# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from l1l11l111l1_l1_ import *
import bidi.algorithm,base64
l1ll1_l1_ = l1l111_l1_ (u"ࠫࡑࡏࡂࡔࡖ࡚ࡓࠬ㍐")
contentsDICT = {}
menuItemsLIST = []
if PY3:
	l11111l111l_l1_ = xbmcvfs.translatePath(l1l111_l1_ (u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰ࡺࡥࡱࡨ࠭㍑"))
	l1ll11ll11_l1_ = xbmcvfs.translatePath(l1l111_l1_ (u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱࡫ࡳࡲ࡫ࠧ㍒"))
	l11l1l111l1_l1_ = xbmcvfs.translatePath(l1l111_l1_ (u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲ࡰࡴ࡭ࡰࡢࡶ࡫ࠫ㍓"))
	l111l1l11l1_l1_ = os.path.join(l1ll11ll11_l1_,l1l111_l1_ (u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪ㍔"),l1l111_l1_ (u"ࠩࡇࡥࡹࡧࡢࡢࡵࡨࠫ㍕"),l1l111_l1_ (u"ࠪࡅࡩࡪ࡯࡯ࡵ࠶࠷࠳ࡪࡢࠨ㍖"))
	l11l1lll111_l1_ = os.path.join(l1ll11ll11_l1_,l1l111_l1_ (u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭㍗"),l1l111_l1_ (u"ࠬࡊࡡࡵࡣࡥࡥࡸ࡫ࠧ㍘"),l1l111_l1_ (u"࠭ࡖࡪࡧࡺࡑࡴࡪࡥࡴ࠸࠱ࡨࡧ࠭㍙"))
	l1llll11l1_l1_ = os.path.join(l1ll11ll11_l1_,l1l111_l1_ (u"ࠧࡶࡵࡨࡶࡩࡧࡴࡢࠩ㍚"),l1l111_l1_ (u"ࠨࡆࡤࡸࡦࡨࡡࡴࡧࠪ㍛"),l1l111_l1_ (u"ࠩࡗࡩࡽࡺࡵࡳࡧࡶ࠵࠸࠴ࡤࡣࠩ㍜"))
	half_triangular_colon = l1l111_l1_ (u"ࡸࠫࡡࡻ࠰࠳ࡦ࠴ࠫ㍝")
	from urllib.parse import quote as _1llll1l11ll_l1_
else:
	l11111l111l_l1_ = xbmc.translatePath(l1l111_l1_ (u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯ࡹࡤࡰࡧࠬ㍞"))
	l1ll11ll11_l1_ = xbmc.translatePath(l1l111_l1_ (u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰ࡪࡲࡱࡪ࠭㍟"))
	l11l1l111l1_l1_ = xbmc.translatePath(l1l111_l1_ (u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱࡯ࡳ࡬ࡶࡡࡵࡪࠪ㍠"))
	l111l1l11l1_l1_ = os.path.join(l1ll11ll11_l1_,l1l111_l1_ (u"ࠧࡶࡵࡨࡶࡩࡧࡴࡢࠩ㍡"),l1l111_l1_ (u"ࠨࡆࡤࡸࡦࡨࡡࡴࡧࠪ㍢"),l1l111_l1_ (u"ࠩࡄࡨࡩࡵ࡮ࡴ࠴࠺࠲ࡩࡨࠧ㍣"))
	l11l1lll111_l1_ = os.path.join(l1ll11ll11_l1_,l1l111_l1_ (u"ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬ㍤"),l1l111_l1_ (u"ࠫࡉࡧࡴࡢࡤࡤࡷࡪ࠭㍥"),l1l111_l1_ (u"ࠬ࡜ࡩࡦࡹࡐࡳࡩ࡫ࡳ࠷࠰ࡧࡦࠬ㍦"))
	l1llll11l1_l1_ = os.path.join(l1ll11ll11_l1_,l1l111_l1_ (u"࠭ࡵࡴࡧࡵࡨࡦࡺࡡࠨ㍧"),l1l111_l1_ (u"ࠧࡅࡣࡷࡥࡧࡧࡳࡦࠩ㍨"),l1l111_l1_ (u"ࠨࡖࡨࡼࡹࡻࡲࡦࡵ࠴࠷࠳ࡪࡢࠨ㍩"))
	half_triangular_colon = l1l111_l1_ (u"ࡷࠪࡠࡺ࠶࠲ࡥ࠳ࠪ㍪").encode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㍫"))
	from urllib import quote as _1llll1l11ll_l1_
l1llll1l1ll1_l1_ = os.path.join(l11l1l111l1_l1_,l1l111_l1_ (u"ࠫࡰࡵࡤࡪ࠰࡯ࡳ࡬࠭㍬"))
l1llllll1lll_l1_ = os.path.join(l11l1l111l1_l1_,l1l111_l1_ (u"ࠬࡱ࡯ࡥ࡫࠱ࡳࡱࡪ࠮࡭ࡱࡪࠫ㍭"))
iptv1_dbfile = os.path.join(addoncachefolder,l1l111_l1_ (u"࠭ࡩࡱࡶࡹ࠵ࡩࡧࡴࡢࡡࡢࡣ࠳ࡪࡢࠨ㍮"))
iptv2_dbfile = os.path.join(addoncachefolder,l1l111_l1_ (u"ࠧࡪࡲࡷࡺ࠷ࡪࡡࡵࡣࡢࡣࡤ࠴ࡤࡣࠩ㍯"))
m3u_dbfile = os.path.join(addoncachefolder,l1l111_l1_ (u"ࠨ࡯࠶ࡹࡩࡧࡴࡢࡡࡢࡣ࠳ࡪࡢࠨ㍰"))
favoritesfile = os.path.join(addoncachefolder,l1l111_l1_ (u"ࠩࡩࡥࡻࡵࡵࡳ࡫ࡷࡩࡸ࠴ࡤࡢࡶࠪ㍱"))
fulliptvfile = os.path.join(addoncachefolder,l1l111_l1_ (u"ࠪ࡭ࡵࡺࡶࡧ࡫࡯ࡩࡤࡥ࡟࠯ࡦࡤࡸࠬ㍲"))
fullm3ufile = os.path.join(addoncachefolder,l1l111_l1_ (u"ࠫࡲ࠹ࡵࡧ࡫࡯ࡩࡤࡥ࡟࠯ࡦࡤࡸࠬ㍳"))
l1l1ll1l1l11_l1_ = os.path.join(addoncachefolder,l1l111_l1_ (u"ࠬࡳࡥࡴࡵࡤ࡫ࡪࡹ࠮ࡥࡣࡷࠫ㍴"))
l1l1lll1ll11_l1_ = os.path.join(addoncachefolder,l1l111_l1_ (u"࠭ࡤࡪࡣ࡯ࡳ࡬ࡥ࠰࠱࠲࠳ࡣ࠳ࡶ࡮ࡨࠩ㍵"))
l1l1l1l1ll1_l1_ = xbmcaddon.Addon().getAddonInfo(l1l111_l1_ (u"ࠧࡱࡣࡷ࡬ࠬ㍶"))
defaulticon = os.path.join(l1l1l1l1ll1_l1_,l1l111_l1_ (u"ࠨ࡫ࡦࡳࡳ࠴ࡰ࡯ࡩࠪ㍷"))
defaultthumb = os.path.join(l1l1l1l1ll1_l1_,l1l111_l1_ (u"ࠩࡷ࡬ࡺࡳࡢ࠯ࡲࡱ࡫ࠬ㍸"))
defaultfanart = os.path.join(l1l1l1l1ll1_l1_,l1l111_l1_ (u"ࠪࡪࡦࡴࡡࡳࡶ࠱ࡴࡳ࡭ࠧ㍹"))
defaultbanner = os.path.join(l1l1l1l1ll1_l1_,l1l111_l1_ (u"ࠫࡧࡧ࡮࡯ࡧࡵ࠲ࡵࡴࡧࠨ㍺"))
defaultlandscape = os.path.join(l1l1l1l1ll1_l1_,l1l111_l1_ (u"ࠬࡲࡡ࡯ࡦࡶࡧࡦࡶࡥ࠯ࡲࡱ࡫ࠬ㍻"))
defaultposter = os.path.join(l1l1l1l1ll1_l1_,l1l111_l1_ (u"࠭ࡰࡰࡵࡷࡩࡷ࠴ࡰ࡯ࡩࠪ㍼"))
defaultclearlogo = os.path.join(l1l1l1l1ll1_l1_,l1l111_l1_ (u"ࠧࡤ࡮ࡨࡥࡷࡲ࡯ࡨࡱ࠱ࡴࡳ࡭ࠧ㍽"))
defaultclearart = os.path.join(l1l1l1l1ll1_l1_,l1l111_l1_ (u"ࠨࡥ࡯ࡩࡦࡸࡡࡳࡶ࠱ࡴࡳ࡭ࠧ㍾"))
l1ll1lll11ll_l1_ = os.path.join(l1l1l1l1ll1_l1_,l1l111_l1_ (u"ࠩࡦ࡬ࡦࡴࡧࡦ࡮ࡲ࡫࠳ࡺࡸࡵࠩ㍿"))
l1lllll1ll_l1_ = os.path.join(l1ll11ll11_l1_,l1l111_l1_ (u"ࠪࡥࡩࡪ࡯࡯ࡵࠪ㎀"))
l1ll1ll1l11l_l1_ = os.path.join(l1ll11ll11_l1_,l1l111_l1_ (u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭㎁"),l1l111_l1_ (u"ࠬࡧࡤࡥࡱࡱࡣࡩࡧࡴࡢࠩ㎂"),addon_id,l1l111_l1_ (u"࠭ࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡺࡰࡰࠬ㎃"))
l1111l11111_l1_ = os.path.join(l11111l111l_l1_,l1l111_l1_ (u"ࠧ࡮ࡧࡧ࡭ࡦ࠭㎄"),l1l111_l1_ (u"ࠨࡈࡲࡲࡹࡹࠧ㎅"),l1l111_l1_ (u"ࠩࡤࡶ࡮ࡧ࡬࠯ࡶࡷࡪࠬ㎆"))
FOLDERS_COUNT = 5
NUMBERS_SEQ_NAME = [l1l111_l1_ (u"ูࠪๆืࠧ㎇"),l1l111_l1_ (u"ࠫศ๎ไࠨ㎈"),l1l111_l1_ (u"ࠬัว็์ࠪ㎉"),l1l111_l1_ (u"࠭หศๆฮࠫ㎊"),l1l111_l1_ (u"ࠧาษห฽ࠬ㎋"),l1l111_l1_ (u"ࠨะสุ้࠭㎌"),l1l111_l1_ (u"ࠩึหิูࠧ㎍"),l1l111_l1_ (u"ࠪืฬฮูࠨ㎎"),l1l111_l1_ (u"ࠫะอๅ็ࠩ㎏"),l1l111_l1_ (u"ࠬะวิ฻ࠪ㎐"),l1l111_l1_ (u"ู࠭ศึิࠫ㎑")]
l1llllll1l1l_l1_ = l1l111_l1_ (u"ࠧ⸼ࠢ⼠ࠤⸯࠦ⸻ࠨ㎒")
l11ll11l_l1_ = 0
l1lll11l1l1l_l1_ = 30*l1l1ll1llll_l1_
l111l11l_l1_ = 2*l1l1l11111l_l1_
l11l1l1_l1_ = 16*l1l1l11111l_l1_
l1lll11l1ll_l1_ = 30*l1l11llll1l_l1_
l1l11l1l11l_l1_ = 1*l1l1l11111l_l1_
l1l1lllllll1_l1_ = [l1l111_l1_ (u"ࠨ࡛ࡗࡆࡤࡉࡈࡂࡐࡑࡉࡑ࡙ࠧ㎓")]
l11111l1111_l1_ = [l1l111_l1_ (u"ࠩࡄࡖࡇࡒࡉࡐࡐ࡝ࠫ㎔"),l1l111_l1_ (u"ࠪࡅࡑࡑࡁࡘࡖࡋࡅࡗ࠭㎕"),l1l111_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࡛ࡏࡐࠨ㎖"),l1l111_l1_ (u"ࠬࡋࡇ࡚ࡆࡈࡅࡉ࠭㎗"),l1l111_l1_ (u"࠭ࡍࡐࡘࡌ࡞ࡑࡇࡎࡅࠩ㎘"),l1l111_l1_ (u"ࠧࡎࡑ࡙ࡗ࠹࡛ࠧ㎙"),l1l111_l1_ (u"ࠨࡏ࡜ࡇࡎࡓࡁࠨ㎚"),l1l111_l1_ (u"ࠩࡏࡅࡗࡕ࡚ࡂࠩ㎛")]
l11111l1111_l1_ += [l1l111_l1_ (u"ࠪࡌࡊࡒࡁࡍࠩ㎜"),l1l111_l1_ (u"ࠫࡘࡋࡒࡊࡇࡖ࠸࡜ࡇࡔࡄࡊࠪ㎝"),l1l111_l1_ (u"ࠬࡇࡋࡐࡃࡐࡇࡆࡓࠧ㎞"),l1l111_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚ࠧ㎟"),l1l111_l1_ (u"ࠧࡄࡋࡐࡅࡈࡒࡕࡑࠩ㎠"),l1l111_l1_ (u"ࠨࡇࡊ࡝ࡓࡕࡗࠨ㎡"),l1l111_l1_ (u"ࠩࡖࡌࡔࡕࡆࡑࡔࡒࠫ㎢"),l1l111_l1_ (u"ࠪࡔࡆࡔࡅࡕࠩ㎣")]
l1l1ll1l1lll_l1_ = [l1l111_l1_ (u"ࠫࡎࡖࡔࡗࠩ㎤"),l1l111_l1_ (u"ࠬࡏࡐࡕࡘ࠰ࡐࡎ࡜ࡅࠨ㎥"),l1l111_l1_ (u"࠭ࡉࡑࡖ࡙࠱ࡒࡕࡖࡊࡇࡖࠫ㎦"),l1l111_l1_ (u"ࠧࡊࡒࡗ࡚࠲࡙ࡅࡓࡋࡈࡗࠬ㎧")]
l1l1ll1l1lll_l1_ += [l1l111_l1_ (u"ࠨࡏ࠶࡙ࠬ㎨"),l1l111_l1_ (u"ࠩࡐ࠷࡚࠳ࡌࡊࡘࡈࠫ㎩"),l1l111_l1_ (u"ࠪࡑ࠸࡛࠭ࡎࡑ࡙ࡍࡊ࡙ࠧ㎪"),l1l111_l1_ (u"ࠫࡒ࠹ࡕ࠮ࡕࡈࡖࡎࡋࡓࠨ㎫")]
l1l1ll1l1lll_l1_ += [l1l111_l1_ (u"ࠬࡏࡆࡊࡎࡐࠫ㎬"),l1l111_l1_ (u"࠭ࡉࡇࡋࡏࡑ࠲ࡇࡒࡂࡄࡌࡇࠬ㎭"),l1l111_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠳ࡅࡏࡉࡏࡍࡘࡎࠧ㎮")]
l1l1ll1l1lll_l1_ += [l1l111_l1_ (u"ࠨࡃࡏࡊࡆ࡚ࡉࡎࡋࠪ㎯"),l1l111_l1_ (u"ࠩࡄࡐࡆࡘࡁࡃࠩ㎰"),l1l111_l1_ (u"ࠪࡅࡐ࡝ࡁࡎࠩ㎱"),l1l111_l1_ (u"ࠫࡆࡒࡍࡂࡃࡕࡉࡋ࠭㎲"),l1l111_l1_ (u"࡙ࠬࡈࡐࡑࡉࡑࡆ࡞ࠧ㎳"),l1l111_l1_ (u"࠭ࡁࡌࡑࡄࡑࠬ㎴"),l1l111_l1_ (u"ࠧࡌࡃࡗࡏࡔ࡚ࡔࡗࠩ㎵")]
l1l1ll1l1lll_l1_ += [l1l111_l1_ (u"ࠨࡍࡄࡖࡇࡇࡌࡂࡖ࡙ࠫ㎶"),l1l111_l1_ (u"ࠩࡅࡓࡐࡘࡁࠨ㎷"),l1l111_l1_ (u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠵ࠬ㎸"),l1l111_l1_ (u"ࠫࡆࡘࡁࡃࡋࡆࡘࡔࡕࡎࡔࠩ㎹"),l1l111_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠷ࠧ㎺"),l1l111_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠲ࠨ㎻")]
l1ll1lll11l_l1_ = [l1l111_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨ㎼"),l1l111_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯࡙ࡍࡉࡋࡏࡔࠩ㎽"),l1l111_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡔࡑࡇ࡙ࡍࡋࡖࡘࡘ࠭㎾"),l1l111_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱ࡈࡎࡁࡏࡐࡈࡐࡘ࠭㎿")]
l1ll1lll11l_l1_ += [l1l111_l1_ (u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏࠩ㏀"),l1l111_l1_ (u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰࡚ࡎࡊࡅࡐࡕࠪ㏁"),l1l111_l1_ (u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱ࡕࡒࡁ࡚ࡎࡌࡗ࡙࡙ࠧ㏂"),l1l111_l1_ (u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲ࡉࡈࡂࡐࡑࡉࡑ࡙ࠧ㏃"),l1l111_l1_ (u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡔࡐࡒࡌࡇࡘ࠭㏄")]
l1lll1111l1_l1_ = [l1l111_l1_ (u"ࠩࡉࡅࡏࡋࡒࡔࡊࡒ࡛ࠬ㏅"),l1l111_l1_ (u"ࠪࡇࡎࡓࡁࡏࡑ࡚ࠫ㏆"),l1l111_l1_ (u"ࠫࡑࡕࡄ࡚ࡐࡈࡘࠬ㏇"),l1l111_l1_ (u"ࠬࡇࡒࡂࡄࡖࡉࡊࡊࠧ㏈"),l1l111_l1_ (u"࠭ࡓࡉࡃࡋࡍࡉࡔࡅࡘࡕࠪ㏉"),l1l111_l1_ (u"ࠧࡄࡋࡐࡅࡈࡒࡕࡃ࡙ࡒࡖࡐ࠭㏊")]
l1lll1111l1_l1_ += [l1l111_l1_ (u"ࠨࡅࡌࡑࡆ࠺ࡕࠨ㏋"),l1l111_l1_ (u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘࠫ㏌"),l1l111_l1_ (u"ࠪࡘ࡛ࡌࡕࡏࠩ㏍"),l1l111_l1_ (u"ࠫ࡜ࡋࡃࡊࡏࡄࠫ㏎"),l1l111_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠹ࠧ㏏"),l1l111_l1_ (u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡂࠨ㏐")]
l1lll1lll1l_l1_ = [l1l111_l1_ (u"ࠧࡄࡋࡐࡅࡆࡈࡄࡐࠩ㏑"),l1l111_l1_ (u"ࠨࡊࡄࡐࡆࡉࡉࡎࡃࠪ㏒"),l1l111_l1_ (u"ࠩࡆࡍࡒࡇࡆࡂࡐࡖࠫ㏓"),l1l111_l1_ (u"ࠪࡇࡎࡓࡁࡍࡋࡊࡌ࡙࠭㏔"),l1l111_l1_ (u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠷࠭㏕"),l1l111_l1_ (u"ࠬࡌࡏࡔࡖࡄࠫ㏖"),l1l111_l1_ (u"࠭ࡁࡉ࡙ࡄࡏࠬ㏗"),l1l111_l1_ (u"ࠧࡇࡃࡅࡖࡆࡑࡁࠨ㏘")]
l1lll1lll1l_l1_ += [l1l111_l1_ (u"ࠨࡕࡋࡓࡋࡎࡁࠨ㏙"),l1l111_l1_ (u"ࠩࡅࡖࡘ࡚ࡅࡋࠩ㏚"),l1l111_l1_ (u"ࠪ࡝ࡆࡗࡏࡕࠩ㏛"),l1l111_l1_ (u"ࠫࡉࡘࡁࡎࡃࡖ࠻ࠬ㏜"),l1l111_l1_ (u"ࠬࡉࡉࡎࡃ࠷࠴࠵࠭㏝"),l1l111_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠴ࠨ㏞")]
l1ll1llll11l_l1_  = [l1l111_l1_ (u"ࠧࡂࡍ࡚ࡅࡒ࠭㏟"),l1l111_l1_ (u"ࠨࡃࡏࡅࡗࡇࡂࠨ㏠"),l1l111_l1_ (u"ࠩࡄࡐࡋࡇࡔࡊࡏࡌࠫ㏡"),l1l111_l1_ (u"ࠪࡅࡗࡇࡂࡔࡇࡈࡈࠬ㏢"),l1l111_l1_ (u"ࠫࡇࡕࡋࡓࡃࠪ㏣"),l1l111_l1_ (u"ࠬࡇࡋࡐࡃࡐࠫ㏤"),l1l111_l1_ (u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠱ࠨ㏥"),l1l111_l1_ (u"ࠧࡇࡃࡖࡉࡑࡎࡄ࠳ࠩ㏦"),l1l111_l1_ (u"ࠨࡅࡌࡑࡆࡉࡌࡖࡄࠪ㏧")]
l1ll1llll11l_l1_ += [l1l111_l1_ (u"ࠩࡆࡍࡒࡇ࠴ࡖࠩ㏨"),l1l111_l1_ (u"ࠪࡇࡎࡓࡁࡇࡃࡑࡗࠬ㏩"),l1l111_l1_ (u"ࠫࡈࡏࡍࡂࡎࡌࡋࡍ࡚ࠧ㏪"),l1l111_l1_ (u"ࠬࡉࡉࡎࡃࡑࡓ࡜࠭㏫"),l1l111_l1_ (u"࠭ࡗࡆࡅࡌࡑࡆ࠭㏬"),l1l111_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊࡎࡆ࡙ࡖࠫ㏭"),l1l111_l1_ (u"ࠨࡈࡒࡗ࡙ࡇࠧ㏮"),l1l111_l1_ (u"ࠩࡄࡌ࡜ࡇࡋࠨ㏯"),l1l111_l1_ (u"ࠪࡊࡆࡈࡒࡂࡍࡄࠫ㏰")]
l1ll1llll11l_l1_ += [l1l111_l1_ (u"ࠫࡋࡇࡊࡆࡔࡖࡌࡔ࡝ࠧ㏱"),l1l111_l1_ (u"ࠬࡎࡁࡍࡃࡆࡍࡒࡇࠧ㏲"),l1l111_l1_ (u"࠭ࡋࡂࡔࡅࡅࡑࡇࡔࡗࠩ㏳"),l1l111_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠲ࠩ㏴"),l1l111_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠴ࠪ㏵"),l1l111_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠶ࠫ㏶"),l1l111_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠸ࠬ㏷")]
l1ll1llll11l_l1_ += [l1l111_l1_ (u"ࠫࡑࡕࡄ࡚ࡐࡈࡘࠬ㏸"),l1l111_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛ࠧ㏹"),l1l111_l1_ (u"࠭ࡓࡉࡑࡒࡊࡒࡇࡘࠨ㏺"),l1l111_l1_ (u"ࠧࡕࡘࡉ࡙ࡓ࠭㏻"),l1l111_l1_ (u"ࠨࡅࡌࡑࡆࡇࡂࡅࡑࠪ㏼"),l1l111_l1_ (u"ࠩࡖࡌࡔࡌࡈࡂࠩ㏽"),l1l111_l1_ (u"ࠪࡇࡎࡓࡁࡄࡎࡘࡆ࡜ࡕࡒࡌࠩ㏾")]
l1ll1llll11l_l1_ += [l1l111_l1_ (u"ࠫࡇࡘࡓࡕࡇࡍࠫ㏿"),l1l111_l1_ (u"ࠬ࡟ࡁࡒࡑࡗࠫ㐀"),l1l111_l1_ (u"࠭ࡄࡓࡃࡐࡅࡘ࠽ࠧ㐁"),l1l111_l1_ (u"ࠧࡄࡋࡐࡅ࠹࠶࠰ࠨ㐂"),l1l111_l1_ (u"ࠨࡃࡕࡅࡇࡏࡃࡕࡑࡒࡒࡘ࠭㐃"),l1l111_l1_ (u"ࠩࡄࡐࡒࡇࡁࡓࡇࡉࠫ㐄"),l1l111_l1_ (u"ࠪࡏࡆ࡚ࡋࡐࡖࡗ࡚ࠬ㐅")]
l1ll111lll11_l1_  = [l1l111_l1_ (u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯࡙ࡍࡉࡋࡏࡔࠩ㐆"),l1l111_l1_ (u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰ࡔࡑࡇ࡙ࡍࡋࡖࡘࡘ࠭㐇"),l1l111_l1_ (u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱ࡈࡎࡁࡏࡐࡈࡐࡘ࠭㐈"),l1l111_l1_ (u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲࡚ࡏࡑࡋࡆࡗࠬ㐉")]
l1ll111lll11_l1_ += [l1l111_l1_ (u"ࠨࡋࡉࡍࡑࡓ࠭ࡂࡔࡄࡆࡎࡉࠧ㐊"),l1l111_l1_ (u"ࠩࡌࡊࡎࡒࡍ࠮ࡇࡑࡋࡑࡏࡓࡉࠩ㐋")]
l1ll111lll11_l1_ += [l1l111_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱࡛ࡏࡄࡆࡑࡖࠫ㐌"),l1l111_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡖࡌࡂ࡛ࡏࡍࡘ࡚ࡓࠨ㐍"),l1l111_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡃࡉࡃࡑࡒࡊࡒࡓࠨ㐎")]
l1ll111lll11_l1_ += [l1l111_l1_ (u"࠭ࡉࡑࡖ࡙࠱ࡑࡏࡖࡆࠩ㐏"),l1l111_l1_ (u"ࠧࡊࡒࡗ࡚࠲ࡓࡏࡗࡋࡈࡗࠬ㐐"),l1l111_l1_ (u"ࠨࡋࡓࡘ࡛࠳ࡓࡆࡔࡌࡉࡘ࠭㐑")]
l1ll111lll11_l1_ += [l1l111_l1_ (u"ࠩࡐ࠷࡚࠳ࡌࡊࡘࡈࠫ㐒"),l1l111_l1_ (u"ࠪࡑ࠸࡛࠭ࡎࡑ࡙ࡍࡊ࡙ࠧ㐓"),l1l111_l1_ (u"ࠫࡒ࠹ࡕ࠮ࡕࡈࡖࡎࡋࡓࠨ㐔")]
l1ll11lll11l_l1_ = [l1l111_l1_ (u"ࠬࡓ࠳ࡖࠩ㐕"),l1l111_l1_ (u"࠭ࡉࡑࡖ࡙ࠫ㐖"),l1l111_l1_ (u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒࠬ㐗"),l1l111_l1_ (u"ࠨࡋࡉࡍࡑࡓࠧ㐘"),l1l111_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪ㐙")]
l1lll11llll_l1_ = l1ll1llll11l_l1_+l1ll111lll11_l1_
l1ll1ll1111l_l1_ = l1ll1llll11l_l1_+l1ll11lll11l_l1_
l1l1111l1l1_l1_ = l1ll1llll11l_l1_+l1ll111lll11_l1_
l1lll11lll1_l1_ = l1l1ll1l1lll_l1_+l1lll1111l1_l1_+l1lll1lll1l_l1_+l1ll1lll11l_l1_
l1lllll1lll1_l1_ = [
						l1l111_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡘࡋࡎࡅࡡࡄࡒࡆࡒ࡙ࡕࡋࡆࡗࡤࡋࡖࡆࡐࡗ࠱࠶ࡹࡴࠨ㐚")
						,l1l111_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡋࡘࡕࡔࡄࡇ࡙ࡥࡍ࠴ࡗ࠻࠱࠶ࡹࡴࠨ㐛")
						,l1l111_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡒࡂࡐࡇࡓࡒࡥࡕࡔࡇࡕࡅࡌࡋࡎࡕ࠯࠴ࡷࡹ࠭㐜")
						,l1l111_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡇࡗࡣࡕࡘࡏ࡙ࡋࡈࡗࡤࡒࡉࡔࡖ࠰࠵ࡸࡺࠧ㐝")
						,l1l111_l1_ (u"ࠧࡊࡒࡗ࡚࠲ࡉࡈࡆࡅࡎࡣࡆࡉࡃࡐࡗࡑࡘ࠲࠷ࡳࡵࠩ㐞")
						,l1l111_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡉࡔࡒࡏࡄࡃࡗࡍࡔࡔ࠭࠲ࡵࡷࠫ㐟")
						,l1l111_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡔࡕࡇࡍࡇࡢࡒࡊ࡝࡟ࡉࡑࡖࡘࡓࡇࡍࡆ࠯࠴ࡷࡹ࠭㐠")
						,l1l111_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡕࡏࡈࡎࡈࡣࡓࡋࡗࡠࡊࡒࡗ࡙ࡔࡁࡎࡇ࠰࠷ࡷࡪࠧ㐡")
						,l1l111_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡘࡅࡂࡆࡢࡅࡑࡒ࡟ࡂࡆࡇࡓࡓ࡙࡟࡙ࡏࡏ࠱࠶ࡹࡴࠨ㐢")
						,l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡉࡒࡓࡌࡒࡅࡖࡕࡈࡖࡈࡕࡎࡕࡇࡑࡘ࠲࠷ࡳࡵࠩ㐣")
						,l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡅ࡝ࡕࡇࡓࡔࡡࡄࡏ࡜ࡇࡍࡠࡅࡄࡔ࡙ࡉࡈࡂ࠯࠶ࡶࡩ࠭㐤")
						,l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡆ࡞ࡖࡁࡔࡕࡢࡅࡐ࡝ࡁࡎࡡࡆࡅࡕ࡚ࡃࡉࡃ࠰࠹ࡹ࡮ࠧ㐥")
						]
l11l1l1l11l_l1_ = l1lllll1lll1_l1_+[
				 l1l111_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡓࡖࡔ࡞࡙ࡠࡖࡈࡗ࡙࠳࠱ࡴࡶࠪ㐦")
				,l1l111_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡓࡕࡋࡎࡖࡔࡏࡣࡍ࡚ࡔࡑࡕࡓࡖࡔ࡞ࡉࡆࡕ࠰࠵ࡸࡺࠧ㐧")
				,l1l111_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤ࡝ࡅࡃࡒࡕࡓ࡝ࡏࡅࡔ࠯࠴ࡷࡹ࠭㐨")
				,l1l111_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡕࡐࡆࡐࡘࡖࡑࡥࡗࡆࡄࡓࡖࡔ࡞ࡉࡆࡕ࠰࠶ࡳࡪࠧ㐩")
				,l1l111_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡘࡇࡅࡔࡗࡕࡘ࡚ࡖࡒ࠱࠶ࡹࡴࠨ㐪")
				,l1l111_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠ࡙ࡈࡆࡕࡘࡏ࡙࡛ࡗࡓ࠲࠸࡮ࡥࠩ㐫")
				,l1l111_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡑࡓࡉࡓ࡛ࡒࡍࡡࡎࡔࡗࡕࡘ࡚ࡅࡒࡑ࠲࠷ࡳࡵࠩ㐬")
				,l1l111_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢࡏࡕࡘࡏ࡙࡛ࡆࡓࡒ࠳࠲࡯ࡦࠪ㐭")
				,l1l111_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡓࡕࡋࡎࡖࡔࡏࡣࡐࡖࡒࡐ࡚࡜ࡇࡔࡓ࠭࠴ࡴࡧࠫ㐮")
				,l1l111_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡈࡎࡅࡄࡍࡢࡌ࡙࡚ࡐࡔࡡࡓࡖࡔ࡞ࡉࡆࡕ࠰࠵ࡸࡺࠧ㐯")
				,l1l111_l1_ (u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠳ࡈࡕࡖࡓࡗࡤ࡚ࡅࡔࡖ࠰࠵ࡸࡺࠧ㐰")
				,l1l111_l1_ (u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙࠭ࡕࡇࡖࡘࡤࡇࡌࡍࡡ࡚ࡉࡇ࡙ࡉࡕࡇࡖ࠱࠶ࡹࡴࠨ㐱")
				,l1l111_l1_ (u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓ࠮ࡖࡈࡗ࡙ࡥࡁࡍࡎࡢ࡛ࡊࡈࡓࡊࡖࡈࡗ࠲࠸࡮ࡥࠩ㐲")
				,l1l111_l1_ (u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࡘࡗࡆࡍࡅࡠࡔࡈࡔࡔࡘࡔ࠮࠳ࡶࡸࠬ㐳")
				,l1l111_l1_ (u"ࠨࡏࡈࡒ࡚࡙࠭ࡔࡊࡒ࡛ࡤࡓࡅࡔࡕࡄࡋࡊ࡙࠭࠲ࡵࡷࠫ㐴")
				,l1l111_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡔࡕࡇࡍࡇࡢࡘࡗࡇࡎࡔࡎࡄࡘࡊ࠳࠱ࡴࡶࠪ㐵")
				,l1l111_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡗࡋࡖࡆࡔࡖࡓࡤ࡚ࡒࡂࡐࡖࡐࡆ࡚ࡅ࠮࠳ࡶࡸࠬ㐶")
				]
l11111lllll_l1_ = [l1l111_l1_ (u"ࠫ࠽࠴࠸࠯࠺࠱࠼ࠬ㐷"),l1l111_l1_ (u"ࠬ࠷࠮࠲࠰࠴࠲࠶࠭㐸"),l1l111_l1_ (u"࠭࠱࠯࠲࠱࠴࠳࠷ࠧ㐹"),l1l111_l1_ (u"ࠧ࠹࠰࠻࠲࠹࠴࠴ࠨ㐺"),l1l111_l1_ (u"ࠨ࠴࠳࠼࠳࠼࠷࠯࠴࠵࠶࠳࠸࠲࠳ࠩ㐻"),l1l111_l1_ (u"ࠩ࠵࠴࠽࠴࠶࠸࠰࠵࠶࠵࠴࠲࠳࠲ࠪ㐼")]
l1l11l1_l1_ = {
			 l1l111_l1_ (u"ࠪࡅࡐࡕࡁࡎࠩ㐽")		:[l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧ࡫ࡰࡣࡰ࠲ࡳ࡫ࡴࠨ㐾")]
			,l1l111_l1_ (u"ࠬࡇࡈࡘࡃࡎࠫ㐿")		:[l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡵ࠱ࡥ࡭ࡽࡡ࡬ࡶࡹ࠲ࡳ࡫ࡴࠨ㑀")]
			,l1l111_l1_ (u"ࠧࡂࡍ࡚ࡅࡒ࠭㑁")		:[l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤ࡯ࡼࡧ࡭࠯ࡰࡨࡸࠬ㑂")]
			,l1l111_l1_ (u"ࠩࡄࡐࡆࡘࡁࡃࠩ㑃")		:[l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡻࡵࡤ࠯ࡣ࡯ࡥࡷࡧࡢ࠯ࡥࡲࡱࠬ㑄")]
			,l1l111_l1_ (u"ࠫࡆࡒࡆࡂࡖࡌࡑࡎ࠭㑅")		:[l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡧ࡬ࡧࡣࡷ࡭ࡲ࡯࠮ࡵࡸࠪ㑆")]
			,l1l111_l1_ (u"࠭ࡁࡍࡏࡄࡅࡗࡋࡆࠨ㑇")		:[l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣ࡯ࡱࡦࡧࡲࡦࡨ࠱ࡧ࡭࠭㑈")]
			,l1l111_l1_ (u"ࠨࡃࡕࡅࡇࡏࡃࡕࡑࡒࡒࡘ࠭㑉")	:[l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡡࡳࡣࡥ࡭ࡨ࠳ࡴࡰࡱࡱࡷ࠳ࡩ࡯࡮ࠩ㑊")]
			,l1l111_l1_ (u"ࠪࡅࡗࡇࡂࡔࡇࡈࡈࠬ㑋")		:[l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡲࡢࡤࡶࡩࡪࡪ࠮࡯ࡧࡷࠫ㑌")]
			,l1l111_l1_ (u"ࠬࡈࡏࡌࡔࡄࠫ㑍")		:[l1l111_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡳࡩࡱࡲࡪࡻࡵࡤ࠯ࡥࡲࡱࠬ㑎")]
			,l1l111_l1_ (u"ࠧࡃࡔࡖࡘࡊࡐࠧ㑏")		:[l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡥࡶࡸࡺࡥ࡫࠰ࡦࡳࡲ࠭㑐")]
			,l1l111_l1_ (u"ࠩࡆࡍࡒࡇ࠴࠱࠲ࠪ㑑")		:[l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡨ࡯࡭ࡢ࠶࠳࠴࠳ࡩ࡯࡮ࠩ㑒")]
			,l1l111_l1_ (u"ࠫࡈࡏࡍࡂ࠶ࡘࠫ㑓")		:[l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࠱ࡤ࡫ࡰࡥ࠹ࡻ࠮ࡤࡱࡰࠫ㑔")]
			,l1l111_l1_ (u"࠭ࡃࡊࡏࡄࡅࡇࡊࡏࠨ㑕")		:[l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡥ࡬ࡱࡦ࠹ࡢࡥࡱ࠱ࡧࡴࡳࠧ㑖")]
			,l1l111_l1_ (u"ࠨࡅࡌࡑࡆࡉࡌࡖࡄࠪ㑗")		:[l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡧ࡮ࡳࡡࡤ࡮ࡸࡦ࠳ࡹ࡫ࡪࡰࠪ㑘")]
			,l1l111_l1_ (u"ࠪࡇࡎࡓࡁࡄࡎࡘࡆ࡜ࡕࡒࡌࠩ㑙")	:[l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡩࡩ࡮ࡣࡦࡰࡺࡨ࠮ࡴࡪࡲࡴࠬ㑚")]
			,l1l111_l1_ (u"ࠬࡉࡉࡎࡃࡉࡅࡓ࡙ࠧ㑛")		:[l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲ࡨ࡯࡭ࡢࡨࡤࡲࡸ࠴ࡣࡰ࡯ࠪ㑜")]
			,l1l111_l1_ (u"ࠧࡄࡋࡐࡅࡑࡏࡇࡉࡖࠪ㑝")	:[l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺ࠶࠻࠴࡭ࡺ࠯ࡦ࡭ࡲࡧ࠮࡯ࡧࡷࠫ㑞")]
			,l1l111_l1_ (u"ࠩࡆࡍࡒࡇࡎࡐ࡙ࠪ㑟")		:[l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡨ࡯࡭ࡢ࠯ࡱࡳࡼ࠴ࡣࡰ࡯ࠪ㑠")]
			,l1l111_l1_ (u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏࠩ㑡")	:[l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮࠯ࡥࡲࡱࠬ㑢"),l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡨࡴࡤࡴ࡭ࡷ࡬࠯ࡣࡳ࡭࠳ࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰ࠱ࡧࡴࡳࠧ㑣")]
			,l1l111_l1_ (u"ࠧࡅࡔࡄࡑࡆ࡙࠷ࠨ㑤")		:[l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡧ࠳ࡪࡲࡢ࡯ࡤࡷ࠼࠴ࡣࡰ࡯ࠪ㑥")]
			,l1l111_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠴ࠫ㑦")		:[l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡳ࠳ࡥࡨࡻ࠱ࡦࡪࡹࡴࠨ㑧")]
			,l1l111_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠷࠭㑨")		:[l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥࡨࡤࡨࡷࡹ࠴ࡳࡵࡱࡵࡩࠬ㑩")]
			,l1l111_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠳ࠨ㑪")		:[l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡫ࡨ࡫ࡾࡨࡥࡴࡶ࠱ࡦ࡮ࡪࠧ㑫")]
			,l1l111_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠶ࠪ㑬")		:[l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩ࡬ࡿ࠭ࡣࡧࡶࡸ࠳ࡴࡥࡵࠩ㑭")]
			,l1l111_l1_ (u"ࠪࡉࡌ࡟ࡄࡆࡃࡇࠫ㑮")		:[l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫ࡧࡺࡦࡨࡥࡩ࠴࡬ࡪࡸࡨࠫ㑯")]
			,l1l111_l1_ (u"ࠬࡋࡌࡄࡋࡑࡉࡒࡇࠧ㑰")		:[l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦ࡮ࡦ࡭ࡳ࡫࡭ࡢ࠰ࡦࡳࡲ࠭㑱")]
			,l1l111_l1_ (u"ࠧࡇࡃࡅࡖࡆࡑࡁࠨ㑲")		:[l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡩࡥࡧࡸ࡫ࡢ࠰ࡦࡳࡲ࠭㑳")]
			,l1l111_l1_ (u"ࠩࡉࡅࡏࡋࡒࡔࡊࡒ࡛ࠬ㑴")	:[l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡫ࡧࡪࡦࡴ࠱ࡷ࡭ࡵࡷࠨ㑵")]
			,l1l111_l1_ (u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠶࠭㑶")		:[l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡪࡦࡹࡥ࡭ࡪࡧ࠲ࡻ࡯ࡰࠨ㑷")]
			,l1l111_l1_ (u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠲ࠨ㑸")		:[l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡶࡰࡦ࠴ࡦࡢࡵࡨࡰ࡭ࡪ࠮ࡤ࡮ࡲࡹࡩ࠭㑹")]
			,l1l111_l1_ (u"ࠨࡈࡒࡗ࡙ࡇࠧ㑺")		:[l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡰ࠮ࡧࡱࡶࡸࡦ࠳ࡴࡷ࠰ࡱࡩࡹ࠭㑻")]
			,l1l111_l1_ (u"ࠪࡌࡆࡒࡁࡄࡋࡐࡅࠬ㑼")		:[l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡮ࡡ࡭ࡣࡦ࡭ࡲࡧ࠮࡮ࡧࡧ࡭ࡦ࠭㑽")]
			,l1l111_l1_ (u"ࠬࡏࡆࡊࡎࡐࠫ㑾")		:[l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡴ࠱࡭࡫࡯࡬࡮ࡶࡹ࠲࡮ࡸࠧ㑿"),l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡱ࠲࡮࡬ࡩ࡭࡯ࡷࡺ࠳࡯ࡲࠨ㒀"),l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡩࡥ࠳࡯ࡦࡪ࡮ࡰࡸࡻ࠴ࡩࡳࠩ㒁"),l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡪࡦ࠸࠮ࡪࡨ࡬ࡰࡲࡺࡶ࠯࡫ࡵࠫ㒂"),l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠽࠸࠴࠱࠺࠲࠱࠶࠹࠴࠱࠳࠴ࠪ㒃")]
			,l1l111_l1_ (u"ࠫࡐࡇࡒࡃࡃࡏࡅ࡙࡜ࠧ㒄")	:[l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡢࡴࡥࡥࡱࡧ࠭ࡵࡸ࠱࡭ࡶ࠭㒅")]
			,l1l111_l1_ (u"࠭ࡋࡂࡖࡎࡓ࡚࡚ࡅࠨ㒆")		:[l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡱࡡࡵ࡭ࡲࡹࡹ࡫࠮ࡤࡱࡰࠫ㒇")]
			,l1l111_l1_ (u"ࠨࡍࡄࡘࡐࡕࡔࡕࡘࠪ㒈")		:[l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡱࡴࡼ࠮࡬࡫ࡷ࡯ࡴࡺ࠮ࡵࡸࠪ㒉")]
			,l1l111_l1_ (u"ࠪࡏࡔࡊࡉࡆࡏࡄࡈࡤࡇࡐࡑࠩ㒊")	:[l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡺࡩ࡯ࡻ࠱ࡧࡨ࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤࠨ㒋"),l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶ࠶࠵࠷࠸࠯ࡨࡺࡷ࠳ࡹࡴࡰࡴࡨࠫ㒌")]
			,l1l111_l1_ (u"࠭ࡌࡐࡆ࡜ࡒࡊ࡚ࠧ㒍")		:[l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡮ࡲࡨࡾࡴࡥࡵ࠰ࡦࡥࡲ࠭㒎")]
			,l1l111_l1_ (u"ࠨࡒࡄࡒࡊ࡚ࠧ㒏")		:[l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡰࡢࡰࡨࡸ࠳ࡩ࡯࠯࡫࡯ࠫ㒐")]
			,l1l111_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙ࠬ㒑")		:[l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹࡨࡢࡣ࠱ࡧࡦࡳࠧ㒒")]
			,l1l111_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈࡓࡋࡗࡔࠩ㒓")	:[l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦ࠰ࡶ࡬࠹ࡻ࠮࡯ࡧࡺࡷࠬ㒔")]
			,l1l111_l1_ (u"ࠧࡔࡊࡒࡊࡍࡇࠧ㒕")		:[l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨ࠲ࡸ࡮࡯ࡧࡪࡤ࠲ࡹࡼࠧ㒖")]
			,l1l111_l1_ (u"ࠩࡖࡌࡔࡕࡆࡎࡃ࡛ࠫ㒗")		:[l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸ࡮࡯ࡰࡨࡰࡥࡽ࠴ࡣࡰ࡯ࠪ㒘"),l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹࡴࡢࡶ࡬ࡧ࠳ࡹࡨࡰࡱࡩࡱࡦࡾ࠮ࡤࡱࡰࠫ㒙"),l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡩࡱࡲࡪࡲࡧࡸ࠯ࡣࡽࡹࡷ࡫ࡥࡥࡩࡨ࠲ࡳ࡫ࡴࠨ㒚")]
			,l1l111_l1_ (u"࠭ࡔࡗࡈࡘࡒࠬ㒛")		:[l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡵ࠱ࡸࡻ࡬ࡵ࡯࠰ࡰࡩࠬ㒜")]
			,l1l111_l1_ (u"ࠨ࡙ࡈࡇࡎࡓࡁࠨ㒝")		:[l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡪࡩࡩ࡮ࡣ࠱ࡧࡱ࡯ࡣ࡬ࠩ㒞")]
			,l1l111_l1_ (u"ࠪ࡝ࡆࡗࡏࡕࠩ㒟")		:[l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡿ࠮ࡺࡣࡴࡳࡹ࠴ࡴࡷࠩ㒠")]
			,l1l111_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭㒡")		:[l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡩ࡯࡮ࠩ㒢")]
			,l1l111_l1_ (u"ࠧࡑ࡛ࡗࡌࡔࡔࠧ㒣")		:[l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡻ࡫ࡲࡤࡧ࡯࠲ࡦࡶࡰ࠰࡮࡬ࡷࡹࡶ࡬ࡢࡻࠪ㒤"),l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡼࡥࡳࡥࡨࡰ࠳ࡧࡰࡱ࠱ࡸࡷࡦ࡭ࡥࡳࡧࡳࡳࡷࡺࠧ㒥"),l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲ࡷࡪࡴࡤࡦ࡯ࡤ࡭ࡱ࠭㒦"),l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡷࡧࡵࡧࡪࡲ࠮ࡢࡲࡳ࠳࡬࡫ࡴ࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩ㒧"),l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡸࡨࡶࡨ࡫࡬࠯ࡣࡳࡴ࠴࡭ࡥࡵ࡫ࡶࡰࡦࡳࡩࡤࠩ㒨"),l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵ࡧࡦࡶࡴࡹࡪࡹࡴࡪࡱࡱࡷࠬ㒩"),l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡺࡪࡸࡣࡦ࡮࠱ࡥࡵࡶ࠯ࡨࡧࡷ࡯ࡳࡵࡷ࡯ࡧࡵࡶࡴࡸࡳࠨ㒪"),l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡻ࡫ࡲࡤࡧ࡯࠲ࡦࡶࡰ࠰ࡥࡤࡴࡹࡩࡨࡢࠩ㒫"),l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡼࡥࡳࡥࡨࡰ࠳ࡧࡰࡱ࠱ࡷࡩࡸࡺࡩ࡯ࡩࠪ㒬")]
			,l1l111_l1_ (u"ࠪࡔ࡞࡚ࡈࡐࡐࡢࡆࡐࡖࠧ㒭")	:[l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡵ࡬࠰ࡷࡳ࠴ࡲࡩࡴࡶࡳࡰࡦࡿࠧ㒮"),l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡶ࡭࠱ࡸࡴ࠵ࡵࡴࡣࡪࡩࡷ࡫ࡰࡰࡴࡷࠫ㒯"),l1l111_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡷ࡮࠲ࡹࡵ࠯ࡴࡧࡱࡨࡪࡳࡡࡪ࡮ࠪ㒰"),l1l111_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡸ࡯࠳ࡺ࡯࠰ࡩࡨࡸࡲ࡫ࡳࡴࡣࡪࡩࡸ࠭㒱"),l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡹࡰ࠴ࡴࡰ࠱ࡪࡩࡹ࡯ࡳ࡭ࡣࡰ࡭ࡨ࠭㒲"),l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡺࡱ࠮ࡵࡱ࠲࡫ࡪࡺࡱࡶࡧࡶࡸ࡮ࡵ࡮ࡴࠩ㒳"),l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡻ࡫࠯ࡶࡲ࠳࡬࡫ࡴ࡬ࡰࡲࡻࡳ࡫ࡲࡳࡱࡵࡷࠬ㒴"),l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡵ࡬࠰ࡷࡳ࠴ࡩࡡࡱࡶࡦ࡬ࡦ࠭㒵"),l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡶ࡭࠱ࡸࡴ࠵ࡴࡦࡵࡷ࡭ࡳ࡭ࠧ㒶")]
			,l1l111_l1_ (u"࠭ࡒࡆࡒࡒࡗࠬ㒷")		:[l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡲࡪࡺ࡬ࡪࡨࡼ࠲ࡦࡶࡰ࠰ࡍࡒࡈࡎࡘࡅࡑࡑ࠲ࡅࡉࡊࡏࡏࡕ࠲ࡥࡩࡪ࡯࡯ࡵ࠱ࡼࡲࡲࠧ㒸"),l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡳ࡫ࡴ࡭࡫ࡩࡽ࠳ࡧࡰࡱ࠱ࡎࡓࡉࡏࡒࡆࡒࡒ࠳ࡆࡊࡄࡐࡐࡖ࠵࠽࠵ࡡࡥࡦࡲࡲࡸ࠷࠸࠯ࡺࡰࡰࠬ㒹"),l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡴࡥࡵ࡮࡬ࡪࡾ࠴ࡡࡱࡲ࠲ࡏࡔࡊࡉࡓࡇࡓࡓ࠴ࡇࡄࡅࡑࡑࡗ࠶࠿࠯ࡢࡦࡧࡳࡳࡹ࠱࠺࠰ࡻࡱࡱ࠭㒺")]
			,l1l111_l1_ (u"ࠪࡖࡊࡖࡏࡔࡡࡅࡏࡕ࠭㒻")	:[l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡴࡨࡴࡴ࠴ࡵ࡬࠰ࡷࡳ࠴ࡇࡄࡅࡑࡑࡗ࠴ࡧࡤࡥࡱࡱࡷ࠳ࡾ࡭࡭ࠩ㒼"),l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡵࡩࡵࡵ࠮ࡶ࡭࠱ࡸࡴ࠵ࡁࡅࡆࡒࡒࡘ࠷࠸࠰ࡣࡧࡨࡴࡴࡳ࠲࠺࠱ࡼࡲࡲࠧ㒽"),l1l111_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡶࡪࡶ࡯࠯ࡷ࡮࠲ࡹࡵ࠯ࡂࡆࡇࡓࡓ࡙࠱࠺࠱ࡤࡨࡩࡵ࡮ࡴ࠳࠼࠲ࡽࡳ࡬ࠨ㒾")]
			,l1l111_l1_ (u"ࠧࡔࡑࡘࡖࡈࡋࡓࠨ㒿")		:[l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠳ࡶࡹࡵࡪࡲࡲࡦࡴࡹࡸࡪࡨࡶࡪ࠴ࡣࡰ࡯࠲࡯ࡴࡪࡩࠨ㓀"),l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡹࡵࡳࡩࡨ࠲ࡸ࡮ࠧ㓁"),l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴࡮ࡦࡶ࡯࡭࡫ࡿ࠮ࡢࡲࡳ࠳ࡐࡕࡄࡊࡔࡈࡔࡔ࠭㓂")]
			}
l1111lll111_l1_ = [l1l111_l1_ (u"ࠫࡑࡏࡓࡕࡒࡏࡅ࡞࠭㓃"),l1l111_l1_ (u"ࠬࡘࡅࡑࡑࡕࡘࡘ࠭㓄"),l1l111_l1_ (u"࠭ࡅࡎࡃࡌࡐࡘ࠭㓅"),l1l111_l1_ (u"ࠧࡎࡇࡖࡗࡆࡍࡅࡔࠩ㓆"),l1l111_l1_ (u"ࠨࡋࡖࡐࡆࡓࡉࡄࡕࠪ㓇"),l1l111_l1_ (u"ࠩࡔ࡙ࡊ࡙ࡔࡊࡑࡑࡗࠬ㓈"),l1l111_l1_ (u"ࠪࡏࡓࡕࡗࡏࡇࡕࡖࡔࡘࡓࠨ㓉"),l1l111_l1_ (u"ࠫࡈࡇࡐࡕࡅࡋࡅࠬ㓊"),l1l111_l1_ (u"࡚ࠬࡅࡔࡖࡌࡒࡌ࠭㓋")]
l11l11l1ll1_l1_ = [l1l111_l1_ (u"࠭ࡁࡅࡆࡒࡒࡘ࠭㓌"),l1l111_l1_ (u"ࠧࡂࡆࡇࡓࡓ࡙࠱࠹ࠩ㓍"),l1l111_l1_ (u"ࠨࡃࡇࡈࡔࡔࡓ࠲࠻ࠪ㓎")]
class l1ll11lll1ll_l1_(l1l1l1llll1_l1_):
	def __init__(self,*args,**kwargs):
		self.l11llllll11_l1_ = -1
	def onClick(self,l1111l111ll_l1_):
		if l1111l111ll_l1_>=9010: self.l11llllll11_l1_ = l1111l111ll_l1_-9010
		self.delete()
	def l111llll1l1_l1_(self,*args):
		self.l111l11l1l1_l1_,self.l1ll11l1ll1l_l1_,self.l111l11llll_l1_ = args[0],args[1],args[2]
		self.header,self.text = args[3],args[4]
		self.profile,self.l1lll1111l1l_l1_ = args[5],args[6]
		self.l1lll111l1l1_l1_,self.l1l1ll1l111l_l1_,self.l1ll11111lll_l1_ = args[7],args[8],args[9]
		if self.l1l1ll1l111l_l1_>0 or self.l1ll11111lll_l1_>0: self.l1ll1ll1ll11_l1_ = True
		else: self.l1ll1ll1ll11_l1_ = False
		self.l1lll111l1ll_l1_,self.l111llll1ll_l1_ = l1llllll1ll1_l1_(self.l111l11l1l1_l1_,self.l1ll11l1ll1l_l1_,self.l111l11llll_l1_,self.header,self.text,self.profile,self.l1lll1111l1l_l1_,self.l1lll111l1l1_l1_,self.l1ll1ll1ll11_l1_)
		self.show()
		self.getControl(9050).setImage(self.l1lll111l1ll_l1_)
		self.getControl(9050).setHeight(self.l111llll1ll_l1_)
		if not self.l1ll11l1ll1l_l1_ and self.l111l11l1l1_l1_ and self.l111l11llll_l1_: self.getControl(9012).setPosition(-220,0)
		return self.l1lll111l1ll_l1_,self.l111llll1ll_l1_
	def l11lllll11l_l1_(self):
		if self.l1l1ll1l111l_l1_:
			from threading import Thread
			self.l1l11l11l1l_l1_ = Thread(target=self.l1lll11lllll_l1_,args=())
			self.l1l11l11l1l_l1_.start()
		else: self.l11l111lll1_l1_()
	def l1lll11lllll_l1_(self):
		self.getControl(9020).setEnabled(True)
		for l1l111lll1_l1_ in range(1,self.l1l1ll1l111l_l1_+1):
			time.sleep(1)
			l1l1ll1l1l1l_l1_ = int(100*l1l111lll1_l1_/self.l1l1ll1l111l_l1_)
			self.l1l1llll111l_l1_(l1l1ll1l1l1l_l1_)
			if self.l11llllll11_l1_>0: break
		self.l11l111lll1_l1_()
	def l11lll111l1_l1_(self):
		if self.l1ll11111lll_l1_:
			from threading import Thread
			self.l1l11l11ll1_l1_ = Thread(target=self.l1lllllllll1_l1_,args=())
			self.l1l11l11ll1_l1_.start()
		else: self.l11l111lll1_l1_()
	def l1lllllllll1_l1_(self):
		self.getControl(9020).setEnabled(True)
		time.sleep(self.l1l1ll1l111l_l1_)
		for l1l111lll1_l1_ in range(self.l1ll11111lll_l1_-1,-1,-1):
			time.sleep(1)
			l1l1ll1l1l1l_l1_ = int(100*l1l111lll1_l1_/self.l1ll11111lll_l1_)
			self.l1l1llll111l_l1_(l1l1ll1l1l1l_l1_)
			if self.l11llllll11_l1_>0: break
		if self.l1ll11111lll_l1_>0: self.l11llllll11_l1_ = 10
		self.delete()
	def l1l1llll111l_l1_(self,l1l1ll1l1l1l_l1_):
		self.l1ll1111ll11_l1_ = l1l1ll1l1l1l_l1_
		self.getControl(9020).setPercent(self.l1ll1111ll11_l1_)
	def l11l111lll1_l1_(self):
		if self.l111l11l1l1_l1_: self.getControl(9010).setEnabled(True)
		if self.l1ll11l1ll1l_l1_: self.getControl(9011).setEnabled(True)
		if self.l111l11llll_l1_: self.getControl(9012).setEnabled(True)
	def delete(self):
		self.close()
		try: os.remove(self.l1lll111l1ll_l1_)
		except: pass
class l11l11l1111_l1_():
	def __init__(self,l11_l1_=False,l1ll1ll1llll_l1_=True):
		self.l11_l1_ = l11_l1_
		self.l1ll1ll1llll_l1_ = l1ll1ll1llll_l1_
		self.l11l1l111ll_l1_,self.l1l1111l11l_l1_ = [],[]
		self.l1111l11l11_l1_,self.l1lllll11l11_l1_ = {},{}
		self.l111ll11ll1_l1_ = []
		self.l1l1llll11l1_l1_,self.l1l1llllll11_l1_,self.l11llll11l1_l1_ = {},{},{}
	def l11l1111l11_l1_(self,id,func,*args):
		id = str(id)
		self.l1111l11l11_l1_[id] = l1l111_l1_ (u"ࠩࡵࡹࡳࡴࡩ࡯ࡩࠪ㓏")
		if self.l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠪࠫ㓐"),id)
		from threading import Thread
		l11lllllll1_l1_ = Thread(target=self.run,args=(id,func,args))
		self.l111ll11ll1_l1_.append(l11lllllll1_l1_)
		return l11lllllll1_l1_
	def start_new_thread(self,id,func,*args):
		l11lllllll1_l1_ = self.l11l1111l11_l1_(id,func,*args)
		l11lllllll1_l1_.start()
	def run(self,id,func,args):
		id = str(id)
		self.l1l1llll11l1_l1_[id] = time.time()
		try:
			self.l1lllll11l11_l1_[id] = func(*args)
			if l1l111_l1_ (u"ࠫࡔࡖࡅࡏࡗࡕࡐࠬ㓑") in str(func) and not self.l1lllll11l11_l1_[id].succeeded:
				l111111l1l1_l1_(l1l111_l1_ (u"ࠬࡌ࡯ࡳࡥࡨࡨࠥ࡫ࡸࡪࡶࠣࡨࡺ࡫ࠠࡵࡱࠣࡸ࡭ࡸࡥࡢࡦࡨࡨࠥࡕࡐࡆࡐࡘࡖࡑࠦࡦࡢ࡫࡯ࠫ㓒"))
			self.l11l1l111ll_l1_.append(id)
			self.l1111l11l11_l1_[id] = l1l111_l1_ (u"࠭ࡦࡪࡰ࡬ࡷ࡭࡫ࡤࠨ㓓")
		except Exception as err:
			if self.l1ll1ll1llll_l1_:
				l1111ll1l11_l1_ = traceback.format_exc()
				sys.stderr.write(l1111ll1l11_l1_)
			self.l1l1111l11l_l1_.append(id)
			self.l1111l11l11_l1_[id] = l1l111_l1_ (u"ࠧࡧࡣ࡬ࡰࡪࡪࠧ㓔")
		self.l1l1llllll11_l1_[id] = time.time()
		self.l11llll11l1_l1_[id] = self.l1l1llllll11_l1_[id] - self.l1l1llll11l1_l1_[id]
	def l1ll1ll1lll1_l1_(self):
		for proc in self.l111ll11ll1_l1_:
			proc.start()
	def l1l1ll1ll1l1_l1_(self):
		while l1l111_l1_ (u"ࠨࡴࡸࡲࡳ࡯࡮ࡨࠩ㓕") in list(self.l1111l11l11_l1_.values()): time.sleep(1.000)
def l1lll111111l_l1_():
	l1ll1l1l1l1l_l1_ = settings.getSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡼࡥࡳࡵ࡬ࡳࡳ࠭㓖"))
	l111l111ll1_l1_ = True
	if l1ll1l1l1l1l_l1_==l1l11l1l1l1_l1_:
		status = l1l111_l1_ (u"ࠪࡒࡔࡥࡕࡑࡆࡄࡘࡊ࠭㓗")
		l111l111ll1_l1_ = False
	elif not os.path.exists(addoncachefolder):
		status = l1l111_l1_ (u"ࠫࡋ࡛ࡌࡍࡡࡘࡔࡉࡇࡔࡆࠩ㓘")
		os.makedirs(addoncachefolder)
	else:
		status = l1l111_l1_ (u"ࠬࡌࡕࡍࡎࡢ࡙ࡕࡊࡁࡕࡇࠪ㓙")
		l11l1ll1l1l_l1_ = [l1l111_l1_ (u"࠭࠸࠯࠷࠱࠴ࠬ㓚"),l1l111_l1_ (u"ࠧ࠳࠲࠵࠵࠳࠷࠰࠯࠳࠼ࠫ㓛"),l1l111_l1_ (u"ࠨ࠴࠳࠶࠶࠴࠱࠲࠰࠵࠸ࡦ࠭㓜"),l1l111_l1_ (u"ࠩ࠵࠴࠷࠷࠮࠲࠴࠱࠷࠵࠭㓝"),l1l111_l1_ (u"ࠪ࠶࠵࠸࠲࠯࠲࠵࠲࠵࠸ࠧ㓞"),l1l111_l1_ (u"ࠫ࠷࠶࠲࠳࠰࠴࠴࠳࠸࠲ࠨ㓟"),l1l111_l1_ (u"ࠬ࠸࠰࠳࠵࠱࠴࠸࠴࠰࠷ࠩ㓠"),l1l111_l1_ (u"࠭࠲࠱࠴࠶࠲࠵࠻࠮࠲࠸ࠪ㓡"),l1l111_l1_ (u"ࠧ࠳࠲࠵࠷࠳࠶࠶࠯࠲࠹ࠫ㓢"),l1l111_l1_ (u"ࠨ࠴࠳࠶࠸࠴࠱࠱࠰࠵࠼ࠬ㓣")]
		l1llll1ll11l_l1_ = l11l1ll1l1l_l1_[-1]
		l111l1l111l_l1_ = l1l1ll1l11ll_l1_(l1llll1ll11l_l1_)
		l1lll1llll1l_l1_ = l1l1ll1l11ll_l1_(l1l11l1l1l1_l1_)
		if l1lll1llll1l_l1_>l111l1l111l_l1_:
			status = l1l111_l1_ (u"ࠩࡖࡍࡒࡖࡌࡆࡡࡘࡔࡉࡇࡔࡆࠩ㓤")
	return status,l111l111ll1_l1_
def l111111l111_l1_(l1lll111ll1_l1_,l1lll1ll1ll1_l1_):
	succeeded,l1111ll11l1_l1_,l11ll1l1l11_l1_ = True,False,False
	type,name,l1l1l1l11l1_l1_,mode,l1l1ll1111l_l1_,l1l111l11ll_l1_,text,context,l1llllll111_l1_ = l1lll111ll1_l1_
	l1l1llllll1l_l1_ = type,name,l1l1l1l11l1_l1_,mode,l1l1ll1111l_l1_,l1l111l11ll_l1_,text,l1l111_l1_ (u"ࠪࠫ㓥"),l1llllll111_l1_
	l1ll1ll11l1l_l1_ = int(mode)
	l1ll1ll11l11_l1_ = int(l1ll1ll11l1l_l1_%10)
	l1ll1ll11ll1_l1_ = int(l1ll1ll11l1l_l1_/10)
	l1l1ll1ll11l_l1_ = settings.getSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮࡮ࡧࡱࡹࡸࡥࡣࡢࡥ࡫ࡩ࠳ࡹࡴࡢࡶࡸࡷࠬ㓦"))
	l1111lll11l_l1_,l111l111ll1_l1_ = l1lll111111l_l1_()
	if l111l111ll1_l1_:
		l1111l1_l1_(l1l111_l1_ (u"ࠬ࠭㓧"),l1l111_l1_ (u"࠭ࠧ㓨"),l1l111_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ㓩"),l1l111_l1_ (u"ࠨฬ่ࠤฯำฯ๋อࠣห้ฮั็ษ่ะࠥ็๊ࠡฮ๊หื้࡜࡯ว็ํࠥอไฦืาหึࠦัใ็࠽ࡠࡳࡢ࡮ࠨ㓪")+l1l11l1l1l1_l1_)
		l1lll1l1lll_l1_(main_dbfile,l1l111_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬ㓫"),l1l111_l1_ (u"ࠪࡕ࡚ࡋࡓࡕࡋࡒࡒࡘ࠭㓬"))
		l1lll1l1lll_l1_(main_dbfile,l1l111_l1_ (u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧ㓭"),l1l111_l1_ (u"ࠬࡇࡌࡍࡡࡄࡈࡉࡕࡎࡔࡡ࡛ࡑࡑ࠭㓮"))
		l1lll1l1lll_l1_(main_dbfile,l1l111_l1_ (u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩ㓯"),l1l111_l1_ (u"ࠧࡂࡗࡗࡌࠬ㓰"))
		l1lll1l1lll_l1_(main_dbfile,l1l111_l1_ (u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫ㓱"),l1l111_l1_ (u"ࠩࡌࡈࡘ࠭㓲"))
		settings.setSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡨࡰࡵࡷ࠲࡫ࡧࡳࡦ࡮࡫ࡨ࠶࠭㓳"),l1l111_l1_ (u"ࠫࠬ㓴"))
		settings.setSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡪࡲࡷࡹ࠴ࡦࡰࡵࡷࡥࠬ㓵"),l1l111_l1_ (u"࠭ࠧ㓶"))
		settings.setSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱࡬ࡴࡹࡴ࠯ࡨࡤࡦࡷࡧ࡫ࡢࠩ㓷"),l1l111_l1_ (u"ࠨࠩ㓸"))
		settings.setSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳࡮࡯ࡴࡶ࠱ࡷ࡭ࡧࡨࡪࡦ࠷ࡹࠬ㓹"),l1l111_l1_ (u"ࠪࠫ㓺"))
		settings.setSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮࡮ࡧࡶࡷࡦ࡭ࡥࡴ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯ࠬ㓻"),l1l111_l1_ (u"ࠬ࠭㓼"))
		settings.setSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡴࡹࡪࡹࡴࡪࡱࡱࡷ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫ࠨ㓽"),l1l111_l1_ (u"ࠧࠨ㓾"))
		settings.setSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡺࡹࡥࡳ࠰ࡳࡶ࡮ࡼࡳࠨ㓿"),l1l111_l1_ (u"ࠩࠪ㔀"))
		settings.setSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡩ࡯ࡨࡲࡷ࠳ࡶࡥࡳ࡫ࡲࡨࠬ㔁"),l1l111_l1_ (u"ࠫࠬ㔂"))
		settings.setSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡴࡨࡴࡴࡹ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭ࠪ㔃"),l1l111_l1_ (u"࠭ࠧ㔄"))
		import l1l1l111l11_l1_
		if l1111lll11l_l1_==l1l111_l1_ (u"ࠧࡔࡋࡐࡔࡑࡋ࡟ࡖࡒࡇࡅ࡙ࡋࠧ㔅"):
			l11llllll1_l1_(l1l111_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ㔆"),l1l111_l1_ (u"ࠩ࠱ࠤࠥࡇࡲࡢࡤ࡬ࡧ࡛࡯ࡤࡦࡱࡶࠤ࡚ࡶࡤࡢࡶࡨࠤ࡙ࡿࡰࡦ࠼ࠣࠤࡘࡏࡍࡑࡎࡈࠤ࡚ࡖࡄࡂࡖࡈࠤࠥࠦࡐࡢࡶ࡫࠾ࠥࡡࠠࠨ㔇")+addon_path+l1l111_l1_ (u"ࠪࠤࡢ࠭㔈"))
			l1lll1l1lll_l1_(main_dbfile,l1l111_l1_ (u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡓࡊࡖࡈࡗࠬ㔉"))
			l1lll1l1lll_l1_(main_dbfile,l1l111_l1_ (u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡊࡒࡗ࡚ࠬ㔊"))
			l1lll1l1lll_l1_(main_dbfile,l1l111_l1_ (u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡏ࠶࡙ࠬ㔋"))
		else:
			l11llllll1_l1_(l1l111_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㔌"),l1l111_l1_ (u"ࠨ࠰ࠣࠤࡆࡸࡡࡣ࡫ࡦ࡚࡮ࡪࡥࡰࡵ࡙ࠣࡵࡪࡡࡵࡧࠣࡘࡾࡶࡥ࠻ࠢࠣࡊ࡚ࡒࡌࠡࡗࡓࡈࡆ࡚ࡅࠡࠢࠣࡔࡦࡺࡨ࠻ࠢ࡞ࠤࠬ㔍")+addon_path+l1l111_l1_ (u"ࠩࠣࡡࠬ㔎"))
			l1111l1_l1_(l1l111_l1_ (u"ࠪࠫ㔏"),l1l111_l1_ (u"ࠫࠬ㔐"),l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㔑"),l1l111_l1_ (u"࠭สๆࠢอฯอ๐สࠡล๋ࠤฯำฯ๋อࠣห้หีะษิࠤฬ๊ฬะ์าࠤ้ฮั็ษ่ะࠥอไโ์า๎ํํวหࠢส่฾ืศ๋หࠣ࠲ࠥษ่ࠡฬ่ࠤู๊อࠡๅสุࠥอไษำ้ห๊าࠠ࡝ࡰ࡟ࡲู๊ࠥใ๊่ࠤฬ๊ย็ࠢส่อืๆศ็ฯࠤอฮูืࠢส่ๆำ่ึษอࠤ้฼ๅศ่ࠣ฽๊๊ࠠศๆหี๋อๅอࠢหูํืษࠡืะ๎าฯ้ࠠ็อ็ฬ๋ไสࠩ㔒"))
			l11l1ll1ll1_l1_()
			FIX_ALL_DATABASES(False)
			l1l1l111l11_l1_.l1ll11l1l111_l1_()
			l1l1l111l11_l1_.l1l1l1lll1l_l1_(l1l111_l1_ (u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡧࡤࡢࡲࡷ࡭ࡻ࡫ࠧ㔓"),False)
			l1l1l111l11_l1_.l1l1l1lll1l_l1_(l1l111_l1_ (u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡲࡵ࡯ࡳࠫ㔔"),False)
			l1l1l111l11_l1_.l1lllllll11l_l1_(False)
			l1l1l111l11_l1_.l1ll11l1111l_l1_(False)
			l1l1l111l11_l1_.l111l1lll1l_l1_(l1l111_l1_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧ㔕"),l1l111_l1_ (u"ࠪࡩࡳࡧࡢ࡭ࡧࠪ㔖"),False)
			try:
				l11l1ll1111_l1_ = os.path.join(l1ll11ll11_l1_,l1l111_l1_ (u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭㔗"),l1l111_l1_ (u"ࠬࡧࡤࡥࡱࡱࡣࡩࡧࡴࡢࠩ㔘"),l1l111_l1_ (u"࠭ࡳࡤࡴ࡬ࡴࡹ࠴࡭ࡰࡦࡸࡰࡪ࠴ࡲࡦࡵࡲࡰࡻ࡫ࡵࡳ࡮ࠪ㔙"),l1l111_l1_ (u"ࠧࡴࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡻࡱࡱ࠭㔚"))
				l11111lll1l_l1_ = xbmcaddon.Addon(id=l1l111_l1_ (u"ࠨࡵࡦࡶ࡮ࡶࡴ࠯࡯ࡲࡨࡺࡲࡥ࠯ࡴࡨࡷࡴࡲࡶࡦࡷࡵࡰࠬ㔛"))
				l11111lll1l_l1_.setSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡧࡵࡵࡱࡢࡴ࡮ࡩ࡫ࠨ㔜"),l1l111_l1_ (u"ࠪࡪࡦࡲࡳࡦࠩ㔝"))
			except: pass
			try:
				l11l1ll1111_l1_ = os.path.join(l1ll11ll11_l1_,l1l111_l1_ (u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭㔞"),l1l111_l1_ (u"ࠬࡧࡤࡥࡱࡱࡣࡩࡧࡴࡢࠩ㔟"),l1l111_l1_ (u"࠭ࡳࡤࡴ࡬ࡴࡹ࠴࡭ࡰࡦࡸࡰࡪ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡥ࡮ࠪ㔠"),l1l111_l1_ (u"ࠧࡴࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡻࡱࡱ࠭㔡"))
				l11111lll1l_l1_ = xbmcaddon.Addon(id=l1l111_l1_ (u"ࠨࡵࡦࡶ࡮ࡶࡴ࠯࡯ࡲࡨࡺࡲࡥ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡧࡰࠬ㔢"))
				l11111lll1l_l1_.setSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡼࡩࡥࡧࡲࡣࡶࡻࡡ࡭࡫ࡷࡽࠬ㔣"),l1l111_l1_ (u"ࠪ࠷ࠬ㔤"))
			except: pass
			try:
				l11l1ll1111_l1_ = os.path.join(l1ll11ll11_l1_,l1l111_l1_ (u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭㔥"),l1l111_l1_ (u"ࠬࡧࡤࡥࡱࡱࡣࡩࡧࡴࡢࠩ㔦"),l1l111_l1_ (u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠭㔧"),l1l111_l1_ (u"ࠧࡴࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡻࡱࡱ࠭㔨"))
				l11111lll1l_l1_ = xbmcaddon.Addon(id=l1l111_l1_ (u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡡࡥࡣࡳࡸ࡮ࡼࡥࠨ㔩"))
				l11111lll1l_l1_.setSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳࡙ࡔࡓࡇࡄࡑࡘࡋࡌࡆࡅࡗࡍࡔࡔࠧ㔪"),l1l111_l1_ (u"ࠪ࠶ࠬ㔫"))
			except: pass
		data = FIX_AND_GET_FILE_CONTENTS(l1l1l11l111_l1_)
		data = FIX_AND_GET_FILE_CONTENTS(favoritesfile)
		data = FIX_AND_GET_FILE_CONTENTS(l1l1ll1l1l11_l1_)
		settings.setSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡷࡧࡵࡷ࡮ࡵ࡮ࠨ㔬"),l1l11l1l1l1_l1_)
		l1l1l111l11_l1_.l11ll1lll11_l1_(False)
	l1ll11l1l1_l1_ = settings.getSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡴࡨࡪࡷ࡫ࡳࡩ࠰ࡶࡸࡦࡺࡵࡴࠩ㔭"))
	l1l111l1ll_l1_ = l11lll11lll_l1_(l1lll1ll1ll1_l1_)
	l1l11llll11_l1_ = l11lll11lll_l1_(name)
	l111111ll11_l1_ = [0,15,17,19,26,34,50,53]
	l1lll111l111_l1_ = [0,15,17,19,26,34,50,53]
	l11llll1lll_l1_ = l1ll1ll11ll1_l1_ not in l1lll111l111_l1_
	l1l1ll1lll11_l1_ = l1ll1ll11ll1_l1_ in [23,28,71,72]
	l1lll1ll1111_l1_ = l1ll1ll11l1l_l1_ in [265,270]
	l1lllll1l111_l1_ = (l11llll1lll_l1_ or l1l1ll1lll11_l1_) and not l1lll1ll1111_l1_
	l11l1ll11l1_l1_ = l1ll11l1l1_l1_!=l1l111_l1_ (u"࠭ࡒࡆࡈࡕࡉࡘࡎࡅࡅࠩ㔮") and (l1ll11l1l1_l1_!=l1l111_l1_ (u"ࠧࠨ㔯") or context==l1l111_l1_ (u"ࠨࠩ㔰"))
	l1ll1ll1l1l1_l1_ = l1l111_l1_ (u"ࠩࡷࡽࡵ࡫࠽ࠨ㔱") in l1ll11l1l1_l1_
	l1ll11l111ll_l1_ = l1ll1ll11l1l_l1_ in [161,162,163,164,165,166,167,168,761,762,763,764,765]
	l1lll1_l1_ = l1ll1ll11l11_l1_==9 or l1ll1ll11l1l_l1_ in [145,516,523,45]
	l11lll11ll1_l1_ = not l1ll11l111ll_l1_
	l11l1l11111_l1_ = not l1lll1_l1_
	l1lll1lll1ll_l1_ = l1l111l1ll_l1_ in [l1l111_l1_ (u"ࠪࠫ㔲"),l1l111_l1_ (u"ࠫ࠳࠴ࠧ㔳")]
	l111l11lll1_l1_ = l1lll1lll1ll_l1_ or l11lll11ll1_l1_
	l111111llll_l1_ = l1lll1lll1ll_l1_ or l11l1l11111_l1_ or l1ll1ll1l1l1_l1_
	l1ll11111111_l1_ = l1ll1ll11l1l_l1_ not in [260,261,265,270,330,540]
	if l1l1ll1ll11l_l1_: l111l11l1ll_l1_ = l1lll1_l1_ or l1ll11l111ll_l1_
	else: l111l11l1ll_l1_ = True
	l1ll1ll1ll_l1_ = l1ll1ll11ll1_l1_ in [74,75]
	l11ll1llll1_l1_ = l1ll1ll11l1l_l1_ in [280,720]
	l111l1ll1l1_l1_ = not l1ll1ll1ll_l1_ and not l11ll1llll1_l1_
	l1l1ll1lllll_l1_ = l111l11lll1_l1_ and l111111llll_l1_ and l1ll11111111_l1_ and l111l11l1ll_l1_ and l111l1ll1l1_l1_
	l11l11ll1l1_l1_ = l1ll11111111_l1_ and l111l11l1ll_l1_ and l111l1ll1l1_l1_
	l11l1lllll1_l1_ = l11l11ll1l1_l1_
	l1l1111ll11_l1_ = settings.getSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯࡮ࡤࡲ࡬ࡻࡡࡨࡧ࠱ࡴࡷࡵࡶࡪࡦࡨࡶࠬ㔴"))
	l111ll1ll1l_l1_ = settings.getSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰࡯ࡥࡳ࡭ࡵࡢࡩࡨ࠲ࡨࡵࡤࡦࠩ㔵"))
	if 1 and l11l1ll11l1_l1_ and l1l1ll1lllll_l1_:
		l1lllll1111l_l1_ = l1lll11l111_l1_(main_dbfile,l1l111_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ㔶"),l1l111_l1_ (u"ࠨࡏࡈࡒ࡚࡙࡟ࡄࡃࡆࡌࡊࡥࠧ㔷")+l1l1111ll11_l1_+l1l111_l1_ (u"ࠩࡢࠫ㔸")+l111ll1ll1l_l1_,l1l1llllll1l_l1_)
		if l1lllll1111l_l1_:
			l11llllll1_l1_(l1l111_l1_ (u"ࠪࠫ㔹"),l1l111_l1_ (u"ࠫ࠳ࠦࠠࡎࡇࡑ࡙ࡘࡥࡃࡂࡅࡋࡉࡤ࠭㔺")+l1l1111ll11_l1_+l1l111_l1_ (u"ࠬࡥࠧ㔻")+l111ll1ll1l_l1_+l1l111_l1_ (u"࠭ࠠࠡࠢࡏࡳࡦࡪࡩ࡯ࡩࠣࡱࡪࡴࡵࠡࡨࡵࡳࡲࠦࡣࡢࡥ࡫ࡩࠬ㔼"))
			if 1 and l1ll1ll1l1l1_l1_:
				l11lll11111_l1_ = []
				from l1ll1111lll1_l1_ import l1llll1llll1_l1_
				from FAVORITES import GET_ALL_FAVORITES,GET_FAVORITES_CONTEXT_MENU
				l1lll1lll111_l1_ = l1llll1llll1_l1_
				l11ll1ll11l_l1_ = GET_ALL_FAVORITES()
				l1111l11lll_l1_ = l1ll11l1l1_l1_
				l11l11l1lll_l1_,l11l1l11l11_l1_,l1lll1ll111l_l1_,l1ll1l1lllll_l1_,l11ll1111l1_l1_,l1111111l11_l1_,l11l1l11l1l_l1_,l1lll11l111l_l1_,l1111111111_l1_ = EXTRACT_KODI_PATH(l1111l11lll_l1_)
				l1lll1lll1l1_l1_ = l11l11l1lll_l1_,l11l1l11l11_l1_,l1lll1ll111l_l1_,l1ll1l1lllll_l1_,l11ll1111l1_l1_,l1111111l11_l1_,l11l1l11l1l_l1_,l1l111_l1_ (u"ࠧࠨ㔽"),l1111111111_l1_
				for l1l1111ll1l_l1_ in l1lllll1111l_l1_:
					l1ll11llllll_l1_ = l1l1111ll1l_l1_[l1l111_l1_ (u"ࠨ࡯ࡨࡲࡺࡏࡴࡦ࡯ࠪ㔾")]
					if l1ll11llllll_l1_==l1lll1lll1l1_l1_ or l1l1111ll1l_l1_[l1l111_l1_ (u"ࠩࡰࡳࡩ࡫ࠧ㔿")] in [265,270]:
						l1l1111ll1l_l1_ = GET_LIST_ITEM(l1ll11llllll_l1_,l1lll1lll111_l1_,l11ll1ll11l_l1_)
						if l1l1111ll1l_l1_[l1l111_l1_ (u"ࠪࡪࡦࡼ࡯ࡳ࡫ࡷࡩࡸ࠭㕀")]:
							l1ll1l1l1ll1_l1_ = GET_FAVORITES_CONTEXT_MENU(l11ll1ll11l_l1_,l1ll11llllll_l1_,l1l1111ll1l_l1_[l1l111_l1_ (u"ࠫࡳ࡫ࡷࡱࡣࡷ࡬ࠬ㕁")])
							l1l1111ll1l_l1_[l1l111_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡼࡹࡥ࡭ࡦࡰࡸࠫ㕂")] = l1ll1l1l1ll1_l1_+l1l1111ll1l_l1_[l1l111_l1_ (u"࠭ࡣࡰࡰࡷࡩࡽࡺ࡟࡮ࡧࡱࡹࠬ㕃")]
					l11lll11111_l1_.append(l1l1111ll1l_l1_)
				settings.setSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡶࡪ࡬ࡲࡦࡵ࡫࠲ࡸࡺࡡࡵࡷࡶࠫ㕄"),l1l111_l1_ (u"ࠨࠩ㕅"))
				if type==l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㕆"): l1lll111111_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡑࡊࡔࡕࡔࡡࡆࡅࡈࡎࡅࡠࠩ㕇")+l1l1111ll11_l1_+l1l111_l1_ (u"ࠫࡤ࠭㕈")+l111ll1ll1l_l1_,l1l1llllll1l_l1_,l11lll11111_l1_,l11l1l1_l1_)
			else: l11lll11111_l1_ = l1lllll1111l_l1_
			if type==l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㕉") and l1l111l1ll_l1_!=l1l111_l1_ (u"࠭࠮࠯ࠩ㕊") and l1lllll1l111_l1_: l1l1l1lll11_l1_()
			l11l1l1lll1_l1_ = CREATE_KODI_MENU(l1l1llllll1l_l1_,l11lll11111_l1_,succeeded,l1111ll11l1_l1_,l11ll1l1l11_l1_)
			return
	elif type==l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㕋") and l1ll11l1l1_l1_==l1l111_l1_ (u"ࠨࡔࡈࡊࡗࡋࡓࡉࡇࡇࠫ㕌") and l11l11ll1l1_l1_:
		l1lll1l1lll_l1_(main_dbfile,l1l111_l1_ (u"ࠩࡐࡉࡓ࡛ࡓࡠࡅࡄࡇࡍࡋ࡟ࠨ㕍")+l1l1111ll11_l1_+l1l111_l1_ (u"ࠪࡣࠬ㕎")+l111ll1ll1l_l1_,l1l1llllll1l_l1_)
	if l1l111_l1_ (u"ࠫࡤ࠭㕏") in context: l1lll111ll11_l1_,l1ll11111l1l_l1_ = context.split(l1l111_l1_ (u"ࠬࡥࠧ㕐"),1)
	else: l1lll111ll11_l1_,l1ll11111l1l_l1_ = context,l1l111_l1_ (u"࠭ࠧ㕑")
	if l1lll111ll11_l1_ in [l1l111_l1_ (u"ࠧ࠲ࠩ㕒"),l1l111_l1_ (u"ࠨ࠴ࠪ㕓"),l1l111_l1_ (u"ࠩ࠶ࠫ㕔"),l1l111_l1_ (u"ࠪ࠸ࠬ㕕"),l1l111_l1_ (u"ࠫ࠺࠭㕖")] and l1ll11111l1l_l1_:
		from FAVORITES import FAVORITES_DISPATCHER
		FAVORITES_DISPATCHER(context)
		settings.setSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡴࡨࡪࡷ࡫ࡳࡩ࠰ࡶࡸࡦࡺࡵࡴࠩ㕗"),addon_path)
		xbmc.executebuiltin(l1l111_l1_ (u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪ㕘"))
		return
	elif l1lll111ll11_l1_==l1l111_l1_ (u"ࠧ࠷ࠩ㕙"):
		if l1ll11111l1l_l1_==l1l111_l1_ (u"ࠨࡆࡒ࡛ࡓࡒࡏࡂࡆࠪ㕚"): l1ll1lll_l1_(l1l111_l1_ (u"ࠩํีั๏ࠠศๆส๊ฯ฾วาࠩ㕛"),l1l111_l1_ (u"ࠪะฬื๊ࠡใะู๋ࠥไโࠢส่ฯำๅ๋ๆࠪ㕜"))
		elif l1ll11111l1l_l1_==l1l111_l1_ (u"ࠫࡉࡋࡌࡆࡖࡈࠫ㕝"): l1ll1ll11l1l_l1_ = 334
		l1lll_l1_ = l1ll1l1111l1_l1_(type,l1l11llll11_l1_,l1l1l1l11l1_l1_,l1ll1ll11l1l_l1_,l1l1ll1111l_l1_,l1l111l11ll_l1_,text,context,l1llllll111_l1_)
		xbmc.executebuiltin(l1l111_l1_ (u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠩ㕞"))
		return
	elif context==l1l111_l1_ (u"࠭࠷ࠨ㕟"):
		from l1111l1111_l1_ import l1lll1111ll_l1_
		l1lll1111ll_l1_()
		xbmc.executebuiltin(l1l111_l1_ (u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠫ㕠"))
		return
	elif context==l1l111_l1_ (u"ࠨ࠺ࠪ㕡"):
		xbmc.executebuiltin(l1l111_l1_ (u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳࡛ࡰࡥࡣࡷࡩ࠭ࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠨ㕢")+addon_id+l1l111_l1_ (u"ࠪࡃࡲࡵࡤࡦ࠿ࠪ㕣")+str(mode)+l1l111_l1_ (u"ࠫࠫࡺࡹࡱࡧࡀࡪࡴࡲࡤࡦࡴࠬࠫ㕤"))
		return
	elif context==l1l111_l1_ (u"ࠬ࠿ࠧ㕥"):
		settings.setSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡵࡩ࡫ࡸࡥࡴࡪ࠱ࡷࡹࡧࡴࡶࡵࠪ㕦"),l1l111_l1_ (u"ࠧࡓࡇࡔ࡙ࡊ࡙ࡔࡆࡆࠪ㕧"))
		xbmc.executebuiltin(l1l111_l1_ (u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬ࠬ㕨"))
		return
	if settings.getSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡩࡡࡤࡪࡨ࠲ࡸࡺࡡࡵࡷࡶࠫ㕩")) not in [l1l111_l1_ (u"ࠪࡅ࡚࡚ࡏࠨ㕪"),l1l111_l1_ (u"ࠫࡘ࡚ࡏࡑࠩ㕫"),l1l111_l1_ (u"ࠬࡒࡉࡎࡋࡗࡉࡉ࠭㕬")]: settings.setSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡦࡥࡨ࡮ࡥ࠯ࡵࡷࡥࡹࡻࡳࠨ㕭"),l1l111_l1_ (u"ࠧࡂࡗࡗࡓࠬ㕮"))
	if not settings.getSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡩࡴࡳ࠯ࡵࡨࡶࡻ࡫ࡲࠨ㕯")): settings.setSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡪ࡮ࡴ࠰ࡶࡩࡷࡼࡥࡳࠩ㕰"),l11111lllll_l1_[0])
	l1l1lll1l11l_l1_ = False if l1l11ll1lll_l1_(l1l111_l1_ (u"ࠪࡓ࡙࠷࠹ࡋࡗ࠳ࡼࡇ࡚ࡕ࡭ࡆ࡛ࠫ㕱")) else True
	l11lllll1ll_l1_ = l111l11l_l1_ if l1l1lll1l11l_l1_ else l11l1l1_l1_
	l11lll1l11l_l1_ = settings.getSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮࡮ࡧࡶࡷࡦ࡭ࡥࡴ࠰ࡶࡸࡦࡺࡵࡴࠩ㕲"))
	l1ll1111111l_l1_ = l1111111lll_l1_(settings.getSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯࡯ࡨࡷࡸࡧࡧࡦࡵ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠭㕳")))
	l1ll1111111l_l1_ = 0 if not l1ll1111111l_l1_ else int(l1ll1111111l_l1_)
	if l11lll1l11l_l1_ in [l1l111_l1_ (u"࠭ࠧ㕴"),l1l111_l1_ (u"ࠧࡆࡔࡕࡓࡗ࠭㕵")] or not l11lllll1ll_l1_ or not l1ll1111111l_l1_ or now-l1ll1111111l_l1_<0 or now-l1ll1111111l_l1_>l11lllll1ll_l1_:
		l11lll1l11l_l1_ = l11111l11l1_l1_(True,False)
	l11llll11ll_l1_ = l1111111lll_l1_(settings.getSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲࡮ࡴࡦࡰࡵ࠱ࡴࡪࡸࡩࡰࡦࠪ㕶")))
	l11llll11ll_l1_ = 0 if not l11llll11ll_l1_ else int(l11llll11ll_l1_)
	l11l1l1111l_l1_ = l1111111lll_l1_(settings.getSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡷࡵࡦࡵࡷ࡭ࡴࡴࡳ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮ࠫ㕷")))
	l11l1l1111l_l1_ = 0 if not l11l1l1111l_l1_ else int(l11l1l1111l_l1_)
	if not l11llll11ll_l1_ or not l11l1l1111l_l1_ or now-l11l1l1111l_l1_<0 or now-l11l1l1111l_l1_>l11llll11ll_l1_:
		l1ll1l1l11l1_l1_ = 1
		if l1l1lll1l11l_l1_:
			l1ll1l11111l_l1_ = l11lll1llll_l1_(True)
			if len(l1ll1l11111l_l1_)>1:
				l11llllll1_l1_(l1l111_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ㕸"),l1l111_l1_ (u"ࠫ࠳ࠦࠠࡔࡪࡲࡻ࡮ࡴࡧࠡࡓࡸࡩࡸࡺࡩࡰࡰࠣࠤࠥࡖࡡࡵࡪ࠽ࠤࡠࠦࠧ㕹")+addon_path+l1l111_l1_ (u"ࠬࠦ࡝ࠨ㕺"))
				id,l1l111llll1_l1_,l1l1llll1ll1_l1_,l11l111ll11_l1_,l11l1111l1l_l1_,reason = l1ll1l11111l_l1_[0]
				l1111l11l1l_l1_,l1111l11ll1_l1_ = l11l111ll11_l1_.split(l1l111_l1_ (u"࠭࡜࡯࠽࠾ࠫ㕻"))
				del l1ll1l11111l_l1_[0]
				l1ll1ll11lll_l1_ = random.sample(l1ll1l11111l_l1_,1)
				id,l1l111llll1_l1_,l1l1llll1ll1_l1_,l11l111ll11_l1_,l11l1111l1l_l1_,reason = l1ll1ll11lll_l1_[0]
				l1l1llll1ll1_l1_ = l1l111_l1_ (u"ࠧ࡜ࡔࡗࡐࡢࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠡ࠼ࠣࠫ㕼")+id+l1l111_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㕽")+l1l1llll1ll1_l1_
				l11l1111l1l_l1_ = l1l111_l1_ (u"ࠩศีุอไࠡำึห้ฯࠠฤ๊ࠣา฼ษࠧ㕾")
				l1llllll1l1l_l1_ = l1l111_l1_ (u"ࠪห้ะศา฻สฮࠬ㕿")
				l111l11l1l1_l1_,l1ll11l1ll1l_l1_ = l11l111ll11_l1_,l11l1111l1l_l1_
				l111llll_l1_ = [l111l11l1l1_l1_,l1ll11l1ll1l_l1_,l1llllll1l1l_l1_]
				l111llll111_l1_ = 5 if l1l11ll1lll_l1_(l1l111_l1_ (u"ࠫ࡜࡙ࡕࡓࡈࡗ࠵࠾ࡗࡔࡆࡈ࡝࡜ࠬ㖀")) else 5
				l111llll11l_l1_ = -9
				while l111llll11l_l1_<0:
					l11l1l1l111_l1_ = random.sample(l111llll_l1_,3)
					l111llll11l_l1_ = l1l1lll11111_l1_(l1l111_l1_ (u"ࠬ࠭㖁"),l11l1l1l111_l1_[0],l11l1l1l111_l1_[1],l11l1l1l111_l1_[2],l1111l11l1l_l1_,l1l1llll1ll1_l1_,l1l111_l1_ (u"࠭ࡣࡰࡰࡩ࡭ࡷࡳ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨ㖂"),l111llll111_l1_,60)
					if l111llll11l_l1_==10: break
					from l1l1l111l11_l1_ import l1ll1lll1l1l_l1_,l1l1l1l1l11_l1_
					if l111llll11l_l1_>=0 and l11l1l1l111_l1_[l111llll11l_l1_]==l111llll_l1_[1]:
						l1ll1lll1l1l_l1_()
						if l111llll11l_l1_>=0: l111llll11l_l1_ = -9
					elif l111llll11l_l1_>=0 and l11l1l1l111_l1_[l111llll11l_l1_]==l111llll_l1_[2]:
						l1l1l1l1l11_l1_(False)
					if l111llll11l_l1_==-1: l1111l1_l1_(l1l111_l1_ (u"ࠧࠨ㖃"),l1l111_l1_ (u"ࠨࠩ㖄"),l1l111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㖅"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢิั้ฮࠣา฼ษ࡛࠰ࡅࡒࡐࡔࡘ࡝࡝ࡰ่้ࠣิั้ฮࠣห้฻อ๋ฯࠣวำะั๊ࠡสัิࠦๅ็ࠢส่ศา่ษหࠣห้๋ส้ใิอࠬ㖆"))
				l1ll1l1l11l1_l1_ = 1
			else: l1ll1l1l11l1_l1_ = 0
		settings.setSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡲࡷࡨࡷࡹ࡯࡯࡯ࡵ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠭㖇"),l1ll1llll111_l1_(now))
		l1lll111111_l1_(main_dbfile,l1l111_l1_ (u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨ㖈"),l1l111_l1_ (u"࠭ࡁࡖࡖࡋࠫ㖉"),l1ll1l1l11l1_l1_,l1ll111l11l_l1_)
	l1lll_l1_ = l1ll1l1111l1_l1_(type,l1l11llll11_l1_,l1l1l1l11l1_l1_,mode,l1l1ll1111l_l1_,l1l111l11ll_l1_,text,context,l1llllll111_l1_)
	if l1l111_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ㖊") in text: l1111ll11l1_l1_ = True
	if type==l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㖋"):
		if l1l111l1ll_l1_!=l1l111_l1_ (u"ࠩ࠱࠲ࠬ㖌") and l1lllll1l111_l1_: l1l1l1lll11_l1_()
		if addon_handle>-1:
			if (l1lll11l111_l1_(main_dbfile,l1l111_l1_ (u"ࠪ࡭ࡳࡺࠧ㖍"),l1l111_l1_ (u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧ㖎"),l1l111_l1_ (u"ࠬࡇࡕࡕࡊࠪ㖏")) or l1ll1ll11l1l_l1_ not in l111111ll11_l1_) and not l1l11ll1lll_l1_(l1l111_l1_ (u"࠭ࡃࡕࡇ࠼ࡈࡘ࠷࠹ࡗࡗ࠳࡚ࡘ࡞ࠧ㖐")):
				from l1ll1111lll1_l1_ import l1llll1llll1_l1_
				l1lllll1111l_l1_ = GET_ALL_LIST_ITEMS(l1llll1llll1_l1_)
				l11l1l1lll1_l1_ = CREATE_KODI_MENU(l1l1llllll1l_l1_,l1lllll1111l_l1_,succeeded,l1111ll11l1_l1_,l11ll1l1l11_l1_)
				if 1 and l1lllll1111l_l1_ and l11l1lllll1_l1_:
					l1lll111111_l1_(main_dbfile,l1l111_l1_ (u"ࠧࡎࡇࡑ࡙ࡘࡥࡃࡂࡅࡋࡉࡤ࠭㖑")+l1l1111ll11_l1_+l1l111_l1_ (u"ࠨࡡࠪ㖒")+l111ll1ll1l_l1_,l1l1llllll1l_l1_,l1lllll1111l_l1_,l11l1l1_l1_)
			else:
				xbmcplugin.addDirectoryItem(addon_handle,l1l111_l1_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠬ㖓")+addon_id+l1l111_l1_ (u"ࠪ࠳ࡄࡺࡹࡱࡧࡀࡰ࡮ࡴ࡫ࠧ࡯ࡲࡨࡪࡃ࠵࠱࠲ࠪ㖔"),xbmcgui.ListItem(l1l111_l1_ (u"้ࠫี๊ไุ่่๊ࠢษࠡ็้ࠤัํวำๅࠪ㖕")))
				xbmcplugin.addDirectoryItem(addon_handle,l1l111_l1_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠨ㖖")+addon_id+l1l111_l1_ (u"࠭࠯ࡀࡶࡼࡴࡪࡃ࡬ࡪࡰ࡮ࠪࡲࡵࡤࡦ࠿࠸࠴࠵࠭㖗"),xbmcgui.ListItem(l1l111_l1_ (u"ࠧฤใอั๊ࠥสใำฦࠤฬ๊สโษุ๎้࠭㖘")))
			xbmcplugin.endOfDirectory(addon_handle,succeeded,l1111ll11l1_l1_,l11ll1l1l11_l1_)
	return
def l1ll1l1111l1_l1_(type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll111_l1_):
	l1ll1ll11l1l_l1_ = int(mode)
	l1ll1ll11ll1_l1_ = int(l1ll1ll11l1l_l1_//10)
	if   l1ll1ll11ll1_l1_==0:  from l1l1l111l11_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,text)
	elif l1ll1ll11ll1_l1_==1:  from l1111l11_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,url,text)
	elif l1ll1ll11ll1_l1_==2:  from l1ll1ll1ll1_l1_ 			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,url,l1llllll1_l1_,text)
	elif l1ll1ll11ll1_l1_==3:  from l11l11l1l11_l1_ 			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,url,l1llllll1_l1_,text)
	elif l1ll1ll11ll1_l1_==4:  from l1ll11lll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,url,text,l1llllll1_l1_)
	elif l1ll1ll11ll1_l1_==5:  from l11llll111l_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,url,text)
	elif l1ll1ll11ll1_l1_==6:  from l1lll1ll1_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,url,text)
	elif l1ll1ll11ll1_l1_==7:  from l11l111_l1_ 			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,url,text)
	elif l1ll1ll11ll1_l1_==8:  from l1ll1ll1lll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,url,text)
	elif l1ll1ll11ll1_l1_==9:  from l111111l1_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,url,text)
	elif l1ll1ll11ll1_l1_==10: from l1lll1ll1l1l_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,url)
	elif l1ll1ll11ll1_l1_==11: from l1ll11ll1l11_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,url,text)
	elif l1ll1ll11ll1_l1_==12: from l11l11l111_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,url,l1llllll1_l1_,text)
	elif l1ll1ll11ll1_l1_==13: from l1ll1l1l1_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,url,l1llllll1_l1_,text)
	elif l1ll1ll11ll1_l1_==14: from l11lll111ll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,url,text,type,l1llllll1_l1_,name,l11l_l1_)
	elif l1ll1ll11ll1_l1_==15: from l1l1l111l11_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,text)
	elif l1ll1ll11ll1_l1_==16: from l1ll11l111ll_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,url,text,l1llllll1_l1_,l1llllll111_l1_)
	elif l1ll1ll11ll1_l1_==17: from l1l1l111l11_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,text)
	elif l1ll1ll11ll1_l1_==18: from l1l1lll11l11_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,url,text)
	elif l1ll1ll11ll1_l1_==19: from l1l1l111l11_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,text)
	elif l1ll1ll11ll1_l1_==20: from l11llllll_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,url,text)
	elif l1ll1ll11ll1_l1_==21: from l111lll1lll_l1_	import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,url,text)
	elif l1ll1ll11ll1_l1_==22: from l111l11lll_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,url,l1llllll1_l1_,text)
	elif l1ll1ll11ll1_l1_==23: from IPTV 			import MAINn	; l1lll_l1_ = MAINn(l1ll1ll11l1l_l1_,url,text,type,l1llllll1_l1_,l1llllll111_l1_)
	elif l1ll1ll11ll1_l1_==24: from l1ll1l1l_l1_ 			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,url,text)
	elif l1ll1ll11ll1_l1_==25: from l1l11l111_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,url,text)
	elif l1ll1ll11ll1_l1_==26: from l1ll1111lll1_l1_ 			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,url,text)
	elif l1ll1ll11ll1_l1_==27: from FAVORITES 		import MAINn	; l1lll_l1_ = MAINn(l1ll1ll11l1l_l1_,context)
	elif l1ll1ll11ll1_l1_==28: from IPTV 			import MAINn	; l1lll_l1_ = MAINn(l1ll1ll11l1l_l1_,url,text,type,l1llllll1_l1_,l1llllll111_l1_)
	elif l1ll1ll11ll1_l1_==29: from l11ll11l11l_l1_	import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,url,l1llllll1_l1_,text)
	elif l1ll1ll11ll1_l1_==30: from l1lllllll1_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,url,text)
	elif l1ll1ll11ll1_l1_==31: from l11l11ll1ll_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,url,text)
	elif l1ll1ll11ll1_l1_==32: from l1ll11llll1_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,url,text)
	elif l1ll1ll11ll1_l1_==33: from l11lll111l_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,url)
	elif l1ll1ll11ll1_l1_==34: from l1l1l111l11_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,text)
	elif l1ll1ll11ll1_l1_==35: from l1l1111l_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,url,text)
	elif l1ll1ll11ll1_l1_==36: from l1lll11lll11_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,url,text)
	elif l1ll1ll11ll1_l1_==37: from l11l1ll1l_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,url,text)
	elif l1ll1ll11ll1_l1_==38: from l1ll1ll11111_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,url,text)
	elif l1ll1ll11ll1_l1_==39: from l1llll1ll1l_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,url,text)
	elif l1ll1ll11ll1_l1_==40: from l1l1l111l1_l1_	import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,url,text,type,l1llllll1_l1_)
	elif l1ll1ll11ll1_l1_==41: from l1l1l111l1_l1_	import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,url,text,type,l1llllll1_l1_)
	elif l1ll1ll11ll1_l1_==42: from l11l111ll_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,url,text)
	elif l1ll1ll11ll1_l1_==43: from l1111lllll_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,url,text)
	elif l1ll1ll11ll1_l1_==44: from l111l11111_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,url,text)
	elif l1ll1ll11ll1_l1_==45: from l1l11111111_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,url,text)
	elif l1ll1ll11ll1_l1_==46: from l111111lll1_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,url,text)
	elif l1ll1ll11ll1_l1_==47: from l11111111_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,url,text)
	elif l1ll1ll11ll1_l1_==48: from l1ll111l1l1l_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,url,text)
	elif l1ll1ll11ll1_l1_==49: from l11111l1l_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,url,text)
	elif l1ll1ll11ll1_l1_==50: from l1l1l111l11_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,text)
	elif l1ll1ll11ll1_l1_==51: from l11111llll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,url,text)
	elif l1ll1ll11ll1_l1_==52: from l11111llll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,url,text)
	elif l1ll1ll11ll1_l1_==53: from l1ll1111lll1_l1_ 			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,url,text)
	elif l1ll1ll11ll1_l1_==54: from l1111l1111_l1_	import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,url,text,l1llllll1_l1_)
	elif l1ll1ll11ll1_l1_==55: from l111l1l11_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,url,text)
	elif l1ll1ll11ll1_l1_==56: from l1ll11llll11_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,url,text)
	elif l1ll1ll11ll1_l1_==57: from l1llll1l11l_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,url,text)
	elif l1ll1ll11ll1_l1_==58: from l11ll1l1lll_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,url,text)
	elif l1ll1ll11ll1_l1_==59: from l1llll11l11_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,url,text)
	elif l1ll1ll11ll1_l1_==60: from l1llll111l1_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,url,text)
	elif l1ll1ll11ll1_l1_==61: from l1l1ll1_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,url,text)
	elif l1ll1ll11ll1_l1_==62: from l1lllll111l_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,url,text)
	elif l1ll1ll11ll1_l1_==63: from l11111ll1_l1_	import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,url,text)
	elif l1ll1ll11ll1_l1_==64: from l1111ll111l_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,url,text)
	elif l1ll1ll11ll1_l1_==65: from l11l11ll1_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,url,text)
	elif l1ll1ll11ll1_l1_==66: from l11lll1l111_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,url,text)
	elif l1ll1ll11ll1_l1_==67: from l1ll11ll1l1_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,url,text)
	elif l1ll1ll11ll1_l1_==68: from l11ll11l11_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,url,text)
	elif l1ll1ll11ll1_l1_==69: from l11l11l1l_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,url,text)
	elif l1ll1ll11ll1_l1_==70: from l1ll111l1ll_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,url,text)
	elif l1ll1ll11ll1_l1_==71: from M3U			import MAINn	; l1lll_l1_ = MAINn(l1ll1ll11l1l_l1_,url,text,type,l1llllll1_l1_,l1llllll111_l1_)
	elif l1ll1ll11ll1_l1_==72: from M3U			import MAINn	; l1lll_l1_ = MAINn(l1ll1ll11l1l_l1_,url,text,type,l1llllll1_l1_,l1llllll111_l1_)
	elif l1ll1ll11ll1_l1_==73: from l1ll1111l_l1_	import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,url,text)
	elif l1ll1ll11ll1_l1_==74: from l1ll1ll1ll_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_)
	elif l1ll1ll11ll1_l1_==75: from l1ll1ll1ll_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_)
	elif l1ll1ll11ll1_l1_==76: from l1ll11l111ll_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,url,text,l1llllll1_l1_,l1llllll111_l1_)
	elif l1ll1ll11ll1_l1_==77: from l111lll11l_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,url,l1llllll1_l1_,text)
	elif l1ll1ll11ll1_l1_==78: from l111ll111l_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,url,l1llllll1_l1_,text)
	elif l1ll1ll11ll1_l1_==79: from l111l1llll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,url,l1llllll1_l1_,text)
	elif l1ll1ll11ll1_l1_==80: from l111l1l1l1_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,url,l1llllll1_l1_,text)
	elif l1ll1ll11ll1_l1_==81: from l1ll11lll1l_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,url,text)
	elif l1ll1ll11ll1_l1_==82: from l1111ll11_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1ll11l1l_l1_,url,l1llllll1_l1_,text)
	else: l1lll_l1_ = None
	return l1lll_l1_
def l1l1111l11_l1_(name=l1l111_l1_ (u"ࠨࠩ㖙")):
	if not name: name = xbmc.getInfoLabel(l1l111_l1_ (u"ࠩࡏ࡭ࡸࡺࡉࡵࡧࡰ࠲ࡑࡧࡢࡦ࡮ࠪ㖚"))
	name = name.replace(l1l111_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㖛"),l1l111_l1_ (u"ࠫࠬ㖜"))
	name = name.replace(l1l111_l1_ (u"ࠬࠦࠠࠡࠢࠪ㖝"),l1l111_l1_ (u"࠭ࠠࠨ㖞")).replace(l1l111_l1_ (u"ࠧࠡࠢࠣࠫ㖟"),l1l111_l1_ (u"ࠨࠢࠪ㖠")).replace(l1l111_l1_ (u"ࠩࠣࠤࠬ㖡"),l1l111_l1_ (u"ࠪࠤࠬ㖢")).strip(l1l111_l1_ (u"ࠫࠥ࠭㖣"))
	name = name.replace(l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ㖤"),l1l111_l1_ (u"࠭ࠧ㖥")).replace(l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ㖦"),l1l111_l1_ (u"ࠨࠩ㖧"))
	tmp = re.findall(l1l111_l1_ (u"ࠩ࡟ࡨࡡࡪ࠺࡝ࡦ࡟ࡨࠥ࠭㖨"),name,re.DOTALL)
	if tmp: name = name.split(tmp[0],1)[1]
	if not name: name = l1l111_l1_ (u"ࠪࡑࡦ࡯࡮ࠡࡏࡨࡲࡺ࠭㖩")
	return name
def l1llll1lllll_l1_(code,reason,source,l11_l1_):
	l1llllllllll_l1_ = settings.getSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮࡭ࡣࡱ࡫ࡺࡧࡧࡦ࠰ࡷࡶࡦࡴࡳ࡭ࡣࡷࡩࠬ㖪"))
	settings.setSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯࡮ࡤࡲ࡬ࡻࡡࡨࡧ࠱ࡸࡷࡧ࡮ࡴ࡮ࡤࡸࡪ࠭㖫"),l1l111_l1_ (u"࠭ࠧ㖬"))
	if l1l111_l1_ (u"ࠧ࠮ࠩ㖭") in source: l1lll11l1l1_l1_ = source.split(l1l111_l1_ (u"ࠨ࠯ࠪ㖮"),1)[0]
	else: l1lll11l1l1_l1_ = source
	l11l1l1llll_l1_ = code in [7,11001,11002,10054]
	l1l1ll1llll1_l1_ = reason.lower()
	l1llll11llll_l1_ = code in [0,104,10061,111]
	l1llll11lll1_l1_ = l1l111_l1_ (u"ࠩࡥࡰࡴࡩ࡫ࡦࡦࠣࡦࡾࠦࡣ࡭ࡱࡸࡨ࡫ࡲࡡࡳࡧࠪ㖯") in l1l1ll1llll1_l1_
	l1llll11ll1l_l1_ = l1l111_l1_ (u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠤࡧࡿࠠ࠶ࠢࡶࡩࡨࡵ࡮ࡥࡵࠣࡦࡷࡵࡷࡴࡧࡵࠤࡨ࡮ࡥࡤ࡭ࠪ㖰") in l1l1ll1llll1_l1_
	l1llll11ll11_l1_ = l1l111_l1_ (u"ࠫࡧࡲ࡯ࡤ࡭ࡨࡨࠥࡨࡹࠡࡴࡨࡧࡦࡶࡴࡤࡪࡤࠫ㖱") in l1l1ll1llll1_l1_
	l1llll11l1ll_l1_ = l1l111_l1_ (u"ࠬࡨ࡬ࡰࡥ࡮ࡩࡩࠦࡢࡺࠢࡦࡰࡴࡻࡤࡧ࡮ࡤࡶࡪࠦࡳࡦࡥࡸࡶ࡮ࡺࡹࠡࡥ࡫ࡩࡨࡱࠧ㖲") in l1l1ll1llll1_l1_
	l1ll11l11lll_l1_ = settings.getSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡳࡶࡴࡾࡹ࠯ࡵࡷࡥࡹࡻࡳࠨ㖳"))
	l1ll111l11l1_l1_ = settings.getSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡨࡳࡹ࠮ࡴࡶࡤࡸࡺࡹࠧ㖴"))
	l11111l1l1l_l1_ = l1l111_l1_ (u"ࠨใื่ࠥ็๊ࠡีะฬࠥอไึใะอ๋ࠥๆࠡษ็ษ๋ะั็ฬࠪ㖵")
	l1111111l1l_l1_ = l1l111_l1_ (u"ࠩࡈࡶࡷࡵࡲࠡࠩ㖶")+str(code)+l1l111_l1_ (u"ࠪ࠾ࠥ࠭㖷")+reason
	l1111111l1l_l1_ = l111l11_l1_(l1111111l1l_l1_)
	if l1llll11llll_l1_ or l1llll11lll1_l1_ or l1llll11ll1l_l1_ or l1llll11ll11_l1_ or l1llll11l1ll_l1_:
		l11111l1l1l_l1_ += l1l111_l1_ (u"ࠫࠥ࠴ࠠศๆ่์็฿ࠠโ์๊ࠤาาศุࠡาࠤ่๎ฯู๋่ࠢิื็ࠡษ็ษ๋ะั็ฬࠣห้ิวึࠢห็ࠥษ่ࠡสส่๊๎โฺ࡞ࡱࠫ㖸")
	if l11l1l1llll_l1_: l11111l1l1l_l1_ += l1l111_l1_ (u"ࠬࠦ࠮ࠡๆา๎่ࠦฮุลࠣࡈࡓ้࡙ࠠ็฼๊ฬํࠠห฻ำีࠥะัอ็ฬࠤฬูๅࠡษ็้ํู่ࠡว็ํࠥืโๆ้࡟ࡲࠬ㖹")
	l1111111l1l_l1_ = l1l111_l1_ (u"࠭࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫ㖺")+l1111111l1l_l1_+l1l111_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㖻")
	if l1ll11l11lll_l1_==l1l111_l1_ (u"ࠨࡃࡖࡏࠬ㖼") or l1ll111l11l1_l1_==l1l111_l1_ (u"ࠩࡄࡗࡐ࠭㖽"):
		l11111l1l1l_l1_ += l1l111_l1_ (u"ࠪࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝่ๆࠣฮึ๐ฯࠡล้ࠤ๏ำว้ๆࠣห้ฮั็ษ่ะࠥหีๅษะࠤฬ๊ๅีๅ็อࠥ࠴࠮ࠡล่ࠤฯื๊ะࠢศีุอไࠡำึห้ฯࠠฤ๊ࠣา฼ษࠠฦๆ์ࠤฬ๊ๅษำ่ะࠥลࠡࠢ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㖾")
	l11lll1ll11_l1_ = False
	if l11_l1_ and source not in l1lllll1lll1_l1_:
		if l1ll11l11lll_l1_==l1l111_l1_ (u"ࠫࡆ࡙ࡋࠨ㖿") or l1ll111l11l1_l1_==l1l111_l1_ (u"ࠬࡇࡓࡌࠩ㗀"):
			l111llll11l_l1_ = l1l1lll11111_l1_(l1l111_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭㗁"),l1l111_l1_ (u"ࠧฯำ๋ะࠬ㗂"),l1l111_l1_ (u"ࠨวิืฬ๊ࠠาีส่ฮࠦร้ࠢั฻ศ࠭㗃"),l1l111_l1_ (u"ࠩศู้ออࠡษ็ู้้ไสࠩ㗄"),l1lll11l1l1_l1_+l1l111_l1_ (u"ࠪࠤࠥࠦࠧ㗅")+TRANSLATE(l1lll11l1l1_l1_),l11111l1l1l_l1_+l1l111_l1_ (u"ࠫࡡࡴࠧ㗆")+l1111111l1l_l1_)
			if l111llll11l_l1_==1:
				from l1l1l111l11_l1_ import l1ll1lll1l1l_l1_
				l1ll1lll1l1l_l1_()
			elif l111llll11l_l1_==2: l11lll1ll11_l1_ = True
		else: l1111l1_l1_(l1l111_l1_ (u"ࠬ࠭㗇"),l1l111_l1_ (u"࠭ࠧ㗈"),l1lll11l1l1_l1_+l1l111_l1_ (u"ࠧࠡࠢࠣࠫ㗉")+TRANSLATE(l1lll11l1l1_l1_),l11111l1l1l_l1_,l1111111l1l_l1_)
	settings.setSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡱࡧ࡮ࡨࡷࡤ࡫ࡪ࠴ࡴࡳࡣࡱࡷࡱࡧࡴࡦࠩ㗊"),l1llllllllll_l1_)
	return l11lll1ll11_l1_
def l11l1ll1ll1_l1_(l1ll1111l1ll_l1_=False):
	l11111ll1l1_l1_ = [l1l1l11l111_l1_,favoritesfile,l1l1ll1l1l11_l1_]
	for filename in os.listdir(addoncachefolder):
		if l1ll1111l1ll_l1_ and (filename.startswith(l1l111_l1_ (u"ࠩ࡬ࡴࡹࡼࠧ㗋")) or filename.startswith(l1l111_l1_ (u"ࠪࡱ࠸ࡻࠧ㗌"))): continue
		if filename.startswith(l1l111_l1_ (u"ࠫ࡫࡯࡬ࡦࡡࠪ㗍")): continue
		l1lllll111ll_l1_ = os.path.join(addoncachefolder,filename)
		if l1lllll111ll_l1_ in l11111ll1l1_l1_: continue
		try: os.remove(l1lllll111ll_l1_)
		except: pass
	time.sleep(1)
	return
def l1lll1l1l111_l1_(proxy,method,url,data,headers,allow_redirects,l11_l1_,source,l11ll1l111l_l1_=True,l1ll1lllllll_l1_=True):
	l1ll11ll1lll_l1_,l1lll1l1l1ll_l1_ = proxy.split(l1l111_l1_ (u"ࠬࡀࠧ㗎"))
	url = url+l1l111_l1_ (u"࠭ࡼࡽࡏࡼࡔࡷࡵࡸࡺࡗࡵࡰࡂ࠭㗏")+proxy
	response = l11l1l_l1_(l11ll11l_l1_,method,url,data,headers,allow_redirects,l11_l1_,source,l11ll1l111l_l1_,l1ll1lllllll_l1_)
	if url in response.content: response.succeeded = False
	if not response.succeeded:
		l111111l1l1_l1_(l1l111_l1_ (u"ࠧࡉࡖࡗࡔࠥࡘࡥࡲࡷࡨࡷࡹࠦࡆࡢ࡫࡯ࡹࡷ࡫ࠧ㗐"))
	return response
def l1ll1111llll_l1_(url):
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ㗑"),url,l1l111_l1_ (u"ࠩࠪ㗒"),l1l111_l1_ (u"ࠪࠫ㗓"),True,l1l111_l1_ (u"ࠫࠬ㗔"),l1l111_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡆࡖࡢࡔࡗࡕࡘࡊࡇࡖࡣࡑࡏࡓࡕ࠯࠴ࡷࡹ࠭㗕"),True,False)
	l111l11ll11_l1_ = []
	if response.succeeded:
		html = response.content
		l1ll1lll1ll1_l1_ = re.findall(l1l111_l1_ (u"࠭ࠠࠩ࠰࠭ࡃ࠮ࠦ࡜ࡥࡽ࠴࠰࠸ࢃ࡭ࡴࠩ㗖"),html)
		if l1ll1lll1ll1_l1_: html = l1l111_l1_ (u"ࠧ࡝ࡰࠪ㗗").join(l1ll1lll1ll1_l1_)
		proxies = html.replace(l1l111_l1_ (u"ࠨ࡞ࡵࠫ㗘"),l1l111_l1_ (u"ࠩࠪ㗙")).strip(l1l111_l1_ (u"ࠪࡠࡳ࠭㗚")).split(l1l111_l1_ (u"ࠫࡡࡴࠧ㗛"))
		l111l11ll11_l1_ = []
		for proxy in proxies:
			if proxy.count(l1l111_l1_ (u"ࠬ࠴ࠧ㗜"))==3: l111l11ll11_l1_.append(proxy)
	return l111l11ll11_l1_
def l11ll1l11ll_l1_(*args):
	l11llll1l11_l1_ = l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡲ࡬࠲ࡵࡸ࡯ࡹࡻࡶࡧࡷࡧࡰࡦ࠰ࡦࡳࡲ࠵ࡶ࠳࠱ࡂࡶࡪࡷࡵࡦࡵࡷࡁࡩ࡯ࡳࡱ࡮ࡤࡽࡵࡸ࡯ࡹ࡫ࡨࡷࠫࡶࡲࡰࡺࡼࡸࡾࡶࡥ࠾ࡪࡷࡸࡵࠬࡴࡪ࡯ࡨࡳࡺࡺ࠽࠲࠲࠳࠴࠵ࠬࡳࡴ࡮ࡀࡽࡪࡹࠦ࡭࡫ࡰ࡭ࡹࡃ࠱࠱ࠨࡦࡳࡺࡴࡴࡳࡻࡀࡒࡑ࠲ࡂࡆ࠮ࡇࡉ࠱ࡌࡒ࠭ࡉࡅ࠰࡙ࡘࠧ㗝")
	l1llll1l1l11_l1_ = l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡴࡤࡻ࠳࡭ࡩࡵࡪࡸࡦࡺࡹࡥࡳࡥࡲࡲࡹ࡫࡮ࡵ࠰ࡦࡳࡲ࠵ࡲࡰࡱࡶࡸࡪࡸ࡫ࡪࡦ࠲ࡳࡵ࡫࡮ࡱࡴࡲࡼࡾࡲࡩࡴࡶ࠲ࡱࡦ࡯࡮࠰ࡊࡗࡘࡕ࡙࠮ࡵࡺࡷࠫ㗞")
	l111l11ll1l_l1_ = l1ll1111llll_l1_(l1llll1l1l11_l1_)
	l111l11ll11_l1_ = l1ll1111llll_l1_(l11llll1l11_l1_)
	l1l1111111l_l1_ = l111l11ll1l_l1_+l111l11ll11_l1_
	l11llllll1_l1_(l1l111_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࡠࡎࡌࡒࡊ࡙ࠧ㗟"),l11llll11l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠩࠣࠤࠥࡍ࡯ࡵࠢࡳࡶࡴࡾࡩࡦࡵࠣࡰ࡮ࡹࡴࠡࠢࠣ࠵ࡸࡺࠫ࠳ࡰࡧ࠾ࠥࡡࠠࠨ㗠")+str(len(l111l11ll1l_l1_))+l1l111_l1_ (u"ࠪ࠯ࠬ㗡")+str(len(l111l11ll11_l1_))+l1l111_l1_ (u"ࠫࠥࡣࠧ㗢"))
	proxy = settings.getSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡲࡵࡳࡽࡿ࠮࡭ࡣࡶࡸࠬ㗣"))
	response = l1l1lllll11_l1_()
	settings.setSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡳࡶࡴࡾࡹ࠯࡮ࡤࡷࡹ࠭㗤"),l1l111_l1_ (u"ࠧࠨ㗥"))
	if proxy or l1l1111111l_l1_:
		id,l1l111l111l_l1_ = 0,10
		l111l1llll1_l1_ = len(l1l1111111l_l1_)
		l111lll11ll_l1_ = l1l111l111l_l1_
		if l111l1llll1_l1_>l111lll11ll_l1_: counts = l111lll11ll_l1_
		else: counts = l111l1llll1_l1_
		l11l1l11lll_l1_ = random.sample(l1l1111111l_l1_,counts)
		if proxy: l11l1l11lll_l1_ = [proxy]+l11l1l11lll_l1_
		threads = l11l11l1111_l1_(False,False)
		t1 = time.time()
		while time.time()-t1<=l1l111l111l_l1_ and not threads.l11l1l111ll_l1_:
			if id<counts:
				proxy = l11l1l11lll_l1_[id]
				threads.start_new_thread(id,l1lll1l1l111_l1_,proxy,*args)
			time.sleep(1)
			id += 1
			l11llllll1_l1_(l1l111_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ㗦"),l11llll11l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠩࠣࠤ࡚ࠥࡲࡺ࡫ࡱ࡫࠿ࠦࠠࠡࡒࡵࡳࡽࡿ࠺ࠡ࡝ࠣࠫ㗧")+proxy+l1l111_l1_ (u"ࠪࠤࡢ࠭㗨"))
		l11l1l111ll_l1_ = threads.l11l1l111ll_l1_
		if l11l1l111ll_l1_:
			l1lllll11l11_l1_ = threads.l1lllll11l11_l1_
			l11111111ll_l1_ = l11l1l111ll_l1_[0]
			response = l1lllll11l11_l1_[l11111111ll_l1_]
			proxy = l11l1l11lll_l1_[int(l11111111ll_l1_)]
			settings.setSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡱࡴࡲࡼࡾ࠴࡬ࡢࡵࡷࠫ㗩"),proxy)
			if l11111111ll_l1_!=0: l11llllll1_l1_(l1l111_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࡤࡒࡉࡏࡇࡖࠫ㗪"),l11llll11l_l1_(l1ll1_l1_)+l1l111_l1_ (u"࠭ࠠࠡࠢࡖࡹࡨࡩࡥࡴࡵ࠽ࠤࠥࠦࡐࡳࡱࡻࡽ࠿࡛ࠦࠡࠩ㗫")+proxy+l1l111_l1_ (u"ࠧࠡ࡟ࠪ㗬"))
			else: l11llllll1_l1_(l1l111_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࡠࡎࡌࡒࡊ࡙ࠧ㗭"),l11llll11l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠩࠣࠤ࡙ࠥࡵࡤࡥࡨࡷࡸࡀࠠࠡࠢࡖࡥࡻ࡫ࡤࠡࡲࡵࡳࡽࡿ࠺ࠡ࡝ࠣࠫ㗮")+proxy+l1l111_l1_ (u"ࠪࠤࡢ࠭㗯"))
	return response
def l1l1lllll11l_l1_(connection,l1l1lll1l111_l1_):
	l11l111l111_l1_ = connection.create_connection
	def l1ll1l111ll1_l1_(address,*args,**kwargs):
		host,port = address
		l1ll1ll1l1ll_l1_ = DNS_RESOLVER(host,l1l1lll1l111_l1_)
		if l1ll1ll1l1ll_l1_: host = l1ll1ll1l1ll_l1_[0]
		else:
			if l1l1lll1l111_l1_ in l11111lllll_l1_: l11111lllll_l1_.remove(l1l1lll1l111_l1_)
			if l11111lllll_l1_:
				l111ll1l111_l1_ = l11111lllll_l1_[0]
				l1ll1ll1l1ll_l1_ = DNS_RESOLVER(host,l111ll1l111_l1_)
				if l1ll1ll1l1ll_l1_: host = l1ll1ll1l1ll_l1_[0]
		address = (host,port)
		return l11l111l111_l1_(address,*args,**kwargs)
	connection.create_connection = l1ll1l111ll1_l1_
	return l11l111l111_l1_
def l1l1lll111l1_l1_(url):
	l11l1ll11ll_l1_,l1111llllll_l1_ = url.split(l1l111_l1_ (u"ࠫ࠴࠭㗰"))[2],80
	if l1l111_l1_ (u"ࠬࡀࠧ㗱") in l11l1ll11ll_l1_: l11l1ll11ll_l1_,l1111llllll_l1_ = l11l1ll11ll_l1_.split(l1l111_l1_ (u"࠭࠺ࠨ㗲"))
	l11l1111111_l1_ = l1l111_l1_ (u"ࠧ࠰ࠩ㗳")+l1l111_l1_ (u"ࠨ࠱ࠪ㗴").join(url.split(l1l111_l1_ (u"ࠩ࠲ࠫ㗵"))[3:])
	request = l1l111_l1_ (u"ࠪࡋࡊ࡚ࠠࠨ㗶")+l11l1111111_l1_+l1l111_l1_ (u"ࠫࠥࡎࡔࡕࡒ࠲࠵࠳࠷࡜ࡳ࡞ࡱࠫ㗷")
	request += l1l111_l1_ (u"ࠬࡎ࡯ࡴࡶ࠽ࠤࠬ㗸")+l11l1ll11ll_l1_+l1l111_l1_ (u"࠭࡜ࡳ࡞ࡱࠫ㗹")
	request += l1l111_l1_ (u"ࠧ࡝ࡴ࡟ࡲࠬ㗺")
	from socket import socket,AF_INET,SOCK_STREAM
	try:
		client = socket(AF_INET,SOCK_STREAM)
		client.connect((l11l1ll11ll_l1_,l1111llllll_l1_))
		client.send(request.encode())
		http_response = client.recv(4096*1024)
		html = repr(http_response)
	except: html = l1l111_l1_ (u"ࠨࠩ㗻")
	return html
def l1l111l_l1_(l1ll1ll_l1_,type):
	if l1l111_l1_ (u"ࠩ࠱ࠫ㗼") not in l1ll1ll_l1_: return l1ll1ll_l1_
	l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠪ࠳ࠬ㗽")
	l1ll1l1l1111_l1_,l1ll1l11llll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠫ࠳࠭㗾"),1)
	l1ll1l11lll1_l1_,l1ll1l11ll1l_l1_ = l1ll1l11llll_l1_.split(l1l111_l1_ (u"ࠬ࠵ࠧ㗿"),1)
	server = l1ll1l1l1111_l1_+l1l111_l1_ (u"࠭࠮ࠨ㘀")+l1ll1l11lll1_l1_
	if type in [l1l111_l1_ (u"ࠧࡩࡱࡶࡸࠬ㘁"),l1l111_l1_ (u"ࠨࡰࡤࡱࡪ࠭㘂")] and l1l111_l1_ (u"ࠩ࠲ࠫ㘃") in server: server = server.rsplit(l1l111_l1_ (u"ࠪ࠳ࠬ㘄"),1)[1]
	if type==l1l111_l1_ (u"ࠫࡳࡧ࡭ࡦࠩ㘅") and l1l111_l1_ (u"ࠬ࠴ࠧ㘆") in server:
		l1lll1111ll1_l1_ = server.split(l1l111_l1_ (u"࠭࠮ࠨ㘇"))
		l1l1l1l1111_l1_ = len(l1lll1111ll1_l1_)
		if l1l1l1l1111_l1_<=2 or l1l111_l1_ (u"ࠧࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲࠬ㘈") in server: l1lll1111ll1_l1_ = l1lll1111ll1_l1_[0]
		elif l1l1l1l1111_l1_>=3: l1lll1111ll1_l1_ = l1lll1111ll1_l1_[1]
		if len(l1lll1111ll1_l1_)>1: server = l1lll1111ll1_l1_
	return server
def l111l1lllll_l1_(l11l11l11l1_l1_):
	l11l11l11ll_l1_ = repr(l11l11l11l1_l1_.encode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭㘉"))).replace(l1l111_l1_ (u"ࠤࠪࠦ㘊"),l1l111_l1_ (u"ࠪࠫ㘋"))
	return l11l11l11ll_l1_
def l1ll11l1111_l1_(string):
	l1l1lllll1ll_l1_ = l1l111_l1_ (u"ࠫࠬ㘌")
	if PY2: string = string.decode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㘍"))
	from unicodedata import decomposition
	for l1llllll11l1_l1_ in string:
		if   l1llllll11l1_l1_==l1l111_l1_ (u"ࡻࠧรࠩ㘎"): l111111ll1l_l1_ = l1l111_l1_ (u"ࠧ࡝࡞ࡸ࠴࠻࠸࠲ࠨ㘏")
		elif l1llllll11l1_l1_==l1l111_l1_ (u"ࡶࠩฦࠫ㘐"): l111111ll1l_l1_ = l1l111_l1_ (u"ࠩ࡟ࡠࡺ࠶࠶࠳࠵ࠪ㘑")
		elif l1llllll11l1_l1_==l1l111_l1_ (u"ࡸࠫษ࠭㘒"): l111111ll1l_l1_ = l1l111_l1_ (u"ࠫࡡࡢࡵ࠱࠸࠵࠸ࠬ㘓")
		elif l1llllll11l1_l1_==l1l111_l1_ (u"ࡺ࠭ลࠨ㘔"): l111111ll1l_l1_ = l1l111_l1_ (u"࠭࡜࡝ࡷ࠳࠺࠷࠻ࠧ㘕")
		elif l1llllll11l1_l1_==l1l111_l1_ (u"ࡵࠨศࠪ㘖"): l111111ll1l_l1_ = l1l111_l1_ (u"ࠨ࡞࡟ࡹ࠵࠼࠲࠷ࠩ㘗")
		else:
			l1l1ll11ll1l_l1_ = decomposition(l1llllll11l1_l1_)
			if l1l111_l1_ (u"ࠩࠣࠫ㘘") in l1l1ll11ll1l_l1_: l111111ll1l_l1_ = l1l111_l1_ (u"ࠪࡠࡡࡻࠧ㘙")+l1l1ll11ll1l_l1_.split(l1l111_l1_ (u"ࠫࠥ࠭㘚"),1)[1]
			else:
				l111111ll1l_l1_ = l1l111_l1_ (u"ࠬ࠶࠰࠱࠲ࠪ㘛")+hex(ord(l1llllll11l1_l1_)).replace(l1l111_l1_ (u"࠭࠰ࡹࠩ㘜"),l1l111_l1_ (u"ࠧࠨ㘝"))
				l111111ll1l_l1_ = l1l111_l1_ (u"ࠨ࡞࡟ࡹࠬ㘞")+l111111ll1l_l1_[-4:]
		l1l1lllll1ll_l1_ += l111111ll1l_l1_
	l1l1lllll1ll_l1_ = l1l1lllll1ll_l1_.replace(l1l111_l1_ (u"ࠩ࡟ࡠࡺ࠶࠶ࡄࡅࠪ㘟"),l1l111_l1_ (u"ࠪࡠࡡࡻ࠰࠷࠶࠼ࠫ㘠"))
	if PY2: l1l1lllll1ll_l1_ = l1l1lllll1ll_l1_.decode(l1l111_l1_ (u"ࠫࡺࡴࡩࡤࡱࡧࡩࡤ࡫ࡳࡤࡣࡳࡩࠬ㘡")).encode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㘢"))
	else: l1l1lllll1ll_l1_ = l1l1lllll1ll_l1_.encode(l1l111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ㘣")).decode(l1l111_l1_ (u"ࠧࡶࡰ࡬ࡧࡴࡪࡥࡠࡧࡶࡧࡦࡶࡥࠨ㘤"))
	return l1l1lllll1ll_l1_
def l1llll1_l1_(header=l1l111_l1_ (u"ࠨๆ๋ัฮࠦวๅ็ไหฯ๐อࠨ㘥"),default=l1l111_l1_ (u"ࠩࠪ㘦"),l111lll111l_l1_=False,source=l1l111_l1_ (u"ࠪࠫ㘧")):
	text = l1ll1lll1111_l1_(header,default,type=xbmcgui.INPUT_ALPHANUM)
	text = text.replace(l1l111_l1_ (u"ࠫࠥࠦࠧ㘨"),l1l111_l1_ (u"ࠬࠦࠧ㘩")).replace(l1l111_l1_ (u"࠭ࠠࠡࠩ㘪"),l1l111_l1_ (u"ࠧࠡࠩ㘫")).replace(l1l111_l1_ (u"ࠨࠢࠣࠫ㘬"),l1l111_l1_ (u"ࠩࠣࠫ㘭"))
	if not text and not l111lll111l_l1_:
		l11llllll1_l1_(l1l111_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ㘮"),l1l111_l1_ (u"ࠫ࠳ࠦࠠࡌࡧࡼࡦࡴࡧࡲࡥࠢࡨࡲࡹࡸࡹࠡࡥࡤࡲࡨ࡫࡬ࡦࡦ࠽ࠤࠥࠦࠢࠨ㘯")+text+l1l111_l1_ (u"ࠬࠨࠧ㘰"))
		l1111l1_l1_(l1l111_l1_ (u"࠭ࠧ㘱"),l1l111_l1_ (u"ࠧࠨ㘲"),l1l111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ㘳"),l1l111_l1_ (u"ࠩอ้ࠥหไ฻ษฤࠤฬ๊ละะส่ࠬ㘴"))
		return l1l111_l1_ (u"ࠪࠫ㘵")
	if text not in [l1l111_l1_ (u"ࠫࠬ㘶"),l1l111_l1_ (u"ࠬࠦࠧ㘷")]:
		text = text.strip(l1l111_l1_ (u"࠭ࠠࠨ㘸"))
		text = l1ll11l1111_l1_(text)
	if source!=l1l111_l1_ (u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔࠩ㘹") and l11111l_l1_(l1l111_l1_ (u"ࠨࡍࡈ࡝ࡇࡕࡁࡓࡆࠪ㘺"),l1l111_l1_ (u"ࠩࠪ㘻"),[text],False):
		l11llllll1_l1_(l1l111_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ㘼"),l1l111_l1_ (u"ࠫ࠳ࠦࠠࡌࡧࡼࡦࡴࡧࡲࡥࠢࡨࡲࡹࡸࡹࠡࡤ࡯ࡳࡨࡱࡥࡥ࠼ࠣࠤࠥࠨࠧ㘽")+text+l1l111_l1_ (u"ࠬࠨࠧ㘾"))
		l1111l1_l1_(l1l111_l1_ (u"࠭ࠧ㘿"),l1l111_l1_ (u"ࠧࠨ㙀"),l1l111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ㙁"),l1l111_l1_ (u"ࠩส๊ฯࠦใหสอࠤ่๊ๅสࠢฦ์ࠥืโๆࠢ็๋ࠥ฿ไศไฬࠤอษแๅษ่ࠤ้๊ใษษิࠤๆ่ืࠡ࠰࠱ࠤํํะศࠢส่อืๆศ็ฯࠤ้อ๋ࠠี่ัࠥฮวิฬัำฬ๋่ࠠๅำห้ࠥไๆษอࠫ㙂"))
		return l1l111_l1_ (u"ࠪࠫ㙃")
	l11llllll1_l1_(l1l111_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ㙄"),l1l111_l1_ (u"ࠬ࠴ࠠࠡࡍࡨࡽࡧࡵࡡࡳࡦࠣࡩࡳࡺࡲࡺࠢࡤࡰࡱࡵࡷࡦࡦ࠽ࠤࠥࠦࠢࠨ㙅")+text+l1l111_l1_ (u"࠭ࠢࠨ㙆"))
	return text
def l1l11l11ll_l1_(l1lllll1_l1_,headers={}):
	url,params = l1lllll1_l1_,l1l111_l1_ (u"ࠧࠨ㙇")
	if l1l111_l1_ (u"ࠨࡾࠪ㙈") in l1lllll1_l1_:
		url,params = l1lllll1_l1_.split(l1l111_l1_ (u"ࠩࡿࠫ㙉"),1)
		if l1l111_l1_ (u"ࠪࡁࠬ㙊") not in params: url,params = l1lllll1_l1_,l1l111_l1_ (u"ࠫࠬ㙋")
	response = l11l1l_l1_(l1lll11l1l1l_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ㙌"),url,l1l111_l1_ (u"࠭ࠧ㙍"),headers,l1l111_l1_ (u"ࠧࠨ㙎"),l1l111_l1_ (u"ࠨࠩ㙏"),l1l111_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡉ࡝࡚ࡒࡂࡅࡗࡣࡒ࠹ࡕ࠹࠯࠴ࡷࡹ࠭㙐"),False,False)
	html = response.content
	if l1l111_l1_ (u"ࠪࡗ࡙ࡘࡅࡂࡏ࠰ࡍࡓࡌࠧ㙑") not in html: return [l1l111_l1_ (u"ࠫ࠲࠷ࠧ㙒")],[l1lllll1_l1_]
	if l1l111_l1_ (u"࡚࡙ࠬࡑࡇࡀࡅ࡚ࡊࡉࡐࠩ㙓") in html: return [l1l111_l1_ (u"࠭࠭࠲ࠩ㙔")],[l1lllll1_l1_]
	if l1l111_l1_ (u"ࠧࡕ࡛ࡓࡉࡂ࡜ࡉࡅࡇࡒࠫ㙕") in html: return [l1l111_l1_ (u"ࠨ࠯࠴ࠫ㙖")],[l1lllll1_l1_]
	l1l1lll1_l1_,l1llll_l1_,l111l1l1ll1_l1_,l1lll1111l11_l1_ = [],[],[],[]
	lines = re.findall(l1l111_l1_ (u"ࠩࠦࡉ࡝࡚࡙࠭࠯ࡖࡘࡗࡋࡁࡎ࠯ࡌࡒࡋࡀࠨ࠯ࠬࡂ࠭ࡠࡢࡲ࡝ࡰࡠ࠯࠭࠴ࠪࡀࠫ࡞ࡠࡷࡢ࡮࡞࠭ࠪ㙗"),html+l1l111_l1_ (u"ࠪࡠࡳ࠭㙘"),re.DOTALL)
	if not lines: return [l1l111_l1_ (u"ࠫ࠲࠷ࠧ㙙")],[l1lllll1_l1_]
	for line,l1ll1ll_l1_ in lines:
		l1l1llll11ll_l1_,l11ll11l1ll_l1_,l111l1ll_l1_ = {},-1,-1
		title = l1l111_l1_ (u"ࠬ࠭㙚")
		items = line.split(l1l111_l1_ (u"࠭ࠬࠨ㙛"))
		for item in items:
			if l1l111_l1_ (u"ࠧ࠾ࠩ㙜") in item:
				key,value = item.split(l1l111_l1_ (u"ࠨ࠿ࠪ㙝"),1)
				l1l1llll11ll_l1_[key.lower()] = value
		if l1l111_l1_ (u"ࠩࡤࡺࡪࡸࡡࡨࡧ࠰ࡦࡦࡴࡤࡸ࡫ࡧࡸ࡭࠭㙞") in line.lower():
			l11ll11l1ll_l1_ = int(l1l1llll11ll_l1_[l1l111_l1_ (u"ࠪࡥࡻ࡫ࡲࡢࡩࡨ࠱ࡧࡧ࡮ࡥࡹ࡬ࡨࡹ࡮ࠧ㙟")])//1024
			title += str(l11ll11l1ll_l1_)+l1l111_l1_ (u"ࠫࡰࡨࡰࡴࠢࠣࠫ㙠")
		elif l1l111_l1_ (u"ࠬࡨࡡ࡯ࡦࡺ࡭ࡩࡺࡨࠨ㙡") in line.lower():
			l11ll11l1ll_l1_ = int(l1l1llll11ll_l1_[l1l111_l1_ (u"࠭ࡢࡢࡰࡧࡻ࡮ࡪࡴࡩࠩ㙢")])//1024
			title += str(l11ll11l1ll_l1_)+l1l111_l1_ (u"ࠧ࡬ࡤࡳࡷࠥࠦࠧ㙣")
		if l1l111_l1_ (u"ࠨࡴࡨࡷࡴࡲࡵࡵ࡫ࡲࡲࠬ㙤") in line.lower():
			l111l1ll_l1_ = int(l1l1llll11ll_l1_[l1l111_l1_ (u"ࠩࡵࡩࡸࡵ࡬ࡶࡶ࡬ࡳࡳ࠭㙥")].split(l1l111_l1_ (u"ࠪࡼࠬ㙦"))[1])
			title += str(l111l1ll_l1_)+l1l111_l1_ (u"ࠫࠥࠦࠧ㙧")
		title = title.strip(l1l111_l1_ (u"ࠬࠦࠠࠨ㙨"))
		if not title: title = l1l111_l1_ (u"࠭ࡕ࡯࡭ࡱࡳࡼࡴࠧ㙩")
		if not l1ll1ll_l1_.startswith(l1l111_l1_ (u"ࠧࡩࡶࡷࡴࠬ㙪")):
			if l1ll1ll_l1_.startswith(l1l111_l1_ (u"ࠨ࠱࠲ࠫ㙫")): l1ll1ll_l1_ = url.split(l1l111_l1_ (u"ࠩ࠽ࠫ㙬"),1)[0]+l1l111_l1_ (u"ࠪ࠾ࠬ㙭")+l1ll1ll_l1_
			elif l1ll1ll_l1_.startswith(l1l111_l1_ (u"ࠫ࠴࠭㙮")): l1ll1ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩ㙯"))+l1ll1ll_l1_
			else: l1ll1ll_l1_ = url.rsplit(l1l111_l1_ (u"࠭࠯ࠨ㙰"),1)[0]+l1l111_l1_ (u"ࠧ࠰ࠩ㙱")+l1ll1ll_l1_
		if params!=l1l111_l1_ (u"ࠨࠩ㙲"): l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠩࡿࠫ㙳")+params
		if l1l111_l1_ (u"ࠪࡴࡷࡵࡧࡳࡧࡶࡷ࡮ࡼࡥ࠮ࡷࡵ࡭ࠬ㙴") in list(l1l1llll11ll_l1_.keys()):
			l111lllll_l1_ = l1l1llll11ll_l1_[l1l111_l1_ (u"ࠫࡵࡸ࡯ࡨࡴࡨࡷࡸ࡯ࡶࡦ࠯ࡸࡶ࡮࠭㙵")]
			l111lllll_l1_ = l111lllll_l1_.replace(l1l111_l1_ (u"ࠬࠨࠧ㙶"),l1l111_l1_ (u"࠭ࠧ㙷")).replace(l1l111_l1_ (u"ࠢࠨࠤ㙸"),l1l111_l1_ (u"ࠨࠩ㙹")).split(l1l111_l1_ (u"ࠩࠦࠫ㙺"),1)[0]
			l11ll11ll1_l1_ = l1l111l1l1_l1_(l111lllll_l1_)
			if l11ll11ll1_l1_: l1lllllll_l1_ = title+l1l111_l1_ (u"ࠪࠤࠥ࠭㙻")+l11ll11ll1_l1_
			else: l1lllllll_l1_ = title
			l1lllllll_l1_ = l1lllllll_l1_+l1l111_l1_ (u"ࠫࠥࠦࡐࡳࡱࡪࡶࡪࡹࡳࡪࡸࡨࠫ㙼")
			l1lllllll_l1_ = l1lllllll_l1_+l1l111_l1_ (u"ࠬࠦࠠࠨ㙽")+l1l111l_l1_(l111lllll_l1_,l1l111_l1_ (u"࠭࡮ࡢ࡯ࡨࠫ㙾"))
			l1l1lll1_l1_.append(l1lllllll_l1_)
			l1llll_l1_.append(l111lllll_l1_)
			l111l1l1ll1_l1_.append(l111l1ll_l1_)
			l1lll1111l11_l1_.append(l11ll11l1ll_l1_)
		l1ll1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠧࠤࠩ㙿"),1)[0]
		l11ll11ll1_l1_ = l1l111l1l1_l1_(l1ll1ll_l1_)
		if l11ll11ll1_l1_: title = title+l1l111_l1_ (u"ࠨࠢࠣࠫ㚀")+l11ll11ll1_l1_
		title = title+l1l111_l1_ (u"ࠩࠣࠤࠬ㚁")+l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠪࡲࡦࡳࡥࠨ㚂"))
		l1l1lll1_l1_.append(title)
		l1llll_l1_.append(l1ll1ll_l1_)
		l111l1l1ll1_l1_.append(l111l1ll_l1_)
		l1lll1111l11_l1_.append(l11ll11l1ll_l1_)
	zz = list(zip(l1l1lll1_l1_,l1llll_l1_,l111l1l1ll1_l1_,l1lll1111l11_l1_))
	zz = sorted(zz, reverse=True, key=lambda key: key[3])
	l1l1lll1_l1_,l1llll_l1_,l111l1l1ll1_l1_,l1lll1111l11_l1_ = list(zip(*zz))
	l1l1lll1_l1_,l1llll_l1_ = list(l1l1lll1_l1_),list(l1llll_l1_)
	return l1l1lll1_l1_,l1llll_l1_
def DNS_RESOLVER(host,l1l1lll1l111_l1_=l1l111_l1_ (u"ࠫࠬ㚃")):
	if not l1l1lll1l111_l1_: l1l1lll1l111_l1_ = l11111lllll_l1_[0]
	if host.replace(l1l111_l1_ (u"ࠬ࠴ࠧ㚄"),l1l111_l1_ (u"࠭ࠧ㚅")).isdigit(): return [host]
	from struct import pack,unpack_from
	from socket import socket,AF_INET,SOCK_DGRAM
	try:
		l11111ll111_l1_ = pack(l1l111_l1_ (u"ࠢ࠿ࡊࠥ㚆"), 12049)
		l11111ll111_l1_ += pack(l1l111_l1_ (u"ࠣࡀࡋࠦ㚇"), 256)
		l11111ll111_l1_ += pack(l1l111_l1_ (u"ࠤࡁࡌࠧ㚈"), 1)
		l11111ll111_l1_ += pack(l1l111_l1_ (u"ࠥࡂࡍࠨ㚉"), 0)
		l11111ll111_l1_ += pack(l1l111_l1_ (u"ࠦࡃࡎࠢ㚊"), 0)
		l11111ll111_l1_ += pack(l1l111_l1_ (u"ࠧࡄࡈࠣ㚋"), 0)
		if PY3: l1llll1lll1l_l1_ = host.split(l1l111_l1_ (u"࠭࠮ࠨ㚌"))
		else: l1llll1lll1l_l1_ = host.decode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㚍")).split(l1l111_l1_ (u"ࠨ࠰ࠪ㚎"))
		for part in l1llll1lll1l_l1_:
			parts = part.encode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㚏"))
			l11111ll111_l1_ += pack(l1l111_l1_ (u"ࠥࡆࠧ㚐"), len(part))
			for l1111lll1ll_l1_ in part:
				l11111ll111_l1_ += pack(l1l111_l1_ (u"ࠦࡨࠨ㚑"), l1111lll1ll_l1_.encode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㚒")))
		l11111ll111_l1_ += pack(l1l111_l1_ (u"ࠨࡂࠣ㚓"), 0)
		l11111ll111_l1_ += pack(l1l111_l1_ (u"ࠢ࠿ࡊࠥ㚔"), 1)
		l11111ll111_l1_ += pack(l1l111_l1_ (u"ࠣࡀࡋࠦ㚕"), 1)
		sock = socket(AF_INET,SOCK_DGRAM)
		sock.sendto(bytes(l11111ll111_l1_), (l1l1lll1l111_l1_, 53))
		sock.settimeout(6)
		data, addr = sock.recvfrom(1024)
		sock.close()
		l11l1l1ll1l_l1_ = unpack_from(l1l111_l1_ (u"ࠤࡁࡌࡍࡎࡈࡉࡊࠥ㚖"), data, 0)
		l111ll111ll_l1_ = l11l1l1ll1l_l1_[3]
		offset = len(host)+18
		l11l111ll11_l1_ = []
		for _ in range(l111ll111ll_l1_):
			l111l1l1l11_l1_ = offset
			l1lll1ll11l1_l1_ = 1
			l11111l1l11_l1_ = False
			while True:
				l1111lll1ll_l1_ = unpack_from(l1l111_l1_ (u"ࠥࡂࡇࠨ㚗"), data, l111l1l1l11_l1_)[0]
				if l1111lll1ll_l1_ == 0:
					l111l1l1l11_l1_ += 1
					break
				if l1111lll1ll_l1_ >= 192:
					l1111ll11ll_l1_ = unpack_from(l1l111_l1_ (u"ࠦࡃࡈࠢ㚘"), data, l111l1l1l11_l1_ + 1)[0]
					l111l1l1l11_l1_ = ((l1111lll1ll_l1_ << 8) + l1111ll11ll_l1_ - 0xc000) - 1
					l11111l1l11_l1_ = True
				l111l1l1l11_l1_ += 1
				if l11111l1l11_l1_ == False: l1lll1ll11l1_l1_ += 1
			if l11111l1l11_l1_ == True: l1lll1ll11l1_l1_ += 1
			offset = offset + l1lll1ll11l1_l1_
			l11llllll1l_l1_ = unpack_from(l1l111_l1_ (u"ࠧࡄࡈࡉࡋࡋࠦ㚙"), data, offset)
			offset = offset + 10
			l11l1ll111l_l1_ = l11llllll1l_l1_[0]
			l11111l1ll1_l1_ = l11llllll1l_l1_[3]
			if l11l1ll111l_l1_ == 1:
				l1111llll1l_l1_ = unpack_from(l1l111_l1_ (u"ࠨ࠾ࠣ㚚")+l1l111_l1_ (u"ࠢࡃࠤ㚛")*l11111l1ll1_l1_, data, offset)
				l1ll1ll1l1ll_l1_ = l1l111_l1_ (u"ࠨࠩ㚜")
				for l1111lll1ll_l1_ in l1111llll1l_l1_: l1ll1ll1l1ll_l1_ += str(l1111lll1ll_l1_) + l1l111_l1_ (u"ࠩ࠱ࠫ㚝")
				l1ll1ll1l1ll_l1_ = l1ll1ll1l1ll_l1_[0:-1]
				l11l111ll11_l1_.append(l1ll1ll1l1ll_l1_)
			if l11l1ll111l_l1_ in [1,2,5,6,15,28]: offset = offset + l11111l1ll1_l1_
	except: l11l111ll11_l1_ = []
	if not l11l111ll11_l1_: l11llllll1_l1_(l1l111_l1_ (u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨ㚞"),l11llll11l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠫࠥࠦࠠࡅࡐࡖࡣࡗࡋࡓࡐࡎ࡙ࡉࡗࠦࡦࡢ࡫࡯ࡩࡩࠦࠠࠡࡊࡲࡷࡹࡀࠠ࡜ࠢࠪ㚟")+host+l1l111_l1_ (u"ࠬࠦ࡝ࠨ㚠"))
	return l11l111ll11_l1_
def l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_,l11_l1_=True):
	if l1111ll_l1_:
		l11l1l1l1ll_l1_ = [l1l111_l1_ (u"࠭ใษษิࠫ㚡"),l1l111_l1_ (u"ࠧษษ็฾ࠬ㚢"),l1l111_l1_ (u"ࠨࡣࡧࡹࡱࡺࠧ㚣"),l1l111_l1_ (u"ࠩࡻࡼࠬ㚤"),l1l111_l1_ (u"ࠪࡷࡪࡾࠧ㚥")]
		if l1ll1_l1_!=l1l111_l1_ (u"ࠫࡇࡕࡋࡓࡃࠪ㚦"):
			l11l1l1l1ll_l1_ += [l1l111_l1_ (u"ࠬࡸ࠺ࠨ㚧"),l1l111_l1_ (u"࠭ࡲ࠮ࠩ㚨"),l1l111_l1_ (u"ࠧ࠮࡯ࡤࠫ㚩")]
			l11l1l1l1ll_l1_ += [l1l111_l1_ (u"ࠨ࠼ࡵࠫ㚪"),l1l111_l1_ (u"ࠩ࠰ࡶࠬ㚫"),l1l111_l1_ (u"ࠪࡱࡦ࠳ࠧ㚬")]
		for l1111ll1ll_l1_ in l1111ll_l1_:
			if l1l111_l1_ (u"ࠫ࡬࡫ࡴ࠯ࡲ࡫ࡴࡄ࠭㚭") in l1111ll1ll_l1_: continue
			if l1l111_l1_ (u"ࠬำไใหࠪ㚮") in l1111ll1ll_l1_: continue
			l1111ll1ll_l1_ = l1111ll1ll_l1_.lower()
			if PY2: l1111ll1ll_l1_ = l1111ll1ll_l1_.decode(l1l111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ㚯")).encode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㚰"))
			l1111ll1ll_l1_ = l1111ll1ll_l1_.replace(l1l111_l1_ (u"ࠨ࠼ࠪ㚱"),l1l111_l1_ (u"ࠩࠪ㚲"))
			l11l1111ll1_l1_ = re.findall(l1l111_l1_ (u"ࠪࠬ࠶ࡡ࠵࠮࠻ࡠ࠯ࢁ࠸࡛࠱࠯࠶ࡡ࠰࠯ࠧ㚳"),l1111ll1ll_l1_,re.DOTALL)
			l1lll1111lll_l1_ = False
			for digits in l11l1111ll1_l1_:
				if len(digits)==2:
					l1lll1111lll_l1_ = True
					break
			if l1l111_l1_ (u"ࠫࡳࡵࡴࠡࡴࡤࡸࡪࡪࠧ㚴") in l1111ll1ll_l1_: continue
			elif l1l111_l1_ (u"ࠬࡻ࡮ࡳࡣࡷࡩࡩ࠭㚵") in l1111ll1ll_l1_: continue
			elif l1l111_l1_ (u"ฺ๋࠭ำฺ้ࠣ์แࠨ㚶") in l1111ll1ll_l1_: continue
			elif l1l11ll1lll_l1_(l1l111_l1_ (u"ࠧࡃࡖࡈࡼࡕ࡜࠱࠺ࡕࡕ࡚ࡓ࡛ࡕ࡭ࡘࡇ࡚ࡊ࡜ࡅ࡙ࠩ㚷")): continue
			elif l1111ll1ll_l1_ in [l1l111_l1_ (u"ࠨࡴࠪ㚸")] or l1lll1111lll_l1_ or any(value in l1111ll1ll_l1_ for value in l11l1l1l1ll_l1_):
				l11llllll1_l1_(l1l111_l1_ (u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧ㚹"),l11llll11l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠪࠤࠥࠦࡂ࡭ࡱࡦ࡯ࡪࡪࠠࡢࡦࡸࡰࡹࡹࠠࡷ࡫ࡧࡩࡴࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ㚺")+url+l1l111_l1_ (u"ࠫࠥࡣࠧ㚻"))
				if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㚼"),l1l111_l1_ (u"࠭วๅใํำ๏๎ࠠๅๆๆฬฬืࠠโไฺࠤํษๆศ่๊ࠢ฾ะ็ࠨ㚽"))
				return True
	return False
def l1111l1_l1_(*args,**kwargs):
	if args:
		l1lll1111l1l_l1_ = args[0]
		l11l111l_l1_ = args[1]
		if not l1lll1111l1l_l1_: l1lll1111l1l_l1_ = l1l111_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ㚾")
		if not l11l111l_l1_: l11l111l_l1_ = l1l111_l1_ (u"ࠨษึฮ๊ืวาࠩ㚿")
		header = args[2]
		text = l1l111_l1_ (u"ࠩ࡟ࡲࠬ㛀").join(args[3:])
	else: l1lll1111l1l_l1_,l11l111l_l1_,header,text = l1l111_l1_ (u"ࠪࠫ㛁"),l1l111_l1_ (u"ࠫࡔࡑࠧ㛂"),l1l111_l1_ (u"ࠬ࠭㛃"),l1l111_l1_ (u"࠭ࠧ㛄")
	l1l1lll11111_l1_(l1lll1111l1l_l1_,l1l111_l1_ (u"ࠧࠨ㛅"),l11l111l_l1_,l1l111_l1_ (u"ࠨࠩ㛆"),header,text,**kwargs)
	return
def l1ll11ll1l_l1_(*args,**kwargs):
	l1lll1111l1l_l1_ = args[0]
	l1llll11111l_l1_ = args[1]
	l1lll1l1lll1_l1_ = args[2]
	if l1lll1l1lll1_l1_ or l1llll11111l_l1_: l1lll1lllll1_l1_ = True
	else: l1lll1lllll1_l1_ = False
	header = args[3]
	text = args[4]
	if not l1lll1111l1l_l1_: l1lll1111l1l_l1_ = l1l111_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ㛇")
	if not l1llll11111l_l1_: l1llll11111l_l1_ = l1l111_l1_ (u"ࠪ็้อࠧ㛈")
	if not l1lll1l1lll1_l1_: l1lll1l1lll1_l1_ = l1l111_l1_ (u"๋ࠫ฿ๅࠨ㛉")
	if len(args)>=6: text += l1l111_l1_ (u"ࠬࡢ࡮ࠨ㛊")+args[5]
	if len(args)>=7: text += l1l111_l1_ (u"࠭࡜࡯ࠩ㛋")+args[6]
	l111llll11l_l1_ = l1l1lll11111_l1_(l1lll1111l1l_l1_,l1llll11111l_l1_,l1l111_l1_ (u"ࠧࠨ㛌"),l1lll1l1lll1_l1_,header,text,**kwargs)
	if l111llll11l_l1_==-1 and l1lll1lllll1_l1_: l111llll11l_l1_ = -1
	elif l111llll11l_l1_==-1 and not l1lll1lllll1_l1_: l111llll11l_l1_ = False
	elif l111llll11l_l1_==0: l111llll11l_l1_ = False
	elif l111llll11l_l1_==2: l111llll11l_l1_ = True
	return l111llll11l_l1_
def l1ll11ll_l1_(*args,**kwargs):
	return xbmcgui.Dialog().select(*args,**kwargs)
def l1ll1lll_l1_(*args,**kwargs):
	header = args[0]
	text = args[1]
	if l1l111_l1_ (u"ࠨࡶ࡬ࡱࡪ࠭㛍") in list(kwargs.keys()): l1l11111lll_l1_ = kwargs[l1l111_l1_ (u"ࠩࡷ࡭ࡲ࡫ࠧ㛎")]
	else: l1l11111lll_l1_ = 1000
	if len(args)>2 and l1l111_l1_ (u"ࠪࡸ࡮ࡳࡥࠨ㛏") not in args[2]: profile = args[2]
	else: profile = l1l111_l1_ (u"ࠫࡳࡵࡴࡪࡨ࡬ࡧࡦࡺࡩࡰࡰࠪ㛐")
	l1ll11111ll1_l1_ = l1l1l1llll1_l1_(l1l111_l1_ (u"ࠬࡊࡩࡢ࡮ࡲ࡫ࡓࡵࡴࡪࡨ࡬ࡧࡦࡺࡩࡰࡰࡌࡱࡦ࡭ࡥ࠯ࡺࡰࡰࠬ㛑"),l1l1l1l1ll1_l1_,l1l111_l1_ (u"࠭ࡄࡦࡨࡤࡹࡱࡺࠧ㛒"),l1l111_l1_ (u"ࠧ࠸࠴࠳ࡴࠬ㛓"))
	l1lll111l1ll_l1_,l111llll1ll_l1_ = l1llllll1ll1_l1_(l1l111_l1_ (u"ࠨࠩ㛔"),l1l111_l1_ (u"ࠩࠪ㛕"),l1l111_l1_ (u"ࠪࠫ㛖"),header,text,profile,l1l111_l1_ (u"ࠫࡱ࡫ࡦࡵࠩ㛗"),720,False)
	l1ll11111ll1_l1_.show()
	if profile==l1l111_l1_ (u"ࠬࡴ࡯ࡵ࡫ࡩ࡭ࡨࡧࡴࡪࡱࡱࡣࡹࡽ࡯ࡩࡣ࡯ࡪࡸ࠭㛘"):
		l1ll11111ll1_l1_.getControl(9040).setHeight(215)
		l1ll11111ll1_l1_.getControl(9040).setPosition(55,-80)
		l1ll11111ll1_l1_.getControl(9050).setPosition(120,-60)
		l1ll11111ll1_l1_.getControl(400).setPosition(90,-35)
	l1ll11111ll1_l1_.getControl(401).setVisible(False)
	l1ll11111ll1_l1_.getControl(402).setVisible(False)
	l1ll11111ll1_l1_.getControl(9050).setImage(l1lll111l1ll_l1_)
	l1ll11111ll1_l1_.getControl(9050).setHeight(l111llll1ll_l1_)
	from threading import Thread
	l11lllllll1_l1_ = Thread(target=l1l1ll11llll_l1_,args=(l1ll11111ll1_l1_,l1lll111l1ll_l1_,l1l11111lll_l1_))
	l11lllllll1_l1_.start()
	return
def l1l1ll11llll_l1_(l1ll11111ll1_l1_,l1lll111l1ll_l1_,l1l11111lll_l1_):
	time.sleep(l1l11111lll_l1_//1000.0)
	time.sleep(0.100)
	if os.path.exists(l1lll111l1ll_l1_):
		try: os.remove(l1lll111l1ll_l1_)
		except: pass
	return
def l1ll111lll1l_l1_(*args,**kwargs):
	header,text,profile,l1lll1111l1l_l1_ = l1l111_l1_ (u"࠭ࠧ㛙"),l1l111_l1_ (u"ࠧࠨ㛚"),l1l111_l1_ (u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࡣࡱࡵ࡮ࡨࠩ㛛"),l1l111_l1_ (u"ࠩ࡯ࡩ࡫ࡺࠧ㛜")
	if len(args)>=1: header = args[0]
	if len(args)>=2: text = args[1]
	if len(args)>=3: profile = args[2]
	if len(args)>=4: l1lll1111l1l_l1_ = args[3]
	return l1l11l1l1l_l1_(l1lll1111l1l_l1_,header,text,profile)
def l11ll1111ll_l1_(*args,**kwargs):
	return xbmcgui.Dialog().l1ll1l1l11ll_l1_(*args,**kwargs)
def l11lllllll_l1_(*args,**kwargs):
	return xbmcgui.Dialog().browseSingle(*args,**kwargs)
def l1ll1lll1111_l1_(*args,**kwargs):
	return xbmcgui.Dialog().input(*args,**kwargs)
def l1l111ll1l_l1_(*args,**kwargs):
	return xbmcgui.DialogProgress(*args,**kwargs)
def l11ll1l11l1_l1_(l1lll1l1l11l_l1_):
	if kodi_version>17.99: l1ll11111ll1_l1_ = l1l111_l1_ (u"ࠪࡦࡺࡹࡹࡥ࡫ࡤࡰࡴ࡭࡮ࡰࡥࡤࡲࡨ࡫࡬ࠨ㛝")
	else: l1ll11111ll1_l1_ = l1l111_l1_ (u"ࠫࡧࡻࡳࡺࡦ࡬ࡥࡱࡵࡧࠨ㛞")
	l1lll1l1l11l_l1_ = l1lll1l1l11l_l1_.lower()
	if l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠬࡹࡴࡢࡴࡷࠫ㛟"): xbmc.executebuiltin(l1l111_l1_ (u"࠭ࡁࡤࡶ࡬ࡺࡦࡺࡥࡘ࡫ࡱࡨࡴࡽࠨࠨ㛠")+l1ll11111ll1_l1_+l1l111_l1_ (u"ࠧࠪࠩ㛡"))
	elif l1lll1l1l11l_l1_==l1l111_l1_ (u"ࠨࡵࡷࡳࡵ࠭㛢"): xbmc.executebuiltin(l1l111_l1_ (u"ࠩࡇ࡭ࡦࡲ࡯ࡨ࠰ࡆࡰࡴࡹࡥࠩࠩ㛣")+l1ll11111ll1_l1_+l1l111_l1_ (u"ࠪ࠭ࠬ㛤"))
	return
def l1l1lll11111_l1_(l1lll1111l1l_l1_,l111l11l1l1_l1_=l1l111_l1_ (u"ࠫࠬ㛥"),l1ll11l1ll1l_l1_=l1l111_l1_ (u"ࠬ࠭㛦"),l111l11llll_l1_=l1l111_l1_ (u"࠭ࠧ㛧"),header=l1l111_l1_ (u"ࠧࠨ㛨"),text=l1l111_l1_ (u"ࠨࠩ㛩"),profile=l1l111_l1_ (u"ࠩࡦࡳࡳ࡬ࡩࡳ࡯ࡢࡦ࡮࡭ࡦࡰࡰࡷࠫ㛪"),l1lll1llll11_l1_=0,l1ll1ll111l1_l1_=0):
	if not l1lll1111l1l_l1_: l1lll1111l1l_l1_ = l1l111_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ㛫")
	l1ll11111ll1_l1_ = l1ll11lll1ll_l1_(l1l111_l1_ (u"ࠫࡉ࡯ࡡ࡭ࡱࡪࡇࡴࡴࡦࡪࡴࡰࡘ࡭ࡸࡥࡦࡄࡸࡸࡹࡵ࡮ࡴ࠰ࡻࡱࡱ࠭㛬"),l1l1l1l1ll1_l1_,l1l111_l1_ (u"ࠬࡊࡥࡧࡣࡸࡰࡹ࠭㛭"),l1l111_l1_ (u"࠭࠷࠳࠲ࡳࠫ㛮"))
	l1ll11111ll1_l1_.l111llll1l1_l1_(l111l11l1l1_l1_,l1ll11l1ll1l_l1_,l111l11llll_l1_,header,text,profile,l1lll1111l1l_l1_,900,l1lll1llll11_l1_,l1ll1ll111l1_l1_)
	if l1lll1llll11_l1_>0: l1ll11111ll1_l1_.l11lllll11l_l1_()
	if l1ll1ll111l1_l1_>0: l1ll11111ll1_l1_.l11lll111l1_l1_()
	if l1lll1llll11_l1_==0 and l1ll1ll111l1_l1_==0: l1ll11111ll1_l1_.l11l111lll1_l1_()
	l1ll11111ll1_l1_.doModal()
	l111llll11l_l1_ = l1ll11111ll1_l1_.l11llllll11_l1_
	return l111llll11l_l1_
def l1l11l1l1l_l1_(l1lll1111l1l_l1_,header,text,profile=l1l111_l1_ (u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࡢࡰࡴࡴࡧࠨ㛯")):
	if not l1lll1111l1l_l1_: l1lll1111l1l_l1_ = l1l111_l1_ (u"ࠨ࡮ࡨࡪࡹ࠭㛰")
	l1ll11111ll1_l1_ = l1l1l1llll1_l1_(l1l111_l1_ (u"ࠩࡇ࡭ࡦࡲ࡯ࡨࡖࡨࡼࡹ࡜ࡩࡦࡹࡨࡶࡋࡻ࡬࡭ࡕࡦࡶࡪ࡫࡮࠯ࡺࡰࡰࠬ㛱"),l1l1l1l1ll1_l1_,l1l111_l1_ (u"ࠪࡈࡪ࡬ࡡࡶ࡮ࡷࠫ㛲"),l1l111_l1_ (u"ࠫ࠼࠸࠰ࡱࠩ㛳"))
	l1lll111l1ll_l1_,l111llll1ll_l1_ = l1llllll1ll1_l1_(l1l111_l1_ (u"ࠬ࠭㛴"),l1l111_l1_ (u"࠭ࠧ㛵"),l1l111_l1_ (u"ࠧࠨ㛶"),header,text,profile,l1lll1111l1l_l1_,1270,False)
	l1ll11111ll1_l1_.show()
	l1ll11111ll1_l1_.getControl(9050).setHeight(l111llll1ll_l1_)
	l1ll11111ll1_l1_.getControl(9050).setImage(l1lll111l1ll_l1_)
	result = l1ll11111ll1_l1_.doModal()
	try: os.remove(l1lll111l1ll_l1_)
	except: pass
	return result
def l1l1ll11l_l1_(l1ll1l1l1lll_l1_=True):
	if l1ll1l1l1lll_l1_:
		l11ll11lll_l1_ = l1lll11l111_l1_(main_dbfile,l1l111_l1_ (u"ࠨࡵࡷࡶࠬ㛷"),l1l111_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬ㛸"),l1l111_l1_ (u"࡙ࠪࡘࡋࡒࡂࡉࡈࡒ࡙࠭㛹"))
		if l11ll11lll_l1_: return l11ll11lll_l1_
	text = l1l111_l1_ (u"ࠫࠬ㛺")
	url = l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡴࡦࡥ࡫ࡦࡱࡵࡧ࠯ࡹ࡬ࡰࡱࡹࡨࡰࡷࡶࡩ࠳ࡩ࡯࡮࠱࠵࠴࠶࠸࠯࠱࠳࠲࠴࠸࠵࡭ࡰࡵࡷ࠱ࡨࡵ࡭࡮ࡱࡱ࠱ࡺࡹࡥࡳ࠯ࡤ࡫ࡪࡴࡴࡴ࠱ࠪ㛻")
	headers = {l1l111_l1_ (u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧ㛼"):url}
	response = l11l1l_l1_(l1lll11l1ll_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ㛽"),url,l1l111_l1_ (u"ࠨࠩ㛾"),headers,l1l111_l1_ (u"ࠩࠪ㛿"),l1l111_l1_ (u"ࠪࠫ㜀"),l1l111_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡘࡁࡏࡆࡒࡑࡤ࡛ࡓࡆࡔࡄࡋࡊࡔࡔ࠮࠳ࡶࡸࠬ㜁"),False,False)
	if response.succeeded:
		html = response.content
		count = html.count(l1l111_l1_ (u"ࠬࡓ࡯ࡻ࡫࡯ࡰࡦ࠭㜂"))
		if count>80:
			text = re.findall(l1l111_l1_ (u"࠭ࡧࡦࡶ࠰ࡸ࡭࡫࠭࡭࡫ࡶࡸ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ㜃"),html,re.DOTALL)
			text = text[0]
	if not text:
		l1llll1lll11_l1_ = os.path.join(l1l1l1l1ll1_l1_,l1l111_l1_ (u"ࠧࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭㜄"),l1l111_l1_ (u"ࠨࡷࡶࡩࡷࡧࡧࡦࡰࡷࡷ࠳ࡺࡸࡵࠩ㜅"))
		text = open(l1llll1lll11_l1_,l1l111_l1_ (u"ࠩࡵࡦࠬ㜆")).read()
		if PY3: text = text.decode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㜇"))
		text = text.replace(l1l111_l1_ (u"ࠫࡡࡸࠧ㜈"),l1l111_l1_ (u"ࠬ࠭㜉"))
	l1lllll1llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠨࡎࡱࡽ࡭ࡱࡲࡡ࠯ࠬࡂ࠭ࡡࡴࠧ㜊"),text,re.DOTALL)
	l11ll11llll_l1_ = []
	for line in l1lllll1llll_l1_:
		l1lll1l11ll1_l1_ = line.lower()
		if l1l111_l1_ (u"ࠧࡢࡰࡧࡶࡴ࡯ࡤࠨ㜋") in l1lll1l11ll1_l1_: continue
		if l1l111_l1_ (u"ࠨࡷࡥࡹࡳࡺࡵࠨ㜌") in l1lll1l11ll1_l1_: continue
		if l1l111_l1_ (u"ࠩ࡬ࡴ࡭ࡵ࡮ࡦࠩ㜍") in l1lll1l11ll1_l1_: continue
		if l1l111_l1_ (u"ࠪࡧࡷࡵࡳࠨ㜎") in l1lll1l11ll1_l1_: continue
		l11ll11llll_l1_.append(line)
	l11ll11lll_l1_ = random.sample(l11ll11llll_l1_,1)
	l11ll11lll_l1_ = l11ll11lll_l1_[0]
	l1lll111111_l1_(main_dbfile,l1l111_l1_ (u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧ㜏"),l1l111_l1_ (u"࡛ࠬࡓࡆࡔࡄࡋࡊࡔࡔࠨ㜐"),l11ll11lll_l1_,l11l1l1_l1_)
	return l11ll11lll_l1_
def l11l11ll11l_l1_(l1111ll1l11_l1_=l1l111_l1_ (u"࠭ࠧ㜑")):
	if not l1111ll1l11_l1_: l1111ll1l11_l1_ = traceback.format_exc()
	sys.stderr.write(l1111ll1l11_l1_)
	lines = l1111ll1l11_l1_.splitlines()
	error = lines[-1]
	l111l1l1l1l_l1_ = open(l1llll1l1ll1_l1_,l1l111_l1_ (u"ࠧࡳࡤࠪ㜒")).read()
	if PY3: l111l1l1l1l_l1_ = l111l1l1l1l_l1_.decode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭㜓"))
	l111l1l1l1l_l1_ = l111l1l1l1l_l1_[-8000:]
	sep = l1l111_l1_ (u"ࠩࡀࠫ㜔")*100
	if sep in l111l1l1l1l_l1_: l111l1l1l1l_l1_ = l111l1l1l1l_l1_.rsplit(sep,1)[1]
	if error in l111l1l1l1l_l1_: l111l1l1l1l_l1_ = l111l1l1l1l_l1_.rsplit(error,1)[0]
	l1ll1l1111ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠬࡘࡵࡵࡳࡥࡨࢀࡒࡵࡤࡦࠫ࠽ࠤࡡࡡࠠࠩ࠰࠭ࡃ࠮ࠦ࡜࡞ࠩ㜕"),l111l1l1l1l_l1_,re.DOTALL)
	for typ,source in reversed(l1ll1l1111ll_l1_):
		if source: break
	else: source = l1l111_l1_ (u"ࠫࡓࡕࡔࠡࡕࡓࡉࡈࡏࡆࡊࡇࡇࠫ㜖")
	file,line,func = l1l111_l1_ (u"ࠬ࠭㜗"),l1l111_l1_ (u"࠭ࠧ㜘"),l1l111_l1_ (u"ࠧࠨ㜙")
	l11ll111ll1_l1_ = l1l111_l1_ (u"ࠨ࡝ࡕࡘࡑࡣ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ษ็า฼ษ࠺ࠡࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㜚")+error
	l1ll1l1l1l11_l1_ = l1l111_l1_ (u"ࠩ࡞ࡖ࡙ࡒ࡝࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ส่๊฻ฯา࠼ࠣࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㜛")+source
	for l1lll1llllll_l1_ in reversed(lines):
		if l1l111_l1_ (u"ࠪࡊ࡮ࡲࡥࠡࠤࠪ㜜") in l1lll1llllll_l1_ and l1l111_l1_ (u"ࠫࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪ㜝") in l1lll1llllll_l1_: break
	l1lll1llllll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡌࡩ࡭ࡧࠣࠦ࠭࠴ࠪࡀࠫࠥࡠ࠱ࠦ࡬ࡪࡰࡨࠤ࠭࠴ࠪࡀࠫ࡟࠰ࠥ࡯࡮ࠡࠪ࠱࠮ࡄ࠯ࠤࠨ㜞"),l1lll1llllll_l1_,re.DOTALL)
	if l1lll1llllll_l1_:
		file,line,func = l1lll1llllll_l1_[0]
		if l1l111_l1_ (u"࠭࠯ࠨ㜟") in file: file = file.rsplit(l1l111_l1_ (u"ࠧ࠰ࠩ㜠"),1)[1]
		else: file = file.rsplit(l1l111_l1_ (u"ࠨ࡞࡟ࠫ㜡"),1)[1]
		l1l1llllllll_l1_ = l1l111_l1_ (u"ࠩ࡞ࡖ࡙ࡒ࡝࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ส่๊๊แ࠻ࠢࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㜢")+file
		line2 = l1l111_l1_ (u"ࠪ࡟ࡗ࡚ࡌ࡞࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠหู้ืา࠼ࠣࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㜣")+line
		l11lllll1l1_l1_ = l1l111_l1_ (u"ࠫࡠࡘࡔࡍ࡟࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡฬ๊ๅไษ้࠾࡛ࠥࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ㜤")+func
		l111l1ll11l_l1_ = l1l1llllllll_l1_+l1l111_l1_ (u"ࠬࡢ࡮ࠨ㜥")+line2+l1l111_l1_ (u"࠭࡜࡯ࠩ㜦")+l11lllll1l1_l1_+l1l111_l1_ (u"ࠧ࡝ࡰࠪ㜧")+l1ll1l1l1l11_l1_+l1l111_l1_ (u"ࠨ࡞ࡱࠫ㜨")+l11ll111ll1_l1_
		l1lll11l1lll_l1_ = line2+l1l111_l1_ (u"ࠩ࡟ࡲࠬ㜩")+l1ll1l1l1l11_l1_+l1l111_l1_ (u"ࠪࡠࡳ࠭㜪")+l11ll111ll1_l1_+l1l111_l1_ (u"ࠫࡡࡴࠧ㜫")+l1l1llllllll_l1_+l1l111_l1_ (u"ࠬࡢ࡮ࠨ㜬")+l11lllll1l1_l1_
		l1lllllll1l1_l1_ = line2+l1l111_l1_ (u"࠭࡜࡯ࠩ㜭")+l11ll111ll1_l1_+l1l111_l1_ (u"ࠧ࡝ࡰࠪ㜮")+l1l1llllllll_l1_+l1l111_l1_ (u"ࠨ࡞ࡱࠫ㜯")+l11lllll1l1_l1_
	else:
		l1l1llllllll_l1_,line2,l11lllll1l1_l1_ = l1l111_l1_ (u"ࠩࠪ㜰"),l1l111_l1_ (u"ࠪࠫ㜱"),l1l111_l1_ (u"ࠫࠬ㜲")
		l111l1ll11l_l1_ = l1ll1l1l1l11_l1_+l1l111_l1_ (u"ࠬࡢ࡮࡝ࡰࠪ㜳")+l11ll111ll1_l1_
		l1lll11l1lll_l1_ = l1ll1l1l1l11_l1_+l1l111_l1_ (u"࠭࡜࡯࡞ࡱࠫ㜴")+l11ll111ll1_l1_
		l1lllllll1l1_l1_ = l11ll111ll1_l1_
	l11l11l1l1l_l1_ = l1l111_l1_ (u"ࠧฮัฮࠤำ฽รࠡ฼ํี๋ࠥโึ๊าࠫ㜵")+l1l111_l1_ (u"ࠨ࡞ࡱࠫ㜶")
	l1ll11111l11_l1_ = l111lll1111_l1_()
	l1llll1l11l1_l1_ = []
	l1lll_l1_ = l1ll11111l11_l1_[l1l111_l1_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧ㜷")]
	l1lll1llll1l_l1_ = l1l1ll1l11ll_l1_(l1l11l1l1l1_l1_)
	if l1l111_l1_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨ㜸") in list(l1ll11111l11_l1_.keys()):
		for l1ll1l1l1l1l_l1_,l1111l1l1ll_l1_,l11ll11l111_l1_ in l1lll_l1_: l1llll1l11l1_l1_ = max(l1llll1l11l1_l1_,l1111l1l1ll_l1_)
		if l1lll1llll1l_l1_<l1llll1l11l1_l1_:
			header = l1l111_l1_ (u"ࠫ็๋ࠠษฬะำ๏ัࠠศๆหี๋อๅอࠢๅฬ้ࠦลาีส่ࠥอไฤะฺหฦࠦไๅ็หี๊าࠧ㜹")
			l111llll11l_l1_ = l1l1lll11111_l1_(l1l111_l1_ (u"ࠬࡸࡩࡨࡪࡷࠫ㜺"),l1l111_l1_ (u"࠭ลาีส่ࠥหไ๊ࠢส่๊ฮัๆฮࠪ㜻"),l1l111_l1_ (u"ࠧหฯา๎ะ࠭㜼"),l1l111_l1_ (u"ࠨะิ์ั࠭㜽"),l11l11l1l1l_l1_+header,l111l1ll11l_l1_)
			if l111llll11l_l1_==0:
				l1llll111l_l1_ = l1ll11ll1l_l1_(l1l111_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ㜾"),l1l111_l1_ (u"ࠪาึ๎ฬࠨ㜿"),l1l111_l1_ (u"ࠫฯำฯ๋อࠪ㝀"),l1l111_l1_ (u"ࠬ࠭㝁"),header)
				if l1llll111l_l1_==1: l111llll11l_l1_ = 1
			if l111llll11l_l1_==1:
				from l1l1l111l11_l1_ import l1lll1l1ll1l_l1_
				l1lll1l1ll1l_l1_()
			return
	l1l1ll11lll1_l1_ = l1lll11l111_l1_(main_dbfile,l1l111_l1_ (u"࠭࡬ࡪࡵࡷࠫ㝂"),l1l111_l1_ (u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪ㝃"),l1l111_l1_ (u"ࠨࡃࡏࡐࡤ࡙ࡅࡏࡖࡢࡉࡗࡘࡏࡓࡕࠪ㝄"))
	if not l1l1ll11lll1_l1_: l1l1ll11lll1_l1_ = []
	l1lll11l1lll_l1_ = l1lll11l1lll_l1_.replace(l1l111_l1_ (u"ࠩ࡟ࡲࠬ㝅"),l1l111_l1_ (u"ࠪࡠࡡࡴࠧ㝆")).replace(l1l111_l1_ (u"ࠫࡠࡘࡔࡍ࡟ࠪ㝇"),l1l111_l1_ (u"ࠬ࠭㝈")).replace(l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ㝉"),l1l111_l1_ (u"ࠧࠨ㝊")).replace(l1l111_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㝋"),l1l111_l1_ (u"ࠩࠪ㝌"))
	l1lllllll1l1_l1_ = l1lllllll1l1_l1_.replace(l1l111_l1_ (u"ࠪࡠࡳ࠭㝍"),l1l111_l1_ (u"ࠫࡡࡢ࡮ࠨ㝎")).replace(l1l111_l1_ (u"ࠬࡡࡒࡕࡎࡠࠫ㝏"),l1l111_l1_ (u"࠭ࠧ㝐")).replace(l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ㝑"),l1l111_l1_ (u"ࠨࠩ㝒")).replace(l1l111_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㝓"),l1l111_l1_ (u"ࠪࠫ㝔"))
	l1l1ll1lll1l_l1_ = l1l11l1l1l1_l1_+l1l111_l1_ (u"ࠫ࠿ࡀࠧ㝕")+l1lllllll1l1_l1_
	if l1l1ll1lll1l_l1_ in l1l1ll11lll1_l1_:
		header = l1l111_l1_ (u"๊ࠬโะࠢๅ้ฯࠦว็ฬࠣืฬฮโศࠢหษึูวๅ๊ࠢิฬࠦวๅะฺวࠥหไ๊ࠢส่๊ฮัๆฮࠪ㝖")
		l1111l1_l1_(l1l111_l1_ (u"࠭ࡲࡪࡩ࡫ࡸࠬ㝗"),l1l111_l1_ (u"ࠧࠨ㝘"),l11l11l1l1l_l1_+header,l111l1ll11l_l1_)
		return
	l1l1lll11lll_l1_ = str(kodi_version).split(l1l111_l1_ (u"ࠨ࠰ࠪ㝙"))[0]
	url = l1l11l1_l1_[l1l111_l1_ (u"ࠩࡓ࡝࡙ࡎࡏࡏࠩ㝚")][6]
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ㝛"),url,l1l111_l1_ (u"ࠫࠬ㝜"),l1l111_l1_ (u"ࠬ࠭㝝"),l1l111_l1_ (u"࠭ࠧ㝞"),l1l111_l1_ (u"ࠧࠨ㝟"),l1l111_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡈ࡜ࡎ࡚࡟ࡆࡔࡕࡓࡗ࡙࠭࠲ࡵࡷࠫ㝠"),False,False)
	html = response.content
	l11lll1111l_l1_ = re.findall(l1l111_l1_ (u"ࠩࡖࡘࡆࡘࡔ࠻࠼ࡖࡘࡆࡘࡔ࡜࡞ࡵࡠࡳࡣࠫ࠻࠼ࠫ࠲࠯ࡅࠩ࡜࡞ࡵࡠࡳࡣࠫ࠻࠼ࠫ࠲࠯ࡅࠩ࡜࡞ࡵࡠࡳࡣࠫ࠻࠼ࠫ࠲࠯ࡅࠩ࡜࡞ࡵࡠࡳࡣࠫ࠻࠼ࠫ࠲࠯ࡅࠩ࡜࡞ࡵࡠࡳࡣࠫࡆࡐࡇ࠾࠿ࡋࡎࡅࠩ㝡"),html,re.DOTALL)
	for l11l11l111l_l1_,l11ll111l1l_l1_,l111111111l_l1_,l1lll11l1ll1_l1_ in l11lll1111l_l1_:
		l11l11l111l_l1_ = l11l11l111l_l1_.split(l1l111_l1_ (u"ࠪ࠯ࠬ㝢"))
		l111111111l_l1_ = l111111111l_l1_.split(l1l111_l1_ (u"ࠫ࠰࠭㝣"))
		l1lll11l1ll1_l1_ = l1lll11l1ll1_l1_.split(l1l111_l1_ (u"ࠬ࠱ࠧ㝤"))
		if line in l11l11l111l_l1_ and error==l11ll111l1l_l1_ and l1l11l1l1l1_l1_ in l111111111l_l1_ and l1l1lll11lll_l1_ in l1lll11l1ll1_l1_:
			header = l1l111_l1_ (u"࠭็ัษࠣห้ิืฤ่ࠢ฽ึ๎แ๊ࠡึ๎฾อไอࠢหห้หีะษิࠤฬ๊โศั่ࠫ㝥")
			l1llll111l_l1_ = l1ll11ll1l_l1_(l1l111_l1_ (u"ࠧࡳ࡫ࡪ࡬ࡹ࠭㝦"),l1l111_l1_ (u"ࠨะิ์ั࠭㝧"),l1l111_l1_ (u"ࠩศีุอไࠡว็ํࠥอไๆสิ้ั࠭㝨"),l11l11l1l1l_l1_+header,l111l1ll11l_l1_)
			if l1llll111l_l1_==1: l1111l1_l1_(l1l111_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ㝩"),l1l111_l1_ (u"ࠫࠬ㝪"),l1l111_l1_ (u"ࠬ࠭㝫"),header)
			return
	header = l1l111_l1_ (u"࠭วๅำฯหฦࠦลาีส่ࠥํะศࠢส่ำ฽รࠡว็ํࠥอไๆสิ้ั࠭㝬")
	l1111l1_l1_(l1l111_l1_ (u"ࠧࡳ࡫ࡪ࡬ࡹ࠭㝭"),l1l111_l1_ (u"ࠨวิืฬ๊ࠠฦๆ์ࠤฬ๊ๅษำ่ะࠬ㝮"),l11l11l1l1l_l1_+header,l111l1ll11l_l1_)
	l1llll111l_l1_ = l1ll11ll1l_l1_(l1l111_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ㝯"),l1l111_l1_ (u"ࠪ็้อࠧ㝰"),l1l111_l1_ (u"๋ࠫ฿ๅࠨ㝱"),l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㝲"),l1l111_l1_ (u"࠭ำ้ใࠣ๎ฯ๋ࠠฦำึห้ࠦำอๆࠣห้ษฮุษฤࠤํอไศีอาิอๅࠡว็ํࠥอไๆสิ้ัࠦไไ์ࠣ๎฾ืแࠡษ็้อืๅอࠢฦ๎๋่ࠦๆฬ์ࠤํ้๊โ๋่๊ࠢอะศࠢะู้ะ่ࠠา๊ࠤฬ๊ๅีๅ็อ๊ࠥร็ࠢส่๊ฮัๆฮ่ࠣฬฺ๊ࠦๆ่ࠤฬฺ๊๋สࠣ์้อ๋ࠠีอ฻๏฿ࠠศื็หาࠦๅีๅ็อࠥ๎็้ࠢ็หࠥ๐ูาใࠣ็๏็ู้ࠠิฮࠥ๎ไๆษำหࠥ฾็าฬࠣ์๊ะฺ้๊ࠡีฯࠦ็ั้ࠣห้๋ิไๆฬࠤ࠳ࠦ็ๅࠢอี๏ีࠠฤำึห้ࠦวๅีฯ่ࠥลࠧ㝳"))
	if l1llll111l_l1_==1: l1l1lll1111l_l1_ = l1l111_l1_ (u"ࠧࡠࡒࡕࡓࡇࡒࡅࡎࡡࠪ㝴")
	else:
		l1111l1_l1_(l1l111_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ㝵"),l1l111_l1_ (u"ࠩࠪ㝶"),l1l111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭㝷"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣสๆࠢศ่฿อมࠡวิืฬ๊ࠠศๆั฻ศࡡ࠯ࡄࡑࡏࡓࡗࡣ࡜࡯ๆฦ๊ࠥอไๆสิ้ัࠦไศࠢํ฽้๋ࠠศๆ฽๎อ่ࠦๅษࠣ๎ุะื๋฻ࠣษฺ๊วฮࠢส่ำ฽รࠡสา์๋ࠦำอๆࠣห้ษฮุษฤࠤฬ๊ะ๋่ࠢ็ฯ๎ศࠡใํ๋ࠥาๅ๋฻ࠣฮๆอี๋ๆ๋ࠣีอࠠศๆั฻ศ่ࠦ฻์ิ๋๋ࠥๆࠡษ็วำ฽วยࠩ㝸"))
		return
	message = l1lll11l1lll_l1_
	from l1l1l111l11_l1_ import l11l11lllll_l1_
	succeeded = l11l11lllll_l1_(l1l111_l1_ (u"ࠬࡋࡲࡳࡱࡵࡷࠬ㝹"),message,True,l1l111_l1_ (u"࠭ࠧ㝺"),l1l111_l1_ (u"ࠧࡆࡏࡄࡍࡑ࠳ࡆࡓࡑࡐ࠱ࡊ࡞ࡉࡕࡡࡈࡖࡗࡕࡒࡔࠩ㝻"),l1l1lll1111l_l1_)
	if succeeded and l1l1lll1111l_l1_:
		l1l1ll11lll1_l1_.append(l1l1ll1lll1l_l1_)
		l1lll111111_l1_(main_dbfile,l1l111_l1_ (u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫ㝼"),l1l111_l1_ (u"ࠩࡄࡐࡑࡥࡓࡆࡐࡗࡣࡊࡘࡒࡐࡔࡖࠫ㝽"),l1l1ll11lll1_l1_,l1ll111l11l_l1_)
	return
def l1ll1l1ll111_l1_(data):
	if PY3: data = data.encode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㝾"))
	filename = l1l111_l1_ (u"ࠫࡸࡀ࡜࡝࠲࠳࠴࠵࡫࡭ࡢࡦࡢࠫ㝿")+str(time.time())+l1l111_l1_ (u"ࠬ࠴ࡤࡢࡶࠪ㞀")
	open(filename,l1l111_l1_ (u"࠭ࡷࡣࠩ㞁")).write(data)
	return
def l11lll1llll_l1_(l1l1ll1lll1_l1_):
	if l1l1ll1lll1_l1_:
		l1ll1l11111l_l1_ = l1lll11l111_l1_(main_dbfile,l1l111_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ㞂"),l1l111_l1_ (u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫ㞃"),l1l111_l1_ (u"ࠩࡔ࡙ࡊ࡙ࡔࡊࡑࡑࡗࠬ㞄"))
		if l1ll1l11111l_l1_: return l1ll1l11111l_l1_
	url = l1l11l1_l1_[l1l111_l1_ (u"ࠪࡔ࡞࡚ࡈࡐࡐࠪ㞅")][5]
	user = l1l1ll111ll_l1_(32,l1l1ll1lll1_l1_)
	l1111l1ll11_l1_ = l111lllllll_l1_()
	l1lll1l111ll_l1_ = l1111l1ll11_l1_.split(l1l111_l1_ (u"ࠫ࠱࠭㞆"))[2]
	l1ll1lllll1l_l1_ = os.path.join(l1l1l1l1ll1_l1_,l1l111_l1_ (u"ࠬࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫ㞇"))
	l1lllll1ll11_l1_ = l1l1lllll111_l1_()
	payload = {l1l111_l1_ (u"࠭ࡵࡴࡧࡵࠫ㞈"):user,l1l111_l1_ (u"ࠧࡷࡧࡵࡷ࡮ࡵ࡮ࠨ㞉"):l1l11l1l1l1_l1_,l1l111_l1_ (u"ࠨࡥࡲࡹࡳࡺࡲࡺࠩ㞊"):l1lll1l111ll_l1_,l1l111_l1_ (u"ࠩ࡬ࡨࡸ࠭㞋"):l1ll1llll111_l1_(l1lllll1ll11_l1_)}
	response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ㞌"),url,payload,l1l111_l1_ (u"ࠫࠬ㞍"),l1l111_l1_ (u"ࠬ࠭㞎"),l1l111_l1_ (u"࠭ࠧ㞏"),l1l111_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡉࡈࡘࡤࡗࡕࡆࡕࡗࡍࡔࡔࡓ࠮࠳ࡶࡸࠬ㞐"))
	if not response.succeeded: return []
	html = response.content
	l1ll1l11111l_l1_ = html.replace(l1l111_l1_ (u"ࠨ࡞࡟ࡶࠬ㞑"),l1l111_l1_ (u"ࠩ࡟ࡲࠬ㞒")).replace(l1l111_l1_ (u"ࠪࡠࡡࡴࠧ㞓"),l1l111_l1_ (u"ࠫࡡࡴࠧ㞔")).replace(l1l111_l1_ (u"ࠬࡢࡲ࡝ࡰࠪ㞕"),l1l111_l1_ (u"࠭࡜࡯ࠩ㞖")).replace(l1l111_l1_ (u"ࠧ࡝ࡴࠪ㞗"),l1l111_l1_ (u"ࠨ࡞ࡱࠫ㞘"))
	l1ll1l11111l_l1_ = re.findall(l1l111_l1_ (u"ࠩࡖࡘࡆࡘࡔ࠻࠼ࡖࡘࡆࡘࡔ࠻࠼ࠫࡠࡩ࠱ࠩ࠻࠼ࠫ࠲࠯ࡅࠩ࡝ࡰ࠽࠾࠭࠴ࠪࡀࠫ࡟ࡲ࠿ࡀࠨ࠯ࠬࡂ࠭ࡡࡴ࠺࠻ࠪ࠱࠮ࡄ࠯࡜࡯࠼࠽ࠬ࠳࠰࠿ࠪ࡞ࡱࡉࡓࡊ࠺࠻ࡇࡑࡈࠬ㞙"),l1ll1l11111l_l1_,re.DOTALL)
	if not l1ll1l11111l_l1_: return []
	l1ll1l11111l_l1_ = sorted(l1ll1l11111l_l1_,reverse=False,key=lambda key: int(key[0]))
	id,l1l111llll1_l1_,l1l1llll1ll1_l1_,l11l111ll11_l1_,l11l1111l1l_l1_,reason = l1ll1l11111l_l1_[0]
	l1lll11ll1l1_l1_ = reason if l1l11ll1lll_l1_(l1l111_l1_ (u"ࠪࡑ࡙࠶࠵ࡉ࡚࠳ࡰ࡙࡚ࡅࡇࡐࡖ࡙ࡓ࡬ࡕࡆࡘࡖࡗ࡚࠿ࡅ࡙ࠩ㞚")) else l1l1llll1ll1_l1_
	settings.setSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡪࡰࡩࡳࡸ࠴ࡰࡦࡴ࡬ࡳࡩ࠭㞛"),l1lll11ll1l1_l1_)
	l1lll111111_l1_(main_dbfile,l1l111_l1_ (u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࠨ㞜"),l1l111_l1_ (u"࠭ࡑࡖࡇࡖࡘࡎࡕࡎࡔࠩ㞝"),l1ll1l11111l_l1_,l11l1l1_l1_)
	return l1ll1l11111l_l1_
def SPLIT_BIGLIST(items,l1l1ll1ll1ll_l1_=0,l1lllll111l1_l1_=0):
	if l1l1ll1ll1ll_l1_ and not l1lllll111l1_l1_: l1lllll111l1_l1_ = len(items)//l1l1ll1ll1ll_l1_
	l1ll1llll1l1_l1_,l1l111lll1_l1_,l1lll1l11lll_l1_ = [],-1,0
	for item in items:
		if l1lll1l11lll_l1_%l1lllll111l1_l1_==0:
			l1l111lll1_l1_ += 1
			l1ll1llll1l1_l1_.append([])
		l1ll1llll1l1_l1_[l1l111lll1_l1_].append(item)
		l1lll1l11lll_l1_ += 1
	return l1ll1llll1l1_l1_
def l111ll1l11l_l1_(filename,data):
	filepath = os.path.join(addoncachefolder,filename)
	if 1 or l1l111_l1_ (u"ࠧࡊࡒࡗ࡚ࡤ࠭㞞") not in filename or l1l111_l1_ (u"ࠨࡏ࠶࡙ࡤ࠭㞟") not in filename: text = str(data)
	else:
		l1ll1llll1l1_l1_ = SPLIT_BIGLIST(data,8)
		text = l1l111_l1_ (u"ࠩࠪ㞠")
		for split in l1ll1llll1l1_l1_:
			text += str(split)+l1l111_l1_ (u"ࠪࡠࡳࡢ࡮࠾࠿ࡀࡁࡡࡴ࡜࡯ࠩ㞡")
		text = text.strip(l1l111_l1_ (u"ࠫࡡࡴ࡜࡯࠿ࡀࡁࡂࡢ࡮࡝ࡰࠪ㞢"))
	l1l1l1l11ll_l1_ = zlib.compress(text)
	open(filepath,l1l111_l1_ (u"ࠬࡽࡢࠨ㞣")).write(l1l1l1l11ll_l1_)
	return
def l11ll11lll1_l1_(l1l1l1ll11l_l1_,filename):
	if l1l1l1ll11l_l1_==l1l111_l1_ (u"࠭ࡤࡪࡥࡷࠫ㞤"): data = {}
	elif l1l1l1ll11l_l1_==l1l111_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ㞥"): data = []
	elif l1l1l1ll11l_l1_==l1l111_l1_ (u"ࠨࡵࡷࡶࠬ㞦"): data = l1l111_l1_ (u"ࠩࠪ㞧")
	elif l1l1l1ll11l_l1_==l1l111_l1_ (u"ࠪ࡭ࡳࡺࠧ㞨"): data = 0
	else: data = None
	filepath = os.path.join(addoncachefolder,filename)
	l1l1l1l11ll_l1_ = open(filepath,l1l111_l1_ (u"ࠫࡷࡨࠧ㞩")).read()
	text = zlib.decompress(l1l1l1l11ll_l1_)
	if l1l111_l1_ (u"ࠬࡢ࡮࡝ࡰࡀࡁࡂࡃ࡜࡯࡞ࡱࠫ㞪") not in text: data = eval(text)
	else:
		l1ll1llll1l1_l1_ = text.split(l1l111_l1_ (u"࠭࡜࡯࡞ࡱࡁࡂࡃ࠽࡝ࡰ࡟ࡲࠬ㞫"))
		del text
		data = []
		l11l1l11ll1_l1_ = l11l11l1111_l1_()
		id = 0
		for split in l1ll1llll1l1_l1_:
			l11l1l11ll1_l1_.l11l1111l11_l1_(str(id),eval,split)
			id += 1
		del l1ll1llll1l1_l1_
		l11l1l11ll1_l1_.l1ll1ll1lll1_l1_()
		l11l1l11ll1_l1_.l1l1ll1ll1l1_l1_()
		l1l1llll1l1l_l1_ = list(l11l1l11ll1_l1_.l1lllll11l11_l1_.keys())
		l1ll111lllll_l1_ = sorted(l1l1llll1l1l_l1_,reverse=False,key=lambda key: int(key))
		for id in l1ll111lllll_l1_:
			data += l11l1l11ll1_l1_.l1lllll11l11_l1_[id]
	return data
def l1ll11lll1l1_l1_(addon_id):
	l1ll11lll111_l1_ = os.path.join(l1ll11ll11_l1_,l1l111_l1_ (u"ࠧࡢࡦࡧࡳࡳࡹࠧ㞬"),addon_id,l1l111_l1_ (u"ࠨࡣࡧࡨࡴࡴ࠮ࡹ࡯࡯ࠫ㞭"))
	try: l1111l1l11l_l1_ = open(l1ll11lll111_l1_,l1l111_l1_ (u"ࠩࡵࡦࠬ㞮")).read()
	except:
		l1lll1l11l11_l1_ = os.path.join(l11111l111l_l1_,l1l111_l1_ (u"ࠪࡥࡩࡪ࡯࡯ࡵࠪ㞯"),addon_id,l1l111_l1_ (u"ࠫࡦࡪࡤࡰࡰ࠱ࡼࡲࡲࠧ㞰"))
		try: l1111l1l11l_l1_ = open(l1lll1l11l11_l1_,l1l111_l1_ (u"ࠬࡸࡢࠨ㞱")).read()
		except: return l1l111_l1_ (u"࠭ࠧ㞲"),[]
	if PY3: l1111l1l11l_l1_ = l1111l1l11l_l1_.decode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㞳"))
	version = re.findall(l1l111_l1_ (u"ࠨ࡫ࡧࡁ࠳࠰࠿ࡷࡧࡵࡷ࡮ࡵ࡮࠾࡝࡟ࠦࡡ࠭࡝ࠩ࠰࠭ࡃ࠮ࡡ࡜ࠣ࡞ࠪࡡࠬ㞴"),l1111l1l11l_l1_,re.DOTALL|re.IGNORECASE)
	if not version: return l1l111_l1_ (u"ࠩࠪ㞵"),[]
	l1l111111ll_l1_,l11l11111l1_l1_ = version[0],l1l1ll1l11ll_l1_(version[0])
	return l1l111111ll_l1_,l11l11111l1_l1_
def l111lll1111_l1_():
	l111l111lll_l1_ = l1lll11l111_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡨ࡮ࡩࡴࠨ㞶"),l1l111_l1_ (u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧ㞷"),l1l111_l1_ (u"ࠬࡇࡌࡍࡡࡄࡈࡉࡕࡎࡔࡡ࡛ࡑࡑ࠭㞸"))
	if l111l111lll_l1_: return l111l111lll_l1_
	l1ll11111l11_l1_,l111l111lll_l1_ = {},{}
	l1ll1l1111ll_l1_ = [l1l11l1_l1_[l1l111_l1_ (u"࠭ࡒࡆࡒࡒࡗࠬ㞹")][0]]
	if kodi_version>17.99: l1ll1l1111ll_l1_.append(l1l11l1_l1_[l1l111_l1_ (u"ࠧࡓࡇࡓࡓࡘ࠭㞺")][1])
	if PY3: l1ll1l1111ll_l1_.append(l1l11l1_l1_[l1l111_l1_ (u"ࠨࡔࡈࡔࡔ࡙ࠧ㞻")][2])
	for l1ll11l1l1l1_l1_ in l1ll1l1111ll_l1_:
		response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭㞼"),l1ll11l1l1l1_l1_,l1l111_l1_ (u"ࠪࠫ㞽"),l1l111_l1_ (u"ࠫࠬ㞾"),l1l111_l1_ (u"ࠬ࠭㞿"),l1l111_l1_ (u"࠭ࠧ㟀"),l1l111_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡔࡈࡅࡉࡥࡁࡍࡎࡢࡅࡉࡊࡏࡏࡕࡢ࡜ࡒࡒ࠭࠲ࡵࡷࠫ㟁"))
		if response.succeeded:
			html = response.content
			l1l1lll11l1l_l1_ = l1ll11l1l1l1_l1_.rsplit(l1l111_l1_ (u"ࠨ࠱ࠪ㟂"),1)[0]
			l111l11l11l_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡬ࡨࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡸࡨࡶࡸ࡯࡯࡯࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ㟃"),html,re.DOTALL|re.IGNORECASE)
			for addon_id,l111ll11lll_l1_ in l111l11l11l_l1_:
				l11l11111ll_l1_ = l1l1lll11l1l_l1_+l1l111_l1_ (u"ࠪ࠳ࠬ㟄")+addon_id+l1l111_l1_ (u"ࠫ࠴࠭㟅")+addon_id+l1l111_l1_ (u"ࠬ࠳ࠧ㟆")+l111ll11lll_l1_+l1l111_l1_ (u"࠭࠮ࡻ࡫ࡳࠫ㟇")
				if addon_id not in list(l1ll11111l11_l1_.keys()):
					l1ll11111l11_l1_[addon_id] = []
					l111l111lll_l1_[addon_id] = []
				l1lll1l1llll_l1_ = l1l1ll1l11ll_l1_(l111ll11lll_l1_)
				l1ll11111l11_l1_[addon_id].append((l111ll11lll_l1_,l1lll1l1llll_l1_,l11l11111ll_l1_))
	for addon_id in list(l1ll11111l11_l1_.keys()):
		l111l111lll_l1_[addon_id] = sorted(l1ll11111l11_l1_[addon_id],reverse=True,key=lambda key: key[1])
	l1lll111111_l1_(main_dbfile,l1l111_l1_ (u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪ㟈"),l1l111_l1_ (u"ࠨࡃࡏࡐࡤࡇࡄࡅࡑࡑࡗࡤ࡞ࡍࡍࠩ㟉"),l111l111lll_l1_,l11l1l1_l1_)
	return l111l111lll_l1_
def l1l1ll1l11ll_l1_(l111ll11lll_l1_):
	l1lll1l1llll_l1_ = []
	l1llll11ll1_l1_ = l111ll11lll_l1_.split(l1l111_l1_ (u"ࠩ࠱ࠫ㟊"))
	for l1l1ll11l1_l1_ in l1llll11ll1_l1_:
		parts = re.findall(l1l111_l1_ (u"ࠪࡠࡩ࠱ࡼ࡜࡞࠮ࡠ࠲ࡧ࠭ࡻࡃ࠰࡞ࡢ࠱ࠧ㟋"),l1l1ll11l1_l1_,re.DOTALL)
		l1l1llll1lll_l1_ = []
		for part in parts:
			if part.isdigit(): part = int(part)
			l1l1llll1lll_l1_.append(part)
		l1lll1l1llll_l1_.append(l1l1llll1lll_l1_)
	return l1lll1l1llll_l1_
def l1lll111lll1_l1_(l1lll1l1llll_l1_):
	l111ll11lll_l1_ = l1l111_l1_ (u"ࠫࠬ㟌")
	for l1l1ll11l1_l1_ in l1lll1l1llll_l1_:
		for part in l1l1ll11l1_l1_: l111ll11lll_l1_ += str(part)
		l111ll11lll_l1_ += l1l111_l1_ (u"ࠬ࠴ࠧ㟍")
	l111ll11lll_l1_ = l111ll11lll_l1_.strip(l1l111_l1_ (u"࠭࠮ࠨ㟎"))
	return l111ll11lll_l1_
def l1llllll11ll_l1_(l11ll11ll11_l1_):
	l1l1lll11ll1_l1_ = {}
	l1ll11111l11_l1_ = l111lll1111_l1_()
	l11lll11l1l_l1_ = l1ll1ll1ll1l_l1_(l11ll11ll11_l1_)
	for addon_id in l11ll11ll11_l1_:
		if addon_id not in list(l1ll11111l11_l1_.keys()): continue
		l111l111lll_l1_ = l1ll11111l11_l1_[addon_id]
		l11ll1lll1l_l1_,l11ll1ll1ll_l1_,l1l1ll11l1l1_l1_ = l111l111lll_l1_[0]
		l1111ll1ll1_l1_,l11111lll11_l1_ = l1ll11lll1l1_l1_(addon_id)
		l11l1ll1lll_l1_,l1lllll11111_l1_ = l11lll11l1l_l1_[addon_id]
		l11llll1111_l1_ = l11ll1ll1ll_l1_>l11111lll11_l1_ and l11l1ll1lll_l1_
		l1l1ll11ll11_l1_ = True
		if not l11l1ll1lll_l1_: l1l11111l1l_l1_ = l1l111_l1_ (u"ࠧ࡮࡫ࡶࡷ࡮ࡴࡧࠨ㟏")
		elif not l1lllll11111_l1_: l1l11111l1l_l1_ = l1l111_l1_ (u"ࠨࡦ࡬ࡷࡦࡨ࡬ࡦࡦࠪ㟐")
		elif l11llll1111_l1_: l1l11111l1l_l1_ = l1l111_l1_ (u"ࠩࡲࡰࡩ࠭㟑")
		else:
			l1l11111l1l_l1_ = l1l111_l1_ (u"ࠪ࡫ࡴࡵࡤࠨ㟒")
			l1l1ll11ll11_l1_ = False
		l1l1lll11ll1_l1_[addon_id] = (l1l1ll11ll11_l1_,l1111ll1ll1_l1_,l11111lll11_l1_,l11ll1lll1l_l1_,l11ll1ll1ll_l1_,l1l11111l1l_l1_,l1l1ll11l1l1_l1_)
	return l1l1lll11ll1_l1_
def l1l111111l_l1_(l1l1111l1l_l1_,l1111l111l1_l1_,l11l111llll_l1_=l1l111_l1_ (u"ࠫࠬ㟓"),line2=l1l111_l1_ (u"ࠬ࠭㟔"),l11l11l111l_l1_=l1l111_l1_ (u"࠭ࠧ㟕")):
	if PY2: l1l1111l1l_l1_.update(l1111l111l1_l1_,l11l111llll_l1_,line2,l11l11l111l_l1_)
	else: l1l1111l1l_l1_.update(l1111l111l1_l1_,l11l111llll_l1_+l1l111_l1_ (u"ࠧ࡝ࡰࠪ㟖")+line2+l1l111_l1_ (u"ࠨ࡞ࡱࠫ㟗")+l11l11l111l_l1_)
	return
def l1ll1lll111l_l1_(l1llllllll1l_l1_):
	def l1lllll1l1ll_l1_(num,b,l1ll1l1ll11l_l1_=l1l111_l1_ (u"ࠤ࠳࠵࠷࠹࠴࠶࠸࠺࠼࠾ࡧࡢࡤࡦࡨࡪ࡬࡮ࡩ࡫࡭࡯ࡱࡳࡵࡰࡲࡴࡶࡸࡺࡼࡷࡹࡻࡽࡅࡇࡉࡄࡆࡈࡊࡌࡎࡐࡋࡍࡏࡑࡓࡕࡗࡒࡔࡖࡘ࡚࡜࡞࡙࡛ࠤ㟘")):
		return ((num == 0) and l1ll1l1ll11l_l1_[0]) or (l1lllll1l1ll_l1_(num // b, b, l1ll1l1ll11l_l1_).lstrip(l1ll1l1ll11l_l1_[0]) + l1ll1l1ll11l_l1_[num % b])
	def unpack(p, a, c, k, e=None, d=None):
		while (c):
			c-=1
			if (k[c]): p = re.sub(l1l111_l1_ (u"ࠥࡠࡡࡨࠢ㟙") + l1lllll1l1ll_l1_(c, a) + l1l111_l1_ (u"ࠦࡡࡢࡢࠣ㟚"),  k[c], p)
		return p
	l1llllllll1l_l1_ = l1llllllll1l_l1_.split(l1l111_l1_ (u"ࠬࢃࠨࠨ㟛"))[1][:-1]
	l1ll1l1l111l_l1_ = eval(l1l111_l1_ (u"࠭ࡵ࡯ࡲࡤࡧࡰ࠮ࠧ㟜")+l1llllllll1l_l1_,{l1l111_l1_ (u"ࠧࡣࡣࡶࡩࡓ࠭㟝"):l1lllll1l1ll_l1_,l1l111_l1_ (u"ࠨࡷࡱࡴࡦࡩ࡫ࠨ㟞"):unpack})
	return l1ll1l1l111l_l1_
def l111ll1l1ll_l1_(url,l1ll1lllll11_l1_=l1l111_l1_ (u"ࠩࠪ㟟")):
	if l1ll1lllll11_l1_==l1l111_l1_ (u"ࠪࡰࡴࡽࡥࡳࠩ㟠"): url = re.sub(l1l111_l1_ (u"ࡶ࡛ࠬࠫ࠱࠯࠼ࡅ࠲ࡠ࡝ࡼ࠴ࢀࠫ㟡"),lambda l11lllll111_l1_: l11lllll111_l1_.group(0).lower(),url)
	elif l1ll1lllll11_l1_==l1l111_l1_ (u"ࠬࡻࡰࡱࡧࡵࠫ㟢"): url = re.sub(l1l111_l1_ (u"ࡸࠧࠦ࡝࠳࠱࠾ࡧ࠭ࡻ࡟ࡾ࠶ࢂ࠭㟣"),lambda l11lllll111_l1_: l11lllll111_l1_.group(0).upper(),url)
	return url
def l1ll1ll1ll1l_l1_(l11ll11ll11_l1_):
	l111lll1l11_l1_,l11111l11ll_l1_ = False,False
	conn = sqlite3.connect(l111l1l11l1_l1_)
	conn.text_factory = str
	l1llll1lll_l1_ = conn.cursor()
	if len(l11ll11ll11_l1_)==1: l111ll1llll_l1_ = l1l111_l1_ (u"ࠧࠩࠤࠪ㟤")+l11ll11ll11_l1_[0]+l1l111_l1_ (u"ࠨࠤࠬࠫ㟥")
	else: l111ll1llll_l1_ = str(tuple(l11ll11ll11_l1_))
	l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠩࡖࡉࡑࡋࡃࡕࠢࡤࡨࡩࡵ࡮ࡊࡆ࠯ࡩࡳࡧࡢ࡭ࡧࡧࠤࡋࡘࡏࡎࠢ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨࠥ࡝ࡈࡆࡔࡈࠤࡦࡪࡤࡰࡰࡌࡈࠥࡏࡎࠡࠩ㟦")+l111ll1llll_l1_+l1l111_l1_ (u"ࠪࠤࡀ࠭㟧"))
	l1l1l1111l1_l1_ = l1llll1lll_l1_.fetchall()
	l11lll11l1l_l1_ = {}
	for addon_id in l11ll11ll11_l1_: l11lll11l1l_l1_[addon_id] = (False,False)
	for addon_id,l11111l11ll_l1_ in l1l1l1111l1_l1_:
		l111lll1l11_l1_ = True
		l11111l11ll_l1_ = l11111l11ll_l1_==1
		l11lll11l1l_l1_[addon_id] = (l111lll1l11_l1_,l11111l11ll_l1_)
	conn.close()
	return l11lll11l1l_l1_
def FIX_AND_GET_FILE_CONTENTS(file):
	l1lll_l1_ = l1l111_l1_ (u"ࠫࠬ㟨")
	if file==l1l1ll1l1l11_l1_: status = l11111l11l1_l1_(True,False)
	if os.path.exists(file):
		l1l11ll1ll1_l1_ = open(file,l1l111_l1_ (u"ࠬࡸࡢࠨ㟩")).read()
		if PY3: l1l11ll1ll1_l1_ = l1l11ll1ll1_l1_.decode(l1l111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ㟪"))
		if file==l1l1ll1l1l11_l1_: l1lll_l1_ = l1l11ll1ll1_l1_
		else:
			l1111lll1l1_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠧࡥ࡫ࡦࡸࠬ㟫"),l1l11ll1ll1_l1_)
			if l1111lll1l1_l1_:
				l1lll_l1_ = {}
				for key in l1111lll1l1_l1_.keys():
					l1lll_l1_[key] = []
					for l1llllll1l11_l1_ in l1111lll1l1_l1_[key]:
						type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll111_l1_ = l1l111_l1_ (u"ࠨࠩ㟬"),l1l111_l1_ (u"ࠩࠪ㟭"),l1l111_l1_ (u"ࠪࠫ㟮"),l1l111_l1_ (u"ࠫࠬ㟯"),l1l111_l1_ (u"ࠬ࠭㟰"),l1l111_l1_ (u"࠭ࠧ㟱"),l1l111_l1_ (u"ࠧࠨ㟲"),l1l111_l1_ (u"ࠨࠩ㟳"),l1l111_l1_ (u"ࠩࠪ㟴")
						type = l1llllll1l11_l1_[0]
						name = l1llllll1l11_l1_[1]
						name = l11lll11lll_l1_(name)
						url = l1llllll1l11_l1_[2]
						mode = l1llllll1l11_l1_[3]
						l11l_l1_ = l1llllll1l11_l1_[4]
						l1llllll1_l1_ = l1llllll1l11_l1_[5]
						if len(l1llllll1l11_l1_)>6: text = l1llllll1l11_l1_[6]
						if len(l1llllll1l11_l1_)>7: context = l1llllll1l11_l1_[7]
						if len(l1llllll1l11_l1_)>8: l1llllll111_l1_ = l1llllll1l11_l1_[8]
						if file==favoritesfile: l1l1lll1llll_l1_ = type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,l1l111_l1_ (u"ࠪࠫ㟵"),l1llllll111_l1_
						else: l1l1lll1llll_l1_ = type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll111_l1_
						l1lll_l1_[key].append(l1l1lll1llll_l1_)
			l1l11l1l1ll_l1_ = str(l1lll_l1_)
			if PY3: l1l11l1l1ll_l1_ = l1l11l1l1ll_l1_.encode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㟶"))
			open(file,l1l111_l1_ (u"ࠬࡽࡢࠨ㟷")).write(l1l11l1l1ll_l1_)
	return l1lll_l1_
def l1ll1llll11_l1_(l1lll11l1l1_l1_):
	l1lll1l1111l_l1_ = l1lll11l1l1_l1_.split(l1l111_l1_ (u"࠭࠭ࠨ㟸"),1)[0]
	l1lll11111l_l1_,l1lll11l11l_l1_,l1llll11111_l1_ = l1l111_l1_ (u"ࠧࠨ㟹"),l1l111_l1_ (u"ࠨࠩ㟺"),l1l111_l1_ (u"ࠩࠪ㟻")
	if   l1lll1l1111l_l1_==l1l111_l1_ (u"ࠪࡅࡍ࡝ࡁࡌࠩ㟼")		:	from l1l1ll1_l1_			import l1l1l11_l1_ as l1lll11111l_l1_,l1lll1_l1_ as l1lll11l11l_l1_,l1lllll_l1_ as l1llll11111_l1_
	elif l1lll1l1111l_l1_==l1l111_l1_ (u"ࠫࡆࡑࡏࡂࡏࠪ㟽")		:	from l11l111_l1_			import l1l1l11_l1_ as l1lll11111l_l1_,l1lll1_l1_ as l1lll11l11l_l1_,l1lllll_l1_ as l1llll11111_l1_
	elif l1lll1l1111l_l1_==l1l111_l1_ (u"ࠬࡇࡋࡐࡃࡐࡇࡆࡓࠧ㟾")	:	from l1l1111l_l1_		import l1l1l11_l1_ as l1lll11111l_l1_,l1lll1_l1_ as l1lll11l11l_l1_,l1lllll_l1_ as l1llll11111_l1_
	elif l1lll1l1111l_l1_==l1l111_l1_ (u"࠭ࡁࡌ࡙ࡄࡑࠬ㟿")		:	from l1ll1l1l_l1_			import l1l1l11_l1_ as l1lll11111l_l1_,l1lll1_l1_ as l1lll11l11l_l1_,l1lllll_l1_ as l1llll11111_l1_
	elif l1lll1l1111l_l1_==l1l111_l1_ (u"ࠧࡂࡎࡄࡖࡆࡈࠧ㠀")	:	from l1111l11_l1_			import l1l1l11_l1_ as l1lll11111l_l1_,l1lll1_l1_ as l1lll11l11l_l1_,l1lllll_l1_ as l1llll11111_l1_
	elif l1lll1l1111l_l1_==l1l111_l1_ (u"ࠨࡃࡏࡊࡆ࡚ࡉࡎࡋࠪ㠁")	:	from l1lll1ll1_l1_		import l1l1l11_l1_ as l1lll11111l_l1_,l1lll1_l1_ as l1lll11l11l_l1_,l1lllll_l1_ as l1llll11111_l1_
	elif l1lll1l1111l_l1_==l1l111_l1_ (u"ࠩࡄࡐࡐࡇࡗࡕࡊࡄࡖࠬ㠂")	: 	from l1ll1l1l1_l1_		import l1l1l11_l1_ as l1lll11111l_l1_,l1lll1_l1_ as l1lll11l11l_l1_,l1lllll_l1_ as l1llll11111_l1_
	elif l1lll1l1111l_l1_==l1l111_l1_ (u"ࠪࡅࡑࡓࡁࡂࡔࡈࡊࠬ㠃")	:	from l1ll11lll_l1_		import l1l1l11_l1_ as l1lll11111l_l1_,l1lll1_l1_ as l1lll11l11l_l1_,l1lllll_l1_ as l1llll11111_l1_
	elif l1lll1l1111l_l1_==l1l111_l1_ (u"ࠫࡆࡘࡁࡃࡋࡆࡘࡔࡕࡎࡔࠩ㠄"):	from l1ll1111l_l1_	import l1l1l11_l1_ as l1lll11111l_l1_,l1lll1_l1_ as l1lll11l11l_l1_,l1lllll_l1_ as l1llll11111_l1_
	elif l1lll1l1111l_l1_==l1l111_l1_ (u"ࠬࡇࡒࡂࡄࡖࡉࡊࡊࠧ㠅")	:	from l1l11l111_l1_		import l1l1l11_l1_ as l1lll11111l_l1_,l1lll1_l1_ as l1lll11l11l_l1_,l1lllll_l1_ as l1llll11111_l1_
	elif l1lll1l1111l_l1_==l1l111_l1_ (u"࠭ࡂࡐࡍࡕࡅࠬ㠆")		:	from l11l1ll1l_l1_			import l1l1l11_l1_ as l1lll11111l_l1_,l1lll1_l1_ as l1lll11l11l_l1_,l1lllll_l1_ as l1llll11111_l1_
	elif l1lll1l1111l_l1_==l1l111_l1_ (u"ࠧࡃࡔࡖࡘࡊࡐࠧ㠇")	:	from l11l11ll1_l1_			import l1l1l11_l1_ as l1lll11111l_l1_,l1lll1_l1_ as l1lll11l11l_l1_,l1lllll_l1_ as l1llll11111_l1_
	elif l1lll1l1111l_l1_==l1l111_l1_ (u"ࠨࡅࡌࡑࡆ࠺࠰࠱ࠩ㠈")	:	from l11l11l1l_l1_		import l1l1l11_l1_ as l1lll11111l_l1_,l1lll1_l1_ as l1lll11l11l_l1_,l1lllll_l1_ as l1llll11111_l1_
	elif l1lll1l1111l_l1_==l1l111_l1_ (u"ࠩࡆࡍࡒࡇ࠴ࡖࠩ㠉")	:	from l11l111ll_l1_			import l1l1l11_l1_ as l1lll11111l_l1_,l1lll1_l1_ as l1lll11l11l_l1_,l1lllll_l1_ as l1llll11111_l1_
	elif l1lll1l1111l_l1_==l1l111_l1_ (u"ࠪࡇࡎࡓࡁࡂࡄࡇࡓࠬ㠊")	:	from l111l1l11_l1_		import l1l1l11_l1_ as l1lll11111l_l1_,l1lll1_l1_ as l1lll11l11l_l1_,l1lllll_l1_ as l1llll11111_l1_
	elif l1lll1l1111l_l1_==l1l111_l1_ (u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࡝ࡏࡓࡍࠪ㠋"):	from l11111ll1_l1_	import l1l1l11_l1_ as l1lll11111l_l1_,l1lll1_l1_ as l1lll11l11l_l1_,l1lllll_l1_ as l1llll11111_l1_
	elif l1lll1l1111l_l1_==l1l111_l1_ (u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡈࠧ㠌"):		from l1111ll11_l1_		import l1l1l11_l1_ as l1lll11111l_l1_,l1lll1_l1_ as l1lll11l11l_l1_,l1lllll_l1_ as l1llll11111_l1_
	elif l1lll1l1111l_l1_==l1l111_l1_ (u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡐࠨ㠍")	:	from l11111l1l_l1_		import l1l1l11_l1_ as l1lll11111l_l1_,l1lll1_l1_ as l1lll11l11l_l1_,l1lllll_l1_ as l1llll11111_l1_
	elif l1lll1l1111l_l1_==l1l111_l1_ (u"ࠧࡄࡋࡐࡅࡋࡇࡎࡔࠩ㠎")	:	from l111111l1_l1_		import l1l1l11_l1_ as l1lll11111l_l1_,l1lll1_l1_ as l1lll11l11l_l1_,l1lllll_l1_ as l1llll11111_l1_
	elif l1lll1l1111l_l1_==l1l111_l1_ (u"ࠨࡅࡌࡑࡆࡒࡉࡈࡊࡗࠫ㠏")	:	from l11111111_l1_		import l1l1l11_l1_ as l1lll11111l_l1_,l1lll1_l1_ as l1lll11l11l_l1_,l1lllll_l1_ as l1llll11111_l1_
	elif l1lll1l1111l_l1_==l1l111_l1_ (u"ࠩࡆࡍࡒࡇࡎࡐ࡙ࠪ㠐")	:	from l1lllllll1_l1_		import l1l1l11_l1_ as l1lll11111l_l1_,l1lll1_l1_ as l1lll11l11l_l1_,l1lllll_l1_ as l1llll11111_l1_
	elif l1lll1l1111l_l1_==l1l111_l1_ (u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎࠨ㠑"):	from l1l1l111l1_l1_	import l1l1l11_l1_ as l1lll11111l_l1_,l1lll1_l1_ as l1lll11l11l_l1_,l1lllll_l1_ as l1llll11111_l1_
	elif l1lll1l1111l_l1_==l1l111_l1_ (u"ࠫࡉࡘࡁࡎࡃࡖ࠻ࠬ㠒")	:	from l11ll11l11_l1_		import l1l1l11_l1_ as l1lll11111l_l1_,l1lll1_l1_ as l1lll11l11l_l1_,l1lllll_l1_ as l1llll11111_l1_
	elif l1lll1l1111l_l1_==l1l111_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠭㠓")	:	from l11l11l111_l1_		import l1l1l11_l1_ as l1lll11111l_l1_,l1lll1_l1_ as l1lll11l11l_l1_,l1lllll_l1_ as l1llll11111_l1_
	elif l1lll1l1111l_l1_==l1l111_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠱ࠨ㠔")	:	from l111lll11l_l1_		import l1l1l11_l1_ as l1lll11111l_l1_,l1lll1_l1_ as l1lll11l11l_l1_,l1lllll_l1_ as l1llll11111_l1_
	elif l1lll1l1111l_l1_==l1l111_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠳ࠩ㠕")	:	from l111ll111l_l1_		import l1l1l11_l1_ as l1lll11111l_l1_,l1lll1_l1_ as l1lll11l11l_l1_,l1lllll_l1_ as l1llll11111_l1_
	elif l1lll1l1111l_l1_==l1l111_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠵ࠪ㠖")	:	from l111l1llll_l1_		import l1l1l11_l1_ as l1lll11111l_l1_,l1lll1_l1_ as l1lll11l11l_l1_,l1lllll_l1_ as l1llll11111_l1_
	elif l1lll1l1111l_l1_==l1l111_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠷ࠫ㠗")	:	from l111l1l1l1_l1_		import l1l1l11_l1_ as l1lll11111l_l1_,l1lll1_l1_ as l1lll11l11l_l1_,l1lllll_l1_ as l1llll11111_l1_
	elif l1lll1l1111l_l1_==l1l111_l1_ (u"ࠪࡉࡌ࡟ࡄࡆࡃࡇࠫ㠘")	:	from l111l11111_l1_		import l1l1l11_l1_ as l1lll11111l_l1_,l1lll1_l1_ as l1lll11l11l_l1_,l1lllll_l1_ as l1llll11111_l1_
	elif l1lll1l1111l_l1_==l1l111_l1_ (u"ࠫࡊࡍ࡙ࡏࡑ࡚ࠫ㠙")	:	from l1111lllll_l1_			import l1l1l11_l1_ as l1lll11111l_l1_,l1lll1_l1_ as l1lll11l11l_l1_,l1lllll_l1_ as l1llll11111_l1_
	elif l1lll1l1111l_l1_==l1l111_l1_ (u"ࠬࡌࡁࡃࡔࡄࡏࡆ࠭㠚")	:	from l1lllll111l_l1_		import l1l1l11_l1_ as l1lll11111l_l1_,l1lll1_l1_ as l1lll11l11l_l1_,l1lllll_l1_ as l1llll11111_l1_
	elif l1lll1l1111l_l1_==l1l111_l1_ (u"࠭ࡆࡂࡌࡈࡖࡘࡎࡏࡘࠩ㠛")	:	from l1llll1ll1l_l1_		import l1l1l11_l1_ as l1lll11111l_l1_,l1lll1_l1_ as l1lll11l11l_l1_,l1lllll_l1_ as l1llll11111_l1_
	elif l1lll1l1111l_l1_==l1l111_l1_ (u"ࠧࡇࡃࡖࡉࡑࡎࡄ࠲ࠩ㠜")	:	from l1llll1l11l_l1_		import l1l1l11_l1_ as l1lll11111l_l1_,l1lll1_l1_ as l1lll11l11l_l1_,l1lllll_l1_ as l1llll11111_l1_
	elif l1lll1l1111l_l1_==l1l111_l1_ (u"ࠨࡈࡄࡗࡊࡒࡈࡅ࠴ࠪ㠝")	:	from l1llll11l11_l1_		import l1l1l11_l1_ as l1lll11111l_l1_,l1lll1_l1_ as l1lll11l11l_l1_,l1lllll_l1_ as l1llll11111_l1_
	elif l1lll1l1111l_l1_==l1l111_l1_ (u"ࠩࡉࡓࡘ࡚ࡁࠨ㠞")		:	from l1llll111l1_l1_			import l1l1l11_l1_ as l1lll11111l_l1_,l1lll1_l1_ as l1lll11l11l_l1_,l1lllll_l1_ as l1llll11111_l1_
	elif l1lll1l1111l_l1_==l1l111_l1_ (u"ࠪࡌࡆࡒࡁࡄࡋࡐࡅࠬ㠟")	:	from l1ll1ll1lll_l1_		import l1l1l11_l1_ as l1lll11111l_l1_,l1lll1_l1_ as l1lll11l11l_l1_,l1lllll_l1_ as l1llll11111_l1_
	elif l1lll1l1111l_l1_==l1l111_l1_ (u"ࠫࡎࡌࡉࡍࡏࠪ㠠")		:	from l1ll1ll1ll1_l1_			import l1l1l11_l1_ as l1lll11111l_l1_,l1lll1_l1_ as l1lll11l11l_l1_,l1lllll_l1_ as l1llll11111_l1_
	elif l1lll1l1111l_l1_==l1l111_l1_ (u"ࠬࡏࡐࡕࡘࠪ㠡")		:	from IPTV			import MENUu as l1lll11111l_l1_,SEARCHh as l1lll11l11l_l1_,menu_namee as l1llll11111_l1_
	elif l1lll1l1111l_l1_==l1l111_l1_ (u"࠭ࡋࡂࡔࡅࡅࡑࡇࡔࡗࠩ㠢")	:	from l1ll11llll1_l1_		import l1l1l11_l1_ as l1lll11111l_l1_,l1lll1_l1_ as l1lll11l11l_l1_,l1lllll_l1_ as l1llll11111_l1_
	elif l1lll1l1111l_l1_==l1l111_l1_ (u"ࠧࡌࡃࡗࡏࡔ࡚ࡔࡗࠩ㠣")	:	from l1ll11lll1l_l1_		import l1l1l11_l1_ as l1lll11111l_l1_,l1lll1_l1_ as l1lll11l11l_l1_,l1lllll_l1_ as l1llll11111_l1_
	elif l1lll1l1111l_l1_==l1l111_l1_ (u"ࠨࡍࡄࡘࡐࡕࡕࡕࡇࠪ㠤")	:	from l1ll11ll1l1_l1_		import l1l1l11_l1_ as l1lll11111l_l1_,l1lll1_l1_ as l1lll11l11l_l1_,l1lllll_l1_ as l1llll11111_l1_
	elif l1lll1l1111l_l1_==l1l111_l1_ (u"ࠩࡏࡅࡗࡕ࡚ࡂࠩ㠥")	:	from l1ll111l1ll_l1_			import l1l1l11_l1_ as l1lll11111l_l1_,l1lll1_l1_ as l1lll11l11l_l1_,l1lllll_l1_ as l1llll11111_l1_
	elif l1lll1l1111l_l1_==l1l111_l1_ (u"ࠪࡐࡔࡊ࡙ࡏࡇࡗࠫ㠦")	:	from l1l11111111_l1_		import l1l1l11_l1_ as l1lll11111l_l1_,l1lll1_l1_ as l1lll11l11l_l1_,l1lllll_l1_ as l1llll11111_l1_
	elif l1lll1l1111l_l1_==l1l111_l1_ (u"ࠫࡒ࠹ࡕࠨ㠧")		:	from M3U			import MENUu as l1lll11111l_l1_,SEARCHh as l1lll11l11l_l1_,menu_namee as l1llll11111_l1_
	elif l1lll1l1111l_l1_==l1l111_l1_ (u"ࠬࡓࡏࡗࡕ࠷࡙ࠬ㠨")	:	from l1ll1ll11111_l1_			import l1l1l11_l1_ as l1lll11111l_l1_,l1lll1_l1_ as l1lll11l11l_l1_,l1lllll_l1_ as l1llll11111_l1_
	elif l1lll1l1111l_l1_==l1l111_l1_ (u"࠭ࡍ࡚ࡅࡌࡑࡆ࠭㠩")	:	from l1lll11lll11_l1_			import l1l1l11_l1_ as l1lll11111l_l1_,l1lll1_l1_ as l1lll11l11l_l1_,l1lllll_l1_ as l1llll11111_l1_
	elif l1lll1l1111l_l1_==l1l111_l1_ (u"ࠧࡑࡃࡑࡉ࡙࠭㠪")		:	from l11l11l1l11_l1_			import l1l1l11_l1_ as l1lll11111l_l1_,l1lll1_l1_ as l1lll11l11l_l1_,l1lllll_l1_ as l1llll11111_l1_
	elif l1lll1l1111l_l1_==l1l111_l1_ (u"ࠨࡕࡋࡅࡍࡏࡄ࠵ࡗࠪ㠫")	:	from l1ll11ll1l11_l1_		import l1l1l11_l1_ as l1lll11111l_l1_,l1lll1_l1_ as l1lll11l11l_l1_,l1lllll_l1_ as l1llll11111_l1_
	elif l1lll1l1111l_l1_==l1l111_l1_ (u"ࠩࡖࡌࡆࡎࡉࡅࡐࡈ࡛ࡘ࠭㠬"):	from l11ll1l1lll_l1_		import l1l1l11_l1_ as l1lll11111l_l1_,l1lll1_l1_ as l1lll11l11l_l1_,l1lllll_l1_ as l1llll11111_l1_
	elif l1lll1l1111l_l1_==l1l111_l1_ (u"ࠪࡗࡍࡏࡁࡗࡑࡌࡇࡊ࠭㠭")	:	from l11l11ll1ll_l1_		import l1l1l11_l1_ as l1lll11111l_l1_,l1lll1_l1_ as l1lll11l11l_l1_,l1lllll_l1_ as l1llll11111_l1_
	elif l1lll1l1111l_l1_==l1l111_l1_ (u"ࠫࡘࡎࡏࡇࡊࡄࠫ㠮")	:	from l1111ll111l_l1_			import l1l1l11_l1_ as l1lll11111l_l1_,l1lll1_l1_ as l1lll11l11l_l1_,l1lllll_l1_ as l1llll11111_l1_
	elif l1lll1l1111l_l1_==l1l111_l1_ (u"࡙ࠬࡈࡐࡑࡉࡑࡆ࡞ࠧ㠯")	:	from l11llll111l_l1_		import l1l1l11_l1_ as l1lll11111l_l1_,l1lll1_l1_ as l1lll11l11l_l1_,l1lllll_l1_ as l1llll11111_l1_
	elif l1lll1l1111l_l1_==l1l111_l1_ (u"࠭ࡓࡉࡑࡒࡊࡕࡘࡏࠨ㠰")	:	from l1ll111l1l1l_l1_		import l1l1l11_l1_ as l1lll11111l_l1_,l1lll1_l1_ as l1lll11l11l_l1_,l1lllll_l1_ as l1llll11111_l1_
	elif l1lll1l1111l_l1_==l1l111_l1_ (u"ࠧࡕࡘࡉ࡙ࡓ࠭㠱")		:	from l111111lll1_l1_			import l1l1l11_l1_ as l1lll11111l_l1_,l1lll1_l1_ as l1lll11l11l_l1_,l1lllll_l1_ as l1llll11111_l1_
	elif l1lll1l1111l_l1_==l1l111_l1_ (u"ࠨ࡙ࡈࡇࡎࡓࡁࠨ㠲")	:	from l1ll11llll11_l1_			import l1l1l11_l1_ as l1lll11111l_l1_,l1lll1_l1_ as l1lll11l11l_l1_,l1lllll_l1_ as l1llll11111_l1_
	elif l1lll1l1111l_l1_==l1l111_l1_ (u"ࠩ࡜ࡅࡖࡕࡔࠨ㠳")		:	from l11lll1l111_l1_			import l1l1l11_l1_ as l1lll11111l_l1_,l1lll1_l1_ as l1lll11l11l_l1_,l1lllll_l1_ as l1llll11111_l1_
	elif l1lll1l1111l_l1_==l1l111_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫ㠴")	:	from l11lll111ll_l1_		import l1l1l11_l1_ as l1lll11111l_l1_,l1lll1_l1_ as l1lll11l11l_l1_,l1lllll_l1_ as l1llll11111_l1_
	elif l1lll1l1111l_l1_==l1l111_l1_ (u"ࠫ࡞࡚ࡂࡠࡅࡋࡅࡓࡔࡅࡍࡕࠪ㠵"):	from l11ll11l11l_l1_	import l1l1l11_l1_ as l1lll11111l_l1_
	return l1lll11111l_l1_,l1lll11l11l_l1_,l1llll11111_l1_
def l1llll111lll_l1_(l1l1ll11l1ll_l1_,headers,l11_l1_):
	l11llllll1_l1_(l1l111_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ㠶"),l1l111_l1_ (u"࠭࠮ࠡࠢࡇࡳࡼࡴ࡬ࡰࡣࡧ࡭ࡳ࡭࠺ࠡ࡝ࠣࠫ㠷")+l1l1ll11l1ll_l1_+l1l111_l1_ (u"ࠧࠡ࡟ࠣࠤࠥࡎࡥࡢࡦࡨࡶࡸࡀࠠ࡜ࠢࠪ㠸")+str(headers)+l1l111_l1_ (u"ࠨࠢࡠࠫ㠹"))
	l1l1111l1l_l1_ = l1l111ll1l_l1_()
	l1l1111l1l_l1_.create(l1l111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㠺"),l1l111_l1_ (u"ࠪ๎ัื๊ࠡษ็ฦ๋ࠦแฮืࠣห้๋ไโࠢส่๊฽ไ้สࠣฮา๋๊ๅ้ࠣ์อ฿ฯ่ษࠣืํ็ࠠหสาวࠥ฿ๅๅ์ฬࠤั๊ศࠡษ็้้็ࠠๆ่ࠣห้หๆหำ้ฮࠬ㠻"))
	l1l11l11l1_l1_ = 1024*1024
	chunksize = 1*l1l11l11l1_l1_
	from requests import get
	response = get(l1l1ll11l1ll_l1_,stream=True,headers=headers)
	l1ll111l1l11_l1_ = response.headers
	response.close()
	l1ll1111ll1l_l1_ = bytes()
	if not l1ll111l1l11_l1_:
		if l11_l1_: l1111l1_l1_(l1l111_l1_ (u"ࠫࠬ㠼"),l1l111_l1_ (u"ࠬ࠭㠽"),l1l111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ㠾"),l1l111_l1_ (u"ࠧศๆหี๋อๅอࠢ็้ࠥ๐สๆๅ้ࠤ๊์ࠠหฯ่๎้ࠦวๅ็็ๅࠥอไๆู็์อ่ࠦศๆึฬอࠦโะࠢํ็ํ์ฺ่ࠠา็๋ࠥิไๆฬࠤๆ๐ࠠศๆศ๊ฯืๆหࠢส่ำอีࠡสๆࠤ࠳ࠦฬาสࠣฮา๋๊ๅࠢส่๊๊แࠡ็ิอࠥษฮา๋ࠪ㠿"))
		l1l1111l1l_l1_.close()
	else:
		if l1l111_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡏࡩࡳ࡭ࡴࡩࠩ㡀") not in list(l1ll111l1l11_l1_.keys()): filesize = 0
		else: filesize = int(l1ll111l1l11_l1_[l1l111_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡐࡪࡴࡧࡵࡪࠪ㡁")])
		l1l111ll11_l1_ = str(int(1000*filesize/l1l11l11l1_l1_)/1000.0)
		l11lll1l1l_l1_ = int(filesize/chunksize)+1
		if l1l111_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱ࡗࡧ࡮ࡨࡧࠪ㡂") in list(l1ll111l1l11_l1_.keys()) and filesize>l1l11l11l1_l1_:
			l1ll11l1ll11_l1_ = True
			ranges = []
			l11l1llll1l_l1_ = 10
			ranges.append(str(0*filesize//l11l1llll1l_l1_)+l1l111_l1_ (u"ࠫ࠲࠭㡃")+str(1*filesize//l11l1llll1l_l1_-1))
			ranges.append(str(1*filesize//l11l1llll1l_l1_)+l1l111_l1_ (u"ࠬ࠳ࠧ㡄")+str(2*filesize//l11l1llll1l_l1_-1))
			ranges.append(str(2*filesize//l11l1llll1l_l1_)+l1l111_l1_ (u"࠭࠭ࠨ㡅")+str(3*filesize//l11l1llll1l_l1_-1))
			ranges.append(str(3*filesize//l11l1llll1l_l1_)+l1l111_l1_ (u"ࠧ࠮ࠩ㡆")+str(4*filesize//l11l1llll1l_l1_-1))
			ranges.append(str(4*filesize//l11l1llll1l_l1_)+l1l111_l1_ (u"ࠨ࠯ࠪ㡇")+str(5*filesize//l11l1llll1l_l1_-1))
			ranges.append(str(5*filesize//l11l1llll1l_l1_)+l1l111_l1_ (u"ࠩ࠰ࠫ㡈")+str(6*filesize//l11l1llll1l_l1_-1))
			ranges.append(str(6*filesize//l11l1llll1l_l1_)+l1l111_l1_ (u"ࠪ࠱ࠬ㡉")+str(7*filesize//l11l1llll1l_l1_-1))
			ranges.append(str(7*filesize//l11l1llll1l_l1_)+l1l111_l1_ (u"ࠫ࠲࠭㡊")+str(8*filesize//l11l1llll1l_l1_-1))
			ranges.append(str(8*filesize//l11l1llll1l_l1_)+l1l111_l1_ (u"ࠬ࠳ࠧ㡋")+str(9*filesize//l11l1llll1l_l1_-1))
			ranges.append(str(9*filesize//l11l1llll1l_l1_)+l1l111_l1_ (u"࠭࠭ࠨ㡌"))
			l11ll1l1l1l_l1_ = float(l11lll1l1l_l1_)/l11l1llll1l_l1_
			l11111111l1_l1_ = l11ll1l1l1l_l1_/int(1+l11ll1l1l1l_l1_)
		else:
			l1ll11l1ll11_l1_ = False
			l11l1llll1l_l1_ = 1
			l11111111l1_l1_ = 1
		l11llllll1_l1_(l1l111_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㡍"),l1l111_l1_ (u"ࠨ࠰ࠣࠤࡉࡵࡷ࡯࡮ࡲࡥࡩࠦࡵࡴ࡫ࡱ࡫ࠥࡸࡡ࡯ࡩࡨࡷ࠿࡛ࠦࠡࠩ㡎")+str(l1ll11l1ll11_l1_)+l1l111_l1_ (u"ࠩࠣࡡࠥࠦࠠࡅࡱࡺࡲࡱࡵࡡࡥࠢࡶ࡭ࡿ࡫࠺ࠡ࡝ࠣࠫ㡏")+str(filesize)+l1l111_l1_ (u"ࠪࠤࡢ࠭㡐"))
		l1l111lll1_l1_,l1ll11ll1ll1_l1_ = 0,0
		for l1lll1l11lll_l1_ in range(l11l1llll1l_l1_):
			l1ll1ll1l_l1_ = headers.copy()
			if l1ll11l1ll11_l1_: l1ll1ll1l_l1_[l1l111_l1_ (u"ࠫࡗࡧ࡮ࡨࡧࠪ㡑")] = l1l111_l1_ (u"ࠬࡨࡹࡵࡧࡶࡁࠬ㡒")+ranges[l1lll1l11lll_l1_]
			response = get(l1l1ll11l1ll_l1_,stream=True,headers=l1ll1ll1l_l1_,timeout=300)
			for chunk in response.iter_content(chunk_size=chunksize):
				if l1l1111l1l_l1_.iscanceled():
					l11llllll1_l1_(l1l111_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭㡓"),l1l111_l1_ (u"ࠧ࠯ࠢࠣࡈࡴࡽ࡮࡭ࡱࡤࡨࠥࡉࡡ࡯ࡥࡨࡰࡪࡪࠧ㡔"))
					break
				l1l111lll1_l1_ += l11111111l1_l1_
				l1ll1111ll1l_l1_ += chunk
				if not l1ll11ll1ll1_l1_: l1ll11ll1ll1_l1_ = len(chunk)
				if filesize: l1l111111l_l1_(l1l1111l1l_l1_,100*l1l111lll1_l1_//l11lll1l1l_l1_,l1l111_l1_ (u"ࠨฮ็ฬࠥอไๆๆไ࠾࠲ࠦวๅฮีลࠥืโๆࠩ㡕"),str(100.0*l1ll11ll1ll1_l1_*l1l111lll1_l1_//chunksize//100.0)+l1l111_l1_ (u"ࠩࠣ࠳ࠥ࠭㡖")+l1l111ll11_l1_+l1l111_l1_ (u"ࠪࠤࡒࡈࠧ㡗"))
				else: l1l111111l_l1_(l1l1111l1l_l1_,l1ll11ll1ll1_l1_*l1l111lll1_l1_//chunksize,l1l111_l1_ (u"ࠫั๊ศࠡษ็้้็࠺࠮ࠩ㡘"),str(100.0*l1ll11ll1ll1_l1_*l1l111lll1_l1_//chunksize//100.0)+l1l111_l1_ (u"ࠬࠦࡍࡃࠩ㡙"))
			response.close()
		l1l1111l1l_l1_.close()
		if len(l1ll1111ll1l_l1_)<filesize and filesize>0:
			l11llllll1_l1_(l1l111_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭㡚"),l1l111_l1_ (u"ࠧ࠯ࠢࠣࡈࡴࡽ࡮࡭ࡱࡤࡨࠥ࡬ࡡࡪ࡮ࡨࡨࠥࡵࡲࠡࡥࡤࡲࡨ࡫࡬ࡦࡦࠣࡥࡹࡀࠠ࡜ࠢࠪ㡛")+str(len(l1ll1111ll1l_l1_)//l1l11l11l1_l1_)+l1l111_l1_ (u"ࠨࠢࡐࡆࠥࡣࠠࠡࠢࡉࡶࡴࡳࠠࡵࡱࡷࡥࡱࠦ࡯ࡧ࠼ࠣ࡟ࠥ࠭㡜")+l1l111ll11_l1_+l1l111_l1_ (u"ࠩࠣࡑࡇࠦ࡝ࠨ㡝"))
			l111llll11l_l1_ = l1l1lll11111_l1_(l1l111_l1_ (u"ࠪࠫ㡞"),l1l111_l1_ (u"ࠫสฺ๊ศรࠣ์ำื่อࠩ㡟"),l1l111_l1_ (u"ࠬอำหะาห๊ࠦวๅ็็ๅࠥอไ็ษๅูࠬ㡠"),l1l111_l1_ (u"࠭ลฺษาอࠥาไษࠢส่๊๊แࠨ㡡"),l1l111_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ㡢"),l1l111_l1_ (u"ࠨใื่ࠥ็๊ࠡฮ็ฬࠥอไๆๆไࠤࡡࡴࠠๅๆฦืๆࠦอะอࠣา฼ษࠠโ์ࠣฮา๋๊ๅࠢส่๊๊แࠡ࡞ࡱࠤฯ๋ࠠอๆหࠤࠬ㡣")+str(len(l1ll1111ll1l_l1_)//l1l11l11l1_l1_)+l1l111_l1_ (u"้ࠩࠣ๏เวษษํฮ๋ࠥๆࠡ็ฯ้ํ฿ࠠࠨ㡤")+l1l111ll11_l1_+l1l111_l1_ (u"ࠪࠤ๊๐ฺศสส๎ฯࠦ࡜࡯ࠢฯีอࠦฬๅสࠣห้๋ไโ่ࠢีฮࠦรฯำ์ࠤࡡࡴ่ࠠๆࠣฮึ๐ฯࠡษึฮำีวๆࠢส่๊๊แࠡษ็๊ฬ่ีࠡมࠤࠥࠬ㡥"))
			if l111llll11l_l1_==2: l1ll1111ll1l_l1_ = l1llll111lll_l1_(l1l1ll11l1ll_l1_,headers,l11_l1_)
			elif l111llll11l_l1_==1: l11llllll1_l1_(l1l111_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ㡦"),l1l111_l1_ (u"ࠬ࠴ࠠࠡࡐࡲࡸࠥࡩ࡯࡮ࡲ࡯ࡩࡹ࡫ࡤࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࡨࡨࠥ࡬ࡩ࡭ࡧࠣ࡭ࡸࠦࡡࡤࡥࡨࡴࡹ࡫ࡤࠡࡣࡱࡨࠥࡽࡩ࡭࡮ࠣࡦࡪࠦࡵࡴࡧࡧࠫ㡧"))
			else: return l1l111_l1_ (u"࠭ࠧ㡨")
			if not l1ll1111ll1l_l1_: return l1l111_l1_ (u"ࠧࠨ㡩")
		else: l11llllll1_l1_(l1l111_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ㡪"),l1l111_l1_ (u"ࠩ࠱ࠤࠥࡊ࡯ࡸࡰ࡯ࡳࡦࡪࠠࡔࡷࡦࡧࡪ࡫ࡤࡦࡦ࠱ࠤࠥࠦࡆࡪ࡮ࡨࠤࡘ࡯ࡺࡦ࠼ࠣ࡟ࠥ࠭㡫")+l1l111ll11_l1_+l1l111_l1_ (u"ࠪࠤࡒࡈࠠ࡞ࠩ㡬"))
	return l1ll1111ll1l_l1_
def l1111111ll1_l1_(l1ll1_l1_):
	return response
def l111lllllll_l1_(l1ll1ll1l1ll_l1_=l1l111_l1_ (u"ࠫࠬ㡭")):
	l1ll11ll11ll_l1_ = l1lll11l111_l1_(main_dbfile,l1l111_l1_ (u"ࠬࡹࡴࡳࠩ㡮"),l1l111_l1_ (u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩ㡯"),l1l111_l1_ (u"ࠧࡊࡒࡏࡓࡈࡇࡔࡊࡑࡑࠫ㡰"))
	if l1ll11ll11ll_l1_: return l1ll11ll11ll_l1_
	l1ll1ll1l1ll_l1_,l1ll11llll1l_l1_,l1lll1l111ll_l1_,l1l11111ll1_l1_,l1lll1l111l1_l1_,l1111l1l1l1_l1_,timezone = l1l111_l1_ (u"ࠨࠩ㡱"),l1l111_l1_ (u"ࠩࠪ㡲"),l1l111_l1_ (u"ࠪࠫ㡳"),l1l111_l1_ (u"ࠫࠬ㡴"),l1l111_l1_ (u"ࠬ࠭㡵"),l1l111_l1_ (u"࠭ࠧ㡶"),l1l111_l1_ (u"ࠧࠨ㡷")
	url = l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡫ࡳࡻ࡭ࡵ࠮ࡪࡵ࠲ࠫ㡸")+l1ll1ll1l1ll_l1_+l1l111_l1_ (u"ࠩࡂࡳࡺࡺࡰࡶࡶࡀ࡮ࡸࡵ࡮ࠧࡨ࡬ࡩࡱࡪࡳ࠾࡫ࡳ࠰ࡨࡵ࡮ࡵ࡫ࡱࡩࡳࡺࠬࡤࡱࡸࡲࡹࡸࡹ࠭ࡥࡲࡹࡳࡺࡲࡺࡡࡦࡳࡩ࡫ࠬࡳࡧࡪ࡭ࡴࡴࠬࡤ࡫ࡷࡽ࠱ࡺࡩ࡮ࡧࡽࡳࡳ࡫ࠧ㡹")
	headers = {l1l111_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ㡺"):l1l111_l1_ (u"ࠫࠬ㡻")}
	response = l1111ll1lll_l1_(l1l111_l1_ (u"ࠬࡍࡅࡕࠩ㡼"),url,l1l111_l1_ (u"࠭ࠧ㡽"),headers,l1l111_l1_ (u"ࠧࠨ㡾"),l1l111_l1_ (u"ࠨࠩ㡿"),l1l111_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡊࡕࡌࡐࡅࡄࡘࡎࡕࡎ࠮࠳ࡶࡸࠬ㢀"))
	if not response.succeeded: l1111l1ll11_l1_ = l1ll1ll1l1ll_l1_+l1l111_l1_ (u"ࠪ࠰ࠬ㢁")+l1ll11llll1l_l1_+l1l111_l1_ (u"ࠫ࠱࠭㢂")+l1lll1l111ll_l1_+l1l111_l1_ (u"ࠬ࠲ࠧ㢃")+l1lll1l111l1_l1_+l1l111_l1_ (u"࠭ࠬࠨ㢄")+l1111l1l1l1_l1_+l1l111_l1_ (u"ࠧ࠭ࠩ㢅")+timezone
	else:
		html = response.content
		html = re.findall(l1l111_l1_ (u"ࠨ࡞ࡾ࠲࠯ࡅ࡜ࡾ࡞ࢀࠫ㢆"),html,re.DOTALL)
		if html:
			html = html[0]
			l11l111l11l_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠩࡧ࡭ࡨࡺࠧ㢇"),html)
			if l1l111_l1_ (u"ࠪ࡭ࡵ࠭㢈") in list(l11l111l11l_l1_.keys()): l1ll1ll1l1ll_l1_ = l11l111l11l_l1_[l1l111_l1_ (u"ࠫ࡮ࡶࠧ㢉")]
			if l1l111_l1_ (u"ࠬࡩ࡯࡯ࡶ࡬ࡲࡪࡴࡴࠨ㢊") in list(l11l111l11l_l1_.keys()): l1ll11llll1l_l1_ = l11l111l11l_l1_[l1l111_l1_ (u"࠭ࡣࡰࡰࡷ࡭ࡳ࡫࡮ࡵࠩ㢋")]
			if l1l111_l1_ (u"ࠧࡤࡱࡸࡲࡹࡸࡹࠨ㢌") in list(l11l111l11l_l1_.keys()): l1lll1l111ll_l1_ = l11l111l11l_l1_[l1l111_l1_ (u"ࠨࡥࡲࡹࡳࡺࡲࡺࠩ㢍")]
			if l1l111_l1_ (u"ࠩࡦࡳࡺࡴࡴࡳࡻࡢࡧࡴࡪࡥࠨ㢎") in list(l11l111l11l_l1_.keys()): l1l11111ll1_l1_ = l11l111l11l_l1_[l1l111_l1_ (u"ࠪࡧࡴࡻ࡮ࡵࡴࡼࡣࡨࡵࡤࡦࠩ㢏")]
			if l1l111_l1_ (u"ࠫࡷ࡫ࡧࡪࡱࡱࠫ㢐") in list(l11l111l11l_l1_.keys()): l1lll1l111l1_l1_ = l11l111l11l_l1_[l1l111_l1_ (u"ࠬࡸࡥࡨ࡫ࡲࡲࠬ㢑")]
			if l1l111_l1_ (u"࠭ࡣࡪࡶࡼࠫ㢒") in list(l11l111l11l_l1_.keys()): l1111l1l1l1_l1_ = l11l111l11l_l1_[l1l111_l1_ (u"ࠧࡤ࡫ࡷࡽࠬ㢓")]
			if l1l111_l1_ (u"ࠨࡶ࡬ࡱࡪࢀ࡯࡯ࡧࠪ㢔") in list(l11l111l11l_l1_.keys()):
				timezone = l11l111l11l_l1_[l1l111_l1_ (u"ࠩࡷ࡭ࡲ࡫ࡺࡰࡰࡨࠫ㢕")][l1l111_l1_ (u"ࠪࡹࡹࡩࠧ㢖")]
				if timezone[0] not in [l1l111_l1_ (u"ࠫ࠲࠭㢗"),l1l111_l1_ (u"ࠬ࠱ࠧ㢘")]: timezone = l1l111_l1_ (u"࠭ࠫࠨ㢙")+timezone
			l1111l1ll11_l1_ = l1ll1ll1l1ll_l1_+l1l111_l1_ (u"ࠧ࠭ࠩ㢚")+l1ll11llll1l_l1_+l1l111_l1_ (u"ࠨ࠮ࠪ㢛")+l1lll1l111ll_l1_+l1l111_l1_ (u"ࠩ࠯ࠫ㢜")+l1lll1l111l1_l1_+l1l111_l1_ (u"ࠪ࠰ࠬ㢝")+l1111l1l1l1_l1_+l1l111_l1_ (u"ࠫ࠱࠭㢞")+timezone
			if PY3: l1111l1ll11_l1_ = l1111l1ll11_l1_.encode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㢟")).decode(l1l111_l1_ (u"࠭ࡵ࡯࡫ࡦࡳࡩ࡫࡟ࡦࡵࡦࡥࡵ࡫ࠧ㢠"))
		l1lll111111_l1_(main_dbfile,l1l111_l1_ (u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪ㢡"),l1l111_l1_ (u"ࠨࡋࡓࡐࡔࡉࡁࡕࡋࡒࡒࠬ㢢"),l1111l1ll11_l1_,l111l11l_l1_)
	l1111l1ll11_l1_ = escapeUNICODE(l1111l1ll11_l1_)
	return l1111l1ll11_l1_
def l111ll_l1_(search):
	options,l11_l1_ = l1l111_l1_ (u"ࠩࠪ㢣"),True
	if search.count(l1l111_l1_ (u"ࠪࡣࠬ㢤"))>=2:
		search,options = search.split(l1l111_l1_ (u"ࠫࡤ࠭㢥"),1)
		options = l1l111_l1_ (u"ࠬࡥࠧ㢦")+options
		if l1l111_l1_ (u"࠭࡟ࡏࡑࡇࡍࡆࡒࡏࡈࡕࡢࠫ㢧") in options: l11_l1_ = False
		else: l11_l1_ = True
	return search,options,l11_l1_
def l1l1lllll111_l1_():
	l1ll1lllll1l_l1_ = os.path.join(l1l1l1l1ll1_l1_,l1l111_l1_ (u"ࠧࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭㢨"))
	l1lllll1ll11_l1_ = 0
	if os.path.exists(l1ll1lllll1l_l1_):
		for filename in os.listdir(l1ll1lllll1l_l1_):
			if l1l111_l1_ (u"ࠨ࠰ࡳࡽࡴ࠭㢩") in filename: continue
			if l1l111_l1_ (u"ࠩࡢࡣࡵࡿࡣࡢࡥ࡫ࡩࡤࡥࠧ㢪") in filename: continue
			l1ll111111_l1_ = os.path.join(l1ll1lllll1l_l1_,filename)
			size,count = l1ll1l11ll_l1_(l1ll111111_l1_)
			l1lllll1ll11_l1_ += size
	return l1lllll1ll11_l1_
def l11111l11l1_l1_(l1l1ll1lll1_l1_,l11_l1_):
	url = l1l11l1_l1_[l1l111_l1_ (u"ࠪࡔ࡞࡚ࡈࡐࡐࠪ㢫")][3]
	user = l1l1ll111ll_l1_(32,l1l1ll1lll1_l1_)
	l1111l1ll11_l1_ = l111lllllll_l1_()
	l1lll1l111ll_l1_ = l1111l1ll11_l1_.split(l1l111_l1_ (u"ࠫ࠱࠭㢬"))[2]
	l1lllll1ll11_l1_ = l1l1lllll111_l1_()
	payload = {l1l111_l1_ (u"ࠬࡻࡳࡦࡴࠪ㢭"):user,l1l111_l1_ (u"࠭ࡶࡦࡴࡶ࡭ࡴࡴࠧ㢮"):l1l11l1l1l1_l1_,l1l111_l1_ (u"ࠧࡤࡱࡸࡲࡹࡸࡹࠨ㢯"):l1lll1l111ll_l1_,l1l111_l1_ (u"ࠨ࡫ࡧࡷࠬ㢰"):l1ll1llll111_l1_(l1lllll1ll11_l1_)}
	if not l1l1ll1lll1_l1_:
		l1lll1l1lll_l1_(main_dbfile,l1l111_l1_ (u"ࠩࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗࠬ㢱"),(l1l111_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ㢲"),url,payload,l1l111_l1_ (u"ࠫࠬ㢳"),l1l111_l1_ (u"ࠬ࠭㢴"),l1l111_l1_ (u"࠭ࠧ㢵")))
	settings.setSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡹࡸ࡫ࡲ࠯ࡲࡵ࡭ࡻࡹࠧ㢶"),l1l111_l1_ (u"ࠨࠩ㢷"))
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ㢸"),url,payload,l1l111_l1_ (u"ࠪࠫ㢹"),l1l111_l1_ (u"ࠫࠬ㢺"),l1l111_l1_ (u"ࠬ࠭㢻"),l1l111_l1_ (u"࠭ࡍࡆࡐࡘࡗ࠲࡙ࡈࡐ࡙ࡢࡑࡊ࡙ࡓࡂࡉࡈࡗ࠲࠷ࡳࡵࠩ㢼"),True,True)
	l11lll1lll1_l1_ = settings.getSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡱࡪࡹࡳࡢࡩࡨࡷ࠳ࡹࡴࡢࡶࡸࡷࠬ㢽"))
	if not l11lll1lll1_l1_: l11lll1lll1_l1_ = l1l111_l1_ (u"ࠨࡐࡈ࡛ࠬ㢾")
	l1lll11l11l1_l1_ = l11lll1lll1_l1_
	if not response.succeeded: l1lll11l11l1_l1_ = l1l111_l1_ (u"ࠩࡈࡖࡗࡕࡒࠨ㢿")
	else:
		l1l11ll1l11_l1_,l1111ll1l1l_l1_,l111l11111l_l1_,l11l11ll111_l1_ = l1l111_l1_ (u"ࠪࠫ㣀"),l1l111_l1_ (u"ࠫࠬ㣁"),l1l111_l1_ (u"ࠬ࠭㣂"),[]
		newfile = response.content
		if newfile:
			l11l11ll111_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"࠭࡬ࡪࡵࡷࠫ㣃"),newfile)
			for l1llll1ll111_l1_,l1ll1l111l11_l1_,message in l11l11ll111_l1_:
				if PY3: message = message.encode(l1l111_l1_ (u"ࠧࡳࡣࡺࡣࡺࡴࡩࡤࡱࡧࡩࡤ࡫ࡳࡤࡣࡳࡩࠬ㣄")).decode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭㣅"))
				if l1llll1ll111_l1_==l1l111_l1_ (u"ࠩ࠳ࠫ㣆"): l1l11ll1l11_l1_ += message+l1l111_l1_ (u"ࠪ࠾࠿࠭㣇")
				else: l1111ll1l1l_l1_ += message+l1l111_l1_ (u"ࠫࡡࡴࠧ㣈")
			l1111ll1l1l_l1_ = l1111ll1l1l_l1_.strip(l1l111_l1_ (u"ࠬࡢ࡮ࠨ㣉"))
			l1l11ll1l11_l1_ = l1l11ll1l11_l1_.strip(l1l111_l1_ (u"࠭࠺࠻ࠩ㣊"))
		settings.setSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡹࡸ࡫ࡲ࠯ࡲࡵ࡭ࡻࡹࠧ㣋"),l1l11ll1l11_l1_)
		settings.setSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡲ࡫ࡳࡴࡣࡪࡩࡸ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬ࠩ㣌"),l1ll1llll111_l1_(now))
		if os.path.exists(l1l1ll1l1l11_l1_): l111l11111l_l1_ = open(l1l1ll1l1l11_l1_,l1l111_l1_ (u"ࠩࡵࡦࠬ㣍")).read()
		if PY3: l1111ll1l1l_l1_ = l1111ll1l1l_l1_.encode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㣎"))
		if l1111ll1l1l_l1_!=l111l11111l_l1_:
			l1lll11l11l1_l1_ = l1l111_l1_ (u"ࠫࡓࡋࡗࠨ㣏")
			try: open(l1l1ll1l1l11_l1_,l1l111_l1_ (u"ࠬࡽࡢࠨ㣐")).write(l1111ll1l1l_l1_)
			except: pass
		if l11_l1_:
			l11l11ll111_l1_ = sorted(l11l11ll111_l1_,reverse=True,key=lambda key: int(key[0]))
			l111l111111_l1_ = l1l111_l1_ (u"࠭ࠧ㣑")
			for l1llll1ll111_l1_,l1ll1l111l11_l1_,message in l11l11ll111_l1_:
				if PY3: message = message.encode(l1l111_l1_ (u"ࠧࡳࡣࡺࡣࡺࡴࡩࡤࡱࡧࡩࡤ࡫ࡳࡤࡣࡳࡩࠬ㣒")).decode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭㣓"))
				if l111l111111_l1_: l111l111111_l1_ += l1l111_l1_ (u"ࠩ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢࡢ࡮࡝ࡰࠪ㣔")
				if l1llll1ll111_l1_==l1l111_l1_ (u"ࠪ࠴ࠬ㣕"): continue
				date = message.split(l1l111_l1_ (u"ࠫࡡࡴࠧ㣖"))[0]
				l11l1lll1l1_l1_ = l1l111_l1_ (u"ࠬ࠭㣗")
				if l1ll1l111l11_l1_:
					l11l1lll1l1_l1_ = l1l111_l1_ (u"࠭ัิษ็อࠥิวึห่่ࠣࠦแใูࠪ㣘")
					if PY3: l11l1lll1l1_l1_ = l11l1lll1l1_l1_.encode(l1l111_l1_ (u"ࠧࡳࡣࡺࡣࡺࡴࡩࡤࡱࡧࡩࡤ࡫ࡳࡤࡣࡳࡩࠬ㣙")).decode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭㣚"))
				l111l111111_l1_ += message.replace(date,l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ㣛")+date+l11l1lll1l1_l1_+l1l111_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㣜"))+l1l111_l1_ (u"ࠫࡡࡴࠧ㣝")
			l111l111111_l1_ = escapeUNICODE(l111l111111_l1_)
			l1l11l1l1l_l1_(l1l111_l1_ (u"ࠬࡸࡩࡨࡪࡷࠫ㣞"),l1l111_l1_ (u"࠭ัิษษ่๋ࠥๆࠡษ็้อืๅอࠢศ่๎ࠦๅิฬัำ๊๐ࠠศๆหี๋อๅอࠩ㣟"),l111l111111_l1_,l1l111_l1_ (u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࡢࡰࡴࡴࡧࠨ㣠"))
			l1lll11l11l1_l1_ = l1l111_l1_ (u"ࠨࡑࡏࡈࠬ㣡")
		if l1lll11l11l1_l1_!=l11lll1lll1_l1_:
			settings.setSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡳࡥࡴࡵࡤ࡫ࡪࡹ࠮ࡴࡶࡤࡸࡺࡹࠧ㣢"),l1lll11l11l1_l1_)
	if l11_l1_: xbmc.executebuiltin(l1l111_l1_ (u"ࠪࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡒࡦࡨࡵࡩࡸ࡮ࠧ㣣"))
	return l1lll11l11l1_l1_
def PING(host,port):
	from socket import socket,AF_INET,SOCK_STREAM
	sock = socket(AF_INET,SOCK_STREAM)
	sock.settimeout(1)
	l1ll11l11ll1_l1_,resp = True,0
	t1 = time.time()
	try: sock.connect((host,port))
	except: l1ll11l11ll1_l1_ = False
	l11ll1ll11_l1_ = time.time()
	if l1ll11l11ll1_l1_: resp = l11ll1ll11_l1_-t1
	return resp
def FIX_ALL_DATABASES(l11_l1_):
	if l11_l1_:
		l1llll111l_l1_ = l1ll11ll1l_l1_(l1l111_l1_ (u"ࠫࠬ㣤"),l1l111_l1_ (u"ࠬ࠭㣥"),l1l111_l1_ (u"࠭ࠧ㣦"),l1l111_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ㣧"),l1l111_l1_ (u"ࠨี๋ๅࠥ๐โ้็ࠣห้ฮั็ษ่ะࠥอไร่ࠣฬส฻ไศฯࠣ์ฯ์ุ๋ใࠣะ๊๐ูࠡไ๋ห฾ีࠠศๆห๎ฬ์วห๋ࠢห้้วีࠢสู่๊สฯั่อࠥ็๊ࠡษ็ฬึ์วๆฮࠣ࠲࠳ࠦ็ๅࠢอี๏ีࠠหึ฽๎ู้ࠦๆๆํอࠥอไห่฻๎ๆࠦวๅฤ้ࠤฤࠧࠧ㣨"))
	else: l1llll111l_l1_ = True
	if l1llll111l_l1_==1:
		for filename in os.listdir(addoncachefolder):
			if filename.endswith(l1l111_l1_ (u"ࠩ࠱ࡨࡧ࠭㣩")) and l1l111_l1_ (u"ࠪࡨࡦࡺࡡࠨ㣪") in filename:
				l1ll1lll1l_l1_ = os.path.join(addoncachefolder,filename)
				try: conn,l1llll1lll_l1_ = l1l1llll1l1_l1_(l1ll1lll1l_l1_)
				except: return
				l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠫࡕࡘࡁࡈࡏࡄࠤ࡮ࡴࡴࡦࡩࡵ࡭ࡹࡿ࡟ࡤࡪࡨࡧࡰࡁࠧ㣫"))
				l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠬࡖࡒࡂࡉࡐࡅࠥࡵࡰࡵ࡫ࡰ࡭ࡿ࡫࠻ࠨ㣬"))
				l1llll1lll_l1_.execute(l1l111_l1_ (u"࠭ࡖࡂࡅࡘ࡙ࡒࡁࠧ㣭"))
				conn.commit()
				conn.close()
		if l11_l1_:
			l1111l1_l1_(l1l111_l1_ (u"ࠧࠨ㣮"),l1l111_l1_ (u"ࠨࠩ㣯"),l1l111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㣰"),l1l111_l1_ (u"ࠪฮ๊ะࠠษ่ฯหาูࠦๆๆํอࠥหีๅษะࠤํะๆู์ไࠤัฺ๋๊ࠢๅ์ฬ฿ฯࠡษ็ฬ๏อๆศฬࠣ์ฬ๊ใศึࠣห้๋ำหะา้ฮࠦแ๋ࠢส่อืๆศ็ฯࠫ㣱"))
	return
def l1ll11ll111l_l1_(word):
	if l1l111_l1_ (u"ࠫࡠ࠭㣲") in word and l1l111_l1_ (u"ࠬࡣࠧ㣳") in word:
		l11ll1l1111_l1_ = [l1l111_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ㣴"),l1l111_l1_ (u"ࠧ࡜࠱ࡕࡘࡑࡣࠧ㣵"),l1l111_l1_ (u"ࠨ࡝࠲ࡐࡊࡌࡔ࡞ࠩ㣶"),l1l111_l1_ (u"ࠩ࡞࠳ࡗࡏࡇࡉࡖࡠࠫ㣷"),l1l111_l1_ (u"ࠪ࡟࠴ࡉࡅࡏࡖࡈࡖࡢ࠭㣸"),l1l111_l1_ (u"ࠫࡠࡘࡔࡍ࡟ࠪ㣹"),l1l111_l1_ (u"ࠬࡡࡌࡆࡈࡗࡡࠬ㣺"),l1l111_l1_ (u"࡛࠭ࡓࡋࡊࡌ࡙ࡣࠧ㣻"),l1l111_l1_ (u"ࠧ࡜ࡅࡈࡒ࡙ࡋࡒ࡞ࠩ㣼")]
		l11l1lll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࡞࡞ࡇࡔࡒࡏࡓࠢ࠱࠮ࡄࡢ࡝ࠨ㣽"),word,re.DOTALL)
		l11l1llll11_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡟࡟ࡈࡕࡌࡐࡔ࠽࠾࠿࠴ࠪࡀ࡞ࡠࠫ㣾"),word,re.DOTALL)
		l1ll1l111111_l1_ = l11ll1l1111_l1_+l11l1lll1ll_l1_+l11l1llll11_l1_
		for tag in l1ll1l111111_l1_: word = word.replace(tag,l1l111_l1_ (u"ࠪࠫ㣿"))
	return word
def l1llll1ll1ll_l1_(l1l1111l1ll_l1_,l11111ll11l_l1_,l1lll1ll1l11_l1_,l1ll1l1ll1ll_l1_):
	from PIL import ImageDraw,ImageFont,Image
	l11ll11ll1l_l1_,l11l11lll1l_l1_,l1ll111l111l_l1_ = l1l111_l1_ (u"ࠫࠬ㤀"),0,15000
	l1l1111l1ll_l1_ = l1l1111l1ll_l1_.replace(l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥ࠭㤁"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࡀ࠺࠻ࠩ㤂"))
	l1l1lll1ll1l_l1_ = ImageFont.truetype(l1111l11111_l1_,size=l11111ll11l_l1_)
	l1lll1ll1l11_l1_ -= l11111ll11l_l1_*2
	l1ll111ll1l1_l1_ = Image.new(l1l111_l1_ (u"ࠧࡓࡉࡅࡅࠬ㤃"),(l1lll1ll1l11_l1_,99),(255,255,255,0))
	l111ll1l1l1_l1_ = ImageDraw.Draw(l1ll111ll1l1_l1_)
	for l1ll11l1l11l_l1_ in l1l1111l1ll_l1_.splitlines():
		l11l11lll1l_l1_ += l1ll1l1ll1ll_l1_
		l11111llll1_l1_,newline = 0,l1l111_l1_ (u"ࠨࠩ㤄")
		for word in l1ll11l1l11l_l1_.split(l1l111_l1_ (u"ࠩࠣࠫ㤅")):
			l111l1ll1ll_l1_ = l1ll11ll111l_l1_(l1l111_l1_ (u"ࠪࠤࠬ㤆")+word)
			l1lllll11l1l_l1_,l111ll11111_l1_ = l111ll1l1l1_l1_.textsize(l111l1ll1ll_l1_,font=l1l1lll1ll1l_l1_)
			if l11111llll1_l1_+l1lllll11l1l_l1_<l1lll1ll1l11_l1_:
				if not newline: newline += word
				else: newline += l1l111_l1_ (u"ࠫࠥ࠭㤇")+word
				l11111llll1_l1_ += l1lllll11l1l_l1_
			else:
				if l1lllll11l1l_l1_<l1lll1ll1l11_l1_:
					newline += l1l111_l1_ (u"ࠬࡢ࡮ࠡࠩ㤈")+word
					l11l11lll1l_l1_ += l1ll1l1ll1ll_l1_
					l11111llll1_l1_ = l1lllll11l1l_l1_
				else:
					while l1lllll11l1l_l1_>l1lll1ll1l11_l1_:
						for l1l111lll1_l1_ in range(1,len(l1l111_l1_ (u"࠭ࠠࠨ㤉")+word),1):
							l111ll1lll1_l1_ = l1l111_l1_ (u"ࠧࠡࠩ㤊")+word[:l1l111lll1_l1_]
							l11l1111lll_l1_ = word[l1l111lll1_l1_:]
							l1lll1lll11l_l1_ = l1ll11ll111l_l1_(l111ll1lll1_l1_)
							l11ll111l11_l1_,l111l11l111_l1_ = l111ll1l1l1_l1_.textsize(l1lll1lll11l_l1_,font=l1l1lll1ll1l_l1_)
							if l11111llll1_l1_+l11ll111l11_l1_>l1lll1ll1l11_l1_:
								l1lll1l11111_l1_ = l1lllll11l1l_l1_-l11ll111l11_l1_
								newline += l111ll1lll1_l1_+l1l111_l1_ (u"ࠨ࡞ࡱࠫ㤋")
								l11l11lll1l_l1_ += l1ll1l1ll1ll_l1_
								l1lllll11l1l_l1_ = l1lll1l11111_l1_
								if l1lll1l11111_l1_>l1lll1ll1l11_l1_:
									l11111llll1_l1_ = 0
									word = l11l1111lll_l1_
								else:
									l11111llll1_l1_ = l1lll1l11111_l1_
									newline += l11l1111lll_l1_
								break
				if l11l11lll1l_l1_>l1ll111l111l_l1_: break
		l11ll11ll1l_l1_ += l1l111_l1_ (u"ࠩ࡟ࡲࠬ㤌")+newline
		if l11l11lll1l_l1_>l1ll111l111l_l1_: break
	l11ll11ll1l_l1_ = l11ll11ll1l_l1_[1:]
	l11ll11ll1l_l1_ = l11ll11ll1l_l1_.replace(l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔ࠽࠾࠿࠭㤍"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࠬ㤎"))
	return l11ll11ll1l_l1_
def l11l1l1ll11_l1_(text):
	text = text.replace(l1l111_l1_ (u"ࠬࡢ࡮ࠨ㤏"),l1l111_l1_ (u"࠭࡟ࡴࡵࡶࡣࡤࡴࡥࡸ࡮࡬ࡲࡪࡥࠧ㤐"))
	text = text.replace(l1l111_l1_ (u"ࠧ࡜ࡔࡗࡐࡢ࠭㤑"),l1l111_l1_ (u"ࠨࡡࡶࡷࡸࡥ࡟࡭࡫ࡱࡩࡷࡺ࡬ࡠࠩ㤒"))
	text = text.replace(l1l111_l1_ (u"ࠩ࡞ࡐࡊࡌࡔ࡞ࠩ㤓"),l1l111_l1_ (u"ࠪࡣࡸࡹࡳࡠࡡ࡯࡭ࡳ࡫࡬ࡦࡨࡷࡣࠬ㤔"))
	text = text.replace(l1l111_l1_ (u"ࠫࡠࡘࡉࡈࡊࡗࡡࠬ㤕"),l1l111_l1_ (u"ࠬࡥࡳࡴࡵࡢࡣࡱ࡯࡮ࡦࡴ࡬࡫࡭ࡺ࡟ࠨ㤖"))
	text = text.replace(l1l111_l1_ (u"࡛࠭ࡄࡇࡑࡘࡊࡘ࡝ࠨ㤗"),l1l111_l1_ (u"ࠧࡠࡵࡶࡷࡤࡥ࡬ࡪࡰࡨࡧࡪࡴࡴࡦࡴࡢࠫ㤘"))
	text = text.replace(l1l111_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㤙"),l1l111_l1_ (u"ࠩࡢࡷࡸࡹ࡟ࡠࡧࡱࡨࡨࡵ࡬ࡰࡴࡢࠫ㤚"))
	l1lllll1l1l1_l1_ = re.findall(l1l111_l1_ (u"ࠪࡠࡠࡉࡏࡍࡑࡕࠤ࠭࠴ࠪࡀࠫ࡟ࡡࠬ㤛"),text,re.DOTALL)
	for l1lll11ll1ll_l1_ in l1lllll1l1l1_l1_: text = text.replace(l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࠬ㤜")+l1lll11ll1ll_l1_+l1l111_l1_ (u"ࠬࡣࠧ㤝"),l1l111_l1_ (u"࠭࡟ࡴࡵࡶࡣࡤࡴࡥࡸࡥࡲࡰࡴࡸࠧ㤞")+l1lll11ll1ll_l1_+l1l111_l1_ (u"ࠧࡠࠩ㤟"))
	return text
def l1llllll1ll1_l1_(l111l11l1l1_l1_,l1ll11l1ll1l_l1_,l111l11llll_l1_,header,text,profile,l11ll11l1l1_l1_,l1lll111l1l1_l1_,l1ll1ll1ll11_l1_):
	l1llllllllll_l1_ = settings.getSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡱࡧ࡮ࡨࡷࡤ࡫ࡪ࠴ࡴࡳࡣࡱࡷࡱࡧࡴࡦࠩ㤠"))
	if l1llllllllll_l1_:
		l1lll_l1_ = LANGUAGE_TRANSLATE([l111l11l1l1_l1_,l1ll11l1ll1l_l1_,l111l11llll_l1_,header,text])
		if l1lll_l1_: l111l11l1l1_l1_,l1ll11l1ll1l_l1_,l111l11llll_l1_,header,text = l1lll_l1_
	from PIL import ImageDraw,ImageFont,Image
	if PY2:
		text = text.decode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㤡"))
		header = header.decode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㤢"))
		l111l11l1l1_l1_ = l111l11l1l1_l1_.decode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㤣"))
		l1ll11l1ll1l_l1_ = l1ll11l1ll1l_l1_.decode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㤤"))
		l111l11llll_l1_ = l111l11llll_l1_.decode(l1l111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ㤥"))
	l111ll11l11_l1_ = 5
	l1l1lll1l1l1_l1_ = 20
	l1llll1l1111_l1_ = 20
	l1lll1l11l1l_l1_ = 0
	l1l1111lll1_l1_ = l1l111_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ㤦")
	l1ll1111l111_l1_ = 0
	l1ll111ll11l_l1_ = 19
	l11l11lll11_l1_ = 30
	l1llll11l111_l1_ = 8
	l1lll11llll1_l1_ = True
	l1ll11l1lll1_l1_ = 375
	l1l1llll1l11_l1_ = 410
	l1l1ll1ll111_l1_ = 50
	l1ll1l1lll1l_l1_ = 280
	l1111lllll1_l1_ = 28
	l1ll111111l1_l1_ = 5
	l111lllll11_l1_ = 0
	l1lll1ll11ll_l1_ = 31
	l111llllll1_l1_ = [36,32,28]
	if profile in [l1l111_l1_ (u"ࠨࡰࡲࡸ࡮࡬ࡩࡤࡣࡷ࡭ࡴࡴࠧ㤧"),l1l111_l1_ (u"ࠩࡱࡳࡹ࡯ࡦࡪࡥࡤࡸ࡮ࡵ࡮ࡠࡶࡺࡳ࡭ࡧ࡬ࡧࡵࠪ㤨")]:
		if profile==l1l111_l1_ (u"ࠪࡲࡴࡺࡩࡧ࡫ࡦࡥࡹ࡯࡯࡯ࡡࡷࡻࡴ࡮ࡡ࡭ࡨࡶࠫ㤩"):
			l1l1111l111_l1_ = l1l111_l1_ (u"࡚ࠫࡖࡐࡆࡔࠪ㤪")
			l1l1111lll1_l1_ = l1l111_l1_ (u"ࠬࡸࡩࡨࡪࡷࠫ㤫")
			l1lll11llll1_l1_ = True
			l1lll1l11l1l_l1_ = 10
		else:
			l1l1111l111_l1_ = 97+20
			l1l1111lll1_l1_ = l1l111_l1_ (u"࠭࡬ࡦࡨࡷࠫ㤬")
			l1lll11llll1_l1_ = False
		l111llllll1_l1_ = [33,33,33]
		l1llll1l1111_l1_ = 20
		l1l1lll1l1l1_l1_ = 0
		l11l11lll11_l1_ = 20
		l1ll111ll11l_l1_ = 25+10
	elif profile==l1l111_l1_ (u"ࠧࡤࡱࡱࡪ࡮ࡸ࡭ࡠࡵࡰࡥࡱࡲࡦࡰࡰࡷࠫ㤭"): l111llllll1_l1_ = [28,24,20] ; l1l1111l111_l1_ = 500
	elif profile==l1l111_l1_ (u"ࠨࡥࡲࡲ࡫࡯ࡲ࡮ࡡࡰࡩࡩ࡯ࡵ࡮ࡨࡲࡲࡹ࠭㤮"): l111llllll1_l1_ = [32,28,24] ; l1l1111l111_l1_ = 500
	elif profile==l1l111_l1_ (u"ࠩࡦࡳࡳ࡬ࡩࡳ࡯ࡢࡦ࡮࡭ࡦࡰࡰࡷࠫ㤯"): l111llllll1_l1_ = [36,32,28] ; l1l1111l111_l1_ = 500
	elif profile==l1l111_l1_ (u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭㤰"): l1l1111l111_l1_ = 740
	elif profile==l1l111_l1_ (u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺ࡟࡭ࡱࡱ࡫ࠬ㤱"): l1l1111l111_l1_ = l1l111_l1_ (u"࡛ࠬࡐࡑࡇࡕࠫ㤲")
	elif profile==l1l111_l1_ (u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡵࡰࡥࡱࡲࡦࡰࡰࡷࠫ㤳"): l111llllll1_l1_ = [28,23,18] ; l1l1111l111_l1_ = 740
	elif profile==l1l111_l1_ (u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡶࡱࡦࡲ࡬ࡧࡱࡱࡸࡤࡲ࡯࡯ࡩࠪ㤴"): l111llllll1_l1_ = [28,23,18] ; l1l1111l111_l1_ = l1l111_l1_ (u"ࠨࡗࡓࡔࡊࡘࠧ㤵")
	l11111l1lll_l1_ = l111llllll1_l1_[0]
	l11l111l1ll_l1_ = l111llllll1_l1_[1]
	l1l11111l11_l1_ = l111llllll1_l1_[2]
	l1111l1111l_l1_ = ImageFont.truetype(l1111l11111_l1_,size=l11111l1lll_l1_)
	l1llll1l1l1l_l1_ = ImageFont.truetype(l1111l11111_l1_,size=l11l111l1ll_l1_)
	l1lllll1l11l_l1_ = ImageFont.truetype(l1111l11111_l1_,size=l1l11111l11_l1_)
	l1ll111ll1l1_l1_ = Image.new(l1l111_l1_ (u"ࠩࡕࡋࡇࡇࠧ㤶"),(100,100),(255,255,255,0))
	l111ll1l1l1_l1_ = ImageDraw.Draw(l1ll111ll1l1_l1_)
	l1ll11l11111_l1_,l1ll1llllll1_l1_ = l111ll1l1l1_l1_.textsize(l1l111_l1_ (u"ࠪࡌࡍࡎࠠࡃࡄࡅࠤ࠽࠾࠸ࠡ࠲࠳࠴ࠬ㤷"),font=l1llll1l1l1l_l1_)
	l1ll11l1l1ll_l1_,l111l111l1l_l1_ = l111ll1l1l1_l1_.textsize(l1l111_l1_ (u"ࠫࡍࡎࡈࠡࡄࡅࡆࠥ࠾࠸࠹ࠢ࠳࠴࠵࠭㤸"),font=l1111l1111l_l1_)
	l1ll1111l1l1_l1_ = header.count(l1l111_l1_ (u"ࠬࡢ࡮ࠨ㤹"))+1
	l11ll11111l_l1_ = l1l1lll1l1l1_l1_+l1ll1111l1l1_l1_*(l111l111l1l_l1_+l1lll1l11l1l_l1_)-l1lll1l11l1l_l1_
	l1lll111llll_l1_ = {l1l111_l1_ (u"࠭ࡤࡦ࡮ࡨࡸࡪࡥࡨࡢࡴࡤ࡯ࡦࡺࠧ㤺"):False,l1l111_l1_ (u"ࠧࡴࡷࡳࡴࡴࡸࡴࡠ࡮࡬࡫ࡦࡺࡵࡳࡧࡶࠫ㤻"):True,l1l111_l1_ (u"ࠨࡃࡕࡅࡇࡏࡃࠡࡎࡌࡋࡆ࡚ࡕࡓࡇࠣࡅࡑࡒࡁࡉࠩ㤼"):False}
	from arabic_reshaper import ArabicReshaper
	l11ll111111_l1_ = ArabicReshaper(configuration=l1lll111llll_l1_)
	if text:
		l1l111111l1_l1_ = l1lll111l1l1_l1_-l11l11lll11_l1_*2
		l1ll111ll111_l1_ = l1ll1llllll1_l1_+l1llll11l111_l1_
		l1lll11l1l11_l1_ = l11ll111111_l1_.reshape(text)
		if l1lll11llll1_l1_:
			l1l1ll1l1111_l1_ = l1llll1ll1ll_l1_(l1lll11l1l11_l1_,l11l111l1ll_l1_,l1l111111l1_l1_,l1ll111ll111_l1_)
			l1lllllll1ll_l1_ = l1ll11ll111l_l1_(l1l1ll1l1111_l1_)
			l1lll111ll1l_l1_ = l1lllllll1ll_l1_.count(l1l111_l1_ (u"ࠩ࡟ࡲࠬ㤽"))+1
			if l1lll111ll1l_l1_<6:
				l1ll11ll1111_l1_ = l1l111111l1_l1_
				l1l1ll1l1111_l1_ = l1llll1ll1ll_l1_(l1lll11l1l11_l1_,l11l111l1ll_l1_,l1ll11ll1111_l1_,l1ll111ll111_l1_)
				l1lllllll1ll_l1_ = l1ll11ll111l_l1_(l1l1ll1l1111_l1_)
				l1lll111ll1l_l1_ = l1lllllll1ll_l1_.count(l1l111_l1_ (u"ࠪࡠࡳ࠭㤾"))+1
			l11ll1lllll_l1_ = l1ll111ll11l_l1_+l1lll111ll1l_l1_*l1ll111ll111_l1_-l1llll11l111_l1_
		else:
			l11ll1lllll_l1_ = l1ll111ll11l_l1_+l1ll1llllll1_l1_
			l1lllllll1ll_l1_ = l1lll11l1l11_l1_.split(l1l111_l1_ (u"ࠫࡡࡴࠧ㤿"))[0]
			l1l1ll1l1111_l1_ = l1lll11l1l11_l1_.split(l1l111_l1_ (u"ࠬࡢ࡮ࠨ㥀"))[0]
	else: l11ll1lllll_l1_ = l1ll111ll11l_l1_
	l1lll1l1ll11_l1_ = l111lllll11_l1_+l1lll1ll11ll_l1_
	if l1ll1ll1ll11_l1_:
		l1ll1l11ll11_l1_ = l1l1llll1l11_l1_-l1ll11l1lll1_l1_
		l1lll1l1ll11_l1_ += l1ll1l11ll11_l1_
	else: l1ll1l11ll11_l1_ = 0
	if l111l11l1l1_l1_ or l1ll11l1ll1l_l1_ or l111l11llll_l1_: l1lll1l1ll11_l1_ += l1l1ll1ll111_l1_
	if l1l1111l111_l1_!=l1l111_l1_ (u"࠭ࡕࡑࡒࡈࡖࠬ㥁"): l111llll1ll_l1_ = l1l1111l111_l1_
	else: l111llll1ll_l1_ = l11ll11111l_l1_+l11ll1lllll_l1_+l1lll1l1ll11_l1_
	l1llllll111l_l1_ = l111llll1ll_l1_-l11ll11111l_l1_-l1lll1l1ll11_l1_-l1ll111ll11l_l1_
	l1ll111ll1l1_l1_ = Image.new(l1l111_l1_ (u"ࠧࡓࡉࡅࡅࠬ㥂"),(l1lll111l1l1_l1_,l111llll1ll_l1_),(255,255,255,0))
	l111ll1l1l1_l1_ = ImageDraw.Draw(l1ll111ll1l1_l1_)
	if not l1ll11l1ll1l_l1_ and l111l11l1l1_l1_ and l111l11llll_l1_:
		l1111lllll1_l1_ += 105
		l1ll111111l1_l1_ -= 110
	if header:
		l111ll11l1l_l1_ = l1l1lll1l1l1_l1_
		header = bidi.algorithm.get_display(l11ll111111_l1_.reshape(header))
		lines = header.splitlines()
		for line in lines:
			if line:
				width,l1lll11ll111_l1_ = l111ll1l1l1_l1_.textsize(line,font=l1111l1111l_l1_)
				if l1l1111lll1_l1_==l1l111_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ㥃"): l1ll11ll1l1l_l1_ = l111ll11l11_l1_+(l1lll111l1l1_l1_-width)/2
				elif l1l1111lll1_l1_==l1l111_l1_ (u"ࠩࡵ࡭࡬࡮ࡴࠨ㥄"): l1ll11ll1l1l_l1_ = l111ll11l11_l1_+l1lll111l1l1_l1_-width-l1llll1l1111_l1_
				elif l1l1111lll1_l1_==l1l111_l1_ (u"ࠪࡰࡪ࡬ࡴࠨ㥅"): l1ll11ll1l1l_l1_ = l111ll11l11_l1_+l1llll1l1111_l1_
				l111ll1l1l1_l1_.text((l1ll11ll1l1l_l1_,l111ll11l1l_l1_),line,font=l1111l1111l_l1_,fill=l1l111_l1_ (u"ࠫࡾ࡫࡬࡭ࡱࡺࠫ㥆"))
			l111ll11l1l_l1_ += l11111l1lll_l1_+l1lll1l11l1l_l1_
	if l111l11l1l1_l1_ or l1ll11l1ll1l_l1_ or l111l11llll_l1_:
		l11l1llllll_l1_ = l11ll11111l_l1_+l1llllll111l_l1_+l1ll111ll11l_l1_+l1ll1l11ll11_l1_+l111lllll11_l1_
		if l111l11l1l1_l1_:
			l111l11l1l1_l1_ = bidi.algorithm.get_display(l11ll111111_l1_.reshape(l111l11l1l1_l1_))
			l1lll11111ll_l1_,l111lll1ll1_l1_ = l111ll1l1l1_l1_.textsize(l111l11l1l1_l1_,font=l1lllll1l11l_l1_)
			l111lllll1l_l1_ = l1111lllll1_l1_+0*(l1ll111111l1_l1_+l1ll1l1lll1l_l1_)+(l1ll1l1lll1l_l1_-l1lll11111ll_l1_)/2
			l111ll1l1l1_l1_.text((l111lllll1l_l1_,l11l1llllll_l1_),l111l11l1l1_l1_,font=l1lllll1l11l_l1_,fill=l1l111_l1_ (u"ࠬࡿࡥ࡭࡮ࡲࡻࠬ㥇"))
		if l1ll11l1ll1l_l1_:
			l1ll11l1ll1l_l1_ = bidi.algorithm.get_display(l11ll111111_l1_.reshape(l1ll11l1ll1l_l1_))
			l1llll11l11l_l1_,l1lll1ll1lll_l1_ = l111ll1l1l1_l1_.textsize(l1ll11l1ll1l_l1_,font=l1lllll1l11l_l1_)
			l11l111l1l1_l1_ = l1111lllll1_l1_+1*(l1ll111111l1_l1_+l1ll1l1lll1l_l1_)+(l1ll1l1lll1l_l1_-l1llll11l11l_l1_)/2
			l111ll1l1l1_l1_.text((l11l111l1l1_l1_,l11l1llllll_l1_),l1ll11l1ll1l_l1_,font=l1lllll1l11l_l1_,fill=l1l111_l1_ (u"࠭ࡹࡦ࡮࡯ࡳࡼ࠭㥈"))
		if l111l11llll_l1_:
			l111l11llll_l1_ = bidi.algorithm.get_display(l11ll111111_l1_.reshape(l111l11llll_l1_))
			l11l1ll1l11_l1_,l111l1111l1_l1_ = l111ll1l1l1_l1_.textsize(l111l11llll_l1_,font=l1lllll1l11l_l1_)
			l111111l1ll_l1_ = l1111lllll1_l1_+2*(l1ll111111l1_l1_+l1ll1l1lll1l_l1_)+(l1ll1l1lll1l_l1_-l11l1ll1l11_l1_)/2
			l111ll1l1l1_l1_.text((l111111l1ll_l1_,l11l1llllll_l1_),l111l11llll_l1_,font=l1lllll1l11l_l1_,fill=l1l111_l1_ (u"ࠧࡺࡧ࡯ࡰࡴࡽࠧ㥉"))
	if text:
		l1l1lll111ll_l1_,l11l1lll11l_l1_ = [],[]
		l1l1ll1l1111_l1_ = l11l1l1ll11_l1_(l1l1ll1l1111_l1_)
		l1ll11l11l11_l1_ = l1l1ll1l1111_l1_.split(l1l111_l1_ (u"ࠨࡡࡶࡷࡸࡥ࡟࡯ࡧࡺࡰ࡮ࡴࡥࡠࠩ㥊"))
		for l1l1lllll1l1_l1_ in l1ll11l11l11_l1_:
			l11lll11l11_l1_ = l11ll11l1l1_l1_
			if   l1l111_l1_ (u"ࠩࡢࡷࡸࡹ࡟ࡠ࡮࡬ࡲࡪࡲࡥࡧࡶࡢࠫ㥋") in l1l1lllll1l1_l1_: l11lll11l11_l1_ = l1l111_l1_ (u"ࠪࡰࡪ࡬ࡴࠨ㥌")
			elif l1l111_l1_ (u"ࠫࡤࡹࡳࡴࡡࡢࡰ࡮ࡴࡥࡳ࡫ࡪ࡬ࡹࡥࠧ㥍") in l1l1lllll1l1_l1_: l11lll11l11_l1_ = l1l111_l1_ (u"ࠬࡸࡩࡨࡪࡷࠫ㥎")
			elif l1l111_l1_ (u"࠭࡟ࡴࡵࡶࡣࡤࡲࡩ࡯ࡧࡦࡩࡳࡺࡥࡳࡡࠪ㥏") in l1l1lllll1l1_l1_: l11lll11l11_l1_ = l1l111_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ㥐")
			l11lll1l1ll_l1_ = l1l1lllll1l1_l1_
			l11ll1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠨࡡࡶࡷࡸࡥ࡟࠯ࠬࡂࡣࠬ㥑"),l1l1lllll1l1_l1_,re.DOTALL)
			for tag in l11ll1l1111_l1_: l11lll1l1ll_l1_ = l11lll1l1ll_l1_.replace(tag,l1l111_l1_ (u"ࠩࠪ㥒"))
			if l11lll1l1ll_l1_==l1l111_l1_ (u"ࠪࠫ㥓"): width,l1lll11ll111_l1_ = 0,l1ll111ll111_l1_
			else: width,l1lll11ll111_l1_ = l111ll1l1l1_l1_.textsize(l11lll1l1ll_l1_,font=l1llll1l1l1l_l1_)
			if   l11lll11l11_l1_==l1l111_l1_ (u"ࠫࡱ࡫ࡦࡵࠩ㥔"): l1111l1lll1_l1_ = l1ll1111l111_l1_+l11l11lll11_l1_
			elif l11lll11l11_l1_==l1l111_l1_ (u"ࠬࡸࡩࡨࡪࡷࠫ㥕"): l1111l1lll1_l1_ = l1ll1111l111_l1_+l11l11lll11_l1_+l1l111111l1_l1_-width
			elif l11lll11l11_l1_==l1l111_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭㥖"): l1111l1lll1_l1_ = l1ll1111l111_l1_+l11l11lll11_l1_+(l1l111111l1_l1_-width)/2
			if l1111l1lll1_l1_<l11l11lll11_l1_: l1111l1lll1_l1_ = l1ll1111l111_l1_+l11l11lll11_l1_
			l1l1lll111ll_l1_.append(l1111l1lll1_l1_)
			l11l1lll11l_l1_.append(width)
		l1111l1lll1_l1_ = l1l1lll111ll_l1_[0]
		l1ll11ll11l1_l1_ = l1l1ll1l1111_l1_.split(l1l111_l1_ (u"ࠧࡠࡵࡶࡷࡤ࠭㥗"))
		l11llll1ll1_l1_ = (255,255,255,255)
		l1llll1ll1l1_l1_ = l11llll1ll1_l1_
		l1ll111l1lll_l1_,l1llll111111_l1_ = 0,0
		l111111l11l_l1_ = False
		l111l1l11ll_l1_ = 0
		l1ll1111l11l_l1_ = l11ll11111l_l1_+l1ll111ll11l_l1_/2
		if l11ll1lllll_l1_<(l1llllll111l_l1_+l1ll111ll11l_l1_):
			l111ll1111l_l1_ = (l1llllll111l_l1_+l1ll111ll11l_l1_-l11ll1lllll_l1_)/2
			l1ll1111l11l_l1_ = l11ll11111l_l1_+l1ll111ll11l_l1_+l111ll1111l_l1_-l1ll1llllll1_l1_/2
		for line in l1ll11ll11l1_l1_:
			if not line or (line and ord(line[0])==65279): continue
			l1ll1l11l11l_l1_ = line.split(l1l111_l1_ (u"ࠨࡡࡱࡩࡼࡲࡩ࡯ࡧࡢࠫ㥘"),1)
			l1ll1l11l1l1_l1_ = line.split(l1l111_l1_ (u"ࠩࡢࡲࡪࡽࡣࡰ࡮ࡲࡶࠬ㥙"),1)
			l1ll1l11l1ll_l1_ = line.split(l1l111_l1_ (u"ࠪࡣࡪࡴࡤࡤࡱ࡯ࡳࡷࡥࠧ㥚"),1)
			l1ll1l111l1l_l1_ = line.split(l1l111_l1_ (u"ࠫࡤࡲࡩ࡯ࡧࡵࡸࡱࡥࠧ㥛"),1)
			l1lllll11ll1_l1_ = line.split(l1l111_l1_ (u"ࠬࡥ࡬ࡪࡰࡨࡰࡪ࡬ࡴࡠࠩ㥜"),1)
			l1ll1l111lll_l1_ = line.split(l1l111_l1_ (u"࠭࡟࡭࡫ࡱࡩࡷ࡯ࡧࡩࡶࡢࠫ㥝"),1)
			l1ll1l11l111_l1_ = line.split(l1l111_l1_ (u"ࠧࡠ࡮࡬ࡲࡪࡩࡥ࡯ࡶࡨࡶࡤ࠭㥞"),1)
			if len(l1ll1l11l11l_l1_)>1:
				l111l1l11ll_l1_ += 1
				line = l1ll1l11l11l_l1_[1]
				l1ll111l1lll_l1_ = 0
				l1111l1lll1_l1_ = l1l1lll111ll_l1_[l111l1l11ll_l1_]
				l1llll111111_l1_ += l1ll111ll111_l1_
				l111111l11l_l1_ = False
			elif len(l1ll1l11l1l1_l1_)>1:
				line = l1ll1l11l1l1_l1_[1]
				l1llll1ll1l1_l1_ = line[0:8]
				l1llll1ll1l1_l1_ = l1l111_l1_ (u"ࠨࠥࠪ㥟")+l1llll1ll1l1_l1_[2:]
				line = line[9:]
			elif len(l1ll1l11l1ll_l1_)>1:
				line = l1ll1l11l1ll_l1_[1]
				l1llll1ll1l1_l1_ = l11llll1ll1_l1_
			elif len(l1ll1l111l1l_l1_)>1:
				line = l1ll1l111l1l_l1_[1]
				l111111l11l_l1_ = True
				l1ll111l1lll_l1_ = l11l1lll11l_l1_[l111l1l11ll_l1_]
			elif len(l1lllll11ll1_l1_)>1:
				line = l1lllll11ll1_l1_[1]
			elif len(l1ll1l111lll_l1_)>1:
				line = l1ll1l111lll_l1_[1]
			elif len(l1ll1l11l111_l1_)>1:
				line = l1ll1l11l111_l1_[1]
			if line:
				l1ll1l1lll11_l1_ = l1ll1111l11l_l1_+l1llll111111_l1_
				line = bidi.algorithm.get_display(line)
				width,l1lll11ll111_l1_ = l111ll1l1l1_l1_.textsize(line,font=l1llll1l1l1l_l1_)
				if l111111l11l_l1_: l1ll111l1lll_l1_ -= width
				l1111l1ll1l_l1_ = l1111l1lll1_l1_+l1ll111l1lll_l1_
				l111ll1l1l1_l1_.text((l1111l1ll1l_l1_,l1ll1l1lll11_l1_),line,font=l1llll1l1l1l_l1_,fill=l1llll1ll1l1_l1_)
				if not l111111l11l_l1_: l1ll111l1lll_l1_ += width
				if l1ll1l1lll11_l1_>l1llllll111l_l1_+l1ll111ll111_l1_: break
	l1lll111l1ll_l1_ = l1l1lll1ll11_l1_.replace(l1l111_l1_ (u"ࠩࡢ࠴࠵࠶࠰ࡠࠩ㥠"),l1l111_l1_ (u"ࠪࡣࠬ㥡")+str(time.time())+l1l111_l1_ (u"ࠫࡤ࠭㥢"))
	l1lll111l1ll_l1_ = l1lll111l1ll_l1_.replace(l1l111_l1_ (u"ࠬࡢ࡜ࠨ㥣"),l1l111_l1_ (u"࠭࡜࡝࡞࡟ࠫ㥤")).replace(l1l111_l1_ (u"ࠧ࠰࠱ࠪ㥥"),l1l111_l1_ (u"ࠨ࠱࠲࠳࠴࠭㥦"))
	if not os.path.exists(addoncachefolder): os.makedirs(addoncachefolder)
	l1ll111ll1l1_l1_.save(l1lll111l1ll_l1_)
	return l1lll111l1ll_l1_,l111llll1ll_l1_
def l1111ll1lll_l1_(method,url,data,headers,allow_redirects,l11_l1_,source,l11ll1l111l_l1_=True,l1ll1lllllll_l1_=True):
	if allow_redirects==l1l111_l1_ (u"ࠩࠪ㥧"): allow_redirects = True
	if l11_l1_==l1l111_l1_ (u"ࠪࠫ㥨"): l11_l1_ = True
	if l11ll1l111l_l1_==l1l111_l1_ (u"ࠫࠬ㥩"): l11ll1l111l_l1_ = True
	if l1ll1lllllll_l1_==l1l111_l1_ (u"ࠬ࠭㥪"): l1ll1lllllll_l1_ = True
	if not data: data = {}
	if not headers: headers = {}
	l1lll11lll1l_l1_ = list(headers.keys())
	if l1l111_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ㥫") not in l1lll11lll1l_l1_: headers[l1l111_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ㥬")] = l1l111_l1_ (u"ࠨࡂࡃࡄࡘࡑࡉࡑࡡࡋࡉࡆࡊࡅࡓࡂࡃࡄࠬ㥭")
	l1lllll1_l1_,l1ll111llll1_l1_,l1lll11111l1_l1_,l1ll1ll1l111_l1_ = l1ll111111ll_l1_(url)
	l1l1lll1l111_l1_ = settings.getSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡪ࡮ࡴ࠰ࡶࡩࡷࡼࡥࡳࠩ㥮"))
	l1ll111l11l1_l1_ = settings.getSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡤ࡯ࡵ࠱ࡷࡹࡧࡴࡶࡵࠪ㥯"))
	l1ll11l11lll_l1_ = settings.getSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡱࡴࡲࡼࡾ࠴ࡳࡵࡣࡷࡹࡸ࠭㥰"))
	l1ll1llll1ll_l1_ = (l1ll111llll1_l1_==None and l1lll11111l1_l1_==None and l1ll1ll1l111_l1_==None)
	l111ll111l1_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠬࡖ࡙ࡕࡊࡒࡒࠬ㥱")]
	l1ll111l1111_l1_ = l1lllll1_l1_ in l111ll111l1_l1_
	l111ll1ll11_l1_ = l1l11l1_l1_[l1l111_l1_ (u"࠭ࡒࡆࡒࡒࡗࠬ㥲")]
	l11ll1l1ll1_l1_ = l1lllll1_l1_ in l111ll1ll11_l1_
	l111lll11l1_l1_ = l1ll111l1111_l1_ or l11ll1l1ll1_l1_
	if l1ll1llll1ll_l1_ and l111lll11l1_l1_:
		if l1ll111l1111_l1_:
			l1llllll1111_l1_ = l111ll111l1_l1_.index(l1lllll1_l1_)
			l1111l1llll_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠧࡑ࡛ࡗࡌࡔࡔ࡟ࡃࡍࡓࠫ㥳")][l1llllll1111_l1_]
			l111l1l1111_l1_ = l1111lll111_l1_[l1llllll1111_l1_]
		elif l11ll1l1ll1_l1_:
			l1llllll1111_l1_ = l111ll1ll11_l1_.index(l1lllll1_l1_)
			l1111l1llll_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠨࡔࡈࡔࡔ࡙࡟ࡃࡍࡓࠫ㥴")][l1llllll1111_l1_]
			l111l1l1111_l1_ = l11l11l1ll1_l1_[l1llllll1111_l1_]
	if l1lll11111l1_l1_==l1l111_l1_ (u"ࠩࠪ㥵"): l1lll11111l1_l1_ = l1l1lll1l111_l1_
	elif l1lll11111l1_l1_==None and l1ll111l11l1_l1_ in [l1l111_l1_ (u"ࠪࡅ࡚࡚ࡏࠨ㥶"),l1l111_l1_ (u"ࠫࡆࡉࡃࡆࡒࡗࡉࡉ࠭㥷")] and l11ll1l111l_l1_: l1lll11111l1_l1_ = l1l1lll1l111_l1_
	l1lll1111111_l1_ = l1lllll1_l1_==l1l11l1_l1_[l1l111_l1_ (u"ࠬࡖ࡙ࡕࡊࡒࡒࠬ㥸")][7]
	if source==l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡅ࡝ࡕࡇࡓࡔࡡࡄࡏ࡜ࡇࡍࡠࡅࡄࡔ࡙ࡉࡈࡂ࠯࠶ࡶࡩ࠭㥹"): l1l111l111l_l1_ = 120
	elif source==l1l111_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡔࡈ࡚ࡊࡘࡓࡐࡡࡗࡖࡆࡔࡓࡍࡃࡗࡉ࠲࠷ࡳࡵࠩ㥺"): l1l111l111l_l1_ = 20
	elif source==l1l111_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡓࡔࡍࡌࡆࡡࡗࡖࡆࡔࡓࡍࡃࡗࡉ࠲࠷ࡳࡵࠩ㥻"): l1l111l111l_l1_ = 20
	elif source in l1lllll1lll1_l1_: l1l111l111l_l1_ = 10
	elif l1ll111l1111_l1_ or l11ll1l1ll1_l1_: l1l111l111l_l1_ = 15
	elif l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡋࡘࡃࡐࠫ㥼") in source: l1l111l111l_l1_ = 70
	elif l1l111_l1_ (u"ࠪࡗࡍࡕࡆࡉࡃࠪ㥽") in source: l1l111l111l_l1_ = 75
	elif l1l111_l1_ (u"ࠫࡈࡏࡍࡂ࠶ࡘࠫ㥾") in source: l1l111l111l_l1_ = 25
	elif l1l111_l1_ (u"ࠬࡇࡈࡘࡃࡎࠫ㥿") in source: l1l111l111l_l1_ = 20
	elif l1l111_l1_ (u"࠭ࡃࡊࡏࡄࡐࡎࡍࡈࡕࠩ㦀") in source: l1l111l111l_l1_ = 20
	elif l1l111_l1_ (u"ࠧࡄࡋࡐࡅࡈࡒࡕࡃ࡙ࡒࡖࡐ࠭㦁") in source: l1l111l111l_l1_ = 30
	elif l1l111_l1_ (u"ࠨࡃࡎࡓࡆࡓࠧ㦂") in source: l1l111l111l_l1_ = 25
	elif l1l111_l1_ (u"ࠩࡄࡏ࡜ࡇࡍࠨ㦃") in source: l1l111l111l_l1_ = 30
	elif l1l111_l1_ (u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠵ࠬ㦄") in source: l1l111l111l_l1_ = 20
	else: l1l111l111l_l1_ = 15
	if l1l111_l1_ (u"ࠫࡘࡎࡁࡉࡋࡇ࠸࡚࠭㦅") in source and not data and l1l111_l1_ (u"ࠬࠬࠧ㦆") not in l1lllll1_l1_ and l1l111_l1_ (u"࠭࠿ࠨ㦇") not in l1lllll1_l1_: l1lllll1_l1_ = l1lllll1_l1_.rstrip(l1l111_l1_ (u"ࠧ࠰ࠩ㦈"))+l1l111_l1_ (u"ࠨ࠱ࠪ㦉")
	l11ll1ll1l1_l1_ = (l1ll111llll1_l1_!=None)
	l1ll1lll1lll_l1_ = (l1lll11111l1_l1_!=None and l1ll111l11l1_l1_!=l1l111_l1_ (u"ࠩࡖࡘࡔࡖࠧ㦊"))
	if l11ll1ll1l1_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠪฮๆ฿๊ๅࠢหีํ้ำ๋ࠢิๆ๊࠭㦋"),l1ll111llll1_l1_)
	elif l1ll1lll1lll_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠫฯ็ู๋ๆࠣࡈࡓ࡙ࠠาไ่ࠫ㦌"),l1lll11111l1_l1_)
	if l11ll1ll1l1_l1_:
		proxies = {l1l111_l1_ (u"ࠧ࡮ࡴࡵࡲࠥ㦍"):l1ll111llll1_l1_,l1l111_l1_ (u"ࠨࡨࡵࡶࡳࡷࠧ㦎"):l1ll111llll1_l1_}
		l1lllllll111_l1_ = l1ll111llll1_l1_
	else: proxies,l1lllllll111_l1_ = {},l1l111_l1_ (u"ࠧࠨ㦏")
	if l1ll1lll1lll_l1_:
		import urllib3.util.connection as connection
		l11l111l111_l1_ = l1l1lllll11l_l1_(connection,l1l1lll1l111_l1_)
	verify = True
	l1ll11l1llll_l1_,l1ll1l1l1l11_l1_,l1l11lll1_l1_,l11lll1l1l1_l1_,l11ll1ll111_l1_ = allow_redirects,source,method,False,False
	if l1lll1111111_l1_: l11ll1ll111_l1_ = True
	if l111lll11l1_l1_ or allow_redirects: l1ll11l1llll_l1_ = False
	if l1ll111l1111_l1_: l1l11lll1_l1_ = l1l111_l1_ (u"ࠨࡒࡒࡗ࡙࠭㦐")
	import requests
	code,reason = -1,l1l111_l1_ (u"ࠩࡘࡲࡰࡴ࡯ࡸࡰࠣࡉࡷࡸ࡯ࡳࠩ㦑")
	for l1l111lll1_l1_ in range(9):
		l1llll1l1lll_l1_ = True
		succeeded = False
		try:
			if l1l111lll1_l1_: l1ll1l1l1l11_l1_ = l1l111_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤࡘࡅࡒࡗࡈࡗ࡙࡙࠭࠲ࡵࡷࠫ㦒")
			if not l11ll1ll1l1_l1_: l1l1l1ll1l1_l1_(l1l111_l1_ (u"ࠫࡗࡋࡑࡖࡇࡖࡘࡘࠦࠠࡐࡒࡈࡒࡤ࡛ࡒࡍࠩ㦓"),l1lllll1_l1_,data,headers,l1ll1l1l1l11_l1_,l1l11lll1_l1_)
			try: response.close()
			except: pass
			l1llllll_l1_ = l1lllll1_l1_
			response = requests.request(l1l11lll1_l1_,l1lllll1_l1_,data=data,headers=headers,verify=verify,allow_redirects=l1ll11l1llll_l1_,timeout=l1l111l111l_l1_,proxies=proxies)
			if 300<=response.status_code<=399:
				if not l11lll1l1l1_l1_:
					l1llllllll11_l1_ = list(response.headers.keys())
					if l1l111_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ㦔") in l1llllllll11_l1_: l1lllll1_l1_ = response.headers[l1l111_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ㦕")]
					elif l1l111_l1_ (u"ࠧ࡭ࡱࡦࡥࡹ࡯࡯࡯ࠩ㦖") in l1llllllll11_l1_: l1lllll1_l1_ = response.headers[l1l111_l1_ (u"ࠨ࡮ࡲࡧࡦࡺࡩࡰࡰࠪ㦗")]
					else: l11lll1l1l1_l1_ = True
					if not l11lll1l1l1_l1_: l1lllll1_l1_ = l1lllll1_l1_.encode(l1l111_l1_ (u"ࠩ࡯ࡥࡹ࡯࡮࠮࠳ࠪ㦘"),l1l111_l1_ (u"ࠪ࡭࡬ࡴ࡯ࡳࡧࠪ㦙")).decode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㦚"),l1l111_l1_ (u"ࠬ࡯ࡧ࡯ࡱࡵࡩࠬ㦛"))
					if l111lll11l1_l1_ and response.status_code==307:
						l1ll11l1llll_l1_ = allow_redirects
						l1l11lll1_l1_ = method
						l11lll1l1l1_l1_ = True
						l1lll11ll11l_l1_
				if not l11lll1l1l1_l1_ or allow_redirects:
					if l1l111_l1_ (u"࠭ࡨࡵࡶࡳࠫ㦜") not in l1lllll1_l1_:
						server = l1l111l_l1_(l1llllll_l1_,l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ㦝"))
						l1lllll1_l1_ = server+l1l111_l1_ (u"ࠨ࠱ࠪ㦞")+l1lllll1_l1_
				if not l11lll1l1l1_l1_ and allow_redirects:
					l11ll11ll1_l1_ = l1l111l1l1_l1_(l1lllll1_l1_)
					if l11ll11ll1_l1_ not in [l1l111_l1_ (u"ࠩ࠱ࡥࡻ࡯ࠧ㦟"),l1l111_l1_ (u"ࠪ࠲ࡹࡹࠧ㦠"),l1l111_l1_ (u"ࠫ࠳ࡳࡰ࠵ࠩ㦡"),l1l111_l1_ (u"ࠬ࠴ࡡࡢࡥࠪ㦢"),l1l111_l1_ (u"࠭࠮࡮࡭ࡹࠫ㦣"),l1l111_l1_ (u"ࠧ࠯࡯ࡳ࠷ࠬ㦤"),l1l111_l1_ (u"ࠨ࠰ࡺࡩࡧࡳࠧ㦥")]: l1lll11ll11l_l1_
			elif 550<=response.status_code<=599:
				response.reason = response.content
				l11ll1ll111_l1_ = True
			l1llllll_l1_ = response.url
			code = response.status_code
			reason = response.reason
			response.raise_for_status()
			succeeded = True
		except requests.exceptions.HTTPError as err:
			pass
		except requests.exceptions.Timeout as err:
			if PY2: reason = str(err.message).split(l1l111_l1_ (u"ࠩ࠽ࠤࠬ㦦"))[1]
			else: reason = str(err).split(l1l111_l1_ (u"ࠪ࠾ࠥ࠭㦧"))[1]
		except requests.exceptions.ConnectionError as err:
			try:
				error = err.message[0]
				reason = error
				if l1l111_l1_ (u"ࠫࡊࡸࡲ࡯ࡱࠪ㦨") in error: code,reason = re.findall(l1l111_l1_ (u"ࠧࡢ࡛ࡆࡴࡵࡲࡴࠦࠨ࡝ࡦ࠮࠭ࡡࡣࠠࠩ࠰࠭ࡃ࠮࠭ࠢ㦩"),error)[0]
				elif l1l111_l1_ (u"࠭ࠬࠡࡧࡵࡶࡴࡸࠨࠨ㦪") in error: code,reason = re.findall(l1l111_l1_ (u"ࠢ࠭ࠢࡨࡶࡷࡵࡲ࡝ࠪࠫࡠࡩ࠱ࠩ࠭ࠢࠪࠬ࠳࠰࠿ࠪࠩࠥ㦫"),error)[0]
				elif error.count(l1l111_l1_ (u"ࠨ࠼ࠪ㦬"))>=2: reason,code = re.findall(l1l111_l1_ (u"ࠩ࠽ࠤ࠭࠴ࠪࡀࠫ࠽࠲࠯ࡅࠨ࡝ࡦ࠮࠭ࠬ㦭"),error)[0]
			except: pass
		except requests.exceptions.RequestException as err:
			if PY2: reason = err.message
			else: reason = str(err)
		except:
			l1llll1l1lll_l1_ = False
			try: code = response.status_code
			except: pass
			try: reason = response.reason
			except: pass
		reason = str(reason)
		l11llllll1_l1_(l1l111_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ㦮"),l1l111_l1_ (u"ࠫ࠳ࠦࠠࡐࡒࡈࡒ࡚ࡘࡌࡠࡔࡈࡕ࡚ࡋࡓࡕࡕࠣࠤࡗࡋࡓࡑࡑࡑࡗࡊࠦࠠࡄࡱࡧࡩ࠿࡛ࠦࠡࠩ㦯")+str(code)+l1l111_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡖࡪࡧࡳࡰࡰ࠽ࠤࡠࠦࠧ㦰")+reason+l1l111_l1_ (u"࠭ࠠ࡞ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨ㦱")+source+l1l111_l1_ (u"ࠧࠡ࡟ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭㦲")+l1lllll1_l1_+l1l111_l1_ (u"ࠨࠢࡠࠫ㦳"))
		if l1llll1l1lll_l1_ and l111lll11l1_l1_ and not l11ll1ll111_l1_ and code!=200:
			l1lllll1_l1_ = l1111l1llll_l1_
			l11ll1ll111_l1_ = True
			continue
		if l1llll1l1lll_l1_: break
	if l1lll11111l1_l1_!=None and l1ll111l11l1_l1_!=l1l111_l1_ (u"ࠩࡖࡘࡔࡖࠧ㦴"): connection.create_connection = l11l111l111_l1_
	if l1ll111l11l1_l1_==l1l111_l1_ (u"ࠪࡅࡑ࡝ࡁ࡚ࡕࠪ㦵") and l11ll1l111l_l1_: l1lll11111l1_l1_ = None
	if not succeeded and l1ll111llll1_l1_==None and source not in l1lllll1lll1_l1_:
		l1111ll1l11_l1_ = traceback.format_exc()
		sys.stderr.write(l1111ll1l11_l1_)
	l1lll1l11_l1_ = l1l1lllll11_l1_()
	l1lll1l11_l1_.url = l1llllll_l1_
	try: content = response.content
	except: content = l1l111_l1_ (u"ࠫࠬ㦶")
	try: headers = response.headers
	except: headers = {}
	try: cookies = response.cookies.get_dict()
	except: cookies = {}
	try: response.close()
	except: pass
	if PY3:
		try: content = content.decode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㦷"))
		except: pass
	code = int(code)
	l1lll1l11_l1_.code = code
	l1lll1l11_l1_.reason = reason
	l1lll1l11_l1_.content = content
	l1lll1l11_l1_.headers = headers
	l1lll1l11_l1_.cookies = cookies
	l1lll1l11_l1_.succeeded = succeeded
	if PY2 or isinstance(l1lll1l11_l1_.content,str): l1ll111l11ll_l1_ = l1lll1l11_l1_.content.lower()
	else: l1ll111l11ll_l1_ = l1l111_l1_ (u"࠭ࠧ㦸")
	l1llll111l11_l1_ = (l1l111_l1_ (u"ࠧࡤ࡮ࡲࡹࡩ࡬࡬ࡢࡴࡨࠫ㦹") in l1ll111l11ll_l1_ or l1l111_l1_ (u"ࠨࡩࡲࡳ࡬ࡲࡥࠨ㦺") in l1ll111l11ll_l1_) and l1ll111l11ll_l1_.count(l1l111_l1_ (u"ࠩࡵࡩࡨࡧࡰࡵࡥ࡫ࡥࠬ㦻"))>2 and l1l111_l1_ (u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠵ࠬ㦼") not in source and l1l111_l1_ (u"ࠫࡷ࡫ࡣࡢࡲࡷࡧ࡭ࡧ࠭ࡵࡱ࡮ࡩࡳ࠭㦽") not in l1ll111l11ll_l1_
	if code==200 and l1llll111l11_l1_: l1lll1l11_l1_.succeeded = False
	if l1lll1l11_l1_.succeeded and l1ll1llll1ll_l1_ and l111lll11l1_l1_:
		if l1lll1111111_l1_: l111l1l1111_l1_ = l1l111_l1_ (u"ࠬࡉࡁࡑࡖࡆࡌࡆ࠭㦾")+data[l1l111_l1_ (u"࠭ࡪࡰࡤࠪ㦿")].upper().replace(l1l111_l1_ (u"ࠧࡈࡇࡗࠫ㧀"),l1l111_l1_ (u"ࠨࠩ㧁"))
		l1lll11ll_l1_ = l1l1llllll1_l1_(l111l1l1111_l1_)
	if not l1lll1l11_l1_.succeeded and l1ll1llll1ll_l1_:
		l1llll1111l1_l1_ = (l1l111_l1_ (u"ࠩࡦࡰࡴࡻࡤࡧ࡮ࡤࡶࡪ࠭㧂") in l1ll111l11ll_l1_ and l1l111_l1_ (u"ࠪࡶࡦࡿࠠࡪࡦ࠽ࠤࠬ㧃") in l1ll111l11ll_l1_)
		l1llll1111ll_l1_ = (l1l111_l1_ (u"ࠫ࠺ࠦࡳࡦࡥࠪ㧄") in l1ll111l11ll_l1_ and l1l111_l1_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷ࠭㧅") in l1ll111l11ll_l1_)
		l1llll111l1l_l1_ = (code in [403] and l1l111_l1_ (u"࠭ࡥࡳࡴࡲࡶࠥࡩ࡯ࡥࡧ࠽ࠤ࠶࠶࠲࠱ࠩ㧆") in l1ll111l11ll_l1_)
		l1llll111ll1_l1_ = (l1l111_l1_ (u"ࠧࡠࡥࡩࡣࡨ࡮࡬ࡠࠩ㧇") in l1ll111l11ll_l1_ and l1l111_l1_ (u"ࠨࡥ࡫ࡥࡱࡲࡥ࡯ࡩࡨ࠱ࠬ㧈") in l1ll111l11ll_l1_)
		if   l1llll111l11_l1_: reason = l1l111_l1_ (u"ࠩࡅࡰࡴࡩ࡫ࡦࡦࠣࡦࡾࠦࡲࡦࡥࡤࡴࡹࡩࡨࡢࠩ㧉")
		elif l1llll1111l1_l1_: reason = l1l111_l1_ (u"ࠪࡆࡱࡵࡣ࡬ࡧࡧࠤࡧࡿࠠࡤ࡮ࡲࡹࡩ࡬࡬ࡢࡴࡨࠫ㧊")
		elif l1llll1111ll_l1_: reason = l1l111_l1_ (u"ࠫࡇࡲ࡯ࡤ࡭ࡨࡨࠥࡨࡹࠡ࠷ࠣࡷࡪࡩ࡯࡯ࡦࡶࠤࡧࡸ࡯ࡸࡵࡨࡶࠥࡩࡨࡦࡥ࡮ࠫ㧋")
		elif l1llll111l1l_l1_: reason = l1l111_l1_ (u"ࠬࡈ࡬ࡰࡥ࡮ࡩࡩࠦࡢࡺࠢࡦࡰࡴࡻࡤࡧ࡮ࡤࡶࡪࠦࡡࡤࡥࡨࡷࡸࠦࡤࡦࡰ࡬ࡩࡩ࠭㧌")
		elif l1llll111ll1_l1_: reason = l1l111_l1_ (u"࠭ࡂ࡭ࡱࡦ࡯ࡪࡪࠠࡣࡻࠣࡧࡱࡵࡵࡥࡨ࡯ࡥࡷ࡫ࠠࡴࡧࡦࡹࡷ࡯ࡴࡺࠢࡦ࡬ࡪࡩ࡫ࠨ㧍")
		else: reason = str(reason)
		if source in l1lllll1lll1_l1_:
			l11llllll1_l1_(l1l111_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋ࡟ࡍࡋࡑࡉࡘ࠭㧎"),l11llll11l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠨࠢࠣࡈ࡮ࡸࡥࡤࡶࠣࡧࡴࡴ࡮ࡦࡥࡷ࡭ࡴࡴࠠࡧࡣ࡬ࡰࡪࡪࠠࠡࠢࡆࡳࡩ࡫࠺ࠡ࡝ࠣࠫ㧏")+str(code)+l1l111_l1_ (u"ࠩࠣࡡࠥࠦࡒࡦࡣࡶࡳࡳࡀࠠ࡜ࠢࠪ㧐")+reason+l1l111_l1_ (u"ࠪࠤࡢࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬ㧑")+source+l1l111_l1_ (u"ࠫࠥࡣࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ㧒")+l1lllll1_l1_+l1l111_l1_ (u"ࠬࠦ࡝ࠨ㧓"))
		else: l11llllll1_l1_(l1l111_l1_ (u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫ㧔"),l11llll11l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠧࠡࠢࠣࡈ࡮ࡸࡥࡤࡶࠣࡧࡴࡴ࡮ࡦࡥࡷ࡭ࡴࡴࠠࡧࡣ࡬ࡰࡪࡪࠠࠡࠢࡆࡳࡩ࡫࠺ࠡ࡝ࠣࠫ㧕")+str(code)+l1l111_l1_ (u"ࠨࠢࡠࠤࠥࠦࡒࡦࡣࡶࡳࡳࡀࠠ࡜ࠢࠪ㧖")+reason+l1l111_l1_ (u"ࠩࠣࡡࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫ㧗")+source+l1l111_l1_ (u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ㧘")+l1lllll1_l1_+l1l111_l1_ (u"ࠫࠥࡣࠧ㧙"))
		l11111ll1ll_l1_ = l111l11_l1_(l1lllll1_l1_)
		if PY2 and isinstance(l11111ll1ll_l1_,unicode): l11111ll1ll_l1_ = l11111ll1ll_l1_.encode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㧚"))
		if l111lll11l1_l1_: l11111ll1ll_l1_ = l11111ll1ll_l1_.split(l1l111_l1_ (u"࠭࠯ࠨ㧛"))[-1]
		reason = str(reason)+l1l111_l1_ (u"ࠧ࡝ࡰࠫࠤࠬ㧜")+l11111ll1ll_l1_+l1l111_l1_ (u"ࠨࠢࠬࠫ㧝")
		if l1llll111l11_l1_ or l1llll1111l1_l1_ or l1llll1111ll_l1_ or l1llll111l1l_l1_ or l1llll111ll1_l1_:
			code = -2
			l1lll1l11_l1_.code = code
			l1lll1l11_l1_.reason = reason
		l1llll111l_l1_ = True
		if (l1ll111l11l1_l1_==l1l111_l1_ (u"ࠩࡄࡗࡐ࠭㧞") or l1ll11l11lll_l1_==l1l111_l1_ (u"ࠪࡅࡘࡑࠧ㧟")) and (l11ll1l111l_l1_ or l1ll1lllllll_l1_):
			l1llll111l_l1_ = l1llll1lllll_l1_(code,reason,source,l11_l1_)
			if l1llll111l_l1_ and l1ll111l11l1_l1_==l1l111_l1_ (u"ࠫࡆ࡙ࡋࠨ㧠"): l1ll111l11l1_l1_ = l1l111_l1_ (u"ࠬࡇࡃࡄࡇࡓࡘࡊࡊࠧ㧡")
			else: l1ll111l11l1_l1_ = l1l111_l1_ (u"࠭ࡒࡆࡌࡈࡇ࡙ࡋࡄࠨ㧢")
			if l1llll111l_l1_ and l1ll11l11lll_l1_==l1l111_l1_ (u"ࠧࡂࡕࡎࠫ㧣"): l1ll11l11lll_l1_ = l1l111_l1_ (u"ࠨࡃࡆࡇࡊࡖࡔࡆࡆࠪ㧤")
			else: l1ll11l11lll_l1_ = l1l111_l1_ (u"ࠩࡕࡉࡏࡋࡃࡕࡇࡇࠫ㧥")
			settings.setSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡤ࡯ࡵ࠱ࡷࡹࡧࡴࡶࡵࠪ㧦"),l1ll111l11l1_l1_)
			settings.setSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡱࡴࡲࡼࡾ࠴ࡳࡵࡣࡷࡹࡸ࠭㧧"),l1ll11l11lll_l1_)
		if l1llll111l_l1_:
			l1l1lll1lll1_l1_ = True
			if code==8 and l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶࠫ㧨") in l1lllll1_l1_ and l1l1lll1lll1_l1_:
				if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"࠭สโ฻ํ่ࠥ็อึࠢื๋ฬีษࠡษ็ฮู็๊าࠢࡖࡗࡑ࠭㧩"),l1l111_l1_ (u"ࠧๅวุ่ฬำࠠๆึๆ่ฮࠦวๅว้ฮึ์๊หࠩ㧪"),time=2000)
				l1llllll_l1_ = l1lllll1_l1_+l1l111_l1_ (u"ࠨࡾࡿࡑࡾ࡙ࡓࡍࡗࡵࡰࡂ࠭㧫")
				l1lll11ll_l1_ = l1111ll1lll_l1_(method,l1llllll_l1_,data,headers,allow_redirects,l11_l1_,source)
				if l1lll11ll_l1_.succeeded:
					l1lll1l11_l1_ = l1lll11ll_l1_
					l11llllll1_l1_(l1l111_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࡡࡏࡍࡓࡋࡓࠨ㧬"),l11llll11l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠪࠤࠥࠦࡓࡶࡥࡦࡩࡪࡪࡥࡥࠢࡸࡷ࡮ࡴࡧࠡࡕࡖࡐ࠿ࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬ㧭")+source+l1l111_l1_ (u"ࠫࠥࡣࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ㧮")+url+l1l111_l1_ (u"ࠬࠦ࡝ࠨ㧯"))
					if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"࠭ๆอษะࠤออำหะาห๊ࠦࡓࡔࡎࠪ㧰"),l1l111_l1_ (u"ࠧๅวุ่ฬำࠠๆึๆ่ฮࠦวๅว้ฮึ์๊หࠩ㧱"),time=2000)
				else:
					l11llllll1_l1_(l1l111_l1_ (u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭㧲"),l11llll11l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠩࠣࠤࠥࡌࡡࡪ࡮ࡨࡨࠥࡻࡳࡪࡰࡪࠤࡘ࡙ࡌ࠻ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨ㧳")+source+l1l111_l1_ (u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ㧴")+url+l1l111_l1_ (u"ࠫࠥࡣࠧ㧵"))
					if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠬ็ิๅࠢหหุะฮะษ่ࠤࡘ࡙ࡌࠨ㧶"),l1l111_l1_ (u"࠭ไฦื็หาࠦๅีๅ็อࠥอไฦ่อี๋๐สࠨ㧷"),time=2000)
			if not l1lll1l11_l1_.succeeded and l1ll11l11lll_l1_ in [l1l111_l1_ (u"ࠧࡂࡗࡗࡓࠬ㧸"),l1l111_l1_ (u"ࠨࡃࡆࡇࡊࡖࡔࡆࡆࠪ㧹")] and l1ll1lllllll_l1_:
				if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠩอๅ฾๐ไࠡีํีๆืวหࠢหีํ้ำ๋ࠩ㧺"),l1l111_l1_ (u"่ࠪส฻ไศฯู้้ࠣไสࠢส่ส์สา่ํฮࠬ㧻"),time=2000)
				l1lll11ll_l1_ = l11ll1l11ll_l1_(method,l1lllll1_l1_,data,headers,allow_redirects,l11_l1_,source)
				if l1lll11ll_l1_.succeeded:
					l1lll1l11_l1_ = l1lll11ll_l1_
					l11llllll1_l1_(l1l111_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࡣࡑࡏࡎࡆࡕࠪ㧼"),l11llll11l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠬࠦࠠࠡࡒࡵࡳࡽ࡯ࡥࡴࠢࡶࡹࡨࡩࡥࡦࡦࡨࡨ࠿ࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬ㧽")+source+l1l111_l1_ (u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ㧾")+url+l1l111_l1_ (u"ࠧࠡ࡟ࠪ㧿"))
					if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠨ่ฯหาࠦำ๋ำไีฬะࠠษำ๋็ุ๐ࠧ㨀"),l1l111_l1_ (u"ࠩ็ษฺ๊วฮุ่่๊ࠢษࠡษ็ษ๋ะั็์อࠫ㨁"),time=2000)
				else:
					l11llllll1_l1_(l1l111_l1_ (u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨ㨂"),l11llll11l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠫࠥࠦࠠࡑࡴࡲࡼ࡮࡫ࡳࠡࡨࡤ࡭ࡱ࡫ࡤ࠻ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨ㨃")+source+l1l111_l1_ (u"ࠬࠦ࡝࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫ㨄")+url+l1l111_l1_ (u"࠭ࠠ࡞ࠩ㨅"))
					if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠧโึ็ࠤุ๐ัโำสฮࠥฮั้ๅึ๎ࠬ㨆"),l1l111_l1_ (u"ࠨๆศู้ออࠡ็ื็้ฯࠠศๆศ๊ฯืๆ๋ฬࠪ㨇"),time=2000)
			if not l1lll1l11_l1_.succeeded and l1ll111l11l1_l1_ in [l1l111_l1_ (u"ࠩࡄ࡙࡙ࡕࠧ㨈"),l1l111_l1_ (u"ࠪࡅࡈࡉࡅࡑࡖࡈࡈࠬ㨉")] and l11ll1l111l_l1_:
				if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠫฯ็ู๋ๆࠣื๏ืแาࠢࡇࡒࡘ࠭㨊"),l1l111_l1_ (u"๊ࠬลึๆสั๋ࠥิไๆฬࠤฬ๊ล็ฬิ๊๏ะࠧ㨋"),time=2000)
				l1llllll_l1_ = l1lllll1_l1_+l1l111_l1_ (u"࠭ࡼࡽࡏࡼࡈࡓ࡙ࡕࡳ࡮ࡀࠫ㨌")
				l1lll11ll_l1_ = l1111ll1lll_l1_(method,l1llllll_l1_,data,headers,allow_redirects,l11_l1_,source)
				if l1lll11ll_l1_.succeeded:
					l1lll1l11_l1_ = l1lll11ll_l1_
					l11llllll1_l1_(l1l111_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋ࡟ࡍࡋࡑࡉࡘ࠭㨍"),l11llll11l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠨࠢࠣࠤࡉࡔࡓࠡࡵࡸࡧࡨ࡫ࡥࡥࡧࡧ࠾ࠥࠦࠠࡅࡐࡖ࠾ࠥࡡࠠࠨ㨎")+l1l1lll1l111_l1_+l1l111_l1_ (u"ࠩࠣࡡࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫ㨏")+source+l1l111_l1_ (u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ㨐")+url+l1l111_l1_ (u"ࠫࠥࡣࠧ㨑"))
					if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠬ์ฬศฯࠣื๏ืแาࠢࡇࡒࡘ࠭㨒"),l1l111_l1_ (u"࠭ไฦื็หาࠦๅีๅ็อࠥอไฦ่อี๋๐สࠨ㨓"),time=2000)
				else:
					l11llllll1_l1_(l1l111_l1_ (u"ࠧࡆࡔࡕࡓࡗࡥࡌࡊࡐࡈࡗࠬ㨔"),l11llll11l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠨࠢࠣࠤࡉࡔࡓࠡࡨࡤ࡭ࡱ࡫ࡤ࠻ࠢࠣࠤࡉࡔࡓ࠻ࠢ࡞ࠤࠬ㨕")+l1l1lll1l111_l1_+l1l111_l1_ (u"ࠩࠣࡡࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫ㨖")+source+l1l111_l1_ (u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ㨗")+url+l1l111_l1_ (u"ࠫࠥࡣࠧ㨘"))
					if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠬ็ิๅࠢึ๎ึ็ัࠡࡆࡑࡗࠬ㨙"),l1l111_l1_ (u"࠭ไฦื็หาࠦๅีๅ็อࠥอไฦ่อี๋๐สࠨ㨚"),time=2000)
		if l1ll11l11lll_l1_==l1l111_l1_ (u"ࠧࡓࡇࡍࡉࡈ࡚ࡅࡅࠩ㨛") or l1ll111l11l1_l1_==l1l111_l1_ (u"ࠨࡔࡈࡎࡊࡉࡔࡆࡆࠪ㨜"): l11_l1_ = False
		if not l1lll1l11_l1_.succeeded:
			if l11_l1_: l11lll1ll11_l1_ = l1llll1lllll_l1_(code,reason,source,l11_l1_)
			if code!=200 and source not in l11l1l1l11l_l1_ and l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࠭㨝") not in source:
				l111111l1l1_l1_(l1l111_l1_ (u"ࠪࡊࡴࡸࡣࡦࡦࠣࡩࡽ࡯ࡴࠡࡦࡸࡩࠥࡺ࡯ࠡࡰࡨࡸࡼࡵࡲ࡬ࠢ࡬ࡷࡸࡻࡥࡴࠢࡺ࡭ࡹ࡮࠺ࠡࠩ㨞")+source)
	if settings.getSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡥࡰࡶ࠲ࡸࡺࡡࡵࡷࡶࠫ㨟")) not in [l1l111_l1_ (u"ࠬࡇࡕࡕࡑࠪ㨠"),l1l111_l1_ (u"࠭ࡓࡕࡑࡓࠫ㨡"),l1l111_l1_ (u"ࠧࡂࡕࡎࠫ㨢")]: settings.setSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡩࡴࡳ࠯ࡵࡷࡥࡹࡻࡳࠨ㨣"),l1l111_l1_ (u"ࠩࡄࡗࡐ࠭㨤"))
	if settings.getSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡰࡳࡱࡻࡽ࠳ࡹࡴࡢࡶࡸࡷࠬ㨥")) not in [l1l111_l1_ (u"ࠫࡆ࡛ࡔࡐࠩ㨦"),l1l111_l1_ (u"࡙ࠬࡔࡐࡒࠪ㨧"),l1l111_l1_ (u"࠭ࡁࡔࡍࠪ㨨")]: settings.setSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡴࡷࡵࡸࡺ࠰ࡶࡸࡦࡺࡵࡴࠩ㨩"),l1l111_l1_ (u"ࠨࡃࡖࡏࠬ㨪"))
	return l1lll1l11_l1_
def l11l1l_l1_(l1l1l1l1lll_l1_,method,url,data,headers,allow_redirects,l11_l1_,source,l11ll1l111l_l1_=True,l1ll1lllllll_l1_=True):
	item = method,url,data,headers,allow_redirects,l11_l1_
	if l1l1l1l1lll_l1_:
		response = l1lll11l111_l1_(main_dbfile,l1l111_l1_ (u"ࠩࡵࡩࡸࡶ࡯࡯ࡵࡨࠫ㨫"),l1l111_l1_ (u"ࠪࡓࡕࡋࡎࡖࡔࡏࡣࡗࡋࡑࡖࡇࡖࡘࡘ࠭㨬"),item)
		if response.succeeded:
			l1l1l1ll1l1_l1_(l1l111_l1_ (u"ࠫࡗࡋࡑࡖࡇࡖࡘࡘࠦࠠࡓࡇࡄࡈࡤࡉࡁࡄࡊࡈࠫ㨭"),url,data,headers,source,method)
			return response
	response = l1111ll1lll_l1_(method,url,data,headers,allow_redirects,l11_l1_,source,l11ll1l111l_l1_,l1ll1lllllll_l1_)
	if response.succeeded:
		if l1l111_l1_ (u"ࠬࡉࡉࡎࡃࡑࡓ࡜࠭㨮") in source: response.content = DECODE_ADILBO_HTML(response.content)
		if l1l1l1l1lll_l1_: l1lll111111_l1_(main_dbfile,l1l111_l1_ (u"࠭ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔࠩ㨯"),item,response,l1l1l1l1lll_l1_)
	return response
def l1l1llll_l1_(l1l1l1l1lll_l1_,url,data,headers,l11_l1_,source):
	if not data or isinstance(data,dict): method = l1l111_l1_ (u"ࠧࡈࡇࡗࠫ㨰")
	else:
		method = l1l111_l1_ (u"ࠨࡒࡒࡗ࡙࠭㨱")
		data = l111l11_l1_(data)
		dummy,data = l1ll11ll1_l1_(data)
	response = l11l1l_l1_(l1l1l1l1lll_l1_,method,url,data,headers,True,l11_l1_,source)
	html = response.content
	html = str(html)
	return html
def l1ll111111ll_l1_(url):
	l1ll11l11l1l_l1_ = url.split(l1l111_l1_ (u"ࠩࡿࢀࠬ㨲"))
	l1lllll1_l1_,l1ll111llll1_l1_,l1lll11111l1_l1_,l1ll1ll1l111_l1_ = l1ll11l11l1l_l1_[0],None,None,None
	for item in l1ll11l11l1l_l1_:
		if l1l111_l1_ (u"ࠪࡑࡾࡖࡲࡰࡺࡼ࡙ࡷࡲ࠽ࠨ㨳") in item: l1ll111llll1_l1_ = item.split(l1l111_l1_ (u"ࠫࡂ࠭㨴"))[1]
		elif l1l111_l1_ (u"ࠬࡓࡹࡅࡐࡖ࡙ࡷࡲ࠽ࠨ㨵") in item: l1lll11111l1_l1_ = item.split(l1l111_l1_ (u"࠭࠽ࠨ㨶"))[1]
		elif l1l111_l1_ (u"ࠧࡎࡻࡖࡗࡑ࡛ࡲ࡭࠿ࠪ㨷") in item: l1ll1ll1l111_l1_ = item.split(l1l111_l1_ (u"ࠨ࠿ࠪ㨸"))[1]
	return l1lllll1_l1_,l1ll111llll1_l1_,l1lll11111l1_l1_,l1ll1ll1l111_l1_
def l11lll11lll_l1_(name):
	start,l1lll11l1l1_l1_,modified = l1l111_l1_ (u"ࠩࠪ㨹"),l1l111_l1_ (u"ࠪࠫ㨺"),l1l111_l1_ (u"ࠫࠬ㨻")
	name = name.replace(ltr,l1l111_l1_ (u"ࠬ࠭㨼")).replace(rtl,l1l111_l1_ (u"࠭ࠧ㨽"))
	tmp = re.findall(l1l111_l1_ (u"ࠧࠩ࠰ࠬࡠࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡢ࡝ࠩ࡞ࡺࡠࡼࡢࡷࠪࠢ࠮ࡠࡠࡢ࠯ࡄࡑࡏࡓࡗࡢ࡝ࠩ࠰࠭ࡃ࠮ࠪࠧ㨾"),name,re.DOTALL)
	if tmp: start,l1lll11l1l1_l1_,name = tmp[0]
	if start not in [l1l111_l1_ (u"ࠨࠢࠪ㨿"),l1l111_l1_ (u"ࠩ࠯ࠫ㩀"),l1l111_l1_ (u"ࠪࠫ㩁")]: modified = l1l111_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ㩂")
	if l1lll11l1l1_l1_: l1lll11l1l1_l1_ = l1l111_l1_ (u"ࠬࡥࠧ㩃")+l1lll11l1l1_l1_+l1l111_l1_ (u"࠭࡟ࠨ㩄")
	name = l1lll11l1l1_l1_+modified+name
	return name
def l1lllll11l1_l1_(url,l1ll1ll111ll_l1_,l1ll1lll11l1_l1_,l1lllll1ll1l_l1_,headers={}):
	l1l1ll1l1ll1_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ㩅"))
	l11l11llll1_l1_ = settings.getSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲࡭ࡵࡳࡵ࠰ࠪ㩆")+l1ll1ll111ll_l1_)
	if l1l1ll1l1ll1_l1_==l11l11llll1_l1_: settings.setSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳࡮࡯ࡴࡶ࠱ࠫ㩇")+l1ll1ll111ll_l1_,l1l111_l1_ (u"ࠪࠫ㩈"))
	if l11l11llll1_l1_: l1llllll_l1_ = url.replace(l1l1ll1l1ll1_l1_,l11l11llll1_l1_)
	else:
		l1llllll_l1_ = url
		l11l11llll1_l1_ = l1l1ll1l1ll1_l1_
	l1lll11ll_l1_ = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ㩉"),l1llllll_l1_,l1l111_l1_ (u"ࠬ࠭㩊"),headers,l1l111_l1_ (u"࠭ࠧ㩋"),l1l111_l1_ (u"ࠧࠨ㩌"),l1l111_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡓࡔࡍࡌࡆࡡࡑࡉ࡜ࡥࡈࡐࡕࡗࡒࡆࡓࡅ࠮࠳ࡶࡸࠬ㩍"))
	html = l1lll11ll_l1_.content
	if PY3:
		try: html = html.decode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㩎"),l1l111_l1_ (u"ࠪ࡭࡬ࡴ࡯ࡳࡧࠪ㩏"))
		except: pass
	if not l1lll11ll_l1_.succeeded or l1lllll1ll1l_l1_ not in html:
		l1ll1lll11l1_l1_ = l1ll1lll11l1_l1_.replace(l1l111_l1_ (u"ࠫࠥ࠭㩐"),l1l111_l1_ (u"ࠬ࠱ࠧ㩑"))
		l1lllll1_l1_ = l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲࡬ࡵ࡯ࡨ࡮ࡨ࠲ࡨࡵ࡭࠰ࡵࡨࡥࡷࡩࡨࡀࡳࡀࠫ㩒")+l1ll1lll11l1_l1_
		l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ㩓"):l1l111_l1_ (u"ࠨࠩ㩔")}
		l1lll1l11_l1_ = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭㩕"),l1lllll1_l1_,l1l111_l1_ (u"ࠪࠫ㩖"),l1ll1ll1l_l1_,l1l111_l1_ (u"ࠫࠬ㩗"),l1l111_l1_ (u"ࠬ࠭㩘"),l1l111_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡑࡒࡋࡑࡋ࡟ࡏࡇ࡚ࡣࡍࡕࡓࡕࡐࡄࡑࡊ࠳࠲࡯ࡦࠪ㩙"))
		if l1lll1l11_l1_.succeeded:
			html = l1lll1l11_l1_.content
			if PY3:
				try: html = html.decode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㩚"),l1l111_l1_ (u"ࠨ࡫ࡪࡲࡴࡸࡥࠨ㩛"))
				except: pass
			l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠩ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠴ࡢࡷࠫ࡞ࡂ࠲࠯ࡅࠨࡩࡶࡷࡴ࠳࠰࠿ࠪࠤࠪ㩜"),html,re.DOTALL)
			l1111l1l111_l1_ = [l11l11llll1_l1_]
			l111l111l11_l1_ = [l1l111_l1_ (u"ࠪࡥࡵࡱࠧ㩝"),l1l111_l1_ (u"ࠫ࡬ࡵ࡯ࡨ࡮ࡨࠫ㩞"),l1l111_l1_ (u"ࠬࡺࡷࡪࡶࡷࡩࡷ࠭㩟"),l1l111_l1_ (u"࠭ࡹࡰࡷࡷࡹࡧ࡫ࠧ㩠"),l1l111_l1_ (u"ࠧࡧࡣࡦࡩࡧࡵ࡯࡬ࠩ㩡")]
			for l1ll1ll_l1_ in l1ll_l1_:
				l11l11llll1_l1_ = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠨࡷࡵࡰࠬ㩢"))
				if any(value in l1ll1ll_l1_ for value in l111l111l11_l1_): continue
				if l11l11llll1_l1_ in l1111l1l111_l1_: continue
				if len(l1111l1l111_l1_)==9:
					l11llllll1_l1_(l1l111_l1_ (u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧ㩣"),l11llll11l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠪࠤࠥࠦࡇࡰࡱࡪࡰࡪࠦࡤࡪࡦࠣࡲࡴࡺࠠࡧࡱࡸࡲࡩࠦ࡮ࡦࡹࠣ࡬ࡴࡹࡴ࡯ࡣࡰࡩࠥࠦࠠࡔ࡫ࡷࡩ࠿࡛ࠦࠡࠩ㩤")+l1ll1ll111ll_l1_+l1l111_l1_ (u"ࠫࠥࡣࠠࠡࡑ࡯ࡨ࠿࡛ࠦࠡࠩ㩥")+l1l1ll1l1ll1_l1_+l1l111_l1_ (u"ࠬࠦ࡝ࠨ㩦"))
					settings.setSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰࡫ࡳࡸࡺ࠮ࠨ㩧")+l1ll1ll111ll_l1_,l1l111_l1_ (u"ࠧࠨ㩨"))
					break
				l1111l1l111_l1_.append(l11l11llll1_l1_)
				l1llllll_l1_ = url.replace(l1l1ll1l1ll1_l1_,l11l11llll1_l1_)
				l1lll11ll_l1_ = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ㩩"),l1llllll_l1_,l1l111_l1_ (u"ࠩࠪ㩪"),headers,l1l111_l1_ (u"ࠪࠫ㩫"),l1l111_l1_ (u"ࠫࠬ㩬"),l1l111_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡐࡑࡊࡐࡊࡥࡎࡆ࡙ࡢࡌࡔ࡙ࡔࡏࡃࡐࡉ࠲࠹ࡲࡥࠩ㩭"))
				html = l1lll11ll_l1_.content
				if l1lll11ll_l1_.succeeded and l1lllll1ll1l_l1_ in html:
					l11llllll1_l1_(l1l111_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊࡥࡌࡊࡐࡈࡗࠬ㩮"),l11llll11l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠧࠡࠢࠣࡋࡴࡵࡧ࡭ࡧࠣࡪࡴࡻ࡮ࡥࠢࡱࡩࡼࠦࡨࡰࡵࡷࡲࡦࡳࡥࠡࠢࠣࡗ࡮ࡺࡥ࠻ࠢ࡞ࠤࠬ㩯")+l1ll1ll111ll_l1_+l1l111_l1_ (u"ࠨࠢࡠࠤࠥࠦࡎࡦࡹ࠽ࠤࡠࠦࠧ㩰")+l11l11llll1_l1_+l1l111_l1_ (u"ࠩࠣࡡࠥࠦࡏ࡭ࡦ࠽ࠤࡠࠦࠧ㩱")+l1l1ll1l1ll1_l1_+l1l111_l1_ (u"ࠪࠤࡢ࠭㩲"))
					settings.setSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡩࡱࡶࡸ࠳࠭㩳")+l1ll1ll111ll_l1_,l11l11llll1_l1_)
					break
	return l11l11llll1_l1_,l1llllll_l1_,l1lll11ll_l1_
def TRANSLATE(text):
	dict = {
	 l1l111_l1_ (u"ࠬࡵ࡬ࡥࠩ㩴")			:l1l111_l1_ (u"࠭โะ์่ࠫ㩵")
	,l1l111_l1_ (u"ࠧࡥ࡫ࡶࡥࡧࡲࡥࡥࠩ㩶")		:l1l111_l1_ (u"ࠨ็อ์็็ࠧ㩷")
	,l1l111_l1_ (u"ࠩࡰ࡭ࡸࡹࡩ࡯ࡩࠪ㩸")		:l1l111_l1_ (u"้ࠪๆ่่ะࠩ㩹")
	,l1l111_l1_ (u"ࠫ࡬ࡵ࡯ࡥࠩ㩺")			:l1l111_l1_ (u"ࠬา๊ะࠩ㩻")
	,l1l111_l1_ (u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭㩼")		:l1l111_l1_ (u"ࠧโึ็ࠫ㩽")
	,l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㩾")		:l1l111_l1_ (u"่ࠩะ้ีࠧ㩿")
	,l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ㪀")		:l1l111_l1_ (u"ࠫๆ๐ฯ๋๊ࠪ㪁")
	,l1l111_l1_ (u"ࠬࡲࡩࡷࡧࠪ㪂")			:l1l111_l1_ (u"࠭โ็ษฬࠫ㪃")
	,l1l111_l1_ (u"ࠧࡢ࡭ࡲࡥࡲ࠭㪄")		:l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦรไ๊ส้ࠥอไใัํ้ࠬ㪅")
	,l1l111_l1_ (u"ࠩࡤ࡯ࡼࡧ࡭ࠨ㪆")		:l1l111_l1_ (u"้ࠪํู่ࠡลๆ์ฬ๋ࠠศๆฯำ๏ีࠧ㪇")
	,l1l111_l1_ (u"ࠫࡦࡱ࡯ࡢ࡯ࡦࡥࡲ࠭㪈")		:l1l111_l1_ (u"๋่ࠬใ฻ࠣว่๎วๆࠢๆห๊࠭㪉")
	,l1l111_l1_ (u"࠭ࡡ࡭ࡣࡵࡥࡧ࠭㪊")		:l1l111_l1_ (u"ࠧๆ๊ๅ฽้ࠥไࠡษ็฽ึฮࠧ㪋")
	,l1l111_l1_ (u"ࠨࡣ࡯ࡪࡦࡺࡩ࡮࡫ࠪ㪌")		:l1l111_l1_ (u"่ࠩ์็฿ࠠศๆ่๊อืࠠศๆไห฼๋๊ࠨ㪍")
	,l1l111_l1_ (u"ࠪࡥࡱࡱࡡࡸࡶ࡫ࡥࡷ࠭㪎")	:l1l111_l1_ (u"๊ࠫ๎โฺࠢๅ๊ฬฯࠠศๆๆ์ะืࠧ㪏")
	,l1l111_l1_ (u"ࠬࡧ࡬࡮ࡣࡤࡶࡪ࡬ࠧ㪐")		:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤ็์วสࠢส่๊฿วาใࠪ㪑")
	,l1l111_l1_ (u"ࠧࡢࡴࡥࡰ࡮ࡵ࡮ࡻࠩ㪒")		:l1l111_l1_ (u"ࠨ็๋ๆ฾ูࠦาส่ࠣ๏๎ๆำࠩ㪓")
	,l1l111_l1_ (u"ࠩࡨ࡫ࡾࡨࡥࡴࡶࡹ࡭ࡵ࠭㪔")	:l1l111_l1_ (u"้ࠪํู่ࠡษํะ๏ࠦศ๋ีอࠤࡻ࡯ࡰࠨ㪕")
	,l1l111_l1_ (u"ࠫࡪࡲࡣࡪࡰࡨࡱࡦ࠭㪖")		:l1l111_l1_ (u"๋่ࠬใ฻ࠣหู้๊็็สࠫ㪗")
	,l1l111_l1_ (u"࠭ࡨࡦ࡮ࡤࡰࠬ㪘")		:l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥํไศๆࠣ๎ํะ๊้สࠪ㪙")
	,l1l111_l1_ (u"ࠨࡥ࡬ࡱࡦ࡬ࡡ࡯ࡵࠪ㪚")		:l1l111_l1_ (u"่ࠩ์็฿ࠠิ์่หࠥ็ว็ิࠪ㪛")
	,l1l111_l1_ (u"ࠪࡷ࡭ࡧࡨࡪࡦ࠷ࡹࠬ㪜")		:l1l111_l1_ (u"๊ࠫ๎โฺࠢืห์ีࠠโ๊ิ๎ํ࠭㪝")
	,l1l111_l1_ (u"ࠬࡹࡨࡰࡱࡩࡱࡦࡾࠧ㪞")		:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤู๎แࠡ็ส็ุ࠭㪟")
	,l1l111_l1_ (u"ࠧࡢࡴࡤࡦࡸ࡫ࡥࡥࠩ㪠")		:l1l111_l1_ (u"ࠨ็๋ๆ฾ูࠦาสࠣื๏๐ฯࠨ㪡")
	,l1l111_l1_ (u"ࠩࡦ࡭ࡲࡧ࡮ࡰࡹࠪ㪢")		:l1l111_l1_ (u"้ࠪํู่ࠡีํ้ฬࠦๆศ๊ࠪ㪣")
	,l1l111_l1_ (u"ࠫࡰࡧࡲࡣࡣ࡯ࡥࡹࡼࠧ㪤")	:l1l111_l1_ (u"๋่ࠬใ฻ࠣๆ๋อษࠡๅิฬ้อมࠨ㪥")
	,l1l111_l1_ (u"࠭ࡹࡵࡤࡢࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬ㪦")	:l1l111_l1_ (u"ࠧๆ๊สๆ฾๊้ࠦฬํ์อ࠭㪧")
	,l1l111_l1_ (u"ࠨ࡯ࡼࡧ࡮ࡳࡡࠨ㪨")		:l1l111_l1_ (u"่ࠩ์็฿ࠠๆษํࠤุ๐ๅศࠩ㪩")
	,l1l111_l1_ (u"ࠪࡻࡪࡩࡩ࡮ࡣࠪ㪪")		:l1l111_l1_ (u"๊ࠫ๎โฺ๋ࠢ๎ู๊ࠥๆษࠪ㪫")
	,l1l111_l1_ (u"ࠬ࡬ࡡࡴࡧ࡯࡬ࡩ࠷ࠧ㪬")		:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤๆอีๅࠢส่ศ๎ไࠨ㪭")
	,l1l111_l1_ (u"ࠧࡧࡣࡶࡩࡱ࡮ࡤ࠳ࠩ㪮")		:l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦแศื็ࠤฬ๊หศ่ํࠫ㪯")
	,l1l111_l1_ (u"ࠩࡥࡳࡰࡸࡡࠨ㪰")		:l1l111_l1_ (u"้ࠪํู่ࠡสๆีฬ࠭㪱")
	,l1l111_l1_ (u"ࠫࡨ࡯࡭ࡢࡣࡥࡨࡴ࠭㪲")		:l1l111_l1_ (u"๋่ࠬใ฻ࠣื๏๋วࠡ฻หำํ࠭㪳")
	,l1l111_l1_ (u"࠭࡬ࡪࡸࡨࡸࡻ࠭㪴")		:l1l111_l1_ (u"ࠧๆๆไࠫ㪵")
	,l1l111_l1_ (u"ࠨ࡮࡬ࡦࡷࡧࡲࡺࠩ㪶")		:l1l111_l1_ (u"่่ࠩๆ࠭㪷")
	,l1l111_l1_ (u"ࠪࡱࡴࡼࡳ࠵ࡷࠪ㪸")		:l1l111_l1_ (u"๊ࠫ๎โฺ่ࠢ์ๆุࠠโ๊ิ๎ํ࠭㪹")
	,l1l111_l1_ (u"ࠬ࡬ࡡ࡫ࡧࡵࡷ࡭ࡵࡷࠨ㪺")	:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤๆาัࠡึ๋ࠫ㪻")
	,l1l111_l1_ (u"ࠧࡦࡩࡼࡦࡪࡹࡴࠨ㪼")		:l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦว๋ฮํࠤอ๐ำหࠩ㪽")
	,l1l111_l1_ (u"ࠩࡨ࡫ࡾࡨࡥࡴࡶ࠴ࠫ㪾")		:l1l111_l1_ (u"้ࠪํู่ࠡษํะ๏ࠦศ๋ีอࠤ࠶࠭㪿")
	,l1l111_l1_ (u"ࠫࡪ࡭ࡹࡣࡧࡶࡸ࠷࠭㫀")		:l1l111_l1_ (u"๋่ࠬใ฻ࠣห๏า๊ࠡสํืฯࠦ࠲ࠨ㫁")
	,l1l111_l1_ (u"࠭ࡥࡨࡻࡥࡩࡸࡺ࠳ࠨ㫂")		:l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥอ๊อ์ࠣฬ๏ูสࠡ࠵ࠪ㫃")
	,l1l111_l1_ (u"ࠨࡧࡪࡽࡧ࡫ࡳࡵ࠶ࠪ㫄")		:l1l111_l1_ (u"่ࠩ์็฿ࠠศ์ฯ๎ࠥฮ๊ิฬࠣ࠸ࠬ㫅")
	,l1l111_l1_ (u"ࠪࡧ࡮ࡳࡡ࠵ࡷࠪ㫆")		:l1l111_l1_ (u"๊ࠫ๎โฺࠢึ๎๊อࠠโ๊ิ๎ํ࠭㫇")
	,l1l111_l1_ (u"ࠬ࡫ࡧࡺࡰࡲࡻࠬ㫈")		:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤส๐ฬ๋้ࠢหํ࠭㫉")
	,l1l111_l1_ (u"ࠧࡦࡩࡼࡨࡪࡧࡤࠨ㫊")		:l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦล๋ฮํࠤิ๐ฯࠨ㫋")
	,l1l111_l1_ (u"ࠩ࡫ࡥࡱࡧࡣࡪ࡯ࡤࠫ㫌")		:l1l111_l1_ (u"้ࠪํู่้ࠡ็หู๊ࠥๆษࠪ㫍")
	,l1l111_l1_ (u"ࠫࡱࡵࡤࡺࡰࡨࡸࠬ㫎")		:l1l111_l1_ (u"๋่ࠬใ฻่ࠣํี๊่ࠡอࠫ㫏")
	,l1l111_l1_ (u"࠭ࡴࡷࡨࡸࡲࠬ㫐")		:l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥะ๊โ์ࠣๅฬ์ࠧ㫑")
	,l1l111_l1_ (u"ࠨࡥ࡬ࡱࡦࡲࡩࡨࡪࡷࠫ㫒")	:l1l111_l1_ (u"่ࠩ์็฿ࠠิ์่ห๊ࠥว๋ฬࠪ㫓")
	,l1l111_l1_ (u"ࠪࡷ࡭ࡧࡨࡪࡦࡱࡩࡼࡹࠧ㫔")	:l1l111_l1_ (u"๊ࠫ๎โฺࠢืห์ีࠠ็์๋ึࠬ㫕")
	,l1l111_l1_ (u"ࠬ࡬࡯ࡴࡶࡤࠫ㫖")		:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤๆ๎ำหษࠪ㫗")
	,l1l111_l1_ (u"ࠧࡢࡪࡺࡥࡰ࠭㫘")		:l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦร่๊ส็ࠥะ๊โ์ࠪ㫙")
	,l1l111_l1_ (u"ࠩࡩࡥࡧࡸࡡ࡬ࡣࠪ㫚")		:l1l111_l1_ (u"้ࠪํู่ࠡใหี่ฯࠧ㫛")
	,l1l111_l1_ (u"ࠫࡨ࡯࡭ࡢࡥ࡯ࡹࡧࡽ࡯ࡳ࡭ࠪ㫜")	:l1l111_l1_ (u"๋่ࠬใ฻ࠣื๏๋วࠡๅ็์อูࠦๆๆࠪ㫝")
	,l1l111_l1_ (u"࠭ࡣࡪ࡯ࡤࡧࡱࡻࡢࠨ㫞")		:l1l111_l1_ (u"ࠧๆ๊ๅ฽ู๊ࠥๆษࠣ็้๎ศࠨ㫟")
	,l1l111_l1_ (u"ࠨࡵ࡫ࡳ࡫࡮ࡡࠨ㫠")		:l1l111_l1_ (u"่ࠩ์็฿ࠠี๊ไ๋ฬࠦส๋ใํࠫ㫡")
	,l1l111_l1_ (u"ࠪࡦࡷࡹࡴࡦ࡬ࠪ㫢")		:l1l111_l1_ (u"๊ࠫ๎โฺࠢหีุะ๊อࠩ㫣")
	,l1l111_l1_ (u"ࠬࡩࡩ࡮ࡣ࠷࠴࠵࠭㫤")		:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤุ๐ๅศࠢ࠷࠴࠵࠭㫥")
	,l1l111_l1_ (u"ࠧ࡭ࡣࡵࡳࡿࡧࠧ㫦")		:l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦไศำ๋ึฬ࠭㫧")
	,l1l111_l1_ (u"ࠩࡼࡥࡶࡵࡴࠨ㫨")		:l1l111_l1_ (u"้ࠪํู่ࠡ์สๆํะࠧ㫩")
	,l1l111_l1_ (u"ࠫࡰࡧࡴ࡬ࡱࡸࡸࡪ࠭㫪")		:l1l111_l1_ (u"๋่ࠬใ฻ࠣ็ฯ้่หࠩ㫫")
	,l1l111_l1_ (u"࠭࡫ࡢࡶ࡮ࡳࡹࡺࡶࠨ㫬")		:l1l111_l1_ (u"ࠧๆ๊ๅ฽้ࠥสไ๊อࠤฯ๐แ๋ࠩ㫭")
	,l1l111_l1_ (u"ࠨࡣࡵࡥࡧ࡯ࡣࡵࡱࡲࡲࡸ࠭㫮")	:l1l111_l1_ (u"่ࠩ์็฿ࠠห๊้ึࠥ฿ัษ์ฬࠫ㫯")
	,l1l111_l1_ (u"ࠪࡨࡷࡧ࡭ࡢࡵ࠺ࠫ㫰")		:l1l111_l1_ (u"๊ࠫ๎โฺࠢาีฬ๋วࠡืะࠫ㫱")
	,l1l111_l1_ (u"ࠬࡹࡨࡰࡱࡩࡴࡷࡵࠧ㫲")		:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤู๎แࠡสิ์ࠬ㫳")
	,l1l111_l1_ (u"ࠧࡪࡨ࡬ࡰࡲ࠭㫴")				:l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦโ็ษฬࠤว๐ࠠโ์็้ࠬ㫵")
	,l1l111_l1_ (u"ࠩ࡬ࡪ࡮ࡲ࡭࠮ࡣࡵࡥࡧ࡯ࡣࠨ㫶")			:l1l111_l1_ (u"้ࠪํู่ࠡไ้หฮࠦย๋ࠢไ๎ฺ้๋ࠠำห๎ࠬ㫷")
	,l1l111_l1_ (u"ࠫ࡮࡬ࡩ࡭࡯࠰ࡩࡳ࡭࡬ࡪࡵ࡫ࠫ㫸")		:l1l111_l1_ (u"๋่ࠬใ฻ࠣๆ๋อษࠡฤํࠤๆ๐ไๆࠢส๊ั๊๊ำ์ࠪ㫹")
	,l1l111_l1_ (u"࠭ࡰࡢࡰࡨࡸࠬ㫺")				:l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥฮว็์อࠫ㫻")
	,l1l111_l1_ (u"ࠨࡲࡤࡲࡪࡺ࠭࡮ࡱࡹ࡭ࡪࡹࠧ㫼")			:l1l111_l1_ (u"่ࠩ์็฿ࠠษษ้๎ฯࠦวโๆส้ࠬ㫽")
	,l1l111_l1_ (u"ࠪࡴࡦࡴࡥࡵ࠯ࡶࡩࡷ࡯ࡥࡴࠩ㫾")			:l1l111_l1_ (u"๊ࠫ๎โฺࠢหห๋๐สࠡ็ึุ่๊วหࠩ㫿")
	,l1l111_l1_ (u"ࠬࡿ࡯ࡶࡶࡸࡦࡪ࠭㬀")				:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤ๏๎ส๋๊หࠫ㬁")
	,l1l111_l1_ (u"ࠧࡺࡱࡸࡸࡺࡨࡥ࠮ࡸ࡬ࡨࡪࡵࡳࠨ㬂")		:l1l111_l1_ (u"ࠨ็๋ๆ฾๊้ࠦฬํ์อࠦแ๋ัํ์์อสࠨ㬃")
	,l1l111_l1_ (u"ࠩࡼࡳࡺࡺࡵࡣࡧ࠰ࡴࡱࡧࡹ࡭࡫ࡶࡸࡸ࠭㬄")	:l1l111_l1_ (u"้ࠪํู่ࠡ์๋ฮ๏๎ศࠡไ๋หห๋ࠧ㬅")
	,l1l111_l1_ (u"ࠫࡾࡵࡵࡵࡷࡥࡩ࠲ࡩࡨࡢࡰࡱࡩࡱࡹࠧ㬆")		:l1l111_l1_ (u"๋่ࠬใ฻ࠣ๎ํะ๊้สࠣๆ๋๎วหࠩ㬇")
	,l1l111_l1_ (u"࠭ࡳࡩ࡫ࡤࡺࡴ࡯ࡣࡦࠩ㬈")			:l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥ฻่หࠢสู่๐ูสࠩ㬉")
	,l1l111_l1_ (u"ࠨࡵ࡫࡭ࡦࡼ࡯ࡪࡥࡨ࠱ࡵ࡫ࡲࡴࡱࡱࡷࠬ㬊")	:l1l111_l1_ (u"่ࠩ์็฿ࠠึ๊อࠤฬ๊ิ๋฻ฬࠤ็อัวࠩ㬋")
	,l1l111_l1_ (u"ࠪࡷ࡭࡯ࡡࡷࡱ࡬ࡧࡪ࠳ࡡ࡭ࡤࡸࡱࡸ࠭㬌")		:l1l111_l1_ (u"๊ࠫ๎โฺุࠢ์ฯࠦวๅึํ฽ฮࠦวๅส๋้ࠬ㬍")
	,l1l111_l1_ (u"ࠬࡹࡨࡪࡣࡹࡳ࡮ࡩࡥ࠮ࡣࡸࡨ࡮ࡵࡳࠨ㬎")		:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤฺ๎สࠡษ็ุ๏฿ษࠡื๋ฮ๏อสࠨ㬏")
	,l1l111_l1_ (u"ࠧࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲࠬ㬐")			:l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦฯ๋ๆํࠤ๊๎ิ็ࠩ㬑")
	,l1l111_l1_ (u"ࠩࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴ࠭ࡷ࡫ࡧࡩࡴࡹࠧ㬒")	:l1l111_l1_ (u"้ࠪํู่ࠡัํ่๏ࠦๅ้ึ้ࠤๆ๐ฯ๋๊๊หฯ࠭㬓")
	,l1l111_l1_ (u"ࠫࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯࠯ࡳࡰࡦࡿ࡬ࡪࡵࡷࡷࠬ㬔"):l1l111_l1_ (u"๋่ࠬใ฻ࠣำ๏๊๊ࠡ็ุ๋๋ࠦโ้ษษ้ࠬ㬕")
	,l1l111_l1_ (u"࠭ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱ࠱ࡨ࡮ࡡ࡯ࡰࡨࡰࡸ࠭㬖")	:l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥี๊ๅ์้ࠣํฺๆࠡไ้์ฬะࠧ㬗")
	,l1l111_l1_ (u"ࠨࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠳ࡴࡰࡲ࡬ࡧࡸ࠭㬘")	:l1l111_l1_ (u"่ࠩ์็฿ࠠะ์็๎๋่ࠥี่้ࠣํอึ๋฻ࠪ㬙")
	,l1l111_l1_ (u"ࠪ࡭ࡵࡺࡶࠨ㬚")					:l1l111_l1_ (u"ࠫࡎࡖࡔࡗࠩ㬛")
	,l1l111_l1_ (u"ࠬ࡯ࡰࡵࡸ࠰ࡰ࡮ࡼࡥࠨ㬜")			:l1l111_l1_ (u"࠭ࡉࡑࡖ࡙ࠤ็์่ศฬࠪ㬝")
	,l1l111_l1_ (u"ࠧࡪࡲࡷࡺ࠲ࡳ࡯ࡷ࡫ࡨࡷࠬ㬞")			:l1l111_l1_ (u"ࠨࡋࡓࡘ࡛ࠦรโๆส้ࠬ㬟")
	,l1l111_l1_ (u"ࠩ࡬ࡴࡹࡼ࠭ࡴࡧࡵ࡭ࡪࡹࠧ㬠")			:l1l111_l1_ (u"ࠪࡍࡕ࡚ࡖࠡ็ึุ่๊วหࠩ㬡")
	,l1l111_l1_ (u"ࠫࡲ࠹ࡵࠨ㬢")					:l1l111_l1_ (u"ࠬࡓ࠳ࡖࠩ㬣")
	,l1l111_l1_ (u"࠭࡭࠴ࡷ࠰ࡰ࡮ࡼࡥࠨ㬤")				:l1l111_l1_ (u"ࠧࡎ࠵ࡘࠤ็์่ศฬࠪ㬥")
	,l1l111_l1_ (u"ࠨ࡯࠶ࡹ࠲ࡳ࡯ࡷ࡫ࡨࡷࠬ㬦")			:l1l111_l1_ (u"ࠩࡐ࠷࡚ࠦรโๆส้ࠬ㬧")
	,l1l111_l1_ (u"ࠪࡱ࠸ࡻ࠭ࡴࡧࡵ࡭ࡪࡹࠧ㬨")			:l1l111_l1_ (u"ࠫࡒ࠹ࡕࠡ็ึุ่๊วหࠩ㬩")
	}
	try: result = dict[text.lower()]
	except: result = l1l111_l1_ (u"ࠬ࠭㬪")
	return result
def l111111l1l1_l1_(message=l1l111_l1_ (u"࠭ࠧ㬫")):
	l1ll1lll1l11_l1_()
	if message: sys.exit(message)
	else: sys.exit()
	return
def QUOTE(urll,exceptions=l1l111_l1_ (u"ࠧ࠻࠱ࠪ㬬")):
	return _1llll1l11ll_l1_(urll,exceptions)
def l11l111111l_l1_(l1l1llll1_l1_):
	if l1l1llll1_l1_ in [l1l111_l1_ (u"ࠨࠩ㬭"),l1l111_l1_ (u"ࠩ࠳ࠫ㬮"),0]: return l1l111_l1_ (u"ࠪࠫ㬯")
	l1l1llll1_l1_ = int(l1l1llll1_l1_)
	l11l1l1l1l1_l1_ = l1l1llll1_l1_^l1ll1ll1_l1_
	l111l1lll11_l1_ = l1l1llll1_l1_^l11l1l1_l1_
	l111l111_l1_ = l1l1llll1_l1_^l111l11l_l1_
	result = str(l11l1l1l1l1_l1_)+str(l111l1lll11_l1_)+str(l111l111_l1_)
	return result
def l1ll11l111l1_l1_(l1l1llll1_l1_):
	if l1l1llll1_l1_ in [l1l111_l1_ (u"ࠫࠬ㬰"),l1l111_l1_ (u"ࠬ࠶ࠧ㬱"),0]: return l1l111_l1_ (u"࠭ࠧ㬲")
	l1l1llll1_l1_ = str(l1l1llll1_l1_)
	result = l1l111_l1_ (u"ࠧࠨ㬳")
	if len(l1l1llll1_l1_)==15:
		l11l1l1l1l1_l1_,l111l1lll11_l1_,l111l111_l1_ = l1l1llll1_l1_[0:4],l1l1llll1_l1_[4:9],l1l1llll1_l1_[9:]
		l11l1l1l1l1_l1_ = int(l11l1l1l1l1_l1_)^l111l11l_l1_
		l111l1lll11_l1_ = int(l111l1lll11_l1_)^l11l1l1_l1_
		l111l111_l1_ = int(l111l111_l1_)^l1ll1ll1_l1_
		if l11l1l1l1l1_l1_==l111l1lll11_l1_==l111l111_l1_: result = str(l11l1l1l1l1_l1_*60)
	return result
def l1ll1llll111_l1_(l1l1llll1_l1_,l1lll111l11l_l1_=l1l111_l1_ (u"ࠨ࠸࠶࠼࠹࠷࠸࠳࠵ࠪ㬴")):
	if l1l1llll1_l1_==l1l111_l1_ (u"ࠩࠪ㬵"): return l1l111_l1_ (u"ࠪࠫ㬶")
	l1l1llll1_l1_ = int(l1l1llll1_l1_)+int(l1lll111l11l_l1_)
	l11l1l1l1l1_l1_ = l1l1llll1_l1_^l1ll1ll1_l1_
	l111l1lll11_l1_ = l1l1llll1_l1_^l11l1l1_l1_
	l111l111_l1_ = l1l1llll1_l1_^l111l11l_l1_
	result = str(l11l1l1l1l1_l1_)+str(l111l1lll11_l1_)+str(l111l111_l1_)
	return result
def l1111111lll_l1_(l1l1llll1_l1_,l1lll111l11l_l1_=l1l111_l1_ (u"ࠫ࠻࠹࠸࠵࠳࠻࠶࠸࠭㬷")):
	if l1l1llll1_l1_==l1l111_l1_ (u"ࠬ࠭㬸"): return l1l111_l1_ (u"࠭ࠧ㬹")
	l1l1llll1_l1_ = str(l1l1llll1_l1_)
	l1l1l1l1111_l1_ = int(len(l1l1llll1_l1_)/3)
	l11l1l1l1l1_l1_ = int(l1l1llll1_l1_[0:l1l1l1l1111_l1_])^l1ll1ll1_l1_
	l111l1lll11_l1_ = int(l1l1llll1_l1_[l1l1l1l1111_l1_:2*l1l1l1l1111_l1_])^l11l1l1_l1_
	l111l111_l1_ = int(l1l1llll1_l1_[2*l1l1l1l1111_l1_:3*l1l1l1l1111_l1_])^l111l11l_l1_
	result = l1l111_l1_ (u"ࠧࠨ㬺")
	if l11l1l1l1l1_l1_==l111l1lll11_l1_==l111l111_l1_: result = str(int(l11l1l1l1l1_l1_)-int(l1lll111l11l_l1_))
	return result
def l1l1ll111l1_l1_(l1l11ll111l_l1_):
	l1llll11l1l1_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠨࡒ࡜ࡘࡍࡕࡎࠨ㬻")][8]
	l1111ll1111_l1_ = l1l1ll111ll_l1_(32)
	l1ll1l1llll1_l1_ = os.path.join(l1l1l1l1ll1_l1_,l1l111_l1_ (u"ࠩࡵࡩࡸࡵࡵࡳࡥࡨࡷࠬ㬼"),l1l111_l1_ (u"ࠪࡷࡰ࡯࡮ࡴࠩ㬽"),l1l111_l1_ (u"ࠫࡉ࡫ࡦࡢࡷ࡯ࡸࠬ㬾"),l1l111_l1_ (u"ࠬ࠽࠲࠱ࡲࠪ㬿"),l1l111_l1_ (u"࠭ࡄࡪࡣ࡯ࡳ࡬ࡉ࡯࡯ࡨ࡬ࡶࡲ࡚ࡨࡳࡧࡨࡆࡺࡺࡴࡰࡰࡶ࠲ࡽࡳ࡬ࠨ㭀"))
	l11ll111lll_l1_,l111lll1l1l_l1_ = l1ll1l11ll_l1_(l1ll1l1llll1_l1_)
	l11ll111lll_l1_ = l1ll1llll111_l1_(l11ll111lll_l1_,l1l111_l1_ (u"ࠧ࠲࠴࠴࠼࠸࠷࠸࠶࠵ࠪ㭁"))
	l111l1l1lll_l1_ = {l1l111_l1_ (u"ࠨ࡫ࡧࡷࠬ㭂"):l1l111_l1_ (u"ࠩࡇࡍࡆࡒࡏࡈࠩ㭃"),l1l111_l1_ (u"ࠪࡹࡸࡸࠧ㭄"):l1111ll1111_l1_,l1l111_l1_ (u"ࠫࡻ࡫ࡲࠨ㭅"):l1l11l1l1l1_l1_,l1l111_l1_ (u"ࠬࡹࡣࡳࠩ㭆"):l1l11ll111l_l1_,l1l111_l1_ (u"࠭ࡳࡪࡼࠪ㭇"):l11ll111lll_l1_}
	l1lll11l11ll_l1_ = {l1l111_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭㭈"):l1l111_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪࠧ㭉")}
	l1llll1l111l_l1_ = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ㭊"),l1llll11l1l1_l1_,l111l1l1lll_l1_,l1lll11l11ll_l1_,l1l111_l1_ (u"ࠪࠫ㭋"),l1l111_l1_ (u"ࠫࠬ㭌"),l1l111_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡓࡉࡑ࡚ࡣࡕࡒࡁ࡚ࡡࡇࡍࡆࡒࡏࡈ࠯࠴ࡷࡹ࠭㭍"))
	l1l1llll1111_l1_ = l1llll1l111l_l1_.content
	try:
		if not l1l1llll1111_l1_: l1ll111l1ll1_l1_
		l1lll11l1111_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"࠭ࡤࡪࡥࡷࠫ㭎"),l1l1llll1111_l1_)
		l1l1lll1l1ll_l1_ = l1lll11l1111_l1_[l1l111_l1_ (u"ࠧ࡮ࡵࡪࠫ㭏")]
		l1ll111ll1ll_l1_ = l1lll11l1111_l1_[l1l111_l1_ (u"ࠨࡵࡨࡧࠬ㭐")]
		l1lll1l1l1l1_l1_ = l1lll11l1111_l1_[l1l111_l1_ (u"ࠩࡶࡸࡵ࠭㭑")]
		l1ll111ll1ll_l1_ = int(l1111111lll_l1_(l1ll111ll1ll_l1_,l1l111_l1_ (u"ࠪ࠵࠷࠷࠸࠴࠳࠻࠹࠸࠭㭒")))
		l1lll1l1l1l1_l1_ = int(l1111111lll_l1_(l1lll1l1l1l1_l1_,l1l111_l1_ (u"ࠫ࠶࠸࠱࠹࠵࠴࠼࠺࠹ࠧ㭓")))
		for l1111llll11_l1_ in range(l1ll111ll1ll_l1_,0,-l1lll1l1l1l1_l1_):
			if not eval(l1l111_l1_ (u"ࠬࡾࡢ࡮ࡥ࠱ࡔࡱࡧࡹࡦࡴࠫ࠭࠳࡯ࡳࡑ࡮ࡤࡽ࡮ࡴࡧࡗ࡫ࡧࡩࡴ࠮ࠩࠨ㭔")): l1ll111l1ll1_l1_
			l1ll1lll_l1_(l1l111_l1_ (u"࠭ศศไํࠤ้๊สอำหอࠥ๎วๅใะูࠬ㭕"),str(l1111llll11_l1_)+l1l111_l1_ (u"ࠧࠡࠢฮห๋๐ษࠨ㭖"),time=500)
			xbmc.sleep(l1lll1l1l1l1_l1_*1000)
		if eval(l1l111_l1_ (u"ࠨࡺࡥࡱࡨ࠴ࡐ࡭ࡣࡼࡩࡷ࠮ࠩ࠯࡫ࡶࡔࡱࡧࡹࡪࡰࡪ࡚࡮ࡪࡥࡰࠪࠬࠫ㭗")):
			l111l1ll111_l1_ = l1l111_l1_ (u"ࠤࡇࡍࡆࡒࡏࡈࡩࡢࡓࡐ࠮ࠧࠨ࠮ࠪาึ๎ฬࠨ࠮ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ࠬࠨࠤ㭘")+l1l1lll1l1ll_l1_+l1l111_l1_ (u"ࠥࠫ࠮ࠨ㭙")
			l111l1ll111_l1_ = l111l1ll111_l1_.replace(l1l111_l1_ (u"ࠫࡡࡴࠧ㭚"),l1l111_l1_ (u"ࠬࡢ࡜࡯ࠩ㭛")).replace(l1l111_l1_ (u"࠭࡜ࡳࠩ㭜"),l1l111_l1_ (u"ࠧ࡝࡞ࡵࠫ㭝"))
			exec(l111l1ll111_l1_)
		l1ll111l1ll1_l1_
	except: exec(l1l111_l1_ (u"ࠨࡺࡥࡱࡨ࠴ࡐ࡭ࡣࡼࡩࡷ࠮ࠩ࠯ࡵࡷࡳࡵ࠮ࠩࠨ㭞"))
	return
def l1l111l1l1l_l1_():
	exec(l1l111_l1_ (u"ࠩࠪࠫࠒࠐࡴࡳࡻ࠽ࠑࠏࠏࡷࡪࡰࡧࡳࡼ࠷࠲࠴ࠢࡀࠤࡽࡨ࡭ࡤࡩࡸ࡭࠳࡝ࡩ࡯ࡦࡲࡻ࠭࠷࠰࠱࠴࠸࠭ࠒࠐࠉࡸࡪ࡬ࡰࡪࠦࡔࡳࡷࡨ࠾ࠒࠐࠉࠊࡺࡥࡱࡨ࠴ࡳ࡭ࡧࡨࡴ࠭࠷࠰࠱࠲ࠬࠑࠏࠏࠉࡵࡴࡼ࠾ࠥࡽࡩ࡯ࡦࡲࡻ࠶࠸࠳࠯ࡩࡨࡸࡋࡵࡣࡶࡵࠫ࠵࠵࠶࠲࠶ࠫࠐࠎࠎࠏࡥࡹࡥࡨࡴࡹࡀࠠࡣࡴࡨࡥࡰࠓࠊࠊࡼࡦࡶࡪࡧࡴࡦࡡࡨࡶࡴࡸࡲࠎࠌࡨࡼࡨ࡫ࡰࡵ࠼ࠣࡼࡧࡳࡣ࠯ࡒ࡯ࡥࡾ࡫ࡲࠩࠫ࠱ࡷࡹࡵࡰࠩࠫࠐࠎࠬ࠭ࠧ㭟"))
	return
def l1ll1l11ll_l1_(file):
	size,count = 0,0
	if os.path.exists(file):
		try: size = os.path.getsize(file)
		except: pass
		if not size:
			try: size = os.stat(file).st_size
			except: pass
		if not size:
			try:
				from pathlib import Path
				size = Path(file).stat().st_size
			except: pass
		if size: count = 1
	return size,count
def l1llll1ll1_l1_(l1lllll11lll_l1_,l1ll11lllll1_l1_,l11_l1_):
	if l11_l1_:
		l1llll111l_l1_ = l1ll11ll1l_l1_(l1l111_l1_ (u"ࠪࠫ㭠"),l1l111_l1_ (u"ࠫࠬ㭡"),l1l111_l1_ (u"ࠬ࠭㭢"),l1l111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ㭣"),l1lllll11lll_l1_+l1l111_l1_ (u"ࠧ࡝ࡰ࡟ࡲࠬ㭤")+l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠ๋้ࠦสา์าࠤู๊อ้ࠡำหࠥอไๆฮ็ำࠥลࠡ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㭥"))
		if l1llll111l_l1_!=1: return
	error = False
	if os.path.exists(l1lllll11lll_l1_):
		for root,dirs,l11lllll1l_l1_ in os.walk(l1lllll11lll_l1_,topdown=False):
			for file in l11lllll1l_l1_:
				filepath = os.path.join(root,file)
				try: os.remove(filepath)
				except Exception as err:
					if l11_l1_ and not error: l1111l1_l1_(l1l111_l1_ (u"ࠩࠪ㭦"),l1l111_l1_ (u"ࠪࠫ㭧"),l1l111_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㭨"),str(err))
					error = True
			if l1ll11lllll1_l1_:
				for dir in dirs:
					l1l1ll1l11l1_l1_ = os.path.join(root,dir)
					try: os.rmdir(l1l1ll1l11l1_l1_)
					except: pass
		if l1ll11lllll1_l1_:
			try: os.rmdir(root)
			except: pass
	if l11_l1_ and not error:
		l1111l1_l1_(l1l111_l1_ (u"ࠬ࠭㭩"),l1l111_l1_ (u"࠭ࠧ㭪"),l1l111_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ㭫"),l1l111_l1_ (u"ࠨฬ่ࠤฬ๊ๅิฯࠣฬ๋าวฮࠩ㭬"))
		settings.setSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡸࡥࡧࡴࡨࡷ࡭࠴ࡳࡵࡣࡷࡹࡸ࠭㭭"),l1l111_l1_ (u"ࠪࡗࡔࡓࡅࡕࡊࡌࡒࡌ࠭㭮"))
		xbmc.executebuiltin(l1l111_l1_ (u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡓࡧࡩࡶࡪࡹࡨࠨ㭯"))
	return
def l1ll1lll1l11_l1_(l1111ll1l11_l1_=l1l111_l1_ (u"ࠬ࠭㭰")):
	if l1111ll1l11_l1_:
		l1llllllllll_l1_ = settings.getSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰࡯ࡥࡳ࡭ࡵࡢࡩࡨ࠲ࡹࡸࡡ࡯ࡵ࡯ࡥࡹ࡫ࠧ㭱"))
		settings.setSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡰࡦࡴࡧࡶࡣࡪࡩ࠳ࡺࡲࡢࡰࡶࡰࡦࡺࡥࠨ㭲"),l1l111_l1_ (u"ࠨࠩ㭳"))
		l11l11ll11l_l1_(l1111ll1l11_l1_)
		settings.setSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡲࡡ࡯ࡩࡸࡥ࡬࡫࠮ࡵࡴࡤࡲࡸࡲࡡࡵࡧࠪ㭴"),l1llllllllll_l1_)
	l1ll11l1l1_l1_ = settings.getSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡲࡦࡨࡵࡩࡸ࡮࠮ࡴࡶࡤࡸࡺࡹࠧ㭵"))
	if l1ll11l1l1_l1_==l1l111_l1_ (u"ࠫࡗࡋࡑࡖࡇࡖࡘࡊࡊࠧ㭶"): settings.setSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡴࡨࡪࡷ࡫ࡳࡩ࠰ࡶࡸࡦࡺࡵࡴࠩ㭷"),l1l111_l1_ (u"࠭ࡒࡆࡈࡕࡉࡘࡎࡅࡅࠩ㭸"))
	elif l1ll11l1l1_l1_==l1l111_l1_ (u"ࠧࡓࡇࡉࡖࡊ࡙ࡈࡆࡆࠪ㭹"): settings.setSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡷ࡫ࡦࡳࡧࡶ࡬࠳ࡹࡴࡢࡶࡸࡷࠬ㭺"),l1l111_l1_ (u"ࠩࠪ㭻"))
	if settings.getSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡤ࡯ࡵ࠱ࡷࡹࡧࡴࡶࡵࠪ㭼")) not in [l1l111_l1_ (u"ࠫࡆ࡛ࡔࡐࠩ㭽"),l1l111_l1_ (u"࡙ࠬࡔࡐࡒࠪ㭾"),l1l111_l1_ (u"࠭ࡁࡔࡍࠪ㭿")]: settings.setSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡨࡳࡹ࠮ࡴࡶࡤࡸࡺࡹࠧ㮀"),l1l111_l1_ (u"ࠨࡃࡖࡏࠬ㮁"))
	if settings.getSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡶࡲࡰࡺࡼ࠲ࡸࡺࡡࡵࡷࡶࠫ㮂")) not in [l1l111_l1_ (u"ࠪࡅ࡚࡚ࡏࠨ㮃"),l1l111_l1_ (u"ࠫࡘ࡚ࡏࡑࠩ㮄"),l1l111_l1_ (u"ࠬࡇࡓࡌࠩ㮅")]: settings.setSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡳࡶࡴࡾࡹ࠯ࡵࡷࡥࡹࡻࡳࠨ㮆"),l1l111_l1_ (u"ࠧࡂࡕࡎࠫ㮇"))
	l11llll1l1l_l1_ = settings.getSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡸࡱࡩ࡯࠰ࡹ࡭ࡪࡽ࡭ࡰࡦࡨࠫ㮈"))
	l11l111ll1l_l1_ = xbmc.executeJSONRPC(l1l111_l1_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡕࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡋࡪࡺࡓࡦࡶࡷ࡭ࡳ࡭ࡖࡢ࡮ࡸࡩࠧ࠲ࠢࡪࡦࠥ࠾࠶࠲ࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡷࡪࡺࡴࡪࡰࡪࠦ࠿ࠨ࡬ࡰࡱ࡮ࡥࡳࡪࡦࡦࡧ࡯࠲ࡸࡱࡩ࡯ࠤࢀࢁࠬ㮉"))
	if l1l111_l1_ (u"ࠪࡷࡰ࡯࡮࠯࡯ࡨࡸࡷࡵࡰࡰ࡮࡬ࡷࡊࡓࡁࡅࠩ㮊") in str(l11l111ll1l_l1_) and l11llll1l1l_l1_ in [l1l111_l1_ (u"ࠫࡊࡓࡁࡅࠢࡏ࡭ࡸࡺࠧ㮋"),l1l111_l1_ (u"ࠬࡋࡍࡂࡆࠣࡋࡦࡲ࡬ࡦࡴࡼࠫ㮌")]:
		time.sleep(0.100)
		xbmc.executebuiltin(l1l111_l1_ (u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡖࡩࡹ࡜ࡩࡦࡹࡐࡳࡩ࡫ࠨ࠱ࠫࠪ㮍"))
	if 0 and addon_handle>-1:
		xbmcplugin.setResolvedUrl(addon_handle,False,xbmcgui.ListItem())
		succeeded,l1111ll11l1_l1_,l11ll1l1l11_l1_ = False,False,False
		xbmcplugin.endOfDirectory(addon_handle,succeeded,l1111ll11l1_l1_,l11ll1l1l11_l1_)
	return
def l1llll1lll1_l1_(l1l1l1l1lll_l1_,method,url,data,headers,source):
	if l1l1l1l1lll_l1_:
		html = l1lll11l111_l1_(main_dbfile,l1l111_l1_ (u"ࠧࡴࡶࡵࠫ㮎"),l1l111_l1_ (u"ࠨࡑࡓࡉࡓ࡛ࡒࡍࡡࡘࡖࡑࡒࡉࡃࠩ㮏"),(method,url,data,headers))
		if html:
			l1l1l1ll1l1_l1_(l1l111_l1_ (u"ࠩࡘࡖࡑࡒࡉࡃࠢࠣࡖࡊࡇࡄࡠࡅࡄࡇࡍࡋࠧ㮐"),url,data,headers,source,method)
			return html
	html = l1l111l1ll1_l1_(method,url,data,headers,source)
	if html and l1l1l1l1lll_l1_: l1lll111111_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡓࡕࡋࡎࡖࡔࡏࡣ࡚ࡘࡌࡍࡋࡅࠫ㮑"),(method,url,data,headers),html,l1l1l1l1lll_l1_)
	return html
DIALOGg_OK = l1111l1_l1_
l11llllllll_l1_ = l11ll1l11l1_l1_
l11lll1ll1l_l1_ = l1ll1lll1111_l1_
DIALOGg_YESNO = l1ll11ll1l_l1_
DIALOGg_SELECT = l1ll11ll_l1_
DIALOGg_PROGRESS = l1l111ll1l_l1_
DIALOGg_TEXTVIEWER = l1ll111lll1l_l1_
DIALOGg_CONTEXTMENU = l11ll1111ll_l1_
l111l1111ll_l1_ = l11lllllll_l1_
DIALOGg_NOTIFICATION = l1ll1lll_l1_
DIALOGg_THREEBUTTONS_TIMEOUT = l1l1lll11111_l1_
l1ll1l1ll1l1_l1_ = l1l11l1l1l_l1_
SERVERr = l1l111l_l1_
OPENn_KEYBOARD = l1llll1_l1_
OPENURLl_CACHED = l1l1llll_l1_
SEARCHh_OPTIONS = l111ll_l1_
PROGRESSs_UPDATE = l1l111111l_l1_
DOWNLOADd_USING_PROGRESSBAR = l1llll111lll_l1_
OPENURLl_REQUESTS_CACHED = l11l1l_l1_
HOURr = l1l1l11111l_l1_
NO_CACHEe = l11ll11l_l1_
REGULAR_CACHEe = l11l1l1_l1_
VERYLONG_CACHEe = l1lll11l1ll_l1_
PERMANENT_CACHEe = l1ll111l11l_l1_
from EXCLUDES import *
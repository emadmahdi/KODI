# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠬࡉࡉࡎࡃࡑࡓ࡜࠭ᥐ")
l1lllll_l1_ = l1l111_l1_ (u"࠭࡟ࡄࡏࡑࡣࠬᥑ")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠧใษษ้ฯ๐ࠧᥒ")]
def l11l1ll_l1_(mode,url,text):
	if   mode==300: l1lll_l1_ = l1l1l11_l1_()
	elif mode==301: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==302: l1lll_l1_ = l1lll11_l1_(url)
	elif mode==303: l1lll_l1_ = l111l1lll_l1_(url)
	elif mode==304: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==305: l1lll_l1_ = PLAY(url)
	elif mode==306: l1lll_l1_ = l1llllll1l_l1_()
	elif mode==309: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ᥓ"),l1lllll_l1_+l1l111_l1_ (u"ࠩ็้ฬึวࠡษ็้ํู่ࠡสฺ๎ฦ࠭ᥔ"),l1l111_l1_ (u"ࠪࠫᥕ"),306)
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᥖ"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬᥗ"),l1l111_l1_ (u"࠭ࠧᥘ"),9999)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᥙ"),l1lllll_l1_+l1l111_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨᥚ"),l1l111_l1_ (u"ࠩࠪᥛ"),309,l1l111_l1_ (u"ࠪࠫᥜ"),l1l111_l1_ (u"ࠫࠬᥝ"),l1l111_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᥞ"))
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᥟ"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᥠ"),l1l111_l1_ (u"ࠨࠩᥡ"),9999)
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭ᥢ"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳࡭ࡵ࡭ࡦࠩᥣ"),l1l111_l1_ (u"ࠫࠬᥤ"),l1l111_l1_ (u"ࠬ࠭ᥥ"),l1l111_l1_ (u"࠭ࠧᥦ"),l1l111_l1_ (u"ࠧࠨᥧ"),l1l111_l1_ (u"ࠨࡅࡌࡑࡆࡔࡏࡘ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫᥨ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩ࠿࡬ࡪࡧࡤࡦࡴࡁࠬ࠳࠰࠿ࠪ࠾࠲࡬ࡪࡧࡤࡦࡴࡁࠫᥩ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠪࡀࡱ࡯࠾࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩᥪ"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		title = title.strip(l1l111_l1_ (u"ࠫࠥ࠭ᥫ"))
		if not any(value in title for value in l11lll_l1_):
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᥬ"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨᥭ")+l1lllll_l1_+title,l1ll1ll_l1_,301)
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ᥮"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ᥯"),l1l111_l1_ (u"ࠩࠪᥰ"),9999)
	l11ll1_l1_(l111l1_l1_+l1l111_l1_ (u"ࠪ࠳࡭ࡵ࡭ࡦࠩᥱ"),html)
	return html
def l1llllll1l_l1_():
	l1111l1_l1_(l1l111_l1_ (u"ࠫࠬᥲ"),l1l111_l1_ (u"ࠬ࠭ᥳ"),l1l111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᥴ"),l1l111_l1_ (u"ࠧๆ๊ๅ฽ู๊ࠥๆษ๊ࠣฬ๎ࠠษูํล๋ࠥๆࠡษ็ฺ้ีัࠡ࠰࠱ࠤอูศษࠢๅ๎ฬ๋ࠠฤืะหอࠦวๅ็๋ๆ฾ࠦศหึไ๎ึࠦๅฮฬ๋๎ฬะࠠอ็ํ฽ࠥ฻แฮษอࠤฬ๊ๅ้ไ฼ࠤ࠳࠴้ࠠษ็์็ะࠠศๆูหห฿๋ࠠา๊ฬࠥ็๊ࠡ็฼ห้าษࠡฬืๅ๏ืࠠศๆุๅาอสࠡษ็ู้็ัสࠢๅฬู้ࠦาุ้ࠣาะ่๋ษอ๋ฬࠦแ๋ࠢๅ์ฬฬๅ้ࠡำหࠥอไษำ้ห๊าࠧ᥵"))
	return
def l11ll1_l1_(url,html=l1l111_l1_ (u"ࠨࠩ᥶")):
	if not html:
		response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭᥷"),url,l1l111_l1_ (u"ࠪࠫ᥸"),l1l111_l1_ (u"ࠫࠬ᥹"),l1l111_l1_ (u"ࠬ࠭᥺"),l1l111_l1_ (u"࠭ࠧ᥻"),l1l111_l1_ (u"ࠧࡄࡋࡐࡅࡓࡕࡗ࠮ࡕࡘࡆࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭᥼"))
		html = response.content
	seq = 0
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠪ࠿ࡷࡪࡩࡴࡪࡱࡱࡂ࠳࠰࠿࠽࠱ࡶࡩࡨࡺࡩࡰࡰࡁ࠭ࠬ᥽"),html,re.DOTALL)
	if l11llll_l1_:
		for block in l11llll_l1_:
			seq += 1
			items = re.findall(l1l111_l1_ (u"ࠩ࠿ࡷࡪࡩࡴࡪࡱࡱࡂ࠳ࡂࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿ࠬ࠳࠰࠿ࠪࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ᥾"),block,re.DOTALL)
			for title,test,l1ll1ll_l1_ in items:
				title = title.strip(l1l111_l1_ (u"ࠪࠤࠬ᥿"))
				if title==l1l111_l1_ (u"ࠫࠬᦀ"): title = l1l111_l1_ (u"ࠬฮ่้๊๋์ࠬᦁ")
				if l1l111_l1_ (u"࠭ࡥ࡮ࡀ࠿ࡥࠬᦂ") not in test:
					if block.count(l1l111_l1_ (u"ࠧ࠰ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠲ࠫᦃ"))>0:
						l1llllll11_l1_ = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᦄ"),block,re.DOTALL)
						for l1ll1ll_l1_ in l1llllll11_l1_:
							title = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠩ࠲ࠫᦅ"))[-2]
							addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᦆ"),l1lllll_l1_+title,l1ll1ll_l1_,301)
						continue
					else: l1ll1ll_l1_ = url+l1l111_l1_ (u"ࠫࡄࡹࡥࡲࡷࡨࡲࡨ࡫࠽ࠨᦇ")+str(seq)
				if not any(value in title for value in l11lll_l1_):
					addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᦈ"),l1lllll_l1_+title,l1ll1ll_l1_,302)
	else: l1lll11_l1_(url,html)
	return
def l1lll11_l1_(url,html=l1l111_l1_ (u"࠭ࠧᦉ")):
	if html==l1l111_l1_ (u"ࠧࠨᦊ"):
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬᦋ"),url,l1l111_l1_ (u"ࠩࠪᦌ"),l1l111_l1_ (u"ࠪࠫᦍ"),l1l111_l1_ (u"ࠫࠬᦎ"),l1l111_l1_ (u"ࠬ࠭ᦏ"),l1l111_l1_ (u"࠭ࡃࡊࡏࡄࡒࡔ࡝࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫᦐ"))
		html = response.content
	if l1l111_l1_ (u"ࠧࡀࡵࡨࡵࡺ࡫࡮ࡤࡧࡀࠫᦑ") in url:
		url,seq = url.split(l1l111_l1_ (u"ࠨࡁࡶࡩࡶࡻࡥ࡯ࡥࡨࡁࠬᦒ"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠫࡀࡸ࡫ࡣࡵ࡫ࡲࡲࡃ࠴ࠪࡀ࠾࠲ࡷࡪࡩࡴࡪࡱࡱࡂ࠮࠭ᦓ"),html,re.DOTALL)
		block = l11llll_l1_[int(seq)-1]
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡵࡵࡳࡵࡵࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡦࡴࡪࡹ࠿ࠩᦔ"),html,re.DOTALL)
		block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠫࡁࡧ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠩ࠰࠭ࡃ࠮ࡪࡡࡵࡣ࠰ࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᦕ"),block,re.DOTALL)
	l1l1_l1_ = []
	for l1ll1ll_l1_,data,l1ll1l_l1_ in items:
		title = re.findall(l1l111_l1_ (u"ࠬࡂࡥ࡮ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡨࡱࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡲࡩ࠿࠰࠭ࡃࡁ࠵ࡥ࡮ࡀࠫ࠲࠯ࡅࠩ࠽ࡧࡰࡂࠬᦖ"),data,re.DOTALL)
		if title: title = title[0][2].replace(l1l111_l1_ (u"࠭࡜࡯ࠩᦗ"),l1l111_l1_ (u"ࠧࠨᦘ")).strip(l1l111_l1_ (u"ࠨࠢࠪᦙ"))
		if not title or title==l1l111_l1_ (u"ࠩࠪᦚ"):
			title = re.findall(l1l111_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠤࡁ࠲࠯ࡅ࠼࠰ࡧࡰࡂ࠭࠴ࠪࡀࠫ࠿ࠫᦛ"),data,re.DOTALL)
			if title: title = title[0].replace(l1l111_l1_ (u"ࠫࡡࡴࠧᦜ"),l1l111_l1_ (u"ࠬ࠭ᦝ")).strip(l1l111_l1_ (u"࠭ࠠࠨᦞ"))
			if not title or title==l1l111_l1_ (u"ࠧࠨᦟ"):
				title = re.findall(l1l111_l1_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨᦠ"),data,re.DOTALL)
				title = title[0].replace(l1l111_l1_ (u"ࠩ࡟ࡲࠬᦡ"),l1l111_l1_ (u"ࠪࠫᦢ")).strip(l1l111_l1_ (u"ࠫࠥ࠭ᦣ"))
		title = unescapeHTML(title)
		if title not in l1l1_l1_:
			l1l1_l1_.append(title)
			l1l1l1l_l1_ = l1ll1ll_l1_+data+l1ll1l_l1_
			if l1l111_l1_ (u"ࠬ࠵ࡳࡦ࡮ࡤࡶࡾ࠵ࠧᦤ") in l1l1l1l_l1_ or l1l111_l1_ (u"࠭ๅิๆึ่ࠬᦥ") in l1l1l1l_l1_ or l1l111_l1_ (u"ࠧࠣࡧࡳ࡭ࡸࡵࡤࡦࠤࠪᦦ") in l1l1l1l_l1_:
				if l1l111_l1_ (u"ࠨสิห๊าࠧᦧ") in data: title = l1l111_l1_ (u"ࠩหี๋อๅอࠢࠪᦨ")+title
				elif l1l111_l1_ (u"ุ้๊ࠪำๅࠩᦩ") in data or l1l111_l1_ (u"๊ࠫ๎ำๆࠩᦪ") in data: title = l1l111_l1_ (u"๋ࠬำๅี็ࠤࠬᦫ")+title
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭᦬"),l1lllll_l1_+title,l1ll1ll_l1_,303,l1ll1l_l1_)
			else: addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭᦭"),l1lllll_l1_+title,l1ll1ll_l1_,305,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ᦮"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࠿ࡰ࡮ࡄ࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ᦯"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᦰ"),l1lllll_l1_+l1l111_l1_ (u"ฺࠫ็อสࠢࠪᦱ")+title,l1ll1ll_l1_,302)
	return
def l111l1lll_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩᦲ"),url,l1l111_l1_ (u"࠭ࠧᦳ"),l1l111_l1_ (u"ࠧࠨᦴ"),l1l111_l1_ (u"ࠨࠩᦵ"),l1l111_l1_ (u"ࠩࠪᦶ"),l1l111_l1_ (u"ࠪࡇࡎࡓࡁࡏࡑ࡚࠱ࡘࡋࡁࡔࡑࡑࡗ࠲࠷ࡳࡵࠩᦷ"))
	html = response.content
	name = re.findall(l1l111_l1_ (u"ࠫࡁࡺࡩࡵ࡮ࡨࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡹ࡯ࡴ࡭ࡧࡁࠫᦸ"),html,re.DOTALL)
	name = name[0].replace(l1l111_l1_ (u"ࠬࢂࠠิ์่หࠥ์ว้ࠩᦹ"),l1l111_l1_ (u"࠭ࠧᦺ")).replace(l1l111_l1_ (u"ࠧࡄ࡫ࡰࡥࠥࡔ࡯ࡸࠩᦻ"),l1l111_l1_ (u"ࠨࠩᦼ")).strip(l1l111_l1_ (u"ࠩࠣࠫᦽ")).replace(l1l111_l1_ (u"ࠪࠤࠥ࠭ᦾ"),l1l111_l1_ (u"ࠫࠥ࠭ᦿ"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡳࡦࡣࡶࡳࡳࡹࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡧࡦࡸ࡮ࡵ࡮࠿ࠩᧀ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬᧁ"),block,re.DOTALL)
		if len(items)>1:
			for l1ll1ll_l1_,title in items:
				title = title.replace(l1l111_l1_ (u"ࠧ࡝ࡰࠪᧂ"),l1l111_l1_ (u"ࠨࠩᧃ")).strip(l1l111_l1_ (u"ࠩࠣࠫᧄ"))
				addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᧅ"),l1lllll_l1_+title,l1ll1ll_l1_,304)
		else: l1ll1l11_l1_(url)
	return
def l1ll1l11_l1_(url):
	if l1l111_l1_ (u"ࠫ࠴ࡹࡥ࡭ࡣࡵࡽ࠴࠭ᧆ") not in url: url = url.strip(l1l111_l1_ (u"ࠬ࠵ࠧᧇ"))+l1l111_l1_ (u"࠭࠯ࡸࡣࡷࡧ࡭࡯࡮ࡨࠩᧈ")
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫᧉ"),url,l1l111_l1_ (u"ࠨࠩ᧊"),l1l111_l1_ (u"ࠩࠪ᧋"),l1l111_l1_ (u"ࠪࠫ᧌"),l1l111_l1_ (u"ࠫࠬ᧍"),l1l111_l1_ (u"ࠬࡉࡉࡎࡃࡑࡓ࡜࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠳ࡶࡸࠬ᧎"))
	html = response.content
	if l1l111_l1_ (u"࠭࠯ࡴࡧ࡯ࡥࡷࡿ࠯ࠨ᧏") not in url:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡧࡳ࡭ࡸࡵࡤࡦࡵࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ᧐"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ᧑"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = title.replace(l1l111_l1_ (u"ࠩ࡟ࡲࠬ᧒"),l1l111_l1_ (u"ࠪࠫ᧓")).strip(l1l111_l1_ (u"ࠫࠥ࠭᧔"))
			title = l1l111_l1_ (u"ࠬอไฮๆๅอࠥ࠭᧕")+title
			addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ᧖"),l1lllll_l1_+title,l1ll1ll_l1_,305)
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡦࡨࡸࡦ࡯࡬ࡴࠤࠫ࠲࠯ࡅࠩࠣࡴࡨࡰࡦࡺࡥࡥࠤࠪ᧗"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡤࡰࡹࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ᧘"),block,re.DOTALL)
		for l1ll1ll_l1_,l1ll1l_l1_,title in items:
			title = title.replace(l1l111_l1_ (u"ࠩ࡟ࡲࠬ᧙"),l1l111_l1_ (u"ࠪࠫ᧚")).strip(l1l111_l1_ (u"ࠫࠥ࠭᧛"))
			addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ᧜"),l1lllll_l1_+title,l1ll1ll_l1_,305,l1ll1l_l1_)
	return
def PLAY(url):
	l1lllll1_l1_ = url+l1l111_l1_ (u"࠭ࡷࡢࡶࡦ࡬࡮ࡴࡧ࠰ࠩ᧝")
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ᧞"),l1lllll1_l1_,l1l111_l1_ (u"ࠨࠩ᧟"),l1l111_l1_ (u"ࠩࠪ᧠"),l1l111_l1_ (u"ࠪࠫ᧡"),l1l111_l1_ (u"ࠫࠬ᧢"),l1l111_l1_ (u"ࠬࡉࡉࡎࡃࡑࡓ࡜࠳ࡐࡍࡃ࡜࠱࠺ࡺࡨࠨ᧣"))
	html = response.content
	l1llll_l1_ = []
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡥࡱࡺࡲࡱࡵࡡࡥࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭᧤"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࠲࡭ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ᧥"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = title.replace(l1l111_l1_ (u"ࠨ࡞ࡱࠫ᧦"),l1l111_l1_ (u"ࠩࠪ᧧")).strip(l1l111_l1_ (u"ࠪࠤࠬ᧨"))
			l111l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡡࡪ࡜ࡥ࡞ࡧ࠯ࠬ᧩"),title,re.DOTALL)
			if l111l1ll_l1_:
				l111l1ll_l1_ = l1l111_l1_ (u"ࠬࡥ࡟ࡠࡡࠪ᧪")+l111l1ll_l1_[0]
				title = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"࠭࡮ࡢ࡯ࡨࠫ᧫"))
			else: l111l1ll_l1_ = l1l111_l1_ (u"ࠧࠨ᧬")
			l111lllll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ᧭")+title+l1l111_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭᧮")+l111l1ll_l1_
			l1llll_l1_.append(l111lllll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡼࡧࡴࡤࡪࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ᧯"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࠭࠵࠯࠯ࠬࡂ࠭ࡠࠨ࡜ࠨ࡟ࠪ᧰"),block,re.DOTALL)
		for l1ll1ll_l1_ in l1ll_l1_:
			l1ll1ll_l1_ = l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽ࠫ᧱")+l1ll1ll_l1_
			title = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"࠭࡮ࡢ࡯ࡨࠫ᧲"))
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ᧳")+title+l1l111_l1_ (u"ࠨࡡࡢࡩࡲࡨࡥࡥࠩ᧴")
			l1llll_l1_.append(l1ll1ll_l1_)
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡤ࡮ࡦࡾ࡜ࠩࡽࡸࡶࡱࡀࠠࠣࠪ࠱࠮ࡄ࠯ࠢࠨ᧵"),html,re.DOTALL)
		if l1ll_l1_:
			items = re.findall(l1l111_l1_ (u"ࠪࡨࡦࡺࡡ࠮࡫ࡱࡨࡪࡾ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡨࡦࡺࡡ࠮࡫ࡧࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰࡮࡬ࡂࠬ᧶"),block,re.DOTALL)
			for index,id,title in items:
				title = title.replace(l1l111_l1_ (u"ࠫࡡࡴࠧ᧷"),l1l111_l1_ (u"ࠬ࠭᧸")).strip(l1l111_l1_ (u"࠭ࠠࠨ᧹"))
				title = title.replace(l1l111_l1_ (u"ࠧࡄ࡫ࡰࡥࠥࡔ࡯ࡸࠩ᧺"),l1l111_l1_ (u"ࠨࡅ࡬ࡱࡦࡔ࡯ࡸࠩ᧻"))
				l1ll1ll_l1_ = l1ll_l1_[0]+l1l111_l1_ (u"ࠩࡂࡥࡨࡺࡩࡰࡰࡀࡷࡼ࡯ࡴࡤࡪࠩ࡭ࡳࡪࡥࡹ࠿ࠪ᧼")+index+l1l111_l1_ (u"ࠪࠪ࡮ࡪ࠽ࠨ᧽")+id+l1l111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ᧾")+title+l1l111_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭᧿")
				l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬᨀ"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠧࠨᨁ"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠨࠩᨂ"): return
	search = search.replace(l1l111_l1_ (u"ࠩࠣࠫᨃ"),l1l111_l1_ (u"ࠪ࠯ࠬᨄ"))
	url = l111l1_l1_ + l1l111_l1_ (u"ࠫ࠴ࡅࡳ࠾ࠩᨅ")+search
	l1lll11_l1_(url)
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠩࡖࡌࡔࡕࡆࡎࡃ࡛ࠫ壄")
l1lllll_l1_ = l1l111_l1_ (u"ࠪࡣࡘࡎࡍࡠࠩ壅")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l1l1l1l1l1_l1_ = l1l11l1_l1_[l1ll1_l1_][1]
l1ll1l1l1ll_l1_ = l1l11l1_l1_[l1ll1_l1_][2]
def l11l1ll_l1_(mode,url,text):
	if   mode==50: l1lll_l1_ = l1l1l11_l1_()
	elif mode==51: l1lll_l1_ = l1lll11_l1_(url)
	elif mode==52: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==53: l1lll_l1_ = PLAY(url)
	elif mode==55: l1lll_l1_ = l11l1111111l_l1_()
	elif mode==56: l1lll_l1_ = l111llllll11_l1_()
	elif mode==57: l1lll_l1_ = l111l1lll1_l1_(url,1)
	elif mode==58: l1lll_l1_ = l111l1lll1_l1_(url,2)
	elif mode==59: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ壆"),l1lllll_l1_+l1l111_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ壇"),l1l111_l1_ (u"࠭ࠧ壈"),59,l1l111_l1_ (u"ࠧࠨ壉"),l1l111_l1_ (u"ࠨࠩ壊"),l1l111_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭壋"))
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ壌"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ壍"),l1l111_l1_ (u"ࠬ࠭壎"),9999)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭壏"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ壐")+l1lllll_l1_+l1l111_l1_ (u"ࠨษ็ุ้๊ำๅษอࠫ壑"),l1l111_l1_ (u"ࠩࠪ壒"),56)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ壓"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭壔")+l1lllll_l1_+l1l111_l1_ (u"ࠬอไศใ็ห๊࠭壕"),l1l111_l1_ (u"࠭ࠧ壖"),55)
	return l1l111_l1_ (u"ࠧࠨ壗")
def l11l1111111l_l1_():
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ壘"),l1lllll_l1_+l1l111_l1_ (u"ࠩสัิัࠠศๆสๅ้อๅࠨ壙"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡲࡵࡶࡪࡧ࠲࠵࠴ࡴࡥࡸࡧࡶࡸࠬ壚"),51)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ壛"),l1lllll_l1_+l1l111_l1_ (u"ࠬอแๅษ่ࠤึอฦอหࠪ壜"),l111l1_l1_+l1l111_l1_ (u"࠭࠯࡮ࡱࡹ࡭ࡪ࠵࠱࠰ࡲࡲࡴࡺࡲࡡࡳࠩ壝"),51)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ壞"),l1lllll_l1_+l1l111_l1_ (u"ࠨษัีࠥอึศใสฮࠥอไศใ็ห๊࠭壟"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡱࡴࡼࡩࡦ࠱࠴࠳ࡱࡧࡴࡦࡵࡷࠫ壠"),51)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ壡"),l1lllll_l1_+l1l111_l1_ (u"ࠫฬ็ไศ็ࠣ็้อำ๋ๅํอࠬ壢"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵࡭ࡰࡸ࡬ࡩ࠴࠷࠯ࡤ࡮ࡤࡷࡸ࡯ࡣࠨ壣"),51)
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ壤"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ壥"),l1l111_l1_ (u"ࠨࠩ壦"),9999)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ壧"),l1lllll_l1_+l1l111_l1_ (u"ࠪหำะ๊ศำࠣหๆ๊วๆ่ࠢีฯฮษࠡสึ๊ฮࠦวๅษ้ฮฬาࠧ壨"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨ࠳࠶࠵ࡹࡰࡲࠪ壩"),57)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ壪"),l1lllll_l1_+l1l111_l1_ (u"࠭วฯฬํหึࠦวโๆส้๋ࠥัหสฬࠤออไศใู่ࠥะโ๋์่ࠫ士"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰࡯ࡲࡺ࡮࡫࠯࠲࠱ࡵࡩࡻ࡯ࡥࡸࠩ壬"),57)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ壭"),l1lllll_l1_+l1l111_l1_ (u"ࠩสาฯ๐วาࠢสๅ้อๅࠡ็ิฮอฯࠠษษ็ห่ััࠡ็ืห์ีษࠨ壮"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡲࡵࡶࡪࡧ࠲࠵࠴ࡼࡩࡦࡹࡶࠫ壯"),57)
	return
def l111llllll11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ声"),l1lllll_l1_+l1l111_l1_ (u"ࠬออะอࠣห้๋ำๅี็หฯ࠭壱"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯࠲࠱ࡱࡩࡼ࡫ࡳࡵࠩ売"),51)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ壳"),l1lllll_l1_+l1l111_l1_ (u"ࠨ็ึุ่๊วหࠢิหหาษࠨ壴"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠲࠵࠴ࡶ࡯ࡱࡷ࡯ࡥࡷ࠭壵"),51)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ壶"),l1lllll_l1_+l1l111_l1_ (u"ࠫฬิัࠡษูหๆอสࠡษ็ุ้๊ำๅษอࠫ壷"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠵࠱࠰࡮ࡤࡸࡪࡹࡴࠨ壸"),51)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭壹"),l1lllll_l1_+l1l111_l1_ (u"ࠧๆี็ื้อสࠡๅ็หุ๐ใ๋หࠪ壺"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡶࡩࡷ࡯ࡥࡴ࠱࠴࠳ࡨࡲࡡࡴࡵ࡬ࡧࠬ壻"),51)
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ壼"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ壽"),l1l111_l1_ (u"ࠫࠬ壾"),9999)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ壿"),l1lllll_l1_+l1l111_l1_ (u"࠭วฯฬํหึࠦๅิๆึ่ฬะࠠๆำอฬฮࠦศิ่ฬࠤฬ๊ว็ฬสะࠬ夀"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡵࡨࡶ࡮࡫ࡳ࠰࠳࠲ࡽࡴࡶࠧ夁"),57)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ夂"),l1lllll_l1_+l1l111_l1_ (u"ࠩสาฯ๐วา่ࠢืู้ไศฬ้ࠣึะศสࠢหห้อแืๆࠣฮ็๐๊ๆࠩ夃"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶ࠳࠶࠵ࡲࡦࡸ࡬ࡩࡼ࠭处"),57)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ夅"),l1lllll_l1_+l1l111_l1_ (u"ࠬอฮห์สี๋ࠥำๅี็หฯࠦๅาฬหอࠥฮวๅษๆฯึࠦๅีษ๊ำฮ࠭夆"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯࠲࠱ࡹ࡭ࡪࡽࡳࠨ备"),57)
	return
def l1lll11_l1_(url):
	if l1l111_l1_ (u"ࠧࡀࠩ夈") in url:
		parts = url.split(l1l111_l1_ (u"ࠨࡁࠪ変"))
		url = parts[0]
		filter = l1l111_l1_ (u"ࠩࡂࠫ夊") + QUOTE(parts[1],l1l111_l1_ (u"ࠪࡁࠫࡀ࠯ࠦࠩ夋"))
	else: filter = l1l111_l1_ (u"ࠫࠬ夌")
	parts = url.split(l1l111_l1_ (u"ࠬ࠵ࠧ复"))
	sort,l1llllll1_l1_,type = parts[-1],parts[-2],parts[-3]
	if sort in [l1l111_l1_ (u"࠭ࡹࡰࡲࠪ夎"),l1l111_l1_ (u"ࠧࡳࡧࡹ࡭ࡪࡽࠧ夏"),l1l111_l1_ (u"ࠨࡸ࡬ࡩࡼࡹࠧ夐")]:
		if type==l1l111_l1_ (u"ࠩࡰࡳࡻ࡯ࡥࠨ夑"): l1l1l1lll_l1_=l1l111_l1_ (u"ࠪๅ๏๊ๅࠨ夒")
		elif type==l1l111_l1_ (u"ࠫࡸ࡫ࡲࡪࡧࡶࠫ夓"): l1l1l1lll_l1_=l1l111_l1_ (u"๋ࠬำๅี็ࠫ夔")
		url = l111l1_l1_ + l1l111_l1_ (u"࠭࠯ࡨࡧࡱࡶࡪ࠵ࡦࡪ࡮ࡷࡩࡷ࠵ࠧ夕") + QUOTE(l1l1l1lll_l1_) + l1l111_l1_ (u"ࠧ࠰ࠩ外") + l1llllll1_l1_ + l1l111_l1_ (u"ࠨ࠱ࠪ夗") + sort + filter
		html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠩࠪ夘"),l1l111_l1_ (u"ࠪࠫ夙"),l1l111_l1_ (u"ࠫࠬ多"),l1l111_l1_ (u"࡙ࠬࡈࡐࡑࡉࡑࡆ࡞࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫ夛"))
		items = re.findall(l1l111_l1_ (u"࠭ࠢࡱ࡫ࡧࠦ࠿࠮࠮ࠫࡁࠬ࠰࠳࠰࠿ࠣࡲࡷ࡭ࡹࡲࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠯ࡄࠨࡰࡦࡲ࡬ࡷࡴࡪࡥࡴࠤ࠽ࠬ࠳࠰࠿ࠪ࠮ࠥࡴࡷ࡫ࡳࡣࡣࡶࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ夜"),html,re.DOTALL)
		l1ll1l11111_l1_=0
		for id,title,l111lllll1ll_l1_,l1ll1l_l1_ in items:
			l1ll1l11111_l1_ += 1
			l1ll1l_l1_ = l1ll1l1l1ll_l1_ + l1l111_l1_ (u"ࠧ࠰ࡸ࠵࠳࡮ࡳࡧ࠰ࡲࡵࡳ࡬ࡸࡡ࡮࠱ࡰࡥ࡮ࡴ࠯ࠨ夝") + l1ll1l_l1_ + l1l111_l1_ (u"ࠨ࠯࠵࠲࡯ࡶࡧࠨ夞")
			l1ll1ll_l1_ = l111l1_l1_ + l1l111_l1_ (u"ࠩ࠲ࡴࡷࡵࡧࡳࡣࡰ࠳ࠬ够") + id
			if type==l1l111_l1_ (u"ࠪࡱࡴࡼࡩࡦࠩ夠"): addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ夡"),l1lllll_l1_+title,l1ll1ll_l1_,53,l1ll1l_l1_)
			if type==l1l111_l1_ (u"ࠬࡹࡥࡳ࡫ࡨࡷࠬ夢"): addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭夣"),l1lllll_l1_+l1l111_l1_ (u"ࠧๆี็ื้ࠦࠧ夤")+title,l1ll1ll_l1_+l1l111_l1_ (u"ࠨࡁࡨࡴࡂ࠭夥")+l111lllll1ll_l1_+l1l111_l1_ (u"ࠩࡀࠫ夦")+title+l1l111_l1_ (u"ࠪࡁࠬ大")+l1ll1l_l1_,52,l1ll1l_l1_)
	else:
		if type==l1l111_l1_ (u"ࠫࡲࡵࡶࡪࡧࠪ夨"): l1l1l1lll_l1_=l1l111_l1_ (u"ࠬࡳ࡯ࡷ࡫ࡨࡷࠬ天")
		elif type==l1l111_l1_ (u"࠭ࡳࡦࡴ࡬ࡩࡸ࠭太"): l1l1l1lll_l1_=l1l111_l1_ (u"ࠧࡴࡧࡵ࡭ࡪࡹࠧ夫")
		url = l1l1l1l1l1_l1_ + l1l111_l1_ (u"ࠨ࠱࡭ࡷࡴࡴ࠯ࡴࡧ࡯ࡩࡨࡺࡥࡥ࠱ࠪ夬") + sort + l1l111_l1_ (u"ࠩ࠰ࠫ夭") + l1l1l1lll_l1_ + l1l111_l1_ (u"ࠪ࠱࡜࡝࠮࡫ࡵࡲࡲࠬ央")
		html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠫࠬ夯"),l1l111_l1_ (u"ࠬ࠭夰"),l1l111_l1_ (u"࠭ࠧ失"),l1l111_l1_ (u"ࠧࡔࡊࡒࡓࡋࡓࡁ࡙࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠵ࡲࡩ࠭夲"))
		items = re.findall(l1l111_l1_ (u"ࠨࠤࡵࡩ࡫ࠨ࠺ࠩ࠰࠭ࡃ࠮࠲ࠢࡦࡲࠥ࠾࠭࠴ࠪࡀࠫ࠯ࠦࡧࡧࡳࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠰ࠧࡺࡩࡵ࡮ࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭夳"),html,re.DOTALL)
		l1ll1l11111_l1_=0
		for id,l111lllll1ll_l1_,l1ll1l_l1_,title in items:
			l1ll1l11111_l1_ += 1
			l1ll1l_l1_ = l1l1l1l1l1_l1_ + l1l111_l1_ (u"ࠩ࠲࡭ࡲ࡭࠯ࡱࡴࡲ࡫ࡷࡧ࡭࠰ࠩ头") + l1ll1l_l1_ + l1l111_l1_ (u"ࠪ࠱࠷࠴ࡪࡱࡩࠪ夵")
			l1ll1ll_l1_ = l111l1_l1_ + l1l111_l1_ (u"ࠫ࠴ࡶࡲࡰࡩࡵࡥࡲ࠵ࠧ夶") + id
			if type==l1l111_l1_ (u"ࠬࡳ࡯ࡷ࡫ࡨࠫ夷"): addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ夸"),l1lllll_l1_+title,l1ll1ll_l1_,53,l1ll1l_l1_)
			elif type==l1l111_l1_ (u"ࠧࡴࡧࡵ࡭ࡪࡹࠧ夹"): addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ夺"),l1lllll_l1_+l1l111_l1_ (u"่ࠩืู้ไࠡࠩ夻")+title,l1ll1ll_l1_+l1l111_l1_ (u"ࠪࡃࡪࡶ࠽ࠨ夼")+l111lllll1ll_l1_+l1l111_l1_ (u"ࠫࡂ࠭夽")+title+l1l111_l1_ (u"ࠬࡃࠧ夾")+l1ll1l_l1_,52,l1ll1l_l1_)
	title=l1l111_l1_ (u"࠭ีโฯฬࠤࠬ夿")
	if l1ll1l11111_l1_==16:
		for l1ll1l1ll11_l1_ in range(1,13) :
			if not l1llllll1_l1_==str(l1ll1l1ll11_l1_):
				url = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡩࡨࡲࡷ࡫࠯ࡧ࡫࡯ࡸࡪࡸ࠯ࠨ奀")+type+l1l111_l1_ (u"ࠨ࠱ࠪ奁")+str(l1ll1l1ll11_l1_)+l1l111_l1_ (u"ࠩ࠲ࠫ奂")+sort + filter
				addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ奃"),l1lllll_l1_+title+str(l1ll1l1ll11_l1_),url,51)
	return
def l1ll1l11_l1_(url):
	parts = url.split(l1l111_l1_ (u"ࠫࡂ࠭奄"))
	l111lllll1ll_l1_ = int(parts[1])
	name = l111l11_l1_(parts[2])
	name = name.replace(l1l111_l1_ (u"ࠬࡥࡍࡐࡆࡢุ้๊ำๅࠢࠪ奅"),l1l111_l1_ (u"࠭ࠧ奆"))
	l1ll1l_l1_ = parts[3]
	url = url.split(l1l111_l1_ (u"ࠧࡀࠩ奇"))[0]
	if l111lllll1ll_l1_==0:
		html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠨࠩ奈"),l1l111_l1_ (u"ࠩࠪ奉"),l1l111_l1_ (u"ࠪࠫ奊"),l1l111_l1_ (u"ࠫࡘࡎࡏࡐࡈࡐࡅ࡝࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠳ࡶࡸࠬ奋"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡂࡳࡦ࡮ࡨࡧࡹ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡥ࡭ࡧࡦࡸࡃ࠭奌"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭࡯ࡱࡶ࡬ࡳࡳࠦࡶࡢ࡮ࡸࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭奍"),block,re.DOTALL)
		l111lllll1ll_l1_ = int(items[-1])
	for l1l1lll_l1_ in range(l111lllll1ll_l1_,0,-1):
		l1ll1ll_l1_ = url + l1l111_l1_ (u"ࠧࡀࡧࡳࡁࠬ奎") + str(l1l1lll_l1_)
		title = l1l111_l1_ (u"ࠨࡡࡐࡓࡉࡥๅิๆึ่ࠥ࠭奏")+name+l1l111_l1_ (u"ࠩࠣ࠱ࠥอไฮๆๅอࠥ࠭奐")+str(l1l1lll_l1_)
		addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ契"),l1lllll_l1_+title,l1ll1ll_l1_,53,l1ll1l_l1_)
	return
def PLAY(url):
	html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"ࠫࠬ奒"),l1l111_l1_ (u"ࠬ࠭奓"),l1l111_l1_ (u"࠭ࠧ奔"),l1l111_l1_ (u"ࠧࡔࡊࡒࡓࡋࡓࡁ࡙࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ奕"))
	l111llllll1l_l1_ = re.findall(l1l111_l1_ (u"ࠨ็อ์ๆืฺࠠๆ์ࠤู๎แࠡ็ส็ุࠦศฺั࠱࠮ࡄࡳ࡯࡮ࡧࡱࡸࡡ࠮ࠢࠩ࠰࠭ࡃ࠮ࠨࠧ奖"),html,re.DOTALL)
	if l111llllll1l_l1_:
		time = l111llllll1l_l1_[1].replace(l1l111_l1_ (u"ࠩࡗࠫ套"),l1l111_l1_ (u"ࠪࠤࠥࠦࠠࠨ奘"))
		l1111l1_l1_(l1l111_l1_ (u"ࠫࠬ奙"),l1l111_l1_ (u"ࠬ࠭奚"),l1l111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้ํู่ࠡษ็วฺ๊๊ࠨ奛"),l1l111_l1_ (u"่ࠧาสࠤฬ๊แ๋ัํ์ู๊ࠥไ๊้ࠤ๊ะ่โำࠣ฽้๏ࠠี๊ไࠤ๊อใิࠢห฽ิࠦ็ัษࠣห้๎โหࠩ奜")+l1l111_l1_ (u"ࠨ࡞ࡱࠫ奝")+time)
		return
	l111lllll11l_l1_,l111llllllll_l1_ = [],[]
	l11l11111111_l1_ = re.findall(l1l111_l1_ (u"ࠩࡹࡥࡷࠦ࡯ࡳ࡫ࡪ࡭ࡳࡥ࡬ࡪࡰ࡮ࠤࡂࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠧ奞"),html,re.DOTALL)[0]
	l111lllllll1_l1_ = re.findall(l1l111_l1_ (u"ࠪࡺࡦࡸࠠࡣࡣࡦ࡯ࡺࡶ࡟ࡰࡴ࡬࡫࡮ࡴ࡟࡭࡫ࡱ࡯ࠥࡃࠠࠣࠪ࠱࠮ࡄ࠯ࠢࠨ奟"),html,re.DOTALL)[0]
	l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࡭ࡲࡳ࠻ࠢࠫ࠲࠯ࡅࠩࡠ࡮࡬ࡲࡰࡢࠫࠣࠪ࠱࠮ࡄ࠯ࠢࠨ奠"),html,re.DOTALL)
	for server,l1ll1ll_l1_ in l1ll_l1_:
		if l1l111_l1_ (u"ࠬࡨࡡࡤ࡭ࡸࡴࠬ奡") in server:
			server = l1l111_l1_ (u"࠭ࡢࡢࡥ࡮ࡹࡵࠦࡳࡦࡴࡹࡩࡷ࠭奢")
			url = l111lllllll1_l1_ + l1ll1ll_l1_
		else:
			server = l1l111_l1_ (u"ࠧ࡮ࡣ࡬ࡲࠥࡹࡥࡳࡸࡨࡶࠬ奣")
			url = l11l11111111_l1_ + l1ll1ll_l1_
		if l1l111_l1_ (u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧ奤") in url:
			l111lllll11l_l1_.append(url)
			l111llllllll_l1_.append(l1l111_l1_ (u"ࠩࡰ࠷ࡺ࠾ࠠࠡࠩ奥")+server)
	l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡱࡵ࠺࠺࠯ࠬࡂࡣࡱ࡯࡮࡬࠰࠭ࡃࡡࡺࠨ࠯ࠬࡂ࠭ࡤࡲࡩ࡯࡭࡟࠯ࠧ࠮࠮ࠫࡁࠬࠦࠬ奦"),html,re.DOTALL)
	l1ll_l1_ += re.findall(l1l111_l1_ (u"ࠫࡲࡶ࠴࠻࠰࠭ࡃࡡࡺࠨ࠯ࠬࡂ࠭ࡤࡲࡩ࡯࡭࡟࠯ࠧ࠮࠮ࠫࡁࠬࠦࠬ奧"),html,re.DOTALL)
	for server,l1ll1ll_l1_ in l1ll_l1_:
		filename = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠬ࠵ࠧ奨"))[-1]
		filename = filename.replace(l1l111_l1_ (u"࠭ࡦࡢ࡮࡯ࡦࡦࡩ࡫ࠨ奩"),l1l111_l1_ (u"ࠧࠨ奪"))
		filename = filename.replace(l1l111_l1_ (u"ࠨ࠰ࡰࡴ࠹࠭奫"),l1l111_l1_ (u"ࠩࠪ奬"))
		filename = filename.replace(l1l111_l1_ (u"ࠪ࠱ࠬ奭"),l1l111_l1_ (u"ࠫࠬ奮"))
		if l1l111_l1_ (u"ࠬࡨࡡࡤ࡭ࡸࡴࠬ奯") in server:
			server = l1l111_l1_ (u"࠭ࡢࡢࡥ࡮ࡹࡵࠦࡳࡦࡴࡹࡩࡷ࠭奰")
			url = l111lllllll1_l1_ + l1ll1ll_l1_
		else:
			server = l1l111_l1_ (u"ࠧ࡮ࡣ࡬ࡲࠥࡹࡥࡳࡸࡨࡶࠬ奱")
			url = l11l11111111_l1_ + l1ll1ll_l1_
		l111lllll11l_l1_.append(url)
		l111llllllll_l1_.append(l1l111_l1_ (u"ࠨ࡯ࡳ࠸ࠥࠦࠧ奲")+server+l1l111_l1_ (u"ࠩࠣࠤࠬ女")+filename)
	l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠪࡗࡪࡲࡥࡤࡶ࡚ࠣ࡮ࡪࡥࡰࠢࡔࡹࡦࡲࡩࡵࡻ࠽ࠫ奴"), l111llllllll_l1_)
	if l11l11l_l1_ == -1 : return
	url = l111lllll11l_l1_[l11l11l_l1_]
	l1llll111_l1_(url,l1ll1_l1_,l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ奵"))
	return
def l111l1lll1_l1_(url,type):
	if l1l111_l1_ (u"ࠬࡹࡥࡳ࡫ࡨࡷࠬ奶") in url: l1lllll1_l1_ = l111l1_l1_ + l1l111_l1_ (u"࠭࠯ࡨࡧࡱࡶࡪ࠵ๅิๆึ่ࠬ奷")
	else: l1lllll1_l1_ = l111l1_l1_ + l1l111_l1_ (u"ࠧ࠰ࡩࡨࡲࡷ࡫࠯โ์็้ࠬ奸")
	l1lllll1_l1_ = QUOTE(l1lllll1_l1_)
	html = l1l1llll_l1_(l1ll1ll1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠨࠩ她"),l1l111_l1_ (u"ࠩࠪ奺"),l1l111_l1_ (u"ࠪࠫ奻"),l1l111_l1_ (u"ࠫࡘࡎࡏࡐࡈࡐࡅ࡝࠳ࡆࡊࡎࡗࡉࡗ࡙࠭࠲ࡵࡷࠫ奼"))
	if type==1: l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡹࡵࡣࡩࡨࡲࡷ࡫ࠨ࠯ࠬࡂ࠭ࡩ࡯ࡶࠨ好"),html,re.DOTALL)
	elif type==2: l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣࡰࡷࡱࡸࡷࡿࠨ࠯ࠬࡂ࠭ࡩ࡯ࡶࠨ奾"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠧࡰࡲࡷ࡭ࡴࡴࠠࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡰࡲࡷ࡭ࡴࡴࠧ奿"),block,re.DOTALL)
	if type==1:
		for l111lllll1l1_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ妀"),l1lllll_l1_+title,url+l1l111_l1_ (u"ࠩࡂࡷࡺࡨࡧࡦࡰࡵࡩࡂ࠭妁")+l111lllll1l1_l1_,58)
	elif type==2:
		url,l111lllll1l1_l1_ = url.split(l1l111_l1_ (u"ࠪࡃࠬ如"))
		for l1lll1l111ll_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ妃"),l1lllll_l1_+title,url+l1l111_l1_ (u"ࠬࡅࡣࡰࡷࡱࡸࡷࡿ࠽ࠨ妄")+l1lll1l111ll_l1_+l1l111_l1_ (u"࠭ࠦࠨ妅")+l111lllll1l1_l1_,51)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search: search = l1llll1_l1_()
	if not search: return
	l1lll1ll_l1_ = search.replace(l1l111_l1_ (u"ࠧࠡࠩ妆"),l1l111_l1_ (u"ࠨࠧ࠵࠴ࠬ妇"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪࡂࡵࡂ࠭妈")+l1lll1ll_l1_
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ妉"),url,l1l111_l1_ (u"ࠫࠬ妊"),l1l111_l1_ (u"ࠬ࠭妋"),True,l1l111_l1_ (u"࠭ࠧ妌"),l1l111_l1_ (u"ࠧࡔࡊࡒࡓࡋࡓࡁ࡙࠯ࡖࡉࡆࡘࡃࡉ࠯࠵ࡲࡩ࠭妍"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡩࡨࡲࡪࡸࡡ࡭࠯ࡥࡳࡩࡿࠨ࠯ࠬࡂ࠭ࡸ࡫ࡡࡳࡥ࡫࠱ࡧࡵࡴࡵࡱࡰ࠱ࡵࡧࡤࡥ࡫ࡱ࡫ࠬ妎"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡦࡦࡩ࡫ࡨࡴࡲࡹࡳࡪ࠭ࡪ࡯ࡤ࡫ࡪࡀࠠࡶࡴ࡯ࡠ࠭࠮࠮ࠫࡁࠬࡠ࠮࠴ࠪࡀ࠾ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃ࠭妏"),block,re.DOTALL)
	if items:
		for l1ll1ll_l1_,l1ll1l_l1_,title in items:
			url = l111l1_l1_ + l1ll1ll_l1_
			if l1l111_l1_ (u"ࠪ࠳ࡵࡸ࡯ࡨࡴࡤࡱ࠴࠭妐") in url:
				if l1l111_l1_ (u"ࠫࡄ࡫ࡰ࠾ࠩ妑") in url:
					title = l1l111_l1_ (u"ࠬࡥࡍࡐࡆࡢุ้๊ำๅࠢࠪ妒")+title
					url = url.replace(l1l111_l1_ (u"࠭࠿ࡦࡲࡀ࠵ࠬ妓"),l1l111_l1_ (u"ࠧࡀࡧࡳࡁ࠵࠭妔"))
					url = url+l1l111_l1_ (u"ࠨ࠿ࠪ妕")+QUOTE(title)+l1l111_l1_ (u"ࠩࡀࠫ妖")+l1ll1l_l1_
					addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ妗"),l1lllll_l1_+title,url,52,l1ll1l_l1_)
				else:
					title = l1l111_l1_ (u"ࠫࡤࡓࡏࡅࡡไ๎้๋ࠠࠨ妘")+title
					addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ妙"),l1lllll_l1_+title,url,53,l1ll1l_l1_)
	return
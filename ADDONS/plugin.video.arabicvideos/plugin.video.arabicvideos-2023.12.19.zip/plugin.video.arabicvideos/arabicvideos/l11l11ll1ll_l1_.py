# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠧࡔࡊࡌࡅ࡛ࡕࡉࡄࡇࠪ坹")
l1lllll_l1_ = l1l111_l1_ (u"ࠨࡡࡖࡌ࡛ࡥࠧ坺")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
headers = {l1l111_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭坻"):None}
def l11l1ll_l1_(mode,url,text):
	if   mode==310: l1lll_l1_ = l1l1l11_l1_()
	elif mode==311: l1lll_l1_ = l1lll11_l1_(url)
	elif mode==312: l1lll_l1_ = PLAY(url)
	elif mode==313: l1lll_l1_ = l11l111111ll_l1_(url)
	elif mode==314: l1lll_l1_ = l1lllll1l_l1_(text)
	elif mode==319: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ坼"),l1lllll_l1_+l1l111_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ坽"),l1l111_l1_ (u"ࠬ࠭坾"),319,l1l111_l1_ (u"࠭ࠧ坿"),l1l111_l1_ (u"ࠧࠨ垀"),l1l111_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ垁"))
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭垂"),l111l1_l1_,l1l111_l1_ (u"ࠪࠫ垃"),l1l111_l1_ (u"ࠫࠬ垄"),l1l111_l1_ (u"ࠬ࠭垅"),l1l111_l1_ (u"࠭ࠧ垆"),l1l111_l1_ (u"ࠧࡔࡊࡌࡅ࡛ࡕࡉࡄࡇ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ垇"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࡫ࡧࡁࠧࡳࡥ࡯ࡷ࡯࡭ࡳࡱࡳࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ垈"),html,re.DOTALL)
	block = l11llll_l1_[0]
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ垉"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ垊"),l1l111_l1_ (u"ࠫࠬ型"),9999)
	items = re.findall(l1l111_l1_ (u"ࠬࡂࡨ࠶ࡀࠫ࠲࠯ࡅࠩ࠽࠱࡫࠹ࡃ࠭垌"),html,re.DOTALL|re.IGNORECASE)
	for seq in range(len(items)):
		title = items[seq].strip(l1l111_l1_ (u"࠭ࠠࠨ垍"))
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ垎"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ垏")+l1lllll_l1_+title,l111l1_l1_,314,l1l111_l1_ (u"ࠩࠪ垐"),l1l111_l1_ (u"ࠪࠫ垑"),str(seq+1))
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ垒"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ垓")+l1lllll_l1_+l1l111_l1_ (u"࠭ๅใษฺ฽ฺࠥ็าࠩ垔"),l111l1_l1_,314,l1l111_l1_ (u"ࠧࠨ垕"),l1l111_l1_ (u"ࠨࠩ垖"),l1l111_l1_ (u"ࠩ࠳ࠫ垗"))
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ垘"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ垙"),l1l111_l1_ (u"ࠬ࠭垚"),9999)
	items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡄࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡆࡃ࠭垛"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࠩ垜")+l1ll1ll_l1_
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ垝"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ垞")+l1lllll_l1_+title,l1ll1ll_l1_,311)
	return html
def l1lllll1l_l1_(seq):
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ垟"),l111l1_l1_,l1l111_l1_ (u"ࠫࠬ垠"),l1l111_l1_ (u"ࠬ࠭垡"),l1l111_l1_ (u"࠭ࠧ垢"),l1l111_l1_ (u"ࠧࠨ垣"),l1l111_l1_ (u"ࠨࡕࡋࡍࡆ࡜ࡏࡊࡅࡈ࠱ࡑࡇࡔࡆࡕࡗ࠱࠶ࡹࡴࠨ垤"))
	html = response.content
	if seq==l1l111_l1_ (u"ࠩ࠳ࠫ垥"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡸࡦࡨ࠭ࡤࡱࡱࡸࡪࡴࡴࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡶࡤࡦࡱ࡫࠾ࠨ垦"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽࠱࡬ࡂ࠭࠴ࠪࡀࠫ࠿ࠫ垧"),block,re.DOTALL)
		for l1ll1ll_l1_,name,title in items:
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࠧ垨")+l1ll1ll_l1_
			title = title.strip(l1l111_l1_ (u"࠭ࠠࠨ垩"))
			name = name.strip(l1l111_l1_ (u"ࠧࠡࠩ垪"))
			title = title+l1l111_l1_ (u"ࠨࠢࠫࠫ垫")+name+l1l111_l1_ (u"ࠩࠬࠫ垬")
			addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ垭"),l1lllll_l1_+title,l1ll1ll_l1_,312)
	elif seq in [l1l111_l1_ (u"ࠫ࠶࠭垮"),l1l111_l1_ (u"ࠬ࠸ࠧ垯"),l1l111_l1_ (u"࠭࠳ࠨ垰")]:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠩ࠾࡫࠹ࡃ࠴ࠪࡀࠫ࠿ࡨ࡮ࡼࠠࡤ࡮ࡤࡷࡸࡃࠢࡤࡱ࡯࠱ࡱ࡭ࠧ垱"),html,re.DOTALL)
		l11l11111l11_l1_ = int(seq)-1
		block = l11llll_l1_[l11l11111l11_l1_]
		if seq==l1l111_l1_ (u"ࠨ࠳ࠪ垲"): items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡸࡺࡲࡰࡰࡪࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅ࠼࠰࡫ࡁࠬ࠳࠰࠿ࠪ࠾ࠪ垳"),block,re.DOTALL)
		else: items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡹࡴࡳࡱࡱ࡫ࡃ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿ࡩࡴࡨࡪࡂࠨ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ垴"),block,re.DOTALL)
		for l1ll1ll_l1_,l1ll1l_l1_,title,name in items:
			l1ll1l_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴࠭垵")+l1ll1l_l1_
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࠧ垶")+l1ll1ll_l1_
			title = title.strip(l1l111_l1_ (u"࠭ࠠࠨ垷"))
			name = name.strip(l1l111_l1_ (u"ࠧࠡࠩ垸"))
			title = title+l1l111_l1_ (u"ࠨࠢࠫࠫ垹")+name+l1l111_l1_ (u"ࠩࠬࠫ垺")
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ垻"),l1lllll_l1_+title,l1ll1ll_l1_,311,l1ll1l_l1_)
	elif seq in [l1l111_l1_ (u"ࠫ࠹࠭垼"),l1l111_l1_ (u"ࠬ࠻ࠧ垽"),l1l111_l1_ (u"࠭࠶ࠨ垾")]:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠩ࠾࡫࠹ࡃ࠴ࠪࡀࠫ࠿࠳ࡹࡧࡢ࡭ࡧࡁࠫ垿"),html,re.DOTALL)
		seq = int(seq)-4
		block = l11llll_l1_[seq]
		items = re.findall(l1l111_l1_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡹࡴࡳࡱࡱ࡫࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡷࡶࡴࡴࡧ࠿࠰࠭ࡃ࠲ࡩࡥ࡭࡮ࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ埀"),block,re.DOTALL)
		for l1ll1l_l1_,l1ll1ll_l1_,l1ll1l111ll_l1_,title,l1llllllll1_l1_ in items:
			l1ll1l_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࠫ埁")+l1ll1l_l1_
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࠬ埂")+l1ll1ll_l1_
			title = title.strip(l1l111_l1_ (u"ࠫࠥ࠭埃"))
			l1ll1l111ll_l1_ = l1ll1l111ll_l1_.strip(l1l111_l1_ (u"ࠬࠦࠧ埄"))
			l1llllllll1_l1_ = l1llllllll1_l1_.strip(l1l111_l1_ (u"࠭ࠠࠨ埅"))
			if l1ll1l111ll_l1_: name = l1ll1l111ll_l1_
			else: name = l1llllllll1_l1_
			title = title+l1l111_l1_ (u"ࠧࠡࠪࠪ埆")+name+l1l111_l1_ (u"ࠨࠫࠪ埇")
			addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ埈"),l1lllll_l1_+title,l1ll1ll_l1_,312,l1ll1l_l1_)
	return
def l1lll11_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ埉"),url,l1l111_l1_ (u"ࠫࠬ埊"),l1l111_l1_ (u"ࠬ࠭埋"),l1l111_l1_ (u"࠭ࠧ埌"),l1l111_l1_ (u"ࠧࠨ埍"),l1l111_l1_ (u"ࠨࡕࡋࡍࡆ࡜ࡏࡊࡅࡈ࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨ城"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡬ࡦࡴࡾ࠭ࡩࡧࡤࡨ࡮ࡴࡧࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡦ࡭ࡱࡤࡸ࠲ࡸࡩࡨࡪࡷࠫ埏"),html,re.DOTALL)
	block = l11llll_l1_[0]
	if l1l111_l1_ (u"ࠪࡧࡦࡺࡳࡶ࡯࠰ࡱࡴࡨࡩ࡭ࡧࠪ埐") in block:
		items = re.findall(l1l111_l1_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡳࡵࡴࡲࡲ࡬ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡵࡴࡲࡲ࡬ࡄ࠮ࠫࡁࡦࡥࡹࡹࡵ࡮࠯ࡰࡳࡧ࡯࡬ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ埑"),block,re.DOTALL)
		if items:
			for l1ll1l_l1_,l1ll1ll_l1_,title,count in items:
				l1ll1l_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࠧ埒")+l1ll1l_l1_
				l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"࠭࠯ࠨ埓")+l1ll1ll_l1_
				count = count.replace(l1l111_l1_ (u"ࠧࠡษ็ูํะ๊ส࠼ࠣࠫ埔"),l1l111_l1_ (u"ࠨ࠼ࠪ埕"))
				title = title.strip(l1l111_l1_ (u"ࠩࠣࠫ埖"))
				title = title+l1l111_l1_ (u"ࠪࠤ࠭࠭埗")+count+l1l111_l1_ (u"ࠫ࠮࠭埘")
				addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ埙"),l1lllll_l1_+title,l1ll1ll_l1_,311,l1ll1l_l1_)
	else:
		items = re.findall(l1l111_l1_ (u"࠭ࠢࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࠳࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀ࠾ࡶࡴࡦࡴ࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠯ࠬࡂࡀࡸࡶࡡ࡯࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭埚"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l11l11111l1l_l1_,l1l1lll111_l1_ in items:
			if title==l1l111_l1_ (u"ࠧࠨ埛") or l11l11111l1l_l1_==l1l111_l1_ (u"ࠨࠩ埜"): continue
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࠫ埝")+l1ll1ll_l1_
			title = title+l1l111_l1_ (u"ࠪࠤ࠭࠭埞")+l1l1lll111_l1_+l1l111_l1_ (u"ࠫ࠮࠭域")
			addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ埠"),l1lllll_l1_+title,l1ll1ll_l1_,312)
	if not items: l1ll1l11_l1_(html)
	return
def l1ll1l11_l1_(html):
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡩࡣࡱࡻ࠱ࡨࡵ࡮ࡵࡧࡱࡸࠧ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠧ埡"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨࡩࡶࡷࡴ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃࡨ࡫࡬࡭ࠤࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄࡩࡥ࡭࡮ࠥࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅࡣࡦ࡮࡯ࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ埢"),block,re.DOTALL)
	for l1ll1ll_l1_,title,name,count,l1l1lll111_l1_ in items:
		l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࠪ埣")+l1ll1ll_l1_
		title = title.strip(l1l111_l1_ (u"ࠩࠣࠫ埤"))
		name = name.strip(l1l111_l1_ (u"ࠪࠤࠬ埥"))
		title = title+l1l111_l1_ (u"ࠫࠥ࠮ࠧ埦")+name+l1l111_l1_ (u"ࠬ࠯ࠧ埧")
		addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ埨"),l1lllll_l1_+title,l1ll1ll_l1_,312,l1l111_l1_ (u"ࠧࠨ埩"),l1l1lll111_l1_)
	return
def l11l111111ll_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ埪"),url,l1l111_l1_ (u"ࠩࠪ埫"),l1l111_l1_ (u"ࠪࠫ埬"),l1l111_l1_ (u"ࠫࠬ埭"),l1l111_l1_ (u"ࠬ࠭埮"),l1l111_l1_ (u"࠭ࡓࡉࡋࡄ࡚ࡔࡏࡃࡆ࠯ࡖࡉࡆࡘࡃࡉࡡࡌࡘࡊࡓࡓ࠮࠳ࡶࡸࠬ埯"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡪࡤࡲࡼ࠲ࡩ࡯࡯ࡶࡨࡲࡹࠦࡰ࠮࠳ࠥࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣ࡫ࡥࡳࡽ࠳ࡣࡰࡰࡷࡩࡳࡺࠢࠨ埰"),html,re.DOTALL)
	if not l11llll_l1_:
		l1lll11_l1_(url)
		return
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡹࡸ࡯࡯ࡩࡁࠬ࠳࠰࠿ࠪ࠾ࠪ埱"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࠫ埲")+l1ll1ll_l1_
		title = title.strip(l1l111_l1_ (u"ࠪࠤࠬ埳"))
		if l1l111_l1_ (u"ࠫ࠴ࡶ࡬ࡢࡻ࠰ࠫ埴") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ埵"),l1lllll_l1_+title,l1ll1ll_l1_,312)
		else: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭埶"),l1lllll_l1_+title,l1ll1ll_l1_,311)
	return
def PLAY(url):
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ執"),url,l1l111_l1_ (u"ࠨࠩ埸"),l1l111_l1_ (u"ࠩࠪ培"),l1l111_l1_ (u"ࠪࠫ基"),l1l111_l1_ (u"ࠫࠬ埻"),l1l111_l1_ (u"࡙ࠬࡈࡊࡃ࡙ࡓࡎࡉࡅ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ埼"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"࠭࠼ࡢࡷࡧ࡭ࡴ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭埽"),html,re.DOTALL)
	if not l1ll1ll_l1_: l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࠽ࡸ࡬ࡨࡪࡵ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ埾"),html,re.DOTALL)
	l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_[0]
	l1llll111_l1_(l1ll1ll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ埿"))
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠩࠪ堀"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠪࠫ堁"): return
	search = search.replace(l1l111_l1_ (u"ࠫࠥ࠭堂"),l1l111_l1_ (u"ࠬ࠱ࠧ堃"))
	l11l11111ll1_l1_ = [l1l111_l1_ (u"࠭ࠦࡵ࠿ࡤࠫ堄"),l1l111_l1_ (u"ࠧࠧࡶࡀࡧࠬ堅"),l1l111_l1_ (u"ࠨࠨࡷࡁࡸ࠭堆")]
	if l11_l1_:
		l11l111111l1_l1_ = [l1l111_l1_ (u"ࠩๅหึฬࠧ堇"),l1l111_l1_ (u"ࠪษฺีวาࠢ࠲ࠤ๊าไะࠩ堈"),l1l111_l1_ (u"๊่ࠫืฺࠢสฺ่๎ส๋ࠩ堉")]
		l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"๋่ࠬใ฻ูࠣํะࠠศๆื๎฾ฯࠠ࠮ࠢฦาฯืࠠศๆหัะ࠭堊"), l11l111111l1_l1_)
		if l11l11l_l1_ == -1: return
	elif l1l111_l1_ (u"࠭࡟ࡔࡊࡌࡅ࡛ࡕࡉࡄࡇ࠰ࡔࡊࡘࡓࡐࡐࡖࡣࠬ堋") in options: l11l11l_l1_ = 0
	elif l1l111_l1_ (u"ࠧࡠࡕࡋࡍࡆ࡜ࡏࡊࡅࡈ࠱ࡆࡒࡂࡖࡏࡖࡣࠬ堌") in options: l11l11l_l1_ = 1
	elif l1l111_l1_ (u"ࠨࡡࡖࡌࡎࡇࡖࡐࡋࡆࡉ࠲ࡇࡕࡅࡋࡒࡗࡤ࠭堍") in options: l11l11l_l1_ = 2
	else: return
	type = l11l11111ll1_l1_[l11l11l_l1_]
	url = l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠱ࡴ࡭ࡶ࠿ࡲ࠿ࠪ堎")+search+type
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ堏"),url,l1l111_l1_ (u"ࠫࠬ堐"),l1l111_l1_ (u"ࠬ࠭堑"),l1l111_l1_ (u"࠭ࠧ堒"),l1l111_l1_ (u"ࠧࠨ堓"),l1l111_l1_ (u"ࠨࡕࡋࡍࡆ࡜ࡏࡊࡅࡈ࠱ࡘࡋࡁࡓࡅࡋ࠱࠶ࡹࡴࠨ堔"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤ࡬ࡦࡴࡾ࠭ࡤࡱࡱࡸࡪࡴࡴࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡩࡣࡱࡻ࠱ࡨࡵ࡮ࡵࡧࡱࡸࠧ࠭堕"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		if l11l11l_l1_ in [0,1]:
			items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥ࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ堖"),block,re.DOTALL)
			for l1ll1ll_l1_,l1ll1l_l1_,title,name in items:
				title = title.strip(l1l111_l1_ (u"ࠫࠥ࠭堗"))
				name = name.strip(l1l111_l1_ (u"ࠬࠦࠧ堘"))
				title = title+l1l111_l1_ (u"࠭ࠠࠩࠩ堙")+name+l1l111_l1_ (u"ࠧࠪࠩ堚")
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ堛"),l1lllll_l1_+title,l1ll1ll_l1_,313,l1ll1l_l1_)
		elif l11l11l_l1_==2:
			items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࠦ࠳࠰࠿࠽࠱࡬ࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄ࠼࠰ࡶࡧࡂࡁࡺࡤ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ堜"),block,re.DOTALL)
			for l1ll1ll_l1_,title,name in items:
				title = title.strip(l1l111_l1_ (u"ࠪࠤࠬ堝"))
				name = name.strip(l1l111_l1_ (u"ࠫࠥ࠭堞"))
				title = title+l1l111_l1_ (u"ࠬࠦࠨࠨ堟")+name+l1l111_l1_ (u"࠭ࠩࠨ堠")
				addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭堡"),l1lllll_l1_+title,l1ll1ll_l1_,312)
	return
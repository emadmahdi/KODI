# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠶࠭⥸")
headers = {l1l111_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ⥹"):l1l111_l1_ (u"࠭ࠧ⥺")}
l1lllll_l1_ = l1l111_l1_ (u"ࠧࡠࡈࡋ࠵ࡤ࠭⥻")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠨฮ๋หหุࠠศๆฦ์ุ้วาࠩ⥼"),l1l111_l1_ (u"ࠩส่๊ืวอ฻สฮࠬ⥽"),l1l111_l1_ (u"ࠪࡻࡼ࡫ࠧ⥾")]
def l11l1ll_l1_(mode,url,text):
	if   mode==570: l1lll_l1_ = l1l1l11_l1_()
	elif mode==571: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==572: l1lll_l1_ = PLAY(url)
	elif mode==573: l1lll_l1_ = l1111lll1_l1_(url,text)
	elif mode==579: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	l1l11ll_l1_,url,response = l1lllll11l1_l1_(l111l1_l1_,l1l111_l1_ (u"ࠫ࡫ࡧࡳࡦ࡮࡫ࡨ࠶࠭⥿"),l1l111_l1_ (u"ࠬ็วึๆࠣษ฾๊ว็์ࠪ⦀"),l1l111_l1_ (u"࠭ࡤࡶࡤࡥࡩࡩ࠳࡭ࡰࡸ࡬ࡩࡸ࠭⦁"))
	html = response.content
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⦂"),l1lllll_l1_+l1l111_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ⦃"),l1l11ll_l1_,579,l1l111_l1_ (u"ࠩࠪ⦄"),l1l111_l1_ (u"ࠪࠫ⦅"),l1l111_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ⦆"))
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ⦇"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭⦈"),l1l111_l1_ (u"ࠧࠨ⦉"),9999)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⦊"),l1lllll_l1_+l1l111_l1_ (u"ࠩส่๊๋๊ำหࠪ⦋"),l1l11ll_l1_,571,l1l111_l1_ (u"ࠪࠫ⦌"),l1l111_l1_ (u"ࠫࠬ⦍"),l1l111_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪ࠱ࠨ⦎"))
	items = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡨ࠴ࠤࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ⦏"),html,re.DOTALL)
	if not items:
		l1111l1_l1_(l1l111_l1_ (u"ࠧࠨ⦐"),l1l111_l1_ (u"ࠨࠩ⦑"),l1l111_l1_ (u"่ࠩ์็฿ࠠโษุ่ࠥอฬࠡัํࠤํออะࠩ⦒"),l1l111_l1_ (u"ࠪห้ฮั็ษ่ะ๊ࠥๅࠡ์ึฮ฼๐ูࠡวํะฬีฺ่๋ࠠห๋ࠦวๅ็๋ๆ฾ࠦร้ࠢอู๊๐ๅࠡษ็้ํู่ࠡฬ฽๎ึ࠭⦓"))
		return
	for title,l1ll1ll_l1_ in items:
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⦔"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ⦕")+l1lllll_l1_+title,l1ll1ll_l1_,571,l1l111_l1_ (u"࠭ࠧ⦖"),l1l111_l1_ (u"ࠧࠨ⦗"),l1l111_l1_ (u"ࠨࡦࡨࡸࡦ࡯࡬ࡴ࠳ࠪ⦘"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡱࡪࡴࡵ࠮ࡲࡵ࡭ࡲࡧࡲࡺࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭⦙"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1llll1l1l1_l1_ = re.findall(l1l111_l1_ (u"ࠪࡀࡱ࡯ࠠࠩ࠰࠭ࡃ࠮ࡂ࠯࡭࡫ࡁࠫ⦚"),block,re.DOTALL)
		l1llll11ll1_l1_ = [l1l111_l1_ (u"ࠫࠬ⦛"),l1l111_l1_ (u"ࠬษแๅษ่࠾ࠥ࠭⦜"),l1l111_l1_ (u"࠭ๅิๆึ่ฬะ࠺ࠡࠩ⦝"),l1l111_l1_ (u"ࠧษำส้ัࡀࠠࠨ⦞"),l1l111_l1_ (u"ࠨฤึ๎ํ๐࠺ࠡࠩ⦟"),l1l111_l1_ (u"ࠩฦ๊๊๐࠺ࠡࠩ⦠")]
		l1l111lll1_l1_ = 0
		for l1llll1ll11_l1_ in l1llll1l1l1_l1_:
			if l1l111lll1_l1_>0: addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ⦡"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ⦢"),l1l111_l1_ (u"ࠬ࠭⦣"),9999)
			items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ⦤"),l1llll1ll11_l1_,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				if l1ll1ll_l1_==l1l111_l1_ (u"ࠧࠤࠩ⦥"): continue
				if l1l111_l1_ (u"ࠨࡪࡷࡸࡵ࠭⦦") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l11ll_l1_+l1ll1ll_l1_
				if title==l1l111_l1_ (u"ࠩࠪ⦧"): continue
				if any(value in title.lower() for value in l11lll_l1_): continue
				title = l1llll11ll1_l1_[l1l111lll1_l1_]+title
				addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⦨"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭⦩")+l1lllll_l1_+title,l1ll1ll_l1_,571,l1l111_l1_ (u"ࠬ࠭⦪"),l1l111_l1_ (u"࠭ࠧ⦫"),l1l111_l1_ (u"ࠧࡥࡧࡷࡥ࡮ࡲࡳ࠳ࠩ⦬"))
			l1l111lll1_l1_ += 1
	return
def l1lll11_l1_(url,type=l1l111_l1_ (u"ࠨࠩ⦭")):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭⦮"),url,l1l111_l1_ (u"ࠪࠫ⦯"),l1l111_l1_ (u"ࠫࠬ⦰"),l1l111_l1_ (u"ࠬ࠭⦱"),l1l111_l1_ (u"࠭ࠧ⦲"),l1l111_l1_ (u"ࠧࡇࡃࡖࡉࡑࡎࡄ࠲࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭⦳"))
	html = response.content
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡪ࠷ࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠫ࠲࠯ࡅࠩࠣࡥࡲࡲࡹࡧࡩ࡯ࡧࡵࠦࠬ⦴"),html,re.DOTALL)
	if not l11ll11_l1_: return
	if type==l1l111_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࡵࠪ⦵"):
		l11llll_l1_ = [html.replace(l1l111_l1_ (u"ࠪࡠࡡ࠵ࠧ⦶"),l1l111_l1_ (u"ࠫ࠴࠭⦷")).replace(l1l111_l1_ (u"ࠬࡢ࡜ࠣࠩ⦸"),l1l111_l1_ (u"࠭ࠢࠨ⦹"))]
	elif type==l1l111_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥ࠳ࠪ⦺"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤ࡫ࡳࡲ࡫ࡓ࡭࡫ࡧࡩࠧ࠮࠮ࠫࡁࠬࠦࡨࡵ࡮ࡵࡣ࡬ࡲࡪࡸࠢࠨ⦻"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭⦼"),block,re.DOTALL)
		l11ll1l11_l1_,l1ll_l1_,l11l11_l1_ = zip(*items)
		items = zip(l1ll_l1_,l11ll1l11_l1_,l11l11_l1_)
	elif type==l1l111_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨ࠷࠭⦽"):
		title,block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࠦࡤࡢࡶࡤ࠱ࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠥࡧ࡬ࡵ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ⦾"),block,re.DOTALL)
	elif type==l1l111_l1_ (u"ࠬࡪࡥࡵࡣ࡬ࡰࡸ࠸ࠧ⦿") and len(l11ll11_l1_)>1:
		title = l11ll11_l1_[0][0]
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⧀"),l1lllll_l1_+title,url,571,l1l111_l1_ (u"ࠧࠨ⧁"),l1l111_l1_ (u"ࠨࠩ⧂"),l1l111_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧ࠶ࠬ⧃"))
		title = l11ll11_l1_[1][0]
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⧄"),l1lllll_l1_+title,url,571,l1l111_l1_ (u"ࠫࠬ⧅"),l1l111_l1_ (u"ࠬ࠭⧆"),l1l111_l1_ (u"࠭ࡤࡦࡶࡤ࡭ࡱࡹ࠳ࠨ⧇"))
		return
	else:
		title,block = l11ll11_l1_[-1]
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠢࡧࡥࡹࡧ࠭ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠣࡪ࠴ࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ⧈"),block,re.DOTALL)
	l1l1_l1_ = []
	for l1ll1ll_l1_,l1ll1l_l1_,title in items:
		if any(value in title.lower() for value in l11lll_l1_): continue
		l1ll1l_l1_ = escapeUNICODE(l1ll1l_l1_)
		l1ll1l_l1_ = l1ll1l_l1_.split(l1l111_l1_ (u"ࠨࡁࡵࡩࡸ࡯ࡺࡦ࠿ࠪ⧉"))[0]
		title = unescapeHTML(title)
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡࠪส่า๊โสࡾะ่็ฯࠩ࠯࡞ࡧ࠯ࠬ⧊"),title,re.DOTALL)
		if l1l111_l1_ (u"ࠪ࠳ࡨࡵ࡬࡭ࡧࡦࡸ࡮ࡵ࡮ࡴ࠱ࠪ⧋") in l1ll1ll_l1_:
			addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⧌"),l1lllll_l1_+title,l1ll1ll_l1_,571,l1ll1l_l1_)
		elif l1l1lll_l1_ and type==l1l111_l1_ (u"ࠬ࠭⧍"):
			title = l1l111_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬ⧎")+l1l1lll_l1_[0][0]
			title = title.strip(l1l111_l1_ (u"ࠧࠡ⠕ࠪ⧏"))
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⧐"),l1lllll_l1_+title,l1ll1ll_l1_,573,l1ll1l_l1_)
				l1l1_l1_.append(title)
		elif l1l111_l1_ (u"ࠩࡨࡴ࡮ࡹ࡯ࡥࡧࡶ࠳ࠬ⧑") in l1ll1ll_l1_ or l1l111_l1_ (u"ࠪࡱࡴࡼࡩࡦࡵ࠲ࠫ⧒") in l1ll1ll_l1_ or l1l111_l1_ (u"ࠫ࡭࡯࡮ࡥ࡫࠲ࠫ⧓") in l1ll1ll_l1_:
			addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ⧔"),l1lllll_l1_+title,l1ll1ll_l1_,572,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⧕"),l1lllll_l1_+title,l1ll1ll_l1_,573,l1ll1l_l1_)
	if type==l1l111_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨ⧖"):
		l111l1l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡰࡳࡷ࡫࡟ࡣࡷࡷࡸࡴࡴ࡟ࡱࡣࡪࡩࠧࡀࠨ࠯ࠬࡂ࠭࠱࠭⧗"),block,re.DOTALL)
		if l111l1l1ll_l1_:
			count = l111l1l1ll_l1_[0]
			l1ll1ll_l1_ = url+l1l111_l1_ (u"ࠩ࠲ࡳ࡫࡬ࡳࡦࡶ࠲ࠫ⧘")+count
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⧙"),l1lllll_l1_+l1l111_l1_ (u"ฺࠫ็อสࠢฦาึ๏ࠧ⧚"),l1ll1ll_l1_,571,l1l111_l1_ (u"ࠬ࠭⧛"),l1l111_l1_ (u"࠭ࠧ⧜"),l1l111_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨ⧝"))
	elif l1l111_l1_ (u"ࠨࡦࡨࡸࡦ࡯࡬ࡴࠩ⧞") in type:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠤࡦࡰࡦࡹࡳ࠾ࠩࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠥ⧟"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠥ࡬ࡷ࡫ࡦ࠾ࠩࠫ࠲࠯ࡅࠩࠨ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠧ⧠"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				title = l1l111_l1_ (u"ฺࠫ็อสࠢࠪ⧡")+unescapeHTML(title)
				addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⧢"),l1lllll_l1_+title,l1ll1ll_l1_,571,l1l111_l1_ (u"࠭ࠧ⧣"),l1l111_l1_ (u"ࠧࠨ⧤"),l1l111_l1_ (u"ࠨࡦࡨࡸࡦ࡯࡬ࡴ࠶ࠪ⧥"))
	return
def l1111lll1_l1_(url,type=l1l111_l1_ (u"ࠩࠪ⧦")):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ⧧"),url,l1l111_l1_ (u"ࠫࠬ⧨"),l1l111_l1_ (u"ࠬ࠭⧩"),l1l111_l1_ (u"࠭ࠧ⧪"),l1l111_l1_ (u"ࠧࠨ⧫"),l1l111_l1_ (u"ࠨࡈࡄࡗࡊࡒࡈࡅ࠳࠰ࡗࡊࡇࡓࡐࡐࡖࡣࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪ⧬"))
	html = response.content
	l111lll1l1_l1_ = False
	if not type:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡷࡪࡧࡳࡰࡰࡏ࡭ࡸࡺࠢࠩ࠰࠭ࡃ࠮ࠨࡣࡰࡰࡷࡥ࡮ࡴࡥࡳࠤࠪ⧭"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦࠡ࠿ࠣࡠࠬ࠮࠮ࠫࡁࠬࡠࠬ࠴ࠪࡀࠢࡧࡥࡹࡧ࠭ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡢ࡮ࡷࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠣࡶ࡬ࡸࡱ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭⧮"),block,re.DOTALL)
			if len(items)>1:
				l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ⧯"))
				l111lll1l1_l1_ = True
				for l1ll1ll_l1_,l1ll1l_l1_,name,title in items:
					name = unescapeHTML(name)
					if l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ⧰") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l11ll_l1_+l1ll1ll_l1_
					title = name+l1l111_l1_ (u"࠭ࠠ࠮ࠢࠪ⧱")+title
					addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⧲"),l1lllll_l1_+title,l1ll1ll_l1_,573,l1ll1l_l1_,l1l111_l1_ (u"ࠨࠩ⧳"),l1l111_l1_ (u"ࠩࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫ⧴"))
	if type==l1l111_l1_ (u"ࠪࡩࡵ࡯ࡳࡰࡦࡨࡷࠬ⧵") or not l111lll1l1_l1_:
		l11l_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡶ࡯ࡴࡶࡨࡶࡎࡳࡧࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ⧶"),html,re.DOTALL)
		if l11l_l1_: l1ll1l_l1_ = l11l_l1_[0]
		else: l1ll1l_l1_ = l1l111_l1_ (u"ࠬ࠭⧷")
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡦࡲࡄࡰࡱࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ⧸"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ⧹"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				title = title.strip(l1l111_l1_ (u"ࠨࠢࠪ⧺"))
				title = unescapeHTML(title)
				addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ⧻"),l1lllll_l1_+title,l1ll1ll_l1_,572,l1ll1l_l1_)
	return
def PLAY(url):
	l1ll11l1_l1_,l1llll1l111_l1_,l1llll1l1ll_l1_ = [],[],[]
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ⧼"),url,l1l111_l1_ (u"ࠫࠬ⧽"),l1l111_l1_ (u"ࠬ࠭⧾"),l1l111_l1_ (u"࠭ࠧ⧿"),l1l111_l1_ (u"ࠧࠨ⨀"),l1l111_l1_ (u"ࠨࡈࡄࡗࡊࡒࡈࡅ࠳࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ⨁"))
	html = response.content
	l1llll11l1l_l1_ = re.findall(l1l111_l1_ (u"่ࠩืฯ๎้ࠡษ็ู้อ็ะห࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃ࠭⨂"),html,re.DOTALL)
	if l1llll11l1l_l1_:
		l1111ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡹࡧࡧࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ⨃"),html,re.DOTALL)
		if l1111ll_l1_ and l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_): return
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡼࡩࡥࡧࡲࡖࡴࡽࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ⨄"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ⨅"),block,re.DOTALL)
		for l1ll1ll_l1_ in items:
			l1ll1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"࠭ࠦࡪ࡯ࡪࡁࠬ⨆"))[0]
			l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࡠࡡࡨࡱࡧ࡫ࡤࠨ⨇"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡵࡷࡶࡪࡧ࡭ࡉࡧࡤࡨࡪࡸࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ⨈"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠤ࡫ࡶࡪ࡬ࠠ࠾ࠢࠪࠬ࠳࠰࠿ࠪࠩ࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠧ⨉"),block,re.DOTALL)
		for l1ll1ll_l1_,name in items:
			l1ll1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠪࠪ࡮ࡳࡧ࠾ࠩ⨊"))[0]
			name = name.strip(l1l111_l1_ (u"ࠫࠥ࠭⨋"))
			l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭⨌")+name+l1l111_l1_ (u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧ⨍"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡥࡱࡺࡲࡱࡵࡡࡥࡎ࡬ࡲࡰࡹࠨ࠯ࠬࡂ࠭ࡧࡲࡡࡤ࡭ࡺ࡭ࡳࡪ࡯ࡸࠩ⨎"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࠳ࡸࡶࡡ࡯ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ⨏"),block,re.DOTALL)
		for l1ll1ll_l1_,name in items:
			l1ll1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠩࠩ࡭ࡲ࡭࠽ࠨ⨐"))[0]
			l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ⨑")+name+l1l111_l1_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨ⨒"))
	for l1llll11lll_l1_ in l1ll11l1_l1_:
		l1ll1ll_l1_,name = l1llll11lll_l1_.split(l1l111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࠬ⨓"))
		if l1ll1ll_l1_ not in l1llll1l111_l1_:
			l1llll1l111_l1_.append(l1ll1ll_l1_)
			l1llll1l1ll_l1_.append(l1llll11lll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll1l1ll_l1_,l1ll1_l1_,l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ⨔"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠧࠨ⨕"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠨࠩ⨖"): return
	search = search.replace(l1l111_l1_ (u"ࠩࠣࠫ⨗"),l1l111_l1_ (u"ࠪ࠯ࠬ⨘"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡅࡳ࠾ࠩ⨙")+search
	l1l11ll_l1_,l1lllll1_l1_,l1lll1l11_l1_ = l1lllll11l1_l1_(url,l1l111_l1_ (u"ࠬ࡬ࡡࡴࡧ࡯࡬ࡩ࠷ࠧ⨚"),l1l111_l1_ (u"࠭แศื็ࠤส฿ไศ่ํࠫ⨛"),l1l111_l1_ (u"ࠧࡥࡷࡥࡦࡪࡪ࠭࡮ࡱࡹ࡭ࡪࡹࠧ⨜"))
	l1lll11_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠨࡦࡨࡸࡦ࡯࡬ࡴ࠷ࠪ⨝"))
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠪࡇࡎࡓࡁࡄࡎࡘࡆࠬᖏ")
l1lllll_l1_ = l1l111_l1_ (u"ࠫࡤࡉࡃࡃࡡࠪᖐ")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠬ฿ัุ้ࠣห้๋ีศำ฼๋ࠬᖑ"),l1l111_l1_ (u"࠭ไๅๅหหึࠦแใูࠣ࠯࠶࠾ࠧᖒ"),l1l111_l1_ (u"ࠧศๆิส๏ู๊สࠩᖓ"),l1l111_l1_ (u"ࠨษไ่ฬ๋ࠠๅๆๆฬฬืࠠโไฺࠫᖔ"),l1l111_l1_ (u"ࠩࡇࡑࡈࡇࠧᖕ")]
def l11l1ll_l1_(mode,url,l1llllll1_l1_,text):
	if   mode==820: l1lll_l1_ = l1l1l11_l1_()
	elif mode==821: l1lll_l1_ = l1lll11_l1_(url,l1llllll1_l1_)
	elif mode==822: l1lll_l1_ = PLAY(url)
	elif mode==823: l1lll_l1_ = l1111lll1_l1_(url,text)
	elif mode==824: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠪࡊ࡚ࡒࡌࡠࡈࡌࡐ࡙ࡋࡒࡠࡡࡢࠫᖖ")+text)
	elif mode==825: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠫࡉࡋࡆࡊࡐࡈࡈࡤࡌࡉࡍࡖࡈࡖࡤࡥ࡟ࠨᖗ")+text)
	elif mode==829: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩᖘ"),l111l1_l1_,l1l111_l1_ (u"࠭ࠧᖙ"),l1l111_l1_ (u"ࠧࠨᖚ"),l1l111_l1_ (u"ࠨࠩᖛ"),l1l111_l1_ (u"ࠩࠪᖜ"),l1l111_l1_ (u"ࠪࡇࡎࡓࡁࡄࡎࡘࡆ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧᖝ"))
	html = response.content
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᖞ"),l1lllll_l1_+l1l111_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬᖟ"),l111l1_l1_,829,l1l111_l1_ (u"࠭ࠧᖠ"),l1l111_l1_ (u"ࠧࠨᖡ"),l1l111_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᖢ"))
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧᖣ"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᖤ"),l1l111_l1_ (u"ࠫࠬᖥ"),9999)
	l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡳ࡭࡫ࡧࡩࡷ࡮࡯࡮ࡧ࠱ࡴ࡭ࡶࠧᖦ")
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᖧ"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩᖨ")+l1lllll_l1_+l1l111_l1_ (u"ࠨษ็้๊๐าสࠩᖩ"),l1ll1ll_l1_,821,l1l111_l1_ (u"ࠩࠪᖪ"),l1l111_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬᖫ"),l1l111_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᖬ"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡔࡢࡤࡶࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᖭ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡧࡦࡶࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀࠬᖮ"),block,re.DOTALL)
		for data,title in items:
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡩࡨࡸࡵࡵࡳࡵࡵࡂࡸࡾࡶࡥ࠾ࡱࡱࡩࠫࡪࡡࡵࡣࡀࠫᖯ")+data
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᖰ"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫᖱ")+l1lllll_l1_+title,l1ll1ll_l1_,821,l1l111_l1_ (u"ࠪࠫᖲ"),l1l111_l1_ (u"ࠫ࡭࡯ࡧࡩࡧࡶࡸࠬᖳ"))
		addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᖴ"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᖵ"),l1l111_l1_ (u"ࠧࠨᖶ"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡰࡤࡺ࡮࡭ࡡࡵ࡫ࡲࡲ࠲ࡳࡥ࡯ࡷࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧᖷ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨᖸ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if l1l111_l1_ (u"ࠪ࠳ࠬᖹ") not in l1ll1ll_l1_: continue
			if title in l11lll_l1_: continue
			l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᖺ"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧᖻ")+l1lllll_l1_+title,l1ll1ll_l1_,821)
	return
def l1lll11_l1_(url,type=l1l111_l1_ (u"࠭ࠧᖼ")):
	block,items = l1l111_l1_ (u"ࠧࠨᖽ"),[]
	if type==l1l111_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪᖾ"):
		headers = {l1l111_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨᖿ"):l1l111_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥࠩᗀ")}
		payload = l1l111_l1_ (u"ࠫ࡬࡫ࡴࠨᗁ")
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡖࡏࡔࡖࠪᗂ"),url,payload,headers,l1l111_l1_ (u"࠭ࠧᗃ"),l1l111_l1_ (u"ࠧࠨᗄ"),l1l111_l1_ (u"ࠨࡅࡌࡑࡆࡉࡌࡖࡄ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧᗅ"))
		html = response.content
		items = re.findall(l1l111_l1_ (u"ࠩࠥ࡭ࡲࡧࡧࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠢࡵ࡫ࡷࡰࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡺࡸ࡬ࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪᗆ"),html,re.DOTALL)
		l1111l11l_l1_,l11l11_l1_,l1ll_l1_ = zip(*items)
		items = zip(l1ll_l1_,l1111l11l_l1_,l11l11_l1_)
	elif type==l1l111_l1_ (u"ࠪ࡬࡮࡭ࡨࡦࡵࡷࠫᗇ"):
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨᗈ"),url,l1l111_l1_ (u"ࠬ࠭ᗉ"),l1l111_l1_ (u"࠭ࠧᗊ"),l1l111_l1_ (u"ࠧࠨᗋ"),l1l111_l1_ (u"ࠨࠩᗌ"),l1l111_l1_ (u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅ࠱࡙ࡏࡔࡍࡇࡖ࠱࠷ࡴࡤࠨᗍ"))
		html = response.content
	else:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧᗎ"),url,l1l111_l1_ (u"ࠫࠬᗏ"),l1l111_l1_ (u"ࠬ࠭ᗐ"),l1l111_l1_ (u"࠭ࠧᗑ"),l1l111_l1_ (u"ࠧࠨᗒ"),l1l111_l1_ (u"ࠨࡅࡌࡑࡆࡉࡌࡖࡄ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠷ࡷࡪࠧᗓ"))
		html = response.content
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡰࡩࡩ࡯ࡡ࠮ࡤ࡯ࡳࡨࡱࠨ࠯ࠬࡂ࠭࡫ࡵ࡯ࡵࡧࡵ࠱ࡲ࡫࡮ࡶࠩᗔ"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	if not block: block = html
	if not items: items = re.findall(l1l111_l1_ (u"ࠪࡧࡴࡴࡴࡦࡰࡷ࠱ࡧࡵࡸ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࡮࠳࠿ࠪ࠱࠮ࡄ࠯࠼ࠨᗕ"),block,re.DOTALL)
	l111l1111_l1_ = []
	for l1ll1ll_l1_,l1ll1l_l1_,title in items:
		l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠫࡡ࠵ࠧᗖ"),l1l111_l1_ (u"ࠬ࠵ࠧᗗ"))
		l1ll1l_l1_ = l1ll1l_l1_.replace(l1l111_l1_ (u"࠭࡜࠰ࠩᗘ"),l1l111_l1_ (u"ࠧ࠰ࠩᗙ"))
		l1ll1ll_l1_ = escapeUNICODE(l1ll1ll_l1_)
		title = escapeUNICODE(title)
		if l1l111_l1_ (u"ࠨ࠱ࡨࡴ࡮ࡹ࡯ࡥࡧ࠲ࠫᗚ") in l1ll1ll_l1_:
			l1111l1l_l1_ = re.findall(l1l111_l1_ (u"ࠩࠫ࠲࠯ࡅ่ࠩࠡࠪ์ุ๋ࡼศๆ่์ุ๋ࠩࠨᗛ"),title,re.DOTALL)
			if l1111l1l_l1_: title = l1111l1l_l1_[0][0]
			else:
				l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢࠫั้่ษࡽษ็ั้่ษࠪࠩᗜ"),title,re.DOTALL)
				if l1l1lll_l1_: title = l1l1lll_l1_[0][0]
			if title in l111l1111_l1_: continue
			l111l1111_l1_.append(title)
			title = l1l111_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪᗝ")+title.strip(l1l111_l1_ (u"ࠬࠦ⠓ࠡࠩᗞ"))
		if l1l111_l1_ (u"࠭࠯ࡦࡲ࡬ࡷࡴࡪࡥࡴࠩᗟ") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᗠ"),l1lllll_l1_+title,l1ll1ll_l1_,821,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠨ࠱ࡶࡩࡦࡹ࡯࡯ࡵࠪᗡ") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᗢ"),l1lllll_l1_+title,l1ll1ll_l1_,821,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧ࠲ࠫᗣ") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᗤ"),l1lllll_l1_+title,l1ll1ll_l1_,823,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠬ࠵ࡡ࡯࡫ࡰࡩ࠲ࡹࡥࡳ࡫ࡨ࠳ࠬᗥ") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᗦ"),l1lllll_l1_+title,l1ll1ll_l1_,823,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠧ࠰ࡵࡨࡥࡸࡵ࡮࠰ࠩᗧ") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᗨ"),l1lllll_l1_+title,l1ll1ll_l1_,823,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠩ࠲ࡩࡵ࡯ࡳࡰࡦࡨ࠳ࠬᗩ") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᗪ"),l1lllll_l1_+title,l1ll1ll_l1_,823,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪᗫ"),l1lllll_l1_+title,l1ll1ll_l1_,822,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬᗬ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬᗭ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			if title: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᗮ"),l1lllll_l1_+l1l111_l1_ (u"ࠨืไัฮࠦࠧᗯ")+title,l1ll1ll_l1_,821)
	return
def l1111lll1_l1_(url,l1l11_l1_):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭ᗰ"),url,l1l111_l1_ (u"ࠪࠫᗱ"),l1l111_l1_ (u"ࠫࠬᗲ"),l1l111_l1_ (u"ࠬ࠭ᗳ"),l1l111_l1_ (u"࠭ࠧᗴ"),l1l111_l1_ (u"ࠧࡄࡋࡐࡅࡈࡒࡕࡃ࠯ࡖࡉࡆ࡙ࡏࡏࡕࡢࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩᗵ"))
	html = response.content
	l1ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠨࡲࡲࡷࡹ࡫ࡲ࠮࡫ࡰࡥ࡬࡫࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᗶ"),html,re.DOTALL)
	l1ll1l_l1_ = l1ll1l_l1_[0] if l1ll1l_l1_ else l1l111_l1_ (u"ࠩࠪᗷ")
	items = []
	if not l1l11_l1_:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡘ࡫ࡡࡴࡱࡱࡷࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩᗸ"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠫࡁࡲࡩ࠯ࠬࡂࡨࡦࡺࡡ࠮ࡵࡨࡥࡸࡵ࡮࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡧࡥࡹࡧ࠭ࡔ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡨࡦࡺࡡ࠮ࡄࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᗹ"),block,re.DOTALL)
			if len(items)>1:
				for l1l11_l1_,l1111ll1l_l1_,l1111llll_l1_,title in items:
					title = title.replace(l1l111_l1_ (u"ࠬࠦࠠࠨᗺ"),l1l111_l1_ (u"࠭ࠠࠨᗻ"))
					l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡣ࡭ࡥࡽࡉࡥ࡯ࡶࡨࡶࡄࡥࡡࡤࡶ࡬ࡳࡳࡃࡇࡦࡶࡖࡩࡦࡹ࡯࡯ࡇࡳࠪࡤࡹࡥࡢࡵࡲࡲࡂ࠭ᗼ")+l1l11_l1_+l1l111_l1_ (u"ࠨࠨࡢࡗࡂ࠭ᗽ")+l1111ll1l_l1_+l1l111_l1_ (u"ࠩࠩࡣࡇࡃࠧᗾ")+l1111llll_l1_
					addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᗿ"),l1lllll_l1_+title,l1ll1ll_l1_,823,l1ll1l_l1_,l1l111_l1_ (u"ࠫࠬᘀ"),l1l11_l1_)
	if len(items)<2:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡅࡱ࡫ࡶࡳࡩ࡫ࡳࠡࡵࡨࡰࡪࡩࡴࡦࡦࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧᘁ"),html,re.DOTALL)
		if l11llll_l1_: l111l11l1_l1_,block = l1l111_l1_ (u"࠭ࠧᘂ"),l11llll_l1_[0]
		else: l111l11l1_l1_,block = l1l111_l1_ (u"ࠧๆ๊ึ้ࠥ࠭ᘃ")+l1l11_l1_,html
		items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࡫࡭࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡧࡰࡂࠬᘄ"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l1l1lll_l1_ in items:
			l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			title = l111l11l1_l1_+l1l111_l1_ (u"ࠩࠣั้่ษࠡࠩᘅ")+l1l1lll_l1_.strip(l1l111_l1_ (u"ࠪࠤࠬᘆ"))
			addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪᘇ"),l1lllll_l1_+title,l1ll1ll_l1_,822,l1ll1l_l1_)
	return
def PLAY(url):
	url = url.replace(l1l111_l1_ (u"ࠬ࠵ࡥࡱ࡫ࡶࡳࡩ࡫࠯ࠨᘈ"),l1l111_l1_ (u"࠭࠯ࡸࡣࡷࡧ࡭࠵ࠧᘉ")).replace(l1l111_l1_ (u"ࠧ࠰ࡣࡱ࡭ࡲ࡫࠯ࠨᘊ"),l1l111_l1_ (u"ࠨ࠱ࡺࡥࡹࡩࡨ࠰ࠩᘋ")).replace(l1l111_l1_ (u"ࠩ࠲ࡱࡴࡼࡩࡦ࠱ࠪᘌ"),l1l111_l1_ (u"ࠪ࠳ࡼࡧࡴࡤࡪ࠲ࠫᘍ"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨᘎ"),url,l1l111_l1_ (u"ࠬ࠭ᘏ"),l1l111_l1_ (u"࠭ࠧᘐ"),l1l111_l1_ (u"ࠧࠨᘑ"),l1l111_l1_ (u"ࠨࠩᘒ"),l1l111_l1_ (u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭ᘓ"))
	html = response.content
	l1ll11l1_l1_,l1111l1ll_l1_ = [],[]
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡴࡱࡧࡹࡦࡴ࠰ࡻࡷࡧࡰࡦࡴ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᘔ"),html,re.DOTALL)
	if l1ll1ll_l1_:
		l1ll1ll_l1_ = l1ll1ll_l1_[0]
		l1111l1ll_l1_.append(l1ll1ll_l1_)
		server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠫࡳࡧ࡭ࡦࠩᘕ"))
		l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭ᘖ")+server+l1l111_l1_ (u"࠭࡟ࡠࡧࡰࡦࡪࡪࠧᘗ"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡴࡧࡵࡺࡪࡸࡳ࠮ࡶࡤࡦࡸ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩᘘ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡥ࡮ࡤࡨࡨࡩࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡩࡲࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ᘙ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			l1ll1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠩࠩ࡭ࡲ࡭࠽ࠨᘚ"),1)[0]
			title = title.strip(l1l111_l1_ (u"ࠪࠤࠬᘛ"))
			if l1ll1ll_l1_ not in l1111l1ll_l1_:
				l1111l1ll_l1_.append(l1ll1ll_l1_)
				l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬᘜ")+title+l1l111_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭ᘝ"))
	items = re.findall(l1l111_l1_ (u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤ࠮ࡤ࡯ࡳࡨࡱ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࡭࠹࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡩ࠵ࡁࠫᘞ"),html,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if l1ll1ll_l1_ not in l1111l1ll_l1_:
			l1111l1ll_l1_.append(l1ll1ll_l1_)
			title = title.replace(l1l111_l1_ (u"ࠧ࠽ࡵࡳࡥࡳࡄࠧᘟ"),l1l111_l1_ (u"ࠨࠢࠪᘠ")).replace(l1l111_l1_ (u"ࠩ࠿࠳ࡸࡶࡡ࡯ࡀࠪᘡ"),l1l111_l1_ (u"ࠪࠫᘢ")).replace(l1l111_l1_ (u"ࠫࡁ࡯࠾ࠨᘣ"),l1l111_l1_ (u"ࠬ࠭ᘤ")).replace(l1l111_l1_ (u"࠭࠼࠰࡫ࡁࠫᘥ"),l1l111_l1_ (u"ࠧࠡࠩᘦ"))
			title = title.strip(l1l111_l1_ (u"ࠨࠢࠪᘧ"))
			l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪᘨ")+title+l1l111_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧᘩ"))
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll11l1_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪᘪ"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search: search = l1llll1_l1_()
	if not search: return
	search = search.replace(l1l111_l1_ (u"ࠬࠦࠧᘫ"),l1l111_l1_ (u"࠭ࠫࠨᘬ"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨࡀࡵࡀࠫᘭ")+search
	l1lll11_l1_(url,l1l111_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࠨᘮ"))
	return
def l11l111l1_l1_(url):
	url = url.split(l1l111_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭ᘯ"))[0]
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧᘰ"),url,l1l111_l1_ (u"ࠫࠬᘱ"),l1l111_l1_ (u"ࠬ࠭ᘲ"),l1l111_l1_ (u"࠭ࠧᘳ"),l1l111_l1_ (u"ࠧࠨᘴ"),l1l111_l1_ (u"ࠨࡅࡌࡑࡆࡉࡌࡖࡄ࠰ࡋࡊ࡚࡟ࡇࡋࡏࡘࡊࡘࡓࡠࡄࡏࡓࡈࡑࡓ࠮࠳ࡶࡸࠬᘵ"))
	html = response.content
	l1l11l1l_l1_ = []
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡤࡨࡻࡧ࡮ࡤࡧࡧ࠱ࡸ࡫ࡡࡳࡥ࡫ࠬ࠳࠰࠿ࠪ࠾࠲ࡪࡴࡸ࡭࠿ࠩᘶ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1l11l1l_l1_ = re.findall(l1l111_l1_ (u"ࠪࡷࡪࡲࡥࡤࡶ࠰ࡱࡪࡴࡵࠣࡀ࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁࡧࡥࡹࡧ࠭ࡵࡣࡻࡁࠧ࠮࠮ࠫࡁࠬࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᘷ"),block,re.DOTALL)
		names,l1111l111_l1_,l1lll1l1_l1_ = zip(*l1l11l1l_l1_)
		l1l11l1l_l1_ = zip(names,l1111l111_l1_,l1lll1l1_l1_)
	return l1l11l1l_l1_
def l111ll1ll_l1_(block):
	items = re.findall(l1l111_l1_ (u"ࠫࡨࡧࡴ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡧࡵ࡬ࡥࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪᘸ"),block,re.DOTALL)
	return items
def l11111lll_l1_(url):
	if l1l111_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩᘹ") in url:
		url,filters = url.split(l1l111_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪᘺ"))
		l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡩࡨࡸࡵࡵࡳࡵࡵࡂࠫᘻ")+filters
	else: l1ll1ll_l1_ = l111l1_l1_
	return l1ll1ll_l1_
l1111l1l1_l1_ = [l1l111_l1_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳࡻࠪᘼ"),l1l111_l1_ (u"ࠩࡵࡩࡱ࡫ࡡࡴࡧ࠰ࡽࡪࡧࡲࠨᘽ"),l1l111_l1_ (u"ࠪ࡫ࡪࡴࡲࡦࠩᘾ"),l1l111_l1_ (u"ࠫࡶࡻࡡ࡭࡫ࡷࡽࠬᘿ")]
l111l111l_l1_ = [l1l111_l1_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿࠧᙀ"),l1l111_l1_ (u"࠭ࡲࡦ࡮ࡨࡥࡸ࡫࠭ࡺࡧࡤࡶࠬᙁ"),l1l111_l1_ (u"ࠧࡨࡧࡱࡶࡪ࠭ᙂ")]
def l1l1ll1l_l1_(url,filter):
	url = url.split(l1l111_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬᙃ"))[0]
	type,filter = filter.split(l1l111_l1_ (u"ࠩࡢࡣࡤ࠭ᙄ"),1)
	if filter==l1l111_l1_ (u"ࠪࠫᙅ"): l11lll1l_l1_,l11lll11_l1_ = l1l111_l1_ (u"ࠫࠬᙆ"),l1l111_l1_ (u"ࠬ࠭ᙇ")
	else: l11lll1l_l1_,l11lll11_l1_ = filter.split(l1l111_l1_ (u"࠭࡟ࡠࡡࠪᙈ"))
	if type==l1l111_l1_ (u"ࠧࡅࡇࡉࡍࡓࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࠨᙉ"):
		if l111l111l_l1_[0]+l1l111_l1_ (u"ࠨ࠿ࠪᙊ") not in l11lll1l_l1_: category = l111l111l_l1_[0]
		for i in range(len(l111l111l_l1_[0:-1])):
			if l111l111l_l1_[i]+l1l111_l1_ (u"ࠩࡀࠫᙋ") in l11lll1l_l1_: category = l111l111l_l1_[i+1]
		l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠪࠪࠬᙌ")+category+l1l111_l1_ (u"ࠫࡂ࠶ࠧᙍ")
		l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠬࠬࠧᙎ")+category+l1l111_l1_ (u"࠭࠽࠱ࠩᙏ")
		l1l111l1_l1_ = l1l11ll1_l1_.strip(l1l111_l1_ (u"ࠧࠧࠩᙐ"))+l1l111_l1_ (u"ࠨࡡࡢࡣࠬᙑ")+l1l1ll11_l1_.strip(l1l111_l1_ (u"ࠩࠩࠫᙒ"))
		l11ll111_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭ᙓ"))
		l1lllll1_l1_ = url+l1l111_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨᙔ")+l11ll111_l1_
	elif type==l1l111_l1_ (u"ࠬࡌࡕࡍࡎࡢࡊࡎࡒࡔࡆࡔࠪᙕ"):
		l11l1l1l_l1_ = l11ll1l1_l1_(l11lll1l_l1_,l1l111_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨᙖ"))
		l11l1l1l_l1_ = l111l11_l1_(l11l1l1l_l1_)
		if l11lll11_l1_: l11lll11_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪᙗ"))
		if not l11lll11_l1_: l1lllll1_l1_ = url
		else: l1lllll1_l1_ = url+l1l111_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬᙘ")+l11lll11_l1_
		l1llllll_l1_ = l11111lll_l1_(l1lllll1_l1_)
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᙙ"),l1lllll_l1_+l1l111_l1_ (u"ࠪว฽ํวาࠢๅหห๋ษࠡษ็ๅ๏ี๊้ࠢส่ฯ๐ࠠห็ࠣหำะ๊ศำ๊หࠥ࠭ᙚ"),l1llllll_l1_,821,l1l111_l1_ (u"ࠫࠬᙛ"),l1l111_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࠬᙜ"))
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᙝ"),l1lllll_l1_+l1l111_l1_ (u"ࠧࠡ࡝࡞ࠤࠥࠦࠧᙞ")+l11l1l1l_l1_+l1l111_l1_ (u"ࠨࠢࠣࠤࡢࡣࠧᙟ"),l1llllll_l1_,821,l1l111_l1_ (u"ࠩࠪᙠ"),l1l111_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࠪᙡ"))
		addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᙢ"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬᙣ"),l1l111_l1_ (u"࠭ࠧᙤ"),9999)
	l1l11l1l_l1_ = l11l111l1_l1_(url)
	dict = {}
	for name,l1l111ll_l1_,block in l1l11l1l_l1_:
		name = name.replace(l1l111_l1_ (u"ࠧไๆࠣࠫᙥ"),l1l111_l1_ (u"ࠨࠩᙦ"))
		items = l111ll1ll_l1_(block)
		if l1l111_l1_ (u"ࠩࡀࠫᙧ") not in l1lllll1_l1_: l1lllll1_l1_ = url
		if type==l1l111_l1_ (u"ࠪࡈࡊࡌࡉࡏࡇࡇࡣࡋࡏࡌࡕࡇࡕࠫᙨ"):
			if category!=l1l111ll_l1_: continue
			elif len(items)<2:
				if l1l111ll_l1_==l111l111l_l1_[-1]:
					l1llllll_l1_ = l11111lll_l1_(l1lllll1_l1_)
					l1lll11_l1_(l1llllll_l1_,l1l111_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࠫᙩ"))
				else: l1l1ll1l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠬࡊࡅࡇࡋࡑࡉࡉࡥࡆࡊࡎࡗࡉࡗࡥ࡟ࡠࠩᙪ")+l1l111l1_l1_)
				return
			else:
				if l1l111ll_l1_==l111l111l_l1_[-1]:
					l1llllll_l1_ = l11111lll_l1_(l1lllll1_l1_)
					addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᙫ"),l1lllll_l1_+l1l111_l1_ (u"ࠧศๆฯ้๏฿ࠠࠨᙬ"),l1llllll_l1_,821,l1l111_l1_ (u"ࠨࠩ᙭"),l1l111_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࠩ᙮"))
				else: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᙯ"),l1lllll_l1_+l1l111_l1_ (u"ࠫฬ๊ฬๆ์฼ࠤࠬᙰ"),l1lllll1_l1_,825,l1l111_l1_ (u"ࠬ࠭ᙱ"),l1l111_l1_ (u"࠭ࠧᙲ"),l1l111l1_l1_)
		elif type==l1l111_l1_ (u"ࠧࡇࡗࡏࡐࡤࡌࡉࡍࡖࡈࡖࠬᙳ"):
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠨࠨࠪᙴ")+l1l111ll_l1_+l1l111_l1_ (u"ࠩࡀ࠴ࠬᙵ")
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠪࠪࠬᙶ")+l1l111ll_l1_+l1l111_l1_ (u"ࠫࡂ࠶ࠧᙷ")
			l1l111l1_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠬࡥ࡟ࡠࠩᙸ")+l1l1ll11_l1_
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᙹ"),l1lllll_l1_+l1l111_l1_ (u"ࠧศๆฯ้๏฿ࠠ࠻ࠩᙺ")+name,l1lllll1_l1_,824,l1l111_l1_ (u"ࠨࠩᙻ"),l1l111_l1_ (u"ࠩࠪᙼ"),l1l111l1_l1_)
		dict[l1l111ll_l1_] = {}
		for value,option in items:
			if not value: continue
			if option in l11lll_l1_: continue
			dict[l1l111ll_l1_][value] = option
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠪࠪࠬᙽ")+l1l111ll_l1_+l1l111_l1_ (u"ࠫࡂ࠭ᙾ")+option
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠬࠬࠧᙿ")+l1l111ll_l1_+l1l111_l1_ (u"࠭࠽ࠨ ")+value
			l1l1l11l_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠧࡠࡡࡢࠫᚁ")+l1l1ll11_l1_
			title = option+l1l111_l1_ (u"ࠨࠢ࠽ࠫᚂ")#+dict[l1l111ll_l1_][l1l111_l1_ (u"ࠩ࠳ࠫᚃ")]
			title = option+l1l111_l1_ (u"ࠪࠤ࠿࠭ᚄ")+name
			if type==l1l111_l1_ (u"ࠫࡋ࡛ࡌࡍࡡࡉࡍࡑ࡚ࡅࡓࠩᚅ"): addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᚆ"),l1lllll_l1_+title,url,824,l1l111_l1_ (u"࠭ࠧᚇ"),l1l111_l1_ (u"ࠧࠨᚈ"),l1l1l11l_l1_)
			elif type==l1l111_l1_ (u"ࠨࡆࡈࡊࡎࡔࡅࡅࡡࡉࡍࡑ࡚ࡅࡓࠩᚉ") and l111l111l_l1_[-2]+l1l111_l1_ (u"ࠩࡀࠫᚊ") in l11lll1l_l1_:
				l11ll111_l1_ = l11ll1l1_l1_(l1l1ll11_l1_,l1l111_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭ᚋ"))
				l1lllll1_l1_ = url+l1l111_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨᚌ")+l11ll111_l1_
				l1llllll_l1_ = l11111lll_l1_(l1lllll1_l1_)
				addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᚍ"),l1lllll_l1_+title,l1llllll_l1_,821,l1l111_l1_ (u"࠭ࠧᚎ"),l1l111_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࠧᚏ"))
			else: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᚐ"),l1lllll_l1_+title,url,825,l1l111_l1_ (u"ࠩࠪᚑ"),l1l111_l1_ (u"ࠪࠫᚒ"),l1l1l11l_l1_)
	return
def l11ll1l1_l1_(filters,mode):
	filters = filters.replace(l1l111_l1_ (u"ࠫࡂࠬࠧᚓ"),l1l111_l1_ (u"ࠬࡃ࠰ࠧࠩᚔ"))
	filters = filters.strip(l1l111_l1_ (u"࠭ࠦࠨᚕ"))
	l11lllll_l1_ = {}
	if l1l111_l1_ (u"ࠧ࠾ࠩᚖ") in filters:
		items = filters.split(l1l111_l1_ (u"ࠨࠨࠪᚗ"))
		for item in items:
			var,value = item.split(l1l111_l1_ (u"ࠩࡀࠫᚘ"))
			l11lllll_l1_[var] = value
	l1l1l111_l1_ = l1l111_l1_ (u"ࠪࠫᚙ")
	for key in l1111l1l1_l1_:
		if key in list(l11lllll_l1_.keys()): value = l11lllll_l1_[key]
		else: value = l1l111_l1_ (u"ࠫ࠵࠭ᚚ")
		if l1l111_l1_ (u"ࠬࠫࠧ᚛") not in value: value = QUOTE(value)
		if mode==l1l111_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨ᚜") and value!=l1l111_l1_ (u"ࠧ࠱ࠩ᚝"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠨࠢ࠮ࠤࠬ᚞")+value
		elif mode==l1l111_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ᚟") and value!=l1l111_l1_ (u"ࠪ࠴ࠬᚠ"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠫࠫ࠭ᚡ")+key+l1l111_l1_ (u"ࠬࡃࠧᚢ")+value
		elif mode==l1l111_l1_ (u"࠭ࡡ࡭࡮ࠪᚣ"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠧࠧࠩᚤ")+key+l1l111_l1_ (u"ࠨ࠿ࠪᚥ")+value
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠩࠣ࠯ࠥ࠭ᚦ"))
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠪࠪࠬᚧ"))
	l1l1l111_l1_ = l1l1l111_l1_.replace(l1l111_l1_ (u"ࠫࡂ࠶ࠧᚨ"),l1l111_l1_ (u"ࠬࡃࠧᚩ"))
	return l1l1l111_l1_
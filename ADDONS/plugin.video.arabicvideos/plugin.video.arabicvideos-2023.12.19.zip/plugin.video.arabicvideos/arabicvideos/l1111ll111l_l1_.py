# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠨࡕࡋࡓࡋࡎࡁࠨ堢")
l1lllll_l1_ = l1l111_l1_ (u"ࠩࡢࡗࡍ࡚࡟ࠨ堣")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠪห้฻แฮหࠣห้ืฦ๋ีํอࠬ堤"),l1l111_l1_ (u"ࠫࡘ࡯ࡧ࡯ࠢ࡬ࡲࠬ堥"),l1l111_l1_ (u"ࠬษแๅษ่ࠤ้๊ใษษิࠤๆ่ืࠨ堦")]
def l11l1ll_l1_(mode,url,text):
	if   mode==640: l1lll_l1_ = l1l1l11_l1_()
	elif mode==641: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==642: l1lll_l1_ = PLAY(url)
	elif mode==643: l1lll_l1_ = l1111_l1_(url,text)
	elif mode==644: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==649: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ堧"),l111l1_l1_,l1l111_l1_ (u"ࠧࠨ堨"),l1l111_l1_ (u"ࠨࠩ堩"),l1l111_l1_ (u"ࠩࠪ堪"),l1l111_l1_ (u"ࠪࠫ堫"),l1l111_l1_ (u"ࠫࡘࡎࡏࡇࡊࡄ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭堬"))
	html = response.content
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ堭"),l1lllll_l1_+l1l111_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭堮"),l1l111_l1_ (u"ࠧࠨ堯"),649,l1l111_l1_ (u"ࠨࠩ堰"),l1l111_l1_ (u"ࠩࠪ報"),l1l111_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ堲"))
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ堳"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ場"),l1l111_l1_ (u"࠭ࠧ堵"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࠰ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠱ࡴ࡭ࡶࠢ࠿ࠪ࠱࠮ࡄ࠯ࠢ࡯ࡣࡹࡷࡱ࡯ࡤࡦ࠯ࡧ࡭ࡻ࡯ࡤࡦࡴࠥࠫ堶"),html,re.DOTALL)
	block = l11llll_l1_[0]
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠣࠩࡧࡶࡴࡶࡤࡰࡹࡱ࠱ࡲ࡫࡮ࡶࠩࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃࠨ堷"),html,re.DOTALL)
	for l1l1l1l_l1_ in l11llll_l1_: block = block.replace(l1l1l1l_l1_,l1l111_l1_ (u"ࠩࠪ堸"))
	items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ堹"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if title in l11lll_l1_: continue
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ堺"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ堻")+l1lllll_l1_+title,l1ll1ll_l1_,644)
	return
def l11ll1_l1_(url):
	l11ll111l_l1_ = []
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ堼"),url,l1l111_l1_ (u"ࠧࠨ堽"),l1l111_l1_ (u"ࠨࠩ堾"),l1l111_l1_ (u"ࠩࠪ堿"),l1l111_l1_ (u"ࠪࠫ塀"),l1l111_l1_ (u"ࠫࡘࡎࡏࡇࡊࡄ࠱ࡘ࡛ࡂࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ塁"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡣࡢࡴࡨࡸࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ塂"),html,re.DOTALL)
	if l11ll1l_l1_:
		block = l11ll1l_l1_[0]
		block = block.replace(l1l111_l1_ (u"࠭ࠢࡱࡴࡨࡷࡪࡴࡴࡢࡶ࡬ࡳࡳࠨࠧ塃"),l1l111_l1_ (u"ࠧ࠽࠱ࡸࡰࡃ࠭塄"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡧࡶࡴࡶࡤࡰࡹࡱ࠱࡭࡫ࡡࡥࡧࡵࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡲࡩ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ塅"),block,re.DOTALL)
		if not l11llll_l1_: l11llll_l1_ = [(l1l111_l1_ (u"ࠩࠪ塆"),block)]
		addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ塇"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠโำีࠤศ๎ࠠโๆอีࠥษ่ࠡฬิฮ๏ฮࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ塈"),l1l111_l1_ (u"ࠬ࠭塉"),9999)
		for l11111_l1_,block in l11llll_l1_:
			l11ll111l_l1_ = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ塊"),block,re.DOTALL)
			if l11111_l1_: l11111_l1_ = l11111_l1_+l1l111_l1_ (u"ࠧ࠻ࠢࠪ塋")
			for l1ll1ll_l1_,title in l11ll111l_l1_:
				title = l11111_l1_+title
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ塌"),l1lllll_l1_+title,l1ll1ll_l1_,641)
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡴࡲ࠳ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠮ࡵࡸࡦࡨࡧࡴࡴࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭塍"),html,re.DOTALL)
	if l11ll11_l1_:
		block = l11ll11_l1_[0]
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ塎"),block,re.DOTALL)
		if len(l1l1111_l1_)<30:
			if l11ll111l_l1_: addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ塏"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ塐"),l1l111_l1_ (u"࠭ࠧ塑"),9999)
			for l1ll1ll_l1_,title in l1l1111_l1_:
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ塒"),l1lllll_l1_+title,l1ll1ll_l1_,641)
	if not l11ll1l_l1_ and not l11ll11_l1_: l1lll11_l1_(url)
	return
def l1lll11_l1_(url,request=l1l111_l1_ (u"ࠨࠩ塓")):
	if request==l1l111_l1_ (u"ࠩࡤ࡮ࡦࡾ࠭ࡴࡧࡤࡶࡨ࡮ࠧ塔"):
		url,search = url.split(l1l111_l1_ (u"ࠪࡃࠬ塕"),1)
		data = l1l111_l1_ (u"ࠫࡶࡻࡥࡳࡻࡖࡸࡷ࡯࡮ࡨ࠿ࠪ塖")+search
		headers = {l1l111_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ塗"):l1l111_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࡀࠦࡣࡩࡣࡵࡷࡪࡺ࠽ࡖࡖࡉ࠱࠽࠭塘")}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡑࡑࡖࡘࠬ塙"),url,data,headers,l1l111_l1_ (u"ࠨࠩ塚"),l1l111_l1_ (u"ࠩࠪ塛"),l1l111_l1_ (u"ࠪࡗࡍࡕࡆࡉࡃ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧ塜"))
	else:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ塝"),url,l1l111_l1_ (u"ࠬ࠭塞"),l1l111_l1_ (u"࠭ࠧ塟"),l1l111_l1_ (u"ࠧࠨ塠"),l1l111_l1_ (u"ࠨࠩ塡"),l1l111_l1_ (u"ࠩࡖࡌࡔࡌࡈࡂ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠵ࡲࡩ࠭塢"))
	html = response.content
	block,items = l1l111_l1_ (u"ࠪࠫ塣"),[]
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ塤"))
	if request==l1l111_l1_ (u"ࠬࡧࡪࡢࡺ࠰ࡷࡪࡧࡲࡤࡪࠪ塥"):
		block = html
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ塦"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1l111_l1_ (u"ࠧࠨ塧"),l1ll1ll_l1_,title))
	elif request==l1l111_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪ塨"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡴࡲ࠳ࡶࡪࡦࡨࡳ࠲ࡽࡡࡵࡥ࡫࠱࡫࡫ࡡࡵࡷࡵࡩࡩࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ塩"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	elif request==l1l111_l1_ (u"ࠪࡲࡪࡽ࡟ࡦࡲ࡬ࡷࡴࡪࡥࡴࠩ塪"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡸ࡯ࡸࠢࡳࡱ࠲ࡻ࡬࠮ࡤࡵࡳࡼࡹࡥ࠮ࡸ࡬ࡨࡪࡵࡳࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ填"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	elif request==l1l111_l1_ (u"ࠬࡴࡥࡸࡡࡰࡳࡻ࡯ࡥࡴࠩ塬"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡳࡱࡺࠤࡵࡳ࠭ࡶ࡮࠰ࡦࡷࡵࡷࡴࡧ࠰ࡺ࡮ࡪࡥࡰࡵࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭塭"),html,re.DOTALL)
		if len(l11llll_l1_)>1: block = l11llll_l1_[1]
	elif request==l1l111_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࡡࡶࡩࡷ࡯ࡥࡴࠩ塮"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤ࡫ࡳࡲ࡫࠭ࡴࡧࡵ࡭ࡪࡹ࠭࡭࡫ࡶࡸࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀ࡞ࡠࡹࢂ࡜࡯࡟࠭ࡀ࠴ࡪࡩࡷࡀࠪ塯"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ塰"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1l111_l1_ (u"ࠪࠫ塱"),l1ll1ll_l1_,title))
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࠭ࡪࡡࡵࡣ࠰ࡩࡨ࡮࡯࠾ࠤ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ塲"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	if block and not items: items = re.findall(l1l111_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡩࡨ࡮࡯࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ塳"),block,re.DOTALL)
	if not items: return
	l1l1_l1_ = []
	l1ll11_l1_ = [l1l111_l1_ (u"࠭ๅีษ๊ำฮ࠭塴"),l1l111_l1_ (u"ࠧโ์็้ࠬ塵"),l1l111_l1_ (u"ࠨษ฽๊๏ฯࠧ塶"),l1l111_l1_ (u"ࠩๆ่๏ฮࠧ塷"),l1l111_l1_ (u"ࠪห฾๊ว็ࠩ塸"),l1l111_l1_ (u"ࠫ์ีวโࠩ塹"),l1l111_l1_ (u"๋ࠬศศำสอࠬ塺"),l1l111_l1_ (u"ู࠭าุࠪ塻"),l1l111_l1_ (u"ࠧๆ้ิะฬ์ࠧ塼"),l1l111_l1_ (u"ࠨษ็ฬํ๋ࠧ塽"),l1l111_l1_ (u"่ࠩืึำ๊สࠩ塾")]
	for l1ll1l_l1_,l1ll1ll_l1_,title in items:
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢࠫห้ำไใหࡿั้่ษࠪ࠰࡟ࡨ࠰࠭塿"),title,re.DOTALL)
		if any(value in title for value in l1ll11_l1_):
			addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ墀"),l1lllll_l1_+title,l1ll1ll_l1_,642,l1ll1l_l1_)
		elif request==l1l111_l1_ (u"ࠬࡴࡥࡸࡡࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫ墁"):
			addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ墂"),l1lllll_l1_+title,l1ll1ll_l1_,642,l1ll1l_l1_)
		elif l1l1lll_l1_:
			title = l1l111_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭境") + l1l1lll_l1_[0][0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ墄"),l1lllll_l1_+title,l1ll1ll_l1_,643,l1ll1l_l1_)
				l1l1_l1_.append(title)
		else: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ墅"),l1lllll_l1_+title,l1ll1ll_l1_,643,l1ll1l_l1_)
	if 1:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ墆"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ墇"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				if l1ll1ll_l1_==l1l111_l1_ (u"ࠬࠩࠧ墈"): continue
				if l1l111_l1_ (u"࠭ࡨࡵࡶࡳࠫ墉") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠧ࠰ࠩ墊")+l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠨ࠱ࠪ墋"))
				title = unescapeHTML(title)
				addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ墌"),l1lllll_l1_+l1l111_l1_ (u"ูࠪๆำษࠡࠩ墍")+title,l1ll1ll_l1_,641)
	return
def l1111_l1_(url,l1l11_l1_):
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ墎"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ墏"),url,l1l111_l1_ (u"࠭ࠧ墐"),l1l111_l1_ (u"ࠧࠨ墑"),l1l111_l1_ (u"ࠨࠩ墒"),l1l111_l1_ (u"ࠩࠪ墓"),l1l111_l1_ (u"ࠪࡗࡍࡕࡆࡉࡃ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠸࡮ࡥࠩ墔"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"࡙ࠫࠧࡥࡢࡵࡲࡲࡸࡈ࡯ࡹࠤࠫ࠲࠯ࡅࠩࠣࡕࡨࡥࡸࡵ࡮ࡴࡇࡳ࡭ࡸࡵࡤࡦࡵࡐࡥ࡮ࡴࠧ墕"),html,re.DOTALL)
	l11l_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡳࡦࡴ࡬ࡩࡸ࠳ࡨࡦࡣࡧࡩࡷࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ墖"),html,re.DOTALL)
	if l11l_l1_: l1ll1l_l1_ = l11l_l1_[0]
	else: l1ll1l_l1_ = l1l111_l1_ (u"࠭ࠧ増")
	items = []
	l11l1_l1_ = False
	if l11ll1l_l1_ and not l1l11_l1_:
		block = l11ll1l_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡹࡥࡳ࡫ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡲࡩ࠿ࠩ墘"),block,re.DOTALL)
		for l1l11_l1_,title in items:
			l1l11_l1_ = l1l11_l1_.strip(l1l111_l1_ (u"ࠨࠥࠪ墙"))
			if len(items)>1: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ墚"),l1lllll_l1_+title,url,643,l1ll1l_l1_,l1l111_l1_ (u"ࠪࠫ墛"),l1l11_l1_)
			else: l11l1_l1_ = True
	else: l11l1_l1_ = True
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"࡙ࠫࠧࡥࡢࡵࡲࡲࡸࡋࡰࡪࡵࡲࡨࡪࡹࡍࡢ࡫ࡱ࠲࠯ࡅࡤࡢࡶࡤ࠱ࡸ࡫ࡲࡪࡧࡀࠦࠬ墜")+l1l11_l1_+l1l111_l1_ (u"ࠬࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ墝"),html,re.DOTALL)
	if l11ll11_l1_ and l11l1_l1_:
		block = l11ll11_l1_[0]
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃࡂࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡪࡳ࠾ࠨ增"),block,re.DOTALL)
		items = []
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1ll1ll_l1_,title,l1ll1l_l1_))
		for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
			if l1l111_l1_ (u"ࠧࡩࡶࡷࡴࠬ墟") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠨ࠱ࠪ墠")+l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠩ࠲ࠫ墡"))
			title = title.replace(l1l111_l1_ (u"ࠪࡀ࠴ࡹࡰࡢࡰࡁࡀࡪࡳ࠾ࠨ墢"),l1l111_l1_ (u"ࠫࠥ࠭墣"))
			addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ墤"),l1lllll_l1_+title,l1ll1ll_l1_,642,l1ll1l_l1_)
	return
def PLAY(url):
	l1llll_l1_,l1ll11111_l1_,l1ll11l1_l1_ = [],[],[]
	l1lllll1_l1_ = url.replace(l1l111_l1_ (u"࠭࠯ࡸࡣࡷࡧ࡭࠴ࡰࡩࡲࠪ墥"),l1l111_l1_ (u"ࠧ࠰ࡸ࡬ࡩࡼ࠴ࡰࡩࡲࠪ墦"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ墧"),l1lllll1_l1_,l1l111_l1_ (u"ࠩࠪ墨"),l1l111_l1_ (u"ࠪࠫ墩"),l1l111_l1_ (u"ࠫࠬ墪"),l1l111_l1_ (u"ࠬ࠭墫"),l1l111_l1_ (u"࠭ࡓࡉࡑࡉࡌࡆ࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ墬"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡧࡰࡦࡪࡪࡤࡦࡦ࠰ࡺ࡮ࡪࡥࡰࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ墭"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭墮"),block,re.DOTALL)
		if l1ll_l1_:
			l1ll1ll_l1_ = l1ll_l1_[0]
			if l1ll1ll_l1_ not in l1llll_l1_:
				l1ll11111_l1_.append(l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࡢࡣࡪࡳࡢࡦࡦࠪ墯"))
				l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦ࡜ࡧࡴࡤࡪࡖࡩࡷࡼࡥࡳࡵࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡨࡸࡩࡱࡶࡁࠫ墰"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l11l1l1l1_l1_ = re.findall(l1l111_l1_ (u"ࠫ࡮ࡪ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴ࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡦࡺࡺࡴࡰࡰࡁࠫ墱"),block,re.DOTALL)
		block = block.replace(l1l111_l1_ (u"ࠬࡢ࡜ࠣࠩ墲"),l1l111_l1_ (u"࠭ࠢࠨ墳")).replace(l1l111_l1_ (u"ࠧ࡝࠱ࠪ墴"),l1l111_l1_ (u"ࠨ࠱ࠪ墵"))
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡀ࡮࡬ࡲࡢ࡯ࡨ࠲ࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ墶"),block,re.DOTALL)
		if len(l11l1l1l1_l1_)==len(l1ll_l1_):
			for id,title in l11l1l1l1_l1_:
				l1ll1ll_l1_ = l1ll_l1_[int(id)]
				if l1ll1ll_l1_ not in l1llll_l1_:
					l1ll11111_l1_.append(l1l111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ墷")+title+l1l111_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬ墸"))
					l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡄࡰࡹࡱࡰࡴࡧࡤࡔࡧࡵࡺࡪࡸࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ墹"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1ll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽࠱࡬ࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ墺"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1ll_l1_:
			if l1ll1ll_l1_ not in l1llll_l1_:
				l1ll11111_l1_.append(l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ墻")+title+l1l111_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ墼"))
				l1llll_l1_.append(l1ll1ll_l1_)
	l1lll1l_l1_ = zip(l1llll_l1_,l1ll11111_l1_)
	for l1ll1ll_l1_,name in l1lll1l_l1_: l1ll11l1_l1_.append(l1ll1ll_l1_+name)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll11l1_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ墽"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠪࠫ墾"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠫࠬ墿"): return
	search = search.replace(l1l111_l1_ (u"ࠬࠦࠧ壀"),l1l111_l1_ (u"࠭ࠫࠨ壁"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠯ࡲ࡫ࡴࡄࡱࡥࡺࡹࡲࡶࡩࡹ࠽ࠨ壂")+search
	l1lll11_l1_(url,l1l111_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࠨ壃"))
	return
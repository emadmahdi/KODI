# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚ࡖࡊࡒࠪ⎄")
l1lllll_l1_ = l1l111_l1_ (u"ࠧࡠࡇࡊ࡚ࡤ࠭⎅")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
def l11l1ll_l1_(mode,url,l1llllll1_l1_,text):
	if   mode==220: l1lll_l1_ = l1l1l11_l1_()
	elif mode==221: l1lll_l1_ = l1lll11_l1_(url,l1llllll1_l1_)
	elif mode==222: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==223: l1lll_l1_ = PLAY(url)
	elif mode==224: l1lll_l1_ = l1l1ll1l_l1_(url)
	elif mode==229: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⎆"),l1lllll_l1_+l1l111_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ⎇"),l1l111_l1_ (u"ࠪࠫ⎈"),229,l1l111_l1_ (u"ࠫࠬ⎉"),l1l111_l1_ (u"ࠬ࠭⎊"),l1l111_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ⎋"))
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ⎌"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ⎍"),l1l111_l1_ (u"ࠩࠪ⎎"),9999)
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ⎏"),l111l1_l1_,l1l111_l1_ (u"ࠫࠬ⎐"),l1l111_l1_ (u"ࠬ࠭⎑"),l1l111_l1_ (u"࠭ࠧ⎒"),l1l111_l1_ (u"ࠧࠨ⎓"),l1l111_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ⎔"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤ࡬ࠤ࡮࠳ࡨࡰ࡯ࡨࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ⎕"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ⎖"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if l1l111_l1_ (u"ࠫࡁ࠵ࡩ࠿ࠩ⎗") in title: title = title.split(l1l111_l1_ (u"ࠬࡂ࠯ࡪࡀࠪ⎘"))[1]
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⎙"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ⎚")+l1lllll_l1_+title,l1ll1ll_l1_,222)
		addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭⎛"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ⎜"),l1l111_l1_ (u"ࠪࠫ⎝"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡧࡧࠨ࠯ࠬࡂ࠭ࡁࡹࡣࡳ࡫ࡳࡸࠬ⎞"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬࡶࡤࡢࠢࡥࡨࡧࠨ࠾࠽ࡵࡷࡶࡴࡴࡧ࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ⎟"),html,re.DOTALL)
		for title,l1ll1ll_l1_ in items:
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⎠"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ⎡")+l1lllll_l1_+title,l1ll1ll_l1_,221)
		addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭⎢"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ⎣"),l1l111_l1_ (u"ࠪࠫ⎤"),9999)
		items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭⎥"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if l1l111_l1_ (u"ࠬ࡮ࡴ࡮࡮ࠪ⎦") not in l1ll1ll_l1_: continue
			if not l1ll1ll_l1_.endswith(l1l111_l1_ (u"࠭࠯ࠨ⎧")): addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⎨"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ⎩")+l1lllll_l1_+title,l1ll1ll_l1_,221)
	return html
def l11ll1_l1_(url):
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭⎪"),url,l1l111_l1_ (u"ࠪࠫ⎫"),l1l111_l1_ (u"ࠫࠬ⎬"),l1l111_l1_ (u"ࠬ࠭⎭"),l1l111_l1_ (u"࠭ࠧ⎮"),l1l111_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔࡗࡋࡓ࠱ࡘ࡛ࡂࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ⎯"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡴࡶࡣࡸࡩࡲࡰ࡮࡯ࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ⎰"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ⎱"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⎲"),l1lllll_l1_+title,l1ll1ll_l1_,224)
	return
def l1l1ll1l_l1_(url):
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⎳"),l1lllll_l1_+l1l111_l1_ (u"ࠬอไอ็ํ฽ࠬ⎴"),url,221)
	html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"࠭ࠧ⎵"),l1l111_l1_ (u"ࠧࠨ⎶"),l1l111_l1_ (u"ࠨࠩ⎷"),l1l111_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࡙ࡍࡕ࠳ࡆࡊࡎࡗࡉࡗ࡙࡟ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ⎸"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡷࡺࡨ࡟࡯ࡣࡹࠬ࠳࠰࠿ࠪ࡫ࡧࡁࠧࡳ࡯ࡷ࡫ࡨࡷࠬ⎹"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠯ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭⎺"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if l1ll1ll_l1_==l1l111_l1_ (u"ࠬࠩࠧ⎻"): name = title
			else:
				title = title + l1l111_l1_ (u"࠭ࠠࠡ࠼ࠣࠤࠬ⎼") + l1l111_l1_ (u"ࠧโๆอีࠥ࠭⎽") + name
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⎾"),l1lllll_l1_+title,l1ll1ll_l1_,221)
	else: l1lll11_l1_(url)
	return
def l1lll11_l1_(url,l1llllll1_l1_=l1l111_l1_ (u"ࠩ࠴ࠫ⎿")):
	if l1llllll1_l1_==l1l111_l1_ (u"ࠪࠫ⏀"): l1llllll1_l1_ = l1l111_l1_ (u"ࠫ࠶࠭⏁")
	if l1l111_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠭⏂") in url or l1l111_l1_ (u"࠭࠿ࠨ⏃") in url: l1lllll1_l1_ = url + l1l111_l1_ (u"ࠧࠧࠩ⏄")
	else: l1lllll1_l1_ = url + l1l111_l1_ (u"ࠨࡁࠪ⏅")
	l1lllll1_l1_ = l1lllll1_l1_ + l1l111_l1_ (u"ࠩࡳࡥ࡬࡫࠽ࠨ⏆") + l1llllll1_l1_
	html = l1l1llll_l1_(l11l1l1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠪࠫ⏇"),l1l111_l1_ (u"ࠫࠬ⏈"),l1l111_l1_ (u"ࠬ࠭⏉"),l1l111_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚ࡖࡊࡒ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧ⏊"))
	if l1l111_l1_ (u"ࠧ࠰ࡵࡨࡥࡸࡵ࡮ࠨ⏋") in url:
		l11llll_l1_=re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡲࡧࡥࠧ࠮࠮ࠫࡁࠬࡨ࡮ࡼࠧ⏌"),html,re.DOTALL)
		block = l11llll_l1_[-1]
	elif l1l111_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠲ࠫ⏍") in url:
		l11llll_l1_=re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡳࡼࡲ࠭ࡤࡣࡵࡳࡺࡹࡥ࡭ࠢࡲࡻࡱ࠳ࡣࡢࡴࡲࡹࡸ࡫࡬ࠩ࠰࠭ࡃ࠮ࡪࡩࡷࠩ⏎"),html,re.DOTALL)
		block = l11llll_l1_[0]
	else:
		l11llll_l1_=re.findall(l1l111_l1_ (u"ࠫ࡮ࡪ࠽ࠣ࡯ࡲࡺ࡮࡫ࡳࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ⏏"),html,re.DOTALL)
		block = l11llll_l1_[-1]
	items = re.findall(l1l111_l1_ (u"ࠬࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡷ࡭ࡹࡲࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ⏐"),block,re.DOTALL)
	for l1ll1ll_l1_,l1ll1l_l1_,title in items:
		title = unescapeHTML(title)
		if l1l111_l1_ (u"࠭࠯࡮ࡱࡹ࡭ࡪ࠵ࠧ⏑") in l1ll1ll_l1_ or l1l111_l1_ (u"ࠧ࠰ࡧࡳ࡭ࡸࡵࡤࡦࠩ⏒") in l1ll1ll_l1_:
			addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ⏓"),l1lllll_l1_+title,l1ll1ll_l1_.rstrip(l1l111_l1_ (u"ࠩ࠲ࠫ⏔")),223,l1ll1l_l1_)
		else:
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⏕"),l1lllll_l1_+title,l1ll1ll_l1_,221,l1ll1l_l1_)
	if len(items)>=16:
		l11l1l111l_l1_ = [l1l111_l1_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨࡷࠬ⏖"),l1l111_l1_ (u"ࠬ࠵ࡴࡷࠩ⏗"),l1l111_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮ࠧ⏘"),l1l111_l1_ (u"ࠧ࠰ࡶࡵࡩࡳࡪࡩ࡯ࡩࠪ⏙")]
		l1llllll1_l1_ = int(l1llllll1_l1_)
		if any(value in url for value in l11l1l111l_l1_):
			for n in range(0,1000,100):
				if int(l1llllll1_l1_/100)*100==n:
					for i in range(n,n+100,10):
						if int(l1llllll1_l1_/10)*10==i:
							for j in range(i,i+10,1):
								if not l1llllll1_l1_==j and j!=0:
									addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⏚"),l1lllll_l1_+l1l111_l1_ (u"ุࠩๅาฯࠠࠨ⏛")+str(j),url,221,l1l111_l1_ (u"ࠪࠫ⏜"),str(j))
						elif i!=0: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⏝"),l1lllll_l1_+l1l111_l1_ (u"ࠬ฻แฮหࠣࠫ⏞")+str(i),url,221,l1l111_l1_ (u"࠭ࠧ⏟"),str(i))
						else: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⏠"),l1lllll_l1_+l1l111_l1_ (u"ࠨืไัฮࠦࠧ⏡")+str(1),url,221,l1l111_l1_ (u"ࠩࠪ⏢"),str(1))
				elif n!=0: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⏣"),l1lllll_l1_+l1l111_l1_ (u"ฺࠫ็อสࠢࠪ⏤")+str(n),url,221,l1l111_l1_ (u"ࠬ࠭⏥"),str(n))
				else: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⏦"),l1lllll_l1_+l1l111_l1_ (u"ࠧึใะอࠥ࠭⏧")+str(1),url,221)
	return
def PLAY(url):
	l1l1lll1_l1_,l1llll_l1_ = [],[]
	html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"ࠨࠩ⏨"),l1l111_l1_ (u"ࠩࠪ⏩"),l1l111_l1_ (u"ࠪࠫ⏪"),l1l111_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࡛ࡏࡐ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ⏫"))
	l1111ll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡂࡴࡥࡀส่ฯ฻ๆ๋ใ࠿࠳ࡹࡪ࠾࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ⏬"),html,re.DOTALL)
	if l1111ll_l1_ and l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_): return
	l1l111ll1_l1_,l1l1l11ll_l1_ = l1l111_l1_ (u"࠭ࠧ⏭"),l1l111_l1_ (u"ࠧࠨ⏮")
	l111l11l1l_l1_,l111l1111l_l1_ = html,html
	l111l11l11_l1_ = re.findall(l1l111_l1_ (u"ࠨࡵ࡫ࡳࡼࡥࡤ࡭ࠢࡤࡴ࡮ࠨࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭⏯"),html,re.DOTALL)
	if l111l11l11_l1_:
		for l1ll1ll_l1_ in l111l11l11_l1_:
			if l1l111_l1_ (u"ࠩ࠲ࡻࡦࡺࡣࡩ࠱ࠪ⏰") in l1ll1ll_l1_: l1l111ll1_l1_ = l1ll1ll_l1_
			elif l1l111_l1_ (u"ࠪ࠳ࡩࡵࡷ࡯࡮ࡲࡥࡩ࠵ࠧ⏱") in l1ll1ll_l1_: l1l1l11ll_l1_ = l1ll1ll_l1_
		if l1l111ll1_l1_!=l1l111_l1_ (u"ࠫࠬ⏲"): l111l11l1l_l1_ = l1l1llll_l1_(l1ll1ll1_l1_,l1l111ll1_l1_,l1l111_l1_ (u"ࠬ࠭⏳"),l1l111_l1_ (u"࠭ࠧ⏴"),l1l111_l1_ (u"ࠧࠨ⏵"),l1l111_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕࡘࡌࡔ࠲ࡖࡌࡂ࡛࠰࠶ࡳࡪࠧ⏶"))
		if l1l1l11ll_l1_!=l1l111_l1_ (u"ࠩࠪ⏷"): l111l1111l_l1_ = l1l1llll_l1_(l1ll1ll1_l1_,l1l1l11ll_l1_,l1l111_l1_ (u"ࠪࠫ⏸"),l1l111_l1_ (u"ࠫࠬ⏹"),l1l111_l1_ (u"ࠬ࠭⏺"),l1l111_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚ࡖࡊࡒ࠰ࡔࡑࡇ࡙࠮࠵ࡵࡨࠬ⏻"))
	l111l11ll1_l1_ = re.findall(l1l111_l1_ (u"ࠧࡪࡦࡀࠦࡻ࡯ࡤࡦࡱࠥ࠲࠯ࡅࡤࡢࡶࡤ࠱ࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ⏼"),l111l11l1l_l1_,re.DOTALL)
	if l111l11ll1_l1_:
		l1lllll1_l1_ = l111l11ll1_l1_[0]
		if l1lllll1_l1_!=l1l111_l1_ (u"ࠨࠩ⏽") and l1l111_l1_ (u"ࠩࡸࡴࡱࡵࡡࡥࡧࡧ࠲ࡪ࡭ࡹࡣࡧࡶࡸ࠳ࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ⏾") in l1lllll1_l1_ and l1l111_l1_ (u"ࠪ࠳ࡄ࡯ࡤ࠾ࡡࠪ⏿") not in l1lllll1_l1_:
			l11l1ll1_l1_ = l1l1llll_l1_(l1ll1ll1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠫࠬ␀"),l1l111_l1_ (u"ࠬ࠭␁"),l1l111_l1_ (u"࠭ࠧ␂"),l1l111_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔࡗࡋࡓ࠱ࡕࡒࡁ࡚࠯࠷ࡸ࡭࠭␃"))
			l111l111l1_l1_ = re.findall(l1l111_l1_ (u"ࠨࡵࡲࡹࡷࡩࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭␄"),l11l1ll1_l1_,re.DOTALL)
			if l111l111l1_l1_:
				for l1ll1ll_l1_,l111l1ll_l1_ in l111l111l1_l1_:
					l1llll_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࡨࡨ࠳࡫ࡧࡺࡤࡨࡷࡹ࠴ࡤࡰࡡࡢࡻࡦࡺࡣࡩࡡࡢࡱࡵ࠺࡟ࡠࠩ␅")+l111l1ll_l1_)
			else:
				server = l1lllll1_l1_.split(l1l111_l1_ (u"ࠪ࠳ࠬ␆"))[2]
				l1llll_l1_.append(l1lllll1_l1_+l1l111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ␇")+server+l1l111_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭␈"))
		elif l1lllll1_l1_!=l1l111_l1_ (u"࠭ࠧ␉"):
			server = l1lllll1_l1_.split(l1l111_l1_ (u"ࠧ࠰ࠩ␊"))[2]
			l1llll_l1_.append(l1lllll1_l1_+l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ␋")+server+l1l111_l1_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪ␌"))
	l111l1l11l_l1_ = re.findall(l1l111_l1_ (u"ࠪࡀࡹࡧࡢ࡭ࡧࠣࡧࡱࡧࡳࡴ࠿ࠥࡨࡱࡹ࡟ࡵࡣࡥࡰࡪ࠮࠮ࠫࡁࠬࡀ࠴ࡺࡡࡣ࡮ࡨࡂࠬ␍"),l111l1111l_l1_,re.DOTALL)
	if l111l1l11l_l1_:
		l111l1l11l_l1_ = l111l1l11l_l1_[0]
		l111l111ll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡁࡺࡤ࠿࠰࠭ࡃࡁࡺࡤ࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ␎"),l111l1l11l_l1_,re.DOTALL)
		if l111l111ll_l1_:
			for l111l1ll_l1_,l1ll1ll_l1_ in l111l111ll_l1_:
				if l1l111_l1_ (u"ࠬࡳࡹࡦࡩࡼࡺ࡮ࡶࠧ␏") not in l1ll1ll_l1_: continue
				if l1ll1ll_l1_.count(l1l111_l1_ (u"࠭࠯ࠨ␐"))>=2:
					server = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠧ࠰ࠩ␑"))[2]
					l1llll_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ␒")+server+l1l111_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩࡥ࡟࡮ࡲ࠷ࡣࡤ࠭␓")+l111l1ll_l1_)
	l111l1l111_l1_ = []
	for l1ll1ll_l1_ in l1llll_l1_:
		l111l1l111_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l111l1l111_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ␔"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠫࠬ␕"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠬ࠭␖"): return
	l1lll1ll_l1_ = search.replace(l1l111_l1_ (u"࠭ࠠࠨ␗"),l1l111_l1_ (u"ࠧࠬࠩ␘"))
	html = l1l1llll_l1_(l111l11l_l1_,l111l1_l1_,l1l111_l1_ (u"ࠨࠩ␙"),l1l111_l1_ (u"ࠩࠪ␚"),l1l111_l1_ (u"ࠪࠫ␛"),l1l111_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࡛ࡏࡐ࠮ࡕࡈࡅࡗࡉࡈ࠮࠳ࡶࡸࠬ␜"))
	token = re.findall(l1l111_l1_ (u"ࠬࡴࡡ࡮ࡧࡀࠦࡤࡺ࡯࡬ࡧࡱࠦࠥࡼࡡ࡭ࡷࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ␝"),html,re.DOTALL)
	if token:
		url = l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠿ࡠࡶࡲ࡯ࡪࡴ࠽ࠨ␞")+token[0]+l1l111_l1_ (u"ࠧࠧࡳࡀࠫ␟")+l1lll1ll_l1_
		l1lll11_l1_(url)
	return
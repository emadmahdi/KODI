# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"࠭ࡄࡐ࡙ࡑࡐࡔࡇࡄࠨ᳘")
def l11l1ll_l1_(mode,url):
	if   mode==330: l1lll_l1_ = l1l11l111l_l1_()
	elif mode==331: l1lll_l1_ = PLAY(url)
	elif mode==332: l1lll_l1_ = l11llll1ll_l1_()
	elif mode==333: l1lll_l1_ = l11ll1l11l_l1_()
	elif mode==334: l1lll_l1_ = l1lll1ll1l_l1_(url)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1lll1ll1l_l1_(l1l11111l1_l1_):
	try: os.remove(l1l11111l1_l1_.decode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼᳙ࠬ")))
	except: os.remove(l1l11111l1_l1_)
	return
def PLAY(url):
	l1llll111_l1_(url,l1ll1_l1_,l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ᳚"))
	return
def l11ll1l11l_l1_():
	message = l1l111_l1_ (u"ࠩฦิ์ฮࠠฦๆ์ࠤึอศุࠢส่ๆ๐ฯ๋๊ࠣวํࠦวๅื๋ฮࠥ็๊ࠡษ็้ํู่ࠡษ็้฼๊่ษࠢฮ้ࠥษึ฻ูࠣ฽้๏ࠠำำࠣห้่วว็ฬࠤฬ๊๊ๆ์้ࠤะ๋ࠠฤะอหึࠦࠢหฯ่๎้ࠦๅๅใสฮࠥ็๊ะ์๋ࠦࠥัๅࠡษัฮฬืࠠะไฬࠤฬ๊ี้ำฬࠤํอฮหษิࠤ๋๎ูࠡ็็ๅࠥอไึ๊ิอࠥ๎ศฺั๊หู่ࠥโࠢํฬิษࠠศๆอั๊๐ไࠨ᳛")
	l1111l1_l1_(l1l111_l1_ (u"᳜ࠪࠫ"),l1l111_l1_ (u"᳝ࠫࠬ"),l1l111_l1_ (u"ࠬ฽ั๋ไฬࠤฯำๅ๋ๆࠣห้๋ไโษอ᳞ࠫ"),message)
	return
def l1l11l111l_l1_():
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮᳟ࠫ"),l1l111_l1_ (u"ุࠧำํๆฮࠦสฮ็ํ่๋ࠥไโษอࠤฬ๊แ๋ัํ์ࠬ᳠"),l1l111_l1_ (u"ࠨࠩ᳡"),333)
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱ᳢ࠧ"),l1l111_l1_ (u"ࠪฮ฿๐๊า่ࠢ็ฬ์ࠠหฯ่๎้ࠦวๅใํำ๏๎็ศฬ᳣ࠪ"),l1l111_l1_ (u"᳤ࠫࠬ"),332)
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭᳥ࠪ"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ᳦࠭"),l1l111_l1_ (u"ࠧࠨ᳧"),9999)
	l1l1111lll_l1_ = l11lll1lll_l1_()
	mtime = os.stat(l1l1111lll_l1_).st_mtime
	l11lllll1l_l1_ = []
	if PY3: l1l1111ll1_l1_ = os.listdir(l1l1111lll_l1_.encode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽᳨࠭")))
	else: l1l1111ll1_l1_ = os.listdir(l1l1111lll_l1_.decode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧᳩ")))
	for filename in l1l1111ll1_l1_:
		if PY3: filename = filename.decode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨᳪ"))
		if not filename.startswith(l1l111_l1_ (u"ࠫ࡫࡯࡬ࡦࡡࠪᳫ")): continue
		filepath = os.path.join(l1l1111lll_l1_,filename)
		mtime = os.path.getmtime(filepath)
		l11lllll1l_l1_.append([filename,mtime])
	l11lllll1l_l1_ = sorted(l11lllll1l_l1_,reverse=True,key=lambda key: key[1])
	for filename,mtime in l11lllll1l_l1_:
		if PY2:
			try: filename = filename.decode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪᳬ"))
			except: pass
			filename = filename.encode(l1l111_l1_ (u"࠭ࡵࡵࡨ࠻᳭ࠫ"))
		filepath = os.path.join(l1l1111lll_l1_,filename)
		addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ᳮ"),filename,filepath,331)
	return
def l11lll1lll_l1_():
	l1l1111lll_l1_ = settings.getSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡩࡵࡷ࡯࡮ࡲࡥࡩ࠴ࡰࡢࡶ࡫ࠫᳯ"))
	if l1l1111lll_l1_: return l1l1111lll_l1_
	settings.setSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠮ࡱࡣࡷ࡬ࠬᳰ"),addoncachefolder)
	return addoncachefolder
def l11llll1ll_l1_():
	l1l1111lll_l1_ = l11lll1lll_l1_()
	l11lll1111_l1_ = l1ll11ll1l_l1_(l1l111_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪᳱ"),l1l111_l1_ (u"ࠫࠬᳲ"),l1l111_l1_ (u"ࠬ࠭ᳳ"),l1l111_l1_ (u"࠭ๅไษ้ࠤฯิา๋่้้ࠣ็วหࠢส่ฯำๅ๋ๆࠪ᳴"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪᳵ")+l1l1111lll_l1_+l1l111_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟࡟ࡲࡡࡴ็ัษ๋ࠣํࠦๅไษ้ࠤฯิา๋่้้ࠣ็วหࠢส่ๆ๐ฯ๋๊ࠣห้ะ๊ࠡฬะ้้ํวࠡษ้ฮࠥฮวิฬัำฬ๋่ࠠาสࠤฬ๊ศา่ส้ัࠦ࠮้ࠡ็ࠤฯื๊ะࠢอ฾๏๐ัࠡษ็้่อๆࠡมࠪᳶ"))
	if l11lll1111_l1_==1:
		newpath = l11lllllll_l1_(3,l1l111_l1_ (u"่ࠩ็ฬ์ࠠหฯ่๎้ࠦๅๅใสฮࠥอไโ์า๎ํ࠭᳷"),l1l111_l1_ (u"ࠪࡰࡴࡩࡡ࡭ࠩ᳸"),l1l111_l1_ (u"ࠫࠬ᳹"),False,True,l1l1111lll_l1_)
		l1llll111l_l1_ = l1ll11ll1l_l1_(l1l111_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬᳺ"),l1l111_l1_ (u"࠭ࠧ᳻"),l1l111_l1_ (u"ࠧࠨ᳼"),l1l111_l1_ (u"ࠨ็ๆห๋ࠦสฯิํ๊๋ࠥไโษอࠤฬ๊สฮ็ํ่ࠬ᳽"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ᳾")+l1l1111lll_l1_+l1l111_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࡡࡴ࡜࡯้ำหࠥํ่ࠡษ็้่อๆࠡษ็ะิ๐ฯࠡๆอาื๐ๆࠡ็็ๅฬะࠠศๆไ๎ิ๐่ࠡษ็ฮ๏ࠦสฮ็็๋ฬࠦว็ฬࠣฬฬูสฯัส้ࠥํะศࠢส่อืๆศ็ฯࠤ࠳ࠦ็ๅࠢอี๏ีࠠศีอาิอๅ่ࠢหำ้อࠠๆ่ࠣห้๋ใศ่ࠣห้่ฯ๋็ࠣรࠬ᳿"))
		if l1llll111l_l1_==1:
			settings.setSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡥࡱࡺࡲࡱࡵࡡࡥ࠰ࡳࡥࡹ࡮ࠧᴀ"),newpath)
			l1111l1_l1_(l1l111_l1_ (u"ࠬ࠭ᴁ"),l1l111_l1_ (u"࠭ࠧᴂ"),l1l111_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᴃ"),l1l111_l1_ (u"ࠨฬ่ࠤฯเ๊๋ำ้่ࠣอๆࠡฬัึ๏์ࠠศๆ่่ๆอสࠡษ็้า๋ไสࠩᴄ"))
	return
def l11lllll11_l1_(filename):
	l1l11l1111_l1_ = l1l111_l1_ (u"ࠩࠪᴅ").join(l1l111lll1_l1_ for l1l111lll1_l1_ in filename if l1l111lll1_l1_ not in l1l111_l1_ (u"ࠪࡠ࠴ࠨ࠺ࠫࡁ࠿ࡂࢁ࠭ᴆ")+half_triangular_colon)
	return l1l11l1111_l1_
def l11ll1lll1_l1_(url,l11ll11ll1_l1_=l1l111_l1_ (u"ࠫࠬᴇ"),l1l11l11_l1_=l1l111_l1_ (u"ࠬ࠭ᴈ")):
	l11llllll1_l1_(l1l111_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭ᴉ"),l11llll11l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠧࠡࠢࠣࡔࡷ࡫ࡰࡢࡴ࡬ࡲ࡬ࠦࡴࡰࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧᴊ")+url+l1l111_l1_ (u"ࠨࠢࡠࠫᴋ"))
	if not l11ll11ll1_l1_: l11ll11ll1_l1_ = l1l111l1l1_l1_(url,l1l11l11_l1_)
	l1l1111lll_l1_ = l11lll1lll_l1_()
	l1l111l1ll_l1_ = l1l1111l11_l1_()
	filename = l1l111l1ll_l1_.replace(l1l111_l1_ (u"ࠩࠣࠫᴌ"),l1l111_l1_ (u"ࠪࡣࠬᴍ"))
	filename = l11lllll11_l1_(filename)
	filename = l1l111_l1_ (u"ࠫ࡫࡯࡬ࡦࡡࠪᴎ")+str(int(now))[-4:]+l1l111_l1_ (u"ࠬࡥࠧᴏ")+filename+l11ll11ll1_l1_
	l11ll1l1l1_l1_ = os.path.join(l1l1111lll_l1_,filename)
	headers = {}
	headers[l1l111_l1_ (u"࠭ࡁࡤࡥࡨࡴࡹ࠳ࡅ࡯ࡥࡲࡨ࡮ࡴࡧࠨᴐ")] = l1l111_l1_ (u"ࠧࠨᴑ")
	headers[l1l111_l1_ (u"ࠨࡃࡦࡧࡪࡶࡴࠨᴒ")] = l1l111_l1_ (u"ࠩ࠭࠳࠯࠭ᴓ")
	url = url.replace(l1l111_l1_ (u"ࠪࡺࡪࡸࡩࡧࡻࡳࡩࡪࡸ࠽ࡧࡣ࡯ࡷࡪ࠭ᴔ"),l1l111_l1_ (u"ࠫࠬᴕ"))
	if l1l111_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ࠿ࠪᴖ") in url:
		l1lllll1_l1_,l11ll11lll_l1_ = url.rsplit(l1l111_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࡀࠫᴗ"),1)
		l11ll11lll_l1_ = l11ll11lll_l1_.replace(l1l111_l1_ (u"ࠧࡽࠩᴘ"),l1l111_l1_ (u"ࠨࠩᴙ")).replace(l1l111_l1_ (u"ࠩࠩࠫᴚ"),l1l111_l1_ (u"ࠪࠫᴛ"))
	else: l1lllll1_l1_,l11ll11lll_l1_ = url,None
	if not l11ll11lll_l1_: l11ll11lll_l1_ = l1l1ll11l_l1_()
	if l11ll11lll_l1_: headers[l1l111_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨᴜ")] = l11ll11lll_l1_
	if l1l111_l1_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷࡃࠧᴝ") in l1lllll1_l1_: l1lllll1_l1_,l11lll11ll_l1_ = l1lllll1_l1_.rsplit(l1l111_l1_ (u"࠭ࡒࡦࡨࡨࡶࡪࡸ࠽ࠨᴞ"),1)
	else: l1lllll1_l1_,l11lll11ll_l1_ = l1lllll1_l1_,l1l111_l1_ (u"ࠧࠨᴟ")
	l1lllll1_l1_ = l1lllll1_l1_.strip(l1l111_l1_ (u"ࠨࡾࠪᴠ")).strip(l1l111_l1_ (u"ࠩࠩࠫᴡ")).strip(l1l111_l1_ (u"ࠪࢀࠬᴢ")).strip(l1l111_l1_ (u"ࠫࠫ࠭ᴣ"))
	l11lll11ll_l1_ = l11lll11ll_l1_.replace(l1l111_l1_ (u"ࠬࢂࠧᴤ"),l1l111_l1_ (u"࠭ࠧᴥ")).replace(l1l111_l1_ (u"ࠧࠧࠩᴦ"),l1l111_l1_ (u"ࠨࠩᴧ"))
	if l11lll11ll_l1_:	headers[l1l111_l1_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪᴨ")] = l11lll11ll_l1_
	l11llllll1_l1_(l1l111_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪᴩ"),l11llll11l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠫࠥࠦࠠࡅࡱࡺࡲࡱࡵࡡࡥ࡫ࡱ࡫ࠥࡼࡩࡥࡧࡲࠤ࡫࡯࡬ࡦࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬᴪ")+l1lllll1_l1_+l1l111_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡌࡪࡧࡤࡦࡴࡶ࠾ࠥࡡࠠࠨᴫ")+str(headers)+l1l111_l1_ (u"࠭ࠠ࡞ࠢࠣࠤࡋ࡯࡬ࡦ࠼ࠣ࡟ࠥ࠭ᴬ")+l11ll1l1l1_l1_+l1l111_l1_ (u"ࠧࠡ࡟ࠪᴭ"))
	l1l11l11l1_l1_ = 1024*1024
	l1l111l11l_l1_ = 0
	try:
		l1l111l111_l1_ =	xbmc.getInfoLabel(l1l111_l1_ (u"ࠨࡕࡼࡷࡹ࡫࡭࠯ࡈࡵࡩࡪ࡙ࡰࡢࡥࡨࠫᴮ"))
		l1l111l111_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡟ࡨ࠰࠭ᴯ"),l1l111l111_l1_)
		l1l111l11l_l1_ = int(l1l111l111_l1_[0])
	except: pass
	if not l1l111l11l_l1_:
		try:
			l1l11111ll_l1_ = os.l11ll11l1l_l1_(l1l1111lll_l1_)
			l1l111l11l_l1_ = l1l11111ll_l1_.f_frsize*l1l11111ll_l1_.f_bavail//l1l11l11l1_l1_
		except: pass
	if not l1l111l11l_l1_:
		try:
			l1l11111ll_l1_ = os.l1l111llll_l1_(l1l1111lll_l1_)
			l1l111l11l_l1_ = l1l11111ll_l1_.f_frsize*l1l11111ll_l1_.f_bavail//l1l11l11l1_l1_
		except: pass
	if not l1l111l11l_l1_:
		try:
			import shutil
			total,l11llll1l1_l1_,l11lll1ll1_l1_ = shutil.l1l11l1l11_l1_(l1l1111lll_l1_)
			l1l111l11l_l1_ = l11lll1ll1_l1_//l1l11l11l1_l1_
		except: pass
	if not l1l111l11l_l1_:
		l1l11l1l1l_l1_(l1l111_l1_ (u"ࠪࡶ࡮࡭ࡨࡵࠩᴰ"),l1l111_l1_ (u"ู๊ࠫวฮหࠣห้ะฮำ์้ࠤ๊า็้ๆฬࠫᴱ"),l1l111_l1_ (u"๊ࠬไฤีไࠤฬ๊ศา่ส้ัฺ๋ࠦำࠣๆฬีัࠡล้ࠤ๏ำฯะ่ࠢๆิอัࠡ็ึหาฯࠠศๆอาื๐ๆࠡษ็ๅฬืฺสࠢไ๎ࠥา็ศิๆࠤํ฿ไ๋้ࠣๅฬ์ࠠหฯ่๎้ࠦวๅใํำ๏๎็ศฬฺ่๋๊ࠣࠦ็็ࠤ฾์ฯไࠢศ่๎ࠦร็ࠢํๆํ๋ࠠๆสิ้ั๐ࠠษำ้ห๊าࠠไ๊า๎ࠥฮอๅ๊ࠢิ์ࠦวๅ็ื็้ฯࠠๅษ้ࠤฯำๅ๋ๆࠣห้็๊ะ์๋๋ฬะࠠใัࠣ๎ุฮศࠡษ่ฮ้อมࠡฮ๊หื้ࠠษษ็้้็วห๋๋ࠢีอࠠโ์๊ࠤำ฽่าหࠣ฽้๏ฺࠠ็็ࠤัํวำๅࠣฬฺ๎ัสุࠢั๏ำษ๊ࠡ็๋ีอࠠศๆึฬอࠦโศ็ࠣห้๋ศา็ฯࠤ๊สโหษࠣฬ๊์ูࠡษ็ฬึ์วๆฮ้๋ࠣࠦสฮ็ํ่ࠥอไโ์า๎ํํวหࠩᴲ"),l1l111_l1_ (u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩᴳ"))
		l11llllll1_l1_(l1l111_l1_ (u"ࠧࡆࡔࡕࡓࡗࡥࡌࡊࡐࡈࡗࠬᴴ"),l11llll11l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠨࠢࠣࠤ࡚ࡴࡡࡣ࡮ࡨࠤࡹࡵࠠࡥࡧࡷࡩࡷࡳࡩ࡯ࡧࠣࡸ࡭࡫ࠠࡥ࡫ࡶ࡯ࠥ࡬ࡲࡦࡧࠣࡷࡵࡧࡣࡦࠩᴵ"))
		return False
	import requests
	if l11ll11ll1_l1_==l1l111_l1_ (u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨᴶ"):
		l1l1lll1_l1_,l1llll_l1_ = l1l11l11ll_l1_(l1lllll1_l1_,headers)
		if len(l1l1lll1_l1_)==0:
			l1ll1lll_l1_(l1l111_l1_ (u"ࠪๅู๊ࠠโ์ࠣษ๏าวะ่่ࠢๆࠦวๅฬะ้๏๊ࠧᴷ"),l1l111_l1_ (u"ࠫࠬᴸ"))
			return False
		elif len(l1l1lll1_l1_)==1: l11l11l_l1_ = 0
		elif len(l1l1lll1_l1_)>1:
			l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠬอฮหำࠣห้๋ไโࠢส่๊์วิสࠪᴹ"), l1l1lll1_l1_)
			if l11l11l_l1_ == -1 :
				l1ll1lll_l1_(l1l111_l1_ (u"࠭สๆࠢศ่฿อมࠡษ็ฮา๋๊ๅࠩᴺ"),l1l111_l1_ (u"ࠧࠨᴻ"))
				return False
		l1lllll1_l1_ = l1llll_l1_[l11l11l_l1_]
	filesize = 0
	if l11ll11ll1_l1_==l1l111_l1_ (u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧᴼ"):
		l11ll1l1l1_l1_ = l11ll1l1l1_l1_.rsplit(l1l111_l1_ (u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨᴽ"))[0]+l1l111_l1_ (u"ࠪ࠲ࡲࡶ࠴ࠨᴾ")
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨᴿ"),l1lllll1_l1_,l1l111_l1_ (u"ࠬ࠭ᵀ"),headers,l1l111_l1_ (u"࠭ࠧᵁ"),l1l111_l1_ (u"ࠧࠨᵂ"),l1l111_l1_ (u"ࠨࡆࡒ࡛ࡓࡒࡏࡂࡆ࠰ࡈࡔ࡝ࡎࡍࡑࡄࡈࡤ࡜ࡉࡅࡇࡒ࠱࠶ࡹࡴࠨᵃ"))
		l11llll111_l1_ = response.content
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠦࡉ࡝࡚ࡉࡏࡈ࠽࠲࠯ࡅ࡛࡝ࡰ࡟ࡶࡢ࠮࠮ࠫࡁࠬ࡟ࡡࡴ࡜ࡳ࡟ࠪᵄ"),l11llll111_l1_+l1l111_l1_ (u"ࠪࡠࡳࡢࡲࠨᵅ"),re.DOTALL)
		if not l1ll_l1_:
			l11llllll1_l1_(l1l111_l1_ (u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩᵆ"),l11llll11l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠬࠦࠠࠡࡖ࡫ࡩࠥࡳ࠳ࡶ࠺ࠣࡪ࡮ࡲࡥࠡࡦ࡬ࡨࠥࡴ࡯ࡵࠢ࡫ࡥࡻ࡫ࠠࡵࡪࡨࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩࠦ࡬ࡪࡰ࡮ࡷࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨᵇ")+l1lllll1_l1_+l1l111_l1_ (u"࠭ࠠ࡞ࠩᵈ"))
			return False
		l1ll1ll_l1_ = l1ll_l1_[0]
		if not l1ll1ll_l1_.startswith(l1l111_l1_ (u"ࠧࡩࡶࡷࡴࠬᵉ")):
			if l1ll1ll_l1_.startswith(l1l111_l1_ (u"ࠨ࠱࠲ࠫᵊ")): l1ll1ll_l1_ = l1lllll1_l1_.split(l1l111_l1_ (u"ࠩ࠽ࠫᵋ"),1)[0]+l1l111_l1_ (u"ࠪ࠾ࠬᵌ")+l1ll1ll_l1_
			elif l1ll1ll_l1_.startswith(l1l111_l1_ (u"ࠫ࠴࠭ᵍ")): l1ll1ll_l1_ = l1l111l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩᵎ"))+l1ll1ll_l1_
			else: l1ll1ll_l1_ = l1lllll1_l1_.rsplit(l1l111_l1_ (u"࠭࠯ࠨᵏ"),1)[0]+l1l111_l1_ (u"ࠧ࠰ࠩᵐ")+l1ll1ll_l1_
		response = requests.request(l1l111_l1_ (u"ࠨࡉࡈࡘࠬᵑ"),l1ll1ll_l1_,headers=headers,verify=False)
		chunk = response.content
		chunksize = len(chunk)
		l11lll1l1l_l1_ = len(l1ll_l1_)
		filesize = chunksize*l11lll1l1l_l1_
	else:
		chunksize = 1*l1l11l11l1_l1_
		response = requests.request(l1l111_l1_ (u"ࠩࡊࡉ࡙࠭ᵒ"),l1lllll1_l1_,headers=headers,verify=False,stream=True)
		if l1l111_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱ࡑ࡫࡮ࡨࡶ࡫ࠫᵓ") in response.headers: filesize = int(response.headers[l1l111_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲ࡒࡥ࡯ࡩࡷ࡬ࠬᵔ")])
		l11lll1l1l_l1_ = int(filesize//chunksize)
	l1l111ll11_l1_ = int(filesize//l1l11l11l1_l1_)+1
	if filesize<21000:
		l11llllll1_l1_(l1l111_l1_ (u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪᵕ"),l11llll11l_l1_(l1ll1_l1_)+l1l111_l1_ (u"࡙࠭ࠠࠡࠢ࡭ࡩ࡫࡯ࠡࡨ࡬ࡰࡪࠦࡩࡴࠢࡷࡳࡴࠦࡳ࡮ࡣ࡯ࡰࠥࡵࡲࠡ࡫ࡷࠤ࡮ࡹࠠ࡮࠵ࡸ࠼ࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨᵖ")+l1lllll1_l1_+l1l111_l1_ (u"ࠧࠡ࡟ࠣࠤࠥ࡜ࡩࡥࡧࡲࠤ࡫࡯࡬ࡦࠢࡶ࡭ࡿ࡫࠺ࠡ࡝ࠣࠫᵗ")+str(l1l111ll11_l1_)+l1l111_l1_ (u"ࠨࠢࡐࡆࠥࡣࠠࠡࠢࡄࡺࡦ࡯࡬ࡢࡤ࡯ࡩࠥࡹࡩࡻࡧ࠽ࠤࡠࠦࠧᵘ")+str(l1l111l11l_l1_)+l1l111_l1_ (u"ࠩࠣࡑࡇࠦ࡝ࠡࠢࠣࡊ࡮ࡲࡥ࠻ࠢ࡞ࠤࠬᵙ")+l11ll1l1l1_l1_+l1l111_l1_ (u"ࠪࠤࡢ࠭ᵚ"))
		l1111l1_l1_(l1l111_l1_ (u"ࠫࠬᵛ"),l1l111_l1_ (u"ࠬ࠭ᵜ"),l1l111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᵝ"),l1l111_l1_ (u"ࠧโึ็ࠤๆ๐ࠠๆ฻ิๅฮࠦออ็้้ࠣ็ࠠศๆไ๎ิ๐่ࠡล๋ࠤฬ๊ๅๅใูࠣ฿๐ัࠡฮาหࠥ๎ไ่าสࠤ้อ๋ࠠ็ๆ๊๊ࠥไษำ้ห๊าࠠหฯ่๎้ࠦ็ัษࠣห้๋ไโࠩᵞ"))
		return False
	l11lll11l1_l1_ = 400
	l11ll1ll1l_l1_ = l1l111l11l_l1_-l1l111ll11_l1_
	if l11ll1ll1l_l1_<l11lll11l1_l1_:
		l11llllll1_l1_(l1l111_l1_ (u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭ᵟ"),l11llll11l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠩࠣࠤࠥࡔ࡯ࡵࠢࡨࡲࡴࡻࡧࡩࠢࡧ࡭ࡸࡱࠠࡴࡲࡤࡧࡪࠦࡴࡰࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤࡹ࡮ࡥࠡࡸ࡬ࡨࡪࡵࠠࡧ࡫࡯ࡩࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨᵠ")+l1lllll1_l1_+l1l111_l1_ (u"ࠪࠤࡢࠦࠠࠡࡘ࡬ࡨࡪࡵࠠࡧ࡫࡯ࡩࠥࡹࡩࡻࡧ࠽ࠤࡠࠦࠧᵡ")+str(l1l111ll11_l1_)+l1l111_l1_ (u"ࠫࠥࡓࡂࠡ࡟ࠣࠤࠥࡇࡶࡢ࡫࡯ࡥࡧࡲࡥࠡࡵ࡬ࡾࡪࡀࠠ࡜ࠢࠪᵢ")+str(l1l111l11l_l1_)+l1l111_l1_ (u"ࠬࠦࡍࡃࠢ࠰ࠤࠬᵣ")+str(l11lll11l1_l1_)+l1l111_l1_ (u"࠭ࠠࡎࡄࠣࡡࠥࠦࠠࡇ࡫࡯ࡩ࠿࡛ࠦࠡࠩᵤ")+l11ll1l1l1_l1_+l1l111_l1_ (u"ࠧࠡ࡟ࠪᵥ"))
		l1111l1_l1_(l1l111_l1_ (u"ࠨࠩᵦ"),l1l111_l1_ (u"ࠩࠪᵧ"),l1l111_l1_ (u"่ࠪฬ๊้ࠦฮาࠤู๊วฮหࠣ็ฬ็๊สࠢ็่ฯำๅ๋ๆࠪᵨ"),l1l111_l1_ (u"ࠫฬ๊ๅๅใࠣห้๋ืๅ๊หࠤฯำๅ๋ๆ๊ࠤาาๅ่ࠢࠪᵩ")+str(l1l111ll11_l1_)+l1l111_l1_ (u"ࠬࠦๅ๋฼สฬฬ๐ส๊ࠡฯ๋ฬุใࠡใํ๋๋ࠥำศฯฬࠤๆอั฻หࠣࠫᵪ")+str(l1l111l11l_l1_)+l1l111_l1_ (u"࠭ࠠๆ์฽หออ๊ห๋่้๋ࠢอศใ฻อࠥ฿ไ๊ࠢ฼้้ࠦฬ่ษี็ࠥฮฯู้่้ࠣอใๅࠢํะอࠦลษไสลࠥ࠭ᵫ")+str(l11lll11l1_l1_)+l1l111_l1_ (u"ࠧࠡ็ํ฾ฬฮว๋ฬࠣๅฬืฺสࠢาหห๋ว๊๊ࠡิฬࠦๅฺ่ส๋ࠥษๆࠡฮ๊หื้ࠠๅษࠣฮําฯࠡใํ๋๋ࠥำศฯฬࠤ่อแ๋ห่ࠣฯำๅ๋ๆ้้ࠣ็ࠠศๆไ๎ิ๐่ࠡษ็้฼๊่ษࠩᵬ"))
		return False
	l1llll111l_l1_ = l1ll11ll1l_l1_(l1l111_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨᵭ"),l1l111_l1_ (u"ࠩࠪᵮ"),l1l111_l1_ (u"ࠪࠫᵯ"),l1l111_l1_ (u"ࠫ์๊ࠠหำํำࠥะอๆ์็ࠤฬ๊ๅๅใࠣรࠬᵰ"),l1l111_l1_ (u"ࠬอไๆๆไࠤฬ๊ๅุๆ๋ฬࠥำฬๆ้ࠣฮ็ื๊ษษࠣࠫᵱ")+str(l1l111ll11_l1_)+l1l111_l1_ (u"࠭ࠠๆ์฽หออ๊ห๋ࠢะ์อาไࠢไ๎์ࠦๅิษะอࠥ็วา฼ฬࠤฯ่ั๋สสࠤࠬᵲ")+str(l1l111l11l_l1_)+l1l111_l1_ (u"ࠧࠡ็ํ฾ฬฮว๋ฬࠣ์์ึวࠡษ็้้็ࠠใัࠣ๎าะวอࠢห฽฻ࠦวๅ๊ๅฮ๊ࠥไหฯ่๎้ࠦๅ็ࠢส่ส์สา่อࠤส๊้ࠡฮ๊หื้ࠠ࠯๊่ࠢࠥอๆห่ࠢฮศ้ฯ๊ࠡอี๏ีࠠศๆสืฯ๋ัศำࠣฬฯำๅ๋ๆ้้ࠣ็ࠠศๆไ๎ิ๐่ࠡมࠪᵳ"))
	if l1llll111l_l1_!=1:
		l1111l1_l1_(l1l111_l1_ (u"ࠨࠩᵴ"),l1l111_l1_ (u"ࠩࠪᵵ"),l1l111_l1_ (u"ࠪࠫᵶ"),l1l111_l1_ (u"ࠫฯ๋ࠠฦๆ฽หฦูࠦๆๆํอࠥะอๆ์็ࠤ๊๊แࠡษ็ๅ๏ี๊้ࠩᵷ"))
		l11llllll1_l1_(l1l111_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬᵸ"),l11llll11l_l1_(l1ll1_l1_)+l1l111_l1_ (u"࠭ࠠࠡࠢࡘࡷࡪࡸࠠࡳࡧࡩࡹࡸ࡫ࡤࠡࡶࡲࠤࡸࡺࡡࡳࡶࠣࡸ࡭࡫ࠠࡥࡱࡺࡲࡱࡵࡡࡥࠢࡲࡪࠥࡺࡨࡦࠢࡹ࡭ࡩ࡫࡯ࠡࡨ࡬ࡰࡪࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩᵹ")+l1lllll1_l1_+l1l111_l1_ (u"ࠧࠡ࡟ࠣࠤࠥࡌࡩ࡭ࡧ࠽ࠤࡠࠦࠧᵺ")+l11ll1l1l1_l1_+l1l111_l1_ (u"ࠨࠢࡠࠫᵻ"))
		return False
	l11llllll1_l1_(l1l111_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩᵼ"),l11llll11l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠪࠤࠥࠦࡄࡰࡹࡱࡰࡴࡧࡤࠡࡵࡷࡥࡷࡺࡥࡥࠢࡶࡹࡨࡩࡥࡴࡵࡩࡹࡱࡲࡹࠨᵽ"))
	l1l1111l1l_l1_ = l1l111ll1l_l1_()
	l1l1111l1l_l1_.create(l11ll1l1l1_l1_,l1l111_l1_ (u"ࠫฬ๊ำุำࠣๅํ่่๊้่ࠠࠣอๆࠡฬัึ๏์ࠠๆๆไࠤฬ๊แ๋ัํ์ࠬᵾ"))
	l11lll1l11_l1_ = True
	t1 = time.time()
	if PY3: file = open(l11ll1l1l1_l1_,l1l111_l1_ (u"ࠬࡽࡢࠨᵿ"))
	else: file = open(l11ll1l1l1_l1_.decode(l1l111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫᶀ")),l1l111_l1_ (u"ࠧࡸࡤࠪᶁ"))
	if l11ll11ll1_l1_==l1l111_l1_ (u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧᶂ"):
		for l1l111lll1_l1_ in range(1,l11lll1l1l_l1_+1):
			l1ll1ll_l1_ = l1ll_l1_[l1l111lll1_l1_-1]
			if not l1ll1ll_l1_.startswith(l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࠧᶃ")):
				if l1ll1ll_l1_.startswith(l1l111_l1_ (u"ࠪ࠳࠴࠭ᶄ")): l1ll1ll_l1_ = l1lllll1_l1_.split(l1l111_l1_ (u"ࠫ࠿࠭ᶅ"),1)[0]+l1l111_l1_ (u"ࠬࡀࠧᶆ")+l1ll1ll_l1_
				elif l1ll1ll_l1_.startswith(l1l111_l1_ (u"࠭࠯ࠨᶇ")): l1ll1ll_l1_ = l1l111l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫᶈ"))+l1ll1ll_l1_
				else: l1ll1ll_l1_ = l1lllll1_l1_.rsplit(l1l111_l1_ (u"ࠨ࠱ࠪᶉ"),1)[0]+l1l111_l1_ (u"ࠩ࠲ࠫᶊ")+l1ll1ll_l1_
			response = requests.request(l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧᶋ"),l1ll1ll_l1_,headers=headers,verify=False)
			chunk = response.content
			response.close()
			file.write(chunk)
			l11ll1ll11_l1_ = time.time()
			l11ll1l111_l1_ = l11ll1ll11_l1_-t1
			l11ll1l1ll_l1_ = l11ll1l111_l1_//l1l111lll1_l1_
			l1l1111111_l1_ = l11ll1l1ll_l1_*(l11lll1l1l_l1_+1)
			l11ll1llll_l1_ = l1l1111111_l1_-l11ll1l111_l1_
			l1l111111l_l1_(l1l1111l1l_l1_,int(100*l1l111lll1_l1_//(l11lll1l1l_l1_+1)),l1l111_l1_ (u"ࠫฬ๊ำุำࠣๅํ่่๊้่ࠠࠣอๆࠡฬัึ๏์ࠠๆๆไࠤฬ๊แ๋ัํ์ࠬᶌ"),l1l111_l1_ (u"ࠬาไษ่่ࠢๆࠦวๅใํำ๏๎࠺࠮ࠢส่ัุมࠡำๅ้ࠬᶍ"),str(l1l111lll1_l1_*chunksize//l1l11l11l1_l1_)+l1l111_l1_ (u"࠭࠯ࠨᶎ")+str(l1l111ll11_l1_)+l1l111_l1_ (u"ࠧࠡࡏࡅࠤ้ࠥࠦࠠไอࠤ๊ะศใ์࠽ࠤࠬᶏ")+time.strftime(l1l111_l1_ (u"ࠣࠧࡋ࠾ࠪࡓ࠺ࠦࡕࠥᶐ"),time.gmtime(l11ll1llll_l1_))+l1l111_l1_ (u"ࠩࠣไࠬᶑ"))
			if l1l1111l1l_l1_.iscanceled():
				l11lll1l11_l1_ = False
				break
	else:
		l1l111lll1_l1_ = 0
		for chunk in response.iter_content(chunk_size=chunksize):
			file.write(chunk)
			l1l111lll1_l1_ = l1l111lll1_l1_+1
			l11ll1ll11_l1_ = time.time()
			l11ll1l111_l1_ = l11ll1ll11_l1_-t1
			l11ll1l1ll_l1_ = l11ll1l111_l1_/l1l111lll1_l1_
			l1l1111111_l1_ = l11ll1l1ll_l1_*(l11lll1l1l_l1_+1)
			l11ll1llll_l1_ = l1l1111111_l1_-l11ll1l111_l1_
			l1l111111l_l1_(l1l1111l1l_l1_,int(100*l1l111lll1_l1_/(l11lll1l1l_l1_+1)),l1l111_l1_ (u"ࠪหู้ืาࠢไ์็ࠦ็้่ࠢ็ฬ์ࠠหะี๎๋ࠦๅๅใࠣห้็๊ะ์๋ࠫᶒ"),l1l111_l1_ (u"ࠫั๊ศࠡ็็ๅࠥอไโ์า๎ํࡀ࠭ࠡษ็ะืวࠠาไ่ࠫᶓ"),str(l1l111lll1_l1_*chunksize//l1l11l11l1_l1_)+l1l111_l1_ (u"ࠬ࠵ࠧᶔ")+str(l1l111ll11_l1_)+l1l111_l1_ (u"࠭ࠠࡎࡄࠣࠤ่ࠥࠦใฬ้ࠣฯฮโ๋࠼ࠣࠫᶕ")+time.strftime(l1l111_l1_ (u"ࠢࠦࡊ࠽ࠩࡒࡀࠥࡔࠤᶖ"),time.gmtime(l11ll1llll_l1_))+l1l111_l1_ (u"ࠨࠢใࠫᶗ"))
			if l1l1111l1l_l1_.iscanceled():
				l11lll1l11_l1_ = False
				break
		response.close()
	file.close()
	l1l1111l1l_l1_.close()
	if not l11lll1l11_l1_:
		l11llllll1_l1_(l1l111_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩᶘ"),l11llll11l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠪࠤࠥࠦࡕࡴࡧࡵࠤࡨࡧ࡮ࡤࡧ࡯ࡩࡩ࠵ࡩ࡯ࡶࡨࡶࡷࡻࡰࡵࡧࡧࠤࡹ࡮ࡥࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࠣࡴࡷࡵࡣࡦࡵࡶࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧᶙ")+l1lllll1_l1_+l1l111_l1_ (u"ࠫࠥࡣࠠࠡࠢࡉ࡭ࡱ࡫࠺ࠡ࡝ࠣࠫᶚ")+l11ll1l1l1_l1_+l1l111_l1_ (u"ࠬࠦ࡝ࠨᶛ"))
		l1111l1_l1_(l1l111_l1_ (u"࠭ࠧᶜ"),l1l111_l1_ (u"ࠧࠨᶝ"),l1l111_l1_ (u"ࠨࠩᶞ"),l1l111_l1_ (u"ࠩอ้ࠥหไ฻ษฤࠤ฾๋ไ๋หࠣฮา๋๊ๅ่่ࠢๆࠦวๅใํำ๏๎ࠧᶟ"))
		return True
	l11llllll1_l1_(l1l111_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪᶠ"),l11llll11l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠫࠥࠦࠠࡗ࡫ࡧࡩࡴࠦࡦࡪ࡮ࡨࠤࡩࡵࡷ࡯࡮ࡲࡥࡩ࡫ࡤࠡࡵࡸࡧࡨ࡫ࡳࡴࡨࡸࡰࡱࡿࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪᶡ")+l1lllll1_l1_+l1l111_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡊ࡮ࡲࡥ࠻ࠢ࡞ࠤࠬᶢ")+l11ll1l1l1_l1_+l1l111_l1_ (u"࠭ࠠ࡞ࠩᶣ"))
	l1111l1_l1_(l1l111_l1_ (u"ࠧࠨᶤ"),l1l111_l1_ (u"ࠨࠩᶥ"),l1l111_l1_ (u"ࠩࠪᶦ"),l1l111_l1_ (u"ࠪฮ๊ࠦสฮ็ํ่๋ࠥไโࠢส่ๆ๐ฯ๋๊ࠣฬ๋าวฮࠩᶧ"))
	return True
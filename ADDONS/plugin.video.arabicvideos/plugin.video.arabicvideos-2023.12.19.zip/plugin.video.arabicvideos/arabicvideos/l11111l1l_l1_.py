# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠪࡇࡎࡓࡁࡄࡎࡘࡔࠬᝤ")
l1lllll_l1_ = l1l111_l1_ (u"ࠫࡤࡉࡍࡄࡡࠪᝥ")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"๋่ࠬใ฻๊ࠣฯ็ไ๋ๅึࠫᝦ")]
def l11l1ll_l1_(mode,url,text):
	if   mode==490: l1lll_l1_ = l1l1l11_l1_()
	elif mode==491: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==492: l1lll_l1_ = PLAY(url)
	elif mode==493: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==494: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==499: l1lll_l1_ = l1lll1_l1_(text,url)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪᝧ"),l111l1_l1_,l1l111_l1_ (u"ࠧࠨᝨ"),l1l111_l1_ (u"ࠨࠩᝩ"),l1l111_l1_ (u"ࠩࠪᝪ"),l1l111_l1_ (u"ࠪࠫᝫ"),l1l111_l1_ (u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡕ࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨᝬ"))
	html = response.content
	l1l11ll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ᝭"),html,re.DOTALL)
	l1l11ll_l1_ = l1l11ll_l1_[0].strip(l1l111_l1_ (u"࠭࠯ࠨᝮ"))
	l1l11ll_l1_ = l1l111l_l1_(l1l11ll_l1_,l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫᝯ"))
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡩ࡭ࡱࡺࡥࡳࠢࡄ࡮ࡦࡾࡩࡧࡻࡉ࡭ࡱࡺࡥࡳࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧᝰ"),html,re.DOTALL)
	if l11ll11_l1_:
		block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡧ࡫࡯ࡸࡪࡸ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ᝱"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if title in l11lll_l1_: continue
			l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠪ࠳ࡼࡶ࠭ࡤࡱࡱࡸࡪࡴࡴ࠰ࡶ࡫ࡩࡲ࡫ࡳ࠰ࡱ࡯ࡨ࠴࡬ࡩ࡭ࡶࡨࡶ࠴࠭ᝲ")+l1ll1ll_l1_+l1l111_l1_ (u"ࠫ࠳ࡶࡨࡱࠩᝳ")
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ᝴"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ᝵")+l1lllll_l1_+title,l1ll1ll_l1_,491)
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ᝶"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ᝷"),l1l111_l1_ (u"ࠩࠪ᝸"),9999)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ᝹"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭᝺")+l1lllll_l1_+l1l111_l1_ (u"ࠬษแๅษ่ࠫ᝻"),l1l11ll_l1_+l1l111_l1_ (u"࠭࠯ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠱สๅ้อๅ࠮࡯ࡲࡺ࡮࡫ࡳ࠮ࡨ࡬ࡰࡲ࡫࠯ࡧࡱࡵࡩ࡮࡭࡮࠮ࡪࡧ࠱ฬ็ไศ็࠰หั์ศ๊࠯࠵ࠫ᝼"),494,l1l111_l1_ (u"ࠧࠨ᝽"),l1l111_l1_ (u"ࠨࠩ᝾"),l1l111_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭᝿"))
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪក"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ខ")+l1lllll_l1_+l1l111_l1_ (u"๋ࠬำๅี็หฯ࠭គ"),l1l11ll_l1_+l1l111_l1_ (u"࠭࠯ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠱่ืู้ไศฬ࠲ุ้๊ำๅษอ࠱ฬาๆษ๋ࠪឃ"),494,l1l111_l1_ (u"ࠧࠨង"),l1l111_l1_ (u"ࠨࠩច"),l1l111_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ឆ"))
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨជ"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫឈ"),l1l111_l1_ (u"ࠬ࠭ញ"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨ࡮ࡢࡸ࡬࡫ࡦࡺࡩࡰࡰ࠰ࡱࡪࡴࡵࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬដ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬឋ"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if l1ll1ll_l1_==l1l111_l1_ (u"ࠨ࠱ࠪឌ"): continue
		if l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࠧឍ") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l11ll_l1_+l1ll1ll_l1_
		if title in l11lll_l1_: continue
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪណ"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ត")+l1lllll_l1_+title,l1ll1ll_l1_,491)
	return html
def l11ll1_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩថ"),url,l1l111_l1_ (u"࠭ࠧទ"),l1l111_l1_ (u"ࠧࠨធ"),l1l111_l1_ (u"ࠨࠩន"),l1l111_l1_ (u"ࠩࠪប"),l1l111_l1_ (u"ࠪࡇࡎࡓࡁࡄࡎࡘࡔ࠲࡙ࡕࡃࡏࡈࡒ࡚࠳࠱ࡴࡶࠪផ"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧ࡬ࡩ࡭ࡶࡨࡶࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪព"),html,re.DOTALL)
	if l11ll1l_l1_:
		block = l11ll1l_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪភ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if title in l11lll_l1_: continue
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ម"),l1lllll_l1_+title,l1ll1ll_l1_,491)
	return
def l1lll11_l1_(url,l111l1l1l_l1_=l1l111_l1_ (u"ࠧࠨយ")):
	items = []
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬរ"),url,l1l111_l1_ (u"ࠩࠪល"),l1l111_l1_ (u"ࠪࠫវ"),l1l111_l1_ (u"ࠫࠬឝ"),l1l111_l1_ (u"ࠬ࠭ឞ"),l1l111_l1_ (u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡐ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬស"))
	html = response.content
	block = l1l111_l1_ (u"ࠧࠨហ")
	if l1l111_l1_ (u"ࠨ࠰ࡳ࡬ࡵ࠭ឡ") in url: block = html
	elif l1l111_l1_ (u"ࠩࡂࡷࡂ࠭អ") in url:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡧࡲ࡯ࡤ࡭ࡶࠬ࠳࠰࠿ࠪࠤࡰࡥࡳ࡯ࡦࡦࡵࡷࠦࠬឣ"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡧ࡬ࡵ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪឤ"),block,re.DOTALL)
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡂ࡭ࡱࡦ࡯ࡸ࠮࠮ࠫࡁࠬࠦࡲࡧ࡮ࡪࡨࡨࡷࡹࠨࠧឥ"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
	if not block: return
	l1l1_l1_ = []
	l1ll11_l1_ = [l1l111_l1_ (u"࠭ๅีษ๊ำฮ࠭ឦ"),l1l111_l1_ (u"ࠧโ์็้ࠬឧ"),l1l111_l1_ (u"ࠨษ฽๊๏ฯࠧឨ"),l1l111_l1_ (u"ࠩฦ฾๋๐ษࠨឩ"),l1l111_l1_ (u"ࠪ็้๐ศࠨឪ"),l1l111_l1_ (u"ࠫฬ฿ไศ่ࠪឫ"),l1l111_l1_ (u"ࠬํฯศใࠪឬ"),l1l111_l1_ (u"࠭ๅษษิหฮ࠭ឭ"),l1l111_l1_ (u"ฺࠧำูࠫឮ"),l1l111_l1_ (u"ࠨ็๊ีัอๆࠨឯ"),l1l111_l1_ (u"ࠩส่อ๎ๅࠨឰ"),l1l111_l1_ (u"ุ้ࠪือ๋หࠪឱ")]
	for l1ll1ll_l1_,l1ll1l_l1_,title in items:
		title = unescapeHTML(title)
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࠭࠴ࠪࡀࠫࠣั้่ษࠡ࡞ࡧ࠯ࠬឲ"),title,re.DOTALL)
		if not l1l1lll_l1_: l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࠤฬ๊อๅไฬࠤࡡࡪࠫࠨឳ"),title,re.DOTALL)
		if not l1l1lll_l1_ or any(value in title for value in l1ll11_l1_):
			addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ឴"),l1lllll_l1_+title,l1ll1ll_l1_,492,l1ll1l_l1_)
		elif l1l1lll_l1_ and l1l111_l1_ (u"ࠧฮๆๅอࠬ឵") in title:
			title = l1l111_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧា") + l1l1lll_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩិ"),l1lllll_l1_+title,l1ll1ll_l1_,493,l1ll1l_l1_)
				l1l1_l1_.append(title)
		else: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪី"),l1lllll_l1_+title,l1ll1ll_l1_,493,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ឹ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬࡂ࡬ࡪࡀ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪឺ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = unescapeHTML(title)
			title = title.replace(l1l111_l1_ (u"࠭วๅืไัฮࠦࠧុ"),l1l111_l1_ (u"ࠧࠨូ"))
			if title!=l1l111_l1_ (u"ࠨࠩួ"): addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩើ"),l1lllll_l1_+l1l111_l1_ (u"ูࠪๆำษࠡࠩឿ")+title,l1ll1ll_l1_,491)
	return
def l1ll1l11_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨៀ"),url,l1l111_l1_ (u"ࠬ࠭េ"),l1l111_l1_ (u"࠭ࠧែ"),l1l111_l1_ (u"ࠧࠨៃ"),l1l111_l1_ (u"ࠨࠩោ"),l1l111_l1_ (u"ࠩࡆࡍࡒࡇࡃࡍࡗࡓ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪៅ"))
	html = response.content
	l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡇࡻࡴࡵࡱࡱࡷࡇࡧࡲࡄࡱࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬំ"),html,re.DOTALL)
	if l1lllll1_l1_:
		l1lllll1_l1_ = l1lllll1_l1_[0]
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨះ"),l1lllll1_l1_,l1l111_l1_ (u"ࠬ࠭ៈ"),l1l111_l1_ (u"࠭ࠧ៉"),l1l111_l1_ (u"ࠧࠨ៊"),l1l111_l1_ (u"ࠨࠩ់"),l1l111_l1_ (u"ࠩࡆࡍࡒࡇࡃࡍࡗࡓ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠲࡯ࡦࠪ៌"))
		html = response.content
	l1ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦ࡮ࡳࡧ࠮ࡴࡨࡷࡵࡵ࡮ࡴ࡫ࡹࡩࠧࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ៍"),html,re.DOTALL)
	if l1ll1l_l1_: l1ll1l_l1_ = l1ll1l_l1_[0]
	else: l1ll1l_l1_ = xbmc.getInfoLabel(l1l111_l1_ (u"ࠫࡑ࡯ࡳࡵࡋࡷࡩࡲ࠴ࡔࡩࡷࡰࡦࠬ៎"))
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡦࡪ࡮ࡷࡩࡷࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ៏"),html,re.DOTALL)
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡃ࡮ࡲࡧࡰࡹࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠣࠩ័"),html,re.DOTALL)
	if l11ll1l_l1_ and l1l111_l1_ (u"ࠧ࠰ࡵࡨࡶ࡮࡫ࡳ࠰ࠩ៑") not in url:
		block = l11ll1l_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ្࠭"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ៓"),l1lllll_l1_+title,l1ll1ll_l1_,493,l1ll1l_l1_)
	elif l11ll11_l1_:
		block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡮ࡳࡡࡨࡧ࡟࠾ࡺࡸ࡬࡝ࠪࠫ࠲࠯ࡅࠩ࡝ࠫ࠱࠮ࡄࠨࡢࡰࡺࡷ࡭ࡹࡲࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ។"),block,re.DOTALL)
		if items:
			for l1ll1ll_l1_,l1ll1l_l1_,title in items:
				title = title.strip(l1l111_l1_ (u"ࠫࠥ࠭៕"))
				addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ៖"),l1lllll_l1_+title,l1ll1ll_l1_,492,l1ll1l_l1_)
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩៗ"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ៘"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				title = unescapeHTML(title)
				title = title.replace(l1l111_l1_ (u"ࠨษ็ูๆำษࠡࠩ៙"),l1l111_l1_ (u"ࠩࠪ៚"))
				if title!=l1l111_l1_ (u"ࠪࠫ៛"): addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫៜ"),l1lllll_l1_+l1l111_l1_ (u"ࠬ฻แฮหࠣࠫ៝")+title,l1ll1ll_l1_,491)
	return
def PLAY(url):
	l1lllll1_l1_ = url.strip(l1l111_l1_ (u"࠭࠯ࠨ៞"))+l1l111_l1_ (u"ࠧ࠰ࡁࡹ࡭ࡪࡽ࠽࠲ࠩ៟")
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ០"),l1lllll1_l1_,l1l111_l1_ (u"ࠩࠪ១"),l1l111_l1_ (u"ࠪࠫ២"),l1l111_l1_ (u"ࠫࠬ៣"),l1l111_l1_ (u"ࠬ࠭៤"),l1l111_l1_ (u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡐ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ៥"))
	html = response.content
	l1llll_l1_ = []
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ៦"))
	l11111l11_l1_ = re.findall(l1l111_l1_ (u"ࠣࡦࡤࡸࡦࡀࠠࠨࡳࡀࠬ࠳࠰࠿ࠪࠨࠥ៧"),html,re.DOTALL)
	l11111l11_l1_ = l11111l11_l1_[0]
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡷࡪࡸࡶࡦࡴࡶࡐ࡮ࡹࡴࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ៨"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡵࡨࡶࡻ࡫ࡲ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱࡯࡭ࡃ࠭៩"),block,re.DOTALL)
		for l111111ll_l1_,title in items:
			title = title.strip(l1l111_l1_ (u"ࠫࠥ࠭៪"))
			l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠬ࠵ࡷࡱ࠯ࡦࡳࡳࡺࡥ࡯ࡶ࠲ࡸ࡭࡫࡭ࡦࡵ࠲ࡳࡱࡪ࠯ࡴࡧࡵࡺࡪࡸࡳ࠰ࡵࡨࡶࡻ࡫ࡲ࠯ࡲ࡫ࡴࡄࡷ࠽ࠨ៫")+l11111l11_l1_+l1l111_l1_ (u"࠭ࠦࡪ࠿ࠪ៬")+l111111ll_l1_+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ៭")+title+l1l111_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩ៮")
			l1llll_l1_.append(l1ll1ll_l1_)
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡩࡲࡨࡥࡥࡕࡨࡶࡻ࡫ࡲࠣ࠰࠭ࡃࡘࡘࡃ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ៯"),html,re.DOTALL)
	if l1ll1ll_l1_:
		title = l1l111_l1_ (u"้ࠪๆ฼ไࠨ៰")
		l1ll1ll_l1_ = l1ll1ll_l1_[0]+l1l111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࡤࡥࡥ࡮ࡤࡨࡨࡤࡥࠧ៱")+title
		l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡤࡰࡹࡱࡰࡴࡧࡤࡴࡎ࡬ࡷࡹࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ៲"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭࠼ࡵࡦࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡸࡩࡄ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ៳"),block,re.DOTALL)
		for title,l1ll1ll_l1_ in items:
			title = title.strip(l1l111_l1_ (u"ࠧࠡࠩ៴"))
			if l1l111_l1_ (u"ࠨࡣࡱࡥࡻ࡯ࡤࡻࠩ៵") in l1ll1ll_l1_: l1lllllll_l1_ = l1l111_l1_ (u"ࠩࡢࡣำอีࠨ៶")
			else: l1lllllll_l1_ = l1l111_l1_ (u"ࠪࠫ៷")
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ៸")+title+l1l111_l1_ (u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩ៹")+l1lllllll_l1_
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ៺"),url)
	return
def l1lll1_l1_(search,l1l11ll_l1_=l1l111_l1_ (u"ࠧࠨ៻")):
	if not l1l11ll_l1_: l1l11ll_l1_ = l111l1_l1_
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search:
		search = l1llll1_l1_()
		if not search: return
	search = search.replace(l1l111_l1_ (u"ࠨࠢࠪ៼"),l1l111_l1_ (u"ࠩ࠮ࠫ៽"))
	url = l1l11ll_l1_+l1l111_l1_ (u"ࠪ࠳࡮ࡴࡤࡦࡺ࠱ࡴ࡭ࡶ࠿ࡴ࠿ࠪ៾")+search
	l1lll11_l1_(url)
	return
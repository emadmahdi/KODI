# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩ廀")
l1lllll_l1_ = l1l111_l1_ (u"ࠩࡢ࡝࡚࡚࡟ࠨ廁")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
def l11l1ll_l1_(mode,url,text,type,l1llllll1_l1_):
	if	 mode==140: l1lll_l1_ = l1l1l11_l1_()
	elif mode==143: l1lll_l1_ = PLAY(url,type)
	elif mode==144: l1lll_l1_ = ITEMS(url,text,l1llllll1_l1_)
	elif mode==145: l1lll_l1_ = l111lll1ll11_l1_(url)
	elif mode==146: l1lll_l1_ = l111l1ll1ll1_l1_(url)
	elif mode==147: l1lll_l1_ = l111ll1lll1l_l1_()
	elif mode==148: l1lll_l1_ = l111ll1lllll_l1_()
	elif mode==149: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ廂"),l1lllll_l1_+l1l111_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ廃"),l1l111_l1_ (u"ࠬ࠭廄"),149,l1l111_l1_ (u"࠭ࠧ廅"),l1l111_l1_ (u"ࠧࠨ廆"),l1l111_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ廇"))
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ廈"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ廉")+l1l111_l1_ (u"ࠫࡤ࡟ࡔࡄࡡࠪ廊")+l1l111_l1_ (u"๋่ࠬศไ฼ࠤฬิสศำ๊หࠥอไๆสิ้ั࠭廋"),l1l111_l1_ (u"࠭ࠧ廌"),290)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ廍"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ廎")+l1lllll_l1_+l1l111_l1_ (u"่ࠩ์ฬู่ࠡษัฮฬื็ศࠢํ์ฯ๐่ษࠩ廏"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳࡫࡫ࡥࡥ࠱ࡪࡹ࡮ࡪࡥࡠࡤࡸ࡭ࡱࡪࡥࡳࠩ廐"),144)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ廑"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ廒")+l1lllll_l1_+l1l111_l1_ (u"࠭วๅืไัฮࠦวๅำษ๎ุ๐ษࠨ廓"),l111l1_l1_,144,l1l111_l1_ (u"ࠧࠨ廔"),l1l111_l1_ (u"ࠨࠩ廕"),l1l111_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭廖"))
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ廗"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭廘")+l1lllll_l1_+l1l111_l1_ (u"ࠬอไๆฯอ์๎ࠦวๅำสสั࠭廙"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡧࡧࡨࡨ࠴ࡺࡲࡦࡰࡧ࡭ࡳ࡭ࠧ廚"),146)
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ廛"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ廜"),l1l111_l1_ (u"ࠩࠪ廝"),9999)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ廞"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭廟")+l1lllll_l1_+l1l111_l1_ (u"ࠬฮอฬ࠼ࠣๆ๋๎วหࠢ฼ีอ๐ษࠨ廠"),l1l111_l1_ (u"࠭ࠧ廡"),147)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ廢"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ廣")+l1lllll_l1_+l1l111_l1_ (u"ࠩหัะࡀࠠใ่๋หฯࠦรอ่ห๎ฮ࠭廤"),l1l111_l1_ (u"ࠪࠫ廥"),148)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ廦"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ廧")+l1lllll_l1_+l1l111_l1_ (u"࠭ศฮอ࠽ࠤฬ็ไศ็ࠣ฽ึฮ๊สࠩ廨"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡴࡨࡷࡺࡲࡴࡴࡁࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹ࠾ใํ่๊࠭廩"),144)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ廪"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ廫")+l1lllll_l1_+l1l111_l1_ (u"ࠪฬาั࠺ࠡษไ่ฬ๋ࠠศฮ้ฬ๏ฯࠧ廬"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡸࡥࡴࡷ࡯ࡸࡸࡅࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࡂࡳ࡯ࡷ࡫ࡨࠫ廭"),144)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ廮"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ廯")+l1lllll_l1_+l1l111_l1_ (u"ࠧษฯฮ࠾๋ࠥำาฯํหฯูࠦาสํอࠬ廰"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡵࡩࡸࡻ࡬ࡵࡵࡂࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺ࠿่ืึำ๊สࠩ廱"),144)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ廲"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ廳")+l1lllll_l1_+l1l111_l1_ (u"ࠫอำห࠻่ࠢืู้ไศฬࠣ฽ึฮ๊สࠩ廴"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡲࡦࡵࡸࡰࡹࡹ࠿ࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾࡃๅิๆึ่ࠫࡹࡰ࠾ࡇࡪࡍࡖࡇࡷ࠾࠿ࠪ廵"),144)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭延"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ廷")+l1lllll_l1_+l1l111_l1_ (u"ࠨสะฯ࠿ࠦๅิๆึ่ฬะࠠศฮ้ฬ๏ฯࠧ廸"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡶࡪࡹࡵ࡭ࡶࡶࡃࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࡀࡷࡪࡸࡩࡦࡵࠩࡷࡵࡃࡅࡨࡋࡔࡅࡼࡃ࠽ࠨ廹"),144)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ建"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭廻")+l1lllll_l1_+l1l111_l1_ (u"ࠬฮอฬ࠼ุ้๊ࠣำๅษอࠤ่อัห๊้ࠫ廼"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡳࡧࡶࡹࡱࡺࡳࡀࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿ࠽ไษิฮํ์ࠦࡴࡲࡀࡉ࡬ࡏࡑࡂࡹࡀࡁࠬ廽"),144)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ廾"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ廿")+l1lllll_l1_+l1l111_l1_ (u"ࠩหัะࡀࠠฯูหอࠥอไๆำฯ฽๏ฯࠧ开"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡷ࡫ࡳࡶ࡮ࡷࡷࡄࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࡁ็์วส࠭ๆีอ๊วย࠭ส่ๆ฼วว์ฬ࠯ำ฽ศส࠭ส่ัู๋สࠨࡶࡴࡂࡉࡁࡊࡕࡄ࡬ࡆࡈࠧ弁"),144)
	return
def l111ll1lll1l_l1_():
	ITEMS(l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡸࡥࡴࡷ࡯ࡸࡸࡅࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࡂ่ๆศห࠮ฬะࠬࡳࡱ࠿ࡈ࡫ࡏࡇࡁࡒ࠿ࡀࠫ异"))
	return
def l111ll1lllll_l1_():
	ITEMS(l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡲࡦࡵࡸࡰࡹࡹ࠿ࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾࡃࡴࡷࠨࡶࡴࡂࡋࡧࡋࡃࡄࡕࡂࡃࠧ弃"))
	return
def PLAY(url,type):
	import ll_l1_
	ll_l1_.l1l_l1_([url],l1ll1_l1_,type,url)
	return
def l111l1ll1ll1_l1_(url):
	html,l1llll1lll_l1_,data = l111ll1ll11l_l1_(url)
	dd = l1llll1lll_l1_[l1l111_l1_ (u"࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ弄")][l1l111_l1_ (u"ࠧࡵࡹࡲࡇࡴࡲࡵ࡮ࡰࡅࡶࡴࡽࡳࡦࡔࡨࡷࡺࡲࡴࡴࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ弅")][l1l111_l1_ (u"ࠨࡶࡤࡦࡸ࠭弆")]
	for l1l111lll1_l1_ in range(len(dd)):
		item = dd[l1l111lll1_l1_]
		l111ll11l11l_l1_(item,url,str(l1l111lll1_l1_))
	l111l1llll1l_l1_ = dd[0][l1l111_l1_ (u"ࠩࡷࡥࡧࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ弇")][l1l111_l1_ (u"ࠪࡧࡴࡴࡴࡦࡰࡷࠫ弈")][l1l111_l1_ (u"ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ弉")][l1l111_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ弊")]
	s = 0
	for l1l111lll1_l1_ in range(len(l111l1llll1l_l1_)):
		item = l111l1llll1l_l1_[l1l111lll1_l1_][l1l111_l1_ (u"࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬ弋")][l1l111_l1_ (u"ࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩ弌")][0]
		if list(item[l1l111_l1_ (u"ࠨࡵ࡫ࡩࡱ࡬ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ弍")][l1l111_l1_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪ弎")].keys())[0]==l1l111_l1_ (u"ࠪ࡬ࡴࡸࡩࡻࡱࡱࡸࡦࡲࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬ式"): continue
		succeeded,title,l1ll1ll_l1_,l1ll1l_l1_,count,l1l1lll111_l1_,l111lll11l1l_l1_,l111ll1ll1l1_l1_ = l111llll1111_l1_(item)
		if not title:
			s += 1
			title = l1l111_l1_ (u"ࠫๆ๐ฯ๋๊๊หฯࠦัศศฯอࠥ࠭弐")+str(s)
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ弑"),l1lllll_l1_+title,url,144,l1l111_l1_ (u"࠭ࠧ弒"),str(l1l111lll1_l1_))
	key = re.findall(l1l111_l1_ (u"ࠧࠣ࡫ࡱࡲࡪࡸࡴࡶࡤࡨࡅࡵ࡯ࡋࡦࡻࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ弓"),html,re.DOTALL)
	l1lllll1_l1_ = l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡤࡱࡰ࠳ࡾࡵࡵࡵࡷࡥࡩ࡮࠵ࡶ࠲࠱ࡪࡹ࡮ࡪࡥࡀ࡭ࡨࡽࡂ࠭弔")+key[0]
	html,l1llll1lll_l1_,l1l11llll_l1_ = l111ll1ll11l_l1_(l1lllll1_l1_)
	for l1lll1l11lll_l1_ in range(3,4):
		dd = l1llll1lll_l1_[l1l111_l1_ (u"ࠩ࡬ࡸࡪࡳࡳࠨ引")][l1lll1l11lll_l1_][l1l111_l1_ (u"ࠪ࡫ࡺ࡯ࡤࡦࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ弖")][l1l111_l1_ (u"ࠫ࡮ࡺࡥ࡮ࡵࠪ弗")]
		for l1l111lll1_l1_ in range(len(dd)):
			item = dd[l1l111lll1_l1_]
			if l1l111_l1_ (u"ࠬ࡟࡯ࡶࡖࡸࡦࡪࠦࡐࡳࡧࡰ࡭ࡺࡳࠧ弘") in str(item): continue
			l111ll11l11l_l1_(item)
	return
def ITEMS(url,data=l1l111_l1_ (u"࠭ࠧ弙"),index=0):
	global settings
	if not data: data = settings.getSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡩࡧࡴࡢࠩ弚"))
	if index: index = int(index)
	else: index = 0
	data = data.replace(l1l111_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ弛"),l1l111_l1_ (u"ࠩࠪ弜"))
	html,l1llll1lll_l1_,l1l11llll_l1_ = l111ll1ll11l_l1_(url,data)
	l1l11ll11l_l1_,l111l1ll1l11_l1_ = l1l111_l1_ (u"ࠪࠫ弝"),l1l111_l1_ (u"ࠫࠬ弞")
	owner = re.findall(l1l111_l1_ (u"ࠬࠨ࡯ࡸࡰࡨࡶࡓࡧ࡭ࡦࠤ࠱࠮ࡄࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡺࡸ࡬ࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ弟"),html,re.DOTALL)
	if not owner: owner = re.findall(l1l111_l1_ (u"࠭ࠢࡷ࡫ࡧࡩࡴࡕࡷ࡯ࡧࡵࠦ࠳࠰࠿ࠣࡶࡨࡼࡹࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡺࡸ࡬ࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ张"),html,re.DOTALL)
	if not owner: owner = re.findall(l1l111_l1_ (u"ࠧࠣࡥ࡫ࡥࡳࡴࡥ࡭ࡏࡨࡸࡦࡪࡡࡵࡣࡕࡩࡳࡪࡥࡳࡧࡵࠦ࠿ࡢࡻࠣࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡵࡷ࡯ࡧࡵ࡙ࡷࡲࡳࠣ࠼࡟࡟ࠧ࠮࠮ࠫࡁࠬࠦࠬ弡"),html,re.DOTALL)
	if owner:
		l1l11ll11l_l1_ = l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫ弢")+owner[0][0]+l1l111_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ弣")
		l1ll1ll_l1_ = owner[0][1]
		if l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ弤") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
		if l1l111_l1_ (u"ࠫࡱ࡯ࡳࡵ࠿ࠪ弥") in url: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ弦"),l1lllll_l1_+l1l11ll11l_l1_,l1ll1ll_l1_,144)
	l111l1lll1l1_l1_ = [l1l111_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮ࠧ弧"),l1l111_l1_ (u"ࠧ࠰ࡸ࡬ࡨࡪࡵࡳࠨ弨"),l1l111_l1_ (u"ࠨ࠱ࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫ弩"),l1l111_l1_ (u"ࠩ࠲ࡴࡱࡧࡹ࡭࡫ࡶࡸࡸ࠭弪"),l1l111_l1_ (u"ࠪ࠳࡫࡫ࡡࡵࡷࡵࡩࡩ࠭弫"),l1l111_l1_ (u"ࠫࡸࡹ࠽ࠨ弬"),l1l111_l1_ (u"ࠬࡩࡴࡰ࡭ࡨࡲࡂ࠭弭"),l1l111_l1_ (u"࠭࡫ࡦࡻࡀࠫ弮"),l1l111_l1_ (u"ࠧࡣࡲࡀࠫ弯"),l1l111_l1_ (u"ࠨࡵ࡫ࡩࡱ࡬࡟ࡪࡦࡀࠫ弰")]
	l111l1ll11ll_l1_ = not any(value in url for value in l111l1lll1l1_l1_)
	if l111l1ll11ll_l1_ and l1l11ll11l_l1_:
		l1l11l1ll_l1_ = l1l111_l1_ (u"ࠩส่อำหࠨ弱")
		l1lllllll_l1_ = l1l111_l1_ (u"ࠪๆํอฦๆࠢส่ฯฺฺ๋ๆࠪ弲")
		l1l11l1l1_l1_ = l1l111_l1_ (u"ࠫฬ๊แ๋ัํ์์อสࠨ弳")
		l111l1ll1l1l_l1_ = l1l111_l1_ (u"ࠬอไใ่๋หฯ࠭弴")
		addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ張"),l1lllll_l1_+l1l11ll11l_l1_,url,9999)
		if l1l111_l1_ (u"ࠧࠣࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤหัะࠨࠧ弶") in html: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ強"),l1lllll_l1_+l1l11l1ll_l1_,url,145,l1l111_l1_ (u"ࠩࠪ弸"),l1l111_l1_ (u"ࠪࠫ弹"),l1l111_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ强"))
		if l1l111_l1_ (u"ࠬࠨࡴࡪࡶ࡯ࡩࠧࡀࠢใ๊สส๊ࠦวๅฬื฾๏๊ࠢࠨ弻") in html: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭弼"),l1lllll_l1_+l1lllllll_l1_,url+l1l111_l1_ (u"ࠧ࠰ࡲ࡯ࡥࡾࡲࡩࡴࡶࡶࠫ弽"),144)
		if l1l111_l1_ (u"ࠨࠤࡷ࡭ࡹࡲࡥࠣ࠼ࠥห้็๊ะ์๋๋ฬะࠢࠨ弾") in html: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ弿"),l1lllll_l1_+l1l11l1l1_l1_,url+l1l111_l1_ (u"ࠪ࠳ࡻ࡯ࡤࡦࡱࡶࠫ彀"),144)
		if l1l111_l1_ (u"ࠫࠧࡺࡩࡵ࡮ࡨࠦ࠿ࠨวๅไ้์ฬะࠢࠨ彁") in html: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ彂"),l1lllll_l1_+l111l1ll1l1l_l1_,url+l1l111_l1_ (u"࠭࠯ࡤࡪࡤࡲࡳ࡫࡬ࡴࠩ彃"),144)
		if l1l111_l1_ (u"ࠧࠣࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤࡖࡩࡦࡸࡣࡩࠤࠪ彄") in html: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ彅"),l1lllll_l1_+l1l11l1ll_l1_,url,145,l1l111_l1_ (u"ࠩࠪ彆"),l1l111_l1_ (u"ࠪࠫ彇"),l1l111_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ彈"))
		if l1l111_l1_ (u"ࠬࠨࡴࡪࡶ࡯ࡩࠧࡀࠢࡑ࡮ࡤࡽࡱ࡯ࡳࡵࡵࠥࠫ彉") in html: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭彊"),l1lllll_l1_+l1lllllll_l1_,url+l1l111_l1_ (u"ࠧ࠰ࡲ࡯ࡥࡾࡲࡩࡴࡶࡶࠫ彋"),144)
		if l1l111_l1_ (u"ࠨࠤࡷ࡭ࡹࡲࡥࠣ࠼࡚ࠥ࡮ࡪࡥࡰࡵࠥࠫ彌") in html: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ彍"),l1lllll_l1_+l1l11l1l1_l1_,url+l1l111_l1_ (u"ࠪ࠳ࡻ࡯ࡤࡦࡱࡶࠫ彎"),144)
		if l1l111_l1_ (u"ࠫࠧࡺࡩࡵ࡮ࡨࠦ࠿ࠨࡃࡩࡣࡱࡲࡪࡲࡳࠣࠩ彏") in html: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ彐"),l1lllll_l1_+l111l1ll1l1l_l1_,url+l1l111_l1_ (u"࠭࠯ࡤࡪࡤࡲࡳ࡫࡬ࡴࠩ彑"),144)
		addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ归"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ当"),l1l111_l1_ (u"ࠩࠪ彔"),9999)
	if l1l111_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺࠩ录") in url:
		dd = l1llll1lll_l1_[l1l111_l1_ (u"ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭彖")][l1l111_l1_ (u"ࠬࡺࡷࡰࡅࡲࡰࡺࡳ࡮ࡔࡧࡤࡶࡨ࡮ࡒࡦࡵࡸࡰࡹࡹࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ彗")][l1l111_l1_ (u"࠭ࡰࡳ࡫ࡰࡥࡷࡿࡃࡰࡰࡷࡩࡳࡺࡳࠨ彘")][l1l111_l1_ (u"ࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭彙")][l1l111_l1_ (u"ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪ彚")]
		l111l1ll111l_l1_ = 0
		for i in range(len(dd)):
			if l1l111_l1_ (u"ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ彛") in list(dd[i].keys()):
				l111l1ll1111_l1_ = dd[i][l1l111_l1_ (u"ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩ彜")]
				length = len(str(l111l1ll1111_l1_))
				if length>l111l1ll111l_l1_:
					l111l1ll111l_l1_ = length
					l111l1ll1l11_l1_ = l111l1ll1111_l1_
		if l111l1ll111l_l1_==0: return
	elif l1l111_l1_ (u"ࠫࠫࡲࡩࡴࡶࡀࠫ彝") in url or l1l111_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭ࡅ࡫ࡦࡻࡀࠫ彞") in url or l1l111_l1_ (u"࠭࠯ࡣࡴࡲࡻࡸ࡫࠿࡬ࡧࡼࡁࠬ彟") in url or l1l111_l1_ (u"ࠧࡤࡶࡲ࡯ࡪࡴ࠽ࠨ彠") in url or l1l111_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩࠩ彡") in url or url==l111l1_l1_:
		l111ll11l111_l1_ = []
		l111ll11l111_l1_.append(l1l111_l1_ (u"ࠤࡦࡧࡠ࠭࡯࡯ࡔࡨࡷࡵࡵ࡮ࡴࡧࡕࡩࡨ࡫ࡩࡷࡧࡧࡇࡴࡳ࡭ࡢࡰࡧࡷࠬࡣ࡛࠱࡟࡞ࠫࡦࡶࡰࡦࡰࡧࡇࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡋࡷࡩࡲࡹࡁࡤࡶ࡬ࡳࡳ࠭࡝࡜ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡊࡶࡨࡱࡸ࠭࡝࡜࠲ࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࠨ形"))
		l111ll11l111_l1_.append(l1l111_l1_ (u"ࠥࡧࡨࡡࠧࡰࡰࡕࡩࡸࡶ࡯࡯ࡵࡨࡖࡪࡩࡥࡪࡸࡨࡨࡆࡩࡴࡪࡱࡱࡷࠬࡣ࡛࠱࡟࡞ࠫࡦࡶࡰࡦࡰࡧࡇࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡋࡷࡩࡲࡹࡁࡤࡶ࡬ࡳࡳ࠭࡝࡜ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡊࡶࡨࡱࡸ࠭࡝ࠣ彣"))
		l111ll11l111_l1_.append(l1l111_l1_ (u"ࠦࡨࡩ࡛࠲࡟࡞ࠫࡷ࡫ࡳࡱࡱࡱࡷࡪ࠭࡝࡜ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡄࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡆࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࠨ࡟ࠥ彤"))
		l111ll11l111_l1_.append(l1l111_l1_ (u"ࠧࡩࡣ࡜࠳ࡠ࡟ࠬࡸࡥࡴࡲࡲࡲࡸ࡫ࠧ࡞࡝ࠪࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡅࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠭ࡧࡳ࡫ࡧࡇࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࠩࡠ࡟ࠬ࡯ࡴࡦ࡯ࡶࠫࡢࠨ彥"))
		l111ll11l111_l1_.append(l1l111_l1_ (u"ࠨࡣࡤ࡝࠴ࡡࡠ࠭ࡲࡦࡵࡳࡳࡳࡹࡥࠨ࡟࡞ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡆࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡࠧࡱ࡮ࡤࡽࡱ࡯ࡳࡵࡘ࡬ࡨࡪࡵࡌࡪࡵࡷࡇࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࠩࡠࠦ彦"))
		l111ll11l111_l1_.append(l1l111_l1_ (u"ࠢࡤࡥ࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜ࠩࡷࡻࡴࡉ࡯࡭ࡷࡰࡲࡇࡸ࡯ࡸࡵࡨࡖࡪࡹࡵ࡭ࡶࡶࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡶࡤࡦࡸ࠭࡝࡜࠯࠴ࡡࡠ࠭ࡥࡹࡲࡤࡲࡩࡧࡢ࡭ࡧࡗࡥࡧࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝ࠣ彧"))
		l111ll11l111_l1_.append(l1l111_l1_ (u"ࠣࡥࡦ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝ࠪࡸࡼࡵࡃࡰ࡮ࡸࡱࡳࡈࡲࡰࡹࡶࡩࡗ࡫ࡳࡶ࡮ࡷࡷࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡷࡥࡧࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡴࡢࡤࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟࡞ࠫࡷ࡯ࡣࡩࡉࡵ࡭ࡩࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞ࠤ彨"))
		l111ll11l111_l1_.append(l1l111_l1_ (u"ࠤࡦࡧࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞ࠫࡹࡽ࡯ࡄࡱ࡯ࡹࡲࡴࡗࡢࡶࡦ࡬ࡓ࡫ࡸࡵࡔࡨࡷࡺࡲࡴࡴࠩࡠ࡟ࠬࡶ࡬ࡢࡻ࡯࡭ࡸࡺࠧ࡞࡝ࠪࡴࡱࡧࡹ࡭࡫ࡶࡸࠬࡣࠢ彩"))
		l111l1lll11l_l1_,l111l1ll1l11_l1_ = l111l1l1llll_l1_(l1llll1lll_l1_,l1l111_l1_ (u"ࠪࠫ彪"),l111ll11l111_l1_)
	if not l111l1ll1l11_l1_:
		try:
			dd = l1llll1lll_l1_[l1l111_l1_ (u"ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭彫")][l1l111_l1_ (u"ࠬࡺࡷࡰࡅࡲࡰࡺࡳ࡮ࡃࡴࡲࡻࡸ࡫ࡒࡦࡵࡸࡰࡹࡹࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ彬")][l1l111_l1_ (u"࠭ࡴࡢࡤࡶࠫ彭")]
			l1llll111l11_l1_ = l1l111_l1_ (u"ࠧ࠰ࡸ࡬ࡨࡪࡵࡳࠨ彮") in url or l1l111_l1_ (u"ࠨ࠱ࡳࡰࡦࡿ࡬ࡪࡵࡷࡷࠬ彯") in url or l1l111_l1_ (u"ࠩ࠲ࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬ彰") in url
			l111ll1111l1_l1_ = l1l111_l1_ (u"ࠪࠦࡹ࡯ࡴ࡭ࡧࠥ࠾ࠧอไโ์า๎ํํวหࠤࠪ影") in html or l1l111_l1_ (u"ࠫࠧࡺࡩࡵ࡮ࡨࠦ࠿ࠨโ้ษษ้ࠥอไหึ฽๎้ࠨࠧ彲") in html or l1l111_l1_ (u"ࠬࠨࡴࡪࡶ࡯ࡩࠧࡀࠢศๆๅ๊ํอสࠣࠩ彳") in html
			l111ll11111l_l1_ = l1l111_l1_ (u"࠭ࠢࡵ࡫ࡷࡰࡪࠨ࠺ࠣࡘ࡬ࡨࡪࡵࡳࠣࠩ彴") in html or l1l111_l1_ (u"ࠧࠣࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤࡓࡰࡦࡿ࡬ࡪࡵࡷࡷࠧ࠭彵") in html or l1l111_l1_ (u"ࠨࠤࡷ࡭ࡹࡲࡥࠣ࠼ࠥࡇ࡭ࡧ࡮࡯ࡧ࡯ࡷࠧ࠭彶") in html
			if l1llll111l11_l1_ and (l111ll1111l1_l1_ or l111ll11111l_l1_):
				for l1l111lll1_l1_ in range(len(dd)):
					if l1l111_l1_ (u"ࠩࡷࡥࡧࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ彷") not in list(dd[l1l111lll1_l1_].keys()): continue
					l111l1llll1l_l1_ = dd[l1l111lll1_l1_][l1l111_l1_ (u"ࠪࡸࡦࡨࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ彸")]
					try: l111l1lll111_l1_ = l111l1llll1l_l1_[l1l111_l1_ (u"ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬ役")][l1l111_l1_ (u"ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫ彺")][l1l111_l1_ (u"࠭ࡳࡶࡤࡐࡩࡳࡻࠧ彻")][l1l111_l1_ (u"ࠧࡤࡪࡤࡲࡳ࡫࡬ࡔࡷࡥࡑࡪࡴࡵࡓࡧࡱࡨࡪࡸࡥࡳࠩ彼")][l1l111_l1_ (u"ࠨࡥࡲࡲࡹ࡫࡮ࡵࡖࡼࡴࡪ࡙ࡵࡣࡏࡨࡲࡺࡏࡴࡦ࡯ࡶࠫ彽")][l1l111lll1_l1_]
					except: l111l1lll111_l1_ = l111l1llll1l_l1_
					try: l1ll1ll_l1_ = l111l1lll111_l1_[l1l111_l1_ (u"ࠩࡨࡲࡩࡶ࡯ࡪࡰࡷࠫ彾")][l1l111_l1_ (u"ࠪࡧࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬ彿")][l1l111_l1_ (u"ࠫࡼ࡫ࡢࡄࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩ往")][l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩ征")]
					except: continue
					if   l1l111_l1_ (u"࠭࠯ࡷ࡫ࡧࡩࡴࡹࠧ徂")		in l1ll1ll_l1_	and l1l111_l1_ (u"ࠧ࠰ࡸ࡬ࡨࡪࡵࡳࠨ徃")		in url: l111l1llll1l_l1_ = dd[l1l111lll1_l1_] ; break
					elif l1l111_l1_ (u"ࠨ࠱ࡳࡰࡦࡿ࡬ࡪࡵࡷࡷࠬ径")	in l1ll1ll_l1_	and l1l111_l1_ (u"ࠩ࠲ࡴࡱࡧࡹ࡭࡫ࡶࡸࡸ࠭待")	in url: l111l1llll1l_l1_ = dd[l1l111lll1_l1_] ; break
					elif l1l111_l1_ (u"ࠪ࠳ࡨ࡮ࡡ࡯ࡰࡨࡰࡸ࠭徆")	in l1ll1ll_l1_	and l1l111_l1_ (u"ࠫ࠴ࡩࡨࡢࡰࡱࡩࡱࡹࠧ徇")		in url: l111l1llll1l_l1_ = dd[l1l111lll1_l1_] ; break
					else: l111l1llll1l_l1_ = dd[0]
			elif l1l111_l1_ (u"ࠬࡨࡰ࠾ࠩ很") in url: l111l1llll1l_l1_ = dd[index]
			else: l111l1llll1l_l1_ = dd[0]
			l111l1ll1l11_l1_ = l111l1llll1l_l1_[l1l111_l1_ (u"࠭ࡴࡢࡤࡕࡩࡳࡪࡥࡳࡧࡵࠫ徉")][l1l111_l1_ (u"ࠧࡤࡱࡱࡸࡪࡴࡴࠨ徊")]
		except: pass
	if not l111l1ll1l11_l1_: return
	l111ll11l111_l1_ = []
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠣࡨࡩ࡟ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࡮ࡴࡴࠩ࡫ࡱࡨࡪࡾࠩ࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡳࡩࡧ࡯ࡪࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࡠ࠭ࡥࡹࡲࡤࡲࡩ࡫ࡤࡔࡪࡨࡰ࡫ࡉ࡯࡯ࡶࡨࡲࡹࡹࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡮ࡺࡥ࡮ࡵࠪࡡࠧ律"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠤࡩࡪࡠ࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࡯࡮ࡵࠪ࡬ࡲࡩ࡫ࡸࠪ࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡴࡪࡨࡰ࡫ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡩࡱࡵ࡭ࡿࡵ࡮ࡵࡣ࡯ࡑࡴࡼࡩࡦࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡭ࡹ࡫࡭ࡴࠩࡠࠦ後"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠥࡪ࡫ࡡࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡࡩ࡯ࡶࠫ࡭ࡳࡪࡥࡹࠫࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡵ࡫ࡩࡱ࡬ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣ࡛ࠨࡪࡲࡶ࡮ࢀ࡯࡯ࡶࡤࡰࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡩࡵࡧࡰࡷࠬࡣࠢ徍"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠦ࡫࡬࡛ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛ࡪࡰࡷࠬ࡮ࡴࡤࡦࡺࠬࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩࡶ࡬ࡪࡲࡦࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝࡜ࠩࡪࡶ࡮ࡪࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡮ࡺࡥ࡮ࡵࠪࡡࠧ徎"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠧ࡬ࡦ࡜ࠩࡶࡩࡨࡺࡩࡰࡰࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࡫ࡱࡸ࠭࡯࡮ࡥࡧࡻ࠭ࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪࡷ࡭࡫࡬ࡧࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡢࡴࡧࡷࠬࡣࠢ徏"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠨࡦࡧ࡝ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࡬ࡲࡹ࠮ࡩ࡯ࡦࡨࡼ࠮ࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫ࡭ࡵࡲࡪࡼࡲࡲࡹࡧ࡬ࡄࡣࡵࡨࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡢࡴࡧࡷࠬࡣࠢ徐"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠢࡧࡨ࡞ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࡭ࡳࡺࠨࡪࡰࡧࡩࡽ࠯࡝࡜ࠩࡵ࡭ࡨ࡮ࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣࠢ徑"))
	if l1l111_l1_ (u"ࠨࡸ࡬ࡩࡼࡃࠧ徒") not in url: l111ll11l111_l1_.append(l1l111_l1_ (u"ࠤࡩࡪࡠ࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡵࡸࡦࡒ࡫࡮ࡶࠩࡠ࡟ࠬࡩࡨࡢࡰࡱࡩࡱ࡙ࡵࡣࡏࡨࡲࡺࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡘࡾࡶࡥࡔࡷࡥࡑࡪࡴࡵࡊࡶࡨࡱࡸ࠭࡝ࠣ従"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠥࡪ࡫ࡡࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡳࡩࡧ࡯ࡪࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࡠ࠭ࡥࡹࡲࡤࡲࡩ࡫ࡤࡔࡪࡨࡰ࡫ࡉ࡯࡯ࡶࡨࡲࡹࡹࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡮ࡺࡥ࡮ࡵࠪࡡࠧ徔"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠦ࡫࡬࡛ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡴࡪࡨࡰ࡫ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡨࡴ࡬ࡨࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡬ࡸࡪࡳࡳࠨ࡟ࠥ徕"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠧ࡬ࡦ࡜ࠩࡶࡩࡨࡺࡩࡰࡰࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡲ࡯ࡥࡾࡲࡩࡴࡶ࡙࡭ࡩ࡫࡯ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࠨ徖"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠨࡦࡧ࡝ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩࡪࡶ࡮ࡪࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡮ࡺࡥ࡮ࡵࠪࡡࠧ得"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠢࡧࡨ࡞ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟ࠥ徘"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠣࡨࡩ࡟ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࠨ徙"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠤࡩࡪࡠ࠭ࡲࡪࡥ࡫ࡋࡷ࡯ࡤࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞ࠤ徚"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠥࡪ࡫ࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠࠦ徛"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠦ࡫࡬ࠢ徜"))
	l11l11l11l1_l1_ = l111l1lllll_l1_(l1l111_l1_ (u"ࡺ࠭ใๅࠢๅ์ฬฬๅࠡษ็ฮูเ๊ๅࠩ徝"))
	l11l11l11ll_l1_ = l111l1lllll_l1_(l1l111_l1_ (u"ࡻࠧไๆࠣห้็๊ะ์๋๋ฬะࠧ從"))
	l111l1ll1lll_l1_ = l111l1lllll_l1_(l1l111_l1_ (u"ࡵࠨๅ็ࠤฬ๊โ็๊สฮࠬ徟"))
	l1l11lll1l1l_l1_ = [l11l11l11l1_l1_,l11l11l11ll_l1_,l111l1ll1lll_l1_,l1l111_l1_ (u"ࠨࡃ࡯ࡰࠥࡶ࡬ࡢࡻ࡯࡭ࡸࡺࡳࠨ徠"),l1l111_l1_ (u"ࠩࡄࡰࡱࠦࡶࡪࡦࡨࡳࡸ࠭御"),l1l111_l1_ (u"ࠪࡅࡱࡲࠠࡤࡪࡤࡲࡳ࡫࡬ࡴࠩ徢")]
	l111l1lll1ll_l1_,l111l1lll111_l1_ = l111l1l1llll_l1_(l111l1ll1l11_l1_,index,l111ll11l111_l1_)
	if l1l111_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ徣") in str(type(l111l1lll111_l1_)) and any(value in str(l111l1lll111_l1_[0]) for value in l1l11lll1l1l_l1_): del l111l1lll111_l1_[0]
	for index2 in range(len(l111l1lll111_l1_)):
		l111ll11l111_l1_ = []
		l111ll11l111_l1_.append(l1l111_l1_ (u"ࠧ࡭ࡧ࡜࡫ࡱࡨࡪࡾ࠲࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡨࡰࡴ࡬ࡾࡴࡴࡴࡢ࡮ࡆࡥࡷࡪࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡪࡨࡥࡩ࡫ࡲࠨ࡟ࠥ徤"))
		l111ll11l111_l1_.append(l1l111_l1_ (u"ࠨࡧࡨ࡝࡬ࡲࡩ࡫ࡸ࠳࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡨࡦࡣࡧࡩࡷ࠭࡝ࠣ徥"))
		l111ll11l111_l1_.append(l1l111_l1_ (u"ࠢࡨࡩ࡞࡭ࡳࡪࡥࡹ࠴ࡠ࡟ࠬ࡮࡯ࡳ࡫ࡽࡳࡳࡺࡡ࡭ࡅࡤࡶࡩࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡩࡧࡤࡨࡪࡸࠧ࡞ࠤ徦"))
		l111ll11l111_l1_.append(l1l111_l1_ (u"ࠣࡩࡪ࡟࡮ࡴࡤࡦࡺ࠵ࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝ࠣ徧"))
		l111ll11l111_l1_.append(l1l111_l1_ (u"ࠤࡪ࡫ࡠ࡯࡮ࡥࡧࡻ࠶ࡢࡡࠧࡳ࡫ࡦ࡬ࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࠧ徨"))
		l111ll11l111_l1_.append(l1l111_l1_ (u"ࠥ࡫࡬ࡡࡩ࡯ࡦࡨࡼ࠷ࡣ࡛ࠨࡴ࡬ࡧ࡭ࡏࡴࡦ࡯ࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟ࠥ復"))
		l111ll11l111_l1_.append(l1l111_l1_ (u"ࠦ࡬࡭࡛ࡪࡰࡧࡩࡽ࠸࡝࡜ࠩࡪࡥࡲ࡫ࡃࡢࡴࡧࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡩࡤࡱࡪ࠭࡝ࠣ循"))
		l111ll11l111_l1_.append(l1l111_l1_ (u"ࠧ࡭ࡧ࡜࡫ࡱࡨࡪࡾ࠲࡞ࠤ徫"))
		l111l1lll11l_l1_,item = l111l1l1llll_l1_(l111l1lll111_l1_,index2,l111ll11l111_l1_)
		l111ll11l11l_l1_(item,url,str(index2))
		if l111l1lll11l_l1_==l1l111_l1_ (u"࠭࠴ࠨ徬"):
			try:
				hh = item[l1l111_l1_ (u"ࠧࡴࡪࡨࡰ࡫ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ徭")][l1l111_l1_ (u"ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩ微")][l1l111_l1_ (u"ࠩ࡫ࡳࡷ࡯ࡺࡰࡰࡷࡥࡱࡓ࡯ࡷ࡫ࡨࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩ徯")][l1l111_l1_ (u"ࠪ࡭ࡹ࡫࡭ࡴࠩ徰")]
				for l111ll1l111l_l1_ in range(len(hh)):
					l1l1l1111lll_l1_ = hh[l111ll1l111l_l1_]
					l111ll11l11l_l1_(l1l1l1111lll_l1_)
			except: pass
	l111lll1ll_l1_ = False
	if l1l111_l1_ (u"ࠫࡻ࡯ࡥࡸ࠿ࠪ徱") not in url and l111l1lll1ll_l1_==l1l111_l1_ (u"ࠬ࠾ࠧ徲"): l111lll1ll_l1_ = True
	if l1l111_l1_ (u"࠭࠺࠻࠼ࠪ徳") in l1l11llll_l1_: l111lll111ll_l1_,key,l111l1ll11l1_l1_,l111ll1llll1_l1_,token,l111ll1ll1ll_l1_ = l1l11llll_l1_.split(l1l111_l1_ (u"ࠧ࠻࠼࠽ࠫ徴"))
	else: l111lll111ll_l1_,key,l111l1ll11l1_l1_,l111ll1llll1_l1_,token,l111ll1ll1ll_l1_ = l1l111_l1_ (u"ࠨࠩ徵"),l1l111_l1_ (u"ࠩࠪ徶"),l1l111_l1_ (u"ࠪࠫ德"),l1l111_l1_ (u"ࠫࠬ徸"),l1l111_l1_ (u"ࠬ࠭徹"),l1l111_l1_ (u"࠭ࠧ徺")
	l1lllll1_l1_,l111l1l1ll_l1_ = l1l111_l1_ (u"ࠧࠨ徻"),l1l111_l1_ (u"ࠨࠩ徼")
	if menuItemsLIST:
		l111ll111111_l1_ = str(menuItemsLIST[-1][1])
		if   l1lllll_l1_+l1l111_l1_ (u"ࠩࡆࡌࡓࡒࠧ徽") in l111ll111111_l1_: l111l1l1ll_l1_ = l1l111_l1_ (u"ࠪࡇࡍࡇࡎࡏࡇࡏࡗࠬ徾")
		elif l1lllll_l1_+l1l111_l1_ (u"࡚࡙ࠫࡅࡓࠩ徿") in l111ll111111_l1_: l111l1l1ll_l1_ = l1l111_l1_ (u"ࠬࡉࡈࡂࡐࡑࡉࡑ࡙ࠧ忀")
		elif l1lllll_l1_+l1l111_l1_ (u"࠭ࡌࡊࡕࡗࠫ忁") in l111ll111111_l1_: l111l1l1ll_l1_ = l1l111_l1_ (u"ࠧࡑࡎࡄ࡝ࡑࡏࡓࡕࡕࠪ忂")
	if l1l111_l1_ (u"ࠨࠤࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡴࠤࠪ心") in html and l1l111_l1_ (u"ࠩࠩࡰ࡮ࡹࡴ࠾ࠩ忄") not in url and not l111lll1ll_l1_ and l1l111_l1_ (u"ࠪࡷ࡭࡫࡬ࡧࡡ࡬ࡨࠬ必") not in url:
		l1lllll1_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡨࡲࡰࡹࡶࡩࡤࡧࡪࡢࡺࡂࡧࡹࡵ࡫ࡦࡰࡀࠫ忆")+l111l1ll11l1_l1_
	elif l1l111_l1_ (u"ࠬࠨࡴࡰ࡭ࡨࡲࠧ࠭忇") in html and l1l111_l1_ (u"࠭ࡢࡱ࠿ࠪ忈") not in url and l1l111_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾ࠭忉") in url or l1l111_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡀ࡭ࡨࡽࡂ࠭忊") in url:
		l1lllll1_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡽࡴࡻࡴࡶࡤࡨ࡭࠴ࡼ࠱࠰ࡵࡨࡥࡷࡩࡨࡀ࡭ࡨࡽࡂ࠭忋")+key
	elif l1l111_l1_ (u"ࠪࠦࡹࡵ࡫ࡦࡰࠥࠫ忌") in html and l1l111_l1_ (u"ࠫࡧࡶ࠽ࠨ忍") not in url:
		l1lllll1_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡹࡰࡷࡷࡹࡧ࡫ࡩ࠰ࡸ࠴࠳ࡧࡸ࡯ࡸࡵࡨࡃࡰ࡫ࡹ࠾ࠩ忎")+key
	if l1lllll1_l1_: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭忏"),l1lllll_l1_+l1l111_l1_ (u"ࠧึใะอࠥษฮา๋ࠪ忐"),l1lllll1_l1_,144,l111l1l1ll_l1_,l1l111_l1_ (u"ࠨࠩ忑"),l1l11llll_l1_)
	return
def l111l1l1llll_l1_(l1l1l1l111ll_l1_,l1l1l1l1l1ll_l1_,l111ll11lll1_l1_):
	l1llll1lll_l1_ = l1l1l1l111ll_l1_
	l111l1ll1l11_l1_,index = l1l1l1l111ll_l1_,l1l1l1l1l1ll_l1_
	l111l1lll111_l1_,index2 = l1l1l1l111ll_l1_,l1l1l1l1l1ll_l1_
	item,l111l1lllll1_l1_ = l1l1l1l111ll_l1_,l1l1l1l1l1ll_l1_
	count = len(l111ll11lll1_l1_)
	for l1l111lll1_l1_ in range(count):
		try:
			out = eval(l111ll11lll1_l1_[l1l111lll1_l1_])
			return str(l1l111lll1_l1_+1),out
		except: pass
	return l1l111_l1_ (u"ࠩࠪ忒"),l1l111_l1_ (u"ࠪࠫ忓")
def l111llll1111_l1_(item):
	try: l111ll1lll11_l1_ = list(item.keys())[0]
	except: return False,l1l111_l1_ (u"ࠫࠬ忔"),l1l111_l1_ (u"ࠬ࠭忕"),l1l111_l1_ (u"࠭ࠧ忖"),l1l111_l1_ (u"ࠧࠨ志"),l1l111_l1_ (u"ࠨࠩ忘"),l1l111_l1_ (u"ࠩࠪ忙"),l1l111_l1_ (u"ࠪࠫ忚")
	succeeded,title,l1ll1ll_l1_,l1ll1l_l1_,count,l1l1lll111_l1_,l111lll11l1l_l1_,l111ll1ll1l1_l1_ = False,l1l111_l1_ (u"ࠫࠬ忛"),l1l111_l1_ (u"ࠬ࠭応"),l1l111_l1_ (u"࠭ࠧ忝"),l1l111_l1_ (u"ࠧࠨ忞"),l1l111_l1_ (u"ࠨࠩ忟"),l1l111_l1_ (u"ࠩࠪ忠"),l1l111_l1_ (u"ࠪࠫ忡")
	l111l1lllll1_l1_ = item[l111ll1lll11_l1_]
	l111ll11l111_l1_ = []
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡻ࡮ࡱ࡮ࡤࡽࡦࡨ࡬ࡦࡖࡨࡼࡹ࠭࡝࡜ࠩࡶ࡭ࡲࡶ࡬ࡦࡖࡨࡼࡹ࠭࡝ࠣ忢"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡦࡰࡴࡰࡥࡹࡺࡥࡥࡖ࡬ࡸࡱ࡫ࠧ࡞࡝ࠪࡷ࡮ࡳࡰ࡭ࡧࡗࡩࡽࡺࠧ࡞ࠤ忣"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡵ࡫ࡷࡰࡪ࠭࡝࡜ࠩࡶ࡭ࡲࡶ࡬ࡦࡖࡨࡼࡹ࠭࡝ࠣ忤"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡶ࡬ࡸࡱ࡫ࠧ࡞࡝ࠪࡶࡺࡴࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡧࡻࡸࠬࡣࠢ忥"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷࡩࡽࡺࠧ࡞࡝ࠪࡷ࡮ࡳࡰ࡭ࡧࡗࡩࡽࡺࠧ࡞ࠤ忦"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡸࡪࡾࡴࠨ࡟࡞ࠫࡷࡻ࡮ࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡶࡨࡼࡹ࠭࡝ࠣ忧"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡯ࡴ࡭ࡧࠪࡡࠧ忨"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠦ࡮ࡺࡥ࡮࡝ࠪࡸ࡮ࡺ࡬ࡦࠩࡠࠦ忩"))
	l111l1lll11l_l1_,title = l111l1l1llll_l1_(item,l111l1lllll1_l1_,l111ll11l111_l1_)
	l111ll11l111_l1_ = []
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡴࡪࡶ࡯ࡩࠬࡣ࡛ࠨࡴࡸࡲࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡴࡡࡷ࡫ࡪࡥࡹ࡯࡯࡯ࡇࡱࡨࡵࡵࡩ࡯ࡶࠪࡡࡠ࠭ࡣࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ࡟࡞ࠫࡼ࡫ࡢࡄࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩࡠ࡟ࠬࡻࡲ࡭ࠩࡠࠦ忪"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧ࡯ࡣࡹ࡭࡬ࡧࡴࡪࡱࡱࡉࡳࡪࡰࡰ࡫ࡱࡸࠬࡣ࡛ࠨࡥࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡷࡦࡤࡆࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫࡢࡡࠧࡶࡴ࡯ࠫࡢࠨ快"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡧࡱࡨࡵࡵࡩ࡯ࡶࠪࡡࡠ࠭ࡣࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ࡟࡞ࠫࡼ࡫ࡢࡄࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩࡠ࡟ࠬࡻࡲ࡭ࠩࡠࠦ忬"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠣ࡫ࡷࡩࡲࡡࠧࡦࡰࡧࡴࡴ࡯࡮ࡵࠩࡠ࡟ࠬࡩ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ࡞࡝ࠪࡻࡪࡨࡃࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ࡟࡞ࠫࡺࡸ࡬ࠨ࡟ࠥ忭"))
	l111l1lll11l_l1_,l1ll1ll_l1_ = l111l1l1llll_l1_(item,l111l1lllll1_l1_,l111ll11l111_l1_)
	l111ll11l111_l1_ = []
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱ࠭࡝࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡻࡲ࡭ࠩࡠࠦ忮"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡶࠫࡢࡡ࠰࡞࡝ࠪࡹࡷࡲࠧ࡞ࠤ忯"))
	l111l1lll11l_l1_,l1ll1l_l1_ = l111l1l1llll_l1_(item,l111l1lllll1_l1_,l111ll11l111_l1_)
	l111ll11l111_l1_ = []
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡼࡩࡥࡧࡲࡇࡴࡻ࡮ࡵࠩࡠࠦ忰"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡶࡪࡦࡨࡳࡈࡵࡵ࡯ࡶࡗࡩࡽࡺࠧ࡞࡝ࠪࡶࡺࡴࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡧࡻࡸࠬࡣࠢ忱"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡒࡺࡪࡸ࡬ࡢࡻࡶࠫࡢࡡ࠰࡞࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡕࡶࡦࡴ࡯ࡥࡾࡈ࡯ࡵࡶࡲࡱࡕࡧ࡮ࡦ࡮ࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡵࡧࡻࡸࠬࡣ࡛ࠨࡴࡸࡲࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡥࡹࡶࠪࡡࠧ忲"))
	l111l1lll11l_l1_,count = l111l1l1llll_l1_(item,l111l1lllll1_l1_,l111ll11l111_l1_)
	l111ll11l111_l1_ = []
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨ࡮ࡨࡲ࡬ࡺࡨࡕࡧࡻࡸࠬࡣ࡛ࠨࡵ࡬ࡱࡵࡲࡥࡕࡧࡻࡸࠬࡣࠢ忳"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡔࡼࡥࡳ࡮ࡤࡽࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡐࡸࡨࡶࡱࡧࡹࡕ࡫ࡰࡩࡘࡺࡡࡵࡷࡶࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡶࡨࡼࡹ࠭࡝࡜ࠩࡶ࡭ࡲࡶ࡬ࡦࡖࡨࡼࡹ࠭࡝ࠣ忴"))
	l111ll11l111_l1_.append(l1l111_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡕࡶࡦࡴ࡯ࡥࡾࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡑࡹࡩࡷࡲࡡࡺࡖ࡬ࡱࡪ࡙ࡴࡢࡶࡸࡷࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡷࡩࡽࡺࠧ࡞࡝ࠪࡶࡺࡴࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡧࡻࡸࠬࡣࠢ念"))
	l111l1lll11l_l1_,l1l1lll111_l1_ = l111l1l1llll_l1_(item,l111l1lllll1_l1_,l111ll11l111_l1_)
	if l1l111_l1_ (u"ࠪࡐࡎ࡜ࡅࠨ忶") in l1l1lll111_l1_: l1l1lll111_l1_,l111lll11l1l_l1_ = l1l111_l1_ (u"ࠫࠬ忷"),l1l111_l1_ (u"ࠬࡒࡉࡗࡇ࠽ࠤࠥ࠭忸")
	if l1l111_l1_ (u"࠭ๅษษืีࠬ忹") in l1l1lll111_l1_: l1l1lll111_l1_,l111lll11l1l_l1_ = l1l111_l1_ (u"ࠧࠨ忺"),l1l111_l1_ (u"ࠨࡎࡌ࡚ࡊࡀࠠࠡࠩ忻")
	if l1l111_l1_ (u"ࠩࡥࡥࡩ࡭ࡥࡴࠩ忼") in list(l111l1lllll1_l1_.keys()):
		l111lll1l11l_l1_ = str(l111l1lllll1_l1_[l1l111_l1_ (u"ࠪࡦࡦࡪࡧࡦࡵࠪ忽")])
		if l1l111_l1_ (u"ࠫࡋࡸࡥࡦࠢࡺ࡭ࡹ࡮ࠠࡂࡦࡶࠫ忾") in l111lll1l11l_l1_: l111ll1ll1l1_l1_ = l1l111_l1_ (u"ࠬࠪ࠺ࠨ忿")
		if l1l111_l1_ (u"࠭ࡌࡊࡘࡈࠤࡓࡕࡗࠨ怀") in l111lll1l11l_l1_: l111lll11l1l_l1_ = l1l111_l1_ (u"ࠧࡍࡋ࡙ࡉ࠿ࠦࠠࠨ态")
		if l1l111_l1_ (u"ࠨࡄࡸࡽࠬ怂") in l111lll1l11l_l1_ or l1l111_l1_ (u"ࠩࡕࡩࡳࡺࠧ怃") in l111lll1l11l_l1_: l111ll1ll1l1_l1_ = l1l111_l1_ (u"ࠪࠨࠩࡀࠧ怄")
		if l111l1lllll_l1_(l1l111_l1_ (u"ࡹ๋ࠬศศึิࠫ怅")) in l111lll1l11l_l1_: l111lll11l1l_l1_ = l1l111_l1_ (u"ࠬࡒࡉࡗࡇ࠽ࠤࠥ࠭怆")
		if l111l1lllll_l1_(l1l111_l1_ (u"ࡻࠧีำสลࠬ怇")) in l111lll1l11l_l1_: l111ll1ll1l1_l1_ = l1l111_l1_ (u"ࠧࠥࠦ࠽ࠫ怈")
		if l111l1lllll_l1_(l1l111_l1_ (u"ࡶࠩสืฯฬฬศำࠪ怉")) in l111lll1l11l_l1_: l111ll1ll1l1_l1_ = l1l111_l1_ (u"ࠩࠧࠨ࠿࠭怊")
		if l111l1lllll_l1_(l1l111_l1_ (u"ࡸࠫส฿ไศ่สฮࠬ怋")) in l111lll1l11l_l1_: l111ll1ll1l1_l1_ = l1l111_l1_ (u"ࠫࠩࡀࠧ怌")
	l1ll1ll_l1_ = escapeUNICODE(l1ll1ll_l1_)
	if l1ll1ll_l1_ and l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ怍") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
	l1ll1l_l1_ = l1ll1l_l1_.split(l1l111_l1_ (u"࠭࠿ࠨ怎"))[0]
	if  l1ll1l_l1_ and l1l111_l1_ (u"ࠧࡩࡶࡷࡴࠬ怏") not in l1ll1l_l1_: l1ll1l_l1_ = l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺ࠨ怐")+l1ll1l_l1_
	title = escapeUNICODE(title)
	if l111ll1ll1l1_l1_: title = l111ll1ll1l1_l1_+l1l111_l1_ (u"ࠩࠣࠤࠬ怑")+title
	l1l1lll111_l1_ = l1l1lll111_l1_.replace(l1l111_l1_ (u"ࠪ࠰ࠬ怒"),l1l111_l1_ (u"ࠫࠬ怓"))
	count = count.replace(l1l111_l1_ (u"ࠬ࠲ࠧ怔"),l1l111_l1_ (u"࠭ࠧ怕"))
	count = re.findall(l1l111_l1_ (u"ࠧ࡝ࡦ࠮ࠫ怖"),count)
	if count: count = count[0]
	else: count = l1l111_l1_ (u"ࠨࠩ怗")
	return True,title,l1ll1ll_l1_,l1ll1l_l1_,count,l1l1lll111_l1_,l111lll11l1l_l1_,l111ll1ll1l1_l1_
def l111ll11l11l_l1_(item,url=l1l111_l1_ (u"ࠩࠪ怘"),index=l1l111_l1_ (u"ࠪࠫ怙")):
	succeeded,title,l1ll1ll_l1_,l1ll1l_l1_,count,l1l1lll111_l1_,l111lll11l1l_l1_,l111ll1ll1l1_l1_ = l111llll1111_l1_(item)
	if not succeeded: return
	elif l1l111_l1_ (u"ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡌࡸࡪࡳࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ怚") in str(item): return
	elif l1l111_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࡕࡿࡶࡓࡧࡱࡨࡪࡸࡥࡳࠩ怛") in str(item): return
	elif not l1ll1ll_l1_ and l1l111_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࠬ怜") in url: return
	elif title and not l1ll1ll_l1_ and (l1l111_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾ࠭思") in url or l1l111_l1_ (u"ࠨࡪࡲࡶ࡮ࢀ࡯࡯ࡶࡤࡰࡒࡵࡶࡪࡧࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ怞") in str(item) or url==l111l1_l1_):
		title = l1l111_l1_ (u"ࠩࡀࡁࡂࠦࠧ怟")+title+l1l111_l1_ (u"ࠪࠤࡂࡃ࠽ࠨ怠")
		addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ怡"),l1lllll_l1_+title,l1l111_l1_ (u"ࠬ࠭怢"),9999)
	elif title and l1l111_l1_ (u"࠭࡭ࡦࡵࡶࡥ࡬࡫ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ怣") in str(item):
		addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ怤"),l1lllll_l1_+title,l1l111_l1_ (u"ࠨࠩ急"),9999)
	elif l1l111_l1_ (u"ࠩ࠲ࡪࡪ࡫ࡤ࠰ࡶࡵࡩࡳࡪࡩ࡯ࡩࠪ怦") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ性"),l1lllll_l1_+title,l1ll1ll_l1_,144,l1ll1l_l1_,index)
	elif not title: return
	elif l111lll11l1l_l1_: addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯ࡶࡦࠩ怨"),l1lllll_l1_+l111lll11l1l_l1_+title,l1ll1ll_l1_,143,l1ll1l_l1_)
	elif l1l111_l1_ (u"ࠬࡽࡡࡵࡥ࡫ࡃࡻࡃࠧ怩") in l1ll1ll_l1_ or l1l111_l1_ (u"࠭࠯ࡴࡪࡲࡶࡹࡹ࠯ࠨ怪") in l1ll1ll_l1_:
		if l1l111_l1_ (u"ࠧࠧ࡮࡬ࡷࡹࡃࠧ怫") in l1ll1ll_l1_ and l1l111_l1_ (u"ࠨ࡫ࡱࡨࡪࡾ࠽ࠨ怬") not in l1ll1ll_l1_:
			l111lll1111l_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠩࠩࡰ࡮ࡹࡴ࠾ࠩ怭"),1)[1]
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡵࡲࡡࡺ࡮࡬ࡷࡹࡅ࡬ࡪࡵࡷࡁࠬ怮")+l111lll1111l_l1_
			addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ怯"),l1lllll_l1_+l1l111_l1_ (u"ࠬࡒࡉࡔࡖࠪ怰")+count+l1l111_l1_ (u"࠭࠺ࠡࠢࠪ怱")+title,l1ll1ll_l1_,144,l1ll1l_l1_)
		else:
			l1ll1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠧࠧ࡮࡬ࡷࡹࡃࠧ怲"),1)[0]
			addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ怳"),l1lllll_l1_+title,l1ll1ll_l1_,143,l1ll1l_l1_,l1l1lll111_l1_)
	else:
		type = l1l111_l1_ (u"ࠩࠪ怴")
		if not l1ll1ll_l1_: l1ll1ll_l1_ = url
		elif not any(value in l1ll1ll_l1_ for value in [l1l111_l1_ (u"ࠪ࠳ࡻ࡯ࡤࡦࡱࡶࠫ怵"),l1l111_l1_ (u"ࠫ࠴ࡶ࡬ࡢࡻ࡯࡭ࡸࡺࡳࠨ怶"),l1l111_l1_ (u"ࠬ࠵ࡣࡩࡣࡱࡲࡪࡲࡳࠨ怷"),l1l111_l1_ (u"࠭࠯ࡧࡧࡤࡸࡺࡸࡥࡥࠩ怸"),l1l111_l1_ (u"ࠧࡴࡵࡀࠫ怹"),l1l111_l1_ (u"ࠨࡤࡳࡁࠬ怺")]):
			if l1l111_l1_ (u"ࠩ࠲ࡧ࡭ࡧ࡮࡯ࡧ࡯࠳ࠬ总")	in l1ll1ll_l1_ or l1l111_l1_ (u"ࠪ࠳ࡨ࠵ࠧ怼") in l1ll1ll_l1_: type = l1l111_l1_ (u"ࠫࡈࡎࡎࡍࠩ怽")+count+l1l111_l1_ (u"ࠬࡀࠠࠡࠩ怾")
			if l1l111_l1_ (u"࠭࠯ࡶࡵࡨࡶ࠴࠭怿") in l1ll1ll_l1_: type = l1l111_l1_ (u"ࠧࡖࡕࡈࡖࠬ恀")+count+l1l111_l1_ (u"ࠨ࠼ࠣࠤࠬ恁")
			index,l111l1llll11_l1_ = l1l111_l1_ (u"ࠩࠪ恂"),l1l111_l1_ (u"ࠪࠫ恃")
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ恄"),l1lllll_l1_+type+title,l1ll1ll_l1_,144,l1ll1l_l1_,index)
	return
def l111ll1ll11l_l1_(url,data=l1l111_l1_ (u"ࠬ࠭恅"),request=l1l111_l1_ (u"࠭ࠧ恆")):
	global settings
	if not data: data = settings.getSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡩࡧࡴࡢࠩ恇"))
	if request==l1l111_l1_ (u"ࠨࠩ恈"): request = l1l111_l1_ (u"ࠩࡼࡸࡎࡴࡩࡵ࡫ࡤࡰࡉࡧࡴࡢࠩ恉")
	l11ll11lll_l1_ = l1l1ll11l_l1_()
	l1ll1ll1l_l1_ = {l1l111_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ恊"):l11ll11lll_l1_,l1l111_l1_ (u"ࠫࡈࡵ࡯࡬࡫ࡨࠫ恋"):l1l111_l1_ (u"ࠬࡖࡒࡆࡈࡀ࡬ࡱࡃࡡࡳࠩ恌")}
	if l1l111_l1_ (u"࠭࠺࠻࠼ࠪ恍") in data: l111lll111ll_l1_,key,l111l1ll11l1_l1_,l111ll1llll1_l1_,token,l111ll1ll1ll_l1_ = data.split(l1l111_l1_ (u"ࠧ࠻࠼࠽ࠫ恎"))
	else: l111lll111ll_l1_,key,l111l1ll11l1_l1_,l111ll1llll1_l1_,token,l111ll1ll1ll_l1_ = l1l111_l1_ (u"ࠨࠩ恏"),l1l111_l1_ (u"ࠩࠪ恐"),l1l111_l1_ (u"ࠪࠫ恑"),l1l111_l1_ (u"ࠫࠬ恒"),l1l111_l1_ (u"ࠬ࠭恓"),l1l111_l1_ (u"࠭ࠧ恔")
	if l1l111_l1_ (u"ࠧࡨࡷ࡬ࡨࡪࡅ࡫ࡦࡻࡀࠫ恕") in url:
		l1l11llll_l1_ = {}
		l1l11llll_l1_[l1l111_l1_ (u"ࠨࡥࡲࡲࡹ࡫ࡸࡵࠩ恖")] = {l1l111_l1_ (u"ࠤࡦࡰ࡮࡫࡮ࡵࠤ恗"):{l1l111_l1_ (u"ࠥ࡬ࡱࠨ恘"):l1l111_l1_ (u"ࠦࡦࡸࠢ恙"),l1l111_l1_ (u"ࠧࡩ࡬ࡪࡧࡱࡸࡓࡧ࡭ࡦࠤ恚"):l1l111_l1_ (u"ࠨࡗࡆࡄࠥ恛"),l1l111_l1_ (u"ࠢࡤ࡮࡬ࡩࡳࡺࡖࡦࡴࡶ࡭ࡴࡴࠢ恜"):l111ll1llll1_l1_}}
		l1l11llll_l1_ = str(l1l11llll_l1_)
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠨࡒࡒࡗ࡙࠭恝"),url,l1l11llll_l1_,l1ll1ll1l_l1_,True,True,l1l111_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡋࡊ࡚࡟ࡑࡃࡊࡉࡤࡊࡁࡕࡃ࠰࠵ࡸࡺࠧ恞"))
	elif l1l111_l1_ (u"ࠪ࡯ࡪࡿ࠽ࠨ恟") in url and l111lll111ll_l1_:
		l1l11llll_l1_ = {l1l111_l1_ (u"ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࠪ恠"):token}
		l1l11llll_l1_[l1l111_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡼࡹ࠭恡")] = {l1l111_l1_ (u"ࠨࡣ࡭࡫ࡨࡲࡹࠨ恢"):{l1l111_l1_ (u"ࠢࡷ࡫ࡶ࡭ࡹࡵࡲࡅࡣࡷࡥࠧ恣"):l111lll111ll_l1_,l1l111_l1_ (u"ࠣࡥ࡯࡭ࡪࡴࡴࡏࡣࡰࡩࠧ恤"):l1l111_l1_ (u"ࠤ࡚ࡉࡇࠨ恥"),l1l111_l1_ (u"ࠥࡧࡱ࡯ࡥ࡯ࡶ࡙ࡩࡷࡹࡩࡰࡰࠥ恦"):l111ll1llll1_l1_}}
		l1l11llll_l1_ = str(l1l11llll_l1_)
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠫࡕࡕࡓࡕࠩ恧"),url,l1l11llll_l1_,l1ll1ll1l_l1_,True,True,l1l111_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡇࡆࡖࡢࡔࡆࡍࡅࡠࡆࡄࡘࡆ࠳࠲࡯ࡦࠪ恨"))
	elif l1l111_l1_ (u"࠭ࡣࡵࡱ࡮ࡩࡳࡃࠧ恩") in url and l111ll1ll1ll_l1_:
		l1ll1ll1l_l1_.update({l1l111_l1_ (u"࡙ࠧ࠯࡜ࡳࡺ࡚ࡵࡣࡧ࠰ࡇࡱ࡯ࡥ࡯ࡶ࠰ࡒࡦࡳࡥࠨ恪"):l1l111_l1_ (u"ࠨ࠳ࠪ恫"),l1l111_l1_ (u"࡛ࠩ࠱࡞ࡵࡵࡕࡷࡥࡩ࠲ࡉ࡬ࡪࡧࡱࡸ࠲࡜ࡥࡳࡵ࡬ࡳࡳ࠭恬"):l111ll1llll1_l1_})
		l1ll1ll1l_l1_.update({l1l111_l1_ (u"ࠪࡇࡴࡵ࡫ࡪࡧࠪ恭"):l1l111_l1_ (u"࡛ࠫࡏࡓࡊࡖࡒࡖࡤࡏࡎࡇࡑ࠴ࡣࡑࡏࡖࡆ࠿ࠪ恮")+l111ll1ll1ll_l1_})
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ息"),url,l1l111_l1_ (u"࠭ࠧ恰"),l1ll1ll1l_l1_,l1l111_l1_ (u"ࠧࠨ恱"),l1l111_l1_ (u"ࠨࠩ恲"),l1l111_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡋࡊ࡚࡟ࡑࡃࡊࡉࡤࡊࡁࡕࡃ࠰࠷ࡷࡪࠧ恳"))
	else:
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ恴"),url,l1l111_l1_ (u"ࠫࠬ恵"),l1ll1ll1l_l1_,l1l111_l1_ (u"ࠬ࠭恶"),l1l111_l1_ (u"࠭ࠧ恷"),l1l111_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡉࡈࡘࡤࡖࡁࡈࡇࡢࡈࡆ࡚ࡁ࠮࠶ࡷ࡬ࠬ恸"))
	html = response.content
	tmp = re.findall(l1l111_l1_ (u"ࠨࠤ࡬ࡲࡳ࡫ࡲࡵࡷࡥࡩࡆࡶࡩࡌࡧࡼࠦ࠳࠰࠿ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ恹"),html,re.DOTALL|re.I)
	if tmp: key = tmp[0]
	tmp = re.findall(l1l111_l1_ (u"ࠩࠥࡧࡻ࡫ࡲࠣ࠰࠭ࡃࠧࡼࡡ࡭ࡷࡨࠦ࠳࠰࠿ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ恺"),html,re.DOTALL|re.I)
	if tmp: l111ll1llll1_l1_ = tmp[0]
	tmp = re.findall(l1l111_l1_ (u"ࠪࠦࡹࡵ࡫ࡦࡰࠥ࠲࠯ࡅࠢࠩ࠰࠭ࡃ࠮ࠨࠧ恻"),html,re.DOTALL|re.I)
	if tmp: token = tmp[0]
	tmp = re.findall(l1l111_l1_ (u"ࠫࠧࡼࡩࡴ࡫ࡷࡳࡷࡊࡡࡵࡣࠥ࠲࠯ࡅࠢࠩ࠰࠭ࡃ࠮ࠨࠧ恼"),html,re.DOTALL|re.I)
	if tmp: l111lll111ll_l1_ = tmp[0]
	tmp = re.findall(l1l111_l1_ (u"ࠬࠨࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࠧ࠴ࠪࡀࠤࠫ࠲࠯ࡅࠩࠣࠩ恽"),html,re.DOTALL|re.I)
	if tmp: l111l1ll11l1_l1_ = tmp[0]
	cookies = response.cookies
	if l1l111_l1_ (u"࠭ࡖࡊࡕࡌࡘࡔࡘ࡟ࡊࡐࡉࡓ࠶ࡥࡌࡊࡘࡈࠫ恾") in list(cookies.keys()): l111ll1ll1ll_l1_ = cookies[l1l111_l1_ (u"ࠧࡗࡋࡖࡍ࡙ࡕࡒࡠࡋࡑࡊࡔ࠷࡟ࡍࡋ࡙ࡉࠬ恿")]
	data = l111lll111ll_l1_+l1l111_l1_ (u"ࠨ࠼࠽࠾ࠬ悀")+key+l1l111_l1_ (u"ࠩ࠽࠾࠿࠭悁")+l111l1ll11l1_l1_+l1l111_l1_ (u"ࠪ࠾࠿ࡀࠧ悂")+l111ll1llll1_l1_+l1l111_l1_ (u"ࠫ࠿ࡀ࠺ࠨ悃")+token+l1l111_l1_ (u"ࠬࡀ࠺࠻ࠩ悄")+l111ll1ll1ll_l1_
	if request==l1l111_l1_ (u"࠭ࡹࡵࡋࡱ࡭ࡹ࡯ࡡ࡭ࡆࡤࡸࡦ࠭悅") and l1l111_l1_ (u"ࠧࡺࡶࡌࡲ࡮ࡺࡩࡢ࡮ࡇࡥࡹࡧࠧ悆") in html:
		l11ll111l1_l1_ = re.findall(l1l111_l1_ (u"ࠨࡹ࡬ࡲࡩࡵࡷ࡝࡝ࠥࡽࡹࡏ࡮ࡪࡶ࡬ࡥࡱࡊࡡࡵࡣࠥࡠࡢࠦ࠽ࠡࠪࡾ࠲࠯ࡅࡽࠪ࠽ࠪ悇"),html,re.DOTALL)
		if not l11ll111l1_l1_: l11ll111l1_l1_ = re.findall(l1l111_l1_ (u"ࠩࡹࡥࡷࠦࡹࡵࡋࡱ࡭ࡹ࡯ࡡ࡭ࡆࡤࡸࡦࠦ࠽ࠡࠪࡾ࠲࠯ࡅࡽࠪ࠽ࠪ悈"),html,re.DOTALL)
		l111lll1l111_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠪࡷࡹࡸࠧ悉"),l11ll111l1_l1_[0])
	elif request==l1l111_l1_ (u"ࠫࡾࡺࡉ࡯࡫ࡷ࡭ࡦࡲࡇࡶ࡫ࡧࡩࡉࡧࡴࡢࠩ悊") and l1l111_l1_ (u"ࠬࡿࡴࡊࡰ࡬ࡸ࡮ࡧ࡬ࡈࡷ࡬ࡨࡪࡊࡡࡵࡣࠪ悋") in html:
		l11ll111l1_l1_ = re.findall(l1l111_l1_ (u"࠭ࡶࡢࡴࠣࡽࡹࡏ࡮ࡪࡶ࡬ࡥࡱࡍࡵࡪࡦࡨࡈࡦࡺࡡࠡ࠿ࠣࠬࢀ࠴ࠪࡀࡿࠬ࠿ࠬ悌"),html,re.DOTALL)
		l111lll1l111_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠧࡴࡶࡵࠫ悍"),l11ll111l1_l1_[0])
	elif l1l111_l1_ (u"ࠨ࠾࠲ࡷࡨࡸࡩࡱࡶࡁࠫ悎") not in html: l111lll1l111_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠩࡶࡸࡷ࠭悏"),html)
	else: l111lll1l111_l1_ = l1l111_l1_ (u"ࠪࠫ悐")
	settings.setSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡦࡤࡸࡦ࠭悑"),data)
	return html,l111lll1l111_l1_,data
def l111lll1ll11_l1_(url):
	search = l1llll1_l1_()
	if not search: return
	search = search.replace(l1l111_l1_ (u"ࠬࠦࠧ悒"),l1l111_l1_ (u"࠭ࠫࠨ悓"))
	l1lllll1_l1_ = url+l1l111_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨࡀࡳࡸࡩࡷࡿ࠽ࠨ悔")+search
	ITEMS(l1lllll1_l1_)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search:
		search = l1llll1_l1_()
		if not search: return
	search = search.replace(l1l111_l1_ (u"ࠨࠢࠪ悕"),l1l111_l1_ (u"ࠩ࠮ࠫ悖"))
	l1lllll1_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡷ࡫ࡳࡶ࡮ࡷࡷࡄࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࡁࠬ悗")+search
	if not l11_l1_:
		if l1l111_l1_ (u"ࠫࡤ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡖࡊࡆࡈࡓࡘࡥࠧ悘") in options: l111ll1l11ll_l1_ = l1l111_l1_ (u"ࠬࠬࡳࡱ࠿ࡈ࡫ࡎࡗࡁࡒࠧ࠵࠹࠸ࡊࠥ࠳࠷࠶ࡈࠬ悙")
		elif l1l111_l1_ (u"࠭࡟࡚ࡑࡘࡘ࡚ࡈࡅ࠮ࡒࡏࡅ࡞ࡒࡉࡔࡖࡖࡣࠬ悚") in options: l111ll1l11ll_l1_ = l1l111_l1_ (u"ࠧࠧࡵࡳࡁࡊ࡭ࡉࡒࡃࡺࠩ࠷࠻࠳ࡅࠧ࠵࠹࠸ࡊࠧ悛")
		elif l1l111_l1_ (u"ࠨࡡ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡇࡍࡇࡎࡏࡇࡏࡗࡤ࠭悜") in options: l111ll1l11ll_l1_ = l1l111_l1_ (u"ࠩࠩࡷࡵࡃࡅࡨࡋࡔࡅ࡬ࠫ࠲࠶࠵ࡇࠩ࠷࠻࠳ࡅࠩ悝")
		l1llllll_l1_ = l1lllll1_l1_+l111ll1l11ll_l1_
	else:
		l111ll1l11l1_l1_,l111ll111l1l_l1_,l1lllllll_l1_ = [],[],l1l111_l1_ (u"ࠪࠫ悞")
		l111ll111lll_l1_ = [l1l111_l1_ (u"ࠫอี่็ࠢอีฯ๐ศࠨ悟"),l1l111_l1_ (u"ࠬะัห์หࠤาูศࠡ็าํࠥอไึๆฬࠫ悠"),l1l111_l1_ (u"࠭สาฬํฬࠥำำษࠢอหึ๐ฮࠡษ็ฮา๋๊ๅࠩ悡"),l1l111_l1_ (u"ࠧหำอ๎อࠦอิสࠣ฽ิีࠠศๆุ่ฬํฯศฬࠪ悢"),l1l111_l1_ (u"ࠨฬิฮ๏ฮࠠฮีหࠤฬ๊สใ์ํ้ࠬ患")]
		l111lll11lll_l1_ = [l1l111_l1_ (u"ࠩࠪ悤"),l1l111_l1_ (u"ࠪࠪࡸࡶ࠽ࡄࡃࡄࠩ࠷࠻࠳ࡅࠩ悥"),l1l111_l1_ (u"ࠫࠫࡹࡰ࠾ࡅࡄࡍࠪ࠸࠵࠴ࡆࠪ悦"),l1l111_l1_ (u"ࠬࠬࡳࡱ࠿ࡆࡅࡒࠫ࠲࠶࠵ࡇࠫ悧"),l1l111_l1_ (u"࠭ࠦࡴࡲࡀࡇࡆࡋࠥ࠳࠷࠶ࡈࠬ您")]
		l111lll1l1l1_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥ๐่ห์๋ฬࠥ࠳ࠠศะอีࠥอไหำอ๎อ࠭悩"),l111ll111lll_l1_)
		if l111lll1l1l1_l1_ == -1: return
		l111ll1l1111_l1_ = l111lll11lll_l1_[l111lll1l1l1_l1_]
		html,c,data = l111ll1ll11l_l1_(l1lllll1_l1_+l111ll1l1111_l1_)
		if c:
			d = c[l1l111_l1_ (u"ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪ悪")][l1l111_l1_ (u"ࠩࡷࡻࡴࡉ࡯࡭ࡷࡰࡲࡘ࡫ࡡࡳࡥ࡫ࡖࡪࡹࡵ࡭ࡶࡶࡖࡪࡴࡤࡦࡴࡨࡶࠬ悫")][l1l111_l1_ (u"ࠪࡴࡷ࡯࡭ࡢࡴࡼࡇࡴࡴࡴࡦࡰࡷࡷࠬ悬")][l1l111_l1_ (u"ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ悭")][l1l111_l1_ (u"ࠬࡹࡵࡣࡏࡨࡲࡺ࠭悮")][l1l111_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭࡙ࡵࡣࡏࡨࡲࡺࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ悯")][l1l111_l1_ (u"ࠧࡨࡴࡲࡹࡵࡹࠧ悰")]
			for l111ll111l11_l1_ in range(len(d)):
				group = d[l111ll111l11_l1_][l1l111_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡇ࡫࡯ࡸࡪࡸࡇࡳࡱࡸࡴࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭悱")][l1l111_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࡵࠪ悲")]
				for l111lll1ll1l_l1_ in range(len(group)):
					l111l1lllll1_l1_ = group[l111lll1ll1l_l1_][l1l111_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࡉ࡭ࡱࡺࡥࡳࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ悳")]
					if l1l111_l1_ (u"ࠫࡳࡧࡶࡪࡩࡤࡸ࡮ࡵ࡮ࡆࡰࡧࡴࡴ࡯࡮ࡵࠩ悴") in list(l111l1lllll1_l1_.keys()):
						l1ll1ll_l1_ = l111l1lllll1_l1_[l1l111_l1_ (u"ࠬࡴࡡࡷ࡫ࡪࡥࡹ࡯࡯࡯ࡇࡱࡨࡵࡵࡩ࡯ࡶࠪ悵")][l1l111_l1_ (u"࠭ࡣࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ悶")][l1l111_l1_ (u"ࠧࡸࡧࡥࡇࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬ悷")][l1l111_l1_ (u"ࠨࡷࡵࡰࠬ悸")]
						l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠩ࡟ࡹ࠵࠶࠲࠷ࠩ悹"),l1l111_l1_ (u"ࠪࠪࠬ悺"))
						title = l111l1lllll1_l1_[l1l111_l1_ (u"ࠫࡹࡵ࡯࡭ࡶ࡬ࡴࠬ悻")]
						title = title.replace(l1l111_l1_ (u"ࠬอไษฯฮࠤ฾์ࠠࠨ悼"),l1l111_l1_ (u"࠭ࠧ悽"))
						if l1l111_l1_ (u"ࠧฦิส่ฮࠦวๅใ็ฮึ࠭悾") in title: continue
						if l1l111_l1_ (u"ࠨไสส๊ฯࠠหึ฽๎้࠭悿") in title:
							title = l1l111_l1_ (u"ࠩฯ๎ิࠦไๅ็ึุ่๊วหࠢࠪ惀")+title
							l1lllllll_l1_ = title
							l111lllll_l1_ = l1ll1ll_l1_
						if l1l111_l1_ (u"ࠪฮึะ๊ษࠢะือ࠭惁") in title: continue
						title = title.replace(l1l111_l1_ (u"ࠫࡘ࡫ࡡࡳࡥ࡫ࠤ࡫ࡵࡲࠡࠩ惂"),l1l111_l1_ (u"ࠬ࠭惃"))
						if l1l111_l1_ (u"࠭ࡒࡦ࡯ࡲࡺࡪ࠭惄") in title: continue
						if l1l111_l1_ (u"ࠧࡑ࡮ࡤࡽࡱ࡯ࡳࡵࠩ情") in title:
							title = l1l111_l1_ (u"ࠨฮํำ๊ࠥไๆี็ื้อสࠡࠩ惆")+title
							l1lllllll_l1_ = title
							l111lllll_l1_ = l1ll1ll_l1_
						if l1l111_l1_ (u"ࠩࡖࡳࡷࡺࠠࡣࡻࠪ惇") in title: continue
						l111ll1l11l1_l1_.append(escapeUNICODE(title))
						l111ll111l1l_l1_.append(l1ll1ll_l1_)
		if not l1lllllll_l1_: l111lll11ll1_l1_ = l1l111_l1_ (u"ࠪࠫ惈")
		else:
			l111ll1l11l1_l1_ = [l1l111_l1_ (u"ࠫอี่็ࠢไ่ฯืࠧ惉"),l1lllllll_l1_]+l111ll1l11l1_l1_
			l111ll111l1l_l1_ = [l1l111_l1_ (u"ࠬ࠭惊"),l111lllll_l1_]+l111ll111l1l_l1_
			l111lll1llll_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"࠭ๅ้ไ฼ࠤ๏๎ส๋๊หࠤ࠲ࠦวฯฬิࠤฬ๊แๅฬิࠫ惋"),l111ll1l11l1_l1_)
			if l111lll1llll_l1_ == -1: return
			l111lll11ll1_l1_ = l111ll111l1l_l1_[l111lll1llll_l1_]
		if l111lll11ll1_l1_: l1llllll_l1_ = l111l1_l1_+l111lll11ll1_l1_
		elif l111ll1l1111_l1_: l1llllll_l1_ = l1lllll1_l1_+l111ll1l1111_l1_
		else: l1llllll_l1_ = l1lllll1_l1_
	ITEMS(l1llllll_l1_)
	return
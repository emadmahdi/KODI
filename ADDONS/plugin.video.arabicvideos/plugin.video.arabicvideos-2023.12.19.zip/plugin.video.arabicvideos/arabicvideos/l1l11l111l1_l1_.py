# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
import xbmc,re,sys,xbmcaddon,random,os,xbmcvfs,time,pickle,zlib,xbmcgui,xbmcplugin,sqlite3,traceback
l1ll1_l1_ = l1l111_l1_ (u"ࠨࡎࡌࡆࡘࡕࡎࡆࠩㆍ")
l1l1l1l1ll1_l1_ = xbmcaddon.Addon().getAddonInfo(l1l111_l1_ (u"ࠩࡳࡥࡹ࡮ࠧㆎ"))
l1l111ll11l_l1_ = os.path.join(l1l1l1l1ll1_l1_,l1l111_l1_ (u"ࠪࡴࡦࡩ࡫ࡢࡩࡨࡷࠬ㆏"))
sys.path.append(l1l111ll11l_l1_)
l1l1l11ll11_l1_ = xbmc.getInfoLabel(l1l111_l1_ (u"ࠦࡘࡿࡳࡵࡧࡰ࠲ࡇࡻࡩ࡭ࡦ࡙ࡩࡷࡹࡩࡰࡰࠥ㆐"))
kodi_version = re.findall(l1l111_l1_ (u"ࠬ࠮࡜ࡥ࡞ࡧࡠ࠳ࡢࡤࠪࠩ㆑"),l1l1l11ll11_l1_,re.DOTALL)
kodi_version = float(kodi_version[0])
l1l1ll11ll1_l1_ = xbmc.Player
l1l1l1llll1_l1_ = xbmcgui.WindowXMLDialog
PY2 = kodi_version<19
PY3 = kodi_version>18.99
if PY3:
	l1ll111l111_l1_ = xbmc.LOGINFO
	ltr,rtl = l1l111_l1_ (u"ࡻࠧ࡝ࡷ࠵࠴࠷ࡧࠧ㆒"),l1l111_l1_ (u"ࡵࠨ࡞ࡸ࠶࠵࠸ࡢࠨ㆓")
	l1l1l1111ll_l1_ = xbmcvfs.translatePath(l1l111_l1_ (u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳ࡹ࡫࡭ࡱࠩ㆔"))
	from urllib.parse import unquote as _1l1l11l1ll_l1_
else:
	l1ll111l111_l1_ = xbmc.LOGNOTICE
	ltr,rtl = l1l111_l1_ (u"ࡷࠪࡠࡺ࠸࠰࠳ࡣࠪ㆕").encode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㆖")),l1l111_l1_ (u"ࡹࠬࡢࡵ࠳࠲࠵ࡦࠬ㆗").encode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㆘"))
	l1l1l1111ll_l1_ = xbmc.translatePath(l1l111_l1_ (u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱ࡷࡩࡲࡶࠧ㆙"))
	from urllib import unquote as _1l1l11l1ll_l1_
l1l1ll1llll_l1_ = 60
l1l1l11111l_l1_ = 60*l1l1ll1llll_l1_
l1l11llll1l_l1_ = 24*l1l1l11111l_l1_
l1l1ll1l1l1_l1_ = 30*l1l11llll1l_l1_
l1ll1ll1_l1_ = 3*l1l11llll1l_l1_
l1ll111l11l_l1_ = 12*l1l1ll1l1l1_l1_
addon_id = sys.argv[0].split(l1l111_l1_ (u"ࠧ࠰ࠩ㆚"))[2]
addon_handle = int(sys.argv[1])
addon_path = sys.argv[2]
l1l1llll111_l1_ = addon_id.split(l1l111_l1_ (u"ࠨ࠰ࠪ㆛"))[2]
l1l11l1l1l1_l1_ = xbmc.getInfoLabel(l1l111_l1_ (u"ࠩࡖࡽࡸࡺࡥ࡮࠰ࡄࡨࡩࡵ࡮ࡗࡧࡵࡷ࡮ࡵ࡮ࠩࠩ㆜")+addon_id+l1l111_l1_ (u"ࠪ࠭ࠬ㆝"))
addoncachefolder = os.path.join(l1l1l1111ll_l1_,addon_id)
main_dbfile = os.path.join(addoncachefolder,l1l111_l1_ (u"ࠫࡲࡧࡩ࡯ࡦࡤࡸࡦ࠴ࡤࡣࠩ㆞"))
l1l1l11l111_l1_ = os.path.join(addoncachefolder,l1l111_l1_ (u"ࠬࡲࡡࡴࡶࡹ࡭ࡩ࡫࡯ࡴ࠰ࡧࡥࡹ࠭㆟"))
now = int(time.time())
settings = xbmcaddon.Addon(id=addon_id)
def l1ll11ll1_l1_(url):
	if l1l111_l1_ (u"࠭࠽ࠨㆠ") in url:
		if l1l111_l1_ (u"ࠧࡀࠩㆡ") in url: l1lllll1_l1_,filters = url.split(l1l111_l1_ (u"ࠨࡁࠪㆢ"),1)
		else: l1lllll1_l1_,filters = l1l111_l1_ (u"ࠩࠪㆣ"),url
		filters = filters.split(l1l111_l1_ (u"ࠪࠪࠬㆤ"))
		l1l11llll_l1_ = {}
		for filter in filters:
			key,value = filter.split(l1l111_l1_ (u"ࠫࡂ࠭ㆥ"),1)
			l1l11llll_l1_[key] = value
	else: l1lllll1_l1_,l1l11llll_l1_ = url,{}
	return l1lllll1_l1_,l1l11llll_l1_
def l111l11_l1_(urll):
	return _1l1l11l1ll_l1_(urll)
def EXTRACT_KODI_PATH(l1l11l11111_l1_):
	l1ll111111l_l1_ = {l1l111_l1_ (u"ࠬࡺࡹࡱࡧࠪㆦ"):l1l111_l1_ (u"࠭ࠧㆧ"),l1l111_l1_ (u"ࠧ࡮ࡱࡧࡩࠬㆨ"):l1l111_l1_ (u"ࠨࠩㆩ"),l1l111_l1_ (u"ࠩࡸࡶࡱ࠭ㆪ"):l1l111_l1_ (u"ࠪࠫㆫ"),l1l111_l1_ (u"ࠫࡹ࡫ࡸࡵࠩㆬ"):l1l111_l1_ (u"ࠬ࠭ㆭ"),l1l111_l1_ (u"࠭ࡰࡢࡩࡨࠫㆮ"):l1l111_l1_ (u"ࠧࠨㆯ"),l1l111_l1_ (u"ࠨࡰࡤࡱࡪ࠭ㆰ"):l1l111_l1_ (u"ࠩࠪㆱ"),l1l111_l1_ (u"ࠪ࡭ࡲࡧࡧࡦࠩㆲ"):l1l111_l1_ (u"ࠫࠬㆳ"),l1l111_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡼࡹ࠭ㆴ"):l1l111_l1_ (u"࠭ࠧㆵ"),l1l111_l1_ (u"ࠧࡪࡰࡩࡳࡩ࡯ࡣࡵࠩㆶ"):l1l111_l1_ (u"ࠨࠩㆷ")}
	if l1l111_l1_ (u"ࠩࡂࠫㆸ") in l1l11l11111_l1_: l1l11l11111_l1_ = l1l11l11111_l1_.split(l1l111_l1_ (u"ࠪࡃࠬㆹ"),1)[1]
	l1lllll1_l1_,l1ll1111111_l1_ = l1ll11ll1_l1_(l1l11l11111_l1_)
	args = dict(list(l1ll111111l_l1_.items())+list(l1ll1111111_l1_.items()))
	l1l111ll1l1_l1_ = args[l1l111_l1_ (u"ࠫࡲࡵࡤࡦࠩㆺ")]
	l1l1l1l11l1_l1_ = l111l11_l1_(args[l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩㆻ")])
	l1l11lll1l1_l1_ = l111l11_l1_(args[l1l111_l1_ (u"࠭ࡴࡦࡺࡷࠫㆼ")])
	l1l111l11ll_l1_ = l111l11_l1_(args[l1l111_l1_ (u"ࠧࡱࡣࡪࡩࠬㆽ")])
	l1l111l11l1_l1_ = l111l11_l1_(args[l1l111_l1_ (u"ࠨࡶࡼࡴࡪ࠭ㆾ")])
	l1l11llll11_l1_ = l111l11_l1_(args[l1l111_l1_ (u"ࠩࡱࡥࡲ࡫ࠧㆿ")])
	l1l1ll1111l_l1_ = l111l11_l1_(args[l1l111_l1_ (u"ࠪ࡭ࡲࡧࡧࡦࠩ㇀")])
	l1l11lll111_l1_ = args[l1l111_l1_ (u"ࠫࡨࡵ࡮ࡵࡧࡻࡸࠬ㇁")]
	l1l1l11l11l_l1_ = l111l11_l1_(args[l1l111_l1_ (u"ࠬ࡯࡮ࡧࡱࡧ࡭ࡨࡺࠧ㇂")])
	if l1l1l11l11l_l1_: l1l1l11l11l_l1_ = eval(l1l1l11l11l_l1_)
	else: l1l1l11l11l_l1_ = {}
	if not l1l111ll1l1_l1_: l1l111l11l1_l1_ = l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㇃") ; l1l111ll1l1_l1_ = l1l111_l1_ (u"ࠧ࠳࠸࠳ࠫ㇄")
	return l1l111l11l1_l1_,l1l11llll11_l1_,l1l1l1l11l1_l1_,l1l111ll1l1_l1_,l1l1ll1111l_l1_,l1l111l11ll_l1_,l1l11lll1l1_l1_,l1l11lll111_l1_,l1l1l11l11l_l1_
def l11llll11l_l1_(l1ll1_l1_):
	l1l11lll11l_l1_ = sys._getframe(1).f_code.co_name
	if not l1ll1_l1_ or not l1l11lll11l_l1_ or l1l11lll11l_l1_==l1l111_l1_ (u"ࠨ࠾ࡰࡳࡩࡻ࡬ࡦࡀࠪ㇅"):
		return l1l111_l1_ (u"ࠩ࡞ࠤࠬ㇆")+l1l1llll111_l1_.upper()+l1l111_l1_ (u"ࠪ࠱ࠬ㇇")+l1l11l1l1l1_l1_+l1l111_l1_ (u"ࠫ࠲࠭㇈")+str(kodi_version)+l1l111_l1_ (u"ࠬࠦ࡝ࠨ㇉")
	return l1l111_l1_ (u"࠭࠮ࠡࠢࠪ㇊")+l1l11lll11l_l1_
def l11llllll1_l1_(level,message):
	if PY2: message = message.decode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㇋")).encode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭㇌"))
	l1l11l1ll11_l1_ = l1ll111l111_l1_
	lines = [l1l111_l1_ (u"ࠩࠪ㇍"),l1l111_l1_ (u"ࠪࠫ㇎")]
	if level: message = message.replace(l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ㇏"),l1l111_l1_ (u"ࠬ࠭㇐")).replace(l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ㇑"),l1l111_l1_ (u"ࠧࠨ㇒")).replace(l1l111_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㇓"),l1l111_l1_ (u"ࠩࠪ㇔"))
	else: level = l1l111_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ㇕")
	l11l1lll1l_l1_,sep,shift = l1l111_l1_ (u"ࠫࠥࠦࠠࠡࠩ㇖"),l1l111_l1_ (u"ࠬࠦࠠࠡࠩ㇗"),l1l111_l1_ (u"࠭ࠧ㇘")
	if l1l111_l1_ (u"ࠧࡆࡔࡕࡓࡗ࠭㇙") in level: l1l11l1ll11_l1_ = xbmc.LOGERROR
	if level==l1l111_l1_ (u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭㇚"):
		message = message+sep
		lines = message.split(sep)
		shift = l11l1lll1l_l1_
	elif level==l1l111_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࡡࡏࡍࡓࡋࡓࠨ㇛"):
		message = message.replace(l1l111_l1_ (u"ࠪ࠲ࠬ㇜")+sep,l1l111_l1_ (u"ࠫ࠳ࠦࠠࠨ㇝"))
		lines = message.split(sep)
		lines[0] = l1l111_l1_ (u"ࠬ࠴ࠧ㇞")+lines[0][1:]
		shift = l11l1lll1l_l1_+sep
	elif level in [l1l111_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭㇟"),l1l111_l1_ (u"ࠧࡆࡔࡕࡓࡗ࠭㇠")]: lines = message.split(l11l1lll1l_l1_)
	shift += 6*l11l1lll1l_l1_
	l1l11l1llll_l1_ = 3*l11l1lll1l_l1_
	if kodi_version>17.99: shift += 11*l1l111_l1_ (u"ࠨࠢࠪ㇡")
	l1l1ll1l111_l1_ = lines[0]
	for line in lines[1:]:
		if l1l111_l1_ (u"ࠩ࡟ࡲࠬ㇢") in line: line = line.replace(l1l111_l1_ (u"ࠪࡠࡳ࠭㇣"),l1l111_l1_ (u"ࠫࡡࡴࠧ㇤")+l11l1lll1l_l1_+l11l1lll1l_l1_)
		l1l11l1llll_l1_ += l11l1lll1l_l1_
		l1l1ll1l111_l1_ += l1l111_l1_ (u"ࠬࡢࡲࠨ㇥")+shift+l1l11l1llll_l1_+line
	l1l1ll1l111_l1_ += l1l111_l1_ (u"࠭ࠠࡠࠩ㇦")
	if l1l111_l1_ (u"ࠧࠦࠩ㇧") in l1l1ll1l111_l1_: l1l1ll1l111_l1_ = l111l11_l1_(l1l1ll1l111_l1_)
	xbmc.log(l1l1ll1l111_l1_,level=l1l11l1ll11_l1_)
	return
def l1l1llll1l1_l1_(l1ll1lll1l_l1_):
	conn = sqlite3.connect(l1ll1lll1l_l1_)
	l1llll1lll_l1_ = conn.cursor()
	l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠨࡒࡕࡅࡌࡓࡁࠡࡣࡸࡸࡴࡳࡡࡵ࡫ࡦࡣ࡮ࡴࡤࡦࡺࡀࡲࡴࡁࠧ㇨"))
	l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠩࡓࡖࡆࡍࡍࡂࠢࡩࡳࡷ࡫ࡩࡨࡰࡢ࡯ࡪࡿࡳ࠾ࡰࡲ࠿ࠬ㇩"))
	l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠪࡔࡗࡇࡇࡎࡃࠣ࡭࡬ࡴ࡯ࡳࡧࡢࡧ࡭࡫ࡣ࡬ࡡࡦࡳࡳࡹࡴࡳࡣ࡬ࡲࡹࡹ࠽ࡺࡧࡶ࠿ࠬ㇪"))
	l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠫࡕࡘࡁࡈࡏࡄࠤ࡯ࡵࡵࡳࡰࡤࡰࡤࡳ࡯ࡥࡧࡀࡓࡋࡌ࠻ࠨ㇫"))
	l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠬࡖࡒࡂࡉࡐࡅࠥࡺࡥ࡮ࡲࡢࡷࡹࡵࡲࡦ࠿ࡐࡉࡒࡕࡒ࡚࠽ࠪ㇬"))
	l1llll1lll_l1_.execute(l1l111_l1_ (u"࠭ࡐࡓࡃࡊࡑࡆࠦࡳࡺࡰࡦ࡬ࡷࡵ࡮ࡰࡷࡶࡁࡔࡌࡆ࠼ࠩ㇭"))
	conn.text_factory = str
	return conn,l1llll1lll_l1_
def l1lll1l1lll_l1_(l1ll1lll1l_l1_,table,l1l1l11lll1_l1_=None):
	try: conn,l1llll1lll_l1_ = l1l1llll1l1_l1_(l1ll1lll1l_l1_)
	except: return
	if l1l1l11lll1_l1_==None: l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠧࡅࡔࡒࡔ࡚ࠥࡁࡃࡎࡈࠤࡎࡌࠠࡆ࡚ࡌࡗ࡙࡙ࠠࠣࠩ㇮")+table+l1l111_l1_ (u"ࠨࠤࠣ࠿ࠬ㇯"))
	else:
		tt = (str(l1l1l11lll1_l1_),)
		try:
			if l1l111_l1_ (u"ࠩࠨࠫㇰ") in l1l1l11lll1_l1_: l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠪࡈࡊࡒࡅࡕࡇࠣࡊࡗࡕࡍࠡࠤࠪㇱ")+table+l1l111_l1_ (u"ࠫࠧࠦࡗࡉࡇࡕࡉࠥࡩ࡯࡭ࡷࡰࡲࠥࡲࡩ࡬ࡧࠣࡃࠥࡁࠧㇲ"),tt)
			else: l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࠦࠬㇳ")+table+l1l111_l1_ (u"࡙࠭ࠢࠡࡋࡉࡗࡋࠠࡤࡱ࡯ࡹࡲࡴࠠ࠾ࠢࡂࠤࡀ࠭ㇴ"),tt)
		except: pass
	conn.commit()
	conn.close()
	return
class l1l1ll1l1ll_l1_(): pass
class l1l1lllll11_l1_(l1l1ll1l1ll_l1_):
	def __init__(self):
		self.url = l1l111_l1_ (u"ࠧࠨㇵ")
		self.code = -99
		self.reason = l1l111_l1_ (u"ࠨࠩㇶ")
		self.content = l1l111_l1_ (u"ࠩࠪㇷ")
		self.headers = {}
		self.cookies = {}
		self.succeeded = False
def l1l1l11ll1l_l1_(type):
	if type==l1l111_l1_ (u"ࠪࡨ࡮ࡩࡴࠨㇸ"): data = {}
	elif type==l1l111_l1_ (u"ࠫࡱ࡯ࡳࡵࠩㇹ"): data = []
	elif type==l1l111_l1_ (u"ࠬࡹࡴࡳࠩㇺ"): data = l1l111_l1_ (u"࠭ࠧㇻ")
	elif type==l1l111_l1_ (u"ࠧࡪࡰࡷࠫㇼ"): data = 0
	elif type==l1l111_l1_ (u"ࠨࡴࡨࡷࡵࡵ࡮ࡴࡧࠪㇽ"): data = l1l1lllll11_l1_()
	elif not type: data = None
	else: data = None
	return data
def l1l11ll1lll_l1_(l1l1lllllll_l1_):
	from hashlib import md5
	l1l11ll1l11_l1_ = settings.getSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡻࡳࡦࡴ࠱ࡴࡷ࡯ࡶࡴࠩㇾ"))
	l1l1ll1l11l_l1_ = l1l1ll111ll_l1_(32).splitlines()
	for l1l11l11l11_l1_ in l1l1ll1l11l_l1_:
		l1l1l1ll111_l1_ = md5((l1l111_l1_ (u"ࠪ࡜࠶࠿ࠧㇿ")+l1l1lllllll_l1_+l1l111_l1_ (u"ࠫ࠶࠾࠽ࠨ㈀")+l1l11l11l11_l1_).encode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㈁"))).hexdigest()[:32]
		if l1l1l1ll111_l1_ in l1l11ll1l11_l1_:
			return True
	return False
def l1lll11l111_l1_(l1ll1lll1l_l1_,l1l1l1ll11l_l1_,table,l1l1l11lll1_l1_=None):
	data = l1l1l11ll1l_l1_(l1l1l1ll11l_l1_)
	cache = settings.getSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡦࡥࡨ࡮ࡥ࠯ࡵࡷࡥࡹࡻࡳࠨ㈂"))
	if table!=l1l111_l1_ (u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪ㈃") and l1ll1lll1l_l1_==main_dbfile:
		if cache==l1l111_l1_ (u"ࠨࡕࡗࡓࡕ࠭㈄"): return data
		l1ll11l1l1_l1_ = settings.getSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡸࡥࡧࡴࡨࡷ࡭࠴ࡳࡵࡣࡷࡹࡸ࠭㈅"))
		if l1ll11l1l1_l1_==l1l111_l1_ (u"ࠪࡖࡊࡌࡒࡆࡕࡋࡉࡉ࠭㈆"):
			l1lll1l1lll_l1_(l1ll1lll1l_l1_,table,l1l1l11lll1_l1_)
			return data
	l1ll111l1l1_l1_ = 0
	if cache==l1l111_l1_ (u"ࠫࡑࡏࡍࡊࡖࡈࡈࠬ㈇"): l1ll111l1l1_l1_ = l1l11l1l11l_l1_
	try: conn,l1llll1lll_l1_ = l1l1llll1l1_l1_(l1ll1lll1l_l1_)
	except: return data
	l1l1l111ll1_l1_ = True
	try: l1llll1lll_l1_.execute(l1l111_l1_ (u"࡙ࠬࡅࡍࡇࡆࡘࠥ࠰ࠠࡇࡔࡒࡑࠥࠨࠧ㈈")+table+l1l111_l1_ (u"࠭ࠢࠡࡎࡌࡑࡎ࡚ࠠ࠲ࠢ࠾ࠫ㈉"))
	except: l1l1l111ll1_l1_ = False
	if l1l1l111ll1_l1_:
		if l1ll111l1l1_l1_: l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥࠨࠧ㈊")+table+l1l111_l1_ (u"ࠨࠤ࡛ࠣࡍࡋࡒࡆࠢࡨࡼࡵ࡯ࡲࡺࡀࠪ㈋")+str(now+l1ll111l1l1_l1_)+l1l111_l1_ (u"ࠩࠣ࠿ࠬ㈌"))
		conn.commit()
		l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠪࡈࡊࡒࡅࡕࡇࠣࡊࡗࡕࡍࠡࠤࠪ㈍")+table+l1l111_l1_ (u"ࠫࠧࠦࡗࡉࡇࡕࡉࠥ࡫ࡸࡱ࡫ࡵࡽࡁ࠭㈎")+str(now)+l1l111_l1_ (u"ࠬࠦ࠻ࠨ㈏"))
		conn.commit()
		if l1l1l11lll1_l1_:
			tt = (str(l1l1l11lll1_l1_),)
			l1llll1lll_l1_.execute(l1l111_l1_ (u"࠭ࡓࡆࡎࡈࡇ࡙ࠦࡤࡢࡶࡤࠤࡋࡘࡏࡎࠢࠥࠫ㈐")+table+l1l111_l1_ (u"࡚ࠧࠣࠢࡌࡊࡘࡅࠡࡥࡲࡰࡺࡳ࡮ࠡ࠿ࠣࡃࠥࡁࠧ㈑"),tt)
			l1l1l1111l1_l1_ = l1llll1lll_l1_.fetchall()
			if l1l1l1111l1_l1_:
				try:
					text = zlib.decompress(l1l1l1111l1_l1_[0][0])
					data = pickle.loads(text)
				except: pass
		else:
			l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠨࡕࡈࡐࡊࡉࡔࠡࡥࡲࡰࡺࡳ࡮࠭ࡦࡤࡸࡦࠦࡆࡓࡑࡐࠤࠧ࠭㈒")+table+l1l111_l1_ (u"ࠩࠥࠤࡀ࠭㈓"))
			l1l1l1111l1_l1_ = l1llll1lll_l1_.fetchall()
			if l1l1l1111l1_l1_:
				data,l1l1llll11l_l1_ = {},[]
				for l1l1ll11lll_l1_,l1l11llll_l1_ in l1l1l1111l1_l1_:
					l1ll1ll11l_l1_ = zlib.decompress(l1l11llll_l1_)
					l1l11llll_l1_ = pickle.loads(l1ll1ll11l_l1_)
					data[l1l1ll11lll_l1_] = l1l11llll_l1_
					l1l1llll11l_l1_.append(l1l1ll11lll_l1_)
				if l1l1llll11l_l1_:
					data[l1l111_l1_ (u"ࠪࡣࡤ࡙ࡅࡒࡗࡈࡒࡈࡋࡄࡠࡅࡒࡐ࡚ࡓࡎࡔࡡࡢࠫ㈔")] = l1l1llll11l_l1_
					if l1l1l1ll11l_l1_==l1l111_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ㈕"): data = l1l1llll11l_l1_
	conn.close()
	return data
def l1l1ll111ll_l1_(l1l1l1l1111_l1_,l1l1ll1lll1_l1_=True):
	l1l111l1l11_l1_ = xbmc.getInfoLabel(l1l111_l1_ (u"ࠬࡔࡥࡵࡹࡲࡶࡰ࠴ࡉࡑࡃࡧࡨࡷ࡫ࡳࡴࠩ㈖"))
	l1l1ll11l1l_l1_ = xbmc.getInfoLabel(l1l111_l1_ (u"࠭ࡓࡺࡵࡷࡩࡲ࠴ࡆࡳ࡫ࡨࡲࡩࡲࡹࡏࡣࡰࡩࠬ㈗"))
	if l1l1ll1lll1_l1_:
		try: l1l111llll1_l1_,l1l1lll111l_l1_,l1l11l1lll1_l1_ = l1lll11l111_l1_(main_dbfile,l1l111_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ㈘"),l1l111_l1_ (u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫ㈙"),l1l111_l1_ (u"ࠩࡌࡈࡘ࠭㈚"))
		except: l1l111llll1_l1_,l1l1lll111l_l1_,l1l11l1lll1_l1_ = l1l111_l1_ (u"ࠪࠫ㈛"),l1l111_l1_ (u"ࠫࠬ㈜"),l1l111_l1_ (u"ࠬ࠭㈝")
		if l1l111llll1_l1_ and l1l111l1l11_l1_==l1l1lll111l_l1_ and l1l1ll11l1l_l1_==l1l11l1lll1_l1_: return l1l111llll1_l1_
	l1l1l1l1111_l1_ = l1l1l1l1111_l1_//2
	from threading import Thread
	if not l1l1lll1ll1_l1_:
		l1l11l11l1l_l1_ = Thread(target=l1l1l111lll_l1_)
		l1l11l11l1l_l1_.start()
	if not l1l1lll1l1l_l1_:
		l1l11l11ll1_l1_ = Thread(target=l1l1ll11111_l1_)
		l1l11l11ll1_l1_.start()
	l1l1lll1l11_l1_,l1l1lll11ll_l1_,l1l1lll11l1_l1_ = l1l111_l1_ (u"࠭ࠧ㈞"),l1l111_l1_ (u"ࠧࠨ㈟"),l1l111_l1_ (u"ࠨ࠲࠳࠵࠶࠸࠲࠴࠵࠷࠸࠺࠻࠶࠷࠹࠺ࠫ㈠")
	for l1l111lll1_l1_ in range(10):
		time.sleep(0.5)
		if not l1l1lll1l11_l1_:
			try:
				l1ll1111l1l_l1_ = xbmc.getInfoLabel(l1l111_l1_ (u"ࠩࡑࡩࡹࡽ࡯ࡳ࡭࠱ࡑࡦࡩࡁࡥࡦࡵࡩࡸࡹࠧ㈡"))
				if l1ll1111l1l_l1_.count(l1l111_l1_ (u"ࠪ࠾ࠬ㈢"))==5 and l1ll1111l1l_l1_.count(l1l111_l1_ (u"ࠫ࠵࠭㈣"))<9:
					l1ll1111l1l_l1_ = l1ll1111l1l_l1_.lower().replace(l1l111_l1_ (u"ࠬࡀࠧ㈤"),l1l111_l1_ (u"࠭ࠧ㈥"))
					l1l1lll1l11_l1_ = str(int(l1ll1111l1l_l1_,16))
			except: pass
		if l1l1lll1ll1_l1_ and l1l1lll1l1l_l1_ and l1l1lll1l11_l1_: break
	try:
		l1l11ll1l1l_l1_ = open(l1l111_l1_ (u"ࠧ࠰ࡲࡵࡳࡨ࠵ࡣࡱࡷ࡬ࡲ࡫ࡵࠧ㈦"),l1l111_l1_ (u"ࠨࡴࡥࠫ㈧")).read()
		if PY3: l1l11ll1l1l_l1_ = l1l11ll1l1l_l1_.decode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㈨"))
		l1l111ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡗࡪࡸࡩࡢ࡮࠱࠮ࡄࡀࠠࠩ࠰࠭ࡃ࠮ࠪࠧ㈩"),l1l11ll1l1l_l1_,re.IGNORECASE)
		if l1l111ll1ll_l1_:
			l1l111ll1ll_l1_ = l1l111ll1ll_l1_[0].strip(l1l111_l1_ (u"ࠫ࠵࠭㈪"))
			if l1l111ll1ll_l1_:
				from hashlib import md5
				if PY3: l1l111ll1ll_l1_ = l1l111ll1ll_l1_.encode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㈫"))
				l1l111ll1ll_l1_ = str(int(md5(l1l111ll1ll_l1_).hexdigest(),36))
				l1l111ll1ll_l1_ = [int(l1l111ll1ll_l1_[l1ll1111ll1_l1_:l1ll1111ll1_l1_+15]) for l1ll1111ll1_l1_ in range(len(l1l111ll1ll_l1_)) if l1ll1111ll1_l1_%15==0]
				l1l1lll11ll_l1_ = str(sum(l1l111ll1ll_l1_))
	except: pass
	l1l111llll1_l1_ = l1l111_l1_ (u"࠭ࠧ㈬")
	for l1l1ll11l11_l1_ in [l1l1lll1ll1_l1_,l1l1lll1l1l_l1_,l1l1lll1l11_l1_,l1l1lll11ll_l1_,l1l1lll11l1_l1_]:
		l1l1ll11l11_l1_ = l1l1l1l1111_l1_*l1l111_l1_ (u"ࠧ࠱ࠩ㈭")+l1l1ll11l11_l1_
		l1l1ll11l11_l1_ = l1l1ll11l11_l1_[-l1l1l1l1111_l1_:]
		mm,ss = l1l111_l1_ (u"ࠨࠩ㈮"),l1l111_l1_ (u"ࠩࠪ㈯")
		l1l11llllll_l1_ = str(int(l1l111_l1_ (u"ࠪ࠽ࠬ㈰")*(l1l1l1l1111_l1_+1))-int(l1l1ll11l11_l1_))[-l1l1l1l1111_l1_:]
		for l1l111lll1_l1_ in list(range(0,l1l1l1l1111_l1_,4)):
			l1l11l1l111_l1_ = l1l11llllll_l1_[l1l111lll1_l1_:l1l111lll1_l1_+4]
			mm += l1l11l1l111_l1_+l1l111_l1_ (u"ࠫ࠲࠭㈱")
			ss += str(sum(map(int,l1l1ll11l11_l1_[l1l111lll1_l1_:l1l111lll1_l1_+4]))%10)
		l1l111llll1_l1_ += mm+ss+l1l111_l1_ (u"ࠬࡢ࡮ࠨ㈲")
	l1l111llll1_l1_ = l1l111llll1_l1_.strip(l1l111_l1_ (u"࠭࡜࡯ࠩ㈳"))
	l1lll111111_l1_(main_dbfile,l1l111_l1_ (u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪ㈴"),l1l111_l1_ (u"ࠨࡋࡇࡗࠬ㈵"),[l1l111llll1_l1_,l1l111l1l11_l1_,l1l1ll11l1l_l1_],l1ll1ll1_l1_)
	return l1l111llll1_l1_
class l1l1l1l1l1l_l1_(l1l1ll11ll1_l1_):
	def __init__(self): self.l1l11lll1ll_l1_ = l1l111_l1_ (u"ࠩࠪ㈶")
	def init(self,l1l11ll111l_l1_):
		self.l1l11ll111l_l1_ = l1l11ll111l_l1_
		self.l1ll1111lll_l1_ = l1l11ll1lll_l1_(l1l111_l1_ (u"ࠪࡇ࡙ࡋ࠹ࡅࡕ࠴࠽࡛࡛࠰ࡗࡕ࡛ࠫ㈷"))
		self.l1l1l1lllll_l1_ = l1l11ll1lll_l1_(l1l111_l1_ (u"ࠫ࡜࡙ࡕࡓࡈࡗ࠵࠾ࡗࡔࡆࡈ࡝࡜ࠬ㈸"))
		self.l1l1l11llll_l1_ = l1l11ll1lll_l1_(l1l111_l1_ (u"ࠬࡈࡔࡆࡺࡓ࡚࠶࠿ࡕࡓࡘࡑ࡙ࡘ࡛࠵ࡉ࡚ࠪ㈹"))
		if self.l1ll1111lll_l1_: self.l1l11lll1ll_l1_ = l1l111_l1_ (u"࠭ࡢ࡭ࡱࡦ࡯ࡪࡪࠧ㈺")
		elif self.l1l1l1lllll_l1_: return
		elif self.l1l1l11llll_l1_:
			from l1l1l111l11_l1_ import l1l1l1l1l11_l1_
			l1l1l1l1l11_l1_(False)
		else:
			self.l1l11lll1ll_l1_ = l1l111_l1_ (u"ࠧࡣ࡮ࡲࡧࡰ࡫ࡤࠨ㈻")
			from l1l1l111l11_l1_ import l1l1l1l1l11_l1_
			l1l1l1l1l11_l1_(False)
	def onPlayBackStopped(self): self.l1l11lll1ll_l1_ = l1l111_l1_ (u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨ㈼")
	def onPlayBackError(self): self.l1l11lll1ll_l1_ = l1l111_l1_ (u"ࠩࡩࡥ࡮ࡲࡥࡥࠩ㈽")
	def onPlayBackEnded(self): self.l1l11lll1ll_l1_ = l1l111_l1_ (u"ࠪࡪࡦ࡯࡬ࡦࡦࠪ㈾")
	def onPlayBackStarted(self):
		self.l1l11lll1ll_l1_ = l1l111_l1_ (u"ࠫࡸࡺࡡࡳࡶࡨࡨࠬ㈿")
		from threading import Thread
		l1l111lll1l_l1_ = Thread(target=self.l1l11l111ll_l1_,args=())
		l1l111lll1l_l1_.start()
	def l1l1lll1lll_l1_(self):
		if self.l1ll1111lll_l1_: self.l1l11lll1ll_l1_ = l1l111_l1_ (u"ࠬࡨ࡬ࡰࡥ࡮ࡩࡩ࠭㉀")
		elif self.l1l1l1lllll_l1_: self.l1l11lll1ll_l1_ = l1l111_l1_ (u"࠭ࡰ࡭ࡣࡼ࡭ࡳ࡭ࠧ㉁")
		elif self.l1l1l11llll_l1_: self.l1l11lll1ll_l1_ = l1l111_l1_ (u"ࠧࡵࡧࡶࡸ࡮ࡴࡧࠨ㉂")
		else: self.l1l11lll1ll_l1_ = l1l111_l1_ (u"ࠨࡤ࡯ࡳࡨࡱࡥࡥࠩ㉃")
	def l1l11l111ll_l1_(self):
		l1l1l1l111l_l1_ = 0
		while not eval(l1l111_l1_ (u"ࠩࡻࡦࡲࡩ࠮ࡑ࡮ࡤࡽࡪࡸࠨࠪ࠰࡬ࡷࡕࡲࡡࡺ࡫ࡱ࡫࡛࡯ࡤࡦࡱࠫ࠭ࠬ㉄")) and self.l1l11lll1ll_l1_==l1l111_l1_ (u"ࠪࡷࡹࡧࡲࡵࡧࡧࠫ㉅"):
			xbmc.sleep(1500)
			l1l1l1l111l_l1_ += 1.5
			if l1l1l1l111l_l1_>60: return
		if self.l1ll1111lll_l1_: self.l1l11lll1ll_l1_ = l1l111_l1_ (u"ࠫࡧࡲ࡯ࡤ࡭ࡨࡨࠬ㉆")
		elif self.l1l1l1lllll_l1_: self.l1l11lll1ll_l1_ = l1l111_l1_ (u"ࠬࡶ࡬ࡢࡻ࡬ࡲ࡬࠭㉇")
		elif self.l1l1l11llll_l1_:
			self.l1l11lll1ll_l1_ = l1l111_l1_ (u"࠭ࡴࡦࡵࡷ࡭ࡳ࡭ࠧ㉈")
			from LIBSTWO import l1l1ll111l1_l1_,l1l111l1l1l_l1_
			from threading import Thread
			l1l111lll11_l1_ = Thread(target=l1l1ll111l1_l1_,args=(self.l1l11ll111l_l1_,))
			l1l111lll11_l1_.start()
			l1l111lllll_l1_ = Thread(target=l1l111l1l1l_l1_,args=())
			l1l111lllll_l1_.start()
		else: self.l1l11lll1ll_l1_ = l1l111_l1_ (u"ࠧࡣ࡮ࡲࡧࡰ࡫ࡤࠨ㉉")
def l1l1l1ll1l1_l1_(type,url,data,headers,source,method):
	l1ll1ll1l_l1_ = str(headers)[0:250].replace(l1l111_l1_ (u"ࠨ࡞ࡱࠫ㉊"),l1l111_l1_ (u"ࠩ࡟ࡠࡳ࠭㉋")).replace(l1l111_l1_ (u"ࠪࡠࡷ࠭㉌"),l1l111_l1_ (u"ࠫࡡࡢࡲࠨ㉍")).replace(l1l111_l1_ (u"ࠬࠦࠠࠡࠢࠪ㉎"),l1l111_l1_ (u"࠭ࠠࠨ㉏")).replace(l1l111_l1_ (u"ࠧࠡࠢࠣࠫ㉐"),l1l111_l1_ (u"ࠨࠢࠪ㉑"))
	if len(str(headers))>250: l1ll1ll1l_l1_ = l1ll1ll1l_l1_+l1l111_l1_ (u"ࠩࠣ࠲࠳࠴ࠧ㉒")
	l1l11llll_l1_ = str(data)[0:250].replace(l1l111_l1_ (u"ࠪࡠࡳ࠭㉓"),l1l111_l1_ (u"ࠫࡡࡢ࡮ࠨ㉔")).replace(l1l111_l1_ (u"ࠬࡢࡲࠨ㉕"),l1l111_l1_ (u"࠭࡜࡝ࡴࠪ㉖")).replace(l1l111_l1_ (u"ࠧࠡࠢࠣࠤࠬ㉗"),l1l111_l1_ (u"ࠨࠢࠪ㉘")).replace(l1l111_l1_ (u"ࠩࠣࠤࠥ࠭㉙"),l1l111_l1_ (u"ࠪࠤࠬ㉚"))
	if len(str(data))>250: l1l11llll_l1_ = l1l11llll_l1_+l1l111_l1_ (u"ࠫࠥ࠴࠮࠯ࠩ㉛")
	l11llllll1_l1_(l1l111_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ㉜"),l1l111_l1_ (u"࠭࠮ࠡࠢࡒࡔࡊࡔࡕࡓࡎࡢࠫ㉝")+type+l1l111_l1_ (u"ࠧࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ㉞")+url+l1l111_l1_ (u"ࠨࠢࡠࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪ㉟")+source+l1l111_l1_ (u"ࠩࠣࡡࠥࠦࠠࡎࡧࡷ࡬ࡴࡪ࠺ࠡ࡝ࠣࠫ㉠")+method+l1l111_l1_ (u"ࠪࠤࡢࠦࠠࠡࡊࡨࡥࡩ࡫ࡲࡴ࠼ࠣ࡟ࠥ࠭㉡")+str(l1ll1ll1l_l1_)+l1l111_l1_ (u"ࠫࠥࡣࠠࠡࠢࡇࡥࡹࡧ࠺ࠡ࡝ࠣࠫ㉢")+l1l11llll_l1_+l1l111_l1_ (u"ࠬࠦ࡝ࠨ㉣"))
	return
l1l1lll1ll1_l1_ = l1l111_l1_ (u"࠭ࠧ㉤")
def l1l1l111lll_l1_():
	global l1l1lll1ll1_l1_
	try:
		import getmac82
		l1ll11111ll_l1_ = getmac82.get_mac_address()
		if l1ll11111ll_l1_.count(l1l111_l1_ (u"ࠧ࠻ࠩ㉥"))==5 and l1ll11111ll_l1_.count(l1l111_l1_ (u"ࠨ࠲ࠪ㉦"))<9:
			l1ll11111ll_l1_ = l1ll11111ll_l1_.lower().replace(l1l111_l1_ (u"ࠩ࠽ࠫ㉧"),l1l111_l1_ (u"ࠪࠫ㉨"))
			l1l1lll1ll1_l1_ = str(int(l1ll11111ll_l1_,16))
	except: pass
	return
l1l1lll1l1l_l1_ = l1l111_l1_ (u"ࠫࠬ㉩")
def l1l1ll11111_l1_():
	global l1l1lll1l1l_l1_
	try:
		import getmac94
		l1ll1111l11_l1_ = getmac94.get_mac_address()
		if l1ll1111l11_l1_.count(l1l111_l1_ (u"ࠬࡀࠧ㉪"))==5 and l1ll1111l11_l1_.count(l1l111_l1_ (u"࠭࠰ࠨ㉫"))<9:
			l1ll1111l11_l1_ = l1ll1111l11_l1_.lower().replace(l1l111_l1_ (u"ࠧ࠻ࠩ㉬"),l1l111_l1_ (u"ࠨࠩ㉭"))
			l1l1lll1l1l_l1_ = str(int(l1ll1111l11_l1_,16))
	except: pass
	return
def l1l111l1ll1_l1_(method,url,data=l1l111_l1_ (u"ࠩࠪ㉮"),headers=l1l111_l1_ (u"ࠪࠫ㉯"),source=l1l111_l1_ (u"ࠫࠬ㉰")):
	l1l1l1ll1l1_l1_(l1l111_l1_ (u"࡛ࠬࡒࡍࡎࡌࡆࠥࠦࡏࡑࡇࡑࡣ࡚ࡘࡌࠨ㉱"),url,data,headers,source,method)
	if PY3: import urllib.request as l1l1ll1ll1l_l1_
	else: import urllib2 as l1l1ll1ll1l_l1_
	if not headers: headers = {l1l111_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ㉲"):l1l111_l1_ (u"ࠧࠨ㉳")}
	if not data: data = {}
	if method==l1l111_l1_ (u"ࠨࡉࡈࡘࠬ㉴"):
		url = url+l1l111_l1_ (u"ࠩࡂࠫ㉵")+l1lllll11_l1_(data)
		data = None
	elif method==l1l111_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ㉶") and l1l111_l1_ (u"ࠫ࡯ࡹ࡯࡯ࠩ㉷") in str(headers):
		from json import dumps
		data = dumps(data)
		data = str(data).encode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㉸"))
	elif method==l1l111_l1_ (u"࠭ࡐࡐࡕࡗࠫ㉹"):
		data = l1lllll11_l1_(data)
		data = data.encode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㉺"))
	try:
		req = l1l1ll1ll1l_l1_.Request(url,headers=headers,data=data)
		response = l1l1ll1ll1l_l1_.urlopen(req)
		html = response.read()
		code,reason = 200,l1l111_l1_ (u"ࠨࡑࡎࠫ㉻")
	except:
		html = l1l111_l1_ (u"ࠩࠪ㉼")
		code,reason = -1,l1l111_l1_ (u"࡙ࠪࡳࡱ࡮ࡰࡹࡱࠤࡊࡸࡲࡰࡴࠪ㉽")
	l11llllll1_l1_(l1l111_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ㉾"),l1l111_l1_ (u"ࠬ࠴ࠠࠡࡑࡓࡉࡓ࡛ࡒࡍࡡࡘࡖࡑࡒࡉࡃࠢࠣࡖࡊ࡙ࡐࡐࡐࡖࡉࠥࠦࡃࡰࡦࡨ࠾ࠥࡡࠠࠨ㉿")+str(code)+l1l111_l1_ (u"࠭ࠠ࡞ࠢࠣࠤࡗ࡫ࡡࡴࡱࡱ࠾ࠥࡡࠠࠨ㊀")+reason+l1l111_l1_ (u"ࠧࠡ࡟ࠣࠤ࡙ࠥ࡯ࡶࡴࡦࡩ࠿࡛ࠦࠡࠩ㊁")+source+l1l111_l1_ (u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ㊂")+url+l1l111_l1_ (u"ࠩࠣࡡࠬ㊃"))
	if html and PY3: html = html.decode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㊄"))
	return html
def l1l1llllll1_l1_(l1l11ll11l1_l1_,l1l11ll11ll_l1_=l1l111_l1_ (u"ࠫࠬ㊅")):
	l1l11ll1111_l1_ = str(random.randrange(111111111111,999999999999))
	headers = {l1l111_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ㊆"):l1l111_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳࡯ࡹ࡯࡯ࠩ㊇")}
	l1l1111llll_l1_ = {	l1l111_l1_ (u"ࠢࡶࡵࡨࡶࡤ࡯ࡤࠣ㊈"):l1l1ll111ll_l1_(32).splitlines()[0],
				l1l111_l1_ (u"ࠣࡱࡶࡣࡻ࡫ࡲࡴ࡫ࡲࡲࠧ㊉"):str(kodi_version),
				l1l111_l1_ (u"ࠤࡤࡴࡵࡥࡶࡦࡴࡶ࡭ࡴࡴࠢ㊊"):l1l11l1l1l1_l1_,
				l1l111_l1_ (u"ࠥࡨࡪࡼࡩࡤࡧࡢࡪࡦࡳࡩ࡭ࡻࠥ㊋"):l1l11l1l1l1_l1_,
				l1l111_l1_ (u"ࠦࡪࡼࡥ࡯ࡶࡢࡸࡾࡶࡥࠣ㊌"):l1l11ll11l1_l1_,
				l1l111_l1_ (u"ࠧ࡫ࡶࡦࡰࡷࡣࡵࡸ࡯ࡱࡧࡵࡸ࡮࡫ࡳࠣ㊍"):{l1l111_l1_ (u"ࠨࡅࡷࡧࡱࡸࡤࡔࡡ࡮ࡧࠥ㊎"):l1l11ll11l1_l1_},
				l1l111_l1_ (u"ࠢࡶࡵࡨࡶࡤࡶࡲࡰࡲࡨࡶࡹ࡯ࡥࡴࠤ㊏"): {l1l111_l1_ (u"ࠣࡗࡶࡩࡷࡥࡅࡷࡧࡱࡸࡤࡔࡡ࡮ࡧࠥ㊐"):l1l11ll11l1_l1_},
				l1l111_l1_ (u"ࠤࡳࡰࡦࡺࡦࡰࡴࡰࠦ㊑"): l1l111_l1_ (u"ࠥࡅࡗࡇࡂࡊࡅࡢ࡚ࡎࡊࡅࡐࡕࠥ㊒"),
				l1l111_l1_ (u"ࠦࠩࡹ࡫ࡪࡲࡢࡹࡸ࡫ࡲࡠࡲࡵࡳࡵ࡫ࡲࡵ࡫ࡨࡷࡤࡹࡹ࡯ࡥࠥ㊓"):False,
				l1l111_l1_ (u"ࠧ࡯ࡰࠣ㊔"): l1l111_l1_ (u"ࠨࠤࡳࡧࡰࡳࡹ࡫ࠢ㊕")
			}
	if not l1l11ll11ll_l1_: l1l11l1111l_l1_ = [l1l1111llll_l1_]
	else:
		l1l111l1111_l1_ = l1l1111llll_l1_.copy()
		l1l111l1111_l1_[l1l111_l1_ (u"ࠧࡦࡸࡨࡲࡹࡥࡴࡺࡲࡨࠫ㊖")] = l1l11ll11ll_l1_
		l1l111l1111_l1_[l1l111_l1_ (u"ࠨࡧࡹࡩࡳࡺ࡟ࡱࡴࡲࡴࡪࡸࡴࡪࡧࡶࠫ㊗")] = {l1l111_l1_ (u"ࠤࡈࡺࡪࡴࡴࡠࡐࡤࡱࡪࠨ㊘"):l1l11ll11ll_l1_}
		l1l111l1111_l1_[l1l111_l1_ (u"ࠪࡹࡸ࡫ࡲࡠࡲࡵࡳࡵ࡫ࡲࡵ࡫ࡨࡷࠬ㊙")] = {l1l111_l1_ (u"࡚ࠦࡹࡥࡳࡡࡈࡺࡪࡴࡴࡠࡐࡤࡱࡪࠨ㊚"):l1l11ll11ll_l1_}
		l1l11l1111l_l1_ = [l1l1111llll_l1_,l1l111l1111_l1_]
	data = {l1l111_l1_ (u"ࠧࡧࡰࡪࡡ࡮ࡩࡾࠨ㊛"):l1l111_l1_ (u"࠭࠲࠶࠶ࡧࡨ࠸ࡧ࠴࠱࠻ࡧ࠼ࡧ࠼࠸࠲ࡦ࠷ࡩ࠶࠷࠷ࡦࡧ࠺࠼ࡨ࡫ࡢࡧ࠴࠼ࠫ㊜"),
			l1l111_l1_ (u"ࠢࡪࡰࡶࡩࡷࡺ࡟ࡪࡦࠥ㊝"):l1l11ll1111_l1_,
			l1l111_l1_ (u"ࠣࡧࡹࡩࡳࡺࡳࠣ㊞"): l1l11l1111l_l1_
		}
	url = l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡵ࡯࠲࠯ࡣࡰࡴࡱ࡯ࡴࡶࡦࡨ࠲ࡨࡵ࡭࠰࠴࠲࡬ࡹࡺࡰࡢࡲ࡬ࠫ㊟")
	html = l1l111l1ll1_l1_(l1l111_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ㊠"),url,data,headers,l1l111_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲࡙ࡅࡏࡆࡢࡅࡓࡇࡌ࡚ࡖࡌࡇࡘࡥࡅࡗࡇࡑࡘ࠲࠷ࡳࡵࠩ㊡"))
	return html
def l1ll1l1_l1_(l1l1l1ll11l_l1_,text):
	text = text.replace(l1l111_l1_ (u"ࠬࡴࡵ࡭࡮ࠪ㊢"),l1l111_l1_ (u"࠭ࡎࡰࡰࡨࠫ㊣"))
	text = text.replace(l1l111_l1_ (u"ࠧࡵࡴࡸࡩࠬ㊤"),l1l111_l1_ (u"ࠨࡖࡵࡹࡪ࠭㊥"))
	text = text.replace(l1l111_l1_ (u"ࠩࡩࡥࡱࡹࡥࠨ㊦"),l1l111_l1_ (u"ࠪࡊࡦࡲࡳࡦࠩ㊧"))
	text = text.replace(l1l111_l1_ (u"ࠫࡡ࠵ࠧ㊨"),l1l111_l1_ (u"ࠬ࠵ࠧ㊩"))
	try: l1ll1ll11l_l1_ = eval(text)
	except: l1ll1ll11l_l1_ = l1l1l11ll1l_l1_(l1l1l1ll11l_l1_)
	return l1ll1ll11l_l1_
def l1l1l1lll11_l1_():
	type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll111_l1_ = EXTRACT_KODI_PATH(addon_path)
	tmp = re.findall(l1l111_l1_ (u"࠭࡜ࡥ࡞ࡧ࠾ࡡࡪ࡜ࡥࠢ࡟࡟࠴ࡉࡏࡍࡑࡕࡠࡢ࠭㊪"),name,re.DOTALL)
	if tmp: name = name.split(tmp[0],1)[1]
	datetime = time.strftime(l1l111_l1_ (u"ࠧࡠࠧࡰ࠲ࠪࡪ࡟ࠦࡊ࠽ࠩࡒࡥࠧ㊫"),time.localtime(now))
	name = name+datetime
	l1lll111ll1_l1_ = type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll111_l1_
	if os.path.exists(l1l1l11l111_l1_):
		l1l11ll1ll1_l1_ = open(l1l1l11l111_l1_,l1l111_l1_ (u"ࠨࡴࡥࠫ㊬")).read()
		if PY3: l1l11ll1ll1_l1_ = l1l11ll1ll1_l1_.decode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㊭"))
		l1l11ll1ll1_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠪࡨ࡮ࡩࡴࠨ㊮"),l1l11ll1ll1_l1_)
	else: l1l11ll1ll1_l1_ = {}
	l1l11l1l1ll_l1_ = {}
	for l1l1lll1111_l1_ in list(l1l11ll1ll1_l1_.keys()):
		if l1l1lll1111_l1_!=type: l1l11l1l1ll_l1_[l1l1lll1111_l1_] = l1l11ll1ll1_l1_[l1l1lll1111_l1_]
		else:
			if name and name!=l1l111_l1_ (u"ࠫ࠳࠴ࠧ㊯"):
				l1l11l11lll_l1_ = l1l11ll1ll1_l1_[l1l1lll1111_l1_]
				if l1lll111ll1_l1_ in l1l11l11lll_l1_:
					index = l1l11l11lll_l1_.index(l1lll111ll1_l1_)
					del l1l11l11lll_l1_[index]
				l111l1l111_l1_ = [l1lll111ll1_l1_]+l1l11l11lll_l1_
				l111l1l111_l1_ = l111l1l111_l1_[:50]
				l1l11l1l1ll_l1_[l1l1lll1111_l1_] = l111l1l111_l1_
			else: l1l11l1l1ll_l1_[l1l1lll1111_l1_] = l1l11ll1ll1_l1_[l1l1lll1111_l1_]
	if type not in list(l1l11l1l1ll_l1_.keys()): l1l11l1l1ll_l1_[type] = [l1lll111ll1_l1_]
	l1l11l1l1ll_l1_ = str(l1l11l1l1ll_l1_)
	if PY3: l1l11l1l1ll_l1_ = l1l11l1l1ll_l1_.encode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㊰"))
	open(l1l1l11l111_l1_,l1l111_l1_ (u"࠭ࡷࡣࠩ㊱")).write(l1l11l1l1ll_l1_)
	return
def l1lll111111_l1_(l1ll1lll1l_l1_,table,l1l1l11lll1_l1_,data,l1l1l1l1lll_l1_,l1l1ll1ll11_l1_=False):
	cache = settings.getSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡧࡦࡩࡨࡦ࠰ࡶࡸࡦࡺࡵࡴࠩ㊲"))
	if cache==l1l111_l1_ (u"ࠨࡎࡌࡑࡎ࡚ࡅࡅࠩ㊳") and l1l1l1l1lll_l1_>l1l11l1l11l_l1_: l1l1l1l1lll_l1_ = l1l11l1l11l_l1_
	if l1l1ll1ll11_l1_:
		l1l11ll11_l1_,l1l11ll1l_l1_ = [],[]
		for l1l111lll1_l1_ in range(len(l1l1l11lll1_l1_)):
			text = pickle.dumps(data[l1l111lll1_l1_])
			l1l11l1ll1l_l1_ = zlib.compress(text)
			l1l11ll11_l1_.append((l1l1l11lll1_l1_[l1l111lll1_l1_],))
			l1l11ll1l_l1_.append((l1l1l1l1lll_l1_+now,str(l1l1l11lll1_l1_[l1l111lll1_l1_]),l1l11l1ll1l_l1_))
	else:
		text = pickle.dumps(data)
		l1l1l1l11ll_l1_ = zlib.compress(text)
	try: conn,l1llll1lll_l1_ = l1l1llll1l1_l1_(l1ll1lll1l_l1_)
	except: return
	while True:
		try:
			l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠩࡅࡉࡌࡏࡎࠡࡋࡐࡑࡊࡊࡉࡂࡖࡈࠤ࡙ࡘࡁࡏࡕࡄࡇ࡙ࡏࡏࡏࠢ࠾ࠫ㊴"))
			break
		except: time.sleep(0.5)
	l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠪࡇࡗࡋࡁࡕࡇࠣࡘࡆࡈࡌࡆࠢࡌࡊࠥࡔࡏࡕࠢࡈ࡜ࡎ࡙ࡔࡔࠢࠥࠫ㊵")+table+l1l111_l1_ (u"ࠫࠧࠦࠨࡦࡺࡳ࡭ࡷࡿࠬࡤࡱ࡯ࡹࡲࡴࠬࡥࡣࡷࡥ࠮ࠦ࠻ࠨ㊶"))
	if l1l1ll1ll11_l1_:
		l1llll1lll_l1_.executemany(l1l111_l1_ (u"ࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࠦࠬ㊷")+table+l1l111_l1_ (u"࡙࠭ࠢࠡࡋࡉࡗࡋࠠࡤࡱ࡯ࡹࡲࡴࠠ࠾ࠢࡂࠤࡀ࠭㊸"),l1l11ll11_l1_)
		l1llll1lll_l1_.executemany(l1l111_l1_ (u"ࠧࡊࡐࡖࡉࡗ࡚ࠠࡊࡐࡗࡓࠥࠨࠧ㊹")+table+l1l111_l1_ (u"ࠨࠤ࡚ࠣࡆࡒࡕࡆࡕࠣࠬࡄ࠲࠿࠭ࡁࠬࠤࡀ࠭㊺"),l1l11ll1l_l1_)
	else:
		if l1l1l1l1lll_l1_:
			tt = (str(l1l1l11lll1_l1_),)
			l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠩࡇࡉࡑࡋࡔࡆࠢࡉࡖࡔࡓࠠࠣࠩ㊻")+table+l1l111_l1_ (u"ࠪࠦࠥ࡝ࡈࡆࡔࡈࠤࡨࡵ࡬ࡶ࡯ࡱࠤࡂࠦ࠿ࠡ࠽ࠪ㊼"),tt)
			tt = (l1l1l1l1lll_l1_+now,str(l1l1l11lll1_l1_),l1l1l1l11ll_l1_)
			l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠫࡎࡔࡓࡆࡔࡗࠤࡎࡔࡔࡐࠢࠥࠫ㊽")+table+l1l111_l1_ (u"ࠬࠨࠠࡗࡃࡏ࡙ࡊ࡙ࠠࠩࡁ࠯ࡃ࠱ࡅࠩࠡ࠽ࠪ㊾"),tt)
		else:
			tt = (l1l1l1l11ll_l1_,str(l1l1l11lll1_l1_))
			l1llll1lll_l1_.execute(l1l111_l1_ (u"࠭ࡕࡑࡆࡄࡘࡊࠦࠢࠨ㊿")+table+l1l111_l1_ (u"ࠧࠣࠢࡖࡉ࡙ࠦࡤࡢࡶࡤࠤࡂࠦ࠿࡙ࠡࡋࡉࡗࡋࠠࡤࡱ࡯ࡹࡲࡴࠠ࠾ࠢࡂࠤࡀ࠭㋀"),tt)
	conn.commit()
	conn.close()
	return
def l1lllll11_l1_(data):
	if PY3: import urllib.parse as l1l1llll1ll_l1_
	else: import urllib as l1l1llll1ll_l1_
	l1ll11111l1_l1_ = l1l1llll1ll_l1_.urlencode(data)
	return l1ll11111l1_l1_
l1l11lll1ll_l1_ = l1l111_l1_ (u"ࠨࠩ㋁")
def l1llll111_l1_(l1llllll_l1_,l1ll1ll11l1_l1_=l1l111_l1_ (u"ࠩࠪ㋂"),l1l111l11l1_l1_=l1l111_l1_ (u"ࠪࠫ㋃")):
	l1l1l1ll1ll_l1_ = l1ll1ll11l1_l1_ not in [l1l111_l1_ (u"ࠫࡒ࠹ࡕࠨ㋄"),l1l111_l1_ (u"ࠬࡏࡐࡕࡘࠪ㋅")]
	global l1l11lll1ll_l1_
	if not l1l111l11l1_l1_: l1l111l11l1_l1_ = l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ㋆")
	l1l11lll1ll_l1_,l1l11lllll1_l1_,httpd = l1l111_l1_ (u"ࠧࡤࡣࡱࡧࡪࡲࡥࡥ࠲ࠪ㋇"),l1l111_l1_ (u"ࠨࠩ㋈"),l1l111_l1_ (u"ࠩࠪ㋉")
	if len(l1llllll_l1_)==3:
		url,l1l1l111l1l_l1_,httpd = l1llllll_l1_
		if l1l1l111l1l_l1_: l1l11lllll1_l1_ = l1l111_l1_ (u"ࠪࠤࠥࠦࡓࡶࡤࡷ࡭ࡹࡲࡥ࠻ࠢ࡞ࠤࠬ㋊")+l1l1l111l1l_l1_+l1l111_l1_ (u"ࠫࠥࡣࠧ㋋")
	else: url,l1l1l111l1l_l1_,httpd = l1llllll_l1_,l1l111_l1_ (u"ࠬ࠭㋌"),l1l111_l1_ (u"࠭ࠧ㋍")
	url = url.replace(l1l111_l1_ (u"ࠧࠦ࠴࠳ࠫ㋎"),l1l111_l1_ (u"ࠨࠢࠪ㋏"))
	l11ll11ll1_l1_ = l1l111l1l1_l1_(url,l1ll1ll11l1_l1_)
	if l1ll1ll11l1_l1_ not in [l1l111_l1_ (u"ࠩࡇࡓ࡜ࡔࡌࡐࡃࡇࠫ㋐"),l1l111_l1_ (u"ࠪࡍࡕ࡚ࡖࠨ㋑")]:
		if l1ll1ll11l1_l1_!=l1l111_l1_ (u"ࠫࡉࡕࡗࡏࡎࡒࡅࡉ࠭㋒"): url = url.replace(l1l111_l1_ (u"ࠬࠦࠧ㋓"),l1l111_l1_ (u"࠭ࠥ࠳࠲ࠪ㋔"))
		l11llllll1_l1_(l1l111_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㋕"),l11llll11l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠨࠢࠣࠤࡕࡸࡥࡱࡣࡵ࡭ࡳ࡭ࠠࡵࡱࠣࡴࡱࡧࡹ࠰ࡦࡲࡻࡳࡲ࡯ࡢࡦࠣࡺ࡮ࡪࡥࡰࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ㋖")+url+l1l111_l1_ (u"ࠩࠣࡡࠬ㋗")+l1l11lllll1_l1_)
		if l11ll11ll1_l1_==l1l111_l1_ (u"ࠪ࠲ࡲ࠹ࡵ࠹ࠩ㋘") and l1ll1ll11l1_l1_ not in [l1l111_l1_ (u"ࠫࡎࡖࡔࡗࠩ㋙"),l1l111_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭㋚")]:
			headers = {l1l111_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ㋛"):l1l111_l1_ (u"ࠧࠨ㋜")}
			from LIBSTWO import l1l11l11ll_l1_,l1ll11ll_l1_,l1ll1lll_l1_
			l1l1lll1_l1_,l1llll_l1_ = l1l11l11ll_l1_(url,headers)
			count = len(l1llll_l1_)
			if count>1:
				l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠨษัฮึࠦวๅ็็ๅࠥอไๆ่สือࡀࠠࠩࠩ㋝")+str(count)+l1l111_l1_ (u"้้ࠩࠣ็ࠩࠨ㋞"), l1l1lll1_l1_)
				if l11l11l_l1_ == -1:
					l1ll1lll_l1_(l1l111_l1_ (u"ࠪฮ๊ࠦลๅ฼สลࠥอไหึ฽๎้࠭㋟"),l1l111_l1_ (u"ࠫࠬ㋠"))
					return l1l11lll1ll_l1_
			else: l11l11l_l1_ = 0
			url = l1llll_l1_[l11l11l_l1_]
			if l1l1lll1_l1_[0]!=l1l111_l1_ (u"ࠬ࠳࠱ࠨ㋡"):
				l11llllll1_l1_(l1l111_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭㋢"),l11llll11l_l1_(l1ll1_l1_)+l1l111_l1_ (u"࡚ࠧࠡࠢࠣ࡮ࡪࡥࡰࠢࡖࡩࡱ࡫ࡣࡵࡧࡧࠤࠥࠦࡓࡦ࡮ࡨࡧࡹ࡯࡯࡯࠼ࠣ࡟ࠥ࠭㋣")+l1l1lll1_l1_[l11l11l_l1_]+l1l111_l1_ (u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ㋤")+url+l1l111_l1_ (u"ࠩࠣࡡࠬ㋥"))
		if l1l111_l1_ (u"ࠪ࠳࡮࡬ࡩ࡭࡯࠲ࠫ㋦") in url: url = url+l1l111_l1_ (u"ࠫࢁ࡛ࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ࠿ࠩࠫ㋧")
		elif l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ㋨") in url.lower() and l1l111_l1_ (u"࠭࠯ࡥࡣࡶ࡬࠴࠭㋩") not in url and l1l111_l1_ (u"ࠧࡺࡱࡸࡸࡺࡨࡥ࠯࡯ࡳࡨࠬ㋪") not in url:
			if l1l111_l1_ (u"ࠨࡸࡨࡶ࡮࡬ࡹࡱࡧࡨࡶࡂ࠭㋫") not in url and l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࠫ㋬") in url.lower():
				if l1l111_l1_ (u"ࠪࢀࠬ㋭") not in url: url = url+l1l111_l1_ (u"ࠫࢁࡼࡥࡳ࡫ࡩࡽࡵ࡫ࡥࡳ࠿ࡩࡥࡱࡹࡥࠨ㋮")
				else: url = url+l1l111_l1_ (u"ࠬࠬࡶࡦࡴ࡬ࡪࡾࡶࡥࡦࡴࡀࡪࡦࡲࡳࡦࠩ㋯")
			if l1l111_l1_ (u"࠭ࡵࡴࡧࡵ࠱ࡦ࡭ࡥ࡯ࡶࠪ㋰") not in url.lower() and l1ll1ll11l1_l1_ not in [l1l111_l1_ (u"ࠧࡊࡒࡗ࡚ࠬ㋱"),l1l111_l1_ (u"ࠨࡏ࠶࡙ࠬ㋲")]:
				if l1l111_l1_ (u"ࠩࡿࠫ㋳") not in url: url = url+l1l111_l1_ (u"ࠪࢀ࡚ࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴ࠾ࠨࠪ㋴")
				else: url = url+l1l111_l1_ (u"࡛ࠫࠫࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ࠿ࠩࠫ㋵")
	l11llllll1_l1_(l1l111_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࡤࡒࡉࡏࡇࡖࠫ㋶"),l11llll11l_l1_(l1ll1_l1_)+l1l111_l1_ (u"࠭ࠠࠡࠢࡊࡳࡹࠦࡦࡪࡰࡤࡰࠥࡻࡲ࡭ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ㋷")+url+l1l111_l1_ (u"ࠧࠡ࡟ࠪ㋸"))
	l1l111l1lll_l1_ = xbmcgui.ListItem()
	l1l111l11l1_l1_,l1l11llll11_l1_,l1l1l1l11l1_l1_,l1l111ll1l1_l1_,l1l1ll1111l_l1_,l1l111l11ll_l1_,l1l11lll1l1_l1_,l1l11lll111_l1_,l1l1l11l11l_l1_ = EXTRACT_KODI_PATH(addon_path)
	if l1ll1ll11l1_l1_ not in [l1l111_l1_ (u"ࠨࡆࡒ࡛ࡓࡒࡏࡂࡆࠪ㋹"),l1l111_l1_ (u"ࠩࡌࡔ࡙࡜ࠧ㋺")]:
		if PY2: l1l111ll111_l1_ = l1l111_l1_ (u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭ࡢࡦࡧࡳࡳ࠭㋻")
		else: l1l111ll111_l1_ = l1l111_l1_ (u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮ࠩ㋼")
		l1l111l1lll_l1_.setProperty(l1l111ll111_l1_, l1l111_l1_ (u"ࠬ࠭㋽"))
		l1l111l1lll_l1_.setMimeType(l1l111_l1_ (u"࠭࡭ࡪ࡯ࡨ࠳ࡽ࠳ࡴࡺࡲࡨࠫ㋾"))
		if kodi_version<20: l1l111l1lll_l1_.setInfo(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭㋿"),{l1l111_l1_ (u"ࠨ࡯ࡨࡨ࡮ࡧࡴࡺࡲࡨࠫ㌀"):l1l111_l1_ (u"ࠩࡰࡳࡻ࡯ࡥࠨ㌁")})
		else:
			l1l1l11l1l1_l1_ = l1l111l1lll_l1_.getVideoInfoTag()
			l1l1l11l1l1_l1_.setMediaType(l1l111_l1_ (u"ࠪࡱࡴࡼࡩࡦࠩ㌂"))
		l1l111l1lll_l1_.setArt({l1l111_l1_ (u"ࠫࡹ࡮ࡵ࡮ࡤࠪ㌃"):l1l1ll1111l_l1_,l1l111_l1_ (u"ࠬࡶ࡯ࡴࡶࡨࡶࠬ㌄"):l1l1ll1111l_l1_,l1l111_l1_ (u"࠭ࡢࡢࡰࡱࡩࡷ࠭㌅"):l1l1ll1111l_l1_,l1l111_l1_ (u"ࠧࡧࡣࡱࡥࡷࡺࠧ㌆"):l1l1ll1111l_l1_,l1l111_l1_ (u"ࠨࡥ࡯ࡩࡦࡸࡡࡳࡶࠪ㌇"):l1l1ll1111l_l1_,l1l111_l1_ (u"ࠩࡦࡰࡪࡧࡲ࡭ࡱࡪࡳࠬ㌈"):l1l1ll1111l_l1_,l1l111_l1_ (u"ࠪࡰࡦࡴࡤࡴࡥࡤࡴࡪ࠭㌉"):l1l1ll1111l_l1_,l1l111_l1_ (u"ࠫ࡮ࡩ࡯࡯ࠩ㌊"):l1l1ll1111l_l1_})
		if l11ll11ll1_l1_ in [l1l111_l1_ (u"ࠬ࠴࡭ࡱࡦࠪ㌋"),l1l111_l1_ (u"࠭࠮࡮࠵ࡸ࠼ࠬ㌌")]: l1l111l1lll_l1_.setContentLookup(True)
		else: l1l111l1lll_l1_.setContentLookup(False)
		from l1l1l111l11_l1_ import l1l1l1lll1l_l1_
		if l1l111_l1_ (u"ࠧࡳࡶࡰࡴࠬ㌍") in url:
			l1l1l1lll1l_l1_(l1l111_l1_ (u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡲࡵ࡯ࡳࠫ㌎"),False)
		elif l11ll11ll1_l1_==l1l111_l1_ (u"ࠩ࠱ࡱࡵࡪࠧ㌏") or l1l111_l1_ (u"ࠪ࠳ࡩࡧࡳࡩ࠱ࠪ㌐") in url:
			l1l1l1lll1l_l1_(l1l111_l1_ (u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡤࡨࡦࡶࡴࡪࡸࡨࠫ㌑"),False)
			l1l111l1lll_l1_.setProperty(l1l111ll111_l1_,l1l111_l1_ (u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡥࡩࡧࡰࡵ࡫ࡹࡩࠬ㌒"))
			l1l111l1lll_l1_.setProperty(l1l111_l1_ (u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠴࡭ࡢࡰ࡬ࡪࡪࡹࡴࡠࡶࡼࡴࡪ࠭㌓"),l1l111_l1_ (u"ࠧ࡮ࡲࡧࠫ㌔"))
		if l1l1l111l1l_l1_:
			l1l111l1lll_l1_.setSubtitles([l1l1l111l1l_l1_])
	if l1l111l11l1_l1_==l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ㌕") and l1ll1ll11l1_l1_==l1l111_l1_ (u"ࠩࡇࡓ࡜ࡔࡌࡐࡃࡇࠫ㌖"):
		l1l11lll1ll_l1_ = l1l111_l1_ (u"ࠪࡴࡱࡧࡹࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ㌗")
		l1ll1ll11l1_l1_ = l1l111_l1_ (u"ࠫࡕࡒࡁ࡚ࡡࡇࡐࡤࡌࡉࡍࡇࡖࠫ㌘")
	elif l1l111l11l1_l1_==l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ㌙") and l1l11lll111_l1_.startswith(l1l111_l1_ (u"࠭࠶ࠨ㌚")):
		l1l11lll1ll_l1_ = l1l111_l1_ (u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥࠩ㌛")
		l1ll1ll11l1_l1_ = l1ll1ll11l1_l1_+l1l111_l1_ (u"ࠨࡡࡇࡐࠬ㌜")
	if l1l11lll1ll_l1_!=l1l111_l1_ (u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ㌝"): l1l1l1lll11_l1_()
	l1l1l111111_l1_ = l1l1l1l1l1l_l1_()
	l1l1l111111_l1_.init(l1ll1ll11l1_l1_)
	if l1l1l111111_l1_.l1l11lll1ll_l1_: l1l11lll1ll_l1_ == l1l111_l1_ (u"ࠪࠫ㌞")
	elif l1l111l11l1_l1_==l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ㌟") and not l1l11lll111_l1_.startswith(l1l111_l1_ (u"ࠬ࠼ࠧ㌠")):
		l1l111l1lll_l1_.setPath(url)
		l11llllll1_l1_(l1l111_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭㌡"),l11llll11l_l1_(l1ll1_l1_)+l1l111_l1_ (u"࡚ࠧࠡࠢࠣ࡮ࡪࡥࡰࠢࡳࡰࡦࡿࠠࡶࡵ࡬ࡲ࡬ࠦࡳࡦࡶࡕࡩࡸࡵ࡬ࡷࡧࡧ࡙ࡷࡲࠨࠪࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ㌢")+url+l1l111_l1_ (u"ࠨࠢࡠࠫ㌣"))
		xbmcplugin.setResolvedUrl(addon_handle,True,l1l111l1lll_l1_)
	elif l1l111l11l1_l1_==l1l111_l1_ (u"ࠩ࡯࡭ࡻ࡫ࠧ㌤"):
		l11llllll1_l1_(l1l111_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ㌥"),l11llll11l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠫࠥࠦࠠࡍ࡫ࡹࡩࠥࡶ࡬ࡢࡻࠣࡹࡸ࡯࡮ࡨࠢࡳࡰࡦࡿࠨࠪࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ㌦")+url+l1l111_l1_ (u"ࠬࠦ࡝ࠨ㌧"))
		l1l1l111111_l1_.play(url,l1l111l1lll_l1_)
	succeeded = False
	if l1l11lll1ll_l1_==l1l111_l1_ (u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤࠨ㌨"):
		from l11lll111l_l1_ import l11ll1lll1_l1_
		succeeded = l11ll1lll1_l1_(url,l11ll11ll1_l1_,l1ll1ll11l1_l1_)
		if succeeded: l1l1l1lll11_l1_()
	else:
		l1l111l111l_l1_,l1l11lll1ll_l1_,l1l1lllll1l_l1_,delay = 0,l1l111_l1_ (u"ࠧࡵࡴ࡬ࡩࡩ࠭㌩"),False,2
		if l1l1l1ll1ll_l1_: from LIBSTWO import l1ll1lll_l1_
		while l1l111l111l_l1_<30:
			l1l11lll1ll_l1_ = l1l1l111111_l1_.l1l11lll1ll_l1_
			if l1l11lll1ll_l1_==l1l111_l1_ (u"ࠨࡵࡷࡥࡷࡺࡥࡥࠩ㌪") and not l1l1lllll1l_l1_:
				if l1l1l1ll1ll_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠩส่ๆ๐ฯ๋๊้ࠣํา่ะࠩ㌫"),l1l111_l1_ (u"ࠪࠫ㌬"),time=500)
				l11llllll1_l1_(l1l111_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࡣࡑࡏࡎࡆࡕࠪ㌭"),l11llll11l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠬࠦࠠࠡࡕࡸࡧࡨ࡫ࡳࡴ࠼ࠣࠤ࡛࡯ࡤࡦࡱࠣࡷࡹࡧࡲࡵࡧࡧࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ㌮")+url+l1l111_l1_ (u"࠭ࠠ࡞ࠩ㌯")+l1l11lllll1_l1_)
				l1l1lllll1l_l1_ = True
			elif l1l11lll1ll_l1_ in [l1l111_l1_ (u"ࠧࡱ࡮ࡤࡽ࡮ࡴࡧࠨ㌰"),l1l111_l1_ (u"ࠨࡶࡨࡷࡹ࡯࡮ࡨࠩ㌱")]:
				if l1l1l1ll1ll_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠩส่ๆ๐ฯ๋๊ࠣ๎฾๋ไࠨ㌲"),l1l111_l1_ (u"ࠪࠫ㌳"),time=500)
				l11llllll1_l1_(l1l111_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࡣࡑࡏࡎࡆࡕࠪ㌴"),l11llll11l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠬࠦࠠࠡࡕࡸࡧࡨ࡫ࡳࡴ࠼ࠣࠤ࡛࡯ࡤࡦࡱࠣࡴࡱࡧࡹࡪࡰࡪࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ㌵")+url+l1l111_l1_ (u"࠭ࠠ࡞ࠩ㌶")+l1l11lllll1_l1_)
				break
			elif l1l11lll1ll_l1_==l1l111_l1_ (u"ࠧࡧࡣ࡬ࡰࡪࡪࠧ㌷"):
				l11llllll1_l1_(l1l111_l1_ (u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭㌸"),l11llll11l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠩࠣࠤࠥࡌࡡࡪ࡮ࡨࡨࠥࡶ࡬ࡢࡻ࡬ࡲ࡬ࠦࡶࡪࡦࡨࡳࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ㌹")+url+l1l111_l1_ (u"ࠪࠤࡢ࠭㌺")+l1l11lllll1_l1_)
				if l1l1l1ll1ll_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠫฬ๊แ๋ัํ์ࠥ็ุ๊่่่๊ࠢษࠨ㌻"),l1l111_l1_ (u"ࠬ࠭㌼"),time=500)
				break
			elif l1l11lll1ll_l1_==l1l111_l1_ (u"࠭ࡢ࡭ࡱࡦ࡯ࡪࡪࠧ㌽"):
				l11llllll1_l1_(l1l111_l1_ (u"ࠧࡆࡔࡕࡓࡗ࠭㌾"),l11llll11l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠨࠢࠣࠤࡉ࡫ࡶࡪࡥࡨࠤ࡮ࡹࠠࡣ࡮ࡲࡧࡰ࡫ࡤ࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫ㌿")+url+l1l111_l1_ (u"ࠩࠣࡡࠬ㍀"))
				break
			xbmc.sleep(delay*1000)
			l1l111l111l_l1_ += delay
		else:
			if l1l1l1ll1ll_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠪห้็๊ะ์๋ࠤ้๋๋ࠠ฻่่ࠬ㍁"),l1l111_l1_ (u"ࠫࠬ㍂"),time=500)
			l11llllll1_l1_(l1l111_l1_ (u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪ㍃"),l11llll11l_l1_(l1ll1_l1_)+l1l111_l1_ (u"࠭ࠠࠡࠢࡗ࡭ࡲ࡫࡯ࡶࡶ࠽ࠤ࡛ࠥ࡮࡬ࡰࡲࡻࡳࠦࡰࡳࡱࡥࡰࡪࡳࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ㍄")+url+l1l111_l1_ (u"ࠧࠡ࡟ࠪ㍅")+l1l11lllll1_l1_)
			l1l11lll1ll_l1_ = l1l111_l1_ (u"ࠨࡶ࡬ࡱࡪࡵࡵࡵࠩ㍆")
	if l1l11lll1ll_l1_ in [l1l111_l1_ (u"ࠩࡳࡰࡦࡿࡩ࡯ࡩࠪ㍇"),l1l111_l1_ (u"ࠪࡸࡪࡹࡴࡪࡰࡪࠫ㍈"),l1l111_l1_ (u"ࠫࡵࡲࡡࡺࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ㍉")] or succeeded:
		if l1l11lll1ll_l1_==l1l111_l1_ (u"ࠬࡺࡥࡴࡶ࡬ࡲ࡬࠭㍊"): l1ll1ll11l1_l1_ = l1ll1ll11l1_l1_+l1l111_l1_ (u"࠭࡟ࡕࡕࠪ㍋")
		response = l1l1llllll1_l1_(l1ll1ll11l1_l1_)
	else: exec(l1l111_l1_ (u"ࠧࡹࡤࡰࡧ࠳ࡖ࡬ࡢࡻࡨࡶ࠭࠯࠮ࡴࡶࡲࡴ࠭࠯ࠧ㍌"))
	return l1l11lll1ll_l1_
def l1l111l1l1_l1_(url,l1l11l11_l1_=l1l111_l1_ (u"ࠨࠩ㍍")):
	l11ll11ll1_l1_ = re.findall(l1l111_l1_ (u"ࠩࠫࡠ࠳ࡧࡶࡪࡾ࡟࠲ࡹࡹࡼ࡝࠰ࡤࡥࡨࢂ࡜࠯࡯ࡳ࠸ࢁࡢ࠮࡮࠵ࡸࢀࡡ࠴࡭࠴ࡷ࠻ࢀࡡ࠴࡭ࡱࡦࡿࡠ࠳ࡳ࡫ࡷࡾ࡟࠲࡫ࡲࡶࡽ࡞࠱ࡱࡵ࠹ࡼ࡝࠰ࡺࡩࡧࡳࠩࠩࡾ࡟ࡃ࠳࠰࠿ࡽ࠱࡟ࡃ࠳࠰࠿ࡽ࡞ࡿ࠲࠯ࡅࠩࠥࠩ㍎"),url.lower(),re.DOTALL|re.IGNORECASE)
	if l11ll11ll1_l1_: l11ll11ll1_l1_ = l11ll11ll1_l1_[0][0]
	else: l11ll11ll1_l1_ = l1l111_l1_ (u"ࠪࠫ㍏")
	return l11ll11ll1_l1_
WRITE_TO_sSQL3 = l1lll111111_l1_
READ_FROM_sSQL3 = l1lll11l111_l1_
DELETE_FROM_sSQL3 = l1lll1l1lll_l1_
EVALl = l1ll1l1_l1_
LOGGINGg = l11llll11l_l1_
LOGg_THIS = l11llllll1_l1_
PLAY_VIDEOo = l1llll111_l1_
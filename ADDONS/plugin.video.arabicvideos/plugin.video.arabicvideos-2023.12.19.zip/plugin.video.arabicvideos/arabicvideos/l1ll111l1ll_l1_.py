# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠬࡒࡁࡓࡑ࡝ࡅࠬピ")
l1lllll_l1_ = l1l111_l1_ (u"࠭࡟ࡍࡔ࡝ࡣࠬフ")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠧศๆุๅาฯࠠศๆิส๏ู๊สࠩブ"),l1l111_l1_ (u"ࠨࡕ࡬࡫ࡳࠦࡩ࡯ࠩプ"),l1l111_l1_ (u"ࠩส่ฬ่ำศ็ࠪヘ"),l1l111_l1_ (u"ࠪ฽ึ฼ࠠศๆ่ึ๏ีࠧベ")]
def l11l1ll_l1_(mode,url,text):
	if   mode==700: l1lll_l1_ = l1l1l11_l1_()
	elif mode==701: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==702: l1lll_l1_ = PLAY(url)
	elif mode==703: l1lll_l1_ = l1111_l1_(url,text)
	elif mode==704: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==709: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	l1l11ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࢀࡩ࡬ࡣ࠱࠽ࠬペ")
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩホ"),l1l11ll_l1_,l1l111_l1_ (u"࠭ࠧボ"),l1l111_l1_ (u"ࠧࠨポ"),l1l111_l1_ (u"ࠨࠩマ"),l1l111_l1_ (u"ࠩࠪミ"),l1l111_l1_ (u"ࠪࡐࡆࡘࡏ࡛ࡃ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬム"))
	html = response.content
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫメ"),l1lllll_l1_+l1l111_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬモ"),l1l111_l1_ (u"࠭ࠧャ"),709,l1l111_l1_ (u"ࠧࠨヤ"),l1l111_l1_ (u"ࠨࠩュ"),l1l111_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ユ"))
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨョ"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫヨ"),l1l111_l1_ (u"ࠬ࠭ラ"),9999)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭リ"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩル")+l1lllll_l1_+l1l111_l1_ (u"ࠨ็่๎ื࠭レ"),l1l11ll_l1_,701,l1l111_l1_ (u"ࠩࠪロ"),l1l111_l1_ (u"ࠪࠫヮ"),l1l111_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭ワ"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡶ࡭࠮ࡶࡲࡴ࠲ࡴࡡࡷࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡩ࡫ࡧࡨࡪࡴࠧヰ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴࠭ヱ"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		title = title.replace(l1l111_l1_ (u"ࠧ࠽ࡤࡁࠫヲ"),l1l111_l1_ (u"ࠨࠩン")).strip(l1l111_l1_ (u"ࠩࠣࠫヴ"))
		if title in l11lll_l1_: continue
		if l1ll1ll_l1_.endswith(l1l111_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽ࠳ࡶࡨࡱࠩヵ")): continue
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫヶ"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧヷ")+l1lllll_l1_+title,l1ll1ll_l1_,704)
	return
def l11ll1_l1_(url):
	found = False
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪヸ"),url,l1l111_l1_ (u"ࠧࠨヹ"),l1l111_l1_ (u"ࠨࠩヺ"),l1l111_l1_ (u"ࠩࠪ・"),l1l111_l1_ (u"ࠪࠫー"),l1l111_l1_ (u"ࠫࡑࡇࡒࡐ࡜ࡄ࠱ࡘ࡛ࡂࡎࡇࡑ࡙࠲࠷ࡳࡵࠩヽ"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠬࡸ࡯࡭ࡧࡀࠦࡲ࡫࡮ࡶࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ヾ"),html,re.DOTALL)
	if l11ll1l_l1_:
		block = l11ll1l_l1_[0]
		block = block.replace(l1l111_l1_ (u"࠭ࠢࡱࡴࡨࡷࡪࡴࡴࡢࡶ࡬ࡳࡳࠨࠧヿ"),l1l111_l1_ (u"ࠧ࠽࠱ࡸࡰࡃ࠭㄀"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡧࡶࡴࡶࡤࡰࡹࡱ࠱࡭࡫ࡡࡥࡧࡵࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡲࡩ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ㄁"),block,re.DOTALL)
		if not l11llll_l1_: l11llll_l1_ = [(l1l111_l1_ (u"ࠩࠪ㄂"),block)]
		addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㄃"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠโำีࠤศ๎ࠠโๆอีࠥษ่ࠡฬิฮ๏ฮࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㄄"),l1l111_l1_ (u"ࠬ࠭ㄅ"),9999)
		for l11111_l1_,block in l11llll_l1_:
			items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫㄆ"),block,re.DOTALL)
			if l11111_l1_: l11111_l1_ = l11111_l1_+l1l111_l1_ (u"ࠧ࠻ࠢࠪㄇ")
			for l1ll1ll_l1_,title in items:
				title = l11111_l1_+title
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨㄈ"),l1lllll_l1_+title,l1ll1ll_l1_,701)
				found = True
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡴࡲ࠳ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠮ࡵࡸࡦࡨࡧࡴࡴࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ㄉ"),html,re.DOTALL)
	if l11ll11_l1_:
		block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬㄊ"),block,re.DOTALL)
		if len(items)<30:
			if found: addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩㄋ"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬㄌ"),l1l111_l1_ (u"࠭ࠧㄍ"),9999)
			for l1ll1ll_l1_,title in items:
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧㄎ"),l1lllll_l1_+title,l1ll1ll_l1_,701)
				found = True
	l111ll111_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡥࡤࡸ࡫ࡵ࡯ࡵࡴࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨㄏ"),html,re.DOTALL)
	if l111ll111_l1_:
		block = l111ll111_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧㄐ"),block,re.DOTALL)
		if 1:
			if found: addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨㄑ"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫㄒ"),l1l111_l1_ (u"ࠬ࠭ㄓ"),9999)
			for l1ll1ll_l1_,title in items:
				title = title.strip(l1l111_l1_ (u"࠭ࠠࠨㄔ"))
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧㄕ"),l1lllll_l1_+title,l1ll1ll_l1_,701)
				found = True
	if not found: l1lll11_l1_(url)
	return
def l1lll11_l1_(url,request=l1l111_l1_ (u"ࠨࠩㄖ")):
	if request==l1l111_l1_ (u"ࠩࡤ࡮ࡦࡾ࠭ࡴࡧࡤࡶࡨ࡮ࠧㄗ"):
		url,search = url.split(l1l111_l1_ (u"ࠪࡃࠬㄘ"),1)
		data = l1l111_l1_ (u"ࠫࡶࡻࡥࡳࡻࡖࡸࡷ࡯࡮ࡨ࠿ࠪㄙ")+search
		headers = {l1l111_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫㄚ"):l1l111_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࡀࠦࡣࡩࡣࡵࡷࡪࡺ࠽ࡖࡖࡉ࠱࠽࠭ㄛ")}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡑࡑࡖࡘࠬㄜ"),url,data,headers,l1l111_l1_ (u"ࠨࠩㄝ"),l1l111_l1_ (u"ࠩࠪㄞ"),l1l111_l1_ (u"ࠪࡐࡆࡘࡏ࡛ࡃ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧㄟ"))
	else:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨㄠ"),url,l1l111_l1_ (u"ࠬ࠭ㄡ"),l1l111_l1_ (u"࠭ࠧㄢ"),l1l111_l1_ (u"ࠧࠨㄣ"),l1l111_l1_ (u"ࠨࠩㄤ"),l1l111_l1_ (u"ࠩࡏࡅࡗࡕ࡚ࡂ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠵ࡲࡩ࠭ㄥ"))
	html = response.content
	block,items = l1l111_l1_ (u"ࠪࠫㄦ"),[]
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨㄧ"))
	if request==l1l111_l1_ (u"ࠬࡧࡪࡢࡺ࠰ࡷࡪࡧࡲࡤࡪࠪㄨ"):
		block = html
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨㄩ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1l111_l1_ (u"ࠧࠨㄪ"),l1ll1ll_l1_,title))
	elif request==l1l111_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪㄫ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡬ࡨࡂࠨࡣࡰࡰࡷࡩࡳࡺࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫㄬ"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	elif request==l1l111_l1_ (u"ࠪࡲࡪࡽ࡟ࡦࡲ࡬ࡷࡴࡪࡥࡴࠩㄭ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡸ࡯ࡸࠢࡳࡱ࠲ࡻ࡬࠮ࡤࡵࡳࡼࡹࡥ࠮ࡸ࡬ࡨࡪࡵࡳࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫㄮ"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	elif request==l1l111_l1_ (u"ࠬࡴࡥࡸࡡࡰࡳࡻ࡯ࡥࡴࠩㄯ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡳࡱࡺࠤࡵࡳ࠭ࡶ࡮࠰ࡦࡷࡵࡷࡴࡧ࠰ࡺ࡮ࡪࡥࡰࡵࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭㄰"),html,re.DOTALL)
		if len(l11llll_l1_)>1: block = l11llll_l1_[1]
	elif request==l1l111_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࡡࡶࡩࡷ࡯ࡥࡴࠩㄱ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡥࡥࠥࡳࡧࡣࠢࡷࡥࡧࡲࡥࠡࡨࡸࡰࡱࠨࠨ࠯ࠬࡂ࠭ࠧࡩ࡬ࡦࡣࡵࡪ࡮ࡾࠢࠨㄲ"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨㄳ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1l111_l1_ (u"ࠪࠫㄴ"),l1ll1ll_l1_,title))
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࠭ࡪࡡࡵࡣ࠰ࡩࡨ࡮࡯࠾ࠤ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬㄵ"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	if block and not items: items = re.findall(l1l111_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡩࡨ࡮࡯࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ㄶ"),block,re.DOTALL)
	if not items: return
	l1l1_l1_ = []
	l1ll11_l1_ = [l1l111_l1_ (u"࠭ๅีษ๊ำฮ࠭ㄷ"),l1l111_l1_ (u"ࠧโ์็้ࠬㄸ"),l1l111_l1_ (u"ࠨษ฽๊๏ฯࠧㄹ"),l1l111_l1_ (u"ࠩๆ่๏ฮࠧㄺ"),l1l111_l1_ (u"ࠪห฾๊ว็ࠩㄻ"),l1l111_l1_ (u"ࠫ์ีวโࠩㄼ"),l1l111_l1_ (u"๋ࠬศศำสอࠬㄽ"),l1l111_l1_ (u"ู࠭าุࠪㄾ"),l1l111_l1_ (u"ࠧๆ้ิะฬ์ࠧㄿ"),l1l111_l1_ (u"ࠨษ็ฬํ๋ࠧㅀ"),l1l111_l1_ (u"่ࠩืึำ๊สࠩㅁ")]
	for l1ll1l_l1_,l1ll1ll_l1_,title in items:
		if l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࠨㅂ") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠫ࠴࠭ㅃ")+l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠬ࠵ࠧㅄ"))
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥ࠮วๅฯ็ๆฮࢂอๅไฬ࠭࠳ࡢࡤࠬࠩㅅ"),title,re.DOTALL)
		if any(value in title for value in l1ll11_l1_):
			addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ㅆ"),l1lllll_l1_+title,l1ll1ll_l1_,702,l1ll1l_l1_)
		elif request==l1l111_l1_ (u"ࠨࡰࡨࡻࡤ࡫ࡰࡪࡵࡲࡨࡪࡹࠧㅇ"):
			addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨㅈ"),l1lllll_l1_+title,l1ll1ll_l1_,702,l1ll1l_l1_)
		elif l1l1lll_l1_:
			title = l1l111_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩㅉ") + l1l1lll_l1_[0][0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫㅊ"),l1lllll_l1_+title,l1ll1ll_l1_,703,l1ll1l_l1_)
				l1l1_l1_.append(title)
		else: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬㅋ"),l1lllll_l1_+title,l1ll1ll_l1_,703,l1ll1l_l1_)
	if 1:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧㅌ"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬㅍ"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				if l1ll1ll_l1_==l1l111_l1_ (u"ࠨࠥࠪㅎ"): continue
				l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠩ࠲ࠫㅏ")+l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠪ࠳ࠬㅐ"))
				title = unescapeHTML(title)
				addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫㅑ"),l1lllll_l1_+l1l111_l1_ (u"ࠬ฻แฮหࠣࠫㅒ")+title,l1ll1ll_l1_,701)
	return
def l1111_l1_(url,l1l11_l1_):
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪㅓ"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫㅔ"),url,l1l111_l1_ (u"ࠨࠩㅕ"),l1l111_l1_ (u"ࠩࠪㅖ"),l1l111_l1_ (u"ࠪࠫㅗ"),l1l111_l1_ (u"ࠫࠬㅘ"),l1l111_l1_ (u"ࠬࡒࡁࡓࡑ࡝ࡅ࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠲ࡵࡷࠫㅙ"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡔࡧࡤࡷࡴࡴࡳࡃࡱࡻࠦ࠭࠴ࠪࡀࠫࠥࡗࡪࡧࡳࡰࡰࡶࡉࡵ࡯ࡳࡰࡦࡨࡷࡒࡧࡩ࡯ࠩㅚ"),html,re.DOTALL)
	l11l_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡵࡨࡶ࡮࡫ࡳ࠮ࡪࡨࡥࡩ࡫ࡲࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩㅛ"),html,re.DOTALL)
	if l11l_l1_: l1ll1l_l1_ = l11l_l1_[0]
	else: l1ll1l_l1_ = l1l111_l1_ (u"ࠨࠩㅜ")
	items = []
	l11l1_l1_ = False
	if l11ll1l_l1_ and not l1l11_l1_:
		block = l11ll1l_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩࠪࠫࡴࡶࡥ࡯ࡅ࡬ࡸࡾࡢࠨࡦࡸࡨࡲࡹ࠲ࠠࠨࠪ࠱࠮ࡄ࠯ࠧ࡝ࠫ࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡣࡷࡷࡸࡴࡴ࠾ࠨࠩࠪㅝ"),block,re.DOTALL)
		if not items: items = re.findall(l1l111_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡵࡨࡶ࡮࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴࠭ㅞ"),block,re.DOTALL)
		for l1l11_l1_,title in items:
			l1l11_l1_ = l1l11_l1_.strip(l1l111_l1_ (u"ࠫࠨ࠭ㅟ"))
			if len(items)>1: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬㅠ"),l1lllll_l1_+title,url,703,l1ll1l_l1_,l1l111_l1_ (u"࠭ࠧㅡ"),l1l11_l1_)
			else: l11l1_l1_ = True
	else: l11l1_l1_ = True
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡕࡨࡥࡸࡵ࡮ࡴࡇࡳ࡭ࡸࡵࡤࡦࡵࡐࡥ࡮ࡴࠨ࠯ࠬࡂ࠭ࡁࡹࡣࡳ࡫ࡳࡸࡃ࠭ㅢ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠨ࡫ࡧࡁࠧ࠭ㅣ")+l1l11_l1_+l1l111_l1_ (u"ࠩࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧㅤ"),block,re.DOTALL)
	if not l11ll11_l1_: l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡵࡨࡶ࡮࡫࠽ࠣࠩㅥ")+l1l11_l1_+l1l111_l1_ (u"ࠫࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪㅦ"),block,re.DOTALL)
	if not l11ll11_l1_: l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠬ࡯ࡤ࠾ࠤࡖࡩࡦࡹ࡯࡯ࠩㅧ")+l1l11_l1_+l1l111_l1_ (u"࠭ࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫㅨ"),block,re.DOTALL)
	if l11ll11_l1_ and l11l1_l1_:
		block = l11ll11_l1_[0]
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠢࡩࡴࡨࡪࡂ࠭ࠨ࠯ࠬࡂ࠭ࠬࡄ࠼࡭࡫ࡁࡀࡪࡳ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃࠨㅩ"),block,re.DOTALL)
		if not l1l1111_l1_: l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡩࡲࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂࠬㅪ"),block,re.DOTALL)
		items = []
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1ll1ll_l1_,title,l1ll1l_l1_))
		if not items: items = re.findall(l1l111_l1_ (u"ࠩࠥࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨㅫ"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
			l1ll1ll_l1_ = l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠪ࠲࠴࠭ㅬ"))
			l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠫ࠴࠭ㅭ")+l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠬ࠵ࠧㅮ"))
			title = title.replace(l1l111_l1_ (u"࠭࠼࠰ࡧࡰࡂࡁࡹࡰࡢࡰࡁࠫㅯ"),l1l111_l1_ (u"ࠧࠡࠩㅰ"))
			addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧㅱ"),l1lllll_l1_+title,l1ll1ll_l1_,702,l1ll1l_l1_)
	return
def PLAY(url):
	l1llll_l1_,l1ll11111_l1_,l1ll11l1_l1_ = [],[],[]
	l1lllll1_l1_ = url.replace(l1l111_l1_ (u"ࠩ࠲ࡺ࡮ࡪࡥࡰ࠰ࡳ࡬ࡵ࠭ㅲ"),l1l111_l1_ (u"ࠪ࠳ࡵࡲࡡࡺ࠰ࡳ࡬ࡵ࠭ㅳ"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨㅴ"),l1lllll1_l1_,l1l111_l1_ (u"ࠬ࠭ㅵ"),l1l111_l1_ (u"࠭ࠧㅶ"),l1l111_l1_ (u"ࠧࠨㅷ"),l1l111_l1_ (u"ࠨࠩㅸ"),l1l111_l1_ (u"ࠩࡏࡅࡗࡕ࡚ࡂ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫㅹ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦ࡜ࡧࡴࡤࡪࡖࡩࡷࡼࡥࡳࡵࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾࠯࠾࠲ࡨ࡮ࡼ࠾ࠨㅺ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡖ࡬ࡢࡻࡨࡶ࡭ࡵ࡬ࡥࡧࡵࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬㅻ"),block,re.DOTALL)
		if l1ll1ll_l1_:
			l1ll1ll_l1_ = l1ll1ll_l1_[0]
			l1ll11111_l1_.append(l1l111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂࡥ࡟ࡦ࡯ࡥࡩࡩ࠭ㅼ"))
			l1llll_l1_.append(l1ll1ll_l1_)
		l1ll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡪࡳࡢࡦࡦࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼࠰ࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡢࡶࡶࡷࡳࡳࡄࠧㅽ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1ll_l1_:
			title = title.strip(l1l111_l1_ (u"ࠧࠡࠩㅾ"))
			if l1ll1ll_l1_ not in l1llll_l1_:
				l1ll11111_l1_.append(l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩㅿ")+title+l1l111_l1_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪㆀ"))
				l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡉࡵࡷ࡯࡮ࡲࡥࡩ࡙ࡥࡳࡸࡨࡶࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪㆁ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬㆂ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1ll_l1_:
			if l1ll1ll_l1_ not in l1llll_l1_:
				title = title.strip(l1l111_l1_ (u"ࠬࡢ࡮ࠨㆃ"))
				l1ll11111_l1_.append(l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧㆄ")+title+l1l111_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫㆅ"))
				l1llll_l1_.append(l1ll1ll_l1_)
	l1lll1l_l1_ = zip(l1llll_l1_,l1ll11111_l1_)
	for l1ll1ll_l1_,name in l1lll1l_l1_: l1ll11l1_l1_.append(l1ll1ll_l1_+name)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll11l1_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧㆆ"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠩࠪㆇ"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠪࠫㆈ"): return
	search = search.replace(l1l111_l1_ (u"ࠫࠥ࠭ㆉ"),l1l111_l1_ (u"ࠬ࠱ࠧㆊ"))
	url = l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠮ࡱࡪࡳࡃࡰ࡫ࡹࡸࡱࡵࡨࡸࡃࠧㆋ")+search
	l1lll11_l1_(url,l1l111_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࠧㆌ"))
	return
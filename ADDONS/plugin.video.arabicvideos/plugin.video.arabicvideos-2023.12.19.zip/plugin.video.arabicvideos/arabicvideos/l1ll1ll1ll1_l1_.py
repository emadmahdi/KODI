# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠪࡍࡋࡏࡌࡎࠩ⸖")
l1lllll_l1_ = l1l111_l1_ (u"ࠫࡤࡏࡆࡍࡡࠪ⸗")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l1l1l1l1l1_l1_ = l1l11l1_l1_[l1ll1_l1_][1]
l1ll1l1l1ll_l1_ = l1l11l1_l1_[l1ll1_l1_][2]
l1ll1l1ll1l_l1_ = l1l11l1_l1_[l1ll1_l1_][3]
def l11l1ll_l1_(mode,url,l1llllll1_l1_,text):
	if   mode==20: l1lll_l1_ = l1ll1l1lll1_l1_()
	elif mode==21: l1lll_l1_ = l1l1l11_l1_(url)
	elif mode==22: l1lll_l1_ = l1lll11_l1_(url,l1llllll1_l1_)
	elif mode==23: l1lll_l1_ = l1ll1l11_l1_(url,l1llllll1_l1_)
	elif mode==24: l1lll_l1_ = PLAY(url,text)
	elif mode==25: l1lll_l1_ = l1ll1l111l1_l1_(url)
	elif mode==27: l1lll_l1_ = l1ll1llll_l1_(url)
	elif mode==28: l1lll_l1_ = l1ll1ll1111_l1_()
	elif mode==29: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1ll1l1lll1_l1_():
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⸘"),l1lllll_l1_+l1l111_l1_ (u"ู࠭าสํࠫ⸙"),l111l1_l1_,21,l1l111_l1_ (u"ࠧࠨ⸚"),l1l111_l1_ (u"ࠨ࠳࠳࠵ࠬ⸛"))
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⸜"),l1lllll_l1_+l1l111_l1_ (u"ࠪࡉࡳ࡭࡬ࡪࡵ࡫ࠫ⸝"),l1l1l1l1l1_l1_,21,l1l111_l1_ (u"ࠫࠬ⸞"),l1l111_l1_ (u"ࠬ࠷࠰࠲ࠩ⸟"))
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⸠"),l1lllll_l1_+l1l111_l1_ (u"ࠧโษิื๎࠭⸡"),l1ll1l1l1ll_l1_,21,l1l111_l1_ (u"ࠨࠩ⸢"),l1l111_l1_ (u"ࠩ࠴࠴࠶࠭⸣"))
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⸤"),l1lllll_l1_+l1l111_l1_ (u"ࠫๆอัิ๋ࠣ࠶ࠬ⸥"),l1ll1l1ll1l_l1_,21,l1l111_l1_ (u"ࠬ࠭⸦"),l1l111_l1_ (u"࠭࠱࠱࠳ࠪ⸧"))
	return
def l1ll1ll1111_l1_():
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡹࡩࠬ⸨"),l1lllll_l1_+l1l111_l1_ (u"ࠨ฻ิฬ๏࠭⸩"),l111l1_l1_,27)
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡻ࡫ࠧ⸪"),l1lllll_l1_+l1l111_l1_ (u"ࠪࡉࡳ࡭࡬ࡪࡵ࡫ࠫ⸫"),l1l1l1l1l1_l1_,27)
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯ࡶࡦࠩ⸬"),l1lllll_l1_+l1l111_l1_ (u"ࠬ็วาี์ࠫ⸭"),l1ll1l1l1ll_l1_,27)
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡸࡨࠫ⸮"),l1lllll_l1_+l1l111_l1_ (u"ࠧโษิื๎ࠦ࠲ࠨⸯ"),l1ll1l1ll1l_l1_,27)
	return
def l1l1l11_l1_(l1ll1ll111l_l1_):
	l1ll1_l1_ = l1ll1ll111l_l1_
	if l1ll1ll111l_l1_==l1l111_l1_ (u"ࠨࡋࡉࡍࡑࡓ࠭ࡂࡔࡄࡆࡎࡉࠧ⸰"): l1ll1ll111l_l1_ = l111l1_l1_
	elif l1ll1ll111l_l1_==l1l111_l1_ (u"ࠩࡌࡊࡎࡒࡍ࠮ࡇࡑࡋࡑࡏࡓࡉࠩ⸱"): l1ll1ll111l_l1_ = l1l1l1l1l1_l1_
	else: l1ll1_l1_ = l1l111_l1_ (u"ࠪࠫ⸲")
	l1lllll1111_l1_ = l1ll1ll11ll_l1_(l1ll1ll111l_l1_)
	if l1lllll1111_l1_==l1l111_l1_ (u"ࠫࡦࡸࠧ⸳") or l1ll1_l1_==l1l111_l1_ (u"ࠬࡏࡆࡊࡎࡐ࠱ࡆࡘࡁࡃࡋࡆࠫ⸴"):
		l1ll1l11l11_l1_ = l1l111_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭⸵")
		l1ll1l111ll_l1_ = l1l111_l1_ (u"ࠧๆี็ื้อสࠡ࠯ࠣัฬ๊๊สࠩ⸶")
		l1llllllll1_l1_ = l1l111_l1_ (u"ࠨ็ึุ่๊วหࠢ࠰ࠤศำฯฬࠩ⸷")
		l1ll1l11l1l_l1_ = l1l111_l1_ (u"่ࠩืู้ไศฬࠣ࠱ࠥษศอัํࠫ⸸")
		l1ll1l11lll_l1_ = l1l111_l1_ (u"ࠪฬะࠦอ๋ࠢล๎ࠥ็๊ๅ็ࠪ⸹")
		l1ll1l11ll1_l1_ = l1l111_l1_ (u"ࠫศ็ไศ็ࠪ⸺")
		l1ll1l1l11l_l1_ = l1l111_l1_ (u"๋่ࠬิ์ๅํࠬ⸻")
		l1ll1l1l111_l1_ = l1l111_l1_ (u"࠭ศาษ่ะࠬ⸼")
	elif l1lllll1111_l1_==l1l111_l1_ (u"ࠧࡦࡰࠪ⸽") or l1ll1_l1_==l1l111_l1_ (u"ࠨࡋࡉࡍࡑࡓ࠭ࡆࡐࡊࡐࡎ࡙ࡈࠨ⸾"):
		l1ll1l11l11_l1_ = l1l111_l1_ (u"ࠩࡖࡩࡦࡸࡣࡩࠢ࡬ࡲࠥࡹࡩࡵࡧࠪ⸿")
		l1ll1l111ll_l1_ = l1l111_l1_ (u"ࠪࡗࡪࡸࡩࡦࡵࠣ࠱ࠥࡉࡵࡳࡴࡨࡲࡹ࠭⹀")
		l1llllllll1_l1_ = l1l111_l1_ (u"ࠫࡘ࡫ࡲࡪࡧࡶࠤ࠲ࠦࡌࡢࡶࡨࡷࡹ࠭⹁")
		l1ll1l11l1l_l1_ = l1l111_l1_ (u"࡙ࠬࡥࡳ࡫ࡨࡷࠥ࠳ࠠࡂ࡮ࡳ࡬ࡦࡨࡥࡵࠩ⹂")
		l1ll1l11lll_l1_ = l1l111_l1_ (u"࠭ࡌࡪࡸࡨࠤ࡮ࡌࡩ࡭࡯ࠣࡧ࡭ࡧ࡮࡯ࡧ࡯ࠫ⹃")
		l1ll1l11ll1_l1_ = l1l111_l1_ (u"ࠧࡎࡱࡹ࡭ࡪࡹࠧ⹄")
		l1ll1l1l11l_l1_ = l1l111_l1_ (u"ࠨࡏࡸࡷ࡮ࡩࠧ⹅")
		l1ll1l1l111_l1_ = l1l111_l1_ (u"ࠩࡖ࡬ࡴࡽࡳࠨ⹆")
	elif l1lllll1111_l1_ in [l1l111_l1_ (u"ࠪࡪࡦ࠭⹇"),l1l111_l1_ (u"ࠫ࡫ࡧ࠲ࠨ⹈")]:
		l1ll1l11l11_l1_ = l1l111_l1_ (u"ࠬาำหฮ๋ࠤิืࠠิษ໏ฮࠬ⹉")
		l1ll1l111ll_l1_ = l1l111_l1_ (u"࠭ำา์ส่ࠥ࠳ࠠอษิ໐ࠬ⹊")
		l1llllllll1_l1_ = l1l111_l1_ (u"ࠧิำํห้ࠦ࠭ࠡฤัี໑์ࠧ⹋")
		l1ll1l11l1l_l1_ = l1l111_l1_ (u"ࠨีิ๎ฬ๊ࠠ࠮ࠢส่ๆฮวࠨ⹌")
		l1ll1l11lll_l1_ = l1l111_l1_ (u"ࠩກาูࠦา็ั๊ࠤฬ๐ࠠโ์็้ࠬ⹍")
		l1ll1l11ll1_l1_ = l1l111_l1_ (u"ࠪๅ๏๊ๅࠨ⹎")
		l1ll1l1l11l_l1_ = l1l111_l1_ (u"๊ࠫ๎ำ๋ไ์ࠫ⹏")
		l1ll1l1l111_l1_ = l1l111_l1_ (u"ࠬฮั็ษ่๋ࠥํวࠨ⹐")
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⹑"),l1lllll_l1_+l1ll1l11l11_l1_,l1ll1ll111l_l1_,29,l1l111_l1_ (u"ࠧࠨ⹒"),l1l111_l1_ (u"ࠨࠩ⹓"),l1l111_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭⹔"))
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡼࡥࠨ⹕"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭⹖")+l1lllll_l1_+l1ll1l11lll_l1_,l1ll1ll111l_l1_,27)
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ⹗"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞࠳ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥ࠷࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ⹘"),l1l111_l1_ (u"ࠧࠨ⹙"),9999)
	l1llll1ll11_l1_ = [l1l111_l1_ (u"ࠨࡕࡨࡶ࡮࡫ࡳࠨ⹚"),l1l111_l1_ (u"ࠩࡓࡶࡴ࡭ࡲࡢ࡯ࠪ⹛"),l1l111_l1_ (u"ࠪࡑࡺࡹࡩࡤࠩ⹜")]
	html = l1l1llll_l1_(l1ll1ll1_l1_,l1ll1ll111l_l1_+l1l111_l1_ (u"ࠫ࠴࡮࡯࡮ࡧࠪ⹝"),l1l111_l1_ (u"ࠬ࠭⹞"),l1l111_l1_ (u"࠭ࠧ⹟"),l1l111_l1_ (u"ࠧࠨ⹠"),l1l111_l1_ (u"ࠨࡋࡉࡍࡑࡓ࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ⹡"))
	l11llll_l1_=re.findall(l1l111_l1_ (u"ࠩࡥࡹࡹࡺ࡯࡯࠯ࡰࡩࡳࡻࠨ࠯ࠬࡂ࠭࠴ࡉ࡯࡯ࡶࡤࡧࡹ࠭⹢"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ⹣"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if any(value in l1ll1ll_l1_ for value in l1llll1ll11_l1_):
				url = l1ll1ll111l_l1_+l1ll1ll_l1_
				if l1l111_l1_ (u"ࠫࡘ࡫ࡲࡪࡧࡶࠫ⹤") in l1ll1ll_l1_:
					addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⹥"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ⹦")+l1lllll_l1_+l1ll1l111ll_l1_,url,22,l1l111_l1_ (u"ࠧࠨ⹧"),l1l111_l1_ (u"ࠨ࠳࠳࠴ࠬ⹨"))
					addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⹩"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ⹪")+l1lllll_l1_+l1llllllll1_l1_,url,22,l1l111_l1_ (u"ࠫࠬ⹫"),l1l111_l1_ (u"ࠬ࠷࠰࠲ࠩ⹬"))
					addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⹭"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ⹮")+l1lllll_l1_+l1ll1l11l1l_l1_,url,22,l1l111_l1_ (u"ࠨࠩ⹯"),l1l111_l1_ (u"ࠩ࠵࠴࠶࠭⹰"))
				elif l1l111_l1_ (u"ࠪࡊ࡮ࡲ࡭ࠨ⹱") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⹲"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ⹳")+l1lllll_l1_+l1ll1l11ll1_l1_,url,22,l1l111_l1_ (u"࠭ࠧ⹴"),l1l111_l1_ (u"ࠧ࠲࠲࠳ࠫ⹵"))
				elif l1l111_l1_ (u"ࠨࡏࡸࡷ࡮ࡩࠧ⹶") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⹷"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ⹸")+l1lllll_l1_+l1ll1l1l11l_l1_,url,25,l1l111_l1_ (u"ࠫࠬ⹹"),l1l111_l1_ (u"ࠬ࠷࠰࠲ࠩ⹺"))
				elif l1l111_l1_ (u"࠭ࡐࡳࡱࡪࡶࡦࡳࠧ⹻") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⹼"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ⹽")+l1lllll_l1_+l1ll1l1l111_l1_,url,22,l1l111_l1_ (u"ࠩࠪ⹾"),l1l111_l1_ (u"ࠪ࠵࠵࠷ࠧ⹿"))
	return html
def l1ll1l111l1_l1_(url):
	l1ll1ll111l_l1_ = l1ll1l1l1l1_l1_(url)
	html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"ࠫࠬ⺀"),l1l111_l1_ (u"ࠬ࠭⺁"),l1l111_l1_ (u"࠭ࠧ⺂"),l1l111_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠳ࡍࡖࡕࡌࡇࡤࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ⺃"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡏࡸࡷ࡮ࡩ࠭ࡵࡱࡲࡰࡸ࠳ࡨࡦࡣࡧࡩࡷ࠮࠮ࠫࡁࠬࡑࡺࡹࡩࡤ࠯ࡥࡳࡩࡿࠧ⺄"),html,re.DOTALL)
	block = l11llll_l1_[0]
	title = re.findall(l1l111_l1_ (u"ࠩ࠿ࡴࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡶ࠾ࠨ⺅"),block,re.DOTALL)[0]
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⺆"),l1lllll_l1_+title,url,22,l1l111_l1_ (u"ࠫࠬ⺇"),l1l111_l1_ (u"ࠬ࠷࠰࠲ࠩ⺈"))
	items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ⺉"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		l1ll1ll_l1_ = l1ll1ll111l_l1_ + l1ll1ll_l1_
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⺊"),l1lllll_l1_+title,l1ll1ll_l1_,23,l1l111_l1_ (u"ࠨࠩ⺋"),l1l111_l1_ (u"ࠩ࠴࠴࠶࠭⺌"))
	return
def l1lll11_l1_(url,l1llllll1_l1_):
	l1ll1ll111l_l1_ = l1ll1l1l1l1_l1_(url)
	l1lllll1111_l1_ = l1ll1ll11ll_l1_(url)
	type = url.split(l1l111_l1_ (u"ࠪ࠳ࠬ⺍"))[-1]
	l1ll11lllll_l1_ = str(int(l1llllll1_l1_)//100)
	l1llllll1_l1_ = str(int(l1llllll1_l1_)%100)
	if type==l1l111_l1_ (u"ࠫࡘ࡫ࡲࡪࡧࡶࠫ⺎") and l1llllll1_l1_==l1l111_l1_ (u"ࠬ࠶ࠧ⺏"):
		html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"࠭ࠧ⺐"),l1l111_l1_ (u"ࠧࠨ⺑"),l1l111_l1_ (u"ࠨࠩ⺒"),l1l111_l1_ (u"ࠩࡌࡊࡎࡒࡍ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬ⺓"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡷࡪࡸࡩࡢ࡮࠰ࡦࡴࡪࡹࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧࡸ࡯ࡸࠩ⺔"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠫ࠲࠯ࡅࠩ࠿࠰࠭ࡃ࡭࠹࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ⺕"),block,re.DOTALL)
		for l1ll1ll_l1_,l1ll1l_l1_,title in items:
			title = escapeUNICODE(title)
			title = unescapeHTML(title)
			l1ll1ll_l1_ = l1ll1ll111l_l1_ + l1ll1ll_l1_
			l1ll1l_l1_ = l1ll1ll111l_l1_ + QUOTE(l1ll1l_l1_)
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⺖"),l1lllll_l1_+title,l1ll1ll_l1_,23,l1ll1l_l1_,l1ll11lllll_l1_+l1l111_l1_ (u"࠭࠰࠲ࠩ⺗"))
	l1ll1l11111_l1_=0
	if type==l1l111_l1_ (u"ࠧࡔࡧࡵ࡭ࡪࡹࠧ⺘"): category=l1l111_l1_ (u"ࠨ࠵ࠪ⺙")
	if type==l1l111_l1_ (u"ࠩࡉ࡭ࡱࡳࠧ⺚"): category=l1l111_l1_ (u"ࠪ࠹ࠬ⺛")
	if type==l1l111_l1_ (u"ࠫࡕࡸ࡯ࡨࡴࡤࡱࠬ⺜"): category=l1l111_l1_ (u"ࠬ࠽ࠧ⺝")
	if type in [l1l111_l1_ (u"࠭ࡓࡦࡴ࡬ࡩࡸ࠭⺞"),l1l111_l1_ (u"ࠧࡑࡴࡲ࡫ࡷࡧ࡭ࠨ⺟"),l1l111_l1_ (u"ࠨࡈ࡬ࡰࡲ࠭⺠")] and l1llllll1_l1_!=l1l111_l1_ (u"ࠩ࠳ࠫ⺡"):
		l1lllll1_l1_ = l1ll1ll111l_l1_+l1l111_l1_ (u"ࠪ࠳ࡍࡵ࡭ࡦ࠱ࡓࡥ࡬࡫ࡩ࡯ࡩࡌࡸࡪࡳ࠿ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠿ࠪ⺢")+category+l1l111_l1_ (u"ࠫࠫࡶࡡࡨࡧࡀࠫ⺣")+l1llllll1_l1_+l1l111_l1_ (u"ࠬࠬࡳࡪࡼࡨࡁ࠸࠶ࠦࡰࡴࡧࡩࡷࡨࡹ࠾ࠩ⺤")+l1ll11lllll_l1_
		html = l1l1llll_l1_(l11l1l1_l1_,l1lllll1_l1_,l1l111_l1_ (u"࠭ࠧ⺥"),l1l111_l1_ (u"ࠧࠨ⺦"),l1l111_l1_ (u"ࠨࠩ⺧"),l1l111_l1_ (u"ࠩࡌࡊࡎࡒࡍ࠮ࡖࡌࡘࡑࡋࡓ࠮࠴ࡱࡨࠬ⺨"))
		items = re.findall(l1l111_l1_ (u"ࠪࠦࡎࡪࠢ࠻ࠪ࠱࠮ࡄ࠯ࠬࠣࡖ࡬ࡸࡱ࡫ࠢ࠻ࠪ࠱࠮ࡄ࠯ࠬ࠯࠭ࡂࠦࡎࡳࡡࡨࡧࡄࡨࡩࡸࡥࡴࡵࡢࡗࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⺩"),html,re.DOTALL)
		for id,title,l1ll1l_l1_ in items:
			title = escapeUNICODE(title)
			title = title.replace(l1l111_l1_ (u"ࠫࡡࡢࠧ⺪"),l1l111_l1_ (u"ࠬ࠭⺫"))
			title = title.replace(l1l111_l1_ (u"࠭ࠢࠨ⺬"),l1l111_l1_ (u"ࠧࠨ⺭"))
			l1ll1l11111_l1_ += 1
			l1ll1ll_l1_ = l1ll1ll111l_l1_ + l1l111_l1_ (u"ࠨ࠱ࠪ⺮") + type + l1l111_l1_ (u"ࠩ࠲ࡇࡴࡴࡴࡦࡰࡷ࠳ࠬ⺯") + id
			l1ll1l_l1_ = l1ll1ll111l_l1_ + QUOTE(l1ll1l_l1_)
			if type==l1l111_l1_ (u"ࠪࡊ࡮ࡲ࡭ࠨ⺰"): addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ⺱"),l1lllll_l1_+title,l1ll1ll_l1_,24,l1ll1l_l1_,l1ll11lllll_l1_+l1l111_l1_ (u"ࠬ࠶࠱ࠨ⺲"))
			else: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⺳"),l1lllll_l1_+title,l1ll1ll_l1_,23,l1ll1l_l1_,l1ll11lllll_l1_+l1l111_l1_ (u"ࠧ࠱࠳ࠪ⺴"))
	if type==l1l111_l1_ (u"ࠨࡏࡸࡷ࡮ࡩࠧ⺵"):
		html = l1l1llll_l1_(l11l1l1_l1_,l1ll1ll111l_l1_+l1l111_l1_ (u"ࠩ࠲ࡑࡺࡹࡩࡤ࠱ࡌࡲࡩ࡫ࡸࡀࡲࡤ࡫ࡪࡃࠧ⺶")+l1llllll1_l1_,l1l111_l1_ (u"ࠪࠫ⺷"),l1l111_l1_ (u"ࠫࠬ⺸"),l1l111_l1_ (u"ࠬ࠭⺹"),l1l111_l1_ (u"࠭ࡉࡇࡋࡏࡑ࠲࡚ࡉࡕࡎࡈࡗ࠲࠹ࡲࡥࠩ⺺"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱ࠱ࡩ࡫࡭ࡰࠪ࠱࠮ࡄ࠯ࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰ࠰ࡨࡪࡳ࡯ࠨ⺻"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࡬࠸ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡨ࠴ࡀࠪ⺼"),block,re.DOTALL)
		for l1ll1ll_l1_,l1ll1l_l1_,title in items:
			l1ll1l11111_l1_ += 1
			l1ll1l_l1_ = l1ll1ll111l_l1_ + l1ll1l_l1_
			l1ll1ll_l1_ = l1ll1ll111l_l1_ + l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⺽"),l1lllll_l1_+title,l1ll1ll_l1_,23,l1ll1l_l1_,l1l111_l1_ (u"ࠪ࠵࠵࠷ࠧ⺾"))
	if l1ll1l11111_l1_>20:
		title=l1l111_l1_ (u"ฺࠫ็อสࠢࠪ⺿")
		if l1lllll1111_l1_==l1l111_l1_ (u"ࠬ࡫࡮ࠨ⻀"): title = l1l111_l1_ (u"࠭ࡐࡢࡩࡨࠤࠬ⻁")
		if l1lllll1111_l1_==l1l111_l1_ (u"ࠧࡧࡣࠪ⻂"): title = l1l111_l1_ (u"ࠨืไั์ࠦࠧ⻃")
		if l1lllll1111_l1_==l1l111_l1_ (u"ࠩࡩࡥ࠷࠭⻄"): title = l1l111_l1_ (u"ูࠪๆำ็ࠡࠩ⻅")
		for l1ll1l1ll11_l1_ in range(1,11) :
			if not l1llllll1_l1_==str(l1ll1l1ll11_l1_):
				l1ll1l1111l_l1_ = l1l111_l1_ (u"ࠫ࠵࠭⻆")+str(l1ll1l1ll11_l1_)
				addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⻇"),l1lllll_l1_+title+str(l1ll1l1ll11_l1_),url,22,l1l111_l1_ (u"࠭ࠧ⻈"),l1ll11lllll_l1_+l1ll1l1111l_l1_[-2:])
	return
def l1ll1l11_l1_(url,l1llllll1_l1_):
	if not l1llllll1_l1_: l1llllll1_l1_ = 0
	l1ll1ll111l_l1_ = l1ll1l1l1l1_l1_(url)
	l1ll1ll11l1_l1_ = l1ll1l1l1l1_l1_(url)
	l1lllll1111_l1_ = l1ll1ll11ll_l1_(url)
	parts = url.split(l1l111_l1_ (u"ࠧ࠰ࠩ⻉"))
	id,type = parts[-1],parts[3]
	l1ll11lllll_l1_ = str(int(l1llllll1_l1_)//100)
	l1llllll1_l1_ = str(int(l1llllll1_l1_)%100)
	l1ll1l11111_l1_ = 0
	if type==l1l111_l1_ (u"ࠨࡕࡨࡶ࡮࡫ࡳࠨ⻊"):
		html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠩࠪ⻋"),l1l111_l1_ (u"ࠪࠫ⻌"),l1l111_l1_ (u"ࠫࠬ⻍"),l1l111_l1_ (u"ࠬࡏࡆࡊࡎࡐ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪ⻎"))
		items = re.findall(l1l111_l1_ (u"࠭ࡃࡰ࡯ࡰࡩࡳࡺ࡟ࡱࡣࡱࡩࡱࡥࡉࡵࡧࡰ࠲࠯ࡅࡰ࠿ࠪ࠱࠮ࡄ࠯࠼ࡪ࠰࠮ࡃࡻࡧࡲࠡ࡫ࡱࡸࡪࡸ࡟ࠡ࠿ࠣࠬ࠳࠰࠿ࠪ࠽࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪ࡞ࠪ࠲࠯ࡅࡤࡢࡶࡤ࠱ࡺࡸ࡬࠾ࠤࠫ࠲࠯ࡅࠩ࡝ࠩࠪ⻏"),html,re.DOTALL)
		title = l1l111_l1_ (u"ࠧࠡ࠯ࠣห้ำไใหࠣࠫ⻐")
		if l1lllll1111_l1_==l1l111_l1_ (u"ࠨࡧࡱࠫ⻑"): title = l1l111_l1_ (u"ࠩࠣ࠱ࠥࡋࡰࡪࡵࡲࡨࡪࠦࠧ⻒")
		if l1lllll1111_l1_==l1l111_l1_ (u"ࠪࡪࡦ࠭⻓"): title = l1l111_l1_ (u"ࠫࠥ࠳ࠠใี่ฮࠥ࠭⻔")
		if l1lllll1111_l1_==l1l111_l1_ (u"ࠬ࡬ࡡ࠳ࠩ⻕"): title = l1l111_l1_ (u"࠭ࠠ࠮ࠢๅื๊ะࠠࠨ⻖")
		if l1lllll1111_l1_==l1l111_l1_ (u"ࠧࡧࡣࠪ⻗"): l1ll1l1llll_l1_ = l1l111_l1_ (u"ࠨࠩ⻘")
		else: l1ll1l1llll_l1_ = l1lllll1111_l1_
		l1ll1ll1l1l_l1_ = re.findall(l1l111_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡷ࡫ࡧࡩࡴࡃࠢࠩ࠰࠭ࡃ࠮࠮࡜ࠨ࠰࠭ࡃࡡ࠭࡟ࠪࠪ࠱࠮ࡄ࠯ࠢ࠿ࠩ⻙"),html,re.DOTALL)
		for name,count,l1ll1l_l1_,l1ll1ll_l1_ in items:
			for l1l1lll_l1_ in range(int(count),0,-1):
				l1ll1ll1l11_l1_ = l1ll1l_l1_ + l1ll1l1llll_l1_ + id + l1l111_l1_ (u"ࠪ࠳ࠬ⻚") + str(l1l1lll_l1_) + l1l111_l1_ (u"ࠫ࠳ࡶ࡮ࡨࠩ⻛")
				l1ll1l111ll_l1_ = name + title + str(l1l1lll_l1_)
				l1ll1l111ll_l1_ = unescapeHTML(l1ll1l111ll_l1_)
				addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ⻜"),l1lllll_l1_+l1ll1l111ll_l1_,url,24,l1ll1ll1l11_l1_,l1l111_l1_ (u"࠭ࠧ⻝"),str(l1l1lll_l1_))
	elif type==l1l111_l1_ (u"ࠧࡑࡴࡲ࡫ࡷࡧ࡭ࠨ⻞"):
		l1lllll1_l1_ = l1ll1ll111l_l1_+l1l111_l1_ (u"ࠨ࠱ࡋࡳࡲ࡫࠯ࡑࡣࡪࡩ࡮ࡴࡧࡂࡶࡷࡥࡨ࡮࡭ࡦࡰࡷࡍࡹ࡫࡭ࡀ࡫ࡧࡁࠬ⻟")+str(id)+l1l111_l1_ (u"ࠩࠩࡴࡦ࡭ࡥ࠾ࠩ⻠")+l1llllll1_l1_+l1l111_l1_ (u"ࠪࠪࡸ࡯ࡺࡦ࠿࠶࠴ࠫࡵࡲࡥࡧࡵࡦࡾࡃ࠱ࠨ⻡")
		html = l1l1llll_l1_(l11l1l1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠫࠬ⻢"),l1l111_l1_ (u"ࠬ࠭⻣"),l1l111_l1_ (u"࠭ࠧ⻤"),l1l111_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠴ࡱࡨࠬ⻥"))
		items = re.findall(l1l111_l1_ (u"ࠨࡇࡳ࡭ࡸࡵࡤࡦࠤ࠽ࠬ࠳࠰࠿ࠪ࠮࠱࠮ࡄࡏ࡭ࡢࡩࡨࡅࡩࡪࡲࡦࡵࡶࡣࡘࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡚࡮ࡪࡥࡰࡃࡧࡨࡷ࡫ࡳࡴࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡄࡪࡵࡦࡶ࡮ࡶࡴࡪࡱࡱࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡅࡤࡴࡹ࡯࡯࡯ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ⻦"),html,re.DOTALL)
		title = l1l111_l1_ (u"ࠩࠣ࠱ࠥอไฮๆๅอࠥ࠭⻧")
		if l1lllll1111_l1_==l1l111_l1_ (u"ࠪࡩࡳ࠭⻨"): title = l1l111_l1_ (u"ࠫࠥ࠳ࠠࡆࡲ࡬ࡷࡴࡪࡥࠡࠩ⻩")
		if l1lllll1111_l1_==l1l111_l1_ (u"ࠬ࡬ࡡࠨ⻪"): title = l1l111_l1_ (u"࠭ࠠ࠮ࠢๅื๊ะࠠࠨ⻫")
		if l1lllll1111_l1_==l1l111_l1_ (u"ࠧࡧࡣ࠵ࠫ⻬"): title = l1l111_l1_ (u"ࠨࠢ࠰ࠤ็ูๅหࠢࠪ⻭")
		for l1l1lll_l1_,l1ll1l_l1_,l1ll1ll_l1_,desc,name in items:
			l1ll1l11111_l1_ += 1
			l1ll1ll1l11_l1_ = l1ll1ll11l1_l1_ + QUOTE(l1ll1l_l1_)
			name = escapeUNICODE(name)
			l1ll1l111ll_l1_ = name + title + str(l1l1lll_l1_)
			addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ⻮"),l1lllll_l1_+l1ll1l111ll_l1_,l1lllll1_l1_,24,l1ll1ll1l11_l1_,l1l111_l1_ (u"ࠪࠫ⻯"),str(l1ll1l11111_l1_))
	elif type==l1l111_l1_ (u"ࠫࡒࡻࡳࡪࡥࠪ⻰"):
		if l1l111_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠭⻱") in url and l1l111_l1_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹࠨ⻲") not in url:
			l1lllll1_l1_ = l1ll1ll111l_l1_+l1l111_l1_ (u"ࠧ࠰ࡏࡸࡷ࡮ࡩ࠯ࡈࡧࡷࡘࡷࡧࡣ࡬ࡵࡅࡽࡄ࡯ࡤ࠾ࠩ⻳")+str(id)+l1l111_l1_ (u"ࠨࠨࡳࡥ࡬࡫࠽ࠨ⻴")+l1llllll1_l1_+l1l111_l1_ (u"ࠩࠩࡷ࡮ࢀࡥ࠾࠵࠳ࠪࡹࡿࡰࡦ࠿࠳ࠫ⻵")
			html = l1l1llll_l1_(l11l1l1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠪࠫ⻶"),l1l111_l1_ (u"ࠫࠬ⻷"),l1l111_l1_ (u"ࠬ࠭⻸"),l1l111_l1_ (u"࠭ࡉࡇࡋࡏࡑ࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠴ࡴࡧࠫ⻹"))
			items = re.findall(l1l111_l1_ (u"ࠧࡊ࡯ࡤ࡫ࡪࡇࡤࡥࡴࡨࡷࡸࡥࡓࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡜࡯ࡪࡥࡨࡅࡩࡪࡲࡦࡵࡶࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡅࡤࡴࡹ࡯࡯࡯ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠰࡚ࠧࡩࡵ࡮ࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭⻺"),html,re.DOTALL)
			for l1ll1l_l1_,l1ll1ll_l1_,name,title in items:
				l1ll1l11111_l1_ += 1
				l1ll1ll1l11_l1_ = l1ll1ll11l1_l1_ + QUOTE(l1ll1l_l1_)
				l1ll1l111ll_l1_ = name + l1l111_l1_ (u"ࠨࠢ࠰ࠤࠬ⻻") + title
				l1ll1l111ll_l1_ = l1ll1l111ll_l1_.strip(l1l111_l1_ (u"ࠩࠣࠫ⻼"))
				l1ll1l111ll_l1_ = escapeUNICODE(l1ll1l111ll_l1_)
				addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ⻽"),l1lllll_l1_+l1ll1l111ll_l1_,l1lllll1_l1_,24,l1ll1ll1l11_l1_,l1l111_l1_ (u"ࠫࠬ⻾"),str(l1ll1l11111_l1_))
		elif l1l111_l1_ (u"ࠬࡉ࡬ࡪࡲࡶࠫ⻿") in url:
			l1lllll1_l1_ = l1ll1ll111l_l1_+l1l111_l1_ (u"࠭࠯ࡎࡷࡶ࡭ࡨ࠵ࡇࡦࡶࡗࡶࡦࡩ࡫ࡴࡄࡼࡃ࡮ࡪ࠽࠱ࠨࡳࡥ࡬࡫࠽ࠨ⼀")+l1llllll1_l1_+l1l111_l1_ (u"ࠧࠧࡵ࡬ࡾࡪࡃ࠳࠱ࠨࡷࡽࡵ࡫࠽࠲࠷ࠪ⼁")
			html = l1l1llll_l1_(l11l1l1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠨࠩ⼂"),l1l111_l1_ (u"ࠩࠪ⼃"),l1l111_l1_ (u"ࠪࠫ⼄"),l1l111_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠺ࡴࡩࠩ⼅"))
			items = re.findall(l1l111_l1_ (u"ࠬࡏ࡭ࡢࡩࡨࡅࡩࡪࡲࡦࡵࡶࡣࡘࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡇࡦࡶࡴࡪࡱࡱࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡘ࡬ࡨࡪࡵࡁࡥࡦࡵࡩࡸࡹࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ⼆"),html,re.DOTALL)
			for l1ll1l_l1_,title,l1ll1ll_l1_ in items:
				l1ll1l11111_l1_ += 1
				l1ll1ll1l11_l1_ = l1ll1ll11l1_l1_ + QUOTE(l1ll1l_l1_)
				l1ll1l111ll_l1_ = title.strip(l1l111_l1_ (u"࠭ࠠࠨ⼇"))
				l1ll1l111ll_l1_ = escapeUNICODE(l1ll1l111ll_l1_)
				addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭⼈"),l1lllll_l1_+l1ll1l111ll_l1_,l1lllll1_l1_,24,l1ll1ll1l11_l1_,l1l111_l1_ (u"ࠨࠩ⼉"),str(l1ll1l11111_l1_))
		elif l1l111_l1_ (u"ࠩࡦࡥࡹ࡫ࡧࡰࡴࡼࠫ⼊") in url:
			if l1l111_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࡂ࠼ࠧ⼋") in url:
				l1lllll1_l1_ = l1ll1ll111l_l1_+l1l111_l1_ (u"ࠫ࠴ࡓࡵࡴ࡫ࡦ࠳ࡌ࡫ࡴࡕࡴࡤࡧࡰࡹࡂࡺࡁ࡬ࡨࡂ࠶ࠦࡱࡣࡪࡩࡂ࠭⼌")+l1llllll1_l1_+l1l111_l1_ (u"ࠬࠬࡳࡪࡼࡨࡁ࠸࠶ࠦࡵࡻࡳࡩࡂ࠼ࠧ⼍")
				html = l1l1llll_l1_(l11l1l1_l1_,l1lllll1_l1_,l1l111_l1_ (u"࠭ࠧ⼎"),l1l111_l1_ (u"ࠧࠨ⼏"),l1l111_l1_ (u"ࠨࠩ⼐"),l1l111_l1_ (u"ࠩࡌࡊࡎࡒࡍ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠹ࡹ࡮ࠧ⼑"))
			elif l1l111_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࡂ࠺ࠧ⼒") in url:
				l1lllll1_l1_ = l1ll1ll111l_l1_+l1l111_l1_ (u"ࠫ࠴ࡓࡵࡴ࡫ࡦ࠳ࡌ࡫ࡴࡕࡴࡤࡧࡰࡹࡂࡺࡁ࡬ࡨࡂ࠶ࠦࡱࡣࡪࡩࡂ࠭⼓")+l1llllll1_l1_+l1l111_l1_ (u"ࠬࠬࡳࡪࡼࡨࡁ࠸࠶ࠦࡵࡻࡳࡩࡂ࠺ࠧ⼔")
				html = l1l1llll_l1_(l11l1l1_l1_,l1lllll1_l1_,l1l111_l1_ (u"࠭ࠧ⼕"),l1l111_l1_ (u"ࠧࠨ⼖"),l1l111_l1_ (u"ࠨࠩ⼗"),l1l111_l1_ (u"ࠩࡌࡊࡎࡒࡍ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠺ࡹ࡮ࠧ⼘"))
			items = re.findall(l1l111_l1_ (u"ࠪࡍࡲࡧࡧࡦࡃࡧࡨࡷ࡫ࡳࡴࡡࡖࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡘࡲ࡭ࡨ࡫ࡁࡥࡦࡵࡩࡸࡹࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡈࡧࡰࡵ࡫ࡲࡲࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠬࠣࡖ࡬ࡸࡱ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ⼙"),html,re.DOTALL)
			for l1ll1l_l1_,l1ll1ll_l1_,name,title in items:
				l1ll1l11111_l1_ += 1
				l1ll1ll1l11_l1_ = l1ll1ll11l1_l1_ + QUOTE(l1ll1l_l1_)
				l1ll1l111ll_l1_ = name + l1l111_l1_ (u"ࠫࠥ࠳ࠠࠨ⼚") + title
				l1ll1l111ll_l1_ = l1ll1l111ll_l1_.strip(l1l111_l1_ (u"ࠬࠦࠧ⼛"))
				l1ll1l111ll_l1_ = escapeUNICODE(l1ll1l111ll_l1_)
				addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ⼜"),l1lllll_l1_+l1ll1l111ll_l1_,l1lllll1_l1_,24,l1ll1ll1l11_l1_,l1l111_l1_ (u"ࠧࠨ⼝"),str(l1ll1l11111_l1_))
	if type==l1l111_l1_ (u"ࠨࡏࡸࡷ࡮ࡩࠧ⼞") or type==l1l111_l1_ (u"ࠩࡓࡶࡴ࡭ࡲࡢ࡯ࠪ⼟"):
		if l1ll1l11111_l1_>25:
			title=l1l111_l1_ (u"ูࠪๆำษࠡࠩ⼠")
			if l1lllll1111_l1_==l1l111_l1_ (u"ࠫࡪࡴࠧ⼡"): title = l1l111_l1_ (u"ࠬࠦࡐࡢࡩࡨࠤࠬ⼢")
			if l1lllll1111_l1_==l1l111_l1_ (u"࠭ࡦࡢࠩ⼣"): title = l1l111_l1_ (u"ࠧࠡืไั์ࠦࠧ⼤")
			if l1lllll1111_l1_==l1l111_l1_ (u"ࠨࡨࡤ࠶ࠬ⼥"): title = l1l111_l1_ (u"ูࠩࠣๆำ็ࠡࠩ⼦")
			for l1ll1l1ll11_l1_ in range(1,11):
				if not l1llllll1_l1_==str(l1ll1l1ll11_l1_):
					l1ll1l1111l_l1_ = l1l111_l1_ (u"ࠪ࠴ࠬ⼧")+str(l1ll1l1ll11_l1_)
					addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⼨"),l1lllll_l1_+title+str(l1ll1l1ll11_l1_),url,23,l1l111_l1_ (u"ࠬ࠭⼩"),l1ll11lllll_l1_+l1ll1l1111l_l1_[-2:])
	return
def PLAY(url,l1l1lll_l1_):
	l1ll1ll11l1_l1_ = l1ll1l1l1l1_l1_(url)
	l1l1lll1_l1_,l1llll_l1_ = [],[]
	html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"࠭ࠧ⼪"),l1l111_l1_ (u"ࠧࠨ⼫"),l1l111_l1_ (u"ࠨࠩ⼬"),l1l111_l1_ (u"ࠩࡌࡊࡎࡒࡍ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ⼭"))
	items = re.findall(l1l111_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡸ࡬ࡨࡪࡵ࠽ࠣࠪ࠱࠮ࡄ࠯ࠨ࡝ࠩ࠱࠮ࡄࡢࠧࡠࠫࠫ࠲࠯ࡅࠩࠣࡀࠪ⼮"),html,re.DOTALL)
	if items:
		l1lllll1111_l1_ = l1ll1ll11ll_l1_(url)
		parts = url.split(l1l111_l1_ (u"ࠫ࠴࠭⼯"))
		id,type = parts[-1],parts[3]
		l1ll1ll_l1_ = items[0][0]+l1lllll1111_l1_+id+l1l111_l1_ (u"ࠬ࠵ࠬࠨ⼰")+l1l1lll_l1_+l1l111_l1_ (u"࠭ࠬࠨ⼱")+l1l1lll_l1_+l1l111_l1_ (u"ࠧࡠࠩ⼲")+items[0][2]
		l1l1lll1_l1_.append(l1l111_l1_ (u"ࠨ࡯࠶ࡹ࠽࠭⼳"))
		l1llll_l1_.append(l1ll1ll_l1_)
	items = re.findall(l1l111_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡶࡴ࡯ࡁࠧ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩࠩ࡞ࠪ࠲࠯ࡅ࡜ࠨࠫࠫࡠ࠳࠴ࠪࡀࠫࠥࠫ⼴"),html,re.DOTALL)
	if items:
		l1lllll1111_l1_ = l1ll1ll11ll_l1_(url)
		parts = url.split(l1l111_l1_ (u"ࠪ࠳ࠬ⼵"))
		id,type = parts[-1],parts[3]
		l1ll1ll_l1_ = items[0][0]+l1lllll1111_l1_+id+l1l111_l1_ (u"ࠫ࠴࠭⼶")+l1l1lll_l1_+items[0][2]
		l1l1lll1_l1_.append(l1l111_l1_ (u"ࠬࡳࡰ࠵ࠢࡸࡶࡱ࠭⼷"))
		l1llll_l1_.append(l1ll1ll_l1_)
	items = re.findall(l1l111_l1_ (u"࠭ࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ⼸"),html,re.DOTALL)
	for l1ll1ll_l1_ in items:
		l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠧ࠰࠱ࠪ⼹"),l1l111_l1_ (u"ࠨ࠱ࠪ⼺"))
		l1l1lll1_l1_.append(l1l111_l1_ (u"ࠩࡰࡴ࠹ࠦࡳࡳࡥࠪ⼻"))
		l1llll_l1_.append(l1ll1ll_l1_)
	items = re.findall(l1l111_l1_ (u"࡚ࠪ࡮ࡪࡥࡰࡃࡧࡨࡷ࡫ࡳࡴࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ⼼"),html,re.DOTALL)
	if items:
		l1ll1ll_l1_ = items[int(l1l1lll_l1_)-1]
		l1ll1ll_l1_ = l1ll1ll11l1_l1_+QUOTE(l1ll1ll_l1_)
		l1l1lll1_l1_.append(l1l111_l1_ (u"ࠫࡲࡶ࠴ࠡࡣࡧࡨࡷ࡫ࡳࡴࠩ⼽"))
		l1llll_l1_.append(l1ll1ll_l1_)
	items = re.findall(l1l111_l1_ (u"ࠬ࡜࡯ࡪࡥࡨࡅࡩࡪࡲࡦࡵࡶࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭⼾"),html,re.DOTALL)
	if items:
		l1ll1ll_l1_ = items[int(l1l1lll_l1_)-1]
		l1ll1ll_l1_ = l1ll1ll11l1_l1_+QUOTE(l1ll1ll_l1_)
		l1l1lll1_l1_.append(l1l111_l1_ (u"࠭࡭ࡱ࠵ࠣࡥࡩࡪࡲࡦࡵࡶࠫ⼿"))
		l1llll_l1_.append(l1ll1ll_l1_)
	if len(l1llll_l1_)==1: l1ll1ll_l1_ = l1llll_l1_[0]
	else:
		l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠧศะอีࠥอไโ์า๎ํࠦวๅ็้หุฮ࠺ࠨ⽀"), l1l1lll1_l1_)
		if l11l11l_l1_ == -1 : return
		l1ll1ll_l1_ = l1llll_l1_[l11l11l_l1_]
	l1llll111_l1_(l1ll1ll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ⽁"))
	return
def l1ll1l1l1l1_l1_(url):
	if l111l1_l1_ in url: l1lll11l1l1_l1_ = l111l1_l1_
	elif l1l1l1l1l1_l1_ in url: l1lll11l1l1_l1_ = l1l1l1l1l1_l1_
	elif l1ll1l1l1ll_l1_ in url: l1lll11l1l1_l1_ = l1ll1l1l1ll_l1_
	elif l1ll1l1ll1l_l1_ in url: l1lll11l1l1_l1_ = l1ll1l1ll1l_l1_
	else: l1lll11l1l1_l1_ = l1l111_l1_ (u"ࠩࠪ⽂")
	return l1lll11l1l1_l1_
def l1ll1ll11ll_l1_(url):
	if   l111l1_l1_ in url: l1lllll1111_l1_ = l1l111_l1_ (u"ࠪࡥࡷ࠭⽃")
	elif l1l1l1l1l1_l1_ in url: l1lllll1111_l1_ = l1l111_l1_ (u"ࠫࡪࡴࠧ⽄")
	elif l1ll1l1l1ll_l1_ in url: l1lllll1111_l1_ = l1l111_l1_ (u"ࠬ࡬ࡡࠨ⽅")
	elif l1ll1l1ll1l_l1_ in url: l1lllll1111_l1_ = l1l111_l1_ (u"࠭ࡦࡢ࠴ࠪ⽆")
	else: l1lllll1111_l1_ = l1l111_l1_ (u"ࠧࠨ⽇")
	return l1lllll1111_l1_
def l1ll1llll_l1_(url):
	l1lllll1111_l1_ = l1ll1ll11ll_l1_(url)
	l1lllll1_l1_ = url + l1l111_l1_ (u"ࠨ࠱ࡋࡳࡲ࡫࠯ࡍ࡫ࡹࡩࠬ⽈")
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭⽉"),l1lllll1_l1_,l1l111_l1_ (u"ࠪࠫ⽊"),l1l111_l1_ (u"ࠫࠬ⽋"),l1l111_l1_ (u"ࠬ࠭⽌"),l1l111_l1_ (u"࠭ࠧ⽍"),l1l111_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠳ࡌࡊࡘࡈ࠱࠶ࡹࡴࠨ⽎"))
	html = response.content
	items = re.findall(l1l111_l1_ (u"ࠨࡵࡲࡹࡷࡩࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭⽏"),html,re.DOTALL)
	l1llllll_l1_ = items[0]
	l1llll111_l1_(l1llllll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠩ࡯࡭ࡻ࡫ࠧ⽐"))
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search:
		search = l1llll1_l1_()
		if not search: return
	l1lll1ll_l1_ = search.replace(l1l111_l1_ (u"ࠪࠤࠬ⽑"),l1l111_l1_ (u"ࠫ࠰࠭⽒"))
	if l11_l1_:
		l1111111l_l1_ = [ l111l1_l1_ , l1l1l1l1l1_l1_ , l1ll1l1l1ll_l1_ , l1ll1l1ll1l_l1_ ]
		l1ll11111_l1_ = [ l1l111_l1_ (u"ࠬ฿ัษ์ࠪ⽓") , l1l111_l1_ (u"࠭ࡅ࡯ࡩ࡯࡭ࡸ࡮ࠧ⽔") , l1l111_l1_ (u"ࠧโษิื๎࠭⽕") , l1l111_l1_ (u"ࠨใสีุ๏ࠠ࠳ࠩ⽖") ]
		l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠩสาฯืࠠศๆ็฾ฮࠦวๅ็้หุฮษ࠻ࠩ⽗"), l1ll11111_l1_)
		if l11l11l_l1_ == -1 : return
		l1l11l11_l1_ = l1111111l_l1_[l11l11l_l1_]
	else:
		if l1l111_l1_ (u"ࠪࡣࡎࡌࡉࡍࡏ࠰ࡅࡗࡇࡂࡊࡅࡢࠫ⽘") in options: l1l11l11_l1_ = l111l1_l1_
		elif l1l111_l1_ (u"ࠫࡤࡏࡆࡊࡎࡐ࠱ࡊࡔࡇࡍࡋࡖࡌࡤ࠭⽙") in options: l1l11l11_l1_ = l1l1l1l1l1_l1_
		else: l1l11l11_l1_ = l1l111_l1_ (u"ࠬ࠭⽚")
	if not l1l11l11_l1_: return
	l1lllll1111_l1_ = l1ll1ll11ll_l1_(l1l11l11_l1_)
	l1lllll1_l1_ = l1l11l11_l1_ + l1l111_l1_ (u"ࠨ࠯ࡉࡱࡰࡩ࠴࡙ࡥࡢࡴࡦ࡬ࡄࡹࡥࡢࡴࡦ࡬ࡸࡺࡲࡪࡰࡪࡁࠧ⽛") + l1lll1ll_l1_
	html = l1l1llll_l1_(l11l1l1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠧࠨ⽜"),l1l111_l1_ (u"ࠨࠩ⽝"),l1l111_l1_ (u"ࠩࠪ⽞"),l1l111_l1_ (u"ࠪࡍࡋࡏࡌࡎ࠯ࡖࡉࡆࡘࡃࡉ࠯࠴ࡷࡹ࠭⽟"))
	items = re.findall(l1l111_l1_ (u"ࠫࠧࡏ࡭ࡢࡩࡨࡅࡩࡪࡲࡦࡵࡶࡣࡘࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡈࡧࡴࡦࡩࡲࡶࡾࡏࡤࠣ࠼ࠫ࠲࠯ࡅࠩ࠭ࠤࡌࡨࠧࡀࠨ࠯ࠬࡂ࠭࠱ࠨࡔࡪࡶ࡯ࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠬࠨ⽠"),html,re.DOTALL)
	if items:
		for l1ll1l_l1_,category,id,title in items:
			if category in [l1l111_l1_ (u"ࠬ࠹ࠧ⽡"),l1l111_l1_ (u"࠭࠷ࠨ⽢")]:
				title = title.replace(l1l111_l1_ (u"ࠧ࡝࡞ࠪ⽣"),l1l111_l1_ (u"ࠨࠩ⽤"))
				title = title.replace(l1l111_l1_ (u"ࠩࠥࠫ⽥"),l1l111_l1_ (u"ࠪࠫ⽦"))
				if category==l1l111_l1_ (u"ࠫ࠸࠭⽧"):
					type = l1l111_l1_ (u"࡙ࠬࡥࡳ࡫ࡨࡷࠬ⽨")
					if l1lllll1111_l1_==l1l111_l1_ (u"࠭ࡡࡳࠩ⽩"): name = l1l111_l1_ (u"ࠧๆี็ื้ࠦ࠺ࠡࠩ⽪")
					elif l1lllll1111_l1_==l1l111_l1_ (u"ࠨࡧࡱࠫ⽫"): name = l1l111_l1_ (u"ࠩࡖࡩࡷ࡯ࡥࡴࠢ࠽ࠤࠬ⽬")
					elif l1lllll1111_l1_==l1l111_l1_ (u"ࠪࡪࡦ࠭⽭"): name = l1l111_l1_ (u"ุࠫื๊ศๆ๋ࠣฬࠦ࠺ࠡࠩ⽮")
					elif l1lllll1111_l1_==l1l111_l1_ (u"ࠬ࡬ࡡ࠳ࠩ⽯"): name = l1l111_l1_ (u"࠭ำา์ส่ࠥํวࠡ࠼ࠣࠫ⽰")
				elif category==l1l111_l1_ (u"ࠧ࠶ࠩ⽱"):
					type = l1l111_l1_ (u"ࠨࡈ࡬ࡰࡲ࠭⽲")
					if l1lllll1111_l1_==l1l111_l1_ (u"ࠩࡤࡶࠬ⽳"): name = l1l111_l1_ (u"ࠪๅ๏๊ๅࠡ࠼ࠣࠫ⽴")
					elif l1lllll1111_l1_==l1l111_l1_ (u"ࠫࡪࡴࠧ⽵"): name = l1l111_l1_ (u"ࠬࡓ࡯ࡷ࡫ࡨࠤ࠿ࠦࠧ⽶")
					elif l1lllll1111_l1_==l1l111_l1_ (u"࠭ࡦࡢࠩ⽷"): name = l1l111_l1_ (u"ࠧโ์็้ࠥࡀࠠࠨ⽸")
					elif l1lllll1111_l1_==l1l111_l1_ (u"ࠨࡨࡤ࠶ࠬ⽹"): name = l1l111_l1_ (u"ࠩไ่๊ࠦ็ศࠢ࠽ࠤࠬ⽺")
				elif category==l1l111_l1_ (u"ࠪ࠻ࠬ⽻"):
					type = l1l111_l1_ (u"ࠫࡕࡸ࡯ࡨࡴࡤࡱࠬ⽼")
					if l1lllll1111_l1_==l1l111_l1_ (u"ࠬࡧࡲࠨ⽽"): name = l1l111_l1_ (u"࠭ศา่ส้ัࠦ࠺ࠡࠩ⽾")
					elif l1lllll1111_l1_==l1l111_l1_ (u"ࠧࡦࡰࠪ⽿"): name = l1l111_l1_ (u"ࠨࡒࡵࡳ࡬ࡸࡡ࡮ࠢ࠽ࠤࠬ⾀")
					elif l1lllll1111_l1_==l1l111_l1_ (u"ࠩࡩࡥࠬ⾁"): name = l1l111_l1_ (u"ࠪฬึ์วๆ้๋ࠣฬࠦ࠺ࠡࠩ⾂")
					elif l1lllll1111_l1_==l1l111_l1_ (u"ࠫ࡫ࡧ࠲ࠨ⾃"): name = l1l111_l1_ (u"ࠬฮั็ษ่๋ࠥํวࠡ࠼ࠣࠫ⾄")
				title = name + title
				l1ll1ll_l1_ = l1l11l11_l1_ + l1l111_l1_ (u"࠭࠯ࠨ⾅") + type + l1l111_l1_ (u"ࠧ࠰ࡅࡲࡲࡹ࡫࡮ࡵ࠱ࠪ⾆") + id
				l1ll1l_l1_ = QUOTE(l1ll1l_l1_)
				l1ll1l_l1_ = l1l11l11_l1_+l1ll1l_l1_
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⾇"),l1lllll_l1_+title,l1ll1ll_l1_,23,l1ll1l_l1_,l1l111_l1_ (u"ࠩ࠴࠴࠶࠭⾈"))
	return
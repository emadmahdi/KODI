# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠨࡇࡊ࡝ࡉࡋࡁࡅࠩ␠")
l1lllll_l1_ = l1l111_l1_ (u"ࠩࡢࡉࡌࡊ࡟ࠨ␡")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ฺ้ࠪอัฺหࠪ␢"),l1l111_l1_ (u"ࠫฬำฯฬࠢส่อืวๆฮࠪ␣"),l1l111_l1_ (u"ࠬออะอࠣห้อไฺษหࠫ␤"),l1l111_l1_ (u"࠭วๅำษ๎ุ๐ษࠨ␥"),l1l111_l1_ (u"ࠧศฯาฯࠥอไศ฼ส๊๎࠭␦")]
def l11l1ll_l1_(mode,url,text):
	if   mode==440: l1lll_l1_ = l1l1l11_l1_()
	elif mode==441: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==442: l1lll_l1_ = PLAY(url)
	elif mode==443: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==449: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ␧"),l111l1_l1_,l1l111_l1_ (u"ࠩࠪ␨"),l1l111_l1_ (u"ࠪࠫ␩"),l1l111_l1_ (u"ࠫࠬ␪"),l1l111_l1_ (u"ࠬ࠭␫"),l1l111_l1_ (u"࠭ࡅࡈ࡛ࡇࡉࡆࡊ࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ␬"))
	html = response.content
	l1l11ll_l1_ = l1l111l_l1_(l111l1_l1_,l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ␭"))
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ␮"),l1lllll_l1_+l1l111_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ␯"),l1l111_l1_ (u"ࠪࠫ␰"),449,l1l111_l1_ (u"ࠫࠬ␱"),l1l111_l1_ (u"ࠬ࠭␲"),l1l111_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ␳"))
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ␴"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ␵")+l1lllll_l1_+l1l111_l1_ (u"ࠩส่ึฬ๊ิ์ฬࠫ␶"),l111l1_l1_,441)
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ␷"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ␸"),l1l111_l1_ (u"ࠬ࠭␹"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡴࡪࡶ࡯ࡩࡤࡳࡥ࡯ࡷࡢࡶ࡮࡭ࡨࡵࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ␺"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ␻"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if title in l11lll_l1_: continue
		if l1ll1ll_l1_==l1l111_l1_ (u"ࠨࠥࠪ␼"): continue
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ␽"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ␾")+l1lllll_l1_+title,l1ll1ll_l1_,441)
	return
def l1lll11_l1_(url,l1111ll1_l1_=l1l111_l1_ (u"ࠫࠬ␿")):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ⑀"),url,l1l111_l1_ (u"࠭ࠧ⑁"),l1l111_l1_ (u"ࠧࠨ⑂"),l1l111_l1_ (u"ࠨࠩ⑃"),l1l111_l1_ (u"ࠩࠪ⑄"),l1l111_l1_ (u"ࠪࡉࡌ࡟ࡄࡆࡃࡇ࠱࡙ࡏࡔࡍࡇࡖ࠱࠷ࡴࡤࠨ⑅"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡱ࡯ࡳࡵ࠯ࡵࡩࡱࡧࡴࡦࡦࠥࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠧ࠭⑆"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠬࡂ࡬ࡪࡀ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡩ࠳ࡁࠬ࠳࠰࠿ࠪ࠾࠲࡬࠶ࡄ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⑇"),block,re.DOTALL)
	for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
		if l1l111_l1_ (u"࠭࠯ࡶࡴ࡯࠳ࠬ⑈") in l1ll1ll_l1_: continue
		elif l1l111_l1_ (u"ࠧ࠰ࡵࡨࡥࡸࡵ࡮࠰ࠩ⑉") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⑊"),l1lllll_l1_+title,l1ll1ll_l1_,443,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠩ࠲ࡩࡵ࡯ࡳࡰࡦࡨ࠳ࠬ⑋") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⑌"),l1lllll_l1_+title,l1ll1ll_l1_,443,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ⑍"),l1lllll_l1_+title,l1ll1ll_l1_,442,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ⑎"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ⑏"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = unescapeHTML(title)
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⑐"),l1lllll_l1_+l1l111_l1_ (u"ࠨืไัฮࠦࠧ⑑")+title,l1ll1ll_l1_,441)
	return
def l1ll1l11_l1_(url):
	data = {l1l111_l1_ (u"࡙ࠩ࡭ࡪࡽࠧ⑒"):1}
	headers = {l1l111_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ⑓"):l1l111_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦࠪ⑔")}
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡖࡏࡔࡖࠪ⑕"),url,data,headers,l1l111_l1_ (u"࠭ࠧ⑖"),l1l111_l1_ (u"ࠧࠨ⑗"),l1l111_l1_ (u"ࠨࡇࡊ࡝ࡉࡋࡁࡅ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠶ࡹࡴࠨ⑘"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡷࡪࡧࡳࡰࡰࡶ࠱ࡱ࡯ࡳࡵࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄ࠮࠽࠱ࡧ࡭ࡻࡄࠧ⑙"),html,re.DOTALL)
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡪࡶࡩࡴࡱࡧࡩࡸ࠳࡬ࡪࡵࡷࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿࠰࠿࠳ࡩ࡯ࡶ࠿ࠩ⑚"),html,re.DOTALL)
	if l11ll1l_l1_:
		block = l11ll1l_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ⑛"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⑜"),l1lllll_l1_+title,l1ll1ll_l1_,443,l1ll1l_l1_)
	elif l11ll11_l1_:
		l1ll1l_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡰࡩ࠽࡭ࡲࡧࡧࡦࠤࠣࡧࡴࡴࡴࡦࡰࡷࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ⑝"),html,re.DOTALL)
		l1ll1l_l1_ = l1ll1l_l1_[0]
		block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ⑞"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = title.replace(l1l111_l1_ (u"ࠨ࡞ࡱࠫ⑟"),l1l111_l1_ (u"ࠩࠪ①")).strip(l1l111_l1_ (u"ࠪࠤࠬ②"))
			addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ③"),l1lllll_l1_+title,l1ll1ll_l1_,442,l1ll1l_l1_)
	return
def PLAY(url):
	data = {l1l111_l1_ (u"ࠬ࡜ࡩࡦࡹࠪ④"):1}
	headers = {l1l111_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ⑤"):l1l111_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩ࠭⑥")}
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡒࡒࡗ࡙࠭⑦"),url,data,headers,l1l111_l1_ (u"ࠩࠪ⑧"),l1l111_l1_ (u"ࠪࠫ⑨"),l1l111_l1_ (u"ࠫࡊࡍ࡙ࡅࡇࡄࡈ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ⑩"))
	html = response.content
	l1llll_l1_ = []
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡷࡢࡶࡦ࡬ࡆࡸࡥࡢࡏࡤࡷࡹ࡫ࡲࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ⑪"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡱ࡯࡮࡬࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡰ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡲࡁࠫ⑫"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = title.replace(l1l111_l1_ (u"ࠧ࡝ࡰࠪ⑬"),l1l111_l1_ (u"ࠨࠩ⑭")).strip(l1l111_l1_ (u"ࠩࠣࠫ⑮"))
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ⑯")+title+l1l111_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬ⑰")
			l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡤࡰࡰࡺࡰࡴࡧࡤ࠮ࡵࡨࡶࡻ࡫ࡲࡴ࠯࡯࡭ࡸࡺࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ⑱"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࠢࡴࡧࡵ࠱ࡳࡧ࡭ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡵࡧ࡮࠿࠰࠭ࡃࡁ࡫࡭࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡧࡰࡂ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭⑲"),block,re.DOTALL)
		for title,l111l1ll_l1_,l1ll1ll_l1_ in items:
			l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠧ࡝ࡰࠪ⑳"),l1l111_l1_ (u"ࠨࠩ⑴"))
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ⑵")+title+l1l111_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ⑶")+l1l111_l1_ (u"ࠫࡤࡥ࡟ࡠࠩ⑷")+l111l1ll_l1_
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ⑸"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"࠭ࠧ⑹"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠧࠨ⑺"): return
	search = search.replace(l1l111_l1_ (u"ࠨࠢࠪ⑻"),l1l111_l1_ (u"ࠩ࠮ࠫ⑼"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡄࡹ࠽ࠨ⑽")+search
	l1lll11_l1_(url)
	return
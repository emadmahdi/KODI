# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠧࡘࡇࡆࡍࡒࡇࠧ媥")
headers = {l1l111_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ媦"):l1l111_l1_ (u"ࠩࠪ媧")}
l1lllll_l1_ = l1l111_l1_ (u"ࠪࡣ࡜ࡉࡍࡠࠩ媨")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"๊ࠫ฻วา฻ฬࠤาืษࠨ媩"),l1l111_l1_ (u"ࠬࡽࡷࡦࠩ媪")]
def l11l1ll_l1_(mode,url,text):
	if   mode==560: l1lll_l1_ = l1l1l11_l1_()
	elif mode==561: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==562: l1lll_l1_ = PLAY(url)
	elif mode==563: l1lll_l1_ = l1ll1l11_l1_(url,text)
	elif mode==564: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࡢࡣࡤ࠭媫")+text)
	elif mode==565: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠧࡇࡋࡏࡘࡊࡘࡓࡠࡡࡢࠫ媬")+text)
	elif mode==566: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==569: l1lll_l1_ = l1lll1_l1_(text,url)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ媭"),l1lllll_l1_+l1l111_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ媮"),l111l1_l1_,569,l1l111_l1_ (u"ࠪࠫ媯"),l1l111_l1_ (u"ࠫࠬ媰"),l1l111_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ媱"))
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭媲"),l1lllll_l1_+l1l111_l1_ (u"ࠧโๆอี๋ࠥอะัࠪ媳"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡄ࡮ࡦࡾࡃࡦࡰࡷࡩࡷ࠵ࡒࡪࡩ࡫ࡸࡇࡧࡲࠨ媴"),564)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ媵"),l1lllll_l1_+l1l111_l1_ (u"ࠪๅ้ะัࠡๅส้้࠭媶"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡇࡪࡢࡺࡆࡩࡳࡺࡥࡳ࠱ࡕ࡭࡬࡮ࡴࡃࡣࡵࠫ媷"),565)
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ媸"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭媹"),l1l111_l1_ (u"ࠧࠨ媺"),9999)
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ媻"),l111l1_l1_,l1l111_l1_ (u"ࠩࠪ媼"),l1l111_l1_ (u"ࠪࠫ媽"),l1l111_l1_ (u"ࠫࠬ媾"),l1l111_l1_ (u"ࠬ࠭媿"),l1l111_l1_ (u"࠭ࡗࡆࡅࡌࡑࡆ࠳ࡍࡆࡐࡘ࠱࠷ࡴࡤࠨ嫀"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡏࡣࡹ࡭࡬ࡧࡴࡪࡱࡱࡑࡪࡴࡵࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡐࡳࡱࡧࡹࡨࡺࡩࡰࡰࡶࡐ࡮ࡹࡴࡃࡷࡷࡸࡴࡴࠢࠨ嫁"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣ࡯ࡨࡲࡺ࠳ࡩࡵࡧࡰ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ嫂"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if title==l1l111_l1_ (u"ࠩࠪ嫃"): continue
			if any(value in title.lower() for value in l11lll_l1_): continue
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ嫄"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭嫅")+l1lllll_l1_+title,l1ll1ll_l1_,566)
		addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ嫆"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭嫇"),l1l111_l1_ (u"ࠧࠨ嫈"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡪࡲࡺࡪࡸࡡࡣ࡮ࡨࠤࡦࡩࡴࡪࡸࡤࡦࡱ࡫ࠨ࠯ࠬࡂ࠭࡭ࡵࡶࡦࡴࡤࡦࡱ࡫ࠠࡢࡥࡷ࡭ࡻࡧࡢ࡭ࡧࠪ嫉"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪ࠰࠭ࡃࡸࡶࡡ࡯ࡀࠫ࠲࠯ࡅࠩ࠽ࠩ嫊"),block,re.DOTALL)
		for l1ll1ll_l1_,l1ll1l_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ嫋"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭嫌")+l1lllll_l1_+title,l1ll1ll_l1_,566,l1ll1l_l1_)
	return html
def l11ll1_l1_(url):
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ嫍"),url,l1l111_l1_ (u"࠭ࠧ嫎"),l1l111_l1_ (u"ࠧࠨ嫏"),l1l111_l1_ (u"ࠨࠩ嫐"),l1l111_l1_ (u"ࠩࠪ嫑"),l1l111_l1_ (u"࡛ࠪࡊࡉࡉࡎࡃ࠰ࡗ࡚ࡈࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ嫒"))
	html = response.content
	if l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡘࡲࡩࡥࡧࡵ࠱࠲ࡍࡲࡪࡦࠥࠫ嫓") in html:
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ嫔"),l1lllll_l1_+l1l111_l1_ (u"࠭วๅ็่๎ืฯࠧ嫕"),url,561,l1l111_l1_ (u"ࠧࠨ嫖"),l1l111_l1_ (u"ࠨࠩ嫗"),l1l111_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫ嫘"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡰ࡮ࡹࡴ࠮࠯ࡗࡥࡧࡹࡵࡪࠤࠫ࠲࠯ࡅࠩࡥ࡫ࡹࠫ嫙"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡯࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ嫚"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ嫛"),l1lllll_l1_+title,l1ll1ll_l1_,561)
	return
def l1lll11_l1_(l1lll1ll111l_l1_,type=l1l111_l1_ (u"࠭ࠧ嫜")):
	if l1l111_l1_ (u"ࠧ࠻࠼ࠪ嫝") in l1lll1ll111l_l1_:
		l1llllll_l1_,url = l1lll1ll111l_l1_.split(l1l111_l1_ (u"ࠨ࠼࠽ࠫ嫞"))
		server = l1l111l_l1_(l1llllll_l1_,l1l111_l1_ (u"ࠩࡸࡶࡱ࠭嫟"))
		url = server+url
	else: url,l1llllll_l1_ = l1lll1ll111l_l1_,l1lll1ll111l_l1_
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ嫠"),url,l1l111_l1_ (u"ࠫࠬ嫡"),l1l111_l1_ (u"ࠬ࠭嫢"),l1l111_l1_ (u"࠭ࠧ嫣"),l1l111_l1_ (u"ࠧࠨ嫤"),l1l111_l1_ (u"ࠨ࡙ࡈࡇࡎࡓࡁ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬ嫥"))
	html = response.content
	if type==l1l111_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫ嫦"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡗࡱ࡯ࡤࡦࡴ࠰࠱ࡌࡸࡩࡥࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢ࡭࡫ࡶࡸ࠲࠳ࡔࡢࡤࡶࡹ࡮ࠨࠧ嫧"),html,re.DOTALL)
	elif type in [l1l111_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࡷࠬ嫨"),l1l111_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࠬ嫩")]:
		l11llll_l1_ = [html.replace(l1l111_l1_ (u"࠭࡜࡝࠱ࠪ嫪"),l1l111_l1_ (u"ࠧ࠰ࠩ嫫")).replace(l1l111_l1_ (u"ࠨ࡞࡟ࠦࠬ嫬"),l1l111_l1_ (u"ࠩࠥࠫ嫭"))]
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡌࡸࡩࡥ࠯࠰࡛ࡪࡩࡩ࡮ࡣࡓࡳࡸࡺࡳࠣࠪ࠱࠮ࡄ࠯ࠢࡓ࡫ࡪ࡬ࡹ࡛ࡉࠣࠩ嫮"),html,re.DOTALL)
	l1l1_l1_ = []
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࡚ࠫࠧࡨࡶ࡯ࡥ࠱࠲ࡍࡲࡪࡦࡌࡸࡪࡳࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡺࡸ࡬࡝ࠪࠫ࠲࠯ࡅࠩ࡝ࠫࠪ嫯"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
			if any(value in title.lower() for value in l11lll_l1_): continue
			l1ll1l_l1_ = escapeUNICODE(l1ll1l_l1_)
			l1ll1ll_l1_ = escapeUNICODE(l1ll1ll_l1_)
			title = unescapeHTML(title)
			title = escapeUNICODE(title)
			title = title.replace(l1l111_l1_ (u"๋ࠬิศ้าอࠥ࠭嫰"),l1l111_l1_ (u"࠭ࠧ嫱"))
			if l1l111_l1_ (u"ࠧ࠰ࡵࡨࡶ࡮࡫ࡳ࠰ࠩ嫲") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ嫳"),l1lllll_l1_+title,l1ll1ll_l1_,563,l1ll1l_l1_)
			elif l1l111_l1_ (u"ࠩะ่็ฯࠧ嫴") in title:
				l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢ࠮ั้่ษࠡ࠭࡟ࡨ࠰࠭嫵"),title,re.DOTALL)
				if l1l1lll_l1_: title = l1l111_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ嫶") + l1l1lll_l1_[0]
				if title not in l1l1_l1_:
					l1l1_l1_.append(title)
					addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ嫷"),l1lllll_l1_+title,l1ll1ll_l1_,563,l1ll1l_l1_)
			else:
				addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ嫸"),l1lllll_l1_+title,l1ll1ll_l1_,562,l1ll1l_l1_)
		if type==l1l111_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨ嫹"):
			l111l1l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡰࡳࡷ࡫࡟ࡣࡷࡷࡸࡴࡴ࡟ࡱࡣࡪࡩࠧࡀࠨ࠯ࠬࡂ࠭࠱࠭嫺"),block,re.DOTALL)
			if l111l1l1ll_l1_:
				count = l111l1l1ll_l1_[0]
				l1ll1ll_l1_ = url+l1l111_l1_ (u"ࠩ࠲ࡳ࡫࡬ࡳࡦࡶ࠲ࠫ嫻")+count
				addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ嫼"),l1lllll_l1_+l1l111_l1_ (u"ฺࠫ็อสࠢฦาึ๏ࠧ嫽"),l1ll1ll_l1_,561,l1l111_l1_ (u"ࠬ࠭嫾"),l1l111_l1_ (u"࠭ࠧ嫿"),l1l111_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨ嬀"))
		elif type==l1l111_l1_ (u"ࠨࠩ嬁"):
			l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ嬂"),html,re.DOTALL)
			if l11llll_l1_:
				block = l11llll_l1_[0]
				items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ嬃"),block,re.DOTALL)
				for l1ll1ll_l1_,title in items:
					title = l1l111_l1_ (u"ฺࠫ็อสࠢࠪ嬄")+unescapeHTML(title)
					addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ嬅"),l1lllll_l1_+title,l1ll1ll_l1_,561)
	return
def l1ll1l11_l1_(url,type=l1l111_l1_ (u"࠭ࠧ嬆")):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ嬇"),url,l1l111_l1_ (u"ࠨࠩ嬈"),l1l111_l1_ (u"ࠩࠪ嬉"),l1l111_l1_ (u"ࠪࠫ嬊"),l1l111_l1_ (u"ࠫࠬ嬋"),l1l111_l1_ (u"ࠬ࡝ࡅࡄࡋࡐࡅ࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠲ࡵࡷࠫ嬌"))
	html = response.content
	html = l111l11_l1_(html)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡓࡦࡣࡶࡳࡳࡹ࠭࠮ࡇࡳ࡭ࡸࡵࡤࡦࡵࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ嬍"),html,re.DOTALL)
	if not type and l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ嬎"),block,re.DOTALL)
		if len(items)>1:
			for l1ll1ll_l1_,title in items:
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ嬏"),l1lllll_l1_+title,l1ll1ll_l1_,563,l1l111_l1_ (u"ࠩࠪ嬐"),l1l111_l1_ (u"ࠪࠫ嬑"),l1l111_l1_ (u"ࠫࡪࡶࡩࡴࡱࡧࡩࡸ࠭嬒"))
			return
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡋࡰࡪࡵࡲࡨࡪࡹ࠭࠮ࡕࡨࡥࡸࡵ࡮ࡴ࠯࠰ࡉࡵ࡯ࡳࡰࡦࡨࡷ࠭࠴ࠪࡀࠫ࠿࠳ࡸ࡯࡮ࡨ࡮ࡨࡷࡪࡩࡴࡪࡱࡱࡷࡃ࠭嬓"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡧࡳ࡭ࡸࡵࡤࡦࡖ࡬ࡸࡱ࡫࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡦࡲ࡬ࡷࡴࡪࡥࡕ࡫ࡷࡰࡪࡄࠧ嬔"),block,re.DOTALL|re.IGNORECASE)
		for l1ll1ll_l1_,title in items:
			title = title.strip(l1l111_l1_ (u"ࠧࠡࠩ嬕"))
			addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ嬖"),l1lllll_l1_+title,l1ll1ll_l1_,562)
	if not menuItemsLIST:
		title = re.findall(l1l111_l1_ (u"ࠩ࠿ࡸ࡮ࡺ࡬ࡦࡀࠫ࠲࠯ࡅࠩ࠽ࠩ嬗"),html,re.DOTALL)
		if title: title = title[0].replace(l1l111_l1_ (u"ࠪࠤ࠲ࠦๅศ์ࠣื๏๋วࠨ嬘"),l1l111_l1_ (u"ࠫࠬ嬙")).replace(l1l111_l1_ (u"๋ࠬิศ้าอࠥ࠭嬚"),l1l111_l1_ (u"࠭ࠧ嬛"))
		else: title = l1l111_l1_ (u"ࠧๆๆไࠤฬ๊สี฼ํ่ࠬ嬜")
		addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ嬝"),l1lllll_l1_+title,url,562)
	return
def PLAY(url):
	l1llll_l1_ = []
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭嬞"),url,l1l111_l1_ (u"ࠪࠫ嬟"),l1l111_l1_ (u"ࠫࠬ嬠"),l1l111_l1_ (u"ࠬ࠭嬡"),l1l111_l1_ (u"࠭ࠧ嬢"),l1l111_l1_ (u"ࠧࡘࡇࡆࡍࡒࡇ࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ嬣"))
	html = response.content
	l1111ll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࠾ࡶࡴࡦࡴ࠾ศๆอู๋๐แ࠽࠰࠭ࡃࡁࡧ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ嬤"),html,re.DOTALL)
	if l1111ll_l1_:
		l1111ll_l1_ = [l1111ll_l1_[0][0],l1111ll_l1_[0][1]]
		if l1111ll_l1_ and l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_): return
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤ࡚ࡥࡹࡩࡨࡔࡧࡵࡺࡪࡸࡳࡍ࡫ࡶࡸࠧ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿࡛ࠥࡦࡺࡣࡩࡕࡨࡶࡻ࡫ࡲࡴࡇࡰࡦࡪࡪࠢࠨ嬥"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡷࡵࡰࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡷࡶࡴࡴࡧ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ嬦"),block,re.DOTALL)
		for l1ll1ll_l1_,name in items:
			if l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ嬧") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			if name==l1l111_l1_ (u"ู๊ࠬาใิࠤํ๐ࠠิ์่หࠬ嬨"): name = l1l111_l1_ (u"࠭ࡷࡦࡥ࡬ࡱࡦ࠭嬩")
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ嬪")+name+l1l111_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩ嬫")
			l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡏ࡭ࡸࡺ࠭࠮ࡆࡲࡻࡳࡲ࡯ࡢࡦࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ嬬"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ嬭"),block,re.DOTALL)
		for l1ll1ll_l1_,l111l1ll_l1_ in items:
			if l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ嬮") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			l111l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡢࡤ࡝ࡦ࡟ࡨ࠰࠭嬯"),l111l1ll_l1_,re.DOTALL)
			if l111l1ll_l1_: l111l1ll_l1_ = l1l111_l1_ (u"࠭࡟ࡠࡡࡢࠫ嬰")+l111l1ll_l1_[0]
			else: l111l1ll_l1_ = l1l111_l1_ (u"ࠧࠨ嬱")
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࡹࡨࡧ࡮ࡳࡡࠨ嬲")+l1l111_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭嬳")+l111l1ll_l1_
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ嬴"),url)
	return
def l1lll1_l1_(search,hostname=l1l111_l1_ (u"ࠫࠬ嬵")):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠬ࠭嬶"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"࠭ࠧ嬷"): return
	search = search.replace(l1l111_l1_ (u"ࠧࠡࠩ嬸"),l1l111_l1_ (u"ࠨ࠭ࠪ嬹"))
	if not hostname:
		hostname = l111l1_l1_
	l1lllll1_l1_ = hostname+l1l111_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪࡂࡵࡂ࠭嬺")+search
	l1lll11_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࠪ嬻"))
	return
def l1l1ll1l_l1_(l1lll1ll111l_l1_,filter):
	if l1l111_l1_ (u"ࠫࡄࡅࠧ嬼") in l1lll1ll111l_l1_: url = l1lll1ll111l_l1_.split(l1l111_l1_ (u"ࠬ࠵࠯ࡨࡧࡷࡴࡴࡹࡴࡴࡁࡂࠫ嬽"))[0]
	else: url = l1lll1ll111l_l1_
	filter = filter.replace(l1l111_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ嬾"),l1l111_l1_ (u"ࠧࠨ嬿"))
	type,filter = filter.split(l1l111_l1_ (u"ࠨࡡࡢࡣࠬ孀"),1)
	if filter==l1l111_l1_ (u"ࠩࠪ孁"): l11lll1l_l1_,l11lll11_l1_ = l1l111_l1_ (u"ࠪࠫ孂"),l1l111_l1_ (u"ࠫࠬ孃")
	else: l11lll1l_l1_,l11lll11_l1_ = filter.split(l1l111_l1_ (u"ࠬࡥ࡟ࡠࠩ孄"))
	if type==l1l111_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࠪ孅"):
		if l1l1lll11_l1_[0]+l1l111_l1_ (u"ࠧ࠾࠿ࠪ孆") not in l11lll1l_l1_: category = l1l1lll11_l1_[0]
		for i in range(len(l1l1lll11_l1_[0:-1])):
			if l1l1lll11_l1_[i]+l1l111_l1_ (u"ࠨ࠿ࡀࠫ孇") in l11lll1l_l1_: category = l1l1lll11_l1_[i+1]
		l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠩࠩࠪࠬ孈")+category+l1l111_l1_ (u"ࠪࡁࡂ࠶ࠧ孉")
		l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠫࠫࠬࠧ孊")+category+l1l111_l1_ (u"ࠬࡃ࠽࠱ࠩ孋")
		l1l111l1_l1_ = l1l11ll1_l1_.strip(l1l111_l1_ (u"࠭ࠦࠧࠩ孌"))+l1l111_l1_ (u"ࠧࡠࡡࡢࠫ孍")+l1l1ll11_l1_.strip(l1l111_l1_ (u"ࠨࠨࠩࠫ孎"))
		l11ll111_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ孏"))
		l1lllll1_l1_ = url+l1l111_l1_ (u"ࠪ࠳࠴࡭ࡥࡵࡲࡲࡷࡹࡹ࠿ࡀࠩ子")+l11ll111_l1_
	elif type==l1l111_l1_ (u"ࠫࡋࡏࡌࡕࡇࡕࡗࠬ孑"):
		l11l1l1l_l1_ = l11ll1l1_l1_(l11lll1l_l1_,l1l111_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡷࡣ࡯ࡹࡪࡹࠧ孒"))
		l11l1l1l_l1_ = l111l11_l1_(l11l1l1l_l1_)
		if l11lll11_l1_!=l1l111_l1_ (u"࠭ࠧ孓"): l11lll11_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ孔"))
		if l11lll11_l1_==l1l111_l1_ (u"ࠨࠩ孕"): l1lllll1_l1_ = url
		else: l1lllll1_l1_ = url+l1l111_l1_ (u"ࠩ࠲࠳࡬࡫ࡴࡱࡱࡶࡸࡸࡅ࠿ࠨ孖")+l11lll11_l1_
		l1111111_l1_ = l1l1l11l1_l1_(l1lllll1_l1_,l1lll1ll111l_l1_)
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ字"),l1lllll_l1_+l1l111_l1_ (u"ࠫศ฾็ศำࠣๆฬฬๅสࠢส่ๆ๐ฯ๋๊ࠣห้ะ๊ࠡฬ่ࠤฬิส๋ษิ๋ฬࠦࠧ存"),l1111111_l1_,561,l1l111_l1_ (u"ࠬ࠭孙"),l1l111_l1_ (u"࠭ࠧ孚"),l1l111_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨ孛"))
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ孜"),l1lllll_l1_+l1l111_l1_ (u"ࠩࠣ࡟ࡠࠦࠠࠡࠩ孝")+l11l1l1l_l1_+l1l111_l1_ (u"ࠪࠤࠥࠦ࡝࡞ࠩ孞"),l1111111_l1_,561,l1l111_l1_ (u"ࠫࠬ孟"),l1l111_l1_ (u"ࠬ࠭孠"),l1l111_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷࡹࠧ孡"))
		addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ孢"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ季"),l1l111_l1_ (u"ࠩࠪ孤"),9999)
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ孥"),url,l1l111_l1_ (u"ࠫࠬ学"),l1l111_l1_ (u"ࠬ࠭孧"),l1l111_l1_ (u"࠭ࠧ孨"),l1l111_l1_ (u"ࠧࠨ孩"),l1l111_l1_ (u"ࠨ࡙ࡈࡇࡎࡓࡁ࠮ࡈࡌࡐ࡙ࡋࡒࡔࡡࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ孪"))
	html = response.content
	html = html.replace(l1l111_l1_ (u"ࠩ࡟ࡠࠧ࠭孫"),l1l111_l1_ (u"ࠪࠦࠬ孬")).replace(l1l111_l1_ (u"ࠫࡡࡢ࠯ࠨ孭"),l1l111_l1_ (u"ࠬ࠵ࠧ孮"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭࠼ࡸࡧࡦ࡭ࡲࡧ࠭࠮ࡨ࡬ࡰࡹ࡫ࡲࠩ࠰࠭ࡃ࠮ࡂ࠯ࡸࡧࡦ࡭ࡲࡧ࠭࠮ࡨ࡬ࡰࡹ࡫ࡲ࠿ࠩ孯"),html,re.DOTALL)
	if not l11llll_l1_: return
	block = l11llll_l1_[0]
	l1l11l1l_l1_ = re.findall(l1l111_l1_ (u"ࠧࡵࡣࡻࡳࡳࡵ࡭ࡺ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿ࠬ࠳࠰࠿ࠪ࠾ࡩ࡭ࡱࡺࡥࡳࡤࡲࡼࠬ孰"),block+l1l111_l1_ (u"ࠨ࠾ࡩ࡭ࡱࡺࡥࡳࡤࡲࡼࠬ孱"),re.DOTALL)
	dict = {}
	for l1l111ll_l1_,name,block in l1l11l1l_l1_:
		name = escapeUNICODE(name)
		if l1l111_l1_ (u"ࠩ࡬ࡲࡹ࡫ࡲࡦࡵࡷࠫ孲") in l1l111ll_l1_: continue
		items = re.findall(l1l111_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡶࡨࡶࡲࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡸࡽࡺ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡵࡺࡷࡂࠬ孳"),block,re.DOTALL)
		if l1l111_l1_ (u"ࠫࡂࡃࠧ孴") not in l1lllll1_l1_: l1lllll1_l1_ = url
		if type==l1l111_l1_ (u"ࠬࡉࡁࡕࡇࡊࡓࡗࡏࡅࡔࠩ孵"):
			if category!=l1l111ll_l1_: continue
			elif len(items)<=1:
				if l1l111ll_l1_==l1l1lll11_l1_[-1]: l1lll11_l1_(l1lllll1_l1_)
				else: l1l1ll1l_l1_(l1lllll1_l1_,l1l111_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࡢࡣࡤ࠭孶")+l1l111l1_l1_)
				return
			else:
				l1111111_l1_ = l1l1l11l1_l1_(l1lllll1_l1_,l1lll1ll111l_l1_)
				if l1l111ll_l1_==l1l1lll11_l1_[-1]:
					addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ孷"),l1lllll_l1_+l1l111_l1_ (u"ࠨษ็ะ๊๐ูࠨ學"),l1111111_l1_,561,l1l111_l1_ (u"ࠩࠪ孹"),l1l111_l1_ (u"ࠪࠫ孺"),l1l111_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࡷࠬ孻"))
				else: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ孼"),l1lllll_l1_+l1l111_l1_ (u"࠭วๅฮ่๎฾࠭孽"),l1lllll1_l1_,564,l1l111_l1_ (u"ࠧࠨ孾"),l1l111_l1_ (u"ࠨࠩ孿"),l1l111l1_l1_)
		elif type==l1l111_l1_ (u"ࠩࡉࡍࡑ࡚ࡅࡓࡕࠪ宀"):
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠪࠪࠫ࠭宁")+l1l111ll_l1_+l1l111_l1_ (u"ࠫࡂࡃ࠰ࠨ宂")
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠬࠬࠦࠨ它")+l1l111ll_l1_+l1l111_l1_ (u"࠭࠽࠾࠲ࠪ宄")
			l1l111l1_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠧࡠࡡࡢࠫ宅")+l1l1ll11_l1_
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ宆"),l1lllll_l1_+name+l1l111_l1_ (u"ࠩ࠽ࠤฬ๊ฬๆ์฼ࠫ宇"),l1lllll1_l1_,565,l1l111_l1_ (u"ࠪࠫ守"),l1l111_l1_ (u"ࠫࠬ安"),l1l111l1_l1_+l1l111_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧ宊"))
		dict[l1l111ll_l1_] = {}
		for value,option in items:
			name = escapeUNICODE(name)
			option = escapeUNICODE(option)
			if value==l1l111_l1_ (u"࠭ࡲࠨ宋") or value==l1l111_l1_ (u"ࠧ࡯ࡥ࠰࠵࠼࠭完"): continue
			if any(value in option.lower() for value in l11lll_l1_): continue
			if l1l111_l1_ (u"ࠨࡪࡷࡸࡵ࠭宍") in option: continue
			if l1l111_l1_ (u"ࠩส่่๊ࠧ宎") in option: continue
			if l1l111_l1_ (u"ࠪࡲ࠲ࡧࠧ宏") in value: continue
			if option==l1l111_l1_ (u"ࠫࠬ宐"): option = value
			l1l11l1ll_l1_ = option
			l1ll1l111ll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡂ࡮ࡢ࡯ࡨࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡳࡧ࡭ࡦࡀࠪ宑"),option,re.DOTALL)
			if l1ll1l111ll_l1_: l1l11l1ll_l1_ = l1ll1l111ll_l1_[0]
			l1lllllll_l1_ = name+l1l111_l1_ (u"࠭࠺ࠡࠩ宒")+l1l11l1ll_l1_
			dict[l1l111ll_l1_][value] = l1lllllll_l1_
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠧࠧࠨࠪ宓")+l1l111ll_l1_+l1l111_l1_ (u"ࠨ࠿ࡀࠫ宔")+l1l11l1ll_l1_
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠩࠩࠪࠬ宕")+l1l111ll_l1_+l1l111_l1_ (u"ࠪࡁࡂ࠭宖")+value
			l1l1l11l_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠫࡤࡥ࡟ࠨ宗")+l1l1ll11_l1_
			if type==l1l111_l1_ (u"ࠬࡌࡉࡍࡖࡈࡖࡘ࠭官"):
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭宙"),l1lllll_l1_+l1lllllll_l1_,url,565,l1l111_l1_ (u"ࠧࠨ定"),l1l111_l1_ (u"ࠨࠩ宛"),l1l1l11l_l1_+l1l111_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ宜"))
			elif type==l1l111_l1_ (u"ࠪࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙ࠧ宝") and l1l1lll11_l1_[-2]+l1l111_l1_ (u"ࠫࡂࡃࠧ实") in l11lll1l_l1_:
				l11ll111_l1_ = l11ll1l1_l1_(l1l1ll11_l1_,l1l111_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨ実"))
				l1llllll_l1_ = url+l1l111_l1_ (u"࠭࠯࠰ࡩࡨࡸࡵࡵࡳࡵࡵࡂࡃࠬ宠")+l11ll111_l1_
				l1111111_l1_ = l1l1l11l1_l1_(l1llllll_l1_,l1lll1ll111l_l1_)
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ审"),l1lllll_l1_+l1lllllll_l1_,l1111111_l1_,561,l1l111_l1_ (u"ࠨࠩ客"),l1l111_l1_ (u"ࠩࠪ宣"),l1l111_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫ室"))
			else: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ宥"),l1lllll_l1_+l1lllllll_l1_,url,564,l1l111_l1_ (u"ࠬ࠭宦"),l1l111_l1_ (u"࠭ࠧ宧"),l1l1l11l_l1_)
	return
l1l1lll11_l1_ = [l1l111_l1_ (u"ࠧࡨࡧࡱࡶࡪ࠭宨"),l1l111_l1_ (u"ࠨࡴࡨࡰࡪࡧࡳࡦ࠯ࡼࡩࡦࡸࠧ宩"),l1l111_l1_ (u"ࠩࡱࡥࡹ࡯࡯࡯ࠩ宪")]
l1l1ll111_l1_ = [l1l111_l1_ (u"ࠪࡱࡵࡧࡡࠨ宫"),l1l111_l1_ (u"ࠫ࡬࡫࡮ࡳࡧࠪ宬"),l1l111_l1_ (u"ࠬࡸࡥ࡭ࡧࡤࡷࡪ࠳ࡹࡦࡣࡵࠫ宭"),l1l111_l1_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹࠨ宮"),l1l111_l1_ (u"ࠧࡒࡷࡤࡰ࡮ࡺࡹࠨ宯"),l1l111_l1_ (u"ࠨ࡫ࡱࡸࡪࡸࡥࡴࡶࠪ宰"),l1l111_l1_ (u"ࠩࡱࡥࡹ࡯࡯࡯ࠩ宱"),l1l111_l1_ (u"ࠪࡰࡦࡴࡧࡶࡣࡪࡩࠬ宲")]
def l1l1l11l1_l1_(l1lllll1_l1_,l1llllll_l1_):
	if l1l111_l1_ (u"ࠫ࠴ࡇࡪࡢࡺࡆࡩࡳࡺࡥࡳ࠱ࡕ࡭࡬࡮ࡴࡃࡣࡵࠫ害") in l1lllll1_l1_: l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠬ࠵ࡁ࡫ࡣࡻࡇࡪࡴࡴࡦࡴ࠲ࡖ࡮࡭ࡨࡵࡄࡤࡶࠬ宴"),l1l111_l1_ (u"࠭࠯ࡂ࡬ࡤࡼࡈ࡫࡮ࡵࡧࡵ࠳ࡋ࡯࡬ࡵࡧࡵ࡭ࡳ࡭ࠧ宵"))
	l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠧ࠰࠱ࡪࡩࡹࡶ࡯ࡴࡶࡶࡃࡄ࠭家"),l1l111_l1_ (u"ࠨ࠼࠽࠳ࡆࡰࡡࡹࡅࡨࡲࡹ࡫ࡲ࠰ࡈ࡬ࡰࡹ࡫ࡲࡪࡰࡪ࠳ࠬ宷"))
	l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠩࡀࡁࠬ宸"),l1l111_l1_ (u"ࠪ࠳ࠬ容"))
	l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠫࠫࠬࠧ宺"),l1l111_l1_ (u"ࠬ࠵ࠧ宻"))
	return l1lllll1_l1_
def l11ll1l1_l1_(filters,mode):
	filters = filters.strip(l1l111_l1_ (u"࠭ࠦࠧࠩ宼"))
	l11lllll_l1_,l1l1l111_l1_ = {},l1l111_l1_ (u"ࠧࠨ宽")
	if l1l111_l1_ (u"ࠨ࠿ࡀࠫ宾") in filters:
		items = filters.split(l1l111_l1_ (u"ࠩࠩࠪࠬ宿"))
		for item in items:
			var,value = item.split(l1l111_l1_ (u"ࠪࡁࡂ࠭寀"))
			l11lllll_l1_[var] = value
	for key in l1l1ll111_l1_:
		if key in list(l11lllll_l1_.keys()): value = l11lllll_l1_[key]
		else: value = l1l111_l1_ (u"ࠫ࠵࠭寁")
		if l1l111_l1_ (u"ࠬࠫࠧ寂") not in value: value = QUOTE(value)
		if mode==l1l111_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨ寃") and value!=l1l111_l1_ (u"ࠧ࠱ࠩ寄"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠨࠢ࠮ࠤࠬ寅")+value
		elif mode==l1l111_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ密") and value!=l1l111_l1_ (u"ࠪ࠴ࠬ寇"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠫࠫࠬࠧ寈")+key+l1l111_l1_ (u"ࠬࡃ࠽ࠨ寉")+value
		elif mode==l1l111_l1_ (u"࠭ࡡ࡭࡮ࠪ寊"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠧࠧࠨࠪ寋")+key+l1l111_l1_ (u"ࠨ࠿ࡀࠫ富")+value
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠩࠣ࠯ࠥ࠭寍"))
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠪࠪࠫ࠭寎"))
	return l1l1l111_l1_
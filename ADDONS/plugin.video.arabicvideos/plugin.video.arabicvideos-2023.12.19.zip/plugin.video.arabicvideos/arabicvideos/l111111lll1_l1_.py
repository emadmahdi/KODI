# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"࡙ࠫ࡜ࡆࡖࡐࠪ娹")
l1lllll_l1_ = l1l111_l1_ (u"ࠬࡥࡔࡗࡈࡢࠫ娺")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"࠭ศฬ่ࠢฬฬฺัࠨ娻")]
def l11l1ll_l1_(mode,url,text):
	if   mode==460: l1lll_l1_ = l1l1l11_l1_()
	elif mode==461: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==462: l1lll_l1_ = PLAY(url)
	elif mode==463: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==469: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ娼"),l111l1_l1_,l1l111_l1_ (u"ࠨࠩ娽"),l1l111_l1_ (u"ࠩࠪ娾"),l1l111_l1_ (u"ࠪࠫ娿"),l1l111_l1_ (u"ࠫࠬ婀"),l1l111_l1_ (u"࡚ࠬࡖࡇࡗࡑ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭婁"))
	html = response.content
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭婂"),l1lllll_l1_+l1l111_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧ婃"),l1l111_l1_ (u"ࠨࠩ婄"),469,l1l111_l1_ (u"ࠩࠪ婅"),l1l111_l1_ (u"ࠪࠫ婆"),l1l111_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ婇"))
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ婈"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭婉"),l1l111_l1_ (u"ࠧࠨ婊"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡰࡩࡳࡻ࠭ࡣࡶࡱࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ婋"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡸࡶࡡ࡯ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡴࡦࡴ࠾ࠨ婌"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ婍") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			if title==l1l111_l1_ (u"ࠫฬ๊ัว์ึ๎ฮ࠭婎"): title = l1l111_l1_ (u"ࠬาฯ๋ัࠣั้่วหࠢอ๎ๆ๐ࠠโษ้ࠫ婏")
			if title in l11lll_l1_: continue
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭婐"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ婑")+l1lllll_l1_+title,l1ll1ll_l1_,461)
	return
def l1lll11_l1_(url,l111l1l1l_l1_=l1l111_l1_ (u"ࠨࠩ婒")):
	items = []
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭婓"),url,l1l111_l1_ (u"ࠪࠫ婔"),l1l111_l1_ (u"ࠫࠬ婕"),l1l111_l1_ (u"ࠬ࠭婖"),l1l111_l1_ (u"࠭ࠧ婗"),l1l111_l1_ (u"ࠧࡕࡘࡉ࡙ࡓ࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪ婘"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡪࡨࡥࡩ࠳ࡴࡪࡶ࡯ࡩࠧ࠮࠮ࠫࡁࠬ࡭ࡩࡃࠢࡧࡱࡲࡸࡪࡸࠢࠨ婙"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡷ࡬ࡺࡳࡢࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ婚"),block,re.DOTALL)
		l1l1_l1_ = []
		l1ll11_l1_ = [l1l111_l1_ (u"ู้ࠪอ็ะหࠪ婛"),l1l111_l1_ (u"ࠫๆ๐ไๆࠩ婜"),l1l111_l1_ (u"ࠬอฺ็์ฬࠫ婝"),l1l111_l1_ (u"࠭ใๅ์หࠫ婞"),l1l111_l1_ (u"ࠧศ฻็ห๋࠭婟"),l1l111_l1_ (u"ࠨ้าหๆ࠭婠"),l1l111_l1_ (u"่ࠩฬฬืวสࠩ婡"),l1l111_l1_ (u"ࠪ฽ึ฼ࠧ婢"),l1l111_l1_ (u"๊ࠫํัอษ้ࠫ婣"),l1l111_l1_ (u"ࠬอไษ๊่ࠫ婤")]
		for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
			if l1l111_l1_ (u"࠭ࡨࡵࡶࡳࠫ婥") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_)
			l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦวๅฯ็ๆฮࠦ࡜ࡥ࠭ࠪ婦"),title,re.DOTALL)
			if any(value in title for value in l1ll11_l1_):
				addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ婧"),l1lllll_l1_+title,l1ll1ll_l1_,462,l1ll1l_l1_)
			elif l1l1lll_l1_ and l1l111_l1_ (u"ࠩส่า๊โสࠩ婨") in title:
				title = l1l111_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ婩") + l1l1lll_l1_[0]
				if title not in l1l1_l1_:
					addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ婪"),l1lllll_l1_+title,l1ll1ll_l1_,463,l1ll1l_l1_)
					l1l1_l1_.append(title)
			else: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ婫"),l1lllll_l1_+title,l1ll1ll_l1_,463,l1ll1l_l1_)
	if l111l1l1l_l1_!=l1l111_l1_ (u"࠭࡬ࡢࡶࡨࡷࡹ࠭婬"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ婭"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭婮"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				l1ll1ll_l1_ = l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠩࠣࠫ婯"))
				if l1ll1ll_l1_==l1l111_l1_ (u"ࠥࠦ婰"): continue
				if l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ婱") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
				if title!=l1l111_l1_ (u"ࠬ࠭婲"): addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭婳"),l1lllll_l1_+l1l111_l1_ (u"ࠧึใะอࠥ࠭婴")+title,l1ll1ll_l1_,461)
	return
def l1ll1l11_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ婵"),url,l1l111_l1_ (u"ࠩࠪ婶"),l1l111_l1_ (u"ࠪࠫ婷"),l1l111_l1_ (u"ࠫࠬ婸"),l1l111_l1_ (u"ࠬ࠭婹"),l1l111_l1_ (u"࠭ࡔࡗࡈࡘࡒ࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠲ࡵࡷࠫ婺"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡩࡧࡤࡨ࠲ࡺࡩࡵ࡮ࡨࠦ࠭࠴ࠪࡀࠫ࡬ࡨࡂࠨࡦࡰࡱࡷࡩࡷࠨࠧ婻"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡶ࡫ࡹࡲࡨࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ婼"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
			if l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ婽") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ婾"),l1lllll_l1_+title,l1ll1ll_l1_,462,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭婿"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ媀"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			l1ll1ll_l1_ = l1ll1ll_l1_.strip(l1l111_l1_ (u"࠭ࠠࠨ媁"))
			if l1ll1ll_l1_==l1l111_l1_ (u"ࠢࠣ媂"): continue
			if l1l111_l1_ (u"ࠨࡪࡷࡸࡵ࠭媃") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			if title!=l1l111_l1_ (u"ࠩࠪ媄"): addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ媅"),l1lllll_l1_+l1l111_l1_ (u"ฺࠫ็อสࠢࠪ媆")+title,l1ll1ll_l1_,463)
	return
def PLAY(url):
	l1llll_l1_ = []
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ媇"),url,l1l111_l1_ (u"࠭ࠧ媈"),l1l111_l1_ (u"ࠧࠨ媉"),l1l111_l1_ (u"ࠨࠩ媊"),l1l111_l1_ (u"ࠩࠪ媋"),l1l111_l1_ (u"ࠪࡘ࡛ࡌࡕࡏ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ媌"))
	html = response.content
	l11l11lll1_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧ࡫࡭ࡣࡧࡧ࡙ࡷࡲࠢ࠻ࠢࠥࠬ࠳࠰࠿ࠪࠤࠪ媍"),html,re.DOTALL)
	if l11l11lll1_l1_:
		l11l11lll1_l1_ = l11l11lll1_l1_[0]
		if l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ媎") not in l11l11lll1_l1_:
			if l1l111_l1_ (u"࠭࠯࠰ࠩ媏") in l11l11lll1_l1_: l11l11lll1_l1_ = l1l111_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠭媐")+l11l11lll1_l1_
			else: l11l11lll1_l1_ = l111l1_l1_+l11l11lll1_l1_
		l11l11lll1_l1_ = l11l11lll1_l1_+l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࡡࡢࡩࡲࡨࡥࡥࠩ媑")
		l1llll_l1_.append(l11l11lll1_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡥ࠵࠺ࡀࡢࡦࡨࡲࡶࡪ࠮࠮ࠫࡁࠬࡷࡲࡧ࡬࡭࠰࠭ࡃࠧ࡜ࡩࡥࡧࡲࡗࡪࡸࡶࡦࡴࡶࠦ࠭࠴ࠪࡀࠫࠥࡔࡱࡧࡹࠣࠩ媒"),html,re.DOTALL)
	if l11llll_l1_:
		l111llll11l1_l1_,l111llll11ll_l1_ = l11llll_l1_[0]
		names = re.findall(l1l111_l1_ (u"ࠪࡧࡴࡴࡴࡦࡰࡷ࠾ࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠭媓"),l111llll11l1_l1_,re.DOTALL)
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠦࡸ࡫ࡴࡗ࡫ࡧࡩࡴࡢࠨࠨࠪ࠱࠮ࡄ࠯ࠧ࡝ࠫࠥ媔"),l111llll11ll_l1_,re.DOTALL)
		l111llll111l_l1_ = zip(names,l1ll_l1_)
		for name,l11ll1ll1l11_l1_ in l111llll111l_l1_:
			l11ll1ll1l11_l1_ = l11ll1ll1l11_l1_[2:]
			if PY2: l11ll1ll1l11_l1_ = l11ll1ll1l11_l1_.decode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ媕"))
			l11ll1ll1l11_l1_ = base64.b64decode(l11ll1ll1l11_l1_)
			if PY3: l11ll1ll1l11_l1_ = l11ll1ll1l11_l1_.decode(l1l111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ媖"))
			l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ媗"),l11ll1ll1l11_l1_,re.DOTALL)
			l1ll1ll_l1_ = l1ll1ll_l1_[0]
			if l1l111_l1_ (u"ࠨࡪࡷࡸࡵ࠭媘") not in l1ll1ll_l1_:
				if l1l111_l1_ (u"ࠩ࠲࠳ࠬ媙") in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻ࠩ媚")+l1ll1ll_l1_
				else: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ媛")+name+l1l111_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭媜")
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ媝"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search:
		search = l1llll1_l1_()
		if not search: return
	if l1l111_l1_ (u"ࠧࠡࠩ媞") in search:
		if l11_l1_: l1111l1_l1_(l1l111_l1_ (u"ࠨࠩ媟"),l1l111_l1_ (u"ࠩࠪ媠"),l1l111_l1_ (u"ࠪࡘ࡛ࡌࡕࡏ่ࠢ์็฿ࠠห์ไ๎ࠥ็ว็ࠩ媡"),l1l111_l1_ (u"้๊ࠫริใࠣห้ฮอฬࠢไ๎ࠥํะศࠢส่๊๎โฺࠢ็หࠥ๐ูๆๆࠣ฽๋ีุࠠๆหࠤศ้หา่๊้ࠢࠥไๆหࠣ์ฬำฯสࠢ࠱࠲࠳๊ࠦาฮ์ࠤฬ๊ศฮอࠣ฽๋ࠦใๅ็ฬࠤํออะหࠣๅ็฽ࠧ媢"))
		return
	url = l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡱ࠰ࠩ媣")+search+l1l111_l1_ (u"࠭࠯ࠨ媤")
	l1lll11_l1_(url)
	return
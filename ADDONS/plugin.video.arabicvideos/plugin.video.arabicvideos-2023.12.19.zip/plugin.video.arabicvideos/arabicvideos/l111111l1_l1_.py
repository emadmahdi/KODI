# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠫࡈࡏࡍࡂࡈࡄࡒࡘ࠭៿")
headers = { l1l111_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ᠀") : l1l111_l1_ (u"࠭ࠧ᠁") }
l1lllll_l1_ = l1l111_l1_ (u"ࠧࡠࡅࡐࡊࡤ࠭᠂")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
def l11l1ll_l1_(mode,url,text):
	if   mode==90: l1lll_l1_ = l1l1l11_l1_()
	elif mode==91: l1lll_l1_ = ITEMS(url)
	elif mode==92: l1lll_l1_ = PLAY(url)
	elif mode==94: l1lll_l1_ = l1lllll1l_l1_()
	elif mode==95: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==99: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᠃"),l1lllll_l1_+l1l111_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ᠄"),l1l111_l1_ (u"ࠪࠫ᠅"),99,l1l111_l1_ (u"ࠫࠬ᠆"),l1l111_l1_ (u"ࠬ࠭᠇"),l1l111_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ᠈"))
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ᠉"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ᠊"),l1l111_l1_ (u"ࠩࠪ᠋"),9999)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ᠌"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭᠍")+l1lllll_l1_+l1l111_l1_ (u"ࠬอไๆุสๅࠥำฯ๋อสࠫ᠎"),l1l111_l1_ (u"࠭ࠧ᠏"),94)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᠐"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ᠑")+l1lllll_l1_+l1l111_l1_ (u"ࠩส่ศำฯฬࠩ᠒"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡄࡺࡹࡱࡧࡀࡰࡦࡺࡥࡴࡶࠪ᠓"),91)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ᠔"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ᠕")+l1lllll_l1_+l1l111_l1_ (u"࠭วๅล฼่๎ࠦสใ์่ห๐࠭᠖"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡁࡷࡽࡵ࡫࠽ࡪ࡯ࡧࡦࠬ᠗"),91)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᠘"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ᠙")+l1lllll_l1_+l1l111_l1_ (u"ࠪห้ษใฬำู้ࠣอ็ะหࠪ᠚"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡅࡴࡺࡲࡨࡁࡻ࡯ࡥࡸࠩ᠛"),91)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ᠜"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ᠝")+l1lllll_l1_+l1l111_l1_ (u"ࠧศๆ่ฯอะࠧ᠞"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡂࡸࡾࡶࡥ࠾ࡲ࡬ࡲࠬ᠟"),91)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᠠ"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬᠡ")+l1lllll_l1_+l1l111_l1_ (u"ࠫัี๊ะࠢส่ศ็ไศ็ࠪᠢ"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵࠿ࡵࡻࡳࡩࡂࡴࡥࡸࡏࡲࡺ࡮࡫ࡳࠨᠣ"),91)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᠤ"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩᠥ")+l1lllll_l1_+l1l111_l1_ (u"ࠨฮา๎ิࠦวๅฯ็ๆฬะࠧᠦ"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡃࡹࡿࡰࡦ࠿ࡱࡩࡼࡋࡰࡪࡵࡲࡨࡪࡹࠧᠧ"),91)
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᠨ"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᠩ"),l1l111_l1_ (u"ࠬ࠭ᠪ"),9999)
	html = l1l1llll_l1_(l1ll1ll1_l1_,l111l1_l1_,l1l111_l1_ (u"࠭ࠧᠫ"),headers,l1l111_l1_ (u"ࠧࠨᠬ"),l1l111_l1_ (u"ࠨࡅࡌࡑࡆࡌࡁࡏࡕ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬᠭ"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡰࡥ࡮ࡴ࡭ࡦࡰࡸࠬ࠳࠰࠿ࠪࡰࡤࡺࠬᠮ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠪࡀࡱ࡯࠾࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬᠯ"),block,re.DOTALL)
	l11lll_l1_ = [l1l111_l1_ (u"ࠫฬ็ไศ็่้้ࠣศศำࠣๅ็฽ࠧᠰ")]
	for l1ll1ll_l1_,title in items:
		title = title.strip(l1l111_l1_ (u"ࠬࠦࠧᠱ"))
		if not any(value in title for value in l11lll_l1_):
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᠲ"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩᠳ")+l1lllll_l1_+title,l1ll1ll_l1_,91)
	return html
def ITEMS(url):
	if l1l111_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠰ࡳ࡬ࡵ࠭ᠴ") in url:
		url,search = url.split(l1l111_l1_ (u"ࠩࡂࡸࡂ࠭ᠵ"))
		headers = { l1l111_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧᠶ") : l1l111_l1_ (u"ࠫࠬᠷ") , l1l111_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫᠸ") : l1l111_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࠬᠹ") }
		data = { l1l111_l1_ (u"ࠧࡵࠩᠺ") : search }
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡒࡒࡗ࡙࠭ᠻ"),url,data,headers,l1l111_l1_ (u"ࠩࠪᠼ"),l1l111_l1_ (u"ࠪࠫᠽ"),l1l111_l1_ (u"ࠫࡈࡏࡍࡂࡈࡄࡒࡘ࠳ࡉࡕࡇࡐࡗ࠲࠷ࡳࡵࠩᠾ"))
		html = response.content
	else:
		headers = { l1l111_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩᠿ") : l1l111_l1_ (u"࠭ࠧᡀ") }
		html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠧࠨᡁ"),headers,l1l111_l1_ (u"ࠨࠩᡂ"),l1l111_l1_ (u"ࠩࡆࡍࡒࡇࡆࡂࡐࡖ࠱ࡎ࡚ࡅࡎࡕ࠰࠶ࡳࡪࠧᡃ"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡭ࡩࡃࠢ࡮ࡱࡹ࡭ࡪࡹ࠭ࡪࡶࡨࡱࡸ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡰ࡮ࡹࡴࡧࡱࡲࡸࠧ࠭ᡄ"),html,re.DOTALL)
	if l11llll_l1_: block = l11llll_l1_[0]
	else: block = l1l111_l1_ (u"ࠫࠬᡅ")
	items = re.findall(l1l111_l1_ (u"ࠬࡨࡡࡤ࡭ࡪࡶࡴࡻ࡮ࡥ࠯࡬ࡱࡦ࡭ࡥ࠻ࡷࡵࡰࡡ࠮ࠨ࠯ࠬࡂ࠭ࡡ࠯࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡱࡴࡼࡩࡦ࠯ࡷ࡭ࡹࡲࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩᡆ"),block,re.DOTALL)
	l1l1_l1_ = []
	for l1ll1l_l1_,l1ll1ll_l1_,title in items:
		if l1l111_l1_ (u"࠭วๅฯ็ๆฮ࠭ᡇ") in title and l1l111_l1_ (u"ࠧ࠰ࡥ࠲ࠫᡈ") not in url and l1l111_l1_ (u"ࠨ࠱ࡦࡥࡹ࠵ࠧᡉ") not in url:
			l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡษ็ั้่ษࠡ࡝࠳࠱࠾ࡣࠫࠨᡊ"),title,re.DOTALL)
			if l1l1lll_l1_:
				title = l1l111_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩᡋ")+l1l1lll_l1_[0]
				if title not in l1l1_l1_:
					addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᡌ"),l1lllll_l1_+title,l1ll1ll_l1_,95,l1ll1l_l1_)
					l1l1_l1_.append(title)
		elif l1l111_l1_ (u"ࠬ࠵ࡶࡪࡦࡨࡳ࠴࠭ᡍ") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬᡎ"),l1lllll_l1_+title,l1ll1ll_l1_,92,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᡏ"),l1lllll_l1_+title,l1ll1ll_l1_,91,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲ࠭࠴ࠪࡀࠫࡧ࡭ࡻ࠭ᡐ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᡑ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = unescapeHTML(title)
			title = title.replace(l1l111_l1_ (u"ࠪห้฻แฮหࠣࠫᡒ"),l1l111_l1_ (u"ࠫࠬᡓ"))
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᡔ"),l1lllll_l1_+l1l111_l1_ (u"࠭ีโฯฬࠤࠬᡕ")+title,l1ll1ll_l1_,91)
	return
def l1ll1l11_l1_(url):
	html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠧࠨᡖ"),headers,l1l111_l1_ (u"ࠨࠩᡗ"),l1l111_l1_ (u"ࠩࡆࡍࡒࡇࡆࡂࡐࡖ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪᡘ"))
	l1ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡭ࡲ࡭ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᡙ"),html,re.DOTALL)
	l1ll1l_l1_ = l1ll1l_l1_[0]
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࡮ࡪ࠽ࠣࡧࡳ࡭ࡸࡵࡤࡦࡵ࠰ࡴࡦࡴࡥ࡭ࠪ࠱࠮ࡄ࠯ࡤࡪࡸࠪᡚ"),html,re.DOTALL)
	if l11llll_l1_:
		name = re.findall(l1l111_l1_ (u"ࠬ࡯ࡴࡦ࡯ࡳࡶࡴࡶ࠽ࠣࡶ࡬ࡸࡱ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨᡛ"),html,re.DOTALL)
		if name: name = name[1]
		else:
			name = xbmc.getInfoLabel(l1l111_l1_ (u"࠭ࡌࡪࡵࡷࡍࡹ࡫࡭࠯ࡎࡤࡦࡪࡲࠧᡜ"))
			if l1l111_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᡝ") in name: name = name.split(l1l111_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᡞ"),1)[1]
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡲࡦࡳࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩᡟ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩᡠ"),l1lllll_l1_+name+l1l111_l1_ (u"ࠫࠥ࠳ࠠࠨᡡ")+title,l1ll1ll_l1_,92,l1ll1l_l1_)
	else:
		tmp = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡳ࡯ࡷ࡫ࡨࡸ࡮ࡺ࡬ࡦࠤࡁࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬᡢ"),html,re.DOTALL)
		if tmp: l1ll1ll_l1_,title = tmp[0]
		else: l1ll1ll_l1_,title = url,name
		addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬᡣ"),l1lllll_l1_+title,l1ll1ll_l1_,92,l1ll1l_l1_)
	return
def PLAY(url):
	l1llll_l1_,l1111111l_l1_ = [],[]
	html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠧࠨᡤ"),headers,l1l111_l1_ (u"ࠨࠩᡥ"),l1l111_l1_ (u"ࠩࡆࡍࡒࡇࡆࡂࡐࡖ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭ᡦ"))
	l1111ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡸࡪࡾࡴ࠮ࡵ࡫ࡥࡩࡵࡷ࠻ࠢࡱࡳࡳ࡫࠻ࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩᡧ"),html,re.DOTALL)
	if l1111ll_l1_ and l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_): return
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࡮ࡪ࠽ࠣ࡮࡬ࡲࡰࡹ࠭ࡱࡣࡱࡩࡱ࠮࠮ࠫࡁࠬࡨ࡮ࡼࠧᡨ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᡩ"),block,re.DOTALL)
		for l1ll1ll_l1_ in items:
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"࠭࠿ࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫᡪ")
			l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࡯ࡣࡹ࠱ࡹࡧࡢࡴࠤࠫ࠲࠯ࡅࠩࡷ࡫ࡧࡩࡴ࠳ࡰࡢࡰࡨࡰ࠲ࡳ࡯ࡳࡧࠪᡫ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨ࡫ࡧࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡦ࡯ࡥࡩࡩࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᡬ"),block,re.DOTALL)
		for id,l1ll1ll_l1_ in items:
			title = l1l111_l1_ (u"ࠩึ๎ึ็ัࠡࠩᡭ")+id
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫᡮ")+title+l1l111_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬᡯ")
			l1llll_l1_.append(l1ll1ll_l1_)
		items = re.findall(l1l111_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡷࡪࡸࡶࡦࡴ࠰ࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᡰ"),block,re.DOTALL)
		for l1ll1ll_l1_ in items:
			if l1l111_l1_ (u"࠭ࡨࡵࡶࡳࠫᡱ") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠭ᡲ")+l1ll1ll_l1_
			l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_)
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧᡳ"),url)
	return
def l1lllll1l_l1_():
	html = l1l1llll_l1_(l11l1l1_l1_,l111l1_l1_,l1l111_l1_ (u"ࠩࠪᡴ"),headers,l1l111_l1_ (u"ࠪࠫᡵ"),l1l111_l1_ (u"ࠫࡈࡏࡍࡂࡈࡄࡒࡘ࠳ࡌࡂࡖࡈࡗ࡙࠳࠱ࡴࡶࠪᡶ"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࡯ࡤ࠾ࠤ࡬ࡲࡩ࡫ࡸ࠮࡮ࡤࡷࡹ࠳࡭ࡰࡸ࡬ࡩ࠭࠴ࠪࡀࠫ࡬ࡨࡂࠨࡩ࡯ࡦࡨࡼ࠲ࡹ࡬ࡪࡦࡨࡶ࠲ࡳ࡯ࡷ࡫ࡨࠫᡷ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᡸ"),block,re.DOTALL)
	for l1ll1l_l1_,l1ll1ll_l1_,title in items:
		if l1l111_l1_ (u"ࠧ࠰ࡸ࡬ࡨࡪࡵ࠯ࠨ᡹") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ᡺"),l1lllll_l1_+title,l1ll1ll_l1_,92,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ᡻"),l1lllll_l1_+title,l1ll1ll_l1_,91,l1ll1l_l1_)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠪࠫ᡼"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠫࠬ᡽"): return
	search = search.replace(l1l111_l1_ (u"ࠬࠦࠧ᡾"),l1l111_l1_ (u"࠭ࠫࠨ᡿"))
	url = l111l1_l1_ + l1l111_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠯ࡲ࡫ࡴࡄࡺ࠽ࠨᢀ")+search
	ITEMS(url)
	return
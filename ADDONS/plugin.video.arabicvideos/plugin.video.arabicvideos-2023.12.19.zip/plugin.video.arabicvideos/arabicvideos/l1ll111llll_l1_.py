﻿# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
def l11l1ll_l1_(mode,l1ll11l1l1l_l1_):
	if l1ll11l1l1l_l1_==l1l111_l1_ (u"ࠩࠪッ"): return
	if mode==1:
		l1ll11l11ll_l1_ = xbmcgui.l1ll11l11l1_l1_()
		l1ll11l1l11_l1_ = xbmcgui.l1ll11l111l_l1_(l1ll11l11ll_l1_)
		l1ll11l1l1l_l1_ = l1ll11l1111_l1_(l1ll11l1l1l_l1_)
		l1ll11l1l11_l1_.getControl(311).l1ll11l1ll1_l1_(l1ll11l1l1l_l1_)
	if mode==0:
		l1ll111ll1l_l1_=l1l111_l1_ (u"ࠪ࡜ࠬツ")
		if PY3: check = isinstance(l1ll11l1l1l_l1_,str)
		else: check = isinstance(l1ll11l1l1l_l1_,unicode)
		if check==True: l1ll111ll1l_l1_=l1l111_l1_ (u"࡚ࠫ࠭ヅ")
		l1ll111ll11_l1_=str(type(l1ll11l1l1l_l1_))+l1l111_l1_ (u"ࠬࠦࠧテ")+l1ll11l1l1l_l1_+l1l111_l1_ (u"࠭ࠠࠨデ")+l1ll111ll1l_l1_+l1l111_l1_ (u"ࠧࠡࠩト")
		for i in range(0,len(l1ll11l1l1l_l1_),1):
			l1ll111ll11_l1_ += hex(ord(l1ll11l1l1l_l1_[i])).replace(l1l111_l1_ (u"ࠨ࠲ࡻࠫド"),l1l111_l1_ (u"ࠩࠪナ"))+l1l111_l1_ (u"ࠪࠤࠬニ")
		l1ll11l1l1l_l1_ = l1ll11l1111_l1_(l1ll11l1l1l_l1_)
		l1ll111ll1l_l1_=l1l111_l1_ (u"ࠫ࡝࠭ヌ")
		if PY3: check = isinstance(l1ll11l1l1l_l1_, str)
		else: check = isinstance(l1ll11l1l1l_l1_, unicode)
		if check==True: l1ll111ll1l_l1_=l1l111_l1_ (u"࡛ࠬࠧネ")
		l1ll111lll1_l1_=str(type(l1ll11l1l1l_l1_))+l1l111_l1_ (u"࠭ࠠࠨノ")+l1ll11l1l1l_l1_+l1l111_l1_ (u"ࠧࠡࠩハ")+l1ll111ll1l_l1_+l1l111_l1_ (u"ࠨࠢࠪバ")
		for i in range(0,len(l1ll11l1l1l_l1_),1):
			l1ll111lll1_l1_ += hex(ord(l1ll11l1l1l_l1_[i])).replace(l1l111_l1_ (u"ࠩ࠳ࡼࠬパ"),l1l111_l1_ (u"ࠪࠫヒ"))+l1l111_l1_ (u"ࠫࠥ࠭ビ")
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"࠭ࡇࡍࡑࡅࡅࡑ࡙ࡅࡂࡔࡆࡌࠬ⮀")
l1lllll_l1_ = l1l111_l1_ (u"ࠧࡠࡉࡏࡗࡤ࠭⮁")
def l11l1ll_l1_(mode,url,text,l1llllll1_l1_):
	if   mode==540: l1lll_l1_ = l1l1l11_l1_()
	elif mode==541: l1lll_l1_ = l1lll1l1l11_l1_(text)
	elif mode==542: l1lll_l1_ = l1lll111lll_l1_(text,url,l1llllll1_l1_)
	elif mode==549: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⮂"),l1l111_l1_ (u"ࠩหัะࠦฬะ์าࠫ⮃"),l1l111_l1_ (u"ࠪࠫ⮄"),549)
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ⮅"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝࠾࠿ࡀࡁ้ࠥไๆษอࠤ๊ิา็หࠣࡁࡂࡃ࠽࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ⮆"),l1l111_l1_ (u"࠭ࠧ⮇"),9999)
	l1lll1l1111_l1_ = l1lll11l111_l1_(main_dbfile,l1l111_l1_ (u"ࠧࡥ࡫ࡦࡸࠬ⮈"),l1l111_l1_ (u"ࠨࡉࡏࡓࡇࡇࡌࡔࡇࡄࡖࡈࡎ࡟ࡔࡋࡗࡉࡘ࠭⮉"))
	if l1lll1l1111_l1_:
		l1lll1l1111_l1_ = l1lll1l1111_l1_[l1l111_l1_ (u"ࠩࡢࡣࡘࡋࡑࡖࡇࡑࡇࡊࡊ࡟ࡄࡑࡏ࡙ࡒࡔࡓࡠࡡࠪ⮊")]
		for search in reversed(l1lll1l1111_l1_):
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⮋"),search,l1l111_l1_ (u"ࠫࠬ⮌"),549,l1l111_l1_ (u"ࠬ࠭⮍"),l1l111_l1_ (u"࠭ࠧ⮎"),search)
	return
def l1lll1_l1_(search):
	if not search:
		search = l1llll1_l1_()
		if not search: return
		search = search.lower()
	l1111l1l1l_l1_ = search.replace(l1lllll_l1_,l1l111_l1_ (u"ࠧࠨ⮏"))
	l1ll1llllll_l1_(l1111l1l1l_l1_)
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭⮐"),l1l111_l1_ (u"ࠩ฼้้ࠦศฮอࠣะ๊อู๋ࠢ࠰ࠤࠬ⮑")+l1111l1l1l_l1_,l1l111_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࡢࡷ࡮ࡺࡥࡴࠩ⮒"),542,l1l111_l1_ (u"ࠫࠬ⮓"),l1l111_l1_ (u"ࠬ࠭⮔"),l1111l1l1l_l1_)
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ⮕"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ⮖"),l1l111_l1_ (u"ࠨࠩ⮗"),9999)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⮘"),l1l111_l1_ (u"๊ࠪฯอฦอࠢส่อำหࠡ็ไู้ฯࠠ࠮ࠢࠪ⮙")+l1111l1l1l_l1_,l1l111_l1_ (u"ࠫࡴࡶࡥ࡯ࡧࡧࡣࡸ࡯ࡴࡦࡵࠪ⮚"),542,l1l111_l1_ (u"ࠬ࠭⮛"),l1l111_l1_ (u"࠭ࠧ⮜"),l1111l1l1l_l1_)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⮝"),l1l111_l1_ (u"ࠨ่อหหาࠠศๆหัะࠦๅใี่อࠥ࠳ࠠࠨ⮞")+l1111l1l1l_l1_,l1l111_l1_ (u"ࠩ࡯࡭ࡸࡺࡥࡥࡡࡶ࡭ࡹ࡫ࡳࠨ⮟"),542,l1l111_l1_ (u"ࠪࠫ⮠"),l1l111_l1_ (u"ࠫࠬ⮡"),l1111l1l1l_l1_)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⮢"),l1l111_l1_ (u"࠭ศฮอ้๋ࠣ็ัะࠢ࠰ࠤࠬ⮣")+l1111l1l1l_l1_,l1l111_l1_ (u"ࠧࠨ⮤"),541,l1l111_l1_ (u"ࠨࠩ⮥"),l1l111_l1_ (u"ࠩࠪ⮦"),l1111l1l1l_l1_)
	return
def l1ll1llllll_l1_(l1lll1ll1l1_l1_):
	l1lll1lll11_l1_ = l1lll11l111_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ⮧"),l1l111_l1_ (u"ࠫࡌࡒࡏࡃࡃࡏࡗࡊࡇࡒࡄࡊࡢࡗࡎ࡚ࡅࡔࠩ⮨"),l1lll1ll1l1_l1_)
	l1lll1ll1ll_l1_ = l1lll11l111_l1_(main_dbfile,l1l111_l1_ (u"ࠬࡲࡩࡴࡶࠪ⮩"),l1l111_l1_ (u"࠭ࡇࡍࡑࡅࡅࡑ࡙ࡅࡂࡔࡆࡌࡤ࡙ࡉࡕࡇࡖࠫ⮪"),l1lllll_l1_+l1lll1ll1l1_l1_)
	l1lll1l1lll_l1_(main_dbfile,l1l111_l1_ (u"ࠧࡈࡎࡒࡆࡆࡒࡓࡆࡃࡕࡇࡍࡥࡓࡊࡖࡈࡗࠬ⮫"),l1lll1ll1l1_l1_)
	l1lll1l1lll_l1_(main_dbfile,l1l111_l1_ (u"ࠨࡉࡏࡓࡇࡇࡌࡔࡇࡄࡖࡈࡎ࡟ࡔࡋࡗࡉࡘ࠭⮬"),l1lllll_l1_+l1lll1ll1l1_l1_)
	old_value = l1lll1lll11_l1_+l1lll1ll1ll_l1_
	if old_value: l1lll1ll1l1_l1_ = l1lllll_l1_+l1lll1ll1l1_l1_
	l1lll111111_l1_(main_dbfile,l1l111_l1_ (u"ࠩࡊࡐࡔࡈࡁࡍࡕࡈࡅࡗࡉࡈࡠࡕࡌࡘࡊ࡙ࠧ⮭"),l1lll1ll1l1_l1_,old_value,l1lll11l1ll_l1_)
	return
def l1lll1111ll_l1_():
	l1llll111l_l1_ = l1ll11ll1l_l1_(l1l111_l1_ (u"ࠪࠫ⮮"),l1l111_l1_ (u"ࠫࠬ⮯"),l1l111_l1_ (u"ࠬ࠭⮰"),l1l111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ⮱"),l1l111_l1_ (u"่ࠧๆࠣฮึ๐ฯࠡ็ึัࠥาๅ๋฻ࠣ็้๋วหࠢส่อำหࠡษ็้ำุๆสࠢไ๎ࠥอไษำ้ห๊าࠠภࠣࠤࠫ⮲"))
	if l1llll111l_l1_!=1: return
	l1lll1l1lll_l1_(main_dbfile,l1l111_l1_ (u"ࠨࡉࡏࡓࡇࡇࡌࡔࡇࡄࡖࡈࡎ࡟ࡔࡋࡗࡉࡘ࠭⮳"))
	l1lll1l1lll_l1_(main_dbfile,l1l111_l1_ (u"ࠩࡊࡐࡔࡈࡁࡍࡕࡈࡅࡗࡉࡈࡠࡑࡓࡉࡓࡋࡄࠨ⮴"))
	l1lll1l1lll_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡋࡑࡕࡂࡂࡎࡖࡉࡆࡘࡃࡉࡡࡆࡐࡔ࡙ࡅࡅࠩ⮵"))
	l1111l1_l1_(l1l111_l1_ (u"ࠫࠬ⮶"),l1l111_l1_ (u"ࠬ࠭⮷"),l1l111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ⮸"),l1l111_l1_ (u"ࠧห็ࠣฬ๋าวฮ่ࠢืาࠦฬๆ์฼ࠤ่๊ๅศฬࠣห้ฮอฬࠢส่๊ิา็หࠣๅ๏ࠦวๅสิ๊ฬ๋ฬࠨ⮹"))
	return
def l1lll111lll_l1_(l1lll111l11_l1_,action,l1lll11l1l1_l1_=l1l111_l1_ (u"ࠨࠩ⮺")):
	l1lll11ll11_l1_,l1lll11ll1l_l1_,l1lll1l111l_l1_,l1ll1lll111_l1_,l1ll1lll1ll_l1_,l1ll1lll1l1_l1_,threads = [],[],[],{},{},{},{}
	if action!=l1l111_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࡡࡶ࡭ࡹ࡫ࡳࠨ⮻"):
		if action==l1l111_l1_ (u"ࠪࡰ࡮ࡹࡴࡦࡦࡢࡷ࡮ࡺࡥࡴࠩ⮼"): l1lll1l111l_l1_ = l1lll11l111_l1_(main_dbfile,l1l111_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ⮽"),l1l111_l1_ (u"ࠬࡍࡌࡐࡄࡄࡐࡘࡋࡁࡓࡅࡋࡣࡘࡏࡔࡆࡕࠪ⮾"),l1lllll_l1_+l1lll111l11_l1_)
		elif action==l1l111_l1_ (u"࠭࡯ࡱࡧࡱࡩࡩࡥࡳࡪࡶࡨࡷࠬ⮿"): l1lll1l111l_l1_ = l1lll11l111_l1_(main_dbfile,l1l111_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ⯀"),l1l111_l1_ (u"ࠨࡉࡏࡓࡇࡇࡌࡔࡇࡄࡖࡈࡎ࡟ࡐࡒࡈࡒࡊࡊࠧ⯁"),l1lll111l11_l1_)
		elif action==l1l111_l1_ (u"ࠩࡦࡰࡴࡹࡥࡥࡡࡶ࡭ࡹ࡫ࡳࠨ⯂"): l1lll1l111l_l1_ = l1lll11l111_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ⯃"),l1l111_l1_ (u"ࠫࡌࡒࡏࡃࡃࡏࡗࡊࡇࡒࡄࡊࡢࡇࡑࡕࡓࡆࡆࠪ⯄"),(l1lll11l1l1_l1_,l1lll111l11_l1_))
	if not l1lll1l111l_l1_:
		l1lll1l1l1l_l1_ = l1l111_l1_ (u"ࠬํะศࠢส่อำหࠡ฼ํี๋่ࠥอ๊าࠤๆ๐ࠠไษืࠤฬ๊ศา่ส้ัࠦ࡜࡯࡞ࡱࡠࡳ࠭⯅")
		l1lll1l1ll1_l1_ = l1l111_l1_ (u"࠭็ๅࠢอี๏ีࠠศๆล๊ࠥอไษฯฮࠤๆ๐ࠠอ็ํ฽ࠥอไๆ๊สๆ฾ูࠦ็ࠢ࡟ࡲࠥࠨ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠢࠪ⯆")+l1lll111l11_l1_+l1l111_l1_ (u"ࠧࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠥࠤࡡࡴฺࠠๆ่หࠥษๆ้ࠡำหࠥอไษฯฮࠤ็ี๋ࠠฯอหัࠦศฺุࠣห้๎โหࠩ⯇")
		if action==l1l111_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡠࡵ࡬ࡸࡪࡹࠧ⯈"): message = l1lll1l1ll1_l1_
		else: message = l1lll1l1l1l_l1_+l1lll1l1ll1_l1_
		l1llll111l_l1_ = l1ll11ll1l_l1_(l1l111_l1_ (u"ࠩࠪ⯉"),l1l111_l1_ (u"ࠪࠫ⯊"),l1l111_l1_ (u"ࠫࠬ⯋"),l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ⯌"),message)
		if l1llll111l_l1_!=1: return
		l11llllll1_l1_(l1l111_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭⯍"),l11llll11l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠧࠡࠢࠣࡗࡪࡧࡲࡤࡪࠣࡊࡴࡸ࠺ࠡ࡝ࠣࠫ⯎")+l1lll111l11_l1_+l1l111_l1_ (u"ࠨࠢࡠࠫ⯏"))
		import threading
		l1llll1111l_l1_ = 1
		for l1lll11l1l1_l1_ in l1lll11llll_l1_:
			l1ll1lll111_l1_[l1lll11l1l1_l1_] = []
			options = l1l111_l1_ (u"ࠩࡢࡒࡔࡊࡉࡂࡎࡒࡋࡘࡥࠧ⯐")
			if l1l111_l1_ (u"ࠪ࠱ࠬ⯑") in l1lll11l1l1_l1_: options = options+l1l111_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࠩ⯒")+l1lll11l1l1_l1_+l1l111_l1_ (u"ࠬࡥࠧ⯓")
			l1lll11111l_l1_,l1lll11l11l_l1_,l1llll11111_l1_ = l1ll1llll11_l1_(l1lll11l1l1_l1_)
			if l1llll1111l_l1_:
				time.sleep(0.5)
				threads[l1lll11l1l1_l1_] = threading.Thread(target=l1lll11l11l_l1_,args=(l1lll111l11_l1_+options,))
				threads[l1lll11l1l1_l1_].start()
			else: l1lll11l11l_l1_(l1lll111l11_l1_+options)
			l1ll1lll_l1_(TRANSLATE(l1lll11l1l1_l1_),l1l111_l1_ (u"࠭ࠧ⯔"),time=1000)
		if l1llll1111l_l1_:
			time.sleep(2)
			for l1lll11l1l1_l1_ in l1lll11llll_l1_:
				threads[l1lll11l1l1_l1_].join(10)
			time.sleep(2)
		for l1lll11l1l1_l1_ in l1lll11llll_l1_:
			l1lll11111l_l1_,l1lll11l11l_l1_,l1llll11111_l1_ = l1ll1llll11_l1_(l1lll11l1l1_l1_)
			for l1lll111ll1_l1_ in menuItemsLIST:
				type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll111_l1_ = l1lll111ll1_l1_
				if l1llll11111_l1_ in name:
					if l1l111_l1_ (u"ࠧࡊࡒࡗ࡚࠲࠭⯕") in l1lll11l1l1_l1_ and (239>=mode>=230 or 289>=mode>=280):
						if l1lll111ll1_l1_ in l1ll1lll111_l1_[l1l111_l1_ (u"ࠨࡋࡓࡘ࡛࠳ࡌࡊࡘࡈࠫ⯖")]: continue
						if l1lll111ll1_l1_ in l1ll1lll111_l1_[l1l111_l1_ (u"ࠩࡌࡔ࡙࡜࠭ࡎࡑ࡙ࡍࡊ࡙ࠧ⯗")]: continue
						if l1lll111ll1_l1_ in l1ll1lll111_l1_[l1l111_l1_ (u"ࠪࡍࡕ࡚ࡖ࠮ࡕࡈࡖࡎࡋࡓࠨ⯘")]: continue
						if l1l111_l1_ (u"ฺࠫ็อสࠩ⯙") not in name:
							if   type==l1l111_l1_ (u"ࠬࡲࡩࡷࡧࠪ⯚"): l1lll11l1l1_l1_ = l1l111_l1_ (u"࠭ࡉࡑࡖ࡙࠱ࡑࡏࡖࡆࠩ⯛")
							elif type==l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭⯜"): l1lll11l1l1_l1_ = l1l111_l1_ (u"ࠨࡋࡓࡘ࡛࠳ࡍࡐࡘࡌࡉࡘ࠭⯝")
							elif type==l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⯞"): l1lll11l1l1_l1_ = l1l111_l1_ (u"ࠪࡍࡕ࡚ࡖ࠮ࡕࡈࡖࡎࡋࡓࠨ⯟")
						else:
							if   l1l111_l1_ (u"ࠫࡑࡏࡖࡆࠩ⯠") in url: l1lll11l1l1_l1_ = l1l111_l1_ (u"ࠬࡏࡐࡕࡘ࠰ࡐࡎ࡜ࡅࠨ⯡")
							elif l1l111_l1_ (u"࠭ࡍࡐࡘࡌࡉࡘ࠭⯢") in url: l1lll11l1l1_l1_ = l1l111_l1_ (u"ࠧࡊࡒࡗ࡚࠲ࡓࡏࡗࡋࡈࡗࠬ⯣")
							elif l1l111_l1_ (u"ࠨࡕࡈࡖࡎࡋࡓࠨ⯤") in url: l1lll11l1l1_l1_ = l1l111_l1_ (u"ࠩࡌࡔ࡙࡜࠭ࡔࡇࡕࡍࡊ࡙ࠧ⯥")
					elif l1l111_l1_ (u"ࠪࡑ࠸࡛࠭ࠨ⯦") in l1lll11l1l1_l1_ and 729>=mode>=710:
						if l1lll111ll1_l1_ in l1ll1lll111_l1_[l1l111_l1_ (u"ࠫࡒ࠹ࡕ࠮ࡎࡌ࡚ࡊ࠭⯧")]: continue
						if l1lll111ll1_l1_ in l1ll1lll111_l1_[l1l111_l1_ (u"ࠬࡓ࠳ࡖ࠯ࡐࡓ࡛ࡏࡅࡔࠩ⯨")]: continue
						if l1lll111ll1_l1_ in l1ll1lll111_l1_[l1l111_l1_ (u"࠭ࡍ࠴ࡗ࠰ࡗࡊࡘࡉࡆࡕࠪ⯩")]: continue
						if l1l111_l1_ (u"ࠧึใะอࠬ⯪") not in name:
							if   type==l1l111_l1_ (u"ࠨ࡮࡬ࡺࡪ࠭⯫"): l1lll11l1l1_l1_ = l1l111_l1_ (u"ࠩࡐ࠷࡚࠳ࡌࡊࡘࡈࠫ⯬")
							elif type==l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ⯭"): l1lll11l1l1_l1_ = l1l111_l1_ (u"ࠫࡒ࠹ࡕ࠮ࡏࡒ࡚ࡎࡋࡓࠨ⯮")
							elif type==l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⯯"): l1lll11l1l1_l1_ = l1l111_l1_ (u"࠭ࡍ࠴ࡗ࠰ࡗࡊࡘࡉࡆࡕࠪ⯰")
						else:
							if   l1l111_l1_ (u"ࠧࡍࡋ࡙ࡉࠬ⯱") in url: l1lll11l1l1_l1_ = l1l111_l1_ (u"ࠨࡏ࠶࡙࠲ࡒࡉࡗࡇࠪ⯲")
							elif l1l111_l1_ (u"ࠩࡐࡓ࡛ࡏࡅࡔࠩ⯳") in url: l1lll11l1l1_l1_ = l1l111_l1_ (u"ࠪࡑ࠸࡛࠭ࡎࡑ࡙ࡍࡊ࡙ࠧ⯴")
							elif l1l111_l1_ (u"ࠫࡘࡋࡒࡊࡇࡖࠫ⯵") in url: l1lll11l1l1_l1_ = l1l111_l1_ (u"ࠬࡓ࠳ࡖ࠯ࡖࡉࡗࡏࡅࡔࠩ⯶")
					elif l1l111_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࠨ⯷") in l1lll11l1l1_l1_ and 149>=mode>=140:
						if l1lll111ll1_l1_ in l1ll1lll111_l1_[l1l111_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡅࡋࡅࡓࡔࡅࡍࡕࠪ⯸")]: continue
						if l1lll111ll1_l1_ in l1ll1lll111_l1_[l1l111_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡓࡐࡆ࡟ࡌࡊࡕࡗࡗࠬ⯹")]: continue
						if l1lll111ll1_l1_ in l1ll1lll111_l1_[l1l111_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰࡚ࡎࡊࡅࡐࡕࠪ⯺")]: continue
						if l1l111_l1_ (u"ูࠪๆำษࠡลัี๎࠭⯻") in name or l1l111_l1_ (u"ࠫ࠿ࡀࠠࠨ⯼") in name:
							continue
						else:
							if   mode==144 and l1l111_l1_ (u"࡛ࠬࡓࡆࡔࠪ⯽") in name: l1lll11l1l1_l1_ = l1l111_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡄࡊࡄࡒࡓࡋࡌࡔࠩ⯾")
							elif mode==144 and l1l111_l1_ (u"ࠧࡄࡊࡑࡐࠬ⯿") in name: l1lll11l1l1_l1_ = l1l111_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡆࡌࡆࡔࡎࡆࡎࡖࠫⰀ")
							elif mode==144 and l1l111_l1_ (u"ࠩࡏࡍࡘ࡚ࠧⰁ") in name: l1lll11l1l1_l1_ = l1l111_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱ࡕࡒࡁ࡚ࡎࡌࡗ࡙࡙ࠧⰂ")
							elif mode==143: l1lll11l1l1_l1_ = l1l111_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲࡜ࡉࡅࡇࡒࡗࠬⰃ")
							else: continue
					elif l1l111_l1_ (u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰ࠫⰄ") in l1lll11l1l1_l1_ and 419>=mode>=400:
						if l1lll111ll1_l1_ in l1ll1lll111_l1_[l1l111_l1_ (u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱ࡕࡒࡁ࡚ࡎࡌࡗ࡙࡙ࠧⰅ")]: continue
						if l1lll111ll1_l1_ in l1ll1lll111_l1_[l1l111_l1_ (u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲ࡉࡈࡂࡐࡑࡉࡑ࡙ࠧⰆ")]: continue
						if l1lll111ll1_l1_ in l1ll1lll111_l1_[l1l111_l1_ (u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡖࡊࡆࡈࡓࡘ࠭Ⰷ")]: continue
						if l1lll111ll1_l1_ in l1ll1lll111_l1_[l1l111_l1_ (u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡕࡑࡓࡍࡈ࡙ࠧⰈ")]: continue
						if   mode in [401,405]: l1lll11l1l1_l1_ = l1l111_l1_ (u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡒࡏࡅ࡞ࡒࡉࡔࡖࡖࠫⰉ")
						elif mode in [402,406]: l1lll11l1l1_l1_ = l1l111_l1_ (u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯ࡆࡌࡆࡔࡎࡆࡎࡖࠫⰊ")
						elif mode in [403,404]: l1lll11l1l1_l1_ = l1l111_l1_ (u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰࡚ࡎࡊࡅࡐࡕࠪⰋ")
						elif mode in [412,413]: l1lll11l1l1_l1_ = l1l111_l1_ (u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱࡙ࡕࡐࡊࡅࡖࠫⰌ")
					elif l1l111_l1_ (u"ࠧࡑࡃࡑࡉ࡙࠳ࠧⰍ") in l1lll11l1l1_l1_ and 39>=mode>=30:
						if l1lll111ll1_l1_ in l1ll1lll111_l1_[l1l111_l1_ (u"ࠨࡒࡄࡒࡊ࡚࠭ࡔࡇࡕࡍࡊ࡙ࠧⰎ")]: continue
						if l1lll111ll1_l1_ in l1ll1lll111_l1_[l1l111_l1_ (u"ࠩࡓࡅࡓࡋࡔ࠮ࡏࡒ࡚ࡎࡋࡓࠨⰏ")]: continue
						if   mode in [32,39]: l1lll11l1l1_l1_ = l1l111_l1_ (u"ࠪࡔࡆࡔࡅࡕ࠯ࡖࡉࡗࡏࡅࡔࠩⰐ")
						elif mode in [33,39]: l1lll11l1l1_l1_ = l1l111_l1_ (u"ࠫࡕࡇࡎࡆࡖ࠰ࡑࡔ࡜ࡉࡆࡕࠪⰑ")
					elif l1l111_l1_ (u"ࠬࡏࡆࡊࡎࡐ࠱ࠬⰒ") in l1lll11l1l1_l1_ and 29>=mode>=20:
						if l1lll111ll1_l1_ in l1ll1lll111_l1_[l1l111_l1_ (u"࠭ࡉࡇࡋࡏࡑ࠲ࡇࡒࡂࡄࡌࡇࠬⰓ")]: continue
						if l1lll111ll1_l1_ in l1ll1lll111_l1_[l1l111_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠳ࡅࡏࡉࡏࡍࡘࡎࠧⰔ")]: continue
						if   l1l111_l1_ (u"ࠨ࠱ࡤࡶ࠳࠭Ⱅ") in url: l1lll11l1l1_l1_ = l1l111_l1_ (u"ࠩࡌࡊࡎࡒࡍ࠮ࡃࡕࡅࡇࡏࡃࠨⰖ")
						elif l1l111_l1_ (u"ࠪ࠳ࡪࡴ࠮ࠨⰗ") in url: l1lll11l1l1_l1_ = l1l111_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡉࡓࡍࡌࡊࡕࡋࠫⰘ")
					l1ll1lll111_l1_[l1lll11l1l1_l1_].append(l1lll111ll1_l1_)
		menuItemsLIST[:] = []
		for l1lll11l1l1_l1_ in list(l1ll1lll111_l1_.keys()):
			l1ll1lll1ll_l1_[l1lll11l1l1_l1_] = []
			l1ll1lll1l1_l1_[l1lll11l1l1_l1_] = []
			for type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll111_l1_ in l1ll1lll111_l1_[l1lll11l1l1_l1_]:
				l1lll111ll1_l1_ = (type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll111_l1_)
				if l1l111_l1_ (u"ࠬ฻แฮหࠪⰙ") in name and type==l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ⱊ"): l1ll1lll1l1_l1_[l1lll11l1l1_l1_].append(l1lll111ll1_l1_)
				else: l1ll1lll1ll_l1_[l1lll11l1l1_l1_].append(l1lll111ll1_l1_)
		l1lll1l11ll_l1_ = [(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬⰛ"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠ้ํอโฺࠢึ๎ึ็ัศฬࠣาฬ฻ษࠡ࠯ࠣๆ้๐ไสࠢสฺ่๊วไๆ࡞࠳ࡈࡕࡌࡐࡔࡠࠫⰜ"),l1l111_l1_ (u"ࠩࠪⰝ"),157,l1l111_l1_ (u"ࠪࠫⰞ"),l1l111_l1_ (u"ࠫࠬⰟ"),l1l111_l1_ (u"ࠬ࠭Ⱐ"),l1l111_l1_ (u"࠭ࠧⰡ"),l1l111_l1_ (u"ࠧࠨⰢ"))]
		for l1lll11l1l1_l1_ in l1lll11lll1_l1_:
			if l1lll11l1l1_l1_==l1lll1111l1_l1_[0]: l1lll1l11ll_l1_ = [(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭Ⱓ"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ๊๎วใ฻ࠣื๏ืแาษอࠤำอีส๋ࠢ฽ฬ๋ษࠡ࠯ࠣ็ะ๐ัสࠢสฺ่๊วไๆ࡞࠳ࡈࡕࡌࡐࡔࡠࠫⰤ"),l1l111_l1_ (u"ࠪࠫⰥ"),157,l1l111_l1_ (u"ࠫࠬⰦ"),l1l111_l1_ (u"ࠬ࠭Ⱗ"),l1l111_l1_ (u"࠭ࠧⰨ"),l1l111_l1_ (u"ࠧࠨⰩ"),l1l111_l1_ (u"ࠨࠩⰪ"))]
			elif l1lll11l1l1_l1_==l1lll1lll1l_l1_[0]: l1lll1l11ll_l1_ = [(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧⰫ"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ๋่ศไ฼ࠤุ๐ัโำสฮࠥ฿วๆหࠣ࠱้ࠥห๋ำฬࠤฬ๊ๅีษๆ่ࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭Ⱜ"),l1l111_l1_ (u"ࠫࠬⰭ"),157,l1l111_l1_ (u"ࠬ࠭Ⱞ"),l1l111_l1_ (u"࠭ࠧⰯ"),l1l111_l1_ (u"ࠧࠨⰰ"),l1l111_l1_ (u"ࠨࠩⰱ"),l1l111_l1_ (u"ࠩࠪⰲ"))]
			elif l1lll11l1l1_l1_==l1ll1lll11l_l1_[0]: l1lll1l11ll_l1_ = [(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨⰳ"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣๅ้ษๅ฽ู๊ࠥาใิหฯࠦฮศืฬࠤ࠲ࠦโๅ์็อࠥอไๆึส็้ࡡ࠯ࡄࡑࡏࡓࡗࡣࠧⰴ"),l1l111_l1_ (u"ࠬ࠭ⰵ"),157,l1l111_l1_ (u"࠭ࠧⰶ"),l1l111_l1_ (u"ࠧࠨⰷ"),l1l111_l1_ (u"ࠨࠩⰸ"),l1l111_l1_ (u"ࠩࠪⰹ"),l1l111_l1_ (u"ࠪࠫⰺ"))]
			if l1lll11l1l1_l1_ not in l1ll1lll1ll_l1_.keys(): continue
			if l1ll1lll1ll_l1_[l1lll11l1l1_l1_]:
				l1ll1lllll1_l1_ = TRANSLATE(l1lll11l1l1_l1_)
				l1lll111l1l_l1_ = [(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩⰻ"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝࠾࠿ࡀࡁࡂࠦࠧⰼ")+l1ll1lllll1_l1_+l1l111_l1_ (u"࠭ࠠ࠾࠿ࡀࡁࡂࡡ࠯ࡄࡑࡏࡓࡗࡣࠧⰽ"),l1l111_l1_ (u"ࠧࠨⰾ"),9999,l1l111_l1_ (u"ࠨࠩⰿ"),l1l111_l1_ (u"ࠩࠪⱀ"),l1l111_l1_ (u"ࠪࠫⱁ"),l1l111_l1_ (u"ࠫࠬⱂ"),l1l111_l1_ (u"ࠬ࠭ⱃ"))]
				if 0:
					l1lll1llll1_l1_ = l1lll111l11_l1_+l1l111_l1_ (u"࠭ࠠ࠮ࠢࠪⱄ")+l1l111_l1_ (u"ࠧษฯฮࠫⱅ")+l1l111_l1_ (u"ࠨࠢࠪⱆ")+l1ll1lllll1_l1_
				else:
					l1lll1llll1_l1_ = l1l111_l1_ (u"ࠩหัะ࠭ⱇ")+l1l111_l1_ (u"ࠪࠤࠬⱈ")+l1ll1lllll1_l1_+l1l111_l1_ (u"ࠫࠥ࠳ࠠࠨⱉ")+l1lll111l11_l1_
				if len(l1ll1lll1ll_l1_[l1lll11l1l1_l1_])<8: l1lll1l11l1_l1_ = []
				else:
					l1lll1lllll_l1_ = l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨⱊ")+l1lll1llll1_l1_+l1l111_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨⱋ")
					l1lll1l11l1_l1_ = [(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⱌ"),l1lllll_l1_+l1lll1lllll_l1_,l1l111_l1_ (u"ࠨࡥ࡯ࡳࡸ࡫ࡤࡠࡵ࡬ࡸࡪࡹࠧⱍ"),542,l1l111_l1_ (u"ࠩࠪⱎ"),l1lll11l1l1_l1_,l1lll111l11_l1_,l1l111_l1_ (u"ࠪࠫⱏ"),l1l111_l1_ (u"ࠫࠬⱐ"))]
				l1lll1ll111_l1_ = l1ll1lll1ll_l1_[l1lll11l1l1_l1_]+l1ll1lll1l1_l1_[l1lll11l1l1_l1_]
				l1lll11ll1l_l1_ += l1lll1l11ll_l1_+l1lll111l1l_l1_+l1lll1ll111_l1_[:7]+l1lll1l11l1_l1_
				l1ll1llll1l_l1_ = [(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⱑ"),l1lllll_l1_+l1lll1llll1_l1_,l1l111_l1_ (u"࠭ࡣ࡭ࡱࡶࡩࡩࡥࡳࡪࡶࡨࡷࠬⱒ"),542,l1l111_l1_ (u"ࠧࠨⱓ"),l1lll11l1l1_l1_,l1lll111l11_l1_,l1l111_l1_ (u"ࠨࠩⱔ"),l1l111_l1_ (u"ࠩࠪⱕ"))]
				l1lll11ll11_l1_ += l1lll1l11ll_l1_+l1ll1llll1l_l1_
				l1lll1l11ll_l1_ = []
				l1lll111111_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡋࡑࡕࡂࡂࡎࡖࡉࡆࡘࡃࡉࡡࡆࡐࡔ࡙ࡅࡅࠩⱖ"),(l1lll11l1l1_l1_,l1lll111l11_l1_),l1lll1ll111_l1_,l1lll11l1ll_l1_)
		l1lll111111_l1_(main_dbfile,l1l111_l1_ (u"ࠫࡌࡒࡏࡃࡃࡏࡗࡊࡇࡒࡄࡊࡢࡓࡕࡋࡎࡆࡆࠪⱗ"),l1lll111l11_l1_,l1lll11ll1l_l1_,l1lll11l1ll_l1_)
		l1lll1l1lll_l1_(main_dbfile,l1l111_l1_ (u"ࠬࡍࡌࡐࡄࡄࡐࡘࡋࡁࡓࡅࡋࡣࡘࡏࡔࡆࡕࠪⱘ"),l1lll111l11_l1_)
		l1lll111111_l1_(main_dbfile,l1l111_l1_ (u"࠭ࡇࡍࡑࡅࡅࡑ࡙ࡅࡂࡔࡆࡌࡤ࡙ࡉࡕࡇࡖࠫⱙ"),l1lllll_l1_+l1lll111l11_l1_,l1lll11ll11_l1_,l1lll11l1ll_l1_)
		l1111l1_l1_(l1l111_l1_ (u"ࠧࠨⱚ"),l1l111_l1_ (u"ࠨࠩⱛ"),l1l111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬⱜ"),l1l111_l1_ (u"ࠪห้ฮอฬࠢส่ั๋วฺ์ࠣห๋ะ็๊ࠢห๊ัออࠡ࡞ࡱࡠࡳࠦสๆࠢอาื๐ๆࠡษ็๊ฯอฦอࠢไ๎้ࠥวีࠢส่อืๆศ็ฯࠤ้๋ฯสࠢฮ่ฬั๊็ࠢํ์๊ࠦไไ์ࠣฮุะื๋฻ࠣห้฿่ะหࠣษ้๐็ศࠢหำํ์ฺࠠ็็ࠤอำหࠡฮา๎ิ࠭ⱝ"))
		if action==l1l111_l1_ (u"ࠫࡱ࡯ࡳࡵࡧࡧࡣࡸ࡯ࡴࡦࡵࠪⱞ") and l1lll11ll11_l1_: l1lll1l111l_l1_ = l1lll11ll11_l1_
		else: l1lll1l111l_l1_ = l1lll11ll1l_l1_
	if action!=l1l111_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࡤࡹࡩࡵࡧࡶࠫⱟ"):
		for type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll111_l1_ in l1lll1l111l_l1_:
			if action in [l1l111_l1_ (u"࠭࡬ࡪࡵࡷࡩࡩࡥࡳࡪࡶࡨࡷࠬⱠ"),l1l111_l1_ (u"ࠧࡰࡲࡨࡲࡪࡪ࡟ࡴ࡫ࡷࡩࡸ࠭ⱡ")] and l1l111_l1_ (u"ࠨืไัฮ࠭Ɫ") in name and type==l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⱣ"): continue
			addMenuItem(type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll111_l1_)
	return
def l1lll1l1l11_l1_(l1lll111l11_l1_=l1l111_l1_ (u"ࠪࠫⱤ")):
	search,options,l11_l1_ = l111ll_l1_(l1lll111l11_l1_)
	if not search:
		search = l1llll1_l1_()
		if not search: return
		search = search.lower()
	l11llllll1_l1_(l1l111_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫⱥ"),l11llll11l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠬࠦࠠࠡࡕࡨࡥࡷࡩࡨࠡࡈࡲࡶ࠿࡛ࠦࠡࠩⱦ")+search+l1l111_l1_ (u"࠭ࠠ࡞ࠩⱧ"))
	l1lll1ll_l1_ = search+options
	if 0: l1lll1ll11l_l1_,l1111l1l1l_l1_ = search+l1l111_l1_ (u"ࠧࠡ࠯ࠣࠫⱨ"),l1l111_l1_ (u"ࠨࠩⱩ")
	else: l1lll1ll11l_l1_,l1111l1l1l_l1_ = l1l111_l1_ (u"ࠩࠪⱪ"),l1l111_l1_ (u"ࠪࠤ࠲ࠦࠧⱫ")+search
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩⱬ"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ๆ๊สๆ฾ࠦำ๋ำไีฬะࠠฯษุอࠥ࠳ࠠใๆํ่ฮࠦวๅ็ืห่๊࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨⱭ"),l1l111_l1_ (u"࠭ࠧⱮ"),157)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⱯ"),l1l111_l1_ (u"ࠨࡡࡐ࠷࡚ࡥࠧⱰ")+l1lll1ll11l_l1_+l1l111_l1_ (u"ࠩหัะࠦࡍ࠴ࡗࠪⱱ")+l1111l1l1l_l1_,l1l111_l1_ (u"ࠪࠫⱲ"),719,l1l111_l1_ (u"ࠫࠬⱳ"),l1l111_l1_ (u"ࠬ࠭ⱴ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ⱶ"),l1l111_l1_ (u"ࠧࡠࡋࡓࡘࡤ࠭ⱶ")+l1lll1ll11l_l1_+l1l111_l1_ (u"ࠨสะฯࠥࡏࡐࡕࡘࠪⱷ")+l1111l1l1l_l1_,l1l111_l1_ (u"ࠩࠪⱸ"),239,l1l111_l1_ (u"ࠪࠫⱹ"),l1l111_l1_ (u"ࠫࠬⱺ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⱻ"),l1l111_l1_ (u"࠭࡟ࡃࡍࡕࡣࠬⱼ")+l1lll1ll11l_l1_+l1l111_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢห็ึอࠧⱽ")+l1111l1l1l_l1_,l1l111_l1_ (u"ࠨࠩⱾ"),379,l1l111_l1_ (u"ࠩࠪⱿ"),l1l111_l1_ (u"ࠪࠫⲀ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⲁ"),l1l111_l1_ (u"ࠬࡥࡋࡍࡃࡢࠫⲂ")+l1lll1ll11l_l1_+l1l111_l1_ (u"࠭ศฮอ้ࠣํู่ࠡๅ็ࠤฬู๊าสࠪⲃ")+l1111l1l1l_l1_,l1l111_l1_ (u"ࠧࠨⲄ"),19,l1l111_l1_ (u"ࠨࠩⲅ"),l1l111_l1_ (u"ࠩࠪⲆ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⲇ"),l1l111_l1_ (u"ࠫࡤࡇࡒࡕࡡࠪⲈ")+l1lll1ll11l_l1_+l1l111_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠห๊้ึࠥ฿ัษ์ฬࠫⲉ")+l1111l1l1l_l1_,l1l111_l1_ (u"࠭ࠧⲊ"),739,l1l111_l1_ (u"ࠧࠨⲋ"),l1l111_l1_ (u"ࠨࠩⲌ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⲍ"),l1l111_l1_ (u"ࠪࡣࡐࡘࡂࡠࠩⲎ")+l1lll1ll11l_l1_+l1l111_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦโ็ษฬࠤ่ืศๅษฤࠫⲏ")+l1111l1l1l_l1_,l1l111_l1_ (u"ࠬ࠭Ⲑ"),329,l1l111_l1_ (u"࠭ࠧⲑ"),l1l111_l1_ (u"ࠧࠨⲒ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⲓ"),l1l111_l1_ (u"ࠩࡢࡊࡍ࠷࡟ࠨⲔ")+l1lll1ll11l_l1_+l1l111_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥ็วึๆࠣห้ษ่ๅࠩⲕ")+l1111l1l1l_l1_,l1l111_l1_ (u"ࠫࠬⲖ"),579,l1l111_l1_ (u"ࠬ࠭ⲗ"),l1l111_l1_ (u"࠭ࠧⲘ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⲙ"),l1l111_l1_ (u"ࠨࡡࡎࡘ࡛ࡥࠧⲚ")+l1lll1ll11l_l1_+l1l111_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤ่ะใ้ฬࠣฮ๏็๊ࠨⲛ")+l1111l1l1l_l1_,l1l111_l1_ (u"ࠪࠫⲜ"),819,l1l111_l1_ (u"ࠫࠬⲝ"),l1l111_l1_ (u"ࠬ࠭Ⲟ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⲟ"),l1l111_l1_ (u"ࠧࡠࡇࡅ࠵ࡤ࠭Ⲡ")+l1lll1ll11l_l1_+l1l111_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣห๏า๊ࠡสํืฯࠦ࠱ࠨⲡ")+l1111l1l1l_l1_,l1l111_l1_ (u"ࠩࠪⲢ"),779,l1l111_l1_ (u"ࠪࠫⲣ"),l1l111_l1_ (u"ࠫࠬⲤ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⲥ"),l1l111_l1_ (u"࠭࡟ࡆࡄ࠵ࡣࠬⲦ")+l1lll1ll11l_l1_+l1l111_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢส๎ั๐ࠠษ์ึฮࠥ࠸ࠧⲧ")+l1111l1l1l_l1_,l1l111_l1_ (u"ࠨࠩⲨ"),789,l1l111_l1_ (u"ࠩࠪⲩ"),l1l111_l1_ (u"ࠪࠫⲪ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⲫ"),l1l111_l1_ (u"ࠬࡥࡉࡇࡎࡢࠫⲬ")+l1lll1ll11l_l1_+l1l111_l1_ (u"࠭ࠠࠡสะฯ๋่ࠥใ฻ࠣๆ๋อษࠡฤํࠤๆ๐ไๆࠩⲭ")+l1111l1l1l_l1_+l1l111_l1_ (u"ࠧࠡࠢࠪⲮ"),l1l111_l1_ (u"ࠨࠩⲯ"),29,l1l111_l1_ (u"ࠩࠪⲰ"),l1l111_l1_ (u"ࠪࠫⲱ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⲲ"),l1l111_l1_ (u"ࠬࡥࡁࡌࡑࡢࠫⲳ")+l1lll1ll11l_l1_+l1l111_l1_ (u"࠭ศฮอ้ࠣํู่ࠡลๆ์ฬ๋ࠠศๆๅำ๏๋ࠧⲴ")+l1111l1l1l_l1_,l1l111_l1_ (u"ࠧࠨⲵ"),79,l1l111_l1_ (u"ࠨࠩⲶ"),l1l111_l1_ (u"ࠩࠪⲷ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⲸ"),l1l111_l1_ (u"ࠫࡤࡇࡋࡘࡡࠪⲹ")+l1lll1ll11l_l1_+l1l111_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠฤๅ๋ห๊ࠦวๅฮา๎ิ࠭Ⲻ")+l1111l1l1l_l1_,l1l111_l1_ (u"࠭ࠧⲻ"),249,l1l111_l1_ (u"ࠧࠨⲼ"),l1l111_l1_ (u"ࠨࠩⲽ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⲾ"),l1l111_l1_ (u"ࠪࡣࡒࡘࡆࡠࠩⲿ")+l1lll1ll11l_l1_+l1l111_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦโ็ษฬࠤฬ๊ๅฺษิๅࠬⳀ")+l1111l1l1l_l1_,l1l111_l1_ (u"ࠬ࠭ⳁ"),49,l1l111_l1_ (u"࠭ࠧⳂ"),l1l111_l1_ (u"ࠧࠨⳃ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⳄ"),l1l111_l1_ (u"ࠩࡢࡗࡍࡓ࡟ࠨⳅ")+l1lll1ll11l_l1_+l1l111_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ฺ่ࠥโ่ࠢหู่ࠧⳆ")+l1111l1l1l_l1_,l1l111_l1_ (u"ࠫࠬⳇ"),59,l1l111_l1_ (u"ࠬ࠭Ⳉ"),l1l111_l1_ (u"࠭ࠧⳉ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⳊ"),l1l111_l1_ (u"ࠨࡡࡉࡘࡒࡥࠧⳋ")+l1lll1ll11l_l1_+l1l111_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤฬ๊ๅ็สิࠤฬ๊แศู่๎ࠬⳌ")+l1111l1l1l_l1_,l1l111_l1_ (u"ࠪࠫⳍ"),69,l1l111_l1_ (u"ࠫࠬⳎ"),l1l111_l1_ (u"ࠬ࠭ⳏ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫⳐ"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟่์ฬู่ࠡีํีๆืวหࠢัหฺฯ้ࠠ฻ส้ฮࠦ࠭ࠡๅฮ๎ึฯࠠศๆุ่ฬ้ไ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩⳑ"),l1l111_l1_ (u"ࠨࠩⳒ"),157)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⳓ"),l1l111_l1_ (u"ࠪࡣࡋࡐࡓࡠࠩⳔ")+l1lll1ll11l_l1_+l1l111_l1_ (u"ࠫࠥฮอฬ่ࠢ์็฿ࠠโฮิࠤู๎ࠧⳕ")+l1111l1l1l_l1_+l1l111_l1_ (u"ࠬࠦࠧⳖ"),l1l111_l1_ (u"࠭ࠧⳗ"),399,l1l111_l1_ (u"ࠧࠨⳘ"),l1l111_l1_ (u"ࠨࠩⳙ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⳚ"),l1l111_l1_ (u"ࠪࡣ࡙࡜ࡆࡠࠩⳛ")+l1lll1ll11l_l1_+l1l111_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦส๋ใํࠤๆอๆࠨⳜ")+l1111l1l1l_l1_,l1l111_l1_ (u"ࠬ࠭ⳝ"),469,l1l111_l1_ (u"࠭ࠧⳞ"),l1l111_l1_ (u"ࠧࠨⳟ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⳠ"),l1l111_l1_ (u"ࠩࡢࡐࡉࡔ࡟ࠨⳡ")+l1lll1ll11l_l1_+l1l111_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽๊่ࠥะ์๊ࠣฯ࠭Ⳣ")+l1111l1l1l_l1_,l1l111_l1_ (u"ࠫࠬⳣ"),459,l1l111_l1_ (u"ࠬ࠭ⳤ"),l1l111_l1_ (u"࠭ࠧ⳥"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⳦"),l1l111_l1_ (u"ࠨࡡࡆࡑࡓࡥࠧ⳧")+l1lll1ll11l_l1_+l1l111_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤุ๐ๅศ้ࠢหํ࠭⳨")+l1111l1l1l_l1_,l1l111_l1_ (u"ࠪࠫ⳩"),309,l1l111_l1_ (u"ࠫࠬ⳪"),l1l111_l1_ (u"ࠬ࠭Ⳬ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⳬ"),l1l111_l1_ (u"ࠧࡠ࡙ࡆࡑࡤ࠭Ⳮ")+l1lll1ll11l_l1_+l1l111_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣ์๏ࠦำ๋็สࠫⳮ")+l1111l1l1l_l1_,l1l111_l1_ (u"ࠩࠪ⳯"),569,l1l111_l1_ (u"ࠪࠫ⳰"),l1l111_l1_ (u"ࠫࠬ⳱"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⳲ"),l1l111_l1_ (u"࠭࡟ࡔࡊࡑࡣࠬⳳ")+l1lll1ll11l_l1_+l1l111_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢืห์ีࠠ็์๋ึࠬ⳴")+l1111l1l1l_l1_,l1l111_l1_ (u"ࠨࠩ⳵"),589,l1l111_l1_ (u"ࠩࠪ⳶"),l1l111_l1_ (u"ࠪࠫ⳷"),l1lll1ll_l1_+l1l111_l1_ (u"ࠫࡤࡔࡏࡅࡋࡄࡐࡔࡍࡓࡠࠩ⳸"))
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⳹"),l1l111_l1_ (u"࠭࡟ࡂࡔࡖࡣࠬ⳺")+l1lll1ll11l_l1_+l1l111_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢ฼ีอࠦำ๋์าࠫ⳻")+l1111l1l1l_l1_,l1l111_l1_ (u"ࠨࠩ⳼"),259,l1l111_l1_ (u"ࠩࠪ⳽"),l1l111_l1_ (u"ࠪࠫ⳾"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⳿"),l1l111_l1_ (u"ࠬࡥࡃࡄࡄࡢࠫⴀ")+l1lll1ll11l_l1_+l1l111_l1_ (u"࠭ศฮอ้ࠣํู่ࠡีํ้ฬࠦใๅ๊หࠫⴁ")+l1111l1l1l_l1_,l1l111_l1_ (u"ࠧࠨⴂ"),829,l1l111_l1_ (u"ࠨࠩⴃ"),l1l111_l1_ (u"ࠩࠪⴄ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⴅ"),l1l111_l1_ (u"ࠫࡤࡉ࠴ࡖࡡࠪⴆ")+l1lll1ll11l_l1_+l1l111_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠิ์่หࠥ็่า์๋ࠫⴇ")+l1111l1l1l_l1_,l1l111_l1_ (u"࠭ࠧⴈ"),429,l1l111_l1_ (u"ࠧࠨⴉ"),l1l111_l1_ (u"ࠨࠩⴊ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⴋ"),l1l111_l1_ (u"ࠪࡣࡘࡎ࠴ࡠࠩⴌ")+l1lll1ll11l_l1_+l1l111_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦิศ้าࠤๆ๎ั๋๊ࠪⴍ")+l1111l1l1l_l1_,l1l111_l1_ (u"ࠬ࠭ⴎ"),119,l1l111_l1_ (u"࠭ࠧⴏ"),l1l111_l1_ (u"ࠧࠨⴐ"),l1lll1ll_l1_+l1l111_l1_ (u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤ࠭ⴑ"))
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⴒ"),l1l111_l1_ (u"ࠪࡣࡊࡈ࠳ࡠࠩⴓ")+l1lll1ll11l_l1_+l1l111_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦว๋ฮํࠤอ๐ำหࠢ࠶ࠫⴔ")+l1111l1l1l_l1_,l1l111_l1_ (u"ࠬ࠭ⴕ"),799,l1l111_l1_ (u"࠭ࠧⴖ"),l1l111_l1_ (u"ࠧࠨⴗ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ⴘ"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ๊๎วใ฻ࠣื๏ืแาษอࠤ฾อๅสࠢ࠰ࠤ่ั๊าหࠣห้๋ิศๅ็࡟࠴ࡉࡏࡍࡑࡕࡡࠬⴙ"),l1l111_l1_ (u"ࠪࠫⴚ"),157)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⴛ"),l1l111_l1_ (u"ࠬࡥࡆࡔࡖࡢࠫⴜ")+l1lll1ll11l_l1_+l1l111_l1_ (u"࠭ศฮอ้ࠣํู่ࠡใ๋ืฯอࠧⴝ")+l1111l1l1l_l1_,l1l111_l1_ (u"ࠧࠨⴞ"),609,l1l111_l1_ (u"ࠨࠩⴟ"),l1l111_l1_ (u"ࠩࠪⴠ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⴡ"),l1l111_l1_ (u"ࠫࡤࡌࡂࡌࡡࠪⴢ")+l1lll1ll11l_l1_+l1l111_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠโสิ็ฮ࠭ⴣ")+l1111l1l1l_l1_,l1l111_l1_ (u"࠭ࠧⴤ"),629,l1l111_l1_ (u"ࠧࠨⴥ"),l1l111_l1_ (u"ࠨࠩ⴦"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⴧ"),l1l111_l1_ (u"ࠪࡣ࡞ࡗࡔࡠࠩ⴨")+l1lll1ll11l_l1_+l1l111_l1_ (u"ࠫอำหࠡ็๋ๆ฾๊ࠦศไ๋ฮࠬ⴩")+l1111l1l1l_l1_,l1l111_l1_ (u"ࠬ࠭⴪"),669,l1l111_l1_ (u"࠭ࠧ⴫"),l1l111_l1_ (u"ࠧࠨ⴬"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⴭ"),l1l111_l1_ (u"ࠩࡢࡆࡗ࡙࡟ࠨ⴮")+l1lll1ll11l_l1_+l1l111_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥฮัิฬํะࠬ⴯")+l1111l1l1l_l1_,l1l111_l1_ (u"ࠫࠬⴰ"),659,l1l111_l1_ (u"ࠬ࠭ⴱ"),l1l111_l1_ (u"࠭ࠧⴲ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⴳ"),l1l111_l1_ (u"ࠨࡡࡋࡐࡈࡥࠧⴴ")+l1lll1ll11l_l1_+l1l111_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤ์๊วࠡีํ้ฬ࠭ⴵ")+l1111l1l1l_l1_,l1l111_l1_ (u"ࠪࠫⴶ"),89,l1l111_l1_ (u"ࠫࠬⴷ"),l1l111_l1_ (u"ࠬ࠭ⴸ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⴹ"),l1l111_l1_ (u"ࠧࡠࡆࡕ࠻ࡤ࠭ⴺ")+l1lll1ll11l_l1_+l1l111_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣำึอๅศุࠢัࠬⴻ")+l1111l1l1l_l1_,l1l111_l1_ (u"ࠩࠪⴼ"),689,l1l111_l1_ (u"ࠪࠫⴽ"),l1l111_l1_ (u"ࠫࠬⴾ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⴿ"),l1l111_l1_ (u"࠭࡟ࡄࡏࡉࡣࠬⵀ")+l1lll1ll11l_l1_+l1l111_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢึ๎๊อࠠโษ้ึࠬⵁ")+l1111l1l1l_l1_,l1l111_l1_ (u"ࠨࠩⵂ"),99,l1l111_l1_ (u"ࠩࠪⵃ"),l1l111_l1_ (u"ࠪࠫⵄ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⵅ"),l1l111_l1_ (u"ࠬࡥࡃࡎࡎࡢࠫⵆ")+l1lll1ll11l_l1_+l1l111_l1_ (u"࠭ศฮอ้ࠣํู่ࠡีํ้ฬࠦไศ์อࠫⵇ")+l1111l1l1l_l1_,l1l111_l1_ (u"ࠧࠨⵈ"),479,l1l111_l1_ (u"ࠨࠩⵉ"),l1l111_l1_ (u"ࠩࠪⵊ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⵋ"),l1l111_l1_ (u"ࠫࡤࡇࡂࡅࡡࠪⵌ")+l1lll1ll11l_l1_+l1l111_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠิ์่หࠥ฿ศะ๊ࠪⵍ")+l1111l1l1l_l1_,l1l111_l1_ (u"࠭ࠧⵎ"),559,l1l111_l1_ (u"ࠧࠨⵏ"),l1l111_l1_ (u"ࠨࠩⵐ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⵑ"),l1l111_l1_ (u"ࠪࡣࡈ࠺ࡈࡠࠩⵒ")+l1lll1ll11l_l1_+l1l111_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦำ๋็สࠤ࠹࠶࠰ࠨⵓ")+l1111l1l1l_l1_,l1l111_l1_ (u"ࠬ࠭ⵔ"),699,l1l111_l1_ (u"࠭ࠧⵕ"),l1l111_l1_ (u"ࠧࠨⵖ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⵗ"),l1l111_l1_ (u"ࠩࡢࡅࡍࡑ࡟ࠨⵘ")+l1lll1ll11l_l1_+l1l111_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥษ็้ษๆࠤฯ๐แ๋ࠩⵙ")+l1111l1l1l_l1_,l1l111_l1_ (u"ࠫࠬⵚ"),619,l1l111_l1_ (u"ࠬ࠭ⵛ"),l1l111_l1_ (u"࠭ࠧⵜ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⵝ"),l1l111_l1_ (u"ࠨࡡࡖࡌ࡙ࡥࠧⵞ")+l1lll1ll11l_l1_+l1l111_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤู๎แ่ษࠣฮ๏็๊ࠨⵟ")+l1111l1l1l_l1_,l1l111_l1_ (u"ࠪࠫⵠ"),649,l1l111_l1_ (u"ࠫࠬⵡ"),l1l111_l1_ (u"ࠬ࠭ⵢ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⵣ"),l1l111_l1_ (u"ࠧࡠࡈࡋ࠶ࡤ࠭ⵤ")+l1lll1ll11l_l1_+l1l111_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣๅฬ฻ไࠡษ็ฯฬ์๊ࠨⵥ")+l1111l1l1l_l1_,l1l111_l1_ (u"ࠩࠪⵦ"),599,l1l111_l1_ (u"ࠪࠫⵧ"),l1l111_l1_ (u"ࠫࠬ⵨"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⵩"),l1l111_l1_ (u"࠭࡟ࡆࡄ࠷ࡣࠬ⵪")+l1lll1ll11l_l1_+l1l111_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢส๎ั๐ࠠษ์ึฮࠥ࠺ࠧ⵫")+l1111l1l1l_l1_,l1l111_l1_ (u"ࠨࠩ⵬"),809,l1l111_l1_ (u"ࠩࠪ⵭"),l1l111_l1_ (u"ࠪࠫ⵮"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⵯ"),l1l111_l1_ (u"ࠬࡥࡃࡄ࡙ࡢࠫ⵰")+l1lll1ll11l_l1_+l1l111_l1_ (u"࠭ศฮอ้ࠣํู่ࠡีํ้ฬࠦใๅ๊หࠤ฾๋ไࠨ⵱")+l1111l1l1l_l1_,l1l111_l1_ (u"ࠧࠨ⵲"),639,l1l111_l1_ (u"ࠨࠩ⵳"),l1l111_l1_ (u"ࠩࠪ⵴"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ⵵"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣๅ้ษๅ฽ู๊ࠥาใิหฯࠦฮศืฬࠤ࠲ࠦโๅ์็อࠥอไๆึส็้ࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ⵶"),l1l111_l1_ (u"ࠬ࠭⵷"),157)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⵸"),l1l111_l1_ (u"ࠧࡠ࡛ࡘࡘࡤ࠭⵹")+l1lll1ll11l_l1_+l1l111_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣ๎ํะ๊้สࠪ⵺")+l1111l1l1l_l1_,l1l111_l1_ (u"ࠩࠪ⵻"),149,l1l111_l1_ (u"ࠪࠫ⵼"),l1l111_l1_ (u"ࠫࠬ⵽"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⵾"),l1l111_l1_ (u"࠭࡟ࡅࡎࡐࡣ⵿ࠬ")+l1lll1ll11l_l1_+l1l111_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢา๎้๐ࠠๆ๊ื๊ࠬⶀ")+l1111l1l1l_l1_,l1l111_l1_ (u"ࠨࠩⶁ"),409,l1l111_l1_ (u"ࠩࠪⶂ"),l1l111_l1_ (u"ࠪࠫⶃ"),l1lll1ll_l1_)
	return
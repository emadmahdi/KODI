# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠩࡉࡅࡘࡋࡌࡉࡆ࠵ࠫ⨞")
headers = {l1l111_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ⨟"):l1l111_l1_ (u"ࠫࠬ⨠")}
l1lllll_l1_ = l1l111_l1_ (u"ࠬࡥࡆࡉ࠴ࡢࠫ⨡")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"࠭ࡷࡸࡧࠪ⨢")]
def l11l1ll_l1_(mode,url,text):
	if   mode==590: l1lll_l1_ = l1l1l11_l1_()
	elif mode==591: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==592: l1lll_l1_ = PLAY(url)
	elif mode==593: l1lll_l1_ = l1111lll1_l1_(url,text)
	elif mode==599: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	l1l11ll_l1_ = l111l1_l1_
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ⨣"),l1l11ll_l1_,l1l111_l1_ (u"ࠨࠩ⨤"),l1l111_l1_ (u"ࠩࠪ⨥"),l1l111_l1_ (u"ࠪࠫ⨦"),l1l111_l1_ (u"ࠫࠬ⨧"),l1l111_l1_ (u"ࠬࡌࡁࡔࡇࡏࡌࡉ࠸࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ⨨"))
	html = response.content
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⨩"),l1lllll_l1_+l1l111_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧ⨪"),l1l11ll_l1_,599,l1l111_l1_ (u"ࠨࠩ⨫"),l1l111_l1_ (u"ࠩࠪ⨬"),l1l111_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ⨭"))
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ⨮"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ⨯"),l1l111_l1_ (u"࠭ࠧ⨰"),9999)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⨱"),l1lllll_l1_+l1l111_l1_ (u"ࠨษ็้๊๐าสࠩ⨲"),l1l11ll_l1_,591,l1l111_l1_ (u"ࠩࠪ⨳"),l1l111_l1_ (u"ࠪࠫ⨴"),l1l111_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠷ࠧ⨵"))
	items = re.findall(l1l111_l1_ (u"ࠬࡂࡳࡵࡴࡲࡲ࡬ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡵࡴࡲࡲ࡬ࡄ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ⨶"),html,re.DOTALL)
	for title,l1ll1ll_l1_ in items:
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⨷"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ⨸")+l1lllll_l1_+title,l1ll1ll_l1_,591,l1l111_l1_ (u"ࠨࠩ⨹"),l1l111_l1_ (u"ࠩࠪ⨺"),l1l111_l1_ (u"ࠪࡨࡪࡺࡡࡪ࡮ࡶ࠵ࠬ⨻"))
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ⨼"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ⨽"),l1l111_l1_ (u"࠭ࠧ⨾"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࡮ࡣ࡬ࡲ࠲ࡳࡥ࡯ࡷࠥࠬ࠳࠰࠿ࠪࡪࡨࡥࡩ࡫ࡲ࠮ࡵࡲࡧ࡮ࡧ࡬ࠨ⨿"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1llll1l1l1_l1_ = re.findall(l1l111_l1_ (u"ࠨ࠾࡯࡭ࠥ࠮࠮ࠫࡁࠬࡀ࠴ࡲࡩ࠿ࠩ⩀"),block,re.DOTALL)
		for l1llll1ll11_l1_ in l1llll1l1l1_l1_:
			items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ⩁"),l1llll1ll11_l1_,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				if l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ⩂") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l11ll_l1_+l1ll1ll_l1_
				addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⩃"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ⩄")+l1lllll_l1_+title,l1ll1ll_l1_,591,l1l111_l1_ (u"࠭ࠧ⩅"),l1l111_l1_ (u"ࠧࠨ⩆"),l1l111_l1_ (u"ࠨࡦࡨࡸࡦ࡯࡬ࡴ࠴ࠪ⩇"))
	return html
def l1lll11_l1_(url,type=l1l111_l1_ (u"ࠩࠪ⩈")):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ⩉"),url,l1l111_l1_ (u"ࠫࠬ⩊"),l1l111_l1_ (u"ࠬ࠭⩋"),l1l111_l1_ (u"࠭ࠧ⩌"),l1l111_l1_ (u"ࠧࠨ⩍"),l1l111_l1_ (u"ࠨࡈࡄࡗࡊࡒࡈࡅ࠴࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧ⩎"))
	html = response.content
	l1llll111ll_l1_ = 0
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡥࡷࡩࡨࡪࡸࡨ࠱ࡸࡲࡩࡥࡧࡵࠬ࠳࠰࠿ࠪ࠾࡫࠸ࡃ࠭⩏"),html,re.DOTALL)
	if l11ll11_l1_: l1l1l1l_l1_ = l11ll11_l1_[0]
	else: l1l1l1l_l1_ = l1l111_l1_ (u"ࠪࠫ⩐")
	if type==l1l111_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠷ࠧ⩑"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡳ࡭࡫ࡧࡩࡷ࠳ࡣࡢࡴࡲࡹࡸ࡫࡬ࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡥࡲࡲࡹࡧࡩ࡯ࡧࡵࡂࠬ⩒"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠣࡵ࡯࡭ࡩ࡫ࡲ࠮ࡶ࡬ࡸࡱ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ⩓"),block,re.DOTALL)
		l11ll1l11_l1_,l11l11_l1_,l1ll_l1_ = zip(*items)
		items = zip(l1ll_l1_,l11ll1l11_l1_,l11l11_l1_)
	elif type==l1l111_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥ࠴ࠪ⩔"):
		items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡬ࡱࡦ࡭ࡥ࠻ࡷࡵࡰࡡ࠮ࠨ࠯ࠬࡂ࠭ࡡ࠯࠮ࠫࡁ࠿࡬࠸࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱࡫࠷ࡃ࠭⩕"),l1l1l1l_l1_,re.DOTALL)
	elif type==l1l111_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࡵࠪ⩖"):
		l11llll_l1_ = [html.replace(l1l111_l1_ (u"ࠪࡠࡡ࠵ࠧ⩗"),l1l111_l1_ (u"ࠫ࠴࠭⩘")).replace(l1l111_l1_ (u"ࠬࡢ࡜ࠣࠩ⩙"),l1l111_l1_ (u"࠭ࠢࠨ⩚"))]
	elif type==l1l111_l1_ (u"ࠧࡥࡧࡷࡥ࡮ࡲࡳ࠳ࠩ⩛") and l1l111_l1_ (u"ࠨࡪࡵࡩ࡫࠭⩜") in l1l1l1l_l1_:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩ࠿࡬࠹ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡨ࠵ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡦࡳࡳࡺࡡࡪࡰࡨࡶࡃ࠭⩝"),html,re.DOTALL)
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⩞"),l1lllll_l1_+l1l111_l1_ (u"๊๋๊ࠫำหࠪ⩟"),url,591,l1l111_l1_ (u"ࠬ࠭⩠"),l1l111_l1_ (u"࠭ࠧ⩡"),l1l111_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥ࠴ࠪ⩢"))
		title = l11llll_l1_[0][0]
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⩣"),l1lllll_l1_+title,url,591,l1l111_l1_ (u"ࠩࠪ⩤"),l1l111_l1_ (u"ࠪࠫ⩥"),l1l111_l1_ (u"ࠫࡩ࡫ࡴࡢ࡫࡯ࡷ࠸࠭⩦"))
		return
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡂࡨ࠵ࡀࠫ࠲࠯ࡅࠩ࠽࠱࡫࠸ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠿ࠩ⩧"),html,re.DOTALL)
		title,block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡪ࡯ࡤ࡫ࡪࡀࡵࡳ࡮࡟ࠬ࠭࠴ࠪࡀࠫ࡟࠭࠳࠰࠿࠽ࡪ࠶࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡩ࠵ࡁࠫ⩨"),block,re.DOTALL)
	l1ll11_l1_ = [l1l111_l1_ (u"ࠧๆึส๋ิฯࠧ⩩"),l1l111_l1_ (u"ࠨใํ่๊࠭⩪"),l1l111_l1_ (u"ࠩส฾๋๐ษࠨ⩫"),l1l111_l1_ (u"ࠪ็้๐ศࠨ⩬"),l1l111_l1_ (u"ࠫฬ฿ไศ่ࠪ⩭"),l1l111_l1_ (u"ࠬํฯศใࠪ⩮"),l1l111_l1_ (u"࠭ๅษษิหฮ࠭⩯"),l1l111_l1_ (u"ฺࠧำูࠫ⩰"),l1l111_l1_ (u"ࠨ็๊ีัอๆࠨ⩱"),l1l111_l1_ (u"ࠩส่อ๎ๅࠨ⩲"),l1l111_l1_ (u"ุ้ࠪือ๋หࠪ⩳"),l1l111_l1_ (u"ࠫา๊โสࠩ⩴")]
	l1l1_l1_ = []
	for l1ll1ll_l1_,l1ll1l_l1_,title in items:
		if any(value in title.lower() for value in l11lll_l1_): continue
		title = title.strip(l1l111_l1_ (u"ࠬࠦࠧ⩵"))
		title = unescapeHTML(title)
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥ࠮วๅฯ็ๆฮࢂอๅไฬ࠭࠳ࡢࡤࠬࠩ⩶"),title,re.DOTALL)
		if l1l111_l1_ (u"ࠧ࠰࡯ࡲࡺࡸ࡫ࡲࡪࡧࡶ࠳ࠬ⩷") in l1ll1ll_l1_:
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⩸"),l1lllll_l1_+title,l1ll1ll_l1_,591,l1ll1l_l1_)
		elif l1l1lll_l1_ and type==l1l111_l1_ (u"ࠩࠪ⩹"):
			title = l1l111_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ⩺")+l1l1lll_l1_[0][0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⩻"),l1lllll_l1_+title,l1ll1ll_l1_,593,l1ll1l_l1_)
				l1l1_l1_.append(title)
		elif any(value in title for value in l1ll11_l1_):
			addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ⩼"),l1lllll_l1_+title,l1ll1ll_l1_,592,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⩽"),l1lllll_l1_+title,l1ll1ll_l1_,593,l1ll1l_l1_)
	if type==l1l111_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨ⩾"):
		l111l1l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡰࡳࡷ࡫࡟ࡣࡷࡷࡸࡴࡴ࡟ࡱࡣࡪࡩࠧࡀࠨ࠯ࠬࡂ࠭࠱࠭⩿"),block,re.DOTALL)
		if l111l1l1ll_l1_:
			count = l111l1l1ll_l1_[0]
			l1ll1ll_l1_ = url+l1l111_l1_ (u"ࠩ࠲ࡳ࡫࡬ࡳࡦࡶ࠲ࠫ⪀")+count
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⪁"),l1lllll_l1_+l1l111_l1_ (u"ฺࠫ็อสࠢฦาึ๏ࠧ⪂"),l1ll1ll_l1_,591,l1l111_l1_ (u"ࠬ࠭⪃"),l1l111_l1_ (u"࠭ࠧ⪄"),l1l111_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨ⪅"))
	elif l1l111_l1_ (u"ࠨࡦࡨࡸࡦ࡯࡬ࡴࠩ⪆") in type:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ⪇"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ⪈"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				title = l1l111_l1_ (u"ฺࠫ็อสࠢࠪ⪉")+unescapeHTML(title)
				addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⪊"),l1lllll_l1_+title,l1ll1ll_l1_,591,l1l111_l1_ (u"࠭ࠧ⪋"),l1l111_l1_ (u"ࠧࠨ⪌"),l1l111_l1_ (u"ࠨࡦࡨࡸࡦ࡯࡬ࡴ࠶ࠪ⪍"))
	return
def l1111lll1_l1_(url,type=l1l111_l1_ (u"ࠩࠪ⪎")):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ⪏"),url,l1l111_l1_ (u"ࠫࠬ⪐"),l1l111_l1_ (u"ࠬ࠭⪑"),l1l111_l1_ (u"࠭ࠧ⪒"),l1l111_l1_ (u"ࠧࠨ⪓"),l1l111_l1_ (u"ࠨࡈࡄࡗࡊࡒࡈࡅ࠴࠰ࡗࡊࡇࡓࡐࡐࡖࡣࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪ⪔"))
	html = response.content
	l111lll1l1_l1_ = False
	if not type:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩ࠿ࡷࡪࡧࡳࡰࡰࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡪࡧࡳࡰࡰࡶࡂࠬ⪕"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡮ࡳࡡࡨࡧ࠽ࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪ࠰࠭ࡃࡁ࡮࠳࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡪ࠶ࡂࠬ⪖"),block,re.DOTALL)
			if len(items)>1:
				l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ⪗"))
				l111lll1l1_l1_ = True
				for l1ll1ll_l1_,l1ll1l_l1_,title in items:
					title = unescapeHTML(title)
					addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⪘"),l1lllll_l1_+title,l1ll1ll_l1_,593,l1ll1l_l1_,l1l111_l1_ (u"࠭ࠧ⪙"),l1l111_l1_ (u"ࠧࡦࡲ࡬ࡷࡴࡪࡥࡴࠩ⪚"))
	if type==l1l111_l1_ (u"ࠨࡧࡳ࡭ࡸࡵࡤࡦࡵࠪ⪛") or not l111lll1l1_l1_:
		l11l_l1_ = re.findall(l1l111_l1_ (u"ࠩ࠿ࡦࡰุࠪࡀ࡫ࡰࡥ࡬࡫࠺ࡶࡴ࡯ࡠ࠭࠮࠮ࠫࡁࠬࡠ࠮ࠨ࠾࠽࠱ࡥ࡯ࡃ࠭⪜"),html,re.DOTALL)
		if l11l_l1_: l1ll1l_l1_ = l11l_l1_[0]
		else: l1ll1l_l1_ = l1l111_l1_ (u"ࠪࠫ⪝")
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡁࡧ࡬࡭࠯ࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡱࡲ࠭ࡦࡲ࡬ࡷࡴࡪࡥࡴࡀࠪ⪞"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ⪟"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				title = title.strip(l1l111_l1_ (u"࠭ࠠࠨ⪠"))
				title = unescapeHTML(title)
				addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭⪡"),l1lllll_l1_+title,l1ll1ll_l1_,592,l1ll1l_l1_)
	return
def PLAY(url):
	l1ll11l1_l1_,l1llll1l111_l1_,l1llll1l1ll_l1_ = [],[],[]
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ⪢"),url,l1l111_l1_ (u"ࠩࠪ⪣"),l1l111_l1_ (u"ࠪࠫ⪤"),l1l111_l1_ (u"ࠫࠬ⪥"),l1l111_l1_ (u"ࠬ࠭⪦"),l1l111_l1_ (u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠲࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ⪧"))
	html = response.content
	l1llll11l1l_l1_ = re.findall(l1l111_l1_ (u"ࠧศๆ฼้ึࠦ࠺࠯ࠬࡂࡀࡸࡺࡲࡰࡰࡪࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡴࡳࡱࡱ࡫ࡃ࠭⪨"),html,re.DOTALL)
	if l1llll11l1l_l1_ and l11111l_l1_(l1ll1_l1_,url,l1llll11l1l_l1_): return
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࠾࡬ࡪࡷࡧ࡭ࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⪩"),html,re.DOTALL)
	if l1ll1ll_l1_:
		l1ll1ll_l1_ = l1ll1ll_l1_[0]
		l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࡢࡣࡪࡳࡢࡦࡦࠪ⪪"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡀࡸࡲࡩࡤࡧ࠰ࡸ࡮ࡺ࡬ࡦࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ⪫"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡸࡶࡱࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࠳࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵࡬ࡪࡀࠪ⪬"),block,re.DOTALL)
		for l1ll1ll_l1_,name in items:
			name = name.strip(l1l111_l1_ (u"ࠬࠦࠧ⪭"))
			l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ⪮")+name+l1l111_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨ⪯"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࠾ࡧࡳࡼࡴ࡬ࡰࡣࡧࡷ࠭࠴ࠪࡀࠫ࠿࠳ࡩࡵࡷ࡯࡮ࡲࡥࡩࡹ࠾ࠨ⪰"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴ࡪࡩࡷࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ⪱"),block,re.DOTALL)
		for l1ll1ll_l1_,name in items:
			l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ⪲")+name+l1l111_l1_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨ⪳"))
	for l1llll11lll_l1_ in l1ll11l1_l1_:
		l1ll1ll_l1_,name = l1llll11lll_l1_.split(l1l111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࠬ⪴"))
		if l1ll1ll_l1_ not in l1llll1l111_l1_:
			l1llll1l111_l1_.append(l1ll1ll_l1_)
			l1llll1l1ll_l1_.append(l1llll11lll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll1l1ll_l1_,l1ll1_l1_,l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ⪵"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠧࠨ⪶"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠨࠩ⪷"): return
	search = search.replace(l1l111_l1_ (u"ࠩࠣࠫ⪸"),l1l111_l1_ (u"ࠪ࠯ࠬ⪹"))
	l1l11ll_l1_ = l111l1_l1_
	url = l1l11ll_l1_+l1l111_l1_ (u"ࠫ࠴ࡅࡳ࠾ࠩ⪺")+search
	l1lll11_l1_(url,l1l111_l1_ (u"ࠬࡪࡥࡵࡣ࡬ࡰࡸ࠻ࠧ⪻"))
	return
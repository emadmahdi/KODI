# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠸ࠧ⃱")
l1lllll_l1_ = l1l111_l1_ (u"࠭࡟ࡆࡄ࠵ࡣࠬ⃲")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠧศๆู่ฬืูสࠢส่าืษࠨ⃳"),l1l111_l1_ (u"ࠨษํะ๏ࠦศ๋ีอࠫ⃴"),l1l111_l1_ (u"ࠩ฼ีํ฼ࠠศๆู่ฬืูสࠩ⃵"),l1l111_l1_ (u"ࠪࡩ࡬ࡿࡢࡦࡵࡷࠫ⃶"),l1l111_l1_ (u"ࠫฬ๐ฬ๋ࠢหืฯࠦวๅสา๎้࠭⃷"),l1l111_l1_ (u"ࠬอ๊อ๋ࠣฬุะࠠศๆฯำ๏ีࠧ⃸")]
def l11l1ll_l1_(mode,url,l1llllll1_l1_,text):
	if   mode==780: l1lll_l1_ = l1l1l11_l1_()
	elif mode==781: l1lll_l1_ = l1lll11_l1_(url,l1llllll1_l1_)
	elif mode==782: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==783: l1lll_l1_ = PLAY(url)
	elif mode==784: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"࠭ࡆࡖࡎࡏࡣࡋࡏࡌࡕࡇࡕࡣࡤࡥࠧ⃹")+text)
	elif mode==785: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠧࡅࡇࡉࡍࡓࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࡠࡡࡢࠫ⃺")+text)
	elif mode==786: l1lll_l1_ = l1111lll1_l1_(url,l1llllll1_l1_)
	elif mode==789: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⃻"),l1lllll_l1_+l1l111_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ⃼"),l1l111_l1_ (u"ࠪࠫ⃽"),789,l1l111_l1_ (u"ࠫࠬ⃾"),l1l111_l1_ (u"ࠬ࠭⃿"),l1l111_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ℀"))
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ℁"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨℂ"),l1l111_l1_ (u"ࠩࠪ℃"),9999)
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ℄"),l111l1_l1_,l1l111_l1_ (u"ࠫࠬ℅"),l1l111_l1_ (u"ࠬ࠭℆"),l1l111_l1_ (u"࠭ࠧℇ"),l1l111_l1_ (u"ࠧࠨ℈"),l1l111_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠴࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ℉"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡯࡭ࡸࡺ࠭ࡱࡣࡪࡩࡸ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩℊ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡵࡧ࡮࠿ࠩℋ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = title.strip(l1l111_l1_ (u"ࠫࠥ࠭ℌ"))
			if any(value in title for value in l11lll_l1_): continue
			if l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࠪℍ") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ℎ"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩℏ")+l1lllll_l1_+title,l1ll1ll_l1_,781)
		addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ℐ"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩℑ"),l1l111_l1_ (u"ࠪࠫℒ"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡲࡧࡩ࡯࠯ࡤࡶࡹ࡯ࡣ࡭ࡧࠫ࠲࠯ࡅࠩࡴࡱࡦ࡭ࡦࡲ࠭ࡣࡱࡻࠫℓ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬࡳࡡࡪࡰ࠰ࡸ࡮ࡺ࡬ࡦ࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ℔"),block,re.DOTALL)
		for title,l1ll1ll_l1_ in items:
			title = title.strip(l1l111_l1_ (u"࠭ࠠࠨℕ"))
			if any(value in title for value in l11lll_l1_): continue
			if l1l111_l1_ (u"ࠧࡩࡶࡷࡴࠬ№") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ℗"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ℘")+l1lllll_l1_+title,l1ll1ll_l1_,781,l1l111_l1_ (u"ࠪࠫℙ"),l1l111_l1_ (u"ࠫࡲࡧࡩ࡯࡯ࡨࡲࡺ࠭ℚ"))
		addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪℛ"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ℜ"),l1l111_l1_ (u"ࠧࠨℝ"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࡯ࡤ࡭ࡳ࠳࡭ࡦࡰࡸࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ℞"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ℟"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = title.strip(l1l111_l1_ (u"ࠪࠤࠬ℠"))
			if any(value in title for value in l11lll_l1_): continue
			if l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ℡") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ™"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ℣")+l1lllll_l1_+title,l1ll1ll_l1_,781)
	return
def l1111lll1_l1_(url,type=l1l111_l1_ (u"ࠧࠨℤ")):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ℥"),url,l1l111_l1_ (u"ࠩࠪΩ"),l1l111_l1_ (u"ࠪࠫ℧"),l1l111_l1_ (u"ࠫࠬℨ"),l1l111_l1_ (u"ࠬ࠭℩"),l1l111_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠲࠮ࡕࡈࡅࡘࡕࡎࡔࡡࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠶ࡹࡴࠨK"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࡮ࡣ࡬ࡲ࠲ࡧࡲࡵ࡫ࡦࡰࡪࠨ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠬ࠳࠰࠿ࠪࡣࡵࡸ࡮ࡩ࡬ࡦࠩÅ"),html,re.DOTALL)
	if l11llll_l1_:
		l111lll1l1_l1_,l1l1l1l1_l1_,items = l1l111_l1_ (u"ࠨࠩℬ"),l1l111_l1_ (u"ࠩࠪℭ"),[]
		for name,block in l11llll_l1_:
			if l1l111_l1_ (u"ࠪั้่วหࠩ℮") in name: l1l1l1l1_l1_ = block
			if l1l111_l1_ (u"๊ࠫ๎วิ็ࠪℯ") in name: l111lll1l1_l1_ = block
		if l111lll1l1_l1_ and not type:
			items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡤࡢࡶࡤ࠱ࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡺࡩࡵ࡮ࡨࠦࡃ࠮࠮ࠫࡁࠬࡀࠬℰ"),l111lll1l1_l1_,re.DOTALL)
			if len(items)>1:
				for l1ll1ll_l1_,l1ll1l_l1_,title in items:
					addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ℱ"),l1lllll_l1_+title,l1ll1ll_l1_,786,l1ll1l_l1_,l1l111_l1_ (u"ࠧࡴࡧࡤࡷࡴࡴࠧℲ"))
		if l1l1l1l1_l1_ and len(items)<2:
			items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡧࡥࡹࡧ࠭ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧℳ"),l1l1l1l1_l1_,re.DOTALL)
			if items:
				for l1ll1ll_l1_,l1ll1l_l1_,title in items:
					addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨℴ"),l1lllll_l1_+title,l1ll1ll_l1_,783,l1ll1l_l1_)
			else:
				items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩℵ"),l1l1l1l1_l1_,re.DOTALL)
				for l1ll1ll_l1_,title in items:
					addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪℶ"),l1lllll_l1_+title,l1ll1ll_l1_,783)
	return
def l1lll11_l1_(url,type=l1l111_l1_ (u"ࠬ࠭ℷ")):
	if l1l111_l1_ (u"࠭ࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠪℸ") in type or l1l111_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࠧℹ") in type:
		l1lllll1_l1_,data = url.split(l1l111_l1_ (u"ࠨࡁࡶࡩࡵࡧࡲࡢࡶࡲࡶࠫ࠭℺"))
		headers = {l1l111_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ℻"):l1l111_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥࠩℼ")}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡕࡕࡓࡕࠩℽ"),l1lllll1_l1_,data,headers,l1l111_l1_ (u"ࠬ࠭ℾ"),l1l111_l1_ (u"࠭ࠧℿ"),l1l111_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠳࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭⅀"))
		html = response.content
		html = l1l111_l1_ (u"ࠨࡤ࡯ࡳࡨࡱࡳࠨ⅁")+html+l1l111_l1_ (u"ࠩࡤࡶࡹ࡯ࡣ࡭ࡧࠪ⅂")
	else:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ⅃"),url,l1l111_l1_ (u"ࠫࠬ⅄"),l1l111_l1_ (u"ࠬ࠭ⅅ"),l1l111_l1_ (u"࠭ࠧⅆ"),l1l111_l1_ (u"ࠧࠨⅇ"),l1l111_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠴࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠶ࡳࡪࠧⅈ"))
		html = response.content
	items,l111lll1ll_l1_,filters = [],False,False
	if not type:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡰࡥ࡮ࡴ࠭ࡤࡱࡱࡸࡪࡴࡴࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬⅉ"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ⅊"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				title = title.strip(l1l111_l1_ (u"ࠫࠥ࠭⅋"))
				addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⅌"),l1lllll_l1_+title,l1ll1ll_l1_,781,l1l111_l1_ (u"࠭ࠧ⅍"),l1l111_l1_ (u"ࠧࡴࡷࡥࡱࡪࡴࡵࠨⅎ"))
				l111lll1ll_l1_ = True
	if not type:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡣ࡯ࡰ࠲ࡺࡡࡹࡧࡶࠬ࠳࠰࠿ࠪࠤ࡯ࡳࡦࡪࠢࠨ⅏"),html,re.DOTALL)
		if l11llll_l1_ and type!=l1l111_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࠩ⅐"):
			if l111lll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ⅑"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ⅒"),l1l111_l1_ (u"ࠬ࠭⅓"),9999)
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⅔"),l1lllll_l1_+l1l111_l1_ (u"ࠧโๆอี๋ࠥอะัࠪ⅕"),url,785,l1l111_l1_ (u"ࠨࠩ⅖"),l1l111_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࠩ⅗"))
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⅘"),l1lllll_l1_+l1l111_l1_ (u"ࠫๆ๊สาࠢๆห๊๊ࠧ⅙"),url,784,l1l111_l1_ (u"ࠬ࠭⅚"),l1l111_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷ࠭⅛"))
			filters = True
	if not l111lll1ll_l1_ and not filters:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡣ࡮ࡲࡧࡰࡹࠨ࠯ࠬࡂ࠭ࡦࡸࡴࡪࡥ࡯ࡩࠬ⅜"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡦࡰࡦࡹࡳ࠾ࠤࡷ࡭ࡹࡲࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ⅝"),block,re.DOTALL)
			for l1ll1ll_l1_,l1ll1l_l1_,title in items:
				l1ll1l_l1_ = l1ll1l_l1_.strip(l1l111_l1_ (u"ࠩ࡟ࡲࠬ⅞"))
				l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_)
				if l1l111_l1_ (u"ࠪ࠳ࡸ࡫࡬ࡢࡴࡼ࠳ࠬ⅟") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⅠ"),l1lllll_l1_+title,l1ll1ll_l1_,781,l1ll1l_l1_)
				elif l1l111_l1_ (u"๋ࠬำๅี็ࠫⅡ") in l1ll1ll_l1_ and l1l111_l1_ (u"࠭อๅไฬࠫⅢ") not in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⅣ"),l1lllll_l1_+title,l1ll1ll_l1_,786,l1ll1l_l1_)
				elif l1l111_l1_ (u"ࠨ็๋ื๊࠭Ⅴ") in l1ll1ll_l1_ and l1l111_l1_ (u"ࠩะ่็ฯࠧⅥ") not in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⅦ"),l1lllll_l1_+title,l1ll1ll_l1_,786,l1ll1l_l1_)
				else: addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪⅧ"),l1lllll_l1_+title,l1ll1ll_l1_,783,l1ll1l_l1_)
		length = 12 if l1l111_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࠬⅨ") in type else 16
		data = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࠨ࡭ࡱࡤࡨ࠲ࡳ࡯ࡳࡧ࠱࠮ࡄ࠯ࠠ࠯ࠬࡂࡨࡦࡺࡡ࠮ࠪ࠱࠮ࡄ࠯࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨⅩ"),html,re.DOTALL)
		if len(items)==length and (data or l1l111_l1_ (u"ࠧࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠫⅪ") in type):
			if data:
				offset = length
				action,name,value = data[0]
				action = action.replace(l1l111_l1_ (u"ࠨ࡮ࡲࡥࡩ࠭Ⅻ"),l1l111_l1_ (u"ࠩࡪࡩࡹ࠭Ⅼ")).replace(l1l111_l1_ (u"ࠪ࠱ࠬⅭ"),l1l111_l1_ (u"ࠫࡤ࠭Ⅾ")).replace(l1l111_l1_ (u"ࠬࠨࠧⅯ"),l1l111_l1_ (u"࠭ࠧⅰ"))
			else:
				data = re.findall(l1l111_l1_ (u"ࠧࡢࡥࡷ࡭ࡴࡴ࠽ࠩ࠰࠭ࡃ࠮ࠬ࡯ࡧࡨࡶࡩࡹࡃࠨ࠯ࠬࡂ࠭ࠫ࠮࠮ࠫࡁࠬࡁ࠭࠴ࠪࡀࠫࠧࠫⅱ"),url,re.DOTALL)
				if data: action,offset,name,value = data[0]
				offset = int(offset)+length
			data = l1l111_l1_ (u"ࠨࡣࡦࡸ࡮ࡵ࡮࠾ࠩⅲ")+action+l1l111_l1_ (u"ࠩࠩࡳ࡫࡬ࡳࡦࡶࡀࠫⅳ")+str(offset)+l1l111_l1_ (u"ࠪࠪࠬⅴ")+name+l1l111_l1_ (u"ࠫࡂ࠭ⅵ")+value
			url = l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡷࡱ࠯ࡤࡨࡲ࡯࡮࠰ࡣࡧࡱ࡮ࡴ࠭ࡢ࡬ࡤࡼ࠳ࡶࡨࡱࡁࡶࡩࡵࡧࡲࡢࡶࡲࡶࠫ࠭ⅶ")+data
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⅷ"),l1lllll_l1_+l1l111_l1_ (u"ࠧศๆ่ึ๏ีࠧⅸ"),url,781,l1l111_l1_ (u"ࠨࠩⅹ"),l1l111_l1_ (u"ࠩࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳࡥࠧⅺ")+type)
	return
def PLAY(url):
	response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧⅻ"),url,l1l111_l1_ (u"ࠫࠬⅼ"),l1l111_l1_ (u"ࠬ࠭ⅽ"),l1l111_l1_ (u"࠭ࠧⅾ"),l1l111_l1_ (u"ࠧࠨⅿ"),l1l111_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠴࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬↀ"))
	html = response.content
	l1ll11l1_l1_,l1111l1ll_l1_ = [],[]
	items = re.findall(l1l111_l1_ (u"ࠩࡶࡩࡷࡼࡥࡳ࠯࡬ࡸࡪࡳ࠮ࠫࡁࡧࡥࡹࡧ࠭ࡤࡱࡧࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ↁ"),html,re.DOTALL)
	for l111ll11l1_l1_ in items:
		l111ll1l11_l1_ = base64.b64decode(l111ll11l1_l1_)
		if PY3: l111ll1l11_l1_ = l111ll1l11_l1_.decode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨↂ"))
		l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩↃ"),l111ll1l11_l1_,re.DOTALL)
		if l1ll1ll_l1_:
			l1ll1ll_l1_ = l1ll1ll_l1_[0]
			if l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࠪↄ") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"࠭ࡨࡵࡶࡳ࠾ࠬↅ")+l1ll1ll_l1_
			if l1ll1ll_l1_ not in l1111l1ll_l1_:
				l1111l1ll_l1_.append(l1ll1ll_l1_)
				server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠧ࡯ࡣࡰࡩࠬↆ"))
				l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩↇ")+server+l1l111_l1_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪↈ"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡨࡴࡽ࡮࡭ࡱࡤࡨࡸ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡥࡤࡶ࡬ࡳࡳࡄࠧ↉"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫࡁࡪࡩࡷࡀ࡞ࠤࡦ࠳ࡺࡂ࠯࡝ࡡ࠯࠮࡜ࡥࡽ࠶࠰࠹ࢃࠩ࡜ࠢࡤ࠱ࡿࡇ࡛࠭࡟࠭ࡀ࠴ࡪࡩࡷࡀ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠳࠰࠿ࡥࡱࡺࡲࡱࡵࡡࡥ࠿ࠫ࠲࠯ࡅࠩࠣࠩ↊"),block,re.DOTALL)
		for l111l1ll_l1_,l111ll1lll_l1_ in items:
			l1ll1ll_l1_ = base64.b64decode(l111ll1lll_l1_)
			if PY3: l1ll1ll_l1_ = l1ll1ll_l1_.decode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ↋"))
			if l1l111_l1_ (u"࠭ࡨࡵࡶࡳࠫ↌") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠭↍")+l1ll1ll_l1_
			if l1ll1ll_l1_ not in l1111l1ll_l1_:
				l1111l1ll_l1_.append(l1ll1ll_l1_)
				server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠨࡰࡤࡱࡪ࠭↎"))
				l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ↏")+server+l1l111_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡟ࡠࡡࡢࠫ←")+l111l1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll11l1_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ↑"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search: search = l1llll1_l1_()
	if not search: return
	l1lll1ll_l1_ = search.replace(l1l111_l1_ (u"ࠬࠦࠧ→"),l1l111_l1_ (u"࠭࠭ࠨ↓"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡨ࡬ࡲࡩ࠵࠿ࡲ࠿ࠪ↔")+l1lll1ll_l1_
	l1lll11_l1_(url,l1l111_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࠨ↕"))
	return
def l11l111l1_l1_(url):
	url = url.split(l1l111_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭↖"))[0]
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ↗"),url,l1l111_l1_ (u"ࠫࠬ↘"),l1l111_l1_ (u"ࠬ࠭↙"),l1l111_l1_ (u"࠭ࠧ↚"),l1l111_l1_ (u"ࠧࠨ↛"),l1l111_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠴࠰ࡋࡊ࡚࡟ࡇࡋࡏࡘࡊࡘࡓࡠࡄࡏࡓࡈࡑࡓ࠮࠳ࡶࡸࠬ↜"))
	html = response.content
	l1l11l1l_l1_ = []
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡰࡥ࡮ࡴ࠭ࡢࡴࡷ࡭ࡨࡲࡥࠩ࠰࠭ࡃ࠮ࡧࡲࡵ࡫ࡦࡰࡪ࠭↝"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1l11l1l_l1_ = re.findall(l1l111_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡶࡤࡼࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ↞"),block,re.DOTALL)
		l1111l111_l1_,names,l1lll1l1_l1_ = zip(*l1l11l1l_l1_)
		l1l11l1l_l1_ = zip(names,l1111l111_l1_,l1lll1l1_l1_)
	return l1l11l1l_l1_
def l111ll1ll_l1_(block):
	items = re.findall(l1l111_l1_ (u"ࠫࡻࡧ࡬ࡶࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ↟"),block,re.DOTALL)
	return items
def l11111lll_l1_(url):
	if l1l111_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࠨ↠") not in url: l1lllll1_l1_,l111ll1l1l_l1_ = url,l1l111_l1_ (u"࠭ࠧ↡")
	else: l1lllll1_l1_,l111ll1l1l_l1_ = url.split(l1l111_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࠪ↢"))
	l1llllll_l1_,l111ll1ll1_l1_ = l1ll11ll1_l1_(l111ll1l1l_l1_)
	l111ll11ll_l1_ = l1l111_l1_ (u"ࠨࠩ↣")
	for key in list(l111ll1ll1_l1_.keys()):
		l111ll11ll_l1_ += l1l111_l1_ (u"ࠩࠩࡥࡷ࡭ࡳࠦ࠷ࡅࠫ↤")+key+l1l111_l1_ (u"ࠪࠩ࠺ࡊ࠽ࠨ↥")+l111ll1ll1_l1_[key]
	l1111111_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡽࡰ࠮ࡣࡧࡱ࡮ࡴ࠯ࡢࡦࡰ࡭ࡳ࠳ࡡ࡫ࡣࡻ࠲ࡵ࡮ࡰࡀࡵࡨࡴࡦࡸࡡࡵࡱࡵࠪࡦࡩࡴࡪࡱࡱࡁ࡬࡫ࡴࡠࡨ࡬ࡰࡹ࡫ࡲࡥࡡࡥࡰࡴࡩ࡫ࡴࠩ↦")+l111ll11ll_l1_
	return l1111111_l1_
l1111l1l1_l1_ = [l1l111_l1_ (u"ࠬࡸࡥ࡭ࡧࡤࡷࡪ࠳ࡹࡦࡣࡵࠫ↧"),l1l111_l1_ (u"࠭࡬ࡢࡰࡪࡹࡦ࡭ࡥࠨ↨"),l1l111_l1_ (u"ࠧࡨࡧࡱࡶࡪ࠭↩"),l1l111_l1_ (u"ࠨࡰࡤࡸ࡮ࡵ࡮ࠨ↪"),l1l111_l1_ (u"ࠩࡦࡥࡹ࡫ࡧࡰࡴࡼࠫ↫"),l1l111_l1_ (u"ࠪࡵࡺࡧ࡬ࡪࡶࡼࠫ↬"),l1l111_l1_ (u"ࠫࡷ࡫ࡳࡰ࡮ࡸࡸ࡮ࡵ࡮ࠨ↭")]
l111l111l_l1_ = [l1l111_l1_ (u"ࠬࡸࡥ࡭ࡧࡤࡷࡪ࠳ࡹࡦࡣࡵࠫ↮"),l1l111_l1_ (u"࠭࡬ࡢࡰࡪࡹࡦ࡭ࡥࠨ↯"),l1l111_l1_ (u"ࠧࡨࡧࡱࡶࡪ࠭↰")]
def l1l1ll1l_l1_(url,filter):
	url = url.split(l1l111_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬ↱"))[0]
	type,filter = filter.split(l1l111_l1_ (u"ࠩࡢࡣࡤ࠭↲"),1)
	if filter==l1l111_l1_ (u"ࠪࠫ↳"): l11lll1l_l1_,l11lll11_l1_ = l1l111_l1_ (u"ࠫࠬ↴"),l1l111_l1_ (u"ࠬ࠭↵")
	else: l11lll1l_l1_,l11lll11_l1_ = filter.split(l1l111_l1_ (u"࠭࡟ࡠࡡࠪ↶"))
	if type==l1l111_l1_ (u"ࠧࡅࡇࡉࡍࡓࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࠨ↷"):
		if l111l111l_l1_[0]+l1l111_l1_ (u"ࠨ࠿ࠪ↸") not in l11lll1l_l1_: category = l111l111l_l1_[0]
		for i in range(len(l111l111l_l1_[0:-1])):
			if l111l111l_l1_[i]+l1l111_l1_ (u"ࠩࡀࠫ↹") in l11lll1l_l1_: category = l111l111l_l1_[i+1]
		l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠪࠪࠬ↺")+category+l1l111_l1_ (u"ࠫࡂ࠶ࠧ↻")
		l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠬࠬࠧ↼")+category+l1l111_l1_ (u"࠭࠽࠱ࠩ↽")
		l1l111l1_l1_ = l1l11ll1_l1_.strip(l1l111_l1_ (u"ࠧࠧࠩ↾"))+l1l111_l1_ (u"ࠨࡡࡢࡣࠬ↿")+l1l1ll11_l1_.strip(l1l111_l1_ (u"ࠩࠩࠫ⇀"))
		l11ll111_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭⇁"))
		l1lllll1_l1_ = url+l1l111_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨ⇂")+l11ll111_l1_
	elif type==l1l111_l1_ (u"ࠬࡌࡕࡍࡎࡢࡊࡎࡒࡔࡆࡔࠪ⇃"):
		l11l1l1l_l1_ = l11ll1l1_l1_(l11lll1l_l1_,l1l111_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨ⇄"))
		l11l1l1l_l1_ = l111l11_l1_(l11l1l1l_l1_)
		if l11lll11_l1_: l11lll11_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ⇅"))
		if not l11lll11_l1_: l1lllll1_l1_ = url
		else: l1lllll1_l1_ = url+l1l111_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬ⇆")+l11lll11_l1_
		l1llllll_l1_ = l11111lll_l1_(l1lllll1_l1_)
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⇇"),l1lllll_l1_+l1l111_l1_ (u"ࠪว฽ํวาࠢๅหห๋ษࠡษ็ๅ๏ี๊้ࠢส่ฯ๐ࠠห็ࠣหำะ๊ศำ๊หࠥ࠭⇈"),l1llllll_l1_,781,l1l111_l1_ (u"ࠫࠬ⇉"),l1l111_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࠬ⇊"))
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⇋"),l1lllll_l1_+l1l111_l1_ (u"ࠧࠡ࡝࡞ࠤࠥࠦࠧ⇌")+l11l1l1l_l1_+l1l111_l1_ (u"ࠨࠢࠣࠤࡢࡣࠧ⇍"),l1llllll_l1_,781,l1l111_l1_ (u"ࠩࠪ⇎"),l1l111_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࠪ⇏"))
		addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ⇐"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ⇑"),l1l111_l1_ (u"࠭ࠧ⇒"),9999)
	l1l11l1l_l1_ = l11l111l1_l1_(url)
	dict = {}
	for name,l1l111ll_l1_,block in l1l11l1l_l1_:
		name = name.replace(l1l111_l1_ (u"ࠧไๆࠣࠫ⇓"),l1l111_l1_ (u"ࠨࠩ⇔"))
		items = l111ll1ll_l1_(block)
		if l1l111_l1_ (u"ࠩࡀࠫ⇕") not in l1lllll1_l1_: l1lllll1_l1_ = url
		if type==l1l111_l1_ (u"ࠪࡈࡊࡌࡉࡏࡇࡇࡣࡋࡏࡌࡕࡇࡕࠫ⇖"):
			if category!=l1l111ll_l1_: continue
			elif len(items)<2:
				if l1l111ll_l1_==l111l111l_l1_[-1]:
					l1llllll_l1_ = l11111lll_l1_(l1lllll1_l1_)
					l1lll11_l1_(l1llllll_l1_,l1l111_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࠫ⇗"))
				else: l1l1ll1l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠬࡊࡅࡇࡋࡑࡉࡉࡥࡆࡊࡎࡗࡉࡗࡥ࡟ࡠࠩ⇘")+l1l111l1_l1_)
				return
			else:
				if l1l111ll_l1_==l111l111l_l1_[-1]:
					l1llllll_l1_ = l11111lll_l1_(l1lllll1_l1_)
					addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⇙"),l1lllll_l1_+l1l111_l1_ (u"ࠧศๆฯ้๏฿ࠠࠨ⇚"),l1llllll_l1_,781,l1l111_l1_ (u"ࠨࠩ⇛"),l1l111_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࠩ⇜"))
				else: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⇝"),l1lllll_l1_+l1l111_l1_ (u"ࠫฬ๊ฬๆ์฼ࠤࠬ⇞"),l1lllll1_l1_,785,l1l111_l1_ (u"ࠬ࠭⇟"),l1l111_l1_ (u"࠭ࠧ⇠"),l1l111l1_l1_)
		elif type==l1l111_l1_ (u"ࠧࡇࡗࡏࡐࡤࡌࡉࡍࡖࡈࡖࠬ⇡"):
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠨࠨࠪ⇢")+l1l111ll_l1_+l1l111_l1_ (u"ࠩࡀ࠴ࠬ⇣")
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠪࠪࠬ⇤")+l1l111ll_l1_+l1l111_l1_ (u"ࠫࡂ࠶ࠧ⇥")
			l1l111l1_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠬࡥ࡟ࡠࠩ⇦")+l1l1ll11_l1_
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⇧"),l1lllll_l1_+l1l111_l1_ (u"ࠧศๆฯ้๏฿ࠠ࠻ࠩ⇨")+name,l1lllll1_l1_,784,l1l111_l1_ (u"ࠨࠩ⇩"),l1l111_l1_ (u"ࠩࠪ⇪"),l1l111l1_l1_)
		dict[l1l111ll_l1_] = {}
		for value,option in items:
			if not value: continue
			if option in l11lll_l1_: continue
			dict[l1l111ll_l1_][value] = option
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠪࠪࠬ⇫")+l1l111ll_l1_+l1l111_l1_ (u"ࠫࡂ࠭⇬")+option
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠬࠬࠧ⇭")+l1l111ll_l1_+l1l111_l1_ (u"࠭࠽ࠨ⇮")+value
			l1l1l11l_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠧࡠࡡࡢࠫ⇯")+l1l1ll11_l1_
			title = option+l1l111_l1_ (u"ࠨࠢ࠽ࠫ⇰")#+dict[l1l111ll_l1_][l1l111_l1_ (u"ࠩ࠳ࠫ⇱")]
			title = option+l1l111_l1_ (u"ࠪࠤ࠿࠭⇲")+name
			if type==l1l111_l1_ (u"ࠫࡋ࡛ࡌࡍࡡࡉࡍࡑ࡚ࡅࡓࠩ⇳"): addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⇴"),l1lllll_l1_+title,url,784,l1l111_l1_ (u"࠭ࠧ⇵"),l1l111_l1_ (u"ࠧࠨ⇶"),l1l1l11l_l1_)
			elif type==l1l111_l1_ (u"ࠨࡆࡈࡊࡎࡔࡅࡅࡡࡉࡍࡑ࡚ࡅࡓࠩ⇷") and l111l111l_l1_[-2]+l1l111_l1_ (u"ࠩࡀࠫ⇸") in l11lll1l_l1_:
				l11ll111_l1_ = l11ll1l1_l1_(l1l1ll11_l1_,l1l111_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭⇹"))
				l1lllll1_l1_ = url+l1l111_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨ⇺")+l11ll111_l1_
				l1llllll_l1_ = l11111lll_l1_(l1lllll1_l1_)
				addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⇻"),l1lllll_l1_+title,l1llllll_l1_,781,l1l111_l1_ (u"࠭ࠧ⇼"),l1l111_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࠧ⇽"))
			elif type==l1l111_l1_ (u"ࠨࡆࡈࡊࡎࡔࡅࡅࡡࡉࡍࡑ࡚ࡅࡓࠩ⇾"): addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⇿"),l1lllll_l1_+title,url,785,l1l111_l1_ (u"ࠪࠫ∀"),l1l111_l1_ (u"ࠫࠬ∁"),l1l1l11l_l1_)
	return
def l11ll1l1_l1_(filters,mode):
	filters = filters.replace(l1l111_l1_ (u"ࠬࡃࠦࠨ∂"),l1l111_l1_ (u"࠭࠽࠱ࠨࠪ∃"))
	filters = filters.strip(l1l111_l1_ (u"ࠧࠧࠩ∄"))
	l11lllll_l1_ = {}
	if l1l111_l1_ (u"ࠨ࠿ࠪ∅") in filters:
		items = filters.split(l1l111_l1_ (u"ࠩࠩࠫ∆"))
		for item in items:
			var,value = item.split(l1l111_l1_ (u"ࠪࡁࠬ∇"))
			l11lllll_l1_[var] = value
	l1l1l111_l1_ = l1l111_l1_ (u"ࠫࠬ∈")
	for key in l1111l1l1_l1_:
		if key in list(l11lllll_l1_.keys()): value = l11lllll_l1_[key]
		else: value = l1l111_l1_ (u"ࠬ࠶ࠧ∉")
		if l1l111_l1_ (u"࠭ࠥࠨ∊") not in value: value = QUOTE(value)
		if mode==l1l111_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡹࡥࡱࡻࡥࡴࠩ∋") and value!=l1l111_l1_ (u"ࠨ࠲ࠪ∌"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠩࠣ࠯ࠥ࠭∍")+value
		elif mode==l1l111_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭∎") and value!=l1l111_l1_ (u"ࠫ࠵࠭∏"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠬࠬࠧ∐")+key+l1l111_l1_ (u"࠭࠽ࠨ∑")+value
		elif mode==l1l111_l1_ (u"ࠧࡢ࡮࡯ࠫ−"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠨࠨࠪ∓")+key+l1l111_l1_ (u"ࠩࡀࠫ∔")+value
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠪࠤ࠰ࠦࠧ∕"))
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠫࠫ࠭∖"))
	l1l1l111_l1_ = l1l1l111_l1_.replace(l1l111_l1_ (u"ࠬࡃ࠰ࠨ∗"),l1l111_l1_ (u"࠭࠽ࠨ∘"))
	return l1l1l111_l1_
# -*- coding: utf-8 -*-
from yoY3NdGViS import *
xjPuFK3EsIZSiobQ5X = 'ARABSEED'
headers = {'User-Agent':OB6QYAMUnPiWXgpkTrItV48FqZSjdR()}
n0qFKQWhiBYXoTrvejVHUA4 = '_ARS_'
Str0BupDTFA = u6rbxnyjTl7I[xjPuFK3EsIZSiobQ5X][0]
P3UK1Rr4IdYe5 = ['الرئيسية','المضاف حديثاً','مصارعه','اعلن معنا – For ads','موبايلات','برامج كمبيوتر','العاب كمبيوتر','اسلاميات','اخرى','اقسام اخري','اشتراكات']
def ehB18u9sQFRi(mode,url,text):
	if   mode==250: N6NCYivtV4I5rEXq = DP6FSBgNdX1rsvVR()
	elif mode==251: N6NCYivtV4I5rEXq = wg5aF3e8rcDh7SGpW6M1OPnkU(url,text)
	elif mode==252: N6NCYivtV4I5rEXq = oanus6TxUFNAhSZKpJdYlEC4mV(url)
	elif mode==253: N6NCYivtV4I5rEXq = GrsxUhb0PEXj2FQRAkD4q(url)
	elif mode==254: N6NCYivtV4I5rEXq = hadMgR0nOKHoGqpA(url,'CATEGORIES___'+text)
	elif mode==255: N6NCYivtV4I5rEXq = hadMgR0nOKHoGqpA(url,'FILTERS___'+text)
	elif mode==256: N6NCYivtV4I5rEXq = qt2zjyIbsS(url,text)
	elif mode==259: N6NCYivtV4I5rEXq = lPwaAjFTMG4n7iSLkXcEuK0Zm(text)
	else: N6NCYivtV4I5rEXq = False
	return N6NCYivtV4I5rEXq
def DP6FSBgNdX1rsvVR():
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(DpQifS0oKBI1hYcO,'GET',Str0BupDTFA+'/main',hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'ARABSEED-MENU-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'بحث في الموقع',hWGMqtBy4wuLaVcj,259,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'_REMEMBERRESULTS_')
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'فلتر محدد',Str0BupDTFA+'/category/اخرى',254)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'فلتر كامل',Str0BupDTFA+'/category/اخرى',255)
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'المميزة',Str0BupDTFA+'/main',251,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'featured_main')
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+'جديد الأفلام',Str0BupDTFA+'/main',251,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'new_movies')
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+'جديد الحلقات',Str0BupDTFA+'/main',251,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'new_episodes')
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+'المضاف حديثاً',Str0BupDTFA+'/latest',251,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'lastest')
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	v2V8Nmrwf4 = trdVA0JvFaD.findall('class="MenuHeader"(.*?)</div>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	TfCqlZthRYgzkbE0GO = v2V8Nmrwf4[0]
	yRE17DrswMOxv0Gc9H = trdVA0JvFaD.findall('href="(.*?)".*?>(.*?)<',TfCqlZthRYgzkbE0GO,trdVA0JvFaD.DOTALL)
	for llxFwq0CUNgQtivJzkHeGV,title in yRE17DrswMOxv0Gc9H:
		title = LNtIDdBA52P(title)
		if title not in P3UK1Rr4IdYe5 and title!=hWGMqtBy4wuLaVcj:
			if 'http' not in llxFwq0CUNgQtivJzkHeGV: llxFwq0CUNgQtivJzkHeGV = Str0BupDTFA+llxFwq0CUNgQtivJzkHeGV
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,256)
	return mMQ3FkNVa4IlxqY
def qt2zjyIbsS(url,type):
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',url,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'ARABSEED-SUBMENU-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	if 'class="SliderInSection' in mMQ3FkNVa4IlxqY: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'الأكثر مشاهدة',url,251,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'most')
	if 'class="MainSlides' in mMQ3FkNVa4IlxqY: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'المميزة',url,251,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'featured')
	if 'class="LinksList' in mMQ3FkNVa4IlxqY:
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('class="LinksList(.*?)</ul>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
			cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
			if len(DJvksH7ZAFUqW9OyQnbGjPCtwR1o)>1 and type=='new_episodes': cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[1]
			items = trdVA0JvFaD.findall('href="(.*?)"(.*?)</a>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
			for llxFwq0CUNgQtivJzkHeGV,title in items:
				m4eVoJdSU51qs3y8Gg06fZNau7A = trdVA0JvFaD.findall('</i>(.*?)<span>(.*?)<',title,trdVA0JvFaD.DOTALL)
				try: pp9oFfEkKX74znPZ = m4eVoJdSU51qs3y8Gg06fZNau7A[0][0].replace(NXMOzZjYsmS9pf,hWGMqtBy4wuLaVcj).strip(Mpsm2VF1OBnCRvK3qf6)
				except: pp9oFfEkKX74znPZ = hWGMqtBy4wuLaVcj
				try: RxS0A5tZ3QYHOX8C7ygproI = m4eVoJdSU51qs3y8Gg06fZNau7A[0][1].replace(NXMOzZjYsmS9pf,hWGMqtBy4wuLaVcj).strip(Mpsm2VF1OBnCRvK3qf6)
				except: RxS0A5tZ3QYHOX8C7ygproI = hWGMqtBy4wuLaVcj
				m4eVoJdSU51qs3y8Gg06fZNau7A = pp9oFfEkKX74znPZ+Mpsm2VF1OBnCRvK3qf6+RxS0A5tZ3QYHOX8C7ygproI
				if '<strong>' in title:
					ify8OKnl5AP6oHW2mzpG = trdVA0JvFaD.findall('</i>(.*?)<',title,trdVA0JvFaD.DOTALL)
					if ify8OKnl5AP6oHW2mzpG: m4eVoJdSU51qs3y8Gg06fZNau7A = ify8OKnl5AP6oHW2mzpG[0]
				if not m4eVoJdSU51qs3y8Gg06fZNau7A:
					ify8OKnl5AP6oHW2mzpG = trdVA0JvFaD.findall('alt="(.*?)"',title,trdVA0JvFaD.DOTALL)
					if ify8OKnl5AP6oHW2mzpG: m4eVoJdSU51qs3y8Gg06fZNau7A = ify8OKnl5AP6oHW2mzpG[0]
				if m4eVoJdSU51qs3y8Gg06fZNau7A:
					if 'key=' in llxFwq0CUNgQtivJzkHeGV: type = llxFwq0CUNgQtivJzkHeGV.split('key=')[1]
					else: type = 'newest'
					m4eVoJdSU51qs3y8Gg06fZNau7A = m4eVoJdSU51qs3y8Gg06fZNau7A.strip(Mpsm2VF1OBnCRvK3qf6)
					RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+m4eVoJdSU51qs3y8Gg06fZNau7A,llxFwq0CUNgQtivJzkHeGV,251,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,type)
	return
def wg5aF3e8rcDh7SGpW6M1OPnkU(url,type):
	eegCUujkiAoBKIqn4fdVRxJSM,data,items = 'GET',hWGMqtBy4wuLaVcj,[]
	if type=='filters':
		if '?' in url:
			NNpHEqnPvMRSwdfo1ylIC4Xc,OucJVrWRKSqDChiG7yn3oz0dafZF = 'POST',{}
			NPM3HKQ57xe,Tmf2x4KQBCYo6tONsERizpubWG0V = url.split('?')
			yefFjNXHl7 = Tmf2x4KQBCYo6tONsERizpubWG0V.split('&')
			for xxcMsZ2DfavVz in yefFjNXHl7:
				key,BoSjXKxz41DcneO9UimClE = xxcMsZ2DfavVz.split('=')
				OucJVrWRKSqDChiG7yn3oz0dafZF[key] = BoSjXKxz41DcneO9UimClE
			if yefFjNXHl7: eegCUujkiAoBKIqn4fdVRxJSM,url,data = NNpHEqnPvMRSwdfo1ylIC4Xc,NPM3HKQ57xe,OucJVrWRKSqDChiG7yn3oz0dafZF
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,eegCUujkiAoBKIqn4fdVRxJSM,url,data,headers,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'ARABSEED-TITLES-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	if type=='filters': DJvksH7ZAFUqW9OyQnbGjPCtwR1o = [mMQ3FkNVa4IlxqY]
	elif 'featured' in type: DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('class="MainSlides(.*?)class="LinksList',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	elif type=='new_movies': DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('جديد الافلام.*?class="SliderInSection"(.*?)</ul>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	elif type=='new_episodes': DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('جديد الحلقات.*?class="SliderInSection"(.*?)</ul>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	elif type=='most': DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('class="SliderInSection(.*?)class="LinksList',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	else: DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('class="Blocks-UL"(.*?)class="AboElSeed"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if 'featured' in type:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		E2t6X7TH0ykep58Kq1vF3 = trdVA0JvFaD.findall('href="(.*?)" title="(.*?)".*?data-lazy.*? (src|data-image)="(.*?)"',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		if E2t6X7TH0ykep58Kq1vF3:
			Dvi8asSrQYX5wE3KMIxT91me,haq1bHZINPE58uoBFnKfTSO2ik4,ozSQOIcFCpxb2l7ZnkutJ0R851Kyj,OfpxWZ5PdcHAIXE76zQh = zip(*E2t6X7TH0ykep58Kq1vF3)
			items = zip(Dvi8asSrQYX5wE3KMIxT91me,OfpxWZ5PdcHAIXE76zQh,haq1bHZINPE58uoBFnKfTSO2ik4)
	else:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('LoadingArea.*? href="(.*?)".*? data-\w{3,5}="(.*?)".*? alt="(.*?)"',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	REbVyXis1w4Ae = []
	for llxFwq0CUNgQtivJzkHeGV,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,title in items:
		if 'WWE' in title: continue
		title = LNtIDdBA52P(title)
		if 'الحلقة' in title:
			IIsmGy4pd7 = trdVA0JvFaD.findall('(.*?) الحلقة \d+',title,trdVA0JvFaD.DOTALL)
			if IIsmGy4pd7:
				title = '_MOD_' + IIsmGy4pd7[0]
				if title not in REbVyXis1w4Ae:
					REbVyXis1w4Ae.append(title)
					RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,253,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
			else: RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,252,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
		elif '/selary/' in llxFwq0CUNgQtivJzkHeGV or 'مسلسل' in title:
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,253,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
		else:
			RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,252,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
	if type in ['newest','best','most']:
		items = trdVA0JvFaD.findall('page-numbers" href="(.*?)">(.*?)<',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,title in items:
			llxFwq0CUNgQtivJzkHeGV = Str0BupDTFA+llxFwq0CUNgQtivJzkHeGV
			llxFwq0CUNgQtivJzkHeGV = LNtIDdBA52P(llxFwq0CUNgQtivJzkHeGV)
			title = LNtIDdBA52P(title)
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'صفحة '+title,llxFwq0CUNgQtivJzkHeGV,251,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,type)
	return
def GrsxUhb0PEXj2FQRAkD4q(url):
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',url,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'ARABSEED-EPISODES-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	mMQ3FkNVa4IlxqY = mMQ3FkNVa4IlxqY[10000:]
	items = trdVA0JvFaD.findall('data-src="(.*?)".*?alt="(.*?)"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if not items: return
	Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,name = items[0]
	if 'الحلقة' in name: name = name.split('الحلقة')[0].strip(Mpsm2VF1OBnCRvK3qf6)
	elif 'حلقة' in name: name = name.split('حلقة')[0].strip(Mpsm2VF1OBnCRvK3qf6)
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('class="ContainerEpisodesList"(.*?)</div>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('href="(.*?)".*?<em>(.*?)</em>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,IIsmGy4pd7 in items:
			title = name+' - الحلقة رقم '+IIsmGy4pd7
			RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,252,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
	else: RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+'ملف التشغيل',url,252,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
	return
def k5kEbWJKfIzsFu(title,llxFwq0CUNgQtivJzkHeGV):
	m4eVoJdSU51qs3y8Gg06fZNau7A = trdVA0JvFaD.findall('[a-zA-Z-]+',title,trdVA0JvFaD.DOTALL)
	if m4eVoJdSU51qs3y8Gg06fZNau7A: title = m4eVoJdSU51qs3y8Gg06fZNau7A[0]
	else: title = title+Mpsm2VF1OBnCRvK3qf6+RRNODILCtGzvgpx(llxFwq0CUNgQtivJzkHeGV,'name')
	title = title.replace('عرب سيد',hWGMqtBy4wuLaVcj).replace('مباشر',hWGMqtBy4wuLaVcj).replace('مشاهدة',hWGMqtBy4wuLaVcj)
	title = title.replace('ٍ',hWGMqtBy4wuLaVcj)
	title = title.replace(FqcVAkh7WjIXHdDKf8nvuyRo,Mpsm2VF1OBnCRvK3qf6).replace(FqcVAkh7WjIXHdDKf8nvuyRo,Mpsm2VF1OBnCRvK3qf6)
	return title
def oanus6TxUFNAhSZKpJdYlEC4mV(url):
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(DpQifS0oKBI1hYcO,'GET',url,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'ARABSEED-PLAY-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	NPM3HKQ57xe = sDQvwGASB0Vf67mik.url
	SODQ7qlNYoZcFK8e50rBsJaAHxiXjE = RRNODILCtGzvgpx(NPM3HKQ57xe,'url')
	headers['Referer'] = SODQ7qlNYoZcFK8e50rBsJaAHxiXjE+'/'
	gSbTs57y6nA,VxrgMAqPs9Yek,Dvi8asSrQYX5wE3KMIxT91me = hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,[]
	vyLdcGE70iQ = trdVA0JvFaD.findall('class="WatchButtons".*?href="(.*?)" class="(watch.*?)".*?href="(.*?)" class="(download.*?)"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if vyLdcGE70iQ: gSbTs57y6nA,soOEufUrRzPXyT9mLZq,VxrgMAqPs9Yek,ffSgj3D680 = vyLdcGE70iQ[0]
	else:
		vyLdcGE70iQ = trdVA0JvFaD.findall('class="WatchButtons".*?href="(.*?)" class="(.*?)"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if vyLdcGE70iQ:
			llxFwq0CUNgQtivJzkHeGV,soOEufUrRzPXyT9mLZq = vyLdcGE70iQ[0]
			if 'watch' in soOEufUrRzPXyT9mLZq: gSbTs57y6nA = llxFwq0CUNgQtivJzkHeGV
			else: VxrgMAqPs9Yek = llxFwq0CUNgQtivJzkHeGV
	if gSbTs57y6nA:
		sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(DpQifS0oKBI1hYcO,'GET',gSbTs57y6nA,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'ARABSEED-PLAY-2nd')
		mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('class="WatcherArea(.*?</ul>)',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
			rrUOyRQ4DfWxLNAXlg2oemEPIsv1 = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
			rrUOyRQ4DfWxLNAXlg2oemEPIsv1 = rrUOyRQ4DfWxLNAXlg2oemEPIsv1.replace('</ul>','<h3>')
			rrUOyRQ4DfWxLNAXlg2oemEPIsv1 = rrUOyRQ4DfWxLNAXlg2oemEPIsv1.replace('<h3>','<h3><h3>')
			rqIW37cd0iT1msDzRevOM = trdVA0JvFaD.findall('<h3>.*?(\d+)(.*?)<h3>',rrUOyRQ4DfWxLNAXlg2oemEPIsv1,trdVA0JvFaD.DOTALL)
			if not rqIW37cd0iT1msDzRevOM: rqIW37cd0iT1msDzRevOM = [(hWGMqtBy4wuLaVcj,rrUOyRQ4DfWxLNAXlg2oemEPIsv1)]
			for QS8ZdxkHD5bjU9qsn4zMYaPrg3h7,cok5ZGXdQP7YhwtqyuaCnVevm6UB in rqIW37cd0iT1msDzRevOM:
				if QS8ZdxkHD5bjU9qsn4zMYaPrg3h7: QS8ZdxkHD5bjU9qsn4zMYaPrg3h7 = '____'+QS8ZdxkHD5bjU9qsn4zMYaPrg3h7
				items = trdVA0JvFaD.findall('data-link="(.*?)".*?<span>(.*?)</span>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
				for llxFwq0CUNgQtivJzkHeGV,name in items:
					if 'http' not in llxFwq0CUNgQtivJzkHeGV: llxFwq0CUNgQtivJzkHeGV = 'http:'+llxFwq0CUNgQtivJzkHeGV
					llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV+'?named='+name+'__watch'+QS8ZdxkHD5bjU9qsn4zMYaPrg3h7
					Dvi8asSrQYX5wE3KMIxT91me.append(llxFwq0CUNgQtivJzkHeGV)
		m4IznKilUOByHweG68VJ = trdVA0JvFaD.findall('class="containerIframe".*? src="(.*?)".*? height="(.*?)"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if not m4IznKilUOByHweG68VJ: m4IznKilUOByHweG68VJ = trdVA0JvFaD.findall('class="containerIframe".*? SRC="(.*?)".*? HEIGHT="(.*?)"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if m4IznKilUOByHweG68VJ:
			llxFwq0CUNgQtivJzkHeGV,QS8ZdxkHD5bjU9qsn4zMYaPrg3h7 = m4IznKilUOByHweG68VJ[0]
			name = RRNODILCtGzvgpx(llxFwq0CUNgQtivJzkHeGV,'name')
			if '%' in QS8ZdxkHD5bjU9qsn4zMYaPrg3h7: llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV+'?named='+name+'__embed__'
			else: llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV+'?named='+name+'__embed____'+QS8ZdxkHD5bjU9qsn4zMYaPrg3h7
			Dvi8asSrQYX5wE3KMIxT91me.append(llxFwq0CUNgQtivJzkHeGV)
	if VxrgMAqPs9Yek:
		sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(DpQifS0oKBI1hYcO,'GET',VxrgMAqPs9Yek,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'ARABSEED-PLAY-3rd')
		mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('class="DownloadArea(.*?)<script src=',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
			rrUOyRQ4DfWxLNAXlg2oemEPIsv1 = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
			rqIW37cd0iT1msDzRevOM = trdVA0JvFaD.findall('class="DownloadServers(.*?)</ul>',rrUOyRQ4DfWxLNAXlg2oemEPIsv1,trdVA0JvFaD.DOTALL)
			for cok5ZGXdQP7YhwtqyuaCnVevm6UB in rqIW37cd0iT1msDzRevOM:
				items = trdVA0JvFaD.findall('href="(.*?)".*?<span>(.*?)</span>.*?<p>(.*?)</p>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
				for llxFwq0CUNgQtivJzkHeGV,title,QS8ZdxkHD5bjU9qsn4zMYaPrg3h7 in items:
					if not llxFwq0CUNgQtivJzkHeGV: continue
					if 'reviewstation' in llxFwq0CUNgQtivJzkHeGV: continue
					llxFwq0CUNgQtivJzkHeGV = jkiCS0UWs2dNAJcGKn6mbHD(llxFwq0CUNgQtivJzkHeGV)
					llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV+'?named='+title+'__download____'+QS8ZdxkHD5bjU9qsn4zMYaPrg3h7
					Dvi8asSrQYX5wE3KMIxT91me.append(llxFwq0CUNgQtivJzkHeGV)
	Gz5Qp19NSKuRX4wjy6BECTO7 = str(Dvi8asSrQYX5wE3KMIxT91me)
	ly9Xa65Q23J = ['.zip?','.rar?','.txt?','.pdf?','.tar?','.iso?','.zip.','.rar.','.txt.','.pdf.','.tar.','.iso.']
	if any(BoSjXKxz41DcneO9UimClE in Gz5Qp19NSKuRX4wjy6BECTO7 for BoSjXKxz41DcneO9UimClE in ly9Xa65Q23J):
		BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'رسالة من المبرمج','جرب رابط مختلف لأن هذا الرابط ليس من نوع الروابط التي فيها ملفات فيديو .. لأن هذا الموقع فيه خدمات أخرى غير ملفات الفيديو')
		return
	import oosSOfvdEQ
	oosSOfvdEQ.zfdYjsGLg8M6i15qZWh(Dvi8asSrQYX5wE3KMIxT91me,xjPuFK3EsIZSiobQ5X,'video',url)
	return
def lPwaAjFTMG4n7iSLkXcEuK0Zm(search):
	search,vvKf4sXgZIMyEJPuC,showDialogs = IVTEJQOiMR2dYta9C(search)
	if not search: search = TrzfUidpv1LyAYqwexHJDuS()
	if not search: return
	search = search.replace(Mpsm2VF1OBnCRvK3qf6,'+')
	url = Str0BupDTFA+'/find/?find='+search
	wg5aF3e8rcDh7SGpW6M1OPnkU(url,'search')
	return
def hadMgR0nOKHoGqpA(url,filter):
	if '??' in url: url = url.split('//getposts??')[0]
	type,filter = filter.split('___',1)
	if filter==hWGMqtBy4wuLaVcj: RJGtCsyDgi0X,kYI6n5bUD83Z = hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj
	else: RJGtCsyDgi0X,kYI6n5bUD83Z = filter.split('___')
	if type=='CATEGORIES':
		if DJrjnM9UKHA2Gp0zOtmR[0]+'==' not in RJGtCsyDgi0X: OJx4sYA9nNbtPT5ezmDHdVBk2C7 = DJrjnM9UKHA2Gp0zOtmR[0]
		for PPuqrvDLEViYOMf1dmkK7 in range(len(DJrjnM9UKHA2Gp0zOtmR[0:-1])):
			if DJrjnM9UKHA2Gp0zOtmR[PPuqrvDLEViYOMf1dmkK7]+'==' in RJGtCsyDgi0X: OJx4sYA9nNbtPT5ezmDHdVBk2C7 = DJrjnM9UKHA2Gp0zOtmR[PPuqrvDLEViYOMf1dmkK7+1]
		nnqvmxlXub3iVDM = RJGtCsyDgi0X+'&&'+OJx4sYA9nNbtPT5ezmDHdVBk2C7+'==0'
		tuYnONZ6GaCecv4TErUHMdBX2DIb8K = kYI6n5bUD83Z+'&&'+OJx4sYA9nNbtPT5ezmDHdVBk2C7+'==0'
		BvO3oKUrHNCwVm791b80sZg = nnqvmxlXub3iVDM.strip('&&')+'___'+tuYnONZ6GaCecv4TErUHMdBX2DIb8K.strip('&&')
		PPlq1nxLf6CamuBI0psW = kKWuMB69mcOHPn3XilFdvp(kYI6n5bUD83Z,'modified_filters')
		NPM3HKQ57xe = url+'//getposts??'+PPlq1nxLf6CamuBI0psW
	elif type=='FILTERS':
		I2OnWkrPaVbwBSHiYR3LZ = kKWuMB69mcOHPn3XilFdvp(RJGtCsyDgi0X,'modified_values')
		I2OnWkrPaVbwBSHiYR3LZ = jkiCS0UWs2dNAJcGKn6mbHD(I2OnWkrPaVbwBSHiYR3LZ)
		if kYI6n5bUD83Z!=hWGMqtBy4wuLaVcj: kYI6n5bUD83Z = kKWuMB69mcOHPn3XilFdvp(kYI6n5bUD83Z,'modified_filters')
		if kYI6n5bUD83Z==hWGMqtBy4wuLaVcj: NPM3HKQ57xe = url
		else: NPM3HKQ57xe = url+'//getposts??'+kYI6n5bUD83Z
		FjQOc5WuzKg0Vikb6tDeNHZP1mS = fgoWEt5zm2NOJM1ZSHGnLpjkv4IC(NPM3HKQ57xe)
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'أظهار قائمة الفيديو التي تم اختيارها ',FjQOc5WuzKg0Vikb6tDeNHZP1mS,251,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'filters')
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+' [[   '+I2OnWkrPaVbwBSHiYR3LZ+'   ]]',FjQOc5WuzKg0Vikb6tDeNHZP1mS,251,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'filters')
		RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(DpQifS0oKBI1hYcO,'POST',url,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'ARABSEED-FILTERS_MENU-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('class="TaxPageFilter"(.*?)class="TermBTNs"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
	D1lTNgrixb863ct = trdVA0JvFaD.findall('class="TaxPageFilterItem".*?<em>(.*?)</em>.*?data-tax="(.*?)"(.*?)</ul>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	gwiqZd50ApJv = trdVA0JvFaD.findall('class="RatingFilter".*?<h4>(.*?)</h4>.*?(<ul>)(.*?)</ul>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	f5rVHP4bmCd7cqvuYEQJlnLTk6yGRS = D1lTNgrixb863ct+gwiqZd50ApJv
	dict = {}
	for name,bksErtC1hwcVqlfyM82AnD,cok5ZGXdQP7YhwtqyuaCnVevm6UB in f5rVHP4bmCd7cqvuYEQJlnLTk6yGRS:
		items = trdVA0JvFaD.findall('data-name="(.*?)".*?data-tax="(.*?)".*?data-term="(.*?)"',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		if name=='اخرى': name = 'الاقسام'
		if not items:
			yRE17DrswMOxv0Gc9H = trdVA0JvFaD.findall('data-rate="(.*?)".*?<em>(.*?)</em>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
			items = []
			for PBo1KkyMCgH8eNDaLtZVcr3EnIi2,BoSjXKxz41DcneO9UimClE in yRE17DrswMOxv0Gc9H: items.append([PBo1KkyMCgH8eNDaLtZVcr3EnIi2,hWGMqtBy4wuLaVcj,BoSjXKxz41DcneO9UimClE])
			bksErtC1hwcVqlfyM82AnD = 'rate'
			name = 'التقييم'
		else: bksErtC1hwcVqlfyM82AnD = items[0][1]
		if '==' not in NPM3HKQ57xe: NPM3HKQ57xe = url
		if type=='CATEGORIES':
			if OJx4sYA9nNbtPT5ezmDHdVBk2C7!=bksErtC1hwcVqlfyM82AnD: continue
			elif len(items)<=1:
				if bksErtC1hwcVqlfyM82AnD==DJrjnM9UKHA2Gp0zOtmR[-1]: wg5aF3e8rcDh7SGpW6M1OPnkU(NPM3HKQ57xe)
				else: hadMgR0nOKHoGqpA(NPM3HKQ57xe,'CATEGORIES___'+BvO3oKUrHNCwVm791b80sZg)
				return
			else:
				FjQOc5WuzKg0Vikb6tDeNHZP1mS = fgoWEt5zm2NOJM1ZSHGnLpjkv4IC(NPM3HKQ57xe)
				if bksErtC1hwcVqlfyM82AnD==DJrjnM9UKHA2Gp0zOtmR[-1]: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'الجميع ',FjQOc5WuzKg0Vikb6tDeNHZP1mS,251,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'filters')
				else: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'الجميع ',NPM3HKQ57xe,254,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,BvO3oKUrHNCwVm791b80sZg)
		elif type=='FILTERS':
			nnqvmxlXub3iVDM = RJGtCsyDgi0X+'&&'+bksErtC1hwcVqlfyM82AnD+'==0'
			tuYnONZ6GaCecv4TErUHMdBX2DIb8K = kYI6n5bUD83Z+'&&'+bksErtC1hwcVqlfyM82AnD+'==0'
			BvO3oKUrHNCwVm791b80sZg = nnqvmxlXub3iVDM+'___'+tuYnONZ6GaCecv4TErUHMdBX2DIb8K
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'الجميع :'+name,NPM3HKQ57xe,255,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,BvO3oKUrHNCwVm791b80sZg)
		dict[bksErtC1hwcVqlfyM82AnD] = {}
		for PBo1KkyMCgH8eNDaLtZVcr3EnIi2,QwGpLVOkc0MPodWfiYsTj,BoSjXKxz41DcneO9UimClE in items:
			if PBo1KkyMCgH8eNDaLtZVcr3EnIi2 in P3UK1Rr4IdYe5: continue
			if 'الكل' in PBo1KkyMCgH8eNDaLtZVcr3EnIi2: continue
			PBo1KkyMCgH8eNDaLtZVcr3EnIi2 = LNtIDdBA52P(PBo1KkyMCgH8eNDaLtZVcr3EnIi2)
			tZaSpl5NQAU8hxw,m4eVoJdSU51qs3y8Gg06fZNau7A = PBo1KkyMCgH8eNDaLtZVcr3EnIi2,PBo1KkyMCgH8eNDaLtZVcr3EnIi2
			m4eVoJdSU51qs3y8Gg06fZNau7A = name+': '+tZaSpl5NQAU8hxw
			dict[bksErtC1hwcVqlfyM82AnD][BoSjXKxz41DcneO9UimClE] = m4eVoJdSU51qs3y8Gg06fZNau7A
			nnqvmxlXub3iVDM = RJGtCsyDgi0X+'&&'+bksErtC1hwcVqlfyM82AnD+'=='+tZaSpl5NQAU8hxw
			tuYnONZ6GaCecv4TErUHMdBX2DIb8K = kYI6n5bUD83Z+'&&'+bksErtC1hwcVqlfyM82AnD+'=='+BoSjXKxz41DcneO9UimClE
			S80DwNWuMTZx4El = nnqvmxlXub3iVDM+'___'+tuYnONZ6GaCecv4TErUHMdBX2DIb8K
			if type=='FILTERS':
				RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+m4eVoJdSU51qs3y8Gg06fZNau7A,url,255,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,S80DwNWuMTZx4El)
			elif type=='CATEGORIES' and DJrjnM9UKHA2Gp0zOtmR[-2]+'==' in RJGtCsyDgi0X:
				PPlq1nxLf6CamuBI0psW = kKWuMB69mcOHPn3XilFdvp(tuYnONZ6GaCecv4TErUHMdBX2DIb8K,'modified_filters')
				CMzQFXeI08KDwAJ9p = url+'//getposts??'+PPlq1nxLf6CamuBI0psW
				FjQOc5WuzKg0Vikb6tDeNHZP1mS = fgoWEt5zm2NOJM1ZSHGnLpjkv4IC(CMzQFXeI08KDwAJ9p)
				RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+m4eVoJdSU51qs3y8Gg06fZNau7A,FjQOc5WuzKg0Vikb6tDeNHZP1mS,251,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'filters')
			else: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+m4eVoJdSU51qs3y8Gg06fZNau7A,url,254,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,S80DwNWuMTZx4El)
	return
DJrjnM9UKHA2Gp0zOtmR = ['category','country','release-year']
USknWg2JD6Vxv = ['category','country','genre','release-year','language','quality','rate']
def fgoWEt5zm2NOJM1ZSHGnLpjkv4IC(url):
	VUBhlAxKZz60JQI8cuM4pRiOt = '/wp-content/themes/Elshaikh2021/Ajaxat/Home/FilteringHome.php'
	url = url.replace('//getposts',VUBhlAxKZz60JQI8cuM4pRiOt)
	url = url.replace('/category/اخرى',hWGMqtBy4wuLaVcj)
	if VUBhlAxKZz60JQI8cuM4pRiOt not in url: url = url+VUBhlAxKZz60JQI8cuM4pRiOt
	url = url.replace('release-year','year')
	url = url.replace('??','?')
	url = url.replace('&&','&')
	url = url.replace('==','=')
	return url
def kKWuMB69mcOHPn3XilFdvp(UGewLrVFhBCo7MdZ8KEaJWXgYp,mode):
	UGewLrVFhBCo7MdZ8KEaJWXgYp = UGewLrVFhBCo7MdZ8KEaJWXgYp.strip('&&')
	ONVGLC8DSp4,mJuhvt0RPAbBMSla = {},hWGMqtBy4wuLaVcj
	if '==' in UGewLrVFhBCo7MdZ8KEaJWXgYp:
		items = UGewLrVFhBCo7MdZ8KEaJWXgYp.split('&&')
		for ImYg2jxU6Lc9Q1C4Oko in items:
			glBvuIRTJseUHjari,BoSjXKxz41DcneO9UimClE = ImYg2jxU6Lc9Q1C4Oko.split('==')
			ONVGLC8DSp4[glBvuIRTJseUHjari] = BoSjXKxz41DcneO9UimClE
	for key in USknWg2JD6Vxv:
		if key in list(ONVGLC8DSp4.keys()): BoSjXKxz41DcneO9UimClE = ONVGLC8DSp4[key]
		else: BoSjXKxz41DcneO9UimClE = '0'
		if '%' not in BoSjXKxz41DcneO9UimClE: BoSjXKxz41DcneO9UimClE = e1mT8H4dGS3XFyx0KLUA9(BoSjXKxz41DcneO9UimClE)
		if mode=='modified_values' and BoSjXKxz41DcneO9UimClE!='0': mJuhvt0RPAbBMSla = mJuhvt0RPAbBMSla+' + '+BoSjXKxz41DcneO9UimClE
		elif mode=='modified_filters' and BoSjXKxz41DcneO9UimClE!='0': mJuhvt0RPAbBMSla = mJuhvt0RPAbBMSla+'&&'+key+'=='+BoSjXKxz41DcneO9UimClE
		elif mode=='all': mJuhvt0RPAbBMSla = mJuhvt0RPAbBMSla+'&&'+key+'=='+BoSjXKxz41DcneO9UimClE
	mJuhvt0RPAbBMSla = mJuhvt0RPAbBMSla.strip(' + ')
	mJuhvt0RPAbBMSla = mJuhvt0RPAbBMSla.strip('&&')
	return mJuhvt0RPAbBMSla
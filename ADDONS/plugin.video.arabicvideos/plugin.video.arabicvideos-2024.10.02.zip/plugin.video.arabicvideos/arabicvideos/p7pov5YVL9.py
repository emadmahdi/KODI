# -*- coding: utf-8 -*-
from yoY3NdGViS import *
xjPuFK3EsIZSiobQ5X = 'ALFATIMI'
n0qFKQWhiBYXoTrvejVHUA4 = '_FTM_'
Str0BupDTFA = u6rbxnyjTl7I[xjPuFK3EsIZSiobQ5X][0]
TwsYHhUlKnfdeO4BtCLkp96 = ['1239','1250','1245','20','1259','218','485','1238','1258','292']
DDAKEUfeVt2H1vZblBcOrgo = ['3030','628']
def ehB18u9sQFRi(mode,url,text):
	if   mode==60: N6NCYivtV4I5rEXq = DP6FSBgNdX1rsvVR()
	elif mode==61: N6NCYivtV4I5rEXq = wg5aF3e8rcDh7SGpW6M1OPnkU(url,text)
	elif mode==62: N6NCYivtV4I5rEXq = GrsxUhb0PEXj2FQRAkD4q(url)
	elif mode==63: N6NCYivtV4I5rEXq = oanus6TxUFNAhSZKpJdYlEC4mV(url)
	elif mode==64: N6NCYivtV4I5rEXq = NEDcIqtWpoC7QbhP0rL(text)
	elif mode==69: N6NCYivtV4I5rEXq = lPwaAjFTMG4n7iSLkXcEuK0Zm(text)
	else: N6NCYivtV4I5rEXq = False
	return N6NCYivtV4I5rEXq
def DP6FSBgNdX1rsvVR():
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'بحث في الموقع',hWGMqtBy4wuLaVcj,69,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'_REMEMBERRESULTS_')
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+'ما يتم مشاهدته الان',Str0BupDTFA,64,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'recent_viewed_vids')
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+'الاكثر مشاهدة',Str0BupDTFA,64,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'most_viewed_vids')
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+'اضيفت مؤخرا',Str0BupDTFA,64,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'recently_added_vids')
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+'فيديو عشوائي',Str0BupDTFA,64,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'random_vids')
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+'افلام ومسلسلات',Str0BupDTFA,61,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'-1')
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+'البرامج الدينية',Str0BupDTFA,61,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'-2')
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+'English Videos',Str0BupDTFA,61,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'-3')
	return hWGMqtBy4wuLaVcj
def wg5aF3e8rcDh7SGpW6M1OPnkU(url,OJx4sYA9nNbtPT5ezmDHdVBk2C7):
	FFoBbcdLf2A4r3SZUktpHvshCNjgO = hWGMqtBy4wuLaVcj
	if OJx4sYA9nNbtPT5ezmDHdVBk2C7 not in ['-1','-2','-3']: FFoBbcdLf2A4r3SZUktpHvshCNjgO = '?cat='+OJx4sYA9nNbtPT5ezmDHdVBk2C7
	NPM3HKQ57xe = Str0BupDTFA+'/menu_level.php'+FFoBbcdLf2A4r3SZUktpHvshCNjgO
	mMQ3FkNVa4IlxqY = f1fLNcPlo2ECKtiBeug0OAvz9YM(KqO5BWGQR9JVL,NPM3HKQ57xe,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'ALFATIMI-TITLES-1st')
	items = trdVA0JvFaD.findall('href=\'(.*?)\'.*?>(.*?)<.*?>(.*?)</span>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	RuvxprKVZ0BTafWsSYqHc,llnMvPUcTBFr0CgN4sZbRYh1fA8u = False,False
	for llxFwq0CUNgQtivJzkHeGV,title,count in items:
		title = LNtIDdBA52P(title)
		title = title.strip(Mpsm2VF1OBnCRvK3qf6)
		if 'http' not in llxFwq0CUNgQtivJzkHeGV: llxFwq0CUNgQtivJzkHeGV = 'http:'+llxFwq0CUNgQtivJzkHeGV
		FFoBbcdLf2A4r3SZUktpHvshCNjgO = trdVA0JvFaD.findall('cat=(.*?)&',llxFwq0CUNgQtivJzkHeGV,trdVA0JvFaD.DOTALL)[0]
		if OJx4sYA9nNbtPT5ezmDHdVBk2C7==FFoBbcdLf2A4r3SZUktpHvshCNjgO: RuvxprKVZ0BTafWsSYqHc = True
		elif RuvxprKVZ0BTafWsSYqHc 	or (OJx4sYA9nNbtPT5ezmDHdVBk2C7=='-1' and FFoBbcdLf2A4r3SZUktpHvshCNjgO in TwsYHhUlKnfdeO4BtCLkp96)  						or (OJx4sYA9nNbtPT5ezmDHdVBk2C7=='-2' and FFoBbcdLf2A4r3SZUktpHvshCNjgO not in DDAKEUfeVt2H1vZblBcOrgo and FFoBbcdLf2A4r3SZUktpHvshCNjgO not in TwsYHhUlKnfdeO4BtCLkp96)  						or (OJx4sYA9nNbtPT5ezmDHdVBk2C7=='-3' and FFoBbcdLf2A4r3SZUktpHvshCNjgO in DDAKEUfeVt2H1vZblBcOrgo):
							if count=='1': RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,63)
							else: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,61,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,FFoBbcdLf2A4r3SZUktpHvshCNjgO)
							llnMvPUcTBFr0CgN4sZbRYh1fA8u = True
	if not llnMvPUcTBFr0CgN4sZbRYh1fA8u: GrsxUhb0PEXj2FQRAkD4q(url)
	return
def GrsxUhb0PEXj2FQRAkD4q(url):
	mMQ3FkNVa4IlxqY = f1fLNcPlo2ECKtiBeug0OAvz9YM(KqO5BWGQR9JVL,url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,True,'ALFATIMI-EPISODES-1st')
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('pagination(.*?)id="footer',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
	items = trdVA0JvFaD.findall('grid_view.*?src="(.*?)".*?title="(.*?)".*?<h2.*?href="(.*?)"',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	llxFwq0CUNgQtivJzkHeGV = hWGMqtBy4wuLaVcj
	for Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,title,llxFwq0CUNgQtivJzkHeGV in items:
		title = title.replace('Add',hWGMqtBy4wuLaVcj).replace('to Quicklist',hWGMqtBy4wuLaVcj).strip(Mpsm2VF1OBnCRvK3qf6)
		if 'http' not in llxFwq0CUNgQtivJzkHeGV: llxFwq0CUNgQtivJzkHeGV = 'http:'+llxFwq0CUNgQtivJzkHeGV
		RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,63,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o=trdVA0JvFaD.findall('(.*?)div',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	cok5ZGXdQP7YhwtqyuaCnVevm6UB=DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
	cok5ZGXdQP7YhwtqyuaCnVevm6UB=trdVA0JvFaD.findall('pagination(.*?)</div>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)[0]
	items=trdVA0JvFaD.findall('href="(.*?)".*?>(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	NPM3HKQ57xe = url.split('?')[0]
	for llxFwq0CUNgQtivJzkHeGV,sHmDY4STJ1cgEeyRMCk9LI5j8t in items:
		llxFwq0CUNgQtivJzkHeGV = NPM3HKQ57xe + llxFwq0CUNgQtivJzkHeGV
		title = LNtIDdBA52P(sHmDY4STJ1cgEeyRMCk9LI5j8t)
		title = 'صفحة ' + title
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,62)
	return llxFwq0CUNgQtivJzkHeGV
def oanus6TxUFNAhSZKpJdYlEC4mV(url):
	if 'videos.php' in url: url = GrsxUhb0PEXj2FQRAkD4q(url)
	mMQ3FkNVa4IlxqY = f1fLNcPlo2ECKtiBeug0OAvz9YM(DpQifS0oKBI1hYcO,url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,True,'ALFATIMI-PLAY-1st')
	items = trdVA0JvFaD.findall('playlistfile:"(.*?)"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	url = items[0]
	if 'http' not in url: url = 'http:'+url
	vOq38Y4XVZwdE(url,xjPuFK3EsIZSiobQ5X,'video')
	return
def NEDcIqtWpoC7QbhP0rL(OJx4sYA9nNbtPT5ezmDHdVBk2C7):
	l17Sn3hK59WV = { 'mode' : OJx4sYA9nNbtPT5ezmDHdVBk2C7 }
	url = 'http://alfatimi.tv/ajax.php'
	headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
	data = gQ5hRKULia2pdOWAxScMwTDbkl(l17Sn3hK59WV)
	mMQ3FkNVa4IlxqY = f1fLNcPlo2ECKtiBeug0OAvz9YM(nHBb7jXk0Daom,url,data,headers,True,'ALFATIMI-MOSTS-1st')
	items = trdVA0JvFaD.findall('href="(.*?)".*?title="(.*?)".*?src="(.*?)".*?href',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	for llxFwq0CUNgQtivJzkHeGV,title,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG in items:
		title = title.strip(Mpsm2VF1OBnCRvK3qf6)
		if 'http' not in llxFwq0CUNgQtivJzkHeGV: llxFwq0CUNgQtivJzkHeGV = 'http:'+llxFwq0CUNgQtivJzkHeGV
		RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,63,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
	return
def lPwaAjFTMG4n7iSLkXcEuK0Zm(search):
	search,vvKf4sXgZIMyEJPuC,showDialogs = IVTEJQOiMR2dYta9C(search)
	if search==hWGMqtBy4wuLaVcj: search = TrzfUidpv1LyAYqwexHJDuS()
	if search==hWGMqtBy4wuLaVcj: return
	lKqyOtIAvVY = search.replace(Mpsm2VF1OBnCRvK3qf6,'+')
	url = Str0BupDTFA + '/search_result.php?query=' + lKqyOtIAvVY
	GrsxUhb0PEXj2FQRAkD4q(url)
	return
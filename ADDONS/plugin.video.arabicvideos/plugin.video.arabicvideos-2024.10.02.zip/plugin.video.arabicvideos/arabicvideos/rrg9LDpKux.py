# -*- coding: utf-8 -*-
from yoY3NdGViS import *
headers = { 'User-Agent' : hWGMqtBy4wuLaVcj }
xjPuFK3EsIZSiobQ5X = 'AKWAM'
n0qFKQWhiBYXoTrvejVHUA4 = '_AKW_'
Str0BupDTFA = u6rbxnyjTl7I[xjPuFK3EsIZSiobQ5X][0]
KQzwjbWNH2IhXtcS = hWGMqtBy4wuLaVcj
P3UK1Rr4IdYe5 = ['ألعاب','المصارعة الحرة','القران الكريم','الكتب و الابحاث','الصور و الخلفيات','المسلسلات الاذاعية']
def ehB18u9sQFRi(mode,url,text):
	if   mode==240: N6NCYivtV4I5rEXq = DP6FSBgNdX1rsvVR()
	elif mode==241: N6NCYivtV4I5rEXq = wg5aF3e8rcDh7SGpW6M1OPnkU(url,text)
	elif mode==242: N6NCYivtV4I5rEXq = GrsxUhb0PEXj2FQRAkD4q(url)
	elif mode==243: N6NCYivtV4I5rEXq = oanus6TxUFNAhSZKpJdYlEC4mV(url)
	elif mode==244: N6NCYivtV4I5rEXq = hadMgR0nOKHoGqpA(url,'FILTERS___'+text)
	elif mode==245: N6NCYivtV4I5rEXq = hadMgR0nOKHoGqpA(url,'CATEGORIES___'+text)
	elif mode==246: N6NCYivtV4I5rEXq = Ko1cGYIDOe3rxMuqEl(url)
	elif mode==247: N6NCYivtV4I5rEXq = gu3WMCiNLv8Fst7R(url)
	elif mode==248: N6NCYivtV4I5rEXq = LFeuqhDwByI()
	elif mode==249: N6NCYivtV4I5rEXq = lPwaAjFTMG4n7iSLkXcEuK0Zm(text)
	else: N6NCYivtV4I5rEXq = False
	return N6NCYivtV4I5rEXq
def LFeuqhDwByI():
	BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'رسالة من المبرمج','هذا الموقع "أكوام الجديد" في بعض الأحيان فيه نوع من الحجب ضد البرامج . وهذا يسبب مشكلة في تشغيل الفيديوهات . هذه المشكلة سببها من الموقع الأصلي وهي تظهر وتختفي بصورة عشوائية')
	return
def DP6FSBgNdX1rsvVR():
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',Str0BupDTFA,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'AKWAM-MENU-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	Mx0rLEvu3taBjWdU = trdVA0JvFaD.findall('home-site-btn-container.*?href="(.*?)"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if Mx0rLEvu3taBjWdU: Mx0rLEvu3taBjWdU = Mx0rLEvu3taBjWdU[0]
	else: Mx0rLEvu3taBjWdU = Str0BupDTFA
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',Mx0rLEvu3taBjWdU,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'AKWAM-MENU-2nd')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'بحث في الموقع',hWGMqtBy4wuLaVcj,249,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'_REMEMBERRESULTS_')
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'فلتر محدد',Str0BupDTFA,246)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'فلتر كامل',Str0BupDTFA,247)
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+'المميزة',Mx0rLEvu3taBjWdU,241,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'featured')
	recent = trdVA0JvFaD.findall('recently-container.*?href="(.*?)"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	llxFwq0CUNgQtivJzkHeGV = recent[0]
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+'أضيف حديثا',llxFwq0CUNgQtivJzkHeGV,241)
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('mb-4 d-flex align-items-center.*?href="(.*?)".*?class="header-link text-white">(.*?)<.*?class="menu"(.*?)</div>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	for llxFwq0CUNgQtivJzkHeGV,name,cok5ZGXdQP7YhwtqyuaCnVevm6UB in DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		if name in P3UK1Rr4IdYe5: continue
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+name,llxFwq0CUNgQtivJzkHeGV,241)
		items = trdVA0JvFaD.findall('href="(.*?)">(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,title in items:
			if title in P3UK1Rr4IdYe5: continue
			title = name+Mpsm2VF1OBnCRvK3qf6+title
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,241)
	return
def Ko1cGYIDOe3rxMuqEl(website=hWGMqtBy4wuLaVcj):
	mMQ3FkNVa4IlxqY = f1fLNcPlo2ECKtiBeug0OAvz9YM(DpQifS0oKBI1hYcO,Str0BupDTFA,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,'AKWAM-MENU-1st')
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('class="menu(.*?)<nav',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('href="(.*?)".*?text">(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,title in items:
			if title not in P3UK1Rr4IdYe5:
				title = title+' مصنفة'
				RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,245)
		if website==hWGMqtBy4wuLaVcj: RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	return mMQ3FkNVa4IlxqY
def gu3WMCiNLv8Fst7R(website=hWGMqtBy4wuLaVcj):
	mMQ3FkNVa4IlxqY = f1fLNcPlo2ECKtiBeug0OAvz9YM(DpQifS0oKBI1hYcO,Str0BupDTFA,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,'AKWAM-MENU-1st')
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('class="menu(.*?)<nav',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('href="(.*?)".*?text">(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,title in items:
			if title not in P3UK1Rr4IdYe5:
				title = title+' مفلترة'
				RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,244)
		if website==hWGMqtBy4wuLaVcj: RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	return mMQ3FkNVa4IlxqY
def wg5aF3e8rcDh7SGpW6M1OPnkU(url,type=hWGMqtBy4wuLaVcj):
	mMQ3FkNVa4IlxqY = f1fLNcPlo2ECKtiBeug0OAvz9YM(KqO5BWGQR9JVL,url,hWGMqtBy4wuLaVcj,headers,True,'AKWAM-TITLES-1st')
	if type=='featured': DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('swiper-container(.*?)swiper-button-prev',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	else: DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('class="widget"(.*?)main-footer',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('data-src="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		if not items:
			items = trdVA0JvFaD.findall('src="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,llxFwq0CUNgQtivJzkHeGV,title in items:
			if '/series/' in llxFwq0CUNgQtivJzkHeGV or '/shows/' in llxFwq0CUNgQtivJzkHeGV:
				RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,242,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
			elif '/movies/' in llxFwq0CUNgQtivJzkHeGV:
				RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,243,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
			elif '/games/' not in llxFwq0CUNgQtivJzkHeGV:
				RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,243,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('pagination(.*?)</div>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('href="(.*?)".*?>(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,title in items:
			if title=='&lsaquo;': title = 'سابقة'
			if title=='&rsaquo;': title = 'لاحقة'
			llxFwq0CUNgQtivJzkHeGV = LNtIDdBA52P(llxFwq0CUNgQtivJzkHeGV)
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'صفحة '+title,llxFwq0CUNgQtivJzkHeGV,241)
	return
def lPwaAjFTMG4n7iSLkXcEuK0Zm(search):
	search,vvKf4sXgZIMyEJPuC,showDialogs = IVTEJQOiMR2dYta9C(search)
	if search==hWGMqtBy4wuLaVcj: search = TrzfUidpv1LyAYqwexHJDuS()
	if search==hWGMqtBy4wuLaVcj: return
	lKqyOtIAvVY = search.replace(Mpsm2VF1OBnCRvK3qf6,'%20')
	url = Str0BupDTFA + '/search?q='+lKqyOtIAvVY
	N6NCYivtV4I5rEXq = wg5aF3e8rcDh7SGpW6M1OPnkU(url)
	return
def GrsxUhb0PEXj2FQRAkD4q(url):
	mMQ3FkNVa4IlxqY = f1fLNcPlo2ECKtiBeug0OAvz9YM(KqO5BWGQR9JVL,url,hWGMqtBy4wuLaVcj,headers,True,'AKWAM-EPISODES-1st')
	if '-episodes">' not in mMQ3FkNVa4IlxqY:
		Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG = MMk8qKvcJe4fQHm3EG7diBD5.getInfoLabel('ListItem.Icon')
		RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+'رابط التشغيل',url,243,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
	else:
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('-episodes">(.*?)<div class="widget-4',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		aTjkFVusW1c35G8v = trdVA0JvFaD.findall('href="(http.*?)".*?>(.*?)<.*?src="(.*?)"',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,title,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG in aTjkFVusW1c35G8v:
			title = title.replace(FqcVAkh7WjIXHdDKf8nvuyRo,Mpsm2VF1OBnCRvK3qf6)
			if 'الحلقات' in title or 'مواسم اخرى' in title: continue
			if '/series/' in llxFwq0CUNgQtivJzkHeGV: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,242,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
			else: RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,243,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
	return
def oanus6TxUFNAhSZKpJdYlEC4mV(url):
	mMQ3FkNVa4IlxqY = f1fLNcPlo2ECKtiBeug0OAvz9YM(DpQifS0oKBI1hYcO,url,hWGMqtBy4wuLaVcj,headers,True,'AKWAM-PLAY-1st')
	BX029UJFPvpNQsc45jbYZRh = trdVA0JvFaD.findall('badge-danger.*?>(.*?)<',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if BX029UJFPvpNQsc45jbYZRh and Dc20k3vN9hT5(xjPuFK3EsIZSiobQ5X,url,BX029UJFPvpNQsc45jbYZRh): return
	kYnULZpSWKDCb31eAsV8yN = trdVA0JvFaD.findall('li><a href="#(.*?)".*?>(.*?)<',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	Dvi8asSrQYX5wE3KMIxT91me,haq1bHZINPE58uoBFnKfTSO2ik4,rqIW37cd0iT1msDzRevOM,kjl74rQdpWEIsVaJCFN3e6wDbu = [],[],[],[]
	if kYnULZpSWKDCb31eAsV8yN:
		QWz1jXGo6ruOitUMqET7yI5 = 'mp4'
		for yGdxzgRarIV5MKh,QS8ZdxkHD5bjU9qsn4zMYaPrg3h7 in kYnULZpSWKDCb31eAsV8yN:
			DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('tab-content quality" id="'+yGdxzgRarIV5MKh+'".*?</div>.\s*</div>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
			cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
			rqIW37cd0iT1msDzRevOM.append(cok5ZGXdQP7YhwtqyuaCnVevm6UB)
			kjl74rQdpWEIsVaJCFN3e6wDbu.append(QS8ZdxkHD5bjU9qsn4zMYaPrg3h7)
	else:
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('class="qualities(.*?)<h3.*?>(.*?)<',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if not DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
			BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'رسالة من المبرمج','لا يوجد ملف فيديو في هذا الرابط')
			return
		else:
			cok5ZGXdQP7YhwtqyuaCnVevm6UB,filename = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
			ly9Xa65Q23J = ['zip','rar','txt','pdf','htm','tar','iso','html']
			QWz1jXGo6ruOitUMqET7yI5 = filename.rsplit('.',1)[1].strip(Mpsm2VF1OBnCRvK3qf6)
			if QWz1jXGo6ruOitUMqET7yI5 in ly9Xa65Q23J:
				BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'رسالة من المبرمج','الملف ليس فيديو ولا صوت')
				return
		rqIW37cd0iT1msDzRevOM.append(cok5ZGXdQP7YhwtqyuaCnVevm6UB)
		kjl74rQdpWEIsVaJCFN3e6wDbu.append(hWGMqtBy4wuLaVcj)
	for PPuqrvDLEViYOMf1dmkK7 in range(len(rqIW37cd0iT1msDzRevOM)):
		m4IznKilUOByHweG68VJ = trdVA0JvFaD.findall('href="(.*?)".*?icon-(.*?)"',rqIW37cd0iT1msDzRevOM[PPuqrvDLEViYOMf1dmkK7],trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,AGRbL3eavtYnlWC8rN in m4IznKilUOByHweG68VJ:
			if 'torrent' in AGRbL3eavtYnlWC8rN: continue
			elif 'download' in AGRbL3eavtYnlWC8rN: type = 'download'
			elif 'play' in AGRbL3eavtYnlWC8rN: type = 'watch'
			else: type = 'unknown'
			llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV+'?named=__'+type+'____'+kjl74rQdpWEIsVaJCFN3e6wDbu[PPuqrvDLEViYOMf1dmkK7]+'__akwam'
			Dvi8asSrQYX5wE3KMIxT91me.append(llxFwq0CUNgQtivJzkHeGV)
	import oosSOfvdEQ
	oosSOfvdEQ.zfdYjsGLg8M6i15qZWh(Dvi8asSrQYX5wE3KMIxT91me,xjPuFK3EsIZSiobQ5X,'video',url)
	return
def hadMgR0nOKHoGqpA(url,filter):
	uEwaiBFX1Hr5 = ['section','category','year','rating']
	if '?' in url: url = url.split('?')[0]
	type,filter = filter.split('___',1)
	if filter==hWGMqtBy4wuLaVcj: RJGtCsyDgi0X,kYI6n5bUD83Z = hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj
	else: RJGtCsyDgi0X,kYI6n5bUD83Z = filter.split('___')
	if type=='CATEGORIES':
		if uEwaiBFX1Hr5[0]+'=' not in RJGtCsyDgi0X: OJx4sYA9nNbtPT5ezmDHdVBk2C7 = uEwaiBFX1Hr5[0]
		for PPuqrvDLEViYOMf1dmkK7 in range(len(uEwaiBFX1Hr5[0:-1])):
			if uEwaiBFX1Hr5[PPuqrvDLEViYOMf1dmkK7]+'=' in RJGtCsyDgi0X: OJx4sYA9nNbtPT5ezmDHdVBk2C7 = uEwaiBFX1Hr5[PPuqrvDLEViYOMf1dmkK7+1]
		nnqvmxlXub3iVDM = RJGtCsyDgi0X+'&'+OJx4sYA9nNbtPT5ezmDHdVBk2C7+'=0'
		tuYnONZ6GaCecv4TErUHMdBX2DIb8K = kYI6n5bUD83Z+'&'+OJx4sYA9nNbtPT5ezmDHdVBk2C7+'=0'
		BvO3oKUrHNCwVm791b80sZg = nnqvmxlXub3iVDM.strip('&')+'___'+tuYnONZ6GaCecv4TErUHMdBX2DIb8K.strip('&')
		PPlq1nxLf6CamuBI0psW = kKWuMB69mcOHPn3XilFdvp(kYI6n5bUD83Z,'all')
		NPM3HKQ57xe = url+'?'+PPlq1nxLf6CamuBI0psW
	elif type=='FILTERS':
		I2OnWkrPaVbwBSHiYR3LZ = kKWuMB69mcOHPn3XilFdvp(RJGtCsyDgi0X,'modified_values')
		I2OnWkrPaVbwBSHiYR3LZ = jkiCS0UWs2dNAJcGKn6mbHD(I2OnWkrPaVbwBSHiYR3LZ)
		if kYI6n5bUD83Z!=hWGMqtBy4wuLaVcj: kYI6n5bUD83Z = kKWuMB69mcOHPn3XilFdvp(kYI6n5bUD83Z,'all')
		if kYI6n5bUD83Z==hWGMqtBy4wuLaVcj: NPM3HKQ57xe = url
		else: NPM3HKQ57xe = url+'?'+kYI6n5bUD83Z
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'أظهار قائمة الفيديو التي تم اختيارها',NPM3HKQ57xe,241,hWGMqtBy4wuLaVcj,'1')
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+' [[   '+I2OnWkrPaVbwBSHiYR3LZ+'   ]]',NPM3HKQ57xe,241,hWGMqtBy4wuLaVcj,'1')
		RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	mMQ3FkNVa4IlxqY = f1fLNcPlo2ECKtiBeug0OAvz9YM(DpQifS0oKBI1hYcO,url,hWGMqtBy4wuLaVcj,headers,True,'AKWAM-FILTERS_MENU-1st')
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('<form id(.*?)</form>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
	f5rVHP4bmCd7cqvuYEQJlnLTk6yGRS = trdVA0JvFaD.findall('<select.*?name="(.*?)".*?">(.*?)<(.*?)</select>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	dict = {}
	for bksErtC1hwcVqlfyM82AnD,name,cok5ZGXdQP7YhwtqyuaCnVevm6UB in f5rVHP4bmCd7cqvuYEQJlnLTk6yGRS:
		items = trdVA0JvFaD.findall('<option(.*?)>(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		if '=' not in NPM3HKQ57xe: NPM3HKQ57xe = url
		if type=='CATEGORIES':
			if OJx4sYA9nNbtPT5ezmDHdVBk2C7!=bksErtC1hwcVqlfyM82AnD: continue
			elif len(items)<=1:
				if bksErtC1hwcVqlfyM82AnD==uEwaiBFX1Hr5[-1]: wg5aF3e8rcDh7SGpW6M1OPnkU(NPM3HKQ57xe)
				else: hadMgR0nOKHoGqpA(NPM3HKQ57xe,'CATEGORIES___'+BvO3oKUrHNCwVm791b80sZg)
				return
			else:
				if bksErtC1hwcVqlfyM82AnD==uEwaiBFX1Hr5[-1]: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'الجميع',NPM3HKQ57xe,241,hWGMqtBy4wuLaVcj,'1')
				else: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'الجميع',NPM3HKQ57xe,245,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,BvO3oKUrHNCwVm791b80sZg)
		elif type=='FILTERS':
			nnqvmxlXub3iVDM = RJGtCsyDgi0X+'&'+bksErtC1hwcVqlfyM82AnD+'=0'
			tuYnONZ6GaCecv4TErUHMdBX2DIb8K = kYI6n5bUD83Z+'&'+bksErtC1hwcVqlfyM82AnD+'=0'
			BvO3oKUrHNCwVm791b80sZg = nnqvmxlXub3iVDM+'___'+tuYnONZ6GaCecv4TErUHMdBX2DIb8K
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'الجميع : '+name,NPM3HKQ57xe,244,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,BvO3oKUrHNCwVm791b80sZg)
		dict[bksErtC1hwcVqlfyM82AnD] = {}
		for BoSjXKxz41DcneO9UimClE,PBo1KkyMCgH8eNDaLtZVcr3EnIi2 in items:
			if PBo1KkyMCgH8eNDaLtZVcr3EnIi2 in P3UK1Rr4IdYe5: continue
			if 'value' not in BoSjXKxz41DcneO9UimClE: BoSjXKxz41DcneO9UimClE = PBo1KkyMCgH8eNDaLtZVcr3EnIi2
			else: BoSjXKxz41DcneO9UimClE = trdVA0JvFaD.findall('"(.*?)"',BoSjXKxz41DcneO9UimClE,trdVA0JvFaD.DOTALL)[0]
			dict[bksErtC1hwcVqlfyM82AnD][BoSjXKxz41DcneO9UimClE] = PBo1KkyMCgH8eNDaLtZVcr3EnIi2
			nnqvmxlXub3iVDM = RJGtCsyDgi0X+'&'+bksErtC1hwcVqlfyM82AnD+'='+PBo1KkyMCgH8eNDaLtZVcr3EnIi2
			tuYnONZ6GaCecv4TErUHMdBX2DIb8K = kYI6n5bUD83Z+'&'+bksErtC1hwcVqlfyM82AnD+'='+BoSjXKxz41DcneO9UimClE
			S80DwNWuMTZx4El = nnqvmxlXub3iVDM+'___'+tuYnONZ6GaCecv4TErUHMdBX2DIb8K
			title = PBo1KkyMCgH8eNDaLtZVcr3EnIi2+' : '#+dict[bksErtC1hwcVqlfyM82AnD]['0']
			title = PBo1KkyMCgH8eNDaLtZVcr3EnIi2+' : '+name
			if type=='FILTERS': RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,url,244,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,S80DwNWuMTZx4El)
			elif type=='CATEGORIES' and uEwaiBFX1Hr5[-2]+'=' in RJGtCsyDgi0X:
				PPlq1nxLf6CamuBI0psW = kKWuMB69mcOHPn3XilFdvp(tuYnONZ6GaCecv4TErUHMdBX2DIb8K,'all')
				CMzQFXeI08KDwAJ9p = url+'?'+PPlq1nxLf6CamuBI0psW
				RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,CMzQFXeI08KDwAJ9p,241,hWGMqtBy4wuLaVcj,'1')
			else: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,url,245,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,S80DwNWuMTZx4El)
	return
def kKWuMB69mcOHPn3XilFdvp(UGewLrVFhBCo7MdZ8KEaJWXgYp,mode):
	UGewLrVFhBCo7MdZ8KEaJWXgYp = UGewLrVFhBCo7MdZ8KEaJWXgYp.strip('&')
	ONVGLC8DSp4 = {}
	if '=' in UGewLrVFhBCo7MdZ8KEaJWXgYp:
		items = UGewLrVFhBCo7MdZ8KEaJWXgYp.split('&')
		for ImYg2jxU6Lc9Q1C4Oko in items:
			glBvuIRTJseUHjari,BoSjXKxz41DcneO9UimClE = ImYg2jxU6Lc9Q1C4Oko.split('=')
			ONVGLC8DSp4[glBvuIRTJseUHjari] = BoSjXKxz41DcneO9UimClE
	mJuhvt0RPAbBMSla = hWGMqtBy4wuLaVcj
	MM02bgXexGhSpwQtlILydi1KJCOFz = ['section','category','rating','year','language','formats','quality']
	for key in MM02bgXexGhSpwQtlILydi1KJCOFz:
		if key in list(ONVGLC8DSp4.keys()): BoSjXKxz41DcneO9UimClE = ONVGLC8DSp4[key]
		else: BoSjXKxz41DcneO9UimClE = '0'
		if mode=='modified_values' and BoSjXKxz41DcneO9UimClE!='0': mJuhvt0RPAbBMSla = mJuhvt0RPAbBMSla+' + '+BoSjXKxz41DcneO9UimClE
		elif mode=='modified_filters' and BoSjXKxz41DcneO9UimClE!='0': mJuhvt0RPAbBMSla = mJuhvt0RPAbBMSla+'&'+key+'='+BoSjXKxz41DcneO9UimClE
		elif mode=='all': mJuhvt0RPAbBMSla = mJuhvt0RPAbBMSla+'&'+key+'='+BoSjXKxz41DcneO9UimClE
	mJuhvt0RPAbBMSla = mJuhvt0RPAbBMSla.strip(' + ')
	mJuhvt0RPAbBMSla = mJuhvt0RPAbBMSla.strip('&')
	return mJuhvt0RPAbBMSla
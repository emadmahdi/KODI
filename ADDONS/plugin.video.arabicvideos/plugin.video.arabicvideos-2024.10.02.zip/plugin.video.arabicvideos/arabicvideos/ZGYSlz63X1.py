# -*- coding: utf-8 -*-
import sys as zGjD5QAkd7SO9YPcZl
A56Abl2j14QS = zGjD5QAkd7SO9YPcZl.version_info [0] == 2
qO2vebR9rSTZnuJDW = 2048
EECQl2Zun37S0KkWwtIDHYNai6Ayd8 = 7
def wwTjCFmkUK (mMBv4T89VDdfJGL):
	global ylRUYSmHX7oCf93TADc8J6rqMVL
	tE23ZuI91qGJ = ord (mMBv4T89VDdfJGL [-1])
	huZOyFMzvY3LpEf = mMBv4T89VDdfJGL [:-1]
	FXE237NbgJweKmBxPfVnsAoYjCazqW = tE23ZuI91qGJ % len (huZOyFMzvY3LpEf)
	LQ2yAP51CVNFXdr = huZOyFMzvY3LpEf [:FXE237NbgJweKmBxPfVnsAoYjCazqW] + huZOyFMzvY3LpEf [FXE237NbgJweKmBxPfVnsAoYjCazqW:]
	if A56Abl2j14QS:
		R0i7UHvbBw25n8 = unicode () .join ([unichr (ord (cIsD9VN758uwbLUaGM2zmEY) - qO2vebR9rSTZnuJDW - (o42QnFjKJ5l98hWTqzCDi73LcvNA + tE23ZuI91qGJ) % EECQl2Zun37S0KkWwtIDHYNai6Ayd8) for o42QnFjKJ5l98hWTqzCDi73LcvNA, cIsD9VN758uwbLUaGM2zmEY in enumerate (LQ2yAP51CVNFXdr)])
	else:
		R0i7UHvbBw25n8 = str () .join ([chr (ord (cIsD9VN758uwbLUaGM2zmEY) - qO2vebR9rSTZnuJDW - (o42QnFjKJ5l98hWTqzCDi73LcvNA + tE23ZuI91qGJ) % EECQl2Zun37S0KkWwtIDHYNai6Ayd8) for o42QnFjKJ5l98hWTqzCDi73LcvNA, cIsD9VN758uwbLUaGM2zmEY in enumerate (LQ2yAP51CVNFXdr)])
	return eval (R0i7UHvbBw25n8)
NeO3CTLHrPfWUoIgy8Q,KNIvHPjUbhr,CnbBKmtF1x84q7AW=wwTjCFmkUK,wwTjCFmkUK,wwTjCFmkUK
zyvJMtBhrw,MMizeNH0AKu,KBkxSYaz93pu1=CnbBKmtF1x84q7AW,KNIvHPjUbhr,NeO3CTLHrPfWUoIgy8Q
LB2q7IVRpcyXlE6C3ihZruPe4An1Y,EDgpT9hIF6GCfl0vXiWnBANjOUVRua,XQo0YS3sk4rHAvwyNltf9CipLWMjx=KBkxSYaz93pu1,MMizeNH0AKu,zyvJMtBhrw
hWUz1ujibPY3G9MIZmvS4kVaK7dT,DJ1ICpbyR2,e2qDYgipPmTw4KvBLnochr=XQo0YS3sk4rHAvwyNltf9CipLWMjx,EDgpT9hIF6GCfl0vXiWnBANjOUVRua,LB2q7IVRpcyXlE6C3ihZruPe4An1Y
A6dMB1FlgxVivJ2fk9C,mkHKSQvjWr5BTcM3wVY,o1u5dij9UrcbXzVS8lwIWfKpnqM=e2qDYgipPmTw4KvBLnochr,DJ1ICpbyR2,hWUz1ujibPY3G9MIZmvS4kVaK7dT
JwiZdgbG5HYuCIsj69aBSRQ0nrNkET,SqrG5mU3j96ldsFpExobw40TJY,HHoGx7Flus60=o1u5dij9UrcbXzVS8lwIWfKpnqM,mkHKSQvjWr5BTcM3wVY,A6dMB1FlgxVivJ2fk9C
QVDJLRlxNg127jMX,gDuGMR3z1aV6YdLmCpiO8Kl,jeAby54c02TgG8zuivonX91=HHoGx7Flus60,SqrG5mU3j96ldsFpExobw40TJY,JwiZdgbG5HYuCIsj69aBSRQ0nrNkET
S1SgCFYGJeMvfp5iZXK,dv0trJR7PwmKyxDYO52VLau8gEph,QvgnCALNstmuUJiET=jeAby54c02TgG8zuivonX91,gDuGMR3z1aV6YdLmCpiO8Kl,QVDJLRlxNg127jMX
OOsBSKq9u6J2lC5WdYpvNMHaFP4,rwQN9AKhLCuMfHxjlbX0U,xcChIL13BpR8WArNt9Pl0So=QvgnCALNstmuUJiET,dv0trJR7PwmKyxDYO52VLau8gEph,S1SgCFYGJeMvfp5iZXK
sULh4NjakzI8He7xJCMGrql,LAhIMyBG0xZVUlO4rJ9z5fbDFgCs,GA4NBdjuZqkKUX6IEMvHPoegDyVrLm=xcChIL13BpR8WArNt9Pl0So,rwQN9AKhLCuMfHxjlbX0U,OOsBSKq9u6J2lC5WdYpvNMHaFP4
ITvnUAMXsyb4eO,wwPrSDa21lUh,FimxS5jkaq1RcJ8DnWTZNO4zQClwt=GA4NBdjuZqkKUX6IEMvHPoegDyVrLm,LAhIMyBG0xZVUlO4rJ9z5fbDFgCs,sULh4NjakzI8He7xJCMGrql
from yoY3NdGViS import *
xjPuFK3EsIZSiobQ5X = mkHKSQvjWr5BTcM3wVY(u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕࠪ৮")
def ehB18u9sQFRi(JbpxsyQVXmSEYKM3vo847Ckh,s9ea72VfoygAOFRCWQTH3zmDuLPE=hWGMqtBy4wuLaVcj):
	if   JbpxsyQVXmSEYKM3vo847Ckh==DJ1ICpbyR2(u"࠰೶"): lZPHq0Az7CdhU9Ika4FWs6B(s9ea72VfoygAOFRCWQTH3zmDuLPE)
	elif JbpxsyQVXmSEYKM3vo847Ckh==A6dMB1FlgxVivJ2fk9C(u"࠲೷"): pass
	elif JbpxsyQVXmSEYKM3vo847Ckh==o1u5dij9UrcbXzVS8lwIWfKpnqM(u"࠴೸"): mag0BJDLNYjc1iKkpl8(s9ea72VfoygAOFRCWQTH3zmDuLPE)
	elif JbpxsyQVXmSEYKM3vo847Ckh==jeAby54c02TgG8zuivonX91(u"࠶೹"): aaFp08c2lEDbxSoYN()
	elif JbpxsyQVXmSEYKM3vo847Ckh==zyvJMtBhrw(u"࠸೺"): sYzH8e57tGm(s9ea72VfoygAOFRCWQTH3zmDuLPE)
	elif JbpxsyQVXmSEYKM3vo847Ckh==DJ1ICpbyR2(u"࠺೻"): JdPhvL270fIxaYSgVABw1e()
	elif JbpxsyQVXmSEYKM3vo847Ckh==LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"࠼೼"): tsS1hMmVRZLFwlCgcI27TPqJQ3WY()
	elif JbpxsyQVXmSEYKM3vo847Ckh==NeO3CTLHrPfWUoIgy8Q(u"࠷೽"): QYpFblwDT5fzUaMWgcurv8qHXC4ek()
	elif JbpxsyQVXmSEYKM3vo847Ckh==o1u5dij9UrcbXzVS8lwIWfKpnqM(u"࠹೾"): qcRILexpUFD6dMmGW()
	elif JbpxsyQVXmSEYKM3vo847Ckh==o1u5dij9UrcbXzVS8lwIWfKpnqM(u"࠻೿"): BBO7Q5CkHhnvotm1ulidUp4JTINX()
	elif JbpxsyQVXmSEYKM3vo847Ckh==KBkxSYaz93pu1(u"࠴࠹࠵ഀ"): uV7hsqACXr8gRlZS9DJp5KcYU()
	elif JbpxsyQVXmSEYKM3vo847Ckh==SqrG5mU3j96ldsFpExobw40TJY(u"࠵࠺࠷ഁ"): lzLcCA8FEJ()
	elif JbpxsyQVXmSEYKM3vo847Ckh==hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"࠶࠻࠲ം"): aaXMLiW9Or0()
	elif JbpxsyQVXmSEYKM3vo847Ckh==QvgnCALNstmuUJiET(u"࠷࠵࠴ഃ"): ZZREdAcOqXvD7iwg42eBGj6()
	elif JbpxsyQVXmSEYKM3vo847Ckh==o1u5dij9UrcbXzVS8lwIWfKpnqM(u"࠱࠶࠶ഄ"): Wcw3BPuqahs4zvOKmf6FVR()
	elif JbpxsyQVXmSEYKM3vo847Ckh==HHoGx7Flus60(u"࠲࠷࠸അ"): N4ICKte1Gwzlk()
	elif JbpxsyQVXmSEYKM3vo847Ckh==FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"࠳࠸࠺ആ"): wp1I8lbtTesBv()
	elif JbpxsyQVXmSEYKM3vo847Ckh==zyvJMtBhrw(u"࠴࠹࠼ഇ"): vDjYFoBSQGJKbRpUs2A()
	elif JbpxsyQVXmSEYKM3vo847Ckh==S1SgCFYGJeMvfp5iZXK(u"࠵࠺࠾ഈ"): XD3H59QuSPwhlaLR()
	elif JbpxsyQVXmSEYKM3vo847Ckh==QvgnCALNstmuUJiET(u"࠶࠻࠹ഉ"): TGM1riEyHtLYb4RjX5pxolJ(VBlawK4mgHSyLEn8iqhUkz5)
	elif JbpxsyQVXmSEYKM3vo847Ckh==HHoGx7Flus60(u"࠷࠷࠱ഊ"): KfzxPSRovbeX5jGONytpuZA()
	elif JbpxsyQVXmSEYKM3vo847Ckh==XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"࠱࠸࠳ഋ"): T4T7vDhbYmgAFESO8xotk()
	elif JbpxsyQVXmSEYKM3vo847Ckh==wwPrSDa21lUh(u"࠲࠹࠵ഌ"): BxcQwOiEX8JSl9tonLUgu04yvC([s9ea72VfoygAOFRCWQTH3zmDuLPE],VBlawK4mgHSyLEn8iqhUkz5,VBlawK4mgHSyLEn8iqhUkz5,fEXMiAyG3ql4vKB)
	elif JbpxsyQVXmSEYKM3vo847Ckh==e2qDYgipPmTw4KvBLnochr(u"࠳࠺࠷഍"): ff1TqXMbjgJ6n4yko(FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡢࡦࡤࡴࡹ࡯ࡶࡦࠩ৯"),VBlawK4mgHSyLEn8iqhUkz5)
	elif JbpxsyQVXmSEYKM3vo847Ckh==KBkxSYaz93pu1(u"࠴࠻࠹എ"): ff1TqXMbjgJ6n4yko(QvgnCALNstmuUJiET(u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡴࡷࡱࡵ࠭ৰ"),VBlawK4mgHSyLEn8iqhUkz5)
	elif JbpxsyQVXmSEYKM3vo847Ckh==DJ1ICpbyR2(u"࠵࠼࠻ഏ"): Cx8MGk5yR4()
	elif JbpxsyQVXmSEYKM3vo847Ckh==rwQN9AKhLCuMfHxjlbX0U(u"࠶࠽࠶ഐ"): OO4dAhD7LMsXH5YrU3kZipfx0()
	elif JbpxsyQVXmSEYKM3vo847Ckh==SqrG5mU3j96ldsFpExobw40TJY(u"࠷࠷࠸഑"): Pspq8YShiHQvEd0ICnc31yjUF(rwQN9AKhLCuMfHxjlbX0U(u"ࠫࡸࡩࡲࡪࡲࡷ࠲ࡲࡵࡤࡶ࡮ࡨ࠲ࡷ࡫ࡳࡰ࡮ࡹࡩࡺࡸ࡬ࠨৱ"))
	elif JbpxsyQVXmSEYKM3vo847Ckh==EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"࠱࠸࠺ഒ"): Pspq8YShiHQvEd0ICnc31yjUF(ITvnUAMXsyb4eO(u"ࠬࡹࡣࡳ࡫ࡳࡸ࠳ࡳ࡯ࡥࡷ࡯ࡩ࠳ࡿࡴ࠮ࡦ࡯ࡴࠬ৲"))
	elif JbpxsyQVXmSEYKM3vo847Ckh==e2qDYgipPmTw4KvBLnochr(u"࠲࠹࠼ഓ"): Pspq8YShiHQvEd0ICnc31yjUF(FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠭৳"))
	elif JbpxsyQVXmSEYKM3vo847Ckh==SqrG5mU3j96ldsFpExobw40TJY(u"࠳࠼࠴ഔ"): qRXHeAKQwYDLP()
	elif JbpxsyQVXmSEYKM3vo847Ckh==JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"࠴࠽࠶ക"): Nh2r4w7uMlxa5Wvno()
	elif JbpxsyQVXmSEYKM3vo847Ckh==OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"࠵࠾࠸ഖ"): yNMPYQgiqof()
	elif JbpxsyQVXmSEYKM3vo847Ckh==KBkxSYaz93pu1(u"࠶࠿࠳ഗ"): SQ8sJcaWwy1LotFZMUPlD2Tx()
	elif JbpxsyQVXmSEYKM3vo847Ckh==wwPrSDa21lUh(u"࠷࠹࠵ഘ"): ZHo3qmFuwaJQ()
	elif JbpxsyQVXmSEYKM3vo847Ckh==MMizeNH0AKu(u"࠱࠺࠷ങ"): Ji19IVyPck5()
	elif JbpxsyQVXmSEYKM3vo847Ckh==wwPrSDa21lUh(u"࠲࠻࠹ച"): JjPdR2QwD7fHt3E6uriOhp5c()
	elif JbpxsyQVXmSEYKM3vo847Ckh==o1u5dij9UrcbXzVS8lwIWfKpnqM(u"࠳࠼࠻ഛ"): RRfGkMuH2JSXcgj1()
	elif JbpxsyQVXmSEYKM3vo847Ckh==LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"࠴࠽࠽ജ"): KpkHMIuxQcDV9XPySE83B6TwnF()
	elif JbpxsyQVXmSEYKM3vo847Ckh==EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"࠵࠾࠿ഝ"): XJGWgVeZ5PmAOknMUQiylLdD18R()
	elif JbpxsyQVXmSEYKM3vo847Ckh==o1u5dij9UrcbXzVS8lwIWfKpnqM(u"࠸࠺࠰ഞ"): Ivab0rCK6nUOTZ5jEc3Ss48R(s9ea72VfoygAOFRCWQTH3zmDuLPE)
	elif JbpxsyQVXmSEYKM3vo847Ckh==S1SgCFYGJeMvfp5iZXK(u"࠹࠴࠲ട"): ZZf2P84FwEJgrslpGVvjc1z()
	elif JbpxsyQVXmSEYKM3vo847Ckh==DJ1ICpbyR2(u"࠳࠵࠴ഠ"): LceZoal2ANE3u()
	elif JbpxsyQVXmSEYKM3vo847Ckh==DJ1ICpbyR2(u"࠴࠶࠶ഡ"): xas43yPL7epf9B()
	elif JbpxsyQVXmSEYKM3vo847Ckh==zyvJMtBhrw(u"࠵࠷࠸ഢ"): ZZIUbqTVz3GRnBu(VBlawK4mgHSyLEn8iqhUkz5)
	elif JbpxsyQVXmSEYKM3vo847Ckh==wwPrSDa21lUh(u"࠶࠸࠺ണ"): RLC7QV5s28uoavEkfHeTn9NqYwyz()
	elif JbpxsyQVXmSEYKM3vo847Ckh==sULh4NjakzI8He7xJCMGrql(u"࠷࠹࠼ത"): DC4GvtpUbZJ38mfMIRijkY(fEXMiAyG3ql4vKB)
	elif JbpxsyQVXmSEYKM3vo847Ckh==QvgnCALNstmuUJiET(u"࠸࠺࠷ഥ"): Y6MUwOztEjeTSW7Ha(VBlawK4mgHSyLEn8iqhUkz5)
	elif JbpxsyQVXmSEYKM3vo847Ckh==LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"࠹࠴࠹ദ"): FNMdbyGSQCHAzO61KtwjJXqRD2()
	elif JbpxsyQVXmSEYKM3vo847Ckh==MMizeNH0AKu(u"࠳࠵࠻ധ"): Wf4vUZliHmBr3PL9bzx(QvgnCALNstmuUJiET(u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬ৴"),VBlawK4mgHSyLEn8iqhUkz5,VBlawK4mgHSyLEn8iqhUkz5)
	elif JbpxsyQVXmSEYKM3vo847Ckh==OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"࠶࠲࠳ന"): kkOY3Ffzs8RD()
	elif JbpxsyQVXmSEYKM3vo847Ckh==XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"࠷࠳࠵ഩ"): eUndmqOvYQo6KGrykfHX253b()
	elif JbpxsyQVXmSEYKM3vo847Ckh==mkHKSQvjWr5BTcM3wVY(u"࠸࠴࠷പ"): llAKR46tqu0()
	elif JbpxsyQVXmSEYKM3vo847Ckh==KBkxSYaz93pu1(u"࠹࠵࠹ഫ"): zto9f7QBjT1KDNFcOwr3ZRVIWi(UC78nrbeDHfwVAh2vt)
	elif JbpxsyQVXmSEYKM3vo847Ckh==LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"࠺࠶࠴ബ"): zto9f7QBjT1KDNFcOwr3ZRVIWi(IlCq2uKjye3ZgSADFc)
	elif JbpxsyQVXmSEYKM3vo847Ckh==jeAby54c02TgG8zuivonX91(u"࠻࠰࠶ഭ"): ffmBzj9LhYFqt()
	elif JbpxsyQVXmSEYKM3vo847Ckh==sULh4NjakzI8He7xJCMGrql(u"࠵࠱࠸മ"): OwGHUMSI3WuYd9VtcC5ehnbFxv04Xi(VBlawK4mgHSyLEn8iqhUkz5)
	elif JbpxsyQVXmSEYKM3vo847Ckh==ITvnUAMXsyb4eO(u"࠶࠲࠺യ"): Bt6ZJeX0PS5IsOaTHM34W()
	elif JbpxsyQVXmSEYKM3vo847Ckh==QVDJLRlxNg127jMX(u"࠷࠳࠼ര"): gIWarve3NMd9RnVjqZbAl()
	elif JbpxsyQVXmSEYKM3vo847Ckh==sULh4NjakzI8He7xJCMGrql(u"࠸࠴࠾റ"): emOlCn5JbvLQizYj()
	elif JbpxsyQVXmSEYKM3vo847Ckh==EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"࠵࠵࠸࠰ല"): e6otJTfO1P7mMakrHRU2qb43GNBAK()
	elif JbpxsyQVXmSEYKM3vo847Ckh==sULh4NjakzI8He7xJCMGrql(u"࠶࠶࠲࠲ള"): svqfOYaR2cD7x59Kpth6()
	elif JbpxsyQVXmSEYKM3vo847Ckh==OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"࠷࠰࠳࠴ഴ"): Pspq8YShiHQvEd0ICnc31yjUF(QVDJLRlxNg127jMX(u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭৵"))
	return
def svqfOYaR2cD7x59Kpth6(bgFiwzJWZ5uy=fEXMiAyG3ql4vKB):
	jj8ZdyQ4slV9BtTD6nSFNALaX1bc = ooH16lsAetOSVay8()
	LpGRlzrQj07P = sULh4NjakzI8He7xJCMGrql(u"ࠩส่ฯฺฺ๋ๆࠣห้๊วฮไࠣ๎฾๋ไࠨ৶") if jj8ZdyQ4slV9BtTD6nSFNALaX1bc else KNIvHPjUbhr(u"ࠪห้ะิ฻์็ࠤฬ๊ไศฯๅࠤ๊ะ่ใใࠪ৷")
	NN8u2B5iU3RMYheFy = jbQkTyxAerZR409gYFq(e2qDYgipPmTw4KvBLnochr(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ৸"),FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠬิั้ฮࠪ৹"),SqrG5mU3j96ldsFpExobw40TJY(u"࠭ล๋ไสๅࠬ৺"),hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠧหึ฽๎้࠭৻"),A6dMB1FlgxVivJ2fk9C(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫৼ"),hXB0vKVQ5PRI91SDTprMdfuHEm4+LpGRlzrQj07P+YYSh2J6BIrsm8+NXMOzZjYsmS9pf+sULh4NjakzI8He7xJCMGrql(u"๊ࠩิ์ࠦวๅ๊฻๎ๆฯࠠหฮ฼่้่ࠥะ์ࠣวํะ่ๆษอ๎่๐วࠡ์ๅ์๊ࠦศหึ฽๎้ࠦวๅใํำ๏๎ࠠศๆ็หา่ࠠ࠯࠰ࠣษ๊อࠠษ฻าࠤฬ์ส่ษฤࠤฬ๊แ๋ัํ์ࠥอไฮษ็๎ࠥฮรไ็็๋ࠥ࠴࠮ࠡล๋ࠤอ฿ฯࠡษ็๊็ืฺࠠๆ์ࠤืืࠠࠣฬฯหํุࠠฦๆ์ࠤฬ๊ไศฯๅࠦࠥ࠴࠮๊ࠡฦ๎฻อࠠๆ็ๆ๊ࠥหไ฻ษฤࠤฬ๊สี฼ํ่ࠥอไๅษะๆࠥฮวๅ่ๅีࠥ฿ไ๊ࠢีีࠥࠨล๋ไสๅࠥอไโ์า๎ํࠨࠠ࠯࠰ࠣ์ศ๐ึศ่้่ࠢ์ࠠศๆสืฯ็วะห้๋ࠣࠦส฻์ํีࠥะัห์หࠤ๊ำส้์สฮࠥอไใ๊สส๊ࠦ࠮࠯๋ࠢาฬ฻ษࠡฬิฮ๏ฮࠠฮๆๅหฯࠦวๅ็ึุ่๊วหࠢ࠱࠲ࠥํไࠡฬิ๎ิࠦวๅฤ้ࠤฯฺฺ๋ๆ๋ࠣีํࠠศๆ๋฼๏็ษࠡล่ࠤส๐โศใ๊หࠥลࠡࠢࠩ৽"))
	if NN8u2B5iU3RMYheFy==bXukYxQ4aHw: ayNEJoZrebx2usT = MMk8qKvcJe4fQHm3EG7diBD5.executeJSONRPC(SqrG5mU3j96ldsFpExobw40TJY(u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡖࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡘ࡫ࡴࡔࡧࡷࡸ࡮ࡴࡧࡗࡣ࡯ࡹࡪࠨࠬࠣ࡫ࡧࠦ࠿࠷ࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡸ࡫ࡴࡵ࡫ࡱ࡫ࠧࡀࠢࡷ࡫ࡧࡩࡴࡶ࡬ࡢࡻࡨࡶ࠳ࡧࡵࡵࡱࡳࡰࡦࡿ࡮ࡦࡺࡷ࡭ࡹ࡫࡭ࠣ࠮ࠥࡺࡦࡲࡵࡦࠤ࠽࡟ࡢࢃࡽࠨ৾"))
	elif NN8u2B5iU3RMYheFy==Y0XZKGRAUQj5O: ayNEJoZrebx2usT = MMk8qKvcJe4fQHm3EG7diBD5.executeJSONRPC(zyvJMtBhrw(u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡗࡪࡺࡴࡪࡰࡪࡷ࠳࡙ࡥࡵࡕࡨࡸࡹ࡯࡮ࡨࡘࡤࡰࡺ࡫ࠢ࠭ࠤ࡬ࡨࠧࡀ࠱࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡹࡥࡵࡶ࡬ࡲ࡬ࠨ࠺ࠣࡸ࡬ࡨࡪࡵࡰ࡭ࡣࡼࡩࡷ࠴ࡡࡶࡶࡲࡴࡱࡧࡹ࡯ࡧࡻࡸ࡮ࡺࡥ࡮ࠤ࠯ࠦࡻࡧ࡬ࡶࡧࠥ࠾ࡠ࠷࡝ࡾࡿࠪ৿"))
	if NN8u2B5iU3RMYheFy in [bXukYxQ4aHw,Y0XZKGRAUQj5O]:
		if JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠬࡺࡲࡶࡧࠪ਀") in str(ayNEJoZrebx2usT): BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,SqrG5mU3j96ldsFpExobw40TJY(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩਁ"),EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠧห็อࠤฬู๊ๆๆํอࠥฮๆอษะࠫਂ"))
		else: BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,jeAby54c02TgG8zuivonX91(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫਃ"),A6dMB1FlgxVivJ2fk9C(u"ࠩ็่ศูแࠡษ็฽๊๊๊สࠢไุ้ะࠧ਄"))
	return
def e6otJTfO1P7mMakrHRU2qb43GNBAK():
	url = u6rbxnyjTl7I[DJ1ICpbyR2(u"ࠪࡖࡊࡒࡅࡂࡕࡈࡗࠬਅ")][dv0trJR7PwmKyxDYO52VLau8gEph(u"࠰വ")]
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(lke5D6CpaAXPdEZyrBSw7T,hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠫࡌࡋࡔࠨਆ"),url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,dv0trJR7PwmKyxDYO52VLau8gEph(u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙࠭ࡊࡐࡖࡘࡆࡒࡌࡠࡑࡏࡈࡤࡘࡅࡍࡇࡄࡗࡊ࠳࠱ࡴࡶࠪਇ"))
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	o9frzGZySuB7KL3xNTAMI6gl8XjqiH = trdVA0JvFaD.findall(hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"࠭ࡨࡳࡧࡩࡁࠧࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࠭ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶ࠲࠯ࡅࠩ࠯ࡼ࡬ࡴࠧ࠭ਈ"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	o9frzGZySuB7KL3xNTAMI6gl8XjqiH = sorted(o9frzGZySuB7KL3xNTAMI6gl8XjqiH,reverse=VBlawK4mgHSyLEn8iqhUkz5)
	OODLkJlZCoKmrzbg2XQSGPUdInA = Eb7qJoNwOgn(xcChIL13BpR8WArNt9Pl0So(u"ࠧศะอีࠥอไฦืาหึࠦวๅาํࠤฯื๊ะࠢอฯอ๐ส่ࠩਉ"),o9frzGZySuB7KL3xNTAMI6gl8XjqiH)
	if OODLkJlZCoKmrzbg2XQSGPUdInA>=EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"࠱ശ"):
		T1q7iEHwgj4 = url.rsplit(ITvnUAMXsyb4eO(u"ࠨ࠱ࠪਊ"),GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"࠳ഷ"))[CnbBKmtF1x84q7AW(u"࠳സ")]+KBkxSYaz93pu1(u"ࠩ࠲ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࠪ਋")+o9frzGZySuB7KL3xNTAMI6gl8XjqiH[OODLkJlZCoKmrzbg2XQSGPUdInA]+A6dMB1FlgxVivJ2fk9C(u"ࠪ࠲ࡿ࡯ࡰࠨ਌")
		succeeded = mZyWVOcY2eR3AKd(S1SgCFYGJeMvfp5iZXK(u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩ਍"),T1q7iEHwgj4,S1SgCFYGJeMvfp5iZXK(u"࡙ࡸࡵࡦඇ"))
		if succeeded:
			ee8c0jzrTntGSUdRJm.setSetting(QVDJLRlxNg127jMX(u"ࠬࡧࡶ࠯ࡸࡨࡶࡸ࡯࡯࡯ࠩ਎"),hWGMqtBy4wuLaVcj)
			dHPVDWfG4jX5e6QEo0CKh = XVmKrby29eCGMnlEY6jz0HNOR(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,KBkxSYaz93pu1(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩਏ"),LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠧห็ࠣฮะฮ๊หࠢศูิอัࠡไา๎๊ࠦไๅสิ๊ฬ๋ฬࠡ࠰࠱ࠤ้้ๆࠡสิ๊ฬ๋ฬࠡๅ๋ำ๏๊ࠦใ๊่ࠤศ๎ส้็สฮ๏้๊ศࠢหฮาี๊ฬࠢฯ้๏฿ࠠศๆหีฬ๋ฬࠡสสืฯิฯศ็ࠣฦำืࠠฦืาหึࠦๅห๊ไีࠥ࠴࠮้ࠡ็ࠤฯื๊ะࠢส่ว์ࠠฦ์ๅหๆࠦวๅฬะำ๏ัࠠศๆฦ์ฯ๎ๅศฬํ็๏ࠦไ่าสࠤฬ๊ศา่ส้ัࠦฟࠢࠣࠪਐ"))
			if dHPVDWfG4jX5e6QEo0CKh: Wf4vUZliHmBr3PL9bzx(HHoGx7Flus60(u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭਑"),VBlawK4mgHSyLEn8iqhUkz5,VBlawK4mgHSyLEn8iqhUkz5)
	return
def Bt6ZJeX0PS5IsOaTHM34W():
	dHPVDWfG4jX5e6QEo0CKh = XVmKrby29eCGMnlEY6jz0HNOR(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ਒"),LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"๋้ࠪࠦสา์าࠤๆ฿ไศ่ࠢืาࠦลฺัสำฬะࠠศๆหี๋อๅอࠢส่ำอีสࠢห์็ะࠠอๆหࠤฬ๊สฮัํฯฬะࠠ࠯࠰๋ࠣีอࠠศๆ่ืาࠦำ้ใࠣ๎ุฮศࠡฬะำ๏ัࠠโ๊ิ๎๊ࠥฬๆ์฼ࠤํ฾ววใࠣห้ฮั็ษ่ะࠥอไห์ࠣฮ฾ะๅะࠢ฼่๎ࠦๅา๊ิࠤํ่สࠡ็฼๎๋࠭ਓ"))
	if dHPVDWfG4jX5e6QEo0CKh:
		ee8c0jzrTntGSUdRJm.setSetting(QvgnCALNstmuUJiET(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡷ࡭ࡵࡲࡵࠩਔ"),hWGMqtBy4wuLaVcj)
		ee8c0jzrTntGSUdRJm.setSetting(mkHKSQvjWr5BTcM3wVY(u"ࠬࡧࡶ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮࠲ࡷ࡫ࡧࡶ࡮ࡤࡶࠬਕ"),hWGMqtBy4wuLaVcj)
		ee8c0jzrTntGSUdRJm.setSetting(S1SgCFYGJeMvfp5iZXK(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡲ࡯࡯ࡩࠪਖ"),hWGMqtBy4wuLaVcj)
		ee8c0jzrTntGSUdRJm.setSetting(wwPrSDa21lUh(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴࡭ࡦࡵࡶࡥ࡬࡫ࡳࠨਗ"),hWGMqtBy4wuLaVcj)
		ee8c0jzrTntGSUdRJm.setSetting(dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮ࡲࡷࡨࡷࡹ࡯࡯࡯ࡵࠪਘ"),hWGMqtBy4wuLaVcj)
		BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,A6dMB1FlgxVivJ2fk9C(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬਙ"),S1SgCFYGJeMvfp5iZXK(u"ࠪฮ๊ࠦๅิฯࠣษ฾ีวะษอࠤฬ๊ศา่ส้ัࠦวๅะสูฮࠦศ้ไอࠤั๊ศࠡษ็ฮาี๊ฬษอࠤ࠳࠴้ࠠี๋ๅࠥ๐โ้็ࠣห้ฮั็ษ่ะࠥอไร่ࠣฬฯำฯ๋อ๋ࠣีํࠠศๆศ฽ิอฯศฬࠣ࠲࠳่ࠦฤ์ูหࠥะอะ์ฮࠤํ฾ววใࠣห้ฮั็ษ่ะࠥอไห์ࠣฮ฾ะๅะࠢ฼่๎ࠦวๅ๊ๅฮࠬਚ"))
		CfKNTtIi3OABbWcPpdF(fEXMiAyG3ql4vKB)
	return
def emOlCn5JbvLQizYj():
	dHPVDWfG4jX5e6QEo0CKh = XVmKrby29eCGMnlEY6jz0HNOR(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,DJ1ICpbyR2(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧਛ"),gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠬํไࠡฬิ๎ิࠦแฺๆสࠤู๊อࠡฮ่๎฾ࠦลฺัสำฬะࠠศๆหี๋อๅอࠢ࠱࠲ࠥ๎ๅิฯࠣะ๊๐ูࠡ็็ๅฬะࠠศๆหี๋อๅอࠢส่็ี๊ๆหࠣ࠲࠳ࠦไไ์ࠣ๎฾๎ฯࠡษ็ฬึ์วๆฮࠣษ้๏ࠠฮษ็อࠥอไึใิࠤ࠳࠴๋ࠠ฻้๎ࠥะฬะ์าࠤฬ๊ศา่ส้ั่ࠦหืไ๎ึํู้๊ࠠ฽์ࠦศฮษ็อࠥอไๆื้฽ࠥอไห์ࠣ์฻฿็ศࠢส่๊ฮัๆฮࠣรࠦࠧࠧਜ"))
	if dHPVDWfG4jX5e6QEo0CKh:
		ZZIUbqTVz3GRnBu(fEXMiAyG3ql4vKB)
		Xe6bnfEPjgqJy5FIoRi0z2v8(vA0ImpguajeHKJ6P,VBlawK4mgHSyLEn8iqhUkz5,fEXMiAyG3ql4vKB)
		BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,dv0trJR7PwmKyxDYO52VLau8gEph(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩਝ"),S1SgCFYGJeMvfp5iZXK(u"ࠧห็ุ้ࠣำࠠอ็ํ฽ࠥอไๆๆไหฯࠦวๅไา๎๊ฯࠠๅๆหี๋อๅอࠢ࠱࠲ࠥ๎ูศัࠣห้ฮั็ษ่ะࠥหไฺ๊๋ࠢ฾๐ษࠡษ็ูๆืࠠ࠯࠰ࠣ์฻฿๊สࠢส่๊฻ๆฺࠩਞ"))
	return
def ffmBzj9LhYFqt():
	pMPR1Cc0usZ6nJTU(MM5Dx39f7ULhcJsRptzIowP,mkHKSQvjWr5BTcM3wVY(u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫਟ"),KNIvHPjUbhr(u"ࠩࡔ࡙ࡊ࡙ࡔࡊࡑࡑࡗࠬਠ"))
	QC27qaXRVojSpLy9K = DNjHn7Gxf3(fEXMiAyG3ql4vKB)
	RpUrqBQkJjeEVLsw9fZvD3 = NXMOzZjYsmS9pf
	qIMF0GWzTCtjQ5JYNnH = soMVfbr6WtpNlcSA+LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠪࠤ࠲࠳࠭࠮࠯ࠣ࠱࠲࠳࠭࠮ࠢ࠰࠱࠲࠳࠭ࠡ࠯࠰࠱࠲࠳ࠠ࠮࠯࠰࠱࠲ࠦࠧਡ")+YYSh2J6BIrsm8
	qow3a0BChy9m = NXMOzZjYsmS9pf+hXB0vKVQ5PRI91SDTprMdfuHEm4+dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠫࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠࠨਢ")+YYSh2J6BIrsm8+S1SgCFYGJeMvfp5iZXK(u"ࠬࡢ࡮࡝ࡰࠪਣ")
	for id,EPuMlX4RDWry9L,txuBWHAqlekYzCmJdFnXb7Og0oS,vIzgrEDLkOA,zzohWAV87dCuEJl0kxnX9Rs3wjMQ2G,reason in reversed(QC27qaXRVojSpLy9K):
		if id==QVDJLRlxNg127jMX(u"࠭࠰ࠨਤ"):
			ee2hxg3Z5aOVTrkmzNQRYPSJWc,bxzkd0chHfWBXa = vIzgrEDLkOA.split(MMizeNH0AKu(u"ࠧ࡝ࡰ࠾࠿ࠬਥ"))
			continue
		if RpUrqBQkJjeEVLsw9fZvD3!=NXMOzZjYsmS9pf: RpUrqBQkJjeEVLsw9fZvD3 += qow3a0BChy9m
		qkrP6CTSuMFneV0EfAUgxm1RoWt = QvgnCALNstmuUJiET(u"ࠨ࡝ࡕࡘࡑࡣࠧਦ")+soMVfbr6WtpNlcSA+id+A6dMB1FlgxVivJ2fk9C(u"ࠩࠣ࠾ࠥ࠭ਧ")+HHoGx7Flus60(u"ࠪหู้ฤศๆࠣ࠾ࠥ࠭ਨ")+YYSh2J6BIrsm8+txuBWHAqlekYzCmJdFnXb7Og0oS
		LwBM9FdHl8aE3iDh5IgzY02kZ = e2qDYgipPmTw4KvBLnochr(u"ࠫࡡࡴ࡛ࡓࡖࡏࡡࠬ਩")+soMVfbr6WtpNlcSA+OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠬอไอ๊สฬࠥࡀࠠࠨਪ")+YYSh2J6BIrsm8+vIzgrEDLkOA
		jdkSvGmCp0WOLoqJUYiTAZ = zyvJMtBhrw(u"࡛࠭ࡓࡖࡏࡡࠬਫ")+soMVfbr6WtpNlcSA+gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠧศๆั฻ศࠦ࠺ࠡࠩਬ")+YYSh2J6BIrsm8+zzohWAV87dCuEJl0kxnX9Rs3wjMQ2G
		UcBD7WEkIXbmzFJe8 = LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠨ࡞ࡱ࡟ࡗ࡚ࡌ࡞ࠩਭ")+soMVfbr6WtpNlcSA+OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠩสุ่ฮศࠡ࠼ࠣࠫਮ")+YYSh2J6BIrsm8+reason
		RpUrqBQkJjeEVLsw9fZvD3 += qkrP6CTSuMFneV0EfAUgxm1RoWt+LwBM9FdHl8aE3iDh5IgzY02kZ+NXMOzZjYsmS9pf+qIMF0GWzTCtjQ5JYNnH+NXMOzZjYsmS9pf+jdkSvGmCp0WOLoqJUYiTAZ+UcBD7WEkIXbmzFJe8+NXMOzZjYsmS9pf
	yBv4YaSomFrkejwgNA7pDnKudCz(gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠪࡶ࡮࡭ࡨࡵࠩਯ"),bxzkd0chHfWBXa,RpUrqBQkJjeEVLsw9fZvD3,JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺ࡟࡭ࡱࡱ࡫ࠬਰ"))
	return
def zto9f7QBjT1KDNFcOwr3ZRVIWi(file):
	if file==IlCq2uKjye3ZgSADFc: tEk13NXIlm = ITvnUAMXsyb4eO(u"่่ࠬศศ่ࠤฬ๊ๅโุ็อࠬ਱")
	elif file==UC78nrbeDHfwVAh2vt: tEk13NXIlm = OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"࠭โ้ษษ้ࠥศฮาࠢส่ๆ๐ฯ๋๊๊หฯ࠭ਲ")
	NN8u2B5iU3RMYheFy = jbQkTyxAerZR409gYFq(S1SgCFYGJeMvfp5iZXK(u"ࠧࡤࡧࡱࡸࡪࡸࠧਲ਼"),SqrG5mU3j96ldsFpExobw40TJY(u"ࠨ็ึัࠬ਴"),LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠩศู้ออࠨਵ"),mkHKSQvjWr5BTcM3wVY(u"ࠪาึ๎ฬࠨਸ਼"),A6dMB1FlgxVivJ2fk9C(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ਷"),mkHKSQvjWr5BTcM3wVY(u"ࠬํไࠡฬิ๎ิࠦลึๆสั๋ࠥไโࠢࠪਸ")+tEk13NXIlm+zyvJMtBhrw(u"࠭ࠠฤ็ࠣฮึ๐ฯࠡ็ึัࠥอไๆๆไࠤฤ࠭ਹ"))
	if NN8u2B5iU3RMYheFy==gDuGMR3z1aV6YdLmCpiO8Kl(u"࠴ഹ"):
		if WQvYkNg7SysPFLitlGEn6.path.exists(file):
			try: WQvYkNg7SysPFLitlGEn6.remove(file)
			except: pass
		BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,QVDJLRlxNg127jMX(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ਺"),LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠨฬ่ࠤู๊อࠡ็็ๅࠥ࠭਻")+tEk13NXIlm)
	elif NN8u2B5iU3RMYheFy==KBkxSYaz93pu1(u"࠶ഺ"):
		data = rpIZC2m6gEkAh(file)
		BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะ਼ࠬ"),S1SgCFYGJeMvfp5iZXK(u"ࠪฮ๊ࠦลึๆสั๋ࠥไโࠢࠪ਽")+tEk13NXIlm)
	return
def eUndmqOvYQo6KGrykfHX253b():
	if guSzmUCXDa1tQpY<e2qDYgipPmTw4KvBLnochr(u"࠷࠸഻"):
		jjEwJpmd2v0oxBRP1Dyu = JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"้๊ࠫริใࠣว๋ะࠠหีอาิ๋ࠠฦืาหึࠦใ้ัํࠤ็ี๊ๆࠢิๆ๊ࠦࠧਾ")+str(guSzmUCXDa1tQpY)+XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"่ࠬࠦๅ้ำหࠥอไใ๊สส๊ࠦวๅ็ุ์ึฯࠠๅษࠣฮ฾๋ไࠡ฻้ำ่ࠦ࠮้ࠡำ๋ࠥอไๆ์ีอࠥะๅไ่ๆࠤ๊์ࠠาฦํอ่่ࠥศศ่ࠤฬ๊แ๋ัํ์์อสࠡใํࠤอืๆศ็ฯࠤ฾๋วะࠢหุ่๊ࠠึ๊ิࠤอีไศ่๊ࠢࠥอไไฬสฬฮࠦ࠮ࠡๆศู้ออࠡษ็ู้้ไสࠢๅ้ࠥฮสฮัํฯࠥฮั็ษ่ะ้่ࠥะ์ࠣษ้๏ࠠฦ์ࠣษฺีวาࠢิๆ๊ํࠠฤ฻็ํ๋ࠥๆࠡ࠳࠻࠲࠵࠭ਿ")
		BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,KNIvHPjUbhr(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩੀ"),jjEwJpmd2v0oxBRP1Dyu)
		return
	Voz0n8C7vtfg26SR9DFuqKTE = MMk8qKvcJe4fQHm3EG7diBD5.executeJSONRPC(EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡓࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡉࡨࡸࡘ࡫ࡴࡵ࡫ࡱ࡫࡛ࡧ࡬ࡶࡧࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡵࡨࡸࡹ࡯࡮ࡨࠤ࠽ࠦࡱࡵ࡯࡬ࡣࡱࡨ࡫࡫ࡥ࡭࠰ࡶ࡯࡮ࡴࠢࡾࡿࠪੁ"))
	ssBcmRijhUKPzpVoYNwdLZvElJ = iAGOsUaS21t3RnQ64ejfY8EX5vMlCH([zyvJMtBhrw(u"ࠨࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊࠧੂ")])
	xu5GdvS1L2FQo6fP,qUnbPABVMKd1m,bbFJxOjHymSBqGIszw4f,itIaljhnCsd4vpKkWJ3GXbSA,kW3RuF0vPIhwB5DlzQ8rgA1MCNZY,wCNcpjHEXiOYokm,RR8VSbyetuKnjFGomhvD = ssBcmRijhUKPzpVoYNwdLZvElJ[OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠩࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄࠨ੃")]
	if xu5GdvS1L2FQo6fP or HHoGx7Flus60(u"ࠪࡷࡰ࡯࡮࠯࡯ࡨࡸࡷࡵࡰࡰ࡮࡬ࡷࡊࡓࡁࡅࠩ੄") not in str(Voz0n8C7vtfg26SR9DFuqKTE):
		BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ੅"),zyvJMtBhrw(u"ࠬอไใ๊สส๊ࠦวๅ็ุ์ึฯࠠห฻่่ࠥ็โุ่ࠢ฽ࠥาไะ่ࠢฮึ๎ศ้ๆึࠤ฾๋วะࠢ࠱ࠤ์ึ็ࠡษ็ๆํอฦๆࠢอ้่์ใࠡ็้ࠤึส๊สࠢๅ์ฬฬๅࠡสิ๊ฬ๋ฬࠡ฻่หิࠦศีๅ็ࠤฺ๎ัࠡสา่ฬࠦๅ็ࠢส่่ะวษหࠪ੆"))
		G62uf8ZSIzBE = llAKR46tqu0()
		if not G62uf8ZSIzBE: return
	c8PUgLdMzy9iWbIuONmJDoC56fAV1e(VBlawK4mgHSyLEn8iqhUkz5)
	return
def c8PUgLdMzy9iWbIuONmJDoC56fAV1e(showDialogs=VBlawK4mgHSyLEn8iqhUkz5):
	Voz0n8C7vtfg26SR9DFuqKTE = MMk8qKvcJe4fQHm3EG7diBD5.executeJSONRPC(SqrG5mU3j96ldsFpExobw40TJY(u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾࡙ࠧࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡈࡧࡷࡗࡪࡺࡴࡪࡰࡪ࡚ࡦࡲࡵࡦࠤ࠯ࠦ࡮ࡪࠢ࠻࠳࠯ࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡴࡧࡷࡸ࡮ࡴࡧࠣ࠼ࠥࡰࡴࡵ࡫ࡢࡰࡧࡪࡪ࡫࡬࠯ࡵ࡮࡭ࡳࠨࡽࡾࠩੇ"))
	if GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭ੈ") not in str(Voz0n8C7vtfg26SR9DFuqKTE):
		if showDialogs:
			BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ੉"),XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠩ็่ศูแࠡฮ๊หื้ࠠๅษࠣ๎ุะฮะ็ࠣะ้ีࠠๆฬิ์อ๎ไิࠢ฼้ฬีࠠ࠯ࠢส่็๎วว็ࠣห้๋ี้ำฬࠤฯ฿ๅๅࠢไๆ฼ࠦๅฺࠢฯ่ิࠦๅหำ๋ฬํ๊ำࠡ฻่หิࠦ࠮้ࠡำ๋ࠥอไใ๊สส๊ࠦสๆๅ้็๋ࠥๆࠡำว๎ฮࠦโ้ษษ้ࠥฮั็ษ่ะࠥ฿ๅศัࠣฬู้ไࠡื๋ีࠥฮฯๅษ้๋ࠣࠦวๅๅอหอฯࠧ੊"))
		return
	J5dVimgY31L8jXQ = WQvYkNg7SysPFLitlGEn6.path.join(W96kNDymei,QVDJLRlxNg127jMX(u"ࠪࡥࡩࡪ࡯࡯ࡵࠪੋ"),e2qDYgipPmTw4KvBLnochr(u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪੌ"),DJ1ICpbyR2(u"ࠬ࠽࠲࠱ࡲ੍ࠪ"),o1u5dij9UrcbXzVS8lwIWfKpnqM(u"࠭ࡍࡺࡘ࡬ࡨࡪࡵࡎࡢࡸ࠱ࡼࡲࡲࠧ੎"))
	if not WQvYkNg7SysPFLitlGEn6.path.exists(J5dVimgY31L8jXQ): return
	KYm6wdR9sybGfD5 = open(J5dVimgY31L8jXQ,QvgnCALNstmuUJiET(u"ࠧࡳࡤࠪ੏")).read()
	if H4qZ2hwilNJYTmCFEQyaSs98cPM0gR: KYm6wdR9sybGfD5 = KYm6wdR9sybGfD5.decode(a7VXeDU82IfQEnPZAdiT)
	K1jVa9HrzYO8mLh = trdVA0JvFaD.findall(jeAby54c02TgG8zuivonX91(u"ࠨ࠾ࡹ࡭ࡪࡽࡳ࠿ࠪ࡟ࡨ࠰࠲࡜ࡥ࠭࠯ࡠࡩ࠱ࠩ࠭ࠪ࠱࠮ࡄ࠯࠼࠰ࡸ࡬ࡩࡼࡹ࠾ࠨ੐"),KYm6wdR9sybGfD5,trdVA0JvFaD.DOTALL)
	cjpTvaMiGysDFYJZLrl3NSPt6Qo,Ng0a3JAbVzDSM = K1jVa9HrzYO8mLh[ybdv7XcT3lxF6QezULwCAGk]
	dT4hyk9fX7Dwzx2PqeE = hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠩ࠿ࡺ࡮࡫ࡷࡴࡀࠪੑ")+cjpTvaMiGysDFYJZLrl3NSPt6Qo+HHoGx7Flus60(u"ࠪ࠰ࠬ੒")+Ng0a3JAbVzDSM+CnbBKmtF1x84q7AW(u"ࠫࡁ࠵ࡶࡪࡧࡺࡷࡃ࠭੓")
	if showDialogs:
		GmQbiqjDO2AvtY0 = MMk8qKvcJe4fQHm3EG7diBD5.getInfoLabel(hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡘ࡬ࡩࡼࡳ࡯ࡥࡧࠪ੔"))
		if GmQbiqjDO2AvtY0==rwQN9AKhLCuMfHxjlbX0U(u"࠭ࡅࡎࡃࡇࠤࡑ࡯ࡳࡵࠩ੕"): cqvXhUjC7sSYB6ie5aoK4rxFDGbN = hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠧใ๊สส๊ࠦวๅๅอหอฯࠧ੖")
		elif GmQbiqjDO2AvtY0==jeAby54c02TgG8zuivonX91(u"ࠨࡇࡐࡅࡉࠦࡇࡢ࡮࡯ࡩࡷࡿࠧ੗"): cqvXhUjC7sSYB6ie5aoK4rxFDGbN = xcChIL13BpR8WArNt9Pl0So(u"ࠩๅ์ฬฬๅࠡษ็ูํืࠧ੘")
		else: cqvXhUjC7sSYB6ie5aoK4rxFDGbN = jeAby54c02TgG8zuivonX91(u"ࠪๆํอฦๆࠢฦาึ๏ࠧਖ਼")
		NN8u2B5iU3RMYheFy = jbQkTyxAerZR409gYFq(LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫਗ਼"),JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"่่ࠬศศ่ࠤศิั๊ࠩਜ਼"),A6dMB1FlgxVivJ2fk9C(u"࠭โ้ษษ้ࠥอไไฬสฬฮ࠭ੜ"),QVDJLRlxNg127jMX(u"ࠧใ๊สส๊ࠦวๅื๋ีࠬ੝"),S1SgCFYGJeMvfp5iZXK(u"ࠨษ้ฮࠥำวๅ์สࠤฯูสฯั่ࠤࠬਫ਼")+cqvXhUjC7sSYB6ie5aoK4rxFDGbN,e2qDYgipPmTw4KvBLnochr(u"ࠩส๊ฯࠦวๅฤ้ࠤฯูสฯั่ࠤฬ๊ลึัสีࠥอไฤะํี๊ࠥฬๅั้ࠣฯื่ษ๊็ืࠥ฿ๅศัࠣ࠲ࠥ๎็ัษ้ࠣ฾์ว่ࠢส๊่ࠦสิฬฺ๎฾ࠦวิฬัำฬ๋ࠠศๆๅ์ฬฬๅࠡษ็ฺ้๎ัสࠢหำ้อࠠๆ่ࠣๆํอฦๆࠢส่่ะวษหࠣ࠲ࠥ๎รุ๋สࠤฯูสุ์฼ࠤส๐โศใ๊หࠥ็๊ࠡลํࠤํ่สࠡฬืหฦࠦ࡜࡯࡞ࡱࠤࠬ੟")+soMVfbr6WtpNlcSA+zyvJMtBhrw(u"ࠪࠤศิสาࠢส่ว์ࠠ็๊฼ࠤฬ๊โ้ษษ้ࠥอไห์ࠣฮึ๐ฯࠡลึฮำีวๆ้สࠤฤࠧࠧ੠")+YYSh2J6BIrsm8)
		if NN8u2B5iU3RMYheFy==o1u5dij9UrcbXzVS8lwIWfKpnqM(u"࠱഼"): bbmjgfVE8OFTQse7WZazn = xcChIL13BpR8WArNt9Pl0So(u"ࠫࡊࡓࡁࡅࠢࡏ࡭ࡸࡺࠧ੡")
		elif NN8u2B5iU3RMYheFy==GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"࠳ഽ"): bbmjgfVE8OFTQse7WZazn = gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠬࡋࡍࡂࡆࠣࡋࡦࡲ࡬ࡦࡴࡼࠫ੢")
		else: bbmjgfVE8OFTQse7WZazn = hWGMqtBy4wuLaVcj
	else:
		GmQbiqjDO2AvtY0 = ee8c0jzrTntGSUdRJm.getSetting(e2qDYgipPmTw4KvBLnochr(u"࠭ࡡࡷ࠰ࡰࡽࡸࡱࡩ࡯࠰ࡹ࡭ࡪࡽ࡭ࡰࡦࡨࠫ੣"))
		if   GmQbiqjDO2AvtY0==hWGMqtBy4wuLaVcj: NN8u2B5iU3RMYheFy = SqrG5mU3j96ldsFpExobw40TJY(u"࠲ാ")
		elif GmQbiqjDO2AvtY0==GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠧࡆࡏࡄࡈࠥࡒࡩࡴࡶࠪ੤"): NN8u2B5iU3RMYheFy = A6dMB1FlgxVivJ2fk9C(u"࠴ി")
		elif GmQbiqjDO2AvtY0==o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠨࡇࡐࡅࡉࠦࡇࡢ࡮࡯ࡩࡷࡿࠧ੥"): NN8u2B5iU3RMYheFy = KBkxSYaz93pu1(u"࠶ീ")
		bbmjgfVE8OFTQse7WZazn = GmQbiqjDO2AvtY0
	if   NN8u2B5iU3RMYheFy==CnbBKmtF1x84q7AW(u"࠵ു"): sa5BZR7L3KN2Or8l1d6SMPmfxiV = JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠩ࠸࠹࠱࠻࠴࠵࠮࠸࠹࠺࠭੦")
	elif NN8u2B5iU3RMYheFy==HHoGx7Flus60(u"࠷ൂ"): sa5BZR7L3KN2Or8l1d6SMPmfxiV = HHoGx7Flus60(u"ࠪ࠹࠹࠺ࠬ࠶࠷࠸࠰࠺࠻ࠧ੧")
	elif NN8u2B5iU3RMYheFy==sULh4NjakzI8He7xJCMGrql(u"࠲ൃ"): sa5BZR7L3KN2Or8l1d6SMPmfxiV = XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠫ࠺࠻࠵࠭࠷࠸࠰࠺࠺࠴ࠨ੨")
	else: return
	ee8c0jzrTntGSUdRJm.setSetting(EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠬࡧࡶ࠯࡯ࡼࡷࡰ࡯࡮࠯ࡸ࡬ࡩࡼࡳ࡯ࡥࡧࠪ੩"),bbmjgfVE8OFTQse7WZazn)
	KDrnPT1ZGSewpm7BIJE9NWXjFdli6 = zyvJMtBhrw(u"࠭࠼ࡷ࡫ࡨࡻࡸࡄࠧ੪")+sa5BZR7L3KN2Or8l1d6SMPmfxiV+jeAby54c02TgG8zuivonX91(u"ࠧ࠭ࠩ੫")+Ng0a3JAbVzDSM+zyvJMtBhrw(u"ࠨ࠾࠲ࡺ࡮࡫ࡷࡴࡀࠪ੬")
	ZkO6hteNg43 = KYm6wdR9sybGfD5.replace(dT4hyk9fX7Dwzx2PqeE,KDrnPT1ZGSewpm7BIJE9NWXjFdli6)
	if H4qZ2hwilNJYTmCFEQyaSs98cPM0gR: ZkO6hteNg43 = ZkO6hteNg43.encode(a7VXeDU82IfQEnPZAdiT)
	open(J5dVimgY31L8jXQ,MMizeNH0AKu(u"ࠩࡺࡦࠬ੭")).write(ZkO6hteNg43)
	KteLZCbM8W0FqE2OBx1(pGYKHZgqFX3B,QVDJLRlxNg127jMX(u"ࠪ࠲ࡡࡺࡓ࡬࡫ࡱࠤࡉ࡫ࡦࡢࡷ࡯ࡸࠥ࡜ࡩࡦࡹࡶ࠾ࠥࡡࠠࠨ੮")+sa5BZR7L3KN2Or8l1d6SMPmfxiV+zyvJMtBhrw(u"ࠫࠥࡣࠧ੯"))
	if showDialogs: MMk8qKvcJe4fQHm3EG7diBD5.executebuiltin(XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠬࡘࡥ࡭ࡱࡤࡨࡘࡱࡩ࡯ࠪࠬࠫੰ"))
	return
def kkOY3Ffzs8RD():
	dHPVDWfG4jX5e6QEo0CKh = XVmKrby29eCGMnlEY6jz0HNOR(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,o1u5dij9UrcbXzVS8lwIWfKpnqM(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩੱ"),GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠧษำ้ห๊าฺࠠ็สำࠥ็ุ๊่่่๊ࠢษࠡ฻้ำ่ࠦ࠮࠯࠰ࠣษ๊อࠠฤๆศูิอัࠡไา๎๊ࠦ࠮࠯࠰ࠣวํࠦว็ฬ้๊ࠣ์ฺ่่๊ࠢࠥอำหะาห๊ࠦวๅสิ๊ฬ๋ฬࠡ࠰࠱࠲ࠥษ่ࠡๆา๎่ࠦๅีๅ็อࠥษฮา๋ࠣฮำ฻ࠠอ้สึ่ࠦร็ฬࠣ์้อࠠหะุࠤอ่๊สࠢั่็ࠦวๅๆ๊ࠤࡡࡴ࡜࡯ࠢะหํ๊ࠠหฯา๎ะࠦวๅสิ๊ฬ๋ฬࠡล๋ࠤฬะีๅࠢหห้๋ศา็ฯࠤู้๋าใฬࠤุฮศࠡษ็ู้้ไสࠢ฼๊ิ้ࠠ࠯࠰࠱ࠤ์๊ࠠหำํำࠥ็อึࠢส่ฯำฯ๋อสฮࠥอไร่ࠣรࠬੲ"))
	if dHPVDWfG4jX5e6QEo0CKh==DJ1ICpbyR2(u"࠲ൄ"): QYpFblwDT5fzUaMWgcurv8qHXC4ek()
	return
def qcRILexpUFD6dMmGW():
	BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫੳ"),FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"๊ࠩิฬࠦวๅ็๋ๆ฾ࠦๅ฻ๆๅࠤ๊์ࠠศๆู่ิื้ࠠ฼ํีู๋ࠥา๊ไࠤ๊ะ๊ࠡ์ิะ฾ࠦไๅ฻่่ࠬੴ"))
	return
def FNMdbyGSQCHAzO61KtwjJXqRD2():
	qkrP6CTSuMFneV0EfAUgxm1RoWt = soMVfbr6WtpNlcSA+SqrG5mU3j96ldsFpExobw40TJY(u"ࠪฮ฾ีวะࠢื๎฾ฯࠠรๆ้ࠣา๋ฯࠡๆึ๊ฮࠦ࠲࠱࠴࠴ࠤ࠿ࠦࠧੵ")+YYSh2J6BIrsm8
	qkrP6CTSuMFneV0EfAUgxm1RoWt += EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠫฬ๊ๅ้ไ฼ࠤศีๆศ้ࠣๅ๏ํࠠฦฯุหห๐ษࠡๆ฼ำิࠦวๅึํ฽ฮࠦแ๋ࠢส่฾อไๆࠢอ้ࠥาๅฺ้สࠤ๊์ࠠอ็ํ฽ࠥอไๆืสำึࠦวๅ็อ์ๆืษࠡใํࠤฬ๊ล็ฬิ๊ฯࠦวๅไา๎๊ฯ้ࠠษ็ะิ๐ฯสࠢส่า้่ๆ์ฬࠤํอไ฻์ิࠤา้่ๆ์ฬࠤํ๋ๆࠡฮ่๎฾ࠦฯ้ๆࠣห้฿วๅ็ࠣฯ๊ࠦสๆࠢอ์า๐ฯ่ษࠣ์าูวษࠢส่๊฿ฯๅࠢะือࠦำไษ้ࠤิ๎ไࠡษ็฽ฬ๊ๅࠡๆึ๊ฮࠦ࠲࠱࠴࠴ࠤํํ๊ࠡษ็ษา฻วว์ฬࠤฬ๊รฮัฮࠤํอไฤึ่่ࠥอไห์ࠣฮู๊ࠦๆๆ๊หࠥ็๊ࠡษ็ื๋๎วหࠢส่฾ฺัสࠢส่๊อึ๋หࠪ੶")
	qkrP6CTSuMFneV0EfAUgxm1RoWt += NXMOzZjYsmS9pf+soMVfbr6WtpNlcSA+jeAby54c02TgG8zuivonX91(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡴࡪࡰࡼ࠲ࡨࡩ࠯ࡴࡪ࡬ࡥࡨࡵࡵ࡯ࡶࠪ੷")+YYSh2J6BIrsm8
	LwBM9FdHl8aE3iDh5IgzY02kZ = soMVfbr6WtpNlcSA+e2qDYgipPmTw4KvBLnochr(u"࠭ศา่ส้ัࠦิา์ฺࠤฬ๊ๅิๆ่ࠤ࠿ࠦࠧ੸")+YYSh2J6BIrsm8
	LwBM9FdHl8aE3iDh5IgzY02kZ += QVDJLRlxNg127jMX(u"่๊ࠧࠣ฽ออัสࠢ฼๊ࠥฮั็ษ่ะࠥ๐่โำ้ࠣ฾๊่ๆษอࠤาูวษ์ฬࠤ่ั๊าหࠣฮ์๋ࠠอ็ํ฽ࠥอไๆี็้๏์ࠠๆอ็ࠤศ๎โศฬࠣห้฻ไศหࠣ์ศ๎โศฬࠣห้้ำ้ใࠣ์ฬ๊ฮิ๊ไࠤํฺใๅࠢส่็๋ั๊ࠡฦ์็อสࠡษ็ๆ๊ื้ࠠลํฺฬ๊้ࠦใิࠤึส๊สࠢส่์๊วๅࠢไ๎ࠥาๅ๋฻ࠣำํ๊ࠠศๆ฼ห้๋้ࠠลํฺฬࠦแ๋้ࠣฮ็๎๊ๆ่ࠢ๎้อฯ๋๋๋ࠢัื๊๊ࠡไ๎์ࠦรุ๋สࠤอำห๊ࠡๅีฬวษࠡษ็ๆึศๆ๊ࠡฦ๎฻อࠠโ์๊ࠤฬูสฯษิอࠥ๎สโษว่ࠥ๎แ๋้ࠣว็๎วๅุ่๊ࠢ๎ศสࠢ็่ศ๋วๆࠢ฼่๏่ࠦฤ็๋ีࠥษฮา๋ࠣฮ์๋ࠠไๆุ้๊ࠣๅࠡ࠰ࠣห้ฮั็ษ่ะ๋ࠥให๊หࠤอฺ๊สࠢฯหๆอࠠิๅิฬฯ่๋ࠦีอาิ๋ࠠ็ฺส้ࠥ๎๊็ั๋ึࠥะอหࠢห๎หฯ้ࠠ์้ำํุࠠไษฯ๎ฯ่ࠦๆะุูࠥ็โุࠢ็วัําสࠢส่ํ๐ๆะ๊ีࠤ࠳ࠦวๅ็๋ๆ฾ࠦวๅำึ้๏ࠦไๅสิ๊ฬ๋ฬ้๋ࠡࠫ੹")
	LwBM9FdHl8aE3iDh5IgzY02kZ += NXMOzZjYsmS9pf+soMVfbr6WtpNlcSA+LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡷ࡭ࡳࡿ࠮ࡤࡥ࠲ࡱࡺࡹ࡬ࡪ࡯ࡵࡹࡱ࡫ࡲࠨ੺")+YYSh2J6BIrsm8
	jjEwJpmd2v0oxBRP1Dyu = wwPrSDa21lUh(u"ࠩ࡞ࡖ࡙ࡒ࡝ࠨ੻")+qkrP6CTSuMFneV0EfAUgxm1RoWt+FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠪࡠࡳࡢ࡮࡝ࡰ࡞ࡖ࡙ࡒ࡝ࠨ੼")+LwBM9FdHl8aE3iDh5IgzY02kZ
	yBv4YaSomFrkejwgNA7pDnKudCz(wwPrSDa21lUh(u"ࠫࡷ࡯ࡧࡩࡶࠪ੽"),hWGMqtBy4wuLaVcj,jjEwJpmd2v0oxBRP1Dyu)
	return
def DC4GvtpUbZJ38mfMIRijkY(aJb19RQ7MVp):
	bXjeBx6vV52PfJpcKah0kUGiSsWC(lke5D6CpaAXPdEZyrBSw7T)
	QC27qaXRVojSpLy9K = DNjHn7Gxf3(aJb19RQ7MVp)
	stmA3SGjD6b(gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠬࡊࡏࡏࡃࡗࡍࡔࡔࡓࠨ੾"))
	id,EPuMlX4RDWry9L,txuBWHAqlekYzCmJdFnXb7Og0oS,vIzgrEDLkOA,zzohWAV87dCuEJl0kxnX9Rs3wjMQ2G,reason = QC27qaXRVojSpLy9K[ybdv7XcT3lxF6QezULwCAGk]
	ee2hxg3Z5aOVTrkmzNQRYPSJWc,bxzkd0chHfWBXa = vIzgrEDLkOA.split(XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"࠭࡜࡯࠽࠾ࠫ੿"))
	LwBM9FdHl8aE3iDh5IgzY02kZ,jdkSvGmCp0WOLoqJUYiTAZ,UcBD7WEkIXbmzFJe8 = zzohWAV87dCuEJl0kxnX9Rs3wjMQ2G.split(XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠧ࡝ࡰ࠾࠿ࠬ઀"))
	ueGkbOdZDPm0j = VBlawK4mgHSyLEn8iqhUkz5
	while ueGkbOdZDPm0j:
		uCQFKYE8Njlyf7aG0eni1k = jbQkTyxAerZR409gYFq(hWGMqtBy4wuLaVcj,ITvnUAMXsyb4eO(u"ࠨะิ์ั࠭ઁ"),dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠩศีุอไࠡำึห้ฯࠠๅๆ่ฬึ๋ฬࠨં"),HHoGx7Flus60(u"ࠪๆฬฬๅสࠢส่ฯฮัฺษอࠫઃ"),LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"้ࠫห๊ใษไࠤฬ๊ลฺๆส๊ฬะࠠ࠻ࠢࠣฮอืูࠡล๋ࠤฬ๋ำฮࠢส่อืๆศ็ฯࠫ઄"),LwBM9FdHl8aE3iDh5IgzY02kZ)
		if uCQFKYE8Njlyf7aG0eni1k==o1u5dij9UrcbXzVS8lwIWfKpnqM(u"࠴൅"): hoeusf9O0kAYKiZW3cqjUlXVE = jbQkTyxAerZR409gYFq(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠬ฿่ะหࠪઅ"),hWGMqtBy4wuLaVcj,KNIvHPjUbhr(u"࠭ๅษัฦࠤฬ๊สษำ฼ࠤ฿๐ัࠡไสฬ้ࠦไๅ่ๅหู࠭આ"),jdkSvGmCp0WOLoqJUYiTAZ,xcChIL13BpR8WArNt9Pl0So(u"ࠧࡤࡱࡱࡪ࡮ࡸ࡭ࡠࡵࡰࡥࡱࡲࡦࡰࡰࡷࠫઇ"))
		elif uCQFKYE8Njlyf7aG0eni1k==EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"࠴െ"): mag0BJDLNYjc1iKkpl8()
		else: ueGkbOdZDPm0j = fEXMiAyG3ql4vKB
	if aJb19RQ7MVp: CfKNTtIi3OABbWcPpdF(fEXMiAyG3ql4vKB)
	return
def ZZIUbqTVz3GRnBu(showDialogs):
	dHPVDWfG4jX5e6QEo0CKh = VBlawK4mgHSyLEn8iqhUkz5
	if showDialogs: dHPVDWfG4jX5e6QEo0CKh = XVmKrby29eCGMnlEY6jz0HNOR(KBkxSYaz93pu1(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨઈ"),hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠩึศฬ๊ࠧઉ"),ITvnUAMXsyb4eO(u"๋้ࠪࠦร็ฬ้ࠣฯษใะ๋ࠢฮึ๐ฯࠡ็ึัࠥ๎สึใํีࠥาๅ๋฻ࠣษ฾ีวะษอࠤอืๆศ็ฯࠤ฾๋วะࠢ็่ๆ๐ฯ๋๊๊หฯࠦวๅ฻ิฬ๏ฯࠠ࠯ࠢะ๎ะࠦสฺ๊าࠤัฺ๋๊ࠢส่ส฿ฯศัสฮࠥหไฺ๊๋ࠢ฾๐ษࠡฬฮฬ๏ะࠠศๆหี๋อๅอࠢยࠫઊ"))
	if dHPVDWfG4jX5e6QEo0CKh:
		G62uf8ZSIzBE = VBlawK4mgHSyLEn8iqhUkz5
		if WQvYkNg7SysPFLitlGEn6.path.exists(muykopvadEFSL85fRCA1ND):
			try: WQvYkNg7SysPFLitlGEn6.remove(muykopvadEFSL85fRCA1ND)
			except: G62uf8ZSIzBE = fEXMiAyG3ql4vKB
		if showDialogs:
			if G62uf8ZSIzBE: BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠫฯ๋ࠠษ่ฯหาࠦๅิฯࠣ์ฯ฻แ๋ำ้้ࠣ็ࠠฦ฻าหิอสࠡสิ๊ฬ๋ฬࠡ฻่หิࠦไๅใํำ๏๎็ศฬࠣห้฿ัษ์ฬࠫઋ"))
			else: BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"๊ࠬไฤีไࠤๆฺไหࠢ฼้้๐ษࠡ็ึั๋ࠥไโࠢส่ส฿ฯศัสฮࠬઌ"))
	return
def RLC7QV5s28uoavEkfHeTn9NqYwyz():
	qRXHeAKQwYDLP()
	KSFJehNMWbIEZrmCU6u = ee8c0jzrTntGSUdRJm.getSetting(XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰࡫ࡸࡹࡶࡣࡢࡥ࡫ࡩࠬઍ"))
	jjEwJpmd2v0oxBRP1Dyu = {}
	jjEwJpmd2v0oxBRP1Dyu[dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠧࡂࡗࡗࡓࠬ઎")] = HHoGx7Flus60(u"ࠨษ็็ฬฺࠠศๆอ่็อฦ๋ࠢํ฽๊๊ࠧએ")
	jjEwJpmd2v0oxBRP1Dyu[mkHKSQvjWr5BTcM3wVY(u"ࠩࡖࡘࡔࡖࠧઐ")] = A6dMB1FlgxVivJ2fk9C(u"ࠪห้้วี่ࠢฮํ่แࠡฬ่ห๊อ้ࠠสส่่อๅๅࠩઑ")
	jjEwJpmd2v0oxBRP1Dyu[KBkxSYaz93pu1(u"ࠫࡑࡏࡍࡊࡖࡈࡈࠬ઒")] = EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"้ࠬวีࠢฯำฬࠦโึ์ิࠤฬ๊ๅะ๋ࠣ࠲ࠥ࠭ઓ")+str(gVRmOBQA8Lse7aojcU5nSl4G2N/LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"࠺࠵േ"))+QvgnCALNstmuUJiET(u"࠭ࠠะไํๆฮࠦแใูࠪઔ")
	CnI1jv4LZifPbNqOgM93Hw7EKVFs = jjEwJpmd2v0oxBRP1Dyu[KSFJehNMWbIEZrmCU6u]
	NN8u2B5iU3RMYheFy = jbQkTyxAerZR409gYFq(hWGMqtBy4wuLaVcj,JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠧไษืࠤࠬક")+str(gVRmOBQA8Lse7aojcU5nSl4G2N/GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"࠻࠶ൈ"))+e2qDYgipPmTw4KvBLnochr(u"ࠨࠢาๆ๏่ษࠨખ"),HHoGx7Flus60(u"ࠩอุ฿๐ไࠡฬ็ๆฬฬ๊ࠨગ"),sULh4NjakzI8He7xJCMGrql(u"ࠪษ๏่วโࠢๆห๊๊ࠧઘ"),CnI1jv4LZifPbNqOgM93Hw7EKVFs,DJ1ICpbyR2(u"ࠫ์๊ࠠหำํำࠥอำหะาห๊ࠦวๅๅสุࠥอไัๅํࠤฬ๊สๅไสส๏ࠦรๆࠢอี๏ีࠠฦ์ๅหๆࠦวๅๅสุࠥฮวๅๅส้้ࠦรๆࠢอี๏ีࠠไษืࠤ฾๋ั่ࠢๅู๏ืࠠอัสࠤฤࠧࠧઙ"))
	if NN8u2B5iU3RMYheFy==QvgnCALNstmuUJiET(u"࠶൉"): CELSRh2VQuU6JdFm7Ts8HgNf1cv = sULh4NjakzI8He7xJCMGrql(u"ࠬࡒࡉࡎࡋࡗࡉࡉ࠭ચ")
	elif NN8u2B5iU3RMYheFy==wwPrSDa21lUh(u"࠱ൊ"): CELSRh2VQuU6JdFm7Ts8HgNf1cv = e2qDYgipPmTw4KvBLnochr(u"࠭ࡁࡖࡖࡒࠫછ")
	elif NN8u2B5iU3RMYheFy==XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"࠳ോ"): CELSRh2VQuU6JdFm7Ts8HgNf1cv = LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠧࡔࡖࡒࡔࠬજ")
	else: CELSRh2VQuU6JdFm7Ts8HgNf1cv = hWGMqtBy4wuLaVcj
	if CELSRh2VQuU6JdFm7Ts8HgNf1cv:
		ee8c0jzrTntGSUdRJm.setSetting(gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲࡭ࡺࡴࡱࡥࡤࡧ࡭࡫ࠧઝ"),CELSRh2VQuU6JdFm7Ts8HgNf1cv)
		UJNrw4z0AoKquZL2PaBsECHpk9 = jjEwJpmd2v0oxBRP1Dyu[CELSRh2VQuU6JdFm7Ts8HgNf1cv]
		BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,UJNrw4z0AoKquZL2PaBsECHpk9)
	return
def xas43yPL7epf9B():
	jjEwJpmd2v0oxBRP1Dyu = {}
	jjEwJpmd2v0oxBRP1Dyu[FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠩࡄ࡙࡙ࡕࠧઞ")] = FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠪื๏ืแาࠢࡇࡒࡘࠦวๅฬ็ๆฬฬ๊ࠡ์฼้้ࡀࠠࠨટ")
	jjEwJpmd2v0oxBRP1Dyu[FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠫࡆ࡙ࡋࠨઠ")] = JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ู๊ࠬาใิࠤࡉࡔࡓࠡีํ฽๊๊ࠠษ฻าࠤฬ๊ำๆษะࠤ้ํ࠺ࠡࠩડ")
	jjEwJpmd2v0oxBRP1Dyu[GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"࠭ࡓࡕࡑࡓࠫઢ")] = xcChIL13BpR8WArNt9Pl0So(u"ࠧิ์ิๅึࠦࡄࡏࡕ้ࠣฯ๎โโࠢอ้ฬ๋ว๊ࠡหห้้วๆๆࠪણ")
	xTKMUvIzDJjb8QZprG2FR = ee8c0jzrTntGSUdRJm.getSetting(LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠨࡣࡹ࠲ࡩࡴࡳࠨત"))
	KSFJehNMWbIEZrmCU6u = ee8c0jzrTntGSUdRJm.getSetting(mkHKSQvjWr5BTcM3wVY(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡦࡱࡷࠬથ"))
	CnI1jv4LZifPbNqOgM93Hw7EKVFs = jjEwJpmd2v0oxBRP1Dyu[KSFJehNMWbIEZrmCU6u]+xTKMUvIzDJjb8QZprG2FR
	NN8u2B5iU3RMYheFy = jbQkTyxAerZR409gYFq(hWGMqtBy4wuLaVcj,dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠪฮูเ๊ๅࠢ฼๊ิࠦวๅ็๋หๆ่ษࠨદ"),e2qDYgipPmTw4KvBLnochr(u"ࠫฯฺฺ๋ๆࠣฮ้่วว์ࠪધ"),QvgnCALNstmuUJiET(u"ࠬห๊ใษไࠤ่อๅๅࠩન"),CnI1jv4LZifPbNqOgM93Hw7EKVFs,mkHKSQvjWr5BTcM3wVY(u"࠭ำ๋ำไีࠥࡊࡎࡔ๊ࠢ์ࠥา็ศิࠣๅ๏ࠦวๅว้ฮึ์๊หࠢํๆํ๋ࠠษฬะ์๏๊ࠠฤี่หฦࠦวๅ็๋ห็฿้ࠠษ็ื๏ืแาษอࠤส๊้ࠡลิๆฬ๋้ࠠ฻้ำࠥฮูืࠢส่๋อำࠡ์ๅ์๊ࠦศฮฮหࠤํ๋ๆฺ๋ࠢั฻ืࠠษ฻ูࠤฬ๊ๅ้ษๅ฽ࠥ࠴ࠠๅฬื฾๏๊ࠠิ์ิๅึࠦࡄࡏࡕࠣๆ๊ࠦศศะอ๎ฬืࠠศๆึ๎ึ็ัࠡษ็้๋อำษࠢฦ์่ࠥๅࠡสศ๎็อแ่ࠢหห้้วๆๆࠪ઩"))
	if NN8u2B5iU3RMYheFy==MMizeNH0AKu(u"࠲ൌ"): CELSRh2VQuU6JdFm7Ts8HgNf1cv = e2qDYgipPmTw4KvBLnochr(u"ࠧࡂࡕࡎࠫપ")
	elif NN8u2B5iU3RMYheFy==QVDJLRlxNg127jMX(u"࠴്"): CELSRh2VQuU6JdFm7Ts8HgNf1cv = wwPrSDa21lUh(u"ࠨࡃࡘࡘࡔ࠭ફ")
	elif NN8u2B5iU3RMYheFy==MMizeNH0AKu(u"࠶ൎ"): CELSRh2VQuU6JdFm7Ts8HgNf1cv = LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠩࡖࡘࡔࡖࠧબ")
	if NN8u2B5iU3RMYheFy in [rwQN9AKhLCuMfHxjlbX0U(u"࠶൐"),e2qDYgipPmTw4KvBLnochr(u"࠶൏")]:
		dHPVDWfG4jX5e6QEo0CKh = XVmKrby29eCGMnlEY6jz0HNOR(EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠪࡧࡪࡴࡴࡦࡴࠪભ"),XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ุࠫ๐ัโำ࠽ࠤࠬમ")+vIDJ3z8NTlStsfnW4MOQC20Bo[bXukYxQ4aHw],HHoGx7Flus60(u"ู๊ࠬาใิ࠾ࠥ࠭ય")+vIDJ3z8NTlStsfnW4MOQC20Bo[ybdv7XcT3lxF6QezULwCAGk],hWGMqtBy4wuLaVcj,LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"࠭รฯฬสีู๊ࠥาใิࠤࡉࡔࡓࠡษ็้๋อำษࠢ็็ࠬર"))
		if dHPVDWfG4jX5e6QEo0CKh==MMizeNH0AKu(u"࠱൑"): wSgeWaKIAZb32C = vIDJ3z8NTlStsfnW4MOQC20Bo[ybdv7XcT3lxF6QezULwCAGk]
		else: wSgeWaKIAZb32C = vIDJ3z8NTlStsfnW4MOQC20Bo[bXukYxQ4aHw]
	elif NN8u2B5iU3RMYheFy==JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"࠳൒"): wSgeWaKIAZb32C = hWGMqtBy4wuLaVcj
	else: CELSRh2VQuU6JdFm7Ts8HgNf1cv = hWGMqtBy4wuLaVcj
	if CELSRh2VQuU6JdFm7Ts8HgNf1cv:
		ee8c0jzrTntGSUdRJm.setSetting(FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡹࡸ࡫ࡤ࡯ࡵࠪ઱"),CELSRh2VQuU6JdFm7Ts8HgNf1cv)
		ee8c0jzrTntGSUdRJm.setSetting(KBkxSYaz93pu1(u"ࠨࡣࡹ࠲ࡩࡴࡳࠨલ"),wSgeWaKIAZb32C)
		UJNrw4z0AoKquZL2PaBsECHpk9 = jjEwJpmd2v0oxBRP1Dyu[CELSRh2VQuU6JdFm7Ts8HgNf1cv]+wSgeWaKIAZb32C
		BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,UJNrw4z0AoKquZL2PaBsECHpk9)
	return
def LceZoal2ANE3u():
	KSFJehNMWbIEZrmCU6u = ee8c0jzrTntGSUdRJm.getSetting(e2qDYgipPmTw4KvBLnochr(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡲࡵࡳࡽࡿࠧળ"))
	jjEwJpmd2v0oxBRP1Dyu = {}
	jjEwJpmd2v0oxBRP1Dyu[OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠪࡅ࡚࡚ࡏࠨ઴")] = dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠫฬ๊ศา๊ๆื๏ࠦวๅฬ็ๆฬฬ๊ࠡฮส๋ืࠦไๅ฻่่ࠬવ")
	jjEwJpmd2v0oxBRP1Dyu[mkHKSQvjWr5BTcM3wVY(u"ࠬࡇࡓࡌࠩશ")] = S1SgCFYGJeMvfp5iZXK(u"࠭วๅสิ์ู่๊ࠡีํ฽๊๊ࠠษ฻าࠤฬ๊ำๆษะࠤ้ํࠧષ")
	jjEwJpmd2v0oxBRP1Dyu[S1SgCFYGJeMvfp5iZXK(u"ࠧࡔࡖࡒࡔࠬસ")] = LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠨษ็ฬึ๎ใิ์้ࠣฯ๎โโࠢอ้ฬ๋ว๊ࠡหห้้วๆๆࠪહ")
	CnI1jv4LZifPbNqOgM93Hw7EKVFs = jjEwJpmd2v0oxBRP1Dyu[KSFJehNMWbIEZrmCU6u]
	NN8u2B5iU3RMYheFy = jbQkTyxAerZR409gYFq(hWGMqtBy4wuLaVcj,xcChIL13BpR8WArNt9Pl0So(u"ࠩอุ฿๐ไࠡ฻้ำࠥอไๆ๊สๅ็ฯࠧ઺"),MMizeNH0AKu(u"ࠪฮูเ๊ๅࠢอ่็อฦ๋ࠩ઻"),LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠫส๐โศใࠣ็ฬ๋ไࠨ઼"),CnI1jv4LZifPbNqOgM93Hw7EKVFs,MMizeNH0AKu(u"ࠬอไษำ๋็ุ๐่๊ࠠࠣะ์อาࠡใํࠤฬ๊ล็ฬิ๊๏ะ๋ࠠ฻่่ࠥ๎ำู๋ࠣฬ๏์ࠠอ้สึ่่ࠦศๆศ๊ฯืๆ๋ฬࠣ࠲ࠥํ่ࠡ์ึฮุ้๋ࠠๆหหฯ้้ࠠ์ๅ์๊ࠦศิฯห๋ฬࠦศะๆสࠤ๊์ใࠡอ่ࠤ๏ฮูฬ้สࠤ้้ࠠ࠯๊่ࠢࠥะั๋ัࠣฮูเ๊ๅࠢฦ้ࠥห๊ใษไࠤฬ๊ศา๊ๆื๏ࠦฟࠨઽ"))
	if NN8u2B5iU3RMYheFy==QvgnCALNstmuUJiET(u"࠲൓"): CELSRh2VQuU6JdFm7Ts8HgNf1cv = JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"࠭ࡁࡔࡍࠪા")
	elif NN8u2B5iU3RMYheFy==HHoGx7Flus60(u"࠴ൔ"): CELSRh2VQuU6JdFm7Ts8HgNf1cv = ITvnUAMXsyb4eO(u"ࠧࡂࡗࡗࡓࠬિ")
	elif NN8u2B5iU3RMYheFy==xcChIL13BpR8WArNt9Pl0So(u"࠶ൕ"): CELSRh2VQuU6JdFm7Ts8HgNf1cv = sULh4NjakzI8He7xJCMGrql(u"ࠨࡕࡗࡓࡕ࠭ી")
	else: CELSRh2VQuU6JdFm7Ts8HgNf1cv = hWGMqtBy4wuLaVcj
	if CELSRh2VQuU6JdFm7Ts8HgNf1cv:
		ee8c0jzrTntGSUdRJm.setSetting(LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡲࡵࡳࡽࡿࠧુ"),CELSRh2VQuU6JdFm7Ts8HgNf1cv)
		UJNrw4z0AoKquZL2PaBsECHpk9 = jjEwJpmd2v0oxBRP1Dyu[CELSRh2VQuU6JdFm7Ts8HgNf1cv]
		BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,UJNrw4z0AoKquZL2PaBsECHpk9)
	return
def gIWarve3NMd9RnVjqZbAl():
	DUn5W9Ns3V82kLS = ee8c0jzrTntGSUdRJm.getSetting(KBkxSYaz93pu1(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴࡭ࡦࡰࡸࡷࡨࡧࡣࡩࡧࠪૂ"))
	if DUn5W9Ns3V82kLS==LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠫࡘ࡚ࡏࡑࠩૃ"): header = SqrG5mU3j96ldsFpExobw40TJY(u"ࠬะฮำ์้ࠤฬ๊โ้ษษ้๋ࠥส้ไไࠫૄ")
	else: header = sULh4NjakzI8He7xJCMGrql(u"࠭สฯิํ๊ࠥอไใ๊สส๊ࠦๅโ฻็ࠫૅ")
	dHPVDWfG4jX5e6QEo0CKh = XVmKrby29eCGMnlEY6jz0HNOR(hWGMqtBy4wuLaVcj,MMizeNH0AKu(u"ࠧฦ์ๅหๆ࠭૆"),LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠨฬไ฽๏๊ࠧે"),header,wwPrSDa21lUh(u"ࠩๅ์ฬฬๅࠡษ็ฬึ์วๆฮࠣ๎ฯ๋ࠠหฯา๎ะํวࠡล๋ฮํ๋วห์ๆ๎ฬࠦศฺัࠣ࠵࠻ࠦำศ฻ฬࠤ๊์ࠠฤ๊็ࠤศูสฯัส้ࠥ࠴࠮๊ࠡศ๎็อแࠡฬัึ๏์ࠠศๆๅ์ฬฬๅࠡ์วำ๏ࠦลๅ๋ࠣฮาี๊ฬ้สࠤๆ๐ࠠไๆ้ࠣึฯ๋ࠠฬ่ࠤฬูสฯัส้ࠥอไใ๊สส๊ࠦ࠮࠯๋๋ࠢีอ๋ࠠีหฬࠥฮืวࠢไ๎ࠥ็สฮࠢๅ์ฬฬๅࠡษ็ฬึ์วๆฮ࡟ࡲࡡࡴ่ࠠๆࠣฮึ๐ฯࠡฬไ฽๏๊ࠠฤ็ࠣษ๏่วโࠢอาื๐ๆࠡษ็ๆํอฦๆࠢยࠥࠦ࠭ૈ"))
	if dHPVDWfG4jX5e6QEo0CKh==-EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"࠶ൖ"): return
	elif dHPVDWfG4jX5e6QEo0CKh:
		ee8c0jzrTntGSUdRJm.setSetting(A6dMB1FlgxVivJ2fk9C(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴࡭ࡦࡰࡸࡷࡨࡧࡣࡩࡧࠪૉ"),rwQN9AKhLCuMfHxjlbX0U(u"ࠫࡆ࡛ࡔࡐࠩ૊"))
		BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,DJ1ICpbyR2(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨો"),e2qDYgipPmTw4KvBLnochr(u"࠭สๆࠢอๅ฾๐ไࠡฬัึ๏์ࠠศๆๅ์ฬฬๅࠨૌ"))
	else:
		ee8c0jzrTntGSUdRJm.setSetting(NeO3CTLHrPfWUoIgy8Q(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡱࡪࡴࡵࡴࡥࡤࡧ࡭࡫્ࠧ"),MMizeNH0AKu(u"ࠨࡕࡗࡓࡕ࠭૎"))
		BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,KBkxSYaz93pu1(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ૏"),jeAby54c02TgG8zuivonX91(u"ࠪฮ๊ࠦล๋ไสๅࠥะฮำ์้ࠤฬ๊โ้ษษ้ࠬૐ"))
	return
def lZPHq0Az7CdhU9Ika4FWs6B(s9ea72VfoygAOFRCWQTH3zmDuLPE):
	if s9ea72VfoygAOFRCWQTH3zmDuLPE!=hWGMqtBy4wuLaVcj:
		s9ea72VfoygAOFRCWQTH3zmDuLPE = cmYMV3Wrwp05J2RNgLs9vCT8X(s9ea72VfoygAOFRCWQTH3zmDuLPE)
		s9ea72VfoygAOFRCWQTH3zmDuLPE = s9ea72VfoygAOFRCWQTH3zmDuLPE.decode(a7VXeDU82IfQEnPZAdiT).encode(a7VXeDU82IfQEnPZAdiT)
		yz8qvJOD6Bj2Tg5kwrfGLcCVNI = NeO3CTLHrPfWUoIgy8Q(u"࠷࠰࠲࠲࠶ൗ")
		qquzbitgB2lSIJ9myPdK0wfFYZ = mUWYiQ2jHICA8cD6LhPTn3wpB1XyK.Window(yz8qvJOD6Bj2Tg5kwrfGLcCVNI)
		qquzbitgB2lSIJ9myPdK0wfFYZ.getControl(XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"࠳࠲࠳൘")).setLabel(s9ea72VfoygAOFRCWQTH3zmDuLPE)
	return
wjpGNOdT9De7XUbtPB0ErJ6Cl8i = [
			 EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠦࡪࡾࡴࡦࡰࡶ࡭ࡴࡴࠠࡢࡸࡶࡴࡦࡩࡥࡴ࠲ࠣ࡭ࡸࠦ࡮ࡰࡶࠣࡧࡺࡸࡲࡦࡰࡷࡰࡾࠦࡳࡶࡲࡳࡳࡷࡺࡥࡥࠤ૑")
			,CnbBKmtF1x84q7AW(u"ࠬࡉࡨࡦࡥ࡮࡭ࡳ࡭ࠠࡧࡱࡵࠤࡒࡧ࡬ࡪࡥ࡬ࡳࡺࡹࠠࡴࡥࡵ࡭ࡵࡺࡳࠨ૒")
			,SqrG5mU3j96ldsFpExobw40TJY(u"࠭ࡐࡗࡔࠣࡍࡕ࡚ࡖࠡࡕ࡬ࡱࡵࡲࡥࠡࡅ࡯࡭ࡪࡴࡴࠨ૓")
			,sULh4NjakzI8He7xJCMGrql(u"ࠧࡖࡰ࡮ࡲࡴࡽ࡮ࠡࡘ࡬ࡨࡪࡵࠠࡊࡰࡩࡳࠥࡑࡥࡺࠩ૔")
			,FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠨࡶ࡫࡭ࡸࠦࡨࡢࡵ࡫ࠤ࡫ࡻ࡮ࡤࡶ࡬ࡳࡳࠦࡩࡴࠢࡥࡶࡴࡱࡥ࡯ࠩ૕")
			,DJ1ICpbyR2(u"ࠩࡸࡷࡪࡹࠠࡱ࡮ࡤ࡭ࡳࠦࡈࡕࡖࡓࠤ࡫ࡵࡲࠡࡣࡧࡨ࠲ࡵ࡮ࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࡶࠫ૖")
			,S1SgCFYGJeMvfp5iZXK(u"ࠪࡥࡩࡼࡡ࡯ࡥࡨࡨ࠲ࡻࡳࡢࡩࡨ࠲࡭ࡺ࡭࡭ࠩ૗")+FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠫࠨ࠭૘")+o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠬࡹࡳ࡭࠯ࡺࡥࡷࡴࡩ࡯ࡩࡶࠫ૙")
			,CnbBKmtF1x84q7AW(u"࠭ࡉ࡯ࡵࡨࡧࡺࡸࡥࡓࡧࡴࡹࡪࡹࡴࡘࡣࡵࡲ࡮ࡴࡧ࠭ࠩ૚")
			,A6dMB1FlgxVivJ2fk9C(u"ࠧࡆࡴࡵࡳࡷࠦࡧࡦࡶࡷ࡭ࡳ࡭ࠠࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄ࠰ࡁࡰࡳࡩ࡫ࡥ࠾࠲ࠩࡸࡪࡾࡴࡵ࠿ࠪ૛")
			,JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠨࡹࡤࡶࡳ࡯࡮ࡨࡵ࠱ࡻࡦࡸ࡮ࠩࠩ૜")
			,gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠩࡡࡢࡣࡤ࡞ࠨ૝")
			,FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠪࡐࡴࡧࡤࡪࡰࡪࠤࡸࡱࡩ࡯ࠢࡩ࡭ࡱ࡫࠺ࠨ૞")
			]
def H7gmzpE0jq6JN9F2WRTYwx4I(xxcMsZ2DfavVz):
	if wwPrSDa21lUh(u"ࠫࡑࡵࡡࡥ࡫ࡱ࡫ࠥࡹ࡫ࡪࡰࠣࡪ࡮ࡲࡥ࠻ࠩ૟") in xxcMsZ2DfavVz and QvgnCALNstmuUJiET(u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪૠ") in xxcMsZ2DfavVz: return VBlawK4mgHSyLEn8iqhUkz5
	for s9ea72VfoygAOFRCWQTH3zmDuLPE in wjpGNOdT9De7XUbtPB0ErJ6Cl8i:
		if s9ea72VfoygAOFRCWQTH3zmDuLPE in xxcMsZ2DfavVz: return VBlawK4mgHSyLEn8iqhUkz5
	return fEXMiAyG3ql4vKB
def E2dqy5wLZVWY(data):
	zb7M0FSnXjIaRD2sQH1Gx9ActCY = KNIvHPjUbhr(u"࠹൚") if H4qZ2hwilNJYTmCFEQyaSs98cPM0gR else EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"࠲࠷൙")
	data = data.replace(rwQN9AKhLCuMfHxjlbX0U(u"࠶࠴൛")*Mpsm2VF1OBnCRvK3qf6,zb7M0FSnXjIaRD2sQH1Gx9ActCY*Mpsm2VF1OBnCRvK3qf6)
	data = data.replace(EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"࠭ࠠ࠽ࡩࡨࡲࡪࡸࡡ࡭ࡀ࠽ࠤࠬૡ"),wwPrSDa21lUh(u"ࠧ࠻ࠢࠪૢ"))
	OucJVrWRKSqDChiG7yn3oz0dafZF = hWGMqtBy4wuLaVcj
	for xxcMsZ2DfavVz in data.splitlines():
		DFw16vKa0u2NxHpXkeMLO9JmI7lVW = trdVA0JvFaD.findall(ITvnUAMXsyb4eO(u"ࠨࠢࠣࠤࠥࠦࡆࡪ࡮ࡨࠤࠧ࠮࠮ࠫࡁࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹ࠮ࠪࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧૣ"),xxcMsZ2DfavVz,trdVA0JvFaD.DOTALL)
		if DFw16vKa0u2NxHpXkeMLO9JmI7lVW: xxcMsZ2DfavVz = xxcMsZ2DfavVz.replace(DFw16vKa0u2NxHpXkeMLO9JmI7lVW[ybdv7XcT3lxF6QezULwCAGk],hWGMqtBy4wuLaVcj)
		OucJVrWRKSqDChiG7yn3oz0dafZF += NXMOzZjYsmS9pf+xxcMsZ2DfavVz
	return OucJVrWRKSqDChiG7yn3oz0dafZF
def Ivab0rCK6nUOTZ5jEc3Ss48R(skM5927QRuT1x6SnJfV4yIAGBr):
	if JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠩࡒࡐࡉ࠭૤") in skM5927QRuT1x6SnJfV4yIAGBr:
		HdZva5lO137RW = IIavAQfbsU6DkGw4tSRWrX5nJlg2jP
		header = QvgnCALNstmuUJiET(u"ࠪๆึอมสࠢสุ่าไࠡษ็ๆิ๐ๅࠡมࠪ૥")
	else:
		HdZva5lO137RW = OG6qjT5MQi4lIe
		header = NeO3CTLHrPfWUoIgy8Q(u"ࠫ็ืวยหࠣหู้ฬๅࠢส่าอไ๋ࠢยࠫ૦")
	dHPVDWfG4jX5e6QEo0CKh = XVmKrby29eCGMnlEY6jz0HNOR(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,header,rwQN9AKhLCuMfHxjlbX0U(u"ูࠬฬๅࠢส่ศิืศรࠣ๎าะ่๋ࠢฦ๎฻อฺࠠๆ์ࠤุาไࠡษ็หุะฮะษ่ࠤ࠳่ࠦศๆสฯ๋๐ๆุࠡิ์ึ๐ษࠡๆ่฽ึ็ษࠡๅํๅࠥำฯฬฬࠣห้๋ิไๆฬࠤํ๋ว้๋ࠡࠤฬ๊ๅไษ้ࠤฬ๊ะ๋ࠢึฬอࠦอะ๊ฮࠤฬ๊ๅีๅ็อࠥ࠴ࠠไ๊า๎ࠥ๐อหใ฻ࠤอูฬๅ์้ࠤ࠳ࠦวๅล๋่ࠥํ่ࠡษ็ืั๊ࠠศๆะห้๐้ࠠใํู๋๋ࠥๅ๊่หฯࠦสษัฦࠤ๊์ะࠡสาห๏ฯࠠศๆอุ฿๐ไࠡษ็ัฬ๊๊ࠡๆหี๋อๅอࠢๆ์ิ๐้ࠠษ็ํࠥอไร่ࠣ࠲ࠥษๅศࠢสุ่าไࠡษ็ๆิ๐ๅࠡใ๊์ࠥอไิฮ็ࠤฬ๊ำศสๅࠤฬ๊ะ๋ࠢอ้ࠥาๅฺ้้๋ࠣࠦศา่ส้ัࠦใ้ัํࠤ็ฮไࠡฤัีࠥหืโษฤࠤ้ํࠠ࠯๊่ࠢࠥะั๋ัࠣห้อำห็ิหึࠦฟࠨ૧"))
	if dHPVDWfG4jX5e6QEo0CKh!=NeO3CTLHrPfWUoIgy8Q(u"࠵൜"): return
	vgdJTtyQ1eGDIL9i36FBYj,MkNO5By27JAx0gtzdLHUp = [],LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"࠵൝")
	size,count = YAvI1Zz5J3yEFXQdWhqmo6nD(HdZva5lO137RW)
	file = open(HdZva5lO137RW,QVDJLRlxNg127jMX(u"࠭ࡲࡣࠩ૨"))
	if size>NeO3CTLHrPfWUoIgy8Q(u"࠱࠱࠲࠵࠴࠵ൟ"): file.seek(-NeO3CTLHrPfWUoIgy8Q(u"࠷࠰࠱࠳࠳࠴൞"),WQvYkNg7SysPFLitlGEn6.SEEK_END)
	data = file.read()
	file.close()
	if H4qZ2hwilNJYTmCFEQyaSs98cPM0gR: data = data.decode(a7VXeDU82IfQEnPZAdiT)
	data = E2dqy5wLZVWY(data)
	yefFjNXHl7 = data.split(NXMOzZjYsmS9pf)
	for xxcMsZ2DfavVz in reversed(yefFjNXHl7):
		UcwBPjhZkV6KymMp2ngtJv = H7gmzpE0jq6JN9F2WRTYwx4I(xxcMsZ2DfavVz)
		if UcwBPjhZkV6KymMp2ngtJv: continue
		xxcMsZ2DfavVz = xxcMsZ2DfavVz.replace(XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠧ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠࡠࠩ૩"),soMVfbr6WtpNlcSA+KNIvHPjUbhr(u"ࠨࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫ૪")+YYSh2J6BIrsm8)
		xxcMsZ2DfavVz = xxcMsZ2DfavVz.replace(dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠩࡈࡖࡗࡕࡒ࠻ࠩ૫"),e2qDYgipPmTw4KvBLnochr(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆ࠱࠲࠳࠴ࡢ࠭૬")+MMizeNH0AKu(u"ࠫࡊࡘࡒࡐࡔ࠽ࠫ૭")+YYSh2J6BIrsm8)
		YWhFTEwHU12mMA86yj7NtB9PQDC = hWGMqtBy4wuLaVcj
		lW6HDne9bSh1 = trdVA0JvFaD.findall(GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠬࡤࠨ࡝ࡦ࠮࠱࠭ࡢࡤࠬ࠯࡟ࡨ࠰ࠦ࡜ࡥ࠭࠽ࡠࡩ࠱࠺࡝ࡦ࠮ࡠ࠳ࡢࡤ࡚ࠬࠫࠬࠬࠥ࠺࡝ࡦ࠮࠭ࠬ૮"),xxcMsZ2DfavVz,trdVA0JvFaD.DOTALL)
		if lW6HDne9bSh1:
			xxcMsZ2DfavVz = xxcMsZ2DfavVz.replace(lW6HDne9bSh1[ybdv7XcT3lxF6QezULwCAGk][ybdv7XcT3lxF6QezULwCAGk],lW6HDne9bSh1[ybdv7XcT3lxF6QezULwCAGk][bXukYxQ4aHw]).replace(lW6HDne9bSh1[ybdv7XcT3lxF6QezULwCAGk][Y0XZKGRAUQj5O],hWGMqtBy4wuLaVcj)
			YWhFTEwHU12mMA86yj7NtB9PQDC = lW6HDne9bSh1[ybdv7XcT3lxF6QezULwCAGk][bXukYxQ4aHw]
		else:
			lW6HDne9bSh1 = trdVA0JvFaD.findall(MMizeNH0AKu(u"࠭࡞ࠩ࡞ࡧ࠯࠿ࡢࡤࠬ࠼࡟ࡨ࠰ࡢ࠮࡝ࡦ࠮࠭࠭ࠦࡔ࠻࡞ࡧ࠯࠮࠭૯"),xxcMsZ2DfavVz,trdVA0JvFaD.DOTALL)
			if lW6HDne9bSh1:
				xxcMsZ2DfavVz = xxcMsZ2DfavVz.replace(lW6HDne9bSh1[ybdv7XcT3lxF6QezULwCAGk][bXukYxQ4aHw],hWGMqtBy4wuLaVcj)
				YWhFTEwHU12mMA86yj7NtB9PQDC = lW6HDne9bSh1[ybdv7XcT3lxF6QezULwCAGk][ybdv7XcT3lxF6QezULwCAGk]
		if YWhFTEwHU12mMA86yj7NtB9PQDC: xxcMsZ2DfavVz = xxcMsZ2DfavVz.replace(YWhFTEwHU12mMA86yj7NtB9PQDC,hXB0vKVQ5PRI91SDTprMdfuHEm4+YWhFTEwHU12mMA86yj7NtB9PQDC+YYSh2J6BIrsm8)
		vgdJTtyQ1eGDIL9i36FBYj.append(xxcMsZ2DfavVz)
		if len(str(vgdJTtyQ1eGDIL9i36FBYj))>EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"࠶࠲࠴࠴࠵ൠ"): break
	vgdJTtyQ1eGDIL9i36FBYj = reversed(vgdJTtyQ1eGDIL9i36FBYj)
	XRzQpoKCr80hxG1SI9PeYZB2js = NXMOzZjYsmS9pf.join(vgdJTtyQ1eGDIL9i36FBYj)
	yBv4YaSomFrkejwgNA7pDnKudCz(FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠧ࡭ࡧࡩࡸࠬ૰"),HHoGx7Flus60(u"ࠨฤัีࠥษำุำࠣืั๊ࠠศๆฦา฼อม๊ࠡส่ฬูสฯัส้ࠬ૱"),XRzQpoKCr80hxG1SI9PeYZB2js,jeAby54c02TgG8zuivonX91(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡸࡳࡡ࡭࡮ࡩࡳࡳࡺ࡟࡭ࡱࡱ࡫ࠬ૲"))
	return
def XJGWgVeZ5PmAOknMUQiylLdD18R():
	PUVt2kH56ISvlKGCdu7qLDnA = open(O2AysQHU7D8YlBtC4xTXvz,OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠪࡶࡧ࠭૳")).read()
	if H4qZ2hwilNJYTmCFEQyaSs98cPM0gR: PUVt2kH56ISvlKGCdu7qLDnA = PUVt2kH56ISvlKGCdu7qLDnA.decode(a7VXeDU82IfQEnPZAdiT)
	PUVt2kH56ISvlKGCdu7qLDnA = PUVt2kH56ISvlKGCdu7qLDnA.replace(HHoGx7Flus60(u"ࠫࡡࡺࠧ૴"),hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠬࠦࠠࠡࠢࠣࠤࠥࠦࠧ૵"))
	ssBcmRijhUKPzpVoYNwdLZvElJ = trdVA0JvFaD.findall(KNIvHPjUbhr(u"࠭ࠨࡷ࡞ࡧ࠲࠯ࡅࠩ࡜࡞ࡱࡠࡷࡣࠧ૶"),PUVt2kH56ISvlKGCdu7qLDnA,trdVA0JvFaD.DOTALL)
	for xxcMsZ2DfavVz in ssBcmRijhUKPzpVoYNwdLZvElJ:
		PUVt2kH56ISvlKGCdu7qLDnA = PUVt2kH56ISvlKGCdu7qLDnA.replace(xxcMsZ2DfavVz,soMVfbr6WtpNlcSA+xxcMsZ2DfavVz+YYSh2J6BIrsm8)
	zJEnrfcbUOg2ihV5MW7KT4PZm(mkHKSQvjWr5BTcM3wVY(u"ࠧศๆอ฾๏๐ัศฬࠣห้ษฮ๋ำฬࠤๆ๐ࠠศๆหีฬ๋ฬࠨ૷"),PUVt2kH56ISvlKGCdu7qLDnA)
	return
def KpkHMIuxQcDV9XPySE83B6TwnF():
	qkrP6CTSuMFneV0EfAUgxm1RoWt = rwQN9AKhLCuMfHxjlbX0U(u"ࠨส฼ฺࠥอไฤิิหึูࠦๅ๋ࠣห้ื๊ๆ๊อࠤ่๎ๆหำ๋่ࠥะ่โำࠣษ๊้ว็์ฬࠤฯ่ฯ๋็ࠣ์ฯษฮ๋ำࠣห้็๊ะ์๋ࠤํํะ่ࠢส่ศุัศำ๋ࠣ๏ࠦวๅลึ๋๊่ࠦศๆฦี็อๅࠡ็฼ࠤอ฿ึ๊ࠡๆห้ะวๅ์ࠪ૸")
	LwBM9FdHl8aE3iDh5IgzY02kZ = zyvJMtBhrw(u"ࠩ็ฮ็ี๊ๆࠢส่ๆ๐ฯ๋๊ࠣหุะฮะ็ࠣหู้็ๆࠢส่๏๋๊็๋่ࠢฯษฮ๋ำ๊ࠤฬูสฯั่ࠤฬ๊ำ่็ࠣห้๐ำศำࠣ࠲ࠥษๅศࠢ฼ำฮࠦวิ้่ࠤ๊ะสศๆํอࠥ็็ั้ࠣฮ็๎ๅࠡสอัึ๐ใࠡษ็ๅ๏ี๊้ࠢห์็ะࠠศๅหี๋ࠥๆ๊ࠡๅฮࠥอไิ้่ࠤฬ๊่ศฯาࠤ࠳ࠦรๆษࠣหู้็ๆࠢส่ศ฿ไ๊๋ࠢห้ษำโๆࠣๅ์๎๋ࠠฯิ็ࠥอไโ์า๎ํࠦลๅ๋ࠣห้ษๅศ็ࠣวํࠦลๅ๋ࠣห้๎ัศรࠣ์้้ๆࠡสๅๅืฯࠠไสํีฮ࠭ૹ")
	jdkSvGmCp0WOLoqJUYiTAZ = A6dMB1FlgxVivJ2fk9C(u"ࠪว๊อࠠศๆฦี็อๅࠡใ๊๎ࠥะำหะา้๊ࠥไหไา๎๊่ࠦศๆอวำ๐ั๊ࠡ็็๋ࠦศๆไาหึูࠦะัࠣห้ั่ศ่ํࠤํอไะไสส็ࠦ࠮ࠡ็ฮ่ฬࠦัใ็ࠣ࠹࠹࠺ࠠห฻้๎ࠥ࠻ࠠะไสส็่ࠦࠡ࠶࠷ࠤะอๆ๋หࠣษ้๏ࠠศๆฦ้ฬ๋ࠠฤ๊ࠣษ้๏ࠠศๆ๋ีฬวࠠษฯึฬࠥอำหะาห๊้ࠠๅๆึ๋๊ࠦวๅ์่๎๋ࠦร้ࠢึ๋๊ࠦวๅ์ึหึ࠭ૺ")
	jjEwJpmd2v0oxBRP1Dyu = qkrP6CTSuMFneV0EfAUgxm1RoWt+rwQN9AKhLCuMfHxjlbX0U(u"ࠫ࠿ࠦࠧૻ")+LwBM9FdHl8aE3iDh5IgzY02kZ+S1SgCFYGJeMvfp5iZXK(u"ࠬࠦ࠮ࠡࠩૼ")+jdkSvGmCp0WOLoqJUYiTAZ
	yBv4YaSomFrkejwgNA7pDnKudCz(sULh4NjakzI8He7xJCMGrql(u"࠭ࡣࡦࡰࡷࡩࡷ࠭૽"),GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ૾"),jjEwJpmd2v0oxBRP1Dyu,xcChIL13BpR8WArNt9Pl0So(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫ૿"))
	return
def IYfvGAuH1W(type,jjEwJpmd2v0oxBRP1Dyu,showDialogs=VBlawK4mgHSyLEn8iqhUkz5,url=hWGMqtBy4wuLaVcj,dUWFtBQ3cpoIZ9=hWGMqtBy4wuLaVcj,s9ea72VfoygAOFRCWQTH3zmDuLPE=hWGMqtBy4wuLaVcj,U0I8gTn4h7YmSfpH=hWGMqtBy4wuLaVcj):
	V8fCsUKgzwEGiANc9HSmyn2D4LPZQ = VBlawK4mgHSyLEn8iqhUkz5
	if not MmcgqAlsFt.j0juxvCpdOFDk2:
		if showDialogs:
			KJjDWLn5ECY18N4uZyA = (e2qDYgipPmTw4KvBLnochr(u"ࠩสุ่฽ั࠻ࠩ଀") in jjEwJpmd2v0oxBRP1Dyu and OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠪห้๋ใศ่࠽ࠫଁ") in jjEwJpmd2v0oxBRP1Dyu and XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠫฬ๊ๅๅใ࠽ࠫଂ") in jjEwJpmd2v0oxBRP1Dyu and hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠬอไฯูฦࠫଃ") in jjEwJpmd2v0oxBRP1Dyu and ITvnUAMXsyb4eO(u"࠭วๅ็ุำึࡀࠧ଄") in jjEwJpmd2v0oxBRP1Dyu)
			if not KJjDWLn5ECY18N4uZyA: V8fCsUKgzwEGiANc9HSmyn2D4LPZQ = XVmKrby29eCGMnlEY6jz0HNOR(QvgnCALNstmuUJiET(u"ࠧࡤࡧࡱࡸࡪࡸࠧଅ"),hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠨ้็ࠤฯืำๅ๊ࠢิ์ࠦวๅำึห้ฯࠠฦๆ์ࠤฬ๊ๅษำ่ะࠬଆ"),jjEwJpmd2v0oxBRP1Dyu.replace(OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠩ࡟ࡠࡳ࠭ଇ"),NXMOzZjYsmS9pf))
	elif showDialogs:
		jjEwJpmd2v0oxBRP1Dyu = HHoGx7Flus60(u"ࠪࡠࡡࡴสๆ่ࠢืาࠦวๅำึห้ฯ࡜࡝ࡰอ้๋ࠥำฮࠢิืฬ๊ษ࡝࡞ࡱฮ๊ࠦๅิฯࠣห้ืำศๆฬࡠࡡࡴสๆ่ࠢืาࠦวๅำึห้ฯ࡜࡝ࡰอ้๋ࠥำฮࠢส่ึูวๅหࠪଈ")
		DKec39hdXSpOFlPb = XVmKrby29eCGMnlEY6jz0HNOR(KNIvHPjUbhr(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫଉ"),hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,S1SgCFYGJeMvfp5iZXK(u"ࠬะๅࠡ็ึัࠥืำศๆอ็ࠬଊ")+zyvJMtBhrw(u"࠭ࠠࠡ࠳࠲࠹ࠬଋ"),hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"่ࠧๆࠣฮึ๐ฯࠡวิืฬ๊ࠠาีส่ฮࠦแศำ฽อࠬଌ"))
		sxtj0IugdMiwypol = XVmKrby29eCGMnlEY6jz0HNOR(e2qDYgipPmTw4KvBLnochr(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ଍"),hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,HHoGx7Flus60(u"ࠩอ้๋ࠥำฮࠢิืฬ๊สไࠩ଎")+dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠪࠤࠥ࠸࠯࠶ࠩଏ"),A6dMB1FlgxVivJ2fk9C(u"ࠫ์๊ࠠหำํำࠥหัิษ็ࠤึูวๅหࠣๅฬืฺสࠩଐ"))
		zYd3ZFKGgS4iQEM0Wyn = XVmKrby29eCGMnlEY6jz0HNOR(GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ଑"),hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"࠭สๆ่ࠢืาࠦัิษ็ฮ่࠭଒")+sULh4NjakzI8He7xJCMGrql(u"ࠧࠡࠢ࠶࠳࠺࠭ଓ"),gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠨ้็ࠤฯื๊ะࠢศีุอไࠡำึห้ฯࠠโษิ฾ฮ࠭ଔ"))
		X7uPiW6Np89Ut = XVmKrby29eCGMnlEY6jz0HNOR(e2qDYgipPmTw4KvBLnochr(u"ࠩࡦࡩࡳࡺࡥࡳࠩକ"),hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,mkHKSQvjWr5BTcM3wVY(u"ࠪฮ๊ࠦๅิฯࠣีุอไหๅࠪଖ")+LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠫࠥࠦ࠴࠰࠷ࠪଗ"),A6dMB1FlgxVivJ2fk9C(u"ࠬํไࠡฬิ๎ิࠦลาีส่ࠥืำศๆฬࠤๆอั฻หࠪଘ"))
		V8fCsUKgzwEGiANc9HSmyn2D4LPZQ = XVmKrby29eCGMnlEY6jz0HNOR(DJ1ICpbyR2(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ଙ"),hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,KBkxSYaz93pu1(u"ࠧห็ุ้ࠣำࠠาีส่ฯ้ࠧଚ")+MMizeNH0AKu(u"ࠨࠢࠣ࠹࠴࠻ࠧଛ"),LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"๊่ࠩࠥะั๋ัࠣษึูวๅࠢิืฬ๊ษࠡใสี฿ฯࠧଜ"))
	EPuMlX4RDWry9L = rV36aR5MufG1tqOWAlkYepcDd(fEXMiAyG3ql4vKB)
	EMVFARjX8b130sd5ghPI = CnbBKmtF1x84q7AW(u"ࠪࡅ࡛ࡀࠠࠨଝ")+EPuMlX4RDWry9L+KBkxSYaz93pu1(u"ࠫ࠲࠭ଞ")+type
	phBvCeKLcg0UZdQPOESHAm = VBlawK4mgHSyLEn8iqhUkz5 if FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠬࡥࡐࡓࡑࡅࡐࡊࡓ࡟ࠨଟ") in s9ea72VfoygAOFRCWQTH3zmDuLPE else fEXMiAyG3ql4vKB
	if not V8fCsUKgzwEGiANc9HSmyn2D4LPZQ:
		if showDialogs: BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,SqrG5mU3j96ldsFpExobw40TJY(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩଠ"),KBkxSYaz93pu1(u"ࠧห็ࠣษ้เวยࠢส่สืำศๆࠣฬ๋อมࠡ฻็ํࠥ฽ไษๅࠪଡ"))
		return fEXMiAyG3ql4vKB
	izr7cX4yhJbPIdpg = MMk8qKvcJe4fQHm3EG7diBD5.getInfoLabel(KBkxSYaz93pu1(u"ࠨࡕࡼࡷࡹ࡫࡭࠯ࡈࡵ࡭ࡪࡴࡤ࡭ࡻࡑࡥࡲ࡫ࠧଢ"))
	jjEwJpmd2v0oxBRP1Dyu += GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠩࠣࡠࡡࡴ࡜࡝ࡰࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࠣࡠࡡࡴࡁࡥࡦࡲࡲࠥ࡜ࡥࡳࡵ࡬ࡳࡳࡀࠠࠨଣ")+aO9cFKo862LqTWlIjy+wwPrSDa21lUh(u"ࠪࠤ࠿ࡢ࡜࡯ࠩତ")
	jjEwJpmd2v0oxBRP1Dyu += QvgnCALNstmuUJiET(u"ࠫࡊࡳࡡࡪ࡮ࠣࡗࡪࡴࡤࡦࡴ࠽ࠤࠬଥ")+EPuMlX4RDWry9L+GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠬࠦ࠺࡝࡞ࡱࡏࡴࡪࡩࠡࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠫଦ")+FFAcZOeDh4KC+xcChIL13BpR8WArNt9Pl0So(u"࠭ࠠ࠻࡞࡟ࡲࠬଧ")
	jjEwJpmd2v0oxBRP1Dyu += o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠧࡌࡱࡧ࡭ࠥࡔࡡ࡮ࡧ࠽ࠤࠬନ")+izr7cX4yhJbPIdpg
	Ch3fRqj2lPAZrszcgytLE9BVK = gHXD9xAZTjLSkqhuV42cIa()
	Ch3fRqj2lPAZrszcgytLE9BVK = e1mT8H4dGS3XFyx0KLUA9(Ch3fRqj2lPAZrszcgytLE9BVK)
	if Ch3fRqj2lPAZrszcgytLE9BVK: jjEwJpmd2v0oxBRP1Dyu += OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠨࠢ࠽ࡠࡡࡴࡌࡰࡥࡤࡸ࡮ࡵ࡮࠻ࠢࠪ଩")+Ch3fRqj2lPAZrszcgytLE9BVK
	if url: jjEwJpmd2v0oxBRP1Dyu += LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠩࠣ࠾ࡡࡢ࡮ࡖࡔࡏ࠾ࠥ࠭ପ")+url
	if dUWFtBQ3cpoIZ9: jjEwJpmd2v0oxBRP1Dyu += A6dMB1FlgxVivJ2fk9C(u"ࠪࠤ࠿ࡢ࡜࡯ࡕࡲࡹࡷࡩࡥ࠻ࠢࠪଫ")+dUWFtBQ3cpoIZ9
	jjEwJpmd2v0oxBRP1Dyu += gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠫࠥࡀ࡜࡝ࡰࠪବ")
	if showDialogs: OnsAxhdVjZF(zyvJMtBhrw(u"ࠬาวา์ࠣห้หัิษ็ࠫଭ"),LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"࠭วๅำฯหฦࠦวๅษ้ฮ฽อัࠨମ"))
	if U0I8gTn4h7YmSfpH:
		XRzQpoKCr80hxG1SI9PeYZB2js = U0I8gTn4h7YmSfpH
		if H4qZ2hwilNJYTmCFEQyaSs98cPM0gR: XRzQpoKCr80hxG1SI9PeYZB2js = XRzQpoKCr80hxG1SI9PeYZB2js.encode(a7VXeDU82IfQEnPZAdiT)
		XRzQpoKCr80hxG1SI9PeYZB2js = FxG0Q9kuBSmTyM.b64encode(XRzQpoKCr80hxG1SI9PeYZB2js)
	elif phBvCeKLcg0UZdQPOESHAm:
		if NeO3CTLHrPfWUoIgy8Q(u"ࠧࡠࡒࡕࡓࡇࡒࡅࡎࡡࡒࡐࡉࡥࠧଯ") in s9ea72VfoygAOFRCWQTH3zmDuLPE: iu9DJxAhctqa2d1bN8ZLwIFY7n = IIavAQfbsU6DkGw4tSRWrX5nJlg2jP
		else: iu9DJxAhctqa2d1bN8ZLwIFY7n = OG6qjT5MQi4lIe
		if not WQvYkNg7SysPFLitlGEn6.path.exists(iu9DJxAhctqa2d1bN8ZLwIFY7n):
			BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,NeO3CTLHrPfWUoIgy8Q(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫର"),DJ1ICpbyR2(u"ࠩึะ้ࠦวๅลั฻ฬว้ࠠษ็หุะฮะษ่ࠤ฿๐ัࠡ็๋ะํีࠧ଱"))
			return fEXMiAyG3ql4vKB
		KteLZCbM8W0FqE2OBx1(pGYKHZgqFX3B,KNIvHPjUbhr(u"ࠪ࠲ࡡࡺࡐࡳࡧࡳࡥࡷ࡯࡮ࡨࠢࡷࡳࠥࡹࡥ࡯ࡦࠣࡸ࡭࡫ࠠ࡭ࡱࡪࡪ࡮ࡲࡥࠨଲ"))
		vgdJTtyQ1eGDIL9i36FBYj,MkNO5By27JAx0gtzdLHUp = [],SqrG5mU3j96ldsFpExobw40TJY(u"࠲ൡ")
		file = open(iu9DJxAhctqa2d1bN8ZLwIFY7n,EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠫࡷࡨࠧଳ"))
		size,count = YAvI1Zz5J3yEFXQdWhqmo6nD(iu9DJxAhctqa2d1bN8ZLwIFY7n)
		if size>NeO3CTLHrPfWUoIgy8Q(u"࠶࠴࠶࠶࠰࠱ൢ"): file.seek(-NeO3CTLHrPfWUoIgy8Q(u"࠶࠴࠶࠶࠰࠱ൢ"),WQvYkNg7SysPFLitlGEn6.SEEK_END)
		data = file.read()
		file.close()
		data = data.decode(a7VXeDU82IfQEnPZAdiT)
		data = E2dqy5wLZVWY(data)
		yefFjNXHl7 = data.splitlines()
		for xxcMsZ2DfavVz in reversed(yefFjNXHl7):
			UcwBPjhZkV6KymMp2ngtJv = H7gmzpE0jq6JN9F2WRTYwx4I(xxcMsZ2DfavVz)
			if UcwBPjhZkV6KymMp2ngtJv: continue
			lW6HDne9bSh1 = trdVA0JvFaD.findall(JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠬࡤࠨ࡝ࡦ࠮࠱࠭ࡢࡤࠬ࠯࡟ࡨ࠰ࠦ࡜ࡥ࠭࠽ࡠࡩ࠱࠺࡝ࡦ࠮ࡠ࠳ࡢࡤ࡚ࠬࠫࠬࠬࠥ࠺࡝ࡦ࠮࠭ࠬ଴"),xxcMsZ2DfavVz,trdVA0JvFaD.DOTALL)
			if lW6HDne9bSh1:
				xxcMsZ2DfavVz = xxcMsZ2DfavVz.replace(lW6HDne9bSh1[ybdv7XcT3lxF6QezULwCAGk][ybdv7XcT3lxF6QezULwCAGk],lW6HDne9bSh1[ybdv7XcT3lxF6QezULwCAGk][bXukYxQ4aHw]).replace(lW6HDne9bSh1[ybdv7XcT3lxF6QezULwCAGk][Y0XZKGRAUQj5O],hWGMqtBy4wuLaVcj)
			else:
				lW6HDne9bSh1 = trdVA0JvFaD.findall(QvgnCALNstmuUJiET(u"࠭࡞ࠩ࡞ࡧ࠯࠿ࡢࡤࠬ࠼࡟ࡨ࠰ࡢ࠮࡝ࡦ࠮࠭࠭ࠦࡔ࠻࡞ࡧ࠯࠮࠭ଵ"),xxcMsZ2DfavVz,trdVA0JvFaD.DOTALL)
				if lW6HDne9bSh1: xxcMsZ2DfavVz = xxcMsZ2DfavVz.replace(lW6HDne9bSh1[ybdv7XcT3lxF6QezULwCAGk][bXukYxQ4aHw],hWGMqtBy4wuLaVcj)
			vgdJTtyQ1eGDIL9i36FBYj.append(xxcMsZ2DfavVz)
			if len(str(vgdJTtyQ1eGDIL9i36FBYj))>CnbBKmtF1x84q7AW(u"࠶࠺࠷࠰࠱࠲ൣ"): break
		vgdJTtyQ1eGDIL9i36FBYj = reversed(vgdJTtyQ1eGDIL9i36FBYj)
		XRzQpoKCr80hxG1SI9PeYZB2js = FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠧ࡝ࡴ࡟ࡲࠬଶ").join(vgdJTtyQ1eGDIL9i36FBYj)
		XRzQpoKCr80hxG1SI9PeYZB2js = XRzQpoKCr80hxG1SI9PeYZB2js.encode(a7VXeDU82IfQEnPZAdiT)
		XRzQpoKCr80hxG1SI9PeYZB2js = FxG0Q9kuBSmTyM.b64encode(XRzQpoKCr80hxG1SI9PeYZB2js)
	else: XRzQpoKCr80hxG1SI9PeYZB2js = hWGMqtBy4wuLaVcj
	url = u6rbxnyjTl7I[EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠨࡒ࡜ࡘࡍࡕࡎࠨଷ")][Y0XZKGRAUQj5O]
	l17Sn3hK59WV = {S1SgCFYGJeMvfp5iZXK(u"ࠩࡶࡹࡧࡰࡥࡤࡶࠪସ"):EMVFARjX8b130sd5ghPI,wwPrSDa21lUh(u"ࠪࡱࡪࡹࡳࡢࡩࡨࠫହ"):jjEwJpmd2v0oxBRP1Dyu,JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠫࡱࡵࡧࡧ࡫࡯ࡩࠬ଺"):XRzQpoKCr80hxG1SI9PeYZB2js}
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(lke5D6CpaAXPdEZyrBSw7T,FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠬࡖࡏࡔࡖࠪ଻"),url,l17Sn3hK59WV,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,S1SgCFYGJeMvfp5iZXK(u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓ࠮ࡕࡈࡒࡉࡥࡅࡎࡃࡌࡐ࠲࠷ࡳࡵ଼ࠩ"))
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	if DJ1ICpbyR2(u"ࠧࠣࡵࡸࡧࡨ࡫ࡥࡥࡧࡧࠦ࠿ࠦ࠱࠭ࠩଽ") in mMQ3FkNVa4IlxqY: G62uf8ZSIzBE = VBlawK4mgHSyLEn8iqhUkz5
	else: G62uf8ZSIzBE = fEXMiAyG3ql4vKB
	if showDialogs:
		if G62uf8ZSIzBE:
			OnsAxhdVjZF(jeAby54c02TgG8zuivonX91(u"ࠨฬ่ࠤฬ๊ลาีส่ࠥฮๆอษะࠫା"),FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠩࡖࡹࡨࡩࡥࡴࡵࠪି"))
			BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,KBkxSYaz93pu1(u"ࠪࡑࡪࡹࡳࡢࡩࡨࠤࡸ࡫࡮ࡵࠩୀ"),JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠫฯ๋ࠠฦำึห้ࠦวๅำึห้ฯࠠษ่ฯหา࠭ୁ"))
		else:
			OnsAxhdVjZF(FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"๊ࠬไฤีไࠤๆฺไࠡษ็ษึูวๅࠩୂ"),CnbBKmtF1x84q7AW(u"࠭ࡆࡢ࡫࡯ࡹࡷ࡫ࠧୃ"))
			BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪୄ"),CnbBKmtF1x84q7AW(u"ࠨะฺวࠥ๎แีๆࠣๅ๏ࠦลาีส่ࠥอไาีส่ฮ࠭୅"))
	return G62uf8ZSIzBE
def lzLcCA8FEJ():
	qkrP6CTSuMFneV0EfAUgxm1RoWt = KNIvHPjUbhr(u"ࠩ࠴࠲ࠥࠦࠠࡊࡨࠣࡽࡴࡻࠠࡩࡣࡹࡩࠥࡶࡲࡰࡤ࡯ࡩࡲࠦࡷࡪࡶ࡫ࠤࡆࡸࡡࡣ࡫ࡦࠤࡹ࡫ࡸࡵࡶࠣࡸ࡭࡫࡮ࠡࡩࡲࠤࡹࡵࠠࠣࡍࡲࡨ࡮ࠦࡉ࡯ࡶࡨࡶ࡫ࡧࡣࡦࠢࡖࡩࡹࡺࡩ࡯ࡩࡶࠦࠥࡧ࡮ࡥࠢࡦ࡬ࡦࡴࡧࡦࠢࡷ࡬ࡪࠦࡦࡰࡰࡷࠤࡹࡵࠠࠣࡃࡵ࡭ࡦࡲࠢࠨ୆")
	LwBM9FdHl8aE3iDh5IgzY02kZ = DJ1ICpbyR2(u"ࠪ࠵࠳ࠦࠠࠡวำห๊ࠥฯ๋ๅู้้ࠣไสࠢไ๎ࠥอไฤฯิๅࠥอไฺำห๎ฮࠦแศา๊ฬࠥหไ๊ࠢศ฽ิอฯศฬࠣ์ฬา็สࠢๆ์ิ๐ࠠฬ็ࠣ฾๏ืࠠศๆั฻ࠥอไๆีอาิ๋ࠠฦๆ์ࠤࠧࡇࡲࡪࡣ࡯ࠦࠬେ")
	BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,KBkxSYaz93pu1(u"ࠫࡆࡸࡡࡣ࡫ࡦࠤࡕࡸ࡯ࡣ࡮ࡨࡱࠬୈ"),qkrP6CTSuMFneV0EfAUgxm1RoWt+NeO3CTLHrPfWUoIgy8Q(u"ࠬࡢ࡮࡝ࡰࠪ୉")+LwBM9FdHl8aE3iDh5IgzY02kZ)
	qkrP6CTSuMFneV0EfAUgxm1RoWt = mkHKSQvjWr5BTcM3wVY(u"࠭࠲࠯ࠢࠣࠤࡎ࡬ࠠࡺࡱࡸࠤࡨࡧ࡮࡝ࠩࡷࠤ࡫࡯࡮ࡥࠢࠥࡅࡷ࡯ࡡ࡭ࠤࠣࡪࡴࡴࡴࠡࡶ࡫ࡩࡳࠦࡣࡩࡣࡱ࡫ࡪࠦࡴࡩࡧࠣࡷࡰ࡯࡮ࠡࡣࡱࡨࠥࡺࡨࡦࡰࠣࡧ࡭ࡧ࡮ࡨࡧࠣࡸ࡭࡫ࠠࡧࡱࡱࡸࠬ୊")
	LwBM9FdHl8aE3iDh5IgzY02kZ = e2qDYgipPmTw4KvBLnochr(u"ࠧ࠳࠰ࠣࠤࠥหะศࠢ็้ࠥะฬะࠢส่ำ฽ࠠࠣࡃࡵ࡭ࡦࡲࠢࠡใๅ้ࠥฮส฻์ํีࠥอไอๆาࠤะ๋ࠠใ็ࠣฬฯเ๊าࠢส่ำ฽ࠠศๆ่ืฯิฯๆࠢศ่๎ࠦࠢࡂࡴ࡬ࡥࡱࠨࠧୋ")
	BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠨࡈࡲࡲࡹࠦࡐࡳࡱࡥࡰࡪࡳࠧୌ"),qkrP6CTSuMFneV0EfAUgxm1RoWt+EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠩ࡟ࡲࡡࡴ୍ࠧ")+LwBM9FdHl8aE3iDh5IgzY02kZ)
	qkrP6CTSuMFneV0EfAUgxm1RoWt = CnbBKmtF1x84q7AW(u"ࠪ࠷࠳ࠦࠠࠡࡋࡩࠤࡾࡵࡵࠡࡦࡲࡲࡡ࠭ࡴࠡࡪࡤࡺࡪࠦࡁࡳࡣࡥ࡭ࡨࠦࡋࡦࡻࡥࡳࡦࡸࡤࠡࡶ࡫ࡩࡳࠦࡧࡰࠢࡷࡳࠥࠨࡋࡰࡦ࡬ࠤࡎࡴࡴࡦࡴࡩࡥࡨ࡫ࠠࡔࡧࡷࡸ࡮ࡴࡧࡴࠤࠣࡥࡳࡪࠠࡤࡪࡤࡲ࡬࡫ࠠࡵࡪࡨࠤࡷ࡫ࡧࡪࡱࡱࡥࡱࠦࡳࡦࡶࡷ࡭ࡳ࡭ࡳࠨ୎")
	LwBM9FdHl8aE3iDh5IgzY02kZ = hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠫ࠸࠴ࠠࠡࠢศิฬࠦไๆࠢํ็๋ࠦไะ์ๆࠤ้๎อส่ࠢๅฬะ๊ฮࠢ฼ีอ๐ษࠡใสิ์ฮࠠฦๆ์ࠤส฿ฯศัสฮࠥ๎วอ้ฬࠤ่๎ฯ๋ࠢฮ้ࠥเ๊าࠢศ฽ิอฯศฬࠣห้๋ๆุไฬࠤฬ๊ฬ฻ำสๅ๏ฯࠧ୏")
	BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠬࡌ࡯࡯ࡶࠣࡔࡷࡵࡢ࡭ࡧࡰࠫ୐"),qkrP6CTSuMFneV0EfAUgxm1RoWt+dv0trJR7PwmKyxDYO52VLau8gEph(u"࠭࡜࡯࡞ࡱࠫ୑")+LwBM9FdHl8aE3iDh5IgzY02kZ)
	dHPVDWfG4jX5e6QEo0CKh = XVmKrby29eCGMnlEY6jz0HNOR(o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠧࡤࡧࡱࡸࡪࡸࠧ୒"),hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,A6dMB1FlgxVivJ2fk9C(u"ࠨࡈࡲࡲࡹࠦࡳࡦࡶࡷ࡭ࡳ࡭ࡳࠨ୓"),JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠩࡇࡳࠥࡿ࡯ࡶࠢࡺࡥࡳࡺࠠࡵࡱࠣ࡫ࡴࠦࡴࡰࠢࠥࡏࡴࡪࡩࠡࡋࡱࡸࡪࡸࡦࡢࡥࡨࠤࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸࠨࠠ࡯ࡱࡺࠤࡄ࠭୔")+e2qDYgipPmTw4KvBLnochr(u"ࠪࡠࡳࡢ࡮ࠨ୕")+EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠫ์๊ࠠหำํำࠥอไั้สฬࠥหไ๊ࠢ็์าฯࠠฦ฻าหิอส๊ࠡสะ์ฯࠠไ๊า๎ࠥษไร่ยࠫୖ"))
	if dHPVDWfG4jX5e6QEo0CKh==KBkxSYaz93pu1(u"࠶൤"): tsS1hMmVRZLFwlCgcI27TPqJQ3WY()
	return
def ZZREdAcOqXvD7iwg42eBGj6():
	BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,rwQN9AKhLCuMfHxjlbX0U(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨୗ"),o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ฺ࠭ศๆหหࠥอไิสหࠤ์๎ࠠๆ่ࠣห้๋่ใ฻ࠣห้ษีๅ์ࠣหฺ้๋ั์่้ࠣฮั็ษ่ะࠥ๎ไๅฬฦ็ิࠦโๆࠢหฮูเ๊ๅࠢส่ึอศุࠢส่ี๐ࠠๅษࠣ๎฾๋ไࠡอ่ࠤ็๋ࠠษวิืฬ๊ࠠๆึๆ่ฮࠦลๅ๋ࠣห้๋ศา็ฯࠤ๊์ࠠศๆๅหห๋ษࠡษ็ีห๐ำ๋ห่้ࠣฮั็ษ่ะࠬ୘"))
	return
def Wcw3BPuqahs4zvOKmf6FVR():
	jjEwJpmd2v0oxBRP1Dyu = QvgnCALNstmuUJiET(u"่ࠧาสࠤฬ๊ศา่ส้ัࠦๅฯืุࠤๆ่ืࠡๆ็฾ฮࠦวๅ฻ิฬ๏ฯ้ࠠๆๆ๊ࠥํะศࠢ็หࠥ๐ๅ็฻ࠣ์ั๎ฯࠡ็๋ห็฿ࠠโ์๊หࠥษแๅษ่ࠤํ๋ำๅี็หฯࠦๅหำฯ้ฮࠦร้่ࠢำอ๊ฬสࠢศ่๎ࠦวๅๆ฽อࠥอไฺำห๎ฮ่ࠦศๆ์ࠤ้เวหࠢสาึ๏้ࠠๆสࠤ๏๎ฬะࠢึฬอࠦไๅฬๆีฬืࠧ୙")
	BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,sULh4NjakzI8He7xJCMGrql(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ୚"),jjEwJpmd2v0oxBRP1Dyu)
	return
def N4ICKte1Gwzlk():
	jjEwJpmd2v0oxBRP1Dyu = jeAby54c02TgG8zuivonX91(u"ࠩส่ึ๎วษูࠣห้ฮื๋ศฬࠤ้อฺࠠๆสๆฮࠦไ่ษࠣฬฬ๊ศา่ส้ั่ࠦ฻ษ็ฬฬࠦวๅีหฬࠥํ่ࠡ็้ࠤฬ๊ๅ้ไ฼ࠤฬ๊รึๆํࠤฬ๊ๅ฻าํࠤ้๊ศา่ส้ั࠭୛")
	BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ଡ଼"),jjEwJpmd2v0oxBRP1Dyu)
	return
def wp1I8lbtTesBv():
	jjEwJpmd2v0oxBRP1Dyu = XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠫ์๐ࠠิ์ิๅึอสࠡๆสࠤ๏ูสุ์฼ࠤฬ๊ศา่ส้ัࠦวิฬัำฬ๋็ศࠢหือฮࠠไ๊้๋ฬࠦๅฮ็ํอ๋ࠥๆࠡษ็ฺ้ีัࠡล๋ࠤอำวอหࠣษ้๏ࠠศึอีฬ้ࠠาี่๎ࠥษ่ࠡฮา๎ิฯࠠฤ๊่ࠣฬฺ๊ࠦำไ๋ฬࠦวๅสิ๊ฬ๋ฬࠨଢ଼")
	BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,DJ1ICpbyR2(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ୞"),OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"࠭ำ๋ำไีฬะࠠิ์ษอࠥษ่ࠡ็ฯ๋ํ๊ษࠨୟ"),jjEwJpmd2v0oxBRP1Dyu)
	return
def vDjYFoBSQGJKbRpUs2A():
	jjEwJpmd2v0oxBRP1Dyu = sULh4NjakzI8He7xJCMGrql(u"ࠧศๆึ๎ึ็ัศฬࠣห้฿วๆห๋ࠣ๏ࠦำ๋ำไีฬะࠠฯษิะ๏ฯ้ࠠ฼ํีࠥะวษ฻ฬࠤ้๊ๅ้ไ฼ࠤฬ๊รึๆํࠤําๅ๋฻ࠣห้๋่ศไ฼ࠤฯูสฯั่๋ฬฺ่ࠦษาอࠥะใ้่้ࠣัอๆ๋หࠣ์ฺ๊วไๆ๊ห้ࠥห๋ำฬࠤ้อๆࠡษ็ๅ๏ี๊้้สฮࠥ็๊่ษࠣษ๊อࠠษูํสฮࠦร้่้๋ࠢ๎ูสࠢฦ์๋ࠥอั๊ไอࠥษ่ࠡใํ๋ฬࠦๅีๅ็อࠥำโ้ไࠣห้๋ไไ์ฬࡠࡳࡢ࡮࡝ࡰสุ่๐ัโำสฮࠥอไฯษุอࠥํ๊ࠡีํีๆืวหࠢอหอ฿ษࠡๆ็้ํู่ࠡษ็วฺ๊๊๊่ࠡืฯิฯๆหࠣๅ๏ࠦๅ้ษๅ฽่ࠥไ๋ๆฬࠤัีว๊ࠡ฼หิฯࠠหๅ๋๊๋ࠥฯโ๊฼อࠥอไฤฮิࠤศ๎๋ࠠ็็็์อࠠศๆ่์็฿ࠠศๆฦู้๐้ࠠๆ๊ิฬࠦแ่์ࠣะ๏ีษ่ࠡึฬ๏อ้ࠠีิ๎฾ฯ้ࠠ็ืห่๊็ศࠢๅ่๏๊ษࠡฮาหࠬୠ")
	yBv4YaSomFrkejwgNA7pDnKudCz(gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨୡ"),KBkxSYaz93pu1(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬୢ"),jjEwJpmd2v0oxBRP1Dyu,EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭ୣ"))
	return
def XD3H59QuSPwhlaLR():
	qkrP6CTSuMFneV0EfAUgxm1RoWt = e2qDYgipPmTw4KvBLnochr(u"ࠫฬฮสฺัࠣ฽๋ࠦๅๅใสฮࠥอไะไฬࠤฬู๊ศๆํอࠬ୤")
	LwBM9FdHl8aE3iDh5IgzY02kZ = NeO3CTLHrPfWUoIgy8Q(u"ࠬอศห฻าࠤ฾์ࠠๆๆไหฯࠦรๅࠢࡰ࠷ࡺ࠾ࠧ୥")
	jdkSvGmCp0WOLoqJUYiTAZ = mkHKSQvjWr5BTcM3wVY(u"࠭วษฬ฼ำࠥ฿ๆࠡ็็ๅฬะࠠศๆอั๊๐ไ๊ࠡส่ิอ่็ๆ๋ำࠥࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ୦")
	BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,DJ1ICpbyR2(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ୧"),qkrP6CTSuMFneV0EfAUgxm1RoWt,LwBM9FdHl8aE3iDh5IgzY02kZ,jdkSvGmCp0WOLoqJUYiTAZ)
	return
def qRXHeAKQwYDLP():
	LwBM9FdHl8aE3iDh5IgzY02kZ = KBkxSYaz93pu1(u"ࠨษ็็ฬฺ่๊้ࠠࠣำุๆࠡ็วๆฯࠦไๅ็฼่ํ๋วหࠢํืฯิฯๆ้ࠣห้ฮั็ษ่ะ๊ࠥฮำู่ࠣๆำวหࠢส่ส์สา่ํฮࠥ๎ั้ษห฻ࠥอไโ์า๎ํํวหࠢ็่ํ฻่ๅࠢศ่๏ํวࠡสึี฾ฯ้ࠠสา์๋ࠦล็ฬิ๊๏ะ้ࠠษ็ฬึ์วๆฮࠣ๎ู๊อ่ษࠣฮ้่วว์สࠤอ฿ฯࠡษ้ฮ์อมࠡ฻่ี์อ้ࠠลํฺฬูࠦ็ัࠣฮาี๊ฬࠢส่อืๆศ็ฯࠤ࠳่่ࠦาสࠤฬ๊ศา่ส้ั๊ࠦิฬัำ๊ࠦำษ฻ฬࠤศ์่ศ฻่ࠣ฾๋ัࠡษ็็ฬฺࠠ࠻ࠩ୨")
	LwBM9FdHl8aE3iDh5IgzY02kZ += HHoGx7Flus60(u"ࠩ࡟ࡲࡡࡴࠧ୩") + hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠪ࠵࠳ࠦหศสอࠤ้๊ีโฯสฮࠥอไห์้ࠣ฾ื่โࠢฦ๊์อࠠๅษࠣฮฯเ๊า้๋ࠢฬฬ๊ศ๋้ࠢิะ็ࠡࠩ୪") + str(VWxPgG1p8Z2Ei4DrX7NotvR/EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"࠼࠰൥")/EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"࠼࠰൥")/SqrG5mU3j96ldsFpExobw40TJY(u"࠲࠵൦")/HHoGx7Flus60(u"࠴࠲൧")) + NeO3CTLHrPfWUoIgy8Q(u"ฺࠫࠥ็าࠩ୫")
	LwBM9FdHl8aE3iDh5IgzY02kZ += NXMOzZjYsmS9pf + EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠬ࠸࠮ࠡฮาหࠥ฽่๋ๆࠣห้๋ฯ๊ࠢ็ฺ่็อศฬࠣห้๋แาู๊ࠤศ์็ศࠢ็หࠥะส฻์ิࠤํ๋ฯห้ࠣࠫ୬") + str(AoRzutVGQfLjYMwdCngZPxs/KNIvHPjUbhr(u"࠸࠳൨")/KNIvHPjUbhr(u"࠸࠳൨")/A6dMB1FlgxVivJ2fk9C(u"࠵࠸൩")) + KNIvHPjUbhr(u"๋๊่࠭ࠠࠫ୭")
	LwBM9FdHl8aE3iDh5IgzY02kZ += NXMOzZjYsmS9pf + wwPrSDa21lUh(u"ࠧ࠴࠰ࠣ฻ํ๐ไࠡษ็้ิ๏ࠠๅๆุๅาอสࠡษ็ฮ๏ࠦๆศัิหࠥะส฻์ิࠤํ๋ฯห้ࠣࠫ୮") + str(DpQifS0oKBI1hYcO/e2qDYgipPmTw4KvBLnochr(u"࠺࠵൪")/e2qDYgipPmTw4KvBLnochr(u"࠺࠵൪")/MMizeNH0AKu(u"࠷࠺൫")) + SqrG5mU3j96ldsFpExobw40TJY(u"ࠨࠢํ์๊࠭୯")
	LwBM9FdHl8aE3iDh5IgzY02kZ += NXMOzZjYsmS9pf + ITvnUAMXsyb4eO(u"ࠩ࠷࠲๋ࠥส้ีฺࠤฬ๊ๅะ๋่้ࠣ฻แฮษอࠤฬ๊ส๋ࠢๅำࠥะส฻์ิࠤํ๋ฯห้ࠣࠫ୰") + str(KqO5BWGQR9JVL/GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"࠼࠰൬")/GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"࠼࠰൬")) + FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠪࠤุอูสࠩୱ")
	LwBM9FdHl8aE3iDh5IgzY02kZ += NXMOzZjYsmS9pf + HHoGx7Flus60(u"ࠫ࠺࠴ࠠใืํีࠥอไๆั์ࠤ้๊ีโฯสฮࠥอไห์ࠣฮฯเ๊าࠢาหห๋ว๊่ࠡำฯํࠠࠨ୲") + str(nHBb7jXk0Daom/QVDJLRlxNg127jMX(u"࠶࠱൭")/QVDJLRlxNg127jMX(u"࠶࠱൭")) + MMizeNH0AKu(u"ࠬࠦำศ฻ฬࠫ୳")
	LwBM9FdHl8aE3iDh5IgzY02kZ += NXMOzZjYsmS9pf + jeAby54c02TgG8zuivonX91(u"࠭࠶࠯ࠢฯำฬࠦโึ์ิࠤฬ๊ๅะ๋่้ࠣ฻แฮษอࠤฬ๊ส๋ࠢอฮ฿๐ัࠡๅฮ๎ึอ้ࠠ็าฮ์ࠦࠧ୴") + str(D8V7AhLkSQYzo/gDuGMR3z1aV6YdLmCpiO8Kl(u"࠷࠲൮")) + mkHKSQvjWr5BTcM3wVY(u"ࠧࠡัๅ๎็ฯࠧ୵")
	LwBM9FdHl8aE3iDh5IgzY02kZ += NXMOzZjYsmS9pf + EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠨ࠹࠱ࠤอี่็ࠢๆหูࠦไๅืไัฬะࠠศๆอ๎ࠥะส฻์ิࠤอูัฺหࠣ์๊ีส่ࠢࠪ୶") + str(lke5D6CpaAXPdEZyrBSw7T) + LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠩࠣำ็๐โสࠩ୷")
	LwBM9FdHl8aE3iDh5IgzY02kZ += NeO3CTLHrPfWUoIgy8Q(u"ࠪࡠࡳࡢ࡮ࠨ୸") + QvgnCALNstmuUJiET(u"๊ࠫัไศ࠼ูࠣๆำวหࠢๅ์ฬฬๅࠡษ็วๆ๊วๆ๋ࠢห้๋ำๅี็หฯ่ࠦศๆะ่็อสࠡ฻่ี์อࠠࠨ୹") + str(KqO5BWGQR9JVL/dv0trJR7PwmKyxDYO52VLau8gEph(u"࠸࠳൯")/dv0trJR7PwmKyxDYO52VLau8gEph(u"࠸࠳൯")) + GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠬࠦำศ฻ฬࠤ࠳ࠦรๆษࠣๆํอฦๆࠢฦ๊ํอูࠡษ็ๅ๏ี๊้้สฮࠥ็ูๆำ๊หࠥ࠭୺") + str(DpQifS0oKBI1hYcO/dv0trJR7PwmKyxDYO52VLau8gEph(u"࠸࠳൯")/dv0trJR7PwmKyxDYO52VLau8gEph(u"࠸࠳൯")/CnbBKmtF1x84q7AW(u"࠵࠸൰")) + S1SgCFYGJeMvfp5iZXK(u"࠭ࠠฤ์ส้ࠥ࠴ࠠฤ็สࠤ๊๊แศฬࠣห้็๊ะ์๋ࠤๆ฿ๅา้สࠤࠬ୻") + str(nHBb7jXk0Daom/dv0trJR7PwmKyxDYO52VLau8gEph(u"࠸࠳൯")/dv0trJR7PwmKyxDYO52VLau8gEph(u"࠸࠳൯")) + zyvJMtBhrw(u"ࠧࠡีส฽ฮࠦแใูࠣ࠲ࠥษๅศࠢไัฺࠦัใ็ࠣห้หีะษิࠤๆ฿ๅา้ࠣࠫ୼") + str(D8V7AhLkSQYzo/dv0trJR7PwmKyxDYO52VLau8gEph(u"࠸࠳൯")) + hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠨࠢาๆ๏่ษࠡ࠰ࠣว๊อࠠโฯุࠤฬฺสาษๆࠤๅࡏࡐࡕࡘࠣๅ฾๋ั่ࠢࠪ୽") + str(lke5D6CpaAXPdEZyrBSw7T) + XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠩࠣำ็๐โสࠩ୾")
	yBv4YaSomFrkejwgNA7pDnKudCz(mkHKSQvjWr5BTcM3wVY(u"ࠪࡶ࡮࡭ࡨࡵࠩ୿"),QVDJLRlxNg127jMX(u"๊ࠫอ่๊ࠠࠣห้้วีࠢสู่๊สฯั่ࠤๆ๐ࠠศๆหี๋อๅอࠩ஀"),LwBM9FdHl8aE3iDh5IgzY02kZ,DJ1ICpbyR2(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨ஁"))
	return
def Nh2r4w7uMlxa5Wvno():
	jjEwJpmd2v0oxBRP1Dyu = wwPrSDa21lUh(u"࠭วๅใสู้ฯࠠห฻้๎๋ࠥฬๅัࠣฬ๋็ำࠡษึ้์ࠦวๅลุ่๏่ࠦศๆ้ๆ฼ฯࠠห฻้๎ࠥษๆࠡษ็หุ๋ࠠศๆฦู้๐ࠠห็ࠣฮ฾ี๊ๅ้ࠣ์ๆอีๅหࠣ์๋่ืสࠢอ฽๋๏ࠠๆฮ็ำࠥ๎สๆࠢอ฽ิ๐ไࠡษึ้์่ࠦษั๋๊ࠥ฿ไศ็ฬࠤฯ฿ๆ๋่่ࠢๆࠦศ็ใึࠤฬูๅ่ࠢส่ศ฻ไ๋ࠩஂ")
	BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪஃ"),jjEwJpmd2v0oxBRP1Dyu)
	return
def yNMPYQgiqof():
	jjEwJpmd2v0oxBRP1Dyu = JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠨวำหࠥ๎วอ้อ็๋ࠥิไๆฬࠤๆ๐ࠠศๆืฬ่ฯ้ࠠฬ่ࠤา๊็ศࠢ࠱࠲࠳ࠦร้ࠢส๊่ࠦสู่ࠣว๋ࠦวๅ็๋ๆ฾ࠦวๅลุ่๏ࠦใศ่ࠣๅ๏ํࠠๆึๆ่ฮࠦๅลไอ๋ࠥ๎สๆࠢะ่์อࠠ࠯࠰࠱ࠤๆหะ็ࠢฯีอࠦๅิฯࠣ็ฬฺࠠศๆหี๋อๅอࠢ็็๏๊ࠦใ๊่ࠤฬ๊ศา่ส้ัࠦศุๆหࠤฬ๊ีโฯฬࠤฬ๊ีฮ์ะอࠥ๎สฯิํ๊์อࠠษั็ห๋ࠥๆࠡษ็ูๆำษࠡษ็ๆิ๐ๅสࠩ஄")
	BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,A6dMB1FlgxVivJ2fk9C(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬஅ"),jjEwJpmd2v0oxBRP1Dyu)
	return
def SQ8sJcaWwy1LotFZMUPlD2Tx():
	jjEwJpmd2v0oxBRP1Dyu = A6dMB1FlgxVivJ2fk9C(u"ࠪห้เัืฺ่๊ࠢࠥ็ศัฬࠤฬ๊สีใํีࠥํุ่่ࠡห๋ࠦีฮหࠣ์ุื๊สࠢส่๊฿ไ้็สฮࠥอไๆฬหหิ๊ษࠡสํ๊ࠥอไษำ้ห๊า้ࠠษ็้ํู่ࠡษ็ู้็ั๊๊ࠡิฬࠦวๅุ่หฺ๋๋ࠦำ้ࠣ฼๊่ษ๋่ࠢฬࠦอศฮฬࠤ้ํฺ่ࠠาࠤฬ๊วหืส่ࠥอ่ࠡษ็ีอ฽ࠠๆ฻้ࠣํอโฺࠢส่ๆ๐ฯ๋๊๊หฯࠦวๅ็ืๅึฯࠧஆ")
	BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧஇ"),jjEwJpmd2v0oxBRP1Dyu)
	return
def ZHo3qmFuwaJQ():
	BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨஈ"),OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"࠭ไไ์ࠣ๎฾๋ไ้ࠡำหࠥอไ็๊฼ࠤ๊์ࠠศๆไ๎ิ๐่่ษอࠤࡡࡴ๋ࠠฮหࠤฯ็ู๋ๆࠣษ฻อแสࠢสื๊ํวࠡ࡞ࡱࠤ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡤࡨࡦࡶࡴࡪࡸࡨࠫஉ"))
	ff1TqXMbjgJ6n4yko(wwPrSDa21lUh(u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡧࡤࡢࡲࡷ࡭ࡻ࡫ࠧஊ"),VBlawK4mgHSyLEn8iqhUkz5)
	return
def Ji19IVyPck5():
	jjEwJpmd2v0oxBRP1Dyu  = XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠨ็วาึอࠠใษ่ฮࠥฮูืࠢืี่อสࠡษ็ษ๋ะั็ฬࠣห้ี่ๅ์ࠣฬํ฼ูࠡ฻สส็ࠦึะࠢส่อืวๆฮ้ࠣะ๊ࠠไ๊า๎๊ࠥสิ็ะࠤๆ่ืࠡๆห฽฻ࠦๅิฬัำ๊๐ࠠศๆ่ฮฺ็อࠡสส่ิิ่ๅࠢ็้ํอโฺࠢส่ๆ๐ฯ๋๊ࠪ஋")
	jjEwJpmd2v0oxBRP1Dyu += HHoGx7Flus60(u"ࠩࠣ์๋ะ๊อห่ࠣ์ึวࠡษ็฽ฬฬโࠡใส๊์ࠦสใำํฬฬࠦฬๆ์฼ࠤู๊สฯั่๎ࠥฮั็ษ่ะ้่ࠥะ์่ࠣฬ๊ࠦิฬฺ๎฾๎ๆࠡษ็ำำ๎ไࠡๆฯ้๏฿ࠠๆ๊สๆ฾ࠦวๅสิ๊ฬ๋ฬࠡฯอํู๋ࠥࠡษึฮำีวๆࠩ஌")
	jjEwJpmd2v0oxBRP1Dyu += NXMOzZjYsmS9pf+hXB0vKVQ5PRI91SDTprMdfuHEm4+ITvnUAMXsyb4eO(u"ࠪไࠥࠦࡖࡑࡐࠣࠤศ๎ࠠࠡࡒࡵࡳࡽࡿࠠࠡล๋ࠤࠥࡊࡎࡔࠢࠣวํࠦร๋ࠢะ่ࠥฮำู๋ࠣฦำืࠧ஍")+YYSh2J6BIrsm8+NXMOzZjYsmS9pf
	jjEwJpmd2v0oxBRP1Dyu += OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠫࡡࡴไศ่๋ࠣีอࠠๅ่ࠣ๎า๊ࠠศๆุ่่๊ษ๊ࠡศ๊๊อࠠโไฺࠤุ๐โ้็ࠣฬส฻ไศฯࠣฬ฾฼ࠠศๆ่์ฬู่๊ࠡศ฽ฬ่ษࠡ็๋ห็฿ࠠศะิํ้ࠥว็ฬࠣฮ฾๋ไࠡีสฬ็อࠠษั๋๊๋ࠥิศๅ็ࠫஎ")
	yBv4YaSomFrkejwgNA7pDnKudCz(o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠬࡸࡩࡨࡪࡷࠫஏ"),LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩஐ"),jjEwJpmd2v0oxBRP1Dyu,XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪ஑"))
	jjEwJpmd2v0oxBRP1Dyu = wwPrSDa21lUh(u"ࠨษ็้ํอโฺࠢส่ฯ๐ࠠหลฮีฯࠦศศๆ฼หหฺ่่ࠠาࠤอ฿ึࠡษ็๊ฬู่ࠠ์࠽ࠫஒ")
	jjEwJpmd2v0oxBRP1Dyu += NXMOzZjYsmS9pf+hXB0vKVQ5PRI91SDTprMdfuHEm4+zyvJMtBhrw(u"ࠩࡤ࡯ࡴࡧ࡭ࠡࠢࡨ࡫ࡾࡨࡥࡴࡶࠣࠤࡪ࡭ࡹࡣࡧࡶࡸࡻ࡯ࡰࠡࠢࡰࡳࡻ࡯ࡺ࡭ࡣࡱࡨࠥࠦࡳࡦࡴ࡬ࡩࡸ࠺ࡷࡢࡶࡦ࡬ࠥࠦࡳࡩࡣ࡫࡭ࡩ࠺ࡵࠨஓ")+YYSh2J6BIrsm8
	jjEwJpmd2v0oxBRP1Dyu += hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠪࡠࡳࡢ࡮ࠨஔ")+MMizeNH0AKu(u"ࠫฬ๊ฯ้ๆࠣห้ะ๊ࠡฬฦฯึะࠠษษ็฽ฬฬโࠡ฻้ำࠥฮูืࠢส่๋อำ้ࠡํ࠾ࠬக")
	jjEwJpmd2v0oxBRP1Dyu += NXMOzZjYsmS9pf+hXB0vKVQ5PRI91SDTprMdfuHEm4+HHoGx7Flus60(u"๋ࠬีาࠢࠣห้้่๋ฬࠣࠤศ๋๊าๅสࠤ้ࠥๆะษࠣࠤๆืๆิษࠣࠤฬ๊๊้่ส๊ࠥࠦศา์ฺห๋๐วࠡษ็ษ๊อัศฬࠣว้๋ว็์สࠤึ๎ำ๋ษࠣห้๐วษษ้ࠤฬ๊ำฺ๊า๎ฮࠦั้็ส๊๏อ่๊ࠠ็๊ิอࠧ஖")+YYSh2J6BIrsm8
	jjEwJpmd2v0oxBRP1Dyu += GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"࠭࡜࡯࡞ࡱࠫ஗")+zyvJMtBhrw(u"ࠧศๆ่ฬึ๋ฬ๊ࠡฯำࠥ฽ั๋ไฬࠤ้ะฬศ๊ีࠤฬู๊ศศๅࠤํ๊ใ็้สࠤฯำสศฮࠣะ์ีࠠไสํีࠥ๎วๅ็หี๊าฺ๋้ࠠࠤฬ๊ๅีๅ็อࠥ฻ฺ๋ำฬࠤํ๊วࠡฬึฮา่ࠠศๆอ฽อࠦแฦาสࠤ้ี๊ไุ่่๊ࠢษࠡสส่ิิ่ๅࠢ็ฬ฾฼ࠠศๆ่์ฬู่๊ࠡฦ๎฻อࠠๅๅํࠤ๏ะึฮࠢะะ๊ࠦวๅ็ื็้ฯࠠࠨ஘")
	jjEwJpmd2v0oxBRP1Dyu += hXB0vKVQ5PRI91SDTprMdfuHEm4+A6dMB1FlgxVivJ2fk9C(u"ࠨษิื้ࠦัิษ็อ๋ࠥฤะสฬࠤส๊้ࠡษ็้อืๅอ๋ࠢห่ะศࠡใํ๋ฬࠦวิ็ࠣฬ้ีใ๊ࠡฦื๊อมࠡษ็้ํอโฺࠢส่ฯ๐ࠠๅษࠣฮุะื๋฻ࠣำำ๎ไ่ษࠪங")+YYSh2J6BIrsm8
	yBv4YaSomFrkejwgNA7pDnKudCz(mkHKSQvjWr5BTcM3wVY(u"ࠩࡵ࡭࡬࡮ࡴࠨச"),jeAby54c02TgG8zuivonX91(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭஛"),jjEwJpmd2v0oxBRP1Dyu,KBkxSYaz93pu1(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧஜ"))
	return
def JjPdR2QwD7fHt3E6uriOhp5c():
	BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠬัไศอࠣ฻ึ่ࠠๅๆอ์ฬ฻ไࠡ็฼ࠤฬ๊ๅษำ่ะࠬ஝"),EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"࠭ราี็ࠤึูวๅหࠣวํࠦๅีๅ็อ๋ࠥๆࠡไสส๊ฯࠠฯั่หฯࠦ็ัษࠣห้ฮั็ษ่ะࡡࡴ࡜࡯ล๋ࠤออำหะาห๊ࠦวๅใํือ๎ใࠡลา๊ฬํ࡜࡯ࠩஞ")+hXB0vKVQ5PRI91SDTprMdfuHEm4+OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡧࡣࡦࡩࡧࡵ࡯࡬࠰ࡦࡳࡲ࠵ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷ࠷࠶࠱࠹ࠩட")+YYSh2J6BIrsm8+mkHKSQvjWr5BTcM3wVY(u"ࠨ࡞ࡱࡠࡳษ่ࠡสสีุอไࠡษํ้๏๊ࠠศๆ์ࠤศีๆศ้ࠣࠤࡡࡴࠠࠨ஠")+hXB0vKVQ5PRI91SDTprMdfuHEm4+GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠩࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳ࠳࠲࠴࠼ࡅ࡭࡭ࡢ࡫࡯࠲ࡨࡵ࡭ࠨ஡")+YYSh2J6BIrsm8)
	return
def BBO7Q5CkHhnvotm1ulidUp4JTINX():
	qRXHeAKQwYDLP()
	dHPVDWfG4jX5e6QEo0CKh = XVmKrby29eCGMnlEY6jz0HNOR(jeAby54c02TgG8zuivonX91(u"ࠪࡧࡪࡴࡴࡦࡴࠪ஢"),hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,e2qDYgipPmTw4KvBLnochr(u"ࠫ์๊ࠠหำํำ๋ࠥำฮࠢฯ้๏฿ࠠศๆๆหูࠦฟࠨண"),A6dMB1FlgxVivJ2fk9C(u"ࠬอไไษืࠤ๏ูัฺࠢ฼้้ࠦวๅสิ๊ฬ๋ฬ๊่ࠡืาํ๋ࠠ฻ํำูࠥอษࠢสฺ่็อศฬ้๋ࠣࠦวๅว้ฮึ์สࠡ฻้ำࠥอไฮษฯอࠥหไ๋้สࠤํอไๆีะࠤ๏ะๅࠡฬ็ๆฬฬ๊ศࠢ฼๊ิࠦว็ฬ๊หฦูࠦๆำࠣห้฻แฮษอࠤํอไๆีะࠤ้อุ๋ࠠิࠤํ๋ๅไ่ࠣ๎า๊ࠠษ฻ูࠤฬ๊ๅีษๆ่ࠬத"))
	if dHPVDWfG4jX5e6QEo0CKh==CnbBKmtF1x84q7AW(u"࠵൱"):
		GG49f0QoTrPgvyYOHeb1MsUIjiJlw(VBlawK4mgHSyLEn8iqhUkz5)
		BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,e2qDYgipPmTw4KvBLnochr(u"࠭สๆ่ࠢืาࠦใศึࠣห้ฮั็ษ่ะࠥฮวๅๅส้้࠭஥"),MMizeNH0AKu(u"ࠧฦาสࠤ่อๆหࠢ฼๊ิ้ࠠๆึๆ่ฮࠦแ๋ࠢสัิࠦวๅ็๋ห็฿ࠠโฮิฬࠥอไๆ๊ๅ฽ࠥอไร่ࠣ࠲࠳࠴้ࠠลำหࠥอไๆึๆ่ฮࠦๅิฬ่ีฮࠦแฦา้ࠤฬืำๅࠢสฺ่๊ใๅหࠣษ้๏ࠠศๆ่ฬึ๋ฬࠨ஦"))
	return dHPVDWfG4jX5e6QEo0CKh
def sYzH8e57tGm(showDialogs=VBlawK4mgHSyLEn8iqhUkz5):
	if not showDialogs: showDialogs = VBlawK4mgHSyLEn8iqhUkz5
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(lke5D6CpaAXPdEZyrBSw7T,HHoGx7Flus60(u"ࠨࡉࡈࡘࠬ஧"),LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩࡽࡧ࡭ࡱ࡮ࡨ࠲ࡨࡵ࡭ࠨந"),hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,fEXMiAyG3ql4vKB,hWGMqtBy4wuLaVcj,EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗ࠲ࡎࡔࡕࡒࡖࡣ࡙ࡋࡓࡕ࠯࠴ࡷࡹ࠭ன"))
	if not sDQvwGASB0Vf67mik.succeeded:
		FFzHxiSu634vgVAlYToLUwdXGhE = fEXMiAyG3ql4vKB
		SaLcnMBU8Kp7qxYgzbeJROu = XFr42BCdkuqpsmZw6NvG39gz7HSK0h(fEXMiAyG3ql4vKB)
		KteLZCbM8W0FqE2OBx1(VRQE4jsXHSfhPWo5DgLwxGk,qhVEWvetzXLOcr1(xjPuFK3EsIZSiobQ5X)+ITvnUAMXsyb4eO(u"ࠫࠥࠦࠠࡉࡖࡗࡔࡘࠦࡆࡢ࡫࡯ࡩࡩࠦࠠࠡࡎࡤࡦࡪࡲ࠺࡜ࠩப")+SaLcnMBU8Kp7qxYgzbeJROu+hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠬࡣࠧ஫"))
		if showDialogs: BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,gDuGMR3z1aV6YdLmCpiO8Kl(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ஬"),QvgnCALNstmuUJiET(u"ࠧโฯุࠤฬ๊วหืส่ࠥอไๆึไีࠥ࠴࠮࠯ุ่่๊ࠢษࠡ࠰࠱࠲ࠥอไศฬุห้ࠦวๅ็ืๅึࠦࠨศๆิฬ฼ࠦวๅ็ืๅึ࠯ࠠๅษࠣ๎฾๋ไࠡ฻้ำู่ࠦๅ๋ࠣ็ํี๊ࠡ࠰࠱࠲ࠥ๎ู็ัๆࠤ่๎ฯ๋ࠢ฽๎ึࠦโศัิࠤ฾๊้ࠡษึฮำีวๆࠢส่๊๎วใ฻ࠣห้๋ิโำฬࠫ஭"))
	else:
		FFzHxiSu634vgVAlYToLUwdXGhE = VBlawK4mgHSyLEn8iqhUkz5
		if showDialogs: BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,xcChIL13BpR8WArNt9Pl0So(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫம"),EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠩฯ๎ิࠦฬะษࠣ࠲࠳࠴ࠠศๆสฮฺอไࠡษ็ู้็ัࠡࠪส่ึฮืࠡษ็ู้็ัࠪࠢํ฽ฺ๊๊่ࠠา็ࠥ๎วๅสิ๊ฬ๋ฬࠡไสำึูࠦๅ๋ࠣหุะฮะษ่ࠤฬ๊ๅ้ษๅ฽ࠥอไๆึไีฮ࠭ய"))
	if not FFzHxiSu634vgVAlYToLUwdXGhE and showDialogs: aaXMLiW9Or0()
	return FFzHxiSu634vgVAlYToLUwdXGhE
def aaXMLiW9Or0():
	BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,xcChIL13BpR8WArNt9Pl0So(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ர"),GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠫอ฿ึࠡษ็้ํอโฺࠢอัฯอฬࠡำห฻๋ࠥิโำࠣ์็ี๋ࠠๅ๋๊ࠥา็ศิๆࠤ฿๐ัࠡไสำึูࠦๅ๋ࠣห้ืศุࠢสฺ่๊แาࠢฦ์ࠥํๆศๅู้้ࠣไสࠢไ๎ฺࠥ็ศัฬࠤฬ๊สีใํีࠥอไฯษุอࠥฮใ้ัํࠤ฾์ฯไࠢ฼่๊อࠠศ่๊ࠤฯ๋ࠠโฯุࠤฬ๊ศา่ส้ัูࠦๅ๋ࠣ็ํี๊ࠡษ็ษฺีวาษอࠤࡡࡴࠠ࠲࠹࠱࠺ࠥࠦࠦࠡࠢ࠴࠼࠳ࡡ࠰࠮࠻ࡠࠤࠥࠬࠠࠡ࠳࠼࠲ࡠ࠶࠭࠴࡟ࠪற"))
	ExBIZiUjAN4lgm12s()
	return
def mag0BJDLNYjc1iKkpl8(s9ea72VfoygAOFRCWQTH3zmDuLPE=hWGMqtBy4wuLaVcj):
	phBvCeKLcg0UZdQPOESHAm = VBlawK4mgHSyLEn8iqhUkz5
	if LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠬࡥࡐࡓࡑࡅࡐࡊࡓ࡟ࠨல") not in s9ea72VfoygAOFRCWQTH3zmDuLPE:
		phBvCeKLcg0UZdQPOESHAm = fEXMiAyG3ql4vKB
		NN8u2B5iU3RMYheFy = jbQkTyxAerZR409gYFq(o1u5dij9UrcbXzVS8lwIWfKpnqM(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ள"),jeAby54c02TgG8zuivonX91(u"ࠧฯำ๋ะࠬழ"),jeAby54c02TgG8zuivonX91(u"ࠨวิืฬ๊ࠠๆึๆ่ฮ࠭வ"),QvgnCALNstmuUJiET(u"ࠩศีุอไࠡำึห้ฯࠧஶ"),zyvJMtBhrw(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ஷ"),KBkxSYaz93pu1(u"ࠫ์๊ࠠหำํำࠥษๆࠡฬิื้ࠦัิษ็อࠥหไ๊ࠢส่๊ฮัๆฮࠣ࠲࠳ࠦรๆࠢอี๏ีࠠฤ่ࠣฮึูไࠡ็ื็้ฯࠠๆ๊ฯ์ิฯࠠโ์ࠣห้ฮั็ษ่ะࠥลࠧஸ"))
		if NN8u2B5iU3RMYheFy in [-CnbBKmtF1x84q7AW(u"࠶൲"),LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"࠶൳")]: return
		elif NN8u2B5iU3RMYheFy==JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"࠱൴"):
			phBvCeKLcg0UZdQPOESHAm = VBlawK4mgHSyLEn8iqhUkz5
			s9ea72VfoygAOFRCWQTH3zmDuLPE = LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠬࡥࡐࡓࡑࡅࡐࡊࡓ࡟ࠨஹ")
	if phBvCeKLcg0UZdQPOESHAm:
		if NeO3CTLHrPfWUoIgy8Q(u"࠭࡟ࡑࡔࡒࡆࡑࡋࡍࡠࡑࡏࡈࡤ࠭஺") not in s9ea72VfoygAOFRCWQTH3zmDuLPE:
			dHPVDWfG4jX5e6QEo0CKh = XVmKrby29eCGMnlEY6jz0HNOR(QVDJLRlxNg127jMX(u"ࠧࡤࡧࡱࡸࡪࡸࠧ஻"),hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠨู๊฽ࠥอไๆึๆ่ฮࠦแ๋ࠢสุ่าไࠨ஼"),DJ1ICpbyR2(u"ࠩๅฬ้ࠦลาีส่ࠥอไิฮ็ࠤ฾๊๊ไࠢฦ๊ࠥะใาำࠣࠤ๋็ำࠡษ็ๅ฾๊ࠠศๆำ๎ࠥษูุษๆࠤฬ๊ๅีๅ็อࠥ࠴ࠠๅๅํࠤ๏ะๅࠡฬึะ๏๊่ࠠา๊ࠤฬ๊ๅีๅ็อࠥ็๊ࠡีฯ่ࠥอไฤะฺหฦ่ࠦศๆสืฯิฯศ็ࠣ࠲ࠥ๎ศะ๊้ࠤ์ึวࠡษ็ฮุา๊ๅࠢึ์ๆࠦสาี็ࠤ๊๊แࠡๆสࠤๆอฦะห้๋ࠣํࠠๅว้๋๊ࠥวࠡ์ะฮํ๐ฺࠠๆ์ࠤฬ๊ๅีๅ็อࠥอไห์ࠣฮึ๐ฯࠡษ้ฮࠥอไฦส็ห฿ูࠦ็้สࠤ࠳ࠦ็ๅࠢๅ้ฯࠦศหๅิหึࠦวๅ็ื็้ฯࠠภࠩ஽"))
			if dHPVDWfG4jX5e6QEo0CKh!=DJ1ICpbyR2(u"࠲൵"):
				BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,CnbBKmtF1x84q7AW(u"ࠪฮ๊ࠦลๅ฼สลࠥอไฦำึห้࠭ா"),hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"้๊ࠫริใࠣฬิ๎ๆࠡฬึะ๏๊ࠠศๆุ่่๊ษࠡใํࠤุาไࠡษ็วำ฽วย๋ࠢห้อำหะาห๊ࠦแศ่ࠣห้๋ศา็ฯࠤ้อ๋ࠠีอ฻๏฿ࠠๆ฻ิๅฮࠦวๅ็ื็้ฯ้ࠠๆสࠤา๊็ศࠢ็ห๋ࠦวๅ็หี๊าࠠๅษࠣ๎฾๊ๅࠡษ็฾๏ฮࠧி"))
				return
	BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,MMizeNH0AKu(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨீ"),KBkxSYaz93pu1(u"࠭แ๋ࠢสู่อิสࠢส่็อฯๆหࠣัฬ๎ไࠡล้ࠤฯ้สษࠢิืฬ๊ษࠡว็ํࠥอไๆสิ้ั่ࠦศึิัࠥ็๊่ษࠣห้๋ิไๆฬࠤศ๎ࠠศๆ่์฻๎ู๊ࠡศิฬࠦราัอࠤั๎วษ่๊ࠢࠥอไๆสิ้ัࠦแฦา้ࠤศ้สษࠢ฼๊ํอๆࠡสิ๎ิ้ࠠฤๆศ่่ะั้่ํࠤฬ๊ล๋็ํ่ࠥ๎สัๅิࠤํ๊วࠡฬ้ื๎ࠦร็ࠢส่๊ฮัๆฮ่ࠣฬฺ๊ࠦๆ่ࠤฬฺ๊๋สࠪு"))
	search = TrzfUidpv1LyAYqwexHJDuS(header=gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠧࡘࡴ࡬ࡸࡪࠦࡡࠡ࡯ࡨࡷࡸࡧࡧࡦࡧࠣࠤࠥอใหสࠣีุอไสࠩூ"),source=xjPuFK3EsIZSiobQ5X)
	if not search: return
	jjEwJpmd2v0oxBRP1Dyu = search
	if phBvCeKLcg0UZdQPOESHAm: type = FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠨࡒࡵࡳࡧࡲࡥ࡮ࠩ௃")
	else: type = EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠩࡐࡩࡸࡹࡡࡨࡧࠪ௄")
	G62uf8ZSIzBE = IYfvGAuH1W(type,jjEwJpmd2v0oxBRP1Dyu,VBlawK4mgHSyLEn8iqhUkz5,hWGMqtBy4wuLaVcj,sULh4NjakzI8He7xJCMGrql(u"ࠪࡉࡒࡇࡉࡍ࠯ࡉࡖࡔࡓ࠭ࡖࡕࡈࡖࡘ࠭௅"),s9ea72VfoygAOFRCWQTH3zmDuLPE)
	return
def aaFp08c2lEDbxSoYN():
	s9ea72VfoygAOFRCWQTH3zmDuLPE = xcChIL13BpR8WArNt9Pl0So(u"ࠫ์ึวࠡษ็ฬึ์วๆฮ่ࠣฬ๊้ࠦฮาࠤ้ํࠠฤ์ࠣื๏ืแาࠢํืฯ฼๊โࠢฦ๎๋ࠥอห๊ํหฯ࠴ࠠศๆหี๋อๅอࠢํืฯิฯๆࠢิ์ฬฮื๊ࠡอฺ๊๐ๆࠡๆ่ัฯ๎๊ศฬ้ࠣึ็ฺ่หࠣ฽้๏ࠠิ์ิๅึอสࠡะสีั๐ษ࠯ࠢส่อืๆศ็ฯࠤ฿๐ัࠡ็ึศํฺ๊่ࠠࠣว๏ࠦๅฮฬ๋๎ฬะࠠห็ࠣฮา๋๊ๅ้สࠤ฾๊้ࠡีํีๆืวห๋้ࠢํอโฺࠢัหึา๊ส้ࠢࠥํอโฺฺࠢีๆࠦหศๆฮࠦ࠳ࠦฬๆ์฼ࠤฬ๊ริ็สลࠥ๎วๅ็สี่อส๊ࠡสฺ่๎ั๊ࠡส่๊์ิ้ำสฮࠥํ๊ࠡะสูฮࠦศศืะหอํว࠯ࠢส่อืๆศ็ฯࠤ้อ๋่ࠠอ๋่ࠦอใ๊ๅࠤฬ๊ืษ฻ࠣ์ฬ๊ๆีำࠣ์็อๆ้่ࠣห้ษไโ์ฬࠤ้๊ๅๅๅํอࠥอไาไ่๎ฮࠦࡄࡎࡅࡄࠤสึวࠡๅส๊๊ࠥฯ๋ๅุ่ࠣ๎้ࠡะสูฮࠦศศๆิ์ฬฮื๊ࠡส่ฯ฼วๆ์้ࠤฬ๊ฮศำฯ๎ฮࠦแศๆิะฬวࠠศๆอ์ฬ฻ไࠡ็฼ࠤสีวาห๋ࠣีํࠠศๆึ๎ึ็ัศฬࠣ์ฬ๊ๅ้ษๅ฽ࠥอไฯษิะ๏ฯ࠮้ࠡำหࠥอไษำ้ห๊า่๊ࠠࠣฬอูวุห้ࠣฯ฻แฮࠢ็้ํอโฺࠢส่ํ๐ศࠨெ")
	yBv4YaSomFrkejwgNA7pDnKudCz(A6dMB1FlgxVivJ2fk9C(u"ࠬࡸࡩࡨࡪࡷࠫே"),QvgnCALNstmuUJiET(u"࠭อใ๊ๅࠤฬ๊ืษ฻ࠣ์ฬ๊ๆีำࠣ์็อๆ้่ࠣห้ษไโ์ฬࠤ้๊ๅๅๅํอࠥอไาไ่๎ฮ࠭ை"),s9ea72VfoygAOFRCWQTH3zmDuLPE,jeAby54c02TgG8zuivonX91(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪ௉"))
	s9ea72VfoygAOFRCWQTH3zmDuLPE = e2qDYgipPmTw4KvBLnochr(u"ࠨࡖ࡫࡭ࡸࠦࡰࡳࡱࡪࡶࡦࡳࠠࡥࡱࡨࡷࠥࡴ࡯ࡵࠢ࡫ࡳࡸࡺࠠࡢࡰࡼࠤࡨࡵ࡮ࡵࡧࡱࡸࠥࡵ࡮ࠡࡣࡱࡽࠥࡹࡥࡳࡸࡨࡶ࠳ࠦࡉࡵࠢࡲࡲࡱࡿࠠࡶࡵࡨࡷࠥࡲࡩ࡯࡭ࡶࠤࡹࡵࠠࡦ࡯ࡥࡩࡩࡪࡥࡥࠢࡦࡳࡳࡺࡥ࡯ࡶࠣࡸ࡭ࡧࡴࠡࡹࡤࡷࠥࡻࡰ࡭ࡱࡤࡨࡪࡪࠠࡵࡱࠣࡴࡴࡶࡵ࡭ࡣࡵࠤࡴࡴ࡬ࡪࡰࡨࠤࡻ࡯ࡤࡦࡱࠣ࡬ࡴࡹࡴࡪࡰࡪࠤࡸ࡯ࡴࡦࡵ࠱ࠤࡆࡲ࡬ࠡࡶࡵࡥࡩ࡫࡭ࡢࡴ࡮ࡷ࠱ࠦࡶࡪࡦࡨࡳࡸ࠲ࠠࡵࡴࡤࡨࡪࠦ࡮ࡢ࡯ࡨࡷ࠱ࠦࡳࡦࡴࡹ࡭ࡨ࡫ࠠ࡮ࡣࡵ࡯ࡸ࠲ࠠࡤࡱࡳࡽࡷ࡯ࡧࡩࡶࡨࡨࠥࡽ࡯ࡳ࡭࠯ࠤࡱࡵࡧࡰࡵࠣࡶࡪ࡬ࡥࡳࡧࡱࡧࡪࡪࠠࡩࡧࡵࡩ࡮ࡴࠠࡣࡧ࡯ࡳࡳ࡭ࠠࡵࡱࠣࡸ࡭࡫ࡩࡳࠢࡵࡩࡸࡶࡥࡤࡶ࡬ࡺࡪࠦ࡯ࡸࡰࡨࡶࡸࠦ࠯ࠡࡥࡲࡱࡵࡧ࡮ࡪࡧࡶ࠲࡚ࠥࡨࡦࠢࡳࡶࡴ࡭ࡲࡢ࡯ࠣ࡭ࡸࠦ࡮ࡰࡶࠣࡶࡪࡹࡰࡰࡰࡶ࡭ࡧࡲࡥࠡࡨࡲࡶࠥࡽࡨࡢࡶࠣࡳࡹ࡮ࡥࡳࠢࡳࡩࡴࡶ࡬ࡦࠢࡸࡴࡱࡵࡡࡥࠢࡷࡳࠥ࠹ࡲࡥࠢࡳࡥࡷࡺࡹࠡࡵ࡬ࡸࡪࡹ࠮࡙ࠡࡨࠤࡺࡸࡧࡦࠢࡤࡰࡱࠦࡣࡰࡲࡼࡶ࡮࡭ࡨࡵࠢࡲࡻࡳ࡫ࡲࡴ࠮ࠣࡸࡴࠦࡲࡦࡥࡲ࡫ࡳ࡯ࡺࡦࠢࡷ࡬ࡦࡺࠠࡵࡪࡨࠤࡱ࡯࡮࡬ࡵࠣࡧࡴࡴࡴࡢ࡫ࡱࡩࡩࠦࡷࡪࡶ࡫࡭ࡳࠦࡴࡩ࡫ࡶࠤࡵࡸ࡯ࡨࡴࡤࡱࠥࡧࡲࡦࠢ࡯ࡳࡨࡧࡴࡦࡦࠣࡷࡴࡳࡥࡸࡪࡨࡶࡪࠦࡥ࡭ࡵࡨࠤࡴࡴࠠࡵࡪࡨࠤࡼ࡫ࡢࠡࡱࡵࠤࡻ࡯ࡤࡦࡱࠣࡩࡲࡨࡥࡥࡦࡨࡨࠥࡧࡲࡦࠢࡩࡶࡴࡳࠠࡰࡶ࡫ࡩࡷࠦࡶࡢࡴ࡬ࡳࡺࡹࠠࡴ࡫ࡷࡩࡸ࠴ࠠࡊࡨࠣࡽࡴࡻࠠࡩࡣࡹࡩࠥࡧ࡮ࡺࠢ࡯ࡩ࡬ࡧ࡬ࠡ࡫ࡶࡷࡺ࡫ࡳࠡࡲ࡯ࡩࡦࡹࡥࠡࡥࡲࡲࡹࡧࡣࡵࠢࡤࡴࡵࡸ࡯ࡱࡴ࡬ࡥࡹ࡫ࠠ࡮ࡧࡧ࡭ࡦࠦࡦࡪ࡮ࡨࠤࡴࡽ࡮ࡦࡴࡶࠤ࠴ࠦࡨࡰࡵࡷࡩࡷࡹ࠮ࠡࡖ࡫࡭ࡸࠦࡰࡳࡱࡪࡶࡦࡳࠠࡪࡵࠣࡷ࡮ࡳࡰ࡭ࡻࠣࡥࠥࡽࡥࡣࠢࡥࡶࡴࡽࡳࡦࡴ࠱ࠫொ")
	yBv4YaSomFrkejwgNA7pDnKudCz(rwQN9AKhLCuMfHxjlbX0U(u"ࠩ࡯ࡩ࡫ࡺࠧோ"),JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠪࡈ࡮࡭ࡩࡵࡣ࡯ࠤࡒ࡯࡬࡭ࡧࡱࡲ࡮ࡻ࡭ࠡࡅࡲࡴࡾࡸࡩࡨࡪࡷࠤࡆࡩࡴࠡࠪࡇࡑࡈࡇࠩࠨௌ"),s9ea72VfoygAOFRCWQTH3zmDuLPE,jeAby54c02TgG8zuivonX91(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺ்ࠧ"))
	return
def T4T7vDhbYmgAFESO8xotk():
	BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,DJ1ICpbyR2(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ௎"),ITvnUAMXsyb4eO(u"࠭วๅสิ๊ฬ๋ฬࠡๆสࠤ๏็อึࠢื๋ฬีษࠡษ็ฮู็๊าࠢ฼๊ิࠦวๅษอูฬ๊ࠠษษ็้ํอโฺࠢสฺ่๊แาหࠣ์้ํะศࠢไ๎ࠥำวๅ๋ࠢะํีࠠี้สำฮฺ๋ࠦำูࠣา๐อสࠢฦ์๋ࠥๆห้ํอࠥอไึๆสั๏ฯࠠฤ๊้ࠣื๐แสࠢไห๋ࠦ็ัษ่๋๊้ࠣࠦไไࠤฬ๊ัษูࠣห้๋ิโำࠣ์้์๋๊ࠠๅๅࠥ฿ๅๅࠢส่อืๆศ็ฯࠫ௏"))
	SQ8sJcaWwy1LotFZMUPlD2Tx()
	return
def OO4dAhD7LMsXH5YrU3kZipfx0():
	qkrP6CTSuMFneV0EfAUgxm1RoWt,LwBM9FdHl8aE3iDh5IgzY02kZ,jdkSvGmCp0WOLoqJUYiTAZ,UcBD7WEkIXbmzFJe8,rLkMc5sauQO3lw,n7tjUD195b,MxIdwCQOKl25L7stgEZ0PVhiHWu = hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj
	l17Sn3hK59WV,TbuXvM5UVjkAlwsaefSgB8IohK9,PflOZKhFj5i91xHnYIrRozsedDQ,QzNRFDWuscK9ykMoH = {LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠧࡢࠩௐ"):QvgnCALNstmuUJiET(u"ࠨࡣࠪ௑")},{},[],{}
	url = u6rbxnyjTl7I[rwQN9AKhLCuMfHxjlbX0U(u"ࠩࡓ࡝࡙ࡎࡏࡏࠩ௒")][bXukYxQ4aHw]
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(D8V7AhLkSQYzo,CnbBKmtF1x84q7AW(u"ࠪࡔࡔ࡙ࡔࠨ௓"),url,l17Sn3hK59WV,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,QVDJLRlxNg127jMX(u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠳ࡕࡔࡃࡊࡉࡤࡘࡅࡑࡑࡕࡘ࠲࠷ࡳࡵࠩ௔"))
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	mMQ3FkNVa4IlxqY = mMQ3FkNVa4IlxqY.replace(A6dMB1FlgxVivJ2fk9C(u"࡛ࠬ࡮ࡪࡶࡨࡨ࡙ࠥࡴࡢࡶࡨࡷࠬ௕"),rwQN9AKhLCuMfHxjlbX0U(u"࠭ࡕࡔࡃࠪ௖"))
	mMQ3FkNVa4IlxqY = mMQ3FkNVa4IlxqY.replace(zyvJMtBhrw(u"ࠧࡖࡰ࡬ࡸࡪࡪࠠࡌ࡫ࡱ࡫ࡩࡵ࡭ࠨௗ"),jeAby54c02TgG8zuivonX91(u"ࠨࡗࡎࠫ௘"))
	mMQ3FkNVa4IlxqY = mMQ3FkNVa4IlxqY.replace(zyvJMtBhrw(u"ࠩࡘࡲ࡮ࡺࡥࡥࠢࡄࡶࡦࡨࠠࡆ࡯࡬ࡶࡦࡺࡥࡴࠩ௙"),A6dMB1FlgxVivJ2fk9C(u"࡙ࠪࡆࡋࠧ௚"))
	mMQ3FkNVa4IlxqY = mMQ3FkNVa4IlxqY.replace(KNIvHPjUbhr(u"ࠫࡘࡧࡵࡥ࡫ࠣࡅࡷࡧࡢࡪࡣࠪ௛"),S1SgCFYGJeMvfp5iZXK(u"ࠬࡑࡓࡂࠩ௜"))
	mMQ3FkNVa4IlxqY = mMQ3FkNVa4IlxqY.replace(HHoGx7Flus60(u"࠭ࡎࡰࡴࡷ࡬ࠥࡓࡡࡤࡧࡧࡳࡳ࡯ࡡࠨ௝"),o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠧࡏ࠰ࡐࡥࡨ࡫ࡤࡰࡰ࡬ࡥࠬ௞"))
	mMQ3FkNVa4IlxqY = mMQ3FkNVa4IlxqY.replace(wwPrSDa21lUh(u"ࠨ࡙ࡨࡷࡹ࡫ࡲ࡯ࠢࡖࡥ࡭ࡧࡲࡢࠩ௟"),HHoGx7Flus60(u"࡚ࠩ࠲ࡘࡧࡨࡢࡴࡤࠫ௠"))
	mMQ3FkNVa4IlxqY = mMQ3FkNVa4IlxqY.replace(e2qDYgipPmTw4KvBLnochr(u"ࠪࡣࡤࡥࠧ௡"),FqcVAkh7WjIXHdDKf8nvuyRo)
	try: heut5lXr1nHT2wcQLkjpyI = Cy9ow3c21nABMjzqeaIT(e2qDYgipPmTw4KvBLnochr(u"ࠫࡱ࡯ࡳࡵࠩ௢"),mMQ3FkNVa4IlxqY)
	except:
		BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ௣"),ITvnUAMXsyb4eO(u"࠭แีๆࠣๅ๏ࠦฬๅส้ࠣาะ่๋ษอࠤฯ่ั๋ำࠣห้อำหะาห๊࠭௤"))
		return
	anOt0YUVpJ1PBQbA3,OLHI8uzpJWYoy4hx6fDt,liuOr2EVxz9ej374tCH = heut5lXr1nHT2wcQLkjpyI
	QzNRFDWuscK9ykMoH = {}
	ArhxHsIzBv1c = [dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠧࡄࡃࡓࡘࡈࡎࡁࡊࡆࠪ௥"),rwQN9AKhLCuMfHxjlbX0U(u"ࠨࡅࡄࡔ࡙ࡉࡈࡂࡖࡒࡏࡊࡔࠧ௦")]
	UyMz5pALSDoVj = [sULh4NjakzI8He7xJCMGrql(u"ࠩࡄࡐࡑ࠭௧"),zyvJMtBhrw(u"ࠪࡔ࡞࡚ࡈࡐࡐࠪ௨"),mkHKSQvjWr5BTcM3wVY(u"ࠫࡎࡔࡓࡕࡃࡏࡐࠬ௩"),CnbBKmtF1x84q7AW(u"ࠬࡓࡅࡕࡔࡒࡔࡔࡒࡉࡔࠩ௪"),DJ1ICpbyR2(u"࠭ࡒࡆࡒࡒࡗࠬ௫")]+ArhxHsIzBv1c+JaefAXmLzMRSjqVhTi0rQPb17IB8U+wb7ZkKqsRIfjgNdBtu3T8HvCiX
	for ITlpOFqLn7W2hYkdijCogm,GGh6C092XTQdMHjPuxm,zF28xe6pVBJQKCWAYZ in OLHI8uzpJWYoy4hx6fDt:
		zF28xe6pVBJQKCWAYZ = emr1Lf523Ti0OtcNgxP(zF28xe6pVBJQKCWAYZ)
		zF28xe6pVBJQKCWAYZ = zF28xe6pVBJQKCWAYZ.strip(Mpsm2VF1OBnCRvK3qf6).strip(CnbBKmtF1x84q7AW(u"ࠧࠡ࠰ࠪ௬"))
		UcBD7WEkIXbmzFJe8 += NXMOzZjYsmS9pf+soMVfbr6WtpNlcSA+ITlpOFqLn7W2hYkdijCogm+EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠨ࠼ࠣࠫ௭")+YYSh2J6BIrsm8+zF28xe6pVBJQKCWAYZ+NXMOzZjYsmS9pf
		if GGh6C092XTQdMHjPuxm.isdigit():
			QzNRFDWuscK9ykMoH[ITlpOFqLn7W2hYkdijCogm] = int(GGh6C092XTQdMHjPuxm)
			if int(GGh6C092XTQdMHjPuxm)>OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"࠳࠳࠴൶"): GGh6C092XTQdMHjPuxm = dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠩ࡫࡭࡬࡮ࡵࡴࡣࡪࡩࠬ௮")
			else: GGh6C092XTQdMHjPuxm = mkHKSQvjWr5BTcM3wVY(u"ࠪࡰࡴࡽࡵࡴࡣࡪࡩࠬ௯")
		if ITlpOFqLn7W2hYkdijCogm not in UyMz5pALSDoVj:
			if   GGh6C092XTQdMHjPuxm==LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠫ࡭࡯ࡧࡩࡷࡶࡥ࡬࡫ࠧ௰"): qkrP6CTSuMFneV0EfAUgxm1RoWt += FqcVAkh7WjIXHdDKf8nvuyRo+ITlpOFqLn7W2hYkdijCogm
			elif GGh6C092XTQdMHjPuxm==EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠬࡲ࡯ࡸࡷࡶࡥ࡬࡫ࠧ௱"): LwBM9FdHl8aE3iDh5IgzY02kZ += FqcVAkh7WjIXHdDKf8nvuyRo+ITlpOFqLn7W2hYkdijCogm
	De2hmNGPwlvXaTB,W973BECw1DN2IKumOMzGAdJhZlf,vQJIK0tgYBCADczT8O7 = list(zip(*OLHI8uzpJWYoy4hx6fDt))
	for ITlpOFqLn7W2hYkdijCogm in sorted(jxyKkBY2FhC6czAUNXe5i):
		if ITlpOFqLn7W2hYkdijCogm not in De2hmNGPwlvXaTB:
			UcBD7WEkIXbmzFJe8 += NXMOzZjYsmS9pf+soMVfbr6WtpNlcSA+ITlpOFqLn7W2hYkdijCogm+jeAby54c02TgG8zuivonX91(u"࠭࠺ࠡࠩ௲")+YYSh2J6BIrsm8+e2qDYgipPmTw4KvBLnochr(u"ࠧๅษࠣ๎ําฯࠨ௳")+QvgnCALNstmuUJiET(u"ࠨ࡞ࡱࡠࡳ࠭௴")
			if ITlpOFqLn7W2hYkdijCogm not in UyMz5pALSDoVj: jdkSvGmCp0WOLoqJUYiTAZ += FqcVAkh7WjIXHdDKf8nvuyRo+ITlpOFqLn7W2hYkdijCogm
	for zF28xe6pVBJQKCWAYZ,MkNO5By27JAx0gtzdLHUp in anOt0YUVpJ1PBQbA3:
		zF28xe6pVBJQKCWAYZ = emr1Lf523Ti0OtcNgxP(zF28xe6pVBJQKCWAYZ)
		rLkMc5sauQO3lw += zF28xe6pVBJQKCWAYZ+XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠩ࠽ࠤࠬ௵")+hXB0vKVQ5PRI91SDTprMdfuHEm4+str(MkNO5By27JAx0gtzdLHUp)+YYSh2J6BIrsm8+A6dMB1FlgxVivJ2fk9C(u"ࠪࠤࠥࠦࠧ௶")
	qkrP6CTSuMFneV0EfAUgxm1RoWt = qkrP6CTSuMFneV0EfAUgxm1RoWt.strip(Mpsm2VF1OBnCRvK3qf6)
	LwBM9FdHl8aE3iDh5IgzY02kZ = LwBM9FdHl8aE3iDh5IgzY02kZ.strip(Mpsm2VF1OBnCRvK3qf6)
	jdkSvGmCp0WOLoqJUYiTAZ = jdkSvGmCp0WOLoqJUYiTAZ.strip(Mpsm2VF1OBnCRvK3qf6)
	hV46DQRUxn3ASjGbckw9gFEP = qkrP6CTSuMFneV0EfAUgxm1RoWt+FqcVAkh7WjIXHdDKf8nvuyRo+LwBM9FdHl8aE3iDh5IgzY02kZ
	L7FtKC923VAjgQUvoZkBIs5OT4J  = hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"๊ࠫ๎วใ฻๊ࠣัำࠠศๆหี๋อๅอࠢหฮูเ๊ๅࠢไ๎ิ๐่่ษอࠤๆ๐ࠠ࠴ࠢฦ๎ฬ๋ࠠศๆ่ห฻๐ษࠨ௷")+NXMOzZjYsmS9pf+rwQN9AKhLCuMfHxjlbX0U(u"ࠬ๎็ัษ้ࠣ฾์ว่ࠢศิฬࠦไะ์ๆࠤฺ๊ใๅหࠣๅ์๐ࠠๅ์ึฮ๋ࠥๆࠡษ็ฬึ์วๆฮࠪ௸")+NXMOzZjYsmS9pf
	L7FtKC923VAjgQUvoZkBIs5OT4J += hXB0vKVQ5PRI91SDTprMdfuHEm4+hV46DQRUxn3ASjGbckw9gFEP+YYSh2J6BIrsm8+EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"࠭࡜࡯࡞ࡱࠫ௹")
	L7FtKC923VAjgQUvoZkBIs5OT4J += wwPrSDa21lUh(u"ࠧๆ๊สๆ฾ࠦไๆࠢํุ฿๊ࠠศๆหี๋อๅอ่๊ࠢ์อࠠโ์า๎ํํวหࠢไ๎ࠥ࠹ࠠฤ์ส้ࠥอไๆษู๎ฮ࠭௺")+NXMOzZjYsmS9pf+xcChIL13BpR8WArNt9Pl0So(u"ࠨ๊๊ิฬࠦๅฺ่ส๋ࠥออห็ส่้ࠥศ๋ำࠣ์ั๎ฯࠡ็ื็้ฯࠠโ์ࠣห้ฮั็ษ่ะࠬ௻")+NXMOzZjYsmS9pf
	L7FtKC923VAjgQUvoZkBIs5OT4J += hXB0vKVQ5PRI91SDTprMdfuHEm4+jdkSvGmCp0WOLoqJUYiTAZ+YYSh2J6BIrsm8
	MY0ZES24W8,h2VKXFiBA0xnjGrZDdbE,TAOqtzYG9PcRC8xDbdjVuQv,VBoj4lxgfkJGXye6nrcC = MMizeNH0AKu(u"࠳൷"),MMizeNH0AKu(u"࠳൷"),MMizeNH0AKu(u"࠳൷"),MMizeNH0AKu(u"࠳൷")
	all = QzNRFDWuscK9ykMoH[SqrG5mU3j96ldsFpExobw40TJY(u"ࠩࡄࡐࡑ࠭௼")]
	if CnbBKmtF1x84q7AW(u"ࠪࡔ࡞࡚ࡈࡐࡐࠪ௽") in list(QzNRFDWuscK9ykMoH.keys()): MY0ZES24W8 = QzNRFDWuscK9ykMoH[EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠫࡕ࡟ࡔࡉࡑࡑࠫ௾")]
	if OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠬࡏࡎࡔࡖࡄࡐࡑ࠭௿") in list(QzNRFDWuscK9ykMoH.keys()): h2VKXFiBA0xnjGrZDdbE = QzNRFDWuscK9ykMoH[rwQN9AKhLCuMfHxjlbX0U(u"࠭ࡉࡏࡕࡗࡅࡑࡒࠧఀ")]
	if QvgnCALNstmuUJiET(u"ࠧࡎࡇࡗࡖࡔࡖࡏࡍࡋࡖࠫఁ") in list(QzNRFDWuscK9ykMoH.keys()): TAOqtzYG9PcRC8xDbdjVuQv = QzNRFDWuscK9ykMoH[gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠨࡏࡈࡘࡗࡕࡐࡐࡎࡌࡗࠬం")]
	if o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠩࡕࡉࡕࡕࡓࠨః") in list(QzNRFDWuscK9ykMoH.keys()): VBoj4lxgfkJGXye6nrcC = QzNRFDWuscK9ykMoH[gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠪࡖࡊࡖࡏࡔࠩఄ")]
	d3xFLHsi6WhYKmQtq19vpGu5nl = all-MY0ZES24W8-h2VKXFiBA0xnjGrZDdbE-TAOqtzYG9PcRC8xDbdjVuQv-VBoj4lxgfkJGXye6nrcC
	QwGpLVOkc0MPodWfiYsTj,HoYv3TExO2 = liuOr2EVxz9ej374tCH[ybdv7XcT3lxF6QezULwCAGk]
	QwGpLVOkc0MPodWfiYsTj,p63P8yrkLfFSGOc = liuOr2EVxz9ej374tCH[bXukYxQ4aHw]
	RRr5CJzVnb8ZUXv10QiFIt = HoYv3TExO2-p63P8yrkLfFSGOc
	MxIdwCQOKl25L7stgEZ0PVhiHWu += soMVfbr6WtpNlcSA+str(p63P8yrkLfFSGOc)+YYSh2J6BIrsm8+CnbBKmtF1x84q7AW(u"ࠫฬู๊ะัࠣห้ำโ๋ไํࠤ้๊รอ้ีอࠥࡀࠠࠨఅ")
	MxIdwCQOKl25L7stgEZ0PVhiHWu += NXMOzZjYsmS9pf+soMVfbr6WtpNlcSA+str(RRr5CJzVnb8ZUXv10QiFIt)+YYSh2J6BIrsm8+rwQN9AKhLCuMfHxjlbX0U(u"ࠬฮวิฬัำฬ๋ࠠࡱࡴࡲࡼࡾࠦร้ࠢࡹࡴࡳࠦ࠺ࠡࠩఆ")
	MxIdwCQOKl25L7stgEZ0PVhiHWu += NXMOzZjYsmS9pf+soMVfbr6WtpNlcSA+str(HoYv3TExO2)+YYSh2J6BIrsm8+mkHKSQvjWr5BTcM3wVY(u"࠭วๅ฻าำࠥอไไๆํࠤ้าๅ๋฻ࠣห้ษฬ่ิฬࠤ࠿ࠦࠧఇ")
	MxIdwCQOKl25L7stgEZ0PVhiHWu += NXMOzZjYsmS9pf+soMVfbr6WtpNlcSA+str(len(liuOr2EVxz9ej374tCH[KBkxSYaz93pu1(u"࠶൸"):]))+YYSh2J6BIrsm8+GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ฺࠧัาࠤฬ๊ฯ้ๆࠣห้ะ๊ࠡใํ๋ฬࠦรอ้ีอࠥࡀࠠ࡝ࡰ࡟ࡲࠬఈ")
	for ZG7ywHXrqjgUomtR45kuL,EPuMlX4RDWry9L in liuOr2EVxz9ej374tCH[wwPrSDa21lUh(u"࠷൹"):]:
		ZG7ywHXrqjgUomtR45kuL = emr1Lf523Ti0OtcNgxP(ZG7ywHXrqjgUomtR45kuL)
		ZG7ywHXrqjgUomtR45kuL = ZG7ywHXrqjgUomtR45kuL.strip(Mpsm2VF1OBnCRvK3qf6).strip(S1SgCFYGJeMvfp5iZXK(u"ࠨࠢ࠱ࠫఉ"))
		MxIdwCQOKl25L7stgEZ0PVhiHWu += ZG7ywHXrqjgUomtR45kuL+e2qDYgipPmTw4KvBLnochr(u"ࠩ࠽ࠤࠬఊ")+hXB0vKVQ5PRI91SDTprMdfuHEm4+str(EPuMlX4RDWry9L)+YYSh2J6BIrsm8+NeO3CTLHrPfWUoIgy8Q(u"ࠪࠤࠥࠦࠧఋ")
	n7tjUD195b += soMVfbr6WtpNlcSA+str(d3xFLHsi6WhYKmQtq19vpGu5nl)+YYSh2J6BIrsm8+NeO3CTLHrPfWUoIgy8Q(u"ࠫๆ๐ฯ๋๊๊หฯࠦวีฬ฽่ฯࠦ࠺ࠡࠩఌ")
	n7tjUD195b += NXMOzZjYsmS9pf+soMVfbr6WtpNlcSA+str(MY0ZES24W8)+YYSh2J6BIrsm8+xcChIL13BpR8WArNt9Pl0So(u"ࠬ฽ไษษอࠤุ๐ัโำࠣฬฬ๐ห้่ࠣ࠾ࠥ࠭఍")
	n7tjUD195b += NXMOzZjYsmS9pf+soMVfbr6WtpNlcSA+str(VBoj4lxgfkJGXye6nrcC)+YYSh2J6BIrsm8+wwPrSDa21lUh(u"࠭ืๅสสฮู๊ࠥาใิࠤฬ๊ๅิฬ๋ำ฾ࠦ࠺ࠡࠩఎ")
	n7tjUD195b += NXMOzZjYsmS9pf+soMVfbr6WtpNlcSA+str(h2VKXFiBA0xnjGrZDdbE)+YYSh2J6BIrsm8+sULh4NjakzI8He7xJCMGrql(u"ࠧหอห๎ฯࠦสุสํๆ้่ࠥะ์ࠣ฽๊อฯࠡ࠼ࠣࠫఏ")
	n7tjUD195b += NXMOzZjYsmS9pf+soMVfbr6WtpNlcSA+str(TAOqtzYG9PcRC8xDbdjVuQv)+YYSh2J6BIrsm8+CnbBKmtF1x84q7AW(u"ࠨฬฮฬ๏ะࠠอๆาࠤ๊ะั้สุู๋่ࠦๆษาࠤ࠿ࠦࠧఐ")
	n7tjUD195b += NXMOzZjYsmS9pf+soMVfbr6WtpNlcSA+str(len(anOt0YUVpJ1PBQbA3))+YYSh2J6BIrsm8+S1SgCFYGJeMvfp5iZXK(u"ࠩา์้ࠦิ฻ๆอࠤๆ๐ฯ๋๊๊หฯࠦ࠺ࠡࠩ఑")
	n7tjUD195b += o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠪࡠࡳࡢ࡮ࠨఒ")+rLkMc5sauQO3lw
	yBv4YaSomFrkejwgNA7pDnKudCz(GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫఓ"),MMizeNH0AKu(u"ࠬ฿ฯะࠢส่ศา็ำหࠣห้ะ๊ࠡษึฮำีๅห๊ࠢิฬࠦวๅสิ๊ฬ๋ฬࠡใํࠤ࠸ࠦร๋ษ่ࠤฬ๊ๅศุํอࠥ็๊ࠡษ็฽ฬ๊ๅࠡๅ็๋ࠬఔ"),MxIdwCQOKl25L7stgEZ0PVhiHWu,OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩక"))
	yBv4YaSomFrkejwgNA7pDnKudCz(NeO3CTLHrPfWUoIgy8Q(u"ࠧࡤࡧࡱࡸࡪࡸࠧఖ"),KNIvHPjUbhr(u"ࠨ฻าำࠥอไโ์า๎ํํวหࠢส่ฯ๐ࠠี฼็๋ฬࠦ็ัษࠣห้ฮั็ษ่ะࠥ็๊ࠡ࠵ࠣว๏อๅࠡษ็้ฬ฼๊สࠢไ๎ࠥอไฺษ็้้ࠥไ่ࠩగ"),n7tjUD195b,KNIvHPjUbhr(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬఘ"))
	yBv4YaSomFrkejwgNA7pDnKudCz(LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠪࡧࡪࡴࡴࡦࡴࠪఙ"),A6dMB1FlgxVivJ2fk9C(u"๊ࠫ๎วใ฻ࠣหูะฺๅฬࠣๅ๏ࠦ࠳ࠡลํห๊ࠦวๅ็สฺ๏ฯࠠโ์ࠣห้฿วๅ็ࠣ็้ํࠧచ"),L7FtKC923VAjgQUvoZkBIs5OT4J,mkHKSQvjWr5BTcM3wVY(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨఛ"))
	yBv4YaSomFrkejwgNA7pDnKudCz(o1u5dij9UrcbXzVS8lwIWfKpnqM(u"࠭࡬ࡦࡨࡷࠫజ"),DJ1ICpbyR2(u"ࠧฤ฻็ํࠥอไะ๊็ࠤฬ๊ส๋ࠢไ๎ࠥ࠹ࠠฤ์ส้ࠥอไๆษู๎ฮࠦวิฬัำ๊ะࠠศๆหี๋อๅอࠩఝ"),UcBD7WEkIXbmzFJe8,LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࡣࡱࡵ࡮ࡨࠩఞ"))
	return
def RRfGkMuH2JSXcgj1():
	jjEwJpmd2v0oxBRP1Dyu = gDuGMR3z1aV6YdLmCpiO8Kl(u"๊ࠩิฬࠦวๅสิ๊ฬ๋ฬࠡ์฼้้ࠦวโุ็ࠤออำหะาห๊ࠦฬๅัࠣ็ํี๊ࠡࠪࡎࡳࡩ࡯ࠠࡔ࡭࡬ࡲ࠮ࠦวๅาํࠤฬูๅ่࡞ࡱࠫట")+soMVfbr6WtpNlcSA+gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠪࡷࡰ࡯࡮࠯࡯ࡨࡸࡷࡵࡰࡰ࡮࡬ࡷࡊࡓࡁࡅࠩఠ")+YYSh2J6BIrsm8+S1SgCFYGJeMvfp5iZXK(u"ࠫࡡࡴ࡜࡯࡞ࡱࠤํ๋ๅไ่ࠣฮะฮ๊ห้ࠣฬฬูสฯัส้๋ࠥำห๊า฽ࠥ฿ๅศัࠣࡉࡒࡇࡄࠡࡔࡨࡴࡴࡹࡩࡵࡱࡵࡽࠥษ่ࠡฬะ้๏๊็ࠡ็้ࡠࡳ࠭డ")+soMVfbr6WtpNlcSA+rwQN9AKhLCuMfHxjlbX0U(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡵࡩࡵࡵ࠮ࡶ࡭࠱ࡸࡴ࠭ఢ")+YYSh2J6BIrsm8+A6dMB1FlgxVivJ2fk9C(u"࠭࡜࡯࡞ࡱࡠࡳࠦ็ั้ࠣห้ืำศๆฬࠤํเ๊า้สࠤ่ั๊า่ࠢ์ั๎ฯสࠢไ๎่ࠥวว็ฬࠤำีๅศฬࠣห้ฮั็ษ่ะࠥ๎วๅ็ี๎ิࠦรุ๋สࠤ๊๎ฬ้ัࠣๅ๏ࠦโศศ่อࠥษฬ้สฬࠤฬ๊ศา่ส้ั࠭ణ")
	yBv4YaSomFrkejwgNA7pDnKudCz(LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠧࡤࡧࡱࡸࡪࡸࠧత"),o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫథ"),jjEwJpmd2v0oxBRP1Dyu,XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬద"))
	return
def ZZf2P84FwEJgrslpGVvjc1z():
	jjEwJpmd2v0oxBRP1Dyu = DJ1ICpbyR2(u"ࠪห้ืวษูํ๊ࠥษฯ็ษ๊ࠤๆ๐็ๆษࠣฮ฼ฮ๊ใࠢๆ์ิ๐ฺࠠ็สำࠥ๎็้ࠢ฼ฬฬืษࠡ฻้ࠤฯัศ๋ฬࠣ็ฬ๋ไࠡษ๋ฮํ๋วห์ๆ๎๊ࠥศา่ส้ัࠦใ้ัํࠤํู๋่ࠢสฺฬ็ษࠡ฻่หิࠦไๅใํำ๏๎็ศฬࠣห้฿ัษ์ฬࠤํู๋่ࠢสฺฬ็ษࠡฮ็ำ๋ࠥสา๊ห์ฺู้ࠠ็สำࠥ๎ๅฺ้ࠣห฻อแส่ࠢืฯ๎ฯฺࠢ฼้ฬี้ࠠใํ๋ࠥษ๊ืษࠣะ๊๐ูࠡษ฼ำฬีสࠡๅ๋ำ๏ࠦวๅ็ฺ่ํฮษࠡๆ฼้้ࠦศา่ส้ัูࠦๆษาࠤํ้ไ่ษࠣฮฯ๋ࠠศ๊อ์๊อส๋ๅํหࠥ๎ไศࠢอัฯอฬࠡลํࠤ๋๎ูࠡ็้ࠤฬ๊ฮษำฬࠤๆ๐ࠠไ๊า๎ࠥษ่ࠡษ็าอืษࠡใํࠤฯัศ๋ฬࠣว฻อแศฬࠣ็ํี๊ࠨధ")+NXMOzZjYsmS9pf+hXB0vKVQ5PRI91SDTprMdfuHEm4+u6rbxnyjTl7I[wwPrSDa21lUh(u"ࠫࡐࡕࡄࡊࡇࡐࡅࡉࡥࡁࡑࡒࠪన")][ybdv7XcT3lxF6QezULwCAGk]+YYSh2J6BIrsm8+o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠬࠦࠠࠡࠢࠣࠤศ๎ࠠࠡࠢࠣࠤࠥ࠭఩")+hXB0vKVQ5PRI91SDTprMdfuHEm4+u6rbxnyjTl7I[A6dMB1FlgxVivJ2fk9C(u"࠭ࡋࡐࡆࡌࡉࡒࡇࡄࡠࡃࡓࡔࠬప")][bXukYxQ4aHw]+YYSh2J6BIrsm8
	jjEwJpmd2v0oxBRP1Dyu += XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠧ࡝ࡰ࡟ࡲࡡࡴวๅำสฬ฼ࠦระ่ส๋ࠥํ่ࠡษ็ืํืำࠡษ็ิ๏๊ࠦฮฬสะ์ࠦๅะ์ิࠤ๊๊แศฬࠣ็ํี๊ࠡๆอฯอ๐สࠡสิ๊ฬ๋ฬࠡ฻่หิࠦศศๆฺี๏่ษࠡษ็ฮ็๊๊ะ์ฬࠤฬ๊โะ์่อࡡࡴࠧఫ")+hXB0vKVQ5PRI91SDTprMdfuHEm4+u6rbxnyjTl7I[xcChIL13BpR8WArNt9Pl0So(u"ࠨࡕࡒ࡙ࡗࡉࡅࡔࠩబ")][bXukYxQ4aHw]+YYSh2J6BIrsm8
	jjEwJpmd2v0oxBRP1Dyu += EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠩ࡟ࡲࡡࡴ࡜࡯ฮ่๎฾ࠦๅๅใสฮࠥ฿ๅศั้ࠣํา่ะหࠣๅ๏ࠦวๅ็๋ๆ฾ࠦระ่ส๋ࠬభ")+NXMOzZjYsmS9pf+hXB0vKVQ5PRI91SDTprMdfuHEm4+u6rbxnyjTl7I[JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠪࡗࡔ࡛ࡒࡄࡇࡖࠫమ")][Y0XZKGRAUQj5O]+YYSh2J6BIrsm8
	yBv4YaSomFrkejwgNA7pDnKudCz(xcChIL13BpR8WArNt9Pl0So(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫయ"),gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠬอไๆ๊สๆ฾ࠦวๅำึ้๏ฯࠠๅสิ๊ฬ๋ฬࠡ฻่หิࠦไๅใํำ๏๎็ศฬࠣห้฿ัษ์ฬࠫర"),jjEwJpmd2v0oxBRP1Dyu,KNIvHPjUbhr(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩఱ"))
	return
def Pspq8YShiHQvEd0ICnc31yjUF(IItWrzYPa7b):
	MMk8qKvcJe4fQHm3EG7diBD5.executebuiltin(zyvJMtBhrw(u"ࠧࡂࡦࡧࡳࡳ࠴ࡏࡱࡧࡱࡗࡪࡺࡴࡪࡰࡪࡷ࠭࠭ల")+IItWrzYPa7b+XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠨࠫࠪళ"), VBlawK4mgHSyLEn8iqhUkz5)
	return
def tsS1hMmVRZLFwlCgcI27TPqJQ3WY():
	MewdQi3zF4maS9TZRopbA1hUI(CnbBKmtF1x84q7AW(u"ࠩࡶࡸࡴࡶࠧఴ"))
	MMk8qKvcJe4fQHm3EG7diBD5.executebuiltin(sULh4NjakzI8He7xJCMGrql(u"ࠥࡅࡨࡺࡩࡷࡣࡷࡩ࡜࡯࡮ࡥࡱࡺࠬࡎࡴࡴࡦࡴࡩࡥࡨ࡫ࡓࡦࡶࡷ࡭ࡳ࡭ࡳࠪࠤవ"))
	return
def JdPhvL270fIxaYSgVABw1e():
	MMk8qKvcJe4fQHm3EG7diBD5.executebuiltin(DJ1ICpbyR2(u"ࠫࡆࡪࡤࡰࡰ࠱ࡓࡵ࡫࡮ࡔࡧࡷࡸ࡮ࡴࡧࡴࠪ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡢࡦࡤࡴࡹ࡯ࡶࡦࠫࠪశ"), VBlawK4mgHSyLEn8iqhUkz5)
	return
def KfzxPSRovbeX5jGONytpuZA():
	BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨష"),LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"࠭ไๆีะࠤ๊ำส้์สฮ่ࠥวว็ฬࠤ࠳ࠦวั้หࠤส๊้ࠡษ็ๆฬฬๅสࠢส่ฯ๐ࠠหำํำ๋ࠥำฮ้สࠤํ๊วࠡฬาา้ࠦลๅ์๊หࠥ๎ไไ่ࠣฬฬูสฯัส้ࠥࠨวๅ็ส์ุࠨࠠฤ๊ࠣࠦฬ๊ั๋็๋ฮࠧࠦวื฼ฺࠤ฾๊้ࠡษ็ึึࠦฬ่หࠣห้๐ๅ๋่ࠣวํࠦวิฬัำ๊ࠦࠢศๆๆ๎อ๎ัะࠤࠣ์ฬ฼ฺุࠢ฼่๎ࠦอาใࠣࠦࡈࠨࠠฤ๊ࠣ฽้๏ࠠศุ฽฻ࠥ฿ไ๊ࠢีีࠥࠨวๅไสส๊ฯࠢࠡษ็ิ๏ࠦแ๋ࠢฯ๋ฮࠦวๅ์่๎๋࠭స"))
	return
def uV7hsqACXr8gRlZS9DJp5KcYU():
	BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪహ"),QvgnCALNstmuUJiET(u"ࠨๆ็ฮ฾อๅๅ่ࠢ฽ࠥอไๆใู่ฮࠦ࠮ࠡษำ๋อࠦลๅ๋ࠣห้ืวษูࠣห้ึ๊ࠡฬิ๎ิࠦลืษไฮ์ࠦร้่ࠢืาํࠠๆ่ࠣࠤ็อฦๆหࠣห้๋แืๆฬࠤํ๊ใ็ࠢ็หࠥะๆใำࠣ฽้๐็๊ࠡ็หࠥะิ฻ๆ๊ࠤ࠳่ࠦษษึฮำีวๆࠢࠥห้๋ว้ีࠥࠤศ๎ࠠࠣษ็ี๏๋่หࠤࠣห฻เืࠡ฻็ํࠥอไำำࠣะ์ฯࠠศๆํ้๏์ࠠ࠯๋ࠢว๊อࠠษษึฮำีวๆࠢࠥห้้๊ษ๊ิำࠧࠦแศุ฽฻ࠥ฿ไ๊ࠢะีๆࠦࠢࡄࠤࠣวํูࠦๅ๋ࠣึึࠦࠢศๆๅหห๋ษࠣࠢส่ี๐ࠠโ์ࠣะ์ฯࠠศๆํ้๏์ࠠ࠯๋๊ࠢๆูࠠศๆๆ่ฬ๋้ࠠษ็฻ึ๐โสࠢ฼๊ิࠦวๅฬ฼ห๊๊ࠠๆ฻้ࠣาะ่๋ษอࠤ็๎วว็ࠣห้๋แืๆฬࠫ఺"))
	return
def llAKR46tqu0(QfTOVCbu0WXGzk=CnbBKmtF1x84q7AW(u"ࠩࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄࠨ఻"),showDialogs=VBlawK4mgHSyLEn8iqhUkz5):
	Voz0n8C7vtfg26SR9DFuqKTE = MMk8qKvcJe4fQHm3EG7diBD5.executeJSONRPC(EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡖࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡌ࡫ࡴࡔࡧࡷࡸ࡮ࡴࡧࡗࡣ࡯ࡹࡪࠨࠬࠣ࡫ࡧࠦ࠿࠷ࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡸ࡫ࡴࡵ࡫ࡱ࡫ࠧࡀࠢ࡭ࡱࡲ࡯ࡦࡴࡤࡧࡧࡨࡰ࠳ࡹ࡫ࡪࡰࠥࢁࢂ఼࠭"))
	data = TPDQ5L9eWpIJcrM3YH48Cs6.loads(Voz0n8C7vtfg26SR9DFuqKTE)
	tw0KXYfg23 = data[e2qDYgipPmTw4KvBLnochr(u"ࠫࡷ࡫ࡳࡶ࡮ࡷࠫఽ")][zyvJMtBhrw(u"ࠬࡼࡡ࡭ࡷࡨࠫా")]
	if VKiGj1LundAJQwEXcqgxC: tw0KXYfg23 = tw0KXYfg23.encode(a7VXeDU82IfQEnPZAdiT)
	if showDialogs:
		dHPVDWfG4jX5e6QEo0CKh = XVmKrby29eCGMnlEY6jz0HNOR(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩి"),JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"่ࠧๆࠣฮึ๐ฯࠡฬ฽๎๏ืࠠอๆาࠤࠬీ")+tw0KXYfg23+NeO3CTLHrPfWUoIgy8Q(u"ࠨࠢส่ี๐ࠠๆีอาิ๋ࠠศๆล๊ࠥ็๊ࠡๅ๋ำ๏ࠦลๅ๋ࠣห้หีะษิࠤฬ๊รฯ์ิࠤ้าไะࠢࠪు")+QfTOVCbu0WXGzk+S1SgCFYGJeMvfp5iZXK(u"ࠩࠣรࠦ࠭ూ"))
		if dHPVDWfG4jX5e6QEo0CKh!=QVDJLRlxNg127jMX(u"࠷ൺ"): return fEXMiAyG3ql4vKB
	G62uf8ZSIzBE,QQ1ei5qSau4XhNTZUFGE6dtk,cWF6iSjbvYufyzMnmx = ERUxe2baSfzkiwC6(QfTOVCbu0WXGzk,fEXMiAyG3ql4vKB,fEXMiAyG3ql4vKB)
	if G62uf8ZSIzBE:
		if showDialogs: BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,CnbBKmtF1x84q7AW(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ృ"),xcChIL13BpR8WArNt9Pl0So(u"ࠫฯ๋สࠡ฻่่๏ฯࠠหอห๎ฯࠦวๅฮ็ำࠥอไอัํำࠥ๎็้ࠢฯห์ุࠠๅๆสืฯิฯศ็ࠣ࠲ู่ࠥโࠢํฮ๊ࠦวๅฤ้ࠤฯเ๊๋ำࠣษ฾ีวะษอࠤ่๎ฯ๋ࠢ็็๏๊ࠦิฬ฼้้ࠦวๅฮ็ำࠥอไอัํำࠥฮฯๅษ้๋ࠣࠦวๅไา๎๊࠭ౄ"))
		FEpnOiHwDL6soV9 = MMk8qKvcJe4fQHm3EG7diBD5.executeJSONRPC(LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡓࡦࡶࡖࡩࡹࡺࡩ࡯ࡩ࡙ࡥࡱࡻࡥࠣ࠮ࠥ࡭ࡩࠨ࠺࠲࠮ࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡳࡦࡶࡷ࡭ࡳ࡭ࠢ࠻ࠤ࡯ࡳࡴࡱࡡ࡯ࡦࡩࡩࡪࡲ࠮ࡴ࡭࡬ࡲࠧ࠲ࠢࡷࡣ࡯ࡹࡪࠨ࠺ࠣࠩ౅")+QfTOVCbu0WXGzk+KBkxSYaz93pu1(u"࠭ࠢࡾࡿࠪె"))
		G62uf8ZSIzBE = VBlawK4mgHSyLEn8iqhUkz5 if S1SgCFYGJeMvfp5iZXK(u"ࠧࡐࡍࠪే") in FEpnOiHwDL6soV9 else fEXMiAyG3ql4vKB
		HB5PvxRhwM.sleep(CnbBKmtF1x84q7AW(u"࠱ൻ"))
		MMk8qKvcJe4fQHm3EG7diBD5.executebuiltin(xcChIL13BpR8WArNt9Pl0So(u"ࠨࡕࡨࡲࡩࡉ࡬ࡪࡥ࡮ࠬ࠶࠷ࠩࠨై"))
	elif showDialogs: BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,NeO3CTLHrPfWUoIgy8Q(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ౉"),HHoGx7Flus60(u"่้ࠪษำโࠢไุ้ะฺࠠ็็๎ฮࠦสฬสํฮࠥ๎สโ฻ํ่ࠥอไอๆาࠤฬ๊ๅุๆ๋ฬࠬొ"))
	return G62uf8ZSIzBE
def ExBIZiUjAN4lgm12s():
	url = rwQN9AKhLCuMfHxjlbX0U(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡲ࡯ࡲࡳࡱࡵࡷ࠳ࡱ࡯ࡥ࡫࠱ࡸࡻ࠵ࡲࡦ࡮ࡨࡥࡸ࡫ࡳ࠰ࡹ࡬ࡲࡩࡵࡷࡴ࠱ࡺ࡭ࡳ࠼࠴࠰ࠩో")
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,DJ1ICpbyR2(u"ࠬࡍࡅࡕࠩౌ"),url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,o1u5dij9UrcbXzVS8lwIWfKpnqM(u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓ࠮ࡕࡋࡓ࡜ࡥࡌࡂࡖࡈࡗ࡙ࡥࡋࡐࡆࡌࡣ࡛ࡋࡒࡔࡋࡒࡒ࠲࠷ࡳࡵ్ࠩ"))
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	hD1lRAZO5LeUWkbGr6SoNmfv = trdVA0JvFaD.findall(OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠧࡵ࡫ࡷࡰࡪࡃࠢ࡬ࡱࡧ࡭࠲࠮࡜ࡥ࠭࡟࠲ࡡࡪࠫ࠮࡝ࡤ࠱ࡿࡇ࡛࠭࡟࠮࠭࠲࠭౎"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	hD1lRAZO5LeUWkbGr6SoNmfv = hD1lRAZO5LeUWkbGr6SoNmfv[ybdv7XcT3lxF6QezULwCAGk].split(dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠨ࠯ࠪ౏"))[ybdv7XcT3lxF6QezULwCAGk]
	top4CrqkgMc8daY7j1BlIynQZ = str(guSzmUCXDa1tQpY)
	UcBD7WEkIXbmzFJe8 = hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠩ࡞ࡖ࡙ࡒ࡝ฦืาหึࠦใ้ัํࠤฬ๊รฯ์ิࠤฬ๊ๅห๊ไีࠥอไร่๋ࠣํࠦ࠺ࠡࠢࠣࠫ౐")+soMVfbr6WtpNlcSA+hD1lRAZO5LeUWkbGr6SoNmfv+YYSh2J6BIrsm8
	UcBD7WEkIXbmzFJe8 += SqrG5mU3j96ldsFpExobw40TJY(u"ࠪࡠࡳࡢ࡮ࠨ౑")+EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠫࡠࡘࡔࡍ࡟ศูิอัࠡๅ๋ำ๏ࠦวๅาํࠤฬ์สࠡฬึฮำีๅ่๊ࠢ์ࠥࡀࠠࠡࠢࠪ౒")+soMVfbr6WtpNlcSA+top4CrqkgMc8daY7j1BlIynQZ+YYSh2J6BIrsm8
	BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,wwPrSDa21lUh(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ౓"),UcBD7WEkIXbmzFJe8)
	return
def B47BfDAdUbmcKGRNVzvTWSZeX8oE():
	G0G7Dz1nKwr5tfIU,ccnmqeuKJSdTAF7lVxk0gUabB,hp69LkKNRYCe = fEXMiAyG3ql4vKB,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj
	SK1emLdE7J2u4bytFwc56TnlH,QBL7kyD3lE18c62TASWqtrupU0gVvi,gScZPinLoGh1 = fEXMiAyG3ql4vKB,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj
	OP6LIZw9Y2JzlsEh817nQig = [GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫ౔"),JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥౕࠩ"),KBkxSYaz93pu1(u"ࠨࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊౖࠧ")]
	ssBcmRijhUKPzpVoYNwdLZvElJ = iAGOsUaS21t3RnQ64ejfY8EX5vMlCH(OP6LIZw9Y2JzlsEh817nQig)
	for nUy7x6dqmk92MPb in OP6LIZw9Y2JzlsEh817nQig:
		if nUy7x6dqmk92MPb not in list(ssBcmRijhUKPzpVoYNwdLZvElJ.keys()): continue
		xu5GdvS1L2FQo6fP,ZZkygB5KqU1CDz,PDjEC7xkvYA3tH8NMR46r,R8f0mIEy6z14vxdWwGTs,II9OoQ0wmLufpM4x25,tCZQRwhFmErx3id9zGTea4g,rZT2eEw1FHYtG6xk = ssBcmRijhUKPzpVoYNwdLZvElJ[nUy7x6dqmk92MPb]
		if nUy7x6dqmk92MPb==KBkxSYaz93pu1(u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧ౗"):
			SK1emLdE7J2u4bytFwc56TnlH = xu5GdvS1L2FQo6fP
			QBL7kyD3lE18c62TASWqtrupU0gVvi = ZZkygB5KqU1CDz+QVDJLRlxNg127jMX(u"ࠪࠤࠥࠦࠠࠩࠢࠪౘ")+J72F0jRI6A(tCZQRwhFmErx3id9zGTea4g)+DJ1ICpbyR2(u"ࠫࠥ࠯ࠧౙ")
			gScZPinLoGh1 = R8f0mIEy6z14vxdWwGTs
		elif nUy7x6dqmk92MPb==A6dMB1FlgxVivJ2fk9C(u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪࠧౚ"):
			G0G7Dz1nKwr5tfIU = G0G7Dz1nKwr5tfIU or xu5GdvS1L2FQo6fP
			ccnmqeuKJSdTAF7lVxk0gUabB += EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"࠭ࠠࠡ࠮ࠣࠤࠬ౛")+ZZkygB5KqU1CDz+jeAby54c02TgG8zuivonX91(u"ࠧࠡࠢࠣࠤ࠭ࠦࠧ౜")+J72F0jRI6A(tCZQRwhFmErx3id9zGTea4g)+MMizeNH0AKu(u"ࠨࠢࠬࠫౝ")
			hp69LkKNRYCe += JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠩࠣࠤ࠱ࠦࠠࠨ౞")+R8f0mIEy6z14vxdWwGTs
		elif nUy7x6dqmk92MPb==SqrG5mU3j96ldsFpExobw40TJY(u"ࠪࡷࡰ࡯࡮࠯࡯ࡨࡸࡷࡵࡰࡰ࡮࡬ࡷࡊࡓࡁࡅࠩ౟"):
			LX5ur2pgCx7dfP6ZVtko8AnOy = xu5GdvS1L2FQo6fP
			jWoaiHX0gzqS = ZZkygB5KqU1CDz+FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠫࠥࠦࠠࠡࠪࠣࠫౠ")+J72F0jRI6A(tCZQRwhFmErx3id9zGTea4g)+LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠬࠦࠩࠨౡ")
			WpByaSjVgQE8HeT902 = R8f0mIEy6z14vxdWwGTs
	ccnmqeuKJSdTAF7lVxk0gUabB = ccnmqeuKJSdTAF7lVxk0gUabB.strip(QVDJLRlxNg127jMX(u"࠭ࠠࠡ࠮ࠣࠤࠬౢ"))
	hp69LkKNRYCe = hp69LkKNRYCe.strip(DJ1ICpbyR2(u"ࠧࠡࠢ࠯ࠤࠥ࠭ౣ"))
	MM2rk8n4HN1GCZuwpeUSo  = jeAby54c02TgG8zuivonX91(u"ࠨ࡝ࡕࡘࡑࡣวๅวุำฬืࠠศๆฦา๏ืࠠๅสิ๊ฬ๋ฬࠡ฻่หิࠦวๅ็อ์ๆืࠠศๆล๊ࠥํ่ࠡ࠼ࠣࠤࠥ࠭౤")+soMVfbr6WtpNlcSA+gScZPinLoGh1+YYSh2J6BIrsm8
	MM2rk8n4HN1GCZuwpeUSo += NXMOzZjYsmS9pf+xcChIL13BpR8WArNt9Pl0So(u"ࠩ࡞ࡖ࡙ࡒ࡝ศๆศูิอัࠡษ็ิ๏ࠦว็ฬࠣฮุะฮะ็๊ࠤ้ฮั็ษ่ะࠥ฿ๅศั๋ࠣํࠦ࠺ࠡࠢࠣࠫ౥")+soMVfbr6WtpNlcSA+QBL7kyD3lE18c62TASWqtrupU0gVvi+YYSh2J6BIrsm8
	MM2rk8n4HN1GCZuwpeUSo += FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠪࡠࡳࡢ࡮ࠨ౦")+JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠫࡠࡘࡔࡍ࡟ส่ส฻ฯศำࠣห้ษฮ๋ำู่๊ࠣส้ั฼ࠤ฾๋วะࠢส่๊ะ่โำࠣห้ศๆ้๋ࠡࠤ࠿ࠦࠠࠡࠩ౧")+soMVfbr6WtpNlcSA+hp69LkKNRYCe+YYSh2J6BIrsm8
	MM2rk8n4HN1GCZuwpeUSo += NXMOzZjYsmS9pf+KBkxSYaz93pu1(u"ࠬࡡࡒࡕࡎࡠห้หีะษิࠤฬ๊ะ๋ࠢส๊ฯࠦสิฬัำ๊ํࠠๅ็ึฮํีูࠡ฻่หิࠦ็้ࠢ࠽ࠤࠥࠦࠧ౨")+soMVfbr6WtpNlcSA+ccnmqeuKJSdTAF7lVxk0gUabB+YYSh2J6BIrsm8
	MM2rk8n4HN1GCZuwpeUSo += e2qDYgipPmTw4KvBLnochr(u"࠭࡜࡯࡞ࡱࠫ౩")+LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠧ࡜ࡔࡗࡐࡢอไฦืาหึࠦวๅลั๎ึࠦไอๆาࠤ๊ะั้สุู๋่ࠦๆษาࠤฬ๊ๅห๊ไีࠥอไร่๋ࠣํࠦ࠺ࠡࠢࠣࠫ౪")+soMVfbr6WtpNlcSA+WpByaSjVgQE8HeT902+YYSh2J6BIrsm8
	MM2rk8n4HN1GCZuwpeUSo += NXMOzZjYsmS9pf+sULh4NjakzI8He7xJCMGrql(u"ࠨ࡝ࡕࡘࡑࡣวๅวุำฬืࠠศๆำ๎ࠥอๆหࠢอืฯิฯๆ้่ࠣั๊ฯࠡ็อีํฮ่ๅีࠣ฽๊อฯ้๋ࠡࠤ࠿ࠦࠠࠡࠩ౫")+soMVfbr6WtpNlcSA+jWoaiHX0gzqS+YYSh2J6BIrsm8
	xu5GdvS1L2FQo6fP = SK1emLdE7J2u4bytFwc56TnlH or G0G7Dz1nKwr5tfIU
	if xu5GdvS1L2FQo6fP:
		header = SqrG5mU3j96ldsFpExobw40TJY(u"ࠩส่ึาวยࠢอัิ๐หࠡวูหๆอสࠡๅ๋ำ๏ࠦไฮๆࠣห้๋ิศๅ็ࠫ౬")
		XVfzajwpqTB4R8xdEKDt = QvgnCALNstmuUJiET(u"ࠪห๋ะࠠษฯสะฮࠦไหฯา๎ะࠦศา่ส้ัูࠦๆษาࠤศ๎ࠠหฯา๎ะࠦๅิฬ๋ำ฾ูࠦๆษาࠫ౭")
	else:
		header = S1SgCFYGJeMvfp5iZXK(u"ࠫาอไ๋ษ่ࠣฬ๊้ࠦฮาࠤฯำฯ๋อสฮ๊ࠥศา่ส้ัูࠦๆษาࠤศ๎ࠠๆีอ์ิ฿ฺࠠ็สำࠬ౮")
		XVfzajwpqTB4R8xdEKDt = KNIvHPjUbhr(u"ࠬอไาฮสลࠥหศๅษ฽ࠤฬ๊ๅษำ่ะࠥ฿ๆࠡษ็ู้้ไสࠢส่ฯ๐ࠠห๊สะ์้ࠧ౯")
	E1EZ0jp9Che5Wn8 = rwQN9AKhLCuMfHxjlbX0U(u"࠭ไไ์ࠣ๎฾๋ไࠡ฻้ำ่ࠦวๅฬะำ๏ัࠠศๆอ่็อฦ๋ࠢํะอࠦร็ࠢํ็ํ์ࠠๅัํ็ࠥ็๊ࠡๅ๋ำ๏ࡢ࡮ๆีอ์ิ฿ฺࠠ็สำࠥࡋࡍࡂࡆࠣࡖࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿࠧ౰")
	OjHy6u7xTq591PIlUnvRLwQz83 = MM2rk8n4HN1GCZuwpeUSo+JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠧ࡝ࡰ࡟ࡲࠬ౱")+XVfzajwpqTB4R8xdEKDt+xcChIL13BpR8WArNt9Pl0So(u"ࠨ࡞ࡱࡠࡳ࠭౲")+E1EZ0jp9Che5Wn8
	yBv4YaSomFrkejwgNA7pDnKudCz(MMizeNH0AKu(u"ࠩࡵ࡭࡬࡮ࡴࠨ౳"),header,OjHy6u7xTq591PIlUnvRLwQz83,OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭౴"))
	return xu5GdvS1L2FQo6fP
def mZyWVOcY2eR3AKd(nUy7x6dqmk92MPb,rZT2eEw1FHYtG6xk,showDialogs):
	G62uf8ZSIzBE = fEXMiAyG3ql4vKB
	if showDialogs:
		dHPVDWfG4jX5e6QEo0CKh = XVmKrby29eCGMnlEY6jz0HNOR(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,SqrG5mU3j96ldsFpExobw40TJY(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ౵"),FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ู่ࠬโࠢํฮ๊ࠦวๅฤ้ࠤั๊ศࠡษ็้้็ࠠศๆฺ่฿๎ืࠡๆ็ษ฻อแสࠢส่๊฽ไ้สฬࠤ้้๊ࠡ์อ้ࠥะหษ์อ๋ࠥ฿ไ๊ࠢๆ์ิ๐ࠠ࠯ࠢส่๊๊แࠡไาࠤ๏้่็ࠢๆฬ๏ื้ࠠไาࠤ๏ำสศฮࠣฬ฾฼ࠠศๆ๋ๆฯࠦ࠮้ࠡ็ࠤฯื๊ะࠢอั๊๐ไࠡษ็้้็ࠠศๆล๊ࠥลࠡࠨ౶"))
		if dHPVDWfG4jX5e6QEo0CKh!=bXukYxQ4aHw: return fEXMiAyG3ql4vKB
	VV7JnO4MP2SCWFUqQAcZbwI6 = kXZctzCN2Fy0o8OG4wE1(rZT2eEw1FHYtG6xk,{},showDialogs)
	if VV7JnO4MP2SCWFUqQAcZbwI6:
		QQqZsUnz7vd9xEJb5rXD = WQvYkNg7SysPFLitlGEn6.path.join(g2jVSXyeCRdALnvbk4hTN17,nUy7x6dqmk92MPb)
		Xe6bnfEPjgqJy5FIoRi0z2v8(QQqZsUnz7vd9xEJb5rXD,VBlawK4mgHSyLEn8iqhUkz5,fEXMiAyG3ql4vKB)
		import zipfile as xuzhQpeAEG,io as ZfbS7lHUN3P
		aaWS0Upw9AGyPO7FeMs = ZfbS7lHUN3P.BytesIO(VV7JnO4MP2SCWFUqQAcZbwI6)
		try:
			gbaVMFIr2dwqZPySfL = xuzhQpeAEG.ZipFile(aaWS0Upw9AGyPO7FeMs)
			gbaVMFIr2dwqZPySfL.extractall(g2jVSXyeCRdALnvbk4hTN17)
			HB5PvxRhwM.sleep(bXukYxQ4aHw)
			MMk8qKvcJe4fQHm3EG7diBD5.executebuiltin(wwPrSDa21lUh(u"࠭ࡕࡱࡦࡤࡸࡪࡒ࡯ࡤࡣ࡯ࡅࡩࡪ࡯࡯ࡵࠪ౷"))
			HB5PvxRhwM.sleep(bXukYxQ4aHw)
			G62uf8ZSIzBE = BBE4oxCkGU0SdV(nUy7x6dqmk92MPb)
		except: G62uf8ZSIzBE = fEXMiAyG3ql4vKB
	if showDialogs:
		if G62uf8ZSIzBE: BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,xcChIL13BpR8WArNt9Pl0So(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ౸"),gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠨฬ่ࠤอ์ฬศฯࠣฮะฮ๊หࠢส่ส฼วโหࠣห้๋ืๅ๊หอࠬ౹"))
		else: BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,jeAby54c02TgG8zuivonX91(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ౺"),rwQN9AKhLCuMfHxjlbX0U(u"่้ࠪษำโࠢไุ้ะฺࠠ็็๎ฮࠦสฬสํฮࠥอไฦุสๅฮࠦวๅ็ฺ่ํฮษࠨ౻"))
	return G62uf8ZSIzBE
def ff1TqXMbjgJ6n4yko(nUy7x6dqmk92MPb,showDialogs=VBlawK4mgHSyLEn8iqhUkz5):
	if showDialogs==hWGMqtBy4wuLaVcj: showDialogs = VBlawK4mgHSyLEn8iqhUkz5
	qGlfeFu4HPwjUAKQXVdcb80akiN = Rc7ME3hXPxtzyH1CvFwf96iUsQlq([nUy7x6dqmk92MPb])
	hvl9HBPUgsDpS3tA0Wyc6xn,sHTFaIyGqfekpEJ9 = qGlfeFu4HPwjUAKQXVdcb80akiN[nUy7x6dqmk92MPb]
	if sHTFaIyGqfekpEJ9:
		G62uf8ZSIzBE = VBlawK4mgHSyLEn8iqhUkz5
		if showDialogs: BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ౼"),KBkxSYaz93pu1(u"ࠬ็อึࠢส่ส฼วโหࠣࡠࡳࠦࠧ౽")+nUy7x6dqmk92MPb+zyvJMtBhrw(u"࠭ࠠ࡝ࡰ๋ࠣีํࠠฤๆศฺฬ็ษࠡ฻้ำ่ࠦๅ้ฮ๋ำฮ่ࠦๆใ฼่ฮ่ࠦอษ๊ึฮࠦไๅษึฮำีวๆࠩ౾"))
	else:
		G62uf8ZSIzBE = fEXMiAyG3ql4vKB
		dHPVDWfG4jX5e6QEo0CKh = XVmKrby29eCGMnlEY6jz0HNOR(NeO3CTLHrPfWUoIgy8Q(u"ࠧࡤࡧࡱࡸࡪࡸࠧ౿"),hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,HHoGx7Flus60(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫಀ"),hWGMqtBy4wuLaVcj+nUy7x6dqmk92MPb+DJ1ICpbyR2(u"ࠩࠣࡠࡳࠦ็ั้ࠣว้หึศใฬࠤ฾์ฯไࠢ฽๎ึࠦๅโ฻็อࠥษ่ࠡ฼ํี๋่ࠥอ๊าอࠥ࠴๋ࠠฮหࠤฯัศ๋ฬ๊หࠥ๎สโ฻ํ่์อࠠๅๅํࠤ๏฿ๅๅࠢส่อืๆศ็ฯࠤ฾์ฯไࠢหูํืษࠡืะ๎าฯࠠ࠯๊่ࠢࠥะั๋ัࠣฮะฮ๊ห๋ࠢฮๆ฿๊ๅ๊ࠢิ์ࠦวๅวูหๆฯࠠศๆล๊ࠥลࠧಁ"))
		if dHPVDWfG4jX5e6QEo0CKh==mkHKSQvjWr5BTcM3wVY(u"࠲ർ"):
			MMk8qKvcJe4fQHm3EG7diBD5.executebuiltin(QVDJLRlxNg127jMX(u"ࠪࡍࡳࡹࡴࡢ࡮࡯ࡅࡩࡪ࡯࡯ࠪࠪಂ")+nUy7x6dqmk92MPb+xcChIL13BpR8WArNt9Pl0So(u"ࠫ࠮࠭ಃ"))
			HB5PvxRhwM.sleep(JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"࠳ൽ"))
			MMk8qKvcJe4fQHm3EG7diBD5.executebuiltin(DJ1ICpbyR2(u"࡙ࠬࡥ࡯ࡦࡆࡰ࡮ࡩ࡫ࠩ࠳࠴࠭ࠬ಄"))
			HB5PvxRhwM.sleep(S1SgCFYGJeMvfp5iZXK(u"࠴ൾ"))
			while MMk8qKvcJe4fQHm3EG7diBD5.getCondVisibility(EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"࠭ࡗࡪࡰࡧࡳࡼ࠴ࡉࡴࡃࡦࡸ࡮ࡼࡥࠩࡲࡵࡳ࡬ࡸࡥࡴࡵࡧ࡭ࡦࡲ࡯ࡨࠫࠪಅ")): HB5PvxRhwM.sleep(MMizeNH0AKu(u"࠵ൿ"))
			G62uf8ZSIzBE = BBE4oxCkGU0SdV(nUy7x6dqmk92MPb)
			if showDialogs and G62uf8ZSIzBE: BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,jeAby54c02TgG8zuivonX91(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪಆ"),dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠨฬ่ࠤๆำีࠡล๋ࠤฯัศ๋ฬࠣวํࠦสโ฻ํ่ࠥษ่ࠡฬะำ๏ัࠠศๆศฺฬ็ษࠡษ็้฼๊่ษหࠣ์์๐ࠠศๆล๊ࠥาว่ิฬࠤ้๊วิฬัำฬ๋ࠧಇ"))
			elif showDialogs: BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,S1SgCFYGJeMvfp5iZXK(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬಈ"),NeO3CTLHrPfWUoIgy8Q(u"ࠪๅู๊ࠠโ์ࠣฮะฮ๊หࠢฦ์ࠥะแฺ์็ࠤศ๎ࠠหฯา๎ะࠦวๅวูหๆฯࠠศๆ่฻้๎ศสࠢ࠱ࠤํอไฮๆ๋ࠣํࠦสฬสํฮ์อ้ࠠฬไ฽๏๊็ศ่๊ࠢࠥิวาฮࠣห้ฮั็ษ่ะࠬಉ"))
	return G62uf8ZSIzBE
def TGM1riEyHtLYb4RjX5pxolJ(showDialogs):
	if not showDialogs: dHPVDWfG4jX5e6QEo0CKh = VBlawK4mgHSyLEn8iqhUkz5
	else: dHPVDWfG4jX5e6QEo0CKh = XVmKrby29eCGMnlEY6jz0HNOR(FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫಊ"),hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,CnbBKmtF1x84q7AW(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨಋ"),rwQN9AKhLCuMfHxjlbX0U(u"࠭ศา่ส้ัࠦใ้ัํࠤ๏่่ๆࠢห฽๊๊๊สࠢอัิ๐หࠡฮ่๎฾ࠦวๅวูหๆอสࠡฬ็ๆฬฬ๊ศࠢๆ่ࠥ࠸࠴ࠡีส฽ฮ่ࠦๅๅ้ࠤ๊๋ใ็ࠢศะึอม่ษࠣห้ศๆࠡ࠰๋้ࠣࠦสา์าࠤฯำฯ๋อࠣะ๊๐ูࠡวูหๆอสࠡๅ๋ำ๏ࠦวๅฤ้ࠤฤ࠭ಌ"))
	if dHPVDWfG4jX5e6QEo0CKh==QVDJLRlxNg127jMX(u"࠶඀"):
		MMk8qKvcJe4fQHm3EG7diBD5.executebuiltin(e2qDYgipPmTw4KvBLnochr(u"ࠧࡖࡲࡧࡥࡹ࡫ࡁࡥࡦࡲࡲࡗ࡫ࡰࡰࡵࠪ಍"))
		if showDialogs:
			BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,CnbBKmtF1x84q7AW(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫಎ"),KBkxSYaz93pu1(u"ࠩอ้ࠥหัิษ็ࠤ฼๊ศࠡว็ํࠥฮั็ษ่ะ้่ࠥะ์ࠣห้ึ๊ࠡใํࠤัํวำๅ่่ࠣ๐๋ࠠไ๋้ࠥฮสฮัํฯࠥาๅ๋฻ࠣษ฻อแศฬࠣ็ํี๊ࠡ࠰ࠣฬ๊อࠠโ์๊หࠥะอะ์ฮࠤ์ึวࠡษ็ฬึ์วๆฮࠣ์ฯำฯ๋อุ้ࠣะ่ะ฻ࠣ฽๊อฯࠡ࠰ࠣ๎ึา้ࠡว฼฻ฬวࠠไ๊า๎ࠥ࠻ࠠะไสส็ࠦร้ࠢฦ็ะืࠠๅๅํࠤ๏์็๋ࠢ฼้้๐ษࠡษ็ฮาี๊ฬࠩಏ"))
	return
def QYpFblwDT5fzUaMWgcurv8qHXC4ek():
	pMPR1Cc0usZ6nJTU(MM5Dx39f7ULhcJsRptzIowP,QvgnCALNstmuUJiET(u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭ಐ"),o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠫࡆࡒࡌࡠࡃࡇࡈࡔࡔࡓࡠ࡚ࡐࡐࠬ಑"))
	ExBIZiUjAN4lgm12s()
	xu5GdvS1L2FQo6fP = B47BfDAdUbmcKGRNVzvTWSZeX8oE()
	if xu5GdvS1L2FQo6fP:
		Y6MUwOztEjeTSW7Ha(VBlawK4mgHSyLEn8iqhUkz5)
		TGM1riEyHtLYb4RjX5pxolJ(VBlawK4mgHSyLEn8iqhUkz5)
		CfKNTtIi3OABbWcPpdF(fEXMiAyG3ql4vKB)
	return
def BBE4oxCkGU0SdV(nUy7x6dqmk92MPb):
	N6NCYivtV4I5rEXq = MMk8qKvcJe4fQHm3EG7diBD5.executeJSONRPC(JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡆࡪࡤࡰࡰࡶ࠲ࡘ࡫ࡴࡂࡦࡧࡳࡳࡋ࡮ࡢࡤ࡯ࡩࡩࠨࠬࠣ࡫ࡧࠦ࠿࠷ࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡦࡪࡤࡰࡰ࡬ࡨࠧࡀࠢࠨಒ")+nUy7x6dqmk92MPb+QvgnCALNstmuUJiET(u"࠭ࠢ࠭ࠤࡨࡲࡦࡨ࡬ࡦࡦࠥ࠾ࡹࡸࡵࡦࡿࢀࠫಓ"))
	succeeded = VBlawK4mgHSyLEn8iqhUkz5 if A6dMB1FlgxVivJ2fk9C(u"ࠧࡐࡍࠪಔ") in N6NCYivtV4I5rEXq else fEXMiAyG3ql4vKB
	return succeeded
def HDG0sQFwOvSt39Tp4ix15goYNnkCJA(nUy7x6dqmk92MPb):
	N6NCYivtV4I5rEXq = MMk8qKvcJe4fQHm3EG7diBD5.executeJSONRPC(LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡂࡦࡧࡳࡳࡹ࠮ࡔࡧࡷࡅࡩࡪ࡯࡯ࡇࡱࡥࡧࡲࡥࡥࠤ࠯ࠦ࡮ࡪࠢ࠻࠳࠯ࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡢࡦࡧࡳࡳ࡯ࡤࠣ࠼ࠥࠫಕ")+nUy7x6dqmk92MPb+DJ1ICpbyR2(u"ࠩࠥ࠰ࠧ࡫࡮ࡢࡤ࡯ࡩࡩࠨ࠺ࡧࡣ࡯ࡷࡪࢃࡽࠨಖ"))
	succeeded = VBlawK4mgHSyLEn8iqhUkz5 if wwPrSDa21lUh(u"ࠪࡓࡐ࠭ಗ") in N6NCYivtV4I5rEXq else fEXMiAyG3ql4vKB
	return succeeded
def ERUxe2baSfzkiwC6(nUy7x6dqmk92MPb,showDialogs,cZp45G6WMqkUXtCLxYuIPD,ssBcmRijhUKPzpVoYNwdLZvElJ=None):
	dHPVDWfG4jX5e6QEo0CKh,succeeded,QQ1ei5qSau4XhNTZUFGE6dtk,ZZkygB5KqU1CDz = VBlawK4mgHSyLEn8iqhUkz5,fEXMiAyG3ql4vKB,LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫಘ"),hWGMqtBy4wuLaVcj
	if not ssBcmRijhUKPzpVoYNwdLZvElJ: ssBcmRijhUKPzpVoYNwdLZvElJ = iAGOsUaS21t3RnQ64ejfY8EX5vMlCH([nUy7x6dqmk92MPb])
	if nUy7x6dqmk92MPb in list(ssBcmRijhUKPzpVoYNwdLZvElJ.keys()):
		xu5GdvS1L2FQo6fP,ZZkygB5KqU1CDz,PDjEC7xkvYA3tH8NMR46r,R8f0mIEy6z14vxdWwGTs,II9OoQ0wmLufpM4x25,tCZQRwhFmErx3id9zGTea4g,rZT2eEw1FHYtG6xk = ssBcmRijhUKPzpVoYNwdLZvElJ[nUy7x6dqmk92MPb]
		if tCZQRwhFmErx3id9zGTea4g==gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠬ࡭࡯ࡰࡦࠪಙ"):
			succeeded,QQ1ei5qSau4XhNTZUFGE6dtk = VBlawK4mgHSyLEn8iqhUkz5,hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"࠭࡮ࡰࡶ࡫࡭ࡳ࡭ࠧಚ")
			if cZp45G6WMqkUXtCLxYuIPD and showDialogs:
				dHPVDWfG4jX5e6QEo0CKh = XVmKrby29eCGMnlEY6jz0HNOR(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪಛ"),A6dMB1FlgxVivJ2fk9C(u"ࠨฮํำࠥาฯศࠢ࠱࠲้่ࠥะ์ࠣ๎ุะฮะ็ࠣวำืࠠฦืาหึࠦๅห๊ไีࠥ็๊ࠡ็๋ห็฿ࠠๆีอ์ิ฿ฺࠠ็สำ๊ࠥ็ั้ࠣห้หึศใฬࡠࡳࡢ࡮ࠨಜ")+nUy7x6dqmk92MPb+mkHKSQvjWr5BTcM3wVY(u"ࠩ࡟ࡲࡡࡴ็ๅࠢอี๏ีࠠฦ฻สำฮࠦสฬสํฮࠥํะ่ࠢส่ส฼วโห้ࠣึฯࠠฤะิํࠬಝ"))
				if dHPVDWfG4jX5e6QEo0CKh:
					succeeded = mZyWVOcY2eR3AKd(nUy7x6dqmk92MPb,rZT2eEw1FHYtG6xk,fEXMiAyG3ql4vKB)
					if succeeded:
						QQ1ei5qSau4XhNTZUFGE6dtk = DJ1ICpbyR2(u"ࠪࡶࡪ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤࠨಞ")
						if showDialogs: BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,QVDJLRlxNg127jMX(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧಟ"),OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠬา๊ะࠢฯำฬࠦ࠮࠯ࠢส่ส฼วโหࠣ็ฬ์สࠡ็๋ะํีษࠡ࠰࠱ࠤํ่วๆࠢส่อืๆศ็ฯࠤอหูศัฬࠤฯัศ๋ฬ๊หࡡࡴ࡜࡯ࠩಠ")+nUy7x6dqmk92MPb)
					else:
						QQ1ei5qSau4XhNTZUFGE6dtk = sULh4NjakzI8He7xJCMGrql(u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭ಡ")
						BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪಢ"),JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠨๆ็วุ็ࠠ࠯࠰ࠣห้ฮั็ษ่ะ๊ࠥๅࠡ์ึฮ฼๐ูࠡว฼หิฯࠠหอห๎ฯࠦ็ั้ࠣห้หึศใฬࡠࡳࡢ࡮ࠨಣ")+nUy7x6dqmk92MPb)
		else:
			if showDialogs:
				if tCZQRwhFmErx3id9zGTea4g==rwQN9AKhLCuMfHxjlbX0U(u"ࠩࡧ࡭ࡸࡧࡢ࡭ࡧࡧࠫತ"): jjEwJpmd2v0oxBRP1Dyu = JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"้ࠪฯ๎โโหࠪಥ")
				elif tCZQRwhFmErx3id9zGTea4g==ITvnUAMXsyb4eO(u"ࠫࡴࡲࡤࠨದ"): jjEwJpmd2v0oxBRP1Dyu = EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"่ࠬฯ๋็ฬࠫಧ")
				elif tCZQRwhFmErx3id9zGTea4g==ITvnUAMXsyb4eO(u"࠭࡭ࡪࡵࡶ࡭ࡳ࡭ࠧನ"): jjEwJpmd2v0oxBRP1Dyu = JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠧ฻์ิࠤ๊ัศหหࠪ಩")
				dHPVDWfG4jX5e6QEo0CKh = XVmKrby29eCGMnlEY6jz0HNOR(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,DJ1ICpbyR2(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫಪ"),XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"๊ࠩิ์ࠦวๅวูหๆฯࠠࠨಫ")+jjEwJpmd2v0oxBRP1Dyu+KBkxSYaz93pu1(u"ࠪࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡวุ่ฬำ่ࠠา๊ࠤฬ๊ๅีๅ็อࠥลࠡ࡝ࡰ࡟ࡲࠬಬ")+nUy7x6dqmk92MPb)
			if not dHPVDWfG4jX5e6QEo0CKh: QQ1ei5qSau4XhNTZUFGE6dtk = rwQN9AKhLCuMfHxjlbX0U(u"ࠫࡨࡧ࡮ࡤࡧ࡯ࡩࡩ࠭ಭ")
			else:
				if tCZQRwhFmErx3id9zGTea4g==OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠬࡪࡩࡴࡣࡥࡰࡪࡪࠧಮ"):
					succeeded = BBE4oxCkGU0SdV(nUy7x6dqmk92MPb)
					if succeeded:
						QQ1ei5qSau4XhNTZUFGE6dtk = KNIvHPjUbhr(u"࠭ࡥ࡯ࡣࡥࡰࡪࡪࠧಯ")
						if showDialogs: BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,MMizeNH0AKu(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪರ"),MMizeNH0AKu(u"ࠨฮํำࠥาฯศࠢ࠱࠲ࠥอไฦุสๅฮࠦใศ่อࠤ๊ะ่ใใฬࠤ࠳࠴้ࠠไส้ࠥอไษำ้ห๊าࠠษฬื฾๏๊็ศ࡞ࡱࡠࡳ࠭ಱ")+nUy7x6dqmk92MPb)
					elif showDialogs: BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,HHoGx7Flus60(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬಲ"),LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"่้ࠪษำโࠢ࠱࠲ࠥอไฦุสๅฮࠦๅห๊ๅๅฮࠦ࠮࠯๋่๊๊ࠢࠦิฬฺ๎฾ࠦวๅสิ๊ฬ๋ฬࠡฬื฾๏๊็ศ࡞ࡱࡠࡳ࠭ಳ")+nUy7x6dqmk92MPb)
				elif tCZQRwhFmErx3id9zGTea4g in [dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠫࡴࡲࡤࠨ಴"),DJ1ICpbyR2(u"ࠬࡳࡩࡴࡵ࡬ࡲ࡬࠭ವ")]:
					succeeded = mZyWVOcY2eR3AKd(nUy7x6dqmk92MPb,rZT2eEw1FHYtG6xk,fEXMiAyG3ql4vKB)
					if succeeded:
						if tCZQRwhFmErx3id9zGTea4g==dv0trJR7PwmKyxDYO52VLau8gEph(u"࠭࡯࡭ࡦࠪಶ"): QQ1ei5qSau4XhNTZUFGE6dtk = wwPrSDa21lUh(u"ࠧࡶࡲࡧࡥࡹ࡫ࡤࠨಷ")
						elif tCZQRwhFmErx3id9zGTea4g==SqrG5mU3j96ldsFpExobw40TJY(u"ࠨ࡯࡬ࡷࡸ࡯࡮ࡨࠩಸ"): QQ1ei5qSau4XhNTZUFGE6dtk = QvgnCALNstmuUJiET(u"ࠩ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨࠬಹ")
						ZZkygB5KqU1CDz = R8f0mIEy6z14vxdWwGTs
						if showDialogs:
							if QQ1ei5qSau4XhNTZUFGE6dtk==LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠪࡹࡵࡪࡡࡵࡧࡧࠫ಺"): BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,CnbBKmtF1x84q7AW(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ಻"),wwPrSDa21lUh(u"ࠬา๊ะࠢฯำฬࠦ࠮࠯ࠢส่ส฼วโหࠣ็ฬ์สࠡไา๎๊ฯࠠ࠯࠰ࠣ์ฬ๊ศา่ส้ัࠦโศ็ࠣฬฯำฯ๋อ๊หࡡࡴ࡜࡯಼ࠩ")+nUy7x6dqmk92MPb)
							elif QQ1ei5qSau4XhNTZUFGE6dtk==mkHKSQvjWr5BTcM3wVY(u"࠭ࡩ࡯ࡵࡷࡥࡱࡲࡥࡥࠩಽ"): BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,rwQN9AKhLCuMfHxjlbX0U(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪಾ"),EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠨฮํำࠥาฯศࠢ࠱࠲ࠥอไฦุสๅฮࠦไๆࠢอ็๋ࠦๅ้ฮ๋ำฮࠦแ๋ࠢๆ์ิ๐ࠠ࠯࠰ࠣ์ฬ๊ศา่ส้ัࠦโศ็ࠣฬฯัศ๋ฬ๊หࡡࡴ࡜࡯ࠩಿ")+nUy7x6dqmk92MPb)
					elif showDialogs: BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬೀ"),hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"่้ࠪษำโࠢ࠱࠲ࠥอไษำ้ห๊าࠠๅ็ࠣ๎ุะื๋฻ࠣฮาี๊ฬࠢฦ์ࠥะหษ์อࠤ์ึ็ࠡษ็ษ฻อแส࡞ࡱࡠࡳ࠭ು")+nUy7x6dqmk92MPb)
	elif showDialogs: BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,KBkxSYaz93pu1(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧೂ"),mkHKSQvjWr5BTcM3wVY(u"๊ࠬไฤีไࠤ࠳࠴่ࠠา๊ࠤฬ๊ลืษไอࠥเ๊า่ࠢ์ั๎ฯสࠢไ๎๋ࠥำห๊า฽ࠥ฿ๅศัࠣ࠲࠳่ࠦๅ้ำห๊ࠥวࠡ์ึฮ฼๐ูࠡษ็ฬึ์วๆฮࠣว๋๊ࠦใ๊่ࠤอะหษ์อࠤ์ึ็ࠡษ็ษ฻อแสࠢฦ์ࠥะอะ์ฮ๋ฬࡢ࡮࡝ࡰࠪೃ")+nUy7x6dqmk92MPb)
	return succeeded,QQ1ei5qSau4XhNTZUFGE6dtk,ZZkygB5KqU1CDz
def Wf4vUZliHmBr3PL9bzx(nUy7x6dqmk92MPb,showDialogs,H9QNsKVLA5lz0Z7,yKSPAh3R6JnEaz=None,Z8gcWPFXkx7oSrR2D=None):
	NB1YG5Kqwub9gJERmk = VBlawK4mgHSyLEn8iqhUkz5 if yKSPAh3R6JnEaz else fEXMiAyG3ql4vKB
	if not NB1YG5Kqwub9gJERmk:
		yKSPAh3R6JnEaz = pbXIg7UFi4dV.connect(N4Rok9EBZeWumSCc2)
		yKSPAh3R6JnEaz.text_factory = str
		Z8gcWPFXkx7oSrR2D = yKSPAh3R6JnEaz.cursor()
	succeeded,D2t5JWVN8sfYqAokQnawM7lbrj = VBlawK4mgHSyLEn8iqhUkz5,fEXMiAyG3ql4vKB
	try:
		q5NCeIu3vYFylO2pMPXa = CnbBKmtF1x84q7AW(u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤࠨೄ")
		Z8gcWPFXkx7oSrR2D.execute(S1SgCFYGJeMvfp5iZXK(u"ࠧࡔࡇࡏࡉࡈ࡚ࠠࡰࡴ࡬࡫࡮ࡴࠠࡇࡔࡒࡑࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤ࡙ࠡࡋࡉࡗࡋࠠࡢࡦࡧࡳࡳࡏࡄࠡ࠿ࠣࠦࠬ೅")+nUy7x6dqmk92MPb+OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠨࠤࠣ࠿ࠬೆ"))
		pUD0WVmgIR7 = Z8gcWPFXkx7oSrR2D.fetchall()
		if pUD0WVmgIR7 and q5NCeIu3vYFylO2pMPXa not in str(pUD0WVmgIR7): Z8gcWPFXkx7oSrR2D.execute(e2qDYgipPmTw4KvBLnochr(u"ࠩࡘࡔࡉࡇࡔࡆࠢ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨ࡙ࠥࡅࡕࠢࡲࡶ࡮࡭ࡩ࡯ࠢࡀࠤࠧ࠭ೇ")+q5NCeIu3vYFylO2pMPXa+KBkxSYaz93pu1(u"ࠪࠦࠥ࡝ࡈࡆࡔࡈࠤࡦࡪࡤࡰࡰࡌࡈࠥࡃࠠࠣࠩೈ")+nUy7x6dqmk92MPb+OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠫࠧࠦ࠻ࠨ೉"))
		LAXeirpfuEQ1BMVPYNDg = zyvJMtBhrw(u"ࠬࡨ࡬ࡢࡥ࡮ࡰ࡮ࡹࡴࠨೊ") if VKiGj1LundAJQwEXcqgxC else sULh4NjakzI8He7xJCMGrql(u"࠭ࡵࡱࡦࡤࡸࡪࡥࡲࡶ࡮ࡨࡷࠬೋ")
		Z8gcWPFXkx7oSrR2D.execute(FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠧࡔࡇࡏࡉࡈ࡚ࠠࠫࠢࡉࡖࡔࡓࠠࠨೌ")+LAXeirpfuEQ1BMVPYNDg+KNIvHPjUbhr(u"ࠨ࡚ࠢࡌࡊࡘࡅࠡࡣࡧࡨࡴࡴࡉࡅࠢࡀࠤ್ࠧ࠭")+nUy7x6dqmk92MPb+dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠩࠥࠤࡀ࠭೎"))
		pUD0WVmgIR7 = Z8gcWPFXkx7oSrR2D.fetchall()
		if pUD0WVmgIR7:
			if showDialogs: dHPVDWfG4jX5e6QEo0CKh = XVmKrby29eCGMnlEY6jz0HNOR(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭೏"),NeO3CTLHrPfWUoIgy8Q(u"ࠫฬ๊สฮัํฯࠥอไฤ๊อ์๊อส๋ๅํࠤ้หึศใฬࠤࡡࡴࠠࠨ೐")+nUy7x6dqmk92MPb+KBkxSYaz93pu1(u"ࠬࠦ࡜࡯࡞ࡱࠤࠬ೑")+hXB0vKVQ5PRI91SDTprMdfuHEm4+S1SgCFYGJeMvfp5iZXK(u"࠭ࠠๆฬ๋ๆๆ่ࠦๅษࠣ๎฾๋ไࠡ࠰࠱ࠤ์๊ࠠหำํำࠥะแฺ์็๋ࠥอไร่ࠣรࠦࠧࠠࠨ೒")+YYSh2J6BIrsm8+NeO3CTLHrPfWUoIgy8Q(u"ࠧࠡ࡞ࡱࡠࡳࠦสิฬฺ๎฾ࠦล๋ไสๅ์ࠦศิ้๋่ฮูࠦ็ัࠣห้฿่ะหࠣษ้๏่ࠠา๊ࠤฬ๊ิศึฬࠤฬ๊ๅ้ฮ๋ำฮࠦแ๋ࠢๅหห๋ษࠡะา้ฬะࠠษำ้ห๊าฺࠠ็สำࠬ೓"))
			else: dHPVDWfG4jX5e6QEo0CKh = bXukYxQ4aHw
			if dHPVDWfG4jX5e6QEo0CKh==bXukYxQ4aHw:
				D2t5JWVN8sfYqAokQnawM7lbrj = VBlawK4mgHSyLEn8iqhUkz5
				Z8gcWPFXkx7oSrR2D.execute(EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠨࡆࡈࡐࡊ࡚ࡅࠡࡈࡕࡓࡒࠦࠧ೔")+LAXeirpfuEQ1BMVPYNDg+SqrG5mU3j96ldsFpExobw40TJY(u"࡛ࠩࠣࡍࡋࡒࡆࠢࡤࡨࡩࡵ࡮ࡊࡆࠣࡁࠥࠨࠧೕ")+nUy7x6dqmk92MPb+GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠪࠦࠥࡁࠧೖ"))
		elif H9QNsKVLA5lz0Z7:
			if showDialogs: dHPVDWfG4jX5e6QEo0CKh = XVmKrby29eCGMnlEY6jz0HNOR(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,sULh4NjakzI8He7xJCMGrql(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ೗"),JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠬอไหฯา๎ะࠦวๅล๋ฮํ๋วห์ๆ๎๊ࠥลืษไอࠥࡢ࡮ࠡࠩ೘")+nUy7x6dqmk92MPb+QvgnCALNstmuUJiET(u"࠭ࠠ࡝ࡰ࡟ࡲࠥ࠭೙")+hXB0vKVQ5PRI91SDTprMdfuHEm4+MMizeNH0AKu(u"ࠧࠡ็ไ฽้่๋ࠦ฻่่ࠥ࠴࠮้ࠡ็ࠤฯื๊ะࠢศ๎็อแ่ࠢส่ว์ࠠภࠣࠤࠤࠬ೚")+YYSh2J6BIrsm8+QVDJLRlxNg127jMX(u"ࠨࠢ࡟ࡲࡡࡴࠠหีอ฻๏฿ࠠหใ฼๎้ํࠠษี๊์้ฯฺ่ࠠาࠤฬู๊้ัฬࠤส๊้้ࠡำ๋ࠥอไีษือࠥอไๆ๊ฯ์ิฯࠠโ์ࠣๆฬฬๅสࠢัำ๊อสࠡสิ๊ฬ๋ฬࠡ฻่หิ࠭೛"))
			else: dHPVDWfG4jX5e6QEo0CKh = bXukYxQ4aHw
			if dHPVDWfG4jX5e6QEo0CKh==bXukYxQ4aHw:
				D2t5JWVN8sfYqAokQnawM7lbrj = VBlawK4mgHSyLEn8iqhUkz5
				if VKiGj1LundAJQwEXcqgxC: Z8gcWPFXkx7oSrR2D.execute(DJ1ICpbyR2(u"ࠩࡌࡒࡘࡋࡒࡕࠢࡌࡒ࡙ࡕࠠࠨ೜")+LAXeirpfuEQ1BMVPYNDg+LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠪࠤ࠭ࡧࡤࡥࡱࡱࡍࡉ࠯ࠠࡗࡃࡏ࡙ࡊ࡙ࠠࠩࠤࠪೝ")+nUy7x6dqmk92MPb+ITvnUAMXsyb4eO(u"ࠫࠧ࠯ࠠ࠼ࠩೞ"))
				else: Z8gcWPFXkx7oSrR2D.execute(S1SgCFYGJeMvfp5iZXK(u"ࠬࡏࡎࡔࡇࡕࡘࠥࡏࡎࡕࡑࠣࠫ೟")+LAXeirpfuEQ1BMVPYNDg+XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"࠭ࠠࠩࡣࡧࡨࡴࡴࡉࡅ࠮ࡸࡴࡩࡧࡴࡦࡔࡸࡰࡪ࠯ࠠࡗࡃࡏ࡙ࡊ࡙ࠠࠩࠤࠪೠ")+nUy7x6dqmk92MPb+KNIvHPjUbhr(u"ࠧࠣ࠮࠴࠭ࠥࡁࠧೡ"))
	except: succeeded = fEXMiAyG3ql4vKB
	if showDialogs and D2t5JWVN8sfYqAokQnawM7lbrj:
		if succeeded: BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,jeAby54c02TgG8zuivonX91(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫೢ"),MMizeNH0AKu(u"้ࠩะาะฺࠠ็็๎ฮࠦลึๆสัࠥะอะ์ฮࠤฬ๊ลืษไอࠥࡢ࡮࡝ࡰࠪೣ")+nUy7x6dqmk92MPb)
		else: BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,HHoGx7Flus60(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭೤"),NeO3CTLHrPfWUoIgy8Q(u"ࠫๆฺไหࠢ฼้้๐ษࠡวุ่ฬำࠠหฯา๎ะࠦวๅวูหๆฯࠠ࡝ࡰ࡟ࡲࠬ೥")+nUy7x6dqmk92MPb)
	if not NB1YG5Kqwub9gJERmk:
		yKSPAh3R6JnEaz.commit()
		yKSPAh3R6JnEaz.close()
		if D2t5JWVN8sfYqAokQnawM7lbrj:
			HB5PvxRhwM.sleep(o1u5dij9UrcbXzVS8lwIWfKpnqM(u"࠷ඁ"))
			MMk8qKvcJe4fQHm3EG7diBD5.executebuiltin(zyvJMtBhrw(u"࡛ࠬࡰࡥࡣࡷࡩࡑࡵࡣࡢ࡮ࡄࡨࡩࡵ࡮ࡴࠩ೦"))
			HB5PvxRhwM.sleep(FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"࠱ං"))
	return D2t5JWVN8sfYqAokQnawM7lbrj
def BxcQwOiEX8JSl9tonLUgu04yvC(OP6LIZw9Y2JzlsEh817nQig,showDialogs,cZp45G6WMqkUXtCLxYuIPD,H9QNsKVLA5lz0Z7):
	yKSPAh3R6JnEaz = pbXIg7UFi4dV.connect(N4Rok9EBZeWumSCc2)
	yKSPAh3R6JnEaz.text_factory = str
	Z8gcWPFXkx7oSrR2D = yKSPAh3R6JnEaz.cursor()
	ssBcmRijhUKPzpVoYNwdLZvElJ = iAGOsUaS21t3RnQ64ejfY8EX5vMlCH(OP6LIZw9Y2JzlsEh817nQig)
	PZnt6THzESBMfXRLbwim1VlDckK = fEXMiAyG3ql4vKB
	for nUy7x6dqmk92MPb in OP6LIZw9Y2JzlsEh817nQig:
		succeeded,QQ1ei5qSau4XhNTZUFGE6dtk,ZZkygB5KqU1CDz = ERUxe2baSfzkiwC6(nUy7x6dqmk92MPb,showDialogs,cZp45G6WMqkUXtCLxYuIPD,ssBcmRijhUKPzpVoYNwdLZvElJ)
		D2t5JWVN8sfYqAokQnawM7lbrj = Wf4vUZliHmBr3PL9bzx(nUy7x6dqmk92MPb,showDialogs,H9QNsKVLA5lz0Z7,yKSPAh3R6JnEaz,Z8gcWPFXkx7oSrR2D)
		if D2t5JWVN8sfYqAokQnawM7lbrj: PZnt6THzESBMfXRLbwim1VlDckK = VBlawK4mgHSyLEn8iqhUkz5
	yKSPAh3R6JnEaz.commit()
	yKSPAh3R6JnEaz.close()
	if PZnt6THzESBMfXRLbwim1VlDckK:
		HB5PvxRhwM.sleep(e2qDYgipPmTw4KvBLnochr(u"࠲ඃ"))
		MMk8qKvcJe4fQHm3EG7diBD5.executebuiltin(xcChIL13BpR8WArNt9Pl0So(u"࠭ࡕࡱࡦࡤࡸࡪࡒ࡯ࡤࡣ࡯ࡅࡩࡪ࡯࡯ࡵࠪ೧"))
		HB5PvxRhwM.sleep(KNIvHPjUbhr(u"࠳඄"))
	if showDialogs:
		if len(OP6LIZw9Y2JzlsEh817nQig)>rwQN9AKhLCuMfHxjlbX0U(u"࠴අ"): BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ೨"),KBkxSYaz93pu1(u"ࠨฬ่ࠤอ์ฬศฯࠣๅา฻ࠠอ็ํ฽ࠥอไฦุสๅฬะࠧ೩"))
		else: BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,KNIvHPjUbhr(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ೪"),e2qDYgipPmTw4KvBLnochr(u"ࠪฮ๊ࠦศ็ฮสัࠥ็อึࠢส่ส฼วโห࡟ࡲࡡࡴࠧ೫")+OP6LIZw9Y2JzlsEh817nQig[KNIvHPjUbhr(u"࠴ආ")])
	return
def Y6MUwOztEjeTSW7Ha(showDialogs):
	oReS4kbOZYEgH = [HHoGx7Flus60(u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩ೬"),LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪࠧ೭"),FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"࠭ࡳࡤࡴ࡬ࡴࡹ࠴࡭ࡰࡦࡸࡰࡪ࠴ࡲࡦࡵࡲࡰࡻ࡫ࡵࡳ࡮ࠪ೮"),OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠧࡴࡥࡵ࡭ࡵࡺ࠮࡮ࡱࡧࡹࡱ࡫࠮ࡺࡶ࠰ࡨࡱࡶࠧ೯")]
	MvNcqx5hkY = [dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦ࠱ࡳࡹ࡮ࡥࡳࡵࠪ೰"),rwQN9AKhLCuMfHxjlbX0U(u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧ࠲࡬࡯ࡴࡦࡧࠪೱ"),QVDJLRlxNg127jMX(u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨ࠳ࡶࡹࡵࡪࡲࡲࡦࡴࡹࡸࡪࡨࡶࡪ࠭ೲ"),jeAby54c02TgG8zuivonX91(u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠴ࡧࡪࡶ࡫ࡹࡧ࠭ೳ"),xcChIL13BpR8WArNt9Pl0So(u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪ࠮ࡨ࡫ࡷࡩࡦ࠭೴"),dv0trJR7PwmKyxDYO52VLau8gEph(u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤ࠯ࡥࡲࡨࡪࡨࡥࡳࡩࠪ೵")]
	for nUy7x6dqmk92MPb in MvNcqx5hkY: HDG0sQFwOvSt39Tp4ix15goYNnkCJA(nUy7x6dqmk92MPb)
	BxcQwOiEX8JSl9tonLUgu04yvC(oReS4kbOZYEgH,showDialogs,fEXMiAyG3ql4vKB,fEXMiAyG3ql4vKB)
	return
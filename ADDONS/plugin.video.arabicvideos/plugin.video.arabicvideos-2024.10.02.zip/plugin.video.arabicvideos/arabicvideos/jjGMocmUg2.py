# -*- coding: utf-8 -*-
from yoY3NdGViS import *
bBER0HlPYh4ZXm6ILWw = 'FAVORITES'
def GwmTvrCi2VudfPSOq0x(JbpxsyQVXmSEYKM3vo847Ckh,pJ7tKUEudAD60XvonZeF):
	if   JbpxsyQVXmSEYKM3vo847Ckh==270: x4xVJLXyIQbSqlHWem = Q7qM9UmTskpgznERAX5wKo0hDb(pJ7tKUEudAD60XvonZeF)
	else: x4xVJLXyIQbSqlHWem = False
	return x4xVJLXyIQbSqlHWem
def Lw8WcPiZ7u6jzh0(kCaIufXo1F0TyL7gtcJV5bneijMWHv,pJ7tKUEudAD60XvonZeF,fpqj0EscR7mi2Ltu5vWKYr3D):
	if not kCaIufXo1F0TyL7gtcJV5bneijMWHv: return
	if   fpqj0EscR7mi2Ltu5vWKYr3D=='UP1'	: vJxcLsjFyu5UWM4b1XCN9rA8SqK(pJ7tKUEudAD60XvonZeF,True,bXukYxQ4aHw)
	elif fpqj0EscR7mi2Ltu5vWKYr3D=='DOWN1'	: vJxcLsjFyu5UWM4b1XCN9rA8SqK(pJ7tKUEudAD60XvonZeF,False,bXukYxQ4aHw)
	elif fpqj0EscR7mi2Ltu5vWKYr3D=='UP4'	: vJxcLsjFyu5UWM4b1XCN9rA8SqK(pJ7tKUEudAD60XvonZeF,True,jR6BYWNFZ0egmH4Tr2Q78LbSs3t)
	elif fpqj0EscR7mi2Ltu5vWKYr3D=='DOWN4'	: vJxcLsjFyu5UWM4b1XCN9rA8SqK(pJ7tKUEudAD60XvonZeF,False,jR6BYWNFZ0egmH4Tr2Q78LbSs3t)
	elif fpqj0EscR7mi2Ltu5vWKYr3D=='ADD1'	: QwDT7cFmtizoVfdZrvY(pJ7tKUEudAD60XvonZeF)
	elif fpqj0EscR7mi2Ltu5vWKYr3D=='REMOVE1': vFOX8gwY6UZc9LfIdGJBiz2orl(pJ7tKUEudAD60XvonZeF)
	elif fpqj0EscR7mi2Ltu5vWKYr3D=='DELETELIST': Z2lI3wBj67iChs0upFkK94orfbJxnW(pJ7tKUEudAD60XvonZeF)
	return
def Q7qM9UmTskpgznERAX5wKo0hDb(pJ7tKUEudAD60XvonZeF):
	F8FLvN50urzmJ9yPn1AitRpQ = Z54CwW0eVXn()
	if pJ7tKUEudAD60XvonZeF in list(F8FLvN50urzmJ9yPn1AitRpQ.keys()):
		try:
			CoebtFizLxq1Y = F8FLvN50urzmJ9yPn1AitRpQ[pJ7tKUEudAD60XvonZeF]
			if ybdv7XcT3lxF6QezULwCAGk and pJ7tKUEudAD60XvonZeF in ['5','11','12','13']:
				for udRvjXt9cAfha5ZsBP3U,j4lHpxXvnF2VtwBb1T9PaJEm3,O9z5L3KtXqPEMepJQ0,JbpxsyQVXmSEYKM3vo847Ckh,acysH2W9N0BhXIvJPRM5t,z5NBJ1tXibWlaTfhdo0FG,s9ea72VfoygAOFRCWQTH3zmDuLPE,kCaIufXo1F0TyL7gtcJV5bneijMWHv,kFeSKZb8qiVd4GxwcAMHQolgU in CoebtFizLxq1Y:
					if udRvjXt9cAfha5ZsBP3U=='video':
						RLDCGt8kq3OVmnzgx1rbi2f7F('video',hXB0vKVQ5PRI91SDTprMdfuHEm4+'تشغيل من الأعلى إلى الأسفل'+YYSh2J6BIrsm8,O9z5L3KtXqPEMepJQ0,JbpxsyQVXmSEYKM3vo847Ckh,acysH2W9N0BhXIvJPRM5t,z5NBJ1tXibWlaTfhdo0FG,s9ea72VfoygAOFRCWQTH3zmDuLPE,kCaIufXo1F0TyL7gtcJV5bneijMWHv)
						RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
						break
			for udRvjXt9cAfha5ZsBP3U,j4lHpxXvnF2VtwBb1T9PaJEm3,O9z5L3KtXqPEMepJQ0,JbpxsyQVXmSEYKM3vo847Ckh,acysH2W9N0BhXIvJPRM5t,z5NBJ1tXibWlaTfhdo0FG,s9ea72VfoygAOFRCWQTH3zmDuLPE,kCaIufXo1F0TyL7gtcJV5bneijMWHv,kFeSKZb8qiVd4GxwcAMHQolgU in CoebtFizLxq1Y:
				RLDCGt8kq3OVmnzgx1rbi2f7F(udRvjXt9cAfha5ZsBP3U,j4lHpxXvnF2VtwBb1T9PaJEm3,O9z5L3KtXqPEMepJQ0,JbpxsyQVXmSEYKM3vo847Ckh,acysH2W9N0BhXIvJPRM5t,z5NBJ1tXibWlaTfhdo0FG,s9ea72VfoygAOFRCWQTH3zmDuLPE,kCaIufXo1F0TyL7gtcJV5bneijMWHv,kFeSKZb8qiVd4GxwcAMHQolgU)
		except:
			F8FLvN50urzmJ9yPn1AitRpQ = rpIZC2m6gEkAh(IlCq2uKjye3ZgSADFc)
			CoebtFizLxq1Y = F8FLvN50urzmJ9yPn1AitRpQ[pJ7tKUEudAD60XvonZeF]
			for udRvjXt9cAfha5ZsBP3U,j4lHpxXvnF2VtwBb1T9PaJEm3,O9z5L3KtXqPEMepJQ0,JbpxsyQVXmSEYKM3vo847Ckh,acysH2W9N0BhXIvJPRM5t,z5NBJ1tXibWlaTfhdo0FG,s9ea72VfoygAOFRCWQTH3zmDuLPE,kCaIufXo1F0TyL7gtcJV5bneijMWHv,kFeSKZb8qiVd4GxwcAMHQolgU in CoebtFizLxq1Y:
				RLDCGt8kq3OVmnzgx1rbi2f7F(udRvjXt9cAfha5ZsBP3U,j4lHpxXvnF2VtwBb1T9PaJEm3,O9z5L3KtXqPEMepJQ0,JbpxsyQVXmSEYKM3vo847Ckh,acysH2W9N0BhXIvJPRM5t,z5NBJ1tXibWlaTfhdo0FG,s9ea72VfoygAOFRCWQTH3zmDuLPE,kCaIufXo1F0TyL7gtcJV5bneijMWHv,kFeSKZb8qiVd4GxwcAMHQolgU)
	return
def QwDT7cFmtizoVfdZrvY(pJ7tKUEudAD60XvonZeF):
	udRvjXt9cAfha5ZsBP3U,j4lHpxXvnF2VtwBb1T9PaJEm3,O9z5L3KtXqPEMepJQ0,JbpxsyQVXmSEYKM3vo847Ckh,acysH2W9N0BhXIvJPRM5t,z5NBJ1tXibWlaTfhdo0FG,s9ea72VfoygAOFRCWQTH3zmDuLPE,kCaIufXo1F0TyL7gtcJV5bneijMWHv,kFeSKZb8qiVd4GxwcAMHQolgU = vikbdSOtZJFz6gQeL(i2tpOA6QzlfUByTSeKacWnV1)
	if pJ7tKUEudAD60XvonZeF in ['5','11','12','13'] and udRvjXt9cAfha5ZsBP3U!='video':
		BZj61bFtfWLzXp('','','رسالة من المبرمج','هذا العنصر ليس ملف فيديو .. قوائم التشغيل فائدتها تشغيل الفيديوهات خلف بعضها أوتوماتيكيا .. ولهذا قوائم التشغيل يجب أن تحتوي على فيديوهات فقط')
		return
	aQNvODnTB3mjP76kR = udRvjXt9cAfha5ZsBP3U,j4lHpxXvnF2VtwBb1T9PaJEm3,O9z5L3KtXqPEMepJQ0,JbpxsyQVXmSEYKM3vo847Ckh,acysH2W9N0BhXIvJPRM5t,z5NBJ1tXibWlaTfhdo0FG,s9ea72VfoygAOFRCWQTH3zmDuLPE,hWGMqtBy4wuLaVcj,kFeSKZb8qiVd4GxwcAMHQolgU
	F8FLvN50urzmJ9yPn1AitRpQ = Z54CwW0eVXn()
	rpTPBIMdvNcm = {}
	for fxlnU8T0PGc in list(F8FLvN50urzmJ9yPn1AitRpQ.keys()):
		if fxlnU8T0PGc!=pJ7tKUEudAD60XvonZeF: rpTPBIMdvNcm[fxlnU8T0PGc] = F8FLvN50urzmJ9yPn1AitRpQ[fxlnU8T0PGc]
		else:
			if j4lHpxXvnF2VtwBb1T9PaJEm3 and j4lHpxXvnF2VtwBb1T9PaJEm3!='..':
				kbncvMgw81JAhfDlWC = F8FLvN50urzmJ9yPn1AitRpQ[fxlnU8T0PGc]
				if aQNvODnTB3mjP76kR in kbncvMgw81JAhfDlWC:
					JKlc1vHiA9DVuFhyr = kbncvMgw81JAhfDlWC.index(aQNvODnTB3mjP76kR)
					del kbncvMgw81JAhfDlWC[JKlc1vHiA9DVuFhyr]
				g0HUt1KcaNwoI = kbncvMgw81JAhfDlWC+[aQNvODnTB3mjP76kR]
				rpTPBIMdvNcm[fxlnU8T0PGc] = g0HUt1KcaNwoI
			else: rpTPBIMdvNcm[fxlnU8T0PGc] = F8FLvN50urzmJ9yPn1AitRpQ[fxlnU8T0PGc]
	if pJ7tKUEudAD60XvonZeF not in list(rpTPBIMdvNcm.keys()): rpTPBIMdvNcm[pJ7tKUEudAD60XvonZeF] = [aQNvODnTB3mjP76kR]
	ITBcP0p1L6mzJDlUYKvOSry = str(rpTPBIMdvNcm)
	if H4qZ2hwilNJYTmCFEQyaSs98cPM0gR: ITBcP0p1L6mzJDlUYKvOSry = ITBcP0p1L6mzJDlUYKvOSry.encode(a7VXeDU82IfQEnPZAdiT)
	open(IlCq2uKjye3ZgSADFc,'wb').write(ITBcP0p1L6mzJDlUYKvOSry)
	return
def vFOX8gwY6UZc9LfIdGJBiz2orl(pJ7tKUEudAD60XvonZeF):
	udRvjXt9cAfha5ZsBP3U,j4lHpxXvnF2VtwBb1T9PaJEm3,O9z5L3KtXqPEMepJQ0,JbpxsyQVXmSEYKM3vo847Ckh,acysH2W9N0BhXIvJPRM5t,z5NBJ1tXibWlaTfhdo0FG,s9ea72VfoygAOFRCWQTH3zmDuLPE,kCaIufXo1F0TyL7gtcJV5bneijMWHv,kFeSKZb8qiVd4GxwcAMHQolgU = vikbdSOtZJFz6gQeL(i2tpOA6QzlfUByTSeKacWnV1)
	aQNvODnTB3mjP76kR = udRvjXt9cAfha5ZsBP3U,j4lHpxXvnF2VtwBb1T9PaJEm3,O9z5L3KtXqPEMepJQ0,JbpxsyQVXmSEYKM3vo847Ckh,acysH2W9N0BhXIvJPRM5t,z5NBJ1tXibWlaTfhdo0FG,s9ea72VfoygAOFRCWQTH3zmDuLPE,hWGMqtBy4wuLaVcj,kFeSKZb8qiVd4GxwcAMHQolgU
	F8FLvN50urzmJ9yPn1AitRpQ = Z54CwW0eVXn()
	if pJ7tKUEudAD60XvonZeF in list(F8FLvN50urzmJ9yPn1AitRpQ.keys()) and aQNvODnTB3mjP76kR in F8FLvN50urzmJ9yPn1AitRpQ[pJ7tKUEudAD60XvonZeF]:
		F8FLvN50urzmJ9yPn1AitRpQ[pJ7tKUEudAD60XvonZeF].remove(aQNvODnTB3mjP76kR)
		if len(F8FLvN50urzmJ9yPn1AitRpQ[pJ7tKUEudAD60XvonZeF])==ybdv7XcT3lxF6QezULwCAGk: del F8FLvN50urzmJ9yPn1AitRpQ[pJ7tKUEudAD60XvonZeF]
		ITBcP0p1L6mzJDlUYKvOSry = str(F8FLvN50urzmJ9yPn1AitRpQ)
		if H4qZ2hwilNJYTmCFEQyaSs98cPM0gR: ITBcP0p1L6mzJDlUYKvOSry = ITBcP0p1L6mzJDlUYKvOSry.encode(a7VXeDU82IfQEnPZAdiT)
		open(IlCq2uKjye3ZgSADFc,'wb').write(ITBcP0p1L6mzJDlUYKvOSry)
	return
def vJxcLsjFyu5UWM4b1XCN9rA8SqK(pJ7tKUEudAD60XvonZeF,ND2UFoKBymvwxRa5qWbXOjrH,CCfXThOorUbA5saFk):
	udRvjXt9cAfha5ZsBP3U,j4lHpxXvnF2VtwBb1T9PaJEm3,O9z5L3KtXqPEMepJQ0,JbpxsyQVXmSEYKM3vo847Ckh,acysH2W9N0BhXIvJPRM5t,z5NBJ1tXibWlaTfhdo0FG,s9ea72VfoygAOFRCWQTH3zmDuLPE,kCaIufXo1F0TyL7gtcJV5bneijMWHv,kFeSKZb8qiVd4GxwcAMHQolgU = vikbdSOtZJFz6gQeL(i2tpOA6QzlfUByTSeKacWnV1)
	aQNvODnTB3mjP76kR = udRvjXt9cAfha5ZsBP3U,j4lHpxXvnF2VtwBb1T9PaJEm3,O9z5L3KtXqPEMepJQ0,JbpxsyQVXmSEYKM3vo847Ckh,acysH2W9N0BhXIvJPRM5t,z5NBJ1tXibWlaTfhdo0FG,s9ea72VfoygAOFRCWQTH3zmDuLPE,hWGMqtBy4wuLaVcj,kFeSKZb8qiVd4GxwcAMHQolgU
	F8FLvN50urzmJ9yPn1AitRpQ = Z54CwW0eVXn()
	if pJ7tKUEudAD60XvonZeF in list(F8FLvN50urzmJ9yPn1AitRpQ.keys()):
		kbncvMgw81JAhfDlWC = F8FLvN50urzmJ9yPn1AitRpQ[pJ7tKUEudAD60XvonZeF]
		if aQNvODnTB3mjP76kR not in kbncvMgw81JAhfDlWC: return
		BBRClkiFSfjqUa2bxWheyO37vE = len(kbncvMgw81JAhfDlWC)
		for qHM8P3uk06wSa1VfZXijWN2 in range(ybdv7XcT3lxF6QezULwCAGk,CCfXThOorUbA5saFk):
			qwhg1dLAB0xYJ9KmoTGu = kbncvMgw81JAhfDlWC.index(aQNvODnTB3mjP76kR)
			if ND2UFoKBymvwxRa5qWbXOjrH: rX1PvUbKEI = qwhg1dLAB0xYJ9KmoTGu-bXukYxQ4aHw
			else: rX1PvUbKEI = qwhg1dLAB0xYJ9KmoTGu+bXukYxQ4aHw
			if rX1PvUbKEI>=BBRClkiFSfjqUa2bxWheyO37vE: rX1PvUbKEI = rX1PvUbKEI-BBRClkiFSfjqUa2bxWheyO37vE
			if rX1PvUbKEI<ybdv7XcT3lxF6QezULwCAGk: rX1PvUbKEI = rX1PvUbKEI+BBRClkiFSfjqUa2bxWheyO37vE
			kbncvMgw81JAhfDlWC.insert(rX1PvUbKEI, kbncvMgw81JAhfDlWC.pop(qwhg1dLAB0xYJ9KmoTGu))
		F8FLvN50urzmJ9yPn1AitRpQ[pJ7tKUEudAD60XvonZeF] = kbncvMgw81JAhfDlWC
		ITBcP0p1L6mzJDlUYKvOSry = str(F8FLvN50urzmJ9yPn1AitRpQ)
		if H4qZ2hwilNJYTmCFEQyaSs98cPM0gR: ITBcP0p1L6mzJDlUYKvOSry = ITBcP0p1L6mzJDlUYKvOSry.encode(a7VXeDU82IfQEnPZAdiT)
		open(IlCq2uKjye3ZgSADFc,'wb').write(ITBcP0p1L6mzJDlUYKvOSry)
	return
def ooYVEyjnOMhvFxgLqDbmNzrJ6Wa(pJ7tKUEudAD60XvonZeF):
	if pJ7tKUEudAD60XvonZeF in ['1','2','3','4']: AjY7FfSNvhCldLzE6XK8iO2x,CCqwES6ZTI = 'مفضلة',pJ7tKUEudAD60XvonZeF
	elif pJ7tKUEudAD60XvonZeF in ['5']: AjY7FfSNvhCldLzE6XK8iO2x,CCqwES6ZTI = 'تشغيل','1'
	elif pJ7tKUEudAD60XvonZeF in ['11']: AjY7FfSNvhCldLzE6XK8iO2x,CCqwES6ZTI = 'تشغيل','2'
	else: AjY7FfSNvhCldLzE6XK8iO2x,CCqwES6ZTI = hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj
	uBQc7t1kiqXJ0SPI2 = AjY7FfSNvhCldLzE6XK8iO2x+Mpsm2VF1OBnCRvK3qf6+CCqwES6ZTI
	return uBQc7t1kiqXJ0SPI2
def Z2lI3wBj67iChs0upFkK94orfbJxnW(pJ7tKUEudAD60XvonZeF):
	uBQc7t1kiqXJ0SPI2 = ooYVEyjnOMhvFxgLqDbmNzrJ6Wa(pJ7tKUEudAD60XvonZeF)
	MeYJm41G2j6Wn = XVmKrby29eCGMnlEY6jz0HNOR('center',hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'رسالة من المبرمج','هل تريد فعلا مسح جميع محتويات قائمة '+uBQc7t1kiqXJ0SPI2+' ؟!')
	if MeYJm41G2j6Wn!=1: return
	F8FLvN50urzmJ9yPn1AitRpQ = Z54CwW0eVXn()
	if pJ7tKUEudAD60XvonZeF in list(F8FLvN50urzmJ9yPn1AitRpQ.keys()):
		del F8FLvN50urzmJ9yPn1AitRpQ[pJ7tKUEudAD60XvonZeF]
		ITBcP0p1L6mzJDlUYKvOSry = str(F8FLvN50urzmJ9yPn1AitRpQ)
		if H4qZ2hwilNJYTmCFEQyaSs98cPM0gR: ITBcP0p1L6mzJDlUYKvOSry = ITBcP0p1L6mzJDlUYKvOSry.encode(a7VXeDU82IfQEnPZAdiT)
		open(IlCq2uKjye3ZgSADFc,'wb').write(ITBcP0p1L6mzJDlUYKvOSry)
		BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'رسالة من المبرمج','تم مسح جميع محتويات قائمة '+uBQc7t1kiqXJ0SPI2)
	return
def Z54CwW0eVXn():
	F8FLvN50urzmJ9yPn1AitRpQ = {}
	if WQvYkNg7SysPFLitlGEn6.path.exists(IlCq2uKjye3ZgSADFc):
		WxKPpOGYbB5qJREFc = open(IlCq2uKjye3ZgSADFc,'rb').read()
		if H4qZ2hwilNJYTmCFEQyaSs98cPM0gR: WxKPpOGYbB5qJREFc = WxKPpOGYbB5qJREFc.decode(a7VXeDU82IfQEnPZAdiT)
		F8FLvN50urzmJ9yPn1AitRpQ = Cy9ow3c21nABMjzqeaIT('dict',WxKPpOGYbB5qJREFc)
	return F8FLvN50urzmJ9yPn1AitRpQ
def AAZbtg5RKeUcr47IYTvVSaELqN(F8FLvN50urzmJ9yPn1AitRpQ,aQNvODnTB3mjP76kR,oTMRJVqbuIzxf1EH9D):
	udRvjXt9cAfha5ZsBP3U,j4lHpxXvnF2VtwBb1T9PaJEm3,O9z5L3KtXqPEMepJQ0,JbpxsyQVXmSEYKM3vo847Ckh,acysH2W9N0BhXIvJPRM5t,z5NBJ1tXibWlaTfhdo0FG,s9ea72VfoygAOFRCWQTH3zmDuLPE,kCaIufXo1F0TyL7gtcJV5bneijMWHv,kFeSKZb8qiVd4GxwcAMHQolgU = aQNvODnTB3mjP76kR
	if not JbpxsyQVXmSEYKM3vo847Ckh: udRvjXt9cAfha5ZsBP3U,JbpxsyQVXmSEYKM3vo847Ckh = 'folder','260'
	qVYf17gFI0bR3l45JXQ,pJ7tKUEudAD60XvonZeF = [],hWGMqtBy4wuLaVcj
	if 'context=' in i2tpOA6QzlfUByTSeKacWnV1:
		rrXw9fL6coyIE8gRaZ4l5HnMGp = trdVA0JvFaD.findall('context=(\d+)',i2tpOA6QzlfUByTSeKacWnV1,trdVA0JvFaD.DOTALL)
		if rrXw9fL6coyIE8gRaZ4l5HnMGp: pJ7tKUEudAD60XvonZeF = str(rrXw9fL6coyIE8gRaZ4l5HnMGp[ybdv7XcT3lxF6QezULwCAGk])
	if JbpxsyQVXmSEYKM3vo847Ckh=='270':
		pJ7tKUEudAD60XvonZeF = kCaIufXo1F0TyL7gtcJV5bneijMWHv
		if pJ7tKUEudAD60XvonZeF in list(F8FLvN50urzmJ9yPn1AitRpQ.keys()):
			uBQc7t1kiqXJ0SPI2 = ooYVEyjnOMhvFxgLqDbmNzrJ6Wa(pJ7tKUEudAD60XvonZeF)
			qVYf17gFI0bR3l45JXQ.append(('مسح قائمة '+uBQc7t1kiqXJ0SPI2,'RunPlugin('+oTMRJVqbuIzxf1EH9D+'&context='+pJ7tKUEudAD60XvonZeF+'_DELETELIST'+')'))
	else:
		if pJ7tKUEudAD60XvonZeF in list(F8FLvN50urzmJ9yPn1AitRpQ.keys()):
			count = len(F8FLvN50urzmJ9yPn1AitRpQ[pJ7tKUEudAD60XvonZeF])
			if count>bXukYxQ4aHw: qVYf17gFI0bR3l45JXQ.append(('تحريك 1 للأعلى','RunPlugin('+oTMRJVqbuIzxf1EH9D+'&context='+pJ7tKUEudAD60XvonZeF+'_UP1)'))
			if count>jR6BYWNFZ0egmH4Tr2Q78LbSs3t: qVYf17gFI0bR3l45JXQ.append(('تحريك 4 للأعلى','RunPlugin('+oTMRJVqbuIzxf1EH9D+'&context='+pJ7tKUEudAD60XvonZeF+'_UP4)'))
			if count>bXukYxQ4aHw: qVYf17gFI0bR3l45JXQ.append(('تحريك 1 للأسفل','RunPlugin('+oTMRJVqbuIzxf1EH9D+'&context='+pJ7tKUEudAD60XvonZeF+'_DOWN1)'))
			if count>jR6BYWNFZ0egmH4Tr2Q78LbSs3t: qVYf17gFI0bR3l45JXQ.append(('تحريك 4 للأسفل','RunPlugin('+oTMRJVqbuIzxf1EH9D+'&context='+pJ7tKUEudAD60XvonZeF+'_DOWN4)'))
		for pJ7tKUEudAD60XvonZeF in ['1','2','3','4','5','11']:
			uBQc7t1kiqXJ0SPI2 = ooYVEyjnOMhvFxgLqDbmNzrJ6Wa(pJ7tKUEudAD60XvonZeF)
			if pJ7tKUEudAD60XvonZeF in list(F8FLvN50urzmJ9yPn1AitRpQ.keys()) and aQNvODnTB3mjP76kR in F8FLvN50urzmJ9yPn1AitRpQ[pJ7tKUEudAD60XvonZeF]:
				qVYf17gFI0bR3l45JXQ.append(('مسح من '+uBQc7t1kiqXJ0SPI2,'RunPlugin('+oTMRJVqbuIzxf1EH9D+'&context='+pJ7tKUEudAD60XvonZeF+'_REMOVE1)'))
			else: qVYf17gFI0bR3l45JXQ.append(('إضافة ل'+uBQc7t1kiqXJ0SPI2,'RunPlugin('+oTMRJVqbuIzxf1EH9D+'&context='+pJ7tKUEudAD60XvonZeF+'_ADD1)'))
	jDZ5sgI0yV = []
	for F034iIv2O8NX657RZsHetaJjgcG,QTIV6PX1Kb in qVYf17gFI0bR3l45JXQ:
		F034iIv2O8NX657RZsHetaJjgcG = soMVfbr6WtpNlcSA+F034iIv2O8NX657RZsHetaJjgcG+YYSh2J6BIrsm8
		jDZ5sgI0yV.append((F034iIv2O8NX657RZsHetaJjgcG,QTIV6PX1Kb,))
	return jDZ5sgI0yV
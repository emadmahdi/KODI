# -*- coding: utf-8 -*-
from yoY3NdGViS import *
xjPuFK3EsIZSiobQ5X = 'EGYBESTVIP'
n0qFKQWhiBYXoTrvejVHUA4 = '_EGV_'
Str0BupDTFA = u6rbxnyjTl7I[xjPuFK3EsIZSiobQ5X][0]
def ehB18u9sQFRi(mode,url,l7COkhRWD9uVS60Pte2NoyAaZn,text):
	if   mode==220: N6NCYivtV4I5rEXq = DP6FSBgNdX1rsvVR()
	elif mode==221: N6NCYivtV4I5rEXq = wg5aF3e8rcDh7SGpW6M1OPnkU(url,l7COkhRWD9uVS60Pte2NoyAaZn)
	elif mode==222: N6NCYivtV4I5rEXq = qt2zjyIbsS(url)
	elif mode==223: N6NCYivtV4I5rEXq = oanus6TxUFNAhSZKpJdYlEC4mV(url)
	elif mode==224: N6NCYivtV4I5rEXq = hadMgR0nOKHoGqpA(url)
	elif mode==229: N6NCYivtV4I5rEXq = lPwaAjFTMG4n7iSLkXcEuK0Zm(text)
	else: N6NCYivtV4I5rEXq = False
	return N6NCYivtV4I5rEXq
def DP6FSBgNdX1rsvVR():
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'بحث في الموقع',hWGMqtBy4wuLaVcj,229,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'_REMEMBERRESULTS_')
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(DpQifS0oKBI1hYcO,'GET',Str0BupDTFA,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'EGYBEST-MENU-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('class="i i-home"(.*?)</div>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('href="(.*?)"(.*?)</a>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,title in items:
			if '</i>' in title: title = title.split('</i>')[1]
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,222)
		RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('class="ba(.*?)<script',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('pda bdb"><strong>(.*?)<.*?href="(.*?)"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		for title,llxFwq0CUNgQtivJzkHeGV in items:
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,221)
		RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
		items = trdVA0JvFaD.findall('href="(.*?)".*?>(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,title in items:
			if 'html' not in llxFwq0CUNgQtivJzkHeGV: continue
			if not llxFwq0CUNgQtivJzkHeGV.endswith('/'): RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,221)
	return mMQ3FkNVa4IlxqY
def qt2zjyIbsS(url):
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(DpQifS0oKBI1hYcO,'GET',url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'EGYBESTVIP-SUBMENU-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('class="rs_scroll"(.*?)</div>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
	items = trdVA0JvFaD.findall('href="(.*?)".*?</i>(.*?)</a>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	for llxFwq0CUNgQtivJzkHeGV,title in items:
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,224)
	return
def hadMgR0nOKHoGqpA(url):
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'الجميع',url,221)
	mMQ3FkNVa4IlxqY = f1fLNcPlo2ECKtiBeug0OAvz9YM(DpQifS0oKBI1hYcO,url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'EGYBESTVIP-FILTERS_MENU-1st')
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('class="sub_nav(.*?)id="movies',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('href="(.*?)".+?>(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,title in items:
			if llxFwq0CUNgQtivJzkHeGV=='#': name = title
			else:
				title = title + '  :  ' + 'فلتر ' + name
				RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,221)
	else: wg5aF3e8rcDh7SGpW6M1OPnkU(url)
	return
def wg5aF3e8rcDh7SGpW6M1OPnkU(url,l7COkhRWD9uVS60Pte2NoyAaZn='1'):
	if l7COkhRWD9uVS60Pte2NoyAaZn==hWGMqtBy4wuLaVcj: l7COkhRWD9uVS60Pte2NoyAaZn = '1'
	if '/search' in url or '?' in url: NPM3HKQ57xe = url + '&'
	else: NPM3HKQ57xe = url + '?'
	NPM3HKQ57xe = NPM3HKQ57xe + 'page=' + l7COkhRWD9uVS60Pte2NoyAaZn
	mMQ3FkNVa4IlxqY = f1fLNcPlo2ECKtiBeug0OAvz9YM(KqO5BWGQR9JVL,NPM3HKQ57xe,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'EGYBESTVIP-TITLES-1st')
	if '/season' in url:
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o=trdVA0JvFaD.findall('class="pda"(.*?)div',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[-1]
	elif '/series/' in url:
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o=trdVA0JvFaD.findall('class="owl-carousel owl-carousel(.*?)div',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
	else:
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o=trdVA0JvFaD.findall('id="movies(.*?)</div>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[-1]
	items = trdVA0JvFaD.findall('<a href="(.*?)".*?src="(.*?)".*?title">(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	for llxFwq0CUNgQtivJzkHeGV,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,title in items:
		title = LNtIDdBA52P(title)
		if '/movie/' in llxFwq0CUNgQtivJzkHeGV or '/episode' in llxFwq0CUNgQtivJzkHeGV:
			RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV.rstrip('/'),223,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
		else:
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,221,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
	if len(items)>=16:
		qYWa8fGFoyrhStsURIe = ['/movies','/tv','/search','/trending']
		l7COkhRWD9uVS60Pte2NoyAaZn = int(l7COkhRWD9uVS60Pte2NoyAaZn)
		if any(BoSjXKxz41DcneO9UimClE in url for BoSjXKxz41DcneO9UimClE in qYWa8fGFoyrhStsURIe):
			for R47xjBkH9IiXYcdDeS0VFtlw in range(0,1000,100):
				if int(l7COkhRWD9uVS60Pte2NoyAaZn/100)*100==R47xjBkH9IiXYcdDeS0VFtlw:
					for PPuqrvDLEViYOMf1dmkK7 in range(R47xjBkH9IiXYcdDeS0VFtlw,R47xjBkH9IiXYcdDeS0VFtlw+100,10):
						if int(l7COkhRWD9uVS60Pte2NoyAaZn/10)*10==PPuqrvDLEViYOMf1dmkK7:
							for rrEgp9JsojRK50Wwl6O in range(PPuqrvDLEViYOMf1dmkK7,PPuqrvDLEViYOMf1dmkK7+10,1):
								if not l7COkhRWD9uVS60Pte2NoyAaZn==rrEgp9JsojRK50Wwl6O and rrEgp9JsojRK50Wwl6O!=0:
									RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'صفحة '+str(rrEgp9JsojRK50Wwl6O),url,221,hWGMqtBy4wuLaVcj,str(rrEgp9JsojRK50Wwl6O))
						elif PPuqrvDLEViYOMf1dmkK7!=0: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'صفحة '+str(PPuqrvDLEViYOMf1dmkK7),url,221,hWGMqtBy4wuLaVcj,str(PPuqrvDLEViYOMf1dmkK7))
						else: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'صفحة '+str(1),url,221,hWGMqtBy4wuLaVcj,str(1))
				elif R47xjBkH9IiXYcdDeS0VFtlw!=0: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'صفحة '+str(R47xjBkH9IiXYcdDeS0VFtlw),url,221,hWGMqtBy4wuLaVcj,str(R47xjBkH9IiXYcdDeS0VFtlw))
				else: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'صفحة '+str(1),url,221)
	return
def oanus6TxUFNAhSZKpJdYlEC4mV(url):
	haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = [],[]
	mMQ3FkNVa4IlxqY = f1fLNcPlo2ECKtiBeug0OAvz9YM(DpQifS0oKBI1hYcO,url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'EGYBESTVIP-PLAY-1st')
	BX029UJFPvpNQsc45jbYZRh = trdVA0JvFaD.findall('<td>التصنيف</td>.*?">(.*?)<',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if BX029UJFPvpNQsc45jbYZRh and Dc20k3vN9hT5(xjPuFK3EsIZSiobQ5X,url,BX029UJFPvpNQsc45jbYZRh): return
	gSbTs57y6nA,VxrgMAqPs9Yek = hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj
	aJi6205AF4ygI1nDmxotX8MGRT,ckyBXWoqYHS8nwEDhM = mMQ3FkNVa4IlxqY,mMQ3FkNVa4IlxqY
	TTeYZjQVpKm9S = trdVA0JvFaD.findall('show_dl api" href="(.*?)"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if TTeYZjQVpKm9S:
		for llxFwq0CUNgQtivJzkHeGV in TTeYZjQVpKm9S:
			if '/watch/' in llxFwq0CUNgQtivJzkHeGV: gSbTs57y6nA = llxFwq0CUNgQtivJzkHeGV
			elif '/download/' in llxFwq0CUNgQtivJzkHeGV: VxrgMAqPs9Yek = llxFwq0CUNgQtivJzkHeGV
		if gSbTs57y6nA!=hWGMqtBy4wuLaVcj: aJi6205AF4ygI1nDmxotX8MGRT = f1fLNcPlo2ECKtiBeug0OAvz9YM(DpQifS0oKBI1hYcO,gSbTs57y6nA,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'EGYBESTVIP-PLAY-2nd')
		if VxrgMAqPs9Yek!=hWGMqtBy4wuLaVcj: ckyBXWoqYHS8nwEDhM = f1fLNcPlo2ECKtiBeug0OAvz9YM(DpQifS0oKBI1hYcO,VxrgMAqPs9Yek,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'EGYBESTVIP-PLAY-3rd')
	LKkXbB2qTFrg7Q5RV0maU = trdVA0JvFaD.findall('id="video".*?data-src="(.*?)"',aJi6205AF4ygI1nDmxotX8MGRT,trdVA0JvFaD.DOTALL)
	if LKkXbB2qTFrg7Q5RV0maU:
		NPM3HKQ57xe = LKkXbB2qTFrg7Q5RV0maU[0]
		if NPM3HKQ57xe!=hWGMqtBy4wuLaVcj and 'uploaded.egybest.download' in NPM3HKQ57xe and '/?id=_' not in NPM3HKQ57xe:
			eecmFXt5SRyCjGpx = f1fLNcPlo2ECKtiBeug0OAvz9YM(DpQifS0oKBI1hYcO,NPM3HKQ57xe,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'EGYBESTVIP-PLAY-4th')
			SrHRAUxtw9zmJdZfuLhY2l = trdVA0JvFaD.findall('source src="(.*?)" title="(.*?)"',eecmFXt5SRyCjGpx,trdVA0JvFaD.DOTALL)
			if SrHRAUxtw9zmJdZfuLhY2l:
				for llxFwq0CUNgQtivJzkHeGV,QS8ZdxkHD5bjU9qsn4zMYaPrg3h7 in SrHRAUxtw9zmJdZfuLhY2l:
					Dvi8asSrQYX5wE3KMIxT91me.append(llxFwq0CUNgQtivJzkHeGV+'?named=ed.egybest.do__watch__mp4__'+QS8ZdxkHD5bjU9qsn4zMYaPrg3h7)
			else:
				SODQ7qlNYoZcFK8e50rBsJaAHxiXjE = NPM3HKQ57xe.split('/')[2]
				Dvi8asSrQYX5wE3KMIxT91me.append(NPM3HKQ57xe+'?named='+SODQ7qlNYoZcFK8e50rBsJaAHxiXjE+'__watch')
		elif NPM3HKQ57xe!=hWGMqtBy4wuLaVcj:
			SODQ7qlNYoZcFK8e50rBsJaAHxiXjE = NPM3HKQ57xe.split('/')[2]
			Dvi8asSrQYX5wE3KMIxT91me.append(NPM3HKQ57xe+'?named='+SODQ7qlNYoZcFK8e50rBsJaAHxiXjE+'__watch')
	h1NtFB5G94sCZmKDiPgVcL827najx = trdVA0JvFaD.findall('<table class="dls_table(.*?)</table>',ckyBXWoqYHS8nwEDhM,trdVA0JvFaD.DOTALL)
	if h1NtFB5G94sCZmKDiPgVcL827najx:
		h1NtFB5G94sCZmKDiPgVcL827najx = h1NtFB5G94sCZmKDiPgVcL827najx[0]
		pIO96bMCwfRGnQ23Yz = trdVA0JvFaD.findall('<td>.*?<td>(.*?)<.*?href="(.*?)"',h1NtFB5G94sCZmKDiPgVcL827najx,trdVA0JvFaD.DOTALL)
		if pIO96bMCwfRGnQ23Yz:
			for QS8ZdxkHD5bjU9qsn4zMYaPrg3h7,llxFwq0CUNgQtivJzkHeGV in pIO96bMCwfRGnQ23Yz:
				if 'myegyvip' not in llxFwq0CUNgQtivJzkHeGV: continue
				if llxFwq0CUNgQtivJzkHeGV.count('/')>=2:
					SODQ7qlNYoZcFK8e50rBsJaAHxiXjE = llxFwq0CUNgQtivJzkHeGV.split('/')[2]
					Dvi8asSrQYX5wE3KMIxT91me.append(llxFwq0CUNgQtivJzkHeGV+'?named='+SODQ7qlNYoZcFK8e50rBsJaAHxiXjE+'__download__mp4__'+QS8ZdxkHD5bjU9qsn4zMYaPrg3h7)
	kF8wafyIPSEV6p0bigxAq = []
	for llxFwq0CUNgQtivJzkHeGV in Dvi8asSrQYX5wE3KMIxT91me:
		kF8wafyIPSEV6p0bigxAq.append(llxFwq0CUNgQtivJzkHeGV)
	import oosSOfvdEQ
	oosSOfvdEQ.zfdYjsGLg8M6i15qZWh(kF8wafyIPSEV6p0bigxAq,xjPuFK3EsIZSiobQ5X,'video',url)
	return
def lPwaAjFTMG4n7iSLkXcEuK0Zm(search):
	search,vvKf4sXgZIMyEJPuC,showDialogs = IVTEJQOiMR2dYta9C(search)
	if search==hWGMqtBy4wuLaVcj: search = TrzfUidpv1LyAYqwexHJDuS()
	if search==hWGMqtBy4wuLaVcj: return
	lKqyOtIAvVY = search.replace(Mpsm2VF1OBnCRvK3qf6,'+')
	mMQ3FkNVa4IlxqY = f1fLNcPlo2ECKtiBeug0OAvz9YM(nHBb7jXk0Daom,Str0BupDTFA,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'EGYBESTVIP-SEARCH-1st')
	vanQT4j5Z8SfO2MHg19I = trdVA0JvFaD.findall('name="_token" value="(.*?)"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if vanQT4j5Z8SfO2MHg19I:
		url = Str0BupDTFA+'/search?_token='+vanQT4j5Z8SfO2MHg19I[0]+'&q='+lKqyOtIAvVY
		wg5aF3e8rcDh7SGpW6M1OPnkU(url)
	return
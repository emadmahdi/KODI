# -*- coding: utf-8 -*-
import sys as zGjD5QAkd7SO9YPcZl
A56Abl2j14QS = zGjD5QAkd7SO9YPcZl.version_info [0] == 2
qO2vebR9rSTZnuJDW = 2048
EECQl2Zun37S0KkWwtIDHYNai6Ayd8 = 7
def wwTjCFmkUK (mMBv4T89VDdfJGL):
	global ylRUYSmHX7oCf93TADc8J6rqMVL
	tE23ZuI91qGJ = ord (mMBv4T89VDdfJGL [-1])
	huZOyFMzvY3LpEf = mMBv4T89VDdfJGL [:-1]
	FXE237NbgJweKmBxPfVnsAoYjCazqW = tE23ZuI91qGJ % len (huZOyFMzvY3LpEf)
	LQ2yAP51CVNFXdr = huZOyFMzvY3LpEf [:FXE237NbgJweKmBxPfVnsAoYjCazqW] + huZOyFMzvY3LpEf [FXE237NbgJweKmBxPfVnsAoYjCazqW:]
	if A56Abl2j14QS:
		R0i7UHvbBw25n8 = unicode () .join ([unichr (ord (cIsD9VN758uwbLUaGM2zmEY) - qO2vebR9rSTZnuJDW - (o42QnFjKJ5l98hWTqzCDi73LcvNA + tE23ZuI91qGJ) % EECQl2Zun37S0KkWwtIDHYNai6Ayd8) for o42QnFjKJ5l98hWTqzCDi73LcvNA, cIsD9VN758uwbLUaGM2zmEY in enumerate (LQ2yAP51CVNFXdr)])
	else:
		R0i7UHvbBw25n8 = str () .join ([chr (ord (cIsD9VN758uwbLUaGM2zmEY) - qO2vebR9rSTZnuJDW - (o42QnFjKJ5l98hWTqzCDi73LcvNA + tE23ZuI91qGJ) % EECQl2Zun37S0KkWwtIDHYNai6Ayd8) for o42QnFjKJ5l98hWTqzCDi73LcvNA, cIsD9VN758uwbLUaGM2zmEY in enumerate (LQ2yAP51CVNFXdr)])
	return eval (R0i7UHvbBw25n8)
NeO3CTLHrPfWUoIgy8Q,KNIvHPjUbhr,CnbBKmtF1x84q7AW=wwTjCFmkUK,wwTjCFmkUK,wwTjCFmkUK
zyvJMtBhrw,MMizeNH0AKu,KBkxSYaz93pu1=CnbBKmtF1x84q7AW,KNIvHPjUbhr,NeO3CTLHrPfWUoIgy8Q
LB2q7IVRpcyXlE6C3ihZruPe4An1Y,EDgpT9hIF6GCfl0vXiWnBANjOUVRua,XQo0YS3sk4rHAvwyNltf9CipLWMjx=KBkxSYaz93pu1,MMizeNH0AKu,zyvJMtBhrw
hWUz1ujibPY3G9MIZmvS4kVaK7dT,DJ1ICpbyR2,e2qDYgipPmTw4KvBLnochr=XQo0YS3sk4rHAvwyNltf9CipLWMjx,EDgpT9hIF6GCfl0vXiWnBANjOUVRua,LB2q7IVRpcyXlE6C3ihZruPe4An1Y
A6dMB1FlgxVivJ2fk9C,mkHKSQvjWr5BTcM3wVY,o1u5dij9UrcbXzVS8lwIWfKpnqM=e2qDYgipPmTw4KvBLnochr,DJ1ICpbyR2,hWUz1ujibPY3G9MIZmvS4kVaK7dT
JwiZdgbG5HYuCIsj69aBSRQ0nrNkET,SqrG5mU3j96ldsFpExobw40TJY,HHoGx7Flus60=o1u5dij9UrcbXzVS8lwIWfKpnqM,mkHKSQvjWr5BTcM3wVY,A6dMB1FlgxVivJ2fk9C
QVDJLRlxNg127jMX,gDuGMR3z1aV6YdLmCpiO8Kl,jeAby54c02TgG8zuivonX91=HHoGx7Flus60,SqrG5mU3j96ldsFpExobw40TJY,JwiZdgbG5HYuCIsj69aBSRQ0nrNkET
S1SgCFYGJeMvfp5iZXK,dv0trJR7PwmKyxDYO52VLau8gEph,QvgnCALNstmuUJiET=jeAby54c02TgG8zuivonX91,gDuGMR3z1aV6YdLmCpiO8Kl,QVDJLRlxNg127jMX
OOsBSKq9u6J2lC5WdYpvNMHaFP4,rwQN9AKhLCuMfHxjlbX0U,xcChIL13BpR8WArNt9Pl0So=QvgnCALNstmuUJiET,dv0trJR7PwmKyxDYO52VLau8gEph,S1SgCFYGJeMvfp5iZXK
sULh4NjakzI8He7xJCMGrql,LAhIMyBG0xZVUlO4rJ9z5fbDFgCs,GA4NBdjuZqkKUX6IEMvHPoegDyVrLm=xcChIL13BpR8WArNt9Pl0So,rwQN9AKhLCuMfHxjlbX0U,OOsBSKq9u6J2lC5WdYpvNMHaFP4
ITvnUAMXsyb4eO,wwPrSDa21lUh,FimxS5jkaq1RcJ8DnWTZNO4zQClwt=GA4NBdjuZqkKUX6IEMvHPoegDyVrLm,LAhIMyBG0xZVUlO4rJ9z5fbDFgCs,sULh4NjakzI8He7xJCMGrql
from yoY3NdGViS import *
xjPuFK3EsIZSiobQ5X = KNIvHPjUbhr(u"ࠫࡉࡕࡗࡏࡎࡒࡅࡉ࠭ࢡ")
def ehB18u9sQFRi(JbpxsyQVXmSEYKM3vo847Ckh,O9z5L3KtXqPEMepJQ0):
	if   JbpxsyQVXmSEYKM3vo847Ckh==sULh4NjakzI8He7xJCMGrql(u"࠹࠳࠱श"): N6NCYivtV4I5rEXq = KVbjOeuBXDp()
	elif JbpxsyQVXmSEYKM3vo847Ckh==DJ1ICpbyR2(u"࠳࠴࠳ष"): N6NCYivtV4I5rEXq = oanus6TxUFNAhSZKpJdYlEC4mV(O9z5L3KtXqPEMepJQ0)
	elif JbpxsyQVXmSEYKM3vo847Ckh==XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"࠴࠵࠵स"): N6NCYivtV4I5rEXq = mCtvqr6j8a3ZNB1iwyl()
	elif JbpxsyQVXmSEYKM3vo847Ckh==rwQN9AKhLCuMfHxjlbX0U(u"࠵࠶࠷ह"): N6NCYivtV4I5rEXq = NXMPTIZnGDqEWJgsjFr()
	else: N6NCYivtV4I5rEXq = fEXMiAyG3ql4vKB
	return N6NCYivtV4I5rEXq
def oanus6TxUFNAhSZKpJdYlEC4mV(O9z5L3KtXqPEMepJQ0):
	vOq38Y4XVZwdE(O9z5L3KtXqPEMepJQ0,xjPuFK3EsIZSiobQ5X,DJ1ICpbyR2(u"ࠬࡼࡩࡥࡧࡲࠫࢢ"))
	return
def NXMPTIZnGDqEWJgsjFr():
	jjEwJpmd2v0oxBRP1Dyu = OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"࠭รั้หࠤส๊้ࠡำสฬ฼ࠦวๅใํำ๏๎ࠠฤ๊ࠣห้฻่หࠢไ๎ࠥอไๆ๊ๅ฽ࠥอไๆู็์อࠦหๆࠢฦฺ฿฽ฺࠠๆ์ࠤืืࠠศๆๅหห๋ษࠡษ็๎๊๐ๆࠡอ่ࠤศิสศำࠣࠦฯำๅ๋ๆ้้ࠣ็วหࠢไ๎ิ๐่ࠣࠢฮ้ࠥอฮหษิࠤิ่ษࠡษ็ูํืษ๊ࠡสาฯอั่๋ࠡ฽๋ࠥไโࠢสฺ่๎ัส๋ࠢฬ฾ี็ศࠢึ์ๆ๊ࠦษัฦࠤฬ๊สฮ็ํ่ࠬࢣ")
	BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,HHoGx7Flus60(u"ุࠧำํๆฮࠦสฮ็ํ่ࠥอไๆๆไหฯ࠭ࢤ"),jjEwJpmd2v0oxBRP1Dyu)
	return
def KVbjOeuBXDp():
	RLDCGt8kq3OVmnzgx1rbi2f7F(A6dMB1FlgxVivJ2fk9C(u"ࠨ࡮࡬ࡲࡰ࠭ࢥ"),hXB0vKVQ5PRI91SDTprMdfuHEm4+KBkxSYaz93pu1(u"ฺࠩี๏่ษࠡฬะ้๏๊ࠠๆๆไหฯࠦวๅใํำ๏๎ࠧࢦ")+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"࠶࠷࠸ऺ"))
	RLDCGt8kq3OVmnzgx1rbi2f7F(XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠪࡰ࡮ࡴ࡫ࠨࢧ"),hXB0vKVQ5PRI91SDTprMdfuHEm4+MMizeNH0AKu(u"ࠫฯเ๊๋ำ้่ࠣอๆࠡฬะ้๏๊ࠠศๆไ๎ิ๐่่ษอࠫࢨ")+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,wwPrSDa21lUh(u"࠷࠸࠸ऻ"))
	RLDCGt8kq3OVmnzgx1rbi2f7F(o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠬࡲࡩ࡯࡭ࠪࢩ"),hXB0vKVQ5PRI91SDTprMdfuHEm4+rwQN9AKhLCuMfHxjlbX0U(u"࠭ࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࠬࢪ")+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,QvgnCALNstmuUJiET(u"࠾࠿࠹࠺़"))
	ZZqfPsz8uV = OYFsHXZI3azxSnKJMf4o71h()
	eGa1LwJD4Q5 = WQvYkNg7SysPFLitlGEn6.stat(ZZqfPsz8uV).st_mtime
	o9frzGZySuB7KL3xNTAMI6gl8XjqiH = []
	if H4qZ2hwilNJYTmCFEQyaSs98cPM0gR: ZON4Igtyx9YTCpkKq8bA = WQvYkNg7SysPFLitlGEn6.listdir(ZZqfPsz8uV.encode(a7VXeDU82IfQEnPZAdiT))
	else: ZON4Igtyx9YTCpkKq8bA = WQvYkNg7SysPFLitlGEn6.listdir(ZZqfPsz8uV.decode(a7VXeDU82IfQEnPZAdiT))
	for pRXW8ZM9Qhfd7aTsPGB3vOjcu in ZON4Igtyx9YTCpkKq8bA:
		if H4qZ2hwilNJYTmCFEQyaSs98cPM0gR: pRXW8ZM9Qhfd7aTsPGB3vOjcu = pRXW8ZM9Qhfd7aTsPGB3vOjcu.decode(a7VXeDU82IfQEnPZAdiT)
		if not pRXW8ZM9Qhfd7aTsPGB3vOjcu.startswith(gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠧࡧ࡫࡯ࡩࡤ࠭ࢫ")): continue
		rfWlSByapFbPk = WQvYkNg7SysPFLitlGEn6.path.join(ZZqfPsz8uV,pRXW8ZM9Qhfd7aTsPGB3vOjcu)
		eGa1LwJD4Q5 = WQvYkNg7SysPFLitlGEn6.path.getmtime(rfWlSByapFbPk)
		o9frzGZySuB7KL3xNTAMI6gl8XjqiH.append([pRXW8ZM9Qhfd7aTsPGB3vOjcu,eGa1LwJD4Q5])
	o9frzGZySuB7KL3xNTAMI6gl8XjqiH = sorted(o9frzGZySuB7KL3xNTAMI6gl8XjqiH,reverse=VBlawK4mgHSyLEn8iqhUkz5,key=lambda key: key[bXukYxQ4aHw])
	for pRXW8ZM9Qhfd7aTsPGB3vOjcu,eGa1LwJD4Q5 in o9frzGZySuB7KL3xNTAMI6gl8XjqiH:
		if VKiGj1LundAJQwEXcqgxC:
			try: pRXW8ZM9Qhfd7aTsPGB3vOjcu = pRXW8ZM9Qhfd7aTsPGB3vOjcu.decode(a7VXeDU82IfQEnPZAdiT)
			except: pass
			pRXW8ZM9Qhfd7aTsPGB3vOjcu = pRXW8ZM9Qhfd7aTsPGB3vOjcu.encode(a7VXeDU82IfQEnPZAdiT)
		rfWlSByapFbPk = WQvYkNg7SysPFLitlGEn6.path.join(ZZqfPsz8uV,pRXW8ZM9Qhfd7aTsPGB3vOjcu)
		RLDCGt8kq3OVmnzgx1rbi2f7F(o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠨࡸ࡬ࡨࡪࡵࠧࢬ"),pRXW8ZM9Qhfd7aTsPGB3vOjcu,rfWlSByapFbPk,MMizeNH0AKu(u"࠹࠳࠲ऽ"))
	return
def OYFsHXZI3azxSnKJMf4o71h():
	ZZqfPsz8uV = ee8c0jzrTntGSUdRJm.getSetting(OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠩࡤࡺ࠳ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠮ࡱࡣࡷ࡬ࠬࢭ"))
	if ZZqfPsz8uV: return ZZqfPsz8uV
	ee8c0jzrTntGSUdRJm.setSetting(ITvnUAMXsyb4eO(u"ࠪࡥࡻ࠴ࡤࡰࡹࡱࡰࡴࡧࡤ࠯ࡲࡤࡸ࡭࠭ࢮ"),vA0ImpguajeHKJ6P)
	return vA0ImpguajeHKJ6P
def mCtvqr6j8a3ZNB1iwyl():
	ZZqfPsz8uV = OYFsHXZI3azxSnKJMf4o71h()
	ww1pxvJgHhERcFun2NLjQoPaiyzs = XVmKrby29eCGMnlEY6jz0HNOR(KBkxSYaz93pu1(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫࢯ"),hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,sULh4NjakzI8He7xJCMGrql(u"๋ࠬใศ่ࠣฮำุ๊็่่ࠢๆอสࠡษ็ฮา๋๊ๅࠩࢰ"),soMVfbr6WtpNlcSA+ZZqfPsz8uV+YYSh2J6BIrsm8+EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"࠭࡜࡯࡞ࡱ๋ีอ่๊้่ࠠࠣอๆࠡฬัึ๏์ࠠๆๆไหฯࠦวๅใํำ๏๎ࠠศๆอ๎ࠥะอๆๆ๊หࠥอๆหࠢหหุะฮะษ่ࠤ์ึวࠡษ็ฬึ์วๆฮࠣ࠲ࠥํไࠡฬิ๎ิࠦส฻์ํีࠥอไๆๅส๊ࠥลࠧࢱ"))
	if ww1pxvJgHhERcFun2NLjQoPaiyzs==MMizeNH0AKu(u"࠱ा"):
		MtR5IY3voLg = RD8CiwWAtQ(NeO3CTLHrPfWUoIgy8Q(u"࠴ि"),HHoGx7Flus60(u"ࠧๆๅส๊ࠥะอๆ์็ࠤ๊๊แศฬࠣห้็๊ะ์๋ࠫࢲ"),LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠨ࡮ࡲࡧࡦࡲࠧࢳ"),hWGMqtBy4wuLaVcj,fEXMiAyG3ql4vKB,VBlawK4mgHSyLEn8iqhUkz5,ZZqfPsz8uV)
		dHPVDWfG4jX5e6QEo0CKh = XVmKrby29eCGMnlEY6jz0HNOR(OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠩࡦࡩࡳࡺࡥࡳࠩࢴ"),hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"้่ࠪอๆࠡฬัึ๏์ࠠๆๆไหฯࠦวๅฬะ้๏๊ࠧࢵ"),soMVfbr6WtpNlcSA+ZZqfPsz8uV+YYSh2J6BIrsm8+S1SgCFYGJeMvfp5iZXK(u"ࠫࡡࡴ࡜࡯้ำหࠥํ่ࠡษ็้่อๆࠡษ็ะิ๐ฯࠡๆอาื๐ๆࠡ็็ๅฬะࠠศๆไ๎ิ๐่ࠡษ็ฮ๏ࠦสฮ็็๋ฬࠦว็ฬࠣฬฬูสฯัส้ࠥํะศࠢส่อืๆศ็ฯࠤ࠳ࠦ็ๅࠢอี๏ีࠠศีอาิอๅ่ࠢหำ้อࠠๆ่ࠣห้๋ใศ่ࠣห้่ฯ๋็ࠣรࠬࢶ"))
		if dHPVDWfG4jX5e6QEo0CKh==KBkxSYaz93pu1(u"࠳ी"):
			ee8c0jzrTntGSUdRJm.setSetting(HHoGx7Flus60(u"ࠬࡧࡶ࠯ࡦࡲࡻࡳࡲ࡯ࡢࡦ࠱ࡴࡦࡺࡨࠨࢷ"),MtR5IY3voLg)
			BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,KBkxSYaz93pu1(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩࢸ"),GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠧห็ࠣฮ฿๐๊า่ࠢ็ฬ์ࠠหะี๎๋ࠦวๅ็็ๅฬะࠠศๆ่ั๊๊ษࠨࢹ"))
	return
def H9iFRYq1pl07(O9z5L3KtXqPEMepJQ0,LDceGoKZizXNV9m7bn6SU3W=hWGMqtBy4wuLaVcj,website=hWGMqtBy4wuLaVcj):
	KteLZCbM8W0FqE2OBx1(pGYKHZgqFX3B,qhVEWvetzXLOcr1(xjPuFK3EsIZSiobQ5X)+NeO3CTLHrPfWUoIgy8Q(u"ࠨࠢࠣࠤࡕࡸࡥࡱࡣࡵ࡭ࡳ࡭ࠠࡵࡱࠣࡨࡴࡽ࡮࡭ࡱࡤࡨࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨࢺ")+O9z5L3KtXqPEMepJQ0+rwQN9AKhLCuMfHxjlbX0U(u"ࠩࠣࡡࠬࢻ"))
	if not LDceGoKZizXNV9m7bn6SU3W: LDceGoKZizXNV9m7bn6SU3W = UGBbEtrcu5jLC6Sxoa3gFyP1mJOpW(O9z5L3KtXqPEMepJQ0)
	ZZqfPsz8uV = OYFsHXZI3azxSnKJMf4o71h()
	SaLcnMBU8Kp7qxYgzbeJROu = XFr42BCdkuqpsmZw6NvG39gz7HSK0h(fEXMiAyG3ql4vKB)
	pRXW8ZM9Qhfd7aTsPGB3vOjcu = SaLcnMBU8Kp7qxYgzbeJROu.replace(Mpsm2VF1OBnCRvK3qf6,KNIvHPjUbhr(u"ࠪࡣࠬࢼ"))
	pRXW8ZM9Qhfd7aTsPGB3vOjcu = vJRN3snSxMqBP1dpIGTQX8Yl(pRXW8ZM9Qhfd7aTsPGB3vOjcu)
	pRXW8ZM9Qhfd7aTsPGB3vOjcu = DJ1ICpbyR2(u"ࠫ࡫࡯࡬ࡦࡡࠪࢽ")+str(int(IHKJoQ8PwW4pNBR6GTAMVz2hdfC5my))[-dv0trJR7PwmKyxDYO52VLau8gEph(u"࠷ु"):]+jeAby54c02TgG8zuivonX91(u"ࠬࡥࠧࢾ")+pRXW8ZM9Qhfd7aTsPGB3vOjcu+LDceGoKZizXNV9m7bn6SU3W
	YwcG32khZ6gORTLJ5FnbdMEIm8oq71 = WQvYkNg7SysPFLitlGEn6.path.join(ZZqfPsz8uV,pRXW8ZM9Qhfd7aTsPGB3vOjcu)
	eE4wIviRq52y316 = {}
	eE4wIviRq52y316[JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"࠭ࡁࡤࡥࡨࡴࡹ࠳ࡅ࡯ࡥࡲࡨ࡮ࡴࡧࠨࢿ")] = hWGMqtBy4wuLaVcj
	eE4wIviRq52y316[LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠧࡂࡥࡦࡩࡵࡺࠧࣀ")] = QvgnCALNstmuUJiET(u"ࠨࠬ࠲࠮ࠬࣁ")
	O9z5L3KtXqPEMepJQ0 = O9z5L3KtXqPEMepJQ0.replace(A6dMB1FlgxVivJ2fk9C(u"ࠩࡹࡩࡷ࡯ࡦࡺࡲࡨࡩࡷࡃࡦࡢ࡮ࡶࡩࠬࣂ"),hWGMqtBy4wuLaVcj)
	if EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺ࠽ࠨࣃ") in O9z5L3KtXqPEMepJQ0:
		NPM3HKQ57xe,o0ST4d1BWzi7r3OnK9ucCXxw = O9z5L3KtXqPEMepJQ0.rsplit(rwQN9AKhLCuMfHxjlbX0U(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴ࠾ࠩࣄ"),KBkxSYaz93pu1(u"࠵ू"))
		o0ST4d1BWzi7r3OnK9ucCXxw = o0ST4d1BWzi7r3OnK9ucCXxw.replace(GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠬࢂࠧࣅ"),hWGMqtBy4wuLaVcj).replace(sULh4NjakzI8He7xJCMGrql(u"࠭ࠦࠨࣆ"),hWGMqtBy4wuLaVcj)
	else: NPM3HKQ57xe,o0ST4d1BWzi7r3OnK9ucCXxw = O9z5L3KtXqPEMepJQ0,None
	if not o0ST4d1BWzi7r3OnK9ucCXxw: o0ST4d1BWzi7r3OnK9ucCXxw = OB6QYAMUnPiWXgpkTrItV48FqZSjdR()
	if o0ST4d1BWzi7r3OnK9ucCXxw: eE4wIviRq52y316[SqrG5mU3j96ldsFpExobw40TJY(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫࣇ")] = o0ST4d1BWzi7r3OnK9ucCXxw
	if NeO3CTLHrPfWUoIgy8Q(u"ࠨࡔࡨࡪࡪࡸࡥࡳ࠿ࠪࣈ") in NPM3HKQ57xe: NPM3HKQ57xe,JPl40rDFqybV9H2Wxi1 = NPM3HKQ57xe.rsplit(dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࡀࠫࣉ"),GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"࠶ृ"))
	else: NPM3HKQ57xe,JPl40rDFqybV9H2Wxi1 = NPM3HKQ57xe,hWGMqtBy4wuLaVcj
	NPM3HKQ57xe = NPM3HKQ57xe.strip(JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠪࢀࠬ࣊")).strip(SqrG5mU3j96ldsFpExobw40TJY(u"ࠫࠫ࠭࣋")).strip(OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠬࢂࠧ࣌")).strip(SqrG5mU3j96ldsFpExobw40TJY(u"࠭ࠦࠨ࣍"))
	JPl40rDFqybV9H2Wxi1 = JPl40rDFqybV9H2Wxi1.replace(SqrG5mU3j96ldsFpExobw40TJY(u"ࠧࡽࠩ࣎"),hWGMqtBy4wuLaVcj).replace(rwQN9AKhLCuMfHxjlbX0U(u"ࠨࠨ࣏ࠪ"),hWGMqtBy4wuLaVcj)
	if JPl40rDFqybV9H2Wxi1:	eE4wIviRq52y316[o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴ࣐ࠪ")] = JPl40rDFqybV9H2Wxi1
	KteLZCbM8W0FqE2OBx1(pGYKHZgqFX3B,qhVEWvetzXLOcr1(xjPuFK3EsIZSiobQ5X)+NeO3CTLHrPfWUoIgy8Q(u"ࠪࠤࠥࠦࡄࡰࡹࡱࡰࡴࡧࡤࡪࡰࡪࠤࡻ࡯ࡤࡦࡱࠣࡪ࡮ࡲࡥ࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝࣑ࠣࠫ")+NPM3HKQ57xe+NeO3CTLHrPfWUoIgy8Q(u"ࠫࠥࡣࠠࠡࠢࡋࡩࡦࡪࡥࡳࡵ࠽ࠤࡠ࣒ࠦࠧ")+str(eE4wIviRq52y316)+CnbBKmtF1x84q7AW(u"ࠬࠦ࡝ࠡࠢࠣࡊ࡮ࡲࡥ࠻ࠢ࡞ࠤ࣓ࠬ")+YwcG32khZ6gORTLJ5FnbdMEIm8oq71+wwPrSDa21lUh(u"࠭ࠠ࡞ࠩࣔ"))
	BbOC8YeQNkdPlDGKI07xiHtXryJWT = e2qDYgipPmTw4KvBLnochr(u"࠷࠰࠳࠶ॄ")*e2qDYgipPmTw4KvBLnochr(u"࠷࠰࠳࠶ॄ")
	PuYElSdyDkX = sULh4NjakzI8He7xJCMGrql(u"࠰ॅ")
	try:
		VfAs8B9geckQ5rdW27FbZCin6q1SHl =	MMk8qKvcJe4fQHm3EG7diBD5.getInfoLabel(ITvnUAMXsyb4eO(u"ࠧࡔࡻࡶࡸࡪࡳ࠮ࡇࡴࡨࡩࡘࡶࡡࡤࡧࠪࣕ"))
		VfAs8B9geckQ5rdW27FbZCin6q1SHl = trdVA0JvFaD.findall(ITvnUAMXsyb4eO(u"ࠨ࡞ࡧ࠯ࠬࣖ"),VfAs8B9geckQ5rdW27FbZCin6q1SHl)
		PuYElSdyDkX = int(VfAs8B9geckQ5rdW27FbZCin6q1SHl[ybdv7XcT3lxF6QezULwCAGk])
	except: pass
	if not PuYElSdyDkX:
		try:
			al1XpIOdKb7frVxjYDPHwWFM = WQvYkNg7SysPFLitlGEn6.statvfs(ZZqfPsz8uV)
			PuYElSdyDkX = al1XpIOdKb7frVxjYDPHwWFM.f_frsize*al1XpIOdKb7frVxjYDPHwWFM.f_bavail//BbOC8YeQNkdPlDGKI07xiHtXryJWT
		except: pass
	if not PuYElSdyDkX:
		try:
			al1XpIOdKb7frVxjYDPHwWFM = WQvYkNg7SysPFLitlGEn6.fstatvfs(ZZqfPsz8uV)
			PuYElSdyDkX = al1XpIOdKb7frVxjYDPHwWFM.f_frsize*al1XpIOdKb7frVxjYDPHwWFM.f_bavail//BbOC8YeQNkdPlDGKI07xiHtXryJWT
		except: pass
	if not PuYElSdyDkX:
		try:
			import shutil as La1TPjt4edWDXHNYBcJb0fRI
			J8dPQ3fzmXBO1aWACZTo4tnvlrR7F,pXgWbmnMuo,dO27EHAt0GciFQqbTN54zWk = La1TPjt4edWDXHNYBcJb0fRI.disk_usage(ZZqfPsz8uV)
			PuYElSdyDkX = dO27EHAt0GciFQqbTN54zWk//BbOC8YeQNkdPlDGKI07xiHtXryJWT
		except: pass
	if not PuYElSdyDkX:
		yBv4YaSomFrkejwgNA7pDnKudCz(KNIvHPjUbhr(u"ࠩࡵ࡭࡬࡮ࡴࠨࣗ"),FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ุ้ࠪออสࠢส่ฯิา๋่้ࠣัํ่ๅหࠪࣘ"),e2qDYgipPmTw4KvBLnochr(u"้๊ࠫริใࠣห้ฮั็ษ่ะࠥเ๊าࠢๅหิืࠠฤ่ࠣ๎าีฯࠡ็ๅำฬืࠠๆีสัฮࠦวๅฬัึ๏์ࠠศๆไหึเษࠡใํࠤัํวำๅࠣ์฾๊๊่ࠢไห๋ࠦสฮ็ํ่ࠥอไโ์า๎ํํวหࠢ็๊ࠥ๐ูๆๆࠣ฽๋ีใࠡว็ํࠥษๆࠡ์ๅ์๊ࠦๅษำ่ะ๏ࠦศา่ส้ัࠦใ้ัํࠤอำไ้ࠡำ๋ࠥอไๆึๆ่ฮࠦไศ่ࠣฮา๋๊ๅࠢส่ๆ๐ฯ๋๊๊หฯࠦโะࠢํือฮࠠศ็อ่ฬวࠠอ้สึ่ࠦศศๆ่่ๆอส๊๊ࠡิฬࠦแ๋้ࠣา฼๎ัสࠢ฼่๎ูࠦๆๆࠣะ์อาไࠢหูํืษࠡืะ๎าฯ้ࠠๆ๊ิฬࠦวๅีหฬ่ࠥวๆࠢส่๊ฮัๆฮ้ࠣษ่สศࠢห้๋฿ࠠศๆหี๋อๅอ่๊ࠢࠥะอๆ์็ࠤฬ๊แ๋ัํ์์อสࠨࣙ"),wwPrSDa21lUh(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨࣚ"))
		KteLZCbM8W0FqE2OBx1(VRQE4jsXHSfhPWo5DgLwxGk,qhVEWvetzXLOcr1(xjPuFK3EsIZSiobQ5X)+FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"࠭ࠠࠡࠢࡘࡲࡦࡨ࡬ࡦࠢࡷࡳࠥࡪࡥࡵࡧࡵࡱ࡮ࡴࡥࠡࡶ࡫ࡩࠥࡪࡩࡴ࡭ࠣࡪࡷ࡫ࡥࠡࡵࡳࡥࡨ࡫ࠧࣛ"))
		return fEXMiAyG3ql4vKB
	if LDceGoKZizXNV9m7bn6SU3W==ITvnUAMXsyb4eO(u"ࠧ࠯࡯࠶ࡹ࠽࠭ࣜ"):
		haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = b8IJFKNyPjgE4GelaCSXB6Qht(NPM3HKQ57xe,eE4wIviRq52y316)
		if len(haq1bHZINPE58uoBFnKfTSO2ik4)==QVDJLRlxNg127jMX(u"࠱ॆ"):
			OnsAxhdVjZF(EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠨใื่ࠥ็๊ࠡวํะฬีࠠๆๆไࠤฬ๊สฮ็ํ่ࠬࣝ"),hWGMqtBy4wuLaVcj)
			return fEXMiAyG3ql4vKB
		elif len(haq1bHZINPE58uoBFnKfTSO2ik4)==FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"࠳े"): OODLkJlZCoKmrzbg2XQSGPUdInA = ITvnUAMXsyb4eO(u"࠳ै")
		elif len(haq1bHZINPE58uoBFnKfTSO2ik4)>KBkxSYaz93pu1(u"࠵ॉ"):
			OODLkJlZCoKmrzbg2XQSGPUdInA = Eb7qJoNwOgn(NeO3CTLHrPfWUoIgy8Q(u"ࠩสาฯืࠠศๆ่่ๆࠦวๅ็้หุฮࠧࣞ"), haq1bHZINPE58uoBFnKfTSO2ik4)
			if OODLkJlZCoKmrzbg2XQSGPUdInA == -DJ1ICpbyR2(u"࠶ॊ") :
				OnsAxhdVjZF(A6dMB1FlgxVivJ2fk9C(u"ࠪฮ๊ࠦลๅ฼สลࠥอไหฯ่๎้࠭ࣟ"),hWGMqtBy4wuLaVcj)
				return fEXMiAyG3ql4vKB
		NPM3HKQ57xe = Dvi8asSrQYX5wE3KMIxT91me[OODLkJlZCoKmrzbg2XQSGPUdInA]
	JjRoXVNC5BEcpeik9mzUIAhK4HWS = KNIvHPjUbhr(u"࠶ो")
	import requests as Av8o1XdSJCsG9fHlbEwr7P
	if LDceGoKZizXNV9m7bn6SU3W==KNIvHPjUbhr(u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪ࣠"):
		YwcG32khZ6gORTLJ5FnbdMEIm8oq71 = YwcG32khZ6gORTLJ5FnbdMEIm8oq71.rsplit(HHoGx7Flus60(u"ࠬ࠴࡭࠴ࡷ࠻ࠫ࣡"))[ybdv7XcT3lxF6QezULwCAGk]+QVDJLRlxNg127jMX(u"࠭࠮࡮ࡲ࠷ࠫ࣢")
		oTawtcGI687h = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(nHBb7jXk0Daom,rwQN9AKhLCuMfHxjlbX0U(u"ࠧࡈࡇࡗࣣࠫ"),NPM3HKQ57xe,hWGMqtBy4wuLaVcj,eE4wIviRq52y316,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,DJ1ICpbyR2(u"ࠨࡆࡒ࡛ࡓࡒࡏࡂࡆ࠰ࡈࡔ࡝ࡎࡍࡑࡄࡈࡤ࡜ࡉࡅࡇࡒ࠱࠶ࡹࡴࠨࣤ"))
		GPlhudxU5wg = oTawtcGI687h.content
		m4IznKilUOByHweG68VJ = trdVA0JvFaD.findall(rwQN9AKhLCuMfHxjlbX0U(u"ࠩࠦࡉ࡝࡚ࡉࡏࡈ࠽࠲࠯ࡅ࡛࡝ࡰ࡟ࡶࡢ࠮࠮ࠫࡁࠬ࡟ࡡࡴ࡜ࡳ࡟ࠪࣥ"),GPlhudxU5wg+LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠪࡠࡳࡢࡲࠨࣦ"),trdVA0JvFaD.DOTALL)
		if not m4IznKilUOByHweG68VJ:
			KteLZCbM8W0FqE2OBx1(VRQE4jsXHSfhPWo5DgLwxGk,qhVEWvetzXLOcr1(xjPuFK3EsIZSiobQ5X)+wwPrSDa21lUh(u"ࠫࠥࠦࠠࡕࡪࡨࠤࡲ࠹ࡵ࠹ࠢࡩ࡭ࡱ࡫ࠠࡥ࡫ࡧࠤࡳࡵࡴࠡࡪࡤࡺࡪࠦࡴࡩࡧࠣࡶࡪࡷࡵࡪࡴࡨࡨࠥࡲࡩ࡯࡭ࡶࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧࣧ")+NPM3HKQ57xe+wwPrSDa21lUh(u"ࠬࠦ࡝ࠨࣨ"))
			return fEXMiAyG3ql4vKB
		llxFwq0CUNgQtivJzkHeGV = m4IznKilUOByHweG68VJ[ybdv7XcT3lxF6QezULwCAGk]
		if not llxFwq0CUNgQtivJzkHeGV.startswith(sULh4NjakzI8He7xJCMGrql(u"࠭ࡨࡵࡶࡳࣩࠫ")):
			if llxFwq0CUNgQtivJzkHeGV.startswith(KBkxSYaz93pu1(u"ࠧ࠰࠱ࠪ࣪")): llxFwq0CUNgQtivJzkHeGV = NPM3HKQ57xe.split(ITvnUAMXsyb4eO(u"ࠨ࠼ࠪ࣫"),HHoGx7Flus60(u"࠱ौ"))[ybdv7XcT3lxF6QezULwCAGk]+xcChIL13BpR8WArNt9Pl0So(u"ࠩ࠽ࠫ࣬")+llxFwq0CUNgQtivJzkHeGV
			elif llxFwq0CUNgQtivJzkHeGV.startswith(OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠪ࠳࣭ࠬ")): llxFwq0CUNgQtivJzkHeGV = RRNODILCtGzvgpx(NPM3HKQ57xe,xcChIL13BpR8WArNt9Pl0So(u"ࠫࡺࡸ࡬ࠨ࣮"))+llxFwq0CUNgQtivJzkHeGV
			else: llxFwq0CUNgQtivJzkHeGV = NPM3HKQ57xe.rsplit(XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠬ࠵࣯ࠧ"),DJ1ICpbyR2(u"࠲्"))[ybdv7XcT3lxF6QezULwCAGk]+ITvnUAMXsyb4eO(u"࠭࠯ࠨࣰ")+llxFwq0CUNgQtivJzkHeGV
		oTawtcGI687h = Av8o1XdSJCsG9fHlbEwr7P.request(HHoGx7Flus60(u"ࠧࡈࡇࡗࣱࠫ"),llxFwq0CUNgQtivJzkHeGV,headers=eE4wIviRq52y316,verify=fEXMiAyG3ql4vKB)
		zzJkjBy2qtUeYxv8uL4moZaAQcM = oTawtcGI687h.content
		HD3AtkQsR05cYmIMUrK9d = len(zzJkjBy2qtUeYxv8uL4moZaAQcM)
		YBKMvnlNx08XPVrGq = len(m4IznKilUOByHweG68VJ)
		JjRoXVNC5BEcpeik9mzUIAhK4HWS = HD3AtkQsR05cYmIMUrK9d*YBKMvnlNx08XPVrGq
	else:
		HD3AtkQsR05cYmIMUrK9d = e2qDYgipPmTw4KvBLnochr(u"࠳ॎ")*BbOC8YeQNkdPlDGKI07xiHtXryJWT
		oTawtcGI687h = Av8o1XdSJCsG9fHlbEwr7P.request(wwPrSDa21lUh(u"ࠨࡉࡈࡘࣲࠬ"),NPM3HKQ57xe,headers=eE4wIviRq52y316,verify=fEXMiAyG3ql4vKB,stream=VBlawK4mgHSyLEn8iqhUkz5)
		if KNIvHPjUbhr(u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡐࡪࡴࡧࡵࡪࠪࣳ") in oTawtcGI687h.headers: JjRoXVNC5BEcpeik9mzUIAhK4HWS = int(oTawtcGI687h.headers[rwQN9AKhLCuMfHxjlbX0U(u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱ࡑ࡫࡮ࡨࡶ࡫ࠫࣴ")])
		YBKMvnlNx08XPVrGq = int(JjRoXVNC5BEcpeik9mzUIAhK4HWS//HD3AtkQsR05cYmIMUrK9d)
	v4FRsANbo5Mp = int(JjRoXVNC5BEcpeik9mzUIAhK4HWS//BbOC8YeQNkdPlDGKI07xiHtXryJWT)+o1u5dij9UrcbXzVS8lwIWfKpnqM(u"࠴ॏ")
	if JjRoXVNC5BEcpeik9mzUIAhK4HWS<NeO3CTLHrPfWUoIgy8Q(u"࠶࠶࠶࠰࠱ॐ"):
		KteLZCbM8W0FqE2OBx1(VRQE4jsXHSfhPWo5DgLwxGk,qhVEWvetzXLOcr1(xjPuFK3EsIZSiobQ5X)+MMizeNH0AKu(u"ࠫࠥࠦࠠࡗ࡫ࡧࡩࡴࠦࡦࡪ࡮ࡨࠤ࡮ࡹࠠࡵࡱࡲࠤࡸࡳࡡ࡭࡮ࠣࡳࡷࠦࡩࡵࠢ࡬ࡷࠥࡳ࠳ࡶ࠺ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭ࣵ")+NPM3HKQ57xe+JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠬࠦ࡝࡚ࠡࠢࠣ࡮ࡪࡥࡰࠢࡩ࡭ࡱ࡫ࠠࡴ࡫ࡽࡩ࠿࡛ࣶࠦࠡࠩ")+str(v4FRsANbo5Mp)+LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"࠭ࠠࡎࡄࠣࡡࠥࠦࠠࡂࡸࡤ࡭ࡱࡧࡢ࡭ࡧࠣࡷ࡮ࢀࡥ࠻ࠢ࡞ࠤࠬࣷ")+str(PuYElSdyDkX)+QvgnCALNstmuUJiET(u"ࠧࠡࡏࡅࠤࡢࠦࠠࠡࡈ࡬ࡰࡪࡀࠠ࡜ࠢࠪࣸ")+YwcG32khZ6gORTLJ5FnbdMEIm8oq71+SqrG5mU3j96ldsFpExobw40TJY(u"ࠨࠢࡠࣹࠫ"))
		BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࣺࠬ"),JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠪๅู๊ࠠโ์้ࠣ฾ืแสࠢะะ๊ࠦๅๅใࠣห้็๊ะ์๋ࠤศ๎ࠠศๆ่่ๆࠦี฻์ิࠤัีว๊ࠡ็๋ีอࠠๅษࠣ๎๊้ๆࠡๆ็ฬึ์วๆฮࠣฮา๋๊ๅ๊ࠢิฬࠦวๅ็็ๅࠬࣻ"))
		return fEXMiAyG3ql4vKB
	P38PFo4Blm1KEw = CnbBKmtF1x84q7AW(u"࠹࠶࠰॑")
	MBlQhYDjU87SyV = PuYElSdyDkX-v4FRsANbo5Mp
	if MBlQhYDjU87SyV<P38PFo4Blm1KEw:
		KteLZCbM8W0FqE2OBx1(VRQE4jsXHSfhPWo5DgLwxGk,qhVEWvetzXLOcr1(xjPuFK3EsIZSiobQ5X)+QvgnCALNstmuUJiET(u"ࠫࠥࠦࠠࡏࡱࡷࠤࡪࡴ࡯ࡶࡩ࡫ࠤࡩ࡯ࡳ࡬ࠢࡶࡴࡦࡩࡥࠡࡶࡲࠤࡩࡵࡷ࡯࡮ࡲࡥࡩࠦࡴࡩࡧࠣࡺ࡮ࡪࡥࡰࠢࡩ࡭ࡱ࡫ࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪࣼ")+NPM3HKQ57xe+NeO3CTLHrPfWUoIgy8Q(u"ࠬࠦ࡝࡚ࠡࠢࠣ࡮ࡪࡥࡰࠢࡩ࡭ࡱ࡫ࠠࡴ࡫ࡽࡩ࠿࡛ࠦࠡࠩࣽ")+str(v4FRsANbo5Mp)+EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"࠭ࠠࡎࡄࠣࡡࠥࠦࠠࡂࡸࡤ࡭ࡱࡧࡢ࡭ࡧࠣࡷ࡮ࢀࡥ࠻ࠢ࡞ࠤࠬࣾ")+str(PuYElSdyDkX)+HHoGx7Flus60(u"ࠧࠡࡏࡅࠤ࠲ࠦࠧࣿ")+str(P38PFo4Blm1KEw)+MMizeNH0AKu(u"ࠨࠢࡐࡆࠥࡣࠠࠡࠢࡉ࡭ࡱ࡫࠺ࠡ࡝ࠣࠫऀ")+YwcG32khZ6gORTLJ5FnbdMEIm8oq71+EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠩࠣࡡࠬँ"))
		BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,S1SgCFYGJeMvfp5iZXK(u"่ࠪฬ๊้ࠦฮาࠤู๊วฮหࠣ็ฬ็๊สࠢ็่ฯำๅ๋ๆࠪं"),GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠫฬ๊ๅๅใࠣห้๋ืๅ๊หࠤฯำๅ๋ๆ๊ࠤาาๅ่ࠢࠪः")+str(v4FRsANbo5Mp)+rwQN9AKhLCuMfHxjlbX0U(u"ࠬࠦๅ๋฼สฬฬ๐ส๊ࠡฯ๋ฬุใࠡใํ๋๋ࠥำศฯฬࠤๆอั฻หࠣࠫऄ")+str(PuYElSdyDkX)+gDuGMR3z1aV6YdLmCpiO8Kl(u"࠭ࠠๆ์฽หออ๊ห๋่้๋ࠢอศใ฻อࠥ฿ไ๊ࠢ฼้้ࠦฬ่ษี็ࠥฮฯู้่้ࠣอใๅࠢํะอࠦลษไสลࠥ࠭अ")+str(P38PFo4Blm1KEw)+QVDJLRlxNg127jMX(u"ࠧࠡ็ํ฾ฬฮว๋ฬࠣๅฬืฺสࠢาหห๋ว๊๊ࠡิฬࠦๅฺ่ส๋ࠥษๆࠡฮ๊หื้ࠠๅษࠣฮําฯࠡใํ๋๋ࠥำศฯฬࠤ่อแ๋ห่ࠣฯำๅ๋ๆ้้ࠣ็ࠠศๆไ๎ิ๐่ࠡษ็้฼๊่ษࠩआ"))
		return fEXMiAyG3ql4vKB
	dHPVDWfG4jX5e6QEo0CKh = XVmKrby29eCGMnlEY6jz0HNOR(ITvnUAMXsyb4eO(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨइ"),hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,KNIvHPjUbhr(u"๊่ࠩࠥะั๋ัࠣฮา๋๊ๅࠢส่๊๊แࠡมࠪई"),KBkxSYaz93pu1(u"ࠪห้๋ไโࠢส่๊฽ไ้สࠣัั๋็ࠡฬๅี๏ฮวࠡࠩउ")+str(v4FRsANbo5Mp)+hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"๋๊ࠫࠥ฻ษหห๏ะ้ࠠฮ๊หื้ࠠโ์๊ࠤู๊วฮหࠣๅฬืฺสࠢอๆึ๐ศศࠢࠪऊ")+str(PuYElSdyDkX)+gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠬࠦๅ๋฼สฬฬ๐ส๊๊ࠡิฬࠦวๅ็็ๅ่ࠥฯࠡ์ะฮฬาࠠษ฻ูࠤฬ๊่ใฬ่้ࠣะอๆ์็ࠤ๊์ࠠศๆศ๊ฯืๆหࠢศ่๎ࠦฬ่ษี็ࠥ࠴่ࠠๆࠣห๋ะࠠๆฬฦ็ิ่ࠦหำํำࠥอไศีอ้ึอัࠡสอั๊๐ไࠡ็็ๅࠥอไโ์า๎ํࠦฟࠨऋ"))
	if dHPVDWfG4jX5e6QEo0CKh!=KBkxSYaz93pu1(u"࠷॒"):
		BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"࠭สๆࠢศ่฿อมࠡ฻่่๏ฯࠠหฯ่๎้ࠦๅๅใࠣห้็๊ะ์๋ࠫऌ"))
		KteLZCbM8W0FqE2OBx1(pGYKHZgqFX3B,qhVEWvetzXLOcr1(xjPuFK3EsIZSiobQ5X)+o1u5dij9UrcbXzVS8lwIWfKpnqM(u"࡙ࠧࠡࠢࠣࡸ࡫ࡲࠡࡥࡤࡲࡨ࡫࡬ࡦࡦࠣࡸ࡭࡫ࠠࡥࡱࡺࡲࡱࡵࡡࡥࠢࡲࡪࠥࡺࡨࡦࠢࡹ࡭ࡩ࡫࡯ࠡࡨ࡬ࡰࡪࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩऍ")+NPM3HKQ57xe+A6dMB1FlgxVivJ2fk9C(u"ࠨࠢࡠࠤࠥࠦࡆࡪ࡮ࡨ࠾ࠥࡡࠠࠨऎ")+YwcG32khZ6gORTLJ5FnbdMEIm8oq71+zyvJMtBhrw(u"ࠩࠣࡡࠬए"))
		return fEXMiAyG3ql4vKB
	KteLZCbM8W0FqE2OBx1(pGYKHZgqFX3B,qhVEWvetzXLOcr1(xjPuFK3EsIZSiobQ5X)+KBkxSYaz93pu1(u"ࠪࠤࠥࠦࡄࡰࡹࡱࡰࡴࡧࡤࠡࡵࡷࡥࡷࡺࡥࡥࠢࡶࡹࡨࡩࡥࡴࡵࡩࡹࡱࡲࡹࠨऐ"))
	xX7c9PeCsht = Tbof9Jl4eHnYZMvVEBFgCh1G3mLtd()
	xX7c9PeCsht.create(YwcG32khZ6gORTLJ5FnbdMEIm8oq71,XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠫฬ๊ำุำࠣๅํ่่๊้่ࠠࠣอๆࠡฬัึ๏์ࠠๆๆไࠤฬ๊แ๋ัํ์ࠬऑ"))
	Emfo0hbk4ctTCFYru7qM3Aw6 = VBlawK4mgHSyLEn8iqhUkz5
	pp9oFfEkKX74znPZ = HB5PvxRhwM.time()
	if not MmcgqAlsFt.sTZjaIcENd:
		BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,MMizeNH0AKu(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨऒ"),LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"࠭ศิสหࠤ฾ีๅࠡษ็ฮอืูࠡฬ่ࠤสฺ๊ศรࠣฮา๋๊ๅ่่ࠢๆࠦวๅใํำ๏๎ࠧओ"))
		return fEXMiAyG3ql4vKB
	if H4qZ2hwilNJYTmCFEQyaSs98cPM0gR: DusgyjapviZ = open(YwcG32khZ6gORTLJ5FnbdMEIm8oq71,hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠧࡸࡤࠪऔ"))
	else: DusgyjapviZ = open(YwcG32khZ6gORTLJ5FnbdMEIm8oq71.decode(a7VXeDU82IfQEnPZAdiT),FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠨࡹࡥࠫक"))
	if LDceGoKZizXNV9m7bn6SU3W==EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨख"):
		for JpzD0lv9cYM6XrHeqCa in range(KBkxSYaz93pu1(u"࠱॓"),YBKMvnlNx08XPVrGq+KBkxSYaz93pu1(u"࠱॓")):
			llxFwq0CUNgQtivJzkHeGV = m4IznKilUOByHweG68VJ[JpzD0lv9cYM6XrHeqCa-zyvJMtBhrw(u"࠲॔")]
			if not llxFwq0CUNgQtivJzkHeGV.startswith(DJ1ICpbyR2(u"ࠪ࡬ࡹࡺࡰࠨग")):
				if llxFwq0CUNgQtivJzkHeGV.startswith(QvgnCALNstmuUJiET(u"ࠫ࠴࠵ࠧघ")): llxFwq0CUNgQtivJzkHeGV = NPM3HKQ57xe.split(ITvnUAMXsyb4eO(u"ࠬࡀࠧङ"),QVDJLRlxNg127jMX(u"࠳ॕ"))[ybdv7XcT3lxF6QezULwCAGk]+KBkxSYaz93pu1(u"࠭࠺ࠨच")+llxFwq0CUNgQtivJzkHeGV
				elif llxFwq0CUNgQtivJzkHeGV.startswith(A6dMB1FlgxVivJ2fk9C(u"ࠧ࠰ࠩछ")): llxFwq0CUNgQtivJzkHeGV = RRNODILCtGzvgpx(NPM3HKQ57xe,EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠨࡷࡵࡰࠬज"))+llxFwq0CUNgQtivJzkHeGV
				else: llxFwq0CUNgQtivJzkHeGV = NPM3HKQ57xe.rsplit(JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠩ࠲ࠫझ"),QvgnCALNstmuUJiET(u"࠴ॖ"))[ybdv7XcT3lxF6QezULwCAGk]+jeAby54c02TgG8zuivonX91(u"ࠪ࠳ࠬञ")+llxFwq0CUNgQtivJzkHeGV
			oTawtcGI687h = Av8o1XdSJCsG9fHlbEwr7P.request(dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠫࡌࡋࡔࠨट"),llxFwq0CUNgQtivJzkHeGV,headers=eE4wIviRq52y316,verify=fEXMiAyG3ql4vKB)
			zzJkjBy2qtUeYxv8uL4moZaAQcM = oTawtcGI687h.content
			oTawtcGI687h.close()
			DusgyjapviZ.write(zzJkjBy2qtUeYxv8uL4moZaAQcM)
			K4Y9XdDMSbx0ew8cWI = HB5PvxRhwM.time()
			mwi9DG85jb3H = K4Y9XdDMSbx0ew8cWI-pp9oFfEkKX74znPZ
			DAUBasoRN6ztdpfc = mwi9DG85jb3H//JpzD0lv9cYM6XrHeqCa
			Xqc4WkQ6jZKle0tmyRVLd387Dzwox = DAUBasoRN6ztdpfc*(YBKMvnlNx08XPVrGq+wwPrSDa21lUh(u"࠵ॗ"))
			DZK0i4srNcl69 = Xqc4WkQ6jZKle0tmyRVLd387Dzwox-mwi9DG85jb3H
			CEIhS05OkFWGozARVZwnyrXf6(xX7c9PeCsht,int(QVDJLRlxNg127jMX(u"࠷࠰࠱ख़")*JpzD0lv9cYM6XrHeqCa//(YBKMvnlNx08XPVrGq+A6dMB1FlgxVivJ2fk9C(u"࠶क़"))),LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠬอไิูิࠤๆ๎โ้๋ࠡࠤ๊้ว็ࠢอาื๐ๆࠡ็็ๅࠥอไโ์า๎ํ࠭ठ"),NeO3CTLHrPfWUoIgy8Q(u"࠭ฬๅส้้ࠣ็ࠠศๆไ๎ิ๐่࠻࠯ࠣห้าายࠢิๆ๊࠭ड"),str(JpzD0lv9cYM6XrHeqCa*HD3AtkQsR05cYmIMUrK9d//BbOC8YeQNkdPlDGKI07xiHtXryJWT)+QvgnCALNstmuUJiET(u"ࠧ࠰ࠩढ")+str(v4FRsANbo5Mp)+FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠨࠢࡐࡆ๊ࠥࠦࠠࠡๅฮ๋ࠥสษไํ࠾ࠥ࠭ण")+HB5PvxRhwM.strftime(GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠤࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠦत"),HB5PvxRhwM.gmtime(DZK0i4srNcl69))+KBkxSYaz93pu1(u"ࠪࠤๅ࠭थ"))
			if xX7c9PeCsht.iscanceled():
				Emfo0hbk4ctTCFYru7qM3Aw6 = fEXMiAyG3ql4vKB
				break
	else:
		JpzD0lv9cYM6XrHeqCa = e2qDYgipPmTw4KvBLnochr(u"࠰ग़")
		for zzJkjBy2qtUeYxv8uL4moZaAQcM in oTawtcGI687h.iter_content(chunk_size=HD3AtkQsR05cYmIMUrK9d):
			DusgyjapviZ.write(zzJkjBy2qtUeYxv8uL4moZaAQcM)
			JpzD0lv9cYM6XrHeqCa = JpzD0lv9cYM6XrHeqCa+QVDJLRlxNg127jMX(u"࠲ज़")
			K4Y9XdDMSbx0ew8cWI = HB5PvxRhwM.time()
			mwi9DG85jb3H = K4Y9XdDMSbx0ew8cWI-pp9oFfEkKX74znPZ
			DAUBasoRN6ztdpfc = mwi9DG85jb3H/JpzD0lv9cYM6XrHeqCa
			Xqc4WkQ6jZKle0tmyRVLd387Dzwox = DAUBasoRN6ztdpfc*(YBKMvnlNx08XPVrGq+MMizeNH0AKu(u"࠳ड़"))
			DZK0i4srNcl69 = Xqc4WkQ6jZKle0tmyRVLd387Dzwox-mwi9DG85jb3H
			CEIhS05OkFWGozARVZwnyrXf6(xX7c9PeCsht,int(ITvnUAMXsyb4eO(u"࠵࠵࠶फ़")*JpzD0lv9cYM6XrHeqCa/(YBKMvnlNx08XPVrGq+rwQN9AKhLCuMfHxjlbX0U(u"࠴ढ़"))),FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠫฬ๊ำุำࠣๅํ่่๊้่ࠠࠣอๆࠡฬัึ๏์ࠠๆๆไࠤฬ๊แ๋ัํ์ࠬद"),QvgnCALNstmuUJiET(u"ࠬาไษ่่ࠢๆࠦวๅใํำ๏๎࠺࠮ࠢส่ัุมࠡำๅ้ࠬध"),str(JpzD0lv9cYM6XrHeqCa*HD3AtkQsR05cYmIMUrK9d//BbOC8YeQNkdPlDGKI07xiHtXryJWT)+KNIvHPjUbhr(u"࠭࠯ࠨन")+str(v4FRsANbo5Mp)+dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠧࠡࡏࡅࠤ้ࠥࠦࠠไอࠤ๊ะศใ์࠽ࠤࠬऩ")+HB5PvxRhwM.strftime(CnbBKmtF1x84q7AW(u"ࠣࠧࡋ࠾ࠪࡓ࠺ࠦࡕࠥप"),HB5PvxRhwM.gmtime(DZK0i4srNcl69))+QVDJLRlxNg127jMX(u"ࠩࠣไࠬफ"))
			if xX7c9PeCsht.iscanceled():
				Emfo0hbk4ctTCFYru7qM3Aw6 = fEXMiAyG3ql4vKB
				break
		oTawtcGI687h.close()
	DusgyjapviZ.close()
	xX7c9PeCsht.close()
	if not Emfo0hbk4ctTCFYru7qM3Aw6:
		KteLZCbM8W0FqE2OBx1(pGYKHZgqFX3B,qhVEWvetzXLOcr1(xjPuFK3EsIZSiobQ5X)+LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠪࠤࠥࠦࡕࡴࡧࡵࠤࡨࡧ࡮ࡤࡧ࡯ࡩࡩ࠵ࡩ࡯ࡶࡨࡶࡷࡻࡰࡵࡧࡧࠤࡹ࡮ࡥࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࠣࡴࡷࡵࡣࡦࡵࡶࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧब")+NPM3HKQ57xe+e2qDYgipPmTw4KvBLnochr(u"ࠫࠥࡣࠠࠡࠢࡉ࡭ࡱ࡫࠺ࠡ࡝ࠣࠫभ")+YwcG32khZ6gORTLJ5FnbdMEIm8oq71+HHoGx7Flus60(u"ࠬࠦ࡝ࠨम"))
		BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,QVDJLRlxNg127jMX(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩय"),gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠧษฯึฬࠥ฽ไษๅࠣฮ๊ࠦลๅ฼สลࠥ฿ๅๅ์ฬࠤฯำๅ๋ๆ้้ࠣ็ࠠศๆไ๎ิ๐่ࠨर"))
		return VBlawK4mgHSyLEn8iqhUkz5
	KteLZCbM8W0FqE2OBx1(pGYKHZgqFX3B,qhVEWvetzXLOcr1(xjPuFK3EsIZSiobQ5X)+o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠨࠢࠣࠤ࡛࡯ࡤࡦࡱࠣࡪ࡮ࡲࡥࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࡨࡨࠥࡹࡵࡤࡥࡨࡷࡸ࡬ࡵ࡭࡮ࡼࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧऱ")+NPM3HKQ57xe+wwPrSDa21lUh(u"ࠩࠣࡡࠥࠦࠠࡇ࡫࡯ࡩ࠿࡛ࠦࠡࠩल")+YwcG32khZ6gORTLJ5FnbdMEIm8oq71+HHoGx7Flus60(u"ࠪࠤࡢ࠭ळ"))
	BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,S1SgCFYGJeMvfp5iZXK(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧऴ"),LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠬะๅࠡฬะ้๏๊ࠠๆๆไࠤฬ๊แ๋ัํ์ࠥฮๆอษะࠫव"))
	return VBlawK4mgHSyLEn8iqhUkz5
# -*- coding: utf-8 -*-
from yoY3NdGViS import *
xjPuFK3EsIZSiobQ5X = 'LIVETV'
Str0BupDTFA = u6rbxnyjTl7I['PYTHON'][0]
def ehB18u9sQFRi(mode,url):
	if   mode==100: N6NCYivtV4I5rEXq = DP6FSBgNdX1rsvVR()
	elif mode==101: N6NCYivtV4I5rEXq = qJQdtBXVnP9EFwlvOKMLecDb('0',True)
	elif mode==102: N6NCYivtV4I5rEXq = qJQdtBXVnP9EFwlvOKMLecDb('1',True)
	elif mode==103: N6NCYivtV4I5rEXq = qJQdtBXVnP9EFwlvOKMLecDb('2',True)
	elif mode==104: N6NCYivtV4I5rEXq = qJQdtBXVnP9EFwlvOKMLecDb('3',True)
	elif mode==105: N6NCYivtV4I5rEXq = oanus6TxUFNAhSZKpJdYlEC4mV(url)
	elif mode==106: N6NCYivtV4I5rEXq = qJQdtBXVnP9EFwlvOKMLecDb('4',True)
	else: N6NCYivtV4I5rEXq = False
	return N6NCYivtV4I5rEXq
def DP6FSBgNdX1rsvVR():
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','_M3U_'+'قوائم فيديوهات M3U',hWGMqtBy4wuLaVcj,762)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','_IPT_'+'قوائم فيديوهات IPTV',hWGMqtBy4wuLaVcj,761)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','_TV0_'+'قنوات من مواقعها الأصلية',hWGMqtBy4wuLaVcj,101)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','_TV4_'+'قنوات مختارة من يوتيوب',hWGMqtBy4wuLaVcj,106)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','_YUT_'+'قنوات عربية من يوتيوب',hWGMqtBy4wuLaVcj,147)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','_YUT_'+'قنوات أجنبية من يوتيوب',hWGMqtBy4wuLaVcj,148)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','_IFL_'+'  قناة آي فيلم من موقعهم  ',hWGMqtBy4wuLaVcj,28)
	RLDCGt8kq3OVmnzgx1rbi2f7F('live','_MRF_'+'قناة المعارف من موقعهم',hWGMqtBy4wuLaVcj,41)
	RLDCGt8kq3OVmnzgx1rbi2f7F('live','_PNT_'+'قناة هلا من موقع بانيت',hWGMqtBy4wuLaVcj,38)
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','_TV1_'+'قنوات تلفزيونية عامة',hWGMqtBy4wuLaVcj,102)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','_TV2_'+'قنوات تلفزيونية خاصة',hWGMqtBy4wuLaVcj,103)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','_TV3_'+'قنوات تلفزيونية للفحص',hWGMqtBy4wuLaVcj,104)
	return
def qJQdtBXVnP9EFwlvOKMLecDb(p7tSrCjXlc6M1i5WQTgq9zGJF,showDialogs=True):
	n0qFKQWhiBYXoTrvejVHUA4 = '_TV'+p7tSrCjXlc6M1i5WQTgq9zGJF+'_'
	l17Sn3hK59WV = {'id':hWGMqtBy4wuLaVcj,'user':IIvxtojw6EXl2f,'function':'list','menu':p7tSrCjXlc6M1i5WQTgq9zGJF}
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(nHBb7jXk0Daom,'POST',Str0BupDTFA,l17Sn3hK59WV,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'LIVETV-ITEMS-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	items = trdVA0JvFaD.findall('([^;\r\n]+?);;(.*?);;(.*?);;(.*?);;(.*?);;',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if items:
		for PPuqrvDLEViYOMf1dmkK7 in range(len(items)):
			name = items[PPuqrvDLEViYOMf1dmkK7][3]
			start = name[0:2]
			start = start.replace('al','Al')
			start = start.replace('El','Al')
			start = start.replace('AL','Al')
			start = start.replace('EL','Al')
			name = start+name[2:]
			start = name[0:3]
			start = start.replace('Al-','Al')
			start = start.replace('Al ','Al')
			name = start+name[3:]
			items[PPuqrvDLEViYOMf1dmkK7] = items[PPuqrvDLEViYOMf1dmkK7][0],items[PPuqrvDLEViYOMf1dmkK7][1],items[PPuqrvDLEViYOMf1dmkK7][2],name,items[PPuqrvDLEViYOMf1dmkK7][4]
		items = set(items)
		items = sorted(items, reverse=False, key=lambda key: key[0].lower())
		items = sorted(items, reverse=False, key=lambda key: key[3].lower())
		for dUWFtBQ3cpoIZ9,SODQ7qlNYoZcFK8e50rBsJaAHxiXjE,VzAiKmWdsgw9XfIuF1e0,name,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG in items:
			if '#' in dUWFtBQ3cpoIZ9: continue
			if dUWFtBQ3cpoIZ9!='URL': name = name+hXB0vKVQ5PRI91SDTprMdfuHEm4+lG0yV5QNFHc2RbXM1Wp+dUWFtBQ3cpoIZ9+YYSh2J6BIrsm8
			url = dUWFtBQ3cpoIZ9+';;'+SODQ7qlNYoZcFK8e50rBsJaAHxiXjE+';;'+VzAiKmWdsgw9XfIuF1e0+';;'+p7tSrCjXlc6M1i5WQTgq9zGJF
			RLDCGt8kq3OVmnzgx1rbi2f7F('live',n0qFKQWhiBYXoTrvejVHUA4+hWGMqtBy4wuLaVcj+name,url,105,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
	else:
		if showDialogs: RLDCGt8kq3OVmnzgx1rbi2f7F('link',n0qFKQWhiBYXoTrvejVHUA4+'هذه الخدمة مخصصة للمبرمج فقط',hWGMqtBy4wuLaVcj,9999)
	return
def oanus6TxUFNAhSZKpJdYlEC4mV(id):
	dUWFtBQ3cpoIZ9,SODQ7qlNYoZcFK8e50rBsJaAHxiXjE,VzAiKmWdsgw9XfIuF1e0,p7tSrCjXlc6M1i5WQTgq9zGJF = id.split(';;')
	url = hWGMqtBy4wuLaVcj
	if dUWFtBQ3cpoIZ9=='URL': url = VzAiKmWdsgw9XfIuF1e0
	elif dUWFtBQ3cpoIZ9=='YOUTUBE':
		url = u6rbxnyjTl7I['YOUTUBE'][0]+'/watch?v='+VzAiKmWdsgw9XfIuF1e0
		import oosSOfvdEQ
		oosSOfvdEQ.zfdYjsGLg8M6i15qZWh([url],xjPuFK3EsIZSiobQ5X,'live',url)
		return
	elif dUWFtBQ3cpoIZ9=='GA':
		l17Sn3hK59WV = { 'id' : hWGMqtBy4wuLaVcj, 'user' : IIvxtojw6EXl2f , 'function' : 'playGA1' , 'menu' : hWGMqtBy4wuLaVcj }
		sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(nHBb7jXk0Daom,'GET',Str0BupDTFA,l17Sn3hK59WV,hWGMqtBy4wuLaVcj,False,hWGMqtBy4wuLaVcj,'LIVETV-PLAY-1st')
		if not sDQvwGASB0Vf67mik.succeeded:
			BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
		cookies = sDQvwGASB0Vf67mik.cookies
		me3AzYj2wVSl91ThidoUOy = cookies['ASP.NET_SessionId']
		url = sDQvwGASB0Vf67mik.headers['Location']
		l17Sn3hK59WV = { 'id' : VzAiKmWdsgw9XfIuF1e0 , 'user' : IIvxtojw6EXl2f , 'function' : 'playGA2' , 'menu' : hWGMqtBy4wuLaVcj }
		headers = { 'Cookie' : 'ASP.NET_SessionId='+me3AzYj2wVSl91ThidoUOy }
		sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(nHBb7jXk0Daom,'GET',Str0BupDTFA,l17Sn3hK59WV,headers,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'LIVETV-PLAY-2nd')
		if not sDQvwGASB0Vf67mik.succeeded:
			BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
		url = trdVA0JvFaD.findall('resp":"(http.*?m3u8)(.*?)"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		llxFwq0CUNgQtivJzkHeGV = url[0][0]
		aNSb8AQWjni1vdus = url[0][1]
		GkWea10HrRYzntumpFAgTh2 = 'http://38.'+SODQ7qlNYoZcFK8e50rBsJaAHxiXjE+'777/'+VzAiKmWdsgw9XfIuF1e0+'_HD.m3u8'+aNSb8AQWjni1vdus
		DwCGhplgSnVvxmBW9NcT = GkWea10HrRYzntumpFAgTh2.replace('36:7','40:7').replace('_HD.m3u8','.m3u8')
		HqWhbm4eYIQM98wVjLo = GkWea10HrRYzntumpFAgTh2.replace('36:7','42:7').replace('_HD.m3u8','.m3u8')
		haq1bHZINPE58uoBFnKfTSO2ik4 = ['HD','SD1','SD2']
		Dvi8asSrQYX5wE3KMIxT91me = [GkWea10HrRYzntumpFAgTh2,DwCGhplgSnVvxmBW9NcT,HqWhbm4eYIQM98wVjLo]
		OODLkJlZCoKmrzbg2XQSGPUdInA = 0
		if OODLkJlZCoKmrzbg2XQSGPUdInA == -1: return
		else: url = Dvi8asSrQYX5wE3KMIxT91me[OODLkJlZCoKmrzbg2XQSGPUdInA]
	elif dUWFtBQ3cpoIZ9=='NT':
		headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
		l17Sn3hK59WV = { 'id' : VzAiKmWdsgw9XfIuF1e0 , 'user' : IIvxtojw6EXl2f , 'function' : 'playNT' , 'menu' : p7tSrCjXlc6M1i5WQTgq9zGJF }
		sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(nHBb7jXk0Daom,'POST', Str0BupDTFA, l17Sn3hK59WV, headers, False,hWGMqtBy4wuLaVcj,'LIVETV-PLAY-3rd')
		if not sDQvwGASB0Vf67mik.succeeded:
			BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
		url = sDQvwGASB0Vf67mik.headers['Location']
		url = url.replace('%20',Mpsm2VF1OBnCRvK3qf6)
		url = url.replace('%3D','=')
		if 'Learn' in VzAiKmWdsgw9XfIuF1e0:
			url = url.replace('NTNNile',hWGMqtBy4wuLaVcj)
			url = url.replace('learning1','Learning')
	elif dUWFtBQ3cpoIZ9=='PL':
		l17Sn3hK59WV = { 'id' : VzAiKmWdsgw9XfIuF1e0 , 'user' : IIvxtojw6EXl2f , 'function' : 'playPL' , 'menu' : p7tSrCjXlc6M1i5WQTgq9zGJF }
		sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(nHBb7jXk0Daom,'POST', Str0BupDTFA, l17Sn3hK59WV, hWGMqtBy4wuLaVcj,False,hWGMqtBy4wuLaVcj,'LIVETV-PLAY-4th')
		if not sDQvwGASB0Vf67mik.succeeded:
			BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
		url = sDQvwGASB0Vf67mik.headers['Location']
		headers = {'Referer':sDQvwGASB0Vf67mik.headers['Referer']}
		sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(lke5D6CpaAXPdEZyrBSw7T,'POST',url, hWGMqtBy4wuLaVcj,headers , hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'LIVETV-PLAY-5th')
		if not sDQvwGASB0Vf67mik.succeeded:
			BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
		items = trdVA0JvFaD.findall('source src="(.*?)"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		url = items[0]
	elif dUWFtBQ3cpoIZ9 in ['TA','FM','YU','WS1','WS2','RL1','RL2']:
		if dUWFtBQ3cpoIZ9=='TA': VzAiKmWdsgw9XfIuF1e0 = id
		headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
		l17Sn3hK59WV = { 'id' : VzAiKmWdsgw9XfIuF1e0 , 'user' : IIvxtojw6EXl2f , 'function' : 'play'+dUWFtBQ3cpoIZ9 , 'menu' : p7tSrCjXlc6M1i5WQTgq9zGJF }
		sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(nHBb7jXk0Daom,'POST',Str0BupDTFA,l17Sn3hK59WV,headers,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'LIVETV-PLAY-6th')
		if not sDQvwGASB0Vf67mik.succeeded:
			BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
		url = sDQvwGASB0Vf67mik.headers['Location']
		if dUWFtBQ3cpoIZ9=='FM':
			sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(lke5D6CpaAXPdEZyrBSw7T,'GET', url, hWGMqtBy4wuLaVcj, hWGMqtBy4wuLaVcj, False,hWGMqtBy4wuLaVcj,'LIVETV-PLAY-7th')
			url = sDQvwGASB0Vf67mik.headers['Location']
			url = url.replace('https','http')
	vOq38Y4XVZwdE(url,xjPuFK3EsIZSiobQ5X,'live')
	return
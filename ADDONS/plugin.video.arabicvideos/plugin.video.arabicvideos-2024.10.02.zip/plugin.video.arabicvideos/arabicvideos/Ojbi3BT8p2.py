# -*- coding: utf-8 -*-
from yoY3NdGViS import *
xjPuFK3EsIZSiobQ5X = 'EGYBEST1'
n0qFKQWhiBYXoTrvejVHUA4 = '_EB1_'
Str0BupDTFA = u6rbxnyjTl7I[xjPuFK3EsIZSiobQ5X][0]
P3UK1Rr4IdYe5 = ['مكتبتي','ايجي بست']
def ehB18u9sQFRi(mode,url,l7COkhRWD9uVS60Pte2NoyAaZn,text):
	if   mode==770: N6NCYivtV4I5rEXq = DP6FSBgNdX1rsvVR()
	elif mode==771: N6NCYivtV4I5rEXq = wg5aF3e8rcDh7SGpW6M1OPnkU(url,l7COkhRWD9uVS60Pte2NoyAaZn)
	elif mode==772: N6NCYivtV4I5rEXq = qt2zjyIbsS(url)
	elif mode==773: N6NCYivtV4I5rEXq = oanus6TxUFNAhSZKpJdYlEC4mV(url)
	elif mode==774: N6NCYivtV4I5rEXq = hadMgR0nOKHoGqpA(url,'FULL_FILTER___'+text)
	elif mode==775: N6NCYivtV4I5rEXq = hadMgR0nOKHoGqpA(url,'DEFINED_FILTER___'+text)
	elif mode==776: N6NCYivtV4I5rEXq = UCjs37gPYNoqt(url,l7COkhRWD9uVS60Pte2NoyAaZn)
	elif mode==779: N6NCYivtV4I5rEXq = lPwaAjFTMG4n7iSLkXcEuK0Zm(text,url)
	else: N6NCYivtV4I5rEXq = False
	return N6NCYivtV4I5rEXq
def DP6FSBgNdX1rsvVR():
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'بحث في الموقع',hWGMqtBy4wuLaVcj,779,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'_REMEMBERRESULTS_')
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(DpQifS0oKBI1hYcO,'GET',Str0BupDTFA,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'EGYBEST1-MENU-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('nav-list(.*?)</ul>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('href="(.*?)".*?<span>(.*?)</span>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,title in items:
			title = title.strip(Mpsm2VF1OBnCRvK3qf6)
			if any(BoSjXKxz41DcneO9UimClE in title for BoSjXKxz41DcneO9UimClE in P3UK1Rr4IdYe5): continue
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,771)
		RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('main-article(.*?)social-box',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('main-title.*?">(.*?)<.*?href="(.*?)"',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for title,llxFwq0CUNgQtivJzkHeGV in items:
			title = title.strip(Mpsm2VF1OBnCRvK3qf6)
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,771,hWGMqtBy4wuLaVcj,'mainmenu')
		RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('main-menu(.*?)</div></div>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('href="(.*?)">(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,title in items:
			title = title.strip(Mpsm2VF1OBnCRvK3qf6)
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,771)
	return mMQ3FkNVa4IlxqY
def UCjs37gPYNoqt(url,type=hWGMqtBy4wuLaVcj):
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'EGYBEST1-SEASONS_EPISODES-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('main-article".*?">(.*?)<(.*?)article',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		k8YRdISjEZF0qyzs5GK,aTjkFVusW1c35G8v,items = hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,[]
		for name,cok5ZGXdQP7YhwtqyuaCnVevm6UB in DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
			if 'حلقات' in name: aTjkFVusW1c35G8v = cok5ZGXdQP7YhwtqyuaCnVevm6UB
			if 'مواسم' in name: k8YRdISjEZF0qyzs5GK = cok5ZGXdQP7YhwtqyuaCnVevm6UB
		if k8YRdISjEZF0qyzs5GK and not type:
			items = trdVA0JvFaD.findall('href="(.*?)".*?data-src="(.*?)".*?"title">(.*?)<',k8YRdISjEZF0qyzs5GK,trdVA0JvFaD.DOTALL)
			if len(items)>1:
				for llxFwq0CUNgQtivJzkHeGV,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,title in items:
					RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,776,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,'season')
		if aTjkFVusW1c35G8v and len(items)<2:
			items = trdVA0JvFaD.findall('href="(.*?)".*?data-src="(.*?)".*?title="(.*?)"',aTjkFVusW1c35G8v,trdVA0JvFaD.DOTALL)
			if items:
				for llxFwq0CUNgQtivJzkHeGV,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,title in items:
					RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,773,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
			else:
				items = trdVA0JvFaD.findall('href="(.*?)">(.*?)<',aTjkFVusW1c35G8v,trdVA0JvFaD.DOTALL)
				for llxFwq0CUNgQtivJzkHeGV,title in items:
					RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,773)
	return
def wg5aF3e8rcDh7SGpW6M1OPnkU(url,type=hWGMqtBy4wuLaVcj):
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'EGYBEST1-TITLES-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	items,rryKCXIY9DzpowW1v538U0ORF,UGewLrVFhBCo7MdZ8KEaJWXgYp = [],False,False
	if not type:
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('main-content(.*?)</div>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
			cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
			items = trdVA0JvFaD.findall('href="(.*?)".*?</i>(.*?)</a>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
			for llxFwq0CUNgQtivJzkHeGV,title in items:
				title = title.strip(Mpsm2VF1OBnCRvK3qf6)
				RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,771,hWGMqtBy4wuLaVcj,'submenu')
				rryKCXIY9DzpowW1v538U0ORF = True
	if not type and 'p=' not in url:
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('searchform(.*?)</form>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
			if rryKCXIY9DzpowW1v538U0ORF: RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'فلتر محدد',url,775,hWGMqtBy4wuLaVcj,'filter')
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'فلتر كامل',url,774,hWGMqtBy4wuLaVcj,'filter')
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'بحث',url,779)
			RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
			UGewLrVFhBCo7MdZ8KEaJWXgYp = True
	if not rryKCXIY9DzpowW1v538U0ORF:
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('blocks(.*?)article',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
			cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
			items = trdVA0JvFaD.findall('href="(.*?)".*?src="(.*?)".*?class="title">(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
			for llxFwq0CUNgQtivJzkHeGV,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,title in items:
				Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG = Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG.strip(NXMOzZjYsmS9pf)
				llxFwq0CUNgQtivJzkHeGV = jkiCS0UWs2dNAJcGKn6mbHD(llxFwq0CUNgQtivJzkHeGV)
				if '/serie/' in llxFwq0CUNgQtivJzkHeGV: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,776,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,'season')
				else: RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,773,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
			l7COkhRWD9uVS60Pte2NoyAaZn = '1'
			if 'p=' in url: url,l7COkhRWD9uVS60Pte2NoyAaZn = url.split('p=',1)
			WFYAlCyzGj1H32ovtQLnBTqhS6X = '&' if '?' in url else '?'
			url = url+WFYAlCyzGj1H32ovtQLnBTqhS6X
			url = url.replace('?&','?')
			if len(items)==40:
				url = url+'p='+str(int(l7COkhRWD9uVS60Pte2NoyAaZn)+1)
				RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'الصفحة التالية',url,771)
			elif l7COkhRWD9uVS60Pte2NoyAaZn!='1':
				url = url+'p='+str(int(l7COkhRWD9uVS60Pte2NoyAaZn)-1)
				RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'الصفحة السابقة',url,771)
	return
def oanus6TxUFNAhSZKpJdYlEC4mV(url):
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(lke5D6CpaAXPdEZyrBSw7T,'GET',url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'EGYBEST1-PLAY-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	BX029UJFPvpNQsc45jbYZRh = trdVA0JvFaD.findall('<label>التصنيف</label>.*?">(.*?)<',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if BX029UJFPvpNQsc45jbYZRh and Dc20k3vN9hT5(xjPuFK3EsIZSiobQ5X,url,BX029UJFPvpNQsc45jbYZRh): return
	HHAWYIZauqLrJBitcneTljf7,zmDKurMJwj6fi,e5jnINLvSCHGrbREgd = [],[],[]
	llxFwq0CUNgQtivJzkHeGV = trdVA0JvFaD.findall('download-section.*?action="(.*?)"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if llxFwq0CUNgQtivJzkHeGV:
		llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV[0]
		if llxFwq0CUNgQtivJzkHeGV not in e5jnINLvSCHGrbREgd:
			e5jnINLvSCHGrbREgd.append(llxFwq0CUNgQtivJzkHeGV)
			zmDKurMJwj6fi.append(llxFwq0CUNgQtivJzkHeGV+'?named=__embed______'+e1mT8H4dGS3XFyx0KLUA9(url))
	rqIW37cd0iT1msDzRevOM = trdVA0JvFaD.findall('WatchServers(.*?)</div>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	for cok5ZGXdQP7YhwtqyuaCnVevm6UB in rqIW37cd0iT1msDzRevOM:
		m4IznKilUOByHweG68VJ = trdVA0JvFaD.findall("url='(.*?)'.*?>(.*?)<",cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,SODQ7qlNYoZcFK8e50rBsJaAHxiXjE in m4IznKilUOByHweG68VJ:
			if llxFwq0CUNgQtivJzkHeGV not in e5jnINLvSCHGrbREgd:
				e5jnINLvSCHGrbREgd.append(llxFwq0CUNgQtivJzkHeGV)
				zmDKurMJwj6fi.append(llxFwq0CUNgQtivJzkHeGV+'?named='+SODQ7qlNYoZcFK8e50rBsJaAHxiXjE+'__both______'+e1mT8H4dGS3XFyx0KLUA9(url))
	import oosSOfvdEQ
	oosSOfvdEQ.zfdYjsGLg8M6i15qZWh(zmDKurMJwj6fi,xjPuFK3EsIZSiobQ5X,'video',url)
	return
def lPwaAjFTMG4n7iSLkXcEuK0Zm(search,url=hWGMqtBy4wuLaVcj):
	search,vvKf4sXgZIMyEJPuC,showDialogs = IVTEJQOiMR2dYta9C(search)
	if not search: search = TrzfUidpv1LyAYqwexHJDuS()
	if not search: return
	lKqyOtIAvVY = search.replace(Mpsm2VF1OBnCRvK3qf6,'%20')
	if not url: url = Str0BupDTFA+'/search?query='+lKqyOtIAvVY
	else: url = url+'?title='+lKqyOtIAvVY+'&genre=&year=&lang='
	wg5aF3e8rcDh7SGpW6M1OPnkU(url,'search')
	return
def n92Ia7FtBScTYHrGRhkP5zi(url):
	url = url.split('/smartemadfilter?')[0]
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(DpQifS0oKBI1hYcO,'GET',url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'EGYBEST1-GET_FILTERS_BLOCKS-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	f5rVHP4bmCd7cqvuYEQJlnLTk6yGRS = []
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('form-row(.*?)</form>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		f5rVHP4bmCd7cqvuYEQJlnLTk6yGRS = trdVA0JvFaD.findall('select name="(.*?)".*?value>(.*?)<(.*?)</select',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		dQkYNWtjwfZFvBs9J1Lixe,aGtU0OYsI2puj19dwhFqVDkbS,rqIW37cd0iT1msDzRevOM = zip(*f5rVHP4bmCd7cqvuYEQJlnLTk6yGRS)
		f5rVHP4bmCd7cqvuYEQJlnLTk6yGRS = zip(aGtU0OYsI2puj19dwhFqVDkbS,dQkYNWtjwfZFvBs9J1Lixe,rqIW37cd0iT1msDzRevOM)
	return f5rVHP4bmCd7cqvuYEQJlnLTk6yGRS
def mPVz8jRSf0iHd2FNTswv4O1gy(cok5ZGXdQP7YhwtqyuaCnVevm6UB):
	items = trdVA0JvFaD.findall('value="(.*?)">(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	return items
def W6n8HvJog2(url):
	url = url.replace('/smartemadfilter?','?title=&')
	return url
eJviUHFbsoM1j7ROT3wklPVu = ['year','lang','genre']
VP4sijvgyceqRh = ['year','lang','genre']
def hadMgR0nOKHoGqpA(url,filter):
	url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==hWGMqtBy4wuLaVcj: RJGtCsyDgi0X,kYI6n5bUD83Z = hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj
	else: RJGtCsyDgi0X,kYI6n5bUD83Z = filter.split('___')
	if type=='DEFINED_FILTER':
		if VP4sijvgyceqRh[0]+'=' not in RJGtCsyDgi0X: OJx4sYA9nNbtPT5ezmDHdVBk2C7 = VP4sijvgyceqRh[0]
		for PPuqrvDLEViYOMf1dmkK7 in range(len(VP4sijvgyceqRh[0:-1])):
			if VP4sijvgyceqRh[PPuqrvDLEViYOMf1dmkK7]+'=' in RJGtCsyDgi0X: OJx4sYA9nNbtPT5ezmDHdVBk2C7 = VP4sijvgyceqRh[PPuqrvDLEViYOMf1dmkK7+1]
		nnqvmxlXub3iVDM = RJGtCsyDgi0X+'&'+OJx4sYA9nNbtPT5ezmDHdVBk2C7+'=0'
		tuYnONZ6GaCecv4TErUHMdBX2DIb8K = kYI6n5bUD83Z+'&'+OJx4sYA9nNbtPT5ezmDHdVBk2C7+'=0'
		BvO3oKUrHNCwVm791b80sZg = nnqvmxlXub3iVDM.strip('&')+'___'+tuYnONZ6GaCecv4TErUHMdBX2DIb8K.strip('&')
		PPlq1nxLf6CamuBI0psW = kKWuMB69mcOHPn3XilFdvp(kYI6n5bUD83Z,'all')
		NPM3HKQ57xe = url+'/smartemadfilter?'+PPlq1nxLf6CamuBI0psW
	elif type=='FULL_FILTER':
		I2OnWkrPaVbwBSHiYR3LZ = kKWuMB69mcOHPn3XilFdvp(RJGtCsyDgi0X,'modified_values')
		I2OnWkrPaVbwBSHiYR3LZ = jkiCS0UWs2dNAJcGKn6mbHD(I2OnWkrPaVbwBSHiYR3LZ)
		if kYI6n5bUD83Z: kYI6n5bUD83Z = kKWuMB69mcOHPn3XilFdvp(kYI6n5bUD83Z,'all')
		if not kYI6n5bUD83Z: NPM3HKQ57xe = url
		else: NPM3HKQ57xe = url+'/smartemadfilter?'+kYI6n5bUD83Z
		CMzQFXeI08KDwAJ9p = W6n8HvJog2(NPM3HKQ57xe)
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'أظهار قائمة الفيديو التي تم اختيارها ',CMzQFXeI08KDwAJ9p,771,hWGMqtBy4wuLaVcj,'filter')
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+' [[   '+I2OnWkrPaVbwBSHiYR3LZ+'   ]]',CMzQFXeI08KDwAJ9p,771,hWGMqtBy4wuLaVcj,'filter')
		RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	f5rVHP4bmCd7cqvuYEQJlnLTk6yGRS = n92Ia7FtBScTYHrGRhkP5zi(url)
	dict = {}
	for name,bksErtC1hwcVqlfyM82AnD,cok5ZGXdQP7YhwtqyuaCnVevm6UB in f5rVHP4bmCd7cqvuYEQJlnLTk6yGRS:
		name = name.replace('كل ',hWGMqtBy4wuLaVcj)
		items = mPVz8jRSf0iHd2FNTswv4O1gy(cok5ZGXdQP7YhwtqyuaCnVevm6UB)
		if '=' not in NPM3HKQ57xe: NPM3HKQ57xe = url
		if type=='DEFINED_FILTER':
			if OJx4sYA9nNbtPT5ezmDHdVBk2C7!=bksErtC1hwcVqlfyM82AnD: continue
			elif len(items)<2:
				if bksErtC1hwcVqlfyM82AnD==VP4sijvgyceqRh[-1]:
					CMzQFXeI08KDwAJ9p = W6n8HvJog2(NPM3HKQ57xe)
					wg5aF3e8rcDh7SGpW6M1OPnkU(CMzQFXeI08KDwAJ9p)
				else: hadMgR0nOKHoGqpA(NPM3HKQ57xe,'DEFINED_FILTER___'+BvO3oKUrHNCwVm791b80sZg)
				return
			else:
				if bksErtC1hwcVqlfyM82AnD==VP4sijvgyceqRh[-1]:
					CMzQFXeI08KDwAJ9p = W6n8HvJog2(NPM3HKQ57xe)
					RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'الجميع ',CMzQFXeI08KDwAJ9p,771,hWGMqtBy4wuLaVcj,'filter')
				else: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'الجميع ',NPM3HKQ57xe,775,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,BvO3oKUrHNCwVm791b80sZg)
		elif type=='FULL_FILTER':
			nnqvmxlXub3iVDM = RJGtCsyDgi0X+'&'+bksErtC1hwcVqlfyM82AnD+'=0'
			tuYnONZ6GaCecv4TErUHMdBX2DIb8K = kYI6n5bUD83Z+'&'+bksErtC1hwcVqlfyM82AnD+'=0'
			BvO3oKUrHNCwVm791b80sZg = nnqvmxlXub3iVDM+'___'+tuYnONZ6GaCecv4TErUHMdBX2DIb8K
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'الجميع :'+name,NPM3HKQ57xe,774,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,BvO3oKUrHNCwVm791b80sZg)
		dict[bksErtC1hwcVqlfyM82AnD] = {}
		for BoSjXKxz41DcneO9UimClE,PBo1KkyMCgH8eNDaLtZVcr3EnIi2 in items:
			if not BoSjXKxz41DcneO9UimClE: continue
			if PBo1KkyMCgH8eNDaLtZVcr3EnIi2 in P3UK1Rr4IdYe5: continue
			dict[bksErtC1hwcVqlfyM82AnD][BoSjXKxz41DcneO9UimClE] = PBo1KkyMCgH8eNDaLtZVcr3EnIi2
			nnqvmxlXub3iVDM = RJGtCsyDgi0X+'&'+bksErtC1hwcVqlfyM82AnD+'='+PBo1KkyMCgH8eNDaLtZVcr3EnIi2
			tuYnONZ6GaCecv4TErUHMdBX2DIb8K = kYI6n5bUD83Z+'&'+bksErtC1hwcVqlfyM82AnD+'='+BoSjXKxz41DcneO9UimClE
			S80DwNWuMTZx4El = nnqvmxlXub3iVDM+'___'+tuYnONZ6GaCecv4TErUHMdBX2DIb8K
			title = PBo1KkyMCgH8eNDaLtZVcr3EnIi2+' :'#+dict[bksErtC1hwcVqlfyM82AnD]['0']
			title = PBo1KkyMCgH8eNDaLtZVcr3EnIi2+' :'+name
			if type=='FULL_FILTER': RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,url,774,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,S80DwNWuMTZx4El)
			elif type=='DEFINED_FILTER' and VP4sijvgyceqRh[-2]+'=' in RJGtCsyDgi0X:
				PPlq1nxLf6CamuBI0psW = kKWuMB69mcOHPn3XilFdvp(tuYnONZ6GaCecv4TErUHMdBX2DIb8K,'modified_filters')
				NPM3HKQ57xe = url+'/smartemadfilter?'+PPlq1nxLf6CamuBI0psW
				CMzQFXeI08KDwAJ9p = W6n8HvJog2(NPM3HKQ57xe)
				RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,CMzQFXeI08KDwAJ9p,771,hWGMqtBy4wuLaVcj,'filter')
			elif type=='DEFINED_FILTER': RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,url,775,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,S80DwNWuMTZx4El)
	return
def kKWuMB69mcOHPn3XilFdvp(UGewLrVFhBCo7MdZ8KEaJWXgYp,mode):
	UGewLrVFhBCo7MdZ8KEaJWXgYp = UGewLrVFhBCo7MdZ8KEaJWXgYp.replace('=&','=0&')
	UGewLrVFhBCo7MdZ8KEaJWXgYp = UGewLrVFhBCo7MdZ8KEaJWXgYp.strip('&')
	ONVGLC8DSp4 = {}
	if '=' in UGewLrVFhBCo7MdZ8KEaJWXgYp:
		items = UGewLrVFhBCo7MdZ8KEaJWXgYp.split('&')
		for ImYg2jxU6Lc9Q1C4Oko in items:
			glBvuIRTJseUHjari,BoSjXKxz41DcneO9UimClE = ImYg2jxU6Lc9Q1C4Oko.split('=')
			ONVGLC8DSp4[glBvuIRTJseUHjari] = BoSjXKxz41DcneO9UimClE
	mJuhvt0RPAbBMSla = hWGMqtBy4wuLaVcj
	for key in eJviUHFbsoM1j7ROT3wklPVu:
		if key in list(ONVGLC8DSp4.keys()): BoSjXKxz41DcneO9UimClE = ONVGLC8DSp4[key]
		else: BoSjXKxz41DcneO9UimClE = '0'
		if '%' not in BoSjXKxz41DcneO9UimClE: BoSjXKxz41DcneO9UimClE = e1mT8H4dGS3XFyx0KLUA9(BoSjXKxz41DcneO9UimClE)
		if mode=='modified_values' and BoSjXKxz41DcneO9UimClE!='0': mJuhvt0RPAbBMSla = mJuhvt0RPAbBMSla+' + '+BoSjXKxz41DcneO9UimClE
		elif mode=='modified_filters' and BoSjXKxz41DcneO9UimClE!='0': mJuhvt0RPAbBMSla = mJuhvt0RPAbBMSla+'&'+key+'='+BoSjXKxz41DcneO9UimClE
		elif mode=='all': mJuhvt0RPAbBMSla = mJuhvt0RPAbBMSla+'&'+key+'='+BoSjXKxz41DcneO9UimClE
	mJuhvt0RPAbBMSla = mJuhvt0RPAbBMSla.strip(' + ')
	mJuhvt0RPAbBMSla = mJuhvt0RPAbBMSla.strip('&')
	mJuhvt0RPAbBMSla = mJuhvt0RPAbBMSla.replace('=0','=')
	return mJuhvt0RPAbBMSla
# -*- coding: utf-8 -*-
from yoY3NdGViS import *
xjPuFK3EsIZSiobQ5X = 'FUSHARVIDEO'
n0qFKQWhiBYXoTrvejVHUA4 = '_FVD_'
Str0BupDTFA = u6rbxnyjTl7I[xjPuFK3EsIZSiobQ5X][0]
P3UK1Rr4IdYe5 = ['الرئيسية','يلا شوت']
def ehB18u9sQFRi(mode,url,text):
	if   mode==900: N6NCYivtV4I5rEXq = DP6FSBgNdX1rsvVR()
	elif mode==901: N6NCYivtV4I5rEXq = wg5aF3e8rcDh7SGpW6M1OPnkU(url,text)
	elif mode==902: N6NCYivtV4I5rEXq = oanus6TxUFNAhSZKpJdYlEC4mV(url)
	elif mode==903: N6NCYivtV4I5rEXq = H1fiR4odCZLuxmkwISX(url)
	elif mode==909: N6NCYivtV4I5rEXq = lPwaAjFTMG4n7iSLkXcEuK0Zm(text)
	else: N6NCYivtV4I5rEXq = False
	return N6NCYivtV4I5rEXq
def DP6FSBgNdX1rsvVR():
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',Str0BupDTFA,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'FUSHARVIDEO-MENU-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'بحث في الموقع',hWGMqtBy4wuLaVcj,909,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'_REMEMBERRESULTS_')
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('"primary-links"(.*?)</u',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('href="(.*?)".*?<span>(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,title in items:
			if title in P3UK1Rr4IdYe5: continue
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,901)
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('"list-categories"(.*?)</u',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('href="(.*?)".*?>(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,title in items:
			if 'http' not in llxFwq0CUNgQtivJzkHeGV: llxFwq0CUNgQtivJzkHeGV = Str0BupDTFA+'/'+llxFwq0CUNgQtivJzkHeGV.lstrip('/')
			if title in P3UK1Rr4IdYe5: continue
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,901)
	return
def wg5aF3e8rcDh7SGpW6M1OPnkU(url,type=hWGMqtBy4wuLaVcj):
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'FUSHARVIDEO-TITLES-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('"home-content"(.*?)"footer"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = cok5ZGXdQP7YhwtqyuaCnVevm6UB.replace('"overlay"','"duration"><')
		items = trdVA0JvFaD.findall('"thumb".*?data-src="(.*?)".*?"duration">(.*?)<.*?href="(.*?)">(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		REbVyXis1w4Ae = []
		for Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,oJV18NUZAzPGqMu7tenCxrkfhdl69B,llxFwq0CUNgQtivJzkHeGV,title in items:
			title = title.strip(' ')
			title = LNtIDdBA52P(title)
			IIsmGy4pd7 = trdVA0JvFaD.findall('(.*?) (الحلقة|حلقة).\d+',title,trdVA0JvFaD.DOTALL)
			if 'episodes' not in type and IIsmGy4pd7:
				title = '_MOD_' + IIsmGy4pd7[0][0]
				title = title.replace('اون لاين',hWGMqtBy4wuLaVcj)
				if title not in REbVyXis1w4Ae:
					RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,903,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
					REbVyXis1w4Ae.append(title)
			else: RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,902,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,oJV18NUZAzPGqMu7tenCxrkfhdl69B)
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('''["']pagination["'](.*?)["']footer["']''',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		type = 'episodes_pages' if 'episodes' in type else 'pages'
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('href="(.*?)">(.*?)</a>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,title in items:
			title = LNtIDdBA52P(title)
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'صفحة '+title,llxFwq0CUNgQtivJzkHeGV,901,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,type)
	else:
		llxFwq0CUNgQtivJzkHeGV = trdVA0JvFaD.findall('load-next-button" href="(.*?)"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if llxFwq0CUNgQtivJzkHeGV: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'صفحة جديدة',llxFwq0CUNgQtivJzkHeGV[0],901,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,type)
	return
def H1fiR4odCZLuxmkwISX(url):
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'FUSHARVIDEO-SERIES-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('class="eplist"(.*?)</div>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		aTjkFVusW1c35G8v = trdVA0JvFaD.findall('href="(.*?)" title="(.*?)"',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,title in aTjkFVusW1c35G8v:
			RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,902)
	else:
		llxFwq0CUNgQtivJzkHeGV = trdVA0JvFaD.findall('"category".*?href="(.*?)"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if llxFwq0CUNgQtivJzkHeGV:
			llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV[0]
			wg5aF3e8rcDh7SGpW6M1OPnkU(llxFwq0CUNgQtivJzkHeGV,'episodes')
	return
def oanus6TxUFNAhSZKpJdYlEC4mV(url):
	zmDKurMJwj6fi,RhxlHcOYSUGBnqM9p8mAIzF23 = [],[]
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'FUSHARVIDEO-PLAY-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	if 'hash=' in mMQ3FkNVa4IlxqY:
		s09KAdQnmltvzLk8HeaJuxTS = trdVA0JvFaD.findall('hash=(.*?)"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		s09KAdQnmltvzLk8HeaJuxTS = list(set(s09KAdQnmltvzLk8HeaJuxTS))
		for NIsiUn6g8xMOuZvz2kejD in s09KAdQnmltvzLk8HeaJuxTS:
			tMqK7iPfza5UykIXDcE = []
			LLsGB1FPiUTyYrdwqf86eHAnQ = NIsiUn6g8xMOuZvz2kejD.split('__')
			for ww93NKCHTO in LLsGB1FPiUTyYrdwqf86eHAnQ:
				try:
					ww93NKCHTO = FxG0Q9kuBSmTyM.b64decode(ww93NKCHTO+'=')
					if H4qZ2hwilNJYTmCFEQyaSs98cPM0gR: ww93NKCHTO = ww93NKCHTO.decode(a7VXeDU82IfQEnPZAdiT)
					tMqK7iPfza5UykIXDcE.append(ww93NKCHTO)
				except: pass
			m4IznKilUOByHweG68VJ = '>'.join(tMqK7iPfza5UykIXDcE)
			m4IznKilUOByHweG68VJ = m4IznKilUOByHweG68VJ.splitlines()
			for llxFwq0CUNgQtivJzkHeGV in m4IznKilUOByHweG68VJ:
				if ' => ' in llxFwq0CUNgQtivJzkHeGV:
					title,llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV.split(' => ')
					llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV+'?named='+title+'__watch'
					zmDKurMJwj6fi.append(llxFwq0CUNgQtivJzkHeGV)
	elif 'post_id' in mMQ3FkNVa4IlxqY:
		TsFgQdloabE4YpPWV = trdVA0JvFaD.findall("post_id = '(.*?)'",mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if TsFgQdloabE4YpPWV:
			TsFgQdloabE4YpPWV = TsFgQdloabE4YpPWV[0]
			headers = {'X-Requested-With':'XMLHttpRequest'}
			IHYesWZQ9DKd = Str0BupDTFA+'/wp-admin/admin-ajax.php?action=video_info&post_id='+TsFgQdloabE4YpPWV
			sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',IHYesWZQ9DKd,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'FUSHARVIDEO-PLAY-2nd')
			YMKNT2AHn6mlOIUwy = sDQvwGASB0Vf67mik.content
			Pz1ApnjyVmvo07DNuUiEkRbTZM2 = trdVA0JvFaD.findall('"name":"(.*?)","src":"(.*?)"',YMKNT2AHn6mlOIUwy,trdVA0JvFaD.DOTALL)
			if not Pz1ApnjyVmvo07DNuUiEkRbTZM2:
				Pz1ApnjyVmvo07DNuUiEkRbTZM2 = trdVA0JvFaD.findall('"src":"(.*?)"',YMKNT2AHn6mlOIUwy,trdVA0JvFaD.DOTALL)
				if Pz1ApnjyVmvo07DNuUiEkRbTZM2:
					nUcKh9lt6Hkfv4Y = ['']*len(Pz1ApnjyVmvo07DNuUiEkRbTZM2)
					Pz1ApnjyVmvo07DNuUiEkRbTZM2 = list(zip(nUcKh9lt6Hkfv4Y,Pz1ApnjyVmvo07DNuUiEkRbTZM2))
			for name,llxFwq0CUNgQtivJzkHeGV in Pz1ApnjyVmvo07DNuUiEkRbTZM2:
				llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV.replace('\\/','/')
				llxFwq0CUNgQtivJzkHeGV = e1mT8H4dGS3XFyx0KLUA9(llxFwq0CUNgQtivJzkHeGV)
				if llxFwq0CUNgQtivJzkHeGV in RhxlHcOYSUGBnqM9p8mAIzF23: continue
				else: RhxlHcOYSUGBnqM9p8mAIzF23.append(llxFwq0CUNgQtivJzkHeGV)
				zmDKurMJwj6fi.append(llxFwq0CUNgQtivJzkHeGV+'?named='+name+'__watch')
			MDSF21x9HK3AZyGUhcb = Str0BupDTFA+'/wp-admin/admin-ajax.php?action=mwp_generate_video_download_link&post_id='+TsFgQdloabE4YpPWV+'&video_id=null&video_url=null&video_source=custom'
			sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',MDSF21x9HK3AZyGUhcb,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'FUSHARVIDEO-PLAY-3rd')
			eecmFXt5SRyCjGpx = sDQvwGASB0Vf67mik.content
			geqj2CKuf35LJDt4lVdA0Q = trdVA0JvFaD.findall('href="(.*?)".*?>(.*?)<',eecmFXt5SRyCjGpx,trdVA0JvFaD.DOTALL)
			if geqj2CKuf35LJDt4lVdA0Q:
				eJAHaT0bK9pL,SsuAXqwI2dQND3mJL8Pao = zip(*geqj2CKuf35LJDt4lVdA0Q)
				geqj2CKuf35LJDt4lVdA0Q = list(zip(SsuAXqwI2dQND3mJL8Pao,eJAHaT0bK9pL))
			for name,llxFwq0CUNgQtivJzkHeGV in geqj2CKuf35LJDt4lVdA0Q:
				llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV.replace('\\/','/')
				llxFwq0CUNgQtivJzkHeGV = e1mT8H4dGS3XFyx0KLUA9(llxFwq0CUNgQtivJzkHeGV)
				if llxFwq0CUNgQtivJzkHeGV in RhxlHcOYSUGBnqM9p8mAIzF23: continue
				else: RhxlHcOYSUGBnqM9p8mAIzF23.append(llxFwq0CUNgQtivJzkHeGV)
				zmDKurMJwj6fi.append(llxFwq0CUNgQtivJzkHeGV+'?named='+name+'__download')
	import oosSOfvdEQ
	oosSOfvdEQ.zfdYjsGLg8M6i15qZWh(zmDKurMJwj6fi,xjPuFK3EsIZSiobQ5X,'video',url)
	return
def lPwaAjFTMG4n7iSLkXcEuK0Zm(search):
	search,vvKf4sXgZIMyEJPuC,showDialogs = IVTEJQOiMR2dYta9C(search)
	if search==hWGMqtBy4wuLaVcj: search = TrzfUidpv1LyAYqwexHJDuS()
	if search==hWGMqtBy4wuLaVcj: return
	search = search.replace(Mpsm2VF1OBnCRvK3qf6,'+')
	url = Str0BupDTFA+'/?s='+search
	wg5aF3e8rcDh7SGpW6M1OPnkU(url,'search')
	return
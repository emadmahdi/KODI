# -*- coding: utf-8 -*-
import sys as zGjD5QAkd7SO9YPcZl
A56Abl2j14QS = zGjD5QAkd7SO9YPcZl.version_info [0] == 2
qO2vebR9rSTZnuJDW = 2048
EECQl2Zun37S0KkWwtIDHYNai6Ayd8 = 7
def wwTjCFmkUK (mMBv4T89VDdfJGL):
	global ylRUYSmHX7oCf93TADc8J6rqMVL
	tE23ZuI91qGJ = ord (mMBv4T89VDdfJGL [-1])
	huZOyFMzvY3LpEf = mMBv4T89VDdfJGL [:-1]
	FXE237NbgJweKmBxPfVnsAoYjCazqW = tE23ZuI91qGJ % len (huZOyFMzvY3LpEf)
	LQ2yAP51CVNFXdr = huZOyFMzvY3LpEf [:FXE237NbgJweKmBxPfVnsAoYjCazqW] + huZOyFMzvY3LpEf [FXE237NbgJweKmBxPfVnsAoYjCazqW:]
	if A56Abl2j14QS:
		R0i7UHvbBw25n8 = unicode () .join ([unichr (ord (cIsD9VN758uwbLUaGM2zmEY) - qO2vebR9rSTZnuJDW - (o42QnFjKJ5l98hWTqzCDi73LcvNA + tE23ZuI91qGJ) % EECQl2Zun37S0KkWwtIDHYNai6Ayd8) for o42QnFjKJ5l98hWTqzCDi73LcvNA, cIsD9VN758uwbLUaGM2zmEY in enumerate (LQ2yAP51CVNFXdr)])
	else:
		R0i7UHvbBw25n8 = str () .join ([chr (ord (cIsD9VN758uwbLUaGM2zmEY) - qO2vebR9rSTZnuJDW - (o42QnFjKJ5l98hWTqzCDi73LcvNA + tE23ZuI91qGJ) % EECQl2Zun37S0KkWwtIDHYNai6Ayd8) for o42QnFjKJ5l98hWTqzCDi73LcvNA, cIsD9VN758uwbLUaGM2zmEY in enumerate (LQ2yAP51CVNFXdr)])
	return eval (R0i7UHvbBw25n8)
NeO3CTLHrPfWUoIgy8Q,KNIvHPjUbhr,CnbBKmtF1x84q7AW=wwTjCFmkUK,wwTjCFmkUK,wwTjCFmkUK
zyvJMtBhrw,MMizeNH0AKu,KBkxSYaz93pu1=CnbBKmtF1x84q7AW,KNIvHPjUbhr,NeO3CTLHrPfWUoIgy8Q
LB2q7IVRpcyXlE6C3ihZruPe4An1Y,EDgpT9hIF6GCfl0vXiWnBANjOUVRua,XQo0YS3sk4rHAvwyNltf9CipLWMjx=KBkxSYaz93pu1,MMizeNH0AKu,zyvJMtBhrw
hWUz1ujibPY3G9MIZmvS4kVaK7dT,DJ1ICpbyR2,e2qDYgipPmTw4KvBLnochr=XQo0YS3sk4rHAvwyNltf9CipLWMjx,EDgpT9hIF6GCfl0vXiWnBANjOUVRua,LB2q7IVRpcyXlE6C3ihZruPe4An1Y
A6dMB1FlgxVivJ2fk9C,mkHKSQvjWr5BTcM3wVY,o1u5dij9UrcbXzVS8lwIWfKpnqM=e2qDYgipPmTw4KvBLnochr,DJ1ICpbyR2,hWUz1ujibPY3G9MIZmvS4kVaK7dT
JwiZdgbG5HYuCIsj69aBSRQ0nrNkET,SqrG5mU3j96ldsFpExobw40TJY,HHoGx7Flus60=o1u5dij9UrcbXzVS8lwIWfKpnqM,mkHKSQvjWr5BTcM3wVY,A6dMB1FlgxVivJ2fk9C
QVDJLRlxNg127jMX,gDuGMR3z1aV6YdLmCpiO8Kl,jeAby54c02TgG8zuivonX91=HHoGx7Flus60,SqrG5mU3j96ldsFpExobw40TJY,JwiZdgbG5HYuCIsj69aBSRQ0nrNkET
S1SgCFYGJeMvfp5iZXK,dv0trJR7PwmKyxDYO52VLau8gEph,QvgnCALNstmuUJiET=jeAby54c02TgG8zuivonX91,gDuGMR3z1aV6YdLmCpiO8Kl,QVDJLRlxNg127jMX
OOsBSKq9u6J2lC5WdYpvNMHaFP4,rwQN9AKhLCuMfHxjlbX0U,xcChIL13BpR8WArNt9Pl0So=QvgnCALNstmuUJiET,dv0trJR7PwmKyxDYO52VLau8gEph,S1SgCFYGJeMvfp5iZXK
sULh4NjakzI8He7xJCMGrql,LAhIMyBG0xZVUlO4rJ9z5fbDFgCs,GA4NBdjuZqkKUX6IEMvHPoegDyVrLm=xcChIL13BpR8WArNt9Pl0So,rwQN9AKhLCuMfHxjlbX0U,OOsBSKq9u6J2lC5WdYpvNMHaFP4
ITvnUAMXsyb4eO,wwPrSDa21lUh,FimxS5jkaq1RcJ8DnWTZNO4zQClwt=GA4NBdjuZqkKUX6IEMvHPoegDyVrLm,LAhIMyBG0xZVUlO4rJ9z5fbDFgCs,sULh4NjakzI8He7xJCMGrql
from yoY3NdGViS import *
xjPuFK3EsIZSiobQ5X = GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ᪠")
AntmbV4eiqEgSBv60y = []
headers = {dv0trJR7PwmKyxDYO52VLau8gEph(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ᪡"):hWGMqtBy4wuLaVcj}
def LBEn1GcYu5He(source,X3X4Y8RzxSVfZJUFDe,url):
	KteLZCbM8W0FqE2OBx1(VRQE4jsXHSfhPWo5DgLwxGk,qhVEWvetzXLOcr1(xjPuFK3EsIZSiobQ5X)+FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠧࠡࠢࠣࡊࡦ࡯࡬ࡦࡦࠣࡪ࡮ࡴࡤࡪࡰࡪࠤࡻ࡯ࡤࡦࡱࠣࡪ࡮ࡲࡥࡴࠢࠣࠤ࡙ࠥࡩࡵࡧ࠽ࠤࡠࠦࠧ᪢")+source+jeAby54c02TgG8zuivonX91(u"ࠨࠢࡠࠤࠥࠦࠠࡕࡻࡳࡩ࠿࡛ࠦࠡࠩ᪣")+X3X4Y8RzxSVfZJUFDe+HHoGx7Flus60(u"ࠩࠣࡡࠬ᪤"))
	eDIOuKvz3ExX9ZRrjQBgLw7dHGMNS = Mqk51CFBym0pIQXZLsOxSJ(MM5Dx39f7ULhcJsRptzIowP,QVDJLRlxNg127jMX(u"ࠪࡨ࡮ࡩࡴࠨ᪥"),rwQN9AKhLCuMfHxjlbX0U(u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧ᪦"),wwPrSDa21lUh(u"࡙ࠬࡉࡕࡇࡖࡣࡊࡘࡒࡐࡔࡖࠫᪧ"))
	zYA9NDGmltgjb0OM6vdTrx14KU = HB5PvxRhwM.strftime(o1u5dij9UrcbXzVS8lwIWfKpnqM(u"࡚࠭ࠥ࠰ࠨࡱ࠳ࠫࡤࠡࠧࡋ࠾ࠪࡓࠧ᪨"),HB5PvxRhwM.gmtime(IHKJoQ8PwW4pNBR6GTAMVz2hdfC5my))
	xxcMsZ2DfavVz = zYA9NDGmltgjb0OM6vdTrx14KU,url
	key = source+nIDXGaRHv7mOohe0Y8dLstECM+aO9cFKo862LqTWlIjy+nIDXGaRHv7mOohe0Y8dLstECM+str(guSzmUCXDa1tQpY)
	jjEwJpmd2v0oxBRP1Dyu = hWGMqtBy4wuLaVcj
	if key not in list(eDIOuKvz3ExX9ZRrjQBgLw7dHGMNS.keys()): eDIOuKvz3ExX9ZRrjQBgLw7dHGMNS[key] = [xxcMsZ2DfavVz]
	else:
		if url not in str(eDIOuKvz3ExX9ZRrjQBgLw7dHGMNS[key]): eDIOuKvz3ExX9ZRrjQBgLw7dHGMNS[key].append(xxcMsZ2DfavVz)
		else: jjEwJpmd2v0oxBRP1Dyu = KBkxSYaz93pu1(u"ࠧ࡝ࡰ๋ࠣีอࠠศๆไ๎ิ๐่ࠡ็๋ะํีࠠโ์ࠣๆฬฬๅสࠢส่ๆ๐ฯ๋๊๊หฯࠦวๅฬํࠤ้๋ࠠห฻่่ࠬ᪩")
	J8dPQ3fzmXBO1aWACZTo4tnvlrR7F = ybdv7XcT3lxF6QezULwCAGk
	for key in list(eDIOuKvz3ExX9ZRrjQBgLw7dHGMNS.keys()):
		eDIOuKvz3ExX9ZRrjQBgLw7dHGMNS[key] = list(set(eDIOuKvz3ExX9ZRrjQBgLw7dHGMNS[key]))
		J8dPQ3fzmXBO1aWACZTo4tnvlrR7F += len(eDIOuKvz3ExX9ZRrjQBgLw7dHGMNS[key])
	BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,sULh4NjakzI8He7xJCMGrql(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ᪪"),QVDJLRlxNg127jMX(u"ࠩ็่ศูแࠡษ็ฬึ์วๆฮ่๊๊ࠣࠦอั้้ࠣ็วหࠢส่ๆ๐ฯ๋๊ࠪ᪫")+jjEwJpmd2v0oxBRP1Dyu+hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠪࡠࡳࡢ࡮ࠡๆ็฽้๋ࠠศๆหี๋อๅอࠢํๆํ๋ࠠษฮ่฽่ࠥวว็ฬࠤออไโ์า๎ํํวหࠢส่ฯ๐ࠠๅ็ࠣ๎ัีࠠๅ้สࠤ๊๊แศฬࠣๅ๏ี๊้๋ࠢืํ็๋ࠠ฻ิฺࠥ฿ไ๋ๅࠣห้ฮั็ษ่ะࠥษๆࠡฬิื้ࠦ็ั้ࠣห้่วว็ฬࠤส๊้ࠡษ็้อืๅอࠢ฼๊ิ๋วࠡ์ุฬาูࠦะั๊หࠥ࠻ࠠโ์า๎ํํวหࠩ᪬")+gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠫࡡࡴ࡜࡯ࠩ᪭")+NeO3CTLHrPfWUoIgy8Q(u"ࠬ฿ฯะࠢส่ๆ๐ฯ๋๊๊หฯࠦแ๋ࠢส่็อฦๆหࠣห้ศๆ้๋ࠡࠤ࠿ࠦࠠࠨ᪮")+str(J8dPQ3fzmXBO1aWACZTo4tnvlrR7F))
	if J8dPQ3fzmXBO1aWACZTo4tnvlrR7F>=XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"࠵ॽ"):
		dHPVDWfG4jX5e6QEo0CKh = XVmKrby29eCGMnlEY6jz0HNOR(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,dv0trJR7PwmKyxDYO52VLau8gEph(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ᪯"),LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠧศๆหี๋อๅอࠢฯ้฾ࠦโศศ่อࠥ็๊่ษࠣ࠹ࠥ็๊ะ์๋๋ฬะࠠๅ็ࠣ๎ัีࠠศๆหี๋อๅอࠢ็๋ฬࠦๅๅใสฮࠥ็๊ะ์๋ࠤ࠳࠴ࠠิ๊ไࠤ๏่่ๆࠢส่อืๆศ็ฯࠤฬ๊ย็ࠢหุ้ำ่ࠠา๊ࠤฬ๊โศศ่อࠥࡢ࡮࡝ࡰ๋้ࠣࠦสา์าࠤสืำศๆ๋ࠣีํࠠศๆๅหห๋ษࠡไห่๋ࠥำฮ้สࠤส๊้ࠡษ็้อืๅอࠢ็็๏๊ࠦใ๊่ࠤฬ๊ๅษำ่ะࠥฮแฮื๋ࠣีํࠠศๆไ๎ิ๐่่ษอࠤฤࠧࠡࠨ᪰"))
		if dHPVDWfG4jX5e6QEo0CKh==LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"࠲ॾ"):
			U0I8gTn4h7YmSfpH = hWGMqtBy4wuLaVcj
			for key in list(eDIOuKvz3ExX9ZRrjQBgLw7dHGMNS.keys()):
				U0I8gTn4h7YmSfpH += NXMOzZjYsmS9pf+key
				VG1ud8vUAxg9jnq = sorted(eDIOuKvz3ExX9ZRrjQBgLw7dHGMNS[key],reverse=fEXMiAyG3ql4vKB,key=lambda WrEISHij4gUDPQLz: WrEISHij4gUDPQLz[ybdv7XcT3lxF6QezULwCAGk])
				for zYA9NDGmltgjb0OM6vdTrx14KU,url in VG1ud8vUAxg9jnq:
					U0I8gTn4h7YmSfpH += NXMOzZjYsmS9pf+zYA9NDGmltgjb0OM6vdTrx14KU+nIDXGaRHv7mOohe0Y8dLstECM+jkiCS0UWs2dNAJcGKn6mbHD(url)
				U0I8gTn4h7YmSfpH += xcChIL13BpR8WArNt9Pl0So(u"ࠨ࡞ࡱࡠࡳ࠭᪱")
			import ZGYSlz63X1
			G62uf8ZSIzBE = ZGYSlz63X1.IYfvGAuH1W(QVDJLRlxNg127jMX(u"࡙ࠩ࡭ࡩ࡫࡯ࡴࠩ᪲"),hWGMqtBy4wuLaVcj,fEXMiAyG3ql4vKB,hWGMqtBy4wuLaVcj,EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡐࡍࡃ࡜ࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ᪳"),hWGMqtBy4wuLaVcj,U0I8gTn4h7YmSfpH)
			if G62uf8ZSIzBE: BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ᪴"),QvgnCALNstmuUJiET(u"ࠬะๅࠡษ็ษึูวๅࠢห๊ัออࠨ᪵"))
			else: BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,rwQN9AKhLCuMfHxjlbX0U(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอ᪶ࠩ"),JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠧโึ็ฮࠥ฿ๅๅ์ฬࠤฬ๊ลาีส่᪷ࠬ"))
		if dHPVDWfG4jX5e6QEo0CKh!=-bXukYxQ4aHw:
			eDIOuKvz3ExX9ZRrjQBgLw7dHGMNS = {}
			pMPR1Cc0usZ6nJTU(MM5Dx39f7ULhcJsRptzIowP,HHoGx7Flus60(u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐ᪸ࠫ"),dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠩࡖࡍ࡙ࡋࡓࡠࡇࡕࡖࡔࡘࡓࠨ᪹"))
	if eDIOuKvz3ExX9ZRrjQBgLw7dHGMNS: BxuD7iQRpW1(MM5Dx39f7ULhcJsRptzIowP,sULh4NjakzI8He7xJCMGrql(u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ᪺࠭"),OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠫࡘࡏࡔࡆࡕࡢࡉࡗࡘࡏࡓࡕࠪ᪻"),eDIOuKvz3ExX9ZRrjQBgLw7dHGMNS,VWxPgG1p8Z2Ei4DrX7NotvR)
	return
def zfdYjsGLg8M6i15qZWh(zmDKurMJwj6fi,source,X3X4Y8RzxSVfZJUFDe,url):
	if not zmDKurMJwj6fi:
		LBEn1GcYu5He(source,X3X4Y8RzxSVfZJUFDe,url)
		return
	zmDKurMJwj6fi = list(set(zmDKurMJwj6fi))
	haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = GIVf6kMy5tl3D0E(zmDKurMJwj6fi,source)
	if MmcgqAlsFt.resolveonly:
		LRmiAODQ7szSVke29FHapMP0u = sspH0IwZRTLhg921Cd4QBjJDXWa(haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me,source,fEXMiAyG3ql4vKB)
		return
	qjvQn208uWwa7esSKgbHMx,pxdY8tiazyJIq,IRlka04VtyGe9hjbU7rpZSwCM5z,LRmiAODQ7szSVke29FHapMP0u = fEXMiAyG3ql4vKB,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,[]
	XxBls624MW7ubFHZhdI5vEftyUKqYD = not any(BoSjXKxz41DcneO9UimClE in source for BoSjXKxz41DcneO9UimClE in LZOi9HCezVMGtnaYD06K7)
	if XxBls624MW7ubFHZhdI5vEftyUKqYD:
		gpnqP3UEb7T = ybdv7XcT3lxF6QezULwCAGk
		O5It4Sy2Yf3aquJGWl61pKdwFeo9 = Mqk51CFBym0pIQXZLsOxSJ(MM5Dx39f7ULhcJsRptzIowP,OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠬࡲࡩࡴࡶࠪ᪼"),KBkxSYaz93pu1(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡄࡠࡕࡘࡇࡈࡋࡅࡅࡇࡇ᪽ࠫ"))
		RIl5Vr4TWKHqEmpUDi = Mqk51CFBym0pIQXZLsOxSJ(MM5Dx39f7ULhcJsRptzIowP,KBkxSYaz93pu1(u"ࠧ࡭࡫ࡶࡸࠬ᪾"),QvgnCALNstmuUJiET(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡆࡢࡊࡆࡏࡌࡆࡆᪿࠪ"))
		XK2iWMx6yfU9E = ybdv7XcT3lxF6QezULwCAGk
		for title,llxFwq0CUNgQtivJzkHeGV in zip(haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me):
			llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV.split(GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠩࡂࡲࡦࡳࡥࡥ࠿ᫀࠪ"),bXukYxQ4aHw)[ybdv7XcT3lxF6QezULwCAGk]
			if llxFwq0CUNgQtivJzkHeGV in O5It4Sy2Yf3aquJGWl61pKdwFeo9:
				gpnqP3UEb7T += bXukYxQ4aHw
				haq1bHZINPE58uoBFnKfTSO2ik4[XK2iWMx6yfU9E] = tsBed5hpnEXTRG0u3U8KYlDfW1j+title+YYSh2J6BIrsm8
			elif llxFwq0CUNgQtivJzkHeGV in RIl5Vr4TWKHqEmpUDi:
				gpnqP3UEb7T += bXukYxQ4aHw
				haq1bHZINPE58uoBFnKfTSO2ik4[XK2iWMx6yfU9E] = hXB0vKVQ5PRI91SDTprMdfuHEm4+title+YYSh2J6BIrsm8
			XK2iWMx6yfU9E += bXukYxQ4aHw
		ImYg2jxU6Lc9Q1C4Oko = [soMVfbr6WtpNlcSA+QVDJLRlxNg127jMX(u"ࠪๅา฻ࠠอ็ํ฽ࠥอไิ์ิๅึอสࠨ᫁")+YYSh2J6BIrsm8]
	else: onvmDiWftdbAYZBTjsu = soMVfbr6WtpNlcSA+A6dMB1FlgxVivJ2fk9C(u"ࠫศิสาࠢสุ่๐ัโำࠣห้๋ๆศีหࠫ᫂")+YYSh2J6BIrsm8
	while VBlawK4mgHSyLEn8iqhUkz5:
		Ij1hXVRiAJ = VBlawK4mgHSyLEn8iqhUkz5
		if XxBls624MW7ubFHZhdI5vEftyUKqYD:
			if len(haq1bHZINPE58uoBFnKfTSO2ik4)==bXukYxQ4aHw: OODLkJlZCoKmrzbg2XQSGPUdInA = bXukYxQ4aHw
			else:
				YoOz51y9tgAIralMbVQJkXKLwnsEUf = str(haq1bHZINPE58uoBFnKfTSO2ik4).count(tsBed5hpnEXTRG0u3U8KYlDfW1j)
				EQ1rGZWgs8XBPvuAl = str(haq1bHZINPE58uoBFnKfTSO2ik4).count(hXB0vKVQ5PRI91SDTprMdfuHEm4)
				MUZKgiSOTrI = len(haq1bHZINPE58uoBFnKfTSO2ik4)-YoOz51y9tgAIralMbVQJkXKLwnsEUf-EQ1rGZWgs8XBPvuAl
				if VKiGj1LundAJQwEXcqgxC: onvmDiWftdbAYZBTjsu = hXB0vKVQ5PRI91SDTprMdfuHEm4+sULh4NjakzI8He7xJCMGrql(u"ࠬࠦࠠࠡีํสฮࡀ᫃ࠧ")+str(EQ1rGZWgs8XBPvuAl)+YYSh2J6BIrsm8+rwQN9AKhLCuMfHxjlbX0U(u"่࠭ࠠࠡࠢะ์๎ไส࠼᫄ࠪ")+str(MUZKgiSOTrI)+tsBed5hpnEXTRG0u3U8KYlDfW1j+DJ1ICpbyR2(u"ࠧอ์าอ࠿࠭᫅")+str(YoOz51y9tgAIralMbVQJkXKLwnsEUf)+YYSh2J6BIrsm8
				else: onvmDiWftdbAYZBTjsu = tsBed5hpnEXTRG0u3U8KYlDfW1j+XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠨฮํำฮࡀࠧ᫆")+str(YoOz51y9tgAIralMbVQJkXKLwnsEUf)+YYSh2J6BIrsm8+CnbBKmtF1x84q7AW(u"ࠩࠣࠤ๋ࠥฬ่๊็อ࠿࠭᫇")+str(MUZKgiSOTrI)+hXB0vKVQ5PRI91SDTprMdfuHEm4+LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠪࠤࠥࠦำ๋ศฬ࠾ࠬ᫈")+str(EQ1rGZWgs8XBPvuAl)+YYSh2J6BIrsm8
				OODLkJlZCoKmrzbg2XQSGPUdInA = Eb7qJoNwOgn(onvmDiWftdbAYZBTjsu,ImYg2jxU6Lc9Q1C4Oko+haq1bHZINPE58uoBFnKfTSO2ik4)
			if OODLkJlZCoKmrzbg2XQSGPUdInA==ybdv7XcT3lxF6QezULwCAGk:
				Ij1hXVRiAJ = fEXMiAyG3ql4vKB
				start,end = ybdv7XcT3lxF6QezULwCAGk,len(haq1bHZINPE58uoBFnKfTSO2ik4)-bXukYxQ4aHw
				LRmiAODQ7szSVke29FHapMP0u = sspH0IwZRTLhg921Cd4QBjJDXWa(haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me,source,VBlawK4mgHSyLEn8iqhUkz5)
				IRlka04VtyGe9hjbU7rpZSwCM5z = hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠫࡷ࡫ࡳࡰ࡮ࡹࡩࡩࡥࡡ࡭࡮ࠪ᫉") if LRmiAODQ7szSVke29FHapMP0u else S1SgCFYGJeMvfp5iZXK(u"ࠬࡴ࡯ࡵࡡࡵࡩࡸࡵ࡬ࡷࡣࡥࡰࡪ᫊࠭")
			elif OODLkJlZCoKmrzbg2XQSGPUdInA>ybdv7XcT3lxF6QezULwCAGk: start,end = OODLkJlZCoKmrzbg2XQSGPUdInA-bXukYxQ4aHw,OODLkJlZCoKmrzbg2XQSGPUdInA-bXukYxQ4aHw
		else:
			if len(haq1bHZINPE58uoBFnKfTSO2ik4)==bXukYxQ4aHw: OODLkJlZCoKmrzbg2XQSGPUdInA = ybdv7XcT3lxF6QezULwCAGk
			else: OODLkJlZCoKmrzbg2XQSGPUdInA = Eb7qJoNwOgn(onvmDiWftdbAYZBTjsu,haq1bHZINPE58uoBFnKfTSO2ik4)
			start,end = OODLkJlZCoKmrzbg2XQSGPUdInA,OODLkJlZCoKmrzbg2XQSGPUdInA
		if OODLkJlZCoKmrzbg2XQSGPUdInA==-bXukYxQ4aHw:
			IRlka04VtyGe9hjbU7rpZSwCM5z = dv0trJR7PwmKyxDYO52VLau8gEph(u"࠭ࡣࡢࡰࡦࡩࡱ࡫ࡤࠨ᫋")
			break
		if Ij1hXVRiAJ:
			IRlka04VtyGe9hjbU7rpZSwCM5z = GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠧࡳࡧࡶࡳࡱࡼࡥࡥࡡࡲࡲࡪ࠭ᫌ")
			LRmiAODQ7szSVke29FHapMP0u = sspH0IwZRTLhg921Cd4QBjJDXWa([haq1bHZINPE58uoBFnKfTSO2ik4[start]],[Dvi8asSrQYX5wE3KMIxT91me[start]],source,VBlawK4mgHSyLEn8iqhUkz5)
			title,llxFwq0CUNgQtivJzkHeGV,pxdY8tiazyJIq,LHN1Zr7FDtbYfjz069Gnh,m4IznKilUOByHweG68VJ = LRmiAODQ7szSVke29FHapMP0u[ybdv7XcT3lxF6QezULwCAGk]
			qUjPtfo7ehkg5bsQyHrBm3Taxc0,B3gkYpFNEJdzq4MSOm216jXHPx75yG = ycPJD2wxaS09Mr86eN5stQG7vd1(title,llxFwq0CUNgQtivJzkHeGV,LHN1Zr7FDtbYfjz069Gnh,m4IznKilUOByHweG68VJ,source,X3X4Y8RzxSVfZJUFDe)
			if qUjPtfo7ehkg5bsQyHrBm3Taxc0 in [KNIvHPjUbhr(u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦ࡬ࡲ࡬࠭ᫍ"),QVDJLRlxNg127jMX(u"ࠩࡳࡰࡦࡿࡩ࡯ࡩࠪᫎ"),A6dMB1FlgxVivJ2fk9C(u"ࠪࡸࡪࡹࡴࡪࡰࡪࠫ᫏")]:
				qjvQn208uWwa7esSKgbHMx = VBlawK4mgHSyLEn8iqhUkz5
				break
			else:
				if not pxdY8tiazyJIq: pxdY8tiazyJIq = LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"࡛ࠫ࡯ࡤࡦࡱࠣࡴࡱࡧࡹࠡࡨࡤ࡭ࡱ࡫ࡤࠨ᫐")
				title = hXB0vKVQ5PRI91SDTprMdfuHEm4+title+YYSh2J6BIrsm8
				LRmiAODQ7szSVke29FHapMP0u[ybdv7XcT3lxF6QezULwCAGk] = title,llxFwq0CUNgQtivJzkHeGV,pxdY8tiazyJIq,LHN1Zr7FDtbYfjz069Gnh,m4IznKilUOByHweG68VJ
				dPHyIh5OMAfGXxcBbC9p = llxFwq0CUNgQtivJzkHeGV.split(wwPrSDa21lUh(u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭᫑"),bXukYxQ4aHw)[ybdv7XcT3lxF6QezULwCAGk]
				pMPR1Cc0usZ6nJTU(MM5Dx39f7ULhcJsRptzIowP,zyvJMtBhrw(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡄࡠࡕࡘࡇࡈࡋࡅࡅࡇࡇࠫ᫒"),dPHyIh5OMAfGXxcBbC9p)
				BxuD7iQRpW1(MM5Dx39f7ULhcJsRptzIowP,e2qDYgipPmTw4KvBLnochr(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡅࡡࡉࡅࡎࡒࡅࡅࠩ᫓"),dPHyIh5OMAfGXxcBbC9p,[pxdY8tiazyJIq,title,llxFwq0CUNgQtivJzkHeGV],KqO5BWGQR9JVL)
			if pxdY8tiazyJIq==sULh4NjakzI8He7xJCMGrql(u"ࠨࡇ࡛ࡍ࡙ࡥࡁࡍࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭᫔"): break
			JfL7eGPh5izVyORaNCjBASvtYd8MUk = NeO3CTLHrPfWUoIgy8Q(u"ࠩ࡞ࡐࡊࡌࡔ࡞ࠢࠣࠫ᫕")+pxdY8tiazyJIq.replace(NXMOzZjYsmS9pf,CnbBKmtF1x84q7AW(u"ࠪࡠࡳࡡࡌࡆࡈࡗࡡࠥࠦࠧ᫖")) if pxdY8tiazyJIq.count(NXMOzZjYsmS9pf)>A6dMB1FlgxVivJ2fk9C(u"࠵ॿ") else NXMOzZjYsmS9pf+pxdY8tiazyJIq
			if o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬ᫗") not in source: BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,QVDJLRlxNg127jMX(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ᫘"),KBkxSYaz93pu1(u"࠭วๅีํีๆืࠠๅ็ࠣ๎฾๋ไࠡฮิฬู๊ࠥาใิࠤ฿๐ั่ࠩ᫙")+NXMOzZjYsmS9pf+JfL7eGPh5izVyORaNCjBASvtYd8MUk,profile=EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠧࡤࡱࡱࡪ࡮ࡸ࡭ࡠ࡯ࡨࡨ࡮ࡻ࡭ࡧࡱࡱࡸࠬ᫚"))
			if len(Dvi8asSrQYX5wE3KMIxT91me)==bXukYxQ4aHw and pxdY8tiazyJIq: break
		for XK2iWMx6yfU9E in range(start,end+bXukYxQ4aHw):
			LTnOlzQwe31YruXxv = ybdv7XcT3lxF6QezULwCAGk if Ij1hXVRiAJ else XK2iWMx6yfU9E
			title,llxFwq0CUNgQtivJzkHeGV,pxdY8tiazyJIq,LHN1Zr7FDtbYfjz069Gnh,m4IznKilUOByHweG68VJ = LRmiAODQ7szSVke29FHapMP0u[LTnOlzQwe31YruXxv]
			haq1bHZINPE58uoBFnKfTSO2ik4[XK2iWMx6yfU9E] = haq1bHZINPE58uoBFnKfTSO2ik4[XK2iWMx6yfU9E].replace(hXB0vKVQ5PRI91SDTprMdfuHEm4,hWGMqtBy4wuLaVcj).replace(tsBed5hpnEXTRG0u3U8KYlDfW1j,hWGMqtBy4wuLaVcj).replace(YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj)
			if pxdY8tiazyJIq: haq1bHZINPE58uoBFnKfTSO2ik4[XK2iWMx6yfU9E] = hXB0vKVQ5PRI91SDTprMdfuHEm4+haq1bHZINPE58uoBFnKfTSO2ik4[XK2iWMx6yfU9E]+YYSh2J6BIrsm8
			else: haq1bHZINPE58uoBFnKfTSO2ik4[XK2iWMx6yfU9E] = tsBed5hpnEXTRG0u3U8KYlDfW1j+haq1bHZINPE58uoBFnKfTSO2ik4[XK2iWMx6yfU9E]+YYSh2J6BIrsm8
	if IRlka04VtyGe9hjbU7rpZSwCM5z==dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠨࡰࡲࡸࡤࡸࡥࡴࡱ࡯ࡺࡦࡨ࡬ࡦࠩ᫛"): BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,CnbBKmtF1x84q7AW(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ᫜"),LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"่้ࠪษำโࠢ็หࠥ๐่อัࠣื๏ืแาษอࠤั๐ฯสࠢไ๎ࠥํะศࠢส่ๆ๐ฯ๋๊ࠣ࠲࠳ࠦอศ๊็ࠤศ์ࠠหสะฯࠥ฿ๆ้ࠡำหࠥอไโ์า๎ํࠦแ๋่ࠢ์ฬู่ࠡลัี๎ࠦแ๋๊ࠢิฬࠦวๅสิ๊ฬ๋ฬࠨ᫝"))
	if not qjvQn208uWwa7esSKgbHMx or IRlka04VtyGe9hjbU7rpZSwCM5z in [QvgnCALNstmuUJiET(u"ࠫࡨࡧ࡮ࡤࡧ࡯ࡩࡩ࠭᫞"),CnbBKmtF1x84q7AW(u"ࠬࡴ࡯ࡵࡡࡵࡩࡸࡵ࡬ࡷࡣࡥࡰࡪ࠭᫟")] or pxdY8tiazyJIq:
		ayNEJoZrebx2usT = MMk8qKvcJe4fQHm3EG7diBD5.executeJSONRPC(ITvnUAMXsyb4eO(u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥ࡭ࡩࠨ࠺࠲࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡖ࡬ࡢࡻ࡯࡭ࡸࡺ࠮ࡄ࡮ࡨࡥࡷࠨࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡵࡲࡡࡺ࡮࡬ࡷࡹ࡯ࡤࠣ࠼࠴ࢁࢂ࠭᫠"))
	return
JJlKIRGv1c,T03fZ7nY8rK,vUmF65ohOgitZ,atWRpJ3k4ecA7oVwDY2h6nG,Bwcj5eNQWaTSI74dUnJCGfHxbRLE,Jw69q5XzakmHv70BYuOE = [],[],[],[],[],[]
def sspH0IwZRTLhg921Cd4QBjJDXWa(HHAWYIZauqLrJBitcneTljf7,zmDKurMJwj6fi,source,showDialogs):
	global JJlKIRGv1c,T03fZ7nY8rK,vUmF65ohOgitZ,atWRpJ3k4ecA7oVwDY2h6nG,Bwcj5eNQWaTSI74dUnJCGfHxbRLE,Jw69q5XzakmHv70BYuOE
	N6NCYivtV4I5rEXq,tqJIXKu94LDPsiMHVQS,new = [],[],[]
	PEgHa6TQ94mRGvDipcw5LsZfKzh(fEXMiAyG3ql4vKB,fEXMiAyG3ql4vKB,fEXMiAyG3ql4vKB)
	count = len(zmDKurMJwj6fi)
	for dV8hf3cYkFXZ2InK1jJzoiN9aquw7x in range(count):
		JJlKIRGv1c.append(None)
		T03fZ7nY8rK.append(None)
		vUmF65ohOgitZ.append(None)
		atWRpJ3k4ecA7oVwDY2h6nG.append(None)
		Bwcj5eNQWaTSI74dUnJCGfHxbRLE.append(None)
		Jw69q5XzakmHv70BYuOE.append(ybdv7XcT3lxF6QezULwCAGk)
		title = HHAWYIZauqLrJBitcneTljf7[dV8hf3cYkFXZ2InK1jJzoiN9aquw7x]
		llxFwq0CUNgQtivJzkHeGV = zmDKurMJwj6fi[dV8hf3cYkFXZ2InK1jJzoiN9aquw7x].strip(Mpsm2VF1OBnCRvK3qf6).strip(QvgnCALNstmuUJiET(u"ࠧࠧࠩ᫡")).strip(DJ1ICpbyR2(u"ࠨࡁࠪ᫢")).strip(mkHKSQvjWr5BTcM3wVY(u"ࠩ࠲ࠫ᫣"))
		if count>bXukYxQ4aHw and showDialogs: OnsAxhdVjZF(mkHKSQvjWr5BTcM3wVY(u"ࠪๅา฻ࠠิ์ิๅึࠦัใ็ࠣࠤࠬ᫤")+str(dV8hf3cYkFXZ2InK1jJzoiN9aquw7x+CnbBKmtF1x84q7AW(u"࠴ঀ")),title)
		DIAof80M6QmlkpOwNycie79 = [XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬ᫥"),S1SgCFYGJeMvfp5iZXK(u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐࠪ᫦"),jeAby54c02TgG8zuivonX91(u"࠭ࡁࡌ࡙ࡄࡑࠬ᫧")]
		if source in DIAof80M6QmlkpOwNycie79: JJlKIRGv1c[dV8hf3cYkFXZ2InK1jJzoiN9aquw7x] = gG3w1FjbtHTDZV6UsmvKXA28EcfWN(title,llxFwq0CUNgQtivJzkHeGV,source,dV8hf3cYkFXZ2InK1jJzoiN9aquw7x)
		else:
			if QvgnCALNstmuUJiET(u"࠵ঁ"):
				uwVihCK0N73EYTAJ = KCTRe67wVy.Thread(target=gG3w1FjbtHTDZV6UsmvKXA28EcfWN,args=(title,llxFwq0CUNgQtivJzkHeGV,source,dV8hf3cYkFXZ2InK1jJzoiN9aquw7x))
				uwVihCK0N73EYTAJ.start()
				tqJIXKu94LDPsiMHVQS.append(uwVihCK0N73EYTAJ)
				new.append(dV8hf3cYkFXZ2InK1jJzoiN9aquw7x)
				HB5PvxRhwM.sleep(ITvnUAMXsyb4eO(u"࠶ং"))
	timeout = NeO3CTLHrPfWUoIgy8Q(u"࠼࠰ঃ") if source==EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠧࡂࡍ࡚ࡅࡒ࠭᫨") else KNIvHPjUbhr(u"࠳࠱঄")
	pp9oFfEkKX74znPZ = HB5PvxRhwM.time()
	for uwVihCK0N73EYTAJ in tqJIXKu94LDPsiMHVQS: uwVihCK0N73EYTAJ.join(timeout)
	for dV8hf3cYkFXZ2InK1jJzoiN9aquw7x in range(count):
		title = HHAWYIZauqLrJBitcneTljf7[dV8hf3cYkFXZ2InK1jJzoiN9aquw7x]
		llxFwq0CUNgQtivJzkHeGV = zmDKurMJwj6fi[dV8hf3cYkFXZ2InK1jJzoiN9aquw7x].strip(Mpsm2VF1OBnCRvK3qf6).strip(o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠨࠨࠪ᫩")).strip(FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠩࡂࠫ᫪")).strip(DJ1ICpbyR2(u"ࠪ࠳ࠬ᫫"))
		tA2nTBHodPFiOhV87j = VBlawK4mgHSyLEn8iqhUkz5 if Jw69q5XzakmHv70BYuOE[dV8hf3cYkFXZ2InK1jJzoiN9aquw7x]+bXukYxQ4aHw>timeout else fEXMiAyG3ql4vKB
		if JJlKIRGv1c[dV8hf3cYkFXZ2InK1jJzoiN9aquw7x] and len(JJlKIRGv1c[dV8hf3cYkFXZ2InK1jJzoiN9aquw7x])==zyvJMtBhrw(u"࠴অ") and (JJlKIRGv1c[dV8hf3cYkFXZ2InK1jJzoiN9aquw7x][ybdv7XcT3lxF6QezULwCAGk] or JJlKIRGv1c[dV8hf3cYkFXZ2InK1jJzoiN9aquw7x][Y0XZKGRAUQj5O]): JfL7eGPh5izVyORaNCjBASvtYd8MUk,m4eVoJdSU51qs3y8Gg06fZNau7A,MDSF21x9HK3AZyGUhcb = JJlKIRGv1c[dV8hf3cYkFXZ2InK1jJzoiN9aquw7x]
		elif tA2nTBHodPFiOhV87j: JfL7eGPh5izVyORaNCjBASvtYd8MUk,m4eVoJdSU51qs3y8Gg06fZNau7A,MDSF21x9HK3AZyGUhcb = XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠫࡋࡧࡩ࡭ࡧࡧ࠾ࠥࠦࡔࡪ࡯ࡨࡨࠥࡕࡵࡵࠢࠫࠫ᫬")+str(timeout)+ITvnUAMXsyb4eO(u"ࠬࠦࡳࡦࡥࡲࡲࡩࡹࠩࠨ᫭"),[],[]
		else: JfL7eGPh5izVyORaNCjBASvtYd8MUk,m4eVoJdSU51qs3y8Gg06fZNau7A,MDSF21x9HK3AZyGUhcb = QvgnCALNstmuUJiET(u"࠭ࡆࡢ࡫࡯ࡩࡩࡀࠠࠡࡅࡲࡹࡱࡪࠠ࡯ࡱࡷࠤ࡫࡯࡮ࡥࠢࡷ࡬ࡪࠦࡶࡪࡦࡨࡳࠥ࡬ࡩ࡭ࡧࠪ᫮"),[],[]
		N6NCYivtV4I5rEXq.append([title,llxFwq0CUNgQtivJzkHeGV,JfL7eGPh5izVyORaNCjBASvtYd8MUk,m4eVoJdSU51qs3y8Gg06fZNau7A,MDSF21x9HK3AZyGUhcb])
		if dV8hf3cYkFXZ2InK1jJzoiN9aquw7x in new:
			dPHyIh5OMAfGXxcBbC9p = llxFwq0CUNgQtivJzkHeGV.split(NeO3CTLHrPfWUoIgy8Q(u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ᫯"),bXukYxQ4aHw)[ybdv7XcT3lxF6QezULwCAGk]
			if not JfL7eGPh5izVyORaNCjBASvtYd8MUk: BxuD7iQRpW1(MM5Dx39f7ULhcJsRptzIowP,LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡆࡢࡗ࡚ࡉࡃࡆࡇࡇࡉࡉ࠭᫰"),dPHyIh5OMAfGXxcBbC9p,[JfL7eGPh5izVyORaNCjBASvtYd8MUk,m4eVoJdSU51qs3y8Gg06fZNau7A,MDSF21x9HK3AZyGUhcb],KqO5BWGQR9JVL)
			else: BxuD7iQRpW1(MM5Dx39f7ULhcJsRptzIowP,LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡇࡣࡋࡇࡉࡍࡇࡇࠫ᫱"),dPHyIh5OMAfGXxcBbC9p,[JfL7eGPh5izVyORaNCjBASvtYd8MUk,m4eVoJdSU51qs3y8Gg06fZNau7A,MDSF21x9HK3AZyGUhcb],KqO5BWGQR9JVL)
	PEgHa6TQ94mRGvDipcw5LsZfKzh(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj)
	return N6NCYivtV4I5rEXq
def gG3w1FjbtHTDZV6UsmvKXA28EcfWN(SODQ7qlNYoZcFK8e50rBsJaAHxiXjE,url,source,oa4HOCVwS1cgB9h5DfAvp8):
	global JJlKIRGv1c,Jw69q5XzakmHv70BYuOE
	Jw69q5XzakmHv70BYuOE[oa4HOCVwS1cgB9h5DfAvp8] = ybdv7XcT3lxF6QezULwCAGk
	pp9oFfEkKX74znPZ = HB5PvxRhwM.time()
	KteLZCbM8W0FqE2OBx1(YYcbiF1UROXlga2,qhVEWvetzXLOcr1(xjPuFK3EsIZSiobQ5X)+CnbBKmtF1x84q7AW(u"ࠪࠤࠥࠦࡒࡦࡵࡲࡰࡻ࡯࡮ࡨࠢࡶࡸࡦࡸࡴࡦࡦࠣࠤ࡙ࠥࡥ࡭ࡧࡦࡸࡪࡪ࠺ࠡ࡝ࠣࠫ᫲")+SODQ7qlNYoZcFK8e50rBsJaAHxiXjE+dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠫࠥࡣࠠࠡࠢࡒࡶ࡮࡭ࡩ࡯ࡣ࡯࠾ࠥࡡࠠࠨ᫳")+url+hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠬࠦ࡝ࠨ᫴"))
	llxFwq0CUNgQtivJzkHeGV,CgLzZUVKfjWNYHMp = url,hWGMqtBy4wuLaVcj
	BzcFfrqi4gtUnjIvOaLD = sULh4NjakzI8He7xJCMGrql(u"࠭ࡉࡏࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࠪ᫵")
	pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = qRFyIG9WZLCEpgeD3hukMYB(url,source)
	if pxdY8tiazyJIq==jeAby54c02TgG8zuivonX91(u"ࠧࡆ࡚ࡌࡘࡤࡇࡌࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ᫶"):
		JJlKIRGv1c[oa4HOCVwS1cgB9h5DfAvp8] = A6dMB1FlgxVivJ2fk9C(u"ࠨࡇ࡛ࡍ࡙ࡥࡁࡍࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭᫷"),[],[]
		Jw69q5XzakmHv70BYuOE[oa4HOCVwS1cgB9h5DfAvp8] = HB5PvxRhwM.time()-pp9oFfEkKX74znPZ
		return JJlKIRGv1c[oa4HOCVwS1cgB9h5DfAvp8]
	elif zyvJMtBhrw(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ᫸") in pxdY8tiazyJIq:
		CgLzZUVKfjWNYHMp = rwQN9AKhLCuMfHxjlbX0U(u"ࠪࡠࡳࡘࡥࡴࡱ࡯ࡺࡪࡸࠠ࠲࠼ࠣࠤࡓ࡫ࡥࡥࠢࡈࡼࡹ࡫ࡲ࡯ࡣ࡯ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷ࠭᫹")
		llxFwq0CUNgQtivJzkHeGV = VqfNpHPEahjCsto8uJSweTYOF36(Dvi8asSrQYX5wE3KMIxT91me)[ybdv7XcT3lxF6QezULwCAGk]
		BzcFfrqi4gtUnjIvOaLD,CgLzZUVKfjWNYHMp,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = AAQIEtp1X3(CgLzZUVKfjWNYHMp,llxFwq0CUNgQtivJzkHeGV,source,oa4HOCVwS1cgB9h5DfAvp8)
		if CgLzZUVKfjWNYHMp==MMizeNH0AKu(u"ࠫࡊ࡞ࡉࡕࡡࡄࡐࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ᫺"):
			Jw69q5XzakmHv70BYuOE[oa4HOCVwS1cgB9h5DfAvp8] = HB5PvxRhwM.time()-pp9oFfEkKX74znPZ
			return CgLzZUVKfjWNYHMp,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me
	elif pxdY8tiazyJIq: CgLzZUVKfjWNYHMp = SqrG5mU3j96ldsFpExobw40TJY(u"ࠬࡘࡥࡴࡱ࡯ࡺࡪࡸࠠ࠲࠼ࠣࠤࠬ᫻")+pxdY8tiazyJIq.replace(NXMOzZjYsmS9pf,hWGMqtBy4wuLaVcj).replace(y6eSQlZEV8uwKG5M3,hWGMqtBy4wuLaVcj)[:KNIvHPjUbhr(u"࠺࠳আ")]
	if Dvi8asSrQYX5wE3KMIxT91me:
		Dvi8asSrQYX5wE3KMIxT91me = VqfNpHPEahjCsto8uJSweTYOF36(Dvi8asSrQYX5wE3KMIxT91me)
		KteLZCbM8W0FqE2OBx1(YYcbiF1UROXlga2,qhVEWvetzXLOcr1(xjPuFK3EsIZSiobQ5X)+sULh4NjakzI8He7xJCMGrql(u"࠭ࠠࠡࠢࡕࡩࡸࡵ࡬ࡷ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡩࡩ࡫ࡤࠡࠢࠣࡗࡪࡲࡥࡤࡶࡨࡨ࠿࡛ࠦࠡࠩ᫼")+SODQ7qlNYoZcFK8e50rBsJaAHxiXjE+sULh4NjakzI8He7xJCMGrql(u"ࠧࠡ࡟ࠣࠤࠥࡘࡥࡴࡱ࡯ࡺࡪࡸ࠺ࠡ࡝ࠣࠫ᫽")+BzcFfrqi4gtUnjIvOaLD+zyvJMtBhrw(u"ࠨࠢࡠࠤࠥࠦࡏࡳ࡫ࡪ࡭ࡳࡧ࡬࠻ࠢ࡞ࠤࠬ᫾")+url+DJ1ICpbyR2(u"ࠩࠣࡡࠥࠦࠠࡍ࡫ࡱ࡯࠿࡛ࠦࠡࠩ᫿")+llxFwq0CUNgQtivJzkHeGV+SqrG5mU3j96ldsFpExobw40TJY(u"ࠪࠤࡢࠦࠠࠡࡘ࡬ࡨࡪࡵࡳ࠻ࠢ࡞ࠤࠬᬀ")+str(Dvi8asSrQYX5wE3KMIxT91me)+mkHKSQvjWr5BTcM3wVY(u"ࠫࠥࡣࠧᬁ"))
	else: KteLZCbM8W0FqE2OBx1(YYcbiF1UROXlga2,qhVEWvetzXLOcr1(xjPuFK3EsIZSiobQ5X)+OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠬࠦࠠࠡࡔࡨࡷࡴࡲࡶࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧࠤࠥࠦࡓࡦ࡮ࡨࡧࡹ࡫ࡤ࠻ࠢ࡞ࠤࠬᬂ")+SODQ7qlNYoZcFK8e50rBsJaAHxiXjE+e2qDYgipPmTw4KvBLnochr(u"࠭ࠠ࡞ࠢࠣࠤࡔࡸࡩࡨ࡫ࡱࡥࡱࡀࠠ࡜ࠢࠪᬃ")+url+SqrG5mU3j96ldsFpExobw40TJY(u"ࠧࠡ࡟ࠣࠤࠥࡒࡩ࡯࡭࠽ࠤࡠࠦࠧᬄ")+llxFwq0CUNgQtivJzkHeGV+mkHKSQvjWr5BTcM3wVY(u"ࠨࠢࡠࠤࠥࠦࡅࡳࡴࡲࡶࡸࡀࠠ࡜ࠢࠪᬅ")+CgLzZUVKfjWNYHMp+MMizeNH0AKu(u"ࠩࠣࡡࠬᬆ"))
	CgLzZUVKfjWNYHMp = jkiCS0UWs2dNAJcGKn6mbHD(CgLzZUVKfjWNYHMp)
	JJlKIRGv1c[oa4HOCVwS1cgB9h5DfAvp8] = CgLzZUVKfjWNYHMp,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me
	Jw69q5XzakmHv70BYuOE[oa4HOCVwS1cgB9h5DfAvp8] = HB5PvxRhwM.time()-pp9oFfEkKX74znPZ
	return CgLzZUVKfjWNYHMp,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me
def ycPJD2wxaS09Mr86eN5stQG7vd1(title,llxFwq0CUNgQtivJzkHeGV,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me,source,X3X4Y8RzxSVfZJUFDe=hWGMqtBy4wuLaVcj):
	if Dvi8asSrQYX5wE3KMIxT91me:
		while VBlawK4mgHSyLEn8iqhUkz5:
			if len(Dvi8asSrQYX5wE3KMIxT91me)==bXukYxQ4aHw: OODLkJlZCoKmrzbg2XQSGPUdInA = ybdv7XcT3lxF6QezULwCAGk
			else: OODLkJlZCoKmrzbg2XQSGPUdInA = Eb7qJoNwOgn(NeO3CTLHrPfWUoIgy8Q(u"ࠪหำะัࠡษ็้้็ࠠศๆ่๊ฬูศ࠻ࠩᬇ"), haq1bHZINPE58uoBFnKfTSO2ik4)
			if OODLkJlZCoKmrzbg2XQSGPUdInA==-bXukYxQ4aHw: FEpnOiHwDL6soV9 = LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠫࡨࡧ࡮ࡤࡧ࡯ࡩࡩ࠭ᬈ")
			else:
				hOUuk7VRfYxcM = Dvi8asSrQYX5wE3KMIxT91me[OODLkJlZCoKmrzbg2XQSGPUdInA]
				KteLZCbM8W0FqE2OBx1(YYcbiF1UROXlga2,qhVEWvetzXLOcr1(xjPuFK3EsIZSiobQ5X)+JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠬࠦࠠࠡࡒ࡯ࡥࡾ࡯࡮ࡨࠢࡶࡸࡦࡸࡴࡦࡦࠣࠤ࡙ࠥࡥ࡭ࡧࡦࡸࡪࡪ࠺ࠡ࡝ࠣࠫᬉ")+title+MMizeNH0AKu(u"࠭ࠠ࡞ࠢࠣࠤࡔࡸࡩࡨ࡫ࡱࡥࡱࡀࠠ࡜ࠢࠪᬊ")+llxFwq0CUNgQtivJzkHeGV+DJ1ICpbyR2(u"ࠧࠡ࡟ࠣࠤࠥ࡜ࡩࡥࡧࡲ࠾ࠥࡡࠠࠨᬋ")+str(hOUuk7VRfYxcM)+jeAby54c02TgG8zuivonX91(u"ࠨࠢࡠࠫᬌ"))
				if SqrG5mU3j96ldsFpExobw40TJY(u"ࠩࡰࡳࡸ࡮ࡡࡩࡦࡤ࠲ࠬᬍ") in hOUuk7VRfYxcM and o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠪࡨࡴࡽ࡮࡭ࡱࡤࡨࡤࡵࡲࡪࡩࠪᬎ") in hOUuk7VRfYxcM:
					JfL7eGPh5izVyORaNCjBASvtYd8MUk,H7wAinr4f3M8oPDFsdkIZ,bQV1Gtm49uZJshH3nWXLPTYrME = XM70EwYa4t2PcFKV6mHxd(hOUuk7VRfYxcM)
					if bQV1Gtm49uZJshH3nWXLPTYrME: hOUuk7VRfYxcM = bQV1Gtm49uZJshH3nWXLPTYrME[ybdv7XcT3lxF6QezULwCAGk]
					else: hOUuk7VRfYxcM = hWGMqtBy4wuLaVcj
				if not hOUuk7VRfYxcM: FEpnOiHwDL6soV9 = HHoGx7Flus60(u"ࠫࡺࡴࡲࡦࡵࡲࡰࡻ࡫ࡤࠨᬏ")
				else: FEpnOiHwDL6soV9 = vOq38Y4XVZwdE(hOUuk7VRfYxcM,source,X3X4Y8RzxSVfZJUFDe)
			if FEpnOiHwDL6soV9 in [mkHKSQvjWr5BTcM3wVY(u"ࠬࡶ࡬ࡢࡻ࡬ࡲ࡬࠭ᬐ"),XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"࠭ࡴࡦࡵࡷ࡭ࡳ࡭ࠧᬑ"),KBkxSYaz93pu1(u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥ࡫ࡱ࡫ࠬᬒ"),xcChIL13BpR8WArNt9Pl0So(u"ࠨࡥࡤࡲࡨ࡫࡬ࡦࡦࠪᬓ")] or len(Dvi8asSrQYX5wE3KMIxT91me)==SqrG5mU3j96ldsFpExobw40TJY(u"࠴ই"): break
			elif FEpnOiHwDL6soV9 in [rwQN9AKhLCuMfHxjlbX0U(u"ࠩࡩࡥ࡮ࡲࡥࡥࠩᬔ"),MMizeNH0AKu(u"ࠪࡸ࡮ࡳࡥࡰࡷࡷࠫᬕ"),rwQN9AKhLCuMfHxjlbX0U(u"ࠫࡹࡸࡩࡦࡦࠪᬖ")]: break
			else: BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,zyvJMtBhrw(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᬗ"),MMizeNH0AKu(u"࠭วๅ็็ๅ๊ࠥๅࠡ์฼้้ࠦฬาส้้ࠣ็ࠠ฻์ิ๋ࠬᬘ"))
	else:
		FEpnOiHwDL6soV9 = jeAby54c02TgG8zuivonX91(u"ࠧࡶࡰࡵࡩࡸࡵ࡬ࡷࡧࡧࠫᬙ")
		if UGBbEtrcu5jLC6Sxoa3gFyP1mJOpW(llxFwq0CUNgQtivJzkHeGV): FEpnOiHwDL6soV9 = vOq38Y4XVZwdE(llxFwq0CUNgQtivJzkHeGV,source,X3X4Y8RzxSVfZJUFDe)
	return FEpnOiHwDL6soV9,Dvi8asSrQYX5wE3KMIxT91me
def rRuhPX9pf1(url,source):
	NPM3HKQ57xe,cg4sWVnezK0rxBoTNtE,SODQ7qlNYoZcFK8e50rBsJaAHxiXjE,Va9G0tDyKZfd3O75,j4lHpxXvnF2VtwBb1T9PaJEm3,X3X4Y8RzxSVfZJUFDe,QWz1jXGo6ruOitUMqET7yI5,QS8ZdxkHD5bjU9qsn4zMYaPrg3h7,JPl40rDFqybV9H2Wxi1 = url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj
	if SqrG5mU3j96ldsFpExobw40TJY(u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩᬚ") in url:
		NPM3HKQ57xe,cg4sWVnezK0rxBoTNtE = url.split(LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪᬛ"),bXukYxQ4aHw)
		cg4sWVnezK0rxBoTNtE = cg4sWVnezK0rxBoTNtE+jeAby54c02TgG8zuivonX91(u"ࠪࡣࡤ࠭ᬜ")+LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠫࡤࡥࠧᬝ")+gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠬࡥ࡟ࠨᬞ")+wwPrSDa21lUh(u"࠭࡟ࡠࠩᬟ")+KNIvHPjUbhr(u"ࠧࡠࡡࠪᬠ")
		j4lHpxXvnF2VtwBb1T9PaJEm3,X3X4Y8RzxSVfZJUFDe,QWz1jXGo6ruOitUMqET7yI5,QS8ZdxkHD5bjU9qsn4zMYaPrg3h7,JPl40rDFqybV9H2Wxi1,s93uy4YSpalAxZ2rQ, = cg4sWVnezK0rxBoTNtE.split(e2qDYgipPmTw4KvBLnochr(u"ࠨࡡࡢࠫᬡ"))[:HHoGx7Flus60(u"࠺ঈ")]
	if not QS8ZdxkHD5bjU9qsn4zMYaPrg3h7: QS8ZdxkHD5bjU9qsn4zMYaPrg3h7 = HHoGx7Flus60(u"ࠩ࠳ࠫᬢ")
	else: QS8ZdxkHD5bjU9qsn4zMYaPrg3h7 = QS8ZdxkHD5bjU9qsn4zMYaPrg3h7.replace(MMizeNH0AKu(u"ࠪࡴࠬᬣ"),hWGMqtBy4wuLaVcj).replace(Mpsm2VF1OBnCRvK3qf6,hWGMqtBy4wuLaVcj)
	NPM3HKQ57xe = NPM3HKQ57xe.strip(ITvnUAMXsyb4eO(u"ࠫࡄ࠭ᬤ")).strip(hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠬ࠵ࠧᬥ")).strip(gDuGMR3z1aV6YdLmCpiO8Kl(u"࠭ࠦࠨᬦ"))
	SODQ7qlNYoZcFK8e50rBsJaAHxiXjE = RRNODILCtGzvgpx(NPM3HKQ57xe,rwQN9AKhLCuMfHxjlbX0U(u"ࠧࡩࡱࡶࡸࠬᬧ"))
	if j4lHpxXvnF2VtwBb1T9PaJEm3: Va9G0tDyKZfd3O75 = j4lHpxXvnF2VtwBb1T9PaJEm3
	else: Va9G0tDyKZfd3O75 = SODQ7qlNYoZcFK8e50rBsJaAHxiXjE
	Va9G0tDyKZfd3O75 = RRNODILCtGzvgpx(Va9G0tDyKZfd3O75,hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠨࡰࡤࡱࡪ࠭ᬨ"))
	j4lHpxXvnF2VtwBb1T9PaJEm3 = j4lHpxXvnF2VtwBb1T9PaJEm3.replace(FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"่ࠩฬฬฺัࠨᬩ"),hWGMqtBy4wuLaVcj).replace(NeO3CTLHrPfWUoIgy8Q(u"ࠪื๏ืแาࠩᬪ"),hWGMqtBy4wuLaVcj).replace(zyvJMtBhrw(u"ࠫฬ๊ࠠࠨᬫ"),Mpsm2VF1OBnCRvK3qf6).replace(FqcVAkh7WjIXHdDKf8nvuyRo,Mpsm2VF1OBnCRvK3qf6)
	cg4sWVnezK0rxBoTNtE = cg4sWVnezK0rxBoTNtE.replace(sULh4NjakzI8He7xJCMGrql(u"๋ࠬศศึิࠫᬬ"),hWGMqtBy4wuLaVcj).replace(dv0trJR7PwmKyxDYO52VLau8gEph(u"࠭ำ๋ำไีࠬᬭ"),hWGMqtBy4wuLaVcj).replace(S1SgCFYGJeMvfp5iZXK(u"ࠧศๆࠣࠫᬮ"),Mpsm2VF1OBnCRvK3qf6).replace(FqcVAkh7WjIXHdDKf8nvuyRo,Mpsm2VF1OBnCRvK3qf6)
	Va9G0tDyKZfd3O75 = Va9G0tDyKZfd3O75.replace(HHoGx7Flus60(u"ࠨ็หหูืࠧᬯ"),hWGMqtBy4wuLaVcj).replace(FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠩึ๎ึ็ัࠨᬰ"),hWGMqtBy4wuLaVcj).replace(KNIvHPjUbhr(u"ࠪห้ࠦࠧᬱ"),Mpsm2VF1OBnCRvK3qf6).replace(FqcVAkh7WjIXHdDKf8nvuyRo,Mpsm2VF1OBnCRvK3qf6)
	return NPM3HKQ57xe,cg4sWVnezK0rxBoTNtE,SODQ7qlNYoZcFK8e50rBsJaAHxiXjE,Va9G0tDyKZfd3O75,j4lHpxXvnF2VtwBb1T9PaJEm3,X3X4Y8RzxSVfZJUFDe,QWz1jXGo6ruOitUMqET7yI5,QS8ZdxkHD5bjU9qsn4zMYaPrg3h7,JPl40rDFqybV9H2Wxi1
def YWceERXKbadhot(url,source):
	SbMcjF0nldxBVGIqWQg7O,j4lHpxXvnF2VtwBb1T9PaJEm3,IfUQDu4t1gGAJpoB,ozdcawTZsVbmUGl,KDOnA5puvt8kTMjmb,xx5hZtqweGJvXNYFCsji8027,BzcFfrqi4gtUnjIvOaLD = hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,None,None,None,None,None
	NPM3HKQ57xe,cg4sWVnezK0rxBoTNtE,SODQ7qlNYoZcFK8e50rBsJaAHxiXjE,Va9G0tDyKZfd3O75,j4lHpxXvnF2VtwBb1T9PaJEm3,X3X4Y8RzxSVfZJUFDe,QWz1jXGo6ruOitUMqET7yI5,QS8ZdxkHD5bjU9qsn4zMYaPrg3h7,JPl40rDFqybV9H2Wxi1 = rRuhPX9pf1(url,source)
	if hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬᬲ") in url:
		if   X3X4Y8RzxSVfZJUFDe==wwPrSDa21lUh(u"ࠬ࡫࡭ࡣࡧࡧࠫᬳ"): X3X4Y8RzxSVfZJUFDe = Mpsm2VF1OBnCRvK3qf6+KNIvHPjUbhr(u"࠭ๅโุ็᬴ࠫ")
		elif X3X4Y8RzxSVfZJUFDe==LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠧࡸࡣࡷࡧ࡭࠭ᬵ"): X3X4Y8RzxSVfZJUFDe = Mpsm2VF1OBnCRvK3qf6+gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠨุ่ࠧฬํฯสࠩᬶ")
		elif X3X4Y8RzxSVfZJUFDe==SqrG5mU3j96ldsFpExobw40TJY(u"ࠩࡥࡳࡹ࡮ࠧᬷ"): X3X4Y8RzxSVfZJUFDe = Mpsm2VF1OBnCRvK3qf6+EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"๋ࠪࠩࠪิศ้าอࠥ๎สฮ็ํ่ࠬᬸ")
		elif X3X4Y8RzxSVfZJUFDe==HHoGx7Flus60(u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭ᬹ"): X3X4Y8RzxSVfZJUFDe = Mpsm2VF1OBnCRvK3qf6+o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠬࠫࠥࠦฬะ้๏๊ࠧᬺ")
		elif X3X4Y8RzxSVfZJUFDe==hWGMqtBy4wuLaVcj: X3X4Y8RzxSVfZJUFDe = Mpsm2VF1OBnCRvK3qf6+JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"࠭ࠥࠦࠧࠨࠫᬻ")
		if QWz1jXGo6ruOitUMqET7yI5!=hWGMqtBy4wuLaVcj:
			if LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠧ࡮ࡲ࠷ࠫᬼ") not in QWz1jXGo6ruOitUMqET7yI5: QWz1jXGo6ruOitUMqET7yI5 = SqrG5mU3j96ldsFpExobw40TJY(u"ࠨࠧࠪᬽ")+QWz1jXGo6ruOitUMqET7yI5
			QWz1jXGo6ruOitUMqET7yI5 = Mpsm2VF1OBnCRvK3qf6+QWz1jXGo6ruOitUMqET7yI5
		if QS8ZdxkHD5bjU9qsn4zMYaPrg3h7!=hWGMqtBy4wuLaVcj:
			QS8ZdxkHD5bjU9qsn4zMYaPrg3h7 = S1SgCFYGJeMvfp5iZXK(u"ࠩࠨࠩࠪࠫࠥࠦࠧࠨࠩࠬᬾ")+QS8ZdxkHD5bjU9qsn4zMYaPrg3h7
			QS8ZdxkHD5bjU9qsn4zMYaPrg3h7 = Mpsm2VF1OBnCRvK3qf6+QS8ZdxkHD5bjU9qsn4zMYaPrg3h7[-FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"࠾উ"):]
	if   CnbBKmtF1x84q7AW(u"ࠪࡅࡐࡕࡁࡎࠩᬿ")		in source: xx5hZtqweGJvXNYFCsji8027	= Va9G0tDyKZfd3O75
	elif DJ1ICpbyR2(u"ࠫࡆࡑࡗࡂࡏࠪᭀ")		in source: IfUQDu4t1gGAJpoB	= DJ1ICpbyR2(u"ࠬࡧ࡫ࡸࡣࡰࠫᭁ")
	elif FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"࠭࡫ࡢࡶ࡮ࡳࡺࡺࡥࠨᭂ")		in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: IfUQDu4t1gGAJpoB	= Va9G0tDyKZfd3O75
	elif CnbBKmtF1x84q7AW(u"ࠧࡱࡪࡲࡸࡴࡹ࠮ࡢࡲࡳ࠲࡬࠭ᭃ")	in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: IfUQDu4t1gGAJpoB	= Va9G0tDyKZfd3O75
	elif dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠨࡣࡵࡥࡧࡹࡥࡦࡦ᭄ࠪ")		in source: IfUQDu4t1gGAJpoB	= Va9G0tDyKZfd3O75
	elif NeO3CTLHrPfWUoIgy8Q(u"ࠩࡤࡰࡦࡸࡡࡣࠩᭅ")		in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: IfUQDu4t1gGAJpoB	= Va9G0tDyKZfd3O75
	elif KBkxSYaz93pu1(u"ࠪࡪࡦࡹࡥ࡭ࠩᭆ")		in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: IfUQDu4t1gGAJpoB	= Va9G0tDyKZfd3O75
	elif CnbBKmtF1x84q7AW(u"ࠫࡹ࠽࡭ࡦࡧ࡯ࠫᭇ")		in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: IfUQDu4t1gGAJpoB	= Va9G0tDyKZfd3O75
	elif XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠬࡳ࡯ࡷࡵ࠷ࡹࠬᭈ")		in j4lHpxXvnF2VtwBb1T9PaJEm3:   IfUQDu4t1gGAJpoB	= Va9G0tDyKZfd3O75
	elif o1u5dij9UrcbXzVS8lwIWfKpnqM(u"࠭࡭ࡺࡧࡪࡽࡻ࡯ࡰࠨᭉ")		in j4lHpxXvnF2VtwBb1T9PaJEm3:   IfUQDu4t1gGAJpoB	= Va9G0tDyKZfd3O75
	elif ITvnUAMXsyb4eO(u"ࠧࡧࡣ࡭ࡩࡷ࠭ᭊ")		in j4lHpxXvnF2VtwBb1T9PaJEm3:   IfUQDu4t1gGAJpoB	= Va9G0tDyKZfd3O75
	elif MMizeNH0AKu(u"ࠨใฯีࠬᭋ")			in j4lHpxXvnF2VtwBb1T9PaJEm3:   IfUQDu4t1gGAJpoB	= GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠩࡩࡥ࡯࡫ࡲࠨᭌ")
	elif CnbBKmtF1x84q7AW(u"ࠪๅู้ื๋่ࠪ᭍")		in j4lHpxXvnF2VtwBb1T9PaJEm3:   IfUQDu4t1gGAJpoB	= sULh4NjakzI8He7xJCMGrql(u"ࠫࡵࡧ࡬ࡦࡵࡷ࡭ࡳ࡫ࠧ᭎")
	elif ITvnUAMXsyb4eO(u"ࠬ࡭ࡤࡳ࡫ࡹࡩࠬ᭏")		in NPM3HKQ57xe:   IfUQDu4t1gGAJpoB	= DJ1ICpbyR2(u"࠭ࡧࡰࡱࡪࡰࡪ࠭᭐")
	elif FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠧ࡮ࡻࡦ࡭ࡲࡧࠧ᭑")		in j4lHpxXvnF2VtwBb1T9PaJEm3:   IfUQDu4t1gGAJpoB	= Va9G0tDyKZfd3O75
	elif NeO3CTLHrPfWUoIgy8Q(u"ࠨࡹࡨࡧ࡮ࡳࡡࠨ᭒")		in j4lHpxXvnF2VtwBb1T9PaJEm3:   IfUQDu4t1gGAJpoB	= Va9G0tDyKZfd3O75
	elif HHoGx7Flus60(u"ࠩࡦ࡭ࡲࡧ࡮ࡰࡹࠪ᭓")		in j4lHpxXvnF2VtwBb1T9PaJEm3:   IfUQDu4t1gGAJpoB	= Va9G0tDyKZfd3O75
	elif e2qDYgipPmTw4KvBLnochr(u"ࠪࡲࡪࡽࡣࡪ࡯ࡤࠫ᭔")		in j4lHpxXvnF2VtwBb1T9PaJEm3:   IfUQDu4t1gGAJpoB	= Va9G0tDyKZfd3O75
	elif FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠫࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯ࠩ᭕")	in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: IfUQDu4t1gGAJpoB	= Va9G0tDyKZfd3O75
	elif o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠬࡨ࡯࡬ࡴࡤࠫ᭖")		in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: IfUQDu4t1gGAJpoB	= Va9G0tDyKZfd3O75
	elif ITvnUAMXsyb4eO(u"࠭ࡴࡷࡨࡸࡲࠬ᭗")		in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: IfUQDu4t1gGAJpoB	= Va9G0tDyKZfd3O75
	elif KBkxSYaz93pu1(u"ࠧࡵࡸ࡮ࡷࡦ࠭᭘")		in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: IfUQDu4t1gGAJpoB	= Va9G0tDyKZfd3O75
	elif FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠨࡣࡱࡥࡻ࡯ࡤࡻࠩ᭙")		in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: IfUQDu4t1gGAJpoB	= Va9G0tDyKZfd3O75
	elif A6dMB1FlgxVivJ2fk9C(u"ࠩࡶ࡬ࡴࡵࡦࡱࡴࡲࠫ᭚")		in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: IfUQDu4t1gGAJpoB	= Va9G0tDyKZfd3O75
	elif KBkxSYaz93pu1(u"ࠪࡷ࡭ࡧࡨࡪࡦ࠷ࡹࠬ᭛")		in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: xx5hZtqweGJvXNYFCsji8027	= Va9G0tDyKZfd3O75
	elif NeO3CTLHrPfWUoIgy8Q(u"ࠫࡸ࡮ࡡࡩࡧࡧ࠸ࡺ࠭᭜")		in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: xx5hZtqweGJvXNYFCsji8027	= Va9G0tDyKZfd3O75
	elif hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠬࡩࡩ࡮ࡣ࠷ࡹࠬ᭝")		in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: xx5hZtqweGJvXNYFCsji8027	= Va9G0tDyKZfd3O75
	elif gDuGMR3z1aV6YdLmCpiO8Kl(u"࠭ࡥࡨࡻࡱࡳࡼ࠭᭞")		in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: xx5hZtqweGJvXNYFCsji8027	= Va9G0tDyKZfd3O75
	elif S1SgCFYGJeMvfp5iZXK(u"ࠧࡩࡣ࡯ࡥࡨ࡯࡭ࡢࠩ᭟")		in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: xx5hZtqweGJvXNYFCsji8027	= Va9G0tDyKZfd3O75
	elif KNIvHPjUbhr(u"ࠨࡥ࡬ࡱࡦࡧࡢࡥࡱࠪ᭠")		in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: xx5hZtqweGJvXNYFCsji8027	= Va9G0tDyKZfd3O75
	elif SqrG5mU3j96ldsFpExobw40TJY(u"ࠩࡵࡩࡩࡳ࡯ࡥࡺࠪ᭡")	 	in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: IfUQDu4t1gGAJpoB	= SqrG5mU3j96ldsFpExobw40TJY(u"ࠪࡶࡪࡪ࡭ࡰࡦࡻࠫ᭢")
	elif MMizeNH0AKu(u"ࠫࡾࡵࡵࡵࡷࠪ᭣")	 	in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: IfUQDu4t1gGAJpoB	= A6dMB1FlgxVivJ2fk9C(u"ࠬࡿ࡯ࡶࡶࡸࡦࡪ࠭᭤")
	elif QvgnCALNstmuUJiET(u"࠭ࡹ࠳ࡷ࠱ࡦࡪ࠭᭥")	 	in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: IfUQDu4t1gGAJpoB	= mkHKSQvjWr5BTcM3wVY(u"ࠧࡺࡱࡸࡸࡺࡨࡥࠨ᭦")
	elif mkHKSQvjWr5BTcM3wVY(u"ࠨࡧࡪࡽ࠲ࡨࡥࡴࡶ࠱ࡲࡪࡺࠧ᭧")	in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: IfUQDu4t1gGAJpoB	= Va9G0tDyKZfd3O75
	elif MMizeNH0AKu(u"ࠩࡧ࠲ࡪ࡭ࡹࡣࡧࡶࡸ࠳ࡪࠧ᭨")	in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: IfUQDu4t1gGAJpoB	= MMizeNH0AKu(u"ࠪࡩ࡬ࡿࡢࡦࡵࡷࡺ࡮ࡶࠧ᭩")
	elif jeAby54c02TgG8zuivonX91(u"ࠫࡪ࡭ࡹ࠯ࡤࡨࡷࡹ࠭᭪")		in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: IfUQDu4t1gGAJpoB	= rwQN9AKhLCuMfHxjlbX0U(u"ࠬ࡫ࡧࡺࡤࡨࡷࡹ࠷ࠧ᭫")
	elif o1u5dij9UrcbXzVS8lwIWfKpnqM(u"࠭ࡥࡨࡻࡥࡩࡸࡺ᭬ࠧ")		in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: IfUQDu4t1gGAJpoB	= rwQN9AKhLCuMfHxjlbX0U(u"ࠧࡦࡩࡼࡦࡪࡹࡴ࠴ࠩ᭭")
	elif HHoGx7Flus60(u"ࠨ࡯ࡲࡷ࡭ࡧࡨࡥࡣࠪ᭮")		in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: IfUQDu4t1gGAJpoB	= mkHKSQvjWr5BTcM3wVY(u"ࠩࡰࡳࡸ࡮ࡡࡩࡦࡤࠫ᭯")
	elif zyvJMtBhrw(u"ࠪࡪࡦࡩࡵ࡭ࡶࡼࡦࡴࡵ࡫ࡴࠩ᭰")	in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: IfUQDu4t1gGAJpoB	= DJ1ICpbyR2(u"ࠫ࡫ࡧࡣࡶ࡮ࡷࡽࡧࡵ࡯࡬ࡵࠪ᭱")
	elif NeO3CTLHrPfWUoIgy8Q(u"ࠬ࡯࡮ࡧ࡮ࡤࡱ࠳ࡩࡣࠨ᭲")	in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: IfUQDu4t1gGAJpoB	= mkHKSQvjWr5BTcM3wVY(u"࠭ࡩ࡯ࡨ࡯ࡥࡲ࠭᭳")
	elif rwQN9AKhLCuMfHxjlbX0U(u"ࠧࡣࡷࡽࡾࡻࡸ࡬ࠨ᭴")		in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: IfUQDu4t1gGAJpoB	= sULh4NjakzI8He7xJCMGrql(u"ࠨࡤࡸࡾࡿࡼࡲ࡭ࠩ᭵")
	elif GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠩࡤࡶࡦࡨ࡬ࡰࡣࡧࡷࠬ᭶")	in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: ozdcawTZsVbmUGl	= CnbBKmtF1x84q7AW(u"ࠪࡥࡷࡧࡢ࡭ࡱࡤࡨࡸ࠭᭷")
	elif SqrG5mU3j96ldsFpExobw40TJY(u"ࠫࡦࡸࡣࡩ࡫ࡹࡩࠬ᭸")		in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: ozdcawTZsVbmUGl	= JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠬࡧࡲࡤࡪ࡬ࡺࡪ࠭᭹")
	elif S1SgCFYGJeMvfp5iZXK(u"࠭ࡣࡢࡶࡦ࡬࠳࡯ࡳࠨ᭺")	 	in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: ozdcawTZsVbmUGl	= SqrG5mU3j96ldsFpExobw40TJY(u"ࠧࡤࡣࡷࡧ࡭࠭᭻")
	elif QvgnCALNstmuUJiET(u"ࠨࡨ࡬ࡰࡪࡸࡩࡰࠩ᭼")		in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: ozdcawTZsVbmUGl	= HHoGx7Flus60(u"ࠩࡩ࡭ࡱ࡫ࡲࡪࡱࠪ᭽")
	elif o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠪࡺ࡮ࡪࡢ࡮ࠩ᭾")		in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: ozdcawTZsVbmUGl	= NeO3CTLHrPfWUoIgy8Q(u"ࠫࡻ࡯ࡤࡣ࡯ࠪ᭿")
	elif HHoGx7Flus60(u"ࠬࡼࡩࡥࡪࡧࠫᮀ")		in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: xx5hZtqweGJvXNYFCsji8027	= Va9G0tDyKZfd3O75
	elif QvgnCALNstmuUJiET(u"࠭࡭ࡺࡸ࡬ࡨࠬᮁ")		in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: xx5hZtqweGJvXNYFCsji8027	= Va9G0tDyKZfd3O75
	elif HHoGx7Flus60(u"ࠧ࡮ࡻࡹ࡭࡮ࡪࠧᮂ")		in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: xx5hZtqweGJvXNYFCsji8027	= Va9G0tDyKZfd3O75
	elif CnbBKmtF1x84q7AW(u"ࠨࡸ࡬ࡨࡪࡵࡢࡪࡰࠪᮃ")		in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: ozdcawTZsVbmUGl	= S1SgCFYGJeMvfp5iZXK(u"ࠩࡹ࡭ࡩ࡫࡯ࡣ࡫ࡱࠫᮄ")
	elif xcChIL13BpR8WArNt9Pl0So(u"ࠪ࡫ࡴࡼࡩࡥࠩᮅ")		in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: ozdcawTZsVbmUGl	= mkHKSQvjWr5BTcM3wVY(u"ࠫ࡬ࡵࡶࡪࡦࠪᮆ")
	elif LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠬࡲࡩࡪࡸ࡬ࡨࡪࡵࠧᮇ") 	in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: ozdcawTZsVbmUGl	= KNIvHPjUbhr(u"࠭࡬ࡪ࡫ࡹ࡭ࡩ࡫࡯ࠨᮈ")
	elif OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠧ࡮ࡲ࠷ࡹࡵࡲ࡯ࡢࡦࠪᮉ")	in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: ozdcawTZsVbmUGl	= gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠨ࡯ࡳ࠸ࡺࡶ࡬ࡰࡣࡧࠫᮊ")
	elif KBkxSYaz93pu1(u"ࠩࡳࡹࡧࡲࡩࡤࡸ࡬ࡨࡪࡵࠧᮋ")	in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: ozdcawTZsVbmUGl	= zyvJMtBhrw(u"ࠪࡴࡺࡨ࡬ࡪࡥࡹ࡭ࡩ࡫࡯ࠨᮌ")
	elif rwQN9AKhLCuMfHxjlbX0U(u"ࠫࡷࡧࡰࡪࡦࡹ࡭ࡩ࡫࡯ࠨᮍ") 	in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: ozdcawTZsVbmUGl	= ITvnUAMXsyb4eO(u"ࠬࡸࡡࡱ࡫ࡧࡺ࡮ࡪࡥࡰࠩᮎ")
	elif KBkxSYaz93pu1(u"࠭ࡴࡰࡲ࠷ࡸࡴࡶࠧᮏ")		in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: ozdcawTZsVbmUGl	= DJ1ICpbyR2(u"ࠧࡵࡱࡳ࠸ࡹࡵࡰࠨᮐ")
	elif sULh4NjakzI8He7xJCMGrql(u"ࠨࡷࡳࡴࠬᮑ") 			in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: ozdcawTZsVbmUGl	= OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠩࡸࡴࡧࡵ࡭ࠨᮒ")
	elif wwPrSDa21lUh(u"ࠪࡹࡵࡨࠧᮓ") 			in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: ozdcawTZsVbmUGl	= GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠫࡺࡶࡢࡰ࡯ࠪᮔ")
	elif LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠬࡻࡱ࡭ࡱࡤࡨࠬᮕ") 		in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: ozdcawTZsVbmUGl	= MMizeNH0AKu(u"࠭ࡵࡲ࡮ࡲࡥࡩ࠭ᮖ")
	elif CnbBKmtF1x84q7AW(u"ࠧࡷࡥࡶࡸࡷ࡫ࡡ࡮ࠩᮗ") 	in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: ozdcawTZsVbmUGl	= MMizeNH0AKu(u"ࠨࡸࡦࡷࡹࡸࡥࡢ࡯ࠪᮘ")
	elif hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠩࡹ࡭ࡩࡨ࡯ࡣࠩᮙ")		in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: ozdcawTZsVbmUGl	= dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠪࡺ࡮ࡪࡢࡰࡤࠪᮚ")
	elif rwQN9AKhLCuMfHxjlbX0U(u"ࠫࡻ࡯ࡤࡰࡼࡤࠫᮛ") 		in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: ozdcawTZsVbmUGl	= zyvJMtBhrw(u"ࠬࡼࡩࡥࡱࡽࡥࠬᮜ")
	elif sULh4NjakzI8He7xJCMGrql(u"࠭ࡷࡢࡶࡦ࡬ࡻ࡯ࡤࡦࡱࠪᮝ") 	in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: ozdcawTZsVbmUGl	= e2qDYgipPmTw4KvBLnochr(u"ࠧࡸࡣࡷࡧ࡭ࡼࡩࡥࡧࡲࠫᮞ")
	elif XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠨࡹ࡬ࡲࡹࡼ࠮࡭࡫ࡹࡩࠬᮟ")	in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: ozdcawTZsVbmUGl	= SqrG5mU3j96ldsFpExobw40TJY(u"ࠩࡺ࡭ࡳࡺࡶ࠯࡮࡬ࡺࡪ࠭ᮠ")
	elif GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠪࡾ࡮ࡶࡰࡺࡵ࡫ࡥࡷ࡫ࠧᮡ")	in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: ozdcawTZsVbmUGl	= hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠫࡿ࡯ࡰࡱࡻࡶ࡬ࡦࡸࡥࠨᮢ")
	elif MMizeNH0AKu(u"ࠬ࡮ࡤ࠮ࡥࡧࡲࠬᮣ")		in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: ozdcawTZsVbmUGl	= jeAby54c02TgG8zuivonX91(u"࠭ࡨࡥ࠯ࡦࡨࡳ࠭ᮤ")
	if   IfUQDu4t1gGAJpoB:	SbMcjF0nldxBVGIqWQg7O,j4lHpxXvnF2VtwBb1T9PaJEm3 = KBkxSYaz93pu1(u"ࠧฯษุࠫᮥ"),IfUQDu4t1gGAJpoB
	elif xx5hZtqweGJvXNYFCsji8027:		SbMcjF0nldxBVGIqWQg7O,j4lHpxXvnF2VtwBb1T9PaJEm3 = SqrG5mU3j96ldsFpExobw40TJY(u"ࠨ่ࠧัิีࠧᮦ"),xx5hZtqweGJvXNYFCsji8027
	elif ozdcawTZsVbmUGl:		SbMcjF0nldxBVGIqWQg7O,j4lHpxXvnF2VtwBb1T9PaJEm3 = LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠩࠨࠩ฾อๅࠡ็฼ีํ็ࠧᮧ"),ozdcawTZsVbmUGl
	elif KDOnA5puvt8kTMjmb:	SbMcjF0nldxBVGIqWQg7O,j4lHpxXvnF2VtwBb1T9PaJEm3 = A6dMB1FlgxVivJ2fk9C(u"ูࠪࠩࠪࠫศ็ࠣาฬืฬ๋ࠩᮨ"),KDOnA5puvt8kTMjmb
	elif BzcFfrqi4gtUnjIvOaLD:	SbMcjF0nldxBVGIqWQg7O,j4lHpxXvnF2VtwBb1T9PaJEm3 = EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠫࠪࠫࠥࠦ฻ส้ࠥิวาฮํࠫᮩ"),Va9G0tDyKZfd3O75
	else:			SbMcjF0nldxBVGIqWQg7O,j4lHpxXvnF2VtwBb1T9PaJEm3 = wwPrSDa21lUh(u"ࠬࠫࠥࠦࠧࠨ฽ฬ๋ࠠๆฮ๊์᮪้࠭"),Va9G0tDyKZfd3O75
	return SbMcjF0nldxBVGIqWQg7O,j4lHpxXvnF2VtwBb1T9PaJEm3,X3X4Y8RzxSVfZJUFDe,QWz1jXGo6ruOitUMqET7yI5,QS8ZdxkHD5bjU9qsn4zMYaPrg3h7
def qRFyIG9WZLCEpgeD3hukMYB(url,source):
	NPM3HKQ57xe,xx5hZtqweGJvXNYFCsji8027,SODQ7qlNYoZcFK8e50rBsJaAHxiXjE,Va9G0tDyKZfd3O75,j4lHpxXvnF2VtwBb1T9PaJEm3,X3X4Y8RzxSVfZJUFDe,QWz1jXGo6ruOitUMqET7yI5,QS8ZdxkHD5bjU9qsn4zMYaPrg3h7,JPl40rDFqybV9H2Wxi1 = rRuhPX9pf1(url,source)
	if   e2qDYgipPmTw4KvBLnochr(u"࠭ࡁࡌࡑࡄࡑ᮫ࠬ")		in source: pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = ppotHCQbEN(NPM3HKQ57xe,j4lHpxXvnF2VtwBb1T9PaJEm3)
	elif zyvJMtBhrw(u"ࠧࡂࡍ࡚ࡅࡒ࠭ᮬ")		in source: pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = rrg9LDpKux(NPM3HKQ57xe,X3X4Y8RzxSVfZJUFDe,QS8ZdxkHD5bjU9qsn4zMYaPrg3h7)
	elif o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠨࡈࡄࡗࡊࡒࡈࡅ࠳ࠪᮭ")		in source: pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = qZLioIBnmS(NPM3HKQ57xe)
	elif S1SgCFYGJeMvfp5iZXK(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪᮮ")		in source: pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = DJ1ICpbyR2(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ᮯ"),[hWGMqtBy4wuLaVcj],[url]
	elif OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠫࡾࡵࡵࡵࡷࠪ᮰")		in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = SqrG5mU3j96ldsFpExobw40TJY(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ᮱"),[hWGMqtBy4wuLaVcj],[url]
	elif rwQN9AKhLCuMfHxjlbX0U(u"࠭ࡹ࠳ࡷ࠱ࡦࡪ࠭᮲")		in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ᮳"),[hWGMqtBy4wuLaVcj],[url]
	elif NeO3CTLHrPfWUoIgy8Q(u"ࠨࡅࡌࡑࡆ࠺ࡕࠨ᮴")		in source: pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = iiYkxqCpdD(NPM3HKQ57xe)
	elif gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅࠫ᮵")		in source: pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = n6xPM2Olgc(NPM3HKQ57xe)
	elif S1SgCFYGJeMvfp5iZXK(u"ࠪࡅࡗࡇࡂࡔࡇࡈࡈࠬ᮶")		in source: pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = WW2cFhXPaH(NPM3HKQ57xe)
	elif CnbBKmtF1x84q7AW(u"ࠫࡈࡏࡍࡂࡃࡅࡈࡔ࠭᮷")		in source: pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = SgYBRznWJk(NPM3HKQ57xe)
	elif jeAby54c02TgG8zuivonX91(u"࡙ࠬࡈࡐࡈࡋࡅࠬ᮸")		in source: pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = RRDrAEy29i(NPM3HKQ57xe)
	elif e2qDYgipPmTw4KvBLnochr(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠱ࠨ᮹")		in source: pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = Ojbi3BT8p2(NPM3HKQ57xe,JPl40rDFqybV9H2Wxi1)
	elif KBkxSYaz93pu1(u"ࠧࡂࡎࡐࡗ࡙ࡈࡁࠨᮺ")		in source: pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = rz0JjOH9Pc(NPM3HKQ57xe)
	elif OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠨࡎࡄࡖࡔࡠࡁࠨᮻ")		in source: pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = sqQzra8NCR(NPM3HKQ57xe)
	elif QvgnCALNstmuUJiET(u"ࠩ࡮ࡥࡹࡱ࡯ࡶࡶࡨࠫᮼ")		in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = NfoRzjxBK0(NPM3HKQ57xe)
	elif sULh4NjakzI8He7xJCMGrql(u"ࠪࡥࡰࡵࡡ࡮࠰ࡦࡥࡲ࠭ᮽ")	in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = LezUiM6xTS(NPM3HKQ57xe)
	elif XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠫࡦࡲࡡࡳࡣࡥࠫᮾ")		in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = sUylxQaIY02z8(NPM3HKQ57xe)
	elif EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠬࡹࡨࡢࡪ࡬ࡨ࠹ࡻࠧᮿ")		in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = EEHXBdaKUy(NPM3HKQ57xe)
	elif QvgnCALNstmuUJiET(u"࠭ࡳࡩࡣ࡫ࡩࡩ࠺ࡵࠨᯀ")		in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = EEHXBdaKUy(NPM3HKQ57xe)
	elif JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠧࡦࡩࡼࡲࡴࡽࠧᯁ")		in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = R3Ok4zXioW(NPM3HKQ57xe)
	elif OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠨࡶࡹࡪࡺࡴࠧᯂ")		in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = I8hFklrG4o(NPM3HKQ57xe)
	elif HHoGx7Flus60(u"ࠩࡷࡺࡰࡹࡡࠨᯃ")		in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = I8hFklrG4o(NPM3HKQ57xe)
	elif DJ1ICpbyR2(u"ࠪࡸࡻ࠳ࡦ࠯ࡥࡲࡱࠬᯄ")		in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = I8hFklrG4o(NPM3HKQ57xe)
	elif FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠫ࡭ࡧ࡬ࡢࡥ࡬ࡱࡦ࠭ᯅ")		in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = LnsdUMcbE1(NPM3HKQ57xe)
	elif KBkxSYaz93pu1(u"ࠬࡹࡨࡰࡱࡩࡴࡷࡵࠧᯆ")		in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = ZvTkQpmwgn(NPM3HKQ57xe)
	elif dv0trJR7PwmKyxDYO52VLau8gEph(u"࠭࡭ࡺࡧࡪࡽࡻ࡯ࡰࠨᯇ")		in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = yw0ZTrcCfds3bPxjH(NPM3HKQ57xe)
	elif MMizeNH0AKu(u"ࠧࡷࡵ࠷ࡹࠬᯈ")			in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = N2yYhKoErg(NPM3HKQ57xe)
	elif jeAby54c02TgG8zuivonX91(u"ࠨࡨࡤ࡮ࡪࡸࠧᯉ")		in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = rrhQGPlFcs(NPM3HKQ57xe)
	elif SqrG5mU3j96ldsFpExobw40TJY(u"ࠩࡦ࡭ࡲࡧ࡮ࡰࡹࠪᯊ")		in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = QvHhfzTkoM(NPM3HKQ57xe)
	elif zyvJMtBhrw(u"ࠪࡲࡪࡽࡣࡪ࡯ࡤࠫᯋ")		in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = QvHhfzTkoM(NPM3HKQ57xe)
	elif EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠫࡨ࡯࡭ࡢ࠯࡯࡭࡬࡮ࡴࠨᯌ")	in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = RRDSYVUTXZ(NPM3HKQ57xe)
	elif e2qDYgipPmTw4KvBLnochr(u"ࠬࡩࡩ࡮ࡣ࡯࡭࡬࡮ࡴࠨᯍ")	in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = RRDSYVUTXZ(NPM3HKQ57xe)
	elif KNIvHPjUbhr(u"࠭࡭ࡺࡥ࡬ࡱࡦ࠭ᯎ")		in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = yuDxW8TmPU(NPM3HKQ57xe)
	elif dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠧࡸࡧࡦ࡭ࡲࡧࠧᯏ")		in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = jGiAk0RM3vgXCJKNm6rBIcHl(NPM3HKQ57xe)
	elif EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠨࡤࡲ࡯ࡷࡧࠧᯐ")		in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = UN2CkoBwZe(NPM3HKQ57xe)
	elif S1SgCFYGJeMvfp5iZXK(u"ࠩࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴࠧᯑ")	in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = KaPoYWIB1b(NPM3HKQ57xe)
	elif wwPrSDa21lUh(u"ࠪࡥࡷࡨ࡬ࡪࡱࡱࡾࠬᯒ")		in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = Qtvgrsi4mV(NPM3HKQ57xe)
	elif hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠫࡪ࡭ࡹ࠮ࡤࡨࡷࡹ࠴࡮ࡦࡶࠪᯓ")	in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = jwnTvOI7lZ(NPM3HKQ57xe)
	elif QvgnCALNstmuUJiET(u"ࠬࡪ࠮ࡦࡩࡼࡦࡪࡹࡴ࠯ࡦࠪᯔ")	in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = hWGMqtBy4wuLaVcj,[hWGMqtBy4wuLaVcj],[NPM3HKQ57xe]
	elif HHoGx7Flus60(u"࠭ࡥࡨࡻࡥࡩࡸࡺࠧᯕ")		in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = CtRiO8neuX(NPM3HKQ57xe)
	elif S1SgCFYGJeMvfp5iZXK(u"ࠧࡴࡧࡵ࡭ࡪࡹ࠴ࡸࡣࡷࡧ࡭࠭ᯖ")	in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = J3Xz2NGLxf(NPM3HKQ57xe)
	elif HHoGx7Flus60(u"ࠨࡷࡳࡦࡦࡳࠧᯗ") 		in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = hWGMqtBy4wuLaVcj,[hWGMqtBy4wuLaVcj],[NPM3HKQ57xe]
	else: pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = rwQN9AKhLCuMfHxjlbX0U(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬᯘ"),[hWGMqtBy4wuLaVcj],[NPM3HKQ57xe]
	if pxdY8tiazyJIq and pxdY8tiazyJIq!=hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠪࡉ࡝ࡏࡔࡠࡃࡏࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨᯙ"): pxdY8tiazyJIq = wwPrSDa21lUh(u"ࠫࡋࡧࡩ࡭ࡧࡧ࠾ࠥࠦࠧᯚ")+pxdY8tiazyJIq
	return pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me
def JPCFpNG5Ow2ER(pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me):
	LHN1Zr7FDtbYfjz069Gnh,m4IznKilUOByHweG68VJ = [],[]
	for title,llxFwq0CUNgQtivJzkHeGV in zip(haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me):
		if UGBbEtrcu5jLC6Sxoa3gFyP1mJOpW(llxFwq0CUNgQtivJzkHeGV):
			LHN1Zr7FDtbYfjz069Gnh.append(title)
			m4IznKilUOByHweG68VJ.append(llxFwq0CUNgQtivJzkHeGV)
	if not m4IznKilUOByHweG68VJ and not pxdY8tiazyJIq: pxdY8tiazyJIq = sULh4NjakzI8He7xJCMGrql(u"ࠬࡌࡡࡪ࡮ࡨࡨࠬᯛ")
	return pxdY8tiazyJIq,LHN1Zr7FDtbYfjz069Gnh,m4IznKilUOByHweG68VJ
def AAQIEtp1X3(CgLzZUVKfjWNYHMp,url,source,oa4HOCVwS1cgB9h5DfAvp8):
	global JJlKIRGv1c,T03fZ7nY8rK,vUmF65ohOgitZ,atWRpJ3k4ecA7oVwDY2h6nG,Bwcj5eNQWaTSI74dUnJCGfHxbRLE
	Zwbls5R8BavYd1ocjuIE = []
	for BzcFfrqi4gtUnjIvOaLD in [T03fZ7nY8rK,vUmF65ohOgitZ,atWRpJ3k4ecA7oVwDY2h6nG,Bwcj5eNQWaTSI74dUnJCGfHxbRLE]: BzcFfrqi4gtUnjIvOaLD[oa4HOCVwS1cgB9h5DfAvp8] = FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"࠭ࡔࡪ࡯ࡨࡳࡺࡺࠧᯜ"),[],[]
	WczAm80rpEtNKR5L9sSlQD,zreintZUE39WlpFwkO1u = [MnOVzmX1UZ3PHQ8gTCs0duv62bfJ,wkHpU6XeoGB9LP5AzIDVr,jTBGVFnt0IALg1mudSrlKJ5z4y,mh7XLIRzFNopBKWtwJu1sUCbaG3O],[]
	if rwQN9AKhLCuMfHxjlbX0U(u"ࠧࡧࡴࡧࡰࠬᯝ") in url: WczAm80rpEtNKR5L9sSlQD,zreintZUE39WlpFwkO1u = [MnOVzmX1UZ3PHQ8gTCs0duv62bfJ,wkHpU6XeoGB9LP5AzIDVr,mh7XLIRzFNopBKWtwJu1sUCbaG3O],[atWRpJ3k4ecA7oVwDY2h6nG]
	if NeO3CTLHrPfWUoIgy8Q(u"ࠨࡻࡲࡹࡹࡻࡢࡦࠩᯞ") in url: WczAm80rpEtNKR5L9sSlQD,zreintZUE39WlpFwkO1u = [MnOVzmX1UZ3PHQ8gTCs0duv62bfJ],[vUmF65ohOgitZ,atWRpJ3k4ecA7oVwDY2h6nG,Bwcj5eNQWaTSI74dUnJCGfHxbRLE]
	for BzcFfrqi4gtUnjIvOaLD in zreintZUE39WlpFwkO1u: BzcFfrqi4gtUnjIvOaLD[oa4HOCVwS1cgB9h5DfAvp8] = mkHKSQvjWr5BTcM3wVY(u"ࠩࡖ࡯࡮ࡶࡰࡦࡦࠪᯟ"),[],[]
	for BzcFfrqi4gtUnjIvOaLD in WczAm80rpEtNKR5L9sSlQD:
		IqlvB0fn5SZXiaVh = KCTRe67wVy.Thread(target=BzcFfrqi4gtUnjIvOaLD,args=(url,source,oa4HOCVwS1cgB9h5DfAvp8))
		Zwbls5R8BavYd1ocjuIE.append(IqlvB0fn5SZXiaVh)
		IqlvB0fn5SZXiaVh.start()
		HB5PvxRhwM.sleep(S1SgCFYGJeMvfp5iZXK(u"࠷ঊ"))
	A7lJFgnut634LYB1yr,nhcdOr6Ix1J9eiouVm3S,UuGtbwR8jnasCDy5A4PlZz1xOo6VX,d8jKHCVc71 = fEXMiAyG3ql4vKB,fEXMiAyG3ql4vKB,fEXMiAyG3ql4vKB,fEXMiAyG3ql4vKB
	timeout,step = sULh4NjakzI8He7xJCMGrql(u"࠳࠱ঋ"),Y0XZKGRAUQj5O
	for F9D5yY4d2LxAS8feu in range(timeout//step):
		if not A7lJFgnut634LYB1yr and T03fZ7nY8rK[oa4HOCVwS1cgB9h5DfAvp8][ybdv7XcT3lxF6QezULwCAGk]!=o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠪࡘ࡮ࡳࡥࡰࡷࡷࠫᯠ"): A7lJFgnut634LYB1yr = VBlawK4mgHSyLEn8iqhUkz5
		if not nhcdOr6Ix1J9eiouVm3S and vUmF65ohOgitZ[oa4HOCVwS1cgB9h5DfAvp8][ybdv7XcT3lxF6QezULwCAGk]!=DJ1ICpbyR2(u"࡙ࠫ࡯࡭ࡦࡱࡸࡸࠬᯡ"): nhcdOr6Ix1J9eiouVm3S = VBlawK4mgHSyLEn8iqhUkz5
		if not UuGtbwR8jnasCDy5A4PlZz1xOo6VX and atWRpJ3k4ecA7oVwDY2h6nG[oa4HOCVwS1cgB9h5DfAvp8][ybdv7XcT3lxF6QezULwCAGk]!=JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"࡚ࠬࡩ࡮ࡧࡲࡹࡹ࠭ᯢ"): UuGtbwR8jnasCDy5A4PlZz1xOo6VX = VBlawK4mgHSyLEn8iqhUkz5
		if not d8jKHCVc71 and Bwcj5eNQWaTSI74dUnJCGfHxbRLE[oa4HOCVwS1cgB9h5DfAvp8][ybdv7XcT3lxF6QezULwCAGk]!=QVDJLRlxNg127jMX(u"࠭ࡔࡪ࡯ࡨࡳࡺࡺࠧᯣ"): d8jKHCVc71 = VBlawK4mgHSyLEn8iqhUkz5
		if A7lJFgnut634LYB1yr and nhcdOr6Ix1J9eiouVm3S and UuGtbwR8jnasCDy5A4PlZz1xOo6VX and d8jKHCVc71: break
		if not T03fZ7nY8rK[oa4HOCVwS1cgB9h5DfAvp8][ybdv7XcT3lxF6QezULwCAGk] and T03fZ7nY8rK[oa4HOCVwS1cgB9h5DfAvp8][Y0XZKGRAUQj5O]: break
		if not vUmF65ohOgitZ[oa4HOCVwS1cgB9h5DfAvp8][ybdv7XcT3lxF6QezULwCAGk] and vUmF65ohOgitZ[oa4HOCVwS1cgB9h5DfAvp8][Y0XZKGRAUQj5O]: break
		if not atWRpJ3k4ecA7oVwDY2h6nG[oa4HOCVwS1cgB9h5DfAvp8][ybdv7XcT3lxF6QezULwCAGk] and atWRpJ3k4ecA7oVwDY2h6nG[oa4HOCVwS1cgB9h5DfAvp8][Y0XZKGRAUQj5O]: break
		if not Bwcj5eNQWaTSI74dUnJCGfHxbRLE[oa4HOCVwS1cgB9h5DfAvp8][ybdv7XcT3lxF6QezULwCAGk] and Bwcj5eNQWaTSI74dUnJCGfHxbRLE[oa4HOCVwS1cgB9h5DfAvp8][Y0XZKGRAUQj5O]: break
		HB5PvxRhwM.sleep(step)
	for IqlvB0fn5SZXiaVh in Zwbls5R8BavYd1ocjuIE: IqlvB0fn5SZXiaVh.join(gDuGMR3z1aV6YdLmCpiO8Kl(u"࠲ঌ"))
	PPQWba5CKoTgDxGzZfeOJ8lusHBSNF = KNIvHPjUbhr(u"ࠧࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡣ࠷࠭ᯤ")
	pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = T03fZ7nY8rK[oa4HOCVwS1cgB9h5DfAvp8]
	Dvi8asSrQYX5wE3KMIxT91me = VqfNpHPEahjCsto8uJSweTYOF36(Dvi8asSrQYX5wE3KMIxT91me)
	JJlKIRGv1c[oa4HOCVwS1cgB9h5DfAvp8] = CgLzZUVKfjWNYHMp,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me
	if pxdY8tiazyJIq==DJ1ICpbyR2(u"ࠨࡇ࡛ࡍ࡙ࡥࡁࡍࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ᯥ") or Dvi8asSrQYX5wE3KMIxT91me: return PPQWba5CKoTgDxGzZfeOJ8lusHBSNF,pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me
	CgLzZUVKfjWNYHMp += gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠩ࡟ࡲࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦ࠲࠻᯦ࠢࠣࠫ")+pxdY8tiazyJIq.replace(NXMOzZjYsmS9pf,hWGMqtBy4wuLaVcj).replace(y6eSQlZEV8uwKG5M3,hWGMqtBy4wuLaVcj)[:A6dMB1FlgxVivJ2fk9C(u"࠺࠳঍")]
	PPQWba5CKoTgDxGzZfeOJ8lusHBSNF = xcChIL13BpR8WArNt9Pl0So(u"ࠪࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘ࡟࠴ࠩᯧ")
	pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = vUmF65ohOgitZ[oa4HOCVwS1cgB9h5DfAvp8]
	Dvi8asSrQYX5wE3KMIxT91me = VqfNpHPEahjCsto8uJSweTYOF36(Dvi8asSrQYX5wE3KMIxT91me)
	JJlKIRGv1c[oa4HOCVwS1cgB9h5DfAvp8] = CgLzZUVKfjWNYHMp,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me
	if pxdY8tiazyJIq==KBkxSYaz93pu1(u"ࠫࡊ࡞ࡉࡕࡡࡄࡐࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩᯨ") or Dvi8asSrQYX5wE3KMIxT91me: return PPQWba5CKoTgDxGzZfeOJ8lusHBSNF,pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me
	CgLzZUVKfjWNYHMp += NeO3CTLHrPfWUoIgy8Q(u"ࠬࡢ࡮ࡓࡧࡶࡳࡱࡼࡥࡳࠢ࠶࠾ࠥࠦࠧᯩ")+pxdY8tiazyJIq.replace(NXMOzZjYsmS9pf,hWGMqtBy4wuLaVcj).replace(y6eSQlZEV8uwKG5M3,hWGMqtBy4wuLaVcj)[:sULh4NjakzI8He7xJCMGrql(u"࠻࠴঎")]
	PPQWba5CKoTgDxGzZfeOJ8lusHBSNF = HHoGx7Flus60(u"࠭ࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡢ࠸ࠬᯪ")
	pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = atWRpJ3k4ecA7oVwDY2h6nG[oa4HOCVwS1cgB9h5DfAvp8]
	Dvi8asSrQYX5wE3KMIxT91me = VqfNpHPEahjCsto8uJSweTYOF36(Dvi8asSrQYX5wE3KMIxT91me)
	JJlKIRGv1c[oa4HOCVwS1cgB9h5DfAvp8] = CgLzZUVKfjWNYHMp,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me
	if pxdY8tiazyJIq==S1SgCFYGJeMvfp5iZXK(u"ࠧࡆ࡚ࡌࡘࡤࡇࡌࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬᯫ") or Dvi8asSrQYX5wE3KMIxT91me: return PPQWba5CKoTgDxGzZfeOJ8lusHBSNF,pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me
	CgLzZUVKfjWNYHMp += A6dMB1FlgxVivJ2fk9C(u"ࠨ࡞ࡱࡖࡪࡹ࡯࡭ࡸࡨࡶࠥ࠺࠺ࠡࠢࠪᯬ")+pxdY8tiazyJIq.replace(NXMOzZjYsmS9pf,hWGMqtBy4wuLaVcj).replace(y6eSQlZEV8uwKG5M3,hWGMqtBy4wuLaVcj)[:EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"࠼࠵এ")]
	PPQWba5CKoTgDxGzZfeOJ8lusHBSNF = EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠩࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗࡥ࠵ࠨᯭ")
	pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = Bwcj5eNQWaTSI74dUnJCGfHxbRLE[oa4HOCVwS1cgB9h5DfAvp8]
	Dvi8asSrQYX5wE3KMIxT91me = VqfNpHPEahjCsto8uJSweTYOF36(Dvi8asSrQYX5wE3KMIxT91me)
	JJlKIRGv1c[oa4HOCVwS1cgB9h5DfAvp8] = CgLzZUVKfjWNYHMp,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me
	if pxdY8tiazyJIq==XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠪࡉ࡝ࡏࡔࡠࡃࡏࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨᯮ") or Dvi8asSrQYX5wE3KMIxT91me: return PPQWba5CKoTgDxGzZfeOJ8lusHBSNF,pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me
	CgLzZUVKfjWNYHMp += NeO3CTLHrPfWUoIgy8Q(u"ࠫࡡࡴࡒࡦࡵࡲࡰࡻ࡫ࡲࠡ࠷࠽ࠤࠥ࠭ᯯ")+pxdY8tiazyJIq.replace(NXMOzZjYsmS9pf,hWGMqtBy4wuLaVcj).replace(y6eSQlZEV8uwKG5M3,hWGMqtBy4wuLaVcj)[:SqrG5mU3j96ldsFpExobw40TJY(u"࠽࠶ঐ")]
	JJlKIRGv1c[oa4HOCVwS1cgB9h5DfAvp8] = CgLzZUVKfjWNYHMp,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me
	return PPQWba5CKoTgDxGzZfeOJ8lusHBSNF,CgLzZUVKfjWNYHMp,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me
def MnOVzmX1UZ3PHQ8gTCs0duv62bfJ(url,source,oa4HOCVwS1cgB9h5DfAvp8):
	SODQ7qlNYoZcFK8e50rBsJaAHxiXjE = RRNODILCtGzvgpx(url,KBkxSYaz93pu1(u"ࠬࡴࡡ࡮ࡧࠪᯰ"))
	Dvi8asSrQYX5wE3KMIxT91me = []
	if hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"࠭ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱࠫᯱ")	in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = KaPoYWIB1b(url)
	elif ITvnUAMXsyb4eO(u"ࠧࡨࡱࡲ࡫ࡱ࡫ࡵࡴࡧࡵࡧࡴ᯲࠭") in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = S9qjt6XGfihoRAwvV(url)
	elif o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠨࡻࡲࡹࡹࡻ᯳ࠧ")		in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = vgu7JcpdwP(url)
	elif EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠩࡼ࠶ࡺ࠴ࡢࡦࠩ᯴")		in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = vgu7JcpdwP(url)
	elif NeO3CTLHrPfWUoIgy8Q(u"ࠪࡴ࡭ࡵࡴࡰࡵ࠱ࡥࡵࡶ࠮ࡨࠩ᯵")	in url   : pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = s9wrPhlEQZT6UqoxNv(url)
	elif jeAby54c02TgG8zuivonX91(u"ࠫࡲࡵࡳࡩࡣ࡫ࡨࡦ࠭᯶")		in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = XM70EwYa4t2PcFKV6mHxd(url)
	elif jeAby54c02TgG8zuivonX91(u"ࠬ࡬ࡡࡴࡧ࡯࡬ࡩ࠭᯷")		in url   : pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = qZLioIBnmS(url)
	elif NeO3CTLHrPfWUoIgy8Q(u"࠭ࡡࡳࡣࡥࡰࡴࡧࡤࡴࠩ᯸")	in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = uIAKOzb0e72B(url)
	elif KBkxSYaz93pu1(u"ࠧࡢࡴࡦ࡬࡮ࡼࡥࠨ᯹")		in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = ujQMRfKe6hP1mOdX2iCHJ(url)
	elif DJ1ICpbyR2(u"ࠨࡤࡸࡾࡿࡼࡲ࡭ࠩ᯺")		in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = TteuHca5Q9SwRBCNlAUfqGp2hKOs(url)
	elif LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠩࡨ࠹ࡹࡹࡡࡳࠩ᯻")		in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = MgAQuU38ZJsFlP1cdrW6Xx(url)
	elif QVDJLRlxNg127jMX(u"ࠪࡪࡦࡩࡵ࡭ࡶࡼࡦࡴࡵ࡫ࡴࠩ᯼")	in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = SLDMHOU8Zat1glC(url)
	elif hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠫ࡮ࡴࡦ࡭ࡣࡰ࠲ࡨࡩࠧ᯽")	in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = SLDMHOU8Zat1glC(url)
	elif ITvnUAMXsyb4eO(u"ࠬࡻࡰࡣࡣࡰࠫ᯾") 		in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = hWGMqtBy4wuLaVcj,[hWGMqtBy4wuLaVcj],[url]
	elif XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"࠭࡬ࡪ࡫ࡹ࡭ࡩ࡫࡯ࠨ᯿") 	in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = dr64o7C3phQaOqL8(url)
	elif sULh4NjakzI8He7xJCMGrql(u"ࠧ࡮ࡲ࠷ࡹࡵࡲ࡯ࡢࡦࠪᰀ")	in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = lRND01gkpxPG(url)
	elif mkHKSQvjWr5BTcM3wVY(u"ࠨࡴࡤࡴ࡮ࡪࡶࡪࡦࡨࡳࠬᰁ") 	in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = Z8oLQGO7F5hm13KfMDtHezsRb69vp(url)
	elif zyvJMtBhrw(u"ࠩࡷࡳࡵ࠺ࡴࡰࡲࠪᰂ")		in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = Nresvop5RwfCGUl(url)
	elif QVDJLRlxNg127jMX(u"ࠪࡹࡵࡨࠧᰃ") 			in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = IpaO7R2l6fL0BtJCv1eZSyYEjW(url)
	elif ITvnUAMXsyb4eO(u"ࠫࡺࡶࡰࠨᰄ") 			in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = IpaO7R2l6fL0BtJCv1eZSyYEjW(url)
	elif XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠬࡻࡱ࡭ࡱࡤࡨࠬᰅ") 		in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = YzRbteScIBhqlxF(url)
	elif KNIvHPjUbhr(u"࠭ࡶࡤࡵࡷࡶࡪࡧ࡭ࠨᰆ") 	in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = UFrAHYeI0XGEh47jCc5iNv(url)
	elif ITvnUAMXsyb4eO(u"ࠧࡷ࡫ࡧࡦࡴࡨࠧᰇ")		in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = jiwuAOsBSaWd7IRcz5UFo48Tgy3Gm1(url)
	elif EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠨࡸ࡬ࡨࡴࢀࡡࠨᰈ") 		in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = K4qdl63Q7MSBjUxJkDC(url)
	elif SqrG5mU3j96ldsFpExobw40TJY(u"ࠩࡺࡥࡹࡩࡨࡷ࡫ࡧࡩࡴ࠭ᰉ") 	in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = BZU5qxeRKlCJot2rys(url)
	elif wwPrSDa21lUh(u"ࠪࡻ࡮ࡴࡴࡷ࠰࡯࡭ࡻ࡫ࠧᰊ")	in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = QMXcNAHpludz3x(url)
	elif ITvnUAMXsyb4eO(u"ࠫࡿ࡯ࡰࡱࡻࡶ࡬ࡦࡸࡥࠨᰋ")	in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE: pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = qGMsxAw7VicurR(url)
	else: pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = hWGMqtBy4wuLaVcj,[],[]
	global T03fZ7nY8rK
	if pxdY8tiazyJIq and pxdY8tiazyJIq!=DJ1ICpbyR2(u"ࠬࡋࡘࡊࡖࡢࡅࡑࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪᰌ"): pxdY8tiazyJIq = DJ1ICpbyR2(u"࠭ࡆࡢ࡫࡯ࡩࡩࡀࠠࠡࠩᰍ")
	T03fZ7nY8rK[oa4HOCVwS1cgB9h5DfAvp8] = pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me
	return
def wkHpU6XeoGB9LP5AzIDVr(url,source,oa4HOCVwS1cgB9h5DfAvp8):
	global vUmF65ohOgitZ
	if dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠧࡺࡱࡸࡸࡺࡨࡥࠨᰎ") in url:
		vUmF65ohOgitZ[oa4HOCVwS1cgB9h5DfAvp8] = FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠨࡈࡤ࡭ࡱ࡫ࡤ࠻ࠢࠣࡗࡰ࡯ࡰࡱࡧࡧࠫᰏ"),[],[]
		return
	pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = hWGMqtBy4wuLaVcj,[],[]
	if UGBbEtrcu5jLC6Sxoa3gFyP1mJOpW(url): pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = hWGMqtBy4wuLaVcj,[hWGMqtBy4wuLaVcj],[url]
	if not Dvi8asSrQYX5wE3KMIxT91me: pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = mTNtxM4AzE9S0pcZP1Ffdi8oK(url)
	if not Dvi8asSrQYX5wE3KMIxT91me: pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = ppCXn9k7x8TfMNWeivFaGu(url)
	if not Dvi8asSrQYX5wE3KMIxT91me:
		if pxdY8tiazyJIq==zyvJMtBhrw(u"ࠩࡈ࡜ࡎ࡚࡟ࡂࡎࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧᰐ"): pxdY8tiazyJIq = hWGMqtBy4wuLaVcj
		vUmF65ohOgitZ[oa4HOCVwS1cgB9h5DfAvp8] = FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠪࡊࡦ࡯࡬ࡦࡦ࠽ࠤࠥ࠭ᰑ")+pxdY8tiazyJIq,[],[]
		return
	vUmF65ohOgitZ[oa4HOCVwS1cgB9h5DfAvp8] = pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me
	return
def jTBGVFnt0IALg1mudSrlKJ5z4y(url,source,oa4HOCVwS1cgB9h5DfAvp8):
	wF5zRoQekA9lxOYacnju13yUIDs = hWGMqtBy4wuLaVcj
	N6NCYivtV4I5rEXq = fEXMiAyG3ql4vKB
	try:
		import resolveurl as ndyKzVOPYD2srl
		N6NCYivtV4I5rEXq = ndyKzVOPYD2srl.resolve(url)
	except Exception as K5e92f3YipU74qhMokEm: wF5zRoQekA9lxOYacnju13yUIDs = str(K5e92f3YipU74qhMokEm)
	global atWRpJ3k4ecA7oVwDY2h6nG
	if not N6NCYivtV4I5rEXq:
		if wF5zRoQekA9lxOYacnju13yUIDs==hWGMqtBy4wuLaVcj:
			wF5zRoQekA9lxOYacnju13yUIDs = R7RLCd9kyl.format_exc()
			if wF5zRoQekA9lxOYacnju13yUIDs!=FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠫࡓࡵ࡮ࡦࡖࡼࡴࡪࡀࠠࡏࡱࡱࡩࡡࡴࠧᰒ"): zGjD5QAkd7SO9YPcZl.stderr.write(wF5zRoQekA9lxOYacnju13yUIDs)
		pxdY8tiazyJIq = wF5zRoQekA9lxOYacnju13yUIDs.splitlines()[-bXukYxQ4aHw]
		atWRpJ3k4ecA7oVwDY2h6nG[oa4HOCVwS1cgB9h5DfAvp8] = LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠬࡌࡡࡪ࡮ࡨࡨ࠿ࠦࠠࠨᰓ")+pxdY8tiazyJIq,[],[]
		return
	atWRpJ3k4ecA7oVwDY2h6nG[oa4HOCVwS1cgB9h5DfAvp8] = hWGMqtBy4wuLaVcj,[hWGMqtBy4wuLaVcj],[N6NCYivtV4I5rEXq]
	return
def mh7XLIRzFNopBKWtwJu1sUCbaG3O(url,source,oa4HOCVwS1cgB9h5DfAvp8):
	wF5zRoQekA9lxOYacnju13yUIDs = hWGMqtBy4wuLaVcj
	N6NCYivtV4I5rEXq = fEXMiAyG3ql4vKB
	try:
		import yt_dlp as JJ9rERkpznaY2lms5HxTLfNCFKOdvB
		are2OsL3HtQuxijm8cRlfDSC = JJ9rERkpznaY2lms5HxTLfNCFKOdvB.YoutubeDL({MMizeNH0AKu(u"࠭࡮ࡰࡡࡦࡳࡱࡵࡲࠨᰔ"): VBlawK4mgHSyLEn8iqhUkz5})
		N6NCYivtV4I5rEXq = are2OsL3HtQuxijm8cRlfDSC.extract_info(url,download=fEXMiAyG3ql4vKB)
	except Exception as K5e92f3YipU74qhMokEm: wF5zRoQekA9lxOYacnju13yUIDs = str(K5e92f3YipU74qhMokEm)
	global Bwcj5eNQWaTSI74dUnJCGfHxbRLE
	if not N6NCYivtV4I5rEXq or XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠧࡧࡱࡵࡱࡦࡺࡳࠨᰕ") not in list(N6NCYivtV4I5rEXq.keys()):
		if wF5zRoQekA9lxOYacnju13yUIDs==hWGMqtBy4wuLaVcj:
			wF5zRoQekA9lxOYacnju13yUIDs = R7RLCd9kyl.format_exc()
			if wF5zRoQekA9lxOYacnju13yUIDs!=jeAby54c02TgG8zuivonX91(u"ࠨࡐࡲࡲࡪ࡚ࡹࡱࡧ࠽ࠤࡓࡵ࡮ࡦ࡞ࡱࠫᰖ"): zGjD5QAkd7SO9YPcZl.stderr.write(wF5zRoQekA9lxOYacnju13yUIDs)
		pxdY8tiazyJIq = wF5zRoQekA9lxOYacnju13yUIDs.splitlines()[-bXukYxQ4aHw]
		Bwcj5eNQWaTSI74dUnJCGfHxbRLE[oa4HOCVwS1cgB9h5DfAvp8] = JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠩࡉࡥ࡮ࡲࡥࡥ࠼ࠣࠤࠬᰗ")+pxdY8tiazyJIq,[],[]
	else:
		haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = [],[]
		for llxFwq0CUNgQtivJzkHeGV in N6NCYivtV4I5rEXq[QVDJLRlxNg127jMX(u"ࠪࡪࡴࡸ࡭ࡢࡶࡶࠫᰘ")]:
			haq1bHZINPE58uoBFnKfTSO2ik4.append(llxFwq0CUNgQtivJzkHeGV[KNIvHPjUbhr(u"ࠫ࡫ࡵࡲ࡮ࡣࡷࠫᰙ")])
			Dvi8asSrQYX5wE3KMIxT91me.append(llxFwq0CUNgQtivJzkHeGV[sULh4NjakzI8He7xJCMGrql(u"ࠬࡻࡲ࡭ࠩᰚ")])
		Bwcj5eNQWaTSI74dUnJCGfHxbRLE[oa4HOCVwS1cgB9h5DfAvp8] = hWGMqtBy4wuLaVcj,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me
	return
def mTNtxM4AzE9S0pcZP1Ffdi8oK(url):
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(nHBb7jXk0Daom,rwQN9AKhLCuMfHxjlbX0U(u"࠭ࡇࡆࡖࠪᰛ"),url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,fEXMiAyG3ql4vKB,EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡖࡊࡊࡉࡓࡇࡆࡘࡤ࡛ࡒࡍ࠯࠴ࡷࡹ࠭ᰜ"))
	headers = sDQvwGASB0Vf67mik.headers
	if NeO3CTLHrPfWUoIgy8Q(u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪᰝ") in list(headers.keys()):
		llxFwq0CUNgQtivJzkHeGV = sDQvwGASB0Vf67mik.headers[KBkxSYaz93pu1(u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫᰞ")]
		if UGBbEtrcu5jLC6Sxoa3gFyP1mJOpW(llxFwq0CUNgQtivJzkHeGV): return hWGMqtBy4wuLaVcj,[hWGMqtBy4wuLaVcj],[llxFwq0CUNgQtivJzkHeGV]
	return gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠪࡊࡦ࡯࡬ࡦࡦ࠽ࠤࠥ࠭ᰟ"),[],[]
def VqfNpHPEahjCsto8uJSweTYOF36(YEaKhr8nAVQjsgycmW3qRJpwFB2iI):
	if A6dMB1FlgxVivJ2fk9C(u"ࠫࡱ࡯ࡳࡵࠩᰠ") in str(type(YEaKhr8nAVQjsgycmW3qRJpwFB2iI)):
		m4IznKilUOByHweG68VJ = []
		for llxFwq0CUNgQtivJzkHeGV in YEaKhr8nAVQjsgycmW3qRJpwFB2iI:
			if OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠬࡹࡴࡳࠩᰡ") in str(type(llxFwq0CUNgQtivJzkHeGV)): llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV.replace(y6eSQlZEV8uwKG5M3,hWGMqtBy4wuLaVcj).replace(NXMOzZjYsmS9pf,hWGMqtBy4wuLaVcj).strip(Mpsm2VF1OBnCRvK3qf6)
			m4IznKilUOByHweG68VJ.append(llxFwq0CUNgQtivJzkHeGV)
	else: m4IznKilUOByHweG68VJ = YEaKhr8nAVQjsgycmW3qRJpwFB2iI.replace(y6eSQlZEV8uwKG5M3,hWGMqtBy4wuLaVcj).replace(NXMOzZjYsmS9pf,hWGMqtBy4wuLaVcj).strip(Mpsm2VF1OBnCRvK3qf6)
	return m4IznKilUOByHweG68VJ
def GIVf6kMy5tl3D0E(bQV1Gtm49uZJshH3nWXLPTYrME,source):
	data = Mqk51CFBym0pIQXZLsOxSJ(MM5Dx39f7ULhcJsRptzIowP,LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"࠭࡬ࡪࡵࡷࠫᰢ"),o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠧࡔࡇࡕ࡚ࡊࡘࡓࠨᰣ"),bQV1Gtm49uZJshH3nWXLPTYrME)
	if data:
		haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = zip(*data)
		haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = list(haq1bHZINPE58uoBFnKfTSO2ik4),list(Dvi8asSrQYX5wE3KMIxT91me)
		return haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me
	haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me,yjMwe4NDbxiUKsAvHFVq = [],[],[]
	for llxFwq0CUNgQtivJzkHeGV in bQV1Gtm49uZJshH3nWXLPTYrME:
		if o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠨ࠱࠲ࠫᰤ") not in llxFwq0CUNgQtivJzkHeGV: continue
		SbMcjF0nldxBVGIqWQg7O,j4lHpxXvnF2VtwBb1T9PaJEm3,X3X4Y8RzxSVfZJUFDe,QWz1jXGo6ruOitUMqET7yI5,QS8ZdxkHD5bjU9qsn4zMYaPrg3h7 = YWceERXKbadhot(llxFwq0CUNgQtivJzkHeGV,source)
		QS8ZdxkHD5bjU9qsn4zMYaPrg3h7 = trdVA0JvFaD.findall(DJ1ICpbyR2(u"ࠩ࡟ࡨ࠰࠭ᰥ"),QS8ZdxkHD5bjU9qsn4zMYaPrg3h7,trdVA0JvFaD.DOTALL)
		if QS8ZdxkHD5bjU9qsn4zMYaPrg3h7: QS8ZdxkHD5bjU9qsn4zMYaPrg3h7 = int(QS8ZdxkHD5bjU9qsn4zMYaPrg3h7[ybdv7XcT3lxF6QezULwCAGk])
		else: QS8ZdxkHD5bjU9qsn4zMYaPrg3h7 = ybdv7XcT3lxF6QezULwCAGk
		SODQ7qlNYoZcFK8e50rBsJaAHxiXjE = RRNODILCtGzvgpx(llxFwq0CUNgQtivJzkHeGV,CnbBKmtF1x84q7AW(u"ࠪࡲࡦࡳࡥࠨᰦ"))
		yjMwe4NDbxiUKsAvHFVq.append([SbMcjF0nldxBVGIqWQg7O,j4lHpxXvnF2VtwBb1T9PaJEm3,X3X4Y8RzxSVfZJUFDe,QWz1jXGo6ruOitUMqET7yI5,QS8ZdxkHD5bjU9qsn4zMYaPrg3h7,llxFwq0CUNgQtivJzkHeGV,SODQ7qlNYoZcFK8e50rBsJaAHxiXjE])
	if yjMwe4NDbxiUKsAvHFVq:
		X6SpHMIxBat4ZoVghwJPRv2Q = sorted(yjMwe4NDbxiUKsAvHFVq,reverse=VBlawK4mgHSyLEn8iqhUkz5,key=lambda key: (key[jR6BYWNFZ0egmH4Tr2Q78LbSs3t],key[ybdv7XcT3lxF6QezULwCAGk],key[x1x9kIQo3zjZWnYaiy],key[Y0XZKGRAUQj5O],key[bXukYxQ4aHw],key[KNIvHPjUbhr(u"࠻঑")],key[KNIvHPjUbhr(u"࠶঒")]))
		RhxlHcOYSUGBnqM9p8mAIzF23,RmS3Tuhj5yor9WKXB = [],[]
		for xxcMsZ2DfavVz in X6SpHMIxBat4ZoVghwJPRv2Q:
			SbMcjF0nldxBVGIqWQg7O,j4lHpxXvnF2VtwBb1T9PaJEm3,X3X4Y8RzxSVfZJUFDe,QWz1jXGo6ruOitUMqET7yI5,QS8ZdxkHD5bjU9qsn4zMYaPrg3h7,llxFwq0CUNgQtivJzkHeGV,SODQ7qlNYoZcFK8e50rBsJaAHxiXjE = xxcMsZ2DfavVz
			if QvgnCALNstmuUJiET(u"๊ࠫ็ึๅࠩᰧ") in X3X4Y8RzxSVfZJUFDe:
				RmS3Tuhj5yor9WKXB.append(xxcMsZ2DfavVz)
				continue
			if xxcMsZ2DfavVz not in RhxlHcOYSUGBnqM9p8mAIzF23: RhxlHcOYSUGBnqM9p8mAIzF23.append(xxcMsZ2DfavVz)
		RhxlHcOYSUGBnqM9p8mAIzF23 = RmS3Tuhj5yor9WKXB+RhxlHcOYSUGBnqM9p8mAIzF23
		XK2iWMx6yfU9E = ybdv7XcT3lxF6QezULwCAGk
		for SbMcjF0nldxBVGIqWQg7O,j4lHpxXvnF2VtwBb1T9PaJEm3,X3X4Y8RzxSVfZJUFDe,QWz1jXGo6ruOitUMqET7yI5,QS8ZdxkHD5bjU9qsn4zMYaPrg3h7,llxFwq0CUNgQtivJzkHeGV,SODQ7qlNYoZcFK8e50rBsJaAHxiXjE in RhxlHcOYSUGBnqM9p8mAIzF23:
			QS8ZdxkHD5bjU9qsn4zMYaPrg3h7 = str(QS8ZdxkHD5bjU9qsn4zMYaPrg3h7) if QS8ZdxkHD5bjU9qsn4zMYaPrg3h7 else hWGMqtBy4wuLaVcj
			title = mkHKSQvjWr5BTcM3wVY(u"ู๊ࠬาใิࠫᰨ")+Mpsm2VF1OBnCRvK3qf6+X3X4Y8RzxSVfZJUFDe+Mpsm2VF1OBnCRvK3qf6+SbMcjF0nldxBVGIqWQg7O+Mpsm2VF1OBnCRvK3qf6+QS8ZdxkHD5bjU9qsn4zMYaPrg3h7+Mpsm2VF1OBnCRvK3qf6+QWz1jXGo6ruOitUMqET7yI5+Mpsm2VF1OBnCRvK3qf6+j4lHpxXvnF2VtwBb1T9PaJEm3
			if SODQ7qlNYoZcFK8e50rBsJaAHxiXjE not in title: title = title+Mpsm2VF1OBnCRvK3qf6+SODQ7qlNYoZcFK8e50rBsJaAHxiXjE
			title = title.replace(XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"࠭ࠥࠨᰩ"),hWGMqtBy4wuLaVcj).strip(Mpsm2VF1OBnCRvK3qf6).replace(FqcVAkh7WjIXHdDKf8nvuyRo,Mpsm2VF1OBnCRvK3qf6).replace(FqcVAkh7WjIXHdDKf8nvuyRo,Mpsm2VF1OBnCRvK3qf6).replace(FqcVAkh7WjIXHdDKf8nvuyRo,Mpsm2VF1OBnCRvK3qf6)
			XK2iWMx6yfU9E += bXukYxQ4aHw
			title = str(XK2iWMx6yfU9E)+xcChIL13BpR8WArNt9Pl0So(u"ࠧ࠯ࠢࠪᰪ")+title
			if llxFwq0CUNgQtivJzkHeGV not in Dvi8asSrQYX5wE3KMIxT91me:
				haq1bHZINPE58uoBFnKfTSO2ik4.append(title)
				Dvi8asSrQYX5wE3KMIxT91me.append(llxFwq0CUNgQtivJzkHeGV)
		if Dvi8asSrQYX5wE3KMIxT91me:
			data = zip(haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me)
			if data: BxuD7iQRpW1(MM5Dx39f7ULhcJsRptzIowP,JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠨࡕࡈࡖ࡛ࡋࡒࡔࠩᰫ"),bQV1Gtm49uZJshH3nWXLPTYrME,data,DpQifS0oKBI1hYcO)
	haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = list(haq1bHZINPE58uoBFnKfTSO2ik4),list(Dvi8asSrQYX5wE3KMIxT91me)
	return haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me
def sUylxQaIY02z8(url):
	if o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨᰬ") in url:
		haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = b8IJFKNyPjgE4GelaCSXB6Qht(url)
		if Dvi8asSrQYX5wE3KMIxT91me: return hWGMqtBy4wuLaVcj,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me
		return QvgnCALNstmuUJiET(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡓ࠳ࡖ࠺ࠪᰭ"),[],[]
	return HHoGx7Flus60(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧᰮ"),[hWGMqtBy4wuLaVcj],[url]
def NfoRzjxBK0(url):
	zmDKurMJwj6fi,HHAWYIZauqLrJBitcneTljf7 = [],[]
	if HHoGx7Flus60(u"ࠬ࠵ࡶࡪࡦࡨࡳࡸ࠴࡭ࡱ࠶ࡂࡺ࡮ࡪ࠽ࠨᰯ") in url:
		sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,KNIvHPjUbhr(u"࠭ࡇࡆࡖࠪᰰ"),url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,fEXMiAyG3ql4vKB,hWGMqtBy4wuLaVcj,GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡏࡆ࡚ࡋࡐࡗࡗࡉ࠲࠷ࡳࡵࠩᰱ"))
		if MMizeNH0AKu(u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪᰲ") in sDQvwGASB0Vf67mik.headers:
			llxFwq0CUNgQtivJzkHeGV = sDQvwGASB0Vf67mik.headers[S1SgCFYGJeMvfp5iZXK(u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫᰳ")]
			zmDKurMJwj6fi.append(llxFwq0CUNgQtivJzkHeGV)
			SODQ7qlNYoZcFK8e50rBsJaAHxiXjE = RRNODILCtGzvgpx(llxFwq0CUNgQtivJzkHeGV,LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠪࡲࡦࡳࡥࠨᰴ"))
			HHAWYIZauqLrJBitcneTljf7.append(SODQ7qlNYoZcFK8e50rBsJaAHxiXjE)
	elif KBkxSYaz93pu1(u"ࠫࡰࡧࡴ࡬ࡱࡸࡸࡪ࠴ࡣࡰ࡯ࠪᰵ") in url:
		sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,MMizeNH0AKu(u"ࠬࡍࡅࡕࠩᰶ"),url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,KNIvHPjUbhr(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡎࡅ࡙ࡑࡏࡖࡖࡈ࠱࠷ࡴࡤࠨ᰷"))
		mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
		XXcjg4MYoSre = trdVA0JvFaD.findall(xcChIL13BpR8WArNt9Pl0So(u"ࠧࠩࡧࡹࡥࡱࡢࠨࡧࡷࡱࡧࡹ࡯࡯࡯࡞ࠫࡴ࠱ࡧࠬࡤ࠮࡮࠰ࡪ࠲ࡤ࡝ࠫ࠱࠮ࡄࡢࠩ࡝ࠫࠬ࠲ࡁ࠵ࡳࡤࡴ࡬ࡴࡹࡄࠧ᰸"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if XXcjg4MYoSre:
			XXcjg4MYoSre = XXcjg4MYoSre[ybdv7XcT3lxF6QezULwCAGk]
			IjWbFB4GQpMYNUmur6K9Rn = hGBzk2RAImCy0LKPMVjaN38lxUg6w(XXcjg4MYoSre)
			tO1GiUvAflF7Mm = trdVA0JvFaD.findall(o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠨࡵࡲࡹࡷࡩࡥࡴ࠼ࠫࡠࡠ࠴ࠪࡀ࡞ࡠ࠭࠱࠭᰹"),IjWbFB4GQpMYNUmur6K9Rn,trdVA0JvFaD.DOTALL)
			if tO1GiUvAflF7Mm:
				tO1GiUvAflF7Mm = tO1GiUvAflF7Mm[ybdv7XcT3lxF6QezULwCAGk]
				tO1GiUvAflF7Mm = Cy9ow3c21nABMjzqeaIT(JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠩ࡯࡭ࡸࡺࠧ᰺"),tO1GiUvAflF7Mm)
				for dict in tO1GiUvAflF7Mm:
					llxFwq0CUNgQtivJzkHeGV = dict[KNIvHPjUbhr(u"ࠪࡪ࡮ࡲࡥࠨ᰻")]
					QS8ZdxkHD5bjU9qsn4zMYaPrg3h7 = dict[mkHKSQvjWr5BTcM3wVY(u"ࠫࡱࡧࡢࡦ࡮ࠪ᰼")]
					zmDKurMJwj6fi.append(llxFwq0CUNgQtivJzkHeGV)
					SODQ7qlNYoZcFK8e50rBsJaAHxiXjE = RRNODILCtGzvgpx(llxFwq0CUNgQtivJzkHeGV,XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠬࡴࡡ࡮ࡧࠪ᰽"))
					HHAWYIZauqLrJBitcneTljf7.append(QS8ZdxkHD5bjU9qsn4zMYaPrg3h7+Mpsm2VF1OBnCRvK3qf6+SODQ7qlNYoZcFK8e50rBsJaAHxiXjE)
		elif o1u5dij9UrcbXzVS8lwIWfKpnqM(u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ᰾") in sDQvwGASB0Vf67mik.headers:
			llxFwq0CUNgQtivJzkHeGV = sDQvwGASB0Vf67mik.headers[SqrG5mU3j96ldsFpExobw40TJY(u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ᰿")]
			zmDKurMJwj6fi.append(llxFwq0CUNgQtivJzkHeGV)
			SODQ7qlNYoZcFK8e50rBsJaAHxiXjE = RRNODILCtGzvgpx(llxFwq0CUNgQtivJzkHeGV,EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠨࡰࡤࡱࡪ࠭᱀"))
			HHAWYIZauqLrJBitcneTljf7.append(SODQ7qlNYoZcFK8e50rBsJaAHxiXjE)
		if CnbBKmtF1x84q7AW(u"ࠩࡂࡹࡷࡲ࠽ࡩࡶࡷࡴࡸࡀ࠯࠰ࡲ࡫ࡳࡹࡵࡳ࠯ࡣࡳࡴ࠳࡭࡯ࡰࠩ᱁") in url:
			llxFwq0CUNgQtivJzkHeGV = url.split(HHoGx7Flus60(u"ࠪࡃࡺࡸ࡬࠾ࠩ᱂"))[bXukYxQ4aHw]
			llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV.split(EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠫࠫ࠭᱃"))[ybdv7XcT3lxF6QezULwCAGk]
			if llxFwq0CUNgQtivJzkHeGV:
				zmDKurMJwj6fi.append(llxFwq0CUNgQtivJzkHeGV)
				HHAWYIZauqLrJBitcneTljf7.append(HHoGx7Flus60(u"ࠬࡶࡨࡰࡶࡲࡷࠥ࡭࡯ࡰࡩ࡯ࡩࠬ᱄"))
	else:
		zmDKurMJwj6fi.append(url)
		SODQ7qlNYoZcFK8e50rBsJaAHxiXjE = RRNODILCtGzvgpx(url,jeAby54c02TgG8zuivonX91(u"࠭࡮ࡢ࡯ࡨࠫ᱅"))
		HHAWYIZauqLrJBitcneTljf7.append(SODQ7qlNYoZcFK8e50rBsJaAHxiXjE)
	if not zmDKurMJwj6fi: return SqrG5mU3j96ldsFpExobw40TJY(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡎࡅ࡙ࡑࡏࡖࡖࡈࠫ᱆"),[],[]
	elif len(zmDKurMJwj6fi)==bXukYxQ4aHw: llxFwq0CUNgQtivJzkHeGV = zmDKurMJwj6fi[ybdv7XcT3lxF6QezULwCAGk]
	else:
		OODLkJlZCoKmrzbg2XQSGPUdInA = Eb7qJoNwOgn(NeO3CTLHrPfWUoIgy8Q(u"ࠨลัฮึࠦวๅ็็ๅࠥอไๆ่สือ࠭᱇"),HHAWYIZauqLrJBitcneTljf7)
		if OODLkJlZCoKmrzbg2XQSGPUdInA==-bXukYxQ4aHw: return JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠩࡈ࡜ࡎ࡚࡟ࡂࡎࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ᱈"),[],[]
		llxFwq0CUNgQtivJzkHeGV = zmDKurMJwj6fi[OODLkJlZCoKmrzbg2XQSGPUdInA]
	return XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭᱉"),[hWGMqtBy4wuLaVcj],[llxFwq0CUNgQtivJzkHeGV]
def S9qjt6XGfihoRAwvV(url):
	headers = {QvgnCALNstmuUJiET(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ᱊"):GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠬࡑ࡯ࡥ࡫࠲ࠫ᱋")+str(guSzmUCXDa1tQpY)}
	for JpzD0lv9cYM6XrHeqCa in range(OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"࠶࠲ও")):
		HB5PvxRhwM.sleep(KNIvHPjUbhr(u"࠲࠱࠵࠵࠶ঔ"))
		sDQvwGASB0Vf67mik = HaZx1JTW4ELwv(QvgnCALNstmuUJiET(u"࠭ࡇࡆࡖࠪ᱌"),url,hWGMqtBy4wuLaVcj,headers,fEXMiAyG3ql4vKB,hWGMqtBy4wuLaVcj,EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡋࡔࡕࡇࡍࡇࡘࡗࡊࡘࡃࡐࡐࡗࡉࡓ࡚࠭࠲ࡵࡷࠫᱍ"))
		if JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪᱎ") in list(sDQvwGASB0Vf67mik.headers.keys()):
			llxFwq0CUNgQtivJzkHeGV = sDQvwGASB0Vf67mik.headers[gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫᱏ")]
			llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV+ITvnUAMXsyb4eO(u"ࠪࢀ࡚ࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴ࠾ࠩ᱐")+headers[zyvJMtBhrw(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ᱑")]
			return hWGMqtBy4wuLaVcj,[hWGMqtBy4wuLaVcj],[llxFwq0CUNgQtivJzkHeGV]
		if sDQvwGASB0Vf67mik.code!=KBkxSYaz93pu1(u"࠷࠶࠾ক"): break
	return NeO3CTLHrPfWUoIgy8Q(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡈࡑࡒࡋࡑࡋࡕࡔࡇࡕࡇࡔࡔࡔࡆࡐࡗࠫ᱒"),[],[]
def s9wrPhlEQZT6UqoxNv(url):
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,dv0trJR7PwmKyxDYO52VLau8gEph(u"࠭ࡇࡆࡖࠪ᱓"),url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡔࡍࡕࡔࡐࡕࡊࡓࡔࡍࡌࡆ࠯࠴ࡷࡹ࠭᱔"))
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	llxFwq0CUNgQtivJzkHeGV = trdVA0JvFaD.findall(HHoGx7Flus60(u"ࠨࠤࠫ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡻ࡯ࡤࡦࡱ࠰ࡨࡴࡽ࡮࡭ࡱࡤࡨࡸ࠴ࠪࡀࠫࠥ࠰࠳࠰࠿࠭࠰࠭ࡃ࠱࠮࠮ࠫࡁࠬ࠰ࠬ᱕"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if llxFwq0CUNgQtivJzkHeGV:
		llxFwq0CUNgQtivJzkHeGV,QS8ZdxkHD5bjU9qsn4zMYaPrg3h7 = llxFwq0CUNgQtivJzkHeGV[ybdv7XcT3lxF6QezULwCAGk]
		return hWGMqtBy4wuLaVcj,[QS8ZdxkHD5bjU9qsn4zMYaPrg3h7],[llxFwq0CUNgQtivJzkHeGV]
	return XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡕࡎࡏࡕࡑࡖࡋࡔࡕࡇࡍࡇࠪ᱖"),[],[]
def jSxyTUJcYz(url):
	if S1SgCFYGJeMvfp5iZXK(u"ࠪ࠳ࡼ࡫ࡥࡱ࡫ࡶ࠳ࠬ᱗") in url:
		sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(nHBb7jXk0Daom,LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠫࡌࡋࡔࠨ᱘"),url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,KBkxSYaz93pu1(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡙ࡈࡇࡎࡓࡁ࠳࠯࠴ࡷࡹ࠭᱙"))
		mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
		llxFwq0CUNgQtivJzkHeGV = trdVA0JvFaD.findall(HHoGx7Flus60(u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡳࡸࡥࡱ࡯ࡴࡺࡀࠪᱚ"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if llxFwq0CUNgQtivJzkHeGV: url = llxFwq0CUNgQtivJzkHeGV[ybdv7XcT3lxF6QezULwCAGk]
		else: return mkHKSQvjWr5BTcM3wVY(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥ࡚ࠢࡉࡈࡏࡍࡂ࠴ࠪᱛ"),[],[]
	return NeO3CTLHrPfWUoIgy8Q(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫᱜ"),[hWGMqtBy4wuLaVcj],[url]
def rz0JjOH9Pc(url):
	if jeAby54c02TgG8zuivonX91(u"ࠩࡶࡩࡷࡼ࠽ࠨᱝ") in url:
		sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(nHBb7jXk0Daom,EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠪࡋࡊ࡚ࠧᱞ"),url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,sULh4NjakzI8He7xJCMGrql(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡎࡐࡗ࡙ࡈࡁ࠮࠳ࡶࡸࠬᱟ"))
		mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
		llxFwq0CUNgQtivJzkHeGV = trdVA0JvFaD.findall(sULh4NjakzI8He7xJCMGrql(u"ࠬࡂࡩࡧࡴࡤࡱࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᱠ"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if llxFwq0CUNgQtivJzkHeGV: url = llxFwq0CUNgQtivJzkHeGV[ybdv7XcT3lxF6QezULwCAGk]
		else:
			llxFwq0CUNgQtivJzkHeGV = trdVA0JvFaD.findall(xcChIL13BpR8WArNt9Pl0So(u"ࠨࡁ࡭ࡤࡤࡔࡱࡧࡹࡦࡴࡆࡳࡳࡺࡲࡰ࡮࡟ࠬࠬ࠮࠮ࠫࡁࠬࠫࠧᱡ"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
			if llxFwq0CUNgQtivJzkHeGV:
				url = llxFwq0CUNgQtivJzkHeGV[ybdv7XcT3lxF6QezULwCAGk]
				url = FxG0Q9kuBSmTyM.b64decode(url)
				if H4qZ2hwilNJYTmCFEQyaSs98cPM0gR: url = url.decode(a7VXeDU82IfQEnPZAdiT)
			else: return LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡄࡐࡒ࡙ࡔࡃࡃࠪᱢ"),[],[]
	return mkHKSQvjWr5BTcM3wVY(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫᱣ"),[hWGMqtBy4wuLaVcj],[url]
def qZLioIBnmS(url):
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(nHBb7jXk0Daom,S1SgCFYGJeMvfp5iZXK(u"ࠩࡊࡉ࡙࠭ᱤ"),url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,mkHKSQvjWr5BTcM3wVY(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡆࡂࡕࡈࡐࡍࡊ࠱࠮࠳ࡶࡸࠬᱥ"))
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	mMQ3FkNVa4IlxqY = pq5nlLYxzuaQg(mMQ3FkNVa4IlxqY)
	llxFwq0CUNgQtivJzkHeGV = trdVA0JvFaD.findall(S1SgCFYGJeMvfp5iZXK(u"ࠫࠧ࡬ࡩ࡭ࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬᱦ"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if llxFwq0CUNgQtivJzkHeGV: return hWGMqtBy4wuLaVcj,[hWGMqtBy4wuLaVcj],[llxFwq0CUNgQtivJzkHeGV[ybdv7XcT3lxF6QezULwCAGk]]
	return FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡇࡃࡖࡉࡑࡎࡄ࠲ࠩᱧ"),[],[]
def sqQzra8NCR(url):
	if len(url)>GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"࠶࠵࠶খ"):
		url = url.strip(zyvJMtBhrw(u"࠭࠯ࠨᱨ"))+DJ1ICpbyR2(u"ࠧ࠰ࠩᱩ")
		sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(nHBb7jXk0Daom,KBkxSYaz93pu1(u"ࠨࡉࡈࡘࠬᱪ"),url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,wwPrSDa21lUh(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡒࡁࡓࡑ࡝ࡅ࠲࠷ࡳࡵࠩᱫ"))
		mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
		if ybdv7XcT3lxF6QezULwCAGk and LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠪࡪࡺࡴࡣࡵ࡫ࡲࡲ࠭࡮ࠬࡶ࠮ࡱ࠰ࡹ࠲ࡥ࠭ࡴࠬࠫᱬ") in mMQ3FkNVa4IlxqY:
			DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall(MMizeNH0AKu(u"ࠫࠧࡲ࡯ࡢࡦࡨࡶࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪᱭ"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
			if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
				cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[CnbBKmtF1x84q7AW(u"࠵গ")]
				DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall(xcChIL13BpR8WArNt9Pl0So(u"ࠬࡂࡳࡤࡴ࡬ࡴࡹࡄࡶࡢࡴࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡧࡷ࡯ࡰࡵࠩᱮ"),cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
				if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
					cok5ZGXdQP7YhwtqyuaCnVevm6UB = zUJTl3EtmvNedxkZ42B(DJvksH7ZAFUqW9OyQnbGjPCtwR1o[LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"࠶ঘ")])
		elif len(mMQ3FkNVa4IlxqY)<LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"࠴࠱࠲ঙ"): llxFwq0CUNgQtivJzkHeGV = mMQ3FkNVa4IlxqY
		else: return MMizeNH0AKu(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡎࡄࡖࡔࡠࡁࠨᱯ"),[],[]
		return DJ1ICpbyR2(u"ࠧࠨᱰ"),[hWGMqtBy4wuLaVcj],[llxFwq0CUNgQtivJzkHeGV]
	return xcChIL13BpR8WArNt9Pl0So(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫᱱ"),[hWGMqtBy4wuLaVcj],[url]
def RRDrAEy29i(url):
	if MMizeNH0AKu(u"ࠩ࠲ࡨࡴࡽ࡮࠯ࡲ࡫ࡴࠬᱲ") in url:
		sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(nHBb7jXk0Daom,ITvnUAMXsyb4eO(u"ࠪࡋࡊ࡚ࠧᱳ"),url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡔࡊࡒࡊࡍࡇ࠭࠲ࡵࡷࠫᱴ"))
		mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
		llxFwq0CUNgQtivJzkHeGV = trdVA0JvFaD.findall(wwPrSDa21lUh(u"ࠬࡼࡩࡥࡧࡲ࠱ࡼࡸࡡࡱࡲࡨࡶ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᱵ"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		url = llxFwq0CUNgQtivJzkHeGV[ybdv7XcT3lxF6QezULwCAGk]
	return KNIvHPjUbhr(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩᱶ"),[hWGMqtBy4wuLaVcj],[url]
def iiYkxqCpdD(url):
	if S1SgCFYGJeMvfp5iZXK(u"ࠧࡴࡧࡵࡺࡪࡸ࠮ࡱࡪࡳࠫᱷ") in url:
		sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(nHBb7jXk0Daom,xcChIL13BpR8WArNt9Pl0So(u"ࠨࡉࡈࡘࠬᱸ"),url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,QvgnCALNstmuUJiET(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡉࡉࡎࡃ࠷࡙࠲࠷ࡳࡵࠩᱹ"))
		mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
		llxFwq0CUNgQtivJzkHeGV = trdVA0JvFaD.findall(A6dMB1FlgxVivJ2fk9C(u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᱺ"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV[ybdv7XcT3lxF6QezULwCAGk]
		if xcChIL13BpR8WArNt9Pl0So(u"ࠫ࡭ࡺࡴࡱࠩᱻ") in llxFwq0CUNgQtivJzkHeGV: return MMizeNH0AKu(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨᱼ"),[hWGMqtBy4wuLaVcj],[llxFwq0CUNgQtivJzkHeGV]
		return mkHKSQvjWr5BTcM3wVY(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡅࡌࡑࡆ࠺ࡕࠨᱽ"),[],[]
	return SqrG5mU3j96ldsFpExobw40TJY(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ᱾"),[hWGMqtBy4wuLaVcj],[url]
def R3Ok4zXioW(url):
	NPM3HKQ57xe,OucJVrWRKSqDChiG7yn3oz0dafZF = fWM9y4vTcPLS0b3UKItC1os5(url)
	PwvNmnqXKrYVZugB5c8 = {QVDJLRlxNg127jMX(u"ࠨ࡚࠰ࡖࡪࡷࡵࡦࡵࡷࡩࡩ࠳ࡗࡪࡶ࡫ࠫ᱿"):mkHKSQvjWr5BTcM3wVY(u"࡛ࠩࡑࡑࡎࡴࡵࡲࡕࡩࡶࡻࡥࡴࡶࠪᲀ"),HHoGx7Flus60(u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩᲁ"):xcChIL13BpR8WArNt9Pl0So(u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦ࠾ࠤࡨ࡮ࡡࡳࡵࡨࡸࡂ࡛ࡔࡇ࠯࠻ࠫᲂ")}
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠬࡖࡏࡔࡖࠪᲃ"),NPM3HKQ57xe,OucJVrWRKSqDChiG7yn3oz0dafZF,PwvNmnqXKrYVZugB5c8,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,rwQN9AKhLCuMfHxjlbX0U(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡈࡋ࡞ࡔࡏࡘ࠯࠴ࡷࡹ࠭ᲄ"))
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	llxFwq0CUNgQtivJzkHeGV = trdVA0JvFaD.findall(A6dMB1FlgxVivJ2fk9C(u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᲅ"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if not llxFwq0CUNgQtivJzkHeGV: return e2qDYgipPmTw4KvBLnochr(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡉࡌ࡟ࡎࡐ࡙ࠪᲆ"),[],[]
	llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV[ybdv7XcT3lxF6QezULwCAGk]
	return EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬᲇ"),[hWGMqtBy4wuLaVcj],[llxFwq0CUNgQtivJzkHeGV]
def ZvTkQpmwgn(url):
	headers = {XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠪ࡜࠲ࡘࡥࡲࡷࡨࡷࡹ࡫ࡤ࠮࡙࡬ࡸ࡭࠭ᲈ"):S1SgCFYGJeMvfp5iZXK(u"ࠫ࡝ࡓࡌࡉࡶࡷࡴࡗ࡫ࡱࡶࡧࡶࡸࠬᲉ")}
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠬࡍࡅࡕࠩᲊ"),url,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,dv0trJR7PwmKyxDYO52VLau8gEph(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡖࡌࡔࡕࡆࡑࡔࡒ࠱࠶ࡹࡴࠨ᲋"))
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	llxFwq0CUNgQtivJzkHeGV = trdVA0JvFaD.findall(DJ1ICpbyR2(u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ᲌"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL|trdVA0JvFaD.IGNORECASE)
	if not llxFwq0CUNgQtivJzkHeGV: return JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡗࡍࡕࡏࡇࡒࡕࡓࠬ᲍"),[],[]
	llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV[ybdv7XcT3lxF6QezULwCAGk]
	return HHoGx7Flus60(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ᲎"),[hWGMqtBy4wuLaVcj],[llxFwq0CUNgQtivJzkHeGV]
def LnsdUMcbE1(url):
	NPM3HKQ57xe,OucJVrWRKSqDChiG7yn3oz0dafZF = fWM9y4vTcPLS0b3UKItC1os5(url)
	PwvNmnqXKrYVZugB5c8 = {QVDJLRlxNg127jMX(u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ᲏"):DJ1ICpbyR2(u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦ࠾ࠤࡨ࡮ࡡࡳࡵࡨࡸࡂ࡛ࡔࡇ࠯࠻ࠫᲐ")}
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠬࡖࡏࡔࡖࠪᲑ"),NPM3HKQ57xe,OucJVrWRKSqDChiG7yn3oz0dafZF,PwvNmnqXKrYVZugB5c8,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,KBkxSYaz93pu1(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡋࡅࡑࡇࡃࡊࡏࡄ࠱࠶ࡹࡴࠨᲒ"))
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	llxFwq0CUNgQtivJzkHeGV = trdVA0JvFaD.findall(sULh4NjakzI8He7xJCMGrql(u"ࠧࠨࠩ࠿࡭࡫ࡸࡡ࡮ࡧࠣࡷࡷࡩ࠽࡜ࠤࠪࡡ࠭࠴ࠪࡀࠫ࡞ࠦࠬࡣࠧࠨࠩᲓ"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL|trdVA0JvFaD.IGNORECASE)
	if not llxFwq0CUNgQtivJzkHeGV: return HHoGx7Flus60(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡌࡆࡒࡁࡄࡋࡐࡅࠬᲔ"),[],[]
	llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV[ybdv7XcT3lxF6QezULwCAGk]
	if rwQN9AKhLCuMfHxjlbX0U(u"ࠩ࡫ࡸࡹࡶࠧᲕ") not in llxFwq0CUNgQtivJzkHeGV: llxFwq0CUNgQtivJzkHeGV = OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠪ࡬ࡹࡺࡰ࠻ࠩᲖ")+llxFwq0CUNgQtivJzkHeGV
	return rwQN9AKhLCuMfHxjlbX0U(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧᲗ"),[hWGMqtBy4wuLaVcj],[llxFwq0CUNgQtivJzkHeGV]
def SgYBRznWJk(url):
	MDSF21x9HK3AZyGUhcb,HHAWYIZauqLrJBitcneTljf7,zmDKurMJwj6fi = url,[],[]
	if JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠬ࠵ࡡ࡫ࡣࡻ࠳ࠬᲘ") in url:
		NPM3HKQ57xe,OucJVrWRKSqDChiG7yn3oz0dafZF = fWM9y4vTcPLS0b3UKItC1os5(url)
		PwvNmnqXKrYVZugB5c8 = {DJ1ICpbyR2(u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬᲙ"):GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩࡁࠠࡤࡪࡤࡶࡸ࡫ࡴ࠾ࡗࡗࡊ࠲࠾ࠧᲚ")}
		sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,mkHKSQvjWr5BTcM3wVY(u"ࠨࡒࡒࡗ࡙࠭Მ"),NPM3HKQ57xe,OucJVrWRKSqDChiG7yn3oz0dafZF,PwvNmnqXKrYVZugB5c8,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,ITvnUAMXsyb4eO(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡉࡉࡎࡃࡄࡆࡉࡕ࠭࠲ࡵࡷࠫᲜ"))
		mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
		e1FSlOgEW4bYJhjVAxf5ycGt = trdVA0JvFaD.findall(QVDJLRlxNg127jMX(u"ࠪࠫࠬࡂࡩࡧࡴࡤࡱࡪ࠴ࠪࡀࡵࡵࡧࡂࡡࠢࠨ࡟ࠫ࠲࠯ࡅࠩ࡜ࠤࠪࡡࠬ࠭ࠧᲝ"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL|trdVA0JvFaD.IGNORECASE)
		if e1FSlOgEW4bYJhjVAxf5ycGt: MDSF21x9HK3AZyGUhcb = e1FSlOgEW4bYJhjVAxf5ycGt[ybdv7XcT3lxF6QezULwCAGk]
	return XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧᲞ"),[hWGMqtBy4wuLaVcj],[MDSF21x9HK3AZyGUhcb]
def I8hFklrG4o(url):
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,QvgnCALNstmuUJiET(u"ࠬࡍࡅࡕࠩᲟ"),url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,A6dMB1FlgxVivJ2fk9C(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡗ࡚ࡋ࡛ࡎ࠮࠳ࡶࡸࠬᲠ"))
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	M3J1TDlaHErKZCSk = trdVA0JvFaD.findall(NeO3CTLHrPfWUoIgy8Q(u"ࠢࡷࡣࡵࠤ࡫ࡹࡥࡳࡸࠣࡁ࠳࠰࠿ࠨࠪ࠱࠮ࡄ࠯ࠧࠣᲡ"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL|trdVA0JvFaD.IGNORECASE)
	if M3J1TDlaHErKZCSk:
		M3J1TDlaHErKZCSk = M3J1TDlaHErKZCSk[ybdv7XcT3lxF6QezULwCAGk][xcChIL13BpR8WArNt9Pl0So(u"࠳চ"):]
		M3J1TDlaHErKZCSk = FxG0Q9kuBSmTyM.b64decode(M3J1TDlaHErKZCSk)
		if H4qZ2hwilNJYTmCFEQyaSs98cPM0gR: M3J1TDlaHErKZCSk = M3J1TDlaHErKZCSk.decode(a7VXeDU82IfQEnPZAdiT)
		llxFwq0CUNgQtivJzkHeGV = trdVA0JvFaD.findall(OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭Ტ"),M3J1TDlaHErKZCSk,trdVA0JvFaD.DOTALL)
	else: llxFwq0CUNgQtivJzkHeGV = hWGMqtBy4wuLaVcj
	if not llxFwq0CUNgQtivJzkHeGV: return NeO3CTLHrPfWUoIgy8Q(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤ࡙࡜ࡆࡖࡐࠪᲣ"),[],[]
	llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV[ybdv7XcT3lxF6QezULwCAGk]
	if A6dMB1FlgxVivJ2fk9C(u"ࠪ࡬ࡹࡺࡰࠨᲤ") not in llxFwq0CUNgQtivJzkHeGV: llxFwq0CUNgQtivJzkHeGV = MMizeNH0AKu(u"ࠫ࡭ࡺࡴࡱ࠼ࠪᲥ")+llxFwq0CUNgQtivJzkHeGV
	return LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨᲦ"),[hWGMqtBy4wuLaVcj],[llxFwq0CUNgQtivJzkHeGV]
def yw0ZTrcCfds3bPxjH(url):
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(nHBb7jXk0Daom,HHoGx7Flus60(u"࠭ࡇࡆࡖࠪᲧ"),url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡑ࡞ࡋࡇ࡚ࡘࡌࡔ࠲࠷ࡳࡵࠩᲨ"))
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	llxFwq0CUNgQtivJzkHeGV = trdVA0JvFaD.findall(XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡥࡲࡰ࠲ࡹ࡭࠮࠳࠵ࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭Ჩ"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if not llxFwq0CUNgQtivJzkHeGV: return e2qDYgipPmTw4KvBLnochr(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡒ࡟ࡅࡈ࡛࡙ࡍࡕ࠭Ც"),[],[]
	llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV[ybdv7XcT3lxF6QezULwCAGk]
	return KBkxSYaz93pu1(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭Ძ"),[hWGMqtBy4wuLaVcj],[llxFwq0CUNgQtivJzkHeGV]
def KaPoYWIB1b(url):
	id = url.split(EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠫ࠴࠭Წ"))[-QVDJLRlxNg127jMX(u"࠳ছ")]
	if MMizeNH0AKu(u"ࠬ࠵ࡥ࡮ࡤࡨࡨࠬᲭ") in url: url = url.replace(FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"࠭࠯ࡦ࡯ࡥࡩࡩ࠭Ხ"),hWGMqtBy4wuLaVcj)
	url = url.replace(xcChIL13BpR8WArNt9Pl0So(u"ࠧ࠯ࡥࡲࡱ࠴࠭Ჯ"),SqrG5mU3j96ldsFpExobw40TJY(u"ࠨ࠰ࡦࡳࡲ࠵ࡰ࡭ࡣࡼࡩࡷ࠵࡭ࡦࡶࡤࡨࡦࡺࡡ࠰ࠩᲰ"))
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(nHBb7jXk0Daom,KNIvHPjUbhr(u"ࠩࡊࡉ࡙࠭Ჱ"),url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,xcChIL13BpR8WArNt9Pl0So(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱࠶ࡹࡴࠨᲲ"))
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	pxdY8tiazyJIq = QVDJLRlxNg127jMX(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑࠫᲳ")
	K5e92f3YipU74qhMokEm = trdVA0JvFaD.findall(mkHKSQvjWr5BTcM3wVY(u"ࠬࠨࡥࡳࡴࡲࡶࠧ࠴ࠪࡀࠤࡰࡩࡸࡹࡡࡨࡧࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭Ჴ"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if K5e92f3YipU74qhMokEm: pxdY8tiazyJIq = K5e92f3YipU74qhMokEm[ybdv7XcT3lxF6QezULwCAGk]
	url = trdVA0JvFaD.findall(ITvnUAMXsyb4eO(u"࠭ࡸ࠮࡯ࡳࡩ࡬࡛ࡒࡍࠤ࠯ࠦࡺࡸ࡬ࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪᲵ"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if not url and pxdY8tiazyJIq:
		return pxdY8tiazyJIq,[],[]
	llxFwq0CUNgQtivJzkHeGV = url[ybdv7XcT3lxF6QezULwCAGk].replace(gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠧ࡝࡞ࠪᲶ"),hWGMqtBy4wuLaVcj)
	H7wAinr4f3M8oPDFsdkIZ,bQV1Gtm49uZJshH3nWXLPTYrME = b8IJFKNyPjgE4GelaCSXB6Qht(llxFwq0CUNgQtivJzkHeGV)
	odaBP0SyZ7IwpmqR = trdVA0JvFaD.findall(gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠨࠤࡲࡻࡳ࡫ࡲࠣ࠼࡟ࡿࠧ࡯ࡤࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࠨࡳࡤࡴࡨࡩࡳࡴࡡ࡮ࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠱ࠨࡵࡳ࡮ࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬᲷ"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if odaBP0SyZ7IwpmqR: ii7f1OCeLMAkUJmY8EN4vrbXuHqoZ,k4w2OHEX8lyWnM7baZsoUhGJ5FCQ,Ah6NVSEFnXb8wjyO = odaBP0SyZ7IwpmqR[ybdv7XcT3lxF6QezULwCAGk]
	else: ii7f1OCeLMAkUJmY8EN4vrbXuHqoZ,k4w2OHEX8lyWnM7baZsoUhGJ5FCQ,Ah6NVSEFnXb8wjyO = hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj
	Ah6NVSEFnXb8wjyO = Ah6NVSEFnXb8wjyO.replace(gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠩ࡟࠳ࠬᲸ"),hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠪ࠳ࠬᲹ"))
	k4w2OHEX8lyWnM7baZsoUhGJ5FCQ = emr1Lf523Ti0OtcNgxP(k4w2OHEX8lyWnM7baZsoUhGJ5FCQ)
	haq1bHZINPE58uoBFnKfTSO2ik4 = [hXB0vKVQ5PRI91SDTprMdfuHEm4+HHoGx7Flus60(u"ࠫࡔ࡝ࡎࡆࡔ࠽ࠤࠥ࠭Ჺ")+k4w2OHEX8lyWnM7baZsoUhGJ5FCQ+YYSh2J6BIrsm8]+H7wAinr4f3M8oPDFsdkIZ
	Dvi8asSrQYX5wE3KMIxT91me = [Ah6NVSEFnXb8wjyO]+bQV1Gtm49uZJshH3nWXLPTYrME
	OODLkJlZCoKmrzbg2XQSGPUdInA = Eb7qJoNwOgn(e2qDYgipPmTw4KvBLnochr(u"ࠬอฮหำࠣห้๋ไโࠢส่๊์วิส࠽ࠤ࠭࠭᲻")+str(len(Dvi8asSrQYX5wE3KMIxT91me)-KBkxSYaz93pu1(u"࠴জ"))+A6dMB1FlgxVivJ2fk9C(u"࠭ࠠๆๆไ࠭ࠬ᲼"),haq1bHZINPE58uoBFnKfTSO2ik4)
	if OODLkJlZCoKmrzbg2XQSGPUdInA==-bXukYxQ4aHw: return DJ1ICpbyR2(u"ࠧࡆ࡚ࡌࡘࡤࡇࡌࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬᲽ"),[],[]
	elif OODLkJlZCoKmrzbg2XQSGPUdInA==ybdv7XcT3lxF6QezULwCAGk:
		RGPB3cEyAdFC6pxI29MHXUSgkrb = zGjD5QAkd7SO9YPcZl.argv[ybdv7XcT3lxF6QezULwCAGk]+NeO3CTLHrPfWUoIgy8Q(u"ࠨࡁࡷࡽࡵ࡫࠽ࡧࡱ࡯ࡨࡪࡸࠦ࡮ࡱࡧࡩࡂ࠺࠰࠳ࠨࡸࡶࡱࡃࠧᲾ")+Ah6NVSEFnXb8wjyO+FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠩࠩࡸࡪࡾࡴࡵ࠿ࠪᲿ")+k4w2OHEX8lyWnM7baZsoUhGJ5FCQ
		MMk8qKvcJe4fQHm3EG7diBD5.executebuiltin(wwPrSDa21lUh(u"ࠥࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡕࡱࡦࡤࡸࡪ࠮ࠢ᳀")+RGPB3cEyAdFC6pxI29MHXUSgkrb+e2qDYgipPmTw4KvBLnochr(u"ࠦ࠮ࠨ᳁"))
		return DJ1ICpbyR2(u"ࠬࡋࡘࡊࡖࡢࡅࡑࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ᳂"),[],[]
	llxFwq0CUNgQtivJzkHeGV =  Dvi8asSrQYX5wE3KMIxT91me[OODLkJlZCoKmrzbg2XQSGPUdInA]
	return hWGMqtBy4wuLaVcj,[hWGMqtBy4wuLaVcj],[llxFwq0CUNgQtivJzkHeGV]
def UN2CkoBwZe(llxFwq0CUNgQtivJzkHeGV):
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(nHBb7jXk0Daom,sULh4NjakzI8He7xJCMGrql(u"࠭ࡇࡆࡖࠪ᳃"),llxFwq0CUNgQtivJzkHeGV,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡆࡔࡑࡒࡂ࠯࠴ࡷࡹ࠭᳄"))
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	if QvgnCALNstmuUJiET(u"ࠨ࠰࡭ࡷࡴࡴࠧ᳅") in llxFwq0CUNgQtivJzkHeGV: url = trdVA0JvFaD.findall(LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠩࠥࡷࡷࡩࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ᳆"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	else: url = trdVA0JvFaD.findall(wwPrSDa21lUh(u"ࠪࡷࡴࡻࡲࡤࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ᳇"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if not url: return LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡂࡐࡍࡕࡅࠬ᳈"),[],[]
	url = url[ybdv7XcT3lxF6QezULwCAGk]
	if hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠬ࡮ࡴࡵࡲࠪ᳉") not in url: url = S1SgCFYGJeMvfp5iZXK(u"࠭ࡨࡵࡶࡳ࠾ࠬ᳊")+url
	return hWGMqtBy4wuLaVcj,[hWGMqtBy4wuLaVcj],[url]
def XM70EwYa4t2PcFKV6mHxd(url):
	headers = { HHoGx7Flus60(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ᳋") : hWGMqtBy4wuLaVcj }
	if wwPrSDa21lUh(u"ࠨࡱࡳࡁࡩࡵࡷ࡯࡮ࡲࡥࡩࡥ࡯ࡳ࡫ࡪࠫ᳌") in url:
		mMQ3FkNVa4IlxqY = f1fLNcPlo2ECKtiBeug0OAvz9YM(nHBb7jXk0Daom,url,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,zyvJMtBhrw(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡓࡏࡔࡊࡄࡌࡉࡇ࠭࠲ࡵࡷࠫ᳍"))
		items = trdVA0JvFaD.findall(wwPrSDa21lUh(u"ࠪࡨ࡮ࡸࡥࡤࡶࠣࡰ࡮ࡴ࡫࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ᳎"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if items: return hWGMqtBy4wuLaVcj,[hWGMqtBy4wuLaVcj],[items[ybdv7XcT3lxF6QezULwCAGk]]
		else:
			jjEwJpmd2v0oxBRP1Dyu = trdVA0JvFaD.findall(XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠫࡨࡲࡡࡴࡵࡀࠦࡪࡸࡲࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ᳏"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
			if jjEwJpmd2v0oxBRP1Dyu:
				BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,MMizeNH0AKu(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่์็฿ࠠศๆสู้๐ࠧ᳐"),jjEwJpmd2v0oxBRP1Dyu[ybdv7XcT3lxF6QezULwCAGk])
				return XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࠧ᳑")+jjEwJpmd2v0oxBRP1Dyu[ybdv7XcT3lxF6QezULwCAGk],[],[]
	else:
		u25Car4veWZpIhniLSUKqH83Gf = QvgnCALNstmuUJiET(u"ࠧ࡮ࡱࡹ࡭ࡿࡲࡡ࡯ࡦࠪ᳒")
		mMQ3FkNVa4IlxqY = f1fLNcPlo2ECKtiBeug0OAvz9YM(nHBb7jXk0Daom,url,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,rwQN9AKhLCuMfHxjlbX0U(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡒࡕࡓࡉࡃࡋࡈࡆ࠳࠲࡯ࡦࠪ᳓"))
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall(sULh4NjakzI8He7xJCMGrql(u"ࠩࡉࡳࡷࡳࠠ࡮ࡧࡷ࡬ࡴࡪ࠽ࠣࡒࡒࡗ࡙ࠨࠠࡢࡥࡷ࡭ࡴࡴ࠽࡝ࠩࠫ࠲࠯ࡅࠩ࡝ࠩࠫ࠲࠯ࡅࠩࡥ࡫ࡹ᳔ࠫ"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if not DJvksH7ZAFUqW9OyQnbGjPCtwR1o: return LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡓࡏࡔࡊࡄࡌࡉࡇ᳕ࠧ"),[],[]
		MDSF21x9HK3AZyGUhcb = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[ybdv7XcT3lxF6QezULwCAGk][ybdv7XcT3lxF6QezULwCAGk]
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[ybdv7XcT3lxF6QezULwCAGk][bXukYxQ4aHw]
		if QvgnCALNstmuUJiET(u"ࠫ࠳ࡸࡡࡳ᳖ࠩ") in cok5ZGXdQP7YhwtqyuaCnVevm6UB or e2qDYgipPmTw4KvBLnochr(u"ࠬ࠴ࡺࡪࡲ᳗ࠪ") in cok5ZGXdQP7YhwtqyuaCnVevm6UB: return JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡍࡐࡕࡋࡅࡍࡊࡁࠡࡐࡲࡸࠥࡧࠠࡷ࡫ࡧࡩࡴࠦࡦࡪ࡮ࡨ᳘ࠫ"),[],[]
		items = trdVA0JvFaD.findall(OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠧ࡯ࡣࡰࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡸࡤࡰࡺ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ᳙"),cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		l17Sn3hK59WV = {}
		for j4lHpxXvnF2VtwBb1T9PaJEm3,BoSjXKxz41DcneO9UimClE in items:
			l17Sn3hK59WV[j4lHpxXvnF2VtwBb1T9PaJEm3] = BoSjXKxz41DcneO9UimClE
		data = gQ5hRKULia2pdOWAxScMwTDbkl(l17Sn3hK59WV)
		mMQ3FkNVa4IlxqY = f1fLNcPlo2ECKtiBeug0OAvz9YM(nHBb7jXk0Daom,MDSF21x9HK3AZyGUhcb,data,headers,hWGMqtBy4wuLaVcj,SqrG5mU3j96ldsFpExobw40TJY(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡒࡕࡓࡉࡃࡋࡈࡆ࠳࠳ࡳࡦࠪ᳚"))
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall(NeO3CTLHrPfWUoIgy8Q(u"ࠩࡇࡳࡼࡴ࡬ࡰࡣࡧࠤ࡛࡯ࡤࡦࡱ࠱࠮ࡄ࡭ࡥࡵ࡞ࠫࡠࠬ࠮࠮ࠫࡁࠬࡠࠬ࠴ࠪࡀࡵࡲࡹࡷࡩࡥࡴ࠼ࠫ࠲࠯ࡅࠩࡪ࡯ࡤ࡫ࡪࡀࠧ᳛"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if not DJvksH7ZAFUqW9OyQnbGjPCtwR1o: return zyvJMtBhrw(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡓࡏࡔࡊࡄࡌࡉࡇ᳜ࠧ"),[],[]
		download = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[ybdv7XcT3lxF6QezULwCAGk][ybdv7XcT3lxF6QezULwCAGk]
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[ybdv7XcT3lxF6QezULwCAGk][bXukYxQ4aHw]
		items = trdVA0JvFaD.findall(A6dMB1FlgxVivJ2fk9C(u"ࠫ࡫࡯࡬ࡦ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠫ࠰ࡱࡧࡢࡦ࡮࠽ࠦ࠳࠰࠿ࠣࡾ᳝ࠬࠫ"),cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		o94WsYVfy3Nqrmg07,haq1bHZINPE58uoBFnKfTSO2ik4,rFMaDkS4jJ8uwLPV,Dvi8asSrQYX5wE3KMIxT91me,IIcxRvkntKO = [],[],[],[],[]
		for llxFwq0CUNgQtivJzkHeGV,title in items:
			if QVDJLRlxNg127jMX(u"ࠬ࠴࡭࠴ࡷ࠻᳞ࠫ") in llxFwq0CUNgQtivJzkHeGV:
				o94WsYVfy3Nqrmg07,rFMaDkS4jJ8uwLPV = b8IJFKNyPjgE4GelaCSXB6Qht(llxFwq0CUNgQtivJzkHeGV)
				Dvi8asSrQYX5wE3KMIxT91me = Dvi8asSrQYX5wE3KMIxT91me + rFMaDkS4jJ8uwLPV
				if o94WsYVfy3Nqrmg07[ybdv7XcT3lxF6QezULwCAGk]==hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"࠭࠭࠲᳟ࠩ"): haq1bHZINPE58uoBFnKfTSO2ik4.append(FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠧࠡีํีๆืࠠฯษุࠤࠬ᳠")+jeAby54c02TgG8zuivonX91(u"ࠨ࡯࠶ࡹ࠽ࠦࠧ᳡")+u25Car4veWZpIhniLSUKqH83Gf)
				else:
					for title in o94WsYVfy3Nqrmg07:
						haq1bHZINPE58uoBFnKfTSO2ik4.append(LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠩࠣื๏ืแาࠢัห᳢ฺࠦࠧ")+EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠪࡱ࠸ࡻ࠸᳣ࠡࠩ")+u25Car4veWZpIhniLSUKqH83Gf+Mpsm2VF1OBnCRvK3qf6+title)
			else:
				title = title.replace(jeAby54c02TgG8zuivonX91(u"ࠫ࠱ࡲࡡࡣࡧ࡯࠾᳤ࠧ࠭"),hWGMqtBy4wuLaVcj)
				title = title.strip(XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠬࠨ᳥ࠧ"))
				title = sULh4NjakzI8He7xJCMGrql(u"࠭ࠠิ์ิๅึࠦࠠฯษุࠤ᳦ࠬ")+FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠧࠡ࡯ࡳ࠸᳧ࠥ࠭")+u25Car4veWZpIhniLSUKqH83Gf+Mpsm2VF1OBnCRvK3qf6+title
				haq1bHZINPE58uoBFnKfTSO2ik4.append(title)
				Dvi8asSrQYX5wE3KMIxT91me.append(llxFwq0CUNgQtivJzkHeGV)
		llxFwq0CUNgQtivJzkHeGV = jeAby54c02TgG8zuivonX91(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡯ࡲࡷ࡭ࡧࡨࡥࡣ࠱ࡳࡳࡲࡩ࡯ࡧ᳨ࠪ") + download
		mMQ3FkNVa4IlxqY = f1fLNcPlo2ECKtiBeug0OAvz9YM(nHBb7jXk0Daom,llxFwq0CUNgQtivJzkHeGV,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,HHoGx7Flus60(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡓࡏࡔࡊࡄࡌࡉࡇ࠭࠶ࡶ࡫ࠫᳩ"))
		items = trdVA0JvFaD.findall(zyvJMtBhrw(u"ࠥࡨࡴࡽ࡮࡭ࡱࡤࡨࡤࡼࡩࡥࡧࡲࡠ࠭࠭ࠨ࠯ࠬࡂ࠭ࠬ࠲ࠧࠩ࠰࠭ࡃ࠮࠭ࠬࠨࠪ࠱࠮ࡄ࠯ࠧ࠯ࠬࡂࡀࡹࡪ࠾ࠩ࠰࠭ࡃ࠮࠲ࠢᳪ"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		for id,JbpxsyQVXmSEYKM3vo847Ckh,hash,DSG1hTbByNjm5AOJU8zwXC in items:
			title = sULh4NjakzI8He7xJCMGrql(u"ู๊ࠫࠥาใิࠤฯำๅ๋ๆࠣาฬ฻ࠠࠨᳫ")+KNIvHPjUbhr(u"ࠬࠦ࡭ࡱ࠶ࠣࠫᳬ")+u25Car4veWZpIhniLSUKqH83Gf+Mpsm2VF1OBnCRvK3qf6+DSG1hTbByNjm5AOJU8zwXC.split(S1SgCFYGJeMvfp5iZXK(u"࠭ࡸࠨ᳭"))[bXukYxQ4aHw]
			llxFwq0CUNgQtivJzkHeGV = CnbBKmtF1x84q7AW(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡮ࡱࡶ࡬ࡦ࡮ࡤࡢ࠰ࡲࡲࡱ࡯࡮ࡦ࠱ࡧࡰࡄࡵࡰ࠾ࡦࡲࡻࡳࡲ࡯ࡢࡦࡢࡳࡷ࡯ࡧࠧ࡫ࡧࡁࠬᳮ")+id+mkHKSQvjWr5BTcM3wVY(u"ࠨࠨࡰࡳࡩ࡫࠽ࠨᳯ")+JbpxsyQVXmSEYKM3vo847Ckh+sULh4NjakzI8He7xJCMGrql(u"ࠩࠩ࡬ࡦࡹࡨ࠾ࠩᳰ")+hash
			IIcxRvkntKO.append(DSG1hTbByNjm5AOJU8zwXC)
			haq1bHZINPE58uoBFnKfTSO2ik4.append(title)
			Dvi8asSrQYX5wE3KMIxT91me.append(llxFwq0CUNgQtivJzkHeGV)
		IIcxRvkntKO = set(IIcxRvkntKO)
		O7FGBEYp0zIiZ,FkqAd3ExPa = [],[]
		for title in haq1bHZINPE58uoBFnKfTSO2ik4:
			IVLPAxG2lSm1h3HDXz6busU5yvteRY = trdVA0JvFaD.findall(S1SgCFYGJeMvfp5iZXK(u"ࠥࠤ࠭ࡢࡤࠫࡺࡿࡠࡩ࠰ࠩࠧࠨࠥᳱ"),title+NeO3CTLHrPfWUoIgy8Q(u"ࠫࠫࠬࠧᳲ"),trdVA0JvFaD.DOTALL)
			for DSG1hTbByNjm5AOJU8zwXC in IIcxRvkntKO:
				if IVLPAxG2lSm1h3HDXz6busU5yvteRY[ybdv7XcT3lxF6QezULwCAGk] in DSG1hTbByNjm5AOJU8zwXC:
					title = title.replace(IVLPAxG2lSm1h3HDXz6busU5yvteRY[ybdv7XcT3lxF6QezULwCAGk],DSG1hTbByNjm5AOJU8zwXC.split(ITvnUAMXsyb4eO(u"ࠬࡾࠧᳳ"))[bXukYxQ4aHw])
			O7FGBEYp0zIiZ.append(title)
		for PPuqrvDLEViYOMf1dmkK7 in range(len(Dvi8asSrQYX5wE3KMIxT91me)):
			items = trdVA0JvFaD.findall(mkHKSQvjWr5BTcM3wVY(u"ࠨࠦࠧࠪ࠱࠮ࡄ࠯ࠨ࡝ࡦ࠭࠭ࠫࠬࠢ᳴"),gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠧࠧࠨࠪᳵ")+O7FGBEYp0zIiZ[PPuqrvDLEViYOMf1dmkK7]+XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠨࠨࠩࠫᳶ"),trdVA0JvFaD.DOTALL)
			FkqAd3ExPa.append( [O7FGBEYp0zIiZ[PPuqrvDLEViYOMf1dmkK7],Dvi8asSrQYX5wE3KMIxT91me[PPuqrvDLEViYOMf1dmkK7],items[ybdv7XcT3lxF6QezULwCAGk][ybdv7XcT3lxF6QezULwCAGk],items[ybdv7XcT3lxF6QezULwCAGk][bXukYxQ4aHw]] )
		FkqAd3ExPa = sorted(FkqAd3ExPa, key=lambda TehOaqr5JGDIvkfZi: TehOaqr5JGDIvkfZi[x1x9kIQo3zjZWnYaiy], reverse=VBlawK4mgHSyLEn8iqhUkz5)
		FkqAd3ExPa = sorted(FkqAd3ExPa, key=lambda TehOaqr5JGDIvkfZi: TehOaqr5JGDIvkfZi[Y0XZKGRAUQj5O], reverse=fEXMiAyG3ql4vKB)
		haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = [],[]
		for PPuqrvDLEViYOMf1dmkK7 in range(len(FkqAd3ExPa)):
			haq1bHZINPE58uoBFnKfTSO2ik4.append(FkqAd3ExPa[PPuqrvDLEViYOMf1dmkK7][ybdv7XcT3lxF6QezULwCAGk])
			Dvi8asSrQYX5wE3KMIxT91me.append(FkqAd3ExPa[PPuqrvDLEViYOMf1dmkK7][bXukYxQ4aHw])
	if len(Dvi8asSrQYX5wE3KMIxT91me)==ybdv7XcT3lxF6QezULwCAGk: return mkHKSQvjWr5BTcM3wVY(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡒࡕࡓࡉࡃࡋࡈࡆ࠭᳷"),[],[]
	return hWGMqtBy4wuLaVcj,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me
def MgAQuU38ZJsFlP1cdrW6Xx(url):
	LLsGB1FPiUTyYrdwqf86eHAnQ = url.split(dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠪࡃࠬ᳸"))
	NPM3HKQ57xe = LLsGB1FPiUTyYrdwqf86eHAnQ[ybdv7XcT3lxF6QezULwCAGk]
	headers = { KBkxSYaz93pu1(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ᳹") : hWGMqtBy4wuLaVcj }
	mMQ3FkNVa4IlxqY = f1fLNcPlo2ECKtiBeug0OAvz9YM(nHBb7jXk0Daom,NPM3HKQ57xe,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡇ࠸ࡘࡘࡇࡒ࠮࠳ࡶࡸࠬᳺ"))
	items = trdVA0JvFaD.findall(JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"࠭ࡐ࡭ࡧࡤࡷࡪࠦࡷࡢ࡫ࡷ࠲࠯ࡅࡨࡳࡧࡩࡁࡡ࠭ࠨ࠯ࠬࡂ࠭ࡡ࠭ࠧ᳻"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	url = items[ybdv7XcT3lxF6QezULwCAGk]
	return mkHKSQvjWr5BTcM3wVY(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ᳼"),[hWGMqtBy4wuLaVcj],[url]
def TteuHca5Q9SwRBCNlAUfqGp2hKOs(url):
	haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = [],[]
	headers = { QVDJLRlxNg127jMX(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ᳽") : hWGMqtBy4wuLaVcj }
	mMQ3FkNVa4IlxqY = f1fLNcPlo2ECKtiBeug0OAvz9YM(DpQifS0oKBI1hYcO,url,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡌࡁࡄࡗࡏࡘ࡞ࡈࡏࡐࡍࡖ࠱࠶ࡹࡴࠨ᳾"))
	NPM3HKQ57xe = trdVA0JvFaD.findall(gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠪࡶࡪࡪࡩࡳࡧࡦࡸࡤࡻࡲ࡭࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ᳿"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if NPM3HKQ57xe: return hWGMqtBy4wuLaVcj,[hWGMqtBy4wuLaVcj],[NPM3HKQ57xe[ybdv7XcT3lxF6QezULwCAGk]]
	else: return EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡂࡖ࡜࡝࡚ࡗࡒࠧᴀ"),[],[]
def SLDMHOU8Zat1glC(url):
	haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = [],[]
	headers = { EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩᴁ") : hWGMqtBy4wuLaVcj }
	mMQ3FkNVa4IlxqY = f1fLNcPlo2ECKtiBeug0OAvz9YM(DpQifS0oKBI1hYcO,url,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,ITvnUAMXsyb4eO(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡉࡅࡈ࡛ࡌࡕ࡛ࡅࡓࡔࡑࡓ࠮࠳ࡶࡸࠬᴂ"))
	NPM3HKQ57xe = trdVA0JvFaD.findall(OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠧࡩࡴࡨࡪࠧ࠲ࠢࠩࡪࡷࡸ࠳࠰࠿ࠪࠤࠪᴃ"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if NPM3HKQ57xe: return hWGMqtBy4wuLaVcj,[hWGMqtBy4wuLaVcj],[NPM3HKQ57xe[ybdv7XcT3lxF6QezULwCAGk]]
	else: return sULh4NjakzI8He7xJCMGrql(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡊࡆࡉࡕࡍࡖ࡜ࡆࡔࡕࡋࡔࠩᴄ"),[],[]
def rrhQGPlFcs(url):
	haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me,errno = [],[],hWGMqtBy4wuLaVcj
	if EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠩ࠲ࡻࡵ࠳ࡡࡥ࡯࡬ࡲ࠴࠭ᴅ") in url:
		NPM3HKQ57xe,OucJVrWRKSqDChiG7yn3oz0dafZF = fWM9y4vTcPLS0b3UKItC1os5(url)
		PwvNmnqXKrYVZugB5c8 = {zyvJMtBhrw(u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩᴆ"):sULh4NjakzI8He7xJCMGrql(u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦ࠾ࠤࡨ࡮ࡡࡳࡵࡨࡸࡂ࡛ࡔࡇ࠯࠻ࠫᴇ")}
		sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(nHBb7jXk0Daom,KBkxSYaz93pu1(u"ࠬࡖࡏࡔࡖࠪᴈ"),NPM3HKQ57xe,OucJVrWRKSqDChiG7yn3oz0dafZF,PwvNmnqXKrYVZugB5c8,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡉࡅࡏࡋࡒࡔࡊࡒ࡛࠲࠸࡮ࡥࠩᴉ"))
		eecmFXt5SRyCjGpx = sDQvwGASB0Vf67mik.content
		if eecmFXt5SRyCjGpx.startswith(zyvJMtBhrw(u"ࠧࡩࡶࡷࡴࠬᴊ")): NPM3HKQ57xe = eecmFXt5SRyCjGpx
		else:
			CMzQFXeI08KDwAJ9p = trdVA0JvFaD.findall(xcChIL13BpR8WArNt9Pl0So(u"ࠨࠩࠪࡷࡷࡩ࠽࡜ࠩࠥࡡ࠭࠴ࠪࡀࠫ࡞ࠫࠧࡣࠧࠨࠩᴋ"),eecmFXt5SRyCjGpx,trdVA0JvFaD.DOTALL)
			if CMzQFXeI08KDwAJ9p:
				NPM3HKQ57xe = CMzQFXeI08KDwAJ9p[ybdv7XcT3lxF6QezULwCAGk]
				CMzQFXeI08KDwAJ9p = trdVA0JvFaD.findall(GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠩࡶࡳࡺࡸࡣࡦ࠿ࠫ࠲࠯ࡅࠩ࡜ࠨࠧࡡࠬᴌ"),NPM3HKQ57xe,trdVA0JvFaD.DOTALL)
				if CMzQFXeI08KDwAJ9p:
					NPM3HKQ57xe = jkiCS0UWs2dNAJcGKn6mbHD(CMzQFXeI08KDwAJ9p[ybdv7XcT3lxF6QezULwCAGk])
					return hWGMqtBy4wuLaVcj,[hWGMqtBy4wuLaVcj],[NPM3HKQ57xe]
	elif LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠪ࠳ࡱ࡯࡮࡬ࡵ࠲ࠫᴍ") in url:
		sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(nHBb7jXk0Daom,S1SgCFYGJeMvfp5iZXK(u"ࠫࡌࡋࡔࠨᴎ"),url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,VBlawK4mgHSyLEn8iqhUkz5,hWGMqtBy4wuLaVcj,mkHKSQvjWr5BTcM3wVY(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡈࡄࡎࡊࡘࡓࡉࡑ࡚࠱࠶ࡹࡴࠨᴏ"))
		eecmFXt5SRyCjGpx = sDQvwGASB0Vf67mik.content
		if GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨᴐ") in list(sDQvwGASB0Vf67mik.headers.keys()): NPM3HKQ57xe = sDQvwGASB0Vf67mik.headers[ITvnUAMXsyb4eO(u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩᴑ")]
		else: NPM3HKQ57xe = trdVA0JvFaD.findall(XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠨ࡫ࡧࡁࠧࡲࡩ࡯࡭ࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᴒ"),eecmFXt5SRyCjGpx,trdVA0JvFaD.DOTALL)[ybdv7XcT3lxF6QezULwCAGk]
	if CnbBKmtF1x84q7AW(u"ࠩ࠲ࡺ࠴࠭ᴓ") in NPM3HKQ57xe or DJ1ICpbyR2(u"ࠪ࠳࡫࠵ࠧᴔ") in NPM3HKQ57xe:
		NPM3HKQ57xe = NPM3HKQ57xe.replace(zyvJMtBhrw(u"ࠫ࠴࡬࠯ࠨᴕ"),o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠬ࠵ࡡࡱ࡫࠲ࡷࡴࡻࡲࡤࡧ࠲ࠫᴖ"))
		NPM3HKQ57xe = NPM3HKQ57xe.replace(xcChIL13BpR8WArNt9Pl0So(u"࠭࠯ࡷ࠱ࠪᴗ"),LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠧ࠰ࡣࡳ࡭࠴ࡹ࡯ࡶࡴࡦࡩ࠴࠭ᴘ"))
		sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(nHBb7jXk0Daom,gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠨࡒࡒࡗ࡙࠭ᴙ"),NPM3HKQ57xe,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡌࡁࡋࡇࡕࡗࡍࡕࡗ࠮࠵ࡵࡨࠬᴚ"))
		eecmFXt5SRyCjGpx = sDQvwGASB0Vf67mik.content
		items = trdVA0JvFaD.findall(jeAby54c02TgG8zuivonX91(u"ࠪࠦ࡫࡯࡬ࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠰ࠧࡲࡡࡣࡧ࡯ࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᴛ"),eecmFXt5SRyCjGpx,trdVA0JvFaD.DOTALL)
		if items:
			for llxFwq0CUNgQtivJzkHeGV,title in items:
				llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV.replace(NeO3CTLHrPfWUoIgy8Q(u"ࠫࡡࡢࠧᴜ"),hWGMqtBy4wuLaVcj)
				haq1bHZINPE58uoBFnKfTSO2ik4.append(title)
				Dvi8asSrQYX5wE3KMIxT91me.append(llxFwq0CUNgQtivJzkHeGV)
		else:
			items = trdVA0JvFaD.findall(S1SgCFYGJeMvfp5iZXK(u"ࠬࠨࡦࡪ࡮ࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᴝ"),eecmFXt5SRyCjGpx,trdVA0JvFaD.DOTALL)
			if items:
				llxFwq0CUNgQtivJzkHeGV = items[ybdv7XcT3lxF6QezULwCAGk]
				llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV.replace(QVDJLRlxNg127jMX(u"࠭࡜࡝ࠩᴞ"),hWGMqtBy4wuLaVcj)
				haq1bHZINPE58uoBFnKfTSO2ik4.append(hWGMqtBy4wuLaVcj)
				Dvi8asSrQYX5wE3KMIxT91me.append(llxFwq0CUNgQtivJzkHeGV)
	else: return EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪᴟ"),[hWGMqtBy4wuLaVcj],[NPM3HKQ57xe]
	if len(Dvi8asSrQYX5wE3KMIxT91me)==ybdv7XcT3lxF6QezULwCAGk: return FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡊࡆࡐࡅࡓࡕࡋࡓ࡜࠭ᴠ"),[],[]
	return hWGMqtBy4wuLaVcj,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me
def N2yYhKoErg(url):
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(nHBb7jXk0Daom,KNIvHPjUbhr(u"ࠩࡊࡉ࡙࠭ᴡ"),url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,KBkxSYaz93pu1(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡍࡐࡘࡖ࠸࡚࠳࠱ࡴࡶࠪᴢ"))
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me,errno = [],[],hWGMqtBy4wuLaVcj
	if A6dMB1FlgxVivJ2fk9C(u"ࠫࡵࡲࡡࡺࡧࡵࡣࡪࡳࡢࡦࡦ࠱ࡴ࡭ࡶࠧᴣ") in url or A6dMB1FlgxVivJ2fk9C(u"ࠬ࠵ࡥ࡮ࡤࡨࡨ࠴࠭ᴤ") in url:
		if EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"࠭ࡰ࡭ࡣࡼࡩࡷࡥࡥ࡮ࡤࡨࡨ࠳ࡶࡨࡱࠩᴥ") in url:
			NPM3HKQ57xe = trdVA0JvFaD.findall(QvgnCALNstmuUJiET(u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᴦ"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
			NPM3HKQ57xe = NPM3HKQ57xe[ybdv7XcT3lxF6QezULwCAGk]
		else: NPM3HKQ57xe = url
		if xcChIL13BpR8WArNt9Pl0So(u"ࠨ࡯ࡲࡺࡸ࠺ࡵࠨᴧ") not in NPM3HKQ57xe: return rwQN9AKhLCuMfHxjlbX0U(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬᴨ"),[hWGMqtBy4wuLaVcj],[NPM3HKQ57xe]
		sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(nHBb7jXk0Daom,wwPrSDa21lUh(u"ࠪࡋࡊ࡚ࠧᴩ"),NPM3HKQ57xe,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,wwPrSDa21lUh(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡎࡑ࡙ࡗ࠹࡛࠭࠳ࡰࡧࠫᴪ"))
		mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall(LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠬ࡯ࡤ࠾ࠤࡳࡰࡦࡿࡥࡳࠤࠫ࠲࠯ࡅࠩࡷ࡫ࡧࡩࡴࡰࡳࠨᴫ"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[ybdv7XcT3lxF6QezULwCAGk]
		items = trdVA0JvFaD.findall(EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"࠭࠼ࡴࡱࡸࡶࡨ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࡭ࡣࡥࡩࡱࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᴬ"),cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		if items:
			for llxFwq0CUNgQtivJzkHeGV,h4s5qao1CX in items:
				haq1bHZINPE58uoBFnKfTSO2ik4.append(h4s5qao1CX)
				Dvi8asSrQYX5wE3KMIxT91me.append(llxFwq0CUNgQtivJzkHeGV)
	elif OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠧ࡮ࡣ࡬ࡲࡤࡶ࡬ࡢࡻࡨࡶ࠳ࡶࡨࡱࠩᴭ") in url:
		NPM3HKQ57xe = trdVA0JvFaD.findall(CnbBKmtF1x84q7AW(u"ࠨࡷࡵࡰࡂ࠮࠮ࠫࡁࠬࠦࠬᴮ"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		NPM3HKQ57xe = NPM3HKQ57xe[ybdv7XcT3lxF6QezULwCAGk]
		sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(nHBb7jXk0Daom,CnbBKmtF1x84q7AW(u"ࠩࡊࡉ࡙࠭ᴯ"),NPM3HKQ57xe,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡍࡐࡘࡖ࠸࡚࠳࠳ࡳࡦࠪᴰ"))
		mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
		CMzQFXeI08KDwAJ9p = trdVA0JvFaD.findall(LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠫࠧ࡬ࡩ࡭ࡧࠥ࠾ࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᴱ"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		CMzQFXeI08KDwAJ9p = CMzQFXeI08KDwAJ9p[ybdv7XcT3lxF6QezULwCAGk]
		haq1bHZINPE58uoBFnKfTSO2ik4.append(hWGMqtBy4wuLaVcj)
		Dvi8asSrQYX5wE3KMIxT91me.append(CMzQFXeI08KDwAJ9p)
	elif gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡟࡭࡫ࡱ࡯ࠬᴲ") in url:
		NPM3HKQ57xe = trdVA0JvFaD.findall(OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"࠭࠼ࡤࡧࡱࡸࡪࡸ࠾࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᴳ"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if NPM3HKQ57xe:
			NPM3HKQ57xe = NPM3HKQ57xe[ybdv7XcT3lxF6QezULwCAGk]
			return DJ1ICpbyR2(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪᴴ"),[hWGMqtBy4wuLaVcj],[NPM3HKQ57xe]
	if len(Dvi8asSrQYX5wE3KMIxT91me)==ybdv7XcT3lxF6QezULwCAGk: return XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡑࡔ࡜ࡓ࠵ࡗࠪᴵ"),[],[]
	return hWGMqtBy4wuLaVcj,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me
def n6xPM2Olgc(url):
	if sULh4NjakzI8He7xJCMGrql(u"ࠩࡂ࡫ࡪࡺ࠽ࠨᴶ") in url:
		llxFwq0CUNgQtivJzkHeGV = url.split(S1SgCFYGJeMvfp5iZXK(u"ࠪࡃ࡬࡫ࡴ࠾ࠩᴷ"),bXukYxQ4aHw)[bXukYxQ4aHw]
		llxFwq0CUNgQtivJzkHeGV = FxG0Q9kuBSmTyM.b64decode(llxFwq0CUNgQtivJzkHeGV)
		if H4qZ2hwilNJYTmCFEQyaSs98cPM0gR: llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV.decode(a7VXeDU82IfQEnPZAdiT,GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠫ࡮࡭࡮ࡰࡴࡨࠫᴸ"))
		return mkHKSQvjWr5BTcM3wVY(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨᴹ"),[hWGMqtBy4wuLaVcj],[llxFwq0CUNgQtivJzkHeGV]
	website = u6rbxnyjTl7I[JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡂࠨᴺ")][ybdv7XcT3lxF6QezULwCAGk]
	headers = {NeO3CTLHrPfWUoIgy8Q(u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨᴻ"):website}
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(lke5D6CpaAXPdEZyrBSw7T,DJ1ICpbyR2(u"ࠨࡉࡈࡘࠬᴼ"),url,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡉࡉࡎࡃࡆࡐ࡚ࡈ࠭࠳ࡰࡧࠫᴽ"))
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	SODQ7qlNYoZcFK8e50rBsJaAHxiXjE = RRNODILCtGzvgpx(url,HHoGx7Flus60(u"ࠪࡹࡷࡲࠧᴾ"))
	llxFwq0CUNgQtivJzkHeGV = trdVA0JvFaD.findall(dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩࡃ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᴿ"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if not llxFwq0CUNgQtivJzkHeGV: llxFwq0CUNgQtivJzkHeGV = trdVA0JvFaD.findall(LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠧࡹ࡯ࡶࡴࡦࡩࡸࡀࠠ࡝࡝ࠪࠬ࠳࠰࠿ࠪࠩࠥᵀ"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if not llxFwq0CUNgQtivJzkHeGV: llxFwq0CUNgQtivJzkHeGV = trdVA0JvFaD.findall(QVDJLRlxNg127jMX(u"ࠨࡦࡪ࡮ࡨ࠾ࠬ࠮࠮ࠫࡁࠬࠫࠧᵁ"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if llxFwq0CUNgQtivJzkHeGV:
		llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV[ybdv7XcT3lxF6QezULwCAGk]+KBkxSYaz93pu1(u"ࠧࡽࡔࡨࡪࡪࡸࡥࡳ࠿ࠪᵂ")+website
		return hWGMqtBy4wuLaVcj,[hWGMqtBy4wuLaVcj],[llxFwq0CUNgQtivJzkHeGV]
	if DJ1ICpbyR2(u"ࠨࡰࡤࡱࡪࡃ࡙ࠢࡶࡲ࡯ࡪࡴࠢࠨᵃ") in mMQ3FkNVa4IlxqY:
		OsRFCWSxw04zDaLmY = trdVA0JvFaD.findall(hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠩࡱࡥࡲ࡫࠽࡚ࠣࡷࡳࡰ࡫࡮ࠣࠢࡦࡳࡳࡺࡥ࡯ࡶࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᵄ"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if OsRFCWSxw04zDaLmY:
			llxFwq0CUNgQtivJzkHeGV = OsRFCWSxw04zDaLmY[ybdv7XcT3lxF6QezULwCAGk]
			llxFwq0CUNgQtivJzkHeGV = FxG0Q9kuBSmTyM.b64decode(llxFwq0CUNgQtivJzkHeGV)
			if H4qZ2hwilNJYTmCFEQyaSs98cPM0gR: llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV.decode(a7VXeDU82IfQEnPZAdiT,ITvnUAMXsyb4eO(u"ࠪ࡭࡬ࡴ࡯ࡳࡧࠪᵅ"))
			llxFwq0CUNgQtivJzkHeGV = trdVA0JvFaD.findall(ITvnUAMXsyb4eO(u"ࠫ࡭ࡺࡴࡱ࠰࠭ࡃ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠬࠨᵆ"),llxFwq0CUNgQtivJzkHeGV,trdVA0JvFaD.DOTALL)
			if llxFwq0CUNgQtivJzkHeGV:
				llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV[ybdv7XcT3lxF6QezULwCAGk]+QvgnCALNstmuUJiET(u"ࠬࢂࡒࡦࡨࡨࡶࡪࡸ࠽ࠨᵇ")+website
				return hWGMqtBy4wuLaVcj,[hWGMqtBy4wuLaVcj],[llxFwq0CUNgQtivJzkHeGV]
	return gDuGMR3z1aV6YdLmCpiO8Kl(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩᵈ"),[hWGMqtBy4wuLaVcj],[url]
def Ojbi3BT8p2(url,JPl40rDFqybV9H2Wxi1):
	HHAWYIZauqLrJBitcneTljf7,zmDKurMJwj6fi = [],[]
	if gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠧ࠰࠳࠲ࠫᵉ") in url:
		llxFwq0CUNgQtivJzkHeGV = url.replace(HHoGx7Flus60(u"ࠨ࠱࠴࠳ࠬᵊ"),LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠩ࠲࠸࠴࠭ᵋ"))
		sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(lke5D6CpaAXPdEZyrBSw7T,HHoGx7Flus60(u"ࠪࡋࡊ࡚ࠧᵌ"),llxFwq0CUNgQtivJzkHeGV,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,fEXMiAyG3ql4vKB,hWGMqtBy4wuLaVcj,SqrG5mU3j96ldsFpExobw40TJY(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆࡉ࡜ࡆࡊ࡙ࡔ࠲࠯࠴ࡷࡹ࠭ᵍ"))
		eecmFXt5SRyCjGpx = sDQvwGASB0Vf67mik.content
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall(jeAby54c02TgG8zuivonX91(u"ࠬࡂࡶࡪࡦࡨࡳ࠭࠴ࠪࡀࠫ࠿࠳ࡻ࡯ࡤࡦࡱࡁࠫᵎ"),eecmFXt5SRyCjGpx,trdVA0JvFaD.DOTALL)
		if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
			cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[ybdv7XcT3lxF6QezULwCAGk]
			items = trdVA0JvFaD.findall(KBkxSYaz93pu1(u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡪࡼࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᵏ"),cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
			for llxFwq0CUNgQtivJzkHeGV,QS8ZdxkHD5bjU9qsn4zMYaPrg3h7 in items:
				if llxFwq0CUNgQtivJzkHeGV not in zmDKurMJwj6fi:
					zmDKurMJwj6fi.append(llxFwq0CUNgQtivJzkHeGV)
					SODQ7qlNYoZcFK8e50rBsJaAHxiXjE = RRNODILCtGzvgpx(llxFwq0CUNgQtivJzkHeGV,ITvnUAMXsyb4eO(u"ࠧ࡯ࡣࡰࡩࠬᵐ"))
					HHAWYIZauqLrJBitcneTljf7.append(SODQ7qlNYoZcFK8e50rBsJaAHxiXjE+FqcVAkh7WjIXHdDKf8nvuyRo+QS8ZdxkHD5bjU9qsn4zMYaPrg3h7)
			return hWGMqtBy4wuLaVcj,HHAWYIZauqLrJBitcneTljf7,zmDKurMJwj6fi
	elif CnbBKmtF1x84q7AW(u"ࠨ࠱ࡧ࠳ࠬᵑ") in url:
		sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(lke5D6CpaAXPdEZyrBSw7T,rwQN9AKhLCuMfHxjlbX0U(u"ࠩࡊࡉ࡙࠭ᵒ"),url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,QvgnCALNstmuUJiET(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅࡈ࡛ࡅࡉࡘ࡚࠱࠮࠴ࡱࡨࠬᵓ"))
		eecmFXt5SRyCjGpx = sDQvwGASB0Vf67mik.content
		llxFwq0CUNgQtivJzkHeGV = trdVA0JvFaD.findall(EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠫࡁ࡯ࡦࡳࡣࡰࡩ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᵔ"),eecmFXt5SRyCjGpx,trdVA0JvFaD.DOTALL)
		if llxFwq0CUNgQtivJzkHeGV:
			llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV[ybdv7XcT3lxF6QezULwCAGk].replace(QvgnCALNstmuUJiET(u"ࠬ࠵࠱࠰ࠩᵕ"),SqrG5mU3j96ldsFpExobw40TJY(u"࠭࠯࠵࠱ࠪᵖ"))
			sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(lke5D6CpaAXPdEZyrBSw7T,OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠧࡈࡇࡗࠫᵗ"),llxFwq0CUNgQtivJzkHeGV,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,fEXMiAyG3ql4vKB,hWGMqtBy4wuLaVcj,LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡊࡍ࡙ࡃࡇࡖࡘ࠶࠳࠳ࡳࡦࠪᵘ"))
			eecmFXt5SRyCjGpx = sDQvwGASB0Vf67mik.content
			llxFwq0CUNgQtivJzkHeGV = trdVA0JvFaD.findall(xcChIL13BpR8WArNt9Pl0So(u"ࠩࡦࡰࡦࡹࡳ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᵙ"),eecmFXt5SRyCjGpx,trdVA0JvFaD.DOTALL)
			if llxFwq0CUNgQtivJzkHeGV: return CnbBKmtF1x84q7AW(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ᵚ"),[hWGMqtBy4wuLaVcj],[llxFwq0CUNgQtivJzkHeGV[ybdv7XcT3lxF6QezULwCAGk]]
	elif GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠫ࠴ࡸ࡯࡭ࡧ࠲ࠫᵛ") in url:
		headers = {LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭ᵜ"):JPl40rDFqybV9H2Wxi1}
		sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(nHBb7jXk0Daom,KNIvHPjUbhr(u"࠭ࡇࡆࡖࠪᵝ"),url,hWGMqtBy4wuLaVcj,headers,fEXMiAyG3ql4vKB,hWGMqtBy4wuLaVcj,QVDJLRlxNg127jMX(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡉࡌ࡟ࡂࡆࡕࡗ࠵࠲࠺ࡴࡩࠩᵞ"))
		llxFwq0CUNgQtivJzkHeGV = sDQvwGASB0Vf67mik.headers[QVDJLRlxNg127jMX(u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪᵟ")]
		sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(nHBb7jXk0Daom,mkHKSQvjWr5BTcM3wVY(u"ࠩࡊࡉ࡙࠭ᵠ"),llxFwq0CUNgQtivJzkHeGV,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,NeO3CTLHrPfWUoIgy8Q(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅࡈ࡛ࡅࡉࡘ࡚࠱࠮࠷ࡷ࡬ࠬᵡ"))
		mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
		pxdY8tiazyJIq,HHAWYIZauqLrJBitcneTljf7,zmDKurMJwj6fi = UfyPgEMvCS1c5zewKB(llxFwq0CUNgQtivJzkHeGV,mMQ3FkNVa4IlxqY)
		return pxdY8tiazyJIq,HHAWYIZauqLrJBitcneTljf7,zmDKurMJwj6fi
	elif JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠫ࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠯ࠨᵢ") in url:
		NPM3HKQ57xe = url.replace(e2qDYgipPmTw4KvBLnochr(u"ࠬ࠵ࡤࡰࡹࡱࡰࡴࡧࡤ࠰ࠩᵣ"),mkHKSQvjWr5BTcM3wVY(u"࠭࠯ࡴࡥࡵ࡭ࡵࡺ࠯ࠨᵤ"))
		PwvNmnqXKrYVZugB5c8 = {DJ1ICpbyR2(u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨᵥ"):JPl40rDFqybV9H2Wxi1}
		sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(nHBb7jXk0Daom,jeAby54c02TgG8zuivonX91(u"ࠨࡉࡈࡘࠬᵦ"),NPM3HKQ57xe,hWGMqtBy4wuLaVcj,PwvNmnqXKrYVZugB5c8,fEXMiAyG3ql4vKB,hWGMqtBy4wuLaVcj,jeAby54c02TgG8zuivonX91(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡋࡇ࡚ࡄࡈࡗ࡙࠷࠭࠷ࡶ࡫ࠫᵧ"))
		mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
		llxFwq0CUNgQtivJzkHeGV = trdVA0JvFaD.findall(dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠪࡀ࡮࡬ࡲࡢ࡯ࡨ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᵨ"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if llxFwq0CUNgQtivJzkHeGV:
			llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV[ybdv7XcT3lxF6QezULwCAGk]
			sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(nHBb7jXk0Daom,S1SgCFYGJeMvfp5iZXK(u"ࠫࡌࡋࡔࠨᵩ"),llxFwq0CUNgQtivJzkHeGV,hWGMqtBy4wuLaVcj,PwvNmnqXKrYVZugB5c8,fEXMiAyG3ql4vKB,hWGMqtBy4wuLaVcj,EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡇࡊ࡝ࡇࡋࡓࡕ࠳࠰࠻ࡹ࡮ࠧᵪ"))
			mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
			if A6dMB1FlgxVivJ2fk9C(u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨᵫ") in list(sDQvwGASB0Vf67mik.headers.keys()):
				llxFwq0CUNgQtivJzkHeGV = sDQvwGASB0Vf67mik.headers[HHoGx7Flus60(u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩᵬ")]
				sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(nHBb7jXk0Daom,LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠨࡉࡈࡘࠬᵭ"),llxFwq0CUNgQtivJzkHeGV,hWGMqtBy4wuLaVcj,PwvNmnqXKrYVZugB5c8,fEXMiAyG3ql4vKB,hWGMqtBy4wuLaVcj,A6dMB1FlgxVivJ2fk9C(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡋࡇ࡚ࡄࡈࡗ࡙࠷࠭࠹ࡶ࡫ࠫᵮ"))
				mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
				pxdY8tiazyJIq,HHAWYIZauqLrJBitcneTljf7,zmDKurMJwj6fi = UfyPgEMvCS1c5zewKB(llxFwq0CUNgQtivJzkHeGV,mMQ3FkNVa4IlxqY)
				if zmDKurMJwj6fi: return pxdY8tiazyJIq,HHAWYIZauqLrJBitcneTljf7,zmDKurMJwj6fi
			elif ITvnUAMXsyb4eO(u"ࠪ࠳ࡪࡳࡢࡦࡦ࠱ࡴ࡭ࡶ࠿ࡪࡦࡀࠫᵯ") in llxFwq0CUNgQtivJzkHeGV:
				llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV.replace(xcChIL13BpR8WArNt9Pl0So(u"ࠫ࠴࡫࡭ࡣࡧࡧ࠲ࡵ࡮ࡰࡀ࡫ࡧࡁࠬᵰ"),LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠬ࠵ࡪࡸࡲ࡯ࡥࡾ࡫ࡲ࠯ࡲ࡫ࡴࡄ࡯ࡤ࠾ࠩᵱ"))
				return zyvJMtBhrw(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩᵲ"),[hWGMqtBy4wuLaVcj],[llxFwq0CUNgQtivJzkHeGV]
	else: return QvgnCALNstmuUJiET(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪᵳ"),[hWGMqtBy4wuLaVcj],[url]
	return XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡉࡌ࡟ࡂࡆࡕࡗ࠵ࠬᵴ"),[],[]
def CtRiO8neuX(url):
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(lke5D6CpaAXPdEZyrBSw7T,NeO3CTLHrPfWUoIgy8Q(u"ࠩࡊࡉ࡙࠭ᵵ"),url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅࡈ࡛ࡅࡉࡘ࡚࠳࠮࠳ࡶࡸࠬᵶ"))
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	data = trdVA0JvFaD.findall(ITvnUAMXsyb4eO(u"ࠫࠧࡧࡣࡵ࡫ࡲࡲࠧ࠴ࠪࡀࡸࡤࡰࡺ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡺࡦࡲࡵࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡼࡡ࡭ࡷࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᵷ"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if data:
		K2hpDdmRLS0nwlZ9vH4EY,id,EEuB0QZ6IN = data[ybdv7XcT3lxF6QezULwCAGk]
		data = KBkxSYaz93pu1(u"ࠬࡵࡰ࠾ࠩᵸ")+K2hpDdmRLS0nwlZ9vH4EY+ITvnUAMXsyb4eO(u"࠭ࠦࡪࡦࡀࠫᵹ")+id+FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠧࠧࡨࡱࡥࡲ࡫࠽ࠨᵺ")+EEuB0QZ6IN
		headers = {sULh4NjakzI8He7xJCMGrql(u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧᵻ"):KBkxSYaz93pu1(u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤࠨᵼ")}
		sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(lke5D6CpaAXPdEZyrBSw7T,KBkxSYaz93pu1(u"ࠪࡔࡔ࡙ࡔࠨᵽ"),url,data,headers,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,wwPrSDa21lUh(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆࡉ࡜ࡆࡊ࡙ࡔ࠴࠯࠵ࡲࡩ࠭ᵾ"))
		mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
		llxFwq0CUNgQtivJzkHeGV = trdVA0JvFaD.findall(XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠬࠨࡲࡦࡨࡨࡶࡪࡸࠢࠡࡸࡤࡰࡺ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᵿ"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if llxFwq0CUNgQtivJzkHeGV: return KBkxSYaz93pu1(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩᶀ"),[hWGMqtBy4wuLaVcj],[llxFwq0CUNgQtivJzkHeGV[ybdv7XcT3lxF6QezULwCAGk]]
	return rwQN9AKhLCuMfHxjlbX0U(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡈࡋ࡞ࡈࡅࡔࡖ࠴ࠫᶁ"),[],[]
def jwnTvOI7lZ(url):
	headers = {SqrG5mU3j96ldsFpExobw40TJY(u"ࠨ࡚࠰ࡖࡪࡷࡵࡦࡵࡷࡩࡩ࠳ࡗࡪࡶ࡫ࠫᶂ"):o1u5dij9UrcbXzVS8lwIWfKpnqM(u"࡛ࠩࡑࡑࡎࡴࡵࡲࡕࡩࡶࡻࡥࡴࡶࠪᶃ")}
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(lke5D6CpaAXPdEZyrBSw7T,SqrG5mU3j96ldsFpExobw40TJY(u"ࠪࡋࡊ࡚ࠧᶄ"),url,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆࡉ࡜ࡆࡊ࡙ࡔ࠵࠯࠴ࡷࡹ࠭ᶅ"))
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	llxFwq0CUNgQtivJzkHeGV = trdVA0JvFaD.findall(wwPrSDa21lUh(u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᶆ"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if llxFwq0CUNgQtivJzkHeGV:
		llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV[ybdv7XcT3lxF6QezULwCAGk].replace(NXMOzZjYsmS9pf,hWGMqtBy4wuLaVcj)
		return QVDJLRlxNg127jMX(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩᶇ"),[hWGMqtBy4wuLaVcj],[llxFwq0CUNgQtivJzkHeGV]
	return KBkxSYaz93pu1(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡈࡋ࡞ࡈࡅࡔࡖ࠴ࠫᶈ"),[],[]
def yIhj3FvGAO(url):
	NPM3HKQ57xe = url.split(sULh4NjakzI8He7xJCMGrql(u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩᶉ"),bXukYxQ4aHw)[ybdv7XcT3lxF6QezULwCAGk].strip(dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠩࡂࠫᶊ")).strip(HHoGx7Flus60(u"ࠪ࠳ࠬᶋ")).strip(dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠫࠫ࠭ᶌ"))
	haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me,items,CMzQFXeI08KDwAJ9p = [],[],[],hWGMqtBy4wuLaVcj
	headers = { CnbBKmtF1x84q7AW(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩᶍ"):EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"࠭ࡍࡰࡼ࡬ࡰࡱࡧ࠯࠶࠰࠳ࠤ࠭࡝ࡩ࡯ࡦࡲࡻࡸࠦࡎࡕࠢ࠴࠴࠳࠶࠻࡙ࠡ࡬ࡲ࠻࠺࠻ࠡࡺ࠹࠸࠮࠭ᶎ") }
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(nHBb7jXk0Daom,dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠧࡈࡇࡗࠫᶏ"),NPM3HKQ57xe,hWGMqtBy4wuLaVcj,headers,VBlawK4mgHSyLEn8iqhUkz5,hWGMqtBy4wuLaVcj,JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡊࡍ࡙ࡃࡇࡖࡘ࠲࠷ࡳࡵࠩᶐ"))
	if MMizeNH0AKu(u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫᶑ") in list(sDQvwGASB0Vf67mik.headers.keys()): CMzQFXeI08KDwAJ9p = sDQvwGASB0Vf67mik.headers[sULh4NjakzI8He7xJCMGrql(u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬᶒ")]
	if OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠫ࡭ࡺࡴࡱࠩᶓ") in CMzQFXeI08KDwAJ9p:
		if QvgnCALNstmuUJiET(u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭ᶔ") in url: CMzQFXeI08KDwAJ9p = CMzQFXeI08KDwAJ9p.replace(dv0trJR7PwmKyxDYO52VLau8gEph(u"࠭࠯ࡧ࠱ࠪᶕ"),GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠧ࠰ࡸ࠲ࠫᶖ"))
		C8UYBQ1xsgOWpXANEqZFVR5f0LI = NPM3HKQ57xe.split(OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠨࡁࡓࡌࡕ࡙ࡉࡅ࠿ࠪᶗ"))[bXukYxQ4aHw]
		headers = { mkHKSQvjWr5BTcM3wVY(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ᶘ"):headers[dv0trJR7PwmKyxDYO52VLau8gEph(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧᶙ")] , rwQN9AKhLCuMfHxjlbX0U(u"ࠫࡈࡵ࡯࡬࡫ࡨࠫᶚ"):LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠬࡖࡈࡑࡕࡌࡈࡂ࠭ᶛ")+C8UYBQ1xsgOWpXANEqZFVR5f0LI }
		sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(nHBb7jXk0Daom,HHoGx7Flus60(u"࠭ࡇࡆࡖࠪᶜ"),CMzQFXeI08KDwAJ9p,hWGMqtBy4wuLaVcj,headers,fEXMiAyG3ql4vKB,hWGMqtBy4wuLaVcj,zyvJMtBhrw(u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠮ࡒࡏࡅ࡞࠳࠳ࡳࡦࠪᶝ"))
		mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
		if OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠨ࠱ࡩ࠳ࠬᶞ") in CMzQFXeI08KDwAJ9p: items = trdVA0JvFaD.findall(CnbBKmtF1x84q7AW(u"ࠩ࠿࡬࠷ࡄ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᶟ"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		elif xcChIL13BpR8WArNt9Pl0So(u"ࠪ࠳ࡻ࠵ࠧᶠ") in CMzQFXeI08KDwAJ9p: items = trdVA0JvFaD.findall(KBkxSYaz93pu1(u"ࠫ࡮ࡪ࠽ࠣࡸ࡬ࡨࡪࡵࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᶡ"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if items: return [],[hWGMqtBy4wuLaVcj],[ items[ybdv7XcT3lxF6QezULwCAGk] ]
		elif gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠬࡂࡨ࠲ࡀ࠷࠴࠹ࡂ࠯ࡩ࠳ࡁࠫᶢ") in mMQ3FkNVa4IlxqY:
			return KBkxSYaz93pu1(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦำ๋ำไีࠥอไโ์า๎ํࠦแ๋้ࠣััฮࠠืัࠣ็ํีู๊๊่ࠡิื็ࠡ็้ࠤฬ๊ล็ฬิ๊ฯࠦวๅะสูฮࠦศไࠩᶣ"),[],[]
	else: return QVDJLRlxNg127jMX(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡈࡋ࡞ࡈࡅࡔࡖࠪᶤ"),[],[]
def J3Xz2NGLxf(llxFwq0CUNgQtivJzkHeGV):
	LLsGB1FPiUTyYrdwqf86eHAnQ = trdVA0JvFaD.findall(OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠨࡲࡲࡷࡹ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠦࡴࡧࡵࡺࡪࡸࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠧࠨࠪᶥ"),llxFwq0CUNgQtivJzkHeGV+o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠩࠩࠪࠬᶦ"),trdVA0JvFaD.DOTALL|trdVA0JvFaD.IGNORECASE)
	TsFgQdloabE4YpPWV,AQFhw7Rmi9IJUoX = LLsGB1FPiUTyYrdwqf86eHAnQ[ybdv7XcT3lxF6QezULwCAGk]
	url = EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸ࡫ࡲࡪࡧࡶ࠸ࡼࡧࡴࡤࡪ࠱ࡲࡪࡺ࠯ࡢ࡬ࡤࡼࡈ࡫࡮ࡵࡧࡵࡃࡤࡧࡣࡵ࡫ࡲࡲࡂ࡭ࡥࡵࡵࡨࡶࡻ࡫ࡲࠧࡡࡳࡳࡸࡺ࡟ࡪࡦࡀࠫᶧ")+TsFgQdloabE4YpPWV+CnbBKmtF1x84q7AW(u"ࠫࠫࡹࡥࡳࡸࡨࡶ࡮ࡪ࠽ࠨᶨ")+AQFhw7Rmi9IJUoX
	headers = { OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩᶩ"):hWGMqtBy4wuLaVcj , e2qDYgipPmTw4KvBLnochr(u"࠭ࡘ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡧࡧ࠱࡜࡯ࡴࡩࠩᶪ"):rwQN9AKhLCuMfHxjlbX0U(u"࡙ࠧࡏࡏࡌࡹࡺࡰࡓࡧࡴࡹࡪࡹࡴࠨᶫ") }
	NPM3HKQ57xe = f1fLNcPlo2ECKtiBeug0OAvz9YM(nHBb7jXk0Daom,url,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,S1SgCFYGJeMvfp5iZXK(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡘࡋࡒࡊࡇࡖ࠸࡜ࡇࡔࡄࡊ࠰࠵ࡸࡺࠧᶬ"))
	return DJ1ICpbyR2(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬᶭ"),[hWGMqtBy4wuLaVcj],[NPM3HKQ57xe]
def yuDxW8TmPU(url):
	SODQ7qlNYoZcFK8e50rBsJaAHxiXjE = RRNODILCtGzvgpx(url,QVDJLRlxNg127jMX(u"ࠪࡹࡷࡲࠧᶮ"))
	PwvNmnqXKrYVZugB5c8 = {S1SgCFYGJeMvfp5iZXK(u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬᶯ"):SODQ7qlNYoZcFK8e50rBsJaAHxiXjE,FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠬࡇࡣࡤࡧࡳࡸ࠲ࡋ࡮ࡤࡱࡧ࡭ࡳ࡭ࠧᶰ"):hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"࠭ࡧࡻ࡫ࡳ࠰ࠥࡪࡥࡧ࡮ࡤࡸࡪ࠭ᶱ")}
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(D8V7AhLkSQYzo,KBkxSYaz93pu1(u"ࠧࡈࡇࡗࠫᶲ"),url,hWGMqtBy4wuLaVcj,PwvNmnqXKrYVZugB5c8,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,SqrG5mU3j96ldsFpExobw40TJY(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡒ࡟ࡃࡊࡏࡄ࠱࠶ࡹࡴࠨᶳ"))
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall(mkHKSQvjWr5BTcM3wVY(u"ࠩࡳࡰࡦࡿࡥࡳ࠰ࡴࡹࡦࡲࡩࡵࡻࡶࡩࡱ࡫ࡣࡵࡱࡵࠬ࠳࠰࠿ࠪࡨࡲࡶࡲࡧࡴࡴ࠼ࠪᶴ"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	NPM3HKQ57xe = hWGMqtBy4wuLaVcj
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[ybdv7XcT3lxF6QezULwCAGk]
		items = trdVA0JvFaD.findall(MMizeNH0AKu(u"ࠪࡪࡴࡸ࡭ࡢࡶ࠽ࠤࡡ࠭ࠨ࡝ࡦ࠱࠮ࡄ࠯࡜ࠨ࠮ࠣࡷࡷࡩ࠺ࠡࠤࠫ࠲࠯ࡅࠩࠣࠩᶵ"),cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = [],[]
		for title,llxFwq0CUNgQtivJzkHeGV in items:
			haq1bHZINPE58uoBFnKfTSO2ik4.append(title)
			Dvi8asSrQYX5wE3KMIxT91me.append(llxFwq0CUNgQtivJzkHeGV)
		if len(Dvi8asSrQYX5wE3KMIxT91me)==bXukYxQ4aHw: NPM3HKQ57xe = Dvi8asSrQYX5wE3KMIxT91me[ybdv7XcT3lxF6QezULwCAGk]
		elif len(Dvi8asSrQYX5wE3KMIxT91me)>bXukYxQ4aHw:
			OODLkJlZCoKmrzbg2XQSGPUdInA = Eb7qJoNwOgn(hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠫศิสาࠢส่๊๊แࠡษ็้๋อำษࠩᶶ"), haq1bHZINPE58uoBFnKfTSO2ik4)
			if OODLkJlZCoKmrzbg2XQSGPUdInA==-bXukYxQ4aHw: return ITvnUAMXsyb4eO(u"ࠬࡋࡘࡊࡖࡢࡅࡑࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪᶷ"),[],[]
			NPM3HKQ57xe = Dvi8asSrQYX5wE3KMIxT91me[OODLkJlZCoKmrzbg2XQSGPUdInA]
	else:
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall(LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"࠭ࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᶸ"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if DJvksH7ZAFUqW9OyQnbGjPCtwR1o: NPM3HKQ57xe = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[ybdv7XcT3lxF6QezULwCAGk]
	if not NPM3HKQ57xe: return QVDJLRlxNg127jMX(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡐ࡝ࡈࡏࡍࡂࠩᶹ"),[],[]
	return jeAby54c02TgG8zuivonX91(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫᶺ"),[hWGMqtBy4wuLaVcj],[NPM3HKQ57xe]
def jGiAk0RM3vgXCJKNm6rBIcHl(url):
	SODQ7qlNYoZcFK8e50rBsJaAHxiXjE = RRNODILCtGzvgpx(url,jeAby54c02TgG8zuivonX91(u"ࠩࡸࡶࡱ࠭ᶻ"))
	PwvNmnqXKrYVZugB5c8 = {e2qDYgipPmTw4KvBLnochr(u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫᶼ"):SODQ7qlNYoZcFK8e50rBsJaAHxiXjE,DJ1ICpbyR2(u"ࠫࡆࡩࡣࡦࡲࡷ࠱ࡊࡴࡣࡰࡦ࡬ࡲ࡬࠭ᶽ"):HHoGx7Flus60(u"ࠬ࡭ࡺࡪࡲ࠯ࠤࡩ࡫ࡦ࡭ࡣࡷࡩࠬᶾ")}
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(D8V7AhLkSQYzo,ITvnUAMXsyb4eO(u"࠭ࡇࡆࡖࠪᶿ"),url,hWGMqtBy4wuLaVcj,PwvNmnqXKrYVZugB5c8,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,xcChIL13BpR8WArNt9Pl0So(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡛ࡊࡉࡉࡎࡃ࠰࠵ࡸࡺࠧ᷀"))
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall(MMizeNH0AKu(u"ࠨࡲ࡯ࡥࡾ࡫ࡲ࠯ࡳࡸࡥࡱ࡯ࡴࡺࡵࡨࡰࡪࡩࡴࡰࡴࠫ࠲࠯ࡅࠩࡧࡱࡵࡱࡦࡺࡳ࠻ࠩ᷁"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	NPM3HKQ57xe = hWGMqtBy4wuLaVcj
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[ybdv7XcT3lxF6QezULwCAGk]
		items = trdVA0JvFaD.findall(S1SgCFYGJeMvfp5iZXK(u"ࠩࡩࡳࡷࡳࡡࡵ࠼ࠣࡠࠬ࠮࡜ࡥ࠰࠭ࡃ࠮ࡢࠧ࠭ࠢࡶࡶࡨࡀࠠࠣࠪ࠱࠮ࡄ࠯ࠢࠨ᷂"),cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = [],[]
		for title,llxFwq0CUNgQtivJzkHeGV in items:
			haq1bHZINPE58uoBFnKfTSO2ik4.append(title)
			Dvi8asSrQYX5wE3KMIxT91me.append(llxFwq0CUNgQtivJzkHeGV)
		if len(Dvi8asSrQYX5wE3KMIxT91me)==bXukYxQ4aHw: NPM3HKQ57xe = Dvi8asSrQYX5wE3KMIxT91me[ybdv7XcT3lxF6QezULwCAGk]
		elif len(Dvi8asSrQYX5wE3KMIxT91me)>bXukYxQ4aHw:
			OODLkJlZCoKmrzbg2XQSGPUdInA = Eb7qJoNwOgn(CnbBKmtF1x84q7AW(u"ࠪวำะัࠡษ็้้็ࠠศๆ่๊ฬูศࠨ᷃"), haq1bHZINPE58uoBFnKfTSO2ik4)
			if OODLkJlZCoKmrzbg2XQSGPUdInA==-bXukYxQ4aHw: return mkHKSQvjWr5BTcM3wVY(u"ࠫࡊ࡞ࡉࡕࡡࡄࡐࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ᷄"),[],[]
			NPM3HKQ57xe = Dvi8asSrQYX5wE3KMIxT91me[OODLkJlZCoKmrzbg2XQSGPUdInA]
	if not NPM3HKQ57xe:
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall(NeO3CTLHrPfWUoIgy8Q(u"ࠬࡹ࡯ࡶࡴࡦࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ᷅"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if DJvksH7ZAFUqW9OyQnbGjPCtwR1o: NPM3HKQ57xe = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[ybdv7XcT3lxF6QezULwCAGk]
	if not NPM3HKQ57xe: return dv0trJR7PwmKyxDYO52VLau8gEph(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤ࡙ࠡࡈࡇࡎࡓࡁࠨ᷆"),[],[]
	return KBkxSYaz93pu1(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ᷇"),[hWGMqtBy4wuLaVcj],[NPM3HKQ57xe]
def LezUiM6xTS(llxFwq0CUNgQtivJzkHeGV):
	LLsGB1FPiUTyYrdwqf86eHAnQ = trdVA0JvFaD.findall(KBkxSYaz93pu1(u"ࠨࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࡠࡄࡶ࡯ࡴࡶ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠪࡸ࡫ࡲࡷࡧࡵ࡭ࡩࡃࠨ࠯ࠬࡂ࠭ࠫࠬࠧ᷈"),llxFwq0CUNgQtivJzkHeGV+hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠩࠩࠪࠬ᷉"),trdVA0JvFaD.DOTALL)
	url,TsFgQdloabE4YpPWV,AQFhw7Rmi9IJUoX = LLsGB1FPiUTyYrdwqf86eHAnQ[ybdv7XcT3lxF6QezULwCAGk]
	data = {sULh4NjakzI8He7xJCMGrql(u"ࠪࡴࡴࡹࡴࡠ࡫ࡧ᷊ࠫ"):TsFgQdloabE4YpPWV,OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠫࡸ࡫ࡲࡷࡧࡵࠫ᷋"):AQFhw7Rmi9IJUoX}
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠬࡖࡏࡔࡖࠪ᷌"),url,data,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,gDuGMR3z1aV6YdLmCpiO8Kl(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡏࡔࡇࡍࡄࡃࡐ࠱࠶ࡹࡴࠨ᷍"))
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	NPM3HKQ57xe = trdVA0JvFaD.findall(MMizeNH0AKu(u"ࠧࡪࡨࡵࡥࡲ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁ᷎ࠬࠦࠬ"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)[ybdv7XcT3lxF6QezULwCAGk]
	return LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖ᷏ࠫ"),[hWGMqtBy4wuLaVcj],[NPM3HKQ57xe]
def RRDSYVUTXZ(url):
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,KBkxSYaz93pu1(u"ࠩࡊࡉ᷐࡙࠭"),url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡃࡊࡏࡄࡐࡎࡍࡈࡕ࠯࠴ࡷࡹ࠭᷑"))
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	llxFwq0CUNgQtivJzkHeGV = trdVA0JvFaD.findall(xcChIL13BpR8WArNt9Pl0So(u"ࠫࡁ࡯ࡦࡳࡣࡰࡩ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ᷒"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if llxFwq0CUNgQtivJzkHeGV:
		llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV[ybdv7XcT3lxF6QezULwCAGk]
		if llxFwq0CUNgQtivJzkHeGV: return OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨᷓ"),[hWGMqtBy4wuLaVcj],[llxFwq0CUNgQtivJzkHeGV]
	return S1SgCFYGJeMvfp5iZXK(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡅࡌࡑࡆࡒࡉࡈࡊࡗࠫᷔ"),[],[]
def gfjYczHh48(url):
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,KNIvHPjUbhr(u"ࠧࡈࡇࡗࠫᷕ"),url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,sULh4NjakzI8He7xJCMGrql(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡈࡏࡍࡂࡅࡏ࡙ࡕ࠳࠱ࡴࡶࠪᷖ"))
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	llxFwq0CUNgQtivJzkHeGV = trdVA0JvFaD.findall(sULh4NjakzI8He7xJCMGrql(u"ࠩ࠿ࡍࡋࡘࡁࡎࡇࠣࡗࡗࡉ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᷗ"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)[ybdv7XcT3lxF6QezULwCAGk]
	return LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ᷘ"),[hWGMqtBy4wuLaVcj],[llxFwq0CUNgQtivJzkHeGV]
def QvHhfzTkoM(url):
	QQUSNlXZ6MEoH1uftykesbKq2 = RRNODILCtGzvgpx(url,KBkxSYaz93pu1(u"ࠫࡺࡸ࡬ࠨᷙ"))
	if CnbBKmtF1x84q7AW(u"ࠬ࡯࡮ࡥࡧࡻࡁࠬᷚ") in url:
		headers = {KNIvHPjUbhr(u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧᷛ"):QQUSNlXZ6MEoH1uftykesbKq2}
		sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,NeO3CTLHrPfWUoIgy8Q(u"ࠧࡈࡇࡗࠫᷜ"),url,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,MMizeNH0AKu(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡈࡏࡍࡂࡐࡒ࡛࠲࠷ࡳࡵࠩᷝ"))
		mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
		NPM3HKQ57xe = trdVA0JvFaD.findall(wwPrSDa21lUh(u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᷞ"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if NPM3HKQ57xe:
			NPM3HKQ57xe = NPM3HKQ57xe[ybdv7XcT3lxF6QezULwCAGk]
			if MMizeNH0AKu(u"ࠪ࡬ࡹࡺࡰࠨᷟ") not in NPM3HKQ57xe: NPM3HKQ57xe = e2qDYgipPmTw4KvBLnochr(u"ࠫ࡭ࡺࡴࡱ࠼ࠪᷠ")+NPM3HKQ57xe
			if KNIvHPjUbhr(u"ࠬࡩࡩ࡮ࡣࡱࡳࡼ࠭ᷡ") in NPM3HKQ57xe:
				NPM3HKQ57xe = NPM3HKQ57xe.replace(jeAby54c02TgG8zuivonX91(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࠨᷢ"),SqrG5mU3j96ldsFpExobw40TJY(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࠨᷣ"))
				sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,wwPrSDa21lUh(u"ࠨࡉࡈࡘࠬᷤ"),NPM3HKQ57xe,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡉࡉࡎࡃࡑࡓ࡜࠳࠲࡯ࡦࠪᷥ"))
				eecmFXt5SRyCjGpx = sDQvwGASB0Vf67mik.content
				items = trdVA0JvFaD.findall(wwPrSDa21lUh(u"ࠪࡷࡴࡻࡲࡤࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷ࡮ࢀࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᷦ"),eecmFXt5SRyCjGpx,trdVA0JvFaD.DOTALL)
				haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = [],[]
				cbtS4iE32pOBe5rUxdfIjlXhokKMR = RRNODILCtGzvgpx(NPM3HKQ57xe,JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠫࡺࡸ࡬ࠨᷧ"))
				for llxFwq0CUNgQtivJzkHeGV,QS8ZdxkHD5bjU9qsn4zMYaPrg3h7 in reversed(items):
					llxFwq0CUNgQtivJzkHeGV = cbtS4iE32pOBe5rUxdfIjlXhokKMR+llxFwq0CUNgQtivJzkHeGV+xcChIL13BpR8WArNt9Pl0So(u"ࠬࢂࡒࡦࡨࡨࡶࡪࡸ࠽ࠨᷨ")+cbtS4iE32pOBe5rUxdfIjlXhokKMR
					haq1bHZINPE58uoBFnKfTSO2ik4.append(QS8ZdxkHD5bjU9qsn4zMYaPrg3h7)
					Dvi8asSrQYX5wE3KMIxT91me.append(llxFwq0CUNgQtivJzkHeGV)
				return hWGMqtBy4wuLaVcj,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me
			else: return MMizeNH0AKu(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩᷩ"),[hWGMqtBy4wuLaVcj],[NPM3HKQ57xe]
	NPM3HKQ57xe = url+QVDJLRlxNg127jMX(u"ࠧࡽࡔࡨࡪࡪࡸࡥࡳ࠿ࠪᷪ")+QQUSNlXZ6MEoH1uftykesbKq2
	if EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠨࡪࡷࡸࡵ࠭ᷫ") not in NPM3HKQ57xe: NPM3HKQ57xe = GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠩ࡫ࡸࡹࡶ࠺ࠨᷬ")+NPM3HKQ57xe
	return hWGMqtBy4wuLaVcj,[hWGMqtBy4wuLaVcj],[NPM3HKQ57xe]
def wxYOpvI8zrQ02V(llxFwq0CUNgQtivJzkHeGV):
	QQUSNlXZ6MEoH1uftykesbKq2 = RRNODILCtGzvgpx(llxFwq0CUNgQtivJzkHeGV,ITvnUAMXsyb4eO(u"ࠪࡹࡷࡲࠧᷭ"))
	if LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠫࡵࡵࡳࡵ࡫ࡧࠫᷮ") in llxFwq0CUNgQtivJzkHeGV:
		LLsGB1FPiUTyYrdwqf86eHAnQ = trdVA0JvFaD.findall(KBkxSYaz93pu1(u"ࠬ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩ࡝ࡁࡳࡳࡸࡺࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠧࡵࡨࡶࡻ࡫ࡲࡪࡦࡀࠬ࠳࠰࠿ࠪࠨࠩࠫᷯ"),llxFwq0CUNgQtivJzkHeGV+zyvJMtBhrw(u"࠭ࠦࠧࠩᷰ"),trdVA0JvFaD.DOTALL)
		url,TsFgQdloabE4YpPWV,AQFhw7Rmi9IJUoX = LLsGB1FPiUTyYrdwqf86eHAnQ[ybdv7XcT3lxF6QezULwCAGk]
		data = {GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠧࡪࡦࠪᷱ"):TsFgQdloabE4YpPWV,JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠨࡵࡨࡶࡻ࡫ࡲࠨᷲ"):AQFhw7Rmi9IJUoX}
		sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,S1SgCFYGJeMvfp5iZXK(u"ࠩࡓࡓࡘ࡚ࠧᷳ"),url,data,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,sULh4NjakzI8He7xJCMGrql(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡃࡊࡏࡄࡒࡔ࡝࠭࠲ࡵࡷࠫᷴ"))
		mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
		NPM3HKQ57xe = trdVA0JvFaD.findall(NeO3CTLHrPfWUoIgy8Q(u"ࠫ࡮࡬ࡲࡢ࡯ࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ᷵"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)[ybdv7XcT3lxF6QezULwCAGk]
		if QVDJLRlxNg127jMX(u"ࠬࡩࡩ࡮ࡣࡱࡳࡼ࠭᷶") in NPM3HKQ57xe:
			headers = {MMizeNH0AKu(u"࠭ࡒࡦࡨࡨࡶࡪࡸ᷷ࠧ"):QQUSNlXZ6MEoH1uftykesbKq2,KBkxSYaz93pu1(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷ᷸ࠫ"):hWGMqtBy4wuLaVcj}
			sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠨࡉࡈࡘ᷹ࠬ"),NPM3HKQ57xe,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡉࡉࡎࡃࡑࡓ࡜࠳࠲࡯ࡦ᷺ࠪ"))
			eecmFXt5SRyCjGpx = sDQvwGASB0Vf67mik.content
			items = trdVA0JvFaD.findall(gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷ࡮ࢀࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ᷻"),eecmFXt5SRyCjGpx,trdVA0JvFaD.DOTALL)
			haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = [],[]
			cbtS4iE32pOBe5rUxdfIjlXhokKMR = RRNODILCtGzvgpx(NPM3HKQ57xe,EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠫࡺࡸ࡬ࠨ᷼"))
			for llxFwq0CUNgQtivJzkHeGV,QS8ZdxkHD5bjU9qsn4zMYaPrg3h7 in reversed(items):
				llxFwq0CUNgQtivJzkHeGV = cbtS4iE32pOBe5rUxdfIjlXhokKMR+llxFwq0CUNgQtivJzkHeGV+CnbBKmtF1x84q7AW(u"ࠬࢂࡒࡦࡨࡨࡶࡪࡸ࠽ࠨ᷽")+cbtS4iE32pOBe5rUxdfIjlXhokKMR
				haq1bHZINPE58uoBFnKfTSO2ik4.append(QS8ZdxkHD5bjU9qsn4zMYaPrg3h7)
				Dvi8asSrQYX5wE3KMIxT91me.append(llxFwq0CUNgQtivJzkHeGV)
			return hWGMqtBy4wuLaVcj,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me
		else: return ITvnUAMXsyb4eO(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ᷾"),[hWGMqtBy4wuLaVcj],[NPM3HKQ57xe]
	else:
		llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV+OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠧࡽࡔࡨࡪࡪࡸࡥࡳ࠿᷿ࠪ")+QQUSNlXZ6MEoH1uftykesbKq2
		return hWGMqtBy4wuLaVcj,[hWGMqtBy4wuLaVcj],[llxFwq0CUNgQtivJzkHeGV]
def Qtvgrsi4mV(llxFwq0CUNgQtivJzkHeGV):
	if A6dMB1FlgxVivJ2fk9C(u"ࠨࡲࡲࡷࡹ࡯ࡤࠨḀ") in llxFwq0CUNgQtivJzkHeGV:
		LLsGB1FPiUTyYrdwqf86eHAnQ = trdVA0JvFaD.findall(JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠩࡳࡳࡸࡺࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠧࡵࡨࡶࡻ࡫ࡲࡪࡦࡀࠬ࠳࠰࠿ࠪࠨࠩࠫḁ"),llxFwq0CUNgQtivJzkHeGV+e2qDYgipPmTw4KvBLnochr(u"ࠪࠪࠫ࠭Ḃ"),trdVA0JvFaD.DOTALL|trdVA0JvFaD.IGNORECASE)
		TsFgQdloabE4YpPWV,AQFhw7Rmi9IJUoX = LLsGB1FPiUTyYrdwqf86eHAnQ[ybdv7XcT3lxF6QezULwCAGk]
		RfOudJtqk4U3 = RRNODILCtGzvgpx(llxFwq0CUNgQtivJzkHeGV,wwPrSDa21lUh(u"ࠫࡺࡸ࡬ࠨḃ"))
		url = RfOudJtqk4U3+JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠬ࠵ࡡ࡫ࡣࡻࡇࡪࡴࡴࡦࡴࡂࡣࡦࡩࡴࡪࡱࡱࡁ࡬࡫ࡴࡴࡧࡵࡺࡪࡸࠦࡠࡲࡲࡷࡹࡥࡩࡥ࠿ࠪḄ")+TsFgQdloabE4YpPWV+NeO3CTLHrPfWUoIgy8Q(u"࠭ࠦࡴࡧࡵࡺࡪࡸࡩࡥ࠿ࠪḅ")+AQFhw7Rmi9IJUoX
		headers = { HHoGx7Flus60(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫḆ"):hWGMqtBy4wuLaVcj , GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠨ࡚࠰ࡖࡪࡷࡵࡦࡵࡷࡩࡩ࠳ࡗࡪࡶ࡫ࠫḇ"):KBkxSYaz93pu1(u"࡛ࠩࡑࡑࡎࡴࡵࡲࡕࡩࡶࡻࡥࡴࡶࠪḈ") }
		NPM3HKQ57xe = f1fLNcPlo2ECKtiBeug0OAvz9YM(nHBb7jXk0Daom,url,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,CnbBKmtF1x84q7AW(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡓࡄࡏࡍࡔࡔ࡚࠮࠳ࡶࡸࠬḉ"))
		NPM3HKQ57xe = NPM3HKQ57xe.replace(NXMOzZjYsmS9pf,hWGMqtBy4wuLaVcj).replace(y6eSQlZEV8uwKG5M3,hWGMqtBy4wuLaVcj)
		return EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧḊ"),[hWGMqtBy4wuLaVcj],[NPM3HKQ57xe]
	elif LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠬ࠵ࡲࡦࡦ࡬ࡶࡪࡩࡴ࠰ࠩḋ") in llxFwq0CUNgQtivJzkHeGV:
		MkNO5By27JAx0gtzdLHUp = ybdv7XcT3lxF6QezULwCAGk
		while OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"࠭࠯ࡳࡧࡧ࡭ࡷ࡫ࡣࡵ࠱ࠪḌ") in llxFwq0CUNgQtivJzkHeGV and MkNO5By27JAx0gtzdLHUp<sULh4NjakzI8He7xJCMGrql(u"࠹ঝ"):
			sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(DpQifS0oKBI1hYcO,MMizeNH0AKu(u"ࠧࡈࡇࡗࠫḍ"),llxFwq0CUNgQtivJzkHeGV,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡘࡂࡍࡋࡒࡒ࡟࠳࠲࡯ࡦࠪḎ"))
			if NeO3CTLHrPfWUoIgy8Q(u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫḏ") in list(sDQvwGASB0Vf67mik.headers.keys()): llxFwq0CUNgQtivJzkHeGV = sDQvwGASB0Vf67mik.headers[DJ1ICpbyR2(u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬḐ")]
			MkNO5By27JAx0gtzdLHUp += bXukYxQ4aHw
		return hWGMqtBy4wuLaVcj,[hWGMqtBy4wuLaVcj],[llxFwq0CUNgQtivJzkHeGV]
	else: return EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡁࡓࡄࡏࡍࡔࡔ࡚ࠨḑ"),[],[]
def WW2cFhXPaH(url):
	SODQ7qlNYoZcFK8e50rBsJaAHxiXjE = RRNODILCtGzvgpx(url,e2qDYgipPmTw4KvBLnochr(u"ࠬࡻࡲ࡭ࠩḒ"))
	headers = {e2qDYgipPmTw4KvBLnochr(u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧḓ"):SODQ7qlNYoZcFK8e50rBsJaAHxiXjE,e2qDYgipPmTw4KvBLnochr(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫḔ"):OB6QYAMUnPiWXgpkTrItV48FqZSjdR()}
	if sULh4NjakzI8He7xJCMGrql(u"ࠨ࠱ࡨࡱࡧ࡫ࡤ࠮ࠩḕ") in url:
		mMQ3FkNVa4IlxqY = f1fLNcPlo2ECKtiBeug0OAvz9YM(nHBb7jXk0Daom,url,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,wwPrSDa21lUh(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡒࡂࡄࡖࡉࡊࡊ࠭࠳ࡰࡧࠫḖ"))
		llxFwq0CUNgQtivJzkHeGV = trdVA0JvFaD.findall(LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠪࡀࡸࡵࡵࡳࡥࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩḗ"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if llxFwq0CUNgQtivJzkHeGV:
			llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV[ybdv7XcT3lxF6QezULwCAGk].replace(DJ1ICpbyR2(u"ࠫ࡭ࡺࡴࡱࡵࠪḘ"),e2qDYgipPmTw4KvBLnochr(u"ࠬ࡮ࡴࡵࡲࠪḙ"))
			return hWGMqtBy4wuLaVcj,[hWGMqtBy4wuLaVcj],[llxFwq0CUNgQtivJzkHeGV]
	else:
		AxJPv1jVOXaMqRwk6uHsoU = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(DpQifS0oKBI1hYcO,QvgnCALNstmuUJiET(u"࠭ࡇࡆࡖࠪḚ"),url,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡗࡇࡂࡔࡇࡈࡈ࠲࠹ࡲࡥࠩḛ"))
		mMQ3FkNVa4IlxqY = AxJPv1jVOXaMqRwk6uHsoU.content
		PwvNmnqXKrYVZugB5c8 = headers.copy()
		if mkHKSQvjWr5BTcM3wVY(u"ࠨࡡ࡯ࡲࡰࡥࠧḜ") in str(AxJPv1jVOXaMqRwk6uHsoU.cookies):
			cookies = AxJPv1jVOXaMqRwk6uHsoU.cookies
			PwvNmnqXKrYVZugB5c8[S1SgCFYGJeMvfp5iZXK(u"ࠩࡆࡳࡴࡱࡩࡦࠩḝ")] = jkiCS0UWs2dNAJcGKn6mbHD(gQ5hRKULia2pdOWAxScMwTDbkl(cookies))
		llxFwq0CUNgQtivJzkHeGV = trdVA0JvFaD.findall(zyvJMtBhrw(u"ࠪࡰ࡮ࡴ࡫࠯ࡪࡵࡩ࡫ࠦ࠽ࠡࠤࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭ࠧ࠭Ḟ"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if not llxFwq0CUNgQtivJzkHeGV: return KNIvHPjUbhr(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧḟ"),[hWGMqtBy4wuLaVcj],[url]
		else:
			llxFwq0CUNgQtivJzkHeGV = jkiCS0UWs2dNAJcGKn6mbHD(llxFwq0CUNgQtivJzkHeGV[ybdv7XcT3lxF6QezULwCAGk])+CnbBKmtF1x84q7AW(u"ࠬࠬࡤ࠾࠳ࠪḠ")
			SkMF3ejVQcGAh92BI5Hyg = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(DpQifS0oKBI1hYcO,LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"࠭ࡇࡆࡖࠪḡ"),llxFwq0CUNgQtivJzkHeGV,hWGMqtBy4wuLaVcj,PwvNmnqXKrYVZugB5c8,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡗࡇࡂࡔࡇࡈࡈ࠲࠺ࡴࡩࠩḢ"))
			mMQ3FkNVa4IlxqY = SkMF3ejVQcGAh92BI5Hyg.content
			llxFwq0CUNgQtivJzkHeGV = trdVA0JvFaD.findall(sULh4NjakzI8He7xJCMGrql(u"ࠨ࡫ࡧࡁࠧࡨࡴ࡯ࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫḣ"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
			if llxFwq0CUNgQtivJzkHeGV:
				llxFwq0CUNgQtivJzkHeGV = jkiCS0UWs2dNAJcGKn6mbHD(llxFwq0CUNgQtivJzkHeGV[ybdv7XcT3lxF6QezULwCAGk])
				if dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠩࡰࡴ࠹࠭Ḥ") in llxFwq0CUNgQtivJzkHeGV and OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠪ࠳ࡩ࠵ࠧḥ") in llxFwq0CUNgQtivJzkHeGV: return hWGMqtBy4wuLaVcj,[hWGMqtBy4wuLaVcj],[llxFwq0CUNgQtivJzkHeGV]
				else: return S1SgCFYGJeMvfp5iZXK(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧḦ"),[hWGMqtBy4wuLaVcj],[llxFwq0CUNgQtivJzkHeGV]
	return hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡂࡔࡄࡆࡘࡋࡅࡅࠩḧ"),[],[]
def EEHXBdaKUy(llxFwq0CUNgQtivJzkHeGV):
	if S1SgCFYGJeMvfp5iZXK(u"࠭࡟ࡢࡥࡷ࡭ࡴࡴ࠽ࡨࡧࡷࡷࡪࡸࡶࡦࡴࠪḨ") in llxFwq0CUNgQtivJzkHeGV:
		headers = {KNIvHPjUbhr(u"࡙ࠧ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪࠪḩ"):GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠨ࡚ࡐࡐࡍࡺࡴࡱࡔࡨࡵࡺ࡫ࡳࡵࠩḪ")}
		sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,HHoGx7Flus60(u"ࠩࡊࡉ࡙࠭ḫ"),llxFwq0CUNgQtivJzkHeGV,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,rwQN9AKhLCuMfHxjlbX0U(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡓࡉࡃࡋࡍࡉ࠺ࡕ࠮࠳ࡶࡸࠬḬ"))
		url = sDQvwGASB0Vf67mik.content
		if url: return dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧḭ"),[hWGMqtBy4wuLaVcj],[url]
	else:
		LLsGB1FPiUTyYrdwqf86eHAnQ = trdVA0JvFaD.findall(dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠬࡶ࡯ࡴࡶ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠪࡸ࡫ࡲࡷࡧࡵ࡭ࡩࡃࠨ࠯ࠬࡂ࠭ࠩ࠭Ḯ"),llxFwq0CUNgQtivJzkHeGV,trdVA0JvFaD.DOTALL|trdVA0JvFaD.IGNORECASE)
		if not LLsGB1FPiUTyYrdwqf86eHAnQ: LLsGB1FPiUTyYrdwqf86eHAnQ = trdVA0JvFaD.findall(mkHKSQvjWr5BTcM3wVY(u"࠭࡟ࡱࡱࡶࡸࡤ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠦࡴࡧࡵࡺࡪࡸࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠥࠩḯ"),llxFwq0CUNgQtivJzkHeGV,trdVA0JvFaD.DOTALL|trdVA0JvFaD.IGNORECASE)
		TsFgQdloabE4YpPWV,AQFhw7Rmi9IJUoX = LLsGB1FPiUTyYrdwqf86eHAnQ[ybdv7XcT3lxF6QezULwCAGk]
		SODQ7qlNYoZcFK8e50rBsJaAHxiXjE = RRNODILCtGzvgpx(llxFwq0CUNgQtivJzkHeGV,rwQN9AKhLCuMfHxjlbX0U(u"ࠧࡶࡴ࡯ࠫḰ"))
		url = SODQ7qlNYoZcFK8e50rBsJaAHxiXjE+hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠨ࠱ࡺࡴ࠲ࡩ࡯࡯ࡶࡨࡲࡹ࠵ࡴࡩࡧࡰࡩࡸ࠵ࡴࡩࡧࡰࡩ࠴ࡇࡪࡢࡺࡤࡸ࠴࡙ࡩ࡯ࡩ࡯ࡩ࠴࡙ࡥࡳࡸࡨࡶ࠳ࡶࡨࡱࠩḱ")
		data = {sULh4NjakzI8He7xJCMGrql(u"ࠩ࡬ࡨࠬḲ"):TsFgQdloabE4YpPWV,sULh4NjakzI8He7xJCMGrql(u"ࠪ࡭ࠬḳ"):AQFhw7Rmi9IJUoX}
		headers = {QVDJLRlxNg127jMX(u"ࠫ࡝࠳ࡒࡦࡳࡸࡩࡸࡺࡥࡥ࠯࡚࡭ࡹ࡮ࠧḴ"):LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠬ࡞ࡍࡍࡊࡷࡸࡵࡘࡥࡲࡷࡨࡷࡹ࠭ḵ"),ITvnUAMXsyb4eO(u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧḶ"):llxFwq0CUNgQtivJzkHeGV}
		sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠧࡑࡑࡖࡘࠬḷ"),url,data,headers,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,xcChIL13BpR8WArNt9Pl0So(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡘࡎࡁࡉࡋࡇ࠸࡚࠳࠲࡯ࡦࠪḸ"))
		eecmFXt5SRyCjGpx = sDQvwGASB0Vf67mik.content
		NPM3HKQ57xe = trdVA0JvFaD.findall(FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧḹ"),eecmFXt5SRyCjGpx,trdVA0JvFaD.DOTALL|trdVA0JvFaD.IGNORECASE)
		if NPM3HKQ57xe:
			NPM3HKQ57xe = NPM3HKQ57xe[ybdv7XcT3lxF6QezULwCAGk]
			return rwQN9AKhLCuMfHxjlbX0U(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭Ḻ"),[hWGMqtBy4wuLaVcj],[NPM3HKQ57xe]
	return NeO3CTLHrPfWUoIgy8Q(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡓࡉࡃࡋࡍࡉ࠺ࡕࠨḻ"),[],[]
def Eas8eOd471cMhDV9KWGifHj3qISbLm(qq7iceKEBC4Jz2ntQOFPLNjTr1SMx):
	tVWpNMCUmF0g4hH81aqzsGfn5B = ee8c0jzrTntGSUdRJm.getSetting(QVDJLRlxNg127jMX(u"ࠬࡧࡶ࠯ࡣ࡮ࡻࡦࡳ࠮ࡷࡧࡵ࡭࡫࡯ࡣࡢࡶ࡬ࡳࡳ࠭Ḽ"))
	headers = {LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"࠭ࡃࡰࡱ࡮࡭ࡪ࠭ḽ"):tVWpNMCUmF0g4hH81aqzsGfn5B} if tVWpNMCUmF0g4hH81aqzsGfn5B else hWGMqtBy4wuLaVcj
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(DpQifS0oKBI1hYcO,gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠧࡈࡇࡗࠫḾ"),qq7iceKEBC4Jz2ntQOFPLNjTr1SMx,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,KBkxSYaz93pu1(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡇ࡟ࡐࡂࡕࡖࡣࡆࡑࡗࡂࡏࡢࡇࡆࡖࡔࡄࡊࡄ࠱࠶ࡹࡴࠨḿ"))
	lREL9z6MTrWHVF7PmcKOS2p = sDQvwGASB0Vf67mik.content
	zLR65iYMxNsoCHIaPp = str(sDQvwGASB0Vf67mik.headers)
	t9N4M2wUkEsrHehTFclIP = zLR65iYMxNsoCHIaPp+lREL9z6MTrWHVF7PmcKOS2p
	if KBkxSYaz93pu1(u"ࠩ࠱ࡱࡵ࠺ࠧṀ") in t9N4M2wUkEsrHehTFclIP: llnMvPUcTBFr0CgN4sZbRYh1fA8u = VBlawK4mgHSyLEn8iqhUkz5
	else:
		OOU9pJ8gSK0NHcQE,vanQT4j5Z8SfO2MHg19I,THxuyVhS854,G5OknJVaI62tElH4Xf3yY,llnMvPUcTBFr0CgN4sZbRYh1fA8u = hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,fEXMiAyG3ql4vKB
		captcha = trdVA0JvFaD.findall(KBkxSYaz93pu1(u"ࠪࡴࡦ࡭ࡥ࠮ࡴࡨࡨ࡮ࡸࡥࡤࡶ࠱࠮ࡄࡧࡣࡵ࡫ࡲࡲࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡦࡤࡸࡦ࠳ࡳࡪࡶࡨ࡯ࡪࡿ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨṁ"),lREL9z6MTrWHVF7PmcKOS2p,trdVA0JvFaD.DOTALL)
		if captcha: THxuyVhS854,G5OknJVaI62tElH4Xf3yY = captcha[ybdv7XcT3lxF6QezULwCAGk]
		HPdKSibRzYZcWXB = u6rbxnyjTl7I[QVDJLRlxNg127jMX(u"ࠫࡕ࡟ࡔࡉࡑࡑࠫṂ")][wwPrSDa21lUh(u"࠼ঞ")]
		if ybdv7XcT3lxF6QezULwCAGk:
			data = {QvgnCALNstmuUJiET(u"ࠬࡻࡳࡦࡴࠪṃ"):IIvxtojw6EXl2f,EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"࠭ࡶࡦࡴࡶ࡭ࡴࡴࠧṄ"):aO9cFKo862LqTWlIjy,dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠧࡶࡴ࡯ࠫṅ"):qq7iceKEBC4Jz2ntQOFPLNjTr1SMx,KNIvHPjUbhr(u"ࠨ࡭ࡨࡽࠬṆ"):G5OknJVaI62tElH4Xf3yY,A6dMB1FlgxVivJ2fk9C(u"ࠩ࡬ࡨࠬṇ"):hWGMqtBy4wuLaVcj,EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠪ࡮ࡴࡨࠧṈ"):OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠫ࡬࡫ࡴࡶࡴ࡯ࡷࠬṉ")}
			sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(lke5D6CpaAXPdEZyrBSw7T,xcChIL13BpR8WArNt9Pl0So(u"ࠬࡖࡏࡔࡖࠪṊ"),HPdKSibRzYZcWXB,data,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,gDuGMR3z1aV6YdLmCpiO8Kl(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡅ࡝ࡕࡇࡓࡔࡡࡄࡏ࡜ࡇࡍࡠࡅࡄࡔ࡙ࡉࡈࡂ࠯࠵ࡲࡩ࠭ṋ"))
			mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
		mMQ3FkNVa4IlxqY = hWGMqtBy4wuLaVcj
		if mMQ3FkNVa4IlxqY.startswith(QVDJLRlxNg127jMX(u"ࠧࡖࡔࡏࡗࡂ࠭Ṍ")):
			YEaKhr8nAVQjsgycmW3qRJpwFB2iI = Cy9ow3c21nABMjzqeaIT(zyvJMtBhrw(u"ࠨ࡮࡬ࡷࡹ࠭ṍ"),mMQ3FkNVa4IlxqY.split(xcChIL13BpR8WArNt9Pl0So(u"ࠩࡘࡖࡑ࡙࠽ࠨṎ"),bXukYxQ4aHw)[bXukYxQ4aHw])
			for s4mUPzjv1bRoNTMdenkuBgYl in YEaKhr8nAVQjsgycmW3qRJpwFB2iI:
				url = s4mUPzjv1bRoNTMdenkuBgYl[LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠪࡹࡷࡲࠧṏ")]
				eegCUujkiAoBKIqn4fdVRxJSM = s4mUPzjv1bRoNTMdenkuBgYl[KNIvHPjUbhr(u"ࠫࡲ࡫ࡴࡩࡱࡧࠫṐ")]
				data = s4mUPzjv1bRoNTMdenkuBgYl[jeAby54c02TgG8zuivonX91(u"ࠬࡪࡡࡵࡣࠪṑ")]
				headers = s4mUPzjv1bRoNTMdenkuBgYl[MMizeNH0AKu(u"࠭ࡨࡦࡣࡧࡩࡷࡹࠧṒ")]
				sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(lke5D6CpaAXPdEZyrBSw7T,eegCUujkiAoBKIqn4fdVRxJSM,url,data,headers,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,wwPrSDa21lUh(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡆ࡞ࡖࡁࡔࡕࡢࡅࡐ࡝ࡁࡎࡡࡆࡅࡕ࡚ࡃࡉࡃ࠰࠷ࡷࡪࠧṓ"))
				lREL9z6MTrWHVF7PmcKOS2p = sDQvwGASB0Vf67mik.content
				if gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠨ࠰ࡰࡴ࠹࠭Ṕ") in lREL9z6MTrWHVF7PmcKOS2p:
					llnMvPUcTBFr0CgN4sZbRYh1fA8u = VBlawK4mgHSyLEn8iqhUkz5
					break
				zLR65iYMxNsoCHIaPp = str(sDQvwGASB0Vf67mik.headers)
				t9N4M2wUkEsrHehTFclIP = zLR65iYMxNsoCHIaPp+lREL9z6MTrWHVF7PmcKOS2p
				OOU9pJ8gSK0NHcQE = trdVA0JvFaD.findall(rwQN9AKhLCuMfHxjlbX0U(u"ࠩࠫࡥࡰࡽࡡ࡮ࡘࡨࡶ࡮࡬ࡩࡤࡣࡷ࡭ࡴࡴ࡜ࡸ࠭ࠬ࠲࠯ࡅࠢࠩࡧࡼࡎ࠳࠰࠿ࠪࠤࠪṕ"),t9N4M2wUkEsrHehTFclIP,trdVA0JvFaD.DOTALL)
				vanQT4j5Z8SfO2MHg19I = trdVA0JvFaD.findall(FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠪࡶࡪࡩࡡࡱࡶࡦ࡬ࡦ࠳ࡴࡰ࡭ࡨࡲ࠳࠰࠿ࠣࠪ࠳࠷ࡆ࠴ࠪࡀࠫࠥࠫṖ"),t9N4M2wUkEsrHehTFclIP,trdVA0JvFaD.DOTALL)
				if vanQT4j5Z8SfO2MHg19I: vanQT4j5Z8SfO2MHg19I = vanQT4j5Z8SfO2MHg19I[ybdv7XcT3lxF6QezULwCAGk]
				if OOU9pJ8gSK0NHcQE or vanQT4j5Z8SfO2MHg19I: break
		if not llnMvPUcTBFr0CgN4sZbRYh1fA8u:
			if not OOU9pJ8gSK0NHcQE:
				if captcha and not vanQT4j5Z8SfO2MHg19I:
					if bXukYxQ4aHw: vanQT4j5Z8SfO2MHg19I = MgS8XP5hQrA1T0B9RViw(G5OknJVaI62tElH4Xf3yY,ITvnUAMXsyb4eO(u"ࠫࡦࡸࠧṗ"),qq7iceKEBC4Jz2ntQOFPLNjTr1SMx)
					else:
						if not mMQ3FkNVa4IlxqY.startswith(OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠬࡏࡄ࠾ࠩṘ")):
							data = {o1u5dij9UrcbXzVS8lwIWfKpnqM(u"࠭ࡵࡴࡧࡵࠫṙ"):IIvxtojw6EXl2f,hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠧࡷࡧࡵࡷ࡮ࡵ࡮ࠨṚ"):aO9cFKo862LqTWlIjy,A6dMB1FlgxVivJ2fk9C(u"ࠨࡷࡵࡰࠬṛ"):qq7iceKEBC4Jz2ntQOFPLNjTr1SMx,JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠩ࡮ࡩࡾ࠭Ṝ"):G5OknJVaI62tElH4Xf3yY,hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠪ࡭ࡩ࠭ṝ"):hWGMqtBy4wuLaVcj,dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠫ࡯ࡵࡢࠨṞ"):LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠬ࡭ࡥࡵ࡫ࡧࠫṟ")}
							sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(lke5D6CpaAXPdEZyrBSw7T,zyvJMtBhrw(u"࠭ࡐࡐࡕࡗࠫṠ"),HPdKSibRzYZcWXB,data,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,CnbBKmtF1x84q7AW(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡆ࡞ࡖࡁࡔࡕࡢࡅࡐ࡝ࡁࡎࡡࡆࡅࡕ࡚ࡃࡉࡃ࠰࠸ࡹ࡮ࠧṡ"))
							mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
						else: mMQ3FkNVa4IlxqY = o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠨࡋࡇࡁ࠶࠸࠳࠵࠼࠽࠾࠿࡚ࡉࡎࡇࡒ࡙࡙ࡃ࠴࠶ࠩṢ")
						if mMQ3FkNVa4IlxqY.startswith(A6dMB1FlgxVivJ2fk9C(u"ࠩࡌࡈࡂ࠭ṣ")):
							GvaB3IVzZbAUo0EOyeXdY21TKSHck4 = trdVA0JvFaD.findall(jeAby54c02TgG8zuivonX91(u"ࠪࡍࡉࡃࠨ࠯ࠬࡂ࠭࠿ࡀ࠺࠻ࡖࡌࡑࡊࡕࡕࡕ࠿ࠫ࠲࠯ࡅࠩࠥࠩṤ"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
							WnVmA4O7YgBKUfREzMZqeTHc3L5,CCiHoyQdYazj = GvaB3IVzZbAUo0EOyeXdY21TKSHck4[ybdv7XcT3lxF6QezULwCAGk]
							jjEwJpmd2v0oxBRP1Dyu = xcChIL13BpR8WArNt9Pl0So(u"ࠫ์ึ็ࠡษ็฽๊๊๊สࠢอัฯอฬ๊ࠡๅฮ๋ࠥๆࠡ࠳࠳ࠤส๊้ࠡࠩṥ")+CCiHoyQdYazj+QvgnCALNstmuUJiET(u"ࠬࠦหศ่ํอࠬṦ")
							xX7c9PeCsht = Tbof9Jl4eHnYZMvVEBFgCh1G3mLtd()
							xX7c9PeCsht.create(FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"࠭ๅฮษ๋่ฮࠦสอษ๋ึࠥ็อึࠢฦ๊ฬࠦร็ีส๊ࠥ๎ไิฬࠣฬึ์วๆฮࠣ็ํ๋ศ๋๊อีࠬṧ"),jjEwJpmd2v0oxBRP1Dyu)
							l35mRFvyzijr = HB5PvxRhwM.time()
							R6MCSKPboyFUhlf,dtKy1NOvwL8C9FkjpxqJSngQ = ybdv7XcT3lxF6QezULwCAGk,ybdv7XcT3lxF6QezULwCAGk
							while R6MCSKPboyFUhlf<int(CCiHoyQdYazj):
								CEIhS05OkFWGozARVZwnyrXf6(xX7c9PeCsht,int(R6MCSKPboyFUhlf/int(CCiHoyQdYazj)*FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"࠷࠰࠱ট")),jjEwJpmd2v0oxBRP1Dyu,hWGMqtBy4wuLaVcj,CCiHoyQdYazj+mkHKSQvjWr5BTcM3wVY(u"ࠧࠡ࠱ࠣࠫṨ")+str(int(R6MCSKPboyFUhlf))+QvgnCALNstmuUJiET(u"ࠨࠢࠣฯฬ์๊สࠩṩ"))
								if R6MCSKPboyFUhlf>dtKy1NOvwL8C9FkjpxqJSngQ+mkHKSQvjWr5BTcM3wVY(u"࠱࠱ঠ"):
									data = {KBkxSYaz93pu1(u"ࠩࡸࡷࡪࡸࠧṪ"):IIvxtojw6EXl2f,zyvJMtBhrw(u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫṫ"):aO9cFKo862LqTWlIjy,QvgnCALNstmuUJiET(u"ࠫࡺࡸ࡬ࠨṬ"):qq7iceKEBC4Jz2ntQOFPLNjTr1SMx,wwPrSDa21lUh(u"ࠬࡱࡥࡺࠩṭ"):G5OknJVaI62tElH4Xf3yY,LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"࠭ࡩࡥࠩṮ"):WnVmA4O7YgBKUfREzMZqeTHc3L5,mkHKSQvjWr5BTcM3wVY(u"ࠧ࡫ࡱࡥࠫṯ"):dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠨࡩࡨࡸࡹࡵ࡫ࡦࡰࠪṰ")}
									sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(lke5D6CpaAXPdEZyrBSw7T,KNIvHPjUbhr(u"ࠩࡓࡓࡘ࡚ࠧṱ"),HPdKSibRzYZcWXB,data,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,ITvnUAMXsyb4eO(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡂ࡚ࡒࡄࡗࡘࡥࡁࡌ࡙ࡄࡑࡤࡉࡁࡑࡖࡆࡌࡆ࠳࠵ࡵࡪࠪṲ"))
									mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
									if mMQ3FkNVa4IlxqY.startswith(LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"࡙ࠫࡕࡋࡆࡐࡀࠫṳ")):
										vanQT4j5Z8SfO2MHg19I = mMQ3FkNVa4IlxqY.split(sULh4NjakzI8He7xJCMGrql(u"࡚ࠬࡏࡌࡇࡑࡁࠬṴ"),rwQN9AKhLCuMfHxjlbX0U(u"࠲ড"))[bXukYxQ4aHw]
										break
									dtKy1NOvwL8C9FkjpxqJSngQ = R6MCSKPboyFUhlf
								else: HB5PvxRhwM.sleep(bXukYxQ4aHw)
								R6MCSKPboyFUhlf = HB5PvxRhwM.time()-l35mRFvyzijr
							xX7c9PeCsht.close()
				if vanQT4j5Z8SfO2MHg19I:
					ACsolPS6c3Bw1aLiOg8dvGWbYtkR = sDQvwGASB0Vf67mik.cookies
					me3AzYj2wVSl91ThidoUOy = trdVA0JvFaD.findall(EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"࠭ࡡ࡬ࡹࡤࡱࡤࡹࡥࡴࡵ࡬ࡳࡳࡃࠨ࠯ࠬࡂ࠭ࡀ࠭ṵ"),t9N4M2wUkEsrHehTFclIP,trdVA0JvFaD.DOTALL)
					if QvgnCALNstmuUJiET(u"ࠧࡢ࡭ࡺࡥࡲࡥࡳࡦࡵࡶ࡭ࡴࡴࠧṶ") in list(ACsolPS6c3Bw1aLiOg8dvGWbYtkR.keys()): me3AzYj2wVSl91ThidoUOy = ACsolPS6c3Bw1aLiOg8dvGWbYtkR[FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠨࡣ࡮ࡻࡦࡳ࡟ࡴࡧࡶࡷ࡮ࡵ࡮ࠨṷ")]
					elif me3AzYj2wVSl91ThidoUOy: me3AzYj2wVSl91ThidoUOy = me3AzYj2wVSl91ThidoUOy[ybdv7XcT3lxF6QezULwCAGk]
					captcha = trdVA0JvFaD.findall(QvgnCALNstmuUJiET(u"ࠩࡳࡥ࡬࡫࠭ࡳࡧࡧ࡭ࡷ࡫ࡣࡵ࠰࠭ࡃࡦࡩࡴࡪࡱࡱࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡥࡣࡷࡥ࠲ࡹࡩࡵࡧ࡮ࡩࡾࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧṸ"),lREL9z6MTrWHVF7PmcKOS2p,trdVA0JvFaD.DOTALL)
					if captcha: THxuyVhS854,G5OknJVaI62tElH4Xf3yY = captcha[ybdv7XcT3lxF6QezULwCAGk]
					if me3AzYj2wVSl91ThidoUOy and captcha:
						headers = {wwPrSDa21lUh(u"ࠪࡇࡴࡵ࡫ࡪࡧࠪṹ"):hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠫࡦࡱࡷࡢ࡯ࡢࡷࡪࡹࡳࡪࡱࡱࡁࠬṺ")+me3AzYj2wVSl91ThidoUOy,sULh4NjakzI8He7xJCMGrql(u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭ṻ"):qq7iceKEBC4Jz2ntQOFPLNjTr1SMx,XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬṼ"):DJ1ICpbyR2(u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩ࠭ṽ")}
						data = LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠨࡩ࠰ࡶࡪࡩࡡࡱࡶࡦ࡬ࡦ࠳ࡲࡦࡵࡳࡳࡳࡹࡥ࠾ࠩṾ")+vanQT4j5Z8SfO2MHg19I
						sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(DpQifS0oKBI1hYcO,mkHKSQvjWr5BTcM3wVY(u"ࠩࡓࡓࡘ࡚ࠧṿ"),THxuyVhS854,data,headers,fEXMiAyG3ql4vKB,hWGMqtBy4wuLaVcj,dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡂ࡚ࡒࡄࡗࡘࡥࡁࡌ࡙ࡄࡑࡤࡉࡁࡑࡖࡆࡌࡆ࠳࠶ࡵࡪࠪẀ"))
						lREL9z6MTrWHVF7PmcKOS2p = sDQvwGASB0Vf67mik.content
						try: cookies = sDQvwGASB0Vf67mik.cookies
						except: cookies = {}
						OOU9pJ8gSK0NHcQE = trdVA0JvFaD.findall(SqrG5mU3j96ldsFpExobw40TJY(u"ࠦࠬ࠮ࡡ࡬ࡹࡤࡱ࡛࡫ࡲࡪࡨ࡬ࡧࡦࡺࡩࡰࡰ࠱࠮ࡄ࠯ࠧ࠻ࠢࠪࠬ࠳࠰࠿ࠪࠩࠥẁ"),str(cookies),trdVA0JvFaD.DOTALL)
			if OOU9pJ8gSK0NHcQE:
				j4lHpxXvnF2VtwBb1T9PaJEm3,OOU9pJ8gSK0NHcQE = OOU9pJ8gSK0NHcQE[ybdv7XcT3lxF6QezULwCAGk]
				tVWpNMCUmF0g4hH81aqzsGfn5B = j4lHpxXvnF2VtwBb1T9PaJEm3+SqrG5mU3j96ldsFpExobw40TJY(u"ࠬࡃࠧẂ")+OOU9pJ8gSK0NHcQE
				ee8c0jzrTntGSUdRJm.setSetting(CnbBKmtF1x84q7AW(u"࠭ࡡࡷ࠰ࡤ࡯ࡼࡧ࡭࠯ࡸࡨࡶ࡮࡬ࡩࡤࡣࡷ࡭ࡴࡴࠧẃ"),tVWpNMCUmF0g4hH81aqzsGfn5B)
				BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,MMizeNH0AKu(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪẄ"),A6dMB1FlgxVivJ2fk9C(u"ࠨ่ฯัฯูࠦๆๆํอࠥ็อึࠢฦ๊ฬࠦล็ีส๊ࠥ࠴࠮๊ࠡๅห๊ࠦวๅสิ๊ฬ๋ฬࠡสัึ๋ࠦๆหษษะࠥํะศࠢส่ๆำีࠡๆๆ๎ࠥ๐ำหะา้์อࠠๅษะๆฬࠦ࠮࠯๋่ࠢฬࠦส้ฮาࠤาอฬสࠢ็ษ฾อฯส๊ࠢิฬࠦวๅใะูู๊ࠥะหࠣวูํัࠡ࡞ࡱࡠࡳูࠦๅ็สࠤศ์่ࠠาสࠤฬ๊แฮืࠣืํ็๋ࠠฬๆีึࠦแ๋ࠢะห้ฯࠠห฼ํีࠥืศุࠢส่ัํวำࠢหห้หๆหำ้ฮࠥ࠴࠮ࠡล๋ࠤส฽แศรࠣีฬ๎สาࠢส่ส์สา่อࠤ࠳࠴ࠠฤ๊ࠣๅฺ๊ࠠิๆๆࠤฬ๊ัศ๊อีࠥ࠴࠮ࠡล๋ࠤฬูสฯัส้ࠥ࡜ࡐࡏࠢฦ์ࠥฮั้ๅึ๎ࠬẅ"))
				if sULh4NjakzI8He7xJCMGrql(u"ࠩ࠱ࡱࡵ࠺ࠧẆ") not in lREL9z6MTrWHVF7PmcKOS2p:
					headers = {e2qDYgipPmTw4KvBLnochr(u"ࠪࡇࡴࡵ࡫ࡪࡧࠪẇ"):tVWpNMCUmF0g4hH81aqzsGfn5B}
					sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(DpQifS0oKBI1hYcO,NeO3CTLHrPfWUoIgy8Q(u"ࠫࡌࡋࡔࠨẈ"),qq7iceKEBC4Jz2ntQOFPLNjTr1SMx,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,KBkxSYaz93pu1(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡄ࡜ࡔࡆ࡙ࡓࡠࡃࡎ࡛ࡆࡓ࡟ࡄࡃࡓࡘࡈࡎࡁ࠮࠹ࡷ࡬ࠬẉ"))
					lREL9z6MTrWHVF7PmcKOS2p = sDQvwGASB0Vf67mik.content
	if not llnMvPUcTBFr0CgN4sZbRYh1fA8u and not tVWpNMCUmF0g4hH81aqzsGfn5B: BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩẊ"),CnbBKmtF1x84q7AW(u"ࠧโึ็ฮࠥ฿ๅๅ์ฬࠤๆำีࠡล้หࠥษๆิษ้ࠤ࠳࠴ࠠฮษ๋่ࠥหูศัฬࠤฬู๊ๆๆํอ๋ࠥัสࠢฦาึ๏ࠠษษึฮำีวๆ้ࠢๅุࠦวๅใํำ๏๎ࠠฤ๊ࠣๅ๏ี๊้ࠢ฽๎ึํࠠๆ่๊ࠣๆูࠠศๆ่์็฿ࠧẋ"))
	return lREL9z6MTrWHVF7PmcKOS2p
def rrg9LDpKux(url,X3X4Y8RzxSVfZJUFDe,QS8ZdxkHD5bjU9qsn4zMYaPrg3h7):
	zmDKurMJwj6fi,HHAWYIZauqLrJBitcneTljf7 = [],[]
	qq7iceKEBC4Jz2ntQOFPLNjTr1SMx = url
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(DpQifS0oKBI1hYcO,JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠨࡉࡈࡘࠬẌ"),url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,rwQN9AKhLCuMfHxjlbX0U(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡋࡘࡃࡐ࠱࠶ࡹࡴࠨẍ"))
	eecmFXt5SRyCjGpx = sDQvwGASB0Vf67mik.content
	NS06oBwOHMQsVXxKe81FfzE = []
	if JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠪ࠳ࡼࡧࡴࡤࡪ࠲ࠫẎ") in eecmFXt5SRyCjGpx or JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠫ࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠯ࠨẏ") in eecmFXt5SRyCjGpx:
		rqIW37cd0iT1msDzRevOM = trdVA0JvFaD.findall(zyvJMtBhrw(u"ࠬࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࡩࡶࡷࡴ࠳࠰࠿࠽࠱ࡤࡂࠬẐ"),eecmFXt5SRyCjGpx,trdVA0JvFaD.DOTALL)
		if rqIW37cd0iT1msDzRevOM:
			for cok5ZGXdQP7YhwtqyuaCnVevm6UB in rqIW37cd0iT1msDzRevOM:
				m4IznKilUOByHweG68VJ = trdVA0JvFaD.findall(o1u5dij9UrcbXzVS8lwIWfKpnqM(u"࠭ࡨࡳࡧࡩࡁࠧ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡹࡰࡢࡰ࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪẑ"),cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
				for llxFwq0CUNgQtivJzkHeGV,title in m4IznKilUOByHweG68VJ:
					if llxFwq0CUNgQtivJzkHeGV in zmDKurMJwj6fi: continue
					if xcChIL13BpR8WArNt9Pl0So(u"ࠧ࠰ࡹࡤࡸࡨ࡮࠯ࠨẒ") not in llxFwq0CUNgQtivJzkHeGV and sULh4NjakzI8He7xJCMGrql(u"ࠨ࠱ࡧࡳࡼࡴ࡬ࡰࡣࡧ࠳ࠬẓ") not in llxFwq0CUNgQtivJzkHeGV: continue
					if ITvnUAMXsyb4eO(u"ࠩสࠫẔ") not in title:
						NS06oBwOHMQsVXxKe81FfzE.append((title,llxFwq0CUNgQtivJzkHeGV))
						continue
					title = title.replace(XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠪࡀ࠴ࡹࡰࡢࡰࡁࠫẕ"),hWGMqtBy4wuLaVcj).replace(hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠫࠥ࠳ࠠࠨẖ"),hWGMqtBy4wuLaVcj).strip(Mpsm2VF1OBnCRvK3qf6).replace(FqcVAkh7WjIXHdDKf8nvuyRo,Mpsm2VF1OBnCRvK3qf6)
					if wwPrSDa21lUh(u"ࠬࡹࡰࡢࡰࠪẗ") in title: continue
					zmDKurMJwj6fi.append(llxFwq0CUNgQtivJzkHeGV)
					HHAWYIZauqLrJBitcneTljf7.append(title)
			for title,llxFwq0CUNgQtivJzkHeGV in NS06oBwOHMQsVXxKe81FfzE:
				if llxFwq0CUNgQtivJzkHeGV not in zmDKurMJwj6fi:
					zmDKurMJwj6fi.append(llxFwq0CUNgQtivJzkHeGV)
					HHAWYIZauqLrJBitcneTljf7.append(title)
			OODLkJlZCoKmrzbg2XQSGPUdInA = ybdv7XcT3lxF6QezULwCAGk
			if len(zmDKurMJwj6fi)>bXukYxQ4aHw:
				OODLkJlZCoKmrzbg2XQSGPUdInA = Eb7qJoNwOgn(wwPrSDa21lUh(u"࠭ศฺุ๊หࠥ๐อหษฯࠤ࠻࠶ࠠฬษ้๎ฮ࠭ẘ"),HHAWYIZauqLrJBitcneTljf7)
				if OODLkJlZCoKmrzbg2XQSGPUdInA==-bXukYxQ4aHw: return EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠧࡆ࡚ࡌࡘࡤࡇࡌࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬẙ"),[],[]
			if zmDKurMJwj6fi and OODLkJlZCoKmrzbg2XQSGPUdInA>=ybdv7XcT3lxF6QezULwCAGk: qq7iceKEBC4Jz2ntQOFPLNjTr1SMx = zmDKurMJwj6fi[OODLkJlZCoKmrzbg2XQSGPUdInA]
	lREL9z6MTrWHVF7PmcKOS2p = Eas8eOd471cMhDV9KWGifHj3qISbLm(qq7iceKEBC4Jz2ntQOFPLNjTr1SMx)
	Dvi8asSrQYX5wE3KMIxT91me,haq1bHZINPE58uoBFnKfTSO2ik4 = [],[]
	if X3X4Y8RzxSVfZJUFDe==o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦࠪẚ"):
		hsCNuQi8pkDSE = trdVA0JvFaD.findall(hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠩࡥࡸࡳ࠳࡬ࡰࡣࡧࡩࡷ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧẛ"),lREL9z6MTrWHVF7PmcKOS2p,trdVA0JvFaD.DOTALL)
		if hsCNuQi8pkDSE:
			llxFwq0CUNgQtivJzkHeGV = jkiCS0UWs2dNAJcGKn6mbHD(hsCNuQi8pkDSE[ybdv7XcT3lxF6QezULwCAGk])
			Dvi8asSrQYX5wE3KMIxT91me.append(llxFwq0CUNgQtivJzkHeGV)
			haq1bHZINPE58uoBFnKfTSO2ik4.append(QS8ZdxkHD5bjU9qsn4zMYaPrg3h7)
	elif X3X4Y8RzxSVfZJUFDe==LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠪࡻࡦࡺࡣࡩࠩẜ"):
		m4IznKilUOByHweG68VJ = trdVA0JvFaD.findall(OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠫࡁࡹ࡯ࡶࡴࡦࡩ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴ࡫ࡽࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ẝ"),lREL9z6MTrWHVF7PmcKOS2p,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,size in m4IznKilUOByHweG68VJ:
			if not llxFwq0CUNgQtivJzkHeGV: continue
			if QS8ZdxkHD5bjU9qsn4zMYaPrg3h7 in size:
				haq1bHZINPE58uoBFnKfTSO2ik4.append(size)
				Dvi8asSrQYX5wE3KMIxT91me.append(llxFwq0CUNgQtivJzkHeGV)
				break
		if not Dvi8asSrQYX5wE3KMIxT91me:
			for llxFwq0CUNgQtivJzkHeGV,size in m4IznKilUOByHweG68VJ:
				if not llxFwq0CUNgQtivJzkHeGV: continue
				haq1bHZINPE58uoBFnKfTSO2ik4.append(size)
				Dvi8asSrQYX5wE3KMIxT91me.append(llxFwq0CUNgQtivJzkHeGV)
	if not Dvi8asSrQYX5wE3KMIxT91me: return DJ1ICpbyR2(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡂࡍ࡚ࡅࡒ࠭ẞ"),[],[]
	return hWGMqtBy4wuLaVcj,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me
def ppotHCQbEN(url,j4lHpxXvnF2VtwBb1T9PaJEm3):
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"࠭ࡇࡆࡖࠪẟ"),url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,VBlawK4mgHSyLEn8iqhUkz5,hWGMqtBy4wuLaVcj,CnbBKmtF1x84q7AW(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡐࡕࡁࡎ࠯࠴ࡷࡹ࠭Ạ"))
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	cookies = sDQvwGASB0Vf67mik.cookies
	if QVDJLRlxNg127jMX(u"ࠨࡩࡲࡰ࡮ࡴ࡫ࠨạ") in list(cookies.keys()):
		tVWpNMCUmF0g4hH81aqzsGfn5B = cookies[A6dMB1FlgxVivJ2fk9C(u"ࠩࡪࡳࡱ࡯࡮࡬ࠩẢ")]
		tVWpNMCUmF0g4hH81aqzsGfn5B = jkiCS0UWs2dNAJcGKn6mbHD(emr1Lf523Ti0OtcNgxP(tVWpNMCUmF0g4hH81aqzsGfn5B))
		items = trdVA0JvFaD.findall(o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠪࡶࡴࡻࡴࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫả"),tVWpNMCUmF0g4hH81aqzsGfn5B,trdVA0JvFaD.DOTALL)
		NPM3HKQ57xe = items[ybdv7XcT3lxF6QezULwCAGk].replace(SqrG5mU3j96ldsFpExobw40TJY(u"ࠫࡡ࠵ࠧẤ"),gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠬ࠵ࠧấ"))
		NPM3HKQ57xe = emr1Lf523Ti0OtcNgxP(NPM3HKQ57xe)
	else: NPM3HKQ57xe = url
	if SqrG5mU3j96ldsFpExobw40TJY(u"࠭ࡣࡢࡶࡦ࡬࠳࡯ࡳࠨẦ") in NPM3HKQ57xe:
		w61tpc5IA0h7gP2vfEOTe = NPM3HKQ57xe.split(EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠧࠦ࠴ࡉࠫầ"))[-bXukYxQ4aHw]
		NPM3HKQ57xe = xcChIL13BpR8WArNt9Pl0So(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡥࡤࡸࡨ࡮࠮ࡪࡵ࠲ࠫẨ")+w61tpc5IA0h7gP2vfEOTe
		return jeAby54c02TgG8zuivonX91(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬẩ"),[hWGMqtBy4wuLaVcj],[NPM3HKQ57xe]
	else:
		website = u6rbxnyjTl7I[NeO3CTLHrPfWUoIgy8Q(u"ࠪࡅࡐࡕࡁࡎࠩẪ")][ybdv7XcT3lxF6QezULwCAGk]
		sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,rwQN9AKhLCuMfHxjlbX0U(u"ࠫࡌࡋࡔࠨẫ"),website,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,VBlawK4mgHSyLEn8iqhUkz5,hWGMqtBy4wuLaVcj,CnbBKmtF1x84q7AW(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡎࡓࡆࡓ࠭࠳ࡰࡧࠫẬ"))
		DCrURuj5iwg4cy1xd3 = sDQvwGASB0Vf67mik.url
		K9AtkZUmExfr0I = NPM3HKQ57xe.split(JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"࠭࠯ࠨậ"))[Y0XZKGRAUQj5O]
		W4vgsfF70lb2P8o1IGtqjrhXT9uQk = DCrURuj5iwg4cy1xd3.split(QvgnCALNstmuUJiET(u"ࠧ࠰ࠩẮ"))[Y0XZKGRAUQj5O]
		CMzQFXeI08KDwAJ9p = NPM3HKQ57xe.replace(K9AtkZUmExfr0I,W4vgsfF70lb2P8o1IGtqjrhXT9uQk)
		headers = { DJ1ICpbyR2(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬắ"):hWGMqtBy4wuLaVcj , JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"࡛ࠩ࠱ࡗ࡫ࡱࡶࡧࡶࡸࡪࡪ࠭ࡘ࡫ࡷ࡬ࠬẰ"):S1SgCFYGJeMvfp5iZXK(u"ࠪ࡜ࡒࡒࡈࡵࡶࡳࡖࡪࡷࡵࡦࡵࡷࠫằ") , jeAby54c02TgG8zuivonX91(u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬẲ"):CMzQFXeI08KDwAJ9p }
		sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(nHBb7jXk0Daom,GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠬࡖࡏࡔࡖࠪẳ"), CMzQFXeI08KDwAJ9p, hWGMqtBy4wuLaVcj, headers, fEXMiAyG3ql4vKB,hWGMqtBy4wuLaVcj,sULh4NjakzI8He7xJCMGrql(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡏࡔࡇࡍ࠮࠵ࡵࡨࠬẴ"))
		mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
		items = trdVA0JvFaD.findall(EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠧࡥ࡫ࡵࡩࡨࡺ࡟࡭࡫ࡱ࡯ࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧẵ"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL|trdVA0JvFaD.IGNORECASE)
		if not items:
			items = trdVA0JvFaD.findall(o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠨ࠾࡬ࡪࡷࡧ࡭ࡦ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩẶ"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL|trdVA0JvFaD.IGNORECASE)
			if not items:
				items = trdVA0JvFaD.findall(gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠩ࠿ࡩࡲࡨࡥࡥ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩặ"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL|trdVA0JvFaD.IGNORECASE)
		if items:
			llxFwq0CUNgQtivJzkHeGV = items[ybdv7XcT3lxF6QezULwCAGk].replace(HHoGx7Flus60(u"ࠪࡠ࠴࠭Ẹ"),QVDJLRlxNg127jMX(u"ࠫ࠴࠭ẹ"))
			llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV.rstrip(CnbBKmtF1x84q7AW(u"ࠬ࠵ࠧẺ"))
			if LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"࠭ࡨࡵࡶࡳࠫẻ") not in llxFwq0CUNgQtivJzkHeGV: llxFwq0CUNgQtivJzkHeGV = KBkxSYaz93pu1(u"ࠧࡩࡶࡷࡴ࠿࠭Ẽ") + llxFwq0CUNgQtivJzkHeGV
			llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV.replace(jeAby54c02TgG8zuivonX91(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࠩẽ"),LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࠫẾ"))
			if j4lHpxXvnF2VtwBb1T9PaJEm3==hWGMqtBy4wuLaVcj: pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = hWGMqtBy4wuLaVcj,[hWGMqtBy4wuLaVcj],[llxFwq0CUNgQtivJzkHeGV]
			else: pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ế"),[hWGMqtBy4wuLaVcj],[llxFwq0CUNgQtivJzkHeGV]
		else: pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = KBkxSYaz93pu1(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡁࡌࡑࡄࡑࠬỀ"),[],[]
		return pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me
def Z8oLQGO7F5hm13KfMDtHezsRb69vp(url):
	headers = { ITvnUAMXsyb4eO(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩề") : hWGMqtBy4wuLaVcj }
	mMQ3FkNVa4IlxqY = f1fLNcPlo2ECKtiBeug0OAvz9YM(nHBb7jXk0Daom,url,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡕࡅࡕࡏࡄࡗࡋࡇࡉࡔ࠳࠱ࡴࡶࠪỂ"))
	items = trdVA0JvFaD.findall(o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠧ࠽ࡵࡲࡹࡷࡩࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡮ࡤࡦࡪࡲ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨể"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me,errno = [],[],hWGMqtBy4wuLaVcj
	if items:
		for llxFwq0CUNgQtivJzkHeGV,h4s5qao1CX in items:
			haq1bHZINPE58uoBFnKfTSO2ik4.append(h4s5qao1CX)
			Dvi8asSrQYX5wE3KMIxT91me.append(llxFwq0CUNgQtivJzkHeGV)
	if len(Dvi8asSrQYX5wE3KMIxT91me)==ybdv7XcT3lxF6QezULwCAGk: return LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡖࡆࡖࡉࡅࡘࡌࡈࡊࡕࠧỄ"),[],[]
	return hWGMqtBy4wuLaVcj,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me
def YzRbteScIBhqlxF(url):
	headers = {MMizeNH0AKu(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ễ"):hWGMqtBy4wuLaVcj}
	mMQ3FkNVa4IlxqY = f1fLNcPlo2ECKtiBeug0OAvz9YM(nHBb7jXk0Daom,url,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡕࡒࡎࡒࡅࡉ࠳࠱ࡴࡶࠪỆ"))
	items = trdVA0JvFaD.findall(CnbBKmtF1x84q7AW(u"ࠫࡸࡵࡵࡳࡥࡨࡷ࠿ࠦ࡜࡜ࠤࠫ࠲࠯ࡅࠩࠣࠩệ"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if items:
		url = items[ybdv7XcT3lxF6QezULwCAGk]+o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠬࢂࡒࡦࡨࡨࡶࡪࡸ࠽ࠨỈ")+url
		return hWGMqtBy4wuLaVcj,[hWGMqtBy4wuLaVcj],[url]
	else: return hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡗࡔࡐࡔࡇࡄࠨỉ"),[],[]
def UFrAHYeI0XGEh47jCc5iNv(url):
	url = url.strip(ITvnUAMXsyb4eO(u"ࠧ࠰ࠩỊ"))
	if jeAby54c02TgG8zuivonX91(u"ࠨ࠱ࡨࡱࡧ࡫ࡤ࠰ࠩị") in url: w61tpc5IA0h7gP2vfEOTe = url.split(LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠩ࠲ࠫỌ"))[jR6BYWNFZ0egmH4Tr2Q78LbSs3t]
	else: w61tpc5IA0h7gP2vfEOTe = url.split(LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠪ࠳ࠬọ"))[-bXukYxQ4aHw]
	url = xcChIL13BpR8WArNt9Pl0So(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡼࡣࡴࡶࡵࡩࡦࡳ࠮ࡵࡱ࠲ࡴࡱࡧࡹࡦࡴࡂࡪ࡮ࡪ࠽ࠨỎ") + w61tpc5IA0h7gP2vfEOTe
	headers = { NeO3CTLHrPfWUoIgy8Q(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩỏ") : hWGMqtBy4wuLaVcj }
	mMQ3FkNVa4IlxqY = f1fLNcPlo2ECKtiBeug0OAvz9YM(nHBb7jXk0Daom,url,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,DJ1ICpbyR2(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡙ࡇࡘ࡚ࡒࡆࡃࡐ࠱࠶ࡹࡴࠨỐ"))
	mMQ3FkNVa4IlxqY = mMQ3FkNVa4IlxqY.replace(o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠧ࡝࡞ࠪố"),hWGMqtBy4wuLaVcj)
	items = trdVA0JvFaD.findall(hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠨࡨ࡬ࡰࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨỒ"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if items: return hWGMqtBy4wuLaVcj,[hWGMqtBy4wuLaVcj],[ items[ybdv7XcT3lxF6QezULwCAGk] ]
	else: return QVDJLRlxNg127jMX(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤ࡛ࡉࡓࡕࡔࡈࡅࡒ࠭ồ"),[],[]
def K4qdl63Q7MSBjUxJkDC(url):
	mMQ3FkNVa4IlxqY = f1fLNcPlo2ECKtiBeug0OAvz9YM(nHBb7jXk0Daom,url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡖࡊࡆࡒ࡞ࡆ࠳࠱ࡴࡶࠪỔ"))
	items = trdVA0JvFaD.findall(hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠫࡸࡸࡣ࠻ࠢࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡲࡡࡣࡧ࡯࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠱ࠦࡲࡦࡵ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫổ"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = [],[]
	for llxFwq0CUNgQtivJzkHeGV,h4s5qao1CX,IVLPAxG2lSm1h3HDXz6busU5yvteRY in items:
		haq1bHZINPE58uoBFnKfTSO2ik4.append(h4s5qao1CX+Mpsm2VF1OBnCRvK3qf6+IVLPAxG2lSm1h3HDXz6busU5yvteRY)
		Dvi8asSrQYX5wE3KMIxT91me.append(llxFwq0CUNgQtivJzkHeGV)
	if len(Dvi8asSrQYX5wE3KMIxT91me)==ybdv7XcT3lxF6QezULwCAGk: return JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡗࡋࡇࡓ࡟ࡇࠧỖ"),[],[]
	return hWGMqtBy4wuLaVcj,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me
def BZU5qxeRKlCJot2rys(url):
	mMQ3FkNVa4IlxqY = f1fLNcPlo2ECKtiBeug0OAvz9YM(nHBb7jXk0Daom,url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,KBkxSYaz93pu1(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡚ࡅ࡙ࡉࡈࡗࡋࡇࡉࡔ࠳࠱ࡴࡶࠪỗ"))
	items = trdVA0JvFaD.findall(mkHKSQvjWr5BTcM3wVY(u"ࠢࡥࡱࡺࡲࡱࡵࡡࡥࡡࡹ࡭ࡩ࡫࡯࡝ࠪࠪࠬ࠳࠰࠿ࠪࠩ࠯ࠫ࠭࠴ࠪࡀࠫࠪ࠰ࠬ࠮࠮ࠫࡁࠬࠫࡡ࠯࡜ࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂ࠳࠰࠿࠽ࡶࡧࡂ࠭࠴ࠪࡀࠫ࠯࠲࠯ࡅ࠼࠰ࡶࡧࡂࠧỘ"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	items = set(items)
	haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = [],[]
	for w61tpc5IA0h7gP2vfEOTe,JbpxsyQVXmSEYKM3vo847Ckh,lOYA59TFm74XVLJ1Cbx,h4s5qao1CX,IVLPAxG2lSm1h3HDXz6busU5yvteRY in items:
		url = jeAby54c02TgG8zuivonX91(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡥࡹࡩࡨࡷ࡫ࡧࡩࡴ࠴ࡵࡴ࠱ࡧࡰࡄࡵࡰ࠾ࡦࡲࡻࡳࡲ࡯ࡢࡦࡢࡳࡷ࡯ࡧࠧ࡫ࡧࡁࠬộ")+w61tpc5IA0h7gP2vfEOTe+LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠩࠩࡱࡴࡪࡥ࠾ࠩỚ")+JbpxsyQVXmSEYKM3vo847Ckh+dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠪࠪ࡭ࡧࡳࡩ࠿ࠪớ")+lOYA59TFm74XVLJ1Cbx
		mMQ3FkNVa4IlxqY = f1fLNcPlo2ECKtiBeug0OAvz9YM(nHBb7jXk0Daom,url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,xcChIL13BpR8WArNt9Pl0So(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡘࡃࡗࡇࡍ࡜ࡉࡅࡇࡒ࠱࠷ࡴࡤࠨỜ"))
		items = trdVA0JvFaD.findall(FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠬࡪࡩࡳࡧࡦࡸࠥࡲࡩ࡯࡭࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫờ"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV in items:
			haq1bHZINPE58uoBFnKfTSO2ik4.append(h4s5qao1CX+Mpsm2VF1OBnCRvK3qf6+IVLPAxG2lSm1h3HDXz6busU5yvteRY)
			Dvi8asSrQYX5wE3KMIxT91me.append(llxFwq0CUNgQtivJzkHeGV)
	if len(Dvi8asSrQYX5wE3KMIxT91me)==ybdv7XcT3lxF6QezULwCAGk: return KNIvHPjUbhr(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤ࡙ࠡࡄࡘࡈࡎࡖࡊࡆࡈࡓࠬỞ"),[],[]
	return hWGMqtBy4wuLaVcj,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me
def IpaO7R2l6fL0BtJCv1eZSyYEjW(url):
	llxFwq0CUNgQtivJzkHeGV = hWGMqtBy4wuLaVcj
	if bXukYxQ4aHw or A6dMB1FlgxVivJ2fk9C(u"ࠧࡌࡧࡼࡁࠬở") not in url:
		NPM3HKQ57xe = url.replace(S1SgCFYGJeMvfp5iZXK(u"ࠨࡷࡳࡦࡴࡳ࠮࡭࡫ࡹࡩࠬỠ"),o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠩࡸࡴࡵࡵ࡭࠯࡮࡬ࡺࡪ࠭ỡ"))
		NPM3HKQ57xe = NPM3HKQ57xe.split(A6dMB1FlgxVivJ2fk9C(u"ࠪ࠳ࠬỢ"))
		w61tpc5IA0h7gP2vfEOTe = NPM3HKQ57xe[x1x9kIQo3zjZWnYaiy]
		NPM3HKQ57xe = ITvnUAMXsyb4eO(u"ࠫ࠴࠭ợ").join(NPM3HKQ57xe[ybdv7XcT3lxF6QezULwCAGk:jR6BYWNFZ0egmH4Tr2Q78LbSs3t])
		l17Sn3hK59WV = {hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠬ࡯ࡤࠨỤ"):w61tpc5IA0h7gP2vfEOTe,KNIvHPjUbhr(u"࠭࡯ࡱࠩụ"):S1SgCFYGJeMvfp5iZXK(u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥ࠴ࠪỦ"),SqrG5mU3j96ldsFpExobw40TJY(u"ࠨ࡯ࡨࡸ࡭ࡵࡤࡠࡨࡵࡩࡪ࠭ủ"):A6dMB1FlgxVivJ2fk9C(u"ࠩࡉࡶࡪ࡫ࠫࡅࡱࡺࡲࡱࡵࡡࡥ࠭ࠨ࠷ࡊࠫ࠳ࡆࠩỨ")}
		sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(nHBb7jXk0Daom,KNIvHPjUbhr(u"ࠪࡔࡔ࡙ࡔࠨứ"),NPM3HKQ57xe,l17Sn3hK59WV,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,MMizeNH0AKu(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡖࡒࡅࡓࡒ࠳࠱ࡴࡶࠪỪ"))
		if KBkxSYaz93pu1(u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧừ") in list(sDQvwGASB0Vf67mik.headers.keys()): llxFwq0CUNgQtivJzkHeGV = sDQvwGASB0Vf67mik.headers[o1u5dij9UrcbXzVS8lwIWfKpnqM(u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨỬ")]
		if not llxFwq0CUNgQtivJzkHeGV and sDQvwGASB0Vf67mik.succeeded:
			mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
			llxFwq0CUNgQtivJzkHeGV = trdVA0JvFaD.findall(S1SgCFYGJeMvfp5iZXK(u"ࠧࡪࡦࡀࠦࡩ࡯ࡲࡦࡥࡷࡣࡱ࡯࡮࡬ࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫử"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
			if llxFwq0CUNgQtivJzkHeGV: llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV[ybdv7XcT3lxF6QezULwCAGk]
	else:
		sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(nHBb7jXk0Daom,A6dMB1FlgxVivJ2fk9C(u"ࠨࡉࡈࡘࠬỮ"),url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,QvgnCALNstmuUJiET(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡛ࡐࡃࡑࡐ࠱࠷ࡴࡤࠨữ"))
		if hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠪࡰࡴࡩࡡࡵ࡫ࡲࡲࠬỰ") in list(sDQvwGASB0Vf67mik.headers.keys()): llxFwq0CUNgQtivJzkHeGV = sDQvwGASB0Vf67mik.headers[LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠫࡱࡵࡣࡢࡶ࡬ࡳࡳ࠭ự")]
	if llxFwq0CUNgQtivJzkHeGV: return hWGMqtBy4wuLaVcj,[hWGMqtBy4wuLaVcj],[llxFwq0CUNgQtivJzkHeGV]
	return KBkxSYaz93pu1(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡖࡒࡅࡓࡒ࠭Ỳ"),[],[]
def dr64o7C3phQaOqL8(url):
	headers = { OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪỳ") : hWGMqtBy4wuLaVcj }
	mMQ3FkNVa4IlxqY = f1fLNcPlo2ECKtiBeug0OAvz9YM(nHBb7jXk0Daom,url,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,SqrG5mU3j96ldsFpExobw40TJY(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡐࡎࡏࡖࡊࡆࡈࡓ࠲࠷ࡳࡵࠩỴ"))
	items = trdVA0JvFaD.findall(KBkxSYaz93pu1(u"ࠨࡵࡲࡹࡷࡩࡥࡴ࠼࠱࠮ࡄࠨࠨ࠯ࠬࡂ࠭ࠧ࠲ࠢࠩ࠰࠭ࡃ࠮ࠨࠧỵ"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = [],[]
	if items:
		haq1bHZINPE58uoBFnKfTSO2ik4.append(QvgnCALNstmuUJiET(u"ࠩࡰࡴ࠹࠭Ỷ"))
		Dvi8asSrQYX5wE3KMIxT91me.append(items[ybdv7XcT3lxF6QezULwCAGk][bXukYxQ4aHw])
		haq1bHZINPE58uoBFnKfTSO2ik4.append(QVDJLRlxNg127jMX(u"ࠪࡱ࠸ࡻ࠸ࠨỷ"))
		Dvi8asSrQYX5wE3KMIxT91me.append(items[ybdv7XcT3lxF6QezULwCAGk][ybdv7XcT3lxF6QezULwCAGk])
		return hWGMqtBy4wuLaVcj,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me
	else: return xcChIL13BpR8WArNt9Pl0So(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡌࡊࡋ࡙ࡍࡉࡋࡏࠨỸ"),[],[]
def vgu7JcpdwP(url):
	w61tpc5IA0h7gP2vfEOTe = url.split(EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠬ࠵ࠧỹ"))[-bXukYxQ4aHw]
	w61tpc5IA0h7gP2vfEOTe = w61tpc5IA0h7gP2vfEOTe.split(JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"࠭ࠦࠨỺ"))[ybdv7XcT3lxF6QezULwCAGk]
	w61tpc5IA0h7gP2vfEOTe = w61tpc5IA0h7gP2vfEOTe.replace(KNIvHPjUbhr(u"ࠧࡸࡣࡷࡧ࡭ࡅࡶ࠾ࠩỻ"),hWGMqtBy4wuLaVcj)
	NPM3HKQ57xe = u6rbxnyjTl7I[ITvnUAMXsyb4eO(u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩỼ")][ybdv7XcT3lxF6QezULwCAGk]+mkHKSQvjWr5BTcM3wVY(u"ࠩ࠲ࡻࡦࡺࡣࡩࡁࡹࡁࠬỽ")+w61tpc5IA0h7gP2vfEOTe
	R0RomVJMUewGQcd = QVDJLRlxNg127jMX(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡽࡴࡻࡴࡶ࠰ࡥࡩ࠴࠭Ỿ")+w61tpc5IA0h7gP2vfEOTe
	bm13PoqKMnfDt7CGc2lVUy9p0eza,ZZdHEetJc2IDzOXBkh,laErqezQm1dh6A8ORPgn2M,QQRydi8qX7w1zWcKZfYEouVULA = hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj
	headers = {KBkxSYaz93pu1(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨỿ"):hWGMqtBy4wuLaVcj}
	if ybdv7XcT3lxF6QezULwCAGk:
		for JpzD0lv9cYM6XrHeqCa in range(dv0trJR7PwmKyxDYO52VLau8gEph(u"࠷ঢ")):
			sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(lke5D6CpaAXPdEZyrBSw7T,JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠬࡍࡅࡕࠩἀ"),NPM3HKQ57xe,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡜ࡓ࡚࡚ࡕࡃࡇ࠰࠵ࡸࡺࠧἁ"))
			mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
			if QvgnCALNstmuUJiET(u"ࠧࡪࡶࡤ࡫ࠬἂ") in mMQ3FkNVa4IlxqY: break
			HB5PvxRhwM.sleep(Y0XZKGRAUQj5O)
		J3KRlV0tIgThaW5zi2rqUFA = trdVA0JvFaD.findall(jeAby54c02TgG8zuivonX91(u"ࠨࡸࡤࡶࠥࡿࡴࡊࡰ࡬ࡸ࡮ࡧ࡬ࡑ࡮ࡤࡽࡪࡸࡒࡦࡵࡳࡳࡳࡹࡥࠡ࠿ࠣࠬ࠳࠰࠿ࠪ࠽࠿࠳ࡸࡩࡲࡪࡲࡷࡂࠬἃ"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if J3KRlV0tIgThaW5zi2rqUFA: J3KRlV0tIgThaW5zi2rqUFA = J3KRlV0tIgThaW5zi2rqUFA[ybdv7XcT3lxF6QezULwCAGk]
		else: J3KRlV0tIgThaW5zi2rqUFA = mMQ3FkNVa4IlxqY
	else:
		mMQ3FkNVa4IlxqY = hWGMqtBy4wuLaVcj
		headers[KNIvHPjUbhr(u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨἄ")] = XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰࡬ࡶࡳࡳ࠭ἅ")
		CMzQFXeI08KDwAJ9p = u6rbxnyjTl7I[CnbBKmtF1x84q7AW(u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬἆ")][ybdv7XcT3lxF6QezULwCAGk]+o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠬ࠵ࡹࡰࡷࡷࡹࡧ࡫ࡩ࠰ࡸ࠴࠳ࡵࡲࡡࡺࡧࡵࠫἇ")
		Tmf2x4KQBCYo6tONsERizpubWG0V = wwPrSDa21lUh(u"࠭ࡻࠣࡸ࡬ࡨࡪࡵࡉࡥࠤ࠽ࠤࠧ࠭Ἀ")+w61tpc5IA0h7gP2vfEOTe+XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠧࠣ࠮ࠣࠦࡨࡵ࡮ࡵࡧࡻࡸࠧࡀࠠࡼࠤࡦࡰ࡮࡫࡮ࡵࠤ࠽ࠤࢀࠨࡣ࡭࡫ࡨࡲࡹ࡜ࡥࡳࡵ࡬ࡳࡳࠨ࠺ࠡࠤ࠵࠲࠷࠶࠲࠳࠲࠼࠵࠽ࠨࠬࠡࠤࡦࡰ࡮࡫࡮ࡵࡐࡤࡱࡪࠨ࠺ࠡࠤࡐ࡛ࡊࡈࠢࡾࡿࢀࠫἉ")
		sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(lke5D6CpaAXPdEZyrBSw7T,QVDJLRlxNg127jMX(u"ࠨࡒࡒࡗ࡙࠭Ἂ"),CMzQFXeI08KDwAJ9p,Tmf2x4KQBCYo6tONsERizpubWG0V,headers,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡟ࡏࡖࡖࡘࡆࡊ࠳࠲࡯ࡦࠪἋ"))
		J3KRlV0tIgThaW5zi2rqUFA = sDQvwGASB0Vf67mik.content
	J3KRlV0tIgThaW5zi2rqUFA = J3KRlV0tIgThaW5zi2rqUFA.replace(mkHKSQvjWr5BTcM3wVY(u"ࠪࡠࡡࡻ࠰࠱࠴࠹ࠫἌ"),LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠫࠫ࠭Ἅ"))
	kyj0IMV6ZfCgo9S23qJWN8r = Cy9ow3c21nABMjzqeaIT(jeAby54c02TgG8zuivonX91(u"ࠬࡪࡩࡤࡶࠪἎ"),J3KRlV0tIgThaW5zi2rqUFA)
	haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = [GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"࠭ศะ๊้ࠤฯืฬๆหࠣ๎ํะ๊้สࠪἏ")],[hWGMqtBy4wuLaVcj]
	try:
		t4xG7aPyXb5MpmAq = kyj0IMV6ZfCgo9S23qJWN8r[KNIvHPjUbhr(u"ࠧࡤࡣࡳࡸ࡮ࡵ࡮ࡴࠩἐ")][SqrG5mU3j96ldsFpExobw40TJY(u"ࠨࡲ࡯ࡥࡾ࡫ࡲࡄࡣࡳࡸ࡮ࡵ࡮ࡴࡖࡵࡥࡨࡱ࡬ࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬἑ")][DJ1ICpbyR2(u"ࠩࡦࡥࡵࡺࡩࡰࡰࡗࡶࡦࡩ࡫ࡴࠩἒ")]
		for IOpAz6lY0nmbiXLJ in t4xG7aPyXb5MpmAq:
			llxFwq0CUNgQtivJzkHeGV = IOpAz6lY0nmbiXLJ[S1SgCFYGJeMvfp5iZXK(u"ࠪࡦࡦࡹࡥࡖࡴ࡯ࠫἓ")]
			try: title = IOpAz6lY0nmbiXLJ[e2qDYgipPmTw4KvBLnochr(u"ࠫࡳࡧ࡭ࡦࠩἔ")][GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠬࡹࡩ࡮ࡲ࡯ࡩ࡙࡫ࡸࡵࠩἕ")]
			except: title = IOpAz6lY0nmbiXLJ[ITvnUAMXsyb4eO(u"࠭࡮ࡢ࡯ࡨࠫ἖")][QVDJLRlxNg127jMX(u"ࠧࡳࡷࡱࡷࠬ἗")][ybdv7XcT3lxF6QezULwCAGk][EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠨࡶࡨࡼࡹࡺࠧἘ")]
			Dvi8asSrQYX5wE3KMIxT91me.append(llxFwq0CUNgQtivJzkHeGV)
			haq1bHZINPE58uoBFnKfTSO2ik4.append(title)
	except: pass
	if len(haq1bHZINPE58uoBFnKfTSO2ik4)>bXukYxQ4aHw:
		OODLkJlZCoKmrzbg2XQSGPUdInA = Eb7qJoNwOgn(ITvnUAMXsyb4eO(u"ࠩสาฯืࠠศๆอีั๋ษࠡࠪࠪἙ")+str(len(haq1bHZINPE58uoBFnKfTSO2ik4))+OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠪࠤ๊๊แࠪࠩἚ"), haq1bHZINPE58uoBFnKfTSO2ik4)
		if OODLkJlZCoKmrzbg2XQSGPUdInA==-bXukYxQ4aHw: return LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠫࡊ࡞ࡉࡕࡡࡄࡐࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩἛ"),[],[]
		elif OODLkJlZCoKmrzbg2XQSGPUdInA!=ybdv7XcT3lxF6QezULwCAGk:
			llxFwq0CUNgQtivJzkHeGV = Dvi8asSrQYX5wE3KMIxT91me[OODLkJlZCoKmrzbg2XQSGPUdInA]+CnbBKmtF1x84q7AW(u"ࠬࠬࠧἜ")
			Ru0HQE1tCcdkGq9rAOajz4D = trdVA0JvFaD.findall(HHoGx7Flus60(u"࠭ࠦࠩࡨࡰࡸࡂ࠴ࠪࡀࠫࠩࠫἝ"),llxFwq0CUNgQtivJzkHeGV)
			if Ru0HQE1tCcdkGq9rAOajz4D: llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV.replace(Ru0HQE1tCcdkGq9rAOajz4D[ybdv7XcT3lxF6QezULwCAGk],OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠧࡧ࡯ࡷࡁࡻࡺࡴࠨ἞"))
			else: llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV+A6dMB1FlgxVivJ2fk9C(u"ࠨࡨࡰࡸࡂࡼࡴࡵࠩ἟")
			bm13PoqKMnfDt7CGc2lVUy9p0eza = llxFwq0CUNgQtivJzkHeGV.strip(JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠩࠩࠫἠ"))
	hZUiMrqn1Vg3bjJ7fFy2X5YB,CJ6GwOR7zHWV,YZzymiV3jb128MqIXklFCN0LUHRJdx,iuMzFsZYx5Rr2IU8bTO14HJCSQtL,AwNVFHCY3RenJhQZ2POB9u40aEj6K = [],[],[],[],[]
	try: ZZdHEetJc2IDzOXBkh = kyj0IMV6ZfCgo9S23qJWN8r[XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠪࡷࡹࡸࡥࡢ࡯࡬ࡲ࡬ࡊࡡࡵࡣࠪἡ")][QVDJLRlxNg127jMX(u"ࠫࡩࡧࡳࡩࡏࡤࡲ࡮࡬ࡥࡴࡶࡘࡶࡱ࠭ἢ")]
	except: pass
	try: laErqezQm1dh6A8ORPgn2M = kyj0IMV6ZfCgo9S23qJWN8r[LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠬࡹࡴࡳࡧࡤࡱ࡮ࡴࡧࡅࡣࡷࡥࠬἣ")][jeAby54c02TgG8zuivonX91(u"࠭ࡨ࡭ࡵࡐࡥࡳ࡯ࡦࡦࡵࡷ࡙ࡷࡲࠧἤ")]
	except: pass
	try: hZUiMrqn1Vg3bjJ7fFy2X5YB = kyj0IMV6ZfCgo9S23qJWN8r[rwQN9AKhLCuMfHxjlbX0U(u"ࠧࡴࡶࡵࡩࡦࡳࡩ࡯ࡩࡇࡥࡹࡧࠧἥ")][QVDJLRlxNg127jMX(u"ࠨࡨࡲࡶࡲࡧࡴࡴࠩἦ")]
	except: pass
	try: CJ6GwOR7zHWV = kyj0IMV6ZfCgo9S23qJWN8r[KNIvHPjUbhr(u"ࠩࡶࡸࡷ࡫ࡡ࡮࡫ࡱ࡫ࡉࡧࡴࡢࠩἧ")][sULh4NjakzI8He7xJCMGrql(u"ࠪࡥࡩࡧࡰࡵ࡫ࡹࡩࡋࡵࡲ࡮ࡣࡷࡷࠬἨ")]
	except: pass
	QqZLYyjmGIr35ktUBga2sN6 = hZUiMrqn1Vg3bjJ7fFy2X5YB+CJ6GwOR7zHWV
	for dict in QqZLYyjmGIr35ktUBga2sN6:
		if SqrG5mU3j96ldsFpExobw40TJY(u"ࠫ࡮ࡺࡡࡨࠩἩ") in list(dict.keys()): dict[e2qDYgipPmTw4KvBLnochr(u"ࠬ࡯ࡴࡢࡩࠪἪ")] = str(dict[XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"࠭ࡩࡵࡣࡪࠫἫ")])
		if EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠧࡧࡲࡶࠫἬ") in list(dict.keys()): dict[CnbBKmtF1x84q7AW(u"ࠨࡨࡳࡷࠬἭ")] = str(dict[dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠩࡩࡴࡸ࠭Ἦ")])
		if LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠪࡱ࡮ࡳࡥࡕࡻࡳࡩࠬἯ") in list(dict.keys()): dict[XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠫࡹࡿࡰࡦࠩἰ")] = dict[dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠬࡳࡩ࡮ࡧࡗࡽࡵ࡫ࠧἱ")]
		if LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"࠭ࡡࡶࡦ࡬ࡳࡘࡧ࡭ࡱ࡮ࡨࡖࡦࡺࡥࠨἲ") in list(dict.keys()): dict[xcChIL13BpR8WArNt9Pl0So(u"ࠧࡢࡷࡧ࡭ࡴࡥࡳࡢ࡯ࡳࡰࡪࡥࡲࡢࡶࡨࠫἳ")] = str(dict[EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠨࡣࡸࡨ࡮ࡵࡓࡢ࡯ࡳࡰࡪࡘࡡࡵࡧࠪἴ")])
		if OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠩࡤࡹࡩ࡯࡯ࡄࡪࡤࡲࡳ࡫࡬ࡴࠩἵ") in list(dict.keys()): dict[S1SgCFYGJeMvfp5iZXK(u"ࠪࡥࡺࡪࡩࡰࡡࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫἶ")] = str(dict[OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠫࡦࡻࡤࡪࡱࡆ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫἷ")])
		if A6dMB1FlgxVivJ2fk9C(u"ࠬࡽࡩࡥࡶ࡫ࠫἸ") in list(dict.keys()): dict[ITvnUAMXsyb4eO(u"࠭ࡳࡪࡼࡨࠫἹ")] = str(dict[gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠧࡸ࡫ࡧࡸ࡭࠭Ἲ")])+jeAby54c02TgG8zuivonX91(u"ࠨࡺࠪἻ")+str(dict[zyvJMtBhrw(u"ࠩ࡫ࡩ࡮࡭ࡨࡵࠩἼ")])
		if sULh4NjakzI8He7xJCMGrql(u"ࠪ࡭ࡳ࡯ࡴࡓࡣࡱ࡫ࡪ࠭Ἵ") in list(dict.keys()): dict[JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠫ࡮ࡴࡩࡵࠩἾ")] = dict[S1SgCFYGJeMvfp5iZXK(u"ࠬ࡯࡮ࡪࡶࡕࡥࡳ࡭ࡥࠨἿ")][e2qDYgipPmTw4KvBLnochr(u"࠭ࡳࡵࡣࡵࡸࠬὀ")]+SqrG5mU3j96ldsFpExobw40TJY(u"ࠧ࠮ࠩὁ")+dict[A6dMB1FlgxVivJ2fk9C(u"ࠨ࡫ࡱ࡭ࡹࡘࡡ࡯ࡩࡨࠫὂ")][ITvnUAMXsyb4eO(u"ࠩࡨࡲࡩ࠭ὃ")]
		if DJ1ICpbyR2(u"ࠪ࡭ࡳࡪࡥࡹࡔࡤࡲ࡬࡫ࠧὄ") in list(dict.keys()): dict[MMizeNH0AKu(u"ࠫ࡮ࡴࡤࡦࡺࠪὅ")] = dict[gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠬ࡯࡮ࡥࡧࡻࡖࡦࡴࡧࡦࠩ὆")][NeO3CTLHrPfWUoIgy8Q(u"࠭ࡳࡵࡣࡵࡸࠬ὇")]+NeO3CTLHrPfWUoIgy8Q(u"ࠧ࠮ࠩὈ")+dict[e2qDYgipPmTw4KvBLnochr(u"ࠨ࡫ࡱࡨࡪࡾࡒࡢࡰࡪࡩࠬὉ")][KNIvHPjUbhr(u"ࠩࡨࡲࡩ࠭Ὂ")]
		if KNIvHPjUbhr(u"ࠪࡥࡻ࡫ࡲࡢࡩࡨࡆ࡮ࡺࡲࡢࡶࡨࠫὋ") in list(dict.keys()): dict[HHoGx7Flus60(u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬὌ")] = dict[sULh4NjakzI8He7xJCMGrql(u"ࠬࡧࡶࡦࡴࡤ࡫ࡪࡈࡩࡵࡴࡤࡸࡪ࠭Ὅ")]
		if KNIvHPjUbhr(u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ὎") in list(dict.keys()) and int(dict[GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ὏")])>EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"࠴࠵࠶࠸࠲࠳࠵࠶࠷ণ"): del dict[KBkxSYaz93pu1(u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩὐ")]
		if LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠩࡶ࡭࡬ࡴࡡࡵࡷࡵࡩࡈ࡯ࡰࡩࡧࡵࠫὑ") in list(dict.keys()):
			USjQadAPteJK8uNn2BMExGzlkIoT7X = dict[LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠪࡷ࡮࡭࡮ࡢࡶࡸࡶࡪࡉࡩࡱࡪࡨࡶࠬὒ")].split(jeAby54c02TgG8zuivonX91(u"ࠫࠫ࠭ὓ"))
			for ImYg2jxU6Lc9Q1C4Oko in USjQadAPteJK8uNn2BMExGzlkIoT7X:
				key,BoSjXKxz41DcneO9UimClE = ImYg2jxU6Lc9Q1C4Oko.split(KNIvHPjUbhr(u"ࠬࡃࠧὔ"),rwQN9AKhLCuMfHxjlbX0U(u"࠵ত"))
				dict[key] = jkiCS0UWs2dNAJcGKn6mbHD(BoSjXKxz41DcneO9UimClE)
		if CnbBKmtF1x84q7AW(u"࠭ࡵࡳ࡮ࠪὕ") in list(dict.keys()): dict[OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠧࡶࡴ࡯ࠫὖ")] = jkiCS0UWs2dNAJcGKn6mbHD(dict[dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠨࡷࡵࡰࠬὗ")])
		YZzymiV3jb128MqIXklFCN0LUHRJdx.append(dict)
	mmU0kFVvyIHPX = hWGMqtBy4wuLaVcj
	if HHoGx7Flus60(u"ࠩࡶࡴࡂࡹࡩࡨࠩ὘") in J3KRlV0tIgThaW5zi2rqUFA:
		if not mMQ3FkNVa4IlxqY:
			sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(lke5D6CpaAXPdEZyrBSw7T,ITvnUAMXsyb4eO(u"ࠪࡋࡊ࡚ࠧὙ"),NPM3HKQ57xe,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࡚࠭ࡑࡘࡘ࡚ࡈࡅ࠮࠵ࡵࡨࠬ὚"))
			mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
		VMLf4PbgcKtjIA = trdVA0JvFaD.findall(KBkxSYaz93pu1(u"ࠬࡹࡲࡤ࠿ࠥࠬ࠴ࡹ࠯ࡱ࡮ࡤࡽࡪࡸ࠯࡝ࡹ࠭ࡃ࠴ࡶ࡬ࡢࡻࡨࡶࡤ࡯ࡡࡴ࠰ࡹࡪࡱࡹࡥࡵ࠱ࡨࡲࡤ࠴࠮࠰ࡤࡤࡷࡪ࠴ࡪࡴࠫࠥࠫὛ"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if VMLf4PbgcKtjIA:
			VMLf4PbgcKtjIA = u6rbxnyjTl7I[KNIvHPjUbhr(u"࡙࠭ࡐࡗࡗ࡙ࡇࡋࠧ὜")][ybdv7XcT3lxF6QezULwCAGk]+VMLf4PbgcKtjIA[ybdv7XcT3lxF6QezULwCAGk]
			sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(lke5D6CpaAXPdEZyrBSw7T,wwPrSDa21lUh(u"ࠧࡈࡇࡗࠫὝ"),VMLf4PbgcKtjIA,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,sULh4NjakzI8He7xJCMGrql(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡞ࡕࡕࡕࡗࡅࡉ࠲࠺ࡴࡩࠩ὞"))
			mmU0kFVvyIHPX = sDQvwGASB0Vf67mik.content
			import youtube_signature.cipher as RMOxgDmWXqp7YTk9Z8Ac4KesNE5,youtube_signature.json_script_engine as p1s9vLRPcVmzMrGY
			USjQadAPteJK8uNn2BMExGzlkIoT7X = NXiEM7WIbKB8COHrGSZAj5QJe.USjQadAPteJK8uNn2BMExGzlkIoT7X.Cipher()
			USjQadAPteJK8uNn2BMExGzlkIoT7X._object_cache = {}
			mmNFhYWldfKwUagzEIuM = USjQadAPteJK8uNn2BMExGzlkIoT7X._load_javascript(mmU0kFVvyIHPX)
			LQvSmTxPo8NKjXYE = Cy9ow3c21nABMjzqeaIT(A6dMB1FlgxVivJ2fk9C(u"ࠩࡶࡸࡷ࠭Ὗ"),str(mmNFhYWldfKwUagzEIuM))
			K5BmMsWY8nw1fSJUHjck = NXiEM7WIbKB8COHrGSZAj5QJe.xfXpr1RkcjmIYLZ8SOW.JsonScriptEngine(LQvSmTxPo8NKjXYE)
	for dict in YZzymiV3jb128MqIXklFCN0LUHRJdx:
		url = dict[KNIvHPjUbhr(u"ࠪࡹࡷࡲࠧὠ")]
		if LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠫࡸ࡯ࡧ࡯ࡣࡷࡹࡷ࡫࠽ࠨὡ") in url or url.count(o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠬࡹࡩࡨ࠿ࠪὢ"))>bXukYxQ4aHw:
			iuMzFsZYx5Rr2IU8bTO14HJCSQtL.append(dict)
		elif mmU0kFVvyIHPX and A6dMB1FlgxVivJ2fk9C(u"࠭ࡳࠨὣ") in list(dict.keys()) and JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠧࡴࡲࠪὤ") in list(dict.keys()):
			X2D36McfiykldRBmvSp = K5BmMsWY8nw1fSJUHjck.execute(dict[xcChIL13BpR8WArNt9Pl0So(u"ࠨࡵࠪὥ")])
			if X2D36McfiykldRBmvSp!=dict[jeAby54c02TgG8zuivonX91(u"ࠩࡶࠫὦ")]:
				dict[dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠪࡹࡷࡲࠧὧ")] = url+XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠫࠫ࠭Ὠ")+dict[xcChIL13BpR8WArNt9Pl0So(u"ࠬࡹࡰࠨὩ")]+SqrG5mU3j96ldsFpExobw40TJY(u"࠭࠽ࠨὪ")+X2D36McfiykldRBmvSp
				iuMzFsZYx5Rr2IU8bTO14HJCSQtL.append(dict)
	for dict in iuMzFsZYx5Rr2IU8bTO14HJCSQtL:
		QWz1jXGo6ruOitUMqET7yI5,dgMTEAl51Ij4RJrhP2H8q,fn7XcRFi9zWg,ffSgj3D680,FFmqotMvR1UNhDB2659COir,fb0MVGEwp5yNkijcSeFXmOa = hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠧࡶࡰ࡮ࡲࡴࡽ࡮ࠨὫ"),OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠨࡷࡱ࡯ࡳࡵࡷ࡯ࠩὬ"),jeAby54c02TgG8zuivonX91(u"ࠩࡸࡲࡰࡴ࡯ࡸࡰࠪὭ"),FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"࡙ࠪࡳࡱ࡮ࡰࡹࡱࠫὮ"),hWGMqtBy4wuLaVcj,GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠫ࠵࠭Ὧ")
		try:
			GGwsOpVHLDXk2i3 = dict[KNIvHPjUbhr(u"ࠬࡺࡹࡱࡧࠪὰ")]
			GGwsOpVHLDXk2i3 = GGwsOpVHLDXk2i3.replace(FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"࠭ࠫࠨά"),hWGMqtBy4wuLaVcj)
			items = trdVA0JvFaD.findall(XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠧࠩ࠰࠭ࡃ࠮࠵ࠨ࠯ࠬࡂ࠭ࡀ࠴ࠪࡀࠤࠫ࠲࠯ࡅࠩࠣࠩὲ"),GGwsOpVHLDXk2i3,trdVA0JvFaD.DOTALL)
			ffSgj3D680,QWz1jXGo6ruOitUMqET7yI5,FFmqotMvR1UNhDB2659COir = items[ybdv7XcT3lxF6QezULwCAGk]
			lgU0NvekiER1d8xVtjwOGZhrpBaK = FFmqotMvR1UNhDB2659COir.split(rwQN9AKhLCuMfHxjlbX0U(u"ࠨ࠮ࠪέ"))
			dgMTEAl51Ij4RJrhP2H8q = hWGMqtBy4wuLaVcj
			for ImYg2jxU6Lc9Q1C4Oko in lgU0NvekiER1d8xVtjwOGZhrpBaK: dgMTEAl51Ij4RJrhP2H8q += ImYg2jxU6Lc9Q1C4Oko.split(jeAby54c02TgG8zuivonX91(u"ࠩ࠱ࠫὴ"))[ybdv7XcT3lxF6QezULwCAGk]+LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠪ࠰ࠬή")
			dgMTEAl51Ij4RJrhP2H8q = dgMTEAl51Ij4RJrhP2H8q.strip(OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠫ࠱࠭ὶ"))
			if HHoGx7Flus60(u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭ί") in list(dict.keys()): fb0MVGEwp5yNkijcSeFXmOa = str(float(dict[gDuGMR3z1aV6YdLmCpiO8Kl(u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧὸ")]*HHoGx7Flus60(u"࠶࠶থ"))//FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"࠷࠰࠳࠶দ")/HHoGx7Flus60(u"࠶࠶থ"))+NeO3CTLHrPfWUoIgy8Q(u"ࠧ࡬ࡤࡳࡷࠥࠦࠧό")
			else: fb0MVGEwp5yNkijcSeFXmOa = hWGMqtBy4wuLaVcj
			if ffSgj3D680==sULh4NjakzI8He7xJCMGrql(u"ࠨࡶࡨࡼࡹࡺࠧὺ"): continue
			elif MMizeNH0AKu(u"ࠩ࠯ࠫύ") in GGwsOpVHLDXk2i3:
				ffSgj3D680 = hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠪࡅ࠰࡜ࠧὼ")
				fn7XcRFi9zWg = QWz1jXGo6ruOitUMqET7yI5+FqcVAkh7WjIXHdDKf8nvuyRo+fb0MVGEwp5yNkijcSeFXmOa+dict[wwPrSDa21lUh(u"ࠫࡸ࡯ࡺࡦࠩώ")].split(dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠬࡾࠧ὾"))[bXukYxQ4aHw]
			elif ffSgj3D680==LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"࠭ࡶࡪࡦࡨࡳࠬ὿"):
				ffSgj3D680 = o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠧࡗ࡫ࡧࡩࡴ࠭ᾀ")
				fn7XcRFi9zWg = fb0MVGEwp5yNkijcSeFXmOa+dict[mkHKSQvjWr5BTcM3wVY(u"ࠨࡵ࡬ࡾࡪ࠭ᾁ")].split(dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠩࡻࠫᾂ"))[bXukYxQ4aHw]+FqcVAkh7WjIXHdDKf8nvuyRo+dict[jeAby54c02TgG8zuivonX91(u"ࠪࡪࡵࡹࠧᾃ")]+KBkxSYaz93pu1(u"ࠫ࡫ࡶࡳࠨᾄ")+FqcVAkh7WjIXHdDKf8nvuyRo+QWz1jXGo6ruOitUMqET7yI5
			elif ffSgj3D680==wwPrSDa21lUh(u"ࠬࡧࡵࡥ࡫ࡲࠫᾅ"):
				ffSgj3D680 = zyvJMtBhrw(u"࠭ࡁࡶࡦ࡬ࡳࠬᾆ")
				fn7XcRFi9zWg = fb0MVGEwp5yNkijcSeFXmOa+str(int(dict[o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠧࡢࡷࡧ࡭ࡴࡥࡳࡢ࡯ࡳࡰࡪࡥࡲࡢࡶࡨࠫᾇ")])/rwQN9AKhLCuMfHxjlbX0U(u"࠱࠱࠲࠳ধ"))+S1SgCFYGJeMvfp5iZXK(u"ࠨ࡭࡫ࡾࠥࠦࠧᾈ")+dict[jeAby54c02TgG8zuivonX91(u"ࠩࡤࡹࡩ࡯࡯ࡠࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠪᾉ")]+mkHKSQvjWr5BTcM3wVY(u"ࠪࡧ࡭࠭ᾊ")+FqcVAkh7WjIXHdDKf8nvuyRo+QWz1jXGo6ruOitUMqET7yI5
		except:
			wF5zRoQekA9lxOYacnju13yUIDs = R7RLCd9kyl.format_exc()
			if wF5zRoQekA9lxOYacnju13yUIDs!=rwQN9AKhLCuMfHxjlbX0U(u"ࠫࡓࡵ࡮ࡦࡖࡼࡴࡪࡀࠠࡏࡱࡱࡩࡡࡴࠧᾋ"): zGjD5QAkd7SO9YPcZl.stderr.write(wF5zRoQekA9lxOYacnju13yUIDs)
		if SqrG5mU3j96ldsFpExobw40TJY(u"ࠬࡪࡵࡳ࠿ࠪᾌ") in dict[JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"࠭ࡵࡳ࡮ࠪᾍ")]: oJV18NUZAzPGqMu7tenCxrkfhdl69B = round(SqrG5mU3j96ldsFpExobw40TJY(u"࠲࠱࠹঩")+float(dict[ITvnUAMXsyb4eO(u"ࠧࡶࡴ࡯ࠫᾎ")].split(jeAby54c02TgG8zuivonX91(u"ࠨࡦࡸࡶࡂ࠭ᾏ"),e2qDYgipPmTw4KvBLnochr(u"࠲ন"))[bXukYxQ4aHw].split(NeO3CTLHrPfWUoIgy8Q(u"ࠩࠩࠫᾐ"),bXukYxQ4aHw)[ybdv7XcT3lxF6QezULwCAGk]))
		elif rwQN9AKhLCuMfHxjlbX0U(u"ࠪࡥࡵࡶࡲࡰࡺࡇࡹࡷࡧࡴࡪࡱࡱࡑࡸ࠭ᾑ") in list(dict.keys()): oJV18NUZAzPGqMu7tenCxrkfhdl69B = round(DJ1ICpbyR2(u"࠳࠲࠺প")+float(dict[NeO3CTLHrPfWUoIgy8Q(u"ࠫࡦࡶࡰࡳࡱࡻࡈࡺࡸࡡࡵ࡫ࡲࡲࡒࡹࠧᾒ")])/KBkxSYaz93pu1(u"࠵࠵࠶࠰ফ"))
		else: oJV18NUZAzPGqMu7tenCxrkfhdl69B = xcChIL13BpR8WArNt9Pl0So(u"ࠬ࠶ࠧᾓ")
		if xcChIL13BpR8WArNt9Pl0So(u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧᾔ") not in list(dict.keys()): fb0MVGEwp5yNkijcSeFXmOa = dict[jeAby54c02TgG8zuivonX91(u"ࠧࡴ࡫ࡽࡩࠬᾕ")].split(GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠨࡺࠪᾖ"))[bXukYxQ4aHw]
		else: fb0MVGEwp5yNkijcSeFXmOa = dict[rwQN9AKhLCuMfHxjlbX0U(u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪᾗ")]
		if A6dMB1FlgxVivJ2fk9C(u"ࠪ࡭ࡳ࡯ࡴࠨᾘ") not in list(dict.keys()): dict[SqrG5mU3j96ldsFpExobw40TJY(u"ࠫ࡮ࡴࡩࡵࠩᾙ")] = LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠬ࠶࠭࠱ࠩᾚ")
		dict[OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"࠭ࡴࡪࡶ࡯ࡩࠬᾛ")] = ffSgj3D680+rwQN9AKhLCuMfHxjlbX0U(u"ࠧ࠻ࠢࠣࠫᾜ")+fn7XcRFi9zWg+CnbBKmtF1x84q7AW(u"ࠨࠢࠣࠬࠬᾝ")+dgMTEAl51Ij4RJrhP2H8q+KNIvHPjUbhr(u"ࠩ࠯ࠫᾞ")+dict[dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠪ࡭ࡹࡧࡧࠨᾟ")]+XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠫ࠮࠭ᾠ")
		dict[jeAby54c02TgG8zuivonX91(u"ࠬࡷࡵࡢ࡮࡬ࡸࡾ࠭ᾡ")] = fn7XcRFi9zWg.split(FqcVAkh7WjIXHdDKf8nvuyRo)[ybdv7XcT3lxF6QezULwCAGk].split(sULh4NjakzI8He7xJCMGrql(u"࠭࡫ࡣࡲࡶࠫᾢ"))[ybdv7XcT3lxF6QezULwCAGk]
		dict[FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠧࡵࡻࡳࡩ࠷࠭ᾣ")] = ffSgj3D680
		dict[zyvJMtBhrw(u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪᾤ")] = QWz1jXGo6ruOitUMqET7yI5
		dict[ITvnUAMXsyb4eO(u"ࠩࡦࡳࡩ࡫ࡣࡴࠩᾥ")] = FFmqotMvR1UNhDB2659COir
		dict[SqrG5mU3j96ldsFpExobw40TJY(u"ࠪࡨࡺࡸࡡࡵ࡫ࡲࡲࠬᾦ")] = oJV18NUZAzPGqMu7tenCxrkfhdl69B
		dict[SqrG5mU3j96ldsFpExobw40TJY(u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬᾧ")] = fb0MVGEwp5yNkijcSeFXmOa
		AwNVFHCY3RenJhQZ2POB9u40aEj6K.append(dict)
	lqubSefg0iRNYZkUj4cGyv6ATmP,uLNbmK84vxSURG3e9X,WV43shCBMp8du,vekHfWQAhuLgN1,xXWISdqa4Jic = [],[],[],[],[]
	CPEn4KkiUcgujsN,EACGax4tXcSpWbT,GEzYSct6Lj,a82m05hkPoTB4IyF,poHj5ArulSe31fqmF0Z2U = [],[],[],[],[]
	if ZZdHEetJc2IDzOXBkh:
		dict = {}
		dict[ITvnUAMXsyb4eO(u"ࠬࡺࡹࡱࡧ࠵ࠫᾨ")] = KNIvHPjUbhr(u"࠭ࡁࠬࡘࠪᾩ")
		dict[ITvnUAMXsyb4eO(u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩᾪ")] = jeAby54c02TgG8zuivonX91(u"ࠨ࡯ࡳࡨࠬᾫ")
		dict[dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠩࡷ࡭ࡹࡲࡥࠨᾬ")] = dict[hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠪࡸࡾࡶࡥ࠳ࠩᾭ")]+KBkxSYaz93pu1(u"ࠫ࠿ࠦࠠࠨᾮ")+dict[wwPrSDa21lUh(u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧᾯ")]+FqcVAkh7WjIXHdDKf8nvuyRo+sULh4NjakzI8He7xJCMGrql(u"࠭ฬ้ัฬࠤี้๊สࠩᾰ")
		dict[dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠧࡶࡴ࡯ࠫᾱ")] = ZZdHEetJc2IDzOXBkh
		dict[QvgnCALNstmuUJiET(u"ࠨࡳࡸࡥࡱ࡯ࡴࡺࠩᾲ")] = NeO3CTLHrPfWUoIgy8Q(u"ࠩ࠳ࠫᾳ")
		dict[dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫᾴ")] = LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠫ࠾࠾࠷࠷࠷࠷࠷࠷࠷࠰ࠨ᾵")
		AwNVFHCY3RenJhQZ2POB9u40aEj6K.append(dict)
	if laErqezQm1dh6A8ORPgn2M:
		o94WsYVfy3Nqrmg07,rFMaDkS4jJ8uwLPV = b8IJFKNyPjgE4GelaCSXB6Qht(laErqezQm1dh6A8ORPgn2M)
		Si7Ly9p8URGq = list(zip(o94WsYVfy3Nqrmg07,rFMaDkS4jJ8uwLPV))
		for title,llxFwq0CUNgQtivJzkHeGV in Si7Ly9p8URGq:
			dict = {}
			dict[hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠬࡺࡹࡱࡧ࠵ࠫᾶ")] = wwPrSDa21lUh(u"࠭ࡁࠬࡘࠪᾷ")
			dict[dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩᾸ")] = OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠨ࡯࠶ࡹ࠽࠭Ᾱ")
			dict[dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠩࡸࡶࡱ࠭Ὰ")] = llxFwq0CUNgQtivJzkHeGV
			if zyvJMtBhrw(u"ࠪ࡯ࡧࡶࡳࠨΆ") in title: dict[HHoGx7Flus60(u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬᾼ")] = title.split(jeAby54c02TgG8zuivonX91(u"ࠬࡱࡢࡱࡵࠪ᾽"))[ybdv7XcT3lxF6QezULwCAGk].rsplit(FqcVAkh7WjIXHdDKf8nvuyRo)[-bXukYxQ4aHw]
			else: dict[QVDJLRlxNg127jMX(u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧι")] = LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠧ࠲࠲ࠪ᾿")
			if title.count(FqcVAkh7WjIXHdDKf8nvuyRo)>bXukYxQ4aHw:
				QS8ZdxkHD5bjU9qsn4zMYaPrg3h7 = title.rsplit(FqcVAkh7WjIXHdDKf8nvuyRo)[-x1x9kIQo3zjZWnYaiy]
				if QS8ZdxkHD5bjU9qsn4zMYaPrg3h7.isdigit(): dict[dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠨࡳࡸࡥࡱ࡯ࡴࡺࠩ῀")] = QS8ZdxkHD5bjU9qsn4zMYaPrg3h7
				else: dict[dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠩࡴࡹࡦࡲࡩࡵࡻࠪ῁")] = MMizeNH0AKu(u"ࠪ࠴࠵࠶࠰ࠨῂ")
			if title==JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠫ࠲࠷ࠧῃ"): dict[rwQN9AKhLCuMfHxjlbX0U(u"ࠬࡺࡩࡵ࡮ࡨࠫῄ")] = dict[OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"࠭ࡴࡺࡲࡨ࠶ࠬ῅")]+sULh4NjakzI8He7xJCMGrql(u"ࠧ࠻ࠢࠣࠫῆ")+dict[rwQN9AKhLCuMfHxjlbX0U(u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪῇ")]+FqcVAkh7WjIXHdDKf8nvuyRo+sULh4NjakzI8He7xJCMGrql(u"ࠩฯ์ิฯࠠัๅํอࠬῈ")
			else: dict[zyvJMtBhrw(u"ࠪࡸ࡮ࡺ࡬ࡦࠩΈ")] = dict[LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠫࡹࡿࡰࡦ࠴ࠪῊ")]+wwPrSDa21lUh(u"ࠬࡀࠠࠡࠩΉ")+dict[wwPrSDa21lUh(u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨῌ")]+FqcVAkh7WjIXHdDKf8nvuyRo+dict[QVDJLRlxNg127jMX(u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ῍")]+LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠨ࡭ࡥࡴࡸࠦࠠࠨ῎")+dict[sULh4NjakzI8He7xJCMGrql(u"ࠩࡴࡹࡦࡲࡩࡵࡻࠪ῏")]
			AwNVFHCY3RenJhQZ2POB9u40aEj6K.append(dict)
	AwNVFHCY3RenJhQZ2POB9u40aEj6K = sorted(AwNVFHCY3RenJhQZ2POB9u40aEj6K,reverse=VBlawK4mgHSyLEn8iqhUkz5,key=lambda key: float(key[rwQN9AKhLCuMfHxjlbX0U(u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫῐ")]))
	if not AwNVFHCY3RenJhQZ2POB9u40aEj6K:
		if not mMQ3FkNVa4IlxqY:
			sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(lke5D6CpaAXPdEZyrBSw7T,DJ1ICpbyR2(u"ࠫࡌࡋࡔࠨῑ"),NPM3HKQ57xe,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,HHoGx7Flus60(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡛ࡒ࡙࡙࡛ࡂࡆ࠯࠸ࡸ࡭࠭ῒ"))
			mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
		qkrP6CTSuMFneV0EfAUgxm1RoWt = trdVA0JvFaD.findall(OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"࠭ࡣ࡭ࡣࡶࡷࡂࠨ࡭ࡦࡵࡶࡥ࡬࡫ࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩΐ"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		LwBM9FdHl8aE3iDh5IgzY02kZ = trdVA0JvFaD.findall(JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠧࠣࡲ࡯ࡥࡾ࡫ࡲࡆࡴࡵࡳࡷࡓࡥࡴࡵࡤ࡫ࡪࡘࡥ࡯ࡦࡨࡶࡪࡸࠢ࠻࡞ࡾࠦࡸࡻࡢࡳࡧࡤࡷࡴࡴࠢ࠻࡞ࡾࠦࡷࡻ࡮ࡴࠤ࠽ࡠࡠࡢࡻࠣࡶࡨࡼࡹࡺࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ῔"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		jdkSvGmCp0WOLoqJUYiTAZ = trdVA0JvFaD.findall(S1SgCFYGJeMvfp5iZXK(u"ࠨࠤࡳࡰࡦࡿࡥࡳࡇࡵࡶࡴࡸࡍࡦࡵࡶࡥ࡬࡫ࡒࡦࡰࡧࡩࡷ࡫ࡲࠣ࠼࡟ࡿࠧࡸࡥࡢࡵࡲࡲࠧࡀࡻࠣࡵ࡬ࡱࡵࡲࡥࡕࡧࡻࡸࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ῕"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		UcBD7WEkIXbmzFJe8 = trdVA0JvFaD.findall(HHoGx7Flus60(u"ࠩࠥࡴࡱࡧࡹࡦࡴࡈࡶࡷࡵࡲࡎࡧࡶࡷࡦ࡭ࡥࡓࡧࡱࡨࡪࡸࡥࡳࠤ࠽ࡠࢀࠨࡳࡶࡤࡵࡩࡦࡹ࡯࡯ࠤ࠽ࡿࠧࡹࡩ࡮ࡲ࡯ࡩ࡙࡫ࡸࡵࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫῖ"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		try: L7FtKC923VAjgQUvoZkBIs5OT4J = kyj0IMV6ZfCgo9S23qJWN8r[rwQN9AKhLCuMfHxjlbX0U(u"ࠪࡴࡱࡧࡹࡢࡤ࡬ࡰ࡮ࡺࡹࡔࡶࡤࡸࡺࡹࠧῗ")][LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠫࡪࡸࡲࡰࡴࡖࡧࡷ࡫ࡥ࡯ࠩῘ")][SqrG5mU3j96ldsFpExobw40TJY(u"ࠬࡩ࡯࡯ࡨ࡬ࡶࡲࡊࡩࡢ࡮ࡲ࡫ࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭Ῑ")][HHoGx7Flus60(u"࠭ࡴࡪࡶ࡯ࡩࠬῚ")][hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠧࡳࡷࡱࡷࠬΊ")][ybdv7XcT3lxF6QezULwCAGk][SqrG5mU3j96ldsFpExobw40TJY(u"ࠨࡶࡨࡼࡹࡺࠧ῜")]
		except: L7FtKC923VAjgQUvoZkBIs5OT4J = hWGMqtBy4wuLaVcj
		try: hV46DQRUxn3ASjGbckw9gFEP = kyj0IMV6ZfCgo9S23qJWN8r[JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠩࡳࡰࡦࡿࡡࡣ࡫࡯࡭ࡹࡿࡓࡵࡣࡷࡹࡸ࠭῝")][jeAby54c02TgG8zuivonX91(u"ࠪࡩࡷࡸ࡯ࡳࡕࡦࡶࡪ࡫࡮ࠨ῞")][GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠫࡨࡵ࡮ࡧ࡫ࡵࡱࡉ࡯ࡡ࡭ࡱࡪࡖࡪࡴࡤࡦࡴࡨࡶࠬ῟")][A6dMB1FlgxVivJ2fk9C(u"ࠬࡪࡩࡢ࡮ࡲ࡫ࡒ࡫ࡳࡴࡣࡪࡩࡸ࠭ῠ")][ybdv7XcT3lxF6QezULwCAGk][FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"࠭ࡲࡶࡰࡶࠫῡ")][ybdv7XcT3lxF6QezULwCAGk][CnbBKmtF1x84q7AW(u"ࠧࡵࡧࡻࡸࡹ࠭ῢ")]
		except: hV46DQRUxn3ASjGbckw9gFEP = hWGMqtBy4wuLaVcj
		try: rWFTOfue0A12Qv3lqVsko = kyj0IMV6ZfCgo9S23qJWN8r[A6dMB1FlgxVivJ2fk9C(u"ࠨࡲ࡯ࡥࡾࡧࡢࡪ࡮࡬ࡸࡾ࡙ࡴࡢࡶࡸࡷࠬΰ")][KBkxSYaz93pu1(u"ࠩࡵࡩࡦࡹ࡯࡯ࠩῤ")]
		except: rWFTOfue0A12Qv3lqVsko = hWGMqtBy4wuLaVcj
		if qkrP6CTSuMFneV0EfAUgxm1RoWt or LwBM9FdHl8aE3iDh5IgzY02kZ or jdkSvGmCp0WOLoqJUYiTAZ or UcBD7WEkIXbmzFJe8 or L7FtKC923VAjgQUvoZkBIs5OT4J or hV46DQRUxn3ASjGbckw9gFEP or rWFTOfue0A12Qv3lqVsko:
			if   qkrP6CTSuMFneV0EfAUgxm1RoWt: jjEwJpmd2v0oxBRP1Dyu = qkrP6CTSuMFneV0EfAUgxm1RoWt[ybdv7XcT3lxF6QezULwCAGk]
			elif LwBM9FdHl8aE3iDh5IgzY02kZ: jjEwJpmd2v0oxBRP1Dyu = LwBM9FdHl8aE3iDh5IgzY02kZ[ybdv7XcT3lxF6QezULwCAGk]
			elif jdkSvGmCp0WOLoqJUYiTAZ: jjEwJpmd2v0oxBRP1Dyu = jdkSvGmCp0WOLoqJUYiTAZ[ybdv7XcT3lxF6QezULwCAGk]
			elif UcBD7WEkIXbmzFJe8: jjEwJpmd2v0oxBRP1Dyu = UcBD7WEkIXbmzFJe8[ybdv7XcT3lxF6QezULwCAGk]
			elif L7FtKC923VAjgQUvoZkBIs5OT4J: jjEwJpmd2v0oxBRP1Dyu = L7FtKC923VAjgQUvoZkBIs5OT4J
			elif hV46DQRUxn3ASjGbckw9gFEP: jjEwJpmd2v0oxBRP1Dyu = hV46DQRUxn3ASjGbckw9gFEP
			elif rWFTOfue0A12Qv3lqVsko: jjEwJpmd2v0oxBRP1Dyu = rWFTOfue0A12Qv3lqVsko
			mmCEABXduHLWkNoQ9t0pTlba6q = jjEwJpmd2v0oxBRP1Dyu.replace(NXMOzZjYsmS9pf,hWGMqtBy4wuLaVcj).strip(Mpsm2VF1OBnCRvK3qf6)
			JqTEOoIhVQpsRlMG2tSbvKywg0mDBZ = hXB0vKVQ5PRI91SDTprMdfuHEm4+JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"๋ࠪีอࠠศๆไ๎ิ๐่ࠡใํ๋๋ࠥิไๆฬࠤ࠳࠴ࠠฤ๊ࠣ฾๏ืࠠๆๆสส๊ࠦไษ฻ูࠤฬ๊ๅิฬัำ๊๐ๆࠡ࠰࠱ࠤศ๎ࠠ฻์ิࠤ๊ะ่โำࠣห้ศๆࠡ࠰࠱ࠤศ๎๋๊ࠠอ๎ํฮ๋ࠠฯอหัࠦิ๋ร้ࠣาีฯࠡ࠰࠱ࠤศ๎๋๊ࠠอ๎ํฮࠠ฻์ิࠤ็อฯาࠢฦ๊ࠥ๐ิ฻ๆࠣห้็๊ะ์๋ࠤฬ๊ย็ࠩῥ")+YYSh2J6BIrsm8
			BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠫึูวๅห้๋ࠣࠦวๅ็๋ๆ฾่ࠦศๆ่ฬึ๋ฬࠨῦ"),JqTEOoIhVQpsRlMG2tSbvKywg0mDBZ+jeAby54c02TgG8zuivonX91(u"ࠬࡢ࡮࡝ࡰࠪῧ")+soMVfbr6WtpNlcSA+rwQN9AKhLCuMfHxjlbX0U(u"࠭ัิษ็อ๋ࠥๆࠡ์๋ฮ๏๎ศࠨῨ")+YYSh2J6BIrsm8+NXMOzZjYsmS9pf+mmCEABXduHLWkNoQ9t0pTlba6q)
			return DJ1ICpbyR2(u"ࠧࡆࡴࡵࡳࡷࠦࠠࠡࠢ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷ࡙ࠦࡐࡗࡗ࡙ࡇࡋࠠࡇࡣ࡬ࡰࡪࡪ࠺ࠡࠩῩ")+mmCEABXduHLWkNoQ9t0pTlba6q,[],[]
		else: return rwQN9AKhLCuMfHxjlbX0U(u"ࠨࡇࡵࡶࡴࡸࠠࠡࠢࠣ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸ࡚ࠠࡑࡘࡘ࡚ࡈࡅࠡࡈࡤ࡭ࡱ࡫ࡤࠨῪ"),[],[]
	NWjDgVEL7a,u6unfUvDSM2AsItNqKZ1y5OCb9lPHY,JRDBdgXMWyU17GNOFI = [],[],[]
	for dict in AwNVFHCY3RenJhQZ2POB9u40aEj6K:
		if dict[S1SgCFYGJeMvfp5iZXK(u"ࠩࡷࡽࡵ࡫࠲ࠨΎ")]==S1SgCFYGJeMvfp5iZXK(u"࡚ࠪ࡮ࡪࡥࡰࠩῬ"):
			lqubSefg0iRNYZkUj4cGyv6ATmP.append(dict[ITvnUAMXsyb4eO(u"ࠫࡹ࡯ࡴ࡭ࡧࠪ῭")])
			CPEn4KkiUcgujsN.append(dict)
		elif dict[KBkxSYaz93pu1(u"ࠬࡺࡹࡱࡧ࠵ࠫ΅")]==DJ1ICpbyR2(u"࠭ࡁࡶࡦ࡬ࡳࠬ`"):
			uLNbmK84vxSURG3e9X.append(dict[zyvJMtBhrw(u"ࠧࡵ࡫ࡷࡰࡪ࠭῰")])
			EACGax4tXcSpWbT.append(dict)
		elif dict[JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪ῱")]==LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠩࡰࡴࡩ࠭ῲ"):
			title = dict[mkHKSQvjWr5BTcM3wVY(u"ࠪࡸ࡮ࡺ࡬ࡦࠩῳ")].replace(QvgnCALNstmuUJiET(u"ࠫࡆ࠱ࡖ࠻ࠢࠣࠫῴ"),hWGMqtBy4wuLaVcj)
			if xcChIL13BpR8WArNt9Pl0So(u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭῵") not in list(dict.keys()): fb0MVGEwp5yNkijcSeFXmOa = A6dMB1FlgxVivJ2fk9C(u"࠭࠰ࠨῶ")
			else: fb0MVGEwp5yNkijcSeFXmOa = dict[e2qDYgipPmTw4KvBLnochr(u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨῷ")]
			NWjDgVEL7a.append([dict,{},title,fb0MVGEwp5yNkijcSeFXmOa])
		else:
			title = dict[sULh4NjakzI8He7xJCMGrql(u"ࠨࡶ࡬ࡸࡱ࡫ࠧῸ")].replace(LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠩࡄ࠯࡛ࡀࠠࠡࠩΌ"),hWGMqtBy4wuLaVcj)
			if QvgnCALNstmuUJiET(u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫῺ") not in list(dict.keys()): fb0MVGEwp5yNkijcSeFXmOa = HHoGx7Flus60(u"ࠫ࠵࠭Ώ")
			else: fb0MVGEwp5yNkijcSeFXmOa = dict[hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭ῼ")]
			NWjDgVEL7a.append([dict,{},title,fb0MVGEwp5yNkijcSeFXmOa])
			WV43shCBMp8du.append(title)
			GEzYSct6Lj.append(dict)
		tLyI1AVp3bRvdBGjUeHTu20Mq = VBlawK4mgHSyLEn8iqhUkz5
		if wwPrSDa21lUh(u"࠭ࡣࡰࡦࡨࡧࡸ࠭´") in list(dict.keys()):
			if o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠧࡢࡸ࠳ࠫ῾") in dict[wwPrSDa21lUh(u"ࠨࡥࡲࡨࡪࡩࡳࠨ῿")]: tLyI1AVp3bRvdBGjUeHTu20Mq = fEXMiAyG3ql4vKB
			elif guSzmUCXDa1tQpY<QVDJLRlxNg127jMX(u"࠶࠾ব"):
				if MMizeNH0AKu(u"ࠫࡦࡼࡣࠨࠀ") not in dict[sULh4NjakzI8He7xJCMGrql(u"ࠬࡩ࡯ࡥࡧࡦࡷࠬࠁ")] and LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"࠭࡭ࡱ࠶ࡤࠫࠂ") not in dict[gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠧࡤࡱࡧࡩࡨࡹࠧࠃ")]: tLyI1AVp3bRvdBGjUeHTu20Mq = fEXMiAyG3ql4vKB
		if dict[KNIvHPjUbhr(u"ࠨࡶࡼࡴࡪ࠸ࠧࠄ")]==OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"࡙ࠩ࡭ࡩ࡫࡯ࠨࠅ") and dict[dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠪ࡭ࡳ࡯ࡴࠨࠆ")]!=S1SgCFYGJeMvfp5iZXK(u"ࠫ࠵࠳࠰ࠨࠇ") and tLyI1AVp3bRvdBGjUeHTu20Mq==VBlawK4mgHSyLEn8iqhUkz5:
			xXWISdqa4Jic.append(dict[LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠬࡺࡩࡵ࡮ࡨࠫࠈ")])
			poHj5ArulSe31fqmF0Z2U.append(dict)
		elif dict[CnbBKmtF1x84q7AW(u"࠭ࡴࡺࡲࡨ࠶ࠬࠉ")]==LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠧࡂࡷࡧ࡭ࡴ࠭ࠊ") and dict[MMizeNH0AKu(u"ࠨ࡫ࡱ࡭ࡹ࠭ࠋ")]!=A6dMB1FlgxVivJ2fk9C(u"ࠩ࠳࠱࠵࠭ࠌ") and tLyI1AVp3bRvdBGjUeHTu20Mq==VBlawK4mgHSyLEn8iqhUkz5:
			vekHfWQAhuLgN1.append(dict[o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠪࡸ࡮ࡺ࡬ࡦࠩࠍ")])
			a82m05hkPoTB4IyF.append(dict)
	for xx2KsYMGZkrVCN in a82m05hkPoTB4IyF:
		X5qHAjLUBdyciIFvZx73WOgD = xx2KsYMGZkrVCN[zyvJMtBhrw(u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬࠎ")]
		for yrwp9qvTFf0Bb6oOam1PhnS in poHj5ArulSe31fqmF0Z2U:
			vvT3IWxDJfAlsMBVyGOg8pcP = yrwp9qvTFf0Bb6oOam1PhnS[gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭ࠏ")]
			fb0MVGEwp5yNkijcSeFXmOa = vvT3IWxDJfAlsMBVyGOg8pcP+X5qHAjLUBdyciIFvZx73WOgD
			title = yrwp9qvTFf0Bb6oOam1PhnS[o1u5dij9UrcbXzVS8lwIWfKpnqM(u"࠭ࡴࡪࡶ࡯ࡩࠬࠐ")].replace(sULh4NjakzI8He7xJCMGrql(u"ࠧࡗ࡫ࡧࡩࡴࡀࠠࠡࠩࠑ"),gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠨ࡯ࡳࡨࠥࠦࠧࠒ"))
			title = title.replace(yrwp9qvTFf0Bb6oOam1PhnS[hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠫࠓ")]+FqcVAkh7WjIXHdDKf8nvuyRo,hWGMqtBy4wuLaVcj)
			title = title.replace(str((float(vvT3IWxDJfAlsMBVyGOg8pcP*LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"࠷࠰ভ"))//KNIvHPjUbhr(u"࠱࠱࠴࠷ম")/LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"࠷࠰ভ")))+ITvnUAMXsyb4eO(u"ࠪ࡯ࡧࡶࡳࠨࠔ"),str((float(fb0MVGEwp5yNkijcSeFXmOa*LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"࠷࠰ভ"))//KNIvHPjUbhr(u"࠱࠱࠴࠷ম")/LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"࠷࠰ভ")))+CnbBKmtF1x84q7AW(u"ࠫࡰࡨࡰࡴࠩࠕ"))
			title = title+jeAby54c02TgG8zuivonX91(u"ࠬ࠮ࠧࠖ")+xx2KsYMGZkrVCN[QVDJLRlxNg127jMX(u"࠭ࡴࡪࡶ࡯ࡩࠬࠗ")].split(OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠧࠩࠩ࠘"),bXukYxQ4aHw)[bXukYxQ4aHw]
			NWjDgVEL7a.append([yrwp9qvTFf0Bb6oOam1PhnS,xx2KsYMGZkrVCN,title,fb0MVGEwp5yNkijcSeFXmOa])
	NWjDgVEL7a = sorted(NWjDgVEL7a, reverse=VBlawK4mgHSyLEn8iqhUkz5, key=lambda key: float(key[x1x9kIQo3zjZWnYaiy]))
	for yrwp9qvTFf0Bb6oOam1PhnS,xx2KsYMGZkrVCN,title,fb0MVGEwp5yNkijcSeFXmOa in NWjDgVEL7a:
		ZyRfKW0gTe4k = yrwp9qvTFf0Bb6oOam1PhnS[KNIvHPjUbhr(u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪ࠙")]
		if JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠫࠚ") in list(xx2KsYMGZkrVCN.keys()):
			ZyRfKW0gTe4k = zyvJMtBhrw(u"ࠪࡱࡵࡪࠧࠛ")
		if ZyRfKW0gTe4k not in JRDBdgXMWyU17GNOFI:
			JRDBdgXMWyU17GNOFI.append(ZyRfKW0gTe4k)
			u6unfUvDSM2AsItNqKZ1y5OCb9lPHY.append([yrwp9qvTFf0Bb6oOam1PhnS,xx2KsYMGZkrVCN,title,fb0MVGEwp5yNkijcSeFXmOa])
	KSQJp8ZsI3eTuarvb2iyFU4gl,w68rPGt4mBz,TUkQVpXSq4PEfKvYtAxe = [],[],ybdv7XcT3lxF6QezULwCAGk
	k4w2OHEX8lyWnM7baZsoUhGJ5FCQ,xTE9wOJXi6hQySHt0rLk147dpBAv = hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj
	try: k4w2OHEX8lyWnM7baZsoUhGJ5FCQ = kyj0IMV6ZfCgo9S23qJWN8r[FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠫࡻ࡯ࡤࡦࡱࡇࡩࡹࡧࡩ࡭ࡵࠪࠜ")][zyvJMtBhrw(u"ࠬࡧࡵࡵࡪࡲࡶࠬࠝ")]
	except: k4w2OHEX8lyWnM7baZsoUhGJ5FCQ = hWGMqtBy4wuLaVcj
	try: MjFLvgYU9dtuBh3rpyEDb7VC = kyj0IMV6ZfCgo9S23qJWN8r[NeO3CTLHrPfWUoIgy8Q(u"࠭ࡶࡪࡦࡨࡳࡉ࡫ࡴࡢ࡫࡯ࡷࠬࠞ")][hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠧࡤࡪࡤࡲࡳ࡫࡬ࡊࡦࠪࠟ")]
	except: MjFLvgYU9dtuBh3rpyEDb7VC = hWGMqtBy4wuLaVcj
	if k4w2OHEX8lyWnM7baZsoUhGJ5FCQ and MjFLvgYU9dtuBh3rpyEDb7VC:
		TUkQVpXSq4PEfKvYtAxe += bXukYxQ4aHw
		title = hXB0vKVQ5PRI91SDTprMdfuHEm4+JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠨࡑ࡚ࡒࡊࡘ࠺ࠡࠢࠪࠠ")+k4w2OHEX8lyWnM7baZsoUhGJ5FCQ+YYSh2J6BIrsm8
		llxFwq0CUNgQtivJzkHeGV = u6rbxnyjTl7I[xcChIL13BpR8WArNt9Pl0So(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪࠡ")][ybdv7XcT3lxF6QezULwCAGk]+CnbBKmtF1x84q7AW(u"ࠪ࠳ࡨ࡮ࡡ࡯ࡰࡨࡰ࠴࠭ࠢ")+MjFLvgYU9dtuBh3rpyEDb7VC
		KSQJp8ZsI3eTuarvb2iyFU4gl.append(title)
		w68rPGt4mBz.append(llxFwq0CUNgQtivJzkHeGV)
		try: xTE9wOJXi6hQySHt0rLk147dpBAv = kyj0IMV6ZfCgo9S23qJWN8r[DJ1ICpbyR2(u"ࠫࡻ࡯ࡤࡦࡱࡇࡩࡹࡧࡩ࡭ࡵࠪࠣ")][wwPrSDa21lUh(u"ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࠨࠤ")][LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡵࠪࠥ")][-bXukYxQ4aHw][A6dMB1FlgxVivJ2fk9C(u"ࠧࡶࡴ࡯ࠫࠦ")]
		except: pass
	for yrwp9qvTFf0Bb6oOam1PhnS,xx2KsYMGZkrVCN,title,fb0MVGEwp5yNkijcSeFXmOa in u6unfUvDSM2AsItNqKZ1y5OCb9lPHY:
		KSQJp8ZsI3eTuarvb2iyFU4gl.append(title) ; w68rPGt4mBz.append(zyvJMtBhrw(u"ࠨࡪ࡬࡫࡭࡫ࡳࡵࠩࠧ"))
	if WV43shCBMp8du: KSQJp8ZsI3eTuarvb2iyFU4gl.append(OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ุࠩ์ึฯ้ࠠื๋ฮ๋ࠥอะัฬࠫࠨ")) ; w68rPGt4mBz.append(ITvnUAMXsyb4eO(u"ࠪࡱࡺࡾࡥࡥࠩࠩ"))
	if NWjDgVEL7a: KSQJp8ZsI3eTuarvb2iyFU4gl.append(GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ฺࠫ๎ัสู๋ࠢํะࠠศๆ่ฮํ็ัࠨࠪ")) ; w68rPGt4mBz.append(e2qDYgipPmTw4KvBLnochr(u"ࠬࡧ࡬࡭ࠩࠫ"))
	if xXWISdqa4Jic: KSQJp8ZsI3eTuarvb2iyFU4gl.append(XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"࠭࡭ࡱࡦࠣหำะัࠡษ็ูํืษ๊ࠡสฺ่๎สࠨࠬ")) ; w68rPGt4mBz.append(A6dMB1FlgxVivJ2fk9C(u"ࠧ࡮ࡲࡧࠫ࠭"))
	if lqubSefg0iRNYZkUj4cGyv6ATmP: KSQJp8ZsI3eTuarvb2iyFU4gl.append(JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠨื๋ีฮࠦศะ๊้ࠤฺ๎สࠨ࠮")) ; w68rPGt4mBz.append(rwQN9AKhLCuMfHxjlbX0U(u"ࠩࡹ࡭ࡩ࡫࡯ࠨ࠯"))
	if uLNbmK84vxSURG3e9X: KSQJp8ZsI3eTuarvb2iyFU4gl.append(JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ูࠪํะࠠษั๋๊ࠥ฻่าหࠪ࠰")) ; w68rPGt4mBz.append(KNIvHPjUbhr(u"ࠫࡦࡻࡤࡪࡱࠪ࠱"))
	M2MQxnfp4RXPqFKk = fEXMiAyG3ql4vKB
	while VBlawK4mgHSyLEn8iqhUkz5:
		OODLkJlZCoKmrzbg2XQSGPUdInA = Eb7qJoNwOgn(R0RomVJMUewGQcd, KSQJp8ZsI3eTuarvb2iyFU4gl)
		if OODLkJlZCoKmrzbg2XQSGPUdInA==-bXukYxQ4aHw: return MMizeNH0AKu(u"ࠬࡋࡘࡊࡖࡢࡅࡑࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ࠲"),[],[]
		elif OODLkJlZCoKmrzbg2XQSGPUdInA==ybdv7XcT3lxF6QezULwCAGk and k4w2OHEX8lyWnM7baZsoUhGJ5FCQ:
			llxFwq0CUNgQtivJzkHeGV = w68rPGt4mBz[OODLkJlZCoKmrzbg2XQSGPUdInA]
			RGPB3cEyAdFC6pxI29MHXUSgkrb = zGjD5QAkd7SO9YPcZl.argv[ybdv7XcT3lxF6QezULwCAGk]+rwQN9AKhLCuMfHxjlbX0U(u"࠭࠿ࡵࡻࡳࡩࡂ࡬࡯࡭ࡦࡨࡶࠫࡳ࡯ࡥࡧࡀ࠵࠹࠷ࠦ࡯ࡣࡰࡩࡂ࠭࠳")+e1mT8H4dGS3XFyx0KLUA9(k4w2OHEX8lyWnM7baZsoUhGJ5FCQ)+S1SgCFYGJeMvfp5iZXK(u"ࠧࠧࡷࡵࡰࡂ࠭࠴")+llxFwq0CUNgQtivJzkHeGV
			if xTE9wOJXi6hQySHt0rLk147dpBAv: RGPB3cEyAdFC6pxI29MHXUSgkrb = RGPB3cEyAdFC6pxI29MHXUSgkrb+sULh4NjakzI8He7xJCMGrql(u"ࠨࠨ࡬ࡱࡦ࡭ࡥ࠾ࠩ࠵")+e1mT8H4dGS3XFyx0KLUA9(xTE9wOJXi6hQySHt0rLk147dpBAv)
			MMk8qKvcJe4fQHm3EG7diBD5.executebuiltin(A6dMB1FlgxVivJ2fk9C(u"ࠤࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳࡛ࡰࡥࡣࡷࡩ࠭ࠨ࠶")+RGPB3cEyAdFC6pxI29MHXUSgkrb+wwPrSDa21lUh(u"ࠥ࠭ࠧ࠷"))
			return CnbBKmtF1x84q7AW(u"ࠫࡊ࡞ࡉࡕࡡࡄࡐࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ࠸"),[],[]
		NN8u2B5iU3RMYheFy = w68rPGt4mBz[OODLkJlZCoKmrzbg2XQSGPUdInA]
		PFHNy3aeMz4qWISd6iVCQcU0Ew7 = KSQJp8ZsI3eTuarvb2iyFU4gl[OODLkJlZCoKmrzbg2XQSGPUdInA]
		if NN8u2B5iU3RMYheFy==JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠬࡪࡡࡴࡪࠪ࠹"):
			QQRydi8qX7w1zWcKZfYEouVULA = ZZdHEetJc2IDzOXBkh
			break
		elif NN8u2B5iU3RMYheFy in [DJ1ICpbyR2(u"࠭ࡡࡶࡦ࡬ࡳࠬ࠺"),o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠧࡷ࡫ࡧࡩࡴ࠭࠻"),A6dMB1FlgxVivJ2fk9C(u"ࠨ࡯ࡸࡼࡪࡪࠧ࠼")]:
			if NN8u2B5iU3RMYheFy==GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠩࡰࡹࡽ࡫ࡤࠨ࠽"): haq1bHZINPE58uoBFnKfTSO2ik4,qXP3Q0oL7AVFIJglMYKiOb6EjSv = WV43shCBMp8du,GEzYSct6Lj
			elif NN8u2B5iU3RMYheFy==xcChIL13BpR8WArNt9Pl0So(u"ࠪࡺ࡮ࡪࡥࡰࠩ࠾"): haq1bHZINPE58uoBFnKfTSO2ik4,qXP3Q0oL7AVFIJglMYKiOb6EjSv = lqubSefg0iRNYZkUj4cGyv6ATmP,CPEn4KkiUcgujsN
			elif NN8u2B5iU3RMYheFy==FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠫࡦࡻࡤࡪࡱࠪ࠿"): haq1bHZINPE58uoBFnKfTSO2ik4,qXP3Q0oL7AVFIJglMYKiOb6EjSv = uLNbmK84vxSURG3e9X,EACGax4tXcSpWbT
			OODLkJlZCoKmrzbg2XQSGPUdInA = Eb7qJoNwOgn(OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠬอฮหำࠣห้๋ไโࠢࠫࠫࡀ")+str(len(haq1bHZINPE58uoBFnKfTSO2ik4))+sULh4NjakzI8He7xJCMGrql(u"࠭ࠠๆๆไ࠭ࠬࡁ"), haq1bHZINPE58uoBFnKfTSO2ik4)
			if OODLkJlZCoKmrzbg2XQSGPUdInA!=-bXukYxQ4aHw:
				QQRydi8qX7w1zWcKZfYEouVULA = qXP3Q0oL7AVFIJglMYKiOb6EjSv[OODLkJlZCoKmrzbg2XQSGPUdInA][S1SgCFYGJeMvfp5iZXK(u"ࠧࡶࡴ࡯ࠫࡂ")]
				PFHNy3aeMz4qWISd6iVCQcU0Ew7 = haq1bHZINPE58uoBFnKfTSO2ik4[OODLkJlZCoKmrzbg2XQSGPUdInA]
				break
		elif NN8u2B5iU3RMYheFy==A6dMB1FlgxVivJ2fk9C(u"ࠨ࡯ࡳࡨࠬࡃ"):
			OODLkJlZCoKmrzbg2XQSGPUdInA = Eb7qJoNwOgn(A6dMB1FlgxVivJ2fk9C(u"ࠩสาฯืࠠอ๊าอࠥอไึ๊ิอࠥ࠮ࠧࡄ")+str(len(xXWISdqa4Jic))+XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠪࠤ๊๊แࠪࠩࡅ"), xXWISdqa4Jic)
			if OODLkJlZCoKmrzbg2XQSGPUdInA!=-bXukYxQ4aHw:
				PFHNy3aeMz4qWISd6iVCQcU0Ew7 = xXWISdqa4Jic[OODLkJlZCoKmrzbg2XQSGPUdInA]
				RNZs9pkQtMfO2g1ho = poHj5ArulSe31fqmF0Z2U[OODLkJlZCoKmrzbg2XQSGPUdInA]
				OODLkJlZCoKmrzbg2XQSGPUdInA = Eb7qJoNwOgn(wwPrSDa21lUh(u"ࠫฬิสาࠢฯ์ิฯࠠศๆุ์ฯࠦࠨࠨࡆ")+str(len(vekHfWQAhuLgN1))+S1SgCFYGJeMvfp5iZXK(u"ࠬࠦๅๅใࠬࠫࡇ"), vekHfWQAhuLgN1)
				if OODLkJlZCoKmrzbg2XQSGPUdInA!=-bXukYxQ4aHw:
					PFHNy3aeMz4qWISd6iVCQcU0Ew7 += DJ1ICpbyR2(u"࠭ࠠࠬࠢࠪࡈ")+vekHfWQAhuLgN1[OODLkJlZCoKmrzbg2XQSGPUdInA]
					MBUzn8FAOb0aEQLlI2xP = a82m05hkPoTB4IyF[OODLkJlZCoKmrzbg2XQSGPUdInA]
					M2MQxnfp4RXPqFKk = VBlawK4mgHSyLEn8iqhUkz5
					break
		elif NN8u2B5iU3RMYheFy==jeAby54c02TgG8zuivonX91(u"ࠧࡢ࡮࡯ࠫࡉ"):
			DD3itHhVn0yamRfeq6U5l1P,hVYQxy4MfsTqSbiDpH8F23P,nXjaSbKLfEZo10gQxtUPcH2qrGkui,UNZ7mKSHzGw1k25bahV3cCI = list(zip(*NWjDgVEL7a))
			OODLkJlZCoKmrzbg2XQSGPUdInA = Eb7qJoNwOgn(ITvnUAMXsyb4eO(u"ࠨษัฮึࠦวๅ็็ๅࠥ࠮ࠧࡊ")+str(len(nXjaSbKLfEZo10gQxtUPcH2qrGkui))+zyvJMtBhrw(u"้้ࠩࠣ็ࠩࠨࡋ"), nXjaSbKLfEZo10gQxtUPcH2qrGkui)
			if OODLkJlZCoKmrzbg2XQSGPUdInA!=-bXukYxQ4aHw:
				PFHNy3aeMz4qWISd6iVCQcU0Ew7 = nXjaSbKLfEZo10gQxtUPcH2qrGkui[OODLkJlZCoKmrzbg2XQSGPUdInA]
				RNZs9pkQtMfO2g1ho = DD3itHhVn0yamRfeq6U5l1P[OODLkJlZCoKmrzbg2XQSGPUdInA]
				if SqrG5mU3j96ldsFpExobw40TJY(u"ࠪࡱࡵࡪࠧࡌ") in nXjaSbKLfEZo10gQxtUPcH2qrGkui[OODLkJlZCoKmrzbg2XQSGPUdInA] and RNZs9pkQtMfO2g1ho[e2qDYgipPmTw4KvBLnochr(u"ࠫࡺࡸ࡬ࠨࡍ")]!=ZZdHEetJc2IDzOXBkh:
					MBUzn8FAOb0aEQLlI2xP = hVYQxy4MfsTqSbiDpH8F23P[OODLkJlZCoKmrzbg2XQSGPUdInA]
					M2MQxnfp4RXPqFKk = VBlawK4mgHSyLEn8iqhUkz5
				else: QQRydi8qX7w1zWcKZfYEouVULA = RNZs9pkQtMfO2g1ho[wwPrSDa21lUh(u"ࠬࡻࡲ࡭ࠩࡎ")]
				break
		elif NN8u2B5iU3RMYheFy==zyvJMtBhrw(u"࠭ࡨࡪࡩ࡫ࡩࡸࡺࠧࡏ"):
			DD3itHhVn0yamRfeq6U5l1P,hVYQxy4MfsTqSbiDpH8F23P,nXjaSbKLfEZo10gQxtUPcH2qrGkui,UNZ7mKSHzGw1k25bahV3cCI = list(zip(*u6unfUvDSM2AsItNqKZ1y5OCb9lPHY))
			RNZs9pkQtMfO2g1ho = DD3itHhVn0yamRfeq6U5l1P[OODLkJlZCoKmrzbg2XQSGPUdInA-TUkQVpXSq4PEfKvYtAxe]
			if EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠧ࡮ࡲࡧࠫࡐ") in nXjaSbKLfEZo10gQxtUPcH2qrGkui[OODLkJlZCoKmrzbg2XQSGPUdInA-TUkQVpXSq4PEfKvYtAxe] and RNZs9pkQtMfO2g1ho[OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠨࡷࡵࡰࠬࡑ")]!=ZZdHEetJc2IDzOXBkh:
				MBUzn8FAOb0aEQLlI2xP = hVYQxy4MfsTqSbiDpH8F23P[OODLkJlZCoKmrzbg2XQSGPUdInA-TUkQVpXSq4PEfKvYtAxe]
				M2MQxnfp4RXPqFKk = VBlawK4mgHSyLEn8iqhUkz5
			else: QQRydi8qX7w1zWcKZfYEouVULA = RNZs9pkQtMfO2g1ho[XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠩࡸࡶࡱ࠭ࡒ")]
			PFHNy3aeMz4qWISd6iVCQcU0Ew7 = nXjaSbKLfEZo10gQxtUPcH2qrGkui[OODLkJlZCoKmrzbg2XQSGPUdInA-TUkQVpXSq4PEfKvYtAxe]
			break
	if not M2MQxnfp4RXPqFKk: eUIlzC0PTZBcaHxhQ5o = QQRydi8qX7w1zWcKZfYEouVULA
	else: eUIlzC0PTZBcaHxhQ5o = OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"࡚ࠪ࡮ࡪࡥࡰ࠼ࠣࠫࡓ")+RNZs9pkQtMfO2g1ho[dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠫࡺࡸ࡬ࠨࡔ")]+dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠬࠦࠫࠡࡃࡸࡨ࡮ࡵ࠺ࠡࠩࡕ")+MBUzn8FAOb0aEQLlI2xP[JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"࠭ࡵࡳ࡮ࠪࡖ")]
	if M2MQxnfp4RXPqFKk:
		FwVTHnZ53B = int(RNZs9pkQtMfO2g1ho[CnbBKmtF1x84q7AW(u"ࠧࡥࡷࡵࡥࡹ࡯࡯࡯ࠩࡗ")])
		YRHc1rxJlUtEPFdKvIDmBq = int(MBUzn8FAOb0aEQLlI2xP[wwPrSDa21lUh(u"ࠨࡦࡸࡶࡦࡺࡩࡰࡰࠪࡘ")])
		oJV18NUZAzPGqMu7tenCxrkfhdl69B = str(max(FwVTHnZ53B,YRHc1rxJlUtEPFdKvIDmBq))
		B6XJLnFiOYtzoKu35vTU4eNsl = RNZs9pkQtMfO2g1ho[e2qDYgipPmTw4KvBLnochr(u"ࠩࡸࡶࡱ࡙࠭")].replace(A6dMB1FlgxVivJ2fk9C(u"࡚ࠪࠪࠬ"),NeO3CTLHrPfWUoIgy8Q(u"ࠫࠫࡧ࡭ࡱ࠽࡛ࠪ"))
		zMoNXvTRrDtK9EUu2gycF = MBUzn8FAOb0aEQLlI2xP[NeO3CTLHrPfWUoIgy8Q(u"ࠬࡻࡲ࡭ࠩ࡜")].replace(rwQN9AKhLCuMfHxjlbX0U(u"࠭ࠦࠨ࡝"),DJ1ICpbyR2(u"ࠧࠧࡣࡰࡴࡀ࠭࡞"))
		mpd = A6dMB1FlgxVivJ2fk9C(u"ࠨ࠾ࡂࡼࡲࡲࠠࡷࡧࡵࡷ࡮ࡵ࡮࠾ࠤ࠴࠲࠵ࠨࠠࡦࡰࡦࡳࡩ࡯࡮ࡨ࠿࡙࡙ࠥࡌ࠭࠹ࠤࡂࡂࡡࡴࠧ࡟")
		mpd += hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠩ࠿ࡑࡕࡊࠠࡹ࡯࡯ࡲࡸࡀࡸࡴ࡫ࡀࠦ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡹ࠶࠲ࡴࡸࡧ࠰࠴࠳࠴࠶࠵ࡘࡎࡎࡖࡧ࡭࡫࡭ࡢ࠯࡬ࡲࡸࡺࡡ࡯ࡥࡨࠦࠥࡾ࡭࡭ࡰࡶࡁࠧࡻࡲ࡯࠼ࡰࡴࡪ࡭࠺ࡥࡣࡶ࡬࠿ࡹࡣࡩࡧࡰࡥ࠿ࡳࡰࡥ࠼࠵࠴࠶࠷ࠢࠡࡺࡰࡰࡳࡹ࠺ࡹ࡮࡬ࡲࡰࡃࠢࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲ࡼ࠹࠮ࡰࡴࡪ࠳࠶࠿࠹࠺࠱ࡻࡰ࡮ࡴ࡫ࠣࠢࡻࡷ࡮ࡀࡳࡤࡪࡨࡱࡦࡒ࡯ࡤࡣࡷ࡭ࡴࡴ࠽ࠣࡷࡵࡲ࠿ࡳࡰࡦࡩ࠽ࡨࡦࡹࡨ࠻ࡵࡦ࡬ࡪࡳࡡ࠻࡯ࡳࡨ࠿࠸࠰࠲࠳ࠣ࡬ࡹࡺࡰ࠻࠱࠲ࡷࡹࡧ࡮ࡥࡣࡵࡨࡸ࠴ࡩࡴࡱ࠱ࡳࡷ࡭࠯ࡪࡶࡷࡪ࠴ࡖࡵࡣ࡮࡬ࡧࡱࡿࡁࡷࡣ࡬ࡰࡦࡨ࡬ࡦࡕࡷࡥࡳࡪࡡࡳࡦࡶ࠳ࡒࡖࡅࡈ࠯ࡇࡅࡘࡎ࡟ࡴࡥ࡫ࡩࡲࡧ࡟ࡧ࡫࡯ࡩࡸ࠵ࡄࡂࡕࡋ࠱ࡒࡖࡄ࠯ࡺࡶࡨࠧࠦ࡭ࡪࡰࡅࡹ࡫࡬ࡥࡳࡖ࡬ࡱࡪࡃࠢࡑࡖ࠴࠲࠺࡙ࠢࠡ࡯ࡨࡨ࡮ࡧࡐࡳࡧࡶࡩࡳࡺࡡࡵ࡫ࡲࡲࡉࡻࡲࡢࡶ࡬ࡳࡳࡃࠢࡑࡖࠪࡠ")+oJV18NUZAzPGqMu7tenCxrkfhdl69B+FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠪࡗࠧࠦࡴࡺࡲࡨࡁࠧࡹࡴࡢࡶ࡬ࡧࠧࠦࡰࡳࡱࡩ࡭ࡱ࡫ࡳ࠾ࠤࡸࡶࡳࡀ࡭ࡱࡧࡪ࠾ࡩࡧࡳࡩ࠼ࡳࡶࡴ࡬ࡩ࡭ࡧ࠽࡭ࡸࡵࡦࡧ࠯ࡰࡥ࡮ࡴ࠺࠳࠲࠴࠵ࠧࡄ࡜࡯ࠩࡡ")
		mpd += CnbBKmtF1x84q7AW(u"ࠫࡁࡖࡥࡳ࡫ࡲࡨࡃࡢ࡮ࠨࡢ")
		mpd += JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠬࡂࡁࡥࡣࡳࡸࡦࡺࡩࡰࡰࡖࡩࡹࠦࡩࡥ࠿ࠥ࠴ࠧࠦ࡭ࡪ࡯ࡨࡘࡾࡶࡥ࠾ࠤࡹ࡭ࡩ࡫࡯࠰ࠩࡣ")+RNZs9pkQtMfO2g1ho[MMizeNH0AKu(u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨࡤ")]+GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠧࠣࠢࡶࡹࡧࡹࡥࡨ࡯ࡨࡲࡹࡇ࡬ࡪࡩࡱࡱࡪࡴࡴ࠾ࠤࡗࡶࡺ࡫ࠢ࠿࡞ࡱࠫࡥ")
		mpd += DJ1ICpbyR2(u"ࠨ࠾ࡕࡳࡱ࡫ࠠࡴࡥ࡫ࡩࡲ࡫ࡉࡥࡗࡵ࡭ࡂࠨࡵࡳࡰ࠽ࡱࡵ࡫ࡧ࠻ࡆࡄࡗࡍࡀࡲࡰ࡮ࡨ࠾࠷࠶࠱࠲ࠤࠣࡺࡦࡲࡵࡦ࠿ࠥࡱࡦ࡯࡮ࠣ࠱ࡁࡠࡳ࠭ࡦ")
		mpd += gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠩ࠿ࡖࡪࡶࡲࡦࡵࡨࡲࡹࡧࡴࡪࡱࡱࠤ࡮ࡪ࠽ࠣࠩࡧ")+RNZs9pkQtMfO2g1ho[jeAby54c02TgG8zuivonX91(u"ࠪ࡭ࡹࡧࡧࠨࡨ")]+SqrG5mU3j96ldsFpExobw40TJY(u"ࠫࠧࠦࡣࡰࡦࡨࡧࡸࡃࠢࠨࡩ")+RNZs9pkQtMfO2g1ho[HHoGx7Flus60(u"ࠬࡩ࡯ࡥࡧࡦࡷࠬࡪ")]+JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"࠭ࠢࠡࡵࡷࡥࡷࡺࡗࡪࡶ࡫ࡗࡆࡖ࠽ࠣ࠳ࠥࠤࡧࡧ࡮ࡥࡹ࡬ࡨࡹ࡮࠽ࠣࠩ࡫")+str(RNZs9pkQtMfO2g1ho[ITvnUAMXsyb4eO(u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ࡬")])+EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠨࠤࠣࡻ࡮ࡪࡴࡩ࠿ࠥࠫ࡭")+str(RNZs9pkQtMfO2g1ho[wwPrSDa21lUh(u"ࠩࡺ࡭ࡩࡺࡨࠨ࡮")])+NeO3CTLHrPfWUoIgy8Q(u"ࠪࠦࠥ࡮ࡥࡪࡩ࡫ࡸࡂࠨࠧ࡯")+str(RNZs9pkQtMfO2g1ho[mkHKSQvjWr5BTcM3wVY(u"ࠫ࡭࡫ࡩࡨࡪࡷࠫࡰ")])+LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠬࠨࠠࡧࡴࡤࡱࡪࡘࡡࡵࡧࡀࠦࠬࡱ")+RNZs9pkQtMfO2g1ho[DJ1ICpbyR2(u"࠭ࡦࡱࡵࠪࡲ")]+QvgnCALNstmuUJiET(u"ࠧࠣࡀ࡟ࡲࠬࡳ")
		mpd += QvgnCALNstmuUJiET(u"ࠨ࠾ࡅࡥࡸ࡫ࡕࡓࡎࡁࠫࡴ")+B6XJLnFiOYtzoKu35vTU4eNsl+GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠩ࠿࠳ࡇࡧࡳࡦࡗࡕࡐࡃࡢ࡮ࠨࡵ")
		mpd += SqrG5mU3j96ldsFpExobw40TJY(u"ࠪࡀࡘ࡫ࡧ࡮ࡧࡱࡸࡇࡧࡳࡦࠢ࡬ࡲࡩ࡫ࡸࡓࡣࡱ࡫ࡪࡃࠢࠨࡶ")+RNZs9pkQtMfO2g1ho[e2qDYgipPmTw4KvBLnochr(u"ࠫ࡮ࡴࡤࡦࡺࠪࡷ")]+LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠬࠨ࠾࡝ࡰࠪࡸ")
		mpd += LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"࠭࠼ࡊࡰ࡬ࡸ࡮ࡧ࡬ࡪࡼࡤࡸ࡮ࡵ࡮ࠡࡴࡤࡲ࡬࡫࠽ࠣࠩࡹ")+RNZs9pkQtMfO2g1ho[LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠧࡪࡰ࡬ࡸࠬࡺ")]+QvgnCALNstmuUJiET(u"ࠨࠤࠣ࠳ࡃࡢ࡮ࠨࡻ")
		mpd += dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠩ࠿࠳ࡘ࡫ࡧ࡮ࡧࡱࡸࡇࡧࡳࡦࡀ࡟ࡲࠬࡼ")
		mpd += mkHKSQvjWr5BTcM3wVY(u"ࠪࡀ࠴ࡘࡥࡱࡴࡨࡷࡪࡴࡴࡢࡶ࡬ࡳࡳࡄ࡜࡯ࠩࡽ")
		mpd += SqrG5mU3j96ldsFpExobw40TJY(u"ࠫࡁ࠵ࡁࡥࡣࡳࡸࡦࡺࡩࡰࡰࡖࡩࡹࡄ࡜࡯ࠩࡾ")
		mpd += e2qDYgipPmTw4KvBLnochr(u"ࠬࡂࡁࡥࡣࡳࡸࡦࡺࡩࡰࡰࡖࡩࡹࠦࡩࡥ࠿ࠥ࠵ࠧࠦ࡭ࡪ࡯ࡨࡘࡾࡶࡥ࠾ࠤࡤࡹࡩ࡯࡯࠰ࠩࡿ")+MBUzn8FAOb0aEQLlI2xP[o1u5dij9UrcbXzVS8lwIWfKpnqM(u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨࢀ")]+NeO3CTLHrPfWUoIgy8Q(u"ࠧࠣࠢࡶࡹࡧࡹࡥࡨ࡯ࡨࡲࡹࡇ࡬ࡪࡩࡱࡱࡪࡴࡴ࠾ࠤࡗࡶࡺ࡫ࠢ࠿࡞ࡱࠫࢁ")
		mpd += mkHKSQvjWr5BTcM3wVY(u"ࠨ࠾ࡕࡳࡱ࡫ࠠࡴࡥ࡫ࡩࡲ࡫ࡉࡥࡗࡵ࡭ࡂࠨࡵࡳࡰ࠽ࡱࡵ࡫ࡧ࠻ࡆࡄࡗࡍࡀࡲࡰ࡮ࡨ࠾࠷࠶࠱࠲ࠤࠣࡺࡦࡲࡵࡦ࠿ࠥࡱࡦ࡯࡮ࠣ࠱ࡁࡠࡳ࠭ࢂ")
		mpd += S1SgCFYGJeMvfp5iZXK(u"ࠩ࠿ࡖࡪࡶࡲࡦࡵࡨࡲࡹࡧࡴࡪࡱࡱࠤ࡮ࡪ࠽ࠣࠩࢃ")+MBUzn8FAOb0aEQLlI2xP[QVDJLRlxNg127jMX(u"ࠪ࡭ࡹࡧࡧࠨࢄ")]+A6dMB1FlgxVivJ2fk9C(u"ࠫࠧࠦࡣࡰࡦࡨࡧࡸࡃࠢࠨࢅ")+MBUzn8FAOb0aEQLlI2xP[QVDJLRlxNg127jMX(u"ࠬࡩ࡯ࡥࡧࡦࡷࠬࢆ")]+MMizeNH0AKu(u"࠭ࠢࠡࡤࡤࡲࡩࡽࡩࡥࡶ࡫ࡁࠧ࠷࠳࠱࠶࠺࠹ࠧࡄ࡜࡯ࠩࢇ")
		mpd += sULh4NjakzI8He7xJCMGrql(u"ࠧ࠽ࡃࡸࡨ࡮ࡵࡃࡩࡣࡱࡲࡪࡲࡃࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡳࡤࡪࡨࡱࡪࡏࡤࡖࡴ࡬ࡁࠧࡻࡲ࡯࠼ࡰࡴࡪ࡭࠺ࡥࡣࡶ࡬࠿࠸࠳࠱࠲࠶࠾࠸ࡀࡡࡶࡦ࡬ࡳࡤࡩࡨࡢࡰࡱࡩࡱࡥࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࡀ࠲࠱࠳࠴ࠦࠥࡼࡡ࡭ࡷࡨࡁࠧ࠭࢈")+MBUzn8FAOb0aEQLlI2xP[dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠨࡣࡸࡨ࡮ࡵ࡟ࡤࡪࡤࡲࡳ࡫࡬ࡴࠩࢉ")]+KBkxSYaz93pu1(u"ࠩࠥ࠳ࡃࡢ࡮ࠨࢊ")
		mpd += XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠪࡀࡇࡧࡳࡦࡗࡕࡐࡃ࠭ࢋ")+zMoNXvTRrDtK9EUu2gycF+ITvnUAMXsyb4eO(u"ࠫࡁ࠵ࡂࡢࡵࡨ࡙ࡗࡒ࠾࡝ࡰࠪࢌ")
		mpd += LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠬࡂࡓࡦࡩࡰࡩࡳࡺࡂࡢࡵࡨࠤ࡮ࡴࡤࡦࡺࡕࡥࡳ࡭ࡥ࠾ࠤࠪࢍ")+MBUzn8FAOb0aEQLlI2xP[OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"࠭ࡩ࡯ࡦࡨࡼࠬࢎ")]+e2qDYgipPmTw4KvBLnochr(u"ࠧࠣࡀ࡟ࡲࠬ࢏")
		mpd += rwQN9AKhLCuMfHxjlbX0U(u"ࠨ࠾ࡌࡲ࡮ࡺࡩࡢ࡮࡬ࡾࡦࡺࡩࡰࡰࠣࡶࡦࡴࡧࡦ࠿ࠥࠫ࢐")+MBUzn8FAOb0aEQLlI2xP[LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠩ࡬ࡲ࡮ࡺࠧ࢑")]+KNIvHPjUbhr(u"ࠪࠦࠥ࠵࠾࡝ࡰࠪ࢒")
		mpd += o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠫࡁ࠵ࡓࡦࡩࡰࡩࡳࡺࡂࡢࡵࡨࡂࡡࡴࠧ࢓")
		mpd += o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠬࡂ࠯ࡓࡧࡳࡶࡪࡹࡥ࡯ࡶࡤࡸ࡮ࡵ࡮࠿࡞ࡱࠫ࢔")
		mpd += LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"࠭࠼࠰ࡃࡧࡥࡵࡺࡡࡵ࡫ࡲࡲࡘ࡫ࡴ࠿࡞ࡱࠫ࢕")
		mpd += mkHKSQvjWr5BTcM3wVY(u"ࠧ࠽࠱ࡓࡩࡷ࡯࡯ࡥࡀ࡟ࡲࠬ࢖")
		mpd += EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠨ࠾࠲ࡑࡕࡊ࠾࡝ࡰࠪࢗ")
		if H4qZ2hwilNJYTmCFEQyaSs98cPM0gR:
			import http.server as FvTS5UwnG80u7LgJh9r
			import http.client as RCpQGnzBIFdtDUq18V
		else:
			import BaseHTTPServer as FvTS5UwnG80u7LgJh9r
			import httplib as RCpQGnzBIFdtDUq18V
		class Ry93oI7LnjAJ1FeOGtl(FvTS5UwnG80u7LgJh9r.HTTPServer):
			def __init__(z3d8DqtAsgLQaCom7X2Ilv1MrU,ip=ITvnUAMXsyb4eO(u"ࠩ࡯ࡳࡨࡧ࡬ࡩࡱࡶࡸࠬ࢘"),port=hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"࠶࠷࠳࠹࠺য"),mpd=HHoGx7Flus60(u"ࠪࡀࡃ࢙࠭")):
				z3d8DqtAsgLQaCom7X2Ilv1MrU.ip = ip
				z3d8DqtAsgLQaCom7X2Ilv1MrU.port = port
				z3d8DqtAsgLQaCom7X2Ilv1MrU.mpd = mpd
				FvTS5UwnG80u7LgJh9r.HTTPServer.__init__(z3d8DqtAsgLQaCom7X2Ilv1MrU,(z3d8DqtAsgLQaCom7X2Ilv1MrU.ip,z3d8DqtAsgLQaCom7X2Ilv1MrU.port),RACs6ZOj3NHIm5vW2GYfkpXaP1Kdb4)
				z3d8DqtAsgLQaCom7X2Ilv1MrU.mpdurl = NeO3CTLHrPfWUoIgy8Q(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࢚ࠬ")+ip+o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠬࡀ࢛ࠧ")+str(port)+dv0trJR7PwmKyxDYO52VLau8gEph(u"࠭࠯ࡺࡱࡸࡸࡺࡨࡥ࠯࡯ࡳࡨࠬ࢜")
			def start(z3d8DqtAsgLQaCom7X2Ilv1MrU):
				z3d8DqtAsgLQaCom7X2Ilv1MrU.threads = wfH5yxroNbj82s9iPp7QvuTn(fEXMiAyG3ql4vKB)
				z3d8DqtAsgLQaCom7X2Ilv1MrU.threads.GJfmn1Wyce6wo2(bXukYxQ4aHw,z3d8DqtAsgLQaCom7X2Ilv1MrU.DTNE6coqlP)
			def DTNE6coqlP(z3d8DqtAsgLQaCom7X2Ilv1MrU):
				z3d8DqtAsgLQaCom7X2Ilv1MrU.keeprunning = VBlawK4mgHSyLEn8iqhUkz5
				while z3d8DqtAsgLQaCom7X2Ilv1MrU.keeprunning:
					z3d8DqtAsgLQaCom7X2Ilv1MrU.handle_request()
			def stop(z3d8DqtAsgLQaCom7X2Ilv1MrU):
				z3d8DqtAsgLQaCom7X2Ilv1MrU.keeprunning = fEXMiAyG3ql4vKB
				z3d8DqtAsgLQaCom7X2Ilv1MrU.R7LghVds31OPn9uZ0MN6qWjFaAt2X()
			def QpSdC0WVnhmsrTNRXgfeMPGvFOK5(z3d8DqtAsgLQaCom7X2Ilv1MrU):
				z3d8DqtAsgLQaCom7X2Ilv1MrU.stop()
				z3d8DqtAsgLQaCom7X2Ilv1MrU.jFL1meU3RWM78GPlJBNbQHdShuT.close()
				z3d8DqtAsgLQaCom7X2Ilv1MrU.server_close()
			def bZYwf8vHietIUG2nL9Xr5h(z3d8DqtAsgLQaCom7X2Ilv1MrU,mpd):
				z3d8DqtAsgLQaCom7X2Ilv1MrU.mpd = mpd
			def R7LghVds31OPn9uZ0MN6qWjFaAt2X(z3d8DqtAsgLQaCom7X2Ilv1MrU):
				WFYAlCyzGj1H32ovtQLnBTqhS6X = RCpQGnzBIFdtDUq18V.HTTPConnection(z3d8DqtAsgLQaCom7X2Ilv1MrU.ip+e2qDYgipPmTw4KvBLnochr(u"ࠧ࠻ࠩ࢝")+str(z3d8DqtAsgLQaCom7X2Ilv1MrU.port))
				WFYAlCyzGj1H32ovtQLnBTqhS6X.request(dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠣࡊࡈࡅࡉࠨ࢞"), GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠤ࠲ࠦ࢟"))
		class RACs6ZOj3NHIm5vW2GYfkpXaP1Kdb4(FvTS5UwnG80u7LgJh9r.BaseHTTPRequestHandler):
			def RpCHqbMxVA875IYBv(z3d8DqtAsgLQaCom7X2Ilv1MrU):
				z3d8DqtAsgLQaCom7X2Ilv1MrU.send_response(dv0trJR7PwmKyxDYO52VLau8gEph(u"࠴࠳࠴র"))
				z3d8DqtAsgLQaCom7X2Ilv1MrU.send_header(JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱ࡹࡿࡰࡦࠩࢠ"),NeO3CTLHrPfWUoIgy8Q(u"ࠫࡹ࡫ࡸࡵࡶ࠲ࡴࡱࡧࡩ࡯ࠩࢡ"))
				z3d8DqtAsgLQaCom7X2Ilv1MrU.end_headers()
				z3d8DqtAsgLQaCom7X2Ilv1MrU.wfile.write(z3d8DqtAsgLQaCom7X2Ilv1MrU.SODQ7qlNYoZcFK8e50rBsJaAHxiXjE.mpd.encode(a7VXeDU82IfQEnPZAdiT))
				HB5PvxRhwM.sleep(bXukYxQ4aHw)
				if z3d8DqtAsgLQaCom7X2Ilv1MrU.path==sULh4NjakzI8He7xJCMGrql(u"ࠬ࠵ࡹࡰࡷࡷࡹࡧ࡫࠮࡮ࡲࡧࠫࢢ"): z3d8DqtAsgLQaCom7X2Ilv1MrU.SODQ7qlNYoZcFK8e50rBsJaAHxiXjE.QpSdC0WVnhmsrTNRXgfeMPGvFOK5()
				if z3d8DqtAsgLQaCom7X2Ilv1MrU.path==o1u5dij9UrcbXzVS8lwIWfKpnqM(u"࠭࠯ࡴࡪࡸࡸࡩࡵࡷ࡯ࠩࢣ"): z3d8DqtAsgLQaCom7X2Ilv1MrU.SODQ7qlNYoZcFK8e50rBsJaAHxiXjE.QpSdC0WVnhmsrTNRXgfeMPGvFOK5()
			def tlaBp3whGbVmk(z3d8DqtAsgLQaCom7X2Ilv1MrU):
				z3d8DqtAsgLQaCom7X2Ilv1MrU.send_response(DJ1ICpbyR2(u"࠵࠴࠵঱"))
				z3d8DqtAsgLQaCom7X2Ilv1MrU.end_headers()
		KQAv3gxDy84fYNieVSTMoFjaX = Ry93oI7LnjAJ1FeOGtl(S1SgCFYGJeMvfp5iZXK(u"ࠧ࠲࠴࠺࠲࠵࠴࠰࠯࠳ࠪࢤ"),e2qDYgipPmTw4KvBLnochr(u"࠹࠺࠶࠵࠶ল"),mpd)
		QQRydi8qX7w1zWcKZfYEouVULA = KQAv3gxDy84fYNieVSTMoFjaX.mpdurl
		KQAv3gxDy84fYNieVSTMoFjaX.start()
	else: KQAv3gxDy84fYNieVSTMoFjaX = hWGMqtBy4wuLaVcj
	if not QQRydi8qX7w1zWcKZfYEouVULA: return jeAby54c02TgG8zuivonX91(u"ࠨࡇࡵࡶࡴࡸࠠࠡࠢࠣ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸ࡚ࠠࡑࡘࡘ࡚ࡈࡅࠡࡈࡤ࡭ࡱ࡫ࡤࠨࢥ"),[],[]
	return hWGMqtBy4wuLaVcj,[hWGMqtBy4wuLaVcj],[[QQRydi8qX7w1zWcKZfYEouVULA,bm13PoqKMnfDt7CGc2lVUy9p0eza,KQAv3gxDy84fYNieVSTMoFjaX]]
def jiwuAOsBSaWd7IRcz5UFo48Tgy3Gm1(url):
	headers = { MMizeNH0AKu(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ࢦ") : hWGMqtBy4wuLaVcj }
	mMQ3FkNVa4IlxqY = f1fLNcPlo2ECKtiBeug0OAvz9YM(nHBb7jXk0Daom,url,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,MMizeNH0AKu(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡖࡊࡆࡅࡓࡇ࠳࠱ࡴࡶࠪࢧ"))
	items = trdVA0JvFaD.findall(LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠫ࡫࡯࡬ࡦ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠫ࠰ࡱࡧࡢࡦ࡮࠽ࠦ࠭࠴ࠪࡀࠫࠥࢀ࠮ࡢࡽࠨࢨ"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	items = set(items)
	items = sorted(items, reverse=VBlawK4mgHSyLEn8iqhUkz5, key=lambda key: key[Y0XZKGRAUQj5O])
	o94WsYVfy3Nqrmg07,haq1bHZINPE58uoBFnKfTSO2ik4,rFMaDkS4jJ8uwLPV,Dvi8asSrQYX5wE3KMIxT91me = [],[],[],[]
	if not items: return LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡗࡋࡇࡆࡔࡈࠧࢩ"),[],[]
	for llxFwq0CUNgQtivJzkHeGV,QwGpLVOkc0MPodWfiYsTj,h4s5qao1CX in items:
		llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV.replace(KBkxSYaz93pu1(u"࠭ࡨࡵࡶࡳࡷ࠿࠭ࢪ"),xcChIL13BpR8WArNt9Pl0So(u"ࠧࡩࡶࡷࡴ࠿࠭ࢫ"))
		if GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧࢬ") in llxFwq0CUNgQtivJzkHeGV:
			o94WsYVfy3Nqrmg07,rFMaDkS4jJ8uwLPV = b8IJFKNyPjgE4GelaCSXB6Qht(llxFwq0CUNgQtivJzkHeGV)
			Dvi8asSrQYX5wE3KMIxT91me = Dvi8asSrQYX5wE3KMIxT91me + rFMaDkS4jJ8uwLPV
			if o94WsYVfy3Nqrmg07[ybdv7XcT3lxF6QezULwCAGk]==ITvnUAMXsyb4eO(u"ࠩ࠰࠵ࠬࢭ"): haq1bHZINPE58uoBFnKfTSO2ik4.append(ITvnUAMXsyb4eO(u"ࠪื๏ืแาࠢัหฺ࠭ࢮ")+OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠫࠥࠦࠠ࡮࠵ࡸ࠼ࠬࢯ"))
			else:
				for title in o94WsYVfy3Nqrmg07:
					haq1bHZINPE58uoBFnKfTSO2ik4.append(CnbBKmtF1x84q7AW(u"ู๊ࠬาใิࠤำอีࠨࢰ")+lG0yV5QNFHc2RbXM1Wp+title)
		else:
			title = QvgnCALNstmuUJiET(u"࠭ำ๋ำไีࠥิวึࠩࢱ")+JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠧࠡࠢࠣࡱࡵ࠺ࠠࠡࠢࠪࢲ")+h4s5qao1CX
			Dvi8asSrQYX5wE3KMIxT91me.append(llxFwq0CUNgQtivJzkHeGV)
			haq1bHZINPE58uoBFnKfTSO2ik4.append(title)
	return hWGMqtBy4wuLaVcj,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me
def UfyPgEMvCS1c5zewKB(url,mMQ3FkNVa4IlxqY):
	HHAWYIZauqLrJBitcneTljf7,zmDKurMJwj6fi,shLaYeCXQV1gFkHn,UEYlTGJarmz,m4IznKilUOByHweG68VJ = [],[],[],[],[]
	if GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠨࡵࡷࡶࠬࢳ") not in str(type(mMQ3FkNVa4IlxqY)): mMQ3FkNVa4IlxqY = mMQ3FkNVa4IlxqY.decode(a7VXeDU82IfQEnPZAdiT,mkHKSQvjWr5BTcM3wVY(u"ࠩ࡬࡫ࡳࡵࡲࡦࠩࢴ"))
	llxFwq0CUNgQtivJzkHeGV = trdVA0JvFaD.findall(QVDJLRlxNg127jMX(u"ࠪࡀࡻ࡯ࡤࡦࡱࠣࡴࡷ࡫࡬ࡰࡣࡧ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫࢵ"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if llxFwq0CUNgQtivJzkHeGV and not UGBbEtrcu5jLC6Sxoa3gFyP1mJOpW(llxFwq0CUNgQtivJzkHeGV[ybdv7XcT3lxF6QezULwCAGk]): llxFwq0CUNgQtivJzkHeGV = []
	if not llxFwq0CUNgQtivJzkHeGV: llxFwq0CUNgQtivJzkHeGV = trdVA0JvFaD.findall(dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠫࡁࡹ࡯ࡶࡴࡦࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪࢶ"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if llxFwq0CUNgQtivJzkHeGV and not UGBbEtrcu5jLC6Sxoa3gFyP1mJOpW(llxFwq0CUNgQtivJzkHeGV[ybdv7XcT3lxF6QezULwCAGk]): llxFwq0CUNgQtivJzkHeGV = []
	if not llxFwq0CUNgQtivJzkHeGV: llxFwq0CUNgQtivJzkHeGV = trdVA0JvFaD.findall(wwPrSDa21lUh(u"ࠬࡪࡩࡳࡧࡦࡸࡤࡲࡩ࡯࡭࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫࢷ"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if llxFwq0CUNgQtivJzkHeGV and not UGBbEtrcu5jLC6Sxoa3gFyP1mJOpW(llxFwq0CUNgQtivJzkHeGV[ybdv7XcT3lxF6QezULwCAGk]): llxFwq0CUNgQtivJzkHeGV = []
	if llxFwq0CUNgQtivJzkHeGV:
		llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV[ybdv7XcT3lxF6QezULwCAGk]
		title = llxFwq0CUNgQtivJzkHeGV.rsplit(gDuGMR3z1aV6YdLmCpiO8Kl(u"࠭࠮ࠨࢸ"),xcChIL13BpR8WArNt9Pl0So(u"࠶঳"))[bXukYxQ4aHw]
		HHAWYIZauqLrJBitcneTljf7.append(title)
		zmDKurMJwj6fi.append(llxFwq0CUNgQtivJzkHeGV)
	else:
		rqIW37cd0iT1msDzRevOM = trdVA0JvFaD.findall(LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠧࡴࡱࡸࡶࡨ࡫ࡳ࠻ࠢ࠭ࠬࡡࡡ࠮ࠫࡁ࡟ࡡ࠮࠭ࢹ"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if not rqIW37cd0iT1msDzRevOM: rqIW37cd0iT1msDzRevOM = trdVA0JvFaD.findall(EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠨࡸࡤࡶࠥࡹ࡯ࡶࡴࡦࡩࡸࠦ࠽ࠡࠪ࡟ࡿ࠳࠰࠿࡝ࡿࠬࠫࢺ"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if not rqIW37cd0iT1msDzRevOM: rqIW37cd0iT1msDzRevOM = trdVA0JvFaD.findall(S1SgCFYGJeMvfp5iZXK(u"ࠩࡹࡥࡷࠦࡪࡸࠢࡀࠤ࠭ࡢࡻ࠯ࠬࡂࡠࢂ࠯ࠧࢻ"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if not rqIW37cd0iT1msDzRevOM: rqIW37cd0iT1msDzRevOM = trdVA0JvFaD.findall(OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠪࡺࡦࡸࠠࡱ࡮ࡤࡽࡪࡸࠠ࠾ࠢ࠱࠮ࡄࡢࠨࠩ࡞ࡾ࠲࠯ࡅ࡜ࡾࠫ࡟࠭ࠬࢼ"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if rqIW37cd0iT1msDzRevOM:
			rqIW37cd0iT1msDzRevOM = rqIW37cd0iT1msDzRevOM[ybdv7XcT3lxF6QezULwCAGk]
			rqIW37cd0iT1msDzRevOM = trdVA0JvFaD.sub(LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࡶࠬ࠮࡛࡝ࡽ࡟࠰ࡢࡡ࡜ࡵ࡞ࡶࡠࡳࡢࡲ࡞ࠬࠬࠬࡡࡽࠫ࡜࡞ࡷࡠࡸࡣࠪࠪ࠼ࠪࢽ"),dv0trJR7PwmKyxDYO52VLau8gEph(u"ࡷ࠭࡜࠲ࠤ࡟࠶ࠧࡀࠧࢾ"),rqIW37cd0iT1msDzRevOM)
			rqIW37cd0iT1msDzRevOM = Cy9ow3c21nABMjzqeaIT(KNIvHPjUbhr(u"࠭ࡤࡪࡥࡷࠫࢿ"),rqIW37cd0iT1msDzRevOM)
			if isinstance(rqIW37cd0iT1msDzRevOM,dict): rqIW37cd0iT1msDzRevOM = [rqIW37cd0iT1msDzRevOM]
			for cok5ZGXdQP7YhwtqyuaCnVevm6UB in rqIW37cd0iT1msDzRevOM:
				W6iRwVAP49kgdStfK,llxFwq0CUNgQtivJzkHeGV = hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj
				if isinstance(cok5ZGXdQP7YhwtqyuaCnVevm6UB,dict):
					keys = list(cok5ZGXdQP7YhwtqyuaCnVevm6UB.keys())
					if   CnbBKmtF1x84q7AW(u"ࠧࡵࡻࡳࡩࠬࣀ") in keys: W6iRwVAP49kgdStfK = str(cok5ZGXdQP7YhwtqyuaCnVevm6UB[zyvJMtBhrw(u"ࠨࡶࡼࡴࡪ࠭ࣁ")])
					if   dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠩࡩ࡭ࡱ࡫ࠧࣂ") in keys: llxFwq0CUNgQtivJzkHeGV = cok5ZGXdQP7YhwtqyuaCnVevm6UB[hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠪࡪ࡮ࡲࡥࠨࣃ")]
					elif wwPrSDa21lUh(u"ࠫ࡭ࡲࡳࠨࣄ") in keys: llxFwq0CUNgQtivJzkHeGV = cok5ZGXdQP7YhwtqyuaCnVevm6UB[S1SgCFYGJeMvfp5iZXK(u"ࠬ࡮࡬ࡴࠩࣅ")]
					elif GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"࠭ࡳࡳࡥࠪࣆ") in keys: llxFwq0CUNgQtivJzkHeGV = cok5ZGXdQP7YhwtqyuaCnVevm6UB[gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠧࡴࡴࡦࠫࣇ")]
					if   QVDJLRlxNg127jMX(u"ࠨ࡮ࡤࡦࡪࡲࠧࣈ") in keys: title = str(cok5ZGXdQP7YhwtqyuaCnVevm6UB[rwQN9AKhLCuMfHxjlbX0U(u"ࠩ࡯ࡥࡧ࡫࡬ࠨࣉ")])
					elif JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠪࡺ࡮ࡪࡥࡰࡡ࡫ࡩ࡮࡭ࡨࡵࠩ࣊") in keys: title = str(cok5ZGXdQP7YhwtqyuaCnVevm6UB[QVDJLRlxNg127jMX(u"ࠫࡻ࡯ࡤࡦࡱࡢ࡬ࡪ࡯ࡧࡩࡶࠪ࣋")])
					elif QvgnCALNstmuUJiET(u"ࠬ࠴ࠧ࣌") in llxFwq0CUNgQtivJzkHeGV: title = llxFwq0CUNgQtivJzkHeGV.rsplit(gDuGMR3z1aV6YdLmCpiO8Kl(u"࠭࠮ࠨ࣍"),jeAby54c02TgG8zuivonX91(u"࠷঴"))[bXukYxQ4aHw]
					else: title = llxFwq0CUNgQtivJzkHeGV
				elif isinstance(cok5ZGXdQP7YhwtqyuaCnVevm6UB,str):
					llxFwq0CUNgQtivJzkHeGV = cok5ZGXdQP7YhwtqyuaCnVevm6UB
					title = llxFwq0CUNgQtivJzkHeGV.rsplit(SqrG5mU3j96ldsFpExobw40TJY(u"ࠧ࠯ࠩ࣎"),mkHKSQvjWr5BTcM3wVY(u"࠱঵"))[bXukYxQ4aHw]
				if bXukYxQ4aHw:
					HHAWYIZauqLrJBitcneTljf7.append(title+FqcVAkh7WjIXHdDKf8nvuyRo+W6iRwVAP49kgdStfK)
					zmDKurMJwj6fi.append(llxFwq0CUNgQtivJzkHeGV)
	for llxFwq0CUNgQtivJzkHeGV,title in zip(zmDKurMJwj6fi,HHAWYIZauqLrJBitcneTljf7):
		llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV.replace(FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠨ࡞࡟࠳࣏ࠬ"),jeAby54c02TgG8zuivonX91(u"ࠩ࠲࣐ࠫ"))
		SODQ7qlNYoZcFK8e50rBsJaAHxiXjE = RRNODILCtGzvgpx(url,jeAby54c02TgG8zuivonX91(u"ࠪࡹࡷࡲ࣑ࠧ"))
		o0ST4d1BWzi7r3OnK9ucCXxw = OB6QYAMUnPiWXgpkTrItV48FqZSjdR()
		if wwPrSDa21lUh(u"ࠫ࡭ࡺࡴࡱ࣒ࠩ") not in llxFwq0CUNgQtivJzkHeGV: llxFwq0CUNgQtivJzkHeGV = SODQ7qlNYoZcFK8e50rBsJaAHxiXjE+llxFwq0CUNgQtivJzkHeGV
		if DJ1ICpbyR2(u"ࠬ࠴࡭࠴ࡷ࠻࣓ࠫ") in llxFwq0CUNgQtivJzkHeGV:
			headers = {xcChIL13BpR8WArNt9Pl0So(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪࣔ"):o0ST4d1BWzi7r3OnK9ucCXxw,A6dMB1FlgxVivJ2fk9C(u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨࣕ"):SODQ7qlNYoZcFK8e50rBsJaAHxiXjE}
			YoWDKN41B5fMsJXeUpSCQqty,cl6eNopBvr13uwdRan5CALkZbtMs2X = b8IJFKNyPjgE4GelaCSXB6Qht(llxFwq0CUNgQtivJzkHeGV,headers)
			UEYlTGJarmz += cl6eNopBvr13uwdRan5CALkZbtMs2X
			shLaYeCXQV1gFkHn += YoWDKN41B5fMsJXeUpSCQqty
		else:
			llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV+MMizeNH0AKu(u"ࠨࡾࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࡃࠧࣖ")+o0ST4d1BWzi7r3OnK9ucCXxw+EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠩࠩࡖࡪ࡬ࡥࡳࡧࡵࡁࠬࣗ")+SODQ7qlNYoZcFK8e50rBsJaAHxiXjE
			UEYlTGJarmz.append(llxFwq0CUNgQtivJzkHeGV)
			shLaYeCXQV1gFkHn.append(title)
	pxdY8tiazyJIq,HHAWYIZauqLrJBitcneTljf7,zmDKurMJwj6fi = hWGMqtBy4wuLaVcj,[],[]
	if UEYlTGJarmz: pxdY8tiazyJIq,HHAWYIZauqLrJBitcneTljf7,zmDKurMJwj6fi = hWGMqtBy4wuLaVcj,shLaYeCXQV1gFkHn,UEYlTGJarmz
	else:
		if e2qDYgipPmTw4KvBLnochr(u"ࠪࡀࠬࣘ") not in mMQ3FkNVa4IlxqY and len(mMQ3FkNVa4IlxqY)<A6dMB1FlgxVivJ2fk9C(u"࠲࠲࠳শ") and mMQ3FkNVa4IlxqY: pxdY8tiazyJIq = mMQ3FkNVa4IlxqY
		else:
			msg = trdVA0JvFaD.findall(sULh4NjakzI8He7xJCMGrql(u"ࠫࡁࡪࡩࡷࠢࡶࡸࡾࡲࡥ࠾ࠤ࠱࠮ࡄࠨ࠾ࠩࡈ࡬ࡰࡪ࠴ࠪࡀࠫ࠿ࠫࣙ"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
			if not msg: msg = trdVA0JvFaD.findall(MMizeNH0AKu(u"ࠬࡂࡤࡪࡸࠣࡧࡱࡧࡳࡴ࠿ࠥࡺࡵࡥࡶࡪࡦࡨࡳࡤࡹࡴࡶࡤࡢࡸࡽࡺࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨࣚ"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
			if not msg: msg = trdVA0JvFaD.findall(LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"࠭࠼ࡩ࠴ࡁࠬࡘࡵࡲࡳࡻ࠱࠮ࡄ࠯࠼ࠨࣛ"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
			if msg: pxdY8tiazyJIq = msg[ybdv7XcT3lxF6QezULwCAGk]
	return pxdY8tiazyJIq,HHAWYIZauqLrJBitcneTljf7,zmDKurMJwj6fi
def QbZ84quzk9tv6BVALU(QE5KgeLm43aSx6,url):
	global WJ3dBsg956vaLAXm
	url = url.strip(KNIvHPjUbhr(u"ࠧ࠰ࠩࣜ"))
	IjWbFB4GQpMYNUmur6K9Rn,l17Sn3hK59WV = hWGMqtBy4wuLaVcj,{}
	headers = {KNIvHPjUbhr(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬࣝ"):OB6QYAMUnPiWXgpkTrItV48FqZSjdR()}
	headers[e2qDYgipPmTw4KvBLnochr(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪࣞ")] = RRNODILCtGzvgpx(url,QVDJLRlxNg127jMX(u"ࠪࡹࡷࡲࠧࣟ"))
	headers[JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠫࡆࡩࡣࡦࡲࡷ࠱ࡑࡧ࡮ࡨࡷࡤ࡫ࡪ࠭࣠")] = OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠬ࡫࡮࠮ࡗࡖ࠰ࡪࡴ࠻ࡲ࠿࠳࠲࠾࠭࣡")
	headers[rwQN9AKhLCuMfHxjlbX0U(u"࠭ࡓࡦࡥ࠰ࡊࡪࡺࡣࡩ࠯ࡇࡩࡸࡺࠧ࣢")] = SqrG5mU3j96ldsFpExobw40TJY(u"ࠧࡪࡨࡵࡥࡲ࡫ࣣࠧ")
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(nHBb7jXk0Daom,rwQN9AKhLCuMfHxjlbX0U(u"ࠨࡉࡈࡘࠬࣤ"),url,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,fEXMiAyG3ql4vKB,dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡞ࡓࡉࡃࡕࡍࡓࡍ࠭࠲ࡵࡷࠫࣥ"))
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	fc1FTYRB2AtjklMod7mOWCxEV = sDQvwGASB0Vf67mik.code
	if not isinstance(mMQ3FkNVa4IlxqY,str): mMQ3FkNVa4IlxqY = mMQ3FkNVa4IlxqY.decode(a7VXeDU82IfQEnPZAdiT,LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠪ࡭࡬ࡴ࡯ࡳࡧࣦࠪ"))
	if hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠫ࡫ࡻ࡮ࡤࡶ࡬ࡳࡳ࠮ࡰ࠭ࡣ࠯ࡧ࠱ࡱࠬࡦ࠮ࠪࣧ") in mMQ3FkNVa4IlxqY:
		XXcjg4MYoSre = trdVA0JvFaD.findall(QVDJLRlxNg127jMX(u"ࠬ࠮ࡥࡷࡣ࡯ࡠ࠭࡬ࡵ࡯ࡥࡷ࡭ࡴࡴ࡜ࠩࡲ࠯ࡥ࠱ࡩࠬ࡬࠮ࡨ࠰ࡠࡪࡲ࡞࠰࠭ࡃ࠮ࡂ࠯ࡴࡥࡵ࡭ࡵࡺ࠾ࠨࣨ"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if XXcjg4MYoSre:
			try: IjWbFB4GQpMYNUmur6K9Rn = hGBzk2RAImCy0LKPMVjaN38lxUg6w(XXcjg4MYoSre[ybdv7XcT3lxF6QezULwCAGk])
			except: IjWbFB4GQpMYNUmur6K9Rn = hWGMqtBy4wuLaVcj
	if LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"࠭ࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠩࡪ࠯ࡹ࠱ࡴࠬࡵ࠮ࡨ࠰ࡷ࠯ࣩࠧ") in mMQ3FkNVa4IlxqY:
		XXcjg4MYoSre = trdVA0JvFaD.findall(wwPrSDa21lUh(u"ࠧࠩࡧࡹࡥࡱࡢࠨࡧࡷࡱࡧࡹ࡯࡯࡯࡞ࠫ࡬࠱ࡻࠬ࡯࠮ࡷ࠰ࡪ࠲ࡲ࠯ࠬࡂ࠭ࡁ࠵ࡳࡤࡴ࡬ࡴࡹࡄࠧ࣪"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if XXcjg4MYoSre:
			try: IjWbFB4GQpMYNUmur6K9Rn = zUJTl3EtmvNedxkZ42B(XXcjg4MYoSre[ybdv7XcT3lxF6QezULwCAGk])
			except: IjWbFB4GQpMYNUmur6K9Rn = hWGMqtBy4wuLaVcj
	eecmFXt5SRyCjGpx = mMQ3FkNVa4IlxqY+IjWbFB4GQpMYNUmur6K9Rn
	if hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠨࠤ࡬ࡨ࠷ࠨࠧ࣫") in eecmFXt5SRyCjGpx or dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠩࠥ࡭ࡩࠨࠧ࣬") in eecmFXt5SRyCjGpx:
		cOA5CMqB4WQr = url.split(GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠪ࠳࣭ࠬ"))[x1x9kIQo3zjZWnYaiy].replace(e2qDYgipPmTw4KvBLnochr(u"ࠫࡪࡳࡢࡦࡦ࠰࣮ࠫ"),hWGMqtBy4wuLaVcj).replace(sULh4NjakzI8He7xJCMGrql(u"ࠬ࠴ࡨࡵ࡯࡯࣯ࠫ"),hWGMqtBy4wuLaVcj)
		if rwQN9AKhLCuMfHxjlbX0U(u"࠭ࠢࡪࡦ࠵ࣰࠦࠬ") in eecmFXt5SRyCjGpx: l17Sn3hK59WV = {xcChIL13BpR8WArNt9Pl0So(u"ࠧࡪࡦ࠵ࣱࠫ"):cOA5CMqB4WQr,QvgnCALNstmuUJiET(u"ࠨࡱࡳࣲࠫ"):SqrG5mU3j96ldsFpExobw40TJY(u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧ࠶ࠬࣳ")}
		elif SqrG5mU3j96ldsFpExobw40TJY(u"ࠪࠦ࡮ࡪࠢࠨࣴ") in eecmFXt5SRyCjGpx: l17Sn3hK59WV = {FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠫ࡮ࡪࠧࣵ"):cOA5CMqB4WQr,LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠬࡵࡰࠨࣶ"):o1u5dij9UrcbXzVS8lwIWfKpnqM(u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤ࠳ࠩࣷ")}
		PwvNmnqXKrYVZugB5c8 = headers.copy()
		PwvNmnqXKrYVZugB5c8[QVDJLRlxNg127jMX(u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭ࣸ")] = rwQN9AKhLCuMfHxjlbX0U(u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪࣹࠧ")
		SkMF3ejVQcGAh92BI5Hyg = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(nHBb7jXk0Daom,hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠩࡓࡓࡘ࡚ࣺࠧ"),url,l17Sn3hK59WV,PwvNmnqXKrYVZugB5c8,hWGMqtBy4wuLaVcj,fEXMiAyG3ql4vKB,FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡘࡔࡊࡄࡖࡎࡔࡇ࠮࠴ࡱࡨࠬࣻ"))
		eecmFXt5SRyCjGpx = SkMF3ejVQcGAh92BI5Hyg.content
	XO3iPx1dV2kNeZm5z4ySM76tfDTc,acs6RTUQD5,mGB1gnx45ZREpokzUwiJrTj = UfyPgEMvCS1c5zewKB(url,eecmFXt5SRyCjGpx)
	WJ3dBsg956vaLAXm[QE5KgeLm43aSx6] = XO3iPx1dV2kNeZm5z4ySM76tfDTc,acs6RTUQD5,mGB1gnx45ZREpokzUwiJrTj,fc1FTYRB2AtjklMod7mOWCxEV
	return
WJ3dBsg956vaLAXm,nQ3kWXGVmur2ZN1ABw65 = {},ybdv7XcT3lxF6QezULwCAGk
def ppCXn9k7x8TfMNWeivFaGu(url):
	global WJ3dBsg956vaLAXm,nQ3kWXGVmur2ZN1ABw65
	m4IznKilUOByHweG68VJ,threads = [],[]
	nQ3kWXGVmur2ZN1ABw65 += rwQN9AKhLCuMfHxjlbX0U(u"࠳࠳࠴ষ")
	xIjyRbid08u6MFN5YmtX = nQ3kWXGVmur2ZN1ABw65
	m4IznKilUOByHweG68VJ.append([bXukYxQ4aHw,url])
	WJ3dBsg956vaLAXm[xIjyRbid08u6MFN5YmtX+bXukYxQ4aHw] = [None,None,None,None]
	y1oVkC9n5IPzYfiLwslchF24v = KCTRe67wVy.Thread(target=QbZ84quzk9tv6BVALU,args=(xIjyRbid08u6MFN5YmtX+bXukYxQ4aHw,url))
	y1oVkC9n5IPzYfiLwslchF24v.start()
	y1oVkC9n5IPzYfiLwslchF24v.join(HHoGx7Flus60(u"࠴࠴স"))
	if not WJ3dBsg956vaLAXm[xIjyRbid08u6MFN5YmtX+LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"࠵হ")][Y0XZKGRAUQj5O]:
		NPM3HKQ57xe = url.replace(sULh4NjakzI8He7xJCMGrql(u"ࠫ࠴࡫࡭ࡣࡧࡧ࠱ࠬࣼ"),FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠬ࠵ࠧࣽ"))
		LLsGB1FPiUTyYrdwqf86eHAnQ = trdVA0JvFaD.findall(HHoGx7Flus60(u"࠭࡞ࠩ࠰࠭ࡃ࠿࠵࠯࠯ࠬࡂ࠭࠴࠮࠮ࠫࡁࠬ࠳࠭࠴ࠪࡀࠫࠧࠫࣾ"),NPM3HKQ57xe+GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠧ࠰ࠩࣿ"),trdVA0JvFaD.DOTALL)
		start,wYn1ycK5FhOgzGqWEQbTpPj,end = LLsGB1FPiUTyYrdwqf86eHAnQ[ybdv7XcT3lxF6QezULwCAGk]
		end = end.strip(ITvnUAMXsyb4eO(u"ࠨ࠱ࠪऀ"))
		kZbSHwctFX9AE6ip = len(wYn1ycK5FhOgzGqWEQbTpPj)<jR6BYWNFZ0egmH4Tr2Q78LbSs3t or wYn1ycK5FhOgzGqWEQbTpPj in [sULh4NjakzI8He7xJCMGrql(u"ࠩࡩ࡭ࡱ࡫ࠧँ"),sULh4NjakzI8He7xJCMGrql(u"ࠪࡺ࡮ࡪࡥࡰࠩं"),XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠫࡻ࡯ࡤࡦࡱࡨࡱࡧ࡫ࡤࠨः"),DJ1ICpbyR2(u"ࠬࡧࡪࡢࡺࠪऄ"),LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"࠭ࡩࡧࡴࡤࡱࡪ࠭अ"),DJ1ICpbyR2(u"ࠧ࡮࡫ࡵࡶࡴࡸࠧआ")]
		if not kZbSHwctFX9AE6ip: m4IznKilUOByHweG68VJ.append([Y0XZKGRAUQj5O,start+S1SgCFYGJeMvfp5iZXK(u"ࠨ࠱ࡨࡱࡧ࡫ࡤ࠮ࠩइ")+wYn1ycK5FhOgzGqWEQbTpPj+MMizeNH0AKu(u"ࠩ࠲ࠫई")+end])
		if end: m4IznKilUOByHweG68VJ.append([x1x9kIQo3zjZWnYaiy,start+GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠪ࠳ࠬउ")+wYn1ycK5FhOgzGqWEQbTpPj+XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠫ࠴࡫࡭ࡣࡧࡧ࠱ࠬऊ")+end])
		if gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠬ࠴ࡨࡵ࡯࡯ࠫऋ") in wYn1ycK5FhOgzGqWEQbTpPj:
			c157tL4NIWMGB = wYn1ycK5FhOgzGqWEQbTpPj.replace(ITvnUAMXsyb4eO(u"࠭࠮ࡩࡶࡰࡰࠬऌ"),hWGMqtBy4wuLaVcj)
			m4IznKilUOByHweG68VJ.append([jR6BYWNFZ0egmH4Tr2Q78LbSs3t,start+JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠧ࠰ࠩऍ")+c157tL4NIWMGB+QvgnCALNstmuUJiET(u"ࠨ࠱ࠪऎ")+end])
			m4IznKilUOByHweG68VJ.append([QvgnCALNstmuUJiET(u"࠺঺"),start+LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠩ࠲ࡩࡲࡨࡥࡥ࠯ࠪए")+c157tL4NIWMGB+HHoGx7Flus60(u"ࠪ࠳ࠬऐ")+end])
			if end: m4IznKilUOByHweG68VJ.append([gDuGMR3z1aV6YdLmCpiO8Kl(u"࠼঻"),start+LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠫ࠴࠭ऑ")+c157tL4NIWMGB+CnbBKmtF1x84q7AW(u"ࠬ࠵ࡥ࡮ࡤࡨࡨ࠲࠭ऒ")+end])
		elif dv0trJR7PwmKyxDYO52VLau8gEph(u"࠭࠮ࡩࡶࡰࡰࠬओ") in end:
			Qkv5Dzl8X2qbE6VUYNZ = end.replace(gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠧ࠯ࡪࡷࡱࡱ࠭औ"),hWGMqtBy4wuLaVcj)
			m4IznKilUOByHweG68VJ.append([SqrG5mU3j96ldsFpExobw40TJY(u"࠷়"),start+ITvnUAMXsyb4eO(u"ࠨ࠱ࠪक")+wYn1ycK5FhOgzGqWEQbTpPj+JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠩ࠲ࠫख")+Qkv5Dzl8X2qbE6VUYNZ])
			if not kZbSHwctFX9AE6ip: m4IznKilUOByHweG68VJ.append([SqrG5mU3j96ldsFpExobw40TJY(u"࠹ঽ"),start+KBkxSYaz93pu1(u"ࠪ࠳ࡪࡳࡢࡦࡦ࠰ࠫग")+wYn1ycK5FhOgzGqWEQbTpPj+DJ1ICpbyR2(u"ࠫ࠴࠭घ")+Qkv5Dzl8X2qbE6VUYNZ])
			m4IznKilUOByHweG68VJ.append([wwPrSDa21lUh(u"࠻া"),start+FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠬ࠵ࠧङ")+wYn1ycK5FhOgzGqWEQbTpPj+dv0trJR7PwmKyxDYO52VLau8gEph(u"࠭࠯ࡦ࡯ࡥࡩࡩ࠳ࠧच")+Qkv5Dzl8X2qbE6VUYNZ])
		else:
			if not kZbSHwctFX9AE6ip: m4IznKilUOByHweG68VJ.append([ITvnUAMXsyb4eO(u"࠴࠴ি"),start+wwPrSDa21lUh(u"ࠧ࠰ࠩछ")+wYn1ycK5FhOgzGqWEQbTpPj+SqrG5mU3j96ldsFpExobw40TJY(u"ࠨ࠰࡫ࡸࡲࡲࠧज")])
			if not kZbSHwctFX9AE6ip: m4IznKilUOByHweG68VJ.append([KBkxSYaz93pu1(u"࠵࠶ী"),start+FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠩ࠲ࡩࡲࡨࡥࡥ࠯ࠪझ")+wYn1ycK5FhOgzGqWEQbTpPj+EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠪ࠲࡭ࡺ࡭࡭ࠩञ")])
			if end: m4IznKilUOByHweG68VJ.append([OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"࠶࠸ু"),start+DJ1ICpbyR2(u"ࠫ࠴࠭ट")+wYn1ycK5FhOgzGqWEQbTpPj+A6dMB1FlgxVivJ2fk9C(u"ࠬ࠵ࠧठ")+end+DJ1ICpbyR2(u"࠭࠮ࡩࡶࡰࡰࠬड")])
			if end: m4IznKilUOByHweG68VJ.append([GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"࠷࠳ূ"),start+S1SgCFYGJeMvfp5iZXK(u"ࠧ࠰ࠩढ")+wYn1ycK5FhOgzGqWEQbTpPj+EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠨ࠱ࡨࡱࡧ࡫ࡤ࠮ࠩण")+end+LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠩ࠱࡬ࡹࡳ࡬ࠨत")])
		if kZbSHwctFX9AE6ip and end:
			end = end.replace(KBkxSYaz93pu1(u"ࠪ࠳ࡪࡳࡢࡦࡦ࠰ࠫथ"),QVDJLRlxNg127jMX(u"ࠫ࠴࠭द"))
			m4IznKilUOByHweG68VJ.append([LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"࠱࠵ৃ"),start+jeAby54c02TgG8zuivonX91(u"ࠬ࠵ࠧध")+end])
			m4IznKilUOByHweG68VJ.append([zyvJMtBhrw(u"࠲࠷ৄ"),start+DJ1ICpbyR2(u"࠭࠯ࡦ࡯ࡥࡩࡩ࠳ࠧन")+end])
			if SqrG5mU3j96ldsFpExobw40TJY(u"ࠧ࠯ࡪࡷࡱࡱ࠭ऩ") in end:
				Qkv5Dzl8X2qbE6VUYNZ = end.replace(zyvJMtBhrw(u"ࠨ࠰࡫ࡸࡲࡲࠧप"),hWGMqtBy4wuLaVcj)
				m4IznKilUOByHweG68VJ.append([jeAby54c02TgG8zuivonX91(u"࠳࠹৅"),start+CnbBKmtF1x84q7AW(u"ࠩ࠲ࠫफ")+Qkv5Dzl8X2qbE6VUYNZ])
				m4IznKilUOByHweG68VJ.append([MMizeNH0AKu(u"࠴࠻৆"),start+sULh4NjakzI8He7xJCMGrql(u"ࠪ࠳ࡪࡳࡢࡦࡦ࠰ࠫब")+Qkv5Dzl8X2qbE6VUYNZ])
			else:
				m4IznKilUOByHweG68VJ.append([hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"࠵࠽ে"),start+hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠫ࠴࠭भ")+end+JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠬ࠴ࡨࡵ࡯࡯ࠫम")])
				m4IznKilUOByHweG68VJ.append([SqrG5mU3j96ldsFpExobw40TJY(u"࠶࠿ৈ"),start+QVDJLRlxNg127jMX(u"࠭࠯ࡦ࡯ࡥࡩࡩ࠳ࠧय")+end+S1SgCFYGJeMvfp5iZXK(u"ࠧ࠯ࡪࡷࡱࡱ࠭र")])
		h6CplwAFjq9J1gPUQu3c0avtL = []
		for VzAiKmWdsgw9XfIuF1e0,llxFwq0CUNgQtivJzkHeGV in m4IznKilUOByHweG68VJ[bXukYxQ4aHw:]:
			WJ3dBsg956vaLAXm[xIjyRbid08u6MFN5YmtX+VzAiKmWdsgw9XfIuF1e0] = [None,None,None,None]
			MOHGBAXzJE6F0Wsvoa = KCTRe67wVy.Thread(target=QbZ84quzk9tv6BVALU,args=(xIjyRbid08u6MFN5YmtX+VzAiKmWdsgw9XfIuF1e0,llxFwq0CUNgQtivJzkHeGV))
			MOHGBAXzJE6F0Wsvoa.start()
			h6CplwAFjq9J1gPUQu3c0avtL.append(MOHGBAXzJE6F0Wsvoa)
			HB5PvxRhwM.sleep(XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"࠶࠮࠸࠷৉"))
		for MOHGBAXzJE6F0Wsvoa in h6CplwAFjq9J1gPUQu3c0avtL: MOHGBAXzJE6F0Wsvoa.join(LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"࠱࠱৊"))
	pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = hWGMqtBy4wuLaVcj,[],[]
	zG7capgdQ1e42M = []
	for VzAiKmWdsgw9XfIuF1e0,llxFwq0CUNgQtivJzkHeGV in m4IznKilUOByHweG68VJ:
		ISi2nOXHJZud0NYoPbywtQv,zSLqdvJBR7UpP,NmnXBSrODFGo9,nRamC7NQ0LXkHvusF14rKt = WJ3dBsg956vaLAXm[xIjyRbid08u6MFN5YmtX+VzAiKmWdsgw9XfIuF1e0]
		if not Dvi8asSrQYX5wE3KMIxT91me and NmnXBSrODFGo9: haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = zSLqdvJBR7UpP,NmnXBSrODFGo9
		if not pxdY8tiazyJIq and ISi2nOXHJZud0NYoPbywtQv: pxdY8tiazyJIq = ISi2nOXHJZud0NYoPbywtQv
		if nRamC7NQ0LXkHvusF14rKt: zG7capgdQ1e42M.append(nRamC7NQ0LXkHvusF14rKt)
	zG7capgdQ1e42M = list(set(zG7capgdQ1e42M))
	if not pxdY8tiazyJIq and len(zG7capgdQ1e42M)==FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"࠲ো"):
		fc1FTYRB2AtjklMod7mOWCxEV = zG7capgdQ1e42M[ybdv7XcT3lxF6QezULwCAGk]
		if fc1FTYRB2AtjklMod7mOWCxEV!=dv0trJR7PwmKyxDYO52VLau8gEph(u"࠴࠳࠴ৌ"):
			if fc1FTYRB2AtjklMod7mOWCxEV<ybdv7XcT3lxF6QezULwCAGk: pxdY8tiazyJIq = gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠨࡘ࡬ࡨࡪࡵࠠࡱࡣࡪࡩ࠴ࡹࡥࡳࡸࡨࡶࠥ࡯ࡳࠡࡰࡲࡸࠥࡧࡣࡤࡧࡶࡷ࡮ࡨ࡬ࡦࠩऱ")
			else:
				pxdY8tiazyJIq = sULh4NjakzI8He7xJCMGrql(u"ࠩࡋࡘ࡙ࡖࠠࡆࡴࡵࡳࡷࡀࠠࠨल")+str(fc1FTYRB2AtjklMod7mOWCxEV)
				if H4qZ2hwilNJYTmCFEQyaSs98cPM0gR: import http.client as RCpQGnzBIFdtDUq18V
				else: import httplib as RCpQGnzBIFdtDUq18V
				try: pxdY8tiazyJIq += HHoGx7Flus60(u"ࠪࠤ࠭ࠦࠧळ")+RCpQGnzBIFdtDUq18V.responses[fc1FTYRB2AtjklMod7mOWCxEV]+ITvnUAMXsyb4eO(u"ࠫࠥ࠯ࠧऴ")
				except: pass
	HB5PvxRhwM.sleep(bXukYxQ4aHw)
	return pxdY8tiazyJIq,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me
class zUNhcGo17C3bgLBP5(mUWYiQ2jHICA8cD6LhPTn3wpB1XyK.WindowDialog):
	def __init__(z3d8DqtAsgLQaCom7X2Ilv1MrU, *args, **wnyfz7W4IbeiAd98XrZLpVsK):
		VsBarXR2nAkiE7OdWfZoYFTqDvgICy = WQvYkNg7SysPFLitlGEn6.path.join(ggKyfILOkNPGxMtDQueVSZ, gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠬࡸࡥࡴࡱࡸࡶࡨ࡫ࡳࠨव"), mkHKSQvjWr5BTcM3wVY(u"࠭ࡲࡦࡥࡤࡴࡹࡩࡨࡢ࠴ࠪश"), gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠧࡥ࡫ࡤࡰࡴ࡭ࡢࡨ࠰ࡳࡲ࡬࠭ष"))
		scjktPraqwELmI9AR = WQvYkNg7SysPFLitlGEn6.path.join(ggKyfILOkNPGxMtDQueVSZ, jeAby54c02TgG8zuivonX91(u"ࠨࡴࡨࡷࡴࡻࡲࡤࡧࡶࠫस"), EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠩࡵࡩࡨࡧࡰࡵࡥ࡫ࡥ࠷࠭ह"), sULh4NjakzI8He7xJCMGrql(u"ࠪࡷࡪࡲࡥࡤࡶࡨࡨ࠳ࡶ࡮ࡨࠩऺ"))
		j531amPedLAS9yHhQ47WYpVzs = WQvYkNg7SysPFLitlGEn6.path.join(ggKyfILOkNPGxMtDQueVSZ, mkHKSQvjWr5BTcM3wVY(u"ࠫࡷ࡫ࡳࡰࡷࡵࡧࡪࡹࠧऻ"), NeO3CTLHrPfWUoIgy8Q(u"ࠬࡸࡥࡤࡣࡳࡸࡨ࡮ࡡ࠳़ࠩ"), CnbBKmtF1x84q7AW(u"࠭ࡢࡶࡶࡷࡳࡳ࡬࡯࠯ࡲࡱ࡫ࠬऽ"))
		AumjHyFwosIGUblO4VW7 = WQvYkNg7SysPFLitlGEn6.path.join(ggKyfILOkNPGxMtDQueVSZ, S1SgCFYGJeMvfp5iZXK(u"ࠧࡳࡧࡶࡳࡺࡸࡣࡦࡵࠪा"), CnbBKmtF1x84q7AW(u"ࠨࡴࡨࡧࡦࡶࡴࡤࡪࡤ࠶ࠬि"), EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠩࡥࡹࡹࡺ࡯࡯ࡰࡩ࠲ࡵࡴࡧࠨी"))
		f62fyPsiOH1hbkJQCEmrS37 = WQvYkNg7SysPFLitlGEn6.path.join(ggKyfILOkNPGxMtDQueVSZ, dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠪࡶࡪࡹ࡯ࡶࡴࡦࡩࡸ࠭ु"), MMizeNH0AKu(u"ࠫࡷ࡫ࡣࡢࡲࡷࡧ࡭ࡧ࠲ࠨू"), wwPrSDa21lUh(u"ࠬࡨࡵࡵࡶࡲࡲࡧ࡭࠮ࡱࡰࡪࠫृ"))
		z3d8DqtAsgLQaCom7X2Ilv1MrU.cancelled = fEXMiAyG3ql4vKB
		z3d8DqtAsgLQaCom7X2Ilv1MrU.chk = [ybdv7XcT3lxF6QezULwCAGk] * KBkxSYaz93pu1(u"࠼্")
		z3d8DqtAsgLQaCom7X2Ilv1MrU.chkbutton = [ybdv7XcT3lxF6QezULwCAGk] * A6dMB1FlgxVivJ2fk9C(u"࠽ৎ")
		z3d8DqtAsgLQaCom7X2Ilv1MrU.chkstate = [fEXMiAyG3ql4vKB] * LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"࠾৏")
		ffjCmwJuT9qA3QIcGp65X, MhkoeVtG3XIrxAmB, WYHCDTR1cL7ukv, QhxfaKLt4ys = A6dMB1FlgxVivJ2fk9C(u"࠸࠵࠱৐"), ybdv7XcT3lxF6QezULwCAGk, A6dMB1FlgxVivJ2fk9C(u"࠷࠱࠲৑"), sULh4NjakzI8He7xJCMGrql(u"࠸࠸࠳৒")
		w4FaUcP8u6h0 = ffjCmwJuT9qA3QIcGp65X+WYHCDTR1cL7ukv//Y0XZKGRAUQj5O
		BiTZsWuRSLIxYK6Fv, D4sb1tuChx7loJez3Mpi, wbOB5kzGZf6i, KlXS4syRd3DzEN8i7c9J = GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"࠶࠹࠺৔"), wwPrSDa21lUh(u"࠳࠵࠴৓"), e2qDYgipPmTw4KvBLnochr(u"࠹࠵࠶৕"), e2qDYgipPmTw4KvBLnochr(u"࠹࠵࠶৕")
		wwITQ1jWmRC9JfD = BiTZsWuRSLIxYK6Fv+wbOB5kzGZf6i//Y0XZKGRAUQj5O
		zyLSYVf3FNvw5mGABHk, WWjrw7cuYtIQ6o, BLzH2psfIn8G9d, wPqediBRDkvrK1yhmgQpso3fu2UA = dv0trJR7PwmKyxDYO52VLau8gEph(u"࠷࠰࠱ৗ"), zyvJMtBhrw(u"࠶࠶࠷৘"), DJ1ICpbyR2(u"࠶࠻࠰৖"), XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"࠶࠲৙")
		yBkbJaA8us0zxP3NTF = w4FaUcP8u6h0-BLzH2psfIn8G9d-zyLSYVf3FNvw5mGABHk//Y0XZKGRAUQj5O
		x1SGsAl2q6Ere = w4FaUcP8u6h0+zyLSYVf3FNvw5mGABHk//Y0XZKGRAUQj5O
		gYDr7jkMNuOKmJ6A, BKgY4MjOwDRWAHm3N, SsordMEuHbX, Rn1xWgJAlbpGP3hc = jeAby54c02TgG8zuivonX91(u"࠵࠸࠹৚"), NeO3CTLHrPfWUoIgy8Q(u"࠶࠴৛"), DJ1ICpbyR2(u"࠺࠶࠰ঢ়"), QvgnCALNstmuUJiET(u"࠹࠵ড়")
		cNet9hVZXoR7OP34d5fLlxWqpTnKGM, NNoGxICUqpBDQe, vF53LEgY8jc7eNM61Ju, hKnI49QGALSNDCFBfjXeMV = o1u5dij9UrcbXzVS8lwIWfKpnqM(u"࠹࠵࠶৞"), JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"࠹࠳ৡ"), LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"࠶࠲࠳ৠ"), gDuGMR3z1aV6YdLmCpiO8Kl(u"࠵࠱য়")
		zAbRdrBt5qDmF0PCp7UKWgQEjfs = xcChIL13BpR8WArNt9Pl0So(u"࠳࠲࠾ৢ")
		ffjCmwJuT9qA3QIcGp65X, MhkoeVtG3XIrxAmB, WYHCDTR1cL7ukv, QhxfaKLt4ys = int(ffjCmwJuT9qA3QIcGp65X*zAbRdrBt5qDmF0PCp7UKWgQEjfs), int(MhkoeVtG3XIrxAmB*zAbRdrBt5qDmF0PCp7UKWgQEjfs), int(WYHCDTR1cL7ukv*zAbRdrBt5qDmF0PCp7UKWgQEjfs), int(QhxfaKLt4ys*zAbRdrBt5qDmF0PCp7UKWgQEjfs)
		BiTZsWuRSLIxYK6Fv, D4sb1tuChx7loJez3Mpi, wbOB5kzGZf6i, KlXS4syRd3DzEN8i7c9J = int(BiTZsWuRSLIxYK6Fv*zAbRdrBt5qDmF0PCp7UKWgQEjfs), int(D4sb1tuChx7loJez3Mpi*zAbRdrBt5qDmF0PCp7UKWgQEjfs), int(wbOB5kzGZf6i*zAbRdrBt5qDmF0PCp7UKWgQEjfs), int(KlXS4syRd3DzEN8i7c9J*zAbRdrBt5qDmF0PCp7UKWgQEjfs)
		yBkbJaA8us0zxP3NTF, qbdz26yvPsVwOUpo8tB, NEDzVLp6K09fHJiukgZXCrhy, aasAmiWOqMTSGtwcyKrubhN49IYn = int(yBkbJaA8us0zxP3NTF*zAbRdrBt5qDmF0PCp7UKWgQEjfs), int(WWjrw7cuYtIQ6o*zAbRdrBt5qDmF0PCp7UKWgQEjfs), int(BLzH2psfIn8G9d*zAbRdrBt5qDmF0PCp7UKWgQEjfs), int(wPqediBRDkvrK1yhmgQpso3fu2UA*zAbRdrBt5qDmF0PCp7UKWgQEjfs)
		x1SGsAl2q6Ere, gH6PlQnye1juTsDV2m4hiqBEGC, G2ZdYAbO79CrEjuVvimIzQ3D, QLyWF239tKAR5ufOPIiYz = int(x1SGsAl2q6Ere*zAbRdrBt5qDmF0PCp7UKWgQEjfs), int(WWjrw7cuYtIQ6o*zAbRdrBt5qDmF0PCp7UKWgQEjfs), int(BLzH2psfIn8G9d*zAbRdrBt5qDmF0PCp7UKWgQEjfs), int(wPqediBRDkvrK1yhmgQpso3fu2UA*zAbRdrBt5qDmF0PCp7UKWgQEjfs)
		gYDr7jkMNuOKmJ6A, BKgY4MjOwDRWAHm3N, SsordMEuHbX, Rn1xWgJAlbpGP3hc = int(gYDr7jkMNuOKmJ6A*zAbRdrBt5qDmF0PCp7UKWgQEjfs), int(BKgY4MjOwDRWAHm3N*zAbRdrBt5qDmF0PCp7UKWgQEjfs), int(SsordMEuHbX*zAbRdrBt5qDmF0PCp7UKWgQEjfs), int(Rn1xWgJAlbpGP3hc*zAbRdrBt5qDmF0PCp7UKWgQEjfs)
		cNet9hVZXoR7OP34d5fLlxWqpTnKGM, NNoGxICUqpBDQe, vF53LEgY8jc7eNM61Ju, hKnI49QGALSNDCFBfjXeMV = int(cNet9hVZXoR7OP34d5fLlxWqpTnKGM*zAbRdrBt5qDmF0PCp7UKWgQEjfs), int(NNoGxICUqpBDQe*zAbRdrBt5qDmF0PCp7UKWgQEjfs), int(vF53LEgY8jc7eNM61Ju*zAbRdrBt5qDmF0PCp7UKWgQEjfs), int(hKnI49QGALSNDCFBfjXeMV*zAbRdrBt5qDmF0PCp7UKWgQEjfs)
		VSoPe9XOrZizJ3Lw = mUWYiQ2jHICA8cD6LhPTn3wpB1XyK.ControlImage(ffjCmwJuT9qA3QIcGp65X, MhkoeVtG3XIrxAmB, WYHCDTR1cL7ukv, QhxfaKLt4ys, VsBarXR2nAkiE7OdWfZoYFTqDvgICy)
		z3d8DqtAsgLQaCom7X2Ilv1MrU.addControl(VSoPe9XOrZizJ3Lw)
		z3d8DqtAsgLQaCom7X2Ilv1MrU.iteration = wnyfz7W4IbeiAd98XrZLpVsK.get(dv0trJR7PwmKyxDYO52VLau8gEph(u"࠭ࡩࡵࡧࡵࡥࡹ࡯࡯࡯ࠩॄ"))
		K8KHqkOo9eBRamgAC = soMVfbr6WtpNlcSA+gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠧโฯุࠤศ์วࠡว้ืฬ์้ࠠๆึฮࠥื่ษ๊อࠤࠥࠦࠠࠡࠢࠣࠤࠥ࠭ॅ")+rwQN9AKhLCuMfHxjlbX0U(u"ࠨษ็้าอ่ๅหࠣี็๋ࠠࠡࠩॆ")+str(z3d8DqtAsgLQaCom7X2Ilv1MrU.iteration)+YYSh2J6BIrsm8
		z3d8DqtAsgLQaCom7X2Ilv1MrU.strActionInfo = mUWYiQ2jHICA8cD6LhPTn3wpB1XyK.ControlLabel(gYDr7jkMNuOKmJ6A, BKgY4MjOwDRWAHm3N, SsordMEuHbX, Rn1xWgJAlbpGP3hc, K8KHqkOo9eBRamgAC, DJ1ICpbyR2(u"ࠩࡩࡳࡳࡺ࠱࠴ࠩे"))
		z3d8DqtAsgLQaCom7X2Ilv1MrU.addControl(z3d8DqtAsgLQaCom7X2Ilv1MrU.strActionInfo)
		Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG = mUWYiQ2jHICA8cD6LhPTn3wpB1XyK.ControlImage(BiTZsWuRSLIxYK6Fv, D4sb1tuChx7loJez3Mpi, wbOB5kzGZf6i, KlXS4syRd3DzEN8i7c9J, wnyfz7W4IbeiAd98XrZLpVsK.get(QvgnCALNstmuUJiET(u"ࠪࡧࡦࡶࡴࡤࡪࡤࠫै")))
		z3d8DqtAsgLQaCom7X2Ilv1MrU.addControl(Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
		gjLck8Gdnz6f = soMVfbr6WtpNlcSA+wnyfz7W4IbeiAd98XrZLpVsK.get(xcChIL13BpR8WArNt9Pl0So(u"ࠫࡲࡹࡧࠨॉ"))+YYSh2J6BIrsm8
		z3d8DqtAsgLQaCom7X2Ilv1MrU.strActionInfo = mUWYiQ2jHICA8cD6LhPTn3wpB1XyK.ControlLabel(cNet9hVZXoR7OP34d5fLlxWqpTnKGM, NNoGxICUqpBDQe, vF53LEgY8jc7eNM61Ju, hKnI49QGALSNDCFBfjXeMV, gjLck8Gdnz6f, wwPrSDa21lUh(u"ࠬ࡬࡯࡯ࡶ࠴࠷ࠬॊ"))
		z3d8DqtAsgLQaCom7X2Ilv1MrU.addControl(z3d8DqtAsgLQaCom7X2Ilv1MrU.strActionInfo)
		text = soMVfbr6WtpNlcSA+S1SgCFYGJeMvfp5iZXK(u"࠭ฮา๊ฯࠫो")+YYSh2J6BIrsm8
		z3d8DqtAsgLQaCom7X2Ilv1MrU.cancelbutton = mUWYiQ2jHICA8cD6LhPTn3wpB1XyK.ControlButton(yBkbJaA8us0zxP3NTF, qbdz26yvPsVwOUpo8tB, NEDzVLp6K09fHJiukgZXCrhy, aasAmiWOqMTSGtwcyKrubhN49IYn, text, focusTexture=f62fyPsiOH1hbkJQCEmrS37, noFocusTexture=j531amPedLAS9yHhQ47WYpVzs, alignment=rwQN9AKhLCuMfHxjlbX0U(u"࠶ৣ"))
		text = soMVfbr6WtpNlcSA+FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠧศีอ้ึอัࠨौ")+YYSh2J6BIrsm8
		z3d8DqtAsgLQaCom7X2Ilv1MrU.okbutton = mUWYiQ2jHICA8cD6LhPTn3wpB1XyK.ControlButton(x1SGsAl2q6Ere, gH6PlQnye1juTsDV2m4hiqBEGC, G2ZdYAbO79CrEjuVvimIzQ3D, QLyWF239tKAR5ufOPIiYz, text, focusTexture=f62fyPsiOH1hbkJQCEmrS37, noFocusTexture=j531amPedLAS9yHhQ47WYpVzs, alignment=OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"࠷৤"))
		z3d8DqtAsgLQaCom7X2Ilv1MrU.addControl(z3d8DqtAsgLQaCom7X2Ilv1MrU.okbutton)
		z3d8DqtAsgLQaCom7X2Ilv1MrU.addControl(z3d8DqtAsgLQaCom7X2Ilv1MrU.cancelbutton)
		gtHkb2MErvD3XdCB, v1ia6S5DpwLIoK0tdXYl2C8GT9kVE = KlXS4syRd3DzEN8i7c9J//x1x9kIQo3zjZWnYaiy, wbOB5kzGZf6i//x1x9kIQo3zjZWnYaiy
		for PPuqrvDLEViYOMf1dmkK7 in range(sULh4NjakzI8He7xJCMGrql(u"࠿৥")):
			W5SVtUKbq1vuzDpRaXEgT4 = PPuqrvDLEViYOMf1dmkK7 // x1x9kIQo3zjZWnYaiy
			n8DzkXaAcsfeU = PPuqrvDLEViYOMf1dmkK7 % x1x9kIQo3zjZWnYaiy
			ssLnSGUZEjlvdtePQHoIMbaTCV = BiTZsWuRSLIxYK6Fv + (v1ia6S5DpwLIoK0tdXYl2C8GT9kVE * n8DzkXaAcsfeU)
			R1g7FTH390YnUjc = D4sb1tuChx7loJez3Mpi + (gtHkb2MErvD3XdCB * W5SVtUKbq1vuzDpRaXEgT4)
			z3d8DqtAsgLQaCom7X2Ilv1MrU.chk[PPuqrvDLEViYOMf1dmkK7] = mUWYiQ2jHICA8cD6LhPTn3wpB1XyK.ControlImage(ssLnSGUZEjlvdtePQHoIMbaTCV, R1g7FTH390YnUjc, v1ia6S5DpwLIoK0tdXYl2C8GT9kVE, gtHkb2MErvD3XdCB, scjktPraqwELmI9AR)
			z3d8DqtAsgLQaCom7X2Ilv1MrU.addControl(z3d8DqtAsgLQaCom7X2Ilv1MrU.chk[PPuqrvDLEViYOMf1dmkK7])
			z3d8DqtAsgLQaCom7X2Ilv1MrU.chk[PPuqrvDLEViYOMf1dmkK7].setVisible(fEXMiAyG3ql4vKB)
			z3d8DqtAsgLQaCom7X2Ilv1MrU.chkbutton[PPuqrvDLEViYOMf1dmkK7] = mUWYiQ2jHICA8cD6LhPTn3wpB1XyK.ControlButton(ssLnSGUZEjlvdtePQHoIMbaTCV, R1g7FTH390YnUjc, v1ia6S5DpwLIoK0tdXYl2C8GT9kVE, gtHkb2MErvD3XdCB, str(PPuqrvDLEViYOMf1dmkK7 + bXukYxQ4aHw), font=JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠨࡨࡲࡲࡹ࠷࠳ࠨ्"), focusTexture=j531amPedLAS9yHhQ47WYpVzs, noFocusTexture=AumjHyFwosIGUblO4VW7)
			z3d8DqtAsgLQaCom7X2Ilv1MrU.addControl(z3d8DqtAsgLQaCom7X2Ilv1MrU.chkbutton[PPuqrvDLEViYOMf1dmkK7])
		for PPuqrvDLEViYOMf1dmkK7 in range(rwQN9AKhLCuMfHxjlbX0U(u"࠹০")):
			vzVysPq2jZxMUaX1iRebI = (PPuqrvDLEViYOMf1dmkK7 // x1x9kIQo3zjZWnYaiy) * x1x9kIQo3zjZWnYaiy
			ZQM5cO2gJa = vzVysPq2jZxMUaX1iRebI + (PPuqrvDLEViYOMf1dmkK7 + bXukYxQ4aHw) % x1x9kIQo3zjZWnYaiy
			rLeiQS3Dx1PuyHOFZ7nRb4d0 = vzVysPq2jZxMUaX1iRebI + (PPuqrvDLEViYOMf1dmkK7 - bXukYxQ4aHw) % x1x9kIQo3zjZWnYaiy
			P18PSHnYMgfIosxacKeq = (PPuqrvDLEViYOMf1dmkK7 - x1x9kIQo3zjZWnYaiy) % zyvJMtBhrw(u"࠺১")
			ZZ1pTlMDmuvQF6BLa0PbYXhj = (PPuqrvDLEViYOMf1dmkK7 + x1x9kIQo3zjZWnYaiy) % jeAby54c02TgG8zuivonX91(u"࠻২")
			z3d8DqtAsgLQaCom7X2Ilv1MrU.chkbutton[PPuqrvDLEViYOMf1dmkK7].controlRight(z3d8DqtAsgLQaCom7X2Ilv1MrU.chkbutton[ZQM5cO2gJa])
			z3d8DqtAsgLQaCom7X2Ilv1MrU.chkbutton[PPuqrvDLEViYOMf1dmkK7].controlLeft(z3d8DqtAsgLQaCom7X2Ilv1MrU.chkbutton[rLeiQS3Dx1PuyHOFZ7nRb4d0])
			if PPuqrvDLEViYOMf1dmkK7 <= Y0XZKGRAUQj5O:
				z3d8DqtAsgLQaCom7X2Ilv1MrU.chkbutton[PPuqrvDLEViYOMf1dmkK7].controlUp(z3d8DqtAsgLQaCom7X2Ilv1MrU.okbutton)
			else:
				z3d8DqtAsgLQaCom7X2Ilv1MrU.chkbutton[PPuqrvDLEViYOMf1dmkK7].controlUp(z3d8DqtAsgLQaCom7X2Ilv1MrU.chkbutton[P18PSHnYMgfIosxacKeq])
			if PPuqrvDLEViYOMf1dmkK7 >= wwPrSDa21lUh(u"࠹৩"):
				z3d8DqtAsgLQaCom7X2Ilv1MrU.chkbutton[PPuqrvDLEViYOMf1dmkK7].controlDown(z3d8DqtAsgLQaCom7X2Ilv1MrU.okbutton)
			else:
				z3d8DqtAsgLQaCom7X2Ilv1MrU.chkbutton[PPuqrvDLEViYOMf1dmkK7].controlDown(z3d8DqtAsgLQaCom7X2Ilv1MrU.chkbutton[ZZ1pTlMDmuvQF6BLa0PbYXhj])
		z3d8DqtAsgLQaCom7X2Ilv1MrU.okbutton.controlLeft(z3d8DqtAsgLQaCom7X2Ilv1MrU.cancelbutton)
		z3d8DqtAsgLQaCom7X2Ilv1MrU.okbutton.controlRight(z3d8DqtAsgLQaCom7X2Ilv1MrU.cancelbutton)
		z3d8DqtAsgLQaCom7X2Ilv1MrU.cancelbutton.controlLeft(z3d8DqtAsgLQaCom7X2Ilv1MrU.okbutton)
		z3d8DqtAsgLQaCom7X2Ilv1MrU.cancelbutton.controlRight(z3d8DqtAsgLQaCom7X2Ilv1MrU.okbutton)
		z3d8DqtAsgLQaCom7X2Ilv1MrU.okbutton.controlDown(z3d8DqtAsgLQaCom7X2Ilv1MrU.chkbutton[Y0XZKGRAUQj5O])
		z3d8DqtAsgLQaCom7X2Ilv1MrU.okbutton.controlUp(z3d8DqtAsgLQaCom7X2Ilv1MrU.chkbutton[dv0trJR7PwmKyxDYO52VLau8gEph(u"࠼৪")])
		z3d8DqtAsgLQaCom7X2Ilv1MrU.cancelbutton.controlDown(z3d8DqtAsgLQaCom7X2Ilv1MrU.chkbutton[ybdv7XcT3lxF6QezULwCAGk])
		z3d8DqtAsgLQaCom7X2Ilv1MrU.cancelbutton.controlUp(z3d8DqtAsgLQaCom7X2Ilv1MrU.chkbutton[OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"࠻৫")])
		z3d8DqtAsgLQaCom7X2Ilv1MrU.setFocus(z3d8DqtAsgLQaCom7X2Ilv1MrU.okbutton)
	def get(z3d8DqtAsgLQaCom7X2Ilv1MrU):
		z3d8DqtAsgLQaCom7X2Ilv1MrU.doModal()
		z3d8DqtAsgLQaCom7X2Ilv1MrU.close()
		if not z3d8DqtAsgLQaCom7X2Ilv1MrU.cancelled:
			return [PPuqrvDLEViYOMf1dmkK7 for PPuqrvDLEViYOMf1dmkK7 in range(mkHKSQvjWr5BTcM3wVY(u"࠿৬")) if z3d8DqtAsgLQaCom7X2Ilv1MrU.chkstate[PPuqrvDLEViYOMf1dmkK7]]
	def onControl(z3d8DqtAsgLQaCom7X2Ilv1MrU, hIt1XGz06sLcHVO7rNDRx):
		if hIt1XGz06sLcHVO7rNDRx.getId() == z3d8DqtAsgLQaCom7X2Ilv1MrU.okbutton.getId() and any(z3d8DqtAsgLQaCom7X2Ilv1MrU.chkstate):
			z3d8DqtAsgLQaCom7X2Ilv1MrU.close()
		elif hIt1XGz06sLcHVO7rNDRx.getId() == z3d8DqtAsgLQaCom7X2Ilv1MrU.cancelbutton.getId():
			z3d8DqtAsgLQaCom7X2Ilv1MrU.cancelled = VBlawK4mgHSyLEn8iqhUkz5
			z3d8DqtAsgLQaCom7X2Ilv1MrU.close()
		else:
			h4s5qao1CX = hIt1XGz06sLcHVO7rNDRx.getLabel()
			if h4s5qao1CX.isnumeric():
				index = int(h4s5qao1CX) - bXukYxQ4aHw
				z3d8DqtAsgLQaCom7X2Ilv1MrU.chkstate[index] = not z3d8DqtAsgLQaCom7X2Ilv1MrU.chkstate[index]
				z3d8DqtAsgLQaCom7X2Ilv1MrU.chk[index].setVisible(z3d8DqtAsgLQaCom7X2Ilv1MrU.chkstate[index])
	def onAction(z3d8DqtAsgLQaCom7X2Ilv1MrU, QSTd4nDuCG3zq5YRKgL9):
		if QSTd4nDuCG3zq5YRKgL9 == xcChIL13BpR8WArNt9Pl0So(u"࠱࠱৭"):
			z3d8DqtAsgLQaCom7X2Ilv1MrU.cancelled = VBlawK4mgHSyLEn8iqhUkz5
			z3d8DqtAsgLQaCom7X2Ilv1MrU.close()
def MgS8XP5hQrA1T0B9RViw(key,aawXIHdWlt7k,url):
	headers = {EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪॎ"):url,xcChIL13BpR8WArNt9Pl0So(u"ࠪࡅࡨࡩࡥࡱࡶ࠰ࡐࡦࡴࡧࡶࡣࡪࡩࠬॏ"):aawXIHdWlt7k}
	hfYAGosI7dPmn2BFWOw5 = HHoGx7Flus60(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡩࡲࡳ࡬ࡲࡥ࠯ࡥࡲࡱ࠴ࡸࡥࡤࡣࡳࡸࡨ࡮ࡡ࠰ࡣࡳ࡭࠴࡬ࡡ࡭࡮ࡥࡥࡨࡱ࠿࡬࠿ࠪॐ")+key
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(DpQifS0oKBI1hYcO,EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠬࡍࡅࡕࠩ॑"),hfYAGosI7dPmn2BFWOw5,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,o1u5dij9UrcbXzVS8lwIWfKpnqM(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡊࡉ࡙ࡥࡒࡆࡅࡄࡔ࡙ࡉࡈࡂ࠴ࡢࡘࡔࡑࡅࡏ࠯࠴ࡷࡹ॒࠭"))
	vanQT4j5Z8SfO2MHg19I,iteration = hWGMqtBy4wuLaVcj,ybdv7XcT3lxF6QezULwCAGk
	while VBlawK4mgHSyLEn8iqhUkz5:
		mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
		l17Sn3hK59WV = trdVA0JvFaD.findall(MMizeNH0AKu(u"ࠧࠣࠪ࠲ࡶࡪࡩࡡࡱࡶࡦ࡬ࡦ࠵ࡡࡱ࡫࠵࠳ࡵࡧࡹ࡭ࡱࡤࡨࡠࡤࠢ࡞࠭ࠬࠫ॓"), mMQ3FkNVa4IlxqY)
		iteration += bXukYxQ4aHw
		message = trdVA0JvFaD.findall(hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠨ࠾࡯ࡥࡧ࡫࡬࡜ࡠࡁࡡ࠰ࡩ࡬ࡢࡵࡶࡁࠧ࡬ࡢࡤ࠯࡬ࡱࡦ࡭ࡥࡴࡧ࡯ࡩࡨࡺ࠭࡮ࡧࡶࡷࡦ࡭ࡥ࠮ࡶࡨࡼࡹࠨ࡛࡟ࡀࡠ࠮ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡲࡡࡣࡧ࡯ࡂࠬ॔"), mMQ3FkNVa4IlxqY)
		if not message: message = trdVA0JvFaD.findall(o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠩ࠿ࡨ࡮ࡼ࡛࡟ࡀࡠ࠯ࡨࡲࡡࡴࡵࡀࠦ࡫ࡨࡣ࠮࡫ࡰࡥ࡬࡫ࡳࡦ࡮ࡨࡧࡹ࠳࡭ࡦࡵࡶࡥ࡬࡫࠭ࡦࡴࡵࡳࡷࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬॕ"), mMQ3FkNVa4IlxqY)
		if not message:
			vanQT4j5Z8SfO2MHg19I = trdVA0JvFaD.findall(LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠪࡶࡪࡧࡤࡰࡰ࡯ࡽࡃ࠮࠮ࠫࡁࠬࡀࠬॖ"), mMQ3FkNVa4IlxqY)[ybdv7XcT3lxF6QezULwCAGk]
			break
		else:
			message = message[ybdv7XcT3lxF6QezULwCAGk]
			l17Sn3hK59WV = l17Sn3hK59WV[ybdv7XcT3lxF6QezULwCAGk]
		SQXobi74LEZFeNIOyWlf = trdVA0JvFaD.findall(sULh4NjakzI8He7xJCMGrql(u"ࡶࠬࡴࡡ࡮ࡧࡀࠦࡨࠨ࡜ࡴ࠭ࡹࡥࡱࡻࡥ࠾ࠤࠫ࡟ࡣࠨ࡝ࠬࠫࠪॗ"), mMQ3FkNVa4IlxqY)[ybdv7XcT3lxF6QezULwCAGk]
		YHuo19pPh0Vn8N = DJ1ICpbyR2(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱࡫ࡴࡵࡧ࡭ࡧ࠱ࡧࡴࡳࠥࡴࠩक़") % (l17Sn3hK59WV.replace(LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"࠭ࠦࡢ࡯ࡳ࠿ࠬख़"), A6dMB1FlgxVivJ2fk9C(u"ࠧࠧࠩग़")))
		message = trdVA0JvFaD.sub(S1SgCFYGJeMvfp5iZXK(u"ࠨ࠾࠲ࡃ࠭ࡪࡩࡷࡾࡶࡸࡷࡵ࡮ࡨࠫ࡞ࡢࡃࡣࠪ࠿ࠩज़"), hWGMqtBy4wuLaVcj, message)
		NNH4YMr5FSTWnlJIyEea = zUNhcGo17C3bgLBP5(captcha=YHuo19pPh0Vn8N, msg=message, iteration=iteration)
		CeDRHcyGfM = NNH4YMr5FSTWnlJIyEea.get()
		if not CeDRHcyGfM: break
		data = {CnbBKmtF1x84q7AW(u"ࠩࡦࠫड़"): SQXobi74LEZFeNIOyWlf, sULh4NjakzI8He7xJCMGrql(u"ࠪࡶࡪࡹࡰࡰࡰࡶࡩࠬढ़"): CeDRHcyGfM}
		sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(DpQifS0oKBI1hYcO,QVDJLRlxNg127jMX(u"ࠫࡕࡕࡓࡕࠩफ़"),hfYAGosI7dPmn2BFWOw5,data,headers,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡉࡈࡘࡤࡘࡅࡄࡃࡓࡘࡈࡎࡁ࠳ࡡࡗࡓࡐࡋࡎ࠮࠴ࡱࡨࠬय़"))
	return vanQT4j5Z8SfO2MHg19I
def uIAKOzb0e72B(url):
	mMQ3FkNVa4IlxqY = f1fLNcPlo2ECKtiBeug0OAvz9YM(nHBb7jXk0Daom,url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡖࡆࡈࡌࡐࡃࡇࡗ࠲࠷ࡳࡵࠩॠ"))
	items = trdVA0JvFaD.findall(S1SgCFYGJeMvfp5iZXK(u"ࠧࡤࡱ࡯ࡳࡷࡃࠢࡳࡧࡧࠦࡃ࠮࠮ࠫࡁࠬࡀࠬॡ"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if items: return hWGMqtBy4wuLaVcj,[hWGMqtBy4wuLaVcj],[ items[ybdv7XcT3lxF6QezULwCAGk] ]
	else: return sULh4NjakzI8He7xJCMGrql(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡅࡗࡇࡂࡍࡑࡄࡈࡘ࠭ॢ"),[],[]
def Nresvop5RwfCGUl(url):
	return hWGMqtBy4wuLaVcj,[hWGMqtBy4wuLaVcj],[url]
def qGMsxAw7VicurR(url):
	SODQ7qlNYoZcFK8e50rBsJaAHxiXjE = url.split(dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠩ࠲ࠫॣ"))
	nkMpZ1HvWzTdgAXfQ = ITvnUAMXsyb4eO(u"ࠪ࠳ࠬ।").join(SODQ7qlNYoZcFK8e50rBsJaAHxiXjE[ybdv7XcT3lxF6QezULwCAGk:x1x9kIQo3zjZWnYaiy])
	mMQ3FkNVa4IlxqY = f1fLNcPlo2ECKtiBeug0OAvz9YM(nHBb7jXk0Daom,url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,A6dMB1FlgxVivJ2fk9C(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࡛࠭ࡋࡓࡔ࡞࡙ࡈࡂࡔࡈ࠱࠶ࡹࡴࠨ॥"))
	items = trdVA0JvFaD.findall(jeAby54c02TgG8zuivonX91(u"ࠬࡪ࡬ࡣࡷࡷࡸࡴࡴ࡜ࠨ࡞ࠬ࠲࡭ࡸࡥࡧࠢࡀࠤࠧ࠮࠮ࠫࡁࠬࠦࠥࡢࠫࠡ࡞ࠫࠬ࠳࠰࠿ࠪࠢ࡟ࠩࠥ࠮࠮ࠫࡁࠬࠤࡡ࠱ࠠࠩ࠰࠭ࡃ࠮ࠦ࡜ࠦࠢࠫ࠲࠯ࡅࠩ࡝ࠫࠣࡠ࠰ࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠧ०"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if items:
		YsBnON28Tejx,pARESJKOk24UZCY5rQ8m,v1BqXOZrNQsn8Wp05VMRT,EfLHiJ0d5uwqYm69rKo,Z5xgTlLS7G3tHmRkrbWVQYjf8IJoCu,ddcPxvaRm4WkUoIeFGuBjXwtqZnr = items[ybdv7XcT3lxF6QezULwCAGk]
		glBvuIRTJseUHjari = int(pARESJKOk24UZCY5rQ8m) % int(v1BqXOZrNQsn8Wp05VMRT) + int(EfLHiJ0d5uwqYm69rKo) % int(Z5xgTlLS7G3tHmRkrbWVQYjf8IJoCu)
		url = nkMpZ1HvWzTdgAXfQ + YsBnON28Tejx + str(glBvuIRTJseUHjari) + ddcPxvaRm4WkUoIeFGuBjXwtqZnr
		return hWGMqtBy4wuLaVcj,[hWGMqtBy4wuLaVcj],[url]
	else: return QVDJLRlxNg127jMX(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡ࡜ࡌࡔࡕ࡟ࡓࡉࡃࡕࡉࠬ१"),[],[]
def lRND01gkpxPG(url):
	id = url.split(HHoGx7Flus60(u"ࠧ࠰ࠩ२"))[-bXukYxQ4aHw]
	headers = { NeO3CTLHrPfWUoIgy8Q(u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ३") : SqrG5mU3j96ldsFpExobw40TJY(u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤࠨ४") }
	l17Sn3hK59WV = { FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠥ࡭ࡩࠨ५"):id , LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠦࡴࡶࠢ६"):DJ1ICpbyR2(u"ࠧࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠲ࠣ७") }
	s4mUPzjv1bRoNTMdenkuBgYl = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(nHBb7jXk0Daom,QvgnCALNstmuUJiET(u"࠭ࡐࡐࡕࡗࠫ८"), url, l17Sn3hK59WV, headers, hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,SqrG5mU3j96ldsFpExobw40TJY(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡑࡕ࠺ࡕࡑࡎࡒࡅࡉ࠳࠱ࡴࡶࠪ९"))
	if CnbBKmtF1x84q7AW(u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ॰") in list(s4mUPzjv1bRoNTMdenkuBgYl.headers.keys()): llxFwq0CUNgQtivJzkHeGV = s4mUPzjv1bRoNTMdenkuBgYl.headers[SqrG5mU3j96ldsFpExobw40TJY(u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫॱ")]
	else: llxFwq0CUNgQtivJzkHeGV = url
	if llxFwq0CUNgQtivJzkHeGV: return hWGMqtBy4wuLaVcj,[hWGMqtBy4wuLaVcj],[llxFwq0CUNgQtivJzkHeGV]
	else: return LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡓࡐ࠵ࡗࡓࡐࡔࡇࡄࠨॲ"),[],[]
def QMXcNAHpludz3x(url):
	mMQ3FkNVa4IlxqY = f1fLNcPlo2ECKtiBeug0OAvz9YM(nHBb7jXk0Daom,url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,sULh4NjakzI8He7xJCMGrql(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡘࡋࡑࡘ࡛ࡒࡉࡗࡇ࠰࠵ࡸࡺࠧॳ"))
	items = trdVA0JvFaD.findall(HHoGx7Flus60(u"ࠬࡳࡰ࠵࠼ࠣࡠࡠࡢࠧࠩ࠰࠭ࡃ࠮ࡢࠧࠨॴ"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if items: return hWGMqtBy4wuLaVcj,[hWGMqtBy4wuLaVcj],[ items[ybdv7XcT3lxF6QezULwCAGk] ]
	else: return HHoGx7Flus60(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤ࡙ࠡࡌࡒ࡙࡜ࡌࡊࡘࡈࠫॵ"),[],[]
def ujQMRfKe6hP1mOdX2iCHJ(url):
	mMQ3FkNVa4IlxqY = f1fLNcPlo2ECKtiBeug0OAvz9YM(nHBb7jXk0Daom,url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡗࡉࡈࡊࡘࡈ࠱࠶ࡹࡴࠨॶ"))
	items = trdVA0JvFaD.findall(FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠨࡵࡲࡹࡷࡩࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ॷ"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if items:
		url = url = jeAby54c02TgG8zuivonX91(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡷࡩࡨࡪࡸࡨ࠲ࡴࡸࡧࠨॸ") + items[ybdv7XcT3lxF6QezULwCAGk]
		return hWGMqtBy4wuLaVcj,[hWGMqtBy4wuLaVcj],[ url ]
	else: return NeO3CTLHrPfWUoIgy8Q(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡇࡒࡄࡊࡌ࡚ࡊ࠭ॹ"),[],[]
def XehEMSYomUdDp(url):
	mMQ3FkNVa4IlxqY = f1fLNcPlo2ECKtiBeug0OAvz9YM(nHBb7jXk0Daom,url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,NeO3CTLHrPfWUoIgy8Q(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆࡕࡗࡖࡊࡇࡍ࠮࠳ࡶࡸࠬॺ"))
	items = trdVA0JvFaD.findall(SqrG5mU3j96ldsFpExobw40TJY(u"ࠬࡼࡩࡥࡧࡲࠤࡵࡸࡥ࡭ࡱࡤࡨ࠳࠰࠿ࡴࡴࡦࡁ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬॻ"),mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if items: return hWGMqtBy4wuLaVcj,[hWGMqtBy4wuLaVcj],[ items[ybdv7XcT3lxF6QezULwCAGk] ]
	else: return KBkxSYaz93pu1(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡇࡖࡘࡗࡋࡁࡎࠩॼ"),[],[]
# -*- coding: utf-8 -*-
from yoY3NdGViS import *
headers = { 'User-Agent' : hWGMqtBy4wuLaVcj }
xjPuFK3EsIZSiobQ5X = 'AKOAMCAM'
n0qFKQWhiBYXoTrvejVHUA4 = '_AKC_'
Str0BupDTFA = u6rbxnyjTl7I[xjPuFK3EsIZSiobQ5X][0]
P3UK1Rr4IdYe5 = ['مصارعة']
def ehB18u9sQFRi(mode,url,text):
	if   mode==350: N6NCYivtV4I5rEXq = DP6FSBgNdX1rsvVR()
	elif mode==351: N6NCYivtV4I5rEXq = wg5aF3e8rcDh7SGpW6M1OPnkU(url,text)
	elif mode==352: N6NCYivtV4I5rEXq = GrsxUhb0PEXj2FQRAkD4q(url)
	elif mode==353: N6NCYivtV4I5rEXq = oanus6TxUFNAhSZKpJdYlEC4mV(url)
	elif mode==354: N6NCYivtV4I5rEXq = hadMgR0nOKHoGqpA(url,'FILTERS___'+text)
	elif mode==355: N6NCYivtV4I5rEXq = hadMgR0nOKHoGqpA(url,'CATEGORIES___'+text)
	elif mode==356: N6NCYivtV4I5rEXq = Ko1cGYIDOe3rxMuqEl(url)
	elif mode==357: N6NCYivtV4I5rEXq = gu3WMCiNLv8Fst7R(url)
	elif mode==359: N6NCYivtV4I5rEXq = lPwaAjFTMG4n7iSLkXcEuK0Zm(text)
	else: N6NCYivtV4I5rEXq = False
	return N6NCYivtV4I5rEXq
def DP6FSBgNdX1rsvVR():
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',n0qFKQWhiBYXoTrvejVHUA4+soMVfbr6WtpNlcSA+'هذا الموقع مغلق'+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,8)
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'بحث في الموقع',hWGMqtBy4wuLaVcj,359,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'_REMEMBERRESULTS_')
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'فلتر محدد',Str0BupDTFA,356)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'فلتر كامل',Str0BupDTFA,357)
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	mMQ3FkNVa4IlxqY = f1fLNcPlo2ECKtiBeug0OAvz9YM(KqO5BWGQR9JVL,Str0BupDTFA,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,'AKOAMCAM-MENU-1st')
	NPM3HKQ57xe = trdVA0JvFaD.findall('recently-container.*?href="(.*?)"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if NPM3HKQ57xe: NPM3HKQ57xe = NPM3HKQ57xe[0]
	else: NPM3HKQ57xe = Str0BupDTFA
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+'اضيف حديثا',NPM3HKQ57xe,351)
	NPM3HKQ57xe = trdVA0JvFaD.findall('@id":"(.*?)"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if NPM3HKQ57xe: NPM3HKQ57xe = NPM3HKQ57xe[0]
	else: NPM3HKQ57xe = Str0BupDTFA
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+'المميزة',NPM3HKQ57xe,351,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'featured')
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('main-categories-list(.*?)main-categories-list',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('href="(.*?)".*?class="font.*?>(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,title in items:
			if title not in P3UK1Rr4IdYe5: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,351)
		RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('class="categories-box(.*?)<footer',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('href="(.*?)".*?">(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,title in items:
			llxFwq0CUNgQtivJzkHeGV = LNtIDdBA52P(llxFwq0CUNgQtivJzkHeGV)
			if title not in P3UK1Rr4IdYe5: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,351)
	return mMQ3FkNVa4IlxqY
def Ko1cGYIDOe3rxMuqEl(website=hWGMqtBy4wuLaVcj):
	mMQ3FkNVa4IlxqY = f1fLNcPlo2ECKtiBeug0OAvz9YM(DpQifS0oKBI1hYcO,Str0BupDTFA,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,'AKOAMCAM-MENU-1st')
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('class="menu(.*?)<nav',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('href="(.*?)".*?text">(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,title in items:
			if title not in P3UK1Rr4IdYe5:
				title = title+' مصنفة'
				RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,355)
		if website==hWGMqtBy4wuLaVcj: RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	return mMQ3FkNVa4IlxqY
def gu3WMCiNLv8Fst7R(website=hWGMqtBy4wuLaVcj):
	mMQ3FkNVa4IlxqY = f1fLNcPlo2ECKtiBeug0OAvz9YM(DpQifS0oKBI1hYcO,Str0BupDTFA,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,'AKOAMCAM-MENU-1st')
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('class="menu(.*?)<nav',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('href="(.*?)".*?text">(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,title in items:
			if title not in P3UK1Rr4IdYe5:
				title = title+' مفلترة'
				RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,354)
		if website==hWGMqtBy4wuLaVcj: RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	return mMQ3FkNVa4IlxqY
def wg5aF3e8rcDh7SGpW6M1OPnkU(url,type=hWGMqtBy4wuLaVcj):
	mMQ3FkNVa4IlxqY = f1fLNcPlo2ECKtiBeug0OAvz9YM(lke5D6CpaAXPdEZyrBSw7T,url,hWGMqtBy4wuLaVcj,headers,True,'AKOAMCAM-TITLES-1st')
	if type=='featured': DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('swiper-container(.*?)swiper-button-prev',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	else: DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('class="container"(.*?)main-footer',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('xlink:href="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		REbVyXis1w4Ae = []
		for Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,llxFwq0CUNgQtivJzkHeGV,title in items:
			title = LNtIDdBA52P(title)
			if 'الحلقة' in title or 'الحلقه' in title:
				IIsmGy4pd7 = trdVA0JvFaD.findall('(.*?) (الحلقة|الحلقه) \d+',title,trdVA0JvFaD.DOTALL)
				if IIsmGy4pd7:
					title = '_MOD_' + IIsmGy4pd7[0][0]
					if title not in REbVyXis1w4Ae:
						RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,352,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
						REbVyXis1w4Ae.append(title)
			elif 'مسلسل' in title:
				RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,352,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
			else: RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,353,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('pagination(.*?)</div>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('href=["\'](.*?)["\'].*?>(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,title in items:
			llxFwq0CUNgQtivJzkHeGV = LNtIDdBA52P(llxFwq0CUNgQtivJzkHeGV)
			title = LNtIDdBA52P(title)
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'صفحة '+title,llxFwq0CUNgQtivJzkHeGV,351)
	return
def lPwaAjFTMG4n7iSLkXcEuK0Zm(search):
	search,vvKf4sXgZIMyEJPuC,showDialogs = IVTEJQOiMR2dYta9C(search)
	if search==hWGMqtBy4wuLaVcj: search = TrzfUidpv1LyAYqwexHJDuS()
	if search==hWGMqtBy4wuLaVcj: return
	lKqyOtIAvVY = search.replace(Mpsm2VF1OBnCRvK3qf6,'+')
	url = Str0BupDTFA + '/?s='+lKqyOtIAvVY
	N6NCYivtV4I5rEXq = wg5aF3e8rcDh7SGpW6M1OPnkU(url)
	return
def GrsxUhb0PEXj2FQRAkD4q(url):
	mMQ3FkNVa4IlxqY = f1fLNcPlo2ECKtiBeug0OAvz9YM(KqO5BWGQR9JVL,url,hWGMqtBy4wuLaVcj,headers,True,'AKOAMCAM-EPISODES-1st')
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('text-white">الحلقات(.*?)<header',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		aTjkFVusW1c35G8v = trdVA0JvFaD.findall('href="(http.*?)".*?src="(.*?)".*?alt="(.*?)"',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,title in aTjkFVusW1c35G8v:
			if 'الحلقة' in title or 'الحلقه' in title: RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,353,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
	else:
		Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG = MMk8qKvcJe4fQHm3EG7diBD5.getInfoLabel('ListItem.Icon')
		if mMQ3FkNVa4IlxqY.count('<title>')>1: title = trdVA0JvFaD.findall('<title>(.*?)<',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)[1]
		else: title = 'رابط التشغيل'
		RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,url,353,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
	return
def oanus6TxUFNAhSZKpJdYlEC4mV(url):
	Dvi8asSrQYX5wE3KMIxT91me,haq1bHZINPE58uoBFnKfTSO2ik4 = [],[]
	XYnvGQuZ1x3AJd7bICOzWaR5cVsH = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(DpQifS0oKBI1hYcO,'GET',url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'AKOAMCAM-PLAY-1st')
	mMQ3FkNVa4IlxqY = XYnvGQuZ1x3AJd7bICOzWaR5cVsH.content
	TsFgQdloabE4YpPWV = trdVA0JvFaD.findall('post_id=(.*?)"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if TsFgQdloabE4YpPWV:
		TsFgQdloabE4YpPWV = TsFgQdloabE4YpPWV[0]
		headers = {'User-Agent':hWGMqtBy4wuLaVcj,'Content-Type':'application/x-www-form-urlencoded'}
		data = {'post_id':TsFgQdloabE4YpPWV}
		NPM3HKQ57xe = Str0BupDTFA+'/wp-content/themes/aflam8kkk/Inc/Ajax/Single/Watch.php'
		OiGwUvjTP4ZDseWx3quIobhXYcVB = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(DpQifS0oKBI1hYcO,'POST',NPM3HKQ57xe,data,headers,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'AKOAMCAM-PLAY-1st')
		eecmFXt5SRyCjGpx = OiGwUvjTP4ZDseWx3quIobhXYcVB.content
		items = trdVA0JvFaD.findall('data-server="(.*?)".*?class="text">(.*?)<',eecmFXt5SRyCjGpx,trdVA0JvFaD.DOTALL)
		for AQFhw7Rmi9IJUoX,name in items:
			llxFwq0CUNgQtivJzkHeGV = 'https://w.akoam.cam/wp-content/themes/aflam8kkk/Inc/Ajax/Single/Server.php'
			llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV+'?postid='+TsFgQdloabE4YpPWV+'&serverid='+AQFhw7Rmi9IJUoX+'?named='+name+'__watch'
			Dvi8asSrQYX5wE3KMIxT91me.append(llxFwq0CUNgQtivJzkHeGV)
			haq1bHZINPE58uoBFnKfTSO2ik4.append(name)
		NPM3HKQ57xe = Str0BupDTFA+'/wp-content/themes/aflam8kkk/Inc/Ajax/Single/Download.php'
		OiGwUvjTP4ZDseWx3quIobhXYcVB = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(DpQifS0oKBI1hYcO,'POST',NPM3HKQ57xe,data,headers,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'AKOAMCAM-PLAY-1st')
		eecmFXt5SRyCjGpx = OiGwUvjTP4ZDseWx3quIobhXYcVB.content
		items = trdVA0JvFaD.findall('href="(.*?)".*?class="text">(.*?)<',eecmFXt5SRyCjGpx,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,title in items:
			llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV.strip(Mpsm2VF1OBnCRvK3qf6)
			llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV+'?named='+title+'__download'
			Dvi8asSrQYX5wE3KMIxT91me.append(llxFwq0CUNgQtivJzkHeGV)
			haq1bHZINPE58uoBFnKfTSO2ik4.append(title)
	import oosSOfvdEQ
	oosSOfvdEQ.zfdYjsGLg8M6i15qZWh(Dvi8asSrQYX5wE3KMIxT91me,xjPuFK3EsIZSiobQ5X,'video',url)
	return
def hadMgR0nOKHoGqpA(url,filter):
	uEwaiBFX1Hr5 = ['cat','genre','release-year','quality','orderby']
	if '?' in url: url = url.split('?')[0]
	type,filter = filter.split('___',1)
	if filter==hWGMqtBy4wuLaVcj: RJGtCsyDgi0X,kYI6n5bUD83Z = hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj
	else: RJGtCsyDgi0X,kYI6n5bUD83Z = filter.split('___')
	if type=='CATEGORIES':
		if uEwaiBFX1Hr5[0]+'=' not in RJGtCsyDgi0X: OJx4sYA9nNbtPT5ezmDHdVBk2C7 = uEwaiBFX1Hr5[0]
		for PPuqrvDLEViYOMf1dmkK7 in range(len(uEwaiBFX1Hr5[0:-1])):
			if uEwaiBFX1Hr5[PPuqrvDLEViYOMf1dmkK7]+'=' in RJGtCsyDgi0X: OJx4sYA9nNbtPT5ezmDHdVBk2C7 = uEwaiBFX1Hr5[PPuqrvDLEViYOMf1dmkK7+1]
		nnqvmxlXub3iVDM = RJGtCsyDgi0X+'&'+OJx4sYA9nNbtPT5ezmDHdVBk2C7+'=0'
		tuYnONZ6GaCecv4TErUHMdBX2DIb8K = kYI6n5bUD83Z+'&'+OJx4sYA9nNbtPT5ezmDHdVBk2C7+'=0'
		BvO3oKUrHNCwVm791b80sZg = nnqvmxlXub3iVDM.strip('&')+'___'+tuYnONZ6GaCecv4TErUHMdBX2DIb8K.strip('&')
		PPlq1nxLf6CamuBI0psW = kKWuMB69mcOHPn3XilFdvp(kYI6n5bUD83Z,'all')
		NPM3HKQ57xe = url+'?'+PPlq1nxLf6CamuBI0psW
	elif type=='FILTERS':
		I2OnWkrPaVbwBSHiYR3LZ = kKWuMB69mcOHPn3XilFdvp(RJGtCsyDgi0X,'modified_values')
		I2OnWkrPaVbwBSHiYR3LZ = jkiCS0UWs2dNAJcGKn6mbHD(I2OnWkrPaVbwBSHiYR3LZ)
		if kYI6n5bUD83Z!=hWGMqtBy4wuLaVcj: kYI6n5bUD83Z = kKWuMB69mcOHPn3XilFdvp(kYI6n5bUD83Z,'all')
		if kYI6n5bUD83Z==hWGMqtBy4wuLaVcj: NPM3HKQ57xe = url
		else: NPM3HKQ57xe = url+'?'+kYI6n5bUD83Z
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'أظهار قائمة الفيديو التي تم اختيارها',NPM3HKQ57xe,351,hWGMqtBy4wuLaVcj,'1')
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+' [[   '+I2OnWkrPaVbwBSHiYR3LZ+'   ]]',NPM3HKQ57xe,351,hWGMqtBy4wuLaVcj,'1')
		RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	mMQ3FkNVa4IlxqY = f1fLNcPlo2ECKtiBeug0OAvz9YM(DpQifS0oKBI1hYcO,url,hWGMqtBy4wuLaVcj,headers,True,'AKOAMCAM-FILTERS_MENU-1st')
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('<form id(.*?)</form>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
	f5rVHP4bmCd7cqvuYEQJlnLTk6yGRS = trdVA0JvFaD.findall('<select.*?name="(.*?)".*?">(.*?)<(.*?)</select>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	dict = {}
	for bksErtC1hwcVqlfyM82AnD,name,cok5ZGXdQP7YhwtqyuaCnVevm6UB in f5rVHP4bmCd7cqvuYEQJlnLTk6yGRS:
		items = trdVA0JvFaD.findall('<option(.*?)>(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		if '=' not in NPM3HKQ57xe: NPM3HKQ57xe = url
		if type=='CATEGORIES':
			if OJx4sYA9nNbtPT5ezmDHdVBk2C7!=bksErtC1hwcVqlfyM82AnD: continue
			elif len(items)<=1:
				if bksErtC1hwcVqlfyM82AnD==uEwaiBFX1Hr5[-1]: wg5aF3e8rcDh7SGpW6M1OPnkU(NPM3HKQ57xe)
				else: hadMgR0nOKHoGqpA(NPM3HKQ57xe,'CATEGORIES___'+BvO3oKUrHNCwVm791b80sZg)
				return
			else:
				if bksErtC1hwcVqlfyM82AnD==uEwaiBFX1Hr5[-1]: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'الجميع',NPM3HKQ57xe,351,hWGMqtBy4wuLaVcj,'1')
				else: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'الجميع',NPM3HKQ57xe,355,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,BvO3oKUrHNCwVm791b80sZg)
		elif type=='FILTERS':
			nnqvmxlXub3iVDM = RJGtCsyDgi0X+'&'+bksErtC1hwcVqlfyM82AnD+'=0'
			tuYnONZ6GaCecv4TErUHMdBX2DIb8K = kYI6n5bUD83Z+'&'+bksErtC1hwcVqlfyM82AnD+'=0'
			BvO3oKUrHNCwVm791b80sZg = nnqvmxlXub3iVDM+'___'+tuYnONZ6GaCecv4TErUHMdBX2DIb8K
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'الجميع : '+name,NPM3HKQ57xe,354,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,BvO3oKUrHNCwVm791b80sZg)
		dict[bksErtC1hwcVqlfyM82AnD] = {}
		for BoSjXKxz41DcneO9UimClE,PBo1KkyMCgH8eNDaLtZVcr3EnIi2 in items:
			if PBo1KkyMCgH8eNDaLtZVcr3EnIi2 in P3UK1Rr4IdYe5: continue
			if 'value' not in BoSjXKxz41DcneO9UimClE: BoSjXKxz41DcneO9UimClE = PBo1KkyMCgH8eNDaLtZVcr3EnIi2
			else: BoSjXKxz41DcneO9UimClE = trdVA0JvFaD.findall('"(.*?)"',BoSjXKxz41DcneO9UimClE,trdVA0JvFaD.DOTALL)[0]
			dict[bksErtC1hwcVqlfyM82AnD][BoSjXKxz41DcneO9UimClE] = PBo1KkyMCgH8eNDaLtZVcr3EnIi2
			nnqvmxlXub3iVDM = RJGtCsyDgi0X+'&'+bksErtC1hwcVqlfyM82AnD+'='+PBo1KkyMCgH8eNDaLtZVcr3EnIi2
			tuYnONZ6GaCecv4TErUHMdBX2DIb8K = kYI6n5bUD83Z+'&'+bksErtC1hwcVqlfyM82AnD+'='+BoSjXKxz41DcneO9UimClE
			S80DwNWuMTZx4El = nnqvmxlXub3iVDM+'___'+tuYnONZ6GaCecv4TErUHMdBX2DIb8K
			title = PBo1KkyMCgH8eNDaLtZVcr3EnIi2+' : '#+dict[bksErtC1hwcVqlfyM82AnD]['0']
			title = PBo1KkyMCgH8eNDaLtZVcr3EnIi2+' : '+name
			if type=='FILTERS': RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,url,354,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,S80DwNWuMTZx4El)
			elif type=='CATEGORIES' and uEwaiBFX1Hr5[-2]+'=' in RJGtCsyDgi0X:
				PPlq1nxLf6CamuBI0psW = kKWuMB69mcOHPn3XilFdvp(tuYnONZ6GaCecv4TErUHMdBX2DIb8K,'all')
				CMzQFXeI08KDwAJ9p = url+'?'+PPlq1nxLf6CamuBI0psW
				RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,CMzQFXeI08KDwAJ9p,351,hWGMqtBy4wuLaVcj,'1')
			else: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,url,355,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,S80DwNWuMTZx4El)
	return
def kKWuMB69mcOHPn3XilFdvp(UGewLrVFhBCo7MdZ8KEaJWXgYp,mode):
	UGewLrVFhBCo7MdZ8KEaJWXgYp = UGewLrVFhBCo7MdZ8KEaJWXgYp.strip('&')
	ONVGLC8DSp4 = {}
	if '=' in UGewLrVFhBCo7MdZ8KEaJWXgYp:
		items = UGewLrVFhBCo7MdZ8KEaJWXgYp.split('&')
		for ImYg2jxU6Lc9Q1C4Oko in items:
			glBvuIRTJseUHjari,BoSjXKxz41DcneO9UimClE = ImYg2jxU6Lc9Q1C4Oko.split('=')
			ONVGLC8DSp4[glBvuIRTJseUHjari] = BoSjXKxz41DcneO9UimClE
	mJuhvt0RPAbBMSla = hWGMqtBy4wuLaVcj
	MM02bgXexGhSpwQtlILydi1KJCOFz = ['cat','genre','release-year','quality','orderby']
	for key in MM02bgXexGhSpwQtlILydi1KJCOFz:
		if key in list(ONVGLC8DSp4.keys()): BoSjXKxz41DcneO9UimClE = ONVGLC8DSp4[key]
		else: BoSjXKxz41DcneO9UimClE = '0'
		if mode=='modified_values' and BoSjXKxz41DcneO9UimClE!='0': mJuhvt0RPAbBMSla = mJuhvt0RPAbBMSla+' + '+BoSjXKxz41DcneO9UimClE
		elif mode=='modified_filters' and BoSjXKxz41DcneO9UimClE!='0': mJuhvt0RPAbBMSla = mJuhvt0RPAbBMSla+'&'+key+'='+BoSjXKxz41DcneO9UimClE
		elif mode=='all': mJuhvt0RPAbBMSla = mJuhvt0RPAbBMSla+'&'+key+'='+BoSjXKxz41DcneO9UimClE
	mJuhvt0RPAbBMSla = mJuhvt0RPAbBMSla.strip(' + ')
	mJuhvt0RPAbBMSla = mJuhvt0RPAbBMSla.strip('&')
	return mJuhvt0RPAbBMSla
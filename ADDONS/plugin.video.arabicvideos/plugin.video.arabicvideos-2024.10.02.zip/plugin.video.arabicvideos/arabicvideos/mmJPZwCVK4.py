# -*- coding: utf-8 -*-
from yoY3NdGViS import *
xjPuFK3EsIZSiobQ5X = 'SHOOFMAX'
n0qFKQWhiBYXoTrvejVHUA4 = '_SHM_'
Str0BupDTFA = u6rbxnyjTl7I[xjPuFK3EsIZSiobQ5X][0]
Mr9c3QFRbp4wm = u6rbxnyjTl7I[xjPuFK3EsIZSiobQ5X][1]
ffhsAbn5tdVj8mk3cviY9aXlQJGyP = u6rbxnyjTl7I[xjPuFK3EsIZSiobQ5X][2]
def ehB18u9sQFRi(mode,url,text):
	if   mode==50: N6NCYivtV4I5rEXq = DP6FSBgNdX1rsvVR()
	elif mode==51: N6NCYivtV4I5rEXq = wg5aF3e8rcDh7SGpW6M1OPnkU(url)
	elif mode==52: N6NCYivtV4I5rEXq = GrsxUhb0PEXj2FQRAkD4q(url)
	elif mode==53: N6NCYivtV4I5rEXq = oanus6TxUFNAhSZKpJdYlEC4mV(url)
	elif mode==55: N6NCYivtV4I5rEXq = Hv7GLrq9VX1()
	elif mode==56: N6NCYivtV4I5rEXq = NNc9kIntVF()
	elif mode==57: N6NCYivtV4I5rEXq = RRTmBF6iZyzUL(url,1)
	elif mode==58: N6NCYivtV4I5rEXq = RRTmBF6iZyzUL(url,2)
	elif mode==59: N6NCYivtV4I5rEXq = lPwaAjFTMG4n7iSLkXcEuK0Zm(text)
	else: N6NCYivtV4I5rEXq = False
	return N6NCYivtV4I5rEXq
def DP6FSBgNdX1rsvVR():
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'بحث في الموقع',hWGMqtBy4wuLaVcj,59,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'_REMEMBERRESULTS_')
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+'المسلسلات',hWGMqtBy4wuLaVcj,56)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+'الافلام',hWGMqtBy4wuLaVcj,55)
	return hWGMqtBy4wuLaVcj
def Hv7GLrq9VX1():
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'أفلام مرتبة بسنة الإنتاج',Str0BupDTFA+'/movie/1/yop',57)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'أفلام مرتبة بالأفضل تقييم',Str0BupDTFA+'/movie/1/review',57)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'أفلام مرتبة بالأكثر مشاهدة',Str0BupDTFA+'/movie/1/views',57)
	return
def NNc9kIntVF():
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'مسلسلات مرتبة بسنة الإنتاج',Str0BupDTFA+'/series/1/yop',57)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'مسلسلات مرتبة بالأفضل تقييم',Str0BupDTFA+'/series/1/review',57)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'مسلسلات مرتبة بالأكثر مشاهدة',Str0BupDTFA+'/series/1/views',57)
	return
def wg5aF3e8rcDh7SGpW6M1OPnkU(url):
	if '?' in url:
		LLsGB1FPiUTyYrdwqf86eHAnQ = url.split('?')
		url = LLsGB1FPiUTyYrdwqf86eHAnQ[0]
		filter = '?' + e1mT8H4dGS3XFyx0KLUA9(LLsGB1FPiUTyYrdwqf86eHAnQ[1],'=&:/%')
	else: filter = hWGMqtBy4wuLaVcj
	type,l7COkhRWD9uVS60Pte2NoyAaZn,sort = url.split('/')[-3:]
	if sort in ['yop','review','views']:
		if type=='movie': soOEufUrRzPXyT9mLZq='فيلم'
		elif type=='series': soOEufUrRzPXyT9mLZq='مسلسل'
		url = Str0BupDTFA + '/genre/filter/' + e1mT8H4dGS3XFyx0KLUA9(soOEufUrRzPXyT9mLZq) + '/' + l7COkhRWD9uVS60Pte2NoyAaZn + '/' + sort + filter
		mMQ3FkNVa4IlxqY = f1fLNcPlo2ECKtiBeug0OAvz9YM(KqO5BWGQR9JVL,url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'SHOOFMAX-TITLES-1st')
		items = trdVA0JvFaD.findall('"pid":(.*?),.*?"ptitle":"(.*?)".+?"pepisodes":(.*?),"presbase":"(.*?)"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		Y1m3TWw9RzglxPnktu2LvUa=0
		for id,title,cMI7BFzNCugRGJ2Xwf3VQPEqm9pKlW,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG in items:
			Y1m3TWw9RzglxPnktu2LvUa += 1
			Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG = ffhsAbn5tdVj8mk3cviY9aXlQJGyP + '/v2/img/program/main/' + Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG + '-2.jpg'
			llxFwq0CUNgQtivJzkHeGV = Str0BupDTFA + '/program/' + id
			if type=='movie': RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,53,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
			if type=='series': RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'مسلسل '+title,llxFwq0CUNgQtivJzkHeGV+'?ep='+cMI7BFzNCugRGJ2Xwf3VQPEqm9pKlW+'='+title+'='+Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,52,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
	else:
		if type=='movie': soOEufUrRzPXyT9mLZq='movies'
		elif type=='series': soOEufUrRzPXyT9mLZq='series'
		url = Mr9c3QFRbp4wm + '/json/selected/' + sort + '-' + soOEufUrRzPXyT9mLZq + '-WW.json'
		mMQ3FkNVa4IlxqY = f1fLNcPlo2ECKtiBeug0OAvz9YM(KqO5BWGQR9JVL,url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'SHOOFMAX-TITLES-2nd')
		items = trdVA0JvFaD.findall('"ref":(.*?),"ep":(.*?),"base":"(.*?)","title":"(.*?)"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		Y1m3TWw9RzglxPnktu2LvUa=0
		for id,cMI7BFzNCugRGJ2Xwf3VQPEqm9pKlW,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,title in items:
			Y1m3TWw9RzglxPnktu2LvUa += 1
			Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG = Mr9c3QFRbp4wm + '/img/program/' + Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG + '-2.jpg'
			llxFwq0CUNgQtivJzkHeGV = Str0BupDTFA + '/program/' + id
			if type=='movie': RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,53,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
			elif type=='series': RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'مسلسل '+title,llxFwq0CUNgQtivJzkHeGV+'?ep='+cMI7BFzNCugRGJ2Xwf3VQPEqm9pKlW+'='+title+'='+Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,52,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
	title='صفحة '
	if Y1m3TWw9RzglxPnktu2LvUa==16:
		for Q1QfyowWJu04FgzMZjIG7rS9 in range(1,13) :
			if not l7COkhRWD9uVS60Pte2NoyAaZn==str(Q1QfyowWJu04FgzMZjIG7rS9):
				url = Str0BupDTFA+'/genre/filter/'+type+'/'+str(Q1QfyowWJu04FgzMZjIG7rS9)+'/'+sort+filter
				RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title+str(Q1QfyowWJu04FgzMZjIG7rS9),url,51)
	return
def GrsxUhb0PEXj2FQRAkD4q(url):
	LLsGB1FPiUTyYrdwqf86eHAnQ = url.split('=')
	cMI7BFzNCugRGJ2Xwf3VQPEqm9pKlW = int(LLsGB1FPiUTyYrdwqf86eHAnQ[1])
	name = jkiCS0UWs2dNAJcGKn6mbHD(LLsGB1FPiUTyYrdwqf86eHAnQ[2])
	name = name.replace('_MOD_مسلسل ',hWGMqtBy4wuLaVcj)
	Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG = LLsGB1FPiUTyYrdwqf86eHAnQ[3]
	url = url.split('?')[0]
	if cMI7BFzNCugRGJ2Xwf3VQPEqm9pKlW==0:
		mMQ3FkNVa4IlxqY = f1fLNcPlo2ECKtiBeug0OAvz9YM(KqO5BWGQR9JVL,url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'SHOOFMAX-EPISODES-1st')
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('<select(.*?)</select>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('option value="(.*?)"',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		cMI7BFzNCugRGJ2Xwf3VQPEqm9pKlW = int(items[-1])
	for IIsmGy4pd7 in range(cMI7BFzNCugRGJ2Xwf3VQPEqm9pKlW,0,-1):
		llxFwq0CUNgQtivJzkHeGV = url + '?ep=' + str(IIsmGy4pd7)
		title = '_MOD_مسلسل '+name+' - الحلقة '+str(IIsmGy4pd7)
		RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,53,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
	return
def oanus6TxUFNAhSZKpJdYlEC4mV(url):
	mMQ3FkNVa4IlxqY = f1fLNcPlo2ECKtiBeug0OAvz9YM(DpQifS0oKBI1hYcO,url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'SHOOFMAX-PLAY-1st')
	WoptHP3kX5yfCGYZl2j = trdVA0JvFaD.findall('متوفر على شوف ماكس بعد.*?moment\("(.*?)"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if WoptHP3kX5yfCGYZl2j:
		HB5PvxRhwM = WoptHP3kX5yfCGYZl2j[1].replace('T',nIDXGaRHv7mOohe0Y8dLstECM)
		BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'رسالة من الموقع الأصلي','هذا الفيديو سيكون متوفر على شوف ماكس بعد هذا الوقت'+NXMOzZjYsmS9pf+HB5PvxRhwM)
		return
	x1GjEmJdOQn,uZDoNEdXTvSRYKe4Cx9zt3HAB58hMc = [],[]
	HHlzVuF6neR8Y5KoE14 = trdVA0JvFaD.findall('var origin_link = "(.*?)"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)[0]
	FFetdOA1J3oHxKk5DL = trdVA0JvFaD.findall('var backup_origin_link = "(.*?)"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)[0]
	m4IznKilUOByHweG68VJ = trdVA0JvFaD.findall('hls: (.*?)_link\+"(.*?)"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	for SODQ7qlNYoZcFK8e50rBsJaAHxiXjE,llxFwq0CUNgQtivJzkHeGV in m4IznKilUOByHweG68VJ:
		if 'backup' in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE:
			SODQ7qlNYoZcFK8e50rBsJaAHxiXjE = 'backup server'
			url = FFetdOA1J3oHxKk5DL + llxFwq0CUNgQtivJzkHeGV
		else:
			SODQ7qlNYoZcFK8e50rBsJaAHxiXjE = 'main server'
			url = HHlzVuF6neR8Y5KoE14 + llxFwq0CUNgQtivJzkHeGV
		if '.m3u8' in url:
			x1GjEmJdOQn.append(url)
			uZDoNEdXTvSRYKe4Cx9zt3HAB58hMc.append('m3u8  '+SODQ7qlNYoZcFK8e50rBsJaAHxiXjE)
	m4IznKilUOByHweG68VJ = trdVA0JvFaD.findall('mp4:.*?_link.*?\t(.*?)_link\+"(.*?)"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	m4IznKilUOByHweG68VJ += trdVA0JvFaD.findall('mp4:.*?\t(.*?)_link\+"(.*?)"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	for SODQ7qlNYoZcFK8e50rBsJaAHxiXjE,llxFwq0CUNgQtivJzkHeGV in m4IznKilUOByHweG68VJ:
		filename = llxFwq0CUNgQtivJzkHeGV.split('/')[-1]
		filename = filename.replace('fallback',hWGMqtBy4wuLaVcj)
		filename = filename.replace('.mp4',hWGMqtBy4wuLaVcj)
		filename = filename.replace('-',hWGMqtBy4wuLaVcj)
		if 'backup' in SODQ7qlNYoZcFK8e50rBsJaAHxiXjE:
			SODQ7qlNYoZcFK8e50rBsJaAHxiXjE = 'backup server'
			url = FFetdOA1J3oHxKk5DL + llxFwq0CUNgQtivJzkHeGV
		else:
			SODQ7qlNYoZcFK8e50rBsJaAHxiXjE = 'main server'
			url = HHlzVuF6neR8Y5KoE14 + llxFwq0CUNgQtivJzkHeGV
		x1GjEmJdOQn.append(url)
		uZDoNEdXTvSRYKe4Cx9zt3HAB58hMc.append('mp4  '+SODQ7qlNYoZcFK8e50rBsJaAHxiXjE+FqcVAkh7WjIXHdDKf8nvuyRo+filename)
	OODLkJlZCoKmrzbg2XQSGPUdInA = Eb7qJoNwOgn('Select Video Quality:', uZDoNEdXTvSRYKe4Cx9zt3HAB58hMc)
	if OODLkJlZCoKmrzbg2XQSGPUdInA == -1 : return
	url = x1GjEmJdOQn[OODLkJlZCoKmrzbg2XQSGPUdInA]
	vOq38Y4XVZwdE(url,xjPuFK3EsIZSiobQ5X,'video')
	return
def RRTmBF6iZyzUL(url,type):
	if 'series' in url: NPM3HKQ57xe = Str0BupDTFA + '/genre/مسلسل'
	else: NPM3HKQ57xe = Str0BupDTFA + '/genre/فيلم'
	NPM3HKQ57xe = e1mT8H4dGS3XFyx0KLUA9(NPM3HKQ57xe)
	mMQ3FkNVa4IlxqY = f1fLNcPlo2ECKtiBeug0OAvz9YM(DpQifS0oKBI1hYcO,NPM3HKQ57xe,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'SHOOFMAX-FILTERS-1st')
	if type==1: DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('subgenre(.*?)div',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	elif type==2: DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('country(.*?)div',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
	items = trdVA0JvFaD.findall('option value="(.*?)">(.*?)</option',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	if type==1:
		for ADKrMtBnIN3HzGjk9lu2ET8e5,title in items:
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,url+'?subgenre='+ADKrMtBnIN3HzGjk9lu2ET8e5,58)
	elif type==2:
		url,ADKrMtBnIN3HzGjk9lu2ET8e5 = url.split('?')
		for ZG7ywHXrqjgUomtR45kuL,title in items:
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,url+'?country='+ZG7ywHXrqjgUomtR45kuL+'&'+ADKrMtBnIN3HzGjk9lu2ET8e5,51)
	return
def lPwaAjFTMG4n7iSLkXcEuK0Zm(search):
	search,vvKf4sXgZIMyEJPuC,showDialogs = IVTEJQOiMR2dYta9C(search)
	if not search: search = TrzfUidpv1LyAYqwexHJDuS()
	if not search: return
	lKqyOtIAvVY = search.replace(Mpsm2VF1OBnCRvK3qf6,'%20')
	url = Str0BupDTFA+'/search?q='+lKqyOtIAvVY
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,True,hWGMqtBy4wuLaVcj,'SHOOFMAX-SEARCH-2nd')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('general-body(.*?)search-bottom-padding',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
	items = trdVA0JvFaD.findall('href="(.*?)".*?background-image: url\((.*?)\).*?<span>(.*?)</span>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	if items:
		for llxFwq0CUNgQtivJzkHeGV,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,title in items:
			url = Str0BupDTFA + llxFwq0CUNgQtivJzkHeGV
			if '/program/' in url:
				if '?ep=' in url:
					title = '_MOD_مسلسل '+title
					url = url.replace('?ep=1','?ep=0')
					url = url+'='+e1mT8H4dGS3XFyx0KLUA9(title)+'='+Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG
					RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,url,52,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
				else:
					title = '_MOD_فيلم '+title
					RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,url,53,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
	return
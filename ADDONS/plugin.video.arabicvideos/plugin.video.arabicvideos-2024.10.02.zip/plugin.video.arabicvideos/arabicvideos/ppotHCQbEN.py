# -*- coding: utf-8 -*-
from yoY3NdGViS import *
headers = { 'User-Agent' : hWGMqtBy4wuLaVcj }
xjPuFK3EsIZSiobQ5X = 'AKOAM'
n0qFKQWhiBYXoTrvejVHUA4 = '_AKO_'
Str0BupDTFA = u6rbxnyjTl7I[xjPuFK3EsIZSiobQ5X][0]
fSGrb8Xq7QDKPMhvsjn1Ycyga = ['فيلم','كليب','العرض الاسبوعي','مسرحية','مسرحيه','اغنية','اعلان','لقاء']
def ehB18u9sQFRi(mode,url,text):
	if   mode==70: N6NCYivtV4I5rEXq = DP6FSBgNdX1rsvVR()
	elif mode==71: N6NCYivtV4I5rEXq = pP0LwjXO3cAJRfCaQY6(url)
	elif mode==72: N6NCYivtV4I5rEXq = wg5aF3e8rcDh7SGpW6M1OPnkU(url,text)
	elif mode==73: N6NCYivtV4I5rEXq = HAnGWKZuvgj83hMPJr6bi2d10l9Q(url)
	elif mode==74: N6NCYivtV4I5rEXq = oanus6TxUFNAhSZKpJdYlEC4mV(url)
	elif mode==79: N6NCYivtV4I5rEXq = lPwaAjFTMG4n7iSLkXcEuK0Zm(text)
	else: N6NCYivtV4I5rEXq = False
	return N6NCYivtV4I5rEXq
def DP6FSBgNdX1rsvVR():
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'بحث في الموقع',hWGMqtBy4wuLaVcj,79,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'_REMEMBERRESULTS_')
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+'سلسلة افلام',hWGMqtBy4wuLaVcj,79,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'سلسلة افلام')
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+'سلاسل منوعة',hWGMqtBy4wuLaVcj,79,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'سلسلة')
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	P3UK1Rr4IdYe5 = ['الكتب و الابحاث','الكورسات التعليمية','الألعاب','البرامج','الاجهزة اللوحية','الصور و الخلفيات','المصارعة الحرة']
	mMQ3FkNVa4IlxqY = f1fLNcPlo2ECKtiBeug0OAvz9YM(DpQifS0oKBI1hYcO,Str0BupDTFA,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,'AKOAM-MENU-1st')
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('class="partions"(.*?)</ul>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('href="(.*?)">(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,title in items:
			if title not in P3UK1Rr4IdYe5:
				RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,71)
	return mMQ3FkNVa4IlxqY
def pP0LwjXO3cAJRfCaQY6(url):
	mMQ3FkNVa4IlxqY = f1fLNcPlo2ECKtiBeug0OAvz9YM(DpQifS0oKBI1hYcO,url,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,'AKOAM-CATEGORIES-1st')
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('sect_parts(.*?)</div>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('href="(.*?)".*?>(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,title in items:
			title = title.strip(Mpsm2VF1OBnCRvK3qf6)
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,72)
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'جميع الفروع',url,72)
	else: wg5aF3e8rcDh7SGpW6M1OPnkU(url,hWGMqtBy4wuLaVcj)
	return
def wg5aF3e8rcDh7SGpW6M1OPnkU(url,type):
	mMQ3FkNVa4IlxqY = f1fLNcPlo2ECKtiBeug0OAvz9YM(KqO5BWGQR9JVL,url,hWGMqtBy4wuLaVcj,headers,True,'AKOAM-TITLES-1st')
	items = []
	if type=='featured':
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('section_title featured_title(.*?)subjects-crousel',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('href="(.*?)"><div class="subject_box.*?src="(.*?)".*?<h3.*?>(.*?)</h3>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	elif type=='search':
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('akoam_result(.*?)<script',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('href="(.*?)".*?background-image: url\((.*?)\).*?<h1>(.*?)</h1>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	elif type=='more':
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('section_title more_title(.*?)footer_bottom_services',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	else:
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('navigation(.*?)<script',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if not items and DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('div class="subject_box.*?href="(.*?)".*?src="(.*?)".*?<h3.*?>(.*?)</h3>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	for llxFwq0CUNgQtivJzkHeGV,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,title in items:
		if 'توضيح هام' in title: continue
		title = title.replace(NXMOzZjYsmS9pf,hWGMqtBy4wuLaVcj).strip(Mpsm2VF1OBnCRvK3qf6)
		title = LNtIDdBA52P(title)
		if any(BoSjXKxz41DcneO9UimClE in title for BoSjXKxz41DcneO9UimClE in fSGrb8Xq7QDKPMhvsjn1Ycyga): RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,73,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
		else: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,73,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('class="pagination"(.*?)</ul>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall("</li><li >.*?href='(.*?)'>(.*?)<",cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,title in items:
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'صفحة '+title,llxFwq0CUNgQtivJzkHeGV,72,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,type)
	return
def QIkHs89oZBvRrwp(url):
	mMQ3FkNVa4IlxqY = f1fLNcPlo2ECKtiBeug0OAvz9YM(DpQifS0oKBI1hYcO,url,hWGMqtBy4wuLaVcj,headers,True,'AKOAM-SECTIONS-2nd')
	NPM3HKQ57xe = trdVA0JvFaD.findall('"href","(.*?)"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	NPM3HKQ57xe = NPM3HKQ57xe[1]
	return NPM3HKQ57xe
def HAnGWKZuvgj83hMPJr6bi2d10l9Q(url):
	mMQ3FkNVa4IlxqY = f1fLNcPlo2ECKtiBeug0OAvz9YM(KqO5BWGQR9JVL,url,hWGMqtBy4wuLaVcj,headers,True,'AKOAM-SECTIONS-1st')
	vmUiez7VSBqYohDTwtRXAEO1 = trdVA0JvFaD.findall('"(https*://akwam.net/\w+.*?)"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	DDQXYhHSA17GVmIBJtwfplUguC = trdVA0JvFaD.findall('"(https*://underurl.com/\w+.*?)"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if vmUiez7VSBqYohDTwtRXAEO1 or DDQXYhHSA17GVmIBJtwfplUguC:
		if vmUiez7VSBqYohDTwtRXAEO1: CMzQFXeI08KDwAJ9p = vmUiez7VSBqYohDTwtRXAEO1[0]
		elif DDQXYhHSA17GVmIBJtwfplUguC: CMzQFXeI08KDwAJ9p = QIkHs89oZBvRrwp(DDQXYhHSA17GVmIBJtwfplUguC[0])
		CMzQFXeI08KDwAJ9p = jkiCS0UWs2dNAJcGKn6mbHD(CMzQFXeI08KDwAJ9p)
		import rrg9LDpKux
		if '/series/' in CMzQFXeI08KDwAJ9p or '/shows/' in CMzQFXeI08KDwAJ9p: rrg9LDpKux.GrsxUhb0PEXj2FQRAkD4q(CMzQFXeI08KDwAJ9p)
		else: rrg9LDpKux.oanus6TxUFNAhSZKpJdYlEC4mV(CMzQFXeI08KDwAJ9p)
		return
	BX029UJFPvpNQsc45jbYZRh = trdVA0JvFaD.findall('محتوى الفيلم.*?>.*?(\w*?)\W*?<',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if BX029UJFPvpNQsc45jbYZRh and Dc20k3vN9hT5(xjPuFK3EsIZSiobQ5X,url,BX029UJFPvpNQsc45jbYZRh): return
	items = trdVA0JvFaD.findall('<br />\n<a href="(.*?)".*?<span style="color:.*?">(.*?)</span>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	for llxFwq0CUNgQtivJzkHeGV,title in items:
		title = LNtIDdBA52P(title)
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,73)
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('class="sub_title".*?<h1.*?>(.*?)</h1>.*?class="main_img".*?src="(.*?)".*?ad-300-250(.*?)ako-feedback',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if not DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		OnsAxhdVjZF('خطأ خارجي','لا يوجد ملف فيديو')
		return
	name,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
	name = name.strip(Mpsm2VF1OBnCRvK3qf6)
	if 'sub_epsiode_title' in cok5ZGXdQP7YhwtqyuaCnVevm6UB:
		items = trdVA0JvFaD.findall('sub_epsiode_title">(.*?)</h2>.*?sub_file_title.*?>(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	else:
		nOv9G5I16ZzK4guDSeaktjlBPsh0 = trdVA0JvFaD.findall('sub_file_title\'>(.*?) - <i>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		items = []
		for filename in nOv9G5I16ZzK4guDSeaktjlBPsh0:
			items.append( ('رابط التشغيل',filename) )
	if not items: items = [ ('رابط التشغيل',hWGMqtBy4wuLaVcj) ]
	count = 0
	haq1bHZINPE58uoBFnKfTSO2ik4,YYrzWI6JPETq = [],[]
	size = len(items)
	for title,filename in items:
		QWz1jXGo6ruOitUMqET7yI5 = hWGMqtBy4wuLaVcj
		if ' - ' in filename: filename = filename.split(' - ')[0]
		else: filename = 'dummy.zip'
		if '.' in filename: QWz1jXGo6ruOitUMqET7yI5 = filename.split('.')[-1]
		title = title.replace(NXMOzZjYsmS9pf,hWGMqtBy4wuLaVcj).strip(Mpsm2VF1OBnCRvK3qf6)
		haq1bHZINPE58uoBFnKfTSO2ik4.append(title)
		YYrzWI6JPETq.append(count)
		count += 1
	if size>0:
		if any(BoSjXKxz41DcneO9UimClE in name for BoSjXKxz41DcneO9UimClE in fSGrb8Xq7QDKPMhvsjn1Ycyga):
			if size==1:
				OODLkJlZCoKmrzbg2XQSGPUdInA = 0
			else:
				OODLkJlZCoKmrzbg2XQSGPUdInA = Eb7qJoNwOgn('اختر الفيديو المناسب:', haq1bHZINPE58uoBFnKfTSO2ik4)
				if OODLkJlZCoKmrzbg2XQSGPUdInA == -1: return
			oanus6TxUFNAhSZKpJdYlEC4mV(url+'?section='+str(1+YYrzWI6JPETq[size-OODLkJlZCoKmrzbg2XQSGPUdInA-1]))
		else:
			for PPuqrvDLEViYOMf1dmkK7 in reversed(range(size)):
				title = name + ' - ' + haq1bHZINPE58uoBFnKfTSO2ik4[PPuqrvDLEViYOMf1dmkK7]
				title = title.replace(NXMOzZjYsmS9pf,hWGMqtBy4wuLaVcj).strip(Mpsm2VF1OBnCRvK3qf6)
				llxFwq0CUNgQtivJzkHeGV = url + '?section='+str(size-PPuqrvDLEViYOMf1dmkK7)
				RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,74,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
	else:
		RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+'الرابط ليس فيديو',hWGMqtBy4wuLaVcj,9999,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
	return
def oanus6TxUFNAhSZKpJdYlEC4mV(url):
	NPM3HKQ57xe,IIsmGy4pd7 = url.split('?section=')
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',NPM3HKQ57xe,hWGMqtBy4wuLaVcj,headers,True,hWGMqtBy4wuLaVcj,'AKOAM-PLAY_AKOAM-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('ad-300-250.*?ad-300-250(.*?)ako-feedback',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	rrUOyRQ4DfWxLNAXlg2oemEPIsv1 = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0].replace("'direct_link_box",'"direct_link_box epsoide_box')
	rrUOyRQ4DfWxLNAXlg2oemEPIsv1 = rrUOyRQ4DfWxLNAXlg2oemEPIsv1 + 'direct_link_box'
	rqIW37cd0iT1msDzRevOM = trdVA0JvFaD.findall('epsoide_box(.*?)direct_link_box',rrUOyRQ4DfWxLNAXlg2oemEPIsv1,trdVA0JvFaD.DOTALL)
	IIsmGy4pd7 = len(rqIW37cd0iT1msDzRevOM)-int(IIsmGy4pd7)
	cok5ZGXdQP7YhwtqyuaCnVevm6UB = rqIW37cd0iT1msDzRevOM[IIsmGy4pd7]
	zmDKurMJwj6fi = []
	asIJkQhfVFiAKmWz7DOjLeM = {'1423075862':'dailymotion','1477487601':'estream','1505328404':'streamango',
		'1423080015':'flashx','1458117295':'openload','1423079306':'vimple','1430052371':'ok.ru',
		'1477488213':'thevid','1558278006':'uqload','1477487990':'vidtodo'}
	items = trdVA0JvFaD.findall("class='download_btn.*?href='(.*?)'",cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	for llxFwq0CUNgQtivJzkHeGV in items:
		zmDKurMJwj6fi.append(llxFwq0CUNgQtivJzkHeGV+'?named=________akoam')
	items = trdVA0JvFaD.findall('background-image: url\((.*?)\).*?href=\'(.*?)\'',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	for c4a61lUDOHBvmXsh0KygkdGPZn,llxFwq0CUNgQtivJzkHeGV in items:
		c4a61lUDOHBvmXsh0KygkdGPZn = c4a61lUDOHBvmXsh0KygkdGPZn.split('/')[-1]
		c4a61lUDOHBvmXsh0KygkdGPZn = c4a61lUDOHBvmXsh0KygkdGPZn.split('.')[0]
		if c4a61lUDOHBvmXsh0KygkdGPZn in asIJkQhfVFiAKmWz7DOjLeM:
			zmDKurMJwj6fi.append(llxFwq0CUNgQtivJzkHeGV+'?named='+asIJkQhfVFiAKmWz7DOjLeM[c4a61lUDOHBvmXsh0KygkdGPZn]+'________akoam')
		else: zmDKurMJwj6fi.append(llxFwq0CUNgQtivJzkHeGV+'?named='+c4a61lUDOHBvmXsh0KygkdGPZn+'________akoam')
	if not zmDKurMJwj6fi:
		message = trdVA0JvFaD.findall('sub-no-file.*?\n(.*?)\n',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		if message: BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'رسالة من الموقع الاصلي',message[0])
	else:
		import oosSOfvdEQ
		oosSOfvdEQ.zfdYjsGLg8M6i15qZWh(zmDKurMJwj6fi,xjPuFK3EsIZSiobQ5X,'video',url)
	return
def lPwaAjFTMG4n7iSLkXcEuK0Zm(search):
	search,vvKf4sXgZIMyEJPuC,showDialogs = IVTEJQOiMR2dYta9C(search)
	if search==hWGMqtBy4wuLaVcj: search = TrzfUidpv1LyAYqwexHJDuS()
	if search==hWGMqtBy4wuLaVcj: return
	lKqyOtIAvVY = search.replace(Mpsm2VF1OBnCRvK3qf6,'%20')
	url = Str0BupDTFA + '/search/'+lKqyOtIAvVY
	N6NCYivtV4I5rEXq = wg5aF3e8rcDh7SGpW6M1OPnkU(url,'search')
	return
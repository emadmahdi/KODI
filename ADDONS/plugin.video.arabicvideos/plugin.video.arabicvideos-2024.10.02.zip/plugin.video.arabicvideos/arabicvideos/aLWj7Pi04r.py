# -*- coding: utf-8 -*-
from yoY3NdGViS import *
xjPuFK3EsIZSiobQ5X = 'SHAHIDNEWS'
n0qFKQWhiBYXoTrvejVHUA4 = '_SHN_'
Str0BupDTFA = u6rbxnyjTl7I[xjPuFK3EsIZSiobQ5X][0]
P3UK1Rr4IdYe5 = ['قنوات فضائية','فارسكو','Show more']
def ehB18u9sQFRi(mode,url,text):
	if   mode==580: N6NCYivtV4I5rEXq = DP6FSBgNdX1rsvVR()
	elif mode==581: N6NCYivtV4I5rEXq = wg5aF3e8rcDh7SGpW6M1OPnkU(url,text)
	elif mode==582: N6NCYivtV4I5rEXq = oanus6TxUFNAhSZKpJdYlEC4mV(url)
	elif mode==583: N6NCYivtV4I5rEXq = GrsxUhb0PEXj2FQRAkD4q(url,text)
	elif mode==584: N6NCYivtV4I5rEXq = qt2zjyIbsS(url)
	elif mode==589: N6NCYivtV4I5rEXq = lPwaAjFTMG4n7iSLkXcEuK0Zm(text)
	else: N6NCYivtV4I5rEXq = False
	return N6NCYivtV4I5rEXq
def DP6FSBgNdX1rsvVR():
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',Str0BupDTFA,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'SHAHIDNEWS-MENU-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'بحث في الموقع',hWGMqtBy4wuLaVcj,589,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'_REMEMBERRESULTS_')
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('/category.php">(.*?)"navslide-divider"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall("'dropdown-menu'(.*?)</ul>",mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	for TfCqlZthRYgzkbE0GO in DJvksH7ZAFUqW9OyQnbGjPCtwR1o: cok5ZGXdQP7YhwtqyuaCnVevm6UB = cok5ZGXdQP7YhwtqyuaCnVevm6UB.replace(TfCqlZthRYgzkbE0GO,hWGMqtBy4wuLaVcj)
	items = trdVA0JvFaD.findall('href="(.*?)".*?>(.*?)</a>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	for llxFwq0CUNgQtivJzkHeGV,title in items:
		if title in P3UK1Rr4IdYe5: continue
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,584)
	return
def qt2zjyIbsS(url):
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'SHAHIDNEWS-SUBMENU-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	cLV4wifngjAdbePKq2x7SDhXGYlO0 = trdVA0JvFaD.findall('"caret"(.*?)</ul>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if cLV4wifngjAdbePKq2x7SDhXGYlO0:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = cLV4wifngjAdbePKq2x7SDhXGYlO0[0]
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = cok5ZGXdQP7YhwtqyuaCnVevm6UB.replace('"presentation"','</ul>')
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		if not DJvksH7ZAFUqW9OyQnbGjPCtwR1o: DJvksH7ZAFUqW9OyQnbGjPCtwR1o = [(hWGMqtBy4wuLaVcj,cok5ZGXdQP7YhwtqyuaCnVevm6UB)]
		RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' فرز أو فلتر أو ترتيب '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
		for HoEKsq4QNVuCc8xdeMam0,cok5ZGXdQP7YhwtqyuaCnVevm6UB in DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
			items = trdVA0JvFaD.findall('href="(.*?)".*?>(.*?)</a>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
			if HoEKsq4QNVuCc8xdeMam0: HoEKsq4QNVuCc8xdeMam0 = HoEKsq4QNVuCc8xdeMam0+': '
			for llxFwq0CUNgQtivJzkHeGV,title in items:
				title = HoEKsq4QNVuCc8xdeMam0+title
				RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,581)
	v2V8Nmrwf4 = trdVA0JvFaD.findall('"pm-category-subcats"(.*?)</ul>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if v2V8Nmrwf4:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = v2V8Nmrwf4[0]
		items = trdVA0JvFaD.findall('href="(.*?)">(.*?)</a>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		if len(items)<30:
			RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
			for llxFwq0CUNgQtivJzkHeGV,title in items:
				RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,581)
	if not cLV4wifngjAdbePKq2x7SDhXGYlO0 and not v2V8Nmrwf4: wg5aF3e8rcDh7SGpW6M1OPnkU(url)
	return
def wg5aF3e8rcDh7SGpW6M1OPnkU(url,s4mUPzjv1bRoNTMdenkuBgYl=hWGMqtBy4wuLaVcj):
	cbYKa2SXGwRCiQIW5NeosU9k = RRNODILCtGzvgpx(url,'url')
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'SHAHIDNEWS-TITLES-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	items = []
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('(data-echo=".*?)</ul>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if not DJvksH7ZAFUqW9OyQnbGjPCtwR1o: DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('"BlocksList"(.*?)"titleSectionCon"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if not DJvksH7ZAFUqW9OyQnbGjPCtwR1o: DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('id="pm-grid"(.*?)</ul>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if not DJvksH7ZAFUqW9OyQnbGjPCtwR1o: DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('id="pm-related"(.*?)</ul>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if not DJvksH7ZAFUqW9OyQnbGjPCtwR1o: return
	cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
	if not items: items = trdVA0JvFaD.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	if not items: items = trdVA0JvFaD.findall('src="(.*?)".*?href="(.*?)".*?>(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	REbVyXis1w4Ae = []
	nNBCdTs98RztMyODHpL63ZUKm4P = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,llxFwq0CUNgQtivJzkHeGV,title in items:
		llxFwq0CUNgQtivJzkHeGV = jkiCS0UWs2dNAJcGKn6mbHD(llxFwq0CUNgQtivJzkHeGV).strip('/')
		if 'http' not in llxFwq0CUNgQtivJzkHeGV: llxFwq0CUNgQtivJzkHeGV = cbYKa2SXGwRCiQIW5NeosU9k+'/'+llxFwq0CUNgQtivJzkHeGV.strip('/')
		if 'http' not in Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG: Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG = cbYKa2SXGwRCiQIW5NeosU9k+'/'+Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG.strip('/')
		IIsmGy4pd7 = trdVA0JvFaD.findall('(.*?) الحلقة \d+',title,trdVA0JvFaD.DOTALL)
		if any(BoSjXKxz41DcneO9UimClE in title for BoSjXKxz41DcneO9UimClE in nNBCdTs98RztMyODHpL63ZUKm4P):
			RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,582,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
		elif IIsmGy4pd7 and 'الحلقة' in title:
			title = '_MOD_' + IIsmGy4pd7[0]
			if title not in REbVyXis1w4Ae:
				RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,583,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
				REbVyXis1w4Ae.append(title)
		elif '/movseries/' in llxFwq0CUNgQtivJzkHeGV:
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,581,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
		else: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,583,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
	if s4mUPzjv1bRoNTMdenkuBgYl not in ['featured_movies','featured_series']:
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('"pagination(.*?)</ul>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
			cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
			items = trdVA0JvFaD.findall('href="(.*?)".*?>(.*?)</a>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
			for llxFwq0CUNgQtivJzkHeGV,title in items:
				if llxFwq0CUNgQtivJzkHeGV=='#': continue
				llxFwq0CUNgQtivJzkHeGV = cbYKa2SXGwRCiQIW5NeosU9k+'/'+llxFwq0CUNgQtivJzkHeGV.strip('/')
				title = LNtIDdBA52P(title)
				RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'صفحة '+title,llxFwq0CUNgQtivJzkHeGV,581)
		C1EL24u0ZA8YRg9vfBXDxiyQ5lFoO = trdVA0JvFaD.findall('showmore" href="(.*?)"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if C1EL24u0ZA8YRg9vfBXDxiyQ5lFoO:
			llxFwq0CUNgQtivJzkHeGV = C1EL24u0ZA8YRg9vfBXDxiyQ5lFoO[0]
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'مشاهدة المزيد',llxFwq0CUNgQtivJzkHeGV,581)
	return
def GrsxUhb0PEXj2FQRAkD4q(url,dp9XPV1Au6EWCJyiGw):
	cbYKa2SXGwRCiQIW5NeosU9k = RRNODILCtGzvgpx(url,'url')
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'SHAHIDNEWS-EPISODES-2nd')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	cLV4wifngjAdbePKq2x7SDhXGYlO0 = trdVA0JvFaD.findall('nav-seasons"(.*?)</ul>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	items = []
	PPOKIaMHbQ6CxFqkZSdi53 = False
	if cLV4wifngjAdbePKq2x7SDhXGYlO0 and not dp9XPV1Au6EWCJyiGw:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = cLV4wifngjAdbePKq2x7SDhXGYlO0[0]
		items = trdVA0JvFaD.findall('href="(.*?)">(.*?)</a>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for dp9XPV1Au6EWCJyiGw,title in items:
			dp9XPV1Au6EWCJyiGw = dp9XPV1Au6EWCJyiGw.strip('#')
			if len(items)>1: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,url,583,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,dp9XPV1Au6EWCJyiGw)
			else: PPOKIaMHbQ6CxFqkZSdi53 = True
	else: PPOKIaMHbQ6CxFqkZSdi53 = True
	v2V8Nmrwf4 = trdVA0JvFaD.findall('id="'+dp9XPV1Au6EWCJyiGw+'"(.*?)</div>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if v2V8Nmrwf4 and PPOKIaMHbQ6CxFqkZSdi53:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = v2V8Nmrwf4[0]
		items = trdVA0JvFaD.findall('href="(.*?)".*?">(.*?)</a>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		if items:
			for llxFwq0CUNgQtivJzkHeGV,title in items:
				llxFwq0CUNgQtivJzkHeGV = cbYKa2SXGwRCiQIW5NeosU9k+'/'+llxFwq0CUNgQtivJzkHeGV.strip('/')
				RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,582)
		else:
			items = trdVA0JvFaD.findall('href="(.*?)".*?title="(.*?)".*?image:url\((.*?)\)',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
			for llxFwq0CUNgQtivJzkHeGV,title,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG in items:
				if 'http' not in llxFwq0CUNgQtivJzkHeGV: llxFwq0CUNgQtivJzkHeGV = cbYKa2SXGwRCiQIW5NeosU9k+'/'+llxFwq0CUNgQtivJzkHeGV.strip('/')
				RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,582)
	return
def oanus6TxUFNAhSZKpJdYlEC4mV(url):
	cbYKa2SXGwRCiQIW5NeosU9k = RRNODILCtGzvgpx(url,'url')
	Dvi8asSrQYX5wE3KMIxT91me = []
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'SHAHIDNEWS-PLAY-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	llxFwq0CUNgQtivJzkHeGV = trdVA0JvFaD.findall('"Playerholder".*?href="(.*?)"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV[0]
	if llxFwq0CUNgQtivJzkHeGV and 'http' not in llxFwq0CUNgQtivJzkHeGV: llxFwq0CUNgQtivJzkHeGV = 'http:'+llxFwq0CUNgQtivJzkHeGV
	hash = llxFwq0CUNgQtivJzkHeGV.split('hash=')[1]
	LLsGB1FPiUTyYrdwqf86eHAnQ = hash.split('__')
	tMqK7iPfza5UykIXDcE = []
	for ww93NKCHTO in LLsGB1FPiUTyYrdwqf86eHAnQ:
		try:
			ww93NKCHTO = FxG0Q9kuBSmTyM.b64decode(ww93NKCHTO+'=')
			if H4qZ2hwilNJYTmCFEQyaSs98cPM0gR: ww93NKCHTO = ww93NKCHTO.decode(a7VXeDU82IfQEnPZAdiT)
			tMqK7iPfza5UykIXDcE.append(ww93NKCHTO)
		except: pass
	m4IznKilUOByHweG68VJ = '>'.join(tMqK7iPfza5UykIXDcE)
	m4IznKilUOByHweG68VJ = m4IznKilUOByHweG68VJ.splitlines()
	if 'farsol' not in str(m4IznKilUOByHweG68VJ):
		for llxFwq0CUNgQtivJzkHeGV in m4IznKilUOByHweG68VJ:
			if ' => ' in llxFwq0CUNgQtivJzkHeGV:
				title,llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV.split(' => ')
				llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV+'?named='+title+'__watch'
				Dvi8asSrQYX5wE3KMIxT91me.append(llxFwq0CUNgQtivJzkHeGV)
		import oosSOfvdEQ
		oosSOfvdEQ.zfdYjsGLg8M6i15qZWh(Dvi8asSrQYX5wE3KMIxT91me,xjPuFK3EsIZSiobQ5X,'video',url)
	else:
		title,llxFwq0CUNgQtivJzkHeGV = m4IznKilUOByHweG68VJ[0].split(' => ')
		BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'رسالة من المبرمج','هذا الفيديو غير متوفر الآن'+NXMOzZjYsmS9pf+'يرجى المحاولة لاحقا'+'\n\n'+title)
	return
def lPwaAjFTMG4n7iSLkXcEuK0Zm(search):
	search,vvKf4sXgZIMyEJPuC,showDialogs = IVTEJQOiMR2dYta9C(search)
	if search==hWGMqtBy4wuLaVcj: search = TrzfUidpv1LyAYqwexHJDuS()
	if search==hWGMqtBy4wuLaVcj: return
	search = search.replace(Mpsm2VF1OBnCRvK3qf6,'+')
	url = Str0BupDTFA+'/search.php?keywords='+search
	wg5aF3e8rcDh7SGpW6M1OPnkU(url)
	return
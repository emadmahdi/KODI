# -*- coding: utf-8 -*-
from yoY3NdGViS import *
xjPuFK3EsIZSiobQ5X = 'SHOOFNET'
n0qFKQWhiBYXoTrvejVHUA4 = '_SNT_'
Str0BupDTFA = u6rbxnyjTl7I[xjPuFK3EsIZSiobQ5X][0]
P3UK1Rr4IdYe5 = ['الرئيسية','يلا شوت']
def ehB18u9sQFRi(mode,url,text):
	if   mode==840: N6NCYivtV4I5rEXq = DP6FSBgNdX1rsvVR()
	elif mode==841: N6NCYivtV4I5rEXq = wg5aF3e8rcDh7SGpW6M1OPnkU(url,text)
	elif mode==842: N6NCYivtV4I5rEXq = oanus6TxUFNAhSZKpJdYlEC4mV(url)
	elif mode==843: N6NCYivtV4I5rEXq = H1fiR4odCZLuxmkwISX(url)
	elif mode==849: N6NCYivtV4I5rEXq = lPwaAjFTMG4n7iSLkXcEuK0Zm(text)
	else: N6NCYivtV4I5rEXq = False
	return N6NCYivtV4I5rEXq
def DP6FSBgNdX1rsvVR():
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',Str0BupDTFA,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'SHOOFNET-MENU-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'بحث في الموقع',hWGMqtBy4wuLaVcj,849,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'_REMEMBERRESULTS_')
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('"primary-links"(.*?)</u',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('href="(.*?)".*?<span>(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,title in items:
			if title in P3UK1Rr4IdYe5: continue
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,841)
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('"list-categories"(.*?)</u',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('href="(.*?)">(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,title in items:
			if title in P3UK1Rr4IdYe5: continue
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,841)
	return
def wg5aF3e8rcDh7SGpW6M1OPnkU(url,type=hWGMqtBy4wuLaVcj):
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'SHOOFNET-TITLES-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('"home-content"(.*?)"footer"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = cok5ZGXdQP7YhwtqyuaCnVevm6UB.replace('"overlay"','"duration"><')
		items = trdVA0JvFaD.findall('"thumb".*?data-src="(.*?)".*?"duration">(.*?)<.*?href="(.*?)">(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		REbVyXis1w4Ae = []
		for Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,oJV18NUZAzPGqMu7tenCxrkfhdl69B,llxFwq0CUNgQtivJzkHeGV,title in items:
			title = title.strip(' ')
			title = LNtIDdBA52P(title)
			IIsmGy4pd7 = trdVA0JvFaD.findall('(.*?) (الحلقة|حلقة).\d+',title,trdVA0JvFaD.DOTALL)
			if 'episodes' not in type and IIsmGy4pd7:
				title = '_MOD_' + IIsmGy4pd7[0][0]
				title = title.replace('اون لاين',hWGMqtBy4wuLaVcj)
				if title not in REbVyXis1w4Ae:
					RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,843,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
					REbVyXis1w4Ae.append(title)
			else: RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,842,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,oJV18NUZAzPGqMu7tenCxrkfhdl69B)
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('''["']pagination["'](.*?)["']footer["']''',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		type = 'episodes_pages' if 'episodes' in type else 'pages'
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('href="(.*?)">(.*?)</a>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,title in items:
			title = LNtIDdBA52P(title)
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'صفحة '+title,llxFwq0CUNgQtivJzkHeGV,841,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,type)
	return
def H1fiR4odCZLuxmkwISX(url):
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'SHOOFNET-SERIES-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	llxFwq0CUNgQtivJzkHeGV = trdVA0JvFaD.findall('"category".*?href="(.*?)"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if llxFwq0CUNgQtivJzkHeGV: wg5aF3e8rcDh7SGpW6M1OPnkU(llxFwq0CUNgQtivJzkHeGV[0],'episodes')
	return
def oanus6TxUFNAhSZKpJdYlEC4mV(url):
	zmDKurMJwj6fi = []
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'SHOOFNET-PLAY-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	TsFgQdloabE4YpPWV = trdVA0JvFaD.findall("var post_id	= '(.*?)'",mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if TsFgQdloabE4YpPWV:
		llxFwq0CUNgQtivJzkHeGV = Str0BupDTFA+'/wp-admin/admin-ajax.php?action=video_info&post_id='+TsFgQdloabE4YpPWV[0]
		sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',llxFwq0CUNgQtivJzkHeGV,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'SHOOFNET-PLAY-2nd')
		mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
		items = trdVA0JvFaD.findall('"name":"(.*?)","src":"(.*?)"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		for title,llxFwq0CUNgQtivJzkHeGV in items:
			llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV.replace('\\/','/')
			llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV+'?named='+title+'__watch'
			zmDKurMJwj6fi.append(llxFwq0CUNgQtivJzkHeGV)
	import oosSOfvdEQ
	oosSOfvdEQ.zfdYjsGLg8M6i15qZWh(zmDKurMJwj6fi,xjPuFK3EsIZSiobQ5X,'video',url)
	return
def lPwaAjFTMG4n7iSLkXcEuK0Zm(search):
	search,vvKf4sXgZIMyEJPuC,showDialogs = IVTEJQOiMR2dYta9C(search)
	if search==hWGMqtBy4wuLaVcj: search = TrzfUidpv1LyAYqwexHJDuS()
	if search==hWGMqtBy4wuLaVcj: return
	search = search.replace(Mpsm2VF1OBnCRvK3qf6,'+')
	url = Str0BupDTFA+'/?s='+search
	wg5aF3e8rcDh7SGpW6M1OPnkU(url,'search')
	return
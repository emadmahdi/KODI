# -*- coding: utf-8 -*-
from yoY3NdGViS import *
xjPuFK3EsIZSiobQ5X = 'GOOGLESEARCH'
n0qFKQWhiBYXoTrvejVHUA4 = '_GOS_'
def ehB18u9sQFRi(JbpxsyQVXmSEYKM3vo847Ckh,O9z5L3KtXqPEMepJQ0,s9ea72VfoygAOFRCWQTH3zmDuLPE):
	if   JbpxsyQVXmSEYKM3vo847Ckh==1010: N6NCYivtV4I5rEXq = DP6FSBgNdX1rsvVR()
	elif JbpxsyQVXmSEYKM3vo847Ckh==1011: N6NCYivtV4I5rEXq = sQwAO8jc3Ua9uLrB(s9ea72VfoygAOFRCWQTH3zmDuLPE)
	elif JbpxsyQVXmSEYKM3vo847Ckh==1012: N6NCYivtV4I5rEXq = hRpce4QgHVOrASiKF78Nw9kz(O9z5L3KtXqPEMepJQ0,s9ea72VfoygAOFRCWQTH3zmDuLPE)
	elif JbpxsyQVXmSEYKM3vo847Ckh==1013: N6NCYivtV4I5rEXq = UBKwr0Dukp5z6RGi3hdYH81m()
	elif JbpxsyQVXmSEYKM3vo847Ckh==1014: N6NCYivtV4I5rEXq = hNnp5uYRDMGclZKFsSvoWbjOmCXT(O9z5L3KtXqPEMepJQ0,s9ea72VfoygAOFRCWQTH3zmDuLPE)
	elif JbpxsyQVXmSEYKM3vo847Ckh==1015: N6NCYivtV4I5rEXq = wbkIePzLSlxM395R1Z7aO4(s9ea72VfoygAOFRCWQTH3zmDuLPE)
	elif JbpxsyQVXmSEYKM3vo847Ckh==1016: N6NCYivtV4I5rEXq = pWJdAMtNXOro(s9ea72VfoygAOFRCWQTH3zmDuLPE)
	elif JbpxsyQVXmSEYKM3vo847Ckh==1018: N6NCYivtV4I5rEXq = lPwaAjFTMG4n7iSLkXcEuK0Zm(s9ea72VfoygAOFRCWQTH3zmDuLPE,-AoRzutVGQfLjYMwdCngZPxs)
	elif JbpxsyQVXmSEYKM3vo847Ckh==1019: N6NCYivtV4I5rEXq = lPwaAjFTMG4n7iSLkXcEuK0Zm(s9ea72VfoygAOFRCWQTH3zmDuLPE)
	else: N6NCYivtV4I5rEXq = False
	return N6NCYivtV4I5rEXq
def DP6FSBgNdX1rsvVR():
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','بحث جوجل جديد',hWGMqtBy4wuLaVcj,1019)
	RLDCGt8kq3OVmnzgx1rbi2f7F('link','كيف يعمل بحث جوجل','',1013)
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+'==== كلمات البحث المخزنة ===='+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	RDJzSUeO82fTC7NLo = Mqk51CFBym0pIQXZLsOxSJ(MM5Dx39f7ULhcJsRptzIowP,'dict','GLOBALSEARCH_SPLITTED_GOOGLE')
	if RDJzSUeO82fTC7NLo:
		RDJzSUeO82fTC7NLo = RDJzSUeO82fTC7NLo['__SEQUENCED_COLUMNS__']
		for WZMblRwhQNn9Gqo in reversed(RDJzSUeO82fTC7NLo):
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',WZMblRwhQNn9Gqo,hWGMqtBy4wuLaVcj,1019,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,WZMblRwhQNn9Gqo)
	return
def lPwaAjFTMG4n7iSLkXcEuK0Zm(search,UrkB6XhW2Z=AoRzutVGQfLjYMwdCngZPxs):
	if not search:
		search = TrzfUidpv1LyAYqwexHJDuS()
		if not search: return
		search = search.lower()
	I4IpiuxdmFPbrsfTvtj = search.replace(n0qFKQWhiBYXoTrvejVHUA4,hWGMqtBy4wuLaVcj)
	KojxLfZi8wBJgme0 = []
	if UrkB6XhW2Z>0: KojxLfZi8wBJgme0 = Mqk51CFBym0pIQXZLsOxSJ(MM5Dx39f7ULhcJsRptzIowP,'list','GOOGLESEARCH_RESULTS',I4IpiuxdmFPbrsfTvtj)
	if not KojxLfZi8wBJgme0 or UrkB6XhW2Z<0:
		SkZeg5RAD1L9 = niWc5EBHqSh8xgC(search,UrkB6XhW2Z)
		Ampt1RMeI30,TqXy0fKQCmgLe = [],[]
		for ImYg2jxU6Lc9Q1C4Oko in SkZeg5RAD1L9:
			name,llxFwq0CUNgQtivJzkHeGV,title,text,ju9GJ6Z15nXVePCL2ayM,ITlpOFqLn7W2hYkdijCogm = ImYg2jxU6Lc9Q1C4Oko
			if name==ITlpOFqLn7W2hYkdijCogm: TqXy0fKQCmgLe.append(ImYg2jxU6Lc9Q1C4Oko)
			else: Ampt1RMeI30.append(ImYg2jxU6Lc9Q1C4Oko)
		import W02GkD1ey4
		if UrkB6XhW2Z>=0: W02GkD1ey4.LRpZG0U5DJiNsj1te2MfSIT(I4IpiuxdmFPbrsfTvtj,'_GOOGLE',True)
		BxuD7iQRpW1(MM5Dx39f7ULhcJsRptzIowP,'GOOGLESEARCH_RESULTS',I4IpiuxdmFPbrsfTvtj,[Ampt1RMeI30,TqXy0fKQCmgLe],AoRzutVGQfLjYMwdCngZPxs)
		if UrkB6XhW2Z<0:
			pMPR1Cc0usZ6nJTU(MM5Dx39f7ULhcJsRptzIowP,'GLOBALSEARCH_DETAILED_GOOGLE',I4IpiuxdmFPbrsfTvtj)
			W02GkD1ey4.LRpZG0U5DJiNsj1te2MfSIT(I4IpiuxdmFPbrsfTvtj,'_GOOGLE',False)
			pMPR1Cc0usZ6nJTU(MM5Dx39f7ULhcJsRptzIowP,'GLOBALSEARCH_DIVIDED_GOOGLE',"%, '"+I4IpiuxdmFPbrsfTvtj+"')")
			BZj61bFtfWLzXp('','','رسالة من المبرمج','تم عمل بحث جوجل جديد')
	RLDCGt8kq3OVmnzgx1rbi2f7F('link','بحث جماعي لمواقع جوجل','search_sites_google',1012,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,I4IpiuxdmFPbrsfTvtj)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','بحث منفرد لمواقع جوجل',hWGMqtBy4wuLaVcj,1011,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,I4IpiuxdmFPbrsfTvtj)
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+'===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','نتائج البحث مفصلة - '+I4IpiuxdmFPbrsfTvtj,'opened_sites_google',1012,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,I4IpiuxdmFPbrsfTvtj)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','نتائج البحث مقسمة - '+I4IpiuxdmFPbrsfTvtj,'listed_sites_google',1012,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,I4IpiuxdmFPbrsfTvtj)
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+'===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','مواقع جوجل - '+I4IpiuxdmFPbrsfTvtj,'',1016,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,I4IpiuxdmFPbrsfTvtj)
	RLDCGt8kq3OVmnzgx1rbi2f7F('link','إعادة بحث جوجل - '+I4IpiuxdmFPbrsfTvtj,'',1018,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,I4IpiuxdmFPbrsfTvtj)
	return
def pWJdAMtNXOro(I4IpiuxdmFPbrsfTvtj):
	Ampt1RMeI30,TqXy0fKQCmgLe = Mqk51CFBym0pIQXZLsOxSJ(MM5Dx39f7ULhcJsRptzIowP,'list','GOOGLESEARCH_RESULTS',I4IpiuxdmFPbrsfTvtj)
	Ampt1RMeI30 = sorted(Ampt1RMeI30,reverse=fEXMiAyG3ql4vKB,key=lambda key: key[ybdv7XcT3lxF6QezULwCAGk])
	KojxLfZi8wBJgme0 = {}
	for name,llxFwq0CUNgQtivJzkHeGV,title,text,ju9GJ6Z15nXVePCL2ayM,ITlpOFqLn7W2hYkdijCogm in Ampt1RMeI30: KojxLfZi8wBJgme0[ITlpOFqLn7W2hYkdijCogm] = name,llxFwq0CUNgQtivJzkHeGV,title,text,ju9GJ6Z15nXVePCL2ayM,ITlpOFqLn7W2hYkdijCogm
	lPGbBZQnIcexgjzihvH0Oro85dk = list(KojxLfZi8wBJgme0.keys())
	import W02GkD1ey4
	OxHBLDKlTgRe3zEY = W02GkD1ey4.JTxDNUKHZgh0YvcjWIBCdeP7(lPGbBZQnIcexgjzihvH0Oro85dk)
	for ITlpOFqLn7W2hYkdijCogm in OxHBLDKlTgRe3zEY:
		if 'tuple' in str(type(ITlpOFqLn7W2hYkdijCogm)):
			vNRpDl1awktg7QP4m0KGqMTS2i.append(ITlpOFqLn7W2hYkdijCogm)
			continue
		name,llxFwq0CUNgQtivJzkHeGV,title,text,ju9GJ6Z15nXVePCL2ayM,ITlpOFqLn7W2hYkdijCogm = KojxLfZi8wBJgme0[ITlpOFqLn7W2hYkdijCogm]
		OLEaRvPrIK,jybQBYEnf41IACTROeGlDdP9z,lr6UH3CkoIi9tuabRW4Vwe1 = CPGup68qUQdti5IVeS7kXRA(ITlpOFqLn7W2hYkdijCogm)
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',lr6UH3CkoIi9tuabRW4Vwe1+name,llxFwq0CUNgQtivJzkHeGV,1014,ju9GJ6Z15nXVePCL2ayM,'',ITlpOFqLn7W2hYkdijCogm)
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+'===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+'مواقع بجوجل غير موجودة بالبرنامج'+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,1015)
	TqXy0fKQCmgLe = sorted(TqXy0fKQCmgLe,reverse=fEXMiAyG3ql4vKB,key=lambda key: key[ybdv7XcT3lxF6QezULwCAGk])
	for name,llxFwq0CUNgQtivJzkHeGV,title,text,ju9GJ6Z15nXVePCL2ayM,ITlpOFqLn7W2hYkdijCogm in TqXy0fKQCmgLe:
		RLDCGt8kq3OVmnzgx1rbi2f7F('link','_GOS_'+hXB0vKVQ5PRI91SDTprMdfuHEm4+name+Mpsm2VF1OBnCRvK3qf6+YYSh2J6BIrsm8,llxFwq0CUNgQtivJzkHeGV,1015,ju9GJ6Z15nXVePCL2ayM,'',ITlpOFqLn7W2hYkdijCogm)
	return
def hRpce4QgHVOrASiKF78Nw9kz(A5iw9HPEgZxu8eatLhYmvKRCIBjUT,I4IpiuxdmFPbrsfTvtj):
	KojxLfZi8wBJgme0 = Mqk51CFBym0pIQXZLsOxSJ(MM5Dx39f7ULhcJsRptzIowP,'list','GOOGLESEARCH_RESULTS',I4IpiuxdmFPbrsfTvtj)
	if not KojxLfZi8wBJgme0: return
	Ampt1RMeI30,TqXy0fKQCmgLe = KojxLfZi8wBJgme0
	eYU50G7k1N2xf,Olcu2sLxHiaohzfRK = [],{}
	for name,llxFwq0CUNgQtivJzkHeGV,title,text,ju9GJ6Z15nXVePCL2ayM,ITlpOFqLn7W2hYkdijCogm in Ampt1RMeI30:
		eYU50G7k1N2xf.append(ITlpOFqLn7W2hYkdijCogm)
		Olcu2sLxHiaohzfRK[ITlpOFqLn7W2hYkdijCogm] = b4CMmISEcQAedJkw9Ut7B1W35p8G(title)
	import W02GkD1ey4
	W02GkD1ey4.KKwBztsuNE0Lgipld3cXPD6Z(I4IpiuxdmFPbrsfTvtj,A5iw9HPEgZxu8eatLhYmvKRCIBjUT,hWGMqtBy4wuLaVcj,eYU50G7k1N2xf,Olcu2sLxHiaohzfRK)
	return
def sQwAO8jc3Ua9uLrB(search):
	KojxLfZi8wBJgme0 = Mqk51CFBym0pIQXZLsOxSJ(MM5Dx39f7ULhcJsRptzIowP,'list','GOOGLESEARCH_RESULTS',search)
	if not KojxLfZi8wBJgme0: return
	Ampt1RMeI30,TqXy0fKQCmgLe = KojxLfZi8wBJgme0
	Ampt1RMeI30 = sorted(Ampt1RMeI30,reverse=fEXMiAyG3ql4vKB,key=lambda key: key[ybdv7XcT3lxF6QezULwCAGk])
	KojxLfZi8wBJgme0 = {}
	for name,llxFwq0CUNgQtivJzkHeGV,title,text,ju9GJ6Z15nXVePCL2ayM,ITlpOFqLn7W2hYkdijCogm in Ampt1RMeI30:
		KojxLfZi8wBJgme0[ITlpOFqLn7W2hYkdijCogm] = name,llxFwq0CUNgQtivJzkHeGV,title,text,ju9GJ6Z15nXVePCL2ayM,ITlpOFqLn7W2hYkdijCogm
	lPGbBZQnIcexgjzihvH0Oro85dk = list(KojxLfZi8wBJgme0.keys())
	import W02GkD1ey4
	OxHBLDKlTgRe3zEY = W02GkD1ey4.JTxDNUKHZgh0YvcjWIBCdeP7(lPGbBZQnIcexgjzihvH0Oro85dk)
	for ITlpOFqLn7W2hYkdijCogm in OxHBLDKlTgRe3zEY:
		if 'tuple' in str(type(ITlpOFqLn7W2hYkdijCogm)):
			vNRpDl1awktg7QP4m0KGqMTS2i.append(ITlpOFqLn7W2hYkdijCogm)
			continue
		name,llxFwq0CUNgQtivJzkHeGV,title,text,ju9GJ6Z15nXVePCL2ayM,ITlpOFqLn7W2hYkdijCogm = KojxLfZi8wBJgme0[ITlpOFqLn7W2hYkdijCogm]
		OLEaRvPrIK,jybQBYEnf41IACTROeGlDdP9z,lr6UH3CkoIi9tuabRW4Vwe1 = CPGup68qUQdti5IVeS7kXRA(ITlpOFqLn7W2hYkdijCogm)
		title = b4CMmISEcQAedJkw9Ut7B1W35p8G(title)
		name = name+' - '+search
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',lr6UH3CkoIi9tuabRW4Vwe1+name,ITlpOFqLn7W2hYkdijCogm,548,ju9GJ6Z15nXVePCL2ayM,'',title)
	return
def b4CMmISEcQAedJkw9Ut7B1W35p8G(title):
	IIsmGy4pd7 = trdVA0JvFaD.findall('(.*?) (الحلقة|حلقة)',title,trdVA0JvFaD.DOTALL)
	m4eVoJdSU51qs3y8Gg06fZNau7A = IIsmGy4pd7[0][0] if IIsmGy4pd7 else title
	m4eVoJdSU51qs3y8Gg06fZNau7A = m4eVoJdSU51qs3y8Gg06fZNau7A.replace('مشاهدة اونلاين، فيديو، الإعلان، صور - السينما.كوم','').replace('- ‎عرب سيد - Arabseed','')
	m4eVoJdSU51qs3y8Gg06fZNau7A = m4eVoJdSU51qs3y8Gg06fZNau7A.replace('- وى سيما wecima ماى سيما mycima - وي سيما','').replace('- فيديو Dailymotion','')
	m4eVoJdSU51qs3y8Gg06fZNau7A = m4eVoJdSU51qs3y8Gg06fZNau7A.replace('الموسم','').replace('الموقع','').replace('- شوف نت','').replace('موسم','').replace('HD','')
	m4eVoJdSU51qs3y8Gg06fZNau7A = m4eVoJdSU51qs3y8Gg06fZNau7A.replace('مشاهدة','').replace('نتائج البحث:','').replace('اونلاين','').replace('- سيما فور بي','')
	m4eVoJdSU51qs3y8Gg06fZNau7A = m4eVoJdSU51qs3y8Gg06fZNau7A.replace('موقع','').replace('| اكوام','').replace('','').replace('','').replace('','').replace('','')
	m4eVoJdSU51qs3y8Gg06fZNau7A = m4eVoJdSU51qs3y8Gg06fZNau7A.strip(' ').replace('    ',' ').replace('   ',' ').replace('  ',' ').replace('  ',' ')
	return m4eVoJdSU51qs3y8Gg06fZNau7A
def niWc5EBHqSh8xgC(search,UrkB6XhW2Z):
	search = search.replace(Mpsm2VF1OBnCRvK3qf6,'%20')
	url = 'https://www.google.com/search?hl=en&filter=1&imgSize=small&safe=active&num=100&start=0&q='+search
	headers = {'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36 Edg/128.0.0.0'}
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(UrkB6XhW2Z,'GET',url,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'GOOGLESEARCH-SEARCH-1st')
	FerMPqU0onXJ4Y,r9yn41tWKIbJMQF = [],[]
	if not sDQvwGASB0Vf67mik.succeeded: return FerMPqU0onXJ4Y
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	lgLDBjRQCvy9U = WQvYkNg7SysPFLitlGEn6.path.join(zKdeknjoPhL9gN8v,'googlesearch')
	if not WQvYkNg7SysPFLitlGEn6.path.exists(lgLDBjRQCvy9U):
		try: WQvYkNg7SysPFLitlGEn6.makedirs(lgLDBjRQCvy9U)
		except: pass
	rqIW37cd0iT1msDzRevOM = trdVA0JvFaD.findall('(\[null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,".*?\]\])',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	for cok5ZGXdQP7YhwtqyuaCnVevm6UB in rqIW37cd0iT1msDzRevOM:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = Cy9ow3c21nABMjzqeaIT('list',cok5ZGXdQP7YhwtqyuaCnVevm6UB)
		llxFwq0CUNgQtivJzkHeGV = cok5ZGXdQP7YhwtqyuaCnVevm6UB[17]
		title,text,name,nWE8aO53lFfD = cok5ZGXdQP7YhwtqyuaCnVevm6UB[31][0:4]
		name = name.strip(' ')
		if not name: name = RRNODILCtGzvgpx(llxFwq0CUNgQtivJzkHeGV,'name')
		name = vJRN3snSxMqBP1dpIGTQX8Yl(name)
		if 'http://' in nWE8aO53lFfD or 'https://' in nWE8aO53lFfD: ju9GJ6Z15nXVePCL2ayM = nWE8aO53lFfD
		elif 'data:image/' in nWE8aO53lFfD and ';base64,' in nWE8aO53lFfD:
			fIUrThCQc0xvt = trdVA0JvFaD.findall('data:image/(\w+);base64,',nWE8aO53lFfD)
			fIUrThCQc0xvt = fIUrThCQc0xvt[0]
			ju9GJ6Z15nXVePCL2ayM = WQvYkNg7SysPFLitlGEn6.path.join(lgLDBjRQCvy9U,name+'.'+fIUrThCQc0xvt)
			if not WQvYkNg7SysPFLitlGEn6.path.exists(ju9GJ6Z15nXVePCL2ayM):
				nWE8aO53lFfD = nWE8aO53lFfD.replace('\\u003d','=')
				nWE8aO53lFfD = nWE8aO53lFfD.replace('data:image/'+fIUrThCQc0xvt+';base64,','')
				S7STQ1sGi2eZfmnd9 = FxG0Q9kuBSmTyM.b64decode(nWE8aO53lFfD)
				open(ju9GJ6Z15nXVePCL2ayM,'wb').write(S7STQ1sGi2eZfmnd9)
		else: ju9GJ6Z15nXVePCL2ayM = ''
		ITlpOFqLn7W2hYkdijCogm = aMhekB4jWCEQYx0Ni5PT(name,llxFwq0CUNgQtivJzkHeGV)
		if ITlpOFqLn7W2hYkdijCogm not in r9yn41tWKIbJMQF:
			r9yn41tWKIbJMQF.append(ITlpOFqLn7W2hYkdijCogm)
			name = J72F0jRI6A(ITlpOFqLn7W2hYkdijCogm)
			FerMPqU0onXJ4Y.append([name,llxFwq0CUNgQtivJzkHeGV,title,text,ju9GJ6Z15nXVePCL2ayM,ITlpOFqLn7W2hYkdijCogm])
	return FerMPqU0onXJ4Y
def hNnp5uYRDMGclZKFsSvoWbjOmCXT(llxFwq0CUNgQtivJzkHeGV,ITlpOFqLn7W2hYkdijCogm):
	OLEaRvPrIK,jybQBYEnf41IACTROeGlDdP9z,lr6UH3CkoIi9tuabRW4Vwe1 = CPGup68qUQdti5IVeS7kXRA(ITlpOFqLn7W2hYkdijCogm)
	if lr6UH3CkoIi9tuabRW4Vwe1: OLEaRvPrIK()
	else: wbkIePzLSlxM395R1Z7aO4()
	return
def UBKwr0Dukp5z6RGi3hdYH81m():
	BZj61bFtfWLzXp('','','رسالة من المبرمج','هذا البحث يستخدم ذكاء وشمولية وسرعة محرك بحث جوجل .. ونتائج هذا البحث هي أسماء مواقع الإنترنت التي موجودة في هذا البرنامج والتي فيها الفيديوهات المطلوبة\n\nهذا البحث يحتاج كلمات بحث عادية جدا بدون أي مراعاة لدقة الكلمات أو تفاصيل الفيديوهات أو حتى إملاء الكلمات\n\nهذا البحث يستطيع أيضا أن يفحص محتويات المواقع التي وجدها جوجل إذا كانت هذه المواقع موجودة بهذا البرنامج')
	return
def wbkIePzLSlxM395R1Z7aO4(ITlpOFqLn7W2hYkdijCogm=''):
	BZj61bFtfWLzXp('','',ITlpOFqLn7W2hYkdijCogm,'هذا الموقع غير موجود في البرنامج .. أو أسم الموقع مختلف وغير مطابق للاسم المستخدم في البرنامج')
	return
def aMhekB4jWCEQYx0Ni5PT(name,llxFwq0CUNgQtivJzkHeGV):
	p8wV7DKMX3ybTQHNWa5 = {
	 'فشار فيديو مشاهدة افلام ومسلسلات اون لاين'	:'FUSHARVIDEO'
	,'وى سيما wecima ماى سيما mycima'			:'WECIMA1'
	,'شبكتي تي في - SHABAKATY TV'				:'SHABAKATY'
	,'اكوام  شبكة اكوام AKWAM'					:'AKWAM'
	,'سيما كلوب  CIMACLUB'						:'CIMACLUB'
	,'سيما فري CIMAFREE':'CIMAFREE'
	,'هلا سيما'			:'HALACIMA'
	,'لاروزا'			:'LAROZA'
	,'برستيج'			:'BRSTEJ'
	,'كرمالك TV'		:'KIRMALK'
	,'سيما فور بي'		:'CIMA4P'
	,'اهواك تي في'		:'AHWAK'
	,'CIMA CLUB'		:'CIMACLUB'
	,'اكوام'			:'AKWAM'
	,'وي سيما'			:'WECIMA1'
	,'سيما ناو'			:'CIMANOW'
	,'سيما لايت'			:'CIMALIGHT'
	,'عرب سيد'			:'ARABSEED'
	,'فيديو ياقوت'		:'YAQOT'
	,'المصطبة TV'		:'ALMSTBA'
	,'دراما كافيه'		:'DRAMACAFE'
	,'سيما 400'			:'CIMA400'
	,'فيديو تكات'		:'TIKAAT'
	,'السينما.كوم'		:'ELCINEMA'
	,'فوستا'			:'FOSTA'
	,'سيما عبدو'		:'CIMAABDO'
	,'فاصل إعلاني'		:'FASELHD1'
	,'مسلسلات تايم'		:'SERIESTIME'
	,'برس3تيج'		:''
	,'برس3تيج'		:''
	,'برس3تيج'		:''
	,'برس3تيج'		:''
	,'برس3تيج'		:''
	,'برس3تيج'		:''
	,'برس3تيج'		:''
	,'برس3تيج'		:''
	}
	u25Car4veWZpIhniLSUKqH83Gf = name.lower()
	FEpnOiHwDL6soV9 = ''
	for key in list(p8wV7DKMX3ybTQHNWa5.keys()):
		if key.lower() in u25Car4veWZpIhniLSUKqH83Gf: FEpnOiHwDL6soV9 = p8wV7DKMX3ybTQHNWa5[key]
	if not FEpnOiHwDL6soV9:
		MDSF21x9HK3AZyGUhcb = RRNODILCtGzvgpx(llxFwq0CUNgQtivJzkHeGV,'url')
		for ITlpOFqLn7W2hYkdijCogm in list(u6rbxnyjTl7I.keys()):
			V4K76PotgYjcyU981mkTXBvfSdAWp2 = RRNODILCtGzvgpx(u6rbxnyjTl7I[ITlpOFqLn7W2hYkdijCogm][0],'url')
			if MDSF21x9HK3AZyGUhcb==V4K76PotgYjcyU981mkTXBvfSdAWp2: FEpnOiHwDL6soV9 = ITlpOFqLn7W2hYkdijCogm
	if not FEpnOiHwDL6soV9:
		u25Car4veWZpIhniLSUKqH83Gf = RRNODILCtGzvgpx(llxFwq0CUNgQtivJzkHeGV,'name')
		for ITlpOFqLn7W2hYkdijCogm in list(u6rbxnyjTl7I.keys()):
			gx0jtHXnSuWDB13ZFehM7p = RRNODILCtGzvgpx(u6rbxnyjTl7I[ITlpOFqLn7W2hYkdijCogm][0],'name')
			if u25Car4veWZpIhniLSUKqH83Gf==gx0jtHXnSuWDB13ZFehM7p: FEpnOiHwDL6soV9 = ITlpOFqLn7W2hYkdijCogm
	if not FEpnOiHwDL6soV9: FEpnOiHwDL6soV9 = name
	FEpnOiHwDL6soV9 = FEpnOiHwDL6soV9.upper()
	return FEpnOiHwDL6soV9
# -*- coding: utf-8 -*-
from yoY3NdGViS import *
xjPuFK3EsIZSiobQ5X = 'FASELHD1'
headers = {'User-Agent':hWGMqtBy4wuLaVcj}
n0qFKQWhiBYXoTrvejVHUA4 = '_FH1_'
Str0BupDTFA = u6rbxnyjTl7I[xjPuFK3EsIZSiobQ5X][0]
P3UK1Rr4IdYe5 = ['جوائز الأوسكار','المراجعات','wwe']
def ehB18u9sQFRi(mode,url,text):
	if   mode==570: N6NCYivtV4I5rEXq = DP6FSBgNdX1rsvVR()
	elif mode==571: N6NCYivtV4I5rEXq = wg5aF3e8rcDh7SGpW6M1OPnkU(url,text)
	elif mode==572: N6NCYivtV4I5rEXq = oanus6TxUFNAhSZKpJdYlEC4mV(url)
	elif mode==573: N6NCYivtV4I5rEXq = UCjs37gPYNoqt(url,text)
	elif mode==576: N6NCYivtV4I5rEXq = vRA1d9tI5q8wnXlWcLbJsETpC0()
	elif mode==579: N6NCYivtV4I5rEXq = lPwaAjFTMG4n7iSLkXcEuK0Zm(text)
	else: N6NCYivtV4I5rEXq = False
	return N6NCYivtV4I5rEXq
def DP6FSBgNdX1rsvVR():
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',n0qFKQWhiBYXoTrvejVHUA4+'لماذا الموقع بطيء',hWGMqtBy4wuLaVcj,576)
	cbYKa2SXGwRCiQIW5NeosU9k,url = Str0BupDTFA,Str0BupDTFA
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'FASELHD1-MENU-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'بحث في الموقع',cbYKa2SXGwRCiQIW5NeosU9k,579,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'_REMEMBERRESULTS_')
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'المميزة',cbYKa2SXGwRCiQIW5NeosU9k,571,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'featured1')
	items = trdVA0JvFaD.findall('class="h3">(.*?)<.*?href="(.*?)"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	for title,llxFwq0CUNgQtivJzkHeGV in items:
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,571,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'details1')
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('"menu-primary"(.*?)</ul>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		iiy48BO9TJ5 = trdVA0JvFaD.findall('<li (.*?)</li>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		FbWh5EMyOJdV91DQ7fezpCAgk0n = [hWGMqtBy4wuLaVcj,'أفلام: ','مسلسلات: ','برامج: ','آسيوي: ','أنمي: ']
		JpzD0lv9cYM6XrHeqCa = 0
		for p7tSrCjXlc6M1i5WQTgq9zGJF in iiy48BO9TJ5:
			if JpzD0lv9cYM6XrHeqCa>0: RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
			items = trdVA0JvFaD.findall('href="(.*?)".*?>(.*?)<',p7tSrCjXlc6M1i5WQTgq9zGJF,trdVA0JvFaD.DOTALL)
			for llxFwq0CUNgQtivJzkHeGV,title in items:
				if llxFwq0CUNgQtivJzkHeGV=='#': continue
				if 'http' not in llxFwq0CUNgQtivJzkHeGV: llxFwq0CUNgQtivJzkHeGV = cbYKa2SXGwRCiQIW5NeosU9k+llxFwq0CUNgQtivJzkHeGV
				if title==hWGMqtBy4wuLaVcj: continue
				if any(BoSjXKxz41DcneO9UimClE in title.lower() for BoSjXKxz41DcneO9UimClE in P3UK1Rr4IdYe5): continue
				title = FbWh5EMyOJdV91DQ7fezpCAgk0n[JpzD0lv9cYM6XrHeqCa]+title
				RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,571,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'details2')
			JpzD0lv9cYM6XrHeqCa += 1
	return
def vRA1d9tI5q8wnXlWcLbJsETpC0():
	BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'رسالة من المبرمج','موقع فاصل الأول بطيء من المصدر .. بسبب قيام أصحاب الموقع بإضافة فحص وتحقق أمني ضد هجوم البرامج وهجوم القراصنة على صفحات الموقع .. والوقت الضائع يذهب في محاولة تجاوز هذا الفحص واثبات أن هذا البرنامج هو مجرد متصفح للمواقع ولا يقوم بالهجوم على المواقع')
	return
def wg5aF3e8rcDh7SGpW6M1OPnkU(url,type=hWGMqtBy4wuLaVcj):
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'FASELHD1-TITLES-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	v2V8Nmrwf4 = trdVA0JvFaD.findall('class="h4">(.*?)</div>(.*?)"container"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if not v2V8Nmrwf4: return
	if type=='filters':
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = [mMQ3FkNVa4IlxqY.replace('\\/','/').replace('\\"','"')]
	elif type=='featured1':
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('"homeSlide"(.*?)"container"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall(' src="(.*?)".*? href="(.*?)">(.*?)</a>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		nGRxyZU4zWrK,m4IznKilUOByHweG68VJ,LHN1Zr7FDtbYfjz069Gnh = zip(*items)
		items = zip(m4IznKilUOByHweG68VJ,nGRxyZU4zWrK,LHN1Zr7FDtbYfjz069Gnh)
	elif type=='featured2':
		title,cok5ZGXdQP7YhwtqyuaCnVevm6UB = v2V8Nmrwf4[0]
		items = trdVA0JvFaD.findall('href="(.*?)".*? data-src="(.*?)".*? alt="(.*?)"',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	elif type=='details2' and len(v2V8Nmrwf4)>1:
		title = v2V8Nmrwf4[0][0]
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,url,571,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'featured2')
		title = v2V8Nmrwf4[1][0]
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,url,571,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'details3')
		return
	else:
		title,cok5ZGXdQP7YhwtqyuaCnVevm6UB = v2V8Nmrwf4[-1]
		items = trdVA0JvFaD.findall('href="(.*?)".*? data-src="(.*?)".*?"h1">(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	REbVyXis1w4Ae = []
	for llxFwq0CUNgQtivJzkHeGV,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,title in items:
		if any(BoSjXKxz41DcneO9UimClE in title.lower() for BoSjXKxz41DcneO9UimClE in P3UK1Rr4IdYe5): continue
		Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG = emr1Lf523Ti0OtcNgxP(Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
		Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG = Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG.split('?resize=')[0]
		title = LNtIDdBA52P(title)
		IIsmGy4pd7 = trdVA0JvFaD.findall('(.*?) (الحلقة|حلقة).\d+',title,trdVA0JvFaD.DOTALL)
		if '/collections/' in llxFwq0CUNgQtivJzkHeGV:
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,571,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
		elif IIsmGy4pd7 and type==hWGMqtBy4wuLaVcj:
			title = '_MOD_'+IIsmGy4pd7[0][0]
			title = title.strip(' –')
			if title not in REbVyXis1w4Ae:
				RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,573,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
				REbVyXis1w4Ae.append(title)
		elif 'episodes/' in llxFwq0CUNgQtivJzkHeGV or 'movies/' in llxFwq0CUNgQtivJzkHeGV or 'hindi/' in llxFwq0CUNgQtivJzkHeGV:
			RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,572,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
		else: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,573,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
	if type=='filters':
		HHDPiqLBrUbSgveQlFwWz3Xd9O = trdVA0JvFaD.findall('"more_button_page":(.*?),',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		if HHDPiqLBrUbSgveQlFwWz3Xd9O:
			count = HHDPiqLBrUbSgveQlFwWz3Xd9O[0]
			llxFwq0CUNgQtivJzkHeGV = url+'/offset/'+count
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'صفحة أخرى',llxFwq0CUNgQtivJzkHeGV,571,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'filters')
	elif 'details' in type:
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall("class='pagination(.*?)</div>",mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
			cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
			items = trdVA0JvFaD.findall("href='(.*?)'.*?>(.*?)<",cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
			for llxFwq0CUNgQtivJzkHeGV,title in items:
				title = 'صفحة '+LNtIDdBA52P(title)
				RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,571,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'details4')
	return
def UCjs37gPYNoqt(url,type=hWGMqtBy4wuLaVcj):
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'FASELHD1-SEASONS_EPISODES-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	k8YRdISjEZF0qyzs5GK = False
	if not type:
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('"seasonList"(.*?)"container"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
			cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
			items = trdVA0JvFaD.findall('href = \'(.*?)\'.*? data-src="(.*?)".*?alt="(.*?)".*?"title">(.*?)</div>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
			if len(items)>1:
				cbYKa2SXGwRCiQIW5NeosU9k = RRNODILCtGzvgpx(url,'url')
				k8YRdISjEZF0qyzs5GK = True
				for llxFwq0CUNgQtivJzkHeGV,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,name,title in items:
					name = LNtIDdBA52P(name)
					if 'http' not in llxFwq0CUNgQtivJzkHeGV: llxFwq0CUNgQtivJzkHeGV = cbYKa2SXGwRCiQIW5NeosU9k+llxFwq0CUNgQtivJzkHeGV
					title = name+' - '+title
					RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,573,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,hWGMqtBy4wuLaVcj,'episodes')
	if type=='episodes' or not k8YRdISjEZF0qyzs5GK:
		nWE8aO53lFfD = trdVA0JvFaD.findall('"posterImg".*?src="(.*?)"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if nWE8aO53lFfD: Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG = nWE8aO53lFfD[0]
		else: Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG = hWGMqtBy4wuLaVcj
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('"epAll"(.*?)</div>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
			cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
			items = trdVA0JvFaD.findall('href="(.*?)".*?>(.*?)</a>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
			for llxFwq0CUNgQtivJzkHeGV,title in items:
				title = title.strip(Mpsm2VF1OBnCRvK3qf6)
				title = LNtIDdBA52P(title)
				RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,572,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
	return
def oanus6TxUFNAhSZKpJdYlEC4mV(url):
	zmDKurMJwj6fi,wIKcsSv7mX6ylH15,UEYlTGJarmz = [],[],[]
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(nHBb7jXk0Daom,'GET',url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'FASELHD1-PLAY-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	wxFEhq5c4GHBJftRezlrTI7 = trdVA0JvFaD.findall('مستوى المشاهدة.*?">(.*?)</span>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if wxFEhq5c4GHBJftRezlrTI7:
		BX029UJFPvpNQsc45jbYZRh = trdVA0JvFaD.findall('"tag">(.*?)</a>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if BX029UJFPvpNQsc45jbYZRh and Dc20k3vN9hT5(xjPuFK3EsIZSiobQ5X,url,BX029UJFPvpNQsc45jbYZRh): return
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('"videoRow"(.*?)</div>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('src="(.*?)"',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV in items:
			llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV.split('&img=')[0]
			zmDKurMJwj6fi.append(llxFwq0CUNgQtivJzkHeGV+'?named=__embed')
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('class="streamHeader(.*?)</ul>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall("href = '(.*?)'.*?</i>(.*?)</a>",cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,name in items:
			llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV.split('&img=')[0]
			name = name.strip(Mpsm2VF1OBnCRvK3qf6)
			zmDKurMJwj6fi.append(llxFwq0CUNgQtivJzkHeGV+'?named='+name+'__watch')
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('class="downloadLinks(.*?)blackwindow',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('href="(.*?)".*?</span>(.*?)</a>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,name in items:
			llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV.split('&img=')[0]
			zmDKurMJwj6fi.append(llxFwq0CUNgQtivJzkHeGV+'?named='+name+'__download')
	for ltukdO8wbXmUvIZTPKSC1qHc6VG in zmDKurMJwj6fi:
		llxFwq0CUNgQtivJzkHeGV,name = ltukdO8wbXmUvIZTPKSC1qHc6VG.split('?named')
		if llxFwq0CUNgQtivJzkHeGV not in wIKcsSv7mX6ylH15:
			wIKcsSv7mX6ylH15.append(llxFwq0CUNgQtivJzkHeGV)
			UEYlTGJarmz.append(ltukdO8wbXmUvIZTPKSC1qHc6VG)
	import oosSOfvdEQ
	oosSOfvdEQ.zfdYjsGLg8M6i15qZWh(UEYlTGJarmz,xjPuFK3EsIZSiobQ5X,'video',url)
	return
def lPwaAjFTMG4n7iSLkXcEuK0Zm(search):
	search,vvKf4sXgZIMyEJPuC,showDialogs = IVTEJQOiMR2dYta9C(search)
	if search==hWGMqtBy4wuLaVcj: search = TrzfUidpv1LyAYqwexHJDuS()
	if search==hWGMqtBy4wuLaVcj: return
	search = search.replace(Mpsm2VF1OBnCRvK3qf6,'+')
	NPM3HKQ57xe = Str0BupDTFA+'/?s='+search
	wg5aF3e8rcDh7SGpW6M1OPnkU(NPM3HKQ57xe,'details5')
	return
# -*- coding: utf-8 -*-
from yoY3NdGViS import *
xjPuFK3EsIZSiobQ5X = 'DAILYMOTION'
n0qFKQWhiBYXoTrvejVHUA4 = '_DLM_'
Str0BupDTFA = u6rbxnyjTl7I[xjPuFK3EsIZSiobQ5X][0]
Mr9c3QFRbp4wm = u6rbxnyjTl7I[xjPuFK3EsIZSiobQ5X][1]
def ehB18u9sQFRi(mode,url,text,type,l7COkhRWD9uVS60Pte2NoyAaZn):
	if	 mode==400: N6NCYivtV4I5rEXq = DP6FSBgNdX1rsvVR()
	elif mode==401: N6NCYivtV4I5rEXq = nHu2UCtXBN(url,text)
	elif mode==402: N6NCYivtV4I5rEXq = DxZesqv1HMpS3kWozPyE(url,text)
	elif mode==403: N6NCYivtV4I5rEXq = oanus6TxUFNAhSZKpJdYlEC4mV(url,text)
	elif mode==404: N6NCYivtV4I5rEXq = ioYAsadWvVj(text,l7COkhRWD9uVS60Pte2NoyAaZn)
	elif mode==405: N6NCYivtV4I5rEXq = c0Gqef3MHdL(text,l7COkhRWD9uVS60Pte2NoyAaZn)
	elif mode==406: N6NCYivtV4I5rEXq = k7zPu8ISbWTOtnFRYsXcEyh4KD(text,l7COkhRWD9uVS60Pte2NoyAaZn)
	elif mode==407: N6NCYivtV4I5rEXq = naLWJZHe4zFoV(url,l7COkhRWD9uVS60Pte2NoyAaZn)
	elif mode==408: N6NCYivtV4I5rEXq = LK7NTfdxmeiS2l8ZHDqcRQGwb(url,l7COkhRWD9uVS60Pte2NoyAaZn)
	elif mode==409: N6NCYivtV4I5rEXq = lPwaAjFTMG4n7iSLkXcEuK0Zm(text,l7COkhRWD9uVS60Pte2NoyAaZn)
	elif mode==411: N6NCYivtV4I5rEXq = J7JHrqKFOtpGXlhoAY8M(url,text)
	elif mode==414: N6NCYivtV4I5rEXq = s0mkizQyXL4ZOqCRAg(text)
	elif mode==415: N6NCYivtV4I5rEXq = DnJb5u69KVIf3Q1NFse4LW(text,l7COkhRWD9uVS60Pte2NoyAaZn)
	elif mode==416: N6NCYivtV4I5rEXq = O40YaJMPmgnIQ7A8K(text,l7COkhRWD9uVS60Pte2NoyAaZn)
	elif mode==417: N6NCYivtV4I5rEXq = lo35VBCr0Ji4nFxfLIDujZHhvQ9Abq(url,l7COkhRWD9uVS60Pte2NoyAaZn)
	else: N6NCYivtV4I5rEXq = False
	return N6NCYivtV4I5rEXq
def DP6FSBgNdX1rsvVR():
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'الرئيسية',hWGMqtBy4wuLaVcj,414)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'بحث في الموقع',hWGMqtBy4wuLaVcj,409,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'_REMEMBERRESULTS_')
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'بحث عن فيديوهات',hWGMqtBy4wuLaVcj,409,hWGMqtBy4wuLaVcj,'videos?sortBy=','_REMEMBERRESULTS_')
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'بحث عن آخر الفيديوهات',hWGMqtBy4wuLaVcj,409,hWGMqtBy4wuLaVcj,'videos?sortBy=RECENT','_REMEMBERRESULTS_')
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'بحث عن الفيديوهات الأكثر مشاهدة',hWGMqtBy4wuLaVcj,409,hWGMqtBy4wuLaVcj,'videos?sortBy=VIEW_COUNT','_REMEMBERRESULTS_')
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'بحث عن قوائم التشغيل',hWGMqtBy4wuLaVcj,409,hWGMqtBy4wuLaVcj,'playlists','_REMEMBERRESULTS_')
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'بحث عن مستخدم',hWGMqtBy4wuLaVcj,409,hWGMqtBy4wuLaVcj,'channels','_REMEMBERRESULTS_')
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'بحث عن بث حي',hWGMqtBy4wuLaVcj,409,hWGMqtBy4wuLaVcj,'lives','_REMEMBERRESULTS_')
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'بحث عن هاشتاك',hWGMqtBy4wuLaVcj,409,hWGMqtBy4wuLaVcj,'hashtags','_REMEMBERRESULTS_')
	return
def DxZesqv1HMpS3kWozPyE(url,TKorEvgUIX72LOwx):
	if '/dm_' in url:
		sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(nHBb7jXk0Daom,'GET',url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,False,hWGMqtBy4wuLaVcj,'DAILYMOTION-CHANNELS_SUBMENU-1st',False,False)
		headers = sDQvwGASB0Vf67mik.headers
		if 'Location' in list(headers.keys()): url = Str0BupDTFA+headers['Location']
	TKorEvgUIX72LOwx = hXB0vKVQ5PRI91SDTprMdfuHEm4+TKorEvgUIX72LOwx+YYSh2J6BIrsm8
	TKorEvgUIX72LOwx = pIZ5wMHO41EGmve3iKUj92JSzk6(TKorEvgUIX72LOwx)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+':: بث حي',url,411,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'channel_lives_now')
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+':: آخر الفيديوهات',url+'/videos',408)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+':: الأكثر مشاهدة',url+'/videos?sort=visited',408)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+':: المميزة',url,411,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'channel_featured_videos')
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+':: قوائم التشغيل',url+'/playlists',407)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+':: قوائم التشغيل أبجدية',url+'/playlists?sort=alphaaz',407)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+':: قنوات ذات صلة',url,411,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'channel_related_channel')
	return
def pIZ5wMHO41EGmve3iKUj92JSzk6(title):
	title = title.rstrip('\\').strip(Mpsm2VF1OBnCRvK3qf6).replace('\\\\','\\')
	title = emr1Lf523Ti0OtcNgxP(title)
	return title
def oanus6TxUFNAhSZKpJdYlEC4mV(url,odaBP0SyZ7IwpmqR):
	import oosSOfvdEQ
	oosSOfvdEQ.zfdYjsGLg8M6i15qZWh([url],xjPuFK3EsIZSiobQ5X,'video',url)
	return
def ioYAsadWvVj(search,l7COkhRWD9uVS60Pte2NoyAaZn=hWGMqtBy4wuLaVcj):
	if l7COkhRWD9uVS60Pte2NoyAaZn==hWGMqtBy4wuLaVcj: l7COkhRWD9uVS60Pte2NoyAaZn = '1'
	if 'sortBy=' in search: sort = search.split('sortBy=')[1].split('&')[0]
	else: sort = hWGMqtBy4wuLaVcj
	search = search.split('/videos')[0]
	s4mUPzjv1bRoNTMdenkuBgYl = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeVideos":true,"page":mypagenumber,"limit":mypagelimitmysortmethod},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    views {      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment VIDEO_WATCH_LATER_FRAGMENT on Video {  id  isInWatchLater  __typename}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    videos {      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_WATCH_LATER_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	s4mUPzjv1bRoNTMdenkuBgYl = s4mUPzjv1bRoNTMdenkuBgYl.replace('mysearchwords',search)
	s4mUPzjv1bRoNTMdenkuBgYl = s4mUPzjv1bRoNTMdenkuBgYl.replace('mypagelimit','40')
	s4mUPzjv1bRoNTMdenkuBgYl = s4mUPzjv1bRoNTMdenkuBgYl.replace('mypagenumber',l7COkhRWD9uVS60Pte2NoyAaZn)
	if sort==hWGMqtBy4wuLaVcj: s4mUPzjv1bRoNTMdenkuBgYl = s4mUPzjv1bRoNTMdenkuBgYl.replace('mysortmethod',hWGMqtBy4wuLaVcj)
	else: s4mUPzjv1bRoNTMdenkuBgYl = s4mUPzjv1bRoNTMdenkuBgYl.replace('mysortmethod',',"sortByVideos":"'+sort+'"')
	url = Str0BupDTFA+'/search/'+search+'/videos'
	mMQ3FkNVa4IlxqY = ttAp0FJWZbyjvowCHSQM6hlBrE29Dm(s4mUPzjv1bRoNTMdenkuBgYl,search)
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('"videos"(.*?)"VideoConnection"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('"node".*?"xid":"(.*?)","title":"(.*?)".*?"name":"(.*?)".*?"displayName":"(.*?)".*?"duration":(.*?),.*?"thumbnailx240":"(.*?)"',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for id,title,Ewn0jQCghH1bc4S63BJVKryFzi,TKorEvgUIX72LOwx,oJV18NUZAzPGqMu7tenCxrkfhdl69B,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG in items:
			if '"' in id: id = id.replace('"',hWGMqtBy4wuLaVcj)
			if '"' in title: title = title.replace('"',hWGMqtBy4wuLaVcj)
			if '"' in Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG: Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG = Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG.replace('"',hWGMqtBy4wuLaVcj)
			if '"' in oJV18NUZAzPGqMu7tenCxrkfhdl69B: oJV18NUZAzPGqMu7tenCxrkfhdl69B = oJV18NUZAzPGqMu7tenCxrkfhdl69B.replace('"',hWGMqtBy4wuLaVcj)
			if '"' in Ewn0jQCghH1bc4S63BJVKryFzi: Ewn0jQCghH1bc4S63BJVKryFzi = Ewn0jQCghH1bc4S63BJVKryFzi.replace('"',hWGMqtBy4wuLaVcj)
			if '"' in TKorEvgUIX72LOwx: TKorEvgUIX72LOwx = TKorEvgUIX72LOwx.replace('"',hWGMqtBy4wuLaVcj)
			llxFwq0CUNgQtivJzkHeGV = Str0BupDTFA+'/video/'+id
			title = pIZ5wMHO41EGmve3iKUj92JSzk6(title)
			odaBP0SyZ7IwpmqR = Ewn0jQCghH1bc4S63BJVKryFzi+'::'+TKorEvgUIX72LOwx
			RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,403,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,oJV18NUZAzPGqMu7tenCxrkfhdl69B,odaBP0SyZ7IwpmqR)
		if '"hasNextPage":true' in mMQ3FkNVa4IlxqY:
			l7COkhRWD9uVS60Pte2NoyAaZn = str(int(l7COkhRWD9uVS60Pte2NoyAaZn)+1)
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'صفحة '+l7COkhRWD9uVS60Pte2NoyAaZn,url,404,hWGMqtBy4wuLaVcj,l7COkhRWD9uVS60Pte2NoyAaZn,search)
	return
def c0Gqef3MHdL(search,l7COkhRWD9uVS60Pte2NoyAaZn=hWGMqtBy4wuLaVcj):
	if l7COkhRWD9uVS60Pte2NoyAaZn==hWGMqtBy4wuLaVcj: l7COkhRWD9uVS60Pte2NoyAaZn = '1'
	s4mUPzjv1bRoNTMdenkuBgYl = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":true,"shouldIncludeVideos":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    views {      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment VIDEO_WATCH_LATER_FRAGMENT on Video {  id  isInWatchLater  __typename}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    videos {      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_WATCH_LATER_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	s4mUPzjv1bRoNTMdenkuBgYl = s4mUPzjv1bRoNTMdenkuBgYl.replace('mysearchwords',search)
	s4mUPzjv1bRoNTMdenkuBgYl = s4mUPzjv1bRoNTMdenkuBgYl.replace('mypagelimit','40')
	s4mUPzjv1bRoNTMdenkuBgYl = s4mUPzjv1bRoNTMdenkuBgYl.replace('mypagenumber',l7COkhRWD9uVS60Pte2NoyAaZn)
	url = Str0BupDTFA+'/search/'+search+'/playlists'
	mMQ3FkNVa4IlxqY = ttAp0FJWZbyjvowCHSQM6hlBrE29Dm(s4mUPzjv1bRoNTMdenkuBgYl,search)
	items = trdVA0JvFaD.findall('"node".*?"xid":"(.*?)".*?"name":"(.*?)".*?"xid":"(.*?)".*?"name":"(.*?)".*?"displayName":"(.*?)".*?"thumbnailx240":"(.*?)".*?"total":(.*?),',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	for id,name,GR3rhWIxLNTCjZASv75en9ot2lDYb0,Ewn0jQCghH1bc4S63BJVKryFzi,TKorEvgUIX72LOwx,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,count in items:
		if '"' in GR3rhWIxLNTCjZASv75en9ot2lDYb0: GR3rhWIxLNTCjZASv75en9ot2lDYb0 = GR3rhWIxLNTCjZASv75en9ot2lDYb0.replace('"',hWGMqtBy4wuLaVcj)
		if '"' in Ewn0jQCghH1bc4S63BJVKryFzi: Ewn0jQCghH1bc4S63BJVKryFzi = Ewn0jQCghH1bc4S63BJVKryFzi.replace('"',hWGMqtBy4wuLaVcj)
		if '"' in TKorEvgUIX72LOwx: TKorEvgUIX72LOwx = TKorEvgUIX72LOwx.replace('"',hWGMqtBy4wuLaVcj)
		if '"' in id: id = id.replace('"',hWGMqtBy4wuLaVcj)
		if '"' in name: name = name.replace('"',hWGMqtBy4wuLaVcj)
		if '"' in Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG: Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG = Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG.replace('"',hWGMqtBy4wuLaVcj)
		if '"' in count: count = count.replace('"',hWGMqtBy4wuLaVcj)
		llxFwq0CUNgQtivJzkHeGV = Str0BupDTFA+'/playlist/'+id
		title = 'LIST'+count+':  '+name
		title = pIZ5wMHO41EGmve3iKUj92JSzk6(title)
		odaBP0SyZ7IwpmqR = Ewn0jQCghH1bc4S63BJVKryFzi+'::'+TKorEvgUIX72LOwx
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,401,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,hWGMqtBy4wuLaVcj,odaBP0SyZ7IwpmqR)
	if '"hasNextPage":true' in mMQ3FkNVa4IlxqY:
		l7COkhRWD9uVS60Pte2NoyAaZn = str(int(l7COkhRWD9uVS60Pte2NoyAaZn)+1)
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'صفحة '+l7COkhRWD9uVS60Pte2NoyAaZn,url,405,hWGMqtBy4wuLaVcj,l7COkhRWD9uVS60Pte2NoyAaZn,search)
	return
def k7zPu8ISbWTOtnFRYsXcEyh4KD(search,l7COkhRWD9uVS60Pte2NoyAaZn=hWGMqtBy4wuLaVcj):
	if l7COkhRWD9uVS60Pte2NoyAaZn==hWGMqtBy4wuLaVcj: l7COkhRWD9uVS60Pte2NoyAaZn = '1'
	s4mUPzjv1bRoNTMdenkuBgYl = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":true,"shouldIncludePlaylists":false,"shouldIncludeVideos":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    views {      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment VIDEO_WATCH_LATER_FRAGMENT on Video {  id  isInWatchLater  __typename}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    videos {      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_WATCH_LATER_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	s4mUPzjv1bRoNTMdenkuBgYl = s4mUPzjv1bRoNTMdenkuBgYl.replace('mysearchwords',search)
	s4mUPzjv1bRoNTMdenkuBgYl = s4mUPzjv1bRoNTMdenkuBgYl.replace('mypagelimit','40')
	s4mUPzjv1bRoNTMdenkuBgYl = s4mUPzjv1bRoNTMdenkuBgYl.replace('mypagenumber',l7COkhRWD9uVS60Pte2NoyAaZn)
	url = Str0BupDTFA+'/search/'+search+'/channels'
	mMQ3FkNVa4IlxqY = ttAp0FJWZbyjvowCHSQM6hlBrE29Dm(s4mUPzjv1bRoNTMdenkuBgYl,search)
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('"channels"(.*?)"ChannelConnection"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('"node".*?"name":"(.*?)".*?"displayName":"(.*?)".*?"thumbnailx240":"(.*?)"',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for id,name,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG in items:
			if '"' in id: id = id.replace('"',hWGMqtBy4wuLaVcj)
			if '"' in name: name = name.replace('"',hWGMqtBy4wuLaVcj)
			if '"' in Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG: Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG = Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG.replace('"',hWGMqtBy4wuLaVcj)
			llxFwq0CUNgQtivJzkHeGV = Str0BupDTFA+'/'+id
			title = 'USER:  '+name
			title = pIZ5wMHO41EGmve3iKUj92JSzk6(title)
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,402,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,hWGMqtBy4wuLaVcj,name)
		if '"hasNextPage":true' in mMQ3FkNVa4IlxqY:
			l7COkhRWD9uVS60Pte2NoyAaZn = str(int(l7COkhRWD9uVS60Pte2NoyAaZn)+1)
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'صفحة '+l7COkhRWD9uVS60Pte2NoyAaZn,url,406,hWGMqtBy4wuLaVcj,l7COkhRWD9uVS60Pte2NoyAaZn,search)
	return
def s0mkizQyXL4ZOqCRAg(LtVN3EgwceRi):
	s4mUPzjv1bRoNTMdenkuBgYl = '''{"operationName":"HOME_QUERY","variables":{"space":"nextplore"},"query":"fragment TOPIC_BASE_FRAG on Topic {  id  xid  name  thumbnail: coverURL(size: \\"x532\\")  coverURL: coverURL(size: \\"x532\\")  isFollowed  whitelistStatus {    id    isWhitelisted    __typename  }  __typename}query HOME_QUERY($space: String!) {  home: views {    id    neon {      id      sections(space: $space) {        edges {          node {            id            name            title            description            groupingType            type            relatedComponent {              __typename              ... on Collection {                id                xid                __typename              }              ... on Channel {                id                xid                name                displayName                logoURL(size: \\"x60\\")                __typename              }              ... on Topic {                id                __typename                ...TOPIC_BASE_FRAG              }            }            components {              edges {                node {                  __typename                  ... on Video {                    id                    xid                    title                    thumbnailx60: thumbnailURL(size: \\"x60\\")                    thumbnailx120: thumbnailURL(size: \\"x120\\")                    thumbnailx240: thumbnailURL(size: \\"x240\\")                    thumbnailx360: thumbnailURL(size: \\"x360\\")                    thumbnailx480: thumbnailURL(size: \\"x480\\")                    thumbnailx720: thumbnailURL(size: \\"x720\\")                    aspectRatio                    createdAt                    channel {                      id                      xid                      name                      displayName                      logoURLx25: logoURL(size: \\"x25\\")                      accountType                      __typename                    }                    description                    duration                    __typename                  }                  ... on Live {                    id                    xid                    title                    thumbnailx60: thumbnailURL(size: \\"x60\\")                    thumbnailx120: thumbnailURL(size: \\"x120\\")                    thumbnailx240: thumbnailURL(size: \\"x240\\")                    thumbnailx360: thumbnailURL(size: \\"x360\\")                    thumbnailx480: thumbnailURL(size: \\"x480\\")                    thumbnailx720: thumbnailURL(size: \\"x720\\")                    aspectRatio                    createdAt                    channel {                      id                      xid                      name                      displayName                      logoURLx25: logoURL(size: \\"x25\\")                      accountType                      __typename                    }                    startAt                    __typename                  }                }                __typename              }              __typename            }            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	J3KRlV0tIgThaW5zi2rqUFA = ttAp0FJWZbyjvowCHSQM6hlBrE29Dm(s4mUPzjv1bRoNTMdenkuBgYl)
	if J3KRlV0tIgThaW5zi2rqUFA:
		YSP2gzXmK5e3FBNLD = Cy9ow3c21nABMjzqeaIT('dict',J3KRlV0tIgThaW5zi2rqUFA)
		D62v7VwWTe = YSP2gzXmK5e3FBNLD['data']['home']['neon']['sections']['edges']
		if not LtVN3EgwceRi:
			cBlbdvgwYaiHtXPo2n = []
			for Mrl489G7TspXzBvJOWiu in D62v7VwWTe:
				Z3JWB2duYzg9iMAELR = Mrl489G7TspXzBvJOWiu['node']['title']
				if Z3JWB2duYzg9iMAELR not in cBlbdvgwYaiHtXPo2n: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+Z3JWB2duYzg9iMAELR,hWGMqtBy4wuLaVcj,414,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,Z3JWB2duYzg9iMAELR)
				cBlbdvgwYaiHtXPo2n.append(Z3JWB2duYzg9iMAELR)
		else:
			for Mrl489G7TspXzBvJOWiu in D62v7VwWTe:
				Z3JWB2duYzg9iMAELR = Mrl489G7TspXzBvJOWiu['node']['title']
				if Z3JWB2duYzg9iMAELR==LtVN3EgwceRi:
					ob0BR4iZDH6F1yaArYu8PepNh9OL = Mrl489G7TspXzBvJOWiu['node']['components']['edges']
					for d7dK8DY0PCzugEtmZ5FOpBfx2XIv in ob0BR4iZDH6F1yaArYu8PepNh9OL:
						oJV18NUZAzPGqMu7tenCxrkfhdl69B = str(d7dK8DY0PCzugEtmZ5FOpBfx2XIv['node']['duration'])
						title = emr1Lf523Ti0OtcNgxP(d7dK8DY0PCzugEtmZ5FOpBfx2XIv['node']['title'])
						title = title.replace('\/','/')
						oo62gRQhBFXzjDWIOHfyES = d7dK8DY0PCzugEtmZ5FOpBfx2XIv['node']['xid']
						Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG = d7dK8DY0PCzugEtmZ5FOpBfx2XIv['node']['thumbnailx480']
						Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG = Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG.replace('\/','/')
						llxFwq0CUNgQtivJzkHeGV = Str0BupDTFA+'/video/'+oo62gRQhBFXzjDWIOHfyES
						RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,403,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,oJV18NUZAzPGqMu7tenCxrkfhdl69B)
	return
def DnJb5u69KVIf3Q1NFse4LW(search,l7COkhRWD9uVS60Pte2NoyAaZn=hWGMqtBy4wuLaVcj):
	if l7COkhRWD9uVS60Pte2NoyAaZn==hWGMqtBy4wuLaVcj: l7COkhRWD9uVS60Pte2NoyAaZn = '1'
	s4mUPzjv1bRoNTMdenkuBgYl = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeTopics":false,"shouldIncludeVideos":false,"shouldIncludeLives":true,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    id    views {      id      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  aspectRatio  __typename}fragment VIDEO_FAVORITES_FRAGMENT on Media {  __typename  ... on Video {    id    viewerEngagement {      id      favorited      __typename    }    __typename  }  ... on Live {    id    viewerEngagement {      id      favorited      __typename    }    __typename  }}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}fragment TOPIC_BASE_FRAG on Topic {  id  xid  name  videos(sort: \\"recent\\", first: 5) {    pageInfo {      hasNextPage      nextPage      __typename    }    edges {      node {        id        ...VIDEO_BASE_FRAGMENT        ...VIDEO_FAVORITES_FRAGMENT        __typename      }      __typename    }    __typename  }  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeTopics: Boolean!, $shouldIncludeLives: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(      query: $query      first: $limit      page: $page      sort: $sortByVideos      durationMin: $durationMinVideos      durationMax: $durationMaxVideos      createdAfter: $createdAfterVideos    ) @include(if: $shouldIncludeVideos) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_FAVORITES_FRAGMENT          __typename        }        __typename      }      __typename    }    lives(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeLives) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          xid          title          thumbnail: thumbnailURL(size: \\"x240\\")          thumbnailx60: thumbnailURL(size: \\"x60\\")          thumbnailx120: thumbnailURL(size: \\"x120\\")          thumbnailx240: thumbnailURL(size: \\"x240\\")          thumbnailx720: thumbnailURL(size: \\"x720\\")          audienceCount          aspectRatio          isOnAir          channel {            id            xid            name            displayName            accountType            __typename          }          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    topics(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeTopics) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...TOPIC_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	s4mUPzjv1bRoNTMdenkuBgYl = s4mUPzjv1bRoNTMdenkuBgYl.replace('mysearchwords',search)
	s4mUPzjv1bRoNTMdenkuBgYl = s4mUPzjv1bRoNTMdenkuBgYl.replace('mypagelimit','40')
	s4mUPzjv1bRoNTMdenkuBgYl = s4mUPzjv1bRoNTMdenkuBgYl.replace('mypagenumber',l7COkhRWD9uVS60Pte2NoyAaZn)
	url = Str0BupDTFA+'/search/'+search+'/lives'
	J3KRlV0tIgThaW5zi2rqUFA = ttAp0FJWZbyjvowCHSQM6hlBrE29Dm(s4mUPzjv1bRoNTMdenkuBgYl,search)
	if J3KRlV0tIgThaW5zi2rqUFA:
		YSP2gzXmK5e3FBNLD = Cy9ow3c21nABMjzqeaIT('dict',J3KRlV0tIgThaW5zi2rqUFA)
		try: D62v7VwWTe = YSP2gzXmK5e3FBNLD['data']['search']['lives']['edges']
		except: D62v7VwWTe = []
		for Mrl489G7TspXzBvJOWiu in D62v7VwWTe:
			name = Mrl489G7TspXzBvJOWiu['node']['title']
			name = emr1Lf523Ti0OtcNgxP(name)
			oo62gRQhBFXzjDWIOHfyES = Mrl489G7TspXzBvJOWiu['node']['xid']
			llxFwq0CUNgQtivJzkHeGV = Str0BupDTFA+'/video/'+oo62gRQhBFXzjDWIOHfyES
			RLDCGt8kq3OVmnzgx1rbi2f7F('live',n0qFKQWhiBYXoTrvejVHUA4+'LIVE: '+name,llxFwq0CUNgQtivJzkHeGV,403)
		if '"hasNextPage":true' in J3KRlV0tIgThaW5zi2rqUFA:
			l7COkhRWD9uVS60Pte2NoyAaZn = str(int(l7COkhRWD9uVS60Pte2NoyAaZn)+1)
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'صفحة '+l7COkhRWD9uVS60Pte2NoyAaZn,url,415,hWGMqtBy4wuLaVcj,l7COkhRWD9uVS60Pte2NoyAaZn,search)
	return
def F48Fto5bsv6nKu2LCdzDWieHk(search,l7COkhRWD9uVS60Pte2NoyAaZn=hWGMqtBy4wuLaVcj):
	if l7COkhRWD9uVS60Pte2NoyAaZn==hWGMqtBy4wuLaVcj: l7COkhRWD9uVS60Pte2NoyAaZn = '1'
	s4mUPzjv1bRoNTMdenkuBgYl = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeTopics":true,"shouldIncludeVideos":false,"shouldIncludeLives":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    id    views {      id      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  aspectRatio  __typename}fragment VIDEO_FAVORITES_FRAGMENT on Media {  __typename  ... on Video {    id    isInWatchLater    __typename  }  ... on Live {    id    isInWatchLater    __typename  }}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}fragment TOPIC_BASE_FRAG on Topic {  id  xid  name  videos(sort: \\"recent\\", first: 5) {    pageInfo {      hasNextPage      nextPage      __typename    }    edges {      node {        id        ...VIDEO_BASE_FRAGMENT        ...VIDEO_FAVORITES_FRAGMENT        __typename      }      __typename    }    __typename  }  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeTopics: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(      query: $query      first: $limit      page: $page      sort: $sortByVideos      durationMin: $durationMinVideos      durationMax: $durationMaxVideos      createdAfter: $createdAfterVideos    ) @include(if: $shouldIncludeVideos) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_FAVORITES_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    topics(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeTopics) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...TOPIC_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	s4mUPzjv1bRoNTMdenkuBgYl = s4mUPzjv1bRoNTMdenkuBgYl.replace('mysearchwords',search)
	s4mUPzjv1bRoNTMdenkuBgYl = s4mUPzjv1bRoNTMdenkuBgYl.replace('mypagelimit','40')
	s4mUPzjv1bRoNTMdenkuBgYl = s4mUPzjv1bRoNTMdenkuBgYl.replace('mypagenumber',l7COkhRWD9uVS60Pte2NoyAaZn)
	url = Str0BupDTFA+'/search/'+search+'/topics'
	J3KRlV0tIgThaW5zi2rqUFA = ttAp0FJWZbyjvowCHSQM6hlBrE29Dm(s4mUPzjv1bRoNTMdenkuBgYl,search)
	if J3KRlV0tIgThaW5zi2rqUFA:
		YSP2gzXmK5e3FBNLD = Cy9ow3c21nABMjzqeaIT('dict',J3KRlV0tIgThaW5zi2rqUFA)
		try: D62v7VwWTe = YSP2gzXmK5e3FBNLD['data']['search']['topics']['edges']
		except: D62v7VwWTe = []
		for Mrl489G7TspXzBvJOWiu in D62v7VwWTe:
			name = Mrl489G7TspXzBvJOWiu['node']['name']
			oo62gRQhBFXzjDWIOHfyES = Mrl489G7TspXzBvJOWiu['node']['xid']
			llxFwq0CUNgQtivJzkHeGV = Str0BupDTFA+'/topic/'+oo62gRQhBFXzjDWIOHfyES
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'TOPIC: '+name,llxFwq0CUNgQtivJzkHeGV,413)
		if '"hasNextPage":true' in J3KRlV0tIgThaW5zi2rqUFA:
			l7COkhRWD9uVS60Pte2NoyAaZn = str(int(l7COkhRWD9uVS60Pte2NoyAaZn)+1)
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'صفحة '+l7COkhRWD9uVS60Pte2NoyAaZn,url,412,hWGMqtBy4wuLaVcj,l7COkhRWD9uVS60Pte2NoyAaZn,search)
	return
def IIn3efXuyw5Vo2PKGATpN1bYLxmt(url,l7COkhRWD9uVS60Pte2NoyAaZn=hWGMqtBy4wuLaVcj):
	if l7COkhRWD9uVS60Pte2NoyAaZn==hWGMqtBy4wuLaVcj: l7COkhRWD9uVS60Pte2NoyAaZn = '1'
	oo62gRQhBFXzjDWIOHfyES = url.split('/')[-1]
	s4mUPzjv1bRoNTMdenkuBgYl = '''{"operationName":"DISCOVERY_TOPIC_MAIN_QUERY","variables":{"page":mypagenumber,"xid":"mytopicid"},"query":"fragment TOPIC_VIDEO_FRAGMENT on Video {  id  xid  title  duration  isLiked  isInWatchLater  isCreatedForKids  createdAt  isExplicit  videoHeight: height  videoWidth: width  category  channel {    id    xid    name    displayName    logoURLx25: logoURL(size: \\"x25\\")    logoURL(size: \\"x60\\")    accountType    __typename  }  stats {    id    views {      id      total      __typename    }    __typename  }  language {    id    codeAlpha2    __typename  }  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  bestAvailableQuality  aspectRatio  isPublished  __typename}query DISCOVERY_TOPIC_MAIN_QUERY($xid: String!, $page: Int = 1) {  topic(xid: $xid) {    id    xid    name    videos(sort: \\"recent\\", first: 30, page: $page) {      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...TOPIC_VIDEO_FRAGMENT          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	s4mUPzjv1bRoNTMdenkuBgYl = s4mUPzjv1bRoNTMdenkuBgYl.replace('mytopicid',oo62gRQhBFXzjDWIOHfyES)
	s4mUPzjv1bRoNTMdenkuBgYl = s4mUPzjv1bRoNTMdenkuBgYl.replace('mypagenumber',l7COkhRWD9uVS60Pte2NoyAaZn)
	J3KRlV0tIgThaW5zi2rqUFA = ttAp0FJWZbyjvowCHSQM6hlBrE29Dm(s4mUPzjv1bRoNTMdenkuBgYl)
	if J3KRlV0tIgThaW5zi2rqUFA:
		YSP2gzXmK5e3FBNLD = Cy9ow3c21nABMjzqeaIT('dict',J3KRlV0tIgThaW5zi2rqUFA)
		D62v7VwWTe = YSP2gzXmK5e3FBNLD['data']['topic']['videos']['edges']
		for Mrl489G7TspXzBvJOWiu in D62v7VwWTe:
			oJV18NUZAzPGqMu7tenCxrkfhdl69B = str(Mrl489G7TspXzBvJOWiu['node']['duration'])
			title = emr1Lf523Ti0OtcNgxP(Mrl489G7TspXzBvJOWiu['node']['title'])
			title = title.replace('\/','/')
			oo62gRQhBFXzjDWIOHfyES = Mrl489G7TspXzBvJOWiu['node']['xid']
			Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG = Mrl489G7TspXzBvJOWiu['node']['thumbnailx480']
			Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG = Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG.replace('\/','/')
			llxFwq0CUNgQtivJzkHeGV = Str0BupDTFA+'/video/'+oo62gRQhBFXzjDWIOHfyES
			RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,403,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,oJV18NUZAzPGqMu7tenCxrkfhdl69B)
		if '"hasNextPage":true' in J3KRlV0tIgThaW5zi2rqUFA:
			l7COkhRWD9uVS60Pte2NoyAaZn = str(int(l7COkhRWD9uVS60Pte2NoyAaZn)+1)
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'صفحة '+l7COkhRWD9uVS60Pte2NoyAaZn,url,413,hWGMqtBy4wuLaVcj,l7COkhRWD9uVS60Pte2NoyAaZn)
	return
def nHu2UCtXBN(url,odaBP0SyZ7IwpmqR):
	id = url.split('/')[-1]
	Ewn0jQCghH1bc4S63BJVKryFzi,TKorEvgUIX72LOwx = odaBP0SyZ7IwpmqR.split('::',1)
	llxFwq0CUNgQtivJzkHeGV = Str0BupDTFA+'/'+Ewn0jQCghH1bc4S63BJVKryFzi
	TKorEvgUIX72LOwx = pIZ5wMHO41EGmve3iKUj92JSzk6(TKorEvgUIX72LOwx)
	title = hXB0vKVQ5PRI91SDTprMdfuHEm4+'OWNER:  '+TKorEvgUIX72LOwx+YYSh2J6BIrsm8
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,402,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,TKorEvgUIX72LOwx)
	s4mUPzjv1bRoNTMdenkuBgYl = '''{"operationName":"DISCOVERY_QUEUE_QUERY","variables":{"collectionXid":"myplaylistid","videoXid":"x7s7qbn"},"query":"query DISCOVERY_QUEUE_QUERY($videoXid: String!, $collectionXid: String, $device: String, $videoCountPerSection: Int) {  views {    id    neon {      id      sections(device: $device, space: \\"watching\\", followingChannelXids: [], followingTopicXids: [], watchedVideoXids: [], context: {mediaXid: $videoXid, collectionXid: $collectionXid}, first: 20) {        edges {          node {            id            name            groupingType            relatedComponent {              ... on Channel {                __typename                id                xid                name                displayName                logoURL(size: \\"x60\\")                logoURLx25: logoURL(size: \\"x25\\")              }              ... on Topic {                __typename                id                xid                name                names {                  edges {                    node {                      id                      name                      language {                        id                        codeAlpha2                        __typename                      }                      __typename                    }                    __typename                  }                  __typename                }              }              ... on Collection {                __typename                id                xid                name              }              __typename            }            components(first: $videoCountPerSection) {              metadata {                algorithm {                  name                  version                  uuid                  __typename                }                __typename              }              edges {                node {                  ... on Video {                    __typename                    id                    xid                    title                    duration                    thumbnailx60: thumbnailURL(size: \\"x60\\")                    thumbnailx120: thumbnailURL(size: \\"x120\\")                    thumbnailx240: thumbnailURL(size: \\"x240\\")                    thumbnailx720: thumbnailURL(size: \\"x720\\")                    channel {                      id                      xid                      accountType                      displayName                      logoURLx25: logoURL(size: \\"x25\\")                      logoURL(size: \\"x60\\")                      __typename                    }                  }                  ... on Channel {                    __typename                    id                    xid                    name                    displayName                    accountType                    logoURL(size: \\"x60\\")                  }                  __typename                }                __typename              }              __typename            }            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	s4mUPzjv1bRoNTMdenkuBgYl = s4mUPzjv1bRoNTMdenkuBgYl.replace('myplaylistid',id)
	mMQ3FkNVa4IlxqY = ttAp0FJWZbyjvowCHSQM6hlBrE29Dm(s4mUPzjv1bRoNTMdenkuBgYl)
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('"collection_videos"(.*?)"SectionEdge"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('"node".*?"xid":"(.*?)".*?"title":"(.*?)".*?"duration":(.*?),.*?"thumbnailx240":"(.*?)".*?"xid":"(.*?)".*?"displayName":"(.*?)"',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for id,title,oJV18NUZAzPGqMu7tenCxrkfhdl69B,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,Ewn0jQCghH1bc4S63BJVKryFzi,TKorEvgUIX72LOwx in items:
			if '"' in id: id = id.replace('"',hWGMqtBy4wuLaVcj)
			if '"' in title: title = title.replace('"',hWGMqtBy4wuLaVcj)
			if '"' in Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG: Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG = Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG.replace('"',hWGMqtBy4wuLaVcj)
			if '"' in oJV18NUZAzPGqMu7tenCxrkfhdl69B: oJV18NUZAzPGqMu7tenCxrkfhdl69B = oJV18NUZAzPGqMu7tenCxrkfhdl69B.replace('"',hWGMqtBy4wuLaVcj)
			if '"' in Ewn0jQCghH1bc4S63BJVKryFzi: Ewn0jQCghH1bc4S63BJVKryFzi = Ewn0jQCghH1bc4S63BJVKryFzi.replace('"',hWGMqtBy4wuLaVcj)
			if '"' in TKorEvgUIX72LOwx: TKorEvgUIX72LOwx = TKorEvgUIX72LOwx.replace('"',hWGMqtBy4wuLaVcj)
			llxFwq0CUNgQtivJzkHeGV = Str0BupDTFA+'/video/'+id
			title = pIZ5wMHO41EGmve3iKUj92JSzk6(title)
			odaBP0SyZ7IwpmqR = Ewn0jQCghH1bc4S63BJVKryFzi+'::'+TKorEvgUIX72LOwx
			RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,403,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,oJV18NUZAzPGqMu7tenCxrkfhdl69B,odaBP0SyZ7IwpmqR)
	return
def LK7NTfdxmeiS2l8ZHDqcRQGwb(url,l7COkhRWD9uVS60Pte2NoyAaZn=hWGMqtBy4wuLaVcj):
	if l7COkhRWD9uVS60Pte2NoyAaZn==hWGMqtBy4wuLaVcj: l7COkhRWD9uVS60Pte2NoyAaZn = '1'
	VzAiKmWdsgw9XfIuF1e0 = url.split('/')[-2]
	if 'sort=' in url: sort = url.split('sort=')[1].split('&')[0]
	else: sort = 'recent'
	s4mUPzjv1bRoNTMdenkuBgYl = '''{"operationName":"CHANNEL_VIDEOS_QUERY","variables":{"channel_xid":"mychannelid","sort":"mysortmethod","page":mypagenumber},"query":"fragment CHANNEL_BASE_FRAGMENT on Channel {  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  isFollowed  accountType  __typename}fragment CHANNEL_IMAGES_FRAGMENT on Channel {  id  coverURLx375: coverURL(size: \\"x375\\")  __typename}fragment CHANNEL_UPDATED_FRAGMENT on Channel {  id  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}fragment CHANNEL_COMPLETE_FRAGMENT on Channel {  id  ...CHANNEL_BASE_FRAGMENT  ...CHANNEL_IMAGES_FRAGMENT  ...CHANNEL_UPDATED_FRAGMENT  description  coverURL1024x: coverURL(size: \\"1024x\\")  coverURL1920x: coverURL(size: \\"1920x\\")  externalLinks {    facebookURL    twitterURL    websiteURL    instagramURL    __typename  }  __typename}fragment CHANNEL_FRAGMENT on Channel {  accountType  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  coverURLx375: coverURL(size: \\"x375\\")  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}fragment VIDEO_FRAGMENT on Video {  id  xid  title  viewCount  duration  createdAt  isInWatchLater  channel {    id    ...CHANNEL_FRAGMENT    __typename  }  thumbURLx240: thumbnailURL(size: \\"x240\\")  thumbURLx360: thumbnailURL(size: \\"x360\\")  thumbURLx480: thumbnailURL(size: \\"x480\\")  thumbURLx720: thumbnailURL(size: \\"x720\\")  __typename}query CHANNEL_VIDEOS_QUERY($channel_xid: String!, $sort: String, $page: Int!) {  channel(xid: $channel_xid) {    id    ...CHANNEL_COMPLETE_FRAGMENT    channel_videos_all_videos: videos(sort: $sort, page: $page, first: mypagelimit) {      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...VIDEO_FRAGMENT          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	s4mUPzjv1bRoNTMdenkuBgYl = s4mUPzjv1bRoNTMdenkuBgYl.replace('mychannelid',VzAiKmWdsgw9XfIuF1e0)
	s4mUPzjv1bRoNTMdenkuBgYl = s4mUPzjv1bRoNTMdenkuBgYl.replace('mypagelimit','40')
	s4mUPzjv1bRoNTMdenkuBgYl = s4mUPzjv1bRoNTMdenkuBgYl.replace('mypagenumber',l7COkhRWD9uVS60Pte2NoyAaZn)
	s4mUPzjv1bRoNTMdenkuBgYl = s4mUPzjv1bRoNTMdenkuBgYl.replace('mysortmethod',sort)
	mMQ3FkNVa4IlxqY = ttAp0FJWZbyjvowCHSQM6hlBrE29Dm(s4mUPzjv1bRoNTMdenkuBgYl)
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('"channel_videos_all_videos"(.*?)"VideoConnection"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('"node".*?"xid":"(.*?)".*?"title":"(.*?)".*?"duration":(.*?),.*?"name":"(.*?)".*?"displayName":"(.*?)".*?"thumbURLx240":"(.*?)"',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for id,title,oJV18NUZAzPGqMu7tenCxrkfhdl69B,Ewn0jQCghH1bc4S63BJVKryFzi,TKorEvgUIX72LOwx,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG in items:
			if '"' in id: id = id.replace('"',hWGMqtBy4wuLaVcj)
			if '"' in title: title = title.replace('"',hWGMqtBy4wuLaVcj)
			if '"' in Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG: Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG = Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG.replace('"',hWGMqtBy4wuLaVcj)
			if '"' in oJV18NUZAzPGqMu7tenCxrkfhdl69B: oJV18NUZAzPGqMu7tenCxrkfhdl69B = oJV18NUZAzPGqMu7tenCxrkfhdl69B.replace('"',hWGMqtBy4wuLaVcj)
			if '"' in Ewn0jQCghH1bc4S63BJVKryFzi: Ewn0jQCghH1bc4S63BJVKryFzi = Ewn0jQCghH1bc4S63BJVKryFzi.replace('"',hWGMqtBy4wuLaVcj)
			if '"' in TKorEvgUIX72LOwx: TKorEvgUIX72LOwx = TKorEvgUIX72LOwx.replace('"',hWGMqtBy4wuLaVcj)
			llxFwq0CUNgQtivJzkHeGV = Str0BupDTFA+'/video/'+id
			title = pIZ5wMHO41EGmve3iKUj92JSzk6(title)
			odaBP0SyZ7IwpmqR = Ewn0jQCghH1bc4S63BJVKryFzi+'::'+TKorEvgUIX72LOwx
			RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,403,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,oJV18NUZAzPGqMu7tenCxrkfhdl69B,odaBP0SyZ7IwpmqR)
		if '"hasNextPage":true' in mMQ3FkNVa4IlxqY:
			l7COkhRWD9uVS60Pte2NoyAaZn = str(int(l7COkhRWD9uVS60Pte2NoyAaZn)+1)
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'صفحة '+l7COkhRWD9uVS60Pte2NoyAaZn,url,408,hWGMqtBy4wuLaVcj,l7COkhRWD9uVS60Pte2NoyAaZn)
	return
def naLWJZHe4zFoV(url,l7COkhRWD9uVS60Pte2NoyAaZn=hWGMqtBy4wuLaVcj):
	if l7COkhRWD9uVS60Pte2NoyAaZn==hWGMqtBy4wuLaVcj: l7COkhRWD9uVS60Pte2NoyAaZn = '1'
	VzAiKmWdsgw9XfIuF1e0 = url.split('/')[-2]
	if 'sort=' in url: sort = url.split('sort=')[1].split('&')[0]
	else: sort = 'recent'
	s4mUPzjv1bRoNTMdenkuBgYl = '''{"operationName":"CHANNEL_COLLECTIONS_QUERY","variables":{"channel_xid":"mychannelid","sort":"mysortmethod","page":mypagenumber},"query":"fragment CHANNEL_BASE_FRAGMENT on Channel {  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  isFollowed  accountType  __typename}fragment CHANNEL_IMAGES_FRAGMENT on Channel {  id  coverURLx375: coverURL(size: \\"x375\\")  __typename}fragment CHANNEL_UPDATED_FRAGMENT on Channel {  id  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}fragment CHANNEL_COMPLETE_FRAGMENT on Channel {  id  ...CHANNEL_BASE_FRAGMENT  ...CHANNEL_IMAGES_FRAGMENT  ...CHANNEL_UPDATED_FRAGMENT  description  coverURL1024x: coverURL(size: \\"1024x\\")  coverURL1920x: coverURL(size: \\"1920x\\")  externalLinks {    facebookURL    twitterURL    websiteURL    instagramURL    __typename  }  __typename}fragment CHANNEL_FRAGMENT on Channel {  accountType  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  coverURLx375: coverURL(size: \\"x375\\")  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}query CHANNEL_COLLECTIONS_QUERY($channel_xid: String!, $sort: String, $page: Int!) {  channel(xid: $channel_xid) {    id    ...CHANNEL_COMPLETE_FRAGMENT    channel_playlist_collections: collections(sort: $sort, page: $page, first: mypagelimit) {      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          xid          updatedAt          name          description          thumbURLx240: thumbnailURL(size: \\"x240\\")          thumbURLx360: thumbnailURL(size: \\"x360\\")          thumbURLx480: thumbnailURL(size: \\"x480\\")          stats {            videos {              total              __typename            }            __typename          }          channel {            id            ...CHANNEL_FRAGMENT            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	s4mUPzjv1bRoNTMdenkuBgYl = s4mUPzjv1bRoNTMdenkuBgYl.replace('mychannelid',VzAiKmWdsgw9XfIuF1e0)
	s4mUPzjv1bRoNTMdenkuBgYl = s4mUPzjv1bRoNTMdenkuBgYl.replace('mypagelimit','40')
	s4mUPzjv1bRoNTMdenkuBgYl = s4mUPzjv1bRoNTMdenkuBgYl.replace('mypagenumber',l7COkhRWD9uVS60Pte2NoyAaZn)
	s4mUPzjv1bRoNTMdenkuBgYl = s4mUPzjv1bRoNTMdenkuBgYl.replace('mysortmethod',sort)
	mMQ3FkNVa4IlxqY = ttAp0FJWZbyjvowCHSQM6hlBrE29Dm(s4mUPzjv1bRoNTMdenkuBgYl)
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('"channel_playlist_collections"(.*?)"CollectionConnection"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('"node".*?"xid":"(.*?)".*?"name":"(.*?)".*?"thumbURLx240":"(.*?)".*?"total":(.*?),.*?"xid":"(.*?)".*?"name":"(.*?)".*?"displayName":"(.*?)"',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for id,name,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,count,GR3rhWIxLNTCjZASv75en9ot2lDYb0,Ewn0jQCghH1bc4S63BJVKryFzi,TKorEvgUIX72LOwx in items:
			if '"' in id: id = id.replace('"',hWGMqtBy4wuLaVcj)
			if '"' in name: name = name.replace('"',hWGMqtBy4wuLaVcj)
			if '"' in Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG: Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG = Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG.replace('"',hWGMqtBy4wuLaVcj)
			if '"' in count: count = count.replace('"',hWGMqtBy4wuLaVcj)
			if '"' in GR3rhWIxLNTCjZASv75en9ot2lDYb0: GR3rhWIxLNTCjZASv75en9ot2lDYb0 = GR3rhWIxLNTCjZASv75en9ot2lDYb0.replace('"',hWGMqtBy4wuLaVcj)
			if '"' in Ewn0jQCghH1bc4S63BJVKryFzi: Ewn0jQCghH1bc4S63BJVKryFzi = Ewn0jQCghH1bc4S63BJVKryFzi.replace('"',hWGMqtBy4wuLaVcj)
			if '"' in TKorEvgUIX72LOwx: TKorEvgUIX72LOwx = TKorEvgUIX72LOwx.replace('"',hWGMqtBy4wuLaVcj)
			llxFwq0CUNgQtivJzkHeGV = Str0BupDTFA+'/playlist/'+id
			title = 'LIST'+count+':  '+name
			title = pIZ5wMHO41EGmve3iKUj92JSzk6(title)
			odaBP0SyZ7IwpmqR = Ewn0jQCghH1bc4S63BJVKryFzi+'::'+TKorEvgUIX72LOwx
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,401,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,hWGMqtBy4wuLaVcj,odaBP0SyZ7IwpmqR)
		if '"hasNextPage":true' in mMQ3FkNVa4IlxqY:
			l7COkhRWD9uVS60Pte2NoyAaZn = str(int(l7COkhRWD9uVS60Pte2NoyAaZn)+1)
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'صفحة '+l7COkhRWD9uVS60Pte2NoyAaZn,url,407,hWGMqtBy4wuLaVcj,l7COkhRWD9uVS60Pte2NoyAaZn)
	return
def J7JHrqKFOtpGXlhoAY8M(url,odi3k0vOAlr):
	VzAiKmWdsgw9XfIuF1e0 = url.split('/')[3]
	s4mUPzjv1bRoNTMdenkuBgYl = '''{"operationName":"CHANNEL_QUERY_DESKTOP","variables":{"channel_name":"mychannelid","relatedChannels":100},"query":"fragment CHANNEL_FRAGMENT on Channel {  accountType  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  coverURLx375: coverURL(size: \\"x375\\")  isFollowed  stats {    id    views {      id      total      __typename    }    followers {      id      total      __typename    }    videos {      id      total      __typename    }    __typename  }  __typename}fragment LIVE_FRAGMENT on Live {  id  xid  title  startAt  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  channel {    id    ...CHANNEL_FRAGMENT    __typename  }  __typename}fragment VIDEO_FRAGMENT on Video {  id  xid  title  viewCount  duration  createdAt  isInWatchLater  channel {    id    ...CHANNEL_FRAGMENT    __typename  }  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment CHANNEL_MAIN_FRAGMENT on Channel {  id  xid  name  displayName  description  accountType  isArtist  logoURL(size: \\"x60\\")  coverURL1024x: coverURL(size: \\"1024x\\")  coverURL1920x: coverURL(size: \\"1920x\\")  isFollowed  tagline  country {    id    codeAlpha2    __typename  }  stats {    id    views {      id      total      __typename    }    followers {      id      total      __typename    }    videos {      id      total      __typename    }    __typename  }  externalLinks {    id    facebookURL    twitterURL    websiteURL    instagramURL    pinterestURL    __typename  }  channel_lives_now: lives(first: 4, isOnAir: true) {    edges {      node {        id        ...LIVE_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_lives_scheduled: lives(first: 4, startIn: 7200) {    edges {      node {        id        ...LIVE_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_featured_videos: videos(first: 4, isFeatured: true) {    edges {      node {        id        ...VIDEO_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_all_videos: videos(first: 4) {    edges {      node {        id        ...VIDEO_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_most_viewed: videos(first: 4, sort: \\"visited\\") {    edges {      node {        id        ...VIDEO_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_collections: collections(first: 4) {    edges {      node {        id        xid        name        description        stats {          id          videos {            id            total            __typename          }          __typename        }        thumbnailx240: thumbnailURL(size: \\"x240\\")        thumbnailx360: thumbnailURL(size: \\"x360\\")        thumbnailx480: thumbnailURL(size: \\"x480\\")        channel {          id          ...CHANNEL_FRAGMENT          __typename        }        __typename      }      __typename    }    __typename  }  channel_related_channel: networkChannels(    hasPublicVideos: true    first: $relatedChannels  ) {    edges {      node {        id        ...CHANNEL_FRAGMENT        __typename      }      __typename    }    __typename  }  __typename}query CHANNEL_QUERY_DESKTOP($channel_name: String!, $relatedChannels: Int) {  channel(name: $channel_name) {    id    ...CHANNEL_MAIN_FRAGMENT    __typename  }}"}'''
	s4mUPzjv1bRoNTMdenkuBgYl = s4mUPzjv1bRoNTMdenkuBgYl.replace('mychannelid',VzAiKmWdsgw9XfIuF1e0)
	mMQ3FkNVa4IlxqY = ttAp0FJWZbyjvowCHSQM6hlBrE29Dm(s4mUPzjv1bRoNTMdenkuBgYl)
	ksyYZIKnjSUGMzBewf6d2891Cpa = TPDQ5L9eWpIJcrM3YH48Cs6.loads(mMQ3FkNVa4IlxqY)
	try: items = ksyYZIKnjSUGMzBewf6d2891Cpa['data']['channel'][odi3k0vOAlr]['edges']
	except: items = []
	if not items: RLDCGt8kq3OVmnzgx1rbi2f7F('link',n0qFKQWhiBYXoTrvejVHUA4+'لا توجد نتائج',hWGMqtBy4wuLaVcj,9999)
	else:
		for ImYg2jxU6Lc9Q1C4Oko in items:
			Y6jARZ8V4mL2vKxeudJnktND = ImYg2jxU6Lc9Q1C4Oko['node']
			oo62gRQhBFXzjDWIOHfyES = Y6jARZ8V4mL2vKxeudJnktND['xid']
			keys = list(Y6jARZ8V4mL2vKxeudJnktND.keys())
			QK78qGA60yEIUu2MkfgO5wLx3Zb = Y6jARZ8V4mL2vKxeudJnktND['__typename'].lower()
			if QK78qGA60yEIUu2MkfgO5wLx3Zb=='channel':
				name = Y6jARZ8V4mL2vKxeudJnktND['name']
				m9GkaVKsCPlS5RvQJtyE6iTjO0 = Y6jARZ8V4mL2vKxeudJnktND['displayName']
				title = 'USER:  '+m9GkaVKsCPlS5RvQJtyE6iTjO0
				Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG = Y6jARZ8V4mL2vKxeudJnktND['coverURLx375']
			else:
				name = Y6jARZ8V4mL2vKxeudJnktND['channel']['name']
				m9GkaVKsCPlS5RvQJtyE6iTjO0 = Y6jARZ8V4mL2vKxeudJnktND['channel']['displayName']
				title = Y6jARZ8V4mL2vKxeudJnktND['title']
				Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG = Y6jARZ8V4mL2vKxeudJnktND['thumbnailx360']
				if QK78qGA60yEIUu2MkfgO5wLx3Zb=='live': title = 'LIVE:  '+title
			title = pIZ5wMHO41EGmve3iKUj92JSzk6(title)
			odaBP0SyZ7IwpmqR = name+'::'+m9GkaVKsCPlS5RvQJtyE6iTjO0
			if VKiGj1LundAJQwEXcqgxC:
				title = title.encode(a7VXeDU82IfQEnPZAdiT)
				odaBP0SyZ7IwpmqR = odaBP0SyZ7IwpmqR.encode(a7VXeDU82IfQEnPZAdiT)
			if QK78qGA60yEIUu2MkfgO5wLx3Zb=='channel':
				llxFwq0CUNgQtivJzkHeGV = Str0BupDTFA+'/'+oo62gRQhBFXzjDWIOHfyES
				RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,402,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,hWGMqtBy4wuLaVcj,odaBP0SyZ7IwpmqR)
			else:
				if QK78qGA60yEIUu2MkfgO5wLx3Zb=='video': oJV18NUZAzPGqMu7tenCxrkfhdl69B = str(Y6jARZ8V4mL2vKxeudJnktND['duration'])
				else: oJV18NUZAzPGqMu7tenCxrkfhdl69B = hWGMqtBy4wuLaVcj
				llxFwq0CUNgQtivJzkHeGV = Str0BupDTFA+'/video/'+oo62gRQhBFXzjDWIOHfyES
				RLDCGt8kq3OVmnzgx1rbi2f7F(QK78qGA60yEIUu2MkfgO5wLx3Zb,n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,403,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,oJV18NUZAzPGqMu7tenCxrkfhdl69B,odaBP0SyZ7IwpmqR)
	return
def O40YaJMPmgnIQ7A8K(search,l7COkhRWD9uVS60Pte2NoyAaZn=hWGMqtBy4wuLaVcj):
	if l7COkhRWD9uVS60Pte2NoyAaZn==hWGMqtBy4wuLaVcj: l7COkhRWD9uVS60Pte2NoyAaZn = '1'
	s4mUPzjv1bRoNTMdenkuBgYl = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeHashtags":true,"shouldIncludeVideos":false,"shouldIncludeLives":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  duration  aspectRatio  thumbnail(height: PORTRAIT_240) {    id    url    __typename  }  creator {    id    xid    name    displayName    accountType    avatar(height: SQUARE_60) {      id      url      __typename    }    __typename  }  __typename}fragment CHANNEL_BASE_FRAG on Channel {  id  xid  name  displayName  accountType  isFollowed  avatar(height: SQUARE_120) {    id    url    __typename  }  followerEngagement {    id    followDate    __typename  }  metrics {    id    engagement {      id      followers {        edges {          node {            id            total            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  description  thumbnail(height: PORTRAIT_240) {    id    url    __typename  }  creator {    id    xid    name    displayName    accountType    avatar(height: SQUARE_60) {      id      url      __typename    }    __typename  }  metrics {    id    engagement {      id      videos(filter: {visibility: {eq: PUBLIC}}) {        edges {          node {            id            total            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }  __typename}fragment HASHTAG_BASE_FRAG on Hashtag {  id  xid  name  metrics {    id    engagement {      id      videos {        edges {          node {            id            total            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }  __typename}fragment LIVE_BASE_FRAGMENT on Live {  id  xid  title  audienceCount  aspectRatio  isOnAir  thumbnail(height: PORTRAIT_240) {    id    url    __typename  }  creator {    id    xid    name    displayName    accountType    avatar(height: SQUARE_60) {      id      url      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeHashtags: Boolean!, $shouldIncludeLives: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(      query: $query      first: $limit      page: $page      sort: $sortByVideos      durationMin: $durationMinVideos      durationMax: $durationMaxVideos      createdAfter: $createdAfterVideos    ) @include(if: $shouldIncludeVideos) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          __typename        }        __typename      }      __typename    }    lives(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeLives) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...LIVE_BASE_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    hashtags(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeHashtags) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...HASHTAG_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	s4mUPzjv1bRoNTMdenkuBgYl = s4mUPzjv1bRoNTMdenkuBgYl.replace('mysearchwords',search)
	s4mUPzjv1bRoNTMdenkuBgYl = s4mUPzjv1bRoNTMdenkuBgYl.replace('mypagelimit','40')
	s4mUPzjv1bRoNTMdenkuBgYl = s4mUPzjv1bRoNTMdenkuBgYl.replace('mypagenumber',l7COkhRWD9uVS60Pte2NoyAaZn)
	url = Str0BupDTFA+'/search/'+search+'/hashtags'
	J3KRlV0tIgThaW5zi2rqUFA = ttAp0FJWZbyjvowCHSQM6hlBrE29Dm(s4mUPzjv1bRoNTMdenkuBgYl,search)
	if J3KRlV0tIgThaW5zi2rqUFA:
		YSP2gzXmK5e3FBNLD = Cy9ow3c21nABMjzqeaIT('dict',J3KRlV0tIgThaW5zi2rqUFA)
		try: D62v7VwWTe = YSP2gzXmK5e3FBNLD['data']['search']['hashtags']['edges']
		except: D62v7VwWTe = []
		for Mrl489G7TspXzBvJOWiu in D62v7VwWTe:
			name = Mrl489G7TspXzBvJOWiu['node']['name']
			llxFwq0CUNgQtivJzkHeGV = Str0BupDTFA+'/hashtag/'+name[1:]
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'HSHTG: '+name,llxFwq0CUNgQtivJzkHeGV,417)
		if '"hasNextPage":true' in J3KRlV0tIgThaW5zi2rqUFA:
			l7COkhRWD9uVS60Pte2NoyAaZn = str(int(l7COkhRWD9uVS60Pte2NoyAaZn)+1)
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'صفحة '+l7COkhRWD9uVS60Pte2NoyAaZn,url,416,hWGMqtBy4wuLaVcj,l7COkhRWD9uVS60Pte2NoyAaZn,search)
	return
def lo35VBCr0Ji4nFxfLIDujZHhvQ9Abq(url,l7COkhRWD9uVS60Pte2NoyAaZn=hWGMqtBy4wuLaVcj):
	if l7COkhRWD9uVS60Pte2NoyAaZn==hWGMqtBy4wuLaVcj: l7COkhRWD9uVS60Pte2NoyAaZn = '1'
	name = url.split('/')[-1]
	s4mUPzjv1bRoNTMdenkuBgYl = '''{"operationName":"HASHTAG_VIDEOS_QUERY","variables":{"hashtag_name":"#myhashtagname","page":mypagenumber},"query":"fragment FRAG_VIDEO_BASE on Video {  id  xid  title  description  thumbnail: thumbnailURL(size: \\"x240\\")  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  bestAvailableQuality  duration  createdAt  viewerEngagement {    id    liked    favorited    __typename  }  isExplicit  canDisplayAds  aspectRatio  stats {    id    views {      id      total      __typename    }    __typename  }  language {    id    codeAlpha2    __typename  }  videoHeight: height  videoWidth: width  __typename}fragment CHANNEL_BASE_FRAG on Channel {  id  xid  name  displayName  description  logoURL(size: \\"x25\\")  logoURLx60: logoURL(size: \\"x60\\")  coverURL(size: \\"x200\\")  coverURLx1024: coverURL(size: \\"1024x\\")  isFollowed  isArtist  accountType  __typename}fragment VIDEO_FRAG on Video {  id  ...FRAG_VIDEO_BASE  channel {    id    ...CHANNEL_BASE_FRAG    __typename  }  __typename}query HASHTAG_VIDEOS_QUERY($hashtag_name: String!, $page: Int!) {  contentFeed(    name: HASHTAG    filter: {name: {eq: $hashtag_name}, post: {eq: VIDEO}}    sort: {create: DESC}    page: $page    first: 30  ) {    totalCount    pageInfo {      hasNextPage      nextPage      __typename    }    edges {      node {        post {          ...VIDEO_FRAG          __typename        }        featured        __typename      }      __typename    }    __typename  }}"}'''
	s4mUPzjv1bRoNTMdenkuBgYl = s4mUPzjv1bRoNTMdenkuBgYl.replace('myhashtagname',name)
	s4mUPzjv1bRoNTMdenkuBgYl = s4mUPzjv1bRoNTMdenkuBgYl.replace('mypagenumber',l7COkhRWD9uVS60Pte2NoyAaZn)
	J3KRlV0tIgThaW5zi2rqUFA = ttAp0FJWZbyjvowCHSQM6hlBrE29Dm(s4mUPzjv1bRoNTMdenkuBgYl)
	if J3KRlV0tIgThaW5zi2rqUFA:
		YSP2gzXmK5e3FBNLD = Cy9ow3c21nABMjzqeaIT('dict',J3KRlV0tIgThaW5zi2rqUFA)
		D62v7VwWTe = YSP2gzXmK5e3FBNLD['data']['contentFeed']['edges']
		for Mrl489G7TspXzBvJOWiu in D62v7VwWTe:
			oJV18NUZAzPGqMu7tenCxrkfhdl69B = str(Mrl489G7TspXzBvJOWiu['node']['post']['duration'])
			title = emr1Lf523Ti0OtcNgxP(Mrl489G7TspXzBvJOWiu['node']['post']['title'])
			title = title.replace('\/','/')
			oo62gRQhBFXzjDWIOHfyES = Mrl489G7TspXzBvJOWiu['node']['post']['xid']
			Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG = Mrl489G7TspXzBvJOWiu['node']['post']['thumbnailx480']
			Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG = Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG.replace('\/','/')
			llxFwq0CUNgQtivJzkHeGV = Str0BupDTFA+'/video/'+oo62gRQhBFXzjDWIOHfyES
			RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,403,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,oJV18NUZAzPGqMu7tenCxrkfhdl69B)
		if '"hasNextPage":true' in J3KRlV0tIgThaW5zi2rqUFA:
			l7COkhRWD9uVS60Pte2NoyAaZn = str(int(l7COkhRWD9uVS60Pte2NoyAaZn)+1)
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'صفحة '+l7COkhRWD9uVS60Pte2NoyAaZn,url,416,hWGMqtBy4wuLaVcj,l7COkhRWD9uVS60Pte2NoyAaZn)
	return
def ttAp0FJWZbyjvowCHSQM6hlBrE29Dm(s4mUPzjv1bRoNTMdenkuBgYl,search=hWGMqtBy4wuLaVcj):
	if H4qZ2hwilNJYTmCFEQyaSs98cPM0gR: s4mUPzjv1bRoNTMdenkuBgYl = s4mUPzjv1bRoNTMdenkuBgYl.encode('utf-8')
	BzmiLUjHt0rQ6pS3ecfd = YV3x2mldnCc9rJe65saRqgvIBHXbAK()
	headers = {"Authorization":BzmiLUjHt0rQ6pS3ecfd,"Origin":Str0BupDTFA,'Content-Type':'text/plain; charset=utf-8'}
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(nHBb7jXk0Daom,'POST',Mr9c3QFRbp4wm,s4mUPzjv1bRoNTMdenkuBgYl,headers,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'DAILYMOTION-GET_PAGEDATA-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	return mMQ3FkNVa4IlxqY
def YV3x2mldnCc9rJe65saRqgvIBHXbAK():
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(nHBb7jXk0Daom,'GET',Str0BupDTFA,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'DAILYMOTION-GET_AUTHINTICATION-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	gb7Wc4AFG98YjBeSkC0XwdLH = trdVA0JvFaD.findall('var r="(.*?)",o="(.*?)"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	UlhsJGyRCYDe13AEMFPtmikuxoO,iiLPZCyMq7SdsxNjucO = gb7Wc4AFG98YjBeSkC0XwdLH[-1]
	DucBW867CsVg5Zyx4hQG = 'https://graphql.api.dailymotion.com/oauth/token'
	PhGt5Mb8zTI3U = 'client_credentials'
	data = {'client_id':UlhsJGyRCYDe13AEMFPtmikuxoO,'client_secret':iiLPZCyMq7SdsxNjucO,'grant_type':PhGt5Mb8zTI3U}
	headers = {'Content-Type':'application/x-www-form-urlencoded'}
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(nHBb7jXk0Daom,'POST',DucBW867CsVg5Zyx4hQG,data,headers,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'DAILYMOTION-GET_AUTHINTICATION-2nd')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	gb7Wc4AFG98YjBeSkC0XwdLH = trdVA0JvFaD.findall('"access_token": *"(.*?)".*?"token_type": *"(.*?)"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	EjmuF1MSnOYqeGAkoNyZQfdpXV02,FH6VkxYCMA3b51QSZtPNylmj = gb7Wc4AFG98YjBeSkC0XwdLH[0]
	BzmiLUjHt0rQ6pS3ecfd = FH6VkxYCMA3b51QSZtPNylmj+" "+EjmuF1MSnOYqeGAkoNyZQfdpXV02
	return BzmiLUjHt0rQ6pS3ecfd
def lPwaAjFTMG4n7iSLkXcEuK0Zm(search,ffSgj3D680=hWGMqtBy4wuLaVcj):
	search,vvKf4sXgZIMyEJPuC,showDialogs = IVTEJQOiMR2dYta9C(search)
	if not ffSgj3D680 and showDialogs:
		vvfhiUZSzpq70OsxR = ['بحث عن فيديوهات','بحث عن آخر الفيديوهات','بحث عن الفيديوهات الاكثر مشاهدة','(جيد للمسلسلات) بحث عن قوائم تشغيل','بحث عن مستخدم','بحث عن بث حي','بحث عن هاشتاك']
		OODLkJlZCoKmrzbg2XQSGPUdInA = Eb7qJoNwOgn('موقع ديلي موشن - اختر البحث',vvfhiUZSzpq70OsxR)
		if OODLkJlZCoKmrzbg2XQSGPUdInA==-1: return
		elif OODLkJlZCoKmrzbg2XQSGPUdInA==0: ffSgj3D680 = 'videos?sortBy='
		elif OODLkJlZCoKmrzbg2XQSGPUdInA==1: ffSgj3D680 = 'videos?sortBy=RECENT'
		elif OODLkJlZCoKmrzbg2XQSGPUdInA==2: ffSgj3D680 = 'videos?sortBy=VIEW_COUNT'
		elif OODLkJlZCoKmrzbg2XQSGPUdInA==3: ffSgj3D680 = 'playlists'
		elif OODLkJlZCoKmrzbg2XQSGPUdInA==4: ffSgj3D680 = 'channels'
		elif OODLkJlZCoKmrzbg2XQSGPUdInA==5: ffSgj3D680 = 'lives'
		elif OODLkJlZCoKmrzbg2XQSGPUdInA==6: ffSgj3D680 = 'hashtags'
	elif '_DAILYMOTION-VIDEOS_' in vvKf4sXgZIMyEJPuC: ffSgj3D680 = 'videos?sortBy='
	elif '_DAILYMOTION-PLAYLISTS_' in vvKf4sXgZIMyEJPuC: ffSgj3D680 = 'playlists'
	elif '_DAILYMOTION-CHANNELS_' in vvKf4sXgZIMyEJPuC: ffSgj3D680 = 'channels'
	elif '_DAILYMOTION-LIVES_' in vvKf4sXgZIMyEJPuC: ffSgj3D680 = 'lives'
	elif '_DAILYMOTION-HASHTAGS_' in vvKf4sXgZIMyEJPuC: ffSgj3D680 = 'hashtags'
	elif not ffSgj3D680: ffSgj3D680 = 'videos?sortBy='
	if not search:
		search = TrzfUidpv1LyAYqwexHJDuS()
		if not search: return
	if 'videos' in ffSgj3D680: ioYAsadWvVj(search+'/'+ffSgj3D680)
	elif 'playlists' in ffSgj3D680: c0Gqef3MHdL(search)
	elif 'channels' in ffSgj3D680: k7zPu8ISbWTOtnFRYsXcEyh4KD(search)
	elif 'lives' in ffSgj3D680: DnJb5u69KVIf3Q1NFse4LW(search)
	elif 'hashtags' in ffSgj3D680: O40YaJMPmgnIQ7A8K(search)
	return
# -*- coding: utf-8 -*-
import sys as zGjD5QAkd7SO9YPcZl
A56Abl2j14QS = zGjD5QAkd7SO9YPcZl.version_info [0] == 2
qO2vebR9rSTZnuJDW = 2048
EECQl2Zun37S0KkWwtIDHYNai6Ayd8 = 7
def wwTjCFmkUK (mMBv4T89VDdfJGL):
	global ylRUYSmHX7oCf93TADc8J6rqMVL
	tE23ZuI91qGJ = ord (mMBv4T89VDdfJGL [-1])
	huZOyFMzvY3LpEf = mMBv4T89VDdfJGL [:-1]
	FXE237NbgJweKmBxPfVnsAoYjCazqW = tE23ZuI91qGJ % len (huZOyFMzvY3LpEf)
	LQ2yAP51CVNFXdr = huZOyFMzvY3LpEf [:FXE237NbgJweKmBxPfVnsAoYjCazqW] + huZOyFMzvY3LpEf [FXE237NbgJweKmBxPfVnsAoYjCazqW:]
	if A56Abl2j14QS:
		R0i7UHvbBw25n8 = unicode () .join ([unichr (ord (cIsD9VN758uwbLUaGM2zmEY) - qO2vebR9rSTZnuJDW - (o42QnFjKJ5l98hWTqzCDi73LcvNA + tE23ZuI91qGJ) % EECQl2Zun37S0KkWwtIDHYNai6Ayd8) for o42QnFjKJ5l98hWTqzCDi73LcvNA, cIsD9VN758uwbLUaGM2zmEY in enumerate (LQ2yAP51CVNFXdr)])
	else:
		R0i7UHvbBw25n8 = str () .join ([chr (ord (cIsD9VN758uwbLUaGM2zmEY) - qO2vebR9rSTZnuJDW - (o42QnFjKJ5l98hWTqzCDi73LcvNA + tE23ZuI91qGJ) % EECQl2Zun37S0KkWwtIDHYNai6Ayd8) for o42QnFjKJ5l98hWTqzCDi73LcvNA, cIsD9VN758uwbLUaGM2zmEY in enumerate (LQ2yAP51CVNFXdr)])
	return eval (R0i7UHvbBw25n8)
NeO3CTLHrPfWUoIgy8Q,KNIvHPjUbhr,CnbBKmtF1x84q7AW=wwTjCFmkUK,wwTjCFmkUK,wwTjCFmkUK
zyvJMtBhrw,MMizeNH0AKu,KBkxSYaz93pu1=CnbBKmtF1x84q7AW,KNIvHPjUbhr,NeO3CTLHrPfWUoIgy8Q
LB2q7IVRpcyXlE6C3ihZruPe4An1Y,EDgpT9hIF6GCfl0vXiWnBANjOUVRua,XQo0YS3sk4rHAvwyNltf9CipLWMjx=KBkxSYaz93pu1,MMizeNH0AKu,zyvJMtBhrw
hWUz1ujibPY3G9MIZmvS4kVaK7dT,DJ1ICpbyR2,e2qDYgipPmTw4KvBLnochr=XQo0YS3sk4rHAvwyNltf9CipLWMjx,EDgpT9hIF6GCfl0vXiWnBANjOUVRua,LB2q7IVRpcyXlE6C3ihZruPe4An1Y
A6dMB1FlgxVivJ2fk9C,mkHKSQvjWr5BTcM3wVY,o1u5dij9UrcbXzVS8lwIWfKpnqM=e2qDYgipPmTw4KvBLnochr,DJ1ICpbyR2,hWUz1ujibPY3G9MIZmvS4kVaK7dT
JwiZdgbG5HYuCIsj69aBSRQ0nrNkET,SqrG5mU3j96ldsFpExobw40TJY,HHoGx7Flus60=o1u5dij9UrcbXzVS8lwIWfKpnqM,mkHKSQvjWr5BTcM3wVY,A6dMB1FlgxVivJ2fk9C
QVDJLRlxNg127jMX,gDuGMR3z1aV6YdLmCpiO8Kl,jeAby54c02TgG8zuivonX91=HHoGx7Flus60,SqrG5mU3j96ldsFpExobw40TJY,JwiZdgbG5HYuCIsj69aBSRQ0nrNkET
S1SgCFYGJeMvfp5iZXK,dv0trJR7PwmKyxDYO52VLau8gEph,QvgnCALNstmuUJiET=jeAby54c02TgG8zuivonX91,gDuGMR3z1aV6YdLmCpiO8Kl,QVDJLRlxNg127jMX
OOsBSKq9u6J2lC5WdYpvNMHaFP4,rwQN9AKhLCuMfHxjlbX0U,xcChIL13BpR8WArNt9Pl0So=QvgnCALNstmuUJiET,dv0trJR7PwmKyxDYO52VLau8gEph,S1SgCFYGJeMvfp5iZXK
sULh4NjakzI8He7xJCMGrql,LAhIMyBG0xZVUlO4rJ9z5fbDFgCs,GA4NBdjuZqkKUX6IEMvHPoegDyVrLm=xcChIL13BpR8WArNt9Pl0So,rwQN9AKhLCuMfHxjlbX0U,OOsBSKq9u6J2lC5WdYpvNMHaFP4
ITvnUAMXsyb4eO,wwPrSDa21lUh,FimxS5jkaq1RcJ8DnWTZNO4zQClwt=GA4NBdjuZqkKUX6IEMvHPoegDyVrLm,LAhIMyBG0xZVUlO4rJ9z5fbDFgCs,sULh4NjakzI8He7xJCMGrql
from yoY3NdGViS import *
xjPuFK3EsIZSiobQ5X = DJ1ICpbyR2(u"ࠫࡈࡒࡅࡂࡐࡈࡖࠬࠀ")
n0qFKQWhiBYXoTrvejVHUA4 = mkHKSQvjWr5BTcM3wVY(u"ࠬࡥࡃࡍࡐࡢࠫࠁ")
zm4rfojxOuLCh = WQvYkNg7SysPFLitlGEn6.path.join(g2jVSXyeCRdALnvbk4hTN17,OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"࠭ࡴࡦ࡯ࡳࠫࠂ"))
ly3qTrudKRIHX8c = WQvYkNg7SysPFLitlGEn6.path.join(g2jVSXyeCRdALnvbk4hTN17,S1SgCFYGJeMvfp5iZXK(u"ࠧࡱࡣࡦ࡯ࡦ࡭ࡥࡴࠩࠃ"))
PYcdbUvGxXN9ozSwOpqyIg6uEkDM0 = WQvYkNg7SysPFLitlGEn6.path.join(W96kNDymei,xcChIL13BpR8WArNt9Pl0So(u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪࠄ"),e2qDYgipPmTw4KvBLnochr(u"ࠩࡗ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡸ࠭ࠅ"))
Yn4MFQPHhk38a69w = wyG5ogaEBfHMV2uX3QRxzD
j2Fe4vEq65GrWNTJY = LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠪ࠳ࡩࡧࡴࡢ࠱ࡶࡽࡸࡺࡥ࡮࠱ࡸࡷࡦ࡭ࡥࡴࡶࡤࡸࡸ࠭ࠆ")
gRN1a4jveA = sULh4NjakzI8He7xJCMGrql(u"ࠫ࠴ࡪࡡࡵࡣ࠲ࡷࡾࡹࡴࡦ࡯࠲ࡨࡷࡵࡰࡣࡱࡻࠫࠇ")
n2ldTZvR7mxNEXDFjc = mkHKSQvjWr5BTcM3wVY(u"ࠬ࠵ࡤࡢࡶࡤ࠳ࡹࡵ࡭ࡣࡵࡷࡳࡳ࡫ࡳࠨࠈ")
UUoYXhcBgwLW = sULh4NjakzI8He7xJCMGrql(u"࠭࠯ࡥࡣࡷࡥ࠴ࡲ࡯ࡨࡩࡨࡶࠬࠉ")
ZZyldLpAW9gfNeuYMiQBT1IJzov = LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠧ࠰ࡦࡤࡸࡦ࠵࡬ࡰࡩࠪࠊ")
HaWZMiy2tEqfvKC3Ao0VhS = HHoGx7Flus60(u"ࠨ࠱ࡧࡥࡹࡧ࠯ࡢࡰࡵࠫࠋ")
def ehB18u9sQFRi(JbpxsyQVXmSEYKM3vo847Ckh):
	if   JbpxsyQVXmSEYKM3vo847Ckh==KNIvHPjUbhr(u"࠼࠺࠰ࡸ"): N6NCYivtV4I5rEXq = NJ6yHlhartU8VLo5ficX()
	elif JbpxsyQVXmSEYKM3vo847Ckh==GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"࠽࠴࠲ࡹ"): N6NCYivtV4I5rEXq = Xe6bnfEPjgqJy5FIoRi0z2v8(zm4rfojxOuLCh,VBlawK4mgHSyLEn8iqhUkz5,VBlawK4mgHSyLEn8iqhUkz5)
	elif JbpxsyQVXmSEYKM3vo847Ckh==NeO3CTLHrPfWUoIgy8Q(u"࠷࠵࠴ࡺ"): N6NCYivtV4I5rEXq = Xe6bnfEPjgqJy5FIoRi0z2v8(ly3qTrudKRIHX8c,VBlawK4mgHSyLEn8iqhUkz5,VBlawK4mgHSyLEn8iqhUkz5)
	elif JbpxsyQVXmSEYKM3vo847Ckh==KNIvHPjUbhr(u"࠸࠶࠶ࡻ"): N6NCYivtV4I5rEXq = Xe6bnfEPjgqJy5FIoRi0z2v8(PYcdbUvGxXN9ozSwOpqyIg6uEkDM0,fEXMiAyG3ql4vKB,VBlawK4mgHSyLEn8iqhUkz5)
	elif JbpxsyQVXmSEYKM3vo847Ckh==FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"࠹࠷࠸ࡼ"): N6NCYivtV4I5rEXq = XbPWu8tcMwVagqyFdm7T9NGpHrOfQ6(Yn4MFQPHhk38a69w,VBlawK4mgHSyLEn8iqhUkz5)
	elif JbpxsyQVXmSEYKM3vo847Ckh==sULh4NjakzI8He7xJCMGrql(u"࠺࠸࠺ࡽ"): N6NCYivtV4I5rEXq = Kehd45WHLX8c(VBlawK4mgHSyLEn8iqhUkz5)
	elif JbpxsyQVXmSEYKM3vo847Ckh==FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"࠻࠺࠶ࡾ"): N6NCYivtV4I5rEXq = uuYM0QglGzOo59Lpk1W()
	elif JbpxsyQVXmSEYKM3vo847Ckh==OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"࠼࠻࠱ࡿ"): N6NCYivtV4I5rEXq = Xe6bnfEPjgqJy5FIoRi0z2v8(j2Fe4vEq65GrWNTJY,fEXMiAyG3ql4vKB,VBlawK4mgHSyLEn8iqhUkz5)
	elif JbpxsyQVXmSEYKM3vo847Ckh==GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"࠽࠵࠳ࢀ"): N6NCYivtV4I5rEXq = Xe6bnfEPjgqJy5FIoRi0z2v8(gRN1a4jveA,fEXMiAyG3ql4vKB,VBlawK4mgHSyLEn8iqhUkz5)
	elif JbpxsyQVXmSEYKM3vo847Ckh==CnbBKmtF1x84q7AW(u"࠷࠶࠵ࢁ"): N6NCYivtV4I5rEXq = Xe6bnfEPjgqJy5FIoRi0z2v8(n2ldTZvR7mxNEXDFjc,fEXMiAyG3ql4vKB,VBlawK4mgHSyLEn8iqhUkz5)
	elif JbpxsyQVXmSEYKM3vo847Ckh==MMizeNH0AKu(u"࠸࠷࠷ࢂ"): N6NCYivtV4I5rEXq = Xe6bnfEPjgqJy5FIoRi0z2v8(UUoYXhcBgwLW,fEXMiAyG3ql4vKB,VBlawK4mgHSyLEn8iqhUkz5)
	elif JbpxsyQVXmSEYKM3vo847Ckh==SqrG5mU3j96ldsFpExobw40TJY(u"࠹࠸࠹ࢃ"): N6NCYivtV4I5rEXq = Xe6bnfEPjgqJy5FIoRi0z2v8(ZZyldLpAW9gfNeuYMiQBT1IJzov,fEXMiAyG3ql4vKB,VBlawK4mgHSyLEn8iqhUkz5)
	elif JbpxsyQVXmSEYKM3vo847Ckh==NeO3CTLHrPfWUoIgy8Q(u"࠺࠹࠻ࢄ"): N6NCYivtV4I5rEXq = Xe6bnfEPjgqJy5FIoRi0z2v8(HaWZMiy2tEqfvKC3Ao0VhS,fEXMiAyG3ql4vKB,VBlawK4mgHSyLEn8iqhUkz5)
	elif JbpxsyQVXmSEYKM3vo847Ckh==mkHKSQvjWr5BTcM3wVY(u"࠻࠺࠽ࢅ"): N6NCYivtV4I5rEXq = SEpqTheBufx6(VBlawK4mgHSyLEn8iqhUkz5)
	elif JbpxsyQVXmSEYKM3vo847Ckh==XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"࠼࠻࠸ࢆ"): N6NCYivtV4I5rEXq = actoHeEhB7qsAuxKjDdynZ()
	else: N6NCYivtV4I5rEXq = fEXMiAyG3ql4vKB
	return N6NCYivtV4I5rEXq
def NJ6yHlhartU8VLo5ficX():
	VApCxsI79LzghXrY,hz3gGBqsDAo58uWi9VH7O2y4 = KIUA9ZN1gLuzYDnCXEjwqFlO(zm4rfojxOuLCh)
	iiKPBLWH7oahIz1DZ9jg,jnx3kCh92oIrMbuWzGqtYHpDiaX = KIUA9ZN1gLuzYDnCXEjwqFlO(ly3qTrudKRIHX8c)
	tiU5C0GpW78I2,L46sTlWwMydR2nSVaDqQt = KIUA9ZN1gLuzYDnCXEjwqFlO(PYcdbUvGxXN9ozSwOpqyIg6uEkDM0)
	U36qC8V9jaiKPAf0DEQwr,eegD6FXy03oTuq1xRE4QWk = YAvI1Zz5J3yEFXQdWhqmo6nD(Yn4MFQPHhk38a69w)
	U36qC8V9jaiKPAf0DEQwr -= e2qDYgipPmTw4KvBLnochr(u"࠹࠶࠹࠸࠷ࢇ")
	eegD6FXy03oTuq1xRE4QWk -= A6dMB1FlgxVivJ2fk9C(u"࠱࢈")
	MM2rk8n4HN1GCZuwpeUSo = HHoGx7Flus60(u"ࠩࠣࠬࠬࠌ")+prICw2y5RcJudxVYlFA(VApCxsI79LzghXrY)+ITvnUAMXsyb4eO(u"ࠪࠤ࠲ࠦࠧࠍ")+str(hz3gGBqsDAo58uWi9VH7O2y4)+OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬࠎ")
	XVfzajwpqTB4R8xdEKDt = EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠬࠦࠨࠨࠏ")+prICw2y5RcJudxVYlFA(iiKPBLWH7oahIz1DZ9jg)+mkHKSQvjWr5BTcM3wVY(u"࠭ࠠ࠮ࠢࠪࠐ")+str(jnx3kCh92oIrMbuWzGqtYHpDiaX)+rwQN9AKhLCuMfHxjlbX0U(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨࠑ")
	E1EZ0jp9Che5Wn8 = gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠨࠢࠫࠫࠒ")+prICw2y5RcJudxVYlFA(tiU5C0GpW78I2)+gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠩࠣ࠱ࠥ࠭ࠓ")+str(L46sTlWwMydR2nSVaDqQt)+FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࠔ")
	OjHy6u7xTq591PIlUnvRLwQz83 = CnbBKmtF1x84q7AW(u"ࠫࠥ࠮ࠧࠕ")+prICw2y5RcJudxVYlFA(U36qC8V9jaiKPAf0DEQwr)+wwPrSDa21lUh(u"ࠬ࠯ࠧࠖ")
	BBRClkiFSfjqUa2bxWheyO37vE = VApCxsI79LzghXrY+iiKPBLWH7oahIz1DZ9jg+tiU5C0GpW78I2+U36qC8V9jaiKPAf0DEQwr
	Rjlrpdef3CVLhnM = hz3gGBqsDAo58uWi9VH7O2y4+jnx3kCh92oIrMbuWzGqtYHpDiaX+L46sTlWwMydR2nSVaDqQt+eegD6FXy03oTuq1xRE4QWk
	s9ea72VfoygAOFRCWQTH3zmDuLPE = LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"࠭ࠠࠩࠩࠗ")+prICw2y5RcJudxVYlFA(BBRClkiFSfjqUa2bxWheyO37vE)+SqrG5mU3j96ldsFpExobw40TJY(u"ࠧࠡ࠯ࠣࠫ࠘")+str(Rjlrpdef3CVLhnM)+MMizeNH0AKu(u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩ࠙")
	RLDCGt8kq3OVmnzgx1rbi2f7F(KNIvHPjUbhr(u"ࠩ࡯࡭ࡳࡱࠧࠚ"),n0qFKQWhiBYXoTrvejVHUA4+GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ุ้ࠪำࠠศๆฯ้๏฿ࠧࠛ")+s9ea72VfoygAOFRCWQTH3zmDuLPE,hWGMqtBy4wuLaVcj,S1SgCFYGJeMvfp5iZXK(u"࠸࠶࠸ࢉ"))
	RLDCGt8kq3OVmnzgx1rbi2f7F(FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠫࡱ࡯࡮࡬ࠩࠜ"),hXB0vKVQ5PRI91SDTprMdfuHEm4+FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠬࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫࠝ")+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,KBkxSYaz93pu1(u"࠻࠼࠽࠾ࢊ"))
	RLDCGt8kq3OVmnzgx1rbi2f7F(QVDJLRlxNg127jMX(u"࠭࡬ࡪࡰ࡮ࠫࠞ"),n0qFKQWhiBYXoTrvejVHUA4+LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠧๆีะࠤฬ๊ๅๅใสฮࠥอไๆฦๅฮฮ࠭ࠟ")+MM2rk8n4HN1GCZuwpeUSo,hWGMqtBy4wuLaVcj,hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"࠺࠸࠶ࢋ"))
	RLDCGt8kq3OVmnzgx1rbi2f7F(NeO3CTLHrPfWUoIgy8Q(u"ࠨ࡮࡬ࡲࡰ࠭ࠠ"),n0qFKQWhiBYXoTrvejVHUA4+rwQN9AKhLCuMfHxjlbX0U(u"่ࠩืาࠦวๅ็็ๅฬะࠠศๆฺ่฿๎ืสࠩࠡ")+XVfzajwpqTB4R8xdEKDt,hWGMqtBy4wuLaVcj,xcChIL13BpR8WArNt9Pl0So(u"࠻࠹࠸ࢌ"))
	RLDCGt8kq3OVmnzgx1rbi2f7F(GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠪࡰ࡮ࡴ࡫ࠨࠢ"),n0qFKQWhiBYXoTrvejVHUA4+mkHKSQvjWr5BTcM3wVY(u"ู๊ࠫอࠡษ็ูํืࠠศๆๅำ๏๋ษࠨࠣ")+E1EZ0jp9Che5Wn8,hWGMqtBy4wuLaVcj,NeO3CTLHrPfWUoIgy8Q(u"࠼࠺࠳ࢍ"))
	RLDCGt8kq3OVmnzgx1rbi2f7F(zyvJMtBhrw(u"ࠬࡲࡩ࡯࡭ࠪࠤ"),n0qFKQWhiBYXoTrvejVHUA4+xcChIL13BpR8WArNt9Pl0So(u"࠭สโำํ฾๋ࠥไโุࠢ์ึࠦวๅวูหๆอสࠨࠥ")+OjHy6u7xTq591PIlUnvRLwQz83,hWGMqtBy4wuLaVcj,sULh4NjakzI8He7xJCMGrql(u"࠽࠴࠵ࢎ"))
	ee8c0jzrTntGSUdRJm.setSetting(o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡶࡪ࡬ࡲࡦࡵ࡫ࠫࠦ"),hWGMqtBy4wuLaVcj)
	return
def uuYM0QglGzOo59Lpk1W():
	U96AiRbathv1klZXuLmj2cG3V = VBlawK4mgHSyLEn8iqhUkz5 if XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠨ࠱ࠪࠧ") in W96kNDymei else fEXMiAyG3ql4vKB
	if not U96AiRbathv1klZXuLmj2cG3V:
		BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,KBkxSYaz93pu1(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬࠨ"),rwQN9AKhLCuMfHxjlbX0U(u"ࠪ฽๊๊๊สࠢอ๊฽๐แࠡษ็ะ์อาࠡ็อ์ๆืษࠡใๅ฻๊ࠥรอ้ีอࠥ๐่็ๅึࠤ࠳࠴้ࠠฮ๊หื้ࠠๅ์ึࠤ๊์ࠠ็๊฼ࠤ๏๎ๆไีࠪࠩ"))
		return
	agkF7iSBOZ4DKJC25yztrsN86cXLfV = ee8c0jzrTntGSUdRJm.getSetting(wwPrSDa21lUh(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡳࡧࡩࡶࡪࡹࡨࠨࠪ"))
	if not agkF7iSBOZ4DKJC25yztrsN86cXLfV: actoHeEhB7qsAuxKjDdynZ()
	VApCxsI79LzghXrY,hz3gGBqsDAo58uWi9VH7O2y4 = KIUA9ZN1gLuzYDnCXEjwqFlO(j2Fe4vEq65GrWNTJY)
	iiKPBLWH7oahIz1DZ9jg,jnx3kCh92oIrMbuWzGqtYHpDiaX = KIUA9ZN1gLuzYDnCXEjwqFlO(gRN1a4jveA)
	tiU5C0GpW78I2,L46sTlWwMydR2nSVaDqQt = KIUA9ZN1gLuzYDnCXEjwqFlO(n2ldTZvR7mxNEXDFjc)
	U36qC8V9jaiKPAf0DEQwr,eegD6FXy03oTuq1xRE4QWk = KIUA9ZN1gLuzYDnCXEjwqFlO(UUoYXhcBgwLW)
	pUxDlGE2kP7oRLtO3dBm6qhvrz,Gp5w64umPL = KIUA9ZN1gLuzYDnCXEjwqFlO(ZZyldLpAW9gfNeuYMiQBT1IJzov)
	Oa6uBbpNm0QIT7FZfLlDswyi8ndA,gY0Gv3PnsEFzSdWwNLi6mfJu8 = KIUA9ZN1gLuzYDnCXEjwqFlO(HaWZMiy2tEqfvKC3Ao0VhS)
	MM2rk8n4HN1GCZuwpeUSo = S1SgCFYGJeMvfp5iZXK(u"ࠬࠦࠨࠨࠫ")+prICw2y5RcJudxVYlFA(VApCxsI79LzghXrY)+CnbBKmtF1x84q7AW(u"࠭ࠠ࠮ࠢࠪࠬ")+str(hz3gGBqsDAo58uWi9VH7O2y4)+xcChIL13BpR8WArNt9Pl0So(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨ࠭")
	XVfzajwpqTB4R8xdEKDt = CnbBKmtF1x84q7AW(u"ࠨࠢࠫࠫ࠮")+prICw2y5RcJudxVYlFA(iiKPBLWH7oahIz1DZ9jg)+EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠩࠣ࠱ࠥ࠭࠯")+str(jnx3kCh92oIrMbuWzGqtYHpDiaX)+xcChIL13BpR8WArNt9Pl0So(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫ࠰")
	E1EZ0jp9Che5Wn8 = GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠫࠥ࠮ࠧ࠱")+prICw2y5RcJudxVYlFA(tiU5C0GpW78I2)+QVDJLRlxNg127jMX(u"ࠬࠦ࠭ࠡࠩ࠲")+str(L46sTlWwMydR2nSVaDqQt)+zyvJMtBhrw(u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧ࠳")
	OjHy6u7xTq591PIlUnvRLwQz83 = HHoGx7Flus60(u"ࠧࠡࠪࠪ࠴")+prICw2y5RcJudxVYlFA(U36qC8V9jaiKPAf0DEQwr)+FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠨࠢ࠰ࠤࠬ࠵")+str(eegD6FXy03oTuq1xRE4QWk)+gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠩࠣࡪ࡮ࡲࡥࡴࠫࠪ࠶")
	jxlV6RLSOH83MZaBKtbWIwTN4f7FPc = zyvJMtBhrw(u"ࠪࠤ࠭࠭࠷")+prICw2y5RcJudxVYlFA(pUxDlGE2kP7oRLtO3dBm6qhvrz)+NeO3CTLHrPfWUoIgy8Q(u"ࠫࠥ࠳ࠠࠨ࠸")+str(Gp5w64umPL)+KNIvHPjUbhr(u"ࠬࠦࡦࡪ࡮ࡨࡷ࠮࠭࠹")
	nfTAh5l1jd29vqFKH4Di6bJM = LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"࠭ࠠࠩࠩ࠺")+prICw2y5RcJudxVYlFA(Oa6uBbpNm0QIT7FZfLlDswyi8ndA)+mkHKSQvjWr5BTcM3wVY(u"ࠧࠡ࠯ࠣࠫ࠻")+str(gY0Gv3PnsEFzSdWwNLi6mfJu8)+hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩ࠼")
	BBRClkiFSfjqUa2bxWheyO37vE = VApCxsI79LzghXrY+iiKPBLWH7oahIz1DZ9jg+tiU5C0GpW78I2+U36qC8V9jaiKPAf0DEQwr+pUxDlGE2kP7oRLtO3dBm6qhvrz+Oa6uBbpNm0QIT7FZfLlDswyi8ndA
	Rjlrpdef3CVLhnM = hz3gGBqsDAo58uWi9VH7O2y4+jnx3kCh92oIrMbuWzGqtYHpDiaX+L46sTlWwMydR2nSVaDqQt+eegD6FXy03oTuq1xRE4QWk+Gp5w64umPL+gY0Gv3PnsEFzSdWwNLi6mfJu8
	s9ea72VfoygAOFRCWQTH3zmDuLPE = o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠩࠣࠬࠬ࠽")+prICw2y5RcJudxVYlFA(BBRClkiFSfjqUa2bxWheyO37vE)+hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠪࠤ࠲ࠦࠧ࠾")+str(Rjlrpdef3CVLhnM)+o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬ࠿")
	RLDCGt8kq3OVmnzgx1rbi2f7F(A6dMB1FlgxVivJ2fk9C(u"ࠬࡲࡩ࡯࡭ࠪࡀ"),n0qFKQWhiBYXoTrvejVHUA4+ITvnUAMXsyb4eO(u"࠭ลฺูสลࠥืฮึหࠣๆึอมส๋ࠢ็ฯอศสࠩࡁ"),hWGMqtBy4wuLaVcj,rwQN9AKhLCuMfHxjlbX0U(u"࠷࠶࠺࢏"))
	RLDCGt8kq3OVmnzgx1rbi2f7F(e2qDYgipPmTw4KvBLnochr(u"ࠧ࡭࡫ࡱ࡯ࠬࡂ"),n0qFKQWhiBYXoTrvejVHUA4+A6dMB1FlgxVivJ2fk9C(u"ࠨ็ึัࠥอไอ็ํ฽ࠬࡃ")+s9ea72VfoygAOFRCWQTH3zmDuLPE,hWGMqtBy4wuLaVcj,xcChIL13BpR8WArNt9Pl0So(u"࠸࠷࠺࢐"))
	RLDCGt8kq3OVmnzgx1rbi2f7F(dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠩ࡯࡭ࡳࡱࠧࡄ"),hXB0vKVQ5PRI91SDTprMdfuHEm4+A6dMB1FlgxVivJ2fk9C(u"ࠪࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡࠩࡅ")+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,o1u5dij9UrcbXzVS8lwIWfKpnqM(u"࠻࠼࠽࠾࢑"))
	RLDCGt8kq3OVmnzgx1rbi2f7F(FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠫࡱ࡯࡮࡬ࠩࡆ"),n0qFKQWhiBYXoTrvejVHUA4+wwPrSDa21lUh(u"๋ࠬำฮ่่ࠢๆอสࠡࡷࡶࡥ࡬࡫ࡳࡵࡣࡷࡷࠬࡇ")+MM2rk8n4HN1GCZuwpeUSo,hWGMqtBy4wuLaVcj,dv0trJR7PwmKyxDYO52VLau8gEph(u"࠺࠹࠶࢒"))
	RLDCGt8kq3OVmnzgx1rbi2f7F(KNIvHPjUbhr(u"࠭࡬ࡪࡰ࡮ࠫࡈ"),n0qFKQWhiBYXoTrvejVHUA4+mkHKSQvjWr5BTcM3wVY(u"ࠧๆีะࠤ๊๊แศฬࠣࡨࡷࡵࡰࡣࡱࡻࠫࡉ")+XVfzajwpqTB4R8xdEKDt,hWGMqtBy4wuLaVcj,NeO3CTLHrPfWUoIgy8Q(u"࠻࠺࠸࢓"))
	RLDCGt8kq3OVmnzgx1rbi2f7F(XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠨ࡮࡬ࡲࡰ࠭ࡊ"),n0qFKQWhiBYXoTrvejVHUA4+JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"่ࠩืาࠦๅๅใสฮࠥࡺ࡯࡮ࡤࡶࡸࡴࡴࡥࡴࠩࡋ")+E1EZ0jp9Che5Wn8,hWGMqtBy4wuLaVcj,FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"࠼࠻࠳࢔"))
	RLDCGt8kq3OVmnzgx1rbi2f7F(zyvJMtBhrw(u"ࠪࡰ࡮ࡴ࡫ࠨࡌ"),n0qFKQWhiBYXoTrvejVHUA4+mkHKSQvjWr5BTcM3wVY(u"ู๊ࠫอࠡ็็ๅฬะࠠ࡭ࡱࡪ࡫ࡪࡸࠧࡍ")+OjHy6u7xTq591PIlUnvRLwQz83,hWGMqtBy4wuLaVcj,rwQN9AKhLCuMfHxjlbX0U(u"࠽࠵࠵࢕"))
	RLDCGt8kq3OVmnzgx1rbi2f7F(KNIvHPjUbhr(u"ࠬࡲࡩ࡯࡭ࠪࡎ"),n0qFKQWhiBYXoTrvejVHUA4+HHoGx7Flus60(u"࠭ๅิฯ้้ࠣ็วหࠢ࡯ࡳ࡬࠭ࡏ")+jxlV6RLSOH83MZaBKtbWIwTN4f7FPc,hWGMqtBy4wuLaVcj,KNIvHPjUbhr(u"࠷࠶࠷࢖"))
	RLDCGt8kq3OVmnzgx1rbi2f7F(HHoGx7Flus60(u"ࠧ࡭࡫ࡱ࡯ࠬࡐ"),n0qFKQWhiBYXoTrvejVHUA4+o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠨ็ึั๋ࠥไโษอࠤࡦࡴࡲࠨࡑ")+nfTAh5l1jd29vqFKH4Di6bJM,hWGMqtBy4wuLaVcj,GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"࠸࠷࠹ࢗ"))
	ee8c0jzrTntGSUdRJm.setSetting(CnbBKmtF1x84q7AW(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡸࡥࡧࡴࡨࡷ࡭࠭ࡒ"),hWGMqtBy4wuLaVcj)
	return
def actoHeEhB7qsAuxKjDdynZ():
	dHPVDWfG4jX5e6QEo0CKh = XVmKrby29eCGMnlEY6jz0HNOR(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ࡓ"),EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"้้๊ࠫࠡ์฼้้ࠦวๅฬ้฼๏็ฺ่ࠠา็ࠥ࠴࠮ࠡสิ๊ฬ๋ฬࠡ฻่หิࠦศฮษฯอࠥหไ๊ࠢศ฽฼อมࠡำัูฮࠦวๅไิหฦฯ้ࠠษ็็ฯอศสࠢ็่๊๊แศฬࠣ์ฬ๊ๅอๆาหฯࠦวๅฬํࠤุ๎แࠡ์่ืาํวࠡษ็ฬึ์วๆฮࠣ࠲࠳ࠦ็ๅࠢอี๏ีࠠฦ฻ฺหฦࠦ็ั้ࠣห้ืฮึหࠣห้ศๆࠡมࠤࠫࡔ"))
	if dHPVDWfG4jX5e6QEo0CKh==-ITvnUAMXsyb4eO(u"࠳࢘"): return
	if dHPVDWfG4jX5e6QEo0CKh:
		import subprocess as mfbFa3YlEJjD5oxgTwC0QL4HtsS
		try:
			mfbFa3YlEJjD5oxgTwC0QL4HtsS.Popen(gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠬࡹࡵࠨࡕ"))
			iipgZBCPm8nvyRq9YNSKwjc0AJof = VBlawK4mgHSyLEn8iqhUkz5
		except: iipgZBCPm8nvyRq9YNSKwjc0AJof = fEXMiAyG3ql4vKB
		if iipgZBCPm8nvyRq9YNSKwjc0AJof:
			O61iXMx7WKNa = j2Fe4vEq65GrWNTJY+Mpsm2VF1OBnCRvK3qf6+gRN1a4jveA+Mpsm2VF1OBnCRvK3qf6+n2ldTZvR7mxNEXDFjc+Mpsm2VF1OBnCRvK3qf6+UUoYXhcBgwLW+Mpsm2VF1OBnCRvK3qf6+ZZyldLpAW9gfNeuYMiQBT1IJzov+Mpsm2VF1OBnCRvK3qf6+HaWZMiy2tEqfvKC3Ao0VhS
			jjFh5SpQL0c = mfbFa3YlEJjD5oxgTwC0QL4HtsS.Popen(gDuGMR3z1aV6YdLmCpiO8Kl(u"࠭ࡳࡶࠢ࠰ࡧࠥࠨࡣࡩ࡯ࡲࡨࠥ࠳ࡒࠡ࠲࠺࠻࠼ࠦࠧࡖ")+O61iXMx7WKNa+zyvJMtBhrw(u"ࠧࠣࠩࡗ"),shell=VBlawK4mgHSyLEn8iqhUkz5,stdin=mfbFa3YlEJjD5oxgTwC0QL4HtsS.PIPE,stdout=mfbFa3YlEJjD5oxgTwC0QL4HtsS.PIPE,stderr=mfbFa3YlEJjD5oxgTwC0QL4HtsS.PIPE)
			BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,wwPrSDa21lUh(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫࡘ"),LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"้ࠩะาะฺࠠ็็๎ฮࠦลฺูสลࠥอไาะุอ࡙ࠬ"))
			CfKNTtIi3OABbWcPpdF(fEXMiAyG3ql4vKB)
		else: BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,MMizeNH0AKu(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࡚࠭"),XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠫ฾๋ไ๋หࠣษ฾฽วยࠢิาฺฯࠠศๆๅีฬวษ๊ࠡส่่ะวษหࠣฮาะวอࠢหี๋อๅอࠢࠣࡶࡴࡵࡴࠡࠢฦ์ࠥࠦࡳࡶࡲࡨࡶࡺࡹࡥࡳࠢࠣวํࠦࠠࡴࡷࠣࠤํา็ศิๆࠤ้อ๋๊ࠠฯำࠥ็๊่๊ࠢิฬࠦวๅสิ๊ฬ๋ฬࠡ࠰࠱ࠤศ๎ࠠไ๊า๎ࠥเ๊าࠢๅหิืฺࠠๆ์ࠤฬูสฯัส้ࠥํะศࠢส่อืๆศ็ฯ࡛ࠫ"))
	return
def prICw2y5RcJudxVYlFA(BBRClkiFSfjqUa2bxWheyO37vE):
	for TehOaqr5JGDIvkfZi in [wwPrSDa21lUh(u"ࠬࡈࠧ࡜"),KNIvHPjUbhr(u"࠭ࡋࡃࠩ࡝"),KNIvHPjUbhr(u"ࠧࡎࡄࠪ࡞"),xcChIL13BpR8WArNt9Pl0So(u"ࠨࡉࡅࠫ࡟"),o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠩࡗࡆࠬࡠ")]:
		if BBRClkiFSfjqUa2bxWheyO37vE<LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"࠴࠴࠷࠺࢙"): break
		else: BBRClkiFSfjqUa2bxWheyO37vE /= NeO3CTLHrPfWUoIgy8Q(u"࠵࠵࠸࠴࠯࠲࢚")
	s9ea72VfoygAOFRCWQTH3zmDuLPE = FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠥࠩ࠸࠴࠱ࡧࠢࠨࡷࠧࡡ")%(BBRClkiFSfjqUa2bxWheyO37vE,TehOaqr5JGDIvkfZi)
	return s9ea72VfoygAOFRCWQTH3zmDuLPE
def KIUA9ZN1gLuzYDnCXEjwqFlO(bWOxP6FrcalX8d5TRNgoDn1V=dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠫ࠳࠭ࡢ")):
	global SSRchvijUfOW,K5KEb3eUO7QBFtuTj8
	SSRchvijUfOW,K5KEb3eUO7QBFtuTj8 = LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"࠵࢛"),LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"࠵࢛")
	def agLV86qMhjE(bWOxP6FrcalX8d5TRNgoDn1V):
		global SSRchvijUfOW,K5KEb3eUO7QBFtuTj8
		if WQvYkNg7SysPFLitlGEn6.path.exists(bWOxP6FrcalX8d5TRNgoDn1V):
			if e2qDYgipPmTw4KvBLnochr(u"࠶࢜") and zyvJMtBhrw(u"ࠬࡹࡣࡢࡰࡧ࡭ࡷ࠭ࡣ") in dir(WQvYkNg7SysPFLitlGEn6):
				for BbNCaFHPL0Swqv4tyJKuIgGslYrZk in WQvYkNg7SysPFLitlGEn6.scandir(bWOxP6FrcalX8d5TRNgoDn1V):
					if BbNCaFHPL0Swqv4tyJKuIgGslYrZk.is_dir(follow_symlinks=fEXMiAyG3ql4vKB):
						agLV86qMhjE(BbNCaFHPL0Swqv4tyJKuIgGslYrZk.path)
					elif BbNCaFHPL0Swqv4tyJKuIgGslYrZk.is_file(follow_symlinks=fEXMiAyG3ql4vKB):
						SSRchvijUfOW += BbNCaFHPL0Swqv4tyJKuIgGslYrZk.stat().st_size
						K5KEb3eUO7QBFtuTj8 += hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"࠱࢝")
			else:
				for BbNCaFHPL0Swqv4tyJKuIgGslYrZk in WQvYkNg7SysPFLitlGEn6.listdir(bWOxP6FrcalX8d5TRNgoDn1V):
					zQS3EpGNX1Pbjy7aWYx = WQvYkNg7SysPFLitlGEn6.path.abspath(WQvYkNg7SysPFLitlGEn6.path.join(bWOxP6FrcalX8d5TRNgoDn1V,BbNCaFHPL0Swqv4tyJKuIgGslYrZk))
					if WQvYkNg7SysPFLitlGEn6.path.isdir(zQS3EpGNX1Pbjy7aWYx):
						agLV86qMhjE(zQS3EpGNX1Pbjy7aWYx)
					elif WQvYkNg7SysPFLitlGEn6.path.isfile(zQS3EpGNX1Pbjy7aWYx):
						BBRClkiFSfjqUa2bxWheyO37vE,Rjlrpdef3CVLhnM = YAvI1Zz5J3yEFXQdWhqmo6nD(zQS3EpGNX1Pbjy7aWYx)
						SSRchvijUfOW += BBRClkiFSfjqUa2bxWheyO37vE
						K5KEb3eUO7QBFtuTj8 += Rjlrpdef3CVLhnM
		return
	try: agLV86qMhjE(bWOxP6FrcalX8d5TRNgoDn1V)
	except: pass
	return SSRchvijUfOW,K5KEb3eUO7QBFtuTj8
def Kehd45WHLX8c(showDialogs):
	if showDialogs:
		dHPVDWfG4jX5e6QEo0CKh = XVmKrby29eCGMnlEY6jz0HNOR(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩࡤ"),hXB0vKVQ5PRI91SDTprMdfuHEm4+o1u5dij9UrcbXzVS8lwIWfKpnqM(u"่ࠧๆࠣฮึ๐ฯࠡ็ึัࠬࡥ")+NXMOzZjYsmS9pf+JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠨ็ฯ่ิࠦวๅ็็ๅฬะࠠศๆ่ศ็ะษࠡ࠰࠱ࠤํ๋ฬๅัࠣห้๋ไโษอࠤฬ๊ๅื฼๋฻ฮࠦ࠮࠯๋้ࠢั๊ฯࠡษ็ูํืࠠศๆๅำ๏๋ษࠡ࠰࠱ࠤํะแา์฽ࠤ๊๊แࠡื๋ีࠥอไฦุสๅฬะࠧࡦ")+NXMOzZjYsmS9pf+xcChIL13BpR8WArNt9Pl0So(u"ࠩยࠥࠦ࠭ࡧ")+YYSh2J6BIrsm8)
		if dHPVDWfG4jX5e6QEo0CKh!=o1u5dij9UrcbXzVS8lwIWfKpnqM(u"࠲࢞"): return
	Xe6bnfEPjgqJy5FIoRi0z2v8(zm4rfojxOuLCh,VBlawK4mgHSyLEn8iqhUkz5,fEXMiAyG3ql4vKB)
	Xe6bnfEPjgqJy5FIoRi0z2v8(ly3qTrudKRIHX8c,VBlawK4mgHSyLEn8iqhUkz5,fEXMiAyG3ql4vKB)
	Xe6bnfEPjgqJy5FIoRi0z2v8(PYcdbUvGxXN9ozSwOpqyIg6uEkDM0,fEXMiAyG3ql4vKB,fEXMiAyG3ql4vKB)
	XbPWu8tcMwVagqyFdm7T9NGpHrOfQ6(Yn4MFQPHhk38a69w,fEXMiAyG3ql4vKB)
	if showDialogs:
		BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,KBkxSYaz93pu1(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ࡨ"),QvgnCALNstmuUJiET(u"ࠫฯ๋ࠠศๆ่ืาࠦศ็ฮสัࠬࡩ"))
		CfKNTtIi3OABbWcPpdF(fEXMiAyG3ql4vKB)
	return
def SEpqTheBufx6(showDialogs):
	if showDialogs:
		dHPVDWfG4jX5e6QEo0CKh = XVmKrby29eCGMnlEY6jz0HNOR(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,SqrG5mU3j96ldsFpExobw40TJY(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨࡪ"),hXB0vKVQ5PRI91SDTprMdfuHEm4+A6dMB1FlgxVivJ2fk9C(u"࠭็ๅࠢอี๏ีࠠๆีะࠤ๊๊แศฬࠪ࡫")+NXMOzZjYsmS9pf+HHoGx7Flus60(u"ࠧࡶࡵࡤ࡫ࡪࡹࡴࡢࡶࡶࠤ࠳࠴ࠠࡥࡴࡲࡴࡧࡵࡸࠡ࠰࠱ࠤࡹࡵ࡭ࡣࡵࡷࡳࡳ࡫ࡳࠡ࠰࠱ࠤࡱࡵࡧࡨࡧࡵࠤ࠳࠴ࠠ࡭ࡱࡪࠤ࠳࠴ࠠࡢࡰࡵࠫ࡬")+NXMOzZjYsmS9pf+JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠨࡁࠤࠥࠬ࡭")+YYSh2J6BIrsm8)
		if dHPVDWfG4jX5e6QEo0CKh!=o1u5dij9UrcbXzVS8lwIWfKpnqM(u"࠳࢟"): return
	Xe6bnfEPjgqJy5FIoRi0z2v8(j2Fe4vEq65GrWNTJY,fEXMiAyG3ql4vKB,fEXMiAyG3ql4vKB)
	Xe6bnfEPjgqJy5FIoRi0z2v8(gRN1a4jveA,fEXMiAyG3ql4vKB,fEXMiAyG3ql4vKB)
	Xe6bnfEPjgqJy5FIoRi0z2v8(n2ldTZvR7mxNEXDFjc,fEXMiAyG3ql4vKB,fEXMiAyG3ql4vKB)
	Xe6bnfEPjgqJy5FIoRi0z2v8(UUoYXhcBgwLW,fEXMiAyG3ql4vKB,fEXMiAyG3ql4vKB)
	Xe6bnfEPjgqJy5FIoRi0z2v8(ZZyldLpAW9gfNeuYMiQBT1IJzov,fEXMiAyG3ql4vKB,fEXMiAyG3ql4vKB)
	Xe6bnfEPjgqJy5FIoRi0z2v8(HaWZMiy2tEqfvKC3Ao0VhS,fEXMiAyG3ql4vKB,fEXMiAyG3ql4vKB)
	if showDialogs:
		BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,HHoGx7Flus60(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ࡮"),hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠪฮ๊ࠦวๅ็ึัࠥฮๆอษะࠫ࡯"))
		CfKNTtIi3OABbWcPpdF(fEXMiAyG3ql4vKB)
	return
def XbPWu8tcMwVagqyFdm7T9NGpHrOfQ6(mZbI1QrGfFn42UKRPNSpzx7w,showDialogs):
	if showDialogs:
		dHPVDWfG4jX5e6QEo0CKh = XVmKrby29eCGMnlEY6jz0HNOR(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧࡰ"),hXB0vKVQ5PRI91SDTprMdfuHEm4+CnbBKmtF1x84q7AW(u"ࠬํไࠡฬิ๎ิࠦๅิฯ้ࠣาะ่๋ษอࠤ๊๊แࠡื๋ีࠥอไอๆาࠤฤࠧࠡࠨࡱ")+YYSh2J6BIrsm8)
		if dHPVDWfG4jX5e6QEo0CKh!=zyvJMtBhrw(u"࠴ࢠ"): return
	WFYAlCyzGj1H32ovtQLnBTqhS6X = pbXIg7UFi4dV.connect(mZbI1QrGfFn42UKRPNSpzx7w)
	WFYAlCyzGj1H32ovtQLnBTqhS6X.text_factory = str
	Z8gcWPFXkx7oSrR2D = WFYAlCyzGj1H32ovtQLnBTqhS6X.cursor()
	Z8gcWPFXkx7oSrR2D.execute(HHoGx7Flus60(u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࡵࡧࡴࡩ࠽ࠪࡲ"))
	Z8gcWPFXkx7oSrR2D.execute(hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥࡹࡩࡻࡧࡶ࠿ࠬࡳ"))
	Z8gcWPFXkx7oSrR2D.execute(o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠨࡆࡈࡐࡊ࡚ࡅࠡࡈࡕࡓࡒࠦࡴࡦࡺࡷࡹࡷ࡫࠻ࠨࡴ"))
	WFYAlCyzGj1H32ovtQLnBTqhS6X.commit()
	Z8gcWPFXkx7oSrR2D.execute(JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"࡙ࠩࡅࡈ࡛ࡕࡎ࠽ࠪࡵ"))
	WFYAlCyzGj1H32ovtQLnBTqhS6X.close()
	if showDialogs:
		BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,zyvJMtBhrw(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ࡶ"),rwQN9AKhLCuMfHxjlbX0U(u"ࠫฯ๋ࠠศๆ่ืาࠦศ็ฮสัࠬࡷ"))
		CfKNTtIi3OABbWcPpdF(fEXMiAyG3ql4vKB)
	return
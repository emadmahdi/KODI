# -*- coding: utf-8 -*-
from yoY3NdGViS import *
xjPuFK3EsIZSiobQ5X = 'CIMAFANS'
headers = { 'User-Agent' : hWGMqtBy4wuLaVcj }
n0qFKQWhiBYXoTrvejVHUA4 = '_CMF_'
Str0BupDTFA = u6rbxnyjTl7I[xjPuFK3EsIZSiobQ5X][0]
def ehB18u9sQFRi(mode,url,text):
	if   mode==90: N6NCYivtV4I5rEXq = DP6FSBgNdX1rsvVR()
	elif mode==91: N6NCYivtV4I5rEXq = qJQdtBXVnP9EFwlvOKMLecDb(url)
	elif mode==92: N6NCYivtV4I5rEXq = oanus6TxUFNAhSZKpJdYlEC4mV(url)
	elif mode==94: N6NCYivtV4I5rEXq = Z5sr7Hb9NXJKVG()
	elif mode==95: N6NCYivtV4I5rEXq = GrsxUhb0PEXj2FQRAkD4q(url)
	elif mode==99: N6NCYivtV4I5rEXq = lPwaAjFTMG4n7iSLkXcEuK0Zm(text)
	else: N6NCYivtV4I5rEXq = False
	return N6NCYivtV4I5rEXq
def DP6FSBgNdX1rsvVR():
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'بحث في الموقع',hWGMqtBy4wuLaVcj,99,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'_REMEMBERRESULTS_')
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+'المضاف حديثا',hWGMqtBy4wuLaVcj,94)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+'الأحدث',Str0BupDTFA+'/?type=latest',91)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+'الأعلى تقيماً',Str0BupDTFA+'/?type=imdb',91)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+'الأكثر مشاهدة',Str0BupDTFA+'/?type=view',91)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+'المثبت',Str0BupDTFA+'/?type=pin',91)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+'جديد الأفلام',Str0BupDTFA+'/?type=newMovies',91)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+'جديد الحلقات',Str0BupDTFA+'/?type=newEpisodes',91)
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	mMQ3FkNVa4IlxqY = f1fLNcPlo2ECKtiBeug0OAvz9YM(DpQifS0oKBI1hYcO,Str0BupDTFA,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,'CIMAFANS-MENU-1st')
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('class="mainmenu(.*?)nav',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
	items = trdVA0JvFaD.findall('<li><a href="(.*?)".*?>(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	P3UK1Rr4IdYe5 = ['افلام للكبار فقط']
	for llxFwq0CUNgQtivJzkHeGV,title in items:
		title = title.strip(Mpsm2VF1OBnCRvK3qf6)
		if not any(BoSjXKxz41DcneO9UimClE in title for BoSjXKxz41DcneO9UimClE in P3UK1Rr4IdYe5):
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,91)
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('class="f-cats"(.*?)</ul>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
	items = trdVA0JvFaD.findall('<li><a href="(.*?)".*?>(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	for llxFwq0CUNgQtivJzkHeGV,title in items:
		title = title.strip(Mpsm2VF1OBnCRvK3qf6)
		if not any(BoSjXKxz41DcneO9UimClE in title for BoSjXKxz41DcneO9UimClE in P3UK1Rr4IdYe5):
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,91)
	return mMQ3FkNVa4IlxqY
def qJQdtBXVnP9EFwlvOKMLecDb(url):
	if '/search.php' in url:
		url,search = url.split('?t=')
		headers = { 'User-Agent' : hWGMqtBy4wuLaVcj , 'Content-Type' : 'application/x-www-form-urlencoded' }
		data = { 't' : search }
		sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'POST',url,data,headers,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'CIMAFANS-ITEMS-1st')
		mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	else:
		headers = { 'User-Agent' : hWGMqtBy4wuLaVcj }
		mMQ3FkNVa4IlxqY = f1fLNcPlo2ECKtiBeug0OAvz9YM(KqO5BWGQR9JVL,url,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,'CIMAFANS-ITEMS-2nd')
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('id="movies-items(.*?)class="listfoot"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o: cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
	else: cok5ZGXdQP7YhwtqyuaCnVevm6UB = hWGMqtBy4wuLaVcj
	items = trdVA0JvFaD.findall('background-image:url\((.*?)\).*?href="(.*?)".*?movie-title">(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	REbVyXis1w4Ae = []
	for Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,llxFwq0CUNgQtivJzkHeGV,title in items:
		if 'الحلقة' in title and '/c/' not in url and '/cat/' not in url:
			IIsmGy4pd7 = trdVA0JvFaD.findall('(.*?) الحلقة [0-9]+',title,trdVA0JvFaD.DOTALL)
			if IIsmGy4pd7:
				title = '_MOD_'+IIsmGy4pd7[0]
				if title not in REbVyXis1w4Ae:
					RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,95,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
					REbVyXis1w4Ae.append(title)
		elif '/video/' in llxFwq0CUNgQtivJzkHeGV: RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,92,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
		else: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,91,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('class="pagination(.*?)div',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('<a href="(.*?)".*?>(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,title in items:
			title = LNtIDdBA52P(title)
			title = title.replace('الصفحة ',hWGMqtBy4wuLaVcj)
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'صفحة '+title,llxFwq0CUNgQtivJzkHeGV,91)
	return
def GrsxUhb0PEXj2FQRAkD4q(url):
	mMQ3FkNVa4IlxqY = f1fLNcPlo2ECKtiBeug0OAvz9YM(KqO5BWGQR9JVL,url,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,'CIMAFANS-EPISODES-1st')
	Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG = trdVA0JvFaD.findall('img src="(.*?)"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG = Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG[0]
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('id="episodes-panel(.*?)div',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		name = trdVA0JvFaD.findall('itemprop="title">(.*?)<',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if name: name = name[1]
		else:
			name = MMk8qKvcJe4fQHm3EG7diBD5.getInfoLabel('ListItem.Label')
			if YYSh2J6BIrsm8 in name: name = name.split(YYSh2J6BIrsm8,1)[1]
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('href="(.*?)".*?name">(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,title in items:
			RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+name+' - '+title,llxFwq0CUNgQtivJzkHeGV,92,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
	else:
		p05pq1QcdOZrzXMJs3I7VTUjEHxKa = trdVA0JvFaD.findall('class="movietitle"><a href="(.*?)">(.*?)<',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if p05pq1QcdOZrzXMJs3I7VTUjEHxKa: llxFwq0CUNgQtivJzkHeGV,title = p05pq1QcdOZrzXMJs3I7VTUjEHxKa[0]
		else: llxFwq0CUNgQtivJzkHeGV,title = url,name
		RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,92,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
	return
def oanus6TxUFNAhSZKpJdYlEC4mV(url):
	Dvi8asSrQYX5wE3KMIxT91me,JJ98NrlGchS3BEePwv = [],[]
	mMQ3FkNVa4IlxqY = f1fLNcPlo2ECKtiBeug0OAvz9YM(KqO5BWGQR9JVL,url,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,'CIMAFANS-PLAY-1st')
	BX029UJFPvpNQsc45jbYZRh = trdVA0JvFaD.findall('text-shadow: none;">(.*?)<',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if BX029UJFPvpNQsc45jbYZRh and Dc20k3vN9hT5(xjPuFK3EsIZSiobQ5X,url,BX029UJFPvpNQsc45jbYZRh): return
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('id="links-panel(.*?)div',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('href="(.*?)"',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV in items:
			llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV+'?__download'
			Dvi8asSrQYX5wE3KMIxT91me.append(llxFwq0CUNgQtivJzkHeGV)
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('nav-tabs"(.*?)video-panel-more',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('id="(.*?)".*?embed src="(.*?)"',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for id,llxFwq0CUNgQtivJzkHeGV in items:
			title = 'سيرفر '+id
			llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV+'?named='+title+'__watch'
			Dvi8asSrQYX5wE3KMIxT91me.append(llxFwq0CUNgQtivJzkHeGV)
		items = trdVA0JvFaD.findall('data-server-src="(.*?)"',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV in items:
			if 'http' not in llxFwq0CUNgQtivJzkHeGV: llxFwq0CUNgQtivJzkHeGV = 'http:'+llxFwq0CUNgQtivJzkHeGV
			llxFwq0CUNgQtivJzkHeGV = jkiCS0UWs2dNAJcGKn6mbHD(llxFwq0CUNgQtivJzkHeGV)
			Dvi8asSrQYX5wE3KMIxT91me.append(llxFwq0CUNgQtivJzkHeGV)
	import oosSOfvdEQ
	oosSOfvdEQ.zfdYjsGLg8M6i15qZWh(Dvi8asSrQYX5wE3KMIxT91me,xjPuFK3EsIZSiobQ5X,'video',url)
	return
def Z5sr7Hb9NXJKVG():
	mMQ3FkNVa4IlxqY = f1fLNcPlo2ECKtiBeug0OAvz9YM(KqO5BWGQR9JVL,Str0BupDTFA,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,'CIMAFANS-LATEST-1st')
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('id="index-last-movie(.*?)id="index-slider-movie',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
	items = trdVA0JvFaD.findall('src="(.*?)".*?href="(.*?)" title="(.*?)"',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	for Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,llxFwq0CUNgQtivJzkHeGV,title in items:
		if '/video/' in llxFwq0CUNgQtivJzkHeGV: RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,92,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
		else: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,91,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
	return
def lPwaAjFTMG4n7iSLkXcEuK0Zm(search):
	search,vvKf4sXgZIMyEJPuC,showDialogs = IVTEJQOiMR2dYta9C(search)
	if search==hWGMqtBy4wuLaVcj: search = TrzfUidpv1LyAYqwexHJDuS()
	if search==hWGMqtBy4wuLaVcj: return
	search = search.replace(Mpsm2VF1OBnCRvK3qf6,'+')
	url = Str0BupDTFA + '/search.php?t='+search
	qJQdtBXVnP9EFwlvOKMLecDb(url)
	return
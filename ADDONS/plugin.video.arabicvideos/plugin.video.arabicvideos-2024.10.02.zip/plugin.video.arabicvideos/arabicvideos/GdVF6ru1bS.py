﻿# -*- coding: utf-8 -*-
from yoY3NdGViS import *
def ehB18u9sQFRi(JbpxsyQVXmSEYKM3vo847Ckh,sRaUPzm7IFQDqSrhy):
	if sRaUPzm7IFQDqSrhy==hWGMqtBy4wuLaVcj: return
	if JbpxsyQVXmSEYKM3vo847Ckh==1:
		yz8qvJOD6Bj2Tg5kwrfGLcCVNI = mUWYiQ2jHICA8cD6LhPTn3wpB1XyK.getCurrentWindowDialogId()
		qquzbitgB2lSIJ9myPdK0wfFYZ = mUWYiQ2jHICA8cD6LhPTn3wpB1XyK.Window(yz8qvJOD6Bj2Tg5kwrfGLcCVNI)
		sRaUPzm7IFQDqSrhy = cmYMV3Wrwp05J2RNgLs9vCT8X(sRaUPzm7IFQDqSrhy)
		qquzbitgB2lSIJ9myPdK0wfFYZ.getControl(311).setLabel(sRaUPzm7IFQDqSrhy)
	if JbpxsyQVXmSEYKM3vo847Ckh==0:
		X3X4Y8RzxSVfZJUFDe='X'
		if H4qZ2hwilNJYTmCFEQyaSs98cPM0gR: BB69zZSTq1QRfGJ8eLpPXkV5n2rUg = isinstance(sRaUPzm7IFQDqSrhy,str)
		else: BB69zZSTq1QRfGJ8eLpPXkV5n2rUg = isinstance(sRaUPzm7IFQDqSrhy,unicode)
		if BB69zZSTq1QRfGJ8eLpPXkV5n2rUg==True: X3X4Y8RzxSVfZJUFDe='U'
		LGxlDdM6Y0yRTV37JWt9ckO=str(type(sRaUPzm7IFQDqSrhy))+Mpsm2VF1OBnCRvK3qf6+sRaUPzm7IFQDqSrhy+Mpsm2VF1OBnCRvK3qf6+X3X4Y8RzxSVfZJUFDe+Mpsm2VF1OBnCRvK3qf6
		for PPuqrvDLEViYOMf1dmkK7 in range(0,len(sRaUPzm7IFQDqSrhy),1):
			LGxlDdM6Y0yRTV37JWt9ckO += hex(ord(sRaUPzm7IFQDqSrhy[PPuqrvDLEViYOMf1dmkK7])).replace('0x',hWGMqtBy4wuLaVcj)+Mpsm2VF1OBnCRvK3qf6
		sRaUPzm7IFQDqSrhy = cmYMV3Wrwp05J2RNgLs9vCT8X(sRaUPzm7IFQDqSrhy)
		X3X4Y8RzxSVfZJUFDe='X'
		if H4qZ2hwilNJYTmCFEQyaSs98cPM0gR: BB69zZSTq1QRfGJ8eLpPXkV5n2rUg = isinstance(sRaUPzm7IFQDqSrhy, str)
		else: BB69zZSTq1QRfGJ8eLpPXkV5n2rUg = isinstance(sRaUPzm7IFQDqSrhy, unicode)
		if BB69zZSTq1QRfGJ8eLpPXkV5n2rUg==True: X3X4Y8RzxSVfZJUFDe='U'
		OOZfghc1qdeAaPtlpKIuzCSTLU5rkx=str(type(sRaUPzm7IFQDqSrhy))+Mpsm2VF1OBnCRvK3qf6+sRaUPzm7IFQDqSrhy+Mpsm2VF1OBnCRvK3qf6+X3X4Y8RzxSVfZJUFDe+Mpsm2VF1OBnCRvK3qf6
		for PPuqrvDLEViYOMf1dmkK7 in range(0,len(sRaUPzm7IFQDqSrhy),1):
			OOZfghc1qdeAaPtlpKIuzCSTLU5rkx += hex(ord(sRaUPzm7IFQDqSrhy[PPuqrvDLEViYOMf1dmkK7])).replace('0x',hWGMqtBy4wuLaVcj)+Mpsm2VF1OBnCRvK3qf6
	return
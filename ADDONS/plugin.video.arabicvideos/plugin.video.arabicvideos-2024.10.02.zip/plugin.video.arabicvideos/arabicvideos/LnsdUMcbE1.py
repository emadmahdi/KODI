# -*- coding: utf-8 -*-
from yoY3NdGViS import *
xjPuFK3EsIZSiobQ5X = 'HALACIMA'
n0qFKQWhiBYXoTrvejVHUA4 = '_HLC_'
Str0BupDTFA = u6rbxnyjTl7I[xjPuFK3EsIZSiobQ5X][0]
P3UK1Rr4IdYe5 = ['مصارعة','احدث البرامج','احدث الالعاب','احدث الاغانى']
def ehB18u9sQFRi(mode,url,text):
	if   mode==80: N6NCYivtV4I5rEXq = DP6FSBgNdX1rsvVR()
	elif mode==81: N6NCYivtV4I5rEXq = wg5aF3e8rcDh7SGpW6M1OPnkU(url,text)
	elif mode==82: N6NCYivtV4I5rEXq = oanus6TxUFNAhSZKpJdYlEC4mV(url)
	elif mode==83: N6NCYivtV4I5rEXq = GrsxUhb0PEXj2FQRAkD4q(url)
	elif mode==89: N6NCYivtV4I5rEXq = lPwaAjFTMG4n7iSLkXcEuK0Zm(text)
	else: N6NCYivtV4I5rEXq = False
	return N6NCYivtV4I5rEXq
def DP6FSBgNdX1rsvVR():
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',Str0BupDTFA,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'HALACIMA-MENU-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	cbYKa2SXGwRCiQIW5NeosU9k = RRNODILCtGzvgpx(Str0BupDTFA,'url')
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'بحث في الموقع',hWGMqtBy4wuLaVcj,89,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'_REMEMBERRESULTS_')
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('main-content(.*?)</ul>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
	items = trdVA0JvFaD.findall('data-name="(.*?)".*?</i>(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	for Zn0DwEg9b7zxavJ8yUqHO5dM1,title in items:
		llxFwq0CUNgQtivJzkHeGV = cbYKa2SXGwRCiQIW5NeosU9k+'/ajax/getItem?item='+Zn0DwEg9b7zxavJ8yUqHO5dM1+'&Ajax=1'
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,81)
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('"nav-main"(.*?)</nav>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
	items = trdVA0JvFaD.findall('href="(.*?)">(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	for llxFwq0CUNgQtivJzkHeGV,title in items:
		if llxFwq0CUNgQtivJzkHeGV=='#': continue
		if title in P3UK1Rr4IdYe5: continue
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,81)
	return
def wg5aF3e8rcDh7SGpW6M1OPnkU(url,Zn0DwEg9b7zxavJ8yUqHO5dM1=hWGMqtBy4wuLaVcj):
	items = []
	if '/ajax/getItem' in url or '/ajax/loadMore' in url:
		NPM3HKQ57xe,OucJVrWRKSqDChiG7yn3oz0dafZF = fWM9y4vTcPLS0b3UKItC1os5(url)
		PwvNmnqXKrYVZugB5c8 = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'POST',NPM3HKQ57xe,OucJVrWRKSqDChiG7yn3oz0dafZF,PwvNmnqXKrYVZugB5c8,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'HALACIMA-TITLES-1st')
		mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = [mMQ3FkNVa4IlxqY]
	else:
		sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'HALACIMA-TITLES-2nd')
		mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
		if Zn0DwEg9b7zxavJ8yUqHO5dM1=='featured':
			DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('"container"(.*?)"container"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
			cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
			items = trdVA0JvFaD.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		elif '"section-post mb-10"' in mMQ3FkNVa4IlxqY:
			DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('"section-post mb-10"(.*?)"container"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		else:
			DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('<article(.*?)"pagination"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if not DJvksH7ZAFUqW9OyQnbGjPCtwR1o: return
	cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
	if not items:
		items = trdVA0JvFaD.findall('href="(.*?)" title="(.*?)".*?data-original="(.*?)"',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		if not items: items = trdVA0JvFaD.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	REbVyXis1w4Ae = []
	nNBCdTs98RztMyODHpL63ZUKm4P = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for llxFwq0CUNgQtivJzkHeGV,title,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG in items:
		llxFwq0CUNgQtivJzkHeGV = jkiCS0UWs2dNAJcGKn6mbHD(llxFwq0CUNgQtivJzkHeGV).strip('/')
		IIsmGy4pd7 = trdVA0JvFaD.findall('(.*?) الحلقة \d+',title,trdVA0JvFaD.DOTALL)
		if '/series/' in llxFwq0CUNgQtivJzkHeGV:
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,83,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
		elif 'سلاسل' not in url and any(BoSjXKxz41DcneO9UimClE in title for BoSjXKxz41DcneO9UimClE in nNBCdTs98RztMyODHpL63ZUKm4P):
			RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,82,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
		elif IIsmGy4pd7 and 'الحلقة' in title:
			title = '_MOD_' + IIsmGy4pd7[0]
			if title not in REbVyXis1w4Ae:
				RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,83,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
				REbVyXis1w4Ae.append(title)
		elif '/movies/' in llxFwq0CUNgQtivJzkHeGV:
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,81,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
		else: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,83,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
	if Zn0DwEg9b7zxavJ8yUqHO5dM1==hWGMqtBy4wuLaVcj:
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('"pagination"(.*?)<footer',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
			cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
			items = trdVA0JvFaD.findall('href="(.*?)".*?>(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
			for llxFwq0CUNgQtivJzkHeGV,title in items:
				if llxFwq0CUNgQtivJzkHeGV=="": continue
				if title!=hWGMqtBy4wuLaVcj: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'صفحة '+title,llxFwq0CUNgQtivJzkHeGV,81)
	if '/ajax/getItem' in url or '/ajax/loadMore' in url:
		if '/ajax/getItem' in url:
			url = url.replace('/ajax/getItem','/ajax/loadMore')+'&offset=20'
		elif '/ajax/loadMore' in url:
			url,offset = url.split('&offset=')
			offset = int(offset)+20
			url = url+'&offset='+str(offset)
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'هناك المزيد',url,81)
	return
def GrsxUhb0PEXj2FQRAkD4q(url):
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'HALACIMA-EPISODES-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	cLV4wifngjAdbePKq2x7SDhXGYlO0 = trdVA0JvFaD.findall('"getSeasonsBySeries(.*?)"container"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	v2V8Nmrwf4 = trdVA0JvFaD.findall('"list-episodes"(.*?)"container"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if cLV4wifngjAdbePKq2x7SDhXGYlO0 and '/series/' not in url:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = cLV4wifngjAdbePKq2x7SDhXGYlO0[0]
		items = trdVA0JvFaD.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,title,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG in items:
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,83,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
	elif v2V8Nmrwf4:
		Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG = trdVA0JvFaD.findall('"image" src="(.*?)"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG = Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG[0]
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = v2V8Nmrwf4[0]
		items = trdVA0JvFaD.findall('href="(.*?)" title="(.*?)"',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,title in items:
			RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,82,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
	return
def oanus6TxUFNAhSZKpJdYlEC4mV(url):
	NPM3HKQ57xe = url.replace('/movies/','/watch_movies/')
	NPM3HKQ57xe = NPM3HKQ57xe.replace('/episodes/','/watch_episodes/')
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',NPM3HKQ57xe,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'HALACIMA-PLAY-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	cbYKa2SXGwRCiQIW5NeosU9k = RRNODILCtGzvgpx(NPM3HKQ57xe,'url')
	Dvi8asSrQYX5wE3KMIxT91me = []
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('"servers"(.*?)</ul>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		TsFgQdloabE4YpPWV = trdVA0JvFaD.findall('postID = "(.*?)"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		TsFgQdloabE4YpPWV = TsFgQdloabE4YpPWV[0]
		items = trdVA0JvFaD.findall("getPlayer\('(.*?)'.*?</i>(.*?)</a>",cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for SODQ7qlNYoZcFK8e50rBsJaAHxiXjE,title in items:
			title = title.replace(NXMOzZjYsmS9pf,hWGMqtBy4wuLaVcj).strip(Mpsm2VF1OBnCRvK3qf6)
			llxFwq0CUNgQtivJzkHeGV = cbYKa2SXGwRCiQIW5NeosU9k+'/ajax/getPlayer?server='+SODQ7qlNYoZcFK8e50rBsJaAHxiXjE+'&postID='+TsFgQdloabE4YpPWV+'&Ajax=1'
			llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV+'?named='+title+'__watch'
			Dvi8asSrQYX5wE3KMIxT91me.append(llxFwq0CUNgQtivJzkHeGV)
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('"downs"(.*?)</ul>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('href="(.*?)" title="(.*?)"',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,name in items:
			llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV+'?named='+name+'__download'
			Dvi8asSrQYX5wE3KMIxT91me.append(llxFwq0CUNgQtivJzkHeGV)
	import oosSOfvdEQ
	oosSOfvdEQ.zfdYjsGLg8M6i15qZWh(Dvi8asSrQYX5wE3KMIxT91me,xjPuFK3EsIZSiobQ5X,'video',url)
	return
def lPwaAjFTMG4n7iSLkXcEuK0Zm(search):
	search,vvKf4sXgZIMyEJPuC,showDialogs = IVTEJQOiMR2dYta9C(search)
	if search==hWGMqtBy4wuLaVcj: search = TrzfUidpv1LyAYqwexHJDuS()
	if search==hWGMqtBy4wuLaVcj: return
	search = search.replace(Mpsm2VF1OBnCRvK3qf6,'-')
	url = Str0BupDTFA+'/search/'+search+'.html'
	wg5aF3e8rcDh7SGpW6M1OPnkU(url)
	return
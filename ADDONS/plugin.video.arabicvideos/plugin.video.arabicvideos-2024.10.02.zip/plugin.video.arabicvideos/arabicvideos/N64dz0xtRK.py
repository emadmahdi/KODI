# -*- coding: utf-8 -*-
from yoY3NdGViS import *
import bs4 as EtTfaX0NeFMOQ
xjPuFK3EsIZSiobQ5X = 'ELCINEMA'
n0qFKQWhiBYXoTrvejVHUA4 = '_ELC_'
Str0BupDTFA = u6rbxnyjTl7I[xjPuFK3EsIZSiobQ5X][0]
headers = {'Referer':Str0BupDTFA}
P3UK1Rr4IdYe5 = []
def ehB18u9sQFRi(mode,url,text):
	if   mode==510: N6NCYivtV4I5rEXq = DP6FSBgNdX1rsvVR()
	elif mode==511: N6NCYivtV4I5rEXq = s5TCkL84nl3oFrJQR(url)
	elif mode==512: N6NCYivtV4I5rEXq = XSCYc8Wwgv7I5rniMyDoRGK1Azbfd(url)
	elif mode==513: N6NCYivtV4I5rEXq = HxwKq02SF4b(url)
	elif mode==514: N6NCYivtV4I5rEXq = ffXlHkWAc6PxVoEb(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==515: N6NCYivtV4I5rEXq = ffXlHkWAc6PxVoEb(url,'SPECIFIED_FILTER___'+text)
	elif mode==516: N6NCYivtV4I5rEXq = PAUhr4gEwc7RMXIn5SV1T(text)
	elif mode==517: N6NCYivtV4I5rEXq = oCG4sjUr6kKl7qwyV(url)
	elif mode==518: N6NCYivtV4I5rEXq = VBzP7iJTc6GYML4UX(url)
	elif mode==519: N6NCYivtV4I5rEXq = lPwaAjFTMG4n7iSLkXcEuK0Zm(text)
	elif mode==520: N6NCYivtV4I5rEXq = YdBfXbHQUPLScFzZJm(url)
	elif mode==521: N6NCYivtV4I5rEXq = GLBJlRIqo7g(url)
	elif mode==522: N6NCYivtV4I5rEXq = oanus6TxUFNAhSZKpJdYlEC4mV(url)
	elif mode==523: N6NCYivtV4I5rEXq = B5H81AYZELo(text)
	elif mode==524: N6NCYivtV4I5rEXq = hB6FEo2YLCHqTAm0U()
	elif mode==525: N6NCYivtV4I5rEXq = mOay12ElvFoet5rfPGnb9()
	elif mode==526: N6NCYivtV4I5rEXq = GGadUQX3ybSDK()
	elif mode==527: N6NCYivtV4I5rEXq = bilSXyGpZcPHQ1TnJgw2C()
	else: N6NCYivtV4I5rEXq = False
	return N6NCYivtV4I5rEXq
def DP6FSBgNdX1rsvVR():
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'بحث بموسوعة السينما',hWGMqtBy4wuLaVcj,519)
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'موسوعة الأعمال',hWGMqtBy4wuLaVcj,525)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'موسوعة الأشخاص',hWGMqtBy4wuLaVcj,526)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'موسوعة المصنفات',hWGMqtBy4wuLaVcj,527)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'موسوعة المنوعات',hWGMqtBy4wuLaVcj,524)
	return
def hB6FEo2YLCHqTAm0U():
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+' فيديوهات - خاصة',Str0BupDTFA+'/video',520)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'فيديوهات - أحدث',Str0BupDTFA+'/video/latest',521)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'فيديوهات - أقدم',Str0BupDTFA+'/video/oldest',521)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'فيديوهات - أكثر مشاهدة',Str0BupDTFA+'/video/views',521)
	return
def mOay12ElvFoet5rfPGnb9():
	xnAr3c9bEmYNSoTuFgypQz0BGaV1 = Str0BupDTFA+'/lineup?utf8=%E2%9C%93'
	gptnz7oT2klGiQ5IsUB = xnAr3c9bEmYNSoTuFgypQz0BGaV1+'&type=2&category=1&foreign=false&tag='
	mGlCxFd2rRuWHvA705bncK = xnAr3c9bEmYNSoTuFgypQz0BGaV1+'&type=2&category=3&foreign=false&tag='
	ibdXUDCMcwahnvYk4FoLsI9Ap3OJEz = xnAr3c9bEmYNSoTuFgypQz0BGaV1+'&type=2&category=1&foreign=true&tag='
	Taer5Etdhg7lxbCDmivXKQnYAsO = xnAr3c9bEmYNSoTuFgypQz0BGaV1+'&type=2&category=3&foreign=true&tag='
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'مصنفات أفلام عربي',gptnz7oT2klGiQ5IsUB,511)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'مصنفات مسلسلات عربي',mGlCxFd2rRuWHvA705bncK,511)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'مصنفات أفلام اجنبي',ibdXUDCMcwahnvYk4FoLsI9Ap3OJEz,511)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'مصنفات مسلسلات اجنبي',Taer5Etdhg7lxbCDmivXKQnYAsO,511)
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'فهرس أعمال أبجدي',Str0BupDTFA+'/index/work/alphabet',517)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'فهرس  بلد الإنتاج',Str0BupDTFA+'/index/work/country',517)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'فهرس اللغة',Str0BupDTFA+'/index/work/language',517)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'فهرس مصنفات العمل',Str0BupDTFA+'/index/work/genre',517)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'فهرس سنة الإصدار',Str0BupDTFA+'/index/work/release_year',517)
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'مواسم - فلتر محدد',Str0BupDTFA+'/seasonals',515)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'مواسم - فلتر كامل',Str0BupDTFA+'/seasonals',514)
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'مصنفات - فلتر محدد',Str0BupDTFA+'/lineup',515)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'مصنفات - فلتر كامل',Str0BupDTFA+'/lineup',514)
	return
def bilSXyGpZcPHQ1TnJgw2C():
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(DpQifS0oKBI1hYcO,'GET',Str0BupDTFA+'/lineup',hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'ELCINEMA-MENU-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	H5JvQIEuUxmV4GWFBY = EtTfaX0NeFMOQ.BeautifulSoup(mMQ3FkNVa4IlxqY,'html.parser',multi_valued_attributes=None)
	cok5ZGXdQP7YhwtqyuaCnVevm6UB = H5JvQIEuUxmV4GWFBY.find('select',attrs={'name':'tag'})
	vvKf4sXgZIMyEJPuC = cok5ZGXdQP7YhwtqyuaCnVevm6UB.find_all('option')
	for PBo1KkyMCgH8eNDaLtZVcr3EnIi2 in vvKf4sXgZIMyEJPuC:
		BoSjXKxz41DcneO9UimClE = PBo1KkyMCgH8eNDaLtZVcr3EnIi2.get('value')
		if not BoSjXKxz41DcneO9UimClE: continue
		title = PBo1KkyMCgH8eNDaLtZVcr3EnIi2.text
		if VKiGj1LundAJQwEXcqgxC:
			title = title.encode(a7VXeDU82IfQEnPZAdiT)
			BoSjXKxz41DcneO9UimClE = BoSjXKxz41DcneO9UimClE.encode(a7VXeDU82IfQEnPZAdiT)
		llxFwq0CUNgQtivJzkHeGV = Str0BupDTFA+'/lineup?utf8=%E2%9C%93&type=&category=&foreign=&tag='+BoSjXKxz41DcneO9UimClE
		title = title.replace('قائمة ',hWGMqtBy4wuLaVcj)
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,511)
	return
def GGadUQX3ybSDK():
	xnAr3c9bEmYNSoTuFgypQz0BGaV1 = Str0BupDTFA+'/lineup?utf8=%E2%9C%93'
	IHYesWZQ9DKd = xnAr3c9bEmYNSoTuFgypQz0BGaV1+'&type=1&category=&foreign=&tag='
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'مصنفات أشخاص',IHYesWZQ9DKd,511)
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'فهرس أشخاص أبجدي',Str0BupDTFA+'/index/person/alphabet',517)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'فهرس موطن',Str0BupDTFA+'/index/person/nationality',517)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'فهرس  تاريخ الميلاد',Str0BupDTFA+'/index/person/birth_year',517)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'فهرس  تاريخ الوفاة',Str0BupDTFA+'/index/person/death_year',517)
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'مصنفات - فلتر محدد',Str0BupDTFA+'/lineup',515)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'مصنفات - فلتر كامل',Str0BupDTFA+'/lineup',514)
	return
def s5TCkL84nl3oFrJQR(url):
	if '/seasonals' in url: C9VNOL3UmyXPYbGrJ8 = 0
	elif '/lineup' in url: C9VNOL3UmyXPYbGrJ8 = 1
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(DpQifS0oKBI1hYcO,'GET',url,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'ELCINEMA-LISTS-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	H5JvQIEuUxmV4GWFBY = EtTfaX0NeFMOQ.BeautifulSoup(mMQ3FkNVa4IlxqY,'html.parser',multi_valued_attributes=None)
	rqIW37cd0iT1msDzRevOM = H5JvQIEuUxmV4GWFBY.find_all(class_='jumbo-theater clearfix')
	for cok5ZGXdQP7YhwtqyuaCnVevm6UB in rqIW37cd0iT1msDzRevOM:
		title = cok5ZGXdQP7YhwtqyuaCnVevm6UB.find_all('a')[C9VNOL3UmyXPYbGrJ8].text
		llxFwq0CUNgQtivJzkHeGV = Str0BupDTFA+cok5ZGXdQP7YhwtqyuaCnVevm6UB.find_all('a')[C9VNOL3UmyXPYbGrJ8].get('href')
		if VKiGj1LundAJQwEXcqgxC:
			title = title.encode(a7VXeDU82IfQEnPZAdiT)
			llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV.encode(a7VXeDU82IfQEnPZAdiT)
		if not rqIW37cd0iT1msDzRevOM:
			XSCYc8Wwgv7I5rniMyDoRGK1Azbfd(llxFwq0CUNgQtivJzkHeGV)
			return
		else:
			title = title.replace('قائمة ',hWGMqtBy4wuLaVcj)
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,512)
	XzIHbY0Q5OD(H5JvQIEuUxmV4GWFBY,511)
	return
def XzIHbY0Q5OD(H5JvQIEuUxmV4GWFBY,mode):
	cok5ZGXdQP7YhwtqyuaCnVevm6UB = H5JvQIEuUxmV4GWFBY.find(class_='pagination')
	if cok5ZGXdQP7YhwtqyuaCnVevm6UB:
		K7iJndLWmYPR = cok5ZGXdQP7YhwtqyuaCnVevm6UB.find_all('a')
		e9BTJyl8vm = cok5ZGXdQP7YhwtqyuaCnVevm6UB.find_all('li')
		y9lN0MazwBmfK8QEtc5k = list(zip(K7iJndLWmYPR,e9BTJyl8vm))
		JpzD0lv9cYM6XrHeqCa = -1
		RJvIGEwFiSzqyQdhXm = len(y9lN0MazwBmfK8QEtc5k)
		for sHmDY4STJ1cgEeyRMCk9LI5j8t,X5nUlGpmhKD2bvIL9WOHidEC37gRe in y9lN0MazwBmfK8QEtc5k:
			JpzD0lv9cYM6XrHeqCa += 1
			X5nUlGpmhKD2bvIL9WOHidEC37gRe = X5nUlGpmhKD2bvIL9WOHidEC37gRe['class']
			if 'unavailable' in X5nUlGpmhKD2bvIL9WOHidEC37gRe or 'current' in X5nUlGpmhKD2bvIL9WOHidEC37gRe: continue
			u25Car4veWZpIhniLSUKqH83Gf = sHmDY4STJ1cgEeyRMCk9LI5j8t.text
			MDSF21x9HK3AZyGUhcb = Str0BupDTFA+sHmDY4STJ1cgEeyRMCk9LI5j8t.get('href')
			if VKiGj1LundAJQwEXcqgxC:
				u25Car4veWZpIhniLSUKqH83Gf = u25Car4veWZpIhniLSUKqH83Gf.encode(a7VXeDU82IfQEnPZAdiT)
				MDSF21x9HK3AZyGUhcb = MDSF21x9HK3AZyGUhcb.encode(a7VXeDU82IfQEnPZAdiT)
			if   JpzD0lv9cYM6XrHeqCa==0: u25Car4veWZpIhniLSUKqH83Gf = 'أولى'
			elif JpzD0lv9cYM6XrHeqCa==1: u25Car4veWZpIhniLSUKqH83Gf = 'سابقة'
			elif JpzD0lv9cYM6XrHeqCa==RJvIGEwFiSzqyQdhXm-2: u25Car4veWZpIhniLSUKqH83Gf = 'لاحقة'
			elif JpzD0lv9cYM6XrHeqCa==RJvIGEwFiSzqyQdhXm-1: u25Car4veWZpIhniLSUKqH83Gf = 'أخيرة'
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'صفحة '+u25Car4veWZpIhniLSUKqH83Gf,MDSF21x9HK3AZyGUhcb,mode)
	return
def XSCYc8Wwgv7I5rniMyDoRGK1Azbfd(url):
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(DpQifS0oKBI1hYcO,'GET',url,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'ELCINEMA-TITLES1-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	H5JvQIEuUxmV4GWFBY = EtTfaX0NeFMOQ.BeautifulSoup(mMQ3FkNVa4IlxqY,'html.parser',multi_valued_attributes=None)
	rqIW37cd0iT1msDzRevOM = H5JvQIEuUxmV4GWFBY.find_all(class_='row')
	items,jlIGSiUuRophY8A = [],True
	for cok5ZGXdQP7YhwtqyuaCnVevm6UB in rqIW37cd0iT1msDzRevOM:
		if not cok5ZGXdQP7YhwtqyuaCnVevm6UB.find(class_='thumbnail-wrapper'): continue
		if jlIGSiUuRophY8A: jlIGSiUuRophY8A = False ; continue
		UU5clJBpYNCZXaTRzwIrSGQd = []
		KS34jXk0F9ohCdWLv = cok5ZGXdQP7YhwtqyuaCnVevm6UB.find_all(class_=['censorship red','censorship purple'])
		for m4A0FcrREbSKzouIk in KS34jXk0F9ohCdWLv:
			wqE9AVn6gRFQj = m4A0FcrREbSKzouIk.find_all('li')[1].text
			if VKiGj1LundAJQwEXcqgxC:
				wqE9AVn6gRFQj = wqE9AVn6gRFQj.encode(a7VXeDU82IfQEnPZAdiT)
			UU5clJBpYNCZXaTRzwIrSGQd.append(wqE9AVn6gRFQj)
		if not Dc20k3vN9hT5(xjPuFK3EsIZSiobQ5X,hWGMqtBy4wuLaVcj,UU5clJBpYNCZXaTRzwIrSGQd,False):
			nWE8aO53lFfD = cok5ZGXdQP7YhwtqyuaCnVevm6UB.find('img').get('data-src')
			title = cok5ZGXdQP7YhwtqyuaCnVevm6UB.find('h3')
			name = title.find('a').text
			llxFwq0CUNgQtivJzkHeGV = Str0BupDTFA+title.find('a').get('href')
			ufIeJbRQN4r2VjYsmq = cok5ZGXdQP7YhwtqyuaCnVevm6UB.find(class_='no-margin')
			DXL7FS2Qrs0zKiN = cok5ZGXdQP7YhwtqyuaCnVevm6UB.find(class_='legend')
			if ufIeJbRQN4r2VjYsmq: ufIeJbRQN4r2VjYsmq = ufIeJbRQN4r2VjYsmq.text
			if DXL7FS2Qrs0zKiN: DXL7FS2Qrs0zKiN = DXL7FS2Qrs0zKiN.text
			if VKiGj1LundAJQwEXcqgxC:
				nWE8aO53lFfD = nWE8aO53lFfD.encode(a7VXeDU82IfQEnPZAdiT)
				name = name.encode(a7VXeDU82IfQEnPZAdiT)
				llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV.encode(a7VXeDU82IfQEnPZAdiT)
				if ufIeJbRQN4r2VjYsmq: ufIeJbRQN4r2VjYsmq = ufIeJbRQN4r2VjYsmq.encode(a7VXeDU82IfQEnPZAdiT)
			SX7OT3VLGp2iQm = {}
			if DXL7FS2Qrs0zKiN: SX7OT3VLGp2iQm['stars'] = DXL7FS2Qrs0zKiN
			if ufIeJbRQN4r2VjYsmq:
				ufIeJbRQN4r2VjYsmq = ufIeJbRQN4r2VjYsmq.replace(NXMOzZjYsmS9pf,' .. ')
				SX7OT3VLGp2iQm['plot'] = ufIeJbRQN4r2VjYsmq.replace('...اقرأ المزيد',hWGMqtBy4wuLaVcj)
			if '/work/' in llxFwq0CUNgQtivJzkHeGV:
				RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+name,llxFwq0CUNgQtivJzkHeGV,516,nWE8aO53lFfD,hWGMqtBy4wuLaVcj,name,hWGMqtBy4wuLaVcj,SX7OT3VLGp2iQm)
			elif '/person/' in llxFwq0CUNgQtivJzkHeGV: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+name,llxFwq0CUNgQtivJzkHeGV,513,nWE8aO53lFfD,hWGMqtBy4wuLaVcj,name,hWGMqtBy4wuLaVcj,SX7OT3VLGp2iQm)
	XzIHbY0Q5OD(H5JvQIEuUxmV4GWFBY,512)
	return
def HxwKq02SF4b(url):
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(DpQifS0oKBI1hYcO,'GET',url,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'ELCINEMA-TITLES2-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	H5JvQIEuUxmV4GWFBY = EtTfaX0NeFMOQ.BeautifulSoup(mMQ3FkNVa4IlxqY,'html.parser',multi_valued_attributes=None)
	rqIW37cd0iT1msDzRevOM = H5JvQIEuUxmV4GWFBY.find_all('li')
	aGtU0OYsI2puj19dwhFqVDkbS,items = [],[]
	for cok5ZGXdQP7YhwtqyuaCnVevm6UB in rqIW37cd0iT1msDzRevOM:
		if not cok5ZGXdQP7YhwtqyuaCnVevm6UB.find(class_='thumbnail-wrapper'): continue
		if not cok5ZGXdQP7YhwtqyuaCnVevm6UB.find(class_=['unstyled','unstyled text-center']): continue
		if cok5ZGXdQP7YhwtqyuaCnVevm6UB.find(class_='hide'): continue
		title = cok5ZGXdQP7YhwtqyuaCnVevm6UB.find(class_=['unstyled','unstyled text-center'])
		name = title.find('a').text
		if name in aGtU0OYsI2puj19dwhFqVDkbS: continue
		aGtU0OYsI2puj19dwhFqVDkbS.append(name)
		llxFwq0CUNgQtivJzkHeGV = Str0BupDTFA+title.find('a').get('href')
		if '/search/work/' in url: nWE8aO53lFfD = cok5ZGXdQP7YhwtqyuaCnVevm6UB.find('img').get('src')
		elif '/search/person/' in url: nWE8aO53lFfD = cok5ZGXdQP7YhwtqyuaCnVevm6UB.find('img').get('data-src')
		elif '/search/video/' in url: nWE8aO53lFfD = cok5ZGXdQP7YhwtqyuaCnVevm6UB.find('img').get('data-src')
		else: nWE8aO53lFfD = cok5ZGXdQP7YhwtqyuaCnVevm6UB.find('img').get('src')
		if VKiGj1LundAJQwEXcqgxC:
			name = name.encode(a7VXeDU82IfQEnPZAdiT)
			llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV.encode(a7VXeDU82IfQEnPZAdiT)
			nWE8aO53lFfD = nWE8aO53lFfD.encode(a7VXeDU82IfQEnPZAdiT)
		name = name.strip(Mpsm2VF1OBnCRvK3qf6)
		items.append((name,llxFwq0CUNgQtivJzkHeGV,nWE8aO53lFfD))
	if '/search/person/' in url: items = sorted(items,reverse=False,key=lambda key: key[0])
	for name,llxFwq0CUNgQtivJzkHeGV,nWE8aO53lFfD in items:
		if '/search/video/' in url: RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+name,llxFwq0CUNgQtivJzkHeGV,522,nWE8aO53lFfD)
		elif '/search/person/' in url: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+name,llxFwq0CUNgQtivJzkHeGV,513,nWE8aO53lFfD,hWGMqtBy4wuLaVcj,name)
		else: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+name,llxFwq0CUNgQtivJzkHeGV,516,nWE8aO53lFfD,hWGMqtBy4wuLaVcj,name)
	return
def PAUhr4gEwc7RMXIn5SV1T(text):
	text = text.replace('الإعلان',hWGMqtBy4wuLaVcj).replace('لفيلم',hWGMqtBy4wuLaVcj).replace('الرسمي',hWGMqtBy4wuLaVcj)
	text = text.replace('إعلان',hWGMqtBy4wuLaVcj).replace('فيلم',hWGMqtBy4wuLaVcj).replace('البرومو',hWGMqtBy4wuLaVcj)
	text = text.replace('التشويقي',hWGMqtBy4wuLaVcj).replace('لمسلسل',hWGMqtBy4wuLaVcj).replace('مسلسل',hWGMqtBy4wuLaVcj)
	text = text.replace(':',hWGMqtBy4wuLaVcj).replace(')',hWGMqtBy4wuLaVcj).replace('(',hWGMqtBy4wuLaVcj).replace(',',hWGMqtBy4wuLaVcj)
	text = text.replace('_',hWGMqtBy4wuLaVcj).replace(';',hWGMqtBy4wuLaVcj).replace('-',hWGMqtBy4wuLaVcj).replace('.',hWGMqtBy4wuLaVcj)
	text = text.replace('\'',hWGMqtBy4wuLaVcj).replace('\"',hWGMqtBy4wuLaVcj)
	text = text.replace(nIDXGaRHv7mOohe0Y8dLstECM,Mpsm2VF1OBnCRvK3qf6).replace(lG0yV5QNFHc2RbXM1Wp,Mpsm2VF1OBnCRvK3qf6).replace(FqcVAkh7WjIXHdDKf8nvuyRo,Mpsm2VF1OBnCRvK3qf6)
	text = text.strip(Mpsm2VF1OBnCRvK3qf6)
	u9g4VS8C6EYbtRrAkWJsp7Feij = text.count(Mpsm2VF1OBnCRvK3qf6)+1
	if u9g4VS8C6EYbtRrAkWJsp7Feij==1:
		B5H81AYZELo(text)
		return
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',n0qFKQWhiBYXoTrvejVHUA4+hXB0vKVQ5PRI91SDTprMdfuHEm4+'==== كلمات للبحث ===='+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	L7LeHp4ED5KGsA9oIx = text.split(Mpsm2VF1OBnCRvK3qf6)
	DDflEg6jPOABLZSdY = pow(2,u9g4VS8C6EYbtRrAkWJsp7Feij)
	WWswl5fBHQAgj6 = []
	def ZZNm2Ry6YCTG1aHtsVF3O5oI(u752etRpvTIjZxlqOJN,uOWdMNLcIFpDHmjortlq1ki6XZBw2):
		if u752etRpvTIjZxlqOJN=='1': return uOWdMNLcIFpDHmjortlq1ki6XZBw2
		return hWGMqtBy4wuLaVcj
	for JpzD0lv9cYM6XrHeqCa in range(DDflEg6jPOABLZSdY,0,-1):
		uaV31HyBALvJ5RdzFPbEZc7s = list(u9g4VS8C6EYbtRrAkWJsp7Feij*'0'+bin(JpzD0lv9cYM6XrHeqCa)[2:])[-u9g4VS8C6EYbtRrAkWJsp7Feij:]
		uaV31HyBALvJ5RdzFPbEZc7s = reversed(uaV31HyBALvJ5RdzFPbEZc7s)
		FEpnOiHwDL6soV9 = map(ZZNm2Ry6YCTG1aHtsVF3O5oI,uaV31HyBALvJ5RdzFPbEZc7s,L7LeHp4ED5KGsA9oIx)
		title = Mpsm2VF1OBnCRvK3qf6.join(filter(None,FEpnOiHwDL6soV9))
		if VKiGj1LundAJQwEXcqgxC: m4eVoJdSU51qs3y8Gg06fZNau7A = title.decode(a7VXeDU82IfQEnPZAdiT)
		else: m4eVoJdSU51qs3y8Gg06fZNau7A = title
		if len(m4eVoJdSU51qs3y8Gg06fZNau7A)>2 and title not in WWswl5fBHQAgj6:
			WWswl5fBHQAgj6.append(title)
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,hWGMqtBy4wuLaVcj,523,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,title)
	return
def B5H81AYZELo(I4IpiuxdmFPbrsfTvtj):
	if VKiGj1LundAJQwEXcqgxC:
		I4IpiuxdmFPbrsfTvtj = I4IpiuxdmFPbrsfTvtj.decode(a7VXeDU82IfQEnPZAdiT)
		import arabic_reshaper as i4x98dXn6zr13KTBW,bidi.algorithm as YpaQHwrJP6qInXKZ7
		I4IpiuxdmFPbrsfTvtj = i4x98dXn6zr13KTBW.ArabicReshaper().reshape(I4IpiuxdmFPbrsfTvtj)
		I4IpiuxdmFPbrsfTvtj = YpaQHwrJP6qInXKZ7.get_display(I4IpiuxdmFPbrsfTvtj)
	import W02GkD1ey4
	I4IpiuxdmFPbrsfTvtj = TrzfUidpv1LyAYqwexHJDuS(HzcTkSV6qrsd9YnC0exa4hF=I4IpiuxdmFPbrsfTvtj)
	W02GkD1ey4.lPwaAjFTMG4n7iSLkXcEuK0Zm(I4IpiuxdmFPbrsfTvtj)
	return
def oCG4sjUr6kKl7qwyV(url):
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(DpQifS0oKBI1hYcO,'GET',url,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'ELCINEMA-INDEXES_LISTS-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	H5JvQIEuUxmV4GWFBY = EtTfaX0NeFMOQ.BeautifulSoup(mMQ3FkNVa4IlxqY,'html.parser',multi_valued_attributes=None)
	cok5ZGXdQP7YhwtqyuaCnVevm6UB = H5JvQIEuUxmV4GWFBY.find(class_='list-separator list-title')
	LHN1Zr7FDtbYfjz069Gnh = cok5ZGXdQP7YhwtqyuaCnVevm6UB.find_all('a')
	items = []
	for title in LHN1Zr7FDtbYfjz069Gnh:
		name = title.text
		llxFwq0CUNgQtivJzkHeGV = Str0BupDTFA+title.get('href')
		if VKiGj1LundAJQwEXcqgxC:
			name = name.encode(a7VXeDU82IfQEnPZAdiT)
			llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV.encode(a7VXeDU82IfQEnPZAdiT)
		if '#' not in llxFwq0CUNgQtivJzkHeGV: items.append((name,llxFwq0CUNgQtivJzkHeGV))
	items = sorted(items,reverse=False,key=lambda key: key[0])
	for ImYg2jxU6Lc9Q1C4Oko in items:
		name,llxFwq0CUNgQtivJzkHeGV = ImYg2jxU6Lc9Q1C4Oko
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+name,llxFwq0CUNgQtivJzkHeGV,518)
	return
def VBzP7iJTc6GYML4UX(url):
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(DpQifS0oKBI1hYcO,'GET',url,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'ELCINEMA-INDEXES_TITLES-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	H5JvQIEuUxmV4GWFBY = EtTfaX0NeFMOQ.BeautifulSoup(mMQ3FkNVa4IlxqY,'html.parser',multi_valued_attributes=None)
	rqIW37cd0iT1msDzRevOM = H5JvQIEuUxmV4GWFBY.find(class_='expand').find_all('tr')
	for cok5ZGXdQP7YhwtqyuaCnVevm6UB in rqIW37cd0iT1msDzRevOM:
		LCR19GQqvMflAomWc2we = cok5ZGXdQP7YhwtqyuaCnVevm6UB.find_all('a')
		if not LCR19GQqvMflAomWc2we: continue
		nWE8aO53lFfD = cok5ZGXdQP7YhwtqyuaCnVevm6UB.find('img').get('data-src')
		name = LCR19GQqvMflAomWc2we[1].text
		llxFwq0CUNgQtivJzkHeGV = Str0BupDTFA+LCR19GQqvMflAomWc2we[1].get('href')
		DXL7FS2Qrs0zKiN = cok5ZGXdQP7YhwtqyuaCnVevm6UB.find(class_='legend')
		if DXL7FS2Qrs0zKiN: DXL7FS2Qrs0zKiN = DXL7FS2Qrs0zKiN.text
		if VKiGj1LundAJQwEXcqgxC:
			name = name.encode(a7VXeDU82IfQEnPZAdiT)
			llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV.encode(a7VXeDU82IfQEnPZAdiT)
			nWE8aO53lFfD = nWE8aO53lFfD.encode(a7VXeDU82IfQEnPZAdiT)
		SX7OT3VLGp2iQm = {}
		if DXL7FS2Qrs0zKiN: SX7OT3VLGp2iQm['stars'] = DXL7FS2Qrs0zKiN
		if '/work/' in llxFwq0CUNgQtivJzkHeGV:
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+name,llxFwq0CUNgQtivJzkHeGV,516,nWE8aO53lFfD,hWGMqtBy4wuLaVcj,name,hWGMqtBy4wuLaVcj,SX7OT3VLGp2iQm)
		elif '/person/' in llxFwq0CUNgQtivJzkHeGV: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+name,llxFwq0CUNgQtivJzkHeGV,513,nWE8aO53lFfD,hWGMqtBy4wuLaVcj,name,hWGMqtBy4wuLaVcj,SX7OT3VLGp2iQm)
	XzIHbY0Q5OD(H5JvQIEuUxmV4GWFBY,518)
	return
def YdBfXbHQUPLScFzZJm(url):
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(DpQifS0oKBI1hYcO,'GET',url,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'ELCINEMA-VIDEOS_LISTS-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	H5JvQIEuUxmV4GWFBY = EtTfaX0NeFMOQ.BeautifulSoup(mMQ3FkNVa4IlxqY,'html.parser',multi_valued_attributes=None)
	LHN1Zr7FDtbYfjz069Gnh = H5JvQIEuUxmV4GWFBY.find_all(class_='section-title inline')
	m4IznKilUOByHweG68VJ = H5JvQIEuUxmV4GWFBY.find_all(class_='button green small right')
	items = zip(LHN1Zr7FDtbYfjz069Gnh,m4IznKilUOByHweG68VJ)
	for title,llxFwq0CUNgQtivJzkHeGV in items:
		title = title.text
		llxFwq0CUNgQtivJzkHeGV = Str0BupDTFA+llxFwq0CUNgQtivJzkHeGV.get('href')
		if VKiGj1LundAJQwEXcqgxC:
			title = title.encode(a7VXeDU82IfQEnPZAdiT)
			llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV.encode(a7VXeDU82IfQEnPZAdiT)
		title = title.replace(nIDXGaRHv7mOohe0Y8dLstECM,Mpsm2VF1OBnCRvK3qf6).replace(lG0yV5QNFHc2RbXM1Wp,Mpsm2VF1OBnCRvK3qf6).replace(FqcVAkh7WjIXHdDKf8nvuyRo,Mpsm2VF1OBnCRvK3qf6)
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,521)
	return
def GLBJlRIqo7g(url):
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(DpQifS0oKBI1hYcO,'GET',url,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'ELCINEMA-VIDEOS_TITLES-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	H5JvQIEuUxmV4GWFBY = EtTfaX0NeFMOQ.BeautifulSoup(mMQ3FkNVa4IlxqY,'html.parser',multi_valued_attributes=None)
	tvBkXJRSyeCinFHTl2 = H5JvQIEuUxmV4GWFBY.find(class_='large-block-grid-4 medium-block-grid-4 small-block-grid-2')
	rqIW37cd0iT1msDzRevOM = tvBkXJRSyeCinFHTl2.find_all('li')
	for cok5ZGXdQP7YhwtqyuaCnVevm6UB in rqIW37cd0iT1msDzRevOM:
		title = cok5ZGXdQP7YhwtqyuaCnVevm6UB.find(class_='title').text
		llxFwq0CUNgQtivJzkHeGV = Str0BupDTFA+cok5ZGXdQP7YhwtqyuaCnVevm6UB.find('a').get('href')
		nWE8aO53lFfD = cok5ZGXdQP7YhwtqyuaCnVevm6UB.find('img').get('data-src')
		oJV18NUZAzPGqMu7tenCxrkfhdl69B = cok5ZGXdQP7YhwtqyuaCnVevm6UB.find(class_='duration').text
		if VKiGj1LundAJQwEXcqgxC:
			title = title.encode(a7VXeDU82IfQEnPZAdiT)
			llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV.encode(a7VXeDU82IfQEnPZAdiT)
			nWE8aO53lFfD = nWE8aO53lFfD.encode(a7VXeDU82IfQEnPZAdiT)
			oJV18NUZAzPGqMu7tenCxrkfhdl69B = oJV18NUZAzPGqMu7tenCxrkfhdl69B.encode(a7VXeDU82IfQEnPZAdiT)
		oJV18NUZAzPGqMu7tenCxrkfhdl69B = oJV18NUZAzPGqMu7tenCxrkfhdl69B.replace(NXMOzZjYsmS9pf,hWGMqtBy4wuLaVcj).strip(Mpsm2VF1OBnCRvK3qf6)
		RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,522,nWE8aO53lFfD,oJV18NUZAzPGqMu7tenCxrkfhdl69B)
	XzIHbY0Q5OD(H5JvQIEuUxmV4GWFBY,521)
	return
def oanus6TxUFNAhSZKpJdYlEC4mV(url):
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(DpQifS0oKBI1hYcO,'GET',url,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'ELCINEMA-PLAY-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	H5JvQIEuUxmV4GWFBY = EtTfaX0NeFMOQ.BeautifulSoup(mMQ3FkNVa4IlxqY,'html.parser',multi_valued_attributes=None)
	llxFwq0CUNgQtivJzkHeGV = H5JvQIEuUxmV4GWFBY.find(class_='flex-video').find('iframe').get('src')
	if VKiGj1LundAJQwEXcqgxC: llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV.encode(a7VXeDU82IfQEnPZAdiT)
	import oosSOfvdEQ
	oosSOfvdEQ.zfdYjsGLg8M6i15qZWh([llxFwq0CUNgQtivJzkHeGV],xjPuFK3EsIZSiobQ5X,'video',url)
	return
def lPwaAjFTMG4n7iSLkXcEuK0Zm(search):
	search,vvKf4sXgZIMyEJPuC,showDialogs = IVTEJQOiMR2dYta9C(search)
	if search==hWGMqtBy4wuLaVcj: search = TrzfUidpv1LyAYqwexHJDuS()
	if search==hWGMqtBy4wuLaVcj: return
	search = search.replace(Mpsm2VF1OBnCRvK3qf6,'%20')
	url = Str0BupDTFA+'/search/?q='+search
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(DpQifS0oKBI1hYcO,'GET',url,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'ELCINEMA-SEARCH-1st')
	if not sDQvwGASB0Vf67mik.succeeded:
		IHYesWZQ9DKd = Str0BupDTFA+'/search_entity/?q='+search+'&entity=work'
		MDSF21x9HK3AZyGUhcb = Str0BupDTFA+'/search_entity/?q='+search+'&entity=person'
		V4K76PotgYjcyU981mkTXBvfSdAWp2 = Str0BupDTFA+'/search_entity/?q='+search+'&entity=video'
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'بحث عن أعمال',IHYesWZQ9DKd,513,hWGMqtBy4wuLaVcj,search)
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'بحث عن أشخاص',MDSF21x9HK3AZyGUhcb,513,hWGMqtBy4wuLaVcj,search)
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'بحث عن فيديوهات',V4K76PotgYjcyU981mkTXBvfSdAWp2,513,hWGMqtBy4wuLaVcj,search)
		return
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	H5JvQIEuUxmV4GWFBY = EtTfaX0NeFMOQ.BeautifulSoup(mMQ3FkNVa4IlxqY,'html.parser',multi_valued_attributes=None)
	rqIW37cd0iT1msDzRevOM = H5JvQIEuUxmV4GWFBY.find_all(class_='section-title left')
	for cok5ZGXdQP7YhwtqyuaCnVevm6UB in rqIW37cd0iT1msDzRevOM:
		title = cok5ZGXdQP7YhwtqyuaCnVevm6UB.text
		if VKiGj1LundAJQwEXcqgxC:
			title = title.encode(a7VXeDU82IfQEnPZAdiT)
		title = title.split('(',1)[0].strip(Mpsm2VF1OBnCRvK3qf6)
		if   'أعمال' in title: llxFwq0CUNgQtivJzkHeGV = url.replace('/search/','/search/work/')
		elif 'أشخاص' in title: llxFwq0CUNgQtivJzkHeGV = url.replace('/search/','/search/person/')
		elif 'فيديوهات' in title: llxFwq0CUNgQtivJzkHeGV = url.replace('/search/','/search/video/')
		else: continue
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,513)
	return
def ffXlHkWAc6PxVoEb(url,text):
	global uEwaiBFX1Hr5,MM02bgXexGhSpwQtlILydi1KJCOFz
	if '/seasonals' in url:
		uEwaiBFX1Hr5 = ['seasonal','year','category']
		MM02bgXexGhSpwQtlILydi1KJCOFz = ['seasonal','year','category']
	elif '/lineup' in url:
		uEwaiBFX1Hr5 = ['category','foreign','type']
		MM02bgXexGhSpwQtlILydi1KJCOFz = ['category','foreign','type']
	hadMgR0nOKHoGqpA(url,text)
	return
def n92Ia7FtBScTYHrGRhkP5zi(url):
	url = url.split('/smartemadfilter?')[0]
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(DpQifS0oKBI1hYcO,'GET',url,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'ELCINEMA-GET_FILTERS_BLOCKS-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('form action="/(.*?)</form>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
	f5rVHP4bmCd7cqvuYEQJlnLTk6yGRS = trdVA0JvFaD.findall('<select name="(.*?)" id="(.*?)".*?>(.*?)</div>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	return f5rVHP4bmCd7cqvuYEQJlnLTk6yGRS
def mPVz8jRSf0iHd2FNTswv4O1gy(cok5ZGXdQP7YhwtqyuaCnVevm6UB):
	items = trdVA0JvFaD.findall('<option value="(.*?)">(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	return items
def pMv1ZGJ0iQE(url):
	QQUSNlXZ6MEoH1uftykesbKq2 = url.split('/smartemadfilter?')[0]
	cbtS4iE32pOBe5rUxdfIjlXhokKMR = RRNODILCtGzvgpx(url,'url')
	url = url.replace('/smartemadfilter?','/?utf8=%E2%9C%93&')
	return url
def T5uabshHFCkvGP6N8nx7S4Q(tuYnONZ6GaCecv4TErUHMdBX2DIb8K,url):
	PPlq1nxLf6CamuBI0psW = kKWuMB69mcOHPn3XilFdvp(tuYnONZ6GaCecv4TErUHMdBX2DIb8K,'all_filters')
	CMzQFXeI08KDwAJ9p = url+'/smartemadfilter?'+PPlq1nxLf6CamuBI0psW
	CMzQFXeI08KDwAJ9p = pMv1ZGJ0iQE(CMzQFXeI08KDwAJ9p)
	return CMzQFXeI08KDwAJ9p
def hadMgR0nOKHoGqpA(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==hWGMqtBy4wuLaVcj: RJGtCsyDgi0X,kYI6n5bUD83Z = hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj
	else: RJGtCsyDgi0X,kYI6n5bUD83Z = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if uEwaiBFX1Hr5[0]+'=' not in RJGtCsyDgi0X: OJx4sYA9nNbtPT5ezmDHdVBk2C7 = uEwaiBFX1Hr5[0]
		for PPuqrvDLEViYOMf1dmkK7 in range(len(uEwaiBFX1Hr5[0:-1])):
			if uEwaiBFX1Hr5[PPuqrvDLEViYOMf1dmkK7]+'=' in RJGtCsyDgi0X: OJx4sYA9nNbtPT5ezmDHdVBk2C7 = uEwaiBFX1Hr5[PPuqrvDLEViYOMf1dmkK7+1]
		nnqvmxlXub3iVDM = RJGtCsyDgi0X+'&'+OJx4sYA9nNbtPT5ezmDHdVBk2C7+'=0'
		tuYnONZ6GaCecv4TErUHMdBX2DIb8K = kYI6n5bUD83Z+'&'+OJx4sYA9nNbtPT5ezmDHdVBk2C7+'=0'
		BvO3oKUrHNCwVm791b80sZg = nnqvmxlXub3iVDM.strip('&')+'___'+tuYnONZ6GaCecv4TErUHMdBX2DIb8K.strip('&')
		PPlq1nxLf6CamuBI0psW = kKWuMB69mcOHPn3XilFdvp(kYI6n5bUD83Z,'modified_filters')
		NPM3HKQ57xe = url+'/smartemadfilter?'+PPlq1nxLf6CamuBI0psW
	elif type=='ALL_ITEMS_FILTER':
		I2OnWkrPaVbwBSHiYR3LZ = kKWuMB69mcOHPn3XilFdvp(RJGtCsyDgi0X,'modified_values')
		I2OnWkrPaVbwBSHiYR3LZ = jkiCS0UWs2dNAJcGKn6mbHD(I2OnWkrPaVbwBSHiYR3LZ)
		if kYI6n5bUD83Z!=hWGMqtBy4wuLaVcj: kYI6n5bUD83Z = kKWuMB69mcOHPn3XilFdvp(kYI6n5bUD83Z,'modified_filters')
		if kYI6n5bUD83Z==hWGMqtBy4wuLaVcj: NPM3HKQ57xe = url
		else: NPM3HKQ57xe = url+'/smartemadfilter?'+kYI6n5bUD83Z
		NPM3HKQ57xe = pMv1ZGJ0iQE(NPM3HKQ57xe)
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'أظهار قائمة الفيديو التي تم اختيارها ',NPM3HKQ57xe,511)
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+' [[   '+I2OnWkrPaVbwBSHiYR3LZ+'   ]]',NPM3HKQ57xe,511)
		RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	f5rVHP4bmCd7cqvuYEQJlnLTk6yGRS = n92Ia7FtBScTYHrGRhkP5zi(url)
	dict = {}
	for name,bksErtC1hwcVqlfyM82AnD,cok5ZGXdQP7YhwtqyuaCnVevm6UB in f5rVHP4bmCd7cqvuYEQJlnLTk6yGRS:
		name = name.replace('--',hWGMqtBy4wuLaVcj)
		items = mPVz8jRSf0iHd2FNTswv4O1gy(cok5ZGXdQP7YhwtqyuaCnVevm6UB)
		if '=' not in NPM3HKQ57xe: NPM3HKQ57xe = url
		if type=='SPECIFIED_FILTER':
			if bksErtC1hwcVqlfyM82AnD not in uEwaiBFX1Hr5: continue
			if OJx4sYA9nNbtPT5ezmDHdVBk2C7!=bksErtC1hwcVqlfyM82AnD: continue
			elif len(items)<2:
				if bksErtC1hwcVqlfyM82AnD==uEwaiBFX1Hr5[-1]:
					url = pMv1ZGJ0iQE(url)
					XSCYc8Wwgv7I5rniMyDoRGK1Azbfd(url)
				else: hadMgR0nOKHoGqpA(NPM3HKQ57xe,'SPECIFIED_FILTER___'+BvO3oKUrHNCwVm791b80sZg)
				return
			else:
				NPM3HKQ57xe = pMv1ZGJ0iQE(NPM3HKQ57xe)
				if bksErtC1hwcVqlfyM82AnD==uEwaiBFX1Hr5[-1]: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'الجميع',NPM3HKQ57xe,511)
				else: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'الجميع',NPM3HKQ57xe,515,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,BvO3oKUrHNCwVm791b80sZg)
		elif type=='ALL_ITEMS_FILTER':
			if bksErtC1hwcVqlfyM82AnD not in MM02bgXexGhSpwQtlILydi1KJCOFz: continue
			nnqvmxlXub3iVDM = RJGtCsyDgi0X+'&'+bksErtC1hwcVqlfyM82AnD+'=0'
			tuYnONZ6GaCecv4TErUHMdBX2DIb8K = kYI6n5bUD83Z+'&'+bksErtC1hwcVqlfyM82AnD+'=0'
			BvO3oKUrHNCwVm791b80sZg = nnqvmxlXub3iVDM+'___'+tuYnONZ6GaCecv4TErUHMdBX2DIb8K
			if   name=='type': name = 'النوع'
			elif name=='category': name = 'العمل'
			elif name=='foreign': name = 'اللغة'
			elif name=='year': name = 'السنة'
			elif name=='seasonal': name = 'الموسم'
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'الجميع: '+name,NPM3HKQ57xe,514,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,BvO3oKUrHNCwVm791b80sZg)
		dict[bksErtC1hwcVqlfyM82AnD] = {}
		for BoSjXKxz41DcneO9UimClE,PBo1KkyMCgH8eNDaLtZVcr3EnIi2 in items:
			if PBo1KkyMCgH8eNDaLtZVcr3EnIi2 in P3UK1Rr4IdYe5: continue
			if 'مصنفات أخرى' in PBo1KkyMCgH8eNDaLtZVcr3EnIi2: continue
			if 'الكل' in PBo1KkyMCgH8eNDaLtZVcr3EnIi2: continue
			if 'اللغة' in PBo1KkyMCgH8eNDaLtZVcr3EnIi2: continue
			PBo1KkyMCgH8eNDaLtZVcr3EnIi2 = PBo1KkyMCgH8eNDaLtZVcr3EnIi2.replace('قائمة ',hWGMqtBy4wuLaVcj)
			if   name=='type': name = 'النوع'
			elif name=='category': name = 'العمل'
			elif name=='foreign': name = 'اللغة'
			elif name=='year': name = 'السنة'
			elif name=='seasonal': name = 'الموسم'
			dict[bksErtC1hwcVqlfyM82AnD][BoSjXKxz41DcneO9UimClE] = PBo1KkyMCgH8eNDaLtZVcr3EnIi2
			nnqvmxlXub3iVDM = RJGtCsyDgi0X+'&'+bksErtC1hwcVqlfyM82AnD+'='+PBo1KkyMCgH8eNDaLtZVcr3EnIi2
			tuYnONZ6GaCecv4TErUHMdBX2DIb8K = kYI6n5bUD83Z+'&'+bksErtC1hwcVqlfyM82AnD+'='+BoSjXKxz41DcneO9UimClE
			S80DwNWuMTZx4El = nnqvmxlXub3iVDM+'___'+tuYnONZ6GaCecv4TErUHMdBX2DIb8K
			if name: title = PBo1KkyMCgH8eNDaLtZVcr3EnIi2+' :'+name
			else: title = PBo1KkyMCgH8eNDaLtZVcr3EnIi2
			if type=='ALL_ITEMS_FILTER': RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,url,514,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,S80DwNWuMTZx4El)
			elif type=='SPECIFIED_FILTER' and uEwaiBFX1Hr5[-2]+'=' in RJGtCsyDgi0X:
				CMzQFXeI08KDwAJ9p = T5uabshHFCkvGP6N8nx7S4Q(tuYnONZ6GaCecv4TErUHMdBX2DIb8K,url)
				RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,CMzQFXeI08KDwAJ9p,511)
			else: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,url,515,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,S80DwNWuMTZx4El)
	return
def kKWuMB69mcOHPn3XilFdvp(UGewLrVFhBCo7MdZ8KEaJWXgYp,mode):
	UGewLrVFhBCo7MdZ8KEaJWXgYp = UGewLrVFhBCo7MdZ8KEaJWXgYp.replace('=&','=0&')
	UGewLrVFhBCo7MdZ8KEaJWXgYp = UGewLrVFhBCo7MdZ8KEaJWXgYp.strip('&')
	ONVGLC8DSp4 = {}
	if '=' in UGewLrVFhBCo7MdZ8KEaJWXgYp:
		items = UGewLrVFhBCo7MdZ8KEaJWXgYp.split('&')
		for ImYg2jxU6Lc9Q1C4Oko in items:
			glBvuIRTJseUHjari,BoSjXKxz41DcneO9UimClE = ImYg2jxU6Lc9Q1C4Oko.split('=')
			ONVGLC8DSp4[glBvuIRTJseUHjari] = BoSjXKxz41DcneO9UimClE
	mJuhvt0RPAbBMSla = hWGMqtBy4wuLaVcj
	for key in MM02bgXexGhSpwQtlILydi1KJCOFz:
		if key in list(ONVGLC8DSp4.keys()): BoSjXKxz41DcneO9UimClE = ONVGLC8DSp4[key]
		else: BoSjXKxz41DcneO9UimClE = '0'
		if '%' not in BoSjXKxz41DcneO9UimClE: BoSjXKxz41DcneO9UimClE = e1mT8H4dGS3XFyx0KLUA9(BoSjXKxz41DcneO9UimClE)
		if mode=='modified_values' and BoSjXKxz41DcneO9UimClE!='0': mJuhvt0RPAbBMSla = mJuhvt0RPAbBMSla+' + '+BoSjXKxz41DcneO9UimClE
		elif mode=='modified_filters' and BoSjXKxz41DcneO9UimClE!='0': mJuhvt0RPAbBMSla = mJuhvt0RPAbBMSla+'&'+key+'='+BoSjXKxz41DcneO9UimClE
		elif mode=='all_filters': mJuhvt0RPAbBMSla = mJuhvt0RPAbBMSla+'&'+key+'='+BoSjXKxz41DcneO9UimClE
	mJuhvt0RPAbBMSla = mJuhvt0RPAbBMSla.strip(' + ')
	mJuhvt0RPAbBMSla = mJuhvt0RPAbBMSla.strip('&')
	mJuhvt0RPAbBMSla = mJuhvt0RPAbBMSla.replace('=0','=')
	return mJuhvt0RPAbBMSla
uEwaiBFX1Hr5 = []
MM02bgXexGhSpwQtlILydi1KJCOFz = []
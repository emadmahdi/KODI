# -*- coding: utf-8 -*-
from yoY3NdGViS import *
bBER0HlPYh4ZXm6ILWw = 'EXCLUDES'
def rvLV1dfYARiZQ32(j4lHpxXvnF2VtwBb1T9PaJEm3,JbNKPl6kAxRFy07jXqt):
	JbNKPl6kAxRFy07jXqt = JbNKPl6kAxRFy07jXqt.replace(hXB0vKVQ5PRI91SDTprMdfuHEm4,hWGMqtBy4wuLaVcj).replace(' '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj)[1:]
	ILmv0SCt132 = trdVA0JvFaD.findall('[a-zA-Z]',j4lHpxXvnF2VtwBb1T9PaJEm3,trdVA0JvFaD.DOTALL)
	if 'بحث IPTV - ' in j4lHpxXvnF2VtwBb1T9PaJEm3: j4lHpxXvnF2VtwBb1T9PaJEm3 = j4lHpxXvnF2VtwBb1T9PaJEm3.replace('بحث IPTV - ',cc6SBsG2vlpjPd8yERNW1AJDZM+'بحث IPTV - '+cc6SBsG2vlpjPd8yERNW1AJDZM)
	elif ' IPTV' in j4lHpxXvnF2VtwBb1T9PaJEm3 and JbNKPl6kAxRFy07jXqt=='IPT': j4lHpxXvnF2VtwBb1T9PaJEm3 = cc6SBsG2vlpjPd8yERNW1AJDZM+j4lHpxXvnF2VtwBb1T9PaJEm3
	elif 'بحث M3U - ' in j4lHpxXvnF2VtwBb1T9PaJEm3: j4lHpxXvnF2VtwBb1T9PaJEm3 = j4lHpxXvnF2VtwBb1T9PaJEm3.replace('بحث M3U - ',cc6SBsG2vlpjPd8yERNW1AJDZM+'بحث M3U - '+cc6SBsG2vlpjPd8yERNW1AJDZM)
	elif ' M3U' in j4lHpxXvnF2VtwBb1T9PaJEm3 and JbNKPl6kAxRFy07jXqt=='M3U': j4lHpxXvnF2VtwBb1T9PaJEm3 = cc6SBsG2vlpjPd8yERNW1AJDZM+j4lHpxXvnF2VtwBb1T9PaJEm3
	elif 'بحث ' in j4lHpxXvnF2VtwBb1T9PaJEm3 and ' - ' in j4lHpxXvnF2VtwBb1T9PaJEm3: j4lHpxXvnF2VtwBb1T9PaJEm3 = cc6SBsG2vlpjPd8yERNW1AJDZM+j4lHpxXvnF2VtwBb1T9PaJEm3
	elif not ILmv0SCt132:
		dh2yXqKucMTW6Ak5iZSrw = trdVA0JvFaD.findall('^( *?)(.*?)( *?)$',j4lHpxXvnF2VtwBb1T9PaJEm3)
		WwHUZrtRE6iYeGNvdL,GQAHCg58BeSLVFTu4z6npa,zG5uYvH1Rfbyn0qkNaiFCrj = dh2yXqKucMTW6Ak5iZSrw[0]
		pp2LXB0suDgGtxzKfAC4EUZ = trdVA0JvFaD.findall('^([!-~])',GQAHCg58BeSLVFTu4z6npa)
		if pp2LXB0suDgGtxzKfAC4EUZ: j4lHpxXvnF2VtwBb1T9PaJEm3 = WwHUZrtRE6iYeGNvdL+w4GYEC6fmU2g7H+GQAHCg58BeSLVFTu4z6npa+zG5uYvH1Rfbyn0qkNaiFCrj
		else: j4lHpxXvnF2VtwBb1T9PaJEm3 = zG5uYvH1Rfbyn0qkNaiFCrj+cc6SBsG2vlpjPd8yERNW1AJDZM+GQAHCg58BeSLVFTu4z6npa+WwHUZrtRE6iYeGNvdL
	else:
		import bidi.algorithm as YpaQHwrJP6qInXKZ7
		if 1:
			xChePq76DGbndOtwVUaIi40vM = j4lHpxXvnF2VtwBb1T9PaJEm3
			Z4d7xuvUFXIi2fMnPh5EY = YpaQHwrJP6qInXKZ7.get_display(j4lHpxXvnF2VtwBb1T9PaJEm3,base_dir='L')
			if VKiGj1LundAJQwEXcqgxC: xChePq76DGbndOtwVUaIi40vM = xChePq76DGbndOtwVUaIi40vM.decode(a7VXeDU82IfQEnPZAdiT)
			if VKiGj1LundAJQwEXcqgxC: Z4d7xuvUFXIi2fMnPh5EY = Z4d7xuvUFXIi2fMnPh5EY.decode(a7VXeDU82IfQEnPZAdiT)
			RrX5t7m4VKxTPM = xChePq76DGbndOtwVUaIi40vM.split(Mpsm2VF1OBnCRvK3qf6)
			nAOSFDuJeoWfUXrjQ6bw9TCs = Z4d7xuvUFXIi2fMnPh5EY.split(Mpsm2VF1OBnCRvK3qf6)
			hFiuCNEo0DIjac8KkAsblRtMeq,zswpL3OM5n0F1,FrpQTnJMH1VDZU9h3y6,vtmAai9r0qkVwxSTDfdRGbOoslh = [],[],hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj
			zzs9StuDB5UekhrwOJ = zip(RrX5t7m4VKxTPM,nAOSFDuJeoWfUXrjQ6bw9TCs)
			for bjJtBn6LRWT3kfwv,OZ9Cip7FThyBkGINv6srScalMfJXH in zzs9StuDB5UekhrwOJ:
				if bjJtBn6LRWT3kfwv==OZ9Cip7FThyBkGINv6srScalMfJXH==hWGMqtBy4wuLaVcj and vtmAai9r0qkVwxSTDfdRGbOoslh:
					FrpQTnJMH1VDZU9h3y6 += Mpsm2VF1OBnCRvK3qf6
					continue
				if bjJtBn6LRWT3kfwv==OZ9Cip7FThyBkGINv6srScalMfJXH:
					LjwCGdhZctkqmpo0ve = 'EN'
					if vtmAai9r0qkVwxSTDfdRGbOoslh==LjwCGdhZctkqmpo0ve: FrpQTnJMH1VDZU9h3y6 += Mpsm2VF1OBnCRvK3qf6+bjJtBn6LRWT3kfwv
					elif bjJtBn6LRWT3kfwv:
						if FrpQTnJMH1VDZU9h3y6:
							zswpL3OM5n0F1.append(FrpQTnJMH1VDZU9h3y6)
							hFiuCNEo0DIjac8KkAsblRtMeq.append(hWGMqtBy4wuLaVcj)
						FrpQTnJMH1VDZU9h3y6 = bjJtBn6LRWT3kfwv
				else:
					LjwCGdhZctkqmpo0ve = 'AR'
					if vtmAai9r0qkVwxSTDfdRGbOoslh==LjwCGdhZctkqmpo0ve: FrpQTnJMH1VDZU9h3y6 += Mpsm2VF1OBnCRvK3qf6+bjJtBn6LRWT3kfwv
					elif bjJtBn6LRWT3kfwv:
						if FrpQTnJMH1VDZU9h3y6:
							hFiuCNEo0DIjac8KkAsblRtMeq.append(FrpQTnJMH1VDZU9h3y6)
							zswpL3OM5n0F1.append(hWGMqtBy4wuLaVcj)
						FrpQTnJMH1VDZU9h3y6 = bjJtBn6LRWT3kfwv
				vtmAai9r0qkVwxSTDfdRGbOoslh = LjwCGdhZctkqmpo0ve
			if LjwCGdhZctkqmpo0ve=='EN':
				hFiuCNEo0DIjac8KkAsblRtMeq.append(FrpQTnJMH1VDZU9h3y6)
				zswpL3OM5n0F1.append(hWGMqtBy4wuLaVcj)
			else:
				zswpL3OM5n0F1.append(FrpQTnJMH1VDZU9h3y6)
				hFiuCNEo0DIjac8KkAsblRtMeq.append(hWGMqtBy4wuLaVcj)
			RZNb9V32cpLvwOzQ = hWGMqtBy4wuLaVcj
			zzs9StuDB5UekhrwOJ = zip(hFiuCNEo0DIjac8KkAsblRtMeq,zswpL3OM5n0F1)
			import bidi.mirror as sKhROMIotj8aP
			for iKxfZlenh3CJ8ky4pY5WuM0omcVQrG,qosAQ4bvlx6mBDGRPzg in zzs9StuDB5UekhrwOJ:
				if iKxfZlenh3CJ8ky4pY5WuM0omcVQrG: RZNb9V32cpLvwOzQ += Mpsm2VF1OBnCRvK3qf6+iKxfZlenh3CJ8ky4pY5WuM0omcVQrG
				else:
					pp2LXB0suDgGtxzKfAC4EUZ = trdVA0JvFaD.findall('([!-~]) *$',qosAQ4bvlx6mBDGRPzg)
					if pp2LXB0suDgGtxzKfAC4EUZ:
						pp2LXB0suDgGtxzKfAC4EUZ = pp2LXB0suDgGtxzKfAC4EUZ[0]
						try:
							wOXQ7F8tiLYb9PedEz = sKhROMIotj8aP.MIRRORED[pp2LXB0suDgGtxzKfAC4EUZ]
							dh2yXqKucMTW6Ak5iZSrw = trdVA0JvFaD.findall('^( *?)(.*?)( *?)$',qosAQ4bvlx6mBDGRPzg)
							if dh2yXqKucMTW6Ak5iZSrw: WwHUZrtRE6iYeGNvdL,qosAQ4bvlx6mBDGRPzg,zG5uYvH1Rfbyn0qkNaiFCrj = dh2yXqKucMTW6Ak5iZSrw[0]
							qosAQ4bvlx6mBDGRPzg = WwHUZrtRE6iYeGNvdL+wOXQ7F8tiLYb9PedEz+qosAQ4bvlx6mBDGRPzg[:-1]+zG5uYvH1Rfbyn0qkNaiFCrj
						except: pass
					RZNb9V32cpLvwOzQ += Mpsm2VF1OBnCRvK3qf6+qosAQ4bvlx6mBDGRPzg
			j4lHpxXvnF2VtwBb1T9PaJEm3 = RZNb9V32cpLvwOzQ[1:]
			if VKiGj1LundAJQwEXcqgxC: j4lHpxXvnF2VtwBb1T9PaJEm3 = j4lHpxXvnF2VtwBb1T9PaJEm3.encode(a7VXeDU82IfQEnPZAdiT)
		else:
			if VKiGj1LundAJQwEXcqgxC: j4lHpxXvnF2VtwBb1T9PaJEm3 = j4lHpxXvnF2VtwBb1T9PaJEm3.decode(a7VXeDU82IfQEnPZAdiT)
			j4lHpxXvnF2VtwBb1T9PaJEm3 = YpaQHwrJP6qInXKZ7.get_display(j4lHpxXvnF2VtwBb1T9PaJEm3)
			xChePq76DGbndOtwVUaIi40vM,Z4d7xuvUFXIi2fMnPh5EY = j4lHpxXvnF2VtwBb1T9PaJEm3,j4lHpxXvnF2VtwBb1T9PaJEm3
			if 1:
				vtmAai9r0qkVwxSTDfdRGbOoslh,mmETCtG0RIjMpvlAcQJB = hWGMqtBy4wuLaVcj,[]
				bbkMFPQeKWY8UvGE = j4lHpxXvnF2VtwBb1T9PaJEm3.split(Mpsm2VF1OBnCRvK3qf6)
				for A1fkJODo2FwLPG in bbkMFPQeKWY8UvGE:
					if not A1fkJODo2FwLPG:
						if mmETCtG0RIjMpvlAcQJB: mmETCtG0RIjMpvlAcQJB[-1] += Mpsm2VF1OBnCRvK3qf6
						else: mmETCtG0RIjMpvlAcQJB.append(hWGMqtBy4wuLaVcj)
						continue
					tHp7N4GmQ3U = trdVA0JvFaD.findall('[!-~]',A1fkJODo2FwLPG[0])
					if tHp7N4GmQ3U==vtmAai9r0qkVwxSTDfdRGbOoslh and mmETCtG0RIjMpvlAcQJB: mmETCtG0RIjMpvlAcQJB[-1] += Mpsm2VF1OBnCRvK3qf6+A1fkJODo2FwLPG
					else:
						if mmETCtG0RIjMpvlAcQJB:
							G7LxDptNqrXCev98Tz1cPJHFE5M = trdVA0JvFaD.findall('[^!-~]',mmETCtG0RIjMpvlAcQJB[-1])
							if G7LxDptNqrXCev98Tz1cPJHFE5M:
								mmETCtG0RIjMpvlAcQJB[-1] = YpaQHwrJP6qInXKZ7.get_display(mmETCtG0RIjMpvlAcQJB[-1])
								QoER0OmeaKu8SyIBx = trdVA0JvFaD.findall('^ +',mmETCtG0RIjMpvlAcQJB[-1])
								if QoER0OmeaKu8SyIBx: mmETCtG0RIjMpvlAcQJB[-1] = mmETCtG0RIjMpvlAcQJB[-1].lstrip(Mpsm2VF1OBnCRvK3qf6)+QoER0OmeaKu8SyIBx[0]
						mmETCtG0RIjMpvlAcQJB.append(A1fkJODo2FwLPG)
					vtmAai9r0qkVwxSTDfdRGbOoslh = tHp7N4GmQ3U
				if mmETCtG0RIjMpvlAcQJB: mmETCtG0RIjMpvlAcQJB[-1] = YpaQHwrJP6qInXKZ7.get_display(mmETCtG0RIjMpvlAcQJB[-1])
				j4lHpxXvnF2VtwBb1T9PaJEm3 = Mpsm2VF1OBnCRvK3qf6.join(mmETCtG0RIjMpvlAcQJB)
			if VKiGj1LundAJQwEXcqgxC: j4lHpxXvnF2VtwBb1T9PaJEm3 = j4lHpxXvnF2VtwBb1T9PaJEm3.encode(a7VXeDU82IfQEnPZAdiT)
	return j4lHpxXvnF2VtwBb1T9PaJEm3
def ddx6ayPYD9cKSvq45Zh0LkIHBUEp(aQNvODnTB3mjP76kR,NOU4G09nYWeEMX71hmHqF,xjgwHolCi4EaB8pzW25KFr7):
	udRvjXt9cAfha5ZsBP3U,j4lHpxXvnF2VtwBb1T9PaJEm3,O9z5L3KtXqPEMepJQ0,JbpxsyQVXmSEYKM3vo847Ckh,acysH2W9N0BhXIvJPRM5t,f0p6eoXk4ajsNldbEMi,eePWR0CjMViGH5hTLc9gskSO3r,kCaIufXo1F0TyL7gtcJV5bneijMWHv,kFeSKZb8qiVd4GxwcAMHQolgU = aQNvODnTB3mjP76kR
	JbpxsyQVXmSEYKM3vo847Ckh = int(JbpxsyQVXmSEYKM3vo847Ckh)
	NNCqlXYrvGZhgD6QKajm1HUMc = trdVA0JvFaD.findall('(_(\d\d\.\d\d)_(\d\d\:\d\d)_)',j4lHpxXvnF2VtwBb1T9PaJEm3,trdVA0JvFaD.DOTALL)
	if NNCqlXYrvGZhgD6QKajm1HUMc:
		NNCqlXYrvGZhgD6QKajm1HUMc,GLMvPnpycjEdkzI,Nbyuo1ZOHJ = NNCqlXYrvGZhgD6QKajm1HUMc[0]
		j4lHpxXvnF2VtwBb1T9PaJEm3 = j4lHpxXvnF2VtwBb1T9PaJEm3.replace(NNCqlXYrvGZhgD6QKajm1HUMc,hWGMqtBy4wuLaVcj)
	NN6CytXdHmk = j4lHpxXvnF2VtwBb1T9PaJEm3
	JbNKPl6kAxRFy07jXqt = trdVA0JvFaD.findall('^_(\w\w\w)_(.*?)$',j4lHpxXvnF2VtwBb1T9PaJEm3,trdVA0JvFaD.DOTALL)
	if JbNKPl6kAxRFy07jXqt:
		JbNKPl6kAxRFy07jXqt,j4lHpxXvnF2VtwBb1T9PaJEm3 = JbNKPl6kAxRFy07jXqt[0]
		ujQ4kq816aDYx = '_MOD_' in j4lHpxXvnF2VtwBb1T9PaJEm3
		ZZNvmiGjlpwIOx = udRvjXt9cAfha5ZsBP3U=='folder'
		if ujQ4kq816aDYx and ZZNvmiGjlpwIOx: IiZHcxgF0wWrVUKSukdzDAnb = ';'
		elif ujQ4kq816aDYx and not ZZNvmiGjlpwIOx: IiZHcxgF0wWrVUKSukdzDAnb = FiSv0uqKNEbQx3dXlWZhPV8
		elif not ujQ4kq816aDYx and ZZNvmiGjlpwIOx: IiZHcxgF0wWrVUKSukdzDAnb = ','
		elif not ujQ4kq816aDYx and not ZZNvmiGjlpwIOx: IiZHcxgF0wWrVUKSukdzDAnb = Mpsm2VF1OBnCRvK3qf6
		j4lHpxXvnF2VtwBb1T9PaJEm3 = j4lHpxXvnF2VtwBb1T9PaJEm3.replace('_MOD_',hWGMqtBy4wuLaVcj)
		JbNKPl6kAxRFy07jXqt = IiZHcxgF0wWrVUKSukdzDAnb+hXB0vKVQ5PRI91SDTprMdfuHEm4+JbNKPl6kAxRFy07jXqt+' '+YYSh2J6BIrsm8
	else: JbNKPl6kAxRFy07jXqt = hWGMqtBy4wuLaVcj
	if NNCqlXYrvGZhgD6QKajm1HUMc:
		if VKiGj1LundAJQwEXcqgxC:
			NNCqlXYrvGZhgD6QKajm1HUMc = soMVfbr6WtpNlcSA+GLMvPnpycjEdkzI+Mpsm2VF1OBnCRvK3qf6+Nbyuo1ZOHJ+YYSh2J6BIrsm8
			if JbNKPl6kAxRFy07jXqt: j4lHpxXvnF2VtwBb1T9PaJEm3 = NNCqlXYrvGZhgD6QKajm1HUMc+Mpsm2VF1OBnCRvK3qf6+cc6SBsG2vlpjPd8yERNW1AJDZM+JbNKPl6kAxRFy07jXqt+j4lHpxXvnF2VtwBb1T9PaJEm3
			else: j4lHpxXvnF2VtwBb1T9PaJEm3 = NNCqlXYrvGZhgD6QKajm1HUMc+cc6SBsG2vlpjPd8yERNW1AJDZM+j4lHpxXvnF2VtwBb1T9PaJEm3+Mpsm2VF1OBnCRvK3qf6
		elif H4qZ2hwilNJYTmCFEQyaSs98cPM0gR:
			if JbNKPl6kAxRFy07jXqt:
				NNCqlXYrvGZhgD6QKajm1HUMc = soMVfbr6WtpNlcSA+GLMvPnpycjEdkzI+Mpsm2VF1OBnCRvK3qf6+Nbyuo1ZOHJ+YYSh2J6BIrsm8
				j4lHpxXvnF2VtwBb1T9PaJEm3 = NNCqlXYrvGZhgD6QKajm1HUMc+Mpsm2VF1OBnCRvK3qf6+JbNKPl6kAxRFy07jXqt+j4lHpxXvnF2VtwBb1T9PaJEm3
			else:
				NNCqlXYrvGZhgD6QKajm1HUMc = soMVfbr6WtpNlcSA+Nbyuo1ZOHJ+Mpsm2VF1OBnCRvK3qf6+GLMvPnpycjEdkzI+YYSh2J6BIrsm8
				j4lHpxXvnF2VtwBb1T9PaJEm3 = j4lHpxXvnF2VtwBb1T9PaJEm3+Mpsm2VF1OBnCRvK3qf6+cc6SBsG2vlpjPd8yERNW1AJDZM+NNCqlXYrvGZhgD6QKajm1HUMc
	elif JbNKPl6kAxRFy07jXqt:
		j4lHpxXvnF2VtwBb1T9PaJEm3 = rvLV1dfYARiZQ32(j4lHpxXvnF2VtwBb1T9PaJEm3,JbNKPl6kAxRFy07jXqt)
		j4lHpxXvnF2VtwBb1T9PaJEm3 = JbNKPl6kAxRFy07jXqt+j4lHpxXvnF2VtwBb1T9PaJEm3
	aQNvODnTB3mjP76kR = udRvjXt9cAfha5ZsBP3U,NN6CytXdHmk,O9z5L3KtXqPEMepJQ0,str(JbpxsyQVXmSEYKM3vo847Ckh),acysH2W9N0BhXIvJPRM5t,f0p6eoXk4ajsNldbEMi,eePWR0CjMViGH5hTLc9gskSO3r,kCaIufXo1F0TyL7gtcJV5bneijMWHv,kFeSKZb8qiVd4GxwcAMHQolgU
	hhDrLuf5l4ngM9wpvPUFX0SYIT = {'type':hWGMqtBy4wuLaVcj,'mode':hWGMqtBy4wuLaVcj,'url':hWGMqtBy4wuLaVcj,'text':hWGMqtBy4wuLaVcj,'page':hWGMqtBy4wuLaVcj,'name':hWGMqtBy4wuLaVcj,'image':hWGMqtBy4wuLaVcj,'context':hWGMqtBy4wuLaVcj,'infodict':hWGMqtBy4wuLaVcj}
	hhDrLuf5l4ngM9wpvPUFX0SYIT['name'] = e1mT8H4dGS3XFyx0KLUA9(NN6CytXdHmk)
	hhDrLuf5l4ngM9wpvPUFX0SYIT['type'] = udRvjXt9cAfha5ZsBP3U.strip(Mpsm2VF1OBnCRvK3qf6)
	hhDrLuf5l4ngM9wpvPUFX0SYIT['mode'] = str(JbpxsyQVXmSEYKM3vo847Ckh).strip(Mpsm2VF1OBnCRvK3qf6)
	if udRvjXt9cAfha5ZsBP3U=='folder' and f0p6eoXk4ajsNldbEMi: hhDrLuf5l4ngM9wpvPUFX0SYIT['page'] = e1mT8H4dGS3XFyx0KLUA9(f0p6eoXk4ajsNldbEMi.strip(Mpsm2VF1OBnCRvK3qf6))
	if kCaIufXo1F0TyL7gtcJV5bneijMWHv: hhDrLuf5l4ngM9wpvPUFX0SYIT['context'] = kCaIufXo1F0TyL7gtcJV5bneijMWHv.strip(Mpsm2VF1OBnCRvK3qf6)
	if eePWR0CjMViGH5hTLc9gskSO3r: hhDrLuf5l4ngM9wpvPUFX0SYIT['text'] = e1mT8H4dGS3XFyx0KLUA9(eePWR0CjMViGH5hTLc9gskSO3r.strip(Mpsm2VF1OBnCRvK3qf6))
	if acysH2W9N0BhXIvJPRM5t: hhDrLuf5l4ngM9wpvPUFX0SYIT['image'] = e1mT8H4dGS3XFyx0KLUA9(acysH2W9N0BhXIvJPRM5t.strip(Mpsm2VF1OBnCRvK3qf6))
	if kFeSKZb8qiVd4GxwcAMHQolgU:
		kFeSKZb8qiVd4GxwcAMHQolgU = str(kFeSKZb8qiVd4GxwcAMHQolgU)
		hhDrLuf5l4ngM9wpvPUFX0SYIT['infodict'] = e1mT8H4dGS3XFyx0KLUA9(kFeSKZb8qiVd4GxwcAMHQolgU.strip(Mpsm2VF1OBnCRvK3qf6))
		kFeSKZb8qiVd4GxwcAMHQolgU = eval(kFeSKZb8qiVd4GxwcAMHQolgU)
	else: kFeSKZb8qiVd4GxwcAMHQolgU = {}
	if O9z5L3KtXqPEMepJQ0: hhDrLuf5l4ngM9wpvPUFX0SYIT['url'] = e1mT8H4dGS3XFyx0KLUA9(O9z5L3KtXqPEMepJQ0.strip(Mpsm2VF1OBnCRvK3qf6))
	iyL9QC2g0j = {'name':hWGMqtBy4wuLaVcj,'context_menu':hWGMqtBy4wuLaVcj,'plot':hWGMqtBy4wuLaVcj,'stars':hWGMqtBy4wuLaVcj,'image':hWGMqtBy4wuLaVcj,'type':hWGMqtBy4wuLaVcj,'isFolder':hWGMqtBy4wuLaVcj,'newpath':hWGMqtBy4wuLaVcj,'duration':hWGMqtBy4wuLaVcj}
	cclvGoDJW0eShO = []
	SbCeHcDfsyraL3BxQTOoqVKWZ = 'plugin://'+nUy7x6dqmk92MPb+'/?type='+hhDrLuf5l4ngM9wpvPUFX0SYIT['type']+'&mode='+hhDrLuf5l4ngM9wpvPUFX0SYIT['mode']
	if hhDrLuf5l4ngM9wpvPUFX0SYIT['page']: SbCeHcDfsyraL3BxQTOoqVKWZ += '&page='+hhDrLuf5l4ngM9wpvPUFX0SYIT['page']
	if hhDrLuf5l4ngM9wpvPUFX0SYIT['name']: SbCeHcDfsyraL3BxQTOoqVKWZ += '&name='+hhDrLuf5l4ngM9wpvPUFX0SYIT['name']
	if hhDrLuf5l4ngM9wpvPUFX0SYIT['text']: SbCeHcDfsyraL3BxQTOoqVKWZ += '&text='+hhDrLuf5l4ngM9wpvPUFX0SYIT['text']
	if hhDrLuf5l4ngM9wpvPUFX0SYIT['infodict']: SbCeHcDfsyraL3BxQTOoqVKWZ += '&infodict='+hhDrLuf5l4ngM9wpvPUFX0SYIT['infodict']
	if hhDrLuf5l4ngM9wpvPUFX0SYIT['image']: SbCeHcDfsyraL3BxQTOoqVKWZ += '&image='+hhDrLuf5l4ngM9wpvPUFX0SYIT['image']
	if hhDrLuf5l4ngM9wpvPUFX0SYIT['url']: SbCeHcDfsyraL3BxQTOoqVKWZ += '&url='+hhDrLuf5l4ngM9wpvPUFX0SYIT['url']
	if JbpxsyQVXmSEYKM3vo847Ckh!=265: iyL9QC2g0j['favorites'] = True
	else: iyL9QC2g0j['favorites'] = False
	if hhDrLuf5l4ngM9wpvPUFX0SYIT['context']: SbCeHcDfsyraL3BxQTOoqVKWZ += '&context='+hhDrLuf5l4ngM9wpvPUFX0SYIT['context']
	if JbpxsyQVXmSEYKM3vo847Ckh in [235,238] and udRvjXt9cAfha5ZsBP3U=='live' and 'EPG' in kCaIufXo1F0TyL7gtcJV5bneijMWHv:
		CrU40o7AdtXawR9qxS = 'plugin://'+nUy7x6dqmk92MPb+'?mode=238&text=SHORT_EPG&url='+O9z5L3KtXqPEMepJQ0
		aTpVvQqN43 = soMVfbr6WtpNlcSA+'البرامج القادمة'+YYSh2J6BIrsm8
		raYZ4LH07AVgM3U2hb = (aTpVvQqN43,'RunPlugin('+CrU40o7AdtXawR9qxS+')')
		cclvGoDJW0eShO.append(raYZ4LH07AVgM3U2hb)
	if JbpxsyQVXmSEYKM3vo847Ckh==265:
		BDc6tsV03u7E = NOU4G09nYWeEMX71hmHqF(eePWR0CjMViGH5hTLc9gskSO3r,True)
		if BDc6tsV03u7E>0:
			CrU40o7AdtXawR9qxS = 'plugin://'+nUy7x6dqmk92MPb+'?mode=266&text='+eePWR0CjMViGH5hTLc9gskSO3r
			aTpVvQqN43 = soMVfbr6WtpNlcSA+'مسح قائمة آخر 50 '+J72F0jRI6A(eePWR0CjMViGH5hTLc9gskSO3r)+YYSh2J6BIrsm8
			raYZ4LH07AVgM3U2hb = (aTpVvQqN43,'RunPlugin('+CrU40o7AdtXawR9qxS+')')
			cclvGoDJW0eShO.append(raYZ4LH07AVgM3U2hb)
	if udRvjXt9cAfha5ZsBP3U=='video' and JbpxsyQVXmSEYKM3vo847Ckh!=331:
		CrU40o7AdtXawR9qxS = SbCeHcDfsyraL3BxQTOoqVKWZ+'&context=6_DOWNLOAD'
		aTpVvQqN43 = soMVfbr6WtpNlcSA+'تحميل ملف الفيديو'+YYSh2J6BIrsm8
		raYZ4LH07AVgM3U2hb = (aTpVvQqN43,'RunPlugin('+CrU40o7AdtXawR9qxS+')')
		cclvGoDJW0eShO.append(raYZ4LH07AVgM3U2hb)
	if JbpxsyQVXmSEYKM3vo847Ckh==331:
		CrU40o7AdtXawR9qxS = SbCeHcDfsyraL3BxQTOoqVKWZ+'&context=6_DELETE'
		aTpVvQqN43 = soMVfbr6WtpNlcSA+'حذف ملف الفيديو'+YYSh2J6BIrsm8
		raYZ4LH07AVgM3U2hb = (aTpVvQqN43,'RunPlugin('+CrU40o7AdtXawR9qxS+')')
		cclvGoDJW0eShO.append(raYZ4LH07AVgM3U2hb)
	if udRvjXt9cAfha5ZsBP3U=='folder' and JbpxsyQVXmSEYKM3vo847Ckh==540:
		Ee0BmYM5r3yIHnKlcOA6ufUWxzCZ = Mqk51CFBym0pIQXZLsOxSJ(MM5Dx39f7ULhcJsRptzIowP,'list','GLOBALSEARCH_SPLITTED_ALL')
		if Ee0BmYM5r3yIHnKlcOA6ufUWxzCZ:
			CrU40o7AdtXawR9qxS = 'plugin://'+nUy7x6dqmk92MPb+'?context=7'
			aTpVvQqN43 = soMVfbr6WtpNlcSA+'مسح كلمات بحث المواقع'+YYSh2J6BIrsm8
			raYZ4LH07AVgM3U2hb = (aTpVvQqN43,'RunPlugin('+CrU40o7AdtXawR9qxS+')')
			cclvGoDJW0eShO.append(raYZ4LH07AVgM3U2hb)
	if udRvjXt9cAfha5ZsBP3U=='folder' and JbpxsyQVXmSEYKM3vo847Ckh==1010:
		Ee0BmYM5r3yIHnKlcOA6ufUWxzCZ = Mqk51CFBym0pIQXZLsOxSJ(MM5Dx39f7ULhcJsRptzIowP,'list','GLOBALSEARCH_SPLITTED_GOOGLE')
		if Ee0BmYM5r3yIHnKlcOA6ufUWxzCZ:
			CrU40o7AdtXawR9qxS = 'plugin://'+nUy7x6dqmk92MPb+'?context=10'
			aTpVvQqN43 = soMVfbr6WtpNlcSA+'مسح كلمات بحث جوجل'+YYSh2J6BIrsm8
			raYZ4LH07AVgM3U2hb = (aTpVvQqN43,'RunPlugin('+CrU40o7AdtXawR9qxS+')')
			cclvGoDJW0eShO.append(raYZ4LH07AVgM3U2hb)
	LV3BWbfhK6qJ0OXz2 = [9990,9999,2,7,100,151,159,176,196,199,230,239,260,261,262,263,264,265,267,270,290,330,341,346,348,501,505,510,540,710,719,761,762,1010,1022]
	if JbpxsyQVXmSEYKM3vo847Ckh not in LV3BWbfhK6qJ0OXz2:
		CrU40o7AdtXawR9qxS = 'plugin://'+nUy7x6dqmk92MPb+'?context=8&mode=260'
		aTpVvQqN43 = soMVfbr6WtpNlcSA+'القائمة الرئيسية'+YYSh2J6BIrsm8
		raYZ4LH07AVgM3U2hb = (aTpVvQqN43,'RunPlugin('+CrU40o7AdtXawR9qxS+')')
		cclvGoDJW0eShO.append(raYZ4LH07AVgM3U2hb)
	Gn5Sspf0Fv = [0,150,160,170,190,260,280,330,340,410,500,520,530,540,760,1010,9990]
	GGfykCrhax83Wp = JbpxsyQVXmSEYKM3vo847Ckh-JbpxsyQVXmSEYKM3vo847Ckh%10
	if JbpxsyQVXmSEYKM3vo847Ckh%10:
		if GGfykCrhax83Wp==280: GGfykCrhax83Wp = 230
		if GGfykCrhax83Wp==410: GGfykCrhax83Wp = 400
		if GGfykCrhax83Wp==520: GGfykCrhax83Wp = 510
		if GGfykCrhax83Wp not in Gn5Sspf0Fv:
			CrU40o7AdtXawR9qxS = 'plugin://'+nUy7x6dqmk92MPb+'?context=8&mode='+str(GGfykCrhax83Wp)
			aTpVvQqN43 = soMVfbr6WtpNlcSA+'قائمة الموقع'+YYSh2J6BIrsm8
			raYZ4LH07AVgM3U2hb = (aTpVvQqN43,'RunPlugin('+CrU40o7AdtXawR9qxS+')')
			cclvGoDJW0eShO.append(raYZ4LH07AVgM3U2hb)
	CrU40o7AdtXawR9qxS = SbCeHcDfsyraL3BxQTOoqVKWZ+'&context=9'
	aTpVvQqN43 = soMVfbr6WtpNlcSA+'تحديث القائمة'+YYSh2J6BIrsm8
	raYZ4LH07AVgM3U2hb = (aTpVvQqN43,'RunPlugin('+CrU40o7AdtXawR9qxS+')')
	cclvGoDJW0eShO.append(raYZ4LH07AVgM3U2hb)
	if fEXMiAyG3ql4vKB and JbpxsyQVXmSEYKM3vo847Ckh%10 and GGfykCrhax83Wp not in Gn5Sspf0Fv:
		CrU40o7AdtXawR9qxS = SbCeHcDfsyraL3BxQTOoqVKWZ+'&context=14'
		aTpVvQqN43 = soMVfbr6WtpNlcSA+'ترتيب عكسي مؤقت'+YYSh2J6BIrsm8
		raYZ4LH07AVgM3U2hb = (aTpVvQqN43,'RunPlugin('+CrU40o7AdtXawR9qxS+')')
		cclvGoDJW0eShO.append(raYZ4LH07AVgM3U2hb)
		CrU40o7AdtXawR9qxS = SbCeHcDfsyraL3BxQTOoqVKWZ+'&context=15'
		aTpVvQqN43 = soMVfbr6WtpNlcSA+'ترتيب تصاعدي مؤقت'+YYSh2J6BIrsm8
		raYZ4LH07AVgM3U2hb = (aTpVvQqN43,'RunPlugin('+CrU40o7AdtXawR9qxS+')')
		cclvGoDJW0eShO.append(raYZ4LH07AVgM3U2hb)
		CrU40o7AdtXawR9qxS = SbCeHcDfsyraL3BxQTOoqVKWZ+'&context=16'
		aTpVvQqN43 = soMVfbr6WtpNlcSA+'ترتيب تنازلي مؤقت'+YYSh2J6BIrsm8
		raYZ4LH07AVgM3U2hb = (aTpVvQqN43,'RunPlugin('+CrU40o7AdtXawR9qxS+')')
		cclvGoDJW0eShO.append(raYZ4LH07AVgM3U2hb)
		CrU40o7AdtXawR9qxS = SbCeHcDfsyraL3BxQTOoqVKWZ+'&context=17'
		aTpVvQqN43 = soMVfbr6WtpNlcSA+'ترتيب عشوائي مؤقت'+YYSh2J6BIrsm8
		raYZ4LH07AVgM3U2hb = (aTpVvQqN43,'RunPlugin('+CrU40o7AdtXawR9qxS+')')
		cclvGoDJW0eShO.append(raYZ4LH07AVgM3U2hb)
	if udRvjXt9cAfha5ZsBP3U in ['link','video','live']: xFCcejlr4s9530WpoAQu2my8DhKOX = False
	elif udRvjXt9cAfha5ZsBP3U=='folder': xFCcejlr4s9530WpoAQu2my8DhKOX = True
	iyL9QC2g0j['name'] = j4lHpxXvnF2VtwBb1T9PaJEm3
	iyL9QC2g0j['context_menu'] = cclvGoDJW0eShO
	if 'plot' in list(kFeSKZb8qiVd4GxwcAMHQolgU.keys()): iyL9QC2g0j['plot'] = kFeSKZb8qiVd4GxwcAMHQolgU['plot']
	if 'stars' in list(kFeSKZb8qiVd4GxwcAMHQolgU.keys()): iyL9QC2g0j['stars'] = kFeSKZb8qiVd4GxwcAMHQolgU['stars']
	if acysH2W9N0BhXIvJPRM5t: iyL9QC2g0j['image'] = acysH2W9N0BhXIvJPRM5t
	if udRvjXt9cAfha5ZsBP3U=='video' and f0p6eoXk4ajsNldbEMi:
		GG4OqC6TJgXjQMLARUWlb2vI = trdVA0JvFaD.findall('[\d:]+',f0p6eoXk4ajsNldbEMi,trdVA0JvFaD.DOTALL)
		if GG4OqC6TJgXjQMLARUWlb2vI:
			GG4OqC6TJgXjQMLARUWlb2vI = '0:0:0:0:0:'+GG4OqC6TJgXjQMLARUWlb2vI[0]
			KmPeHvQYBna8foZrX6Dz,ansOeoqAIcd394FBwNZm7YTPvQ,cfhbrpXlHsaDC8N1jUOokZ3,f4OS5umYxvhyojX,x7eCcnldT1t4 = GG4OqC6TJgXjQMLARUWlb2vI.rsplit(':',4)
			NHDZRpziaUxSq = int(ansOeoqAIcd394FBwNZm7YTPvQ)*24*LOchm76Z8SuMaq1PGCT+int(cfhbrpXlHsaDC8N1jUOokZ3)*LOchm76Z8SuMaq1PGCT+int(f4OS5umYxvhyojX)*60+int(x7eCcnldT1t4)
			iyL9QC2g0j['duration'] = NHDZRpziaUxSq
	iyL9QC2g0j['type'] = udRvjXt9cAfha5ZsBP3U
	iyL9QC2g0j['isFolder'] = xFCcejlr4s9530WpoAQu2my8DhKOX
	iyL9QC2g0j['newpath'] = SbCeHcDfsyraL3BxQTOoqVKWZ
	iyL9QC2g0j['menuItem'] = aQNvODnTB3mjP76kR
	iyL9QC2g0j['mode'] = JbpxsyQVXmSEYKM3vo847Ckh
	return iyL9QC2g0j
def uE9HfdgDLMS0CbBWNp8wk1smlTo(NOU4G09nYWeEMX71hmHqF):
	VYkojDcNHPXi5KL6lzTEy,Ao8udjwfk3YgC2m = [],hWGMqtBy4wuLaVcj
	from jjGMocmUg2 import Z54CwW0eVXn,AAZbtg5RKeUcr47IYTvVSaELqN
	xjgwHolCi4EaB8pzW25KFr7 = Z54CwW0eVXn()
	agkF7iSBOZ4DKJC25yztrsN86cXLfV = ee8c0jzrTntGSUdRJm.getSetting('av.status.refresh')
	if i2tpOA6QzlfUByTSeKacWnV1 and (not agkF7iSBOZ4DKJC25yztrsN86cXLfV or agkF7iSBOZ4DKJC25yztrsN86cXLfV=='REFRESH_CACHE'): agkF7iSBOZ4DKJC25yztrsN86cXLfV = Mqk51CFBym0pIQXZLsOxSJ(MM5Dx39f7ULhcJsRptzIowP,'str','FOLDERS_SORT',i2tpOA6QzlfUByTSeKacWnV1)
	if agkF7iSBOZ4DKJC25yztrsN86cXLfV:
		if   '_PERM' in agkF7iSBOZ4DKJC25yztrsN86cXLfV: Ao8udjwfk3YgC2m = 'ترتيب دائمي'
		elif '_TEMP' in agkF7iSBOZ4DKJC25yztrsN86cXLfV: Ao8udjwfk3YgC2m = 'ترتيب مؤقت'
		if   '_REVERSED_' in agkF7iSBOZ4DKJC25yztrsN86cXLfV: u25Car4veWZpIhniLSUKqH83Gf = 'عكسي' ; vNRpDl1awktg7QP4m0KGqMTS2i[:] = reversed(vNRpDl1awktg7QP4m0KGqMTS2i)
		elif '_ASCENDED_' in agkF7iSBOZ4DKJC25yztrsN86cXLfV: u25Car4veWZpIhniLSUKqH83Gf = 'تصاعدي' ; vNRpDl1awktg7QP4m0KGqMTS2i[:] = sorted(vNRpDl1awktg7QP4m0KGqMTS2i,reverse=fEXMiAyG3ql4vKB,key=lambda key:key[bXukYxQ4aHw])
		elif '_DESCENDED_' in agkF7iSBOZ4DKJC25yztrsN86cXLfV: u25Car4veWZpIhniLSUKqH83Gf = 'تنازلي' ; vNRpDl1awktg7QP4m0KGqMTS2i[:] = sorted(vNRpDl1awktg7QP4m0KGqMTS2i,reverse=VBlawK4mgHSyLEn8iqhUkz5,key=lambda key:key[bXukYxQ4aHw])
		elif '_RANDOMIZED_' in agkF7iSBOZ4DKJC25yztrsN86cXLfV: u25Car4veWZpIhniLSUKqH83Gf = 'عشوائي' ; eOmXSF6kIWV7yqKCR.shuffle(vNRpDl1awktg7QP4m0KGqMTS2i)
	name = Ao8udjwfk3YgC2m+' ['+u25Car4veWZpIhniLSUKqH83Gf+']' if Ao8udjwfk3YgC2m else 'ترتيب دائمي [بدون]'
	name = soMVfbr6WtpNlcSA+name+YYSh2J6BIrsm8
	if agkF7iSBOZ4DKJC25yztrsN86cXLfV in xLj46t2Qbi3dr8EgRDXmPMqpUwsvN: ee8c0jzrTntGSUdRJm.setSetting('av.status.refresh',hWGMqtBy4wuLaVcj)
	X3X4Y8RzxSVfZJUFDe,wJUqaIAzvtsMSEZlKV,S6NALBOqGn1zi2W5M8y7,u2GRrQ0854,nWE8aO53lFfD,l7COkhRWD9uVS60Pte2NoyAaZn,XNBHzrlKD9yW,MH5c7Nekugx8O1AQjInRWyT64GV,SX7OT3VLGp2iQm = vikbdSOtZJFz6gQeL(i2tpOA6QzlfUByTSeKacWnV1)
	Gn5Sspf0Fv = [0,150,160,170,190,260,280,330,340,410,500,520,530,540,760,1010,9990,1020]
	JbpxsyQVXmSEYKM3vo847Ckh = int(u2GRrQ0854)
	GGfykCrhax83Wp = JbpxsyQVXmSEYKM3vo847Ckh-JbpxsyQVXmSEYKM3vo847Ckh%10
	if JbpxsyQVXmSEYKM3vo847Ckh%10 and GGfykCrhax83Wp not in Gn5Sspf0Fv:
		vNRpDl1awktg7QP4m0KGqMTS2i[:] = [('link',name,'',533,'','',i2tpOA6QzlfUByTSeKacWnV1,'','')]+vNRpDl1awktg7QP4m0KGqMTS2i
	for aQNvODnTB3mjP76kR in vNRpDl1awktg7QP4m0KGqMTS2i:
		iyL9QC2g0j = ddx6ayPYD9cKSvq45Zh0LkIHBUEp(aQNvODnTB3mjP76kR,NOU4G09nYWeEMX71hmHqF,xjgwHolCi4EaB8pzW25KFr7)
		if iyL9QC2g0j['favorites']:
			xmc1tUXPa3Qkvbu = AAZbtg5RKeUcr47IYTvVSaELqN(xjgwHolCi4EaB8pzW25KFr7,iyL9QC2g0j['menuItem'],iyL9QC2g0j['newpath'])
			iyL9QC2g0j['context_menu'] = xmc1tUXPa3Qkvbu+iyL9QC2g0j['context_menu']
		VYkojDcNHPXi5KL6lzTEy.append(iyL9QC2g0j)
	return VYkojDcNHPXi5KL6lzTEy
def WWm2QXdeFCTrqNkS0lBVcD75UwhR(KgUCchf0AS4luxk1zOrm2):
	IiZHcxgF0wWrVUKSukdzDAnb,BR6GDZVSa02wcTMznQAHeogX9FWL, = [],hWGMqtBy4wuLaVcj
	for VDvfJ2uLMsg1xjcN5wGkzlQi in KgUCchf0AS4luxk1zOrm2:
		if not VDvfJ2uLMsg1xjcN5wGkzlQi: IiZHcxgF0wWrVUKSukdzDAnb.append(hWGMqtBy4wuLaVcj)
		else: break
	KgUCchf0AS4luxk1zOrm2 = KgUCchf0AS4luxk1zOrm2[len(IiZHcxgF0wWrVUKSukdzDAnb):]
	s9ea72VfoygAOFRCWQTH3zmDuLPE = '\n\n\n\n'.join(KgUCchf0AS4luxk1zOrm2)
	s9ea72VfoygAOFRCWQTH3zmDuLPE = s9ea72VfoygAOFRCWQTH3zmDuLPE.replace('===== ===== =====','000001')
	s9ea72VfoygAOFRCWQTH3zmDuLPE = s9ea72VfoygAOFRCWQTH3zmDuLPE.replace(hXB0vKVQ5PRI91SDTprMdfuHEm4,'000002')
	s9ea72VfoygAOFRCWQTH3zmDuLPE = s9ea72VfoygAOFRCWQTH3zmDuLPE.replace(soMVfbr6WtpNlcSA,'000003')
	s9ea72VfoygAOFRCWQTH3zmDuLPE = s9ea72VfoygAOFRCWQTH3zmDuLPE.replace(YYSh2J6BIrsm8,'000004')
	s9ea72VfoygAOFRCWQTH3zmDuLPE = s9ea72VfoygAOFRCWQTH3zmDuLPE.replace('[RIGHT]','000005')
	oa4HOCVwS1cgB9h5DfAvp8 = 100000
	jjs7Fux8tZGvqnUiY5zlehdJ1 = {}
	Kyz4F952lWaNwC7eHxRqSp = trdVA0JvFaD.findall('http.*?[\r\n ]',s9ea72VfoygAOFRCWQTH3zmDuLPE,trdVA0JvFaD.DOTALL)
	for uVgFK21twDOS in Kyz4F952lWaNwC7eHxRqSp:
		oa4HOCVwS1cgB9h5DfAvp8 += 1
		s9ea72VfoygAOFRCWQTH3zmDuLPE = s9ea72VfoygAOFRCWQTH3zmDuLPE.replace(uVgFK21twDOS,str(oa4HOCVwS1cgB9h5DfAvp8))
		jjs7Fux8tZGvqnUiY5zlehdJ1[str(oa4HOCVwS1cgB9h5DfAvp8)] = uVgFK21twDOS
	for qHM8P3uk06wSa1VfZXijWN2 in range(0,len(s9ea72VfoygAOFRCWQTH3zmDuLPE),4800):
		hrQHcAwZmSznp7RgU320oeOXFyf6K = s9ea72VfoygAOFRCWQTH3zmDuLPE[qHM8P3uk06wSa1VfZXijWN2:qHM8P3uk06wSa1VfZXijWN2+4800]
		tDJsWk6lj7ihA9La1yC = ee8c0jzrTntGSUdRJm.getSetting('av.language.code')
		O9z5L3KtXqPEMepJQ0 = 'https://translator-api.glosbe.com/translateByLangDetect?sourceLang=ar&targetLang='+tDJsWk6lj7ihA9La1yC
		eE4wIviRq52y316 = {'Content-Type':'text/plain'}
		QiK1J5cwCG2s = hrQHcAwZmSznp7RgU320oeOXFyf6K.encode(a7VXeDU82IfQEnPZAdiT)
		oTawtcGI687h = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(lke5D6CpaAXPdEZyrBSw7T,'POST',O9z5L3KtXqPEMepJQ0,QiK1J5cwCG2s,eE4wIviRq52y316,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'LIBRARY-GLOSBE_TRANSLATE-1st')
		if oTawtcGI687h.succeeded:
			zJjQP6hXe8vbdrTDq1EmZwncYUL = oTawtcGI687h.content
			z7YmIE6gPLVNHQ = Cy9ow3c21nABMjzqeaIT('str',zJjQP6hXe8vbdrTDq1EmZwncYUL)
			if z7YmIE6gPLVNHQ:
				z7YmIE6gPLVNHQ = z7YmIE6gPLVNHQ['translation']
				z7YmIE6gPLVNHQ = emr1Lf523Ti0OtcNgxP(z7YmIE6gPLVNHQ)
				for uuk6b4oz9gUJAmLVljxYpMi8ThI in range(len(z7YmIE6gPLVNHQ)):
					BR6GDZVSa02wcTMznQAHeogX9FWL += z7YmIE6gPLVNHQ[uuk6b4oz9gUJAmLVljxYpMi8ThI][0]
	BR6GDZVSa02wcTMznQAHeogX9FWL = BR6GDZVSa02wcTMznQAHeogX9FWL.replace('000001','===== ===== =====')
	BR6GDZVSa02wcTMznQAHeogX9FWL = BR6GDZVSa02wcTMznQAHeogX9FWL.replace('000002',hXB0vKVQ5PRI91SDTprMdfuHEm4)
	BR6GDZVSa02wcTMznQAHeogX9FWL = BR6GDZVSa02wcTMznQAHeogX9FWL.replace('000003',soMVfbr6WtpNlcSA)
	BR6GDZVSa02wcTMznQAHeogX9FWL = BR6GDZVSa02wcTMznQAHeogX9FWL.replace('000004',YYSh2J6BIrsm8)
	BR6GDZVSa02wcTMznQAHeogX9FWL = BR6GDZVSa02wcTMznQAHeogX9FWL.replace('000005','[RIGHT]')
	for oa4HOCVwS1cgB9h5DfAvp8 in list(jjs7Fux8tZGvqnUiY5zlehdJ1.keys()):
		uVgFK21twDOS = jjs7Fux8tZGvqnUiY5zlehdJ1[oa4HOCVwS1cgB9h5DfAvp8]
		BR6GDZVSa02wcTMznQAHeogX9FWL = BR6GDZVSa02wcTMznQAHeogX9FWL.replace(oa4HOCVwS1cgB9h5DfAvp8,uVgFK21twDOS)
	BR6GDZVSa02wcTMznQAHeogX9FWL = BR6GDZVSa02wcTMznQAHeogX9FWL.split('\n\n\n\n')
	return IiZHcxgF0wWrVUKSukdzDAnb+BR6GDZVSa02wcTMznQAHeogX9FWL
def rSFjMvwRh0W6KLmOqs(KgUCchf0AS4luxk1zOrm2):
	IiZHcxgF0wWrVUKSukdzDAnb,BR6GDZVSa02wcTMznQAHeogX9FWL, = [],hWGMqtBy4wuLaVcj
	for VDvfJ2uLMsg1xjcN5wGkzlQi in KgUCchf0AS4luxk1zOrm2:
		if not VDvfJ2uLMsg1xjcN5wGkzlQi: IiZHcxgF0wWrVUKSukdzDAnb.append(hWGMqtBy4wuLaVcj)
		else: break
	KgUCchf0AS4luxk1zOrm2 = KgUCchf0AS4luxk1zOrm2[len(IiZHcxgF0wWrVUKSukdzDAnb):]
	s9ea72VfoygAOFRCWQTH3zmDuLPE = '\\n\\n\\n\\n'.join(KgUCchf0AS4luxk1zOrm2)
	s9ea72VfoygAOFRCWQTH3zmDuLPE = s9ea72VfoygAOFRCWQTH3zmDuLPE.replace('كلا','no')
	s9ea72VfoygAOFRCWQTH3zmDuLPE = s9ea72VfoygAOFRCWQTH3zmDuLPE.replace('استمرار','continue')
	s9ea72VfoygAOFRCWQTH3zmDuLPE = s9ea72VfoygAOFRCWQTH3zmDuLPE.replace('===== ===== =====','000001')
	s9ea72VfoygAOFRCWQTH3zmDuLPE = s9ea72VfoygAOFRCWQTH3zmDuLPE.replace(hXB0vKVQ5PRI91SDTprMdfuHEm4,'000002')
	s9ea72VfoygAOFRCWQTH3zmDuLPE = s9ea72VfoygAOFRCWQTH3zmDuLPE.replace(soMVfbr6WtpNlcSA,'000003')
	s9ea72VfoygAOFRCWQTH3zmDuLPE = s9ea72VfoygAOFRCWQTH3zmDuLPE.replace(YYSh2J6BIrsm8,'000004')
	s9ea72VfoygAOFRCWQTH3zmDuLPE = s9ea72VfoygAOFRCWQTH3zmDuLPE.replace('[RIGHT]','000005')
	s9ea72VfoygAOFRCWQTH3zmDuLPE = s9ea72VfoygAOFRCWQTH3zmDuLPE.replace('[CENTER]','000006')
	s9ea72VfoygAOFRCWQTH3zmDuLPE = s9ea72VfoygAOFRCWQTH3zmDuLPE.replace('[RTL]','000007')
	s9ea72VfoygAOFRCWQTH3zmDuLPE = s9ea72VfoygAOFRCWQTH3zmDuLPE.replace("'","\\\\\\'")
	s9ea72VfoygAOFRCWQTH3zmDuLPE = s9ea72VfoygAOFRCWQTH3zmDuLPE.replace('"','\\\\\\"')
	s9ea72VfoygAOFRCWQTH3zmDuLPE = s9ea72VfoygAOFRCWQTH3zmDuLPE.replace(NXMOzZjYsmS9pf,'\\n')
	s9ea72VfoygAOFRCWQTH3zmDuLPE = s9ea72VfoygAOFRCWQTH3zmDuLPE.replace(y6eSQlZEV8uwKG5M3,'\\\\r')
	for qHM8P3uk06wSa1VfZXijWN2 in range(0,len(s9ea72VfoygAOFRCWQTH3zmDuLPE),4800):
		hrQHcAwZmSznp7RgU320oeOXFyf6K = s9ea72VfoygAOFRCWQTH3zmDuLPE[qHM8P3uk06wSa1VfZXijWN2:qHM8P3uk06wSa1VfZXijWN2+4800]
		O9z5L3KtXqPEMepJQ0 = 'https://translate.google.com/_/TranslateWebserverUi/data/batchexecute'
		eE4wIviRq52y316 = {'Content-Type':'application/x-www-form-urlencoded'}
		tDJsWk6lj7ihA9La1yC = ee8c0jzrTntGSUdRJm.getSetting('av.language.code')
		QiK1J5cwCG2s = 'f.req='+e1mT8H4dGS3XFyx0KLUA9('[[["MkEWBc","[[\\"'+hrQHcAwZmSznp7RgU320oeOXFyf6K+'\\",\\"ar\\",\\"'+tDJsWk6lj7ihA9La1yC+'\\",1],[]]",null,"generic"]]]',hWGMqtBy4wuLaVcj)
		QiK1J5cwCG2s = QiK1J5cwCG2s.replace('%5Cn','%5C%5Cn')
		oTawtcGI687h = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(lke5D6CpaAXPdEZyrBSw7T,'POST',O9z5L3KtXqPEMepJQ0,QiK1J5cwCG2s,eE4wIviRq52y316,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'LIBRARY-GOOGLE_TRANSLATE-1st')
		if oTawtcGI687h.succeeded:
			zJjQP6hXe8vbdrTDq1EmZwncYUL = oTawtcGI687h.content
			zJjQP6hXe8vbdrTDq1EmZwncYUL = zJjQP6hXe8vbdrTDq1EmZwncYUL.split(NXMOzZjYsmS9pf)[-1]
			z7YmIE6gPLVNHQ = Cy9ow3c21nABMjzqeaIT('str',zJjQP6hXe8vbdrTDq1EmZwncYUL)[0][2]
			if z7YmIE6gPLVNHQ:
				z7YmIE6gPLVNHQ = Cy9ow3c21nABMjzqeaIT('str',z7YmIE6gPLVNHQ)[1][0][0][5]
				z7YmIE6gPLVNHQ = emr1Lf523Ti0OtcNgxP(z7YmIE6gPLVNHQ)
				for uuk6b4oz9gUJAmLVljxYpMi8ThI in range(len(z7YmIE6gPLVNHQ)):
					BR6GDZVSa02wcTMznQAHeogX9FWL += z7YmIE6gPLVNHQ[uuk6b4oz9gUJAmLVljxYpMi8ThI][0]
	BR6GDZVSa02wcTMznQAHeogX9FWL = BR6GDZVSa02wcTMznQAHeogX9FWL.replace('00000','0000').replace('0000','000')
	BR6GDZVSa02wcTMznQAHeogX9FWL = BR6GDZVSa02wcTMznQAHeogX9FWL.replace('0001','===== ===== =====')
	BR6GDZVSa02wcTMznQAHeogX9FWL = BR6GDZVSa02wcTMznQAHeogX9FWL.replace('0002',hXB0vKVQ5PRI91SDTprMdfuHEm4)
	BR6GDZVSa02wcTMznQAHeogX9FWL = BR6GDZVSa02wcTMznQAHeogX9FWL.replace('0003',soMVfbr6WtpNlcSA)
	BR6GDZVSa02wcTMznQAHeogX9FWL = BR6GDZVSa02wcTMznQAHeogX9FWL.replace('0004',YYSh2J6BIrsm8)
	BR6GDZVSa02wcTMznQAHeogX9FWL = BR6GDZVSa02wcTMznQAHeogX9FWL.replace('0005','[RIGHT]')
	BR6GDZVSa02wcTMznQAHeogX9FWL = BR6GDZVSa02wcTMznQAHeogX9FWL.replace('0006','[CENTER]')
	BR6GDZVSa02wcTMznQAHeogX9FWL = BR6GDZVSa02wcTMznQAHeogX9FWL.replace('0007','[RTL]')
	BR6GDZVSa02wcTMznQAHeogX9FWL = BR6GDZVSa02wcTMznQAHeogX9FWL.split('\n\n\n\n')
	return IiZHcxgF0wWrVUKSukdzDAnb+BR6GDZVSa02wcTMznQAHeogX9FWL
def hT0xcMVHyEWqJlfngFXaGb(KgUCchf0AS4luxk1zOrm2):
	IiZHcxgF0wWrVUKSukdzDAnb,d0wTMHZ4lz6Vnjpveb5umchf1Oo = [],[]
	for VDvfJ2uLMsg1xjcN5wGkzlQi in KgUCchf0AS4luxk1zOrm2:
		if not VDvfJ2uLMsg1xjcN5wGkzlQi: IiZHcxgF0wWrVUKSukdzDAnb.append(hWGMqtBy4wuLaVcj)
		else: break
	KgUCchf0AS4luxk1zOrm2 = KgUCchf0AS4luxk1zOrm2[len(IiZHcxgF0wWrVUKSukdzDAnb):]
	s9ea72VfoygAOFRCWQTH3zmDuLPE = '\n\n\n\n'.join(KgUCchf0AS4luxk1zOrm2)
	s9ea72VfoygAOFRCWQTH3zmDuLPE = s9ea72VfoygAOFRCWQTH3zmDuLPE.replace('كلا','no')
	s9ea72VfoygAOFRCWQTH3zmDuLPE = s9ea72VfoygAOFRCWQTH3zmDuLPE.replace('استمرار','continue')
	s9ea72VfoygAOFRCWQTH3zmDuLPE = s9ea72VfoygAOFRCWQTH3zmDuLPE.replace('أدناه','below')
	s9ea72VfoygAOFRCWQTH3zmDuLPE = s9ea72VfoygAOFRCWQTH3zmDuLPE.replace(hXB0vKVQ5PRI91SDTprMdfuHEm4,'00001')
	s9ea72VfoygAOFRCWQTH3zmDuLPE = s9ea72VfoygAOFRCWQTH3zmDuLPE.replace(soMVfbr6WtpNlcSA,'00002')
	s9ea72VfoygAOFRCWQTH3zmDuLPE = s9ea72VfoygAOFRCWQTH3zmDuLPE.replace(YYSh2J6BIrsm8,'00003')
	s9ea72VfoygAOFRCWQTH3zmDuLPE = s9ea72VfoygAOFRCWQTH3zmDuLPE.replace('=====','00004')
	s9ea72VfoygAOFRCWQTH3zmDuLPE = s9ea72VfoygAOFRCWQTH3zmDuLPE.replace(',','00005')
	s9ea72VfoygAOFRCWQTH3zmDuLPE = s9ea72VfoygAOFRCWQTH3zmDuLPE.replace('[RTL]','00009')
	s9ea72VfoygAOFRCWQTH3zmDuLPE = s9ea72VfoygAOFRCWQTH3zmDuLPE.replace('[CENTER]','0000A')
	s9ea72VfoygAOFRCWQTH3zmDuLPE = s9ea72VfoygAOFRCWQTH3zmDuLPE.replace(y6eSQlZEV8uwKG5M3,'0000B')
	KgUCchf0AS4luxk1zOrm2 = s9ea72VfoygAOFRCWQTH3zmDuLPE.split(NXMOzZjYsmS9pf)
	s9ea72VfoygAOFRCWQTH3zmDuLPE,BR6GDZVSa02wcTMznQAHeogX9FWL = hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj
	for VDvfJ2uLMsg1xjcN5wGkzlQi in KgUCchf0AS4luxk1zOrm2:
		if len(s9ea72VfoygAOFRCWQTH3zmDuLPE+VDvfJ2uLMsg1xjcN5wGkzlQi)<1800: s9ea72VfoygAOFRCWQTH3zmDuLPE += NXMOzZjYsmS9pf+VDvfJ2uLMsg1xjcN5wGkzlQi
		else:
			d0wTMHZ4lz6Vnjpveb5umchf1Oo.append(s9ea72VfoygAOFRCWQTH3zmDuLPE)
			s9ea72VfoygAOFRCWQTH3zmDuLPE = VDvfJ2uLMsg1xjcN5wGkzlQi
	d0wTMHZ4lz6Vnjpveb5umchf1Oo.append(s9ea72VfoygAOFRCWQTH3zmDuLPE)
	for VDvfJ2uLMsg1xjcN5wGkzlQi in d0wTMHZ4lz6Vnjpveb5umchf1Oo:
		eE4wIviRq52y316 = {'Content-Type':'application/json','User-Agent':hWGMqtBy4wuLaVcj}
		O9z5L3KtXqPEMepJQ0 = 'https://api.reverso.net/translate/v1/translation'
		tDJsWk6lj7ihA9La1yC = ee8c0jzrTntGSUdRJm.getSetting('av.language.code')
		QiK1J5cwCG2s = {"format":"text","from":"ara","to":tDJsWk6lj7ihA9La1yC,"input":VDvfJ2uLMsg1xjcN5wGkzlQi,"options":{"sentenceSplitter":True,"origin":"translation.web","contextResults":False,"languageDetection":False}}
		QiK1J5cwCG2s = TPDQ5L9eWpIJcrM3YH48Cs6.dumps(QiK1J5cwCG2s)
		oTawtcGI687h = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(lke5D6CpaAXPdEZyrBSw7T,'POST',O9z5L3KtXqPEMepJQ0,QiK1J5cwCG2s,eE4wIviRq52y316,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'LIBRARY-REVERSO_TRANSLATE-1st')
		if oTawtcGI687h.succeeded:
			zJjQP6hXe8vbdrTDq1EmZwncYUL = oTawtcGI687h.content
			zJjQP6hXe8vbdrTDq1EmZwncYUL = Cy9ow3c21nABMjzqeaIT('dict',zJjQP6hXe8vbdrTDq1EmZwncYUL)
			BR6GDZVSa02wcTMznQAHeogX9FWL += NXMOzZjYsmS9pf+hWGMqtBy4wuLaVcj.join(zJjQP6hXe8vbdrTDq1EmZwncYUL['translation'])
	BR6GDZVSa02wcTMznQAHeogX9FWL = BR6GDZVSa02wcTMznQAHeogX9FWL[2:]
	BR6GDZVSa02wcTMznQAHeogX9FWL = BR6GDZVSa02wcTMznQAHeogX9FWL.replace('000000','00000').replace('00000','0000').replace('0000','000')
	BR6GDZVSa02wcTMznQAHeogX9FWL = BR6GDZVSa02wcTMznQAHeogX9FWL.replace('0001',hXB0vKVQ5PRI91SDTprMdfuHEm4)
	BR6GDZVSa02wcTMznQAHeogX9FWL = BR6GDZVSa02wcTMznQAHeogX9FWL.replace('0002',soMVfbr6WtpNlcSA)
	BR6GDZVSa02wcTMznQAHeogX9FWL = BR6GDZVSa02wcTMznQAHeogX9FWL.replace('0003',YYSh2J6BIrsm8)
	BR6GDZVSa02wcTMznQAHeogX9FWL = BR6GDZVSa02wcTMznQAHeogX9FWL.replace('0004','=====')
	BR6GDZVSa02wcTMznQAHeogX9FWL = BR6GDZVSa02wcTMznQAHeogX9FWL.replace('0005',',')
	BR6GDZVSa02wcTMznQAHeogX9FWL = BR6GDZVSa02wcTMznQAHeogX9FWL.replace('0009','[RTL]')
	BR6GDZVSa02wcTMznQAHeogX9FWL = BR6GDZVSa02wcTMznQAHeogX9FWL.replace('000A','[CENTER]')
	BR6GDZVSa02wcTMznQAHeogX9FWL = BR6GDZVSa02wcTMznQAHeogX9FWL.replace('000B',y6eSQlZEV8uwKG5M3)
	BR6GDZVSa02wcTMznQAHeogX9FWL = BR6GDZVSa02wcTMznQAHeogX9FWL.split('\n\n\n\n')
	return IiZHcxgF0wWrVUKSukdzDAnb+BR6GDZVSa02wcTMznQAHeogX9FWL
def aMwjFti8rlX(KgUCchf0AS4luxk1zOrm2):
	ECyN4WlSmv9wVHGcMa = ee8c0jzrTntGSUdRJm.getSetting('av.language.translate')
	if not ECyN4WlSmv9wVHGcMa or not KgUCchf0AS4luxk1zOrm2: return KgUCchf0AS4luxk1zOrm2
	jg5XFhouLKxBHDf = ee8c0jzrTntGSUdRJm.getSetting('av.language.provider')
	tDJsWk6lj7ihA9La1yC = ee8c0jzrTntGSUdRJm.getSetting('av.language.code')
	jjAUNRZuIEr6xGcJWgBMemo5YF8h2 = tDJsWk6lj7ihA9La1yC+'__'+str(KgUCchf0AS4luxk1zOrm2)
	ee8c0jzrTntGSUdRJm.setSetting('av.language.translate',hWGMqtBy4wuLaVcj)
	BR6GDZVSa02wcTMznQAHeogX9FWL = Mqk51CFBym0pIQXZLsOxSJ(MM5Dx39f7ULhcJsRptzIowP,'list','TRANSLATE_'+jg5XFhouLKxBHDf,jjAUNRZuIEr6xGcJWgBMemo5YF8h2)
	if not BR6GDZVSa02wcTMznQAHeogX9FWL:
		if jg5XFhouLKxBHDf=='GOOGLE': BR6GDZVSa02wcTMznQAHeogX9FWL = rSFjMvwRh0W6KLmOqs(KgUCchf0AS4luxk1zOrm2)
		elif jg5XFhouLKxBHDf=='REVERSO': BR6GDZVSa02wcTMznQAHeogX9FWL = hT0xcMVHyEWqJlfngFXaGb(KgUCchf0AS4luxk1zOrm2)
		elif jg5XFhouLKxBHDf=='GLOSBE': BR6GDZVSa02wcTMznQAHeogX9FWL = WWm2QXdeFCTrqNkS0lBVcD75UwhR(KgUCchf0AS4luxk1zOrm2)
		if len(KgUCchf0AS4luxk1zOrm2)==len(BR6GDZVSa02wcTMznQAHeogX9FWL):
			BxuD7iQRpW1(MM5Dx39f7ULhcJsRptzIowP,'TRANSLATE_'+jg5XFhouLKxBHDf,jjAUNRZuIEr6xGcJWgBMemo5YF8h2,BR6GDZVSa02wcTMznQAHeogX9FWL,AoRzutVGQfLjYMwdCngZPxs)
		else:
			BR6GDZVSa02wcTMznQAHeogX9FWL = KgUCchf0AS4luxk1zOrm2
			OnsAxhdVjZF('الترجمة فشلت','Translation Failed')
	ee8c0jzrTntGSUdRJm.setSetting('av.language.translate','1')
	return BR6GDZVSa02wcTMznQAHeogX9FWL
def pmGvcwCfA4La(aQNvODnTB3mjP76kR,VYkojDcNHPXi5KL6lzTEy,YpiyX9QrtV7zUehHq0RKgdCLjW,k1ki6ahd2uPfOMjsGEmVobSeBpQT,U9NuzFjwZOfSAl7seTMB):
	udRvjXt9cAfha5ZsBP3U,j4lHpxXvnF2VtwBb1T9PaJEm3,O9z5L3KtXqPEMepJQ0,JbpxsyQVXmSEYKM3vo847Ckh,acysH2W9N0BhXIvJPRM5t,z5NBJ1tXibWlaTfhdo0FG,s9ea72VfoygAOFRCWQTH3zmDuLPE,kCaIufXo1F0TyL7gtcJV5bneijMWHv,kFeSKZb8qiVd4GxwcAMHQolgU = aQNvODnTB3mjP76kR
	hMZPR3UILm1CEsctD = []
	ECyN4WlSmv9wVHGcMa = ee8c0jzrTntGSUdRJm.getSetting('av.language.translate')
	if ECyN4WlSmv9wVHGcMa:
		botpflDPL9d5,sH97JpPkwaSR5GyLWQde,O3Cxvt1wjhnoXdQLqBSWNflE5G = [],[],[]
		if not hMZPR3UILm1CEsctD:
			for iyL9QC2g0j in VYkojDcNHPXi5KL6lzTEy:
				j4lHpxXvnF2VtwBb1T9PaJEm3 = iyL9QC2g0j['name'].replace(cc6SBsG2vlpjPd8yERNW1AJDZM,hWGMqtBy4wuLaVcj).replace(w4GYEC6fmU2g7H,hWGMqtBy4wuLaVcj)
				NNCqlXYrvGZhgD6QKajm1HUMc = trdVA0JvFaD.findall('^(\[COLOR FFFFFF00\])(\d\d.\d\d) (\d\d.\d\d)(\[/COLOR\]) (.*?)$',j4lHpxXvnF2VtwBb1T9PaJEm3,trdVA0JvFaD.DOTALL)
				if NNCqlXYrvGZhgD6QKajm1HUMc:
					IiZHcxgF0wWrVUKSukdzDAnb,GLMvPnpycjEdkzI,Nbyuo1ZOHJ,vXYFdtOMoWGuNyEr2ew8,j4lHpxXvnF2VtwBb1T9PaJEm3 = NNCqlXYrvGZhgD6QKajm1HUMc[0]
					NNCqlXYrvGZhgD6QKajm1HUMc = IiZHcxgF0wWrVUKSukdzDAnb+GLMvPnpycjEdkzI+Mpsm2VF1OBnCRvK3qf6+Nbyuo1ZOHJ+vXYFdtOMoWGuNyEr2ew8+Mpsm2VF1OBnCRvK3qf6
				else:
					NNCqlXYrvGZhgD6QKajm1HUMc = trdVA0JvFaD.findall('^(.*?) (\[COLOR FFFFFF00\])(\d\d.\d\d) (\d\d.\d\d)(\[/COLOR\])$',j4lHpxXvnF2VtwBb1T9PaJEm3,trdVA0JvFaD.DOTALL)
					if NNCqlXYrvGZhgD6QKajm1HUMc:
						j4lHpxXvnF2VtwBb1T9PaJEm3,IiZHcxgF0wWrVUKSukdzDAnb,Nbyuo1ZOHJ,GLMvPnpycjEdkzI,vXYFdtOMoWGuNyEr2ew8 = NNCqlXYrvGZhgD6QKajm1HUMc[0]
						NNCqlXYrvGZhgD6QKajm1HUMc = IiZHcxgF0wWrVUKSukdzDAnb+GLMvPnpycjEdkzI+Mpsm2VF1OBnCRvK3qf6+Nbyuo1ZOHJ+vXYFdtOMoWGuNyEr2ew8+Mpsm2VF1OBnCRvK3qf6
					else: NNCqlXYrvGZhgD6QKajm1HUMc = hWGMqtBy4wuLaVcj
				JbNKPl6kAxRFy07jXqt = trdVA0JvFaD.findall('^(.\[COLOR FFF08C1F\]\w\w\w \[/COLOR\])(.*?)$',j4lHpxXvnF2VtwBb1T9PaJEm3,trdVA0JvFaD.DOTALL)
				if JbNKPl6kAxRFy07jXqt: JbNKPl6kAxRFy07jXqt,j4lHpxXvnF2VtwBb1T9PaJEm3 = JbNKPl6kAxRFy07jXqt[0]
				else: JbNKPl6kAxRFy07jXqt = hWGMqtBy4wuLaVcj
				botpflDPL9d5.append(NNCqlXYrvGZhgD6QKajm1HUMc+JbNKPl6kAxRFy07jXqt)
				sH97JpPkwaSR5GyLWQde.append(j4lHpxXvnF2VtwBb1T9PaJEm3)
			O3Cxvt1wjhnoXdQLqBSWNflE5G = aMwjFti8rlX(sH97JpPkwaSR5GyLWQde)
			if O3Cxvt1wjhnoXdQLqBSWNflE5G:
				for qHM8P3uk06wSa1VfZXijWN2 in range(len(VYkojDcNHPXi5KL6lzTEy)):
					iyL9QC2g0j = VYkojDcNHPXi5KL6lzTEy[qHM8P3uk06wSa1VfZXijWN2]
					iyL9QC2g0j['name'] = botpflDPL9d5[qHM8P3uk06wSa1VfZXijWN2]+O3Cxvt1wjhnoXdQLqBSWNflE5G[qHM8P3uk06wSa1VfZXijWN2]
					hMZPR3UILm1CEsctD.append(iyL9QC2g0j)
	if hMZPR3UILm1CEsctD: VYkojDcNHPXi5KL6lzTEy = hMZPR3UILm1CEsctD
	HOdeyqaGcIJZT7R36SCNl,Gcyx9fBhu7TZlI,d8vtlmWsq6fBbz7xiGHZ2n53 = [],0,0
	Waz2HurFjRX = ee8c0jzrTntGSUdRJm.getSetting('av.status.menusimages')
	o75oATcIy0LB9RJFQXzHvkNqb = Waz2HurFjRX!='STOP'
	if o75oATcIy0LB9RJFQXzHvkNqb:
		HlO6Fu72gpWERBnYob = WQvYkNg7SysPFLitlGEn6.path.join(zKdeknjoPhL9gN8v,JbpxsyQVXmSEYKM3vo847Ckh)
		try: ySeCiUazgRNTEGtOs5X = WQvYkNg7SysPFLitlGEn6.listdir(HlO6Fu72gpWERBnYob)
		except:
			if not WQvYkNg7SysPFLitlGEn6.path.exists(HlO6Fu72gpWERBnYob):
				try: WQvYkNg7SysPFLitlGEn6.makedirs(HlO6Fu72gpWERBnYob)
				except: pass
			ySeCiUazgRNTEGtOs5X = []
	AAiDtcXRJ7F = NLvhYox1qka6Mu3mZ7z('menu_item')
	for iyL9QC2g0j in VYkojDcNHPXi5KL6lzTEy:
		j4lHpxXvnF2VtwBb1T9PaJEm3 = iyL9QC2g0j['name']
		cclvGoDJW0eShO = iyL9QC2g0j['context_menu']
		RWpoJblvhCsdnGYxFPkMu0Ot = iyL9QC2g0j['plot']
		MALzmwDot2cB7RaJXpdVOql4GFh = iyL9QC2g0j['stars']
		acysH2W9N0BhXIvJPRM5t = iyL9QC2g0j['image']
		udRvjXt9cAfha5ZsBP3U = iyL9QC2g0j['type']
		GG4OqC6TJgXjQMLARUWlb2vI = iyL9QC2g0j['duration']
		xFCcejlr4s9530WpoAQu2my8DhKOX = iyL9QC2g0j['isFolder']
		SbCeHcDfsyraL3BxQTOoqVKWZ = iyL9QC2g0j['newpath']
		A3yVIMYEfoFir5zaw89cXTmO = mUWYiQ2jHICA8cD6LhPTn3wpB1XyK.ListItem(j4lHpxXvnF2VtwBb1T9PaJEm3)
		A3yVIMYEfoFir5zaw89cXTmO.addContextMenuItems(cclvGoDJW0eShO)
		WMkoD86dnqOrTAaBvtgR2PVj = False if o75oATcIy0LB9RJFQXzHvkNqb else True
		if acysH2W9N0BhXIvJPRM5t:
			A3yVIMYEfoFir5zaw89cXTmO.setArt({'icon':acysH2W9N0BhXIvJPRM5t,'thumb':acysH2W9N0BhXIvJPRM5t,'fanart':acysH2W9N0BhXIvJPRM5t,'banner':acysH2W9N0BhXIvJPRM5t,'clearart':acysH2W9N0BhXIvJPRM5t,'poster':acysH2W9N0BhXIvJPRM5t,'clearlogo':acysH2W9N0BhXIvJPRM5t,'landscape':acysH2W9N0BhXIvJPRM5t})
			WMkoD86dnqOrTAaBvtgR2PVj = False
		elif not WMkoD86dnqOrTAaBvtgR2PVj:
			WMkoD86dnqOrTAaBvtgR2PVj = True
			j4lHpxXvnF2VtwBb1T9PaJEm3 = XFr42BCdkuqpsmZw6NvG39gz7HSK0h(fEXMiAyG3ql4vKB,j4lHpxXvnF2VtwBb1T9PaJEm3)
			j4lHpxXvnF2VtwBb1T9PaJEm3 = vJRN3snSxMqBP1dpIGTQX8Yl(j4lHpxXvnF2VtwBb1T9PaJEm3)
			BcRaXlyxN9WqTK45EM68AsFnZhJo = j4lHpxXvnF2VtwBb1T9PaJEm3+'.png'
			KvolASP6iCTnWfsOQ = WQvYkNg7SysPFLitlGEn6.path.join(HlO6Fu72gpWERBnYob,BcRaXlyxN9WqTK45EM68AsFnZhJo)
			if BcRaXlyxN9WqTK45EM68AsFnZhJo in ySeCiUazgRNTEGtOs5X:
				A3yVIMYEfoFir5zaw89cXTmO.setArt({'icon':KvolASP6iCTnWfsOQ,'thumb':KvolASP6iCTnWfsOQ,'fanart':KvolASP6iCTnWfsOQ,'banner':KvolASP6iCTnWfsOQ,'clearart':KvolASP6iCTnWfsOQ,'poster':KvolASP6iCTnWfsOQ,'clearlogo':KvolASP6iCTnWfsOQ,'landscape':KvolASP6iCTnWfsOQ})
				WMkoD86dnqOrTAaBvtgR2PVj = False
			elif Gcyx9fBhu7TZlI<40 and d8vtlmWsq6fBbz7xiGHZ2n53<=3:
				try:
					gUcrITQWHL102h5tV = iW3Hrds1FefRTP4(AAiDtcXRJ7F,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,j4lHpxXvnF2VtwBb1T9PaJEm3,'menu_item','center',False,KvolASP6iCTnWfsOQ)
					A3yVIMYEfoFir5zaw89cXTmO.setArt({'icon':KvolASP6iCTnWfsOQ,'thumb':KvolASP6iCTnWfsOQ,'fanart':KvolASP6iCTnWfsOQ,'banner':KvolASP6iCTnWfsOQ,'clearart':KvolASP6iCTnWfsOQ,'poster':KvolASP6iCTnWfsOQ,'clearlogo':KvolASP6iCTnWfsOQ,'landscape':KvolASP6iCTnWfsOQ})
					Gcyx9fBhu7TZlI += 1
					WMkoD86dnqOrTAaBvtgR2PVj = False
					ySeCiUazgRNTEGtOs5X.append(BcRaXlyxN9WqTK45EM68AsFnZhJo)
					if Gcyx9fBhu7TZlI==5: OnsAxhdVjZF('إضافة الكتابة لصور القائمة','انتظار',HB5PvxRhwM=500)
				except: d8vtlmWsq6fBbz7xiGHZ2n53 += 1
		if WMkoD86dnqOrTAaBvtgR2PVj:
			A3yVIMYEfoFir5zaw89cXTmO.setArt({'icon':BU8LSZFzYdg,'thumb':BU8LSZFzYdg,'fanart':BU8LSZFzYdg,'banner':BU8LSZFzYdg,'clearart':BU8LSZFzYdg,'poster':BU8LSZFzYdg,'clearlogo':BU8LSZFzYdg,'landscape':BU8LSZFzYdg})
		if guSzmUCXDa1tQpY<20:
			if RWpoJblvhCsdnGYxFPkMu0Ot: A3yVIMYEfoFir5zaw89cXTmO.setInfo('video',{'Plot':RWpoJblvhCsdnGYxFPkMu0Ot,'PlotOutline':RWpoJblvhCsdnGYxFPkMu0Ot})
			if MALzmwDot2cB7RaJXpdVOql4GFh: A3yVIMYEfoFir5zaw89cXTmO.setInfo('video',{'Rating':MALzmwDot2cB7RaJXpdVOql4GFh})
			if not acysH2W9N0BhXIvJPRM5t:
				A3yVIMYEfoFir5zaw89cXTmO.setInfo('video',{'Title':j4lHpxXvnF2VtwBb1T9PaJEm3})
			if udRvjXt9cAfha5ZsBP3U=='video':
				A3yVIMYEfoFir5zaw89cXTmO.setInfo('video',{'mediatype':'tvshow'})
				if GG4OqC6TJgXjQMLARUWlb2vI: A3yVIMYEfoFir5zaw89cXTmO.setInfo('video',{'duration':GG4OqC6TJgXjQMLARUWlb2vI})
				A3yVIMYEfoFir5zaw89cXTmO.setProperty('IsPlayable','true')
		else:
			ZUNceGo12L5dHylp3a0knjCOKERb = A3yVIMYEfoFir5zaw89cXTmO.getVideoInfoTag()
			if MALzmwDot2cB7RaJXpdVOql4GFh: ZUNceGo12L5dHylp3a0knjCOKERb.setRating(float(MALzmwDot2cB7RaJXpdVOql4GFh))
			if not acysH2W9N0BhXIvJPRM5t:
				ZUNceGo12L5dHylp3a0knjCOKERb.setTitle(j4lHpxXvnF2VtwBb1T9PaJEm3)
			if udRvjXt9cAfha5ZsBP3U=='video':
				ZUNceGo12L5dHylp3a0knjCOKERb.setMediaType('tvshow')
				if GG4OqC6TJgXjQMLARUWlb2vI: ZUNceGo12L5dHylp3a0knjCOKERb.setDuration(GG4OqC6TJgXjQMLARUWlb2vI)
				A3yVIMYEfoFir5zaw89cXTmO.setProperty('IsPlayable','true')
		HOdeyqaGcIJZT7R36SCNl.append((SbCeHcDfsyraL3BxQTOoqVKWZ,A3yVIMYEfoFir5zaw89cXTmO,xFCcejlr4s9530WpoAQu2my8DhKOX))
	u6sYmx5Dtz.setContent(l95lLYCJweSnVHqzrstyPWcE,'tvshows')
	iMSYgPv0HkclwxC = u6sYmx5Dtz.addDirectoryItems(l95lLYCJweSnVHqzrstyPWcE,HOdeyqaGcIJZT7R36SCNl)
	u6sYmx5Dtz.endOfDirectory(l95lLYCJweSnVHqzrstyPWcE,YpiyX9QrtV7zUehHq0RKgdCLjW,k1ki6ahd2uPfOMjsGEmVobSeBpQT,U9NuzFjwZOfSAl7seTMB)
	return iMSYgPv0HkclwxC
def RLDCGt8kq3OVmnzgx1rbi2f7F(udRvjXt9cAfha5ZsBP3U,j4lHpxXvnF2VtwBb1T9PaJEm3,O9z5L3KtXqPEMepJQ0,JbpxsyQVXmSEYKM3vo847Ckh,acysH2W9N0BhXIvJPRM5t=hWGMqtBy4wuLaVcj,z5NBJ1tXibWlaTfhdo0FG=hWGMqtBy4wuLaVcj,s9ea72VfoygAOFRCWQTH3zmDuLPE=hWGMqtBy4wuLaVcj,kCaIufXo1F0TyL7gtcJV5bneijMWHv=hWGMqtBy4wuLaVcj,kFeSKZb8qiVd4GxwcAMHQolgU={}):
	j4lHpxXvnF2VtwBb1T9PaJEm3 = j4lHpxXvnF2VtwBb1T9PaJEm3.replace(y6eSQlZEV8uwKG5M3,hWGMqtBy4wuLaVcj).replace(NXMOzZjYsmS9pf,hWGMqtBy4wuLaVcj).replace('\t',hWGMqtBy4wuLaVcj)
	O9z5L3KtXqPEMepJQ0 = O9z5L3KtXqPEMepJQ0.replace(y6eSQlZEV8uwKG5M3,hWGMqtBy4wuLaVcj).replace(NXMOzZjYsmS9pf,hWGMqtBy4wuLaVcj).replace('\t',hWGMqtBy4wuLaVcj)
	if '_SCRIPT_' in j4lHpxXvnF2VtwBb1T9PaJEm3: bBER0HlPYh4ZXm6ILWw,j4lHpxXvnF2VtwBb1T9PaJEm3 = j4lHpxXvnF2VtwBb1T9PaJEm3.split('_SCRIPT_',1)
	else: bBER0HlPYh4ZXm6ILWw,j4lHpxXvnF2VtwBb1T9PaJEm3 = hWGMqtBy4wuLaVcj,j4lHpxXvnF2VtwBb1T9PaJEm3
	if bBER0HlPYh4ZXm6ILWw:
		XGVkCMzJbuYmxr9p1Hs85UjLOAQ6E7 = j4lHpxXvnF2VtwBb1T9PaJEm3
		if not XGVkCMzJbuYmxr9p1Hs85UjLOAQ6E7: XGVkCMzJbuYmxr9p1Hs85UjLOAQ6E7 = '....'
		elif XGVkCMzJbuYmxr9p1Hs85UjLOAQ6E7.count('_')>1: XGVkCMzJbuYmxr9p1Hs85UjLOAQ6E7 = XGVkCMzJbuYmxr9p1Hs85UjLOAQ6E7.split('_',2)[2]
		XGVkCMzJbuYmxr9p1Hs85UjLOAQ6E7 = XGVkCMzJbuYmxr9p1Hs85UjLOAQ6E7.replace(' ',hWGMqtBy4wuLaVcj)
		XGVkCMzJbuYmxr9p1Hs85UjLOAQ6E7 = XGVkCMzJbuYmxr9p1Hs85UjLOAQ6E7.replace('ـ',hWGMqtBy4wuLaVcj).replace('ة','ه').replace('ؤ','و')
		XGVkCMzJbuYmxr9p1Hs85UjLOAQ6E7 = XGVkCMzJbuYmxr9p1Hs85UjLOAQ6E7.replace('أ','ا').replace('إ','ا').replace('آ','ا')
		XGVkCMzJbuYmxr9p1Hs85UjLOAQ6E7 = XGVkCMzJbuYmxr9p1Hs85UjLOAQ6E7.replace('لأ','لا').replace('لإ','لا').replace('لآ','لا')
		XGVkCMzJbuYmxr9p1Hs85UjLOAQ6E7 = XGVkCMzJbuYmxr9p1Hs85UjLOAQ6E7.replace('َ',hWGMqtBy4wuLaVcj).replace('ً',hWGMqtBy4wuLaVcj).replace('ُ',hWGMqtBy4wuLaVcj).replace('ٌ',hWGMqtBy4wuLaVcj)
		XGVkCMzJbuYmxr9p1Hs85UjLOAQ6E7 = XGVkCMzJbuYmxr9p1Hs85UjLOAQ6E7.replace('ِ',hWGMqtBy4wuLaVcj).replace('ٍ',hWGMqtBy4wuLaVcj).replace('ْ',hWGMqtBy4wuLaVcj).replace('ّ',hWGMqtBy4wuLaVcj)
		XGVkCMzJbuYmxr9p1Hs85UjLOAQ6E7 = XGVkCMzJbuYmxr9p1Hs85UjLOAQ6E7.replace('|',hWGMqtBy4wuLaVcj).replace('~',hWGMqtBy4wuLaVcj)
		XGVkCMzJbuYmxr9p1Hs85UjLOAQ6E7 = XGVkCMzJbuYmxr9p1Hs85UjLOAQ6E7.replace('اون لاين',hWGMqtBy4wuLaVcj).replace('سيما لايت',hWGMqtBy4wuLaVcj)
		Pbtch0wlGrsfWIzjVxgu1qJAUX8 = ['العاب','خيال','البوم','الان','اطفال','حاليه','الغاز','صالح','الدين','مواليد','العالم','اعمال']
		if not any(m8dJpRgAhYBX7VMx in XGVkCMzJbuYmxr9p1Hs85UjLOAQ6E7 for m8dJpRgAhYBX7VMx in Pbtch0wlGrsfWIzjVxgu1qJAUX8): XGVkCMzJbuYmxr9p1Hs85UjLOAQ6E7 = XGVkCMzJbuYmxr9p1Hs85UjLOAQ6E7.replace('ال',hWGMqtBy4wuLaVcj)
		XGVkCMzJbuYmxr9p1Hs85UjLOAQ6E7 = XGVkCMzJbuYmxr9p1Hs85UjLOAQ6E7.replace('اخري','اخرى').replace('اجنبى','اجنبي').replace('عائليه','عائلي')
		XGVkCMzJbuYmxr9p1Hs85UjLOAQ6E7 = XGVkCMzJbuYmxr9p1Hs85UjLOAQ6E7.replace('اجنبيه','اجنبي').replace('عربيه','عربي').replace('رومانسيه','رومانسي')
		XGVkCMzJbuYmxr9p1Hs85UjLOAQ6E7 = XGVkCMzJbuYmxr9p1Hs85UjLOAQ6E7.replace('غربيه','غربي').replace('و مسلسلات','مسلسلات').replace('اغانى','اغاني')
		XGVkCMzJbuYmxr9p1Hs85UjLOAQ6E7 = XGVkCMzJbuYmxr9p1Hs85UjLOAQ6E7.replace('تاريخي','تاريخ').replace('خيال علمي','خيال').replace('موسيقيه','موسيقى')
		XGVkCMzJbuYmxr9p1Hs85UjLOAQ6E7 = XGVkCMzJbuYmxr9p1Hs85UjLOAQ6E7.replace('هندى','هندي').replace('هنديه','هندي').replace('وثائقيه','وثائقي')
		XGVkCMzJbuYmxr9p1Hs85UjLOAQ6E7 = XGVkCMzJbuYmxr9p1Hs85UjLOAQ6E7.replace('تليفزيونيه','تلفزيون').replace('تلفزيونيه','تلفزيون').replace('و كرتون','وكرتون')
		XGVkCMzJbuYmxr9p1Hs85UjLOAQ6E7 = XGVkCMzJbuYmxr9p1Hs85UjLOAQ6E7.replace('الحاليه','حاليه').replace('موسیقي','موسيقى').replace('الانمي','انمي')
		XGVkCMzJbuYmxr9p1Hs85UjLOAQ6E7 = XGVkCMzJbuYmxr9p1Hs85UjLOAQ6E7.replace('المسلسلات','مسلسلات').replace('البرامج','برامج').replace('كارتون','كرتون')
		XGVkCMzJbuYmxr9p1Hs85UjLOAQ6E7 = XGVkCMzJbuYmxr9p1Hs85UjLOAQ6E7.replace('حروب','حرب').replace('الاناشيد','اناشيد').replace('اسيويه','اسيوي')
		XGVkCMzJbuYmxr9p1Hs85UjLOAQ6E7 = XGVkCMzJbuYmxr9p1Hs85UjLOAQ6E7.replace('عربى','عربي').replace('تركى','تركي').replace('تركيه','تركي')
		XGVkCMzJbuYmxr9p1Hs85UjLOAQ6E7 = XGVkCMzJbuYmxr9p1Hs85UjLOAQ6E7.replace('رياضي','رياضة').replace('رياضه','رياضة').replace('اسيويه','اسيوي')
		XGVkCMzJbuYmxr9p1Hs85UjLOAQ6E7 = XGVkCMzJbuYmxr9p1Hs85UjLOAQ6E7.replace('كوميدى','كوميدي').replace('كوميديه','كوميدي').replace('انيمي','انمي')
		XGVkCMzJbuYmxr9p1Hs85UjLOAQ6E7 = XGVkCMzJbuYmxr9p1Hs85UjLOAQ6E7.replace('انيميشن','انميشن').replace('انمى','انميشن').replace('انمي','انميشن')
		XGVkCMzJbuYmxr9p1Hs85UjLOAQ6E7 = XGVkCMzJbuYmxr9p1Hs85UjLOAQ6E7.replace('انميشنشن','انميشن').replace('الانميشن','انميشن').replace('افلام مسلسلات','افلام ومسلسلات')
		XGVkCMzJbuYmxr9p1Hs85UjLOAQ6E7 = XGVkCMzJbuYmxr9p1Hs85UjLOAQ6E7.replace(FqcVAkh7WjIXHdDKf8nvuyRo,Mpsm2VF1OBnCRvK3qf6).strip(Mpsm2VF1OBnCRvK3qf6)
		bBER0HlPYh4ZXm6ILWw = '_LST_'+J72F0jRI6A(bBER0HlPYh4ZXm6ILWw)
		if XGVkCMzJbuYmxr9p1Hs85UjLOAQ6E7 not in list(FvkuXRitwj.keys()): FvkuXRitwj[XGVkCMzJbuYmxr9p1Hs85UjLOAQ6E7] = {}
		FvkuXRitwj[XGVkCMzJbuYmxr9p1Hs85UjLOAQ6E7][bBER0HlPYh4ZXm6ILWw] = [udRvjXt9cAfha5ZsBP3U,j4lHpxXvnF2VtwBb1T9PaJEm3,O9z5L3KtXqPEMepJQ0,JbpxsyQVXmSEYKM3vo847Ckh,acysH2W9N0BhXIvJPRM5t,z5NBJ1tXibWlaTfhdo0FG,s9ea72VfoygAOFRCWQTH3zmDuLPE,kCaIufXo1F0TyL7gtcJV5bneijMWHv,kFeSKZb8qiVd4GxwcAMHQolgU]
	vNRpDl1awktg7QP4m0KGqMTS2i.append([udRvjXt9cAfha5ZsBP3U,j4lHpxXvnF2VtwBb1T9PaJEm3,O9z5L3KtXqPEMepJQ0,JbpxsyQVXmSEYKM3vo847Ckh,acysH2W9N0BhXIvJPRM5t,z5NBJ1tXibWlaTfhdo0FG,s9ea72VfoygAOFRCWQTH3zmDuLPE,kCaIufXo1F0TyL7gtcJV5bneijMWHv,kFeSKZb8qiVd4GxwcAMHQolgU])
	return
def LNtIDdBA52P(aNsFC3Y6ITdjtD):
	if H4qZ2hwilNJYTmCFEQyaSs98cPM0gR: from html import unescape as _CXsNQJy1WVdiocb
	else:
		from HTMLParser import HTMLParser as yUbXYEPR8jmq7IxNGh
		_CXsNQJy1WVdiocb = yUbXYEPR8jmq7IxNGh().unescape
	if '&' in aNsFC3Y6ITdjtD and ';' in aNsFC3Y6ITdjtD:
		if VKiGj1LundAJQwEXcqgxC: aNsFC3Y6ITdjtD = aNsFC3Y6ITdjtD.decode(a7VXeDU82IfQEnPZAdiT)
		aNsFC3Y6ITdjtD = _CXsNQJy1WVdiocb(aNsFC3Y6ITdjtD)
		if VKiGj1LundAJQwEXcqgxC: aNsFC3Y6ITdjtD = aNsFC3Y6ITdjtD.encode(a7VXeDU82IfQEnPZAdiT)
	return aNsFC3Y6ITdjtD
def emr1Lf523Ti0OtcNgxP(aNsFC3Y6ITdjtD):
	if '\\u' in aNsFC3Y6ITdjtD:
		if VKiGj1LundAJQwEXcqgxC: aNsFC3Y6ITdjtD = aNsFC3Y6ITdjtD.decode('unicode_escape','ignore').encode(a7VXeDU82IfQEnPZAdiT)
		elif H4qZ2hwilNJYTmCFEQyaSs98cPM0gR: aNsFC3Y6ITdjtD = aNsFC3Y6ITdjtD.encode(a7VXeDU82IfQEnPZAdiT).decode('unicode_escape','ignore')
	return aNsFC3Y6ITdjtD
def u4HdnJLfyrebDC3Rj8tzkT0VhmQp(pdcS9Mh1q3eZjyTGX2UIw0VArO,iLNzmx7D4y,Hty3NjhEMqOsme4vlK,UhiIl3Qgd8e9SuqfT2CmV6sOAFJ,s9ea72VfoygAOFRCWQTH3zmDuLPE,jr7HeFnOEXGuhZz36iNJxqKkY9m2Cf,B0fiGmONbYkap,rrJxUWyeN3M8tDZOzGq,IXQ6LwHoiY0P12):
	cpzPHN32l0nb7FiXsYuIGZTrS = WQvYkNg7SysPFLitlGEn6.path.dirname(IXQ6LwHoiY0P12)
	if not WQvYkNg7SysPFLitlGEn6.path.exists(cpzPHN32l0nb7FiXsYuIGZTrS):
		try: WQvYkNg7SysPFLitlGEn6.makedirs(cpzPHN32l0nb7FiXsYuIGZTrS)
		except: pass
	O0UYtwAnM4eR = NLvhYox1qka6Mu3mZ7z(jr7HeFnOEXGuhZz36iNJxqKkY9m2Cf)
	gUcrITQWHL102h5tV = iW3Hrds1FefRTP4(O0UYtwAnM4eR,pdcS9Mh1q3eZjyTGX2UIw0VArO,iLNzmx7D4y,Hty3NjhEMqOsme4vlK,UhiIl3Qgd8e9SuqfT2CmV6sOAFJ,s9ea72VfoygAOFRCWQTH3zmDuLPE,jr7HeFnOEXGuhZz36iNJxqKkY9m2Cf,B0fiGmONbYkap,rrJxUWyeN3M8tDZOzGq,IXQ6LwHoiY0P12)
	return gUcrITQWHL102h5tV
def NLvhYox1qka6Mu3mZ7z(jr7HeFnOEXGuhZz36iNJxqKkY9m2Cf):
	tsoAWghKk7yaf4QPH6LGCiEZblNunj = 5
	ddnpt9uqC8WgUDw7FoG = 20
	SrNIYmnFDAZoMp18kVcCs4 = 20
	y6NqeYpZl2Hx93V5nfz = 0
	nFLNzJlmi5Zv = 'center'
	yNCOFolgHpx5zj3PKQk = 0
	ddDXg8TljvKLPAf5qe70iszU = 19
	LsVaoyTjmHrJU4Cx8zpKePuSQtNlgR = 30
	WiUHYKTLo35FVZXDfEQ0MItrz1 = 8
	a6aseP8zgK2ixyXCc = True
	lZpRg5qH2ceBk = 375
	ncOKbPtgWHFiEX8Y2 = 410
	VZsRtz6wgd708bn9 = 50
	eCThSD37M1t2uLPJ = 280
	xlusLndJIH = 28
	kvmJ619age53V = 5
	CmBUfHgYNbx0yopX = 0
	KZXDy49T5PIcrhv = 31
	DCxXT8GtLf0jhAKpQFsPI7gY = [36,32,28]
	from PIL import ImageDraw as hSuRrpxJ1blOyYCDEmFGU,ImageFont as nwbQDs5xKHFLUk4jmtzZo,Image as HlYKqcxN58kV6EAbpmoPdRO4Ua
	if 'notification' in jr7HeFnOEXGuhZz36iNJxqKkY9m2Cf:
		if jr7HeFnOEXGuhZz36iNJxqKkY9m2Cf=='notification_regular':
			kkNiBf9SvWQZj51cmnLd7HwXreyl6u = 117
			nFLNzJlmi5Zv = 'left'
			a6aseP8zgK2ixyXCc = False
		elif jr7HeFnOEXGuhZz36iNJxqKkY9m2Cf=='notification_auto':
			kkNiBf9SvWQZj51cmnLd7HwXreyl6u = 'UPPER'
			nFLNzJlmi5Zv = 'right'
			y6NqeYpZl2Hx93V5nfz = 10
		ffjTFqhMbpwGX4WKYPr87CVBORn9 = 720
		DCxXT8GtLf0jhAKpQFsPI7gY = [33,33,33]
		SrNIYmnFDAZoMp18kVcCs4 = 20
		ddnpt9uqC8WgUDw7FoG = 0
		LsVaoyTjmHrJU4Cx8zpKePuSQtNlgR = 20
		ddDXg8TljvKLPAf5qe70iszU = 35
	elif jr7HeFnOEXGuhZz36iNJxqKkY9m2Cf=='menu_item':
		DCxXT8GtLf0jhAKpQFsPI7gY,ffjTFqhMbpwGX4WKYPr87CVBORn9,kkNiBf9SvWQZj51cmnLd7HwXreyl6u = [28,28,28],200,250
		yNCOFolgHpx5zj3PKQk,LsVaoyTjmHrJU4Cx8zpKePuSQtNlgR,ddDXg8TljvKLPAf5qe70iszU, = 0,-12,-30
		ddnpt9uqC8WgUDw7FoG = 0
		UBQV6mq4jZg = HlYKqcxN58kV6EAbpmoPdRO4Ua.open(BU8LSZFzYdg)
		iRETCyPkcQuxUsZ = HlYKqcxN58kV6EAbpmoPdRO4Ua.new('RGBA',(ffjTFqhMbpwGX4WKYPr87CVBORn9,kkNiBf9SvWQZj51cmnLd7HwXreyl6u),(255,0,0,255))
	elif jr7HeFnOEXGuhZz36iNJxqKkY9m2Cf=='confirm_smallfont': DCxXT8GtLf0jhAKpQFsPI7gY,kkNiBf9SvWQZj51cmnLd7HwXreyl6u,ffjTFqhMbpwGX4WKYPr87CVBORn9 = [28,24,20],500,900
	elif jr7HeFnOEXGuhZz36iNJxqKkY9m2Cf=='confirm_mediumfont': DCxXT8GtLf0jhAKpQFsPI7gY,kkNiBf9SvWQZj51cmnLd7HwXreyl6u,ffjTFqhMbpwGX4WKYPr87CVBORn9 = [32,28,24],500,900
	elif jr7HeFnOEXGuhZz36iNJxqKkY9m2Cf=='confirm_bigfont': DCxXT8GtLf0jhAKpQFsPI7gY,kkNiBf9SvWQZj51cmnLd7HwXreyl6u,ffjTFqhMbpwGX4WKYPr87CVBORn9 = [36,32,28],500,900
	elif jr7HeFnOEXGuhZz36iNJxqKkY9m2Cf=='textview_bigfont': kkNiBf9SvWQZj51cmnLd7HwXreyl6u,ffjTFqhMbpwGX4WKYPr87CVBORn9 = 740,1270
	elif jr7HeFnOEXGuhZz36iNJxqKkY9m2Cf=='textview_bigfont_long': kkNiBf9SvWQZj51cmnLd7HwXreyl6u,ffjTFqhMbpwGX4WKYPr87CVBORn9 = 'UPPER',1270
	elif jr7HeFnOEXGuhZz36iNJxqKkY9m2Cf=='textview_smallfont': DCxXT8GtLf0jhAKpQFsPI7gY,kkNiBf9SvWQZj51cmnLd7HwXreyl6u,ffjTFqhMbpwGX4WKYPr87CVBORn9 = [28,23,18],740,1270
	elif jr7HeFnOEXGuhZz36iNJxqKkY9m2Cf=='textview_smallfont_long': DCxXT8GtLf0jhAKpQFsPI7gY,kkNiBf9SvWQZj51cmnLd7HwXreyl6u,ffjTFqhMbpwGX4WKYPr87CVBORn9 = [28,23,18],'UPPER',1270
	sz0VjCMl6DLFQ2gBc5r,vvJ8gzpykYmS390LhauiUoA1nbXP,GrWhFqsB5w = DCxXT8GtLf0jhAKpQFsPI7gY
	cwilYrGk78Wn9sj = nwbQDs5xKHFLUk4jmtzZo.truetype(FhC0YikZjr8c74tNubWIToEfBl,size=sz0VjCMl6DLFQ2gBc5r)
	EVXlv3QaIgpYq6NodZfukiF = nwbQDs5xKHFLUk4jmtzZo.truetype(FhC0YikZjr8c74tNubWIToEfBl,size=vvJ8gzpykYmS390LhauiUoA1nbXP)
	KRTfZGEdSPJeBYvg5IUWVMhL93Qb = nwbQDs5xKHFLUk4jmtzZo.truetype(FhC0YikZjr8c74tNubWIToEfBl,size=GrWhFqsB5w)
	Kvh2o1QaUwlcIqHt0 = ffjTFqhMbpwGX4WKYPr87CVBORn9-LsVaoyTjmHrJU4Cx8zpKePuSQtNlgR*2
	UFHogqet0WxfB3wrID9hE = HlYKqcxN58kV6EAbpmoPdRO4Ua.new('RGBA',(Kvh2o1QaUwlcIqHt0,100),(255,255,255,0))
	xvkU8AyhpuKGCM3sir6 = hSuRrpxJ1blOyYCDEmFGU.Draw(UFHogqet0WxfB3wrID9hE)
	nn8eSyTcEpXR72PxHdk,otA85zkf1S = xvkU8AyhpuKGCM3sir6.textsize('HHH BBB 888 000',font=cwilYrGk78Wn9sj)
	mdKOn5yZogX9MjTiD4r,AN2Ge4z7YLQv5bSJpXIxTW3tok = xvkU8AyhpuKGCM3sir6.textsize('HHH BBB 888 000',font=EVXlv3QaIgpYq6NodZfukiF)
	iaTeZNFJxsmkP8QRHGWVEICdO45h = {'delete_harakat':False,'support_ligatures':True,'ARABIC LIGATURE ALLAH':False}
	from arabic_reshaper import ArabicReshaper as qKbRfXNLh9WA1dTFYVa687DI
	rrztHqeP65s1BbXEOT = qKbRfXNLh9WA1dTFYVa687DI(configuration=iaTeZNFJxsmkP8QRHGWVEICdO45h)
	O0UYtwAnM4eR = {}
	GBqjmLb4X7If8F = locals()
	for W6kuMbXBPcHdlyNGxeZ3T in GBqjmLb4X7If8F: O0UYtwAnM4eR[W6kuMbXBPcHdlyNGxeZ3T] = GBqjmLb4X7If8F[W6kuMbXBPcHdlyNGxeZ3T]
	return O0UYtwAnM4eR
def iW3Hrds1FefRTP4(O0UYtwAnM4eR,pdcS9Mh1q3eZjyTGX2UIw0VArO,iLNzmx7D4y,Hty3NjhEMqOsme4vlK,UhiIl3Qgd8e9SuqfT2CmV6sOAFJ,s9ea72VfoygAOFRCWQTH3zmDuLPE,jr7HeFnOEXGuhZz36iNJxqKkY9m2Cf,B0fiGmONbYkap,rrJxUWyeN3M8tDZOzGq,IXQ6LwHoiY0P12):
	for W6kuMbXBPcHdlyNGxeZ3T in O0UYtwAnM4eR: globals()[W6kuMbXBPcHdlyNGxeZ3T] = O0UYtwAnM4eR[W6kuMbXBPcHdlyNGxeZ3T]
	global xlusLndJIH,kvmJ619age53V
	if jr7HeFnOEXGuhZz36iNJxqKkY9m2Cf!='menu_item':
		ECyN4WlSmv9wVHGcMa = ee8c0jzrTntGSUdRJm.getSetting('av.language.translate')
		if ECyN4WlSmv9wVHGcMa:
			if pdcS9Mh1q3eZjyTGX2UIw0VArO=='نعم  Yes': pdcS9Mh1q3eZjyTGX2UIw0VArO = 'Yes'
			elif pdcS9Mh1q3eZjyTGX2UIw0VArO=='كلا  No': pdcS9Mh1q3eZjyTGX2UIw0VArO = 'No'
			if iLNzmx7D4y=='نعم  Yes': iLNzmx7D4y = 'Yes'
			elif iLNzmx7D4y=='كلا  No': iLNzmx7D4y = 'No'
			if Hty3NjhEMqOsme4vlK=='نعم  Yes': Hty3NjhEMqOsme4vlK = 'Yes'
			elif Hty3NjhEMqOsme4vlK=='كلا  No': Hty3NjhEMqOsme4vlK = 'No'
			x4xVJLXyIQbSqlHWem = aMwjFti8rlX([pdcS9Mh1q3eZjyTGX2UIw0VArO,iLNzmx7D4y,Hty3NjhEMqOsme4vlK,UhiIl3Qgd8e9SuqfT2CmV6sOAFJ,s9ea72VfoygAOFRCWQTH3zmDuLPE])
			if x4xVJLXyIQbSqlHWem: pdcS9Mh1q3eZjyTGX2UIw0VArO,iLNzmx7D4y,Hty3NjhEMqOsme4vlK,UhiIl3Qgd8e9SuqfT2CmV6sOAFJ,s9ea72VfoygAOFRCWQTH3zmDuLPE = x4xVJLXyIQbSqlHWem
	if VKiGj1LundAJQwEXcqgxC:
		s9ea72VfoygAOFRCWQTH3zmDuLPE = s9ea72VfoygAOFRCWQTH3zmDuLPE.decode(a7VXeDU82IfQEnPZAdiT)
		UhiIl3Qgd8e9SuqfT2CmV6sOAFJ = UhiIl3Qgd8e9SuqfT2CmV6sOAFJ.decode(a7VXeDU82IfQEnPZAdiT)
		pdcS9Mh1q3eZjyTGX2UIw0VArO = pdcS9Mh1q3eZjyTGX2UIw0VArO.decode(a7VXeDU82IfQEnPZAdiT)
		iLNzmx7D4y = iLNzmx7D4y.decode(a7VXeDU82IfQEnPZAdiT)
		Hty3NjhEMqOsme4vlK = Hty3NjhEMqOsme4vlK.decode(a7VXeDU82IfQEnPZAdiT)
	vokT9lhWFECPcJX = UhiIl3Qgd8e9SuqfT2CmV6sOAFJ.count(NXMOzZjYsmS9pf)+1
	QJPa9j7WFzAxfvRb1neqEoHS = ddnpt9uqC8WgUDw7FoG+vokT9lhWFECPcJX*(otA85zkf1S+y6NqeYpZl2Hx93V5nfz)-y6NqeYpZl2Hx93V5nfz
	if s9ea72VfoygAOFRCWQTH3zmDuLPE:
		YF2jyRopl3WqcH = AN2Ge4z7YLQv5bSJpXIxTW3tok+WiUHYKTLo35FVZXDfEQ0MItrz1
		p5umJWPYFBxe4Tqb31 = rrztHqeP65s1BbXEOT.reshape(s9ea72VfoygAOFRCWQTH3zmDuLPE)
		if a6aseP8zgK2ixyXCc:
			k4FdmJARtfI0YlXahzKEP9VsN3C = iST1DXRgoLwf3r(xvkU8AyhpuKGCM3sir6,EVXlv3QaIgpYq6NodZfukiF,p5umJWPYFBxe4Tqb31,vvJ8gzpykYmS390LhauiUoA1nbXP,Kvh2o1QaUwlcIqHt0,YF2jyRopl3WqcH)
			Zhzs4QruEjab9qSUWTv = NP2yGmHiv53Oafb1Kq(k4FdmJARtfI0YlXahzKEP9VsN3C)
			SS18FeVCKpQkRX7 = Zhzs4QruEjab9qSUWTv.count(NXMOzZjYsmS9pf)+1
			voLnarYMezVElc7Sm4h = ddDXg8TljvKLPAf5qe70iszU+SS18FeVCKpQkRX7*YF2jyRopl3WqcH-WiUHYKTLo35FVZXDfEQ0MItrz1
		else:
			voLnarYMezVElc7Sm4h = ddDXg8TljvKLPAf5qe70iszU+AN2Ge4z7YLQv5bSJpXIxTW3tok
			Zhzs4QruEjab9qSUWTv = p5umJWPYFBxe4Tqb31.split(NXMOzZjYsmS9pf)[0]
			k4FdmJARtfI0YlXahzKEP9VsN3C = p5umJWPYFBxe4Tqb31.split(NXMOzZjYsmS9pf)[0]
	else: voLnarYMezVElc7Sm4h = ddDXg8TljvKLPAf5qe70iszU
	YtFBiKZ35OMwED67Xol0xURh = CmBUfHgYNbx0yopX+KZXDy49T5PIcrhv
	if rrJxUWyeN3M8tDZOzGq:
		nyCMdrSHvPIohYFbTf7i6Z = ncOKbPtgWHFiEX8Y2-lZpRg5qH2ceBk
		YtFBiKZ35OMwED67Xol0xURh += nyCMdrSHvPIohYFbTf7i6Z
	else: nyCMdrSHvPIohYFbTf7i6Z = 0
	if pdcS9Mh1q3eZjyTGX2UIw0VArO or iLNzmx7D4y or Hty3NjhEMqOsme4vlK: YtFBiKZ35OMwED67Xol0xURh += VZsRtz6wgd708bn9
	gUcrITQWHL102h5tV = kkNiBf9SvWQZj51cmnLd7HwXreyl6u if kkNiBf9SvWQZj51cmnLd7HwXreyl6u!='UPPER' else QJPa9j7WFzAxfvRb1neqEoHS+voLnarYMezVElc7Sm4h+YtFBiKZ35OMwED67Xol0xURh
	UFHogqet0WxfB3wrID9hE = HlYKqcxN58kV6EAbpmoPdRO4Ua.new('RGBA',(ffjTFqhMbpwGX4WKYPr87CVBORn9,gUcrITQWHL102h5tV),(255,255,255,0))
	Ekv4N3wZzHhyFu1Ox = hSuRrpxJ1blOyYCDEmFGU.Draw(UFHogqet0WxfB3wrID9hE)
	Jwp75yLbFW2qmsnDQCzgovlUt = gUcrITQWHL102h5tV-QJPa9j7WFzAxfvRb1neqEoHS-YtFBiKZ35OMwED67Xol0xURh-ddDXg8TljvKLPAf5qe70iszU
	if not iLNzmx7D4y and pdcS9Mh1q3eZjyTGX2UIw0VArO and Hty3NjhEMqOsme4vlK:
		xlusLndJIH += 105
		kvmJ619age53V -= 110
	import bidi.algorithm as YpaQHwrJP6qInXKZ7
	if UhiIl3Qgd8e9SuqfT2CmV6sOAFJ:
		mfYakXPy3h = ddnpt9uqC8WgUDw7FoG
		UhiIl3Qgd8e9SuqfT2CmV6sOAFJ = YpaQHwrJP6qInXKZ7.get_display(rrztHqeP65s1BbXEOT.reshape(UhiIl3Qgd8e9SuqfT2CmV6sOAFJ))
		KgUCchf0AS4luxk1zOrm2 = UhiIl3Qgd8e9SuqfT2CmV6sOAFJ.splitlines()
		for VDvfJ2uLMsg1xjcN5wGkzlQi in KgUCchf0AS4luxk1zOrm2:
			if VDvfJ2uLMsg1xjcN5wGkzlQi:
				jzghiXuPEJ,PHsFqfxR2p9a7mNYc = Ekv4N3wZzHhyFu1Ox.textsize(VDvfJ2uLMsg1xjcN5wGkzlQi,font=cwilYrGk78Wn9sj)
				if nFLNzJlmi5Zv=='center': EbtTA9e2nUv0VjYMHBdcwmDJS7Z8NR = tsoAWghKk7yaf4QPH6LGCiEZblNunj+(ffjTFqhMbpwGX4WKYPr87CVBORn9-jzghiXuPEJ)/2
				elif nFLNzJlmi5Zv=='right': EbtTA9e2nUv0VjYMHBdcwmDJS7Z8NR = tsoAWghKk7yaf4QPH6LGCiEZblNunj+ffjTFqhMbpwGX4WKYPr87CVBORn9-jzghiXuPEJ-SrNIYmnFDAZoMp18kVcCs4
				elif nFLNzJlmi5Zv=='left': EbtTA9e2nUv0VjYMHBdcwmDJS7Z8NR = tsoAWghKk7yaf4QPH6LGCiEZblNunj+SrNIYmnFDAZoMp18kVcCs4
				Ekv4N3wZzHhyFu1Ox.text((EbtTA9e2nUv0VjYMHBdcwmDJS7Z8NR,mfYakXPy3h),VDvfJ2uLMsg1xjcN5wGkzlQi,font=cwilYrGk78Wn9sj,fill='yellow')
			mfYakXPy3h += sz0VjCMl6DLFQ2gBc5r+y6NqeYpZl2Hx93V5nfz
	if pdcS9Mh1q3eZjyTGX2UIw0VArO or iLNzmx7D4y or Hty3NjhEMqOsme4vlK:
		GLgDckb4JIOR = QJPa9j7WFzAxfvRb1neqEoHS+Jwp75yLbFW2qmsnDQCzgovlUt+ddDXg8TljvKLPAf5qe70iszU+nyCMdrSHvPIohYFbTf7i6Z+CmBUfHgYNbx0yopX
		if pdcS9Mh1q3eZjyTGX2UIw0VArO:
			pdcS9Mh1q3eZjyTGX2UIw0VArO = YpaQHwrJP6qInXKZ7.get_display(rrztHqeP65s1BbXEOT.reshape(pdcS9Mh1q3eZjyTGX2UIw0VArO))
			EFkswofg98UnBPOelYMhTp,BB4cXEnhLoOgl2bjC7yGQkwsMiK = Ekv4N3wZzHhyFu1Ox.textsize(pdcS9Mh1q3eZjyTGX2UIw0VArO,font=KRTfZGEdSPJeBYvg5IUWVMhL93Qb)
			zNcsByZkp8dgxqP7QXfi01thU = xlusLndJIH+0*(kvmJ619age53V+eCThSD37M1t2uLPJ)+(eCThSD37M1t2uLPJ-EFkswofg98UnBPOelYMhTp)/2
			Ekv4N3wZzHhyFu1Ox.text((zNcsByZkp8dgxqP7QXfi01thU,GLgDckb4JIOR),pdcS9Mh1q3eZjyTGX2UIw0VArO,font=KRTfZGEdSPJeBYvg5IUWVMhL93Qb,fill='yellow')
		if iLNzmx7D4y:
			iLNzmx7D4y = YpaQHwrJP6qInXKZ7.get_display(rrztHqeP65s1BbXEOT.reshape(iLNzmx7D4y))
			O7OadIEoeDXZzyUs,noe3hjH4XQ1Gvp = Ekv4N3wZzHhyFu1Ox.textsize(iLNzmx7D4y,font=KRTfZGEdSPJeBYvg5IUWVMhL93Qb)
			Q6DG30bX7SI4id = xlusLndJIH+1*(kvmJ619age53V+eCThSD37M1t2uLPJ)+(eCThSD37M1t2uLPJ-O7OadIEoeDXZzyUs)/2
			Ekv4N3wZzHhyFu1Ox.text((Q6DG30bX7SI4id,GLgDckb4JIOR),iLNzmx7D4y,font=KRTfZGEdSPJeBYvg5IUWVMhL93Qb,fill='yellow')
		if Hty3NjhEMqOsme4vlK:
			Hty3NjhEMqOsme4vlK = YpaQHwrJP6qInXKZ7.get_display(rrztHqeP65s1BbXEOT.reshape(Hty3NjhEMqOsme4vlK))
			MEHLsqnWfG,AocwT7ECLr2WtJ = Ekv4N3wZzHhyFu1Ox.textsize(Hty3NjhEMqOsme4vlK,font=KRTfZGEdSPJeBYvg5IUWVMhL93Qb)
			soXu31rcV0PaU = xlusLndJIH+2*(kvmJ619age53V+eCThSD37M1t2uLPJ)+(eCThSD37M1t2uLPJ-MEHLsqnWfG)/2
			Ekv4N3wZzHhyFu1Ox.text((soXu31rcV0PaU,GLgDckb4JIOR),Hty3NjhEMqOsme4vlK,font=KRTfZGEdSPJeBYvg5IUWVMhL93Qb,fill='yellow')
	if s9ea72VfoygAOFRCWQTH3zmDuLPE:
		gRkSXLGmIrui89e,YYKBztwxmQ9bI36spWuE2 = [],[]
		k4FdmJARtfI0YlXahzKEP9VsN3C = vz5XScnI3LtefGyOP(k4FdmJARtfI0YlXahzKEP9VsN3C)
		MdYXerR8fbc6sDFKIVOuQ = k4FdmJARtfI0YlXahzKEP9VsN3C.split('_sss__newline_')
		for IbQvCHKB3gilVZ in MdYXerR8fbc6sDFKIVOuQ:
			yVlXduZhqAkmSi9FQe = B0fiGmONbYkap
			if   '_sss__lineleft_' in IbQvCHKB3gilVZ: yVlXduZhqAkmSi9FQe = 'left'
			elif '_sss__lineright_' in IbQvCHKB3gilVZ: yVlXduZhqAkmSi9FQe = 'right'
			elif '_sss__linecenter_' in IbQvCHKB3gilVZ: yVlXduZhqAkmSi9FQe = 'center'
			ddewsQZtEc029izlHquv = IbQvCHKB3gilVZ
			cKeW8znJDNE3o = trdVA0JvFaD.findall('_sss__.*?_',IbQvCHKB3gilVZ,trdVA0JvFaD.DOTALL)
			for zkKdPD8bcJ0XMfhFyWjtS4U9 in cKeW8znJDNE3o: ddewsQZtEc029izlHquv = ddewsQZtEc029izlHquv.replace(zkKdPD8bcJ0XMfhFyWjtS4U9,hWGMqtBy4wuLaVcj)
			if ddewsQZtEc029izlHquv==hWGMqtBy4wuLaVcj: jzghiXuPEJ,PHsFqfxR2p9a7mNYc = 0,YF2jyRopl3WqcH
			else: jzghiXuPEJ,PHsFqfxR2p9a7mNYc = Ekv4N3wZzHhyFu1Ox.textsize(ddewsQZtEc029izlHquv,font=EVXlv3QaIgpYq6NodZfukiF)
			if   yVlXduZhqAkmSi9FQe=='left': Z6awy1fuIUq9XPSCn = yNCOFolgHpx5zj3PKQk+LsVaoyTjmHrJU4Cx8zpKePuSQtNlgR
			elif yVlXduZhqAkmSi9FQe=='right': Z6awy1fuIUq9XPSCn = yNCOFolgHpx5zj3PKQk+LsVaoyTjmHrJU4Cx8zpKePuSQtNlgR+Kvh2o1QaUwlcIqHt0-jzghiXuPEJ
			elif yVlXduZhqAkmSi9FQe=='center': Z6awy1fuIUq9XPSCn = yNCOFolgHpx5zj3PKQk+LsVaoyTjmHrJU4Cx8zpKePuSQtNlgR+(Kvh2o1QaUwlcIqHt0-jzghiXuPEJ)/2
			if Z6awy1fuIUq9XPSCn<LsVaoyTjmHrJU4Cx8zpKePuSQtNlgR: Z6awy1fuIUq9XPSCn = yNCOFolgHpx5zj3PKQk+LsVaoyTjmHrJU4Cx8zpKePuSQtNlgR
			gRkSXLGmIrui89e.append(Z6awy1fuIUq9XPSCn)
			YYKBztwxmQ9bI36spWuE2.append(jzghiXuPEJ)
		Z6awy1fuIUq9XPSCn = gRkSXLGmIrui89e[0]
		tGdZba2NTLeHWj4YxkKFCs08pJ = k4FdmJARtfI0YlXahzKEP9VsN3C.split('_sss_')
		dNh1ePZFa4Y6CD8SRG2AfBTq0OUz = (255,255,255,255)
		lBoYtPJ3TZ86vGQfi7FbxSIcwA = dNh1ePZFa4Y6CD8SRG2AfBTq0OUz
		G7e89RCbk6cyq5TMuwKp0P,xfzlqrOakipX = 0,0
		Y80LRmtiSnZz5dxj6XIFVHyP = False
		EVbFATw7jC85nLPKiZlBtDgp = 0
		WXHBrZ67ds2uaJCEtcgflxS3nwF = QJPa9j7WFzAxfvRb1neqEoHS+ddDXg8TljvKLPAf5qe70iszU/2
		if voLnarYMezVElc7Sm4h<(Jwp75yLbFW2qmsnDQCzgovlUt+ddDXg8TljvKLPAf5qe70iszU):
			OGtaiSjPs2gFDE4vQfw = (Jwp75yLbFW2qmsnDQCzgovlUt+ddDXg8TljvKLPAf5qe70iszU-voLnarYMezVElc7Sm4h)/2
			WXHBrZ67ds2uaJCEtcgflxS3nwF = QJPa9j7WFzAxfvRb1neqEoHS+ddDXg8TljvKLPAf5qe70iszU+OGtaiSjPs2gFDE4vQfw-AN2Ge4z7YLQv5bSJpXIxTW3tok/2
		for VDvfJ2uLMsg1xjcN5wGkzlQi in tGdZba2NTLeHWj4YxkKFCs08pJ:
			if not VDvfJ2uLMsg1xjcN5wGkzlQi or (VDvfJ2uLMsg1xjcN5wGkzlQi and ord(VDvfJ2uLMsg1xjcN5wGkzlQi[0])==65279): continue
			xke1gSlQHq45aCWjvLzMRni9 = VDvfJ2uLMsg1xjcN5wGkzlQi.split('_newline_',1)
			Z8myTD6GgaS = VDvfJ2uLMsg1xjcN5wGkzlQi.split('_newcolor',1)
			Q4Q81aRyLxMr = VDvfJ2uLMsg1xjcN5wGkzlQi.split('_endcolor_',1)
			fmRuhqFAew5 = VDvfJ2uLMsg1xjcN5wGkzlQi.split('_linertl_',1)
			DgkWNjx6YvCrbq = VDvfJ2uLMsg1xjcN5wGkzlQi.split('_lineleft_',1)
			Eb61MZpQkIufqGjwK5oHXReYBrd3cD = VDvfJ2uLMsg1xjcN5wGkzlQi.split('_lineright_',1)
			eqwEoWVFkPT1md5bS0 = VDvfJ2uLMsg1xjcN5wGkzlQi.split('_linecenter_',1)
			if len(xke1gSlQHq45aCWjvLzMRni9)>1:
				EVbFATw7jC85nLPKiZlBtDgp += 1
				VDvfJ2uLMsg1xjcN5wGkzlQi = xke1gSlQHq45aCWjvLzMRni9[1]
				G7e89RCbk6cyq5TMuwKp0P = 0
				Z6awy1fuIUq9XPSCn = gRkSXLGmIrui89e[EVbFATw7jC85nLPKiZlBtDgp]
				xfzlqrOakipX += YF2jyRopl3WqcH
				Y80LRmtiSnZz5dxj6XIFVHyP = False
			elif len(Z8myTD6GgaS)>1:
				VDvfJ2uLMsg1xjcN5wGkzlQi = Z8myTD6GgaS[1]
				lBoYtPJ3TZ86vGQfi7FbxSIcwA = VDvfJ2uLMsg1xjcN5wGkzlQi[0:8]
				lBoYtPJ3TZ86vGQfi7FbxSIcwA = '#'+lBoYtPJ3TZ86vGQfi7FbxSIcwA[2:]
				VDvfJ2uLMsg1xjcN5wGkzlQi = VDvfJ2uLMsg1xjcN5wGkzlQi[9:]
			elif len(Q4Q81aRyLxMr)>1:
				VDvfJ2uLMsg1xjcN5wGkzlQi = Q4Q81aRyLxMr[1]
				lBoYtPJ3TZ86vGQfi7FbxSIcwA = dNh1ePZFa4Y6CD8SRG2AfBTq0OUz
			elif len(fmRuhqFAew5)>1:
				VDvfJ2uLMsg1xjcN5wGkzlQi = fmRuhqFAew5[1]
				Y80LRmtiSnZz5dxj6XIFVHyP = True
				G7e89RCbk6cyq5TMuwKp0P = YYKBztwxmQ9bI36spWuE2[EVbFATw7jC85nLPKiZlBtDgp]
			elif len(DgkWNjx6YvCrbq)>1: VDvfJ2uLMsg1xjcN5wGkzlQi = DgkWNjx6YvCrbq[1]
			elif len(Eb61MZpQkIufqGjwK5oHXReYBrd3cD)>1: VDvfJ2uLMsg1xjcN5wGkzlQi = Eb61MZpQkIufqGjwK5oHXReYBrd3cD[1]
			elif len(eqwEoWVFkPT1md5bS0)>1: VDvfJ2uLMsg1xjcN5wGkzlQi = eqwEoWVFkPT1md5bS0[1]
			if VDvfJ2uLMsg1xjcN5wGkzlQi:
				njB2EW5O19ZyNLHS7RolG0v6 = WXHBrZ67ds2uaJCEtcgflxS3nwF+xfzlqrOakipX
				VDvfJ2uLMsg1xjcN5wGkzlQi = YpaQHwrJP6qInXKZ7.get_display(VDvfJ2uLMsg1xjcN5wGkzlQi)
				jzghiXuPEJ,PHsFqfxR2p9a7mNYc = Ekv4N3wZzHhyFu1Ox.textsize(VDvfJ2uLMsg1xjcN5wGkzlQi,font=EVXlv3QaIgpYq6NodZfukiF)
				if Y80LRmtiSnZz5dxj6XIFVHyP: G7e89RCbk6cyq5TMuwKp0P -= jzghiXuPEJ
				EjP2s8NydXeWYp3lqw7B4Rugr = Z6awy1fuIUq9XPSCn+G7e89RCbk6cyq5TMuwKp0P
				Ekv4N3wZzHhyFu1Ox.text((EjP2s8NydXeWYp3lqw7B4Rugr,njB2EW5O19ZyNLHS7RolG0v6),VDvfJ2uLMsg1xjcN5wGkzlQi,font=EVXlv3QaIgpYq6NodZfukiF,fill=lBoYtPJ3TZ86vGQfi7FbxSIcwA)
				if jr7HeFnOEXGuhZz36iNJxqKkY9m2Cf=='menu_item': Ekv4N3wZzHhyFu1Ox.text((EjP2s8NydXeWYp3lqw7B4Rugr+1,njB2EW5O19ZyNLHS7RolG0v6+1),VDvfJ2uLMsg1xjcN5wGkzlQi,font=EVXlv3QaIgpYq6NodZfukiF,fill=lBoYtPJ3TZ86vGQfi7FbxSIcwA)
				if not Y80LRmtiSnZz5dxj6XIFVHyP: G7e89RCbk6cyq5TMuwKp0P += jzghiXuPEJ
				if njB2EW5O19ZyNLHS7RolG0v6>Jwp75yLbFW2qmsnDQCzgovlUt+YF2jyRopl3WqcH: break
	if jr7HeFnOEXGuhZz36iNJxqKkY9m2Cf=='menu_item':
		VVdkitm70ucB6gSb3s2APnlavXfZ54 = UBQV6mq4jZg.copy()
		HB5PvxRhwM.sleep(0.05)
		VVdkitm70ucB6gSb3s2APnlavXfZ54.paste(iRETCyPkcQuxUsZ,(0,0),mask=UFHogqet0WxfB3wrID9hE)
	else: VVdkitm70ucB6gSb3s2APnlavXfZ54 = UFHogqet0WxfB3wrID9hE
	if VKiGj1LundAJQwEXcqgxC: IXQ6LwHoiY0P12 = IXQ6LwHoiY0P12.decode(a7VXeDU82IfQEnPZAdiT)
	try: VVdkitm70ucB6gSb3s2APnlavXfZ54.save(IXQ6LwHoiY0P12)
	except UnicodeError:
		if VKiGj1LundAJQwEXcqgxC:
			IXQ6LwHoiY0P12 = IXQ6LwHoiY0P12.encode(a7VXeDU82IfQEnPZAdiT)
			VVdkitm70ucB6gSb3s2APnlavXfZ54.save(IXQ6LwHoiY0P12)
	return gUcrITQWHL102h5tV
def iST1DXRgoLwf3r(xvkU8AyhpuKGCM3sir6,EVXlv3QaIgpYq6NodZfukiF,FC6J1yNrtV,L2m5MPR6tgY8iVbuSAlvcQTqWp,Kvh2o1QaUwlcIqHt0,NNor6gXSAnfq7d5x98aVjRZLeCz):
	VByNYL9fT1kzpmnP,rZfG1KdDXOkyihlqn6JCjL3PBaF,dGzxhmAPXcCsBO75owH = hWGMqtBy4wuLaVcj,0,15000
	FC6J1yNrtV = FC6J1yNrtV.replace('[COLOR ','[COLOR:::')
	Ehtf8dTRVFH = Kvh2o1QaUwlcIqHt0-L2m5MPR6tgY8iVbuSAlvcQTqWp*2
	for MeYdtsLypGH6hTCWrVkD1ifz in FC6J1yNrtV.splitlines():
		rZfG1KdDXOkyihlqn6JCjL3PBaF += NNor6gXSAnfq7d5x98aVjRZLeCz
		A0PY8ZHbpt9ao7g1VLv,YYpD6cwrZ7CTWbdgV5RaFEXj9Be = 0,hWGMqtBy4wuLaVcj
		for A1fkJODo2FwLPG in MeYdtsLypGH6hTCWrVkD1ifz.split(Mpsm2VF1OBnCRvK3qf6):
			zzWeAZYId02TJcbj169EKRtas = NP2yGmHiv53Oafb1Kq(Mpsm2VF1OBnCRvK3qf6+A1fkJODo2FwLPG)
			QgJdkCKEs1qUuI57F,vbnWxCoEkPSVOd0jN1IG4p7Bf = xvkU8AyhpuKGCM3sir6.textsize(zzWeAZYId02TJcbj169EKRtas,font=EVXlv3QaIgpYq6NodZfukiF)
			if A0PY8ZHbpt9ao7g1VLv+QgJdkCKEs1qUuI57F<Ehtf8dTRVFH:
				if not YYpD6cwrZ7CTWbdgV5RaFEXj9Be: YYpD6cwrZ7CTWbdgV5RaFEXj9Be += A1fkJODo2FwLPG
				else: YYpD6cwrZ7CTWbdgV5RaFEXj9Be += Mpsm2VF1OBnCRvK3qf6+A1fkJODo2FwLPG
				A0PY8ZHbpt9ao7g1VLv += QgJdkCKEs1qUuI57F
			else:
				if QgJdkCKEs1qUuI57F<Ehtf8dTRVFH:
					YYpD6cwrZ7CTWbdgV5RaFEXj9Be += '\n '+A1fkJODo2FwLPG
					rZfG1KdDXOkyihlqn6JCjL3PBaF += NNor6gXSAnfq7d5x98aVjRZLeCz
					A0PY8ZHbpt9ao7g1VLv = QgJdkCKEs1qUuI57F
				else:
					while QgJdkCKEs1qUuI57F>Ehtf8dTRVFH:
						for qHM8P3uk06wSa1VfZXijWN2 in range(1,len(Mpsm2VF1OBnCRvK3qf6+A1fkJODo2FwLPG),1):
							CtZGM063W2z97uJ5xKE4SfHnBFU = Mpsm2VF1OBnCRvK3qf6+A1fkJODo2FwLPG[:qHM8P3uk06wSa1VfZXijWN2]
							jHPVC5IS9hr1AlUpR3qDYxK = A1fkJODo2FwLPG[qHM8P3uk06wSa1VfZXijWN2:]
							J6DF5rXNf8zElS2IuyLw74pxR = NP2yGmHiv53Oafb1Kq(CtZGM063W2z97uJ5xKE4SfHnBFU)
							vv4aBEnUrhxIR0tb,RCQ8WUPb9ao7JcZ0 = xvkU8AyhpuKGCM3sir6.textsize(J6DF5rXNf8zElS2IuyLw74pxR,font=EVXlv3QaIgpYq6NodZfukiF)
							if A0PY8ZHbpt9ao7g1VLv+vv4aBEnUrhxIR0tb>Ehtf8dTRVFH:
								CKIrEqySGOidZmxJ = QgJdkCKEs1qUuI57F-vv4aBEnUrhxIR0tb
								YYpD6cwrZ7CTWbdgV5RaFEXj9Be += CtZGM063W2z97uJ5xKE4SfHnBFU+NXMOzZjYsmS9pf
								rZfG1KdDXOkyihlqn6JCjL3PBaF += NNor6gXSAnfq7d5x98aVjRZLeCz
								QgJdkCKEs1qUuI57F = CKIrEqySGOidZmxJ
								if CKIrEqySGOidZmxJ>Ehtf8dTRVFH:
									A0PY8ZHbpt9ao7g1VLv = 0
									A1fkJODo2FwLPG = jHPVC5IS9hr1AlUpR3qDYxK
								else:
									A0PY8ZHbpt9ao7g1VLv = CKIrEqySGOidZmxJ
									YYpD6cwrZ7CTWbdgV5RaFEXj9Be += jHPVC5IS9hr1AlUpR3qDYxK
								break
				if rZfG1KdDXOkyihlqn6JCjL3PBaF>dGzxhmAPXcCsBO75owH: break
		VByNYL9fT1kzpmnP += NXMOzZjYsmS9pf+YYpD6cwrZ7CTWbdgV5RaFEXj9Be
		if rZfG1KdDXOkyihlqn6JCjL3PBaF>dGzxhmAPXcCsBO75owH: break
	VByNYL9fT1kzpmnP = VByNYL9fT1kzpmnP[1:]
	VByNYL9fT1kzpmnP = VByNYL9fT1kzpmnP.replace('[COLOR:::','[COLOR ')
	return VByNYL9fT1kzpmnP
def NP2yGmHiv53Oafb1Kq(A1fkJODo2FwLPG):
	if '[' in A1fkJODo2FwLPG and ']' in A1fkJODo2FwLPG:
		cKeW8znJDNE3o = [YYSh2J6BIrsm8,'[/RTL]','[/LEFT]','[/RIGHT]','[/CENTER]','[RTL]','[LEFT]','[RIGHT]','[CENTER]']
		t3I5gqomEGYCkXW4DQ = trdVA0JvFaD.findall('\[COLOR .*?\]',A1fkJODo2FwLPG,trdVA0JvFaD.DOTALL)
		ttTD8qflvmbAoVLgUOYQF = trdVA0JvFaD.findall('\[COLOR:::.*?\]',A1fkJODo2FwLPG,trdVA0JvFaD.DOTALL)
		AW7NqgRkLcJBl = cKeW8znJDNE3o+t3I5gqomEGYCkXW4DQ+ttTD8qflvmbAoVLgUOYQF
		for zkKdPD8bcJ0XMfhFyWjtS4U9 in AW7NqgRkLcJBl: A1fkJODo2FwLPG = A1fkJODo2FwLPG.replace(zkKdPD8bcJ0XMfhFyWjtS4U9,hWGMqtBy4wuLaVcj)
	return A1fkJODo2FwLPG
def vz5XScnI3LtefGyOP(s9ea72VfoygAOFRCWQTH3zmDuLPE):
	s9ea72VfoygAOFRCWQTH3zmDuLPE = s9ea72VfoygAOFRCWQTH3zmDuLPE.replace(NXMOzZjYsmS9pf,'_sss__newline_')
	s9ea72VfoygAOFRCWQTH3zmDuLPE = s9ea72VfoygAOFRCWQTH3zmDuLPE.replace('[RTL]','_sss__linertl_')
	s9ea72VfoygAOFRCWQTH3zmDuLPE = s9ea72VfoygAOFRCWQTH3zmDuLPE.replace('[LEFT]','_sss__lineleft_')
	s9ea72VfoygAOFRCWQTH3zmDuLPE = s9ea72VfoygAOFRCWQTH3zmDuLPE.replace('[RIGHT]','_sss__lineright_')
	s9ea72VfoygAOFRCWQTH3zmDuLPE = s9ea72VfoygAOFRCWQTH3zmDuLPE.replace('[CENTER]','_sss__linecenter_')
	s9ea72VfoygAOFRCWQTH3zmDuLPE = s9ea72VfoygAOFRCWQTH3zmDuLPE.replace(YYSh2J6BIrsm8,'_sss__endcolor_')
	UtWnEq1Y3aH2QFrwZMey7hgBJR = trdVA0JvFaD.findall('\[COLOR (.*?)\]',s9ea72VfoygAOFRCWQTH3zmDuLPE,trdVA0JvFaD.DOTALL)
	for ab1e3mRzidX5IKPZwlHjn in UtWnEq1Y3aH2QFrwZMey7hgBJR: s9ea72VfoygAOFRCWQTH3zmDuLPE = s9ea72VfoygAOFRCWQTH3zmDuLPE.replace('[COLOR '+ab1e3mRzidX5IKPZwlHjn+']','_sss__newcolor'+ab1e3mRzidX5IKPZwlHjn+'_')
	return s9ea72VfoygAOFRCWQTH3zmDuLPE
def XFr42BCdkuqpsmZw6NvG39gz7HSK0h(IjMvAHugBp,j4lHpxXvnF2VtwBb1T9PaJEm3=hWGMqtBy4wuLaVcj):
	if not j4lHpxXvnF2VtwBb1T9PaJEm3: j4lHpxXvnF2VtwBb1T9PaJEm3 = MMk8qKvcJe4fQHm3EG7diBD5.getInfoLabel('ListItem.Label')
	j4lHpxXvnF2VtwBb1T9PaJEm3 = j4lHpxXvnF2VtwBb1T9PaJEm3.replace(nIDXGaRHv7mOohe0Y8dLstECM,Mpsm2VF1OBnCRvK3qf6).replace(lG0yV5QNFHc2RbXM1Wp,Mpsm2VF1OBnCRvK3qf6).replace(FqcVAkh7WjIXHdDKf8nvuyRo,Mpsm2VF1OBnCRvK3qf6).strip(Mpsm2VF1OBnCRvK3qf6)
	if IjMvAHugBp: j4lHpxXvnF2VtwBb1T9PaJEm3 = j4lHpxXvnF2VtwBb1T9PaJEm3.replace('[COLOR ',hWGMqtBy4wuLaVcj).replace(']',hWGMqtBy4wuLaVcj)
	else: j4lHpxXvnF2VtwBb1T9PaJEm3 = j4lHpxXvnF2VtwBb1T9PaJEm3.replace(soMVfbr6WtpNlcSA,hWGMqtBy4wuLaVcj).replace(hXB0vKVQ5PRI91SDTprMdfuHEm4,hWGMqtBy4wuLaVcj).replace(tsBed5hpnEXTRG0u3U8KYlDfW1j,hWGMqtBy4wuLaVcj).replace(mjT0nQWPKRuLrbVCvpkN,hWGMqtBy4wuLaVcj)
	j4lHpxXvnF2VtwBb1T9PaJEm3 = j4lHpxXvnF2VtwBb1T9PaJEm3.replace(NXMOzZjYsmS9pf,hWGMqtBy4wuLaVcj).replace(y6eSQlZEV8uwKG5M3,hWGMqtBy4wuLaVcj).replace(YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj)
	j4lHpxXvnF2VtwBb1T9PaJEm3 = j4lHpxXvnF2VtwBb1T9PaJEm3.replace(cc6SBsG2vlpjPd8yERNW1AJDZM,hWGMqtBy4wuLaVcj).replace(w4GYEC6fmU2g7H,hWGMqtBy4wuLaVcj)
	rrXw9fL6coyIE8gRaZ4l5HnMGp = trdVA0JvFaD.findall('\d\d:\d\d ',j4lHpxXvnF2VtwBb1T9PaJEm3,trdVA0JvFaD.DOTALL)
	if rrXw9fL6coyIE8gRaZ4l5HnMGp: j4lHpxXvnF2VtwBb1T9PaJEm3 = j4lHpxXvnF2VtwBb1T9PaJEm3.split(rrXw9fL6coyIE8gRaZ4l5HnMGp[0],1)[1]
	if not j4lHpxXvnF2VtwBb1T9PaJEm3: j4lHpxXvnF2VtwBb1T9PaJEm3 = 'Main Menu'
	return j4lHpxXvnF2VtwBb1T9PaJEm3
def vJRN3snSxMqBP1dpIGTQX8Yl(pRXW8ZM9Qhfd7aTsPGB3vOjcu):
	mLkph156cx = hWGMqtBy4wuLaVcj.join(qHM8P3uk06wSa1VfZXijWN2 for qHM8P3uk06wSa1VfZXijWN2 in pRXW8ZM9Qhfd7aTsPGB3vOjcu if qHM8P3uk06wSa1VfZXijWN2 not in '\/":*?<>|'+FiSv0uqKNEbQx3dXlWZhPV8)
	return mLkph156cx
def pq5nlLYxzuaQg(z5NBJ1tXibWlaTfhdo0FG):
	QiK1J5cwCG2s = trdVA0JvFaD.findall("adilbo_HTML_encoder(.*?)/g.....(.*?)\)",z5NBJ1tXibWlaTfhdo0FG,trdVA0JvFaD.S)
	if QiK1J5cwCG2s:
		eiQKOuZNn8mzx,hygtqmU9QOcdj = QiK1J5cwCG2s[0]
		eiQKOuZNn8mzx = trdVA0JvFaD.findall("=[\r\n\s\t]+'(.*?)';", eiQKOuZNn8mzx, trdVA0JvFaD.S)[0]
		if eiQKOuZNn8mzx and hygtqmU9QOcdj:
			i1i0V5aLDmEUs = eiQKOuZNn8mzx.replace("'",hWGMqtBy4wuLaVcj).replace("+",hWGMqtBy4wuLaVcj).replace("\n",hWGMqtBy4wuLaVcj).replace("\r",hWGMqtBy4wuLaVcj)
			r5dfJXPx1RwHKi2 = i1i0V5aLDmEUs.split('.')
			z5NBJ1tXibWlaTfhdo0FG = hWGMqtBy4wuLaVcj
			for UoQTWwnyKVDqPRsXSmzAL in r5dfJXPx1RwHKi2:
				VgT6noRfpWIkSl = FxG0Q9kuBSmTyM.b64decode(UoQTWwnyKVDqPRsXSmzAL+'==').decode(a7VXeDU82IfQEnPZAdiT)
				OOD9QkET1zjNbaIe2L = trdVA0JvFaD.findall('\d+', VgT6noRfpWIkSl, trdVA0JvFaD.S)
				if OOD9QkET1zjNbaIe2L:
					H5hptEPiNUjQMeXw3mfcnTZI1y = int(OOD9QkET1zjNbaIe2L[0])
					H5hptEPiNUjQMeXw3mfcnTZI1y += int(hygtqmU9QOcdj)
					z5NBJ1tXibWlaTfhdo0FG = z5NBJ1tXibWlaTfhdo0FG + chr(H5hptEPiNUjQMeXw3mfcnTZI1y)
			if H4qZ2hwilNJYTmCFEQyaSs98cPM0gR: z5NBJ1tXibWlaTfhdo0FG = z5NBJ1tXibWlaTfhdo0FG.encode('iso-8859-1').decode(a7VXeDU82IfQEnPZAdiT)
	return z5NBJ1tXibWlaTfhdo0FG
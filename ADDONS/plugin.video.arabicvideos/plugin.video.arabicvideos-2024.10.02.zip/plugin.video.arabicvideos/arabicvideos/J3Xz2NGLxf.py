# -*- coding: utf-8 -*-
from yoY3NdGViS import *
xjPuFK3EsIZSiobQ5X = 'SERIES4WATCH'
headers = { 'User-Agent' : hWGMqtBy4wuLaVcj }
n0qFKQWhiBYXoTrvejVHUA4 = '_SFW_'
Str0BupDTFA = u6rbxnyjTl7I[xjPuFK3EsIZSiobQ5X][0]
def ehB18u9sQFRi(mode,url,text):
	if   mode==210: N6NCYivtV4I5rEXq = DP6FSBgNdX1rsvVR()
	elif mode==211: N6NCYivtV4I5rEXq = wg5aF3e8rcDh7SGpW6M1OPnkU(url)
	elif mode==212: N6NCYivtV4I5rEXq = oanus6TxUFNAhSZKpJdYlEC4mV(url)
	elif mode==213: N6NCYivtV4I5rEXq = GrsxUhb0PEXj2FQRAkD4q(url)
	elif mode==214: N6NCYivtV4I5rEXq = vvqXOspxRh80BSUtFL79m4TIyEb(url)
	elif mode==215: N6NCYivtV4I5rEXq = jGaeJYT5FHpirMgbXn(url)
	elif mode==218: N6NCYivtV4I5rEXq = w9EdimAtKlPaLGR7TFJWYVhUu()
	elif mode==219: N6NCYivtV4I5rEXq = lPwaAjFTMG4n7iSLkXcEuK0Zm(text)
	else: N6NCYivtV4I5rEXq = False
	return N6NCYivtV4I5rEXq
def w9EdimAtKlPaLGR7TFJWYVhUu():
	message = 'هذا الموقع تغير بالكامل ... وبحاجة الى اعادة برمجة من الصفر ... والمبرمج حاليا مشغول ويعاني من وعكة صحية ... ولهذا سوف يبقى الموقع مغلق الى ما شاء الله'
	BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'رسالة من المبرمج','الموقع تغير بالكامل',message)
	return
def DP6FSBgNdX1rsvVR():
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'بحث في الموقع',hWGMqtBy4wuLaVcj,219,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'_REMEMBERRESULTS_')
	url = Str0BupDTFA+'/getpostsPin?type=one&data=pin&limit=25'
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+'المميزة',url,211)
	mMQ3FkNVa4IlxqY = f1fLNcPlo2ECKtiBeug0OAvz9YM(DpQifS0oKBI1hYcO,Str0BupDTFA,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,'SERIES4WATCH-MENU-1st')
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('FiltersButtons(.*?)</div>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
	items = trdVA0JvFaD.findall('data-get="(.*?)".*?</i>(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	for llxFwq0CUNgQtivJzkHeGV,title in items:
		url = Str0BupDTFA+'/getposts?type=one&data='+llxFwq0CUNgQtivJzkHeGV
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+title,url,211)
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('navigation-menu(.*?)</div>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
	items = trdVA0JvFaD.findall('href="(http.*?)">(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	P3UK1Rr4IdYe5 = ['مسلسلات انمي','الرئيسية']
	for llxFwq0CUNgQtivJzkHeGV,title in items:
		title = title.strip(Mpsm2VF1OBnCRvK3qf6)
		if not any(BoSjXKxz41DcneO9UimClE in title for BoSjXKxz41DcneO9UimClE in P3UK1Rr4IdYe5):
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,211)
	return mMQ3FkNVa4IlxqY
def wg5aF3e8rcDh7SGpW6M1OPnkU(url):
	mMQ3FkNVa4IlxqY = f1fLNcPlo2ECKtiBeug0OAvz9YM(KqO5BWGQR9JVL,url,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,'SERIES4WATCH-TITLES-1st')
	if 'getposts' in url or '/search?s=' in url: cok5ZGXdQP7YhwtqyuaCnVevm6UB = mMQ3FkNVa4IlxqY
	else:
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('MediaGrid"(.*?)class="pagination"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if DJvksH7ZAFUqW9OyQnbGjPCtwR1o: cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		else: return
	items = trdVA0JvFaD.findall('src="(.*?)".*?href="(.*?)".*?<h3>(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	REbVyXis1w4Ae = []
	XpMKS0Damzilq6xQ3j2LPGrfghYU = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,llxFwq0CUNgQtivJzkHeGV,title in items:
		if '/series/' in llxFwq0CUNgQtivJzkHeGV: continue
		llxFwq0CUNgQtivJzkHeGV = jkiCS0UWs2dNAJcGKn6mbHD(llxFwq0CUNgQtivJzkHeGV).strip('/')
		title = LNtIDdBA52P(title)
		title = title.strip(Mpsm2VF1OBnCRvK3qf6)
		if '/film/' in llxFwq0CUNgQtivJzkHeGV or any(BoSjXKxz41DcneO9UimClE in title for BoSjXKxz41DcneO9UimClE in XpMKS0Damzilq6xQ3j2LPGrfghYU):
			RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,212,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
		elif '/episode/' in llxFwq0CUNgQtivJzkHeGV and 'الحلقة' in title:
			IIsmGy4pd7 = trdVA0JvFaD.findall('(.*?) الحلقة \d+',title,trdVA0JvFaD.DOTALL)
			if IIsmGy4pd7:
				title = '_MOD_' + IIsmGy4pd7[0]
				if title not in REbVyXis1w4Ae:
					RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,213,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
					REbVyXis1w4Ae.append(title)
		else: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,213,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('class="pagination(.*?)</div>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('<a href=["\'](http.*?)["\'].*?>(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,title in items:
			llxFwq0CUNgQtivJzkHeGV = LNtIDdBA52P(llxFwq0CUNgQtivJzkHeGV)
			title = LNtIDdBA52P(title)
			title = title.replace('الصفحة ',hWGMqtBy4wuLaVcj)
			if title!=hWGMqtBy4wuLaVcj: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'صفحة '+title,llxFwq0CUNgQtivJzkHeGV,211)
	return
def GrsxUhb0PEXj2FQRAkD4q(url):
	gROw5JUAXM7yT6,items,q0WatP1ke9EX4xcBQ = -1,[],[]
	mMQ3FkNVa4IlxqY = f1fLNcPlo2ECKtiBeug0OAvz9YM(KqO5BWGQR9JVL,url,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,'SERIES4WATCH-EPISODES-1st')
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('ti-list-numbered(.*?)</div>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		rqIW37cd0iT1msDzRevOM = hWGMqtBy4wuLaVcj.join(DJvksH7ZAFUqW9OyQnbGjPCtwR1o)
		items = trdVA0JvFaD.findall('href="(.*?)"',rqIW37cd0iT1msDzRevOM,trdVA0JvFaD.DOTALL)
	items.append(url)
	items = set(items)
	for llxFwq0CUNgQtivJzkHeGV in items:
		llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV.strip('/')
		title = '_MOD_' + llxFwq0CUNgQtivJzkHeGV.split('/')[-1].replace('-',Mpsm2VF1OBnCRvK3qf6)
		coDr4CpZ9UyQn8txJuA315eN0OjH = trdVA0JvFaD.findall('الحلقة-(\d+)',llxFwq0CUNgQtivJzkHeGV.split('/')[-1],trdVA0JvFaD.DOTALL)
		if coDr4CpZ9UyQn8txJuA315eN0OjH: coDr4CpZ9UyQn8txJuA315eN0OjH = coDr4CpZ9UyQn8txJuA315eN0OjH[0]
		else: coDr4CpZ9UyQn8txJuA315eN0OjH = '0'
		q0WatP1ke9EX4xcBQ.append([llxFwq0CUNgQtivJzkHeGV,title,coDr4CpZ9UyQn8txJuA315eN0OjH])
	items = sorted(q0WatP1ke9EX4xcBQ, reverse=False, key=lambda key: int(key[2]))
	hQHu89XzPmgROD5W4kiLBjvt73A6qN = str(items).count('/season/')
	gROw5JUAXM7yT6 = str(items).count('/episode/')
	if hQHu89XzPmgROD5W4kiLBjvt73A6qN>1 and gROw5JUAXM7yT6>0 and '/season/' not in url:
		for llxFwq0CUNgQtivJzkHeGV,title,coDr4CpZ9UyQn8txJuA315eN0OjH in items:
			if '/season/' in llxFwq0CUNgQtivJzkHeGV: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,213)
	else:
		for llxFwq0CUNgQtivJzkHeGV,title,coDr4CpZ9UyQn8txJuA315eN0OjH in items:
			if '/season/' not in llxFwq0CUNgQtivJzkHeGV: RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,212)
	return
def oanus6TxUFNAhSZKpJdYlEC4mV(url):
	Dvi8asSrQYX5wE3KMIxT91me = []
	LLsGB1FPiUTyYrdwqf86eHAnQ = url.split('/')
	mMQ3FkNVa4IlxqY = f1fLNcPlo2ECKtiBeug0OAvz9YM(DpQifS0oKBI1hYcO,url,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,'SERIES4WATCH-PLAY-1st')
	if '/watch/' in mMQ3FkNVa4IlxqY:
		NPM3HKQ57xe = url.replace(LLsGB1FPiUTyYrdwqf86eHAnQ[3],'watch')
		eecmFXt5SRyCjGpx = f1fLNcPlo2ECKtiBeug0OAvz9YM(DpQifS0oKBI1hYcO,NPM3HKQ57xe,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,'SERIES4WATCH-PLAY-2nd')
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('class="servers-list(.*?)</div>',eecmFXt5SRyCjGpx,trdVA0JvFaD.DOTALL)
		if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
			cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
			items = trdVA0JvFaD.findall('data-embedd="(.*?)".*?server_image">\n(.*?)\n',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
			if items:
				id = trdVA0JvFaD.findall('post_id=(.*?)"',eecmFXt5SRyCjGpx,trdVA0JvFaD.DOTALL)
				if id:
					VzAiKmWdsgw9XfIuF1e0 = id[0]
					for llxFwq0CUNgQtivJzkHeGV,title in items:
						llxFwq0CUNgQtivJzkHeGV = Str0BupDTFA+'/?postid='+VzAiKmWdsgw9XfIuF1e0+'&serverid='+llxFwq0CUNgQtivJzkHeGV+'?named='+title+'__watch'
						Dvi8asSrQYX5wE3KMIxT91me.append(llxFwq0CUNgQtivJzkHeGV)
			else:
				items = trdVA0JvFaD.findall('data-embedd=".*?(http.*?)("|&quot;)',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
				for llxFwq0CUNgQtivJzkHeGV,QwGpLVOkc0MPodWfiYsTj in items:
					Dvi8asSrQYX5wE3KMIxT91me.append(llxFwq0CUNgQtivJzkHeGV)
	if '/download/' in mMQ3FkNVa4IlxqY:
		NPM3HKQ57xe = url.replace(LLsGB1FPiUTyYrdwqf86eHAnQ[3],'download')
		eecmFXt5SRyCjGpx = f1fLNcPlo2ECKtiBeug0OAvz9YM(DpQifS0oKBI1hYcO,NPM3HKQ57xe,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,'SERIES4WATCH-PLAY-3rd')
		id = trdVA0JvFaD.findall('postId:"(.*?)"',eecmFXt5SRyCjGpx,trdVA0JvFaD.DOTALL)
		if id:
			VzAiKmWdsgw9XfIuF1e0 = id[0]
			PwvNmnqXKrYVZugB5c8 = { 'User-Agent':hWGMqtBy4wuLaVcj , 'X-Requested-With':'XMLHttpRequest' }
			NPM3HKQ57xe = Str0BupDTFA + '/ajaxCenter?_action=getdownloadlinks&postId='+VzAiKmWdsgw9XfIuF1e0
			eecmFXt5SRyCjGpx = f1fLNcPlo2ECKtiBeug0OAvz9YM(DpQifS0oKBI1hYcO,NPM3HKQ57xe,hWGMqtBy4wuLaVcj,PwvNmnqXKrYVZugB5c8,hWGMqtBy4wuLaVcj,'SERIES4WATCH-PLAY-4th')
			DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('<h3.*?(\d+)(.*?)</div>',eecmFXt5SRyCjGpx,trdVA0JvFaD.DOTALL)
			if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
				for DSG1hTbByNjm5AOJU8zwXC,cok5ZGXdQP7YhwtqyuaCnVevm6UB in DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
					items = trdVA0JvFaD.findall('<td>(.*?)<.*?href="(.*?)"',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
					for name,llxFwq0CUNgQtivJzkHeGV in items:
						Dvi8asSrQYX5wE3KMIxT91me.append(llxFwq0CUNgQtivJzkHeGV+'?named='+name+'__download'+'____'+DSG1hTbByNjm5AOJU8zwXC)
			else:
				DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('<h6(.*?)</table>',eecmFXt5SRyCjGpx,trdVA0JvFaD.DOTALL)
				if not DJvksH7ZAFUqW9OyQnbGjPCtwR1o: DJvksH7ZAFUqW9OyQnbGjPCtwR1o = [eecmFXt5SRyCjGpx]
				for cok5ZGXdQP7YhwtqyuaCnVevm6UB in DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
					name = hWGMqtBy4wuLaVcj
					items = trdVA0JvFaD.findall('href="(http.*?)"',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
					for llxFwq0CUNgQtivJzkHeGV in items:
						SODQ7qlNYoZcFK8e50rBsJaAHxiXjE = '&&' + llxFwq0CUNgQtivJzkHeGV.split('/')[2].lower() + '&&'
						SODQ7qlNYoZcFK8e50rBsJaAHxiXjE = SODQ7qlNYoZcFK8e50rBsJaAHxiXjE.replace('.com&&',hWGMqtBy4wuLaVcj).replace('.co&&',hWGMqtBy4wuLaVcj)
						SODQ7qlNYoZcFK8e50rBsJaAHxiXjE = SODQ7qlNYoZcFK8e50rBsJaAHxiXjE.replace('.net&&',hWGMqtBy4wuLaVcj).replace('.org&&',hWGMqtBy4wuLaVcj)
						SODQ7qlNYoZcFK8e50rBsJaAHxiXjE = SODQ7qlNYoZcFK8e50rBsJaAHxiXjE.replace('.live&&',hWGMqtBy4wuLaVcj).replace('.online&&',hWGMqtBy4wuLaVcj)
						SODQ7qlNYoZcFK8e50rBsJaAHxiXjE = SODQ7qlNYoZcFK8e50rBsJaAHxiXjE.replace('&&hd.',hWGMqtBy4wuLaVcj).replace('&&www.',hWGMqtBy4wuLaVcj)
						SODQ7qlNYoZcFK8e50rBsJaAHxiXjE = SODQ7qlNYoZcFK8e50rBsJaAHxiXjE.replace('&&',hWGMqtBy4wuLaVcj)
						llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV + '?named=' + name + SODQ7qlNYoZcFK8e50rBsJaAHxiXjE + '__download'
						Dvi8asSrQYX5wE3KMIxT91me.append(llxFwq0CUNgQtivJzkHeGV)
	import oosSOfvdEQ
	oosSOfvdEQ.zfdYjsGLg8M6i15qZWh(Dvi8asSrQYX5wE3KMIxT91me,xjPuFK3EsIZSiobQ5X,'video',url)
	return
def lPwaAjFTMG4n7iSLkXcEuK0Zm(search):
	search,vvKf4sXgZIMyEJPuC,showDialogs = IVTEJQOiMR2dYta9C(search)
	if search==hWGMqtBy4wuLaVcj: search = TrzfUidpv1LyAYqwexHJDuS()
	if search==hWGMqtBy4wuLaVcj: return
	search = search.replace(Mpsm2VF1OBnCRvK3qf6,'+')
	url = Str0BupDTFA + '/search?s='+search
	wg5aF3e8rcDh7SGpW6M1OPnkU(url)
	return
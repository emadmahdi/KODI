# -*- coding: utf-8 -*-
from yoY3NdGViS import *
bBER0HlPYh4ZXm6ILWw = 'IPTV'
O50cprnq2W1DAgTiRZUm = '_IPT_'
vNkywjI1YV6DAUdH = [
		 'IGNORED'
		,'LIVE_UNKNOWN_GROUPED','LIVE_UNKNOWN_GROUPED_SORTED'
		,'VOD_UNKNOWN_GROUPED','VOD_UNKNOWN_GROUPED_SORTED'
		,'LIVE_ARCHIVED_GROUPED_SORTED','LIVE_EPG_GROUPED_SORTED','LIVE_TIMESHIFT_GROUPED_SORTED'
		,'LIVE_GROUPED','LIVE_GROUPED_SORTED'
		,'LIVE_ORIGINAL_GROUPED','LIVE_FROM_GROUP_SORTED','LIVE_FROM_NAME_SORTED'
		,'VOD_MOVIES_GROUPED','VOD_MOVIES_GROUPED_SORTED'
		,'VOD_SERIES_GROUPED','VOD_SERIES_GROUPED_SORTED'
		,'VOD_ORIGINAL_GROUPED','VOD_FROM_GROUP_SORTED','VOD_FROM_NAME_SORTED'
		]
def GwmTvrCi2VudfPSOq0x(JbpxsyQVXmSEYKM3vo847Ckh,O9z5L3KtXqPEMepJQ0,s9ea72VfoygAOFRCWQTH3zmDuLPE,udRvjXt9cAfha5ZsBP3U,z5NBJ1tXibWlaTfhdo0FG,kFeSKZb8qiVd4GxwcAMHQolgU):
	global O50cprnq2W1DAgTiRZUm
	try:
		ZZNvmiGjlpwIOx = str(kFeSKZb8qiVd4GxwcAMHQolgU['folder'])
		O50cprnq2W1DAgTiRZUm = '_IP'+ZZNvmiGjlpwIOx+'_'
	except: ZZNvmiGjlpwIOx = hWGMqtBy4wuLaVcj
	if   JbpxsyQVXmSEYKM3vo847Ckh==230: x4xVJLXyIQbSqlHWem = EV05QbUtGN4zf8elTaKoCn()
	elif JbpxsyQVXmSEYKM3vo847Ckh==231: x4xVJLXyIQbSqlHWem = iCfurd34Gnxt5N(ZZNvmiGjlpwIOx)
	elif JbpxsyQVXmSEYKM3vo847Ckh==232: x4xVJLXyIQbSqlHWem = B2BdYsVOPcJ(ZZNvmiGjlpwIOx)
	elif JbpxsyQVXmSEYKM3vo847Ckh==233: x4xVJLXyIQbSqlHWem = YDs4gfOMR8rQeSoqnUXwxCEa6BlP1(ZZNvmiGjlpwIOx,O9z5L3KtXqPEMepJQ0,s9ea72VfoygAOFRCWQTH3zmDuLPE,z5NBJ1tXibWlaTfhdo0FG)
	elif JbpxsyQVXmSEYKM3vo847Ckh==234: x4xVJLXyIQbSqlHWem = qJQdtBXVnP9EFwlvOKMLecDb(ZZNvmiGjlpwIOx,O9z5L3KtXqPEMepJQ0,s9ea72VfoygAOFRCWQTH3zmDuLPE,z5NBJ1tXibWlaTfhdo0FG)
	elif JbpxsyQVXmSEYKM3vo847Ckh==235: x4xVJLXyIQbSqlHWem = oanus6TxUFNAhSZKpJdYlEC4mV(ZZNvmiGjlpwIOx,O9z5L3KtXqPEMepJQ0,udRvjXt9cAfha5ZsBP3U)
	elif JbpxsyQVXmSEYKM3vo847Ckh==236: x4xVJLXyIQbSqlHWem = NjdI2F6vbK(ZZNvmiGjlpwIOx,True)
	elif JbpxsyQVXmSEYKM3vo847Ckh==237: x4xVJLXyIQbSqlHWem = VhlpEXgH37Jx(ZZNvmiGjlpwIOx,True)
	elif JbpxsyQVXmSEYKM3vo847Ckh==238: x4xVJLXyIQbSqlHWem = AAi0D8X54VISxHgUzPC(ZZNvmiGjlpwIOx,O9z5L3KtXqPEMepJQ0,s9ea72VfoygAOFRCWQTH3zmDuLPE)
	elif JbpxsyQVXmSEYKM3vo847Ckh==239: x4xVJLXyIQbSqlHWem = JJZuoXlhrIYv(s9ea72VfoygAOFRCWQTH3zmDuLPE,ZZNvmiGjlpwIOx,O9z5L3KtXqPEMepJQ0,z5NBJ1tXibWlaTfhdo0FG)
	elif JbpxsyQVXmSEYKM3vo847Ckh==280: x4xVJLXyIQbSqlHWem = Q7qM9UmTskpgznERAX5wKo0hDb(ZZNvmiGjlpwIOx,True)
	elif JbpxsyQVXmSEYKM3vo847Ckh==281: x4xVJLXyIQbSqlHWem = vvql6FyRM4JY(ZZNvmiGjlpwIOx)
	elif JbpxsyQVXmSEYKM3vo847Ckh==282: x4xVJLXyIQbSqlHWem = sco9jVPZ3liOXxy2BShM(ZZNvmiGjlpwIOx)
	elif JbpxsyQVXmSEYKM3vo847Ckh==283: x4xVJLXyIQbSqlHWem = ZpEic0wWLfP1YNbUM7A(ZZNvmiGjlpwIOx)
	elif JbpxsyQVXmSEYKM3vo847Ckh==285: x4xVJLXyIQbSqlHWem = qqEHNFxhesSP1Aru7G2(ZZNvmiGjlpwIOx,O9z5L3KtXqPEMepJQ0,s9ea72VfoygAOFRCWQTH3zmDuLPE)
	elif JbpxsyQVXmSEYKM3vo847Ckh==286: x4xVJLXyIQbSqlHWem = zTAGmbQWSUavCEOB0RnkxD1KeoVdt(ZZNvmiGjlpwIOx)
	elif JbpxsyQVXmSEYKM3vo847Ckh==289: x4xVJLXyIQbSqlHWem = QNDl4JqFCVREeiSvOU(s9ea72VfoygAOFRCWQTH3zmDuLPE,ZZNvmiGjlpwIOx,O9z5L3KtXqPEMepJQ0,z5NBJ1tXibWlaTfhdo0FG)
	else: x4xVJLXyIQbSqlHWem = False
	return x4xVJLXyIQbSqlHWem
def EV05QbUtGN4zf8elTaKoCn():
	for ZZNvmiGjlpwIOx in range(1,SdRCvwxfo1P95Jjb+1):
		O50cprnq2W1DAgTiRZUm = '_IP'+str(ZZNvmiGjlpwIOx)+'_'
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',O50cprnq2W1DAgTiRZUm+'قائمة مجلد '+A7ZIc5uC1nT0PWYHEjb2BfxeV38[ZZNvmiGjlpwIOx],hWGMqtBy4wuLaVcj,280,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,{'folder':ZZNvmiGjlpwIOx})
	return
def Q7qM9UmTskpgznERAX5wKo0hDb(ZZNvmiGjlpwIOx=hWGMqtBy4wuLaVcj,WJrHC9Da7gRnmplf53=hWGMqtBy4wuLaVcj):
	if ZZNvmiGjlpwIOx:
		UXyq9nPgufMh1 = {'folder':ZZNvmiGjlpwIOx}
		FhWHOJ7vySrd3bKt = hWGMqtBy4wuLaVcj
	else:
		UXyq9nPgufMh1 = hWGMqtBy4wuLaVcj
		FhWHOJ7vySrd3bKt = hWGMqtBy4wuLaVcj
	NNcGBv9yQ5VtbW = OhBPub8QYNceaq3W(ZZNvmiGjlpwIOx,WJrHC9Da7gRnmplf53)
	if not NNcGBv9yQ5VtbW:
		RLDCGt8kq3OVmnzgx1rbi2f7F('link',O50cprnq2W1DAgTiRZUm+soMVfbr6WtpNlcSA+' إضافة أو تغيير اشتراك'+FhWHOJ7vySrd3bKt+' '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,231,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,UXyq9nPgufMh1)
		RLDCGt8kq3OVmnzgx1rbi2f7F('link',O50cprnq2W1DAgTiRZUm+soMVfbr6WtpNlcSA+' جلب ملفات'+FhWHOJ7vySrd3bKt+' '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,232,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,UXyq9nPgufMh1)
		RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	else:
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',O50cprnq2W1DAgTiRZUm+'بحث في الملفات'+FhWHOJ7vySrd3bKt,hWGMqtBy4wuLaVcj,289,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'_REMEMBERRESULTS_',hWGMqtBy4wuLaVcj,UXyq9nPgufMh1)
		RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',O50cprnq2W1DAgTiRZUm+'قنوات بدون جلب ملفات','XTREAM_LIVE_GROUPS',285,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,UXyq9nPgufMh1)
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',O50cprnq2W1DAgTiRZUm+'قنوات مصنفة مرتبة'+FhWHOJ7vySrd3bKt,'LIVE_GROUPED_SORTED',233,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,UXyq9nPgufMh1)
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',O50cprnq2W1DAgTiRZUm+'قنوات مصنفة من القسم'+FhWHOJ7vySrd3bKt,'LIVE_FROM_GROUP_SORTED',233,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,UXyq9nPgufMh1)
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',O50cprnq2W1DAgTiRZUm+'قنوات مصنفة من الاسم'+FhWHOJ7vySrd3bKt,'LIVE_FROM_NAME_SORTED',233,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,UXyq9nPgufMh1)
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',O50cprnq2W1DAgTiRZUm+'قنوات مصنفة بلا ترتيب'+FhWHOJ7vySrd3bKt,'LIVE_GROUPED',233,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,UXyq9nPgufMh1)
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',O50cprnq2W1DAgTiRZUm+'قنوات بلا ترتيب'+FhWHOJ7vySrd3bKt,'LIVE_ORIGINAL_GROUPED',233,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,UXyq9nPgufMh1)
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',O50cprnq2W1DAgTiRZUm+'قنوات مجهولة مرتبة'+FhWHOJ7vySrd3bKt,'LIVE_UNKNOWN_GROUPED_SORTED',233,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,UXyq9nPgufMh1)
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',O50cprnq2W1DAgTiRZUm+'قنوات مجهولة بلا ترتيب'+FhWHOJ7vySrd3bKt,'LIVE_UNKNOWN_GROUPED',233,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,UXyq9nPgufMh1)
		RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',O50cprnq2W1DAgTiRZUm+'أفلام بدون جلب ملفات','XTREAM_VOD_GROUPS',285,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,UXyq9nPgufMh1)
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',O50cprnq2W1DAgTiRZUm+'أفلام مصنفة بلا ترتيب'+FhWHOJ7vySrd3bKt,'VOD_MOVIES_GROUPED',233,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,UXyq9nPgufMh1)
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',O50cprnq2W1DAgTiRZUm+'أفلام مصنفة مرتبة'+FhWHOJ7vySrd3bKt,'VOD_MOVIES_GROUPED_SORTED',233,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,UXyq9nPgufMh1)
		RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',O50cprnq2W1DAgTiRZUm+'مسلسلات بدون جلب ملفات','XTREAM_SERIES_GROUPS',285,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,UXyq9nPgufMh1)
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',O50cprnq2W1DAgTiRZUm+'مسلسلات مصنفة بلا ترتيب'+FhWHOJ7vySrd3bKt,'VOD_SERIES_GROUPED',233,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,UXyq9nPgufMh1)
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',O50cprnq2W1DAgTiRZUm+'مسلسلات مصنفة مرتبة'+FhWHOJ7vySrd3bKt,'VOD_SERIES_GROUPED_SORTED',233,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,UXyq9nPgufMh1)
		RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',O50cprnq2W1DAgTiRZUm+'فيديوهات بلا ترتيب'+FhWHOJ7vySrd3bKt,'VOD_ORIGINAL_GROUPED',233,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,UXyq9nPgufMh1)
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',O50cprnq2W1DAgTiRZUm+'فيديوهات مصنفة من القسم'+FhWHOJ7vySrd3bKt,'VOD_FROM_GROUP_SORTED',233,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,UXyq9nPgufMh1)
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',O50cprnq2W1DAgTiRZUm+'فيديوهات مصنفة من الاسم'+FhWHOJ7vySrd3bKt,'VOD_FROM_NAME_SORTED',233,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,UXyq9nPgufMh1)
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',O50cprnq2W1DAgTiRZUm+'فيديوهات مجهولة بلا ترتيب'+FhWHOJ7vySrd3bKt,'VOD_UNKNOWN_GROUPED',233,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,UXyq9nPgufMh1)
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',O50cprnq2W1DAgTiRZUm+'فيديوهات مجهولة مرتبة'+FhWHOJ7vySrd3bKt,'VOD_UNKNOWN_GROUPED_SORTED',233,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,UXyq9nPgufMh1)
		RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',O50cprnq2W1DAgTiRZUm+'برامج القنوات (جدول فقط)'+FhWHOJ7vySrd3bKt,'LIVE_EPG_GROUPED_SORTED',233,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,UXyq9nPgufMh1)
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',O50cprnq2W1DAgTiRZUm+'أرشيف القنوات للأيام الماضية'+FhWHOJ7vySrd3bKt,'LIVE_TIMESHIFT_GROUPED_SORTED',233,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,UXyq9nPgufMh1)
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',O50cprnq2W1DAgTiRZUm+'أرشيف برامج القنوات للأيام الماضية'+FhWHOJ7vySrd3bKt,'LIVE_ARCHIVED_GROUPED_SORTED',233,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,UXyq9nPgufMh1)
		RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',O50cprnq2W1DAgTiRZUm+'إضافة أو تغيير اشتراك'+FhWHOJ7vySrd3bKt,hWGMqtBy4wuLaVcj,231,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,UXyq9nPgufMh1)
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',O50cprnq2W1DAgTiRZUm+'جلب ملفات'+FhWHOJ7vySrd3bKt,hWGMqtBy4wuLaVcj,232,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,UXyq9nPgufMh1)
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',O50cprnq2W1DAgTiRZUm+'مسح ملفات'+FhWHOJ7vySrd3bKt,hWGMqtBy4wuLaVcj,237,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,UXyq9nPgufMh1)
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',O50cprnq2W1DAgTiRZUm+'فحص اشتراك'+FhWHOJ7vySrd3bKt,hWGMqtBy4wuLaVcj,236,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,UXyq9nPgufMh1)
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',O50cprnq2W1DAgTiRZUm+'عدد فيديوهات'+FhWHOJ7vySrd3bKt,hWGMqtBy4wuLaVcj,281,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,UXyq9nPgufMh1)
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',O50cprnq2W1DAgTiRZUm+'Referer تغيير'+FhWHOJ7vySrd3bKt,hWGMqtBy4wuLaVcj,286,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,UXyq9nPgufMh1)
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',O50cprnq2W1DAgTiRZUm+'User-Agent تغيير'+FhWHOJ7vySrd3bKt,hWGMqtBy4wuLaVcj,283,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,UXyq9nPgufMh1)
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',O50cprnq2W1DAgTiRZUm+'استخدم السيرفر الأسرع'+FhWHOJ7vySrd3bKt,hWGMqtBy4wuLaVcj,282,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,UXyq9nPgufMh1)
	return
def NjdI2F6vbK(ZZNvmiGjlpwIOx,WJrHC9Da7gRnmplf53=True):
	DTzBh4YjkKagtqRQx8wIHf5V3cU,dRMiZfl719XHzp3ENycUOF68k = False,hWGMqtBy4wuLaVcj
	c9EDgwAj2GnCXtqB,R1RWlgS0kiJEFL3cX2famq = hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj
	IxdSqDFvuO8wYb7f6KVJsTBGiycg,LJmA1qSt9aXc,WJ4jm6MzHbSQcO9,wNf6hz8Vtq2J4eULdBpRFCG5imj,VyaUHwQzXLqJS = WWKXJ7yo4Gb3qYsmvg5BCVHhj0P(ZZNvmiGjlpwIOx)
	if wNf6hz8Vtq2J4eULdBpRFCG5imj==hWGMqtBy4wuLaVcj: return False,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj
	eE4wIviRq52y316 = b5bp1UwmZdnxiEJ3DlSu6hMzqX2v(ZZNvmiGjlpwIOx)
	if IxdSqDFvuO8wYb7f6KVJsTBGiycg:
		oTawtcGI687h = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(lke5D6CpaAXPdEZyrBSw7T,'GET',IxdSqDFvuO8wYb7f6KVJsTBGiycg,hWGMqtBy4wuLaVcj,eE4wIviRq52y316,False,hWGMqtBy4wuLaVcj,'IPTV-CHECK_ACCOUNT-1st')
		zJjQP6hXe8vbdrTDq1EmZwncYUL = oTawtcGI687h.content
		if oTawtcGI687h.succeeded:
			ZFk5jfxwGBStqVY,ss5VcGK8hk1p3HtoPgAniZa,ppSYQKG3fjIHVimkt,OSeXxlqir4va2w0dmB3hPyRVZ8,kwBy0lcj8nFdrThY6aSAQ7Li = 0,0,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj
			try:
				C74q0HGvOJI = Cy9ow3c21nABMjzqeaIT('dict',zJjQP6hXe8vbdrTDq1EmZwncYUL)
				dRMiZfl719XHzp3ENycUOF68k = C74q0HGvOJI['user_info']['status']
				DTzBh4YjkKagtqRQx8wIHf5V3cU = True
				ppSYQKG3fjIHVimkt = C74q0HGvOJI['server_info']['time_now']
			except: pass
			if ppSYQKG3fjIHVimkt:
				try:
					BS7FRhc4QA9xLaJs = HB5PvxRhwM.strptime(ppSYQKG3fjIHVimkt,'%Y.%m.%d %H:%M:%S')
					ZFk5jfxwGBStqVY = int(HB5PvxRhwM.mktime(BS7FRhc4QA9xLaJs))
					ss5VcGK8hk1p3HtoPgAniZa = int(IHKJoQ8PwW4pNBR6GTAMVz2hdfC5my-ZFk5jfxwGBStqVY)
					ss5VcGK8hk1p3HtoPgAniZa = int((ss5VcGK8hk1p3HtoPgAniZa+900)/1800)*1800
				except: pass
				try:
					BS7FRhc4QA9xLaJs = HB5PvxRhwM.localtime(int(C74q0HGvOJI['user_info']['created_at']))
					OSeXxlqir4va2w0dmB3hPyRVZ8 = HB5PvxRhwM.strftime('%Y.%m.%d %H:%M:%S',BS7FRhc4QA9xLaJs)
				except: pass
				try:
					BS7FRhc4QA9xLaJs = HB5PvxRhwM.localtime(int(C74q0HGvOJI['user_info']['exp_date']))
					kwBy0lcj8nFdrThY6aSAQ7Li = HB5PvxRhwM.strftime('%Y.%m.%d %H:%M:%S',BS7FRhc4QA9xLaJs)
				except: pass
			ee8c0jzrTntGSUdRJm.setSetting('av.iptv.timestamp_'+ZZNvmiGjlpwIOx,str(IHKJoQ8PwW4pNBR6GTAMVz2hdfC5my))
			ee8c0jzrTntGSUdRJm.setSetting('av.iptv.timediff_'+ZZNvmiGjlpwIOx,str(ss5VcGK8hk1p3HtoPgAniZa))
			try:
				EnHvi6s9bjxUQmJg8Ke7uyo = '"server_info":'+zJjQP6hXe8vbdrTDq1EmZwncYUL.split('"server_info":')[1]
				EnHvi6s9bjxUQmJg8Ke7uyo = EnHvi6s9bjxUQmJg8Ke7uyo.replace(':',': ').replace(',',', ').replace('}}','}')
				WRThYXquyef2LwAcJzOo0nv = trdVA0JvFaD.findall('"url": "(.*?)", "port": "(.*?)"',EnHvi6s9bjxUQmJg8Ke7uyo,trdVA0JvFaD.DOTALL)
				c9EDgwAj2GnCXtqB,R1RWlgS0kiJEFL3cX2famq = WRThYXquyef2LwAcJzOo0nv[0]
			except: DTzBh4YjkKagtqRQx8wIHf5V3cU = False
			if DTzBh4YjkKagtqRQx8wIHf5V3cU and WJrHC9Da7gRnmplf53:
				max = C74q0HGvOJI['user_info']['max_connections']
				v9Wef13BqZKCYRx = C74q0HGvOJI['user_info']['active_cons']
				nYARuNSkKCQpxEZ = C74q0HGvOJI['user_info']['is_trial']
				boKDEmzIPVkaAeSLidYHp56qW = IxdSqDFvuO8wYb7f6KVJsTBGiycg.split('?',1)
				jjEwJpmd2v0oxBRP1Dyu = 'URL:  '+hXB0vKVQ5PRI91SDTprMdfuHEm4+IxdSqDFvuO8wYb7f6KVJsTBGiycg+YYSh2J6BIrsm8
				jjEwJpmd2v0oxBRP1Dyu += '\n\nStatus:  '+hXB0vKVQ5PRI91SDTprMdfuHEm4+dRMiZfl719XHzp3ENycUOF68k+YYSh2J6BIrsm8
				jjEwJpmd2v0oxBRP1Dyu += '\nTrial:    '+hXB0vKVQ5PRI91SDTprMdfuHEm4+str(nYARuNSkKCQpxEZ=='1')+YYSh2J6BIrsm8
				jjEwJpmd2v0oxBRP1Dyu += '\nCreated  At:  '+hXB0vKVQ5PRI91SDTprMdfuHEm4+OSeXxlqir4va2w0dmB3hPyRVZ8+YYSh2J6BIrsm8
				jjEwJpmd2v0oxBRP1Dyu += '\nExpiry Date:  '+hXB0vKVQ5PRI91SDTprMdfuHEm4+kwBy0lcj8nFdrThY6aSAQ7Li+YYSh2J6BIrsm8
				jjEwJpmd2v0oxBRP1Dyu += '\nConnections   ( Active / Maximum ) :  '+hXB0vKVQ5PRI91SDTprMdfuHEm4+v9Wef13BqZKCYRx+' / '+max+YYSh2J6BIrsm8
				jjEwJpmd2v0oxBRP1Dyu += '\nAllowed Outputs:   '+hXB0vKVQ5PRI91SDTprMdfuHEm4+" , ".join(C74q0HGvOJI['user_info']['allowed_output_formats'])+YYSh2J6BIrsm8
				jjEwJpmd2v0oxBRP1Dyu += '\n\n'+EnHvi6s9bjxUQmJg8Ke7uyo
				if dRMiZfl719XHzp3ENycUOF68k=='Active': zJEnrfcbUOg2ihV5MW7KT4PZm('الاشتراك يعمل بدون مشاكل',jjEwJpmd2v0oxBRP1Dyu)
				else: zJEnrfcbUOg2ihV5MW7KT4PZm('يبدو أن هناك مشكلة في الاشتراك',jjEwJpmd2v0oxBRP1Dyu)
	if IxdSqDFvuO8wYb7f6KVJsTBGiycg and DTzBh4YjkKagtqRQx8wIHf5V3cU and dRMiZfl719XHzp3ENycUOF68k=='Active':
		KteLZCbM8W0FqE2OBx1(pGYKHZgqFX3B,'.\tChecking IPTV URL   [ IPTV account is OK ]   [ '+IxdSqDFvuO8wYb7f6KVJsTBGiycg+' ]')
		YpiyX9QrtV7zUehHq0RKgdCLjW = True
	else:
		KteLZCbM8W0FqE2OBx1(VRQE4jsXHSfhPWo5DgLwxGk,'Checking IPTV URL   [ Does not work ]   [ '+IxdSqDFvuO8wYb7f6KVJsTBGiycg+' ]')
		if WJrHC9Da7gRnmplf53: BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'فحص اشتراك ـIPTV','رابط اشتراك ـIPTV الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـIPTV وقم بإضافة رابط ـIPTV جديد أو قم بإصلاح الرابط القديم')
		YpiyX9QrtV7zUehHq0RKgdCLjW = False
	return YpiyX9QrtV7zUehHq0RKgdCLjW,c9EDgwAj2GnCXtqB,R1RWlgS0kiJEFL3cX2famq
def qJQdtBXVnP9EFwlvOKMLecDb(ZZNvmiGjlpwIOx,Et7IhqupLyZ8deaolcjx,IjF9xVMKtS20UOZahnu5zDAcQ,Z5nl0jQD6XTI8ux,WJrHC9Da7gRnmplf53=True):
	if not Z5nl0jQD6XTI8ux: Z5nl0jQD6XTI8ux = '1'
	if not OhBPub8QYNceaq3W(ZZNvmiGjlpwIOx,WJrHC9Da7gRnmplf53): return
	Zp5LawF3h1OU0xyucVqzk = Uk0JAvcrY6X(ZZNvmiGjlpwIOx,Et7IhqupLyZ8deaolcjx)
	tw5Zql97GHv4Cu1jEY8PDBy6 = Mqk51CFBym0pIQXZLsOxSJ(Zp5LawF3h1OU0xyucVqzk,'list',Et7IhqupLyZ8deaolcjx,IjF9xVMKtS20UOZahnu5zDAcQ)
	vXYFdtOMoWGuNyEr2ew8 = int(Z5nl0jQD6XTI8ux)*100
	IiZHcxgF0wWrVUKSukdzDAnb = vXYFdtOMoWGuNyEr2ew8-100
	for kCaIufXo1F0TyL7gtcJV5bneijMWHv,NiUSJbP8kMVZY,O9z5L3KtXqPEMepJQ0,efLKh7nE5X8UAgBRil3yZ in tw5Zql97GHv4Cu1jEY8PDBy6[IiZHcxgF0wWrVUKSukdzDAnb:vXYFdtOMoWGuNyEr2ew8]:
		GISLirb8FH = ('GROUPED' in Et7IhqupLyZ8deaolcjx or Et7IhqupLyZ8deaolcjx=='ALL')
		oUV67q9SAXCic2Jdr = ('GROUPED' not in Et7IhqupLyZ8deaolcjx and Et7IhqupLyZ8deaolcjx!='ALL')
		if GISLirb8FH or oUV67q9SAXCic2Jdr:
			if   'ARCHIVED'  in Et7IhqupLyZ8deaolcjx: vNRpDl1awktg7QP4m0KGqMTS2i.append(['folder',O50cprnq2W1DAgTiRZUm+NiUSJbP8kMVZY,O9z5L3KtXqPEMepJQ0,238,efLKh7nE5X8UAgBRil3yZ,hWGMqtBy4wuLaVcj,'ARCHIVED',hWGMqtBy4wuLaVcj,{'folder':ZZNvmiGjlpwIOx}])
			elif 'EPG' 		 in Et7IhqupLyZ8deaolcjx: vNRpDl1awktg7QP4m0KGqMTS2i.append(['folder',O50cprnq2W1DAgTiRZUm+NiUSJbP8kMVZY,O9z5L3KtXqPEMepJQ0,238,efLKh7nE5X8UAgBRil3yZ,hWGMqtBy4wuLaVcj,'FULL_EPG',hWGMqtBy4wuLaVcj,{'folder':ZZNvmiGjlpwIOx}])
			elif 'TIMESHIFT' in Et7IhqupLyZ8deaolcjx: vNRpDl1awktg7QP4m0KGqMTS2i.append(['folder',O50cprnq2W1DAgTiRZUm+NiUSJbP8kMVZY,O9z5L3KtXqPEMepJQ0,238,efLKh7nE5X8UAgBRil3yZ,hWGMqtBy4wuLaVcj,'TIMESHIFT',hWGMqtBy4wuLaVcj,{'folder':ZZNvmiGjlpwIOx}])
			elif 'LIVE' 	 in Et7IhqupLyZ8deaolcjx: vNRpDl1awktg7QP4m0KGqMTS2i.append(['live',O50cprnq2W1DAgTiRZUm+NiUSJbP8kMVZY,O9z5L3KtXqPEMepJQ0,235,efLKh7nE5X8UAgBRil3yZ,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,kCaIufXo1F0TyL7gtcJV5bneijMWHv,{'folder':ZZNvmiGjlpwIOx}])
			else: vNRpDl1awktg7QP4m0KGqMTS2i.append(['video',O50cprnq2W1DAgTiRZUm+NiUSJbP8kMVZY,O9z5L3KtXqPEMepJQ0,235,efLKh7nE5X8UAgBRil3yZ,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,{'folder':ZZNvmiGjlpwIOx}])
	xYt7uXLKMInBEvH8 = len(tw5Zql97GHv4Cu1jEY8PDBy6)
	XzIHbY0Q5OD(ZZNvmiGjlpwIOx,Z5nl0jQD6XTI8ux,Et7IhqupLyZ8deaolcjx,234,xYt7uXLKMInBEvH8,IjF9xVMKtS20UOZahnu5zDAcQ)
	return
def IINsFREUSoTY5aK3i9ewv1Dr(inmlvL5kH7A):
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',inmlvL5kH7A+'هذه القائمة إما فارغة أو غير موجودة',hWGMqtBy4wuLaVcj,9999)
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',inmlvL5kH7A+'أو الخدمة غير موجودة في اشتراكك',hWGMqtBy4wuLaVcj,9999)
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',inmlvL5kH7A+'أو رابط IPTVـ الذي أنت أضفته غير صحيح',hWGMqtBy4wuLaVcj,9999)
	return
def YDs4gfOMR8rQeSoqnUXwxCEa6BlP1(ZZNvmiGjlpwIOx,Et7IhqupLyZ8deaolcjx,IjF9xVMKtS20UOZahnu5zDAcQ,Z5nl0jQD6XTI8ux,Q6QGtAwDMR3OvKFHP=hWGMqtBy4wuLaVcj,WJrHC9Da7gRnmplf53=True):
	if not Z5nl0jQD6XTI8ux: Z5nl0jQD6XTI8ux = '1'
	inmlvL5kH7A = O50cprnq2W1DAgTiRZUm
	if not OhBPub8QYNceaq3W(ZZNvmiGjlpwIOx,WJrHC9Da7gRnmplf53): return False
	if '__SERIES__' in IjF9xVMKtS20UOZahnu5zDAcQ: pj3wZcWzNR1I6qG2ParH8Q,VoekOE9Bu4ZHPqz3CmlNaw7DKfbQA = IjF9xVMKtS20UOZahnu5zDAcQ.split('__SERIES__')
	else: pj3wZcWzNR1I6qG2ParH8Q,VoekOE9Bu4ZHPqz3CmlNaw7DKfbQA = IjF9xVMKtS20UOZahnu5zDAcQ,hWGMqtBy4wuLaVcj
	Zp5LawF3h1OU0xyucVqzk = Uk0JAvcrY6X(ZZNvmiGjlpwIOx,Et7IhqupLyZ8deaolcjx)
	MV0JxD7roKlXW3ybS = Mqk51CFBym0pIQXZLsOxSJ(Zp5LawF3h1OU0xyucVqzk,'list',Et7IhqupLyZ8deaolcjx,'__GROUPS__')
	if not MV0JxD7roKlXW3ybS: return False
	yoge6hA5cBbVldOz = []
	for NCyaEWFD0HwzO7chxlv8jupKItGB9,efLKh7nE5X8UAgBRil3yZ in MV0JxD7roKlXW3ybS:
		if Q6QGtAwDMR3OvKFHP:
			if '__SERIES__' in NCyaEWFD0HwzO7chxlv8jupKItGB9: inmlvL5kH7A = 'SERIES'
			elif '!!__UNKNOWN__!!' in NCyaEWFD0HwzO7chxlv8jupKItGB9: inmlvL5kH7A = 'UNKNOWN'
			elif 'LIVE' in Et7IhqupLyZ8deaolcjx: inmlvL5kH7A = 'LIVE'
			else: inmlvL5kH7A = 'VIDEOS'
			inmlvL5kH7A = ','+hXB0vKVQ5PRI91SDTprMdfuHEm4+inmlvL5kH7A+': '+YYSh2J6BIrsm8
		if '__SERIES__' in NCyaEWFD0HwzO7chxlv8jupKItGB9: ABoEGOZSn6Ps,h3hnLaK67xNWBcd92wJfXg = NCyaEWFD0HwzO7chxlv8jupKItGB9.split('__SERIES__')
		else: ABoEGOZSn6Ps,h3hnLaK67xNWBcd92wJfXg = NCyaEWFD0HwzO7chxlv8jupKItGB9,hWGMqtBy4wuLaVcj
		if not IjF9xVMKtS20UOZahnu5zDAcQ:
			if ABoEGOZSn6Ps in yoge6hA5cBbVldOz: continue
			yoge6hA5cBbVldOz.append(ABoEGOZSn6Ps)
			if 'RANDOM' in Q6QGtAwDMR3OvKFHP: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',inmlvL5kH7A+ABoEGOZSn6Ps,Et7IhqupLyZ8deaolcjx,167,hWGMqtBy4wuLaVcj,'1',NCyaEWFD0HwzO7chxlv8jupKItGB9,hWGMqtBy4wuLaVcj,{'folder':ZZNvmiGjlpwIOx})
			elif '__SERIES__' in NCyaEWFD0HwzO7chxlv8jupKItGB9: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',inmlvL5kH7A+ABoEGOZSn6Ps,Et7IhqupLyZ8deaolcjx,233,hWGMqtBy4wuLaVcj,'1',NCyaEWFD0HwzO7chxlv8jupKItGB9,hWGMqtBy4wuLaVcj,{'folder':ZZNvmiGjlpwIOx})
			else: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',inmlvL5kH7A+ABoEGOZSn6Ps,Et7IhqupLyZ8deaolcjx,234,hWGMqtBy4wuLaVcj,'1',NCyaEWFD0HwzO7chxlv8jupKItGB9,hWGMqtBy4wuLaVcj,{'folder':ZZNvmiGjlpwIOx})
		elif '__SERIES__' in NCyaEWFD0HwzO7chxlv8jupKItGB9 and ABoEGOZSn6Ps==pj3wZcWzNR1I6qG2ParH8Q:
			if h3hnLaK67xNWBcd92wJfXg in yoge6hA5cBbVldOz: continue
			yoge6hA5cBbVldOz.append(h3hnLaK67xNWBcd92wJfXg)
			if 'RANDOM' in Q6QGtAwDMR3OvKFHP: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',inmlvL5kH7A+h3hnLaK67xNWBcd92wJfXg,Et7IhqupLyZ8deaolcjx,167,hWGMqtBy4wuLaVcj,'1',NCyaEWFD0HwzO7chxlv8jupKItGB9,hWGMqtBy4wuLaVcj,{'folder':ZZNvmiGjlpwIOx})
			else: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',inmlvL5kH7A+h3hnLaK67xNWBcd92wJfXg,Et7IhqupLyZ8deaolcjx,234,efLKh7nE5X8UAgBRil3yZ,'1',NCyaEWFD0HwzO7chxlv8jupKItGB9,hWGMqtBy4wuLaVcj,{'folder':ZZNvmiGjlpwIOx})
	vNRpDl1awktg7QP4m0KGqMTS2i[:] = sorted(vNRpDl1awktg7QP4m0KGqMTS2i,reverse=False,key=lambda W6kuMbXBPcHdlyNGxeZ3T: W6kuMbXBPcHdlyNGxeZ3T[1].lower())
	if not Q6QGtAwDMR3OvKFHP:
		vXYFdtOMoWGuNyEr2ew8 = int(Z5nl0jQD6XTI8ux)*100
		IiZHcxgF0wWrVUKSukdzDAnb = vXYFdtOMoWGuNyEr2ew8-100
		xYt7uXLKMInBEvH8 = len(vNRpDl1awktg7QP4m0KGqMTS2i)
		vNRpDl1awktg7QP4m0KGqMTS2i[:] = vNRpDl1awktg7QP4m0KGqMTS2i[IiZHcxgF0wWrVUKSukdzDAnb:vXYFdtOMoWGuNyEr2ew8]
		XzIHbY0Q5OD(ZZNvmiGjlpwIOx,Z5nl0jQD6XTI8ux,Et7IhqupLyZ8deaolcjx,233,xYt7uXLKMInBEvH8,IjF9xVMKtS20UOZahnu5zDAcQ)
	return True
def AAi0D8X54VISxHgUzPC(ZZNvmiGjlpwIOx,O9z5L3KtXqPEMepJQ0,BXDwKRQgzePubSMLTZjCIAicl):
	if not OhBPub8QYNceaq3W(ZZNvmiGjlpwIOx,True): return
	eE4wIviRq52y316 = b5bp1UwmZdnxiEJ3DlSu6hMzqX2v(ZZNvmiGjlpwIOx)
	ZFk5jfxwGBStqVY = ee8c0jzrTntGSUdRJm.getSetting('av.iptv.timestamp_'+ZZNvmiGjlpwIOx)
	if not ZFk5jfxwGBStqVY or IHKJoQ8PwW4pNBR6GTAMVz2hdfC5my-int(ZFk5jfxwGBStqVY)>24*LOchm76Z8SuMaq1PGCT:
		YpiyX9QrtV7zUehHq0RKgdCLjW,c9EDgwAj2GnCXtqB,R1RWlgS0kiJEFL3cX2famq = NjdI2F6vbK(ZZNvmiGjlpwIOx,False)
		if not YpiyX9QrtV7zUehHq0RKgdCLjW: return
	ss5VcGK8hk1p3HtoPgAniZa = int(ee8c0jzrTntGSUdRJm.getSetting('av.iptv.timediff_'+ZZNvmiGjlpwIOx))
	WJ4jm6MzHbSQcO9 = ee8c0jzrTntGSUdRJm.getSetting('av.iptv.server_'+ZZNvmiGjlpwIOx)
	wNf6hz8Vtq2J4eULdBpRFCG5imj = ee8c0jzrTntGSUdRJm.getSetting('av.iptv.username_'+ZZNvmiGjlpwIOx)
	VyaUHwQzXLqJS = ee8c0jzrTntGSUdRJm.getSetting('av.iptv.password_'+ZZNvmiGjlpwIOx)
	Au51npoSdfwzGjPeqHZ9rb3xKUmv = O9z5L3KtXqPEMepJQ0.split('/')
	wQaS0Bqlczx4jmI8O1 = Au51npoSdfwzGjPeqHZ9rb3xKUmv[-1].replace('.ts',hWGMqtBy4wuLaVcj).replace('.m3u8',hWGMqtBy4wuLaVcj)
	if BXDwKRQgzePubSMLTZjCIAicl=='SHORT_EPG': DQw7Wgy4vc1GXxhzEdokYqlCVPJK = 'get_short_epg'
	else: DQw7Wgy4vc1GXxhzEdokYqlCVPJK = 'get_simple_data_table'
	IxdSqDFvuO8wYb7f6KVJsTBGiycg,LJmA1qSt9aXc,WJ4jm6MzHbSQcO9,wNf6hz8Vtq2J4eULdBpRFCG5imj,VyaUHwQzXLqJS = WWKXJ7yo4Gb3qYsmvg5BCVHhj0P(ZZNvmiGjlpwIOx)
	if not wNf6hz8Vtq2J4eULdBpRFCG5imj: return
	lArTF7bxX0feIqLR4upUwEVd9h = IxdSqDFvuO8wYb7f6KVJsTBGiycg+'&action='+DQw7Wgy4vc1GXxhzEdokYqlCVPJK+'&stream_id='+wQaS0Bqlczx4jmI8O1
	zJjQP6hXe8vbdrTDq1EmZwncYUL = cBayH2Pkgj(lke5D6CpaAXPdEZyrBSw7T,lArTF7bxX0feIqLR4upUwEVd9h,hWGMqtBy4wuLaVcj,eE4wIviRq52y316,hWGMqtBy4wuLaVcj,'IPTV-EPG_ITEMS-2nd')
	IW76pBTiGcveZtSm = Cy9ow3c21nABMjzqeaIT('dict',zJjQP6hXe8vbdrTDq1EmZwncYUL)
	rc8CEX0ZmigAwLbU7NkFjf = IW76pBTiGcveZtSm['epg_listings']
	XCdr1Hb3wlUxymsjfVN = []
	if BXDwKRQgzePubSMLTZjCIAicl in ['ARCHIVED','TIMESHIFT']:
		for C74q0HGvOJI in rc8CEX0ZmigAwLbU7NkFjf:
			if C74q0HGvOJI['has_archive']==1:
				XCdr1Hb3wlUxymsjfVN.append(C74q0HGvOJI)
				if BXDwKRQgzePubSMLTZjCIAicl in ['TIMESHIFT']: break
		if not XCdr1Hb3wlUxymsjfVN: return
		RLDCGt8kq3OVmnzgx1rbi2f7F('link',O50cprnq2W1DAgTiRZUm+hXB0vKVQ5PRI91SDTprMdfuHEm4+'الملفات الأولي بهذه القائمة قد لا تعمل'+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
		if BXDwKRQgzePubSMLTZjCIAicl in ['TIMESHIFT']:
			rXEMLgHQG4etUOoIyZNK6P = 2
			tthCSGYozjvUeNlr6u4ybTsPc = rXEMLgHQG4etUOoIyZNK6P*LOchm76Z8SuMaq1PGCT
			XCdr1Hb3wlUxymsjfVN = []
			SfqCb40zvuO8GIra2iy1ETjPFQskM = int(int(C74q0HGvOJI['start_timestamp'])/tthCSGYozjvUeNlr6u4ybTsPc)*tthCSGYozjvUeNlr6u4ybTsPc
			Ux7RWJQbzi4rI0T2k = IHKJoQ8PwW4pNBR6GTAMVz2hdfC5my+tthCSGYozjvUeNlr6u4ybTsPc
			erBtf3Ew7WqdJFxlZLPHb = int((Ux7RWJQbzi4rI0T2k-SfqCb40zvuO8GIra2iy1ETjPFQskM)/LOchm76Z8SuMaq1PGCT)
			for Rjlrpdef3CVLhnM in range(erBtf3Ew7WqdJFxlZLPHb):
				if Rjlrpdef3CVLhnM>=6:
					if Rjlrpdef3CVLhnM%rXEMLgHQG4etUOoIyZNK6P!=0: continue
					GG4OqC6TJgXjQMLARUWlb2vI = tthCSGYozjvUeNlr6u4ybTsPc
				else: GG4OqC6TJgXjQMLARUWlb2vI = tthCSGYozjvUeNlr6u4ybTsPc//2
				HdyRSor0Ae86siJ5YQ = SfqCb40zvuO8GIra2iy1ETjPFQskM+Rjlrpdef3CVLhnM*LOchm76Z8SuMaq1PGCT
				C74q0HGvOJI = {}
				C74q0HGvOJI['title'] = hWGMqtBy4wuLaVcj
				BS7FRhc4QA9xLaJs = HB5PvxRhwM.localtime(HdyRSor0Ae86siJ5YQ-ss5VcGK8hk1p3HtoPgAniZa-LOchm76Z8SuMaq1PGCT)
				C74q0HGvOJI['start'] = HB5PvxRhwM.strftime('%Y.%m.%d %H:%M:%S',BS7FRhc4QA9xLaJs)
				C74q0HGvOJI['start_timestamp'] = str(HdyRSor0Ae86siJ5YQ)
				C74q0HGvOJI['stop_timestamp'] = str(HdyRSor0Ae86siJ5YQ+GG4OqC6TJgXjQMLARUWlb2vI)
				XCdr1Hb3wlUxymsjfVN.append(C74q0HGvOJI)
	elif BXDwKRQgzePubSMLTZjCIAicl in ['SHORT_EPG','FULL_EPG']: XCdr1Hb3wlUxymsjfVN = rc8CEX0ZmigAwLbU7NkFjf
	if BXDwKRQgzePubSMLTZjCIAicl=='FULL_EPG' and len(XCdr1Hb3wlUxymsjfVN)>0:
		RLDCGt8kq3OVmnzgx1rbi2f7F('link',O50cprnq2W1DAgTiRZUm+hXB0vKVQ5PRI91SDTprMdfuHEm4+'هذه قائمة برامج القنوات (جدول فقط)ـ'+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	fjHylWVX3aScImKgRA4Zzkie97JUsr = []
	efLKh7nE5X8UAgBRil3yZ = MMk8qKvcJe4fQHm3EG7diBD5.getInfoLabel('ListItem.Icon')
	for C74q0HGvOJI in XCdr1Hb3wlUxymsjfVN:
		NiUSJbP8kMVZY = FxG0Q9kuBSmTyM.b64decode(C74q0HGvOJI['title'])
		if H4qZ2hwilNJYTmCFEQyaSs98cPM0gR: NiUSJbP8kMVZY = NiUSJbP8kMVZY.decode(a7VXeDU82IfQEnPZAdiT)
		HdyRSor0Ae86siJ5YQ = int(C74q0HGvOJI['start_timestamp'])
		AAM2tcNEBnuP = int(C74q0HGvOJI['stop_timestamp'])
		EJLjRqlBpKMAYiFcxGbV5t06 = str(int((AAM2tcNEBnuP-HdyRSor0Ae86siJ5YQ+59)/60))
		wIPN0pWjqMYQKDS3 = C74q0HGvOJI['start'].replace(Mpsm2VF1OBnCRvK3qf6,':')
		BS7FRhc4QA9xLaJs = HB5PvxRhwM.localtime(HdyRSor0Ae86siJ5YQ-LOchm76Z8SuMaq1PGCT)
		et9L0ZEYfJQGp5uT = HB5PvxRhwM.strftime('%H:%M',BS7FRhc4QA9xLaJs)
		OosI1Hn3wqjPS92CZ8G6 = HB5PvxRhwM.strftime('%a',BS7FRhc4QA9xLaJs)
		if BXDwKRQgzePubSMLTZjCIAicl=='SHORT_EPG': NiUSJbP8kMVZY = soMVfbr6WtpNlcSA+et9L0ZEYfJQGp5uT+' ـ '+NiUSJbP8kMVZY+YYSh2J6BIrsm8
		elif BXDwKRQgzePubSMLTZjCIAicl=='TIMESHIFT': NiUSJbP8kMVZY = OosI1Hn3wqjPS92CZ8G6+Mpsm2VF1OBnCRvK3qf6+et9L0ZEYfJQGp5uT+' ('+EJLjRqlBpKMAYiFcxGbV5t06+'min)'
		else: NiUSJbP8kMVZY = OosI1Hn3wqjPS92CZ8G6+Mpsm2VF1OBnCRvK3qf6+et9L0ZEYfJQGp5uT+' ('+EJLjRqlBpKMAYiFcxGbV5t06+'min)   '+NiUSJbP8kMVZY+' ـ'
		if BXDwKRQgzePubSMLTZjCIAicl in ['ARCHIVED','FULL_EPG','TIMESHIFT']:
			Cj4zWKQcyhqHBiLOsISkV = WJ4jm6MzHbSQcO9+'/timeshift/'+wNf6hz8Vtq2J4eULdBpRFCG5imj+'/'+VyaUHwQzXLqJS+'/'+EJLjRqlBpKMAYiFcxGbV5t06+'/'+wIPN0pWjqMYQKDS3+'/'+wQaS0Bqlczx4jmI8O1+'.m3u8'
			if BXDwKRQgzePubSMLTZjCIAicl=='FULL_EPG': RLDCGt8kq3OVmnzgx1rbi2f7F('link',O50cprnq2W1DAgTiRZUm+NiUSJbP8kMVZY,Cj4zWKQcyhqHBiLOsISkV,9999,efLKh7nE5X8UAgBRil3yZ,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,{'folder':ZZNvmiGjlpwIOx})
			else: RLDCGt8kq3OVmnzgx1rbi2f7F('video',O50cprnq2W1DAgTiRZUm+NiUSJbP8kMVZY,Cj4zWKQcyhqHBiLOsISkV,235,efLKh7nE5X8UAgBRil3yZ,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,{'folder':ZZNvmiGjlpwIOx})
		fjHylWVX3aScImKgRA4Zzkie97JUsr.append(NiUSJbP8kMVZY)
	if BXDwKRQgzePubSMLTZjCIAicl=='SHORT_EPG' and fjHylWVX3aScImKgRA4Zzkie97JUsr: vbOatKieVQzcLp0 = tw36hiVuYD1G9jlBp(fjHylWVX3aScImKgRA4Zzkie97JUsr)
	return fjHylWVX3aScImKgRA4Zzkie97JUsr
def sco9jVPZ3liOXxy2BShM(ZZNvmiGjlpwIOx):
	if not OhBPub8QYNceaq3W(ZZNvmiGjlpwIOx,True): return
	WJ4jm6MzHbSQcO9,ggLhaOeDSyFqMiYbfuzIH,hVjJTuQW3bPdrCxRLDZ4EK10 = hWGMqtBy4wuLaVcj,0,0
	YpiyX9QrtV7zUehHq0RKgdCLjW,c9EDgwAj2GnCXtqB,R1RWlgS0kiJEFL3cX2famq = NjdI2F6vbK(ZZNvmiGjlpwIOx,False)
	if YpiyX9QrtV7zUehHq0RKgdCLjW:
		fT3EV2a8M5R = BNeOTHu75qV6p(c9EDgwAj2GnCXtqB)
		ggLhaOeDSyFqMiYbfuzIH = WWTntIZ7hBCpPOdScNwrsX(fT3EV2a8M5R[0],int(R1RWlgS0kiJEFL3cX2famq))
		Zp5LawF3h1OU0xyucVqzk = Uk0JAvcrY6X(ZZNvmiGjlpwIOx,'LIVE_GROUPED')
		Y2YJtGk97sEMgD6LRplT85Ovm = Mqk51CFBym0pIQXZLsOxSJ(Zp5LawF3h1OU0xyucVqzk,'list','LIVE_GROUPED')
		tw5Zql97GHv4Cu1jEY8PDBy6 = Mqk51CFBym0pIQXZLsOxSJ(Zp5LawF3h1OU0xyucVqzk,'list','LIVE_GROUPED',Y2YJtGk97sEMgD6LRplT85Ovm[1])
		O9z5L3KtXqPEMepJQ0 = tw5Zql97GHv4Cu1jEY8PDBy6[0][2]
		WdzcxuQ1Dyg4YOl7C9qMeAZ = trdVA0JvFaD.findall('://(.*?)/',O9z5L3KtXqPEMepJQ0,trdVA0JvFaD.DOTALL)
		WdzcxuQ1Dyg4YOl7C9qMeAZ = WdzcxuQ1Dyg4YOl7C9qMeAZ[0]
		if ':' in WdzcxuQ1Dyg4YOl7C9qMeAZ: nnUhFMAP3wcpsJIXT4daH7Y,ooLfthKA46DplaTdz2 = WdzcxuQ1Dyg4YOl7C9qMeAZ.split(':')
		else: nnUhFMAP3wcpsJIXT4daH7Y,ooLfthKA46DplaTdz2 = WdzcxuQ1Dyg4YOl7C9qMeAZ,'80'
		vJ5C4e8aUnErS97yqVXY1 = BNeOTHu75qV6p(nnUhFMAP3wcpsJIXT4daH7Y)
		hVjJTuQW3bPdrCxRLDZ4EK10 = WWTntIZ7hBCpPOdScNwrsX(vJ5C4e8aUnErS97yqVXY1[0],int(ooLfthKA46DplaTdz2))
	if ggLhaOeDSyFqMiYbfuzIH and hVjJTuQW3bPdrCxRLDZ4EK10:
		jjEwJpmd2v0oxBRP1Dyu = 'هل تريد استخدام السيرفر الأصلي أم السيرفر الأسرع ؟!!'
		jjEwJpmd2v0oxBRP1Dyu += '\n\n'+'وقت ضائع في السيرفر الأصلي'+NXMOzZjYsmS9pf+str(int(hVjJTuQW3bPdrCxRLDZ4EK10*1000))+' ملي ثانية'
		jjEwJpmd2v0oxBRP1Dyu += '\n\n'+'وقت ضائع في السيرفر البديل'+NXMOzZjYsmS9pf+str(int(ggLhaOeDSyFqMiYbfuzIH*1000))+' ملي ثانية'
		MeYJm41G2j6Wn = XVmKrby29eCGMnlEY6jz0HNOR('center','السيرفر الأصلي','السيرفر الأسرع','رسالة من المبرمج',jjEwJpmd2v0oxBRP1Dyu)
		if MeYJm41G2j6Wn==1 and ggLhaOeDSyFqMiYbfuzIH<hVjJTuQW3bPdrCxRLDZ4EK10: WJ4jm6MzHbSQcO9 = c9EDgwAj2GnCXtqB+':'+R1RWlgS0kiJEFL3cX2famq
	else: BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'رسالة من المبرمج','البرنامج لم يجد السيرفر البديل')
	ee8c0jzrTntGSUdRJm.setSetting('av.iptv.server_'+ZZNvmiGjlpwIOx,WJ4jm6MzHbSQcO9)
	return
def oanus6TxUFNAhSZKpJdYlEC4mV(ZZNvmiGjlpwIOx,O9z5L3KtXqPEMepJQ0,udRvjXt9cAfha5ZsBP3U):
	wWpTXn09dPz3k75Qyea8stNl4i = ee8c0jzrTntGSUdRJm.getSetting('av.iptv.useragent_'+ZZNvmiGjlpwIOx)
	mvgGdSLRQU = ee8c0jzrTntGSUdRJm.getSetting('av.iptv.referer_'+ZZNvmiGjlpwIOx)
	if wWpTXn09dPz3k75Qyea8stNl4i or mvgGdSLRQU:
		O9z5L3KtXqPEMepJQ0 += '|'
		if wWpTXn09dPz3k75Qyea8stNl4i: O9z5L3KtXqPEMepJQ0 += '&User-Agent='+wWpTXn09dPz3k75Qyea8stNl4i
		if mvgGdSLRQU: O9z5L3KtXqPEMepJQ0 += '&Referer='+mvgGdSLRQU
		O9z5L3KtXqPEMepJQ0 = O9z5L3KtXqPEMepJQ0.replace('|&','|')
	gDEw51mqAJGUW7QOI4akz2H = ee8c0jzrTntGSUdRJm.getSetting('av.iptv.server_'+ZZNvmiGjlpwIOx)
	if gDEw51mqAJGUW7QOI4akz2H:
		voMbHuWfJX7SglG = trdVA0JvFaD.findall('://(.*?)/',O9z5L3KtXqPEMepJQ0,trdVA0JvFaD.DOTALL)
		O9z5L3KtXqPEMepJQ0 = O9z5L3KtXqPEMepJQ0.replace(voMbHuWfJX7SglG[0],gDEw51mqAJGUW7QOI4akz2H)
	vOq38Y4XVZwdE(O9z5L3KtXqPEMepJQ0,bBER0HlPYh4ZXm6ILWw,udRvjXt9cAfha5ZsBP3U)
	return
def ZpEic0wWLfP1YNbUM7A(ZZNvmiGjlpwIOx):
	BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'رسالة من المبرمج','تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـIPTV أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـIPTV تحتاج ـUser-Agent خاص')
	wWpTXn09dPz3k75Qyea8stNl4i = ee8c0jzrTntGSUdRJm.getSetting('av.iptv.useragent_'+ZZNvmiGjlpwIOx)
	PkyReSCYQpmDI = XVmKrby29eCGMnlEY6jz0HNOR('center','استخدام الأصلي','تعديل القديم',wWpTXn09dPz3k75Qyea8stNl4i,'هذا هو ـUser-Agent المستخدم حاليا مع ـIPTV الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـIPTV ؟!')
	if PkyReSCYQpmDI==1: wWpTXn09dPz3k75Qyea8stNl4i = TrzfUidpv1LyAYqwexHJDuS('أكتب ـIPTV User-Agent جديد',wWpTXn09dPz3k75Qyea8stNl4i,True)
	else: wWpTXn09dPz3k75Qyea8stNl4i = 'Unknown'
	if wWpTXn09dPz3k75Qyea8stNl4i==Mpsm2VF1OBnCRvK3qf6:
		BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'رسالة من المبرمج','غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	PkyReSCYQpmDI = XVmKrby29eCGMnlEY6jz0HNOR('center',hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,wWpTXn09dPz3k75Qyea8stNl4i,'هل تريد استخدام هذا ـUser-Agent بدلا من  القديم ؟')
	if PkyReSCYQpmDI!=1:
		BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'رسالة من المبرمج','تم الإلغاء')
		return
	ee8c0jzrTntGSUdRJm.setSetting('av.iptv.useragent_'+ZZNvmiGjlpwIOx,wWpTXn09dPz3k75Qyea8stNl4i)
	SRc0wiMvLgkPJ5zhpbUfHn2(ZZNvmiGjlpwIOx)
	return
def zTAGmbQWSUavCEOB0RnkxD1KeoVdt(ZZNvmiGjlpwIOx):
	BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'رسالة من المبرمج','تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـIPTV أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـIPTV تحتاج ـReferer خاص')
	mvgGdSLRQU = ee8c0jzrTntGSUdRJm.getSetting('av.iptv.referer_'+ZZNvmiGjlpwIOx)
	PkyReSCYQpmDI = XVmKrby29eCGMnlEY6jz0HNOR('center','استخدام الأصلي','تعديل القديم',mvgGdSLRQU,'هذا هو ـReferer المستخدم حاليا مع ـIPTV الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـIPTV ؟!')
	if PkyReSCYQpmDI==1: mvgGdSLRQU = TrzfUidpv1LyAYqwexHJDuS('أكتب ـIPTV Referer جديد',mvgGdSLRQU,True)
	else: mvgGdSLRQU = hWGMqtBy4wuLaVcj
	if mvgGdSLRQU==Mpsm2VF1OBnCRvK3qf6:
		BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'رسالة من المبرمج','غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	PkyReSCYQpmDI = XVmKrby29eCGMnlEY6jz0HNOR('center',hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,mvgGdSLRQU,'هل تريد استخدام هذا ـReferer بدلا من  القديم ؟')
	if PkyReSCYQpmDI!=1:
		BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'رسالة من المبرمج','تم الإلغاء')
		return
	ee8c0jzrTntGSUdRJm.setSetting('av.iptv.referer_'+ZZNvmiGjlpwIOx,mvgGdSLRQU)
	SRc0wiMvLgkPJ5zhpbUfHn2(ZZNvmiGjlpwIOx)
	return
def WWKXJ7yo4Gb3qYsmvg5BCVHhj0P(ZZNvmiGjlpwIOx,yG2ehLzcpkZ4UsVAENDmdrtojX8F1=hWGMqtBy4wuLaVcj):
	if not yG2ehLzcpkZ4UsVAENDmdrtojX8F1: yG2ehLzcpkZ4UsVAENDmdrtojX8F1 = ee8c0jzrTntGSUdRJm.getSetting('av.iptv.url_'+ZZNvmiGjlpwIOx)
	WJ4jm6MzHbSQcO9 = RRNODILCtGzvgpx(yG2ehLzcpkZ4UsVAENDmdrtojX8F1,'url')
	wNf6hz8Vtq2J4eULdBpRFCG5imj = trdVA0JvFaD.findall('username=(.*?)&',yG2ehLzcpkZ4UsVAENDmdrtojX8F1+'&',trdVA0JvFaD.DOTALL)
	VyaUHwQzXLqJS = trdVA0JvFaD.findall('password=(.*?)&',yG2ehLzcpkZ4UsVAENDmdrtojX8F1+'&',trdVA0JvFaD.DOTALL)
	if not wNf6hz8Vtq2J4eULdBpRFCG5imj or not VyaUHwQzXLqJS:
		BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'فحص اشتراك ـIPTV','رابط اشتراك ـIPTV الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـIPTV وقم بإضافة رابط ـIPTV جديد أو قم بإصلاح الرابط القديم')
		return hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj
	wNf6hz8Vtq2J4eULdBpRFCG5imj = wNf6hz8Vtq2J4eULdBpRFCG5imj[0]
	VyaUHwQzXLqJS = VyaUHwQzXLqJS[0]
	IxdSqDFvuO8wYb7f6KVJsTBGiycg = WJ4jm6MzHbSQcO9+'/player_api.php?username='+wNf6hz8Vtq2J4eULdBpRFCG5imj+'&password='+VyaUHwQzXLqJS
	LJmA1qSt9aXc = WJ4jm6MzHbSQcO9+'/get.php?username='+wNf6hz8Vtq2J4eULdBpRFCG5imj+'&password='+VyaUHwQzXLqJS+'&type=m3u_plus'
	return IxdSqDFvuO8wYb7f6KVJsTBGiycg,LJmA1qSt9aXc,WJ4jm6MzHbSQcO9,wNf6hz8Vtq2J4eULdBpRFCG5imj,VyaUHwQzXLqJS
def SV8l1AumTRboUFZwiIydaPYrzDhv(ZZNvmiGjlpwIOx,G1Rau0zVemAPwOq2bxQJoFIs7vUT=hWGMqtBy4wuLaVcj):
	WgrvNFHaR5bDzCLAl8pMcQhBXd4Y = G1Rau0zVemAPwOq2bxQJoFIs7vUT.replace('/','_').replace(':','_').replace('.','_')
	WgrvNFHaR5bDzCLAl8pMcQhBXd4Y = WgrvNFHaR5bDzCLAl8pMcQhBXd4Y.replace('?','_').replace('=','_').replace('&','_')
	WgrvNFHaR5bDzCLAl8pMcQhBXd4Y = WQvYkNg7SysPFLitlGEn6.path.join(vA0ImpguajeHKJ6P,WgrvNFHaR5bDzCLAl8pMcQhBXd4Y).strip('.m3u')+'.m3u'
	return WgrvNFHaR5bDzCLAl8pMcQhBXd4Y
def iCfurd34Gnxt5N(ZZNvmiGjlpwIOx):
	haod7wNi9Rl1vF0GXpLZ5zOJ3 = ee8c0jzrTntGSUdRJm.getSetting('av.iptv.url_'+ZZNvmiGjlpwIOx)
	TDQWhuAHNyzRGr46vaj = True
	if haod7wNi9Rl1vF0GXpLZ5zOJ3:
		PkyReSCYQpmDI = jbQkTyxAerZR409gYFq('center','كتابة جديد','تعديل القديم','مسح القديم','الرابط الحالي هو:',hXB0vKVQ5PRI91SDTprMdfuHEm4+haod7wNi9Rl1vF0GXpLZ5zOJ3+YYSh2J6BIrsm8+'\n\n هذا هو رابط ـIPTV المسجل في البرنامج ... هل تريد تعديله أم تريد كتابة رابط جديد ؟!')
		if PkyReSCYQpmDI==-1: return
		elif PkyReSCYQpmDI==0: haod7wNi9Rl1vF0GXpLZ5zOJ3 = hWGMqtBy4wuLaVcj
		elif PkyReSCYQpmDI==2:
			PkyReSCYQpmDI = XVmKrby29eCGMnlEY6jz0HNOR('center',hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'رسالة من المبرمج','هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if PkyReSCYQpmDI in [-1,0]: return
			BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'رسالة من المبرمج','تم مسح الرابط')
			TDQWhuAHNyzRGr46vaj = False
			L35pcPqtm2O1eMEhJWFvQk = hWGMqtBy4wuLaVcj
	if TDQWhuAHNyzRGr46vaj:
		L35pcPqtm2O1eMEhJWFvQk = TrzfUidpv1LyAYqwexHJDuS('اكتب رابط ـIPTV كاملا',haod7wNi9Rl1vF0GXpLZ5zOJ3)
		L35pcPqtm2O1eMEhJWFvQk = L35pcPqtm2O1eMEhJWFvQk.strip(Mpsm2VF1OBnCRvK3qf6)
		if not L35pcPqtm2O1eMEhJWFvQk:
			PkyReSCYQpmDI = XVmKrby29eCGMnlEY6jz0HNOR('center',hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'رسالة من المبرمج','لقد قمت بإدخال رابط فارغ .. هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if PkyReSCYQpmDI in [-1,0]: return
			BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'رسالة من المبرمج','تم مسح الرابط')
	else:
		IxdSqDFvuO8wYb7f6KVJsTBGiycg,LJmA1qSt9aXc,WJ4jm6MzHbSQcO9,wNf6hz8Vtq2J4eULdBpRFCG5imj,VyaUHwQzXLqJS = WWKXJ7yo4Gb3qYsmvg5BCVHhj0P(ZZNvmiGjlpwIOx,L35pcPqtm2O1eMEhJWFvQk)
		if not wNf6hz8Vtq2J4eULdBpRFCG5imj: return
		jjEwJpmd2v0oxBRP1Dyu = 'هذه المعلومات تم أخذها من رابط ـIPTV الذي انت كتبته . هل تريد استخدامها ؟!\n'
		jjEwJpmd2v0oxBRP1Dyu += NXMOzZjYsmS9pf+soMVfbr6WtpNlcSA+WJ4jm6MzHbSQcO9+YYSh2J6BIrsm8+'عنوان السيرفر: '
		jjEwJpmd2v0oxBRP1Dyu += NXMOzZjYsmS9pf+soMVfbr6WtpNlcSA+wNf6hz8Vtq2J4eULdBpRFCG5imj+YYSh2J6BIrsm8+'اسم المستخدم: '
		jjEwJpmd2v0oxBRP1Dyu += NXMOzZjYsmS9pf+soMVfbr6WtpNlcSA+uSsphGHPNOF6iwA++'كلمة السر: '
		PkyReSCYQpmDI = XVmKrby29eCGMnlEY6jz0HNOR('right',hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'الرابط الجديد هو:',hXB0vKVQ5PRI91SDTprMdfuHEm4+L35pcPqtm2O1eMEhJWFvQk+YYSh2J6BIrsm8+'\n\n'+jjEwJpmd2v0oxBRP1Dyu)
		if PkyReSCYQpmDI!=1:
			BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'رسالة من المبرمج','تم الإلغاء')
			return
	ee8c0jzrTntGSUdRJm.setSetting('av.iptv.url_'+ZZNvmiGjlpwIOx,L35pcPqtm2O1eMEhJWFvQk)
	ee8c0jzrTntGSUdRJm.setSetting('av.iptv.timestamp_'+ZZNvmiGjlpwIOx,hWGMqtBy4wuLaVcj)
	ee8c0jzrTntGSUdRJm.setSetting('av.iptv.timediff_'+ZZNvmiGjlpwIOx,hWGMqtBy4wuLaVcj)
	wWpTXn09dPz3k75Qyea8stNl4i = ee8c0jzrTntGSUdRJm.getSetting('av.iptv.useragent_'+ZZNvmiGjlpwIOx)
	if not wWpTXn09dPz3k75Qyea8stNl4i: ee8c0jzrTntGSUdRJm.setSetting('av.iptv.useragent_'+ZZNvmiGjlpwIOx,'Unknown')
	JzYjMOuFif = XVmKrby29eCGMnlEY6jz0HNOR('center',hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,L35pcPqtm2O1eMEhJWFvQk+'\n\nتم تغير رابط اشتراك ـIPTV إلى هذا الرابط الجديد ... هل تريد فحص هذا الرابط الآن ؟')
	if JzYjMOuFif==1: YpiyX9QrtV7zUehHq0RKgdCLjW,c9EDgwAj2GnCXtqB,R1RWlgS0kiJEFL3cX2famq = NjdI2F6vbK(ZZNvmiGjlpwIOx,True)
	SRc0wiMvLgkPJ5zhpbUfHn2(ZZNvmiGjlpwIOx)
	return
def msUkacnOupri8H9dPNvtY0D3elCJE(KgUCchf0AS4luxk1zOrm2,pvZHdIfLWJ9RM2,eeprncjLGJAbykmgoMf7X61KI9tO,adzfw5H1NKAIjpZmVqoE04,BDc6tsV03u7E,uuk6b4oz9gUJAmLVljxYpMi8ThI,LJmA1qSt9aXc):
	tw5Zql97GHv4Cu1jEY8PDBy6,tROmFf3MpP0AXIqloC = [],[]
	ccpVTZQ9yq4kLxtCJmwgM5vbSj1 = ['.avi','.mp4','.mkv','.mp3','.webm','.aac']
	for VDvfJ2uLMsg1xjcN5wGkzlQi in KgUCchf0AS4luxk1zOrm2:
		if uuk6b4oz9gUJAmLVljxYpMi8ThI%473==0:
			CEIhS05OkFWGozARVZwnyrXf6(adzfw5H1NKAIjpZmVqoE04,40+int(10*uuk6b4oz9gUJAmLVljxYpMi8ThI/BDc6tsV03u7E),'قراءة الفيديوهات','الفيديو رقم:-',str(uuk6b4oz9gUJAmLVljxYpMi8ThI)+' / '+str(BDc6tsV03u7E))
			if adzfw5H1NKAIjpZmVqoE04.iscanceled():
				adzfw5H1NKAIjpZmVqoE04.close()
				return None,None,None
		O9z5L3KtXqPEMepJQ0 = trdVA0JvFaD.findall('^(.*?)\n+((http|https|rtmp).*?)$',VDvfJ2uLMsg1xjcN5wGkzlQi,trdVA0JvFaD.DOTALL)
		if O9z5L3KtXqPEMepJQ0:
			VDvfJ2uLMsg1xjcN5wGkzlQi,O9z5L3KtXqPEMepJQ0,KmPeHvQYBna8foZrX6Dz = O9z5L3KtXqPEMepJQ0[0]
			O9z5L3KtXqPEMepJQ0 = O9z5L3KtXqPEMepJQ0.replace(NXMOzZjYsmS9pf,hWGMqtBy4wuLaVcj)
			VDvfJ2uLMsg1xjcN5wGkzlQi = VDvfJ2uLMsg1xjcN5wGkzlQi.replace(NXMOzZjYsmS9pf,hWGMqtBy4wuLaVcj)
		else:
			tROmFf3MpP0AXIqloC.append({'line':VDvfJ2uLMsg1xjcN5wGkzlQi})
			continue
		vXn06xrNpWVZUGcMSf8oDQTstEiw,kCaIufXo1F0TyL7gtcJV5bneijMWHv,NCyaEWFD0HwzO7chxlv8jupKItGB9,NiUSJbP8kMVZY,udRvjXt9cAfha5ZsBP3U,mqYhiavDlScU9pP = {},hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,False
		try:
			VDvfJ2uLMsg1xjcN5wGkzlQi,NiUSJbP8kMVZY = VDvfJ2uLMsg1xjcN5wGkzlQi.rsplit('",',1)
			VDvfJ2uLMsg1xjcN5wGkzlQi = VDvfJ2uLMsg1xjcN5wGkzlQi+'"'
		except:
			try: VDvfJ2uLMsg1xjcN5wGkzlQi,NiUSJbP8kMVZY = VDvfJ2uLMsg1xjcN5wGkzlQi.rsplit('1,',1)
			except: NiUSJbP8kMVZY = hWGMqtBy4wuLaVcj
		vXn06xrNpWVZUGcMSf8oDQTstEiw['url'] = O9z5L3KtXqPEMepJQ0
		sha3UQqoKu1c8ERmO5IpPNVtSiA0L = trdVA0JvFaD.findall(' (.*?)="(.*?)"',VDvfJ2uLMsg1xjcN5wGkzlQi,trdVA0JvFaD.DOTALL)
		for W6kuMbXBPcHdlyNGxeZ3T,m8dJpRgAhYBX7VMx in sha3UQqoKu1c8ERmO5IpPNVtSiA0L:
			W6kuMbXBPcHdlyNGxeZ3T = W6kuMbXBPcHdlyNGxeZ3T.replace('"',hWGMqtBy4wuLaVcj).strip(Mpsm2VF1OBnCRvK3qf6)
			vXn06xrNpWVZUGcMSf8oDQTstEiw[W6kuMbXBPcHdlyNGxeZ3T] = m8dJpRgAhYBX7VMx.strip(Mpsm2VF1OBnCRvK3qf6)
		WkQ3McKsx9oVUJA7HSeqfF = list(vXn06xrNpWVZUGcMSf8oDQTstEiw.keys())
		if not NiUSJbP8kMVZY:
			if 'name' in WkQ3McKsx9oVUJA7HSeqfF and vXn06xrNpWVZUGcMSf8oDQTstEiw['name']: NiUSJbP8kMVZY = vXn06xrNpWVZUGcMSf8oDQTstEiw['name']
		vXn06xrNpWVZUGcMSf8oDQTstEiw['title'] = NiUSJbP8kMVZY.strip(Mpsm2VF1OBnCRvK3qf6).replace(FqcVAkh7WjIXHdDKf8nvuyRo,Mpsm2VF1OBnCRvK3qf6).replace(FqcVAkh7WjIXHdDKf8nvuyRo,Mpsm2VF1OBnCRvK3qf6)
		if 'logo' in WkQ3McKsx9oVUJA7HSeqfF:
			vXn06xrNpWVZUGcMSf8oDQTstEiw['img'] = vXn06xrNpWVZUGcMSf8oDQTstEiw['logo']
			del vXn06xrNpWVZUGcMSf8oDQTstEiw['logo']
		else: vXn06xrNpWVZUGcMSf8oDQTstEiw['img'] = hWGMqtBy4wuLaVcj
		if 'group' in WkQ3McKsx9oVUJA7HSeqfF and vXn06xrNpWVZUGcMSf8oDQTstEiw['group']: NCyaEWFD0HwzO7chxlv8jupKItGB9 = vXn06xrNpWVZUGcMSf8oDQTstEiw['group']
		if any(BoSjXKxz41DcneO9UimClE in O9z5L3KtXqPEMepJQ0.lower() for BoSjXKxz41DcneO9UimClE in ccpVTZQ9yq4kLxtCJmwgM5vbSj1):
			mqYhiavDlScU9pP = True if 'm3u' not in O9z5L3KtXqPEMepJQ0 else False
		if mqYhiavDlScU9pP or '__SERIES__' in NCyaEWFD0HwzO7chxlv8jupKItGB9 or '__MOVIES__' in NCyaEWFD0HwzO7chxlv8jupKItGB9:
			udRvjXt9cAfha5ZsBP3U = 'VOD'
			if '__SERIES__' in NCyaEWFD0HwzO7chxlv8jupKItGB9: udRvjXt9cAfha5ZsBP3U = udRvjXt9cAfha5ZsBP3U+'_SERIES'
			elif '__MOVIES__' in NCyaEWFD0HwzO7chxlv8jupKItGB9: udRvjXt9cAfha5ZsBP3U = udRvjXt9cAfha5ZsBP3U+'_MOVIES'
			else: udRvjXt9cAfha5ZsBP3U = udRvjXt9cAfha5ZsBP3U+'_UNKNOWN'
			NCyaEWFD0HwzO7chxlv8jupKItGB9 = NCyaEWFD0HwzO7chxlv8jupKItGB9.replace('__SERIES__',hWGMqtBy4wuLaVcj).replace('__MOVIES__',hWGMqtBy4wuLaVcj)
		else:
			udRvjXt9cAfha5ZsBP3U = 'LIVE'
			if NiUSJbP8kMVZY in pvZHdIfLWJ9RM2: kCaIufXo1F0TyL7gtcJV5bneijMWHv = kCaIufXo1F0TyL7gtcJV5bneijMWHv+'_EPG'
			if NiUSJbP8kMVZY in eeprncjLGJAbykmgoMf7X61KI9tO: kCaIufXo1F0TyL7gtcJV5bneijMWHv = kCaIufXo1F0TyL7gtcJV5bneijMWHv+'_ARCHIVED'
			if not NCyaEWFD0HwzO7chxlv8jupKItGB9: udRvjXt9cAfha5ZsBP3U = udRvjXt9cAfha5ZsBP3U+'_UNKNOWN'
			else: udRvjXt9cAfha5ZsBP3U = udRvjXt9cAfha5ZsBP3U+kCaIufXo1F0TyL7gtcJV5bneijMWHv
		NCyaEWFD0HwzO7chxlv8jupKItGB9 = NCyaEWFD0HwzO7chxlv8jupKItGB9.strip(Mpsm2VF1OBnCRvK3qf6).replace(FqcVAkh7WjIXHdDKf8nvuyRo,Mpsm2VF1OBnCRvK3qf6).replace(FqcVAkh7WjIXHdDKf8nvuyRo,Mpsm2VF1OBnCRvK3qf6)
		if 'LIVE_UNKNOWN' in udRvjXt9cAfha5ZsBP3U: NCyaEWFD0HwzO7chxlv8jupKItGB9 = '!!__UNKNOWN_LIVE__!!'
		elif 'VOD_UNKNOWN' in udRvjXt9cAfha5ZsBP3U: NCyaEWFD0HwzO7chxlv8jupKItGB9 = '!!__UNKNOWN_VOD__!!'
		elif 'VOD_SERIES' in udRvjXt9cAfha5ZsBP3U:
			qZb5gLD1lCxvN3X6n4BsYjOU2hofPS = trdVA0JvFaD.findall('(.*?) [Ss]\d+ +[Ee]\d+',vXn06xrNpWVZUGcMSf8oDQTstEiw['title'],trdVA0JvFaD.DOTALL)
			if qZb5gLD1lCxvN3X6n4BsYjOU2hofPS: qZb5gLD1lCxvN3X6n4BsYjOU2hofPS = qZb5gLD1lCxvN3X6n4BsYjOU2hofPS[0]
			else: qZb5gLD1lCxvN3X6n4BsYjOU2hofPS = '!!__UNKNOWN_SERIES__!!'
			NCyaEWFD0HwzO7chxlv8jupKItGB9 = NCyaEWFD0HwzO7chxlv8jupKItGB9+'__SERIES__'+qZb5gLD1lCxvN3X6n4BsYjOU2hofPS
		if 'id' in WkQ3McKsx9oVUJA7HSeqfF: del vXn06xrNpWVZUGcMSf8oDQTstEiw['id']
		if 'ID' in WkQ3McKsx9oVUJA7HSeqfF: del vXn06xrNpWVZUGcMSf8oDQTstEiw['ID']
		if 'name' in WkQ3McKsx9oVUJA7HSeqfF: del vXn06xrNpWVZUGcMSf8oDQTstEiw['name']
		NiUSJbP8kMVZY = vXn06xrNpWVZUGcMSf8oDQTstEiw['title']
		NiUSJbP8kMVZY = emr1Lf523Ti0OtcNgxP(NiUSJbP8kMVZY)
		NiUSJbP8kMVZY = Cx6jM1dRgwfult(NiUSJbP8kMVZY)
		e6VjqFzNIR4,NCyaEWFD0HwzO7chxlv8jupKItGB9 = TBJtfPbwRDrLyqAeovCksFWcng78(NCyaEWFD0HwzO7chxlv8jupKItGB9)
		KuN0BPkXQzFaTMA6,NiUSJbP8kMVZY = TBJtfPbwRDrLyqAeovCksFWcng78(NiUSJbP8kMVZY)
		vXn06xrNpWVZUGcMSf8oDQTstEiw['type'] = udRvjXt9cAfha5ZsBP3U
		vXn06xrNpWVZUGcMSf8oDQTstEiw['context'] = kCaIufXo1F0TyL7gtcJV5bneijMWHv
		vXn06xrNpWVZUGcMSf8oDQTstEiw['group'] = NCyaEWFD0HwzO7chxlv8jupKItGB9.upper()
		vXn06xrNpWVZUGcMSf8oDQTstEiw['title'] = NiUSJbP8kMVZY.upper()
		vXn06xrNpWVZUGcMSf8oDQTstEiw['country'] = KuN0BPkXQzFaTMA6.upper()
		vXn06xrNpWVZUGcMSf8oDQTstEiw['language'] = e6VjqFzNIR4.upper()
		tw5Zql97GHv4Cu1jEY8PDBy6.append(vXn06xrNpWVZUGcMSf8oDQTstEiw)
		uuk6b4oz9gUJAmLVljxYpMi8ThI += 1
	return tw5Zql97GHv4Cu1jEY8PDBy6,uuk6b4oz9gUJAmLVljxYpMi8ThI,tROmFf3MpP0AXIqloC
def Cx6jM1dRgwfult(NiUSJbP8kMVZY):
	NiUSJbP8kMVZY = NiUSJbP8kMVZY.replace(FqcVAkh7WjIXHdDKf8nvuyRo,Mpsm2VF1OBnCRvK3qf6).replace(FqcVAkh7WjIXHdDKf8nvuyRo,Mpsm2VF1OBnCRvK3qf6).replace(FqcVAkh7WjIXHdDKf8nvuyRo,Mpsm2VF1OBnCRvK3qf6)
	NiUSJbP8kMVZY = NiUSJbP8kMVZY.replace('||','|').replace('___',':').replace('--','-')
	NiUSJbP8kMVZY = NiUSJbP8kMVZY.replace('[[','[').replace(']]',']')
	NiUSJbP8kMVZY = NiUSJbP8kMVZY.replace('((','(').replace('))',')')
	NiUSJbP8kMVZY = NiUSJbP8kMVZY.replace('<<','<').replace('>>','>')
	NiUSJbP8kMVZY = NiUSJbP8kMVZY.strip(Mpsm2VF1OBnCRvK3qf6)
	return NiUSJbP8kMVZY
def BBTSu8qMhVFWzE(N9N8aTDJbzPl0i3R,adzfw5H1NKAIjpZmVqoE04):
	HdOSrqXbgR1xL4 = {}
	for HTUOSQ3vdcRhEAnCmt0aIbiV in vNkywjI1YV6DAUdH: HdOSrqXbgR1xL4[HTUOSQ3vdcRhEAnCmt0aIbiV] = []
	BDc6tsV03u7E = len(N9N8aTDJbzPl0i3R)
	ltiGVfIY7R0ED9yFPM12L4zUT8 = str(BDc6tsV03u7E)
	uuk6b4oz9gUJAmLVljxYpMi8ThI = 0
	tROmFf3MpP0AXIqloC = []
	for vXn06xrNpWVZUGcMSf8oDQTstEiw in N9N8aTDJbzPl0i3R:
		if uuk6b4oz9gUJAmLVljxYpMi8ThI%873==0:
			CEIhS05OkFWGozARVZwnyrXf6(adzfw5H1NKAIjpZmVqoE04,50+int(5*uuk6b4oz9gUJAmLVljxYpMi8ThI/BDc6tsV03u7E),'تصنيف الفيديوهات الغير مرتبة','الفيديو رقم:-',str(uuk6b4oz9gUJAmLVljxYpMi8ThI)+' / '+ltiGVfIY7R0ED9yFPM12L4zUT8)
			if adzfw5H1NKAIjpZmVqoE04.iscanceled():
				adzfw5H1NKAIjpZmVqoE04.close()
				return None,None
		NCyaEWFD0HwzO7chxlv8jupKItGB9,kCaIufXo1F0TyL7gtcJV5bneijMWHv,NiUSJbP8kMVZY,O9z5L3KtXqPEMepJQ0,efLKh7nE5X8UAgBRil3yZ = vXn06xrNpWVZUGcMSf8oDQTstEiw['group'],vXn06xrNpWVZUGcMSf8oDQTstEiw['context'],vXn06xrNpWVZUGcMSf8oDQTstEiw['title'],vXn06xrNpWVZUGcMSf8oDQTstEiw['url'],vXn06xrNpWVZUGcMSf8oDQTstEiw['img']
		KuN0BPkXQzFaTMA6,e6VjqFzNIR4,HTUOSQ3vdcRhEAnCmt0aIbiV = vXn06xrNpWVZUGcMSf8oDQTstEiw['country'],vXn06xrNpWVZUGcMSf8oDQTstEiw['language'],vXn06xrNpWVZUGcMSf8oDQTstEiw['type']
		HPB5E8XFbWMoxmhK0 = (NCyaEWFD0HwzO7chxlv8jupKItGB9,kCaIufXo1F0TyL7gtcJV5bneijMWHv,NiUSJbP8kMVZY,O9z5L3KtXqPEMepJQ0,efLKh7nE5X8UAgBRil3yZ)
		t09xgkBWHTbAO = False
		if 'LIVE' in HTUOSQ3vdcRhEAnCmt0aIbiV:
			if 'UNKNOWN' in HTUOSQ3vdcRhEAnCmt0aIbiV: HdOSrqXbgR1xL4['LIVE_UNKNOWN_GROUPED'].append(HPB5E8XFbWMoxmhK0)
			elif 'LIVE' in HTUOSQ3vdcRhEAnCmt0aIbiV: HdOSrqXbgR1xL4['LIVE_GROUPED'].append(HPB5E8XFbWMoxmhK0)
			else: t09xgkBWHTbAO = True
			HdOSrqXbgR1xL4['LIVE_ORIGINAL_GROUPED'].append(HPB5E8XFbWMoxmhK0)
		elif 'VOD' in HTUOSQ3vdcRhEAnCmt0aIbiV:
			if 'UNKNOWN' in HTUOSQ3vdcRhEAnCmt0aIbiV: HdOSrqXbgR1xL4['VOD_UNKNOWN_GROUPED'].append(HPB5E8XFbWMoxmhK0)
			elif 'MOVIES' in HTUOSQ3vdcRhEAnCmt0aIbiV: HdOSrqXbgR1xL4['VOD_MOVIES_GROUPED'].append(HPB5E8XFbWMoxmhK0)
			elif 'SERIES' in HTUOSQ3vdcRhEAnCmt0aIbiV: HdOSrqXbgR1xL4['VOD_SERIES_GROUPED'].append(HPB5E8XFbWMoxmhK0)
			else: t09xgkBWHTbAO = True
			HdOSrqXbgR1xL4['VOD_ORIGINAL_GROUPED'].append(HPB5E8XFbWMoxmhK0)
		else: t09xgkBWHTbAO = True
		if t09xgkBWHTbAO: tROmFf3MpP0AXIqloC.append(vXn06xrNpWVZUGcMSf8oDQTstEiw)
		uuk6b4oz9gUJAmLVljxYpMi8ThI += 1
	aDp4dHmbSjEiT6lo2YFP3I59h1 = sorted(N9N8aTDJbzPl0i3R,reverse=False,key=lambda W6kuMbXBPcHdlyNGxeZ3T: W6kuMbXBPcHdlyNGxeZ3T['title'].lower())
	del N9N8aTDJbzPl0i3R
	ltiGVfIY7R0ED9yFPM12L4zUT8 = str(BDc6tsV03u7E)
	uuk6b4oz9gUJAmLVljxYpMi8ThI = 0
	for vXn06xrNpWVZUGcMSf8oDQTstEiw in aDp4dHmbSjEiT6lo2YFP3I59h1:
		uuk6b4oz9gUJAmLVljxYpMi8ThI += 1
		if uuk6b4oz9gUJAmLVljxYpMi8ThI%873==0:
			CEIhS05OkFWGozARVZwnyrXf6(adzfw5H1NKAIjpZmVqoE04,55+int(5*uuk6b4oz9gUJAmLVljxYpMi8ThI/BDc6tsV03u7E),'تصنيف الفيديوهات المرتبة','الفيديو رقم:-',str(uuk6b4oz9gUJAmLVljxYpMi8ThI)+' / '+ltiGVfIY7R0ED9yFPM12L4zUT8)
			if adzfw5H1NKAIjpZmVqoE04.iscanceled():
				adzfw5H1NKAIjpZmVqoE04.close()
				return None,None
		HTUOSQ3vdcRhEAnCmt0aIbiV = vXn06xrNpWVZUGcMSf8oDQTstEiw['type']
		NCyaEWFD0HwzO7chxlv8jupKItGB9,kCaIufXo1F0TyL7gtcJV5bneijMWHv,NiUSJbP8kMVZY,O9z5L3KtXqPEMepJQ0,efLKh7nE5X8UAgBRil3yZ = vXn06xrNpWVZUGcMSf8oDQTstEiw['group'],vXn06xrNpWVZUGcMSf8oDQTstEiw['context'],vXn06xrNpWVZUGcMSf8oDQTstEiw['title'],vXn06xrNpWVZUGcMSf8oDQTstEiw['url'],vXn06xrNpWVZUGcMSf8oDQTstEiw['img']
		KuN0BPkXQzFaTMA6,e6VjqFzNIR4 = vXn06xrNpWVZUGcMSf8oDQTstEiw['country'],vXn06xrNpWVZUGcMSf8oDQTstEiw['language']
		bDFC2HjkSJTK50V6Od7n8Nwh9AI = (NCyaEWFD0HwzO7chxlv8jupKItGB9,kCaIufXo1F0TyL7gtcJV5bneijMWHv+'_TIMESHIFT',NiUSJbP8kMVZY,O9z5L3KtXqPEMepJQ0,efLKh7nE5X8UAgBRil3yZ)
		HPB5E8XFbWMoxmhK0 = (NCyaEWFD0HwzO7chxlv8jupKItGB9,kCaIufXo1F0TyL7gtcJV5bneijMWHv,NiUSJbP8kMVZY,O9z5L3KtXqPEMepJQ0,efLKh7nE5X8UAgBRil3yZ)
		QNATZuvj9h1FawGKH0bf = (KuN0BPkXQzFaTMA6,kCaIufXo1F0TyL7gtcJV5bneijMWHv,NiUSJbP8kMVZY,O9z5L3KtXqPEMepJQ0,efLKh7nE5X8UAgBRil3yZ)
		UalrHRI0xoDY = (e6VjqFzNIR4,kCaIufXo1F0TyL7gtcJV5bneijMWHv,NiUSJbP8kMVZY,O9z5L3KtXqPEMepJQ0,efLKh7nE5X8UAgBRil3yZ)
		if 'LIVE' in HTUOSQ3vdcRhEAnCmt0aIbiV:
			if 'UNKNOWN' in HTUOSQ3vdcRhEAnCmt0aIbiV: HdOSrqXbgR1xL4['LIVE_UNKNOWN_GROUPED_SORTED'].append(HPB5E8XFbWMoxmhK0)
			else: HdOSrqXbgR1xL4['LIVE_GROUPED_SORTED'].append(HPB5E8XFbWMoxmhK0)
			if 'EPG'		in HTUOSQ3vdcRhEAnCmt0aIbiV: HdOSrqXbgR1xL4['LIVE_EPG_GROUPED_SORTED'].append(HPB5E8XFbWMoxmhK0)
			if 'ARCHIVED'	in HTUOSQ3vdcRhEAnCmt0aIbiV: HdOSrqXbgR1xL4['LIVE_ARCHIVED_GROUPED_SORTED'].append(HPB5E8XFbWMoxmhK0)
			if 'ARCHIVED'	in HTUOSQ3vdcRhEAnCmt0aIbiV: HdOSrqXbgR1xL4['LIVE_TIMESHIFT_GROUPED_SORTED'].append(bDFC2HjkSJTK50V6Od7n8Nwh9AI)
			HdOSrqXbgR1xL4['LIVE_FROM_NAME_SORTED'].append(QNATZuvj9h1FawGKH0bf)
			HdOSrqXbgR1xL4['LIVE_FROM_GROUP_SORTED'].append(UalrHRI0xoDY)
		elif 'VOD' in HTUOSQ3vdcRhEAnCmt0aIbiV:
			if   'UNKNOWN'	in HTUOSQ3vdcRhEAnCmt0aIbiV: HdOSrqXbgR1xL4['VOD_UNKNOWN_GROUPED_SORTED'].append(HPB5E8XFbWMoxmhK0)
			elif 'MOVIES'	in HTUOSQ3vdcRhEAnCmt0aIbiV: HdOSrqXbgR1xL4['VOD_MOVIES_GROUPED_SORTED'].append(HPB5E8XFbWMoxmhK0)
			elif 'SERIES'	in HTUOSQ3vdcRhEAnCmt0aIbiV: HdOSrqXbgR1xL4['VOD_SERIES_GROUPED_SORTED'].append(HPB5E8XFbWMoxmhK0)
			HdOSrqXbgR1xL4['VOD_FROM_NAME_SORTED'].append(QNATZuvj9h1FawGKH0bf)
			HdOSrqXbgR1xL4['VOD_FROM_GROUP_SORTED'].append(UalrHRI0xoDY)
	return HdOSrqXbgR1xL4,tROmFf3MpP0AXIqloC
def TBJtfPbwRDrLyqAeovCksFWcng78(NiUSJbP8kMVZY):
	if len(NiUSJbP8kMVZY)<3: return NiUSJbP8kMVZY,NiUSJbP8kMVZY
	LjwCGdhZctkqmpo0ve,CUVcFjeq2u0a = hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj
	RRAsWJKzDwaYUEbHGN3n = NiUSJbP8kMVZY
	arpQB5XJL4VYytMecAR6HklCZmT = NiUSJbP8kMVZY[:1]
	GGiYxA5OBL6r8UoPm = NiUSJbP8kMVZY[1:]
	if   arpQB5XJL4VYytMecAR6HklCZmT=='(': CUVcFjeq2u0a = ')'
	elif arpQB5XJL4VYytMecAR6HklCZmT=='[': CUVcFjeq2u0a = ']'
	elif arpQB5XJL4VYytMecAR6HklCZmT=='<': CUVcFjeq2u0a = '>'
	elif arpQB5XJL4VYytMecAR6HklCZmT=='|': CUVcFjeq2u0a = '|'
	if CUVcFjeq2u0a and (CUVcFjeq2u0a in GGiYxA5OBL6r8UoPm):
		F9Zqwyv7tzadBAWE8SjhJRGulLs,Vcb0mCY6TR = GGiYxA5OBL6r8UoPm.split(CUVcFjeq2u0a,1)
		LjwCGdhZctkqmpo0ve = F9Zqwyv7tzadBAWE8SjhJRGulLs
		RRAsWJKzDwaYUEbHGN3n = arpQB5XJL4VYytMecAR6HklCZmT+F9Zqwyv7tzadBAWE8SjhJRGulLs+CUVcFjeq2u0a+Mpsm2VF1OBnCRvK3qf6+Vcb0mCY6TR
	elif NiUSJbP8kMVZY.count('|')>=2:
		F9Zqwyv7tzadBAWE8SjhJRGulLs,Vcb0mCY6TR = NiUSJbP8kMVZY.split('|',1)
		LjwCGdhZctkqmpo0ve = F9Zqwyv7tzadBAWE8SjhJRGulLs
		RRAsWJKzDwaYUEbHGN3n = F9Zqwyv7tzadBAWE8SjhJRGulLs+' |'+Vcb0mCY6TR
	else:
		CUVcFjeq2u0a = trdVA0JvFaD.findall('^\w{2}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',NiUSJbP8kMVZY,trdVA0JvFaD.DOTALL)
		if not CUVcFjeq2u0a: CUVcFjeq2u0a = trdVA0JvFaD.findall('^\w{3}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',NiUSJbP8kMVZY,trdVA0JvFaD.DOTALL)
		if not CUVcFjeq2u0a: CUVcFjeq2u0a = trdVA0JvFaD.findall('^\w{4}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',NiUSJbP8kMVZY,trdVA0JvFaD.DOTALL)
		if CUVcFjeq2u0a:
			F9Zqwyv7tzadBAWE8SjhJRGulLs,Vcb0mCY6TR = NiUSJbP8kMVZY.split(CUVcFjeq2u0a[0],1)
			LjwCGdhZctkqmpo0ve = F9Zqwyv7tzadBAWE8SjhJRGulLs
			RRAsWJKzDwaYUEbHGN3n = F9Zqwyv7tzadBAWE8SjhJRGulLs+Mpsm2VF1OBnCRvK3qf6+CUVcFjeq2u0a[0]+Mpsm2VF1OBnCRvK3qf6+Vcb0mCY6TR
	RRAsWJKzDwaYUEbHGN3n = RRAsWJKzDwaYUEbHGN3n.replace(lG0yV5QNFHc2RbXM1Wp,Mpsm2VF1OBnCRvK3qf6).replace(FqcVAkh7WjIXHdDKf8nvuyRo,Mpsm2VF1OBnCRvK3qf6)
	LjwCGdhZctkqmpo0ve = LjwCGdhZctkqmpo0ve.replace(FqcVAkh7WjIXHdDKf8nvuyRo,Mpsm2VF1OBnCRvK3qf6)
	if not LjwCGdhZctkqmpo0ve: LjwCGdhZctkqmpo0ve = '!!__UNKNOWN__!!'
	LjwCGdhZctkqmpo0ve = LjwCGdhZctkqmpo0ve.strip(Mpsm2VF1OBnCRvK3qf6)
	RRAsWJKzDwaYUEbHGN3n = RRAsWJKzDwaYUEbHGN3n.strip(Mpsm2VF1OBnCRvK3qf6)
	return LjwCGdhZctkqmpo0ve,RRAsWJKzDwaYUEbHGN3n
def b5bp1UwmZdnxiEJ3DlSu6hMzqX2v(ZZNvmiGjlpwIOx):
	eE4wIviRq52y316 = {}
	wWpTXn09dPz3k75Qyea8stNl4i = ee8c0jzrTntGSUdRJm.getSetting('av.iptv.useragent_'+ZZNvmiGjlpwIOx)
	if wWpTXn09dPz3k75Qyea8stNl4i: eE4wIviRq52y316['User-Agent'] = wWpTXn09dPz3k75Qyea8stNl4i
	mvgGdSLRQU = ee8c0jzrTntGSUdRJm.getSetting('av.iptv.referer_'+ZZNvmiGjlpwIOx)
	if mvgGdSLRQU: eE4wIviRq52y316['Referer'] = mvgGdSLRQU
	return eE4wIviRq52y316
def B2BdYsVOPcJ(ZZNvmiGjlpwIOx):
	global adzfw5H1NKAIjpZmVqoE04,HdOSrqXbgR1xL4,wwhaLTWGUprtV9cxF8XbAyzNd0Qm1k,vvD4FWfbRku5HA8LoTMyNwZXnz0Osg,NN8LYXDu3sqV0rTMzCtQfk6,Y2YJtGk97sEMgD6LRplT85Ovm,HTCDKMwh938t5AkEaXxgLRqUn7Fzl,jDBcZL12Pd,INOfdYbCjDLKoBPktZ2uie3cHT
	IxdSqDFvuO8wYb7f6KVJsTBGiycg,LJmA1qSt9aXc,WJ4jm6MzHbSQcO9,wNf6hz8Vtq2J4eULdBpRFCG5imj,VyaUHwQzXLqJS = WWKXJ7yo4Gb3qYsmvg5BCVHhj0P(ZZNvmiGjlpwIOx)
	if not wNf6hz8Vtq2J4eULdBpRFCG5imj: return
	eE4wIviRq52y316 = b5bp1UwmZdnxiEJ3DlSu6hMzqX2v(ZZNvmiGjlpwIOx)
	MeYJm41G2j6Wn = XVmKrby29eCGMnlEY6jz0HNOR('center',hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'رسالة من المبرمج','جلب ملفات ـIPTV جديدة قد تحتاج عدة دقائق . هل تريد أن تجلب الملفات الآن ؟')
	if MeYJm41G2j6Wn!=1: return
	WgrvNFHaR5bDzCLAl8pMcQhBXd4Y = JfBKhMCkg0LvDObn2Rw9jpe5qcUzH.replace('___','_'+ZZNvmiGjlpwIOx)
	if 1:
		YpiyX9QrtV7zUehHq0RKgdCLjW,c9EDgwAj2GnCXtqB,R1RWlgS0kiJEFL3cX2famq = NjdI2F6vbK(ZZNvmiGjlpwIOx,False)
		if not YpiyX9QrtV7zUehHq0RKgdCLjW:
			BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'رسالة من المبرمج','فشل بسحب ملفات ـIPTV . أحتمال رابط ـIPTV غير صحيح أو قديم أو لا يعمل .. علما أن هذه الخدمة تحتاج اشتراك مدفوع وصحيح ويجب أن تضيف رابط الاشتراك بنفسك للبرنامج باستخدام قائمة ـIPTV الموجودة بهذا البرنامج')
			if not LJmA1qSt9aXc: KteLZCbM8W0FqE2OBx1(VRQE4jsXHSfhPWo5DgLwxGk,qhVEWvetzXLOcr1(bBER0HlPYh4ZXm6ILWw)+'   No IPTV URL found to download IPTV files')
			else: KteLZCbM8W0FqE2OBx1(VRQE4jsXHSfhPWo5DgLwxGk,qhVEWvetzXLOcr1(bBER0HlPYh4ZXm6ILWw)+'   Failed to download IPTV files')
			return
		TqIlHBr27uXJCUyKj59RfNnbm = kXZctzCN2Fy0o8OG4wE1(LJmA1qSt9aXc,eE4wIviRq52y316,True)
		if not TqIlHBr27uXJCUyKj59RfNnbm: return
		open(WgrvNFHaR5bDzCLAl8pMcQhBXd4Y,'wb').write(TqIlHBr27uXJCUyKj59RfNnbm)
	else: TqIlHBr27uXJCUyKj59RfNnbm = open(WgrvNFHaR5bDzCLAl8pMcQhBXd4Y,'rb').read()
	if H4qZ2hwilNJYTmCFEQyaSs98cPM0gR and TqIlHBr27uXJCUyKj59RfNnbm: TqIlHBr27uXJCUyKj59RfNnbm = TqIlHBr27uXJCUyKj59RfNnbm.decode(a7VXeDU82IfQEnPZAdiT)
	adzfw5H1NKAIjpZmVqoE04 = Tbof9Jl4eHnYZMvVEBFgCh1G3mLtd()
	adzfw5H1NKAIjpZmVqoE04.create('جلب ملفات ـIPTV جديدة',hWGMqtBy4wuLaVcj)
	CEIhS05OkFWGozARVZwnyrXf6(adzfw5H1NKAIjpZmVqoE04,15,'تنظيف الملف الرئيسي',hWGMqtBy4wuLaVcj)
	TqIlHBr27uXJCUyKj59RfNnbm = TqIlHBr27uXJCUyKj59RfNnbm.replace('"tvg-','" tvg-')
	TqIlHBr27uXJCUyKj59RfNnbm = TqIlHBr27uXJCUyKj59RfNnbm.replace('َ',hWGMqtBy4wuLaVcj).replace('ً',hWGMqtBy4wuLaVcj).replace('ُ',hWGMqtBy4wuLaVcj).replace('ٌ',hWGMqtBy4wuLaVcj)
	TqIlHBr27uXJCUyKj59RfNnbm = TqIlHBr27uXJCUyKj59RfNnbm.replace('ّ',hWGMqtBy4wuLaVcj).replace('ِ',hWGMqtBy4wuLaVcj).replace('ٍ',hWGMqtBy4wuLaVcj).replace('ْ',hWGMqtBy4wuLaVcj)
	TqIlHBr27uXJCUyKj59RfNnbm = TqIlHBr27uXJCUyKj59RfNnbm.replace('group-title=','group=').replace('tvg-',hWGMqtBy4wuLaVcj)
	eeprncjLGJAbykmgoMf7X61KI9tO,pvZHdIfLWJ9RM2 = [],[]
	CEIhS05OkFWGozARVZwnyrXf6(adzfw5H1NKAIjpZmVqoE04,20,'جلب الملفات الثانوية','الملف رقم:-','1 / 3')
	if adzfw5H1NKAIjpZmVqoE04.iscanceled():
		adzfw5H1NKAIjpZmVqoE04.close()
		return
	O9z5L3KtXqPEMepJQ0 = IxdSqDFvuO8wYb7f6KVJsTBGiycg+'&action=get_series_categories'
	oTawtcGI687h = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',O9z5L3KtXqPEMepJQ0,hWGMqtBy4wuLaVcj,eE4wIviRq52y316,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'IPTV-CREATE_STREAMS-1st')
	zJjQP6hXe8vbdrTDq1EmZwncYUL = oTawtcGI687h.content
	zJjQP6hXe8vbdrTDq1EmZwncYUL = emr1Lf523Ti0OtcNgxP(zJjQP6hXe8vbdrTDq1EmZwncYUL)
	Ln6oOpyUMmde9zvjtR = trdVA0JvFaD.findall('category_name":"(.*?)"',zJjQP6hXe8vbdrTDq1EmZwncYUL,trdVA0JvFaD.DOTALL)
	del zJjQP6hXe8vbdrTDq1EmZwncYUL
	for NCyaEWFD0HwzO7chxlv8jupKItGB9 in Ln6oOpyUMmde9zvjtR:
		NCyaEWFD0HwzO7chxlv8jupKItGB9 = NCyaEWFD0HwzO7chxlv8jupKItGB9.replace('\/','/')
		if VKiGj1LundAJQwEXcqgxC: NCyaEWFD0HwzO7chxlv8jupKItGB9 = NCyaEWFD0HwzO7chxlv8jupKItGB9.decode(a7VXeDU82IfQEnPZAdiT).encode(a7VXeDU82IfQEnPZAdiT)
		TqIlHBr27uXJCUyKj59RfNnbm = TqIlHBr27uXJCUyKj59RfNnbm.replace('group="'+NCyaEWFD0HwzO7chxlv8jupKItGB9+'"','group="__SERIES__'+NCyaEWFD0HwzO7chxlv8jupKItGB9+'"')
	del Ln6oOpyUMmde9zvjtR
	CEIhS05OkFWGozARVZwnyrXf6(adzfw5H1NKAIjpZmVqoE04,25,'جلب الملفات الثانوية','الملف رقم:-','2 / 3')
	if adzfw5H1NKAIjpZmVqoE04.iscanceled():
		adzfw5H1NKAIjpZmVqoE04.close()
		return
	O9z5L3KtXqPEMepJQ0 = IxdSqDFvuO8wYb7f6KVJsTBGiycg+'&action=get_vod_categories'
	oTawtcGI687h = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',O9z5L3KtXqPEMepJQ0,hWGMqtBy4wuLaVcj,eE4wIviRq52y316,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'IPTV-CREATE_STREAMS-2nd')
	zJjQP6hXe8vbdrTDq1EmZwncYUL = oTawtcGI687h.content
	zJjQP6hXe8vbdrTDq1EmZwncYUL = emr1Lf523Ti0OtcNgxP(zJjQP6hXe8vbdrTDq1EmZwncYUL)
	NzQWGiSoV2OKBJDneqb = trdVA0JvFaD.findall('category_name":"(.*?)"',zJjQP6hXe8vbdrTDq1EmZwncYUL,trdVA0JvFaD.DOTALL)
	del zJjQP6hXe8vbdrTDq1EmZwncYUL
	for NCyaEWFD0HwzO7chxlv8jupKItGB9 in NzQWGiSoV2OKBJDneqb:
		NCyaEWFD0HwzO7chxlv8jupKItGB9 = NCyaEWFD0HwzO7chxlv8jupKItGB9.replace('\/','/')
		if VKiGj1LundAJQwEXcqgxC: NCyaEWFD0HwzO7chxlv8jupKItGB9 = NCyaEWFD0HwzO7chxlv8jupKItGB9.decode(a7VXeDU82IfQEnPZAdiT).encode(a7VXeDU82IfQEnPZAdiT)
		TqIlHBr27uXJCUyKj59RfNnbm = TqIlHBr27uXJCUyKj59RfNnbm.replace('group="'+NCyaEWFD0HwzO7chxlv8jupKItGB9+'"','group="__MOVIES__'+NCyaEWFD0HwzO7chxlv8jupKItGB9+'"')
	del NzQWGiSoV2OKBJDneqb
	CEIhS05OkFWGozARVZwnyrXf6(adzfw5H1NKAIjpZmVqoE04,30,'جلب الملفات الثانوية','الملف رقم:-','3 / 3')
	if adzfw5H1NKAIjpZmVqoE04.iscanceled():
		adzfw5H1NKAIjpZmVqoE04.close()
		return
	O9z5L3KtXqPEMepJQ0 = IxdSqDFvuO8wYb7f6KVJsTBGiycg+'&action=get_live_streams'
	oTawtcGI687h = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',O9z5L3KtXqPEMepJQ0,hWGMqtBy4wuLaVcj,eE4wIviRq52y316,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'IPTV-CREATE_STREAMS-3rd')
	zJjQP6hXe8vbdrTDq1EmZwncYUL = oTawtcGI687h.content
	zJjQP6hXe8vbdrTDq1EmZwncYUL = emr1Lf523Ti0OtcNgxP(zJjQP6hXe8vbdrTDq1EmZwncYUL)
	CRf0dNjo6vYrzOE4euk37ZUS = trdVA0JvFaD.findall('"name":"(.*?)".*?"tv_archive":(.*?),',zJjQP6hXe8vbdrTDq1EmZwncYUL,trdVA0JvFaD.DOTALL)
	for j4lHpxXvnF2VtwBb1T9PaJEm3,t1t0TPZdR6xyIcNMi8eGKJ in CRf0dNjo6vYrzOE4euk37ZUS:
		if t1t0TPZdR6xyIcNMi8eGKJ=='1': eeprncjLGJAbykmgoMf7X61KI9tO.append(j4lHpxXvnF2VtwBb1T9PaJEm3)
	del CRf0dNjo6vYrzOE4euk37ZUS
	WYQ9ztnVA6EZhRySfmUOjkJBa = trdVA0JvFaD.findall('"name":"(.*?)".*?"epg_channel_id":(.*?),',zJjQP6hXe8vbdrTDq1EmZwncYUL,trdVA0JvFaD.DOTALL)
	del zJjQP6hXe8vbdrTDq1EmZwncYUL
	for j4lHpxXvnF2VtwBb1T9PaJEm3,h6ESipgIqyUaksv5rFZNBfj in WYQ9ztnVA6EZhRySfmUOjkJBa:
		if h6ESipgIqyUaksv5rFZNBfj!='null': pvZHdIfLWJ9RM2.append(j4lHpxXvnF2VtwBb1T9PaJEm3)
	del WYQ9ztnVA6EZhRySfmUOjkJBa
	TqIlHBr27uXJCUyKj59RfNnbm = TqIlHBr27uXJCUyKj59RfNnbm.replace(y6eSQlZEV8uwKG5M3,NXMOzZjYsmS9pf)
	KgUCchf0AS4luxk1zOrm2 = trdVA0JvFaD.findall('NF:(.+?)'+'#'+'EXTI',TqIlHBr27uXJCUyKj59RfNnbm+'\n+'+'#'+'EXTINF:',trdVA0JvFaD.DOTALL)
	if not KgUCchf0AS4luxk1zOrm2:
		KteLZCbM8W0FqE2OBx1(VRQE4jsXHSfhPWo5DgLwxGk,qhVEWvetzXLOcr1(bBER0HlPYh4ZXm6ILWw)+'   Folder:'+ZZNvmiGjlpwIOx+'   No video links found in IPTV file')
		BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'رسالة من المبرمج','رابط ـIPTV الذي أنت أضفته لا توجد فيه فيديوهات .. احتمال رابط ـIPTV غير صحيح'+NXMOzZjYsmS9pf+soMVfbr6WtpNlcSA+'مجلد رقم '+ZZNvmiGjlpwIOx)
		adzfw5H1NKAIjpZmVqoE04.close()
		return
	xEHzbTsioJ9VqpUh2uZlL3 = []
	for VDvfJ2uLMsg1xjcN5wGkzlQi in KgUCchf0AS4luxk1zOrm2:
		lP1ajwWObdYK0sZx = VDvfJ2uLMsg1xjcN5wGkzlQi.lower()
		if 'adult' in lP1ajwWObdYK0sZx: continue
		if 'xxx' in lP1ajwWObdYK0sZx: continue
		xEHzbTsioJ9VqpUh2uZlL3.append(VDvfJ2uLMsg1xjcN5wGkzlQi)
	KgUCchf0AS4luxk1zOrm2 = xEHzbTsioJ9VqpUh2uZlL3
	del xEHzbTsioJ9VqpUh2uZlL3
	rc7fGmYaxzKEyJHwC4j = 1024*1024
	KDjCPBTMir8qb2REQIsf5JVp7 = 1+len(TqIlHBr27uXJCUyKj59RfNnbm)//rc7fGmYaxzKEyJHwC4j//10
	del TqIlHBr27uXJCUyKj59RfNnbm
	kbvF2fqVcS61y9h4LQIdB8uWUat = len(KgUCchf0AS4luxk1zOrm2)
	bbNgvWXUdjip6hT3z = DDpEuzS4Pv(KgUCchf0AS4luxk1zOrm2,KDjCPBTMir8qb2REQIsf5JVp7)
	del KgUCchf0AS4luxk1zOrm2
	for qHM8P3uk06wSa1VfZXijWN2 in range(KDjCPBTMir8qb2REQIsf5JVp7):
		CEIhS05OkFWGozARVZwnyrXf6(adzfw5H1NKAIjpZmVqoE04,35+int(5*qHM8P3uk06wSa1VfZXijWN2/KDjCPBTMir8qb2REQIsf5JVp7),'تقطيع الملف الرئيسي','الجزء رقم:-',str(qHM8P3uk06wSa1VfZXijWN2+1)+' / '+str(KDjCPBTMir8qb2REQIsf5JVp7))
		if adzfw5H1NKAIjpZmVqoE04.iscanceled():
			adzfw5H1NKAIjpZmVqoE04.close()
			return
		ZZ3UilBxXCqcL = str(bbNgvWXUdjip6hT3z[qHM8P3uk06wSa1VfZXijWN2])
		if H4qZ2hwilNJYTmCFEQyaSs98cPM0gR: ZZ3UilBxXCqcL = ZZ3UilBxXCqcL.encode(a7VXeDU82IfQEnPZAdiT)
		open(WgrvNFHaR5bDzCLAl8pMcQhBXd4Y+'.00'+str(qHM8P3uk06wSa1VfZXijWN2),'wb').write(ZZ3UilBxXCqcL)
	del bbNgvWXUdjip6hT3z,ZZ3UilBxXCqcL
	Q1AxpKq6roG3nh,N9N8aTDJbzPl0i3R,uuk6b4oz9gUJAmLVljxYpMi8ThI = [],[],0
	for qHM8P3uk06wSa1VfZXijWN2 in range(KDjCPBTMir8qb2REQIsf5JVp7):
		if adzfw5H1NKAIjpZmVqoE04.iscanceled():
			adzfw5H1NKAIjpZmVqoE04.close()
			return
		ZZ3UilBxXCqcL = open(WgrvNFHaR5bDzCLAl8pMcQhBXd4Y+'.00'+str(qHM8P3uk06wSa1VfZXijWN2),'rb').read()
		HB5PvxRhwM.sleep(1)
		try: WQvYkNg7SysPFLitlGEn6.remove(WgrvNFHaR5bDzCLAl8pMcQhBXd4Y+'.00'+str(qHM8P3uk06wSa1VfZXijWN2))
		except: pass
		if H4qZ2hwilNJYTmCFEQyaSs98cPM0gR: ZZ3UilBxXCqcL = ZZ3UilBxXCqcL.decode(a7VXeDU82IfQEnPZAdiT)
		WZ7d2vx9e6KNJrEGQq = Cy9ow3c21nABMjzqeaIT('list',ZZ3UilBxXCqcL)
		del ZZ3UilBxXCqcL
		tw5Zql97GHv4Cu1jEY8PDBy6,uuk6b4oz9gUJAmLVljxYpMi8ThI,tROmFf3MpP0AXIqloC = msUkacnOupri8H9dPNvtY0D3elCJE(WZ7d2vx9e6KNJrEGQq,pvZHdIfLWJ9RM2,eeprncjLGJAbykmgoMf7X61KI9tO,adzfw5H1NKAIjpZmVqoE04,kbvF2fqVcS61y9h4LQIdB8uWUat,uuk6b4oz9gUJAmLVljxYpMi8ThI,LJmA1qSt9aXc)
		if adzfw5H1NKAIjpZmVqoE04.iscanceled():
			adzfw5H1NKAIjpZmVqoE04.close()
			return
		if not tw5Zql97GHv4Cu1jEY8PDBy6:
			adzfw5H1NKAIjpZmVqoE04.close()
			return
		N9N8aTDJbzPl0i3R += tw5Zql97GHv4Cu1jEY8PDBy6
		Q1AxpKq6roG3nh += tROmFf3MpP0AXIqloC
	del WZ7d2vx9e6KNJrEGQq,tw5Zql97GHv4Cu1jEY8PDBy6
	HdOSrqXbgR1xL4,tROmFf3MpP0AXIqloC = BBTSu8qMhVFWzE(N9N8aTDJbzPl0i3R,adzfw5H1NKAIjpZmVqoE04)
	if adzfw5H1NKAIjpZmVqoE04.iscanceled():
		adzfw5H1NKAIjpZmVqoE04.close()
		return
	Q1AxpKq6roG3nh += tROmFf3MpP0AXIqloC
	del N9N8aTDJbzPl0i3R,tROmFf3MpP0AXIqloC
	vvD4FWfbRku5HA8LoTMyNwZXnz0Osg,NN8LYXDu3sqV0rTMzCtQfk6,Y2YJtGk97sEMgD6LRplT85Ovm,HTCDKMwh938t5AkEaXxgLRqUn7Fzl,jDBcZL12Pd = {},{},{},0,0
	mntgadoNWh = list(HdOSrqXbgR1xL4.keys())
	INOfdYbCjDLKoBPktZ2uie3cHT = len(mntgadoNWh)*3
	if 1:
		QqVgxXWo02 = {}
		for Et7IhqupLyZ8deaolcjx in mntgadoNWh:
			QqVgxXWo02[Et7IhqupLyZ8deaolcjx] = KCTRe67wVy.Thread(target=yLYriGDCzwHmd,args=(Et7IhqupLyZ8deaolcjx,))
			QqVgxXWo02[Et7IhqupLyZ8deaolcjx].start()
		for Et7IhqupLyZ8deaolcjx in mntgadoNWh:
			QqVgxXWo02[Et7IhqupLyZ8deaolcjx].join()
		if adzfw5H1NKAIjpZmVqoE04.iscanceled():
			adzfw5H1NKAIjpZmVqoE04.close()
			return
	else:
		for Et7IhqupLyZ8deaolcjx in mntgadoNWh:
			yLYriGDCzwHmd(Et7IhqupLyZ8deaolcjx)
			if adzfw5H1NKAIjpZmVqoE04.iscanceled():
				adzfw5H1NKAIjpZmVqoE04.close()
				return
	VhlpEXgH37Jx(ZZNvmiGjlpwIOx,False)
	mntgadoNWh = list(vvD4FWfbRku5HA8LoTMyNwZXnz0Osg.keys())
	wwhaLTWGUprtV9cxF8XbAyzNd0Qm1k = 0
	if 1:
		QqVgxXWo02 = {}
		for Et7IhqupLyZ8deaolcjx in mntgadoNWh:
			QqVgxXWo02[Et7IhqupLyZ8deaolcjx] = KCTRe67wVy.Thread(target=iJXC68lhdYUBnjFLQb9K1zZ,args=(ZZNvmiGjlpwIOx,Et7IhqupLyZ8deaolcjx))
			QqVgxXWo02[Et7IhqupLyZ8deaolcjx].start()
		for Et7IhqupLyZ8deaolcjx in mntgadoNWh:
			QqVgxXWo02[Et7IhqupLyZ8deaolcjx].join()
		if adzfw5H1NKAIjpZmVqoE04.iscanceled():
			adzfw5H1NKAIjpZmVqoE04.close()
			return
	else:
		for Et7IhqupLyZ8deaolcjx in mntgadoNWh:
			iJXC68lhdYUBnjFLQb9K1zZ(ZZNvmiGjlpwIOx,Et7IhqupLyZ8deaolcjx)
			if adzfw5H1NKAIjpZmVqoE04.iscanceled():
				adzfw5H1NKAIjpZmVqoE04.close()
				return
	qHM8P3uk06wSa1VfZXijWN2 = 0
	GltPYWd54NBKcTkQoLU = len(Q1AxpKq6roG3nh)
	Zp5LawF3h1OU0xyucVqzk = Uk0JAvcrY6X(ZZNvmiGjlpwIOx,'IGNORED')
	for OvQIunNjhP0LmXY in Q1AxpKq6roG3nh:
		if qHM8P3uk06wSa1VfZXijWN2%27==0:
			CEIhS05OkFWGozARVZwnyrXf6(adzfw5H1NKAIjpZmVqoE04,95+int(5*qHM8P3uk06wSa1VfZXijWN2//GltPYWd54NBKcTkQoLU),'تخزين المهملة','الفيديو رقم:-',str(qHM8P3uk06wSa1VfZXijWN2)+' / '+str(GltPYWd54NBKcTkQoLU))
			if adzfw5H1NKAIjpZmVqoE04.iscanceled():
				adzfw5H1NKAIjpZmVqoE04.close()
				return
		BxuD7iQRpW1(Zp5LawF3h1OU0xyucVqzk,'IGNORED',str(OvQIunNjhP0LmXY),hWGMqtBy4wuLaVcj,VWxPgG1p8Z2Ei4DrX7NotvR)
		qHM8P3uk06wSa1VfZXijWN2 += 1
	BxuD7iQRpW1(Zp5LawF3h1OU0xyucVqzk,'IGNORED','__COUNT__',str(GltPYWd54NBKcTkQoLU),VWxPgG1p8Z2Ei4DrX7NotvR)
	BxuD7iQRpW1(Zp5LawF3h1OU0xyucVqzk,'DUMMY','__DUMMY__','1',VWxPgG1p8Z2Ei4DrX7NotvR)
	adzfw5H1NKAIjpZmVqoE04.close()
	HB5PvxRhwM.sleep(1)
	YlL3SO5i80BWMAbNjpdscuhX2f = vvql6FyRM4JY(ZZNvmiGjlpwIOx,False)
	BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'رسالة من المبرمج',soMVfbr6WtpNlcSA+'تم جلب ملفات ـIPTV جديدة'+YYSh2J6BIrsm8+'\n\n'+YlL3SO5i80BWMAbNjpdscuhX2f)
	SRc0wiMvLgkPJ5zhpbUfHn2(ZZNvmiGjlpwIOx)
	OwGHUMSI3WuYd9VtcC5ehnbFxv04Xi(False)
	CfKNTtIi3OABbWcPpdF(False)
	return
def yLYriGDCzwHmd(Et7IhqupLyZ8deaolcjx):
	global adzfw5H1NKAIjpZmVqoE04,HdOSrqXbgR1xL4,wwhaLTWGUprtV9cxF8XbAyzNd0Qm1k,vvD4FWfbRku5HA8LoTMyNwZXnz0Osg,NN8LYXDu3sqV0rTMzCtQfk6,Y2YJtGk97sEMgD6LRplT85Ovm,HTCDKMwh938t5AkEaXxgLRqUn7Fzl,jDBcZL12Pd,INOfdYbCjDLKoBPktZ2uie3cHT
	vvD4FWfbRku5HA8LoTMyNwZXnz0Osg[Et7IhqupLyZ8deaolcjx] = {}
	OqEwTBcWsuPVkdgN40ItFS,ql0KY43EUQwRIG8xcVFTvmyHSkWL9N = {},[]
	nCdPBZFOtJH47LiAmND86EQMW9z1 = len(HdOSrqXbgR1xL4[Et7IhqupLyZ8deaolcjx])
	vvD4FWfbRku5HA8LoTMyNwZXnz0Osg[Et7IhqupLyZ8deaolcjx]['__COUNT__'] = nCdPBZFOtJH47LiAmND86EQMW9z1
	if nCdPBZFOtJH47LiAmND86EQMW9z1>0:
		lIP0QrgsKU3BJh4cqMd9HuX,ZIvVtMrmUw,GoB8TExLvHl3r9saVQKZyq,VmOQgwIsGr9473Po0RvcKz,F3fph7DuyajJBrRoIOmA = zip(*HdOSrqXbgR1xL4[Et7IhqupLyZ8deaolcjx])
		del ZIvVtMrmUw,GoB8TExLvHl3r9saVQKZyq,VmOQgwIsGr9473Po0RvcKz
		GGdY9crfqBPxFJRloywmuVW = list(set(lIP0QrgsKU3BJh4cqMd9HuX))
		for NCyaEWFD0HwzO7chxlv8jupKItGB9 in GGdY9crfqBPxFJRloywmuVW:
			OqEwTBcWsuPVkdgN40ItFS[NCyaEWFD0HwzO7chxlv8jupKItGB9] = hWGMqtBy4wuLaVcj
			vvD4FWfbRku5HA8LoTMyNwZXnz0Osg[Et7IhqupLyZ8deaolcjx][NCyaEWFD0HwzO7chxlv8jupKItGB9] = []
		CEIhS05OkFWGozARVZwnyrXf6(adzfw5H1NKAIjpZmVqoE04,60+int(15*jDBcZL12Pd//INOfdYbCjDLKoBPktZ2uie3cHT),'تصنيع القوائم','الجزء رقم:-',str(jDBcZL12Pd)+' / '+str(INOfdYbCjDLKoBPktZ2uie3cHT))
		if adzfw5H1NKAIjpZmVqoE04.iscanceled(): return
		jDBcZL12Pd += 1
		QjIhbYNdeq150CGRxXoa9g = len(GGdY9crfqBPxFJRloywmuVW)
		del GGdY9crfqBPxFJRloywmuVW
		ql0KY43EUQwRIG8xcVFTvmyHSkWL9N = list(set(zip(lIP0QrgsKU3BJh4cqMd9HuX,F3fph7DuyajJBrRoIOmA)))
		del lIP0QrgsKU3BJh4cqMd9HuX,F3fph7DuyajJBrRoIOmA
		for NCyaEWFD0HwzO7chxlv8jupKItGB9,acysH2W9N0BhXIvJPRM5t in ql0KY43EUQwRIG8xcVFTvmyHSkWL9N:
			if not OqEwTBcWsuPVkdgN40ItFS[NCyaEWFD0HwzO7chxlv8jupKItGB9] and acysH2W9N0BhXIvJPRM5t: OqEwTBcWsuPVkdgN40ItFS[NCyaEWFD0HwzO7chxlv8jupKItGB9] = acysH2W9N0BhXIvJPRM5t
		CEIhS05OkFWGozARVZwnyrXf6(adzfw5H1NKAIjpZmVqoE04,60+int(15*jDBcZL12Pd//INOfdYbCjDLKoBPktZ2uie3cHT),'تصنيع القوائم','الجزء رقم:-',str(jDBcZL12Pd)+' / '+str(INOfdYbCjDLKoBPktZ2uie3cHT))
		if adzfw5H1NKAIjpZmVqoE04.iscanceled(): return
		jDBcZL12Pd += 1
		jL4C9VYQwWA7zybgPahDtS = list(OqEwTBcWsuPVkdgN40ItFS.keys())
		lgNOCVsfi4zZ8uomLG69hHUJI = list(OqEwTBcWsuPVkdgN40ItFS.values())
		del OqEwTBcWsuPVkdgN40ItFS
		ql0KY43EUQwRIG8xcVFTvmyHSkWL9N = list(zip(jL4C9VYQwWA7zybgPahDtS,lgNOCVsfi4zZ8uomLG69hHUJI))
		del jL4C9VYQwWA7zybgPahDtS,lgNOCVsfi4zZ8uomLG69hHUJI
		ql0KY43EUQwRIG8xcVFTvmyHSkWL9N = sorted(ql0KY43EUQwRIG8xcVFTvmyHSkWL9N)
	else: jDBcZL12Pd += 2
	vvD4FWfbRku5HA8LoTMyNwZXnz0Osg[Et7IhqupLyZ8deaolcjx]['__GROUPS__'] = ql0KY43EUQwRIG8xcVFTvmyHSkWL9N
	del ql0KY43EUQwRIG8xcVFTvmyHSkWL9N
	for NCyaEWFD0HwzO7chxlv8jupKItGB9,kCaIufXo1F0TyL7gtcJV5bneijMWHv,NiUSJbP8kMVZY,O9z5L3KtXqPEMepJQ0,efLKh7nE5X8UAgBRil3yZ in HdOSrqXbgR1xL4[Et7IhqupLyZ8deaolcjx]:
		vvD4FWfbRku5HA8LoTMyNwZXnz0Osg[Et7IhqupLyZ8deaolcjx][NCyaEWFD0HwzO7chxlv8jupKItGB9].append((kCaIufXo1F0TyL7gtcJV5bneijMWHv,NiUSJbP8kMVZY,O9z5L3KtXqPEMepJQ0,efLKh7nE5X8UAgBRil3yZ))
	CEIhS05OkFWGozARVZwnyrXf6(adzfw5H1NKAIjpZmVqoE04,60+int(15*jDBcZL12Pd//INOfdYbCjDLKoBPktZ2uie3cHT),'تصنيع القوائم','الجزء رقم:-',str(jDBcZL12Pd)+' / '+str(INOfdYbCjDLKoBPktZ2uie3cHT))
	if adzfw5H1NKAIjpZmVqoE04.iscanceled(): return
	jDBcZL12Pd += 1
	del HdOSrqXbgR1xL4[Et7IhqupLyZ8deaolcjx]
	Y2YJtGk97sEMgD6LRplT85Ovm[Et7IhqupLyZ8deaolcjx] = list(vvD4FWfbRku5HA8LoTMyNwZXnz0Osg[Et7IhqupLyZ8deaolcjx].keys())
	NN8LYXDu3sqV0rTMzCtQfk6[Et7IhqupLyZ8deaolcjx] = len(Y2YJtGk97sEMgD6LRplT85Ovm[Et7IhqupLyZ8deaolcjx])
	HTCDKMwh938t5AkEaXxgLRqUn7Fzl += NN8LYXDu3sqV0rTMzCtQfk6[Et7IhqupLyZ8deaolcjx]
	return
def iJXC68lhdYUBnjFLQb9K1zZ(ZZNvmiGjlpwIOx,Et7IhqupLyZ8deaolcjx):
	global adzfw5H1NKAIjpZmVqoE04,HdOSrqXbgR1xL4,wwhaLTWGUprtV9cxF8XbAyzNd0Qm1k,vvD4FWfbRku5HA8LoTMyNwZXnz0Osg,NN8LYXDu3sqV0rTMzCtQfk6,Y2YJtGk97sEMgD6LRplT85Ovm,HTCDKMwh938t5AkEaXxgLRqUn7Fzl,jDBcZL12Pd,INOfdYbCjDLKoBPktZ2uie3cHT
	Zp5LawF3h1OU0xyucVqzk = Uk0JAvcrY6X(ZZNvmiGjlpwIOx,Et7IhqupLyZ8deaolcjx)
	for uuk6b4oz9gUJAmLVljxYpMi8ThI in range(1+NN8LYXDu3sqV0rTMzCtQfk6[Et7IhqupLyZ8deaolcjx]//273):
		klbodexIgj42B73 = []
		omKayRGOC8tgPnb9USWhJLlDpveZ = Y2YJtGk97sEMgD6LRplT85Ovm[Et7IhqupLyZ8deaolcjx][0:273]
		for NCyaEWFD0HwzO7chxlv8jupKItGB9 in omKayRGOC8tgPnb9USWhJLlDpveZ:
			klbodexIgj42B73.append(vvD4FWfbRku5HA8LoTMyNwZXnz0Osg[Et7IhqupLyZ8deaolcjx][NCyaEWFD0HwzO7chxlv8jupKItGB9])
		BxuD7iQRpW1(Zp5LawF3h1OU0xyucVqzk,Et7IhqupLyZ8deaolcjx,omKayRGOC8tgPnb9USWhJLlDpveZ,klbodexIgj42B73,VWxPgG1p8Z2Ei4DrX7NotvR,True)
		wwhaLTWGUprtV9cxF8XbAyzNd0Qm1k += len(omKayRGOC8tgPnb9USWhJLlDpveZ)
		CEIhS05OkFWGozARVZwnyrXf6(adzfw5H1NKAIjpZmVqoE04,75+int(20*wwhaLTWGUprtV9cxF8XbAyzNd0Qm1k//HTCDKMwh938t5AkEaXxgLRqUn7Fzl),'تخزين القوائم','القائمة رقم:-',str(wwhaLTWGUprtV9cxF8XbAyzNd0Qm1k)+' / '+str(HTCDKMwh938t5AkEaXxgLRqUn7Fzl))
		if adzfw5H1NKAIjpZmVqoE04.iscanceled(): return
		del Y2YJtGk97sEMgD6LRplT85Ovm[Et7IhqupLyZ8deaolcjx][0:273]
	del vvD4FWfbRku5HA8LoTMyNwZXnz0Osg[Et7IhqupLyZ8deaolcjx],Y2YJtGk97sEMgD6LRplT85Ovm[Et7IhqupLyZ8deaolcjx],NN8LYXDu3sqV0rTMzCtQfk6[Et7IhqupLyZ8deaolcjx]
	return
def vvql6FyRM4JY(ZZNvmiGjlpwIOx,WJrHC9Da7gRnmplf53=True):
	if not OhBPub8QYNceaq3W(ZZNvmiGjlpwIOx,WJrHC9Da7gRnmplf53): return
	MJip5YmVno = 'رسالة من المبرمج'
	tdVUCZDOefgsEKRq = Uk0JAvcrY6X(ZZNvmiGjlpwIOx,'LIVE_ORIGINAL_GROUPED')
	JgpyNbw3KedvPXUfxa47 = Uk0JAvcrY6X(ZZNvmiGjlpwIOx,'VOD_ORIGINAL_GROUPED')
	GltPYWd54NBKcTkQoLU = Mqk51CFBym0pIQXZLsOxSJ(tdVUCZDOefgsEKRq,'int','IGNORED','__COUNT__')
	lsNHaT1zbDE = Mqk51CFBym0pIQXZLsOxSJ(tdVUCZDOefgsEKRq,'int','LIVE_ORIGINAL_GROUPED','__COUNT__')
	Uoyq4SinKHN50OdwChfLQ = Mqk51CFBym0pIQXZLsOxSJ(JgpyNbw3KedvPXUfxa47,'int','VOD_ORIGINAL_GROUPED','__COUNT__')
	v48ZGUwCte0YDOyhobs = Mqk51CFBym0pIQXZLsOxSJ(tdVUCZDOefgsEKRq,'int','LIVE_GROUPED','__COUNT__')
	Nyt5FWfUTP47iSqr0dgDsLxpc = Mqk51CFBym0pIQXZLsOxSJ(tdVUCZDOefgsEKRq,'int','LIVE_UNKNOWN_GROUPED','__COUNT__')
	phmf8CMcyKEsS6D7oNgIe9kvYTO0Bx = Mqk51CFBym0pIQXZLsOxSJ(tdVUCZDOefgsEKRq,'int','VOD_MOVIES_GROUPED','__COUNT__')
	ccCh89w0W41im = Mqk51CFBym0pIQXZLsOxSJ(JgpyNbw3KedvPXUfxa47,'int','VOD_SERIES_GROUPED','__COUNT__')
	G7cZVMokpwAn8fSJ0e = Mqk51CFBym0pIQXZLsOxSJ(tdVUCZDOefgsEKRq,'int','VOD_UNKNOWN_GROUPED','__COUNT__')
	Y2YJtGk97sEMgD6LRplT85Ovm = Mqk51CFBym0pIQXZLsOxSJ(JgpyNbw3KedvPXUfxa47,'list','VOD_SERIES_GROUPED','__GROUPS__')
	sBHdiMq1XVFSPAgw48xYl = []
	for NCyaEWFD0HwzO7chxlv8jupKItGB9,efLKh7nE5X8UAgBRil3yZ in Y2YJtGk97sEMgD6LRplT85Ovm:
		OcB89MQzoU64ESjGW = NCyaEWFD0HwzO7chxlv8jupKItGB9.split('__SERIES__')[1]
		sBHdiMq1XVFSPAgw48xYl.append(OcB89MQzoU64ESjGW)
	cWAJi89ulPZgOaYrEF5Uq = len(sBHdiMq1XVFSPAgw48xYl)
	xYt7uXLKMInBEvH8 = int(phmf8CMcyKEsS6D7oNgIe9kvYTO0Bx)+int(ccCh89w0W41im)+int(G7cZVMokpwAn8fSJ0e)+int(Nyt5FWfUTP47iSqr0dgDsLxpc)+int(v48ZGUwCte0YDOyhobs)
	YlL3SO5i80BWMAbNjpdscuhX2f = hWGMqtBy4wuLaVcj
	YlL3SO5i80BWMAbNjpdscuhX2f += 'قنوات: '+str(v48ZGUwCte0YDOyhobs)
	YlL3SO5i80BWMAbNjpdscuhX2f += '   .   أفلام: '+str(phmf8CMcyKEsS6D7oNgIe9kvYTO0Bx)
	YlL3SO5i80BWMAbNjpdscuhX2f += '\nمسلسلات: '+str(cWAJi89ulPZgOaYrEF5Uq)
	YlL3SO5i80BWMAbNjpdscuhX2f += '   .   حلقات: '+str(ccCh89w0W41im)
	YlL3SO5i80BWMAbNjpdscuhX2f += '\nقنوات مجهولة: '+str(Nyt5FWfUTP47iSqr0dgDsLxpc)
	YlL3SO5i80BWMAbNjpdscuhX2f += '   .   فيدوهات مجهولة: '+str(G7cZVMokpwAn8fSJ0e)
	YlL3SO5i80BWMAbNjpdscuhX2f += '\nمجموع القنوات: '+str(lsNHaT1zbDE)
	YlL3SO5i80BWMAbNjpdscuhX2f += '   .   مجموع الفيديوهات: '+str(Uoyq4SinKHN50OdwChfLQ)
	YlL3SO5i80BWMAbNjpdscuhX2f += '\n\nمجموع المضافة: '+str(xYt7uXLKMInBEvH8)
	YlL3SO5i80BWMAbNjpdscuhX2f += '   .   مجموع المهملة: '+str(GltPYWd54NBKcTkQoLU)
	if WJrHC9Da7gRnmplf53: BZj61bFtfWLzXp('center',hWGMqtBy4wuLaVcj,MJip5YmVno,YlL3SO5i80BWMAbNjpdscuhX2f)
	ccl5TUPWuKj = YlL3SO5i80BWMAbNjpdscuhX2f.replace('\n\n',NXMOzZjYsmS9pf)
	KteLZCbM8W0FqE2OBx1(pGYKHZgqFX3B,'.\tCounts of IPTV videos   Folder: '+ZZNvmiGjlpwIOx+NXMOzZjYsmS9pf+ccl5TUPWuKj)
	return YlL3SO5i80BWMAbNjpdscuhX2f
def VhlpEXgH37Jx(ZZNvmiGjlpwIOx,WJrHC9Da7gRnmplf53=True):
	if WJrHC9Da7gRnmplf53:
		MeYJm41G2j6Wn = XVmKrby29eCGMnlEY6jz0HNOR('center',hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'مسح ملفات ـIPTV','تستطيع في أي وقت الدخول إلى قائمة ـIPTV وجلب ملفات ـIPTV جديدة .. هل تريد الآن مسح الملفات القديمة المخزنة في البرنامج ؟!')
		if MeYJm41G2j6Wn!=1: return
		DusgyjapviZ = JfBKhMCkg0LvDObn2Rw9jpe5qcUzH.replace('___','_'+ZZNvmiGjlpwIOx)
		try: WQvYkNg7SysPFLitlGEn6.remove(DusgyjapviZ)
		except: pass
	DusgyjapviZ = bXmN7lhEQo2Tv4WGgDp5.replace('___','_'+ZZNvmiGjlpwIOx)
	try: WQvYkNg7SysPFLitlGEn6.remove(DusgyjapviZ)
	except: pass
	DusgyjapviZ = Y3fGRujshztP0ZHgTBmkEdSiy89nV4.replace('___','_'+ZZNvmiGjlpwIOx)
	try: WQvYkNg7SysPFLitlGEn6.remove(DusgyjapviZ)
	except: pass
	pMPR1Cc0usZ6nJTU(MM5Dx39f7ULhcJsRptzIowP,'SECTIONS_IPTV','SECTIONS_IPTV_'+ZZNvmiGjlpwIOx)
	pMPR1Cc0usZ6nJTU(MM5Dx39f7ULhcJsRptzIowP,'SECTIONS_IPTV','SECTIONS_IPTV_ALL')
	OwGHUMSI3WuYd9VtcC5ehnbFxv04Xi(False)
	SRc0wiMvLgkPJ5zhpbUfHn2(ZZNvmiGjlpwIOx)
	if WJrHC9Da7gRnmplf53:
		BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'رسالة من المبرمج','تم مسح جميع ملفات ـIPTV')
		CfKNTtIi3OABbWcPpdF(False)
	return
def OhBPub8QYNceaq3W(ZZNvmiGjlpwIOx=hWGMqtBy4wuLaVcj,WJrHC9Da7gRnmplf53=True):
	if ZZNvmiGjlpwIOx:
		Zp5LawF3h1OU0xyucVqzk = Uk0JAvcrY6X(str(ZZNvmiGjlpwIOx),'DUMMY')
		KmPeHvQYBna8foZrX6Dz = Mqk51CFBym0pIQXZLsOxSJ(Zp5LawF3h1OU0xyucVqzk,'str','DUMMY','__DUMMY__')
		if KmPeHvQYBna8foZrX6Dz: return True
	else:
		ZZNvmiGjlpwIOx = '1'
		for FhWHOJ7vySrd3bKt in range(1,SdRCvwxfo1P95Jjb+1):
			Zp5LawF3h1OU0xyucVqzk = Uk0JAvcrY6X(str(FhWHOJ7vySrd3bKt),'DUMMY')
			KmPeHvQYBna8foZrX6Dz = Mqk51CFBym0pIQXZLsOxSJ(Zp5LawF3h1OU0xyucVqzk,'str','DUMMY','__DUMMY__')
			if KmPeHvQYBna8foZrX6Dz: return True
	if WJrHC9Da7gRnmplf53:
		BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'رسالة من المبرمج','هذا الجزء من البرنامج يحتاج اشتراك IPTV مدفوع من شركة IPTV .. ونوع الرابط المطلوب هو  m3u .. وهذا مثال لتوضيح شكل الرابط المطلوب في هذا البرنامج  '+hXB0vKVQ5PRI91SDTprMdfuHEm4+' \n\nhttp://xyz.xyz/get.php?username=xyz&password=xyz&type=m3u_plus '+YYSh2J6BIrsm8)
		MJip5YmVno = 'إضافة وتغيير رابط '+A7ZIc5uC1nT0PWYHEjb2BfxeV38[1]+' (مجلد '+A7ZIc5uC1nT0PWYHEjb2BfxeV38[int(ZZNvmiGjlpwIOx)]+')'
		MeYJm41G2j6Wn = XVmKrby29eCGMnlEY6jz0HNOR(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,MJip5YmVno,'لإضافة رابط IPTV .. أولا أفتح قائمة IPTV .. وثانيا أنقر على إضافة رابط أو اشتراك ـIPTV .. وثالثا أنقر على جلب ملفات ـIPTV \n\n هل تريد إضافة أو تغيير رابط IPTV الآن ؟!')
		if MeYJm41G2j6Wn==1: iCfurd34Gnxt5N(ZZNvmiGjlpwIOx)
	return False
def JJZuoXlhrIYv(zsTHrun3d1BG2iAtM4j,ZZNvmiGjlpwIOx=hWGMqtBy4wuLaVcj,Et7IhqupLyZ8deaolcjx=hWGMqtBy4wuLaVcj,Z5nl0jQD6XTI8ux=hWGMqtBy4wuLaVcj):
	if not Z5nl0jQD6XTI8ux: Z5nl0jQD6XTI8ux = '1'
	WZMblRwhQNn9Gqo,T0E1NY7V4pLXyHtxCkfw8mWUd3n9,WJrHC9Da7gRnmplf53 = IVTEJQOiMR2dYta9C(zsTHrun3d1BG2iAtM4j)
	if not OhBPub8QYNceaq3W(ZZNvmiGjlpwIOx,WJrHC9Da7gRnmplf53): return
	if not WZMblRwhQNn9Gqo:
		WZMblRwhQNn9Gqo = TrzfUidpv1LyAYqwexHJDuS()
		if not WZMblRwhQNn9Gqo: return
	oCwTNBlr9RL3 = [hWGMqtBy4wuLaVcj,'LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not Et7IhqupLyZ8deaolcjx:
		if not WJrHC9Da7gRnmplf53:
			if   '_IPTV-LIVE_' in T0E1NY7V4pLXyHtxCkfw8mWUd3n9: Et7IhqupLyZ8deaolcjx = oCwTNBlr9RL3[1]
			elif '_IPTV-MOVIES' in T0E1NY7V4pLXyHtxCkfw8mWUd3n9: Et7IhqupLyZ8deaolcjx = oCwTNBlr9RL3[2]
			elif '_IPTV-SERIES' in T0E1NY7V4pLXyHtxCkfw8mWUd3n9: Et7IhqupLyZ8deaolcjx = oCwTNBlr9RL3[3]
			else: Et7IhqupLyZ8deaolcjx = oCwTNBlr9RL3[0]
		else:
			guNjUlR76F9 = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			NN8u2B5iU3RMYheFy = Eb7qJoNwOgn('أختر البحث المناسب', guNjUlR76F9)
			if NN8u2B5iU3RMYheFy==-1: return
			Et7IhqupLyZ8deaolcjx = oCwTNBlr9RL3[NN8u2B5iU3RMYheFy]
	WZMblRwhQNn9Gqo = WZMblRwhQNn9Gqo+'_NODIALOGS_'
	if ZZNvmiGjlpwIOx: QNDl4JqFCVREeiSvOU(WZMblRwhQNn9Gqo,ZZNvmiGjlpwIOx,Et7IhqupLyZ8deaolcjx,Z5nl0jQD6XTI8ux)
	else:
		for ZZNvmiGjlpwIOx in range(1,SdRCvwxfo1P95Jjb+1):
			QNDl4JqFCVREeiSvOU(WZMblRwhQNn9Gqo,str(ZZNvmiGjlpwIOx),Et7IhqupLyZ8deaolcjx,Z5nl0jQD6XTI8ux)
		vNRpDl1awktg7QP4m0KGqMTS2i[:] = sorted(vNRpDl1awktg7QP4m0KGqMTS2i,reverse=False,key=lambda W6kuMbXBPcHdlyNGxeZ3T: W6kuMbXBPcHdlyNGxeZ3T[1].lower())
	return
def QNDl4JqFCVREeiSvOU(zsTHrun3d1BG2iAtM4j,ZZNvmiGjlpwIOx,Et7IhqupLyZ8deaolcjx=hWGMqtBy4wuLaVcj,Z5nl0jQD6XTI8ux=hWGMqtBy4wuLaVcj):
	if not Z5nl0jQD6XTI8ux: Z5nl0jQD6XTI8ux = '1'
	WZMblRwhQNn9Gqo,T0E1NY7V4pLXyHtxCkfw8mWUd3n9,WJrHC9Da7gRnmplf53 = IVTEJQOiMR2dYta9C(zsTHrun3d1BG2iAtM4j)
	if not ZZNvmiGjlpwIOx: return
	if not OhBPub8QYNceaq3W(ZZNvmiGjlpwIOx,WJrHC9Da7gRnmplf53): return
	if not WZMblRwhQNn9Gqo:
		WZMblRwhQNn9Gqo = TrzfUidpv1LyAYqwexHJDuS()
		if not WZMblRwhQNn9Gqo: return
	oCwTNBlr9RL3 = [hWGMqtBy4wuLaVcj,'LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not Et7IhqupLyZ8deaolcjx:
		if not WJrHC9Da7gRnmplf53:
			if   '_IPTV-LIVE_' in T0E1NY7V4pLXyHtxCkfw8mWUd3n9: Et7IhqupLyZ8deaolcjx = oCwTNBlr9RL3[1]
			elif '_IPTV-MOVIES' in T0E1NY7V4pLXyHtxCkfw8mWUd3n9: Et7IhqupLyZ8deaolcjx = oCwTNBlr9RL3[2]
			elif '_IPTV-SERIES' in T0E1NY7V4pLXyHtxCkfw8mWUd3n9: Et7IhqupLyZ8deaolcjx = oCwTNBlr9RL3[3]
			else: Et7IhqupLyZ8deaolcjx = oCwTNBlr9RL3[0]
		else:
			guNjUlR76F9 = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			NN8u2B5iU3RMYheFy = Eb7qJoNwOgn('أختر البحث المناسب', guNjUlR76F9)
			if NN8u2B5iU3RMYheFy==-1: return
			Et7IhqupLyZ8deaolcjx = oCwTNBlr9RL3[NN8u2B5iU3RMYheFy]
	lNrxbMS5pKBHoi2v34jyCL7Xd6 = WZMblRwhQNn9Gqo.lower()
	Zp5LawF3h1OU0xyucVqzk = Uk0JAvcrY6X(ZZNvmiGjlpwIOx,'SEARCH')
	x4xVJLXyIQbSqlHWem = Mqk51CFBym0pIQXZLsOxSJ(Zp5LawF3h1OU0xyucVqzk,'list','SEARCH',(Et7IhqupLyZ8deaolcjx,lNrxbMS5pKBHoi2v34jyCL7Xd6))
	if not x4xVJLXyIQbSqlHWem:
		z2bOyNct81uAR,T4fGtUo0gmpPe91BqM = [],[]
		if not Et7IhqupLyZ8deaolcjx: vvtPUc5oRpWnI3KOYs7 = [1,2,3,4,5]
		else: vvtPUc5oRpWnI3KOYs7 = [oCwTNBlr9RL3.index(Et7IhqupLyZ8deaolcjx)]
		for qHM8P3uk06wSa1VfZXijWN2 in vvtPUc5oRpWnI3KOYs7:
			Zp5LawF3h1OU0xyucVqzk = Uk0JAvcrY6X(ZZNvmiGjlpwIOx,oCwTNBlr9RL3[qHM8P3uk06wSa1VfZXijWN2])
			if qHM8P3uk06wSa1VfZXijWN2!=3:
				tw5Zql97GHv4Cu1jEY8PDBy6 = Mqk51CFBym0pIQXZLsOxSJ(Zp5LawF3h1OU0xyucVqzk,'dict',oCwTNBlr9RL3[qHM8P3uk06wSa1VfZXijWN2])
				del tw5Zql97GHv4Cu1jEY8PDBy6['__COUNT__']
				del tw5Zql97GHv4Cu1jEY8PDBy6['__GROUPS__']
				del tw5Zql97GHv4Cu1jEY8PDBy6['__SEQUENCED_COLUMNS__']
				Y2YJtGk97sEMgD6LRplT85Ovm = list(tw5Zql97GHv4Cu1jEY8PDBy6.keys())
				for NCyaEWFD0HwzO7chxlv8jupKItGB9 in Y2YJtGk97sEMgD6LRplT85Ovm:
					for kCaIufXo1F0TyL7gtcJV5bneijMWHv,NiUSJbP8kMVZY,O9z5L3KtXqPEMepJQ0,efLKh7nE5X8UAgBRil3yZ in tw5Zql97GHv4Cu1jEY8PDBy6[NCyaEWFD0HwzO7chxlv8jupKItGB9]:
						if lNrxbMS5pKBHoi2v34jyCL7Xd6 in NiUSJbP8kMVZY.lower(): T4fGtUo0gmpPe91BqM.append((NiUSJbP8kMVZY,O9z5L3KtXqPEMepJQ0,efLKh7nE5X8UAgBRil3yZ))
					del tw5Zql97GHv4Cu1jEY8PDBy6[NCyaEWFD0HwzO7chxlv8jupKItGB9]
				del tw5Zql97GHv4Cu1jEY8PDBy6
			else: Y2YJtGk97sEMgD6LRplT85Ovm = Mqk51CFBym0pIQXZLsOxSJ(Zp5LawF3h1OU0xyucVqzk,'list',oCwTNBlr9RL3[qHM8P3uk06wSa1VfZXijWN2],'__GROUPS__')
			for NCyaEWFD0HwzO7chxlv8jupKItGB9 in Y2YJtGk97sEMgD6LRplT85Ovm:
				try: NCyaEWFD0HwzO7chxlv8jupKItGB9,efLKh7nE5X8UAgBRil3yZ = NCyaEWFD0HwzO7chxlv8jupKItGB9
				except: efLKh7nE5X8UAgBRil3yZ = hWGMqtBy4wuLaVcj
				if lNrxbMS5pKBHoi2v34jyCL7Xd6 in NCyaEWFD0HwzO7chxlv8jupKItGB9.lower():
					if qHM8P3uk06wSa1VfZXijWN2!=3: NWG27IXrqeiLD9JoYgm36f4 = NCyaEWFD0HwzO7chxlv8jupKItGB9
					else:
						ABoEGOZSn6Ps,h3hnLaK67xNWBcd92wJfXg = NCyaEWFD0HwzO7chxlv8jupKItGB9.split('__SERIES__')
						if lNrxbMS5pKBHoi2v34jyCL7Xd6 in ABoEGOZSn6Ps.lower(): NWG27IXrqeiLD9JoYgm36f4 = ABoEGOZSn6Ps
						else: NWG27IXrqeiLD9JoYgm36f4 = h3hnLaK67xNWBcd92wJfXg
					z2bOyNct81uAR.append((NCyaEWFD0HwzO7chxlv8jupKItGB9,NWG27IXrqeiLD9JoYgm36f4,oCwTNBlr9RL3[qHM8P3uk06wSa1VfZXijWN2],efLKh7nE5X8UAgBRil3yZ))
			del Y2YJtGk97sEMgD6LRplT85Ovm
		z2bOyNct81uAR = set(z2bOyNct81uAR)
		T4fGtUo0gmpPe91BqM = set(T4fGtUo0gmpPe91BqM)
		z2bOyNct81uAR = sorted(z2bOyNct81uAR,reverse=False,key=lambda W6kuMbXBPcHdlyNGxeZ3T: W6kuMbXBPcHdlyNGxeZ3T[1])
		T4fGtUo0gmpPe91BqM = sorted(T4fGtUo0gmpPe91BqM,reverse=False,key=lambda W6kuMbXBPcHdlyNGxeZ3T: W6kuMbXBPcHdlyNGxeZ3T[0])
		BxuD7iQRpW1(Zp5LawF3h1OU0xyucVqzk,'SEARCH',(Et7IhqupLyZ8deaolcjx,lNrxbMS5pKBHoi2v34jyCL7Xd6),(z2bOyNct81uAR,T4fGtUo0gmpPe91BqM),VWxPgG1p8Z2Ei4DrX7NotvR)
	else: z2bOyNct81uAR,T4fGtUo0gmpPe91BqM = x4xVJLXyIQbSqlHWem
	Y2YJtGk97sEMgD6LRplT85Ovm = len(z2bOyNct81uAR)
	WsQdfzq8GrOtx5iCL = len(T4fGtUo0gmpPe91BqM)
	z5NBJ1tXibWlaTfhdo0FG = int(Z5nl0jQD6XTI8ux)
	WWBk6MurtUgVi = max(0,(z5NBJ1tXibWlaTfhdo0FG-1)*100)
	GwLE5lP36TmuKScYbk = max(0,z5NBJ1tXibWlaTfhdo0FG*100)
	NFgsClzyIpPixj79dcuE36 = max(0,WWBk6MurtUgVi-Y2YJtGk97sEMgD6LRplT85Ovm)
	ncMlOQ9R6BgPbs71iXqDp2yASLYr = max(0,GwLE5lP36TmuKScYbk-Y2YJtGk97sEMgD6LRplT85Ovm)
	for NCyaEWFD0HwzO7chxlv8jupKItGB9,NWG27IXrqeiLD9JoYgm36f4,pLA3jgZfIVdOaMYnQxb,efLKh7nE5X8UAgBRil3yZ in z2bOyNct81uAR[WWBk6MurtUgVi:GwLE5lP36TmuKScYbk]:
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',O50cprnq2W1DAgTiRZUm+NWG27IXrqeiLD9JoYgm36f4,pLA3jgZfIVdOaMYnQxb,234,efLKh7nE5X8UAgBRil3yZ,'1',NCyaEWFD0HwzO7chxlv8jupKItGB9,hWGMqtBy4wuLaVcj,{'folder':ZZNvmiGjlpwIOx})
	del z2bOyNct81uAR
	for NiUSJbP8kMVZY,O9z5L3KtXqPEMepJQ0,efLKh7nE5X8UAgBRil3yZ in T4fGtUo0gmpPe91BqM[NFgsClzyIpPixj79dcuE36:ncMlOQ9R6BgPbs71iXqDp2yASLYr]:
		rTSpRByEW5m7xjXQzJHf8o = UGBbEtrcu5jLC6Sxoa3gFyP1mJOpW(O9z5L3KtXqPEMepJQ0)
		udRvjXt9cAfha5ZsBP3U = 'live'
		if '.mkv' in rTSpRByEW5m7xjXQzJHf8o or 'VOD' in Et7IhqupLyZ8deaolcjx: udRvjXt9cAfha5ZsBP3U = 'video'
		RLDCGt8kq3OVmnzgx1rbi2f7F(udRvjXt9cAfha5ZsBP3U,O50cprnq2W1DAgTiRZUm+NiUSJbP8kMVZY,O9z5L3KtXqPEMepJQ0,235,efLKh7nE5X8UAgBRil3yZ,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,{'folder':ZZNvmiGjlpwIOx})
	del T4fGtUo0gmpPe91BqM
	XzIHbY0Q5OD(ZZNvmiGjlpwIOx,Z5nl0jQD6XTI8ux,Et7IhqupLyZ8deaolcjx,239,Y2YJtGk97sEMgD6LRplT85Ovm+WsQdfzq8GrOtx5iCL,WZMblRwhQNn9Gqo+'_NODIALOGS_')
	return
def XzIHbY0Q5OD(ZZNvmiGjlpwIOx,Z5nl0jQD6XTI8ux,Et7IhqupLyZ8deaolcjx,JbpxsyQVXmSEYKM3vo847Ckh,xYt7uXLKMInBEvH8,s9ea72VfoygAOFRCWQTH3zmDuLPE):
	if Z5nl0jQD6XTI8ux!='1': RLDCGt8kq3OVmnzgx1rbi2f7F('folder',O50cprnq2W1DAgTiRZUm+'صفحة '+str(1),Et7IhqupLyZ8deaolcjx,JbpxsyQVXmSEYKM3vo847Ckh,hWGMqtBy4wuLaVcj,str(1),s9ea72VfoygAOFRCWQTH3zmDuLPE,hWGMqtBy4wuLaVcj,{'folder':ZZNvmiGjlpwIOx})
	if not xYt7uXLKMInBEvH8: xYt7uXLKMInBEvH8 = 0
	ClWinPDkyep6X7NGQIaSzYsEZK = int(xYt7uXLKMInBEvH8/100)+1
	for z5NBJ1tXibWlaTfhdo0FG in range(2,ClWinPDkyep6X7NGQIaSzYsEZK):
		GISLirb8FH = (z5NBJ1tXibWlaTfhdo0FG%10==0 or int(Z5nl0jQD6XTI8ux)-4<z5NBJ1tXibWlaTfhdo0FG<int(Z5nl0jQD6XTI8ux)+4)
		oUV67q9SAXCic2Jdr = (GISLirb8FH and int(Z5nl0jQD6XTI8ux)-40<z5NBJ1tXibWlaTfhdo0FG<int(Z5nl0jQD6XTI8ux)+40)
		if str(z5NBJ1tXibWlaTfhdo0FG)!=Z5nl0jQD6XTI8ux and (z5NBJ1tXibWlaTfhdo0FG%100==0 or oUV67q9SAXCic2Jdr):
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',O50cprnq2W1DAgTiRZUm+'صفحة '+str(z5NBJ1tXibWlaTfhdo0FG),Et7IhqupLyZ8deaolcjx,JbpxsyQVXmSEYKM3vo847Ckh,hWGMqtBy4wuLaVcj,str(z5NBJ1tXibWlaTfhdo0FG),s9ea72VfoygAOFRCWQTH3zmDuLPE,hWGMqtBy4wuLaVcj,{'folder':ZZNvmiGjlpwIOx})
	if str(ClWinPDkyep6X7NGQIaSzYsEZK)!=Z5nl0jQD6XTI8ux: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',O50cprnq2W1DAgTiRZUm+'أخر صفحة '+str(ClWinPDkyep6X7NGQIaSzYsEZK),Et7IhqupLyZ8deaolcjx,JbpxsyQVXmSEYKM3vo847Ckh,hWGMqtBy4wuLaVcj,str(ClWinPDkyep6X7NGQIaSzYsEZK),s9ea72VfoygAOFRCWQTH3zmDuLPE,hWGMqtBy4wuLaVcj,{'folder':ZZNvmiGjlpwIOx})
	return
def Uk0JAvcrY6X(ZZNvmiGjlpwIOx,Et7IhqupLyZ8deaolcjx):
	if 'SERIES' in Et7IhqupLyZ8deaolcjx or 'VOD_ORIGINAL' in Et7IhqupLyZ8deaolcjx: Zp5LawF3h1OU0xyucVqzk = Y3fGRujshztP0ZHgTBmkEdSiy89nV4
	else: Zp5LawF3h1OU0xyucVqzk = bXmN7lhEQo2Tv4WGgDp5
	Zp5LawF3h1OU0xyucVqzk = Zp5LawF3h1OU0xyucVqzk.replace('___','_'+ZZNvmiGjlpwIOx)
	return Zp5LawF3h1OU0xyucVqzk
def qqEHNFxhesSP1Aru7G2(ZZNvmiGjlpwIOx,Et7IhqupLyZ8deaolcjx,IjF9xVMKtS20UOZahnu5zDAcQ):
	IxdSqDFvuO8wYb7f6KVJsTBGiycg,LJmA1qSt9aXc,WJ4jm6MzHbSQcO9,wNf6hz8Vtq2J4eULdBpRFCG5imj,VyaUHwQzXLqJS = WWKXJ7yo4Gb3qYsmvg5BCVHhj0P(ZZNvmiGjlpwIOx)
	if not wNf6hz8Vtq2J4eULdBpRFCG5imj: return
	eE4wIviRq52y316 = b5bp1UwmZdnxiEJ3DlSu6hMzqX2v(ZZNvmiGjlpwIOx)
	if   Et7IhqupLyZ8deaolcjx=='XTREAM_LIVE_GROUPS': O9z5L3KtXqPEMepJQ0 = IxdSqDFvuO8wYb7f6KVJsTBGiycg+'&action=get_live_categories'
	elif Et7IhqupLyZ8deaolcjx=='XTREAM_VOD_GROUPS': O9z5L3KtXqPEMepJQ0 = IxdSqDFvuO8wYb7f6KVJsTBGiycg+'&action=get_vod_categories'
	elif Et7IhqupLyZ8deaolcjx=='XTREAM_SERIES_GROUPS': O9z5L3KtXqPEMepJQ0 = IxdSqDFvuO8wYb7f6KVJsTBGiycg+'&action=get_series_categories'
	elif Et7IhqupLyZ8deaolcjx=='XTREAM_LIVE_ITEMS': O9z5L3KtXqPEMepJQ0 = IxdSqDFvuO8wYb7f6KVJsTBGiycg+'&action=get_live_streams&category_id='+IjF9xVMKtS20UOZahnu5zDAcQ
	elif Et7IhqupLyZ8deaolcjx=='XTREAM_VOD_ITEMS': O9z5L3KtXqPEMepJQ0 = IxdSqDFvuO8wYb7f6KVJsTBGiycg+'&action=get_vod_streams&category_id='+IjF9xVMKtS20UOZahnu5zDAcQ
	elif Et7IhqupLyZ8deaolcjx=='XTREAM_SERIES_ITEMS': O9z5L3KtXqPEMepJQ0 = IxdSqDFvuO8wYb7f6KVJsTBGiycg+'&action=get_series&category_id='+IjF9xVMKtS20UOZahnu5zDAcQ
	elif Et7IhqupLyZ8deaolcjx=='XTREAM_EPISODES': O9z5L3KtXqPEMepJQ0 = IxdSqDFvuO8wYb7f6KVJsTBGiycg+'&action=get_series_info&series_id='+IjF9xVMKtS20UOZahnu5zDAcQ
	else: return
	oTawtcGI687h = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',O9z5L3KtXqPEMepJQ0,hWGMqtBy4wuLaVcj,eE4wIviRq52y316,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'IPTV-XTREAM_MENUS-1st')
	zJjQP6hXe8vbdrTDq1EmZwncYUL = oTawtcGI687h.content
	if VKiGj1LundAJQwEXcqgxC: zJjQP6hXe8vbdrTDq1EmZwncYUL = zJjQP6hXe8vbdrTDq1EmZwncYUL.decode(a7VXeDU82IfQEnPZAdiT).encode(a7VXeDU82IfQEnPZAdiT)
	sjD6voFCBmhW9 = Cy9ow3c21nABMjzqeaIT('list',zJjQP6hXe8vbdrTDq1EmZwncYUL)
	if 'GROUPS' in Et7IhqupLyZ8deaolcjx:
		Et7IhqupLyZ8deaolcjx = Et7IhqupLyZ8deaolcjx.replace('_GROUPS','_ITEMS')
		sjD6voFCBmhW9 = sorted(sjD6voFCBmhW9,reverse=False,key=lambda W6kuMbXBPcHdlyNGxeZ3T: W6kuMbXBPcHdlyNGxeZ3T['category_name'].lower())
		for NCyaEWFD0HwzO7chxlv8jupKItGB9 in sjD6voFCBmhW9:
			w61tpc5IA0h7gP2vfEOTe = NCyaEWFD0HwzO7chxlv8jupKItGB9['category_id']
			NiUSJbP8kMVZY = NCyaEWFD0HwzO7chxlv8jupKItGB9['category_name']
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',O50cprnq2W1DAgTiRZUm+NiUSJbP8kMVZY,Et7IhqupLyZ8deaolcjx,285,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,str(w61tpc5IA0h7gP2vfEOTe),hWGMqtBy4wuLaVcj,{'folder':ZZNvmiGjlpwIOx})
	elif Et7IhqupLyZ8deaolcjx=='XTREAM_SERIES_ITEMS':
		sjD6voFCBmhW9 = sorted(sjD6voFCBmhW9,reverse=False,key=lambda W6kuMbXBPcHdlyNGxeZ3T: W6kuMbXBPcHdlyNGxeZ3T['name'].lower())
		for VgDfaXpuMPidv in sjD6voFCBmhW9:
			NiUSJbP8kMVZY = VgDfaXpuMPidv['name']
			acysH2W9N0BhXIvJPRM5t = VgDfaXpuMPidv['cover']
			w61tpc5IA0h7gP2vfEOTe = VgDfaXpuMPidv['series_id']
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',O50cprnq2W1DAgTiRZUm+NiUSJbP8kMVZY,'XTREAM_EPISODES',285,acysH2W9N0BhXIvJPRM5t,hWGMqtBy4wuLaVcj,str(w61tpc5IA0h7gP2vfEOTe),hWGMqtBy4wuLaVcj,{'folder':ZZNvmiGjlpwIOx})
	elif Et7IhqupLyZ8deaolcjx=='XTREAM_EPISODES':
		acysH2W9N0BhXIvJPRM5t = sjD6voFCBmhW9['info']['cover']
		j4lHpxXvnF2VtwBb1T9PaJEm3 = sjD6voFCBmhW9['info']['name']
		ccikmw3qN9h = sjD6voFCBmhW9['episodes']
		for b0xyiMzrKJSp18jGckRNtBh in ccikmw3qN9h:
			uxo5jY7S9UhLmJFZd4VXvOrfH = ccikmw3qN9h[b0xyiMzrKJSp18jGckRNtBh]
			for xxHFOySPL316iD in uxo5jY7S9UhLmJFZd4VXvOrfH:
				NiUSJbP8kMVZY = xxHFOySPL316iD['title']
				rrXw9fL6coyIE8gRaZ4l5HnMGp = trdVA0JvFaD.findall('\d+.(S\d+E\d+)',NiUSJbP8kMVZY,trdVA0JvFaD.DOTALL)
				if rrXw9fL6coyIE8gRaZ4l5HnMGp: NiUSJbP8kMVZY = j4lHpxXvnF2VtwBb1T9PaJEm3+Mpsm2VF1OBnCRvK3qf6+rrXw9fL6coyIE8gRaZ4l5HnMGp[0]
				w61tpc5IA0h7gP2vfEOTe = xxHFOySPL316iD['id']
				gt2kBxbEvcUNfsP5eI3aMVrpjSuy = xxHFOySPL316iD['container_extension']
				O9z5L3KtXqPEMepJQ0 = IxdSqDFvuO8wYb7f6KVJsTBGiycg.split('/player_api.php')[0]+'/series/'+wNf6hz8Vtq2J4eULdBpRFCG5imj+'/'+VyaUHwQzXLqJS+'/'+str(w61tpc5IA0h7gP2vfEOTe)+'.'+gt2kBxbEvcUNfsP5eI3aMVrpjSuy
				RLDCGt8kq3OVmnzgx1rbi2f7F('video',O50cprnq2W1DAgTiRZUm+NiUSJbP8kMVZY,O9z5L3KtXqPEMepJQ0,235,acysH2W9N0BhXIvJPRM5t,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,{'folder':ZZNvmiGjlpwIOx})
	elif 'ITEMS' in Et7IhqupLyZ8deaolcjx:
		udRvjXt9cAfha5ZsBP3U = 'live' if 'LIVE' in Et7IhqupLyZ8deaolcjx else 'video'
		sjD6voFCBmhW9 = sorted(sjD6voFCBmhW9,reverse=False,key=lambda W6kuMbXBPcHdlyNGxeZ3T: W6kuMbXBPcHdlyNGxeZ3T['name'].lower())
		for tcmpfER6e2Nrzi in sjD6voFCBmhW9:
			NiUSJbP8kMVZY = tcmpfER6e2Nrzi['name']
			acysH2W9N0BhXIvJPRM5t = tcmpfER6e2Nrzi['stream_icon']
			w61tpc5IA0h7gP2vfEOTe = tcmpfER6e2Nrzi['stream_id']
			try:
				gt2kBxbEvcUNfsP5eI3aMVrpjSuy = tcmpfER6e2Nrzi['container_extension']
				if gt2kBxbEvcUNfsP5eI3aMVrpjSuy: gt2kBxbEvcUNfsP5eI3aMVrpjSuy = '.'+gt2kBxbEvcUNfsP5eI3aMVrpjSuy
			except: gt2kBxbEvcUNfsP5eI3aMVrpjSuy = hWGMqtBy4wuLaVcj
			if tcmpfER6e2Nrzi['stream_type']=='live': HTUOSQ3vdcRhEAnCmt0aIbiV,IkFuCf7gebmRrvTXJO9nAsSHlK4oU6 = hWGMqtBy4wuLaVcj,'live'
			elif tcmpfER6e2Nrzi['stream_type']=='movie': HTUOSQ3vdcRhEAnCmt0aIbiV,IkFuCf7gebmRrvTXJO9nAsSHlK4oU6 = 'movie/','video'
			O9z5L3KtXqPEMepJQ0 = IxdSqDFvuO8wYb7f6KVJsTBGiycg.split('/player_api.php')[0]+'/'+HTUOSQ3vdcRhEAnCmt0aIbiV+wNf6hz8Vtq2J4eULdBpRFCG5imj+'/'+VyaUHwQzXLqJS+'/'+str(w61tpc5IA0h7gP2vfEOTe)+gt2kBxbEvcUNfsP5eI3aMVrpjSuy
			RLDCGt8kq3OVmnzgx1rbi2f7F(udRvjXt9cAfha5ZsBP3U,O50cprnq2W1DAgTiRZUm+NiUSJbP8kMVZY,O9z5L3KtXqPEMepJQ0,235,acysH2W9N0BhXIvJPRM5t,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,{'folder':ZZNvmiGjlpwIOx})
	return
def SRc0wiMvLgkPJ5zhpbUfHn2(ZZNvmiGjlpwIOx):
	jg5XFhouLKxBHDf = ee8c0jzrTntGSUdRJm.getSetting('av.language.provider')
	tDJsWk6lj7ihA9La1yC = ee8c0jzrTntGSUdRJm.getSetting('av.language.code')
	pMPR1Cc0usZ6nJTU(MM5Dx39f7ULhcJsRptzIowP,'MENUS_CACHE_'+jg5XFhouLKxBHDf+'_'+tDJsWk6lj7ihA9La1yC,'%_IP'+ZZNvmiGjlpwIOx+'_%')
	return
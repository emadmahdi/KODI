# -*- coding: utf-8 -*-
from yoY3NdGViS import *
xjPuFK3EsIZSiobQ5X = 'FASELHD2'
headers = {'User-Agent':hWGMqtBy4wuLaVcj}
n0qFKQWhiBYXoTrvejVHUA4 = '_FH2_'
Str0BupDTFA = u6rbxnyjTl7I[xjPuFK3EsIZSiobQ5X][0]
P3UK1Rr4IdYe5 = ['wwe']
def ehB18u9sQFRi(mode,url,text):
	if   mode==590: N6NCYivtV4I5rEXq = DP6FSBgNdX1rsvVR()
	elif mode==591: N6NCYivtV4I5rEXq = wg5aF3e8rcDh7SGpW6M1OPnkU(url,text)
	elif mode==592: N6NCYivtV4I5rEXq = oanus6TxUFNAhSZKpJdYlEC4mV(url)
	elif mode==593: N6NCYivtV4I5rEXq = UCjs37gPYNoqt(url,text)
	elif mode==599: N6NCYivtV4I5rEXq = lPwaAjFTMG4n7iSLkXcEuK0Zm(text)
	else: N6NCYivtV4I5rEXq = False
	return N6NCYivtV4I5rEXq
def DP6FSBgNdX1rsvVR():
	cbYKa2SXGwRCiQIW5NeosU9k = Str0BupDTFA
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',cbYKa2SXGwRCiQIW5NeosU9k,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'FASELHD2-MENU-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'بحث في الموقع',cbYKa2SXGwRCiQIW5NeosU9k,599,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'_REMEMBERRESULTS_')
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'المميزة',cbYKa2SXGwRCiQIW5NeosU9k,591,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'featured1')
	items = trdVA0JvFaD.findall('<strong>(.*?)</strong>.*?href="(.*?)"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	for title,llxFwq0CUNgQtivJzkHeGV in items:
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,591,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'details1')
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('main-menu"(.*?)header-social',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		iiy48BO9TJ5 = trdVA0JvFaD.findall('<li (.*?)</li>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for p7tSrCjXlc6M1i5WQTgq9zGJF in iiy48BO9TJ5:
			items = trdVA0JvFaD.findall('href="(.*?)".*?>(.*?)<',p7tSrCjXlc6M1i5WQTgq9zGJF,trdVA0JvFaD.DOTALL)
			for llxFwq0CUNgQtivJzkHeGV,title in items:
				if 'http' not in llxFwq0CUNgQtivJzkHeGV: llxFwq0CUNgQtivJzkHeGV = cbYKa2SXGwRCiQIW5NeosU9k+llxFwq0CUNgQtivJzkHeGV
				RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,591,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'details2')
	return mMQ3FkNVa4IlxqY
def wg5aF3e8rcDh7SGpW6M1OPnkU(url,type=hWGMqtBy4wuLaVcj):
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'FASELHD2-TITLES-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	ff8mcgrzb6xhnDk5Qdw3qA0JFl1 = 0
	v2V8Nmrwf4 = trdVA0JvFaD.findall('"archive-slider(.*?)<h4>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if v2V8Nmrwf4: TfCqlZthRYgzkbE0GO = v2V8Nmrwf4[0]
	else: TfCqlZthRYgzkbE0GO = hWGMqtBy4wuLaVcj
	if type=='featured1':
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('"slider-carousel"(.*?)</container>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall(' src="(.*?)".*?"slider-title">(.*?)<.*?<a href="(.*?)"',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		nGRxyZU4zWrK,LHN1Zr7FDtbYfjz069Gnh,m4IznKilUOByHweG68VJ = zip(*items)
		items = zip(m4IznKilUOByHweG68VJ,nGRxyZU4zWrK,LHN1Zr7FDtbYfjz069Gnh)
	elif type=='featured2':
		items = trdVA0JvFaD.findall('href="(.*?)".*?image:url\((.*?)\).*?<h3.*?>(.*?)</h3>',TfCqlZthRYgzkbE0GO,trdVA0JvFaD.DOTALL)
	elif type=='filters':
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = [mMQ3FkNVa4IlxqY.replace('\\/','/').replace('\\"','"')]
	elif type=='details2' and 'href' in TfCqlZthRYgzkbE0GO:
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('<h4>(.*?)</h4>(.*?)</container>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'مميزة',url,591,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'featured2')
		title = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0][0]
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,url,591,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'details3')
		return
	else:
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('<h4>(.*?)</h4>(.*?)</container>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		title,cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('href="(.*?)".*?image:url\((.*?)\).*?<h3.*?>(.*?)</h3>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	nNBCdTs98RztMyODHpL63ZUKm4P = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية','حلقة']
	REbVyXis1w4Ae = []
	for llxFwq0CUNgQtivJzkHeGV,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,title in items:
		if any(BoSjXKxz41DcneO9UimClE in title.lower() for BoSjXKxz41DcneO9UimClE in P3UK1Rr4IdYe5): continue
		title = title.strip(Mpsm2VF1OBnCRvK3qf6)
		title = LNtIDdBA52P(title)
		IIsmGy4pd7 = trdVA0JvFaD.findall('(.*?) (الحلقة|حلقة).\d+',title,trdVA0JvFaD.DOTALL)
		if '/movseries/' in llxFwq0CUNgQtivJzkHeGV:
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,591,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
		elif IIsmGy4pd7 and type==hWGMqtBy4wuLaVcj:
			title = '_MOD_'+IIsmGy4pd7[0][0]
			if title not in REbVyXis1w4Ae:
				RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,593,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
				REbVyXis1w4Ae.append(title)
		elif any(BoSjXKxz41DcneO9UimClE in title for BoSjXKxz41DcneO9UimClE in nNBCdTs98RztMyODHpL63ZUKm4P):
			RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,592,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
		else: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,593,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
	if type=='filters':
		HHDPiqLBrUbSgveQlFwWz3Xd9O = trdVA0JvFaD.findall('"more_button_page":(.*?),',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		if HHDPiqLBrUbSgveQlFwWz3Xd9O:
			count = HHDPiqLBrUbSgveQlFwWz3Xd9O[0]
			llxFwq0CUNgQtivJzkHeGV = url+'/offset/'+count
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'صفحة أخرى',llxFwq0CUNgQtivJzkHeGV,591,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'filters')
	elif 'details' in type:
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('class="pagination(.*?)</div>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
			cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
			items = trdVA0JvFaD.findall('href="(.*?)">(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
			for llxFwq0CUNgQtivJzkHeGV,title in items:
				title = 'صفحة '+LNtIDdBA52P(title)
				RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,591,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'details4')
	return
def UCjs37gPYNoqt(url,type=hWGMqtBy4wuLaVcj):
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'FASELHD2-SEASONS_EPISODES-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	k8YRdISjEZF0qyzs5GK = False
	if not type:
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('<seasons(.*?)</seasons>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
			cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
			items = trdVA0JvFaD.findall('href="(.*?)".*?image:url\((.*?)\).*?<h3>(.*?)</h3>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
			if len(items)>1:
				cbYKa2SXGwRCiQIW5NeosU9k = RRNODILCtGzvgpx(url,'url')
				k8YRdISjEZF0qyzs5GK = True
				for llxFwq0CUNgQtivJzkHeGV,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,title in items:
					title = LNtIDdBA52P(title)
					RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,593,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,hWGMqtBy4wuLaVcj,'episodes')
	if type=='episodes' or not k8YRdISjEZF0qyzs5GK:
		nWE8aO53lFfD = trdVA0JvFaD.findall('<bkز*?image:url\((.*?)\)"></bk>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if nWE8aO53lFfD: Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG = nWE8aO53lFfD[0]
		else: Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG = hWGMqtBy4wuLaVcj
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('<all-episodes(.*?)</all-episodes>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
			cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
			items = trdVA0JvFaD.findall('href="(.*?)".*?>(.*?)</a>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
			for llxFwq0CUNgQtivJzkHeGV,title in items:
				title = title.strip(Mpsm2VF1OBnCRvK3qf6)
				title = LNtIDdBA52P(title)
				RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,592,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
	return
def oanus6TxUFNAhSZKpJdYlEC4mV(url):
	zmDKurMJwj6fi,wIKcsSv7mX6ylH15,UEYlTGJarmz = [],[],[]
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(nHBb7jXk0Daom,'GET',url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'FASELHD2-PLAY-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	wxFEhq5c4GHBJftRezlrTI7 = trdVA0JvFaD.findall('العمر :.*?<strong">(.*?)</strong>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if wxFEhq5c4GHBJftRezlrTI7 and Dc20k3vN9hT5(xjPuFK3EsIZSiobQ5X,url,wxFEhq5c4GHBJftRezlrTI7): return
	llxFwq0CUNgQtivJzkHeGV = trdVA0JvFaD.findall('<iframe src="(.*?)"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if llxFwq0CUNgQtivJzkHeGV:
		llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV[0]
		zmDKurMJwj6fi.append(llxFwq0CUNgQtivJzkHeGV+'?named=__embed')
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('<slice-title(.*?)</ul>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('data-url="(.*?)".*?</i>(.*?)</li>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,name in items:
			name = name.strip(Mpsm2VF1OBnCRvK3qf6)
			zmDKurMJwj6fi.append(llxFwq0CUNgQtivJzkHeGV+'?named='+name+'__watch')
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('<downloads(.*?)</downloads>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('href="(.*?)".*?</div>(.*?)</div>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,name in items:
			zmDKurMJwj6fi.append(llxFwq0CUNgQtivJzkHeGV+'?named='+name+'__download')
	for ltukdO8wbXmUvIZTPKSC1qHc6VG in zmDKurMJwj6fi:
		llxFwq0CUNgQtivJzkHeGV,name = ltukdO8wbXmUvIZTPKSC1qHc6VG.split('?named')
		if llxFwq0CUNgQtivJzkHeGV not in wIKcsSv7mX6ylH15:
			wIKcsSv7mX6ylH15.append(llxFwq0CUNgQtivJzkHeGV)
			UEYlTGJarmz.append(ltukdO8wbXmUvIZTPKSC1qHc6VG)
	import oosSOfvdEQ
	oosSOfvdEQ.zfdYjsGLg8M6i15qZWh(UEYlTGJarmz,xjPuFK3EsIZSiobQ5X,'video',url)
	return
def lPwaAjFTMG4n7iSLkXcEuK0Zm(search):
	search,vvKf4sXgZIMyEJPuC,showDialogs = IVTEJQOiMR2dYta9C(search)
	if search==hWGMqtBy4wuLaVcj: search = TrzfUidpv1LyAYqwexHJDuS()
	if search==hWGMqtBy4wuLaVcj: return
	search = search.replace(Mpsm2VF1OBnCRvK3qf6,'+')
	cbYKa2SXGwRCiQIW5NeosU9k = Str0BupDTFA
	url = cbYKa2SXGwRCiQIW5NeosU9k+'/?s='+search
	wg5aF3e8rcDh7SGpW6M1OPnkU(url,'details5')
	return
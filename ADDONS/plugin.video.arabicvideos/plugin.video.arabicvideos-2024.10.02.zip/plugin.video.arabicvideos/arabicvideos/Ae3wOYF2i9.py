# -*- coding: utf-8 -*-
from yoY3NdGViS import *
xjPuFK3EsIZSiobQ5X = 'ALARAB'
headers = {'User-Agent':hWGMqtBy4wuLaVcj}
n0qFKQWhiBYXoTrvejVHUA4 = '_KLA_'
Str0BupDTFA = u6rbxnyjTl7I[xjPuFK3EsIZSiobQ5X][0]
def ehB18u9sQFRi(mode,url,text):
	if   mode==10: N6NCYivtV4I5rEXq = DP6FSBgNdX1rsvVR()
	elif mode==11: N6NCYivtV4I5rEXq = wg5aF3e8rcDh7SGpW6M1OPnkU(url)
	elif mode==12: N6NCYivtV4I5rEXq = oanus6TxUFNAhSZKpJdYlEC4mV(url)
	elif mode==13: N6NCYivtV4I5rEXq = GrsxUhb0PEXj2FQRAkD4q(url)
	elif mode==14: N6NCYivtV4I5rEXq = Z5sr7Hb9NXJKVG()
	elif mode==15: N6NCYivtV4I5rEXq = qwGbBEYSt0k82h53T()
	elif mode==16: N6NCYivtV4I5rEXq = RFjN4bo7CcDV()
	elif mode==19: N6NCYivtV4I5rEXq = lPwaAjFTMG4n7iSLkXcEuK0Zm(text)
	else: N6NCYivtV4I5rEXq = False
	return N6NCYivtV4I5rEXq
def DP6FSBgNdX1rsvVR():
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'بحث في الموقع',hWGMqtBy4wuLaVcj,19,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'_REMEMBERRESULTS_')
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+'آخر الإضافات',hWGMqtBy4wuLaVcj,14)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+'مسلسلات رمضان',hWGMqtBy4wuLaVcj,15)
	mMQ3FkNVa4IlxqY = f1fLNcPlo2ECKtiBeug0OAvz9YM(DpQifS0oKBI1hYcO,Str0BupDTFA,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,'ALARAB-MENU-1st')
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o=trdVA0JvFaD.findall('id="nav-slider"(.*?)</div>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	xIF5lSiToba8HRQ6jLtyEkN9s7m = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
	items = trdVA0JvFaD.findall('href="(.*?)".*?>(.*?)<',xIF5lSiToba8HRQ6jLtyEkN9s7m,trdVA0JvFaD.DOTALL)
	for llxFwq0CUNgQtivJzkHeGV,title in items:
		llxFwq0CUNgQtivJzkHeGV = Str0BupDTFA+llxFwq0CUNgQtivJzkHeGV
		title = title.strip(Mpsm2VF1OBnCRvK3qf6)
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,11)
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('id="navbar"(.*?)</div>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	TfCqlZthRYgzkbE0GO = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
	items = trdVA0JvFaD.findall('href="(.*?)".*?>(.*?)<',TfCqlZthRYgzkbE0GO,trdVA0JvFaD.DOTALL)
	for llxFwq0CUNgQtivJzkHeGV,title in items:
		llxFwq0CUNgQtivJzkHeGV = Str0BupDTFA+llxFwq0CUNgQtivJzkHeGV
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,11)
	return mMQ3FkNVa4IlxqY
def qwGbBEYSt0k82h53T():
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'جميع المسلسلات العربية',Str0BupDTFA+'/view-8/مسلسلات-عربية',11)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'مسلسلات السنة الأخيرة',hWGMqtBy4wuLaVcj,16)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'مسلسلات رمضان الأخيرة 1',Str0BupDTFA+'/view-8/مسلسلات-رمضان-2022',11)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'مسلسلات رمضان الأخيرة 2',Str0BupDTFA+'/view-8/مسلسلات-رمضان-2023',11)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'مسلسلات رمضان 2023',Str0BupDTFA+'/ramadan2023/مصرية',11)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'مسلسلات رمضان 2022',Str0BupDTFA+'/ramadan2022/مصرية',11)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'مسلسلات رمضان 2021',Str0BupDTFA+'/ramadan2021/مصرية',11)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'مسلسلات رمضان 2020',Str0BupDTFA+'/ramadan2020/مصرية',11)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'مسلسلات رمضان 2019',Str0BupDTFA+'/ramadan2019/مصرية',11)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'مسلسلات رمضان 2018',Str0BupDTFA+'/ramadan2018/مصرية',11)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'مسلسلات رمضان 2017',Str0BupDTFA+'/ramadan2017/مصرية',11)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'مسلسلات رمضان 2016',Str0BupDTFA+'/ramadan2016/مصرية',11)
	return
def Z5sr7Hb9NXJKVG():
	mMQ3FkNVa4IlxqY = f1fLNcPlo2ECKtiBeug0OAvz9YM(KqO5BWGQR9JVL,Str0BupDTFA,hWGMqtBy4wuLaVcj,headers,True,'ALARAB-LATEST-1st')
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o=trdVA0JvFaD.findall('heading-top(.*?)div class=',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]+DJvksH7ZAFUqW9OyQnbGjPCtwR1o[1]
	items=trdVA0JvFaD.findall('href="(.*?)".*?data-src="(.*?)" alt="(.*?)"',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	for llxFwq0CUNgQtivJzkHeGV,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,title in items:
		url = Str0BupDTFA + llxFwq0CUNgQtivJzkHeGV
		if 'series' in url: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,url,11,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
		else: RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,url,12,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
	return
def wg5aF3e8rcDh7SGpW6M1OPnkU(url):
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',url,hWGMqtBy4wuLaVcj,headers,True,True,'ALARAB-TITLES-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('video-category(.*?)right_content',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if not DJvksH7ZAFUqW9OyQnbGjPCtwR1o: return
	cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
	llnMvPUcTBFr0CgN4sZbRYh1fA8u = False
	items = trdVA0JvFaD.findall('video-box.*?href="(.*?)".*?src="(http.*?)" alt="(.*?)"',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	REbVyXis1w4Ae,q0WatP1ke9EX4xcBQ = [],[]
	for llxFwq0CUNgQtivJzkHeGV,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,title in items:
		if title==hWGMqtBy4wuLaVcj: title = llxFwq0CUNgQtivJzkHeGV.split('/')[-1].replace('-',Mpsm2VF1OBnCRvK3qf6)
		coDr4CpZ9UyQn8txJuA315eN0OjH = trdVA0JvFaD.findall('(\d+)',title,trdVA0JvFaD.DOTALL)
		if coDr4CpZ9UyQn8txJuA315eN0OjH: coDr4CpZ9UyQn8txJuA315eN0OjH = int(coDr4CpZ9UyQn8txJuA315eN0OjH[0])
		else: coDr4CpZ9UyQn8txJuA315eN0OjH = 0
		q0WatP1ke9EX4xcBQ.append([Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,llxFwq0CUNgQtivJzkHeGV,title,coDr4CpZ9UyQn8txJuA315eN0OjH])
	q0WatP1ke9EX4xcBQ = sorted(q0WatP1ke9EX4xcBQ, reverse=True, key=lambda key: key[3])
	for Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,llxFwq0CUNgQtivJzkHeGV,title,coDr4CpZ9UyQn8txJuA315eN0OjH in q0WatP1ke9EX4xcBQ:
		llxFwq0CUNgQtivJzkHeGV = Str0BupDTFA + llxFwq0CUNgQtivJzkHeGV
		title = title.replace('مشاهدة مسلسل','مسلسل')
		title = title.replace('مشاهدة المسلسل','المسلسل')
		title = title.replace('مشاهدة فيلم','فيلم')
		title = title.replace('مشاهدة الفيلم','الفيلم')
		title = title.replace('مباشرة كواليتي',hWGMqtBy4wuLaVcj)
		title = title.replace('عالية على العرب',hWGMqtBy4wuLaVcj)
		title = title.replace('مشاهدة مباشرة',hWGMqtBy4wuLaVcj)
		title = title.replace('اون لاين',hWGMqtBy4wuLaVcj)
		title = title.replace('اونلاين',hWGMqtBy4wuLaVcj)
		title = title.replace('بجودة عالية',hWGMqtBy4wuLaVcj)
		title = title.replace('جودة عالية',hWGMqtBy4wuLaVcj)
		title = title.replace('بدون تحميل',hWGMqtBy4wuLaVcj)
		title = title.replace('على العرب',hWGMqtBy4wuLaVcj)
		title = title.replace('مباشرة',hWGMqtBy4wuLaVcj)
		title = title.strip(Mpsm2VF1OBnCRvK3qf6).replace(FqcVAkh7WjIXHdDKf8nvuyRo,Mpsm2VF1OBnCRvK3qf6).replace(FqcVAkh7WjIXHdDKf8nvuyRo,Mpsm2VF1OBnCRvK3qf6)
		title = '_MOD_'+title
		m4eVoJdSU51qs3y8Gg06fZNau7A = title
		if '/q/' in url and ('الحلقة' in title or 'الحلقه' in title):
			IIsmGy4pd7 = trdVA0JvFaD.findall('(.*?) الحلقة \d+',title,trdVA0JvFaD.DOTALL)
			if IIsmGy4pd7: m4eVoJdSU51qs3y8Gg06fZNau7A = IIsmGy4pd7[0]
		if m4eVoJdSU51qs3y8Gg06fZNau7A not in REbVyXis1w4Ae:
			REbVyXis1w4Ae.append(m4eVoJdSU51qs3y8Gg06fZNau7A)
			if '/q/' in url and ('الحلقة' in title or 'الحلقه' in title):
				RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+m4eVoJdSU51qs3y8Gg06fZNau7A,llxFwq0CUNgQtivJzkHeGV,13,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
				llnMvPUcTBFr0CgN4sZbRYh1fA8u = True
			elif 'series' in llxFwq0CUNgQtivJzkHeGV:
				RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,11,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
				llnMvPUcTBFr0CgN4sZbRYh1fA8u = True
			else:
				RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,12,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
				llnMvPUcTBFr0CgN4sZbRYh1fA8u = True
	if llnMvPUcTBFr0CgN4sZbRYh1fA8u:
		items = trdVA0JvFaD.findall('tsc_3d_button red.*?href="(.*?)" title="(.*?)"',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,l7COkhRWD9uVS60Pte2NoyAaZn in items:
			url = Str0BupDTFA + llxFwq0CUNgQtivJzkHeGV
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+l7COkhRWD9uVS60Pte2NoyAaZn,url,11)
	return
def GrsxUhb0PEXj2FQRAkD4q(url):
	mMQ3FkNVa4IlxqY = f1fLNcPlo2ECKtiBeug0OAvz9YM(KqO5BWGQR9JVL,url,hWGMqtBy4wuLaVcj,headers,True,'ALARAB-EPISODES-1st')
	TT1pO8cio5xCnQufKGHv = trdVA0JvFaD.findall('href="(/series.*?)"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	NPM3HKQ57xe = Str0BupDTFA+TT1pO8cio5xCnQufKGHv[0]
	N6NCYivtV4I5rEXq = wg5aF3e8rcDh7SGpW6M1OPnkU(NPM3HKQ57xe)
	return
def oanus6TxUFNAhSZKpJdYlEC4mV(url):
	Dvi8asSrQYX5wE3KMIxT91me = []
	mMQ3FkNVa4IlxqY = f1fLNcPlo2ECKtiBeug0OAvz9YM(nHBb7jXk0Daom,url,hWGMqtBy4wuLaVcj,headers,True,'ALARAB-PLAY-1st')
	NPM3HKQ57xe = trdVA0JvFaD.findall('class="resp-iframe" src="(.*?)"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if NPM3HKQ57xe:
		NPM3HKQ57xe = NPM3HKQ57xe[0]
		m4IznKilUOByHweG68VJ = trdVA0JvFaD.findall('^(http.*?)(http.*?)$',NPM3HKQ57xe,trdVA0JvFaD.DOTALL)
		if m4IznKilUOByHweG68VJ:
			jlIGSiUuRophY8A = m4IznKilUOByHweG68VJ[0][0]
			Wth685GNi9DRgpIoecQj,U92x5I4nRbfVXyaHqcv8G = m4IznKilUOByHweG68VJ[0][1].rsplit('/',1)
			CMzQFXeI08KDwAJ9p = Wth685GNi9DRgpIoecQj+'?named=__watch'
			Dvi8asSrQYX5wE3KMIxT91me.append(CMzQFXeI08KDwAJ9p)
			FjQOc5WuzKg0Vikb6tDeNHZP1mS = jlIGSiUuRophY8A+U92x5I4nRbfVXyaHqcv8G
		else:
			eecmFXt5SRyCjGpx = f1fLNcPlo2ECKtiBeug0OAvz9YM(DpQifS0oKBI1hYcO,NPM3HKQ57xe,hWGMqtBy4wuLaVcj,headers,False,'ALARAB-PLAY-2nd')
			NPM3HKQ57xe = trdVA0JvFaD.findall('"src": "(.*?)"',eecmFXt5SRyCjGpx,trdVA0JvFaD.DOTALL)
			if NPM3HKQ57xe:
				NPM3HKQ57xe = NPM3HKQ57xe[0]+'?named=__watch__m3u8'
				Dvi8asSrQYX5wE3KMIxT91me.append(NPM3HKQ57xe)
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('searchBox(.*?)<style>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		NPM3HKQ57xe = trdVA0JvFaD.findall('href="(.*?)"',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		if NPM3HKQ57xe:
			NPM3HKQ57xe = NPM3HKQ57xe[0]+'?named=__watch'
			Dvi8asSrQYX5wE3KMIxT91me.append(NPM3HKQ57xe)
	import oosSOfvdEQ
	oosSOfvdEQ.zfdYjsGLg8M6i15qZWh(Dvi8asSrQYX5wE3KMIxT91me,xjPuFK3EsIZSiobQ5X,'video',url)
	return
def RFjN4bo7CcDV():
	mMQ3FkNVa4IlxqY = f1fLNcPlo2ECKtiBeug0OAvz9YM(DpQifS0oKBI1hYcO,Str0BupDTFA,hWGMqtBy4wuLaVcj,headers,True,'ALARAB-RAMADAN-1st')
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('id="content_sec"(.*?)id="left_content"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
	items = trdVA0JvFaD.findall('href="(.*?)".*?>(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	NL7g1WBlwa3iS = trdVA0JvFaD.findall('/ramadan([0-9]+)/',str(items),trdVA0JvFaD.DOTALL)
	NL7g1WBlwa3iS = NL7g1WBlwa3iS[0]
	for llxFwq0CUNgQtivJzkHeGV,title in items:
		url = Str0BupDTFA+llxFwq0CUNgQtivJzkHeGV
		title = title.strip(Mpsm2VF1OBnCRvK3qf6)+Mpsm2VF1OBnCRvK3qf6+NL7g1WBlwa3iS
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,url,11)
	return
def lPwaAjFTMG4n7iSLkXcEuK0Zm(search):
	search,vvKf4sXgZIMyEJPuC,showDialogs = IVTEJQOiMR2dYta9C(search)
	if search==hWGMqtBy4wuLaVcj: search = TrzfUidpv1LyAYqwexHJDuS()
	if search==hWGMqtBy4wuLaVcj: return
	lKqyOtIAvVY = search.replace(Mpsm2VF1OBnCRvK3qf6,'+')
	url = Str0BupDTFA + "/q/" + lKqyOtIAvVY
	N6NCYivtV4I5rEXq = wg5aF3e8rcDh7SGpW6M1OPnkU(url)
	return
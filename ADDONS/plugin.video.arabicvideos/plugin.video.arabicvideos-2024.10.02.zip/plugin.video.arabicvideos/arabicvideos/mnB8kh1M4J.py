# -*- coding: utf-8 -*-
from yoY3NdGViS import *
xjPuFK3EsIZSiobQ5X = 'MOVIZLAND'
headers = { 'User-Agent' : hWGMqtBy4wuLaVcj }
n0qFKQWhiBYXoTrvejVHUA4 = '_MVZ_'
Str0BupDTFA = u6rbxnyjTl7I[xjPuFK3EsIZSiobQ5X][0]
Mr9c3QFRbp4wm = u6rbxnyjTl7I[xjPuFK3EsIZSiobQ5X][1]
def ehB18u9sQFRi(mode,url,text):
	if   mode==180: N6NCYivtV4I5rEXq = DP6FSBgNdX1rsvVR()
	elif mode==181: N6NCYivtV4I5rEXq = wg5aF3e8rcDh7SGpW6M1OPnkU(url,text)
	elif mode==182: N6NCYivtV4I5rEXq = oanus6TxUFNAhSZKpJdYlEC4mV(url)
	elif mode==183: N6NCYivtV4I5rEXq = GrsxUhb0PEXj2FQRAkD4q(url)
	elif mode==188: N6NCYivtV4I5rEXq = w9EdimAtKlPaLGR7TFJWYVhUu()
	elif mode==189: N6NCYivtV4I5rEXq = lPwaAjFTMG4n7iSLkXcEuK0Zm(text)
	else: N6NCYivtV4I5rEXq = False
	return N6NCYivtV4I5rEXq
def w9EdimAtKlPaLGR7TFJWYVhUu():
	message = 'هذا الموقع تغير بالكامل ... وبحاجة الى اعادة برمجة من الصفر ... والمبرمج حاليا مشغول ويعاني من وعكة صحية ... ولهذا سوف يبقى الموقع مغلق الى ما شاء الله'
	BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'رسالة من المبرمج',message)
	return
def DP6FSBgNdX1rsvVR():
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'بحث في الموقع',hWGMqtBy4wuLaVcj,189,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'_REMEMBERRESULTS_')
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+'بوكس اوفيس موفيز لاند',Str0BupDTFA,181,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'box-office')
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+'أحدث الافلام',Str0BupDTFA,181,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'latest-movies')
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+'تليفزيون موفيز لاند',Str0BupDTFA,181,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'tv')
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+'الاكثر مشاهدة',Str0BupDTFA,181,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'top-views')
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+'أقوى الافلام الحالية',Str0BupDTFA,181,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'top-movies')
	mMQ3FkNVa4IlxqY = f1fLNcPlo2ECKtiBeug0OAvz9YM(DpQifS0oKBI1hYcO,Str0BupDTFA,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,'MOVIZLAND-MENU-1st')
	items = trdVA0JvFaD.findall('<h2><a href="(.*?)".*?">(.*?)<',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	for llxFwq0CUNgQtivJzkHeGV,title in items:
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,181)
	return mMQ3FkNVa4IlxqY
def wg5aF3e8rcDh7SGpW6M1OPnkU(url,type=hWGMqtBy4wuLaVcj):
	mMQ3FkNVa4IlxqY = f1fLNcPlo2ECKtiBeug0OAvz9YM(KqO5BWGQR9JVL,url,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,'MOVIZLAND-ITEMS-1st')
	if type=='latest-movies': cok5ZGXdQP7YhwtqyuaCnVevm6UB = trdVA0JvFaD.findall('class="titleSection">أحدث الأفلام</h1>(.*?)<h1',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)[0]
	elif type=='box-office': cok5ZGXdQP7YhwtqyuaCnVevm6UB = trdVA0JvFaD.findall('class="titleSection">بوكس اوفيس موفيز لاند</h1>(.*?)<h1',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)[0]
	elif type=='top-movies': cok5ZGXdQP7YhwtqyuaCnVevm6UB = trdVA0JvFaD.findall('btn-2-overlay(.*?)<style>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)[0]
	elif type=='top-views': cok5ZGXdQP7YhwtqyuaCnVevm6UB = trdVA0JvFaD.findall('btn-1 btn-absoly(.*?)btn-2 btn-absoly',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)[0]
	elif type=='tv': cok5ZGXdQP7YhwtqyuaCnVevm6UB = trdVA0JvFaD.findall('class="titleSection">تليفزيون موفيز لاند</h1>(.*?)class="paging"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)[0]
	else: cok5ZGXdQP7YhwtqyuaCnVevm6UB = mMQ3FkNVa4IlxqY
	if type in ['top-views','top-movies']:
		items = trdVA0JvFaD.findall('style="background-image:url\(\'(.*?)\'.*?href="(.*?)".*?href="(.*?)".*?bottom-title.*?>(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	else: items = trdVA0JvFaD.findall('height="3[0-9]+" src="(.*?)".*?bottom-title.*?href=.*?>(.*?)<.*?href="(.*?)".*?href="(.*?)"',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	REbVyXis1w4Ae = []
	XpMKS0Damzilq6xQ3j2LPGrfghYU = ['فيلم','الحلقة','الحلقه','عرض','Raw','SmackDown','اعلان','اجزاء']
	for Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,YsBnON28Tejx,pARESJKOk24UZCY5rQ8m,v1BqXOZrNQsn8Wp05VMRT in items:
		if type in ['top-views','top-movies']:
			Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,llxFwq0CUNgQtivJzkHeGV,MDSF21x9HK3AZyGUhcb,title = Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,YsBnON28Tejx,pARESJKOk24UZCY5rQ8m,v1BqXOZrNQsn8Wp05VMRT
		else: Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,title,llxFwq0CUNgQtivJzkHeGV,MDSF21x9HK3AZyGUhcb = Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,YsBnON28Tejx,pARESJKOk24UZCY5rQ8m,v1BqXOZrNQsn8Wp05VMRT
		llxFwq0CUNgQtivJzkHeGV = jkiCS0UWs2dNAJcGKn6mbHD(llxFwq0CUNgQtivJzkHeGV)
		llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV.replace('?view=true',hWGMqtBy4wuLaVcj)
		title = LNtIDdBA52P(title)
		if 'بجودة ' in title or 'بجوده ' in title:
			title = '_MOD_' + title.replace('بجودة ',hWGMqtBy4wuLaVcj).replace('بجوده ',hWGMqtBy4wuLaVcj)
		title = title.strip(Mpsm2VF1OBnCRvK3qf6)
		if 'الحلقة' in title or 'الحلقه' in title:
			IIsmGy4pd7 = trdVA0JvFaD.findall('(.*?) (الحلقة|الحلقه) \d+',title,trdVA0JvFaD.DOTALL)
			if IIsmGy4pd7:
				title = '_MOD_' + IIsmGy4pd7[0][0]
				if title not in REbVyXis1w4Ae:
					RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,183,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
					REbVyXis1w4Ae.append(title)
		elif any(BoSjXKxz41DcneO9UimClE in title for BoSjXKxz41DcneO9UimClE in XpMKS0Damzilq6xQ3j2LPGrfghYU):
			llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV + '?servers=' + MDSF21x9HK3AZyGUhcb
			RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,182,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
		else:
			llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV + '?servers=' + MDSF21x9HK3AZyGUhcb
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,183,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
	if type==hWGMqtBy4wuLaVcj:
		items = trdVA0JvFaD.findall('\n<li><a href="(.*?)".*?>(.*?)<',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,title in items:
			title = LNtIDdBA52P(title)
			title = title.replace('الصفحة ',hWGMqtBy4wuLaVcj)
			if title!=hWGMqtBy4wuLaVcj:
				RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'صفحة '+title,llxFwq0CUNgQtivJzkHeGV,181)
	return
def GrsxUhb0PEXj2FQRAkD4q(url):
	NPM3HKQ57xe = url.split('?servers=')[0]
	mMQ3FkNVa4IlxqY = f1fLNcPlo2ECKtiBeug0OAvz9YM(KqO5BWGQR9JVL,NPM3HKQ57xe,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,'MOVIZLAND-EPISODES-1st')
	cok5ZGXdQP7YhwtqyuaCnVevm6UB = trdVA0JvFaD.findall('<title>(.*?)</title>.*?height="([0-9]+)" src="(.*?)"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	title,QwGpLVOkc0MPodWfiYsTj,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG = cok5ZGXdQP7YhwtqyuaCnVevm6UB[0]
	name = trdVA0JvFaD.findall('(.*?) (الحلقة|الحلقه) [0-9]+',title,trdVA0JvFaD.DOTALL)
	if name: name = '_MOD_' + name[0][0]
	else: name = title
	items = []
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('class="episodesNumbers"(.*?)</div>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('href="(.*?)"',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV in items:
			llxFwq0CUNgQtivJzkHeGV = jkiCS0UWs2dNAJcGKn6mbHD(llxFwq0CUNgQtivJzkHeGV)
			title = trdVA0JvFaD.findall('(الحلقة|الحلقه)-([0-9]+)',llxFwq0CUNgQtivJzkHeGV.split('/')[-2],trdVA0JvFaD.DOTALL)
			if not title: title = trdVA0JvFaD.findall('()-([0-9]+)',llxFwq0CUNgQtivJzkHeGV.split('/')[-2],trdVA0JvFaD.DOTALL)
			if title: title = Mpsm2VF1OBnCRvK3qf6 + title[0][1]
			else: title = hWGMqtBy4wuLaVcj
			title = name + ' - ' + 'الحلقة' + title
			title = LNtIDdBA52P(title)
			RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,182,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
	if not items:
		title = LNtIDdBA52P(title)
		if 'بجودة ' in title or 'بجوده ' in title:
			title = '_MOD_' + title.replace('بجودة ',hWGMqtBy4wuLaVcj).replace('بجوده ',hWGMqtBy4wuLaVcj)
		RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,url,182,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
	return
def oanus6TxUFNAhSZKpJdYlEC4mV(url):
	YEaKhr8nAVQjsgycmW3qRJpwFB2iI = url.split('?servers=')
	NPM3HKQ57xe = YEaKhr8nAVQjsgycmW3qRJpwFB2iI[0]
	del YEaKhr8nAVQjsgycmW3qRJpwFB2iI[0]
	mMQ3FkNVa4IlxqY = f1fLNcPlo2ECKtiBeug0OAvz9YM(DpQifS0oKBI1hYcO,NPM3HKQ57xe,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,'MOVIZLAND-PLAY-1st')
	llxFwq0CUNgQtivJzkHeGV = trdVA0JvFaD.findall('font-size: 25px;" href="(.*?)"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)[0]
	if llxFwq0CUNgQtivJzkHeGV not in YEaKhr8nAVQjsgycmW3qRJpwFB2iI: YEaKhr8nAVQjsgycmW3qRJpwFB2iI.append(llxFwq0CUNgQtivJzkHeGV)
	Dvi8asSrQYX5wE3KMIxT91me = []
	for llxFwq0CUNgQtivJzkHeGV in YEaKhr8nAVQjsgycmW3qRJpwFB2iI:
		if '://moshahda.' in llxFwq0CUNgQtivJzkHeGV:
			II4Pievh7KUB5utH9Xgf = llxFwq0CUNgQtivJzkHeGV
			Dvi8asSrQYX5wE3KMIxT91me.append(II4Pievh7KUB5utH9Xgf+'?named=Main')
	for llxFwq0CUNgQtivJzkHeGV in YEaKhr8nAVQjsgycmW3qRJpwFB2iI:
		if '://vb.movizland.' in llxFwq0CUNgQtivJzkHeGV:
			mMQ3FkNVa4IlxqY = f1fLNcPlo2ECKtiBeug0OAvz9YM(DpQifS0oKBI1hYcO,llxFwq0CUNgQtivJzkHeGV,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,'MOVIZLAND-PLAY-2nd')
			mMQ3FkNVa4IlxqY = mMQ3FkNVa4IlxqY.decode('windows-1256').encode(a7VXeDU82IfQEnPZAdiT)
			mMQ3FkNVa4IlxqY = mMQ3FkNVa4IlxqY.replace('src="http://up.movizland.com/uploads/13721411411.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"')
			mMQ3FkNVa4IlxqY = mMQ3FkNVa4IlxqY.replace('src="http://up.movizland.online/uploads/13721411411.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"')
			mMQ3FkNVa4IlxqY = mMQ3FkNVa4IlxqY.replace('</a></div><br /><div align="center">','src="/uploads/13721411411.png"')
			mMQ3FkNVa4IlxqY = mMQ3FkNVa4IlxqY.replace('class="tborder" align="center"','src="/uploads/13721411411.png"')
			DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('(src="/uploads/13721411411.png".*?href="http://moshahda\..*?/\w+.html".*?src="/uploads/13721411411.png")',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
			if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
				H7wAinr4f3M8oPDFsdkIZ,bQV1Gtm49uZJshH3nWXLPTYrME = [],[]
				if len(DJvksH7ZAFUqW9OyQnbGjPCtwR1o)==1:
					title = hWGMqtBy4wuLaVcj
					cok5ZGXdQP7YhwtqyuaCnVevm6UB = mMQ3FkNVa4IlxqY
				else:
					for cok5ZGXdQP7YhwtqyuaCnVevm6UB in DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
						TfCqlZthRYgzkbE0GO = trdVA0JvFaD.findall('src="/uploads/13721411411.png".*?http://up.movizland.(online|com)/uploads/.*?\*\*\*\*\*\*\*+(.*?src="/uploads/13721411411.png")',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
						if TfCqlZthRYgzkbE0GO: cok5ZGXdQP7YhwtqyuaCnVevm6UB = 'src="/uploads/13721411411.png"  \n  ' + TfCqlZthRYgzkbE0GO[0][1]
						TfCqlZthRYgzkbE0GO = trdVA0JvFaD.findall('src="/uploads/13721411411.png".*?<hr size="1" style="color:'+'#'+'333; background-color:'+'#'+'333" />(.*?href="http://moshahda\..*?/\w+.html".*?src="/uploads/13721411411.png")',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
						if TfCqlZthRYgzkbE0GO: cok5ZGXdQP7YhwtqyuaCnVevm6UB = 'src="/uploads/13721411411.png"  \n  ' + TfCqlZthRYgzkbE0GO[0]
						TfCqlZthRYgzkbE0GO = trdVA0JvFaD.findall('(src="/uploads/13721411411.png".*?href="http://moshahda\..*?/\w+.html".*?)<hr size="1" style="color:'+'#'+'333; background-color:'+'#'+'333" />.*?src="/uploads/13721411411.png"',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
						if TfCqlZthRYgzkbE0GO: cok5ZGXdQP7YhwtqyuaCnVevm6UB = TfCqlZthRYgzkbE0GO[0] + '  \n  src="/uploads/13721411411.png"'
						kHZNKGml59BerbgPXC8IOTjE4s = trdVA0JvFaD.findall('<(.*?)http://up.movizland.(online|com)/uploads/',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
						title = trdVA0JvFaD.findall('> *([^<>]+) *<',kHZNKGml59BerbgPXC8IOTjE4s[0][0],trdVA0JvFaD.DOTALL)
						title = Mpsm2VF1OBnCRvK3qf6.join(title)
						title = title.strip(Mpsm2VF1OBnCRvK3qf6)
						title = title.replace(FqcVAkh7WjIXHdDKf8nvuyRo,Mpsm2VF1OBnCRvK3qf6).replace(FqcVAkh7WjIXHdDKf8nvuyRo,Mpsm2VF1OBnCRvK3qf6).replace(FqcVAkh7WjIXHdDKf8nvuyRo,Mpsm2VF1OBnCRvK3qf6).replace(FqcVAkh7WjIXHdDKf8nvuyRo,Mpsm2VF1OBnCRvK3qf6).replace(FqcVAkh7WjIXHdDKf8nvuyRo,Mpsm2VF1OBnCRvK3qf6)
						H7wAinr4f3M8oPDFsdkIZ.append(title)
					OODLkJlZCoKmrzbg2XQSGPUdInA = Eb7qJoNwOgn('أختر الفيديو المطلوب:', H7wAinr4f3M8oPDFsdkIZ)
					if OODLkJlZCoKmrzbg2XQSGPUdInA == -1 : return
					title = H7wAinr4f3M8oPDFsdkIZ[OODLkJlZCoKmrzbg2XQSGPUdInA]
					cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[OODLkJlZCoKmrzbg2XQSGPUdInA]
				llxFwq0CUNgQtivJzkHeGV = trdVA0JvFaD.findall('href="(http://moshahda\..*?/\w+.html)"',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
				zBS7i5YsgGRlPZn2urpmN6 = llxFwq0CUNgQtivJzkHeGV[0]
				Dvi8asSrQYX5wE3KMIxT91me.append(zBS7i5YsgGRlPZn2urpmN6+'?named=Forum')
				cok5ZGXdQP7YhwtqyuaCnVevm6UB = cok5ZGXdQP7YhwtqyuaCnVevm6UB.replace('ـ',hWGMqtBy4wuLaVcj)
				cok5ZGXdQP7YhwtqyuaCnVevm6UB = cok5ZGXdQP7YhwtqyuaCnVevm6UB.replace('src="http://up.movizland.online/uploads/1517412175296.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="both"  \n  ')
				cok5ZGXdQP7YhwtqyuaCnVevm6UB = cok5ZGXdQP7YhwtqyuaCnVevm6UB.replace('src="http://up.movizland.com/uploads/1517412175296.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="both"  \n  ')
				cok5ZGXdQP7YhwtqyuaCnVevm6UB = cok5ZGXdQP7YhwtqyuaCnVevm6UB.replace('سيرفرات التحميل','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="download"  \n  ')
				cok5ZGXdQP7YhwtqyuaCnVevm6UB = cok5ZGXdQP7YhwtqyuaCnVevm6UB.replace('روابط التحميل','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="download"  \n  ')
				cok5ZGXdQP7YhwtqyuaCnVevm6UB = cok5ZGXdQP7YhwtqyuaCnVevm6UB.replace('سيرفرات المشاهد','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="watch"  \n  ')
				cok5ZGXdQP7YhwtqyuaCnVevm6UB = cok5ZGXdQP7YhwtqyuaCnVevm6UB.replace('روابط المشاهد','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="watch"  \n  ')
				ijY8uvfq3krx = trdVA0JvFaD.findall('(src="/uploads/13721411411.png".*?href="http://e5tsar.com/\d+".*?src="/uploads/13721411411.png")',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
				for adgDkA7BqZ2wpWFR63SPV0Y in ijY8uvfq3krx:
					type = trdVA0JvFaD.findall(' typetype="(.*?)" ',adgDkA7BqZ2wpWFR63SPV0Y)
					if type:
						if type[0]!='both': type = '__'+type[0]
						else: type = hWGMqtBy4wuLaVcj
					items = trdVA0JvFaD.findall('(?<!http://e5tsar.com/)(\w+[ \w]*</font>.*?|\w+[ \w]*<br />.*?)href="(http://e5tsar.com/.*?)"',adgDkA7BqZ2wpWFR63SPV0Y,trdVA0JvFaD.DOTALL)
					for quSN8AWX6oed,llxFwq0CUNgQtivJzkHeGV in items:
						title = trdVA0JvFaD.findall('(\w+[ \w]*)<',quSN8AWX6oed)
						title = title[-1]
						llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV + '?named=' + title + type
						Dvi8asSrQYX5wE3KMIxT91me.append(llxFwq0CUNgQtivJzkHeGV)
	CMzQFXeI08KDwAJ9p = NPM3HKQ57xe.replace(Str0BupDTFA,Mr9c3QFRbp4wm)
	mMQ3FkNVa4IlxqY = f1fLNcPlo2ECKtiBeug0OAvz9YM(DpQifS0oKBI1hYcO,CMzQFXeI08KDwAJ9p,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,'MOVIZLAND-PLAY-3rd')
	items = trdVA0JvFaD.findall('" href="(.*?)"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if items:
		xfnsOE10BX5mugRGJaijQDo = items[-1]
		Dvi8asSrQYX5wE3KMIxT91me.append(xfnsOE10BX5mugRGJaijQDo+'?named=Mobile')
	import oosSOfvdEQ
	oosSOfvdEQ.zfdYjsGLg8M6i15qZWh(Dvi8asSrQYX5wE3KMIxT91me,xjPuFK3EsIZSiobQ5X,'video',url)
	return
def lPwaAjFTMG4n7iSLkXcEuK0Zm(search):
	search,vvKf4sXgZIMyEJPuC,showDialogs = IVTEJQOiMR2dYta9C(search)
	if search==hWGMqtBy4wuLaVcj: search = TrzfUidpv1LyAYqwexHJDuS()
	if search==hWGMqtBy4wuLaVcj: return
	search = search.replace(Mpsm2VF1OBnCRvK3qf6,'+')
	mMQ3FkNVa4IlxqY = f1fLNcPlo2ECKtiBeug0OAvz9YM(KqO5BWGQR9JVL,Str0BupDTFA,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,'MOVIZLAND-SEARCH-1st')
	items = trdVA0JvFaD.findall('<option value="(.*?)">(.*?)</option>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	yhu8T5tC4jfriWUY = [ hWGMqtBy4wuLaVcj ]
	vvp23xUZnEfN0VC4mzad9bhSRr = [ 'الكل وبدون فلتر' ]
	for OJx4sYA9nNbtPT5ezmDHdVBk2C7,title in items:
		yhu8T5tC4jfriWUY.append(OJx4sYA9nNbtPT5ezmDHdVBk2C7)
		vvp23xUZnEfN0VC4mzad9bhSRr.append(title)
	if OJx4sYA9nNbtPT5ezmDHdVBk2C7:
		OODLkJlZCoKmrzbg2XQSGPUdInA = Eb7qJoNwOgn('اختر الفلتر المناسب:', vvp23xUZnEfN0VC4mzad9bhSRr)
		if OODLkJlZCoKmrzbg2XQSGPUdInA == -1 : return
		OJx4sYA9nNbtPT5ezmDHdVBk2C7 = yhu8T5tC4jfriWUY[OODLkJlZCoKmrzbg2XQSGPUdInA]
	else: OJx4sYA9nNbtPT5ezmDHdVBk2C7 = hWGMqtBy4wuLaVcj
	url = Str0BupDTFA + '/?s='+search+'&mcat='+OJx4sYA9nNbtPT5ezmDHdVBk2C7
	wg5aF3e8rcDh7SGpW6M1OPnkU(url)
	return
# -*- coding: utf-8 -*-
from yoY3NdGViS import *
xjPuFK3EsIZSiobQ5X = 'YOUTUBE'
n0qFKQWhiBYXoTrvejVHUA4 = '_YUT_'
Str0BupDTFA = u6rbxnyjTl7I[xjPuFK3EsIZSiobQ5X][0]
K9qeioHZ7bIC = 0
def ehB18u9sQFRi(mode,url,text,type,l7COkhRWD9uVS60Pte2NoyAaZn,name,nWE8aO53lFfD):
	if	 mode==140: N6NCYivtV4I5rEXq = DP6FSBgNdX1rsvVR()
	elif mode==141: N6NCYivtV4I5rEXq = ccnEjdlgp8qRuFZ(url,name,nWE8aO53lFfD)
	elif mode==143: N6NCYivtV4I5rEXq = oanus6TxUFNAhSZKpJdYlEC4mV(url,type)
	elif mode==144: N6NCYivtV4I5rEXq = wg5aF3e8rcDh7SGpW6M1OPnkU(url,l7COkhRWD9uVS60Pte2NoyAaZn,text)
	elif mode==145: N6NCYivtV4I5rEXq = ttouNCaeMwE8ny0qGUmxc1ADsvQLBY(url,l7COkhRWD9uVS60Pte2NoyAaZn)
	elif mode==147: N6NCYivtV4I5rEXq = N6uyQkt1lUOxBJEXY3hj()
	elif mode==148: N6NCYivtV4I5rEXq = rcBxmg6teybRXDIZ()
	elif mode==149: N6NCYivtV4I5rEXq = lPwaAjFTMG4n7iSLkXcEuK0Zm(text)
	else: N6NCYivtV4I5rEXq = False
	return N6NCYivtV4I5rEXq
def DP6FSBgNdX1rsvVR():
	if 0:
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'قائمة 1',Str0BupDTFA+'/playlist?list=PLDJPKWWTSFaaGNjpDcPUsWZJVePmAYk_E&pp=iAQB',144)
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'قائمة 2',Str0BupDTFA+'/playlist?list=PLAj5Gs8FH8ZnUbF0RV-7G3BoqIyZA4uSA',144)
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'شخص',Str0BupDTFA+'/user/TCNofficial',144)
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'موقع',Str0BupDTFA+'/channel/UCq59aGNsq9bbhwVTq1Utvgw',144)
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'حساب',Str0BupDTFA+'/@TheSocialCTV',144)
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'العاب',Str0BupDTFA+'/gaming',144)
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'افلام',Str0BupDTFA+'/feed/storefront',144)
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'مختارات',Str0BupDTFA+'/feed/guide_builder',144)
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'قصيرة',Str0BupDTFA+'/shorts',144,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'_REMEMBERRESULTS_')
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'تصفح',Str0BupDTFA+'/youtubei/v1/guide?key=',144)
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'رئيسية',Str0BupDTFA+hWGMqtBy4wuLaVcj,144)
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'رائج',Str0BupDTFA+'/feed/trending?bp=',144)
		RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'بحث في الموقع',hWGMqtBy4wuLaVcj,149,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'_REMEMBERRESULTS_')
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'الرائجة',Str0BupDTFA+'/feed/trending',144)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'التصفح',Str0BupDTFA+'/youtubei/v1/guide?key=',144)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'القصيرة',Str0BupDTFA+'/shorts',144,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'_REMEMBERRESULTS_')
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'مختارات يوتيوب',Str0BupDTFA+'/feed/guide_builder',144)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'مختارات البرنامج',hWGMqtBy4wuLaVcj,290)
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'بحث: قنوات عربية',hWGMqtBy4wuLaVcj,147)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'بحث: قنوات أجنبية',hWGMqtBy4wuLaVcj,148)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'بحث: افلام عربية',Str0BupDTFA+'/results?search_query=فيلم',144)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'بحث: افلام اجنبية',Str0BupDTFA+'/results?search_query=movie',144)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'بحث: مسرحيات عربية',Str0BupDTFA+'/results?search_query=مسرحية',144)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'بحث: مسلسلات عربية',Str0BupDTFA+'/results?search_query=مسلسل&sp=EgIQAw==',144)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'بحث: مسلسلات اجنبية',Str0BupDTFA+'/results?search_query=series&sp=EgIQAw==',144)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'بحث: مسلسلات كارتون',Str0BupDTFA+'/results?search_query=كارتون&sp=EgIQAw==',144)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'بحث: خطبة المرجعية',Str0BupDTFA+'/results?search_query=قناة+كربلاء+الفضائية+خطبة+الجمعة&sp=CAISAhAB',144)
	return
def ccnEjdlgp8qRuFZ(url,name,nWE8aO53lFfD):
	name = RqfZ4ma8Jjh9EU(name)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'CHNL:  '+name,url,144,nWE8aO53lFfD)
	return
def N6uyQkt1lUOxBJEXY3hj():
	wg5aF3e8rcDh7SGpW6M1OPnkU(Str0BupDTFA+'/results?search_query=قناة+بث&sp=EgJAAQ==')
	return
def rcBxmg6teybRXDIZ():
	wg5aF3e8rcDh7SGpW6M1OPnkU(Str0BupDTFA+'/results?search_query=tv&sp=EgJAAQ==')
	return
def oanus6TxUFNAhSZKpJdYlEC4mV(url,type):
	url = url.split('&',1)[0]
	import oosSOfvdEQ
	oosSOfvdEQ.zfdYjsGLg8M6i15qZWh([url],xjPuFK3EsIZSiobQ5X,type,url)
	return
def X9fzZpaeq8W6ErI4bOU51T(FAJ4XhNPL5H0wdWifIKOjrB,url,C9VNOL3UmyXPYbGrJ8):
	level,QQCYzVD0lsT1Xabk,iWsEc1mM05vjLyCoNDl8rpUSb9XQ,AA6qOa5dh4fKNvsSuMo0P = C9VNOL3UmyXPYbGrJ8.split('::')
	EE2UbrpiWx5gaNjSfVY0DZTweMG4Av,wrBYANnkH58J2loGCMQza9tFUTuW = [],[]
	if '/youtubei/v1/browse' in url: EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yccc['onResponseReceivedActions']")
	if '/youtubei/v1/search' in url: EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yccc['onResponseReceivedCommands']")
	EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs'][0]['tabRenderer']['content']['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['playlistVideoListRenderer']['contents']")
	if level=='1': EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs'][0]['tabRenderer']['content']['richGridRenderer']['header']['feedFilterChipBarRenderer']['contents']")
	EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yccc['contents']['twoColumnWatchNextResults']['playlist']['playlist']['contents']")
	EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yccc['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['contents']")
	EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs']")
	EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yccc['entries']")
	EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yccc['items'][3]['guideSectionRenderer']['items']")
	xIwXcT20KUed6hsMzD,OpH5bkRNGm1eJSLPhx,VXgaM8ioEDR9 = XkelnmQwbOaY8RsPIFot(FAJ4XhNPL5H0wdWifIKOjrB,hWGMqtBy4wuLaVcj,EE2UbrpiWx5gaNjSfVY0DZTweMG4Av)
	if level=='1' and xIwXcT20KUed6hsMzD:
		if len(OpH5bkRNGm1eJSLPhx)>1 and 'search_query' not in url:
			for E2t6X7TH0ykep58Kq1vF3 in range(len(OpH5bkRNGm1eJSLPhx)):
				QQCYzVD0lsT1Xabk = str(E2t6X7TH0ykep58Kq1vF3)
				EE2UbrpiWx5gaNjSfVY0DZTweMG4Av = []
				EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yddd["+QQCYzVD0lsT1Xabk+"]['reloadContinuationItemsCommand']['continuationItems']")
				EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yddd["+QQCYzVD0lsT1Xabk+"]['command']")
				EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yddd["+QQCYzVD0lsT1Xabk+"]")
				G62uf8ZSIzBE,ImYg2jxU6Lc9Q1C4Oko,coDr4CpZ9UyQn8txJuA315eN0OjH = XkelnmQwbOaY8RsPIFot(OpH5bkRNGm1eJSLPhx,hWGMqtBy4wuLaVcj,EE2UbrpiWx5gaNjSfVY0DZTweMG4Av)
				if G62uf8ZSIzBE: wrBYANnkH58J2loGCMQza9tFUTuW.append([ImYg2jxU6Lc9Q1C4Oko,url,'2::'+QQCYzVD0lsT1Xabk+'::0::0'])
			EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yccc['continuationEndpoint']")
			G62uf8ZSIzBE,ImYg2jxU6Lc9Q1C4Oko,coDr4CpZ9UyQn8txJuA315eN0OjH = XkelnmQwbOaY8RsPIFot(FAJ4XhNPL5H0wdWifIKOjrB,hWGMqtBy4wuLaVcj,EE2UbrpiWx5gaNjSfVY0DZTweMG4Av)
			if G62uf8ZSIzBE and wrBYANnkH58J2loGCMQza9tFUTuW and 'continuationCommand' in list(ImYg2jxU6Lc9Q1C4Oko.keys()):
				llxFwq0CUNgQtivJzkHeGV = Str0BupDTFA+'/my_main_page_shorts_link'
				wrBYANnkH58J2loGCMQza9tFUTuW.append([ImYg2jxU6Lc9Q1C4Oko,llxFwq0CUNgQtivJzkHeGV,'1::0::0::0'])
	return OpH5bkRNGm1eJSLPhx,xIwXcT20KUed6hsMzD,wrBYANnkH58J2loGCMQza9tFUTuW,VXgaM8ioEDR9
def TYl6zxDsLV(FAJ4XhNPL5H0wdWifIKOjrB,OpH5bkRNGm1eJSLPhx,url,C9VNOL3UmyXPYbGrJ8):
	level,QQCYzVD0lsT1Xabk,iWsEc1mM05vjLyCoNDl8rpUSb9XQ,AA6qOa5dh4fKNvsSuMo0P = C9VNOL3UmyXPYbGrJ8.split('::')
	EE2UbrpiWx5gaNjSfVY0DZTweMG4Av,tK6C3grifaJnbk8jvuG = [],[]
	EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yddd[0]['itemSectionRenderer']['contents']")
	EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yddd["+QQCYzVD0lsT1Xabk+"]['reloadContinuationItemsCommand']['continuationItems']")
	EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yddd[1]['reloadContinuationItemsCommand']['continuationItems']")
	if '/youtubei/v1/browse' in url: EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yddd[0]['appendContinuationItemsAction']['continuationItems']")
	elif '/youtubei/v1/search' in url: EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yddd[0]['appendContinuationItemsAction']['continuationItems'][0]['itemSectionRenderer']['contents']")
	EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yddd["+QQCYzVD0lsT1Xabk+"]['tabRenderer']['content']['sectionListRenderer']['contents']")
	if '/videos' in url or ('/shorts' in url and '/shorts/' not in url):
		EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yddd["+QQCYzVD0lsT1Xabk+"]['tabRenderer']['content']['richGridRenderer']['header']['feedFilterChipBarRenderer']['contents']")
	EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yddd["+QQCYzVD0lsT1Xabk+"]['tabRenderer']['content']['richGridRenderer']['contents']")
	EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yddd["+QQCYzVD0lsT1Xabk+"]['expandableTabRenderer']['content']['sectionListRenderer']['contents']")
	EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yddd["+QQCYzVD0lsT1Xabk+"]['richSectionRenderer']['content']['richShelfRenderer']['contents']")
	EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yddd["+QQCYzVD0lsT1Xabk+"]")
	VjNGirytRH,sPNXWmEYaCI3i0wo7eh5FSkx,fA9NXKsMe3qthR2WZE = XkelnmQwbOaY8RsPIFot(OpH5bkRNGm1eJSLPhx,hWGMqtBy4wuLaVcj,EE2UbrpiWx5gaNjSfVY0DZTweMG4Av)
	if level=='2' and VjNGirytRH:
		if len(sPNXWmEYaCI3i0wo7eh5FSkx)>1:
			for E2t6X7TH0ykep58Kq1vF3 in range(len(sPNXWmEYaCI3i0wo7eh5FSkx)):
				iWsEc1mM05vjLyCoNDl8rpUSb9XQ = str(E2t6X7TH0ykep58Kq1vF3)
				EE2UbrpiWx5gaNjSfVY0DZTweMG4Av = []
				EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yeee["+iWsEc1mM05vjLyCoNDl8rpUSb9XQ+"]['richSectionRenderer']['content']")
				EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yeee["+iWsEc1mM05vjLyCoNDl8rpUSb9XQ+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['header']")
				EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yeee["+iWsEc1mM05vjLyCoNDl8rpUSb9XQ+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
				EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yeee["+iWsEc1mM05vjLyCoNDl8rpUSb9XQ+"]['itemSectionRenderer']['contents'][0]")
				EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yeee["+iWsEc1mM05vjLyCoNDl8rpUSb9XQ+"]['richItemRenderer']['content']")
				EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yeee["+iWsEc1mM05vjLyCoNDl8rpUSb9XQ+"]")
				G62uf8ZSIzBE,ImYg2jxU6Lc9Q1C4Oko,coDr4CpZ9UyQn8txJuA315eN0OjH = XkelnmQwbOaY8RsPIFot(sPNXWmEYaCI3i0wo7eh5FSkx,hWGMqtBy4wuLaVcj,EE2UbrpiWx5gaNjSfVY0DZTweMG4Av)
				if G62uf8ZSIzBE: tK6C3grifaJnbk8jvuG.append([ImYg2jxU6Lc9Q1C4Oko,url,'3::'+QQCYzVD0lsT1Xabk+'::'+iWsEc1mM05vjLyCoNDl8rpUSb9XQ+'::0'])
			EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yddd[0]['appendContinuationItemsAction']['continuationItems'][1]")
			EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yddd[1]")
			G62uf8ZSIzBE,ImYg2jxU6Lc9Q1C4Oko,coDr4CpZ9UyQn8txJuA315eN0OjH = XkelnmQwbOaY8RsPIFot(OpH5bkRNGm1eJSLPhx,hWGMqtBy4wuLaVcj,EE2UbrpiWx5gaNjSfVY0DZTweMG4Av)
			if G62uf8ZSIzBE and tK6C3grifaJnbk8jvuG and 'continuationItemRenderer' in list(ImYg2jxU6Lc9Q1C4Oko.keys()):
				tK6C3grifaJnbk8jvuG.append([ImYg2jxU6Lc9Q1C4Oko,url,'3::0::0::0'])
	return sPNXWmEYaCI3i0wo7eh5FSkx,VjNGirytRH,tK6C3grifaJnbk8jvuG,fA9NXKsMe3qthR2WZE
def nX23Cb7QeFoNEDWa(FAJ4XhNPL5H0wdWifIKOjrB,sPNXWmEYaCI3i0wo7eh5FSkx,url,C9VNOL3UmyXPYbGrJ8):
	level,QQCYzVD0lsT1Xabk,iWsEc1mM05vjLyCoNDl8rpUSb9XQ,AA6qOa5dh4fKNvsSuMo0P = C9VNOL3UmyXPYbGrJ8.split('::')
	EE2UbrpiWx5gaNjSfVY0DZTweMG4Av,b4GLzdKAcu9yUC8wRjYWlHT0 = [],[]
	EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yeee["+iWsEc1mM05vjLyCoNDl8rpUSb9XQ+"]['shelfRenderer']['content']['verticalListRenderer']['items']")
	EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yeee["+iWsEc1mM05vjLyCoNDl8rpUSb9XQ+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalMovieListRenderer']['items']")
	EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yeee["+iWsEc1mM05vjLyCoNDl8rpUSb9XQ+"]['itemSectionRenderer']['contents'][0]['reelShelfRenderer']['items']")
	EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yeee["+iWsEc1mM05vjLyCoNDl8rpUSb9XQ+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yeee["+iWsEc1mM05vjLyCoNDl8rpUSb9XQ+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalListRenderer']['items']")
	EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yeee["+iWsEc1mM05vjLyCoNDl8rpUSb9XQ+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['expandedShelfContentsRenderer']['items']")
	EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yeee["+iWsEc1mM05vjLyCoNDl8rpUSb9XQ+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
	EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yeee["+iWsEc1mM05vjLyCoNDl8rpUSb9XQ+"]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yeee[0]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yeee[0]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yeee[0]['itemSectionRenderer']['contents'][0]['playlistVideoListRenderer']['contents']")
	EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yeee["+iWsEc1mM05vjLyCoNDl8rpUSb9XQ+"]['reelShelfRenderer']['items']")
	EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yeee["+iWsEc1mM05vjLyCoNDl8rpUSb9XQ+"]['richSectionRenderer']['content']['richShelfRenderer']['contents']")
	EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yeee")
	keKfOW9w72631v8Nq,GtJNdMl6bLjRKWe04,MxudeDVimfnyEaNw = XkelnmQwbOaY8RsPIFot(sPNXWmEYaCI3i0wo7eh5FSkx,hWGMqtBy4wuLaVcj,EE2UbrpiWx5gaNjSfVY0DZTweMG4Av)
	if level=='3' and keKfOW9w72631v8Nq:
		if len(GtJNdMl6bLjRKWe04)>0:
			for E2t6X7TH0ykep58Kq1vF3 in range(len(GtJNdMl6bLjRKWe04)):
				AA6qOa5dh4fKNvsSuMo0P = str(E2t6X7TH0ykep58Kq1vF3)
				EE2UbrpiWx5gaNjSfVY0DZTweMG4Av = []
				EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yfff["+AA6qOa5dh4fKNvsSuMo0P+"]['richItemRenderer']['content']")
				EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yfff["+AA6qOa5dh4fKNvsSuMo0P+"]['gameCardRenderer']['game']")
				EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yfff["+AA6qOa5dh4fKNvsSuMo0P+"]['itemSectionRenderer']['contents'][0]")
				EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yfff["+AA6qOa5dh4fKNvsSuMo0P+"]")
				EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yfff")
				G62uf8ZSIzBE,ImYg2jxU6Lc9Q1C4Oko,coDr4CpZ9UyQn8txJuA315eN0OjH = XkelnmQwbOaY8RsPIFot(GtJNdMl6bLjRKWe04,hWGMqtBy4wuLaVcj,EE2UbrpiWx5gaNjSfVY0DZTweMG4Av)
				if G62uf8ZSIzBE: b4GLzdKAcu9yUC8wRjYWlHT0.append([ImYg2jxU6Lc9Q1C4Oko,url,'4::'+QQCYzVD0lsT1Xabk+'::'+iWsEc1mM05vjLyCoNDl8rpUSb9XQ+'::'+AA6qOa5dh4fKNvsSuMo0P])
	return GtJNdMl6bLjRKWe04,keKfOW9w72631v8Nq,b4GLzdKAcu9yUC8wRjYWlHT0,MxudeDVimfnyEaNw
def XkelnmQwbOaY8RsPIFot(YsBnON28Tejx,pARESJKOk24UZCY5rQ8m,asgIdvKZLE):
	FAJ4XhNPL5H0wdWifIKOjrB,pARESJKOk24UZCY5rQ8m = YsBnON28Tejx,pARESJKOk24UZCY5rQ8m
	OpH5bkRNGm1eJSLPhx,pARESJKOk24UZCY5rQ8m = YsBnON28Tejx,pARESJKOk24UZCY5rQ8m
	sPNXWmEYaCI3i0wo7eh5FSkx,pARESJKOk24UZCY5rQ8m = YsBnON28Tejx,pARESJKOk24UZCY5rQ8m
	GtJNdMl6bLjRKWe04,pARESJKOk24UZCY5rQ8m = YsBnON28Tejx,pARESJKOk24UZCY5rQ8m
	ImYg2jxU6Lc9Q1C4Oko,kv2qB5RfKtblO184WS9m = YsBnON28Tejx,pARESJKOk24UZCY5rQ8m
	count = len(asgIdvKZLE)
	for JpzD0lv9cYM6XrHeqCa in range(count):
		try:
			Kawy3nsv94QA7Xim6SRu = eval(asgIdvKZLE[JpzD0lv9cYM6XrHeqCa])
			return True,Kawy3nsv94QA7Xim6SRu,JpzD0lv9cYM6XrHeqCa+1
		except: pass
	return False,hWGMqtBy4wuLaVcj,0
def wg5aF3e8rcDh7SGpW6M1OPnkU(url,C9VNOL3UmyXPYbGrJ8=hWGMqtBy4wuLaVcj,data=hWGMqtBy4wuLaVcj):
	wrBYANnkH58J2loGCMQza9tFUTuW,tK6C3grifaJnbk8jvuG,b4GLzdKAcu9yUC8wRjYWlHT0 = [],[],[]
	if '::' not in C9VNOL3UmyXPYbGrJ8: C9VNOL3UmyXPYbGrJ8 = '1::0::0::0'
	level,QQCYzVD0lsT1Xabk,iWsEc1mM05vjLyCoNDl8rpUSb9XQ,AA6qOa5dh4fKNvsSuMo0P = C9VNOL3UmyXPYbGrJ8.split('::')
	if level=='4': level,QQCYzVD0lsT1Xabk,iWsEc1mM05vjLyCoNDl8rpUSb9XQ,AA6qOa5dh4fKNvsSuMo0P = '1',QQCYzVD0lsT1Xabk,iWsEc1mM05vjLyCoNDl8rpUSb9XQ,AA6qOa5dh4fKNvsSuMo0P
	data = data.replace('_REMEMBERRESULTS_',hWGMqtBy4wuLaVcj)
	mMQ3FkNVa4IlxqY,FAJ4XhNPL5H0wdWifIKOjrB,OucJVrWRKSqDChiG7yn3oz0dafZF = UUQuB9XmZA0(url,data)
	C9VNOL3UmyXPYbGrJ8 = level+'::'+QQCYzVD0lsT1Xabk+'::'+iWsEc1mM05vjLyCoNDl8rpUSb9XQ+'::'+AA6qOa5dh4fKNvsSuMo0P
	if level in ['1','2','3']:
		OpH5bkRNGm1eJSLPhx,xIwXcT20KUed6hsMzD,wrBYANnkH58J2loGCMQza9tFUTuW,VXgaM8ioEDR9 = X9fzZpaeq8W6ErI4bOU51T(FAJ4XhNPL5H0wdWifIKOjrB,url,C9VNOL3UmyXPYbGrJ8)
		if not xIwXcT20KUed6hsMzD: return
		hz3gGBqsDAo58uWi9VH7O2y4 = len(wrBYANnkH58J2loGCMQza9tFUTuW)
		if hz3gGBqsDAo58uWi9VH7O2y4<2:
			if level=='1': level = '2'
			wrBYANnkH58J2loGCMQza9tFUTuW = []
	C9VNOL3UmyXPYbGrJ8 = level+'::'+QQCYzVD0lsT1Xabk+'::'+iWsEc1mM05vjLyCoNDl8rpUSb9XQ+'::'+AA6qOa5dh4fKNvsSuMo0P
	if level in ['2','3']:
		sPNXWmEYaCI3i0wo7eh5FSkx,VjNGirytRH,tK6C3grifaJnbk8jvuG,fA9NXKsMe3qthR2WZE = TYl6zxDsLV(FAJ4XhNPL5H0wdWifIKOjrB,OpH5bkRNGm1eJSLPhx,url,C9VNOL3UmyXPYbGrJ8)
		if not VjNGirytRH: return
		jnx3kCh92oIrMbuWzGqtYHpDiaX = len(tK6C3grifaJnbk8jvuG)
		if jnx3kCh92oIrMbuWzGqtYHpDiaX<2:
			if level=='2': level = '3'
			tK6C3grifaJnbk8jvuG = []
	C9VNOL3UmyXPYbGrJ8 = level+'::'+QQCYzVD0lsT1Xabk+'::'+iWsEc1mM05vjLyCoNDl8rpUSb9XQ+'::'+AA6qOa5dh4fKNvsSuMo0P
	if level in ['3']:
		GtJNdMl6bLjRKWe04,keKfOW9w72631v8Nq,b4GLzdKAcu9yUC8wRjYWlHT0,MxudeDVimfnyEaNw = nX23Cb7QeFoNEDWa(FAJ4XhNPL5H0wdWifIKOjrB,sPNXWmEYaCI3i0wo7eh5FSkx,url,C9VNOL3UmyXPYbGrJ8)
		if not keKfOW9w72631v8Nq: return
		L46sTlWwMydR2nSVaDqQt = len(b4GLzdKAcu9yUC8wRjYWlHT0)
	for ImYg2jxU6Lc9Q1C4Oko,url,C9VNOL3UmyXPYbGrJ8 in wrBYANnkH58J2loGCMQza9tFUTuW+tK6C3grifaJnbk8jvuG+b4GLzdKAcu9yUC8wRjYWlHT0:
		OYxIojkiHrw1tzhlpg5 = aDTRfdX3kAYsByC8x(ImYg2jxU6Lc9Q1C4Oko,url,C9VNOL3UmyXPYbGrJ8)
	return
def aDTRfdX3kAYsByC8x(ImYg2jxU6Lc9Q1C4Oko,url=hWGMqtBy4wuLaVcj,C9VNOL3UmyXPYbGrJ8=hWGMqtBy4wuLaVcj):
	if '::' in C9VNOL3UmyXPYbGrJ8: level,QQCYzVD0lsT1Xabk,iWsEc1mM05vjLyCoNDl8rpUSb9XQ,AA6qOa5dh4fKNvsSuMo0P = C9VNOL3UmyXPYbGrJ8.split('::')
	else: level,QQCYzVD0lsT1Xabk,iWsEc1mM05vjLyCoNDl8rpUSb9XQ,AA6qOa5dh4fKNvsSuMo0P = '1','0','0','0'
	G62uf8ZSIzBE,title,llxFwq0CUNgQtivJzkHeGV,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,count,oJV18NUZAzPGqMu7tenCxrkfhdl69B,AIlKnEy3iwRfzeF5rkUbhgp,qqmnN2fDj3LSEZU5IgA,nb7UNYGvByVfWPOlMESmIQJ8t26TA = II8WCQAeRgj(ImYg2jxU6Lc9Q1C4Oko)
	yKzGr3CeHAFtRwgOEkjPvmJBoYhc8 = '/videos?' in llxFwq0CUNgQtivJzkHeGV or '/streams?' in llxFwq0CUNgQtivJzkHeGV or '/playlists?' in llxFwq0CUNgQtivJzkHeGV
	gm7AuXQ3dy1oF = '/channels?' in llxFwq0CUNgQtivJzkHeGV or '/shorts?' in llxFwq0CUNgQtivJzkHeGV
	if yKzGr3CeHAFtRwgOEkjPvmJBoYhc8 or gm7AuXQ3dy1oF: llxFwq0CUNgQtivJzkHeGV = url
	yKzGr3CeHAFtRwgOEkjPvmJBoYhc8 = 'watch?v=' not in llxFwq0CUNgQtivJzkHeGV and '/playlist?list=' not in llxFwq0CUNgQtivJzkHeGV
	gm7AuXQ3dy1oF = '/gaming' not in llxFwq0CUNgQtivJzkHeGV  and '/feed/storefront' not in llxFwq0CUNgQtivJzkHeGV
	if C9VNOL3UmyXPYbGrJ8[0:5]=='3::0::' and yKzGr3CeHAFtRwgOEkjPvmJBoYhc8 and gm7AuXQ3dy1oF: llxFwq0CUNgQtivJzkHeGV = url
	if '/youtubei/v1/guide?key=' in url or '/gaming' in llxFwq0CUNgQtivJzkHeGV:
		level,QQCYzVD0lsT1Xabk,iWsEc1mM05vjLyCoNDl8rpUSb9XQ,AA6qOa5dh4fKNvsSuMo0P = '1','0','0','0'
		C9VNOL3UmyXPYbGrJ8 = hWGMqtBy4wuLaVcj
	OucJVrWRKSqDChiG7yn3oz0dafZF = hWGMqtBy4wuLaVcj
	if '/youtubei/v1/browse' in llxFwq0CUNgQtivJzkHeGV or '/youtubei/v1/search' in llxFwq0CUNgQtivJzkHeGV or '/my_main_page_shorts_link' in url:
		data = ee8c0jzrTntGSUdRJm.getSetting('av.youtube.data')
		if data.count(':::')==4:
			WXaPYMdkIbQ1q,key,z9pgfh5slRqHukt1Lon8,TXsB4A682ceWVRtkEiIwMDJra,vanQT4j5Z8SfO2MHg19I = data.split(':::')
			OucJVrWRKSqDChiG7yn3oz0dafZF = WXaPYMdkIbQ1q+':::'+key+':::'+z9pgfh5slRqHukt1Lon8+':::'+TXsB4A682ceWVRtkEiIwMDJra+':::'+nb7UNYGvByVfWPOlMESmIQJ8t26TA
			if '/my_main_page_shorts_link' in url and not llxFwq0CUNgQtivJzkHeGV: llxFwq0CUNgQtivJzkHeGV = url
			else: llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV+'?key='+key
	if not title:
		global K9qeioHZ7bIC
		K9qeioHZ7bIC += 1
		title = 'فيديوهات '+str(K9qeioHZ7bIC)
		C9VNOL3UmyXPYbGrJ8 = '3'+'::'+QQCYzVD0lsT1Xabk+'::'+iWsEc1mM05vjLyCoNDl8rpUSb9XQ+'::'+AA6qOa5dh4fKNvsSuMo0P
	if not G62uf8ZSIzBE: return False
	elif 'searchPyvRenderer' in str(ImYg2jxU6Lc9Q1C4Oko): return False
	elif '/about' in llxFwq0CUNgQtivJzkHeGV: return False
	elif '/community' in llxFwq0CUNgQtivJzkHeGV: return False
	elif 'continuationItemRenderer' in list(ImYg2jxU6Lc9Q1C4Oko.keys()) or 'continuationCommand' in list(ImYg2jxU6Lc9Q1C4Oko.keys()):
		if int(level)>1: level = str(int(level)-1)
		C9VNOL3UmyXPYbGrJ8 = level+'::'+QQCYzVD0lsT1Xabk+'::'+iWsEc1mM05vjLyCoNDl8rpUSb9XQ+'::'+AA6qOa5dh4fKNvsSuMo0P
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+':: '+'صفحة أخرى',llxFwq0CUNgQtivJzkHeGV,144,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,C9VNOL3UmyXPYbGrJ8,OucJVrWRKSqDChiG7yn3oz0dafZF)
	elif '/search' in llxFwq0CUNgQtivJzkHeGV:
		title = ':: '+title
		C9VNOL3UmyXPYbGrJ8 = '3'+'::'+QQCYzVD0lsT1Xabk+'::'+iWsEc1mM05vjLyCoNDl8rpUSb9XQ+'::'+AA6qOa5dh4fKNvsSuMo0P
		url = url.replace('/search',hWGMqtBy4wuLaVcj)
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,url,145,hWGMqtBy4wuLaVcj,C9VNOL3UmyXPYbGrJ8,'_REMEMBERRESULTS_')
	elif 'search_query' in url and not llxFwq0CUNgQtivJzkHeGV:
		C9VNOL3UmyXPYbGrJ8 = '3'+'::'+QQCYzVD0lsT1Xabk+'::'+iWsEc1mM05vjLyCoNDl8rpUSb9XQ+'::'+AA6qOa5dh4fKNvsSuMo0P
		title = ':: '+title
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,url,144,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,C9VNOL3UmyXPYbGrJ8,OucJVrWRKSqDChiG7yn3oz0dafZF)
	elif '/browse' in llxFwq0CUNgQtivJzkHeGV and url==Str0BupDTFA:
		title = ':: '+title
		C9VNOL3UmyXPYbGrJ8 = '2::0::0::0'
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,144,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,C9VNOL3UmyXPYbGrJ8,OucJVrWRKSqDChiG7yn3oz0dafZF)
	elif not llxFwq0CUNgQtivJzkHeGV and 'horizontalMovieListRenderer' in str(ImYg2jxU6Lc9Q1C4Oko):
		title = ':: '+title
		C9VNOL3UmyXPYbGrJ8 = '3::0::0::0'
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,url,144,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,C9VNOL3UmyXPYbGrJ8)
	elif 'messageRenderer' in str(ImYg2jxU6Lc9Q1C4Oko):
		RLDCGt8kq3OVmnzgx1rbi2f7F('link',n0qFKQWhiBYXoTrvejVHUA4+title,hWGMqtBy4wuLaVcj,9999)
	elif AIlKnEy3iwRfzeF5rkUbhgp:
		RLDCGt8kq3OVmnzgx1rbi2f7F('live',n0qFKQWhiBYXoTrvejVHUA4+AIlKnEy3iwRfzeF5rkUbhgp+title,llxFwq0CUNgQtivJzkHeGV,143,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
	elif '/playlist?list=' in llxFwq0CUNgQtivJzkHeGV:
		llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV.replace('&playnext=1',hWGMqtBy4wuLaVcj)
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'LIST'+count+':  '+title,llxFwq0CUNgQtivJzkHeGV,144,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,C9VNOL3UmyXPYbGrJ8)
	elif '/shorts/' in llxFwq0CUNgQtivJzkHeGV:
		llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV.split('&list=',1)[0]
		RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,143,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,oJV18NUZAzPGqMu7tenCxrkfhdl69B)
	elif '/watch?v=' in llxFwq0CUNgQtivJzkHeGV:
		if '&list=' in llxFwq0CUNgQtivJzkHeGV and count:
			SbaUEPCock = llxFwq0CUNgQtivJzkHeGV.split('&list=',1)[1]
			llxFwq0CUNgQtivJzkHeGV = Str0BupDTFA+'/playlist?list='+SbaUEPCock
			C9VNOL3UmyXPYbGrJ8 = '1::0::0::0'
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'LIST'+count+':  '+title,llxFwq0CUNgQtivJzkHeGV,144,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,C9VNOL3UmyXPYbGrJ8)
		else:
			llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV.split('&list=',1)[0]
			RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,143,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,oJV18NUZAzPGqMu7tenCxrkfhdl69B)
	elif '/channel/' in llxFwq0CUNgQtivJzkHeGV or '/c/' in llxFwq0CUNgQtivJzkHeGV or ('/@' in llxFwq0CUNgQtivJzkHeGV and llxFwq0CUNgQtivJzkHeGV.count('/')==3):
		if VKiGj1LundAJQwEXcqgxC:
			title = title.decode(a7VXeDU82IfQEnPZAdiT).encode('raw_unicode_escape')
			title = emr1Lf523Ti0OtcNgxP(title)
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'CHNL'+count+':  '+title,llxFwq0CUNgQtivJzkHeGV,144,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,C9VNOL3UmyXPYbGrJ8)
	elif '/user/' in llxFwq0CUNgQtivJzkHeGV:
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'USER'+count+':  '+title,llxFwq0CUNgQtivJzkHeGV,144,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,C9VNOL3UmyXPYbGrJ8)
	else:
		if not llxFwq0CUNgQtivJzkHeGV: llxFwq0CUNgQtivJzkHeGV = url
		title = ':: '+title
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,144,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,C9VNOL3UmyXPYbGrJ8,OucJVrWRKSqDChiG7yn3oz0dafZF)
	return True
def II8WCQAeRgj(ImYg2jxU6Lc9Q1C4Oko):
	G62uf8ZSIzBE,title,llxFwq0CUNgQtivJzkHeGV,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,count,oJV18NUZAzPGqMu7tenCxrkfhdl69B,AIlKnEy3iwRfzeF5rkUbhgp,qqmnN2fDj3LSEZU5IgA,vanQT4j5Z8SfO2MHg19I = False,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj
	if not isinstance(ImYg2jxU6Lc9Q1C4Oko,dict): return G62uf8ZSIzBE,title,llxFwq0CUNgQtivJzkHeGV,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,count,oJV18NUZAzPGqMu7tenCxrkfhdl69B,AIlKnEy3iwRfzeF5rkUbhgp,qqmnN2fDj3LSEZU5IgA,vanQT4j5Z8SfO2MHg19I
	for Np8CvKznuE3s6m9I2WfJX4LRDAGc in list(ImYg2jxU6Lc9Q1C4Oko.keys()):
		kv2qB5RfKtblO184WS9m = ImYg2jxU6Lc9Q1C4Oko[Np8CvKznuE3s6m9I2WfJX4LRDAGc]
		if isinstance(kv2qB5RfKtblO184WS9m,dict): break
	EE2UbrpiWx5gaNjSfVY0DZTweMG4Av = []
	EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yrender['header']['playlistHeaderRenderer']['title']['simpleText']")
	EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yrender['header']['richListHeaderRenderer']['title']['simpleText']")
	EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yrender['header']['richListHeaderRenderer']['title']")
	EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yrender['headline']['simpleText']")
	EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yrender['unplayableText']['simpleText']")
	EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yrender['formattedTitle']['simpleText']")
	EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yrender['title']['simpleText']")
	EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yrender['title']['runs'][0]['text']")
	EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yrender['text']['simpleText']")
	EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yrender['text']['runs'][0]['text']")
	EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yrender['title']['content']")
	EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yrender['title']")
	EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("item['title']")
	EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("item['reelWatchEndpoint']['videoId']")
	G62uf8ZSIzBE,title,coDr4CpZ9UyQn8txJuA315eN0OjH = XkelnmQwbOaY8RsPIFot(ImYg2jxU6Lc9Q1C4Oko,kv2qB5RfKtblO184WS9m,EE2UbrpiWx5gaNjSfVY0DZTweMG4Av)
	EE2UbrpiWx5gaNjSfVY0DZTweMG4Av = []
	EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yrender['title']['runs'][0]['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yrender['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yrender['continuationEndpoint']['commandMetadata']['webCommandMetadata']['apiUrl']")
	EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yrender['navigationEndpoint']['commandMetadata']['webCommandMetadata']['apiUrl']")
	EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yrender['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("item['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("item['commandMetadata']['webCommandMetadata']['url']")
	G62uf8ZSIzBE,llxFwq0CUNgQtivJzkHeGV,coDr4CpZ9UyQn8txJuA315eN0OjH = XkelnmQwbOaY8RsPIFot(ImYg2jxU6Lc9Q1C4Oko,kv2qB5RfKtblO184WS9m,EE2UbrpiWx5gaNjSfVY0DZTweMG4Av)
	EE2UbrpiWx5gaNjSfVY0DZTweMG4Av = []
	EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yrender['thumbnail']['thumbnails'][0]['url']")
	EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yrender['thumbnails'][0]['thumbnails'][0]['url']")
	EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("item['reelWatchEndpoint']['thumbnail']['thumbnails'][0]['url']")
	G62uf8ZSIzBE,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,coDr4CpZ9UyQn8txJuA315eN0OjH = XkelnmQwbOaY8RsPIFot(ImYg2jxU6Lc9Q1C4Oko,kv2qB5RfKtblO184WS9m,EE2UbrpiWx5gaNjSfVY0DZTweMG4Av)
	EE2UbrpiWx5gaNjSfVY0DZTweMG4Av = []
	EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayBottomPanelRenderer']['text']['runs'][0]['text']")
	EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yrender['videoCountShortText']['simpleText']")
	EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yrender['videoCountText']['runs'][0]['text']")
	EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yrender['videoCount']")
	G62uf8ZSIzBE,count,coDr4CpZ9UyQn8txJuA315eN0OjH = XkelnmQwbOaY8RsPIFot(ImYg2jxU6Lc9Q1C4Oko,kv2qB5RfKtblO184WS9m,EE2UbrpiWx5gaNjSfVY0DZTweMG4Av)
	EE2UbrpiWx5gaNjSfVY0DZTweMG4Av = []
	EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['runs'][0]['text']")
	EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['simpleText']")
	EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yrender['lengthText']['simpleText']")
	EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['icon']['iconType']")
	EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['style']")
	G62uf8ZSIzBE,oJV18NUZAzPGqMu7tenCxrkfhdl69B,coDr4CpZ9UyQn8txJuA315eN0OjH = XkelnmQwbOaY8RsPIFot(ImYg2jxU6Lc9Q1C4Oko,kv2qB5RfKtblO184WS9m,EE2UbrpiWx5gaNjSfVY0DZTweMG4Av)
	EE2UbrpiWx5gaNjSfVY0DZTweMG4Av = []
	EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yrender['navigationEndpoint']['continuationCommand']['token']")
	EE2UbrpiWx5gaNjSfVY0DZTweMG4Av.append("yrender['continuationEndpoint']['continuationCommand']['token']")
	G62uf8ZSIzBE,vanQT4j5Z8SfO2MHg19I,coDr4CpZ9UyQn8txJuA315eN0OjH = XkelnmQwbOaY8RsPIFot(ImYg2jxU6Lc9Q1C4Oko,kv2qB5RfKtblO184WS9m,EE2UbrpiWx5gaNjSfVY0DZTweMG4Av)
	if 'LIVE' in oJV18NUZAzPGqMu7tenCxrkfhdl69B: oJV18NUZAzPGqMu7tenCxrkfhdl69B,AIlKnEy3iwRfzeF5rkUbhgp = hWGMqtBy4wuLaVcj,'LIVE:  '
	if 'مباشر' in oJV18NUZAzPGqMu7tenCxrkfhdl69B: oJV18NUZAzPGqMu7tenCxrkfhdl69B,AIlKnEy3iwRfzeF5rkUbhgp = hWGMqtBy4wuLaVcj,'LIVE:  '
	if 'badges' in list(kv2qB5RfKtblO184WS9m.keys()):
		po1iZwlIqkAJfcYBvstKeOdQF = str(kv2qB5RfKtblO184WS9m['badges'])
		if 'Free with Ads' in po1iZwlIqkAJfcYBvstKeOdQF: qqmnN2fDj3LSEZU5IgA = '$:  '
		if 'LIVE' in po1iZwlIqkAJfcYBvstKeOdQF: AIlKnEy3iwRfzeF5rkUbhgp = 'LIVE:  '
		if 'Buy' in po1iZwlIqkAJfcYBvstKeOdQF or 'Rent' in po1iZwlIqkAJfcYBvstKeOdQF: qqmnN2fDj3LSEZU5IgA = '$$:  '
		if DDZcb1RmaIMH(u'مباشر') in po1iZwlIqkAJfcYBvstKeOdQF: AIlKnEy3iwRfzeF5rkUbhgp = 'LIVE:  '
		if DDZcb1RmaIMH(u'شراء') in po1iZwlIqkAJfcYBvstKeOdQF: qqmnN2fDj3LSEZU5IgA = '$$:  '
		if DDZcb1RmaIMH(u'استئجار') in po1iZwlIqkAJfcYBvstKeOdQF: qqmnN2fDj3LSEZU5IgA = '$$:  '
		if DDZcb1RmaIMH(u'إعلانات') in po1iZwlIqkAJfcYBvstKeOdQF: qqmnN2fDj3LSEZU5IgA = '$:  '
	llxFwq0CUNgQtivJzkHeGV = emr1Lf523Ti0OtcNgxP(llxFwq0CUNgQtivJzkHeGV)
	if llxFwq0CUNgQtivJzkHeGV and 'http' not in llxFwq0CUNgQtivJzkHeGV: llxFwq0CUNgQtivJzkHeGV = Str0BupDTFA+llxFwq0CUNgQtivJzkHeGV
	Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG = Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG.split('?')[0]
	if  Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG and 'http' not in Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG: Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG = 'https:'+Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG
	title = emr1Lf523Ti0OtcNgxP(title)
	if qqmnN2fDj3LSEZU5IgA: title = qqmnN2fDj3LSEZU5IgA+title
	oJV18NUZAzPGqMu7tenCxrkfhdl69B = oJV18NUZAzPGqMu7tenCxrkfhdl69B.replace(',',hWGMqtBy4wuLaVcj)
	count = count.replace(',',hWGMqtBy4wuLaVcj)
	count = trdVA0JvFaD.findall('\d+',count)
	if count: count = count[0]
	else: count = hWGMqtBy4wuLaVcj
	return True,title,llxFwq0CUNgQtivJzkHeGV,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,count,oJV18NUZAzPGqMu7tenCxrkfhdl69B,AIlKnEy3iwRfzeF5rkUbhgp,qqmnN2fDj3LSEZU5IgA,vanQT4j5Z8SfO2MHg19I
def UUQuB9XmZA0(url,data=hWGMqtBy4wuLaVcj,s4mUPzjv1bRoNTMdenkuBgYl=hWGMqtBy4wuLaVcj):
	if s4mUPzjv1bRoNTMdenkuBgYl==hWGMqtBy4wuLaVcj: s4mUPzjv1bRoNTMdenkuBgYl = 'ytInitialData'
	o0ST4d1BWzi7r3OnK9ucCXxw = OB6QYAMUnPiWXgpkTrItV48FqZSjdR()
	PwvNmnqXKrYVZugB5c8 = {'User-Agent':o0ST4d1BWzi7r3OnK9ucCXxw,'Cookie':'PREF=hl=ar'}
	global ee8c0jzrTntGSUdRJm
	if not data: data = ee8c0jzrTntGSUdRJm.getSetting('av.youtube.data')
	if data.count(':::')==4: WXaPYMdkIbQ1q,key,z9pgfh5slRqHukt1Lon8,TXsB4A682ceWVRtkEiIwMDJra,vanQT4j5Z8SfO2MHg19I = data.split(':::')
	else: WXaPYMdkIbQ1q,key,z9pgfh5slRqHukt1Lon8,TXsB4A682ceWVRtkEiIwMDJra,vanQT4j5Z8SfO2MHg19I = hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj
	OucJVrWRKSqDChiG7yn3oz0dafZF = {"context":{"client":{"hl":"ar","clientName":"WEB","clientVersion":z9pgfh5slRqHukt1Lon8}}}
	if url==Str0BupDTFA+'/shorts' or '/my_main_page_shorts_link' in url:
		url = Str0BupDTFA+'/youtubei/v1/reel/reel_watch_sequence'+'?key='+key
		OucJVrWRKSqDChiG7yn3oz0dafZF['sequenceParams'] = WXaPYMdkIbQ1q
		OucJVrWRKSqDChiG7yn3oz0dafZF = str(OucJVrWRKSqDChiG7yn3oz0dafZF)
		sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(nHBb7jXk0Daom,'POST',url,OucJVrWRKSqDChiG7yn3oz0dafZF,PwvNmnqXKrYVZugB5c8,True,True,'YOUTUBE-GET_PAGE_DATA-1st')
	elif '/guide?key=' in url:
		url = Str0BupDTFA+'/youtubei/v1/guide?key='+key
		OucJVrWRKSqDChiG7yn3oz0dafZF = str(OucJVrWRKSqDChiG7yn3oz0dafZF)
		sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(nHBb7jXk0Daom,'POST',url,OucJVrWRKSqDChiG7yn3oz0dafZF,PwvNmnqXKrYVZugB5c8,True,True,'YOUTUBE-GET_PAGE_DATA-3rd')
	elif 'key=' in url and WXaPYMdkIbQ1q:
		OucJVrWRKSqDChiG7yn3oz0dafZF['continuation'] = vanQT4j5Z8SfO2MHg19I
		OucJVrWRKSqDChiG7yn3oz0dafZF['context']['client']['visitorData'] = WXaPYMdkIbQ1q
		OucJVrWRKSqDChiG7yn3oz0dafZF = str(OucJVrWRKSqDChiG7yn3oz0dafZF)
		sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(nHBb7jXk0Daom,'POST',url,OucJVrWRKSqDChiG7yn3oz0dafZF,PwvNmnqXKrYVZugB5c8,True,True,'YOUTUBE-GET_PAGE_DATA-4th')
	elif 'ctoken=' in url and TXsB4A682ceWVRtkEiIwMDJra:
		PwvNmnqXKrYVZugB5c8.update({'X-YouTube-Client-Name':'1','X-YouTube-Client-Version':z9pgfh5slRqHukt1Lon8})
		PwvNmnqXKrYVZugB5c8.update({'Cookie':'VISITOR_INFO1_LIVE='+TXsB4A682ceWVRtkEiIwMDJra})
		sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(nHBb7jXk0Daom,'GET',url,hWGMqtBy4wuLaVcj,PwvNmnqXKrYVZugB5c8,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'YOUTUBE-GET_PAGE_DATA-5th')
	else:
		sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(nHBb7jXk0Daom,'GET',url,hWGMqtBy4wuLaVcj,PwvNmnqXKrYVZugB5c8,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'YOUTUBE-GET_PAGE_DATA-6th')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	p05pq1QcdOZrzXMJs3I7VTUjEHxKa = trdVA0JvFaD.findall('"innertubeApiKey".*?"(.*?)"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL|trdVA0JvFaD.I)
	if p05pq1QcdOZrzXMJs3I7VTUjEHxKa: key = p05pq1QcdOZrzXMJs3I7VTUjEHxKa[0]
	p05pq1QcdOZrzXMJs3I7VTUjEHxKa = trdVA0JvFaD.findall('"cver".*?"value".*?"(.*?)"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL|trdVA0JvFaD.I)
	if p05pq1QcdOZrzXMJs3I7VTUjEHxKa: z9pgfh5slRqHukt1Lon8 = p05pq1QcdOZrzXMJs3I7VTUjEHxKa[0]
	p05pq1QcdOZrzXMJs3I7VTUjEHxKa = trdVA0JvFaD.findall('"visitorData".*?"(.*?)"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL|trdVA0JvFaD.I)
	if p05pq1QcdOZrzXMJs3I7VTUjEHxKa: WXaPYMdkIbQ1q = p05pq1QcdOZrzXMJs3I7VTUjEHxKa[0]
	cookies = sDQvwGASB0Vf67mik.cookies
	if 'VISITOR_INFO1_LIVE' in list(cookies.keys()): TXsB4A682ceWVRtkEiIwMDJra = cookies['VISITOR_INFO1_LIVE']
	Tmf2x4KQBCYo6tONsERizpubWG0V = WXaPYMdkIbQ1q+':::'+key+':::'+z9pgfh5slRqHukt1Lon8+':::'+TXsB4A682ceWVRtkEiIwMDJra+':::'+vanQT4j5Z8SfO2MHg19I
	if s4mUPzjv1bRoNTMdenkuBgYl=='ytInitialData' and 'ytInitialData' in mMQ3FkNVa4IlxqY:
		hXzOAlcgKw = trdVA0JvFaD.findall('window\["ytInitialData"\] = ({.*?});',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if not hXzOAlcgKw: hXzOAlcgKw = trdVA0JvFaD.findall('var ytInitialData = ({.*?});',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		Q0pVCdB96SsbXx = Cy9ow3c21nABMjzqeaIT('str',hXzOAlcgKw[0])
	elif s4mUPzjv1bRoNTMdenkuBgYl=='ytInitialGuideData' and 'ytInitialGuideData' in mMQ3FkNVa4IlxqY:
		hXzOAlcgKw = trdVA0JvFaD.findall('var ytInitialGuideData = ({.*?});',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		Q0pVCdB96SsbXx = Cy9ow3c21nABMjzqeaIT('str',hXzOAlcgKw[0])
	elif '</script>' not in mMQ3FkNVa4IlxqY: Q0pVCdB96SsbXx = Cy9ow3c21nABMjzqeaIT('str',mMQ3FkNVa4IlxqY)
	else: Q0pVCdB96SsbXx = hWGMqtBy4wuLaVcj
	if 0:
		FAJ4XhNPL5H0wdWifIKOjrB = str(Q0pVCdB96SsbXx)
		if H4qZ2hwilNJYTmCFEQyaSs98cPM0gR: FAJ4XhNPL5H0wdWifIKOjrB = FAJ4XhNPL5H0wdWifIKOjrB.encode(a7VXeDU82IfQEnPZAdiT)
		open('S:\\0000emad.dat','wb').write(FAJ4XhNPL5H0wdWifIKOjrB)
	ee8c0jzrTntGSUdRJm.setSetting('av.youtube.data',Tmf2x4KQBCYo6tONsERizpubWG0V)
	return mMQ3FkNVa4IlxqY,Q0pVCdB96SsbXx,Tmf2x4KQBCYo6tONsERizpubWG0V
def ttouNCaeMwE8ny0qGUmxc1ADsvQLBY(url,C9VNOL3UmyXPYbGrJ8):
	search = TrzfUidpv1LyAYqwexHJDuS()
	if not search: return
	search = search.replace(Mpsm2VF1OBnCRvK3qf6,'+')
	NPM3HKQ57xe = url+'/search?query='+search
	wg5aF3e8rcDh7SGpW6M1OPnkU(NPM3HKQ57xe,C9VNOL3UmyXPYbGrJ8)
	return
def lPwaAjFTMG4n7iSLkXcEuK0Zm(search):
	search,vvKf4sXgZIMyEJPuC,showDialogs = IVTEJQOiMR2dYta9C(search)
	if not search:
		search = TrzfUidpv1LyAYqwexHJDuS()
		if not search: return
	search = search.replace(Mpsm2VF1OBnCRvK3qf6,'+')
	NPM3HKQ57xe = Str0BupDTFA+'/results?search_query='+search
	if not showDialogs:
		if '_YOUTUBE-VIDEOS_' in vvKf4sXgZIMyEJPuC: JPOjfi74KspT = '&sp=EgIQAQ%253D%253D'
		elif '_YOUTUBE-PLAYLISTS_' in vvKf4sXgZIMyEJPuC: JPOjfi74KspT = '&sp=EgIQAw%253D%253D'
		elif '_YOUTUBE-CHANNELS_' in vvKf4sXgZIMyEJPuC: JPOjfi74KspT = '&sp=EgIQAg%253D%253D'
		else: JPOjfi74KspT = hWGMqtBy4wuLaVcj
		CMzQFXeI08KDwAJ9p = NPM3HKQ57xe+JPOjfi74KspT
	else:
		hxvVMpOrTdk,qLYF5Db1NZ,m4eVoJdSU51qs3y8Gg06fZNau7A = [],[],hWGMqtBy4wuLaVcj
		fTXYz2CZ5cF1xmi4j8tRsyQhv = ['فيديوهات مرتبة بالصلة','فيديوهات مرتبة بالتاريخ','فيديوهات مرتبة بعدد المشاهدات','فيديوهات مرتبة بالتقييم','(جيد للمسلسلات) قوائم تشغيل','قنوات','بث حي']
		FUhjZuYgnm0 = ['&sp=CAASAhAB','&sp=CAISAhAB','&sp=CAMSAhAB','&sp=CAESAhAB','&sp=EgIQAw==','&sp=EgIQAg==','&sp=EgJAAQ==']
		vXT3yH8egowfICFEs = Eb7qJoNwOgn('اختر البحث المناسب',fTXYz2CZ5cF1xmi4j8tRsyQhv)
		if vXT3yH8egowfICFEs == -1: return
		FaEj8KGPNhg1V = FUhjZuYgnm0[vXT3yH8egowfICFEs]
		mMQ3FkNVa4IlxqY,ssBDVT0kh3od,data = UUQuB9XmZA0(NPM3HKQ57xe+FaEj8KGPNhg1V)
		if ssBDVT0kh3od:
			try:
				v1fwA8koXingBNCprRblsGjq20J9 = ssBDVT0kh3od['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['subMenu']['searchSubMenuRenderer']['groups']
				for LTmypCAwz7bfFIvs6Okqa3 in range(len(v1fwA8koXingBNCprRblsGjq20J9)):
					group = v1fwA8koXingBNCprRblsGjq20J9[LTmypCAwz7bfFIvs6Okqa3]['searchFilterGroupRenderer']['filters']
					for PfgCrFdymn4l8QX in range(len(group)):
						kv2qB5RfKtblO184WS9m = group[PfgCrFdymn4l8QX]['searchFilterRenderer']
						if 'navigationEndpoint' in list(kv2qB5RfKtblO184WS9m.keys()):
							llxFwq0CUNgQtivJzkHeGV = kv2qB5RfKtblO184WS9m['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']
							llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV.replace('\u0026','&')
							title = kv2qB5RfKtblO184WS9m['tooltip']
							title = title.replace('البحث عن ',hWGMqtBy4wuLaVcj)
							if 'إزالة الفلتر' in title: continue
							if 'قائمة تشغيل' in title:
								title = 'جيد للمسلسلات '+title
								m4eVoJdSU51qs3y8Gg06fZNau7A = title
								MDSF21x9HK3AZyGUhcb = llxFwq0CUNgQtivJzkHeGV
							if 'ترتيب حسب' in title: continue
							title = title.replace('Search for ',hWGMqtBy4wuLaVcj)
							if 'Remove' in title: continue
							if 'Playlist' in title:
								title = 'جيد للمسلسلات '+title
								m4eVoJdSU51qs3y8Gg06fZNau7A = title
								MDSF21x9HK3AZyGUhcb = llxFwq0CUNgQtivJzkHeGV
							if 'Sort by' in title: continue
							hxvVMpOrTdk.append(emr1Lf523Ti0OtcNgxP(title))
							qLYF5Db1NZ.append(llxFwq0CUNgQtivJzkHeGV)
			except: pass
		if not m4eVoJdSU51qs3y8Gg06fZNau7A: B2GRPEOItdYXQjqes3fxop = hWGMqtBy4wuLaVcj
		else:
			hxvVMpOrTdk = ['بدون فلتر',m4eVoJdSU51qs3y8Gg06fZNau7A]+hxvVMpOrTdk
			qLYF5Db1NZ = [hWGMqtBy4wuLaVcj,MDSF21x9HK3AZyGUhcb]+qLYF5Db1NZ
			gFtA8S0nHyZ = Eb7qJoNwOgn('موقع يوتيوب - اختر الفلتر',hxvVMpOrTdk)
			if gFtA8S0nHyZ == -1: return
			B2GRPEOItdYXQjqes3fxop = qLYF5Db1NZ[gFtA8S0nHyZ]
		if B2GRPEOItdYXQjqes3fxop: CMzQFXeI08KDwAJ9p = Str0BupDTFA+B2GRPEOItdYXQjqes3fxop
		elif FaEj8KGPNhg1V: CMzQFXeI08KDwAJ9p = NPM3HKQ57xe+FaEj8KGPNhg1V
		else: CMzQFXeI08KDwAJ9p = NPM3HKQ57xe
	wg5aF3e8rcDh7SGpW6M1OPnkU(CMzQFXeI08KDwAJ9p)
	return
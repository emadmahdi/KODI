# -*- coding: utf-8 -*-
from yoY3NdGViS import *
xjPuFK3EsIZSiobQ5X = 'MOVS4U'
n0qFKQWhiBYXoTrvejVHUA4 = '_M4U_'
Str0BupDTFA = u6rbxnyjTl7I[xjPuFK3EsIZSiobQ5X][0]
P3UK1Rr4IdYe5 = ['انواع افلام','جودات افلام']
def ehB18u9sQFRi(mode,url,text):
	if   mode==380: N6NCYivtV4I5rEXq = DP6FSBgNdX1rsvVR()
	elif mode==381: N6NCYivtV4I5rEXq = wg5aF3e8rcDh7SGpW6M1OPnkU(url,text)
	elif mode==382: N6NCYivtV4I5rEXq = oanus6TxUFNAhSZKpJdYlEC4mV(url)
	elif mode==383: N6NCYivtV4I5rEXq = GrsxUhb0PEXj2FQRAkD4q(url)
	elif mode==389: N6NCYivtV4I5rEXq = lPwaAjFTMG4n7iSLkXcEuK0Zm(text)
	else: N6NCYivtV4I5rEXq = False
	return N6NCYivtV4I5rEXq
def DP6FSBgNdX1rsvVR():
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'بحث في الموقع',hWGMqtBy4wuLaVcj,389,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'_REMEMBERRESULTS_')
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+'المميزة',Str0BupDTFA,381,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'featured')
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+'الجانبية',Str0BupDTFA,381,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'sider')
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(DpQifS0oKBI1hYcO,'GET',Str0BupDTFA,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'MOVS4U-MENU-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	items = trdVA0JvFaD.findall('<header>.*?<h2>(.*?)<',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	for XK2iWMx6yfU9E in range(len(items)):
		title = items[XK2iWMx6yfU9E]
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+title,Str0BupDTFA,381,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'latest'+str(XK2iWMx6yfU9E))
	cok5ZGXdQP7YhwtqyuaCnVevm6UB = hWGMqtBy4wuLaVcj
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('class="menu"(.*?)id="contenedor"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o: cok5ZGXdQP7YhwtqyuaCnVevm6UB += DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('class="sidebar(.*?)aside',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o: cok5ZGXdQP7YhwtqyuaCnVevm6UB += DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
	items = trdVA0JvFaD.findall('href="(.*?)">(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	jlIGSiUuRophY8A = True
	for llxFwq0CUNgQtivJzkHeGV,title in items:
		title = LNtIDdBA52P(title)
		if title=='الأعلى مشاهدة':
			if jlIGSiUuRophY8A:
				title = 'الافلام '+title
				jlIGSiUuRophY8A = False
			else: title = 'المسلسلات '+title
		if title not in P3UK1Rr4IdYe5:
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,381)
	return mMQ3FkNVa4IlxqY
def wg5aF3e8rcDh7SGpW6M1OPnkU(url,type):
	cok5ZGXdQP7YhwtqyuaCnVevm6UB,items = [],[]
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'MOVS4U-TITLES-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	if type=='search':
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('class="search-page"(.*?)class="sidebar',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
			cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
			items = trdVA0JvFaD.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	elif type=='sider':
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('class="widget(.*?)class="widget',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		Tbt04p3uq2jP86Vwg = trdVA0JvFaD.findall('href="(.*?)".*?img src="(.*?)".*?<h3>(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		Dvi8asSrQYX5wE3KMIxT91me,OfpxWZ5PdcHAIXE76zQh,haq1bHZINPE58uoBFnKfTSO2ik4 = zip(*Tbt04p3uq2jP86Vwg)
		items = zip(OfpxWZ5PdcHAIXE76zQh,Dvi8asSrQYX5wE3KMIxT91me,haq1bHZINPE58uoBFnKfTSO2ik4)
	elif type=='featured':
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('id="slider-movies-tvshows"(.*?)<header>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	elif 'latest' in type:
		XK2iWMx6yfU9E = int(type[-1:])
		mMQ3FkNVa4IlxqY = mMQ3FkNVa4IlxqY.replace('<header>','<end><start>')
		mMQ3FkNVa4IlxqY = mMQ3FkNVa4IlxqY.replace('<div class="sidebar','<end><div class="sidebar')
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('<start>(.*?)<end>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[XK2iWMx6yfU9E]
		if XK2iWMx6yfU9E==2: items = trdVA0JvFaD.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	else:
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('class="content"(.*?)class="(pagination|sidebar)',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
			cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0][0]
			if '/collection/' in url:
				items = trdVA0JvFaD.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
			elif '/quality/' in url:
				items = trdVA0JvFaD.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	if not items and cok5ZGXdQP7YhwtqyuaCnVevm6UB:
		items = trdVA0JvFaD.findall('img src="(.*?)".*?href=.*?href="(.*?)">(.*?)</div>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	REbVyXis1w4Ae = []
	for Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,llxFwq0CUNgQtivJzkHeGV,title in items:
		if 'serie' in title:
			title = trdVA0JvFaD.findall('^(.*?)<.*?serie">(.*?)<',title,trdVA0JvFaD.DOTALL)
			title = title[0][1]
			if title in REbVyXis1w4Ae: continue
			REbVyXis1w4Ae.append(title)
			title = '_MOD_'+title
		m4eVoJdSU51qs3y8Gg06fZNau7A = trdVA0JvFaD.findall('^(.*?)<',title,trdVA0JvFaD.DOTALL)
		if m4eVoJdSU51qs3y8Gg06fZNau7A: title = m4eVoJdSU51qs3y8Gg06fZNau7A[0]
		title = LNtIDdBA52P(title)
		if '/tvshows/' in llxFwq0CUNgQtivJzkHeGV: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,383,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
		elif '/episodes/' in llxFwq0CUNgQtivJzkHeGV: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,383,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
		elif '/seasons/' in llxFwq0CUNgQtivJzkHeGV: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,383,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
		elif '/collection/' in llxFwq0CUNgQtivJzkHeGV: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,381,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
		else: RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,382,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('class="pagination".*?Page (.*?) of (.*?)<(.*?)</div>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		jmS3Yz48H9BlUXIe0kQDbWrvOPh57 = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0][0]
		NNajd7R5yEhVUrQGKHbcBxoXL = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0][1]
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0][2]
		items = trdVA0JvFaD.findall("href='(.*?)'.*?>(.*?)<",cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,title in items:
			if title==hWGMqtBy4wuLaVcj or title==NNajd7R5yEhVUrQGKHbcBxoXL: continue
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'صفحة '+title,llxFwq0CUNgQtivJzkHeGV,381,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,type)
		llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV.replace('/page/'+title+'/','/page/'+NNajd7R5yEhVUrQGKHbcBxoXL+'/')
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'اخر صفحة '+NNajd7R5yEhVUrQGKHbcBxoXL,llxFwq0CUNgQtivJzkHeGV,381,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,type)
	return
def GrsxUhb0PEXj2FQRAkD4q(url):
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'MOVS4U-EPISODES-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	BX029UJFPvpNQsc45jbYZRh = trdVA0JvFaD.findall('class="C rated".*?>(.*?)<',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if BX029UJFPvpNQsc45jbYZRh and Dc20k3vN9hT5(xjPuFK3EsIZSiobQ5X,url,BX029UJFPvpNQsc45jbYZRh,False):
		RLDCGt8kq3OVmnzgx1rbi2f7F('link',n0qFKQWhiBYXoTrvejVHUA4+'المسلسل للكبار والمبرمج منعه',hWGMqtBy4wuLaVcj,9999)
		return
	if '/episodes/' in url or '/tvshows/' in url:
		NPM3HKQ57xe = trdVA0JvFaD.findall('''class='item'><a href="(.*?)"''',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if NPM3HKQ57xe:
			NPM3HKQ57xe = NPM3HKQ57xe[1]
			GrsxUhb0PEXj2FQRAkD4q(NPM3HKQ57xe)
			return
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('''class='episodios'(.*?)id="cast"''',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('''src='(.*?)'.*?class='numerando'>(.*?)<.*?href='(.*?)'>(.*?)<''',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,IIsmGy4pd7,llxFwq0CUNgQtivJzkHeGV,name in items:
			title = IIsmGy4pd7+' : '+name+' الحلقة'
			RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,382)
	return
def oanus6TxUFNAhSZKpJdYlEC4mV(url):
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'MOVS4U-PLAY-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	BX029UJFPvpNQsc45jbYZRh = trdVA0JvFaD.findall('class="C rated".*?>(.*?)<',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if BX029UJFPvpNQsc45jbYZRh and Dc20k3vN9hT5(xjPuFK3EsIZSiobQ5X,url,BX029UJFPvpNQsc45jbYZRh): return
	Dvi8asSrQYX5wE3KMIxT91me = []
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('''id='player-option-1'(.*?)class=("sheader"|'pag_episodes')''',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0][0]
		items = trdVA0JvFaD.findall("data-url='(.*?)'.*?class='server'>(.*?)<",cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,title in items:
			llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV+'?named='+title+'__watch'
			Dvi8asSrQYX5wE3KMIxT91me.append(llxFwq0CUNgQtivJzkHeGV)
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('class="remodal"(.*?)class="remodal-close"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('class="___dl_gdrive.*?href="(.*?)".*?">(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,title in items:
			llxFwq0CUNgQtivJzkHeGV = Str0BupDTFA+llxFwq0CUNgQtivJzkHeGV
			llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV+'?named='+title+'__download'
			Dvi8asSrQYX5wE3KMIxT91me.append(llxFwq0CUNgQtivJzkHeGV)
	import oosSOfvdEQ
	oosSOfvdEQ.zfdYjsGLg8M6i15qZWh(Dvi8asSrQYX5wE3KMIxT91me,xjPuFK3EsIZSiobQ5X,'video',url)
	return
def lPwaAjFTMG4n7iSLkXcEuK0Zm(search):
	search,vvKf4sXgZIMyEJPuC,showDialogs = IVTEJQOiMR2dYta9C(search)
	if search==hWGMqtBy4wuLaVcj: search = TrzfUidpv1LyAYqwexHJDuS()
	if search==hWGMqtBy4wuLaVcj: return
	search = search.replace(Mpsm2VF1OBnCRvK3qf6,'+')
	url = Str0BupDTFA+'/?s='+search
	wg5aF3e8rcDh7SGpW6M1OPnkU(url,'search')
	return
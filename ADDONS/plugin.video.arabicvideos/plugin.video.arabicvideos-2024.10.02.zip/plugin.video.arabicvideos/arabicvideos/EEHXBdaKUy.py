# -*- coding: utf-8 -*-
from yoY3NdGViS import *
xjPuFK3EsIZSiobQ5X = 'SHAHID4U'
n0qFKQWhiBYXoTrvejVHUA4 = '_SH4_'
Str0BupDTFA = u6rbxnyjTl7I[xjPuFK3EsIZSiobQ5X][0]
headers = {'User-Agent':OB6QYAMUnPiWXgpkTrItV48FqZSjdR(True)}
P3UK1Rr4IdYe5 = ['عروض مصارعة','الكل','افلام','javascript','مصارعة حرة']
def ehB18u9sQFRi(mode,url,text):
	if   mode==110: N6NCYivtV4I5rEXq = DP6FSBgNdX1rsvVR()
	elif mode==111: N6NCYivtV4I5rEXq = wg5aF3e8rcDh7SGpW6M1OPnkU(url,text)
	elif mode==112: N6NCYivtV4I5rEXq = oanus6TxUFNAhSZKpJdYlEC4mV(url)
	elif mode==113: N6NCYivtV4I5rEXq = GrsxUhb0PEXj2FQRAkD4q(url,True)
	elif mode==114: N6NCYivtV4I5rEXq = hadMgR0nOKHoGqpA(url,'FULL_FILTER___'+text)
	elif mode==115: N6NCYivtV4I5rEXq = hadMgR0nOKHoGqpA(url,'DEFINED_FILTER___'+text)
	elif mode==116: N6NCYivtV4I5rEXq = GrsxUhb0PEXj2FQRAkD4q(url,False)
	elif mode==119: N6NCYivtV4I5rEXq = lPwaAjFTMG4n7iSLkXcEuK0Zm(text)
	else: N6NCYivtV4I5rEXq = False
	return N6NCYivtV4I5rEXq
def DP6FSBgNdX1rsvVR():
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',Str0BupDTFA,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'SHAHID4U-MENU-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	cbYKa2SXGwRCiQIW5NeosU9k = RRNODILCtGzvgpx(sDQvwGASB0Vf67mik.url,'url')
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'بحث في الموقع',hWGMqtBy4wuLaVcj,119,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'_REMEMBERRESULTS_')
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'فلتر محدد',cbYKa2SXGwRCiQIW5NeosU9k,115)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'فلتر كامل',cbYKa2SXGwRCiQIW5NeosU9k,114)
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'المميزة',cbYKa2SXGwRCiQIW5NeosU9k,111,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'featured')
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('simple-filter(.*?)adv-filter',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if not DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'موقع شاهد فوريو','البرنامج لم يستطيع إيجاد عنوان الموقع أو تصميم الموقع تغير')
		return
	else:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('location = \'(.*?)\'.*?src="(.*?)".*?<h3>(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for filter,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,title in items:
			url = cbYKa2SXGwRCiQIW5NeosU9k+filter
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+title,url,111,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,hWGMqtBy4wuLaVcj,filter)
		RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('class="dropdown"(.*?)<script>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('href="(.*?)".*?>(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,title in items:
			title = title.replace(NXMOzZjYsmS9pf,hWGMqtBy4wuLaVcj).replace(y6eSQlZEV8uwKG5M3,hWGMqtBy4wuLaVcj).strip(Mpsm2VF1OBnCRvK3qf6)
			if title in P3UK1Rr4IdYe5: continue
			if 'http' not in llxFwq0CUNgQtivJzkHeGV: llxFwq0CUNgQtivJzkHeGV = cbYKa2SXGwRCiQIW5NeosU9k+llxFwq0CUNgQtivJzkHeGV
			if 'netflix' in llxFwq0CUNgQtivJzkHeGV: title = 'نيتفلكس'
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,111)
	return mMQ3FkNVa4IlxqY
def wg5aF3e8rcDh7SGpW6M1OPnkU(url,Zn0DwEg9b7zxavJ8yUqHO5dM1=hWGMqtBy4wuLaVcj,sDQvwGASB0Vf67mik=hWGMqtBy4wuLaVcj):
	if not sDQvwGASB0Vf67mik: sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',url,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'SHAHID4U-TITLES-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o,items,REbVyXis1w4Ae = [],[],[]
	if Zn0DwEg9b7zxavJ8yUqHO5dM1=='featured': DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('glide__slides(.*?)</ul>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	else: DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('shows-container(.*?)pagination',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if not DJvksH7ZAFUqW9OyQnbGjPCtwR1o: return
	cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
	if not items: items = trdVA0JvFaD.findall('href="(.*?)".*?url\((.*?)\).*?"title">(.*?)</h4>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	nNBCdTs98RztMyODHpL63ZUKm4P = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for llxFwq0CUNgQtivJzkHeGV,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,title in items:
		if 'WWE' in title: continue
		if 'javascript' in llxFwq0CUNgQtivJzkHeGV: continue
		llxFwq0CUNgQtivJzkHeGV = jkiCS0UWs2dNAJcGKn6mbHD(llxFwq0CUNgQtivJzkHeGV).strip('/')
		title = LNtIDdBA52P(title)
		title = title.strip(Mpsm2VF1OBnCRvK3qf6)
		IIsmGy4pd7 = trdVA0JvFaD.findall('(.*?) الحلقة \d+',title,trdVA0JvFaD.DOTALL)
		if '/film/' in llxFwq0CUNgQtivJzkHeGV or 'فيلم' in llxFwq0CUNgQtivJzkHeGV or any(BoSjXKxz41DcneO9UimClE in title for BoSjXKxz41DcneO9UimClE in nNBCdTs98RztMyODHpL63ZUKm4P):
			RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,112,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
		elif IIsmGy4pd7 and 'الحلقة' in title and '/list' not in url:
			title = '_MOD_' + IIsmGy4pd7[0]
			if title not in REbVyXis1w4Ae:
				RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,113,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
				REbVyXis1w4Ae.append(title)
		elif '/actor/' in llxFwq0CUNgQtivJzkHeGV:
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,111,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
		elif '/series/' in llxFwq0CUNgQtivJzkHeGV and '/list' not in url:
			llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV+'/list'
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,111,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
		elif '/list' in url and 'حلقة' in title:
			RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,112,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
		else: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,113,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('"pagination"(.*?)</ul>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		if Zn0DwEg9b7zxavJ8yUqHO5dM1!='search': items = trdVA0JvFaD.findall('(updateQuery).*?>(.+?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		else: items = trdVA0JvFaD.findall('<li>.*?href="(.*?)">(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		if 'page=' in url: url = url.split('page=',1)[0][:-1]
		for llxFwq0CUNgQtivJzkHeGV,title in items:
			title = title.replace(NXMOzZjYsmS9pf,hWGMqtBy4wuLaVcj).replace(y6eSQlZEV8uwKG5M3,hWGMqtBy4wuLaVcj)
			title = title.strip(Mpsm2VF1OBnCRvK3qf6)
			if Zn0DwEg9b7zxavJ8yUqHO5dM1!='search':
				if '?' in url: llxFwq0CUNgQtivJzkHeGV = url+'&page='+title
				else: llxFwq0CUNgQtivJzkHeGV = url+'?page='+title
			title = LNtIDdBA52P(title)
			if title: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'صفحة '+title,llxFwq0CUNgQtivJzkHeGV,111,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,Zn0DwEg9b7zxavJ8yUqHO5dM1)
	return
def GrsxUhb0PEXj2FQRAkD4q(url,FuBLxrkEaglznGN):
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',url,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'SHAHID4U-EPISODES-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('items d-flex(.*?)</div>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if len(DJvksH7ZAFUqW9OyQnbGjPCtwR1o)>1:
		if '/season/' in DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]: k8YRdISjEZF0qyzs5GK,aTjkFVusW1c35G8v = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0],DJvksH7ZAFUqW9OyQnbGjPCtwR1o[1]
		else: k8YRdISjEZF0qyzs5GK,aTjkFVusW1c35G8v = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[1],DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
	else: k8YRdISjEZF0qyzs5GK,aTjkFVusW1c35G8v = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0],DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
	for JpzD0lv9cYM6XrHeqCa in range(2):
		if FuBLxrkEaglznGN: mode,type,cok5ZGXdQP7YhwtqyuaCnVevm6UB = 116,'folder',k8YRdISjEZF0qyzs5GK
		else: mode,type,cok5ZGXdQP7YhwtqyuaCnVevm6UB = 112,'video',aTjkFVusW1c35G8v
		items = trdVA0JvFaD.findall('href="(.*?)".*?span.*?">(.*?)<.*?span.*?">(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		if FuBLxrkEaglznGN and len(items)<2:
			FuBLxrkEaglznGN = False
			continue
		for llxFwq0CUNgQtivJzkHeGV,tZaSpl5NQAU8hxw,m4eVoJdSU51qs3y8Gg06fZNau7A in items:
			title = tZaSpl5NQAU8hxw+Mpsm2VF1OBnCRvK3qf6+m4eVoJdSU51qs3y8Gg06fZNau7A
			RLDCGt8kq3OVmnzgx1rbi2f7F(type,n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,mode)
		break
	if not items and '/episodes' in mMQ3FkNVa4IlxqY:
		KkYdJElVmtDPCUg = trdVA0JvFaD.findall('class="breadcrumb"(.*?)</div>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if KkYdJElVmtDPCUg:
			cok5ZGXdQP7YhwtqyuaCnVevm6UB = KkYdJElVmtDPCUg[0]
			m4IznKilUOByHweG68VJ = trdVA0JvFaD.findall('href="(.*?)"',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
			if len(m4IznKilUOByHweG68VJ)>2:
				llxFwq0CUNgQtivJzkHeGV = m4IznKilUOByHweG68VJ[2]+'list'
				wg5aF3e8rcDh7SGpW6M1OPnkU(llxFwq0CUNgQtivJzkHeGV)
	return
def oanus6TxUFNAhSZKpJdYlEC4mV(url):
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(DpQifS0oKBI1hYcO,'GET',url,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'SHAHID4U-PLAY-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('class="actions(.*?)</div>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if not DJvksH7ZAFUqW9OyQnbGjPCtwR1o: return
	cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
	m4IznKilUOByHweG68VJ = trdVA0JvFaD.findall('href="(.*?)"',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	qkWzADUy5l01r8d = '/watch/' in cok5ZGXdQP7YhwtqyuaCnVevm6UB
	download = '/download/' in cok5ZGXdQP7YhwtqyuaCnVevm6UB
	if   qkWzADUy5l01r8d and not download: xtgBRp30qHTmyk,uyVpTh15EYwCs = m4IznKilUOByHweG68VJ[0],hWGMqtBy4wuLaVcj
	elif not qkWzADUy5l01r8d and download: xtgBRp30qHTmyk,uyVpTh15EYwCs = hWGMqtBy4wuLaVcj,m4IznKilUOByHweG68VJ[0]
	elif qkWzADUy5l01r8d and download: xtgBRp30qHTmyk,uyVpTh15EYwCs = m4IznKilUOByHweG68VJ[0],m4IznKilUOByHweG68VJ[1]
	else: xtgBRp30qHTmyk,uyVpTh15EYwCs = hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj
	Dvi8asSrQYX5wE3KMIxT91me = []
	if qkWzADUy5l01r8d:
		sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(DpQifS0oKBI1hYcO,'GET',xtgBRp30qHTmyk,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'SHAHID4U-PLAY-2nd')
		eecmFXt5SRyCjGpx = sDQvwGASB0Vf67mik.content
		v2V8Nmrwf4 = trdVA0JvFaD.findall('let servers(.*?)player',eecmFXt5SRyCjGpx,trdVA0JvFaD.DOTALL|trdVA0JvFaD.IGNORECASE)
		if v2V8Nmrwf4:
			TfCqlZthRYgzkbE0GO = v2V8Nmrwf4[0]
			yRE17DrswMOxv0Gc9H = trdVA0JvFaD.findall('"name":"(.*?)".*?"url":"(.*?)"',TfCqlZthRYgzkbE0GO,trdVA0JvFaD.DOTALL)
			for title,llxFwq0CUNgQtivJzkHeGV in yRE17DrswMOxv0Gc9H:
				llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV.replace('\\/','/')
				llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV+'?named='+title+'__watch'
				Dvi8asSrQYX5wE3KMIxT91me.append(llxFwq0CUNgQtivJzkHeGV)
	if download:
		sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(DpQifS0oKBI1hYcO,'GET',uyVpTh15EYwCs,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'SHAHID4U-PLAY-3rd')
		eecmFXt5SRyCjGpx = sDQvwGASB0Vf67mik.content
		v2V8Nmrwf4 = trdVA0JvFaD.findall('"servers"(.*?)info-container',eecmFXt5SRyCjGpx,trdVA0JvFaD.DOTALL)
		if v2V8Nmrwf4:
			TfCqlZthRYgzkbE0GO = v2V8Nmrwf4[0]
			yRE17DrswMOxv0Gc9H = trdVA0JvFaD.findall('href="(.*?)".*?<span>(.*?)<.*?</i>.*?<span>(.*?)<',TfCqlZthRYgzkbE0GO,trdVA0JvFaD.DOTALL)
			for llxFwq0CUNgQtivJzkHeGV,title,QS8ZdxkHD5bjU9qsn4zMYaPrg3h7 in yRE17DrswMOxv0Gc9H:
				llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV+'?named='+title+'__download'+'____'+QS8ZdxkHD5bjU9qsn4zMYaPrg3h7
				Dvi8asSrQYX5wE3KMIxT91me.append(llxFwq0CUNgQtivJzkHeGV)
	import oosSOfvdEQ
	oosSOfvdEQ.zfdYjsGLg8M6i15qZWh(Dvi8asSrQYX5wE3KMIxT91me,xjPuFK3EsIZSiobQ5X,'video',url)
	return
def lPwaAjFTMG4n7iSLkXcEuK0Zm(search):
	search,vvKf4sXgZIMyEJPuC,showDialogs = IVTEJQOiMR2dYta9C(search)
	if not search:
		search = TrzfUidpv1LyAYqwexHJDuS()
		if not search: return
	search = search.replace(Mpsm2VF1OBnCRvK3qf6,'+')
	url = Str0BupDTFA+'/search?s='+search
	wg5aF3e8rcDh7SGpW6M1OPnkU(url,'search')
	return
def n92Ia7FtBScTYHrGRhkP5zi(url):
	url = url.split('/smartemadfilter?')[0]
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(DpQifS0oKBI1hYcO,'GET',url,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'SHAHID4U-GET_FILTERS_BLOCKS-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	f5rVHP4bmCd7cqvuYEQJlnLTk6yGRS = []
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('adv-filter(.*?)shows-container',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		f5rVHP4bmCd7cqvuYEQJlnLTk6yGRS = trdVA0JvFaD.findall('''updateQuery\('(.*?)'.*?value.*?>(.*?)<(.*?)</select''',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		dQkYNWtjwfZFvBs9J1Lixe,aGtU0OYsI2puj19dwhFqVDkbS,rqIW37cd0iT1msDzRevOM = zip(*f5rVHP4bmCd7cqvuYEQJlnLTk6yGRS)
		f5rVHP4bmCd7cqvuYEQJlnLTk6yGRS = zip(aGtU0OYsI2puj19dwhFqVDkbS,dQkYNWtjwfZFvBs9J1Lixe,rqIW37cd0iT1msDzRevOM)
	return f5rVHP4bmCd7cqvuYEQJlnLTk6yGRS
def mPVz8jRSf0iHd2FNTswv4O1gy(cok5ZGXdQP7YhwtqyuaCnVevm6UB):
	items = trdVA0JvFaD.findall('value="(.*?)".*?>\s*(.*?)\s*<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	return items
def W6n8HvJog2(url):
	if '/smartemadfilter?' not in url: url = url+'/smartemadfilter?'
	QQUSNlXZ6MEoH1uftykesbKq2 = url.split('/smartemadfilter?')[0]
	cbtS4iE32pOBe5rUxdfIjlXhokKMR = RRNODILCtGzvgpx(url,'url')
	url = url.replace(QQUSNlXZ6MEoH1uftykesbKq2,cbtS4iE32pOBe5rUxdfIjlXhokKMR)
	url = url.replace('/smartemadfilter?','/?')
	return url
eJviUHFbsoM1j7ROT3wklPVu = ['quality','year','genre','category']
VP4sijvgyceqRh = ['category','genre','year']
def hadMgR0nOKHoGqpA(url,filter):
	url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==hWGMqtBy4wuLaVcj: RJGtCsyDgi0X,kYI6n5bUD83Z = hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj
	else: RJGtCsyDgi0X,kYI6n5bUD83Z = filter.split('___')
	if type=='DEFINED_FILTER':
		if VP4sijvgyceqRh[0]+'=' not in RJGtCsyDgi0X: OJx4sYA9nNbtPT5ezmDHdVBk2C7 = VP4sijvgyceqRh[0]
		for PPuqrvDLEViYOMf1dmkK7 in range(len(VP4sijvgyceqRh[0:-1])):
			if VP4sijvgyceqRh[PPuqrvDLEViYOMf1dmkK7]+'=' in RJGtCsyDgi0X: OJx4sYA9nNbtPT5ezmDHdVBk2C7 = VP4sijvgyceqRh[PPuqrvDLEViYOMf1dmkK7+1]
		nnqvmxlXub3iVDM = RJGtCsyDgi0X+'&'+OJx4sYA9nNbtPT5ezmDHdVBk2C7+'=0'
		tuYnONZ6GaCecv4TErUHMdBX2DIb8K = kYI6n5bUD83Z+'&'+OJx4sYA9nNbtPT5ezmDHdVBk2C7+'=0'
		BvO3oKUrHNCwVm791b80sZg = nnqvmxlXub3iVDM.strip('&')+'___'+tuYnONZ6GaCecv4TErUHMdBX2DIb8K.strip('&')
		PPlq1nxLf6CamuBI0psW = kKWuMB69mcOHPn3XilFdvp(kYI6n5bUD83Z,'modified_filters')
		NPM3HKQ57xe = url+'/smartemadfilter?'+PPlq1nxLf6CamuBI0psW
	elif type=='FULL_FILTER':
		I2OnWkrPaVbwBSHiYR3LZ = kKWuMB69mcOHPn3XilFdvp(RJGtCsyDgi0X,'modified_values')
		I2OnWkrPaVbwBSHiYR3LZ = jkiCS0UWs2dNAJcGKn6mbHD(I2OnWkrPaVbwBSHiYR3LZ)
		if kYI6n5bUD83Z!=hWGMqtBy4wuLaVcj: kYI6n5bUD83Z = kKWuMB69mcOHPn3XilFdvp(kYI6n5bUD83Z,'modified_filters')
		if kYI6n5bUD83Z==hWGMqtBy4wuLaVcj: NPM3HKQ57xe = url
		else: NPM3HKQ57xe = url+'/smartemadfilter?'+kYI6n5bUD83Z
		CMzQFXeI08KDwAJ9p = W6n8HvJog2(NPM3HKQ57xe)
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'أظهار قائمة الفيديو التي تم اختيارها ',CMzQFXeI08KDwAJ9p,111)
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+' [[   '+I2OnWkrPaVbwBSHiYR3LZ+'   ]]',CMzQFXeI08KDwAJ9p,111)
		RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	f5rVHP4bmCd7cqvuYEQJlnLTk6yGRS = n92Ia7FtBScTYHrGRhkP5zi(url)
	dict = {}
	for name,bksErtC1hwcVqlfyM82AnD,cok5ZGXdQP7YhwtqyuaCnVevm6UB in f5rVHP4bmCd7cqvuYEQJlnLTk6yGRS:
		name = name.replace('كل ',hWGMqtBy4wuLaVcj)
		items = mPVz8jRSf0iHd2FNTswv4O1gy(cok5ZGXdQP7YhwtqyuaCnVevm6UB)
		if '=' not in NPM3HKQ57xe: NPM3HKQ57xe = url
		if type=='DEFINED_FILTER':
			if OJx4sYA9nNbtPT5ezmDHdVBk2C7!=bksErtC1hwcVqlfyM82AnD: continue
			elif len(items)<2:
				if bksErtC1hwcVqlfyM82AnD==VP4sijvgyceqRh[-1]:
					CMzQFXeI08KDwAJ9p = W6n8HvJog2(NPM3HKQ57xe)
					wg5aF3e8rcDh7SGpW6M1OPnkU(CMzQFXeI08KDwAJ9p)
				else: hadMgR0nOKHoGqpA(NPM3HKQ57xe,'DEFINED_FILTER___'+BvO3oKUrHNCwVm791b80sZg)
				return
			else:
				if bksErtC1hwcVqlfyM82AnD==VP4sijvgyceqRh[-1]:
					CMzQFXeI08KDwAJ9p = W6n8HvJog2(NPM3HKQ57xe)
					RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'الجميع',CMzQFXeI08KDwAJ9p,111)
				else: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'الجميع',NPM3HKQ57xe,115,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,BvO3oKUrHNCwVm791b80sZg)
		elif type=='FULL_FILTER':
			nnqvmxlXub3iVDM = RJGtCsyDgi0X+'&'+bksErtC1hwcVqlfyM82AnD+'=0'
			tuYnONZ6GaCecv4TErUHMdBX2DIb8K = kYI6n5bUD83Z+'&'+bksErtC1hwcVqlfyM82AnD+'=0'
			BvO3oKUrHNCwVm791b80sZg = nnqvmxlXub3iVDM+'___'+tuYnONZ6GaCecv4TErUHMdBX2DIb8K
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'الجميع :'+name,NPM3HKQ57xe,114,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,BvO3oKUrHNCwVm791b80sZg)
		dict[bksErtC1hwcVqlfyM82AnD] = {}
		for BoSjXKxz41DcneO9UimClE,PBo1KkyMCgH8eNDaLtZVcr3EnIi2 in items:
			if BoSjXKxz41DcneO9UimClE=='196533': PBo1KkyMCgH8eNDaLtZVcr3EnIi2 = 'أفلام نيتفلكس'
			elif BoSjXKxz41DcneO9UimClE=='196531': PBo1KkyMCgH8eNDaLtZVcr3EnIi2 = 'مسلسلات نيتفلكس'
			if PBo1KkyMCgH8eNDaLtZVcr3EnIi2 in P3UK1Rr4IdYe5: continue
			dict[bksErtC1hwcVqlfyM82AnD][BoSjXKxz41DcneO9UimClE] = PBo1KkyMCgH8eNDaLtZVcr3EnIi2
			nnqvmxlXub3iVDM = RJGtCsyDgi0X+'&'+bksErtC1hwcVqlfyM82AnD+'='+PBo1KkyMCgH8eNDaLtZVcr3EnIi2
			tuYnONZ6GaCecv4TErUHMdBX2DIb8K = kYI6n5bUD83Z+'&'+bksErtC1hwcVqlfyM82AnD+'='+BoSjXKxz41DcneO9UimClE
			S80DwNWuMTZx4El = nnqvmxlXub3iVDM+'___'+tuYnONZ6GaCecv4TErUHMdBX2DIb8K
			title = PBo1KkyMCgH8eNDaLtZVcr3EnIi2+' :'#+dict[bksErtC1hwcVqlfyM82AnD]['0']
			title = PBo1KkyMCgH8eNDaLtZVcr3EnIi2+' :'+name
			if type=='FULL_FILTER': RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,url,114,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,S80DwNWuMTZx4El)
			elif type=='DEFINED_FILTER' and VP4sijvgyceqRh[-2]+'=' in RJGtCsyDgi0X:
				PPlq1nxLf6CamuBI0psW = kKWuMB69mcOHPn3XilFdvp(tuYnONZ6GaCecv4TErUHMdBX2DIb8K,'modified_filters')
				NPM3HKQ57xe = url+'/smartemadfilter?'+PPlq1nxLf6CamuBI0psW
				CMzQFXeI08KDwAJ9p = W6n8HvJog2(NPM3HKQ57xe)
				RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,CMzQFXeI08KDwAJ9p,111)
			else: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,url,115,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,S80DwNWuMTZx4El)
	return
def kKWuMB69mcOHPn3XilFdvp(UGewLrVFhBCo7MdZ8KEaJWXgYp,mode):
	UGewLrVFhBCo7MdZ8KEaJWXgYp = UGewLrVFhBCo7MdZ8KEaJWXgYp.replace('=&','=0&')
	UGewLrVFhBCo7MdZ8KEaJWXgYp = UGewLrVFhBCo7MdZ8KEaJWXgYp.strip('&')
	ONVGLC8DSp4 = {}
	if '=' in UGewLrVFhBCo7MdZ8KEaJWXgYp:
		items = UGewLrVFhBCo7MdZ8KEaJWXgYp.split('&')
		for ImYg2jxU6Lc9Q1C4Oko in items:
			glBvuIRTJseUHjari,BoSjXKxz41DcneO9UimClE = ImYg2jxU6Lc9Q1C4Oko.split('=')
			ONVGLC8DSp4[glBvuIRTJseUHjari] = BoSjXKxz41DcneO9UimClE
	mJuhvt0RPAbBMSla = hWGMqtBy4wuLaVcj
	for key in eJviUHFbsoM1j7ROT3wklPVu:
		if key in list(ONVGLC8DSp4.keys()): BoSjXKxz41DcneO9UimClE = ONVGLC8DSp4[key]
		else: BoSjXKxz41DcneO9UimClE = '0'
		if '%' not in BoSjXKxz41DcneO9UimClE: BoSjXKxz41DcneO9UimClE = e1mT8H4dGS3XFyx0KLUA9(BoSjXKxz41DcneO9UimClE)
		if mode=='modified_values' and BoSjXKxz41DcneO9UimClE!='0': mJuhvt0RPAbBMSla = mJuhvt0RPAbBMSla+' + '+BoSjXKxz41DcneO9UimClE
		elif mode=='modified_filters' and BoSjXKxz41DcneO9UimClE!='0': mJuhvt0RPAbBMSla = mJuhvt0RPAbBMSla+'&'+key+'='+BoSjXKxz41DcneO9UimClE
		elif mode=='all': mJuhvt0RPAbBMSla = mJuhvt0RPAbBMSla+'&'+key+'='+BoSjXKxz41DcneO9UimClE
	mJuhvt0RPAbBMSla = mJuhvt0RPAbBMSla.strip(' + ')
	mJuhvt0RPAbBMSla = mJuhvt0RPAbBMSla.strip('&')
	mJuhvt0RPAbBMSla = mJuhvt0RPAbBMSla.replace('=0','=')
	return mJuhvt0RPAbBMSla
# -*- coding: utf-8 -*-
from yoY3NdGViS import *
xjPuFK3EsIZSiobQ5X = 'DRAMAS7'
n0qFKQWhiBYXoTrvejVHUA4 = '_DR7_'
Str0BupDTFA = u6rbxnyjTl7I[xjPuFK3EsIZSiobQ5X][0]
P3UK1Rr4IdYe5 = ['الصفحة الرئيسية','Sign in','تسجيل']
def ehB18u9sQFRi(mode,url,text):
	if   mode==680: N6NCYivtV4I5rEXq = DP6FSBgNdX1rsvVR()
	elif mode==681: N6NCYivtV4I5rEXq = wg5aF3e8rcDh7SGpW6M1OPnkU(url,text)
	elif mode==682: N6NCYivtV4I5rEXq = oanus6TxUFNAhSZKpJdYlEC4mV(url)
	elif mode==683: N6NCYivtV4I5rEXq = R4i0moBGrAfhaZ3(url,text)
	elif mode==684: N6NCYivtV4I5rEXq = qt2zjyIbsS(url)
	elif mode==689: N6NCYivtV4I5rEXq = lPwaAjFTMG4n7iSLkXcEuK0Zm(text)
	else: N6NCYivtV4I5rEXq = False
	return N6NCYivtV4I5rEXq
def DP6FSBgNdX1rsvVR():
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',Str0BupDTFA,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'DRAMAS7-MENU-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'بحث في الموقع',hWGMqtBy4wuLaVcj,689,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'_REMEMBERRESULTS_')
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+'المميزة',Str0BupDTFA,681,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'featured')
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('/category.php">(.*?)"navslide-divider"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall("'dropdown-menu'(.*?)</ul>",mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	for TfCqlZthRYgzkbE0GO in DJvksH7ZAFUqW9OyQnbGjPCtwR1o: cok5ZGXdQP7YhwtqyuaCnVevm6UB = cok5ZGXdQP7YhwtqyuaCnVevm6UB.replace(TfCqlZthRYgzkbE0GO,hWGMqtBy4wuLaVcj)
	items = trdVA0JvFaD.findall('href="(.*?)".*?>(.*?)</a>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	for llxFwq0CUNgQtivJzkHeGV,title in items:
		if title in P3UK1Rr4IdYe5: continue
		if title=='جديد الأفلام': title = 'المضاف حديثا'
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,684)
	return
def qt2zjyIbsS(url):
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'DRAMAS7-SUBMENU-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	cLV4wifngjAdbePKq2x7SDhXGYlO0 = trdVA0JvFaD.findall('"caret"(.*?)</ul>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if cLV4wifngjAdbePKq2x7SDhXGYlO0:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = cLV4wifngjAdbePKq2x7SDhXGYlO0[0]
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = cok5ZGXdQP7YhwtqyuaCnVevm6UB.replace('"presentation"','</ul>')
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		if not DJvksH7ZAFUqW9OyQnbGjPCtwR1o: DJvksH7ZAFUqW9OyQnbGjPCtwR1o = [(hWGMqtBy4wuLaVcj,cok5ZGXdQP7YhwtqyuaCnVevm6UB)]
		RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' فرز أو فلتر أو ترتيب '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
		for HoEKsq4QNVuCc8xdeMam0,cok5ZGXdQP7YhwtqyuaCnVevm6UB in DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
			items = trdVA0JvFaD.findall('href="(.*?)".*?>(.*?)</a>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
			if HoEKsq4QNVuCc8xdeMam0: HoEKsq4QNVuCc8xdeMam0 = HoEKsq4QNVuCc8xdeMam0+': '
			for llxFwq0CUNgQtivJzkHeGV,title in items:
				title = HoEKsq4QNVuCc8xdeMam0+title
				RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,681)
	v2V8Nmrwf4 = trdVA0JvFaD.findall('"pm-category-subcats"(.*?)</ul>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if v2V8Nmrwf4:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = v2V8Nmrwf4[0]
		items = trdVA0JvFaD.findall('href="(.*?)">(.*?)</a>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		if len(items)<30:
			RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
			for llxFwq0CUNgQtivJzkHeGV,title in items:
				RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,681)
	if not cLV4wifngjAdbePKq2x7SDhXGYlO0 and not v2V8Nmrwf4: wg5aF3e8rcDh7SGpW6M1OPnkU(url)
	return
def wg5aF3e8rcDh7SGpW6M1OPnkU(url,s4mUPzjv1bRoNTMdenkuBgYl=hWGMqtBy4wuLaVcj):
	if s4mUPzjv1bRoNTMdenkuBgYl=='ajax-search':
		url,search = url.split('?',1)
		data = 'queryString='+search
		headers = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'POST',url,data,headers,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'DRAMAS7-TITLES-1st')
	else:
		sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'DRAMAS7-TITLES-2nd')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	cok5ZGXdQP7YhwtqyuaCnVevm6UB,items = hWGMqtBy4wuLaVcj,[]
	cbYKa2SXGwRCiQIW5NeosU9k = RRNODILCtGzvgpx(url,'url')
	if s4mUPzjv1bRoNTMdenkuBgYl=='ajax-search':
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = mMQ3FkNVa4IlxqY
		yRE17DrswMOxv0Gc9H = trdVA0JvFaD.findall('href="(.*?)">(.*?)</a>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,title in yRE17DrswMOxv0Gc9H: items.append((hWGMqtBy4wuLaVcj,llxFwq0CUNgQtivJzkHeGV,title))
	elif s4mUPzjv1bRoNTMdenkuBgYl=='featured':
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('id="featured"(.*?)</ul>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
			cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
			if cok5ZGXdQP7YhwtqyuaCnVevm6UB:
				items = trdVA0JvFaD.findall('''href="(.*?)" title="(.*?)".*?:url\(\'(.*?)\'''',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
				m4IznKilUOByHweG68VJ,LHN1Zr7FDtbYfjz069Gnh,cpe36NzrSZEWbUyIjPsB = zip(*items)
				items = zip(cpe36NzrSZEWbUyIjPsB,m4IznKilUOByHweG68VJ,LHN1Zr7FDtbYfjz069Gnh)
	elif s4mUPzjv1bRoNTMdenkuBgYl=='new_episodes':
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('"row pm-ul-browse-videos(.*?)</ul>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if DJvksH7ZAFUqW9OyQnbGjPCtwR1o: cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
	elif s4mUPzjv1bRoNTMdenkuBgYl=='new_movies':
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('"row pm-ul-browse-videos(.*?)</ul>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if len(DJvksH7ZAFUqW9OyQnbGjPCtwR1o)>1: cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[1]
	elif s4mUPzjv1bRoNTMdenkuBgYl=='featured_series':
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('"home-series-list"(.*?)</div>[\t|\n]*</div>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if DJvksH7ZAFUqW9OyQnbGjPCtwR1o: cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		yRE17DrswMOxv0Gc9H = trdVA0JvFaD.findall('href="(.*?)">(.*?)</a>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,title in yRE17DrswMOxv0Gc9H: items.append((hWGMqtBy4wuLaVcj,llxFwq0CUNgQtivJzkHeGV,title))
	else:
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('(data-echo=".*?)</ul>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if DJvksH7ZAFUqW9OyQnbGjPCtwR1o: cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
	if cok5ZGXdQP7YhwtqyuaCnVevm6UB and not items: items = trdVA0JvFaD.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	if not items: return
	REbVyXis1w4Ae = []
	nNBCdTs98RztMyODHpL63ZUKm4P = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,llxFwq0CUNgQtivJzkHeGV,title in items:
		IIsmGy4pd7 = trdVA0JvFaD.findall('(.*?) (الحلقة|حلقة).\d+',title,trdVA0JvFaD.DOTALL)
		if any(BoSjXKxz41DcneO9UimClE in title for BoSjXKxz41DcneO9UimClE in nNBCdTs98RztMyODHpL63ZUKm4P):
			RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,682,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
		elif s4mUPzjv1bRoNTMdenkuBgYl=='new_episodes':
			RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,682,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
		elif IIsmGy4pd7:
			title = '_MOD_' + IIsmGy4pd7[0][0]
			if title not in REbVyXis1w4Ae:
				RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,683,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
				REbVyXis1w4Ae.append(title)
		else: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,683,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
	if 1:
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('"pagination(.*?)</ul>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
			cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
			items = trdVA0JvFaD.findall('href="(.*?)".*?>(.*?)</a>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
			for llxFwq0CUNgQtivJzkHeGV,title in items:
				if llxFwq0CUNgQtivJzkHeGV=='#': continue
				llxFwq0CUNgQtivJzkHeGV = cbYKa2SXGwRCiQIW5NeosU9k+'/'+llxFwq0CUNgQtivJzkHeGV.strip('/')
				title = LNtIDdBA52P(title)
				RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'صفحة '+title,llxFwq0CUNgQtivJzkHeGV,681)
	return
def R4i0moBGrAfhaZ3(url,dp9XPV1Au6EWCJyiGw):
	cbYKa2SXGwRCiQIW5NeosU9k = RRNODILCtGzvgpx(url,'url')
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'DRAMAS7-EPISODES-2nd')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	cLV4wifngjAdbePKq2x7SDhXGYlO0 = trdVA0JvFaD.findall('"SeasonsBox"(.*?)"SeasonsEpisodesMain',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	nWE8aO53lFfD = trdVA0JvFaD.findall('"series-header".*?src="(.*?)"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if nWE8aO53lFfD: Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG = nWE8aO53lFfD[0]
	else: Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG = hWGMqtBy4wuLaVcj
	items = []
	PPOKIaMHbQ6CxFqkZSdi53 = False
	if cLV4wifngjAdbePKq2x7SDhXGYlO0 and not dp9XPV1Au6EWCJyiGw:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = cLV4wifngjAdbePKq2x7SDhXGYlO0[0]
		items = trdVA0JvFaD.findall('''onclick="openCity\(event, '(.*?)'\)">(.*?)</button>''',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for dp9XPV1Au6EWCJyiGw,title in items:
			dp9XPV1Au6EWCJyiGw = dp9XPV1Au6EWCJyiGw.strip('#')
			if len(items)>1: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,url,683,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,hWGMqtBy4wuLaVcj,dp9XPV1Au6EWCJyiGw)
			else: PPOKIaMHbQ6CxFqkZSdi53 = True
	else: PPOKIaMHbQ6CxFqkZSdi53 = True
	v2V8Nmrwf4 = trdVA0JvFaD.findall('id="'+dp9XPV1Au6EWCJyiGw+'"(.*?)</ul>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if v2V8Nmrwf4 and PPOKIaMHbQ6CxFqkZSdi53:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = v2V8Nmrwf4[0]
		yRE17DrswMOxv0Gc9H = trdVA0JvFaD.findall('title="(.*?)" href="(.*?)"',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		items = []
		for title,llxFwq0CUNgQtivJzkHeGV in yRE17DrswMOxv0Gc9H: items.append((llxFwq0CUNgQtivJzkHeGV,title,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG))
		if not items: items = trdVA0JvFaD.findall('"thumbnail".*?href="(.*?)" title="(.*?)".*?src="(.*?)"',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,title,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG in items:
			llxFwq0CUNgQtivJzkHeGV = cbYKa2SXGwRCiQIW5NeosU9k+'/'+llxFwq0CUNgQtivJzkHeGV.strip('/')
			title = title.replace('</em><span>',Mpsm2VF1OBnCRvK3qf6)
			RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,682,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
	return
def oanus6TxUFNAhSZKpJdYlEC4mV(url):
	zmDKurMJwj6fi,RhxlHcOYSUGBnqM9p8mAIzF23 = [],[]
	NPM3HKQ57xe = url.replace('watch.php','play.php')
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',NPM3HKQ57xe,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'DRAMAS7-PLAY-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('"WatchList"(.*?)</ul>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('embed-url="(.*?)".*?<strong>(.*?)</strong>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,title in items:
			if llxFwq0CUNgQtivJzkHeGV not in RhxlHcOYSUGBnqM9p8mAIzF23:
				RhxlHcOYSUGBnqM9p8mAIzF23.append(llxFwq0CUNgQtivJzkHeGV)
				SODQ7qlNYoZcFK8e50rBsJaAHxiXjE = RRNODILCtGzvgpx(llxFwq0CUNgQtivJzkHeGV,'name')
				llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV+'?named='+SODQ7qlNYoZcFK8e50rBsJaAHxiXjE+'__watch'
				zmDKurMJwj6fi.append(llxFwq0CUNgQtivJzkHeGV)
	llxFwq0CUNgQtivJzkHeGV = trdVA0JvFaD.findall('<iframe src="(.*?)"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if llxFwq0CUNgQtivJzkHeGV:
		llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV[0]
		if llxFwq0CUNgQtivJzkHeGV not in RhxlHcOYSUGBnqM9p8mAIzF23:
			RhxlHcOYSUGBnqM9p8mAIzF23.append(llxFwq0CUNgQtivJzkHeGV)
			SODQ7qlNYoZcFK8e50rBsJaAHxiXjE = RRNODILCtGzvgpx(llxFwq0CUNgQtivJzkHeGV,'name')
			llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV+'?named='+SODQ7qlNYoZcFK8e50rBsJaAHxiXjE+'__embed'
			zmDKurMJwj6fi.append(llxFwq0CUNgQtivJzkHeGV)
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('"downloadlist"(.*?)</ul>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('download-url="(.*?)".*?<strong>(.*?)</strong>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,title in items:
			if llxFwq0CUNgQtivJzkHeGV not in RhxlHcOYSUGBnqM9p8mAIzF23:
				RhxlHcOYSUGBnqM9p8mAIzF23.append(llxFwq0CUNgQtivJzkHeGV)
				SODQ7qlNYoZcFK8e50rBsJaAHxiXjE = RRNODILCtGzvgpx(llxFwq0CUNgQtivJzkHeGV,'name')
				llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV+'?named='+SODQ7qlNYoZcFK8e50rBsJaAHxiXjE+'__download'
				zmDKurMJwj6fi.append(llxFwq0CUNgQtivJzkHeGV)
	import oosSOfvdEQ
	oosSOfvdEQ.zfdYjsGLg8M6i15qZWh(zmDKurMJwj6fi,xjPuFK3EsIZSiobQ5X,'video',url)
	return
def lPwaAjFTMG4n7iSLkXcEuK0Zm(search):
	search,vvKf4sXgZIMyEJPuC,showDialogs = IVTEJQOiMR2dYta9C(search)
	if search==hWGMqtBy4wuLaVcj: search = TrzfUidpv1LyAYqwexHJDuS()
	if search==hWGMqtBy4wuLaVcj: return
	search = search.replace(Mpsm2VF1OBnCRvK3qf6,'+')
	url = Str0BupDTFA+'/search.php?keywords='+search
	wg5aF3e8rcDh7SGpW6M1OPnkU(url,'search')
	return
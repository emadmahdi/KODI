﻿# -*- coding: utf-8 -*-
from yoY3NdGViS import *
xjPuFK3EsIZSiobQ5X = 'ALMAAREF'
headers = {'User-Agent':hWGMqtBy4wuLaVcj}
n0qFKQWhiBYXoTrvejVHUA4 = '_MRF_'
Str0BupDTFA = u6rbxnyjTl7I[xjPuFK3EsIZSiobQ5X][0]
P3UK1Rr4IdYe5 = ['التواصل الاجتماعي','صور التواصل الاجتماعي','أرشيف جميع البرامج']
def ehB18u9sQFRi(mode,url,text,l7COkhRWD9uVS60Pte2NoyAaZn):
	if   mode==40: N6NCYivtV4I5rEXq = DP6FSBgNdX1rsvVR()
	elif mode==41: N6NCYivtV4I5rEXq = wUOB4TVkC1X2hesdItWFf()
	elif mode==42: N6NCYivtV4I5rEXq = AMNiIBWsrftoVJ5Xpz7KU0d(text,l7COkhRWD9uVS60Pte2NoyAaZn)
	elif mode==43: N6NCYivtV4I5rEXq = oanus6TxUFNAhSZKpJdYlEC4mV(url)
	elif mode==44: N6NCYivtV4I5rEXq = wg5aF3e8rcDh7SGpW6M1OPnkU(text,l7COkhRWD9uVS60Pte2NoyAaZn)
	elif mode==49: N6NCYivtV4I5rEXq = lPwaAjFTMG4n7iSLkXcEuK0Zm(text)
	else: N6NCYivtV4I5rEXq = False
	return N6NCYivtV4I5rEXq
def DP6FSBgNdX1rsvVR():
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'بحث في الموقع',hWGMqtBy4wuLaVcj,49)
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	RLDCGt8kq3OVmnzgx1rbi2f7F('live',n0qFKQWhiBYXoTrvejVHUA4+'البث الحي لقناة المعارف',hWGMqtBy4wuLaVcj,41)
	AMNiIBWsrftoVJ5Xpz7KU0d(hWGMqtBy4wuLaVcj,'1')
	return
def xqfoZ2ESrBn6Xk(vvKf4sXgZIMyEJPuC,SZUbIPaqGEQNz5Dwdu3tMvp):
	search,sort,TT1pO8cio5xCnQufKGHv,OJx4sYA9nNbtPT5ezmDHdVBk2C7,pXFLybUjhgv = hWGMqtBy4wuLaVcj,[],[],[],[]
	QwGpLVOkc0MPodWfiYsTj,PK0qlwJNfHTczX = fWM9y4vTcPLS0b3UKItC1os5(vvKf4sXgZIMyEJPuC)
	for PBo1KkyMCgH8eNDaLtZVcr3EnIi2 in list(PK0qlwJNfHTczX.keys()):
		BoSjXKxz41DcneO9UimClE = PK0qlwJNfHTczX[PBo1KkyMCgH8eNDaLtZVcr3EnIi2]
		if not BoSjXKxz41DcneO9UimClE: continue
		if   PBo1KkyMCgH8eNDaLtZVcr3EnIi2=='sort': sort = [BoSjXKxz41DcneO9UimClE]
		elif PBo1KkyMCgH8eNDaLtZVcr3EnIi2=='series': TT1pO8cio5xCnQufKGHv = [BoSjXKxz41DcneO9UimClE]
		elif PBo1KkyMCgH8eNDaLtZVcr3EnIi2=='search': search = BoSjXKxz41DcneO9UimClE
		elif PBo1KkyMCgH8eNDaLtZVcr3EnIi2=='category': OJx4sYA9nNbtPT5ezmDHdVBk2C7 = [BoSjXKxz41DcneO9UimClE]
		elif PBo1KkyMCgH8eNDaLtZVcr3EnIi2=='specialist': pXFLybUjhgv = [BoSjXKxz41DcneO9UimClE]
	l17Sn3hK59WV = {"action":"facetwp_refresh","data":{"facets":{"search":search,"video_categories":OJx4sYA9nNbtPT5ezmDHdVBk2C7,"specialist":pXFLybUjhgv,"series":TT1pO8cio5xCnQufKGHv,"number":[],"sort_video":sort,"count":[],"pagination":[]},"frozen_facets":{},"template":"video_desktop_posts","extras":{"sort":"default"},"soft_refresh":0,"is_bfcache":1,"first_load":0,"paged":int(SZUbIPaqGEQNz5Dwdu3tMvp)}}
	l17Sn3hK59WV = TPDQ5L9eWpIJcrM3YH48Cs6.dumps(l17Sn3hK59WV)
	llxFwq0CUNgQtivJzkHeGV = 'https://almaaref.ch/wp-json/facetwp/v1/refresh'
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'POST',llxFwq0CUNgQtivJzkHeGV,l17Sn3hK59WV,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'ALMAAREF-REQUEST_DATA_PAGE-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	data = Cy9ow3c21nABMjzqeaIT('dict',mMQ3FkNVa4IlxqY)
	return data
def AMNiIBWsrftoVJ5Xpz7KU0d(vvKf4sXgZIMyEJPuC,level):
	rqIW37cd0iT1msDzRevOM = xqfoZ2ESrBn6Xk(vvKf4sXgZIMyEJPuC,'1')
	cok5ZGXdQP7YhwtqyuaCnVevm6UB = rqIW37cd0iT1msDzRevOM['facets']
	if level=='1':
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = cok5ZGXdQP7YhwtqyuaCnVevm6UB['video_categories']
		items = trdVA0JvFaD.findall('<div(.*?)/div>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for ImYg2jxU6Lc9Q1C4Oko in items:
			p05pq1QcdOZrzXMJs3I7VTUjEHxKa = trdVA0JvFaD.findall('data-value=\\"(.*?)\\".*?display-value\\">(.*?)<',ImYg2jxU6Lc9Q1C4Oko+'<',trdVA0JvFaD.DOTALL)
			if not p05pq1QcdOZrzXMJs3I7VTUjEHxKa: p05pq1QcdOZrzXMJs3I7VTUjEHxKa = trdVA0JvFaD.findall('data-value=\\"(.*?)\\">(.*?)<',ImYg2jxU6Lc9Q1C4Oko+'<',trdVA0JvFaD.DOTALL)
			OJx4sYA9nNbtPT5ezmDHdVBk2C7,title = p05pq1QcdOZrzXMJs3I7VTUjEHxKa[0]
			if VKiGj1LundAJQwEXcqgxC: title = emr1Lf523Ti0OtcNgxP(title)
			if not vvKf4sXgZIMyEJPuC: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+title,hWGMqtBy4wuLaVcj,42,hWGMqtBy4wuLaVcj,'2','?category='+OJx4sYA9nNbtPT5ezmDHdVBk2C7)
			else: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,hWGMqtBy4wuLaVcj,42,hWGMqtBy4wuLaVcj,'2',vvKf4sXgZIMyEJPuC+'&category='+OJx4sYA9nNbtPT5ezmDHdVBk2C7)
	if level=='2':
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = cok5ZGXdQP7YhwtqyuaCnVevm6UB['specialist']
		items = trdVA0JvFaD.findall('value="(.*?)".*?>(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for pXFLybUjhgv,title in items:
			if VKiGj1LundAJQwEXcqgxC: title = emr1Lf523Ti0OtcNgxP(title)
			if not pXFLybUjhgv: title = title = 'الجميع'
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,hWGMqtBy4wuLaVcj,42,hWGMqtBy4wuLaVcj,'3',vvKf4sXgZIMyEJPuC+'&specialist='+pXFLybUjhgv)
	elif level=='3':
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = cok5ZGXdQP7YhwtqyuaCnVevm6UB['series']
		items = trdVA0JvFaD.findall('value="(.*?)".*?>(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for TT1pO8cio5xCnQufKGHv,title in items:
			if VKiGj1LundAJQwEXcqgxC: title = emr1Lf523Ti0OtcNgxP(title)
			if not TT1pO8cio5xCnQufKGHv: title = title = 'الجميع'
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,hWGMqtBy4wuLaVcj,42,hWGMqtBy4wuLaVcj,'4',vvKf4sXgZIMyEJPuC+'&series='+TT1pO8cio5xCnQufKGHv)
	elif level=='4':
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = cok5ZGXdQP7YhwtqyuaCnVevm6UB['sort_video']
		items = trdVA0JvFaD.findall('value="(.*?)".*?>(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for sort,title in items:
			if not sort: continue
			if VKiGj1LundAJQwEXcqgxC: title = emr1Lf523Ti0OtcNgxP(title)
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,hWGMqtBy4wuLaVcj,44,hWGMqtBy4wuLaVcj,'1',vvKf4sXgZIMyEJPuC+'&sort='+sort)
	return
def wg5aF3e8rcDh7SGpW6M1OPnkU(vvKf4sXgZIMyEJPuC,SZUbIPaqGEQNz5Dwdu3tMvp):
	rqIW37cd0iT1msDzRevOM = xqfoZ2ESrBn6Xk(vvKf4sXgZIMyEJPuC,SZUbIPaqGEQNz5Dwdu3tMvp)
	cok5ZGXdQP7YhwtqyuaCnVevm6UB = rqIW37cd0iT1msDzRevOM['template']
	items = trdVA0JvFaD.findall('src="(.*?)".*?href="(.*?)">(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	for Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,llxFwq0CUNgQtivJzkHeGV,title in items:
		if VKiGj1LundAJQwEXcqgxC: title = emr1Lf523Ti0OtcNgxP(title)
		RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,43,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
	cok5ZGXdQP7YhwtqyuaCnVevm6UB = rqIW37cd0iT1msDzRevOM['facets']['pagination']
	items = trdVA0JvFaD.findall('data-page="(.*?)">(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	for l7COkhRWD9uVS60Pte2NoyAaZn,title in items:
		if SZUbIPaqGEQNz5Dwdu3tMvp==l7COkhRWD9uVS60Pte2NoyAaZn: continue
		if VKiGj1LundAJQwEXcqgxC: title = emr1Lf523Ti0OtcNgxP(title)
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'صفحة '+title,hWGMqtBy4wuLaVcj,44,hWGMqtBy4wuLaVcj,l7COkhRWD9uVS60Pte2NoyAaZn,vvKf4sXgZIMyEJPuC)
	return
def oanus6TxUFNAhSZKpJdYlEC4mV(url):
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'ALMAAREF-PLAY-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	llxFwq0CUNgQtivJzkHeGV = trdVA0JvFaD.findall('<video src="(.*?)"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if not llxFwq0CUNgQtivJzkHeGV: llxFwq0CUNgQtivJzkHeGV = trdVA0JvFaD.findall('youtube_url.*?(http.*?)&',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	zmDKurMJwj6fi = []
	if llxFwq0CUNgQtivJzkHeGV:
		llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV[0].replace('\/','/')
		zmDKurMJwj6fi.append(llxFwq0CUNgQtivJzkHeGV)
	import oosSOfvdEQ
	oosSOfvdEQ.zfdYjsGLg8M6i15qZWh(zmDKurMJwj6fi,xjPuFK3EsIZSiobQ5X,'video',url)
	return
def wUOB4TVkC1X2hesdItWFf():
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(DpQifS0oKBI1hYcO,'GET',Str0BupDTFA+'/بث-مباشر',hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'ALMAAREF-LIVE-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	url = trdVA0JvFaD.findall('"svpPlayer".*?(http.*?)&',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	url = url[0].replace('\\',hWGMqtBy4wuLaVcj)
	vOq38Y4XVZwdE(url,xjPuFK3EsIZSiobQ5X,'live')
	return
def lPwaAjFTMG4n7iSLkXcEuK0Zm(search):
	search,vvKf4sXgZIMyEJPuC,showDialogs = IVTEJQOiMR2dYta9C(search)
	m2MrveXLigyq = False
	if search==hWGMqtBy4wuLaVcj:
		search = TrzfUidpv1LyAYqwexHJDuS()
		m2MrveXLigyq = True
	if search==hWGMqtBy4wuLaVcj: return
	if not m2MrveXLigyq: wg5aF3e8rcDh7SGpW6M1OPnkU('?search='+search,'1')
	else: AMNiIBWsrftoVJ5Xpz7KU0d('?search='+search,'1')
	return
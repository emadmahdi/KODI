# -*- coding: utf-8 -*-
from yoY3NdGViS import *
xjPuFK3EsIZSiobQ5X = 'SHIAVOICE'
n0qFKQWhiBYXoTrvejVHUA4 = '_SHV_'
Str0BupDTFA = u6rbxnyjTl7I[xjPuFK3EsIZSiobQ5X][0]
headers = {'User-Agent':None}
def ehB18u9sQFRi(mode,url,text):
	if   mode==310: N6NCYivtV4I5rEXq = DP6FSBgNdX1rsvVR()
	elif mode==311: N6NCYivtV4I5rEXq = wg5aF3e8rcDh7SGpW6M1OPnkU(url)
	elif mode==312: N6NCYivtV4I5rEXq = oanus6TxUFNAhSZKpJdYlEC4mV(url)
	elif mode==313: N6NCYivtV4I5rEXq = zXmuO0xpS8PQ3VwqEcH(url)
	elif mode==314: N6NCYivtV4I5rEXq = Z5sr7Hb9NXJKVG(text)
	elif mode==319: N6NCYivtV4I5rEXq = lPwaAjFTMG4n7iSLkXcEuK0Zm(text)
	else: N6NCYivtV4I5rEXq = False
	return N6NCYivtV4I5rEXq
def DP6FSBgNdX1rsvVR():
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'بحث في الموقع',hWGMqtBy4wuLaVcj,319,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'_REMEMBERRESULTS_')
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(DpQifS0oKBI1hYcO,'GET',Str0BupDTFA,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'SHIAVOICE-MENU-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('id="menulinks"(.*?)</ul>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	items = trdVA0JvFaD.findall('<h5>(.*?)</h5>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL|trdVA0JvFaD.IGNORECASE)
	for XK2iWMx6yfU9E in range(len(items)):
		title = items[XK2iWMx6yfU9E].strip(Mpsm2VF1OBnCRvK3qf6)
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+title,Str0BupDTFA,314,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,str(XK2iWMx6yfU9E+1))
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+'مقاطع شهر',Str0BupDTFA,314,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'0')
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	items = trdVA0JvFaD.findall('href="(.*?)".*?<B>(.*?)</B>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	for llxFwq0CUNgQtivJzkHeGV,title in items:
		llxFwq0CUNgQtivJzkHeGV = Str0BupDTFA+'/'+llxFwq0CUNgQtivJzkHeGV
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,311)
	return mMQ3FkNVa4IlxqY
def Z5sr7Hb9NXJKVG(XK2iWMx6yfU9E):
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(nHBb7jXk0Daom,'GET',Str0BupDTFA,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'SHIAVOICE-LATEST-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	if XK2iWMx6yfU9E=='0':
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('class="tab-content"(.*?)</table>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('href="(.*?)".*?title="(.*?)".*?</i>(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,name,title in items:
			llxFwq0CUNgQtivJzkHeGV = Str0BupDTFA+'/'+llxFwq0CUNgQtivJzkHeGV
			title = title.strip(Mpsm2VF1OBnCRvK3qf6)
			name = name.strip(Mpsm2VF1OBnCRvK3qf6)
			title = title+' ('+name+')'
			RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,312)
	elif XK2iWMx6yfU9E in ['1','2','3']:
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('(<h5>.*?)<div class="col-lg',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		FmxdhaQRgz2pe = int(XK2iWMx6yfU9E)-1
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[FmxdhaQRgz2pe]
		if XK2iWMx6yfU9E=='1': items = trdVA0JvFaD.findall('href="(.*?)".*?src="(.*?)".*?<strong>(.*?)<.*?</i>(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		else: items = trdVA0JvFaD.findall('href="(.*?)".*?src="(.*?)".*?<strong>(.*?)<.*?href=".*?">(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,title,name in items:
			Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG = Str0BupDTFA+'/'+Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG
			llxFwq0CUNgQtivJzkHeGV = Str0BupDTFA+'/'+llxFwq0CUNgQtivJzkHeGV
			title = title.strip(Mpsm2VF1OBnCRvK3qf6)
			name = name.strip(Mpsm2VF1OBnCRvK3qf6)
			title = title+' ('+name+')'
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,311,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
	elif XK2iWMx6yfU9E in ['4','5','6']:
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('(<h5>.*?)</table>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		XK2iWMx6yfU9E = int(XK2iWMx6yfU9E)-4
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[XK2iWMx6yfU9E]
		items = trdVA0JvFaD.findall('src="(.*?)".*?href="(.*?)".*?title="(.*?)".*?<strong.*?>(.*?)</strong>.*?-cell">(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,llxFwq0CUNgQtivJzkHeGV,Ao8udjwfk3YgC2m,title,u25Car4veWZpIhniLSUKqH83Gf in items:
			Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG = Str0BupDTFA+'/'+Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG
			llxFwq0CUNgQtivJzkHeGV = Str0BupDTFA+'/'+llxFwq0CUNgQtivJzkHeGV
			title = title.strip(Mpsm2VF1OBnCRvK3qf6)
			Ao8udjwfk3YgC2m = Ao8udjwfk3YgC2m.strip(Mpsm2VF1OBnCRvK3qf6)
			u25Car4veWZpIhniLSUKqH83Gf = u25Car4veWZpIhniLSUKqH83Gf.strip(Mpsm2VF1OBnCRvK3qf6)
			if Ao8udjwfk3YgC2m: name = Ao8udjwfk3YgC2m
			else: name = u25Car4veWZpIhniLSUKqH83Gf
			title = title+' ('+name+')'
			RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,312,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
	return
def wg5aF3e8rcDh7SGpW6M1OPnkU(url):
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'SHIAVOICE-TITLES-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('ibox-heading"(.*?)class="float-right',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
	if 'catsum-mobile' in cok5ZGXdQP7YhwtqyuaCnVevm6UB:
		items = trdVA0JvFaD.findall('src="(.*?)".*?href="(.*?)".*?<strong>(.*?)</strong>.*?catsum-mobile">(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		if items:
			for Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,llxFwq0CUNgQtivJzkHeGV,title,count in items:
				Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG = Str0BupDTFA+'/'+Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG
				llxFwq0CUNgQtivJzkHeGV = Str0BupDTFA+'/'+llxFwq0CUNgQtivJzkHeGV
				count = count.replace(' الصوتية: ',':')
				title = title.strip(Mpsm2VF1OBnCRvK3qf6)
				title = title+' ('+count+')'
				RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,311,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
	else:
		items = trdVA0JvFaD.findall('" href="(.*?)".*?</i>(.*?)</a>.*?">(.*?)<.*?<span.*?<span.*?<span.*?">(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,title,Ozv9jFsy38NmPipCXRo1dwTQ,oJV18NUZAzPGqMu7tenCxrkfhdl69B in items:
			if title==hWGMqtBy4wuLaVcj or Ozv9jFsy38NmPipCXRo1dwTQ==hWGMqtBy4wuLaVcj: continue
			llxFwq0CUNgQtivJzkHeGV = Str0BupDTFA+'/'+llxFwq0CUNgQtivJzkHeGV
			title = title+' ('+oJV18NUZAzPGqMu7tenCxrkfhdl69B+')'
			RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,312)
	if not items: GrsxUhb0PEXj2FQRAkD4q(mMQ3FkNVa4IlxqY)
	return
def GrsxUhb0PEXj2FQRAkD4q(mMQ3FkNVa4IlxqY):
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('class="ibox-content"(.*?)class="pagination',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
	items = trdVA0JvFaD.findall('href="(http.*?)".*?</i>(.*?)<.*?cell">(.*?)<.*?cell">(.*?)<.*?cell">(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	for llxFwq0CUNgQtivJzkHeGV,title,name,count,oJV18NUZAzPGqMu7tenCxrkfhdl69B in items:
		llxFwq0CUNgQtivJzkHeGV = Str0BupDTFA+'/'+llxFwq0CUNgQtivJzkHeGV
		title = title.strip(Mpsm2VF1OBnCRvK3qf6)
		name = name.strip(Mpsm2VF1OBnCRvK3qf6)
		title = title+' ('+name+')'
		RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,312,hWGMqtBy4wuLaVcj,oJV18NUZAzPGqMu7tenCxrkfhdl69B)
	return
def zXmuO0xpS8PQ3VwqEcH(url):
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'SHIAVOICE-SEARCH_ITEMS-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('class="ibox-content p-1"(.*?)class="ibox-content"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if not DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		wg5aF3e8rcDh7SGpW6M1OPnkU(url)
		return
	cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
	items = trdVA0JvFaD.findall('href="(.*?)".*?<strong>(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	for llxFwq0CUNgQtivJzkHeGV,title in items:
		llxFwq0CUNgQtivJzkHeGV = Str0BupDTFA+'/'+llxFwq0CUNgQtivJzkHeGV
		title = title.strip(Mpsm2VF1OBnCRvK3qf6)
		if '/play-' in llxFwq0CUNgQtivJzkHeGV: RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,312)
		else: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,311)
	return
def oanus6TxUFNAhSZKpJdYlEC4mV(url):
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(nHBb7jXk0Daom,'GET',url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'SHIAVOICE-PLAY-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	llxFwq0CUNgQtivJzkHeGV = trdVA0JvFaD.findall('<audio.*?src="(.*?)"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if not llxFwq0CUNgQtivJzkHeGV: llxFwq0CUNgQtivJzkHeGV = trdVA0JvFaD.findall('<video.*?src="(.*?)"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	llxFwq0CUNgQtivJzkHeGV = Str0BupDTFA+llxFwq0CUNgQtivJzkHeGV[0]
	vOq38Y4XVZwdE(llxFwq0CUNgQtivJzkHeGV,xjPuFK3EsIZSiobQ5X,'video')
	return
def lPwaAjFTMG4n7iSLkXcEuK0Zm(search):
	search,vvKf4sXgZIMyEJPuC,showDialogs = IVTEJQOiMR2dYta9C(search)
	if search==hWGMqtBy4wuLaVcj: search = TrzfUidpv1LyAYqwexHJDuS()
	if search==hWGMqtBy4wuLaVcj: return
	search = search.replace(Mpsm2VF1OBnCRvK3qf6,'+')
	RrgNe4ynUtp2QYE = ['&t=a','&t=c','&t=s']
	if showDialogs:
		W7nuUcvJA1oKeqyhrE3P0d5 = ['قارئ','إصدار / مجلد','مقطع الصوتي']
		OODLkJlZCoKmrzbg2XQSGPUdInA = Eb7qJoNwOgn('موقع صوت الشيعة - أختر البحث', W7nuUcvJA1oKeqyhrE3P0d5)
		if OODLkJlZCoKmrzbg2XQSGPUdInA == -1: return
	elif '_SHIAVOICE-PERSONS_' in vvKf4sXgZIMyEJPuC: OODLkJlZCoKmrzbg2XQSGPUdInA = 0
	elif '_SHIAVOICE-ALBUMS_' in vvKf4sXgZIMyEJPuC: OODLkJlZCoKmrzbg2XQSGPUdInA = 1
	elif '_SHIAVOICE-AUDIOS_' in vvKf4sXgZIMyEJPuC: OODLkJlZCoKmrzbg2XQSGPUdInA = 2
	else: return
	type = RrgNe4ynUtp2QYE[OODLkJlZCoKmrzbg2XQSGPUdInA]
	url = Str0BupDTFA+'/search.php?q='+search+type
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'SHIAVOICE-SEARCH-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('class="ibox-content"(.*?)class="ibox-content"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		if OODLkJlZCoKmrzbg2XQSGPUdInA in [0,1]:
			items = trdVA0JvFaD.findall('href="(.*?)".*?src="(.*?)".*?href=".*?">(.*?)<.*?">(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
			for llxFwq0CUNgQtivJzkHeGV,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,title,name in items:
				title = title.strip(Mpsm2VF1OBnCRvK3qf6)
				name = name.strip(Mpsm2VF1OBnCRvK3qf6)
				title = title+' ('+name+')'
				RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,313,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
		elif OODLkJlZCoKmrzbg2XQSGPUdInA==2:
			items = trdVA0JvFaD.findall('href="(http.*?)".*?</i>(.*?)</a></td><td>(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
			for llxFwq0CUNgQtivJzkHeGV,title,name in items:
				title = title.strip(Mpsm2VF1OBnCRvK3qf6)
				name = name.strip(Mpsm2VF1OBnCRvK3qf6)
				title = title+' ('+name+')'
				RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,312)
	return
# -*- coding: utf-8 -*-
from yoY3NdGViS import *
xjPuFK3EsIZSiobQ5X = 'KATKOUTE'
n0qFKQWhiBYXoTrvejVHUA4 = '_KTK_'
Str0BupDTFA = u6rbxnyjTl7I[xjPuFK3EsIZSiobQ5X][0]
P3UK1Rr4IdYe5 = ['الصفحة الرئيسية','Sign in','الأقسام']
def ehB18u9sQFRi(mode,url,text):
	if   mode==670: N6NCYivtV4I5rEXq = DP6FSBgNdX1rsvVR()
	elif mode==671: N6NCYivtV4I5rEXq = wg5aF3e8rcDh7SGpW6M1OPnkU(url,text)
	elif mode==672: N6NCYivtV4I5rEXq = oanus6TxUFNAhSZKpJdYlEC4mV(url)
	elif mode==673: N6NCYivtV4I5rEXq = R4i0moBGrAfhaZ3(url,text)
	elif mode==674: N6NCYivtV4I5rEXq = qt2zjyIbsS(url)
	elif mode==679: N6NCYivtV4I5rEXq = lPwaAjFTMG4n7iSLkXcEuK0Zm(text)
	else: N6NCYivtV4I5rEXq = False
	return N6NCYivtV4I5rEXq
def DP6FSBgNdX1rsvVR():
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',Str0BupDTFA,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'KATKOUTE-MENU-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'بحث في الموقع',hWGMqtBy4wuLaVcj,679,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'_REMEMBERRESULTS_')
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('"navslide-divider"(.*?)</ul>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('href="(.*?)">(.*?)</a>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,title in items:
			if title in P3UK1Rr4IdYe5: continue
			if title=='الأقسام': mode = 675
			else: mode = 674
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,mode)
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	items = pP0LwjXO3cAJRfCaQY6(Str0BupDTFA+'/watch/browse.html')
	for llxFwq0CUNgQtivJzkHeGV,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,title in items:
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,674,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
	return
def pP0LwjXO3cAJRfCaQY6(url):
	pgj1NhfSenwsqXPy2BxZRtbcMCuJOT = Mqk51CFBym0pIQXZLsOxSJ(MM5Dx39f7ULhcJsRptzIowP,'list','KATKOUTE','CATEGORIES')
	if pgj1NhfSenwsqXPy2BxZRtbcMCuJOT: return pgj1NhfSenwsqXPy2BxZRtbcMCuJOT
	pgj1NhfSenwsqXPy2BxZRtbcMCuJOT = []
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(lke5D6CpaAXPdEZyrBSw7T,'GET',url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'KATKOUTE-CATEGORIES-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('"category-header"(.*?)<footer>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		pgj1NhfSenwsqXPy2BxZRtbcMCuJOT = trdVA0JvFaD.findall('href="(.*?)".*?src="(.*?)" alt="(.*?)"',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		if pgj1NhfSenwsqXPy2BxZRtbcMCuJOT: BxuD7iQRpW1(MM5Dx39f7ULhcJsRptzIowP,'KATKOUTE','CATEGORIES',pgj1NhfSenwsqXPy2BxZRtbcMCuJOT,DpQifS0oKBI1hYcO)
	return pgj1NhfSenwsqXPy2BxZRtbcMCuJOT
def qt2zjyIbsS(url):
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'KATKOUTE-SUBMENU-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	cLV4wifngjAdbePKq2x7SDhXGYlO0 = trdVA0JvFaD.findall('"caret"(.*?)</ul>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if cLV4wifngjAdbePKq2x7SDhXGYlO0:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = cLV4wifngjAdbePKq2x7SDhXGYlO0[0]
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = cok5ZGXdQP7YhwtqyuaCnVevm6UB.replace('"presentation"','</ul>')
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		if not DJvksH7ZAFUqW9OyQnbGjPCtwR1o: DJvksH7ZAFUqW9OyQnbGjPCtwR1o = [(hWGMqtBy4wuLaVcj,cok5ZGXdQP7YhwtqyuaCnVevm6UB)]
		RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' فرز أو فلتر أو ترتيب '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
		for HoEKsq4QNVuCc8xdeMam0,cok5ZGXdQP7YhwtqyuaCnVevm6UB in DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
			items = trdVA0JvFaD.findall('href="(.*?)".*?>(.*?)</a>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
			if HoEKsq4QNVuCc8xdeMam0: HoEKsq4QNVuCc8xdeMam0 = HoEKsq4QNVuCc8xdeMam0+': '
			for llxFwq0CUNgQtivJzkHeGV,title in items:
				title = HoEKsq4QNVuCc8xdeMam0+title
				RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,671)
	v2V8Nmrwf4 = trdVA0JvFaD.findall('"pm-category-subcats"(.*?)</ul>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if v2V8Nmrwf4:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = v2V8Nmrwf4[0]
		items = trdVA0JvFaD.findall('href="(.*?)">(.*?)</a>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		if len(items)<30:
			RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
			for llxFwq0CUNgQtivJzkHeGV,title in items:
				RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,671)
	if not cLV4wifngjAdbePKq2x7SDhXGYlO0 and not v2V8Nmrwf4: wg5aF3e8rcDh7SGpW6M1OPnkU(url)
	return
def wg5aF3e8rcDh7SGpW6M1OPnkU(url,s4mUPzjv1bRoNTMdenkuBgYl=hWGMqtBy4wuLaVcj):
	if s4mUPzjv1bRoNTMdenkuBgYl=='ajax-search':
		url,search = url.split('?',1)
		data = 'queryString='+search
		headers = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'POST',url,data,headers,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'KATKOUTE-TITLES-1st')
	else:
		sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'KATKOUTE-TITLES-2nd')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	cok5ZGXdQP7YhwtqyuaCnVevm6UB,items = hWGMqtBy4wuLaVcj,[]
	cbYKa2SXGwRCiQIW5NeosU9k = RRNODILCtGzvgpx(url,'url')
	if s4mUPzjv1bRoNTMdenkuBgYl=='ajax-search':
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = mMQ3FkNVa4IlxqY
		yRE17DrswMOxv0Gc9H = trdVA0JvFaD.findall('href="(.*?)">(.*?)</a>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,title in yRE17DrswMOxv0Gc9H: items.append((hWGMqtBy4wuLaVcj,llxFwq0CUNgQtivJzkHeGV,title))
	elif s4mUPzjv1bRoNTMdenkuBgYl=='featured':
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('"pm-video-watch-featured"(.*?)</ul>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if DJvksH7ZAFUqW9OyQnbGjPCtwR1o: cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
	elif s4mUPzjv1bRoNTMdenkuBgYl=='new_episodes':
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('"row pm-ul-browse-videos(.*?)</ul>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if DJvksH7ZAFUqW9OyQnbGjPCtwR1o: cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
	elif s4mUPzjv1bRoNTMdenkuBgYl=='new_movies':
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('"row pm-ul-browse-videos(.*?)</ul>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if len(DJvksH7ZAFUqW9OyQnbGjPCtwR1o)>1: cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[1]
	elif s4mUPzjv1bRoNTMdenkuBgYl=='featured_series':
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('"home-series-list"(.*?)</div>[\t|\n]*</div>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if DJvksH7ZAFUqW9OyQnbGjPCtwR1o: cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		yRE17DrswMOxv0Gc9H = trdVA0JvFaD.findall('href="(.*?)">(.*?)</a>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,title in yRE17DrswMOxv0Gc9H: items.append((hWGMqtBy4wuLaVcj,llxFwq0CUNgQtivJzkHeGV,title))
	else:
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('(data-echo=".*?)</ul>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if DJvksH7ZAFUqW9OyQnbGjPCtwR1o: cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
	if cok5ZGXdQP7YhwtqyuaCnVevm6UB and not items: items = trdVA0JvFaD.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	if not items: return
	REbVyXis1w4Ae = []
	nNBCdTs98RztMyODHpL63ZUKm4P = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية','فلم']
	for Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,llxFwq0CUNgQtivJzkHeGV,title in items:
		IIsmGy4pd7 = trdVA0JvFaD.findall('(.*?) (الحلقة|حلقة).\d+',title,trdVA0JvFaD.DOTALL)
		if any(BoSjXKxz41DcneO9UimClE in title for BoSjXKxz41DcneO9UimClE in nNBCdTs98RztMyODHpL63ZUKm4P):
			RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,672,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
		elif s4mUPzjv1bRoNTMdenkuBgYl=='new_episodes':
			RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,672,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
		elif IIsmGy4pd7:
			title = '_MOD_' + IIsmGy4pd7[0][0]
			if title not in REbVyXis1w4Ae:
				RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,673,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
				REbVyXis1w4Ae.append(title)
		elif '/movseries/' in llxFwq0CUNgQtivJzkHeGV:
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,671,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
		else: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,673,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('"pagination(.*?)</ul>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('href="(.*?)".*?>(.*?)</a>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,title in items:
			if llxFwq0CUNgQtivJzkHeGV=='#': continue
			if 'http' not in llxFwq0CUNgQtivJzkHeGV:
				NPM3HKQ57xe = url.rsplit('/',1)[0]
				llxFwq0CUNgQtivJzkHeGV = NPM3HKQ57xe+'/'+llxFwq0CUNgQtivJzkHeGV.strip('/')
			title = LNtIDdBA52P(title)
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'صفحة '+title,llxFwq0CUNgQtivJzkHeGV,671,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,s4mUPzjv1bRoNTMdenkuBgYl)
	return
def R4i0moBGrAfhaZ3(url,dp9XPV1Au6EWCJyiGw):
	RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+'تشغيل الفيديو',url,672)
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	pgj1NhfSenwsqXPy2BxZRtbcMCuJOT = pP0LwjXO3cAJRfCaQY6(Str0BupDTFA+'/watch/browse.html')
	Gfd1TmMatc7XHjOkLy2YKu,iMS5uLrCjIWe6GmcNDUAxoOhEpJ21X,a9KWA6vHzyFebqT72NLmG = zip(*pgj1NhfSenwsqXPy2BxZRtbcMCuJOT)
	mtg7hcrwS569 = []
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'KATKOUTE-EPISODES-2nd')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('"row pm-video-heading"(.*?)id="player"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		m4IznKilUOByHweG68VJ = trdVA0JvFaD.findall('class="myButton".*?href="(.*?)".*?<b>(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,title in m4IznKilUOByHweG68VJ:
			if llxFwq0CUNgQtivJzkHeGV not in Gfd1TmMatc7XHjOkLy2YKu:
				ImYg2jxU6Lc9Q1C4Oko = (llxFwq0CUNgQtivJzkHeGV,title)
				mtg7hcrwS569.append(ImYg2jxU6Lc9Q1C4Oko)
		if len(mtg7hcrwS569)==1:
			llxFwq0CUNgQtivJzkHeGV,title = mtg7hcrwS569[0]
			wg5aF3e8rcDh7SGpW6M1OPnkU(llxFwq0CUNgQtivJzkHeGV,'new_episodes')
			return
		else:
			for llxFwq0CUNgQtivJzkHeGV,title in mtg7hcrwS569:
				RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,671,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'new_episodes')
	if not mtg7hcrwS569: wg5aF3e8rcDh7SGpW6M1OPnkU(url,'new_episodes')
	return
def oanus6TxUFNAhSZKpJdYlEC4mV(url):
	zmDKurMJwj6fi = []
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'KATKOUTE-PLAY-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('sources:(.*?)flashplayer',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		m4IznKilUOByHweG68VJ = trdVA0JvFaD.findall('file: "(.*?)".*?label: "(.*?)"',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,QS8ZdxkHD5bjU9qsn4zMYaPrg3h7 in m4IznKilUOByHweG68VJ:
			llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV+'?named=__watch__'+QS8ZdxkHD5bjU9qsn4zMYaPrg3h7
			zmDKurMJwj6fi.append(llxFwq0CUNgQtivJzkHeGV)
	m4IznKilUOByHweG68VJ = trdVA0JvFaD.findall('"embedded-video".*?src="(.*?)"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if not m4IznKilUOByHweG68VJ: m4IznKilUOByHweG68VJ = trdVA0JvFaD.findall("file: '(.*?)'",mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if m4IznKilUOByHweG68VJ:
		llxFwq0CUNgQtivJzkHeGV = m4IznKilUOByHweG68VJ[0]
		if 'http' not in llxFwq0CUNgQtivJzkHeGV: llxFwq0CUNgQtivJzkHeGV = 'http:'+llxFwq0CUNgQtivJzkHeGV
		zmDKurMJwj6fi.append(llxFwq0CUNgQtivJzkHeGV+'?named=__embed')
	import oosSOfvdEQ
	oosSOfvdEQ.zfdYjsGLg8M6i15qZWh(zmDKurMJwj6fi,xjPuFK3EsIZSiobQ5X,'video',url)
	return
def lPwaAjFTMG4n7iSLkXcEuK0Zm(search):
	search,vvKf4sXgZIMyEJPuC,showDialogs = IVTEJQOiMR2dYta9C(search)
	if search==hWGMqtBy4wuLaVcj: search = TrzfUidpv1LyAYqwexHJDuS()
	if search==hWGMqtBy4wuLaVcj: return
	search = search.replace(Mpsm2VF1OBnCRvK3qf6,'+')
	url = Str0BupDTFA+'/watch/search.php?keywords='+search
	wg5aF3e8rcDh7SGpW6M1OPnkU(url,'search')
	return
# -*- coding: utf-8 -*-
import sys as zGjD5QAkd7SO9YPcZl
A56Abl2j14QS = zGjD5QAkd7SO9YPcZl.version_info [0] == 2
qO2vebR9rSTZnuJDW = 2048
EECQl2Zun37S0KkWwtIDHYNai6Ayd8 = 7
def wwTjCFmkUK (mMBv4T89VDdfJGL):
	global ylRUYSmHX7oCf93TADc8J6rqMVL
	tE23ZuI91qGJ = ord (mMBv4T89VDdfJGL [-1])
	huZOyFMzvY3LpEf = mMBv4T89VDdfJGL [:-1]
	FXE237NbgJweKmBxPfVnsAoYjCazqW = tE23ZuI91qGJ % len (huZOyFMzvY3LpEf)
	LQ2yAP51CVNFXdr = huZOyFMzvY3LpEf [:FXE237NbgJweKmBxPfVnsAoYjCazqW] + huZOyFMzvY3LpEf [FXE237NbgJweKmBxPfVnsAoYjCazqW:]
	if A56Abl2j14QS:
		R0i7UHvbBw25n8 = unicode () .join ([unichr (ord (cIsD9VN758uwbLUaGM2zmEY) - qO2vebR9rSTZnuJDW - (o42QnFjKJ5l98hWTqzCDi73LcvNA + tE23ZuI91qGJ) % EECQl2Zun37S0KkWwtIDHYNai6Ayd8) for o42QnFjKJ5l98hWTqzCDi73LcvNA, cIsD9VN758uwbLUaGM2zmEY in enumerate (LQ2yAP51CVNFXdr)])
	else:
		R0i7UHvbBw25n8 = str () .join ([chr (ord (cIsD9VN758uwbLUaGM2zmEY) - qO2vebR9rSTZnuJDW - (o42QnFjKJ5l98hWTqzCDi73LcvNA + tE23ZuI91qGJ) % EECQl2Zun37S0KkWwtIDHYNai6Ayd8) for o42QnFjKJ5l98hWTqzCDi73LcvNA, cIsD9VN758uwbLUaGM2zmEY in enumerate (LQ2yAP51CVNFXdr)])
	return eval (R0i7UHvbBw25n8)
NeO3CTLHrPfWUoIgy8Q,KNIvHPjUbhr,CnbBKmtF1x84q7AW=wwTjCFmkUK,wwTjCFmkUK,wwTjCFmkUK
zyvJMtBhrw,MMizeNH0AKu,KBkxSYaz93pu1=CnbBKmtF1x84q7AW,KNIvHPjUbhr,NeO3CTLHrPfWUoIgy8Q
LB2q7IVRpcyXlE6C3ihZruPe4An1Y,EDgpT9hIF6GCfl0vXiWnBANjOUVRua,XQo0YS3sk4rHAvwyNltf9CipLWMjx=KBkxSYaz93pu1,MMizeNH0AKu,zyvJMtBhrw
hWUz1ujibPY3G9MIZmvS4kVaK7dT,DJ1ICpbyR2,e2qDYgipPmTw4KvBLnochr=XQo0YS3sk4rHAvwyNltf9CipLWMjx,EDgpT9hIF6GCfl0vXiWnBANjOUVRua,LB2q7IVRpcyXlE6C3ihZruPe4An1Y
A6dMB1FlgxVivJ2fk9C,mkHKSQvjWr5BTcM3wVY,o1u5dij9UrcbXzVS8lwIWfKpnqM=e2qDYgipPmTw4KvBLnochr,DJ1ICpbyR2,hWUz1ujibPY3G9MIZmvS4kVaK7dT
JwiZdgbG5HYuCIsj69aBSRQ0nrNkET,SqrG5mU3j96ldsFpExobw40TJY,HHoGx7Flus60=o1u5dij9UrcbXzVS8lwIWfKpnqM,mkHKSQvjWr5BTcM3wVY,A6dMB1FlgxVivJ2fk9C
QVDJLRlxNg127jMX,gDuGMR3z1aV6YdLmCpiO8Kl,jeAby54c02TgG8zuivonX91=HHoGx7Flus60,SqrG5mU3j96ldsFpExobw40TJY,JwiZdgbG5HYuCIsj69aBSRQ0nrNkET
S1SgCFYGJeMvfp5iZXK,dv0trJR7PwmKyxDYO52VLau8gEph,QvgnCALNstmuUJiET=jeAby54c02TgG8zuivonX91,gDuGMR3z1aV6YdLmCpiO8Kl,QVDJLRlxNg127jMX
OOsBSKq9u6J2lC5WdYpvNMHaFP4,rwQN9AKhLCuMfHxjlbX0U,xcChIL13BpR8WArNt9Pl0So=QvgnCALNstmuUJiET,dv0trJR7PwmKyxDYO52VLau8gEph,S1SgCFYGJeMvfp5iZXK
sULh4NjakzI8He7xJCMGrql,LAhIMyBG0xZVUlO4rJ9z5fbDFgCs,GA4NBdjuZqkKUX6IEMvHPoegDyVrLm=xcChIL13BpR8WArNt9Pl0So,rwQN9AKhLCuMfHxjlbX0U,OOsBSKq9u6J2lC5WdYpvNMHaFP4
ITvnUAMXsyb4eO,wwPrSDa21lUh,FimxS5jkaq1RcJ8DnWTZNO4zQClwt=GA4NBdjuZqkKUX6IEMvHPoegDyVrLm,LAhIMyBG0xZVUlO4rJ9z5fbDFgCs,sULh4NjakzI8He7xJCMGrql
from m8L6HZjgX1 import *
xjPuFK3EsIZSiobQ5X = o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠬࡏࡎࡊࡖࠪඎ")
NGldhyXZJSmr = SqrG5mU3j96ldsFpExobw40TJY(u"࠭࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂ࠭ඏ")
X3X4Y8RzxSVfZJUFDe,wJUqaIAzvtsMSEZlKV,S6NALBOqGn1zi2W5M8y7,u2GRrQ0854,nWE8aO53lFfD,l7COkhRWD9uVS60Pte2NoyAaZn,XNBHzrlKD9yW,MH5c7Nekugx8O1AQjInRWyT64GV,SX7OT3VLGp2iQm = vikbdSOtZJFz6gQeL(i2tpOA6QzlfUByTSeKacWnV1)
ahU9MCTwjqmOPsZnY6lLK73bvJ = int(u2GRrQ0854)
h4s5qao1CX = MMk8qKvcJe4fQHm3EG7diBD5.getInfoLabel(GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠧࡍ࡫ࡶࡸࡎࡺࡥ࡮࠰ࡏࡥࡧ࡫࡬ࠨඐ"))
h4s5qao1CX = h4s5qao1CX.replace(w4GYEC6fmU2g7H,hWGMqtBy4wuLaVcj).replace(cc6SBsG2vlpjPd8yERNW1AJDZM,hWGMqtBy4wuLaVcj)
if ahU9MCTwjqmOPsZnY6lLK73bvJ==KNIvHPjUbhr(u"࠵࠺࠵බ"): kOv3SC9lfa0T = sULh4NjakzI8He7xJCMGrql(u"ࠨࠢࠣࠤ࡛࡫ࡲࡴ࡫ࡲࡲ࠿࡛ࠦࠡࠩඑ")+aO9cFKo862LqTWlIjy+QVDJLRlxNg127jMX(u"ࠩࠣࡡࠥࠦࠠࡌࡱࡧ࡭࠿࡛ࠦࠡࠩඒ")+FFAcZOeDh4KC+xcChIL13BpR8WArNt9Pl0So(u"ࠪࠤࡢ࠭ඓ")
else:
	C498ObYci2xwQUkIAPne03hW = jkiCS0UWs2dNAJcGKn6mbHD(i2tpOA6QzlfUByTSeKacWnV1).replace(hXB0vKVQ5PRI91SDTprMdfuHEm4,hWGMqtBy4wuLaVcj).replace(soMVfbr6WtpNlcSA,hWGMqtBy4wuLaVcj)
	C498ObYci2xwQUkIAPne03hW = C498ObYci2xwQUkIAPne03hW.replace(YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj).strip(Mpsm2VF1OBnCRvK3qf6)
	C498ObYci2xwQUkIAPne03hW = C498ObYci2xwQUkIAPne03hW.replace(nIDXGaRHv7mOohe0Y8dLstECM,Mpsm2VF1OBnCRvK3qf6).replace(lG0yV5QNFHc2RbXM1Wp,Mpsm2VF1OBnCRvK3qf6).replace(FqcVAkh7WjIXHdDKf8nvuyRo,Mpsm2VF1OBnCRvK3qf6)
	kOv3SC9lfa0T = GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠫࠥࠦࠠࡍࡣࡥࡩࡱࡀࠠ࡜ࠢࠪඔ")+h4s5qao1CX+mkHKSQvjWr5BTcM3wVY(u"ࠬࠦ࡝ࠡࠢࠣࡑࡴࡪࡥ࠻ࠢ࡞ࠤࠬඕ")+u2GRrQ0854+wwPrSDa21lUh(u"࠭ࠠ࡞ࠢࠣࠤࡕࡧࡴࡩ࠼ࠣ࡟ࠥ࠭ඖ")+C498ObYci2xwQUkIAPne03hW+dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠧࠡ࡟ࠪ඗")
KteLZCbM8W0FqE2OBx1(pGYKHZgqFX3B,NGldhyXZJSmr+NXMOzZjYsmS9pf+qhVEWvetzXLOcr1(xjPuFK3EsIZSiobQ5X)+kOv3SC9lfa0T)
if KNIvHPjUbhr(u"ࠨࡡࠪ඘") in MH5c7Nekugx8O1AQjInRWyT64GV: Iq3U2AkJeVXgmwMi,N4NC8byh6KMgcj3 = MH5c7Nekugx8O1AQjInRWyT64GV.split(o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠩࡢࠫ඙"),KNIvHPjUbhr(u"࠵භ"))
else: Iq3U2AkJeVXgmwMi,N4NC8byh6KMgcj3 = MH5c7Nekugx8O1AQjInRWyT64GV,hWGMqtBy4wuLaVcj
hlxkBcuTP3dfMLs8t,wF5zRoQekA9lxOYacnju13yUIDs = fEXMiAyG3ql4vKB,hWGMqtBy4wuLaVcj
if Iq3U2AkJeVXgmwMi in [GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠪ࠵ࠬක"),QvgnCALNstmuUJiET(u"ࠫ࠷࠭ඛ"),KNIvHPjUbhr(u"ࠬ࠹ࠧග"),o1u5dij9UrcbXzVS8lwIWfKpnqM(u"࠭࠴ࠨඝ"),e2qDYgipPmTw4KvBLnochr(u"ࠧ࠶ࠩඞ"),o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠨ࠳࠴ࠫඟ"),LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠩ࠴࠶ࠬච"),LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠪ࠵࠸࠭ඡ")] and (OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠫࡆࡊࡄࠨජ") in N4NC8byh6KMgcj3 or MMizeNH0AKu(u"ࠬࡘࡅࡎࡑ࡙ࡉࠬඣ") in N4NC8byh6KMgcj3 or zyvJMtBhrw(u"࠭ࡕࡑࠩඤ") in N4NC8byh6KMgcj3 or SqrG5mU3j96ldsFpExobw40TJY(u"ࠧࡅࡑ࡚ࡒࠬඥ") in N4NC8byh6KMgcj3):
	from jjGMocmUg2 import Lw8WcPiZ7u6jzh0
	Lw8WcPiZ7u6jzh0(MH5c7Nekugx8O1AQjInRWyT64GV,Iq3U2AkJeVXgmwMi,N4NC8byh6KMgcj3)
	ee8c0jzrTntGSUdRJm.setSetting(jeAby54c02TgG8zuivonX91(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡷ࡫ࡦࡳࡧࡶ࡬ࠬඦ"),i2tpOA6QzlfUByTSeKacWnV1)
	hlxkBcuTP3dfMLs8t = VBlawK4mgHSyLEn8iqhUkz5
elif not Q9dmawtsE7unfZFyvzNVx5c1iL48CB and ahU9MCTwjqmOPsZnY6lLK73bvJ in [XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"࠷࠹࠵ම"),OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"࠽࠱࠶ඹ")]:
	BBprgGU1NPZsFqWkyHRi9c = str(SX7OT3VLGp2iQm[DJ1ICpbyR2(u"ࠩࡩࡳࡱࡪࡥࡳࠩට")])
	xjPuFK3EsIZSiobQ5X = A6dMB1FlgxVivJ2fk9C(u"ࠪࡍࡕ࡚ࡖࠨඨ") if ahU9MCTwjqmOPsZnY6lLK73bvJ==DJ1ICpbyR2(u"࠲࠴࠷ය") else NeO3CTLHrPfWUoIgy8Q(u"ࠫࡒ࠹ࡕࠨඩ")
	M0Snpgv31JiGjm42NHP = xjPuFK3EsIZSiobQ5X.lower()
	o0ST4d1BWzi7r3OnK9ucCXxw = ee8c0jzrTntGSUdRJm.getSetting(hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠬࡧࡶ࠯ࠩඪ")+M0Snpgv31JiGjm42NHP+OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"࠭࠮ࡶࡵࡨࡶࡦ࡭ࡥ࡯ࡶࡢࠫණ")+BBprgGU1NPZsFqWkyHRi9c)
	JPl40rDFqybV9H2Wxi1 = ee8c0jzrTntGSUdRJm.getSetting(xcChIL13BpR8WArNt9Pl0So(u"ࠧࡢࡸ࠱ࠫඬ")+M0Snpgv31JiGjm42NHP+gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠨ࠰ࡵࡩ࡫࡫ࡲࡦࡴࡢࠫත")+BBprgGU1NPZsFqWkyHRi9c)
	if o0ST4d1BWzi7r3OnK9ucCXxw or JPl40rDFqybV9H2Wxi1:
		S6NALBOqGn1zi2W5M8y7 += sULh4NjakzI8He7xJCMGrql(u"ࠩࡿࠫථ")
		if o0ST4d1BWzi7r3OnK9ucCXxw: S6NALBOqGn1zi2W5M8y7 += mkHKSQvjWr5BTcM3wVY(u"࡚ࠪࠪࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴ࠾ࠩද")+o0ST4d1BWzi7r3OnK9ucCXxw
		if JPl40rDFqybV9H2Wxi1: S6NALBOqGn1zi2W5M8y7 += wwPrSDa21lUh(u"ࠫࠫࡘࡥࡧࡧࡵࡩࡷࡃࠧධ")+JPl40rDFqybV9H2Wxi1
		S6NALBOqGn1zi2W5M8y7 = S6NALBOqGn1zi2W5M8y7.replace(dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠬࢂࠦࠨන"),e2qDYgipPmTw4KvBLnochr(u"࠭ࡼࠨ඲"))
	ZHnaYtvKI0MDCkifexTJ = ee8c0jzrTntGSUdRJm.getSetting(OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠧࡢࡸ࠱ࠫඳ")+M0Snpgv31JiGjm42NHP+hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠨ࠰ࡶࡩࡷࡼࡥࡳࡡࠪප")+BBprgGU1NPZsFqWkyHRi9c)
	if ZHnaYtvKI0MDCkifexTJ:
		BYZJPpNEUu1Vy3 = trdVA0JvFaD.findall(KNIvHPjUbhr(u"ࠩ࠽࠳࠴࠮࠮ࠫࡁࠬ࠳ࠬඵ"),S6NALBOqGn1zi2W5M8y7,trdVA0JvFaD.DOTALL)
		S6NALBOqGn1zi2W5M8y7 = S6NALBOqGn1zi2W5M8y7.replace(BYZJPpNEUu1Vy3[ybdv7XcT3lxF6QezULwCAGk],ZHnaYtvKI0MDCkifexTJ)
	vOq38Y4XVZwdE(S6NALBOqGn1zi2W5M8y7,xjPuFK3EsIZSiobQ5X,X3X4Y8RzxSVfZJUFDe)
else:
	import yoY3NdGViS
	try: yoY3NdGViS.LDqugTFOUPBKGadrixzSy9Z(X3X4Y8RzxSVfZJUFDe,wJUqaIAzvtsMSEZlKV,S6NALBOqGn1zi2W5M8y7,u2GRrQ0854,nWE8aO53lFfD,l7COkhRWD9uVS60Pte2NoyAaZn,XNBHzrlKD9yW,MH5c7Nekugx8O1AQjInRWyT64GV,SX7OT3VLGp2iQm,ahU9MCTwjqmOPsZnY6lLK73bvJ,Iq3U2AkJeVXgmwMi,N4NC8byh6KMgcj3,h4s5qao1CX)
	except Exception as nKh8r540GQBVPTokjZ2: wF5zRoQekA9lxOYacnju13yUIDs = R7RLCd9kyl.format_exc()
	hlxkBcuTP3dfMLs8t = yoY3NdGViS.hlxkBcuTP3dfMLs8t
EZAp20cJB35S(hlxkBcuTP3dfMLs8t,wF5zRoQekA9lxOYacnju13yUIDs)
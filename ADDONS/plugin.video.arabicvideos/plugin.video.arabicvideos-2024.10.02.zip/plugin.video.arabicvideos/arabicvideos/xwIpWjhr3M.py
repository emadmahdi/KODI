# -*- coding: utf-8 -*-
from yoY3NdGViS import *
xjPuFK3EsIZSiobQ5X = 'ARABICTOONS'
n0qFKQWhiBYXoTrvejVHUA4 = '_ART_'
Str0BupDTFA = u6rbxnyjTl7I[xjPuFK3EsIZSiobQ5X][0]
def ehB18u9sQFRi(mode,url,text):
	if   mode==730: N6NCYivtV4I5rEXq = DP6FSBgNdX1rsvVR()
	elif mode==731: N6NCYivtV4I5rEXq = wg5aF3e8rcDh7SGpW6M1OPnkU(url)
	elif mode==732: N6NCYivtV4I5rEXq = oanus6TxUFNAhSZKpJdYlEC4mV(url)
	elif mode==733: N6NCYivtV4I5rEXq = GrsxUhb0PEXj2FQRAkD4q(url)
	elif mode==734: N6NCYivtV4I5rEXq = H9jEf0DWKAzLSIhCO1vFq(url)
	elif mode==735: N6NCYivtV4I5rEXq = yuikVh3B4UR(url)
	elif mode==739: N6NCYivtV4I5rEXq = lPwaAjFTMG4n7iSLkXcEuK0Zm(text)
	else: N6NCYivtV4I5rEXq = False
	return N6NCYivtV4I5rEXq
def DP6FSBgNdX1rsvVR():
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'بحث في الموقع',hWGMqtBy4wuLaVcj,739,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'_REMEMBERRESULTS_')
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+'مسلسلات مميزة',Str0BupDTFA+'/top.php',735)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+'مسلسلات',Str0BupDTFA+'/cartoon.php',734)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+'افلام',Str0BupDTFA+'/movies.php',731)
	return
def H9jEf0DWKAzLSIhCO1vFq(url):
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'الكل',url,731)
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'ARABICTOONS-SERIES_SUBMENU-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('label="navigation"(.*?)</ul>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall("href='(.*?)'>(.*?)</a>",cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,title in items:
			llxFwq0CUNgQtivJzkHeGV = Str0BupDTFA+'/'+llxFwq0CUNgQtivJzkHeGV
			title = 'حرف '+title
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,731)
	return
def yuikVh3B4UR(url):
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'ARABICTOONS-SERIES_FEATURED-2nd')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('class="slider"(.*?)</ul>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('title="(.*?)" href="(.*?)".*?src="(.*?)"',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for title,llxFwq0CUNgQtivJzkHeGV,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG in items:
			llxFwq0CUNgQtivJzkHeGV = Str0BupDTFA+'/'+llxFwq0CUNgQtivJzkHeGV
			Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG = Str0BupDTFA+'/'+Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG
			title = title.strip(Mpsm2VF1OBnCRvK3qf6)
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,733,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
	return
def wg5aF3e8rcDh7SGpW6M1OPnkU(url):
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'ARABICTOONS-TITLES-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall("class='moviesBlocks(.*?)navigation",mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
	items = trdVA0JvFaD.findall('class="movie".*?href="(.*?)".*?src="(.*?)".*?<b>(.*?)</b>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	for llxFwq0CUNgQtivJzkHeGV,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,title in items:
		llxFwq0CUNgQtivJzkHeGV = Str0BupDTFA+'/'+llxFwq0CUNgQtivJzkHeGV
		Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG = Str0BupDTFA+'/'+Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG
		title = title.strip(Mpsm2VF1OBnCRvK3qf6)
		if 'movies.php' in url: RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,732,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
		else: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,733,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('"pagination(.*?)</ul>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[-1]
		items = trdVA0JvFaD.findall('href="(.*?)".*?>(.*?)</a>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,title in items:
			llxFwq0CUNgQtivJzkHeGV = Str0BupDTFA+'/'+llxFwq0CUNgQtivJzkHeGV
			title = title.strip(Mpsm2VF1OBnCRvK3qf6)
			title = LNtIDdBA52P(title)
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'صفحة '+title,llxFwq0CUNgQtivJzkHeGV,731)
	return
def GrsxUhb0PEXj2FQRAkD4q(url):
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'ARABICTOONS-EPISODES-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall("class='moviesBlocks(.*?)script",mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('class="movie".*?title="(.*?)".*?href="(.*?)".*?src="(.*?)".*?<b>(.*?)</b>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for title,llxFwq0CUNgQtivJzkHeGV,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,KpAUxnTMcZ in items:
			llxFwq0CUNgQtivJzkHeGV = Str0BupDTFA+'/'+llxFwq0CUNgQtivJzkHeGV
			Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG = Str0BupDTFA+'/'+Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG
			title = title.strip(Mpsm2VF1OBnCRvK3qf6)
			title = title+Mpsm2VF1OBnCRvK3qf6+KpAUxnTMcZ.strip(Mpsm2VF1OBnCRvK3qf6)
			RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,732,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
	return
def oanus6TxUFNAhSZKpJdYlEC4mV(url):
	zmDKurMJwj6fi = []
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'ARABICTOONS-PLAY-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	m4IznKilUOByHweG68VJ = trdVA0JvFaD.findall('source src="(.*?)"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if m4IznKilUOByHweG68VJ:
		llxFwq0CUNgQtivJzkHeGV = m4IznKilUOByHweG68VJ[0]
		if 'Referer=' not in llxFwq0CUNgQtivJzkHeGV: llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV+'|Referer=https://www.arabic-toons.com'
		zmDKurMJwj6fi.append(llxFwq0CUNgQtivJzkHeGV+'?named=__embed')
	import oosSOfvdEQ
	oosSOfvdEQ.zfdYjsGLg8M6i15qZWh(zmDKurMJwj6fi,xjPuFK3EsIZSiobQ5X,'video',url)
	return
def lPwaAjFTMG4n7iSLkXcEuK0Zm(search):
	search,vvKf4sXgZIMyEJPuC,showDialogs = IVTEJQOiMR2dYta9C(search)
	if search==hWGMqtBy4wuLaVcj: search = TrzfUidpv1LyAYqwexHJDuS()
	if search==hWGMqtBy4wuLaVcj: return
	search = search.replace(Mpsm2VF1OBnCRvK3qf6,'%20')
	Dvi8asSrQYX5wE3KMIxT91me = [hWGMqtBy4wuLaVcj,'m']
	eeS1CB5UWIf = ['مسلسلات','افلام']
	if showDialogs:
		OODLkJlZCoKmrzbg2XQSGPUdInA = Eb7qJoNwOgn('اختر النوع المطلوب:', eeS1CB5UWIf)
		if OODLkJlZCoKmrzbg2XQSGPUdInA==-1: return
	else: OODLkJlZCoKmrzbg2XQSGPUdInA = 0
	type = Dvi8asSrQYX5wE3KMIxT91me[OODLkJlZCoKmrzbg2XQSGPUdInA]
	url = Str0BupDTFA+'/livesearch.php?'+type+'&q='+search
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'ARABICTOONS-SEARCH-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	items = trdVA0JvFaD.findall('href="(.*?)">(.*?)<',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	for llxFwq0CUNgQtivJzkHeGV,title in items:
		llxFwq0CUNgQtivJzkHeGV = Str0BupDTFA+'/'+llxFwq0CUNgQtivJzkHeGV
		title = title.strip(Mpsm2VF1OBnCRvK3qf6)
		if type=='m': RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,732)
		else: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,733)
	return
# -*- coding: utf-8 -*-
from yoY3NdGViS import *
xjPuFK3EsIZSiobQ5X = 'MYCIMA'
headers = {'User-Agent':hWGMqtBy4wuLaVcj}
n0qFKQWhiBYXoTrvejVHUA4 = '_MCM_'
Str0BupDTFA = u6rbxnyjTl7I[xjPuFK3EsIZSiobQ5X][0]
P3UK1Rr4IdYe5 = ['مصارعة حرة','wwe']
def ehB18u9sQFRi(mode,url,text):
	if   mode==360: N6NCYivtV4I5rEXq = DP6FSBgNdX1rsvVR()
	elif mode==361: N6NCYivtV4I5rEXq = wg5aF3e8rcDh7SGpW6M1OPnkU(url,text)
	elif mode==362: N6NCYivtV4I5rEXq = oanus6TxUFNAhSZKpJdYlEC4mV(url)
	elif mode==363: N6NCYivtV4I5rEXq = GrsxUhb0PEXj2FQRAkD4q(url,text)
	elif mode==364: N6NCYivtV4I5rEXq = hadMgR0nOKHoGqpA(url,'CATEGORIES___'+text)
	elif mode==365: N6NCYivtV4I5rEXq = hadMgR0nOKHoGqpA(url,'FILTERS___'+text)
	elif mode==366: N6NCYivtV4I5rEXq = qt2zjyIbsS(url)
	elif mode==369: N6NCYivtV4I5rEXq = lPwaAjFTMG4n7iSLkXcEuK0Zm(text,url)
	else: N6NCYivtV4I5rEXq = False
	return N6NCYivtV4I5rEXq
def DP6FSBgNdX1rsvVR():
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'بحث في الموقع',Str0BupDTFA,369,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'_REMEMBERRESULTS_')
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'فلتر محدد',Str0BupDTFA+'/AjaxCenter/RightBar',364)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'فلتر كامل',Str0BupDTFA+'/AjaxCenter/RightBar',365)
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(DpQifS0oKBI1hYcO,'GET',Str0BupDTFA,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'MYCIMA-MENU-2nd')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('class="NavigationMenu"(.*?)class="ProductionsListButton"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('class="menu-item.*?href="(.*?)">(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,title in items:
			if title==hWGMqtBy4wuLaVcj: continue
			if any(BoSjXKxz41DcneO9UimClE in title.lower() for BoSjXKxz41DcneO9UimClE in P3UK1Rr4IdYe5): continue
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,366)
		RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('hoverable activable(.*?)hoverable activable',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('href="(.*?)".*?url\((.*?)\).*?span>(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,title in items:
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,366,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
	return mMQ3FkNVa4IlxqY
def qt2zjyIbsS(url):
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(DpQifS0oKBI1hYcO,'GET',url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'MYCIMA-SUBMENU-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	if 'class="Slider--Grid"' in mMQ3FkNVa4IlxqY:
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'المميزة',url,361,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'featured')
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('class="list--Tabsui"(.*?)div',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('href="(.*?)".*?i>(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,title in items:
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,361)
	return
def wg5aF3e8rcDh7SGpW6M1OPnkU(u7iGbE0HcNz1dPoxQVnKOFLS,type=hWGMqtBy4wuLaVcj):
	if '::' in u7iGbE0HcNz1dPoxQVnKOFLS:
		CMzQFXeI08KDwAJ9p,url = u7iGbE0HcNz1dPoxQVnKOFLS.split('::')
		SODQ7qlNYoZcFK8e50rBsJaAHxiXjE = RRNODILCtGzvgpx(CMzQFXeI08KDwAJ9p,'url')
		url = SODQ7qlNYoZcFK8e50rBsJaAHxiXjE+url
	else: url,CMzQFXeI08KDwAJ9p = u7iGbE0HcNz1dPoxQVnKOFLS,u7iGbE0HcNz1dPoxQVnKOFLS
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'MYCIMA-TITLES-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	if type=='featured':
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('class="Slider--Grid"(.*?)class="list--Tabsui"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	elif type=='filters':
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = [mMQ3FkNVa4IlxqY.replace('\\/','/').replace('\\"','"')]
	else:
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('class="Grid--MycimaPosts"(.*?)</li></ul></div></div>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	REbVyXis1w4Ae = []
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('GridItem"><a href="(.*?)" title="(.*?)".*?url\((.*?)\)',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,title,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG in items:
			if any(BoSjXKxz41DcneO9UimClE in title.lower() for BoSjXKxz41DcneO9UimClE in P3UK1Rr4IdYe5): continue
			Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG = emr1Lf523Ti0OtcNgxP(Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
			title = LNtIDdBA52P(title)
			title = emr1Lf523Ti0OtcNgxP(title)
			title = title.replace('مشاهدة ',hWGMqtBy4wuLaVcj)
			if '/series/' in llxFwq0CUNgQtivJzkHeGV: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,363,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
			elif 'حلقة' in title:
				IIsmGy4pd7 = trdVA0JvFaD.findall('(.*?) +حلقة +\d+',title,trdVA0JvFaD.DOTALL)
				if IIsmGy4pd7: title = '_MOD_' + IIsmGy4pd7[0]
				if title not in REbVyXis1w4Ae:
					REbVyXis1w4Ae.append(title)
					RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,363,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
			else:
				RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,362,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
		if type=='filters':
			HHDPiqLBrUbSgveQlFwWz3Xd9O = trdVA0JvFaD.findall('"more_button_page":(.*?),',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
			if HHDPiqLBrUbSgveQlFwWz3Xd9O:
				count = HHDPiqLBrUbSgveQlFwWz3Xd9O[0]
				llxFwq0CUNgQtivJzkHeGV = url+'/offset/'+count
				RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'صفحة أخرى',llxFwq0CUNgQtivJzkHeGV,361,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'filters')
		elif type==hWGMqtBy4wuLaVcj:
			DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('class="pagination(.*?)</div>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
			if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
				cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
				items = trdVA0JvFaD.findall('href="(.*?)">(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
				for llxFwq0CUNgQtivJzkHeGV,title in items:
					title = 'صفحة '+LNtIDdBA52P(title)
					RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,361)
	return
def GrsxUhb0PEXj2FQRAkD4q(url,type=hWGMqtBy4wuLaVcj):
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'MYCIMA-EPISODES-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	mMQ3FkNVa4IlxqY = jkiCS0UWs2dNAJcGKn6mbHD(mMQ3FkNVa4IlxqY)
	name = trdVA0JvFaD.findall('itemprop="item" href=".*?/series/(.*?)"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if name: name = name[-1].replace('-',Mpsm2VF1OBnCRvK3qf6).strip('/')
	if 'موسم' in name and type==hWGMqtBy4wuLaVcj:
		name = name.split('موسم')[0]
		name = name.replace('مشاهدة',hWGMqtBy4wuLaVcj).strip(Mpsm2VF1OBnCRvK3qf6)
	elif 'حلقة' in name:
		name = name.split('حلقة')[0]
		name = name.replace('مشاهدة',hWGMqtBy4wuLaVcj).strip(Mpsm2VF1OBnCRvK3qf6)
	else: name = name
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('class="Seasons--Episodes"(.*?)</singlesection',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		if type==hWGMqtBy4wuLaVcj:
			items = trdVA0JvFaD.findall('href="(.*?)">(.*?)</a>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
			for llxFwq0CUNgQtivJzkHeGV,title in items:
				if 'class' in title: continue
				if 'episode' in title: continue
				title = name+' - '+title
				RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,363,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'episodes')
		if len(vNRpDl1awktg7QP4m0KGqMTS2i)==0:
			TfCqlZthRYgzkbE0GO = trdVA0JvFaD.findall('class="Episodes--Seasons--Episodes"(.*?)&&',cok5ZGXdQP7YhwtqyuaCnVevm6UB+'&&',trdVA0JvFaD.DOTALL)
			if TfCqlZthRYgzkbE0GO: cok5ZGXdQP7YhwtqyuaCnVevm6UB = TfCqlZthRYgzkbE0GO[0]
			items = trdVA0JvFaD.findall('href="(.*?)".*?<episodeTitle>(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
			for llxFwq0CUNgQtivJzkHeGV,title in items:
				title = title.strip(Mpsm2VF1OBnCRvK3qf6)
				title = name+' - '+title
				RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,362)
	if len(vNRpDl1awktg7QP4m0KGqMTS2i)==0:
		title = trdVA0JvFaD.findall('<title>(.*?)<',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if title: title = title[0].replace(' - ماي سيما',hWGMqtBy4wuLaVcj).replace('مشاهدة ',hWGMqtBy4wuLaVcj)
		else: title = 'ملف التشغيل'
		RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,url,362)
	return
def oanus6TxUFNAhSZKpJdYlEC4mV(url):
	Dvi8asSrQYX5wE3KMIxT91me = []
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(nHBb7jXk0Daom,'GET',url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'MYCIMA-PLAY-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	BX029UJFPvpNQsc45jbYZRh = trdVA0JvFaD.findall('<span>التصنيف<.*?<a.*?">(.*?)<.*?">(.*?)<',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if BX029UJFPvpNQsc45jbYZRh:
		BX029UJFPvpNQsc45jbYZRh = [BX029UJFPvpNQsc45jbYZRh[0][0],BX029UJFPvpNQsc45jbYZRh[0][1]]
		if BX029UJFPvpNQsc45jbYZRh and Dc20k3vN9hT5(xjPuFK3EsIZSiobQ5X,url,BX029UJFPvpNQsc45jbYZRh): return
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('class="WatchServersList"(.*?)class="WatchServersEmbed"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('data-url="(.*?)".*?strong>(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,name in items:
			if 'http' not in llxFwq0CUNgQtivJzkHeGV: llxFwq0CUNgQtivJzkHeGV = Str0BupDTFA+llxFwq0CUNgQtivJzkHeGV
			if name=='سيرفر ماي سيما': name = 'mycima'
			llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV+'?named='+name+'__watch'
			Dvi8asSrQYX5wE3KMIxT91me.append(llxFwq0CUNgQtivJzkHeGV)
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('class="List--Download(.*?)</div>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('href="(.*?)".*?</i>(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,QS8ZdxkHD5bjU9qsn4zMYaPrg3h7 in items:
			if 'http' not in llxFwq0CUNgQtivJzkHeGV: llxFwq0CUNgQtivJzkHeGV = Str0BupDTFA+llxFwq0CUNgQtivJzkHeGV
			QS8ZdxkHD5bjU9qsn4zMYaPrg3h7 = trdVA0JvFaD.findall('\d\d\d+',QS8ZdxkHD5bjU9qsn4zMYaPrg3h7,trdVA0JvFaD.DOTALL)
			if QS8ZdxkHD5bjU9qsn4zMYaPrg3h7: QS8ZdxkHD5bjU9qsn4zMYaPrg3h7 = '____'+QS8ZdxkHD5bjU9qsn4zMYaPrg3h7[0]
			else: QS8ZdxkHD5bjU9qsn4zMYaPrg3h7 = hWGMqtBy4wuLaVcj
			llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV+'?named=mycima'+'__download'+QS8ZdxkHD5bjU9qsn4zMYaPrg3h7
			Dvi8asSrQYX5wE3KMIxT91me.append(llxFwq0CUNgQtivJzkHeGV)
	import oosSOfvdEQ
	oosSOfvdEQ.zfdYjsGLg8M6i15qZWh(Dvi8asSrQYX5wE3KMIxT91me,xjPuFK3EsIZSiobQ5X,'video',url)
	return
def lPwaAjFTMG4n7iSLkXcEuK0Zm(search,HE7UpwDGYlPTV0s=hWGMqtBy4wuLaVcj):
	search,vvKf4sXgZIMyEJPuC,showDialogs = IVTEJQOiMR2dYta9C(search)
	if search==hWGMqtBy4wuLaVcj: search = TrzfUidpv1LyAYqwexHJDuS()
	if search==hWGMqtBy4wuLaVcj: return
	search = search.replace(Mpsm2VF1OBnCRvK3qf6,'+')
	Dvi8asSrQYX5wE3KMIxT91me = ['/list','/','/list/series','/list/anime','/list/tv']
	eeS1CB5UWIf = ['الكل','الأفلام','المسلسلات','الانيمي و الكرتون','البرامج تليفزيونية']
	if showDialogs:
		OODLkJlZCoKmrzbg2XQSGPUdInA = Eb7qJoNwOgn('اختر النوع المطلوب:', eeS1CB5UWIf)
		if OODLkJlZCoKmrzbg2XQSGPUdInA==-1: return
	else: OODLkJlZCoKmrzbg2XQSGPUdInA = 0
	if HE7UpwDGYlPTV0s==hWGMqtBy4wuLaVcj:
		sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(nHBb7jXk0Daom,'GET',Str0BupDTFA,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,False,hWGMqtBy4wuLaVcj,'MYCIMA-SEARCH-1st')
		HE7UpwDGYlPTV0s = sDQvwGASB0Vf67mik.headers['Location']
		HE7UpwDGYlPTV0s = HE7UpwDGYlPTV0s.strip('/')
	NPM3HKQ57xe = HE7UpwDGYlPTV0s+'/search/'+search+Dvi8asSrQYX5wE3KMIxT91me[OODLkJlZCoKmrzbg2XQSGPUdInA]
	wg5aF3e8rcDh7SGpW6M1OPnkU(NPM3HKQ57xe)
	return
def hadMgR0nOKHoGqpA(u7iGbE0HcNz1dPoxQVnKOFLS,filter):
	if '??' in u7iGbE0HcNz1dPoxQVnKOFLS: url = u7iGbE0HcNz1dPoxQVnKOFLS.split('//getposts??')[0]
	else: url = u7iGbE0HcNz1dPoxQVnKOFLS
	filter = filter.replace('_FORGETRESULTS_',hWGMqtBy4wuLaVcj)
	type,filter = filter.split('___',1)
	if filter==hWGMqtBy4wuLaVcj: RJGtCsyDgi0X,kYI6n5bUD83Z = hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj
	else: RJGtCsyDgi0X,kYI6n5bUD83Z = filter.split('___')
	if type=='CATEGORIES':
		if DJrjnM9UKHA2Gp0zOtmR[0]+'==' not in RJGtCsyDgi0X: OJx4sYA9nNbtPT5ezmDHdVBk2C7 = DJrjnM9UKHA2Gp0zOtmR[0]
		for PPuqrvDLEViYOMf1dmkK7 in range(len(DJrjnM9UKHA2Gp0zOtmR[0:-1])):
			if DJrjnM9UKHA2Gp0zOtmR[PPuqrvDLEViYOMf1dmkK7]+'==' in RJGtCsyDgi0X: OJx4sYA9nNbtPT5ezmDHdVBk2C7 = DJrjnM9UKHA2Gp0zOtmR[PPuqrvDLEViYOMf1dmkK7+1]
		nnqvmxlXub3iVDM = RJGtCsyDgi0X+'&&'+OJx4sYA9nNbtPT5ezmDHdVBk2C7+'==0'
		tuYnONZ6GaCecv4TErUHMdBX2DIb8K = kYI6n5bUD83Z+'&&'+OJx4sYA9nNbtPT5ezmDHdVBk2C7+'==0'
		BvO3oKUrHNCwVm791b80sZg = nnqvmxlXub3iVDM.strip('&&')+'___'+tuYnONZ6GaCecv4TErUHMdBX2DIb8K.strip('&&')
		PPlq1nxLf6CamuBI0psW = kKWuMB69mcOHPn3XilFdvp(kYI6n5bUD83Z,'modified_filters')
		NPM3HKQ57xe = url+'//getposts??'+PPlq1nxLf6CamuBI0psW
	elif type=='FILTERS':
		I2OnWkrPaVbwBSHiYR3LZ = kKWuMB69mcOHPn3XilFdvp(RJGtCsyDgi0X,'modified_values')
		I2OnWkrPaVbwBSHiYR3LZ = jkiCS0UWs2dNAJcGKn6mbHD(I2OnWkrPaVbwBSHiYR3LZ)
		if kYI6n5bUD83Z!=hWGMqtBy4wuLaVcj: kYI6n5bUD83Z = kKWuMB69mcOHPn3XilFdvp(kYI6n5bUD83Z,'modified_filters')
		if kYI6n5bUD83Z==hWGMqtBy4wuLaVcj: NPM3HKQ57xe = url
		else: NPM3HKQ57xe = url+'//getposts??'+kYI6n5bUD83Z
		FjQOc5WuzKg0Vikb6tDeNHZP1mS = fgoWEt5zm2NOJM1ZSHGnLpjkv4IC(NPM3HKQ57xe,u7iGbE0HcNz1dPoxQVnKOFLS)
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'أظهار قائمة الفيديو التي تم اختيارها ',FjQOc5WuzKg0Vikb6tDeNHZP1mS,361,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'filters')
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+' [[   '+I2OnWkrPaVbwBSHiYR3LZ+'   ]]',FjQOc5WuzKg0Vikb6tDeNHZP1mS,361,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'filters')
		RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(DpQifS0oKBI1hYcO,'GET',url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'MYCIMA-FILTERS_MENU-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	mMQ3FkNVa4IlxqY = mMQ3FkNVa4IlxqY.replace('\\"','"').replace('\\/','/')
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('<mycima--filter(.*?)</mycima--filter>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if not DJvksH7ZAFUqW9OyQnbGjPCtwR1o: return
	cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
	f5rVHP4bmCd7cqvuYEQJlnLTk6yGRS = trdVA0JvFaD.findall('taxonomy="(.*?)".*?<span>(.*?)<(.*?)<filterbox',cok5ZGXdQP7YhwtqyuaCnVevm6UB+'<filterbox',trdVA0JvFaD.DOTALL)
	dict = {}
	for bksErtC1hwcVqlfyM82AnD,name,cok5ZGXdQP7YhwtqyuaCnVevm6UB in f5rVHP4bmCd7cqvuYEQJlnLTk6yGRS:
		name = emr1Lf523Ti0OtcNgxP(name)
		if 'interest' in bksErtC1hwcVqlfyM82AnD: continue
		items = trdVA0JvFaD.findall('data-term="(.*?)".*?<txt>(.*?)</txt>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		if '==' not in NPM3HKQ57xe: NPM3HKQ57xe = url
		if type=='CATEGORIES':
			if OJx4sYA9nNbtPT5ezmDHdVBk2C7!=bksErtC1hwcVqlfyM82AnD: continue
			elif len(items)<=1:
				if bksErtC1hwcVqlfyM82AnD==DJrjnM9UKHA2Gp0zOtmR[-1]: wg5aF3e8rcDh7SGpW6M1OPnkU(NPM3HKQ57xe)
				else: hadMgR0nOKHoGqpA(NPM3HKQ57xe,'CATEGORIES___'+BvO3oKUrHNCwVm791b80sZg)
				return
			else:
				FjQOc5WuzKg0Vikb6tDeNHZP1mS = fgoWEt5zm2NOJM1ZSHGnLpjkv4IC(NPM3HKQ57xe,u7iGbE0HcNz1dPoxQVnKOFLS)
				if bksErtC1hwcVqlfyM82AnD==DJrjnM9UKHA2Gp0zOtmR[-1]:
					RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'الجميع',FjQOc5WuzKg0Vikb6tDeNHZP1mS,361,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'filters')
				else: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'الجميع',NPM3HKQ57xe,364,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,BvO3oKUrHNCwVm791b80sZg)
		elif type=='FILTERS':
			nnqvmxlXub3iVDM = RJGtCsyDgi0X+'&&'+bksErtC1hwcVqlfyM82AnD+'==0'
			tuYnONZ6GaCecv4TErUHMdBX2DIb8K = kYI6n5bUD83Z+'&&'+bksErtC1hwcVqlfyM82AnD+'==0'
			BvO3oKUrHNCwVm791b80sZg = nnqvmxlXub3iVDM+'___'+tuYnONZ6GaCecv4TErUHMdBX2DIb8K
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+name+': الجميع',NPM3HKQ57xe,365,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,BvO3oKUrHNCwVm791b80sZg+'_FORGETRESULTS_')
		dict[bksErtC1hwcVqlfyM82AnD] = {}
		for BoSjXKxz41DcneO9UimClE,PBo1KkyMCgH8eNDaLtZVcr3EnIi2 in items:
			name = emr1Lf523Ti0OtcNgxP(name)
			PBo1KkyMCgH8eNDaLtZVcr3EnIi2 = emr1Lf523Ti0OtcNgxP(PBo1KkyMCgH8eNDaLtZVcr3EnIi2)
			if BoSjXKxz41DcneO9UimClE=='r' or BoSjXKxz41DcneO9UimClE=='nc-17': continue
			if any(BoSjXKxz41DcneO9UimClE in PBo1KkyMCgH8eNDaLtZVcr3EnIi2.lower() for BoSjXKxz41DcneO9UimClE in P3UK1Rr4IdYe5): continue
			if 'http' in PBo1KkyMCgH8eNDaLtZVcr3EnIi2: continue
			if 'الكل' in PBo1KkyMCgH8eNDaLtZVcr3EnIi2: continue
			if 'n-a' in BoSjXKxz41DcneO9UimClE: continue
			if PBo1KkyMCgH8eNDaLtZVcr3EnIi2==hWGMqtBy4wuLaVcj: PBo1KkyMCgH8eNDaLtZVcr3EnIi2 = BoSjXKxz41DcneO9UimClE
			tZaSpl5NQAU8hxw = PBo1KkyMCgH8eNDaLtZVcr3EnIi2
			Ao8udjwfk3YgC2m = trdVA0JvFaD.findall('<name>(.*?)</name>',PBo1KkyMCgH8eNDaLtZVcr3EnIi2,trdVA0JvFaD.DOTALL)
			if Ao8udjwfk3YgC2m: tZaSpl5NQAU8hxw = Ao8udjwfk3YgC2m[0]
			m4eVoJdSU51qs3y8Gg06fZNau7A = name+': '+tZaSpl5NQAU8hxw
			dict[bksErtC1hwcVqlfyM82AnD][BoSjXKxz41DcneO9UimClE] = m4eVoJdSU51qs3y8Gg06fZNau7A
			nnqvmxlXub3iVDM = RJGtCsyDgi0X+'&&'+bksErtC1hwcVqlfyM82AnD+'=='+tZaSpl5NQAU8hxw
			tuYnONZ6GaCecv4TErUHMdBX2DIb8K = kYI6n5bUD83Z+'&&'+bksErtC1hwcVqlfyM82AnD+'=='+BoSjXKxz41DcneO9UimClE
			S80DwNWuMTZx4El = nnqvmxlXub3iVDM+'___'+tuYnONZ6GaCecv4TErUHMdBX2DIb8K
			if type=='FILTERS':
				RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+m4eVoJdSU51qs3y8Gg06fZNau7A,url,365,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,S80DwNWuMTZx4El+'_FORGETRESULTS_')
			elif type=='CATEGORIES' and DJrjnM9UKHA2Gp0zOtmR[-2]+'==' in RJGtCsyDgi0X:
				PPlq1nxLf6CamuBI0psW = kKWuMB69mcOHPn3XilFdvp(tuYnONZ6GaCecv4TErUHMdBX2DIb8K,'modified_filters')
				CMzQFXeI08KDwAJ9p = url+'//getposts??'+PPlq1nxLf6CamuBI0psW
				FjQOc5WuzKg0Vikb6tDeNHZP1mS = fgoWEt5zm2NOJM1ZSHGnLpjkv4IC(CMzQFXeI08KDwAJ9p,u7iGbE0HcNz1dPoxQVnKOFLS)
				RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+m4eVoJdSU51qs3y8Gg06fZNau7A,FjQOc5WuzKg0Vikb6tDeNHZP1mS,361,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'filters')
			else: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+m4eVoJdSU51qs3y8Gg06fZNau7A,url,364,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,S80DwNWuMTZx4El)
	return
DJrjnM9UKHA2Gp0zOtmR = ['genre','release-year','nation']
USknWg2JD6Vxv = ['mpaa','genre','release-year','category','Quality','interest','nation','language']
def fgoWEt5zm2NOJM1ZSHGnLpjkv4IC(NPM3HKQ57xe,CMzQFXeI08KDwAJ9p):
	if '/AjaxCenter/RightBar' in NPM3HKQ57xe: NPM3HKQ57xe = NPM3HKQ57xe.replace('/AjaxCenter/RightBar','/AjaxCenter/Filtering')
	NPM3HKQ57xe = NPM3HKQ57xe.replace('//getposts??','::/AjaxCenter/Filtering/')
	NPM3HKQ57xe = NPM3HKQ57xe.replace('==','/')
	NPM3HKQ57xe = NPM3HKQ57xe.replace('&&','/')
	return NPM3HKQ57xe
def kKWuMB69mcOHPn3XilFdvp(UGewLrVFhBCo7MdZ8KEaJWXgYp,mode):
	UGewLrVFhBCo7MdZ8KEaJWXgYp = UGewLrVFhBCo7MdZ8KEaJWXgYp.strip('&&')
	ONVGLC8DSp4,mJuhvt0RPAbBMSla = {},hWGMqtBy4wuLaVcj
	if '==' in UGewLrVFhBCo7MdZ8KEaJWXgYp:
		items = UGewLrVFhBCo7MdZ8KEaJWXgYp.split('&&')
		for ImYg2jxU6Lc9Q1C4Oko in items:
			glBvuIRTJseUHjari,BoSjXKxz41DcneO9UimClE = ImYg2jxU6Lc9Q1C4Oko.split('==')
			ONVGLC8DSp4[glBvuIRTJseUHjari] = BoSjXKxz41DcneO9UimClE
	for key in USknWg2JD6Vxv:
		if key in list(ONVGLC8DSp4.keys()): BoSjXKxz41DcneO9UimClE = ONVGLC8DSp4[key]
		else: BoSjXKxz41DcneO9UimClE = '0'
		if '%' not in BoSjXKxz41DcneO9UimClE: BoSjXKxz41DcneO9UimClE = e1mT8H4dGS3XFyx0KLUA9(BoSjXKxz41DcneO9UimClE)
		if mode=='modified_values' and BoSjXKxz41DcneO9UimClE!='0': mJuhvt0RPAbBMSla = mJuhvt0RPAbBMSla+' + '+BoSjXKxz41DcneO9UimClE
		elif mode=='modified_filters' and BoSjXKxz41DcneO9UimClE!='0': mJuhvt0RPAbBMSla = mJuhvt0RPAbBMSla+'&&'+key+'=='+BoSjXKxz41DcneO9UimClE
		elif mode=='all': mJuhvt0RPAbBMSla = mJuhvt0RPAbBMSla+'&&'+key+'=='+BoSjXKxz41DcneO9UimClE
	mJuhvt0RPAbBMSla = mJuhvt0RPAbBMSla.strip(' + ')
	mJuhvt0RPAbBMSla = mJuhvt0RPAbBMSla.strip('&&')
	return mJuhvt0RPAbBMSla
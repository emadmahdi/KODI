# -*- coding: utf-8 -*-
from yoY3NdGViS import *
xjPuFK3EsIZSiobQ5X = 'GLOBALSEARCH'
n0qFKQWhiBYXoTrvejVHUA4 = '_GLS_'
def ehB18u9sQFRi(JbpxsyQVXmSEYKM3vo847Ckh,O9z5L3KtXqPEMepJQ0,s9ea72VfoygAOFRCWQTH3zmDuLPE,l7COkhRWD9uVS60Pte2NoyAaZn):
	if   JbpxsyQVXmSEYKM3vo847Ckh==540: N6NCYivtV4I5rEXq = DP6FSBgNdX1rsvVR()
	elif JbpxsyQVXmSEYKM3vo847Ckh==541: N6NCYivtV4I5rEXq = zplTsogrLvwhke4MG1dOjbPunKm(s9ea72VfoygAOFRCWQTH3zmDuLPE)
	elif JbpxsyQVXmSEYKM3vo847Ckh==542: N6NCYivtV4I5rEXq = KKwBztsuNE0Lgipld3cXPD6Z(s9ea72VfoygAOFRCWQTH3zmDuLPE,O9z5L3KtXqPEMepJQ0,l7COkhRWD9uVS60Pte2NoyAaZn)
	elif JbpxsyQVXmSEYKM3vo847Ckh==543: N6NCYivtV4I5rEXq = UBKwr0Dukp5z6RGi3hdYH81m()
	elif JbpxsyQVXmSEYKM3vo847Ckh==548: N6NCYivtV4I5rEXq = Wea5ALrQv7CbUgSDfis(O9z5L3KtXqPEMepJQ0,s9ea72VfoygAOFRCWQTH3zmDuLPE)
	elif JbpxsyQVXmSEYKM3vo847Ckh==549: N6NCYivtV4I5rEXq = lPwaAjFTMG4n7iSLkXcEuK0Zm(s9ea72VfoygAOFRCWQTH3zmDuLPE)
	else: N6NCYivtV4I5rEXq = False
	return N6NCYivtV4I5rEXq
def DP6FSBgNdX1rsvVR():
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','بحث جديد لجميع المواقع',hWGMqtBy4wuLaVcj,549)
	RLDCGt8kq3OVmnzgx1rbi2f7F('link','كيف يعمل بحث جميع المواقع','',543)
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+'==== كلمات البحث المخزنة ===='+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	RDJzSUeO82fTC7NLo = Mqk51CFBym0pIQXZLsOxSJ(MM5Dx39f7ULhcJsRptzIowP,'dict','GLOBALSEARCH_SPLITTED_ALL')
	if RDJzSUeO82fTC7NLo:
		RDJzSUeO82fTC7NLo = RDJzSUeO82fTC7NLo['__SEQUENCED_COLUMNS__']
		for WZMblRwhQNn9Gqo in reversed(RDJzSUeO82fTC7NLo):
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',WZMblRwhQNn9Gqo,hWGMqtBy4wuLaVcj,549,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,WZMblRwhQNn9Gqo)
	return
def lPwaAjFTMG4n7iSLkXcEuK0Zm(WZMblRwhQNn9Gqo):
	if not WZMblRwhQNn9Gqo:
		WZMblRwhQNn9Gqo = TrzfUidpv1LyAYqwexHJDuS()
		if not WZMblRwhQNn9Gqo: return
		WZMblRwhQNn9Gqo = WZMblRwhQNn9Gqo.lower()
	I4IpiuxdmFPbrsfTvtj = WZMblRwhQNn9Gqo.replace(n0qFKQWhiBYXoTrvejVHUA4,hWGMqtBy4wuLaVcj)
	LRpZG0U5DJiNsj1te2MfSIT(I4IpiuxdmFPbrsfTvtj,'_ALL',True)
	RLDCGt8kq3OVmnzgx1rbi2f7F('link','بحث جماعي للمواقع - '+I4IpiuxdmFPbrsfTvtj,'search_sites_all',542,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,I4IpiuxdmFPbrsfTvtj)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','بحث منفرد للمواقع - '+I4IpiuxdmFPbrsfTvtj,hWGMqtBy4wuLaVcj,541,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,I4IpiuxdmFPbrsfTvtj)
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+'===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','نتائج البحث مفصلة - '+I4IpiuxdmFPbrsfTvtj,'opened_sites_all',542,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,I4IpiuxdmFPbrsfTvtj)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','نتائج البحث مقسمة - '+I4IpiuxdmFPbrsfTvtj,'listed_sites_all',542,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,I4IpiuxdmFPbrsfTvtj)
	return
def LRpZG0U5DJiNsj1te2MfSIT(V5MjDyYOfZu9kQ,uuZfrcpgHDqoInt7LVvaY0m,LV3fQKgB8hoS2):
	if uuZfrcpgHDqoInt7LVvaY0m=='_ALL': Qu4D7S0rdb = '_GLS_'
	elif uuZfrcpgHDqoInt7LVvaY0m=='_GOOGLE': Qu4D7S0rdb = '_GOS_'
	lwLP5UtpHn8x947z = Mqk51CFBym0pIQXZLsOxSJ(MM5Dx39f7ULhcJsRptzIowP,'list','GLOBALSEARCH_SPLITTED'+uuZfrcpgHDqoInt7LVvaY0m,V5MjDyYOfZu9kQ)
	osDnlxRvmPJeAF = Mqk51CFBym0pIQXZLsOxSJ(MM5Dx39f7ULhcJsRptzIowP,'list','GLOBALSEARCH_SPLITTED'+uuZfrcpgHDqoInt7LVvaY0m,Qu4D7S0rdb+V5MjDyYOfZu9kQ)
	pMPR1Cc0usZ6nJTU(MM5Dx39f7ULhcJsRptzIowP,'GLOBALSEARCH_SPLITTED'+uuZfrcpgHDqoInt7LVvaY0m,V5MjDyYOfZu9kQ)
	pMPR1Cc0usZ6nJTU(MM5Dx39f7ULhcJsRptzIowP,'GLOBALSEARCH_SPLITTED'+uuZfrcpgHDqoInt7LVvaY0m,Qu4D7S0rdb+V5MjDyYOfZu9kQ)
	TSQFdNnRDW0vuKe5 = lwLP5UtpHn8x947z+osDnlxRvmPJeAF
	if TSQFdNnRDW0vuKe5 and LV3fQKgB8hoS2: V5MjDyYOfZu9kQ = Qu4D7S0rdb+V5MjDyYOfZu9kQ
	BxuD7iQRpW1(MM5Dx39f7ULhcJsRptzIowP,'GLOBALSEARCH_SPLITTED'+uuZfrcpgHDqoInt7LVvaY0m,V5MjDyYOfZu9kQ,TSQFdNnRDW0vuKe5,AoRzutVGQfLjYMwdCngZPxs)
	return
def SnKDeXQwcj7UMkmtG8OpBz(uuZfrcpgHDqoInt7LVvaY0m):
	dHPVDWfG4jX5e6QEo0CKh = XVmKrby29eCGMnlEY6jz0HNOR(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'رسالة من المبرمج','هل تريد مسح جميع كلمات البحث المخزنة في البرنامج ؟!!')
	if dHPVDWfG4jX5e6QEo0CKh!=1: return
	pMPR1Cc0usZ6nJTU(MM5Dx39f7ULhcJsRptzIowP,'GLOBALSEARCH_SPLITTED'+uuZfrcpgHDqoInt7LVvaY0m)
	pMPR1Cc0usZ6nJTU(MM5Dx39f7ULhcJsRptzIowP,'GLOBALSEARCH_DETAILED'+uuZfrcpgHDqoInt7LVvaY0m)
	pMPR1Cc0usZ6nJTU(MM5Dx39f7ULhcJsRptzIowP,'GLOBALSEARCH_DIVIDED'+uuZfrcpgHDqoInt7LVvaY0m)
	if uuZfrcpgHDqoInt7LVvaY0m=='_GOOGLE': pMPR1Cc0usZ6nJTU(MM5Dx39f7ULhcJsRptzIowP,'GOOGLESEARCH_RESULTS')
	BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'رسالة من المبرمج','تم بنجاح مسح جميع كلمات البحث المخزنة في البرنامج')
	return
def KKwBztsuNE0Lgipld3cXPD6Z(tA5Zj46kJMm0hsFXLw,EqJbQGCBZ4RwWyNHxUlIpK310F,LSKx8vJUqhnRCZrYPV2TH49dG1c=hWGMqtBy4wuLaVcj,II4jAxS3WnUQcY8gKGsEM90PX=eFskjYoBzr7Ua80Vvi,llgsTkKuWn={}):
	YiyqI7BcMLeu6sZ,q5UYTM6f3JrEKPXCSbA,C0I2uolqHY8ZyL,Zhci3klCyWmtqn7OfM8UuvzAG59L,QqVgxXWo02 = [],{},{},{},{}
	if '_all' in EqJbQGCBZ4RwWyNHxUlIpK310F: uuZfrcpgHDqoInt7LVvaY0m,A5iw9HPEgZxu8eatLhYmvKRCIBjUT,Qu4D7S0rdb = '_ALL','_all','_GLS_'
	elif '_google' in EqJbQGCBZ4RwWyNHxUlIpK310F: uuZfrcpgHDqoInt7LVvaY0m,A5iw9HPEgZxu8eatLhYmvKRCIBjUT,Qu4D7S0rdb = '_GOOGLE','_google','_GOS_'
	if EqJbQGCBZ4RwWyNHxUlIpK310F in ['listed_sites'+A5iw9HPEgZxu8eatLhYmvKRCIBjUT,'opened_sites'+A5iw9HPEgZxu8eatLhYmvKRCIBjUT,'closed_sites'+A5iw9HPEgZxu8eatLhYmvKRCIBjUT]:
		if EqJbQGCBZ4RwWyNHxUlIpK310F=='listed_sites'+A5iw9HPEgZxu8eatLhYmvKRCIBjUT: YiyqI7BcMLeu6sZ = Mqk51CFBym0pIQXZLsOxSJ(MM5Dx39f7ULhcJsRptzIowP,'list','GLOBALSEARCH_SPLITTED'+uuZfrcpgHDqoInt7LVvaY0m,Qu4D7S0rdb+tA5Zj46kJMm0hsFXLw)
		elif EqJbQGCBZ4RwWyNHxUlIpK310F=='opened_sites'+A5iw9HPEgZxu8eatLhYmvKRCIBjUT: YiyqI7BcMLeu6sZ = Mqk51CFBym0pIQXZLsOxSJ(MM5Dx39f7ULhcJsRptzIowP,'list','GLOBALSEARCH_DETAILED'+uuZfrcpgHDqoInt7LVvaY0m,tA5Zj46kJMm0hsFXLw)
		elif EqJbQGCBZ4RwWyNHxUlIpK310F=='closed_sites'+A5iw9HPEgZxu8eatLhYmvKRCIBjUT: YiyqI7BcMLeu6sZ = Mqk51CFBym0pIQXZLsOxSJ(MM5Dx39f7ULhcJsRptzIowP,'list','GLOBALSEARCH_DIVIDED'+uuZfrcpgHDqoInt7LVvaY0m,(LSKx8vJUqhnRCZrYPV2TH49dG1c,tA5Zj46kJMm0hsFXLw))
	if not YiyqI7BcMLeu6sZ:
		qkrP6CTSuMFneV0EfAUgxm1RoWt = 'هذا البحث غير موجود في كاش البرنامج \n\n\n'
		LwBM9FdHl8aE3iDh5IgzY02kZ = 'هل تريد الآن البحث في جميع المواقع عن \n "'+soMVfbr6WtpNlcSA+Mpsm2VF1OBnCRvK3qf6+tA5Zj46kJMm0hsFXLw+Mpsm2VF1OBnCRvK3qf6+YYSh2J6BIrsm8+'" \n علما أن هذا البحث قد يحتاج بعض الوقت'
		if EqJbQGCBZ4RwWyNHxUlIpK310F=='search_sites'+A5iw9HPEgZxu8eatLhYmvKRCIBjUT: jjEwJpmd2v0oxBRP1Dyu = LwBM9FdHl8aE3iDh5IgzY02kZ
		else: jjEwJpmd2v0oxBRP1Dyu = qkrP6CTSuMFneV0EfAUgxm1RoWt+LwBM9FdHl8aE3iDh5IgzY02kZ
		dHPVDWfG4jX5e6QEo0CKh = XVmKrby29eCGMnlEY6jz0HNOR(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'رسالة من المبرمج',jjEwJpmd2v0oxBRP1Dyu)
		if dHPVDWfG4jX5e6QEo0CKh!=1: return
		PEgHa6TQ94mRGvDipcw5LsZfKzh(False,False,False)
		KteLZCbM8W0FqE2OBx1(pGYKHZgqFX3B,qhVEWvetzXLOcr1(xjPuFK3EsIZSiobQ5X)+'   Search For: [ '+tA5Zj46kJMm0hsFXLw+' ]')
		pFKNLPmoEiWV9Aj6IbGtMZ12Dec = 1
		for ITlpOFqLn7W2hYkdijCogm in II4jAxS3WnUQcY8gKGsEM90PX:
			rruCeVzsktRxGDjBm = llgsTkKuWn[ITlpOFqLn7W2hYkdijCogm] if llgsTkKuWn else tA5Zj46kJMm0hsFXLw
			try: OLEaRvPrIK,jybQBYEnf41IACTROeGlDdP9z,lr6UH3CkoIi9tuabRW4Vwe1 = CPGup68qUQdti5IVeS7kXRA(ITlpOFqLn7W2hYkdijCogm)
			except: continue
			q5UYTM6f3JrEKPXCSbA[ITlpOFqLn7W2hYkdijCogm] = []
			T0E1NY7V4pLXyHtxCkfw8mWUd3n9 = '_NODIALOGS_'
			if '-' in ITlpOFqLn7W2hYkdijCogm: T0E1NY7V4pLXyHtxCkfw8mWUd3n9 = T0E1NY7V4pLXyHtxCkfw8mWUd3n9+'_REMEMBERRESULTS__'+ITlpOFqLn7W2hYkdijCogm+'_'
			if pFKNLPmoEiWV9Aj6IbGtMZ12Dec:
				HB5PvxRhwM.sleep(0.75)
				QqVgxXWo02[ITlpOFqLn7W2hYkdijCogm] = KCTRe67wVy.Thread(target=jybQBYEnf41IACTROeGlDdP9z,args=(rruCeVzsktRxGDjBm+T0E1NY7V4pLXyHtxCkfw8mWUd3n9,))
				QqVgxXWo02[ITlpOFqLn7W2hYkdijCogm].start()
			else: jybQBYEnf41IACTROeGlDdP9z(rruCeVzsktRxGDjBm+T0E1NY7V4pLXyHtxCkfw8mWUd3n9)
			OnsAxhdVjZF(J72F0jRI6A(ITlpOFqLn7W2hYkdijCogm),hWGMqtBy4wuLaVcj,HB5PvxRhwM=1000)
		if pFKNLPmoEiWV9Aj6IbGtMZ12Dec:
			HB5PvxRhwM.sleep(2)
			for ITlpOFqLn7W2hYkdijCogm in II4jAxS3WnUQcY8gKGsEM90PX: QqVgxXWo02[ITlpOFqLn7W2hYkdijCogm].join(10)
			HB5PvxRhwM.sleep(2)
		for ITlpOFqLn7W2hYkdijCogm in II4jAxS3WnUQcY8gKGsEM90PX:
			try: OLEaRvPrIK,jybQBYEnf41IACTROeGlDdP9z,lr6UH3CkoIi9tuabRW4Vwe1 = CPGup68qUQdti5IVeS7kXRA(ITlpOFqLn7W2hYkdijCogm)
			except: continue
			for EbAdj82tGKVCH1 in vNRpDl1awktg7QP4m0KGqMTS2i:
				udRvjXt9cAfha5ZsBP3U,j4lHpxXvnF2VtwBb1T9PaJEm3,O9z5L3KtXqPEMepJQ0,JbpxsyQVXmSEYKM3vo847Ckh,nWE8aO53lFfD,l7COkhRWD9uVS60Pte2NoyAaZn,s9ea72VfoygAOFRCWQTH3zmDuLPE,MH5c7Nekugx8O1AQjInRWyT64GV,SX7OT3VLGp2iQm = EbAdj82tGKVCH1
				if lr6UH3CkoIi9tuabRW4Vwe1 in j4lHpxXvnF2VtwBb1T9PaJEm3:
					if 'IPTV-' in ITlpOFqLn7W2hYkdijCogm and (239>=JbpxsyQVXmSEYKM3vo847Ckh>=230 or 289>=JbpxsyQVXmSEYKM3vo847Ckh>=280):
						if EbAdj82tGKVCH1 in q5UYTM6f3JrEKPXCSbA['IPTV-LIVE']: continue
						if EbAdj82tGKVCH1 in q5UYTM6f3JrEKPXCSbA['IPTV-MOVIES']: continue
						if EbAdj82tGKVCH1 in q5UYTM6f3JrEKPXCSbA['IPTV-SERIES']: continue
						if 'صفحة' not in j4lHpxXvnF2VtwBb1T9PaJEm3:
							if   udRvjXt9cAfha5ZsBP3U=='live': ITlpOFqLn7W2hYkdijCogm = 'IPTV-LIVE'
							elif udRvjXt9cAfha5ZsBP3U=='video': ITlpOFqLn7W2hYkdijCogm = 'IPTV-MOVIES'
							elif udRvjXt9cAfha5ZsBP3U=='folder': ITlpOFqLn7W2hYkdijCogm = 'IPTV-SERIES'
						else:
							if   'LIVE' in O9z5L3KtXqPEMepJQ0: ITlpOFqLn7W2hYkdijCogm = 'IPTV-LIVE'
							elif 'MOVIES' in O9z5L3KtXqPEMepJQ0: ITlpOFqLn7W2hYkdijCogm = 'IPTV-MOVIES'
							elif 'SERIES' in O9z5L3KtXqPEMepJQ0: ITlpOFqLn7W2hYkdijCogm = 'IPTV-SERIES'
					elif 'M3U-' in ITlpOFqLn7W2hYkdijCogm and 729>=JbpxsyQVXmSEYKM3vo847Ckh>=710:
						if EbAdj82tGKVCH1 in q5UYTM6f3JrEKPXCSbA['M3U-LIVE']: continue
						if EbAdj82tGKVCH1 in q5UYTM6f3JrEKPXCSbA['M3U-MOVIES']: continue
						if EbAdj82tGKVCH1 in q5UYTM6f3JrEKPXCSbA['M3U-SERIES']: continue
						if 'صفحة' not in j4lHpxXvnF2VtwBb1T9PaJEm3:
							if   udRvjXt9cAfha5ZsBP3U=='live': ITlpOFqLn7W2hYkdijCogm = 'M3U-LIVE'
							elif udRvjXt9cAfha5ZsBP3U=='video': ITlpOFqLn7W2hYkdijCogm = 'M3U-MOVIES'
							elif udRvjXt9cAfha5ZsBP3U=='folder': ITlpOFqLn7W2hYkdijCogm = 'M3U-SERIES'
						else:
							if   'LIVE' in O9z5L3KtXqPEMepJQ0: ITlpOFqLn7W2hYkdijCogm = 'M3U-LIVE'
							elif 'MOVIES' in O9z5L3KtXqPEMepJQ0: ITlpOFqLn7W2hYkdijCogm = 'M3U-MOVIES'
							elif 'SERIES' in O9z5L3KtXqPEMepJQ0: ITlpOFqLn7W2hYkdijCogm = 'M3U-SERIES'
					elif 'YOUTUBE-' in ITlpOFqLn7W2hYkdijCogm and 149>=JbpxsyQVXmSEYKM3vo847Ckh>=140:
						if EbAdj82tGKVCH1 in q5UYTM6f3JrEKPXCSbA['YOUTUBE-CHANNELS']: continue
						if EbAdj82tGKVCH1 in q5UYTM6f3JrEKPXCSbA['YOUTUBE-PLAYLISTS']: continue
						if EbAdj82tGKVCH1 in q5UYTM6f3JrEKPXCSbA['YOUTUBE-VIDEOS']: continue
						if 'صفحة أخرى' in j4lHpxXvnF2VtwBb1T9PaJEm3 or ':: ' in j4lHpxXvnF2VtwBb1T9PaJEm3:
							continue
						else:
							if   JbpxsyQVXmSEYKM3vo847Ckh==144 and 'USER' in j4lHpxXvnF2VtwBb1T9PaJEm3: ITlpOFqLn7W2hYkdijCogm = 'YOUTUBE-CHANNELS'
							elif JbpxsyQVXmSEYKM3vo847Ckh==144 and 'CHNL' in j4lHpxXvnF2VtwBb1T9PaJEm3: ITlpOFqLn7W2hYkdijCogm = 'YOUTUBE-CHANNELS'
							elif JbpxsyQVXmSEYKM3vo847Ckh==144 and 'LIST' in j4lHpxXvnF2VtwBb1T9PaJEm3: ITlpOFqLn7W2hYkdijCogm = 'YOUTUBE-PLAYLISTS'
							elif JbpxsyQVXmSEYKM3vo847Ckh==143: ITlpOFqLn7W2hYkdijCogm = 'YOUTUBE-VIDEOS'
							else: continue
					elif 'DAILYMOTION-' in ITlpOFqLn7W2hYkdijCogm and 419>=JbpxsyQVXmSEYKM3vo847Ckh>=400:
						if EbAdj82tGKVCH1 in q5UYTM6f3JrEKPXCSbA['DAILYMOTION-PLAYLISTS']: continue
						if EbAdj82tGKVCH1 in q5UYTM6f3JrEKPXCSbA['DAILYMOTION-CHANNELS']: continue
						if EbAdj82tGKVCH1 in q5UYTM6f3JrEKPXCSbA['DAILYMOTION-VIDEOS']: continue
						if EbAdj82tGKVCH1 in q5UYTM6f3JrEKPXCSbA['DAILYMOTION-LIVES']: continue
						if EbAdj82tGKVCH1 in q5UYTM6f3JrEKPXCSbA['DAILYMOTION-HASHTAGS']: continue
						if   JbpxsyQVXmSEYKM3vo847Ckh in [401,405]: ITlpOFqLn7W2hYkdijCogm = 'DAILYMOTION-PLAYLISTS'
						elif JbpxsyQVXmSEYKM3vo847Ckh in [402,406]: ITlpOFqLn7W2hYkdijCogm = 'DAILYMOTION-CHANNELS'
						elif JbpxsyQVXmSEYKM3vo847Ckh in [404]: ITlpOFqLn7W2hYkdijCogm = 'DAILYMOTION-VIDEOS'
						elif JbpxsyQVXmSEYKM3vo847Ckh in [415]: ITlpOFqLn7W2hYkdijCogm = 'DAILYMOTION-LIVES'
						elif JbpxsyQVXmSEYKM3vo847Ckh in [416]: ITlpOFqLn7W2hYkdijCogm = 'DAILYMOTION-HASHTAGS'
					elif 'PANET-' in ITlpOFqLn7W2hYkdijCogm and 39>=JbpxsyQVXmSEYKM3vo847Ckh>=30:
						if EbAdj82tGKVCH1 in q5UYTM6f3JrEKPXCSbA['PANET-SERIES']: continue
						if EbAdj82tGKVCH1 in q5UYTM6f3JrEKPXCSbA['PANET-MOVIES']: continue
						if   JbpxsyQVXmSEYKM3vo847Ckh in [32,39]: ITlpOFqLn7W2hYkdijCogm = 'PANET-SERIES'
						elif JbpxsyQVXmSEYKM3vo847Ckh in [33,39]: ITlpOFqLn7W2hYkdijCogm = 'PANET-MOVIES'
					elif 'IFILM-' in ITlpOFqLn7W2hYkdijCogm and 29>=JbpxsyQVXmSEYKM3vo847Ckh>=20:
						if EbAdj82tGKVCH1 in q5UYTM6f3JrEKPXCSbA['IFILM-ARABIC']: continue
						if EbAdj82tGKVCH1 in q5UYTM6f3JrEKPXCSbA['IFILM-ENGLISH']: continue
						if   '/ar.' in O9z5L3KtXqPEMepJQ0: ITlpOFqLn7W2hYkdijCogm = 'IFILM-ARABIC'
						elif '/en.' in O9z5L3KtXqPEMepJQ0: ITlpOFqLn7W2hYkdijCogm = 'IFILM-ENGLISH'
					q5UYTM6f3JrEKPXCSbA[ITlpOFqLn7W2hYkdijCogm].append(EbAdj82tGKVCH1)
		for ITlpOFqLn7W2hYkdijCogm in list(q5UYTM6f3JrEKPXCSbA.keys()):
			C0I2uolqHY8ZyL[ITlpOFqLn7W2hYkdijCogm] = []
			Zhci3klCyWmtqn7OfM8UuvzAG59L[ITlpOFqLn7W2hYkdijCogm] = []
			for udRvjXt9cAfha5ZsBP3U,j4lHpxXvnF2VtwBb1T9PaJEm3,O9z5L3KtXqPEMepJQ0,JbpxsyQVXmSEYKM3vo847Ckh,nWE8aO53lFfD,l7COkhRWD9uVS60Pte2NoyAaZn,s9ea72VfoygAOFRCWQTH3zmDuLPE,MH5c7Nekugx8O1AQjInRWyT64GV,SX7OT3VLGp2iQm in q5UYTM6f3JrEKPXCSbA[ITlpOFqLn7W2hYkdijCogm]:
				EbAdj82tGKVCH1 = (udRvjXt9cAfha5ZsBP3U,j4lHpxXvnF2VtwBb1T9PaJEm3,O9z5L3KtXqPEMepJQ0,JbpxsyQVXmSEYKM3vo847Ckh,nWE8aO53lFfD,l7COkhRWD9uVS60Pte2NoyAaZn,s9ea72VfoygAOFRCWQTH3zmDuLPE,MH5c7Nekugx8O1AQjInRWyT64GV,SX7OT3VLGp2iQm)
				if 'صفحة' in j4lHpxXvnF2VtwBb1T9PaJEm3 and udRvjXt9cAfha5ZsBP3U=='folder': Zhci3klCyWmtqn7OfM8UuvzAG59L[ITlpOFqLn7W2hYkdijCogm].append(EbAdj82tGKVCH1)
				else: C0I2uolqHY8ZyL[ITlpOFqLn7W2hYkdijCogm].append(EbAdj82tGKVCH1)
		T9ZUCcfYi4kOHdN1nW,jjqmDBrWdvgTRU9YkKVCto3cAlui = [],[]
		lPGbBZQnIcexgjzihvH0Oro85dk = list(C0I2uolqHY8ZyL.keys())
		OxHBLDKlTgRe3zEY = JTxDNUKHZgh0YvcjWIBCdeP7(lPGbBZQnIcexgjzihvH0Oro85dk)
		Z6eIWjyb59znBN2LHkCshd1 = []
		for ITlpOFqLn7W2hYkdijCogm in OxHBLDKlTgRe3zEY:
			if 'tuple' in str(type(ITlpOFqLn7W2hYkdijCogm)):
				Z6eIWjyb59znBN2LHkCshd1 = [ITlpOFqLn7W2hYkdijCogm]
				continue
			if ITlpOFqLn7W2hYkdijCogm not in II4jAxS3WnUQcY8gKGsEM90PX: continue
			if C0I2uolqHY8ZyL[ITlpOFqLn7W2hYkdijCogm]:
				oqpAy6Nit0k = J72F0jRI6A(ITlpOFqLn7W2hYkdijCogm)
				YFwIrMbjz9ospa4Zt3CTl7iA6G0V = [('link',soMVfbr6WtpNlcSA+'===== '+oqpAy6Nit0k+' ====='+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj)]
				if 0: Etb3JvkPwzreyumG = tA5Zj46kJMm0hsFXLw+' - '+'بحث'+Mpsm2VF1OBnCRvK3qf6+oqpAy6Nit0k
				else: Etb3JvkPwzreyumG = 'بحث'+Mpsm2VF1OBnCRvK3qf6+oqpAy6Nit0k+' - '+tA5Zj46kJMm0hsFXLw
				if len(C0I2uolqHY8ZyL[ITlpOFqLn7W2hYkdijCogm])<8: YJtRT6EFMIlDAobNjk1VW3Qexsy = []
				else:
					iis8oUK5x40CJTOPWYNFhLQEgBMb = hXB0vKVQ5PRI91SDTprMdfuHEm4+Etb3JvkPwzreyumG+YYSh2J6BIrsm8
					YJtRT6EFMIlDAobNjk1VW3Qexsy = [('folder',Qu4D7S0rdb+iis8oUK5x40CJTOPWYNFhLQEgBMb,'closed_sites'+A5iw9HPEgZxu8eatLhYmvKRCIBjUT,542,hWGMqtBy4wuLaVcj,ITlpOFqLn7W2hYkdijCogm,tA5Zj46kJMm0hsFXLw,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj)]
				ByD7mUj4Rq0FXEnx5tibSLYck = C0I2uolqHY8ZyL[ITlpOFqLn7W2hYkdijCogm]+Zhci3klCyWmtqn7OfM8UuvzAG59L[ITlpOFqLn7W2hYkdijCogm]
				Ux2Rsvc0jr7qgn1fi4 = Z6eIWjyb59znBN2LHkCshd1+YFwIrMbjz9ospa4Zt3CTl7iA6G0V+ByD7mUj4Rq0FXEnx5tibSLYck[:7]+YJtRT6EFMIlDAobNjk1VW3Qexsy
				T9ZUCcfYi4kOHdN1nW += Ux2Rsvc0jr7qgn1fi4
				OIHVW4XBb3oih9yMfltgq5r8TPYnRz = [('folder',Qu4D7S0rdb+Etb3JvkPwzreyumG,'closed_sites'+A5iw9HPEgZxu8eatLhYmvKRCIBjUT,542,hWGMqtBy4wuLaVcj,ITlpOFqLn7W2hYkdijCogm,tA5Zj46kJMm0hsFXLw,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj)]
				AjIrVtZ8fnpdPuoCg1kS40OXRxzG = Z6eIWjyb59znBN2LHkCshd1+OIHVW4XBb3oih9yMfltgq5r8TPYnRz
				jjqmDBrWdvgTRU9YkKVCto3cAlui += AjIrVtZ8fnpdPuoCg1kS40OXRxzG
				BxuD7iQRpW1(MM5Dx39f7ULhcJsRptzIowP,'GLOBALSEARCH_DIVIDED'+uuZfrcpgHDqoInt7LVvaY0m,(ITlpOFqLn7W2hYkdijCogm,tA5Zj46kJMm0hsFXLw),ByD7mUj4Rq0FXEnx5tibSLYck,AoRzutVGQfLjYMwdCngZPxs)
				Z6eIWjyb59znBN2LHkCshd1 = []
		BxuD7iQRpW1(MM5Dx39f7ULhcJsRptzIowP,'GLOBALSEARCH_DETAILED'+uuZfrcpgHDqoInt7LVvaY0m,tA5Zj46kJMm0hsFXLw,T9ZUCcfYi4kOHdN1nW,AoRzutVGQfLjYMwdCngZPxs)
		pMPR1Cc0usZ6nJTU(MM5Dx39f7ULhcJsRptzIowP,'GLOBALSEARCH_SPLITTED'+uuZfrcpgHDqoInt7LVvaY0m,tA5Zj46kJMm0hsFXLw)
		BxuD7iQRpW1(MM5Dx39f7ULhcJsRptzIowP,'GLOBALSEARCH_SPLITTED'+uuZfrcpgHDqoInt7LVvaY0m,Qu4D7S0rdb+tA5Zj46kJMm0hsFXLw,jjqmDBrWdvgTRU9YkKVCto3cAlui,AoRzutVGQfLjYMwdCngZPxs)
		BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'رسالة من المبرمج','البحث الجماعي انتهى بنجاح \n\n تم تخزين النتائج في كاش البرنامج لمدة ثلاثين يوم لكي تستطيع العودة إليها بدون عمل بحث جديد')
		YiyqI7BcMLeu6sZ = jjqmDBrWdvgTRU9YkKVCto3cAlui if EqJbQGCBZ4RwWyNHxUlIpK310F=='listed_sites'+A5iw9HPEgZxu8eatLhYmvKRCIBjUT and jjqmDBrWdvgTRU9YkKVCto3cAlui else T9ZUCcfYi4kOHdN1nW
	if EqJbQGCBZ4RwWyNHxUlIpK310F in ['listed_sites'+A5iw9HPEgZxu8eatLhYmvKRCIBjUT,'opened_sites'+A5iw9HPEgZxu8eatLhYmvKRCIBjUT,'closed_sites'+A5iw9HPEgZxu8eatLhYmvKRCIBjUT]:
		for udRvjXt9cAfha5ZsBP3U,j4lHpxXvnF2VtwBb1T9PaJEm3,O9z5L3KtXqPEMepJQ0,JbpxsyQVXmSEYKM3vo847Ckh,nWE8aO53lFfD,l7COkhRWD9uVS60Pte2NoyAaZn,s9ea72VfoygAOFRCWQTH3zmDuLPE,MH5c7Nekugx8O1AQjInRWyT64GV,SX7OT3VLGp2iQm in YiyqI7BcMLeu6sZ:
			if EqJbQGCBZ4RwWyNHxUlIpK310F in ['listed_sites'+A5iw9HPEgZxu8eatLhYmvKRCIBjUT,'opened_sites'+A5iw9HPEgZxu8eatLhYmvKRCIBjUT] and 'صفحة' in j4lHpxXvnF2VtwBb1T9PaJEm3 and udRvjXt9cAfha5ZsBP3U=='folder': continue
			RLDCGt8kq3OVmnzgx1rbi2f7F(udRvjXt9cAfha5ZsBP3U,j4lHpxXvnF2VtwBb1T9PaJEm3,O9z5L3KtXqPEMepJQ0,JbpxsyQVXmSEYKM3vo847Ckh,nWE8aO53lFfD,l7COkhRWD9uVS60Pte2NoyAaZn,s9ea72VfoygAOFRCWQTH3zmDuLPE,MH5c7Nekugx8O1AQjInRWyT64GV,SX7OT3VLGp2iQm)
	PEgHa6TQ94mRGvDipcw5LsZfKzh(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj)
	return
def zplTsogrLvwhke4MG1dOjbPunKm(search):
	lPGbBZQnIcexgjzihvH0Oro85dk = ZRzNHsKaInDwbBSWfj9yAmLiXo2xvg
	OxHBLDKlTgRe3zEY = JTxDNUKHZgh0YvcjWIBCdeP7(lPGbBZQnIcexgjzihvH0Oro85dk)
	for ITlpOFqLn7W2hYkdijCogm in OxHBLDKlTgRe3zEY:
		if '-' in ITlpOFqLn7W2hYkdijCogm: continue
		if 'tuple' in str(type(ITlpOFqLn7W2hYkdijCogm)):
			vNRpDl1awktg7QP4m0KGqMTS2i.append(ITlpOFqLn7W2hYkdijCogm)
			continue
		OLEaRvPrIK,jybQBYEnf41IACTROeGlDdP9z,lr6UH3CkoIi9tuabRW4Vwe1 = CPGup68qUQdti5IVeS7kXRA(ITlpOFqLn7W2hYkdijCogm)
		name = J72F0jRI6A(ITlpOFqLn7W2hYkdijCogm)+' - '+search
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',lr6UH3CkoIi9tuabRW4Vwe1+name,ITlpOFqLn7W2hYkdijCogm,548,'','',search)
	return
def Wea5ALrQv7CbUgSDfis(ITlpOFqLn7W2hYkdijCogm,search):
	OLEaRvPrIK,jybQBYEnf41IACTROeGlDdP9z,lr6UH3CkoIi9tuabRW4Vwe1 = CPGup68qUQdti5IVeS7kXRA(ITlpOFqLn7W2hYkdijCogm)
	jybQBYEnf41IACTROeGlDdP9z(search)
	return
def UBKwr0Dukp5z6RGi3hdYH81m():
	BZj61bFtfWLzXp('','','رسالة من المبرمج','هذا البحث يستخدم محركات البحث الصغيرة الموجودة في كل موقع من مواقع البرنامج .. ونتائج هذا البحث تعتمد على دقة وفعالية وبرمجة كل موقع منها\n\nللأسف هذه المحركات الصغيرة لا تفهم جميع تفاصيل الفيديوهات ولا تفهم طريقة تفكير البشر ولا تستطيع إصلاح الأخطاء الإملائية .. ولهذا هي تحتاج دقة كبيرة جدا في اختيار وكتابة كلمات البحث المناسبة الصحيحة الدقيقة حتى تجد لك طلبك')
	return
def JTxDNUKHZgh0YvcjWIBCdeP7(lPGbBZQnIcexgjzihvH0Oro85dk):
	OxHBLDKlTgRe3zEY,Z6eIWjyb59znBN2LHkCshd1 = [],None
	for ITlpOFqLn7W2hYkdijCogm in ZRzNHsKaInDwbBSWfj9yAmLiXo2xvg:
		if ITlpOFqLn7W2hYkdijCogm=='PRIVATE': Z6eIWjyb59znBN2LHkCshd1 = ('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+'مواقع سيرفرات خاصة - قليلة المشاكل'+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,157,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj)
		elif ITlpOFqLn7W2hYkdijCogm=='MIXED': Z6eIWjyb59znBN2LHkCshd1 = ('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+'مواقع سيرفرات خاصة وعامة - كثيرة المشاكل'+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,157,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj)
		elif ITlpOFqLn7W2hYkdijCogm=='PUBLIC': Z6eIWjyb59znBN2LHkCshd1 = ('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+'مواقع سيرفرات عامة - كثيرة المشاكل'+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,157,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj)
		if ITlpOFqLn7W2hYkdijCogm not in lPGbBZQnIcexgjzihvH0Oro85dk: continue
		if Z6eIWjyb59znBN2LHkCshd1:
			OxHBLDKlTgRe3zEY.append(Z6eIWjyb59znBN2LHkCshd1)
			Z6eIWjyb59znBN2LHkCshd1 = None
		if ITlpOFqLn7W2hYkdijCogm not in ['PRIVATE','MIXED','PUBLIC']: OxHBLDKlTgRe3zEY.append(ITlpOFqLn7W2hYkdijCogm)
	return OxHBLDKlTgRe3zEY
def tcSyRGgpXDOeBZCf(tA5Zj46kJMm0hsFXLw=hWGMqtBy4wuLaVcj):
	WZMblRwhQNn9Gqo,T0E1NY7V4pLXyHtxCkfw8mWUd3n9,showDialogs = IVTEJQOiMR2dYta9C(tA5Zj46kJMm0hsFXLw)
	if not WZMblRwhQNn9Gqo:
		WZMblRwhQNn9Gqo = TrzfUidpv1LyAYqwexHJDuS()
		if not WZMblRwhQNn9Gqo: return
		WZMblRwhQNn9Gqo = WZMblRwhQNn9Gqo.lower()
	KteLZCbM8W0FqE2OBx1(pGYKHZgqFX3B,qhVEWvetzXLOcr1(xjPuFK3EsIZSiobQ5X)+'   Search For: [ '+WZMblRwhQNn9Gqo+' ]')
	lKqyOtIAvVY = WZMblRwhQNn9Gqo+T0E1NY7V4pLXyHtxCkfw8mWUd3n9
	if 0: ASJlm0BoFIg46WPK,I4IpiuxdmFPbrsfTvtj = WZMblRwhQNn9Gqo+' - ',hWGMqtBy4wuLaVcj
	else: ASJlm0BoFIg46WPK,I4IpiuxdmFPbrsfTvtj = hWGMqtBy4wuLaVcj,' - '+WZMblRwhQNn9Gqo
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+'مواقع سيرفرات خاصة - قليلة المشاكل'+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,157)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','_M3U_'+ASJlm0BoFIg46WPK+'بحث M3U'+I4IpiuxdmFPbrsfTvtj,hWGMqtBy4wuLaVcj,719,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,lKqyOtIAvVY)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','_IPT_'+ASJlm0BoFIg46WPK+'بحث IPTV'+I4IpiuxdmFPbrsfTvtj,hWGMqtBy4wuLaVcj,239,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,lKqyOtIAvVY)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','_BKR_'+ASJlm0BoFIg46WPK+'بحث موقع بكرا'+I4IpiuxdmFPbrsfTvtj,hWGMqtBy4wuLaVcj,379,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,lKqyOtIAvVY)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','_ART_'+ASJlm0BoFIg46WPK+'بحث موقع تونز عربية'+I4IpiuxdmFPbrsfTvtj,hWGMqtBy4wuLaVcj,739,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,lKqyOtIAvVY)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','_KRB_'+ASJlm0BoFIg46WPK+'بحث موقع قناة كربلاء'+I4IpiuxdmFPbrsfTvtj,hWGMqtBy4wuLaVcj,329,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,lKqyOtIAvVY)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','_FH2_'+ASJlm0BoFIg46WPK+'بحث موقع فاصل الثاني'+I4IpiuxdmFPbrsfTvtj,hWGMqtBy4wuLaVcj,599,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,lKqyOtIAvVY)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','_KTV_'+ASJlm0BoFIg46WPK+'بحث موقع كتكوت تيفي'+I4IpiuxdmFPbrsfTvtj,hWGMqtBy4wuLaVcj,819,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,lKqyOtIAvVY)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','_EB1_'+ASJlm0BoFIg46WPK+'بحث موقع ايجي بيست 1'+I4IpiuxdmFPbrsfTvtj,hWGMqtBy4wuLaVcj,779,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,lKqyOtIAvVY)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','_EB2_'+ASJlm0BoFIg46WPK+'بحث موقع ايجي بيست 2'+I4IpiuxdmFPbrsfTvtj,hWGMqtBy4wuLaVcj,789,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,lKqyOtIAvVY)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','_IFL_'+ASJlm0BoFIg46WPK+'  بحث موقع قناة آي فيلم'+I4IpiuxdmFPbrsfTvtj+FqcVAkh7WjIXHdDKf8nvuyRo,hWGMqtBy4wuLaVcj,29,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,lKqyOtIAvVY)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','_AKO_'+ASJlm0BoFIg46WPK+'بحث موقع أكوام القديم'+I4IpiuxdmFPbrsfTvtj,hWGMqtBy4wuLaVcj,79,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,lKqyOtIAvVY)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','_AKW_'+ASJlm0BoFIg46WPK+'بحث موقع أكوام الجديد'+I4IpiuxdmFPbrsfTvtj,hWGMqtBy4wuLaVcj,249,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,lKqyOtIAvVY)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','_MRF_'+ASJlm0BoFIg46WPK+'بحث موقع قناة المعارف'+I4IpiuxdmFPbrsfTvtj,hWGMqtBy4wuLaVcj,49,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,lKqyOtIAvVY)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','_SHM_'+ASJlm0BoFIg46WPK+'بحث موقع شوف ماكس'+I4IpiuxdmFPbrsfTvtj,hWGMqtBy4wuLaVcj,59,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,lKqyOtIAvVY)
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+'مواقع سيرفرات خاصة وعامة - كثيرة المشاكل'+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,157)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','_LRZ_'+ASJlm0BoFIg46WPK+'بحث موقع لاروزا'+I4IpiuxdmFPbrsfTvtj,hWGMqtBy4wuLaVcj,709,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,lKqyOtIAvVY)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','_FJS_'+ASJlm0BoFIg46WPK+' بحث موقع فجر شو'+I4IpiuxdmFPbrsfTvtj+Mpsm2VF1OBnCRvK3qf6,hWGMqtBy4wuLaVcj,399,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,lKqyOtIAvVY)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','_TVF_'+ASJlm0BoFIg46WPK+'بحث موقع تيفي فان'+I4IpiuxdmFPbrsfTvtj,hWGMqtBy4wuLaVcj,469,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,lKqyOtIAvVY)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','_LDN_'+ASJlm0BoFIg46WPK+'بحث موقع لودي نت'+I4IpiuxdmFPbrsfTvtj,hWGMqtBy4wuLaVcj,459,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,lKqyOtIAvVY)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','_CMN_'+ASJlm0BoFIg46WPK+'بحث موقع سيما ناو'+I4IpiuxdmFPbrsfTvtj,hWGMqtBy4wuLaVcj,309,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,lKqyOtIAvVY)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','_SHN_'+ASJlm0BoFIg46WPK+'بحث موقع شاهد نيوز'+I4IpiuxdmFPbrsfTvtj,hWGMqtBy4wuLaVcj,589,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,lKqyOtIAvVY+'_NODIALOGS_')
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','_ARS_'+ASJlm0BoFIg46WPK+'بحث موقع عرب سييد'+I4IpiuxdmFPbrsfTvtj,hWGMqtBy4wuLaVcj,259,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,lKqyOtIAvVY)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','_CCB_'+ASJlm0BoFIg46WPK+'بحث موقع سيما كلوب'+I4IpiuxdmFPbrsfTvtj,hWGMqtBy4wuLaVcj,829,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,lKqyOtIAvVY)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','_SH4_'+ASJlm0BoFIg46WPK+'بحث موقع شاهد فوريو'+I4IpiuxdmFPbrsfTvtj,hWGMqtBy4wuLaVcj,119,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,lKqyOtIAvVY+'_NODIALOGS_')
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','_SHT_'+ASJlm0BoFIg46WPK+'بحث موقع شوفها تيفي'+I4IpiuxdmFPbrsfTvtj,hWGMqtBy4wuLaVcj,649,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,lKqyOtIAvVY)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','_WC1_'+ASJlm0BoFIg46WPK+'بحث موقع وي سيما 1'+I4IpiuxdmFPbrsfTvtj,hWGMqtBy4wuLaVcj,569,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,lKqyOtIAvVY)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','_WC2_'+ASJlm0BoFIg46WPK+'بحث موقع وي سيما 2'+I4IpiuxdmFPbrsfTvtj,hWGMqtBy4wuLaVcj,1009,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,lKqyOtIAvVY)
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+'مواقع سيرفرات عامة - كثيرة المشاكل'+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,157)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','_TKT_'+ASJlm0BoFIg46WPK+'بحث موقع تكات'+I4IpiuxdmFPbrsfTvtj,hWGMqtBy4wuLaVcj,949,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,lKqyOtIAvVY)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','_FST_'+ASJlm0BoFIg46WPK+'بحث موقع فوستا'+I4IpiuxdmFPbrsfTvtj,hWGMqtBy4wuLaVcj,609,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,lKqyOtIAvVY)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','_FBK_'+ASJlm0BoFIg46WPK+'بحث موقع فبركة'+I4IpiuxdmFPbrsfTvtj,hWGMqtBy4wuLaVcj,629,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,lKqyOtIAvVY)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','_YQT_'+ASJlm0BoFIg46WPK+'بحث موقع ياقوت'+I4IpiuxdmFPbrsfTvtj,hWGMqtBy4wuLaVcj,669,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,lKqyOtIAvVY)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','_SHB_'+ASJlm0BoFIg46WPK+'بحث موقع شبكتي'+I4IpiuxdmFPbrsfTvtj,hWGMqtBy4wuLaVcj,969,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,lKqyOtIAvVY)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','_VRB_'+ASJlm0BoFIg46WPK+'بحث موقع فاربون'+I4IpiuxdmFPbrsfTvtj,hWGMqtBy4wuLaVcj,879,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,lKqyOtIAvVY)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','_BRS_'+ASJlm0BoFIg46WPK+'بحث موقع برستيج'+I4IpiuxdmFPbrsfTvtj,hWGMqtBy4wuLaVcj,659,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,lKqyOtIAvVY)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','_KRM_'+ASJlm0BoFIg46WPK+'بحث موقع كرمالك'+I4IpiuxdmFPbrsfTvtj,hWGMqtBy4wuLaVcj,929,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,lKqyOtIAvVY)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','_ANZ_'+ASJlm0BoFIg46WPK+'بحث موقع انمي زد'+I4IpiuxdmFPbrsfTvtj,hWGMqtBy4wuLaVcj,979,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,lKqyOtIAvVY)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','_FSK_'+ASJlm0BoFIg46WPK+'بحث موقع فاريسكو'+I4IpiuxdmFPbrsfTvtj,hWGMqtBy4wuLaVcj,999,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,lKqyOtIAvVY)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','_HLC_'+ASJlm0BoFIg46WPK+'بحث موقع هلا سيما'+I4IpiuxdmFPbrsfTvtj,hWGMqtBy4wuLaVcj,89,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,lKqyOtIAvVY)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','_MST_'+ASJlm0BoFIg46WPK+'بحث موقع المصطبة'+I4IpiuxdmFPbrsfTvtj,hWGMqtBy4wuLaVcj,869,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,lKqyOtIAvVY)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','_SNT_'+ASJlm0BoFIg46WPK+'بحث موقع شوف نت'+I4IpiuxdmFPbrsfTvtj,hWGMqtBy4wuLaVcj,849,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,lKqyOtIAvVY)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','_DR7_'+ASJlm0BoFIg46WPK+'بحث موقع دراما صح'+I4IpiuxdmFPbrsfTvtj,hWGMqtBy4wuLaVcj,689,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,lKqyOtIAvVY)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','_CFR_'+ASJlm0BoFIg46WPK+'بحث موقع سيما فري'+I4IpiuxdmFPbrsfTvtj,hWGMqtBy4wuLaVcj,839,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,lKqyOtIAvVY)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','_CMF_'+ASJlm0BoFIg46WPK+'بحث موقع سيما فانز'+I4IpiuxdmFPbrsfTvtj,hWGMqtBy4wuLaVcj,99,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,lKqyOtIAvVY)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','_CML_'+ASJlm0BoFIg46WPK+'بحث موقع سيما لايت'+I4IpiuxdmFPbrsfTvtj,hWGMqtBy4wuLaVcj,479,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,lKqyOtIAvVY)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','_C4H_'+ASJlm0BoFIg46WPK+'بحث موقع سيما 400'+I4IpiuxdmFPbrsfTvtj,hWGMqtBy4wuLaVcj,699,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,lKqyOtIAvVY)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','_ABD_'+ASJlm0BoFIg46WPK+'بحث موقع سيما عبدو'+I4IpiuxdmFPbrsfTvtj,hWGMqtBy4wuLaVcj,559,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,lKqyOtIAvVY)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','_AKT_'+ASJlm0BoFIg46WPK+'بحث موقع اكوام تيوب'+I4IpiuxdmFPbrsfTvtj,hWGMqtBy4wuLaVcj,859,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,lKqyOtIAvVY)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','_DCF_'+ASJlm0BoFIg46WPK+'بحث موقع دراما كافيه'+I4IpiuxdmFPbrsfTvtj,hWGMqtBy4wuLaVcj,939,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,lKqyOtIAvVY)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','_FTV_'+ASJlm0BoFIg46WPK+'بحث موقع فوشار تيفي'+I4IpiuxdmFPbrsfTvtj,hWGMqtBy4wuLaVcj,919,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,lKqyOtIAvVY)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','_CWB_'+ASJlm0BoFIg46WPK+'بحث موقع سيما وبس'+I4IpiuxdmFPbrsfTvtj,hWGMqtBy4wuLaVcj,989,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,lKqyOtIAvVY)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','_AHK_'+ASJlm0BoFIg46WPK+'بحث موقع أهواك تيفي'+I4IpiuxdmFPbrsfTvtj,hWGMqtBy4wuLaVcj,619,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,lKqyOtIAvVY)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','_SRT_'+ASJlm0BoFIg46WPK+'بحث موقع سيريس تايم'+I4IpiuxdmFPbrsfTvtj,hWGMqtBy4wuLaVcj,899,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,lKqyOtIAvVY)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','_FVD_'+ASJlm0BoFIg46WPK+'بحث موقع فوشار فيديو'+I4IpiuxdmFPbrsfTvtj,hWGMqtBy4wuLaVcj,909,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,lKqyOtIAvVY)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','_C4P_'+ASJlm0BoFIg46WPK+'بحث موقع سيما فور بي'+I4IpiuxdmFPbrsfTvtj,hWGMqtBy4wuLaVcj,889,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,lKqyOtIAvVY)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','_EB4_'+ASJlm0BoFIg46WPK+'بحث موقع ايجي بيست 4'+I4IpiuxdmFPbrsfTvtj,hWGMqtBy4wuLaVcj,809,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,lKqyOtIAvVY)
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+'مواقع سيرفرات خاصة - قليلة المشاكل'+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,157)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','_YUT_'+ASJlm0BoFIg46WPK+'بحث موقع يوتيوب'+I4IpiuxdmFPbrsfTvtj,hWGMqtBy4wuLaVcj,149,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,lKqyOtIAvVY)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','_DLM_'+ASJlm0BoFIg46WPK+'بحث موقع دايلي موشن'+I4IpiuxdmFPbrsfTvtj,hWGMqtBy4wuLaVcj,409,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,lKqyOtIAvVY)
	return
# -*- coding: utf-8 -*-
from yoY3NdGViS import *
xjPuFK3EsIZSiobQ5X = 'RANDOMS'
n0qFKQWhiBYXoTrvejVHUA4 = '_LST_'
lKNx6dIb1ARcU4C = 4
JSOquE5nQ8RYkmsac = 10
def ehB18u9sQFRi(JbpxsyQVXmSEYKM3vo847Ckh,url,s9ea72VfoygAOFRCWQTH3zmDuLPE,l7COkhRWD9uVS60Pte2NoyAaZn,SX7OT3VLGp2iQm):
	try: BBprgGU1NPZsFqWkyHRi9c = str(SX7OT3VLGp2iQm['folder'])
	except: BBprgGU1NPZsFqWkyHRi9c = hWGMqtBy4wuLaVcj
	if   JbpxsyQVXmSEYKM3vo847Ckh==160: N6NCYivtV4I5rEXq = DP6FSBgNdX1rsvVR()
	elif JbpxsyQVXmSEYKM3vo847Ckh==161: N6NCYivtV4I5rEXq = FQ8HbE0eUCl6K15LcorWOs2Bqta(s9ea72VfoygAOFRCWQTH3zmDuLPE)
	elif JbpxsyQVXmSEYKM3vo847Ckh==162: N6NCYivtV4I5rEXq = jSOhLNUkr95(s9ea72VfoygAOFRCWQTH3zmDuLPE,162)
	elif JbpxsyQVXmSEYKM3vo847Ckh==163: N6NCYivtV4I5rEXq = jSOhLNUkr95(s9ea72VfoygAOFRCWQTH3zmDuLPE,163)
	elif JbpxsyQVXmSEYKM3vo847Ckh==164: N6NCYivtV4I5rEXq = QIVHepFB25bSKJEAPw6NtZn(s9ea72VfoygAOFRCWQTH3zmDuLPE)
	elif JbpxsyQVXmSEYKM3vo847Ckh==165: N6NCYivtV4I5rEXq = AAZ2KnVhs9DgP4fbSxv(url,s9ea72VfoygAOFRCWQTH3zmDuLPE)
	elif JbpxsyQVXmSEYKM3vo847Ckh==166: N6NCYivtV4I5rEXq = uJmPcWFRn1YLEQdMiw6azZt5qbDj(url,s9ea72VfoygAOFRCWQTH3zmDuLPE)
	elif JbpxsyQVXmSEYKM3vo847Ckh==167: N6NCYivtV4I5rEXq = diXP4qk8mQ7WF3nzjsCO92V(url,s9ea72VfoygAOFRCWQTH3zmDuLPE)
	elif JbpxsyQVXmSEYKM3vo847Ckh==168: N6NCYivtV4I5rEXq = JThpcVwEQxy2GRKgMB86WbqC(url,s9ea72VfoygAOFRCWQTH3zmDuLPE)
	elif JbpxsyQVXmSEYKM3vo847Ckh==761: N6NCYivtV4I5rEXq = Bze93rN02OiMVZyxpY45UIKkajgct()
	elif JbpxsyQVXmSEYKM3vo847Ckh==762: N6NCYivtV4I5rEXq = fgW0aUDQVo5Cvsyd1c2Hm3LB()
	elif JbpxsyQVXmSEYKM3vo847Ckh==763: N6NCYivtV4I5rEXq = Ppl7YvB0OwQZLjfob(BBprgGU1NPZsFqWkyHRi9c,s9ea72VfoygAOFRCWQTH3zmDuLPE,l7COkhRWD9uVS60Pte2NoyAaZn)
	elif JbpxsyQVXmSEYKM3vo847Ckh==764: N6NCYivtV4I5rEXq = jW4Suit8BYq(BBprgGU1NPZsFqWkyHRi9c,s9ea72VfoygAOFRCWQTH3zmDuLPE)
	elif JbpxsyQVXmSEYKM3vo847Ckh==765: N6NCYivtV4I5rEXq = ZDpmMzbtaAH(BBprgGU1NPZsFqWkyHRi9c,s9ea72VfoygAOFRCWQTH3zmDuLPE)
	else: N6NCYivtV4I5rEXq = False
	return N6NCYivtV4I5rEXq
def DP6FSBgNdX1rsvVR():
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','قنوات تلفزيون عشوائية',hWGMqtBy4wuLaVcj,161,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'_LIVETV__RANDOM__REMEMBERRESULTS_')
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','قسم عشوائي',hWGMqtBy4wuLaVcj,162,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'_SITES__REMEMBERRESULTS_')
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','فيديوهات عشوائية',hWGMqtBy4wuLaVcj,163,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'_SITES__RANDOM__REMEMBERRESULTS_')
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','فيديوهات بحث عشوائي',hWGMqtBy4wuLaVcj,164,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'_SITES__RANDOM__REMEMBERRESULTS_')
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','فيديوهات عشوائية من قسم',hWGMqtBy4wuLaVcj,763,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'_SITES__RANDOM_')
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','قنوات M3U عشوائية',hWGMqtBy4wuLaVcj,163,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'_M3U__LIVE__RANDOM__REMEMBERRESULTS_')
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','فيديوهات M3U عشوائية',hWGMqtBy4wuLaVcj,163,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'_M3U__VOD__RANDOM__REMEMBERRESULTS_')
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','قسم قنوات M3U عشوائي',hWGMqtBy4wuLaVcj,162,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'_M3U__LIVE__REMEMBERRESULTS_')
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','قسم فيديو M3U عشوائي',hWGMqtBy4wuLaVcj,162,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'_M3U__VOD__REMEMBERRESULTS_')
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','فيديوهات M3U بحث عشوائي',hWGMqtBy4wuLaVcj,164,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'_M3U__RANDOM__REMEMBERRESULTS_')
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','فيديوهات M3U عشوائية من قسم',hWGMqtBy4wuLaVcj,765,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'_M3U__RANDOM__REMEMBERRESULTS_')
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','قنوات IPTV عشوائية',hWGMqtBy4wuLaVcj,163,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'_IPTV__LIVE__RANDOM__REMEMBERRESULTS_')
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','فيديوهات IPTV عشوائية',hWGMqtBy4wuLaVcj,163,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'_IPTV__VOD__RANDOM__REMEMBERRESULTS_')
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','قسم قنوات IPTV عشوائي',hWGMqtBy4wuLaVcj,162,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'_IPTV__LIVE__REMEMBERRESULTS_')
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','قسم فيديو IPTV عشوائي',hWGMqtBy4wuLaVcj,162,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'_IPTV__VOD__REMEMBERRESULTS_')
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','فيديوهات IPTV بحث عشوائي',hWGMqtBy4wuLaVcj,164,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'_IPTV__RANDOM__REMEMBERRESULTS_')
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','فيديوهات IPTV عشوائية من قسم',hWGMqtBy4wuLaVcj,764,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'_IPTV__RANDOM__REMEMBERRESULTS_')
	return
def Bze93rN02OiMVZyxpY45UIKkajgct():
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','_IPT_'+'فيديوهات جميع IPTV',hWGMqtBy4wuLaVcj,764)
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+'===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	for BBprgGU1NPZsFqWkyHRi9c in range(1,SdRCvwxfo1P95Jjb+1):
		n0qFKQWhiBYXoTrvejVHUA4 = '_IP'+str(BBprgGU1NPZsFqWkyHRi9c)+'_'
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+' فيديوهات مجلد '+A7ZIc5uC1nT0PWYHEjb2BfxeV38[BBprgGU1NPZsFqWkyHRi9c],hWGMqtBy4wuLaVcj,764,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,{'folder':BBprgGU1NPZsFqWkyHRi9c})
	return
def fgW0aUDQVo5Cvsyd1c2Hm3LB():
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','_M3U_'+'فيديوهات جميع M3U',hWGMqtBy4wuLaVcj,765)
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+'===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	for BBprgGU1NPZsFqWkyHRi9c in range(1,SdRCvwxfo1P95Jjb+1):
		n0qFKQWhiBYXoTrvejVHUA4 = '_MU'+str(BBprgGU1NPZsFqWkyHRi9c)+'_'
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+' فيديوهات مجلد '+A7ZIc5uC1nT0PWYHEjb2BfxeV38[BBprgGU1NPZsFqWkyHRi9c],hWGMqtBy4wuLaVcj,765,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,{'folder':BBprgGU1NPZsFqWkyHRi9c})
	return
def bsYWPd267BuzDqZ(ITlpOFqLn7W2hYkdijCogm):
	global OvNw7ZhgolRxQem1rMA9,xnrZfsSmWT
	OLEaRvPrIK,jybQBYEnf41IACTROeGlDdP9z,lr6UH3CkoIi9tuabRW4Vwe1 = CPGup68qUQdti5IVeS7kXRA(ITlpOFqLn7W2hYkdijCogm)
	try:
		if 'IFILM' in ITlpOFqLn7W2hYkdijCogm: OLEaRvPrIK(ITlpOFqLn7W2hYkdijCogm)
		else: OLEaRvPrIK()
		uL34oQ7jAtMEG1ahJvdU = False
	except:
		OHVmqy3Zi1()
		uL34oQ7jAtMEG1ahJvdU = True
	ITlpOFqLn7W2hYkdijCogm = J72F0jRI6A(ITlpOFqLn7W2hYkdijCogm)
	if uL34oQ7jAtMEG1ahJvdU:
		OnsAxhdVjZF(ITlpOFqLn7W2hYkdijCogm,'فشل للأسف',HB5PvxRhwM=2000)
		OvNw7ZhgolRxQem1rMA9 += 1
		xnrZfsSmWT += Mpsm2VF1OBnCRvK3qf6+ITlpOFqLn7W2hYkdijCogm
	else: OnsAxhdVjZF(ITlpOFqLn7W2hYkdijCogm,hWGMqtBy4wuLaVcj,HB5PvxRhwM=1000)
	return
def rfzaS51Towi24Akcluq(VgnHm1elsKp0WCBQ=True):
	global OvNw7ZhgolRxQem1rMA9,xnrZfsSmWT
	if not VgnHm1elsKp0WCBQ:
		global FvkuXRitwj
		N6NCYivtV4I5rEXq = Mqk51CFBym0pIQXZLsOxSJ(MM5Dx39f7ULhcJsRptzIowP,'dict','SECTIONS_SITES','SECTIONS_SITES_ALL')
		if N6NCYivtV4I5rEXq:
			FvkuXRitwj = N6NCYivtV4I5rEXq
			return
	dHPVDWfG4jX5e6QEo0CKh = XVmKrby29eCGMnlEY6jz0HNOR('center',hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'رسالة من المبرمج','لكي تملئ هذه القائمة . البرنامج يحتاج أن يفحص جميع مواقع الفيديو التي في البرنامج لكي يستخرج منها فقط الأقسام الرئيسية . ثم يقوم البرنامج بخزن هذه الأقسام حتى لا تحتاج أن تملئها مرة أخرى . عملية ملئ جميع الأقسام تحتاج عادة أقل من 3 دقائق . هل تريد أن تجمع قائمة الأقسام الآن ؟')
	if dHPVDWfG4jX5e6QEo0CKh!=1: return
	PEgHa6TQ94mRGvDipcw5LsZfKzh(False,False,False)
	z0jOxHmWU5Gybin = vNRpDl1awktg7QP4m0KGqMTS2i
	OvNw7ZhgolRxQem1rMA9,xnrZfsSmWT,threads = 0,hWGMqtBy4wuLaVcj,{}
	for ITlpOFqLn7W2hYkdijCogm in Oi4dHUj1o6Is0ewZP7bzA:
		HB5PvxRhwM.sleep(0.75)
		threads[ITlpOFqLn7W2hYkdijCogm] = KCTRe67wVy.Thread(target=bsYWPd267BuzDqZ,args=(ITlpOFqLn7W2hYkdijCogm,))
		threads[ITlpOFqLn7W2hYkdijCogm].start()
		if OvNw7ZhgolRxQem1rMA9>=JSOquE5nQ8RYkmsac: break
	else:
		for ITlpOFqLn7W2hYkdijCogm in list(threads.keys()): threads[ITlpOFqLn7W2hYkdijCogm].join()
	vNRpDl1awktg7QP4m0KGqMTS2i[:] = z0jOxHmWU5Gybin
	if OvNw7ZhgolRxQem1rMA9>=JSOquE5nQ8RYkmsac: BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'رسالة من المبرمج','لديك مشكلة في '+str(OvNw7ZhgolRxQem1rMA9)+' مواقع من مواقع البرنامج ... وسببها قد يكون عدم وجود إنترنيت في جهازك وهي:'+xnrZfsSmWT)
	else:
		BxuD7iQRpW1(MM5Dx39f7ULhcJsRptzIowP,'SECTIONS_SITES','SECTIONS_SITES_ALL',FvkuXRitwj,VWxPgG1p8Z2Ei4DrX7NotvR)
		BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'رسالة من المبرمج','تم جلب جميع الأقسام المتوفرة في البرنامج')
	PEgHa6TQ94mRGvDipcw5LsZfKzh(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj)
	Za2Eugh8Mp1eQYH4()
	return
def Jg6ZBMXEdPzeaRQx2q7kwlcAoS0yur(BBprgGU1NPZsFqWkyHRi9c,T0E1NY7V4pLXyHtxCkfw8mWUd3n9):
	aJb19RQ7MVp = False
	fSGIN9coC3UB = vNRpDl1awktg7QP4m0KGqMTS2i
	vNRpDl1awktg7QP4m0KGqMTS2i[:] = []
	if aJb19RQ7MVp and '_CREATENEW_' not in T0E1NY7V4pLXyHtxCkfw8mWUd3n9:
		N6NCYivtV4I5rEXq = Mqk51CFBym0pIQXZLsOxSJ(MM5Dx39f7ULhcJsRptzIowP,'list','SECTIONS_IPTV','SECTIONS_IPTV_'+BBprgGU1NPZsFqWkyHRi9c)
	elif '_LIVE_' not in T0E1NY7V4pLXyHtxCkfw8mWUd3n9 or '_VOD_' not in T0E1NY7V4pLXyHtxCkfw8mWUd3n9:
		import t2YzocLAmj
		jjEwJpmd2v0oxBRP1Dyu = 'للأسف لديك مشكلة في هذا الموقع . ورسالة الخطأ كان فيها تفاصيل المشكلة . أذا المشكلة ليست حجب فجرب إرسال هذه المشكلة إلى المبرمج من قائمة خدمات البرنامج'
		if '_LIVE_' not in T0E1NY7V4pLXyHtxCkfw8mWUd3n9:
			try: t2YzocLAmj.YDs4gfOMR8rQeSoqnUXwxCEa6BlP1(BBprgGU1NPZsFqWkyHRi9c,'VOD_UNKNOWN_GROUPED_SORTED',hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,T0E1NY7V4pLXyHtxCkfw8mWUd3n9+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'موقع ـIPTV للفيديوهات',jjEwJpmd2v0oxBRP1Dyu)
			try: t2YzocLAmj.YDs4gfOMR8rQeSoqnUXwxCEa6BlP1(BBprgGU1NPZsFqWkyHRi9c,'VOD_MOVIES_GROUPED_SORTED',hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,T0E1NY7V4pLXyHtxCkfw8mWUd3n9+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'موقع ـIPTV للفيديوهات',jjEwJpmd2v0oxBRP1Dyu)
			try: t2YzocLAmj.YDs4gfOMR8rQeSoqnUXwxCEa6BlP1(BBprgGU1NPZsFqWkyHRi9c,'VOD_SERIES_GROUPED_SORTED',hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,T0E1NY7V4pLXyHtxCkfw8mWUd3n9+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'موقع ـIPTV للفيديوهات',jjEwJpmd2v0oxBRP1Dyu)
		if '_VOD_' not in T0E1NY7V4pLXyHtxCkfw8mWUd3n9:
			try: t2YzocLAmj.YDs4gfOMR8rQeSoqnUXwxCEa6BlP1(BBprgGU1NPZsFqWkyHRi9c,'LIVE_UNKNOWN_GROUPED_SORTED',hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,T0E1NY7V4pLXyHtxCkfw8mWUd3n9+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'موقع ـIPTV للقنوات',jjEwJpmd2v0oxBRP1Dyu)
			try: t2YzocLAmj.YDs4gfOMR8rQeSoqnUXwxCEa6BlP1(BBprgGU1NPZsFqWkyHRi9c,'LIVE_GROUPED_SORTED',hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,T0E1NY7V4pLXyHtxCkfw8mWUd3n9+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'موقع ـIPTV للقنوات',jjEwJpmd2v0oxBRP1Dyu)
		N6NCYivtV4I5rEXq = vNRpDl1awktg7QP4m0KGqMTS2i
		if aJb19RQ7MVp: BxuD7iQRpW1(MM5Dx39f7ULhcJsRptzIowP,'SECTIONS_IPTV','SECTIONS_IPTV_'+BBprgGU1NPZsFqWkyHRi9c,N6NCYivtV4I5rEXq,VWxPgG1p8Z2Ei4DrX7NotvR)
	vNRpDl1awktg7QP4m0KGqMTS2i[:] = fSGIN9coC3UB
	return N6NCYivtV4I5rEXq
def hhXjodAECp23zyOJQ(BBprgGU1NPZsFqWkyHRi9c,T0E1NY7V4pLXyHtxCkfw8mWUd3n9):
	aJb19RQ7MVp = False
	fSGIN9coC3UB = vNRpDl1awktg7QP4m0KGqMTS2i
	vNRpDl1awktg7QP4m0KGqMTS2i[:] = []
	if aJb19RQ7MVp and '_CREATENEW_' not in T0E1NY7V4pLXyHtxCkfw8mWUd3n9:
		N6NCYivtV4I5rEXq = Mqk51CFBym0pIQXZLsOxSJ(MM5Dx39f7ULhcJsRptzIowP,'list','SECTIONS_M3U','SECTIONS_M3U_'+BBprgGU1NPZsFqWkyHRi9c)
	elif '_LIVE_' not in T0E1NY7V4pLXyHtxCkfw8mWUd3n9 or '_VOD_' not in T0E1NY7V4pLXyHtxCkfw8mWUd3n9:
		import llfcJ30oFC
		jjEwJpmd2v0oxBRP1Dyu = 'للأسف لديك مشكلة في هذا الموقع . ورسالة الخطأ كان فيها تفاصيل المشكلة . أذا المشكلة ليست حجب فجرب إرسال هذه المشكلة إلى المبرمج من قائمة خدمات البرنامج'
		if '_LIVE_' not in T0E1NY7V4pLXyHtxCkfw8mWUd3n9:
			try: llfcJ30oFC.YDs4gfOMR8rQeSoqnUXwxCEa6BlP1(BBprgGU1NPZsFqWkyHRi9c,'VOD_UNKNOWN_GROUPED_SORTED',hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,T0E1NY7V4pLXyHtxCkfw8mWUd3n9+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'موقع ـM3U للفيديوهات',jjEwJpmd2v0oxBRP1Dyu)
			try: llfcJ30oFC.YDs4gfOMR8rQeSoqnUXwxCEa6BlP1(BBprgGU1NPZsFqWkyHRi9c,'VOD_MOVIES_GROUPED_SORTED',hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,T0E1NY7V4pLXyHtxCkfw8mWUd3n9+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'موقع ـM3U للفيديوهات',jjEwJpmd2v0oxBRP1Dyu)
			try: llfcJ30oFC.YDs4gfOMR8rQeSoqnUXwxCEa6BlP1(BBprgGU1NPZsFqWkyHRi9c,'VOD_SERIES_GROUPED_SORTED',hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,T0E1NY7V4pLXyHtxCkfw8mWUd3n9+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'موقع ـM3U للفيديوهات',jjEwJpmd2v0oxBRP1Dyu)
		if '_VOD_' not in T0E1NY7V4pLXyHtxCkfw8mWUd3n9:
			try: llfcJ30oFC.YDs4gfOMR8rQeSoqnUXwxCEa6BlP1(BBprgGU1NPZsFqWkyHRi9c,'LIVE_UNKNOWN_GROUPED_SORTED',hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,T0E1NY7V4pLXyHtxCkfw8mWUd3n9+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'موقع ـM3U للقنوات',jjEwJpmd2v0oxBRP1Dyu)
			try: llfcJ30oFC.YDs4gfOMR8rQeSoqnUXwxCEa6BlP1(BBprgGU1NPZsFqWkyHRi9c,'LIVE_GROUPED_SORTED',hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,T0E1NY7V4pLXyHtxCkfw8mWUd3n9+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'موقع ـM3U للقنوات',jjEwJpmd2v0oxBRP1Dyu)
		N6NCYivtV4I5rEXq = vNRpDl1awktg7QP4m0KGqMTS2i
		if aJb19RQ7MVp: BxuD7iQRpW1(MM5Dx39f7ULhcJsRptzIowP,'SECTIONS_M3U','SECTIONS_M3U_'+BBprgGU1NPZsFqWkyHRi9c,N6NCYivtV4I5rEXq,VWxPgG1p8Z2Ei4DrX7NotvR)
	vNRpDl1awktg7QP4m0KGqMTS2i[:] = fSGIN9coC3UB
	return N6NCYivtV4I5rEXq
def Ppl7YvB0OwQZLjfob(BBprgGU1NPZsFqWkyHRi9c,T0E1NY7V4pLXyHtxCkfw8mWUd3n9,IuH7soa3qEl5G04mzU):
	if '_CREATENEW_' in T0E1NY7V4pLXyHtxCkfw8mWUd3n9 and IuH7soa3qEl5G04mzU==hWGMqtBy4wuLaVcj: rfzaS51Towi24Akcluq(True)
	elif IuH7soa3qEl5G04mzU: rfzaS51Towi24Akcluq(False)
	ttazZ4gCMJWoABn = T0E1NY7V4pLXyHtxCkfw8mWUd3n9.replace('_CREATENEW_',hWGMqtBy4wuLaVcj).replace('_FORGETRESULTS_',hWGMqtBy4wuLaVcj).replace('_REMEMBERRESULTS_',hWGMqtBy4wuLaVcj)
	if not IuH7soa3qEl5G04mzU:
		RLDCGt8kq3OVmnzgx1rbi2f7F('link','تحديث قائمة الأقسام',hWGMqtBy4wuLaVcj,763,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'_CREATENEW_'+ttazZ4gCMJWoABn,hWGMqtBy4wuLaVcj,{'folder':BBprgGU1NPZsFqWkyHRi9c})
		RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+'===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	pgj1NhfSenwsqXPy2BxZRtbcMCuJOT = ['أفلام','مسلسلات','مسرحيات','برامج','أطفال وكرتون','رمضان','أحدث-أخر','سلاسل','موسيقى','أشهر-أكثر','الآن','ضحك','رياضة','نيتفلكس','ممثلين','بث حي','دينية','سنوات','أخرى']
	ZDiNymFGE46daopj8K9T2qBr1M3Oz = ['افلام','movie','فيلم','فلم']
	H1fiR4odCZLuxmkwISX = ['مسلسل','series']
	yAz7solhG8pmeHfFV = ['مسارح','مسرحيات']
	lXhE6icB5fKxG493 = ['برامج','show','تلفزيون','تليفزيون']
	qk0B2CWOJ3tLn = ['انمي','كرتون','كارتون','kids','طفل','اطفال']
	RFjN4bo7CcDV = ['رمضان']
	Z5sr7Hb9NXJKVG = ['احدث','اخر','موخر','جديد','مضاف','حديث']
	g2MPxnD3uKm1djW4caSEtGNTB = ['سلاسل','سلسله']
	p8uvyk2ildtw4QSn3 = ['اغاني','موسيقى','كليب','حفل','music']
	QZR93OSD4a1gHwVj6KbzCN = ['اكثر','اشهر','مميزه','اعلى','مختاره','مختارات','اقوى']
	quvEPzwByYbj5eSpFQ3im7RtcdH = ['الان','حالي','مثبت','رائج']
	w4nZyMFTfs = ['ضحك','كوميدي']
	a0r4kF8Rxf1S = ['رياضه','كوره','مصارعه','شوت','رياضة']
	fayzSIEwohRL3Fp = ['نيتفلكس','netflix','نيتفليكس']
	bTjQseJSnpPuU4REi73KxhcfFo = ['ممثلين','اشخاص','نجوم']
	wUOB4TVkC1X2hesdItWFf = ['بث حي','live','قناه','قنوات']
	GwRJ90qI2B7 = ['دين','ادعيه','زيارات','لطميات','دعاء','قران','قصائد','رثاء','مرجعيه','اذان','اسلام','تواشيح','خطب','حوزوي','عتبات','مواليد','نواعي','عقائد','اناشيد']
	nx6ARwU0MtlEGq = ['19','20','21','22','23','24','25','26']
	if not IuH7soa3qEl5G04mzU:
		IuH7soa3qEl5G04mzU = 0
		for Xiz8dp1hTOWroGgMj3 in pgj1NhfSenwsqXPy2BxZRtbcMCuJOT:
			IuH7soa3qEl5G04mzU += 1
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+Xiz8dp1hTOWroGgMj3,hWGMqtBy4wuLaVcj,763,hWGMqtBy4wuLaVcj,str(IuH7soa3qEl5G04mzU),ttazZ4gCMJWoABn,hWGMqtBy4wuLaVcj,{'folder':BBprgGU1NPZsFqWkyHRi9c})
	else:
		for j4lHpxXvnF2VtwBb1T9PaJEm3 in sorted(list(FvkuXRitwj.keys())):
			u25Car4veWZpIhniLSUKqH83Gf = j4lHpxXvnF2VtwBb1T9PaJEm3.lower()
			OJx4sYA9nNbtPT5ezmDHdVBk2C7 = []
			if any(BoSjXKxz41DcneO9UimClE in u25Car4veWZpIhniLSUKqH83Gf for BoSjXKxz41DcneO9UimClE in ZDiNymFGE46daopj8K9T2qBr1M3Oz): OJx4sYA9nNbtPT5ezmDHdVBk2C7.append(1)
			if any(BoSjXKxz41DcneO9UimClE in u25Car4veWZpIhniLSUKqH83Gf for BoSjXKxz41DcneO9UimClE in H1fiR4odCZLuxmkwISX): OJx4sYA9nNbtPT5ezmDHdVBk2C7.append(2)
			if any(BoSjXKxz41DcneO9UimClE in u25Car4veWZpIhniLSUKqH83Gf for BoSjXKxz41DcneO9UimClE in yAz7solhG8pmeHfFV): OJx4sYA9nNbtPT5ezmDHdVBk2C7.append(3)
			if any(BoSjXKxz41DcneO9UimClE in u25Car4veWZpIhniLSUKqH83Gf for BoSjXKxz41DcneO9UimClE in lXhE6icB5fKxG493): OJx4sYA9nNbtPT5ezmDHdVBk2C7.append(4)
			if any(BoSjXKxz41DcneO9UimClE in u25Car4veWZpIhniLSUKqH83Gf for BoSjXKxz41DcneO9UimClE in qk0B2CWOJ3tLn): OJx4sYA9nNbtPT5ezmDHdVBk2C7.append(5)
			if any(BoSjXKxz41DcneO9UimClE in u25Car4veWZpIhniLSUKqH83Gf for BoSjXKxz41DcneO9UimClE in RFjN4bo7CcDV): OJx4sYA9nNbtPT5ezmDHdVBk2C7.append(6)
			if any(BoSjXKxz41DcneO9UimClE in u25Car4veWZpIhniLSUKqH83Gf for BoSjXKxz41DcneO9UimClE in Z5sr7Hb9NXJKVG) and u25Car4veWZpIhniLSUKqH83Gf not in ['اخرى']: OJx4sYA9nNbtPT5ezmDHdVBk2C7.append(7)
			if any(BoSjXKxz41DcneO9UimClE in u25Car4veWZpIhniLSUKqH83Gf for BoSjXKxz41DcneO9UimClE in g2MPxnD3uKm1djW4caSEtGNTB): OJx4sYA9nNbtPT5ezmDHdVBk2C7.append(8)
			if any(BoSjXKxz41DcneO9UimClE in u25Car4veWZpIhniLSUKqH83Gf for BoSjXKxz41DcneO9UimClE in p8uvyk2ildtw4QSn3): OJx4sYA9nNbtPT5ezmDHdVBk2C7.append(9)
			if any(BoSjXKxz41DcneO9UimClE in u25Car4veWZpIhniLSUKqH83Gf for BoSjXKxz41DcneO9UimClE in QZR93OSD4a1gHwVj6KbzCN): OJx4sYA9nNbtPT5ezmDHdVBk2C7.append(10)
			if any(BoSjXKxz41DcneO9UimClE in u25Car4veWZpIhniLSUKqH83Gf for BoSjXKxz41DcneO9UimClE in quvEPzwByYbj5eSpFQ3im7RtcdH): OJx4sYA9nNbtPT5ezmDHdVBk2C7.append(11)
			if any(BoSjXKxz41DcneO9UimClE in u25Car4veWZpIhniLSUKqH83Gf for BoSjXKxz41DcneO9UimClE in w4nZyMFTfs): OJx4sYA9nNbtPT5ezmDHdVBk2C7.append(12)
			if any(BoSjXKxz41DcneO9UimClE in u25Car4veWZpIhniLSUKqH83Gf for BoSjXKxz41DcneO9UimClE in a0r4kF8Rxf1S): OJx4sYA9nNbtPT5ezmDHdVBk2C7.append(13)
			if any(BoSjXKxz41DcneO9UimClE in u25Car4veWZpIhniLSUKqH83Gf for BoSjXKxz41DcneO9UimClE in fayzSIEwohRL3Fp): OJx4sYA9nNbtPT5ezmDHdVBk2C7.append(14)
			if any(BoSjXKxz41DcneO9UimClE in u25Car4veWZpIhniLSUKqH83Gf for BoSjXKxz41DcneO9UimClE in bTjQseJSnpPuU4REi73KxhcfFo): OJx4sYA9nNbtPT5ezmDHdVBk2C7.append(15)
			if any(BoSjXKxz41DcneO9UimClE in u25Car4veWZpIhniLSUKqH83Gf for BoSjXKxz41DcneO9UimClE in wUOB4TVkC1X2hesdItWFf): OJx4sYA9nNbtPT5ezmDHdVBk2C7.append(16)
			if any(BoSjXKxz41DcneO9UimClE in u25Car4veWZpIhniLSUKqH83Gf for BoSjXKxz41DcneO9UimClE in GwRJ90qI2B7): OJx4sYA9nNbtPT5ezmDHdVBk2C7.append(17)
			if any(BoSjXKxz41DcneO9UimClE in u25Car4veWZpIhniLSUKqH83Gf for BoSjXKxz41DcneO9UimClE in nx6ARwU0MtlEGq): OJx4sYA9nNbtPT5ezmDHdVBk2C7.append(18)
			if not OJx4sYA9nNbtPT5ezmDHdVBk2C7: OJx4sYA9nNbtPT5ezmDHdVBk2C7 = [19]
			for FFoBbcdLf2A4r3SZUktpHvshCNjgO in OJx4sYA9nNbtPT5ezmDHdVBk2C7:
				if str(FFoBbcdLf2A4r3SZUktpHvshCNjgO)==IuH7soa3qEl5G04mzU:
					RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+j4lHpxXvnF2VtwBb1T9PaJEm3,j4lHpxXvnF2VtwBb1T9PaJEm3,166,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,ttazZ4gCMJWoABn+'_REMEMBERRESULTS_')
	return
def jW4Suit8BYq(BBprgGU1NPZsFqWkyHRi9c,T0E1NY7V4pLXyHtxCkfw8mWUd3n9):
	aJb19RQ7MVp = False
	if aJb19RQ7MVp:
		RLDCGt8kq3OVmnzgx1rbi2f7F('link','تحديث قائمة أقسام IPTV',hWGMqtBy4wuLaVcj,764,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'_CREATENEW_',hWGMqtBy4wuLaVcj,{'folder':BBprgGU1NPZsFqWkyHRi9c})
		RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+'===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	fSGIN9coC3UB = vNRpDl1awktg7QP4m0KGqMTS2i[:]
	import t2YzocLAmj
	if BBprgGU1NPZsFqWkyHRi9c:
		if not t2YzocLAmj.OhBPub8QYNceaq3W(BBprgGU1NPZsFqWkyHRi9c,True): return
		xfsgJZ9tF1dBcEW4bC2e8oPva0D = Jg6ZBMXEdPzeaRQx2q7kwlcAoS0yur(BBprgGU1NPZsFqWkyHRi9c,T0E1NY7V4pLXyHtxCkfw8mWUd3n9)
		kF8wafyIPSEV6p0bigxAq = sorted(xfsgJZ9tF1dBcEW4bC2e8oPva0D,reverse=False,key=lambda key: key[1].lower())
	else:
		if not t2YzocLAmj.OhBPub8QYNceaq3W(hWGMqtBy4wuLaVcj,True): return
		if aJb19RQ7MVp and '_CREATENEW_' not in T0E1NY7V4pLXyHtxCkfw8mWUd3n9:
			kF8wafyIPSEV6p0bigxAq = Mqk51CFBym0pIQXZLsOxSJ(MM5Dx39f7ULhcJsRptzIowP,'list','SECTIONS_IPTV','SECTIONS_IPTV_ALL')
		else:
			otTLRs6Vx0WfyNPrcB51,kF8wafyIPSEV6p0bigxAq,xfsgJZ9tF1dBcEW4bC2e8oPva0D = [],[],[]
			for DD9A4BiEfYmunoFXGTvPl7yO in range(1,SdRCvwxfo1P95Jjb+1):
				kF8wafyIPSEV6p0bigxAq += Jg6ZBMXEdPzeaRQx2q7kwlcAoS0yur(str(DD9A4BiEfYmunoFXGTvPl7yO),T0E1NY7V4pLXyHtxCkfw8mWUd3n9)
			for type,j4lHpxXvnF2VtwBb1T9PaJEm3,url,JbpxsyQVXmSEYKM3vo847Ckh,nWE8aO53lFfD,l7COkhRWD9uVS60Pte2NoyAaZn,s9ea72VfoygAOFRCWQTH3zmDuLPE,MH5c7Nekugx8O1AQjInRWyT64GV,SX7OT3VLGp2iQm in kF8wafyIPSEV6p0bigxAq:
				if s9ea72VfoygAOFRCWQTH3zmDuLPE not in otTLRs6Vx0WfyNPrcB51:
					otTLRs6Vx0WfyNPrcB51.append(s9ea72VfoygAOFRCWQTH3zmDuLPE)
					BYrIj87L2b = type,j4lHpxXvnF2VtwBb1T9PaJEm3,s9ea72VfoygAOFRCWQTH3zmDuLPE,165,nWE8aO53lFfD,l7COkhRWD9uVS60Pte2NoyAaZn,T0E1NY7V4pLXyHtxCkfw8mWUd3n9,MH5c7Nekugx8O1AQjInRWyT64GV,SX7OT3VLGp2iQm
					xfsgJZ9tF1dBcEW4bC2e8oPva0D.append(BYrIj87L2b)
			kF8wafyIPSEV6p0bigxAq = sorted(xfsgJZ9tF1dBcEW4bC2e8oPva0D,reverse=False,key=lambda key: key[1].lower())
			if aJb19RQ7MVp: BxuD7iQRpW1(MM5Dx39f7ULhcJsRptzIowP,'SECTIONS_IPTV','SECTIONS_IPTV_ALL',kF8wafyIPSEV6p0bigxAq,VWxPgG1p8Z2Ei4DrX7NotvR)
	vNRpDl1awktg7QP4m0KGqMTS2i[:] = fSGIN9coC3UB+kF8wafyIPSEV6p0bigxAq
	CfKNTtIi3OABbWcPpdF(False)
	return
def ZDpmMzbtaAH(BBprgGU1NPZsFqWkyHRi9c,T0E1NY7V4pLXyHtxCkfw8mWUd3n9):
	aJb19RQ7MVp = False
	if aJb19RQ7MVp:
		RLDCGt8kq3OVmnzgx1rbi2f7F('link','تحديث قائمة أقسام M3U',hWGMqtBy4wuLaVcj,765,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'_CREATENEW_',hWGMqtBy4wuLaVcj,{'folder':BBprgGU1NPZsFqWkyHRi9c})
		RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+'===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	fSGIN9coC3UB = vNRpDl1awktg7QP4m0KGqMTS2i[:]
	import llfcJ30oFC
	if BBprgGU1NPZsFqWkyHRi9c:
		if not llfcJ30oFC.OhBPub8QYNceaq3W(BBprgGU1NPZsFqWkyHRi9c,True): return
		xfsgJZ9tF1dBcEW4bC2e8oPva0D = hhXjodAECp23zyOJQ(BBprgGU1NPZsFqWkyHRi9c,T0E1NY7V4pLXyHtxCkfw8mWUd3n9)
		kF8wafyIPSEV6p0bigxAq = sorted(xfsgJZ9tF1dBcEW4bC2e8oPva0D,reverse=False,key=lambda key: key[1].lower())
	else:
		if not llfcJ30oFC.OhBPub8QYNceaq3W(hWGMqtBy4wuLaVcj,True): return
		if aJb19RQ7MVp and '_CREATENEW_' not in T0E1NY7V4pLXyHtxCkfw8mWUd3n9:
			kF8wafyIPSEV6p0bigxAq = Mqk51CFBym0pIQXZLsOxSJ(MM5Dx39f7ULhcJsRptzIowP,'list','SECTIONS_M3U','SECTIONS_M3U_ALL')
		else:
			otTLRs6Vx0WfyNPrcB51,kF8wafyIPSEV6p0bigxAq,xfsgJZ9tF1dBcEW4bC2e8oPva0D = [],[],[]
			for DD9A4BiEfYmunoFXGTvPl7yO in range(1,SdRCvwxfo1P95Jjb+1):
				kF8wafyIPSEV6p0bigxAq += hhXjodAECp23zyOJQ(str(DD9A4BiEfYmunoFXGTvPl7yO),T0E1NY7V4pLXyHtxCkfw8mWUd3n9)
			for type,j4lHpxXvnF2VtwBb1T9PaJEm3,url,JbpxsyQVXmSEYKM3vo847Ckh,nWE8aO53lFfD,l7COkhRWD9uVS60Pte2NoyAaZn,s9ea72VfoygAOFRCWQTH3zmDuLPE,MH5c7Nekugx8O1AQjInRWyT64GV,SX7OT3VLGp2iQm in kF8wafyIPSEV6p0bigxAq:
				if s9ea72VfoygAOFRCWQTH3zmDuLPE not in otTLRs6Vx0WfyNPrcB51:
					otTLRs6Vx0WfyNPrcB51.append(s9ea72VfoygAOFRCWQTH3zmDuLPE)
					BYrIj87L2b = type,j4lHpxXvnF2VtwBb1T9PaJEm3,s9ea72VfoygAOFRCWQTH3zmDuLPE,165,nWE8aO53lFfD,l7COkhRWD9uVS60Pte2NoyAaZn,T0E1NY7V4pLXyHtxCkfw8mWUd3n9,MH5c7Nekugx8O1AQjInRWyT64GV,SX7OT3VLGp2iQm
					xfsgJZ9tF1dBcEW4bC2e8oPva0D.append(BYrIj87L2b)
			kF8wafyIPSEV6p0bigxAq = sorted(xfsgJZ9tF1dBcEW4bC2e8oPva0D,reverse=False,key=lambda key: key[1].lower())
			if aJb19RQ7MVp: BxuD7iQRpW1(MM5Dx39f7ULhcJsRptzIowP,'SECTIONS_M3U','SECTIONS_M3U_ALL',kF8wafyIPSEV6p0bigxAq,VWxPgG1p8Z2Ei4DrX7NotvR)
	vNRpDl1awktg7QP4m0KGqMTS2i[:] = fSGIN9coC3UB+kF8wafyIPSEV6p0bigxAq
	CfKNTtIi3OABbWcPpdF(False)
	return
def AAZ2KnVhs9DgP4fbSxv(group,T0E1NY7V4pLXyHtxCkfw8mWUd3n9):
	aJb19RQ7MVp = False
	N6NCYivtV4I5rEXq = []
	AdTCfxcGmqONJarioetbXs9Dlhk = '_IPTV_' if 'IPTV' in T0E1NY7V4pLXyHtxCkfw8mWUd3n9 else '_M3U_'
	if aJb19RQ7MVp: N6NCYivtV4I5rEXq = Mqk51CFBym0pIQXZLsOxSJ(MM5Dx39f7ULhcJsRptzIowP,'list','SECTIONS'+AdTCfxcGmqONJarioetbXs9Dlhk[:-1],group)
	if not N6NCYivtV4I5rEXq:
		for BBprgGU1NPZsFqWkyHRi9c in range(1,SdRCvwxfo1P95Jjb+1):
			if aJb19RQ7MVp: N6NCYivtV4I5rEXq += Mqk51CFBym0pIQXZLsOxSJ(MM5Dx39f7ULhcJsRptzIowP,'list','SECTIONS'+AdTCfxcGmqONJarioetbXs9Dlhk[:-1],'SECTIONS'+AdTCfxcGmqONJarioetbXs9Dlhk+str(BBprgGU1NPZsFqWkyHRi9c))
			elif AdTCfxcGmqONJarioetbXs9Dlhk=='_IPTV_': N6NCYivtV4I5rEXq += Jg6ZBMXEdPzeaRQx2q7kwlcAoS0yur(str(BBprgGU1NPZsFqWkyHRi9c),'_CREATENEW_')
			elif AdTCfxcGmqONJarioetbXs9Dlhk=='_M3U_': N6NCYivtV4I5rEXq += hhXjodAECp23zyOJQ(str(BBprgGU1NPZsFqWkyHRi9c),'_CREATENEW_')
		for type,j4lHpxXvnF2VtwBb1T9PaJEm3,url,JbpxsyQVXmSEYKM3vo847Ckh,nWE8aO53lFfD,l7COkhRWD9uVS60Pte2NoyAaZn,s9ea72VfoygAOFRCWQTH3zmDuLPE,MH5c7Nekugx8O1AQjInRWyT64GV,SX7OT3VLGp2iQm in N6NCYivtV4I5rEXq:
			if s9ea72VfoygAOFRCWQTH3zmDuLPE==group: lqvO2yUHs3ZQtxzGYFK(type,j4lHpxXvnF2VtwBb1T9PaJEm3,url,JbpxsyQVXmSEYKM3vo847Ckh,nWE8aO53lFfD,l7COkhRWD9uVS60Pte2NoyAaZn,s9ea72VfoygAOFRCWQTH3zmDuLPE,MH5c7Nekugx8O1AQjInRWyT64GV,SX7OT3VLGp2iQm)
		items,yRE17DrswMOxv0Gc9H = [],[]
		for type,j4lHpxXvnF2VtwBb1T9PaJEm3,url,JbpxsyQVXmSEYKM3vo847Ckh,nWE8aO53lFfD,l7COkhRWD9uVS60Pte2NoyAaZn,s9ea72VfoygAOFRCWQTH3zmDuLPE,MH5c7Nekugx8O1AQjInRWyT64GV,SX7OT3VLGp2iQm in vNRpDl1awktg7QP4m0KGqMTS2i:
			NgV6byYHISq90UuWeX1EAKp4 = type,j4lHpxXvnF2VtwBb1T9PaJEm3[4:],url,JbpxsyQVXmSEYKM3vo847Ckh,nWE8aO53lFfD,l7COkhRWD9uVS60Pte2NoyAaZn,s9ea72VfoygAOFRCWQTH3zmDuLPE,MH5c7Nekugx8O1AQjInRWyT64GV,hWGMqtBy4wuLaVcj
			if NgV6byYHISq90UuWeX1EAKp4 not in yRE17DrswMOxv0Gc9H:
				yRE17DrswMOxv0Gc9H.append(NgV6byYHISq90UuWeX1EAKp4)
				ImYg2jxU6Lc9Q1C4Oko = type,j4lHpxXvnF2VtwBb1T9PaJEm3,url,JbpxsyQVXmSEYKM3vo847Ckh,nWE8aO53lFfD,l7COkhRWD9uVS60Pte2NoyAaZn,s9ea72VfoygAOFRCWQTH3zmDuLPE,MH5c7Nekugx8O1AQjInRWyT64GV,SX7OT3VLGp2iQm
				items.append(ImYg2jxU6Lc9Q1C4Oko)
		N6NCYivtV4I5rEXq = sorted(items,reverse=False,key=lambda key: key[1].lower()[5:])
		if aJb19RQ7MVp: BxuD7iQRpW1(MM5Dx39f7ULhcJsRptzIowP,'SECTIONS'+AdTCfxcGmqONJarioetbXs9Dlhk[:-1],group,N6NCYivtV4I5rEXq,VWxPgG1p8Z2Ei4DrX7NotvR)
	if '_RANDOM_' in T0E1NY7V4pLXyHtxCkfw8mWUd3n9 and len(N6NCYivtV4I5rEXq)>lKNx6dIb1ARcU4C:
		vNRpDl1awktg7QP4m0KGqMTS2i[:] = []
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder','['+hXB0vKVQ5PRI91SDTprMdfuHEm4+group+YYSh2J6BIrsm8+' :القسم]',group,165,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,AdTCfxcGmqONJarioetbXs9Dlhk+'_RANDOM__FORGETRESULTS__REMEMBERRESULTS_')
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder','إعادة الطلب العشوائي من نفس القسم',group,165,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,AdTCfxcGmqONJarioetbXs9Dlhk+'_RANDOM__FORGETRESULTS__REMEMBERRESULTS_')
		RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+'===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
		N6NCYivtV4I5rEXq = vNRpDl1awktg7QP4m0KGqMTS2i+eOmXSF6kIWV7yqKCR.sample(N6NCYivtV4I5rEXq,lKNx6dIb1ARcU4C)
	vNRpDl1awktg7QP4m0KGqMTS2i[:] = N6NCYivtV4I5rEXq
	CfKNTtIi3OABbWcPpdF(False)
	return
def FQ8HbE0eUCl6K15LcorWOs2Bqta(T0E1NY7V4pLXyHtxCkfw8mWUd3n9):
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','إعادة طلب قنوات عشوائية',hWGMqtBy4wuLaVcj,161,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'_FORGETRESULTS__REMEMBERRESULTS__LIVETV__RANDOM_')
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+'===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	HCfk9NFhgdzqTOr = vNRpDl1awktg7QP4m0KGqMTS2i[:]
	vNRpDl1awktg7QP4m0KGqMTS2i[:] = []
	import cExDXrt5fI
	cExDXrt5fI.qJQdtBXVnP9EFwlvOKMLecDb('0',False)
	cExDXrt5fI.qJQdtBXVnP9EFwlvOKMLecDb('1',False)
	cExDXrt5fI.qJQdtBXVnP9EFwlvOKMLecDb('2',False)
	if '_RANDOM_' in T0E1NY7V4pLXyHtxCkfw8mWUd3n9:
		vNRpDl1awktg7QP4m0KGqMTS2i[:] = lHrgfFehs26(vNRpDl1awktg7QP4m0KGqMTS2i)
		if len(vNRpDl1awktg7QP4m0KGqMTS2i)>lKNx6dIb1ARcU4C: vNRpDl1awktg7QP4m0KGqMTS2i[:] = eOmXSF6kIWV7yqKCR.sample(vNRpDl1awktg7QP4m0KGqMTS2i,lKNx6dIb1ARcU4C)
	vNRpDl1awktg7QP4m0KGqMTS2i[:] = HCfk9NFhgdzqTOr+vNRpDl1awktg7QP4m0KGqMTS2i
	return
def QIVHepFB25bSKJEAPw6NtZn(T0E1NY7V4pLXyHtxCkfw8mWUd3n9):
	T0E1NY7V4pLXyHtxCkfw8mWUd3n9 = T0E1NY7V4pLXyHtxCkfw8mWUd3n9.replace('_FORGETRESULTS_',hWGMqtBy4wuLaVcj).replace('_REMEMBERRESULTS_',hWGMqtBy4wuLaVcj)
	headers = { 'User-Agent' : hWGMqtBy4wuLaVcj }
	url = 'https://www.bestrandoms.com/random-arabic-words'
	data = {'quantity':'50'}
	data = gQ5hRKULia2pdOWAxScMwTDbkl(data)
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(D8V7AhLkSQYzo,'GET',url,data,headers,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'RANDOMS-RANDOM_VIDEOS_FROM_WORDS-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('class="content"(.*?)class="clearfix"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
	items = trdVA0JvFaD.findall('<span>(.*?)</span>.*?<span>(.*?)</span>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	ZjLnmYHlGkIuqy9w6Q7Sve,vvZl47bpEOH = list(zip(*items))
	ekTlzYXsGEx6QUPa4W = []
	xxPX5oGuyCc7Lf = [Mpsm2VF1OBnCRvK3qf6,'"','`',',','.',':',';',"'",'-']
	kKXamuIShblnvrH9EeDp = vvZl47bpEOH+ZjLnmYHlGkIuqy9w6Q7Sve
	for tKLbTR8zJl1Q2YjF in kKXamuIShblnvrH9EeDp:
		if tKLbTR8zJl1Q2YjF in vvZl47bpEOH: FcehHSUIdwmLxJKo6nZRgk2 = 2
		if tKLbTR8zJl1Q2YjF in ZjLnmYHlGkIuqy9w6Q7Sve: FcehHSUIdwmLxJKo6nZRgk2 = 4
		SU3MZJeiV2TxCbNcPAudjY = [PPuqrvDLEViYOMf1dmkK7 in tKLbTR8zJl1Q2YjF for PPuqrvDLEViYOMf1dmkK7 in xxPX5oGuyCc7Lf]
		if any(SU3MZJeiV2TxCbNcPAudjY):
			C9VNOL3UmyXPYbGrJ8 = SU3MZJeiV2TxCbNcPAudjY.index(True)
			yyBFs4ELrqlumjJD0giYQKMbvSIhkz = xxPX5oGuyCc7Lf[C9VNOL3UmyXPYbGrJ8]
			mX6h7gduNnifQGF = hWGMqtBy4wuLaVcj
			if tKLbTR8zJl1Q2YjF.count(yyBFs4ELrqlumjJD0giYQKMbvSIhkz)>1: P2vGS1jLB0u5kbyZXhATJfrm7,afODWrA5wCsbqxyBLup6,mX6h7gduNnifQGF = tKLbTR8zJl1Q2YjF.split(yyBFs4ELrqlumjJD0giYQKMbvSIhkz,2)
			else: P2vGS1jLB0u5kbyZXhATJfrm7,afODWrA5wCsbqxyBLup6 = tKLbTR8zJl1Q2YjF.split(yyBFs4ELrqlumjJD0giYQKMbvSIhkz,1)
			if len(P2vGS1jLB0u5kbyZXhATJfrm7)>FcehHSUIdwmLxJKo6nZRgk2: ekTlzYXsGEx6QUPa4W.append(P2vGS1jLB0u5kbyZXhATJfrm7.lower())
			if len(afODWrA5wCsbqxyBLup6)>FcehHSUIdwmLxJKo6nZRgk2: ekTlzYXsGEx6QUPa4W.append(afODWrA5wCsbqxyBLup6.lower())
			if len(mX6h7gduNnifQGF)>FcehHSUIdwmLxJKo6nZRgk2: ekTlzYXsGEx6QUPa4W.append(mX6h7gduNnifQGF.lower())
		elif len(tKLbTR8zJl1Q2YjF)>FcehHSUIdwmLxJKo6nZRgk2: ekTlzYXsGEx6QUPa4W.append(tKLbTR8zJl1Q2YjF.lower())
	for PPuqrvDLEViYOMf1dmkK7 in range(9): eOmXSF6kIWV7yqKCR.shuffle(ekTlzYXsGEx6QUPa4W)
	if '_SITES_' in T0E1NY7V4pLXyHtxCkfw8mWUd3n9:
		BHtJK4AqgVwbD = jxyKkBY2FhC6czAUNXe5i
	elif '_IPTV_' in T0E1NY7V4pLXyHtxCkfw8mWUd3n9:
		BHtJK4AqgVwbD = ['IPTV']
		import t2YzocLAmj
		if not t2YzocLAmj.OhBPub8QYNceaq3W(hWGMqtBy4wuLaVcj,True): return
	elif '_M3U_' in T0E1NY7V4pLXyHtxCkfw8mWUd3n9:
		BHtJK4AqgVwbD = ['M3U']
		import llfcJ30oFC
		if not llfcJ30oFC.OhBPub8QYNceaq3W(hWGMqtBy4wuLaVcj,True): return
	count,D798atgKUSfBwpzlTcuLjenICq = 0,0
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','[  ] :البحث عن',hWGMqtBy4wuLaVcj,164,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'_FORGETRESULTS__REMEMBERRESULTS_'+T0E1NY7V4pLXyHtxCkfw8mWUd3n9)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','إعادة البحث العشوائي',hWGMqtBy4wuLaVcj,164,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'_FORGETRESULTS__REMEMBERRESULTS_'+T0E1NY7V4pLXyHtxCkfw8mWUd3n9)
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+'===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	w6ItVNXiZbexPGDHyha5 = vNRpDl1awktg7QP4m0KGqMTS2i[:]
	vNRpDl1awktg7QP4m0KGqMTS2i[:] = []
	yptzJ61Is2qDvZOSF9aXhP3QfT = []
	for tKLbTR8zJl1Q2YjF in ekTlzYXsGEx6QUPa4W:
		afODWrA5wCsbqxyBLup6 = trdVA0JvFaD.findall('[ \,\;\:\-\+\=\"\'\[\]\(\)\{\}\!\@'+'#'+'\$\%\^\&\*\_\<\>]',tKLbTR8zJl1Q2YjF,trdVA0JvFaD.DOTALL)
		if afODWrA5wCsbqxyBLup6: tKLbTR8zJl1Q2YjF = tKLbTR8zJl1Q2YjF.split(afODWrA5wCsbqxyBLup6[0],1)[0]
		DD6cgLCM8JUd0HBnlfov5qk = tKLbTR8zJl1Q2YjF.replace('ّ',hWGMqtBy4wuLaVcj).replace('َ',hWGMqtBy4wuLaVcj).replace('ً',hWGMqtBy4wuLaVcj).replace('ُ',hWGMqtBy4wuLaVcj).replace('ٌ',hWGMqtBy4wuLaVcj)
		DD6cgLCM8JUd0HBnlfov5qk = DD6cgLCM8JUd0HBnlfov5qk.replace('ِ',hWGMqtBy4wuLaVcj).replace('ٍ',hWGMqtBy4wuLaVcj).replace('ْ',hWGMqtBy4wuLaVcj).replace('،',hWGMqtBy4wuLaVcj).replace('ـ',hWGMqtBy4wuLaVcj)
		if DD6cgLCM8JUd0HBnlfov5qk: yptzJ61Is2qDvZOSF9aXhP3QfT.append(DD6cgLCM8JUd0HBnlfov5qk)
	x4M9H30zKfpjPbaEY = []
	for JpzD0lv9cYM6XrHeqCa in range(0,20):
		search = eOmXSF6kIWV7yqKCR.sample(yptzJ61Is2qDvZOSF9aXhP3QfT,1)[0]
		if search in x4M9H30zKfpjPbaEY: continue
		x4M9H30zKfpjPbaEY.append(search)
		ITlpOFqLn7W2hYkdijCogm = eOmXSF6kIWV7yqKCR.sample(BHtJK4AqgVwbD,1)[0]
		KteLZCbM8W0FqE2OBx1(pGYKHZgqFX3B,qhVEWvetzXLOcr1(xjPuFK3EsIZSiobQ5X)+'   Random Video Search   site:'+str(ITlpOFqLn7W2hYkdijCogm)+'  search:'+search)
		OLEaRvPrIK,jybQBYEnf41IACTROeGlDdP9z,lr6UH3CkoIi9tuabRW4Vwe1 = CPGup68qUQdti5IVeS7kXRA(ITlpOFqLn7W2hYkdijCogm)
		jybQBYEnf41IACTROeGlDdP9z(search+'_NODIALOGS_')
		if len(vNRpDl1awktg7QP4m0KGqMTS2i)>0: break
	search = search.replace('_MOD_',hWGMqtBy4wuLaVcj)
	w6ItVNXiZbexPGDHyha5[0][1] = '['+hXB0vKVQ5PRI91SDTprMdfuHEm4+search+YYSh2J6BIrsm8+' :بحث عن]'
	vNRpDl1awktg7QP4m0KGqMTS2i[:] = lHrgfFehs26(vNRpDl1awktg7QP4m0KGqMTS2i)
	if len(vNRpDl1awktg7QP4m0KGqMTS2i)>lKNx6dIb1ARcU4C: vNRpDl1awktg7QP4m0KGqMTS2i[:] = eOmXSF6kIWV7yqKCR.sample(vNRpDl1awktg7QP4m0KGqMTS2i,lKNx6dIb1ARcU4C)
	vNRpDl1awktg7QP4m0KGqMTS2i[:] = w6ItVNXiZbexPGDHyha5+vNRpDl1awktg7QP4m0KGqMTS2i
	return
def uJmPcWFRn1YLEQdMiw6azZt5qbDj(gaWOl6QfJtr,T0E1NY7V4pLXyHtxCkfw8mWUd3n9):
	gaWOl6QfJtr = gaWOl6QfJtr.replace('_MOD_',hWGMqtBy4wuLaVcj)
	T0E1NY7V4pLXyHtxCkfw8mWUd3n9 = T0E1NY7V4pLXyHtxCkfw8mWUd3n9.replace('_FORGETRESULTS_',hWGMqtBy4wuLaVcj).replace('_REMEMBERRESULTS_',hWGMqtBy4wuLaVcj)
	rfzaS51Towi24Akcluq(False)
	if FvkuXRitwj=={}: return
	if '_RANDOM_' in T0E1NY7V4pLXyHtxCkfw8mWUd3n9:
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder','['+hXB0vKVQ5PRI91SDTprMdfuHEm4+gaWOl6QfJtr+YYSh2J6BIrsm8+' :القسم]',gaWOl6QfJtr,166,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'_FORGETRESULTS__REMEMBERRESULTS_'+T0E1NY7V4pLXyHtxCkfw8mWUd3n9)
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder','إعادة الطلب العشوائي من نفس القسم',gaWOl6QfJtr,166,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'_FORGETRESULTS__REMEMBERRESULTS_'+T0E1NY7V4pLXyHtxCkfw8mWUd3n9)
		RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+'===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	for website in sorted(list(FvkuXRitwj[gaWOl6QfJtr].keys())):
		type,j4lHpxXvnF2VtwBb1T9PaJEm3,url,DASrslYGWIQwxjOdu0eN368o,nWE8aO53lFfD,l7COkhRWD9uVS60Pte2NoyAaZn,s9ea72VfoygAOFRCWQTH3zmDuLPE,MH5c7Nekugx8O1AQjInRWyT64GV,SX7OT3VLGp2iQm = FvkuXRitwj[gaWOl6QfJtr][website]
		if '_RANDOM_' in T0E1NY7V4pLXyHtxCkfw8mWUd3n9 or len(FvkuXRitwj[gaWOl6QfJtr])==1:
			lqvO2yUHs3ZQtxzGYFK(type,hWGMqtBy4wuLaVcj,url,DASrslYGWIQwxjOdu0eN368o,hWGMqtBy4wuLaVcj,l7COkhRWD9uVS60Pte2NoyAaZn,s9ea72VfoygAOFRCWQTH3zmDuLPE,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj)
			vNRpDl1awktg7QP4m0KGqMTS2i[:] = lHrgfFehs26(vNRpDl1awktg7QP4m0KGqMTS2i)
			fSGIN9coC3UB,kF8wafyIPSEV6p0bigxAq = vNRpDl1awktg7QP4m0KGqMTS2i[:3],vNRpDl1awktg7QP4m0KGqMTS2i[3:]
			for PPuqrvDLEViYOMf1dmkK7 in range(9): eOmXSF6kIWV7yqKCR.shuffle(kF8wafyIPSEV6p0bigxAq)
			if '_RANDOM_' in T0E1NY7V4pLXyHtxCkfw8mWUd3n9: vNRpDl1awktg7QP4m0KGqMTS2i[:] = fSGIN9coC3UB+kF8wafyIPSEV6p0bigxAq[:lKNx6dIb1ARcU4C]
			else: vNRpDl1awktg7QP4m0KGqMTS2i[:] = fSGIN9coC3UB+kF8wafyIPSEV6p0bigxAq
		elif '_SITES_' in T0E1NY7V4pLXyHtxCkfw8mWUd3n9: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',website,url,DASrslYGWIQwxjOdu0eN368o,nWE8aO53lFfD,l7COkhRWD9uVS60Pte2NoyAaZn,s9ea72VfoygAOFRCWQTH3zmDuLPE,MH5c7Nekugx8O1AQjInRWyT64GV,SX7OT3VLGp2iQm)
	return
def jSOhLNUkr95(T0E1NY7V4pLXyHtxCkfw8mWUd3n9,JbpxsyQVXmSEYKM3vo847Ckh):
	T0E1NY7V4pLXyHtxCkfw8mWUd3n9 = T0E1NY7V4pLXyHtxCkfw8mWUd3n9.replace('_FORGETRESULTS_',hWGMqtBy4wuLaVcj).replace('_REMEMBERRESULTS_',hWGMqtBy4wuLaVcj)
	j4lHpxXvnF2VtwBb1T9PaJEm3,cnIKkB1VqTuvwSXOGL0 = hWGMqtBy4wuLaVcj,[]
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','['+hXB0vKVQ5PRI91SDTprMdfuHEm4+j4lHpxXvnF2VtwBb1T9PaJEm3+YYSh2J6BIrsm8+' :القسم]',hWGMqtBy4wuLaVcj,JbpxsyQVXmSEYKM3vo847Ckh,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'_FORGETRESULTS__REMEMBERRESULTS_'+T0E1NY7V4pLXyHtxCkfw8mWUd3n9)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','إعادة طلب قسم عشوائي',hWGMqtBy4wuLaVcj,JbpxsyQVXmSEYKM3vo847Ckh,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'_FORGETRESULTS__REMEMBERRESULTS_'+T0E1NY7V4pLXyHtxCkfw8mWUd3n9)
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+'===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	fSGIN9coC3UB = vNRpDl1awktg7QP4m0KGqMTS2i[:]
	vNRpDl1awktg7QP4m0KGqMTS2i[:] = []
	N6NCYivtV4I5rEXq = []
	if '_SITES_' in T0E1NY7V4pLXyHtxCkfw8mWUd3n9:
		rfzaS51Towi24Akcluq(False)
		if FvkuXRitwj=={}: return
		XxZe0cqjm3Vbs = list(FvkuXRitwj.keys())
		gaWOl6QfJtr = eOmXSF6kIWV7yqKCR.sample(XxZe0cqjm3Vbs,1)[0]
		ekTlzYXsGEx6QUPa4W = list(FvkuXRitwj[gaWOl6QfJtr].keys())
		website = eOmXSF6kIWV7yqKCR.sample(ekTlzYXsGEx6QUPa4W,1)[0]
		type,j4lHpxXvnF2VtwBb1T9PaJEm3,url,DASrslYGWIQwxjOdu0eN368o,nWE8aO53lFfD,l7COkhRWD9uVS60Pte2NoyAaZn,s9ea72VfoygAOFRCWQTH3zmDuLPE,MH5c7Nekugx8O1AQjInRWyT64GV,SX7OT3VLGp2iQm = FvkuXRitwj[gaWOl6QfJtr][website]
		KteLZCbM8W0FqE2OBx1(pGYKHZgqFX3B,qhVEWvetzXLOcr1(xjPuFK3EsIZSiobQ5X)+'   Random Category   website: '+website+'   name: '+j4lHpxXvnF2VtwBb1T9PaJEm3+'   url: '+url+'   mode: '+str(DASrslYGWIQwxjOdu0eN368o))
	elif '_IPTV_' in T0E1NY7V4pLXyHtxCkfw8mWUd3n9:
		import t2YzocLAmj
		if not t2YzocLAmj.OhBPub8QYNceaq3W(hWGMqtBy4wuLaVcj,True): return
		for BBprgGU1NPZsFqWkyHRi9c in range(1,SdRCvwxfo1P95Jjb+1):
			N6NCYivtV4I5rEXq += Jg6ZBMXEdPzeaRQx2q7kwlcAoS0yur(str(BBprgGU1NPZsFqWkyHRi9c),T0E1NY7V4pLXyHtxCkfw8mWUd3n9)
		if not N6NCYivtV4I5rEXq: return
		type,j4lHpxXvnF2VtwBb1T9PaJEm3,url,DASrslYGWIQwxjOdu0eN368o,nWE8aO53lFfD,l7COkhRWD9uVS60Pte2NoyAaZn,s9ea72VfoygAOFRCWQTH3zmDuLPE,MH5c7Nekugx8O1AQjInRWyT64GV,SX7OT3VLGp2iQm = eOmXSF6kIWV7yqKCR.sample(N6NCYivtV4I5rEXq,1)[0]
		KteLZCbM8W0FqE2OBx1(pGYKHZgqFX3B,qhVEWvetzXLOcr1(xjPuFK3EsIZSiobQ5X)+'   Random Category   name: '+j4lHpxXvnF2VtwBb1T9PaJEm3+'   url: '+url+'   mode: '+str(DASrslYGWIQwxjOdu0eN368o))
	elif '_M3U_' in T0E1NY7V4pLXyHtxCkfw8mWUd3n9:
		import llfcJ30oFC
		if not llfcJ30oFC.OhBPub8QYNceaq3W(hWGMqtBy4wuLaVcj,True): return
		for BBprgGU1NPZsFqWkyHRi9c in range(1,SdRCvwxfo1P95Jjb+1):
			N6NCYivtV4I5rEXq += hhXjodAECp23zyOJQ(str(BBprgGU1NPZsFqWkyHRi9c),T0E1NY7V4pLXyHtxCkfw8mWUd3n9)
		if not N6NCYivtV4I5rEXq: return
		type,j4lHpxXvnF2VtwBb1T9PaJEm3,url,DASrslYGWIQwxjOdu0eN368o,nWE8aO53lFfD,l7COkhRWD9uVS60Pte2NoyAaZn,s9ea72VfoygAOFRCWQTH3zmDuLPE,MH5c7Nekugx8O1AQjInRWyT64GV,SX7OT3VLGp2iQm = eOmXSF6kIWV7yqKCR.sample(N6NCYivtV4I5rEXq,1)[0]
		KteLZCbM8W0FqE2OBx1(pGYKHZgqFX3B,qhVEWvetzXLOcr1(xjPuFK3EsIZSiobQ5X)+'   Random Category   name: '+j4lHpxXvnF2VtwBb1T9PaJEm3+'   url: '+url+'   mode: '+str(DASrslYGWIQwxjOdu0eN368o))
	iiNAV9wBJfjQ2R3O7bv = j4lHpxXvnF2VtwBb1T9PaJEm3
	mmiIVRs5xUeyHBgYSc6dADXw1KJt7 = []
	for PPuqrvDLEViYOMf1dmkK7 in range(0,10):
		if PPuqrvDLEViYOMf1dmkK7>0: KteLZCbM8W0FqE2OBx1(pGYKHZgqFX3B,qhVEWvetzXLOcr1(xjPuFK3EsIZSiobQ5X)+'   Random Category   name: '+j4lHpxXvnF2VtwBb1T9PaJEm3+'   url: '+url+'   mode: '+str(DASrslYGWIQwxjOdu0eN368o))
		vNRpDl1awktg7QP4m0KGqMTS2i[:] = []
		if DASrslYGWIQwxjOdu0eN368o==234 and '__IPTVSeries__' in s9ea72VfoygAOFRCWQTH3zmDuLPE: DASrslYGWIQwxjOdu0eN368o = 233
		if DASrslYGWIQwxjOdu0eN368o==714 and '__M3USeries__' in s9ea72VfoygAOFRCWQTH3zmDuLPE: DASrslYGWIQwxjOdu0eN368o = 713
		if DASrslYGWIQwxjOdu0eN368o==144: DASrslYGWIQwxjOdu0eN368o = 291
		QwGpLVOkc0MPodWfiYsTj = lqvO2yUHs3ZQtxzGYFK(type,j4lHpxXvnF2VtwBb1T9PaJEm3,url,DASrslYGWIQwxjOdu0eN368o,nWE8aO53lFfD,l7COkhRWD9uVS60Pte2NoyAaZn,s9ea72VfoygAOFRCWQTH3zmDuLPE,MH5c7Nekugx8O1AQjInRWyT64GV,SX7OT3VLGp2iQm)
		if '_IPTV_' in T0E1NY7V4pLXyHtxCkfw8mWUd3n9 and DASrslYGWIQwxjOdu0eN368o==167: del vNRpDl1awktg7QP4m0KGqMTS2i[:3]
		if '_M3U_' in T0E1NY7V4pLXyHtxCkfw8mWUd3n9 and DASrslYGWIQwxjOdu0eN368o==168: del vNRpDl1awktg7QP4m0KGqMTS2i[:3]
		cnIKkB1VqTuvwSXOGL0[:] = lHrgfFehs26(vNRpDl1awktg7QP4m0KGqMTS2i)
		if mmiIVRs5xUeyHBgYSc6dADXw1KJt7 and DDZcb1RmaIMH(u'حلقة') in str(cnIKkB1VqTuvwSXOGL0) or DDZcb1RmaIMH(u'حلقه') in str(cnIKkB1VqTuvwSXOGL0):
			j4lHpxXvnF2VtwBb1T9PaJEm3 = iiNAV9wBJfjQ2R3O7bv
			cnIKkB1VqTuvwSXOGL0[:] = mmiIVRs5xUeyHBgYSc6dADXw1KJt7
			break
		iiNAV9wBJfjQ2R3O7bv = j4lHpxXvnF2VtwBb1T9PaJEm3
		mmiIVRs5xUeyHBgYSc6dADXw1KJt7 = cnIKkB1VqTuvwSXOGL0
		if str(cnIKkB1VqTuvwSXOGL0).count('video')>0: break
		if str(cnIKkB1VqTuvwSXOGL0).count('live')>0: break
		if DASrslYGWIQwxjOdu0eN368o==233: break
		if DASrslYGWIQwxjOdu0eN368o==713: break
		if DASrslYGWIQwxjOdu0eN368o==291: break
		if cnIKkB1VqTuvwSXOGL0: type,j4lHpxXvnF2VtwBb1T9PaJEm3,url,DASrslYGWIQwxjOdu0eN368o,nWE8aO53lFfD,l7COkhRWD9uVS60Pte2NoyAaZn,s9ea72VfoygAOFRCWQTH3zmDuLPE,MH5c7Nekugx8O1AQjInRWyT64GV,SX7OT3VLGp2iQm = eOmXSF6kIWV7yqKCR.sample(cnIKkB1VqTuvwSXOGL0,1)[0]
	if not j4lHpxXvnF2VtwBb1T9PaJEm3: j4lHpxXvnF2VtwBb1T9PaJEm3 = '....'
	elif j4lHpxXvnF2VtwBb1T9PaJEm3.count('_')>1: j4lHpxXvnF2VtwBb1T9PaJEm3 = j4lHpxXvnF2VtwBb1T9PaJEm3.split('_',2)[2]
	j4lHpxXvnF2VtwBb1T9PaJEm3 = j4lHpxXvnF2VtwBb1T9PaJEm3.replace('UNKNOWN: ',hWGMqtBy4wuLaVcj)
	j4lHpxXvnF2VtwBb1T9PaJEm3 = j4lHpxXvnF2VtwBb1T9PaJEm3.replace('_MOD_',hWGMqtBy4wuLaVcj)
	fSGIN9coC3UB[0][1] = '['+hXB0vKVQ5PRI91SDTprMdfuHEm4+j4lHpxXvnF2VtwBb1T9PaJEm3+YYSh2J6BIrsm8+' :القسم]'
	for PPuqrvDLEViYOMf1dmkK7 in range(9): eOmXSF6kIWV7yqKCR.shuffle(cnIKkB1VqTuvwSXOGL0)
	if '_RANDOM_' in T0E1NY7V4pLXyHtxCkfw8mWUd3n9: vNRpDl1awktg7QP4m0KGqMTS2i[:] = fSGIN9coC3UB+cnIKkB1VqTuvwSXOGL0[:lKNx6dIb1ARcU4C]
	else: vNRpDl1awktg7QP4m0KGqMTS2i[:] = fSGIN9coC3UB+cnIKkB1VqTuvwSXOGL0
	return
def diXP4qk8mQ7WF3nzjsCO92V(JQSyL91rPfuYUC6lbZF2qIa30o5zcp,EWxZb76AdTRevJVcDPHl0uyoIf):
	EWxZb76AdTRevJVcDPHl0uyoIf = EWxZb76AdTRevJVcDPHl0uyoIf.replace('_FORGETRESULTS_',hWGMqtBy4wuLaVcj).replace('_REMEMBERRESULTS_',hWGMqtBy4wuLaVcj)
	wAknGX1LRUTh5 = EWxZb76AdTRevJVcDPHl0uyoIf
	if '__IPTVSeries__' in EWxZb76AdTRevJVcDPHl0uyoIf:
		wAknGX1LRUTh5 = EWxZb76AdTRevJVcDPHl0uyoIf.split('__IPTVSeries__')[0]
		type = ',SERIES: '
	elif 'VOD' in JQSyL91rPfuYUC6lbZF2qIa30o5zcp: type = ',VIDEOS: '
	elif 'LIVE' in JQSyL91rPfuYUC6lbZF2qIa30o5zcp: type = ',LIVE: '
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','['+hXB0vKVQ5PRI91SDTprMdfuHEm4+type+wAknGX1LRUTh5+YYSh2J6BIrsm8+' :القسم]',JQSyL91rPfuYUC6lbZF2qIa30o5zcp,167,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'_FORGETRESULTS__REMEMBERRESULTS_'+EWxZb76AdTRevJVcDPHl0uyoIf)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','إعادة الطلب العشوائي من نفس القسم',JQSyL91rPfuYUC6lbZF2qIa30o5zcp,167,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'_FORGETRESULTS__REMEMBERRESULTS_'+EWxZb76AdTRevJVcDPHl0uyoIf)
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+'===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	import t2YzocLAmj
	for BBprgGU1NPZsFqWkyHRi9c in range(1,SdRCvwxfo1P95Jjb+1):
		if '__IPTVSeries__' in EWxZb76AdTRevJVcDPHl0uyoIf: t2YzocLAmj.YDs4gfOMR8rQeSoqnUXwxCEa6BlP1(str(BBprgGU1NPZsFqWkyHRi9c),JQSyL91rPfuYUC6lbZF2qIa30o5zcp,EWxZb76AdTRevJVcDPHl0uyoIf,hWGMqtBy4wuLaVcj,False)
		else: t2YzocLAmj.qJQdtBXVnP9EFwlvOKMLecDb(str(BBprgGU1NPZsFqWkyHRi9c),JQSyL91rPfuYUC6lbZF2qIa30o5zcp,EWxZb76AdTRevJVcDPHl0uyoIf,hWGMqtBy4wuLaVcj,False)
	vNRpDl1awktg7QP4m0KGqMTS2i[:] = lHrgfFehs26(vNRpDl1awktg7QP4m0KGqMTS2i)
	if len(vNRpDl1awktg7QP4m0KGqMTS2i)>(lKNx6dIb1ARcU4C+3): vNRpDl1awktg7QP4m0KGqMTS2i[:] = vNRpDl1awktg7QP4m0KGqMTS2i[:3]+eOmXSF6kIWV7yqKCR.sample(vNRpDl1awktg7QP4m0KGqMTS2i[3:],lKNx6dIb1ARcU4C)
	return
def JThpcVwEQxy2GRKgMB86WbqC(JQSyL91rPfuYUC6lbZF2qIa30o5zcp,EWxZb76AdTRevJVcDPHl0uyoIf):
	EWxZb76AdTRevJVcDPHl0uyoIf = EWxZb76AdTRevJVcDPHl0uyoIf.replace('_FORGETRESULTS_',hWGMqtBy4wuLaVcj).replace('_REMEMBERRESULTS_',hWGMqtBy4wuLaVcj)
	wAknGX1LRUTh5 = EWxZb76AdTRevJVcDPHl0uyoIf
	if '__M3USeries__' in EWxZb76AdTRevJVcDPHl0uyoIf:
		wAknGX1LRUTh5 = EWxZb76AdTRevJVcDPHl0uyoIf.split('__M3USeries__')[0]
		type = ',SERIES: '
	elif 'VOD' in JQSyL91rPfuYUC6lbZF2qIa30o5zcp: type = ',VIDEOS: '
	elif 'LIVE' in JQSyL91rPfuYUC6lbZF2qIa30o5zcp: type = ',LIVE: '
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','['+hXB0vKVQ5PRI91SDTprMdfuHEm4+type+wAknGX1LRUTh5+YYSh2J6BIrsm8+' :القسم]',JQSyL91rPfuYUC6lbZF2qIa30o5zcp,168,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'_FORGETRESULTS__REMEMBERRESULTS_'+EWxZb76AdTRevJVcDPHl0uyoIf)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder','إعادة الطلب العشوائي من نفس القسم',JQSyL91rPfuYUC6lbZF2qIa30o5zcp,168,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'_FORGETRESULTS__REMEMBERRESULTS_'+EWxZb76AdTRevJVcDPHl0uyoIf)
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+'===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	import llfcJ30oFC
	for BBprgGU1NPZsFqWkyHRi9c in range(1,SdRCvwxfo1P95Jjb+1):
		if '__M3USeries__' in EWxZb76AdTRevJVcDPHl0uyoIf: llfcJ30oFC.YDs4gfOMR8rQeSoqnUXwxCEa6BlP1(str(BBprgGU1NPZsFqWkyHRi9c),JQSyL91rPfuYUC6lbZF2qIa30o5zcp,EWxZb76AdTRevJVcDPHl0uyoIf,hWGMqtBy4wuLaVcj,False)
		else: llfcJ30oFC.qJQdtBXVnP9EFwlvOKMLecDb(str(BBprgGU1NPZsFqWkyHRi9c),JQSyL91rPfuYUC6lbZF2qIa30o5zcp,EWxZb76AdTRevJVcDPHl0uyoIf,hWGMqtBy4wuLaVcj,False)
	vNRpDl1awktg7QP4m0KGqMTS2i[:] = lHrgfFehs26(vNRpDl1awktg7QP4m0KGqMTS2i)
	if len(vNRpDl1awktg7QP4m0KGqMTS2i)>(lKNx6dIb1ARcU4C+3): vNRpDl1awktg7QP4m0KGqMTS2i[:] = vNRpDl1awktg7QP4m0KGqMTS2i[:3]+eOmXSF6kIWV7yqKCR.sample(vNRpDl1awktg7QP4m0KGqMTS2i[3:],lKNx6dIb1ARcU4C)
	return
def lHrgfFehs26(vNRpDl1awktg7QP4m0KGqMTS2i):
	cnIKkB1VqTuvwSXOGL0 = []
	for type,j4lHpxXvnF2VtwBb1T9PaJEm3,url,JbpxsyQVXmSEYKM3vo847Ckh,nWE8aO53lFfD,l7COkhRWD9uVS60Pte2NoyAaZn,s9ea72VfoygAOFRCWQTH3zmDuLPE,MH5c7Nekugx8O1AQjInRWyT64GV,SX7OT3VLGp2iQm in vNRpDl1awktg7QP4m0KGqMTS2i:
		if 'صفحة' in j4lHpxXvnF2VtwBb1T9PaJEm3 or 'صفحه' in j4lHpxXvnF2VtwBb1T9PaJEm3 or 'page' in j4lHpxXvnF2VtwBb1T9PaJEm3.lower(): continue
		cnIKkB1VqTuvwSXOGL0.append([type,j4lHpxXvnF2VtwBb1T9PaJEm3,url,JbpxsyQVXmSEYKM3vo847Ckh,nWE8aO53lFfD,l7COkhRWD9uVS60Pte2NoyAaZn,s9ea72VfoygAOFRCWQTH3zmDuLPE,MH5c7Nekugx8O1AQjInRWyT64GV,SX7OT3VLGp2iQm])
	return cnIKkB1VqTuvwSXOGL0
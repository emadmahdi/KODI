# -*- coding: utf-8 -*-
from yoY3NdGViS import *
xjPuFK3EsIZSiobQ5X = 'CIMA4U'
headers = {'User-Agent':hWGMqtBy4wuLaVcj}
n0qFKQWhiBYXoTrvejVHUA4 = '_C4U_'
Str0BupDTFA = u6rbxnyjTl7I[xjPuFK3EsIZSiobQ5X][0]
P3UK1Rr4IdYe5 = ['مصارعة حرة','اخري','اخرى','الرئيسية','بدون إختيار','افلام','مسلسلات']
def ehB18u9sQFRi(mode,url,text):
	if   mode==420: N6NCYivtV4I5rEXq = DP6FSBgNdX1rsvVR()
	elif mode==421: N6NCYivtV4I5rEXq = wg5aF3e8rcDh7SGpW6M1OPnkU(url,text)
	elif mode==422: N6NCYivtV4I5rEXq = ppcbK7vZlfXRTt0BEei9zho(url)
	elif mode==423: N6NCYivtV4I5rEXq = GrsxUhb0PEXj2FQRAkD4q(url)
	elif mode==424: N6NCYivtV4I5rEXq = hadMgR0nOKHoGqpA(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==425: N6NCYivtV4I5rEXq = hadMgR0nOKHoGqpA(url,'SPECIFIED_FILTER___'+text)
	elif mode==426: N6NCYivtV4I5rEXq = oanus6TxUFNAhSZKpJdYlEC4mV(url)
	elif mode==427: N6NCYivtV4I5rEXq = ZmkCHrXyz4MEwQ1JeY2j(url)
	elif mode==429: N6NCYivtV4I5rEXq = lPwaAjFTMG4n7iSLkXcEuK0Zm(text)
	else: N6NCYivtV4I5rEXq = False
	return N6NCYivtV4I5rEXq
def DP6FSBgNdX1rsvVR():
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',Str0BupDTFA,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'CIMA4U-MENU-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	cbYKa2SXGwRCiQIW5NeosU9k = trdVA0JvFaD.findall('href="(.*?)"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	cbYKa2SXGwRCiQIW5NeosU9k = cbYKa2SXGwRCiQIW5NeosU9k[0].strip('/')
	cbYKa2SXGwRCiQIW5NeosU9k = RRNODILCtGzvgpx(cbYKa2SXGwRCiQIW5NeosU9k,'url')
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'بحث في الموقع',hWGMqtBy4wuLaVcj,429,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'_REMEMBERRESULTS_')
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'فلتر محدد',cbYKa2SXGwRCiQIW5NeosU9k,425)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'فلتر كامل',cbYKa2SXGwRCiQIW5NeosU9k,424)
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+'الرئيسية',cbYKa2SXGwRCiQIW5NeosU9k,421)
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('NavigationMenu(.*?)</div>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
	items = trdVA0JvFaD.findall('href="*(.*?)"*>(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	for llxFwq0CUNgQtivJzkHeGV,title in items:
		if title in P3UK1Rr4IdYe5: continue
		if '/actors' in llxFwq0CUNgQtivJzkHeGV: title = 'أفلام النجوم'
		elif '/netflix' in llxFwq0CUNgQtivJzkHeGV: title = 'أفلام ومسلسلات نيتفلكس'
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,421)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'قائمة تفصيلية',cbYKa2SXGwRCiQIW5NeosU9k,427)
	return
def ZmkCHrXyz4MEwQ1JeY2j(website=hWGMqtBy4wuLaVcj):
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',Str0BupDTFA,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'CIMA4U-MENU-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('FilteringTitle(.*?)PageTitle',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
	items = trdVA0JvFaD.findall('data-tax="*(.*?)"* data-id="*(.*?)[">]*<a href="*(.*?)[">]+.*?</div>(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	for OJx4sYA9nNbtPT5ezmDHdVBk2C7,id,llxFwq0CUNgQtivJzkHeGV,title in items:
		if title in P3UK1Rr4IdYe5: continue
		if 'netflix-movies' in llxFwq0CUNgQtivJzkHeGV: title = 'أفلام نيتفلكس'
		elif 'series-netflix' in llxFwq0CUNgQtivJzkHeGV: title = 'مسلسلات نيتفلكس'
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,421,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,OJx4sYA9nNbtPT5ezmDHdVBk2C7+'|'+id)
	return
def wg5aF3e8rcDh7SGpW6M1OPnkU(url,Zn0DwEg9b7zxavJ8yUqHO5dM1=hWGMqtBy4wuLaVcj):
	if '/HomepageLoader/' in url: url = url.strip('/')+'/mpaa/family/'
	items = []
	cbYKa2SXGwRCiQIW5NeosU9k = RRNODILCtGzvgpx(url,'url')
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',url,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'CIMA4U-TITLES-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	if not Zn0DwEg9b7zxavJ8yUqHO5dM1 or '|' in Zn0DwEg9b7zxavJ8yUqHO5dM1:
		if '|' not in Zn0DwEg9b7zxavJ8yUqHO5dM1: yKD0Te38NH9JclXnV6d = hWGMqtBy4wuLaVcj
		else: yKD0Te38NH9JclXnV6d = '/archive/'+Zn0DwEg9b7zxavJ8yUqHO5dM1
		xL3dgJWbrpso = False
		if 'PinSlider' in mMQ3FkNVa4IlxqY:
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'المميزة',url,421,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'featured')
			xL3dgJWbrpso = True
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('PageTitle(.*?)PageContent',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
			TfCqlZthRYgzkbE0GO = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
			yRE17DrswMOxv0Gc9H = trdVA0JvFaD.findall('data-tab="(.*?)".*?<span>(.*?)<',TfCqlZthRYgzkbE0GO,trdVA0JvFaD.DOTALL)
			for gEOFGhW3cVvmntfJLBau8,m4eVoJdSU51qs3y8Gg06fZNau7A in yRE17DrswMOxv0Gc9H:
				MDSF21x9HK3AZyGUhcb = cbYKa2SXGwRCiQIW5NeosU9k+'/ajaxcenter/action/HomepageLoader/tab/'+gEOFGhW3cVvmntfJLBau8+yKD0Te38NH9JclXnV6d+'/'
				RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+m4eVoJdSU51qs3y8Gg06fZNau7A,MDSF21x9HK3AZyGUhcb,421)
				xL3dgJWbrpso = True
		if xL3dgJWbrpso: RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	if Zn0DwEg9b7zxavJ8yUqHO5dM1=='featured':
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('PinSlider(.*?)MultiFilter',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if not DJvksH7ZAFUqW9OyQnbGjPCtwR1o: DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('PinSlider(.*?)PageTitle',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if DJvksH7ZAFUqW9OyQnbGjPCtwR1o: cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		else: cok5ZGXdQP7YhwtqyuaCnVevm6UB = hWGMqtBy4wuLaVcj
	elif '/HomepageLoader/' in url or '/searchcenter/' in url:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = mMQ3FkNVa4IlxqY
	elif '/filter/' in url:
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('PageContent(.*?)class="*pagination"*',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
	elif '/actors' in url:
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('PageContent(.*?)class="*pagination"*',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('href="*(.*?)[">]+.*?image:url\((.*?)\).*?ActorName">(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	else:
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('Cima4uBlocks(.*?)</li></ul>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if DJvksH7ZAFUqW9OyQnbGjPCtwR1o: cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		else: cok5ZGXdQP7YhwtqyuaCnVevm6UB = hWGMqtBy4wuLaVcj
	if not items: items = trdVA0JvFaD.findall('class="*MovieBlock"*.*?href="*(.*?)[">]+.*?image:url\((.*?)\).*?image.*?BoxTitleInfo.*?</div></div>(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	if not items: items = trdVA0JvFaD.findall('class="MovieBlock".*?href="(.*?)".*?data-image="(.*?)".*?alt="(.*?)"',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	REbVyXis1w4Ae = []
	for llxFwq0CUNgQtivJzkHeGV,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,title in items:
		if not title: continue
		if '?news=' in llxFwq0CUNgQtivJzkHeGV: continue
		title = title.replace('مشاهدة ',hWGMqtBy4wuLaVcj)
		title = LNtIDdBA52P(title)
		IIsmGy4pd7 = trdVA0JvFaD.findall('(.*?) حلقة \d+',title,trdVA0JvFaD.DOTALL)
		if IIsmGy4pd7 and 'حلقة' in title:
			title = '_MOD_' + IIsmGy4pd7[0]
			if title not in REbVyXis1w4Ae:
				RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,422,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
				REbVyXis1w4Ae.append(title)
		elif '/actor/' in llxFwq0CUNgQtivJzkHeGV: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,421,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
		else: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,422,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('pagination(.*?)</ul>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o and Zn0DwEg9b7zxavJ8yUqHO5dM1!='featured':
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('href=[\'\"](.*?)[\'\"]>(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,title in items:
			title = LNtIDdBA52P(title)
			title = title.replace('الصفحة ',hWGMqtBy4wuLaVcj)
			if title!=hWGMqtBy4wuLaVcj: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'صفحة '+title,llxFwq0CUNgQtivJzkHeGV,421)
	C1EL24u0ZA8YRg9vfBXDxiyQ5lFoO = trdVA0JvFaD.findall('</li><a href="(.*?)".*?>(.*?)<',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if C1EL24u0ZA8YRg9vfBXDxiyQ5lFoO:
		llxFwq0CUNgQtivJzkHeGV,title = C1EL24u0ZA8YRg9vfBXDxiyQ5lFoO[0]
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,421)
	return
def ppcbK7vZlfXRTt0BEei9zho(url):
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'CIMA4U-SEASONS-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('class="WatchNow".*?href="(.*?)"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		url = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'CIMA4U-SEASONS-2nd')
		mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('SeasonsSections(.*?)</div></div></div>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if '/tag/' in url or '/actor' in url:
		wg5aF3e8rcDh7SGpW6M1OPnkU(url)
	elif DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG = MMk8qKvcJe4fQHm3EG7diBD5.getInfoLabel('ListItem.Thumb')
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall("href='(.*?)'>(.*?)<",cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		YpxlWik2vNeHs = ['مسلسل','موسم','برنامج','حلقة']
		for llxFwq0CUNgQtivJzkHeGV,title in items:
			if any(BoSjXKxz41DcneO9UimClE in title for BoSjXKxz41DcneO9UimClE in YpxlWik2vNeHs):
				RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,423,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
			else: RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,426,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
	else: GrsxUhb0PEXj2FQRAkD4q(url)
	return
def GrsxUhb0PEXj2FQRAkD4q(url):
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'CIMA4U-EPISODES-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG = trdVA0JvFaD.findall('"background-image:url\((.*?)\)',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG: Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG = Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG[0]
	else: Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG = hWGMqtBy4wuLaVcj
	KkYdJElVmtDPCUg = trdVA0JvFaD.findall('EpisodesSection(.*?)</ul>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if KkYdJElVmtDPCUg:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = KkYdJElVmtDPCUg[0]
		items = trdVA0JvFaD.findall('href="(.*?)"><em>(.*?)<.*?<span>(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,title,IIsmGy4pd7 in items:
			title = title+Mpsm2VF1OBnCRvK3qf6+IIsmGy4pd7
			RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,426,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
	else: RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+'رابط التشغيل',url,426,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
	return
def oanus6TxUFNAhSZKpJdYlEC4mV(url):
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',url,hWGMqtBy4wuLaVcj,headers,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'CIMA4U-PLAY-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	UHX1OkZxbTeLVitv = sDQvwGASB0Vf67mik.url
	if VKiGj1LundAJQwEXcqgxC: UHX1OkZxbTeLVitv = UHX1OkZxbTeLVitv.encode(a7VXeDU82IfQEnPZAdiT)
	cbYKa2SXGwRCiQIW5NeosU9k = RRNODILCtGzvgpx(UHX1OkZxbTeLVitv,'url')
	Dvi8asSrQYX5wE3KMIxT91me = []
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('WatchSection(.*?)</div></div>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('data-link="(.*?)".*? />(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for AQFhw7Rmi9IJUoX,title in items:
			title = title.strip(Mpsm2VF1OBnCRvK3qf6)
			if 'myvid' in title.lower(): title = 'خاص '+title
			llxFwq0CUNgQtivJzkHeGV = cbYKa2SXGwRCiQIW5NeosU9k+'/structure/server.php?id='+AQFhw7Rmi9IJUoX+'?named='+title+'__watch'
			llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV.replace(y6eSQlZEV8uwKG5M3,hWGMqtBy4wuLaVcj)
			Dvi8asSrQYX5wE3KMIxT91me.append(llxFwq0CUNgQtivJzkHeGV)
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('DownloadServers(.*?)</div></div>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('href="(.*?)".*? />(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,title in items:
			title = title.strip(Mpsm2VF1OBnCRvK3qf6)
			if 'myvid' in title.lower(): m4eVoJdSU51qs3y8Gg06fZNau7A = '__خاص'
			else: m4eVoJdSU51qs3y8Gg06fZNau7A = hWGMqtBy4wuLaVcj
			llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV+'?named='+title+'__download'+m4eVoJdSU51qs3y8Gg06fZNau7A
			llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV.replace(y6eSQlZEV8uwKG5M3,hWGMqtBy4wuLaVcj)
			Dvi8asSrQYX5wE3KMIxT91me.append(llxFwq0CUNgQtivJzkHeGV)
	import oosSOfvdEQ
	oosSOfvdEQ.zfdYjsGLg8M6i15qZWh(Dvi8asSrQYX5wE3KMIxT91me,xjPuFK3EsIZSiobQ5X,'video',url)
	return
def lPwaAjFTMG4n7iSLkXcEuK0Zm(search):
	search,vvKf4sXgZIMyEJPuC,showDialogs = IVTEJQOiMR2dYta9C(search)
	if search==hWGMqtBy4wuLaVcj: search = TrzfUidpv1LyAYqwexHJDuS()
	if search==hWGMqtBy4wuLaVcj: return
	search = search.replace(Mpsm2VF1OBnCRvK3qf6,'+')
	url = Str0BupDTFA+'/Search?q='+search
	wg5aF3e8rcDh7SGpW6M1OPnkU(url,'search')
	return
def n92Ia7FtBScTYHrGRhkP5zi(url):
	if 'smartemadfilter' not in url: url = RRNODILCtGzvgpx(url,'url')
	else: url = url.split('/smartemadfilter?')[0]
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'CIMA4U-GET_FILTERS_BLOCKS-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('MultiFilter(.*?)PageTitle',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
	f5rVHP4bmCd7cqvuYEQJlnLTk6yGRS = trdVA0JvFaD.findall('Hoverable.*?<span>(.*?)</span>.*?"all".*?(data-tax="(.*?)".*?)</ul>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	return f5rVHP4bmCd7cqvuYEQJlnLTk6yGRS
def mPVz8jRSf0iHd2FNTswv4O1gy(cok5ZGXdQP7YhwtqyuaCnVevm6UB):
	items = trdVA0JvFaD.findall('data-id="(.*?)".*?</div>(.*?)</a>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	return items
def pMv1ZGJ0iQE(url):
	QQUSNlXZ6MEoH1uftykesbKq2 = url.split('/smartemadfilter?')[0]
	cbtS4iE32pOBe5rUxdfIjlXhokKMR = RRNODILCtGzvgpx(url,'url')
	url = url.replace(QQUSNlXZ6MEoH1uftykesbKq2,cbtS4iE32pOBe5rUxdfIjlXhokKMR)
	url = url.replace('/smartemadfilter?','/ajaxcenter/action/HomepageLoader/')
	url = url.replace('=','/').replace('&','/')
	url = url+'/'
	return url
uEwaiBFX1Hr5 = ['category','types','release-year']
MM02bgXexGhSpwQtlILydi1KJCOFz = ['Quality','release-year','types','category']
def hadMgR0nOKHoGqpA(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==hWGMqtBy4wuLaVcj: RJGtCsyDgi0X,kYI6n5bUD83Z = hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj
	else: RJGtCsyDgi0X,kYI6n5bUD83Z = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if '/category/' in url:
			global uEwaiBFX1Hr5
			uEwaiBFX1Hr5 = uEwaiBFX1Hr5[1:]
		if uEwaiBFX1Hr5[0]+'=' not in RJGtCsyDgi0X: OJx4sYA9nNbtPT5ezmDHdVBk2C7 = uEwaiBFX1Hr5[0]
		for PPuqrvDLEViYOMf1dmkK7 in range(len(uEwaiBFX1Hr5[0:-1])):
			if uEwaiBFX1Hr5[PPuqrvDLEViYOMf1dmkK7]+'=' in RJGtCsyDgi0X: OJx4sYA9nNbtPT5ezmDHdVBk2C7 = uEwaiBFX1Hr5[PPuqrvDLEViYOMf1dmkK7+1]
		nnqvmxlXub3iVDM = RJGtCsyDgi0X+'&'+OJx4sYA9nNbtPT5ezmDHdVBk2C7+'=0'
		tuYnONZ6GaCecv4TErUHMdBX2DIb8K = kYI6n5bUD83Z+'&'+OJx4sYA9nNbtPT5ezmDHdVBk2C7+'=0'
		BvO3oKUrHNCwVm791b80sZg = nnqvmxlXub3iVDM.strip('&')+'___'+tuYnONZ6GaCecv4TErUHMdBX2DIb8K.strip('&')
		PPlq1nxLf6CamuBI0psW = kKWuMB69mcOHPn3XilFdvp(kYI6n5bUD83Z,'modified_filters')
		NPM3HKQ57xe = url+'/smartemadfilter?'+PPlq1nxLf6CamuBI0psW
	elif type=='ALL_ITEMS_FILTER':
		I2OnWkrPaVbwBSHiYR3LZ = kKWuMB69mcOHPn3XilFdvp(RJGtCsyDgi0X,'modified_values')
		I2OnWkrPaVbwBSHiYR3LZ = jkiCS0UWs2dNAJcGKn6mbHD(I2OnWkrPaVbwBSHiYR3LZ)
		if kYI6n5bUD83Z!=hWGMqtBy4wuLaVcj: kYI6n5bUD83Z = kKWuMB69mcOHPn3XilFdvp(kYI6n5bUD83Z,'modified_filters')
		if kYI6n5bUD83Z==hWGMqtBy4wuLaVcj: NPM3HKQ57xe = url
		else: NPM3HKQ57xe = url+'/smartemadfilter?'+kYI6n5bUD83Z
		NPM3HKQ57xe = pMv1ZGJ0iQE(NPM3HKQ57xe)
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'أظهار قائمة الفيديو التي تم اختيارها ',NPM3HKQ57xe,421,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'filter')
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+' [[   '+I2OnWkrPaVbwBSHiYR3LZ+'   ]]',NPM3HKQ57xe,421,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'filter')
		RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	f5rVHP4bmCd7cqvuYEQJlnLTk6yGRS = n92Ia7FtBScTYHrGRhkP5zi(url)
	dict = {}
	for name,cok5ZGXdQP7YhwtqyuaCnVevm6UB,bksErtC1hwcVqlfyM82AnD in f5rVHP4bmCd7cqvuYEQJlnLTk6yGRS:
		if '/category/' in url and bksErtC1hwcVqlfyM82AnD=='category': continue
		name = name.replace('--',hWGMqtBy4wuLaVcj)
		items = mPVz8jRSf0iHd2FNTswv4O1gy(cok5ZGXdQP7YhwtqyuaCnVevm6UB)
		if '=' not in NPM3HKQ57xe: NPM3HKQ57xe = url
		if type=='SPECIFIED_FILTER':
			if OJx4sYA9nNbtPT5ezmDHdVBk2C7!=bksErtC1hwcVqlfyM82AnD: continue
			elif len(items)<2:
				if bksErtC1hwcVqlfyM82AnD==uEwaiBFX1Hr5[-1]:
					url = pMv1ZGJ0iQE(url)
					wg5aF3e8rcDh7SGpW6M1OPnkU(url)
				else: hadMgR0nOKHoGqpA(NPM3HKQ57xe,'SPECIFIED_FILTER___'+BvO3oKUrHNCwVm791b80sZg)
				return
			else:
				NPM3HKQ57xe = pMv1ZGJ0iQE(NPM3HKQ57xe)
				if bksErtC1hwcVqlfyM82AnD==uEwaiBFX1Hr5[-1]: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'الجميع',NPM3HKQ57xe,421,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'filter')
				else: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'الجميع',NPM3HKQ57xe,425,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,BvO3oKUrHNCwVm791b80sZg)
		elif type=='ALL_ITEMS_FILTER':
			nnqvmxlXub3iVDM = RJGtCsyDgi0X+'&'+bksErtC1hwcVqlfyM82AnD+'=0'
			tuYnONZ6GaCecv4TErUHMdBX2DIb8K = kYI6n5bUD83Z+'&'+bksErtC1hwcVqlfyM82AnD+'=0'
			BvO3oKUrHNCwVm791b80sZg = nnqvmxlXub3iVDM+'___'+tuYnONZ6GaCecv4TErUHMdBX2DIb8K
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'الجميع :'+name,NPM3HKQ57xe,424,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,BvO3oKUrHNCwVm791b80sZg)
		dict[bksErtC1hwcVqlfyM82AnD] = {}
		for BoSjXKxz41DcneO9UimClE,PBo1KkyMCgH8eNDaLtZVcr3EnIi2 in items:
			if BoSjXKxz41DcneO9UimClE=='196533': PBo1KkyMCgH8eNDaLtZVcr3EnIi2 = 'أفلام نيتفلكس'
			elif BoSjXKxz41DcneO9UimClE=='196531': PBo1KkyMCgH8eNDaLtZVcr3EnIi2 = 'مسلسلات نيتفلكس'
			if PBo1KkyMCgH8eNDaLtZVcr3EnIi2 in P3UK1Rr4IdYe5: continue
			dict[bksErtC1hwcVqlfyM82AnD][BoSjXKxz41DcneO9UimClE] = PBo1KkyMCgH8eNDaLtZVcr3EnIi2
			nnqvmxlXub3iVDM = RJGtCsyDgi0X+'&'+bksErtC1hwcVqlfyM82AnD+'='+PBo1KkyMCgH8eNDaLtZVcr3EnIi2
			tuYnONZ6GaCecv4TErUHMdBX2DIb8K = kYI6n5bUD83Z+'&'+bksErtC1hwcVqlfyM82AnD+'='+BoSjXKxz41DcneO9UimClE
			S80DwNWuMTZx4El = nnqvmxlXub3iVDM+'___'+tuYnONZ6GaCecv4TErUHMdBX2DIb8K
			title = PBo1KkyMCgH8eNDaLtZVcr3EnIi2+' :'#+dict[bksErtC1hwcVqlfyM82AnD]['0']
			title = PBo1KkyMCgH8eNDaLtZVcr3EnIi2+' :'+name
			if type=='ALL_ITEMS_FILTER': RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,url,424,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,S80DwNWuMTZx4El)
			elif type=='SPECIFIED_FILTER' and uEwaiBFX1Hr5[-2]+'=' in RJGtCsyDgi0X:
				PPlq1nxLf6CamuBI0psW = kKWuMB69mcOHPn3XilFdvp(tuYnONZ6GaCecv4TErUHMdBX2DIb8K,'modified_filters')
				CMzQFXeI08KDwAJ9p = url+'/smartemadfilter?'+PPlq1nxLf6CamuBI0psW
				CMzQFXeI08KDwAJ9p = pMv1ZGJ0iQE(CMzQFXeI08KDwAJ9p)
				RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,CMzQFXeI08KDwAJ9p,421,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'filter')
			else: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,url,425,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,S80DwNWuMTZx4El)
	return
def kKWuMB69mcOHPn3XilFdvp(UGewLrVFhBCo7MdZ8KEaJWXgYp,mode):
	UGewLrVFhBCo7MdZ8KEaJWXgYp = UGewLrVFhBCo7MdZ8KEaJWXgYp.replace('=&','=0&')
	UGewLrVFhBCo7MdZ8KEaJWXgYp = UGewLrVFhBCo7MdZ8KEaJWXgYp.strip('&')
	ONVGLC8DSp4 = {}
	if '=' in UGewLrVFhBCo7MdZ8KEaJWXgYp:
		items = UGewLrVFhBCo7MdZ8KEaJWXgYp.split('&')
		for ImYg2jxU6Lc9Q1C4Oko in items:
			glBvuIRTJseUHjari,BoSjXKxz41DcneO9UimClE = ImYg2jxU6Lc9Q1C4Oko.split('=')
			ONVGLC8DSp4[glBvuIRTJseUHjari] = BoSjXKxz41DcneO9UimClE
	mJuhvt0RPAbBMSla = hWGMqtBy4wuLaVcj
	for key in MM02bgXexGhSpwQtlILydi1KJCOFz:
		if key in list(ONVGLC8DSp4.keys()): BoSjXKxz41DcneO9UimClE = ONVGLC8DSp4[key]
		else: BoSjXKxz41DcneO9UimClE = '0'
		if '%' not in BoSjXKxz41DcneO9UimClE: BoSjXKxz41DcneO9UimClE = e1mT8H4dGS3XFyx0KLUA9(BoSjXKxz41DcneO9UimClE)
		if mode=='modified_values' and BoSjXKxz41DcneO9UimClE!='0': mJuhvt0RPAbBMSla = mJuhvt0RPAbBMSla+' + '+BoSjXKxz41DcneO9UimClE
		elif mode=='modified_filters' and BoSjXKxz41DcneO9UimClE!='0': mJuhvt0RPAbBMSla = mJuhvt0RPAbBMSla+'&'+key+'='+BoSjXKxz41DcneO9UimClE
		elif mode=='all': mJuhvt0RPAbBMSla = mJuhvt0RPAbBMSla+'&'+key+'='+BoSjXKxz41DcneO9UimClE
	mJuhvt0RPAbBMSla = mJuhvt0RPAbBMSla.strip(' + ')
	mJuhvt0RPAbBMSla = mJuhvt0RPAbBMSla.strip('&')
	mJuhvt0RPAbBMSla = mJuhvt0RPAbBMSla.replace('=0','=')
	return mJuhvt0RPAbBMSla
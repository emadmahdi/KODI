# -*- coding: utf-8 -*-
import sys as zGjD5QAkd7SO9YPcZl
A56Abl2j14QS = zGjD5QAkd7SO9YPcZl.version_info [0] == 2
qO2vebR9rSTZnuJDW = 2048
EECQl2Zun37S0KkWwtIDHYNai6Ayd8 = 7
def wwTjCFmkUK (mMBv4T89VDdfJGL):
	global ylRUYSmHX7oCf93TADc8J6rqMVL
	tE23ZuI91qGJ = ord (mMBv4T89VDdfJGL [-1])
	huZOyFMzvY3LpEf = mMBv4T89VDdfJGL [:-1]
	FXE237NbgJweKmBxPfVnsAoYjCazqW = tE23ZuI91qGJ % len (huZOyFMzvY3LpEf)
	LQ2yAP51CVNFXdr = huZOyFMzvY3LpEf [:FXE237NbgJweKmBxPfVnsAoYjCazqW] + huZOyFMzvY3LpEf [FXE237NbgJweKmBxPfVnsAoYjCazqW:]
	if A56Abl2j14QS:
		R0i7UHvbBw25n8 = unicode () .join ([unichr (ord (cIsD9VN758uwbLUaGM2zmEY) - qO2vebR9rSTZnuJDW - (o42QnFjKJ5l98hWTqzCDi73LcvNA + tE23ZuI91qGJ) % EECQl2Zun37S0KkWwtIDHYNai6Ayd8) for o42QnFjKJ5l98hWTqzCDi73LcvNA, cIsD9VN758uwbLUaGM2zmEY in enumerate (LQ2yAP51CVNFXdr)])
	else:
		R0i7UHvbBw25n8 = str () .join ([chr (ord (cIsD9VN758uwbLUaGM2zmEY) - qO2vebR9rSTZnuJDW - (o42QnFjKJ5l98hWTqzCDi73LcvNA + tE23ZuI91qGJ) % EECQl2Zun37S0KkWwtIDHYNai6Ayd8) for o42QnFjKJ5l98hWTqzCDi73LcvNA, cIsD9VN758uwbLUaGM2zmEY in enumerate (LQ2yAP51CVNFXdr)])
	return eval (R0i7UHvbBw25n8)
NeO3CTLHrPfWUoIgy8Q,KNIvHPjUbhr,CnbBKmtF1x84q7AW=wwTjCFmkUK,wwTjCFmkUK,wwTjCFmkUK
zyvJMtBhrw,MMizeNH0AKu,KBkxSYaz93pu1=CnbBKmtF1x84q7AW,KNIvHPjUbhr,NeO3CTLHrPfWUoIgy8Q
LB2q7IVRpcyXlE6C3ihZruPe4An1Y,EDgpT9hIF6GCfl0vXiWnBANjOUVRua,XQo0YS3sk4rHAvwyNltf9CipLWMjx=KBkxSYaz93pu1,MMizeNH0AKu,zyvJMtBhrw
hWUz1ujibPY3G9MIZmvS4kVaK7dT,DJ1ICpbyR2,e2qDYgipPmTw4KvBLnochr=XQo0YS3sk4rHAvwyNltf9CipLWMjx,EDgpT9hIF6GCfl0vXiWnBANjOUVRua,LB2q7IVRpcyXlE6C3ihZruPe4An1Y
A6dMB1FlgxVivJ2fk9C,mkHKSQvjWr5BTcM3wVY,o1u5dij9UrcbXzVS8lwIWfKpnqM=e2qDYgipPmTw4KvBLnochr,DJ1ICpbyR2,hWUz1ujibPY3G9MIZmvS4kVaK7dT
JwiZdgbG5HYuCIsj69aBSRQ0nrNkET,SqrG5mU3j96ldsFpExobw40TJY,HHoGx7Flus60=o1u5dij9UrcbXzVS8lwIWfKpnqM,mkHKSQvjWr5BTcM3wVY,A6dMB1FlgxVivJ2fk9C
QVDJLRlxNg127jMX,gDuGMR3z1aV6YdLmCpiO8Kl,jeAby54c02TgG8zuivonX91=HHoGx7Flus60,SqrG5mU3j96ldsFpExobw40TJY,JwiZdgbG5HYuCIsj69aBSRQ0nrNkET
S1SgCFYGJeMvfp5iZXK,dv0trJR7PwmKyxDYO52VLau8gEph,QvgnCALNstmuUJiET=jeAby54c02TgG8zuivonX91,gDuGMR3z1aV6YdLmCpiO8Kl,QVDJLRlxNg127jMX
OOsBSKq9u6J2lC5WdYpvNMHaFP4,rwQN9AKhLCuMfHxjlbX0U,xcChIL13BpR8WArNt9Pl0So=QvgnCALNstmuUJiET,dv0trJR7PwmKyxDYO52VLau8gEph,S1SgCFYGJeMvfp5iZXK
sULh4NjakzI8He7xJCMGrql,LAhIMyBG0xZVUlO4rJ9z5fbDFgCs,GA4NBdjuZqkKUX6IEMvHPoegDyVrLm=xcChIL13BpR8WArNt9Pl0So,rwQN9AKhLCuMfHxjlbX0U,OOsBSKq9u6J2lC5WdYpvNMHaFP4
ITvnUAMXsyb4eO,wwPrSDa21lUh,FimxS5jkaq1RcJ8DnWTZNO4zQClwt=GA4NBdjuZqkKUX6IEMvHPoegDyVrLm,LAhIMyBG0xZVUlO4rJ9z5fbDFgCs,sULh4NjakzI8He7xJCMGrql
from m8L6HZjgX1 import *
import base64 as FxG0Q9kuBSmTyM
xjPuFK3EsIZSiobQ5X = FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠪࡐࡎࡈࡓࡕ࡙ࡒࠫୱ")
FvkuXRitwj = {}
vNRpDl1awktg7QP4m0KGqMTS2i = []
xaUyi1IZb4psmHdLP6,vZf1CMiWboX9m,GlE6YUzP4tDQhoiRTWFy37Cxb = hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj
tcQ5U3FBMOY2iXue7z = {}
oaygHCpIDcs8wA,vv5MhADynk0zUapIWNSexuftOYb = [ybdv7XcT3lxF6QezULwCAGk],[ybdv7XcT3lxF6QezULwCAGk]
hlxkBcuTP3dfMLs8t = fEXMiAyG3ql4vKB
if H4qZ2hwilNJYTmCFEQyaSs98cPM0gR:
	van3wiJRm0T = u56uNLKlxv1wA83gbjpJPhr0E2kfd.translatePath(zyvJMtBhrw(u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯ࡹࡤࡰࡧࠬ୲"))
	W96kNDymei = u56uNLKlxv1wA83gbjpJPhr0E2kfd.translatePath(QVDJLRlxNg127jMX(u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰ࡪࡲࡱࡪ࠭୳"))
	Q6F5pTtAGwIjoviOaXLCxR9JeV7 = u56uNLKlxv1wA83gbjpJPhr0E2kfd.translatePath(xcChIL13BpR8WArNt9Pl0So(u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱࡯ࡳ࡬ࡶࡡࡵࡪࠪ୴"))
	N4Rok9EBZeWumSCc2 = WQvYkNg7SysPFLitlGEn6.path.join(W96kNDymei,JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠧࡶࡵࡨࡶࡩࡧࡴࡢࠩ୵"),ITvnUAMXsyb4eO(u"ࠨࡆࡤࡸࡦࡨࡡࡴࡧࠪ୶"),FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠩࡄࡨࡩࡵ࡮ࡴ࠵࠶࠲ࡩࡨࠧ୷"))
	f6b17RiUv3eIFEgmC = WQvYkNg7SysPFLitlGEn6.path.join(W96kNDymei,e2qDYgipPmTw4KvBLnochr(u"ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬ୸"),MMizeNH0AKu(u"ࠫࡉࡧࡴࡢࡤࡤࡷࡪ࠭୹"),o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠬ࡜ࡩࡦࡹࡐࡳࡩ࡫ࡳ࠷࠰ࡧࡦࠬ୺"))
	wyG5ogaEBfHMV2uX3QRxzD = WQvYkNg7SysPFLitlGEn6.path.join(W96kNDymei,e2qDYgipPmTw4KvBLnochr(u"࠭ࡵࡴࡧࡵࡨࡦࡺࡡࠨ୻"),GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠧࡅࡣࡷࡥࡧࡧࡳࡦࠩ୼"),CnbBKmtF1x84q7AW(u"ࠨࡖࡨࡼࡹࡻࡲࡦࡵ࠴࠷࠳ࡪࡢࠨ୽"))
	FiSv0uqKNEbQx3dXlWZhPV8 = ITvnUAMXsyb4eO(u"ࡷࠪࡠࡺ࠶࠲ࡥ࠳ࠪ୾")
	from urllib.parse import quote as _drLhef4VZ3xMkj2
else:
	van3wiJRm0T = MMk8qKvcJe4fQHm3EG7diBD5.translatePath(OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡸࡣ࡯ࡦࠫ୿"))
	W96kNDymei = MMk8qKvcJe4fQHm3EG7diBD5.translatePath(ITvnUAMXsyb4eO(u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯ࡩࡱࡰࡩࠬ஀"))
	Q6F5pTtAGwIjoviOaXLCxR9JeV7 = MMk8qKvcJe4fQHm3EG7diBD5.translatePath(o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰࡮ࡲ࡫ࡵࡧࡴࡩࠩ஁"))
	N4Rok9EBZeWumSCc2 = WQvYkNg7SysPFLitlGEn6.path.join(W96kNDymei,LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"࠭ࡵࡴࡧࡵࡨࡦࡺࡡࠨஂ"),LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠧࡅࡣࡷࡥࡧࡧࡳࡦࠩஃ"),FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠨࡃࡧࡨࡴࡴࡳ࠳࠹࠱ࡨࡧ࠭஄"))
	f6b17RiUv3eIFEgmC = WQvYkNg7SysPFLitlGEn6.path.join(W96kNDymei,rwQN9AKhLCuMfHxjlbX0U(u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫஅ"),QVDJLRlxNg127jMX(u"ࠪࡈࡦࡺࡡࡣࡣࡶࡩࠬஆ"),o1u5dij9UrcbXzVS8lwIWfKpnqM(u"࡛ࠫ࡯ࡥࡸࡏࡲࡨࡪࡹ࠶࠯ࡦࡥࠫஇ"))
	wyG5ogaEBfHMV2uX3QRxzD = WQvYkNg7SysPFLitlGEn6.path.join(W96kNDymei,OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧஈ"),HHoGx7Flus60(u"࠭ࡄࡢࡶࡤࡦࡦࡹࡥࠨஉ"),dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠧࡕࡧࡻࡸࡺࡸࡥࡴ࠳࠶࠲ࡩࡨࠧஊ"))
	FiSv0uqKNEbQx3dXlWZhPV8 = hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࡶࠩ࡟ࡹ࠵࠸ࡤ࠲ࠩ஋").encode(a7VXeDU82IfQEnPZAdiT)
	from urllib import quote as _drLhef4VZ3xMkj2
OG6qjT5MQi4lIe = WQvYkNg7SysPFLitlGEn6.path.join(Q6F5pTtAGwIjoviOaXLCxR9JeV7,NeO3CTLHrPfWUoIgy8Q(u"ࠩ࡮ࡳࡩ࡯࠮࡭ࡱࡪࠫ஌"))
IIavAQfbsU6DkGw4tSRWrX5nJlg2jP = WQvYkNg7SysPFLitlGEn6.path.join(Q6F5pTtAGwIjoviOaXLCxR9JeV7,NeO3CTLHrPfWUoIgy8Q(u"ࠪ࡯ࡴࡪࡩ࠯ࡱ࡯ࡨ࠳ࡲ࡯ࡨࠩ஍"))
bXmN7lhEQo2Tv4WGgDp5 = WQvYkNg7SysPFLitlGEn6.path.join(vA0ImpguajeHKJ6P,zyvJMtBhrw(u"ࠫ࡮ࡶࡴࡷ࠳ࡧࡥࡹࡧ࡟ࡠࡡ࠱ࡨࡧ࠭எ"))
Y3fGRujshztP0ZHgTBmkEdSiy89nV4 = WQvYkNg7SysPFLitlGEn6.path.join(vA0ImpguajeHKJ6P,wwPrSDa21lUh(u"ࠬ࡯ࡰࡵࡸ࠵ࡨࡦࡺࡡࡠࡡࡢ࠲ࡩࡨࠧஏ"))
ff2dFKJpYzojAknBG = WQvYkNg7SysPFLitlGEn6.path.join(vA0ImpguajeHKJ6P,A6dMB1FlgxVivJ2fk9C(u"࠭࡭࠴ࡷࡧࡥࡹࡧ࡟ࡠࡡ࠱ࡨࡧ࠭ஐ"))
IlCq2uKjye3ZgSADFc = WQvYkNg7SysPFLitlGEn6.path.join(vA0ImpguajeHKJ6P,gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠧࡧࡣࡹࡳࡺࡸࡩࡵࡧࡶ࠲ࡩࡧࡴࠨ஑"))
JfBKhMCkg0LvDObn2Rw9jpe5qcUzH = WQvYkNg7SysPFLitlGEn6.path.join(vA0ImpguajeHKJ6P,dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠨ࡫ࡳࡸࡻ࡬ࡩ࡭ࡧࡢࡣࡤ࠴ࡤࡢࡶࠪஒ"))
Kh82Z7XQGcjvNBpmztwReC = WQvYkNg7SysPFLitlGEn6.path.join(vA0ImpguajeHKJ6P,zyvJMtBhrw(u"ࠩࡰ࠷ࡺ࡬ࡩ࡭ࡧࡢࡣࡤ࠴ࡤࡢࡶࠪஓ"))
zKdeknjoPhL9gN8v = WQvYkNg7SysPFLitlGEn6.path.join(vA0ImpguajeHKJ6P,A6dMB1FlgxVivJ2fk9C(u"ࠪ࡭ࡲࡧࡧࡦࡵࠪஔ"))
q5xrdSOHgu2FevD9LjKp = WQvYkNg7SysPFLitlGEn6.path.join(zKdeknjoPhL9gN8v,DJ1ICpbyR2(u"ࠫࡩ࡯ࡡ࡭ࡱࡪࡷࠬக"))
xx74tQY9vGjRuXZs = WQvYkNg7SysPFLitlGEn6.path.join(zKdeknjoPhL9gN8v,rwQN9AKhLCuMfHxjlbX0U(u"ࠬࡴ࡯ࡵ࡫ࡩ࡭ࡨࡧࡴࡪࡱࡱࡷࠬ஖"))
UUszEDWjBZTu3rOSF4v1 = WQvYkNg7SysPFLitlGEn6.path.join(q5xrdSOHgu2FevD9LjKp,EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"࠭ࡤࡪࡣ࡯ࡳ࡬ࡥ࠰࠱࠲࠳ࡣ࠳ࡶ࡮ࡨࠩ஗"))
ggKyfILOkNPGxMtDQueVSZ = FaP2ug05rl8EmAHkQsNid.Addon().getAddonInfo(rwQN9AKhLCuMfHxjlbX0U(u"ࠧࡱࡣࡷ࡬ࠬ஘"))
Hs04GVD6tArB7jW = WQvYkNg7SysPFLitlGEn6.path.join(ggKyfILOkNPGxMtDQueVSZ,CnbBKmtF1x84q7AW(u"ࠨ࡫ࡦࡳࡳ࠴ࡰ࡯ࡩࠪங"))
O8OieWNvbV1BL5HXmCAUFcx6DjQfw = WQvYkNg7SysPFLitlGEn6.path.join(ggKyfILOkNPGxMtDQueVSZ,mkHKSQvjWr5BTcM3wVY(u"ࠩࡷ࡬ࡺࡳࡢ࠯ࡲࡱ࡫ࠬச"))
zIXE7kBSlAbKF50 = WQvYkNg7SysPFLitlGEn6.path.join(ggKyfILOkNPGxMtDQueVSZ,HHoGx7Flus60(u"ࠪࡪࡦࡴࡡࡳࡶ࠱ࡴࡳ࡭ࠧ஛"))
b4ZxmJPGsW2QRgrTMEDU0kqLXNHYOi = WQvYkNg7SysPFLitlGEn6.path.join(ggKyfILOkNPGxMtDQueVSZ,FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠫࡧࡧ࡮࡯ࡧࡵ࠲ࡵࡴࡧࠨஜ"))
QQVGCAy9ivhzsL8YD1naEIlkU6WO = WQvYkNg7SysPFLitlGEn6.path.join(ggKyfILOkNPGxMtDQueVSZ,ITvnUAMXsyb4eO(u"ࠬࡲࡡ࡯ࡦࡶࡧࡦࡶࡥ࠯ࡲࡱ࡫ࠬ஝"))
DfvWRV1zTrQ = WQvYkNg7SysPFLitlGEn6.path.join(ggKyfILOkNPGxMtDQueVSZ,jeAby54c02TgG8zuivonX91(u"࠭ࡰࡰࡵࡷࡩࡷ࠴ࡰ࡯ࡩࠪஞ"))
dxzGDVwJh3MLWHrPlNiI0j5tCAe = WQvYkNg7SysPFLitlGEn6.path.join(ggKyfILOkNPGxMtDQueVSZ,SqrG5mU3j96ldsFpExobw40TJY(u"ࠧࡤ࡮ࡨࡥࡷࡲ࡯ࡨࡱ࠱ࡴࡳ࡭ࠧட"))
WjvU1PEkZuxMbzCRr28JyBaofLGFtq = WQvYkNg7SysPFLitlGEn6.path.join(ggKyfILOkNPGxMtDQueVSZ,o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠨࡥ࡯ࡩࡦࡸࡡࡳࡶ࠱ࡴࡳ࡭ࠧ஠"))
BU8LSZFzYdg = WQvYkNg7SysPFLitlGEn6.path.join(ggKyfILOkNPGxMtDQueVSZ,FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠩࡰࡩࡳࡻ࡟ࡳࡧࡧࡣ࠷࠶࠰ࡹ࠴࠸࠴࠳ࡶ࡮ࡨࠩ஡"))
O2AysQHU7D8YlBtC4xTXvz = WQvYkNg7SysPFLitlGEn6.path.join(ggKyfILOkNPGxMtDQueVSZ,mkHKSQvjWr5BTcM3wVY(u"ࠪࡧ࡭ࡧ࡮ࡨࡧ࡯ࡳ࡬࠴ࡴࡹࡶࠪ஢"))
g2jVSXyeCRdALnvbk4hTN17 = WQvYkNg7SysPFLitlGEn6.path.join(W96kNDymei,OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠫࡦࡪࡤࡰࡰࡶࠫண"))
muykopvadEFSL85fRCA1ND = WQvYkNg7SysPFLitlGEn6.path.join(W96kNDymei,QVDJLRlxNg127jMX(u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧத"),ITvnUAMXsyb4eO(u"࠭ࡡࡥࡦࡲࡲࡤࡪࡡࡵࡣࠪ஥"),nUy7x6dqmk92MPb,hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠧࡴࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡻࡱࡱ࠭஦"))
FhC0YikZjr8c74tNubWIToEfBl = WQvYkNg7SysPFLitlGEn6.path.join(van3wiJRm0T,wwPrSDa21lUh(u"ࠨ࡯ࡨࡨ࡮ࡧࠧ஧"),DJ1ICpbyR2(u"ࠩࡉࡳࡳࡺࡳࠨந"),QvgnCALNstmuUJiET(u"ࠪࡥࡷ࡯ࡡ࡭࠰ࡷࡸ࡫࠭ன"))
SdRCvwxfo1P95Jjb = LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"࠻ፔ")
A7ZIc5uC1nT0PWYHEjb2BfxeV38 = [XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ฺࠫ็ัࠨப"),jeAby54c02TgG8zuivonX91(u"ࠬษ่ๅࠩ஫"),e2qDYgipPmTw4KvBLnochr(u"࠭หศ่ํࠫ஬"),MMizeNH0AKu(u"ࠧฬษ็ฯࠬ஭"),o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠨำสฬ฾࠭ம"),gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠩัหู๊ࠧய"),e2qDYgipPmTw4KvBLnochr(u"ࠪืฬีำࠨர"),zyvJMtBhrw(u"ุࠫอศฺࠩற"),KBkxSYaz93pu1(u"ࠬัวๆ่ࠪல"),DJ1ICpbyR2(u"࠭สศี฼ࠫள"),sULh4NjakzI8He7xJCMGrql(u"ฺࠧษืีࠬழ")]
PPWZFTodxwQrjenBS0YmlXbp = hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠨ⸽ࠣ⼡ࠥ⸰ࠠ⸼ࠩவ")
Bv25dfmw6CgR = [wwPrSDa21lUh(u"ࠩ࡜ࡘࡇࡥࡃࡉࡃࡑࡒࡊࡒࡓࠨஶ")]
THiCdlyt1azhp5jsg28qYFGwJfS = [ITvnUAMXsyb4eO(u"ࠪࡍࡋࡏࡌࡎࠩஷ"),gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠫࡎࡌࡉࡍࡏ࠰ࡅࡗࡇࡂࡊࡅࠪஸ"),KNIvHPjUbhr(u"ࠬࡏࡆࡊࡎࡐ࠱ࡊࡔࡇࡍࡋࡖࡌࠬஹ")]
THiCdlyt1azhp5jsg28qYFGwJfS += [sULh4NjakzI8He7xJCMGrql(u"࠭ࡁࡌ࡙ࡄࡑࠬ஺"),DJ1ICpbyR2(u"ࠧࡂࡎࡐࡅࡆࡘࡅࡇࠩ஻"),hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠨࡕࡋࡓࡔࡌࡍࡂ࡚ࠪ஼"),FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠩࡄࡏࡔࡇࡍࠨ஽"),QvgnCALNstmuUJiET(u"ࠪࡉࡑࡉࡉࡏࡇࡐࡅࠬா")]
THiCdlyt1azhp5jsg28qYFGwJfS += [jeAby54c02TgG8zuivonX91(u"ࠫࡐࡇࡒࡃࡃࡏࡅ࡙࡜ࠧி"),NeO3CTLHrPfWUoIgy8Q(u"ࠬࡈࡏࡌࡔࡄࠫீ"),LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"࠭ࡁࡓࡃࡅࡍࡈ࡚ࡏࡐࡐࡖࠫு"),e2qDYgipPmTw4KvBLnochr(u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠲ࠩூ"),ITvnUAMXsyb4eO(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠴ࠪ௃")]
PPDYZBWQCn = [LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠩࡉࡅࡏࡋࡒࡔࡊࡒ࡛ࠬ௄"),o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠪࡇࡎࡓࡁࡏࡑ࡚ࠫ௅"),gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠫࡑࡕࡄ࡚ࡐࡈࡘࠬெ"),ITvnUAMXsyb4eO(u"ࠬࡇࡒࡂࡄࡖࡉࡊࡊࠧே"),KNIvHPjUbhr(u"࠭ࡓࡉࡃࡋࡍࡉࡔࡅࡘࡕࠪை"),JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠧࡌࡃࡗࡏࡔ࡚ࡔࡗࠩ௉"),jeAby54c02TgG8zuivonX91(u"ࠨࡕࡋࡓࡔࡌࡎࡆࡖࠪொ")]
PPDYZBWQCn += [MMizeNH0AKu(u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘࠫோ"),e2qDYgipPmTw4KvBLnochr(u"ࠪࡘ࡛ࡌࡕࡏࠩௌ"),ITvnUAMXsyb4eO(u"ࠫ࡜ࡋࡃࡊࡏࡄ࠵்ࠬ"),XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠬ࡝ࡅࡄࡋࡐࡅ࠷࠭௎"),SqrG5mU3j96ldsFpExobw40TJY(u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡂࠨ௏"),JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠧࡍࡃࡕࡓ࡟ࡇࠧௐ")]
vprCg1ZiPDKnqlmJL3 = [QVDJLRlxNg127jMX(u"ࠨࡅࡌࡑࡆࡇࡂࡅࡑࠪ௑"),XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠩࡆࡍࡒࡇࡆࡂࡐࡖࠫ௒"),e2qDYgipPmTw4KvBLnochr(u"ࠪࡇࡎࡓࡁࡍࡋࡊࡌ࡙࠭௓"),LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠫࡋࡕࡓࡕࡃࠪ௔"),gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠬࡇࡈࡘࡃࡎࠫ௕"),ITvnUAMXsyb4eO(u"࠭ࡆࡂࡄࡕࡅࡐࡇࠧ௖"),zyvJMtBhrw(u"ࠧࡇࡃࡖࡉࡑࡎࡄ࠳ࠩௗ"),xcChIL13BpR8WArNt9Pl0So(u"ࠨࡅࡌࡑࡆࡌࡒࡆࡇࠪ௘"),KBkxSYaz93pu1(u"࡙ࠩࡅࡗࡈࡏࡏࠩ௙"),CnbBKmtF1x84q7AW(u"ࠪࡗࡊࡘࡉࡆࡕࡗࡍࡒࡋࠧ௚")]
vprCg1ZiPDKnqlmJL3 += [JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠫࡘࡎࡏࡇࡊࡄࠫ௛"),sULh4NjakzI8He7xJCMGrql(u"ࠬࡈࡒࡔࡖࡈࡎࠬ௜"),DJ1ICpbyR2(u"࡙࠭ࡂࡓࡒࡘࠬ௝"),LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠧࡅࡔࡄࡑࡆ࡙࠷ࠨ௞"),CnbBKmtF1x84q7AW(u"ࠨࡅࡌࡑࡆ࠺࠰࠱ࠩ௟"),SqrG5mU3j96ldsFpExobw40TJY(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠷ࠫ௠"),xcChIL13BpR8WArNt9Pl0So(u"ࠪࡌࡆࡒࡁࡄࡋࡐࡅࠬ௡"),DJ1ICpbyR2(u"ࠫࡆࡑࡗࡂࡏࡗ࡙ࡇࡋࠧ௢"),S1SgCFYGJeMvfp5iZXK(u"ࠬࡇࡌࡎࡕࡗࡆࡆ࠭௣"),xcChIL13BpR8WArNt9Pl0So(u"࠭ࡃࡊࡏࡄ࠸ࡕ࠭௤"),o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠧࡇࡃࡕࡉࡘࡑࡏࠨ௥")]
vprCg1ZiPDKnqlmJL3 += [SqrG5mU3j96ldsFpExobw40TJY(u"ࠨࡈࡘࡗࡍࡇࡒࡗࡋࡇࡉࡔ࠭௦"),hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠩࡉ࡙ࡘࡎࡁࡓࡖ࡙ࠫ௧"),xcChIL13BpR8WArNt9Pl0So(u"ࠪࡏࡎࡘࡍࡂࡎࡎࠫ௨"),FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠫࡉࡘࡁࡎࡃࡆࡅࡋࡋࠧ௩"),QvgnCALNstmuUJiET(u"࡚ࠬࡉࡌࡃࡄࡘࠬ௪"),HHoGx7Flus60(u"࠭ࡓࡉࡃࡅࡅࡐࡇࡔ࡚ࠩ௫"),S1SgCFYGJeMvfp5iZXK(u"ࠧࡂࡐࡌࡑࡊࡠࡉࡅࠩ௬"),ITvnUAMXsyb4eO(u"ࠨࡅࡌࡑࡆ࡝ࡂࡂࡕࠪ௭")]
vprCg1ZiPDKnqlmJL3 += [QVDJLRlxNg127jMX(u"࡙ࠩࡍࡉࡋࡏࡏࡕࡄࡉࡒ࠭௮"),mkHKSQvjWr5BTcM3wVY(u"ࠪࡊ࡚ࡔࡏࡏࡖ࡙ࠫ௯"),MMizeNH0AKu(u"ࠫࡆ࡟ࡌࡐࡎࠪ௰"),HHoGx7Flus60(u"ࠬࡋࡌࡊࡈ࡙ࡍࡉࡋࡏࠨ௱"),EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"࠭ࡍࡂࡕࡄ࡚ࡎࡊࡅࡐࠩ௲")]
ZHpFwYcg1RJBasj3vye = [MMizeNH0AKu(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨ௳"),HHoGx7Flus60(u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯࡙ࡍࡉࡋࡏࡔࠩ௴"),xcChIL13BpR8WArNt9Pl0So(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡔࡑࡇ࡙ࡍࡋࡖࡘࡘ࠭௵"),OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱ࡈࡎࡁࡏࡐࡈࡐࡘ࠭௶")]
ZHpFwYcg1RJBasj3vye += [JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏࠩ௷"),DJ1ICpbyR2(u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰࡚ࡎࡊࡅࡐࡕࠪ௸"),LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱ࡕࡒࡁ࡚ࡎࡌࡗ࡙࡙ࠧ௹"),DJ1ICpbyR2(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲ࡉࡈࡂࡐࡑࡉࡑ࡙ࠧ௺"),QVDJLRlxNg127jMX(u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡌࡊࡘࡈࡗࠬ௻"),GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡉࡃࡖࡌ࡙ࡇࡇࡔࠩ௼")]
ZHpFwYcg1RJBasj3vye += [e2qDYgipPmTw4KvBLnochr(u"ࠪࡍࡕ࡚ࡖࠨ௽"),HHoGx7Flus60(u"ࠫࡎࡖࡔࡗ࠯ࡏࡍ࡛ࡋࠧ௾"),sULh4NjakzI8He7xJCMGrql(u"ࠬࡏࡐࡕࡘ࠰ࡑࡔ࡜ࡉࡆࡕࠪ௿"),MMizeNH0AKu(u"࠭ࡉࡑࡖ࡙࠱ࡘࡋࡒࡊࡇࡖࠫఀ")]
ZHpFwYcg1RJBasj3vye += [ITvnUAMXsyb4eO(u"ࠧࡎ࠵ࡘࠫఁ"),sULh4NjakzI8He7xJCMGrql(u"ࠨࡏ࠶࡙࠲ࡒࡉࡗࡇࠪం"),LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠩࡐ࠷࡚࠳ࡍࡐࡘࡌࡉࡘ࠭ః"),rwQN9AKhLCuMfHxjlbX0U(u"ࠪࡑ࠸࡛࠭ࡔࡇࡕࡍࡊ࡙ࠧఄ")]
s0RJNLCitcDe5UY2zGK1IB6O8xTr  = [A6dMB1FlgxVivJ2fk9C(u"ࠫࡆࡑࡗࡂࡏࠪఅ"),LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠬࡇࡒࡂࡄࡖࡉࡊࡊࠧఆ"),CnbBKmtF1x84q7AW(u"࠭ࡂࡐࡍࡕࡅࠬఇ"),EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠧࡂࡍࡒࡅࡒ࠭ఈ"),XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠨࡅࡌࡑࡆࡉࡌࡖࡄࠪఉ"),OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠩࡉࡅࡇࡘࡁࡌࡃࠪఊ"),gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠶ࠬఋ"),jeAby54c02TgG8zuivonX91(u"ࠫࡈࡏࡍࡂࡈࡕࡉࡊ࠭ఌ"),LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠬࡉࡉࡎࡃ࠷ࡔࠬ఍")]
s0RJNLCitcDe5UY2zGK1IB6O8xTr += [NeO3CTLHrPfWUoIgy8Q(u"࠭ࡃࡊࡏࡄࡊࡆࡔࡓࠨఎ"),e2qDYgipPmTw4KvBLnochr(u"ࠧࡄࡋࡐࡅࡑࡏࡇࡉࡖࠪఏ"),zyvJMtBhrw(u"ࠨࡅࡌࡑࡆࡔࡏࡘࠩఐ"),XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"࡚ࠩࡉࡈࡏࡍࡂ࠳ࠪ఑"),hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"࡛ࠪࡊࡉࡉࡎࡃ࠵ࠫఒ"),e2qDYgipPmTw4KvBLnochr(u"ࠫࡘࡎࡁࡉࡋࡇࡒࡊ࡝ࡓࠨఓ"),OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠬࡌࡏࡔࡖࡄࠫఔ"),zyvJMtBhrw(u"࠭ࡁࡉ࡙ࡄࡏࠬక"),KBkxSYaz93pu1(u"ࠧࡔࡊࡒࡓࡋࡔࡅࡕࠩఖ"),KBkxSYaz93pu1(u"ࠨࡕࡈࡖࡎࡋࡓࡕࡋࡐࡉࠬగ")]
s0RJNLCitcDe5UY2zGK1IB6O8xTr += [EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠩࡉࡅࡏࡋࡒࡔࡊࡒ࡛ࠬఘ"),CnbBKmtF1x84q7AW(u"ࠪࡏࡆࡘࡂࡂࡎࡄࡘ࡛࠭ఙ"),xcChIL13BpR8WArNt9Pl0So(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠶࠭చ"),e2qDYgipPmTw4KvBLnochr(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠸ࠧఛ"),NeO3CTLHrPfWUoIgy8Q(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠴ࠨజ"),QvgnCALNstmuUJiET(u"ࠧࡉࡃࡏࡅࡈࡏࡍࡂࠩఝ"),QVDJLRlxNg127jMX(u"ࠨࡃࡎ࡛ࡆࡓࡔࡖࡄࡈࠫఞ"),o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠩࡉࡅࡗࡋࡓࡌࡑࠪట")]
s0RJNLCitcDe5UY2zGK1IB6O8xTr += [GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠪࡐࡔࡊ࡙ࡏࡇࡗࠫఠ"),KNIvHPjUbhr(u"ࠫࡘࡎࡁࡉࡋࡇ࠸࡚࠭డ"),jeAby54c02TgG8zuivonX91(u"࡙ࠬࡈࡐࡑࡉࡑࡆ࡞ࠧఢ"),wwPrSDa21lUh(u"࠭ࡔࡗࡈࡘࡒࠬణ"),e2qDYgipPmTw4KvBLnochr(u"ࠧࡄࡋࡐࡅࡆࡈࡄࡐࠩత"),jeAby54c02TgG8zuivonX91(u"ࠨࡕࡋࡓࡋࡎࡁࠨథ"),e2qDYgipPmTw4KvBLnochr(u"࡙ࠩࡅࡗࡈࡏࡏࠩద"),e2qDYgipPmTw4KvBLnochr(u"ࠪࡅࡑࡓࡓࡕࡄࡄࠫధ")]
s0RJNLCitcDe5UY2zGK1IB6O8xTr += [HHoGx7Flus60(u"ࠫࡇࡘࡓࡕࡇࡍࠫన"),S1SgCFYGJeMvfp5iZXK(u"ࠬ࡟ࡁࡒࡑࡗࠫ఩"),gDuGMR3z1aV6YdLmCpiO8Kl(u"࠭ࡄࡓࡃࡐࡅࡘ࠽ࠧప"),QvgnCALNstmuUJiET(u"ࠧࡄࡋࡐࡅ࠹࠶࠰ࠨఫ"),FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠨࡃࡕࡅࡇࡏࡃࡕࡑࡒࡒࡘ࠭బ"),DJ1ICpbyR2(u"ࠩࡄࡐࡒࡇࡁࡓࡇࡉࠫభ"),XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠪࡏࡆ࡚ࡋࡐࡖࡗ࡚ࠬమ"),EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠫࡑࡇࡒࡐ࡜ࡄࠫయ")]
s0RJNLCitcDe5UY2zGK1IB6O8xTr += [ITvnUAMXsyb4eO(u"ࠬࡌࡕࡔࡊࡄࡖ࡛ࡏࡄࡆࡑࠪర"),KBkxSYaz93pu1(u"࠭ࡆࡖࡕࡋࡅࡗ࡚ࡖࠨఱ"),SqrG5mU3j96ldsFpExobw40TJY(u"ࠧࡌࡋࡕࡑࡆࡒࡋࠨల"),QvgnCALNstmuUJiET(u"ࠨࡆࡕࡅࡒࡇࡃࡂࡈࡈࠫళ"),DJ1ICpbyR2(u"ࠩࡗࡍࡐࡇࡁࡕࠩఴ"),zyvJMtBhrw(u"ࠪࡗࡍࡇࡂࡂࡍࡄࡘ࡞࠭వ"),ITvnUAMXsyb4eO(u"ࠫࡆࡔࡉࡎࡇ࡝ࡍࡉ࠭శ"),OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠬࡉࡉࡎࡃ࡚ࡆࡆ࡙ࠧష")]
pluVj0goNywh  = [dv0trJR7PwmKyxDYO52VLau8gEph(u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱࡛ࡏࡄࡆࡑࡖࠫస"),A6dMB1FlgxVivJ2fk9C(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲ࡖࡌࡂ࡛ࡏࡍࡘ࡚ࡓࠨహ"),A6dMB1FlgxVivJ2fk9C(u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡃࡉࡃࡑࡒࡊࡒࡓࠨ఺"),o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡍࡋ࡙ࡉࡘ࠭఻"),o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡊࡄࡗࡍ࡚ࡁࡈࡕ఼ࠪ")]
pluVj0goNywh += [mkHKSQvjWr5BTcM3wVY(u"ࠫࡎࡌࡉࡍࡏ࠰ࡅࡗࡇࡂࡊࡅࠪఽ"),S1SgCFYGJeMvfp5iZXK(u"ࠬࡏࡆࡊࡎࡐ࠱ࡊࡔࡇࡍࡋࡖࡌࠬా")]
pluVj0goNywh += [QVDJLRlxNg127jMX(u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡗࡋࡇࡉࡔ࡙ࠧి"),CnbBKmtF1x84q7AW(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡒࡏࡅ࡞ࡒࡉࡔࡖࡖࠫీ"),sULh4NjakzI8He7xJCMGrql(u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡆࡌࡆࡔࡎࡆࡎࡖࠫు")]
pluVj0goNywh += [sULh4NjakzI8He7xJCMGrql(u"ࠩࡌࡔ࡙࡜࠭ࡍࡋ࡙ࡉࠬూ"),mkHKSQvjWr5BTcM3wVY(u"ࠪࡍࡕ࡚ࡖ࠮ࡏࡒ࡚ࡎࡋࡓࠨృ"),QvgnCALNstmuUJiET(u"ࠫࡎࡖࡔࡗ࠯ࡖࡉࡗࡏࡅࡔࠩౄ")]
pluVj0goNywh += [FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠬࡓ࠳ࡖ࠯ࡏࡍ࡛ࡋࠧ౅"),OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"࠭ࡍ࠴ࡗ࠰ࡑࡔ࡜ࡉࡆࡕࠪె"),sULh4NjakzI8He7xJCMGrql(u"ࠧࡎ࠵ࡘ࠱ࡘࡋࡒࡊࡇࡖࠫే")]
ggQMla0FZ9znyKp56ToGJPb = [dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠨࡏ࠶࡙ࠬై"),ITvnUAMXsyb4eO(u"ࠩࡌࡔ࡙࡜ࠧ౉"),SqrG5mU3j96ldsFpExobw40TJY(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎࠨొ"),QVDJLRlxNg127jMX(u"ࠫࡎࡌࡉࡍࡏࠪో"),QvgnCALNstmuUJiET(u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭ౌ")]
eFskjYoBzr7Ua80Vvi = s0RJNLCitcDe5UY2zGK1IB6O8xTr+pluVj0goNywh
jxyKkBY2FhC6czAUNXe5i = s0RJNLCitcDe5UY2zGK1IB6O8xTr+ggQMla0FZ9znyKp56ToGJPb
Oi4dHUj1o6Is0ewZP7bzA = s0RJNLCitcDe5UY2zGK1IB6O8xTr+pluVj0goNywh+Bv25dfmw6CgR
ZRzNHsKaInDwbBSWfj9yAmLiXo2xvg = [LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"࠭ࡐࡓࡋ࡙ࡅ࡙ࡋ్ࠧ")]+THiCdlyt1azhp5jsg28qYFGwJfS+[wwPrSDa21lUh(u"ࠧࡎࡋ࡛ࡉࡉ࠭౎")]+PPDYZBWQCn+[QVDJLRlxNg127jMX(u"ࠨࡒࡘࡆࡑࡏࡃࠨ౏")]+vprCg1ZiPDKnqlmJL3+[GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠩࡓࡖࡎ࡜ࡁࡕࡇࠪ౐")]+ZHpFwYcg1RJBasj3vye
LZOi9HCezVMGtnaYD06K7 = [jeAby54c02TgG8zuivonX91(u"ࠪࡅࡐࡕࡁࡎࠩ౑"),S1SgCFYGJeMvfp5iZXK(u"ࠫࡆࡑࡗࡂࡏࠪ౒"),MMizeNH0AKu(u"ࠬࡏࡆࡊࡎࡐࠫ౓"),hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"࠭ࡋࡂࡔࡅࡅࡑࡇࡔࡗࠩ౔"),MMizeNH0AKu(u"ࠧࡂࡎࡐࡅࡆࡘࡅࡇౕࠩ"),FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠨࡕࡋࡓࡔࡌࡍࡂౖ࡚ࠪ"),LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠩࡖࡌࡎࡇࡖࡐࡋࡆࡉࠬ౗"),GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫౘ"),gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏࠩౙ"),CnbBKmtF1x84q7AW(u"ࠬࡓ࠳ࡖࠩౚ"),sULh4NjakzI8He7xJCMGrql(u"࠭ࡉࡑࡖ࡙ࠫ౛"),MMizeNH0AKu(u"ࠧࡃࡑࡎࡖࡆ࠭౜"),xcChIL13BpR8WArNt9Pl0So(u"ࠨࡇࡏࡇࡎࡔࡅࡎࡃࠪౝ"),NeO3CTLHrPfWUoIgy8Q(u"ࠩࡄࡖࡆࡈࡉࡄࡖࡒࡓࡓ࡙ࠧ౞")]
NOT_TO_TEST_ALL_SERVERS = [CnbBKmtF1x84q7AW(u"ࠪࡣࡆࡑࡏࡠࠩ౟"),gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠫࡤࡇࡋࡘࡡࠪౠ"),ITvnUAMXsyb4eO(u"ࠬࡥࡉࡇࡎࡢࠫౡ"),DJ1ICpbyR2(u"࠭࡟ࡌࡔࡅࡣࠬౢ"),EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠧࡠࡏࡕࡊࡤ࠭ౣ"),DJ1ICpbyR2(u"ࠨࡡࡖࡌࡒࡥࠧ౤"),S1SgCFYGJeMvfp5iZXK(u"ࠩࡢࡗࡍ࡜࡟ࠨ౥"),hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠪࡣ࡞࡛ࡔࡠࠩ౦"),OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠫࡤࡊࡌࡎࡡࠪ౧"),EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠬࡥࡍࡖࠩ౨"),jeAby54c02TgG8zuivonX91(u"࠭࡟ࡊࡒࠪ౩"),QvgnCALNstmuUJiET(u"ࠧࡠࡄࡎࡖࡤ࠭౪"),gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠨࡡࡈࡐࡈࡥࠧ౫"),DJ1ICpbyR2(u"ࠩࡢࡅࡗ࡚࡟ࠨ౬")]
xLj46t2Qbi3dr8EgRDXmPMqpUwsvN = [dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠪࡑࡊࡔࡕࡠࡔࡈ࡚ࡊࡘࡓࡆࡆࡢࡘࡊࡓࡐࠨ౭"),KBkxSYaz93pu1(u"ࠫࡒࡋࡎࡖࡡࡄࡗࡈࡋࡎࡅࡇࡇࡣ࡙ࡋࡍࡑࠩ౮"),rwQN9AKhLCuMfHxjlbX0U(u"ࠬࡓࡅࡏࡗࡢࡈࡊ࡙ࡃࡆࡐࡇࡉࡉࡥࡔࡆࡏࡓࠫ౯"),DJ1ICpbyR2(u"࠭ࡍࡆࡐࡘࡣࡗࡇࡎࡅࡑࡐࡍ࡟ࡋࡄࡠࡖࡈࡑࡕ࠭౰"),KBkxSYaz93pu1(u"ࠧࡎࡇࡑ࡙ࡤࡘࡅࡗࡇࡕࡗࡊࡊ࡟ࡑࡇࡕࡑࠬ౱"),XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠨࡏࡈࡒ࡚ࡥࡁࡔࡅࡈࡒࡉࡋࡄࡠࡒࡈࡖࡒ࠭౲"),FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠩࡐࡉࡓ࡛࡟ࡅࡇࡖࡇࡊࡔࡄࡆࡆࡢࡔࡊࡘࡍࠨ౳"),wwPrSDa21lUh(u"ࠪࡑࡊࡔࡕࡠࡔࡄࡒࡉࡕࡍࡊ࡜ࡈࡈࡤࡖࡅࡓࡏࠪ౴")]
oovCPgZVNS1xDtnUs = [
						o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࡙࠭ࡕࡋࡅࡗࡏࡎࡈ࠯࠴ࡷࡹ࠭౵")
						,KNIvHPjUbhr(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡚ࡖࡌࡆࡘࡉࡏࡉ࠰࠶ࡳࡪࠧ౶")
						,QvgnCALNstmuUJiET(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡐ࡙ࡑ࡚ࡉࡠ࡚ࡖࡌࡆࡘࡉࡏࡉ࠰࠵ࡸࡺࠧ౷")
						]
IYkLXVOJe2 = [
						o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡕࡈࡒࡉࡥࡁࡏࡃࡏ࡝࡙ࡏࡃࡔࡡࡈ࡚ࡊࡔࡔࡔ࠯࠴ࡷࡹ࠭౸")
						,wwPrSDa21lUh(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡈ࡜࡙ࡘࡁࡄࡖࡢࡑ࠸࡛࠸࠮࠳ࡶࡸࠬ౹")
						,LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡖࡆࡔࡄࡐࡏࡢ࡙ࡘࡋࡒࡂࡉࡈࡒ࡙࠳࠱ࡴࡶࠪ౺")
						,gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡋࡔࡠࡒࡕࡓ࡝ࡏࡅࡔࡡࡏࡍࡘ࡚࠭࠲ࡵࡷࠫ౻")
						,S1SgCFYGJeMvfp5iZXK(u"ࠫࡎࡖࡔࡗ࠯ࡆࡌࡊࡉࡋࡠࡃࡆࡇࡔ࡛ࡎࡕ࠯࠴ࡷࡹ࠭౼")
						,CnbBKmtF1x84q7AW(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡆࡑࡏࡓࡈࡇࡔࡊࡑࡑ࠱࠶ࡹࡴࠨ౽")
						,hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡑࡒࡋࡑࡋ࡟ࡏࡇ࡚ࡣࡍࡕࡓࡕࡐࡄࡑࡊ࠳࠱ࡴࡶࠪ౾")
						,QvgnCALNstmuUJiET(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡉࡒࡓࡌࡒࡅࡠࡐࡈ࡛ࡤࡎࡏࡔࡖࡑࡅࡒࡋ࠭࠴ࡴࡧࠫ౿")
						,SqrG5mU3j96ldsFpExobw40TJY(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡕࡉࡆࡊ࡟ࡂࡎࡏࡣࡆࡊࡄࡐࡐࡖࡣ࡝ࡓࡌ࠮࠳ࡶࡸࠬಀ")
						,gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡍࡏࡐࡉࡏࡉ࡚࡙ࡅࡓࡅࡒࡒ࡙ࡋࡎࡕ࠯࠴ࡷࡹ࠭ಁ")
						,HHoGx7Flus60(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡂ࡚ࡒࡄࡗࡘࡥࡁࡌ࡙ࡄࡑࡤࡉࡁࡑࡖࡆࡌࡆ࠳࠳ࡳࡦࠪಂ")
						,EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡃ࡛ࡓࡅࡘ࡙࡟ࡂࡍ࡚ࡅࡒࡥࡃࡂࡒࡗࡇࡍࡇ࠭࠶ࡶ࡫ࠫಃ")
						,FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠬࡋࡌࡄࡋࡑࡉࡒࡇ࠭ࡔࡇࡄࡖࡈࡎ࠭࠲ࡵࡷࠫ಄")
						,XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡛ࡗࡍࡇࡒࡊࡐࡊ࠱࠶ࡹࡴࠨಅ")
						,xcChIL13BpR8WArNt9Pl0So(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡜ࡘࡎࡁࡓࡋࡑࡋ࠲࠸࡮ࡥࠩಆ")
						]
HCW4OXeRDroS = IYkLXVOJe2+[
				 zyvJMtBhrw(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡓࡖࡔ࡞࡙ࡠࡖࡈࡗ࡙࠳࠱ࡴࡶࠪಇ")
				,wwPrSDa21lUh(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡓࡕࡋࡎࡖࡔࡏࡣࡍ࡚ࡔࡑࡕࡓࡖࡔ࡞ࡉࡆࡕ࠰࠵ࡸࡺࠧಈ")
				,e2qDYgipPmTw4KvBLnochr(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤ࡝ࡅࡃࡒࡕࡓ࡝ࡏࡅࡔ࠯࠴ࡷࡹ࠭ಉ")
				,LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡕࡐࡆࡐࡘࡖࡑࡥࡗࡆࡄࡓࡖࡔ࡞ࡉࡆࡕ࠰࠶ࡳࡪࠧಊ")
				,jeAby54c02TgG8zuivonX91(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡘࡇࡅࡔࡗࡕࡘ࡚ࡖࡒ࠱࠶ࡹࡴࠨಋ")
				,GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠ࡙ࡈࡆࡕࡘࡏ࡙࡛ࡗࡓ࠲࠸࡮ࡥࠩಌ")
				,mkHKSQvjWr5BTcM3wVY(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡑࡓࡉࡓ࡛ࡒࡍࡡࡎࡔࡗࡕࡘ࡚ࡅࡒࡑ࠲࠷ࡳࡵࠩ಍")
				,o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢࡏࡕࡘࡏ࡙࡛ࡆࡓࡒ࠳࠲࡯ࡦࠪಎ")
				,HHoGx7Flus60(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡓࡕࡋࡎࡖࡔࡏࡣࡐࡖࡒࡐ࡚࡜ࡇࡔࡓ࠭࠴ࡴࡧࠫಏ")
				,JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡈࡎࡅࡄࡍࡢࡌ࡙࡚ࡐࡔࡡࡓࡖࡔ࡞ࡉࡆࡕ࠰࠵ࡸࡺࠧಐ")
				,FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠳ࡈࡕࡖࡓࡗࡤ࡚ࡅࡔࡖ࠰࠵ࡸࡺࠧ಑")
				,GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙࠭ࡕࡇࡖࡘࡤࡇࡌࡍࡡ࡚ࡉࡇ࡙ࡉࡕࡇࡖ࠱࠶ࡹࡴࠨಒ")
				,e2qDYgipPmTw4KvBLnochr(u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓ࠮ࡖࡈࡗ࡙ࡥࡁࡍࡎࡢ࡛ࡊࡈࡓࡊࡖࡈࡗ࠲࠸࡮ࡥࠩಓ")
				,zyvJMtBhrw(u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࡘࡗࡆࡍࡅࡠࡔࡈࡔࡔࡘࡔ࠮࠳ࡶࡸࠬಔ")
				,LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡓࡔࡍࡌࡆࡡࡗࡖࡆࡔࡓࡍࡃࡗࡉ࠲࠷ࡳࡵࠩಕ")
				,KBkxSYaz93pu1(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡖࡊ࡜ࡅࡓࡕࡒࡣ࡙ࡘࡁࡏࡕࡏࡅ࡙ࡋ࠭࠲ࡵࡷࠫಖ")
				]
vIDJ3z8NTlStsfnW4MOQC20Bo = [rwQN9AKhLCuMfHxjlbX0U(u"ࠪ࠼࠳࠾࠮࠹࠰࠻ࠫಗ"),rwQN9AKhLCuMfHxjlbX0U(u"ࠫ࠶࠴࠱࠯࠳࠱࠵ࠬಘ"),gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠬ࠷࠮࠱࠰࠳࠲࠶࠭ಙ"),OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"࠭࠸࠯࠺࠱࠸࠳࠺ࠧಚ"),KBkxSYaz93pu1(u"ࠧ࠳࠲࠻࠲࠻࠽࠮࠳࠴࠵࠲࠷࠸࠲ࠨಛ"),OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠨ࠴࠳࠼࠳࠼࠷࠯࠴࠵࠴࠳࠸࠲࠱ࠩಜ")]
u6rbxnyjTl7I = {
			 hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠩࡄࡌ࡜ࡇࡋࠨಝ")		:[zyvJMtBhrw(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡹ࠮ࡢࡪࡺࡥࡰࡺࡶ࠯ࡰࡨࡸࠬಞ")]
			,QVDJLRlxNg127jMX(u"ࠫࡆࡑࡏࡂࡏࠪಟ")		:[ITvnUAMXsyb4eO(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡ࡬࠰ࡶࡺ࠴ࡵ࡬ࡥࠩಠ")]
			,QvgnCALNstmuUJiET(u"࠭ࡁࡌ࡙ࡄࡑࠬಡ")		:[jeAby54c02TgG8zuivonX91(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣ࡮࠲ࡸࡼࠧಢ")]
			,QvgnCALNstmuUJiET(u"ࠨࡃࡎ࡛ࡆࡓࡔࡖࡄࡈࠫಣ")	:[NeO3CTLHrPfWUoIgy8Q(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡭࠳ࡧ࡫ࡸࡣࡰ࠲ࡹࡻࡢࡦࠩತ")]
			,FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠪࡅࡑࡓࡁࡂࡔࡈࡊࠬಥ")		:[rwQN9AKhLCuMfHxjlbX0U(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧ࡬࡮ࡣࡤࡶࡪ࡬࠮ࡤࡪࠪದ")]
			,GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠬࡇࡌࡎࡕࡗࡆࡆ࠭ಧ")		:[o1u5dij9UrcbXzVS8lwIWfKpnqM(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡷࡱࡧ࠲ࡦࡲ࡭ࡴࡶࡥࡥ࠳ࡺࡶࠨನ")]
			,o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠧࡂࡐࡌࡑࡊࡠࡉࡅࠩ಩")		:[NeO3CTLHrPfWUoIgy8Q(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡲ࡮ࡳࡥࡻ࡫ࡧ࠲ࡸ࡮࡯ࡸࠩಪ")]
			,xcChIL13BpR8WArNt9Pl0So(u"ࠩࡄࡖࡆࡈࡉࡄࡖࡒࡓࡓ࡙ࠧಫ")	:[NeO3CTLHrPfWUoIgy8Q(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡻࡼࡽ࠮ࡢࡴࡤࡦ࡮ࡩ࠭ࡵࡱࡲࡲࡸ࠴ࡣࡰ࡯ࠪಬ")]
			,FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠫࡆࡘࡁࡃࡕࡈࡉࡉ࠭ಭ")		:[S1SgCFYGJeMvfp5iZXK(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡࡳࡣࡥࡷࡪ࡫ࡤ࠯ࡰࡨࡸࠬಮ")]
			,KBkxSYaz93pu1(u"࠭ࡁ࡚ࡎࡒࡐࠬಯ")		:[hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡨ࠲ࡦࡿ࡬ࡰ࡮࠱ࡲࡪࡺࠧರ")]
			,FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠨࡄࡒࡏࡗࡇࠧಱ")		:[rwQN9AKhLCuMfHxjlbX0U(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡶ࡬ࡴࡵࡦࡷࡱࡧ࠲ࡨࡵ࡭ࠨಲ")]
			,FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠪࡆࡗ࡙ࡔࡆࡌࠪಳ")		:[zyvJMtBhrw(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡨࡲࡴࡶࡨ࡮࠳ࡩ࡯࡮ࠩ಴")]
			,JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠬࡉࡉࡎࡃ࠷࠴࠵࠭ವ")		:[KBkxSYaz93pu1(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡤ࡫ࡰࡥ࠹࠶࠰࠯ࡥࡲࡱࠬಶ")]
			,OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠧࡄࡋࡐࡅ࠹ࡖࠧಷ")		:[wwPrSDa21lUh(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡶ࠲ࡨ࡯࡭ࡢ࠶ࡳ࠲ࡨࡵ࡭ࠨಸ")]
			,KBkxSYaz93pu1(u"ࠩࡆࡍࡒࡇ࠴ࡖࠩಹ")		:[jeAby54c02TgG8zuivonX91(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࠶ࡩࡩ࡮ࡣ࠷ࡹ࠳ࡩ࡯࡮ࠩ಺")]
			,EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠫࡈࡏࡍࡂࡃࡅࡈࡔ࠭಻")		:[XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡣࡪ࡯ࡤ࠷ࡧࡪ࡯࠯ࡥࡲࡱ಼ࠬ")]
			,EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡂࠨಽ")		:[S1SgCFYGJeMvfp5iZXK(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡥ࡬ࡱࡦࡩ࡬ࡶࡤ࠱ࡻࡦࡺࡣࡩࠩಾ")]
			,KNIvHPjUbhr(u"ࠨࡅࡌࡑࡆࡉࡌࡖࡄ࡚ࡓࡗࡑࠧಿ")	:[DJ1ICpbyR2(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡸࡻࡼ࠮ࡤ࡫ࡰࡥࡨࡲࡵࡣ࠰ࡶ࡬ࡴࡶࠧೀ")]
			,EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠪࡇࡎࡓࡁࡇࡃࡑࡗࠬು")		:[DJ1ICpbyR2(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡦ࡭ࡲࡧࡦࡢࡰࡶ࠲ࡨࡵ࡭ࠨೂ")]
			,FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠬࡉࡉࡎࡃࡉࡖࡊࡋࠧೃ")		:[MMizeNH0AKu(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡤ࡫ࡰࡥ࡫ࡸࡥࡦ࠰ࡹ࡭ࡵ࠭ೄ")]
			,zyvJMtBhrw(u"ࠧࡄࡋࡐࡅࡑࡏࡇࡉࡖࠪ೅")	:[e2qDYgipPmTw4KvBLnochr(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺ࠶࠼࠴࡭ࡺ࠯ࡦ࡭ࡲࡧ࠮࡯ࡧࡷ࠳ࡲࡿࡣ࠲ࠩೆ")]
			,EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠩࡆࡍࡒࡇࡎࡐ࡙ࠪೇ")		:[GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡨ࡯࡭ࡢࡰࡲࡻ࠳ࡩࡣࠨೈ")]
			,gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠫࡈࡏࡍࡂ࡙ࡅࡅࡘ࠭೉")		:[OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡣࡪ࡯ࡤࡻࡧࡧࡳ࠯࡯ࡼࡧ࡮ࡳࡡ࠯ࡥࡦࠫೊ")]
			,mkHKSQvjWr5BTcM3wVY(u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑࠫೋ")	:[hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰ࠱ࡧࡴࡳࠧೌ"),rwQN9AKhLCuMfHxjlbX0U(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡪࡶࡦࡶࡨࡲ࡮࠱ࡥࡵ࡯࠮ࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲ࠳ࡩ࡯࡮್ࠩ")]
			,sULh4NjakzI8He7xJCMGrql(u"ࠩࡇࡖࡆࡓࡁࡄࡃࡉࡉࠬ೎")	:[GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼ࠸࠵࠯ࡦࡵࡥࡲࡧࡣࡢࡨࡨ࠱ࡹࡼ࠮ࡤࡱࡰࠫ೏")]
			,hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠫࡉࡘࡁࡎࡃࡖ࠻ࠬ೐")		:[ITvnUAMXsyb4eO(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡࡤ࠰ࡧࡶࡦࡳࡡࡴ࠹࠱ࡧࡴࡳࠧ೑")]
			,XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠱ࠨ೒")		:[wwPrSDa21lUh(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡪࡽࡧ࡫ࡳࡵ࠰ࡩࡹࡳ࠭೓")]
			,sULh4NjakzI8He7xJCMGrql(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠴ࠪ೔")		:[ITvnUAMXsyb4eO(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩ࡬ࡿࡢࡦࡵࡷ࠲ࡼ࡫ࡢࡤࡣࡰࠫೕ")]
			,HHoGx7Flus60(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠷ࠬೖ")		:[jeAby54c02TgG8zuivonX91(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡯ࡥࡨࡻࡥࡩࡸࡺ࠮ࡣ࡫ࡧࠫ೗")]
			,GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠺ࠧ೘")		:[FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦࡩࡼ࠱ࡧ࡫ࡳࡵ࠰ࡱࡩࡹ࠭೙")]
			,S1SgCFYGJeMvfp5iZXK(u"ࠧࡆࡉ࡜ࡈࡊࡇࡄࠨ೚")		:[dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨ࡫ࡾࡪࡥࡢࡦ࠱ࡰ࡮ࡼࡥࠨ೛")]
			,JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠩࡈࡐࡈࡏࡎࡆࡏࡄࠫ೜")		:[FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪࡲࡣࡪࡰࡨࡱࡦ࠴ࡣࡰ࡯ࠪೝ")]
			,ITvnUAMXsyb4eO(u"ࠫࡊࡒࡉࡇࡘࡌࡈࡊࡕࠧೞ")	:[hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡩࡣ࡫࡭ࡩ࠴ࡥ࡭࡫ࡩ࠲ࡳ࡫ࡷࡴࠩ೟")]
			,HHoGx7Flus60(u"࠭ࡆࡂࡄࡕࡅࡐࡇࠧೠ")		:[CnbBKmtF1x84q7AW(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡨࡤࡦࡷࡱࡡ࠯ࡥࡲࡱࠬೡ")]
			,QvgnCALNstmuUJiET(u"ࠨࡈࡄࡎࡊࡘࡓࡉࡑ࡚ࠫೢ")	:[mkHKSQvjWr5BTcM3wVY(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡪࡦࡰࡥࡳ࠰ࡶ࡬ࡴࡽࠧೣ")]
			,EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠪࡊࡆࡘࡅࡔࡍࡒࠫ೤")		:[FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡼࡩࡱ࠰ࡩࡥࡷ࡫ࡳ࡬ࡱ࠱ࡲࡪࡺࠧ೥")]
			,EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠬࡌࡁࡔࡇࡏࡌࡉ࠸ࠧ೦")		:[wwPrSDa21lUh(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡵ࡯ࡥ࠳࡬ࡡࡴࡧ࡯࡬ࡩ࠴ࡣ࡭ࡱࡸࡨࠬ೧")]
			,HHoGx7Flus60(u"ࠧࡇࡑࡖࡘࡆ࠭೨")		:[MMizeNH0AKu(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻ࡯࠴ࡦࡰࡵࡷࡥ࠲ࡺࡶ࠯ࡰࡨࡸࠬ೩")]
			,MMizeNH0AKu(u"ࠩࡉ࡙ࡓࡕࡎࡕࡘࠪ೪")		:[XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡬࠴ࡡ࡭࡯ࡨࡷ࡭ࡱࡡࡩ࠰ࡱࡩࡹ࠭೫")]
			,A6dMB1FlgxVivJ2fk9C(u"ࠫࡋ࡛ࡓࡉࡃࡕࡘ࡛࠭೬")		:[EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡢ࠯ࡨࡸࡷ࡭ࡧࡲ࠮ࡶࡹ࠲ࡨࡵ࡭ࠨ೭")]
			,LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"࠭ࡆࡖࡕࡋࡅࡗ࡜ࡉࡅࡇࡒࠫ೮")	:[CnbBKmtF1x84q7AW(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡵ࠱ࡪࡺࡹࡨࡢࡴ࠱ࡺ࡮ࡪࡥࡰࠩ೯")]
			,JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠨࡊࡄࡐࡆࡉࡉࡎࡃࠪ೰")		:[xcChIL13BpR8WArNt9Pl0So(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡬ࡦࡲࡡࡤ࡫ࡰࡥ࠳ࡳࡥࡥ࡫ࡤࠫೱ")]
			,XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠪࡍࡋࡏࡌࡎࠩೲ")		:[o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡲ࠯࡫ࡩ࡭ࡱࡳࡴࡷ࠰࡬ࡶࠬೳ"),SqrG5mU3j96ldsFpExobw40TJY(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥ࡯࠰࡬ࡪ࡮ࡲ࡭ࡵࡸ࠱࡭ࡷ࠭೴"),sULh4NjakzI8He7xJCMGrql(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡧࡣ࠱࡭࡫࡯࡬࡮ࡶࡹ࠲࡮ࡸࠧ೵"),sULh4NjakzI8He7xJCMGrql(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡨࡤ࠶࠳࡯ࡦࡪ࡮ࡰࡸࡻ࠴ࡩࡳࠩ೶"),dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠻࠶࠲࠶࠿࠰࠯࠴࠷࠲࠶࠸࠲ࠨ೷")]
			,jeAby54c02TgG8zuivonX91(u"ࠩࡎࡅࡗࡈࡁࡍࡃࡗ࡚ࠬ೸")	:[wwPrSDa21lUh(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡧࡲࡣࡣ࡯ࡥ࠲ࡺࡶ࠯࡫ࡴࠫ೹")]
			,XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠫࡐࡇࡔࡌࡑࡗࡘ࡛࠭೺")		:[CnbBKmtF1x84q7AW(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡧࡰࡱ࠱࡯࡮ࡺ࡫ࡰࡶ࠱ࡸࡻ࠭೻")]
			,QVDJLRlxNg127jMX(u"࠭ࡋࡊࡔࡐࡅࡑࡑࠧ೼")		:[MMizeNH0AKu(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡸ࠲ࡰ࡯ࡲ࡮ࡣ࡯࡯࠳ࡩ࡯࡮ࠩ೽")]
			,S1SgCFYGJeMvfp5iZXK(u"ࠨࡍࡒࡈࡎࡋࡍࡂࡆࡢࡅࡕࡖࠧ೾")	:[o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡸ࡮ࡴࡹ࠯ࡥࡦ࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠭೿"),MMizeNH0AKu(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴ࠴࠳࠵࠽࠴ࡦࡸࡵ࠱ࡷࡹࡵࡲࡦࠩഀ")]
			,NeO3CTLHrPfWUoIgy8Q(u"ࠫࡑࡇࡒࡐ࡜ࡄࠫഁ")		:[e2qDYgipPmTw4KvBLnochr(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡬ࡢࡴࡲࡾࡦ࠴ࡩ࡯ࡨࡲࠫം")]
			,QvgnCALNstmuUJiET(u"࠭ࡌࡐࡆ࡜ࡒࡊ࡚ࠧഃ")		:[dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡮ࡲࡨࡾࡴࡥࡵ࠰࡯࡭ࡳࡱࠧഄ")]
			,LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠨࡏࡄࡗࡆ࡜ࡉࡅࡇࡒࠫഅ")	:[EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮࡮ࡣࡶࡥࡻ࡯ࡤࡦࡱ࠱ࡲࡪࡽࡳࠨആ")]
			,e2qDYgipPmTw4KvBLnochr(u"ࠪࡔࡆࡔࡅࡕࠩഇ")		:[KNIvHPjUbhr(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡲࡤࡲࡪࡺ࠮ࡤࡱ࠱࡭ࡱ࠭ഈ")]
			,jeAby54c02TgG8zuivonX91(u"ࠬࡘࡅࡍࡇࡄࡗࡊ࡙ࠧഉ")		:[ITvnUAMXsyb4eO(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡶࡹࡷ࡭ࡥ࠯ࡵ࡫࠳ࡰࡵࡤࡪ࠱ࡨࡱࡦࡪ࡟ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠵࡯࡭ࡦ࠲࡭ࡳࡪࡥࡹ࠰࡫ࡸࡲࡲࠧഊ")]
			,A6dMB1FlgxVivJ2fk9C(u"ࠧࡔࡇࡕࡍࡊ࡙ࡔࡊࡏࡈࠫഋ")	:[XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡥࡥ࠳ࡹࡥࡳ࡫ࡨࡷࡹ࡯࡭ࡦ࠰ࡦࡥࡲ࠭ഌ")]
			,HHoGx7Flus60(u"ࠩࡖࡌࡆࡈࡁࡌࡃࡗ࡝ࠬ഍")	:[xcChIL13BpR8WArNt9Pl0So(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦ࠴ࡓࡉࡃࡅࡅࡐࡇࡔ࡚࠰ࡹ࡭ࡵ࠭എ")]
			,jeAby54c02TgG8zuivonX91(u"ࠫࡘࡎࡁࡉࡋࡇ࠸࡚࠭ഏ")		:[OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡩࡧࡧ࠸ࡺ࠸࠮ࡤࡱࡰࠫഐ")]
			,NeO3CTLHrPfWUoIgy8Q(u"࠭ࡓࡉࡃࡋࡍࡉࡔࡅࡘࡕࠪ഑")	:[dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧ࠱ࡷ࡭࠺ࡵ࠯ࡰࡨࡻࡸ࠭ഒ")]
			,sULh4NjakzI8He7xJCMGrql(u"ࠨࡕࡋࡓࡋࡎࡁࠨഓ")		:[XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡴࡪࡲࡪ࡭ࡧ࠮ࡵࡸࠪഔ")]
			,hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠪࡗࡍࡕࡏࡇࡏࡄ࡜ࠬക")		:[S1SgCFYGJeMvfp5iZXK(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹࡨࡰࡱࡩࡱࡦࡾ࠮ࡤࡱࡰࠫഖ"),ITvnUAMXsyb4eO(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡵࡣࡷ࡭ࡨ࠴ࡳࡩࡱࡲࡪࡲࡧࡸ࠯ࡥࡲࡱࠬഗ"),e2qDYgipPmTw4KvBLnochr(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴࡪࡲࡳ࡫ࡳࡡࡹ࠰ࡤࡾࡺࡸࡥࡦࡦࡪࡩ࠳ࡴࡥࡵࠩഘ")]
			,jeAby54c02TgG8zuivonX91(u"ࠧࡔࡊࡒࡓࡋࡔࡅࡕࠩങ")		:[S1SgCFYGJeMvfp5iZXK(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡷ࠳ࡧ࡫ࡸࡣࡰ࠲ࡹࡻࡢࡦࠩച")]
			,QvgnCALNstmuUJiET(u"ࠩࡗࡍࡐࡇࡁࡕࠩഛ")		:[MMizeNH0AKu(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡶ࡬࡯ࡦࡧࡴ࠯ࡰࡨࡸࠬജ")]
			,HHoGx7Flus60(u"࡙ࠫ࡜ࡆࡖࡐࠪഝ")		:[HHoGx7Flus60(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳ࠯ࡶࡹࡪࡺࡴ࠮࡮ࡧࠪഞ")]
			,FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"࠭ࡖࡂࡔࡅࡓࡓ࠭ട")		:[mkHKSQvjWr5BTcM3wVY(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡯࠱ࡺࡦࡸࡢࡰࡰ࠱ࡧࡦࡳࠧഠ")]
			,MMizeNH0AKu(u"ࠨࡘࡌࡈࡊࡕࡎࡔࡃࡈࡑࠬഡ")	:[KBkxSYaz93pu1(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡺ࡮ࡪࡥࡰ࠰ࡱࡷࡦ࡫࡭࠯ࡰࡨࡸࠬഢ")]
			,KNIvHPjUbhr(u"࡛ࠪࡊࡉࡉࡎࡃ࠴ࠫണ")		:[wwPrSDa21lUh(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡥࡤ࡫ࡰࡥ࠳ࡹࡨࡰࡹࠪത")]
			,mkHKSQvjWr5BTcM3wVY(u"ࠬ࡝ࡅࡄࡋࡐࡅ࠷࠭ഥ")		:[hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡧࡦ࡭ࡲࡧ࠮ࡤ࡮࡬ࡧࡰ࠭ദ")]
			,o1u5dij9UrcbXzVS8lwIWfKpnqM(u"࡚ࠧࡃࡔࡓ࡙࠭ധ")		:[hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡼ࠲ࡾࡧࡱࡰࡶ࠱ࡸࡻ࠭ന")]
			,GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪഩ")		:[JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡦࡳࡲ࠭പ")]
			,LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠫࡗࡋࡐࡐࡕࠪഫ")		:[gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡰࡨࡸࡱ࡯ࡦࡺ࠰ࡤࡴࡵ࠵ࡋࡐࡆࡌࡖࡊࡖࡏ࠰ࡃࡇࡈࡔࡔࡓ࠰ࡣࡧࡨࡴࡴࡳ࠯ࡺࡰࡰࠬബ"),gDuGMR3z1aV6YdLmCpiO8Kl(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡱࡩࡹࡲࡩࡧࡻ࠱ࡥࡵࡶ࠯ࡌࡑࡇࡍࡗࡋࡐࡐ࠱ࡄࡈࡉࡕࡎࡔ࠳࠻࠳ࡦࡪࡤࡰࡰࡶ࠵࠽࠴ࡸ࡮࡮ࠪഭ"),QvgnCALNstmuUJiET(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡲࡪࡺ࡬ࡪࡨࡼ࠲ࡦࡶࡰ࠰ࡍࡒࡈࡎࡘࡅࡑࡑ࠲ࡅࡉࡊࡏࡏࡕ࠴࠽࠴ࡧࡤࡥࡱࡱࡷ࠶࠿࠮ࡹ࡯࡯ࠫമ")]
			,QvgnCALNstmuUJiET(u"ࠨࡔࡈࡔࡔ࡙࡟ࡃࡍࡓࠫയ")	:[OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡲࡦࡲࡲ࠲ࡺࡱ࠮ࡵࡱ࠲ࡅࡉࡊࡏࡏࡕ࠲ࡥࡩࡪ࡯࡯ࡵ࠱ࡼࡲࡲࠧര"),ITvnUAMXsyb4eO(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡳࡧࡳࡳ࠳ࡻ࡫࠯ࡶࡲ࠳ࡆࡊࡄࡐࡐࡖ࠵࠽࠵ࡡࡥࡦࡲࡲࡸ࠷࠸࠯ࡺࡰࡰࠬറ"),MMizeNH0AKu(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡴࡨࡴࡴ࠴ࡵ࡬࠰ࡷࡳ࠴ࡇࡄࡅࡑࡑࡗ࠶࠿࠯ࡢࡦࡧࡳࡳࡹ࠱࠺࠰ࡻࡱࡱ࠭ല")]
			,mkHKSQvjWr5BTcM3wVY(u"࡙ࠬࡏࡖࡔࡆࡉࡘ࠭ള")		:[SqrG5mU3j96ldsFpExobw40TJY(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠱ࡴࡾࡺࡨࡰࡰࡤࡲࡾࡽࡨࡦࡴࡨ࠲ࡨࡵ࡭࠰࡭ࡲࡨ࡮࠭ഴ"),NeO3CTLHrPfWUoIgy8Q(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡷࡺࡸࡧࡦ࠰ࡶ࡬ࠬവ"),S1SgCFYGJeMvfp5iZXK(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡳ࡫ࡴ࡭࡫ࡩࡽ࠳ࡧࡰࡱ࠱ࡎࡓࡉࡏࡒࡆࡒࡒࠫശ")]
			}
if bXukYxQ4aHw:
	u6rbxnyjTl7I[gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠩࡓ࡝࡙ࡎࡏࡏࠩഷ")] = [CnbBKmtF1x84q7AW(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲ࡰ࡮ࡹࡴࡱ࡮ࡤࡽࠬസ"),mkHKSQvjWr5BTcM3wVY(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡷࡧࡵࡧࡪࡲ࠮ࡢࡲࡳ࠳ࡺࡹࡡࡨࡧࡵࡩࡵࡵࡲࡵࠩഹ"),S1SgCFYGJeMvfp5iZXK(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡸࡨࡶࡨ࡫࡬࠯ࡣࡳࡴ࠴ࡹࡥ࡯ࡦࡨࡱࡦ࡯࡬ࠨഺ"),e2qDYgipPmTw4KvBLnochr(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵ࡧࡦࡶࡰࡩࡸࡹࡡࡨࡧࡶ഻ࠫ"),LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡺࡪࡸࡣࡦ࡮࠱ࡥࡵࡶ࠯ࡨࡧࡷ࡭ࡸࡲࡡ࡮࡫ࡦ഼ࠫ"),CnbBKmtF1x84q7AW(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡻ࡫ࡲࡤࡧ࡯࠲ࡦࡶࡰ࠰ࡩࡨࡸࡶࡻࡥࡴࡶ࡬ࡳࡳࡹࠧഽ"),jeAby54c02TgG8zuivonX91(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡼࡥࡳࡥࡨࡰ࠳ࡧࡰࡱ࠱ࡪࡩࡹࡱ࡮ࡰࡹࡱࡩࡷࡸ࡯ࡳࡵࠪാ"),FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲ࡧࡦࡶࡴࡤࡪࡤࠫി"),LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡷࡧࡵࡧࡪࡲ࠮ࡢࡲࡳ࠳ࡹ࡫ࡳࡵ࡫ࡱ࡫ࠬീ"),mkHKSQvjWr5BTcM3wVY(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡸࡨࡶࡨ࡫࡬࠯ࡣࡳࡴ࠴࡭ࡥࡵࡧࡻࡸࡷࡧࡰࡺࡶ࡫ࡳࡳࡩ࡯ࡥࡧࠪു")]
	u6rbxnyjTl7I[gDuGMR3z1aV6YdLmCpiO8Kl(u"࠭ࡐ࡚ࡖࡋࡓࡓࡥࡂࡌࡒࠪൂ")] = [mkHKSQvjWr5BTcM3wVY(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡸ࡯࠳ࡺ࡯࠰࡮࡬ࡷࡹࡶ࡬ࡢࡻࠪൃ"),gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡹࡰ࠴ࡴࡰ࠱ࡸࡷࡦ࡭ࡥࡳࡧࡳࡳࡷࡺࠧൄ"),EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡺࡱ࠮ࡵࡱ࠲ࡷࡪࡴࡤࡦ࡯ࡤ࡭ࡱ࠭൅"),KBkxSYaz93pu1(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡻ࡫࠯ࡶࡲ࠳࡬࡫ࡴ࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩെ"),LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡵ࡬࠰ࡷࡳ࠴࡭ࡥࡵ࡫ࡶࡰࡦࡳࡩࡤࠩേ"),MMizeNH0AKu(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡶ࡭࠱ࡸࡴ࠵ࡧࡦࡶࡴࡹࡪࡹࡴࡪࡱࡱࡷࠬൈ"),GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡷ࡮࠲ࡹࡵ࠯ࡨࡧࡷ࡯ࡳࡵࡷ࡯ࡧࡵࡶࡴࡸࡳࠨ൉"),KNIvHPjUbhr(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡸ࡯࠳ࡺ࡯࠰ࡥࡤࡴࡹࡩࡨࡢࠩൊ"),QvgnCALNstmuUJiET(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡹࡰ࠴ࡴࡰ࠱ࡷࡩࡸࡺࡩ࡯ࡩࠪോ"),NeO3CTLHrPfWUoIgy8Q(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡺࡱ࠮ࡵࡱ࠲࡫ࡪࡺࡥࡹࡶࡵࡥࡵࡿࡴࡩࡱࡱࡧࡴࡪࡥࠨൌ")]
else:
	u6rbxnyjTl7I[LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠪࡔ࡞࡚ࡈࡐࡐ്ࠪ")] = [sULh4NjakzI8He7xJCMGrql(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡲࡩࡴࡶࡳࡰࡦࡿࠧൎ"),LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡵࡴࡣࡪࡩࡷ࡫ࡰࡰࡴࡷࠫ൏"),CnbBKmtF1x84q7AW(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡴࡧࡱࡨࡪࡳࡡࡪ࡮ࠪ൐"),EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸࡲ࡫ࡳࡴࡣࡪࡩࡸ࠭൑"),XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹ࡯ࡳ࡭ࡣࡰ࡭ࡨ࠭൒"),JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺࡱࡶࡧࡶࡸ࡮ࡵ࡮ࡴࠩ൓"),ITvnUAMXsyb4eO(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴ࡬ࡰࡲࡻࡳ࡫ࡲࡳࡱࡵࡷࠬൔ"),QVDJLRlxNg127jMX(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡩࡡࡱࡶࡦ࡬ࡦ࠭ൕ"),ITvnUAMXsyb4eO(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡴࡦࡵࡷ࡭ࡳ࡭ࠧൖ"),LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷࡩࡽࡺࡲࡢࡲࡼࡸ࡭ࡵ࡮ࡤࡱࡧࡩࠬൗ")]
	u6rbxnyjTl7I[sULh4NjakzI8He7xJCMGrql(u"ࠧࡑ࡛ࡗࡌࡔࡔ࡟ࡃࡍࡓࠫ൘")] = [NeO3CTLHrPfWUoIgy8Q(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱࡯࡭ࡸࡺࡰ࡭ࡣࡼࠫ൙"),LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡹࡸࡧࡧࡦࡴࡨࡴࡴࡸࡴࠨ൚"),LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡸ࡫࡮ࡥࡧࡰࡥ࡮ࡲࠧ൛"),KNIvHPjUbhr(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵ࡯ࡨࡷࡸࡧࡧࡦࡵࠪ൜"),hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶ࡬ࡷࡱࡧ࡭ࡪࡥࠪ൝"),jeAby54c02TgG8zuivonX91(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ࠭൞"),LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸࡰࡴ࡯ࡸࡰࡨࡶࡷࡵࡲࡴࠩൟ"),mkHKSQvjWr5BTcM3wVY(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡦࡥࡵࡺࡣࡩࡣࠪൠ"),gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡸࡪࡹࡴࡪࡰࡪࠫൡ"),SqrG5mU3j96ldsFpExobw40TJY(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴࡦࡺࡷࡶࡦࡶࡹࡵࡪࡲࡲࡨࡵࡤࡦࠩൢ")]
JaefAXmLzMRSjqVhTi0rQPb17IB8U = [mkHKSQvjWr5BTcM3wVY(u"ࠫࡑࡏࡓࡕࡒࡏࡅ࡞࠭ൣ"),dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠬࡘࡅࡑࡑࡕࡘࡘ࠭൤"),DJ1ICpbyR2(u"࠭ࡅࡎࡃࡌࡐࡘ࠭൥"),zyvJMtBhrw(u"ࠧࡎࡇࡖࡗࡆࡍࡅࡔࠩ൦"),DJ1ICpbyR2(u"ࠨࡋࡖࡐࡆࡓࡉࡄࡕࠪ൧"),XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠩࡔ࡙ࡊ࡙ࡔࡊࡑࡑࡗࠬ൨"),DJ1ICpbyR2(u"ࠪࡏࡓࡕࡗࡏࡇࡕࡖࡔࡘࡓࠨ൩"),QvgnCALNstmuUJiET(u"ࠫࡈࡇࡐࡕࡅࡋࡅࠬ൪"),S1SgCFYGJeMvfp5iZXK(u"࡚ࠬࡅࡔࡖࡌࡒࡌ࠭൫"),rwQN9AKhLCuMfHxjlbX0U(u"࠭ࡅ࡙ࡖࡕࡅࡕ࡟ࡔࡉࡑࡑࡇࡔࡊࡅࠨ൬")]
wb7ZkKqsRIfjgNdBtu3T8HvCiX = [A6dMB1FlgxVivJ2fk9C(u"ࠧࡂࡆࡇࡓࡓ࡙ࠧ൭"),NeO3CTLHrPfWUoIgy8Q(u"ࠨࡃࡇࡈࡔࡔࡓ࠲࠺ࠪ൮"),OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠩࡄࡈࡉࡕࡎࡔ࠳࠼ࠫ൯")]
class z1HcSxJQi6Tak(LReTm9MyqCHKFIZtv8WYD):
	def __init__(zEcNagLnXdmhIwkOAs628J,*aargs,**kkwargs):
		zEcNagLnXdmhIwkOAs628J.choiceID = -bXukYxQ4aHw
	def onClick(zEcNagLnXdmhIwkOAs628J,UULPZ6dgwQ):
		if UULPZ6dgwQ>=sULh4NjakzI8He7xJCMGrql(u"࠹࠱࠳࠳ፕ"): zEcNagLnXdmhIwkOAs628J.choiceID = UULPZ6dgwQ-sULh4NjakzI8He7xJCMGrql(u"࠹࠱࠳࠳ፕ")
		zEcNagLnXdmhIwkOAs628J.DFw16vKa0u2NxHpXkeMLO9JmI7lVW()
	def Ruz8pSYFVEt(zEcNagLnXdmhIwkOAs628J,*aargs):
		zEcNagLnXdmhIwkOAs628J.button0,zEcNagLnXdmhIwkOAs628J.button1,zEcNagLnXdmhIwkOAs628J.button2 = aargs[ybdv7XcT3lxF6QezULwCAGk],aargs[bXukYxQ4aHw],aargs[Y0XZKGRAUQj5O]
		zEcNagLnXdmhIwkOAs628J.header,zEcNagLnXdmhIwkOAs628J.text = aargs[x1x9kIQo3zjZWnYaiy],aargs[jR6BYWNFZ0egmH4Tr2Q78LbSs3t]
		zEcNagLnXdmhIwkOAs628J.profile,zEcNagLnXdmhIwkOAs628J.direction = aargs[MMizeNH0AKu(u"࠶ፖ")],aargs[A6dMB1FlgxVivJ2fk9C(u"࠸ፗ")]
		zEcNagLnXdmhIwkOAs628J.buttonstimeout,zEcNagLnXdmhIwkOAs628J.closetimeout = aargs[KBkxSYaz93pu1(u"࠻ፙ")],aargs[jeAby54c02TgG8zuivonX91(u"࠻ፘ")]
		if zEcNagLnXdmhIwkOAs628J.buttonstimeout>ybdv7XcT3lxF6QezULwCAGk or zEcNagLnXdmhIwkOAs628J.closetimeout>EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"࠵ፚ"): zEcNagLnXdmhIwkOAs628J.enable_progressbar = VBlawK4mgHSyLEn8iqhUkz5
		else: zEcNagLnXdmhIwkOAs628J.enable_progressbar = fEXMiAyG3ql4vKB
		zEcNagLnXdmhIwkOAs628J.image_filename = UUszEDWjBZTu3rOSF4v1.replace(JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠪࡣ࠵࠶࠰࠱ࡡࠪ൰"),hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠫࡤ࠭൱")+str(HB5PvxRhwM.time())+FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠬࡥࠧ൲"))
		zEcNagLnXdmhIwkOAs628J.image_filename = zEcNagLnXdmhIwkOAs628J.image_filename.replace(mkHKSQvjWr5BTcM3wVY(u"࠭࡜࡝ࠩ൳"),xcChIL13BpR8WArNt9Pl0So(u"ࠧ࡝࡞࡟ࡠࠬ൴")).replace(CnbBKmtF1x84q7AW(u"ࠨ࠱࠲ࠫ൵"),LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠩ࠲࠳࠴࠵ࠧ൶"))
		zEcNagLnXdmhIwkOAs628J.image_height = u4HdnJLfyrebDC3Rj8tzkT0VhmQp(zEcNagLnXdmhIwkOAs628J.button0,zEcNagLnXdmhIwkOAs628J.button1,zEcNagLnXdmhIwkOAs628J.button2,zEcNagLnXdmhIwkOAs628J.header,zEcNagLnXdmhIwkOAs628J.text,zEcNagLnXdmhIwkOAs628J.profile,zEcNagLnXdmhIwkOAs628J.direction,zEcNagLnXdmhIwkOAs628J.enable_progressbar,zEcNagLnXdmhIwkOAs628J.image_filename)
		zEcNagLnXdmhIwkOAs628J.show()
		zEcNagLnXdmhIwkOAs628J.getControl(EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"࠿࠰࠶࠲፛")).setImage(zEcNagLnXdmhIwkOAs628J.image_filename)
		zEcNagLnXdmhIwkOAs628J.getControl(rwQN9AKhLCuMfHxjlbX0U(u"࠹࠱࠷࠳፜")).setHeight(zEcNagLnXdmhIwkOAs628J.image_height)
		if not zEcNagLnXdmhIwkOAs628J.button1 and zEcNagLnXdmhIwkOAs628J.button0 and zEcNagLnXdmhIwkOAs628J.button2: zEcNagLnXdmhIwkOAs628J.getControl(QvgnCALNstmuUJiET(u"࠻࠳࠵࠷፞")).setPosition(-GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"࠵࠶࠵፟"),LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"࠱፝"))
		return zEcNagLnXdmhIwkOAs628J.image_filename,zEcNagLnXdmhIwkOAs628J.image_height
	def RZnowUrJ0kfO9HeL3IGai(zEcNagLnXdmhIwkOAs628J):
		if zEcNagLnXdmhIwkOAs628J.buttonstimeout:
			zEcNagLnXdmhIwkOAs628J.th1 = KCTRe67wVy.Thread(target=zEcNagLnXdmhIwkOAs628J.pvUrxgECAtaV3Ik,args=())
			zEcNagLnXdmhIwkOAs628J.th1.start()
		else: zEcNagLnXdmhIwkOAs628J.anl20QKDE5iUeMf()
	def pvUrxgECAtaV3Ik(zEcNagLnXdmhIwkOAs628J):
		zEcNagLnXdmhIwkOAs628J.getControl(mkHKSQvjWr5BTcM3wVY(u"࠽࠵࠸࠰፠")).setEnabled(VBlawK4mgHSyLEn8iqhUkz5)
		for JpzD0lv9cYM6XrHeqCa in range(bXukYxQ4aHw,zEcNagLnXdmhIwkOAs628J.buttonstimeout+bXukYxQ4aHw):
			HB5PvxRhwM.sleep(bXukYxQ4aHw)
			TRMXEynwGcdOs4h = int(SqrG5mU3j96ldsFpExobw40TJY(u"࠶࠶࠰፡")*JpzD0lv9cYM6XrHeqCa/zEcNagLnXdmhIwkOAs628J.buttonstimeout)
			zEcNagLnXdmhIwkOAs628J.eeXkCasYwP3(TRMXEynwGcdOs4h)
			if zEcNagLnXdmhIwkOAs628J.choiceID>o1u5dij9UrcbXzVS8lwIWfKpnqM(u"࠶።"): break
		zEcNagLnXdmhIwkOAs628J.anl20QKDE5iUeMf()
	def SP8eLAK3y0o4RpGfE7H1j(zEcNagLnXdmhIwkOAs628J):
		if zEcNagLnXdmhIwkOAs628J.closetimeout:
			zEcNagLnXdmhIwkOAs628J.th2 = KCTRe67wVy.Thread(target=zEcNagLnXdmhIwkOAs628J.X1XkfgdSxLoFUN0rieTuJC6yph9,args=())
			zEcNagLnXdmhIwkOAs628J.th2.start()
		else: zEcNagLnXdmhIwkOAs628J.anl20QKDE5iUeMf()
	def X1XkfgdSxLoFUN0rieTuJC6yph9(zEcNagLnXdmhIwkOAs628J):
		zEcNagLnXdmhIwkOAs628J.getControl(jeAby54c02TgG8zuivonX91(u"࠹࠱࠴࠳፣")).setEnabled(VBlawK4mgHSyLEn8iqhUkz5)
		HB5PvxRhwM.sleep(zEcNagLnXdmhIwkOAs628J.buttonstimeout)
		for JpzD0lv9cYM6XrHeqCa in range(zEcNagLnXdmhIwkOAs628J.closetimeout-bXukYxQ4aHw,-bXukYxQ4aHw,-bXukYxQ4aHw):
			HB5PvxRhwM.sleep(bXukYxQ4aHw)
			TRMXEynwGcdOs4h = int(o1u5dij9UrcbXzVS8lwIWfKpnqM(u"࠲࠲࠳፤")*JpzD0lv9cYM6XrHeqCa/zEcNagLnXdmhIwkOAs628J.closetimeout)
			zEcNagLnXdmhIwkOAs628J.eeXkCasYwP3(TRMXEynwGcdOs4h)
			if zEcNagLnXdmhIwkOAs628J.choiceID>ybdv7XcT3lxF6QezULwCAGk: break
		if zEcNagLnXdmhIwkOAs628J.closetimeout>ybdv7XcT3lxF6QezULwCAGk: zEcNagLnXdmhIwkOAs628J.choiceID = e2qDYgipPmTw4KvBLnochr(u"࠳࠳፥")
		zEcNagLnXdmhIwkOAs628J.DFw16vKa0u2NxHpXkeMLO9JmI7lVW()
	def eeXkCasYwP3(zEcNagLnXdmhIwkOAs628J,TRMXEynwGcdOs4h):
		zEcNagLnXdmhIwkOAs628J.precent = TRMXEynwGcdOs4h
		zEcNagLnXdmhIwkOAs628J.getControl(QVDJLRlxNg127jMX(u"࠼࠴࠷࠶፦")).setPercent(zEcNagLnXdmhIwkOAs628J.precent)
	def anl20QKDE5iUeMf(zEcNagLnXdmhIwkOAs628J):
		if zEcNagLnXdmhIwkOAs628J.button0: zEcNagLnXdmhIwkOAs628J.getControl(A6dMB1FlgxVivJ2fk9C(u"࠽࠵࠷࠰፧")).setEnabled(VBlawK4mgHSyLEn8iqhUkz5)
		if zEcNagLnXdmhIwkOAs628J.button1: zEcNagLnXdmhIwkOAs628J.getControl(xcChIL13BpR8WArNt9Pl0So(u"࠾࠶࠱࠲፨")).setEnabled(VBlawK4mgHSyLEn8iqhUkz5)
		if zEcNagLnXdmhIwkOAs628J.button2: zEcNagLnXdmhIwkOAs628J.getControl(EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"࠿࠰࠲࠴፩")).setEnabled(VBlawK4mgHSyLEn8iqhUkz5)
	def DFw16vKa0u2NxHpXkeMLO9JmI7lVW(zEcNagLnXdmhIwkOAs628J):
		zEcNagLnXdmhIwkOAs628J.close()
		try: WQvYkNg7SysPFLitlGEn6.remove(zEcNagLnXdmhIwkOAs628J.image_filename)
		except: pass
class wfH5yxroNbj82s9iPp7QvuTn():
	def __init__(zEcNagLnXdmhIwkOAs628J,showDialogs=fEXMiAyG3ql4vKB,logErrors=VBlawK4mgHSyLEn8iqhUkz5):
		zEcNagLnXdmhIwkOAs628J.showDialogs = showDialogs
		zEcNagLnXdmhIwkOAs628J.logErrors = logErrors
		zEcNagLnXdmhIwkOAs628J.finishedLIST,zEcNagLnXdmhIwkOAs628J.failedLIST = [],[]
		zEcNagLnXdmhIwkOAs628J.statusDICT,zEcNagLnXdmhIwkOAs628J.resultsDICT = {},{}
		zEcNagLnXdmhIwkOAs628J.processesLIST = []
		zEcNagLnXdmhIwkOAs628J.starttimeDICT,zEcNagLnXdmhIwkOAs628J.finishtimeDICT,zEcNagLnXdmhIwkOAs628J.elpasedtimeDICT = {},{},{}
	def qSFtZyUrNnE(zEcNagLnXdmhIwkOAs628J,p1tmbSLQT0jfKloyc5gvCIauJz,hRcFeH8SnCvqt2pBLkfGEU,*aargs):
		p1tmbSLQT0jfKloyc5gvCIauJz = str(p1tmbSLQT0jfKloyc5gvCIauJz)
		zEcNagLnXdmhIwkOAs628J.statusDICT[p1tmbSLQT0jfKloyc5gvCIauJz] = S1SgCFYGJeMvfp5iZXK(u"ࠪࡶࡺࡴ࡮ࡪࡰࡪࠫ൷")
		if zEcNagLnXdmhIwkOAs628J.showDialogs: OnsAxhdVjZF(hWGMqtBy4wuLaVcj,p1tmbSLQT0jfKloyc5gvCIauJz)
		GtYBimvRdJc7P1L8XbgsAek = KCTRe67wVy.Thread(target=zEcNagLnXdmhIwkOAs628J.HHYVBco6wnvTfRNEF,args=(p1tmbSLQT0jfKloyc5gvCIauJz,hRcFeH8SnCvqt2pBLkfGEU,aargs))
		zEcNagLnXdmhIwkOAs628J.processesLIST.append(GtYBimvRdJc7P1L8XbgsAek)
		return GtYBimvRdJc7P1L8XbgsAek
	def GJfmn1Wyce6wo2(zEcNagLnXdmhIwkOAs628J,p1tmbSLQT0jfKloyc5gvCIauJz,hRcFeH8SnCvqt2pBLkfGEU,*aargs):
		GtYBimvRdJc7P1L8XbgsAek = zEcNagLnXdmhIwkOAs628J.qSFtZyUrNnE(p1tmbSLQT0jfKloyc5gvCIauJz,hRcFeH8SnCvqt2pBLkfGEU,*aargs)
		GtYBimvRdJc7P1L8XbgsAek.start()
	def HHYVBco6wnvTfRNEF(zEcNagLnXdmhIwkOAs628J,p1tmbSLQT0jfKloyc5gvCIauJz,hRcFeH8SnCvqt2pBLkfGEU,aargs):
		p1tmbSLQT0jfKloyc5gvCIauJz = str(p1tmbSLQT0jfKloyc5gvCIauJz)
		zEcNagLnXdmhIwkOAs628J.starttimeDICT[p1tmbSLQT0jfKloyc5gvCIauJz] = HB5PvxRhwM.time()
		try:
			zEcNagLnXdmhIwkOAs628J.resultsDICT[p1tmbSLQT0jfKloyc5gvCIauJz] = hRcFeH8SnCvqt2pBLkfGEU(*aargs)
			if LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠫࡔࡖࡅࡏࡗࡕࡐࠬ൸") in str(hRcFeH8SnCvqt2pBLkfGEU) and not zEcNagLnXdmhIwkOAs628J.resultsDICT[p1tmbSLQT0jfKloyc5gvCIauJz].succeeded: Za2Eugh8Mp1eQYH4()
			zEcNagLnXdmhIwkOAs628J.finishedLIST.append(p1tmbSLQT0jfKloyc5gvCIauJz)
			zEcNagLnXdmhIwkOAs628J.statusDICT[p1tmbSLQT0jfKloyc5gvCIauJz] = QVDJLRlxNg127jMX(u"ࠬ࡬ࡩ࡯࡫ࡶ࡬ࡪࡪࠧ൹")
		except Exception as HUpcs4WLhwzqV:
			if zEcNagLnXdmhIwkOAs628J.logErrors:
				wF5zRoQekA9lxOYacnju13yUIDs = R7RLCd9kyl.format_exc()
				if wF5zRoQekA9lxOYacnju13yUIDs!=JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"࠭ࡎࡰࡰࡨࡘࡾࡶࡥ࠻ࠢࡑࡳࡳ࡫࡜࡯ࠩൺ"): zGjD5QAkd7SO9YPcZl.stderr.write(wF5zRoQekA9lxOYacnju13yUIDs)
			zEcNagLnXdmhIwkOAs628J.failedLIST.append(p1tmbSLQT0jfKloyc5gvCIauJz)
			zEcNagLnXdmhIwkOAs628J.statusDICT[p1tmbSLQT0jfKloyc5gvCIauJz] = XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠧࡧࡣ࡬ࡰࡪࡪࠧൻ")
		zEcNagLnXdmhIwkOAs628J.finishtimeDICT[p1tmbSLQT0jfKloyc5gvCIauJz] = HB5PvxRhwM.time()
		zEcNagLnXdmhIwkOAs628J.elpasedtimeDICT[p1tmbSLQT0jfKloyc5gvCIauJz] = zEcNagLnXdmhIwkOAs628J.finishtimeDICT[p1tmbSLQT0jfKloyc5gvCIauJz] - zEcNagLnXdmhIwkOAs628J.starttimeDICT[p1tmbSLQT0jfKloyc5gvCIauJz]
	def ndOAzCvQJUf(zEcNagLnXdmhIwkOAs628J):
		for Ynpl7C1w9dgGNs in zEcNagLnXdmhIwkOAs628J.processesLIST:
			Ynpl7C1w9dgGNs.start()
	def fjHFSPQRi4IdDn68(zEcNagLnXdmhIwkOAs628J):
		while QVDJLRlxNg127jMX(u"ࠨࡴࡸࡲࡳ࡯࡮ࡨࠩർ") in list(zEcNagLnXdmhIwkOAs628J.statusDICT.values()): HB5PvxRhwM.sleep(ITvnUAMXsyb4eO(u"࠱፪"))
def ffeEJ30UNpykYO():
	if not Q9dmawtsE7unfZFyvzNVx5c1iL48CB: return LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠩࡑࡓࡤ࡛ࡐࡅࡃࡗࡉࠬൽ")
	RIK7b0rJqXF5Y6G1gncazC8Vtw4UTs = KBkxSYaz93pu1(u"ࠪࡊ࡚ࡒࡌࡠࡗࡓࡈࡆ࡚ࡅࠨൾ")
	EEzLQiBf9l2Zch3mW4 = [LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠫ࠽࠴࠵࠯࠲ࠪൿ"),MMizeNH0AKu(u"ࠬ࠸࠰࠳࠳࠱࠵࠵࠴࠱࠺ࠩ඀"),SqrG5mU3j96ldsFpExobw40TJY(u"࠭࠲࠱࠴࠴࠲࠶࠷࠮࠳࠶ࡤࠫඁ"),EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠧ࠳࠲࠵࠵࠳࠷࠲࠯࠵࠳ࠫං"),CnbBKmtF1x84q7AW(u"ࠨ࠴࠳࠶࠷࠴࠰࠳࠰࠳࠶ࠬඃ"),CnbBKmtF1x84q7AW(u"ࠩ࠵࠴࠷࠸࠮࠲࠲࠱࠶࠷࠭඄"),S1SgCFYGJeMvfp5iZXK(u"ࠪ࠶࠵࠸࠳࠯࠲࠶࠲࠵࠼ࠧඅ"),DJ1ICpbyR2(u"ࠫ࠷࠶࠲࠴࠰࠳࠹࠳࠷࠶ࠨආ"),o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠬ࠸࠰࠳࠵࠱࠴࠻࠴࠰࠷ࠩඇ"),gDuGMR3z1aV6YdLmCpiO8Kl(u"࠭࠲࠱࠴࠶࠲࠶࠶࠮࠳࠺ࠪඈ"),wwPrSDa21lUh(u"ࠧ࠳࠲࠵࠸࠳࠶࠱࠯࠳࠷ࠫඉ"),A6dMB1FlgxVivJ2fk9C(u"ࠨ࠴࠳࠶࠹࠴࠰࠸࠰࠵࠴ࠬඊ")]
	g6NORSau94Qjz0FMDiHKPq5cCfrn = EEzLQiBf9l2Zch3mW4[-bXukYxQ4aHw]
	Zfl0PtpAosMKQOHWky6CSIJi43j = w0yCzjaYOfEProxWik7lNXt8nA(g6NORSau94Qjz0FMDiHKPq5cCfrn)
	VwLsAG8BFIDWjzJ3kv9xcHXK5gRh = w0yCzjaYOfEProxWik7lNXt8nA(aO9cFKo862LqTWlIjy)
	if VwLsAG8BFIDWjzJ3kv9xcHXK5gRh>Zfl0PtpAosMKQOHWky6CSIJi43j:
		RIK7b0rJqXF5Y6G1gncazC8Vtw4UTs = OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠩࡖࡍࡒࡖࡌࡆࡡࡘࡔࡉࡇࡔࡆࠩඋ")
	return RIK7b0rJqXF5Y6G1gncazC8Vtw4UTs
def GQAuyEMhI6xdLiT():
	for jEouDWXOhenPHqidA,KKQ5ia7HZmGdWFvnyUJgXtz0u,o9frzGZySuB7KL3xNTAMI6gl8XjqiH in WQvYkNg7SysPFLitlGEn6.walk(zKdeknjoPhL9gN8v,topdown=fEXMiAyG3ql4vKB):
		if len(o9frzGZySuB7KL3xNTAMI6gl8XjqiH)>dv0trJR7PwmKyxDYO52VLau8gEph(u"࠶࠲࠳፫"): Xe6bnfEPjgqJy5FIoRi0z2v8(jEouDWXOhenPHqidA,fEXMiAyG3ql4vKB,fEXMiAyG3ql4vKB)
	return
def UGjc2OeCnoIpEWk0zP(aJb19RQ7MVp):
	if A6dMB1FlgxVivJ2fk9C(u"ࠪࡉ࡝࡚ࡒࡂࡒ࡜ࡘࡍࡕࡎࡄࡑࡇࡉࠬඌ") in str(iO1SgmkzGYaFoPXbfdj3NxQBus): return
	global u6rbxnyjTl7I,oaygHCpIDcs8wA
	qGn9IRUg27HZxyadO084SlscvXDF1f = hWGMqtBy4wuLaVcj
	if aJb19RQ7MVp: qGn9IRUg27HZxyadO084SlscvXDF1f = Mqk51CFBym0pIQXZLsOxSJ(MM5Dx39f7ULhcJsRptzIowP,QvgnCALNstmuUJiET(u"ࠫࡸࡺࡲࠨඍ"),wwPrSDa21lUh(u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࠨඎ"),xcChIL13BpR8WArNt9Pl0So(u"࠭ࡅ࡙ࡖࡕࡅࡕ࡟ࡔࡉࡑࡑࡇࡔࡊࡅࠨඏ"))
	if not qGn9IRUg27HZxyadO084SlscvXDF1f:
		S6NALBOqGn1zi2W5M8y7 = u6rbxnyjTl7I[XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠧࡑ࡛ࡗࡌࡔࡔࠧඐ")][ITvnUAMXsyb4eO(u"࠻፬")]
		AqIOj0aJsHQwtvlcyx = {MMizeNH0AKu(u"ࠨࡷࡶࡩࡷ࠭එ"):IIvxtojw6EXl2f,DJ1ICpbyR2(u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪඒ"):aO9cFKo862LqTWlIjy}
		BUXsmKe5dGpJj09REb6HqcO7tNv = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(lke5D6CpaAXPdEZyrBSw7T,FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠪࡔࡔ࡙ࡔࠨඓ"),S6NALBOqGn1zi2W5M8y7,AqIOj0aJsHQwtvlcyx,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,QvgnCALNstmuUJiET(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡋࡘࡕࡔࡄࡣࡕ࡟ࡔࡉࡑࡑࡣࡈࡕࡄࡆ࠯࠴ࡷࡹ࠭ඔ"))
		if BUXsmKe5dGpJj09REb6HqcO7tNv.succeeded:
			qGn9IRUg27HZxyadO084SlscvXDF1f = BUXsmKe5dGpJj09REb6HqcO7tNv.content
			BxuD7iQRpW1(MM5Dx39f7ULhcJsRptzIowP,gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࠨඕ"),xcChIL13BpR8WArNt9Pl0So(u"࠭ࡅ࡙ࡖࡕࡅࡕ࡟ࡔࡉࡑࡑࡇࡔࡊࡅࠨඖ"),qGn9IRUg27HZxyadO084SlscvXDF1f,VWxPgG1p8Z2Ei4DrX7NotvR)
	if qGn9IRUg27HZxyadO084SlscvXDF1f:
		global NEW_SITESURLS,vv5MhADynk0zUapIWNSexuftOYb
		exec(qGn9IRUg27HZxyadO084SlscvXDF1f,globals(),locals())
		u6rbxnyjTl7I.update(NEW_SITESURLS)
		oaygHCpIDcs8wA = vv5MhADynk0zUapIWNSexuftOYb
	return
def pXbZfBU7CYNkc5KTm():
	try: WQvYkNg7SysPFLitlGEn6.makedirs(vA0ImpguajeHKJ6P)
	except: pass
	WIxHYUqG8LoP = ffeEJ30UNpykYO()
	if WIxHYUqG8LoP==SqrG5mU3j96ldsFpExobw40TJY(u"ࠧࡔࡋࡐࡔࡑࡋ࡟ࡖࡒࡇࡅ࡙ࡋࠧ඗"): KteLZCbM8W0FqE2OBx1(pGYKHZgqFX3B,zyvJMtBhrw(u"ࠨ࠰࡟ࡸࡆࡸࡡࡣ࡫ࡦ࡚࡮ࡪࡥࡰࡵ࡙ࠣࡵࡪࡡࡵࡧࠣࡘࡾࡶࡥ࠻ࠢࠣࡗࡎࡓࡐࡍࡇ࡙ࠣࡕࡊࡁࡕࡇࠣࠤࠥࡖࡡࡵࡪ࠽ࠤࡠࠦࠧ඘")+i2tpOA6QzlfUByTSeKacWnV1+HHoGx7Flus60(u"ࠩࠣࡡࠬ඙"))
	else: KteLZCbM8W0FqE2OBx1(pGYKHZgqFX3B,NeO3CTLHrPfWUoIgy8Q(u"ࠪ࠲ࡡࡺࡁࡳࡣࡥ࡭ࡨ࡜ࡩࡥࡧࡲࡷ࡛ࠥࡰࡥࡣࡷࡩ࡚ࠥࡹࡱࡧ࠽ࠤࠥࡌࡕࡍࡎ࡙ࠣࡕࡊࡁࡕࡇࠣࠤࠥࡖࡡࡵࡪ࠽ࠤࡠࠦࠧක")+i2tpOA6QzlfUByTSeKacWnV1+A6dMB1FlgxVivJ2fk9C(u"ࠫࠥࡣࠧඛ"))
	BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨග"),sULh4NjakzI8He7xJCMGrql(u"࠭สๆࠢอัิ๐หࠡษ็ฬึ์วๆฮࠣๅ๏ࠦฬ่ษี็ࡡࡴลๅ๋ࠣห้หีะษิࠤึ่ๅ࠻࡞ࡱࡠࡳ࠭ඝ")+aO9cFKo862LqTWlIjy)
	BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪඞ"),QVDJLRlxNg127jMX(u"ࠨฬ่ࠤฯัศ๋ฬࠣวํࠦสฮัํฯࠥอไฦืาหึࠦวๅฮา๎ิࠦไษำ้ห๊าࠠศๆไ๎ิ๐่่ษอࠤฬู๊าสํอࠥ࠴ࠠฤ๊ࠣฮ๊ࠦๅิฯࠣ็ฬฺࠠศๆหี๋อๅอࠢ࡟ࡲࡡࡴࠠิ์ๅ์๊ࠦวๅฤ้ࠤฬ๊ศา่ส้ัࠦศษ฻ูࠤฬ๊แฮุ๊หฯࠦไื็ส๊ࠥ฿ๅๅࠢส่อืๆศ็ฯࠤอ฻่าหูࠣา๐อส๋้ࠢฯ้วๆๆฬࠫඟ"))
	pMPR1Cc0usZ6nJTU(MM5Dx39f7ULhcJsRptzIowP,o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬච"),FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠪࡕ࡚ࡋࡓࡕࡋࡒࡒࡘ࠭ඡ"))
	pMPR1Cc0usZ6nJTU(MM5Dx39f7ULhcJsRptzIowP,rwQN9AKhLCuMfHxjlbX0U(u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧජ"),JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠬࡇࡌࡍࡡࡄࡈࡉࡕࡎࡔࡡ࡛ࡑࡑ࠭ඣ"))
	pMPR1Cc0usZ6nJTU(MM5Dx39f7ULhcJsRptzIowP,KBkxSYaz93pu1(u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩඤ"),QVDJLRlxNg127jMX(u"ࠧࡇࡑࡕ࡛ࡆࡘࡄࡔࠩඥ"))
	pMPR1Cc0usZ6nJTU(MM5Dx39f7ULhcJsRptzIowP,CnbBKmtF1x84q7AW(u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫඦ"),FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠩࡖࡍ࡙ࡋࡓࡠࡐࡄࡑࡊ࡙ࠧට"))
	pMPR1Cc0usZ6nJTU(MM5Dx39f7ULhcJsRptzIowP,sULh4NjakzI8He7xJCMGrql(u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭ඨ"),S1SgCFYGJeMvfp5iZXK(u"ࠫࡘࡏࡔࡆࡕࡢࡇࡍࡋࡃࡌࠩඩ"))
	pMPR1Cc0usZ6nJTU(MM5Dx39f7ULhcJsRptzIowP,MMizeNH0AKu(u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨඪ"),SqrG5mU3j96ldsFpExobw40TJY(u"࠭ࡓࡊࡖࡈࡗࡤ࡜ࡅࡓࡋࡉ࡝ࠬණ"))
	ee8c0jzrTntGSUdRJm.setSetting(LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠧࡢࡸ࠱࡬ࡴࡹࡴ࠯ࡨࡲࡷࡹࡧࠧඬ"),hWGMqtBy4wuLaVcj)
	ee8c0jzrTntGSUdRJm.setSetting(QvgnCALNstmuUJiET(u"ࠨࡣࡹ࠲࡭ࡵࡳࡵ࠰ࡩࡥࡧࡸࡡ࡬ࡣࠪත"),hWGMqtBy4wuLaVcj)
	ee8c0jzrTntGSUdRJm.setSetting(EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠩࡤࡺ࠳࡮࡯ࡴࡶ࠱ࡷ࡭ࡧࡨࡪࡦ࠷ࡹࠬථ"),hWGMqtBy4wuLaVcj)
	ee8c0jzrTntGSUdRJm.setSetting(LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠪࡥࡻ࠴ࡨࡰࡵࡷ࠲࡫ࡧࡳࡦ࡮࡫ࡨ࠶࠭ද"),hWGMqtBy4wuLaVcj)
	ee8c0jzrTntGSUdRJm.setSetting(gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠫࡦࡼ࠮ࡱࡴ࡬ࡺࡸ࠷ࠧධ"),hWGMqtBy4wuLaVcj)
	ee8c0jzrTntGSUdRJm.setSetting(SqrG5mU3j96ldsFpExobw40TJY(u"ࠬࡧࡶ࠯ࡲࡵ࡭ࡻࡹ࠲ࠨන"),hWGMqtBy4wuLaVcj)
	ee8c0jzrTntGSUdRJm.setSetting(LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"࠭ࡡࡷ࠰ࡳࡩࡷ࡯࡯ࡥ࠰࡬ࡲ࡫ࡵࡳࠨ඲"),hWGMqtBy4wuLaVcj)
	ee8c0jzrTntGSUdRJm.setSetting(QvgnCALNstmuUJiET(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴ࡳࡩࡱࡵࡸࠬඳ"),hWGMqtBy4wuLaVcj)
	ee8c0jzrTntGSUdRJm.setSetting(JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮ࡳࡧࡪࡹࡱࡧࡲࠨප"),hWGMqtBy4wuLaVcj)
	ee8c0jzrTntGSUdRJm.setSetting(sULh4NjakzI8He7xJCMGrql(u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯࡮ࡲࡲ࡬࠭ඵ"),hWGMqtBy4wuLaVcj)
	ee8c0jzrTntGSUdRJm.setSetting(QVDJLRlxNg127jMX(u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰ࡰࡩࡸࡹࡡࡨࡧࡶࠫබ"),hWGMqtBy4wuLaVcj)
	ee8c0jzrTntGSUdRJm.setSetting(CnbBKmtF1x84q7AW(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ࠭භ"),hWGMqtBy4wuLaVcj)
	pMPR1Cc0usZ6nJTU(MM5Dx39f7ULhcJsRptzIowP,sULh4NjakzI8He7xJCMGrql(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡔࡋࡗࡉࡘ࠭ම"))
	pMPR1Cc0usZ6nJTU(MM5Dx39f7ULhcJsRptzIowP,hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡋࡓࡘ࡛࠭ඹ"))
	pMPR1Cc0usZ6nJTU(MM5Dx39f7ULhcJsRptzIowP,NeO3CTLHrPfWUoIgy8Q(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡐ࠷࡚࠭ය"))
	pMPR1Cc0usZ6nJTU(MM5Dx39f7ULhcJsRptzIowP,CnbBKmtF1x84q7AW(u"ࠨࡕࡆࡖࡆࡖࡅࡓࡕࡢࡗ࡙ࡇࡔࡖࡕࠪර"))
	OwGHUMSI3WuYd9VtcC5ehnbFxv04Xi(fEXMiAyG3ql4vKB)
	bXjeBx6vV52PfJpcKah0kUGiSsWC(lke5D6CpaAXPdEZyrBSw7T)
	import ZGYSlz63X1
	ZGYSlz63X1.Y6MUwOztEjeTSW7Ha(VBlawK4mgHSyLEn8iqhUkz5)
	if WIxHYUqG8LoP==MMizeNH0AKu(u"ࠩࡖࡍࡒࡖࡌࡆࡡࡘࡔࡉࡇࡔࡆࠩ඼"):
		GG49f0QoTrPgvyYOHeb1MsUIjiJlw(VBlawK4mgHSyLEn8iqhUkz5,[MM5Dx39f7ULhcJsRptzIowP])
	else:
		GG49f0QoTrPgvyYOHeb1MsUIjiJlw(fEXMiAyG3ql4vKB,[])
		ZGYSlz63X1.ZZf2P84FwEJgrslpGVvjc1z()
		ZGYSlz63X1.ff1TqXMbjgJ6n4yko(gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡣࡧࡥࡵࡺࡩࡷࡧࠪල"),fEXMiAyG3ql4vKB)
		ZGYSlz63X1.ff1TqXMbjgJ6n4yko(GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡵࡸࡲࡶࠧ඾"),fEXMiAyG3ql4vKB)
		try:
			IHWFEuXpACRnJr = WQvYkNg7SysPFLitlGEn6.path.join(W96kNDymei,DJ1ICpbyR2(u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧ඿"),HHoGx7Flus60(u"࠭ࡡࡥࡦࡲࡲࡤࡪࡡࡵࡣࠪව"),OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠧࡴࡥࡵ࡭ࡵࡺ࠮࡮ࡱࡧࡹࡱ࡫࠮ࡳࡧࡶࡳࡱࡼࡥࡶࡴ࡯ࠫශ"),sULh4NjakzI8He7xJCMGrql(u"ࠨࡵࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡼࡲࡲࠧෂ"))
			XS10aKFBqOxVwDj7elPEbcZgJNmiof = FaP2ug05rl8EmAHkQsNid.Addon(id=KBkxSYaz93pu1(u"ࠩࡶࡧࡷ࡯ࡰࡵ࠰ࡰࡳࡩࡻ࡬ࡦ࠰ࡵࡩࡸࡵ࡬ࡷࡧࡸࡶࡱ࠭ස"))
			XS10aKFBqOxVwDj7elPEbcZgJNmiof.setSetting(zyvJMtBhrw(u"ࠪࡥࡻ࠴ࡡࡶࡶࡲࡣࡵ࡯ࡣ࡬ࠩහ"),QVDJLRlxNg127jMX(u"ࠫࡋࡧ࡬ࡴࡧࠪළ"))
		except: pass
		try:
			IHWFEuXpACRnJr = WQvYkNg7SysPFLitlGEn6.path.join(W96kNDymei,NeO3CTLHrPfWUoIgy8Q(u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧෆ"),KBkxSYaz93pu1(u"࠭ࡡࡥࡦࡲࡲࡤࡪࡡࡵࡣࠪ෇"),hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠧࡴࡥࡵ࡭ࡵࡺ࠮࡮ࡱࡧࡹࡱ࡫࠮ࡺࡶ࠰ࡨࡱࡶࠧ෈"),zyvJMtBhrw(u"ࠨࡵࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡼࡲࡲࠧ෉"))
			XS10aKFBqOxVwDj7elPEbcZgJNmiof = FaP2ug05rl8EmAHkQsNid.Addon(id=e2qDYgipPmTw4KvBLnochr(u"ࠩࡶࡧࡷ࡯ࡰࡵ࠰ࡰࡳࡩࡻ࡬ࡦ࠰ࡼࡸ࠲ࡪ࡬ࡱ්ࠩ"))
			XS10aKFBqOxVwDj7elPEbcZgJNmiof.setSetting(FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠪࡥࡻ࠴ࡶࡪࡦࡨࡳࡤࡷࡵࡢ࡮࡬ࡸࡾ࠭෋"),QVDJLRlxNg127jMX(u"ࠫ࠸࠭෌"))
		except: pass
		try:
			IHWFEuXpACRnJr = WQvYkNg7SysPFLitlGEn6.path.join(W96kNDymei,LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧ෍"),wwPrSDa21lUh(u"࠭ࡡࡥࡦࡲࡲࡤࡪࡡࡵࡣࠪ෎"),o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡧࡤࡢࡲࡷ࡭ࡻ࡫ࠧා"),FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠨࡵࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡼࡲࡲࠧැ"))
			XS10aKFBqOxVwDj7elPEbcZgJNmiof = FaP2ug05rl8EmAHkQsNid.Addon(id=LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡢࡦࡤࡴࡹ࡯ࡶࡦࠩෑ"))
			XS10aKFBqOxVwDj7elPEbcZgJNmiof.setSetting(e2qDYgipPmTw4KvBLnochr(u"ࠪࡥࡻ࠴ࡓࡕࡔࡈࡅࡒ࡙ࡅࡍࡇࡆࡘࡎࡕࡎࠨි"),jeAby54c02TgG8zuivonX91(u"ࠫ࠷࠭ී"))
		except: pass
	F49URk16JIawgp7YWZAXGtnMb = rpIZC2m6gEkAh(UC78nrbeDHfwVAh2vt)
	F49URk16JIawgp7YWZAXGtnMb = rpIZC2m6gEkAh(IlCq2uKjye3ZgSADFc)
	ZGYSlz63X1.c8PUgLdMzy9iWbIuONmJDoC56fAV1e(fEXMiAyG3ql4vKB)
	ee8c0jzrTntGSUdRJm.setSetting(e2qDYgipPmTw4KvBLnochr(u"ࠬࡧࡶ࠯ࡸࡨࡶࡸ࡯࡯࡯ࠩු"),aO9cFKo862LqTWlIjy)
	CfKNTtIi3OABbWcPpdF(fEXMiAyG3ql4vKB)
	return
def Gtp15S93F0lhbxcTCU7():
	AV7uZK2wkN = ssYJQiWrZIRqkMe(ee8c0jzrTntGSUdRJm.getSetting(KNIvHPjUbhr(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡹࡨࡰࡴࡷࠫ෕")))
	AV7uZK2wkN = ybdv7XcT3lxF6QezULwCAGk if not AV7uZK2wkN else int(AV7uZK2wkN)
	if not AV7uZK2wkN or not ybdv7XcT3lxF6QezULwCAGk<=IHKJoQ8PwW4pNBR6GTAMVz2hdfC5my-AV7uZK2wkN<=nHBb7jXk0Daom:
		ee8c0jzrTntGSUdRJm.setSetting(jeAby54c02TgG8zuivonX91(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴ࡳࡩࡱࡵࡸࠬූ"),smVarGBSwFI219cP(IHKJoQ8PwW4pNBR6GTAMVz2hdfC5my))
		bXjeBx6vV52PfJpcKah0kUGiSsWC(lke5D6CpaAXPdEZyrBSw7T)
		ttcGmKRfiYjqraFlCAHJLv1Wb = ssYJQiWrZIRqkMe(ee8c0jzrTntGSUdRJm.getSetting(gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮ࡳࡧࡪࡹࡱࡧࡲࠨ෗")))
		ttcGmKRfiYjqraFlCAHJLv1Wb = ybdv7XcT3lxF6QezULwCAGk if not ttcGmKRfiYjqraFlCAHJLv1Wb else int(ttcGmKRfiYjqraFlCAHJLv1Wb)
		if not ttcGmKRfiYjqraFlCAHJLv1Wb or not ybdv7XcT3lxF6QezULwCAGk<=IHKJoQ8PwW4pNBR6GTAMVz2hdfC5my-ttcGmKRfiYjqraFlCAHJLv1Wb<=KqO5BWGQR9JVL:
			ee8c0jzrTntGSUdRJm.setSetting(LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯ࡴࡨ࡫ࡺࡲࡡࡳࠩෘ"),smVarGBSwFI219cP(IHKJoQ8PwW4pNBR6GTAMVz2hdfC5my))
			UGjc2OeCnoIpEWk0zP(fEXMiAyG3ql4vKB)
		BDhJvU82lFus = ssYJQiWrZIRqkMe(ee8c0jzrTntGSUdRJm.getSetting(CnbBKmtF1x84q7AW(u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰࡯ࡳࡳ࡭ࠧෙ")))
		BDhJvU82lFus = ybdv7XcT3lxF6QezULwCAGk if not BDhJvU82lFus else int(BDhJvU82lFus)
		if not BDhJvU82lFus or not ybdv7XcT3lxF6QezULwCAGk<=IHKJoQ8PwW4pNBR6GTAMVz2hdfC5my-BDhJvU82lFus<=DpQifS0oKBI1hYcO:
			ee8c0jzrTntGSUdRJm.setSetting(S1SgCFYGJeMvfp5iZXK(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡰࡴࡴࡧࠨේ"),smVarGBSwFI219cP(IHKJoQ8PwW4pNBR6GTAMVz2hdfC5my))
			GtYBimvRdJc7P1L8XbgsAek = KCTRe67wVy.Thread(target=GQAuyEMhI6xdLiT)
			GtYBimvRdJc7P1L8XbgsAek.start()
	u4aYqk52tzEhSWUTvx = ssYJQiWrZIRqkMe(ee8c0jzrTntGSUdRJm.getSetting(e2qDYgipPmTw4KvBLnochr(u"ࠬࡧࡶ࠯ࡲࡨࡶ࡮ࡵࡤ࠯࡫ࡱࡪࡴࡹࠧෛ")))
	u4aYqk52tzEhSWUTvx = ybdv7XcT3lxF6QezULwCAGk if not u4aYqk52tzEhSWUTvx else int(u4aYqk52tzEhSWUTvx)
	zfpMSUsTDxBVuylg7wqNtaQ3 = ssYJQiWrZIRqkMe(ee8c0jzrTntGSUdRJm.getSetting(A6dMB1FlgxVivJ2fk9C(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡷࡵࡦࡵࡷ࡭ࡴࡴࡳࠨො")))
	zfpMSUsTDxBVuylg7wqNtaQ3 = ybdv7XcT3lxF6QezULwCAGk if not zfpMSUsTDxBVuylg7wqNtaQ3 else int(zfpMSUsTDxBVuylg7wqNtaQ3)
	if not u4aYqk52tzEhSWUTvx or not zfpMSUsTDxBVuylg7wqNtaQ3 or not ybdv7XcT3lxF6QezULwCAGk<=IHKJoQ8PwW4pNBR6GTAMVz2hdfC5my-zfpMSUsTDxBVuylg7wqNtaQ3<=u4aYqk52tzEhSWUTvx: OOekif9mwHvcyQU()
	return
def OOekif9mwHvcyQU():
	V8S6y9PtYlijZAMubkONxFHUw30p = bXukYxQ4aHw
	BLzOVEFvMwfdoC2K = fEXMiAyG3ql4vKB if MmcgqAlsFt.PiR735OmVcFjpE0yeCoM4 else VBlawK4mgHSyLEn8iqhUkz5
	if BLzOVEFvMwfdoC2K:
		QC27qaXRVojSpLy9K = DNjHn7Gxf3(VBlawK4mgHSyLEn8iqhUkz5)
		if len(QC27qaXRVojSpLy9K)>bXukYxQ4aHw:
			KteLZCbM8W0FqE2OBx1(pGYKHZgqFX3B,CnbBKmtF1x84q7AW(u"ࠧ࠯࡞ࡷࡗ࡭ࡵࡷࡪࡰࡪࠤࡖࡻࡥࡴࡶ࡬ࡳࡳࠦࠠࠡࡒࡤࡸ࡭ࡀࠠ࡜ࠢࠪෝ")+i2tpOA6QzlfUByTSeKacWnV1+OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠨࠢࡠࠫෞ"))
			p1tmbSLQT0jfKloyc5gvCIauJz,EPuMlX4RDWry9L,txuBWHAqlekYzCmJdFnXb7Og0oS,vIzgrEDLkOA,zzohWAV87dCuEJl0kxnX9Rs3wjMQ2G,jZyzn8MtORbaeCW = QC27qaXRVojSpLy9K[ybdv7XcT3lxF6QezULwCAGk]
			ee2hxg3Z5aOVTrkmzNQRYPSJWc,bxzkd0chHfWBXa = vIzgrEDLkOA.split(gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠩ࡟ࡲࡀࡁࠧෟ"))
			del QC27qaXRVojSpLy9K[ybdv7XcT3lxF6QezULwCAGk]
			I0j6EbJ4HDvwxYSKLWU = eOmXSF6kIWV7yqKCR.sample(QC27qaXRVojSpLy9K,bXukYxQ4aHw)
			p1tmbSLQT0jfKloyc5gvCIauJz,EPuMlX4RDWry9L,txuBWHAqlekYzCmJdFnXb7Og0oS,vIzgrEDLkOA,zzohWAV87dCuEJl0kxnX9Rs3wjMQ2G,jZyzn8MtORbaeCW = I0j6EbJ4HDvwxYSKLWU[ybdv7XcT3lxF6QezULwCAGk]
			txuBWHAqlekYzCmJdFnXb7Og0oS = gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠪ࡟ࡗ࡚ࡌ࡞ࠩ෠")+soMVfbr6WtpNlcSA+S1SgCFYGJeMvfp5iZXK(u"ࠫࠥࡀࠠࠨ෡")+p1tmbSLQT0jfKloyc5gvCIauJz+YYSh2J6BIrsm8+txuBWHAqlekYzCmJdFnXb7Og0oS
			zzohWAV87dCuEJl0kxnX9Rs3wjMQ2G = FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠬหัิษ็ࠤึูวๅห่้๋ࠣศา็ฯࠫ෢")
			PPWZFTodxwQrjenBS0YmlXbp = FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"࠭วๅฬหี฾อสࠨ෣")
			button0,button1 = vIzgrEDLkOA,zzohWAV87dCuEJl0kxnX9Rs3wjMQ2G
			kYnULZpSWKDCb31eAsV8yN = [button0,button1,PPWZFTodxwQrjenBS0YmlXbp]
			EfDrqClYG8LK6TXuR9M1Fehg = bXukYxQ4aHw if MmcgqAlsFt.sTZjaIcENd else MMizeNH0AKu(u"࠴࠴፭")
			c7doTBkbPWtIsGlgeFa58f = -hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"࠽፮")
			while c7doTBkbPWtIsGlgeFa58f<ybdv7XcT3lxF6QezULwCAGk:
				V7xpcYhWdw8TRy2LuSqbZzrKt = eOmXSF6kIWV7yqKCR.sample(kYnULZpSWKDCb31eAsV8yN,x1x9kIQo3zjZWnYaiy)
				c7doTBkbPWtIsGlgeFa58f = jbQkTyxAerZR409gYFq(hWGMqtBy4wuLaVcj,V7xpcYhWdw8TRy2LuSqbZzrKt[ybdv7XcT3lxF6QezULwCAGk],V7xpcYhWdw8TRy2LuSqbZzrKt[bXukYxQ4aHw],V7xpcYhWdw8TRy2LuSqbZzrKt[Y0XZKGRAUQj5O],ee2hxg3Z5aOVTrkmzNQRYPSJWc,txuBWHAqlekYzCmJdFnXb7Og0oS,dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠧࡤࡱࡱࡪ࡮ࡸ࡭ࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩ෤"),EfDrqClYG8LK6TXuR9M1Fehg,KNIvHPjUbhr(u"࠻࠶፯"))
				if c7doTBkbPWtIsGlgeFa58f==ITvnUAMXsyb4eO(u"࠷࠰፰"): break
				import ZGYSlz63X1
				if c7doTBkbPWtIsGlgeFa58f>=ybdv7XcT3lxF6QezULwCAGk and V7xpcYhWdw8TRy2LuSqbZzrKt[c7doTBkbPWtIsGlgeFa58f]==kYnULZpSWKDCb31eAsV8yN[bXukYxQ4aHw]:
					ZGYSlz63X1.mag0BJDLNYjc1iKkpl8()
					if c7doTBkbPWtIsGlgeFa58f>=ybdv7XcT3lxF6QezULwCAGk: c7doTBkbPWtIsGlgeFa58f = -A6dMB1FlgxVivJ2fk9C(u"࠹፱")
				elif c7doTBkbPWtIsGlgeFa58f>=ybdv7XcT3lxF6QezULwCAGk and V7xpcYhWdw8TRy2LuSqbZzrKt[c7doTBkbPWtIsGlgeFa58f]==kYnULZpSWKDCb31eAsV8yN[Y0XZKGRAUQj5O]:
					ZGYSlz63X1.DC4GvtpUbZJ38mfMIRijkY(fEXMiAyG3ql4vKB)
				if c7doTBkbPWtIsGlgeFa58f==-bXukYxQ4aHw: BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,mkHKSQvjWr5BTcM3wVY(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ෥"),soMVfbr6WtpNlcSA+e2qDYgipPmTw4KvBLnochr(u"ࠩัีําࠠฯูฦࠫ෦")+YYSh2J6BIrsm8+A6dMB1FlgxVivJ2fk9C(u"ࠪࡠࡳࠦไๅะิ์ัࠦวๅืะ๎าࠦรฯฬิࠤํออะ่๊ࠢࠥอไฤฮ๋ฬฮࠦวๅ็อ์ๆืษࠨ෧"))
			V8S6y9PtYlijZAMubkONxFHUw30p = bXukYxQ4aHw
		else: V8S6y9PtYlijZAMubkONxFHUw30p = ybdv7XcT3lxF6QezULwCAGk
	ee8c0jzrTntGSUdRJm.setSetting(S1SgCFYGJeMvfp5iZXK(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ࠭෨"),smVarGBSwFI219cP(IHKJoQ8PwW4pNBR6GTAMVz2hdfC5my))
	BxuD7iQRpW1(MM5Dx39f7ULhcJsRptzIowP,LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨ෩"),hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"࠭ࡓࡊࡖࡈࡗࡤࡔࡁࡎࡇࡖࠫ෪"),V8S6y9PtYlijZAMubkONxFHUw30p,VWxPgG1p8Z2Ei4DrX7NotvR)
	return
def dmockO8CjZ9Wp2(X3X4Y8RzxSVfZJUFDe,wJUqaIAzvtsMSEZlKV,S6NALBOqGn1zi2W5M8y7,u2GRrQ0854,nWE8aO53lFfD,l7COkhRWD9uVS60Pte2NoyAaZn,XNBHzrlKD9yW,MH5c7Nekugx8O1AQjInRWyT64GV,SX7OT3VLGp2iQm,ahU9MCTwjqmOPsZnY6lLK73bvJ,h4s5qao1CX,G62uf8ZSIzBE,W5mewaZEsh,b9Vog0ysSGkHzAMZnarhJE2wFQmXq1):
	r8DwfBNi3bqc9xyVuXF7YLj02dPRI = int(ahU9MCTwjqmOPsZnY6lLK73bvJ%OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"࠲࠲፲"))
	DASrslYGWIQwxjOdu0eN368o = int(ahU9MCTwjqmOPsZnY6lLK73bvJ/rwQN9AKhLCuMfHxjlbX0U(u"࠳࠳፳"))
	tDHVapfQdxX3LZeRh = X3X4Y8RzxSVfZJUFDe,wJUqaIAzvtsMSEZlKV,S6NALBOqGn1zi2W5M8y7,u2GRrQ0854,nWE8aO53lFfD,l7COkhRWD9uVS60Pte2NoyAaZn,XNBHzrlKD9yW,hWGMqtBy4wuLaVcj,SX7OT3VLGp2iQm
	DUn5W9Ns3V82kLS = ee8c0jzrTntGSUdRJm.getSetting(OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡱࡪࡴࡵࡴࡥࡤࡧ࡭࡫ࠧ෫"))
	if not DUn5W9Ns3V82kLS: ee8c0jzrTntGSUdRJm.setSetting(xcChIL13BpR8WArNt9Pl0So(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡲ࡫࡮ࡶࡵࡦࡥࡨ࡮ࡥࠨ෬"),A6dMB1FlgxVivJ2fk9C(u"ࠩࡄ࡙࡙ࡕࠧ෭"))
	agkF7iSBOZ4DKJC25yztrsN86cXLfV = ee8c0jzrTntGSUdRJm.getSetting(mkHKSQvjWr5BTcM3wVY(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡲࡦࡨࡵࡩࡸ࡮ࠧ෮"))
	SaLcnMBU8Kp7qxYgzbeJROu = RqfZ4ma8Jjh9EU(h4s5qao1CX)
	S4zsXB1uYRxcQKZ7EWDy8p = [ybdv7XcT3lxF6QezULwCAGk,JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"࠵࠺፵"),ITvnUAMXsyb4eO(u"࠶࠽፶"),e2qDYgipPmTw4KvBLnochr(u"࠷࠹፷"),jeAby54c02TgG8zuivonX91(u"࠵࠺፴"),QvgnCALNstmuUJiET(u"࠵࠷፺"),jeAby54c02TgG8zuivonX91(u"࠵࠱፸"),JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"࠶࠵፹")]
	Cvh4MFx9PD7sEbUfAmTB = DASrslYGWIQwxjOdu0eN368o not in S4zsXB1uYRxcQKZ7EWDy8p
	FnB2U4uX38cA7L6vK9epNx = DASrslYGWIQwxjOdu0eN368o in [e2qDYgipPmTw4KvBLnochr(u"࠸࠳፾"),FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"࠵࠼፻"),DJ1ICpbyR2(u"࠼࠷፽"),LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"࠻࠷፼")]
	VORFDEIPin05bHWCYrk2qTv6Jt7S = ahU9MCTwjqmOPsZnY6lLK73bvJ in [gDuGMR3z1aV6YdLmCpiO8Kl(u"࠳࠸࠸ᎀ"),EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"࠲࠸࠲፿")]
	AMc08flqTCvhoLUpjrI2n1e54ux = (Cvh4MFx9PD7sEbUfAmTB or FnB2U4uX38cA7L6vK9epNx) and not VORFDEIPin05bHWCYrk2qTv6Jt7S
	LLl0CV5tyvTIw = (agkF7iSBOZ4DKJC25yztrsN86cXLfV or not MH5c7Nekugx8O1AQjInRWyT64GV) and agkF7iSBOZ4DKJC25yztrsN86cXLfV not in [sULh4NjakzI8He7xJCMGrql(u"ࠫࡗࡋࡆࡓࡇࡖࡌࡤࡉࡁࡄࡊࡈࠫ෯")]+xLj46t2Qbi3dr8EgRDXmPMqpUwsvN
	VVsD49JztQdLhU = jeAby54c02TgG8zuivonX91(u"ࠬࡺࡹࡱࡧࡀࠫ෰") in agkF7iSBOZ4DKJC25yztrsN86cXLfV
	ej38lDurcg = ahU9MCTwjqmOPsZnY6lLK73bvJ in [gDuGMR3z1aV6YdLmCpiO8Kl(u"࠶࠼࠱ᎋ"),SqrG5mU3j96ldsFpExobw40TJY(u"࠷࠶࠳ᎌ"),A6dMB1FlgxVivJ2fk9C(u"࠱࠷࠵ᎍ"),MMizeNH0AKu(u"࠲࠸࠷ᎇ"),LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"࠳࠹࠹ᎈ"),JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"࠴࠺࠻ᎉ"),QVDJLRlxNg127jMX(u"࠵࠻࠽ᎊ"),dv0trJR7PwmKyxDYO52VLau8gEph(u"࠱࠷࠺ᎆ"),GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"࠻࠻࠷ᎃ"),EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"࠹࠹࠶ᎁ"),FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"࠺࠺࠸ᎂ"),sULh4NjakzI8He7xJCMGrql(u"࠼࠼࠴ᎄ"),XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"࠽࠶࠶ᎅ")]
	lPwaAjFTMG4n7iSLkXcEuK0Zm = r8DwfBNi3bqc9xyVuXF7YLj02dPRI==sULh4NjakzI8He7xJCMGrql(u"࠺ᎎ") or ahU9MCTwjqmOPsZnY6lLK73bvJ in [xcChIL13BpR8WArNt9Pl0So(u"࠴࠸࠺᎐"),gDuGMR3z1aV6YdLmCpiO8Kl(u"࠺࠷࠶᎒"),QVDJLRlxNg127jMX(u"࠹࠷࠹᎑"),xcChIL13BpR8WArNt9Pl0So(u"࠶࠸ᎏ")]
	zuRr4KAPUMZ2OmDH1ldx7BIvbL = not ej38lDurcg
	cWhY67NrHv0mtsPuVG91AxS = not lPwaAjFTMG4n7iSLkXcEuK0Zm
	PlhHfwijQLD1JoOr5eq872ZyuazXI = SaLcnMBU8Kp7qxYgzbeJROu in [hWGMqtBy4wuLaVcj,DJ1ICpbyR2(u"࠭࠮࠯ࠩ෱")]
	cL6dBEMQD9eFt0iUvZIRXWxCnJy = PlhHfwijQLD1JoOr5eq872ZyuazXI or zuRr4KAPUMZ2OmDH1ldx7BIvbL
	h2SpJgVdeC7oTUlI8Y = PlhHfwijQLD1JoOr5eq872ZyuazXI or cWhY67NrHv0mtsPuVG91AxS or VVsD49JztQdLhU
	R4e12CynJZko8W = ahU9MCTwjqmOPsZnY6lLK73bvJ not in [zyvJMtBhrw(u"࠵࠺࠵᎗"),ITvnUAMXsyb4eO(u"࠸࠶࠲᎓"),OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"࠶࠻࠻᎘"),dv0trJR7PwmKyxDYO52VLau8gEph(u"࠳࠹࠳᎕"),zyvJMtBhrw(u"࠳࠴࠲᎔"),CnbBKmtF1x84q7AW(u"࠷࠷࠴᎖"),rwQN9AKhLCuMfHxjlbX0U(u"࠶࠶࠱࠱᎙")]
	if DUn5W9Ns3V82kLS==gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠧࡔࡖࡒࡔࠬෲ"): DjtqCK8vgGFcZ0zE63d = lPwaAjFTMG4n7iSLkXcEuK0Zm or ej38lDurcg
	else: DjtqCK8vgGFcZ0zE63d = VBlawK4mgHSyLEn8iqhUkz5
	pC896fEsT1bqOL = DASrslYGWIQwxjOdu0eN368o in [HHoGx7Flus60(u"࠸࠶᎜"),mkHKSQvjWr5BTcM3wVY(u"࠷࠶᎛"),GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"࠻࠴᎚"),MMizeNH0AKu(u"࠳࠳࠵᎝")]
	CCQ2qKGTU5wkoYSHdFsRA = ahU9MCTwjqmOPsZnY6lLK73bvJ in [A6dMB1FlgxVivJ2fk9C(u"࠵࠼࠵᎞"),wwPrSDa21lUh(u"࠻࠷࠶᎟")]
	sq1rIzwWFUYTl0ZXbopvyPkmc = not pC896fEsT1bqOL and not CCQ2qKGTU5wkoYSHdFsRA
	PBkQLI0bz74qfG = cL6dBEMQD9eFt0iUvZIRXWxCnJy and h2SpJgVdeC7oTUlI8Y and R4e12CynJZko8W and DjtqCK8vgGFcZ0zE63d and sq1rIzwWFUYTl0ZXbopvyPkmc
	ztCUQ7Iy5pEhjTe = R4e12CynJZko8W and DjtqCK8vgGFcZ0zE63d and sq1rIzwWFUYTl0ZXbopvyPkmc
	mUfTGE2JW7qdoz9PYnrptSNlc5i8 = ztCUQ7Iy5pEhjTe
	lxMmbVO6gvQSthz1AFfe3IZPH9n2qW = ee8c0jzrTntGSUdRJm.getSetting(QVDJLRlxNg127jMX(u"ࠨࡣࡹ࠲ࡱࡧ࡮ࡨࡷࡤ࡫ࡪ࠴ࡰࡳࡱࡹ࡭ࡩ࡫ࡲࠨෳ"))
	Yeat7ZiMI2LgS = ee8c0jzrTntGSUdRJm.getSetting(dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠩࡤࡺ࠳ࡲࡡ࡯ࡩࡸࡥ࡬࡫࠮ࡤࡱࡧࡩࠬ෴"))
	ayWcYR1eLECFvV0f3NnlXOzK2 = fEXMiAyG3ql4vKB
	if LLl0CV5tyvTIw and PBkQLI0bz74qfG:
		SV8JK1ZgPRWGLynsXYav0eu2F6zo = Mqk51CFBym0pIQXZLsOxSJ(MM5Dx39f7ULhcJsRptzIowP,CnbBKmtF1x84q7AW(u"ࠪࡰ࡮ࡹࡴࠨ෵"),zyvJMtBhrw(u"ࠫࡒࡋࡎࡖࡕࡢࡇࡆࡉࡈࡆࡡࠪ෶")+lxMmbVO6gvQSthz1AFfe3IZPH9n2qW+SqrG5mU3j96ldsFpExobw40TJY(u"ࠬࡥࠧ෷")+Yeat7ZiMI2LgS,tDHVapfQdxX3LZeRh)
		if SV8JK1ZgPRWGLynsXYav0eu2F6zo:
			KteLZCbM8W0FqE2OBx1(hWGMqtBy4wuLaVcj,zyvJMtBhrw(u"࠭࠮࡝ࡶࡐࡉࡓ࡛ࡓࡠࡅࡄࡇࡍࡋ࡟ࠨ෸")+lxMmbVO6gvQSthz1AFfe3IZPH9n2qW+mkHKSQvjWr5BTcM3wVY(u"ࠧࡠࠩ෹")+Yeat7ZiMI2LgS+HHoGx7Flus60(u"ࠨࠢࠣࠤࡑࡵࡡࡥ࡫ࡱ࡫ࠥࡳࡥ࡯ࡷࠣࡪࡷࡵ࡭ࠡࡥࡤࡧ࡭࡫ࠧ෺"))
			if VVsD49JztQdLhU:
				bSA4VODnfYzpRg25UokXcK6 = []
				from PPEqJVcZfd import eepKVQRXIOnhoA
				from jjGMocmUg2 import Z54CwW0eVXn,AAZbtg5RKeUcr47IYTvVSaELqN
				gQVW5w9hd2PO = eepKVQRXIOnhoA
				zf9w6CGsigUny25TaVkcP3H = Z54CwW0eVXn()
				pDaHk6u0PSX9vwBbtfCgKNOd = agkF7iSBOZ4DKJC25yztrsN86cXLfV
				Vqdpvr3Q6M4,yHgnOS9ArD6uB3iwKslQYCq5bT,u7iGbE0HcNz1dPoxQVnKOFLS,MXfIpdAD1gk4KuajVZLec60Wl2,cNj95b1tF6,xadZzyNwPL5F9sGl,hZQPk2JafYHvKqo6IcWETbyUsDiwMR,XSVlcyh0G3QFsbTLgZ,x4xPfokp23WlJrUFE1dNRBsI = vikbdSOtZJFz6gQeL(pDaHk6u0PSX9vwBbtfCgKNOd)
				OOWDZ8lLJFnmyaGYxe64Kjq3 = Vqdpvr3Q6M4,yHgnOS9ArD6uB3iwKslQYCq5bT,u7iGbE0HcNz1dPoxQVnKOFLS,MXfIpdAD1gk4KuajVZLec60Wl2,cNj95b1tF6,xadZzyNwPL5F9sGl,hZQPk2JafYHvKqo6IcWETbyUsDiwMR,hWGMqtBy4wuLaVcj,x4xPfokp23WlJrUFE1dNRBsI
				for Xh70Lzi14uIxEFqnyPV2c in SV8JK1ZgPRWGLynsXYav0eu2F6zo:
					rzUtjfowB6Pib0 = Xh70Lzi14uIxEFqnyPV2c[HHoGx7Flus60(u"ࠩࡰࡩࡳࡻࡉࡵࡧࡰࠫ෻")]
					if rzUtjfowB6Pib0==OOWDZ8lLJFnmyaGYxe64Kjq3 or Xh70Lzi14uIxEFqnyPV2c[gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠪࡱࡴࡪࡥࠨ෼")] in [rwQN9AKhLCuMfHxjlbX0U(u"࠸࠶࠶Ꭱ"),LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"࠷࠽࠰Ꭰ")]:
						Xh70Lzi14uIxEFqnyPV2c = ddx6ayPYD9cKSvq45Zh0LkIHBUEp(rzUtjfowB6Pib0,gQVW5w9hd2PO,zf9w6CGsigUny25TaVkcP3H)
						if Xh70Lzi14uIxEFqnyPV2c[DJ1ICpbyR2(u"ࠫ࡫ࡧࡶࡰࡴ࡬ࡸࡪࡹࠧ෽")]:
							dd3QaKLx9My6A = AAZbtg5RKeUcr47IYTvVSaELqN(zf9w6CGsigUny25TaVkcP3H,rzUtjfowB6Pib0,Xh70Lzi14uIxEFqnyPV2c[XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠬࡴࡥࡸࡲࡤࡸ࡭࠭෾")])
							Xh70Lzi14uIxEFqnyPV2c[ITvnUAMXsyb4eO(u"࠭ࡣࡰࡰࡷࡩࡽࡺ࡟࡮ࡧࡱࡹࠬ෿")] = dd3QaKLx9My6A+Xh70Lzi14uIxEFqnyPV2c[QVDJLRlxNg127jMX(u"ࠧࡤࡱࡱࡸࡪࡾࡴࡠ࡯ࡨࡲࡺ࠭฀")]
					bSA4VODnfYzpRg25UokXcK6.append(Xh70Lzi14uIxEFqnyPV2c)
				ee8c0jzrTntGSUdRJm.setSetting(GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡷ࡫ࡦࡳࡧࡶ࡬ࠬก"),hWGMqtBy4wuLaVcj)
				if X3X4Y8RzxSVfZJUFDe==wwPrSDa21lUh(u"ࠩࡩࡳࡱࡪࡥࡳࠩข"): BxuD7iQRpW1(MM5Dx39f7ULhcJsRptzIowP,QVDJLRlxNg127jMX(u"ࠪࡑࡊࡔࡕࡔࡡࡆࡅࡈࡎࡅࡠࠩฃ")+lxMmbVO6gvQSthz1AFfe3IZPH9n2qW+QVDJLRlxNg127jMX(u"ࠫࡤ࠭ค")+Yeat7ZiMI2LgS,tDHVapfQdxX3LZeRh,bSA4VODnfYzpRg25UokXcK6,KqO5BWGQR9JVL)
			else: bSA4VODnfYzpRg25UokXcK6 = SV8JK1ZgPRWGLynsXYav0eu2F6zo
			if X3X4Y8RzxSVfZJUFDe==GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬฅ") and SaLcnMBU8Kp7qxYgzbeJROu!=QvgnCALNstmuUJiET(u"࠭࠮࠯ࠩฆ") and AMc08flqTCvhoLUpjrI2n1e54ux: QJieP0hZkz2slvKyn71OSto()
			ayWcYR1eLECFvV0f3NnlXOzK2 = pmGvcwCfA4La(tDHVapfQdxX3LZeRh,bSA4VODnfYzpRg25UokXcK6,G62uf8ZSIzBE,W5mewaZEsh,b9Vog0ysSGkHzAMZnarhJE2wFQmXq1)
	elif X3X4Y8RzxSVfZJUFDe==dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧง") and agkF7iSBOZ4DKJC25yztrsN86cXLfV not in [KBkxSYaz93pu1(u"ࠨࡔࡈࡊࡗࡋࡓࡉࡡࡆࡅࡈࡎࡅࠨจ")]+xLj46t2Qbi3dr8EgRDXmPMqpUwsvN and ztCUQ7Iy5pEhjTe:
		pMPR1Cc0usZ6nJTU(MM5Dx39f7ULhcJsRptzIowP,e2qDYgipPmTw4KvBLnochr(u"ࠩࡐࡉࡓ࡛ࡓࡠࡅࡄࡇࡍࡋ࡟ࠨฉ")+lxMmbVO6gvQSthz1AFfe3IZPH9n2qW+MMizeNH0AKu(u"ࠪࡣࠬช")+Yeat7ZiMI2LgS,tDHVapfQdxX3LZeRh)
	return ayWcYR1eLECFvV0f3NnlXOzK2,agkF7iSBOZ4DKJC25yztrsN86cXLfV,tDHVapfQdxX3LZeRh,SaLcnMBU8Kp7qxYgzbeJROu,AMc08flqTCvhoLUpjrI2n1e54ux,mUfTGE2JW7qdoz9PYnrptSNlc5i8,lxMmbVO6gvQSthz1AFfe3IZPH9n2qW,Yeat7ZiMI2LgS
def NNIPDxmKsnYpyA3jL27C6(X3X4Y8RzxSVfZJUFDe,wJUqaIAzvtsMSEZlKV,S6NALBOqGn1zi2W5M8y7,u2GRrQ0854,nWE8aO53lFfD,l7COkhRWD9uVS60Pte2NoyAaZn,XNBHzrlKD9yW,MH5c7Nekugx8O1AQjInRWyT64GV,SX7OT3VLGp2iQm,ahU9MCTwjqmOPsZnY6lLK73bvJ,Iq3U2AkJeVXgmwMi,N4NC8byh6KMgcj3):
	if Iq3U2AkJeVXgmwMi in [zyvJMtBhrw(u"ࠫ࠶࠭ซ"),GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠬ࠸ࠧฌ"),e2qDYgipPmTw4KvBLnochr(u"࠭࠳ࠨญ"),A6dMB1FlgxVivJ2fk9C(u"ࠧ࠵ࠩฎ"),EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠨ࠷ࠪฏ"),OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠩ࠴࠵ࠬฐ"),OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠪ࠵࠷࠭ฑ"),e2qDYgipPmTw4KvBLnochr(u"ࠫ࠶࠹ࠧฒ")] and N4NC8byh6KMgcj3:
		import jjGMocmUg2
		jjGMocmUg2.Lw8WcPiZ7u6jzh0(MH5c7Nekugx8O1AQjInRWyT64GV,Iq3U2AkJeVXgmwMi,N4NC8byh6KMgcj3)
		CfKNTtIi3OABbWcPpdF(fEXMiAyG3ql4vKB,i2tpOA6QzlfUByTSeKacWnV1)
	elif Iq3U2AkJeVXgmwMi==sULh4NjakzI8He7xJCMGrql(u"ࠬ࠼ࠧณ"):
		import yoY3NdGViS
		if N4NC8byh6KMgcj3==wwPrSDa21lUh(u"࠭ࡄࡐ࡙ࡑࡐࡔࡇࡄࠨด"): yoY3NdGViS.OnsAxhdVjZF(o1u5dij9UrcbXzVS8lwIWfKpnqM(u"๋ࠧำฯํࠥอไศ่อ฼ฬืࠧต"),EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠨฮสี๏ࠦแฮื้้ࠣ็ࠠศๆอั๊๐ไࠨถ"),HB5PvxRhwM=FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"࠲࠱࠲࠳Ꭲ"))
		elif N4NC8byh6KMgcj3==QvgnCALNstmuUJiET(u"ࠩࡇࡉࡑࡋࡔࡆࠩท"): JdgFHe3LwWc58G9TORuPr72bx4Ck(O9z5L3KtXqPEMepJQ0,fEXMiAyG3ql4vKB)
		N6NCYivtV4I5rEXq = yoY3NdGViS.lqvO2yUHs3ZQtxzGYFK(X3X4Y8RzxSVfZJUFDe,wJUqaIAzvtsMSEZlKV,S6NALBOqGn1zi2W5M8y7,ahU9MCTwjqmOPsZnY6lLK73bvJ,nWE8aO53lFfD,l7COkhRWD9uVS60Pte2NoyAaZn,XNBHzrlKD9yW,MH5c7Nekugx8O1AQjInRWyT64GV,SX7OT3VLGp2iQm)
		if N4NC8byh6KMgcj3==EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠪࡈࡔ࡝ࡎࡍࡑࡄࡈࠬธ"): Za2Eugh8Mp1eQYH4()
	elif MH5c7Nekugx8O1AQjInRWyT64GV==rwQN9AKhLCuMfHxjlbX0U(u"ࠫ࠼࠭น"):
		import W02GkD1ey4
		W02GkD1ey4.SnKDeXQwcj7UMkmtG8OpBz(gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠬࡥࡁࡍࡎࠪบ"))
		CfKNTtIi3OABbWcPpdF(fEXMiAyG3ql4vKB)
	elif MH5c7Nekugx8O1AQjInRWyT64GV==jeAby54c02TgG8zuivonX91(u"࠭࠸ࠨป"): MMk8qKvcJe4fQHm3EG7diBD5.executebuiltin(KNIvHPjUbhr(u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱࡙ࡵࡪࡡࡵࡧࠫࡴࡱࡻࡧࡪࡰ࠽࠳࠴࠭ผ")+nUy7x6dqmk92MPb+dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠨࡁࡰࡳࡩ࡫࠽ࠨฝ")+str(u2GRrQ0854)+e2qDYgipPmTw4KvBLnochr(u"ࠩࠩࡸࡾࡶࡥ࠾ࡨࡲࡰࡩ࡫ࡲࠪࠩพ"))
	elif MH5c7Nekugx8O1AQjInRWyT64GV==NeO3CTLHrPfWUoIgy8Q(u"ࠪ࠽ࠬฟ"):
		CfKNTtIi3OABbWcPpdF(VBlawK4mgHSyLEn8iqhUkz5)
	elif MH5c7Nekugx8O1AQjInRWyT64GV==o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠫ࠶࠶ࠧภ"):
		import W02GkD1ey4
		W02GkD1ey4.SnKDeXQwcj7UMkmtG8OpBz(JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠬࡥࡇࡐࡑࡊࡐࡊ࠭ม"))
		CfKNTtIi3OABbWcPpdF(fEXMiAyG3ql4vKB)
	elif MH5c7Nekugx8O1AQjInRWyT64GV==QvgnCALNstmuUJiET(u"࠭࠱࠵ࠩย"): CfKNTtIi3OABbWcPpdF(VBlawK4mgHSyLEn8iqhUkz5,MMizeNH0AKu(u"ࠧࡎࡇࡑ࡙ࡤࡘࡅࡗࡇࡕࡗࡊࡊ࡟ࡕࡇࡐࡔࠬร"))
	elif MH5c7Nekugx8O1AQjInRWyT64GV==LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠨ࠳࠸ࠫฤ"): CfKNTtIi3OABbWcPpdF(VBlawK4mgHSyLEn8iqhUkz5,DJ1ICpbyR2(u"ࠩࡐࡉࡓ࡛࡟ࡂࡕࡆࡉࡓࡊࡅࡅࡡࡗࡉࡒࡖࠧล"))
	elif MH5c7Nekugx8O1AQjInRWyT64GV==sULh4NjakzI8He7xJCMGrql(u"ࠪ࠵࠻࠭ฦ"): CfKNTtIi3OABbWcPpdF(VBlawK4mgHSyLEn8iqhUkz5,EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠫࡒࡋࡎࡖࡡࡇࡉࡘࡉࡅࡏࡆࡈࡈࡤ࡚ࡅࡎࡒࠪว"))
	elif MH5c7Nekugx8O1AQjInRWyT64GV==jeAby54c02TgG8zuivonX91(u"ࠬ࠷࠷ࠨศ"): CfKNTtIi3OABbWcPpdF(VBlawK4mgHSyLEn8iqhUkz5,zyvJMtBhrw(u"࠭ࡍࡆࡐࡘࡣࡗࡇࡎࡅࡑࡐࡍ࡟ࡋࡄࡠࡖࡈࡑࡕ࠭ษ"))
	if MH5c7Nekugx8O1AQjInRWyT64GV in [rwQN9AKhLCuMfHxjlbX0U(u"ࠧ࠺ࠩส"),JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠨ࠳࠷ࠫห"),CnbBKmtF1x84q7AW(u"ࠩ࠴࠹ࠬฬ"),OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠪ࠵࠻࠭อ"),LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠫ࠶࠽ࠧฮ")]: Za2Eugh8Mp1eQYH4()
	return
def LDqugTFOUPBKGadrixzSy9Z(X3X4Y8RzxSVfZJUFDe,wJUqaIAzvtsMSEZlKV,S6NALBOqGn1zi2W5M8y7,u2GRrQ0854,nWE8aO53lFfD,l7COkhRWD9uVS60Pte2NoyAaZn,XNBHzrlKD9yW,MH5c7Nekugx8O1AQjInRWyT64GV,SX7OT3VLGp2iQm,ahU9MCTwjqmOPsZnY6lLK73bvJ,Iq3U2AkJeVXgmwMi,N4NC8byh6KMgcj3,h4s5qao1CX):
	if Q9dmawtsE7unfZFyvzNVx5c1iL48CB: pXbZfBU7CYNkc5KTm()
	if MH5c7Nekugx8O1AQjInRWyT64GV: NNIPDxmKsnYpyA3jL27C6(X3X4Y8RzxSVfZJUFDe,wJUqaIAzvtsMSEZlKV,S6NALBOqGn1zi2W5M8y7,u2GRrQ0854,nWE8aO53lFfD,l7COkhRWD9uVS60Pte2NoyAaZn,XNBHzrlKD9yW,MH5c7Nekugx8O1AQjInRWyT64GV,SX7OT3VLGp2iQm,ahU9MCTwjqmOPsZnY6lLK73bvJ,Iq3U2AkJeVXgmwMi,N4NC8byh6KMgcj3)
	Gtp15S93F0lhbxcTCU7()
	UGjc2OeCnoIpEWk0zP(VBlawK4mgHSyLEn8iqhUkz5)
	G62uf8ZSIzBE,W5mewaZEsh,b9Vog0ysSGkHzAMZnarhJE2wFQmXq1 = VBlawK4mgHSyLEn8iqhUkz5,fEXMiAyG3ql4vKB,fEXMiAyG3ql4vKB
	A6FeGSDErPRyhcUm2vi53YjIxMfu = dmockO8CjZ9Wp2(X3X4Y8RzxSVfZJUFDe,wJUqaIAzvtsMSEZlKV,S6NALBOqGn1zi2W5M8y7,u2GRrQ0854,nWE8aO53lFfD,l7COkhRWD9uVS60Pte2NoyAaZn,XNBHzrlKD9yW,MH5c7Nekugx8O1AQjInRWyT64GV,SX7OT3VLGp2iQm,ahU9MCTwjqmOPsZnY6lLK73bvJ,h4s5qao1CX,G62uf8ZSIzBE,W5mewaZEsh,b9Vog0ysSGkHzAMZnarhJE2wFQmXq1)
	ayWcYR1eLECFvV0f3NnlXOzK2,agkF7iSBOZ4DKJC25yztrsN86cXLfV,tDHVapfQdxX3LZeRh,SaLcnMBU8Kp7qxYgzbeJROu,AMc08flqTCvhoLUpjrI2n1e54ux,mUfTGE2JW7qdoz9PYnrptSNlc5i8,lxMmbVO6gvQSthz1AFfe3IZPH9n2qW,Yeat7ZiMI2LgS = A6FeGSDErPRyhcUm2vi53YjIxMfu
	if ayWcYR1eLECFvV0f3NnlXOzK2: return
	if agkF7iSBOZ4DKJC25yztrsN86cXLfV==OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠬࡘࡅࡇࡔࡈࡗࡍࡥࡃࡂࡅࡋࡉࠬฯ"): bXjeBx6vV52PfJpcKah0kUGiSsWC(lke5D6CpaAXPdEZyrBSw7T)
	MewdQi3zF4maS9TZRopbA1hUI(HHoGx7Flus60(u"࠭ࡳࡵࡣࡵࡸࠬะ"))
	if ee8c0jzrTntGSUdRJm.getSetting(DJ1ICpbyR2(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱࡬ࡹࡺࡰࡤࡣࡦ࡬ࡪ࠭ั")) not in [DJ1ICpbyR2(u"ࠨࡃࡘࡘࡔ࠭า"),NeO3CTLHrPfWUoIgy8Q(u"ࠩࡖࡘࡔࡖࠧำ"),rwQN9AKhLCuMfHxjlbX0U(u"ࠪࡐࡎࡓࡉࡕࡇࡇࠫิ")]:
		ee8c0jzrTntGSUdRJm.setSetting(wwPrSDa21lUh(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡩࡶࡷࡴࡨࡧࡣࡩࡧࠪี"),GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠬࡇࡕࡕࡑࠪึ"))
	if not ee8c0jzrTntGSUdRJm.getSetting(LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"࠭ࡡࡷ࠰ࡧࡲࡸ࠭ื")): ee8c0jzrTntGSUdRJm.setSetting(GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠧࡢࡸ࠱ࡨࡳࡹุࠧ"),vIDJ3z8NTlStsfnW4MOQC20Bo[ybdv7XcT3lxF6QezULwCAGk])
	N6NCYivtV4I5rEXq = lqvO2yUHs3ZQtxzGYFK(X3X4Y8RzxSVfZJUFDe,wJUqaIAzvtsMSEZlKV,S6NALBOqGn1zi2W5M8y7,u2GRrQ0854,nWE8aO53lFfD,l7COkhRWD9uVS60Pte2NoyAaZn,XNBHzrlKD9yW,MH5c7Nekugx8O1AQjInRWyT64GV,SX7OT3VLGp2iQm)
	if NeO3CTLHrPfWUoIgy8Q(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡูࠪ") in XNBHzrlKD9yW: W5mewaZEsh = VBlawK4mgHSyLEn8iqhUkz5
	if X3X4Y8RzxSVfZJUFDe==KBkxSYaz93pu1(u"ࠩࡩࡳࡱࡪࡥࡳฺࠩ"):
		if SaLcnMBU8Kp7qxYgzbeJROu!=OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠪ࠲࠳࠭฻") and AMc08flqTCvhoLUpjrI2n1e54ux: QJieP0hZkz2slvKyn71OSto()
		if l95lLYCJweSnVHqzrstyPWcE>-bXukYxQ4aHw:
			WWGEN6lshOZ = [ybdv7XcT3lxF6QezULwCAGk,LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"࠳࠸Ꭴ"),zyvJMtBhrw(u"࠴࠻Ꭵ"),EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"࠵࠾Ꭶ"),DJ1ICpbyR2(u"࠳࠸Ꭳ"),DJ1ICpbyR2(u"࠳࠵Ꭹ"),LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"࠺࠶Ꭷ"),A6dMB1FlgxVivJ2fk9C(u"࠻࠳Ꭸ")]
			if (Mqk51CFBym0pIQXZLsOxSJ(MM5Dx39f7ULhcJsRptzIowP,ITvnUAMXsyb4eO(u"ࠫ࡮ࡴࡴࠨ฼"),xcChIL13BpR8WArNt9Pl0So(u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨ฽"),XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"࠭ࡓࡊࡖࡈࡗࡤࡔࡁࡎࡇࡖࠫ฾")) or ahU9MCTwjqmOPsZnY6lLK73bvJ not in WWGEN6lshOZ) and not MmcgqAlsFt.j0juxvCpdOFDk2:
				from PPEqJVcZfd import eepKVQRXIOnhoA
				SV8JK1ZgPRWGLynsXYav0eu2F6zo = uE9HfdgDLMS0CbBWNp8wk1smlTo(eepKVQRXIOnhoA)
				ayWcYR1eLECFvV0f3NnlXOzK2 = pmGvcwCfA4La(tDHVapfQdxX3LZeRh,SV8JK1ZgPRWGLynsXYav0eu2F6zo,G62uf8ZSIzBE,W5mewaZEsh,b9Vog0ysSGkHzAMZnarhJE2wFQmXq1)
				if SV8JK1ZgPRWGLynsXYav0eu2F6zo and mUfTGE2JW7qdoz9PYnrptSNlc5i8:
					BxuD7iQRpW1(MM5Dx39f7ULhcJsRptzIowP,jeAby54c02TgG8zuivonX91(u"ࠧࡎࡇࡑ࡙ࡘࡥࡃࡂࡅࡋࡉࡤ࠭฿")+lxMmbVO6gvQSthz1AFfe3IZPH9n2qW+DJ1ICpbyR2(u"ࠨࡡࠪเ")+Yeat7ZiMI2LgS,tDHVapfQdxX3LZeRh,SV8JK1ZgPRWGLynsXYav0eu2F6zo,KqO5BWGQR9JVL)
			else:
				u6sYmx5Dtz.addDirectoryItem(l95lLYCJweSnVHqzrstyPWcE,S1SgCFYGJeMvfp5iZXK(u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠬแ")+nUy7x6dqmk92MPb+gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠪ࠳ࡄࡺࡹࡱࡧࡀࡰ࡮ࡴ࡫ࠧ࡯ࡲࡨࡪࡃ࠵࠱࠲ࠪโ"),mUWYiQ2jHICA8cD6LhPTn3wpB1XyK.ListItem(HHoGx7Flus60(u"้ࠫี๊ไุ่่๊ࠢษࠡ็้ࠤัํวำๅࠪใ")))
				u6sYmx5Dtz.addDirectoryItem(l95lLYCJweSnVHqzrstyPWcE,S1SgCFYGJeMvfp5iZXK(u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠨไ")+nUy7x6dqmk92MPb+o1u5dij9UrcbXzVS8lwIWfKpnqM(u"࠭࠯ࡀࡶࡼࡴࡪࡃ࡬ࡪࡰ࡮ࠪࡲࡵࡤࡦ࠿࠸࠴࠵࠭ๅ"),mUWYiQ2jHICA8cD6LhPTn3wpB1XyK.ListItem(DJ1ICpbyR2(u"ࠧฤใอั๊ࠥสใำฦࠤฬ๊สโษุ๎้࠭ๆ")))
			u6sYmx5Dtz.endOfDirectory(l95lLYCJweSnVHqzrstyPWcE,G62uf8ZSIzBE,W5mewaZEsh,b9Vog0ysSGkHzAMZnarhJE2wFQmXq1)
	return
def bXjeBx6vV52PfJpcKah0kUGiSsWC(jKR4Q9y6E21Plz8Lcai3Cb0JZTudeW):
	if JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠨࡏࡈࡗࡘࡇࡇࡆࡕࠪ็") in iO1SgmkzGYaFoPXbfdj3NxQBus or rwQN9AKhLCuMfHxjlbX0U(u"ࠩࡐࡉࡘ࡙ࡁࡈࡇࡖࡣ่࡙࡙ࠧ") in iO1SgmkzGYaFoPXbfdj3NxQBus: return
	jj6R7OLExzA2G3lK = fEXMiAyG3ql4vKB if jKR4Q9y6E21Plz8Lcai3Cb0JZTudeW else VBlawK4mgHSyLEn8iqhUkz5
	if not jj6R7OLExzA2G3lK:
		UPYqBrv2pQfKSC57iDG1yHjo6w0Jd = ssYJQiWrZIRqkMe(ee8c0jzrTntGSUdRJm.getSetting(LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰ࡰࡩࡸࡹࡡࡨࡧࡶ้ࠫ")))
		UPYqBrv2pQfKSC57iDG1yHjo6w0Jd = ybdv7XcT3lxF6QezULwCAGk if not UPYqBrv2pQfKSC57iDG1yHjo6w0Jd else int(UPYqBrv2pQfKSC57iDG1yHjo6w0Jd)
		if not UPYqBrv2pQfKSC57iDG1yHjo6w0Jd or not ybdv7XcT3lxF6QezULwCAGk<=IHKJoQ8PwW4pNBR6GTAMVz2hdfC5my-UPYqBrv2pQfKSC57iDG1yHjo6w0Jd<=jKR4Q9y6E21Plz8Lcai3Cb0JZTudeW: jj6R7OLExzA2G3lK = VBlawK4mgHSyLEn8iqhUkz5
	if not jj6R7OLExzA2G3lK:
		oHUeVl15EnCP9Od8 = ee8c0jzrTntGSUdRJm.getSetting(o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮࡮ࡧࡶࡷࡦ࡭ࡥࡴ๊ࠩ"))
		if oHUeVl15EnCP9Od8 in [hWGMqtBy4wuLaVcj,HHoGx7Flus60(u"ࠬࡕࡌࡅࡡࡗࡓࡤࡋࡒࡓࡑࡕ๋ࠫ"),NeO3CTLHrPfWUoIgy8Q(u"࠭ࡎࡆ࡙ࡢࡘࡔࡥࡅࡓࡔࡒࡖࠬ์")]: jj6R7OLExzA2G3lK = VBlawK4mgHSyLEn8iqhUkz5
	if not jj6R7OLExzA2G3lK:
		nWFqsv6MlOwSd5trg3T4mfQ2Rk8a = ee8c0jzrTntGSUdRJm.getSetting(SqrG5mU3j96ldsFpExobw40TJY(u"ࠧࡢࡸ࠱ࡴࡷ࡯ࡶࡴ࠳ࠪํ"))
		ZvqSeWL1wAcgO9Fony0Y = ee8c0jzrTntGSUdRJm.getSetting(SqrG5mU3j96ldsFpExobw40TJY(u"ࠨࡣࡹ࠲ࡵࡸࡩࡷࡵ࠵ࠫ๎"))
		rKp8WYSPBV3 = xcRlSgBrOhKz69LNou0f8D5MVem.md5(GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"࠶Ꭺ")*nWFqsv6MlOwSd5trg3T4mfQ2Rk8a.encode(a7VXeDU82IfQEnPZAdiT)).hexdigest()
		rKp8WYSPBV3 = xcRlSgBrOhKz69LNou0f8D5MVem.md5(gDuGMR3z1aV6YdLmCpiO8Kl(u"࠳࠷Ꭻ")*rKp8WYSPBV3.encode(a7VXeDU82IfQEnPZAdiT)).hexdigest()
		rKp8WYSPBV3 = xcRlSgBrOhKz69LNou0f8D5MVem.md5(hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"࠴࠽Ꭼ")*rKp8WYSPBV3.encode(a7VXeDU82IfQEnPZAdiT)).hexdigest()
		if rKp8WYSPBV3!=ZvqSeWL1wAcgO9Fony0Y: jj6R7OLExzA2G3lK = VBlawK4mgHSyLEn8iqhUkz5
	if jj6R7OLExzA2G3lK: O8JQEp4eTc93zX5RUAnag6K(fEXMiAyG3ql4vKB)
	return
def lqvO2yUHs3ZQtxzGYFK(X3X4Y8RzxSVfZJUFDe,wJUqaIAzvtsMSEZlKV,S6NALBOqGn1zi2W5M8y7,u2GRrQ0854,nWE8aO53lFfD,l7COkhRWD9uVS60Pte2NoyAaZn,XNBHzrlKD9yW,MH5c7Nekugx8O1AQjInRWyT64GV,SX7OT3VLGp2iQm):
	ahU9MCTwjqmOPsZnY6lLK73bvJ = int(u2GRrQ0854)
	DASrslYGWIQwxjOdu0eN368o = int(ahU9MCTwjqmOPsZnY6lLK73bvJ//NeO3CTLHrPfWUoIgy8Q(u"࠵࠵Ꭽ"))
	if   DASrslYGWIQwxjOdu0eN368o==ybdv7XcT3lxF6QezULwCAGk:  from ZGYSlz63X1 		import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==bXukYxQ4aHw:  from Ae3wOYF2i9 		import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==Y0XZKGRAUQj5O:  from mSb0zlth7R 		import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,l7COkhRWD9uVS60Pte2NoyAaZn,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==x1x9kIQo3zjZWnYaiy:  from UgZkz8fqRY 		import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,l7COkhRWD9uVS60Pte2NoyAaZn,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==jR6BYWNFZ0egmH4Tr2Q78LbSs3t:  from Fa2eEo4S9J 		import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW,l7COkhRWD9uVS60Pte2NoyAaZn)
	elif DASrslYGWIQwxjOdu0eN368o==ITvnUAMXsyb4eO(u"࠺Ꭾ"):  from mmJPZwCVK4 		import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"࠼Ꭿ"):  from p7pov5YVL9 		import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==dv0trJR7PwmKyxDYO52VLau8gEph(u"࠷Ꮀ"):  from ppotHCQbEN 			import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==MMizeNH0AKu(u"࠹Ꮁ"):  from LnsdUMcbE1 		import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==KBkxSYaz93pu1(u"࠻Ꮂ"):  from MdvaXFz729		import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==HHoGx7Flus60(u"࠴࠴Ꮃ"): from cExDXrt5fI 		import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7)
	elif DASrslYGWIQwxjOdu0eN368o==QVDJLRlxNg127jMX(u"࠵࠶Ꮄ"): from EEHXBdaKUy 		import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==S1SgCFYGJeMvfp5iZXK(u"࠶࠸Ꮅ"): from yIhj3FvGAO 		import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,l7COkhRWD9uVS60Pte2NoyAaZn,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"࠷࠳Ꮆ"): from bjghZzTf0c		import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,l7COkhRWD9uVS60Pte2NoyAaZn,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==zyvJMtBhrw(u"࠱࠵Ꮇ"): from vgu7JcpdwP 		import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW,X3X4Y8RzxSVfZJUFDe,l7COkhRWD9uVS60Pte2NoyAaZn,wJUqaIAzvtsMSEZlKV,nWE8aO53lFfD)
	elif DASrslYGWIQwxjOdu0eN368o==mkHKSQvjWr5BTcM3wVY(u"࠲࠷Ꮈ"): from ZGYSlz63X1 		import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==gDuGMR3z1aV6YdLmCpiO8Kl(u"࠳࠹Ꮉ"): from ej38lDurcg		import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW,l7COkhRWD9uVS60Pte2NoyAaZn,SX7OT3VLGp2iQm)
	elif DASrslYGWIQwxjOdu0eN368o==KNIvHPjUbhr(u"࠴࠻Ꮊ"): from ZGYSlz63X1 		import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==S1SgCFYGJeMvfp5iZXK(u"࠵࠽Ꮋ"): from mnB8kh1M4J		import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==S1SgCFYGJeMvfp5iZXK(u"࠶࠿Ꮌ"): from ZGYSlz63X1 		import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==wwPrSDa21lUh(u"࠸࠰Ꮍ"): from Qtvgrsi4mV		import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==QVDJLRlxNg127jMX(u"࠲࠲Ꮎ"): from J3Xz2NGLxf	import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==wwPrSDa21lUh(u"࠳࠴Ꮏ"): from fOvPaV1Iez		import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,l7COkhRWD9uVS60Pte2NoyAaZn,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==zyvJMtBhrw(u"࠴࠶Ꮐ"): from t2YzocLAmj			import GwmTvrCi2VudfPSOq0x; N6NCYivtV4I5rEXq = GwmTvrCi2VudfPSOq0x(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW,X3X4Y8RzxSVfZJUFDe,l7COkhRWD9uVS60Pte2NoyAaZn,SX7OT3VLGp2iQm)
	elif DASrslYGWIQwxjOdu0eN368o==MMizeNH0AKu(u"࠵࠸Ꮑ"): from rrg9LDpKux 			import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==rwQN9AKhLCuMfHxjlbX0U(u"࠶࠺Ꮒ"): from WW2cFhXPaH 		import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==DJ1ICpbyR2(u"࠷࠼Ꮓ"): from PPEqJVcZfd 			import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==QvgnCALNstmuUJiET(u"࠸࠷Ꮔ"): from jjGMocmUg2		import GwmTvrCi2VudfPSOq0x; N6NCYivtV4I5rEXq = GwmTvrCi2VudfPSOq0x(ahU9MCTwjqmOPsZnY6lLK73bvJ,MH5c7Nekugx8O1AQjInRWyT64GV)
	elif DASrslYGWIQwxjOdu0eN368o==SqrG5mU3j96ldsFpExobw40TJY(u"࠲࠹Ꮕ"): from t2YzocLAmj			import GwmTvrCi2VudfPSOq0x; N6NCYivtV4I5rEXq = GwmTvrCi2VudfPSOq0x(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW,X3X4Y8RzxSVfZJUFDe,l7COkhRWD9uVS60Pte2NoyAaZn,SX7OT3VLGp2iQm)
	elif DASrslYGWIQwxjOdu0eN368o==LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"࠳࠻Ꮖ"): from lBJh4iO8aI	import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,l7COkhRWD9uVS60Pte2NoyAaZn,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"࠵࠳Ꮗ"): from QvHhfzTkoM		import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"࠶࠵Ꮘ"): from pWPojqC3cH		import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==rwQN9AKhLCuMfHxjlbX0U(u"࠷࠷Ꮙ"): from ssoDU5VCYK		import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==gDuGMR3z1aV6YdLmCpiO8Kl(u"࠸࠹Ꮚ"): from fJl3RLyKjw		import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7)
	elif DASrslYGWIQwxjOdu0eN368o==dv0trJR7PwmKyxDYO52VLau8gEph(u"࠹࠴Ꮛ"): from ZGYSlz63X1 		import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==DJ1ICpbyR2(u"࠳࠶Ꮜ"): from LezUiM6xTS		import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==SqrG5mU3j96ldsFpExobw40TJY(u"࠴࠸Ꮝ"): from yuDxW8TmPU			import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==S1SgCFYGJeMvfp5iZXK(u"࠵࠺Ꮞ"): from UN2CkoBwZe			import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==SqrG5mU3j96ldsFpExobw40TJY(u"࠶࠼Ꮟ"): from N2yYhKoErg 		import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==sULh4NjakzI8He7xJCMGrql(u"࠷࠾Ꮠ"): from rrhQGPlFcs		import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==xcChIL13BpR8WArNt9Pl0So(u"࠹࠶Ꮡ"): from KaPoYWIB1b	import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW,X3X4Y8RzxSVfZJUFDe,l7COkhRWD9uVS60Pte2NoyAaZn)
	elif DASrslYGWIQwxjOdu0eN368o==hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"࠺࠱Ꮢ"): from KaPoYWIB1b	import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW,X3X4Y8RzxSVfZJUFDe,l7COkhRWD9uVS60Pte2NoyAaZn)
	elif DASrslYGWIQwxjOdu0eN368o==sULh4NjakzI8He7xJCMGrql(u"࠴࠳Ꮣ"): from iiYkxqCpdD			import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==ITvnUAMXsyb4eO(u"࠵࠵Ꮤ"): from R3Ok4zXioW			import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==o1u5dij9UrcbXzVS8lwIWfKpnqM(u"࠶࠷Ꮥ"): from rTyhA5HbqP		import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==rwQN9AKhLCuMfHxjlbX0U(u"࠷࠹Ꮦ"): from OelsqxmGvT		import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"࠸࠻Ꮧ"): from I8hFklrG4o			import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"࠹࠽Ꮨ"): from RRDSYVUTXZ		import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==rwQN9AKhLCuMfHxjlbX0U(u"࠺࠸Ꮩ"): from ZvTkQpmwgn		import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==dv0trJR7PwmKyxDYO52VLau8gEph(u"࠴࠺Ꮪ"): from gfjYczHh48		import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"࠶࠲Ꮫ"): from ZGYSlz63X1 		import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==o1u5dij9UrcbXzVS8lwIWfKpnqM(u"࠷࠴Ꮬ"): from N64dz0xtRK 		import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==QvgnCALNstmuUJiET(u"࠸࠶Ꮭ"): from N64dz0xtRK 		import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==jeAby54c02TgG8zuivonX91(u"࠹࠸Ꮮ"): from PPEqJVcZfd 			import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"࠺࠺Ꮯ"): from W02GkD1ey4	import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW,l7COkhRWD9uVS60Pte2NoyAaZn)
	elif DASrslYGWIQwxjOdu0eN368o==SqrG5mU3j96ldsFpExobw40TJY(u"࠻࠵Ꮰ"): from SgYBRznWJk 		import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==wwPrSDa21lUh(u"࠵࠷Ꮱ"): from G6MaRNF03P		import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==xcChIL13BpR8WArNt9Pl0So(u"࠶࠹Ꮲ"): from qZLioIBnmS		import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==HHoGx7Flus60(u"࠷࠻Ꮳ"): from aLWj7Pi04r		import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==jeAby54c02TgG8zuivonX91(u"࠸࠽Ꮴ"): from FN4qQbOexB		import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==dv0trJR7PwmKyxDYO52VLau8gEph(u"࠺࠵Ꮵ"): from w7ZXtJMzx6			import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==SqrG5mU3j96ldsFpExobw40TJY(u"࠻࠷Ꮶ"): from pKDY172QWZ			import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==jeAby54c02TgG8zuivonX91(u"࠼࠲Ꮷ"): from foejGdvkDJ		import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==mkHKSQvjWr5BTcM3wVY(u"࠶࠴Ꮸ"): from EEWqhiFTue	import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==zyvJMtBhrw(u"࠷࠶Ꮹ"): from RRDrAEy29i			import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==DJ1ICpbyR2(u"࠸࠸Ꮺ"): from lov2yxN1tT			import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==S1SgCFYGJeMvfp5iZXK(u"࠹࠺Ꮻ"): from RRGNzFoi7f			import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==xcChIL13BpR8WArNt9Pl0So(u"࠺࠼Ꮼ"): from NfoRzjxBK0		import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"࠻࠾Ꮽ"): from E5HZz8RP0h		import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==zyvJMtBhrw(u"࠼࠹Ꮾ"): from vHtyTdOp6l		import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==SqrG5mU3j96ldsFpExobw40TJY(u"࠷࠱Ꮿ"): from sqQzra8NCR			import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==QvgnCALNstmuUJiET(u"࠸࠳Ᏸ"): from llfcJ30oFC			import GwmTvrCi2VudfPSOq0x; N6NCYivtV4I5rEXq = GwmTvrCi2VudfPSOq0x(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW,X3X4Y8RzxSVfZJUFDe,l7COkhRWD9uVS60Pte2NoyAaZn,SX7OT3VLGp2iQm)
	elif DASrslYGWIQwxjOdu0eN368o==LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"࠹࠵Ᏹ"): from llfcJ30oFC			import GwmTvrCi2VudfPSOq0x; N6NCYivtV4I5rEXq = GwmTvrCi2VudfPSOq0x(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW,X3X4Y8RzxSVfZJUFDe,l7COkhRWD9uVS60Pte2NoyAaZn,SX7OT3VLGp2iQm)
	elif DASrslYGWIQwxjOdu0eN368o==A6dMB1FlgxVivJ2fk9C(u"࠺࠷Ᏺ"): from xwIpWjhr3M	import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==A6dMB1FlgxVivJ2fk9C(u"࠻࠹Ᏻ"): from r8kFBva4UP		import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ)
	elif DASrslYGWIQwxjOdu0eN368o==o1u5dij9UrcbXzVS8lwIWfKpnqM(u"࠼࠻Ᏼ"): from r8kFBva4UP		import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ)
	elif DASrslYGWIQwxjOdu0eN368o==HHoGx7Flus60(u"࠽࠶Ᏽ"): from ej38lDurcg		import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW,l7COkhRWD9uVS60Pte2NoyAaZn,SX7OT3VLGp2iQm)
	elif DASrslYGWIQwxjOdu0eN368o==CnbBKmtF1x84q7AW(u"࠷࠸᏶"): from Ojbi3BT8p2 		import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,l7COkhRWD9uVS60Pte2NoyAaZn,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==A6dMB1FlgxVivJ2fk9C(u"࠸࠺᏷"): from b0brqMUFiE 		import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,l7COkhRWD9uVS60Pte2NoyAaZn,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==mkHKSQvjWr5BTcM3wVY(u"࠹࠼ᏸ"): from CtRiO8neuX 		import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,l7COkhRWD9uVS60Pte2NoyAaZn,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==KBkxSYaz93pu1(u"࠻࠴ᏹ"): from jwnTvOI7lZ 		import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,l7COkhRWD9uVS60Pte2NoyAaZn,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==o1u5dij9UrcbXzVS8lwIWfKpnqM(u"࠼࠶ᏺ"): from phOvqEnMQ6 		import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"࠽࠸ᏻ"): from n6xPM2Olgc		import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,l7COkhRWD9uVS60Pte2NoyAaZn,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==sULh4NjakzI8He7xJCMGrql(u"࠾࠳ᏼ"): from H1xaqgTriF		import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"࠸࠵ᏽ"): from oIWgitFG6O		import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==HHoGx7Flus60(u"࠹࠷᏾"): from PNvhBGumD2		import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==xcChIL13BpR8WArNt9Pl0So(u"࠺࠹᏿"): from rz0JjOH9Pc		import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==o1u5dij9UrcbXzVS8lwIWfKpnqM(u"࠻࠻᐀"): from Xutmsgp8e4			import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==jeAby54c02TgG8zuivonX91(u"࠼࠽ᐁ"): from SqMfJo0ztI			import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==MMizeNH0AKu(u"࠽࠿ᐂ"): from FkGWI3gDLa		import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==o1u5dij9UrcbXzVS8lwIWfKpnqM(u"࠿࠰ᐃ"): from CRtGZ78qjP	import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"࠹࠲ᐄ"): from FmvTYZn0qx		import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==DJ1ICpbyR2(u"࠺࠴ᐅ"): from CeysAphKI3		import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==KBkxSYaz93pu1(u"࠻࠶ᐆ"): from hSqClboQNY		import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"࠼࠸ᐇ"): from jK3sV6LWGX			import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"࠽࠺ᐈ"): from A4AbDczUxm			import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==S1SgCFYGJeMvfp5iZXK(u"࠾࠼ᐉ"): from bXIhFxgaS3		import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"࠿࠷ᐊ"): from Emt50CqprJ		import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"࠹࠹ᐋ"): from YYt6vwDOTs		import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==dv0trJR7PwmKyxDYO52VLau8gEph(u"࠺࠻ᐌ"): from xxQlPRrD2v		import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==e2qDYgipPmTw4KvBLnochr(u"࠳࠳࠴ᐍ"): from jSxyTUJcYz		import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==SqrG5mU3j96ldsFpExobw40TJY(u"࠴࠴࠶ᐎ"): from xTJfnd8roE	import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==jeAby54c02TgG8zuivonX91(u"࠵࠵࠸ᐏ"): from ZGYSlz63X1 		import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==KNIvHPjUbhr(u"࠶࠶࠳ᐐ"): from j9JzCRpomK	import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==DJ1ICpbyR2(u"࠷࠰࠵ᐑ"): from t8HgZ2C9Ke		import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"࠱࠱࠷ᐒ"): from sH0dnxVKFJ			import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"࠲࠲࠹ᐓ"): from GKjdANXSik		import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW)
	elif DASrslYGWIQwxjOdu0eN368o==A6dMB1FlgxVivJ2fk9C(u"࠳࠳࠻ᐔ"): from HBlgtOU8y4		import ehB18u9sQFRi	; N6NCYivtV4I5rEXq = ehB18u9sQFRi(ahU9MCTwjqmOPsZnY6lLK73bvJ,S6NALBOqGn1zi2W5M8y7,XNBHzrlKD9yW)
	else: N6NCYivtV4I5rEXq = None
	return N6NCYivtV4I5rEXq
def VEx8ogwsaZTLQpP4ctHXiCr0DNY9y(kw6Zs29tznG0CFIUWxOh7qeH,jZyzn8MtORbaeCW,dUWFtBQ3cpoIZ9,showDialogs):
	ITlpOFqLn7W2hYkdijCogm = dUWFtBQ3cpoIZ9.split(gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠩ࠰ࠫ๏"),bXukYxQ4aHw)[ybdv7XcT3lxF6QezULwCAGk] if DJ1ICpbyR2(u"ࠪ࠱ࠬ๐") in dUWFtBQ3cpoIZ9 else dUWFtBQ3cpoIZ9
	if not showDialogs or dUWFtBQ3cpoIZ9 in IYkLXVOJe2: return fEXMiAyG3ql4vKB
	ZZdrzYJuScnhwiApxV = ee8c0jzrTntGSUdRJm.getSetting(o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠫࡦࡼ࠮࡭ࡣࡱ࡫ࡺࡧࡧࡦ࠰ࡷࡶࡦࡴࡳ࡭ࡣࡷࡩࠬ๑"))
	ee8c0jzrTntGSUdRJm.setSetting(ITvnUAMXsyb4eO(u"ࠬࡧࡶ࠯࡮ࡤࡲ࡬ࡻࡡࡨࡧ࠱ࡸࡷࡧ࡮ࡴ࡮ࡤࡸࡪ࠭๒"),hWGMqtBy4wuLaVcj)
	AAN381c4rSodxZ5zqhEvD = kw6Zs29tznG0CFIUWxOh7qeH in [GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"࠽ᐘ"),KNIvHPjUbhr(u"࠵࠶࠶࠰࠲ᐖ"),A6dMB1FlgxVivJ2fk9C(u"࠴࠵࠵࠶࠲ᐕ"),MMizeNH0AKu(u"࠶࠶࠰࠶࠶ᐗ")]
	IAsdxLOWYJFcmnh1BryVgv4Ro = jZyzn8MtORbaeCW.lower()
	dALmR1bhyIKBneG6zS = kw6Zs29tznG0CFIUWxOh7qeH in [ybdv7XcT3lxF6QezULwCAGk,LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"࠳࠳࠸ᐛ"),dv0trJR7PwmKyxDYO52VLau8gEph(u"࠱࠱࠲࠹࠵ᐙ"),o1u5dij9UrcbXzVS8lwIWfKpnqM(u"࠲࠳࠴ᐚ")]
	lTbpzL8DM1gs5ehw7ixG = KNIvHPjUbhr(u"࠭ࡢ࡭ࡱࡦ࡯ࡪࡪࠠࡣࡻࠣࡧࡱࡵࡵࡥࡨ࡯ࡥࡷ࡫ࠧ๓") in IAsdxLOWYJFcmnh1BryVgv4Ro
	eKTbRfrL7Xa825sYNpkxQ3wcF = xcChIL13BpR8WArNt9Pl0So(u"ࠧࡣ࡮ࡲࡧࡰ࡫ࡤࠡࡤࡼࠤ࠺ࠦࡳࡦࡥࡲࡲࡩࡹࠠࡣࡴࡲࡻࡸ࡫ࡲࠡࡥ࡫ࡩࡨࡱࠧ๔") in IAsdxLOWYJFcmnh1BryVgv4Ro
	GHSCMzcWKquohFjNm7D2Z = KBkxSYaz93pu1(u"ࠨࡤ࡯ࡳࡨࡱࡥࡥࠢࡥࡽࠥࡸࡥࡤࡣࡳࡸࡨ࡮ࡡࠨ๕") in IAsdxLOWYJFcmnh1BryVgv4Ro
	sZrF8Iox7vyQt5 = LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠩࡥࡰࡴࡩ࡫ࡦࡦࠣࡦࡾࠦࡣ࡭ࡱࡸࡨ࡫ࡲࡡࡳࡧࠣࡷࡪࡩࡵࡳ࡫ࡷࡽࠥࡩࡨࡦࡥ࡮ࠫ๖") in IAsdxLOWYJFcmnh1BryVgv4Ro
	QbqvPf5AKC9wS6goxtZFs21H = ee8c0jzrTntGSUdRJm.getSetting(sULh4NjakzI8He7xJCMGrql(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡵࡴࡧࡳࡶࡴࡾࡹࠨ๗"))
	iN41e5cDBwxtX9OhmYUvPJdfLb = ee8c0jzrTntGSUdRJm.getSetting(zyvJMtBhrw(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡵࡨࡨࡳࡹࠧ๘"))
	kEn3uhiqsroU8e5GjObvzw = dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠬ็ิๅࠢไ๎ูࠥอษࠢสฺ่็อส่๊ࠢࠥอไฦ่อี๋ะࠧ๙")
	dbTxZP5Fnclzef4Y97 = OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"࠭ࡅࡳࡴࡲࡶࠥ࠭๚")+str(kw6Zs29tznG0CFIUWxOh7qeH)+CnbBKmtF1x84q7AW(u"ࠧ࠻ࠢࠪ๛")+jZyzn8MtORbaeCW
	dbTxZP5Fnclzef4Y97 = jkiCS0UWs2dNAJcGKn6mbHD(dbTxZP5Fnclzef4Y97)
	if dALmR1bhyIKBneG6zS or lTbpzL8DM1gs5ehw7ixG or eKTbRfrL7Xa825sYNpkxQ3wcF or GHSCMzcWKquohFjNm7D2Z or sZrF8Iox7vyQt5: kEn3uhiqsroU8e5GjObvzw += ITvnUAMXsyb4eO(u"ࠨࠢ࠱ࠤฬ๊ๅ้ไ฼ࠤๆ๐็ࠡฯฯฬࠥ฼ฯࠡๅ๋ำ๏ࠦๅึัิ๋ࠥอไฦ่อี๋ะࠠศๆัหฺࠦศไࠢฦ์ࠥฮวๅ็๋ๆ฾ࡢ࡮ࠨ๜")
	if AAN381c4rSodxZ5zqhEvD: kEn3uhiqsroU8e5GjObvzw += OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠩࠣ࠲๊ࠥฯ๋ๅࠣา฼ษࠠࡅࡐࡖࠤํู๋็ษ๊ࠤฯ฿ะาࠢอีั๋ษࠡษึ้ࠥอไๆ๊ๅ฽ࠥหไ๊ࠢิๆ๊ํ࡜࡯ࠩ๝")
	dbTxZP5Fnclzef4Y97 = NXMOzZjYsmS9pf+hXB0vKVQ5PRI91SDTprMdfuHEm4+dbTxZP5Fnclzef4Y97+YYSh2J6BIrsm8
	if QbqvPf5AKC9wS6goxtZFs21H==gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠪࡅࡘࡑࠧ๞") or iN41e5cDBwxtX9OhmYUvPJdfLb==JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠫࡆ࡙ࡋࠨ๟"):
		kEn3uhiqsroU8e5GjObvzw += NXMOzZjYsmS9pf+soMVfbr6WtpNlcSA+o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠬํไࠡฬิ๎ิࠦร็ࠢํัฬ๎ไࠡษ็ฬึ์วๆฮࠣษฺ๊วฮࠢสฺ่๊ใๅหࠣ࠲࠳ࠦรๆࠢอี๏ีࠠฦำึห้ࠦัิษ็อࠥษ่ࠡะฺวࠥหไ๊ࠢส่๊ฮัๆฮࠣรࠦࠧࠧ๠")+YYSh2J6BIrsm8
	r5jmTKLnJvstRoIdDz3i8BNVGH = fEXMiAyG3ql4vKB
	if QbqvPf5AKC9wS6goxtZFs21H==o1u5dij9UrcbXzVS8lwIWfKpnqM(u"࠭ࡁࡔࡍࠪ๡") or iN41e5cDBwxtX9OhmYUvPJdfLb==KNIvHPjUbhr(u"ࠧࡂࡕࡎࠫ๢"):
		c7doTBkbPWtIsGlgeFa58f = jbQkTyxAerZR409gYFq(MMizeNH0AKu(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ๣"),sULh4NjakzI8He7xJCMGrql(u"ࠩัีําࠧ๤"),QvgnCALNstmuUJiET(u"ࠪษึูวๅࠢ็่๊ฮัๆฮࠪ๥"),CnbBKmtF1x84q7AW(u"ࠫฯ฻ไ๋ฯࠣห้๋ิไๆฬࠫ๦"),ITlpOFqLn7W2hYkdijCogm+lG0yV5QNFHc2RbXM1Wp+J72F0jRI6A(ITlpOFqLn7W2hYkdijCogm),kEn3uhiqsroU8e5GjObvzw+NXMOzZjYsmS9pf+dbTxZP5Fnclzef4Y97)
		if c7doTBkbPWtIsGlgeFa58f==bXukYxQ4aHw:
			from ZGYSlz63X1 import mag0BJDLNYjc1iKkpl8
			mag0BJDLNYjc1iKkpl8()
		elif c7doTBkbPWtIsGlgeFa58f==Y0XZKGRAUQj5O: r5jmTKLnJvstRoIdDz3i8BNVGH = VBlawK4mgHSyLEn8iqhUkz5
	else: BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,ITlpOFqLn7W2hYkdijCogm+lG0yV5QNFHc2RbXM1Wp+J72F0jRI6A(ITlpOFqLn7W2hYkdijCogm),kEn3uhiqsroU8e5GjObvzw,dbTxZP5Fnclzef4Y97)
	ee8c0jzrTntGSUdRJm.setSetting(OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠬࡧࡶ࠯࡮ࡤࡲ࡬ࡻࡡࡨࡧ࠱ࡸࡷࡧ࡮ࡴ࡮ࡤࡸࡪ࠭๧"),ZZdrzYJuScnhwiApxV)
	return r5jmTKLnJvstRoIdDz3i8BNVGH
def GG49f0QoTrPgvyYOHeb1MsUIjiJlw(s39nqfFkgaz=fEXMiAyG3ql4vKB,EEdDx1bZloHAYahGygizufcj46=[]):
	vr7h3putEPS0Odjxi8MLWz2I9wf = [UC78nrbeDHfwVAh2vt,IlCq2uKjye3ZgSADFc]+EEdDx1bZloHAYahGygizufcj46
	for o4oOCVEFpXHUwMKszi in WQvYkNg7SysPFLitlGEn6.listdir(vA0ImpguajeHKJ6P):
		if s39nqfFkgaz and (o4oOCVEFpXHUwMKszi.startswith(KNIvHPjUbhr(u"࠭ࡩࡱࡶࡹࠫ๨")) or o4oOCVEFpXHUwMKszi.startswith(CnbBKmtF1x84q7AW(u"ࠧ࡮࠵ࡸࠫ๩"))): continue
		if o4oOCVEFpXHUwMKszi.startswith(hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠨࡨ࡬ࡰࡪࡥࠧ๪")): continue
		S7PIzYdHG9QgVLZspk8hu5D4WE = WQvYkNg7SysPFLitlGEn6.path.join(vA0ImpguajeHKJ6P,o4oOCVEFpXHUwMKszi)
		if S7PIzYdHG9QgVLZspk8hu5D4WE in vr7h3putEPS0Odjxi8MLWz2I9wf: continue
		try: WQvYkNg7SysPFLitlGEn6.remove(S7PIzYdHG9QgVLZspk8hu5D4WE)
		except: pass
	if zKdeknjoPhL9gN8v not in vr7h3putEPS0Odjxi8MLWz2I9wf: Xe6bnfEPjgqJy5FIoRi0z2v8(zKdeknjoPhL9gN8v,VBlawK4mgHSyLEn8iqhUkz5,fEXMiAyG3ql4vKB)
	HB5PvxRhwM.sleep(EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"࠴ᐜ"))
	return
def ZragotPSKx0dukFnq(kkcBlyP0JHu2C94ZmITvbd8wfirAV,fjUoJylTVWh0,S6NALBOqGn1zi2W5M8y7,F49URk16JIawgp7YWZAXGtnMb,UBRzLM6ZdkWOKwy0qPfFIlC,SSKgaJNQBPwlZY,showDialogs,dUWFtBQ3cpoIZ9,vlwhfTp01Md4P5kR3rAD62oSBUbLu7=VBlawK4mgHSyLEn8iqhUkz5,GDP8fawQRqBtUrcA9x4uLCZTMNF6=VBlawK4mgHSyLEn8iqhUkz5):
	S6NALBOqGn1zi2W5M8y7 = S6NALBOqGn1zi2W5M8y7+HHoGx7Flus60(u"ࠩࡿࢀࡒࡿࡐࡳࡱࡻࡽ࡚ࡸ࡬࠾ࠩ๫")+kkcBlyP0JHu2C94ZmITvbd8wfirAV
	BUXsmKe5dGpJj09REb6HqcO7tNv = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(DpQifS0oKBI1hYcO,fjUoJylTVWh0,S6NALBOqGn1zi2W5M8y7,F49URk16JIawgp7YWZAXGtnMb,UBRzLM6ZdkWOKwy0qPfFIlC,SSKgaJNQBPwlZY,showDialogs,dUWFtBQ3cpoIZ9,vlwhfTp01Md4P5kR3rAD62oSBUbLu7,GDP8fawQRqBtUrcA9x4uLCZTMNF6)
	if S6NALBOqGn1zi2W5M8y7 in BUXsmKe5dGpJj09REb6HqcO7tNv.content: BUXsmKe5dGpJj09REb6HqcO7tNv.succeeded = fEXMiAyG3ql4vKB
	if not BUXsmKe5dGpJj09REb6HqcO7tNv.succeeded:
		Za2Eugh8Mp1eQYH4()
	return BUXsmKe5dGpJj09REb6HqcO7tNv
def hhcIdagHeMUQZtKLolSxk2X(S6NALBOqGn1zi2W5M8y7):
	BUXsmKe5dGpJj09REb6HqcO7tNv = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(nHBb7jXk0Daom,EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠪࡋࡊ࡚ࠧ๬"),S6NALBOqGn1zi2W5M8y7,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,VBlawK4mgHSyLEn8iqhUkz5,hWGMqtBy4wuLaVcj,HHoGx7Flus60(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡅࡕࡡࡓࡖࡔ࡞ࡉࡆࡕࡢࡐࡎ࡙ࡔ࠮࠳ࡶࡸࠬ๭"),VBlawK4mgHSyLEn8iqhUkz5,fEXMiAyG3ql4vKB)
	ieouGzyxkq4VvmDOcLCpdPR = []
	if BUXsmKe5dGpJj09REb6HqcO7tNv.succeeded:
		wYZ9hmIlS3cv17s2W = BUXsmKe5dGpJj09REb6HqcO7tNv.content
		AIBgD6QZeli2uJvWTm0RYXc = trdVA0JvFaD.findall(dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠬࠦࠨ࠯ࠬࡂ࠭ࠥࡢࡤࡼ࠳࠯࠷ࢂࡳࡳࠨ๮"),wYZ9hmIlS3cv17s2W)
		if AIBgD6QZeli2uJvWTm0RYXc: wYZ9hmIlS3cv17s2W = NXMOzZjYsmS9pf.join(AIBgD6QZeli2uJvWTm0RYXc)
		nBpgxhSva72EUHjWGPzqmlYiA05X = wYZ9hmIlS3cv17s2W.replace(y6eSQlZEV8uwKG5M3,hWGMqtBy4wuLaVcj).strip(NXMOzZjYsmS9pf).split(NXMOzZjYsmS9pf)
		ieouGzyxkq4VvmDOcLCpdPR = []
		for kkcBlyP0JHu2C94ZmITvbd8wfirAV in nBpgxhSva72EUHjWGPzqmlYiA05X:
			if kkcBlyP0JHu2C94ZmITvbd8wfirAV.count(NeO3CTLHrPfWUoIgy8Q(u"࠭࠮ࠨ๯"))==x1x9kIQo3zjZWnYaiy: ieouGzyxkq4VvmDOcLCpdPR.append(kkcBlyP0JHu2C94ZmITvbd8wfirAV)
	return ieouGzyxkq4VvmDOcLCpdPR
def rl9Twe5k0EoiPUIFq(*aargs):
	aj5n0e68TFWtkdBhmPROzD1UxbENyv = mkHKSQvjWr5BTcM3wVY(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡳ࡭࠳ࡶࡲࡰࡺࡼࡷࡨࡸࡡࡱࡧ࠱ࡧࡴࡳ࠯ࡷ࠴࠲ࡃࡷ࡫ࡱࡶࡧࡶࡸࡂࡪࡩࡴࡲ࡯ࡥࡾࡶࡲࡰࡺ࡬ࡩࡸࠬࡰࡳࡱࡻࡽࡹࡿࡰࡦ࠿࡫ࡸࡹࡶࠦࡵ࡫ࡰࡩࡴࡻࡴ࠾࠳࠳࠴࠵࠶ࠦࡴࡵ࡯ࡁࡾ࡫ࡳࠧ࡮࡬ࡱ࡮ࡺ࠽࠲࠲ࠩࡧࡴࡻ࡮ࡵࡴࡼࡁࡓࡒࠬࡃࡇ࠯ࡈࡊ࠲ࡆࡓ࠮ࡊࡆ࠱࡚ࡒࠨ๰")
	NMCUZGn5Wq9Kj8zbXElJ = ITvnUAMXsyb4eO(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡵࡥࡼ࠴ࡧࡪࡶ࡫ࡹࡧࡻࡳࡦࡴࡦࡳࡳࡺࡥ࡯ࡶ࠱ࡧࡴࡳ࠯ࡳࡱࡲࡷࡹ࡫ࡲ࡬࡫ࡧ࠳ࡴࡶࡥ࡯ࡲࡵࡳࡽࡿ࡬ࡪࡵࡷ࠳ࡲࡧࡩ࡯࠱ࡋࡘ࡙ࡖࡓ࠯ࡶࡻࡸࠬ๱")
	kkuh0WdRepfyJZP3DwLv9VB14IOs = hhcIdagHeMUQZtKLolSxk2X(NMCUZGn5Wq9Kj8zbXElJ)
	ieouGzyxkq4VvmDOcLCpdPR = hhcIdagHeMUQZtKLolSxk2X(aj5n0e68TFWtkdBhmPROzD1UxbENyv)
	QwnBt8pL6yfh = kkuh0WdRepfyJZP3DwLv9VB14IOs+ieouGzyxkq4VvmDOcLCpdPR
	KteLZCbM8W0FqE2OBx1(YYcbiF1UROXlga2,qhVEWvetzXLOcr1(xjPuFK3EsIZSiobQ5X)+QvgnCALNstmuUJiET(u"ࠩࠣࠤࠥࡍ࡯ࡵࠢࡳࡶࡴࡾࡩࡦࡵࠣࡰ࡮ࡹࡴࠡࠢࠣ࠵ࡸࡺࠫ࠳ࡰࡧ࠾ࠥࡡࠠࠨ๲")+str(len(kkuh0WdRepfyJZP3DwLv9VB14IOs))+rwQN9AKhLCuMfHxjlbX0U(u"ࠪ࠯ࠬ๳")+str(len(ieouGzyxkq4VvmDOcLCpdPR))+LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠫࠥࡣࠧ๴"))
	kkcBlyP0JHu2C94ZmITvbd8wfirAV = ee8c0jzrTntGSUdRJm.getSetting(gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠬࡧࡶ࠯ࡲࡵࡳࡽࡿ࠮࡭ࡣࡶࡸࠬ๵"))
	BUXsmKe5dGpJj09REb6HqcO7tNv = aRBhF1OdxM0ek5SwqG()
	ee8c0jzrTntGSUdRJm.setSetting(LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"࠭ࡡࡷ࠰ࡳࡶࡴࡾࡹ࠯࡮ࡤࡷࡹ࠭๶"),hWGMqtBy4wuLaVcj)
	if kkcBlyP0JHu2C94ZmITvbd8wfirAV or QwnBt8pL6yfh:
		p1tmbSLQT0jfKloyc5gvCIauJz,CCiHoyQdYazj = ybdv7XcT3lxF6QezULwCAGk,HHoGx7Flus60(u"࠵࠵ᐝ")
		SSqBuKk4aZ = len(QwnBt8pL6yfh)
		nV9yoQzeq5xPiflXpUIugavLcNmE = CCiHoyQdYazj
		if SSqBuKk4aZ>nV9yoQzeq5xPiflXpUIugavLcNmE: HfJlZx25muAU1hqbFVXarIsOnw = nV9yoQzeq5xPiflXpUIugavLcNmE
		else: HfJlZx25muAU1hqbFVXarIsOnw = SSqBuKk4aZ
		jjiUur4cTdefw2Y = eOmXSF6kIWV7yqKCR.sample(QwnBt8pL6yfh,HfJlZx25muAU1hqbFVXarIsOnw)
		if kkcBlyP0JHu2C94ZmITvbd8wfirAV: jjiUur4cTdefw2Y = [kkcBlyP0JHu2C94ZmITvbd8wfirAV]+jjiUur4cTdefw2Y
		RKmbo6tlvfL4xPn5c = wfH5yxroNbj82s9iPp7QvuTn(fEXMiAyG3ql4vKB,fEXMiAyG3ql4vKB)
		pp9oFfEkKX74znPZ = HB5PvxRhwM.time()
		while HB5PvxRhwM.time()-pp9oFfEkKX74znPZ<=CCiHoyQdYazj and not RKmbo6tlvfL4xPn5c.finishedLIST:
			if p1tmbSLQT0jfKloyc5gvCIauJz<HfJlZx25muAU1hqbFVXarIsOnw:
				kkcBlyP0JHu2C94ZmITvbd8wfirAV = jjiUur4cTdefw2Y[p1tmbSLQT0jfKloyc5gvCIauJz]
				RKmbo6tlvfL4xPn5c.GJfmn1Wyce6wo2(p1tmbSLQT0jfKloyc5gvCIauJz,ZragotPSKx0dukFnq,kkcBlyP0JHu2C94ZmITvbd8wfirAV,*aargs)
			HB5PvxRhwM.sleep(S1SgCFYGJeMvfp5iZXK(u"࠵࠴࠷࠶ᐞ"))
			p1tmbSLQT0jfKloyc5gvCIauJz += bXukYxQ4aHw
			KteLZCbM8W0FqE2OBx1(pGYKHZgqFX3B,qhVEWvetzXLOcr1(xjPuFK3EsIZSiobQ5X)+CnbBKmtF1x84q7AW(u"ࠧࠡࠢࠣࡘࡷࡿࡩ࡯ࡩ࠽ࠤࠥࠦࡐࡳࡱࡻࡽ࠿࡛ࠦࠡࠩ๷")+kkcBlyP0JHu2C94ZmITvbd8wfirAV+e2qDYgipPmTw4KvBLnochr(u"ࠨࠢࡠࠫ๸"))
		finishedLIST = RKmbo6tlvfL4xPn5c.finishedLIST
		if finishedLIST:
			resultsDICT = RKmbo6tlvfL4xPn5c.resultsDICT
			vHPGFkuh7DNe85qxaSicW = finishedLIST[ybdv7XcT3lxF6QezULwCAGk]
			BUXsmKe5dGpJj09REb6HqcO7tNv = resultsDICT[vHPGFkuh7DNe85qxaSicW]
			kkcBlyP0JHu2C94ZmITvbd8wfirAV = jjiUur4cTdefw2Y[int(vHPGFkuh7DNe85qxaSicW)]
			ee8c0jzrTntGSUdRJm.setSetting(e2qDYgipPmTw4KvBLnochr(u"ࠩࡤࡺ࠳ࡶࡲࡰࡺࡼ࠲ࡱࡧࡳࡵࠩ๹"),kkcBlyP0JHu2C94ZmITvbd8wfirAV)
			if vHPGFkuh7DNe85qxaSicW!=ybdv7XcT3lxF6QezULwCAGk: KteLZCbM8W0FqE2OBx1(YYcbiF1UROXlga2,qhVEWvetzXLOcr1(xjPuFK3EsIZSiobQ5X)+wwPrSDa21lUh(u"ࠪࠤࠥࠦࡓࡶࡥࡦࡩࡸࡹ࠺ࠡࠢࠣࡔࡷࡵࡸࡺ࠼ࠣ࡟ࠥ࠭๺")+kkcBlyP0JHu2C94ZmITvbd8wfirAV+zyvJMtBhrw(u"ࠫࠥࡣࠧ๻"))
			else: KteLZCbM8W0FqE2OBx1(YYcbiF1UROXlga2,qhVEWvetzXLOcr1(xjPuFK3EsIZSiobQ5X)+HHoGx7Flus60(u"ࠬࠦࠠࠡࡕࡸࡧࡨ࡫ࡳࡴ࠼ࠣࠤ࡙ࠥࡡࡷࡧࡧࠤࡵࡸ࡯ࡹࡻ࠽ࠤࡠࠦࠧ๼")+kkcBlyP0JHu2C94ZmITvbd8wfirAV+FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"࠭ࠠ࡞ࠩ๽"))
	return BUXsmKe5dGpJj09REb6HqcO7tNv
def LplGeCtbFnTMXvJhu(UKYogA6VRcOx3NEw5syl,T5EshFWwM3J7zH):
	jP6CGFa9p0Rv3 = UKYogA6VRcOx3NEw5syl.create_connection
	def pm7AsP3vL8GeICRa9EbByjUc(zwDoA9USqLp4iJ,*aargs,**kkwargs):
		JfH0yTDjbBchm6Aui7W,sfn63NJcqO7WZCQxtLHU = zwDoA9USqLp4iJ
		ip = BNeOTHu75qV6p(JfH0yTDjbBchm6Aui7W,T5EshFWwM3J7zH)
		if ip: JfH0yTDjbBchm6Aui7W = ip[ybdv7XcT3lxF6QezULwCAGk]
		else:
			if T5EshFWwM3J7zH in vIDJ3z8NTlStsfnW4MOQC20Bo: vIDJ3z8NTlStsfnW4MOQC20Bo.remove(T5EshFWwM3J7zH)
			if vIDJ3z8NTlStsfnW4MOQC20Bo:
				zbVW9mC6vPM5q8UeRJ31XdisxHOcL = vIDJ3z8NTlStsfnW4MOQC20Bo[ybdv7XcT3lxF6QezULwCAGk]
				ip = BNeOTHu75qV6p(JfH0yTDjbBchm6Aui7W,zbVW9mC6vPM5q8UeRJ31XdisxHOcL)
				if ip: JfH0yTDjbBchm6Aui7W = ip[ybdv7XcT3lxF6QezULwCAGk]
		zwDoA9USqLp4iJ = (JfH0yTDjbBchm6Aui7W,sfn63NJcqO7WZCQxtLHU)
		return jP6CGFa9p0Rv3(zwDoA9USqLp4iJ,*aargs,**kkwargs)
	UKYogA6VRcOx3NEw5syl.create_connection = pm7AsP3vL8GeICRa9EbByjUc
	return jP6CGFa9p0Rv3
def HHSQUub7VAqw3Wrm1Lz(S6NALBOqGn1zi2W5M8y7):
	lonqkWVaxTyg3czLES,ZWCevuDGMQBgz5F = S6NALBOqGn1zi2W5M8y7.split(DJ1ICpbyR2(u"ࠧ࠰ࠩ๾"))[Y0XZKGRAUQj5O],hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"࠾࠰ᐟ")
	if CnbBKmtF1x84q7AW(u"ࠨ࠼ࠪ๿") in lonqkWVaxTyg3czLES: lonqkWVaxTyg3czLES,ZWCevuDGMQBgz5F = lonqkWVaxTyg3czLES.split(hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠩ࠽ࠫ຀"))
	qq2W7VcfSPFERbNHnd5ZJyOxaT9 = CnbBKmtF1x84q7AW(u"ࠪ࠳ࠬກ")+XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠫ࠴࠭ຂ").join(S6NALBOqGn1zi2W5M8y7.split(jeAby54c02TgG8zuivonX91(u"ࠬ࠵ࠧ຃"))[o1u5dij9UrcbXzVS8lwIWfKpnqM(u"࠳ᐠ"):])
	s4mUPzjv1bRoNTMdenkuBgYl = EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"࠭ࡇࡆࡖࠣࠫຄ")+qq2W7VcfSPFERbNHnd5ZJyOxaT9+XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠧࠡࡊࡗࡘࡕ࠵࠱࠯࠳࡟ࡶࡡࡴࠧ຅")
	s4mUPzjv1bRoNTMdenkuBgYl += XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠨࡊࡲࡷࡹࡀࠠࠨຆ")+lonqkWVaxTyg3czLES+zyvJMtBhrw(u"ࠩ࡟ࡶࡡࡴࠧງ")
	s4mUPzjv1bRoNTMdenkuBgYl += NeO3CTLHrPfWUoIgy8Q(u"ࠪࡠࡷࡢ࡮ࠨຈ")
	from socket import socket as jFL1meU3RWM78GPlJBNbQHdShuT,AF_INET as hSuRrpxJ1blOyYCDEmFGU,SOCK_STREAM as nwbQDs5xKHFLUk4jmtzZo
	try:
		ZiEu0bh9pydOUtIP = jFL1meU3RWM78GPlJBNbQHdShuT(hSuRrpxJ1blOyYCDEmFGU,nwbQDs5xKHFLUk4jmtzZo)
		ZiEu0bh9pydOUtIP.connect((lonqkWVaxTyg3czLES,ZWCevuDGMQBgz5F))
		ZiEu0bh9pydOUtIP.send(s4mUPzjv1bRoNTMdenkuBgYl.encode(a7VXeDU82IfQEnPZAdiT))
		hcIZTCDEaX86tNf0KbePq = ZiEu0bh9pydOUtIP.recv(NeO3CTLHrPfWUoIgy8Q(u"࠶࠳࠽࠻ᐢ")*QvgnCALNstmuUJiET(u"࠲࠲࠵࠸ᐡ"))
		wYZ9hmIlS3cv17s2W = repr(hcIZTCDEaX86tNf0KbePq)
	except: wYZ9hmIlS3cv17s2W = hWGMqtBy4wuLaVcj
	return wYZ9hmIlS3cv17s2W
def RRNODILCtGzvgpx(bWsVM7A1KOYIq2j0k5836Qw,X3X4Y8RzxSVfZJUFDe):
	if sULh4NjakzI8He7xJCMGrql(u"ࠫ࠳࠭ຉ") not in bWsVM7A1KOYIq2j0k5836Qw: return bWsVM7A1KOYIq2j0k5836Qw
	bWsVM7A1KOYIq2j0k5836Qw = bWsVM7A1KOYIq2j0k5836Qw+NeO3CTLHrPfWUoIgy8Q(u"ࠬ࠵ࠧຊ")
	yW267qlcSKgwOeJA3UErZ,Z7nx4lpfoQ = bWsVM7A1KOYIq2j0k5836Qw.split(QvgnCALNstmuUJiET(u"࠭࠮ࠨ຋"),JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"࠴ᐣ"))
	ttvsqjxrGEQK2dBmXYa5yNfwFP1Ai,ttWVZdo2bjQBLp4fAuag5RhKzC = Z7nx4lpfoQ.split(KNIvHPjUbhr(u"ࠧ࠰ࠩຌ"),LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"࠵ᐤ"))
	BHCP2amVTOfy75 = yW267qlcSKgwOeJA3UErZ+jeAby54c02TgG8zuivonX91(u"ࠨ࠰ࠪຍ")+ttvsqjxrGEQK2dBmXYa5yNfwFP1Ai
	if X3X4Y8RzxSVfZJUFDe in [SqrG5mU3j96ldsFpExobw40TJY(u"ࠩ࡫ࡳࡸࡺࠧຎ"),ITvnUAMXsyb4eO(u"ࠪࡲࡦࡳࡥࠨຏ")] and dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠫ࠴࠭ຐ") in BHCP2amVTOfy75: BHCP2amVTOfy75 = BHCP2amVTOfy75.rsplit(o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠬ࠵ࠧຑ"),A6dMB1FlgxVivJ2fk9C(u"࠶ᐥ"))[bXukYxQ4aHw]
	if X3X4Y8RzxSVfZJUFDe==EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"࠭࡮ࡢ࡯ࡨࠫຒ") and FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠧ࠯ࠩຓ") in BHCP2amVTOfy75:
		iS2EfMhCPGgzHkoqabW0xr = BHCP2amVTOfy75.split(KNIvHPjUbhr(u"ࠨ࠰ࠪດ"))
		dKjvLaWQAuyB = len(iS2EfMhCPGgzHkoqabW0xr)
		if S1SgCFYGJeMvfp5iZXK(u"ࠩࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴࠧຕ") in BHCP2amVTOfy75: iS2EfMhCPGgzHkoqabW0xr = zyvJMtBhrw(u"ࠪࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮ࠨຖ")
		elif dKjvLaWQAuyB<=Y0XZKGRAUQj5O: iS2EfMhCPGgzHkoqabW0xr = iS2EfMhCPGgzHkoqabW0xr[ybdv7XcT3lxF6QezULwCAGk]
		elif dKjvLaWQAuyB>=x1x9kIQo3zjZWnYaiy: iS2EfMhCPGgzHkoqabW0xr = iS2EfMhCPGgzHkoqabW0xr[bXukYxQ4aHw]
		if len(iS2EfMhCPGgzHkoqabW0xr)>bXukYxQ4aHw: BHCP2amVTOfy75 = iS2EfMhCPGgzHkoqabW0xr
	return BHCP2amVTOfy75
def DDZcb1RmaIMH(idNbRr1XBCw3YWxQh):
	lmf6I7LcWj = repr(idNbRr1XBCw3YWxQh.encode(a7VXeDU82IfQEnPZAdiT)).replace(KBkxSYaz93pu1(u"ࠦࠬࠨທ"),hWGMqtBy4wuLaVcj)
	return lmf6I7LcWj
def cmYMV3Wrwp05J2RNgLs9vCT8X(RRCNAJXvYuD9Fbl1h):
	aas0iZUYdOjRblfoNxIAEug7JV6h = hWGMqtBy4wuLaVcj
	if VKiGj1LundAJQwEXcqgxC: RRCNAJXvYuD9Fbl1h = RRCNAJXvYuD9Fbl1h.decode(a7VXeDU82IfQEnPZAdiT)
	from unicodedata import decomposition as HlYKqcxN58kV6EAbpmoPdRO4Ua
	for m6M80ftV2PdkIJU1 in RRCNAJXvYuD9Fbl1h:
		if   m6M80ftV2PdkIJU1==LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࡺ࠭ยࠨຘ"): kgiZYIXtB9FsAV5v4QqplwcKbWuaC = XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"࠭࡜࡝ࡷ࠳࠺࠷࠸ࠧນ")
		elif m6M80ftV2PdkIJU1==e2qDYgipPmTw4KvBLnochr(u"ࡵࠨลࠪບ"): kgiZYIXtB9FsAV5v4QqplwcKbWuaC = hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠨ࡞࡟ࡹ࠵࠼࠲࠴ࠩປ")
		elif m6M80ftV2PdkIJU1==mkHKSQvjWr5BTcM3wVY(u"ࡷࠪศࠬຜ"): kgiZYIXtB9FsAV5v4QqplwcKbWuaC = CnbBKmtF1x84q7AW(u"ࠪࡠࡡࡻ࠰࠷࠴࠷ࠫຝ")
		elif m6M80ftV2PdkIJU1==hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࡹࠬหࠧພ"): kgiZYIXtB9FsAV5v4QqplwcKbWuaC = LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠬࡢ࡜ࡶ࠲࠹࠶࠺࠭ຟ")
		elif m6M80ftV2PdkIJU1==e2qDYgipPmTw4KvBLnochr(u"ࡻࠧวࠩຠ"): kgiZYIXtB9FsAV5v4QqplwcKbWuaC = MMizeNH0AKu(u"ࠧ࡝࡞ࡸ࠴࠻࠸࠶ࠨມ")
		else:
			ggD8avOturbqNL = HlYKqcxN58kV6EAbpmoPdRO4Ua(m6M80ftV2PdkIJU1)
			if Mpsm2VF1OBnCRvK3qf6 in ggD8avOturbqNL: kgiZYIXtB9FsAV5v4QqplwcKbWuaC = S1SgCFYGJeMvfp5iZXK(u"ࠨ࡞࡟ࡹࠬຢ")+ggD8avOturbqNL.split(Mpsm2VF1OBnCRvK3qf6,bXukYxQ4aHw)[bXukYxQ4aHw]
			else:
				kgiZYIXtB9FsAV5v4QqplwcKbWuaC = QvgnCALNstmuUJiET(u"ࠩ࠳࠴࠵࠶ࠧຣ")+hex(ord(m6M80ftV2PdkIJU1)).replace(QVDJLRlxNg127jMX(u"ࠪ࠴ࡽ࠭຤"),hWGMqtBy4wuLaVcj)
				kgiZYIXtB9FsAV5v4QqplwcKbWuaC = KBkxSYaz93pu1(u"ࠫࡡࡢࡵࠨລ")+kgiZYIXtB9FsAV5v4QqplwcKbWuaC[-jR6BYWNFZ0egmH4Tr2Q78LbSs3t:]
		aas0iZUYdOjRblfoNxIAEug7JV6h += kgiZYIXtB9FsAV5v4QqplwcKbWuaC
	aas0iZUYdOjRblfoNxIAEug7JV6h = aas0iZUYdOjRblfoNxIAEug7JV6h.replace(QVDJLRlxNg127jMX(u"ࠬࡢ࡜ࡶ࠲࠹ࡇࡈ࠭຦"),dv0trJR7PwmKyxDYO52VLau8gEph(u"࠭࡜࡝ࡷ࠳࠺࠹࠿ࠧວ"))
	if VKiGj1LundAJQwEXcqgxC: aas0iZUYdOjRblfoNxIAEug7JV6h = aas0iZUYdOjRblfoNxIAEug7JV6h.decode(S1SgCFYGJeMvfp5iZXK(u"ࠧࡶࡰ࡬ࡧࡴࡪࡥࡠࡧࡶࡧࡦࡶࡥࠨຨ")).encode(a7VXeDU82IfQEnPZAdiT)
	else: aas0iZUYdOjRblfoNxIAEug7JV6h = aas0iZUYdOjRblfoNxIAEug7JV6h.encode(a7VXeDU82IfQEnPZAdiT).decode(GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠨࡷࡱ࡭ࡨࡵࡤࡦࡡࡨࡷࡨࡧࡰࡦࠩຩ"))
	return aas0iZUYdOjRblfoNxIAEug7JV6h
def TrzfUidpv1LyAYqwexHJDuS(header=NeO3CTLHrPfWUoIgy8Q(u"ࠩ็์าฯࠠศๆ่ๅฬะ๊ฮࠩສ"),HzcTkSV6qrsd9YnC0exa4hF=hWGMqtBy4wuLaVcj,aaFHeSJDqs5Cd=fEXMiAyG3ql4vKB,source=hWGMqtBy4wuLaVcj):
	XNBHzrlKD9yW = pXyrkEW8m64sDeAzfH(header,HzcTkSV6qrsd9YnC0exa4hF,type=mUWYiQ2jHICA8cD6LhPTn3wpB1XyK.INPUT_ALPHANUM)
	XNBHzrlKD9yW = XNBHzrlKD9yW.replace(FqcVAkh7WjIXHdDKf8nvuyRo,Mpsm2VF1OBnCRvK3qf6).replace(FqcVAkh7WjIXHdDKf8nvuyRo,Mpsm2VF1OBnCRvK3qf6).replace(FqcVAkh7WjIXHdDKf8nvuyRo,Mpsm2VF1OBnCRvK3qf6)
	if not XNBHzrlKD9yW and not aaFHeSJDqs5Cd:
		KteLZCbM8W0FqE2OBx1(pGYKHZgqFX3B,HHoGx7Flus60(u"ࠪ࠲ࡡࡺࡋࡦࡻࡥࡳࡦࡸࡤࠡࡧࡱࡸࡷࡿࠠࡤࡣࡱࡧࡪࡲࡥࡥ࠼ࠣࠤࠥࠨࠧຫ")+XNBHzrlKD9yW+hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠫࠧ࠭ຬ"))
		BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,ITvnUAMXsyb4eO(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨອ"),mkHKSQvjWr5BTcM3wVY(u"࠭สๆࠢศ่฿อมࠡษ็ษิิวๅࠩຮ"))
		return hWGMqtBy4wuLaVcj
	if XNBHzrlKD9yW not in [hWGMqtBy4wuLaVcj,Mpsm2VF1OBnCRvK3qf6]:
		XNBHzrlKD9yW = XNBHzrlKD9yW.strip(Mpsm2VF1OBnCRvK3qf6)
		XNBHzrlKD9yW = cmYMV3Wrwp05J2RNgLs9vCT8X(XNBHzrlKD9yW)
	if source!=QvgnCALNstmuUJiET(u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔࠩຯ") and Dc20k3vN9hT5(MMizeNH0AKu(u"ࠨࡍࡈ࡝ࡇࡕࡁࡓࡆࠪະ"),hWGMqtBy4wuLaVcj,[XNBHzrlKD9yW],fEXMiAyG3ql4vKB):
		KteLZCbM8W0FqE2OBx1(pGYKHZgqFX3B,o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠩ࠱ࡠࡹࡑࡥࡺࡤࡲࡥࡷࡪࠠࡦࡰࡷࡶࡾࠦࡢ࡭ࡱࡦ࡯ࡪࡪ࠺ࠡࠢࠣࠦࠬັ")+XNBHzrlKD9yW+LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠪࠦࠬາ"))
		BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,mkHKSQvjWr5BTcM3wVY(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧຳ"),hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠬอๆหࠢๆฮอะࠠไๆ่อࠥษ่ࠡำๅ้๊ࠥ็ࠡ฻็ห็ฯࠠษลไ่ฬ๋ࠠๅๆๆฬฬืࠠโไฺࠤ࠳࠴้้ࠠำหࠥอไษำ้ห๊าࠠๅษࠣ๎ุ๋อࠡสสืฯิฯศ็๋่ࠣึวࠡๅ็้ฬะࠧິ"))
		return hWGMqtBy4wuLaVcj
	KteLZCbM8W0FqE2OBx1(pGYKHZgqFX3B,ITvnUAMXsyb4eO(u"࠭࠮࡝ࡶࡎࡩࡾࡨ࡯ࡢࡴࡧࠤࡪࡴࡴࡳࡻࠣࡥࡱࡲ࡯ࡸࡧࡧ࠾ࠥࠦࠠࠣࠩີ")+XNBHzrlKD9yW+NeO3CTLHrPfWUoIgy8Q(u"ࠧࠣࠩຶ"))
	return XNBHzrlKD9yW
def b8IJFKNyPjgE4GelaCSXB6Qht(NPM3HKQ57xe,PwvNmnqXKrYVZugB5c8={}):
	S6NALBOqGn1zi2W5M8y7,QhwNPaAO8cm0vqZouUY,duy23h0kTUCi6IGSJ,CysMr5Z7vqSenAK0BobTN3 = NPM3HKQ57xe,{},{},hWGMqtBy4wuLaVcj
	if dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠨࡾࠪື") in NPM3HKQ57xe: S6NALBOqGn1zi2W5M8y7,QhwNPaAO8cm0vqZouUY = fWM9y4vTcPLS0b3UKItC1os5(NPM3HKQ57xe,DJ1ICpbyR2(u"ࠩࡿຸࠫ"))
	f2qPOz3RsjJnFwNpAatkdIEDVQ1BLm = list(set(list(PwvNmnqXKrYVZugB5c8.keys())+list(QhwNPaAO8cm0vqZouUY.keys())))
	for jKJu4sm3FwBXipMExahVcdgRQUr7 in f2qPOz3RsjJnFwNpAatkdIEDVQ1BLm:
		if jKJu4sm3FwBXipMExahVcdgRQUr7 in list(QhwNPaAO8cm0vqZouUY.keys()): duy23h0kTUCi6IGSJ[jKJu4sm3FwBXipMExahVcdgRQUr7] = QhwNPaAO8cm0vqZouUY[jKJu4sm3FwBXipMExahVcdgRQUr7]
		else: duy23h0kTUCi6IGSJ[jKJu4sm3FwBXipMExahVcdgRQUr7] = PwvNmnqXKrYVZugB5c8[jKJu4sm3FwBXipMExahVcdgRQUr7]
	if xcChIL13BpR8WArNt9Pl0So(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺູࠧ") not in f2qPOz3RsjJnFwNpAatkdIEDVQ1BLm: duy23h0kTUCi6IGSJ[sULh4NjakzI8He7xJCMGrql(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ຺")] = OB6QYAMUnPiWXgpkTrItV48FqZSjdR()
	if XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭ົ") not in f2qPOz3RsjJnFwNpAatkdIEDVQ1BLm: duy23h0kTUCi6IGSJ[xcChIL13BpR8WArNt9Pl0So(u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧຼ")] = RRNODILCtGzvgpx(S6NALBOqGn1zi2W5M8y7,xcChIL13BpR8WArNt9Pl0So(u"ࠧࡶࡴ࡯ࠫຽ"))
	if QVDJLRlxNg127jMX(u"ࠨࡃࡦࡧࡪࡶࡴ࠮ࡎࡤࡲ࡬ࡻࡡࡨࡧࠪ຾") not in f2qPOz3RsjJnFwNpAatkdIEDVQ1BLm: duy23h0kTUCi6IGSJ[KBkxSYaz93pu1(u"ࠩࡄࡧࡨ࡫ࡰࡵ࠯ࡏࡥࡳ࡭ࡵࡢࡩࡨࠫ຿")] = XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠪࡩࡳ࠳ࡕࡔ࠮ࡨࡲࡀࡷ࠽࠱࠰࠼ࠫເ")
	for jKJu4sm3FwBXipMExahVcdgRQUr7 in list(duy23h0kTUCi6IGSJ.keys()): CysMr5Z7vqSenAK0BobTN3 += A6dMB1FlgxVivJ2fk9C(u"ࠫࠫ࠭ແ")+jKJu4sm3FwBXipMExahVcdgRQUr7+xcChIL13BpR8WArNt9Pl0So(u"ࠬࡃࠧໂ")+duy23h0kTUCi6IGSJ[jKJu4sm3FwBXipMExahVcdgRQUr7]
	if CysMr5Z7vqSenAK0BobTN3: CysMr5Z7vqSenAK0BobTN3 = SqrG5mU3j96ldsFpExobw40TJY(u"࠭ࡼࠨໃ")+CysMr5Z7vqSenAK0BobTN3[bXukYxQ4aHw:]
	BUXsmKe5dGpJj09REb6HqcO7tNv = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(D8V7AhLkSQYzo,NeO3CTLHrPfWUoIgy8Q(u"ࠧࡈࡇࡗࠫໄ"),S6NALBOqGn1zi2W5M8y7,hWGMqtBy4wuLaVcj,duy23h0kTUCi6IGSJ,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,e2qDYgipPmTw4KvBLnochr(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡈ࡜࡙ࡘࡁࡄࡖࡢࡑ࠸࡛࠸࠮࠳ࡶࡸࠬ໅"),fEXMiAyG3ql4vKB,fEXMiAyG3ql4vKB)
	wYZ9hmIlS3cv17s2W = BUXsmKe5dGpJj09REb6HqcO7tNv.content
	if gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠩࡖࡘࡗࡋࡁࡎ࠯ࡌࡒࡋ࠭ໆ") not in wYZ9hmIlS3cv17s2W: return [hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠪ࠱࠶࠭໇")],[S6NALBOqGn1zi2W5M8y7+CysMr5Z7vqSenAK0BobTN3]
	if MMizeNH0AKu(u"࡙ࠫ࡟ࡐࡆ࠿ࡄ࡙ࡉࡏࡏࠨ່") in wYZ9hmIlS3cv17s2W: return [JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠬ࠳࠱ࠨ້")],[S6NALBOqGn1zi2W5M8y7+CysMr5Z7vqSenAK0BobTN3]
	if EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"࠭ࡔ࡚ࡒࡈࡁ࡛ࡏࡄࡆࡑ໊ࠪ") in wYZ9hmIlS3cv17s2W: return [zyvJMtBhrw(u"ࠧ࠮࠳໋ࠪ")],[S6NALBOqGn1zi2W5M8y7+CysMr5Z7vqSenAK0BobTN3]
	haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me,zEmVTBN1evQPoRpX0H9as84,dwg0bnuYJry5BiLtTGDWjh = [],[],[],[]
	yefFjNXHl7 = trdVA0JvFaD.findall(jeAby54c02TgG8zuivonX91(u"ࠨࠥࡈ࡜࡙࠳ࡘ࠮ࡕࡗࡖࡊࡇࡍ࠮ࡋࡑࡊ࠿࠮࠮ࠫࡁࠬ࡟ࡡࡸ࡜࡯࡟࠮ࠬ࠳࠰࠿ࠪ࡝࡟ࡶࡡࡴ࡝ࠬࠩ໌"),wYZ9hmIlS3cv17s2W+NXMOzZjYsmS9pf,trdVA0JvFaD.DOTALL)
	if not yefFjNXHl7: return [mkHKSQvjWr5BTcM3wVY(u"ࠩ࠰࠵ࠬໍ")],[S6NALBOqGn1zi2W5M8y7+CysMr5Z7vqSenAK0BobTN3]
	for O1wKxLtr08BhHUFaQlVCdk3e5gDpz9,bWsVM7A1KOYIq2j0k5836Qw in yefFjNXHl7:
		iQPYeO5BK6fIpWX1mwFH4hu3R0lAxZ,fb0MVGEwp5yNkijcSeFXmOa,QS8ZdxkHD5bjU9qsn4zMYaPrg3h7 = {},-LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"࠷ᐦ"),-LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"࠷ᐦ")
		V1VwIdhQ7YoKMzkTqGsjZ6cPAp5JL = hWGMqtBy4wuLaVcj
		H1eWYhmUozqOxrTbkScPI = O1wKxLtr08BhHUFaQlVCdk3e5gDpz9.split(MMizeNH0AKu(u"ࠪ࠰ࠬ໎"))
		for YGEAhZgn41MJyBudfqwr6Q in H1eWYhmUozqOxrTbkScPI:
			if LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠫࡂ࠭໏") in YGEAhZgn41MJyBudfqwr6Q:
				jKJu4sm3FwBXipMExahVcdgRQUr7,R1Rpns76wZd9NljL8fyUg = YGEAhZgn41MJyBudfqwr6Q.split(FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠬࡃࠧ໐"),EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"࠱ᐧ"))
				iQPYeO5BK6fIpWX1mwFH4hu3R0lAxZ[jKJu4sm3FwBXipMExahVcdgRQUr7.lower()] = R1Rpns76wZd9NljL8fyUg
		if sULh4NjakzI8He7xJCMGrql(u"࠭ࡡࡷࡧࡵࡥ࡬࡫࠭ࡣࡣࡱࡨࡼ࡯ࡤࡵࡪࠪ໑") in O1wKxLtr08BhHUFaQlVCdk3e5gDpz9.lower():
			fb0MVGEwp5yNkijcSeFXmOa = int(iQPYeO5BK6fIpWX1mwFH4hu3R0lAxZ[KNIvHPjUbhr(u"ࠧࡢࡸࡨࡶࡦ࡭ࡥ࠮ࡤࡤࡲࡩࡽࡩࡥࡶ࡫ࠫ໒")])//QVDJLRlxNg127jMX(u"࠲࠲࠵࠸ᐨ")
			V1VwIdhQ7YoKMzkTqGsjZ6cPAp5JL += str(fb0MVGEwp5yNkijcSeFXmOa)+XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠨ࡭ࡥࡴࡸࠦࠠࠨ໓")
		elif wwPrSDa21lUh(u"ࠩࡥࡥࡳࡪࡷࡪࡦࡷ࡬ࠬ໔") in O1wKxLtr08BhHUFaQlVCdk3e5gDpz9.lower():
			fb0MVGEwp5yNkijcSeFXmOa = int(iQPYeO5BK6fIpWX1mwFH4hu3R0lAxZ[wwPrSDa21lUh(u"ࠪࡦࡦࡴࡤࡸ࡫ࡧࡸ࡭࠭໕")])//dv0trJR7PwmKyxDYO52VLau8gEph(u"࠳࠳࠶࠹ᐩ")
			V1VwIdhQ7YoKMzkTqGsjZ6cPAp5JL += str(fb0MVGEwp5yNkijcSeFXmOa)+XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠫࡰࡨࡰࡴࠢࠣࠫ໖")
		if rwQN9AKhLCuMfHxjlbX0U(u"ࠬࡸࡥࡴࡱ࡯ࡹࡹ࡯࡯࡯ࠩ໗") in O1wKxLtr08BhHUFaQlVCdk3e5gDpz9.lower():
			QS8ZdxkHD5bjU9qsn4zMYaPrg3h7 = int(iQPYeO5BK6fIpWX1mwFH4hu3R0lAxZ[dv0trJR7PwmKyxDYO52VLau8gEph(u"࠭ࡲࡦࡵࡲࡰࡺࡺࡩࡰࡰࠪ໘")].split(QVDJLRlxNg127jMX(u"ࠧࡹࠩ໙"))[bXukYxQ4aHw])
			V1VwIdhQ7YoKMzkTqGsjZ6cPAp5JL += str(QS8ZdxkHD5bjU9qsn4zMYaPrg3h7)+FqcVAkh7WjIXHdDKf8nvuyRo
		V1VwIdhQ7YoKMzkTqGsjZ6cPAp5JL = V1VwIdhQ7YoKMzkTqGsjZ6cPAp5JL.strip(FqcVAkh7WjIXHdDKf8nvuyRo)
		if not V1VwIdhQ7YoKMzkTqGsjZ6cPAp5JL: V1VwIdhQ7YoKMzkTqGsjZ6cPAp5JL = ITvnUAMXsyb4eO(u"ࠨࡗࡱ࡯ࡳࡵࡷ࡯ࠩ໚")
		if not bWsVM7A1KOYIq2j0k5836Qw.startswith(A6dMB1FlgxVivJ2fk9C(u"ࠩ࡫ࡸࡹࡶࠧ໛")):
			if bWsVM7A1KOYIq2j0k5836Qw.startswith(XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠪ࠳࠴࠭ໜ")): bWsVM7A1KOYIq2j0k5836Qw = S6NALBOqGn1zi2W5M8y7.split(DJ1ICpbyR2(u"ࠫ࠿࠭ໝ"),bXukYxQ4aHw)[ybdv7XcT3lxF6QezULwCAGk]+wwPrSDa21lUh(u"ࠬࡀࠧໞ")+bWsVM7A1KOYIq2j0k5836Qw
			elif bWsVM7A1KOYIq2j0k5836Qw.startswith(MMizeNH0AKu(u"࠭࠯ࠨໟ")): bWsVM7A1KOYIq2j0k5836Qw = RRNODILCtGzvgpx(S6NALBOqGn1zi2W5M8y7,ITvnUAMXsyb4eO(u"ࠧࡶࡴ࡯ࠫ໠"))+bWsVM7A1KOYIq2j0k5836Qw
			else: bWsVM7A1KOYIq2j0k5836Qw = S6NALBOqGn1zi2W5M8y7.rsplit(ITvnUAMXsyb4eO(u"ࠨ࠱ࠪ໡"),bXukYxQ4aHw)[ybdv7XcT3lxF6QezULwCAGk]+o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠩ࠲ࠫ໢")+bWsVM7A1KOYIq2j0k5836Qw
		if zyvJMtBhrw(u"ࠪࡴࡷࡵࡧࡳࡧࡶࡷ࡮ࡼࡥ࠮ࡷࡵ࡭ࠬ໣") in list(iQPYeO5BK6fIpWX1mwFH4hu3R0lAxZ.keys()):
			MDSF21x9HK3AZyGUhcb = iQPYeO5BK6fIpWX1mwFH4hu3R0lAxZ[FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠫࡵࡸ࡯ࡨࡴࡨࡷࡸ࡯ࡶࡦ࠯ࡸࡶ࡮࠭໤")]
			MDSF21x9HK3AZyGUhcb = MDSF21x9HK3AZyGUhcb.replace(FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠬࠨࠧ໥"),hWGMqtBy4wuLaVcj).replace(DJ1ICpbyR2(u"ࠨࠧࠣ໦"),hWGMqtBy4wuLaVcj).split(jeAby54c02TgG8zuivonX91(u"ࠧࠤࠩ໧"),bXukYxQ4aHw)[ybdv7XcT3lxF6QezULwCAGk]
			LDceGoKZizXNV9m7bn6SU3W = UGBbEtrcu5jLC6Sxoa3gFyP1mJOpW(MDSF21x9HK3AZyGUhcb)
			if LDceGoKZizXNV9m7bn6SU3W: m4eVoJdSU51qs3y8Gg06fZNau7A = V1VwIdhQ7YoKMzkTqGsjZ6cPAp5JL+FqcVAkh7WjIXHdDKf8nvuyRo+LDceGoKZizXNV9m7bn6SU3W
			else: m4eVoJdSU51qs3y8Gg06fZNau7A = V1VwIdhQ7YoKMzkTqGsjZ6cPAp5JL
			m4eVoJdSU51qs3y8Gg06fZNau7A = m4eVoJdSU51qs3y8Gg06fZNau7A+zyvJMtBhrw(u"ࠨࠢࠣࡔࡷࡵࡧࡳࡧࡶࡷ࡮ࡼࡥࠨ໨")
			m4eVoJdSU51qs3y8Gg06fZNau7A = m4eVoJdSU51qs3y8Gg06fZNau7A+FqcVAkh7WjIXHdDKf8nvuyRo+RRNODILCtGzvgpx(MDSF21x9HK3AZyGUhcb,JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠩࡱࡥࡲ࡫ࠧ໩"))
			haq1bHZINPE58uoBFnKfTSO2ik4.append(m4eVoJdSU51qs3y8Gg06fZNau7A)
			Dvi8asSrQYX5wE3KMIxT91me.append(MDSF21x9HK3AZyGUhcb)
			zEmVTBN1evQPoRpX0H9as84.append(QS8ZdxkHD5bjU9qsn4zMYaPrg3h7)
			dwg0bnuYJry5BiLtTGDWjh.append(fb0MVGEwp5yNkijcSeFXmOa)
		bWsVM7A1KOYIq2j0k5836Qw = bWsVM7A1KOYIq2j0k5836Qw.split(MMizeNH0AKu(u"ࠪࠧࠬ໪"),bXukYxQ4aHw)[ybdv7XcT3lxF6QezULwCAGk]
		LDceGoKZizXNV9m7bn6SU3W = UGBbEtrcu5jLC6Sxoa3gFyP1mJOpW(bWsVM7A1KOYIq2j0k5836Qw)
		if LDceGoKZizXNV9m7bn6SU3W: V1VwIdhQ7YoKMzkTqGsjZ6cPAp5JL = V1VwIdhQ7YoKMzkTqGsjZ6cPAp5JL+FqcVAkh7WjIXHdDKf8nvuyRo+LDceGoKZizXNV9m7bn6SU3W
		V1VwIdhQ7YoKMzkTqGsjZ6cPAp5JL = V1VwIdhQ7YoKMzkTqGsjZ6cPAp5JL+FqcVAkh7WjIXHdDKf8nvuyRo+RRNODILCtGzvgpx(bWsVM7A1KOYIq2j0k5836Qw,JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠫࡳࡧ࡭ࡦࠩ໫"))
		haq1bHZINPE58uoBFnKfTSO2ik4.append(V1VwIdhQ7YoKMzkTqGsjZ6cPAp5JL)
		Dvi8asSrQYX5wE3KMIxT91me.append(bWsVM7A1KOYIq2j0k5836Qw)
		zEmVTBN1evQPoRpX0H9as84.append(QS8ZdxkHD5bjU9qsn4zMYaPrg3h7)
		dwg0bnuYJry5BiLtTGDWjh.append(fb0MVGEwp5yNkijcSeFXmOa)
	iwkQ8Wf5GDxsHTFLrV0Pp14On = list(zip(haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me,zEmVTBN1evQPoRpX0H9as84,dwg0bnuYJry5BiLtTGDWjh))
	iwkQ8Wf5GDxsHTFLrV0Pp14On = sorted(iwkQ8Wf5GDxsHTFLrV0Pp14On, reverse=VBlawK4mgHSyLEn8iqhUkz5, key=lambda key: key[x1x9kIQo3zjZWnYaiy])
	haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me,zEmVTBN1evQPoRpX0H9as84,dwg0bnuYJry5BiLtTGDWjh = list(zip(*iwkQ8Wf5GDxsHTFLrV0Pp14On))
	haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = list(haq1bHZINPE58uoBFnKfTSO2ik4),list(Dvi8asSrQYX5wE3KMIxT91me)
	bQV1Gtm49uZJshH3nWXLPTYrME = []
	for bWsVM7A1KOYIq2j0k5836Qw in Dvi8asSrQYX5wE3KMIxT91me: bQV1Gtm49uZJshH3nWXLPTYrME.append(bWsVM7A1KOYIq2j0k5836Qw+CysMr5Z7vqSenAK0BobTN3)
	return haq1bHZINPE58uoBFnKfTSO2ik4,bQV1Gtm49uZJshH3nWXLPTYrME
def BNeOTHu75qV6p(JfH0yTDjbBchm6Aui7W,T5EshFWwM3J7zH=hWGMqtBy4wuLaVcj):
	if not T5EshFWwM3J7zH: T5EshFWwM3J7zH = vIDJ3z8NTlStsfnW4MOQC20Bo[ybdv7XcT3lxF6QezULwCAGk]
	if JfH0yTDjbBchm6Aui7W.replace(DJ1ICpbyR2(u"ࠬ࠴ࠧ໬"),hWGMqtBy4wuLaVcj).isdigit(): return [JfH0yTDjbBchm6Aui7W]
	from struct import pack as qKbRfXNLh9WA1dTFYVa687DI,unpack_from as r7glOANo6qx5P
	from socket import socket as jFL1meU3RWM78GPlJBNbQHdShuT,AF_INET as hSuRrpxJ1blOyYCDEmFGU,SOCK_DGRAM as pCAEny5eP4tGMIH
	try:
		iaDW523FTVBwQ0xePhEdf6HnAv = qKbRfXNLh9WA1dTFYVa687DI(KNIvHPjUbhr(u"ࠨ࠾ࡉࠤ໭"), mkHKSQvjWr5BTcM3wVY(u"࠴࠶࠵࠺࠹ᐪ"))
		iaDW523FTVBwQ0xePhEdf6HnAv += qKbRfXNLh9WA1dTFYVa687DI(gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠢ࠿ࡊࠥ໮"), EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"࠶࠺࠼ᐫ"))
		iaDW523FTVBwQ0xePhEdf6HnAv += qKbRfXNLh9WA1dTFYVa687DI(wwPrSDa21lUh(u"ࠣࡀࡋࠦ໯"), bXukYxQ4aHw)
		iaDW523FTVBwQ0xePhEdf6HnAv += qKbRfXNLh9WA1dTFYVa687DI(MMizeNH0AKu(u"ࠤࡁࡌࠧ໰"), ybdv7XcT3lxF6QezULwCAGk)
		iaDW523FTVBwQ0xePhEdf6HnAv += qKbRfXNLh9WA1dTFYVa687DI(FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠥࡂࡍࠨ໱"), ybdv7XcT3lxF6QezULwCAGk)
		iaDW523FTVBwQ0xePhEdf6HnAv += qKbRfXNLh9WA1dTFYVa687DI(KBkxSYaz93pu1(u"ࠦࡃࡎࠢ໲"), ybdv7XcT3lxF6QezULwCAGk)
		if H4qZ2hwilNJYTmCFEQyaSs98cPM0gR: thcOGsl9T54LgaFZiK = JfH0yTDjbBchm6Aui7W.split(DJ1ICpbyR2(u"ࠬ࠴ࠧ໳"))
		else: thcOGsl9T54LgaFZiK = JfH0yTDjbBchm6Aui7W.decode(a7VXeDU82IfQEnPZAdiT).split(QvgnCALNstmuUJiET(u"࠭࠮ࠨ໴"))
		for KKB8MPmXr5vZwlTUonqVJD in thcOGsl9T54LgaFZiK:
			tLxsm3CdXpNhzMj0ArIvfgR2 = KKB8MPmXr5vZwlTUonqVJD.encode(a7VXeDU82IfQEnPZAdiT)
			iaDW523FTVBwQ0xePhEdf6HnAv += qKbRfXNLh9WA1dTFYVa687DI(QVDJLRlxNg127jMX(u"ࠢࡃࠤ໵"), len(KKB8MPmXr5vZwlTUonqVJD))
			for Y9E8xSFa3Km in KKB8MPmXr5vZwlTUonqVJD:
				iaDW523FTVBwQ0xePhEdf6HnAv += qKbRfXNLh9WA1dTFYVa687DI(zyvJMtBhrw(u"ࠣࡥࠥ໶"), Y9E8xSFa3Km.encode(a7VXeDU82IfQEnPZAdiT))
		iaDW523FTVBwQ0xePhEdf6HnAv += qKbRfXNLh9WA1dTFYVa687DI(A6dMB1FlgxVivJ2fk9C(u"ࠤࡅࠦ໷"), ybdv7XcT3lxF6QezULwCAGk)
		iaDW523FTVBwQ0xePhEdf6HnAv += qKbRfXNLh9WA1dTFYVa687DI(hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠥࡂࡍࠨ໸"), bXukYxQ4aHw)
		iaDW523FTVBwQ0xePhEdf6HnAv += qKbRfXNLh9WA1dTFYVa687DI(SqrG5mU3j96ldsFpExobw40TJY(u"ࠦࡃࡎࠢ໹"), bXukYxQ4aHw)
		gl6mxQDwOs8I5YW32bkXrGfzie = jFL1meU3RWM78GPlJBNbQHdShuT(hSuRrpxJ1blOyYCDEmFGU,pCAEny5eP4tGMIH)
		gl6mxQDwOs8I5YW32bkXrGfzie.sendto(bytes(iaDW523FTVBwQ0xePhEdf6HnAv), (T5EshFWwM3J7zH, HHoGx7Flus60(u"࠺࠹ᐬ")))
		gl6mxQDwOs8I5YW32bkXrGfzie.settimeout(jeAby54c02TgG8zuivonX91(u"࠼ᐭ"))
		F49URk16JIawgp7YWZAXGtnMb, uuN4bpIcnPalYR = gl6mxQDwOs8I5YW32bkXrGfzie.recvfrom(KNIvHPjUbhr(u"࠱࠱࠴࠷ᐮ"))
		gl6mxQDwOs8I5YW32bkXrGfzie.close()
		ORw7IHMrJz = r7glOANo6qx5P(KNIvHPjUbhr(u"ࠧࡄࡈࡉࡊࡋࡌࡍࠨ໺"), F49URk16JIawgp7YWZAXGtnMb, ybdv7XcT3lxF6QezULwCAGk)
		hjTGpYxK8LboRD = ORw7IHMrJz[x1x9kIQo3zjZWnYaiy]
		jaDz5U1nVIrkAu9y = len(JfH0yTDjbBchm6Aui7W)+ITvnUAMXsyb4eO(u"࠲࠺ᐯ")
		vIzgrEDLkOA = []
		for _LYIFx6OQtvu8iPnmfRw5S7Z in range(hjTGpYxK8LboRD):
			T2mXckFzV0Cvt = jaDz5U1nVIrkAu9y
			LHRVPjQSvYceaB7C04r2 = bXukYxQ4aHw
			WH7UlpvGDXPbi6Lg9 = fEXMiAyG3ql4vKB
			while VBlawK4mgHSyLEn8iqhUkz5:
				Y9E8xSFa3Km = r7glOANo6qx5P(FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠨ࠾ࡃࠤ໻"), F49URk16JIawgp7YWZAXGtnMb, T2mXckFzV0Cvt)[ybdv7XcT3lxF6QezULwCAGk]
				if Y9E8xSFa3Km == ybdv7XcT3lxF6QezULwCAGk:
					T2mXckFzV0Cvt += bXukYxQ4aHw
					break
				if Y9E8xSFa3Km >= SqrG5mU3j96ldsFpExobw40TJY(u"࠳࠼࠶ᐰ"):
					Zx0HPeINVboTqjDtvu = r7glOANo6qx5P(e2qDYgipPmTw4KvBLnochr(u"ࠢ࠿ࡄࠥ໼"), F49URk16JIawgp7YWZAXGtnMb, T2mXckFzV0Cvt + bXukYxQ4aHw)[ybdv7XcT3lxF6QezULwCAGk]
					T2mXckFzV0Cvt = ((Y9E8xSFa3Km << e2qDYgipPmTw4KvBLnochr(u"࠻ᐱ")) + Zx0HPeINVboTqjDtvu - 0xc000) - bXukYxQ4aHw
					WH7UlpvGDXPbi6Lg9 = VBlawK4mgHSyLEn8iqhUkz5
				T2mXckFzV0Cvt += bXukYxQ4aHw
				if WH7UlpvGDXPbi6Lg9 == fEXMiAyG3ql4vKB: LHRVPjQSvYceaB7C04r2 += bXukYxQ4aHw
			if WH7UlpvGDXPbi6Lg9 == VBlawK4mgHSyLEn8iqhUkz5: LHRVPjQSvYceaB7C04r2 += bXukYxQ4aHw
			jaDz5U1nVIrkAu9y = jaDz5U1nVIrkAu9y + LHRVPjQSvYceaB7C04r2
			YrNqclvhTeJLZBgf0 = r7glOANo6qx5P(OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠣࡀࡋࡌࡎࡎࠢ໽"), F49URk16JIawgp7YWZAXGtnMb, jaDz5U1nVIrkAu9y)
			jaDz5U1nVIrkAu9y = jaDz5U1nVIrkAu9y + e2qDYgipPmTw4KvBLnochr(u"࠵࠵ᐲ")
			ZSypGYiuEs63vQeO2d = YrNqclvhTeJLZBgf0[ybdv7XcT3lxF6QezULwCAGk]
			JZbU1EsOkwQuc37xLa9lqYI = YrNqclvhTeJLZBgf0[x1x9kIQo3zjZWnYaiy]
			if ZSypGYiuEs63vQeO2d == bXukYxQ4aHw:
				Bm7G59SLoxZWv8 = r7glOANo6qx5P(GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠤࡁࠦ໾")+dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠥࡆࠧ໿")*JZbU1EsOkwQuc37xLa9lqYI, F49URk16JIawgp7YWZAXGtnMb, jaDz5U1nVIrkAu9y)
				ip = hWGMqtBy4wuLaVcj
				for Y9E8xSFa3Km in Bm7G59SLoxZWv8: ip += str(Y9E8xSFa3Km) + KNIvHPjUbhr(u"ࠫ࠳࠭ༀ")
				ip = ip[ybdv7XcT3lxF6QezULwCAGk:-bXukYxQ4aHw]
				vIzgrEDLkOA.append(ip)
			if ZSypGYiuEs63vQeO2d in [bXukYxQ4aHw,Y0XZKGRAUQj5O,gDuGMR3z1aV6YdLmCpiO8Kl(u"࠵ᐵ"),SqrG5mU3j96ldsFpExobw40TJY(u"࠷ᐶ"),QVDJLRlxNg127jMX(u"࠷࠵ᐴ"),QvgnCALNstmuUJiET(u"࠷࠾ᐳ")]: jaDz5U1nVIrkAu9y = jaDz5U1nVIrkAu9y + JZbU1EsOkwQuc37xLa9lqYI
	except: vIzgrEDLkOA = []
	if not vIzgrEDLkOA: KteLZCbM8W0FqE2OBx1(VRQE4jsXHSfhPWo5DgLwxGk,qhVEWvetzXLOcr1(xjPuFK3EsIZSiobQ5X)+hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠬࠦࠠࠡࡆࡑࡗࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࠠࡧࡣ࡬ࡰࡪࡪࠠࠡࠢࡋࡳࡸࡺ࠺ࠡ࡝ࠣࠫ༁")+JfH0yTDjbBchm6Aui7W+QVDJLRlxNg127jMX(u"࠭ࠠ࡞ࠩ༂"))
	return vIzgrEDLkOA
def Dc20k3vN9hT5(xjPuFK3EsIZSiobQ5X,S6NALBOqGn1zi2W5M8y7,BX029UJFPvpNQsc45jbYZRh,showDialogs=VBlawK4mgHSyLEn8iqhUkz5):
	if BX029UJFPvpNQsc45jbYZRh:
		FEwqHJP7DCR9vc = [hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠧไสสีࠬ༃"),JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠨสส่฿࠭༄"),S1SgCFYGJeMvfp5iZXK(u"ࠩࡤࡨࡺࡲࡴࠨ༅"),HHoGx7Flus60(u"ࠪࡼࡽ࠭༆"),A6dMB1FlgxVivJ2fk9C(u"ࠫࡸ࡫ࡸࠨ༇")]
		if xjPuFK3EsIZSiobQ5X!=FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠬࡈࡏࡌࡔࡄࠫ༈"):
			FEwqHJP7DCR9vc += [EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"࠭ࡲ࠻ࠩ༉"),ITvnUAMXsyb4eO(u"ࠧࡳ࠯ࠪ༊"),QvgnCALNstmuUJiET(u"ࠨ࠯ࡰࡥࠬ་")]
			FEwqHJP7DCR9vc += [zyvJMtBhrw(u"ࠩ࠽ࡶࠬ༌"),hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠪ࠱ࡷ࠭།"),QvgnCALNstmuUJiET(u"ࠫࡲࡧ࠭ࠨ༎")]
		for wqE9AVn6gRFQj in BX029UJFPvpNQsc45jbYZRh:
			if hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠬ࡭ࡥࡵ࠰ࡳ࡬ࡵࡅࠧ༏") in wqE9AVn6gRFQj: continue
			if rwQN9AKhLCuMfHxjlbX0U(u"࠭อๅไฬࠫ༐") in wqE9AVn6gRFQj: continue
			wqE9AVn6gRFQj = wqE9AVn6gRFQj.lower()
			if VKiGj1LundAJQwEXcqgxC: wqE9AVn6gRFQj = wqE9AVn6gRFQj.decode(a7VXeDU82IfQEnPZAdiT).encode(a7VXeDU82IfQEnPZAdiT)
			wqE9AVn6gRFQj = wqE9AVn6gRFQj.replace(jeAby54c02TgG8zuivonX91(u"ࠧ࠻ࠩ༑"),hWGMqtBy4wuLaVcj)
			AYl6g8dekE47UK = trdVA0JvFaD.findall(zyvJMtBhrw(u"ࠨࠪ࠴࡟࠺࠳࠹࡞࠭ࡿ࠶ࡠ࠶࠭࠴࡟࠮࠭ࠬ༒"),wqE9AVn6gRFQj,trdVA0JvFaD.DOTALL)
			F2eJN5vSAgkm3l9V0o8dsXELUb6y = fEXMiAyG3ql4vKB
			for kZpCMeIlFamcQHKuv0r4w7 in AYl6g8dekE47UK:
				if len(kZpCMeIlFamcQHKuv0r4w7)==Y0XZKGRAUQj5O:
					F2eJN5vSAgkm3l9V0o8dsXELUb6y = VBlawK4mgHSyLEn8iqhUkz5
					break
			if LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠩࡱࡳࡹࠦࡲࡢࡶࡨࡨࠬ༓") in wqE9AVn6gRFQj: continue
			elif gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠪࡹࡳࡸࡡࡵࡧࡧࠫ༔") in wqE9AVn6gRFQj: continue
			elif XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠫ฿๐ัࠡ็ุ๊ๆ࠭༕") in wqE9AVn6gRFQj: continue
			elif NNA8aswIZfdr2([OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠬࡈࡔࡆࡺࡓ࡚࠶࠿ࡓࡓࡘࡑ࡙࡚ࡲࡖࡅࡘࡈ࡚ࡊ࡞ࠧ༖")])[ybdv7XcT3lxF6QezULwCAGk]: continue
			elif wqE9AVn6gRFQj in [jeAby54c02TgG8zuivonX91(u"࠭ࡲࠨ༗")] or F2eJN5vSAgkm3l9V0o8dsXELUb6y or any(BoSjXKxz41DcneO9UimClE in wqE9AVn6gRFQj for BoSjXKxz41DcneO9UimClE in FEwqHJP7DCR9vc):
				KteLZCbM8W0FqE2OBx1(VRQE4jsXHSfhPWo5DgLwxGk,qhVEWvetzXLOcr1(xjPuFK3EsIZSiobQ5X)+JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠧࠡࠢࠣࡆࡱࡵࡣ࡬ࡧࡧࠤࡦࡪࡵ࡭ࡶࡶࠤࡻ࡯ࡤࡦࡱࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟༘ࠥ࠭")+S6NALBOqGn1zi2W5M8y7+jeAby54c02TgG8zuivonX91(u"ࠨࠢࡠ༙ࠫ"))
				if showDialogs: OnsAxhdVjZF(sULh4NjakzI8He7xJCMGrql(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ༚"),xcChIL13BpR8WArNt9Pl0So(u"ࠪห้็๊ะ์๋ࠤ้๊ใษษิࠤๆ่ื๊ࠡฦ๊ฬࠦๅ็฻อ๋ࠬ༛"))
				return VBlawK4mgHSyLEn8iqhUkz5
	return fEXMiAyG3ql4vKB
def BZj61bFtfWLzXp(*aargs,**kkwargs):
	if aargs:
		direction = aargs[ybdv7XcT3lxF6QezULwCAGk]
		yGdxzgRarIV5MKh = aargs[bXukYxQ4aHw]
		if not direction: direction = GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ༜")
		if not yGdxzgRarIV5MKh: yGdxzgRarIV5MKh = S1SgCFYGJeMvfp5iZXK(u"ࠬอำห็ิหึ࠭༝")
		zzZmACR6eDtyaYnIlX5vU = aargs[Y0XZKGRAUQj5O]
		XNBHzrlKD9yW = NXMOzZjYsmS9pf.join(aargs[CnbBKmtF1x84q7AW(u"࠵ᐷ"):])
	else: direction,yGdxzgRarIV5MKh,zzZmACR6eDtyaYnIlX5vU,XNBHzrlKD9yW = hWGMqtBy4wuLaVcj,QVDJLRlxNg127jMX(u"࠭ࡏࡌࠩ༞"),hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj
	jbQkTyxAerZR409gYFq(direction,hWGMqtBy4wuLaVcj,yGdxzgRarIV5MKh,hWGMqtBy4wuLaVcj,zzZmACR6eDtyaYnIlX5vU,XNBHzrlKD9yW,**kkwargs)
	return
def XVmKrby29eCGMnlEY6jz0HNOR(*aargs,**kkwargs):
	direction = aargs[ybdv7XcT3lxF6QezULwCAGk]
	O293uiEy05MYT4bwfvg1jW6SLhno = aargs[bXukYxQ4aHw]
	dMFH72KXZjhJOc0aStsCBrYynVgPL = aargs[Y0XZKGRAUQj5O]
	if dMFH72KXZjhJOc0aStsCBrYynVgPL or O293uiEy05MYT4bwfvg1jW6SLhno: W9WJLsjTlQ1qVbNE2FA8rCI = VBlawK4mgHSyLEn8iqhUkz5
	else: W9WJLsjTlQ1qVbNE2FA8rCI = fEXMiAyG3ql4vKB
	zzZmACR6eDtyaYnIlX5vU = aargs[x1x9kIQo3zjZWnYaiy]
	XNBHzrlKD9yW = aargs[jR6BYWNFZ0egmH4Tr2Q78LbSs3t]
	if not direction: direction = gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠧࡤࡧࡱࡸࡪࡸࠧ༟")
	if not O293uiEy05MYT4bwfvg1jW6SLhno: O293uiEy05MYT4bwfvg1jW6SLhno = KBkxSYaz93pu1(u"ࠨๅ็หࠥࠦࡎࡰࠩ༠")
	if not dMFH72KXZjhJOc0aStsCBrYynVgPL: dMFH72KXZjhJOc0aStsCBrYynVgPL = S1SgCFYGJeMvfp5iZXK(u"้ࠩ฽๊࡚ࠦࠠࡧࡶࠫ༡")
	if len(aargs)>=NeO3CTLHrPfWUoIgy8Q(u"࠺ᐹ"): XNBHzrlKD9yW += NXMOzZjYsmS9pf+aargs[hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"࠸ᐸ")]
	if len(aargs)>=LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"࠼ᐺ"): XNBHzrlKD9yW += NXMOzZjYsmS9pf+aargs[JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"࠼ᐻ")]
	c7doTBkbPWtIsGlgeFa58f = jbQkTyxAerZR409gYFq(direction,O293uiEy05MYT4bwfvg1jW6SLhno,hWGMqtBy4wuLaVcj,dMFH72KXZjhJOc0aStsCBrYynVgPL,zzZmACR6eDtyaYnIlX5vU,XNBHzrlKD9yW,**kkwargs)
	if c7doTBkbPWtIsGlgeFa58f==-QvgnCALNstmuUJiET(u"࠱ᐼ") and W9WJLsjTlQ1qVbNE2FA8rCI: c7doTBkbPWtIsGlgeFa58f = -bXukYxQ4aHw
	elif c7doTBkbPWtIsGlgeFa58f==-bXukYxQ4aHw and not W9WJLsjTlQ1qVbNE2FA8rCI: c7doTBkbPWtIsGlgeFa58f = fEXMiAyG3ql4vKB
	elif c7doTBkbPWtIsGlgeFa58f==ybdv7XcT3lxF6QezULwCAGk: c7doTBkbPWtIsGlgeFa58f = fEXMiAyG3ql4vKB
	elif c7doTBkbPWtIsGlgeFa58f==Y0XZKGRAUQj5O: c7doTBkbPWtIsGlgeFa58f = VBlawK4mgHSyLEn8iqhUkz5
	return c7doTBkbPWtIsGlgeFa58f
def Eb7qJoNwOgn(*aargs,**kkwargs):
	return mUWYiQ2jHICA8cD6LhPTn3wpB1XyK.Dialog().select(*aargs,**kkwargs)
def OnsAxhdVjZF(*aargs,**kkwargs):
	zzZmACR6eDtyaYnIlX5vU = aargs[ybdv7XcT3lxF6QezULwCAGk]
	XNBHzrlKD9yW = aargs[bXukYxQ4aHw]
	iiMnoQOmG5vp9NWDAlgL4j3uF6 = kkwargs[sULh4NjakzI8He7xJCMGrql(u"ࠪࡸ࡮ࡳࡥࠨ༢")] if e2qDYgipPmTw4KvBLnochr(u"ࠫࡹ࡯࡭ࡦࠩ༣") in list(kkwargs.keys()) else OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"࠲࠲࠳࠴ᐽ")
	hetVJgH2wObGax1kQiZflB = aargs[Y0XZKGRAUQj5O] if len(aargs)>Y0XZKGRAUQj5O and HHoGx7Flus60(u"ࠬࡺࡩ࡮ࡧࠪ༤") not in aargs[Y0XZKGRAUQj5O] else gDuGMR3z1aV6YdLmCpiO8Kl(u"࠭࡮ࡰࡶ࡬ࡪ࡮ࡩࡡࡵ࡫ࡲࡲࡤࡸࡥࡨࡷ࡯ࡥࡷ࠭༥")
	GtYBimvRdJc7P1L8XbgsAek = KCTRe67wVy.Thread(target=qC4GLe5SIVojpQ1f2cxUBHM,args=(zzZmACR6eDtyaYnIlX5vU,XNBHzrlKD9yW,hetVJgH2wObGax1kQiZflB,iiMnoQOmG5vp9NWDAlgL4j3uF6))
	GtYBimvRdJc7P1L8XbgsAek.start()
	return
def qC4GLe5SIVojpQ1f2cxUBHM(zzZmACR6eDtyaYnIlX5vU,XNBHzrlKD9yW,hetVJgH2wObGax1kQiZflB,iiMnoQOmG5vp9NWDAlgL4j3uF6):
	BR1qPtwE7ra2I3UC4WYnMV9N = hetVJgH2wObGax1kQiZflB.replace(S1SgCFYGJeMvfp5iZXK(u"ࠧ࡯ࡱࡷ࡭࡫࡯ࡣࡢࡶ࡬ࡳࡳࡥࠧ༦"),hWGMqtBy4wuLaVcj)
	name = XFr42BCdkuqpsmZw6NvG39gz7HSK0h(VBlawK4mgHSyLEn8iqhUkz5,BR1qPtwE7ra2I3UC4WYnMV9N+S1SgCFYGJeMvfp5iZXK(u"ࠨࠢ࠰ࠤࠬ༧")+zzZmACR6eDtyaYnIlX5vU+dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠩࠣ࠱ࠥ࠭༨")+XNBHzrlKD9yW)
	name = vJRN3snSxMqBP1dpIGTQX8Yl(name)
	image_filename = WQvYkNg7SysPFLitlGEn6.path.join(xx74tQY9vGjRuXZs,name+S1SgCFYGJeMvfp5iZXK(u"ࠪ࠲ࡵࡴࡧࠨ༩"))
	if WQvYkNg7SysPFLitlGEn6.path.exists(image_filename):
		if hetVJgH2wObGax1kQiZflB==wwPrSDa21lUh(u"ࠫࡳࡵࡴࡪࡨ࡬ࡧࡦࡺࡩࡰࡰࡢࡶࡪ࡭ࡵ࡭ࡣࡵࠫ༪"): image_height = SqrG5mU3j96ldsFpExobw40TJY(u"࠳࠴࠻ᐾ")
		elif hetVJgH2wObGax1kQiZflB==JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠬࡴ࡯ࡵ࡫ࡩ࡭ࡨࡧࡴࡪࡱࡱࡣࡦࡻࡴࡰࠩ༫"): image_height = FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"࠵࠵࠵ᐿ")
	else: image_height = u4HdnJLfyrebDC3Rj8tzkT0VhmQp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,zzZmACR6eDtyaYnIlX5vU,XNBHzrlKD9yW,hetVJgH2wObGax1kQiZflB,A6dMB1FlgxVivJ2fk9C(u"࠭࡬ࡦࡨࡷࠫ༬"),fEXMiAyG3ql4vKB,image_filename)
	H3Y6T7ZdRIFW5fDGyzCUMcjAntJ = LReTm9MyqCHKFIZtv8WYD(ITvnUAMXsyb4eO(u"ࠧࡅ࡫ࡤࡰࡴ࡭ࡎࡰࡶ࡬ࡪ࡮ࡩࡡࡵ࡫ࡲࡲࡎࡳࡡࡨࡧ࠱ࡼࡲࡲࠧ༭"),ggKyfILOkNPGxMtDQueVSZ,hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠨࡆࡨࡪࡦࡻ࡬ࡵࠩ༮"),SqrG5mU3j96ldsFpExobw40TJY(u"ࠩ࠺࠶࠵ࡶࠧ༯"))
	H3Y6T7ZdRIFW5fDGyzCUMcjAntJ.show()
	if hetVJgH2wObGax1kQiZflB==S1SgCFYGJeMvfp5iZXK(u"ࠪࡲࡴࡺࡩࡧ࡫ࡦࡥࡹ࡯࡯࡯ࡡࡤࡹࡹࡵࠧ༰"):
		H3Y6T7ZdRIFW5fDGyzCUMcjAntJ.getControl(FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"࠾࠶࠴࠱ᑁ")).setHeight(wwPrSDa21lUh(u"࠶࠶࠻ᑀ"))
		H3Y6T7ZdRIFW5fDGyzCUMcjAntJ.getControl(OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"࠺࠲࠷࠴ᑄ")).setPosition(gDuGMR3z1aV6YdLmCpiO8Kl(u"࠻࠵ᑂ"),-rwQN9AKhLCuMfHxjlbX0U(u"࠸࠱ᑃ"))
		H3Y6T7ZdRIFW5fDGyzCUMcjAntJ.getControl(HHoGx7Flus60(u"࠻࠳࠹࠵ᑅ")).setPosition(LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"࠴࠶࠵ᑆ"),-FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"࠺࠵ᑇ"))
		H3Y6T7ZdRIFW5fDGyzCUMcjAntJ.getControl(wwPrSDa21lUh(u"࠴࠱࠲ᑊ")).setPosition(KNIvHPjUbhr(u"࠾࠶ᑈ"),-DJ1ICpbyR2(u"࠹࠵ᑉ"))
	H3Y6T7ZdRIFW5fDGyzCUMcjAntJ.getControl(DJ1ICpbyR2(u"࠵࠲࠴ᑋ")).setVisible(fEXMiAyG3ql4vKB)
	H3Y6T7ZdRIFW5fDGyzCUMcjAntJ.getControl(JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"࠶࠳࠶ᑌ")).setVisible(fEXMiAyG3ql4vKB)
	H3Y6T7ZdRIFW5fDGyzCUMcjAntJ.getControl(rwQN9AKhLCuMfHxjlbX0U(u"࠼࠴࠺࠶ᑍ")).setImage(image_filename)
	H3Y6T7ZdRIFW5fDGyzCUMcjAntJ.getControl(KNIvHPjUbhr(u"࠽࠵࠻࠰ᑎ")).setHeight(image_height)
	HB5PvxRhwM.sleep(iiMnoQOmG5vp9NWDAlgL4j3uF6//sULh4NjakzI8He7xJCMGrql(u"࠶࠶࠰࠱࠰࠳ᑏ"))
	return
def zJEnrfcbUOg2ihV5MW7KT4PZm(*aargs,**kkwargs):
	zzZmACR6eDtyaYnIlX5vU,XNBHzrlKD9yW,profile,direction = hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺ࡟࡭ࡱࡱ࡫ࠬ༱"),XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠬࡲࡥࡧࡶࠪ༲")
	if len(aargs)>=bXukYxQ4aHw: zzZmACR6eDtyaYnIlX5vU = aargs[ybdv7XcT3lxF6QezULwCAGk]
	if len(aargs)>=Y0XZKGRAUQj5O: XNBHzrlKD9yW = aargs[bXukYxQ4aHw]
	if len(aargs)>=x1x9kIQo3zjZWnYaiy: profile = aargs[Y0XZKGRAUQj5O]
	if len(aargs)>=jR6BYWNFZ0egmH4Tr2Q78LbSs3t: direction = aargs[x1x9kIQo3zjZWnYaiy]
	return yBv4YaSomFrkejwgNA7pDnKudCz(direction,zzZmACR6eDtyaYnIlX5vU,XNBHzrlKD9yW,profile)
def tw36hiVuYD1G9jlBp(*aargs,**kkwargs):
	return mUWYiQ2jHICA8cD6LhPTn3wpB1XyK.Dialog().contextmenu(*aargs,**kkwargs)
def RD8CiwWAtQ(*aargs,**kkwargs):
	return mUWYiQ2jHICA8cD6LhPTn3wpB1XyK.Dialog().browseSingle(*aargs,**kkwargs)
def pXyrkEW8m64sDeAzfH(*aargs,**kkwargs):
	return mUWYiQ2jHICA8cD6LhPTn3wpB1XyK.Dialog().input(*aargs,**kkwargs)
def Tbof9Jl4eHnYZMvVEBFgCh1G3mLtd(*aargs,**kkwargs):
	return mUWYiQ2jHICA8cD6LhPTn3wpB1XyK.DialogProgress(*aargs,**kkwargs)
def jbQkTyxAerZR409gYFq(direction,button0=hWGMqtBy4wuLaVcj,button1=hWGMqtBy4wuLaVcj,button2=hWGMqtBy4wuLaVcj,zzZmACR6eDtyaYnIlX5vU=hWGMqtBy4wuLaVcj,XNBHzrlKD9yW=hWGMqtBy4wuLaVcj,profile=wwPrSDa21lUh(u"࠭ࡣࡰࡰࡩ࡭ࡷࡳ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨ༳"),qLNFP0GcmKYM2JuekfD=ybdv7XcT3lxF6QezULwCAGk,BnbPtxmrdkXfO3UsI12lWAZihMJ6=ybdv7XcT3lxF6QezULwCAGk):
	if not direction: direction = NeO3CTLHrPfWUoIgy8Q(u"ࠧࡤࡧࡱࡸࡪࡸࠧ༴")
	H3Y6T7ZdRIFW5fDGyzCUMcjAntJ = z1HcSxJQi6Tak(QvgnCALNstmuUJiET(u"ࠨࡆ࡬ࡥࡱࡵࡧࡄࡱࡱࡪ࡮ࡸ࡭ࡕࡪࡵࡩࡪࡈࡵࡵࡶࡲࡲࡸ࠴ࡸ࡮࡮༵ࠪ"),ggKyfILOkNPGxMtDQueVSZ,CnbBKmtF1x84q7AW(u"ࠩࡇࡩ࡫ࡧࡵ࡭ࡶࠪ༶"),CnbBKmtF1x84q7AW(u"ࠪ࠻࠷࠶ࡰࠨ༷"))
	H3Y6T7ZdRIFW5fDGyzCUMcjAntJ.Ruz8pSYFVEt(button0,button1,button2,zzZmACR6eDtyaYnIlX5vU,XNBHzrlKD9yW,profile,direction,qLNFP0GcmKYM2JuekfD,BnbPtxmrdkXfO3UsI12lWAZihMJ6)
	if qLNFP0GcmKYM2JuekfD>ybdv7XcT3lxF6QezULwCAGk: H3Y6T7ZdRIFW5fDGyzCUMcjAntJ.RZnowUrJ0kfO9HeL3IGai()
	if BnbPtxmrdkXfO3UsI12lWAZihMJ6>ybdv7XcT3lxF6QezULwCAGk: H3Y6T7ZdRIFW5fDGyzCUMcjAntJ.SP8eLAK3y0o4RpGfE7H1j()
	if qLNFP0GcmKYM2JuekfD==ybdv7XcT3lxF6QezULwCAGk and BnbPtxmrdkXfO3UsI12lWAZihMJ6==ybdv7XcT3lxF6QezULwCAGk: H3Y6T7ZdRIFW5fDGyzCUMcjAntJ.anl20QKDE5iUeMf()
	H3Y6T7ZdRIFW5fDGyzCUMcjAntJ.doModal()
	c7doTBkbPWtIsGlgeFa58f = H3Y6T7ZdRIFW5fDGyzCUMcjAntJ.choiceID
	return c7doTBkbPWtIsGlgeFa58f
def yBv4YaSomFrkejwgNA7pDnKudCz(direction,zzZmACR6eDtyaYnIlX5vU,XNBHzrlKD9yW,profile=zyvJMtBhrw(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺ࡟࡭ࡱࡱ࡫ࠬ༸")):
	if not direction: direction = e2qDYgipPmTw4KvBLnochr(u"ࠬࡲࡥࡧࡶ༹ࠪ")
	H3Y6T7ZdRIFW5fDGyzCUMcjAntJ = LReTm9MyqCHKFIZtv8WYD(SqrG5mU3j96ldsFpExobw40TJY(u"࠭ࡄࡪࡣ࡯ࡳ࡬࡚ࡥࡹࡶ࡙࡭ࡪࡽࡥࡳࡈࡸࡰࡱ࡙ࡣࡳࡧࡨࡲ࠳ࡾ࡭࡭ࠩ༺"),ggKyfILOkNPGxMtDQueVSZ,A6dMB1FlgxVivJ2fk9C(u"ࠧࡅࡧࡩࡥࡺࡲࡴࠨ༻"),ITvnUAMXsyb4eO(u"ࠨ࠹࠵࠴ࡵ࠭༼"))
	image_filename = UUszEDWjBZTu3rOSF4v1.replace(FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠩࡢ࠴࠵࠶࠰ࡠࠩ༽"),rwQN9AKhLCuMfHxjlbX0U(u"ࠪࡣࠬ༾")+str(HB5PvxRhwM.time())+EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠫࡤ࠭༿"))
	image_filename = image_filename.replace(LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠬࡢ࡜ࠨཀ"),EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"࠭࡜࡝࡞࡟ࠫཁ")).replace(KBkxSYaz93pu1(u"ࠧ࠰࠱ࠪག"),S1SgCFYGJeMvfp5iZXK(u"ࠨ࠱࠲࠳࠴࠭གྷ"))
	image_height = u4HdnJLfyrebDC3Rj8tzkT0VhmQp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,zzZmACR6eDtyaYnIlX5vU,XNBHzrlKD9yW,profile,direction,fEXMiAyG3ql4vKB,image_filename)
	H3Y6T7ZdRIFW5fDGyzCUMcjAntJ.show()
	H3Y6T7ZdRIFW5fDGyzCUMcjAntJ.getControl(OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"࠿࠰࠶࠲ᑐ")).setHeight(image_height)
	H3Y6T7ZdRIFW5fDGyzCUMcjAntJ.getControl(LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"࠹࠱࠷࠳ᑑ")).setImage(image_filename)
	DTloYF7kyQXrR = H3Y6T7ZdRIFW5fDGyzCUMcjAntJ.doModal()
	try: WQvYkNg7SysPFLitlGEn6.remove(image_filename)
	except: pass
	return DTloYF7kyQXrR
def OB6QYAMUnPiWXgpkTrItV48FqZSjdR(Y4YryxXoenGwjl5g=VBlawK4mgHSyLEn8iqhUkz5):
	if Y4YryxXoenGwjl5g:
		o0ST4d1BWzi7r3OnK9ucCXxw = Mqk51CFBym0pIQXZLsOxSJ(MM5Dx39f7ULhcJsRptzIowP,S1SgCFYGJeMvfp5iZXK(u"ࠩࡶࡸࡷ࠭ང"),CnbBKmtF1x84q7AW(u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭ཅ"),zyvJMtBhrw(u"࡚࡙ࠫࡅࡓࡃࡊࡉࡓ࡚ࠧཆ"))
		if o0ST4d1BWzi7r3OnK9ucCXxw: return o0ST4d1BWzi7r3OnK9ucCXxw
	XNBHzrlKD9yW = hWGMqtBy4wuLaVcj
	if ybdv7XcT3lxF6QezULwCAGk and BUXsmKe5dGpJj09REb6HqcO7tNv.succeeded:
		wYZ9hmIlS3cv17s2W = BUXsmKe5dGpJj09REb6HqcO7tNv.content
		SyHorjp3UgM7ZC51 = wYZ9hmIlS3cv17s2W.count(QVDJLRlxNg127jMX(u"ࠬࡓ࡯ࡻ࡫࡯ࡰࡦ࠭ཇ"))
		if SyHorjp3UgM7ZC51>JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"࠹࠲ᑒ"):
			XNBHzrlKD9yW = trdVA0JvFaD.findall(sULh4NjakzI8He7xJCMGrql(u"࠭ࡧࡦࡶ࠰ࡸ࡭࡫࠭࡭࡫ࡶࡸ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ཈"),wYZ9hmIlS3cv17s2W,trdVA0JvFaD.DOTALL)
			XNBHzrlKD9yW = XNBHzrlKD9yW[ybdv7XcT3lxF6QezULwCAGk]
	if not XNBHzrlKD9yW:
		N8cJw93zYSDIf = WQvYkNg7SysPFLitlGEn6.path.join(ggKyfILOkNPGxMtDQueVSZ,FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠧࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭ཉ"),DJ1ICpbyR2(u"ࠨࡷࡶࡩࡷࡧࡧࡦࡰࡷࡷ࠳ࡺࡸࡵࠩཊ"))
		XNBHzrlKD9yW = open(N8cJw93zYSDIf,jeAby54c02TgG8zuivonX91(u"ࠩࡵࡦࠬཋ")).read()
		if H4qZ2hwilNJYTmCFEQyaSs98cPM0gR: XNBHzrlKD9yW = XNBHzrlKD9yW.decode(a7VXeDU82IfQEnPZAdiT)
		XNBHzrlKD9yW = XNBHzrlKD9yW.replace(y6eSQlZEV8uwKG5M3,hWGMqtBy4wuLaVcj)
	ICvrmDnsZoq7 = trdVA0JvFaD.findall(ITvnUAMXsyb4eO(u"ࠪࠬࡒࡵࡺࡪ࡮࡯ࡥ࠳࠰࠿ࠪ࡞ࡱࠫཌ"),XNBHzrlKD9yW,trdVA0JvFaD.DOTALL)
	k34kpwzavhemSg6J8VYB5AbcZ2TU = []
	for O1wKxLtr08BhHUFaQlVCdk3e5gDpz9 in ICvrmDnsZoq7:
		v5GN8l04VpEfP7d = O1wKxLtr08BhHUFaQlVCdk3e5gDpz9.lower()
		if JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠫࡦࡴࡤࡳࡱ࡬ࡨࠬཌྷ") in v5GN8l04VpEfP7d: continue
		if S1SgCFYGJeMvfp5iZXK(u"ࠬࡻࡢࡶࡰࡷࡹࠬཎ") in v5GN8l04VpEfP7d: continue
		if mkHKSQvjWr5BTcM3wVY(u"࠭ࡩࡱࡪࡲࡲࡪ࠭ཏ") in v5GN8l04VpEfP7d: continue
		if LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠧࡤࡴࡲࡷࠬཐ") in v5GN8l04VpEfP7d: continue
		k34kpwzavhemSg6J8VYB5AbcZ2TU.append(O1wKxLtr08BhHUFaQlVCdk3e5gDpz9)
	o0ST4d1BWzi7r3OnK9ucCXxw = eOmXSF6kIWV7yqKCR.sample(k34kpwzavhemSg6J8VYB5AbcZ2TU,bXukYxQ4aHw)
	o0ST4d1BWzi7r3OnK9ucCXxw = o0ST4d1BWzi7r3OnK9ucCXxw[ybdv7XcT3lxF6QezULwCAGk]
	BxuD7iQRpW1(MM5Dx39f7ULhcJsRptzIowP,HHoGx7Flus60(u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫད"),sULh4NjakzI8He7xJCMGrql(u"ࠩࡘࡗࡊࡘࡁࡈࡇࡑࡘࠬདྷ"),o0ST4d1BWzi7r3OnK9ucCXxw,KqO5BWGQR9JVL)
	return o0ST4d1BWzi7r3OnK9ucCXxw
def OHVmqy3Zi1(wF5zRoQekA9lxOYacnju13yUIDs=hWGMqtBy4wuLaVcj):
	if not wF5zRoQekA9lxOYacnju13yUIDs: wF5zRoQekA9lxOYacnju13yUIDs = R7RLCd9kyl.format_exc()
	if gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠪࡗࡾࡹࡴࡦ࡯ࡈࡼ࡮ࡺࠧན") in wF5zRoQekA9lxOYacnju13yUIDs or sULh4NjakzI8He7xJCMGrql(u"ࠫࡤࡥ࡟ࡇࡑࡕࡇࡊࡥࡅ࡙ࡋࡗࡣࡤࡥࠧཔ") in wF5zRoQekA9lxOYacnju13yUIDs: return
	if wF5zRoQekA9lxOYacnju13yUIDs!=o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠬࡔ࡯࡯ࡧࡗࡽࡵ࡫࠺ࠡࡐࡲࡲࡪࡢ࡮ࠨཕ"): zGjD5QAkd7SO9YPcZl.stderr.write(wF5zRoQekA9lxOYacnju13yUIDs)
	yefFjNXHl7 = wF5zRoQekA9lxOYacnju13yUIDs.splitlines()
	nKh8r540GQBVPTokjZ2 = yefFjNXHl7[-jeAby54c02TgG8zuivonX91(u"࠳ᑓ")]
	qU2ucroB5svVOayhigt9GZfKEMW3 = open(OG6qjT5MQi4lIe,KBkxSYaz93pu1(u"࠭ࡲࡣࠩབ")).read()
	if H4qZ2hwilNJYTmCFEQyaSs98cPM0gR: qU2ucroB5svVOayhigt9GZfKEMW3 = qU2ucroB5svVOayhigt9GZfKEMW3.decode(a7VXeDU82IfQEnPZAdiT)
	qU2ucroB5svVOayhigt9GZfKEMW3 = qU2ucroB5svVOayhigt9GZfKEMW3[-EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"࠻࠴࠵࠶ᑔ"):]
	xL3dgJWbrpso = A6dMB1FlgxVivJ2fk9C(u"ࠧ࠾ࠩབྷ")*DJ1ICpbyR2(u"࠵࠵࠶ᑕ")
	if xL3dgJWbrpso in qU2ucroB5svVOayhigt9GZfKEMW3: qU2ucroB5svVOayhigt9GZfKEMW3 = qU2ucroB5svVOayhigt9GZfKEMW3.rsplit(xL3dgJWbrpso,bXukYxQ4aHw)[bXukYxQ4aHw]
	if nKh8r540GQBVPTokjZ2 in qU2ucroB5svVOayhigt9GZfKEMW3: qU2ucroB5svVOayhigt9GZfKEMW3 = qU2ucroB5svVOayhigt9GZfKEMW3.rsplit(nKh8r540GQBVPTokjZ2,bXukYxQ4aHw)[ybdv7XcT3lxF6QezULwCAGk]
	tO1GiUvAflF7Mm = trdVA0JvFaD.findall(QvgnCALNstmuUJiET(u"ࠨࠪࡖࡳࡺࡸࡣࡦࡾࡐࡳࡩ࡫ࠩ࠻ࠢ࡟࡟ࠥ࠮࠮ࠫࡁࠬࠤࡡࡣࠧམ"),qU2ucroB5svVOayhigt9GZfKEMW3,trdVA0JvFaD.DOTALL)
	for xv1FGZNrkz0qJ3WdbU29OHQhPDIVY,dUWFtBQ3cpoIZ9 in reversed(tO1GiUvAflF7Mm):
		if dUWFtBQ3cpoIZ9: break
	else: dUWFtBQ3cpoIZ9 = GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠩࡑࡓ࡙ࠦࡓࡑࡇࡆࡍࡋࡏࡅࡅࠩཙ")
	QTkAP1Nv4cDU0mVuWirzpafolHxF6,O1wKxLtr08BhHUFaQlVCdk3e5gDpz9,hRcFeH8SnCvqt2pBLkfGEU = hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj
	vIe6cP9Gb4DCKizQB = LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠪ࡟ࡗ࡚ࡌ࡞ࠩཚ")+soMVfbr6WtpNlcSA+SqrG5mU3j96ldsFpExobw40TJY(u"ࠫฬ๊ฮุล࠽ࠤࠥ࠭ཛ")+YYSh2J6BIrsm8+nKh8r540GQBVPTokjZ2
	s93uy4YSpalAxZ2rQ = ITvnUAMXsyb4eO(u"ࠬࡡࡒࡕࡎࡠࠫཛྷ")+soMVfbr6WtpNlcSA+e2qDYgipPmTw4KvBLnochr(u"࠭วๅ็ุำึࡀࠠࠡࠩཝ")+YYSh2J6BIrsm8+dUWFtBQ3cpoIZ9
	for TwWgmFrnZoDOVaYi4IhjlSk8pe2 in reversed(yefFjNXHl7):
		if CnbBKmtF1x84q7AW(u"ࠧࡇ࡫࡯ࡩࠥࠨࠧཞ") in TwWgmFrnZoDOVaYi4IhjlSk8pe2 and hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠨࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧཟ") in TwWgmFrnZoDOVaYi4IhjlSk8pe2: break
	TwWgmFrnZoDOVaYi4IhjlSk8pe2 = trdVA0JvFaD.findall(sULh4NjakzI8He7xJCMGrql(u"ࠩࡉ࡭ࡱ࡫ࠠࠣࠪ࠱࠮ࡄ࠯ࠢ࡝࠮ࠣࡰ࡮ࡴࡥࠡࠪ࠱࠮ࡄ࠯࡜࠭ࠢ࡬ࡲࠥ࠮࠮ࠫࡁࠬࠨࠬའ"),TwWgmFrnZoDOVaYi4IhjlSk8pe2,trdVA0JvFaD.DOTALL)
	if TwWgmFrnZoDOVaYi4IhjlSk8pe2:
		QTkAP1Nv4cDU0mVuWirzpafolHxF6,O1wKxLtr08BhHUFaQlVCdk3e5gDpz9,hRcFeH8SnCvqt2pBLkfGEU = TwWgmFrnZoDOVaYi4IhjlSk8pe2[ybdv7XcT3lxF6QezULwCAGk]
		if jeAby54c02TgG8zuivonX91(u"ࠪ࠳ࠬཡ") in QTkAP1Nv4cDU0mVuWirzpafolHxF6: QTkAP1Nv4cDU0mVuWirzpafolHxF6 = QTkAP1Nv4cDU0mVuWirzpafolHxF6.rsplit(GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠫ࠴࠭ར"),bXukYxQ4aHw)[bXukYxQ4aHw]
		else: QTkAP1Nv4cDU0mVuWirzpafolHxF6 = QTkAP1Nv4cDU0mVuWirzpafolHxF6.rsplit(JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠬࡢ࡜ࠨལ"),bXukYxQ4aHw)[bXukYxQ4aHw]
		cbs9VNgdpmnYlqxahvDWGUkjRESK3o = e2qDYgipPmTw4KvBLnochr(u"࡛࠭ࡓࡖࡏࡡࠬཤ")+soMVfbr6WtpNlcSA+A6dMB1FlgxVivJ2fk9C(u"ࠧศๆ่่ๆࡀࠠࠡࠩཥ")+YYSh2J6BIrsm8+QTkAP1Nv4cDU0mVuWirzpafolHxF6
		f9DZTF7EJI8qpSdlO = S1SgCFYGJeMvfp5iZXK(u"ࠨ࡝ࡕࡘࡑࡣࠧས")+soMVfbr6WtpNlcSA+dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠩสุ่฽ั࠻ࠢࠣࠫཧ")+YYSh2J6BIrsm8+O1wKxLtr08BhHUFaQlVCdk3e5gDpz9
		qrb0lY1X9zAf = GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠪ࡟ࡗ࡚ࡌ࡞ࠩཨ")+soMVfbr6WtpNlcSA+LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠫฬ๊ๅไษ้࠾ࠥࠦࠧཀྵ")+YYSh2J6BIrsm8+hRcFeH8SnCvqt2pBLkfGEU
		SnI4kxDXvV78cmMqFCsG1 = cbs9VNgdpmnYlqxahvDWGUkjRESK3o+NXMOzZjYsmS9pf+f9DZTF7EJI8qpSdlO+NXMOzZjYsmS9pf+qrb0lY1X9zAf+NXMOzZjYsmS9pf+s93uy4YSpalAxZ2rQ+NXMOzZjYsmS9pf+vIe6cP9Gb4DCKizQB
		ZZMV7Px6iqCcT0ymtaulXwL = f9DZTF7EJI8qpSdlO+NXMOzZjYsmS9pf+s93uy4YSpalAxZ2rQ+NXMOzZjYsmS9pf+vIe6cP9Gb4DCKizQB+NXMOzZjYsmS9pf+cbs9VNgdpmnYlqxahvDWGUkjRESK3o+NXMOzZjYsmS9pf+qrb0lY1X9zAf
		u98w6XaPfEQen = f9DZTF7EJI8qpSdlO+NXMOzZjYsmS9pf+vIe6cP9Gb4DCKizQB+NXMOzZjYsmS9pf+cbs9VNgdpmnYlqxahvDWGUkjRESK3o+NXMOzZjYsmS9pf+qrb0lY1X9zAf
	else:
		cbs9VNgdpmnYlqxahvDWGUkjRESK3o,f9DZTF7EJI8qpSdlO,qrb0lY1X9zAf = hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj
		SnI4kxDXvV78cmMqFCsG1 = s93uy4YSpalAxZ2rQ+zyvJMtBhrw(u"ࠬࡢ࡮࡝ࡰࠪཪ")+vIe6cP9Gb4DCKizQB
		ZZMV7Px6iqCcT0ymtaulXwL = s93uy4YSpalAxZ2rQ+gDuGMR3z1aV6YdLmCpiO8Kl(u"࠭࡜࡯࡞ࡱࠫཫ")+vIe6cP9Gb4DCKizQB
		u98w6XaPfEQen = vIe6cP9Gb4DCKizQB
	R64JBqKxEAHFQmUIrNicvnXZhT7z = HHoGx7Flus60(u"ࠧฮัฮࠤำ฽รࠡ฼ํี๋ࠥโึ๊าࠫཬ")+NXMOzZjYsmS9pf
	EE2I8iHJDy6 = KbCpy1XTILsEoSj73hidn6B0D5R8mF()
	D4UO3XfA7cQgxN20ZwCL1 = []
	N6NCYivtV4I5rEXq = EE2I8iHJDy6[xcChIL13BpR8WArNt9Pl0So(u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭཭")]
	VwLsAG8BFIDWjzJ3kv9xcHXK5gRh = w0yCzjaYOfEProxWik7lNXt8nA(aO9cFKo862LqTWlIjy)
	if wwPrSDa21lUh(u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧ཮") in list(EE2I8iHJDy6.keys()):
		for QP8x2LzMOdkKiNDbopTH4l,CawBVh3gULkZq45iQ9,sf9gX0F2qO4JM6 in N6NCYivtV4I5rEXq:
			D4UO3XfA7cQgxN20ZwCL1 = max(D4UO3XfA7cQgxN20ZwCL1,CawBVh3gULkZq45iQ9)
		if VwLsAG8BFIDWjzJ3kv9xcHXK5gRh<D4UO3XfA7cQgxN20ZwCL1:
			zzZmACR6eDtyaYnIlX5vU = JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠪๆ๊ࠦศหฯา๎ะࠦวๅสิ๊ฬ๋ฬࠡไห่ࠥหัิษ็ࠤฬ๊รฯูสล๊ࠥไๆสิ้ั࠭཯")
			c7doTBkbPWtIsGlgeFa58f = jbQkTyxAerZR409gYFq(EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠫࡷ࡯ࡧࡩࡶࠪ཰"),S1SgCFYGJeMvfp5iZXK(u"ࠬหัิษ็ࠤส๊้ࠡษ็้อืๅอཱࠩ"),KBkxSYaz93pu1(u"࠭สฮัํฯིࠬ"),QvgnCALNstmuUJiET(u"ࠧฯำ๋ะཱིࠬ"),R64JBqKxEAHFQmUIrNicvnXZhT7z+zzZmACR6eDtyaYnIlX5vU,SnI4kxDXvV78cmMqFCsG1)
			if c7doTBkbPWtIsGlgeFa58f==bXukYxQ4aHw:
				import ZGYSlz63X1
				ZGYSlz63X1.Y6MUwOztEjeTSW7Ha(VBlawK4mgHSyLEn8iqhUkz5)
				Za2Eugh8Mp1eQYH4()
			elif c7doTBkbPWtIsGlgeFa58f==Y0XZKGRAUQj5O: Za2Eugh8Mp1eQYH4()
	Dsa06E8djiBmUN3HSVXgLM5pF72 = Mqk51CFBym0pIQXZLsOxSJ(MM5Dx39f7ULhcJsRptzIowP,xcChIL13BpR8WArNt9Pl0So(u"ࠨ࡮࡬ࡷࡹུ࠭"),hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑཱུࠬ"),xcChIL13BpR8WArNt9Pl0So(u"ࠪࡅࡑࡒ࡟ࡔࡇࡑࡘࡤࡋࡒࡓࡑࡕࡗࠬྲྀ"))
	if not Dsa06E8djiBmUN3HSVXgLM5pF72: Dsa06E8djiBmUN3HSVXgLM5pF72 = []
	ZZMV7Px6iqCcT0ymtaulXwL = ZZMV7Px6iqCcT0ymtaulXwL.replace(NXMOzZjYsmS9pf,EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠫࡡࡢ࡮ࠨཷ")).replace(JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠬࡡࡒࡕࡎࡠࠫླྀ"),hWGMqtBy4wuLaVcj).replace(soMVfbr6WtpNlcSA,hWGMqtBy4wuLaVcj).replace(YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj)
	u98w6XaPfEQen = u98w6XaPfEQen.replace(NXMOzZjYsmS9pf,sULh4NjakzI8He7xJCMGrql(u"࠭࡜࡝ࡰࠪཹ")).replace(JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠧ࡜ࡔࡗࡐࡢེ࠭"),hWGMqtBy4wuLaVcj).replace(soMVfbr6WtpNlcSA,hWGMqtBy4wuLaVcj).replace(YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj)
	LvhBAVtODxJKjgSoWH6sGi5lY = aO9cFKo862LqTWlIjy+gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠨ࠼࠽ཻࠫ")+u98w6XaPfEQen
	if LvhBAVtODxJKjgSoWH6sGi5lY in Dsa06E8djiBmUN3HSVXgLM5pF72:
		zzZmACR6eDtyaYnIlX5vU = KNIvHPjUbhr(u"ࠩ็ๆิࠦโๆฬࠣห๋ะࠠิษหๆฬࠦศฦำึห้ࠦ็ัษࠣห้ิืฤࠢศ่๎ࠦวๅ็หี๊าོࠧ")
		BZj61bFtfWLzXp(dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠪࡶ࡮࡭ࡨࡵཽࠩ"),hWGMqtBy4wuLaVcj,R64JBqKxEAHFQmUIrNicvnXZhT7z+zzZmACR6eDtyaYnIlX5vU,SnI4kxDXvV78cmMqFCsG1)
		return
	wQGpsjtxoEZ5vDh = str(guSzmUCXDa1tQpY).split(JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠫ࠳࠭ཾ"))[ybdv7XcT3lxF6QezULwCAGk]
	S6NALBOqGn1zi2W5M8y7 = u6rbxnyjTl7I[A6dMB1FlgxVivJ2fk9C(u"ࠬࡖ࡙ࡕࡊࡒࡒࠬཿ")][zyvJMtBhrw(u"࠻ᑖ")]
	BUXsmKe5dGpJj09REb6HqcO7tNv = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(nHBb7jXk0Daom,KNIvHPjUbhr(u"࠭ࡐࡐࡕࡗྀࠫ"),S6NALBOqGn1zi2W5M8y7,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,wwPrSDa21lUh(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡕࡋࡓ࡜ࡥࡅ࡙ࡋࡗࡣࡊࡘࡒࡐࡔࡖ࠱࠶ࡹࡴࠨཱྀ"),fEXMiAyG3ql4vKB,fEXMiAyG3ql4vKB)
	wYZ9hmIlS3cv17s2W = BUXsmKe5dGpJj09REb6HqcO7tNv.content
	F8ZjHnMoAGi9syhav4Ck3czbElgLw = trdVA0JvFaD.findall(XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠨࡕࡗࡅࡗ࡚࠺࠻ࡕࡗࡅࡗ࡚࡛࡝ࡴ࡟ࡲࡢ࠱࠺࠻ࠪ࠱࠮ࡄ࠯࡛࡝ࡴ࡟ࡲࡢ࠱࠺࠻ࠪ࠱࠮ࡄ࠯࡛࡝ࡴ࡟ࡲࡢ࠱࠺࠻ࠪ࠱࠮ࡄ࠯࡛࡝ࡴ࡟ࡲࡢ࠱࠺࠻ࠪ࠱࠮ࡄ࠯࡛࡝ࡴ࡟ࡲࡢ࠱ࡅࡏࡆ࠽࠾ࡊࡔࡄࠨྂ"),wYZ9hmIlS3cv17s2W,trdVA0JvFaD.DOTALL)
	for Vr2QCwSeMEBn4X,DQcUY8bBn3yOHIlajN1kmrSZhd,XZFk4eD3HUApMd9r,E7xABl2cmMQZk9L1aybGte in F8ZjHnMoAGi9syhav4Ck3czbElgLw:
		Vr2QCwSeMEBn4X = Vr2QCwSeMEBn4X.split(SqrG5mU3j96ldsFpExobw40TJY(u"ࠩ࠮ࠫྃ"))
		XZFk4eD3HUApMd9r = XZFk4eD3HUApMd9r.split(XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠪ࠯྄ࠬ"))
		E7xABl2cmMQZk9L1aybGte = E7xABl2cmMQZk9L1aybGte.split(XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠫ࠰࠭྅"))
		if O1wKxLtr08BhHUFaQlVCdk3e5gDpz9 in Vr2QCwSeMEBn4X and nKh8r540GQBVPTokjZ2==DQcUY8bBn3yOHIlajN1kmrSZhd and aO9cFKo862LqTWlIjy in XZFk4eD3HUApMd9r and wQGpsjtxoEZ5vDh in E7xABl2cmMQZk9L1aybGte:
			zzZmACR6eDtyaYnIlX5vU = hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠬํะศࠢส่ำ฽รࠡ็฼ีํ็้ࠠีํ฽ฬ๊ฬࠡสส่ส฻ฯศำࠣห้่วะ็ࠪ྆")
			dHPVDWfG4jX5e6QEo0CKh = XVmKrby29eCGMnlEY6jz0HNOR(JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"࠭ࡲࡪࡩ࡫ࡸࠬ྇"),LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠧฯำ๋ะࠬྈ"),ITvnUAMXsyb4eO(u"ࠨวิืฬ๊ࠠฦๆ์ࠤฬ๊ๅษำ่ะࠬྉ"),R64JBqKxEAHFQmUIrNicvnXZhT7z+zzZmACR6eDtyaYnIlX5vU,SnI4kxDXvV78cmMqFCsG1)
			if dHPVDWfG4jX5e6QEo0CKh==bXukYxQ4aHw: BZj61bFtfWLzXp(sULh4NjakzI8He7xJCMGrql(u"ࠩࡦࡩࡳࡺࡥࡳࠩྊ"),hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,zzZmACR6eDtyaYnIlX5vU)
			return
	zzZmACR6eDtyaYnIlX5vU = QvgnCALNstmuUJiET(u"ࠪห้ืฬศรࠣษึูวๅ๊ࠢิฬࠦวๅะฺวࠥหไ๊ࠢส่๊ฮัๆฮࠪྋ")
	FhbZWrHPw6puX43VzJndxTDa = jbQkTyxAerZR409gYFq(zyvJMtBhrw(u"ࠫࡷ࡯ࡧࡩࡶࠪྌ"),rwQN9AKhLCuMfHxjlbX0U(u"ࠬหัิษ็ࠤส๊้ࠡษ็้อืๅอࠩྍ"),JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"࠭สฮัํฯࠥาาว์ࠪྎ"),mkHKSQvjWr5BTcM3wVY(u"ࠧหฯา๎ะࠦวๅสิ๊ฬ๋ฬࠨྏ"),R64JBqKxEAHFQmUIrNicvnXZhT7z+zzZmACR6eDtyaYnIlX5vU,SnI4kxDXvV78cmMqFCsG1)
	if FhbZWrHPw6puX43VzJndxTDa==bXukYxQ4aHw:
		UGjc2OeCnoIpEWk0zP(fEXMiAyG3ql4vKB)
		OnsAxhdVjZF(S1SgCFYGJeMvfp5iZXK(u"ࠨ่ฯัฯูࠦๆๆํอࠥอไหฯา๎ะࠦวๅฮีส๏࠭ྐ"),rwQN9AKhLCuMfHxjlbX0U(u"ࠩ๐ࡗࡺࡩࡣࡦࡵࡶࠫྑ"),HB5PvxRhwM=dv0trJR7PwmKyxDYO52VLau8gEph(u"࠽࠵࠱ᑗ"))
		Za2Eugh8Mp1eQYH4()
	elif FhbZWrHPw6puX43VzJndxTDa==Y0XZKGRAUQj5O:
		import ZGYSlz63X1
		ZGYSlz63X1.Y6MUwOztEjeTSW7Ha(VBlawK4mgHSyLEn8iqhUkz5)
		Za2Eugh8Mp1eQYH4()
	dHPVDWfG4jX5e6QEo0CKh = XVmKrby29eCGMnlEY6jz0HNOR(KNIvHPjUbhr(u"ࠪࡧࡪࡴࡴࡦࡴࠪྒ"),hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧྒྷ"),KBkxSYaz93pu1(u"ู่ࠬโࠢํฮ๊ࠦลาีสู่ࠥฬๅࠢส่ศิืศรࠣ์ฬ๊วิฬัำฬ๋ࠠฦๆ์ࠤฬ๊ๅษำ่ะ๊ࠥใ๋ࠢํ฽ึ็ࠠศๆ่ฬึ๋ฬࠡลํ๊ࠥ๎ๅห๋ࠣ์่๐แ๊ࠡ็้ฬึวࠡฯุ่ฯࠦ็ั้ࠣห้๋ิไๆฬࠤ้ษๆࠡษ็้อืๅอࠢ็หࠥ๐ูๅ็ࠣห้เ๊ษ๋่ࠢฬ๊ࠦิฬฺ๎฾ࠦวึๆสั๋ࠥิไๆฬࠤํํ่ࠡๆสࠤ๏฿ัโࠢๆ๎ๆุ่ࠦำอࠤํ๊ๅศาสࠤ฽ํัห๋้ࠢฯ๏ู้ࠠิฮࠥํะ่ࠢสฺ่๊ใๅหࠣ࠲ࠥํไࠡฬิ๎ิࠦราีส่ࠥอไิฮ็ࠤฤ࠭ྔ"))
	if dHPVDWfG4jX5e6QEo0CKh==bXukYxQ4aHw: phBvCeKLcg0UZdQPOESHAm = A6dMB1FlgxVivJ2fk9C(u"࠭࡟ࡑࡔࡒࡆࡑࡋࡍࡠࠩྕ")
	else:
		BZj61bFtfWLzXp(JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠧࡤࡧࡱࡸࡪࡸࠧྖ"),hWGMqtBy4wuLaVcj,CnbBKmtF1x84q7AW(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫྗ"),soMVfbr6WtpNlcSA+QVDJLRlxNg127jMX(u"ࠩอ้ࠥหไ฻ษฤࠤสืำศๆࠣห้ิืฤࠩ྘")+YYSh2J6BIrsm8+QvgnCALNstmuUJiET(u"ࠪࡠࡳ๊ร็ࠢส่๊ฮัๆฮ่ࠣฬฺ๊ࠦๆ่ࠤฬฺ๊๋สࠣ์้อ๋ࠠีอ฻๏฿ࠠฦื็หาࠦวๅะฺวࠥฮฯ้่ࠣืั๊ࠠศๆฦา฼อมࠡษ็ิ๏ࠦๅไฬ๋ฬࠥ็๊่ࠢฯ้๏฿ࠠหใสู๏๊่ࠠาสࠤฬ๊ฮุลࠣ์฿๐ั่่๊ࠢࠥอไฤะฺหฦ࠭ྙ"))
		return
	oo4bfXvY8EOqAS90Vd = ZZMV7Px6iqCcT0ymtaulXwL
	import ZGYSlz63X1
	G62uf8ZSIzBE = ZGYSlz63X1.IYfvGAuH1W(FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠫࡊࡸࡲࡰࡴࡶࠫྚ"),oo4bfXvY8EOqAS90Vd,VBlawK4mgHSyLEn8iqhUkz5,hWGMqtBy4wuLaVcj,rwQN9AKhLCuMfHxjlbX0U(u"ࠬࡋࡍࡂࡋࡏ࠱ࡋࡘࡏࡎ࠯ࡖࡌࡔ࡝࡟ࡆ࡚ࡌࡘࡤࡋࡒࡓࡑࡕࡗࠬྛ"),phBvCeKLcg0UZdQPOESHAm)
	if G62uf8ZSIzBE and phBvCeKLcg0UZdQPOESHAm:
		Dsa06E8djiBmUN3HSVXgLM5pF72.append(LvhBAVtODxJKjgSoWH6sGi5lY)
		BxuD7iQRpW1(MM5Dx39f7ULhcJsRptzIowP,JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩྜ"),EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠧࡂࡎࡏࡣࡘࡋࡎࡕࡡࡈࡖࡗࡕࡒࡔࠩྜྷ"),Dsa06E8djiBmUN3HSVXgLM5pF72,VWxPgG1p8Z2Ei4DrX7NotvR)
	return
def M72mAcg9KGadTJQ15Zf46LnRE(F49URk16JIawgp7YWZAXGtnMb,filename=None):
	if H4qZ2hwilNJYTmCFEQyaSs98cPM0gR: F49URk16JIawgp7YWZAXGtnMb = F49URk16JIawgp7YWZAXGtnMb.encode(a7VXeDU82IfQEnPZAdiT)
	if not filename: o4oOCVEFpXHUwMKszi = GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠨࡵ࠽ࡠࡡ࠶࠰࠱࠲ࡨࡱࡦࡪ࡟ࠨྞ")+str(HB5PvxRhwM.time())+mkHKSQvjWr5BTcM3wVY(u"ࠩ࠱ࡨࡦࡺࠧྟ")
	else: o4oOCVEFpXHUwMKszi = mkHKSQvjWr5BTcM3wVY(u"ࠪࡷ࠿ࡢ࡜࠱࠲࠳࠴ࡪࡳࡡࡥࡡࠪྠ")+filename+XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠫ࠳ࡪࡡࡵࠩྡ")
	open(o4oOCVEFpXHUwMKszi,zyvJMtBhrw(u"ࠬࡽࡢࠨྡྷ")).write(F49URk16JIawgp7YWZAXGtnMb)
	return
def DNjHn7Gxf3(aJb19RQ7MVp):
	if aJb19RQ7MVp:
		QC27qaXRVojSpLy9K = Mqk51CFBym0pIQXZLsOxSJ(MM5Dx39f7ULhcJsRptzIowP,xcChIL13BpR8WArNt9Pl0So(u"࠭࡬ࡪࡵࡷࠫྣ"),DJ1ICpbyR2(u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪྤ"),S1SgCFYGJeMvfp5iZXK(u"ࠨࡓࡘࡉࡘ࡚ࡉࡐࡐࡖࠫྥ"))
		if QC27qaXRVojSpLy9K: return QC27qaXRVojSpLy9K
	S6NALBOqGn1zi2W5M8y7 = u6rbxnyjTl7I[LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠩࡓ࡝࡙ࡎࡏࡏࠩྦ")][dv0trJR7PwmKyxDYO52VLau8gEph(u"࠵ᑘ")]
	EPuMlX4RDWry9L = rV36aR5MufG1tqOWAlkYepcDd(fEXMiAyG3ql4vKB) if not aJb19RQ7MVp else IIvxtojw6EXl2f
	Ch3fRqj2lPAZrszcgytLE9BVK = gHXD9xAZTjLSkqhuV42cIa()
	ZG7ywHXrqjgUomtR45kuL = Ch3fRqj2lPAZrszcgytLE9BVK.split(LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠪ࠰ࠬྦྷ"))[Y0XZKGRAUQj5O]
	csNdvwrT748l6t9CPm = WQvYkNg7SysPFLitlGEn6.path.join(ggKyfILOkNPGxMtDQueVSZ,QVDJLRlxNg127jMX(u"ࠫࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪྨ"))
	ysvuiDfEtQGxKeIBFd4Y8 = wcjqgloENXpdCUKeSJ4m7vL6xQV0k()
	AqIOj0aJsHQwtvlcyx = {S1SgCFYGJeMvfp5iZXK(u"ࠬࡻࡳࡦࡴࠪྩ"):EPuMlX4RDWry9L,xcChIL13BpR8WArNt9Pl0So(u"࠭ࡶࡦࡴࡶ࡭ࡴࡴࠧྪ"):aO9cFKo862LqTWlIjy,e2qDYgipPmTw4KvBLnochr(u"ࠧࡤࡱࡸࡲࡹࡸࡹࠨྫ"):ZG7ywHXrqjgUomtR45kuL,QvgnCALNstmuUJiET(u"ࠨ࡫ࡧࡷࠬྫྷ"):smVarGBSwFI219cP(ysvuiDfEtQGxKeIBFd4Y8)}
	BUXsmKe5dGpJj09REb6HqcO7tNv = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(lke5D6CpaAXPdEZyrBSw7T,DJ1ICpbyR2(u"ࠩࡓࡓࡘ࡚ࠧྭ"),S6NALBOqGn1zi2W5M8y7,AqIOj0aJsHQwtvlcyx,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,CnbBKmtF1x84q7AW(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡋࡔࡠࡓࡘࡉࡘ࡚ࡉࡐࡐࡖ࠱࠶ࡹࡴࠨྮ"))
	QC27qaXRVojSpLy9K = []
	if BUXsmKe5dGpJj09REb6HqcO7tNv.succeeded:
		wYZ9hmIlS3cv17s2W = BUXsmKe5dGpJj09REb6HqcO7tNv.content
		QC27qaXRVojSpLy9K = wYZ9hmIlS3cv17s2W.replace(zyvJMtBhrw(u"ࠫࡡࡢࡲࠨྯ"),NXMOzZjYsmS9pf).replace(o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠬࡢ࡜࡯ࠩྰ"),NXMOzZjYsmS9pf).replace(MMizeNH0AKu(u"࠭࡜ࡳ࡞ࡱࠫྱ"),NXMOzZjYsmS9pf).replace(y6eSQlZEV8uwKG5M3,NXMOzZjYsmS9pf)
		QC27qaXRVojSpLy9K = trdVA0JvFaD.findall(KNIvHPjUbhr(u"ࠧࡔࡖࡄࡖ࡙ࡀ࠺ࡔࡖࡄࡖ࡙ࡀ࠺ࠩ࡞ࡧ࠯࠮ࡀ࠺ࠩ࠰࠭ࡃ࠮ࡢ࡮࠻࠼ࠫ࠲࠯ࡅࠩ࡝ࡰ࠽࠾࠭࠴ࠪࡀࠫ࡟ࡲ࠿ࡀࠨ࠯ࠬࡂ࠭ࡡࡴ࠺࠻ࠪ࠱࠮ࡄ࠯࡜࡯ࡇࡑࡈ࠿ࡀࡅࡏࡆࠪྲ"),QC27qaXRVojSpLy9K,trdVA0JvFaD.DOTALL)
		if QC27qaXRVojSpLy9K:
			QC27qaXRVojSpLy9K = sorted(QC27qaXRVojSpLy9K,reverse=fEXMiAyG3ql4vKB,key=lambda key: int(key[ybdv7XcT3lxF6QezULwCAGk]))
			p1tmbSLQT0jfKloyc5gvCIauJz,EPuMlX4RDWry9L,txuBWHAqlekYzCmJdFnXb7Og0oS,vIzgrEDLkOA,zzohWAV87dCuEJl0kxnX9Rs3wjMQ2G,jZyzn8MtORbaeCW = QC27qaXRVojSpLy9K[ybdv7XcT3lxF6QezULwCAGk]
			fZm9q0vdFhlTn = jZyzn8MtORbaeCW if NNA8aswIZfdr2([DJ1ICpbyR2(u"ࠨࡏࡗ࠴࠺ࡎࡘ࠱࡮ࡗࡘࡊࡌࡎࡔࡗࡑࡪ࡚ࡋࡖࡔࡕࡘ࠽ࡊ࡞ࠧླ")])[ybdv7XcT3lxF6QezULwCAGk] else txuBWHAqlekYzCmJdFnXb7Og0oS
			ee8c0jzrTntGSUdRJm.setSetting(MMizeNH0AKu(u"ࠩࡤࡺ࠳ࡶࡥࡳ࡫ࡲࡨ࠳࡯࡮ࡧࡱࡶࠫྴ"),fZm9q0vdFhlTn)
			BxuD7iQRpW1(MM5Dx39f7ULhcJsRptzIowP,DJ1ICpbyR2(u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭ྵ"),o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠫࡖ࡛ࡅࡔࡖࡌࡓࡓ࡙ࠧྶ"),QC27qaXRVojSpLy9K,KqO5BWGQR9JVL)
			ee8c0jzrTntGSUdRJm.setSetting(xcChIL13BpR8WArNt9Pl0So(u"ࠬࡧࡶ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮࠲ࡶࡻࡥࡴࡶ࡬ࡳࡳࡹࠧྷ"),smVarGBSwFI219cP(IHKJoQ8PwW4pNBR6GTAMVz2hdfC5my))
	return QC27qaXRVojSpLy9K
def DDpEuzS4Pv(H1eWYhmUozqOxrTbkScPI,odekCOPx60qmA1FUVvpEKYMD9zn=ybdv7XcT3lxF6QezULwCAGk,wdV9JIZLEiju2zlcOgPo=ybdv7XcT3lxF6QezULwCAGk):
	if odekCOPx60qmA1FUVvpEKYMD9zn and not wdV9JIZLEiju2zlcOgPo: wdV9JIZLEiju2zlcOgPo = len(H1eWYhmUozqOxrTbkScPI)//odekCOPx60qmA1FUVvpEKYMD9zn
	WH4d5XKA2Q7NnMthrV0,JpzD0lv9cYM6XrHeqCa,h7MpBTVqyLOX4jxi1mrRN8CAZkEn = [],-bXukYxQ4aHw,ybdv7XcT3lxF6QezULwCAGk
	for YGEAhZgn41MJyBudfqwr6Q in H1eWYhmUozqOxrTbkScPI:
		if h7MpBTVqyLOX4jxi1mrRN8CAZkEn%wdV9JIZLEiju2zlcOgPo==ybdv7XcT3lxF6QezULwCAGk:
			JpzD0lv9cYM6XrHeqCa += bXukYxQ4aHw
			WH4d5XKA2Q7NnMthrV0.append([])
		WH4d5XKA2Q7NnMthrV0[JpzD0lv9cYM6XrHeqCa].append(YGEAhZgn41MJyBudfqwr6Q)
		h7MpBTVqyLOX4jxi1mrRN8CAZkEn += bXukYxQ4aHw
	return WH4d5XKA2Q7NnMthrV0
def zrQiC1IdtyMH(o4oOCVEFpXHUwMKszi,F49URk16JIawgp7YWZAXGtnMb):
	dVclanWB9Cy1T5mpNYQ7SUPfg0st = WQvYkNg7SysPFLitlGEn6.path.join(vA0ImpguajeHKJ6P,o4oOCVEFpXHUwMKszi)
	if bXukYxQ4aHw or GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"࠭ࡉࡑࡖ࡙ࡣࠬྸ") not in o4oOCVEFpXHUwMKszi or LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠧࡎ࠵ࡘࡣࠬྐྵ") not in o4oOCVEFpXHUwMKszi: XNBHzrlKD9yW = str(F49URk16JIawgp7YWZAXGtnMb)
	else:
		WH4d5XKA2Q7NnMthrV0 = DDpEuzS4Pv(F49URk16JIawgp7YWZAXGtnMb,NeO3CTLHrPfWUoIgy8Q(u"࠹ᑙ"))
		XNBHzrlKD9yW = hWGMqtBy4wuLaVcj
		for E7vgCpnMIelJBVXdtf in WH4d5XKA2Q7NnMthrV0:
			XNBHzrlKD9yW += str(E7vgCpnMIelJBVXdtf)+GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠨ࡞ࡱࡠࡳࡃ࠽࠾࠿࡟ࡲࡡࡴࠧྺ")
		XNBHzrlKD9yW = XNBHzrlKD9yW.strip(SqrG5mU3j96ldsFpExobw40TJY(u"ࠩ࡟ࡲࡡࡴ࠽࠾࠿ࡀࡠࡳࡢ࡮ࠨྻ"))
	HDkISbcQMqAJfTYXeKPZjEpsG0 = IZedRkDajQCrHAM4mOPtNEKzc70vF.compress(XNBHzrlKD9yW)
	open(dVclanWB9Cy1T5mpNYQ7SUPfg0st,FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠪࡻࡧ࠭ྼ")).write(HDkISbcQMqAJfTYXeKPZjEpsG0)
	return
def QFPVImEnHh4Jk(YGI85DN9P76z02eik,o4oOCVEFpXHUwMKszi):
	if YGI85DN9P76z02eik==CnbBKmtF1x84q7AW(u"ࠫࡩ࡯ࡣࡵࠩ྽"): F49URk16JIawgp7YWZAXGtnMb = {}
	elif YGI85DN9P76z02eik==FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠬࡲࡩࡴࡶࠪ྾"): F49URk16JIawgp7YWZAXGtnMb = []
	elif YGI85DN9P76z02eik==OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"࠭ࡳࡵࡴࠪ྿"): F49URk16JIawgp7YWZAXGtnMb = hWGMqtBy4wuLaVcj
	elif YGI85DN9P76z02eik==QVDJLRlxNg127jMX(u"ࠧࡪࡰࡷࠫ࿀"): F49URk16JIawgp7YWZAXGtnMb = ybdv7XcT3lxF6QezULwCAGk
	else: F49URk16JIawgp7YWZAXGtnMb = None
	dVclanWB9Cy1T5mpNYQ7SUPfg0st = WQvYkNg7SysPFLitlGEn6.path.join(vA0ImpguajeHKJ6P,o4oOCVEFpXHUwMKszi)
	HDkISbcQMqAJfTYXeKPZjEpsG0 = open(dVclanWB9Cy1T5mpNYQ7SUPfg0st,FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠨࡴࡥࠫ࿁")).read()
	XNBHzrlKD9yW = IZedRkDajQCrHAM4mOPtNEKzc70vF.decompress(HDkISbcQMqAJfTYXeKPZjEpsG0)
	if EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠩ࡟ࡲࡡࡴ࠽࠾࠿ࡀࡠࡳࡢ࡮ࠨ࿂") not in XNBHzrlKD9yW: F49URk16JIawgp7YWZAXGtnMb = eval(XNBHzrlKD9yW)
	else:
		WH4d5XKA2Q7NnMthrV0 = XNBHzrlKD9yW.split(o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠪࡠࡳࡢ࡮࠾࠿ࡀࡁࡡࡴ࡜࡯ࠩ࿃"))
		del XNBHzrlKD9yW
		F49URk16JIawgp7YWZAXGtnMb = []
		yyGzKqAnujivxBDCJ5N40RoW8gV = wfH5yxroNbj82s9iPp7QvuTn()
		p1tmbSLQT0jfKloyc5gvCIauJz = ybdv7XcT3lxF6QezULwCAGk
		for E7vgCpnMIelJBVXdtf in WH4d5XKA2Q7NnMthrV0:
			yyGzKqAnujivxBDCJ5N40RoW8gV.qSFtZyUrNnE(str(p1tmbSLQT0jfKloyc5gvCIauJz),eval,E7vgCpnMIelJBVXdtf)
			p1tmbSLQT0jfKloyc5gvCIauJz += bXukYxQ4aHw
		del WH4d5XKA2Q7NnMthrV0
		yyGzKqAnujivxBDCJ5N40RoW8gV.ndOAzCvQJUf()
		yyGzKqAnujivxBDCJ5N40RoW8gV.fjHFSPQRi4IdDn68()
		ltHTvIkeDouxCa5XhrRWp = list(yyGzKqAnujivxBDCJ5N40RoW8gV.resultsDICT.keys())
		BQNtvMxA54gpWUcFEZP6sTaifuLyK = sorted(ltHTvIkeDouxCa5XhrRWp,reverse=fEXMiAyG3ql4vKB,key=lambda key: int(key))
		for p1tmbSLQT0jfKloyc5gvCIauJz in BQNtvMxA54gpWUcFEZP6sTaifuLyK:
			F49URk16JIawgp7YWZAXGtnMb += yyGzKqAnujivxBDCJ5N40RoW8gV.resultsDICT[p1tmbSLQT0jfKloyc5gvCIauJz]
	return F49URk16JIawgp7YWZAXGtnMb
def FNqZDIAJ49V08HoBpTiOlxwjPQM7a(nUy7x6dqmk92MPb):
	LUkmrtlbsXu = WQvYkNg7SysPFLitlGEn6.path.join(W96kNDymei,OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠫࡦࡪࡤࡰࡰࡶࠫ࿄"),nUy7x6dqmk92MPb,dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠬࡧࡤࡥࡱࡱ࠲ࡽࡳ࡬ࠨ࿅"))
	try: Exb0LWAciDuQdO6nNjKfJkGS = open(LUkmrtlbsXu,LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"࠭ࡲࡣ࿆ࠩ")).read()
	except:
		pnMdAUKPN8526wksJqRbuex9QHcE = WQvYkNg7SysPFLitlGEn6.path.join(van3wiJRm0T,XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠧࡢࡦࡧࡳࡳࡹࠧ࿇"),nUy7x6dqmk92MPb,QVDJLRlxNg127jMX(u"ࠨࡣࡧࡨࡴࡴ࠮ࡹ࡯࡯ࠫ࿈"))
		try: Exb0LWAciDuQdO6nNjKfJkGS = open(pnMdAUKPN8526wksJqRbuex9QHcE,NeO3CTLHrPfWUoIgy8Q(u"ࠩࡵࡦࠬ࿉")).read()
		except: return hWGMqtBy4wuLaVcj,[]
	if H4qZ2hwilNJYTmCFEQyaSs98cPM0gR: Exb0LWAciDuQdO6nNjKfJkGS = Exb0LWAciDuQdO6nNjKfJkGS.decode(a7VXeDU82IfQEnPZAdiT)
	bb19aPwBeOhfiX6uxMNtCd = trdVA0JvFaD.findall(KNIvHPjUbhr(u"ࠪ࡭ࡩࡃ࠮ࠫࡁࡹࡩࡷࡹࡩࡰࡰࡀ࡟ࡡࠨ࡜ࠨ࡟ࠫ࠲࠯ࡅࠩ࡜࡞ࠥࡠࠬࡣࠧ࿊"),Exb0LWAciDuQdO6nNjKfJkGS,trdVA0JvFaD.DOTALL|trdVA0JvFaD.IGNORECASE)
	if not bb19aPwBeOhfiX6uxMNtCd: return hWGMqtBy4wuLaVcj,[]
	Mc6xziFXu4BhE1VbGIQYrWlesaPH,Ghx5VK1EeSBoYIRckD80CUwFqZ2vO = bb19aPwBeOhfiX6uxMNtCd[ybdv7XcT3lxF6QezULwCAGk],w0yCzjaYOfEProxWik7lNXt8nA(bb19aPwBeOhfiX6uxMNtCd[ybdv7XcT3lxF6QezULwCAGk])
	return Mc6xziFXu4BhE1VbGIQYrWlesaPH,Ghx5VK1EeSBoYIRckD80CUwFqZ2vO
def KbCpy1XTILsEoSj73hidn6B0D5R8mF():
	KvHmql2B8ztXJ4e7sGyDQE1Ojk = Mqk51CFBym0pIQXZLsOxSJ(MM5Dx39f7ULhcJsRptzIowP,DJ1ICpbyR2(u"ࠫࡩ࡯ࡣࡵࠩ࿋"),KBkxSYaz93pu1(u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࠨ࿌"),hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"࠭ࡁࡍࡎࡢࡅࡉࡊࡏࡏࡕࡢ࡜ࡒࡒࠧ࿍"))
	if KvHmql2B8ztXJ4e7sGyDQE1Ojk: return KvHmql2B8ztXJ4e7sGyDQE1Ojk
	EE2I8iHJDy6,KvHmql2B8ztXJ4e7sGyDQE1Ojk = {},{}
	tO1GiUvAflF7Mm = [u6rbxnyjTl7I[DJ1ICpbyR2(u"ࠧࡓࡇࡓࡓࡘ࠭࿎")][ybdv7XcT3lxF6QezULwCAGk]]
	if guSzmUCXDa1tQpY>FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"࠳࠺࠲࠾࠿ᑚ"): tO1GiUvAflF7Mm.append(u6rbxnyjTl7I[rwQN9AKhLCuMfHxjlbX0U(u"ࠨࡔࡈࡔࡔ࡙ࠧ࿏")][bXukYxQ4aHw])
	if H4qZ2hwilNJYTmCFEQyaSs98cPM0gR: tO1GiUvAflF7Mm.append(u6rbxnyjTl7I[EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠩࡕࡉࡕࡕࡓࠨ࿐")][Y0XZKGRAUQj5O])
	for fqMx1b6EkHh in tO1GiUvAflF7Mm:
		BUXsmKe5dGpJj09REb6HqcO7tNv = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(lke5D6CpaAXPdEZyrBSw7T,FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠪࡋࡊ࡚ࠧ࿑"),fqMx1b6EkHh,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,NeO3CTLHrPfWUoIgy8Q(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡘࡅࡂࡆࡢࡅࡑࡒ࡟ࡂࡆࡇࡓࡓ࡙࡟࡙ࡏࡏ࠱࠶ࡹࡴࠨ࿒"))
		if BUXsmKe5dGpJj09REb6HqcO7tNv.succeeded:
			wYZ9hmIlS3cv17s2W = BUXsmKe5dGpJj09REb6HqcO7tNv.content
			WBoZ8xtnq5y7UPm = fqMx1b6EkHh.rsplit(S1SgCFYGJeMvfp5iZXK(u"ࠬ࠵ࠧ࿓"),A6dMB1FlgxVivJ2fk9C(u"࠴ᑛ"))[ybdv7XcT3lxF6QezULwCAGk]
			TuDdBJKFYMZrx2syLlzVw79GNh = trdVA0JvFaD.findall(QVDJLRlxNg127jMX(u"࠭ࡩࡥ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡼࡥࡳࡵ࡬ࡳࡳࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ࿔"),wYZ9hmIlS3cv17s2W,trdVA0JvFaD.DOTALL|trdVA0JvFaD.IGNORECASE)
			for nUy7x6dqmk92MPb,kPf6gR2LcWxv in TuDdBJKFYMZrx2syLlzVw79GNh:
				n81SDcsRGivabA4 = WBoZ8xtnq5y7UPm+DJ1ICpbyR2(u"ࠧ࠰ࠩ࿕")+nUy7x6dqmk92MPb+LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠨ࠱ࠪ࿖")+nUy7x6dqmk92MPb+QVDJLRlxNg127jMX(u"ࠩ࠰ࠫ࿗")+kPf6gR2LcWxv+JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠪ࠲ࡿ࡯ࡰࠨ࿘")
				if nUy7x6dqmk92MPb not in list(EE2I8iHJDy6.keys()):
					EE2I8iHJDy6[nUy7x6dqmk92MPb] = []
					KvHmql2B8ztXJ4e7sGyDQE1Ojk[nUy7x6dqmk92MPb] = []
				PPi6hKREnru0z4lAgc1WBjZb = w0yCzjaYOfEProxWik7lNXt8nA(kPf6gR2LcWxv)
				EE2I8iHJDy6[nUy7x6dqmk92MPb].append((kPf6gR2LcWxv,PPi6hKREnru0z4lAgc1WBjZb,n81SDcsRGivabA4))
	for nUy7x6dqmk92MPb in list(EE2I8iHJDy6.keys()):
		KvHmql2B8ztXJ4e7sGyDQE1Ojk[nUy7x6dqmk92MPb] = sorted(EE2I8iHJDy6[nUy7x6dqmk92MPb],reverse=VBlawK4mgHSyLEn8iqhUkz5,key=lambda key: key[bXukYxQ4aHw])
	BxuD7iQRpW1(MM5Dx39f7ULhcJsRptzIowP,e2qDYgipPmTw4KvBLnochr(u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧ࿙"),HHoGx7Flus60(u"ࠬࡇࡌࡍࡡࡄࡈࡉࡕࡎࡔࡡ࡛ࡑࡑ࠭࿚"),KvHmql2B8ztXJ4e7sGyDQE1Ojk,KqO5BWGQR9JVL)
	return KvHmql2B8ztXJ4e7sGyDQE1Ojk
def w0yCzjaYOfEProxWik7lNXt8nA(kPf6gR2LcWxv):
	PPi6hKREnru0z4lAgc1WBjZb = []
	FbWh5EMyOJdV91DQ7fezpCAgk0n = kPf6gR2LcWxv.split(zyvJMtBhrw(u"࠭࠮ࠨ࿛"))
	for Z3JWB2duYzg9iMAELR in FbWh5EMyOJdV91DQ7fezpCAgk0n:
		tLxsm3CdXpNhzMj0ArIvfgR2 = trdVA0JvFaD.findall(jeAby54c02TgG8zuivonX91(u"ࠧ࡝ࡦ࠮ࢀࡠࡢࠫ࡝࠯ࡤ࠱ࡿࡇ࡛࠭࡟࠮ࠫ࿜"),Z3JWB2duYzg9iMAELR,trdVA0JvFaD.DOTALL)
		tMqK7iPfza5UykIXDcE = []
		for KKB8MPmXr5vZwlTUonqVJD in tLxsm3CdXpNhzMj0ArIvfgR2:
			if KKB8MPmXr5vZwlTUonqVJD.isdigit(): KKB8MPmXr5vZwlTUonqVJD = int(KKB8MPmXr5vZwlTUonqVJD)
			tMqK7iPfza5UykIXDcE.append(KKB8MPmXr5vZwlTUonqVJD)
		PPi6hKREnru0z4lAgc1WBjZb.append(tMqK7iPfza5UykIXDcE)
	return PPi6hKREnru0z4lAgc1WBjZb
def BI3UXbZ5pMKV8vdswPG(PPi6hKREnru0z4lAgc1WBjZb):
	kPf6gR2LcWxv = hWGMqtBy4wuLaVcj
	for Z3JWB2duYzg9iMAELR in PPi6hKREnru0z4lAgc1WBjZb:
		for KKB8MPmXr5vZwlTUonqVJD in Z3JWB2duYzg9iMAELR: kPf6gR2LcWxv += str(KKB8MPmXr5vZwlTUonqVJD)
		kPf6gR2LcWxv += GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠨ࠰ࠪ࿝")
	kPf6gR2LcWxv = kPf6gR2LcWxv.strip(wwPrSDa21lUh(u"ࠩ࠱ࠫ࿞"))
	return kPf6gR2LcWxv
def iAGOsUaS21t3RnQ64ejfY8EX5vMlCH(OP6LIZw9Y2JzlsEh817nQig):
	ssBcmRijhUKPzpVoYNwdLZvElJ = {}
	EE2I8iHJDy6 = KbCpy1XTILsEoSj73hidn6B0D5R8mF()
	qGlfeFu4HPwjUAKQXVdcb80akiN = Rc7ME3hXPxtzyH1CvFwf96iUsQlq(OP6LIZw9Y2JzlsEh817nQig)
	for nUy7x6dqmk92MPb in OP6LIZw9Y2JzlsEh817nQig:
		if nUy7x6dqmk92MPb not in list(EE2I8iHJDy6.keys()): continue
		KvHmql2B8ztXJ4e7sGyDQE1Ojk = EE2I8iHJDy6[nUy7x6dqmk92MPb]
		R8f0mIEy6z14vxdWwGTs,II9OoQ0wmLufpM4x25,rZT2eEw1FHYtG6xk = KvHmql2B8ztXJ4e7sGyDQE1Ojk[ybdv7XcT3lxF6QezULwCAGk]
		ZZkygB5KqU1CDz,PDjEC7xkvYA3tH8NMR46r = FNqZDIAJ49V08HoBpTiOlxwjPQM7a(nUy7x6dqmk92MPb)
		hvl9HBPUgsDpS3tA0Wyc6xn,sHTFaIyGqfekpEJ9 = qGlfeFu4HPwjUAKQXVdcb80akiN[nUy7x6dqmk92MPb]
		qgSjWf7lc5XQ6eosGr3zUdBiYmk0R = II9OoQ0wmLufpM4x25>PDjEC7xkvYA3tH8NMR46r and hvl9HBPUgsDpS3tA0Wyc6xn
		xu5GdvS1L2FQo6fP = VBlawK4mgHSyLEn8iqhUkz5
		if not hvl9HBPUgsDpS3tA0Wyc6xn: NJyuG4p0M6HnIkTl2RtBY = SqrG5mU3j96ldsFpExobw40TJY(u"ࠪࡱ࡮ࡹࡳࡪࡰࡪࠫ࿟")
		elif not sHTFaIyGqfekpEJ9: NJyuG4p0M6HnIkTl2RtBY = GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠫࡩ࡯ࡳࡢࡤ࡯ࡩࡩ࠭࿠")
		elif qgSjWf7lc5XQ6eosGr3zUdBiYmk0R: NJyuG4p0M6HnIkTl2RtBY = ITvnUAMXsyb4eO(u"ࠬࡵ࡬ࡥࠩ࿡")
		else:
			NJyuG4p0M6HnIkTl2RtBY = NeO3CTLHrPfWUoIgy8Q(u"࠭ࡧࡰࡱࡧࠫ࿢")
			xu5GdvS1L2FQo6fP = fEXMiAyG3ql4vKB
		ssBcmRijhUKPzpVoYNwdLZvElJ[nUy7x6dqmk92MPb] = xu5GdvS1L2FQo6fP,ZZkygB5KqU1CDz,PDjEC7xkvYA3tH8NMR46r,R8f0mIEy6z14vxdWwGTs,II9OoQ0wmLufpM4x25,NJyuG4p0M6HnIkTl2RtBY,rZT2eEw1FHYtG6xk
	return ssBcmRijhUKPzpVoYNwdLZvElJ
def CEIhS05OkFWGozARVZwnyrXf6(xX7c9PeCsht,MjpTeGrhbBzL5x7HCtE,YCX3aoKz7Ow2MWEy=hWGMqtBy4wuLaVcj,f9DZTF7EJI8qpSdlO=hWGMqtBy4wuLaVcj,Vr2QCwSeMEBn4X=hWGMqtBy4wuLaVcj):
	if VKiGj1LundAJQwEXcqgxC: xX7c9PeCsht.update(MjpTeGrhbBzL5x7HCtE,YCX3aoKz7Ow2MWEy,f9DZTF7EJI8qpSdlO,Vr2QCwSeMEBn4X)
	else: xX7c9PeCsht.update(MjpTeGrhbBzL5x7HCtE,YCX3aoKz7Ow2MWEy+NXMOzZjYsmS9pf+f9DZTF7EJI8qpSdlO+NXMOzZjYsmS9pf+Vr2QCwSeMEBn4X)
	return
def hGBzk2RAImCy0LKPMVjaN38lxUg6w(XXcjg4MYoSre):
	def hhIV5jW8YTHDx(dTjEFcLBw1UvqImt4Q7MO,uOWdMNLcIFpDHmjortlq1ki6XZBw2,n3UEHj0mrNfZvAIBlw9akqJP=hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠢ࠱࠳࠵࠷࠹࠻࠶࠸࠺࠼ࡥࡧࡩࡤࡦࡨࡪ࡬࡮ࡰ࡫࡭࡯ࡱࡳࡵࡷࡲࡴࡶࡸࡺࡼࡾࡹࡻࡃࡅࡇࡉࡋࡆࡈࡊࡌࡎࡐࡒࡍࡏࡑࡓࡕࡗ࡙ࡔࡖࡘ࡚࡜࡞ࡠࠢ࿣")):
		return ((dTjEFcLBw1UvqImt4Q7MO == ybdv7XcT3lxF6QezULwCAGk) and n3UEHj0mrNfZvAIBlw9akqJP[ybdv7XcT3lxF6QezULwCAGk]) or (hhIV5jW8YTHDx(dTjEFcLBw1UvqImt4Q7MO // uOWdMNLcIFpDHmjortlq1ki6XZBw2, uOWdMNLcIFpDHmjortlq1ki6XZBw2, n3UEHj0mrNfZvAIBlw9akqJP).lstrip(n3UEHj0mrNfZvAIBlw9akqJP[ybdv7XcT3lxF6QezULwCAGk]) + n3UEHj0mrNfZvAIBlw9akqJP[dTjEFcLBw1UvqImt4Q7MO % uOWdMNLcIFpDHmjortlq1ki6XZBw2])
	def AUQ9p0b2BkLmJ73yNo6qrsZcl5O(WiAmh52FswBbK, u752etRpvTIjZxlqOJN, ssBDVT0kh3od, ct0SbW6lQxPyC1, gsuq6lCaQtkb5SBLN=None, v1fwA8koXingBNCprRblsGjq20J9=None, kJPIsCTWX8A7MhQY=None):
		while (ssBDVT0kh3od):
			ssBDVT0kh3od-=LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"࠵ᑜ")
			if (ct0SbW6lQxPyC1[ssBDVT0kh3od]): WiAmh52FswBbK = trdVA0JvFaD.sub(DJ1ICpbyR2(u"ࠣ࡞࡟ࡦࠧ࿤") + hhIV5jW8YTHDx(ssBDVT0kh3od, u752etRpvTIjZxlqOJN) + o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠤ࡟ࡠࡧࠨ࿥"),  ct0SbW6lQxPyC1[ssBDVT0kh3od], WiAmh52FswBbK)
		return WiAmh52FswBbK
	XXcjg4MYoSre = XXcjg4MYoSre.split(jeAby54c02TgG8zuivonX91(u"ࠪࢁ࠭࠭࿦"))[bXukYxQ4aHw]
	XXcjg4MYoSre = XXcjg4MYoSre.rsplit(o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠫࡸࡶ࡬ࡪࡶࠪ࿧"))[ybdv7XcT3lxF6QezULwCAGk]+rwQN9AKhLCuMfHxjlbX0U(u"ࠧࡹࡰ࡭࡫ࡷࠬࠬࢂࠧࠪࠫࠥ࿨")
	IjWbFB4GQpMYNUmur6K9Rn = eval(NeO3CTLHrPfWUoIgy8Q(u"࠭ࡵ࡯ࡲࡤࡧࡰ࠮ࠧ࿩")+XXcjg4MYoSre,{OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠧࡣࡣࡶࡩࡓ࠭࿪"):hhIV5jW8YTHDx,KNIvHPjUbhr(u"ࠨࡷࡱࡴࡦࡩ࡫ࠨ࿫"):AUQ9p0b2BkLmJ73yNo6qrsZcl5O})
	return IjWbFB4GQpMYNUmur6K9Rn
def zUJTl3EtmvNedxkZ42B(code):
	_ew0jaEPQlbFZrSsd=GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠤ࠳࠵࠷࠹࠴࠶࠸࠺࠼࠾ࡧࡢࡤࡦࡨࡪ࡬࡮ࡩ࡫࡭࡯ࡱࡳࡵࡰࡲࡴࡶࡸࡺࡼࡷࡹࡻࡽࡅࡇࡉࡄࡆࡈࡊࡌࡎࡐࡋࡍࡏࡑࡓࡕࡗࡒࡔࡖࡘ࡚࡜࡞࡙࡛࠭࠲ࠦ࿬")
	def NeXWQcO31DdPposbjh2t7RJGy(v1fwA8koXingBNCprRblsGjq20J9,gsuq6lCaQtkb5SBLN,TqOvir74kb):
		iw8oUzVa3xr9heqKRgTQN = list(_ew0jaEPQlbFZrSsd)
		vR6qzU1NfJMi = iw8oUzVa3xr9heqKRgTQN[o1u5dij9UrcbXzVS8lwIWfKpnqM(u"࠵ᑝ"):gsuq6lCaQtkb5SBLN]
		PPuqrvDLEViYOMf1dmkK7 = iw8oUzVa3xr9heqKRgTQN[e2qDYgipPmTw4KvBLnochr(u"࠶ᑞ"):TqOvir74kb]
		v1fwA8koXingBNCprRblsGjq20J9 = list(v1fwA8koXingBNCprRblsGjq20J9)[::-mkHKSQvjWr5BTcM3wVY(u"࠱ᑟ")]
		rrEgp9JsojRK50Wwl6O = QvgnCALNstmuUJiET(u"࠱ᑠ")
		for ssBDVT0kh3od,uOWdMNLcIFpDHmjortlq1ki6XZBw2 in enumerate(v1fwA8koXingBNCprRblsGjq20J9):
			if uOWdMNLcIFpDHmjortlq1ki6XZBw2 in vR6qzU1NfJMi: rrEgp9JsojRK50Wwl6O = rrEgp9JsojRK50Wwl6O + vR6qzU1NfJMi.index(uOWdMNLcIFpDHmjortlq1ki6XZBw2)*gsuq6lCaQtkb5SBLN**ssBDVT0kh3od
		ct0SbW6lQxPyC1 = o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠥࠦ࿭")
		while rrEgp9JsojRK50Wwl6O > jeAby54c02TgG8zuivonX91(u"࠲ᑡ"):
			ct0SbW6lQxPyC1 = PPuqrvDLEViYOMf1dmkK7[rrEgp9JsojRK50Wwl6O%TqOvir74kb] + ct0SbW6lQxPyC1
			rrEgp9JsojRK50Wwl6O = (rrEgp9JsojRK50Wwl6O - (rrEgp9JsojRK50Wwl6O%TqOvir74kb))//TqOvir74kb
		return int(ct0SbW6lQxPyC1) or wwPrSDa21lUh(u"࠳ᑢ")
	def Gmjlai612ZbU3s(vR6qzU1NfJMi,u,R47xjBkH9IiXYcdDeS0VFtlw,ffBta09FTWU7Gcxb5,gsuq6lCaQtkb5SBLN,kJPIsCTWX8A7MhQY):
		kJPIsCTWX8A7MhQY = gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠦࠧ࿮");
		PPuqrvDLEViYOMf1dmkK7 = FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"࠴ᑣ")
		while PPuqrvDLEViYOMf1dmkK7 < len(vR6qzU1NfJMi):
			rrEgp9JsojRK50Wwl6O = SqrG5mU3j96ldsFpExobw40TJY(u"࠵ᑤ")
			DDRQvnfTxWbqpcgr8FiBOKP = zyvJMtBhrw(u"ࠧࠨ࿯")
			while vR6qzU1NfJMi[PPuqrvDLEViYOMf1dmkK7] is not R47xjBkH9IiXYcdDeS0VFtlw[gsuq6lCaQtkb5SBLN]:
				DDRQvnfTxWbqpcgr8FiBOKP = JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"࠭ࠧ࿰").join([DDRQvnfTxWbqpcgr8FiBOKP,vR6qzU1NfJMi[PPuqrvDLEViYOMf1dmkK7]])
				PPuqrvDLEViYOMf1dmkK7 = PPuqrvDLEViYOMf1dmkK7 + JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"࠷ᑥ")
			while rrEgp9JsojRK50Wwl6O < len(R47xjBkH9IiXYcdDeS0VFtlw):
				DDRQvnfTxWbqpcgr8FiBOKP = DDRQvnfTxWbqpcgr8FiBOKP.replace(R47xjBkH9IiXYcdDeS0VFtlw[rrEgp9JsojRK50Wwl6O],str(rrEgp9JsojRK50Wwl6O))
				rrEgp9JsojRK50Wwl6O = rrEgp9JsojRK50Wwl6O + LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"࠱ᑦ")
			kJPIsCTWX8A7MhQY = sULh4NjakzI8He7xJCMGrql(u"ࠧࠨ࿱").join([kJPIsCTWX8A7MhQY,e2qDYgipPmTw4KvBLnochr(u"ࠨࠩ࿲").join(map(chr, [NeXWQcO31DdPposbjh2t7RJGy(DDRQvnfTxWbqpcgr8FiBOKP,gsuq6lCaQtkb5SBLN,FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"࠲࠲ᑧ")) - ffBta09FTWU7Gcxb5]))])
			PPuqrvDLEViYOMf1dmkK7 = PPuqrvDLEViYOMf1dmkK7 + S1SgCFYGJeMvfp5iZXK(u"࠳ᑨ")
		return kJPIsCTWX8A7MhQY
	code = code.replace(o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠩ࡟ࡲࠬ࿳"),sULh4NjakzI8He7xJCMGrql(u"ࠪࠫ࿴")).replace(A6dMB1FlgxVivJ2fk9C(u"ࠫࡡࡸࠧ࿵"),XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠬ࠭࿶"))
	IjtWabFlwh4HULekZi2vGs = trdVA0JvFaD.findall(GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"࠭࡜ࡾ࡞ࠫࠦ࠭ࡢࡷࠬࠫࠥ࠰࠭ࡢࡤࠬࠫ࠯ࠦ࠭ࡢࡷࠬࠫࠥ࠰࠭ࡢࡤࠬࠫ࠯ࠬࡡࡪࠫࠪ࠮ࠫࡠࡩ࠱ࠩ࡝ࠫ࡟࠭ࠬ࿷"),code,trdVA0JvFaD.DOTALL)
	if IjtWabFlwh4HULekZi2vGs:
		IjtWabFlwh4HULekZi2vGs = list(IjtWabFlwh4HULekZi2vGs[JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"࠳ᑩ")])
		for X52KTnD3fVbkONWIH8MGmhUuldeiv,code in enumerate(IjtWabFlwh4HULekZi2vGs):
			if code.isdigit(): IjtWabFlwh4HULekZi2vGs[X52KTnD3fVbkONWIH8MGmhUuldeiv] = int(code)
			else: IjtWabFlwh4HULekZi2vGs[X52KTnD3fVbkONWIH8MGmhUuldeiv] = code.replace(wwPrSDa21lUh(u"ࠧ࡝ࠤࠪ࿸"),rwQN9AKhLCuMfHxjlbX0U(u"ࠨࠩ࿹"))
		kE5UwuH7RIGvrix0TXnyC4oAVdFLMB = Gmjlai612ZbU3s(*IjtWabFlwh4HULekZi2vGs)
		return kE5UwuH7RIGvrix0TXnyC4oAVdFLMB
	return e2qDYgipPmTw4KvBLnochr(u"ࠩࠪ࿺")
def c5WZHCsePNkqxUudFtVaTybIOv(S6NALBOqGn1zi2W5M8y7,ZZ65xsyt3bqh1YrOnDzmFeERwofd=hWGMqtBy4wuLaVcj):
	if ZZ65xsyt3bqh1YrOnDzmFeERwofd==sULh4NjakzI8He7xJCMGrql(u"ࠪࡰࡴࡽࡥࡳࠩ࿻"): S6NALBOqGn1zi2W5M8y7 = trdVA0JvFaD.sub(S1SgCFYGJeMvfp5iZXK(u"ࡶ࡛ࠬࠫ࠱࠯࠼ࡅ࠲ࡠ࡝ࡼ࠴ࢀࠫ࿼"),lambda OiDSf0mGbtVFPEQwAIcuNlLWnYe9M: OiDSf0mGbtVFPEQwAIcuNlLWnYe9M.group(ybdv7XcT3lxF6QezULwCAGk).lower(),S6NALBOqGn1zi2W5M8y7)
	elif ZZ65xsyt3bqh1YrOnDzmFeERwofd==xcChIL13BpR8WArNt9Pl0So(u"ࠬࡻࡰࡱࡧࡵࠫ࿽"): S6NALBOqGn1zi2W5M8y7 = trdVA0JvFaD.sub(zyvJMtBhrw(u"ࡸࠧࠦ࡝࠳࠱࠾ࡧ࠭ࡻ࡟ࡾ࠶ࢂ࠭࿾"),lambda OiDSf0mGbtVFPEQwAIcuNlLWnYe9M: OiDSf0mGbtVFPEQwAIcuNlLWnYe9M.group(ybdv7XcT3lxF6QezULwCAGk).upper(),S6NALBOqGn1zi2W5M8y7)
	return S6NALBOqGn1zi2W5M8y7
def Rc7ME3hXPxtzyH1CvFwf96iUsQlq(OP6LIZw9Y2JzlsEh817nQig):
	jCA5xTWcNoJsb9teLSU2XE8k7z,jj8ZdyQ4slV9BtTD6nSFNALaX1bc = fEXMiAyG3ql4vKB,fEXMiAyG3ql4vKB
	WFYAlCyzGj1H32ovtQLnBTqhS6X = pbXIg7UFi4dV.connect(N4Rok9EBZeWumSCc2)
	WFYAlCyzGj1H32ovtQLnBTqhS6X.text_factory = str
	Z8gcWPFXkx7oSrR2D = WFYAlCyzGj1H32ovtQLnBTqhS6X.cursor()
	if len(OP6LIZw9Y2JzlsEh817nQig)==bXukYxQ4aHw: gLt3X1fCxahSrDj0zkVNM = dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠧࠩࠤࠪ࿿")+OP6LIZw9Y2JzlsEh817nQig[ybdv7XcT3lxF6QezULwCAGk]+LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠨࠤࠬࠫက")
	else: gLt3X1fCxahSrDj0zkVNM = str(tuple(OP6LIZw9Y2JzlsEh817nQig))
	Z8gcWPFXkx7oSrR2D.execute(LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠩࡖࡉࡑࡋࡃࡕࠢࡤࡨࡩࡵ࡮ࡊࡆ࠯ࡩࡳࡧࡢ࡭ࡧࡧࠤࡋࡘࡏࡎࠢ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨࠥ࡝ࡈࡆࡔࡈࠤࡦࡪࡤࡰࡰࡌࡈࠥࡏࡎࠡࠩခ")+gLt3X1fCxahSrDj0zkVNM+NeO3CTLHrPfWUoIgy8Q(u"ࠪࠤࡀ࠭ဂ"))
	pUD0WVmgIR7 = Z8gcWPFXkx7oSrR2D.fetchall()
	qGlfeFu4HPwjUAKQXVdcb80akiN = {}
	for nUy7x6dqmk92MPb in OP6LIZw9Y2JzlsEh817nQig: qGlfeFu4HPwjUAKQXVdcb80akiN[nUy7x6dqmk92MPb] = (fEXMiAyG3ql4vKB,fEXMiAyG3ql4vKB)
	for nUy7x6dqmk92MPb,jj8ZdyQ4slV9BtTD6nSFNALaX1bc in pUD0WVmgIR7:
		jCA5xTWcNoJsb9teLSU2XE8k7z = VBlawK4mgHSyLEn8iqhUkz5
		jj8ZdyQ4slV9BtTD6nSFNALaX1bc = jj8ZdyQ4slV9BtTD6nSFNALaX1bc==bXukYxQ4aHw
		qGlfeFu4HPwjUAKQXVdcb80akiN[nUy7x6dqmk92MPb] = (jCA5xTWcNoJsb9teLSU2XE8k7z,jj8ZdyQ4slV9BtTD6nSFNALaX1bc)
	WFYAlCyzGj1H32ovtQLnBTqhS6X.close()
	return qGlfeFu4HPwjUAKQXVdcb80akiN
def rpIZC2m6gEkAh(QTkAP1Nv4cDU0mVuWirzpafolHxF6):
	N6NCYivtV4I5rEXq = hWGMqtBy4wuLaVcj
	if WQvYkNg7SysPFLitlGEn6.path.exists(QTkAP1Nv4cDU0mVuWirzpafolHxF6):
		KYm6wdR9sybGfD5 = open(QTkAP1Nv4cDU0mVuWirzpafolHxF6,MMizeNH0AKu(u"ࠫࡷࡨࠧဃ")).read()
		if H4qZ2hwilNJYTmCFEQyaSs98cPM0gR: KYm6wdR9sybGfD5 = KYm6wdR9sybGfD5.decode(a7VXeDU82IfQEnPZAdiT)
		yyNarzLupGhMDcCjwUedIZiTWB = Cy9ow3c21nABMjzqeaIT(zyvJMtBhrw(u"ࠬࡪࡩࡤࡶࠪင"),KYm6wdR9sybGfD5)
		if yyNarzLupGhMDcCjwUedIZiTWB:
			N6NCYivtV4I5rEXq = {}
			for jKJu4sm3FwBXipMExahVcdgRQUr7 in yyNarzLupGhMDcCjwUedIZiTWB.keys():
				N6NCYivtV4I5rEXq[jKJu4sm3FwBXipMExahVcdgRQUr7] = []
				for PtIHzcFjvdAf in yyNarzLupGhMDcCjwUedIZiTWB[jKJu4sm3FwBXipMExahVcdgRQUr7]:
					X3X4Y8RzxSVfZJUFDe,wJUqaIAzvtsMSEZlKV,S6NALBOqGn1zi2W5M8y7,u2GRrQ0854,nWE8aO53lFfD,l7COkhRWD9uVS60Pte2NoyAaZn,XNBHzrlKD9yW,MH5c7Nekugx8O1AQjInRWyT64GV,SX7OT3VLGp2iQm = hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj
					X3X4Y8RzxSVfZJUFDe = PtIHzcFjvdAf[ybdv7XcT3lxF6QezULwCAGk]
					wJUqaIAzvtsMSEZlKV = PtIHzcFjvdAf[bXukYxQ4aHw]
					wJUqaIAzvtsMSEZlKV = RqfZ4ma8Jjh9EU(wJUqaIAzvtsMSEZlKV)
					S6NALBOqGn1zi2W5M8y7 = PtIHzcFjvdAf[Y0XZKGRAUQj5O]
					u2GRrQ0854 = PtIHzcFjvdAf[x1x9kIQo3zjZWnYaiy]
					nWE8aO53lFfD = PtIHzcFjvdAf[jR6BYWNFZ0egmH4Tr2Q78LbSs3t]
					l7COkhRWD9uVS60Pte2NoyAaZn = PtIHzcFjvdAf[SqrG5mU3j96ldsFpExobw40TJY(u"࠹ᑪ")]
					if len(PtIHzcFjvdAf)>S1SgCFYGJeMvfp5iZXK(u"࠻ᑫ"): XNBHzrlKD9yW = PtIHzcFjvdAf[S1SgCFYGJeMvfp5iZXK(u"࠻ᑫ")]
					if len(PtIHzcFjvdAf)>MMizeNH0AKu(u"࠽ᑬ"): MH5c7Nekugx8O1AQjInRWyT64GV = PtIHzcFjvdAf[MMizeNH0AKu(u"࠽ᑬ")]
					if len(PtIHzcFjvdAf)>XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"࠸ᑭ"): SX7OT3VLGp2iQm = PtIHzcFjvdAf[XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"࠸ᑭ")]
					if QTkAP1Nv4cDU0mVuWirzpafolHxF6==IlCq2uKjye3ZgSADFc: Z5wmHXfJd3nklhQTEWyjegRt1MU = X3X4Y8RzxSVfZJUFDe,wJUqaIAzvtsMSEZlKV,S6NALBOqGn1zi2W5M8y7,u2GRrQ0854,nWE8aO53lFfD,l7COkhRWD9uVS60Pte2NoyAaZn,XNBHzrlKD9yW,hWGMqtBy4wuLaVcj,SX7OT3VLGp2iQm
					else: Z5wmHXfJd3nklhQTEWyjegRt1MU = X3X4Y8RzxSVfZJUFDe,wJUqaIAzvtsMSEZlKV,S6NALBOqGn1zi2W5M8y7,u2GRrQ0854,nWE8aO53lFfD,l7COkhRWD9uVS60Pte2NoyAaZn,XNBHzrlKD9yW,MH5c7Nekugx8O1AQjInRWyT64GV,SX7OT3VLGp2iQm
					N6NCYivtV4I5rEXq[jKJu4sm3FwBXipMExahVcdgRQUr7].append(Z5wmHXfJd3nklhQTEWyjegRt1MU)
		ZkO6hteNg43 = str(N6NCYivtV4I5rEXq)
		if H4qZ2hwilNJYTmCFEQyaSs98cPM0gR: ZkO6hteNg43 = ZkO6hteNg43.encode(a7VXeDU82IfQEnPZAdiT)
		open(QTkAP1Nv4cDU0mVuWirzpafolHxF6,QVDJLRlxNg127jMX(u"࠭ࡷࡣࠩစ")).write(ZkO6hteNg43)
	return N6NCYivtV4I5rEXq
def CPGup68qUQdti5IVeS7kXRA(ITlpOFqLn7W2hYkdijCogm):
	IqUKC95Hs26Vbn0BT3exP = ITlpOFqLn7W2hYkdijCogm.split(SqrG5mU3j96ldsFpExobw40TJY(u"ࠧ࠮ࠩဆ"),bXukYxQ4aHw)[ybdv7XcT3lxF6QezULwCAGk]
	OLEaRvPrIK,jybQBYEnf41IACTROeGlDdP9z,lr6UH3CkoIi9tuabRW4Vwe1 = hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj
	if   IqUKC95Hs26Vbn0BT3exP==A6dMB1FlgxVivJ2fk9C(u"ࠨࡃࡋ࡛ࡆࡑࠧဇ")		:	from pKDY172QWZ			import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠩࡄࡏࡔࡇࡍࠨဈ")		:	from ppotHCQbEN			import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==HHoGx7Flus60(u"ࠪࡅࡐࡕࡁࡎࡅࡄࡑࠬဉ")	:	from LezUiM6xTS		import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠫࡆࡑࡗࡂࡏࠪည")		:	from rrg9LDpKux			import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==SqrG5mU3j96ldsFpExobw40TJY(u"ࠬࡇࡋࡘࡃࡐࡘ࡚ࡈࡅࠨဋ")	:	from PNvhBGumD2		import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==ITvnUAMXsyb4eO(u"࠭ࡁࡍࡃࡕࡅࡇ࠭ဌ")	:	from Ae3wOYF2i9			import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==e2qDYgipPmTw4KvBLnochr(u"ࠧࡂࡎࡉࡅ࡙ࡏࡍࡊࠩဍ")	:	from p7pov5YVL9		import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠨࡃࡏࡏࡆ࡝ࡔࡉࡃࡕࠫဎ")	: 	from bjghZzTf0c		import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==zyvJMtBhrw(u"ࠩࡄࡐࡒࡇࡁࡓࡇࡉࠫဏ")	:	from Fa2eEo4S9J		import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==SqrG5mU3j96ldsFpExobw40TJY(u"ࠪࡅࡑࡓࡓࡕࡄࡄࠫတ")	:	from rz0JjOH9Pc		import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠫࡆࡔࡉࡎࡇ࡝ࡍࡉ࠭ထ")	:	from Emt50CqprJ		import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠬࡇࡒࡂࡄࡌࡇ࡙ࡕࡏࡏࡕࠪဒ"):	from xwIpWjhr3M	import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==sULh4NjakzI8He7xJCMGrql(u"࠭ࡁࡓࡃࡅࡗࡊࡋࡄࠨဓ")	:	from WW2cFhXPaH		import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==CnbBKmtF1x84q7AW(u"ࠧࡂ࡛ࡏࡓࡑ࠭န")		:	from sH0dnxVKFJ			import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==DJ1ICpbyR2(u"ࠨࡄࡒࡏࡗࡇࠧပ")		:	from UN2CkoBwZe			import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==xcChIL13BpR8WArNt9Pl0So(u"ࠩࡅࡖࡘ࡚ࡅࡋࠩဖ")	:	from lov2yxN1tT			import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==MMizeNH0AKu(u"ࠪࡇࡎࡓࡁ࠵࠲࠳ࠫဗ")	:	from vHtyTdOp6l		import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==KBkxSYaz93pu1(u"ࠫࡈࡏࡍࡂ࠶ࡓࠫဘ")	:	from SqMfJo0ztI			import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠬࡉࡉࡎࡃ࠷࡙ࠬမ")	:	from iiYkxqCpdD			import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"࠭ࡃࡊࡏࡄࡅࡇࡊࡏࠨယ")	:	from SgYBRznWJk		import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==QVDJLRlxNg127jMX(u"ࠧࡄࡋࡐࡅࡈࡒࡕࡃࠩရ")	:	from n6xPM2Olgc		import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==CnbBKmtF1x84q7AW(u"ࠨࡅࡌࡑࡆࡉࡌࡖࡄ࡚ࡓࡗࡑࠧလ"):	from EEWqhiFTue	import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==rwQN9AKhLCuMfHxjlbX0U(u"ࠩࡆࡍࡒࡇࡃࡍࡗࡓࠫဝ")	:	from gfjYczHh48		import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==ITvnUAMXsyb4eO(u"ࠪࡇࡎࡓࡁࡇࡃࡑࡗࠬသ")	:	from MdvaXFz729		import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==xcChIL13BpR8WArNt9Pl0So(u"ࠫࡈࡏࡍࡂࡈࡕࡉࡊ࠭ဟ")	:	from H1xaqgTriF		import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠬࡉࡉࡎࡃࡏࡍࡌࡎࡔࠨဠ")	:	from RRDSYVUTXZ		import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==sULh4NjakzI8He7xJCMGrql(u"࠭ࡃࡊࡏࡄࡒࡔ࡝ࠧအ")	:	from QvHhfzTkoM		import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠧࡄࡋࡐࡅ࡜ࡈࡁࡔࠩဢ")	:	from YYt6vwDOTs		import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==sULh4NjakzI8He7xJCMGrql(u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠭ဣ"):	from KaPoYWIB1b	import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==wwPrSDa21lUh(u"ࠩࡇࡖࡆࡓࡁࡄࡃࡉࡉࠬဤ")	:	from hSqClboQNY		import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==jeAby54c02TgG8zuivonX91(u"ࠪࡈࡗࡇࡍࡂࡕ࠺ࠫဥ")	:	from E5HZz8RP0h		import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==SqrG5mU3j96ldsFpExobw40TJY(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘࠬဦ")	:	from yIhj3FvGAO		import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠷ࠧဧ")	:	from Ojbi3BT8p2		import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠲ࠨဨ")	:	from b0brqMUFiE		import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠴ࠩဩ")	:	from CtRiO8neuX		import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==DJ1ICpbyR2(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠶ࠪဪ")	:	from jwnTvOI7lZ		import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==zyvJMtBhrw(u"ࠩࡈࡋ࡞ࡊࡅࡂࡆࠪါ")	:	from rTyhA5HbqP		import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==sULh4NjakzI8He7xJCMGrql(u"ࠪࡉࡌ࡟ࡎࡐ࡙ࠪာ")	:	from R3Ok4zXioW			import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==KNIvHPjUbhr(u"ࠫࡊࡒࡃࡊࡐࡈࡑࡆ࠭ိ")	:	from N64dz0xtRK		import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠬࡋࡌࡊࡈ࡙ࡍࡉࡋࡏࠨီ")	:	from GKjdANXSik		import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"࠭ࡆࡂࡄࡕࡅࡐࡇࠧု")	:	from foejGdvkDJ		import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==NeO3CTLHrPfWUoIgy8Q(u"ࠧࡇࡃࡍࡉࡗ࡙ࡈࡐ࡙ࠪူ")	:	from rrhQGPlFcs		import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠨࡈࡄࡖࡊ࡙ࡋࡐࠩေ")	:	from xxQlPRrD2v		import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠩࡉࡅࡘࡋࡌࡉࡆ࠴ࠫဲ")	:	from qZLioIBnmS		import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==mkHKSQvjWr5BTcM3wVY(u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠶ࠬဳ")	:	from FN4qQbOexB		import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠫࡋࡕࡓࡕࡃࠪဴ")		:	from w7ZXtJMzx6			import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==sULh4NjakzI8He7xJCMGrql(u"ࠬࡌࡕࡏࡑࡑࡘ࡛࠭ဵ")	:	from HBlgtOU8y4		import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==CnbBKmtF1x84q7AW(u"࠭ࡆࡖࡕࡋࡅࡗ࡚ࡖࠨံ")	:	from FmvTYZn0qx		import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==MMizeNH0AKu(u"ࠧࡇࡗࡖࡌࡆࡘࡖࡊࡆࡈࡓ့ࠬ"):	from CRtGZ78qjP	import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==CnbBKmtF1x84q7AW(u"ࠨࡉࡒࡓࡌࡒࡅࡔࡇࡄࡖࡈࡎࠧး"):	from xTJfnd8roE	import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠩࡋࡅࡑࡇࡃࡊࡏࡄ္ࠫ")	:	from LnsdUMcbE1		import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==DJ1ICpbyR2(u"ࠪࡍࡋࡏࡌࡎ်ࠩ")		:	from mSb0zlth7R			import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==S1SgCFYGJeMvfp5iZXK(u"ࠫࡎࡖࡔࡗࠩျ")		:	from t2YzocLAmj			import Q7qM9UmTskpgznERAX5wKo0hDb as OLEaRvPrIK,JJZuoXlhrIYv as jybQBYEnf41IACTROeGlDdP9z,O50cprnq2W1DAgTiRZUm as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠬࡑࡁࡓࡄࡄࡐࡆ࡚ࡖࠨြ")	:	from ssoDU5VCYK		import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==mkHKSQvjWr5BTcM3wVY(u"࠭ࡋࡂࡖࡎࡓ࡙࡚ࡖࠨွ")	:	from phOvqEnMQ6		import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==wwPrSDa21lUh(u"ࠧࡌࡃࡗࡏࡔ࡛ࡔࡆࠩှ")	:	from NfoRzjxBK0		import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==rwQN9AKhLCuMfHxjlbX0U(u"ࠨࡍࡌࡖࡒࡇࡌࡌࠩဿ")	:	from CeysAphKI3		import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==rwQN9AKhLCuMfHxjlbX0U(u"ࠩࡏࡅࡗࡕ࡚ࡂࠩ၀")	:	from sqQzra8NCR			import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==QvgnCALNstmuUJiET(u"ࠪࡐࡔࡊ࡙ࡏࡇࡗࠫ၁")	:	from OelsqxmGvT		import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==MMizeNH0AKu(u"ࠫࡒ࠹ࡕࠨ၂")		:	from llfcJ30oFC			import Q7qM9UmTskpgznERAX5wKo0hDb as OLEaRvPrIK,JJZuoXlhrIYv as jybQBYEnf41IACTROeGlDdP9z,O50cprnq2W1DAgTiRZUm as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==rwQN9AKhLCuMfHxjlbX0U(u"ࠬࡓࡁࡔࡃ࡙ࡍࡉࡋࡏࠨ၃")	:	from t8HgZ2C9Ke		import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==KBkxSYaz93pu1(u"࠭ࡍࡐࡘࡖ࠸࡚࠭၄")	:	from N2yYhKoErg			import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==zyvJMtBhrw(u"ࠧࡎ࡛ࡆࡍࡒࡇࠧ၅")	:	from yuDxW8TmPU			import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==QVDJLRlxNg127jMX(u"ࠨࡒࡄࡒࡊ࡚ࠧ၆")		:	from UgZkz8fqRY			import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==QvgnCALNstmuUJiET(u"ࠩࡔࡊࡎࡒࡍࠨ၇")		:	from A4AbDczUxm			import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==QvgnCALNstmuUJiET(u"ࠪࡗࡊࡘࡉࡆࡕࡗࡍࡒࡋࠧ၈"):	from FkGWI3gDLa		import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠫࡘࡎࡁࡃࡃࡎࡅ࡙࡟ࠧ၉")	:	from bXIhFxgaS3		import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==gDuGMR3z1aV6YdLmCpiO8Kl(u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛ࠧ၊")	:	from EEHXBdaKUy		import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"࠭ࡓࡉࡃࡋࡍࡉࡔࡅࡘࡕࠪ။"):	from aLWj7Pi04r		import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==jeAby54c02TgG8zuivonX91(u"ࠧࡔࡊࡌࡅ࡛ࡕࡉࡄࡇࠪ၌")	:	from pWPojqC3cH		import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠨࡕࡋࡓࡋࡎࡁࠨ၍")	:	from RRDrAEy29i			import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠩࡖࡌࡔࡕࡆࡎࡃ࡛ࠫ၎")	:	from mmJPZwCVK4		import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==MMizeNH0AKu(u"ࠪࡗࡍࡕࡏࡇࡐࡈࡘࠬ၏")	:	from oIWgitFG6O		import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠫࡘࡎࡏࡐࡈࡓࡖࡔ࠭ၐ")	:	from ZvTkQpmwgn		import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"࡚ࠬࡉࡌࡃࡄࡘࠬၑ")	:	from jK3sV6LWGX			import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"࠭ࡔࡗࡈࡘࡒࠬၒ")		:	from I8hFklrG4o			import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==xcChIL13BpR8WArNt9Pl0So(u"ࠧࡕࡘࡉ࡙ࡓ࠭ၓ")		:	from I8hFklrG4o			import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==KNIvHPjUbhr(u"ࠨࡘࡄࡖࡇࡕࡎࠨၔ")	:	from Xutmsgp8e4			import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==e2qDYgipPmTw4KvBLnochr(u"࡙ࠩࡍࡉࡋࡏࡏࡕࡄࡉࡒ࠭ၕ"):	from j9JzCRpomK		import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==rwQN9AKhLCuMfHxjlbX0U(u"࡛ࠪࡊࡉࡉࡎࡃ࠴ࠫၖ")	:	from G6MaRNF03P		import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠫ࡜ࡋࡃࡊࡏࡄ࠶ࠬၗ")	:	from jSxyTUJcYz		import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠬ࡟ࡁࡒࡑࡗࠫၘ")		:	from RRGNzFoi7f			import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"࡙࠭ࡐࡗࡗ࡙ࡇࡋࠧၙ")	:	from vgu7JcpdwP		import DP6FSBgNdX1rsvVR as OLEaRvPrIK,lPwaAjFTMG4n7iSLkXcEuK0Zm as jybQBYEnf41IACTROeGlDdP9z,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	elif IqUKC95Hs26Vbn0BT3exP==QvgnCALNstmuUJiET(u"࡚ࠧࡖࡅࡣࡈࡎࡁࡏࡐࡈࡐࡘ࠭ၚ"):	from lBJh4iO8aI	import DP6FSBgNdX1rsvVR as OLEaRvPrIK,n0qFKQWhiBYXoTrvejVHUA4 as lr6UH3CkoIi9tuabRW4Vwe1
	return OLEaRvPrIK,jybQBYEnf41IACTROeGlDdP9z,lr6UH3CkoIi9tuabRW4Vwe1
def kXZctzCN2Fy0o8OG4wE1(bEY274q5aSCjVnHI,UBRzLM6ZdkWOKwy0qPfFIlC,showDialogs):
	KteLZCbM8W0FqE2OBx1(pGYKHZgqFX3B,LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠨ࠰࡟ࡸࡉࡵࡷ࡯࡮ࡲࡥࡩ࡯࡮ࡨ࠼ࠣ࡟ࠥ࠭ၛ")+bEY274q5aSCjVnHI+QvgnCALNstmuUJiET(u"ࠩࠣࡡࠥࠦࠠࡉࡧࡤࡨࡪࡸࡳ࠻ࠢ࡞ࠤࠬၜ")+str(UBRzLM6ZdkWOKwy0qPfFIlC)+LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠪࠤࡢ࠭ၝ"))
	xX7c9PeCsht = Tbof9Jl4eHnYZMvVEBFgCh1G3mLtd()
	xX7c9PeCsht.create(OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧၞ"),gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠬ๐ฬา์ࠣห้ศๆࠡใะูࠥอไๆๆไࠤฬ๊ๅุๆ๋ฬࠥะอๆ์็๋ࠥ๎ศฺั๊หู่ࠥโࠢอฬิษฺࠠ็็๎ฮࠦฬๅสࠣห้๋ไโ่๊ࠢࠥอไฦ่อี๋ะࠧၟ"))
	BbOC8YeQNkdPlDGKI07xiHtXryJWT = SqrG5mU3j96ldsFpExobw40TJY(u"࠲࠲࠵࠸ᑮ")*SqrG5mU3j96ldsFpExobw40TJY(u"࠲࠲࠵࠸ᑮ")
	ZZwQ8lm9yKNXHUqW = QvgnCALNstmuUJiET(u"࠳ᑯ")*BbOC8YeQNkdPlDGKI07xiHtXryJWT
	import requests as Av8o1XdSJCsG9fHlbEwr7P
	BUXsmKe5dGpJj09REb6HqcO7tNv = Av8o1XdSJCsG9fHlbEwr7P.get(bEY274q5aSCjVnHI,stream=VBlawK4mgHSyLEn8iqhUkz5,headers=UBRzLM6ZdkWOKwy0qPfFIlC)
	or1MZWjDthPQLvxq0ldzYGeFk = BUXsmKe5dGpJj09REb6HqcO7tNv.headers
	BUXsmKe5dGpJj09REb6HqcO7tNv.close()
	XAnE10OJLZyTSKFkVgu = bytes()
	if not or1MZWjDthPQLvxq0ldzYGeFk:
		if showDialogs: BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,rwQN9AKhLCuMfHxjlbX0U(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩၠ"),HHoGx7Flus60(u"ࠧศๆหี๋อๅอࠢ็้ࠥ๐สๆๅ้ࠤ๊์ࠠหฯ่๎้ࠦวๅ็็ๅࠥอไๆู็์อ่ࠦศๆึฬอࠦโะࠢํ็ํ์ฺ่ࠠา็๋ࠥิไๆฬࠤๆ๐ࠠศๆศ๊ฯืๆหࠢส่ำอีࠡสๆࠤ࠳ࠦฬาสࠣฮา๋๊ๅࠢส่๊๊แࠡ็ิอࠥษฮา๋ࠪၡ"))
		xX7c9PeCsht.close()
	else:
		if LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡏࡩࡳ࡭ࡴࡩࠩၢ") not in list(or1MZWjDthPQLvxq0ldzYGeFk.keys()): YSExzXvF7uwaCpBNKVL6q3edh2I = ybdv7XcT3lxF6QezULwCAGk
		else: YSExzXvF7uwaCpBNKVL6q3edh2I = int(or1MZWjDthPQLvxq0ldzYGeFk[GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡐࡪࡴࡧࡵࡪࠪၣ")])
		v4FRsANbo5Mp = str(int(o1u5dij9UrcbXzVS8lwIWfKpnqM(u"࠵࠵࠶࠰ᑱ")*YSExzXvF7uwaCpBNKVL6q3edh2I/BbOC8YeQNkdPlDGKI07xiHtXryJWT)/mkHKSQvjWr5BTcM3wVY(u"࠴࠴࠵࠶࠮࠱ᑰ"))
		YBKMvnlNx08XPVrGq = int(YSExzXvF7uwaCpBNKVL6q3edh2I/ZZwQ8lm9yKNXHUqW)+bXukYxQ4aHw
		if XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱ࡗࡧ࡮ࡨࡧࠪၤ") in list(or1MZWjDthPQLvxq0ldzYGeFk.keys()) and YSExzXvF7uwaCpBNKVL6q3edh2I>BbOC8YeQNkdPlDGKI07xiHtXryJWT:
			XZfVpSaoQMLU40c6D = VBlawK4mgHSyLEn8iqhUkz5
			AGEO3hYx7IwHPv = []
			kNTUdunPRifIlAZ = dv0trJR7PwmKyxDYO52VLau8gEph(u"࠶࠶ᑲ")
			AGEO3hYx7IwHPv.append(str(ybdv7XcT3lxF6QezULwCAGk*YSExzXvF7uwaCpBNKVL6q3edh2I//kNTUdunPRifIlAZ)+KNIvHPjUbhr(u"ࠫ࠲࠭ၥ")+str(bXukYxQ4aHw*YSExzXvF7uwaCpBNKVL6q3edh2I//kNTUdunPRifIlAZ-bXukYxQ4aHw))
			AGEO3hYx7IwHPv.append(str(bXukYxQ4aHw*YSExzXvF7uwaCpBNKVL6q3edh2I//kNTUdunPRifIlAZ)+hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠬ࠳ࠧၦ")+str(Y0XZKGRAUQj5O*YSExzXvF7uwaCpBNKVL6q3edh2I//kNTUdunPRifIlAZ-bXukYxQ4aHw))
			AGEO3hYx7IwHPv.append(str(Y0XZKGRAUQj5O*YSExzXvF7uwaCpBNKVL6q3edh2I//kNTUdunPRifIlAZ)+hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"࠭࠭ࠨၧ")+str(x1x9kIQo3zjZWnYaiy*YSExzXvF7uwaCpBNKVL6q3edh2I//kNTUdunPRifIlAZ-bXukYxQ4aHw))
			AGEO3hYx7IwHPv.append(str(x1x9kIQo3zjZWnYaiy*YSExzXvF7uwaCpBNKVL6q3edh2I//kNTUdunPRifIlAZ)+A6dMB1FlgxVivJ2fk9C(u"ࠧ࠮ࠩၨ")+str(jR6BYWNFZ0egmH4Tr2Q78LbSs3t*YSExzXvF7uwaCpBNKVL6q3edh2I//kNTUdunPRifIlAZ-bXukYxQ4aHw))
			AGEO3hYx7IwHPv.append(str(jR6BYWNFZ0egmH4Tr2Q78LbSs3t*YSExzXvF7uwaCpBNKVL6q3edh2I//kNTUdunPRifIlAZ)+NeO3CTLHrPfWUoIgy8Q(u"ࠨ࠯ࠪၩ")+str(ITvnUAMXsyb4eO(u"࠻ᑳ")*YSExzXvF7uwaCpBNKVL6q3edh2I//kNTUdunPRifIlAZ-bXukYxQ4aHw))
			AGEO3hYx7IwHPv.append(str(CnbBKmtF1x84q7AW(u"࠵ᑴ")*YSExzXvF7uwaCpBNKVL6q3edh2I//kNTUdunPRifIlAZ)+hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠩ࠰ࠫၪ")+str(jeAby54c02TgG8zuivonX91(u"࠷ᑵ")*YSExzXvF7uwaCpBNKVL6q3edh2I//kNTUdunPRifIlAZ-bXukYxQ4aHw))
			AGEO3hYx7IwHPv.append(str(GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"࠹ᑷ")*YSExzXvF7uwaCpBNKVL6q3edh2I//kNTUdunPRifIlAZ)+KNIvHPjUbhr(u"ࠪ࠱ࠬၫ")+str(GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"࠹ᑶ")*YSExzXvF7uwaCpBNKVL6q3edh2I//kNTUdunPRifIlAZ-bXukYxQ4aHw))
			AGEO3hYx7IwHPv.append(str(LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"࠼ᑹ")*YSExzXvF7uwaCpBNKVL6q3edh2I//kNTUdunPRifIlAZ)+KNIvHPjUbhr(u"ࠫ࠲࠭ၬ")+str(SqrG5mU3j96ldsFpExobw40TJY(u"࠼ᑸ")*YSExzXvF7uwaCpBNKVL6q3edh2I//kNTUdunPRifIlAZ-bXukYxQ4aHw))
			AGEO3hYx7IwHPv.append(str(KBkxSYaz93pu1(u"࠸ᑻ")*YSExzXvF7uwaCpBNKVL6q3edh2I//kNTUdunPRifIlAZ)+o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠬ࠳ࠧၭ")+str(KBkxSYaz93pu1(u"࠿ᑺ")*YSExzXvF7uwaCpBNKVL6q3edh2I//kNTUdunPRifIlAZ-bXukYxQ4aHw))
			AGEO3hYx7IwHPv.append(str(GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"࠺ᑼ")*YSExzXvF7uwaCpBNKVL6q3edh2I//kNTUdunPRifIlAZ)+zyvJMtBhrw(u"࠭࠭ࠨၮ"))
			m5sMGJRrNLCEfjQUh3HB876FDndc = float(YBKMvnlNx08XPVrGq)/kNTUdunPRifIlAZ
			oWO2t6d3xvyAfLuimBRhjpUXFN = m5sMGJRrNLCEfjQUh3HB876FDndc/int(bXukYxQ4aHw+m5sMGJRrNLCEfjQUh3HB876FDndc)
		else:
			XZfVpSaoQMLU40c6D = fEXMiAyG3ql4vKB
			kNTUdunPRifIlAZ = bXukYxQ4aHw
			oWO2t6d3xvyAfLuimBRhjpUXFN = bXukYxQ4aHw
		KteLZCbM8W0FqE2OBx1(pGYKHZgqFX3B,DJ1ICpbyR2(u"ࠧ࠯࡞ࡷࡈࡴࡽ࡮࡭ࡱࡤࡨࠥࡻࡳࡪࡰࡪࠤࡷࡧ࡮ࡨࡧࡶ࠾ࠥࡡࠠࠨၯ")+str(XZfVpSaoQMLU40c6D)+SqrG5mU3j96ldsFpExobw40TJY(u"ࠨࠢࡠࠤࠥࠦࡄࡰࡹࡱࡰࡴࡧࡤࠡࡵ࡬ࡾࡪࡀࠠ࡜ࠢࠪၰ")+str(YSExzXvF7uwaCpBNKVL6q3edh2I)+rwQN9AKhLCuMfHxjlbX0U(u"ࠩࠣࡡࠬၱ"))
		JpzD0lv9cYM6XrHeqCa,ipUCFWscIvkXTb81qdJQZ09 = ybdv7XcT3lxF6QezULwCAGk,ybdv7XcT3lxF6QezULwCAGk
		for h7MpBTVqyLOX4jxi1mrRN8CAZkEn in range(kNTUdunPRifIlAZ):
			PwvNmnqXKrYVZugB5c8 = UBRzLM6ZdkWOKwy0qPfFIlC.copy()
			if XZfVpSaoQMLU40c6D: PwvNmnqXKrYVZugB5c8[JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠪࡖࡦࡴࡧࡦࠩၲ")] = xcChIL13BpR8WArNt9Pl0So(u"ࠫࡧࡿࡴࡦࡵࡀࠫၳ")+AGEO3hYx7IwHPv[h7MpBTVqyLOX4jxi1mrRN8CAZkEn]
			BUXsmKe5dGpJj09REb6HqcO7tNv = Av8o1XdSJCsG9fHlbEwr7P.get(bEY274q5aSCjVnHI,stream=VBlawK4mgHSyLEn8iqhUkz5,headers=PwvNmnqXKrYVZugB5c8,timeout=wwPrSDa21lUh(u"࠵࠳࠴ᑽ"))
			for YFLzEXuBk8ZRec9nTCypv4OQi in BUXsmKe5dGpJj09REb6HqcO7tNv.iter_content(chunk_size=ZZwQ8lm9yKNXHUqW):
				if xX7c9PeCsht.iscanceled():
					KteLZCbM8W0FqE2OBx1(pGYKHZgqFX3B,xcChIL13BpR8WArNt9Pl0So(u"ࠬ࠴࡜ࡵࡆࡲࡻࡳࡲ࡯ࡢࡦࠣࡇࡦࡴࡣࡦ࡮ࡨࡨࠬၴ"))
					break
				JpzD0lv9cYM6XrHeqCa += oWO2t6d3xvyAfLuimBRhjpUXFN
				XAnE10OJLZyTSKFkVgu += YFLzEXuBk8ZRec9nTCypv4OQi
				if not ipUCFWscIvkXTb81qdJQZ09: ipUCFWscIvkXTb81qdJQZ09 = len(YFLzEXuBk8ZRec9nTCypv4OQi)
				if YSExzXvF7uwaCpBNKVL6q3edh2I: CEIhS05OkFWGozARVZwnyrXf6(xX7c9PeCsht,MMizeNH0AKu(u"࠴࠴࠵ᑾ")*JpzD0lv9cYM6XrHeqCa//YBKMvnlNx08XPVrGq,zyvJMtBhrw(u"࠭ฬๅสࠣห้๋ไโ࠼࠰ࠤฬ๊ฬำรࠣี็๋ࠧၵ"),str(JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"࠵࠵࠶࠮࠱ᑿ")*ipUCFWscIvkXTb81qdJQZ09*JpzD0lv9cYM6XrHeqCa//ZZwQ8lm9yKNXHUqW//JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"࠵࠵࠶࠮࠱ᑿ"))+EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠧࠡ࠱ࠣࠫၶ")+v4FRsANbo5Mp+dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠨࠢࡐࡆࠬၷ"))
				else: CEIhS05OkFWGozARVZwnyrXf6(xX7c9PeCsht,ipUCFWscIvkXTb81qdJQZ09*JpzD0lv9cYM6XrHeqCa//ZZwQ8lm9yKNXHUqW,rwQN9AKhLCuMfHxjlbX0U(u"ࠩฯ่อࠦวๅ็็ๅ࠿࠳ࠧၸ"),str(KNIvHPjUbhr(u"࠶࠶࠰࠯࠲ᒀ")*ipUCFWscIvkXTb81qdJQZ09*JpzD0lv9cYM6XrHeqCa//ZZwQ8lm9yKNXHUqW//KNIvHPjUbhr(u"࠶࠶࠰࠯࠲ᒀ"))+EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠪࠤࡒࡈࠧၹ"))
			BUXsmKe5dGpJj09REb6HqcO7tNv.close()
		xX7c9PeCsht.close()
		if len(XAnE10OJLZyTSKFkVgu)<YSExzXvF7uwaCpBNKVL6q3edh2I and YSExzXvF7uwaCpBNKVL6q3edh2I>ybdv7XcT3lxF6QezULwCAGk:
			KteLZCbM8W0FqE2OBx1(pGYKHZgqFX3B,QVDJLRlxNg127jMX(u"ࠫ࠳ࡢࡴࡅࡱࡺࡲࡱࡵࡡࡥࠢࡩࡥ࡮ࡲࡥࡥࠢࡲࡶࠥࡩࡡ࡯ࡥࡨࡰࡪࡪࠠࡢࡶ࠽ࠤࡠࠦࠧၺ")+str(len(XAnE10OJLZyTSKFkVgu)//BbOC8YeQNkdPlDGKI07xiHtXryJWT)+ITvnUAMXsyb4eO(u"ࠬࠦࡍࡃࠢࡠࠤࠥࠦࡆࡳࡱࡰࠤࡹࡵࡴࡢ࡮ࠣࡳ࡫ࡀࠠ࡜ࠢࠪၻ")+v4FRsANbo5Mp+JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"࠭ࠠࡎࡄࠣࡡࠬၼ"))
			c7doTBkbPWtIsGlgeFa58f = jbQkTyxAerZR409gYFq(hWGMqtBy4wuLaVcj,zyvJMtBhrw(u"ࠧฦๆ฽หฦ่ࠦฯำ๋ะࠬၽ"),sULh4NjakzI8He7xJCMGrql(u"ࠨษึฮำีวๆࠢส่๊๊แࠡษ็๊ฬ่ีࠨၾ"),zyvJMtBhrw(u"ࠩศ฽ฬีษࠡฮ็ฬࠥอไๆๆไࠫၿ"),CnbBKmtF1x84q7AW(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ႀ"),QvgnCALNstmuUJiET(u"ࠫๆฺไࠡใํࠤั๊ศࠡษ็้้็ࠠ࡝ࡰ่้ࠣษำโࠢะำะࠦฮุลࠣๅ๏ࠦสฮ็ํ่ࠥอไๆๆไࠤࡡࡴࠠห็ࠣะ้ฮࠠࠨႁ")+str(len(XAnE10OJLZyTSKFkVgu)//BbOC8YeQNkdPlDGKI07xiHtXryJWT)+DJ1ICpbyR2(u"ࠬࠦๅ๋฼สฬฬ๐สࠡ็้ࠤ๊าๅ้฻ࠣࠫႂ")+v4FRsANbo5Mp+EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"࠭ࠠๆ์฽หออ๊หࠢ࡟ࡲࠥาัษࠢฯ่อࠦวๅ็็ๅ๋ࠥัสࠢฦาึ๏ࠠ࡝ࡰ๋้ࠣࠦสา์าࠤฬูสฯัส้ࠥอไๆๆไࠤฬ๊ๆศไุࠤฤࠧࠡࠨႃ"))
			if c7doTBkbPWtIsGlgeFa58f==Y0XZKGRAUQj5O: XAnE10OJLZyTSKFkVgu = kXZctzCN2Fy0o8OG4wE1(bEY274q5aSCjVnHI,UBRzLM6ZdkWOKwy0qPfFIlC,showDialogs)
			elif c7doTBkbPWtIsGlgeFa58f==bXukYxQ4aHw: KteLZCbM8W0FqE2OBx1(pGYKHZgqFX3B,KBkxSYaz93pu1(u"ࠧ࠯࡞ࡷࡒࡴࡺࠠࡤࡱࡰࡴࡱ࡫ࡴࡦࡦࠣࡨࡴࡽ࡮࡭ࡱࡤࡨࡪࡪࠠࡧ࡫࡯ࡩࠥ࡯ࡳࠡࡣࡦࡧࡪࡶࡴࡦࡦࠣࡥࡳࡪࠠࡸ࡫࡯ࡰࠥࡨࡥࠡࡷࡶࡩࡩ࠭ႄ"))
			else: return hWGMqtBy4wuLaVcj
			if not XAnE10OJLZyTSKFkVgu: return hWGMqtBy4wuLaVcj
		else: KteLZCbM8W0FqE2OBx1(pGYKHZgqFX3B,mkHKSQvjWr5BTcM3wVY(u"ࠨ࠰࡟ࡸࡉࡵࡷ࡯࡮ࡲࡥࡩࠦࡓࡶࡥࡦࡩࡪࡪࡥࡥ࠰ࠣࠤࠥࡌࡩ࡭ࡧࠣࡗ࡮ࢀࡥ࠻ࠢ࡞ࠤࠬႅ")+v4FRsANbo5Mp+KNIvHPjUbhr(u"ࠩࠣࡑࡇࠦ࡝ࠨႆ"))
	return XAnE10OJLZyTSKFkVgu
def NdG0OKmwRPhaYBrzJi7(xjPuFK3EsIZSiobQ5X):
	return BUXsmKe5dGpJj09REb6HqcO7tNv
def gHXD9xAZTjLSkqhuV42cIa(ip=hWGMqtBy4wuLaVcj):
	global MmavK9YO5hEt4q8LjX6cuW
	if MmavK9YO5hEt4q8LjX6cuW: return MmavK9YO5hEt4q8LjX6cuW
	x1luGzZKLQ7eniFBHrf,ZG7ywHXrqjgUomtR45kuL,JlhDjVQaFZf9bxEGR462is,kMahriDNUClF4vm2XVSLz,ZhM7kf4FNAOwQaDeslvKXmL2c,a1auNgfc7rdIC5vxmhOi = hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj
	S6NALBOqGn1zi2W5M8y7 = LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡭ࡵࡽࡨࡰ࠰࡬ࡷ࠴࠭ႇ")+ip+wwPrSDa21lUh(u"ࠫࡄࡵࡵࡵࡲࡸࡸࡂࡰࡳࡰࡰࠩࡪ࡮࡫࡬ࡥࡵࡀ࡭ࡵ࠲ࡣࡰࡰࡷ࡭ࡳ࡫࡮ࡵ࠮ࡦࡳࡺࡴࡴࡳࡻ࠯ࡧࡴࡻ࡮ࡵࡴࡼࡣࡨࡵࡤࡦ࠮ࡵࡩ࡬࡯࡯࡯࠮ࡦ࡭ࡹࡿࠬࡵ࡫ࡰࡩࡿࡵ࡮ࡦࠩႈ")
	UBRzLM6ZdkWOKwy0qPfFIlC = {HHoGx7Flus60(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩႉ"):hWGMqtBy4wuLaVcj}
	BUXsmKe5dGpJj09REb6HqcO7tNv = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(nHBb7jXk0Daom,gDuGMR3z1aV6YdLmCpiO8Kl(u"࠭ࡇࡆࡖࠪႊ"),S6NALBOqGn1zi2W5M8y7,hWGMqtBy4wuLaVcj,UBRzLM6ZdkWOKwy0qPfFIlC,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,SqrG5mU3j96ldsFpExobw40TJY(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡉࡈࡓࡑࡕࡃࡂࡖࡌࡓࡓ࠳࠱ࡴࡶࠪႋ"))
	if not BUXsmKe5dGpJj09REb6HqcO7tNv.succeeded:
		S6NALBOqGn1zi2W5M8y7 = gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡫ࡳ࠱ࡦࡶࡩ࠯ࡥࡲࡱ࠴ࡰࡳࡰࡰ࠲ࠫႌ")+ip+zyvJMtBhrw(u"ࠩࡂࡪ࡮࡫࡬ࡥࡵࡀࡵࡺ࡫ࡲࡺ࠮ࡦࡳࡳࡺࡩ࡯ࡧࡱࡸ࠱ࡩ࡯ࡶࡰࡷࡶࡾ࠲ࡣࡰࡷࡱࡸࡷࡿࡃࡰࡦࡨ࠰ࡷ࡫ࡧࡪࡱࡱࡒࡦࡳࡥ࠭ࡥ࡬ࡸࡾ࠲࡯ࡧࡨࡶࡩࡹႍ࠭")
		BUXsmKe5dGpJj09REb6HqcO7tNv = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(nHBb7jXk0Daom,MMizeNH0AKu(u"ࠪࡋࡊ࡚ࠧႎ"),S6NALBOqGn1zi2W5M8y7,hWGMqtBy4wuLaVcj,UBRzLM6ZdkWOKwy0qPfFIlC,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡅࡐࡎࡒࡇࡆ࡚ࡉࡐࡐ࠰࠶ࡳࡪࠧႏ"))
	if BUXsmKe5dGpJj09REb6HqcO7tNv.succeeded:
		mMQ3FkNVa4IlxqY = BUXsmKe5dGpJj09REb6HqcO7tNv.content
		NiX4H08IWt3KPxEAjTFSGuC = TPDQ5L9eWpIJcrM3YH48Cs6.loads(mMQ3FkNVa4IlxqY)
		KmPkItvn58cSfDhuNYalOgz1 = list(NiX4H08IWt3KPxEAjTFSGuC.keys())
		if KBkxSYaz93pu1(u"ࠬ࡯ࡰࠨ႐") in KmPkItvn58cSfDhuNYalOgz1: ip = NiX4H08IWt3KPxEAjTFSGuC[SqrG5mU3j96ldsFpExobw40TJY(u"࠭ࡩࡱࠩ႑")]
		if S1SgCFYGJeMvfp5iZXK(u"ࠧࡤࡱࡱࡸ࡮ࡴࡥ࡯ࡶࠪ႒") in KmPkItvn58cSfDhuNYalOgz1: x1luGzZKLQ7eniFBHrf = NiX4H08IWt3KPxEAjTFSGuC[DJ1ICpbyR2(u"ࠨࡥࡲࡲࡹ࡯࡮ࡦࡰࡷࠫ႓")]
		if DJ1ICpbyR2(u"ࠩࡦࡳࡺࡴࡴࡳࡻࠪ႔") in KmPkItvn58cSfDhuNYalOgz1: ZG7ywHXrqjgUomtR45kuL = NiX4H08IWt3KPxEAjTFSGuC[EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠪࡧࡴࡻ࡮ࡵࡴࡼࠫ႕")]
		if rwQN9AKhLCuMfHxjlbX0U(u"ࠫࡨࡵࡵ࡯ࡶࡵࡽࡤࡩ࡯ࡥࡧࠪ႖") in KmPkItvn58cSfDhuNYalOgz1: JlhDjVQaFZf9bxEGR462is = NiX4H08IWt3KPxEAjTFSGuC[dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠬࡩ࡯ࡶࡰࡷࡶࡾࡥࡣࡰࡦࡨࠫ႗")]
		if KNIvHPjUbhr(u"࠭ࡲࡦࡩ࡬ࡳࡳ࠭႘") in KmPkItvn58cSfDhuNYalOgz1: kMahriDNUClF4vm2XVSLz = NiX4H08IWt3KPxEAjTFSGuC[KBkxSYaz93pu1(u"ࠧࡳࡧࡪ࡭ࡴࡴࠧ႙")]
		if zyvJMtBhrw(u"ࠨࡥ࡬ࡸࡾ࠭ႚ") in KmPkItvn58cSfDhuNYalOgz1: ZhM7kf4FNAOwQaDeslvKXmL2c = NiX4H08IWt3KPxEAjTFSGuC[wwPrSDa21lUh(u"ࠩࡦ࡭ࡹࡿࠧႛ")]
		if XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠪࡵࡺ࡫ࡲࡺࠩႜ") in KmPkItvn58cSfDhuNYalOgz1: ip = NiX4H08IWt3KPxEAjTFSGuC[LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠫࡶࡻࡥࡳࡻࠪႝ")]
		if A6dMB1FlgxVivJ2fk9C(u"ࠬࡩ࡯ࡶࡰࡷࡶࡾࡉ࡯ࡥࡧࠪ႞") in KmPkItvn58cSfDhuNYalOgz1: JlhDjVQaFZf9bxEGR462is = NiX4H08IWt3KPxEAjTFSGuC[NeO3CTLHrPfWUoIgy8Q(u"࠭ࡣࡰࡷࡱࡸࡷࡿࡃࡰࡦࡨࠫ႟")]
		if LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠧࡳࡧࡪ࡭ࡴࡴࡎࡢ࡯ࡨࠫႠ") in KmPkItvn58cSfDhuNYalOgz1: kMahriDNUClF4vm2XVSLz = NiX4H08IWt3KPxEAjTFSGuC[MMizeNH0AKu(u"ࠨࡴࡨ࡫࡮ࡵ࡮ࡏࡣࡰࡩࠬႡ")]
		if OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠩࡷ࡭ࡲ࡫ࡺࡰࡰࡨࠫႢ") in KmPkItvn58cSfDhuNYalOgz1:
			a1auNgfc7rdIC5vxmhOi = NiX4H08IWt3KPxEAjTFSGuC[xcChIL13BpR8WArNt9Pl0So(u"ࠪࡸ࡮ࡳࡥࡻࡱࡱࡩࠬႣ")][JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠫࡺࡺࡣࠨႤ")]
			if a1auNgfc7rdIC5vxmhOi[ybdv7XcT3lxF6QezULwCAGk] not in [zyvJMtBhrw(u"ࠬ࠳ࠧႥ"),mkHKSQvjWr5BTcM3wVY(u"࠭ࠫࠨႦ")]: a1auNgfc7rdIC5vxmhOi = ITvnUAMXsyb4eO(u"ࠧࠬࠩႧ")+a1auNgfc7rdIC5vxmhOi
		if S1SgCFYGJeMvfp5iZXK(u"ࠨࡱࡩࡪࡸ࡫ࡴࠨႨ") in KmPkItvn58cSfDhuNYalOgz1:
			a1auNgfc7rdIC5vxmhOi = NiX4H08IWt3KPxEAjTFSGuC[DJ1ICpbyR2(u"ࠩࡲࡪ࡫ࡹࡥࡵࠩႩ")]
			if a1auNgfc7rdIC5vxmhOi>=KBkxSYaz93pu1(u"࠶ᒁ"): a1auNgfc7rdIC5vxmhOi = mkHKSQvjWr5BTcM3wVY(u"ࠪ࠯ࠬႪ")+HB5PvxRhwM.strftime(o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠦࠪࡎ࠺ࠦࡏࠥႫ"),HB5PvxRhwM.gmtime(a1auNgfc7rdIC5vxmhOi))
			else: a1auNgfc7rdIC5vxmhOi = QvgnCALNstmuUJiET(u"ࠬ࠳ࠧႬ")+HB5PvxRhwM.strftime(NeO3CTLHrPfWUoIgy8Q(u"ࠨࠥࡉ࠼ࠨࡑࠧႭ"),HB5PvxRhwM.gmtime(-a1auNgfc7rdIC5vxmhOi))
	MmavK9YO5hEt4q8LjX6cuW = ip+wwPrSDa21lUh(u"ࠧ࠭ࠩႮ")+x1luGzZKLQ7eniFBHrf+zyvJMtBhrw(u"ࠨ࠮ࠪႯ")+ZG7ywHXrqjgUomtR45kuL+CnbBKmtF1x84q7AW(u"ࠩ࠯ࠫႰ")+kMahriDNUClF4vm2XVSLz+GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠪ࠰ࠬႱ")+ZhM7kf4FNAOwQaDeslvKXmL2c+JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠫ࠱࠭Ⴒ")+a1auNgfc7rdIC5vxmhOi
	MmavK9YO5hEt4q8LjX6cuW = MmavK9YO5hEt4q8LjX6cuW.encode(a7VXeDU82IfQEnPZAdiT)
	if H4qZ2hwilNJYTmCFEQyaSs98cPM0gR: MmavK9YO5hEt4q8LjX6cuW = MmavK9YO5hEt4q8LjX6cuW.decode(hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠬࡻ࡮ࡪࡥࡲࡨࡪࡥࡥࡴࡥࡤࡴࡪ࠭Ⴓ"))
	MmavK9YO5hEt4q8LjX6cuW = emr1Lf523Ti0OtcNgxP(MmavK9YO5hEt4q8LjX6cuW)
	return MmavK9YO5hEt4q8LjX6cuW
def IVTEJQOiMR2dYta9C(IvOLJPhdH28irnbcp4oZXf):
	v81TFfeSDlaAdUN,showDialogs = hWGMqtBy4wuLaVcj,VBlawK4mgHSyLEn8iqhUkz5
	if IvOLJPhdH28irnbcp4oZXf.count(FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"࠭࡟ࠨႴ"))>=Y0XZKGRAUQj5O:
		IvOLJPhdH28irnbcp4oZXf,v81TFfeSDlaAdUN = IvOLJPhdH28irnbcp4oZXf.split(SqrG5mU3j96ldsFpExobw40TJY(u"ࠧࡠࠩႵ"),bXukYxQ4aHw)
		v81TFfeSDlaAdUN = zyvJMtBhrw(u"ࠨࡡࠪႶ")+v81TFfeSDlaAdUN
		if rwQN9AKhLCuMfHxjlbX0U(u"ࠩࡢࡒࡔࡊࡉࡂࡎࡒࡋࡘࡥࠧႷ") in v81TFfeSDlaAdUN: showDialogs = fEXMiAyG3ql4vKB
		else: showDialogs = VBlawK4mgHSyLEn8iqhUkz5
	return IvOLJPhdH28irnbcp4oZXf,v81TFfeSDlaAdUN,showDialogs
def wcjqgloENXpdCUKeSJ4m7vL6xQV0k():
	csNdvwrT748l6t9CPm = WQvYkNg7SysPFLitlGEn6.path.join(ggKyfILOkNPGxMtDQueVSZ,ITvnUAMXsyb4eO(u"ࠪࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩႸ"))
	ysvuiDfEtQGxKeIBFd4Y8 = ybdv7XcT3lxF6QezULwCAGk
	if WQvYkNg7SysPFLitlGEn6.path.exists(csNdvwrT748l6t9CPm):
		for o4oOCVEFpXHUwMKszi in WQvYkNg7SysPFLitlGEn6.listdir(csNdvwrT748l6t9CPm):
			if XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠫ࠳ࡶࡹࡰࠩႹ") in o4oOCVEFpXHUwMKszi: continue
			if o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠬࡥ࡟ࡱࡻࡦࡥࡨ࡮ࡥࡠࡡࠪႺ") in o4oOCVEFpXHUwMKszi: continue
			zQS3EpGNX1Pbjy7aWYx = WQvYkNg7SysPFLitlGEn6.path.join(csNdvwrT748l6t9CPm,o4oOCVEFpXHUwMKszi)
			DrvPsiHhIgN2t,SyHorjp3UgM7ZC51 = YAvI1Zz5J3yEFXQdWhqmo6nD(zQS3EpGNX1Pbjy7aWYx)
			ysvuiDfEtQGxKeIBFd4Y8 += DrvPsiHhIgN2t
	return ysvuiDfEtQGxKeIBFd4Y8
def O8JQEp4eTc93zX5RUAnag6K(showDialogs):
	IIkb7rYR5j4ElB6ntAJ1aTKZ9mP = ee8c0jzrTntGSUdRJm.getSetting(rwQN9AKhLCuMfHxjlbX0U(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡰࡩࡸࡹࡡࡨࡧࡶࠫႻ"))
	ApqsfECtUy6 = Mqk51CFBym0pIQXZLsOxSJ(MM5Dx39f7ULhcJsRptzIowP,NeO3CTLHrPfWUoIgy8Q(u"ࠧࡴࡶࡵࠫႼ"),EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫႽ"),MMizeNH0AKu(u"ࠩࡐࡉࡘ࡙ࡁࡈࡇࡖࠫႾ"))
	D8D1ivPr6aR,yk8dfVEC6hTOZxUwiauJsH7lNc3 = IIkb7rYR5j4ElB6ntAJ1aTKZ9mP,ApqsfECtUy6
	w97xtmYBNc81ygViMPSdT3Ifpbvq,uBU0gipbK6Tsfat1LHMYF7CS = hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj
	if bXukYxQ4aHw:
		S6NALBOqGn1zi2W5M8y7 = u6rbxnyjTl7I[A6dMB1FlgxVivJ2fk9C(u"ࠪࡔ࡞࡚ࡈࡐࡐࠪႿ")][x1x9kIQo3zjZWnYaiy]
		Ch3fRqj2lPAZrszcgytLE9BVK = gHXD9xAZTjLSkqhuV42cIa()
		ZG7ywHXrqjgUomtR45kuL = Ch3fRqj2lPAZrszcgytLE9BVK.split(KNIvHPjUbhr(u"ࠫ࠱࠭Ⴠ"))[Y0XZKGRAUQj5O]
		ysvuiDfEtQGxKeIBFd4Y8 = wcjqgloENXpdCUKeSJ4m7vL6xQV0k()
		AqIOj0aJsHQwtvlcyx = {jeAby54c02TgG8zuivonX91(u"ࠬࡻࡳࡦࡴࠪჁ"):IIvxtojw6EXl2f,MMizeNH0AKu(u"࠭ࡶࡦࡴࡶ࡭ࡴࡴࠧჂ"):aO9cFKo862LqTWlIjy,o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠧࡤࡱࡸࡲࡹࡸࡹࠨჃ"):ZG7ywHXrqjgUomtR45kuL,NeO3CTLHrPfWUoIgy8Q(u"ࠨ࡫ࡧࡷࠬჄ"):smVarGBSwFI219cP(ysvuiDfEtQGxKeIBFd4Y8)}
		BUXsmKe5dGpJj09REb6HqcO7tNv = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(lke5D6CpaAXPdEZyrBSw7T,KBkxSYaz93pu1(u"ࠩࡓࡓࡘ࡚ࠧჅ"),S6NALBOqGn1zi2W5M8y7,AqIOj0aJsHQwtvlcyx,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,sULh4NjakzI8He7xJCMGrql(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡋࡔࡠࡏࡈࡗࡘࡇࡇࡆࡕ࠰࠵ࡸࡺࠧ჆"))
		if not BUXsmKe5dGpJj09REb6HqcO7tNv.succeeded:
			if IIkb7rYR5j4ElB6ntAJ1aTKZ9mP in [hWGMqtBy4wuLaVcj,S1SgCFYGJeMvfp5iZXK(u"ࠫࡓࡋࡗࠨჇ")]: D8D1ivPr6aR = dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠬࡔࡅࡘࡡࡗࡓࡤࡋࡒࡓࡑࡕࠫ჈")
			elif IIkb7rYR5j4ElB6ntAJ1aTKZ9mP==rwQN9AKhLCuMfHxjlbX0U(u"࠭ࡏࡍࡆࠪ჉"): D8D1ivPr6aR = XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠧࡐࡎࡇࡣ࡙ࡕ࡟ࡆࡔࡕࡓࡗ࠭჊")
		else:
			r1PkezZDtiN = BUXsmKe5dGpJj09REb6HqcO7tNv.content
			r1PkezZDtiN = Cy9ow3c21nABMjzqeaIT(S1SgCFYGJeMvfp5iZXK(u"ࠨ࡮࡬ࡷࡹ࠭჋"),r1PkezZDtiN)
			r1PkezZDtiN = sorted(r1PkezZDtiN,reverse=VBlawK4mgHSyLEn8iqhUkz5,key=lambda key: int(key[ybdv7XcT3lxF6QezULwCAGk]))
			uBU0gipbK6Tsfat1LHMYF7CS,yk8dfVEC6hTOZxUwiauJsH7lNc3 = hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj
			for JseMBoIbuK95WOSlRQkwrAg,QWv8drSzOeTtAR7GFMjZabn9C,oo4bfXvY8EOqAS90Vd in r1PkezZDtiN:
				if JseMBoIbuK95WOSlRQkwrAg==XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠩ࠳ࠫ჌"):
					uBU0gipbK6Tsfat1LHMYF7CS += oo4bfXvY8EOqAS90Vd+SqrG5mU3j96ldsFpExobw40TJY(u"ࠪ࠾࠿࠭Ⴭ")
					continue
				if yk8dfVEC6hTOZxUwiauJsH7lNc3: yk8dfVEC6hTOZxUwiauJsH7lNc3 += NXMOzZjYsmS9pf+hXB0vKVQ5PRI91SDTprMdfuHEm4+dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠫࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࠪ჎")+YYSh2J6BIrsm8+jeAby54c02TgG8zuivonX91(u"ࠬࡢ࡮࡝ࡰࠪ჏")
				ffarUeK3J1Fo2PSz7B5v = oo4bfXvY8EOqAS90Vd.split(NXMOzZjYsmS9pf)[ybdv7XcT3lxF6QezULwCAGk]
				IfUQDu4t1gGAJpoB = hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"࠭ัิษ็อࠥิวึห่่ࠣࠦแใูࠪა") if QWv8drSzOeTtAR7GFMjZabn9C else hWGMqtBy4wuLaVcj
				yk8dfVEC6hTOZxUwiauJsH7lNc3 += oo4bfXvY8EOqAS90Vd.replace(ffarUeK3J1Fo2PSz7B5v,soMVfbr6WtpNlcSA+ffarUeK3J1Fo2PSz7B5v+IfUQDu4t1gGAJpoB+YYSh2J6BIrsm8)+NXMOzZjYsmS9pf
			yk8dfVEC6hTOZxUwiauJsH7lNc3 = NXMOzZjYsmS9pf+yk8dfVEC6hTOZxUwiauJsH7lNc3+rwQN9AKhLCuMfHxjlbX0U(u"ࠧ࡝ࡰ࡟ࡲࠬბ")
			uBU0gipbK6Tsfat1LHMYF7CS = uBU0gipbK6Tsfat1LHMYF7CS.strip(FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠨ࠼࠽ࠫგ"))
			w97xtmYBNc81ygViMPSdT3Ifpbvq = ee8c0jzrTntGSUdRJm.getSetting(mkHKSQvjWr5BTcM3wVY(u"ࠩࡤࡺ࠳ࡶࡲࡪࡸࡶ࠵ࠬდ"))
			if yk8dfVEC6hTOZxUwiauJsH7lNc3==ApqsfECtUy6 and IIkb7rYR5j4ElB6ntAJ1aTKZ9mP in [JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠪࡓࡑࡊࠧე"),KBkxSYaz93pu1(u"ࠫࡔࡒࡄࡠࡖࡒࡣࡊࡘࡒࡐࡔࠪვ")]: D8D1ivPr6aR = SqrG5mU3j96ldsFpExobw40TJY(u"ࠬࡕࡌࡅࠩზ")
			else: D8D1ivPr6aR = MMizeNH0AKu(u"࠭ࡎࡆ࡙ࠪთ")
			BxuD7iQRpW1(MM5Dx39f7ULhcJsRptzIowP,OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪი"),gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠨࡏࡈࡗࡘࡇࡇࡆࡕࠪკ"),yk8dfVEC6hTOZxUwiauJsH7lNc3,VWxPgG1p8Z2Ei4DrX7NotvR)
			ee8c0jzrTntGSUdRJm.setSetting(DJ1ICpbyR2(u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯࡯ࡨࡷࡸࡧࡧࡦࡵࠪლ"),smVarGBSwFI219cP(IHKJoQ8PwW4pNBR6GTAMVz2hdfC5my))
			ee8c0jzrTntGSUdRJm.setSetting(dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠪࡥࡻ࠴ࡰࡳ࡫ࡹࡷ࠶࠭მ"),uBU0gipbK6Tsfat1LHMYF7CS)
			rKp8WYSPBV3 = xcRlSgBrOhKz69LNou0f8D5MVem.md5(FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"࠵ᒂ")*uBU0gipbK6Tsfat1LHMYF7CS.encode(a7VXeDU82IfQEnPZAdiT)).hexdigest()
			rKp8WYSPBV3 = xcRlSgBrOhKz69LNou0f8D5MVem.md5(mkHKSQvjWr5BTcM3wVY(u"࠲࠶ᒃ")*rKp8WYSPBV3.encode(a7VXeDU82IfQEnPZAdiT)).hexdigest()
			rKp8WYSPBV3 = xcRlSgBrOhKz69LNou0f8D5MVem.md5(SqrG5mU3j96ldsFpExobw40TJY(u"࠳࠼ᒄ")*rKp8WYSPBV3.encode(a7VXeDU82IfQEnPZAdiT)).hexdigest()
			ee8c0jzrTntGSUdRJm.setSetting(A6dMB1FlgxVivJ2fk9C(u"ࠫࡦࡼ࠮ࡱࡴ࡬ࡺࡸ࠸ࠧნ"),rKp8WYSPBV3)
	if showDialogs:
		if D8D1ivPr6aR in [NeO3CTLHrPfWUoIgy8Q(u"ࠬࡕࡌࡅࡡࡗࡓࡤࡋࡒࡓࡑࡕࠫო"),MMizeNH0AKu(u"࠭ࡎࡆ࡙ࡢࡘࡔࡥࡅࡓࡔࡒࡖࠬპ")]:
			BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,CnbBKmtF1x84q7AW(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪჟ"),xcChIL13BpR8WArNt9Pl0So(u"ࠨ้้ห่ࠦๅีๅ็อࠥ็๊ࠡฮ๊หื้้้ࠠํࠤ้๐ำห่๊ࠢࠥอไษำ้ห๊าࠠ࠯࠰๋ࠣีํࠠศๆุ่่๊ษࠡไาࠤ๏้่็ࠢึฬอํวࠡษ็ษ๋ะั็ฬࠣห้ิวึࠢห็ࠥษ่ࠡษ็ีฬ๎สาࠢส่ำอีࠡสๆࠤศ๎ࠠๆึๆ่ฮࠦแ๋ࠢส่ศูไศๅࠣ฽๋ีใࠨრ"))
		else:
			yBv4YaSomFrkejwgNA7pDnKudCz(mkHKSQvjWr5BTcM3wVY(u"ࠩࡵ࡭࡬࡮ࡴࠨს"),mkHKSQvjWr5BTcM3wVY(u"ࠪีุอฦๅ่๊ࠢࠥอไๆสิ้ัࠦลๅุ๋้ࠣะฮะ็ํࠤฬ๊ศา่ส้ั࠭ტ"),yk8dfVEC6hTOZxUwiauJsH7lNc3,LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺ࡟࡭ࡱࡱ࡫ࠬუ"))
			D8D1ivPr6aR = GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠬࡕࡌࡅࠩფ")
	if D8D1ivPr6aR!=IIkb7rYR5j4ElB6ntAJ1aTKZ9mP:
		ee8c0jzrTntGSUdRJm.setSetting(GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡰࡩࡸࡹࡡࡨࡧࡶࠫქ"),D8D1ivPr6aR)
		CfKNTtIi3OABbWcPpdF(fEXMiAyG3ql4vKB)
	jj8v6zNTbiA79Cnl = VBlawK4mgHSyLEn8iqhUkz5 if uBU0gipbK6Tsfat1LHMYF7CS!=w97xtmYBNc81ygViMPSdT3Ifpbvq else fEXMiAyG3ql4vKB
	if jj8v6zNTbiA79Cnl:
		MmcgqAlsFt.j0juxvCpdOFDk2,MmcgqAlsFt.sTZjaIcENd,MmcgqAlsFt.W5bBlPX8OGRw26oeT4Zctp,MmcgqAlsFt.PiR735OmVcFjpE0yeCoM4 = NNA8aswIZfdr2([QvgnCALNstmuUJiET(u"ࠧࡄࡖࡈ࠽ࡉ࡙࠱࠺ࡘࡘ࠴࡛࡙ࡘࠨღ"),QvgnCALNstmuUJiET(u"ࠨ࡙ࡖ࡙ࡗࡌࡔ࠲࠻ࡔࡘࡊࡌ࡚࡙ࠩყ"),SqrG5mU3j96ldsFpExobw40TJY(u"ࠩࡅࡘࡊࡾࡐࡗ࠳࠼࡙ࡗ࡜ࡎࡖࡕࡘ࠹ࡍ࡞ࠧშ"),CnbBKmtF1x84q7AW(u"ࠪࡓ࡙࠷࠹ࡋࡗ࠳ࡼࡇ࡚ࡕ࡭ࡆ࡛ࠫჩ")])
		CfKNTtIi3OABbWcPpdF(fEXMiAyG3ql4vKB)
	return
def WWTntIZ7hBCpPOdScNwrsX(JfH0yTDjbBchm6Aui7W,sfn63NJcqO7WZCQxtLHU):
	from socket import socket as jFL1meU3RWM78GPlJBNbQHdShuT,AF_INET as hSuRrpxJ1blOyYCDEmFGU,SOCK_STREAM as nwbQDs5xKHFLUk4jmtzZo
	gl6mxQDwOs8I5YW32bkXrGfzie = jFL1meU3RWM78GPlJBNbQHdShuT(hSuRrpxJ1blOyYCDEmFGU,nwbQDs5xKHFLUk4jmtzZo)
	gl6mxQDwOs8I5YW32bkXrGfzie.settimeout(bXukYxQ4aHw)
	OYxIojkiHrw1tzhlpg5,UwDzL9yIOxRHZ5M7CkPcXo4Ytp = VBlawK4mgHSyLEn8iqhUkz5,ybdv7XcT3lxF6QezULwCAGk
	pp9oFfEkKX74znPZ = HB5PvxRhwM.time()
	try: gl6mxQDwOs8I5YW32bkXrGfzie.connect((JfH0yTDjbBchm6Aui7W,sfn63NJcqO7WZCQxtLHU))
	except: OYxIojkiHrw1tzhlpg5 = fEXMiAyG3ql4vKB
	K4Y9XdDMSbx0ew8cWI = HB5PvxRhwM.time()
	if OYxIojkiHrw1tzhlpg5: UwDzL9yIOxRHZ5M7CkPcXo4Ytp = K4Y9XdDMSbx0ew8cWI-pp9oFfEkKX74znPZ
	return UwDzL9yIOxRHZ5M7CkPcXo4Ytp
def OwGHUMSI3WuYd9VtcC5ehnbFxv04Xi(showDialogs):
	if showDialogs:
		dHPVDWfG4jX5e6QEo0CKh = XVmKrby29eCGMnlEY6jz0HNOR(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧც"),EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ู่ࠬโࠢํๆํ๋ࠠศๆหี๋อๅอࠢส่ว์ࠠษวุ่ฬำ้ࠠฬ้฼๏็ࠠอ็ํ฽่่ࠥศ฻าࠤฬ๊ศ๋ษ้หฯ่ࠦศๆๆหูࠦวๅ็ึฮำีๅสࠢไ๎ࠥอไษำ้ห๊าࠠ࠯࠰๋้ࠣࠦสา์าࠤฯฺฺ๋ๆࠣ฽๊๊๊สࠢส่ฯ์ุ๋ใࠣห้ศๆࠡมࠤࠫძ"))
	else: dHPVDWfG4jX5e6QEo0CKh = VBlawK4mgHSyLEn8iqhUkz5
	if dHPVDWfG4jX5e6QEo0CKh==bXukYxQ4aHw:
		for o4oOCVEFpXHUwMKszi in WQvYkNg7SysPFLitlGEn6.listdir(vA0ImpguajeHKJ6P):
			if o4oOCVEFpXHUwMKszi.endswith(wwPrSDa21lUh(u"࠭࠮ࡥࡤࠪწ")) and dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠧࡥࡣࡷࡥࠬჭ") in o4oOCVEFpXHUwMKszi:
				mZbI1QrGfFn42UKRPNSpzx7w = WQvYkNg7SysPFLitlGEn6.path.join(vA0ImpguajeHKJ6P,o4oOCVEFpXHUwMKszi)
				WFYAlCyzGj1H32ovtQLnBTqhS6X,Z8gcWPFXkx7oSrR2D = ZX6AGYSgqrUBTw9I8WDNpuE2eCink4(mZbI1QrGfFn42UKRPNSpzx7w)
				Z8gcWPFXkx7oSrR2D.execute(KNIvHPjUbhr(u"ࠨࡒࡕࡅࡌࡓࡁࠡࡨࡲࡶࡪ࡯ࡧ࡯ࡡ࡮ࡩࡾࡹ࠽࡯ࡱ࠾ࠫხ"))
				Z8gcWPFXkx7oSrR2D.execute(sULh4NjakzI8He7xJCMGrql(u"ࠩࡓࡖࡆࡍࡍࡂࠢࡷࡩࡲࡶ࡟ࡴࡶࡲࡶࡪࡃࡍࡆࡏࡒࡖ࡞ࡁࠧჯ"))
				Z8gcWPFXkx7oSrR2D.execute(LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠪࡔࡗࡇࡇࡎࡃࠣ࡭ࡳࡺࡥࡨࡴ࡬ࡸࡾࡥࡣࡩࡧࡦ࡯ࡀ࠭ჰ"))
				Z8gcWPFXkx7oSrR2D.execute(HHoGx7Flus60(u"ࠫࡕࡘࡁࡈࡏࡄࠤࡴࡶࡴࡪ࡯࡬ࡾࡪࡁࠧჱ"))
				Z8gcWPFXkx7oSrR2D.execute(A6dMB1FlgxVivJ2fk9C(u"ࠬ࡜ࡁࡄࡗࡘࡑࡀ࠭ჲ"))
				WFYAlCyzGj1H32ovtQLnBTqhS6X.commit()
				WFYAlCyzGj1H32ovtQLnBTqhS6X.close()
		if showDialogs: BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩჳ"),o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠧห็อࠤอ์ฬศฯࠣ฽๊๊๊สࠢศู้ออ๊ࠡอ๊฽๐แࠡฮ่๎฾ࠦโ้ษ฼ำࠥอไษ์ส๊ฬะ้ࠠษ็็ฬฺࠠศๆ่ืฯิฯๆหࠣๅ๏ࠦวๅสิ๊ฬ๋ฬࠨჴ"))
	return
def PEgHa6TQ94mRGvDipcw5LsZfKzh(t3ZMV0ocNl,fRyELFcJnrUQv6izHGACD,showDialogs):
	if t3ZMV0ocNl!=None:
		global xaUyi1IZb4psmHdLP6
		xaUyi1IZb4psmHdLP6 = t3ZMV0ocNl
	if fRyELFcJnrUQv6izHGACD!=None:
		global vZf1CMiWboX9m
		vZf1CMiWboX9m = fRyELFcJnrUQv6izHGACD
	if showDialogs!=None:
		global GlE6YUzP4tDQhoiRTWFy37Cxb
		GlE6YUzP4tDQhoiRTWFy37Cxb = showDialogs
	return
def i57i4UNx0azqpSTQoKAy(fjUoJylTVWh0,S6NALBOqGn1zi2W5M8y7,data,headers,allow_redirects,showDialogs,dUWFtBQ3cpoIZ9,vlwhfTp01Md4P5kR3rAD62oSBUbLu7,GDP8fawQRqBtUrcA9x4uLCZTMNF6):
	if showDialogs==hWGMqtBy4wuLaVcj: kSwGWZQN6LiFHUg0nxCutl8KO = VBlawK4mgHSyLEn8iqhUkz5 if GlE6YUzP4tDQhoiRTWFy37Cxb==hWGMqtBy4wuLaVcj else GlE6YUzP4tDQhoiRTWFy37Cxb
	else: kSwGWZQN6LiFHUg0nxCutl8KO = VBlawK4mgHSyLEn8iqhUkz5 if showDialogs else fEXMiAyG3ql4vKB
	if GDP8fawQRqBtUrcA9x4uLCZTMNF6==hWGMqtBy4wuLaVcj: tBryl9dVaNzsMDCjqxJLIhS8 = VBlawK4mgHSyLEn8iqhUkz5 if vZf1CMiWboX9m==hWGMqtBy4wuLaVcj else vZf1CMiWboX9m
	else: tBryl9dVaNzsMDCjqxJLIhS8 = VBlawK4mgHSyLEn8iqhUkz5 if GDP8fawQRqBtUrcA9x4uLCZTMNF6 else fEXMiAyG3ql4vKB
	if vlwhfTp01Md4P5kR3rAD62oSBUbLu7==hWGMqtBy4wuLaVcj: bbzHK1VSDwLh = VBlawK4mgHSyLEn8iqhUkz5 if xaUyi1IZb4psmHdLP6==hWGMqtBy4wuLaVcj else xaUyi1IZb4psmHdLP6
	else: bbzHK1VSDwLh = VBlawK4mgHSyLEn8iqhUkz5 if vlwhfTp01Md4P5kR3rAD62oSBUbLu7 else fEXMiAyG3ql4vKB
	if allow_redirects==hWGMqtBy4wuLaVcj: smXRo1cSGQl = VBlawK4mgHSyLEn8iqhUkz5
	else: smXRo1cSGQl = VBlawK4mgHSyLEn8iqhUkz5 if allow_redirects else fEXMiAyG3ql4vKB
	PwvNmnqXKrYVZugB5c8 = {} if headers==hWGMqtBy4wuLaVcj else headers
	OucJVrWRKSqDChiG7yn3oz0dafZF = {} if data==hWGMqtBy4wuLaVcj else data
	if dUWFtBQ3cpoIZ9==KBkxSYaz93pu1(u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕ࠰ࡍࡓ࡙ࡔࡂࡎࡏࡣࡔࡒࡄࡠࡔࡈࡐࡊࡇࡓࡆ࠯࠴ࡷࡹ࠭ჵ"): PwvNmnqXKrYVZugB5c8 = {}
	else:
		oe9gr4KGBbDdAO3TqnaQ1PS0JCIu = list(PwvNmnqXKrYVZugB5c8.keys())
		if FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪჶ") not in oe9gr4KGBbDdAO3TqnaQ1PS0JCIu: PwvNmnqXKrYVZugB5c8[mkHKSQvjWr5BTcM3wVY(u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫჷ")] = wwPrSDa21lUh(u"ࠫ࡭ࡺࡴࡱࠩჸ")
		if CnbBKmtF1x84q7AW(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩჹ") not in oe9gr4KGBbDdAO3TqnaQ1PS0JCIu: PwvNmnqXKrYVZugB5c8[JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪჺ")] = OB6QYAMUnPiWXgpkTrItV48FqZSjdR(VBlawK4mgHSyLEn8iqhUkz5)
	return fjUoJylTVWh0,S6NALBOqGn1zi2W5M8y7,OucJVrWRKSqDChiG7yn3oz0dafZF,PwvNmnqXKrYVZugB5c8,smXRo1cSGQl,kSwGWZQN6LiFHUg0nxCutl8KO,dUWFtBQ3cpoIZ9,bbzHK1VSDwLh,tBryl9dVaNzsMDCjqxJLIhS8
def HaZx1JTW4ELwv(fjUoJylTVWh0,S6NALBOqGn1zi2W5M8y7,F49URk16JIawgp7YWZAXGtnMb,UBRzLM6ZdkWOKwy0qPfFIlC,SSKgaJNQBPwlZY,showDialogs,dUWFtBQ3cpoIZ9,vlwhfTp01Md4P5kR3rAD62oSBUbLu7=hWGMqtBy4wuLaVcj,GDP8fawQRqBtUrcA9x4uLCZTMNF6=hWGMqtBy4wuLaVcj):
	aNSb8AQWjni1vdus = i57i4UNx0azqpSTQoKAy(fjUoJylTVWh0,S6NALBOqGn1zi2W5M8y7,F49URk16JIawgp7YWZAXGtnMb,UBRzLM6ZdkWOKwy0qPfFIlC,SSKgaJNQBPwlZY,showDialogs,dUWFtBQ3cpoIZ9,vlwhfTp01Md4P5kR3rAD62oSBUbLu7,GDP8fawQRqBtUrcA9x4uLCZTMNF6)
	fjUoJylTVWh0,S6NALBOqGn1zi2W5M8y7,OucJVrWRKSqDChiG7yn3oz0dafZF,PwvNmnqXKrYVZugB5c8,smXRo1cSGQl,kSwGWZQN6LiFHUg0nxCutl8KO,dUWFtBQ3cpoIZ9,bbzHK1VSDwLh,tBryl9dVaNzsMDCjqxJLIhS8 = aNSb8AQWjni1vdus
	NPM3HKQ57xe,pRxdZFXemjq4,OXdrUl5wZ0uKQMS9zpeI3V2Hj,nnmdQ4OqbiAoYDsPHMv = e91ATlnmKdpq(S6NALBOqGn1zi2W5M8y7)
	T5EshFWwM3J7zH = ee8c0jzrTntGSUdRJm.getSetting(mkHKSQvjWr5BTcM3wVY(u"ࠧࡢࡸ࠱ࡨࡳࡹࠧ჻"))
	iN41e5cDBwxtX9OhmYUvPJdfLb = ee8c0jzrTntGSUdRJm.getSetting(zyvJMtBhrw(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡺࡹࡥࡥࡰࡶࠫჼ"))
	QbqvPf5AKC9wS6goxtZFs21H = ee8c0jzrTntGSUdRJm.getSetting(e2qDYgipPmTw4KvBLnochr(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡲࡵࡳࡽࡿࠧჽ"))
	IMiTf0WrHAUCbvojaRFQu7l = [GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠪࡷࡨࡸࡡࡱࡧࡲࡴࡸ࠭ჾ"),OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠫࡸࡩࡲࡢࡲࡨࡶࡦࡶࡩࠨჿ"),S1SgCFYGJeMvfp5iZXK(u"ࠬࡹࡣࡳࡣࡳ࡭ࡳ࡭ࡡ࡯ࡶࠪᄀ"),o1u5dij9UrcbXzVS8lwIWfKpnqM(u"࠭ࡳࡤࡴࡤࡴ࡮ࡴࡧࡳࡱࡥࡳࡹ࠭ᄁ"),OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠧࡴࡥࡵࡥࡵ࡫ࡵࡱࠩᄂ"),EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠨࡵࡦࡶࡦࡶࡥ࠯ࡦࡲࠫᄃ")]
	PK3bO4TX9BzNHlFx6 = VBlawK4mgHSyLEn8iqhUkz5 if any(BoSjXKxz41DcneO9UimClE in S6NALBOqGn1zi2W5M8y7 for BoSjXKxz41DcneO9UimClE in IMiTf0WrHAUCbvojaRFQu7l) else fEXMiAyG3ql4vKB
	if sULh4NjakzI8He7xJCMGrql(u"ࠩࠩࡹࡷࡲ࠽ࠨᄄ") in NPM3HKQ57xe and PK3bO4TX9BzNHlFx6: kkoKaprUtZ5WbSwTGmuHxYi = NPM3HKQ57xe.rsplit(dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠪࠪࡺࡸ࡬࠾ࠩᄅ"),KNIvHPjUbhr(u"࠴ᒅ"))[bXukYxQ4aHw]
	else: kkoKaprUtZ5WbSwTGmuHxYi = hWGMqtBy4wuLaVcj
	XcpHDZFn41juVYQKfwzraJ = u6rbxnyjTl7I[jeAby54c02TgG8zuivonX91(u"ࠫࡕ࡟ࡔࡉࡑࡑࠫᄆ")]
	rrs3DdwiVEgokIUvBt8cnNQFM2 = NPM3HKQ57xe in XcpHDZFn41juVYQKfwzraJ or kkoKaprUtZ5WbSwTGmuHxYi in XcpHDZFn41juVYQKfwzraJ
	n7nmbY40QRGoPErUvuLaZh = u6rbxnyjTl7I[QvgnCALNstmuUJiET(u"ࠬࡘࡅࡑࡑࡖࠫᄇ")]
	qo2Pcr0a7zU3XLjty45nw9B1 = NPM3HKQ57xe in n7nmbY40QRGoPErUvuLaZh or kkoKaprUtZ5WbSwTGmuHxYi in n7nmbY40QRGoPErUvuLaZh
	KnvcL4uQhH9sE38DwGle27jN = rrs3DdwiVEgokIUvBt8cnNQFM2 or qo2Pcr0a7zU3XLjty45nw9B1
	KqXZy2ej5v7kga3npNIVJ8CL9 = fEXMiAyG3ql4vKB
	RXrBJglna8u9F = VBlawK4mgHSyLEn8iqhUkz5
	MMGXncWHz9IVkwm31 = pRxdZFXemjq4==None and OXdrUl5wZ0uKQMS9zpeI3V2Hj==None and not PK3bO4TX9BzNHlFx6
	if MMGXncWHz9IVkwm31 and KnvcL4uQhH9sE38DwGle27jN:
		if rrs3DdwiVEgokIUvBt8cnNQFM2:
			rh3W5wMIHBt7paQRNTjAXmzKn = XcpHDZFn41juVYQKfwzraJ.index(NPM3HKQ57xe)
			N3jOweRKUsLJCzFA0kcDhr5a1mg = u6rbxnyjTl7I[GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"࠭ࡐ࡚ࡖࡋࡓࡓࡥࡂࡌࡒࠪᄈ")][rh3W5wMIHBt7paQRNTjAXmzKn]
			QSTd4nDuCG3zq5YRKgL9 = JaefAXmLzMRSjqVhTi0rQPb17IB8U[rh3W5wMIHBt7paQRNTjAXmzKn]
			if QSTd4nDuCG3zq5YRKgL9==XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠧࡍࡋࡖࡘࡕࡒࡁ࡚ࠩᄉ"): bbzHK1VSDwLh,tBryl9dVaNzsMDCjqxJLIhS8,RXrBJglna8u9F = fEXMiAyG3ql4vKB,fEXMiAyG3ql4vKB,fEXMiAyG3ql4vKB
			elif QSTd4nDuCG3zq5YRKgL9==hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠨࡅࡄࡔ࡙ࡉࡈࡂࠩᄊ"): KqXZy2ej5v7kga3npNIVJ8CL9 = VBlawK4mgHSyLEn8iqhUkz5
		elif qo2Pcr0a7zU3XLjty45nw9B1:
			rh3W5wMIHBt7paQRNTjAXmzKn = n7nmbY40QRGoPErUvuLaZh.index(NPM3HKQ57xe)
			N3jOweRKUsLJCzFA0kcDhr5a1mg = u6rbxnyjTl7I[MMizeNH0AKu(u"ࠩࡕࡉࡕࡕࡓࡠࡄࡎࡔࠬᄋ")][rh3W5wMIHBt7paQRNTjAXmzKn]
			QSTd4nDuCG3zq5YRKgL9 = wb7ZkKqsRIfjgNdBtu3T8HvCiX[rh3W5wMIHBt7paQRNTjAXmzKn]
	if OXdrUl5wZ0uKQMS9zpeI3V2Hj==hWGMqtBy4wuLaVcj: OXdrUl5wZ0uKQMS9zpeI3V2Hj = T5EshFWwM3J7zH
	elif OXdrUl5wZ0uKQMS9zpeI3V2Hj==None and iN41e5cDBwxtX9OhmYUvPJdfLb in [QvgnCALNstmuUJiET(u"ࠪࡅ࡚࡚ࡏࠨᄌ"),o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠫࡆࡉࡃࡆࡒࡗࡉࡉ࠭ᄍ")] and bbzHK1VSDwLh: OXdrUl5wZ0uKQMS9zpeI3V2Hj = T5EshFWwM3J7zH
	if rrs3DdwiVEgokIUvBt8cnNQFM2 or qo2Pcr0a7zU3XLjty45nw9B1: CCiHoyQdYazj = xcChIL13BpR8WArNt9Pl0So(u"࠵࠺ᒆ")
	elif PK3bO4TX9BzNHlFx6: CCiHoyQdYazj = o1u5dij9UrcbXzVS8lwIWfKpnqM(u"࠻࠶ᒇ")
	elif dUWFtBQ3cpoIZ9 in IYkLXVOJe2: CCiHoyQdYazj = sULh4NjakzI8He7xJCMGrql(u"࠷࠰ᒈ")
	elif dUWFtBQ3cpoIZ9==rwQN9AKhLCuMfHxjlbX0U(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡒࡆࡘࡈࡖࡘࡕ࡟ࡕࡔࡄࡒࡘࡒࡁࡕࡇ࠰࠵ࡸࡺࠧᄎ"): CCiHoyQdYazj = XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"࠲࠱ᒉ")
	elif dUWFtBQ3cpoIZ9==wwPrSDa21lUh(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡑࡒࡋࡑࡋ࡟ࡕࡔࡄࡒࡘࡒࡁࡕࡇ࠰࠵ࡸࡺࠧᄏ"): CCiHoyQdYazj = OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"࠳࠲ᒊ")
	elif OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡐ࡝ࡁࡎࠩᄐ") in dUWFtBQ3cpoIZ9: CCiHoyQdYazj = S1SgCFYGJeMvfp5iZXK(u"࠹࠳ᒋ")
	elif QvgnCALNstmuUJiET(u"ࠨࡕࡋࡓࡋࡎࡁࠨᄑ") in dUWFtBQ3cpoIZ9: CCiHoyQdYazj = ITvnUAMXsyb4eO(u"࠺࠹ᒌ")
	elif QvgnCALNstmuUJiET(u"ࠩࡆࡍࡒࡇ࠴ࡖࠩᄒ") in dUWFtBQ3cpoIZ9: CCiHoyQdYazj = hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"࠶࠺ᒍ")
	elif LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠪࡅࡍ࡝ࡁࡌࠩᄓ") in dUWFtBQ3cpoIZ9: CCiHoyQdYazj = GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"࠷࠶ᒎ")
	elif EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠫࡈࡏࡍࡂࡎࡌࡋࡍ࡚ࠧᄔ") in dUWFtBQ3cpoIZ9: CCiHoyQdYazj = DJ1ICpbyR2(u"࠸࠰ᒏ")
	elif SqrG5mU3j96ldsFpExobw40TJY(u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡈࡗࡐࡔࡎࠫᄕ") in dUWFtBQ3cpoIZ9: CCiHoyQdYazj = wwPrSDa21lUh(u"࠳࠱ᒐ")
	elif S1SgCFYGJeMvfp5iZXK(u"࠭ࡁࡌࡑࡄࡑࠬᄖ") in dUWFtBQ3cpoIZ9: CCiHoyQdYazj = QVDJLRlxNg127jMX(u"࠳࠷ᒑ")
	elif KBkxSYaz93pu1(u"ࠧࡂࡍ࡚ࡅࡒ࠭ᄗ") in dUWFtBQ3cpoIZ9: CCiHoyQdYazj = sULh4NjakzI8He7xJCMGrql(u"࠵࠳ᒒ")
	elif SqrG5mU3j96ldsFpExobw40TJY(u"ࠨࡈࡄࡗࡊࡒࡈࡅ࠳ࠪᄘ") in dUWFtBQ3cpoIZ9: CCiHoyQdYazj = zyvJMtBhrw(u"࠵࠴ᒓ")
	elif A6dMB1FlgxVivJ2fk9C(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠶ࠫᄙ") in dUWFtBQ3cpoIZ9: CCiHoyQdYazj = LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"࠺࠵ᒔ")
	elif LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠪࡌࡆࡒࡁࡄࡋࡐࡅࠬᄚ") in dUWFtBQ3cpoIZ9: CCiHoyQdYazj = e2qDYgipPmTw4KvBLnochr(u"࠹࠶ᒕ")
	else: CCiHoyQdYazj = NeO3CTLHrPfWUoIgy8Q(u"࠷࠵ᒖ")
	qQLwef7NmT53cld4RkWOVsHiME6guB = (pRxdZFXemjq4!=None)
	FZulnb9NXxoL = (OXdrUl5wZ0uKQMS9zpeI3V2Hj!=None and iN41e5cDBwxtX9OhmYUvPJdfLb!=gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠫࡘ࡚ࡏࡑࠩᄛ"))
	if qQLwef7NmT53cld4RkWOVsHiME6guB and not PK3bO4TX9BzNHlFx6: OnsAxhdVjZF(zyvJMtBhrw(u"ࠬะแฺ์็ࠤอื่ไีํࠤึ่ๅࠨᄜ"),pRxdZFXemjq4)
	elif FZulnb9NXxoL: OnsAxhdVjZF(KBkxSYaz93pu1(u"࠭สโ฻ํ่ࠥࡊࡎࡔࠢิๆ๊࠭ᄝ"),OXdrUl5wZ0uKQMS9zpeI3V2Hj)
	if qQLwef7NmT53cld4RkWOVsHiME6guB:
		nBpgxhSva72EUHjWGPzqmlYiA05X = {HHoGx7Flus60(u"ࠢࡩࡶࡷࡴࠧᄞ"):pRxdZFXemjq4,EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠣࡪࡷࡸࡵࡹࠢᄟ"):pRxdZFXemjq4}
		QlrPbhoXCyYOV9Dx1d0RMpwIj = pRxdZFXemjq4
	else: nBpgxhSva72EUHjWGPzqmlYiA05X,QlrPbhoXCyYOV9Dx1d0RMpwIj = {},hWGMqtBy4wuLaVcj
	if FZulnb9NXxoL:
		import urllib3.util.connection as UKYogA6VRcOx3NEw5syl
		jP6CGFa9p0Rv3 = LplGeCtbFnTMXvJhu(UKYogA6VRcOx3NEw5syl,T5EshFWwM3J7zH)
	fgcmaIqwxBWL4nP,s93uy4YSpalAxZ2rQ,NNpHEqnPvMRSwdfo1ylIC4Xc,QuJw0tzPI6fZeXc7LDvEY32TSHR,bUyO2BLuqrG7x,verify = smXRo1cSGQl,dUWFtBQ3cpoIZ9,fjUoJylTVWh0,fEXMiAyG3ql4vKB,fEXMiAyG3ql4vKB,nnmdQ4OqbiAoYDsPHMv
	if KqXZy2ej5v7kga3npNIVJ8CL9: bUyO2BLuqrG7x = VBlawK4mgHSyLEn8iqhUkz5
	if KnvcL4uQhH9sE38DwGle27jN or smXRo1cSGQl: fgcmaIqwxBWL4nP = fEXMiAyG3ql4vKB
	if rrs3DdwiVEgokIUvBt8cnNQFM2: NNpHEqnPvMRSwdfo1ylIC4Xc = JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠩࡓࡓࡘ࡚ࠧᄠ")
	kw6Zs29tznG0CFIUWxOh7qeH,jZyzn8MtORbaeCW = -bXukYxQ4aHw,wwPrSDa21lUh(u"࡙ࠪࡳࡱ࡮ࡰࡹࡱࠤࡊࡸࡲࡰࡴࠪᄡ")
	gzYnhfT2LyAOXkuPQxi4NVdw1m = fEXMiAyG3ql4vKB
	global tcQ5U3FBMOY2iXue7z
	if not tcQ5U3FBMOY2iXue7z: tcQ5U3FBMOY2iXue7z = Mqk51CFBym0pIQXZLsOxSJ(MM5Dx39f7ULhcJsRptzIowP,e2qDYgipPmTw4KvBLnochr(u"ࠫࡩ࡯ࡣࡵࠩᄢ"),mkHKSQvjWr5BTcM3wVY(u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࠨᄣ"),xcChIL13BpR8WArNt9Pl0So(u"࠭ࡆࡐࡔ࡚ࡅࡗࡊࡓࠨᄤ"))
	llVUr3jpSG = []
	while NPM3HKQ57xe not in llVUr3jpSG and NPM3HKQ57xe in list(tcQ5U3FBMOY2iXue7z.keys()):
		llVUr3jpSG.append(NPM3HKQ57xe)
		NPM3HKQ57xe = tcQ5U3FBMOY2iXue7z[NPM3HKQ57xe]
	import requests as Av8o1XdSJCsG9fHlbEwr7P
	for JpzD0lv9cYM6XrHeqCa in range(FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"࠹ᒗ")):
		IE21Hn3VMpqB = VBlawK4mgHSyLEn8iqhUkz5
		G62uf8ZSIzBE = fEXMiAyG3ql4vKB
		try:
			if JpzD0lv9cYM6XrHeqCa: s93uy4YSpalAxZ2rQ = sULh4NjakzI8He7xJCMGrql(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡑࡓࡉࡓ࡛ࡒࡍࡡࡕࡉࡖ࡛ࡅࡔࡖࡖ࠱࠶ࡹࡴࠨᄥ")
			if PK3bO4TX9BzNHlFx6 or not qQLwef7NmT53cld4RkWOVsHiME6guB: Dv0PbigXyWH4MUCSpE(mkHKSQvjWr5BTcM3wVY(u"ࠨࡔࡈࡕ࡚ࡋࡓࡕࡕ࡟ࡸࡔࡖࡅࡏࡡࡘࡖࡑ࠭ᄦ"),NPM3HKQ57xe,OucJVrWRKSqDChiG7yn3oz0dafZF,PwvNmnqXKrYVZugB5c8,s93uy4YSpalAxZ2rQ,NNpHEqnPvMRSwdfo1ylIC4Xc)
			try: BUXsmKe5dGpJj09REb6HqcO7tNv.close()
			except: pass
			CMzQFXeI08KDwAJ9p = NPM3HKQ57xe
			BUXsmKe5dGpJj09REb6HqcO7tNv = Av8o1XdSJCsG9fHlbEwr7P.request(NNpHEqnPvMRSwdfo1ylIC4Xc,NPM3HKQ57xe,data=OucJVrWRKSqDChiG7yn3oz0dafZF,headers=PwvNmnqXKrYVZugB5c8,verify=verify,allow_redirects=fgcmaIqwxBWL4nP,timeout=CCiHoyQdYazj,proxies=nBpgxhSva72EUHjWGPzqmlYiA05X)
			if HHoGx7Flus60(u"࠴࠲࠳ᒘ")<=BUXsmKe5dGpJj09REb6HqcO7tNv.status_code<=FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"࠵࠼࠽ᒙ"):
				if not QuJw0tzPI6fZeXc7LDvEY32TSHR:
					LsqOACPV2Xi9YaQf8zhFl = list(BUXsmKe5dGpJj09REb6HqcO7tNv.headers.keys())
					if KBkxSYaz93pu1(u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫᄧ") in LsqOACPV2Xi9YaQf8zhFl: NPM3HKQ57xe = BUXsmKe5dGpJj09REb6HqcO7tNv.headers[S1SgCFYGJeMvfp5iZXK(u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬᄨ")]
					elif xcChIL13BpR8WArNt9Pl0So(u"ࠫࡱࡵࡣࡢࡶ࡬ࡳࡳ࠭ᄩ") in LsqOACPV2Xi9YaQf8zhFl: NPM3HKQ57xe = BUXsmKe5dGpJj09REb6HqcO7tNv.headers[sULh4NjakzI8He7xJCMGrql(u"ࠬࡲ࡯ࡤࡣࡷ࡭ࡴࡴࠧᄪ")]
					else: QuJw0tzPI6fZeXc7LDvEY32TSHR = VBlawK4mgHSyLEn8iqhUkz5
					if not QuJw0tzPI6fZeXc7LDvEY32TSHR: NPM3HKQ57xe = NPM3HKQ57xe.encode(dv0trJR7PwmKyxDYO52VLau8gEph(u"࠭࡬ࡢࡶ࡬ࡲ࠲࠷ࠧᄫ"),HHoGx7Flus60(u"ࠧࡪࡩࡱࡳࡷ࡫ࠧᄬ")).decode(a7VXeDU82IfQEnPZAdiT,GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠨ࡫ࡪࡲࡴࡸࡥࠨᄭ"))
					if KnvcL4uQhH9sE38DwGle27jN and BUXsmKe5dGpJj09REb6HqcO7tNv.status_code==EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"࠶࠴࠼ᒚ"):
						fgcmaIqwxBWL4nP = smXRo1cSGQl
						NNpHEqnPvMRSwdfo1ylIC4Xc = fjUoJylTVWh0
						QuJw0tzPI6fZeXc7LDvEY32TSHR = VBlawK4mgHSyLEn8iqhUkz5
						C9C3GQst6lp2n
				if not QuJw0tzPI6fZeXc7LDvEY32TSHR or smXRo1cSGQl:
					if wwPrSDa21lUh(u"ࠩ࡫ࡸࡹࡶࠧᄮ") not in NPM3HKQ57xe:
						BHCP2amVTOfy75 = RRNODILCtGzvgpx(CMzQFXeI08KDwAJ9p,rwQN9AKhLCuMfHxjlbX0U(u"ࠪࡹࡷࡲࠧᄯ"))
						NPM3HKQ57xe = BHCP2amVTOfy75+A6dMB1FlgxVivJ2fk9C(u"ࠫ࠴࠭ᄰ")+NPM3HKQ57xe.lstrip(OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠬ࠵ࠧᄱ"))
				if NPM3HKQ57xe!=CMzQFXeI08KDwAJ9p:
					tcQ5U3FBMOY2iXue7z[CMzQFXeI08KDwAJ9p] = NPM3HKQ57xe
					gzYnhfT2LyAOXkuPQxi4NVdw1m = VBlawK4mgHSyLEn8iqhUkz5
				if not QuJw0tzPI6fZeXc7LDvEY32TSHR and smXRo1cSGQl and not UGBbEtrcu5jLC6Sxoa3gFyP1mJOpW(NPM3HKQ57xe): C9C3GQst6lp2n
			elif EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"࠺࠻࠰ᒜ")<=BUXsmKe5dGpJj09REb6HqcO7tNv.status_code<=QVDJLRlxNg127jMX(u"࠹࠾࠿ᒛ"):
				BUXsmKe5dGpJj09REb6HqcO7tNv.reason = BUXsmKe5dGpJj09REb6HqcO7tNv.content
				bUyO2BLuqrG7x = VBlawK4mgHSyLEn8iqhUkz5
			CMzQFXeI08KDwAJ9p = BUXsmKe5dGpJj09REb6HqcO7tNv.url
			kw6Zs29tznG0CFIUWxOh7qeH = BUXsmKe5dGpJj09REb6HqcO7tNv.status_code
			jZyzn8MtORbaeCW = BUXsmKe5dGpJj09REb6HqcO7tNv.reason
			BUXsmKe5dGpJj09REb6HqcO7tNv.raise_for_status()
			G62uf8ZSIzBE = VBlawK4mgHSyLEn8iqhUkz5
		except Av8o1XdSJCsG9fHlbEwr7P.exceptions.HTTPError as HUpcs4WLhwzqV:
			pass
		except Av8o1XdSJCsG9fHlbEwr7P.exceptions.Timeout as HUpcs4WLhwzqV:
			if VKiGj1LundAJQwEXcqgxC: jZyzn8MtORbaeCW = str(HUpcs4WLhwzqV.message).split(ITvnUAMXsyb4eO(u"࠭࠺ࠡࠩᄲ"))[bXukYxQ4aHw]
			else: jZyzn8MtORbaeCW = str(HUpcs4WLhwzqV).split(A6dMB1FlgxVivJ2fk9C(u"ࠧ࠻ࠢࠪᄳ"))[bXukYxQ4aHw]
		except Av8o1XdSJCsG9fHlbEwr7P.exceptions.ConnectionError as HUpcs4WLhwzqV:
			try: nKh8r540GQBVPTokjZ2 = HUpcs4WLhwzqV.message[ybdv7XcT3lxF6QezULwCAGk]
			except: nKh8r540GQBVPTokjZ2 = str(HUpcs4WLhwzqV)
			ji7MgxA1eHnpOzI3tuGUvPCW = trdVA0JvFaD.findall(ITvnUAMXsyb4eO(u"ࠣ࡞࡞ࡉࡷࡸ࡮ࡰࠢࠫࡠࡩ࠱ࠩ࡝࡟ࠣࠬ࠳࠰࠿ࠪࠩࠥᄴ"),nKh8r540GQBVPTokjZ2)
			if not ji7MgxA1eHnpOzI3tuGUvPCW: ji7MgxA1eHnpOzI3tuGUvPCW = trdVA0JvFaD.findall(ITvnUAMXsyb4eO(u"ࠤ࠯ࠤࡪࡸࡲࡰࡴ࡟ࠬ࠭ࡢࡤࠬࠫ࠯ࠤࠬ࠮࠮ࠫࡁࠬࠫࠧᄵ"),nKh8r540GQBVPTokjZ2)
			if not ji7MgxA1eHnpOzI3tuGUvPCW:
				RbrDyLx5lkvUA2sn9woGJ = trdVA0JvFaD.findall(zyvJMtBhrw(u"ࠥ࠾ࠥ࠮࠮ࠫࡁࠬ࠾࠳࠰࠿ࠩ࡞ࡧ࠯࠮ࡀࠢᄶ"),nKh8r540GQBVPTokjZ2)
				if RbrDyLx5lkvUA2sn9woGJ: ji7MgxA1eHnpOzI3tuGUvPCW = [RbrDyLx5lkvUA2sn9woGJ[ybdv7XcT3lxF6QezULwCAGk][bXukYxQ4aHw],RbrDyLx5lkvUA2sn9woGJ[ybdv7XcT3lxF6QezULwCAGk][ybdv7XcT3lxF6QezULwCAGk]]
			if not ji7MgxA1eHnpOzI3tuGUvPCW: ji7MgxA1eHnpOzI3tuGUvPCW = trdVA0JvFaD.findall(jeAby54c02TgG8zuivonX91(u"ࠦ࠿࠮࡜ࡥ࠭ࠬ࠾ࠥ࠮࠮ࠫࡁࠬࠫࠧᄷ"),nKh8r540GQBVPTokjZ2)
			if not ji7MgxA1eHnpOzI3tuGUvPCW: ji7MgxA1eHnpOzI3tuGUvPCW = trdVA0JvFaD.findall(CnbBKmtF1x84q7AW(u"ࠧࠦࠨ࡝ࡦ࠮࠭ࡢࠦࠨ࠯ࠬࡂ࠭ࠬࠨᄸ"),nKh8r540GQBVPTokjZ2)
			try: kw6Zs29tznG0CFIUWxOh7qeH,jZyzn8MtORbaeCW = ji7MgxA1eHnpOzI3tuGUvPCW[ybdv7XcT3lxF6QezULwCAGk]
			except: kw6Zs29tznG0CFIUWxOh7qeH,jZyzn8MtORbaeCW = -jeAby54c02TgG8zuivonX91(u"࠸ᒝ"),nKh8r540GQBVPTokjZ2
		except Av8o1XdSJCsG9fHlbEwr7P.exceptions.RequestException as HUpcs4WLhwzqV:
			if VKiGj1LundAJQwEXcqgxC: jZyzn8MtORbaeCW = HUpcs4WLhwzqV.message
			else: jZyzn8MtORbaeCW = str(HUpcs4WLhwzqV)
		except:
			IE21Hn3VMpqB = fEXMiAyG3ql4vKB
			try: kw6Zs29tznG0CFIUWxOh7qeH = BUXsmKe5dGpJj09REb6HqcO7tNv.status_code
			except: pass
			try: jZyzn8MtORbaeCW = BUXsmKe5dGpJj09REb6HqcO7tNv.reason
			except: pass
		jZyzn8MtORbaeCW = str(jZyzn8MtORbaeCW)
		KteLZCbM8W0FqE2OBx1(pGYKHZgqFX3B,rwQN9AKhLCuMfHxjlbX0U(u"࠭ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔ࡞ࡷࡖࡊ࡙ࡐࡐࡐࡖࡉࠥࠦࡃࡰࡦࡨ࠾ࠥࡡࠠࠨᄹ")+str(kw6Zs29tznG0CFIUWxOh7qeH)+xcChIL13BpR8WArNt9Pl0So(u"ࠧࠡ࡟ࠣࠤࠥࡘࡥࡢࡵࡲࡲ࠿࡛ࠦࠡࠩᄺ")+jZyzn8MtORbaeCW+wwPrSDa21lUh(u"ࠨࠢࡠࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪᄻ")+dUWFtBQ3cpoIZ9+S1SgCFYGJeMvfp5iZXK(u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨᄼ")+S6NALBOqGn1zi2W5M8y7+dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠪࠤࡢ࠭ᄽ"))
		if MMGXncWHz9IVkwm31 and KnvcL4uQhH9sE38DwGle27jN and IE21Hn3VMpqB and not bUyO2BLuqrG7x and kw6Zs29tznG0CFIUWxOh7qeH!=mkHKSQvjWr5BTcM3wVY(u"࠲࠱࠲ᒞ"):
			NPM3HKQ57xe = N3jOweRKUsLJCzFA0kcDhr5a1mg
			bUyO2BLuqrG7x = VBlawK4mgHSyLEn8iqhUkz5
			continue
		if IE21Hn3VMpqB: break
	if not G62uf8ZSIzBE and llVUr3jpSG:
		for url in llVUr3jpSG: del tcQ5U3FBMOY2iXue7z[url]
		gzYnhfT2LyAOXkuPQxi4NVdw1m = VBlawK4mgHSyLEn8iqhUkz5
	if gzYnhfT2LyAOXkuPQxi4NVdw1m:
		BxuD7iQRpW1(MM5Dx39f7ULhcJsRptzIowP,LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧᄾ"),xcChIL13BpR8WArNt9Pl0So(u"ࠬࡌࡏࡓ࡙ࡄࡖࡉ࡙ࠧᄿ"),tcQ5U3FBMOY2iXue7z,DpQifS0oKBI1hYcO)
		tcQ5U3FBMOY2iXue7z = {}
	if OXdrUl5wZ0uKQMS9zpeI3V2Hj!=None and iN41e5cDBwxtX9OhmYUvPJdfLb!=HHoGx7Flus60(u"࠭ࡓࡕࡑࡓࠫᅀ"): UKYogA6VRcOx3NEw5syl.create_connection = jP6CGFa9p0Rv3
	if iN41e5cDBwxtX9OhmYUvPJdfLb==S1SgCFYGJeMvfp5iZXK(u"ࠧࡂࡎ࡚ࡅ࡞࡙ࠧᅁ") and bbzHK1VSDwLh: OXdrUl5wZ0uKQMS9zpeI3V2Hj = None
	if not G62uf8ZSIzBE and pRxdZFXemjq4==None and dUWFtBQ3cpoIZ9 not in IYkLXVOJe2:
		wF5zRoQekA9lxOYacnju13yUIDs = R7RLCd9kyl.format_exc()
		if wF5zRoQekA9lxOYacnju13yUIDs!=EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠨࡐࡲࡲࡪ࡚ࡹࡱࡧ࠽ࠤࡓࡵ࡮ࡦ࡞ࡱࠫᅂ"): zGjD5QAkd7SO9YPcZl.stderr.write(wF5zRoQekA9lxOYacnju13yUIDs)
	SkMF3ejVQcGAh92BI5Hyg = aRBhF1OdxM0ek5SwqG()
	if PK3bO4TX9BzNHlFx6: CMzQFXeI08KDwAJ9p = kkoKaprUtZ5WbSwTGmuHxYi
	if not CMzQFXeI08KDwAJ9p: CMzQFXeI08KDwAJ9p = NPM3HKQ57xe
	SkMF3ejVQcGAh92BI5Hyg.url = CMzQFXeI08KDwAJ9p
	SkMF3ejVQcGAh92BI5Hyg.scrape = PK3bO4TX9BzNHlFx6
	try: xxzF0d3Ey2jCba8n9ePkivDLYWTS = BUXsmKe5dGpJj09REb6HqcO7tNv.content
	except: xxzF0d3Ey2jCba8n9ePkivDLYWTS = hWGMqtBy4wuLaVcj
	try: duy23h0kTUCi6IGSJ = BUXsmKe5dGpJj09REb6HqcO7tNv.headers
	except: duy23h0kTUCi6IGSJ = {}
	try: AIWzsfZKe9yLSg8di5xqGlUFkO = BUXsmKe5dGpJj09REb6HqcO7tNv.cookies.get_dict()
	except: AIWzsfZKe9yLSg8di5xqGlUFkO = {}
	try: BUXsmKe5dGpJj09REb6HqcO7tNv.close()
	except: pass
	if H4qZ2hwilNJYTmCFEQyaSs98cPM0gR:
		try: xxzF0d3Ey2jCba8n9ePkivDLYWTS = xxzF0d3Ey2jCba8n9ePkivDLYWTS.decode(a7VXeDU82IfQEnPZAdiT)
		except: pass
	kw6Zs29tznG0CFIUWxOh7qeH = int(kw6Zs29tznG0CFIUWxOh7qeH)
	SkMF3ejVQcGAh92BI5Hyg.code = kw6Zs29tznG0CFIUWxOh7qeH
	SkMF3ejVQcGAh92BI5Hyg.reason = jZyzn8MtORbaeCW
	SkMF3ejVQcGAh92BI5Hyg.content = xxzF0d3Ey2jCba8n9ePkivDLYWTS
	SkMF3ejVQcGAh92BI5Hyg.headers = duy23h0kTUCi6IGSJ
	SkMF3ejVQcGAh92BI5Hyg.cookies = AIWzsfZKe9yLSg8di5xqGlUFkO
	SkMF3ejVQcGAh92BI5Hyg.succeeded = G62uf8ZSIzBE
	SkMF3ejVQcGAh92BI5Hyg.scrapernumber = hWGMqtBy4wuLaVcj
	SkMF3ejVQcGAh92BI5Hyg.scraperserver = hWGMqtBy4wuLaVcj
	SkMF3ejVQcGAh92BI5Hyg.scraperurl = hWGMqtBy4wuLaVcj
	if VKiGj1LundAJQwEXcqgxC or isinstance(SkMF3ejVQcGAh92BI5Hyg.content,str): Bfh0Xz2NC1oegxYq = SkMF3ejVQcGAh92BI5Hyg.content.lower()
	else: Bfh0Xz2NC1oegxYq = hWGMqtBy4wuLaVcj
	yKzGr3CeHAFtRwgOEkjPvmJBoYhc8 = (ITvnUAMXsyb4eO(u"ࠩࡦࡰࡴࡻࡤࡧ࡮ࡤࡶࡪ࠭ᅃ") in Bfh0Xz2NC1oegxYq or ITvnUAMXsyb4eO(u"ࠪ࡫ࡴࡵࡧ࡭ࡧࠪᅄ") in Bfh0Xz2NC1oegxYq) and Bfh0Xz2NC1oegxYq.count(SqrG5mU3j96ldsFpExobw40TJY(u"ࠫࡷ࡫ࡣࡢࡲࡷࡧ࡭ࡧࠧᅅ"))>SqrG5mU3j96ldsFpExobw40TJY(u"࠳ᒟ") and NeO3CTLHrPfWUoIgy8Q(u"ࠬࡌࡁࡔࡇࡏࡌࡉ࠷ࠧᅆ") not in dUWFtBQ3cpoIZ9 and MMizeNH0AKu(u"࠭ࡲࡦࡥࡤࡴࡹࡩࡨࡢ࠯ࡷࡳࡰ࡫࡮ࠨᅇ") not in Bfh0Xz2NC1oegxYq and not PK3bO4TX9BzNHlFx6
	if kw6Zs29tznG0CFIUWxOh7qeH==S1SgCFYGJeMvfp5iZXK(u"࠴࠳࠴ᒠ") and yKzGr3CeHAFtRwgOEkjPvmJBoYhc8: SkMF3ejVQcGAh92BI5Hyg.succeeded = fEXMiAyG3ql4vKB
	if SkMF3ejVQcGAh92BI5Hyg.succeeded and MMGXncWHz9IVkwm31 and KnvcL4uQhH9sE38DwGle27jN:
		fhobD4JvAis7ndHL = o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠧࡄࡃࡓࡘࡈࡎࡁࠨᅈ")+OucJVrWRKSqDChiG7yn3oz0dafZF[NeO3CTLHrPfWUoIgy8Q(u"ࠨ࡬ࡲࡦࠬᅉ")].upper().replace(A6dMB1FlgxVivJ2fk9C(u"ࠩࡊࡉ࡙࠭ᅊ"),hWGMqtBy4wuLaVcj) if KqXZy2ej5v7kga3npNIVJ8CL9 else QSTd4nDuCG3zq5YRKgL9
		stmA3SGjD6b(fhobD4JvAis7ndHL)
	if not SkMF3ejVQcGAh92BI5Hyg.succeeded and MMGXncWHz9IVkwm31:
		gm7AuXQ3dy1oF = (o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠪࡧࡱࡵࡵࡥࡨ࡯ࡥࡷ࡫ࠧᅋ") in Bfh0Xz2NC1oegxYq and wwPrSDa21lUh(u"ࠫࡷࡧࡹࠡ࡫ࡧ࠾ࠥ࠭ᅌ") in Bfh0Xz2NC1oegxYq)
		u7oCsNixna5mecbTqhrvBgMOdGRKk9 = (MMizeNH0AKu(u"ࠬ࠻ࠠࡴࡧࡦࠫᅍ") in Bfh0Xz2NC1oegxYq and XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"࠭ࡢࡳࡱࡺࡷࡪࡸࠧᅎ") in Bfh0Xz2NC1oegxYq)
		migIyvJFoD4OpAkNC = (kw6Zs29tznG0CFIUWxOh7qeH in [dv0trJR7PwmKyxDYO52VLau8gEph(u"࠷࠴࠸ᒡ")] and XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠧࡦࡴࡵࡳࡷࠦࡣࡰࡦࡨ࠾ࠥ࠷࠰࠳࠲ࠪᅏ") in Bfh0Xz2NC1oegxYq)
		QfdEB8cH2IOu5GWVixPqFtwrYXh = (zyvJMtBhrw(u"ࠨࡡࡦࡪࡤࡩࡨ࡭ࡡࠪᅐ") in Bfh0Xz2NC1oegxYq and SqrG5mU3j96ldsFpExobw40TJY(u"ࠩࡦ࡬ࡦࡲ࡬ࡦࡰࡪࡩ࠲࠭ᅑ") in Bfh0Xz2NC1oegxYq)
		if   yKzGr3CeHAFtRwgOEkjPvmJBoYhc8: jZyzn8MtORbaeCW = HHoGx7Flus60(u"ࠪࡆࡱࡵࡣ࡬ࡧࡧࠤࡧࡿࠠࡳࡧࡦࡥࡵࡺࡣࡩࡣࠪᅒ")
		elif gm7AuXQ3dy1oF: jZyzn8MtORbaeCW = NeO3CTLHrPfWUoIgy8Q(u"ࠫࡇࡲ࡯ࡤ࡭ࡨࡨࠥࡨࡹࠡࡥ࡯ࡳࡺࡪࡦ࡭ࡣࡵࡩࠬᅓ")
		elif u7oCsNixna5mecbTqhrvBgMOdGRKk9: jZyzn8MtORbaeCW = GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠬࡈ࡬ࡰࡥ࡮ࡩࡩࠦࡢࡺࠢ࠸ࠤࡸ࡫ࡣࡰࡰࡧࡷࠥࡨࡲࡰࡹࡶࡩࡷࠦࡣࡩࡧࡦ࡯ࠬᅔ")
		elif migIyvJFoD4OpAkNC: jZyzn8MtORbaeCW = wwPrSDa21lUh(u"࠭ࡂ࡭ࡱࡦ࡯ࡪࡪࠠࡣࡻࠣࡧࡱࡵࡵࡥࡨ࡯ࡥࡷ࡫ࠠࡢࡥࡦࡩࡸࡹࠠࡥࡧࡱ࡭ࡪࡪࠧᅕ")
		elif QfdEB8cH2IOu5GWVixPqFtwrYXh: jZyzn8MtORbaeCW = rwQN9AKhLCuMfHxjlbX0U(u"ࠧࡃ࡮ࡲࡧࡰ࡫ࡤࠡࡤࡼࠤࡨࡲ࡯ࡶࡦࡩࡰࡦࡸࡥࠡࡵࡨࡧࡺࡸࡩࡵࡻࠣࡧ࡭࡫ࡣ࡬ࠩᅖ")
		else: jZyzn8MtORbaeCW = str(jZyzn8MtORbaeCW)
		if dUWFtBQ3cpoIZ9 in oovCPgZVNS1xDtnUs: pass
		elif dUWFtBQ3cpoIZ9 in IYkLXVOJe2:
			KteLZCbM8W0FqE2OBx1(VRQE4jsXHSfhPWo5DgLwxGk,qhVEWvetzXLOcr1(xjPuFK3EsIZSiobQ5X)+KBkxSYaz93pu1(u"ࠨࠢࠣࡈ࡮ࡸࡥࡤࡶࠣࡧࡴࡴ࡮ࡦࡥࡷ࡭ࡴࡴࠠࡧࡣ࡬ࡰࡪࡪࠠࠡࠢࡆࡳࡩ࡫࠺ࠡ࡝ࠣࠫᅗ")+str(kw6Zs29tznG0CFIUWxOh7qeH)+CnbBKmtF1x84q7AW(u"ࠩࠣࡡࠥࠦࠠࡓࡧࡤࡷࡴࡴ࠺ࠡ࡝ࠣࠫᅘ")+jZyzn8MtORbaeCW+sULh4NjakzI8He7xJCMGrql(u"ࠪࠤࡢࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬᅙ")+dUWFtBQ3cpoIZ9+dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠫࠥࡣࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪᅚ")+NPM3HKQ57xe+EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠬࠦ࡝ࠨᅛ"))
		else: KteLZCbM8W0FqE2OBx1(VRQE4jsXHSfhPWo5DgLwxGk,qhVEWvetzXLOcr1(xjPuFK3EsIZSiobQ5X)+sULh4NjakzI8He7xJCMGrql(u"࠭ࠠࠡࠢࡇ࡭ࡷ࡫ࡣࡵࠢࡦࡳࡳࡴࡥࡤࡶ࡬ࡳࡳࠦࡦࡢ࡫࡯ࡩࡩࠦࠠࠡࡅࡲࡨࡪࡀࠠ࡜ࠢࠪᅜ")+str(kw6Zs29tznG0CFIUWxOh7qeH)+GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠧࠡ࡟ࠣࠤࠥࡘࡥࡢࡵࡲࡲ࠿࡛ࠦࠡࠩᅝ")+jZyzn8MtORbaeCW+hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠨࠢࡠࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪᅞ")+dUWFtBQ3cpoIZ9+o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨᅟ")+NPM3HKQ57xe+zyvJMtBhrw(u"ࠪࠤࡢ࠭ᅠ"))
		qqikXADGgoZrB = kkoKaprUtZ5WbSwTGmuHxYi if PK3bO4TX9BzNHlFx6 else jkiCS0UWs2dNAJcGKn6mbHD(NPM3HKQ57xe)
		if VKiGj1LundAJQwEXcqgxC and isinstance(qqikXADGgoZrB,unicode): qqikXADGgoZrB = qqikXADGgoZrB.encode(a7VXeDU82IfQEnPZAdiT)
		if KnvcL4uQhH9sE38DwGle27jN: qqikXADGgoZrB = qqikXADGgoZrB.split(CnbBKmtF1x84q7AW(u"ࠫ࠴࠭ᅡ"))[-bXukYxQ4aHw]
		HWRDSjKvXGL = str(jZyzn8MtORbaeCW)+dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠬࡢ࡮ࠩࠢࠪᅢ")+qqikXADGgoZrB+S1SgCFYGJeMvfp5iZXK(u"࠭ࠠࠪࠩᅣ")
		if kw6Zs29tznG0CFIUWxOh7qeH in [-bXukYxQ4aHw,-Y0XZKGRAUQj5O] or yKzGr3CeHAFtRwgOEkjPvmJBoYhc8 or gm7AuXQ3dy1oF or u7oCsNixna5mecbTqhrvBgMOdGRKk9 or migIyvJFoD4OpAkNC or QfdEB8cH2IOu5GWVixPqFtwrYXh:
			SkMF3ejVQcGAh92BI5Hyg.code = -x1x9kIQo3zjZWnYaiy
			SkMF3ejVQcGAh92BI5Hyg.reason = jZyzn8MtORbaeCW
			if tBryl9dVaNzsMDCjqxJLIhS8:
				sjD4xoNlUHban7RZQmL9k3VzSdfT = GzdbwIR06mTtaFfHAiv7p1CgK95Bh(fjUoJylTVWh0,NPM3HKQ57xe,OucJVrWRKSqDChiG7yn3oz0dafZF,PwvNmnqXKrYVZugB5c8,smXRo1cSGQl,kSwGWZQN6LiFHUg0nxCutl8KO,dUWFtBQ3cpoIZ9,kw6Zs29tznG0CFIUWxOh7qeH,jZyzn8MtORbaeCW)
				if sjD4xoNlUHban7RZQmL9k3VzSdfT.succeeded: return sjD4xoNlUHban7RZQmL9k3VzSdfT
		dHPVDWfG4jX5e6QEo0CKh = VBlawK4mgHSyLEn8iqhUkz5
		if (iN41e5cDBwxtX9OhmYUvPJdfLb==QvgnCALNstmuUJiET(u"ࠧࡂࡕࡎࠫᅤ") or QbqvPf5AKC9wS6goxtZFs21H==LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠨࡃࡖࡏࠬᅥ")) and (bbzHK1VSDwLh or tBryl9dVaNzsMDCjqxJLIhS8):
			dHPVDWfG4jX5e6QEo0CKh = VEx8ogwsaZTLQpP4ctHXiCr0DNY9y(kw6Zs29tznG0CFIUWxOh7qeH,HWRDSjKvXGL,dUWFtBQ3cpoIZ9,kSwGWZQN6LiFHUg0nxCutl8KO)
			if dHPVDWfG4jX5e6QEo0CKh and iN41e5cDBwxtX9OhmYUvPJdfLb==mkHKSQvjWr5BTcM3wVY(u"ࠩࡄࡗࡐ࠭ᅦ"): iN41e5cDBwxtX9OhmYUvPJdfLb = gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠪࡅࡈࡉࡅࡑࡖࡈࡈࠬᅧ")
			else: iN41e5cDBwxtX9OhmYUvPJdfLb = hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠫࡗࡋࡊࡆࡅࡗࡉࡉ࠭ᅨ")
			if dHPVDWfG4jX5e6QEo0CKh and QbqvPf5AKC9wS6goxtZFs21H==mkHKSQvjWr5BTcM3wVY(u"ࠬࡇࡓࡌࠩᅩ"): QbqvPf5AKC9wS6goxtZFs21H = hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"࠭ࡁࡄࡅࡈࡔ࡙ࡋࡄࠨᅪ")
			else: QbqvPf5AKC9wS6goxtZFs21H = rwQN9AKhLCuMfHxjlbX0U(u"ࠧࡓࡇࡍࡉࡈ࡚ࡅࡅࠩᅫ")
			ee8c0jzrTntGSUdRJm.setSetting(HHoGx7Flus60(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡺࡹࡥࡥࡰࡶࠫᅬ"),iN41e5cDBwxtX9OhmYUvPJdfLb)
			ee8c0jzrTntGSUdRJm.setSetting(XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡲࡵࡳࡽࡿࠧᅭ"),QbqvPf5AKC9wS6goxtZFs21H)
		if dHPVDWfG4jX5e6QEo0CKh:
			if kw6Zs29tznG0CFIUWxOh7qeH==A6dMB1FlgxVivJ2fk9C(u"࠼ᒢ") and QvgnCALNstmuUJiET(u"ࠪ࡬ࡹࡺࡰࡴࠩᅮ") in NPM3HKQ57xe and RXrBJglna8u9F:
				if kSwGWZQN6LiFHUg0nxCutl8KO: OnsAxhdVjZF(gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠫฯ็ู๋ๆࠣๅา฻ࠠี้สำฮࠦวๅฬืๅ๏ืࠠࡔࡕࡏࠫᅯ"),ITvnUAMXsyb4eO(u"๊ࠬลึๆสั๋ࠥิไๆฬࠤฬ๊ล็ฬิ๊๏ะࠧᅰ"),HB5PvxRhwM=OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"࠷࠶࠰࠱ᒣ"))
				CMzQFXeI08KDwAJ9p = NPM3HKQ57xe+KNIvHPjUbhr(u"࠭ࡼࡽࡐࡲ࡚ࡪࡸࡩࡧࡻࡖࡗࡑ࠭ᅱ")
				fp9RhI8SNBmAulVZbk5J1cgto64YU = HaZx1JTW4ELwv(fjUoJylTVWh0,CMzQFXeI08KDwAJ9p,F49URk16JIawgp7YWZAXGtnMb,UBRzLM6ZdkWOKwy0qPfFIlC,SSKgaJNQBPwlZY,kSwGWZQN6LiFHUg0nxCutl8KO,GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡑࡓࡉࡓ࡛ࡒࡍࡡࡕࡉࡖ࡛ࡅࡔࡖࡖ࠱࠷ࡴࡤࠨᅲ"))
				if fp9RhI8SNBmAulVZbk5J1cgto64YU.succeeded:
					SkMF3ejVQcGAh92BI5Hyg = fp9RhI8SNBmAulVZbk5J1cgto64YU
					KteLZCbM8W0FqE2OBx1(YYcbiF1UROXlga2,qhVEWvetzXLOcr1(xjPuFK3EsIZSiobQ5X)+e2qDYgipPmTw4KvBLnochr(u"ࠨࠢࠣࠤࡘࡻࡣࡤࡧࡨࡨࡪࡪࠠࡶࡵ࡬ࡲ࡬ࠦࡓࡔࡎ࠽ࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪᅳ")+dUWFtBQ3cpoIZ9+LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨᅴ")+S6NALBOqGn1zi2W5M8y7+A6dMB1FlgxVivJ2fk9C(u"ࠪࠤࡢ࠭ᅵ"))
					if kSwGWZQN6LiFHUg0nxCutl8KO: OnsAxhdVjZF(JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"๋ࠫาวฮࠢหหุะฮะษ่ࠤࡘ࡙ࡌࠨᅶ"),QVDJLRlxNg127jMX(u"๊ࠬลึๆสั๋ࠥิไๆฬࠤฬ๊ล็ฬิ๊๏ะࠧᅷ"),HB5PvxRhwM=OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"࠸࠰࠱࠲ᒤ"))
				else:
					KteLZCbM8W0FqE2OBx1(VRQE4jsXHSfhPWo5DgLwxGk,qhVEWvetzXLOcr1(xjPuFK3EsIZSiobQ5X)+SqrG5mU3j96ldsFpExobw40TJY(u"࠭ࠠࠡࠢࡉࡥ࡮ࡲࡥࡥࠢࡸࡷ࡮ࡴࡧࠡࡕࡖࡐ࠿ࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬᅸ")+dUWFtBQ3cpoIZ9+FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠧࠡ࡟ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭ᅹ")+S6NALBOqGn1zi2W5M8y7+zyvJMtBhrw(u"ࠨࠢࡠࠫᅺ"))
					if kSwGWZQN6LiFHUg0nxCutl8KO: OnsAxhdVjZF(gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠩไุ้ࠦศศีอาิอๅࠡࡕࡖࡐࠬᅻ"),o1u5dij9UrcbXzVS8lwIWfKpnqM(u"่ࠪส฻ไศฯู้้ࠣไสࠢส่ส์สา่ํฮࠬᅼ"),HB5PvxRhwM=LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"࠲࠱࠲࠳ᒥ"))
			if not SkMF3ejVQcGAh92BI5Hyg.succeeded and QbqvPf5AKC9wS6goxtZFs21H in [JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠫࡆ࡛ࡔࡐࠩᅽ"),zyvJMtBhrw(u"ࠬࡇࡃࡄࡇࡓࡘࡊࡊࠧᅾ")] and tBryl9dVaNzsMDCjqxJLIhS8:
				if kSwGWZQN6LiFHUg0nxCutl8KO: OnsAxhdVjZF(e2qDYgipPmTw4KvBLnochr(u"࠭สโ฻ํู่๊ࠥาใิหฯࠦศา๊ๆื๏࠭ᅿ"),GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠧๅวุ่ฬำࠠๆึๆ่ฮࠦวๅว้ฮึ์๊หࠩᆀ"),HB5PvxRhwM=A6dMB1FlgxVivJ2fk9C(u"࠳࠲࠳࠴ᒦ"))
				fp9RhI8SNBmAulVZbk5J1cgto64YU = rl9Twe5k0EoiPUIFq(fjUoJylTVWh0,NPM3HKQ57xe,F49URk16JIawgp7YWZAXGtnMb,UBRzLM6ZdkWOKwy0qPfFIlC,SSKgaJNQBPwlZY,kSwGWZQN6LiFHUg0nxCutl8KO,dUWFtBQ3cpoIZ9)
				if fp9RhI8SNBmAulVZbk5J1cgto64YU.succeeded:
					SkMF3ejVQcGAh92BI5Hyg = fp9RhI8SNBmAulVZbk5J1cgto64YU
					KteLZCbM8W0FqE2OBx1(YYcbiF1UROXlga2,qhVEWvetzXLOcr1(xjPuFK3EsIZSiobQ5X)+FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠨࠢࠣࠤࡕࡸ࡯ࡹ࡫ࡨࡷࠥࡹࡵࡤࡥࡨࡩࡩ࡫ࡤ࠻ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨᆁ")+dUWFtBQ3cpoIZ9+ITvnUAMXsyb4eO(u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨᆂ")+S6NALBOqGn1zi2W5M8y7+DJ1ICpbyR2(u"ࠪࠤࡢ࠭ᆃ"))
					if kSwGWZQN6LiFHUg0nxCutl8KO: OnsAxhdVjZF(OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"๋ࠫาวฮࠢึ๎ึ็ัศฬࠣฬึ๎ใิ์ࠪᆄ"),o1u5dij9UrcbXzVS8lwIWfKpnqM(u"๊ࠬลึๆสั๋ࠥิไๆฬࠤฬ๊ล็ฬิ๊๏ะࠧᆅ"),HB5PvxRhwM=ITvnUAMXsyb4eO(u"࠴࠳࠴࠵ᒧ"))
				else:
					KteLZCbM8W0FqE2OBx1(VRQE4jsXHSfhPWo5DgLwxGk,qhVEWvetzXLOcr1(xjPuFK3EsIZSiobQ5X)+CnbBKmtF1x84q7AW(u"࠭ࠠࠡࠢࡓࡶࡴࡾࡩࡦࡵࠣࡪࡦ࡯࡬ࡦࡦ࠽ࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪᆆ")+dUWFtBQ3cpoIZ9+JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠧࠡ࡟ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭ᆇ")+S6NALBOqGn1zi2W5M8y7+DJ1ICpbyR2(u"ࠨࠢࡠࠫᆈ"))
					if kSwGWZQN6LiFHUg0nxCutl8KO: OnsAxhdVjZF(GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠩไุ้ࠦำ๋ำไีฬะࠠษำ๋็ุ๐ࠧᆉ"),zyvJMtBhrw(u"่ࠪส฻ไศฯู้้ࠣไสࠢส่ส์สา่ํฮࠬᆊ"),HB5PvxRhwM=DJ1ICpbyR2(u"࠵࠴࠵࠶ᒨ"))
			if not SkMF3ejVQcGAh92BI5Hyg.succeeded and iN41e5cDBwxtX9OhmYUvPJdfLb in [DJ1ICpbyR2(u"ࠫࡆ࡛ࡔࡐࠩᆋ"),xcChIL13BpR8WArNt9Pl0So(u"ࠬࡇࡃࡄࡇࡓࡘࡊࡊࠧᆌ")] and bbzHK1VSDwLh:
				if kSwGWZQN6LiFHUg0nxCutl8KO: OnsAxhdVjZF(e2qDYgipPmTw4KvBLnochr(u"࠭สโ฻ํู่๊ࠥาใิࠤࡉࡔࡓࠨᆍ"),dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠧๅวุ่ฬำࠠๆึๆ่ฮࠦวๅว้ฮึ์๊หࠩᆎ"),HB5PvxRhwM=QvgnCALNstmuUJiET(u"࠶࠵࠶࠰ᒩ"))
				CMzQFXeI08KDwAJ9p = NPM3HKQ57xe+QVDJLRlxNg127jMX(u"ࠨࡾࡿࡑࡾࡊࡎࡔࡗࡵࡰࡂ࠭ᆏ")
				fp9RhI8SNBmAulVZbk5J1cgto64YU = HaZx1JTW4ELwv(fjUoJylTVWh0,CMzQFXeI08KDwAJ9p,F49URk16JIawgp7YWZAXGtnMb,UBRzLM6ZdkWOKwy0qPfFIlC,SSKgaJNQBPwlZY,kSwGWZQN6LiFHUg0nxCutl8KO,hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡓࡕࡋࡎࡖࡔࡏࡣࡗࡋࡑࡖࡇࡖࡘࡘ࠳࠴ࡵࡪࠪᆐ"))
				if fp9RhI8SNBmAulVZbk5J1cgto64YU.succeeded:
					SkMF3ejVQcGAh92BI5Hyg = fp9RhI8SNBmAulVZbk5J1cgto64YU
					KteLZCbM8W0FqE2OBx1(YYcbiF1UROXlga2,qhVEWvetzXLOcr1(xjPuFK3EsIZSiobQ5X)+e2qDYgipPmTw4KvBLnochr(u"ࠪࠤࠥࠦࡄࡏࡕࠣࡷࡺࡩࡣࡦࡧࡧࡩࡩࡀࠠࠡࠢࡇࡒࡘࡀࠠ࡜ࠢࠪᆑ")+T5EshFWwM3J7zH+hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠫࠥࡣࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭ᆒ")+dUWFtBQ3cpoIZ9+dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠬࠦ࡝࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫᆓ")+S6NALBOqGn1zi2W5M8y7+KBkxSYaz93pu1(u"࠭ࠠ࡞ࠩᆔ"))
					if kSwGWZQN6LiFHUg0nxCutl8KO: OnsAxhdVjZF(hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠧ็ฮสัู๊ࠥาใิࠤࡉࡔࡓࠨᆕ"),dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠨๆศู้ออࠡ็ื็้ฯࠠศๆศ๊ฯืๆ๋ฬࠪᆖ"),HB5PvxRhwM=sULh4NjakzI8He7xJCMGrql(u"࠷࠶࠰࠱ᒪ"))
				else:
					KteLZCbM8W0FqE2OBx1(VRQE4jsXHSfhPWo5DgLwxGk,qhVEWvetzXLOcr1(xjPuFK3EsIZSiobQ5X)+CnbBKmtF1x84q7AW(u"ࠩࠣࠤࠥࡊࡎࡔࠢࡩࡥ࡮ࡲࡥࡥ࠼ࠣࠤࠥࡊࡎࡔ࠼ࠣ࡟ࠥ࠭ᆗ")+T5EshFWwM3J7zH+KBkxSYaz93pu1(u"ࠪࠤࡢࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬᆘ")+dUWFtBQ3cpoIZ9+XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠫࠥࡣࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪᆙ")+S6NALBOqGn1zi2W5M8y7+e2qDYgipPmTw4KvBLnochr(u"ࠬࠦ࡝ࠨᆚ"))
					if kSwGWZQN6LiFHUg0nxCutl8KO: OnsAxhdVjZF(LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"࠭แีๆࠣื๏ืแาࠢࡇࡒࡘ࠭ᆛ"),CnbBKmtF1x84q7AW(u"ࠧๅวุ่ฬำࠠๆึๆ่ฮࠦวๅว้ฮึ์๊หࠩᆜ"),HB5PvxRhwM=jeAby54c02TgG8zuivonX91(u"࠸࠰࠱࠲ᒫ"))
		if QbqvPf5AKC9wS6goxtZFs21H==LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠨࡔࡈࡎࡊࡉࡔࡆࡆࠪᆝ") or iN41e5cDBwxtX9OhmYUvPJdfLb==OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠩࡕࡉࡏࡋࡃࡕࡇࡇࠫᆞ"): kSwGWZQN6LiFHUg0nxCutl8KO = fEXMiAyG3ql4vKB
		if not SkMF3ejVQcGAh92BI5Hyg.succeeded:
			if kSwGWZQN6LiFHUg0nxCutl8KO: r5jmTKLnJvstRoIdDz3i8BNVGH = VEx8ogwsaZTLQpP4ctHXiCr0DNY9y(kw6Zs29tznG0CFIUWxOh7qeH,HWRDSjKvXGL,dUWFtBQ3cpoIZ9,kSwGWZQN6LiFHUg0nxCutl8KO)
			if kw6Zs29tznG0CFIUWxOh7qeH!=wwPrSDa21lUh(u"࠲࠱࠲ᒬ") and dUWFtBQ3cpoIZ9 not in HCW4OXeRDroS and e2qDYgipPmTw4KvBLnochr(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࠧᆟ") not in dUWFtBQ3cpoIZ9: vn97kbzpVDXotqS6RhuK2srl()
	if ee8c0jzrTntGSUdRJm.getSetting(LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡵࡨࡨࡳࡹࠧᆠ")) not in [MMizeNH0AKu(u"ࠬࡇࡕࡕࡑࠪᆡ"),QVDJLRlxNg127jMX(u"࠭ࡓࡕࡑࡓࠫᆢ"),KBkxSYaz93pu1(u"ࠧࡂࡕࡎࠫᆣ")]: ee8c0jzrTntGSUdRJm.setSetting(KNIvHPjUbhr(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡺࡹࡥࡥࡰࡶࠫᆤ"),mkHKSQvjWr5BTcM3wVY(u"ࠩࡄࡗࡐ࠭ᆥ"))
	if ee8c0jzrTntGSUdRJm.getSetting(LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡵࡴࡧࡳࡶࡴࡾࡹࠨᆦ")) not in [e2qDYgipPmTw4KvBLnochr(u"ࠫࡆ࡛ࡔࡐࠩᆧ"),DJ1ICpbyR2(u"࡙ࠬࡔࡐࡒࠪᆨ"),JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"࠭ࡁࡔࡍࠪᆩ")]: ee8c0jzrTntGSUdRJm.setSetting(A6dMB1FlgxVivJ2fk9C(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡹࡸ࡫ࡰࡳࡱࡻࡽࠬᆪ"),LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠨࡃࡖࡏࠬᆫ"))
	return SkMF3ejVQcGAh92BI5Hyg
def kB2Mfr9YEmjK(website,yjRQCb72xh5EO9giLe8,AasrFJx7ByE1ZXm85=None):
	UhcDgO18H2mN5bESILGXxkQ79st = rwQN9AKhLCuMfHxjlbX0U(u"࠲࠲ᒭ")
	qMQX2RJye3cflAi7WDE9HU4BtS0 = [o1u5dij9UrcbXzVS8lwIWfKpnqM(u"࠳ᒮ"),o1u5dij9UrcbXzVS8lwIWfKpnqM(u"࠳ᒮ"),o1u5dij9UrcbXzVS8lwIWfKpnqM(u"࠳ᒮ"),o1u5dij9UrcbXzVS8lwIWfKpnqM(u"࠴࠴ᒯ"),LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"࠹ᒰ"),o1u5dij9UrcbXzVS8lwIWfKpnqM(u"࠴࠴ᒯ"),o1u5dij9UrcbXzVS8lwIWfKpnqM(u"࠳ᒮ"),o1u5dij9UrcbXzVS8lwIWfKpnqM(u"࠳ᒮ"),o1u5dij9UrcbXzVS8lwIWfKpnqM(u"࠳ᒮ"),LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"࠹ᒰ")]
	ygRHjPLbtd4ODi = oaygHCpIDcs8wA
	m0uV8vhKSIrsRQ4zf = []
	dWb0vyHhMD49 = [jeAby54c02TgG8zuivonX91(u"࠵ᒱ")]*UhcDgO18H2mN5bESILGXxkQ79st
	F0Kqwvzcj4eX = Mqk51CFBym0pIQXZLsOxSJ(MM5Dx39f7ULhcJsRptzIowP,LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠩࡧ࡭ࡨࡺࠧᆬ"),QVDJLRlxNg127jMX(u"ࠪࡗࡈࡘࡁࡑࡇࡕࡗࡤ࡙ࡔࡂࡖࡘࡗࠬᆭ"))
	for mR94s1DcOzeZdBa5QS3 in list(F0Kqwvzcj4eX.keys()):
		if website not in mR94s1DcOzeZdBa5QS3: continue
		ITlpOFqLn7W2hYkdijCogm,bHcEo6KJsIXR8BZhUO9ijGdk4 = mR94s1DcOzeZdBa5QS3.split(zyvJMtBhrw(u"ࠫࡤࡥࠧᆮ"))
		dWb0vyHhMD49[int(bHcEo6KJsIXR8BZhUO9ijGdk4)] = F0Kqwvzcj4eX[mR94s1DcOzeZdBa5QS3]
	for dV8hf3cYkFXZ2InK1jJzoiN9aquw7x in range(UhcDgO18H2mN5bESILGXxkQ79st):
		if dV8hf3cYkFXZ2InK1jJzoiN9aquw7x in ygRHjPLbtd4ODi+yjRQCb72xh5EO9giLe8: continue
		if dV8hf3cYkFXZ2InK1jJzoiN9aquw7x==AasrFJx7ByE1ZXm85: dWb0vyHhMD49[dV8hf3cYkFXZ2InK1jJzoiN9aquw7x] = dWb0vyHhMD49[dV8hf3cYkFXZ2InK1jJzoiN9aquw7x]+S1SgCFYGJeMvfp5iZXK(u"࠷ᒲ")
		if dWb0vyHhMD49[dV8hf3cYkFXZ2InK1jJzoiN9aquw7x]<SqrG5mU3j96ldsFpExobw40TJY(u"࠳ᒳ"): m0uV8vhKSIrsRQ4zf += [dV8hf3cYkFXZ2InK1jJzoiN9aquw7x]*qMQX2RJye3cflAi7WDE9HU4BtS0[dV8hf3cYkFXZ2InK1jJzoiN9aquw7x]
	if not m0uV8vhKSIrsRQ4zf:
		for dV8hf3cYkFXZ2InK1jJzoiN9aquw7x in range(UhcDgO18H2mN5bESILGXxkQ79st):
			dWb0vyHhMD49[dV8hf3cYkFXZ2InK1jJzoiN9aquw7x] = KNIvHPjUbhr(u"࠱ᒴ")
			if dV8hf3cYkFXZ2InK1jJzoiN9aquw7x in ygRHjPLbtd4ODi+yjRQCb72xh5EO9giLe8: continue
			m0uV8vhKSIrsRQ4zf += [dV8hf3cYkFXZ2InK1jJzoiN9aquw7x]*qMQX2RJye3cflAi7WDE9HU4BtS0[dV8hf3cYkFXZ2InK1jJzoiN9aquw7x]
	for dV8hf3cYkFXZ2InK1jJzoiN9aquw7x in ygRHjPLbtd4ODi: dWb0vyHhMD49[dV8hf3cYkFXZ2InK1jJzoiN9aquw7x] = KBkxSYaz93pu1(u"࠻࠼࠽࠾ᒵ")
	KCuwjZItxqH = []
	for dV8hf3cYkFXZ2InK1jJzoiN9aquw7x in range(UhcDgO18H2mN5bESILGXxkQ79st): KCuwjZItxqH.append(website+DJ1ICpbyR2(u"ࠬࡥ࡟ࠨᆯ")+str(dV8hf3cYkFXZ2InK1jJzoiN9aquw7x))
	BxuD7iQRpW1(MM5Dx39f7ULhcJsRptzIowP,gDuGMR3z1aV6YdLmCpiO8Kl(u"࠭ࡓࡄࡔࡄࡔࡊࡘࡓࡠࡕࡗࡅ࡙࡛ࡓࠨᆰ"),KCuwjZItxqH,dWb0vyHhMD49,dKZePjlDFhABt1zp27JMqO*QvgnCALNstmuUJiET(u"࠸ᒶ"),VBlawK4mgHSyLEn8iqhUkz5)
	return m0uV8vhKSIrsRQ4zf
def GzdbwIR06mTtaFfHAiv7p1CgK95Bh(fjUoJylTVWh0,NPM3HKQ57xe,OucJVrWRKSqDChiG7yn3oz0dafZF,PwvNmnqXKrYVZugB5c8,smXRo1cSGQl,kSwGWZQN6LiFHUg0nxCutl8KO,dUWFtBQ3cpoIZ9,kw6Zs29tznG0CFIUWxOh7qeH,jZyzn8MtORbaeCW,yjRQCb72xh5EO9giLe8=[]):
	OnsAxhdVjZF(QVDJLRlxNg127jMX(u"ࠧษัฦฮࠥ฿ๅๅ์ฬࠤฯาว้ิࠣห้ำฬษࠩᆱ"),hWGMqtBy4wuLaVcj,HB5PvxRhwM=FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"࠻࠺࠶ᒷ"))
	KteLZCbM8W0FqE2OBx1(YYcbiF1UROXlga2,qhVEWvetzXLOcr1(xjPuFK3EsIZSiobQ5X)+wwPrSDa21lUh(u"ࠨࠢࠣࠤ࡙ࡸࡹࡪࡰࡪࠤࡧࡿࡰࡢࡵࡶࠤࡧࡲ࡯ࡤ࡭࡬ࡲ࡬ࠦࠠࠡࡅࡲࡨࡪࡀࠠ࡜ࠢࠪᆲ")+str(kw6Zs29tznG0CFIUWxOh7qeH)+EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠩࠣࡡࠥࠦࡒࡦࡣࡶࡳࡳࡀࠠ࡜ࠢࠪᆳ")+jZyzn8MtORbaeCW+e2qDYgipPmTw4KvBLnochr(u"ࠪࠤࡢࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬᆴ")+dUWFtBQ3cpoIZ9+KBkxSYaz93pu1(u"ࠫࠥࡣࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩᆵ")+NPM3HKQ57xe+LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠬࠦ࡝ࠨᆶ"))
	website = dUWFtBQ3cpoIZ9.split(zyvJMtBhrw(u"࠭࠭ࠨᆷ"))[ybdv7XcT3lxF6QezULwCAGk]
	IMiTf0WrHAUCbvojaRFQu7l = kB2Mfr9YEmjK(website,yjRQCb72xh5EO9giLe8)
	e1FSlOgEW4bYJhjVAxf5ycGt = []
	if website==EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠧࡇࡃࡖࡉࡑࡎࡄ࠲ࠩᆸ"):
		if ybdv7XcT3lxF6QezULwCAGk in IMiTf0WrHAUCbvojaRFQu7l: e1FSlOgEW4bYJhjVAxf5ycGt += [ybdv7XcT3lxF6QezULwCAGk]
		if bXukYxQ4aHw in IMiTf0WrHAUCbvojaRFQu7l: e1FSlOgEW4bYJhjVAxf5ycGt += [bXukYxQ4aHw]
		if Y0XZKGRAUQj5O in IMiTf0WrHAUCbvojaRFQu7l: e1FSlOgEW4bYJhjVAxf5ycGt += [Y0XZKGRAUQj5O]
		if x1x9kIQo3zjZWnYaiy in IMiTf0WrHAUCbvojaRFQu7l: e1FSlOgEW4bYJhjVAxf5ycGt += [x1x9kIQo3zjZWnYaiy]*OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"࠶࠶ᒸ")
		if jR6BYWNFZ0egmH4Tr2Q78LbSs3t in IMiTf0WrHAUCbvojaRFQu7l: e1FSlOgEW4bYJhjVAxf5ycGt += [jR6BYWNFZ0egmH4Tr2Q78LbSs3t]*xcChIL13BpR8WArNt9Pl0So(u"࠻ᒹ")
		if EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"࠶ᒻ") in IMiTf0WrHAUCbvojaRFQu7l: e1FSlOgEW4bYJhjVAxf5ycGt += [EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"࠶ᒻ")]*GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"࠱࠱ᒺ")
		if xcChIL13BpR8WArNt9Pl0So(u"࠸ᒼ") in IMiTf0WrHAUCbvojaRFQu7l: e1FSlOgEW4bYJhjVAxf5ycGt += [xcChIL13BpR8WArNt9Pl0So(u"࠸ᒼ")]
		if xcChIL13BpR8WArNt9Pl0So(u"࠺ᒽ") in IMiTf0WrHAUCbvojaRFQu7l: e1FSlOgEW4bYJhjVAxf5ycGt += [xcChIL13BpR8WArNt9Pl0So(u"࠺ᒽ")]
	elif website==hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠨࡕࡋࡅࡍࡏࡄ࠵ࡗࠪᆹ"):
		if x1x9kIQo3zjZWnYaiy in IMiTf0WrHAUCbvojaRFQu7l: e1FSlOgEW4bYJhjVAxf5ycGt += [x1x9kIQo3zjZWnYaiy]*zyvJMtBhrw(u"࠵࠵ᒾ")
	elif website==JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠩࡆࡍࡒࡇࡗࡃࡃࡖࠫᆺ"):
		if bXukYxQ4aHw in IMiTf0WrHAUCbvojaRFQu7l: e1FSlOgEW4bYJhjVAxf5ycGt += [bXukYxQ4aHw]
		if jR6BYWNFZ0egmH4Tr2Q78LbSs3t in IMiTf0WrHAUCbvojaRFQu7l: e1FSlOgEW4bYJhjVAxf5ycGt += [jR6BYWNFZ0egmH4Tr2Q78LbSs3t]*JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"࠺ᒿ")
		if xcChIL13BpR8WArNt9Pl0So(u"࠵ᓁ") in IMiTf0WrHAUCbvojaRFQu7l: e1FSlOgEW4bYJhjVAxf5ycGt += [xcChIL13BpR8WArNt9Pl0So(u"࠵ᓁ")]*sULh4NjakzI8He7xJCMGrql(u"࠷࠰ᓀ")
		if MMizeNH0AKu(u"࠷ᓂ") in IMiTf0WrHAUCbvojaRFQu7l: e1FSlOgEW4bYJhjVAxf5ycGt += [MMizeNH0AKu(u"࠷ᓂ")]
		if gDuGMR3z1aV6YdLmCpiO8Kl(u"࠹ᓃ") in IMiTf0WrHAUCbvojaRFQu7l: e1FSlOgEW4bYJhjVAxf5ycGt += [gDuGMR3z1aV6YdLmCpiO8Kl(u"࠹ᓃ")]
	elif website==mkHKSQvjWr5BTcM3wVY(u"ࠪࡇࡎࡓࡁࡍࡋࡊࡌ࡙࠭ᆻ"):
		if jR6BYWNFZ0egmH4Tr2Q78LbSs3t in IMiTf0WrHAUCbvojaRFQu7l: e1FSlOgEW4bYJhjVAxf5ycGt += [jR6BYWNFZ0egmH4Tr2Q78LbSs3t]*ITvnUAMXsyb4eO(u"࠸ᓄ")
		if A6dMB1FlgxVivJ2fk9C(u"࠺ᓆ") in IMiTf0WrHAUCbvojaRFQu7l: e1FSlOgEW4bYJhjVAxf5ycGt += [A6dMB1FlgxVivJ2fk9C(u"࠺ᓆ")]*MMizeNH0AKu(u"࠵࠵ᓅ")
	elif website==jeAby54c02TgG8zuivonX91(u"ࠫ࡜ࡋࡃࡊࡏࡄ࠵ࠬᆼ"):
		if CnbBKmtF1x84q7AW(u"࠿ᓇ") in IMiTf0WrHAUCbvojaRFQu7l: e1FSlOgEW4bYJhjVAxf5ycGt += [CnbBKmtF1x84q7AW(u"࠿ᓇ")]*rwQN9AKhLCuMfHxjlbX0U(u"࠵ᓈ")
	if e1FSlOgEW4bYJhjVAxf5ycGt: IMiTf0WrHAUCbvojaRFQu7l = e1FSlOgEW4bYJhjVAxf5ycGt
	if IMiTf0WrHAUCbvojaRFQu7l:
		a0zywlUMgH25vFxTIVfosQcKbWtAP = eOmXSF6kIWV7yqKCR.sample(IMiTf0WrHAUCbvojaRFQu7l,bXukYxQ4aHw)[ybdv7XcT3lxF6QezULwCAGk]
	else: a0zywlUMgH25vFxTIVfosQcKbWtAP = -bXukYxQ4aHw
	update = VBlawK4mgHSyLEn8iqhUkz5
	if a0zywlUMgH25vFxTIVfosQcKbWtAP==ybdv7XcT3lxF6QezULwCAGk:
		scraperserver = OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠬࡹࡣࡳࡣࡳࡩࡴࡶࡳ࠲ࠩᆽ")
		bqKpGwk6Crd = LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡳࡤࡴࡤࡴࡪࡵࡰࡴ࠰࡮ࡩࡪࡶ࡟ࡩࡧࡤࡨࡪࡸࡳ࠾ࡖࡵࡹࡪ࠴ࡣࡰࡷࡱࡸࡷࡿ࠽ࡪ࡮࠽࠵࠺࠶ࡤ࠳࠴ࡩ࠵࠲ࡩ࠵࠹ࡣ࠰࠸࠵࠸࠱࠮ࡣࡤ࠼࠹࠳ࡥ࠺࠴࠶ࡧࡦ࡬࠸࠶࠺࠶࠸ࡅࡶࡲࡰࡺࡼ࠲ࡸࡩࡲࡢࡲࡨࡳࡵࡹ࠮ࡪࡱ࠽࠹࠸࠻࠳ࠨᆾ")
		FjQOc5WuzKg0Vikb6tDeNHZP1mS = NPM3HKQ57xe+OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠧࡽࡾࡐࡽࡕࡸ࡯ࡹࡻࡘࡶࡱࡃࠧᆿ")+bqKpGwk6Crd+o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠨࡾࡿࡒࡴ࡜ࡥࡳ࡫ࡩࡽࡘ࡙ࡌࠨᇀ")
		sjD4xoNlUHban7RZQmL9k3VzSdfT = HaZx1JTW4ELwv(fjUoJylTVWh0,FjQOc5WuzKg0Vikb6tDeNHZP1mS,OucJVrWRKSqDChiG7yn3oz0dafZF,PwvNmnqXKrYVZugB5c8,smXRo1cSGQl,kSwGWZQN6LiFHUg0nxCutl8KO,dUWFtBQ3cpoIZ9,fEXMiAyG3ql4vKB,fEXMiAyG3ql4vKB)
	elif a0zywlUMgH25vFxTIVfosQcKbWtAP==bXukYxQ4aHw:
		scraperserver = SqrG5mU3j96ldsFpExobw40TJY(u"ࠩࡶࡧࡷࡧࡰࡦࡱࡳࡷ࠷࠭ᇁ")
		bqKpGwk6Crd = KNIvHPjUbhr(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡷࡨࡸࡡࡱࡧࡲࡴࡸ࠴࡫ࡦࡧࡳࡣ࡭࡫ࡡࡥࡧࡵࡷࡂ࡚ࡲࡶࡧ࠱ࡧࡴࡻ࡮ࡵࡴࡼࡁ࡮ࡲ࠺࠴࠻࠼࠵ࡪ࠿ࡣ࠶࠯࠺ࡩࡪ࠹࠭࠵ࡧࡨ࠶࠲࠾࠴ࡤ࠲࠰ࡪࡩ࠽࠹࠳ࡤࡤࡨࡩ࠹ࡤ࠶ࡂࡳࡶࡴࡾࡹ࠯ࡵࡦࡶࡦࡶࡥࡰࡲࡶ࠲࡮ࡵ࠺࠶࠵࠸࠷ࠬᇂ")
		FjQOc5WuzKg0Vikb6tDeNHZP1mS = NPM3HKQ57xe+GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠫࢁࢂࡍࡺࡒࡵࡳࡽࡿࡕࡳ࡮ࡀࠫᇃ")+bqKpGwk6Crd+xcChIL13BpR8WArNt9Pl0So(u"ࠬࢂࡼࡏࡱ࡙ࡩࡷ࡯ࡦࡺࡕࡖࡐࠬᇄ")
		sjD4xoNlUHban7RZQmL9k3VzSdfT = HaZx1JTW4ELwv(fjUoJylTVWh0,FjQOc5WuzKg0Vikb6tDeNHZP1mS,OucJVrWRKSqDChiG7yn3oz0dafZF,PwvNmnqXKrYVZugB5c8,smXRo1cSGQl,kSwGWZQN6LiFHUg0nxCutl8KO,dUWFtBQ3cpoIZ9,fEXMiAyG3ql4vKB,fEXMiAyG3ql4vKB)
	elif a0zywlUMgH25vFxTIVfosQcKbWtAP==Y0XZKGRAUQj5O:
		scraperserver = dv0trJR7PwmKyxDYO52VLau8gEph(u"࠭ࡳࡤࡴࡤࡴࡪࡸࡡࡱ࡫ࠪᇅ")
		bqKpGwk6Crd = jeAby54c02TgG8zuivonX91(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡴࡥࡵࡥࡵ࡫ࡲࡢࡲ࡬࠲ࡰ࡫ࡥࡱࡡ࡫ࡩࡦࡪࡥࡳࡵࡀࡘࡷࡻࡥ࠯ࡥࡲࡹࡳࡺࡲࡺࡡࡦࡳࡩ࡫࠽ࡪ࡮࠽࠻࠻ࡨ࠴ࡧࡥ࠶࠸࡫ࡩࡤ࠲࠻ࡧ࠽ࡨ࠻࠵ࡢ࠳࠸ࡪ࠸࠼࠰࠵ࡥࡧ࠽࠶࠺ࡣࡁࡲࡵࡳࡽࡿ࠭ࡴࡧࡵࡺࡪࡸ࠮ࡴࡥࡵࡥࡵ࡫ࡲࡢࡲ࡬࠲ࡨࡵ࡭࠻࠺࠳࠴࠶࠭ᇆ")
		FjQOc5WuzKg0Vikb6tDeNHZP1mS = NPM3HKQ57xe+xcChIL13BpR8WArNt9Pl0So(u"ࠨࡾࡿࡑࡾࡖࡲࡰࡺࡼ࡙ࡷࡲ࠽ࠨᇇ")+bqKpGwk6Crd+HHoGx7Flus60(u"ࠩࡿࢀࡓࡵࡖࡦࡴ࡬ࡪࡾ࡙ࡓࡍࠩᇈ")
		sjD4xoNlUHban7RZQmL9k3VzSdfT = HaZx1JTW4ELwv(fjUoJylTVWh0,FjQOc5WuzKg0Vikb6tDeNHZP1mS,OucJVrWRKSqDChiG7yn3oz0dafZF,PwvNmnqXKrYVZugB5c8,smXRo1cSGQl,kSwGWZQN6LiFHUg0nxCutl8KO,dUWFtBQ3cpoIZ9,fEXMiAyG3ql4vKB,fEXMiAyG3ql4vKB)
	elif a0zywlUMgH25vFxTIVfosQcKbWtAP==x1x9kIQo3zjZWnYaiy:
		scraperserver = MMizeNH0AKu(u"ࠪࡷࡨࡸࡡࡱࡧࡸࡴࠬᇉ")
		CMzQFXeI08KDwAJ9p = NPM3HKQ57xe.replace(GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࠭ᇊ"),QvgnCALNstmuUJiET(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠭ᇋ"))
		FjQOc5WuzKg0Vikb6tDeNHZP1mS = sULh4NjakzI8He7xJCMGrql(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡡࡱ࡫࠱ࡷࡨࡸࡡࡱࡧࡸࡴ࠳ࡩ࡯࡮࠱ࡂࡥࡵ࡯࡟࡬ࡧࡼࡁ࠶࡜ࡎࡴࡏࡷࡐ࠶ࡵࡂࡓ࡚࡮ࡗࡓࡉࡢࡄࡏࡍ࠵ࡐ࡞࡙ࡋ࡬࡭࠴ࡩࡰ࡚ࡸࠨ࡮ࡩࡪࡶ࡟ࡩࡧࡤࡨࡪࡸࡳ࠾ࡈࡤࡰࡸ࡫ࠦࡤࡱࡸࡲࡹࡸࡹࡠࡥࡲࡨࡪࡃࡩ࡭ࠨࡸࡶࡱࡃࠧᇌ")+e1mT8H4dGS3XFyx0KLUA9(CMzQFXeI08KDwAJ9p)
		sjD4xoNlUHban7RZQmL9k3VzSdfT = HaZx1JTW4ELwv(SqrG5mU3j96ldsFpExobw40TJY(u"ࠧࡈࡇࡗࠫᇍ"),FjQOc5WuzKg0Vikb6tDeNHZP1mS,OucJVrWRKSqDChiG7yn3oz0dafZF,PwvNmnqXKrYVZugB5c8,smXRo1cSGQl,kSwGWZQN6LiFHUg0nxCutl8KO,dUWFtBQ3cpoIZ9,fEXMiAyG3ql4vKB,fEXMiAyG3ql4vKB)
	elif a0zywlUMgH25vFxTIVfosQcKbWtAP==jR6BYWNFZ0egmH4Tr2Q78LbSs3t:
		scraperserver = dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠨࡵࡦࡶࡦࡶࡩ࡯ࡩࡵࡳࡧࡵࡴࠨᇎ")
		FjQOc5WuzKg0Vikb6tDeNHZP1mS = sULh4NjakzI8He7xJCMGrql(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡤࡴ࡮࠴ࡳࡤࡴࡤࡴ࡮ࡴࡧࡳࡱࡥࡳࡹ࠴ࡣࡰ࡯࠲ࡃࡹࡵ࡫ࡦࡰࡀࡥ࠹࡬࠷ࡧࡤ࠴࠸࠲࠸ࡤࡦࡨ࠰࠸࠵࠽࠱࠮࠺࠹࠸ࡧ࠳࠲࠳ࡧ࠶࠶࠻࠺ࡤ࠵ࡦࡧࡧࠫࡶࡲࡰࡺࡼࡇࡴࡻ࡮ࡵࡴࡼࡁࡎࡒࠦࡶࡴ࡯ࡁࠬᇏ")+e1mT8H4dGS3XFyx0KLUA9(NPM3HKQ57xe)
		sjD4xoNlUHban7RZQmL9k3VzSdfT = HaZx1JTW4ELwv(KBkxSYaz93pu1(u"ࠪࡋࡊ࡚ࠧᇐ"),FjQOc5WuzKg0Vikb6tDeNHZP1mS,OucJVrWRKSqDChiG7yn3oz0dafZF,PwvNmnqXKrYVZugB5c8,smXRo1cSGQl,kSwGWZQN6LiFHUg0nxCutl8KO,dUWFtBQ3cpoIZ9,fEXMiAyG3ql4vKB,fEXMiAyG3ql4vKB)
		try:
			sjD4xoNlUHban7RZQmL9k3VzSdfT.content = Cy9ow3c21nABMjzqeaIT(OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠫࡩ࡯ࡣࡵࠩᇑ"),sjD4xoNlUHban7RZQmL9k3VzSdfT.content)
			sjD4xoNlUHban7RZQmL9k3VzSdfT.content = sjD4xoNlUHban7RZQmL9k3VzSdfT.content[A6dMB1FlgxVivJ2fk9C(u"ࠬࡸࡥࡴࡷ࡯ࡸࠬᇒ")]
		except: pass
	elif a0zywlUMgH25vFxTIVfosQcKbWtAP==S1SgCFYGJeMvfp5iZXK(u"࠶ᓉ"):
		scraperserver = mkHKSQvjWr5BTcM3wVY(u"࠭ࡳࡤࡴࡤࡴ࡮ࡴࡧࡢࡰࡷ࠵ࠬᇓ")
		bqKpGwk6Crd = XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡴࡥࡵࡥࡵ࡯࡮ࡨࡣࡱࡸࠫࡶࡲࡰࡺࡼࡣࡨࡵࡵ࡯ࡶࡵࡽࡂࡏࡌࠧࡤࡵࡳࡼࡹࡥࡳ࠿ࡉࡥࡱࡹࡥࠧࡨࡲࡶࡼࡧࡲࡥࡡ࡫ࡩࡦࡪࡥࡳࡵࡀࡘࡷࡻࡥ࠻࠴ࡥ࠷࠹࠶ࡡ࠷࠺࠼࠴ࡦ࠻࠴࠱࠳ࡧࡦࡨ࠹࠷࠳ࡥ࠴࠵࠹࠻ࡤ࠺࠸࠵ࡩ࠽ࡆࡰࡳࡱࡻࡽ࠳ࡹࡣࡳࡣࡳ࡭ࡳ࡭ࡡ࡯ࡶ࠱ࡧࡴࡳ࠺࠹࠲࠻࠴ࠬᇔ")
		FjQOc5WuzKg0Vikb6tDeNHZP1mS = NPM3HKQ57xe+JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠨࡾࡿࡑࡾࡖࡲࡰࡺࡼ࡙ࡷࡲ࠽ࠨᇕ")+bqKpGwk6Crd+hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠩࡿࢀࡓࡵࡖࡦࡴ࡬ࡪࡾ࡙ࡓࡍࠩᇖ")
		sjD4xoNlUHban7RZQmL9k3VzSdfT = HaZx1JTW4ELwv(fjUoJylTVWh0,FjQOc5WuzKg0Vikb6tDeNHZP1mS,OucJVrWRKSqDChiG7yn3oz0dafZF,PwvNmnqXKrYVZugB5c8,smXRo1cSGQl,kSwGWZQN6LiFHUg0nxCutl8KO,dUWFtBQ3cpoIZ9,fEXMiAyG3ql4vKB,fEXMiAyG3ql4vKB)
	elif a0zywlUMgH25vFxTIVfosQcKbWtAP==S1SgCFYGJeMvfp5iZXK(u"࠸ᓊ"):
		scraperserver = GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠪࡷࡨࡸࡡࡱࡧ࠱ࡨࡴ࠷ࠧᇗ")
		bqKpGwk6Crd = LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡨࡩ࠲࠷࠵ࡤࡦ࠶࡫࠵࠱࠶࠷ࡨ࠷ࡩࡡ࠶ࡦ࠸ࡨ࠸࡬࠹ࡦ࠵ࡦ࠷࠽࠼ࡥࡤࡣ࠴࠵࠵࠾࠳࠹࠻ࡤ࠻࠸ࡀࡣࡶࡵࡷࡳࡲࡎࡥࡢࡦࡨࡶࡸࡃࡔࡳࡷࡨࠪ࡬࡫࡯ࡄࡱࡧࡩࡂ࡯࡬ࡁࡲࡵࡳࡽࡿ࠮ࡴࡥࡵࡥࡵ࡫࠮ࡥࡱ࠽࠼࠵࠾࠰ࠨᇘ")
		FjQOc5WuzKg0Vikb6tDeNHZP1mS = NPM3HKQ57xe+FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠬࢂࡼࡎࡻࡓࡶࡴࡾࡹࡖࡴ࡯ࡁࠬᇙ")+bqKpGwk6Crd+NeO3CTLHrPfWUoIgy8Q(u"࠭ࡼࡽࡐࡲ࡚ࡪࡸࡩࡧࡻࡖࡗࡑ࠭ᇚ")
		sjD4xoNlUHban7RZQmL9k3VzSdfT = HaZx1JTW4ELwv(fjUoJylTVWh0,FjQOc5WuzKg0Vikb6tDeNHZP1mS,OucJVrWRKSqDChiG7yn3oz0dafZF,PwvNmnqXKrYVZugB5c8,smXRo1cSGQl,kSwGWZQN6LiFHUg0nxCutl8KO,dUWFtBQ3cpoIZ9,fEXMiAyG3ql4vKB,fEXMiAyG3ql4vKB)
	elif a0zywlUMgH25vFxTIVfosQcKbWtAP==MMizeNH0AKu(u"࠺ᓋ"):
		scraperserver = o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠧࡴࡥࡵࡥࡵ࡫࠮ࡥࡱ࠵ࠫᇛ")
		bqKpGwk6Crd = zyvJMtBhrw(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳ࡦ࠷ࡩ࠹ࡡࡦ࠳࠻࠹ࡩ࡬࠴ࡣࡨ࠹ࡥ࡫࠻࠳࠴ࡥ࠺࠴࠹࠶ࡢ࠴࠶࠺ࡧ࠾࡫࠹࠺ࡤࡨ࠸࠻࠼ࡡࡦ࠻࠽ࡧࡺࡹࡴࡰ࡯ࡋࡩࡦࡪࡥࡳࡵࡀࡘࡷࡻࡥࠧࡩࡨࡳࡈࡵࡤࡦ࠿࡬ࡰࡅࡶࡲࡰࡺࡼ࠲ࡸࡩࡲࡢࡲࡨ࠲ࡩࡵ࠺࠹࠲࠻࠴ࠬᇜ")
		FjQOc5WuzKg0Vikb6tDeNHZP1mS = NPM3HKQ57xe+xcChIL13BpR8WArNt9Pl0So(u"ࠩࡿࢀࡒࡿࡐࡳࡱࡻࡽ࡚ࡸ࡬࠾ࠩᇝ")+bqKpGwk6Crd+ITvnUAMXsyb4eO(u"ࠪࢀࢁࡔ࡯ࡗࡧࡵ࡭࡫ࡿࡓࡔࡎࠪᇞ")
		sjD4xoNlUHban7RZQmL9k3VzSdfT = HaZx1JTW4ELwv(fjUoJylTVWh0,FjQOc5WuzKg0Vikb6tDeNHZP1mS,OucJVrWRKSqDChiG7yn3oz0dafZF,PwvNmnqXKrYVZugB5c8,smXRo1cSGQl,kSwGWZQN6LiFHUg0nxCutl8KO,dUWFtBQ3cpoIZ9,fEXMiAyG3ql4vKB,fEXMiAyG3ql4vKB)
	elif a0zywlUMgH25vFxTIVfosQcKbWtAP==gDuGMR3z1aV6YdLmCpiO8Kl(u"࠼ᓌ"):
		scraperserver = hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠫࡸࡩࡲࡢࡲࡨࡳࡵࡹ࠳ࠨᇟ")
		FjQOc5WuzKg0Vikb6tDeNHZP1mS = CnbBKmtF1x84q7AW(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡰࡳࡱࡻࡽ࠳ࡹࡣࡳࡣࡳࡩࡴࡶࡳ࠯࡫ࡲ࠳ࡻ࠷࠯ࡀࡣࡳ࡭ࡤࡱࡥࡺ࠿࠶࠽࠾࠷ࡥ࠺ࡥ࠸࠱࠼࡫ࡥ࠴࠯࠷ࡩࡪ࠸࠭࠹࠶ࡦ࠴࠲࡬ࡤ࠸࠻࠵ࡦࡦࡪࡤ࠴ࡦ࠸ࠪࡨࡵࡵ࡯ࡶࡵࡽࡂ࡯࡬ࠧࡷࡵࡰࡂ࠭ᇠ")+e1mT8H4dGS3XFyx0KLUA9(NPM3HKQ57xe)
		sjD4xoNlUHban7RZQmL9k3VzSdfT = HaZx1JTW4ELwv(wwPrSDa21lUh(u"࠭ࡇࡆࡖࠪᇡ"),FjQOc5WuzKg0Vikb6tDeNHZP1mS,OucJVrWRKSqDChiG7yn3oz0dafZF,PwvNmnqXKrYVZugB5c8,smXRo1cSGQl,kSwGWZQN6LiFHUg0nxCutl8KO,dUWFtBQ3cpoIZ9,fEXMiAyG3ql4vKB,fEXMiAyG3ql4vKB)
	elif a0zywlUMgH25vFxTIVfosQcKbWtAP==QVDJLRlxNg127jMX(u"࠾ᓍ"):
		scraperserver = OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠧࡴࡥࡵࡥࡵ࡯࡮ࡨࡣࡱࡸ࠷࠭ᇢ")
		bqKpGwk6Crd = hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡵࡦࡶࡦࡶࡩ࡯ࡩࡤࡲࡹࠬࡰࡳࡱࡻࡽࡤࡩ࡯ࡶࡰࡷࡶࡾࡃࡁࡆࠨࡵࡩࡹࡻࡲ࡯ࡡࡳࡥ࡬࡫࡟ࡴࡱࡸࡶࡨ࡫࠽ࡵࡴࡸࡩࠫ࡬࡯ࡳࡹࡤࡶࡩࡥࡨࡦࡣࡧࡩࡷࡹ࠽ࡵࡴࡸࡩ࠿࠸ࡢ࠴࠶࠳ࡥ࠻࠾࠹࠱ࡣ࠸࠸࠵࠷ࡤࡣࡥ࠶࠻࠷ࡩ࠱࠲࠶࠸ࡨ࠾࠼࠲ࡦ࠺ࡃࡴࡷࡵࡸࡺ࠰ࡶࡧࡷࡧࡰࡪࡰࡪࡥࡳࡺ࠮ࡤࡱࡰ࠾࠽࠶࠸࠱ࠩᇣ")
		FjQOc5WuzKg0Vikb6tDeNHZP1mS = NPM3HKQ57xe+A6dMB1FlgxVivJ2fk9C(u"ࠩࡿࢀࡒࡿࡐࡳࡱࡻࡽ࡚ࡸ࡬࠾ࠩᇤ")+bqKpGwk6Crd+A6dMB1FlgxVivJ2fk9C(u"ࠪࢀࢁࡔ࡯ࡗࡧࡵ࡭࡫ࡿࡓࡔࡎࠪᇥ")
		sjD4xoNlUHban7RZQmL9k3VzSdfT = HaZx1JTW4ELwv(fjUoJylTVWh0,FjQOc5WuzKg0Vikb6tDeNHZP1mS,OucJVrWRKSqDChiG7yn3oz0dafZF,PwvNmnqXKrYVZugB5c8,smXRo1cSGQl,kSwGWZQN6LiFHUg0nxCutl8KO,dUWFtBQ3cpoIZ9,fEXMiAyG3ql4vKB,fEXMiAyG3ql4vKB)
	else:
		scraperserver,FjQOc5WuzKg0Vikb6tDeNHZP1mS = hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj
		sjD4xoNlUHban7RZQmL9k3VzSdfT = aRBhF1OdxM0ek5SwqG()
		update = fEXMiAyG3ql4vKB
	if update and not sjD4xoNlUHban7RZQmL9k3VzSdfT.succeeded:
		kB2Mfr9YEmjK(website,[],a0zywlUMgH25vFxTIVfosQcKbWtAP)
		if len(list(set(IMiTf0WrHAUCbvojaRFQu7l)))>bXukYxQ4aHw:
			dHPVDWfG4jX5e6QEo0CKh = XVmKrby29eCGMnlEY6jz0HNOR(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᇦ"),XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"๊ࠬไฤีไࠤุ๐ัโำ้ࠣ฾อไอหࠣห้ำฬษࠢิๆ๊ࠦࠧᇧ")+str(a0zywlUMgH25vFxTIVfosQcKbWtAP)+HHoGx7Flus60(u"࠭ࠠโึ็ࠤๆ๐ฺࠠ็็๎ฮࠦสอษ๋ึࠥอไฮฮหࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡ็ะหํ๊ษࠡฬฯหํุࠠศๆะะอࠦๅาหࠣวำื้ࠡสสืฯิฯศ็ࠣื๏ืแา่ࠢาฯ๊แࠡมࠤࠫᇨ"))
			if dHPVDWfG4jX5e6QEo0CKh==bXukYxQ4aHw:
				yjRQCb72xh5EO9giLe8.append(a0zywlUMgH25vFxTIVfosQcKbWtAP)
				sjD4xoNlUHban7RZQmL9k3VzSdfT = GzdbwIR06mTtaFfHAiv7p1CgK95Bh(fjUoJylTVWh0,NPM3HKQ57xe,OucJVrWRKSqDChiG7yn3oz0dafZF,PwvNmnqXKrYVZugB5c8,smXRo1cSGQl,kSwGWZQN6LiFHUg0nxCutl8KO,dUWFtBQ3cpoIZ9,kw6Zs29tznG0CFIUWxOh7qeH,jZyzn8MtORbaeCW,yjRQCb72xh5EO9giLe8)
				return sjD4xoNlUHban7RZQmL9k3VzSdfT
	sjD4xoNlUHban7RZQmL9k3VzSdfT.scrapernumber = str(a0zywlUMgH25vFxTIVfosQcKbWtAP)
	sjD4xoNlUHban7RZQmL9k3VzSdfT.scraperserver = scraperserver
	sjD4xoNlUHban7RZQmL9k3VzSdfT.scraperurl = FjQOc5WuzKg0Vikb6tDeNHZP1mS
	Hm1TBvbQAz0NwCon = zyvJMtBhrw(u"ࠧิ์ิๅึࠦัใ็ࠣࠫᇩ")+sjD4xoNlUHban7RZQmL9k3VzSdfT.scrapernumber
	if sjD4xoNlUHban7RZQmL9k3VzSdfT.succeeded:
		KteLZCbM8W0FqE2OBx1(YYcbiF1UROXlga2,qhVEWvetzXLOcr1(xjPuFK3EsIZSiobQ5X)+S1SgCFYGJeMvfp5iZXK(u"ࠨࠢࠣࠤࡘࡻࡣࡤࡧࡨࡨࡪࡪࠠࡣࡻࡳࡥࡸࡹࠠࡣ࡮ࡲࡧࡰ࡯࡮ࡨࠢࠣࠤࡘ࡫ࡲࡷࡧࡵ࠾ࠥࡡࠠࠨᇪ")+scraperserver+EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠩࠣࡡࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫᇫ")+dUWFtBQ3cpoIZ9+jeAby54c02TgG8zuivonX91(u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩᇬ")+NPM3HKQ57xe+ITvnUAMXsyb4eO(u"ࠫࠥࡣࠧᇭ"))
		OnsAxhdVjZF(jeAby54c02TgG8zuivonX91(u"ࠬ์ฬฮฬࠣ฽๊๊๊สࠢอะฬ๎าࠡษ็ััฮࠧᇮ"),Hm1TBvbQAz0NwCon,HB5PvxRhwM=QvgnCALNstmuUJiET(u"࠽࠵࠱ᓎ"))
	else:
		KteLZCbM8W0FqE2OBx1(VRQE4jsXHSfhPWo5DgLwxGk,qhVEWvetzXLOcr1(xjPuFK3EsIZSiobQ5X)+zyvJMtBhrw(u"࠭ࠠࠡࠢࡉࡥ࡮ࡲࡥࡥࠢࡥࡽࡵࡧࡳࡴࠢࡥࡰࡴࡩ࡫ࡪࡰࡪࠤࠥࠦࡓࡦࡴࡹࡩࡷࡀࠠ࡜ࠢࠪᇯ")+scraperserver+JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠧࠡ࡟ࠣࠤࠥࡉ࡯ࡥࡧ࠽ࠤࡠࠦࠧᇰ")+str(sjD4xoNlUHban7RZQmL9k3VzSdfT.code)+A6dMB1FlgxVivJ2fk9C(u"ࠨࠢࡠࠤࠥࠦࡒࡦࡣࡶࡳࡳࡀࠠ࡜ࠢࠪᇱ")+sjD4xoNlUHban7RZQmL9k3VzSdfT.reason+SqrG5mU3j96ldsFpExobw40TJY(u"ࠩࠣࡡࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫᇲ")+dUWFtBQ3cpoIZ9+KNIvHPjUbhr(u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩᇳ")+NPM3HKQ57xe+GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠫࠥࡣࠧᇴ"))
		OnsAxhdVjZF(XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠬ็ิๅฬࠣ฽๊๊๊สࠢอะฬ๎าࠡษ็ััฮࠧᇵ"),Hm1TBvbQAz0NwCon,HB5PvxRhwM=sULh4NjakzI8He7xJCMGrql(u"࠷࠶࠲ᓏ"))
	return sjD4xoNlUHban7RZQmL9k3VzSdfT
def CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(QKFp5qOk03PnabuZHR1GC42,fjUoJylTVWh0,S6NALBOqGn1zi2W5M8y7,F49URk16JIawgp7YWZAXGtnMb,UBRzLM6ZdkWOKwy0qPfFIlC,SSKgaJNQBPwlZY,showDialogs,dUWFtBQ3cpoIZ9,vlwhfTp01Md4P5kR3rAD62oSBUbLu7=hWGMqtBy4wuLaVcj,GDP8fawQRqBtUrcA9x4uLCZTMNF6=hWGMqtBy4wuLaVcj):
	NPM3HKQ57xe,pRxdZFXemjq4,OXdrUl5wZ0uKQMS9zpeI3V2Hj,nnmdQ4OqbiAoYDsPHMv = e91ATlnmKdpq(S6NALBOqGn1zi2W5M8y7)
	try: eUpdkPnXjTfJ = UBRzLM6ZdkWOKwy0qPfFIlC.copy()
	except: eUpdkPnXjTfJ = UBRzLM6ZdkWOKwy0qPfFIlC
	YGEAhZgn41MJyBudfqwr6Q = fjUoJylTVWh0,NPM3HKQ57xe,F49URk16JIawgp7YWZAXGtnMb,eUpdkPnXjTfJ,SSKgaJNQBPwlZY
	if QKFp5qOk03PnabuZHR1GC42<wwPrSDa21lUh(u"࠱ᓐ"):
		pMPR1Cc0usZ6nJTU(MM5Dx39f7ULhcJsRptzIowP,HHoGx7Flus60(u"࠭ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔࠩᇶ"),YGEAhZgn41MJyBudfqwr6Q)
		QKFp5qOk03PnabuZHR1GC42 = -QKFp5qOk03PnabuZHR1GC42
	if QKFp5qOk03PnabuZHR1GC42>HHoGx7Flus60(u"࠲ᓑ"):
		BUXsmKe5dGpJj09REb6HqcO7tNv = Mqk51CFBym0pIQXZLsOxSJ(MM5Dx39f7ULhcJsRptzIowP,rwQN9AKhLCuMfHxjlbX0U(u"ࠧࡳࡧࡶࡴࡴࡴࡳࡦࠩᇷ"),mkHKSQvjWr5BTcM3wVY(u"ࠨࡑࡓࡉࡓ࡛ࡒࡍࡡࡕࡉࡖ࡛ࡅࡔࡖࡖࠫᇸ"),YGEAhZgn41MJyBudfqwr6Q)
		if BUXsmKe5dGpJj09REb6HqcO7tNv.succeeded:
			Dv0PbigXyWH4MUCSpE(LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠩࡕࡉࡖ࡛ࡅࡔࡖࡖࠤࠥࡘࡅࡂࡆࡢࡇࡆࡉࡈࡆࠩᇹ"),NPM3HKQ57xe,F49URk16JIawgp7YWZAXGtnMb,UBRzLM6ZdkWOKwy0qPfFIlC,dUWFtBQ3cpoIZ9,fjUoJylTVWh0)
			return BUXsmKe5dGpJj09REb6HqcO7tNv
	BUXsmKe5dGpJj09REb6HqcO7tNv = HaZx1JTW4ELwv(fjUoJylTVWh0,S6NALBOqGn1zi2W5M8y7,F49URk16JIawgp7YWZAXGtnMb,UBRzLM6ZdkWOKwy0qPfFIlC,SSKgaJNQBPwlZY,showDialogs,dUWFtBQ3cpoIZ9,vlwhfTp01Md4P5kR3rAD62oSBUbLu7,GDP8fawQRqBtUrcA9x4uLCZTMNF6)
	if BUXsmKe5dGpJj09REb6HqcO7tNv.succeeded:
		if o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠪࡇࡎࡓࡁࡏࡑ࡚ࠫᇺ") in dUWFtBQ3cpoIZ9: BUXsmKe5dGpJj09REb6HqcO7tNv.content = pq5nlLYxzuaQg(BUXsmKe5dGpJj09REb6HqcO7tNv.content)
		if BUXsmKe5dGpJj09REb6HqcO7tNv.scrape: QKFp5qOk03PnabuZHR1GC42 = DpQifS0oKBI1hYcO
		if QKFp5qOk03PnabuZHR1GC42 and BUXsmKe5dGpJj09REb6HqcO7tNv.content: BxuD7iQRpW1(MM5Dx39f7ULhcJsRptzIowP,ITvnUAMXsyb4eO(u"ࠫࡔࡖࡅࡏࡗࡕࡐࡤࡘࡅࡒࡗࡈࡗ࡙࡙ࠧᇻ"),YGEAhZgn41MJyBudfqwr6Q,BUXsmKe5dGpJj09REb6HqcO7tNv,QKFp5qOk03PnabuZHR1GC42)
	return BUXsmKe5dGpJj09REb6HqcO7tNv
def f1fLNcPlo2ECKtiBeug0OAvz9YM(QKFp5qOk03PnabuZHR1GC42,S6NALBOqGn1zi2W5M8y7,F49URk16JIawgp7YWZAXGtnMb,UBRzLM6ZdkWOKwy0qPfFIlC,showDialogs,dUWFtBQ3cpoIZ9):
	if not F49URk16JIawgp7YWZAXGtnMb or isinstance(F49URk16JIawgp7YWZAXGtnMb,dict): fjUoJylTVWh0 = A6dMB1FlgxVivJ2fk9C(u"ࠬࡍࡅࡕࠩᇼ")
	else:
		fjUoJylTVWh0 = o1u5dij9UrcbXzVS8lwIWfKpnqM(u"࠭ࡐࡐࡕࡗࠫᇽ")
		F49URk16JIawgp7YWZAXGtnMb = jkiCS0UWs2dNAJcGKn6mbHD(F49URk16JIawgp7YWZAXGtnMb)
		F4FsGuwMlKenEzcjA2yUqNLkTab,F49URk16JIawgp7YWZAXGtnMb = fWM9y4vTcPLS0b3UKItC1os5(F49URk16JIawgp7YWZAXGtnMb)
	BUXsmKe5dGpJj09REb6HqcO7tNv = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(QKFp5qOk03PnabuZHR1GC42,fjUoJylTVWh0,S6NALBOqGn1zi2W5M8y7,F49URk16JIawgp7YWZAXGtnMb,UBRzLM6ZdkWOKwy0qPfFIlC,VBlawK4mgHSyLEn8iqhUkz5,showDialogs,dUWFtBQ3cpoIZ9)
	wYZ9hmIlS3cv17s2W = BUXsmKe5dGpJj09REb6HqcO7tNv.content
	wYZ9hmIlS3cv17s2W = str(wYZ9hmIlS3cv17s2W)
	return wYZ9hmIlS3cv17s2W
def e91ATlnmKdpq(S6NALBOqGn1zi2W5M8y7):
	GixY31avF8I = S6NALBOqGn1zi2W5M8y7.split(CnbBKmtF1x84q7AW(u"ࠧࡽࡾࠪᇾ"))
	NPM3HKQ57xe,pRxdZFXemjq4,OXdrUl5wZ0uKQMS9zpeI3V2Hj,nnmdQ4OqbiAoYDsPHMv = GixY31avF8I[ybdv7XcT3lxF6QezULwCAGk],None,None,VBlawK4mgHSyLEn8iqhUkz5
	for YGEAhZgn41MJyBudfqwr6Q in GixY31avF8I:
		if DJ1ICpbyR2(u"ࠨࡏࡼࡔࡷࡵࡸࡺࡗࡵࡰࡂ࠭ᇿ") in YGEAhZgn41MJyBudfqwr6Q: pRxdZFXemjq4 = YGEAhZgn41MJyBudfqwr6Q[A6dMB1FlgxVivJ2fk9C(u"࠴࠵ᓒ"):]
		elif SqrG5mU3j96ldsFpExobw40TJY(u"ࠩࡐࡽࡉࡔࡓࡖࡴ࡯ࡁࠬሀ") in YGEAhZgn41MJyBudfqwr6Q: OXdrUl5wZ0uKQMS9zpeI3V2Hj = YGEAhZgn41MJyBudfqwr6Q[wwPrSDa21lUh(u"࠽ᓓ"):]
		elif SqrG5mU3j96ldsFpExobw40TJY(u"ࠪࡒࡴ࡜ࡥࡳ࡫ࡩࡽࡘ࡙ࡌࠨሁ") in YGEAhZgn41MJyBudfqwr6Q: nnmdQ4OqbiAoYDsPHMv = fEXMiAyG3ql4vKB
	return NPM3HKQ57xe,pRxdZFXemjq4,OXdrUl5wZ0uKQMS9zpeI3V2Hj,nnmdQ4OqbiAoYDsPHMv
def LqXYEK7l02kwIU4eoyNTGiOanv1M(QKFp5qOk03PnabuZHR1GC42,fjUoJylTVWh0,S6NALBOqGn1zi2W5M8y7,tlbo2OAdYeuNUvqWEz1x3armCDRG,A4UgqJauY8y5PbQmixBRLcjhXF6,lN2peIPqVyj1MarDJn5,UBRzLM6ZdkWOKwy0qPfFIlC=hWGMqtBy4wuLaVcj):
	rvEfIlKdgNkmGcSeCw = RRNODILCtGzvgpx(S6NALBOqGn1zi2W5M8y7,S1SgCFYGJeMvfp5iZXK(u"ࠫࡺࡸ࡬ࠨሂ"))
	wSgeWaKIAZb32C = ee8c0jzrTntGSUdRJm.getSetting(A6dMB1FlgxVivJ2fk9C(u"ࠬࡧࡶ࠯ࡪࡲࡷࡹ࠴ࠧሃ")+tlbo2OAdYeuNUvqWEz1x3armCDRG)
	if rvEfIlKdgNkmGcSeCw==wSgeWaKIAZb32C: ee8c0jzrTntGSUdRJm.setSetting(o1u5dij9UrcbXzVS8lwIWfKpnqM(u"࠭ࡡࡷ࠰࡫ࡳࡸࡺ࠮ࠨሄ")+tlbo2OAdYeuNUvqWEz1x3armCDRG,hWGMqtBy4wuLaVcj)
	if wSgeWaKIAZb32C: CMzQFXeI08KDwAJ9p = S6NALBOqGn1zi2W5M8y7.replace(rvEfIlKdgNkmGcSeCw,wSgeWaKIAZb32C)
	else:
		CMzQFXeI08KDwAJ9p = S6NALBOqGn1zi2W5M8y7
		wSgeWaKIAZb32C = rvEfIlKdgNkmGcSeCw
	fp9RhI8SNBmAulVZbk5J1cgto64YU = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(QKFp5qOk03PnabuZHR1GC42,fjUoJylTVWh0,CMzQFXeI08KDwAJ9p,hWGMqtBy4wuLaVcj,UBRzLM6ZdkWOKwy0qPfFIlC,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡉࡒࡓࡌࡒࡅࡠࡐࡈ࡛ࡤࡎࡏࡔࡖࡑࡅࡒࡋ࠭࠲ࡵࡷࠫህ"))
	wYZ9hmIlS3cv17s2W = fp9RhI8SNBmAulVZbk5J1cgto64YU.content
	if H4qZ2hwilNJYTmCFEQyaSs98cPM0gR:
		try: wYZ9hmIlS3cv17s2W = wYZ9hmIlS3cv17s2W.decode(a7VXeDU82IfQEnPZAdiT,NeO3CTLHrPfWUoIgy8Q(u"ࠨ࡫ࡪࡲࡴࡸࡥࠨሆ"))
		except: pass
	if not fp9RhI8SNBmAulVZbk5J1cgto64YU.succeeded or lN2peIPqVyj1MarDJn5 not in wYZ9hmIlS3cv17s2W:
		A4UgqJauY8y5PbQmixBRLcjhXF6 = A4UgqJauY8y5PbQmixBRLcjhXF6.replace(Mpsm2VF1OBnCRvK3qf6,o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠩ࠮ࠫሇ"))
		NPM3HKQ57xe = LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡩࡲࡳ࡬ࡲࡥ࠯ࡥࡲࡱ࠴ࡹࡥࡢࡴࡦ࡬ࡄࡷ࠽ࠨለ")+A4UgqJauY8y5PbQmixBRLcjhXF6
		PwvNmnqXKrYVZugB5c8 = {o1u5dij9UrcbXzVS8lwIWfKpnqM(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨሉ"):hWGMqtBy4wuLaVcj}
		SkMF3ejVQcGAh92BI5Hyg = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(QKFp5qOk03PnabuZHR1GC42,fjUoJylTVWh0,NPM3HKQ57xe,hWGMqtBy4wuLaVcj,PwvNmnqXKrYVZugB5c8,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,KNIvHPjUbhr(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡐࡑࡊࡐࡊࡥࡎࡆ࡙ࡢࡌࡔ࡙ࡔࡏࡃࡐࡉ࠲࠸࡮ࡥࠩሊ"))
		if SkMF3ejVQcGAh92BI5Hyg.succeeded:
			wYZ9hmIlS3cv17s2W = SkMF3ejVQcGAh92BI5Hyg.content
			if H4qZ2hwilNJYTmCFEQyaSs98cPM0gR:
				try: wYZ9hmIlS3cv17s2W = wYZ9hmIlS3cv17s2W.decode(a7VXeDU82IfQEnPZAdiT,KNIvHPjUbhr(u"࠭ࡩࡨࡰࡲࡶࡪ࠭ላ"))
				except: pass
			m4IznKilUOByHweG68VJ = trdVA0JvFaD.findall(rwQN9AKhLCuMfHxjlbX0U(u"ࠧ࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤ࠲ࡠࡼ࠰࡜ࡀ࠰࠭ࡃ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠢࠨሌ"),wYZ9hmIlS3cv17s2W,trdVA0JvFaD.DOTALL)
			QcHIDTVoFNgwRhymvEbqOx69AJLe = [wSgeWaKIAZb32C]
			GT1eO7tSui2sEJDnvZAH = [CnbBKmtF1x84q7AW(u"ࠨࡣࡳ࡯ࠬል"),e2qDYgipPmTw4KvBLnochr(u"ࠩࡪࡳࡴ࡭࡬ࡦࠩሎ"),DJ1ICpbyR2(u"ࠪࡸࡼ࡯ࡴࡵࡧࡵࠫሏ"),rwQN9AKhLCuMfHxjlbX0U(u"ࠫࡾࡵࡵࡵࡷࡥࡩࠬሐ"),NeO3CTLHrPfWUoIgy8Q(u"ࠬ࡬ࡡࡤࡧࡥࡳࡴࡱࠧሑ"),DJ1ICpbyR2(u"࠭ࡰࡩࡲࠪሒ"),QvgnCALNstmuUJiET(u"ࠧࡢࡶ࡯ࡥࡶ࠭ሓ"),ITvnUAMXsyb4eO(u"ࠨࡵ࡬ࡸࡪ࡯࡮ࡥ࡫ࡦࡩࡸ࠭ሔ"),dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠩࡶࡹࡷ࠴࡬ࡺࠩሕ"),NeO3CTLHrPfWUoIgy8Q(u"ࠪࡦࡱࡵࡧࡴࡲࡲࡸࠬሖ"),LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠫ࡮ࡴࡦࡰࡴࡰࡩࡷ࠭ሗ"),SqrG5mU3j96ldsFpExobw40TJY(u"ࠬࡹࡩࡵࡧ࡯࡭ࡰ࡫ࠧመ"),FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"࠭ࡩ࡯ࡵࡷࡥ࡬ࡸࡡ࡮ࠩሙ"),FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠧࡴࡰࡤࡴࡨ࡮ࡡࡵࠩሚ"),S1SgCFYGJeMvfp5iZXK(u"ࠨࡪࡷࡸࡵ࠳ࡥࡲࡷ࡬ࡺࠬማ"),OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠩࡩࡥࡸ࡫࡬ࡱ࡮ࡸࡷࠬሜ")]
			for bWsVM7A1KOYIq2j0k5836Qw in m4IznKilUOByHweG68VJ:
				if any(BoSjXKxz41DcneO9UimClE in bWsVM7A1KOYIq2j0k5836Qw for BoSjXKxz41DcneO9UimClE in GT1eO7tSui2sEJDnvZAH): continue
				wSgeWaKIAZb32C = RRNODILCtGzvgpx(bWsVM7A1KOYIq2j0k5836Qw,LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠪࡹࡷࡲࠧም"))
				if wSgeWaKIAZb32C in QcHIDTVoFNgwRhymvEbqOx69AJLe: continue
				if len(QcHIDTVoFNgwRhymvEbqOx69AJLe)==xcChIL13BpR8WArNt9Pl0So(u"࠾ᓔ"):
					KteLZCbM8W0FqE2OBx1(VRQE4jsXHSfhPWo5DgLwxGk,qhVEWvetzXLOcr1(xjPuFK3EsIZSiobQ5X)+MMizeNH0AKu(u"ࠫࠥࠦࠠࡈࡱࡲ࡫ࡱ࡫ࠠࡥ࡫ࡧࠤࡳࡵࡴࠡࡨ࡬ࡲࡩࠦࡡࠡࡰࡨࡻࠥ࡮࡯ࡴࡶࡱࡥࡲ࡫ࠠࠡࠢࡖ࡭ࡹ࡫࠺ࠡ࡝ࠣࠫሞ")+tlbo2OAdYeuNUvqWEz1x3armCDRG+dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠬࠦ࡝ࠡࠢࡒࡰࡩࡀࠠ࡜ࠢࠪሟ")+rvEfIlKdgNkmGcSeCw+S1SgCFYGJeMvfp5iZXK(u"࠭ࠠ࡞ࠩሠ"))
					ee8c0jzrTntGSUdRJm.setSetting(mkHKSQvjWr5BTcM3wVY(u"ࠧࡢࡸ࠱࡬ࡴࡹࡴ࠯ࠩሡ")+tlbo2OAdYeuNUvqWEz1x3armCDRG,hWGMqtBy4wuLaVcj)
					break
				QcHIDTVoFNgwRhymvEbqOx69AJLe.append(wSgeWaKIAZb32C)
				CMzQFXeI08KDwAJ9p = S6NALBOqGn1zi2W5M8y7.replace(rvEfIlKdgNkmGcSeCw,wSgeWaKIAZb32C)
				fp9RhI8SNBmAulVZbk5J1cgto64YU = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(QKFp5qOk03PnabuZHR1GC42,fjUoJylTVWh0,CMzQFXeI08KDwAJ9p,hWGMqtBy4wuLaVcj,UBRzLM6ZdkWOKwy0qPfFIlC,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡓࡔࡍࡌࡆࡡࡑࡉ࡜ࡥࡈࡐࡕࡗࡒࡆࡓࡅ࠮࠵ࡵࡨࠬሢ"))
				wYZ9hmIlS3cv17s2W = fp9RhI8SNBmAulVZbk5J1cgto64YU.content
				if fp9RhI8SNBmAulVZbk5J1cgto64YU.succeeded and lN2peIPqVyj1MarDJn5 in wYZ9hmIlS3cv17s2W:
					KteLZCbM8W0FqE2OBx1(YYcbiF1UROXlga2,qhVEWvetzXLOcr1(xjPuFK3EsIZSiobQ5X)+zyvJMtBhrw(u"ࠩࠣࠤࠥࡍ࡯ࡰࡩ࡯ࡩࠥ࡬࡯ࡶࡰࡧࠤࡦࠦ࡮ࡦࡹࠣ࡬ࡴࡹࡴ࡯ࡣࡰࡩࠥࠦࠠࡔ࡫ࡷࡩ࠿࡛ࠦࠡࠩሣ")+tlbo2OAdYeuNUvqWEz1x3armCDRG+wwPrSDa21lUh(u"ࠪࠤࡢࠦࠠࠡࡐࡨࡻ࠿࡛ࠦࠡࠩሤ")+wSgeWaKIAZb32C+A6dMB1FlgxVivJ2fk9C(u"ࠫࠥࡣࠠࠡࡑ࡯ࡨ࠿࡛ࠦࠡࠩሥ")+rvEfIlKdgNkmGcSeCw+MMizeNH0AKu(u"ࠬࠦ࡝ࠨሦ"))
					ee8c0jzrTntGSUdRJm.setSetting(JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"࠭ࡡࡷ࠰࡫ࡳࡸࡺ࠮ࠨሧ")+tlbo2OAdYeuNUvqWEz1x3armCDRG,wSgeWaKIAZb32C)
					break
	return wSgeWaKIAZb32C,CMzQFXeI08KDwAJ9p,fp9RhI8SNBmAulVZbk5J1cgto64YU
def J72F0jRI6A(XNBHzrlKD9yW):
	zCxubdqpcyJoGFfW = {
	 NeO3CTLHrPfWUoIgy8Q(u"ࠧࡢࡪࡺࡥࡰ࠭ረ")				:FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠨ็๋ๆ฾ࠦร่๊ส็ࠥะ๊โ์ࠪሩ")
	,hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠩࡤ࡯ࡴࡧ࡭ࠨሪ")				:o1u5dij9UrcbXzVS8lwIWfKpnqM(u"้ࠪํู่ࠡลๆ์ฬ๋ࠠศๆๅำ๏๋ࠧራ")
	,rwQN9AKhLCuMfHxjlbX0U(u"ࠫࡦࡱ࡯ࡢ࡯ࡦࡥࡲ࠭ሬ")				:KNIvHPjUbhr(u"๋่ࠬใ฻ࠣว่๎วๆࠢๆห๊࠭ር")
	,hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"࠭ࡡ࡬ࡹࡤࡱࠬሮ")				:OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠧๆ๊ๅ฽ࠥษใ้ษ่ࠤฬ๊ฬะ์าࠫሯ")
	,HHoGx7Flus60(u"ࠨࡣ࡮ࡻࡦࡳࡴࡶࡤࡨࠫሰ")			:S1SgCFYGJeMvfp5iZXK(u"่ࠩ์็฿ࠠศๅ๋ห๊ࠦส๋๊หࠫሱ")
	,QVDJLRlxNg127jMX(u"ࠪࡥࡱࡧࡲࡢࡤࠪሲ")				:zyvJMtBhrw(u"๊ࠫ๎โฺࠢๆ่ࠥอไฺำหࠫሳ")
	,hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠬࡧ࡬ࡧࡣࡷ࡭ࡲ࡯ࠧሴ")				:XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"࠭ๅ้ไ฼ࠤฬ๊ๅ็สิࠤฬ๊แศู่๎ࠬስ")
	,sULh4NjakzI8He7xJCMGrql(u"ࠧࡢ࡮࡮ࡥࡼࡺࡨࡢࡴࠪሶ")			:GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠨ็๋ๆ฾ࠦโ็ษฬࠤฬ๊ใ้อิࠫሷ")
	,hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠩࡤࡰࡲࡧࡡࡳࡧࡩࠫሸ")				:DJ1ICpbyR2(u"้ࠪํู่ࠡไ้หฮࠦวๅ็฼หึ็ࠧሹ")
	,HHoGx7Flus60(u"ࠫࡦࡲ࡭ࡴࡶࡥࡥࠬሺ")				:EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"๋่ࠬใ฻ࠣห้๋ีุสฬࠫሻ")
	,ITvnUAMXsyb4eO(u"࠭ࡡ࡯࡫ࡰࡩࡿ࡯ࡤࠨሼ")				:zyvJMtBhrw(u"ࠧๆ๊ๅ฽ࠥอๆๆ์ࠣึิ࠭ሽ")
	,FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠨࡣࡵࡥࡧ࡯ࡣࡵࡱࡲࡲࡸ࠭ሾ")			:zyvJMtBhrw(u"่ࠩ์็฿ࠠห๊้ึࠥ฿ัษ์ฬࠫሿ")
	,GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠪࡥࡷࡧࡢࡴࡧࡨࡨࠬቀ")				:e2qDYgipPmTw4KvBLnochr(u"๊ࠫ๎โฺࠢ฼ีอࠦำ๋์าࠫቁ")
	,QVDJLRlxNg127jMX(u"ࠬࡧࡲࡣ࡮࡬ࡳࡳࢀࠧቂ")				:GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"࠭ๅ้ไ฼ࠤ฾ืศࠡๆํ์ุ๋ࠧቃ")
	,QvgnCALNstmuUJiET(u"ࠧࡢࡻ࡯ࡳࡱ࠭ቄ")				:QvgnCALNstmuUJiET(u"ࠨ็๋ๆ฾ࠦร๋ๆ๋่ࠬቅ")
	,mkHKSQvjWr5BTcM3wVY(u"ࠩࡥࡳࡰࡸࡡࠨቆ")				:LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"้ࠪํู่ࠡสๆีฬ࠭ቇ")
	,HHoGx7Flus60(u"ࠫࡧࡸࡳࡵࡧ࡭ࠫቈ")				:MMizeNH0AKu(u"๋่ࠬใ฻ࠣฬึูส๋ฮࠪ቉")
	,e2qDYgipPmTw4KvBLnochr(u"࠭ࡣࡪ࡯ࡤ࠸࠵࠶ࠧቊ")				:CnbBKmtF1x84q7AW(u"ࠧๆ๊ๅ฽ู๊ࠥๆษࠣ࠸࠵࠶ࠧቋ")
	,o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠨࡥ࡬ࡱࡦ࠺ࡰࠨቌ")				:mkHKSQvjWr5BTcM3wVY(u"่ࠩ์็฿ࠠิ์่หࠥ็่าࠢห๎ࠬቍ")
	,jeAby54c02TgG8zuivonX91(u"ࠪࡧ࡮ࡳࡡ࠵ࡷࠪ቎")				:A6dMB1FlgxVivJ2fk9C(u"๊ࠫ๎โฺࠢึ๎๊อࠠโ๊ิ๎ํ࠭቏")
	,OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠬࡩࡩ࡮ࡣࡤࡦࡩࡵࠧቐ")				:GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"࠭ๅ้ไ฼ࠤุ๐ๅศࠢ฼ฬิ๎ࠧቑ")
	,GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠧࡤ࡫ࡰࡥࡨࡲࡵࡣࠩቒ")				:o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠨ็๋ๆ฾ࠦำ๋็สࠤ่๊่ษࠩቓ")
	,EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠩࡦ࡭ࡲࡧࡣ࡭ࡷࡥࡻࡴࡸ࡫ࠨቔ")			:o1u5dij9UrcbXzVS8lwIWfKpnqM(u"้ࠪํู่ࠡีํ้ฬࠦใๅ๊หࠤ฾๋ไࠨቕ")
	,CnbBKmtF1x84q7AW(u"ࠫࡨ࡯࡭ࡢࡥ࡯ࡹࡵ࠭ቖ")				:e2qDYgipPmTw4KvBLnochr(u"๋่ࠬใ฻ࠣื๏๋วࠡๅ็์อ࠭቗")
	,GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"࠭ࡣࡪ࡯ࡤࡪࡦࡴࡳࠨቘ")				:LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠧๆ๊ๅ฽ู๊ࠥๆษࠣๅฬ์าࠨ቙")
	,SqrG5mU3j96ldsFpExobw40TJY(u"ࠨࡥ࡬ࡱࡦ࡬ࡲࡦࡧࠪቚ")				:xcChIL13BpR8WArNt9Pl0So(u"่ࠩ์็฿ࠠิ์่หࠥ็ั๋ࠩቛ")
	,KNIvHPjUbhr(u"ࠪࡧ࡮ࡳࡡ࡭࡫ࡪ࡬ࡹ࠭ቜ")			:KNIvHPjUbhr(u"๊ࠫ๎โฺࠢึ๎๊อࠠๅษํฮࠬቝ")
	,MMizeNH0AKu(u"ࠬࡩࡩ࡮ࡣࡱࡳࡼ࠭቞")				:gDuGMR3z1aV6YdLmCpiO8Kl(u"࠭ๅ้ไ฼ࠤุ๐ๅศ้ࠢหํ࠭቟")
	,o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠧࡤ࡫ࡰࡥࡼࡨࡡࡴࠩበ")				:jeAby54c02TgG8zuivonX91(u"ࠨ็๋ๆ฾ࠦำ๋็สࠤํฮำࠨቡ")
	,OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠩࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴࠧቢ")			:dv0trJR7PwmKyxDYO52VLau8gEph(u"้ࠪํู่ࠡัส๎้๐ࠠๆ๊ื๊ࠬባ")
	,QVDJLRlxNg127jMX(u"ࠫࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯࠯ࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫቤ")	:S1SgCFYGJeMvfp5iZXK(u"๋่ࠬใ฻ࠣำฬ๐ไ๋่ࠢ์ู์ࠠๆีอาิ๋๊็ࠩብ")
	,hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"࠭ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱ࠱࡭ࡧࡳࡩࡶࡤ࡫ࡸ࠭ቦ")	:MMizeNH0AKu(u"ࠧๆ๊ๅ฽ࠥีว๋ๆํࠤ๊๎ิ็๊ࠢหูะวไࠩቧ")
	,HHoGx7Flus60(u"ࠨࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠳࡬ࡪࡸࡨࡷࠬቨ")	:SqrG5mU3j96ldsFpExobw40TJY(u"่ࠩ์็฿ࠠะษํ่๏ࠦๅ้ึ้ࠤ๊ฮวีำࠪቩ")
	,EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠪࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮࠮ࡲ࡯ࡥࡾࡲࡩࡴࡶࡶࠫቪ"):A6dMB1FlgxVivJ2fk9C(u"๊ࠫ๎โฺࠢาห๏๊๊ࠡ็ุ๋๋ࠦโ้ษษ้ࠬቫ")
	,mkHKSQvjWr5BTcM3wVY(u"ࠬࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰ࠰ࡸࡴࡶࡩࡤࡵࠪቬ")	:FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"࠭ๅ้ไ฼ࠤิอ๊ๅ์้ࠣํฺๆࠡ็๋ห฻๐ูࠨቭ")
	,LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠧࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲ࠲ࡼࡩࡥࡧࡲࡷࠬቮ")	:sULh4NjakzI8He7xJCMGrql(u"ࠨ็๋ๆ฾ࠦฯศ์็๎๋่ࠥี่ࠣๅ๏ี๊้้สฮࠬቯ")
	,QvgnCALNstmuUJiET(u"ࠩࡧ࡭ࡸࡧࡢ࡭ࡧࡧࠫተ")				:LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"้ࠪฯ๎โโࠩቱ")
	,sULh4NjakzI8He7xJCMGrql(u"ࠫࡩࡸࡡ࡮ࡣࡦࡥ࡫࡫ࠧቲ")			:GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"๋่ࠬใ฻ࠣำึอๅศࠢๆหๆ๐็ࠨታ")
	,mkHKSQvjWr5BTcM3wVY(u"࠭ࡤࡳࡣࡰࡥࡸ࠽ࠧቴ")				:CnbBKmtF1x84q7AW(u"ࠧๆ๊ๅ฽ࠥีัศ็สࠤฺำࠧት")
	,DJ1ICpbyR2(u"ࠨࡧࡪࡽࡧ࡫ࡳࡵࠩቶ")				:dv0trJR7PwmKyxDYO52VLau8gEph(u"่ࠩ์็฿ࠠศ์ฯ๎ࠥฮ๊ิฬࠪቷ")
	,XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠪࡩ࡬ࡿࡢࡦࡵࡷ࠵ࠬቸ")				:sULh4NjakzI8He7xJCMGrql(u"๊ࠫ๎โฺࠢส๎ั๐ࠠษ์ึฮࠥ࠷ࠧቹ")
	,HHoGx7Flus60(u"ࠬ࡫ࡧࡺࡤࡨࡷࡹ࠸ࠧቺ")				:KNIvHPjUbhr(u"࠭ๅ้ไ฼ࠤฬ๐ฬ๋ࠢห๎ุะࠠ࠳ࠩቻ")
	,DJ1ICpbyR2(u"ࠧࡦࡩࡼࡦࡪࡹࡴ࠴ࠩቼ")				:LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠨ็๋ๆ฾ࠦว๋ฮํࠤอ๐ำหࠢ࠶ࠫች")
	,KBkxSYaz93pu1(u"ࠩࡨ࡫ࡾࡨࡥࡴࡶ࠷ࠫቾ")				:dv0trJR7PwmKyxDYO52VLau8gEph(u"้ࠪํู่ࠡษํะ๏ࠦศ๋ีอࠤ࠹࠭ቿ")
	,LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠫࡪ࡭ࡹࡣࡧࡶࡸࡻ࡯ࡰࠨኀ")			:SqrG5mU3j96ldsFpExobw40TJY(u"๋่ࠬใ฻ࠣห๏า๊ࠡสํืฯࠦࡶࡪࡲࠪኁ")
	,wwPrSDa21lUh(u"࠭ࡥࡨࡻࡧࡩࡦࡪࠧኂ")				:FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠧๆ๊ๅ฽ࠥห๊อ์ࠣำ๏ีࠧኃ")
	,o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠨࡧࡪࡽࡳࡵࡷࠨኄ")				:MMizeNH0AKu(u"่ࠩ์็฿ࠠฦ์ฯ๎ࠥ์ว้ࠩኅ")
	,JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠪࡩࡱࡩࡩ࡯ࡧࡰࡥࠬኆ")				:o1u5dij9UrcbXzVS8lwIWfKpnqM(u"๊ࠫ๎โฺ่ࠢ์ุ๎ูสࠢสุ่๐ๆๆษࠪኇ")
	,CnbBKmtF1x84q7AW(u"ࠬ࡫࡬ࡪࡨࡹ࡭ࡩ࡫࡯ࠨኈ")			:LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"࠭ๅ้ไ฼ࠤศ๊๊โࠢไ๎ิ๐่ࠨ኉")
	,OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠧࡧࡣࡥࡶࡦࡱࡡࠨኊ")				:DJ1ICpbyR2(u"ࠨ็๋ๆ฾ࠦแษำๆอࠬኋ")
	,XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠩࡩࡥ࡮ࡲࡥࡥࠩኌ")				:JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠪๅู๊ࠧኍ")
	,NeO3CTLHrPfWUoIgy8Q(u"ࠫ࡫ࡧࡪࡦࡴࡶ࡬ࡴࡽࠧ኎")			:e2qDYgipPmTw4KvBLnochr(u"๋่ࠬใ฻ࠣๅัืࠠี๊ࠪ኏")
	,S1SgCFYGJeMvfp5iZXK(u"࠭ࡦࡢࡴࡨࡷࡰࡵࠧነ")				:xcChIL13BpR8WArNt9Pl0So(u"ࠧๆ๊ๅ฽ࠥ็วา์ึ็ํ࠭ኑ")
	,FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠨࡨࡤࡷࡪࡲࡨࡥ࠳ࠪኒ")				:OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"่ࠩ์็฿ࠠโษุ่ࠥอไฤ๊็ࠫና")
	,ITvnUAMXsyb4eO(u"ࠪࡪࡦࡹࡥ࡭ࡪࡧ࠶ࠬኔ")				:CnbBKmtF1x84q7AW(u"๊ࠫ๎โฺࠢไหฺ๊ࠠศๆฮห๋๐ࠧን")
	,gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬኖ")				:CnbBKmtF1x84q7AW(u"࠭ๅอๆาࠫኗ")
	,sULh4NjakzI8He7xJCMGrql(u"ࠧࡧࡱࡶࡸࡦ࠭ኘ")				:LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠨ็๋ๆ฾ࠦแ้ีอหࠬኙ")
	,QvgnCALNstmuUJiET(u"ࠩࡩࡹࡳࡵ࡮ࡵࡸࠪኚ")				:mkHKSQvjWr5BTcM3wVY(u"้ࠪํู่ࠡใ้์๋ࠦส๋ใํࠫኛ")
	,A6dMB1FlgxVivJ2fk9C(u"ࠫ࡫ࡻࡳࡩࡣࡵࡸࡻ࠭ኜ")				:hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"๋่ࠬใ฻ࠣๅํฺวาࠢอ๎ๆ๐ࠧኝ")
	,zyvJMtBhrw(u"࠭ࡦࡶࡵ࡫ࡥࡷࡼࡩࡥࡧࡲࠫኞ")			:EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠧๆ๊ๅ฽ࠥ็่ีษิࠤๆ๐ฯ๋๊ࠪኟ")
	,zyvJMtBhrw(u"ࠨࡩࡲࡳࡩ࠭አ")					:CnbBKmtF1x84q7AW(u"ࠩฯ๎ิ࠭ኡ")
	,zyvJMtBhrw(u"ࠪ࡬ࡦࡲࡡࡤ࡫ࡰࡥࠬኢ")				:FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"๊ࠫ๎โฺ๊่ࠢฬࠦำ๋็สࠫኣ")
	,KNIvHPjUbhr(u"ࠬ࡮ࡥ࡭ࡣ࡯ࠫኤ")				:HHoGx7Flus60(u"࠭ๅ้ไ฼ࠤ์๊วๅࠢํ์ฯ๐่ษࠩእ")
	,CnbBKmtF1x84q7AW(u"ࠧࡪࡨ࡬ࡰࡲ࠭ኦ")				:EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠨ็๋ๆ฾ࠦโ็ษฬࠤว๐ࠠโ์็้ࠬኧ")
	,MMizeNH0AKu(u"ࠩ࡬ࡪ࡮ࡲ࡭࠮ࡣࡵࡥࡧ࡯ࡣࠨከ")			:LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"้ࠪํู่ࠡไ้หฮࠦย๋ࠢไ๎ฺ้๋ࠠำห๎ࠬኩ")
	,HHoGx7Flus60(u"ࠫ࡮࡬ࡩ࡭࡯࠰ࡩࡳ࡭࡬ࡪࡵ࡫ࠫኪ")		:EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"๋่ࠬใ฻ࠣๆ๋อษࠡฤํࠤๆ๐ไๆࠢส๊ั๊๊ำ์ࠪካ")
	,rwQN9AKhLCuMfHxjlbX0U(u"࠭ࡩࡱࡶࡹࠫኬ")					:CnbBKmtF1x84q7AW(u"ࠧࡊࡒࡗ࡚ࠬክ")
	,dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠨ࡫ࡳࡸࡻ࠳࡬ࡪࡸࡨࠫኮ")			:LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠩࡌࡔ࡙࡜ࠠใ่๋หฯ࠭ኯ")
	,rwQN9AKhLCuMfHxjlbX0U(u"ࠪ࡭ࡵࡺࡶ࠮࡯ࡲࡺ࡮࡫ࡳࠨኰ")			:S1SgCFYGJeMvfp5iZXK(u"ࠫࡎࡖࡔࡗࠢฦๅ้อๅࠨ኱")
	,GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠬ࡯ࡰࡵࡸ࠰ࡷࡪࡸࡩࡦࡵࠪኲ")			:SqrG5mU3j96ldsFpExobw40TJY(u"࠭ࡉࡑࡖ࡙ࠤู๊ไิๆสฮࠬኳ")
	,CnbBKmtF1x84q7AW(u"ࠧ࡬ࡣࡵࡦࡦࡲࡡࡵࡸࠪኴ")			:KBkxSYaz93pu1(u"ࠨ็๋ๆ฾ࠦโ็ษฬࠤ่ืศๅษฤࠫኵ")
	,jeAby54c02TgG8zuivonX91(u"ࠩ࡮ࡥࡹࡱ࡯ࡵࡶࡹࠫ኶")				:GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"้ࠪํู่ࠡๅอ็ํะࠠห์ไ๎ࠬ኷")
	,S1SgCFYGJeMvfp5iZXK(u"ࠫࡰࡧࡴ࡬ࡱࡸࡸࡪ࠭ኸ")				:KBkxSYaz93pu1(u"๋่ࠬใ฻ࠣ็ฯ้่หࠩኹ")
	,QvgnCALNstmuUJiET(u"࠭࡫ࡪࡴࡰࡥࡱࡱࠧኺ")				:e2qDYgipPmTw4KvBLnochr(u"ࠧๆ๊ๅ฽้ࠥัๆษ็็ࠬኻ")
	,DJ1ICpbyR2(u"ࠨ࡮ࡤࡶࡴࢀࡡࠨኼ")				:o1u5dij9UrcbXzVS8lwIWfKpnqM(u"่ࠩ์็฿ࠠๅษิ์ือࠧኽ")
	,rwQN9AKhLCuMfHxjlbX0U(u"ࠪࡰ࡮ࡨࡲࡢࡴࡼࠫኾ")				:sULh4NjakzI8He7xJCMGrql(u"๊๊ࠫแࠨ኿")
	,mkHKSQvjWr5BTcM3wVY(u"ࠬࡲࡩࡷࡧࠪዀ")					:FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"࠭โ็ษฬࠫ዁")
	,KNIvHPjUbhr(u"ࠧ࡭࡫ࡹࡩࡹࡼࠧዂ")				:o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠨ็็ๅࠬዃ")
	,LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠩ࡯ࡳࡩࡿ࡮ࡦࡶࠪዄ")				:GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"้ࠪํู่ࠡๆ๋ำ๏ࠦๆหࠩዅ")
	,ITvnUAMXsyb4eO(u"ࠫࡲ࠹ࡵࠨ዆")					:DJ1ICpbyR2(u"ࠬࡓ࠳ࡖࠩ዇")
	,NeO3CTLHrPfWUoIgy8Q(u"࠭࡭࠴ࡷ࠰ࡰ࡮ࡼࡥࠨወ")				:QvgnCALNstmuUJiET(u"ࠧࡎ࠵ࡘࠤ็์่ศฬࠪዉ")
	,KBkxSYaz93pu1(u"ࠨ࡯࠶ࡹ࠲ࡳ࡯ࡷ࡫ࡨࡷࠬዊ")			:DJ1ICpbyR2(u"ࠩࡐ࠷࡚ࠦรโๆส้ࠬዋ")
	,A6dMB1FlgxVivJ2fk9C(u"ࠪࡱ࠸ࡻ࠭ࡴࡧࡵ࡭ࡪࡹࠧዌ")			:NeO3CTLHrPfWUoIgy8Q(u"ࠫࡒ࠹ࡕࠡ็ึุ่๊วหࠩው")
	,jeAby54c02TgG8zuivonX91(u"ࠬࡳࡡࡴࡣࡹ࡭ࡩ࡫࡯ࠨዎ")			:rwQN9AKhLCuMfHxjlbX0U(u"࠭ๅ้ไ฼ࠤ๊อำศࠢไ๎ิ๐่ࠨዏ")
	,rwQN9AKhLCuMfHxjlbX0U(u"ࠧ࡮࡫ࡶࡷ࡮ࡴࡧࠨዐ")				:hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠨ็ไๆํีࠧዑ")
	,FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠩࡰࡳࡻࡹ࠴ࡶࠩዒ")				:EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"้ࠪํู่ࠡ็๋ๅืࠦแ้ำํ์ࠬዓ")
	,KBkxSYaz93pu1(u"ࠫࡲࡿࡣࡪ࡯ࡤࠫዔ")				:hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"๋่ࠬใ฻้ࠣฬ๐ࠠิ์่หࠬዕ")
	,rwQN9AKhLCuMfHxjlbX0U(u"࠭࡯࡭ࡦࠪዖ")					:mkHKSQvjWr5BTcM3wVY(u"ࠧใัํ้ࠬ዗")
	,XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠨࡲࡤࡲࡪࡺࠧዘ")				:HHoGx7Flus60(u"่ࠩ์็฿ࠠษษ้๎ฯ࠭ዙ")
	,XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠪࡴࡦࡴࡥࡵ࠯ࡰࡳࡻ࡯ࡥࡴࠩዚ")			:CnbBKmtF1x84q7AW(u"๊ࠫ๎โฺࠢหห๋๐สࠡษไ่ฬ๋ࠧዛ")
	,LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠬࡶࡡ࡯ࡧࡷ࠱ࡸ࡫ࡲࡪࡧࡶࠫዜ")			:NeO3CTLHrPfWUoIgy8Q(u"࠭ๅ้ไ฼ࠤออๆ๋ฬุ้๊ࠣำๅษอࠫዝ")
	,DJ1ICpbyR2(u"ࠧࡲࡨ࡬ࡰࡲ࠭ዞ")				:QvgnCALNstmuUJiET(u"ࠨ็๋ๆ฾ࠦใ๋๊ࠣๅ๏๊ๅࠨዟ")
	,SqrG5mU3j96ldsFpExobw40TJY(u"ࠩࡶࡩࡷ࡯ࡥࡴࡶ࡬ࡱࡪ࠭ዠ")			:gDuGMR3z1aV6YdLmCpiO8Kl(u"้ࠪํู่ࠡีํี๏ูࠠหษํ้ࠬዡ")
	,EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠫࡸ࡮ࡡࡣࡣ࡮ࡥࡹࡿࠧዢ")			:NeO3CTLHrPfWUoIgy8Q(u"๋่ࠬใ฻ุࠣอ้ส๋ࠩዣ")
	,QvgnCALNstmuUJiET(u"࠭ࡳࡩࡣ࡫࡭ࡩ࠺ࡵࠨዤ")				:sULh4NjakzI8He7xJCMGrql(u"ࠧๆ๊ๅ฽ฺࠥว่ัࠣๅํื๊้ࠩዥ")
	,hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠨࡵ࡫ࡥ࡭࡯ࡤ࡯ࡧࡺࡷࠬዦ")			:EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"่ࠩ์็฿ࠠีษ๊ำࠥ์๊้ิࠪዧ")
	,S1SgCFYGJeMvfp5iZXK(u"ࠪࡷ࡭࡯ࡡࡷࡱ࡬ࡧࡪ࠭የ")			:rwQN9AKhLCuMfHxjlbX0U(u"๊ࠫ๎โฺุࠢ์ฯࠦวๅึํ฽ฮ࠭ዩ")
	,EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠬࡹࡨࡪࡣࡹࡳ࡮ࡩࡥ࠮ࡣ࡯ࡦࡺࡳࡳࠨዪ")		:mkHKSQvjWr5BTcM3wVY(u"࠭ๅ้ไ฼ࠤฺ๎สࠡษ็ุ๏฿ษࠡษ็ฬํ๋ࠧያ")
	,zyvJMtBhrw(u"ࠧࡴࡪ࡬ࡥࡻࡵࡩࡤࡧ࠰ࡥࡺࡪࡩࡰࡵࠪዬ")		:xcChIL13BpR8WArNt9Pl0So(u"ࠨ็๋ๆ฾ࠦี้ฬࠣหฺฺ้๊หูࠣํะ๊ศฬࠪይ")
	,XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠩࡶ࡬࡮ࡧࡶࡰ࡫ࡦࡩ࠲ࡶࡥࡳࡵࡲࡲࡸ࠭ዮ")	:xcChIL13BpR8WArNt9Pl0So(u"้ࠪํู่ࠡื๋ฮࠥอไี์฼อ่ࠥวาศࠪዯ")
	,QvgnCALNstmuUJiET(u"ࠫࡸ࡮࡯ࡧࡪࡤࠫደ")				:rwQN9AKhLCuMfHxjlbX0U(u"๋่ࠬใ฻ุࠣํ็็ศࠢอ๎ๆ๐ࠧዱ")
	,sULh4NjakzI8He7xJCMGrql(u"࠭ࡳࡩࡱࡲࡪࡲࡧࡸࠨዲ")				:JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠧๆ๊ๅ฽ฺ่ࠥโ่ࠢหู่ࠧዳ")
	,OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠨࡵ࡫ࡳࡴ࡬࡮ࡦࡶࠪዴ")				:xcChIL13BpR8WArNt9Pl0So(u"่ࠩ์็฿ࠠี๊ไࠤ๋ะࠧድ")
	,mkHKSQvjWr5BTcM3wVY(u"ࠪࡷ࡭ࡵ࡯ࡧࡲࡵࡳࠬዶ")				:OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"๊ࠫ๎โฺࠢื์ๆࠦศา๊ࠪዷ")
	,A6dMB1FlgxVivJ2fk9C(u"ࠬࡺࡩ࡬ࡣࡤࡸࠬዸ")				:hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"࠭ๅ้ไ฼ࠤฯ้วหࠩዹ")
	,FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠧࡵࡸࡩࡹࡳ࠭ዺ")				:NeO3CTLHrPfWUoIgy8Q(u"ࠨ็๋ๆ฾ࠦส๋ใํࠤๆอๆࠨዻ")
	,DJ1ICpbyR2(u"ࠩࡹࡥࡷࡨ࡯࡯ࠩዼ")				:LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"้ࠪํู่ࠡใสีอ๎ๆࠨዽ")
	,jeAby54c02TgG8zuivonX91(u"ࠫࡻ࡯ࡤࡦࡱࠪዾ")				:KNIvHPjUbhr(u"ࠬ็๊ะ์๋ࠫዿ")
	,GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"࠭ࡶࡪࡦࡨࡳࡳࡹࡡࡦ࡯ࠪጀ")			:rwQN9AKhLCuMfHxjlbX0U(u"ࠧๆ๊ๅ฽ࠥ็๊ะ์๋ࠤู๋วว็ࠪጁ")
	,LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠨࡹࡨࡧ࡮ࡳࡡ࠲ࠩጂ")				:DJ1ICpbyR2(u"่ࠩ์็฿้ࠠ์ࠣื๏๋วࠡ࠳ࠪጃ")
	,rwQN9AKhLCuMfHxjlbX0U(u"ࠪࡻࡪࡩࡩ࡮ࡣ࠵ࠫጄ")				:MMizeNH0AKu(u"๊ࠫ๎โฺ๋ࠢ๎ู๊ࠥๆษࠣ࠶ࠬጅ")
	,QvgnCALNstmuUJiET(u"ࠬࡿࡡࡲࡱࡷࠫጆ")				:QvgnCALNstmuUJiET(u"࠭ๅ้ไ฼ࠤ๏อโ้ฬࠪጇ")
	,e2qDYgipPmTw4KvBLnochr(u"ࠧࡺࡱࡸࡸࡺࡨࡥࠨገ")				:KNIvHPjUbhr(u"ࠨ็๋ๆ฾๊้ࠦฬํ์อ࠭ጉ")
	,SqrG5mU3j96ldsFpExobw40TJY(u"ࠩࡼࡳࡺࡺࡵࡣࡧ࠰ࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬጊ")		:FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"้ࠪํู่ࠡ์๋ฮ๏๎ศࠡไ้์ฬะࠧጋ")
	,xcChIL13BpR8WArNt9Pl0So(u"ࠫࡾࡵࡵࡵࡷࡥࡩ࠲ࡶ࡬ࡢࡻ࡯࡭ࡸࡺࡳࠨጌ")	:hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"๋่ࠬใ฻ࠣ๎ํะ๊้สࠣๆํอฦๆࠩግ")
	,MMizeNH0AKu(u"࠭ࡹࡰࡷࡷࡹࡧ࡫࠭ࡷ࡫ࡧࡩࡴࡹࠧጎ")		:hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠧๆ๊ๅ฽ࠥ๐่ห์๋ฬࠥ็๊ะ์๋๋ฬะࠧጏ")
	,mkHKSQvjWr5BTcM3wVY(u"ࠨࡻࡷࡦࡤࡩࡨࡢࡰࡱࡩࡱࡹࠧጐ")			:mkHKSQvjWr5BTcM3wVY(u"่ࠩ์ฬู่ࠡ็้ࠤ๏๎ส๋๊หࠫ጑")
	}
	C7CRkZtJeojn1mzbSP8Lw6FWA = XNBHzrlKD9yW.lower()
	for key in list(zCxubdqpcyJoGFfW.keys()):
		SawolmXJIDrtB6qzOf0UEyYc58QA = key.lower()
		if C7CRkZtJeojn1mzbSP8Lw6FWA==SawolmXJIDrtB6qzOf0UEyYc58QA:
			XNBHzrlKD9yW = zCxubdqpcyJoGFfW[key]
			break
	return XNBHzrlKD9yW
def Za2Eugh8Mp1eQYH4():
	ayNEJoZrebx2usT = MMk8qKvcJe4fQHm3EG7diBD5.executeJSONRPC(EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢࡪࡦࠥ࠾࠶࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡓࡰࡦࡿ࡬ࡪࡵࡷ࠲ࡈࡲࡥࡢࡴࠥ࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡲ࡯ࡥࡾࡲࡩࡴࡶ࡬ࡨࠧࡀ࠱ࡾࡿࠪጒ"))
	raise ValueError(LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠫࡤࡥ࡟ࡇࡑࡕࡇࡊࡥࡅ࡙ࡋࡗࡣࡤࡥࠧጓ"))
def CfKNTtIi3OABbWcPpdF(T2XjRMvDHB8wgyczq4kIWxUh36Adu0,fubPOkz0EgDXBGh6=hWGMqtBy4wuLaVcj):
	global hlxkBcuTP3dfMLs8t
	hlxkBcuTP3dfMLs8t = VBlawK4mgHSyLEn8iqhUkz5
	if not fubPOkz0EgDXBGh6 and T2XjRMvDHB8wgyczq4kIWxUh36Adu0: fubPOkz0EgDXBGh6 = xcChIL13BpR8WArNt9Pl0So(u"ࠬࡘࡅࡒࡗࡈࡗ࡙ࡥࡒࡆࡈࡕࡉࡘࡎ࡟ࡄࡃࡆࡌࡊ࠭ጔ")
	ee8c0jzrTntGSUdRJm.setSetting(LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡵࡩ࡫ࡸࡥࡴࡪࠪጕ"),fubPOkz0EgDXBGh6)
	return
def e1mT8H4dGS3XFyx0KLUA9(S6NALBOqGn1zi2W5M8y7,lpHRwe4tGqVrfSNnvsOA8BX=xcChIL13BpR8WArNt9Pl0So(u"ࠧ࠻࠱ࠪ጖")):
	return _drLhef4VZ3xMkj2(S6NALBOqGn1zi2W5M8y7,lpHRwe4tGqVrfSNnvsOA8BX)
def MV3ixj8y50t9HqkuwaPG(KpAUxnTMcZ):
	if KpAUxnTMcZ in [hWGMqtBy4wuLaVcj,hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠨ࠲ࠪ጗"),ybdv7XcT3lxF6QezULwCAGk]: return hWGMqtBy4wuLaVcj
	KpAUxnTMcZ = int(KpAUxnTMcZ)
	ZZuMOK7TRk = KpAUxnTMcZ^DpQifS0oKBI1hYcO
	h7BHN5dnWeq1ZfrUm4JtCVuR3Tc0 = KpAUxnTMcZ^KqO5BWGQR9JVL
	U92x5I4nRbfVXyaHqcv8G = KpAUxnTMcZ^nHBb7jXk0Daom
	DTloYF7kyQXrR = str(ZZuMOK7TRk)+str(h7BHN5dnWeq1ZfrUm4JtCVuR3Tc0)+str(U92x5I4nRbfVXyaHqcv8G)
	return DTloYF7kyQXrR
def n8GPqp6VdJyiTYlHsZIRErwuLN4jQ(KpAUxnTMcZ):
	if KpAUxnTMcZ in [hWGMqtBy4wuLaVcj,SqrG5mU3j96ldsFpExobw40TJY(u"ࠩ࠳ࠫጘ"),ybdv7XcT3lxF6QezULwCAGk]: return hWGMqtBy4wuLaVcj
	KpAUxnTMcZ = str(KpAUxnTMcZ)
	DTloYF7kyQXrR = hWGMqtBy4wuLaVcj
	if len(KpAUxnTMcZ)==XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"࠷࠵ᓕ"):
		ZZuMOK7TRk,h7BHN5dnWeq1ZfrUm4JtCVuR3Tc0,U92x5I4nRbfVXyaHqcv8G = KpAUxnTMcZ[ybdv7XcT3lxF6QezULwCAGk:jR6BYWNFZ0egmH4Tr2Q78LbSs3t],KpAUxnTMcZ[jR6BYWNFZ0egmH4Tr2Q78LbSs3t:SqrG5mU3j96ldsFpExobw40TJY(u"࠹ᓖ")],KpAUxnTMcZ[SqrG5mU3j96ldsFpExobw40TJY(u"࠹ᓖ"):]
		ZZuMOK7TRk = int(ZZuMOK7TRk)^nHBb7jXk0Daom
		h7BHN5dnWeq1ZfrUm4JtCVuR3Tc0 = int(h7BHN5dnWeq1ZfrUm4JtCVuR3Tc0)^KqO5BWGQR9JVL
		U92x5I4nRbfVXyaHqcv8G = int(U92x5I4nRbfVXyaHqcv8G)^DpQifS0oKBI1hYcO
		if ZZuMOK7TRk==h7BHN5dnWeq1ZfrUm4JtCVuR3Tc0==U92x5I4nRbfVXyaHqcv8G: DTloYF7kyQXrR = str(ZZuMOK7TRk*hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"࠷࠲ᓗ"))
	return DTloYF7kyQXrR
def smVarGBSwFI219cP(KpAUxnTMcZ,AuP4tsGC31piSTh=dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠪ࠺࠸࠾࠴࠲࠺࠵࠷ࠬጙ")):
	if KpAUxnTMcZ==hWGMqtBy4wuLaVcj: return hWGMqtBy4wuLaVcj
	KpAUxnTMcZ = int(KpAUxnTMcZ)+int(AuP4tsGC31piSTh)
	ZZuMOK7TRk = KpAUxnTMcZ^DpQifS0oKBI1hYcO
	h7BHN5dnWeq1ZfrUm4JtCVuR3Tc0 = KpAUxnTMcZ^KqO5BWGQR9JVL
	U92x5I4nRbfVXyaHqcv8G = KpAUxnTMcZ^nHBb7jXk0Daom
	DTloYF7kyQXrR = str(ZZuMOK7TRk)+str(h7BHN5dnWeq1ZfrUm4JtCVuR3Tc0)+str(U92x5I4nRbfVXyaHqcv8G)
	return DTloYF7kyQXrR
def ssYJQiWrZIRqkMe(KpAUxnTMcZ,AuP4tsGC31piSTh=GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠫ࠻࠹࠸࠵࠳࠻࠶࠸࠭ጚ")):
	if KpAUxnTMcZ==hWGMqtBy4wuLaVcj: return hWGMqtBy4wuLaVcj
	KpAUxnTMcZ = str(KpAUxnTMcZ)
	dKjvLaWQAuyB = int(len(KpAUxnTMcZ)/x1x9kIQo3zjZWnYaiy)
	ZZuMOK7TRk = int(KpAUxnTMcZ[ybdv7XcT3lxF6QezULwCAGk:dKjvLaWQAuyB])^DpQifS0oKBI1hYcO
	h7BHN5dnWeq1ZfrUm4JtCVuR3Tc0 = int(KpAUxnTMcZ[dKjvLaWQAuyB:Y0XZKGRAUQj5O*dKjvLaWQAuyB])^KqO5BWGQR9JVL
	U92x5I4nRbfVXyaHqcv8G = int(KpAUxnTMcZ[Y0XZKGRAUQj5O*dKjvLaWQAuyB:x1x9kIQo3zjZWnYaiy*dKjvLaWQAuyB])^nHBb7jXk0Daom
	DTloYF7kyQXrR = hWGMqtBy4wuLaVcj
	if ZZuMOK7TRk==h7BHN5dnWeq1ZfrUm4JtCVuR3Tc0==U92x5I4nRbfVXyaHqcv8G: DTloYF7kyQXrR = str(int(ZZuMOK7TRk)-int(AuP4tsGC31piSTh))
	return DTloYF7kyQXrR
def pZnPfYmUrWk6(iyEphnMXfCWGa):
	LLYixnfMkqIQmhJAslz = u6rbxnyjTl7I[sULh4NjakzI8He7xJCMGrql(u"ࠬࡖ࡙ࡕࡊࡒࡒࠬጛ")][gDuGMR3z1aV6YdLmCpiO8Kl(u"࠺ᓘ")]
	w9eY6BpgAvy3onRk7S4QZ = WQvYkNg7SysPFLitlGEn6.path.join(ggKyfILOkNPGxMtDQueVSZ,JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"࠭ࡲࡦࡵࡲࡹࡷࡩࡥࡴࠩጜ"),JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠧࡴ࡭࡬ࡲࡸ࠭ጝ"),gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠨࡆࡨࡪࡦࡻ࡬ࡵࠩጞ"),FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠩ࠺࠶࠵ࡶࠧጟ"),zyvJMtBhrw(u"ࠪࡈ࡮ࡧ࡬ࡰࡩࡆࡳࡳ࡬ࡩࡳ࡯ࡗ࡬ࡷ࡫ࡥࡃࡷࡷࡸࡴࡴࡳ࠯ࡺࡰࡰࠬጠ"))
	EfGqjMatnJyKNmekrIV708d49QT,GT53oyJCUd2mRi7AjvMkFrNcBS = YAvI1Zz5J3yEFXQdWhqmo6nD(w9eY6BpgAvy3onRk7S4QZ)
	EfGqjMatnJyKNmekrIV708d49QT = smVarGBSwFI219cP(EfGqjMatnJyKNmekrIV708d49QT,SqrG5mU3j96ldsFpExobw40TJY(u"ࠫ࠶࠸࠱࠹࠵࠴࠼࠺࠹ࠧጡ"))
	EHmxY3De4G = {jeAby54c02TgG8zuivonX91(u"ࠬ࡯ࡤࡴࠩጢ"):MMizeNH0AKu(u"࠭ࡄࡊࡃࡏࡓࡌ࠭ጣ"),hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠧࡶࡵࡵࠫጤ"):IIvxtojw6EXl2f,dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠨࡸࡨࡶࠬጥ"):aO9cFKo862LqTWlIjy,xcChIL13BpR8WArNt9Pl0So(u"ࠩࡶࡧࡷ࠭ጦ"):iyEphnMXfCWGa,A6dMB1FlgxVivJ2fk9C(u"ࠪࡷ࡮ࢀࠧጧ"):EfGqjMatnJyKNmekrIV708d49QT}
	PJxQXbasjH = {MMizeNH0AKu(u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪጨ"):rwQN9AKhLCuMfHxjlbX0U(u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧࠫጩ")}
	KTd4Cky7OL0AuJ = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"࠭ࡐࡐࡕࡗࠫጪ"),LLYixnfMkqIQmhJAslz,EHmxY3De4G,PJxQXbasjH,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,MMizeNH0AKu(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡕࡋࡓ࡜ࡥࡐࡍࡃ࡜ࡣࡉࡏࡁࡍࡑࡊ࠱࠶ࡹࡴࠨጫ"))
	YRB3c90n5NfbgdQvxJoW6ElV7TAeF = KTd4Cky7OL0AuJ.content
	try:
		if not YRB3c90n5NfbgdQvxJoW6ElV7TAeF: aKfRiW9P2UNE
		aJVXUDy1i6YZpGnk5bMg = Cy9ow3c21nABMjzqeaIT(QVDJLRlxNg127jMX(u"ࠨࡦ࡬ࡧࡹ࠭ጬ"),YRB3c90n5NfbgdQvxJoW6ElV7TAeF)
		thPiJUNOZT0xjKuw4QYHFdf2Dm75vk = aJVXUDy1i6YZpGnk5bMg[sULh4NjakzI8He7xJCMGrql(u"ࠩࡰࡷ࡬࠭ጭ")]
		YYLkfndg0ENAR2pCo7zceQm3sBa = aJVXUDy1i6YZpGnk5bMg[rwQN9AKhLCuMfHxjlbX0U(u"ࠪࡷࡪࡩࠧጮ")]
		HbucXyF0wPZf = aJVXUDy1i6YZpGnk5bMg[rwQN9AKhLCuMfHxjlbX0U(u"ࠫࡸࡺࡰࠨጯ")]
		YYLkfndg0ENAR2pCo7zceQm3sBa = int(ssYJQiWrZIRqkMe(YYLkfndg0ENAR2pCo7zceQm3sBa,XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠬ࠷࠲࠲࠺࠶࠵࠽࠻࠳ࠨጰ")))
		HbucXyF0wPZf = int(ssYJQiWrZIRqkMe(HbucXyF0wPZf,DJ1ICpbyR2(u"࠭࠱࠳࠳࠻࠷࠶࠾࠵࠴ࠩጱ")))
		for K3AuJ1QX9z0HWoVSvb5NFC in range(YYLkfndg0ENAR2pCo7zceQm3sBa,ybdv7XcT3lxF6QezULwCAGk,-HbucXyF0wPZf):
			if not eval(DJ1ICpbyR2(u"ࠧࡹࡤࡰࡧ࠳ࡖ࡬ࡢࡻࡨࡶ࠭࠯࠮ࡪࡵࡓࡰࡦࡿࡩ࡯ࡩࠫ࠭ࠬጲ"),{KBkxSYaz93pu1(u"ࠨࡺࡥࡱࡨ࠭ጳ"):MMk8qKvcJe4fQHm3EG7diBD5}): aKfRiW9P2UNE
			OnsAxhdVjZF(sULh4NjakzI8He7xJCMGrql(u"ࠩหห็๐ࠠๅๆอะึฮษ๊ࠡส่ๆำีࠨጴ"),str(K3AuJ1QX9z0HWoVSvb5NFC)+xcChIL13BpR8WArNt9Pl0So(u"ࠪࠤࠥัว็์ฬࠫጵ"),HB5PvxRhwM=KBkxSYaz93pu1(u"࠶࠴࠵ᓙ")*HbucXyF0wPZf)
			MMk8qKvcJe4fQHm3EG7diBD5.sleep(OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"࠵࠵࠶࠰ᓚ")*HbucXyF0wPZf)
		if eval(EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠫࡽࡨ࡭ࡤ࠰ࡓࡰࡦࡿࡥࡳࠪࠬ࠲࡮ࡹࡐ࡭ࡣࡼ࡭ࡳ࡭ࠨࠪࠩጶ"),{hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠬࡾࡢ࡮ࡥࠪጷ"):MMk8qKvcJe4fQHm3EG7diBD5}):
			thPiJUNOZT0xjKuw4QYHFdf2Dm75vk = thPiJUNOZT0xjKuw4QYHFdf2Dm75vk.replace(NXMOzZjYsmS9pf,o1u5dij9UrcbXzVS8lwIWfKpnqM(u"࠭࡜࡝ࡰࠪጸ")).replace(y6eSQlZEV8uwKG5M3,SqrG5mU3j96ldsFpExobw40TJY(u"ࠧ࡝࡞ࡵࠫጹ"))
			BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,DJ1ICpbyR2(u"ࠨะิ์ั࠭ጺ"),QvgnCALNstmuUJiET(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬጻ"),thPiJUNOZT0xjKuw4QYHFdf2Dm75vk)
		aKfRiW9P2UNE
	except: exec(LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠪࡼࡧࡳࡣ࠯ࡒ࡯ࡥࡾ࡫ࡲࠩࠫ࠱ࡷࡹࡵࡰࠩࠫࠪጼ"),{o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠫࡽࡨ࡭ࡤࠩጽ"):MMk8qKvcJe4fQHm3EG7diBD5})
	return
def NRFuVkwcn4XCY6vKOp():
	exec(OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠬ࠭ࠧࠎࠌࡷࡶࡾࡀࠍࠋࠋࡺ࡭ࡳࡪ࡯ࡸ࠳࠵࠷ࠥࡃࠠࡹࡤࡰࡧ࡬ࡻࡩ࠯࡙࡬ࡲࡩࡵࡷࠩ࠳࠳࠴࠷࠻ࠩࠎࠌࠌࡻ࡭࡯࡬ࡦࠢࡗࡶࡺ࡫࠺ࠎࠌࠌࠍࡽࡨ࡭ࡤ࠰ࡶࡰࡪ࡫ࡰࠩ࠳࠳࠴࠵࠯ࠍࠋࠋࠌࡸࡷࡿ࠺ࠡࡹ࡬ࡲࡩࡵࡷ࠲࠴࠶࠲࡬࡫ࡴࡇࡱࡦࡹࡸ࠮࠱࠱࠲࠵࠹࠮ࠓࠊࠊࠋࡨࡼࡨ࡫ࡰࡵ࠼ࠣࡦࡷ࡫ࡡ࡬ࠏࠍࠍࡿࡩࡲࡦࡣࡷࡩࡤ࡫ࡲࡰࡴࡵࠑࠏ࡫ࡸࡤࡧࡳࡸ࠿ࠦࡸࡣ࡯ࡦ࠲ࡕࡲࡡࡺࡧࡵࠬ࠮࠴ࡳࡵࡱࡳࠬ࠮ࠓࠊࠨࠩࠪጾ"),{jeAby54c02TgG8zuivonX91(u"࠭ࡸࡣ࡯ࡦ࡫ࡺ࡯ࠧጿ"):mUWYiQ2jHICA8cD6LhPTn3wpB1XyK,MMizeNH0AKu(u"ࠧࡹࡤࡰࡧࠬፀ"):MMk8qKvcJe4fQHm3EG7diBD5})
	return
def YAvI1Zz5J3yEFXQdWhqmo6nD(QTkAP1Nv4cDU0mVuWirzpafolHxF6):
	DrvPsiHhIgN2t,SyHorjp3UgM7ZC51 = ybdv7XcT3lxF6QezULwCAGk,ybdv7XcT3lxF6QezULwCAGk
	if WQvYkNg7SysPFLitlGEn6.path.exists(QTkAP1Nv4cDU0mVuWirzpafolHxF6):
		try: DrvPsiHhIgN2t = WQvYkNg7SysPFLitlGEn6.path.getsize(QTkAP1Nv4cDU0mVuWirzpafolHxF6)
		except: pass
		if not DrvPsiHhIgN2t:
			try: DrvPsiHhIgN2t = WQvYkNg7SysPFLitlGEn6.stat(QTkAP1Nv4cDU0mVuWirzpafolHxF6).st_size
			except: pass
		if not DrvPsiHhIgN2t:
			try:
				from pathlib import Path as RiICvFWOLSXVmyNkH2lAw4
				DrvPsiHhIgN2t = RiICvFWOLSXVmyNkH2lAw4(QTkAP1Nv4cDU0mVuWirzpafolHxF6).stat().st_size
			except: pass
		if DrvPsiHhIgN2t: SyHorjp3UgM7ZC51 = bXukYxQ4aHw
	return DrvPsiHhIgN2t,SyHorjp3UgM7ZC51
def JdgFHe3LwWc58G9TORuPr72bx4Ck(E1o5UTyH0pWqK8NCwBVSAlQDGfien,showDialogs):
	if showDialogs:
		dHPVDWfG4jX5e6QEo0CKh = XVmKrby29eCGMnlEY6jz0HNOR(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,wwPrSDa21lUh(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫፁ"),E1o5UTyH0pWqK8NCwBVSAlQDGfien+ITvnUAMXsyb4eO(u"ࠩ࡟ࡲࡡࡴࠧፂ")+hXB0vKVQ5PRI91SDTprMdfuHEm4+QvgnCALNstmuUJiET(u"๋้ࠪࠦสา์าࠤู๊อ้ࠡำหࠥอไๆๆไࠤฤࠧࠧፃ")+YYSh2J6BIrsm8)
		if dHPVDWfG4jX5e6QEo0CKh!=wwPrSDa21lUh(u"࠶ᓛ"): return
	VStDOZ89rQewqPg67uXyfLNH2vC = fEXMiAyG3ql4vKB
	if WQvYkNg7SysPFLitlGEn6.path.exists(E1o5UTyH0pWqK8NCwBVSAlQDGfien):
		try: WQvYkNg7SysPFLitlGEn6.remove(E1o5UTyH0pWqK8NCwBVSAlQDGfien.decode(a7VXeDU82IfQEnPZAdiT))
		except:
			try: WQvYkNg7SysPFLitlGEn6.remove(ocgZI0rF75Gxqlt4SH3dykzXfLW8)
			except Exception as BfSHD6dr8P5Tbyt2Vups:
				if showDialogs: BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,ITvnUAMXsyb4eO(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧፄ"),str(BfSHD6dr8P5Tbyt2Vups))
				VStDOZ89rQewqPg67uXyfLNH2vC = VBlawK4mgHSyLEn8iqhUkz5
	if showDialogs:
		if VStDOZ89rQewqPg67uXyfLNH2vC: BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,wwPrSDa21lUh(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨፅ"),EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"࠭แีๆอࠤ฾๋ไ๋หุ้ࠣำࠠศๆ่่ๆ࠭ፆ"))
		else:
			BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,sULh4NjakzI8He7xJCMGrql(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪፇ"),hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠨฬ่ࠤฬ๊ๅิฯࠣฬ๋าวฮࠩፈ"))
			CfKNTtIi3OABbWcPpdF(fEXMiAyG3ql4vKB)
	return
def Xe6bnfEPjgqJy5FIoRi0z2v8(jurwOHgkZRYIA72UBGJamNx9tQo8S,YuS8nxpdTj45Z9KfVqHRtD7s,showDialogs):
	if showDialogs:
		dHPVDWfG4jX5e6QEo0CKh = XVmKrby29eCGMnlEY6jz0HNOR(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,QvgnCALNstmuUJiET(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬፉ"),jurwOHgkZRYIA72UBGJamNx9tQo8S+LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠪࡠࡳࡢ࡮ࠨፊ")+hXB0vKVQ5PRI91SDTprMdfuHEm4+EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠫ์๊ࠠหำํำ๋ࠥำฮ๊ࠢิฬࠦวๅ็ฯ่ิࠦฟࠢࠩፋ")+YYSh2J6BIrsm8)
		if dHPVDWfG4jX5e6QEo0CKh!=bXukYxQ4aHw: return
	nKh8r540GQBVPTokjZ2 = fEXMiAyG3ql4vKB
	if WQvYkNg7SysPFLitlGEn6.path.exists(jurwOHgkZRYIA72UBGJamNx9tQo8S):
		for jEouDWXOhenPHqidA,KKQ5ia7HZmGdWFvnyUJgXtz0u,o9frzGZySuB7KL3xNTAMI6gl8XjqiH in WQvYkNg7SysPFLitlGEn6.walk(jurwOHgkZRYIA72UBGJamNx9tQo8S,topdown=fEXMiAyG3ql4vKB):
			for QTkAP1Nv4cDU0mVuWirzpafolHxF6 in o9frzGZySuB7KL3xNTAMI6gl8XjqiH:
				dVclanWB9Cy1T5mpNYQ7SUPfg0st = WQvYkNg7SysPFLitlGEn6.path.join(jEouDWXOhenPHqidA,QTkAP1Nv4cDU0mVuWirzpafolHxF6)
				try: WQvYkNg7SysPFLitlGEn6.remove(dVclanWB9Cy1T5mpNYQ7SUPfg0st)
				except Exception as HUpcs4WLhwzqV:
					if showDialogs and not nKh8r540GQBVPTokjZ2: BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,rwQN9AKhLCuMfHxjlbX0U(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨፌ"),str(HUpcs4WLhwzqV))
					nKh8r540GQBVPTokjZ2 = VBlawK4mgHSyLEn8iqhUkz5
			if YuS8nxpdTj45Z9KfVqHRtD7s:
				for dir in KKQ5ia7HZmGdWFvnyUJgXtz0u:
					QQqZsUnz7vd9xEJb5rXD = WQvYkNg7SysPFLitlGEn6.path.join(jEouDWXOhenPHqidA,dir)
					try: WQvYkNg7SysPFLitlGEn6.rmdir(QQqZsUnz7vd9xEJb5rXD)
					except: pass
		if YuS8nxpdTj45Z9KfVqHRtD7s:
			try: WQvYkNg7SysPFLitlGEn6.rmdir(jEouDWXOhenPHqidA)
			except: pass
	if showDialogs and not nKh8r540GQBVPTokjZ2:
		BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,xcChIL13BpR8WArNt9Pl0So(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩፍ"),rwQN9AKhLCuMfHxjlbX0U(u"ࠧห็ࠣห้๋ำฮࠢห๊ัออࠨፎ"))
		CfKNTtIi3OABbWcPpdF(fEXMiAyG3ql4vKB)
	return
def NNnAUwYFTOPH4m(QKFp5qOk03PnabuZHR1GC42,fjUoJylTVWh0,S6NALBOqGn1zi2W5M8y7,F49URk16JIawgp7YWZAXGtnMb,UBRzLM6ZdkWOKwy0qPfFIlC,dUWFtBQ3cpoIZ9):
	NPM3HKQ57xe,pRxdZFXemjq4,OXdrUl5wZ0uKQMS9zpeI3V2Hj,nnmdQ4OqbiAoYDsPHMv = e91ATlnmKdpq(S6NALBOqGn1zi2W5M8y7)
	YGEAhZgn41MJyBudfqwr6Q = fjUoJylTVWh0,NPM3HKQ57xe,F49URk16JIawgp7YWZAXGtnMb,UBRzLM6ZdkWOKwy0qPfFIlC
	if QKFp5qOk03PnabuZHR1GC42<hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"࠶ᓜ"):
		pMPR1Cc0usZ6nJTU(MM5Dx39f7ULhcJsRptzIowP,QvgnCALNstmuUJiET(u"ࠨࡑࡓࡉࡓ࡛ࡒࡍࡡࡘࡖࡑࡒࡉࡃࠩፏ"),YGEAhZgn41MJyBudfqwr6Q)
		QKFp5qOk03PnabuZHR1GC42 = -QKFp5qOk03PnabuZHR1GC42
	if QKFp5qOk03PnabuZHR1GC42>jeAby54c02TgG8zuivonX91(u"࠰ᓝ"):
		wYZ9hmIlS3cv17s2W = Mqk51CFBym0pIQXZLsOxSJ(MM5Dx39f7ULhcJsRptzIowP,QvgnCALNstmuUJiET(u"ࠩࡶࡸࡷ࠭ፐ"),wwPrSDa21lUh(u"ࠪࡓࡕࡋࡎࡖࡔࡏࡣ࡚ࡘࡌࡍࡋࡅࠫፑ"),YGEAhZgn41MJyBudfqwr6Q)
		if wYZ9hmIlS3cv17s2W:
			Dv0PbigXyWH4MUCSpE(CnbBKmtF1x84q7AW(u"࡚ࠫࡘࡌࡍࡋࡅࠤࠥࡘࡅࡂࡆࡢࡇࡆࡉࡈࡆࠩፒ"),S6NALBOqGn1zi2W5M8y7,F49URk16JIawgp7YWZAXGtnMb,UBRzLM6ZdkWOKwy0qPfFIlC,dUWFtBQ3cpoIZ9,fjUoJylTVWh0)
			return wYZ9hmIlS3cv17s2W
	wYZ9hmIlS3cv17s2W = Y2heCz1DlR0GLKHJTs5OPb9(fjUoJylTVWh0,S6NALBOqGn1zi2W5M8y7,F49URk16JIawgp7YWZAXGtnMb,UBRzLM6ZdkWOKwy0qPfFIlC,dUWFtBQ3cpoIZ9)
	if wYZ9hmIlS3cv17s2W and QKFp5qOk03PnabuZHR1GC42: BxuD7iQRpW1(MM5Dx39f7ULhcJsRptzIowP,LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠬࡕࡐࡆࡐࡘࡖࡑࡥࡕࡓࡎࡏࡍࡇ࠭ፓ"),YGEAhZgn41MJyBudfqwr6Q,wYZ9hmIlS3cv17s2W,QKFp5qOk03PnabuZHR1GC42)
	return wYZ9hmIlS3cv17s2W
from wgUB2Rijys import *
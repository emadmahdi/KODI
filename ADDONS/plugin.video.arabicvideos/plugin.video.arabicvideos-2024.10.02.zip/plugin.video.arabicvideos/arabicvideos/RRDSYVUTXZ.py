# -*- coding: utf-8 -*-
from yoY3NdGViS import *
xjPuFK3EsIZSiobQ5X = 'CIMALIGHT'
n0qFKQWhiBYXoTrvejVHUA4 = '_CML_'
Str0BupDTFA = u6rbxnyjTl7I[xjPuFK3EsIZSiobQ5X][0]
P3UK1Rr4IdYe5 = ['قنوات فضائية']
def ehB18u9sQFRi(mode,url,text):
	if   mode==470: N6NCYivtV4I5rEXq = DP6FSBgNdX1rsvVR()
	elif mode==471: N6NCYivtV4I5rEXq = wg5aF3e8rcDh7SGpW6M1OPnkU(url,text)
	elif mode==472: N6NCYivtV4I5rEXq = oanus6TxUFNAhSZKpJdYlEC4mV(url)
	elif mode==473: N6NCYivtV4I5rEXq = R4i0moBGrAfhaZ3(url,text)
	elif mode==474: N6NCYivtV4I5rEXq = qt2zjyIbsS(url)
	elif mode==479: N6NCYivtV4I5rEXq = lPwaAjFTMG4n7iSLkXcEuK0Zm(text)
	else: N6NCYivtV4I5rEXq = False
	return N6NCYivtV4I5rEXq
def DP6FSBgNdX1rsvVR():
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',Str0BupDTFA,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'CIMALIGHT-MENU-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	cbYKa2SXGwRCiQIW5NeosU9k = trdVA0JvFaD.findall('"url": "(.*?)"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	cbYKa2SXGwRCiQIW5NeosU9k = cbYKa2SXGwRCiQIW5NeosU9k[0].strip('/')
	cbYKa2SXGwRCiQIW5NeosU9k = RRNODILCtGzvgpx(cbYKa2SXGwRCiQIW5NeosU9k,'url')
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'بحث في الموقع',hWGMqtBy4wuLaVcj,479,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'_REMEMBERRESULTS_')
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('"content"(.*?)</div>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
	items = trdVA0JvFaD.findall('href="(.*?)".*?</i>(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	for llxFwq0CUNgQtivJzkHeGV,title in items:
		title = title.replace(FqcVAkh7WjIXHdDKf8nvuyRo,hWGMqtBy4wuLaVcj).strip(Mpsm2VF1OBnCRvK3qf6)
		llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV.replace('cat=online-movies1','cat=online-movies')
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,474)
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('/category.php">(.*?)"navslide-divider"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall("'dropdown-menu'(.*?)</ul>",mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	items = trdVA0JvFaD.findall('href="(.*?)".*?>(.*?)</a>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	for llxFwq0CUNgQtivJzkHeGV,title in items:
		if title in P3UK1Rr4IdYe5: continue
		if 'مسلسل ' in title: continue
		if 'برنامج ' in title: continue
		if 'للكبار' in title: continue
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,474)
	return
def qt2zjyIbsS(url):
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'CIMALIGHT-TITLES-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	if 'topvideos.php' in url: DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('"caret"(.*?)id="pm-grid"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	else: DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('"caret"(.*?)</ul>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('href="(.*?)".*?>(.*?)</a>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,title in items:
			if 'topvideos.php' in llxFwq0CUNgQtivJzkHeGV:
				if 'topvideos.php?c=english-movies' in llxFwq0CUNgQtivJzkHeGV: continue
				if 'topvideos.php?c=online-movies1' in llxFwq0CUNgQtivJzkHeGV: continue
				if 'topvideos.php?c=misc' in llxFwq0CUNgQtivJzkHeGV: continue
				if 'topvideos.php?c=tv-channel' in llxFwq0CUNgQtivJzkHeGV: continue
				if 'منذ البداية' in title and 'do=rating' not in llxFwq0CUNgQtivJzkHeGV: continue
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,471)
	else: wg5aF3e8rcDh7SGpW6M1OPnkU(url)
	return
def wg5aF3e8rcDh7SGpW6M1OPnkU(url,s4mUPzjv1bRoNTMdenkuBgYl=hWGMqtBy4wuLaVcj):
	cbYKa2SXGwRCiQIW5NeosU9k = RRNODILCtGzvgpx(url,'url')
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'CIMALIGHT-TITLES-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	items = []
	if s4mUPzjv1bRoNTMdenkuBgYl=='featured_movies':
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('"container-fluid"(.*?)</ul>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('href="(.*?)".*?"title">(.*?)</div>.*?image:url\(\'(.*?)\'\)',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		m4IznKilUOByHweG68VJ,LHN1Zr7FDtbYfjz069Gnh,cpe36NzrSZEWbUyIjPsB = zip(*items)
		items = zip(cpe36NzrSZEWbUyIjPsB,m4IznKilUOByHweG68VJ,LHN1Zr7FDtbYfjz069Gnh)
	elif s4mUPzjv1bRoNTMdenkuBgYl=='featured_series':
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('المسلسلات المميزة(.*?)<style>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('href="(.*?)".*?title="(.*?)".*?image:url\(\'(.*?)\'\)',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		m4IznKilUOByHweG68VJ,LHN1Zr7FDtbYfjz069Gnh,cpe36NzrSZEWbUyIjPsB = zip(*items)
		items = zip(cpe36NzrSZEWbUyIjPsB,m4IznKilUOByHweG68VJ,LHN1Zr7FDtbYfjz069Gnh)
	else:
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('(data-echo=".*?)</ul>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if not DJvksH7ZAFUqW9OyQnbGjPCtwR1o: DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('"BlocksList"(.*?)"titleSectionCon"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if not DJvksH7ZAFUqW9OyQnbGjPCtwR1o: DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('id="pm-grid"(.*?)</ul>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if not DJvksH7ZAFUqW9OyQnbGjPCtwR1o: DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('id="pm-related"(.*?)</ul>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if not DJvksH7ZAFUqW9OyQnbGjPCtwR1o: DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('pm-ul-browse-videos(.*?)clearfix',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if not DJvksH7ZAFUqW9OyQnbGjPCtwR1o: return
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
	if not items: items = trdVA0JvFaD.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	if not items: items = trdVA0JvFaD.findall('src="(.*?)".*?href="(.*?)".*?>(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	REbVyXis1w4Ae = []
	nNBCdTs98RztMyODHpL63ZUKm4P = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,llxFwq0CUNgQtivJzkHeGV,title in items:
		llxFwq0CUNgQtivJzkHeGV = jkiCS0UWs2dNAJcGKn6mbHD(llxFwq0CUNgQtivJzkHeGV).strip('/')
		title = title.replace('ماي سيما',hWGMqtBy4wuLaVcj).replace('مشاهدة',hWGMqtBy4wuLaVcj).strip(Mpsm2VF1OBnCRvK3qf6).replace(FqcVAkh7WjIXHdDKf8nvuyRo,Mpsm2VF1OBnCRvK3qf6)
		if 'http' not in llxFwq0CUNgQtivJzkHeGV: llxFwq0CUNgQtivJzkHeGV = cbYKa2SXGwRCiQIW5NeosU9k+'/'+llxFwq0CUNgQtivJzkHeGV.strip('/')
		if 'http' not in Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG: Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG = cbYKa2SXGwRCiQIW5NeosU9k+'/'+Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG.strip('/')
		IIsmGy4pd7 = trdVA0JvFaD.findall('(.*?) (الحلقة|حلقة) \d+',title,trdVA0JvFaD.DOTALL)
		if any(BoSjXKxz41DcneO9UimClE in title for BoSjXKxz41DcneO9UimClE in nNBCdTs98RztMyODHpL63ZUKm4P):
			title = '_MOD_'+title
			RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,472,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
		elif IIsmGy4pd7 and 'حلقة' in title:
			title = '_MOD_'+IIsmGy4pd7[0][0]
			if title not in REbVyXis1w4Ae:
				RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,473,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
				REbVyXis1w4Ae.append(title)
		elif '/movseries/' in llxFwq0CUNgQtivJzkHeGV:
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,471,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
		else: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,473,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
	if s4mUPzjv1bRoNTMdenkuBgYl not in ['featured_movies','featured_series']:
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('"pagination(.*?)</ul>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
			cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
			items = trdVA0JvFaD.findall('href="(.*?)".*?>(.*?)</a>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
			for llxFwq0CUNgQtivJzkHeGV,title in items:
				if llxFwq0CUNgQtivJzkHeGV=='#': continue
				llxFwq0CUNgQtivJzkHeGV = cbYKa2SXGwRCiQIW5NeosU9k+'/'+llxFwq0CUNgQtivJzkHeGV.strip('/')
				title = LNtIDdBA52P(title)
				RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'صفحة '+title,llxFwq0CUNgQtivJzkHeGV,471)
		C1EL24u0ZA8YRg9vfBXDxiyQ5lFoO = trdVA0JvFaD.findall('showmore" href="(.*?)"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if C1EL24u0ZA8YRg9vfBXDxiyQ5lFoO:
			llxFwq0CUNgQtivJzkHeGV = C1EL24u0ZA8YRg9vfBXDxiyQ5lFoO[0]
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'مشاهدة المزيد',llxFwq0CUNgQtivJzkHeGV,471)
	return
def R4i0moBGrAfhaZ3(url,dp9XPV1Au6EWCJyiGw):
	cbYKa2SXGwRCiQIW5NeosU9k = RRNODILCtGzvgpx(url,'url')
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'CIMALIGHT-EPISODES-2nd')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	cLV4wifngjAdbePKq2x7SDhXGYlO0 = trdVA0JvFaD.findall('"SeasonsBox"(.*?)</div>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	items = []
	if cLV4wifngjAdbePKq2x7SDhXGYlO0 and not dp9XPV1Au6EWCJyiGw:
		Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG = trdVA0JvFaD.findall('"series-header".*?src="(.*?)"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG = Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG[0] if Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG else hWGMqtBy4wuLaVcj
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = cLV4wifngjAdbePKq2x7SDhXGYlO0[0]
		items = trdVA0JvFaD.findall('openCity\(event\, \'(.*?)\'\)".*?>(.*?)</button>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		if len(items)==1: dp9XPV1Au6EWCJyiGw = items[0][0]
		elif len(items)>1:
			for dp9XPV1Au6EWCJyiGw,title in items: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,url,473,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,hWGMqtBy4wuLaVcj,dp9XPV1Au6EWCJyiGw)
	v2V8Nmrwf4 = trdVA0JvFaD.findall('id="'+dp9XPV1Au6EWCJyiGw+'"(.*?)</ul>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if v2V8Nmrwf4 and len(items)<2:
		Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG = trdVA0JvFaD.findall('"series-header".*?src="(.*?)"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG = Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG[0] if Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG else hWGMqtBy4wuLaVcj
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = v2V8Nmrwf4[0]
		items = trdVA0JvFaD.findall('href="(.*?)".*?title="(.*?)"',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		if items:
			for llxFwq0CUNgQtivJzkHeGV,title in items:
				title = title.replace('ماي سيما',hWGMqtBy4wuLaVcj).replace('مسلسل',hWGMqtBy4wuLaVcj).strip(Mpsm2VF1OBnCRvK3qf6)
				if 'http' not in llxFwq0CUNgQtivJzkHeGV: llxFwq0CUNgQtivJzkHeGV = cbYKa2SXGwRCiQIW5NeosU9k+'/'+llxFwq0CUNgQtivJzkHeGV.strip('/')
				RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,472,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
		else:
			items = trdVA0JvFaD.findall('href="(.*?)".*?title="(.*?)".*?image:url\((.*?)\)',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
			for llxFwq0CUNgQtivJzkHeGV,title,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG in items:
				if 'http' not in llxFwq0CUNgQtivJzkHeGV: llxFwq0CUNgQtivJzkHeGV = cbYKa2SXGwRCiQIW5NeosU9k+'/'+llxFwq0CUNgQtivJzkHeGV.strip('/')
				RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,472,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
	if 'id="pm-related"' in mMQ3FkNVa4IlxqY:
		if items: RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'مواضيع ذات صلة',url,471)
	return
def oanus6TxUFNAhSZKpJdYlEC4mV(url):
	Dvi8asSrQYX5wE3KMIxT91me = []
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'CIMALIGHT-PLAY-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('<div itemprop="description">(.*?)href=',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		BX029UJFPvpNQsc45jbYZRh = trdVA0JvFaD.findall('<p>(.*?)</p>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		if BX029UJFPvpNQsc45jbYZRh and Dc20k3vN9hT5(xjPuFK3EsIZSiobQ5X,url,BX029UJFPvpNQsc45jbYZRh,True): return
	NPM3HKQ57xe = url.replace('/watch.php','/play.php')
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',NPM3HKQ57xe,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'CIMALIGHT-PLAY-2nd')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	qqQsFXRTUP078H = []
	llxFwq0CUNgQtivJzkHeGV = trdVA0JvFaD.findall('"embedURL" href="(.*?)"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if llxFwq0CUNgQtivJzkHeGV:
		llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV[0]
		if llxFwq0CUNgQtivJzkHeGV and llxFwq0CUNgQtivJzkHeGV not in qqQsFXRTUP078H:
			qqQsFXRTUP078H.append(llxFwq0CUNgQtivJzkHeGV)
			llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV+'?named=__embed'
			if 'http' not in llxFwq0CUNgQtivJzkHeGV: llxFwq0CUNgQtivJzkHeGV = 'http:'+llxFwq0CUNgQtivJzkHeGV
			Dvi8asSrQYX5wE3KMIxT91me.append(llxFwq0CUNgQtivJzkHeGV)
	items = trdVA0JvFaD.findall("<iframe src='(.*?)'.*?<strong>(.*?)</strong>",mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	for llxFwq0CUNgQtivJzkHeGV,title in items:
		if llxFwq0CUNgQtivJzkHeGV not in qqQsFXRTUP078H:
			qqQsFXRTUP078H.append(llxFwq0CUNgQtivJzkHeGV)
			llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV+'?named='+title+'__watch'
			if 'http' not in llxFwq0CUNgQtivJzkHeGV: llxFwq0CUNgQtivJzkHeGV = 'http:'+llxFwq0CUNgQtivJzkHeGV
			Dvi8asSrQYX5wE3KMIxT91me.append(llxFwq0CUNgQtivJzkHeGV)
	NPM3HKQ57xe = url.replace('/watch.php','/downloads.php')
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',NPM3HKQ57xe,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'CIMALIGHT-PLAY-3rd')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('"downloadlist"(.*?)</ul>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('href="(.*?)".*?<strong>(.*?)</strong>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,title in items:
			if llxFwq0CUNgQtivJzkHeGV not in qqQsFXRTUP078H:
				qqQsFXRTUP078H.append(llxFwq0CUNgQtivJzkHeGV)
				llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV+'?named='+title+'__download'
				if 'http' not in llxFwq0CUNgQtivJzkHeGV: llxFwq0CUNgQtivJzkHeGV = 'http:'+llxFwq0CUNgQtivJzkHeGV
				Dvi8asSrQYX5wE3KMIxT91me.append(llxFwq0CUNgQtivJzkHeGV)
	import oosSOfvdEQ
	oosSOfvdEQ.zfdYjsGLg8M6i15qZWh(Dvi8asSrQYX5wE3KMIxT91me,xjPuFK3EsIZSiobQ5X,'video',url)
	return
def lPwaAjFTMG4n7iSLkXcEuK0Zm(search):
	search,vvKf4sXgZIMyEJPuC,showDialogs = IVTEJQOiMR2dYta9C(search)
	if search==hWGMqtBy4wuLaVcj: search = TrzfUidpv1LyAYqwexHJDuS()
	if search==hWGMqtBy4wuLaVcj: return
	search = search.replace(Mpsm2VF1OBnCRvK3qf6,'+')
	SODQ7qlNYoZcFK8e50rBsJaAHxiXjE = RRNODILCtGzvgpx(Str0BupDTFA,'url')
	url = SODQ7qlNYoZcFK8e50rBsJaAHxiXjE+'/search.php?keywords='+search
	wg5aF3e8rcDh7SGpW6M1OPnkU(url,'search')
	return
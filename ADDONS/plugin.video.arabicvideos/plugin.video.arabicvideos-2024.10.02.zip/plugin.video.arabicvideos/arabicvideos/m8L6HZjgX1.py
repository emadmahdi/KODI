# -*- coding: utf-8 -*-
import sys as zGjD5QAkd7SO9YPcZl
A56Abl2j14QS = zGjD5QAkd7SO9YPcZl.version_info [0] == 2
qO2vebR9rSTZnuJDW = 2048
EECQl2Zun37S0KkWwtIDHYNai6Ayd8 = 7
def wwTjCFmkUK (mMBv4T89VDdfJGL):
	global ylRUYSmHX7oCf93TADc8J6rqMVL
	tE23ZuI91qGJ = ord (mMBv4T89VDdfJGL [-1])
	huZOyFMzvY3LpEf = mMBv4T89VDdfJGL [:-1]
	FXE237NbgJweKmBxPfVnsAoYjCazqW = tE23ZuI91qGJ % len (huZOyFMzvY3LpEf)
	LQ2yAP51CVNFXdr = huZOyFMzvY3LpEf [:FXE237NbgJweKmBxPfVnsAoYjCazqW] + huZOyFMzvY3LpEf [FXE237NbgJweKmBxPfVnsAoYjCazqW:]
	if A56Abl2j14QS:
		R0i7UHvbBw25n8 = unicode () .join ([unichr (ord (cIsD9VN758uwbLUaGM2zmEY) - qO2vebR9rSTZnuJDW - (o42QnFjKJ5l98hWTqzCDi73LcvNA + tE23ZuI91qGJ) % EECQl2Zun37S0KkWwtIDHYNai6Ayd8) for o42QnFjKJ5l98hWTqzCDi73LcvNA, cIsD9VN758uwbLUaGM2zmEY in enumerate (LQ2yAP51CVNFXdr)])
	else:
		R0i7UHvbBw25n8 = str () .join ([chr (ord (cIsD9VN758uwbLUaGM2zmEY) - qO2vebR9rSTZnuJDW - (o42QnFjKJ5l98hWTqzCDi73LcvNA + tE23ZuI91qGJ) % EECQl2Zun37S0KkWwtIDHYNai6Ayd8) for o42QnFjKJ5l98hWTqzCDi73LcvNA, cIsD9VN758uwbLUaGM2zmEY in enumerate (LQ2yAP51CVNFXdr)])
	return eval (R0i7UHvbBw25n8)
NeO3CTLHrPfWUoIgy8Q,KNIvHPjUbhr,CnbBKmtF1x84q7AW=wwTjCFmkUK,wwTjCFmkUK,wwTjCFmkUK
zyvJMtBhrw,MMizeNH0AKu,KBkxSYaz93pu1=CnbBKmtF1x84q7AW,KNIvHPjUbhr,NeO3CTLHrPfWUoIgy8Q
LB2q7IVRpcyXlE6C3ihZruPe4An1Y,EDgpT9hIF6GCfl0vXiWnBANjOUVRua,XQo0YS3sk4rHAvwyNltf9CipLWMjx=KBkxSYaz93pu1,MMizeNH0AKu,zyvJMtBhrw
hWUz1ujibPY3G9MIZmvS4kVaK7dT,DJ1ICpbyR2,e2qDYgipPmTw4KvBLnochr=XQo0YS3sk4rHAvwyNltf9CipLWMjx,EDgpT9hIF6GCfl0vXiWnBANjOUVRua,LB2q7IVRpcyXlE6C3ihZruPe4An1Y
A6dMB1FlgxVivJ2fk9C,mkHKSQvjWr5BTcM3wVY,o1u5dij9UrcbXzVS8lwIWfKpnqM=e2qDYgipPmTw4KvBLnochr,DJ1ICpbyR2,hWUz1ujibPY3G9MIZmvS4kVaK7dT
JwiZdgbG5HYuCIsj69aBSRQ0nrNkET,SqrG5mU3j96ldsFpExobw40TJY,HHoGx7Flus60=o1u5dij9UrcbXzVS8lwIWfKpnqM,mkHKSQvjWr5BTcM3wVY,A6dMB1FlgxVivJ2fk9C
QVDJLRlxNg127jMX,gDuGMR3z1aV6YdLmCpiO8Kl,jeAby54c02TgG8zuivonX91=HHoGx7Flus60,SqrG5mU3j96ldsFpExobw40TJY,JwiZdgbG5HYuCIsj69aBSRQ0nrNkET
S1SgCFYGJeMvfp5iZXK,dv0trJR7PwmKyxDYO52VLau8gEph,QvgnCALNstmuUJiET=jeAby54c02TgG8zuivonX91,gDuGMR3z1aV6YdLmCpiO8Kl,QVDJLRlxNg127jMX
OOsBSKq9u6J2lC5WdYpvNMHaFP4,rwQN9AKhLCuMfHxjlbX0U,xcChIL13BpR8WArNt9Pl0So=QvgnCALNstmuUJiET,dv0trJR7PwmKyxDYO52VLau8gEph,S1SgCFYGJeMvfp5iZXK
sULh4NjakzI8He7xJCMGrql,LAhIMyBG0xZVUlO4rJ9z5fbDFgCs,GA4NBdjuZqkKUX6IEMvHPoegDyVrLm=xcChIL13BpR8WArNt9Pl0So,rwQN9AKhLCuMfHxjlbX0U,OOsBSKq9u6J2lC5WdYpvNMHaFP4
ITvnUAMXsyb4eO,wwPrSDa21lUh,FimxS5jkaq1RcJ8DnWTZNO4zQClwt=GA4NBdjuZqkKUX6IEMvHPoegDyVrLm,LAhIMyBG0xZVUlO4rJ9z5fbDFgCs,sULh4NjakzI8He7xJCMGrql
import xbmc as MMk8qKvcJe4fQHm3EG7diBD5,re as trdVA0JvFaD,sys as zGjD5QAkd7SO9YPcZl,xbmcaddon as FaP2ug05rl8EmAHkQsNid,random as eOmXSF6kIWV7yqKCR,os as WQvYkNg7SysPFLitlGEn6,xbmcvfs as u56uNLKlxv1wA83gbjpJPhr0E2kfd,time as HB5PvxRhwM,pickle as Jfn98z6aWOokIrXYl4jQdTEiRBFqeC,zlib as IZedRkDajQCrHAM4mOPtNEKzc70vF,xbmcgui as mUWYiQ2jHICA8cD6LhPTn3wpB1XyK,xbmcplugin as u6sYmx5Dtz,sqlite3 as pbXIg7UFi4dV,traceback as R7RLCd9kyl,threading as KCTRe67wVy,hashlib as xcRlSgBrOhKz69LNou0f8D5MVem,json as TPDQ5L9eWpIJcrM3YH48Cs6
import MmcgqAlsFt
xjPuFK3EsIZSiobQ5X = OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠬࡒࡉࡃࡕࡒࡒࡊ࠭य़")
hWGMqtBy4wuLaVcj = gDuGMR3z1aV6YdLmCpiO8Kl(u"࠭ࠧॠ")
Mpsm2VF1OBnCRvK3qf6 = wwPrSDa21lUh(u"ࠧࠡࠩॡ")
FqcVAkh7WjIXHdDKf8nvuyRo = Mpsm2VF1OBnCRvK3qf6*QvgnCALNstmuUJiET(u"࠴ଣ")
lG0yV5QNFHc2RbXM1Wp = Mpsm2VF1OBnCRvK3qf6*gDuGMR3z1aV6YdLmCpiO8Kl(u"࠶ତ")
nIDXGaRHv7mOohe0Y8dLstECM = Mpsm2VF1OBnCRvK3qf6*rwQN9AKhLCuMfHxjlbX0U(u"࠸ଥ")
VBlawK4mgHSyLEn8iqhUkz5 = zyvJMtBhrw(u"࡚ࡲࡶࡧ୭")
fEXMiAyG3ql4vKB = A6dMB1FlgxVivJ2fk9C(u"ࡆࡢ࡮ࡶࡩ୮")
ybdv7XcT3lxF6QezULwCAGk = A6dMB1FlgxVivJ2fk9C(u"࠵ଦ")
bXukYxQ4aHw = KBkxSYaz93pu1(u"࠷ଧ")
Y0XZKGRAUQj5O = LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"࠲ନ")
x1x9kIQo3zjZWnYaiy = CnbBKmtF1x84q7AW(u"࠴଩")
jR6BYWNFZ0egmH4Tr2Q78LbSs3t = GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"࠶ପ")
hXB0vKVQ5PRI91SDTprMdfuHEm4 = DJ1ICpbyR2(u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡈ࠵࠳ࡈࡠࠫॢ")
soMVfbr6WtpNlcSA = xcChIL13BpR8WArNt9Pl0So(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬॣ")
tsBed5hpnEXTRG0u3U8KYlDfW1j = FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋ࠸ࡅࡄࡈ࠵ࡉࡢ࠭।")
mjT0nQWPKRuLrbVCvpkN = S1SgCFYGJeMvfp5iZXK(u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌ࠱ࡇ࠷࠴ࡊࡋࡣࠧ॥")
YYSh2J6BIrsm8 = CnbBKmtF1x84q7AW(u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ०")
a7VXeDU82IfQEnPZAdiT = LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"࠭ࡵࡵࡨ࠻ࠫ१")
pGYKHZgqFX3B = JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠧࡏࡑࡗࡍࡈࡋࠧ२")
YYcbiF1UROXlga2 = S1SgCFYGJeMvfp5iZXK(u"ࠨࡐࡒࡘࡎࡉࡅࡠࡎࡌࡒࡊ࡙ࠧ३")
pKJjfBXL51wlaTAs = S1SgCFYGJeMvfp5iZXK(u"ࠩࡈࡖࡗࡕࡒࠨ४")
VRQE4jsXHSfhPWo5DgLwxGk = HHoGx7Flus60(u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨ५")
NXMOzZjYsmS9pf = zyvJMtBhrw(u"ࠫࡡࡴࠧ६")
y6eSQlZEV8uwKG5M3 = mkHKSQvjWr5BTcM3wVY(u"ࠬࡢࡲࠨ७")
ggKyfILOkNPGxMtDQueVSZ = FaP2ug05rl8EmAHkQsNid.Addon().getAddonInfo(FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"࠭ࡰࡢࡶ࡫ࠫ८"))
Hnatdr15pigs8A0uJDlkXz = WQvYkNg7SysPFLitlGEn6.path.join(ggKyfILOkNPGxMtDQueVSZ,GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠧࡱࡣࡦ࡯ࡦ࡭ࡥࡴࠩ९"))
zGjD5QAkd7SO9YPcZl.path.append(Hnatdr15pigs8A0uJDlkXz)
FFAcZOeDh4KC = MMk8qKvcJe4fQHm3EG7diBD5.getInfoLabel(JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠣࡕࡼࡷࡹ࡫࡭࠯ࡄࡸ࡭ࡱࡪࡖࡦࡴࡶ࡭ࡴࡴࠢ॰"))
guSzmUCXDa1tQpY = trdVA0JvFaD.findall(hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠩࠫࡠࡩࡢࡤ࡝࠰࡟ࡨ࠮࠭ॱ"),FFAcZOeDh4KC,trdVA0JvFaD.DOTALL)
guSzmUCXDa1tQpY = float(guSzmUCXDa1tQpY[ybdv7XcT3lxF6QezULwCAGk])
wwF217xRKfBAm = MMk8qKvcJe4fQHm3EG7diBD5.Player
LReTm9MyqCHKFIZtv8WYD = mUWYiQ2jHICA8cD6LhPTn3wpB1XyK.WindowXMLDialog
VKiGj1LundAJQwEXcqgxC = guSzmUCXDa1tQpY<hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"࠴࠽ଫ")
H4qZ2hwilNJYTmCFEQyaSs98cPM0gR = guSzmUCXDa1tQpY>QvgnCALNstmuUJiET(u"࠵࠽࠴࠹࠺ବ")
if H4qZ2hwilNJYTmCFEQyaSs98cPM0gR:
	rkp74Xbt2ajZ = MMk8qKvcJe4fQHm3EG7diBD5.LOGINFO
	w4GYEC6fmU2g7H,cc6SBsG2vlpjPd8yERNW1AJDZM = OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࡸࠫࡡࡻ࠲࠱࠴ࡤࠫॲ"),xcChIL13BpR8WArNt9Pl0So(u"ࡹࠬࡢࡵ࠳࠲࠵ࡦࠬॳ")
	hS7nXLvTHCUBAtYwEOg = u56uNLKlxv1wA83gbjpJPhr0E2kfd.translatePath(DJ1ICpbyR2(u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰ࡶࡨࡱࡵ࠭ॴ"))
	from urllib.parse import unquote as _IDzPpAg07NQOCksoWT5
else:
	rkp74Xbt2ajZ = MMk8qKvcJe4fQHm3EG7diBD5.LOGNOTICE
	w4GYEC6fmU2g7H,cc6SBsG2vlpjPd8yERNW1AJDZM = A6dMB1FlgxVivJ2fk9C(u"ࡻࠧ࡝ࡷ࠵࠴࠷ࡧࠧॵ").encode(a7VXeDU82IfQEnPZAdiT),GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࡵࠨ࡞ࡸ࠶࠵࠸ࡢࠨॶ").encode(a7VXeDU82IfQEnPZAdiT)
	hS7nXLvTHCUBAtYwEOg = MMk8qKvcJe4fQHm3EG7diBD5.translatePath(sULh4NjakzI8He7xJCMGrql(u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳ࡹ࡫࡭ࡱࠩॷ"))
	from urllib import unquote as _IDzPpAg07NQOCksoWT5
UUtZcnoks2Od7HCrAz = hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"࠻࠶ଭ")
LOchm76Z8SuMaq1PGCT = LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"࠼࠰ମ")*UUtZcnoks2Od7HCrAz
dKZePjlDFhABt1zp27JMqO = sULh4NjakzI8He7xJCMGrql(u"࠲࠵ଯ")*LOchm76Z8SuMaq1PGCT
jVOFdy24YibL = CnbBKmtF1x84q7AW(u"࠴࠲ର")*dKZePjlDFhABt1zp27JMqO
lke5D6CpaAXPdEZyrBSw7T = ybdv7XcT3lxF6QezULwCAGk
D8V7AhLkSQYzo = KNIvHPjUbhr(u"࠵࠳଱")*UUtZcnoks2Od7HCrAz
nHBb7jXk0Daom = Y0XZKGRAUQj5O*LOchm76Z8SuMaq1PGCT
KqO5BWGQR9JVL = LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"࠴࠺ଲ")*LOchm76Z8SuMaq1PGCT
DpQifS0oKBI1hYcO = x1x9kIQo3zjZWnYaiy*dKZePjlDFhABt1zp27JMqO
AoRzutVGQfLjYMwdCngZPxs = NeO3CTLHrPfWUoIgy8Q(u"࠷࠵ଳ")*dKZePjlDFhABt1zp27JMqO
VWxPgG1p8Z2Ei4DrX7NotvR = xcChIL13BpR8WArNt9Pl0So(u"࠶࠸଴")*jVOFdy24YibL
gVRmOBQA8Lse7aojcU5nSl4G2N = LOchm76Z8SuMaq1PGCT
nUy7x6dqmk92MPb = zGjD5QAkd7SO9YPcZl.argv[ybdv7XcT3lxF6QezULwCAGk].split(rwQN9AKhLCuMfHxjlbX0U(u"ࠩ࠲ࠫॸ"))[Y0XZKGRAUQj5O]
l95lLYCJweSnVHqzrstyPWcE = int(zGjD5QAkd7SO9YPcZl.argv[bXukYxQ4aHw])
i2tpOA6QzlfUByTSeKacWnV1 = zGjD5QAkd7SO9YPcZl.argv[Y0XZKGRAUQj5O]
W8OofeKN6ndp2Q = nUy7x6dqmk92MPb.split(mkHKSQvjWr5BTcM3wVY(u"ࠪ࠲ࠬॹ"))[Y0XZKGRAUQj5O]
aO9cFKo862LqTWlIjy = MMk8qKvcJe4fQHm3EG7diBD5.getInfoLabel(KNIvHPjUbhr(u"ࠫࡘࡿࡳࡵࡧࡰ࠲ࡆࡪࡤࡰࡰ࡙ࡩࡷࡹࡩࡰࡰࠫࠫॺ")+nUy7x6dqmk92MPb+XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠬ࠯ࠧॻ"))
vA0ImpguajeHKJ6P = WQvYkNg7SysPFLitlGEn6.path.join(hS7nXLvTHCUBAtYwEOg,nUy7x6dqmk92MPb)
MM5Dx39f7ULhcJsRptzIowP = WQvYkNg7SysPFLitlGEn6.path.join(vA0ImpguajeHKJ6P,ITvnUAMXsyb4eO(u"࠭࡭ࡢ࡫ࡱࡨࡦࡺࡡ࠯ࡦࡥࠫॼ"))
UC78nrbeDHfwVAh2vt = WQvYkNg7SysPFLitlGEn6.path.join(vA0ImpguajeHKJ6P,KNIvHPjUbhr(u"ࠧ࡭ࡣࡶࡸࡻ࡯ࡤࡦࡱࡶ࠲ࡩࡧࡴࠨॽ"))
IHKJoQ8PwW4pNBR6GTAMVz2hdfC5my = int(HB5PvxRhwM.time())
ee8c0jzrTntGSUdRJm = FaP2ug05rl8EmAHkQsNid.Addon(id=nUy7x6dqmk92MPb)
QP8x2LzMOdkKiNDbopTH4l = ee8c0jzrTntGSUdRJm.getSetting(EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠨࡣࡹ࠲ࡻ࡫ࡲࡴ࡫ࡲࡲࠬॾ"))
Q9dmawtsE7unfZFyvzNVx5c1iL48CB = fEXMiAyG3ql4vKB if QP8x2LzMOdkKiNDbopTH4l==aO9cFKo862LqTWlIjy else VBlawK4mgHSyLEn8iqhUkz5
oKcOsHdzwePgh7 = fEXMiAyG3ql4vKB
def fWM9y4vTcPLS0b3UKItC1os5(S6NALBOqGn1zi2W5M8y7,xL3dgJWbrpso=KNIvHPjUbhr(u"ࠩࡂࠫॿ")):
	if mkHKSQvjWr5BTcM3wVY(u"ࠪࡁࠬঀ") in S6NALBOqGn1zi2W5M8y7:
		if xL3dgJWbrpso in S6NALBOqGn1zi2W5M8y7: NPM3HKQ57xe,AhVYZ2F1brKceuPj = S6NALBOqGn1zi2W5M8y7.split(xL3dgJWbrpso,GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"࠷ଵ"))
		else: NPM3HKQ57xe,AhVYZ2F1brKceuPj = hWGMqtBy4wuLaVcj,S6NALBOqGn1zi2W5M8y7
		AhVYZ2F1brKceuPj = AhVYZ2F1brKceuPj.split(QVDJLRlxNg127jMX(u"ࠫࠫ࠭ঁ"))
		OucJVrWRKSqDChiG7yn3oz0dafZF = {}
		for Ar8TEOixgRvBMhwmNSes4Kp0DYZqlk in AhVYZ2F1brKceuPj:
			jKJu4sm3FwBXipMExahVcdgRQUr7,R1Rpns76wZd9NljL8fyUg = Ar8TEOixgRvBMhwmNSes4Kp0DYZqlk.split(wwPrSDa21lUh(u"ࠬࡃࠧং"),GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"࠱ଶ"))
			OucJVrWRKSqDChiG7yn3oz0dafZF[jKJu4sm3FwBXipMExahVcdgRQUr7] = R1Rpns76wZd9NljL8fyUg
	else: NPM3HKQ57xe,OucJVrWRKSqDChiG7yn3oz0dafZF = S6NALBOqGn1zi2W5M8y7,{}
	return NPM3HKQ57xe,OucJVrWRKSqDChiG7yn3oz0dafZF
def RqfZ4ma8Jjh9EU(wJUqaIAzvtsMSEZlKV):
	xjH0QDzE62GZmWbKMsTY19ka,ITlpOFqLn7W2hYkdijCogm,Xs0Tvug5mC9nbkaI64P = hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj
	wJUqaIAzvtsMSEZlKV = wJUqaIAzvtsMSEZlKV.replace(w4GYEC6fmU2g7H,hWGMqtBy4wuLaVcj).replace(cc6SBsG2vlpjPd8yERNW1AJDZM,hWGMqtBy4wuLaVcj)
	p05pq1QcdOZrzXMJs3I7VTUjEHxKa = trdVA0JvFaD.findall(hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"࠭ࠨ࠯ࠫ࡟࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌ࠰࠹ࡅ࠴ࡊࡡࡣࠨ࡝ࡹ࡟ࡻࡡࡽࠩࠡ࠭࡟࡟ࡡ࠵ࡃࡐࡎࡒࡖࡡࡣࠨ࠯ࠬࡂ࠭ࠩ࠭ঃ"),wJUqaIAzvtsMSEZlKV,trdVA0JvFaD.DOTALL)
	if p05pq1QcdOZrzXMJs3I7VTUjEHxKa: xjH0QDzE62GZmWbKMsTY19ka,ITlpOFqLn7W2hYkdijCogm,wJUqaIAzvtsMSEZlKV = p05pq1QcdOZrzXMJs3I7VTUjEHxKa[ybdv7XcT3lxF6QezULwCAGk]
	if xjH0QDzE62GZmWbKMsTY19ka not in [Mpsm2VF1OBnCRvK3qf6,gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠧ࠭ࠩ঄"),hWGMqtBy4wuLaVcj]: Xs0Tvug5mC9nbkaI64P = HHoGx7Flus60(u"ࠨࡡࡐࡓࡉࡥࠧঅ")
	if ITlpOFqLn7W2hYkdijCogm: ITlpOFqLn7W2hYkdijCogm = LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠩࡢࠫআ")+ITlpOFqLn7W2hYkdijCogm+SqrG5mU3j96ldsFpExobw40TJY(u"ࠪࡣࠬই")
	wJUqaIAzvtsMSEZlKV = ITlpOFqLn7W2hYkdijCogm+Xs0Tvug5mC9nbkaI64P+wJUqaIAzvtsMSEZlKV
	return wJUqaIAzvtsMSEZlKV
def jkiCS0UWs2dNAJcGKn6mbHD(S6NALBOqGn1zi2W5M8y7):
	return _IDzPpAg07NQOCksoWT5(S6NALBOqGn1zi2W5M8y7)
def vikbdSOtZJFz6gQeL(SWvj3CK2nqw):
	eR1ThH9pjJbK2Y0tuVDB5 = {o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠫࡹࡿࡰࡦࠩঈ"):hWGMqtBy4wuLaVcj,LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠬࡳ࡯ࡥࡧࠪউ"):hWGMqtBy4wuLaVcj,ITvnUAMXsyb4eO(u"࠭ࡵࡳ࡮ࠪঊ"):hWGMqtBy4wuLaVcj,NeO3CTLHrPfWUoIgy8Q(u"ࠧࡵࡧࡻࡸࠬঋ"):hWGMqtBy4wuLaVcj,e2qDYgipPmTw4KvBLnochr(u"ࠨࡲࡤ࡫ࡪ࠭ঌ"):hWGMqtBy4wuLaVcj,A6dMB1FlgxVivJ2fk9C(u"ࠩࡱࡥࡲ࡫ࠧ঍"):hWGMqtBy4wuLaVcj,JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠪ࡭ࡲࡧࡧࡦࠩ঎"):hWGMqtBy4wuLaVcj,A6dMB1FlgxVivJ2fk9C(u"ࠫࡨࡵ࡮ࡵࡧࡻࡸࠬএ"):hWGMqtBy4wuLaVcj,zyvJMtBhrw(u"ࠬ࡯࡮ࡧࡱࡧ࡭ࡨࡺࠧঐ"):hWGMqtBy4wuLaVcj}
	if SqrG5mU3j96ldsFpExobw40TJY(u"࠭࠿ࠨ঑") in SWvj3CK2nqw: SWvj3CK2nqw = SWvj3CK2nqw.split(MMizeNH0AKu(u"ࠧࡀࠩ঒"),bXukYxQ4aHw)[bXukYxQ4aHw]
	NPM3HKQ57xe,hJnSi03d4Go = fWM9y4vTcPLS0b3UKItC1os5(SWvj3CK2nqw)
	aargs = dict(list(eR1ThH9pjJbK2Y0tuVDB5.items())+list(hJnSi03d4Go.items()))
	N4NRFgAPxIVpSlT1tG7C = aargs[ITvnUAMXsyb4eO(u"ࠨ࡯ࡲࡨࡪ࠭ও")]
	sgGd1ecjAftLHVbNKxZP = jkiCS0UWs2dNAJcGKn6mbHD(aargs[DJ1ICpbyR2(u"ࠩࡸࡶࡱ࠭ঔ")])
	aUWfjZh2Xu = jkiCS0UWs2dNAJcGKn6mbHD(aargs[QvgnCALNstmuUJiET(u"ࠪࡸࡪࡾࡴࠨক")])
	WeCH6nsUT5Q7 = jkiCS0UWs2dNAJcGKn6mbHD(aargs[zyvJMtBhrw(u"ࠫࡵࡧࡧࡦࠩখ")])
	FE9OmZkMHn = jkiCS0UWs2dNAJcGKn6mbHD(aargs[OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠬࡺࡹࡱࡧࠪগ")])
	a17pX2NESVdbAHhflt0zITe8xcqM = jkiCS0UWs2dNAJcGKn6mbHD(aargs[DJ1ICpbyR2(u"࠭࡮ࡢ࡯ࡨࠫঘ")])
	Ogyr7b1scVTD4fhRS0Bv2lMH6 = jkiCS0UWs2dNAJcGKn6mbHD(aargs[gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠧࡪ࡯ࡤ࡫ࡪ࠭ঙ")])
	kHSDtO6x4QU = aargs[KNIvHPjUbhr(u"ࠨࡥࡲࡲࡹ࡫ࡸࡵࠩচ")]
	UuWjwOKB8F = jkiCS0UWs2dNAJcGKn6mbHD(aargs[FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠩ࡬ࡲ࡫ࡵࡤࡪࡥࡷࠫছ")])
	if UuWjwOKB8F: UuWjwOKB8F = eval(UuWjwOKB8F)
	else: UuWjwOKB8F = {}
	if not N4NRFgAPxIVpSlT1tG7C: FE9OmZkMHn = e2qDYgipPmTw4KvBLnochr(u"ࠪࡪࡴࡲࡤࡦࡴࠪজ") ; N4NRFgAPxIVpSlT1tG7C = ITvnUAMXsyb4eO(u"ࠫ࠷࠼࠰ࠨঝ")
	return FE9OmZkMHn,a17pX2NESVdbAHhflt0zITe8xcqM,sgGd1ecjAftLHVbNKxZP,N4NRFgAPxIVpSlT1tG7C,Ogyr7b1scVTD4fhRS0Bv2lMH6,WeCH6nsUT5Q7,aUWfjZh2Xu,kHSDtO6x4QU,UuWjwOKB8F
def qhVEWvetzXLOcr1(xjPuFK3EsIZSiobQ5X):
	cp32mLfGaSjZq = zGjD5QAkd7SO9YPcZl._getframe(bXukYxQ4aHw).f_code.co_name
	if not xjPuFK3EsIZSiobQ5X or not cp32mLfGaSjZq or cp32mLfGaSjZq==EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠬࡂ࡭ࡰࡦࡸࡰࡪࡄࠧঞ"):
		return GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"࡛࠭ࠡࠩট")+W8OofeKN6ndp2Q.upper()+hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠧ࠮ࠩঠ")+aO9cFKo862LqTWlIjy+KNIvHPjUbhr(u"ࠨ࠯ࠪড")+str(guSzmUCXDa1tQpY)+o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠩࠣࡡࠬঢ")
	return o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠪ࠲ࡡࡺࠧণ")+cp32mLfGaSjZq
def KteLZCbM8W0FqE2OBx1(GQLdpWl2kzCJ3r4qhgo5R,oo4bfXvY8EOqAS90Vd):
	if VKiGj1LundAJQwEXcqgxC: oo4bfXvY8EOqAS90Vd = oo4bfXvY8EOqAS90Vd.decode(a7VXeDU82IfQEnPZAdiT).encode(a7VXeDU82IfQEnPZAdiT)
	tag2QluvIPqhNDzM = rkp74Xbt2ajZ
	yefFjNXHl7 = [hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj]
	if GQLdpWl2kzCJ3r4qhgo5R: oo4bfXvY8EOqAS90Vd = oo4bfXvY8EOqAS90Vd.replace(soMVfbr6WtpNlcSA,hWGMqtBy4wuLaVcj).replace(hXB0vKVQ5PRI91SDTprMdfuHEm4,hWGMqtBy4wuLaVcj).replace(YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj)
	else: GQLdpWl2kzCJ3r4qhgo5R = pGYKHZgqFX3B
	Ym8TPuz5DZO7RkwK,xL3dgJWbrpso = hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠫࡡࡺࠧত"),lG0yV5QNFHc2RbXM1Wp
	TUkQVpXSq4PEfKvYtAxe = MMizeNH0AKu(u"࠶࠵ସ")*Mpsm2VF1OBnCRvK3qf6 if H4qZ2hwilNJYTmCFEQyaSs98cPM0gR else LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"࠴࠳ଷ")*Mpsm2VF1OBnCRvK3qf6
	mm4ztuDonOjZrT = jR6BYWNFZ0egmH4Tr2Q78LbSs3t*Ym8TPuz5DZO7RkwK
	if oo4bfXvY8EOqAS90Vd.startswith(zyvJMtBhrw(u"ࠬࡕࡐࡆࡐࡘࡖࡑ࠭থ")): oo4bfXvY8EOqAS90Vd = S1SgCFYGJeMvfp5iZXK(u"࠭࠮࡝ࡶࠪদ")+oo4bfXvY8EOqAS90Vd
	if pKJjfBXL51wlaTAs in GQLdpWl2kzCJ3r4qhgo5R: tag2QluvIPqhNDzM = MMk8qKvcJe4fQHm3EG7diBD5.LOGERROR
	if GQLdpWl2kzCJ3r4qhgo5R in [pGYKHZgqFX3B,pKJjfBXL51wlaTAs]: yefFjNXHl7 = [oo4bfXvY8EOqAS90Vd]
	elif GQLdpWl2kzCJ3r4qhgo5R==VRQE4jsXHSfhPWo5DgLwxGk: yefFjNXHl7 = oo4bfXvY8EOqAS90Vd.split(xL3dgJWbrpso)
	elif GQLdpWl2kzCJ3r4qhgo5R==YYcbiF1UROXlga2:
		e1FSlOgEW4bYJhjVAxf5ycGt = oo4bfXvY8EOqAS90Vd.split(xL3dgJWbrpso)
		yefFjNXHl7 = [e1FSlOgEW4bYJhjVAxf5ycGt[ybdv7XcT3lxF6QezULwCAGk]]
		for dV8hf3cYkFXZ2InK1jJzoiN9aquw7x in range(bXukYxQ4aHw,len(e1FSlOgEW4bYJhjVAxf5ycGt),Y0XZKGRAUQj5O):
			try: LAitCuNefqUpTD4kJP37o6ySQ8M = e1FSlOgEW4bYJhjVAxf5ycGt[dV8hf3cYkFXZ2InK1jJzoiN9aquw7x]+xL3dgJWbrpso+e1FSlOgEW4bYJhjVAxf5ycGt[dV8hf3cYkFXZ2InK1jJzoiN9aquw7x+QvgnCALNstmuUJiET(u"࠴ହ")]
			except: LAitCuNefqUpTD4kJP37o6ySQ8M = e1FSlOgEW4bYJhjVAxf5ycGt[dV8hf3cYkFXZ2InK1jJzoiN9aquw7x]
			yefFjNXHl7.append(LAitCuNefqUpTD4kJP37o6ySQ8M)
	G7QKV0YrdoF3SjJ5gvNxTts48X9 = yefFjNXHl7[ybdv7XcT3lxF6QezULwCAGk]
	for O1wKxLtr08BhHUFaQlVCdk3e5gDpz9 in yefFjNXHl7[bXukYxQ4aHw:]:
		if GQLdpWl2kzCJ3r4qhgo5R in [VRQE4jsXHSfhPWo5DgLwxGk,YYcbiF1UROXlga2]: mm4ztuDonOjZrT += Ym8TPuz5DZO7RkwK
		G7QKV0YrdoF3SjJ5gvNxTts48X9 += y6eSQlZEV8uwKG5M3+TUkQVpXSq4PEfKvYtAxe+mm4ztuDonOjZrT+O1wKxLtr08BhHUFaQlVCdk3e5gDpz9
	G7QKV0YrdoF3SjJ5gvNxTts48X9 += e2qDYgipPmTw4KvBLnochr(u"ࠧࠡࡡࠪধ")
	if hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠨࠧࠪন") in G7QKV0YrdoF3SjJ5gvNxTts48X9: G7QKV0YrdoF3SjJ5gvNxTts48X9 = jkiCS0UWs2dNAJcGKn6mbHD(G7QKV0YrdoF3SjJ5gvNxTts48X9)
	MMk8qKvcJe4fQHm3EG7diBD5.log(G7QKV0YrdoF3SjJ5gvNxTts48X9,level=tag2QluvIPqhNDzM)
	return
def ZX6AGYSgqrUBTw9I8WDNpuE2eCink4(mZbI1QrGfFn42UKRPNSpzx7w):
	try: WFYAlCyzGj1H32ovtQLnBTqhS6X = pbXIg7UFi4dV.connect(mZbI1QrGfFn42UKRPNSpzx7w,check_same_thread=rwQN9AKhLCuMfHxjlbX0U(u"ࡇࡣ࡯ࡷࡪ୯"))
	except:
		if not WQvYkNg7SysPFLitlGEn6.path.exists(vA0ImpguajeHKJ6P):
			WQvYkNg7SysPFLitlGEn6.makedirs(vA0ImpguajeHKJ6P)
			WFYAlCyzGj1H32ovtQLnBTqhS6X = pbXIg7UFi4dV.connect(mZbI1QrGfFn42UKRPNSpzx7w,check_same_thread=sULh4NjakzI8He7xJCMGrql(u"ࡈࡤࡰࡸ࡫୰"))
	WFYAlCyzGj1H32ovtQLnBTqhS6X.text_factory = str
	Z8gcWPFXkx7oSrR2D = WFYAlCyzGj1H32ovtQLnBTqhS6X.cursor()
	Z8gcWPFXkx7oSrR2D.execute(ITvnUAMXsyb4eO(u"ࠩࡓࡖࡆࡍࡍࡂࠢࡤࡹࡹࡵ࡭ࡢࡶ࡬ࡧࡤ࡯࡮ࡥࡧࡻࡁࡳࡵ࠻ࠨ঩"))
	Z8gcWPFXkx7oSrR2D.execute(NeO3CTLHrPfWUoIgy8Q(u"ࠪࡔࡗࡇࡇࡎࡃࠣ࡭࡬ࡴ࡯ࡳࡧࡢࡧ࡭࡫ࡣ࡬ࡡࡦࡳࡳࡹࡴࡳࡣ࡬ࡲࡹࡹ࠽ࡺࡧࡶ࠿ࠬপ"))
	Z8gcWPFXkx7oSrR2D.execute(HHoGx7Flus60(u"ࠫࡕࡘࡁࡈࡏࡄࠤ࡯ࡵࡵࡳࡰࡤࡰࡤࡳ࡯ࡥࡧࡀࡓࡋࡌ࠻ࠨফ"))
	Z8gcWPFXkx7oSrR2D.execute(e2qDYgipPmTw4KvBLnochr(u"ࠬࡖࡒࡂࡉࡐࡅࠥࡹࡹ࡯ࡥ࡫ࡶࡴࡴ࡯ࡶࡵࡀࡓࡋࡌ࠻ࠨব"))
	ayNEJoZrebx2usT = r9LBIvPTxF83(mZbI1QrGfFn42UKRPNSpzx7w,WFYAlCyzGj1H32ovtQLnBTqhS6X,Z8gcWPFXkx7oSrR2D,fEXMiAyG3ql4vKB,HHoGx7Flus60(u"࠭ࡂࡆࡉࡌࡒࠥࡏࡍࡎࡇࡇࡍࡆ࡚ࡅࠡࡖࡕࡅࡓ࡙ࡁࡄࡖࡌࡓࡓࠦ࠻ࠨভ"))
	if ayNEJoZrebx2usT: WFYAlCyzGj1H32ovtQLnBTqhS6X.commit()
	else:
		import yoY3NdGViS
		yoY3NdGViS.BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪম"),hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠨษ็ฬึ์วๆฮࠣ฾๏ืࠠใษาีࠥษๆࠡ์ึฮำีๅࠡษ็้้็ࠠศๆัหฺࠦศใษ฼ำฮࠦศ๋ษ้หฯํࠠ࠯࠰ࠣ์ุฮศ้ࠡำ๋ࠥอไๆึๆ่ฮࠦโะࠢํ็ํ์ࠠศๆัีําࠠๆ่ࠣห้ฮั็ษ่ะࠥฮี้ำฬࠤ฿๐ัࠡืะ๎าฯࠠ࡝ࡰ࡟ࡲ๊ࠥอๅࠢสฺ่๊ใๅหࠣะึฮࠠฦูไหฦࠦใ้ัํࠤํหูศัฬࠤฯฺฺ๋ๆ๊ࠤ࠳࠴ࠠฤ๊ࠣะึฮࠠฦูไหฦࠦวๅฮ๊หื่ࠦฦ฻สำฮࠦสี฼ํ่์࠭য"))
		vn97kbzpVDXotqS6RhuK2srl()
	return WFYAlCyzGj1H32ovtQLnBTqhS6X,Z8gcWPFXkx7oSrR2D
def r9LBIvPTxF83(mZbI1QrGfFn42UKRPNSpzx7w,WFYAlCyzGj1H32ovtQLnBTqhS6X,Z8gcWPFXkx7oSrR2D,rEQtGb7WUkmaKnovPHx83Z2gul,bbZhB2ugDNt89EP3lkfoJMxpV,plsrZL25TE1tNDyjMIKanAqb=()):
	try:
		if rEQtGb7WUkmaKnovPHx83Z2gul: Z8gcWPFXkx7oSrR2D.executemany(bbZhB2ugDNt89EP3lkfoJMxpV,plsrZL25TE1tNDyjMIKanAqb)
		else: Z8gcWPFXkx7oSrR2D.execute(bbZhB2ugDNt89EP3lkfoJMxpV,plsrZL25TE1tNDyjMIKanAqb)
		WFYAlCyzGj1H32ovtQLnBTqhS6X.commit()
		ayNEJoZrebx2usT = VBlawK4mgHSyLEn8iqhUkz5
	except:
		ayNEJoZrebx2usT,timeout = fEXMiAyG3ql4vKB,KNIvHPjUbhr(u"࠹଺")
		GVN6E3rPXdvTUp7sAcCDeqkZLSng = HB5PvxRhwM.time()
		while HB5PvxRhwM.time()-GVN6E3rPXdvTUp7sAcCDeqkZLSng<timeout and not ayNEJoZrebx2usT:
			try:
				if rEQtGb7WUkmaKnovPHx83Z2gul: Z8gcWPFXkx7oSrR2D.executemany(bbZhB2ugDNt89EP3lkfoJMxpV,plsrZL25TE1tNDyjMIKanAqb)
				else: Z8gcWPFXkx7oSrR2D.execute(bbZhB2ugDNt89EP3lkfoJMxpV,plsrZL25TE1tNDyjMIKanAqb)
				WFYAlCyzGj1H32ovtQLnBTqhS6X.commit()
				ayNEJoZrebx2usT = VBlawK4mgHSyLEn8iqhUkz5
			except: HB5PvxRhwM.sleep(A6dMB1FlgxVivJ2fk9C(u"࠵࠴࠲࠶଻"))
		if not ayNEJoZrebx2usT:
			KteLZCbM8W0FqE2OBx1(VRQE4jsXHSfhPWo5DgLwxGk,LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠩ࠱ࡠࡹ࡛࡮ࡢࡤ࡯ࡩࠥࡺ࡯ࠡࡹࡵ࡭ࡹ࡫ࠠࡵࡱࠣࡸ࡭࡫ࠠࡥࡣࡷࡥࡧࡧࡳࡦࠢࡩ࡭ࡱ࡫ࠠࠡࠢࠪর")+mZbI1QrGfFn42UKRPNSpzx7w+XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠪࠤࠥࠦࡆࡢ࡫࡯ࡩࡩࠦࡷࡩࡧࡱࠤࡪࡾࡥࡤࡷࡷ࡭ࡳ࡭ࠠࡵࡪ࡬ࡷࠥࡹࡴࡢࡶࡨࡱࡪࡴࡴࠡࠢࠣࠫ঱")+bbZhB2ugDNt89EP3lkfoJMxpV+NXMOzZjYsmS9pf)
			import yoY3NdGViS
			yoY3NdGViS.OnsAxhdVjZF(GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠫๆฺไࠡใํࠤ็อูะหࠣห้ฮ๊ศ่สฮࠬল"),XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠬࡌࡡࡪ࡮ࡸࡶࡪ࠭঳"))
	return ayNEJoZrebx2usT
def Mqk51CFBym0pIQXZLsOxSJ(mZbI1QrGfFn42UKRPNSpzx7w,YGI85DN9P76z02eik,lempRB38tIw,e1YbfJTpiuK4tjaCd0FMNQOLVWc=None):
	F49URk16JIawgp7YWZAXGtnMb = BOkRoCi42L7VQFyPsJ51WpSdEY(YGI85DN9P76z02eik)
	QKFp5qOk03PnabuZHR1GC42 = ee8c0jzrTntGSUdRJm.getSetting(NeO3CTLHrPfWUoIgy8Q(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰࡫ࡸࡹࡶࡣࡢࡥ࡫ࡩࠬ঴"))
	if lempRB38tIw not in [ITvnUAMXsyb4eO(u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪ঵"),wwPrSDa21lUh(u"ࠨࡉࡏࡓࡇࡇࡌࡔࡇࡄࡖࡈࡎ࡟ࡔࡒࡏࡍ࡙࡚ࡅࡅࡡࡄࡐࡑ࠭শ"),zyvJMtBhrw(u"ࠩࡊࡐࡔࡈࡁࡍࡕࡈࡅࡗࡉࡈࡠࡕࡓࡐࡎ࡚ࡔࡆࡆࡢࡋࡔࡕࡇࡍࡇࠪষ")] and mZbI1QrGfFn42UKRPNSpzx7w==MM5Dx39f7ULhcJsRptzIowP and e1YbfJTpiuK4tjaCd0FMNQOLVWc!=wwPrSDa21lUh(u"ࠪࡑࡊ࡙ࡓࡂࡉࡈࡗࠬস"):
		if QKFp5qOk03PnabuZHR1GC42==DJ1ICpbyR2(u"ࠫࡘ࡚ࡏࡑࠩহ"): return F49URk16JIawgp7YWZAXGtnMb
		agkF7iSBOZ4DKJC25yztrsN86cXLfV = ee8c0jzrTntGSUdRJm.getSetting(MMizeNH0AKu(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡴࡨࡪࡷ࡫ࡳࡩࠩ঺"))
		if agkF7iSBOZ4DKJC25yztrsN86cXLfV==KBkxSYaz93pu1(u"࠭ࡒࡆࡈࡕࡉࡘࡎ࡟ࡄࡃࡆࡌࡊ࠭঻"):
			pMPR1Cc0usZ6nJTU(mZbI1QrGfFn42UKRPNSpzx7w,lempRB38tIw,e1YbfJTpiuK4tjaCd0FMNQOLVWc)
			return F49URk16JIawgp7YWZAXGtnMb
	FPUWRVbmSqg9Xo6tw7lsKONcf3Qn = ybdv7XcT3lxF6QezULwCAGk
	if QKFp5qOk03PnabuZHR1GC42==jeAby54c02TgG8zuivonX91(u"ࠧࡍࡋࡐࡍ࡙ࡋࡄࠨ়"): FPUWRVbmSqg9Xo6tw7lsKONcf3Qn = gVRmOBQA8Lse7aojcU5nSl4G2N
	WFYAlCyzGj1H32ovtQLnBTqhS6X,Z8gcWPFXkx7oSrR2D = ZX6AGYSgqrUBTw9I8WDNpuE2eCink4(mZbI1QrGfFn42UKRPNSpzx7w)
	Lw9QacS0ZVJR5jMOAb6BdH = Z8gcWPFXkx7oSrR2D.execute(rwQN9AKhLCuMfHxjlbX0U(u"ࠨࡕࡈࡐࡊࡉࡔࠡࡰࡤࡱࡪࠦࡆࡓࡑࡐࠤࡸࡷ࡬ࡪࡶࡨࡣࡲࡧࡳࡵࡧࡵࠤ࡜ࡎࡅࡓࡇࠣࡸࡾࡶࡥ࠾ࠤࡷࡥࡧࡲࡥࠣࠢࡄࡒࡉࠦ࡮ࡢ࡯ࡨࡁࠧ࠭ঽ")+lempRB38tIw+rwQN9AKhLCuMfHxjlbX0U(u"ࠩࠥࠤࡀ࠭া")).fetchall()
	if Lw9QacS0ZVJR5jMOAb6BdH:
		if FPUWRVbmSqg9Xo6tw7lsKONcf3Qn: r9LBIvPTxF83(mZbI1QrGfFn42UKRPNSpzx7w,WFYAlCyzGj1H32ovtQLnBTqhS6X,Z8gcWPFXkx7oSrR2D,fEXMiAyG3ql4vKB,dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠪࡈࡊࡒࡅࡕࡇࠣࡊࡗࡕࡍࠡࠤࠪি")+lempRB38tIw+S1SgCFYGJeMvfp5iZXK(u"ࠫࠧࠦࡗࡉࡇࡕࡉࠥ࡫ࡸࡱ࡫ࡵࡽࡃ࠭ী")+str(IHKJoQ8PwW4pNBR6GTAMVz2hdfC5my+FPUWRVbmSqg9Xo6tw7lsKONcf3Qn)+o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠬࠦ࠻ࠨু"))
		r9LBIvPTxF83(mZbI1QrGfFn42UKRPNSpzx7w,WFYAlCyzGj1H32ovtQLnBTqhS6X,Z8gcWPFXkx7oSrR2D,fEXMiAyG3ql4vKB,wwPrSDa21lUh(u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࠧ࠭ূ")+lempRB38tIw+HHoGx7Flus60(u"࡚ࠧࠣࠢࡌࡊࡘࡅࠡࡧࡻࡴ࡮ࡸࡹ࠽ࠩৃ")+str(IHKJoQ8PwW4pNBR6GTAMVz2hdfC5my)+hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠨࠢ࠾ࠫৄ"))
		if e1YbfJTpiuK4tjaCd0FMNQOLVWc:
			dBp9at3GjN = (str(e1YbfJTpiuK4tjaCd0FMNQOLVWc),)
			Z8gcWPFXkx7oSrR2D.execute(o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠩࡖࡉࡑࡋࡃࡕࠢࡧࡥࡹࡧࠠࡇࡔࡒࡑࠥࠨࠧ৅")+lempRB38tIw+dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠪࠦࠥ࡝ࡈࡆࡔࡈࠤࡨࡵ࡬ࡶ࡯ࡱࠤࡂࠦ࠿ࠡ࠽ࠪ৆"),dBp9at3GjN)
			pUD0WVmgIR7 = Z8gcWPFXkx7oSrR2D.fetchall()
			if pUD0WVmgIR7:
				try:
					XNBHzrlKD9yW = IZedRkDajQCrHAM4mOPtNEKzc70vF.decompress(pUD0WVmgIR7[ybdv7XcT3lxF6QezULwCAGk][ybdv7XcT3lxF6QezULwCAGk])
					F49URk16JIawgp7YWZAXGtnMb = Jfn98z6aWOokIrXYl4jQdTEiRBFqeC.loads(XNBHzrlKD9yW)
				except: pass
		else:
			Z8gcWPFXkx7oSrR2D.execute(CnbBKmtF1x84q7AW(u"ࠫࡘࡋࡌࡆࡅࡗࠤࡨࡵ࡬ࡶ࡯ࡱ࠰ࡩࡧࡴࡢࠢࡉࡖࡔࡓࠠࠣࠩে")+lempRB38tIw+e2qDYgipPmTw4KvBLnochr(u"ࠬࠨࠠ࠼ࠩৈ"))
			pUD0WVmgIR7 = Z8gcWPFXkx7oSrR2D.fetchall()
			if pUD0WVmgIR7:
				F49URk16JIawgp7YWZAXGtnMb,joqFxhiR1eA0I6ydS5fU = {},[]
				for WdCOioPfIDFRbg8YsZqw6nXv5c4zl0,OucJVrWRKSqDChiG7yn3oz0dafZF in pUD0WVmgIR7:
					XVfzajwpqTB4R8xdEKDt = IZedRkDajQCrHAM4mOPtNEKzc70vF.decompress(OucJVrWRKSqDChiG7yn3oz0dafZF)
					OucJVrWRKSqDChiG7yn3oz0dafZF = Jfn98z6aWOokIrXYl4jQdTEiRBFqeC.loads(XVfzajwpqTB4R8xdEKDt)
					F49URk16JIawgp7YWZAXGtnMb[WdCOioPfIDFRbg8YsZqw6nXv5c4zl0] = OucJVrWRKSqDChiG7yn3oz0dafZF
					joqFxhiR1eA0I6ydS5fU.append(WdCOioPfIDFRbg8YsZqw6nXv5c4zl0)
				if joqFxhiR1eA0I6ydS5fU:
					F49URk16JIawgp7YWZAXGtnMb[OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"࠭࡟ࡠࡕࡈࡕ࡚ࡋࡎࡄࡇࡇࡣࡈࡕࡌࡖࡏࡑࡗࡤࡥࠧ৉")] = joqFxhiR1eA0I6ydS5fU
					if YGI85DN9P76z02eik==GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠧ࡭࡫ࡶࡸࠬ৊"): F49URk16JIawgp7YWZAXGtnMb = joqFxhiR1eA0I6ydS5fU
	WFYAlCyzGj1H32ovtQLnBTqhS6X.close()
	return F49URk16JIawgp7YWZAXGtnMb
def BxuD7iQRpW1(mZbI1QrGfFn42UKRPNSpzx7w,lempRB38tIw,e1YbfJTpiuK4tjaCd0FMNQOLVWc,F49URk16JIawgp7YWZAXGtnMb,bmLaIdZsF0AKOeQWN14rBx58R,Tz7xXZjAHf=fEXMiAyG3ql4vKB):
	QKFp5qOk03PnabuZHR1GC42 = ee8c0jzrTntGSUdRJm.getSetting(KNIvHPjUbhr(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲࡭ࡺࡴࡱࡥࡤࡧ࡭࡫ࠧো"))
	if QKFp5qOk03PnabuZHR1GC42==KBkxSYaz93pu1(u"ࠩࡏࡍࡒࡏࡔࡆࡆࠪৌ") and bmLaIdZsF0AKOeQWN14rBx58R>gVRmOBQA8Lse7aojcU5nSl4G2N: bmLaIdZsF0AKOeQWN14rBx58R = gVRmOBQA8Lse7aojcU5nSl4G2N
	if Tz7xXZjAHf:
		pp9oFfEkKX74znPZ,RxS0A5tZ3QYHOX8C7ygproI = [],[]
		for JpzD0lv9cYM6XrHeqCa in range(len(e1YbfJTpiuK4tjaCd0FMNQOLVWc)):
			XNBHzrlKD9yW = Jfn98z6aWOokIrXYl4jQdTEiRBFqeC.dumps(F49URk16JIawgp7YWZAXGtnMb[JpzD0lv9cYM6XrHeqCa])
			BvSyM62WO7r0KZCAeks3u = IZedRkDajQCrHAM4mOPtNEKzc70vF.compress(XNBHzrlKD9yW)
			pp9oFfEkKX74znPZ.append((e1YbfJTpiuK4tjaCd0FMNQOLVWc[JpzD0lv9cYM6XrHeqCa],))
			RxS0A5tZ3QYHOX8C7ygproI.append((bmLaIdZsF0AKOeQWN14rBx58R+IHKJoQ8PwW4pNBR6GTAMVz2hdfC5my,str(e1YbfJTpiuK4tjaCd0FMNQOLVWc[JpzD0lv9cYM6XrHeqCa]),BvSyM62WO7r0KZCAeks3u))
	else:
		XNBHzrlKD9yW = Jfn98z6aWOokIrXYl4jQdTEiRBFqeC.dumps(F49URk16JIawgp7YWZAXGtnMb)
		HDkISbcQMqAJfTYXeKPZjEpsG0 = IZedRkDajQCrHAM4mOPtNEKzc70vF.compress(XNBHzrlKD9yW)
	WFYAlCyzGj1H32ovtQLnBTqhS6X,Z8gcWPFXkx7oSrR2D = ZX6AGYSgqrUBTw9I8WDNpuE2eCink4(mZbI1QrGfFn42UKRPNSpzx7w)
	r9LBIvPTxF83(mZbI1QrGfFn42UKRPNSpzx7w,WFYAlCyzGj1H32ovtQLnBTqhS6X,Z8gcWPFXkx7oSrR2D,fEXMiAyG3ql4vKB,KBkxSYaz93pu1(u"ࠪࡇࡗࡋࡁࡕࡇࠣࡘࡆࡈࡌࡆࠢࡌࡊࠥࡔࡏࡕࠢࡈ࡜ࡎ࡙ࡔࡔ্ࠢࠥࠫ")+lempRB38tIw+ITvnUAMXsyb4eO(u"ࠫࠧࠦࠨࡦࡺࡳ࡭ࡷࡿࠬࡤࡱ࡯ࡹࡲࡴࠬࡥࡣࡷࡥ࠮ࠦ࠻ࠨৎ"))
	if Tz7xXZjAHf:
		r9LBIvPTxF83(mZbI1QrGfFn42UKRPNSpzx7w,WFYAlCyzGj1H32ovtQLnBTqhS6X,Z8gcWPFXkx7oSrR2D,VBlawK4mgHSyLEn8iqhUkz5,zyvJMtBhrw(u"ࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࠦࠬ৏")+lempRB38tIw+mkHKSQvjWr5BTcM3wVY(u"࡙࠭ࠢࠡࡋࡉࡗࡋࠠࡤࡱ࡯ࡹࡲࡴࠠ࠾ࠢࡂࠤࡀ࠭৐"),pp9oFfEkKX74znPZ)
		r9LBIvPTxF83(mZbI1QrGfFn42UKRPNSpzx7w,WFYAlCyzGj1H32ovtQLnBTqhS6X,Z8gcWPFXkx7oSrR2D,VBlawK4mgHSyLEn8iqhUkz5,o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠧࡊࡐࡖࡉࡗ࡚ࠠࡊࡐࡗࡓࠥࠨࠧ৑")+lempRB38tIw+HHoGx7Flus60(u"ࠨࠤ࡚ࠣࡆࡒࡕࡆࡕࠣࠬࡄ࠲࠿࠭ࡁࠬࠤࡀ࠭৒"),RxS0A5tZ3QYHOX8C7ygproI)
	else:
		if bmLaIdZsF0AKOeQWN14rBx58R:
			dBp9at3GjN = (str(e1YbfJTpiuK4tjaCd0FMNQOLVWc),)
			r9LBIvPTxF83(mZbI1QrGfFn42UKRPNSpzx7w,WFYAlCyzGj1H32ovtQLnBTqhS6X,Z8gcWPFXkx7oSrR2D,fEXMiAyG3ql4vKB,KNIvHPjUbhr(u"ࠩࡇࡉࡑࡋࡔࡆࠢࡉࡖࡔࡓࠠࠣࠩ৓")+lempRB38tIw+HHoGx7Flus60(u"ࠪࠦࠥ࡝ࡈࡆࡔࡈࠤࡨࡵ࡬ࡶ࡯ࡱࠤࡂࠦ࠿ࠡ࠽ࠪ৔"),dBp9at3GjN)
			dBp9at3GjN = (bmLaIdZsF0AKOeQWN14rBx58R+IHKJoQ8PwW4pNBR6GTAMVz2hdfC5my,str(e1YbfJTpiuK4tjaCd0FMNQOLVWc),HDkISbcQMqAJfTYXeKPZjEpsG0)
			r9LBIvPTxF83(mZbI1QrGfFn42UKRPNSpzx7w,WFYAlCyzGj1H32ovtQLnBTqhS6X,Z8gcWPFXkx7oSrR2D,fEXMiAyG3ql4vKB,KBkxSYaz93pu1(u"ࠫࡎࡔࡓࡆࡔࡗࠤࡎࡔࡔࡐࠢࠥࠫ৕")+lempRB38tIw+o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠬࠨࠠࡗࡃࡏ࡙ࡊ࡙ࠠࠩࡁ࠯ࡃ࠱ࡅࠩࠡ࠽ࠪ৖"),dBp9at3GjN)
		else:
			dBp9at3GjN = (HDkISbcQMqAJfTYXeKPZjEpsG0,str(e1YbfJTpiuK4tjaCd0FMNQOLVWc))
			r9LBIvPTxF83(mZbI1QrGfFn42UKRPNSpzx7w,WFYAlCyzGj1H32ovtQLnBTqhS6X,Z8gcWPFXkx7oSrR2D,fEXMiAyG3ql4vKB,gDuGMR3z1aV6YdLmCpiO8Kl(u"࠭ࡕࡑࡆࡄࡘࡊࠦࠢࠨৗ")+lempRB38tIw+SqrG5mU3j96ldsFpExobw40TJY(u"ࠧࠣࠢࡖࡉ࡙ࠦࡤࡢࡶࡤࠤࡂࠦ࠿࡙ࠡࡋࡉࡗࡋࠠࡤࡱ࡯ࡹࡲࡴࠠ࠾ࠢࡂࠤࡀ࠭৘"),dBp9at3GjN)
	WFYAlCyzGj1H32ovtQLnBTqhS6X.close()
	return
def pMPR1Cc0usZ6nJTU(mZbI1QrGfFn42UKRPNSpzx7w,lempRB38tIw,e1YbfJTpiuK4tjaCd0FMNQOLVWc=None):
	WFYAlCyzGj1H32ovtQLnBTqhS6X,Z8gcWPFXkx7oSrR2D = ZX6AGYSgqrUBTw9I8WDNpuE2eCink4(mZbI1QrGfFn42UKRPNSpzx7w)
	if e1YbfJTpiuK4tjaCd0FMNQOLVWc==None: r9LBIvPTxF83(mZbI1QrGfFn42UKRPNSpzx7w,WFYAlCyzGj1H32ovtQLnBTqhS6X,Z8gcWPFXkx7oSrR2D,fEXMiAyG3ql4vKB,wwPrSDa21lUh(u"ࠨࡆࡕࡓࡕࠦࡔࡂࡄࡏࡉࠥࡏࡆࠡࡇ࡛ࡍࡘ࡚ࡓࠡࠤࠪ৙")+lempRB38tIw+OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠩࠥࠤࡀ࠭৚"))
	else:
		Lw9QacS0ZVJR5jMOAb6BdH = Z8gcWPFXkx7oSrR2D.execute(LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠪࡗࡊࡒࡅࡄࡖࠣࡲࡦࡳࡥࠡࡈࡕࡓࡒࠦࡳࡲ࡮࡬ࡸࡪࡥ࡭ࡢࡵࡷࡩࡷࠦࡗࡉࡇࡕࡉࠥࡺࡹࡱࡧࡀࠦࡹࡧࡢ࡭ࡧࠥࠤࡆࡔࡄࠡࡰࡤࡱࡪࡃࠢࠨ৛")+lempRB38tIw+MMizeNH0AKu(u"ࠫࠧࠦ࠻ࠨড়")).fetchall()
		if Lw9QacS0ZVJR5jMOAb6BdH:
			dBp9at3GjN = (str(e1YbfJTpiuK4tjaCd0FMNQOLVWc),)
			if hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠬࠫࠧঢ়") in e1YbfJTpiuK4tjaCd0FMNQOLVWc: r9LBIvPTxF83(mZbI1QrGfFn42UKRPNSpzx7w,WFYAlCyzGj1H32ovtQLnBTqhS6X,Z8gcWPFXkx7oSrR2D,fEXMiAyG3ql4vKB,QVDJLRlxNg127jMX(u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࠧ࠭৞")+lempRB38tIw+DJ1ICpbyR2(u"࡚ࠧࠣࠢࡌࡊࡘࡅࠡࡥࡲࡰࡺࡳ࡮ࠡ࡮࡬࡯ࡪࠦ࠿ࠡ࠽ࠪয়"),dBp9at3GjN)
			else: r9LBIvPTxF83(mZbI1QrGfFn42UKRPNSpzx7w,WFYAlCyzGj1H32ovtQLnBTqhS6X,Z8gcWPFXkx7oSrR2D,fEXMiAyG3ql4vKB,FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠨࡆࡈࡐࡊ࡚ࡅࠡࡈࡕࡓࡒࠦࠢࠨৠ")+lempRB38tIw+gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠩࠥࠤ࡜ࡎࡅࡓࡇࠣࡧࡴࡲࡵ࡮ࡰࠣࡁࠥࡅࠠ࠼ࠩৡ"),dBp9at3GjN)
	WFYAlCyzGj1H32ovtQLnBTqhS6X.close()
	return
class ZZAil86Ry12xMqwvg(): pass
class aRBhF1OdxM0ek5SwqG(ZZAil86Ry12xMqwvg):
	def __init__(zEcNagLnXdmhIwkOAs628J):
		zEcNagLnXdmhIwkOAs628J.url = hWGMqtBy4wuLaVcj
		zEcNagLnXdmhIwkOAs628J.code = -XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"࠿࠹଼")
		zEcNagLnXdmhIwkOAs628J.reason = hWGMqtBy4wuLaVcj
		zEcNagLnXdmhIwkOAs628J.content = hWGMqtBy4wuLaVcj
		zEcNagLnXdmhIwkOAs628J.headers = {}
		zEcNagLnXdmhIwkOAs628J.cookies = {}
		zEcNagLnXdmhIwkOAs628J.succeeded = fEXMiAyG3ql4vKB
def BOkRoCi42L7VQFyPsJ51WpSdEY(X3X4Y8RzxSVfZJUFDe):
	if X3X4Y8RzxSVfZJUFDe==mkHKSQvjWr5BTcM3wVY(u"ࠪࡨ࡮ࡩࡴࠨৢ"): F49URk16JIawgp7YWZAXGtnMb = {}
	elif X3X4Y8RzxSVfZJUFDe==rwQN9AKhLCuMfHxjlbX0U(u"ࠫࡱ࡯ࡳࡵࠩৣ"): F49URk16JIawgp7YWZAXGtnMb = []
	elif X3X4Y8RzxSVfZJUFDe==mkHKSQvjWr5BTcM3wVY(u"ࠬࡺࡵࡱ࡮ࡨࠫ৤"): F49URk16JIawgp7YWZAXGtnMb = ()
	elif X3X4Y8RzxSVfZJUFDe==sULh4NjakzI8He7xJCMGrql(u"࠭ࡳࡵࡴࠪ৥"): F49URk16JIawgp7YWZAXGtnMb = hWGMqtBy4wuLaVcj
	elif X3X4Y8RzxSVfZJUFDe==CnbBKmtF1x84q7AW(u"ࠧࡪࡰࡷࠫ০"): F49URk16JIawgp7YWZAXGtnMb = ybdv7XcT3lxF6QezULwCAGk
	elif X3X4Y8RzxSVfZJUFDe==MMizeNH0AKu(u"ࠨࡴࡨࡷࡵࡵ࡮ࡴࡧࠪ১"): F49URk16JIawgp7YWZAXGtnMb = aRBhF1OdxM0ek5SwqG()
	elif not X3X4Y8RzxSVfZJUFDe: F49URk16JIawgp7YWZAXGtnMb = None
	else: F49URk16JIawgp7YWZAXGtnMb = None
	return F49URk16JIawgp7YWZAXGtnMb
def NNA8aswIZfdr2(prgxTZUQM2Et16jIYLN0Vusy):
	Jiwdn1CRNbpKra7 = ee8c0jzrTntGSUdRJm.getSetting(EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠩࡤࡺ࠳ࡶࡲࡪࡸࡶ࠵ࠬ২"))
	l0wzB12gfSrxdQ5 = IIvxtojw6EXl2f.splitlines()
	aai2DJRFoduqYezsfZA6WKPTSr = ybdv7XcT3lxF6QezULwCAGk
	RJvIGEwFiSzqyQdhXm = len(prgxTZUQM2Et16jIYLN0Vusy)
	uBU0gipbK6Tsfat1LHMYF7CS = [fEXMiAyG3ql4vKB]*RJvIGEwFiSzqyQdhXm
	for tjCWpV9mT3YrRQAszoPI2id6ZuJb0q in [IHKJoQ8PwW4pNBR6GTAMVz2hdfC5my,IHKJoQ8PwW4pNBR6GTAMVz2hdfC5my-nHBb7jXk0Daom]:
		TimYDwVLFb0yxrJt = str(tjCWpV9mT3YrRQAszoPI2id6ZuJb0q*MMizeNH0AKu(u"࠲࠲࠳࠴࠵࠶࠮࠱ା")/ITvnUAMXsyb4eO(u"࠴࠴࠴࠳࠴࠵ଽ"))[ybdv7XcT3lxF6QezULwCAGk:jeAby54c02TgG8zuivonX91(u"࠶ି")]
		if TimYDwVLFb0yxrJt!=aai2DJRFoduqYezsfZA6WKPTSr:
			for dV8hf3cYkFXZ2InK1jJzoiN9aquw7x in range(RJvIGEwFiSzqyQdhXm):
				if not uBU0gipbK6Tsfat1LHMYF7CS[dV8hf3cYkFXZ2InK1jJzoiN9aquw7x]:
					OYxIojkiHrw1tzhlpg5 = fEXMiAyG3ql4vKB
					for zHI8GkB2Lg1cSmCqeyNodEX6 in l0wzB12gfSrxdQ5:
						G4N2IzuVtwYnLiHEFvd = SqrG5mU3j96ldsFpExobw40TJY(u"ࠪ࡜࠶࠿ࠧ৩")+prgxTZUQM2Et16jIYLN0Vusy[dV8hf3cYkFXZ2InK1jJzoiN9aquw7x]+LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠫ࠶࠾࠽ࠨ৪")+zHI8GkB2Lg1cSmCqeyNodEX6[-zyvJMtBhrw(u"࠵࠸ୀ"):]+aO9cFKo862LqTWlIjy+TimYDwVLFb0yxrJt
						G4N2IzuVtwYnLiHEFvd = xcRlSgBrOhKz69LNou0f8D5MVem.md5(G4N2IzuVtwYnLiHEFvd.encode(a7VXeDU82IfQEnPZAdiT)).hexdigest()[:DJ1ICpbyR2(u"࠷࠷ୁ")]
						if G4N2IzuVtwYnLiHEFvd in Jiwdn1CRNbpKra7:
							OYxIojkiHrw1tzhlpg5 = VBlawK4mgHSyLEn8iqhUkz5
							break
					uBU0gipbK6Tsfat1LHMYF7CS[dV8hf3cYkFXZ2InK1jJzoiN9aquw7x] = OYxIojkiHrw1tzhlpg5
		aai2DJRFoduqYezsfZA6WKPTSr = TimYDwVLFb0yxrJt
	return uBU0gipbK6Tsfat1LHMYF7CS
class ZbAY8pMkFvzJWaNQj7B(wwF217xRKfBAm):
	def __init__(zEcNagLnXdmhIwkOAs628J): pass
	def MQfhP9Ym241(zEcNagLnXdmhIwkOAs628J,iyEphnMXfCWGa):
		zEcNagLnXdmhIwkOAs628J.aYNj9my0BglzWKEntZo = GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠬࡨ࡬ࡰࡥ࡮ࡩࡩ࠭৫") if MmcgqAlsFt.j0juxvCpdOFDk2 else hWGMqtBy4wuLaVcj
		zEcNagLnXdmhIwkOAs628J.iyEphnMXfCWGa = iyEphnMXfCWGa
		if not MmcgqAlsFt.sTZjaIcENd:
			import yoY3NdGViS
			yoY3NdGViS.bXjeBx6vV52PfJpcKah0kUGiSsWC(D8V7AhLkSQYzo)
	def onPlayBackStopped(zEcNagLnXdmhIwkOAs628J): zEcNagLnXdmhIwkOAs628J.aYNj9my0BglzWKEntZo = HHoGx7Flus60(u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭৬")
	def onPlayBackError(zEcNagLnXdmhIwkOAs628J): zEcNagLnXdmhIwkOAs628J.aYNj9my0BglzWKEntZo = LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠧࡧࡣ࡬ࡰࡪࡪࠧ৭")
	def onPlayBackEnded(zEcNagLnXdmhIwkOAs628J): zEcNagLnXdmhIwkOAs628J.aYNj9my0BglzWKEntZo = S1SgCFYGJeMvfp5iZXK(u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨ৮")
	def onPlayBackStarted(zEcNagLnXdmhIwkOAs628J):
		zEcNagLnXdmhIwkOAs628J.aYNj9my0BglzWKEntZo = MMizeNH0AKu(u"ࠩࡶࡸࡦࡸࡴࡦࡦࠪ৯")
		MJyQAPs1EN7Wec = KCTRe67wVy.Thread(target=zEcNagLnXdmhIwkOAs628J.XSj4nTyfk8OFPcho5GIYdC6is7,args=())
		MJyQAPs1EN7Wec.start()
	def onAVStarted(zEcNagLnXdmhIwkOAs628J):
		if MmcgqAlsFt.sTZjaIcENd: zEcNagLnXdmhIwkOAs628J.aYNj9my0BglzWKEntZo = S1SgCFYGJeMvfp5iZXK(u"ࠪࡴࡱࡧࡹࡪࡰࡪࠫৰ")
		else: zEcNagLnXdmhIwkOAs628J.aYNj9my0BglzWKEntZo = jeAby54c02TgG8zuivonX91(u"ࠫࡹ࡫ࡳࡵ࡫ࡱ࡫ࠬৱ")
	def XSj4nTyfk8OFPcho5GIYdC6is7(zEcNagLnXdmhIwkOAs628J):
		MewdQi3zF4maS9TZRopbA1hUI(EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠬࡹࡴࡰࡲࠪ৲"))
		iWQerVFZgbvA1cHYsP8amj = ybdv7XcT3lxF6QezULwCAGk
		while not eval(NeO3CTLHrPfWUoIgy8Q(u"࠭ࡸࡣ࡯ࡦ࠲ࡕࡲࡡࡺࡧࡵࠬ࠮࠴ࡩࡴࡒ࡯ࡥࡾ࡯࡮ࡨࠪࠬࠫ৳"),{wwPrSDa21lUh(u"ࠧࡹࡤࡰࡧࠬ৴"):MMk8qKvcJe4fQHm3EG7diBD5}) and zEcNagLnXdmhIwkOAs628J.aYNj9my0BglzWKEntZo==xcChIL13BpR8WArNt9Pl0So(u"ࠨࡵࡷࡥࡷࡺࡥࡥࠩ৵"):
			MMk8qKvcJe4fQHm3EG7diBD5.sleep(ITvnUAMXsyb4eO(u"࠶࠶࠰࠱ୂ"))
			iWQerVFZgbvA1cHYsP8amj += bXukYxQ4aHw
			if iWQerVFZgbvA1cHYsP8amj>KNIvHPjUbhr(u"࠼࠰ୃ"): return
		if MmcgqAlsFt.j0juxvCpdOFDk2: zEcNagLnXdmhIwkOAs628J.aYNj9my0BglzWKEntZo = HHoGx7Flus60(u"ࠩࡥࡰࡴࡩ࡫ࡦࡦࠪ৶")
		elif MmcgqAlsFt.sTZjaIcENd: zEcNagLnXdmhIwkOAs628J.aYNj9my0BglzWKEntZo = NeO3CTLHrPfWUoIgy8Q(u"ࠪࡴࡱࡧࡹࡪࡰࡪࠫ৷")
		elif MmcgqAlsFt.W5bBlPX8OGRw26oeT4Zctp:
			import yoY3NdGViS
			zEcNagLnXdmhIwkOAs628J.aYNj9my0BglzWKEntZo = jeAby54c02TgG8zuivonX91(u"ࠫࡹ࡫ࡳࡵ࡫ࡱ࡫ࠬ৸")
			HtAfYER2ZizpXLN3acoyI = KCTRe67wVy.Thread(target=yoY3NdGViS.pZnPfYmUrWk6,args=(zEcNagLnXdmhIwkOAs628J.iyEphnMXfCWGa,))
			HtAfYER2ZizpXLN3acoyI.start()
			Hm0UydXj4azORMo = KCTRe67wVy.Thread(target=yoY3NdGViS.NRFuVkwcn4XCY6vKOp,args=())
			Hm0UydXj4azORMo.start()
		else: zEcNagLnXdmhIwkOAs628J.aYNj9my0BglzWKEntZo = QvgnCALNstmuUJiET(u"ࠬࡨ࡬ࡰࡥ࡮ࡩࡩ࠭৹")
def EEzrJ1mQk5YR():
	l5obu93WXLgAxZvYyad,kAvR4MpNyhz7db = hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj
	TuqkNCZ9aHVy2 = MMk8qKvcJe4fQHm3EG7diBD5.getInfoLabel(FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"࠭ࡓࡺࡵࡷࡩࡲ࠴ࡆࡳ࡫ࡨࡲࡩࡲࡹࡏࡣࡰࡩࠬ৺"))
	try:
		a5t8F2kShvlj0A1QOLTe = open(CnbBKmtF1x84q7AW(u"ࠧ࠰ࡲࡵࡳࡨ࠵ࡣࡱࡷ࡬ࡲ࡫ࡵࠧ৻"),KBkxSYaz93pu1(u"ࠨࡴࡥࠫৼ")).read()
		if H4qZ2hwilNJYTmCFEQyaSs98cPM0gR: a5t8F2kShvlj0A1QOLTe = a5t8F2kShvlj0A1QOLTe.decode(a7VXeDU82IfQEnPZAdiT)
		J8lfuEQX6UVxeNG2rnLPA = trdVA0JvFaD.findall(mkHKSQvjWr5BTcM3wVY(u"ࠩࡖࡩࡷ࡯ࡡ࡭࠰࠭ࡃ࠿ࠦࠨ࠯ࠬࡂ࠭ࠩ࠭৽"),a5t8F2kShvlj0A1QOLTe,trdVA0JvFaD.IGNORECASE)
		if J8lfuEQX6UVxeNG2rnLPA: l5obu93WXLgAxZvYyad = J8lfuEQX6UVxeNG2rnLPA[ybdv7XcT3lxF6QezULwCAGk]
	except: pass
	try:
		import subprocess as mfbFa3YlEJjD5oxgTwC0QL4HtsS
		Ynpl7C1w9dgGNs = mfbFa3YlEJjD5oxgTwC0QL4HtsS.Popen(A6dMB1FlgxVivJ2fk9C(u"ࠪࡷࡹࡧࡴࠡ࠯ࡦࠤ࡙ࠧࠦࠥࠢࠥࠤ࠴ࡹࡴࡰࡴࡤ࡫ࡪ࠵ࡥ࡮ࡷ࡯ࡥࡹ࡫ࡤ࠰࠲ࠣ࠿ࠥࡹࡴࡢࡶࠣ࠱ࡨ࡚ࠦࠢࠡࠧࠤࠧࠦ࠯ࡷࡣࡵ࠳ࡱࡵࡧࠨ৾"),shell=VBlawK4mgHSyLEn8iqhUkz5,stdin=mfbFa3YlEJjD5oxgTwC0QL4HtsS.PIPE,stdout=mfbFa3YlEJjD5oxgTwC0QL4HtsS.PIPE,stderr=mfbFa3YlEJjD5oxgTwC0QL4HtsS.PIPE)
		WWlKNn6TodSH = Ynpl7C1w9dgGNs.stdout.read()
		if WWlKNn6TodSH:
			if H4qZ2hwilNJYTmCFEQyaSs98cPM0gR:
				WWlKNn6TodSH = WWlKNn6TodSH.decode(a7VXeDU82IfQEnPZAdiT,A6dMB1FlgxVivJ2fk9C(u"ࠫ࡮࡭࡮ࡰࡴࡨࠫ৿"))
			LQy8kGENe9FpvtPRTw03bga = trdVA0JvFaD.findall(HHoGx7Flus60(u"ࠬࠦࠨ࡝ࡦࡾ࠵࠵ࢃࠩࠡࠩ਀"),WWlKNn6TodSH,trdVA0JvFaD.IGNORECASE)
			if LQy8kGENe9FpvtPRTw03bga: kAvR4MpNyhz7db = min(LQy8kGENe9FpvtPRTw03bga)
	except: pass
	return TuqkNCZ9aHVy2,l5obu93WXLgAxZvYyad,kAvR4MpNyhz7db
def rV36aR5MufG1tqOWAlkYepcDd(OOo8sLYyzT0xpS7Ekf=VBlawK4mgHSyLEn8iqhUkz5,dKjvLaWQAuyB=xcChIL13BpR8WArNt9Pl0So(u"࠳࠳ୄ")):
	J9iuWG7sBFtcNw = VBlawK4mgHSyLEn8iqhUkz5
	if OOo8sLYyzT0xpS7Ekf:
		aauOoGhtnEUXTwN1LHPl9mYFSA = Mqk51CFBym0pIQXZLsOxSJ(MM5Dx39f7ULhcJsRptzIowP,KNIvHPjUbhr(u"࠭࡬ࡪࡵࡷࠫਁ"),jeAby54c02TgG8zuivonX91(u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪਂ"),FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠨࡕࡌࡘࡊ࡙࡟ࡄࡊࡈࡇࡐ࠭ਃ"))
		if aauOoGhtnEUXTwN1LHPl9mYFSA:
			l0wzB12gfSrxdQ5,oa9LSpF1Vc6gREH,CEw9YOQsuGp,ETyHAB69fxqSXl = aauOoGhtnEUXTwN1LHPl9mYFSA
			J9iuWG7sBFtcNw = Mqk51CFBym0pIQXZLsOxSJ(MM5Dx39f7ULhcJsRptzIowP,NeO3CTLHrPfWUoIgy8Q(u"ࠩ࡯࡭ࡸࡺࠧ਄"),HHoGx7Flus60(u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭ਅ"),hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠫࡘࡏࡔࡆࡕࡢ࡚ࡊࡘࡉࡇ࡛ࠪਆ"))
			if J9iuWG7sBFtcNw: TuqkNCZ9aHVy2,l5obu93WXLgAxZvYyad,kAvR4MpNyhz7db = J9iuWG7sBFtcNw
			else: TuqkNCZ9aHVy2,l5obu93WXLgAxZvYyad,kAvR4MpNyhz7db = EEzrJ1mQk5YR()
			if (oa9LSpF1Vc6gREH,CEw9YOQsuGp,ETyHAB69fxqSXl)==(TuqkNCZ9aHVy2,l5obu93WXLgAxZvYyad,kAvR4MpNyhz7db): return NXMOzZjYsmS9pf.join(l0wzB12gfSrxdQ5)
	if J9iuWG7sBFtcNw: TuqkNCZ9aHVy2,l5obu93WXLgAxZvYyad,kAvR4MpNyhz7db = EEzrJ1mQk5YR()
	global HYoQNpkrx9lyUbf0RMDP,NP4X51dkYhGIWv
	HYoQNpkrx9lyUbf0RMDP,NP4X51dkYhGIWv,Uay63TlxEbYgAF0peiPSNrn7kwCMG = hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj
	dKjvLaWQAuyB = dKjvLaWQAuyB//Y0XZKGRAUQj5O
	KCTRe67wVy.Thread(target=hhGwbB4QoR5PHD).start()
	KCTRe67wVy.Thread(target=WWyQi7LpOA4Rs).start()
	for JpzD0lv9cYM6XrHeqCa in range(LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"࠲࠲୅")):
		HB5PvxRhwM.sleep(XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"࠲࠱࠹୆"))
		if not Uay63TlxEbYgAF0peiPSNrn7kwCMG:
			try:
				Lp4GPOjfMmeNalvnF = MMk8qKvcJe4fQHm3EG7diBD5.getInfoLabel(KNIvHPjUbhr(u"ࠬࡔࡥࡵࡹࡲࡶࡰ࠴ࡍࡢࡥࡄࡨࡩࡸࡥࡴࡵࠪਇ"))
				if Lp4GPOjfMmeNalvnF.count(zyvJMtBhrw(u"࠭࠺ࠨਈ"))==KNIvHPjUbhr(u"࠹ୈ") and Lp4GPOjfMmeNalvnF.count(xcChIL13BpR8WArNt9Pl0So(u"ࠧ࠱ࠩਉ"))<QVDJLRlxNg127jMX(u"࠼େ"):
					Lp4GPOjfMmeNalvnF = Lp4GPOjfMmeNalvnF.lower().replace(sULh4NjakzI8He7xJCMGrql(u"ࠨ࠼ࠪਊ"),hWGMqtBy4wuLaVcj)
					Uay63TlxEbYgAF0peiPSNrn7kwCMG = str(int(Lp4GPOjfMmeNalvnF,gDuGMR3z1aV6YdLmCpiO8Kl(u"࠶࠼୉")))
			except: pass
		if HYoQNpkrx9lyUbf0RMDP and NP4X51dkYhGIWv and Uay63TlxEbYgAF0peiPSNrn7kwCMG: break
	QirvsbzWjB1O = [HYoQNpkrx9lyUbf0RMDP,NP4X51dkYhGIWv,Uay63TlxEbYgAF0peiPSNrn7kwCMG,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,ITvnUAMXsyb4eO(u"ࠩ࠳࠴࠶࠷࠲࠳࠵࠶࠸࠹࠻࠵࠷࠸࠺࠻ࠬ਋")]
	if l5obu93WXLgAxZvYyad or kAvR4MpNyhz7db:
		BVCukIiaUy1tH9x = [(jR6BYWNFZ0egmH4Tr2Q78LbSs3t,l5obu93WXLgAxZvYyad),(QVDJLRlxNg127jMX(u"࠻୊"),kAvR4MpNyhz7db)]
		for jKJu4sm3FwBXipMExahVcdgRQUr7,R1Rpns76wZd9NljL8fyUg in BVCukIiaUy1tH9x:
			R1Rpns76wZd9NljL8fyUg = R1Rpns76wZd9NljL8fyUg.strip(sULh4NjakzI8He7xJCMGrql(u"ࠪ࠴ࠬ਌"))
			if R1Rpns76wZd9NljL8fyUg:
				if H4qZ2hwilNJYTmCFEQyaSs98cPM0gR: R1Rpns76wZd9NljL8fyUg = R1Rpns76wZd9NljL8fyUg.encode(a7VXeDU82IfQEnPZAdiT)
				R1Rpns76wZd9NljL8fyUg = str(int(xcRlSgBrOhKz69LNou0f8D5MVem.md5(R1Rpns76wZd9NljL8fyUg).hexdigest(),mkHKSQvjWr5BTcM3wVY(u"࠳࠷ୋ")))
				qAWX8V4KGlNY9 = [int(R1Rpns76wZd9NljL8fyUg[Us1moWePCZSVdlR40zp3FTvjktOcLa:Us1moWePCZSVdlR40zp3FTvjktOcLa+A6dMB1FlgxVivJ2fk9C(u"࠳࠸୍")]) for Us1moWePCZSVdlR40zp3FTvjktOcLa in range(len(R1Rpns76wZd9NljL8fyUg)) if Us1moWePCZSVdlR40zp3FTvjktOcLa%A6dMB1FlgxVivJ2fk9C(u"࠳࠸୍")==e2qDYgipPmTw4KvBLnochr(u"࠱ୌ")]
				QirvsbzWjB1O[jKJu4sm3FwBXipMExahVcdgRQUr7-bXukYxQ4aHw] = str(sum(qAWX8V4KGlNY9))
	l0wzB12gfSrxdQ5,TpzRAvHy8ULxCj = [],fEXMiAyG3ql4vKB
	for inLYOJ8UHDI in range(len(QirvsbzWjB1O)):
		qAWX8V4KGlNY9 = QirvsbzWjB1O[inLYOJ8UHDI]
		if not qAWX8V4KGlNY9: continue
		if TpzRAvHy8ULxCj and qAWX8V4KGlNY9==QirvsbzWjB1O[-bXukYxQ4aHw]: continue
		TpzRAvHy8ULxCj = VBlawK4mgHSyLEn8iqhUkz5
		qAWX8V4KGlNY9 = wwPrSDa21lUh(u"ࠫ࠵࠭਍")*dKjvLaWQAuyB+qAWX8V4KGlNY9
		qAWX8V4KGlNY9 = qAWX8V4KGlNY9[-dKjvLaWQAuyB:]
		mmoxiql2cbIu3nJ0hd4,MK5Wehxqp8C13uRTgaIcnkE9br = hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj
		O3bR7XD06Q5kiVHacx4 = str(int(KNIvHPjUbhr(u"ࠬ࠿ࠧ਎")*(dKjvLaWQAuyB+bXukYxQ4aHw))-int(qAWX8V4KGlNY9))[-dKjvLaWQAuyB:]
		for dV8hf3cYkFXZ2InK1jJzoiN9aquw7x in list(range(ybdv7XcT3lxF6QezULwCAGk,dKjvLaWQAuyB,jR6BYWNFZ0egmH4Tr2Q78LbSs3t)):
			mmoxiql2cbIu3nJ0hd4 += O3bR7XD06Q5kiVHacx4[dV8hf3cYkFXZ2InK1jJzoiN9aquw7x:dV8hf3cYkFXZ2InK1jJzoiN9aquw7x+jR6BYWNFZ0egmH4Tr2Q78LbSs3t]+o1u5dij9UrcbXzVS8lwIWfKpnqM(u"࠭࠭ࠨਏ")
			MK5Wehxqp8C13uRTgaIcnkE9br += str(sum(map(int,qAWX8V4KGlNY9[dV8hf3cYkFXZ2InK1jJzoiN9aquw7x:dV8hf3cYkFXZ2InK1jJzoiN9aquw7x+jR6BYWNFZ0egmH4Tr2Q78LbSs3t]))%EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"࠴࠴୎"))
		zHI8GkB2Lg1cSmCqeyNodEX6 = str(inLYOJ8UHDI)+mmoxiql2cbIu3nJ0hd4+MK5Wehxqp8C13uRTgaIcnkE9br
		l0wzB12gfSrxdQ5.append(zHI8GkB2Lg1cSmCqeyNodEX6)
	BxuD7iQRpW1(MM5Dx39f7ULhcJsRptzIowP,wwPrSDa21lUh(u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪਐ"),EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠨࡕࡌࡘࡊ࡙࡟ࡗࡇࡕࡍࡋ࡟ࠧ਑"),[TuqkNCZ9aHVy2,l5obu93WXLgAxZvYyad,kAvR4MpNyhz7db],KqO5BWGQR9JVL)
	BxuD7iQRpW1(MM5Dx39f7ULhcJsRptzIowP,KNIvHPjUbhr(u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬ਒"),dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠪࡗࡎ࡚ࡅࡔࡡࡆࡌࡊࡉࡋࠨਓ"),[l0wzB12gfSrxdQ5,TuqkNCZ9aHVy2,l5obu93WXLgAxZvYyad,kAvR4MpNyhz7db],DpQifS0oKBI1hYcO)
	return NXMOzZjYsmS9pf.join(l0wzB12gfSrxdQ5)
def Dv0PbigXyWH4MUCSpE(X3X4Y8RzxSVfZJUFDe,S6NALBOqGn1zi2W5M8y7,F49URk16JIawgp7YWZAXGtnMb,UBRzLM6ZdkWOKwy0qPfFIlC,dUWFtBQ3cpoIZ9,fjUoJylTVWh0):
	PwvNmnqXKrYVZugB5c8 = str(UBRzLM6ZdkWOKwy0qPfFIlC)[ybdv7XcT3lxF6QezULwCAGk:mkHKSQvjWr5BTcM3wVY(u"࠶࠺࠶୏")].replace(NXMOzZjYsmS9pf,NeO3CTLHrPfWUoIgy8Q(u"ࠫࡡࡢ࡮ࠨਔ")).replace(y6eSQlZEV8uwKG5M3,NeO3CTLHrPfWUoIgy8Q(u"ࠬࡢ࡜ࡳࠩਕ")).replace(nIDXGaRHv7mOohe0Y8dLstECM,Mpsm2VF1OBnCRvK3qf6).replace(lG0yV5QNFHc2RbXM1Wp,Mpsm2VF1OBnCRvK3qf6)
	if len(str(UBRzLM6ZdkWOKwy0qPfFIlC))>xcChIL13BpR8WArNt9Pl0So(u"࠷࠻࠰୐"): PwvNmnqXKrYVZugB5c8 = PwvNmnqXKrYVZugB5c8+CnbBKmtF1x84q7AW(u"࠭ࠠ࠯࠰࠱ࠫਖ")
	OucJVrWRKSqDChiG7yn3oz0dafZF = str(F49URk16JIawgp7YWZAXGtnMb)[ybdv7XcT3lxF6QezULwCAGk:hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"࠸࠵࠱୑")].replace(NXMOzZjYsmS9pf,rwQN9AKhLCuMfHxjlbX0U(u"ࠧ࡝࡞ࡱࠫਗ")).replace(y6eSQlZEV8uwKG5M3,QVDJLRlxNg127jMX(u"ࠨ࡞࡟ࡶࠬਘ")).replace(nIDXGaRHv7mOohe0Y8dLstECM,Mpsm2VF1OBnCRvK3qf6).replace(lG0yV5QNFHc2RbXM1Wp,Mpsm2VF1OBnCRvK3qf6)
	if len(str(F49URk16JIawgp7YWZAXGtnMb))>NeO3CTLHrPfWUoIgy8Q(u"࠲࠶࠲୒"): OucJVrWRKSqDChiG7yn3oz0dafZF = OucJVrWRKSqDChiG7yn3oz0dafZF+NeO3CTLHrPfWUoIgy8Q(u"ࠩࠣ࠲࠳࠴ࠧਙ")
	KteLZCbM8W0FqE2OBx1(pGYKHZgqFX3B,hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠪࡓࡕࡋࡎࡖࡔࡏࡣࠬਚ")+X3X4Y8RzxSVfZJUFDe+EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠫࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧਛ")+S6NALBOqGn1zi2W5M8y7+QvgnCALNstmuUJiET(u"ࠬࠦ࡝ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧਜ")+dUWFtBQ3cpoIZ9+SqrG5mU3j96ldsFpExobw40TJY(u"࠭ࠠ࡞ࠢࠣࠤࡒ࡫ࡴࡩࡱࡧ࠾ࠥࡡࠠࠨਝ")+fjUoJylTVWh0+FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠧࠡ࡟ࠣࠤࠥࡎࡥࡢࡦࡨࡶࡸࡀࠠ࡜ࠢࠪਞ")+str(PwvNmnqXKrYVZugB5c8)+KBkxSYaz93pu1(u"ࠨࠢࡠࠤࠥࠦࡄࡢࡶࡤ࠾ࠥࡡࠠࠨਟ")+OucJVrWRKSqDChiG7yn3oz0dafZF+e2qDYgipPmTw4KvBLnochr(u"ࠩࠣࡡࠬਠ"))
	return
def hhGwbB4QoR5PHD():
	global HYoQNpkrx9lyUbf0RMDP
	import getmac82 as onIrfJ6zAXjCv4DcHsNiSkdYU
	try:
		iytX8gmnUGNVO = onIrfJ6zAXjCv4DcHsNiSkdYU.get_mac_address()
		if iytX8gmnUGNVO.count(GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠪ࠾ࠬਡ"))==FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"࠷୔") and iytX8gmnUGNVO.count(KNIvHPjUbhr(u"ࠫ࠵࠭ਢ"))<hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"࠺୓"):
			iytX8gmnUGNVO = iytX8gmnUGNVO.lower().replace(gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠬࡀࠧਣ"),hWGMqtBy4wuLaVcj)
			HYoQNpkrx9lyUbf0RMDP = str(int(iytX8gmnUGNVO,S1SgCFYGJeMvfp5iZXK(u"࠴࠺୕")))
	except: pass
	return
def WWyQi7LpOA4Rs():
	global NP4X51dkYhGIWv
	import getmac94 as poBn7mUxzLwtJFNH0cA9P5Q
	try:
		iTuMqYeKj2PoIS3BQNmc79nzy = poBn7mUxzLwtJFNH0cA9P5Q.get_mac_address()
		if iTuMqYeKj2PoIS3BQNmc79nzy.count(MMizeNH0AKu(u"࠭࠺ࠨਤ"))==OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"࠺ୗ") and iTuMqYeKj2PoIS3BQNmc79nzy.count(SqrG5mU3j96ldsFpExobw40TJY(u"ࠧ࠱ࠩਥ"))<LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"࠽ୖ"):
			iTuMqYeKj2PoIS3BQNmc79nzy = iTuMqYeKj2PoIS3BQNmc79nzy.lower().replace(LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠨ࠼ࠪਦ"),hWGMqtBy4wuLaVcj)
			NP4X51dkYhGIWv = str(int(iTuMqYeKj2PoIS3BQNmc79nzy,jeAby54c02TgG8zuivonX91(u"࠷࠶୘")))
	except: pass
	return
def Y2heCz1DlR0GLKHJTs5OPb9(fjUoJylTVWh0,S6NALBOqGn1zi2W5M8y7,F49URk16JIawgp7YWZAXGtnMb=hWGMqtBy4wuLaVcj,UBRzLM6ZdkWOKwy0qPfFIlC=hWGMqtBy4wuLaVcj,dUWFtBQ3cpoIZ9=hWGMqtBy4wuLaVcj):
	Dv0PbigXyWH4MUCSpE(sULh4NjakzI8He7xJCMGrql(u"ࠩࡘࡖࡑࡒࡉࡃ࡞ࡷࡠࡹࡕࡐࡆࡐࡢ࡙ࡗࡒࠧਧ"),S6NALBOqGn1zi2W5M8y7,F49URk16JIawgp7YWZAXGtnMb,UBRzLM6ZdkWOKwy0qPfFIlC,dUWFtBQ3cpoIZ9,fjUoJylTVWh0)
	if H4qZ2hwilNJYTmCFEQyaSs98cPM0gR: import urllib.request as HFzV1brLpDNdh3mC
	else: import urllib2 as HFzV1brLpDNdh3mC
	if not UBRzLM6ZdkWOKwy0qPfFIlC: UBRzLM6ZdkWOKwy0qPfFIlC = {KBkxSYaz93pu1(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧਨ"):hWGMqtBy4wuLaVcj}
	if not F49URk16JIawgp7YWZAXGtnMb: F49URk16JIawgp7YWZAXGtnMb = {}
	if fjUoJylTVWh0==CnbBKmtF1x84q7AW(u"ࠫࡌࡋࡔࠨ਩"):
		S6NALBOqGn1zi2W5M8y7 = S6NALBOqGn1zi2W5M8y7+GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠬࡅࠧਪ")+gQ5hRKULia2pdOWAxScMwTDbkl(F49URk16JIawgp7YWZAXGtnMb)
		F49URk16JIawgp7YWZAXGtnMb = None
	elif fjUoJylTVWh0==S1SgCFYGJeMvfp5iZXK(u"࠭ࡐࡐࡕࡗࠫਫ") and KBkxSYaz93pu1(u"ࠧ࡫ࡵࡲࡲࠬਬ") in str(UBRzLM6ZdkWOKwy0qPfFIlC):
		F49URk16JIawgp7YWZAXGtnMb = TPDQ5L9eWpIJcrM3YH48Cs6.dumps(F49URk16JIawgp7YWZAXGtnMb)
		F49URk16JIawgp7YWZAXGtnMb = str(F49URk16JIawgp7YWZAXGtnMb).encode(a7VXeDU82IfQEnPZAdiT)
	elif fjUoJylTVWh0==A6dMB1FlgxVivJ2fk9C(u"ࠨࡒࡒࡗ࡙࠭ਭ"):
		F49URk16JIawgp7YWZAXGtnMb = gQ5hRKULia2pdOWAxScMwTDbkl(F49URk16JIawgp7YWZAXGtnMb)
		F49URk16JIawgp7YWZAXGtnMb = F49URk16JIawgp7YWZAXGtnMb.encode(a7VXeDU82IfQEnPZAdiT)
	try:
		dGBOikQKAzF2M = HFzV1brLpDNdh3mC.Request(S6NALBOqGn1zi2W5M8y7,headers=UBRzLM6ZdkWOKwy0qPfFIlC,data=F49URk16JIawgp7YWZAXGtnMb)
		BUXsmKe5dGpJj09REb6HqcO7tNv = HFzV1brLpDNdh3mC.urlopen(dGBOikQKAzF2M)
		wYZ9hmIlS3cv17s2W = BUXsmKe5dGpJj09REb6HqcO7tNv.read()
		kw6Zs29tznG0CFIUWxOh7qeH,jZyzn8MtORbaeCW = XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"࠲࠱࠲୙"),wwPrSDa21lUh(u"ࠩࡒࡏࠬਮ")
	except:
		wYZ9hmIlS3cv17s2W = hWGMqtBy4wuLaVcj
		kw6Zs29tznG0CFIUWxOh7qeH,jZyzn8MtORbaeCW = -bXukYxQ4aHw,QvgnCALNstmuUJiET(u"࡙ࠪࡳࡱ࡮ࡰࡹࡱࠤࡊࡸࡲࡰࡴࠪਯ")
	KteLZCbM8W0FqE2OBx1(pGYKHZgqFX3B,LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠫࡔࡖࡅࡏࡗࡕࡐࡤ࡛ࡒࡍࡎࡌࡆࡡࡺ࡜ࡵࡔࡈࡗࡕࡕࡎࡔࡇࠣࠤࡈࡵࡤࡦ࠼ࠣ࡟ࠥ࠭ਰ")+str(kw6Zs29tznG0CFIUWxOh7qeH)+LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠬࠦ࡝ࠡࠢࠣࡖࡪࡧࡳࡰࡰ࠽ࠤࡠࠦࠧ਱")+jZyzn8MtORbaeCW+A6dMB1FlgxVivJ2fk9C(u"࠭ࠠ࡞ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨਲ")+dUWFtBQ3cpoIZ9+LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠧࠡ࡟ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭ਲ਼")+S6NALBOqGn1zi2W5M8y7+CnbBKmtF1x84q7AW(u"ࠨࠢࡠࠫ਴"))
	if wYZ9hmIlS3cv17s2W and H4qZ2hwilNJYTmCFEQyaSs98cPM0gR: wYZ9hmIlS3cv17s2W = wYZ9hmIlS3cv17s2W.decode(a7VXeDU82IfQEnPZAdiT)
	return wYZ9hmIlS3cv17s2W
def C5NA8EQG2cS3FbfXU47DM(x6xNgd0WHEQeTts8):
	tvRE9Tum2AKVyXOz = {
		A6dMB1FlgxVivJ2fk9C(u"ࠤࡸࡷࡪࡸ࡟ࡪࡦࠥਵ"):j8fz6cKJpAb7kedIsS,
		QvgnCALNstmuUJiET(u"ࠥࡳࡸࡥࡶࡦࡴࡶ࡭ࡴࡴࠢਸ਼"):str(guSzmUCXDa1tQpY),
		DJ1ICpbyR2(u"ࠦࡦࡶࡰࡠࡸࡨࡶࡸ࡯࡯࡯ࠤ਷"):aO9cFKo862LqTWlIjy,
		LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠧࡪࡥࡷ࡫ࡦࡩࡤ࡬ࡡ࡮࡫࡯ࡽࠧਸ"):aO9cFKo862LqTWlIjy,
		CnbBKmtF1x84q7AW(u"ࠨࡰ࡭ࡣࡷࡪࡴࡸ࡭ࠣਹ"): aO9cFKo862LqTWlIjy,
		gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠢࡤࡣࡵࡶ࡮࡫ࡲࠣ਺"):GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠣࡃࡕࡅࡇࡏࡃࡠࡘࡌࡈࡊࡕࡓࠣ਻"),
		rwQN9AKhLCuMfHxjlbX0U(u"ࠤ࡬ࡴ਼ࠧ"): SqrG5mU3j96ldsFpExobw40TJY(u"ࠥࠨࡷ࡫࡭ࡰࡶࡨࠦ਽"),
		EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠦࠩࡹ࡫ࡪࡲࡢࡹࡸ࡫ࡲࡠࡲࡵࡳࡵ࡫ࡲࡵ࡫ࡨࡷࡤࡹࡹ࡯ࡥࠥਾ"):fEXMiAyG3ql4vKB
	}
	YAuxcqgp9HkwtShPI3 = []
	for QSTd4nDuCG3zq5YRKgL9 in x6xNgd0WHEQeTts8:
		fhobD4JvAis7ndHL = tvRE9Tum2AKVyXOz.copy()
		fhobD4JvAis7ndHL[EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠬ࡫ࡶࡦࡰࡷࡣࡹࡿࡰࡦࠩਿ")] = QSTd4nDuCG3zq5YRKgL9
		fhobD4JvAis7ndHL[dv0trJR7PwmKyxDYO52VLau8gEph(u"࠭ࡥࡷࡧࡱࡸࡤࡶࡲࡰࡲࡨࡶࡹ࡯ࡥࡴࠩੀ")] = {e2qDYgipPmTw4KvBLnochr(u"ࠢࡆࡸࡨࡲࡹࡥࡎࡢ࡯ࡨࠦੁ"):QSTd4nDuCG3zq5YRKgL9}
		fhobD4JvAis7ndHL[QvgnCALNstmuUJiET(u"ࠨࡷࡶࡩࡷࡥࡰࡳࡱࡳࡩࡷࡺࡩࡦࡵࠪੂ")] = {sULh4NjakzI8He7xJCMGrql(u"ࠤࡘࡷࡪࡸ࡟ࡆࡸࡨࡲࡹࡥࡎࡢ࡯ࡨࠦ੃"):QSTd4nDuCG3zq5YRKgL9}
		YAuxcqgp9HkwtShPI3.append(fhobD4JvAis7ndHL)
	lGKtNH2zDk = str(eOmXSF6kIWV7yqKCR.randrange(gDuGMR3z1aV6YdLmCpiO8Kl(u"࠲࠳࠴࠵࠶࠷࠱࠲࠳࠴࠵࠶୚"),EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"࠻࠼࠽࠾࠿࠹࠺࠻࠼࠽࠾࠿୛")))
	F49URk16JIawgp7YWZAXGtnMb = {
		NeO3CTLHrPfWUoIgy8Q(u"ࠥࡥࡵ࡯࡟࡬ࡧࡼࠦ੄"):sULh4NjakzI8He7xJCMGrql(u"ࠫ࠷࠻࠴ࡥࡦ࠶ࡥ࠹࠶࠹ࡥ࠺ࡥ࠺࠽࠷ࡤ࠵ࡧ࠴࠵࠼࡫ࡥ࠸࠺ࡦࡩࡧ࡬࠲࠺ࠩ੅"),
		LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠧ࡯࡮ࡴࡧࡵࡸࡤ࡯ࡤࠣ੆"):lGKtNH2zDk,
		LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠨࡥࡷࡧࡱࡸࡸࠨੇ"): YAuxcqgp9HkwtShPI3
	}
	UBRzLM6ZdkWOKwy0qPfFIlC = {dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭ੈ"):KBkxSYaz93pu1(u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡪࡴࡱࡱࠫ੉")}
	S6NALBOqGn1zi2W5M8y7 = ITvnUAMXsyb4eO(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡵ࡯࠲࠯ࡣࡰࡴࡱ࡯ࡴࡶࡦࡨ࠲ࡨࡵ࡭࠰࠴࠲࡬ࡹࡺࡰࡢࡲ࡬ࠫ੊")
	wYZ9hmIlS3cv17s2W = Y2heCz1DlR0GLKHJTs5OPb9(GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠪࡔࡔ࡙ࡔࠨੋ"),S6NALBOqGn1zi2W5M8y7,F49URk16JIawgp7YWZAXGtnMb,UBRzLM6ZdkWOKwy0qPfFIlC,xcChIL13BpR8WArNt9Pl0So(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲࡙ࡅࡏࡆࡢࡅࡓࡇࡌ࡚ࡖࡌࡇࡘࡥࡅࡗࡇࡑࡘࡘ࠳࠱ࡴࡶࠪੌ"))
	return wYZ9hmIlS3cv17s2W
def Cy9ow3c21nABMjzqeaIT(YGI85DN9P76z02eik,XNBHzrlKD9yW):
	XNBHzrlKD9yW = XNBHzrlKD9yW.replace(jeAby54c02TgG8zuivonX91(u"ࠬࡴࡵ࡭࡮੍ࠪ"),LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"࠭ࡎࡰࡰࡨࠫ੎"))
	XNBHzrlKD9yW = XNBHzrlKD9yW.replace(CnbBKmtF1x84q7AW(u"ࠧࡵࡴࡸࡩࠬ੏"),jeAby54c02TgG8zuivonX91(u"ࠨࡖࡵࡹࡪ࠭੐"))
	XNBHzrlKD9yW = XNBHzrlKD9yW.replace(DJ1ICpbyR2(u"ࠩࡩࡥࡱࡹࡥࠨੑ"),wwPrSDa21lUh(u"ࠪࡊࡦࡲࡳࡦࠩ੒"))
	XNBHzrlKD9yW = XNBHzrlKD9yW.replace(CnbBKmtF1x84q7AW(u"ࠫࡡ࠵ࠧ੓"),A6dMB1FlgxVivJ2fk9C(u"ࠬ࠵ࠧ੔"))
	try: XVfzajwpqTB4R8xdEKDt = eval(XNBHzrlKD9yW)
	except: XVfzajwpqTB4R8xdEKDt = BOkRoCi42L7VQFyPsJ51WpSdEY(YGI85DN9P76z02eik)
	return XVfzajwpqTB4R8xdEKDt
def QJieP0hZkz2slvKyn71OSto():
	X3X4Y8RzxSVfZJUFDe,wJUqaIAzvtsMSEZlKV,S6NALBOqGn1zi2W5M8y7,u2GRrQ0854,nWE8aO53lFfD,l7COkhRWD9uVS60Pte2NoyAaZn,XNBHzrlKD9yW,MH5c7Nekugx8O1AQjInRWyT64GV,SX7OT3VLGp2iQm = vikbdSOtZJFz6gQeL(i2tpOA6QzlfUByTSeKacWnV1)
	p05pq1QcdOZrzXMJs3I7VTUjEHxKa = trdVA0JvFaD.findall(FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"࠭࡜ࡥ࡞ࡧ࠾ࡡࡪ࡜ࡥࠢ࡟࡟࠴ࡉࡏࡍࡑࡕࡠࡢ࠭੕"),wJUqaIAzvtsMSEZlKV,trdVA0JvFaD.DOTALL)
	if p05pq1QcdOZrzXMJs3I7VTUjEHxKa: wJUqaIAzvtsMSEZlKV = wJUqaIAzvtsMSEZlKV.split(p05pq1QcdOZrzXMJs3I7VTUjEHxKa[ybdv7XcT3lxF6QezULwCAGk],JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"࠴ଡ଼"))[bXukYxQ4aHw]
	zYA9NDGmltgjb0OM6vdTrx14KU = HB5PvxRhwM.strftime(sULh4NjakzI8He7xJCMGrql(u"ࠧࡠࠧࡰ࠲ࠪࡪ࡟ࠦࡊ࠽ࠩࡒࡥࠧ੖"),HB5PvxRhwM.localtime(IHKJoQ8PwW4pNBR6GTAMVz2hdfC5my))
	wJUqaIAzvtsMSEZlKV = wJUqaIAzvtsMSEZlKV+zYA9NDGmltgjb0OM6vdTrx14KU
	EbAdj82tGKVCH1 = X3X4Y8RzxSVfZJUFDe,wJUqaIAzvtsMSEZlKV,S6NALBOqGn1zi2W5M8y7,u2GRrQ0854,nWE8aO53lFfD,l7COkhRWD9uVS60Pte2NoyAaZn,XNBHzrlKD9yW,MH5c7Nekugx8O1AQjInRWyT64GV,SX7OT3VLGp2iQm
	if WQvYkNg7SysPFLitlGEn6.path.exists(UC78nrbeDHfwVAh2vt):
		KYm6wdR9sybGfD5 = open(UC78nrbeDHfwVAh2vt,dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠨࡴࡥࠫ੗")).read()
		if H4qZ2hwilNJYTmCFEQyaSs98cPM0gR: KYm6wdR9sybGfD5 = KYm6wdR9sybGfD5.decode(a7VXeDU82IfQEnPZAdiT)
		KYm6wdR9sybGfD5 = Cy9ow3c21nABMjzqeaIT(DJ1ICpbyR2(u"ࠩࡧ࡭ࡨࡺࠧ੘"),KYm6wdR9sybGfD5)
	else: KYm6wdR9sybGfD5 = {}
	ZkO6hteNg43 = {}
	for JCBPEWf7sXOg5MDi in list(KYm6wdR9sybGfD5.keys()):
		if JCBPEWf7sXOg5MDi!=X3X4Y8RzxSVfZJUFDe: ZkO6hteNg43[JCBPEWf7sXOg5MDi] = KYm6wdR9sybGfD5[JCBPEWf7sXOg5MDi]
		else:
			if wJUqaIAzvtsMSEZlKV and wJUqaIAzvtsMSEZlKV!=xcChIL13BpR8WArNt9Pl0So(u"ࠪ࠲࠳࠭ਖ਼"):
				m5lj9iCL8316WF = KYm6wdR9sybGfD5[JCBPEWf7sXOg5MDi]
				if EbAdj82tGKVCH1 in m5lj9iCL8316WF:
					C9VNOL3UmyXPYbGrJ8 = m5lj9iCL8316WF.index(EbAdj82tGKVCH1)
					del m5lj9iCL8316WF[C9VNOL3UmyXPYbGrJ8]
				kF8wafyIPSEV6p0bigxAq = [EbAdj82tGKVCH1]+m5lj9iCL8316WF
				kF8wafyIPSEV6p0bigxAq = kF8wafyIPSEV6p0bigxAq[:zyvJMtBhrw(u"࠹࠵ଢ଼")]
				ZkO6hteNg43[JCBPEWf7sXOg5MDi] = kF8wafyIPSEV6p0bigxAq
			else: ZkO6hteNg43[JCBPEWf7sXOg5MDi] = KYm6wdR9sybGfD5[JCBPEWf7sXOg5MDi]
	if X3X4Y8RzxSVfZJUFDe not in list(ZkO6hteNg43.keys()): ZkO6hteNg43[X3X4Y8RzxSVfZJUFDe] = [EbAdj82tGKVCH1]
	ZkO6hteNg43 = str(ZkO6hteNg43)
	if H4qZ2hwilNJYTmCFEQyaSs98cPM0gR: ZkO6hteNg43 = ZkO6hteNg43.encode(a7VXeDU82IfQEnPZAdiT)
	open(UC78nrbeDHfwVAh2vt,LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠫࡼࡨࠧਗ਼")).write(ZkO6hteNg43)
	return
def gQ5hRKULia2pdOWAxScMwTDbkl(F49URk16JIawgp7YWZAXGtnMb):
	if H4qZ2hwilNJYTmCFEQyaSs98cPM0gR: import urllib.parse as yF1B8xXDQJc0oSziIpRg7Of
	else: import urllib as yF1B8xXDQJc0oSziIpRg7Of
	mgWJiQG07VfoInwXMH = yF1B8xXDQJc0oSziIpRg7Of.urlencode(F49URk16JIawgp7YWZAXGtnMb)
	return mgWJiQG07VfoInwXMH
def vOq38Y4XVZwdE(CMzQFXeI08KDwAJ9p,SNyUT5iKbnD=hWGMqtBy4wuLaVcj,FE9OmZkMHn=hWGMqtBy4wuLaVcj):
	ceZCjWpsPnTH6rbxmuE8tJF = SNyUT5iKbnD not in [e2qDYgipPmTw4KvBLnochr(u"ࠬࡓ࠳ࡖࠩਜ਼"),gDuGMR3z1aV6YdLmCpiO8Kl(u"࠭ࡉࡑࡖ࡙ࠫੜ")]
	if not FE9OmZkMHn: FE9OmZkMHn = A6dMB1FlgxVivJ2fk9C(u"ࠧࡷ࡫ࡧࡩࡴ࠭੝")
	qUjPtfo7ehkg5bsQyHrBm3Taxc0,k32ktvHFyin,KQAv3gxDy84fYNieVSTMoFjaX = wwPrSDa21lUh(u"ࠨࡥࡤࡲࡨ࡫࡬ࡦࡦࠪਫ਼"),hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj
	if len(CMzQFXeI08KDwAJ9p)==x1x9kIQo3zjZWnYaiy:
		S6NALBOqGn1zi2W5M8y7,ktWSi4uKVT9bpFaL,KQAv3gxDy84fYNieVSTMoFjaX = CMzQFXeI08KDwAJ9p
		if ktWSi4uKVT9bpFaL: k32ktvHFyin = QVDJLRlxNg127jMX(u"ࠩࠣࠤ࡙ࠥࡵࡣࡶ࡬ࡸࡱ࡫࠺ࠡ࡝ࠣࠫ੟")+ktWSi4uKVT9bpFaL+LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠪࠤࡢ࠭੠")
	else: S6NALBOqGn1zi2W5M8y7,ktWSi4uKVT9bpFaL,KQAv3gxDy84fYNieVSTMoFjaX = CMzQFXeI08KDwAJ9p,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj
	S6NALBOqGn1zi2W5M8y7 = S6NALBOqGn1zi2W5M8y7.replace(QvgnCALNstmuUJiET(u"ࠫࠪ࠸࠰ࠨ੡"),Mpsm2VF1OBnCRvK3qf6)
	LDceGoKZizXNV9m7bn6SU3W = UGBbEtrcu5jLC6Sxoa3gFyP1mJOpW(S6NALBOqGn1zi2W5M8y7)
	if SNyUT5iKbnD not in [sULh4NjakzI8He7xJCMGrql(u"ࠬࡊࡏࡘࡐࡏࡓࡆࡊࠧ੢"),CnbBKmtF1x84q7AW(u"࠭ࡉࡑࡖ࡙ࠫ੣")]:
		if SNyUT5iKbnD!=NeO3CTLHrPfWUoIgy8Q(u"ࠧࡅࡑ࡚ࡒࡑࡕࡁࡅࠩ੤"): S6NALBOqGn1zi2W5M8y7 = S6NALBOqGn1zi2W5M8y7.replace(Mpsm2VF1OBnCRvK3qf6,FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠨࠧ࠵࠴ࠬ੥"))
		KteLZCbM8W0FqE2OBx1(pGYKHZgqFX3B,qhVEWvetzXLOcr1(xjPuFK3EsIZSiobQ5X)+EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠩࠣࠤࠥࡖࡲࡦࡲࡤࡶ࡮ࡴࡧࠡࡶࡲࠤࡵࡲࡡࡺ࠱ࡧࡳࡼࡴ࡬ࡰࡣࡧࠤࡻ࡯ࡤࡦࡱࠣࠤࠥ࡜ࡩࡥࡧࡲ࠾ࠥࡡࠠࠨ੦")+S6NALBOqGn1zi2W5M8y7+rwQN9AKhLCuMfHxjlbX0U(u"ࠪࠤࡢ࠭੧")+k32ktvHFyin)
		if LDceGoKZizXNV9m7bn6SU3W==QvgnCALNstmuUJiET(u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪ੨") and SNyUT5iKbnD not in [LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠬࡏࡐࡕࡘࠪ੩"),LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"࡙࠭ࡐࡗࡗ࡙ࡇࡋࠧ੪")]:
			from yoY3NdGViS import b8IJFKNyPjgE4GelaCSXB6Qht,Eb7qJoNwOgn,OnsAxhdVjZF
			haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = b8IJFKNyPjgE4GelaCSXB6Qht(S6NALBOqGn1zi2W5M8y7)
			SyHorjp3UgM7ZC51 = len(Dvi8asSrQYX5wE3KMIxT91me)
			if SyHorjp3UgM7ZC51>bXukYxQ4aHw:
				OODLkJlZCoKmrzbg2XQSGPUdInA = Eb7qJoNwOgn(A6dMB1FlgxVivJ2fk9C(u"ࠧศะอีࠥอไๆๆไࠤฬ๊ๅ็ษึฬ࠿ࠦࠨࠨ੫")+str(SyHorjp3UgM7ZC51)+KNIvHPjUbhr(u"ࠨ่่ࠢๆ࠯ࠧ੬"), haq1bHZINPE58uoBFnKfTSO2ik4)
				if OODLkJlZCoKmrzbg2XQSGPUdInA==-bXukYxQ4aHw:
					OnsAxhdVjZF(wwPrSDa21lUh(u"ࠩศ่฿อมࠡ฻่่๏ฯࠠหึ฽๎้ࠦวๅใํำ๏๎ࠧ੭"),KNIvHPjUbhr(u"ࠪࡇࡦࡴࡣࡦ࡮ࠪ੮"))
					return qUjPtfo7ehkg5bsQyHrBm3Taxc0
			else: OODLkJlZCoKmrzbg2XQSGPUdInA = ybdv7XcT3lxF6QezULwCAGk
			S6NALBOqGn1zi2W5M8y7 = Dvi8asSrQYX5wE3KMIxT91me[OODLkJlZCoKmrzbg2XQSGPUdInA]
			if haq1bHZINPE58uoBFnKfTSO2ik4[ybdv7XcT3lxF6QezULwCAGk]!=sULh4NjakzI8He7xJCMGrql(u"ࠫ࠲࠷ࠧ੯"):
				KteLZCbM8W0FqE2OBx1(pGYKHZgqFX3B,qhVEWvetzXLOcr1(xjPuFK3EsIZSiobQ5X)+CnbBKmtF1x84q7AW(u"ࠬࠦࠠࠡࡘ࡬ࡨࡪࡵࠠࡔࡧ࡯ࡩࡨࡺࡥࡥࠢࠣࠤࡘ࡫࡬ࡦࡥࡷ࡭ࡴࡴ࠺ࠡ࡝ࠣࠫੰ")+haq1bHZINPE58uoBFnKfTSO2ik4[OODLkJlZCoKmrzbg2XQSGPUdInA]+FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"࠭ࠠ࡞ࠢࠣࠤ࡛࡯ࡤࡦࡱ࠽ࠤࡠࠦࠧੱ")+S6NALBOqGn1zi2W5M8y7+zyvJMtBhrw(u"ࠧࠡ࡟ࠪੲ"))
		if A6dMB1FlgxVivJ2fk9C(u"ࠨ࠱࡬ࡪ࡮ࡲ࡭࠰ࠩੳ") in S6NALBOqGn1zi2W5M8y7: S6NALBOqGn1zi2W5M8y7 = S6NALBOqGn1zi2W5M8y7+mkHKSQvjWr5BTcM3wVY(u"ࠩࡿ࡙ࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺ࠽ࠧࠩੴ")
		elif FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠪ࡬ࡹࡺࡰࠨੵ") in S6NALBOqGn1zi2W5M8y7.lower() and LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠫ࠴ࡪࡡࡴࡪ࠲ࠫ੶") not in S6NALBOqGn1zi2W5M8y7 and HHoGx7Flus60(u"ࠬࡿ࡯ࡶࡶࡸࡦࡪ࠴࡭ࡱࡦࠪ੷") not in S6NALBOqGn1zi2W5M8y7:
			S6NALBOqGn1zi2W5M8y7 = S6NALBOqGn1zi2W5M8y7+zyvJMtBhrw(u"࠭ࡼࠨ੸") if jeAby54c02TgG8zuivonX91(u"ࠧࡽࠩ੹") not in S6NALBOqGn1zi2W5M8y7 else S6NALBOqGn1zi2W5M8y7+KNIvHPjUbhr(u"ࠨࠨࠪ੺")
			if mkHKSQvjWr5BTcM3wVY(u"ࠩࡹࡩࡷ࡯ࡦࡺࡲࡨࡩࡷࡃࠧ੻") not in S6NALBOqGn1zi2W5M8y7 and KNIvHPjUbhr(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࠬ੼") in S6NALBOqGn1zi2W5M8y7.lower(): S6NALBOqGn1zi2W5M8y7 += jeAby54c02TgG8zuivonX91(u"ࠫࡻ࡫ࡲࡪࡨࡼࡴࡪ࡫ࡲ࠾ࡨࡤࡰࡸ࡫ࠦࠨ੽")
			if NeO3CTLHrPfWUoIgy8Q(u"ࠬࡻࡳࡦࡴ࠰ࡥ࡬࡫࡮ࡵ࠿ࠪ੾") not in S6NALBOqGn1zi2W5M8y7.lower() and SNyUT5iKbnD not in [mkHKSQvjWr5BTcM3wVY(u"࠭ࡉࡑࡖ࡙ࠫ੿"),OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠧࡎ࠵ࡘࠫ઀")]: S6NALBOqGn1zi2W5M8y7 += A6dMB1FlgxVivJ2fk9C(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࡂࠬࠧઁ")
			if KBkxSYaz93pu1(u"ࠩࡵࡩ࡫࡫ࡲࡦࡴࡀࠫં") not in S6NALBOqGn1zi2W5M8y7.lower(): S6NALBOqGn1zi2W5M8y7 += ITvnUAMXsyb4eO(u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࡁ࡭ࡺࡴࡱࠨࠪઃ")
	KteLZCbM8W0FqE2OBx1(YYcbiF1UROXlga2,qhVEWvetzXLOcr1(xjPuFK3EsIZSiobQ5X)+FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠫࠥࠦࠠࡈࡱࡷࠤ࡫࡯࡮ࡢ࡮ࠣࡹࡷࡲ࡙ࠠࠡࠢ࡭ࡩ࡫࡯࠻ࠢ࡞ࠤࠬ઄")+S6NALBOqGn1zi2W5M8y7+SqrG5mU3j96ldsFpExobw40TJY(u"ࠬࠦ࡝ࠨઅ"))
	lHNsoLY2cTdkQOPwx0hen = mUWYiQ2jHICA8cD6LhPTn3wpB1XyK.ListItem()
	FE9OmZkMHn,a17pX2NESVdbAHhflt0zITe8xcqM,sgGd1ecjAftLHVbNKxZP,N4NRFgAPxIVpSlT1tG7C,Ogyr7b1scVTD4fhRS0Bv2lMH6,WeCH6nsUT5Q7,aUWfjZh2Xu,kHSDtO6x4QU,UuWjwOKB8F = vikbdSOtZJFz6gQeL(i2tpOA6QzlfUByTSeKacWnV1)
	if SNyUT5iKbnD not in [rwQN9AKhLCuMfHxjlbX0U(u"࠭ࡄࡐ࡙ࡑࡐࡔࡇࡄࠨઆ"),SqrG5mU3j96ldsFpExobw40TJY(u"ࠧࡊࡒࡗ࡚ࠬઇ")]:
		if VKiGj1LundAJQwEXcqgxC: ew78G5jv1QJYKnsuorb3zxHfh2P = gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲࡧࡤࡥࡱࡱࠫઈ")
		else: ew78G5jv1QJYKnsuorb3zxHfh2P = MMizeNH0AKu(u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳࠧઉ")
		lHNsoLY2cTdkQOPwx0hen.setProperty(ew78G5jv1QJYKnsuorb3zxHfh2P, hWGMqtBy4wuLaVcj)
		lHNsoLY2cTdkQOPwx0hen.setMimeType(SqrG5mU3j96ldsFpExobw40TJY(u"ࠪࡱ࡮ࡳࡥ࠰ࡺ࠰ࡸࡾࡶࡥࠨઊ"))
		if guSzmUCXDa1tQpY<e2qDYgipPmTw4KvBLnochr(u"࠷࠶୞"): lHNsoLY2cTdkQOPwx0hen.setInfo(GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠫࡻ࡯ࡤࡦࡱࠪઋ"),{LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠬࡳࡥࡥ࡫ࡤࡸࡾࡶࡥࠨઌ"):jeAby54c02TgG8zuivonX91(u"࠭࡭ࡰࡸ࡬ࡩࠬઍ")})
		else:
			j5UBi9oWL1xTRt = lHNsoLY2cTdkQOPwx0hen.getVideoInfoTag()
			j5UBi9oWL1xTRt.setMediaType(HHoGx7Flus60(u"ࠧ࡮ࡱࡹ࡭ࡪ࠭઎"))
		lHNsoLY2cTdkQOPwx0hen.setArt({o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠨࡶ࡫ࡹࡲࡨࠧએ"):Ogyr7b1scVTD4fhRS0Bv2lMH6,e2qDYgipPmTw4KvBLnochr(u"ࠩࡳࡳࡸࡺࡥࡳࠩઐ"):Ogyr7b1scVTD4fhRS0Bv2lMH6,GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠪࡦࡦࡴ࡮ࡦࡴࠪઑ"):Ogyr7b1scVTD4fhRS0Bv2lMH6,KBkxSYaz93pu1(u"ࠫ࡫ࡧ࡮ࡢࡴࡷࠫ઒"):Ogyr7b1scVTD4fhRS0Bv2lMH6,ITvnUAMXsyb4eO(u"ࠬࡩ࡬ࡦࡣࡵࡥࡷࡺࠧઓ"):Ogyr7b1scVTD4fhRS0Bv2lMH6,HHoGx7Flus60(u"࠭ࡣ࡭ࡧࡤࡶࡱࡵࡧࡰࠩઔ"):Ogyr7b1scVTD4fhRS0Bv2lMH6,KNIvHPjUbhr(u"ࠧ࡭ࡣࡱࡨࡸࡩࡡࡱࡧࠪક"):Ogyr7b1scVTD4fhRS0Bv2lMH6,GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠨ࡫ࡦࡳࡳ࠭ખ"):Ogyr7b1scVTD4fhRS0Bv2lMH6})
		if LDceGoKZizXNV9m7bn6SU3W in [NeO3CTLHrPfWUoIgy8Q(u"ࠩ࠱ࡱࡵࡪࠧગ"),DJ1ICpbyR2(u"ࠪ࠲ࡲ࠹ࡵ࠹ࠩઘ")]: lHNsoLY2cTdkQOPwx0hen.setContentLookup(VBlawK4mgHSyLEn8iqhUkz5)
		else: lHNsoLY2cTdkQOPwx0hen.setContentLookup(fEXMiAyG3ql4vKB)
		from ZGYSlz63X1 import ff1TqXMbjgJ6n4yko
		if LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠫࡷࡺ࡭ࡱࠩઙ") in S6NALBOqGn1zi2W5M8y7:
			ff1TqXMbjgJ6n4yko(LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡶࡹࡳࡰࠨચ"),fEXMiAyG3ql4vKB)
		elif LDceGoKZizXNV9m7bn6SU3W==MMizeNH0AKu(u"࠭࠮࡮ࡲࡧࠫછ") or hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠧ࠰ࡦࡤࡷ࡭࠵ࠧજ") in S6NALBOqGn1zi2W5M8y7:
			ff1TqXMbjgJ6n4yko(LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡡࡥࡣࡳࡸ࡮ࡼࡥࠨઝ"),fEXMiAyG3ql4vKB)
			lHNsoLY2cTdkQOPwx0hen.setProperty(ew78G5jv1QJYKnsuorb3zxHfh2P,GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡢࡦࡤࡴࡹ࡯ࡶࡦࠩઞ"))
			lHNsoLY2cTdkQOPwx0hen.setProperty(wwPrSDa21lUh(u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡣࡧࡥࡵࡺࡩࡷࡧ࠱ࡱࡦࡴࡩࡧࡧࡶࡸࡤࡺࡹࡱࡧࠪટ"),dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠫࡲࡶࡤࠨઠ"))
		if ktWSi4uKVT9bpFaL:
			lHNsoLY2cTdkQOPwx0hen.setSubtitles([ktWSi4uKVT9bpFaL])
	if FE9OmZkMHn==LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠬࡼࡩࡥࡧࡲࠫડ") and SNyUT5iKbnD==e2qDYgipPmTw4KvBLnochr(u"࠭ࡄࡐ࡙ࡑࡐࡔࡇࡄࠨઢ"):
		qUjPtfo7ehkg5bsQyHrBm3Taxc0 = jeAby54c02TgG8zuivonX91(u"ࠧࡱ࡮ࡤࡽࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧણ")
		SNyUT5iKbnD = FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠨࡒࡏࡅ࡞ࡥࡄࡍࡡࡉࡍࡑࡋࡓࠨત")
	elif FE9OmZkMHn==A6dMB1FlgxVivJ2fk9C(u"ࠩࡹ࡭ࡩ࡫࡯ࠨથ") and kHSDtO6x4QU.startswith(zyvJMtBhrw(u"ࠪ࠺ࠬદ")):
		qUjPtfo7ehkg5bsQyHrBm3Taxc0 = hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࡯࡮ࡨࠩધ")
		SNyUT5iKbnD = SNyUT5iKbnD+CnbBKmtF1x84q7AW(u"ࠬࡥࡄࡍࠩન")
	if qUjPtfo7ehkg5bsQyHrBm3Taxc0!=wwPrSDa21lUh(u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤࡪࡰࡪࠫ઩"): QJieP0hZkz2slvKyn71OSto()
	kkS5tYma7qnKce4F9hdJA.MQfhP9Ym241(SNyUT5iKbnD)
	if kkS5tYma7qnKce4F9hdJA.aYNj9my0BglzWKEntZo: return wwPrSDa21lUh(u"ࠧࡣ࡮ࡲࡧࡰ࡫ࡤࠨપ")
	if FE9OmZkMHn==SqrG5mU3j96ldsFpExobw40TJY(u"ࠨࡸ࡬ࡨࡪࡵࠧફ") and not kHSDtO6x4QU.startswith(gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠩ࠹ࠫબ")):
		lHNsoLY2cTdkQOPwx0hen.setPath(S6NALBOqGn1zi2W5M8y7)
		KteLZCbM8W0FqE2OBx1(pGYKHZgqFX3B,qhVEWvetzXLOcr1(xjPuFK3EsIZSiobQ5X)+zyvJMtBhrw(u"ࠪࠤࠥࠦࡖࡪࡦࡨࡳࠥࡶ࡬ࡢࡻࠣࡹࡸ࡯࡮ࡨࠢࡶࡩࡹࡘࡥࡴࡱ࡯ࡺࡪࡪࡕࡳ࡮ࠫ࠭ࠥࠦࠠࡗ࡫ࡧࡩࡴࡀࠠ࡜ࠢࠪભ")+S6NALBOqGn1zi2W5M8y7+OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠫࠥࡣࠧમ"))
		u6sYmx5Dtz.setResolvedUrl(l95lLYCJweSnVHqzrstyPWcE,VBlawK4mgHSyLEn8iqhUkz5,lHNsoLY2cTdkQOPwx0hen)
	elif FE9OmZkMHn==xcChIL13BpR8WArNt9Pl0So(u"ࠬࡲࡩࡷࡧࠪય"):
		KteLZCbM8W0FqE2OBx1(pGYKHZgqFX3B,qhVEWvetzXLOcr1(xjPuFK3EsIZSiobQ5X)+hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"࠭ࠠࠡࠢࡏ࡭ࡻ࡫ࠠࡱ࡮ࡤࡽࠥࡻࡳࡪࡰࡪࠤࡵࡲࡡࡺࠪࠬࠤࠥࠦࡖࡪࡦࡨࡳ࠿࡛ࠦࠡࠩર")+S6NALBOqGn1zi2W5M8y7+CnbBKmtF1x84q7AW(u"ࠧࠡ࡟ࠪ઱"))
		kkS5tYma7qnKce4F9hdJA.play(S6NALBOqGn1zi2W5M8y7,lHNsoLY2cTdkQOPwx0hen)
	G62uf8ZSIzBE = fEXMiAyG3ql4vKB
	if qUjPtfo7ehkg5bsQyHrBm3Taxc0==wwPrSDa21lUh(u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦ࡬ࡲ࡬࠭લ"):
		from fJl3RLyKjw import H9iFRYq1pl07
		G62uf8ZSIzBE = H9iFRYq1pl07(S6NALBOqGn1zi2W5M8y7,LDceGoKZizXNV9m7bn6SU3W,SNyUT5iKbnD)
		if G62uf8ZSIzBE: QJieP0hZkz2slvKyn71OSto()
	else:
		CCiHoyQdYazj,qUjPtfo7ehkg5bsQyHrBm3Taxc0,J12F5utAn3YsrD,MNIAcfQdLsPHh,dM31xtBywgpAmWZ4SU2qsXReQYVG = ybdv7XcT3lxF6QezULwCAGk,hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠩࡷࡶ࡮࡫ࡤࠨળ"),fEXMiAyG3ql4vKB,HHoGx7Flus60(u"࠱࠱࠲࠳ୠ"),wwPrSDa21lUh(u"࠺࠵࠱࠲࠳ୟ")
		if ceZCjWpsPnTH6rbxmuE8tJF: from yoY3NdGViS import OnsAxhdVjZF
		while CCiHoyQdYazj<dM31xtBywgpAmWZ4SU2qsXReQYVG:
			MMk8qKvcJe4fQHm3EG7diBD5.sleep(MNIAcfQdLsPHh)
			CCiHoyQdYazj += MNIAcfQdLsPHh
			if kkS5tYma7qnKce4F9hdJA.aYNj9my0BglzWKEntZo==QVDJLRlxNg127jMX(u"ࠪࡷࡹࡧࡲࡵࡧࡧࠫ઴") and not J12F5utAn3YsrD:
				if ceZCjWpsPnTH6rbxmuE8tJF: OnsAxhdVjZF(jeAby54c02TgG8zuivonX91(u"๋ࠫาอหࠢ฼้้๐ษࠡวํะฬีࠠศๆไ๎ิ๐่ࠨવ"),LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"࡙ࠬࡵࡤࡥࡨࡷࡸ࠭શ"),HB5PvxRhwM=sULh4NjakzI8He7xJCMGrql(u"࠸࠷࠳ୡ"))
				KteLZCbM8W0FqE2OBx1(YYcbiF1UROXlga2,qhVEWvetzXLOcr1(xjPuFK3EsIZSiobQ5X)+DJ1ICpbyR2(u"࠭ࠠࠡࠢࡖࡹࡨࡩࡥࡴࡵ࠽ࠤࠥ࡜ࡩࡥࡧࡲࠤࡸࡺࡡࡳࡶࡨࡨࠥࠦࠠࡗ࡫ࡧࡩࡴࡀࠠ࡜ࠢࠪષ")+S6NALBOqGn1zi2W5M8y7+S1SgCFYGJeMvfp5iZXK(u"ࠧࠡ࡟ࠪસ")+k32ktvHFyin)
				J12F5utAn3YsrD = VBlawK4mgHSyLEn8iqhUkz5
			elif kkS5tYma7qnKce4F9hdJA.aYNj9my0BglzWKEntZo in [KNIvHPjUbhr(u"ࠨࡲ࡯ࡥࡾ࡯࡮ࡨࠩહ"),hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠩࡷࡩࡸࡺࡩ࡯ࡩࠪ઺")]:
				KteLZCbM8W0FqE2OBx1(YYcbiF1UROXlga2,qhVEWvetzXLOcr1(xjPuFK3EsIZSiobQ5X)+zyvJMtBhrw(u"ࠪࠤࠥࠦࡓࡶࡥࡦࡩࡸࡹ࠺࡙ࠡࠢ࡭ࡩ࡫࡯ࠡࡲ࡯ࡥࡾ࡯࡮ࡨࠢࠣࠤ࡛࡯ࡤࡦࡱ࠽ࠤࡠࠦࠧ઻")+S6NALBOqGn1zi2W5M8y7+zyvJMtBhrw(u"ࠫࠥࡣ઼ࠧ")+k32ktvHFyin)
				break
			elif kkS5tYma7qnKce4F9hdJA.aYNj9my0BglzWKEntZo==SqrG5mU3j96ldsFpExobw40TJY(u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬઽ"):
				KteLZCbM8W0FqE2OBx1(VRQE4jsXHSfhPWo5DgLwxGk,qhVEWvetzXLOcr1(xjPuFK3EsIZSiobQ5X)+QVDJLRlxNg127jMX(u"࠭ࠠࠡࠢࡉࡥ࡮ࡲࡥࡥࠢࡳࡰࡦࡿࡩ࡯ࡩࠣࡺ࡮ࡪࡥࡰࠢࠣࠤ࡛࡯ࡤࡦࡱ࠽ࠤࡠࠦࠧા")+S6NALBOqGn1zi2W5M8y7+A6dMB1FlgxVivJ2fk9C(u"ࠧࠡ࡟ࠪિ")+k32ktvHFyin)
				if ceZCjWpsPnTH6rbxmuE8tJF: OnsAxhdVjZF(OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠨใื่ฯูࠦๆๆํอࠥะิ฻์็ࠤฬ๊แ๋ัํ์ࠬી"),rwQN9AKhLCuMfHxjlbX0U(u"ࠩࡉࡥ࡮ࡲࡵࡳࡧࠪુ"),HB5PvxRhwM=o1u5dij9UrcbXzVS8lwIWfKpnqM(u"࠹࠸࠴ୢ"))
				break
			elif kkS5tYma7qnKce4F9hdJA.aYNj9my0BglzWKEntZo==OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠫૂ"):
				KteLZCbM8W0FqE2OBx1(pKJjfBXL51wlaTAs,qhVEWvetzXLOcr1(xjPuFK3EsIZSiobQ5X)+OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠫࠥࠦࠠࡅࡧࡹ࡭ࡨ࡫ࠠࡪࡵࠣࡦࡱࡵࡣ࡬ࡧࡧࠤࠥࠦࡖࡪࡦࡨࡳ࠿࡛ࠦࠡࠩૃ")+S6NALBOqGn1zi2W5M8y7+mkHKSQvjWr5BTcM3wVY(u"ࠬࠦ࡝ࠨૄ"))
				break
		else: qUjPtfo7ehkg5bsQyHrBm3Taxc0 = GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"࠭ࡴࡪ࡯ࡨࡳࡺࡺࠧૅ")
	if qUjPtfo7ehkg5bsQyHrBm3Taxc0 in [o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠧࡱ࡮ࡤࡽࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ૆")] or kkS5tYma7qnKce4F9hdJA.aYNj9my0BglzWKEntZo in [DJ1ICpbyR2(u"ࠨࡲ࡯ࡥࡾ࡯࡮ࡨࠩે"),QVDJLRlxNg127jMX(u"ࠩࡷࡩࡸࡺࡩ࡯ࡩࠪૈ")] or G62uf8ZSIzBE: stmA3SGjD6b(SNyUT5iKbnD)
	else: exec(OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠪ࡭ࡲࡶ࡯ࡳࡶࠣࡼࡧࡳࡣ࠼ࡺࡥࡱࡨ࠴ࡐ࡭ࡣࡼࡩࡷ࠮ࠩ࠯ࡵࡷࡳࡵ࠮ࠩࠨૉ"))
	e53tvFf6raEZH0iGXAQcWzKJ = MMk8qKvcJe4fQHm3EG7diBD5.Player().isPlaying()
	if not e53tvFf6raEZH0iGXAQcWzKJ and qUjPtfo7ehkg5bsQyHrBm3Taxc0 not in [LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࡯࡮ࡨࠩ૊")]:
		msg = XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"࡚ࠬࡩ࡮ࡧࡲࡹࡹ࠭ો") if qUjPtfo7ehkg5bsQyHrBm3Taxc0==e2qDYgipPmTw4KvBLnochr(u"࠭ࡴࡪ࡯ࡨࡳࡺࡺࠧૌ") else e2qDYgipPmTw4KvBLnochr(u"ࠧࡖࡰ࡮ࡲࡴࡽ࡮ࠨ્")
		if ceZCjWpsPnTH6rbxmuE8tJF: OnsAxhdVjZF(OOsBSKq9u6J2lC5WdYpvNMHaFP4(u"ࠨใื่ฯูࠦๆๆํอࠥะิ฻์็ࠤฬ๊แ๋ัํ์ࠬ૎"),msg,HB5PvxRhwM=KNIvHPjUbhr(u"࠺࠹࠵ୣ"))
		KteLZCbM8W0FqE2OBx1(VRQE4jsXHSfhPWo5DgLwxGk,qhVEWvetzXLOcr1(xjPuFK3EsIZSiobQ5X)+XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠩࠣࠤࠥ࠭૏")+msg+JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠪ࠾ࠥࠦࡕ࡯࡭ࡱࡳࡼࡴࠠࡱࡴࡲࡦࡱ࡫࡭࡚ࠡࠢࠣ࡮ࡪࡥࡰ࠼ࠣ࡟ࠥ࠭ૐ")+S6NALBOqGn1zi2W5M8y7+A6dMB1FlgxVivJ2fk9C(u"ࠫࠥࡣࠧ૑")+k32ktvHFyin)
	return kkS5tYma7qnKce4F9hdJA.aYNj9my0BglzWKEntZo
def UGBbEtrcu5jLC6Sxoa3gFyP1mJOpW(S6NALBOqGn1zi2W5M8y7):
	if H4qZ2hwilNJYTmCFEQyaSs98cPM0gR: from urllib.parse import urlparse as JZ4Htn6evyqWMEzSmo1sAbPiwxRT
	else: from urlparse import urlparse as JZ4Htn6evyqWMEzSmo1sAbPiwxRT
	path = JZ4Htn6evyqWMEzSmo1sAbPiwxRT(S6NALBOqGn1zi2W5M8y7).path
	LgWESKmdItVal = hWGMqtBy4wuLaVcj if dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠬ࠴ࠧ૒") not in path else path.rsplit(FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"࠭࠮ࠨ૓"),DJ1ICpbyR2(u"࠵୤"))[bXukYxQ4aHw]
	if LgWESKmdItVal in [NeO3CTLHrPfWUoIgy8Q(u"ࠧࡢࡸ࡬ࠫ૔"),rwQN9AKhLCuMfHxjlbX0U(u"ࠨࡶࡶࠫ૕"),dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠩࡤࡥࡨ࠭૖"),GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠪࡱࡵ࠺ࠧ૗"),e2qDYgipPmTw4KvBLnochr(u"ࠫࡲ࠹ࡵࠨ૘"),LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠬࡳ࠳ࡶ࠺ࠪ૙"),xcChIL13BpR8WArNt9Pl0So(u"࠭࡭ࡱࡦࠪ૚"),CnbBKmtF1x84q7AW(u"ࠧ࡮࡭ࡹࠫ૛"),gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠨࡨ࡯ࡺࠬ૜"),JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠩࡰࡴ࠸࠭૝"),hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠪࡻࡪࡨ࡭ࠨ૞")]: return xcChIL13BpR8WArNt9Pl0So(u"ࠫ࠳࠭૟")+LgWESKmdItVal
	return hWGMqtBy4wuLaVcj
def stmA3SGjD6b(fhobD4JvAis7ndHL):
	if not MmcgqAlsFt.sTZjaIcENd: fhobD4JvAis7ndHL += NeO3CTLHrPfWUoIgy8Q(u"ࠬࡥࡔࡔࠩૠ")
	iO1SgmkzGYaFoPXbfdj3NxQBus.append(fhobD4JvAis7ndHL)
	return
def vn97kbzpVDXotqS6RhuK2srl(RP48gml6IJ5dAzi1DuWXvsLF9ye=fEXMiAyG3ql4vKB):
	EZAp20cJB35S(RP48gml6IJ5dAzi1DuWXvsLF9ye,JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"࠭࡟ࡠࡡࡉࡓࡗࡉࡅࡠࡇ࡛ࡍ࡙ࡥ࡟ࡠࠩૡ"))
	zGjD5QAkd7SO9YPcZl.exit()
def EZAp20cJB35S(RP48gml6IJ5dAzi1DuWXvsLF9ye,wF5zRoQekA9lxOYacnju13yUIDs):
	if wF5zRoQekA9lxOYacnju13yUIDs:
		if QvgnCALNstmuUJiET(u"ࠧࡠࡡࡢࡊࡔࡘࡃࡆࡡࡈ࡜ࡎ࡚࡟ࡠࡡࠪૢ") in wF5zRoQekA9lxOYacnju13yUIDs: KteLZCbM8W0FqE2OBx1(hWGMqtBy4wuLaVcj,XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠨࡡࡢࡣࡋࡕࡒࡄࡇࡢࡉ࡝ࡏࡔࡠࡡࡢࠫૣ"))
		else:
			ZZdrzYJuScnhwiApxV = ee8c0jzrTntGSUdRJm.getSetting(ITvnUAMXsyb4eO(u"ࠩࡤࡺ࠳ࡲࡡ࡯ࡩࡸࡥ࡬࡫࠮ࡵࡴࡤࡲࡸࡲࡡࡵࡧࠪ૤"))
			ee8c0jzrTntGSUdRJm.setSetting(XQo0YS3sk4rHAvwyNltf9CipLWMjx(u"ࠪࡥࡻ࠴࡬ࡢࡰࡪࡹࡦ࡭ࡥ࠯ࡶࡵࡥࡳࡹ࡬ࡢࡶࡨࠫ૥"),hWGMqtBy4wuLaVcj)
			import yoY3NdGViS
			yoY3NdGViS.OHVmqy3Zi1(wF5zRoQekA9lxOYacnju13yUIDs)
			ee8c0jzrTntGSUdRJm.setSetting(mkHKSQvjWr5BTcM3wVY(u"ࠫࡦࡼ࠮࡭ࡣࡱ࡫ࡺࡧࡧࡦ࠰ࡷࡶࡦࡴࡳ࡭ࡣࡷࡩࠬ૦"),ZZdrzYJuScnhwiApxV)
	MewdQi3zF4maS9TZRopbA1hUI(DJ1ICpbyR2(u"ࠬࡹࡴࡰࡲࠪ૧"))
	agkF7iSBOZ4DKJC25yztrsN86cXLfV = ee8c0jzrTntGSUdRJm.getSetting(jeAby54c02TgG8zuivonX91(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡵࡩ࡫ࡸࡥࡴࡪࠪ૨"))
	if agkF7iSBOZ4DKJC25yztrsN86cXLfV==wwPrSDa21lUh(u"ࠧࡓࡇࡔ࡙ࡊ࡙ࡔࡠࡔࡈࡊࡗࡋࡓࡉࡡࡆࡅࡈࡎࡅࠨ૩"): ee8c0jzrTntGSUdRJm.setSetting(GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡷ࡫ࡦࡳࡧࡶ࡬ࠬ૪"),QVDJLRlxNg127jMX(u"ࠩࡕࡉࡋࡘࡅࡔࡊࡢࡇࡆࡉࡈࡆࠩ૫"))
	elif agkF7iSBOZ4DKJC25yztrsN86cXLfV==jeAby54c02TgG8zuivonX91(u"ࠪࡖࡊࡌࡒࡆࡕࡋࡣࡈࡇࡃࡉࡇࠪ૬"): ee8c0jzrTntGSUdRJm.setSetting(DJ1ICpbyR2(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡳࡧࡩࡶࡪࡹࡨࠨ૭"),hWGMqtBy4wuLaVcj)
	if ee8c0jzrTntGSUdRJm.getSetting(dv0trJR7PwmKyxDYO52VLau8gEph(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡷࡶࡩࡩࡴࡳࠨ૮")) not in [HHoGx7Flus60(u"࠭ࡁࡖࡖࡒࠫ૯"),o1u5dij9UrcbXzVS8lwIWfKpnqM(u"ࠧࡔࡖࡒࡔࠬ૰"),CnbBKmtF1x84q7AW(u"ࠨࡃࡖࡏࠬ૱")]: ee8c0jzrTntGSUdRJm.setSetting(CnbBKmtF1x84q7AW(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡦࡱࡷࠬ૲"),ITvnUAMXsyb4eO(u"ࠪࡅࡘࡑࠧ૳"))
	if ee8c0jzrTntGSUdRJm.getSetting(zyvJMtBhrw(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡵࡨࡴࡷࡵࡸࡺࠩ૴")) not in [MMizeNH0AKu(u"ࠬࡇࡕࡕࡑࠪ૵"),SqrG5mU3j96ldsFpExobw40TJY(u"࠭ࡓࡕࡑࡓࠫ૶"),KNIvHPjUbhr(u"ࠧࡂࡕࡎࠫ૷")]: ee8c0jzrTntGSUdRJm.setSetting(FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡺࡹࡥࡱࡴࡲࡼࡾ࠭૸"),MMizeNH0AKu(u"ࠩࡄࡗࡐ࠭ૹ"))
	cqvXhUjC7sSYB6ie5aoK4rxFDGbN = ee8c0jzrTntGSUdRJm.getSetting(QvgnCALNstmuUJiET(u"ࠪࡥࡻ࠴࡭ࡺࡵ࡮࡭ࡳ࠴ࡶࡪࡧࡺࡱࡴࡪࡥࠨૺ"))
	Voz0n8C7vtfg26SR9DFuqKTE = MMk8qKvcJe4fQHm3EG7diBD5.executeJSONRPC(zyvJMtBhrw(u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡗࡪࡺࡴࡪࡰࡪࡷ࠳ࡍࡥࡵࡕࡨࡸࡹ࡯࡮ࡨࡘࡤࡰࡺ࡫ࠢ࠭ࠤ࡬ࡨࠧࡀ࠱࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡹࡥࡵࡶ࡬ࡲ࡬ࠨ࠺ࠣ࡮ࡲࡳࡰࡧ࡮ࡥࡨࡨࡩࡱ࠴ࡳ࡬࡫ࡱࠦࢂࢃࠧૻ"))
	if FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠬࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇࠫૼ") in str(Voz0n8C7vtfg26SR9DFuqKTE) and cqvXhUjC7sSYB6ie5aoK4rxFDGbN in [dv0trJR7PwmKyxDYO52VLau8gEph(u"࠭ࡅࡎࡃࡇࠤࡑ࡯ࡳࡵࠩ૽"),hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠧࡆࡏࡄࡈࠥࡍࡡ࡭࡮ࡨࡶࡾ࠭૾")]:
		HB5PvxRhwM.sleep(A6dMB1FlgxVivJ2fk9C(u"࠵࠴࠱࠱࠲୥"))
		MMk8qKvcJe4fQHm3EG7diBD5.executebuiltin(JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡘ࡫ࡴࡗ࡫ࡨࡻࡒࡵࡤࡦࠪ࠳࠭ࠬ૿"))
	if ybdv7XcT3lxF6QezULwCAGk and l95lLYCJweSnVHqzrstyPWcE>-bXukYxQ4aHw:
		u6sYmx5Dtz.setResolvedUrl(l95lLYCJweSnVHqzrstyPWcE,fEXMiAyG3ql4vKB,mUWYiQ2jHICA8cD6LhPTn3wpB1XyK.ListItem())
		G62uf8ZSIzBE,W5mewaZEsh,b9Vog0ysSGkHzAMZnarhJE2wFQmXq1 = fEXMiAyG3ql4vKB,fEXMiAyG3ql4vKB,fEXMiAyG3ql4vKB
		u6sYmx5Dtz.endOfDirectory(l95lLYCJweSnVHqzrstyPWcE,G62uf8ZSIzBE,W5mewaZEsh,b9Vog0ysSGkHzAMZnarhJE2wFQmXq1)
	if iO1SgmkzGYaFoPXbfdj3NxQBus:
		if DJ1ICpbyR2(u"ࠩࡇࡓࡓࡇࡔࡊࡑࡑࡗࠬ଀") in str(iO1SgmkzGYaFoPXbfdj3NxQBus) and SqrG5mU3j96ldsFpExobw40TJY(u"ࠪࡕ࡚ࡋࡓࡕࡋࡒࡒࡘ࠭ଁ") in str(iO1SgmkzGYaFoPXbfdj3NxQBus) and DJ1ICpbyR2(u"ࠫࡒࡋࡓࡔࡃࡊࡉࡘ࠭ଂ") in str(iO1SgmkzGYaFoPXbfdj3NxQBus):
			for fhobD4JvAis7ndHL in [S1SgCFYGJeMvfp5iZXK(u"ࠬࡓࡅࡔࡕࡄࡋࡊ࡙ࠧଃ"),KBkxSYaz93pu1(u"࠭ࡑࡖࡇࡖࡘࡎࡕࡎࡔࠩ଄"),JwiZdgbG5HYuCIsj69aBSRQ0nrNkET(u"ࠧࡎࡇࡖࡗࡆࡍࡅࡔࡡࡗࡗࠬଅ"),LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠨࡓࡘࡉࡘ࡚ࡉࡐࡐࡖࡣ࡙࡙ࠧଆ")]:
				if fhobD4JvAis7ndHL in iO1SgmkzGYaFoPXbfdj3NxQBus: iO1SgmkzGYaFoPXbfdj3NxQBus.remove(fhobD4JvAis7ndHL)
		HtAfYER2ZizpXLN3acoyI = KCTRe67wVy.Thread(target=C5NA8EQG2cS3FbfXU47DM,args=(iO1SgmkzGYaFoPXbfdj3NxQBus,))
		HtAfYER2ZizpXLN3acoyI.start()
	Urykt2O9e0qXF7vhuo8 = ooH16lsAetOSVay8()
	e53tvFf6raEZH0iGXAQcWzKJ = MMk8qKvcJe4fQHm3EG7diBD5.Player().isPlaying()
	if Urykt2O9e0qXF7vhuo8 and e53tvFf6raEZH0iGXAQcWzKJ:
		do2v8ZANEy = mqfBLz4JuEyQZRxUIFOtnVTrSga5()
		if do2v8ZANEy:
			MmcgqAlsFt.resolveonly = VBlawK4mgHSyLEn8iqhUkz5
			HB5PvxRhwM.sleep(LB2q7IVRpcyXlE6C3ihZruPe4An1Y(u"࠼࠰୦"))
			e53tvFf6raEZH0iGXAQcWzKJ = MMk8qKvcJe4fQHm3EG7diBD5.Player().isPlaying()
			if e53tvFf6raEZH0iGXAQcWzKJ:
				X3X4Y8RzxSVfZJUFDe,wJUqaIAzvtsMSEZlKV,S6NALBOqGn1zi2W5M8y7,u2GRrQ0854,nWE8aO53lFfD,l7COkhRWD9uVS60Pte2NoyAaZn,XNBHzrlKD9yW,MH5c7Nekugx8O1AQjInRWyT64GV,SX7OT3VLGp2iQm = vikbdSOtZJFz6gQeL(do2v8ZANEy)
				import yoY3NdGViS
				if not any(BoSjXKxz41DcneO9UimClE in wJUqaIAzvtsMSEZlKV for BoSjXKxz41DcneO9UimClE in yoY3NdGViS.NOT_TO_TEST_ALL_SERVERS):
					yoY3NdGViS.OnsAxhdVjZF(gDuGMR3z1aV6YdLmCpiO8Kl(u"ࠩส่ๆ๐ฯ๋๊ࠣห้๊วฮไࠪଇ"),DJ1ICpbyR2(u"ࠪๅา฻ࠠอ็ํ฽ࠥอไิ์ิๅึอสࠨଈ"),HB5PvxRhwM=KBkxSYaz93pu1(u"࠲࠱࠲࠳୧"))
					HB5PvxRhwM.sleep(e2qDYgipPmTw4KvBLnochr(u"࠳୨"))
					if VKiGj1LundAJQwEXcqgxC:
						S6NALBOqGn1zi2W5M8y7 = S6NALBOqGn1zi2W5M8y7.encode(a7VXeDU82IfQEnPZAdiT)
					N6NCYivtV4I5rEXq = yoY3NdGViS.lqvO2yUHs3ZQtxzGYFK(X3X4Y8RzxSVfZJUFDe,wJUqaIAzvtsMSEZlKV,S6NALBOqGn1zi2W5M8y7,u2GRrQ0854,nWE8aO53lFfD,l7COkhRWD9uVS60Pte2NoyAaZn,XNBHzrlKD9yW,MH5c7Nekugx8O1AQjInRWyT64GV,SX7OT3VLGp2iQm)
					yoY3NdGViS.OnsAxhdVjZF(QVDJLRlxNg127jMX(u"ࠫࠬଉ"),FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠬอๆห้์ࠤๆำีࠡษ็ื๏ืแาษอࠫଊ"),HB5PvxRhwM=e2qDYgipPmTw4KvBLnochr(u"࠴࠳࠴࠵୩"))
	if RP48gml6IJ5dAzi1DuWXvsLF9ye: MMk8qKvcJe4fQHm3EG7diBD5.executebuiltin(EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪଋ"))
	return
def mqfBLz4JuEyQZRxUIFOtnVTrSga5():
	apRZt8FYQmgvI7 = MMk8qKvcJe4fQHm3EG7diBD5.executeJSONRPC(KBkxSYaz93pu1(u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡐ࡭ࡣࡼࡰ࡮ࡹࡴ࠯ࡉࡨࡸࡎࡺࡥ࡮ࡵࠥ࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡲ࡯ࡥࡾࡲࡩࡴࡶ࡬ࡨࠧࡀ࠱࠭ࠤࡳࡶࡴࡶࡥࡳࡶ࡬ࡩࡸࠨ࠺࡜ࠤࡷ࡭ࡹࡲࡥࠣ࠮ࠥࡪ࡮ࡲࡥࠣ࠮ࠥࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࠨ࡝ࡾ࠮ࠥ࡭ࡩࠨ࠺࠲ࡿࠪଌ"))
	N6NCYivtV4I5rEXq = TPDQ5L9eWpIJcrM3YH48Cs6.loads(apRZt8FYQmgvI7)[sULh4NjakzI8He7xJCMGrql(u"ࠨࡴࡨࡷࡺࡲࡴࠨ଍")]
	do2v8ZANEy = hWGMqtBy4wuLaVcj
	try: items = N6NCYivtV4I5rEXq[hWUz1ujibPY3G9MIZmvS4kVaK7dT(u"ࠩ࡬ࡸࡪࡳࡳࠨ଎")]
	except: return hWGMqtBy4wuLaVcj
	if items:
		for XK2iWMx6yfU9E,file in enumerate(items):
			path = file[FimxS5jkaq1RcJ8DnWTZNO4zQClwt(u"ࠪࡪ࡮ࡲࡥࠨଏ")]
			if nUy7x6dqmk92MPb not in path: continue
			path = path.split(nUy7x6dqmk92MPb)[bXukYxQ4aHw][bXukYxQ4aHw:]
			if path==i2tpOA6QzlfUByTSeKacWnV1: break
		count = N6NCYivtV4I5rEXq[HHoGx7Flus60(u"ࠫࡱ࡯࡭ࡪࡶࡶࠫଐ")][NeO3CTLHrPfWUoIgy8Q(u"ࠬࡺ࡯ࡵࡣ࡯ࠫ଑")]
		if XK2iWMx6yfU9E+bXukYxQ4aHw<count: do2v8ZANEy = items[XK2iWMx6yfU9E+bXukYxQ4aHw][rwQN9AKhLCuMfHxjlbX0U(u"࠭ࡦࡪ࡮ࡨࠫ଒")]
	return do2v8ZANEy
def ooH16lsAetOSVay8():
	ayNEJoZrebx2usT = MMk8qKvcJe4fQHm3EG7diBD5.executeJSONRPC(ITvnUAMXsyb4eO(u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠤࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡔࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡊࡩࡹ࡙ࡥࡵࡶ࡬ࡲ࡬࡜ࡡ࡭ࡷࡨࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡶࡩࡹࡺࡩ࡯ࡩࠥ࠾ࠧࡼࡩࡥࡧࡲࡴࡱࡧࡹࡦࡴ࠱ࡥࡺࡺ࡯ࡱ࡮ࡤࡽࡳ࡫ࡸࡵ࡫ࡷࡩࡲࠨࡽࡾࠩଓ"))
	jj8ZdyQ4slV9BtTD6nSFNALaX1bc = fEXMiAyG3ql4vKB if KBkxSYaz93pu1(u"ࠨ࡝ࡠࠫଔ") in str(ayNEJoZrebx2usT) else VBlawK4mgHSyLEn8iqhUkz5
	return jj8ZdyQ4slV9BtTD6nSFNALaX1bc
def MewdQi3zF4maS9TZRopbA1hUI(hDYVOWiM6Rfu2mzHvSAw):
	global oKcOsHdzwePgh7
	if oKcOsHdzwePgh7:
		if hDYVOWiM6Rfu2mzHvSAw==xcChIL13BpR8WArNt9Pl0So(u"ࠩࡶࡸࡴࡶࠧକ"):
			H3Y6T7ZdRIFW5fDGyzCUMcjAntJ = rwQN9AKhLCuMfHxjlbX0U(u"ࠪࡦࡺࡹࡹࡥ࡫ࡤࡰࡴ࡭࡮ࡰࡥࡤࡲࡨ࡫࡬ࠨଖ") if guSzmUCXDa1tQpY>S1SgCFYGJeMvfp5iZXK(u"࠴࠻࠳࠿࠹୪") else HHoGx7Flus60(u"ࠫࡧࡻࡳࡺࡦ࡬ࡥࡱࡵࡧࠨଗ")
			MMk8qKvcJe4fQHm3EG7diBD5.executebuiltin(wwPrSDa21lUh(u"ࠬࡊࡩࡢ࡮ࡲ࡫࠳ࡉ࡬ࡰࡵࡨࠬࠬଘ")+H3Y6T7ZdRIFW5fDGyzCUMcjAntJ+QVDJLRlxNg127jMX(u"࠭ࠩࠨଙ"))
			oKcOsHdzwePgh7 = fEXMiAyG3ql4vKB
	else:
		if hDYVOWiM6Rfu2mzHvSAw==e2qDYgipPmTw4KvBLnochr(u"ࠧࡴࡶࡤࡶࡹ࠭ଚ"):
			H3Y6T7ZdRIFW5fDGyzCUMcjAntJ = jeAby54c02TgG8zuivonX91(u"ࠨࡤࡸࡷࡾࡪࡩࡢ࡮ࡲ࡫ࡳࡵࡣࡢࡰࡦࡩࡱ࠭ଛ") if guSzmUCXDa1tQpY>zyvJMtBhrw(u"࠵࠼࠴࠹࠺୫") else GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠩࡥࡹࡸࡿࡤࡪࡣ࡯ࡳ࡬࠭ଜ")
			MMk8qKvcJe4fQHm3EG7diBD5.executebuiltin(EDgpT9hIF6GCfl0vXiWnBANjOUVRua(u"ࠪࡅࡨࡺࡩࡷࡣࡷࡩ࡜࡯࡮ࡥࡱࡺࠬࠬଝ")+H3Y6T7ZdRIFW5fDGyzCUMcjAntJ+QVDJLRlxNg127jMX(u"ࠫ࠮࠭ଞ"))
			oKcOsHdzwePgh7 = VBlawK4mgHSyLEn8iqhUkz5
	return
o21gzZ6MkmL50BCd,nnNT5p14Y3gZJWVK2xI67XtFjCQPaD = None,None
iO1SgmkzGYaFoPXbfdj3NxQBus = []
IIvxtojw6EXl2f = rV36aR5MufG1tqOWAlkYepcDd()
j8fz6cKJpAb7kedIsS = IIvxtojw6EXl2f.splitlines()[ybdv7XcT3lxF6QezULwCAGk][-sULh4NjakzI8He7xJCMGrql(u"࠷࠺୬"):]
MmcgqAlsFt.j0juxvCpdOFDk2,MmcgqAlsFt.sTZjaIcENd,MmcgqAlsFt.W5bBlPX8OGRw26oeT4Zctp,MmcgqAlsFt.PiR735OmVcFjpE0yeCoM4 = NNA8aswIZfdr2([GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠬࡉࡔࡆ࠻ࡇࡗ࠶࠿ࡖࡖ࠲࡙ࡗ࡝࠭ଟ"),CnbBKmtF1x84q7AW(u"࠭ࡗࡔࡗࡕࡊ࡙࠷࠹ࡒࡖࡈࡊ࡟࡞ࠧଠ"),LAhIMyBG0xZVUlO4rJ9z5fbDFgCs(u"ࠧࡃࡖࡈࡼࡕ࡜࠱࠺ࡗࡕ࡚ࡓ࡛ࡓࡖ࠷ࡋ࡜ࠬଡ"),GA4NBdjuZqkKUX6IEMvHPoegDyVrLm(u"ࠨࡑࡗ࠵࠾ࡐࡕ࠱ࡺࡅࡘ࡚ࡲࡄ࡙ࠩଢ")])
MmavK9YO5hEt4q8LjX6cuW = hWGMqtBy4wuLaVcj
MmcgqAlsFt.resolveonly = fEXMiAyG3ql4vKB
kkS5tYma7qnKce4F9hdJA = ZbAY8pMkFvzJWaNQj7B()
MmcgqAlsFt.showDialogs = VBlawK4mgHSyLEn8iqhUkz5
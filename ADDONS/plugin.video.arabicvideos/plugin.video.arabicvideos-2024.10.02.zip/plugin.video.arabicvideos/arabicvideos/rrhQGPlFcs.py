# -*- coding: utf-8 -*-
from yoY3NdGViS import *
xjPuFK3EsIZSiobQ5X = 'FAJERSHOW'
n0qFKQWhiBYXoTrvejVHUA4 = '_FJS_'
Str0BupDTFA = u6rbxnyjTl7I[xjPuFK3EsIZSiobQ5X][0]
P3UK1Rr4IdYe5 = ['التصنيفات','انشاء حساب','طلبات الزوّار']
def ehB18u9sQFRi(mode,url,text):
	if   mode==390: N6NCYivtV4I5rEXq = DP6FSBgNdX1rsvVR()
	elif mode==391: N6NCYivtV4I5rEXq = wg5aF3e8rcDh7SGpW6M1OPnkU(url,text)
	elif mode==392: N6NCYivtV4I5rEXq = oanus6TxUFNAhSZKpJdYlEC4mV(url)
	elif mode==393: N6NCYivtV4I5rEXq = GrsxUhb0PEXj2FQRAkD4q(url)
	elif mode==399: N6NCYivtV4I5rEXq = lPwaAjFTMG4n7iSLkXcEuK0Zm(text)
	else: N6NCYivtV4I5rEXq = False
	return N6NCYivtV4I5rEXq
def DP6FSBgNdX1rsvVR():
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'بحث في الموقع',hWGMqtBy4wuLaVcj,399,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'_REMEMBERRESULTS_')
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(DpQifS0oKBI1hYcO,'GET',Str0BupDTFA,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'FAJERSHOW-MENU-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	items = trdVA0JvFaD.findall('<header>.*?<h2>(.*?)<',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	for XK2iWMx6yfU9E in range(len(items)):
		title = items[XK2iWMx6yfU9E]
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+title,Str0BupDTFA,391,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'latest'+str(XK2iWMx6yfU9E))
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+'مختارات عشوائية',Str0BupDTFA,391,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'randoms')
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+'أعلى الأفلام تقييماً',Str0BupDTFA,391,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'top_imdb_movies')
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+'أعلى المسلسلات تقييماً',Str0BupDTFA,391,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'top_imdb_series')
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+'أفلام مميزة',Str0BupDTFA+'/movies',391,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'featured_movies')
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+'مسلسلات مميزة',Str0BupDTFA+'/tvshows',391,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'featured_tvshows')
	cok5ZGXdQP7YhwtqyuaCnVevm6UB = hWGMqtBy4wuLaVcj
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('class="menu"(.*?)id="contenedor"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o: cok5ZGXdQP7YhwtqyuaCnVevm6UB += DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(DpQifS0oKBI1hYcO,'GET',Str0BupDTFA+'/movies',hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'FAJERSHOW-MENU-2nd')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('class="releases"(.*?)aside',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o: cok5ZGXdQP7YhwtqyuaCnVevm6UB += DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	items = trdVA0JvFaD.findall('href="(.*?)">(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	jlIGSiUuRophY8A = True
	for llxFwq0CUNgQtivJzkHeGV,title in items:
		title = LNtIDdBA52P(title)
		if title=='الأعلى مشاهدة':
			if jlIGSiUuRophY8A:
				title = 'الافلام '+title
				jlIGSiUuRophY8A = False
			else: title = 'المسلسلات '+title
		if title not in P3UK1Rr4IdYe5:
			if title=='أفلام': RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+title,Str0BupDTFA+'/movies',391,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'all_movies_tvshows')
			elif title=='مسلسلات': RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+title,Str0BupDTFA+'/tvshows',391,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'all_movies_tvshows')
			else: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,391)
	return mMQ3FkNVa4IlxqY
def wg5aF3e8rcDh7SGpW6M1OPnkU(url,type):
	cok5ZGXdQP7YhwtqyuaCnVevm6UB,items = [],[]
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'FAJERSHOW-TITLES-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	if type in ['featured_movies','featured_tvshows']:
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('class="content"(.*?)id="archive-content"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if DJvksH7ZAFUqW9OyQnbGjPCtwR1o: cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
	elif type=='all_movies_tvshows':
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('id="archive-content"(.*?)class="pagination"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if DJvksH7ZAFUqW9OyQnbGjPCtwR1o: cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
	elif type=='top_imdb_movies':
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall("class='top-imdb-list tleft(.*?)class='top-imdb-list tright",mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
			cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
			items = trdVA0JvFaD.findall("img src='(.*?)'.*?href='(.*?)'>(.*?)<",cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	elif type=='top_imdb_series':
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall("class='top-imdb-list tright(.*?)footer",mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
			cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
			items = trdVA0JvFaD.findall("img src='(.*?)'.*?href='(.*?)'>(.*?)<",cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	elif type=='search':
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('class="search-page"(.*?)class="sidebar',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
			cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
			items = trdVA0JvFaD.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	elif type=='sider':
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('class="widget(.*?)class="widget',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		iwkQ8Wf5GDxsHTFLrV0Pp14On = trdVA0JvFaD.findall('href="(.*?)".*?img src="(.*?)".*?<h3>(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		Dvi8asSrQYX5wE3KMIxT91me,OfpxWZ5PdcHAIXE76zQh,haq1bHZINPE58uoBFnKfTSO2ik4 = zip(*iwkQ8Wf5GDxsHTFLrV0Pp14On)
		items = zip(OfpxWZ5PdcHAIXE76zQh,Dvi8asSrQYX5wE3KMIxT91me,haq1bHZINPE58uoBFnKfTSO2ik4)
	elif type=='randoms':
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('id="slider-movies-tvshows"(.*?)<header>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	elif 'latest' in type:
		XK2iWMx6yfU9E = int(type[-1:])
		mMQ3FkNVa4IlxqY = mMQ3FkNVa4IlxqY.replace('<header>','<end><start>')
		mMQ3FkNVa4IlxqY = mMQ3FkNVa4IlxqY.replace('</div></div></div>','</div></div></div><end>')
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('<start>(.*?)<end>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[XK2iWMx6yfU9E]
		if XK2iWMx6yfU9E==6:
			iwkQ8Wf5GDxsHTFLrV0Pp14On = trdVA0JvFaD.findall('img src="(.*?)" alt="(.*?)".*?href="(.*?)"',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
			OfpxWZ5PdcHAIXE76zQh,haq1bHZINPE58uoBFnKfTSO2ik4,Dvi8asSrQYX5wE3KMIxT91me = zip(*iwkQ8Wf5GDxsHTFLrV0Pp14On)
			items = zip(OfpxWZ5PdcHAIXE76zQh,Dvi8asSrQYX5wE3KMIxT91me,haq1bHZINPE58uoBFnKfTSO2ik4)
	else:
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('class="content"(.*?)class="(pagination|sidebar)',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
			cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0][0]
			if '/collection/' in url:
				items = trdVA0JvFaD.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
			elif '/quality/' in url:
				items = trdVA0JvFaD.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	if not items and cok5ZGXdQP7YhwtqyuaCnVevm6UB:
		items = trdVA0JvFaD.findall('img src="(.*?)".*?href=.*?href="(.*?)">(.*?)</div>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	REbVyXis1w4Ae = []
	for Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,llxFwq0CUNgQtivJzkHeGV,title in items:
		if 'src=' in title: continue
		if 'serie' in title:
			title = trdVA0JvFaD.findall('^(.*?)<.*?serie">(.*?)<',title,trdVA0JvFaD.DOTALL)
			title = title[0][1]
			if title in REbVyXis1w4Ae: continue
			REbVyXis1w4Ae.append(title)
			title = '_MOD_'+title
		m4eVoJdSU51qs3y8Gg06fZNau7A = trdVA0JvFaD.findall('^(.*?)<',title,trdVA0JvFaD.DOTALL)
		if m4eVoJdSU51qs3y8Gg06fZNau7A: title = m4eVoJdSU51qs3y8Gg06fZNau7A[0]
		title = LNtIDdBA52P(title)
		if '/tvshows/' in llxFwq0CUNgQtivJzkHeGV: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,393,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
		elif '/episodes/' in llxFwq0CUNgQtivJzkHeGV: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,393,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
		elif '/seasons/' in llxFwq0CUNgQtivJzkHeGV: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,393,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
		elif '/collection/' in llxFwq0CUNgQtivJzkHeGV: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,391,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
		else: RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,392,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
	if type not in ['featured_movies','featured_tvshows']:
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('"pagination"(.*?)</div>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
			cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
			items = trdVA0JvFaD.findall('href="(.*?)".*?>(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
			for llxFwq0CUNgQtivJzkHeGV,title in items:
				RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'صفحة '+title,llxFwq0CUNgQtivJzkHeGV,391,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,type)
	return
def GrsxUhb0PEXj2FQRAkD4q(url):
	SODQ7qlNYoZcFK8e50rBsJaAHxiXjE = RRNODILCtGzvgpx(url,'url')
	url = url.replace(SODQ7qlNYoZcFK8e50rBsJaAHxiXjE,Str0BupDTFA)
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'FAJERSHOW-EPISODES-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	BX029UJFPvpNQsc45jbYZRh = trdVA0JvFaD.findall('class="C rated".*?>(.*?)<',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if BX029UJFPvpNQsc45jbYZRh and Dc20k3vN9hT5(xjPuFK3EsIZSiobQ5X,url,BX029UJFPvpNQsc45jbYZRh): return
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('<ul class="episodios">(.*?)</ul></div></div></div>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('src="(.*?)".*?href="(.*?)">(.*?)</a>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,llxFwq0CUNgQtivJzkHeGV,title in items:
			RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,392,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
	return
def oanus6TxUFNAhSZKpJdYlEC4mV(url):
	mMQ3FkNVa4IlxqY = NNnAUwYFTOPH4m(KqO5BWGQR9JVL,'GET',url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'FAJERSHOW-PLAY-1st')
	BX029UJFPvpNQsc45jbYZRh = trdVA0JvFaD.findall('class="C rated".*?>(.*?)<',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if BX029UJFPvpNQsc45jbYZRh and Dc20k3vN9hT5(xjPuFK3EsIZSiobQ5X,url,BX029UJFPvpNQsc45jbYZRh): return
	Dvi8asSrQYX5wE3KMIxT91me = []
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('id="player-option-1"(.*?)class=["|\'](sheader|pag_episodes)["|\']',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0][0]
		items = trdVA0JvFaD.findall('data-type="(.*?)" data-post="(.*?)" data-nume="(.*?)".*?class="vid_title">(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for type,NIsiUn6g8xMOuZvz2kejD,sWtdCX5Sv9,title in items:
			llxFwq0CUNgQtivJzkHeGV = Str0BupDTFA+'/wp-admin/admin-ajax.php?action=doo_player_ajax&post='+NIsiUn6g8xMOuZvz2kejD+'&nume='+sWtdCX5Sv9+'&type='+type
			llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV+'?named='+title+'__watch'
			Dvi8asSrQYX5wE3KMIxT91me.append(llxFwq0CUNgQtivJzkHeGV)
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('''id=["']download["'] class(.*?)class=["']sbox["']''',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('''img src=["'](.*?)["'].*?href=["'](.*?)["'].*?["']quality["']>(.*?)<.*?<td>(.*?)<''',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,llxFwq0CUNgQtivJzkHeGV,QS8ZdxkHD5bjU9qsn4zMYaPrg3h7,aawXIHdWlt7k in items:
			if '=' in Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG:
				RfOudJtqk4U3 = Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG.split('=')[1]
				title = RRNODILCtGzvgpx(RfOudJtqk4U3,'host')
			else: title = hWGMqtBy4wuLaVcj
			title = aawXIHdWlt7k+Mpsm2VF1OBnCRvK3qf6+title
			llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV+'?named='+title+'__download____'+QS8ZdxkHD5bjU9qsn4zMYaPrg3h7
			Dvi8asSrQYX5wE3KMIxT91me.append(llxFwq0CUNgQtivJzkHeGV)
	import oosSOfvdEQ
	oosSOfvdEQ.zfdYjsGLg8M6i15qZWh(Dvi8asSrQYX5wE3KMIxT91me,xjPuFK3EsIZSiobQ5X,'video',url)
	return
def lPwaAjFTMG4n7iSLkXcEuK0Zm(search):
	search,vvKf4sXgZIMyEJPuC,showDialogs = IVTEJQOiMR2dYta9C(search)
	if search==hWGMqtBy4wuLaVcj: search = TrzfUidpv1LyAYqwexHJDuS()
	if search==hWGMqtBy4wuLaVcj: return
	search = search.replace(Mpsm2VF1OBnCRvK3qf6,'+')
	url = Str0BupDTFA+'/?s='+search
	wg5aF3e8rcDh7SGpW6M1OPnkU(url,'search')
	return
# -*- coding: utf-8 -*-
from yoY3NdGViS import *
xjPuFK3EsIZSiobQ5X = 'CIMACLUP'
n0qFKQWhiBYXoTrvejVHUA4 = '_CMC_'
Str0BupDTFA = u6rbxnyjTl7I[xjPuFK3EsIZSiobQ5X][0]
P3UK1Rr4IdYe5 = ['موقع نتفليكس']
def ehB18u9sQFRi(mode,url,text):
	if   mode==490: N6NCYivtV4I5rEXq = DP6FSBgNdX1rsvVR()
	elif mode==491: N6NCYivtV4I5rEXq = wg5aF3e8rcDh7SGpW6M1OPnkU(url,text)
	elif mode==492: N6NCYivtV4I5rEXq = oanus6TxUFNAhSZKpJdYlEC4mV(url)
	elif mode==493: N6NCYivtV4I5rEXq = GrsxUhb0PEXj2FQRAkD4q(url)
	elif mode==494: N6NCYivtV4I5rEXq = qt2zjyIbsS(url)
	elif mode==499: N6NCYivtV4I5rEXq = lPwaAjFTMG4n7iSLkXcEuK0Zm(text,url)
	else: N6NCYivtV4I5rEXq = False
	return N6NCYivtV4I5rEXq
def DP6FSBgNdX1rsvVR():
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',Str0BupDTFA,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'CIMACLUP-MENU-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	cbYKa2SXGwRCiQIW5NeosU9k = trdVA0JvFaD.findall('href="(.*?)"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	cbYKa2SXGwRCiQIW5NeosU9k = cbYKa2SXGwRCiQIW5NeosU9k[0].strip('/')
	cbYKa2SXGwRCiQIW5NeosU9k = RRNODILCtGzvgpx(cbYKa2SXGwRCiQIW5NeosU9k,'url')
	v2V8Nmrwf4 = trdVA0JvFaD.findall('"filter AjaxifyFilter"(.*?)</div>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if v2V8Nmrwf4:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = v2V8Nmrwf4[0]
		items = trdVA0JvFaD.findall('data-filter="(.*?)".*?>(.*?)</a>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,title in items:
			if title in P3UK1Rr4IdYe5: continue
			llxFwq0CUNgQtivJzkHeGV = cbYKa2SXGwRCiQIW5NeosU9k+'/wp-content/themes/old/filter/'+llxFwq0CUNgQtivJzkHeGV+'.php'
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,491)
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+'أفلام',cbYKa2SXGwRCiQIW5NeosU9k+'/category/افلام-movies-filme/foreign-hd-افلام-اجنبى-2',494,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'_REMEMBERRESULTS_')
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+'مسلسلات',cbYKa2SXGwRCiQIW5NeosU9k+'/category/مسلسلات/مسلسلات-اجنبى',494,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'_REMEMBERRESULTS_')
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('class="navigation-menu"(.*?)</ul>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
	items = trdVA0JvFaD.findall('href="(.*?)".*?>(.*?)</a>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	for llxFwq0CUNgQtivJzkHeGV,title in items:
		if llxFwq0CUNgQtivJzkHeGV=='/': continue
		if 'http' not in llxFwq0CUNgQtivJzkHeGV: llxFwq0CUNgQtivJzkHeGV = cbYKa2SXGwRCiQIW5NeosU9k+llxFwq0CUNgQtivJzkHeGV
		if title in P3UK1Rr4IdYe5: continue
		RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,491)
	return mMQ3FkNVa4IlxqY
def qt2zjyIbsS(url):
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'CIMACLUP-SUBMENU-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	cLV4wifngjAdbePKq2x7SDhXGYlO0 = trdVA0JvFaD.findall('"filter"(.*?)</div>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if cLV4wifngjAdbePKq2x7SDhXGYlO0:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = cLV4wifngjAdbePKq2x7SDhXGYlO0[0]
		items = trdVA0JvFaD.findall('href="(.*?)".*?>(.*?)</a>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,title in items:
			if title in P3UK1Rr4IdYe5: continue
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,491)
	return
def wg5aF3e8rcDh7SGpW6M1OPnkU(url,Zn0DwEg9b7zxavJ8yUqHO5dM1=hWGMqtBy4wuLaVcj):
	items = []
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'CIMACLUP-TITLES-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	cok5ZGXdQP7YhwtqyuaCnVevm6UB = hWGMqtBy4wuLaVcj
	if '.php' in url: cok5ZGXdQP7YhwtqyuaCnVevm6UB = mMQ3FkNVa4IlxqY
	elif '?s=' in url:
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('"blocks(.*?)"manifest"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
			cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
			items = trdVA0JvFaD.findall('href="(.*?)".*?src="(.*?)".*?alt="(.*?)"',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	else:
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('"Blocks(.*?)"manifest"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
			cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
	if not cok5ZGXdQP7YhwtqyuaCnVevm6UB: return
	REbVyXis1w4Ae = []
	nNBCdTs98RztMyODHpL63ZUKm4P = ['مشاهدة','فيلم','اغنية','أغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for llxFwq0CUNgQtivJzkHeGV,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,title in items:
		title = LNtIDdBA52P(title)
		IIsmGy4pd7 = trdVA0JvFaD.findall('(.*?) حلقة \d+',title,trdVA0JvFaD.DOTALL)
		if not IIsmGy4pd7: IIsmGy4pd7 = trdVA0JvFaD.findall('(.*?) الحلقة \d+',title,trdVA0JvFaD.DOTALL)
		if not IIsmGy4pd7 or any(BoSjXKxz41DcneO9UimClE in title for BoSjXKxz41DcneO9UimClE in nNBCdTs98RztMyODHpL63ZUKm4P):
			RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,492,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
		elif IIsmGy4pd7 and 'حلقة' in title:
			title = '_MOD_' + IIsmGy4pd7[0]
			if title not in REbVyXis1w4Ae:
				RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,493,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
				REbVyXis1w4Ae.append(title)
		else: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,493,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('"pagination"(.*?)</ul>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('<li><a href="(.*?)".*?>(.*?)</a>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,title in items:
			title = LNtIDdBA52P(title)
			title = title.replace('الصفحة ',hWGMqtBy4wuLaVcj)
			if title!=hWGMqtBy4wuLaVcj: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'صفحة '+title,llxFwq0CUNgQtivJzkHeGV,491)
	return
def GrsxUhb0PEXj2FQRAkD4q(url):
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'CIMACLUP-EPISODES-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	NPM3HKQ57xe = trdVA0JvFaD.findall('"ButtonsBarCo".*?href="(.*?)"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if NPM3HKQ57xe:
		NPM3HKQ57xe = NPM3HKQ57xe[0]
		sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',NPM3HKQ57xe,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'CIMACLUP-EPISODES-2nd')
		mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG = trdVA0JvFaD.findall('"img-responsive" src="(.*?)"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG: Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG = Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG[0]
	else: Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG = MMk8qKvcJe4fQHm3EG7diBD5.getInfoLabel('ListItem.Thumb')
	cLV4wifngjAdbePKq2x7SDhXGYlO0 = trdVA0JvFaD.findall('"filter"(.*?)</div>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	v2V8Nmrwf4 = trdVA0JvFaD.findall('"Blocks(.*?)class="pagination"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if cLV4wifngjAdbePKq2x7SDhXGYlO0 and '/series/' not in url:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = cLV4wifngjAdbePKq2x7SDhXGYlO0[0]
		items = trdVA0JvFaD.findall('href="(.*?)".*?>(.*?)</a>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,title in items:
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,493,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
	elif v2V8Nmrwf4:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = v2V8Nmrwf4[0]
		items = trdVA0JvFaD.findall('href="(.*?)".*?image\:url\((.*?)\).*?"boxtitle">(.*?)</div>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		if items:
			for llxFwq0CUNgQtivJzkHeGV,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,title in items:
				title = title.strip(Mpsm2VF1OBnCRvK3qf6)
				RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,492,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('"pagination"(.*?)</div>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
			cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
			items = trdVA0JvFaD.findall('href="(.*?)".*?>(.*?)</a>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
			for llxFwq0CUNgQtivJzkHeGV,title in items:
				title = LNtIDdBA52P(title)
				title = title.replace('الصفحة ',hWGMqtBy4wuLaVcj)
				if title!=hWGMqtBy4wuLaVcj: RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'صفحة '+title,llxFwq0CUNgQtivJzkHeGV,491)
	return
def oanus6TxUFNAhSZKpJdYlEC4mV(url):
	NPM3HKQ57xe = url.strip('/')+'/?view=1'
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',NPM3HKQ57xe,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'CIMACLUP-PLAY-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	Dvi8asSrQYX5wE3KMIxT91me = []
	cbYKa2SXGwRCiQIW5NeosU9k = RRNODILCtGzvgpx(url,'url')
	FGWLHNuyJcBdxKOi4 = trdVA0JvFaD.findall("data: 'q=(.*?)&",mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	FGWLHNuyJcBdxKOi4 = FGWLHNuyJcBdxKOi4[0]
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('"serversList"(.*?)</ul>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('data-server="(.*?)">(.*?)</li>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for PcGsV06tZUmY5pFvN4wCfEg1,title in items:
			title = title.strip(Mpsm2VF1OBnCRvK3qf6)
			llxFwq0CUNgQtivJzkHeGV = cbYKa2SXGwRCiQIW5NeosU9k+'/wp-content/themes/old/servers/server.php?q='+FGWLHNuyJcBdxKOi4+'&i='+PcGsV06tZUmY5pFvN4wCfEg1+'?named='+title+'__watch'
			Dvi8asSrQYX5wE3KMIxT91me.append(llxFwq0CUNgQtivJzkHeGV)
	llxFwq0CUNgQtivJzkHeGV = trdVA0JvFaD.findall('"embedServer".*?SRC="(.*?)"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if llxFwq0CUNgQtivJzkHeGV:
		title = 'مفضل'
		llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV[0]+'?named=__embed__'+title
		Dvi8asSrQYX5wE3KMIxT91me.append(llxFwq0CUNgQtivJzkHeGV)
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('"downloadsList"(.*?)</div>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('<td>(.*?)</td>.*?href="(.*?)"',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for title,llxFwq0CUNgQtivJzkHeGV in items:
			title = title.strip(Mpsm2VF1OBnCRvK3qf6)
			if 'anavidz' in llxFwq0CUNgQtivJzkHeGV: m4eVoJdSU51qs3y8Gg06fZNau7A = '__خاص'
			else: m4eVoJdSU51qs3y8Gg06fZNau7A = hWGMqtBy4wuLaVcj
			llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV+'?named='+title+'__download'+m4eVoJdSU51qs3y8Gg06fZNau7A
			Dvi8asSrQYX5wE3KMIxT91me.append(llxFwq0CUNgQtivJzkHeGV)
	import oosSOfvdEQ
	oosSOfvdEQ.zfdYjsGLg8M6i15qZWh(Dvi8asSrQYX5wE3KMIxT91me,xjPuFK3EsIZSiobQ5X,'video',url)
	return
def lPwaAjFTMG4n7iSLkXcEuK0Zm(search,cbYKa2SXGwRCiQIW5NeosU9k=hWGMqtBy4wuLaVcj):
	if not cbYKa2SXGwRCiQIW5NeosU9k: cbYKa2SXGwRCiQIW5NeosU9k = Str0BupDTFA
	search,vvKf4sXgZIMyEJPuC,showDialogs = IVTEJQOiMR2dYta9C(search)
	if not search:
		search = TrzfUidpv1LyAYqwexHJDuS()
		if not search: return
	search = search.replace(Mpsm2VF1OBnCRvK3qf6,'+')
	url = cbYKa2SXGwRCiQIW5NeosU9k+'/index.php?s='+search
	wg5aF3e8rcDh7SGpW6M1OPnkU(url)
	return
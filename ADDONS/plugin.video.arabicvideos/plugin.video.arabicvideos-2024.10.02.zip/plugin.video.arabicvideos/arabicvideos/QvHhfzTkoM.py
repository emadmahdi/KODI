# -*- coding: utf-8 -*-
from yoY3NdGViS import *
xjPuFK3EsIZSiobQ5X = 'CIMANOW'
n0qFKQWhiBYXoTrvejVHUA4 = '_CMN_'
Str0BupDTFA = u6rbxnyjTl7I[xjPuFK3EsIZSiobQ5X][0]
P3UK1Rr4IdYe5 = ['قائمتي']
def ehB18u9sQFRi(mode,url,text):
	if   mode==300: N6NCYivtV4I5rEXq = DP6FSBgNdX1rsvVR()
	elif mode==301: N6NCYivtV4I5rEXq = qt2zjyIbsS(url)
	elif mode==302: N6NCYivtV4I5rEXq = wg5aF3e8rcDh7SGpW6M1OPnkU(url)
	elif mode==303: N6NCYivtV4I5rEXq = ppcbK7vZlfXRTt0BEei9zho(url)
	elif mode==304: N6NCYivtV4I5rEXq = GrsxUhb0PEXj2FQRAkD4q(url)
	elif mode==305: N6NCYivtV4I5rEXq = oanus6TxUFNAhSZKpJdYlEC4mV(url)
	elif mode==306: N6NCYivtV4I5rEXq = vRA1d9tI5q8wnXlWcLbJsETpC0()
	elif mode==309: N6NCYivtV4I5rEXq = lPwaAjFTMG4n7iSLkXcEuK0Zm(text)
	else: N6NCYivtV4I5rEXq = False
	return N6NCYivtV4I5rEXq
def DP6FSBgNdX1rsvVR():
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',n0qFKQWhiBYXoTrvejVHUA4+'لماذا الموقع بطيء',hWGMqtBy4wuLaVcj,306)
	RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'بحث في الموقع',hWGMqtBy4wuLaVcj,309,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'_REMEMBERRESULTS_')
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(DpQifS0oKBI1hYcO,'GET',Str0BupDTFA+'/home',hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'CIMANOW-MENU-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('<header>(.*?)</header>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
	items = trdVA0JvFaD.findall('<li><a href="(.*?)">(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	for llxFwq0CUNgQtivJzkHeGV,title in items:
		title = title.strip(Mpsm2VF1OBnCRvK3qf6)
		if not any(BoSjXKxz41DcneO9UimClE in title for BoSjXKxz41DcneO9UimClE in P3UK1Rr4IdYe5):
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',xjPuFK3EsIZSiobQ5X+'_SCRIPT_'+n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,301)
	RLDCGt8kq3OVmnzgx1rbi2f7F('link',hXB0vKVQ5PRI91SDTprMdfuHEm4+' ===== ===== ===== '+YYSh2J6BIrsm8,hWGMqtBy4wuLaVcj,9999)
	qt2zjyIbsS(Str0BupDTFA+'/home',mMQ3FkNVa4IlxqY)
	return mMQ3FkNVa4IlxqY
def vRA1d9tI5q8wnXlWcLbJsETpC0():
	BZj61bFtfWLzXp(hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'رسالة من المبرمج','موقع سيما ناو بطيء من المصدر .. بسبب قيام أصحاب الموقع بتشفير محتويات جميع صفحات الموقع .. والوقت الضائع يذهب في معالجة تشفير الصفحات المشفرة قبل عرض محتوياتها في قوائم هذا البرنامج')
	return
def qt2zjyIbsS(url,mMQ3FkNVa4IlxqY=hWGMqtBy4wuLaVcj):
	if not mMQ3FkNVa4IlxqY:
		sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(DpQifS0oKBI1hYcO,'GET',url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'CIMANOW-SUBMENU-1st')
		mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	XK2iWMx6yfU9E = 0
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('(<section>.*?</section>)',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		for cok5ZGXdQP7YhwtqyuaCnVevm6UB in DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
			XK2iWMx6yfU9E += 1
			items = trdVA0JvFaD.findall('<section>.<span>(.*?)<(.*?)href="(.*?)"',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
			for title,pJuxVqEs9AliykM3XrGtzdvHFWL7co,llxFwq0CUNgQtivJzkHeGV in items:
				title = title.strip(Mpsm2VF1OBnCRvK3qf6)
				if title==hWGMqtBy4wuLaVcj: title = 'بووووو'
				if 'em><a' not in pJuxVqEs9AliykM3XrGtzdvHFWL7co:
					if cok5ZGXdQP7YhwtqyuaCnVevm6UB.count('/category/')>0:
						pgj1NhfSenwsqXPy2BxZRtbcMCuJOT = trdVA0JvFaD.findall('href="(.*?)"',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
						for llxFwq0CUNgQtivJzkHeGV in pgj1NhfSenwsqXPy2BxZRtbcMCuJOT:
							title = llxFwq0CUNgQtivJzkHeGV.split('/')[-2]
							RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,301)
						continue
					else: llxFwq0CUNgQtivJzkHeGV = url+'?sequence='+str(XK2iWMx6yfU9E)
				if not any(BoSjXKxz41DcneO9UimClE in title for BoSjXKxz41DcneO9UimClE in P3UK1Rr4IdYe5):
					RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,302)
	else: wg5aF3e8rcDh7SGpW6M1OPnkU(url,mMQ3FkNVa4IlxqY)
	return
def wg5aF3e8rcDh7SGpW6M1OPnkU(url,mMQ3FkNVa4IlxqY=hWGMqtBy4wuLaVcj):
	if mMQ3FkNVa4IlxqY==hWGMqtBy4wuLaVcj:
		sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'CIMANOW-TITLES-1st')
		mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	if '?sequence=' in url:
		url,XK2iWMx6yfU9E = url.split('?sequence=')
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('(<section>.*?</section>)',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[int(XK2iWMx6yfU9E)-1]
	else:
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('"posts"(.*?)</body>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
	items = trdVA0JvFaD.findall('<a.*?href="(.*?)"(.*?)data-src="(.*?)"',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
	REbVyXis1w4Ae = []
	for llxFwq0CUNgQtivJzkHeGV,data,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG in items:
		title = trdVA0JvFaD.findall('<em>(.*?)</em>(.*?)</li>.*?</em>(.*?)<em>',data,trdVA0JvFaD.DOTALL)
		if title: title = title[0][2].replace(NXMOzZjYsmS9pf,hWGMqtBy4wuLaVcj).strip(Mpsm2VF1OBnCRvK3qf6)
		if not title or title==hWGMqtBy4wuLaVcj:
			title = trdVA0JvFaD.findall('title">.*?</em>(.*?)<',data,trdVA0JvFaD.DOTALL)
			if title: title = title[0].replace(NXMOzZjYsmS9pf,hWGMqtBy4wuLaVcj).strip(Mpsm2VF1OBnCRvK3qf6)
			if not title or title==hWGMqtBy4wuLaVcj:
				title = trdVA0JvFaD.findall('title">(.*?)<',data,trdVA0JvFaD.DOTALL)
				title = title[0].replace(NXMOzZjYsmS9pf,hWGMqtBy4wuLaVcj).strip(Mpsm2VF1OBnCRvK3qf6)
		title = LNtIDdBA52P(title)
		title = title.replace(FqcVAkh7WjIXHdDKf8nvuyRo,Mpsm2VF1OBnCRvK3qf6)
		if title not in REbVyXis1w4Ae:
			REbVyXis1w4Ae.append(title)
			TfCqlZthRYgzkbE0GO = llxFwq0CUNgQtivJzkHeGV+data+Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG
			if '/selary/' in TfCqlZthRYgzkbE0GO or 'مسلسل' in TfCqlZthRYgzkbE0GO or '"episode"' in TfCqlZthRYgzkbE0GO:
				if 'برامج' in data: title = 'برنامج '+title
				elif 'مسلسل' in data or 'موسم' in data: title = 'مسلسل '+title
				RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,303,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
			else: RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,305,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('"pagination"(.*?)</div>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('<li><a href="(.*?)">(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,title in items:
			RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+'صفحة '+title,llxFwq0CUNgQtivJzkHeGV,302)
	return
def ppcbK7vZlfXRTt0BEei9zho(url):
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'CIMANOW-SEASONS-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	name = trdVA0JvFaD.findall('<title>(.*?)</title>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	name = name[0].replace('| سيما ناو',hWGMqtBy4wuLaVcj).replace('Cima Now',hWGMqtBy4wuLaVcj).strip(Mpsm2VF1OBnCRvK3qf6).replace(FqcVAkh7WjIXHdDKf8nvuyRo,Mpsm2VF1OBnCRvK3qf6)
	name = name.split('الحلقة')[0].strip(Mpsm2VF1OBnCRvK3qf6)
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('<section(.*?)</section>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('href="(.*?)">(.*?)<',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		if len(items)>1:
			for llxFwq0CUNgQtivJzkHeGV,title in items:
				title = name+' - '+title.replace(NXMOzZjYsmS9pf,hWGMqtBy4wuLaVcj).strip(Mpsm2VF1OBnCRvK3qf6)
				RLDCGt8kq3OVmnzgx1rbi2f7F('folder',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,304)
		else: GrsxUhb0PEXj2FQRAkD4q(url)
	return
def GrsxUhb0PEXj2FQRAkD4q(url):
	if '/selary/' not in url: url = url.strip('/')+'/watching'
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(KqO5BWGQR9JVL,'GET',url,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'CIMANOW-EPISODES-1st')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	if '/selary/' not in url:
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('"episodes"(.*?)</ul>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('href="(.*?)">(.*?)</a>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,title in items:
			title = title.replace(NXMOzZjYsmS9pf,hWGMqtBy4wuLaVcj).strip(Mpsm2VF1OBnCRvK3qf6)
			title = 'الحلقة '+title
			RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,305)
	else:
		DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('"details"(.*?)"related"',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('href="(.*?)".*?src=.*?src="(.*?)".*?alt="(.*?)"',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG,title in items:
			title = title.replace(NXMOzZjYsmS9pf,hWGMqtBy4wuLaVcj).strip(Mpsm2VF1OBnCRvK3qf6)
			RLDCGt8kq3OVmnzgx1rbi2f7F('video',n0qFKQWhiBYXoTrvejVHUA4+title,llxFwq0CUNgQtivJzkHeGV,305,Vl4CvI0Kur3e1sgnoEW9HLdJFU6pwG)
	return
def oanus6TxUFNAhSZKpJdYlEC4mV(url):
	NPM3HKQ57xe = url+'watching/'
	sDQvwGASB0Vf67mik = CCi6dsXkhlLDwz3c7n28aFEpeNg0ut(nHBb7jXk0Daom,'GET',NPM3HKQ57xe,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,hWGMqtBy4wuLaVcj,'CIMANOW-PLAY-5th')
	mMQ3FkNVa4IlxqY = sDQvwGASB0Vf67mik.content
	Dvi8asSrQYX5wE3KMIxT91me = []
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('"download"(.*?)</ul>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		items = trdVA0JvFaD.findall('href="(.*?)".*?</i>(.*?)</a>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV,title in items:
			title = title.replace(NXMOzZjYsmS9pf,hWGMqtBy4wuLaVcj).strip(Mpsm2VF1OBnCRvK3qf6)
			QS8ZdxkHD5bjU9qsn4zMYaPrg3h7 = trdVA0JvFaD.findall('\d\d\d+',title,trdVA0JvFaD.DOTALL)
			if QS8ZdxkHD5bjU9qsn4zMYaPrg3h7:
				QS8ZdxkHD5bjU9qsn4zMYaPrg3h7 = '____'+QS8ZdxkHD5bjU9qsn4zMYaPrg3h7[0]
				title = RRNODILCtGzvgpx(llxFwq0CUNgQtivJzkHeGV,'name')
			else: QS8ZdxkHD5bjU9qsn4zMYaPrg3h7 = hWGMqtBy4wuLaVcj
			MDSF21x9HK3AZyGUhcb = llxFwq0CUNgQtivJzkHeGV+'?named='+title+'__download'+QS8ZdxkHD5bjU9qsn4zMYaPrg3h7
			Dvi8asSrQYX5wE3KMIxT91me.append(MDSF21x9HK3AZyGUhcb)
	DJvksH7ZAFUqW9OyQnbGjPCtwR1o = trdVA0JvFaD.findall('"watch"(.*?)</ul>',mMQ3FkNVa4IlxqY,trdVA0JvFaD.DOTALL)
	if DJvksH7ZAFUqW9OyQnbGjPCtwR1o:
		cok5ZGXdQP7YhwtqyuaCnVevm6UB = DJvksH7ZAFUqW9OyQnbGjPCtwR1o[0]
		m4IznKilUOByHweG68VJ = trdVA0JvFaD.findall('"embed".*?src="(.*?)"',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
		for llxFwq0CUNgQtivJzkHeGV in m4IznKilUOByHweG68VJ:
			if 'http' not in llxFwq0CUNgQtivJzkHeGV: llxFwq0CUNgQtivJzkHeGV = 'http:'+llxFwq0CUNgQtivJzkHeGV
			title = RRNODILCtGzvgpx(llxFwq0CUNgQtivJzkHeGV,'name')
			llxFwq0CUNgQtivJzkHeGV = llxFwq0CUNgQtivJzkHeGV+'?named='+title+'__embed'
			Dvi8asSrQYX5wE3KMIxT91me.append(llxFwq0CUNgQtivJzkHeGV)
		m4IznKilUOByHweG68VJ = [Str0BupDTFA+'/wp-content/themes/Cima%20Now%20New/core.php']
		if m4IznKilUOByHweG68VJ:
			items = trdVA0JvFaD.findall('data-index="(.*?)".*?data-id="(.*?)".*?>(.*?)</li>',cok5ZGXdQP7YhwtqyuaCnVevm6UB,trdVA0JvFaD.DOTALL)
			for C9VNOL3UmyXPYbGrJ8,id,title in items:
				title = title.replace(NXMOzZjYsmS9pf,hWGMqtBy4wuLaVcj).strip(Mpsm2VF1OBnCRvK3qf6)
				llxFwq0CUNgQtivJzkHeGV = m4IznKilUOByHweG68VJ[0]+'?action=switch&index='+C9VNOL3UmyXPYbGrJ8+'&id='+id+'?named='+title+'__watch'
				Dvi8asSrQYX5wE3KMIxT91me.append(llxFwq0CUNgQtivJzkHeGV)
	import oosSOfvdEQ
	oosSOfvdEQ.zfdYjsGLg8M6i15qZWh(Dvi8asSrQYX5wE3KMIxT91me,xjPuFK3EsIZSiobQ5X,'video',url)
	return
def lPwaAjFTMG4n7iSLkXcEuK0Zm(search):
	search,vvKf4sXgZIMyEJPuC,showDialogs = IVTEJQOiMR2dYta9C(search)
	if search==hWGMqtBy4wuLaVcj: search = TrzfUidpv1LyAYqwexHJDuS()
	if search==hWGMqtBy4wuLaVcj: return
	search = search.replace(Mpsm2VF1OBnCRvK3qf6,'+')
	url = Str0BupDTFA + '/?s='+search
	wg5aF3e8rcDh7SGpW6M1OPnkU(url)
	return
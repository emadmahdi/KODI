# -*- coding: utf-8 -*-

import xbmc,xbmcgui,sys,os,requests,re,xbmcvfs,base64,logging,time

def YESNO_DIALOG(text):
	header = 'رسالة من المبرمج'
	if PY2: yes = xbmcgui.Dialog().yesno(header,text,'','','كلا','نعم')
	else: yes = xbmcgui.Dialog().yesno(header,text,'كلا','نعم')
	return yes

def SEND_LOGFILE(logfilepath):
	yes = YESNO_DIALOG('قبل إرسال سجل الأخطاء يجب أن تشغل برنامج عماد وتنتظر حتى تظهر لك المشاكل والأخطاء .. عندها سيقوم كودي بتسجيل هذه المشاكل والأخطاء في سجل الأخطاء .. وبعدها قم بإرسال سجل الأخطاء للمبرمج .. هل تريد الآن إرسال سجل الأخطاء إلى المبرمج ؟!')
	if yes==1 and os.path.exists(logfilepath):
		addon_version = xbmc.getInfoLabel('System.AddonVersion('+addon_id+')')
		file = open(logfilepath,'rb')
		size = os.path.getsize(logfilepath)
		if size>301000: file.seek(-301000,os.SEEK_END)
		data = file.read()
		file.close()
		user = re.findall("'user_id': '(.*?)'",data,re.DOTALL)
		if not user: user = re.findall("'user': '(.*?)'",data,re.DOTALL)
		user = user[0] if user else '0000'
		user = user.split('\n',1)[0]
		subject = 'AV: '+user+'-Recovery'
		message = 'Email Sender: '+user+' :'+'\n'+'Addon Version: '+addon_version+' :'
		logfiledata = base64.b64encode(data)
		payload = {'subject':subject,'message':message,'logfile':logfiledata}
		url = 'https://kodiemad.vercel.app/sendemail'
		response = requests.request('POST',url,data=payload)
		if response.status_code==200: xbmcgui.Dialog().ok('رسالة من المبرمج','جيد .. نجحت عملية إرسال سجل الأخطاء')
		else: xbmcgui.Dialog().ok('رسالة من المبرمج','للأسف .. فشلت عملية إرسال سجل الأخطاء')
	return

def DELETE_SETTINGS_FILE():
	yes = YESNO_DIALOG('ملف إعدادات البرنامج يحتوي على معلومات تخص تحديث البرنامج وتنظيم عمل البرنامج .. عند مسح هذا الملف سيقوم البرنامج بخلق ملف جديد فارغ .. هل تريد الآن مسح ملف إعدادات البرنامج ؟!')
	if yes==1:
		succeeded = True
		settingsfolder = os.path.join(userfolder,'userdata','addon_data',addon_id)
		settingsfile = os.path.join(settingsfolder,'settings.xml')
		#try: open(settingsfile,'w').write('<settings version="2"></settings>')
		if os.path.exists(settingsfile):
			try: os.remove(settingsfile)
			except Exception as err: succeeded = False
		if succeeded: xbmcgui.Dialog().ok('رسالة من المبرمج','جيد .. نجحت عملية مسح الملف')
		else: xbmcgui.Dialog().ok('رسالة من المبرمج','للأسف .. فشلت عملية مسح الملف')
	return

def DELETE_CACHE_FOLDER():
	yes = YESNO_DIALOG('مجلد كاش البرنامج يحتوي على ملفات تخص تنظيم عمل البرنامج مثل ملفات المفضلة وملفات IPTV و M3U وصور القوائم .. عند مسح هذا المجلد سيقوم البرنامج بخلق مجلد جديد فارغ .. هل تريد الآن مسح مجلد كاش البرنامج ؟!')
	if yes==1:
		if PY3: cachefolder = xbmcvfs.translatePath('special://temp')
		else: cachefolder = xbmc.translatePath('special://temp')
		addoncachefolder = os.path.join(cachefolder,addon_id)
		succeeded = True
		if os.path.exists(addoncachefolder):
			#os.chmod(addoncachefolder,0o777)
			for rroot,ddirs,files in os.walk(addoncachefolder,topdown=False):
				for ffile in files:
					ffilepath = os.path.join(rroot,ffile)
					#os.chmod(ffilepath,0o777)
					try: os.remove(ffilepath)
					except Exception as err: succeeded = False
				for ddir in ddirs:
					folder = os.path.join(rroot,ddir)
					try: os.rmdir(folder)
					except: pass
			try: os.rmdir(rroot)
			except: pass
		if succeeded: xbmcgui.Dialog().ok('رسالة من المبرمج','جيد .. نجحت عملية مسح مجلد كاش البرنامج')
		else: xbmcgui.Dialog().ok('رسالة من المبرمج','للأسف .. فشلت عملية مسح مجلد كاش البرنامج')
	return

def INSTALL_OLD_VERSION():
	url = 'https://kodiemad.surge.sh/kodi/emad_arabicvideos/old/index.html'
	response = requests.request('GET',url)
	html = response.content
	html = html.decode('utf8')
	files = re.findall('href="plugin.video.(.*?).zip"',html,re.DOTALL)
	files = sorted(files,reverse=True)
	selection = xbmcgui.Dialog().select('اختر الإصدار الذي تريد تثبيته',files)
	if selection==-1: return
	filename = files[selection]
	if PY2: filename = filename.encode('utf8')
	zipfileurl = url.rsplit('/',1)[0]+'/'+'plugin.video.'+filename+'.zip'
	succeeded = False
	response = requests.request('GET',zipfileurl)
	if response.status_code==200:
		zipfile_contents = response.content
		import zipfile,io
		file_like_object = io.BytesIO(zipfile_contents)
		useraddonsfolder = os.path.join(userfolder,'addons')
		zf = zipfile.ZipFile(file_like_object)
		zf.extractall(useraddonsfolder)
		time.sleep(1)
		xbmc.executebuiltin('UpdateLocalAddons')
		time.sleep(1)
		results = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"'+addon_id+'","enabled":true}}')
		if 'OK' in results: succeeded = True
	if succeeded: xbmcgui.Dialog().ok('رسالة من المبرمج','جيد .. نجحت عملية تثبيت الإصدار القديم \n\n '+filename)
	else: xbmcgui.Dialog().ok('رسالة من المبرمج','للأسف .. فشلت عملية تثبيت الإصدار القديم \n\n '+filename)
	MODIFY_AUTOUPDATE()
	#xbmc.log('AAAAAAAAAA:    '+zipfileurl,level=xbmc.LOGERROR)
	return

def MODIFY_AUTOUPDATE(disable=None):
	if disable==None:
		yes = YESNO_DIALOG('حتى يبقى الإصدار القديم في جهازك ولا يتم تحديثه أوتوماتيكيا .. يجب أن تقوم بإيقاف التحديث الأوتوماتيكي .. هل تريد إيقاف التحديث الأوتوماتيكي للبرنامج ؟!')
		if yes==-1: return
		disable = True if yes==1 else False
	if PY3: addons_dbfile = os.path.join(userfolder,'userdata','Database','Addons33.db')
	else: addons_dbfile = os.path.join(userfolder,'userdata','Database','Addons27.db')
	import sqlite3
	succeeded = False
	emad_repo = 'repository.emad'
	table_name = 'blacklist' if PY2 else 'update_rules'
	try:
		conn = sqlite3.connect(addons_dbfile)
		conn.text_factory = str
		cc = conn.cursor()
		cc.execute('SELECT origin FROM installed WHERE addonID = "'+addon_id+'" ;')
		rows = cc.fetchall()
		if rows and emad_repo not in str(rows): cc.execute('UPDATE installed SET origin = "'+emad_repo+'" WHERE addonID = "'+addon_id+'" ;')
		cc.execute('SELECT * FROM '+table_name+' WHERE addonID = "'+addon_id+'" ;')
		rows = cc.fetchall()
		enabled = False if rows else True
		if not enabled and not disable: cc.execute('DELETE FROM '+table_name+' WHERE addonID = "'+addon_id+'" ;')
		elif enabled and disable:
			if PY2: cc.execute('INSERT INTO '+table_name+' (addonID) VALUES ("'+addon_id+'") ;')
			else: cc.execute('INSERT INTO '+table_name+' (addonID,updateRule) VALUES ("'+addon_id+'",1) ;')
		conn.commit()
		conn.close()
		succeeded = True
	except: pass
	if succeeded:
		time.sleep(1)
		xbmc.executebuiltin('UpdateLocalAddons')
		time.sleep(1)
		xbmcgui.Dialog().ok('رسالة من المبرمج','جيد .. نجحت العملية')
	else: xbmcgui.Dialog().ok('رسالة من المبرمج','للأسف .. فشلت العملية')
	return

job = sys.argv[1]
addon_id = 'plugin.video.arabicvideos'
kodi_release = xbmc.getInfoLabel("System.BuildVersion")
kodi_version = re.findall('(\d\d\.\d)',kodi_release,re.DOTALL)
kodi_version = float(kodi_version[0])
PY2 = kodi_version<19
PY3 = kodi_version>18.99

if PY3:
	logfolder = xbmcvfs.translatePath('special://logpath')
	userfolder = xbmcvfs.translatePath('special://home')
else:
	logfolder = xbmc.translatePath('special://logpath')
	userfolder = xbmc.translatePath('special://home')

logfile = os.path.join(logfolder,'kodi.log')
oldlogfile = os.path.join(logfolder,'kodi.old.log')

if   job=='send_logfile'			: SEND_LOGFILE(logfile)
elif job=='send_old_logfile'		: SEND_LOGFILE(oldlogfile)
elif job=='delete_settings'		: DELETE_SETTINGS_FILE()
elif job=='delete_cache'			: DELETE_CACHE_FOLDER()
elif job=='install_old_version'	: INSTALL_OLD_VERSION()
elif job=='modify_autoupdate'	: MODIFY_AUTOUPDATE()



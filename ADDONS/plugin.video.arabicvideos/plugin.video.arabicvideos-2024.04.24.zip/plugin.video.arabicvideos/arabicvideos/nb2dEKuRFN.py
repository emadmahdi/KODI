# -*- coding: utf-8 -*-
from G6AHskJeqN import *
baNWS6nfqTC5iX4Kl = 'CIMANOW'
teUPLFC3B8bArakwHVGsdhoIWDM49f = '_CMN_'
EZxQp1WOldMTvFU = AK5RqLhji4W1wt9VdrCD3PGeQM[baNWS6nfqTC5iX4Kl][0]
eh2tDvRFWpLQI = ['قائمتي']
def VbgEajY4Bt2COpGDcPqI(mode,url,text):
	if   mode==300: ft3e2JBKQVXWlFPjaMhkEqGxvDg = eN02L7Tf5bQ()
	elif mode==301: ft3e2JBKQVXWlFPjaMhkEqGxvDg = M25iOAH9NfalvyPEUuToG8qn(url)
	elif mode==302: ft3e2JBKQVXWlFPjaMhkEqGxvDg = sscM839DP1jWZ4zl6uIx0Kyn(url)
	elif mode==303: ft3e2JBKQVXWlFPjaMhkEqGxvDg = WWF1Rc6KZx(url)
	elif mode==304: ft3e2JBKQVXWlFPjaMhkEqGxvDg = o4oY13v5dWMcbilEDjKCnXNzHZ0(url)
	elif mode==305: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HDxCnPKFhITpZmOsA4a0UL6(url)
	elif mode==306: ft3e2JBKQVXWlFPjaMhkEqGxvDg = hDWwUCIZYtLcszqARkx3KmMiXeV5u()
	elif mode==309: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HjZcUIVAXFCqy9TfBWKtgY2(text)
	else: ft3e2JBKQVXWlFPjaMhkEqGxvDg = False
	return ft3e2JBKQVXWlFPjaMhkEqGxvDg
def eN02L7Tf5bQ():
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link',teUPLFC3B8bArakwHVGsdhoIWDM49f+'لماذا الموقع بطيء','',306)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'بحث في الموقع','',309,'','','_REMEMBERRESULTS_')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(IIiPCruL6dT8s1lqj47SzpVHnYNm,'GET',EZxQp1WOldMTvFU+'/home','','','','','CIMANOW-MENU-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('<header>(.*?)</header>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	vsptNMP2ZQC = XBuP6Op7y4K[0]
	items = My7Dwqvs6bfGNSIgX.findall('<li><a href="(.*?)">(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	for BoEFz2WhUyvTgDeiZ,title in items:
		title = title.strip(' ')
		if not any(WoFrX46wzbCNp18 in title for WoFrX46wzbCNp18 in eh2tDvRFWpLQI):
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,301)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	M25iOAH9NfalvyPEUuToG8qn(EZxQp1WOldMTvFU+'/home',MK6ZT2zjC1SbmveNFqor)
	return MK6ZT2zjC1SbmveNFqor
def hDWwUCIZYtLcszqARkx3KmMiXeV5u():
	ZIOHgA3z0TBR('','','رسالة من المبرمج','موقع سيما ناو بطيء من المصدر .. بسبب قيام أصحاب الموقع بتشفير محتويات جميع صفحات الموقع .. والوقت الضائع يذهب في معالجة تشفير الصفحات المشفرة قبل عرض محتوياتها في قوائم هذا البرنامج')
	return
def M25iOAH9NfalvyPEUuToG8qn(url,MK6ZT2zjC1SbmveNFqor=''):
	if not MK6ZT2zjC1SbmveNFqor:
		xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(IIiPCruL6dT8s1lqj47SzpVHnYNm,'GET',url,'','','','','CIMANOW-SUBMENU-1st')
		MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	DQlGE75goqn9fkJt0P8ihR = 0
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('(<section>.*?</section>)',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		for vsptNMP2ZQC in XBuP6Op7y4K:
			DQlGE75goqn9fkJt0P8ihR += 1
			items = My7Dwqvs6bfGNSIgX.findall('<section>.<span>(.*?)<(.*?)href="(.*?)"',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
			for title,DOKB6aLcxwndEtHiNqoT5lGze1X2,BoEFz2WhUyvTgDeiZ in items:
				title = title.strip(' ')
				if title=='': title = 'بووووو'
				if 'em><a' not in DOKB6aLcxwndEtHiNqoT5lGze1X2:
					if vsptNMP2ZQC.count('/category/')>0:
						kkAK8c2b6l = My7Dwqvs6bfGNSIgX.findall('href="(.*?)"',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
						for BoEFz2WhUyvTgDeiZ in kkAK8c2b6l:
							title = BoEFz2WhUyvTgDeiZ.split('/')[-2]
							VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,301)
						continue
					else: BoEFz2WhUyvTgDeiZ = url+'?sequence='+str(DQlGE75goqn9fkJt0P8ihR)
				if not any(WoFrX46wzbCNp18 in title for WoFrX46wzbCNp18 in eh2tDvRFWpLQI):
					VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,302)
	else: sscM839DP1jWZ4zl6uIx0Kyn(url,MK6ZT2zjC1SbmveNFqor)
	return
def sscM839DP1jWZ4zl6uIx0Kyn(url,MK6ZT2zjC1SbmveNFqor=''):
	if MK6ZT2zjC1SbmveNFqor=='':
		xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'','','','','CIMANOW-TITLES-1st')
		MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	if '?sequence=' in url:
		url,DQlGE75goqn9fkJt0P8ihR = url.split('?sequence=')
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('(<section>.*?</section>)',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		vsptNMP2ZQC = XBuP6Op7y4K[int(DQlGE75goqn9fkJt0P8ihR)-1]
	else:
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"posts"(.*?)</body>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		vsptNMP2ZQC = XBuP6Op7y4K[0]
	items = My7Dwqvs6bfGNSIgX.findall('<a.*?href="(.*?)"(.*?)data-src="(.*?)"',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	y7y3d5Fbhv42ONmtwLZ0SerYoQq = []
	for BoEFz2WhUyvTgDeiZ,data,IcWzVO137wFvemn2QTq8yKs9 in items:
		title = My7Dwqvs6bfGNSIgX.findall('<em>(.*?)</em>(.*?)</li>.*?</em>(.*?)<em>',data,My7Dwqvs6bfGNSIgX.DOTALL)
		if title: title = title[0][2].replace('\n','').strip(' ')
		if not title or title=='':
			title = My7Dwqvs6bfGNSIgX.findall('title">.*?</em>(.*?)<',data,My7Dwqvs6bfGNSIgX.DOTALL)
			if title: title = title[0].replace('\n','').strip(' ')
			if not title or title=='':
				title = My7Dwqvs6bfGNSIgX.findall('title">(.*?)<',data,My7Dwqvs6bfGNSIgX.DOTALL)
				title = title[0].replace('\n','').strip(' ')
		title = PIfAumbGicwg5ye(title)
		title = title.replace('  ',' ')
		if title not in y7y3d5Fbhv42ONmtwLZ0SerYoQq:
			y7y3d5Fbhv42ONmtwLZ0SerYoQq.append(title)
			iiBEzXVNFDhfj36 = BoEFz2WhUyvTgDeiZ+data+IcWzVO137wFvemn2QTq8yKs9
			if '/selary/' in iiBEzXVNFDhfj36 or 'مسلسل' in iiBEzXVNFDhfj36 or '"episode"' in iiBEzXVNFDhfj36:
				if 'برامج' in data: title = 'برنامج '+title
				elif 'مسلسل' in data or 'موسم' in data: title = 'مسلسل '+title
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,303,IcWzVO137wFvemn2QTq8yKs9)
			else: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,305,IcWzVO137wFvemn2QTq8yKs9)
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"pagination"(.*?)</div>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('<li><a href="(.*?)">(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title in items:
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'صفحة '+title,BoEFz2WhUyvTgDeiZ,302)
	return
def WWF1Rc6KZx(url):
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'','','','','CIMANOW-SEASONS-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	name = My7Dwqvs6bfGNSIgX.findall('<title>(.*?)</title>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	name = name[0].replace('| سيما ناو','').replace('Cima Now','').strip(' ').replace('  ',' ')
	name = name.split('الحلقة')[0].strip(' ')
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('<section(.*?)</section>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)">(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		if len(items)>1:
			for BoEFz2WhUyvTgDeiZ,title in items:
				title = name+' - '+title.replace('\n','').strip(' ')
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,304)
		else: o4oY13v5dWMcbilEDjKCnXNzHZ0(url)
	return
def o4oY13v5dWMcbilEDjKCnXNzHZ0(url):
	if '/selary/' not in url: url = url.strip('/')+'/watching'
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'','','','','CIMANOW-EPISODES-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	if '/selary/' not in url:
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"episodes"(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)">(.*?)</a>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title in items:
			title = title.replace('\n','').strip(' ')
			title = 'الحلقة '+title
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,305)
	else:
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"details"(.*?)"related"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?src=.*?src="(.*?)".*?alt="(.*?)"',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,IcWzVO137wFvemn2QTq8yKs9,title in items:
			title = title.replace('\n','').strip(' ')
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,305,IcWzVO137wFvemn2QTq8yKs9)
	return
def HDxCnPKFhITpZmOsA4a0UL6(url):
	bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = url+'watching/'
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(f9Oum6c0FotxYn,'GET',bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,'','','','','CIMANOW-PLAY-5th')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	QQ2cE1FjUyxPonbDhaTkV6B3i = []
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"download"(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?</i>(.*?)</a>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title in items:
			title = title.replace('\n','').strip(' ')
			LLnUyuiC2wRM0 = My7Dwqvs6bfGNSIgX.findall('\d\d\d+',title,My7Dwqvs6bfGNSIgX.DOTALL)
			if LLnUyuiC2wRM0:
				LLnUyuiC2wRM0 = '____'+LLnUyuiC2wRM0[0]
				title = ooq2D9xF8ZLpPBs(BoEFz2WhUyvTgDeiZ,'name')
			else: LLnUyuiC2wRM0 = ''
			bOBQpgMudItXo = BoEFz2WhUyvTgDeiZ+'?named='+title+'__download'+LLnUyuiC2wRM0
			QQ2cE1FjUyxPonbDhaTkV6B3i.append(bOBQpgMudItXo)
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"watch"(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		NVHrZsqUp2 = My7Dwqvs6bfGNSIgX.findall('"embed".*?src="(.*?)"',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ in NVHrZsqUp2:
			if 'http' not in BoEFz2WhUyvTgDeiZ: BoEFz2WhUyvTgDeiZ = 'http:'+BoEFz2WhUyvTgDeiZ
			title = ooq2D9xF8ZLpPBs(BoEFz2WhUyvTgDeiZ,'name')
			BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ+'?named='+title+'__embed'
			QQ2cE1FjUyxPonbDhaTkV6B3i.append(BoEFz2WhUyvTgDeiZ)
		NVHrZsqUp2 = [EZxQp1WOldMTvFU+'/wp-content/themes/Cima%20Now%20New/core.php']
		if NVHrZsqUp2:
			items = My7Dwqvs6bfGNSIgX.findall('data-index="(.*?)".*?data-id="(.*?)".*?>(.*?)</li>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
			for gMous1DWl97JdE5h6n0CFjeLZkq,id,title in items:
				title = title.replace('\n','').strip(' ')
				BoEFz2WhUyvTgDeiZ = NVHrZsqUp2[0]+'?action=switch&index='+gMous1DWl97JdE5h6n0CFjeLZkq+'&id='+id+'?named='+title+'__watch'
				QQ2cE1FjUyxPonbDhaTkV6B3i.append(BoEFz2WhUyvTgDeiZ)
	import t1kDWXQVpC
	t1kDWXQVpC.rqVt2xDi7jzJHBcPMRs6h0L(QQ2cE1FjUyxPonbDhaTkV6B3i,baNWS6nfqTC5iX4Kl,'video',url)
	return
def HjZcUIVAXFCqy9TfBWKtgY2(search):
	search,LQf3AeozSrai,showDialogs = X54MLovbG8nAEkB9J(search)
	if search=='': search = ViKAIsLurq83RSENayxWb()
	if search=='': return
	search = search.replace(' ','+')
	url = EZxQp1WOldMTvFU + '/?s='+search
	sscM839DP1jWZ4zl6uIx0Kyn(url)
	return
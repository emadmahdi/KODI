# -*- coding: utf-8 -*-
from G6AHskJeqN import *
baNWS6nfqTC5iX4Kl = 'MOVIZLAND'
headers = { 'User-Agent' : '' }
teUPLFC3B8bArakwHVGsdhoIWDM49f = '_MVZ_'
EZxQp1WOldMTvFU = AK5RqLhji4W1wt9VdrCD3PGeQM[baNWS6nfqTC5iX4Kl][0]
oHxnAT1DzYQv = AK5RqLhji4W1wt9VdrCD3PGeQM[baNWS6nfqTC5iX4Kl][1]
def VbgEajY4Bt2COpGDcPqI(mode,url,text):
	if   mode==180: ft3e2JBKQVXWlFPjaMhkEqGxvDg = eN02L7Tf5bQ()
	elif mode==181: ft3e2JBKQVXWlFPjaMhkEqGxvDg = sscM839DP1jWZ4zl6uIx0Kyn(url,text)
	elif mode==182: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HDxCnPKFhITpZmOsA4a0UL6(url)
	elif mode==183: ft3e2JBKQVXWlFPjaMhkEqGxvDg = o4oY13v5dWMcbilEDjKCnXNzHZ0(url)
	elif mode==188: ft3e2JBKQVXWlFPjaMhkEqGxvDg = uGsCteIibkFrvzdZ()
	elif mode==189: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HjZcUIVAXFCqy9TfBWKtgY2(text)
	else: ft3e2JBKQVXWlFPjaMhkEqGxvDg = False
	return ft3e2JBKQVXWlFPjaMhkEqGxvDg
def uGsCteIibkFrvzdZ():
	message = 'هذا الموقع تغير بالكامل ... وبحاجة الى اعادة برمجة من الصفر ... والمبرمج حاليا مشغول ويعاني من وعكة صحية ... ولهذا سوف يبقى الموقع مغلق الى ما شاء الله'
	ZIOHgA3z0TBR('','','رسالة من المبرمج',message)
	return
def eN02L7Tf5bQ():
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'بحث في الموقع','',189,'','','_REMEMBERRESULTS_')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'بوكس اوفيس موفيز لاند',EZxQp1WOldMTvFU,181,'','','box-office')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'أحدث الافلام',EZxQp1WOldMTvFU,181,'','','latest-movies')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'تليفزيون موفيز لاند',EZxQp1WOldMTvFU,181,'','','tv')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'الاكثر مشاهدة',EZxQp1WOldMTvFU,181,'','','top-views')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'أقوى الافلام الحالية',EZxQp1WOldMTvFU,181,'','','top-movies')
	MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(IIiPCruL6dT8s1lqj47SzpVHnYNm,EZxQp1WOldMTvFU,'',headers,'','MOVIZLAND-MENU-1st')
	items = My7Dwqvs6bfGNSIgX.findall('<h2><a href="(.*?)".*?">(.*?)<',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	for BoEFz2WhUyvTgDeiZ,title in items:
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,181)
	return MK6ZT2zjC1SbmveNFqor
def sscM839DP1jWZ4zl6uIx0Kyn(url,type=''):
	MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(UuEtImzir9,url,'',headers,'','MOVIZLAND-ITEMS-1st')
	if type=='latest-movies': vsptNMP2ZQC = My7Dwqvs6bfGNSIgX.findall('class="titleSection">أحدث الأفلام</h1>(.*?)<h1',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)[0]
	elif type=='box-office': vsptNMP2ZQC = My7Dwqvs6bfGNSIgX.findall('class="titleSection">بوكس اوفيس موفيز لاند</h1>(.*?)<h1',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)[0]
	elif type=='top-movies': vsptNMP2ZQC = My7Dwqvs6bfGNSIgX.findall('btn-2-overlay(.*?)<style>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)[0]
	elif type=='top-views': vsptNMP2ZQC = My7Dwqvs6bfGNSIgX.findall('btn-1 btn-absoly(.*?)btn-2 btn-absoly',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)[0]
	elif type=='tv': vsptNMP2ZQC = My7Dwqvs6bfGNSIgX.findall('class="titleSection">تليفزيون موفيز لاند</h1>(.*?)class="paging"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)[0]
	else: vsptNMP2ZQC = MK6ZT2zjC1SbmveNFqor
	if type in ['top-views','top-movies']:
		items = My7Dwqvs6bfGNSIgX.findall('style="background-image:url\(\'(.*?)\'.*?href="(.*?)".*?href="(.*?)".*?bottom-title.*?>(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	else: items = My7Dwqvs6bfGNSIgX.findall('height="3[0-9]+" src="(.*?)".*?bottom-title.*?href=.*?>(.*?)<.*?href="(.*?)".*?href="(.*?)"',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	y7y3d5Fbhv42ONmtwLZ0SerYoQq = []
	sMFW9ecd2nE = ['فيلم','الحلقة','الحلقه','عرض','Raw','SmackDown','اعلان','اجزاء']
	for IcWzVO137wFvemn2QTq8yKs9,Iwh7pS4CTEjZeO,pzYNuWHETc9orAef1BLmShsGRIw,OoW8aQ35s6TkSleGmyuw90PI in items:
		if type in ['top-views','top-movies']:
			IcWzVO137wFvemn2QTq8yKs9,BoEFz2WhUyvTgDeiZ,bOBQpgMudItXo,title = IcWzVO137wFvemn2QTq8yKs9,Iwh7pS4CTEjZeO,pzYNuWHETc9orAef1BLmShsGRIw,OoW8aQ35s6TkSleGmyuw90PI
		else: IcWzVO137wFvemn2QTq8yKs9,title,BoEFz2WhUyvTgDeiZ,bOBQpgMudItXo = IcWzVO137wFvemn2QTq8yKs9,Iwh7pS4CTEjZeO,pzYNuWHETc9orAef1BLmShsGRIw,OoW8aQ35s6TkSleGmyuw90PI
		BoEFz2WhUyvTgDeiZ = XnQbsZF0Ouh8p7zCdUN(BoEFz2WhUyvTgDeiZ)
		BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ.replace('?view=true','')
		title = PIfAumbGicwg5ye(title)
		if 'بجودة ' in title or 'بجوده ' in title:
			title = '_MOD_' + title.replace('بجودة ','').replace('بجوده ','')
		title = title.strip(' ')
		if 'الحلقة' in title or 'الحلقه' in title:
			ffhN7jAqe3Q4cR0Ukptzl = My7Dwqvs6bfGNSIgX.findall('(.*?) (الحلقة|الحلقه) \d+',title,My7Dwqvs6bfGNSIgX.DOTALL)
			if ffhN7jAqe3Q4cR0Ukptzl:
				title = '_MOD_' + ffhN7jAqe3Q4cR0Ukptzl[0][0]
				if title not in y7y3d5Fbhv42ONmtwLZ0SerYoQq:
					VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,183,IcWzVO137wFvemn2QTq8yKs9)
					y7y3d5Fbhv42ONmtwLZ0SerYoQq.append(title)
		elif any(WoFrX46wzbCNp18 in title for WoFrX46wzbCNp18 in sMFW9ecd2nE):
			BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ + '?servers=' + bOBQpgMudItXo
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,182,IcWzVO137wFvemn2QTq8yKs9)
		else:
			BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ + '?servers=' + bOBQpgMudItXo
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,183,IcWzVO137wFvemn2QTq8yKs9)
	if type=='':
		items = My7Dwqvs6bfGNSIgX.findall('\n<li><a href="(.*?)".*?>(.*?)<',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title in items:
			title = PIfAumbGicwg5ye(title)
			title = title.replace('الصفحة ','')
			if title!='':
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'صفحة '+title,BoEFz2WhUyvTgDeiZ,181)
	return
def o4oY13v5dWMcbilEDjKCnXNzHZ0(url):
	bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = url.split('?servers=')[0]
	MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(UuEtImzir9,bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,'',headers,'','MOVIZLAND-EPISODES-1st')
	vsptNMP2ZQC = My7Dwqvs6bfGNSIgX.findall('<title>(.*?)</title>.*?height="([0-9]+)" src="(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	title,wLWTRZQNlpACcvdFU3Vo,IcWzVO137wFvemn2QTq8yKs9 = vsptNMP2ZQC[0]
	name = My7Dwqvs6bfGNSIgX.findall('(.*?) (الحلقة|الحلقه) [0-9]+',title,My7Dwqvs6bfGNSIgX.DOTALL)
	if name: name = '_MOD_' + name[0][0]
	else: name = title
	items = []
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('class="episodesNumbers"(.*?)</div>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)"',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ in items:
			BoEFz2WhUyvTgDeiZ = XnQbsZF0Ouh8p7zCdUN(BoEFz2WhUyvTgDeiZ)
			title = My7Dwqvs6bfGNSIgX.findall('(الحلقة|الحلقه)-([0-9]+)',BoEFz2WhUyvTgDeiZ.split('/')[-2],My7Dwqvs6bfGNSIgX.DOTALL)
			if not title: title = My7Dwqvs6bfGNSIgX.findall('()-([0-9]+)',BoEFz2WhUyvTgDeiZ.split('/')[-2],My7Dwqvs6bfGNSIgX.DOTALL)
			if title: title = ' ' + title[0][1]
			else: title = ''
			title = name + ' - ' + 'الحلقة' + title
			title = PIfAumbGicwg5ye(title)
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,182,IcWzVO137wFvemn2QTq8yKs9)
	if not items:
		title = PIfAumbGicwg5ye(title)
		if 'بجودة ' in title or 'بجوده ' in title:
			title = '_MOD_' + title.replace('بجودة ','').replace('بجوده ','')
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,url,182,IcWzVO137wFvemn2QTq8yKs9)
	return
def HDxCnPKFhITpZmOsA4a0UL6(url):
	U13zMpCrR827fED6q4FKBoaLAs = url.split('?servers=')
	bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = U13zMpCrR827fED6q4FKBoaLAs[0]
	del U13zMpCrR827fED6q4FKBoaLAs[0]
	MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(IIiPCruL6dT8s1lqj47SzpVHnYNm,bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,'',headers,'','MOVIZLAND-PLAY-1st')
	BoEFz2WhUyvTgDeiZ = My7Dwqvs6bfGNSIgX.findall('font-size: 25px;" href="(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)[0]
	if BoEFz2WhUyvTgDeiZ not in U13zMpCrR827fED6q4FKBoaLAs: U13zMpCrR827fED6q4FKBoaLAs.append(BoEFz2WhUyvTgDeiZ)
	QQ2cE1FjUyxPonbDhaTkV6B3i = []
	for BoEFz2WhUyvTgDeiZ in U13zMpCrR827fED6q4FKBoaLAs:
		if '://moshahda.' in BoEFz2WhUyvTgDeiZ:
			OBhUNs9LmSTo7YMCec3xivP = BoEFz2WhUyvTgDeiZ
			QQ2cE1FjUyxPonbDhaTkV6B3i.append(OBhUNs9LmSTo7YMCec3xivP+'?named=Main')
	for BoEFz2WhUyvTgDeiZ in U13zMpCrR827fED6q4FKBoaLAs:
		if '://vb.movizland.' in BoEFz2WhUyvTgDeiZ:
			MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(IIiPCruL6dT8s1lqj47SzpVHnYNm,BoEFz2WhUyvTgDeiZ,'',headers,'','MOVIZLAND-PLAY-2nd')
			MK6ZT2zjC1SbmveNFqor = MK6ZT2zjC1SbmveNFqor.decode('windows-1256').encode('utf8')
			MK6ZT2zjC1SbmveNFqor = MK6ZT2zjC1SbmveNFqor.replace('src="http://up.movizland.com/uploads/13721411411.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"')
			MK6ZT2zjC1SbmveNFqor = MK6ZT2zjC1SbmveNFqor.replace('src="http://up.movizland.online/uploads/13721411411.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"')
			MK6ZT2zjC1SbmveNFqor = MK6ZT2zjC1SbmveNFqor.replace('</a></div><br /><div align="center">','src="/uploads/13721411411.png"')
			MK6ZT2zjC1SbmveNFqor = MK6ZT2zjC1SbmveNFqor.replace('class="tborder" align="center"','src="/uploads/13721411411.png"')
			XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('(src="/uploads/13721411411.png".*?href="http://moshahda\..*?/\w+.html".*?src="/uploads/13721411411.png")',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
			if XBuP6Op7y4K:
				XXxkpYnSUfE4A9jMu,iLIUfJZxbBAvczHmg2a = [],[]
				if len(XBuP6Op7y4K)==1:
					title = ''
					vsptNMP2ZQC = MK6ZT2zjC1SbmveNFqor
				else:
					for vsptNMP2ZQC in XBuP6Op7y4K:
						iiBEzXVNFDhfj36 = My7Dwqvs6bfGNSIgX.findall('src="/uploads/13721411411.png".*?http://up.movizland.(online|com)/uploads/.*?\*\*\*\*\*\*\*+(.*?src="/uploads/13721411411.png")',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
						if iiBEzXVNFDhfj36: vsptNMP2ZQC = 'src="/uploads/13721411411.png"  \n  ' + iiBEzXVNFDhfj36[0][1]
						iiBEzXVNFDhfj36 = My7Dwqvs6bfGNSIgX.findall('src="/uploads/13721411411.png".*?<hr size="1" style="color:'+'#'+'333; background-color:'+'#'+'333" />(.*?href="http://moshahda\..*?/\w+.html".*?src="/uploads/13721411411.png")',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
						if iiBEzXVNFDhfj36: vsptNMP2ZQC = 'src="/uploads/13721411411.png"  \n  ' + iiBEzXVNFDhfj36[0]
						iiBEzXVNFDhfj36 = My7Dwqvs6bfGNSIgX.findall('(src="/uploads/13721411411.png".*?href="http://moshahda\..*?/\w+.html".*?)<hr size="1" style="color:'+'#'+'333; background-color:'+'#'+'333" />.*?src="/uploads/13721411411.png"',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
						if iiBEzXVNFDhfj36: vsptNMP2ZQC = iiBEzXVNFDhfj36[0] + '  \n  src="/uploads/13721411411.png"'
						IT3hteFWjLUixHpvJm0zrYBwaD = My7Dwqvs6bfGNSIgX.findall('<(.*?)http://up.movizland.(online|com)/uploads/',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
						title = My7Dwqvs6bfGNSIgX.findall('> *([^<>]+) *<',IT3hteFWjLUixHpvJm0zrYBwaD[0][0],My7Dwqvs6bfGNSIgX.DOTALL)
						title = ' '.join(title)
						title = title.strip(' ')
						title = title.replace('  ',' ').replace('  ',' ').replace('  ',' ').replace('  ',' ').replace('  ',' ')
						XXxkpYnSUfE4A9jMu.append(title)
					GOtNfU3xQFkEhPouwA = CnKwdteDG5BE8MTRhUpYIJm3NLrSgq('أختر الفيديو المطلوب:', XXxkpYnSUfE4A9jMu)
					if GOtNfU3xQFkEhPouwA == -1 : return
					title = XXxkpYnSUfE4A9jMu[GOtNfU3xQFkEhPouwA]
					vsptNMP2ZQC = XBuP6Op7y4K[GOtNfU3xQFkEhPouwA]
				BoEFz2WhUyvTgDeiZ = My7Dwqvs6bfGNSIgX.findall('href="(http://moshahda\..*?/\w+.html)"',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
				M871ERZrTsi = BoEFz2WhUyvTgDeiZ[0]
				QQ2cE1FjUyxPonbDhaTkV6B3i.append(M871ERZrTsi+'?named=Forum')
				vsptNMP2ZQC = vsptNMP2ZQC.replace('ـ','')
				vsptNMP2ZQC = vsptNMP2ZQC.replace('src="http://up.movizland.online/uploads/1517412175296.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="both"  \n  ')
				vsptNMP2ZQC = vsptNMP2ZQC.replace('src="http://up.movizland.com/uploads/1517412175296.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="both"  \n  ')
				vsptNMP2ZQC = vsptNMP2ZQC.replace('سيرفرات التحميل','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="download"  \n  ')
				vsptNMP2ZQC = vsptNMP2ZQC.replace('روابط التحميل','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="download"  \n  ')
				vsptNMP2ZQC = vsptNMP2ZQC.replace('سيرفرات المشاهد','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="watch"  \n  ')
				vsptNMP2ZQC = vsptNMP2ZQC.replace('روابط المشاهد','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="watch"  \n  ')
				WcNA5H7SsCEm69wiPeJMbpjO = My7Dwqvs6bfGNSIgX.findall('(src="/uploads/13721411411.png".*?href="http://e5tsar.com/\d+".*?src="/uploads/13721411411.png")',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
				for Uwbc0HTBk6amhX1L45NJDr7dy in WcNA5H7SsCEm69wiPeJMbpjO:
					type = My7Dwqvs6bfGNSIgX.findall(' typetype="(.*?)" ',Uwbc0HTBk6amhX1L45NJDr7dy)
					if type:
						if type[0]!='both': type = '__'+type[0]
						else: type = ''
					items = My7Dwqvs6bfGNSIgX.findall('(?<!http://e5tsar.com/)(\w+[ \w]*</font>.*?|\w+[ \w]*<br />.*?)href="(http://e5tsar.com/.*?)"',Uwbc0HTBk6amhX1L45NJDr7dy,My7Dwqvs6bfGNSIgX.DOTALL)
					for L7ZPnUmRj2l1qvaDTC0WpucsVf,BoEFz2WhUyvTgDeiZ in items:
						title = My7Dwqvs6bfGNSIgX.findall('(\w+[ \w]*)<',L7ZPnUmRj2l1qvaDTC0WpucsVf)
						title = title[-1]
						BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ + '?named=' + title + type
						QQ2cE1FjUyxPonbDhaTkV6B3i.append(BoEFz2WhUyvTgDeiZ)
	QAKdHzO0rehbtyIc = bJEs4IVAPdyUrhwCLv9k2YoOl8nt1.replace(EZxQp1WOldMTvFU,oHxnAT1DzYQv)
	MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(IIiPCruL6dT8s1lqj47SzpVHnYNm,QAKdHzO0rehbtyIc,'',headers,'','MOVIZLAND-PLAY-3rd')
	items = My7Dwqvs6bfGNSIgX.findall('" href="(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if items:
		Vk4mXbCRcE6LI = items[-1]
		QQ2cE1FjUyxPonbDhaTkV6B3i.append(Vk4mXbCRcE6LI+'?named=Mobile')
	import t1kDWXQVpC
	t1kDWXQVpC.rqVt2xDi7jzJHBcPMRs6h0L(QQ2cE1FjUyxPonbDhaTkV6B3i,baNWS6nfqTC5iX4Kl,'video',url)
	return
def HjZcUIVAXFCqy9TfBWKtgY2(search):
	search,LQf3AeozSrai,showDialogs = X54MLovbG8nAEkB9J(search)
	if search=='': search = ViKAIsLurq83RSENayxWb()
	if search=='': return
	search = search.replace(' ','+')
	MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(UuEtImzir9,EZxQp1WOldMTvFU,'',headers,'','MOVIZLAND-SEARCH-1st')
	items = My7Dwqvs6bfGNSIgX.findall('<option value="(.*?)">(.*?)</option>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	CnNsvLHqf31 = [ '' ]
	aUMmwSXexcqN = [ 'الكل وبدون فلتر' ]
	for g4Y0BXLxCpuojKP1SAUtcq7TwN2,title in items:
		CnNsvLHqf31.append(g4Y0BXLxCpuojKP1SAUtcq7TwN2)
		aUMmwSXexcqN.append(title)
	if g4Y0BXLxCpuojKP1SAUtcq7TwN2:
		GOtNfU3xQFkEhPouwA = CnKwdteDG5BE8MTRhUpYIJm3NLrSgq('اختر الفلتر المناسب:', aUMmwSXexcqN)
		if GOtNfU3xQFkEhPouwA == -1 : return
		g4Y0BXLxCpuojKP1SAUtcq7TwN2 = CnNsvLHqf31[GOtNfU3xQFkEhPouwA]
	else: g4Y0BXLxCpuojKP1SAUtcq7TwN2 = ''
	url = EZxQp1WOldMTvFU + '/?s='+search+'&mcat='+g4Y0BXLxCpuojKP1SAUtcq7TwN2
	sscM839DP1jWZ4zl6uIx0Kyn(url)
	return
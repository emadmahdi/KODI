# -*- coding: utf-8 -*-
from G6AHskJeqN import *
baNWS6nfqTC5iX4Kl = 'BOKRA'
teUPLFC3B8bArakwHVGsdhoIWDM49f = '_BKR_'
EZxQp1WOldMTvFU = AK5RqLhji4W1wt9VdrCD3PGeQM[baNWS6nfqTC5iX4Kl][0]
headers = {'User-Agent':''}
eh2tDvRFWpLQI = ['افلام للكبار','بكرا TV']
def VbgEajY4Bt2COpGDcPqI(mode,url,text):
	if   mode==370: ft3e2JBKQVXWlFPjaMhkEqGxvDg = eN02L7Tf5bQ()
	elif mode==371: ft3e2JBKQVXWlFPjaMhkEqGxvDg = sscM839DP1jWZ4zl6uIx0Kyn(url,text)
	elif mode==372: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HDxCnPKFhITpZmOsA4a0UL6(url)
	elif mode==374: ft3e2JBKQVXWlFPjaMhkEqGxvDg = k5aGMSJh7eFYcv(url)
	elif mode==375: ft3e2JBKQVXWlFPjaMhkEqGxvDg = nYLsPCXv0cIUh9NeQSbk(url)
	elif mode==376: ft3e2JBKQVXWlFPjaMhkEqGxvDg = NNgcLA2ljpvrZGhVtKXM(0,url)
	elif mode==377: ft3e2JBKQVXWlFPjaMhkEqGxvDg = NNgcLA2ljpvrZGhVtKXM(1,url)
	elif mode==379: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HjZcUIVAXFCqy9TfBWKtgY2(text)
	else: ft3e2JBKQVXWlFPjaMhkEqGxvDg = False
	return ft3e2JBKQVXWlFPjaMhkEqGxvDg
def eN02L7Tf5bQ():
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(IIiPCruL6dT8s1lqj47SzpVHnYNm,'GET',EZxQp1WOldMTvFU,'','','','','BOKRA-MENU-1st')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'بحث في الموقع','',379,'','','_REMEMBERRESULTS_')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('right-side(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)">(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title in items:
			BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU+BoEFz2WhUyvTgDeiZ
			if not any(WoFrX46wzbCNp18 in title for WoFrX46wzbCNp18 in eh2tDvRFWpLQI):
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,371)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'المميزة',EZxQp1WOldMTvFU,375)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'الأحدث',EZxQp1WOldMTvFU,376)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'قائمة الممثلين',EZxQp1WOldMTvFU,374)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('class="container"(.*?)top-menu',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)">(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title in items[7:]:
			title = title.strip(' ')
			BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU+BoEFz2WhUyvTgDeiZ
			if not any(WoFrX46wzbCNp18 in title for WoFrX46wzbCNp18 in eh2tDvRFWpLQI):
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,371)
		for BoEFz2WhUyvTgDeiZ,title in items[0:7]:
			title = title.strip(' ')
			BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU+BoEFz2WhUyvTgDeiZ
			if not any(WoFrX46wzbCNp18 in title for WoFrX46wzbCNp18 in eh2tDvRFWpLQI):
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,371)
	return
def k5aGMSJh7eFYcv(website=''):
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(IIiPCruL6dT8s1lqj47SzpVHnYNm,'GET',EZxQp1WOldMTvFU,'','','','','BOKRA-ACTORSMENU-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('class="row cat Tags"(.*?)</div>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)" title="(.*?)"',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title in items:
			if 'http' in BoEFz2WhUyvTgDeiZ: continue
			else: BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU+BoEFz2WhUyvTgDeiZ
			if not any(WoFrX46wzbCNp18 in title for WoFrX46wzbCNp18 in eh2tDvRFWpLQI):
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,371)
	return
def nYLsPCXv0cIUh9NeQSbk(website=''):
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(f9Oum6c0FotxYn,'GET',EZxQp1WOldMTvFU,'','','','','BOKRA-FEATURED-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"MainContent"(.*?)main-title2',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(/vidpage_.*?)".*? src="(.*?)".*?<h3>(.*?)</h3>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,IcWzVO137wFvemn2QTq8yKs9,title in items:
			BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU+BoEFz2WhUyvTgDeiZ
			if not any(WoFrX46wzbCNp18 in title for WoFrX46wzbCNp18 in eh2tDvRFWpLQI):
				IcWzVO137wFvemn2QTq8yKs9 = IcWzVO137wFvemn2QTq8yKs9.replace('://',':///').replace('//','/').replace(' ','%20')
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,372,IcWzVO137wFvemn2QTq8yKs9)
	return
def NNgcLA2ljpvrZGhVtKXM(id,website=''):
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(f9Oum6c0FotxYn,'GET',EZxQp1WOldMTvFU,'','','','','BOKRA-WATCHINGNOW-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('main-title2(.*?)class="row',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[id]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*? src="(.*?)".*?<h4>(.*?)</h4>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,IcWzVO137wFvemn2QTq8yKs9,title in items:
			BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU+BoEFz2WhUyvTgDeiZ
			if not any(WoFrX46wzbCNp18 in title for WoFrX46wzbCNp18 in eh2tDvRFWpLQI):
				IcWzVO137wFvemn2QTq8yKs9 = IcWzVO137wFvemn2QTq8yKs9.replace('://',':///').replace('//','/').replace(' ','%20')
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,372,IcWzVO137wFvemn2QTq8yKs9)
	return
def sscM839DP1jWZ4zl6uIx0Kyn(url,FjDbpLOVQBJZToN=''):
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'','','','','BOKRA-TITLES-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	if 'vidpage_' in url:
		BoEFz2WhUyvTgDeiZ = My7Dwqvs6bfGNSIgX.findall('href="(/Album-.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if BoEFz2WhUyvTgDeiZ:
			BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU+BoEFz2WhUyvTgDeiZ[0]
			sscM839DP1jWZ4zl6uIx0Kyn(BoEFz2WhUyvTgDeiZ)
			return
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('class=" subcats"(.*?)class="col-md-3',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if FjDbpLOVQBJZToN=='' and XBuP6Op7y4K and XBuP6Op7y4K[0].count('href')>1:
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'الجميع',url,371,'','','titles')
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)" title="(.*?)"',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title in items:
			BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU+'/'+BoEFz2WhUyvTgDeiZ
			title = title.strip(' ')
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,371)
	else:
		y7y3d5Fbhv42ONmtwLZ0SerYoQq = []
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('class="col-md-3(.*?)col-xs-12',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if not XBuP6Op7y4K: XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('class="col-sm-8"(.*?)col-xs-12',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if XBuP6Op7y4K:
			vsptNMP2ZQC = XBuP6Op7y4K[0]
			items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?src="(.*?)".*?<h4>(.*?)</h4>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
			for BoEFz2WhUyvTgDeiZ,IcWzVO137wFvemn2QTq8yKs9,title in items:
				BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU+BoEFz2WhUyvTgDeiZ
				title = title.strip(' ')
				IcWzVO137wFvemn2QTq8yKs9 = IcWzVO137wFvemn2QTq8yKs9.replace('://',':///').replace('//','/').replace(' ','%20')
				if '/al_' in BoEFz2WhUyvTgDeiZ:
					VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,371,IcWzVO137wFvemn2QTq8yKs9)
				elif 'الحلقة' in title and ('/Cat-' in url or '/Search/' in url):
					ffhN7jAqe3Q4cR0Ukptzl = My7Dwqvs6bfGNSIgX.findall('(.*?) - +الحلقة +\d+',title,My7Dwqvs6bfGNSIgX.DOTALL)
					if ffhN7jAqe3Q4cR0Ukptzl: title = '_MOD_مسلسل '+ffhN7jAqe3Q4cR0Ukptzl[0]
					if title not in y7y3d5Fbhv42ONmtwLZ0SerYoQq:
						y7y3d5Fbhv42ONmtwLZ0SerYoQq.append(title)
						VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,371,IcWzVO137wFvemn2QTq8yKs9)
				else: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,372,IcWzVO137wFvemn2QTq8yKs9)
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('class="pagination(.*?)</div>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if XBuP6Op7y4K:
			vsptNMP2ZQC = XBuP6Op7y4K[0]
			items = My7Dwqvs6bfGNSIgX.findall('class="".*?href="(.*?)">(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
			for BoEFz2WhUyvTgDeiZ,title in items:
				BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU+BoEFz2WhUyvTgDeiZ
				title = 'صفحة '+PIfAumbGicwg5ye(title)
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,371,'','','titles')
	return
def HDxCnPKFhITpZmOsA4a0UL6(url):
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(f9Oum6c0FotxYn,'GET',url,'','','','','BOKRA-PLAY-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	ME2Q6F7u8Vp1km9ws = My7Dwqvs6bfGNSIgX.findall('label-success mrg-btm-5 ">(.*?)<',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if ME2Q6F7u8Vp1km9ws and a97xrkSOefH5DbjXunq(baNWS6nfqTC5iX4Kl,url,ME2Q6F7u8Vp1km9ws): return
	QAKdHzO0rehbtyIc = ''
	bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = My7Dwqvs6bfGNSIgX.findall('var url = "(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if bJEs4IVAPdyUrhwCLv9k2YoOl8nt1: bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = bJEs4IVAPdyUrhwCLv9k2YoOl8nt1[0]
	else: bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = url.replace('/vidpage_','/Play/')
	if 'http' not in bJEs4IVAPdyUrhwCLv9k2YoOl8nt1: bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = EZxQp1WOldMTvFU+bJEs4IVAPdyUrhwCLv9k2YoOl8nt1
	bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = bJEs4IVAPdyUrhwCLv9k2YoOl8nt1.strip('-')
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(f9Oum6c0FotxYn,'GET',bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,'','','','','BOKRA-PLAY-2nd')
	wN6n7OZBoDkTvCi8LdbJjYV = xHb86g9WZqPwRfVjXD2JalzSIp.content
	QAKdHzO0rehbtyIc = My7Dwqvs6bfGNSIgX.findall('src="(.*?)"',wN6n7OZBoDkTvCi8LdbJjYV,My7Dwqvs6bfGNSIgX.DOTALL)
	if QAKdHzO0rehbtyIc:
		QAKdHzO0rehbtyIc = QAKdHzO0rehbtyIc[-1]
		if 'http' not in QAKdHzO0rehbtyIc: QAKdHzO0rehbtyIc = 'http:'+QAKdHzO0rehbtyIc
		if '/PLAY/' not in bJEs4IVAPdyUrhwCLv9k2YoOl8nt1:
			if 'embed.min.js' in QAKdHzO0rehbtyIc:
				GwxneJVIQC8dfDaYtAl1BHv = My7Dwqvs6bfGNSIgX.findall('data-publisher-id="(.*?)" data-video-id="(.*?)"',wN6n7OZBoDkTvCi8LdbJjYV,My7Dwqvs6bfGNSIgX.DOTALL)
				if GwxneJVIQC8dfDaYtAl1BHv:
					WOfdHKmNGpa1DTwkVcCEM2Bv6RFq, iiaJYCdeXoS8K = GwxneJVIQC8dfDaYtAl1BHv[0]
					QAKdHzO0rehbtyIc = ooq2D9xF8ZLpPBs(QAKdHzO0rehbtyIc,'url')+'/v2/'+WOfdHKmNGpa1DTwkVcCEM2Bv6RFq+'/config/'+iiaJYCdeXoS8K+'.json'
		import t1kDWXQVpC
		t1kDWXQVpC.rqVt2xDi7jzJHBcPMRs6h0L([QAKdHzO0rehbtyIc],baNWS6nfqTC5iX4Kl,'video',url)
	return
def HjZcUIVAXFCqy9TfBWKtgY2(search):
	search,LQf3AeozSrai,showDialogs = X54MLovbG8nAEkB9J(search)
	if search=='': search = ViKAIsLurq83RSENayxWb()
	if search=='': return
	search = search.replace(' ','+')
	url = EZxQp1WOldMTvFU+'/Search/'+search
	sscM839DP1jWZ4zl6uIx0Kyn(url)
	return
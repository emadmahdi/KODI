# -*- coding: utf-8 -*-
from G6AHskJeqN import *
baNWS6nfqTC5iX4Kl = 'CIMACLUP'
teUPLFC3B8bArakwHVGsdhoIWDM49f = '_CMC_'
EZxQp1WOldMTvFU = AK5RqLhji4W1wt9VdrCD3PGeQM[baNWS6nfqTC5iX4Kl][0]
eh2tDvRFWpLQI = ['موقع نتفليكس']
def VbgEajY4Bt2COpGDcPqI(mode,url,text):
	if   mode==490: ft3e2JBKQVXWlFPjaMhkEqGxvDg = eN02L7Tf5bQ()
	elif mode==491: ft3e2JBKQVXWlFPjaMhkEqGxvDg = sscM839DP1jWZ4zl6uIx0Kyn(url,text)
	elif mode==492: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HDxCnPKFhITpZmOsA4a0UL6(url)
	elif mode==493: ft3e2JBKQVXWlFPjaMhkEqGxvDg = o4oY13v5dWMcbilEDjKCnXNzHZ0(url)
	elif mode==494: ft3e2JBKQVXWlFPjaMhkEqGxvDg = M25iOAH9NfalvyPEUuToG8qn(url)
	elif mode==499: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HjZcUIVAXFCqy9TfBWKtgY2(text,url)
	else: ft3e2JBKQVXWlFPjaMhkEqGxvDg = False
	return ft3e2JBKQVXWlFPjaMhkEqGxvDg
def eN02L7Tf5bQ():
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',EZxQp1WOldMTvFU,'','','','','CIMACLUP-MENU-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	xxE5BSyQkNsj = My7Dwqvs6bfGNSIgX.findall('href="(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	xxE5BSyQkNsj = xxE5BSyQkNsj[0].strip('/')
	xxE5BSyQkNsj = ooq2D9xF8ZLpPBs(xxE5BSyQkNsj,'url')
	kdYXhMN8Hpbt = My7Dwqvs6bfGNSIgX.findall('"filter AjaxifyFilter"(.*?)</div>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if kdYXhMN8Hpbt:
		vsptNMP2ZQC = kdYXhMN8Hpbt[0]
		items = My7Dwqvs6bfGNSIgX.findall('data-filter="(.*?)".*?>(.*?)</a>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title in items:
			if title in eh2tDvRFWpLQI: continue
			BoEFz2WhUyvTgDeiZ = xxE5BSyQkNsj+'/wp-content/themes/old/filter/'+BoEFz2WhUyvTgDeiZ+'.php'
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,491)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'أفلام',xxE5BSyQkNsj+'/category/افلام-movies-filme/foreign-hd-افلام-اجنبى-2',494,'','','_REMEMBERRESULTS_')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'مسلسلات',xxE5BSyQkNsj+'/category/مسلسلات/مسلسلات-اجنبى',494,'','','_REMEMBERRESULTS_')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('class="navigation-menu"(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	vsptNMP2ZQC = XBuP6Op7y4K[0]
	items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?>(.*?)</a>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	for BoEFz2WhUyvTgDeiZ,title in items:
		if BoEFz2WhUyvTgDeiZ=='/': continue
		if 'http' not in BoEFz2WhUyvTgDeiZ: BoEFz2WhUyvTgDeiZ = xxE5BSyQkNsj+BoEFz2WhUyvTgDeiZ
		if title in eh2tDvRFWpLQI: continue
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,491)
	return MK6ZT2zjC1SbmveNFqor
def M25iOAH9NfalvyPEUuToG8qn(url):
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'','','','','CIMACLUP-SUBMENU-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	KRI8WExzA4p = My7Dwqvs6bfGNSIgX.findall('"filter"(.*?)</div>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if KRI8WExzA4p:
		vsptNMP2ZQC = KRI8WExzA4p[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?>(.*?)</a>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title in items:
			if title in eh2tDvRFWpLQI: continue
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,491)
	return
def sscM839DP1jWZ4zl6uIx0Kyn(url,rwQsc9O3oGdFKbxPlNiM56S2pLUJ0=''):
	items = []
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'','','','','CIMACLUP-TITLES-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	vsptNMP2ZQC = ''
	if '.php' in url: vsptNMP2ZQC = MK6ZT2zjC1SbmveNFqor
	elif '?s=' in url:
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"blocks(.*?)"manifest"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if XBuP6Op7y4K:
			vsptNMP2ZQC = XBuP6Op7y4K[0]
			items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?src="(.*?)".*?alt="(.*?)"',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	else:
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"Blocks(.*?)"manifest"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if XBuP6Op7y4K:
			vsptNMP2ZQC = XBuP6Op7y4K[0]
	if not vsptNMP2ZQC: return
	y7y3d5Fbhv42ONmtwLZ0SerYoQq = []
	tkBQK76YMeUlRI1TomgECfA = ['مشاهدة','فيلم','اغنية','أغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for BoEFz2WhUyvTgDeiZ,IcWzVO137wFvemn2QTq8yKs9,title in items:
		title = PIfAumbGicwg5ye(title)
		ffhN7jAqe3Q4cR0Ukptzl = My7Dwqvs6bfGNSIgX.findall('(.*?) حلقة \d+',title,My7Dwqvs6bfGNSIgX.DOTALL)
		if not ffhN7jAqe3Q4cR0Ukptzl: ffhN7jAqe3Q4cR0Ukptzl = My7Dwqvs6bfGNSIgX.findall('(.*?) الحلقة \d+',title,My7Dwqvs6bfGNSIgX.DOTALL)
		if not ffhN7jAqe3Q4cR0Ukptzl or any(WoFrX46wzbCNp18 in title for WoFrX46wzbCNp18 in tkBQK76YMeUlRI1TomgECfA):
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,492,IcWzVO137wFvemn2QTq8yKs9)
		elif ffhN7jAqe3Q4cR0Ukptzl and 'حلقة' in title:
			title = '_MOD_' + ffhN7jAqe3Q4cR0Ukptzl[0]
			if title not in y7y3d5Fbhv42ONmtwLZ0SerYoQq:
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,493,IcWzVO137wFvemn2QTq8yKs9)
				y7y3d5Fbhv42ONmtwLZ0SerYoQq.append(title)
		else: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,493,IcWzVO137wFvemn2QTq8yKs9)
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"pagination"(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('<li><a href="(.*?)".*?>(.*?)</a>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title in items:
			title = PIfAumbGicwg5ye(title)
			title = title.replace('الصفحة ','')
			if title!='': VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'صفحة '+title,BoEFz2WhUyvTgDeiZ,491)
	return
def o4oY13v5dWMcbilEDjKCnXNzHZ0(url):
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'','','','','CIMACLUP-EPISODES-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = My7Dwqvs6bfGNSIgX.findall('"ButtonsBarCo".*?href="(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if bJEs4IVAPdyUrhwCLv9k2YoOl8nt1:
		bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = bJEs4IVAPdyUrhwCLv9k2YoOl8nt1[0]
		xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,'','','','','CIMACLUP-EPISODES-2nd')
		MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	IcWzVO137wFvemn2QTq8yKs9 = My7Dwqvs6bfGNSIgX.findall('"img-responsive" src="(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if IcWzVO137wFvemn2QTq8yKs9: IcWzVO137wFvemn2QTq8yKs9 = IcWzVO137wFvemn2QTq8yKs9[0]
	else: IcWzVO137wFvemn2QTq8yKs9 = tUXmK5PeEH9SDq.getInfoLabel('ListItem.Thumb')
	KRI8WExzA4p = My7Dwqvs6bfGNSIgX.findall('"filter"(.*?)</div>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	kdYXhMN8Hpbt = My7Dwqvs6bfGNSIgX.findall('"Blocks(.*?)class="pagination"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if KRI8WExzA4p and '/series/' not in url:
		vsptNMP2ZQC = KRI8WExzA4p[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?>(.*?)</a>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title in items:
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,493,IcWzVO137wFvemn2QTq8yKs9)
	elif kdYXhMN8Hpbt:
		vsptNMP2ZQC = kdYXhMN8Hpbt[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?image\:url\((.*?)\).*?"boxtitle">(.*?)</div>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		if items:
			for BoEFz2WhUyvTgDeiZ,IcWzVO137wFvemn2QTq8yKs9,title in items:
				title = title.strip(' ')
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,492,IcWzVO137wFvemn2QTq8yKs9)
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"pagination"(.*?)</div>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if XBuP6Op7y4K:
			vsptNMP2ZQC = XBuP6Op7y4K[0]
			items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?>(.*?)</a>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
			for BoEFz2WhUyvTgDeiZ,title in items:
				title = PIfAumbGicwg5ye(title)
				title = title.replace('الصفحة ','')
				if title!='': VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'صفحة '+title,BoEFz2WhUyvTgDeiZ,491)
	return
def HDxCnPKFhITpZmOsA4a0UL6(url):
	bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = url.strip('/')+'/?view=1'
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,'','','','','CIMACLUP-PLAY-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	QQ2cE1FjUyxPonbDhaTkV6B3i = []
	xxE5BSyQkNsj = ooq2D9xF8ZLpPBs(url,'url')
	GuQo8hCDmdBYNZRt5926LFMVwlJnA4 = My7Dwqvs6bfGNSIgX.findall("data: 'q=(.*?)&",MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	GuQo8hCDmdBYNZRt5926LFMVwlJnA4 = GuQo8hCDmdBYNZRt5926LFMVwlJnA4[0]
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"serversList"(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('data-server="(.*?)">(.*?)</li>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for a80aUzWcZHwT6Lxt2VJiNYRQBjfSq,title in items:
			title = title.strip(' ')
			BoEFz2WhUyvTgDeiZ = xxE5BSyQkNsj+'/wp-content/themes/old/servers/server.php?q='+GuQo8hCDmdBYNZRt5926LFMVwlJnA4+'&i='+a80aUzWcZHwT6Lxt2VJiNYRQBjfSq+'?named='+title+'__watch'
			QQ2cE1FjUyxPonbDhaTkV6B3i.append(BoEFz2WhUyvTgDeiZ)
	BoEFz2WhUyvTgDeiZ = My7Dwqvs6bfGNSIgX.findall('"embedServer".*?SRC="(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if BoEFz2WhUyvTgDeiZ:
		title = 'مفضل'
		BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ[0]+'?named=__embed__'+title
		QQ2cE1FjUyxPonbDhaTkV6B3i.append(BoEFz2WhUyvTgDeiZ)
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"downloadsList"(.*?)</div>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('<td>(.*?)</td>.*?href="(.*?)"',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for title,BoEFz2WhUyvTgDeiZ in items:
			title = title.strip(' ')
			if 'anavidz' in BoEFz2WhUyvTgDeiZ: U2UaTcgBpsEZxKiRG1Xv8 = '__خاص'
			else: U2UaTcgBpsEZxKiRG1Xv8 = ''
			BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ+'?named='+title+'__download'+U2UaTcgBpsEZxKiRG1Xv8
			QQ2cE1FjUyxPonbDhaTkV6B3i.append(BoEFz2WhUyvTgDeiZ)
	import t1kDWXQVpC
	t1kDWXQVpC.rqVt2xDi7jzJHBcPMRs6h0L(QQ2cE1FjUyxPonbDhaTkV6B3i,baNWS6nfqTC5iX4Kl,'video',url)
	return
def HjZcUIVAXFCqy9TfBWKtgY2(search,xxE5BSyQkNsj=''):
	if not xxE5BSyQkNsj: xxE5BSyQkNsj = EZxQp1WOldMTvFU
	search,LQf3AeozSrai,showDialogs = X54MLovbG8nAEkB9J(search)
	if not search:
		search = ViKAIsLurq83RSENayxWb()
		if not search: return
	search = search.replace(' ','+')
	url = xxE5BSyQkNsj+'/index.php?s='+search
	sscM839DP1jWZ4zl6uIx0Kyn(url)
	return
# -*- coding: utf-8 -*-
from G6AHskJeqN import *
headers = { 'User-Agent' : '' }
baNWS6nfqTC5iX4Kl = 'AKOAMCAM'
teUPLFC3B8bArakwHVGsdhoIWDM49f = '_AKC_'
EZxQp1WOldMTvFU = AK5RqLhji4W1wt9VdrCD3PGeQM[baNWS6nfqTC5iX4Kl][0]
eh2tDvRFWpLQI = ['مصارعة']
def VbgEajY4Bt2COpGDcPqI(mode,url,text):
	if   mode==350: ft3e2JBKQVXWlFPjaMhkEqGxvDg = eN02L7Tf5bQ()
	elif mode==351: ft3e2JBKQVXWlFPjaMhkEqGxvDg = sscM839DP1jWZ4zl6uIx0Kyn(url,text)
	elif mode==352: ft3e2JBKQVXWlFPjaMhkEqGxvDg = o4oY13v5dWMcbilEDjKCnXNzHZ0(url)
	elif mode==353: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HDxCnPKFhITpZmOsA4a0UL6(url)
	elif mode==354: ft3e2JBKQVXWlFPjaMhkEqGxvDg = LLJlTxDePyjoVKA(url,'FILTERS___'+text)
	elif mode==355: ft3e2JBKQVXWlFPjaMhkEqGxvDg = LLJlTxDePyjoVKA(url,'CATEGORIES___'+text)
	elif mode==356: ft3e2JBKQVXWlFPjaMhkEqGxvDg = Xxa4Ef8z0bUCeq2gDNhdH5(url)
	elif mode==357: ft3e2JBKQVXWlFPjaMhkEqGxvDg = kkwOGtEscDKbfNUjIXL(url)
	elif mode==359: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HjZcUIVAXFCqy9TfBWKtgY2(text)
	else: ft3e2JBKQVXWlFPjaMhkEqGxvDg = False
	return ft3e2JBKQVXWlFPjaMhkEqGxvDg
def eN02L7Tf5bQ():
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link',teUPLFC3B8bArakwHVGsdhoIWDM49f+'[COLOR FFFFFF00]هذا الموقع مغلق[/COLOR]','',8)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'بحث في الموقع','',359,'','','_REMEMBERRESULTS_')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'فلتر محدد',EZxQp1WOldMTvFU,356)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'فلتر كامل',EZxQp1WOldMTvFU,357)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(UuEtImzir9,EZxQp1WOldMTvFU,'',headers,'','AKOAMCAM-MENU-1st')
	bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = My7Dwqvs6bfGNSIgX.findall('recently-container.*?href="(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if bJEs4IVAPdyUrhwCLv9k2YoOl8nt1: bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = bJEs4IVAPdyUrhwCLv9k2YoOl8nt1[0]
	else: bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = EZxQp1WOldMTvFU
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'اضيف حديثا',bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,351)
	bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = My7Dwqvs6bfGNSIgX.findall('@id":"(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if bJEs4IVAPdyUrhwCLv9k2YoOl8nt1: bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = bJEs4IVAPdyUrhwCLv9k2YoOl8nt1[0]
	else: bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = EZxQp1WOldMTvFU
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'المميزة',bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,351,'','','featured')
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('main-categories-list(.*?)main-categories-list',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?class="font.*?>(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title in items:
			if title not in eh2tDvRFWpLQI: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,351)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('class="categories-box(.*?)<footer',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?">(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title in items:
			BoEFz2WhUyvTgDeiZ = PIfAumbGicwg5ye(BoEFz2WhUyvTgDeiZ)
			if title not in eh2tDvRFWpLQI: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,351)
	return MK6ZT2zjC1SbmveNFqor
def Xxa4Ef8z0bUCeq2gDNhdH5(website=''):
	MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(IIiPCruL6dT8s1lqj47SzpVHnYNm,EZxQp1WOldMTvFU,'',headers,'','AKOAMCAM-MENU-1st')
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('class="menu(.*?)<nav',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?text">(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title in items:
			if title not in eh2tDvRFWpLQI:
				title = title+' مصنفة'
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,355)
		if website=='': VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	return MK6ZT2zjC1SbmveNFqor
def kkwOGtEscDKbfNUjIXL(website=''):
	MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(IIiPCruL6dT8s1lqj47SzpVHnYNm,EZxQp1WOldMTvFU,'',headers,'','AKOAMCAM-MENU-1st')
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('class="menu(.*?)<nav',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?text">(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title in items:
			if title not in eh2tDvRFWpLQI:
				title = title+' مفلترة'
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,354)
		if website=='': VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	return MK6ZT2zjC1SbmveNFqor
def sscM839DP1jWZ4zl6uIx0Kyn(url,type=''):
	MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(SToQEHqGtMnAlFbCz4wxBDuOsmW7,url,'',headers,True,'AKOAMCAM-TITLES-1st')
	if type=='featured': XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('swiper-container(.*?)swiper-button-prev',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	else: XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('class="container"(.*?)main-footer',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('xlink:href="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		y7y3d5Fbhv42ONmtwLZ0SerYoQq = []
		for IcWzVO137wFvemn2QTq8yKs9,BoEFz2WhUyvTgDeiZ,title in items:
			title = PIfAumbGicwg5ye(title)
			if 'الحلقة' in title or 'الحلقه' in title:
				ffhN7jAqe3Q4cR0Ukptzl = My7Dwqvs6bfGNSIgX.findall('(.*?) (الحلقة|الحلقه) \d+',title,My7Dwqvs6bfGNSIgX.DOTALL)
				if ffhN7jAqe3Q4cR0Ukptzl:
					title = '_MOD_' + ffhN7jAqe3Q4cR0Ukptzl[0][0]
					if title not in y7y3d5Fbhv42ONmtwLZ0SerYoQq:
						VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,352,IcWzVO137wFvemn2QTq8yKs9)
						y7y3d5Fbhv42ONmtwLZ0SerYoQq.append(title)
			elif 'مسلسل' in title:
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,352,IcWzVO137wFvemn2QTq8yKs9)
			else: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,353,IcWzVO137wFvemn2QTq8yKs9)
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('pagination(.*?)</div>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('href=["\'](.*?)["\'].*?>(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title in items:
			BoEFz2WhUyvTgDeiZ = PIfAumbGicwg5ye(BoEFz2WhUyvTgDeiZ)
			title = PIfAumbGicwg5ye(title)
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'صفحة '+title,BoEFz2WhUyvTgDeiZ,351)
	return
def HjZcUIVAXFCqy9TfBWKtgY2(search):
	search,LQf3AeozSrai,showDialogs = X54MLovbG8nAEkB9J(search)
	if search=='': search = ViKAIsLurq83RSENayxWb()
	if search=='': return
	ystIEd371fLkT50pcRUWi9olNDu = search.replace(' ','+')
	url = EZxQp1WOldMTvFU + '/?s='+ystIEd371fLkT50pcRUWi9olNDu
	ft3e2JBKQVXWlFPjaMhkEqGxvDg = sscM839DP1jWZ4zl6uIx0Kyn(url)
	return
def o4oY13v5dWMcbilEDjKCnXNzHZ0(url):
	MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(UuEtImzir9,url,'',headers,True,'AKOAMCAM-EPISODES-1st')
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('text-white">الحلقات(.*?)<header',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		o93oJVvuQUY = My7Dwqvs6bfGNSIgX.findall('href="(http.*?)".*?src="(.*?)".*?alt="(.*?)"',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,IcWzVO137wFvemn2QTq8yKs9,title in o93oJVvuQUY:
			if 'الحلقة' in title or 'الحلقه' in title: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,353,IcWzVO137wFvemn2QTq8yKs9)
	else:
		IcWzVO137wFvemn2QTq8yKs9 = tUXmK5PeEH9SDq.getInfoLabel('ListItem.Icon')
		if MK6ZT2zjC1SbmveNFqor.count('<title>')>1: title = My7Dwqvs6bfGNSIgX.findall('<title>(.*?)<',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)[1]
		else: title = 'رابط التشغيل'
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,url,353,IcWzVO137wFvemn2QTq8yKs9)
	return
def HDxCnPKFhITpZmOsA4a0UL6(url):
	QQ2cE1FjUyxPonbDhaTkV6B3i,wlfZEzuRyYLvrp = [],[]
	bQXVvj7oKlif = mORwgTnXBdQ7iCSHKf(IIiPCruL6dT8s1lqj47SzpVHnYNm,'GET',url,'','','','','AKOAMCAM-PLAY-1st')
	MK6ZT2zjC1SbmveNFqor = bQXVvj7oKlif.content
	IIi2NYTdvHzGUQ89EBLOgqr = My7Dwqvs6bfGNSIgX.findall('post_id=(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if IIi2NYTdvHzGUQ89EBLOgqr:
		IIi2NYTdvHzGUQ89EBLOgqr = IIi2NYTdvHzGUQ89EBLOgqr[0]
		headers = {'User-Agent':'','Content-Type':'application/x-www-form-urlencoded'}
		data = {'post_id':IIi2NYTdvHzGUQ89EBLOgqr}
		bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = EZxQp1WOldMTvFU+'/wp-content/themes/aflam8kkk/Inc/Ajax/Single/Watch.php'
		uyQHMt0mdIURVsb5jwFSp7ahilgKW = mORwgTnXBdQ7iCSHKf(IIiPCruL6dT8s1lqj47SzpVHnYNm,'POST',bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,data,headers,'','','AKOAMCAM-PLAY-1st')
		wN6n7OZBoDkTvCi8LdbJjYV = uyQHMt0mdIURVsb5jwFSp7ahilgKW.content
		items = My7Dwqvs6bfGNSIgX.findall('data-server="(.*?)".*?class="text">(.*?)<',wN6n7OZBoDkTvCi8LdbJjYV,My7Dwqvs6bfGNSIgX.DOTALL)
		for p8hzHJnjC95karceyWxX,name in items:
			BoEFz2WhUyvTgDeiZ = 'https://w.akoam.cam/wp-content/themes/aflam8kkk/Inc/Ajax/Single/Server.php'
			BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ+'?postid='+IIi2NYTdvHzGUQ89EBLOgqr+'&serverid='+p8hzHJnjC95karceyWxX+'?named='+name+'__watch'
			QQ2cE1FjUyxPonbDhaTkV6B3i.append(BoEFz2WhUyvTgDeiZ)
			wlfZEzuRyYLvrp.append(name)
		bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = EZxQp1WOldMTvFU+'/wp-content/themes/aflam8kkk/Inc/Ajax/Single/Download.php'
		uyQHMt0mdIURVsb5jwFSp7ahilgKW = mORwgTnXBdQ7iCSHKf(IIiPCruL6dT8s1lqj47SzpVHnYNm,'POST',bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,data,headers,'','','AKOAMCAM-PLAY-1st')
		wN6n7OZBoDkTvCi8LdbJjYV = uyQHMt0mdIURVsb5jwFSp7ahilgKW.content
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?class="text">(.*?)<',wN6n7OZBoDkTvCi8LdbJjYV,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title in items:
			BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ.strip(' ')
			BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ+'?named='+title+'__download'
			QQ2cE1FjUyxPonbDhaTkV6B3i.append(BoEFz2WhUyvTgDeiZ)
			wlfZEzuRyYLvrp.append(title)
	import t1kDWXQVpC
	t1kDWXQVpC.rqVt2xDi7jzJHBcPMRs6h0L(QQ2cE1FjUyxPonbDhaTkV6B3i,baNWS6nfqTC5iX4Kl,'video',url)
	return
def LLJlTxDePyjoVKA(url,filter):
	vIZKhbfsXmWAyUVecrNOz95LQ = ['cat','genre','release-year','quality','orderby']
	if '?' in url: url = url.split('?')[0]
	type,filter = filter.split('___',1)
	if filter=='': H2HMwT4JFz7rDkPZmRjcX,JPnr9ICqkDyV = '',''
	else: H2HMwT4JFz7rDkPZmRjcX,JPnr9ICqkDyV = filter.split('___')
	if type=='CATEGORIES':
		if vIZKhbfsXmWAyUVecrNOz95LQ[0]+'=' not in H2HMwT4JFz7rDkPZmRjcX: g4Y0BXLxCpuojKP1SAUtcq7TwN2 = vIZKhbfsXmWAyUVecrNOz95LQ[0]
		for FVW0I9sYcAjmDgn8r in range(len(vIZKhbfsXmWAyUVecrNOz95LQ[0:-1])):
			if vIZKhbfsXmWAyUVecrNOz95LQ[FVW0I9sYcAjmDgn8r]+'=' in H2HMwT4JFz7rDkPZmRjcX: g4Y0BXLxCpuojKP1SAUtcq7TwN2 = vIZKhbfsXmWAyUVecrNOz95LQ[FVW0I9sYcAjmDgn8r+1]
		HHXeMqVOshPcW3tULa5v = H2HMwT4JFz7rDkPZmRjcX+'&'+g4Y0BXLxCpuojKP1SAUtcq7TwN2+'=0'
		DoSfCckGA9BQe = JPnr9ICqkDyV+'&'+g4Y0BXLxCpuojKP1SAUtcq7TwN2+'=0'
		A7AEKRlF6Hf3eWVxY0NdwgsMPCc = HHXeMqVOshPcW3tULa5v.strip('&')+'___'+DoSfCckGA9BQe.strip('&')
		woj78rBnbLlmZWIy19iPHFCf5 = BrbZhHKJ0jnIe2lumE9M(JPnr9ICqkDyV,'all')
		bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = url+'?'+woj78rBnbLlmZWIy19iPHFCf5
	elif type=='FILTERS':
		WUSylLup41cYkhVXGtq = BrbZhHKJ0jnIe2lumE9M(H2HMwT4JFz7rDkPZmRjcX,'modified_values')
		WUSylLup41cYkhVXGtq = XnQbsZF0Ouh8p7zCdUN(WUSylLup41cYkhVXGtq)
		if JPnr9ICqkDyV!='': JPnr9ICqkDyV = BrbZhHKJ0jnIe2lumE9M(JPnr9ICqkDyV,'all')
		if JPnr9ICqkDyV=='': bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = url
		else: bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = url+'?'+JPnr9ICqkDyV
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'أظهار قائمة الفيديو التي تم اختيارها',bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,351,'','1')
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+' [[   '+WUSylLup41cYkhVXGtq+'   ]]',bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,351,'','1')
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(IIiPCruL6dT8s1lqj47SzpVHnYNm,url,'',headers,True,'AKOAMCAM-FILTERS_MENU-1st')
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('<form id(.*?)</form>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	vsptNMP2ZQC = XBuP6Op7y4K[0]
	E3ErsLQfR4JXt = My7Dwqvs6bfGNSIgX.findall('<select.*?name="(.*?)".*?">(.*?)<(.*?)</select>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	dict = {}
	for RTsbVE9CiQt,name,vsptNMP2ZQC in E3ErsLQfR4JXt:
		items = My7Dwqvs6bfGNSIgX.findall('<option(.*?)>(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		if '=' not in bJEs4IVAPdyUrhwCLv9k2YoOl8nt1: bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = url
		if type=='CATEGORIES':
			if g4Y0BXLxCpuojKP1SAUtcq7TwN2!=RTsbVE9CiQt: continue
			elif len(items)<=1:
				if RTsbVE9CiQt==vIZKhbfsXmWAyUVecrNOz95LQ[-1]: sscM839DP1jWZ4zl6uIx0Kyn(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1)
				else: LLJlTxDePyjoVKA(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,'CATEGORIES___'+A7AEKRlF6Hf3eWVxY0NdwgsMPCc)
				return
			else:
				if RTsbVE9CiQt==vIZKhbfsXmWAyUVecrNOz95LQ[-1]: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'الجميع',bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,351,'','1')
				else: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'الجميع',bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,355,'','',A7AEKRlF6Hf3eWVxY0NdwgsMPCc)
		elif type=='FILTERS':
			HHXeMqVOshPcW3tULa5v = H2HMwT4JFz7rDkPZmRjcX+'&'+RTsbVE9CiQt+'=0'
			DoSfCckGA9BQe = JPnr9ICqkDyV+'&'+RTsbVE9CiQt+'=0'
			A7AEKRlF6Hf3eWVxY0NdwgsMPCc = HHXeMqVOshPcW3tULa5v+'___'+DoSfCckGA9BQe
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'الجميع : '+name,bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,354,'','',A7AEKRlF6Hf3eWVxY0NdwgsMPCc)
		dict[RTsbVE9CiQt] = {}
		for WoFrX46wzbCNp18,A5AMg7LY1HlOz0B82n in items:
			if A5AMg7LY1HlOz0B82n in eh2tDvRFWpLQI: continue
			if 'value' not in WoFrX46wzbCNp18: WoFrX46wzbCNp18 = A5AMg7LY1HlOz0B82n
			else: WoFrX46wzbCNp18 = My7Dwqvs6bfGNSIgX.findall('"(.*?)"',WoFrX46wzbCNp18,My7Dwqvs6bfGNSIgX.DOTALL)[0]
			dict[RTsbVE9CiQt][WoFrX46wzbCNp18] = A5AMg7LY1HlOz0B82n
			HHXeMqVOshPcW3tULa5v = H2HMwT4JFz7rDkPZmRjcX+'&'+RTsbVE9CiQt+'='+A5AMg7LY1HlOz0B82n
			DoSfCckGA9BQe = JPnr9ICqkDyV+'&'+RTsbVE9CiQt+'='+WoFrX46wzbCNp18
			QQIzTLCXyhtZ7pRNnGq = HHXeMqVOshPcW3tULa5v+'___'+DoSfCckGA9BQe
			title = A5AMg7LY1HlOz0B82n+' : '#+dict[RTsbVE9CiQt]['0']
			title = A5AMg7LY1HlOz0B82n+' : '+name
			if type=='FILTERS': VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,url,354,'','',QQIzTLCXyhtZ7pRNnGq)
			elif type=='CATEGORIES' and vIZKhbfsXmWAyUVecrNOz95LQ[-2]+'=' in H2HMwT4JFz7rDkPZmRjcX:
				woj78rBnbLlmZWIy19iPHFCf5 = BrbZhHKJ0jnIe2lumE9M(DoSfCckGA9BQe,'all')
				QAKdHzO0rehbtyIc = url+'?'+woj78rBnbLlmZWIy19iPHFCf5
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,QAKdHzO0rehbtyIc,351,'','1')
			else: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,url,355,'','',QQIzTLCXyhtZ7pRNnGq)
	return
def BrbZhHKJ0jnIe2lumE9M(PPebqkulZUsx3GCLdnYvR,mode):
	PPebqkulZUsx3GCLdnYvR = PPebqkulZUsx3GCLdnYvR.strip('&')
	mVSjqdOvyf = {}
	if '=' in PPebqkulZUsx3GCLdnYvR:
		items = PPebqkulZUsx3GCLdnYvR.split('&')
		for ZA1fBenNahOR3xrkjvwYSVMy6JK5s in items:
			nmqEj60bcdSQoFPGa,WoFrX46wzbCNp18 = ZA1fBenNahOR3xrkjvwYSVMy6JK5s.split('=')
			mVSjqdOvyf[nmqEj60bcdSQoFPGa] = WoFrX46wzbCNp18
	DidZH6E0pJelcU9xMCBgyL2KvR = ''
	lWF7u5qUtSak3B = ['cat','genre','release-year','quality','orderby']
	for key in lWF7u5qUtSak3B:
		if key in list(mVSjqdOvyf.keys()): WoFrX46wzbCNp18 = mVSjqdOvyf[key]
		else: WoFrX46wzbCNp18 = '0'
		if mode=='modified_values' and WoFrX46wzbCNp18!='0': DidZH6E0pJelcU9xMCBgyL2KvR = DidZH6E0pJelcU9xMCBgyL2KvR+' + '+WoFrX46wzbCNp18
		elif mode=='modified_filters' and WoFrX46wzbCNp18!='0': DidZH6E0pJelcU9xMCBgyL2KvR = DidZH6E0pJelcU9xMCBgyL2KvR+'&'+key+'='+WoFrX46wzbCNp18
		elif mode=='all': DidZH6E0pJelcU9xMCBgyL2KvR = DidZH6E0pJelcU9xMCBgyL2KvR+'&'+key+'='+WoFrX46wzbCNp18
	DidZH6E0pJelcU9xMCBgyL2KvR = DidZH6E0pJelcU9xMCBgyL2KvR.strip(' + ')
	DidZH6E0pJelcU9xMCBgyL2KvR = DidZH6E0pJelcU9xMCBgyL2KvR.strip('&')
	return DidZH6E0pJelcU9xMCBgyL2KvR
# -*- coding: utf-8 -*-
import sys as ehpURIi6QBDOGu8qj5EYzXrsWHJ7
hEJlvpt9LRO = ehpURIi6QBDOGu8qj5EYzXrsWHJ7.version_info [0] == 2
RrwvuxJ2OXsWnE9fzYNPDqS = 2048
pS1kDZ93ogBi50Hm7elLhEcyFfTx = 7
def E6Xo0wuA9fdQKlGOI (Ovquk0bMSPEL1ciQ73BJ2Ae):
	global Xb8HYvTBqV5RFAhE3KwMjC
	G4LMt9nR3Se6xWNpPuJd = ord (Ovquk0bMSPEL1ciQ73BJ2Ae [-1])
	qkDvfXryhi7cSz5Ee4AtVn0 = Ovquk0bMSPEL1ciQ73BJ2Ae [:-1]
	FEcyWfSHeL5Kotpx = G4LMt9nR3Se6xWNpPuJd % len (qkDvfXryhi7cSz5Ee4AtVn0)
	FPhirCoHEGw3I05B = qkDvfXryhi7cSz5Ee4AtVn0 [:FEcyWfSHeL5Kotpx] + qkDvfXryhi7cSz5Ee4AtVn0 [FEcyWfSHeL5Kotpx:]
	if hEJlvpt9LRO:
		ffWep5hGgyVTXHL1SM = unicode () .join ([unichr (ord (DDX7Qar0kqlIAKHdwnEh) - RrwvuxJ2OXsWnE9fzYNPDqS - (XapSRJwDcy5TEK0QHZr6n + G4LMt9nR3Se6xWNpPuJd) % pS1kDZ93ogBi50Hm7elLhEcyFfTx) for XapSRJwDcy5TEK0QHZr6n, DDX7Qar0kqlIAKHdwnEh in enumerate (FPhirCoHEGw3I05B)])
	else:
		ffWep5hGgyVTXHL1SM = str () .join ([chr (ord (DDX7Qar0kqlIAKHdwnEh) - RrwvuxJ2OXsWnE9fzYNPDqS - (XapSRJwDcy5TEK0QHZr6n + G4LMt9nR3Se6xWNpPuJd) % pS1kDZ93ogBi50Hm7elLhEcyFfTx) for XapSRJwDcy5TEK0QHZr6n, DDX7Qar0kqlIAKHdwnEh in enumerate (FPhirCoHEGw3I05B)])
	return eval (ffWep5hGgyVTXHL1SM)
fY5wTlhtnOc0Er6sdy4k87b,C2jP0iLNGKnHu9xp,UnWjVbo503mEMv9KF=E6Xo0wuA9fdQKlGOI,E6Xo0wuA9fdQKlGOI,E6Xo0wuA9fdQKlGOI
jx7s8T0BFgODXLMzIYedf,UxS67uoGThbMwnfNRzy4gajLd23JH,QynMHGWA0blfqTUdxRh5Jzi2t=UnWjVbo503mEMv9KF,C2jP0iLNGKnHu9xp,fY5wTlhtnOc0Er6sdy4k87b
jSu5Cg2Ub1OAkZVs8Yoz,V2RbfGOBdcA6l8NTsPWzEyvS7,LgpdP3UjFRnlX=QynMHGWA0blfqTUdxRh5Jzi2t,UxS67uoGThbMwnfNRzy4gajLd23JH,jx7s8T0BFgODXLMzIYedf
gItVahxL0w,BmcLzCFjuIrZP5fwXH18aN6YS,qbPw1d3KimF=LgpdP3UjFRnlX,V2RbfGOBdcA6l8NTsPWzEyvS7,jSu5Cg2Ub1OAkZVs8Yoz
EAc8h2sINroQYvR3WH06Ji7MVpn,vvHpKfcqRnrFzjG,l0WAe1f7Bpi5ZXk=qbPw1d3KimF,BmcLzCFjuIrZP5fwXH18aN6YS,gItVahxL0w
YB5xyI7MaRslVpv,PPNA7jWqZgDnXKVvtuai1kQdsEoMb0,BK9OvRSjZbtx7kYyop1u6zrE2QeiFI=l0WAe1f7Bpi5ZXk,vvHpKfcqRnrFzjG,EAc8h2sINroQYvR3WH06Ji7MVpn
sRth5giAQzWlEVm7JOX,WMkAjB1RgN7q,NVS30xAdRFMIw1n9CislkE2=BK9OvRSjZbtx7kYyop1u6zrE2QeiFI,PPNA7jWqZgDnXKVvtuai1kQdsEoMb0,YB5xyI7MaRslVpv
NB6ZDMqe91yfKQ240WpbIntjxiY5z,k5dztomYyN3H,T6wRistc1SCo4hqObgumK=NVS30xAdRFMIw1n9CislkE2,WMkAjB1RgN7q,sRth5giAQzWlEVm7JOX
RqldvxFuM5GEQ2HAz93o7afBb0,rbjsM8cRFiuA1,nr5mZG89ICi6cgt4MfLJa0=T6wRistc1SCo4hqObgumK,k5dztomYyN3H,NB6ZDMqe91yfKQ240WpbIntjxiY5z
hhlbF1Sns5TrEN8QPCYmL4,FGDJwkEbTB5SoXujs3f,BoWHNb9daQVCF16A=nr5mZG89ICi6cgt4MfLJa0,rbjsM8cRFiuA1,RqldvxFuM5GEQ2HAz93o7afBb0
v5EA6TqHX3s4jzBMk,C2dgEDAKQGsvh,b05yftsZ6NYgIKP=BoWHNb9daQVCF16A,FGDJwkEbTB5SoXujs3f,hhlbF1Sns5TrEN8QPCYmL4
from G6AHskJeqN import *
baNWS6nfqTC5iX4Kl = BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠫࡈࡒࡅࡂࡐࡈࡖࠬࠀ")
teUPLFC3B8bArakwHVGsdhoIWDM49f = PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠬࡥࡃࡍࡐࡢࠫࠁ")
sWwi50jqNdcyEvUnxl8kKF49Qr = XXRtDhYvWb35qnLBxIri7ScNUks0.path.join(plygqUwWMPVORX0LYtejNDr8GI6bnK,UxS67uoGThbMwnfNRzy4gajLd23JH(u"࠭ࡴࡦ࡯ࡳࠫࠂ"))
ZZa8dBG1cigyRlpqsoEfSP5mb = XXRtDhYvWb35qnLBxIri7ScNUks0.path.join(plygqUwWMPVORX0LYtejNDr8GI6bnK,gItVahxL0w(u"ࠧࡱࡣࡦ࡯ࡦ࡭ࡥࡴࠩࠃ"))
VVn0ry1DJPTqLiWA = XXRtDhYvWb35qnLBxIri7ScNUks0.path.join(gK53PXkR96t7djpHeqEyL0,YB5xyI7MaRslVpv(u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪࠄ"),UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠩࡗ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡸ࠭ࠅ"))
PKHXG7MhI2uy13LfpTtkQsdzBqjv8 = o1oN28gvAMLw5az
w9z4E3FBC50vTQS6qKJd = jx7s8T0BFgODXLMzIYedf(u"ࠪ࠳ࡩࡧࡴࡢ࠱ࡶࡽࡸࡺࡥ࡮࠱ࡸࡷࡦ࡭ࡥࡴࡶࡤࡸࡸ࠭ࠆ")
tKUPMhHNIbpR9ucj34A = nr5mZG89ICi6cgt4MfLJa0(u"ࠫ࠴ࡪࡡࡵࡣ࠲ࡷࡾࡹࡴࡦ࡯࠲ࡨࡷࡵࡰࡣࡱࡻࠫࠇ")
GhRObnaBT1gq54EcxyvwMs = gItVahxL0w(u"ࠬ࠵ࡤࡢࡶࡤ࠳ࡹࡵ࡭ࡣࡵࡷࡳࡳ࡫ࡳࠨࠈ")
OV8twIrXxaks = BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠭࠯ࡥࡣࡷࡥ࠴ࡲ࡯ࡨࡩࡨࡶࠬࠉ")
BBW0YfOEX1o5ki3NDwMledjIcHZ4Gq = hhlbF1Sns5TrEN8QPCYmL4(u"ࠧ࠰ࡦࡤࡸࡦ࠵࡬ࡰࡩࠪࠊ")
vcWqDTaesoV = nr5mZG89ICi6cgt4MfLJa0(u"ࠨ࠱ࡧࡥࡹࡧ࠯ࡢࡰࡵࠫࠋ")
def VbgEajY4Bt2COpGDcPqI(H3HDqY5N4e0fWSXMikZ8CR7suUmJdx):
	if   H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==k5dztomYyN3H(u"࠹࠷࠴ࣉ"): ft3e2JBKQVXWlFPjaMhkEqGxvDg = nnF6UCaj7QwS2XhkRJ9MBEpDsml()
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==qbPw1d3KimF(u"࠺࠸࠶࣊"): ft3e2JBKQVXWlFPjaMhkEqGxvDg = SSRbfdTHKi1ngDyzeGt5X(sWwi50jqNdcyEvUnxl8kKF49Qr,UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࡖࡵࡹࡪࣳ"),UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࡖࡵࡹࡪࣳ"))
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==qbPw1d3KimF(u"࠻࠹࠸࣋"): ft3e2JBKQVXWlFPjaMhkEqGxvDg = SSRbfdTHKi1ngDyzeGt5X(ZZa8dBG1cigyRlpqsoEfSP5mb,hhlbF1Sns5TrEN8QPCYmL4(u"ࡗࡶࡺ࡫ࣴ"),hhlbF1Sns5TrEN8QPCYmL4(u"ࡗࡶࡺ࡫ࣴ"))
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==UxS67uoGThbMwnfNRzy4gajLd23JH(u"࠼࠺࠳࣌"): ft3e2JBKQVXWlFPjaMhkEqGxvDg = SSRbfdTHKi1ngDyzeGt5X(VVn0ry1DJPTqLiWA,gItVahxL0w(u"ࡋࡧ࡬ࡴࡧࣶ"),v5EA6TqHX3s4jzBMk(u"ࡘࡷࡻࡥࣵ"))
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==k5dztomYyN3H(u"࠽࠴࠵࣍"): ft3e2JBKQVXWlFPjaMhkEqGxvDg = ZsLbeUT14fmYO(PKHXG7MhI2uy13LfpTtkQsdzBqjv8,sRth5giAQzWlEVm7JOX(u"࡚ࡲࡶࡧࣷ"))
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==k5dztomYyN3H(u"࠷࠵࠷࣎"): ft3e2JBKQVXWlFPjaMhkEqGxvDg = PB5Tvzr9cySqQlwmU2uf03t67sDM(C2dgEDAKQGsvh(u"ࡔࡳࡷࡨࣸ"))
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==T6wRistc1SCo4hqObgumK(u"࠸࠷࠳࣏"): ft3e2JBKQVXWlFPjaMhkEqGxvDg = T6CQeEJ0NLFDfGrWX4UAi()
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠹࠸࠵࣐"): ft3e2JBKQVXWlFPjaMhkEqGxvDg = SSRbfdTHKi1ngDyzeGt5X(w9z4E3FBC50vTQS6qKJd,T6wRistc1SCo4hqObgumK(u"ࡈࡤࡰࡸ࡫ࣺ"),EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࡕࡴࡸࡩࣹ"))
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==NVS30xAdRFMIw1n9CislkE2(u"࠺࠹࠷࣑"): ft3e2JBKQVXWlFPjaMhkEqGxvDg = SSRbfdTHKi1ngDyzeGt5X(tKUPMhHNIbpR9ucj34A,C2dgEDAKQGsvh(u"ࡊࡦࡲࡳࡦࣼ"),PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࡗࡶࡺ࡫ࣻ"))
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==C2dgEDAKQGsvh(u"࠻࠺࠹࣒"): ft3e2JBKQVXWlFPjaMhkEqGxvDg = SSRbfdTHKi1ngDyzeGt5X(GhRObnaBT1gq54EcxyvwMs,gItVahxL0w(u"ࡌࡡ࡭ࡵࡨࣾ"),qbPw1d3KimF(u"࡙ࡸࡵࡦࣽ"))
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==rbjsM8cRFiuA1(u"࠼࠻࠴࣓"): ft3e2JBKQVXWlFPjaMhkEqGxvDg = SSRbfdTHKi1ngDyzeGt5X(OV8twIrXxaks,fY5wTlhtnOc0Er6sdy4k87b(u"ࡇࡣ࡯ࡷࡪऀ"),LgpdP3UjFRnlX(u"ࡔࡳࡷࡨࣿ"))
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠽࠵࠶ࣔ"): ft3e2JBKQVXWlFPjaMhkEqGxvDg = SSRbfdTHKi1ngDyzeGt5X(BBW0YfOEX1o5ki3NDwMledjIcHZ4Gq,BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࡉࡥࡱࡹࡥं"),LgpdP3UjFRnlX(u"ࡖࡵࡹࡪँ"))
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==LgpdP3UjFRnlX(u"࠷࠶࠸ࣕ"): ft3e2JBKQVXWlFPjaMhkEqGxvDg = SSRbfdTHKi1ngDyzeGt5X(vcWqDTaesoV,v5EA6TqHX3s4jzBMk(u"ࡋࡧ࡬ࡴࡧऄ"),rbjsM8cRFiuA1(u"ࡘࡷࡻࡥः"))
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==BmcLzCFjuIrZP5fwXH18aN6YS(u"࠸࠷࠺ࣖ"): ft3e2JBKQVXWlFPjaMhkEqGxvDg = Wn8pNQiUJzm1(jSu5Cg2Ub1OAkZVs8Yoz(u"࡚ࡲࡶࡧअ"))
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==YB5xyI7MaRslVpv(u"࠹࠸࠼ࣗ"): ft3e2JBKQVXWlFPjaMhkEqGxvDg = e6HOjDstnZ()
	else: ft3e2JBKQVXWlFPjaMhkEqGxvDg = C2jP0iLNGKnHu9xp(u"ࡆࡢ࡮ࡶࡩआ")
	return ft3e2JBKQVXWlFPjaMhkEqGxvDg
def nnF6UCaj7QwS2XhkRJ9MBEpDsml():
	bas9HiKEup80,KaNH53jqsdTylFh = hhrCT5bUynimj(sWwi50jqNdcyEvUnxl8kKF49Qr)
	kH3YvdULJ0iy2thnMbKIGs8AT,y1yHIOTgXVAGmhjdQ8rEL3CxKWF = hhrCT5bUynimj(ZZa8dBG1cigyRlpqsoEfSP5mb)
	YhqDnLTFVi6W0yj9c,H0qmxGO3CNSnoVh1A5weaTF = hhrCT5bUynimj(VVn0ry1DJPTqLiWA)
	ckL0oUTBEh9M48greq7,P45Vb1ywQMCdZrTnpFXJKqmjRHSvks = SIG93nyQ6qCPRdkwijWlsM(PKHXG7MhI2uy13LfpTtkQsdzBqjv8)
	ckL0oUTBEh9M48greq7 -= UnWjVbo503mEMv9KF(u"࠶࠺࠽࠼࠴ࣘ")
	P45Vb1ywQMCdZrTnpFXJKqmjRHSvks -= v5EA6TqHX3s4jzBMk(u"࠵ࣙ")
	QponsFKtGr9McgBRIW = jx7s8T0BFgODXLMzIYedf(u"ࠩࠣࠬࠬࠌ")+o3VAPzh2wcs8byM1EeSWO(bas9HiKEup80)+nr5mZG89ICi6cgt4MfLJa0(u"ࠪࠤ࠲ࠦࠧࠍ")+str(KaNH53jqsdTylFh)+fY5wTlhtnOc0Er6sdy4k87b(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬࠎ")
	ty842nqSiZglc6GoEPdTMAjLvRBOxm = T6wRistc1SCo4hqObgumK(u"ࠬࠦࠨࠨࠏ")+o3VAPzh2wcs8byM1EeSWO(kH3YvdULJ0iy2thnMbKIGs8AT)+vvHpKfcqRnrFzjG(u"࠭ࠠ࠮ࠢࠪࠐ")+str(y1yHIOTgXVAGmhjdQ8rEL3CxKWF)+fY5wTlhtnOc0Er6sdy4k87b(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨࠑ")
	w8WimcjhaYC63GE4ot9g05 = LgpdP3UjFRnlX(u"ࠨࠢࠫࠫࠒ")+o3VAPzh2wcs8byM1EeSWO(YhqDnLTFVi6W0yj9c)+EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠩࠣ࠱ࠥ࠭ࠓ")+str(H0qmxGO3CNSnoVh1A5weaTF)+T6wRistc1SCo4hqObgumK(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࠔ")
	Oo4nZJDa3ldX5I0h6ezkL = v5EA6TqHX3s4jzBMk(u"ࠫࠥ࠮ࠧࠕ")+o3VAPzh2wcs8byM1EeSWO(ckL0oUTBEh9M48greq7)+T6wRistc1SCo4hqObgumK(u"ࠬ࠯ࠧࠖ")
	DlVeTymZPB68wv = bas9HiKEup80+kH3YvdULJ0iy2thnMbKIGs8AT+YhqDnLTFVi6W0yj9c+ckL0oUTBEh9M48greq7
	e3tYvEisRnJpNc5 = KaNH53jqsdTylFh+y1yHIOTgXVAGmhjdQ8rEL3CxKWF+H0qmxGO3CNSnoVh1A5weaTF+P45Vb1ywQMCdZrTnpFXJKqmjRHSvks
	Gfsr6KpyVRovQmB8xcXUJ = YB5xyI7MaRslVpv(u"࠭ࠠࠩࠩࠗ")+o3VAPzh2wcs8byM1EeSWO(DlVeTymZPB68wv)+BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠧࠡ࠯ࠣࠫ࠘")+str(e3tYvEisRnJpNc5)+l0WAe1f7Bpi5ZXk(u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩ࠙")
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX(sRth5giAQzWlEVm7JOX(u"ࠩ࡯࡭ࡳࡱࠧࠚ"),teUPLFC3B8bArakwHVGsdhoIWDM49f+C2dgEDAKQGsvh(u"ุ้ࠪำࠠศๆฯ้๏฿ࠧࠛ")+Gfsr6KpyVRovQmB8xcXUJ,v5EA6TqHX3s4jzBMk(u"ࠫࠬࠜ"),YB5xyI7MaRslVpv(u"࠼࠺࠵ࣚ"))
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX(FGDJwkEbTB5SoXujs3f(u"ࠬࡲࡩ࡯࡭ࠪࠝ"),C2jP0iLNGKnHu9xp(u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨࠞ"),sRth5giAQzWlEVm7JOX(u"ࠧࠨࠟ"),vvHpKfcqRnrFzjG(u"࠿࠹࠺࠻ࣛ"))
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX(sRth5giAQzWlEVm7JOX(u"ࠨ࡮࡬ࡲࡰ࠭ࠠ"),teUPLFC3B8bArakwHVGsdhoIWDM49f+YB5xyI7MaRslVpv(u"่ࠩืาࠦวๅ็็ๅฬะࠠศๆ่ศ็ะษࠨࠡ")+QponsFKtGr9McgBRIW,fY5wTlhtnOc0Er6sdy4k87b(u"ࠪࠫࠢ"),hhlbF1Sns5TrEN8QPCYmL4(u"࠷࠵࠳ࣜ"))
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX(WMkAjB1RgN7q(u"ࠫࡱ࡯࡮࡬ࠩࠣ"),teUPLFC3B8bArakwHVGsdhoIWDM49f+BoWHNb9daQVCF16A(u"๋ࠬำฮࠢส่๊๊แศฬࠣห้๋ึ฻ฺ๊อࠬࠤ")+ty842nqSiZglc6GoEPdTMAjLvRBOxm,vvHpKfcqRnrFzjG(u"࠭ࠧࠥ"),jSu5Cg2Ub1OAkZVs8Yoz(u"࠸࠶࠵ࣝ"))
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX(qbPw1d3KimF(u"ࠧ࡭࡫ࡱ࡯ࠬࠦ"),teUPLFC3B8bArakwHVGsdhoIWDM49f+NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠨ็ึัࠥอไึ๊ิࠤฬ๊โะ์่อࠬࠧ")+w8WimcjhaYC63GE4ot9g05,v5EA6TqHX3s4jzBMk(u"ࠩࠪࠨ"),NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠹࠷࠷ࣞ"))
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX(NVS30xAdRFMIw1n9CislkE2(u"ࠪࡰ࡮ࡴ࡫ࠨࠩ"),teUPLFC3B8bArakwHVGsdhoIWDM49f+T6wRistc1SCo4hqObgumK(u"ࠫฯ็ั๋฼้้ࠣ็ࠠึ๊ิࠤฬ๊ลืษไหฯ࠭ࠪ")+Oo4nZJDa3ldX5I0h6ezkL,C2jP0iLNGKnHu9xp(u"ࠬ࠭ࠫ"),v5EA6TqHX3s4jzBMk(u"࠺࠸࠹ࣟ"))
	bLEBi8IO7uU2x3htYDdVq95.setSetting(PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡵࡩ࡫ࡸࡥࡴࡪࠪࠬ"),C2jP0iLNGKnHu9xp(u"ࠧࠨ࠭"))
	return
def T6CQeEJ0NLFDfGrWX4UAi():
	OWTkH94F8NVxAUjeX0EJwM = UnWjVbo503mEMv9KF(u"ࡖࡵࡹࡪई") if C2jP0iLNGKnHu9xp(u"ࠨ࠱ࠪ࠮") in gK53PXkR96t7djpHeqEyL0 else sRth5giAQzWlEVm7JOX(u"ࡇࡣ࡯ࡷࡪइ")
	if not OWTkH94F8NVxAUjeX0EJwM:
		ZIOHgA3z0TBR(YB5xyI7MaRslVpv(u"ࠩࠪ࠯"),BoWHNb9daQVCF16A(u"ࠪࠫ࠰"),fY5wTlhtnOc0Er6sdy4k87b(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ࠱"),BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠬ฿ๅๅ์ฬࠤฯ์ุ๋ใࠣห้า็ศิ้ࠣฯ๎แาหࠣๅ็฽ࠠๅลฯ๋ืฯ๋๊้ࠠ็ุࠦ࠮࠯๋ࠢะ์อาไࠢ็๎ุࠦๅ็้ࠢ์฾๊้่ࠦๆืࠬ࠲"))
		return
	zJwPBdKbhsfqD5vX = bLEBi8IO7uU2x3htYDdVq95.getSetting(vvHpKfcqRnrFzjG(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡵࡩ࡫ࡸࡥࡴࡪࠪ࠳"))
	if not zJwPBdKbhsfqD5vX: e6HOjDstnZ()
	bas9HiKEup80,KaNH53jqsdTylFh = hhrCT5bUynimj(w9z4E3FBC50vTQS6qKJd)
	kH3YvdULJ0iy2thnMbKIGs8AT,y1yHIOTgXVAGmhjdQ8rEL3CxKWF = hhrCT5bUynimj(tKUPMhHNIbpR9ucj34A)
	YhqDnLTFVi6W0yj9c,H0qmxGO3CNSnoVh1A5weaTF = hhrCT5bUynimj(GhRObnaBT1gq54EcxyvwMs)
	ckL0oUTBEh9M48greq7,P45Vb1ywQMCdZrTnpFXJKqmjRHSvks = hhrCT5bUynimj(OV8twIrXxaks)
	ZZz4W1JyGlkmL2AapwC8FrhQi,DtIMPsKXfzeB = hhrCT5bUynimj(BBW0YfOEX1o5ki3NDwMledjIcHZ4Gq)
	VRDZiGCvE1dfA,XXZP0upr83zme = hhrCT5bUynimj(vcWqDTaesoV)
	QponsFKtGr9McgBRIW = YB5xyI7MaRslVpv(u"ࠧࠡࠪࠪ࠴")+o3VAPzh2wcs8byM1EeSWO(bas9HiKEup80)+C2dgEDAKQGsvh(u"ࠨࠢ࠰ࠤࠬ࠵")+str(KaNH53jqsdTylFh)+hhlbF1Sns5TrEN8QPCYmL4(u"ࠩࠣࡪ࡮ࡲࡥࡴࠫࠪ࠶")
	ty842nqSiZglc6GoEPdTMAjLvRBOxm = BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠪࠤ࠭࠭࠷")+o3VAPzh2wcs8byM1EeSWO(kH3YvdULJ0iy2thnMbKIGs8AT)+FGDJwkEbTB5SoXujs3f(u"ࠫࠥ࠳ࠠࠨ࠸")+str(y1yHIOTgXVAGmhjdQ8rEL3CxKWF)+b05yftsZ6NYgIKP(u"ࠬࠦࡦࡪ࡮ࡨࡷ࠮࠭࠹")
	w8WimcjhaYC63GE4ot9g05 = nr5mZG89ICi6cgt4MfLJa0(u"࠭ࠠࠩࠩ࠺")+o3VAPzh2wcs8byM1EeSWO(YhqDnLTFVi6W0yj9c)+b05yftsZ6NYgIKP(u"ࠧࠡ࠯ࠣࠫ࠻")+str(H0qmxGO3CNSnoVh1A5weaTF)+vvHpKfcqRnrFzjG(u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩ࠼")
	Oo4nZJDa3ldX5I0h6ezkL = UnWjVbo503mEMv9KF(u"ࠩࠣࠬࠬ࠽")+o3VAPzh2wcs8byM1EeSWO(ckL0oUTBEh9M48greq7)+C2dgEDAKQGsvh(u"ࠪࠤ࠲ࠦࠧ࠾")+str(P45Vb1ywQMCdZrTnpFXJKqmjRHSvks)+BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬ࠿")
	Hxed64K85SOAqoTFPZcUfYX = NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠬࠦࠨࠨࡀ")+o3VAPzh2wcs8byM1EeSWO(ZZz4W1JyGlkmL2AapwC8FrhQi)+l0WAe1f7Bpi5ZXk(u"࠭ࠠ࠮ࠢࠪࡁ")+str(DtIMPsKXfzeB)+RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨࡂ")
	deFCk2Hnq9LmVg6ihu3Y = RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠨࠢࠫࠫࡃ")+o3VAPzh2wcs8byM1EeSWO(VRDZiGCvE1dfA)+jx7s8T0BFgODXLMzIYedf(u"ࠩࠣ࠱ࠥ࠭ࡄ")+str(XXZP0upr83zme)+k5dztomYyN3H(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࡅ")
	DlVeTymZPB68wv = bas9HiKEup80+kH3YvdULJ0iy2thnMbKIGs8AT+YhqDnLTFVi6W0yj9c+ckL0oUTBEh9M48greq7+ZZz4W1JyGlkmL2AapwC8FrhQi+VRDZiGCvE1dfA
	e3tYvEisRnJpNc5 = KaNH53jqsdTylFh+y1yHIOTgXVAGmhjdQ8rEL3CxKWF+H0qmxGO3CNSnoVh1A5weaTF+P45Vb1ywQMCdZrTnpFXJKqmjRHSvks+DtIMPsKXfzeB+XXZP0upr83zme
	Gfsr6KpyVRovQmB8xcXUJ = gItVahxL0w(u"ࠫࠥ࠮ࠧࡆ")+o3VAPzh2wcs8byM1EeSWO(DlVeTymZPB68wv)+QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠬࠦ࠭ࠡࠩࡇ")+str(e3tYvEisRnJpNc5)+v5EA6TqHX3s4jzBMk(u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧࡈ")
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX(nr5mZG89ICi6cgt4MfLJa0(u"ࠧ࡭࡫ࡱ࡯ࠬࡉ"),teUPLFC3B8bArakwHVGsdhoIWDM49f+l0WAe1f7Bpi5ZXk(u"ࠨว฼฻ฬวࠠาะุอ่ࠥัศรฬࠤํ้สศสฬࠫࡊ"),BoWHNb9daQVCF16A(u"ࠩࠪࡋ"),fY5wTlhtnOc0Er6sdy4k87b(u"࠻࠺࠾࣠"))
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX(LgpdP3UjFRnlX(u"ࠪࡰ࡮ࡴ࡫ࠨࡌ"),teUPLFC3B8bArakwHVGsdhoIWDM49f+NVS30xAdRFMIw1n9CislkE2(u"ู๊ࠫอࠡษ็ะ๊๐ูࠨࡍ")+Gfsr6KpyVRovQmB8xcXUJ,vvHpKfcqRnrFzjG(u"ࠬ࠭ࡎ"),nr5mZG89ICi6cgt4MfLJa0(u"࠼࠻࠷࣡"))
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX(NVS30xAdRFMIw1n9CislkE2(u"࠭࡬ࡪࡰ࡮ࠫࡏ"),vvHpKfcqRnrFzjG(u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩࡐ"),V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠨࠩࡑ"),C2dgEDAKQGsvh(u"࠿࠹࠺࠻࣢"))
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX(BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠩ࡯࡭ࡳࡱࠧࡒ"),teUPLFC3B8bArakwHVGsdhoIWDM49f+UnWjVbo503mEMv9KF(u"ุ้ࠪำࠠๆๆไหฯࠦࡵࡴࡣࡪࡩࡸࡺࡡࡵࡵࠪࡓ")+QponsFKtGr9McgBRIW,fY5wTlhtnOc0Er6sdy4k87b(u"ࠫࠬࡔ"),BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠷࠶࠳ࣣ"))
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX(WMkAjB1RgN7q(u"ࠬࡲࡩ࡯࡭ࠪࡕ"),teUPLFC3B8bArakwHVGsdhoIWDM49f+jSu5Cg2Ub1OAkZVs8Yoz(u"࠭ๅิฯ้้ࠣ็วหࠢࡧࡶࡴࡶࡢࡰࡺࠪࡖ")+ty842nqSiZglc6GoEPdTMAjLvRBOxm,jx7s8T0BFgODXLMzIYedf(u"ࠧࠨࡗ"),C2jP0iLNGKnHu9xp(u"࠸࠷࠵ࣤ"))
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX(nr5mZG89ICi6cgt4MfLJa0(u"ࠨ࡮࡬ࡲࡰ࠭ࡘ"),teUPLFC3B8bArakwHVGsdhoIWDM49f+V2RbfGOBdcA6l8NTsPWzEyvS7(u"่ࠩืาࠦๅๅใสฮࠥࡺ࡯࡮ࡤࡶࡸࡴࡴࡥࡴ࡙ࠩ")+w8WimcjhaYC63GE4ot9g05,C2jP0iLNGKnHu9xp(u"࡚ࠪࠫ"),qbPw1d3KimF(u"࠹࠸࠷ࣥ"))
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX(LgpdP3UjFRnlX(u"ࠫࡱ࡯࡮࡬࡛ࠩ"),teUPLFC3B8bArakwHVGsdhoIWDM49f+qbPw1d3KimF(u"๋ࠬำฮ่่ࠢๆอสࠡ࡮ࡲ࡫࡬࡫ࡲࠨ࡜")+Oo4nZJDa3ldX5I0h6ezkL,v5EA6TqHX3s4jzBMk(u"࠭ࠧ࡝"),vvHpKfcqRnrFzjG(u"࠺࠹࠹ࣦ"))
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX(BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠧ࡭࡫ࡱ࡯ࠬ࡞"),teUPLFC3B8bArakwHVGsdhoIWDM49f+LgpdP3UjFRnlX(u"ࠨ็ึั๋ࠥไโษอࠤࡱࡵࡧࠨ࡟")+Hxed64K85SOAqoTFPZcUfYX,T6wRistc1SCo4hqObgumK(u"ࠩࠪࡠ"),b05yftsZ6NYgIKP(u"࠻࠺࠻ࣧ"))
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX(NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠪࡰ࡮ࡴ࡫ࠨࡡ"),teUPLFC3B8bArakwHVGsdhoIWDM49f+k5dztomYyN3H(u"ู๊ࠫอࠡ็็ๅฬะࠠࡢࡰࡵࠫࡢ")+deFCk2Hnq9LmVg6ihu3Y,hhlbF1Sns5TrEN8QPCYmL4(u"ࠬ࠭ࡣ"),RqldvxFuM5GEQ2HAz93o7afBb0(u"࠼࠻࠶ࣨ"))
	bLEBi8IO7uU2x3htYDdVq95.setSetting(RqldvxFuM5GEQ2HAz93o7afBb0(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡵࡩ࡫ࡸࡥࡴࡪࠪࡤ"),jx7s8T0BFgODXLMzIYedf(u"ࠧࠨࡥ"))
	return
def e6HOjDstnZ():
	tLwvQlnjGpWsRVCN1 = mmwySO1P4jnKz5(C2dgEDAKQGsvh(u"ࠨࠩࡦ"),EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠩࠪࡧ"),gItVahxL0w(u"ࠪࠫࡨ"),k5dztomYyN3H(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧࡩ"),jx7s8T0BFgODXLMzIYedf(u"๊ࠬใ๋ࠢํ฽๊๊ࠠศๆอ๊฽๐แࠡ฻้ำ่ࠦ࠮࠯ࠢหี๋อๅอࠢ฼้ฬีࠠษฯสะฮࠦลๅ๋ࠣษ฾฽วยࠢิาฺฯࠠศๆๅีฬวษ๊ࠡส่่ะวษห่้๋ࠣไโษอࠤํอไๆฮ็ำฬะࠠศๆอ๎ู่ࠥโࠢํุ้ำ็ศࠢส่อืๆศ็ฯࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡว฼฻ฬว่ࠠา๊ࠤฬ๊ัฯืฬࠤฬ๊ย็ࠢยࠥࠬࡪ"))
	if tLwvQlnjGpWsRVCN1==-l0WAe1f7Bpi5ZXk(u"࠷ࣩ"): return
	if tLwvQlnjGpWsRVCN1:
		import subprocess as AWYxCeLTy0atb2pwV8XoEBkHv4d
		try:
			AWYxCeLTy0atb2pwV8XoEBkHv4d.Popen(RqldvxFuM5GEQ2HAz93o7afBb0(u"࠭ࡳࡶࠩ࡫"))
			SjWmql52xtbuoBZGw1TFDcJUkvf = PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࡗࡶࡺ࡫उ")
		except: SjWmql52xtbuoBZGw1TFDcJUkvf = sRth5giAQzWlEVm7JOX(u"ࡊࡦࡲࡳࡦऊ")
		if SjWmql52xtbuoBZGw1TFDcJUkvf:
			hTBFcCdyrjNIpUbz31MviGQm5sk = w9z4E3FBC50vTQS6qKJd+NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠧࠡࠩ࡬")+tKUPMhHNIbpR9ucj34A+C2dgEDAKQGsvh(u"ࠨࠢࠪ࡭")+GhRObnaBT1gq54EcxyvwMs+RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠩࠣࠫ࡮")+OV8twIrXxaks+V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠪࠤࠬ࡯")+BBW0YfOEX1o5ki3NDwMledjIcHZ4Gq+QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠫࠥ࠭ࡰ")+vcWqDTaesoV
			X5yVKAHIlYBR = AWYxCeLTy0atb2pwV8XoEBkHv4d.Popen(b05yftsZ6NYgIKP(u"ࠬࡹࡵࠡ࠯ࡦࠤࠧࡩࡨ࡮ࡱࡧࠤ࠲ࡘࠠ࠱࠹࠺࠻ࠥ࠭ࡱ")+hTBFcCdyrjNIpUbz31MviGQm5sk+BoWHNb9daQVCF16A(u"࠭ࠢࠨࡲ"),shell=rbjsM8cRFiuA1(u"࡙ࡸࡵࡦऋ"),stdin=AWYxCeLTy0atb2pwV8XoEBkHv4d.PIPE,stdout=AWYxCeLTy0atb2pwV8XoEBkHv4d.PIPE,stderr=AWYxCeLTy0atb2pwV8XoEBkHv4d.PIPE)
			ZIOHgA3z0TBR(UnWjVbo503mEMv9KF(u"ࠧࠨࡳ"),NVS30xAdRFMIw1n9CislkE2(u"ࠨࠩࡴ"),rbjsM8cRFiuA1(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬࡵ"),RqldvxFuM5GEQ2HAz93o7afBb0(u"๊ࠪัำสࠡ฻่่๏ฯࠠฦ฻ฺหฦࠦวๅำัูฮ࠭ࡶ"))
			bLEBi8IO7uU2x3htYDdVq95.setSetting(rbjsM8cRFiuA1(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡳࡧࡩࡶࡪࡹࡨࠨࡷ"),fY5wTlhtnOc0Er6sdy4k87b(u"࡙ࠬࡏࡎࡇࡗࡌࡎࡔࡇࠨࡸ"))
			tUXmK5PeEH9SDq.executebuiltin(fY5wTlhtnOc0Er6sdy4k87b(u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪࡹ"))
		else: ZIOHgA3z0TBR(v5EA6TqHX3s4jzBMk(u"ࠧࠨࡺ"),qbPw1d3KimF(u"ࠨࠩࡻ"),gItVahxL0w(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬࡼ"),sRth5giAQzWlEVm7JOX(u"ࠪ฽๊๊๊สࠢศ฽฼อมࠡำัูฮࠦวๅไิหฦฯ้ࠠษ็็ฯอศสࠢอัฯอฬࠡสิ๊ฬ๋ฬࠡࠢࡵࡳࡴࡺࠠࠡล๋ࠤࠥࡹࡵࡱࡧࡵࡹࡸ࡫ࡲࠡࠢฦ์ࠥࠦࡳࡶࠢࠣ์ัํวำๅ่ࠣฬ๊้ࠦฮาࠤๆ๐็้ࠡำหࠥอไษำ้ห๊าࠠ࠯࠰ࠣวํࠦใ้ัํࠤ฿๐ัࠡไสำึูࠦๅ๋ࠣหุะฮะษ่ࠤ์ึวࠡษ็ฬึ์วๆฮࠪࡽ"))
	return
def o3VAPzh2wcs8byM1EeSWO(DlVeTymZPB68wv):
	for PesMFvXRrd1 in [EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠫࡇ࠭ࡾ"),BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠬࡑࡂࠨࡿ"),YB5xyI7MaRslVpv(u"࠭ࡍࡃࠩࢀ"),hhlbF1Sns5TrEN8QPCYmL4(u"ࠧࡈࡄࠪࢁ"),C2jP0iLNGKnHu9xp(u"ࠨࡖࡅࠫࢂ")]:
		if DlVeTymZPB68wv<vvHpKfcqRnrFzjG(u"࠱࠱࠴࠷࣪"): break
		else: DlVeTymZPB68wv /= BmcLzCFjuIrZP5fwXH18aN6YS(u"࠲࠲࠵࠸࠳࠶࣫")
	Gfsr6KpyVRovQmB8xcXUJ = FGDJwkEbTB5SoXujs3f(u"ࠤࠨ࠷࠳࠷ࡦࠡࠧࡶࠦࢃ")%(DlVeTymZPB68wv,PesMFvXRrd1)
	return Gfsr6KpyVRovQmB8xcXUJ
def hhrCT5bUynimj(I9ujaoQJ1vV8es0tY=T6wRistc1SCo4hqObgumK(u"ࠪ࠲ࠬࢄ")):
	global QilxobqyPcrg6Ymef5hG,E3B8nIfD5ciypjZ94ObAv1P
	QilxobqyPcrg6Ymef5hG,E3B8nIfD5ciypjZ94ObAv1P = hhlbF1Sns5TrEN8QPCYmL4(u"࠲࣬"),hhlbF1Sns5TrEN8QPCYmL4(u"࠲࣬")
	def iazMKc4hUCOWbBYGLeZ3XDQ2(I9ujaoQJ1vV8es0tY):
		global QilxobqyPcrg6Ymef5hG,E3B8nIfD5ciypjZ94ObAv1P
		if XXRtDhYvWb35qnLBxIri7ScNUks0.path.exists(I9ujaoQJ1vV8es0tY):
			if nr5mZG89ICi6cgt4MfLJa0(u"࠳࣭") and EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠫࡸࡩࡡ࡯ࡦ࡬ࡶࠬࢅ") in dir(XXRtDhYvWb35qnLBxIri7ScNUks0):
				for lBVNPi5jkZnJLHh7z3wFTdxpUfom in XXRtDhYvWb35qnLBxIri7ScNUks0.scandir(I9ujaoQJ1vV8es0tY):
					if lBVNPi5jkZnJLHh7z3wFTdxpUfom.is_dir(follow_symlinks=V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࡌࡡ࡭ࡵࡨऌ")):
						iazMKc4hUCOWbBYGLeZ3XDQ2(lBVNPi5jkZnJLHh7z3wFTdxpUfom.path)
					elif lBVNPi5jkZnJLHh7z3wFTdxpUfom.is_file(follow_symlinks=NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࡆࡢ࡮ࡶࡩऍ")):
						QilxobqyPcrg6Ymef5hG += lBVNPi5jkZnJLHh7z3wFTdxpUfom.stat().st_size
						E3B8nIfD5ciypjZ94ObAv1P += RqldvxFuM5GEQ2HAz93o7afBb0(u"࠵࣮")
			else:
				for lBVNPi5jkZnJLHh7z3wFTdxpUfom in XXRtDhYvWb35qnLBxIri7ScNUks0.listdir(I9ujaoQJ1vV8es0tY):
					ucwkq5lERhZUgxeYQtpMTr0F6LX = XXRtDhYvWb35qnLBxIri7ScNUks0.path.abspath(XXRtDhYvWb35qnLBxIri7ScNUks0.path.join(I9ujaoQJ1vV8es0tY,lBVNPi5jkZnJLHh7z3wFTdxpUfom))
					if XXRtDhYvWb35qnLBxIri7ScNUks0.path.isdir(ucwkq5lERhZUgxeYQtpMTr0F6LX):
						iazMKc4hUCOWbBYGLeZ3XDQ2(ucwkq5lERhZUgxeYQtpMTr0F6LX)
					elif XXRtDhYvWb35qnLBxIri7ScNUks0.path.isfile(ucwkq5lERhZUgxeYQtpMTr0F6LX):
						DlVeTymZPB68wv,e3tYvEisRnJpNc5 = SIG93nyQ6qCPRdkwijWlsM(ucwkq5lERhZUgxeYQtpMTr0F6LX)
						QilxobqyPcrg6Ymef5hG += DlVeTymZPB68wv
						E3B8nIfD5ciypjZ94ObAv1P += e3tYvEisRnJpNc5
		return
	try: iazMKc4hUCOWbBYGLeZ3XDQ2(I9ujaoQJ1vV8es0tY)
	except: pass
	return QilxobqyPcrg6Ymef5hG,E3B8nIfD5ciypjZ94ObAv1P
def SSNfMTtxG45pJyPBFzIKqQ2eamgVh(o75gtPKAYyk,showDialogs):
	if showDialogs:
		tLwvQlnjGpWsRVCN1 = mmwySO1P4jnKz5(T6wRistc1SCo4hqObgumK(u"ࠬ࠭ࢆ"),RqldvxFuM5GEQ2HAz93o7afBb0(u"࠭ࠧࢇ"),v5EA6TqHX3s4jzBMk(u"ࠧࠨ࢈"),sRth5giAQzWlEVm7JOX(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫࢉ"),o75gtPKAYyk+BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠩ࡟ࡲࡡࡴࠧࢊ")+sRth5giAQzWlEVm7JOX(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢํไࠡฬิ๎ิࠦๅิฯ๋ࠣีอࠠศๆ่่ๆࠦฟࠢ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪࢋ"))
		if tLwvQlnjGpWsRVCN1!=nr5mZG89ICi6cgt4MfLJa0(u"࠶࣯"): return
	D2D7W0Imf5KaHncX4bEG8yviQYshV = V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࡇࡣ࡯ࡷࡪऎ")
	if XXRtDhYvWb35qnLBxIri7ScNUks0.path.exists(o75gtPKAYyk):
		try: XXRtDhYvWb35qnLBxIri7ScNUks0.remove(o75gtPKAYyk)
		except Exception as uuewWOtIk02Tgb3sdpSPnz:
			if showDialogs: ZIOHgA3z0TBR(jSu5Cg2Ub1OAkZVs8Yoz(u"ࠫࠬࢌ"),RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠬ࠭ࢍ"),rbjsM8cRFiuA1(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩࢎ"),str(uuewWOtIk02Tgb3sdpSPnz))
			D2D7W0Imf5KaHncX4bEG8yviQYshV = qbPw1d3KimF(u"ࡖࡵࡹࡪए")
	if showDialogs and not D2D7W0Imf5KaHncX4bEG8yviQYshV:
		ZIOHgA3z0TBR(jSu5Cg2Ub1OAkZVs8Yoz(u"ࠧࠨ࢏"),RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠨࠩ࢐"),YB5xyI7MaRslVpv(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ࢑"),PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠪฮ๊ࠦวๅ็ึัࠥฮๆอษะࠫ࢒"))
		bLEBi8IO7uU2x3htYDdVq95.setSetting(NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡳࡧࡩࡶࡪࡹࡨࠨ࢓"),UxS67uoGThbMwnfNRzy4gajLd23JH(u"࡙ࠬࡏࡎࡇࡗࡌࡎࡔࡇࠨ࢔"))
		tUXmK5PeEH9SDq.executebuiltin(LgpdP3UjFRnlX(u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪ࢕"))
	return
def PB5Tvzr9cySqQlwmU2uf03t67sDM(showDialogs):
	if showDialogs:
		tLwvQlnjGpWsRVCN1 = mmwySO1P4jnKz5(hhlbF1Sns5TrEN8QPCYmL4(u"ࠧࠨ࢖"),jSu5Cg2Ub1OAkZVs8Yoz(u"ࠨࠩࢗ"),PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠩࠪ࢘"),rbjsM8cRFiuA1(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࢙࠭"),BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣ็ๅࠢอี๏ีࠠๆีะ࢚ࠫ")+jSu5Cg2Ub1OAkZVs8Yoz(u"ࠬࡢ࡮ࠨ࢛")+jSu5Cg2Ub1OAkZVs8Yoz(u"࠭ๅอๆาࠤฬ๊ๅๅใสฮࠥอไๆฦๅฮฮࠦ࠮࠯๋้ࠢั๊ฯࠡษ็้้็วหࠢส่๊฼ฺู้ฬࠤ࠳࠴้ࠠ็ฯ่ิࠦวๅื๋ีࠥอไใัํ้ฮࠦ࠮࠯๋ࠢฮๆื๊฻่่ࠢๆࠦี้ำࠣห้หึศใสฮࠬ࢜")+hhlbF1Sns5TrEN8QPCYmL4(u"ࠧ࡝ࡰࠪ࢝")+RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠨมࠤࠥࠬ࢞")+nr5mZG89ICi6cgt4MfLJa0(u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ࢟"))
		if tLwvQlnjGpWsRVCN1!=k5dztomYyN3H(u"࠷ࣰ"): return
	SSRbfdTHKi1ngDyzeGt5X(sWwi50jqNdcyEvUnxl8kKF49Qr,BoWHNb9daQVCF16A(u"ࡘࡷࡻࡥऑ"),b05yftsZ6NYgIKP(u"ࡉࡥࡱࡹࡥऐ"))
	SSRbfdTHKi1ngDyzeGt5X(ZZa8dBG1cigyRlpqsoEfSP5mb,FGDJwkEbTB5SoXujs3f(u"࡚ࡲࡶࡧओ"),v5EA6TqHX3s4jzBMk(u"ࡋࡧ࡬ࡴࡧऒ"))
	SSRbfdTHKi1ngDyzeGt5X(VVn0ry1DJPTqLiWA,UnWjVbo503mEMv9KF(u"ࡆࡢ࡮ࡶࡩऔ"),UnWjVbo503mEMv9KF(u"ࡆࡢ࡮ࡶࡩऔ"))
	ZsLbeUT14fmYO(PKHXG7MhI2uy13LfpTtkQsdzBqjv8,sRth5giAQzWlEVm7JOX(u"ࡇࡣ࡯ࡷࡪक"))
	if showDialogs:
		ZIOHgA3z0TBR(WMkAjB1RgN7q(u"ࠪࠫࢠ"),vvHpKfcqRnrFzjG(u"ࠫࠬࢡ"),BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨࢢ"),BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠭สๆࠢสู่๊อࠡส้ะฬำࠧࢣ"))
		bLEBi8IO7uU2x3htYDdVq95.setSetting(EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡶࡪ࡬ࡲࡦࡵ࡫ࠫࢤ"),BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠨࡕࡒࡑࡊ࡚ࡈࡊࡐࡊࠫࢥ"))
		tUXmK5PeEH9SDq.executebuiltin(BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡘࡥࡧࡴࡨࡷ࡭࠭ࢦ"))
	return
def Wn8pNQiUJzm1(showDialogs):
	if showDialogs:
		tLwvQlnjGpWsRVCN1 = mmwySO1P4jnKz5(rbjsM8cRFiuA1(u"ࠪࠫࢧ"),BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠫࠬࢨ"),jx7s8T0BFgODXLMzIYedf(u"ࠬ࠭ࢩ"),EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩࢪ"),PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟๊่ࠥะั๋ัุ้ࠣำࠠๆๆไหฯ࠭ࢫ")+BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠨ࡞ࡱࠫࢬ")+PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠩࡸࡷࡦ࡭ࡥࡴࡶࡤࡸࡸࠦ࠮࠯ࠢࡧࡶࡴࡶࡢࡰࡺࠣ࠲࠳ࠦࡴࡰ࡯ࡥࡷࡹࡵ࡮ࡦࡵࠣ࠲࠳ࠦ࡬ࡰࡩࡪࡩࡷࠦ࠮࠯ࠢ࡯ࡳ࡬ࠦ࠮࠯ࠢࡤࡲࡷ࠭ࢭ")+FGDJwkEbTB5SoXujs3f(u"ࠪࡠࡳ࠭ࢮ")+QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠫࡄࠧࠡࠨࢯ")+C2dgEDAKQGsvh(u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧࢰ"))
		if tLwvQlnjGpWsRVCN1!=hhlbF1Sns5TrEN8QPCYmL4(u"࠱ࣱ"): return
	SSRbfdTHKi1ngDyzeGt5X(w9z4E3FBC50vTQS6qKJd,NVS30xAdRFMIw1n9CislkE2(u"ࡈࡤࡰࡸ࡫ख"),NVS30xAdRFMIw1n9CislkE2(u"ࡈࡤࡰࡸ࡫ख"))
	SSRbfdTHKi1ngDyzeGt5X(tKUPMhHNIbpR9ucj34A,C2jP0iLNGKnHu9xp(u"ࡉࡥࡱࡹࡥग"),C2jP0iLNGKnHu9xp(u"ࡉࡥࡱࡹࡥग"))
	SSRbfdTHKi1ngDyzeGt5X(GhRObnaBT1gq54EcxyvwMs,RqldvxFuM5GEQ2HAz93o7afBb0(u"ࡊࡦࡲࡳࡦघ"),RqldvxFuM5GEQ2HAz93o7afBb0(u"ࡊࡦࡲࡳࡦघ"))
	SSRbfdTHKi1ngDyzeGt5X(OV8twIrXxaks,PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࡋࡧ࡬ࡴࡧङ"),PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࡋࡧ࡬ࡴࡧङ"))
	SSRbfdTHKi1ngDyzeGt5X(BBW0YfOEX1o5ki3NDwMledjIcHZ4Gq,UnWjVbo503mEMv9KF(u"ࡌࡡ࡭ࡵࡨच"),UnWjVbo503mEMv9KF(u"ࡌࡡ࡭ࡵࡨच"))
	SSRbfdTHKi1ngDyzeGt5X(vcWqDTaesoV,EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࡆࡢ࡮ࡶࡩछ"),EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࡆࡢ࡮ࡶࡩछ"))
	if showDialogs:
		ZIOHgA3z0TBR(fY5wTlhtnOc0Er6sdy4k87b(u"࠭ࠧࢱ"),C2dgEDAKQGsvh(u"ࠧࠨࢲ"),hhlbF1Sns5TrEN8QPCYmL4(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫࢳ"),FGDJwkEbTB5SoXujs3f(u"ࠩอ้ࠥอไๆีะࠤอ์ฬศฯࠪࢴ"))
		bLEBi8IO7uU2x3htYDdVq95.setSetting(LgpdP3UjFRnlX(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡲࡦࡨࡵࡩࡸ࡮ࠧࢵ"),nr5mZG89ICi6cgt4MfLJa0(u"ࠫࡘࡕࡍࡆࡖࡋࡍࡓࡍࠧࢶ"))
		tUXmK5PeEH9SDq.executebuiltin(C2jP0iLNGKnHu9xp(u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠩࢷ"))
	return
def ZsLbeUT14fmYO(GTYRu9hVKZoHOyUt4w2ilpLqA,showDialogs):
	if showDialogs:
		tLwvQlnjGpWsRVCN1 = mmwySO1P4jnKz5(QynMHGWA0blfqTUdxRh5Jzi2t(u"࠭ࠧࢸ"),v5EA6TqHX3s4jzBMk(u"ࠧࠨࢹ"),QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠨࠩࢺ"),UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬࢻ"),k5dztomYyN3H(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢํไࠡฬิ๎ิࠦๅิฯ้ࠣาะ่๋ษอࠤ๊๊แࠡื๋ีࠥอไอๆาࠤฤࠧࠡࠨࢼ")+BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ࢽ"))
		if tLwvQlnjGpWsRVCN1!=jx7s8T0BFgODXLMzIYedf(u"࠲ࣲ"): return
	W9YiR1FGTdzO3jByXPA70D = LLuOT2NGmXvS4C1WRyod8sQtIhV70a.connect(GTYRu9hVKZoHOyUt4w2ilpLqA)
	W9YiR1FGTdzO3jByXPA70D.text_factory = str
	CCJpwYUsTN1cBIz5PH = W9YiR1FGTdzO3jByXPA70D.cursor()
	CCJpwYUsTN1cBIz5PH.execute(LgpdP3UjFRnlX(u"ࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࡴࡦࡺࡨ࠼ࠩࢾ"))
	CCJpwYUsTN1cBIz5PH.execute(nr5mZG89ICi6cgt4MfLJa0(u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࡸ࡯ࡺࡦࡵ࠾ࠫࢿ"))
	CCJpwYUsTN1cBIz5PH.execute(sRth5giAQzWlEVm7JOX(u"ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥࡺࡥࡹࡶࡸࡶࡪࡁࠧࣀ"))
	W9YiR1FGTdzO3jByXPA70D.commit()
	CCJpwYUsTN1cBIz5PH.execute(rbjsM8cRFiuA1(u"ࠨࡘࡄࡇ࡚࡛ࡍ࠼ࠩࣁ"))
	W9YiR1FGTdzO3jByXPA70D.close()
	if showDialogs:
		ZIOHgA3z0TBR(C2jP0iLNGKnHu9xp(u"ࠩࠪࣂ"),k5dztomYyN3H(u"ࠪࠫࣃ"),YB5xyI7MaRslVpv(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧࣄ"),vvHpKfcqRnrFzjG(u"ࠬะๅࠡษ็ุ้ำࠠษ่ฯหา࠭ࣅ"))
		bLEBi8IO7uU2x3htYDdVq95.setSetting(C2dgEDAKQGsvh(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡵࡩ࡫ࡸࡥࡴࡪࠪࣆ"),jx7s8T0BFgODXLMzIYedf(u"ࠧࡔࡑࡐࡉ࡙ࡎࡉࡏࡉࠪࣇ"))
		tUXmK5PeEH9SDq.executebuiltin(BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬ࠬࣈ"))
	return
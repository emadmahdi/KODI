# -*- coding: utf-8 -*-
from G6AHskJeqN import *
baNWS6nfqTC5iX4Kl = 'ARABSEED'
headers = {'User-Agent':IeSGolOpBHM8U62m()}
teUPLFC3B8bArakwHVGsdhoIWDM49f = '_ARS_'
EZxQp1WOldMTvFU = AK5RqLhji4W1wt9VdrCD3PGeQM[baNWS6nfqTC5iX4Kl][0]
eh2tDvRFWpLQI = ['الرئيسية','المضاف حديثاً','مصارعه','اعلن معنا – For ads','موبايلات','برامج كمبيوتر','العاب كمبيوتر','اسلاميات','اخرى','اقسام اخري','اشتراكات']
def VbgEajY4Bt2COpGDcPqI(mode,url,text):
	if   mode==250: ft3e2JBKQVXWlFPjaMhkEqGxvDg = eN02L7Tf5bQ()
	elif mode==251: ft3e2JBKQVXWlFPjaMhkEqGxvDg = sscM839DP1jWZ4zl6uIx0Kyn(url,text)
	elif mode==252: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HDxCnPKFhITpZmOsA4a0UL6(url)
	elif mode==253: ft3e2JBKQVXWlFPjaMhkEqGxvDg = o4oY13v5dWMcbilEDjKCnXNzHZ0(url)
	elif mode==254: ft3e2JBKQVXWlFPjaMhkEqGxvDg = LLJlTxDePyjoVKA(url,'CATEGORIES___'+text)
	elif mode==255: ft3e2JBKQVXWlFPjaMhkEqGxvDg = LLJlTxDePyjoVKA(url,'FILTERS___'+text)
	elif mode==256: ft3e2JBKQVXWlFPjaMhkEqGxvDg = M25iOAH9NfalvyPEUuToG8qn(url,text)
	elif mode==259: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HjZcUIVAXFCqy9TfBWKtgY2(text)
	else: ft3e2JBKQVXWlFPjaMhkEqGxvDg = False
	return ft3e2JBKQVXWlFPjaMhkEqGxvDg
def eN02L7Tf5bQ():
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(IIiPCruL6dT8s1lqj47SzpVHnYNm,'GET',EZxQp1WOldMTvFU+'/main','',headers,'','','ARABSEED-MENU-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'بحث في الموقع','',259,'','','_REMEMBERRESULTS_')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'فلتر محدد',EZxQp1WOldMTvFU+'/category/اخرى',254)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'فلتر كامل',EZxQp1WOldMTvFU+'/category/اخرى',255)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'المميزة',EZxQp1WOldMTvFU+'/main',251,'','','featured_main')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'جديد الأفلام',EZxQp1WOldMTvFU+'/main',251,'','','new_movies')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'جديد الحلقات',EZxQp1WOldMTvFU+'/main',251,'','','new_episodes')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'المضاف حديثاً',EZxQp1WOldMTvFU+'/latest',251,'','','lastest')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	kdYXhMN8Hpbt = My7Dwqvs6bfGNSIgX.findall('class="MenuHeader"(.*?)</div>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	iiBEzXVNFDhfj36 = kdYXhMN8Hpbt[0]
	zE1FBZLDvygwGdkef74lnRJVXCUqKH = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?>(.*?)<',iiBEzXVNFDhfj36,My7Dwqvs6bfGNSIgX.DOTALL)
	for BoEFz2WhUyvTgDeiZ,title in zE1FBZLDvygwGdkef74lnRJVXCUqKH:
		title = PIfAumbGicwg5ye(title)
		if title not in eh2tDvRFWpLQI and title!='':
			if 'http' not in BoEFz2WhUyvTgDeiZ: BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU+BoEFz2WhUyvTgDeiZ
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,256)
	return MK6ZT2zjC1SbmveNFqor
def M25iOAH9NfalvyPEUuToG8qn(url,type):
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'',headers,'','','ARABSEED-SUBMENU-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	if 'class="SliderInSection' in MK6ZT2zjC1SbmveNFqor: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'الأكثر مشاهدة',url,251,'','','most')
	if 'class="MainSlides' in MK6ZT2zjC1SbmveNFqor: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'المميزة',url,251,'','','featured')
	if 'class="LinksList' in MK6ZT2zjC1SbmveNFqor:
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('class="LinksList(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if XBuP6Op7y4K:
			vsptNMP2ZQC = XBuP6Op7y4K[0]
			if len(XBuP6Op7y4K)>1 and type=='new_episodes': vsptNMP2ZQC = XBuP6Op7y4K[1]
			items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)"(.*?)</a>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
			for BoEFz2WhUyvTgDeiZ,title in items:
				U2UaTcgBpsEZxKiRG1Xv8 = My7Dwqvs6bfGNSIgX.findall('</i>(.*?)<span>(.*?)<',title,My7Dwqvs6bfGNSIgX.DOTALL)
				try: TTLQDONupiB6q = U2UaTcgBpsEZxKiRG1Xv8[0][0].replace('\n','').strip(' ')
				except: TTLQDONupiB6q = ''
				try: kdizpIZj1fqeuPslGXF4y6gLESwTU = U2UaTcgBpsEZxKiRG1Xv8[0][1].replace('\n','').strip(' ')
				except: kdizpIZj1fqeuPslGXF4y6gLESwTU = ''
				U2UaTcgBpsEZxKiRG1Xv8 = TTLQDONupiB6q+' '+kdizpIZj1fqeuPslGXF4y6gLESwTU
				if '<strong>' in title:
					oVtD9zvkFegZa1S3q = My7Dwqvs6bfGNSIgX.findall('</i>(.*?)<',title,My7Dwqvs6bfGNSIgX.DOTALL)
					if oVtD9zvkFegZa1S3q: U2UaTcgBpsEZxKiRG1Xv8 = oVtD9zvkFegZa1S3q[0]
				if not U2UaTcgBpsEZxKiRG1Xv8:
					oVtD9zvkFegZa1S3q = My7Dwqvs6bfGNSIgX.findall('alt="(.*?)"',title,My7Dwqvs6bfGNSIgX.DOTALL)
					if oVtD9zvkFegZa1S3q: U2UaTcgBpsEZxKiRG1Xv8 = oVtD9zvkFegZa1S3q[0]
				if U2UaTcgBpsEZxKiRG1Xv8:
					if 'key=' in BoEFz2WhUyvTgDeiZ: type = BoEFz2WhUyvTgDeiZ.split('key=')[1]
					else: type = 'newest'
					U2UaTcgBpsEZxKiRG1Xv8 = U2UaTcgBpsEZxKiRG1Xv8.strip(' ')
					VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+U2UaTcgBpsEZxKiRG1Xv8,BoEFz2WhUyvTgDeiZ,251,'','',type)
	return
def sscM839DP1jWZ4zl6uIx0Kyn(url,type):
	IkMc3VWz5SHlDgxn2h94fUtj,data,items = 'GET','',[]
	if type=='filters':
		if '?' in url:
			Q8e7GvtsDJqZT,toAVQS46Fv8aJYyLf25KnkUNC = 'POST',{}
			bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,nIVjDQ0AwGaFqic6eRlxPNK3HOyWUS = url.split('?')
			p1GZLhkOD64IX = nIVjDQ0AwGaFqic6eRlxPNK3HOyWUS.split('&')
			for PcOUYpACoRnGhSWdiJV in p1GZLhkOD64IX:
				key,WoFrX46wzbCNp18 = PcOUYpACoRnGhSWdiJV.split('=')
				toAVQS46Fv8aJYyLf25KnkUNC[key] = WoFrX46wzbCNp18
			if p1GZLhkOD64IX: IkMc3VWz5SHlDgxn2h94fUtj,url,data = Q8e7GvtsDJqZT,bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,toAVQS46Fv8aJYyLf25KnkUNC
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,IkMc3VWz5SHlDgxn2h94fUtj,url,data,headers,'','','ARABSEED-TITLES-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	if type=='filters': XBuP6Op7y4K = [MK6ZT2zjC1SbmveNFqor]
	elif 'featured' in type: XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('class="MainSlides(.*?)class="LinksList',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	elif type=='new_movies': XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('جديد الافلام.*?class="SliderInSection"(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	elif type=='new_episodes': XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('جديد الحلقات.*?class="SliderInSection"(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	elif type=='most': XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('class="SliderInSection(.*?)class="LinksList',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	else: XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('class="Blocks-UL"(.*?)class="AboElSeed"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if 'featured' in type:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		hklGvBFSHupmAE5UVQ2zOcJ8 = My7Dwqvs6bfGNSIgX.findall('href="(.*?)" title="(.*?)".*?data-lazy.*? (src|data-image)="(.*?)"',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		if hklGvBFSHupmAE5UVQ2zOcJ8:
			QQ2cE1FjUyxPonbDhaTkV6B3i,wlfZEzuRyYLvrp,jPqWMSyKm4tpuzc3RIkiF1l,zY4Ib2VUSPeFEJMy9Rtij = zip(*hklGvBFSHupmAE5UVQ2zOcJ8)
			items = zip(QQ2cE1FjUyxPonbDhaTkV6B3i,zY4Ib2VUSPeFEJMy9Rtij,wlfZEzuRyYLvrp)
	else:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('LoadingArea.*? href="(.*?)".*? data-\w{3,5}="(.*?)".*? alt="(.*?)"',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	y7y3d5Fbhv42ONmtwLZ0SerYoQq = []
	for BoEFz2WhUyvTgDeiZ,IcWzVO137wFvemn2QTq8yKs9,title in items:
		if 'WWE' in title: continue
		title = PIfAumbGicwg5ye(title)
		if 'الحلقة' in title:
			ffhN7jAqe3Q4cR0Ukptzl = My7Dwqvs6bfGNSIgX.findall('(.*?) الحلقة \d+',title,My7Dwqvs6bfGNSIgX.DOTALL)
			if ffhN7jAqe3Q4cR0Ukptzl:
				title = '_MOD_' + ffhN7jAqe3Q4cR0Ukptzl[0]
				if title not in y7y3d5Fbhv42ONmtwLZ0SerYoQq:
					y7y3d5Fbhv42ONmtwLZ0SerYoQq.append(title)
					VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,253,IcWzVO137wFvemn2QTq8yKs9)
			else: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,252,IcWzVO137wFvemn2QTq8yKs9)
		elif '/selary/' in BoEFz2WhUyvTgDeiZ or 'مسلسل' in title:
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,253,IcWzVO137wFvemn2QTq8yKs9)
		else:
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,252,IcWzVO137wFvemn2QTq8yKs9)
	if type in ['newest','best','most']:
		items = My7Dwqvs6bfGNSIgX.findall('page-numbers" href="(.*?)">(.*?)<',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title in items:
			BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU+BoEFz2WhUyvTgDeiZ
			BoEFz2WhUyvTgDeiZ = PIfAumbGicwg5ye(BoEFz2WhUyvTgDeiZ)
			title = PIfAumbGicwg5ye(title)
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'صفحة '+title,BoEFz2WhUyvTgDeiZ,251,'','',type)
	return
def o4oY13v5dWMcbilEDjKCnXNzHZ0(url):
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'',headers,'','','ARABSEED-EPISODES-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	MK6ZT2zjC1SbmveNFqor = MK6ZT2zjC1SbmveNFqor[10000:]
	items = My7Dwqvs6bfGNSIgX.findall('data-src="(.*?)".*?alt="(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if not items: return
	IcWzVO137wFvemn2QTq8yKs9,name = items[0]
	if 'الحلقة' in name: name = name.split('الحلقة')[0].strip(' ')
	elif 'حلقة' in name: name = name.split('حلقة')[0].strip(' ')
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('class="ContainerEpisodesList"(.*?)</div>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?<em>(.*?)</em>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,ffhN7jAqe3Q4cR0Ukptzl in items:
			title = name+' - الحلقة رقم '+ffhN7jAqe3Q4cR0Ukptzl
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,252,IcWzVO137wFvemn2QTq8yKs9)
	else: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+'ملف التشغيل',url,252,IcWzVO137wFvemn2QTq8yKs9)
	return
def Q082RuzqDeZAk(title,BoEFz2WhUyvTgDeiZ):
	U2UaTcgBpsEZxKiRG1Xv8 = My7Dwqvs6bfGNSIgX.findall('[a-zA-Z-]+',title,My7Dwqvs6bfGNSIgX.DOTALL)
	if U2UaTcgBpsEZxKiRG1Xv8: title = U2UaTcgBpsEZxKiRG1Xv8[0]
	else: title = title+' '+ooq2D9xF8ZLpPBs(BoEFz2WhUyvTgDeiZ,'name')
	title = title.replace('عرب سيد','').replace('مباشر','').replace('مشاهدة','')
	title = title.replace('ٍ','')
	title = title.replace('  ',' ').replace('  ',' ')
	return title
def HDxCnPKFhITpZmOsA4a0UL6(url):
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(IIiPCruL6dT8s1lqj47SzpVHnYNm,'GET',url,'',headers,'','','ARABSEED-PLAY-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = xHb86g9WZqPwRfVjXD2JalzSIp.url
	LkVZrOE4XBSN2Qex5PyHqC = ooq2D9xF8ZLpPBs(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,'url')
	headers['Referer'] = LkVZrOE4XBSN2Qex5PyHqC+'/'
	mj6Sw8JteAr5zbsWic,u3uqSNbACv,QQ2cE1FjUyxPonbDhaTkV6B3i = '','',[]
	OSczuT518l7JKniXAPZyF = My7Dwqvs6bfGNSIgX.findall('class="WatchButtons".*?href="(.*?)" class="(watch.*?)".*?href="(.*?)" class="(download.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if OSczuT518l7JKniXAPZyF: mj6Sw8JteAr5zbsWic,FjDbpLOVQBJZToN,u3uqSNbACv,ssINGezFJnxfcU = OSczuT518l7JKniXAPZyF[0]
	else:
		OSczuT518l7JKniXAPZyF = My7Dwqvs6bfGNSIgX.findall('class="WatchButtons".*?href="(.*?)" class="(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if OSczuT518l7JKniXAPZyF:
			BoEFz2WhUyvTgDeiZ,FjDbpLOVQBJZToN = OSczuT518l7JKniXAPZyF[0]
			if 'watch' in FjDbpLOVQBJZToN: mj6Sw8JteAr5zbsWic = BoEFz2WhUyvTgDeiZ
			else: u3uqSNbACv = BoEFz2WhUyvTgDeiZ
	if mj6Sw8JteAr5zbsWic:
		xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(IIiPCruL6dT8s1lqj47SzpVHnYNm,'GET',mj6Sw8JteAr5zbsWic,'',headers,'','','ARABSEED-PLAY-2nd')
		MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('class="WatcherArea"(.*?</ul>)',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if XBuP6Op7y4K:
			PpfdgJWUnIRE3krDhKLbYs6w = XBuP6Op7y4K[0]
			PpfdgJWUnIRE3krDhKLbYs6w = PpfdgJWUnIRE3krDhKLbYs6w.replace('</ul>','<h3>')
			PpfdgJWUnIRE3krDhKLbYs6w = PpfdgJWUnIRE3krDhKLbYs6w.replace('<h3>','<h3><h3>')
			xAcIatGBYy0FLXroS1ig3Ts9KZ8P5 = My7Dwqvs6bfGNSIgX.findall('<h3>.*?(\d+)(.*?)<h3>',PpfdgJWUnIRE3krDhKLbYs6w,My7Dwqvs6bfGNSIgX.DOTALL)
			if not xAcIatGBYy0FLXroS1ig3Ts9KZ8P5: xAcIatGBYy0FLXroS1ig3Ts9KZ8P5 = [('',PpfdgJWUnIRE3krDhKLbYs6w)]
			for LLnUyuiC2wRM0,vsptNMP2ZQC in xAcIatGBYy0FLXroS1ig3Ts9KZ8P5:
				if LLnUyuiC2wRM0: LLnUyuiC2wRM0 = '____'+LLnUyuiC2wRM0
				items = My7Dwqvs6bfGNSIgX.findall('data-link="(.*?)".*?<span>(.*?)</span>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
				for BoEFz2WhUyvTgDeiZ,name in items:
					if 'http' not in BoEFz2WhUyvTgDeiZ: BoEFz2WhUyvTgDeiZ = 'http:'+BoEFz2WhUyvTgDeiZ
					BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ+'?named='+name+'__watch'+LLnUyuiC2wRM0
					QQ2cE1FjUyxPonbDhaTkV6B3i.append(BoEFz2WhUyvTgDeiZ)
		NVHrZsqUp2 = My7Dwqvs6bfGNSIgX.findall('class="containerIframe".*? src="(.*?)".*? height="(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if not NVHrZsqUp2: NVHrZsqUp2 = My7Dwqvs6bfGNSIgX.findall('class="containerIframe".*? SRC="(.*?)".*? HEIGHT="(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if NVHrZsqUp2:
			BoEFz2WhUyvTgDeiZ,LLnUyuiC2wRM0 = NVHrZsqUp2[0]
			name = ooq2D9xF8ZLpPBs(BoEFz2WhUyvTgDeiZ,'name')
			if '%' in LLnUyuiC2wRM0: BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ+'?named='+name+'__embed__'
			else: BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ+'?named='+name+'__embed____'+LLnUyuiC2wRM0
			QQ2cE1FjUyxPonbDhaTkV6B3i.append(BoEFz2WhUyvTgDeiZ)
	if u3uqSNbACv:
		xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(IIiPCruL6dT8s1lqj47SzpVHnYNm,'GET',u3uqSNbACv,'',headers,'','','ARABSEED-PLAY-3rd')
		MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('class="DownloadArea"(.*?)function',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if XBuP6Op7y4K:
			vsptNMP2ZQC = XBuP6Op7y4K[0]
			items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?<span>(.*?)</span>.*?<p>(.*?)</p>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
			for BoEFz2WhUyvTgDeiZ,title,LLnUyuiC2wRM0 in items:
				if not BoEFz2WhUyvTgDeiZ: continue
				if 'reviewstation' in BoEFz2WhUyvTgDeiZ: continue
				BoEFz2WhUyvTgDeiZ = XnQbsZF0Ouh8p7zCdUN(BoEFz2WhUyvTgDeiZ)
				BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ+'?named='+title+'__download____'+LLnUyuiC2wRM0
				QQ2cE1FjUyxPonbDhaTkV6B3i.append(BoEFz2WhUyvTgDeiZ)
	kz3oAXwjdLCPBIerf2E = str(QQ2cE1FjUyxPonbDhaTkV6B3i)
	Jv3hwKiE1tCxajp0dZF4Gm2ykXz = ['.zip?','.rar?','.txt?','.pdf?','.tar?','.iso?','.zip.','.rar.','.txt.','.pdf.','.tar.','.iso.']
	if any(WoFrX46wzbCNp18 in kz3oAXwjdLCPBIerf2E for WoFrX46wzbCNp18 in Jv3hwKiE1tCxajp0dZF4Gm2ykXz):
		ZIOHgA3z0TBR('','','رسالة من المبرمج','جرب رابط مختلف لأن هذا الرابط ليس من نوع الروابط التي فيها ملفات فيديو .. لأن هذا الموقع فيه خدمات أخرى غير ملفات الفيديو')
		return
	import t1kDWXQVpC
	t1kDWXQVpC.rqVt2xDi7jzJHBcPMRs6h0L(QQ2cE1FjUyxPonbDhaTkV6B3i,baNWS6nfqTC5iX4Kl,'video',url)
	return
def HjZcUIVAXFCqy9TfBWKtgY2(search):
	search,LQf3AeozSrai,showDialogs = X54MLovbG8nAEkB9J(search)
	if not search: search = ViKAIsLurq83RSENayxWb()
	if not search: return
	search = search.replace(' ','+')
	url = EZxQp1WOldMTvFU+'/find/?find='+search
	sscM839DP1jWZ4zl6uIx0Kyn(url,'search')
	return
def LLJlTxDePyjoVKA(url,filter):
	if '??' in url: url = url.split('//getposts??')[0]
	type,filter = filter.split('___',1)
	if filter=='': H2HMwT4JFz7rDkPZmRjcX,JPnr9ICqkDyV = '',''
	else: H2HMwT4JFz7rDkPZmRjcX,JPnr9ICqkDyV = filter.split('___')
	if type=='CATEGORIES':
		if kEaCuLOYxJQI7btFwzV3P[0]+'==' not in H2HMwT4JFz7rDkPZmRjcX: g4Y0BXLxCpuojKP1SAUtcq7TwN2 = kEaCuLOYxJQI7btFwzV3P[0]
		for FVW0I9sYcAjmDgn8r in range(len(kEaCuLOYxJQI7btFwzV3P[0:-1])):
			if kEaCuLOYxJQI7btFwzV3P[FVW0I9sYcAjmDgn8r]+'==' in H2HMwT4JFz7rDkPZmRjcX: g4Y0BXLxCpuojKP1SAUtcq7TwN2 = kEaCuLOYxJQI7btFwzV3P[FVW0I9sYcAjmDgn8r+1]
		HHXeMqVOshPcW3tULa5v = H2HMwT4JFz7rDkPZmRjcX+'&&'+g4Y0BXLxCpuojKP1SAUtcq7TwN2+'==0'
		DoSfCckGA9BQe = JPnr9ICqkDyV+'&&'+g4Y0BXLxCpuojKP1SAUtcq7TwN2+'==0'
		A7AEKRlF6Hf3eWVxY0NdwgsMPCc = HHXeMqVOshPcW3tULa5v.strip('&&')+'___'+DoSfCckGA9BQe.strip('&&')
		woj78rBnbLlmZWIy19iPHFCf5 = BrbZhHKJ0jnIe2lumE9M(JPnr9ICqkDyV,'modified_filters')
		bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = url+'//getposts??'+woj78rBnbLlmZWIy19iPHFCf5
	elif type=='FILTERS':
		WUSylLup41cYkhVXGtq = BrbZhHKJ0jnIe2lumE9M(H2HMwT4JFz7rDkPZmRjcX,'modified_values')
		WUSylLup41cYkhVXGtq = XnQbsZF0Ouh8p7zCdUN(WUSylLup41cYkhVXGtq)
		if JPnr9ICqkDyV!='': JPnr9ICqkDyV = BrbZhHKJ0jnIe2lumE9M(JPnr9ICqkDyV,'modified_filters')
		if JPnr9ICqkDyV=='': bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = url
		else: bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = url+'//getposts??'+JPnr9ICqkDyV
		UnFC90p8KGPSwHJrV = onz7dgENVKPxB(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'أظهار قائمة الفيديو التي تم اختيارها ',UnFC90p8KGPSwHJrV,251,'','','filters')
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+' [[   '+WUSylLup41cYkhVXGtq+'   ]]',UnFC90p8KGPSwHJrV,251,'','','filters')
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(IIiPCruL6dT8s1lqj47SzpVHnYNm,'POST',url,'',headers,'','','ARABSEED-FILTERS_MENU-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('class="TaxPageFilter"(.*?)class="TermBTNs"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	vsptNMP2ZQC = XBuP6Op7y4K[0]
	O15iPVhAvQHo7KUSklc24gTqfuz = My7Dwqvs6bfGNSIgX.findall('class="TaxPageFilterItem".*?<em>(.*?)</em>.*?data-tax="(.*?)"(.*?)</ul>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	HNrUodljIAiX7yRsQbgtcVvKDP9 = My7Dwqvs6bfGNSIgX.findall('class="RatingFilter".*?<h4>(.*?)</h4>.*?(<ul>)(.*?)</ul>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	E3ErsLQfR4JXt = O15iPVhAvQHo7KUSklc24gTqfuz+HNrUodljIAiX7yRsQbgtcVvKDP9
	dict = {}
	for name,RTsbVE9CiQt,vsptNMP2ZQC in E3ErsLQfR4JXt:
		items = My7Dwqvs6bfGNSIgX.findall('data-name="(.*?)".*?data-tax="(.*?)".*?data-term="(.*?)"',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		if name=='اخرى': name = 'الاقسام'
		if not items:
			zE1FBZLDvygwGdkef74lnRJVXCUqKH = My7Dwqvs6bfGNSIgX.findall('data-rate="(.*?)".*?<em>(.*?)</em>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
			items = []
			for A5AMg7LY1HlOz0B82n,WoFrX46wzbCNp18 in zE1FBZLDvygwGdkef74lnRJVXCUqKH: items.append([A5AMg7LY1HlOz0B82n,'',WoFrX46wzbCNp18])
			RTsbVE9CiQt = 'rate'
			name = 'التقييم'
		else: RTsbVE9CiQt = items[0][1]
		if '==' not in bJEs4IVAPdyUrhwCLv9k2YoOl8nt1: bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = url
		if type=='CATEGORIES':
			if g4Y0BXLxCpuojKP1SAUtcq7TwN2!=RTsbVE9CiQt: continue
			elif len(items)<=1:
				if RTsbVE9CiQt==kEaCuLOYxJQI7btFwzV3P[-1]: sscM839DP1jWZ4zl6uIx0Kyn(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1)
				else: LLJlTxDePyjoVKA(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,'CATEGORIES___'+A7AEKRlF6Hf3eWVxY0NdwgsMPCc)
				return
			else:
				UnFC90p8KGPSwHJrV = onz7dgENVKPxB(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1)
				if RTsbVE9CiQt==kEaCuLOYxJQI7btFwzV3P[-1]: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'الجميع ',UnFC90p8KGPSwHJrV,251,'','','filters')
				else: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'الجميع ',bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,254,'','',A7AEKRlF6Hf3eWVxY0NdwgsMPCc)
		elif type=='FILTERS':
			HHXeMqVOshPcW3tULa5v = H2HMwT4JFz7rDkPZmRjcX+'&&'+RTsbVE9CiQt+'==0'
			DoSfCckGA9BQe = JPnr9ICqkDyV+'&&'+RTsbVE9CiQt+'==0'
			A7AEKRlF6Hf3eWVxY0NdwgsMPCc = HHXeMqVOshPcW3tULa5v+'___'+DoSfCckGA9BQe
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'الجميع :'+name,bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,255,'','',A7AEKRlF6Hf3eWVxY0NdwgsMPCc)
		dict[RTsbVE9CiQt] = {}
		for A5AMg7LY1HlOz0B82n,wLWTRZQNlpACcvdFU3Vo,WoFrX46wzbCNp18 in items:
			if A5AMg7LY1HlOz0B82n in eh2tDvRFWpLQI: continue
			if 'الكل' in A5AMg7LY1HlOz0B82n: continue
			A5AMg7LY1HlOz0B82n = PIfAumbGicwg5ye(A5AMg7LY1HlOz0B82n)
			yXskwRgtdJ,U2UaTcgBpsEZxKiRG1Xv8 = A5AMg7LY1HlOz0B82n,A5AMg7LY1HlOz0B82n
			U2UaTcgBpsEZxKiRG1Xv8 = name+': '+yXskwRgtdJ
			dict[RTsbVE9CiQt][WoFrX46wzbCNp18] = U2UaTcgBpsEZxKiRG1Xv8
			HHXeMqVOshPcW3tULa5v = H2HMwT4JFz7rDkPZmRjcX+'&&'+RTsbVE9CiQt+'=='+yXskwRgtdJ
			DoSfCckGA9BQe = JPnr9ICqkDyV+'&&'+RTsbVE9CiQt+'=='+WoFrX46wzbCNp18
			QQIzTLCXyhtZ7pRNnGq = HHXeMqVOshPcW3tULa5v+'___'+DoSfCckGA9BQe
			if type=='FILTERS':
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+U2UaTcgBpsEZxKiRG1Xv8,url,255,'','',QQIzTLCXyhtZ7pRNnGq)
			elif type=='CATEGORIES' and kEaCuLOYxJQI7btFwzV3P[-2]+'==' in H2HMwT4JFz7rDkPZmRjcX:
				woj78rBnbLlmZWIy19iPHFCf5 = BrbZhHKJ0jnIe2lumE9M(DoSfCckGA9BQe,'modified_filters')
				QAKdHzO0rehbtyIc = url+'//getposts??'+woj78rBnbLlmZWIy19iPHFCf5
				UnFC90p8KGPSwHJrV = onz7dgENVKPxB(QAKdHzO0rehbtyIc)
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+U2UaTcgBpsEZxKiRG1Xv8,UnFC90p8KGPSwHJrV,251,'','','filters')
			else: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+U2UaTcgBpsEZxKiRG1Xv8,url,254,'','',QQIzTLCXyhtZ7pRNnGq)
	return
kEaCuLOYxJQI7btFwzV3P = ['category','country','release-year']
DlOqSAQowZ4 = ['category','country','genre','release-year','language','quality','rate']
def onz7dgENVKPxB(url):
	VIoAp74OTMP52BHiE1WqFvtDL0ru = '/wp-content/themes/Elshaikh2021/Ajaxat/Home/FilteringHome.php'
	url = url.replace('//getposts',VIoAp74OTMP52BHiE1WqFvtDL0ru)
	url = url.replace('/category/اخرى','')
	if VIoAp74OTMP52BHiE1WqFvtDL0ru not in url: url = url+VIoAp74OTMP52BHiE1WqFvtDL0ru
	url = url.replace('release-year','year')
	url = url.replace('??','?')
	url = url.replace('&&','&')
	url = url.replace('==','=')
	return url
def BrbZhHKJ0jnIe2lumE9M(PPebqkulZUsx3GCLdnYvR,mode):
	PPebqkulZUsx3GCLdnYvR = PPebqkulZUsx3GCLdnYvR.strip('&&')
	mVSjqdOvyf,DidZH6E0pJelcU9xMCBgyL2KvR = {},''
	if '==' in PPebqkulZUsx3GCLdnYvR:
		items = PPebqkulZUsx3GCLdnYvR.split('&&')
		for ZA1fBenNahOR3xrkjvwYSVMy6JK5s in items:
			nmqEj60bcdSQoFPGa,WoFrX46wzbCNp18 = ZA1fBenNahOR3xrkjvwYSVMy6JK5s.split('==')
			mVSjqdOvyf[nmqEj60bcdSQoFPGa] = WoFrX46wzbCNp18
	for key in DlOqSAQowZ4:
		if key in list(mVSjqdOvyf.keys()): WoFrX46wzbCNp18 = mVSjqdOvyf[key]
		else: WoFrX46wzbCNp18 = '0'
		if '%' not in WoFrX46wzbCNp18: WoFrX46wzbCNp18 = F8fMqZKB4APk(WoFrX46wzbCNp18)
		if mode=='modified_values' and WoFrX46wzbCNp18!='0': DidZH6E0pJelcU9xMCBgyL2KvR = DidZH6E0pJelcU9xMCBgyL2KvR+' + '+WoFrX46wzbCNp18
		elif mode=='modified_filters' and WoFrX46wzbCNp18!='0': DidZH6E0pJelcU9xMCBgyL2KvR = DidZH6E0pJelcU9xMCBgyL2KvR+'&&'+key+'=='+WoFrX46wzbCNp18
		elif mode=='all': DidZH6E0pJelcU9xMCBgyL2KvR = DidZH6E0pJelcU9xMCBgyL2KvR+'&&'+key+'=='+WoFrX46wzbCNp18
	DidZH6E0pJelcU9xMCBgyL2KvR = DidZH6E0pJelcU9xMCBgyL2KvR.strip(' + ')
	DidZH6E0pJelcU9xMCBgyL2KvR = DidZH6E0pJelcU9xMCBgyL2KvR.strip('&&')
	return DidZH6E0pJelcU9xMCBgyL2KvR
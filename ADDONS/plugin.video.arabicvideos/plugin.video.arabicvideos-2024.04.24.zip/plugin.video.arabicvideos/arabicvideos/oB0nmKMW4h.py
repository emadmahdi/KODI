# -*- coding: utf-8 -*-
from G6AHskJeqN import *
import bs4 as Mx2LQs9YirSTHgpkF
baNWS6nfqTC5iX4Kl = 'ELCINEMA'
teUPLFC3B8bArakwHVGsdhoIWDM49f = '_ELC_'
EZxQp1WOldMTvFU = AK5RqLhji4W1wt9VdrCD3PGeQM[baNWS6nfqTC5iX4Kl][0]
headers = {'Referer':EZxQp1WOldMTvFU}
eh2tDvRFWpLQI = []
def VbgEajY4Bt2COpGDcPqI(mode,url,text):
	if   mode==510: ft3e2JBKQVXWlFPjaMhkEqGxvDg = eN02L7Tf5bQ()
	elif mode==511: ft3e2JBKQVXWlFPjaMhkEqGxvDg = tpqK4BT9GUCwxhNk(url)
	elif mode==512: ft3e2JBKQVXWlFPjaMhkEqGxvDg = FxeaIH6wZpYb5mj1NAyBCG3Uko(url)
	elif mode==513: ft3e2JBKQVXWlFPjaMhkEqGxvDg = t6bHS3um8jknyr1RzavPpFgDGBxwMf(url)
	elif mode==514: ft3e2JBKQVXWlFPjaMhkEqGxvDg = QQ7IAukpCJYWv0wMVUL(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==515: ft3e2JBKQVXWlFPjaMhkEqGxvDg = QQ7IAukpCJYWv0wMVUL(url,'SPECIFIED_FILTER___'+text)
	elif mode==516: ft3e2JBKQVXWlFPjaMhkEqGxvDg = ciP5gsXRLtnoZCeydDAu(text)
	elif mode==517: ft3e2JBKQVXWlFPjaMhkEqGxvDg = BPaq0uc9DwiVXYAWHNhsQ8UT3feoKz(url)
	elif mode==518: ft3e2JBKQVXWlFPjaMhkEqGxvDg = FTOSYU0g5J2r3hwzVDPj4Bdnq(url)
	elif mode==519: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HjZcUIVAXFCqy9TfBWKtgY2(text)
	elif mode==520: ft3e2JBKQVXWlFPjaMhkEqGxvDg = UUhTX4yZWaM7KSJ(url)
	elif mode==521: ft3e2JBKQVXWlFPjaMhkEqGxvDg = cAPFfj7LsZUQYdK0DX(url)
	elif mode==522: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HDxCnPKFhITpZmOsA4a0UL6(url)
	elif mode==523: ft3e2JBKQVXWlFPjaMhkEqGxvDg = ZdBTUXfe1aR3pFxJgtHvQbsc2Lq6wk(text)
	elif mode==524: ft3e2JBKQVXWlFPjaMhkEqGxvDg = GG4NzKMjesxI6OLu1bDaBWd()
	elif mode==525: ft3e2JBKQVXWlFPjaMhkEqGxvDg = A5GaYOXrRPoQUhkudtvi90D4FJ()
	elif mode==526: ft3e2JBKQVXWlFPjaMhkEqGxvDg = jBP3CdI0eio()
	elif mode==527: ft3e2JBKQVXWlFPjaMhkEqGxvDg = AlDpeHioYS6xmz0JaKdZy8MW()
	else: ft3e2JBKQVXWlFPjaMhkEqGxvDg = False
	return ft3e2JBKQVXWlFPjaMhkEqGxvDg
def eN02L7Tf5bQ():
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'بحث بموسوعة السينما','',519)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'موسوعة الأعمال','',525)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'موسوعة الأشخاص','',526)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'موسوعة المصنفات','',527)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'موسوعة المنوعات','',524)
	return
def GG4NzKMjesxI6OLu1bDaBWd():
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+' فيديوهات - خاصة',EZxQp1WOldMTvFU+'/video',520)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'فيديوهات - أحدث',EZxQp1WOldMTvFU+'/video/latest',521)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'فيديوهات - أقدم',EZxQp1WOldMTvFU+'/video/oldest',521)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'فيديوهات - أكثر مشاهدة',EZxQp1WOldMTvFU+'/video/views',521)
	return
def A5GaYOXrRPoQUhkudtvi90D4FJ():
	XoYcgE8KGsDnyLlCk = EZxQp1WOldMTvFU+'/lineup?utf8=%E2%9C%93'
	Lfd1JWj73gultGZMH = XoYcgE8KGsDnyLlCk+'&type=2&category=1&foreign=false&tag='
	GUxBPjJAguqTr7zKCFINy = XoYcgE8KGsDnyLlCk+'&type=2&category=3&foreign=false&tag='
	CbA1Ujp37B = XoYcgE8KGsDnyLlCk+'&type=2&category=1&foreign=true&tag='
	E28BcTknhqlRemoubiY9yp = XoYcgE8KGsDnyLlCk+'&type=2&category=3&foreign=true&tag='
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'مصنفات أفلام عربي',Lfd1JWj73gultGZMH,511)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'مصنفات مسلسلات عربي',GUxBPjJAguqTr7zKCFINy,511)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'مصنفات أفلام اجنبي',CbA1Ujp37B,511)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'مصنفات مسلسلات اجنبي',E28BcTknhqlRemoubiY9yp,511)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'فهرس أعمال أبجدي',EZxQp1WOldMTvFU+'/index/work/alphabet',517)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'فهرس  بلد الإنتاج',EZxQp1WOldMTvFU+'/index/work/country',517)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'فهرس اللغة',EZxQp1WOldMTvFU+'/index/work/language',517)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'فهرس مصنفات العمل',EZxQp1WOldMTvFU+'/index/work/genre',517)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'فهرس سنة الإصدار',EZxQp1WOldMTvFU+'/index/work/release_year',517)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'مواسم - فلتر محدد',EZxQp1WOldMTvFU+'/seasonals',515)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'مواسم - فلتر كامل',EZxQp1WOldMTvFU+'/seasonals',514)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'مصنفات - فلتر محدد',EZxQp1WOldMTvFU+'/lineup',515)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'مصنفات - فلتر كامل',EZxQp1WOldMTvFU+'/lineup',514)
	return
def AlDpeHioYS6xmz0JaKdZy8MW():
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(IIiPCruL6dT8s1lqj47SzpVHnYNm,'GET',EZxQp1WOldMTvFU+'/lineup','',headers,'','','ELCINEMA-MENU-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	x6K9kB5RIJj30CsU24LDub = Mx2LQs9YirSTHgpkF.BeautifulSoup(MK6ZT2zjC1SbmveNFqor,'html.parser',multi_valued_attributes=None)
	vsptNMP2ZQC = x6K9kB5RIJj30CsU24LDub.find('select',attrs={'name':'tag'})
	LQf3AeozSrai = vsptNMP2ZQC.find_all('option')
	for A5AMg7LY1HlOz0B82n in LQf3AeozSrai:
		WoFrX46wzbCNp18 = A5AMg7LY1HlOz0B82n.get('value')
		if not WoFrX46wzbCNp18: continue
		title = A5AMg7LY1HlOz0B82n.text
		if V8fmEML1b0PeaRZySnzh3H5J9:
			title = title.encode('utf8')
			WoFrX46wzbCNp18 = WoFrX46wzbCNp18.encode('utf8')
		BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU+'/lineup?utf8=%E2%9C%93&type=&category=&foreign=&tag='+WoFrX46wzbCNp18
		title = title.replace('قائمة ','')
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,511)
	return
def jBP3CdI0eio():
	XoYcgE8KGsDnyLlCk = EZxQp1WOldMTvFU+'/lineup?utf8=%E2%9C%93'
	zzhK4iZqaFW = XoYcgE8KGsDnyLlCk+'&type=1&category=&foreign=&tag='
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'مصنفات أشخاص',zzhK4iZqaFW,511)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'فهرس أشخاص أبجدي',EZxQp1WOldMTvFU+'/index/person/alphabet',517)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'فهرس موطن',EZxQp1WOldMTvFU+'/index/person/nationality',517)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'فهرس  تاريخ الميلاد',EZxQp1WOldMTvFU+'/index/person/birth_year',517)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'فهرس  تاريخ الوفاة',EZxQp1WOldMTvFU+'/index/person/death_year',517)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'مصنفات - فلتر محدد',EZxQp1WOldMTvFU+'/lineup',515)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'مصنفات - فلتر كامل',EZxQp1WOldMTvFU+'/lineup',514)
	return
def tpqK4BT9GUCwxhNk(url):
	if '/seasonals' in url: gMous1DWl97JdE5h6n0CFjeLZkq = 0
	elif '/lineup' in url: gMous1DWl97JdE5h6n0CFjeLZkq = 1
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(IIiPCruL6dT8s1lqj47SzpVHnYNm,'GET',url,'',headers,'','','ELCINEMA-LISTS-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	x6K9kB5RIJj30CsU24LDub = Mx2LQs9YirSTHgpkF.BeautifulSoup(MK6ZT2zjC1SbmveNFqor,'html.parser',multi_valued_attributes=None)
	xAcIatGBYy0FLXroS1ig3Ts9KZ8P5 = x6K9kB5RIJj30CsU24LDub.find_all(class_='jumbo-theater clearfix')
	for vsptNMP2ZQC in xAcIatGBYy0FLXroS1ig3Ts9KZ8P5:
		title = vsptNMP2ZQC.find_all('a')[gMous1DWl97JdE5h6n0CFjeLZkq].text
		BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU+vsptNMP2ZQC.find_all('a')[gMous1DWl97JdE5h6n0CFjeLZkq].get('href')
		if V8fmEML1b0PeaRZySnzh3H5J9:
			title = title.encode('utf8')
			BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ.encode('utf8')
		if not xAcIatGBYy0FLXroS1ig3Ts9KZ8P5:
			FxeaIH6wZpYb5mj1NAyBCG3Uko(BoEFz2WhUyvTgDeiZ)
			return
		else:
			title = title.replace('قائمة ','')
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,512)
	ORiJ0ZCPYdkgTrEq3fwFXusIjS(x6K9kB5RIJj30CsU24LDub,511)
	return
def ORiJ0ZCPYdkgTrEq3fwFXusIjS(x6K9kB5RIJj30CsU24LDub,mode):
	vsptNMP2ZQC = x6K9kB5RIJj30CsU24LDub.find(class_='pagination')
	if vsptNMP2ZQC:
		TpqYA0HJXUj6teEKNdFuVB = vsptNMP2ZQC.find_all('a')
		cJZdgmSiXuDALTR3MHkhvtP7lNfYVj = vsptNMP2ZQC.find_all('li')
		zOu94MwSf63Ul5VEcKNbYsx = list(zip(TpqYA0HJXUj6teEKNdFuVB,cJZdgmSiXuDALTR3MHkhvtP7lNfYVj))
		k3Om08MCgqQao4n1 = -1
		KKkapdn7Slo50RfXYTGJ6cgZ = len(zOu94MwSf63Ul5VEcKNbYsx)
		for mfx4oMDwjFq3XTZiybLWRrk0pO,P0AkgzXYfnaWHVK3rpoFZlm in zOu94MwSf63Ul5VEcKNbYsx:
			k3Om08MCgqQao4n1 += 1
			P0AkgzXYfnaWHVK3rpoFZlm = P0AkgzXYfnaWHVK3rpoFZlm['class']
			if 'unavailable' in P0AkgzXYfnaWHVK3rpoFZlm or 'current' in P0AkgzXYfnaWHVK3rpoFZlm: continue
			bdHQJiTCSFGgoXL3v2rMNAEn6y = mfx4oMDwjFq3XTZiybLWRrk0pO.text
			bOBQpgMudItXo = EZxQp1WOldMTvFU+mfx4oMDwjFq3XTZiybLWRrk0pO.get('href')
			if V8fmEML1b0PeaRZySnzh3H5J9:
				bdHQJiTCSFGgoXL3v2rMNAEn6y = bdHQJiTCSFGgoXL3v2rMNAEn6y.encode('utf8')
				bOBQpgMudItXo = bOBQpgMudItXo.encode('utf8')
			if   k3Om08MCgqQao4n1==0: bdHQJiTCSFGgoXL3v2rMNAEn6y = 'أولى'
			elif k3Om08MCgqQao4n1==1: bdHQJiTCSFGgoXL3v2rMNAEn6y = 'سابقة'
			elif k3Om08MCgqQao4n1==KKkapdn7Slo50RfXYTGJ6cgZ-2: bdHQJiTCSFGgoXL3v2rMNAEn6y = 'لاحقة'
			elif k3Om08MCgqQao4n1==KKkapdn7Slo50RfXYTGJ6cgZ-1: bdHQJiTCSFGgoXL3v2rMNAEn6y = 'أخيرة'
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'صفحة '+bdHQJiTCSFGgoXL3v2rMNAEn6y,bOBQpgMudItXo,mode)
	return
def FxeaIH6wZpYb5mj1NAyBCG3Uko(url):
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(IIiPCruL6dT8s1lqj47SzpVHnYNm,'GET',url,'',headers,'','','ELCINEMA-TITLES1-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	x6K9kB5RIJj30CsU24LDub = Mx2LQs9YirSTHgpkF.BeautifulSoup(MK6ZT2zjC1SbmveNFqor,'html.parser',multi_valued_attributes=None)
	xAcIatGBYy0FLXroS1ig3Ts9KZ8P5 = x6K9kB5RIJj30CsU24LDub.find_all(class_='row')
	items,lErmvOQ4B6 = [],True
	for vsptNMP2ZQC in xAcIatGBYy0FLXroS1ig3Ts9KZ8P5:
		if not vsptNMP2ZQC.find(class_='thumbnail-wrapper'): continue
		if lErmvOQ4B6: lErmvOQ4B6 = False ; continue
		cXkhRNEWFb59CITf8Uv7p1AGnye0 = []
		DBjSr6iHPEmTw7vQ = vsptNMP2ZQC.find_all(class_=['censorship red','censorship purple'])
		for vzSxXtVnIejC9J04Rf6ybkT8g in DBjSr6iHPEmTw7vQ:
			xMWO2IzwVSlsyURBQmvFdX6 = vzSxXtVnIejC9J04Rf6ybkT8g.find_all('li')[1].text
			if V8fmEML1b0PeaRZySnzh3H5J9:
				xMWO2IzwVSlsyURBQmvFdX6 = xMWO2IzwVSlsyURBQmvFdX6.encode('utf8')
			cXkhRNEWFb59CITf8Uv7p1AGnye0.append(xMWO2IzwVSlsyURBQmvFdX6)
		if not a97xrkSOefH5DbjXunq(baNWS6nfqTC5iX4Kl,'',cXkhRNEWFb59CITf8Uv7p1AGnye0,False):
			QFrVYJkywEsXquMNz = vsptNMP2ZQC.find('img').get('data-src')
			title = vsptNMP2ZQC.find('h3')
			name = title.find('a').text
			BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU+title.find('a').get('href')
			OsxujdPf52tFY = vsptNMP2ZQC.find(class_='no-margin')
			T54XRdc7wxNQbmfaKsuky3SjnHWo = vsptNMP2ZQC.find(class_='legend')
			if OsxujdPf52tFY: OsxujdPf52tFY = OsxujdPf52tFY.text
			if T54XRdc7wxNQbmfaKsuky3SjnHWo: T54XRdc7wxNQbmfaKsuky3SjnHWo = T54XRdc7wxNQbmfaKsuky3SjnHWo.text
			if V8fmEML1b0PeaRZySnzh3H5J9:
				QFrVYJkywEsXquMNz = QFrVYJkywEsXquMNz.encode('utf8')
				name = name.encode('utf8')
				BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ.encode('utf8')
				if OsxujdPf52tFY: OsxujdPf52tFY = OsxujdPf52tFY.encode('utf8')
			yPoqtK3i7zHulhZJDWYsnLxvT0 = {}
			if T54XRdc7wxNQbmfaKsuky3SjnHWo: yPoqtK3i7zHulhZJDWYsnLxvT0['stars'] = T54XRdc7wxNQbmfaKsuky3SjnHWo
			if OsxujdPf52tFY:
				OsxujdPf52tFY = OsxujdPf52tFY.replace('\n',' .. ')
				yPoqtK3i7zHulhZJDWYsnLxvT0['plot'] = OsxujdPf52tFY.replace('...اقرأ المزيد','')
			if '/work/' in BoEFz2WhUyvTgDeiZ:
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+name,BoEFz2WhUyvTgDeiZ,516,QFrVYJkywEsXquMNz,'',name,'',yPoqtK3i7zHulhZJDWYsnLxvT0)
			elif '/person/' in BoEFz2WhUyvTgDeiZ: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+name,BoEFz2WhUyvTgDeiZ,513,QFrVYJkywEsXquMNz,'',name,'',yPoqtK3i7zHulhZJDWYsnLxvT0)
	ORiJ0ZCPYdkgTrEq3fwFXusIjS(x6K9kB5RIJj30CsU24LDub,512)
	return
def t6bHS3um8jknyr1RzavPpFgDGBxwMf(url):
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(IIiPCruL6dT8s1lqj47SzpVHnYNm,'GET',url,'',headers,'','','ELCINEMA-TITLES2-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	x6K9kB5RIJj30CsU24LDub = Mx2LQs9YirSTHgpkF.BeautifulSoup(MK6ZT2zjC1SbmveNFqor,'html.parser',multi_valued_attributes=None)
	xAcIatGBYy0FLXroS1ig3Ts9KZ8P5 = x6K9kB5RIJj30CsU24LDub.find_all('li')
	P9pVfsQSTg7IraUGeKLWwxdz,items = [],[]
	for vsptNMP2ZQC in xAcIatGBYy0FLXroS1ig3Ts9KZ8P5:
		if not vsptNMP2ZQC.find(class_='thumbnail-wrapper'): continue
		if not vsptNMP2ZQC.find(class_=['unstyled','unstyled text-center']): continue
		if vsptNMP2ZQC.find(class_='hide'): continue
		title = vsptNMP2ZQC.find(class_=['unstyled','unstyled text-center'])
		name = title.find('a').text
		if name in P9pVfsQSTg7IraUGeKLWwxdz: continue
		P9pVfsQSTg7IraUGeKLWwxdz.append(name)
		BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU+title.find('a').get('href')
		if '/search/work/' in url: QFrVYJkywEsXquMNz = vsptNMP2ZQC.find('img').get('src')
		elif '/search/person/' in url: QFrVYJkywEsXquMNz = vsptNMP2ZQC.find('img').get('data-src')
		elif '/search/video/' in url: QFrVYJkywEsXquMNz = vsptNMP2ZQC.find('img').get('data-src')
		else: QFrVYJkywEsXquMNz = vsptNMP2ZQC.find('img').get('src')
		if V8fmEML1b0PeaRZySnzh3H5J9:
			name = name.encode('utf8')
			BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ.encode('utf8')
			QFrVYJkywEsXquMNz = QFrVYJkywEsXquMNz.encode('utf8')
		name = name.strip(' ')
		items.append((name,BoEFz2WhUyvTgDeiZ,QFrVYJkywEsXquMNz))
	if '/search/person/' in url: items = sorted(items,reverse=False,key=lambda key: key[0])
	for name,BoEFz2WhUyvTgDeiZ,QFrVYJkywEsXquMNz in items:
		if '/search/video/' in url: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+name,BoEFz2WhUyvTgDeiZ,522,QFrVYJkywEsXquMNz)
		elif '/search/person/' in url: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+name,BoEFz2WhUyvTgDeiZ,513,QFrVYJkywEsXquMNz,'',name)
		else: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+name,BoEFz2WhUyvTgDeiZ,516,QFrVYJkywEsXquMNz,'',name)
	return
def ciP5gsXRLtnoZCeydDAu(text):
	text = text.replace('الإعلان','').replace('لفيلم','').replace('الرسمي','')
	text = text.replace('إعلان','').replace('فيلم','').replace('البرومو','')
	text = text.replace('التشويقي','').replace('لمسلسل','').replace('مسلسل','')
	text = text.replace(':','').replace(')','').replace('(','').replace(',','')
	text = text.replace('_','').replace(';','').replace('-','').replace('.','')
	text = text.replace('\'','').replace('\"','')
	text = text.replace('    ',' ').replace('   ',' ').replace('  ',' ')
	text = text.strip(' ')
	TcEfqvLCabho1tjp5ZX = text.count(' ')+1
	if TcEfqvLCabho1tjp5ZX==1:
		ZdBTUXfe1aR3pFxJgtHvQbsc2Lq6wk(text)
		return
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link',teUPLFC3B8bArakwHVGsdhoIWDM49f+'[COLOR FFC89008]==== كلمات للبحث ====[/COLOR]','',9999)
	en5qvcJ0zIHi1POG = text.split(' ')
	AnZQe2T6csCxkSalzI = pow(2,TcEfqvLCabho1tjp5ZX)
	zzLiDsTBEI5YHCqR0gSkt6pZ = []
	def KoXWAaYGF2PfSug(xhIMnjFbcKD,tUunlg3F1qhOVDQ7vr):
		if xhIMnjFbcKD=='1': return tUunlg3F1qhOVDQ7vr
		return ''
	for k3Om08MCgqQao4n1 in range(AnZQe2T6csCxkSalzI,0,-1):
		I4pnTD0hPJXLoVG7baESsZWH = list(TcEfqvLCabho1tjp5ZX*'0'+bin(k3Om08MCgqQao4n1)[2:])[-TcEfqvLCabho1tjp5ZX:]
		I4pnTD0hPJXLoVG7baESsZWH = reversed(I4pnTD0hPJXLoVG7baESsZWH)
		FFryOE3KRpiuDQ = map(KoXWAaYGF2PfSug,I4pnTD0hPJXLoVG7baESsZWH,en5qvcJ0zIHi1POG)
		title = ' '.join(filter(None,FFryOE3KRpiuDQ))
		if V8fmEML1b0PeaRZySnzh3H5J9: U2UaTcgBpsEZxKiRG1Xv8 = title.decode('utf8')
		else: U2UaTcgBpsEZxKiRG1Xv8 = title
		if len(U2UaTcgBpsEZxKiRG1Xv8)>2 and title not in zzLiDsTBEI5YHCqR0gSkt6pZ:
			zzLiDsTBEI5YHCqR0gSkt6pZ.append(title)
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,'',523,'','',title)
	return
def ZdBTUXfe1aR3pFxJgtHvQbsc2Lq6wk(SzODUMcwsHkNf4IlY):
	if V8fmEML1b0PeaRZySnzh3H5J9:
		SzODUMcwsHkNf4IlY = SzODUMcwsHkNf4IlY.decode('utf8')
		import arabic_reshaper as QimwKpdT6EayZUMvse
		SzODUMcwsHkNf4IlY = QimwKpdT6EayZUMvse.ArabicReshaper().reshape(SzODUMcwsHkNf4IlY)
		SzODUMcwsHkNf4IlY = mFS3RqXrOoUsMcx5GD0jKfI.get_display(SzODUMcwsHkNf4IlY)
	import OesqjQaWuv
	SzODUMcwsHkNf4IlY = ViKAIsLurq83RSENayxWb(default=SzODUMcwsHkNf4IlY)
	OesqjQaWuv.HjZcUIVAXFCqy9TfBWKtgY2(SzODUMcwsHkNf4IlY)
	return
def BPaq0uc9DwiVXYAWHNhsQ8UT3feoKz(url):
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(IIiPCruL6dT8s1lqj47SzpVHnYNm,'GET',url,'',headers,'','','ELCINEMA-INDEXES_LISTS-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	x6K9kB5RIJj30CsU24LDub = Mx2LQs9YirSTHgpkF.BeautifulSoup(MK6ZT2zjC1SbmveNFqor,'html.parser',multi_valued_attributes=None)
	vsptNMP2ZQC = x6K9kB5RIJj30CsU24LDub.find(class_='list-separator list-title')
	msjnlSMrQGJ4oLwE2d = vsptNMP2ZQC.find_all('a')
	items = []
	for title in msjnlSMrQGJ4oLwE2d:
		name = title.text
		BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU+title.get('href')
		if V8fmEML1b0PeaRZySnzh3H5J9:
			name = name.encode('utf8')
			BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ.encode('utf8')
		if '#' not in BoEFz2WhUyvTgDeiZ: items.append((name,BoEFz2WhUyvTgDeiZ))
	items = sorted(items,reverse=False,key=lambda key: key[0])
	for ZA1fBenNahOR3xrkjvwYSVMy6JK5s in items:
		name,BoEFz2WhUyvTgDeiZ = ZA1fBenNahOR3xrkjvwYSVMy6JK5s
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+name,BoEFz2WhUyvTgDeiZ,518)
	return
def FTOSYU0g5J2r3hwzVDPj4Bdnq(url):
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(IIiPCruL6dT8s1lqj47SzpVHnYNm,'GET',url,'',headers,'','','ELCINEMA-INDEXES_TITLES-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	x6K9kB5RIJj30CsU24LDub = Mx2LQs9YirSTHgpkF.BeautifulSoup(MK6ZT2zjC1SbmveNFqor,'html.parser',multi_valued_attributes=None)
	xAcIatGBYy0FLXroS1ig3Ts9KZ8P5 = x6K9kB5RIJj30CsU24LDub.find(class_='expand').find_all('tr')
	for vsptNMP2ZQC in xAcIatGBYy0FLXroS1ig3Ts9KZ8P5:
		JN7hxH3yg4IG6K91fjSsCe = vsptNMP2ZQC.find_all('a')
		if not JN7hxH3yg4IG6K91fjSsCe: continue
		QFrVYJkywEsXquMNz = vsptNMP2ZQC.find('img').get('data-src')
		name = JN7hxH3yg4IG6K91fjSsCe[1].text
		BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU+JN7hxH3yg4IG6K91fjSsCe[1].get('href')
		T54XRdc7wxNQbmfaKsuky3SjnHWo = vsptNMP2ZQC.find(class_='legend')
		if T54XRdc7wxNQbmfaKsuky3SjnHWo: T54XRdc7wxNQbmfaKsuky3SjnHWo = T54XRdc7wxNQbmfaKsuky3SjnHWo.text
		if V8fmEML1b0PeaRZySnzh3H5J9:
			name = name.encode('utf8')
			BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ.encode('utf8')
			QFrVYJkywEsXquMNz = QFrVYJkywEsXquMNz.encode('utf8')
		yPoqtK3i7zHulhZJDWYsnLxvT0 = {}
		if T54XRdc7wxNQbmfaKsuky3SjnHWo: yPoqtK3i7zHulhZJDWYsnLxvT0['stars'] = T54XRdc7wxNQbmfaKsuky3SjnHWo
		if '/work/' in BoEFz2WhUyvTgDeiZ:
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+name,BoEFz2WhUyvTgDeiZ,516,QFrVYJkywEsXquMNz,'',name,'',yPoqtK3i7zHulhZJDWYsnLxvT0)
		elif '/person/' in BoEFz2WhUyvTgDeiZ: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+name,BoEFz2WhUyvTgDeiZ,513,QFrVYJkywEsXquMNz,'',name,'',yPoqtK3i7zHulhZJDWYsnLxvT0)
	ORiJ0ZCPYdkgTrEq3fwFXusIjS(x6K9kB5RIJj30CsU24LDub,518)
	return
def UUhTX4yZWaM7KSJ(url):
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(IIiPCruL6dT8s1lqj47SzpVHnYNm,'GET',url,'',headers,'','','ELCINEMA-VIDEOS_LISTS-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	x6K9kB5RIJj30CsU24LDub = Mx2LQs9YirSTHgpkF.BeautifulSoup(MK6ZT2zjC1SbmveNFqor,'html.parser',multi_valued_attributes=None)
	msjnlSMrQGJ4oLwE2d = x6K9kB5RIJj30CsU24LDub.find_all(class_='section-title inline')
	NVHrZsqUp2 = x6K9kB5RIJj30CsU24LDub.find_all(class_='button green small right')
	items = zip(msjnlSMrQGJ4oLwE2d,NVHrZsqUp2)
	for title,BoEFz2WhUyvTgDeiZ in items:
		title = title.text
		BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU+BoEFz2WhUyvTgDeiZ.get('href')
		if V8fmEML1b0PeaRZySnzh3H5J9:
			title = title.encode('utf8')
			BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ.encode('utf8')
		title = title.replace('    ',' ').replace('   ',' ').replace('  ',' ')
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,521)
	return
def cAPFfj7LsZUQYdK0DX(url):
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(IIiPCruL6dT8s1lqj47SzpVHnYNm,'GET',url,'',headers,'','','ELCINEMA-VIDEOS_TITLES-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	x6K9kB5RIJj30CsU24LDub = Mx2LQs9YirSTHgpkF.BeautifulSoup(MK6ZT2zjC1SbmveNFqor,'html.parser',multi_valued_attributes=None)
	PHvmTLalyMtz6V01BgodIWAenS = x6K9kB5RIJj30CsU24LDub.find(class_='large-block-grid-4 medium-block-grid-4 small-block-grid-2')
	xAcIatGBYy0FLXroS1ig3Ts9KZ8P5 = PHvmTLalyMtz6V01BgodIWAenS.find_all('li')
	for vsptNMP2ZQC in xAcIatGBYy0FLXroS1ig3Ts9KZ8P5:
		title = vsptNMP2ZQC.find(class_='title').text
		BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU+vsptNMP2ZQC.find('a').get('href')
		QFrVYJkywEsXquMNz = vsptNMP2ZQC.find('img').get('data-src')
		LEb1HQDAeFdsrNTnVgmXo9 = vsptNMP2ZQC.find(class_='duration').text
		if V8fmEML1b0PeaRZySnzh3H5J9:
			title = title.encode('utf8')
			BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ.encode('utf8')
			QFrVYJkywEsXquMNz = QFrVYJkywEsXquMNz.encode('utf8')
			LEb1HQDAeFdsrNTnVgmXo9 = LEb1HQDAeFdsrNTnVgmXo9.encode('utf8')
		LEb1HQDAeFdsrNTnVgmXo9 = LEb1HQDAeFdsrNTnVgmXo9.replace('\n','').strip(' ')
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,522,QFrVYJkywEsXquMNz,LEb1HQDAeFdsrNTnVgmXo9)
	ORiJ0ZCPYdkgTrEq3fwFXusIjS(x6K9kB5RIJj30CsU24LDub,521)
	return
def HDxCnPKFhITpZmOsA4a0UL6(url):
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(IIiPCruL6dT8s1lqj47SzpVHnYNm,'GET',url,'',headers,'','','ELCINEMA-PLAY-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	x6K9kB5RIJj30CsU24LDub = Mx2LQs9YirSTHgpkF.BeautifulSoup(MK6ZT2zjC1SbmveNFqor,'html.parser',multi_valued_attributes=None)
	BoEFz2WhUyvTgDeiZ = x6K9kB5RIJj30CsU24LDub.find(class_='flex-video').find('iframe').get('src')
	if V8fmEML1b0PeaRZySnzh3H5J9: BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ.encode('utf8')
	B0xcwKkMQ16mpSFRaVHPTzuhUZngLq(BoEFz2WhUyvTgDeiZ,baNWS6nfqTC5iX4Kl,'video')
	return
def HjZcUIVAXFCqy9TfBWKtgY2(search):
	search,LQf3AeozSrai,showDialogs = X54MLovbG8nAEkB9J(search)
	if search=='': search = ViKAIsLurq83RSENayxWb()
	if search=='': return
	search = search.replace(' ','%20')
	url = EZxQp1WOldMTvFU+'/search/?q='+search
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(IIiPCruL6dT8s1lqj47SzpVHnYNm,'GET',url,'',headers,'','','ELCINEMA-SEARCH-1st')
	if not xHb86g9WZqPwRfVjXD2JalzSIp.succeeded:
		zzhK4iZqaFW = EZxQp1WOldMTvFU+'/search_entity/?q='+search+'&entity=work'
		bOBQpgMudItXo = EZxQp1WOldMTvFU+'/search_entity/?q='+search+'&entity=person'
		YYhjLTZwP8rN2VioJIM = EZxQp1WOldMTvFU+'/search_entity/?q='+search+'&entity=video'
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'بحث عن أعمال',zzhK4iZqaFW,513,'',search)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'بحث عن أشخاص',bOBQpgMudItXo,513,'',search)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'بحث عن فيديوهات',YYhjLTZwP8rN2VioJIM,513,'',search)
		return
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	x6K9kB5RIJj30CsU24LDub = Mx2LQs9YirSTHgpkF.BeautifulSoup(MK6ZT2zjC1SbmveNFqor,'html.parser',multi_valued_attributes=None)
	xAcIatGBYy0FLXroS1ig3Ts9KZ8P5 = x6K9kB5RIJj30CsU24LDub.find_all(class_='section-title left')
	for vsptNMP2ZQC in xAcIatGBYy0FLXroS1ig3Ts9KZ8P5:
		title = vsptNMP2ZQC.text
		if V8fmEML1b0PeaRZySnzh3H5J9:
			title = title.encode('utf8')
		title = title.split('(',1)[0].strip(' ')
		if   'أعمال' in title: BoEFz2WhUyvTgDeiZ = url.replace('/search/','/search/work/')
		elif 'أشخاص' in title: BoEFz2WhUyvTgDeiZ = url.replace('/search/','/search/person/')
		elif 'فيديوهات' in title: BoEFz2WhUyvTgDeiZ = url.replace('/search/','/search/video/')
		else: continue
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,513)
	return
def QQ7IAukpCJYWv0wMVUL(url,text):
	global vIZKhbfsXmWAyUVecrNOz95LQ,lWF7u5qUtSak3B
	if '/seasonals' in url:
		vIZKhbfsXmWAyUVecrNOz95LQ = ['seasonal','year','category']
		lWF7u5qUtSak3B = ['seasonal','year','category']
	elif '/lineup' in url:
		vIZKhbfsXmWAyUVecrNOz95LQ = ['category','foreign','type']
		lWF7u5qUtSak3B = ['category','foreign','type']
	LLJlTxDePyjoVKA(url,text)
	return
def lAjOn69YLFxJNEvTrbfwkiXm2d(url):
	url = url.split('/smartemadfilter?')[0]
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(IIiPCruL6dT8s1lqj47SzpVHnYNm,'GET',url,'',headers,'','','ELCINEMA-GET_FILTERS_BLOCKS-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('form action="/(.*?)</form>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	vsptNMP2ZQC = XBuP6Op7y4K[0]
	E3ErsLQfR4JXt = My7Dwqvs6bfGNSIgX.findall('<select name="(.*?)" id="(.*?)".*?>(.*?)</div>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	return E3ErsLQfR4JXt
def kvYFrVe3g8H7dNhIa(vsptNMP2ZQC):
	items = My7Dwqvs6bfGNSIgX.findall('<option value="(.*?)">(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	return items
def NewZb13oj4KLaqD0JzGPf6rYQ2ARn(url):
	ulX0L8F7ZqcwGTJRMk = url.split('/smartemadfilter?')[0]
	M0RTIYy1EUX = ooq2D9xF8ZLpPBs(url,'url')
	url = url.replace('/smartemadfilter?','/?utf8=%E2%9C%93&')
	return url
def sBUe7ExVNMKo(DoSfCckGA9BQe,url):
	woj78rBnbLlmZWIy19iPHFCf5 = BrbZhHKJ0jnIe2lumE9M(DoSfCckGA9BQe,'all_filters')
	QAKdHzO0rehbtyIc = url+'/smartemadfilter?'+woj78rBnbLlmZWIy19iPHFCf5
	QAKdHzO0rehbtyIc = NewZb13oj4KLaqD0JzGPf6rYQ2ARn(QAKdHzO0rehbtyIc)
	return QAKdHzO0rehbtyIc
def LLJlTxDePyjoVKA(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter=='': H2HMwT4JFz7rDkPZmRjcX,JPnr9ICqkDyV = '',''
	else: H2HMwT4JFz7rDkPZmRjcX,JPnr9ICqkDyV = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if vIZKhbfsXmWAyUVecrNOz95LQ[0]+'=' not in H2HMwT4JFz7rDkPZmRjcX: g4Y0BXLxCpuojKP1SAUtcq7TwN2 = vIZKhbfsXmWAyUVecrNOz95LQ[0]
		for FVW0I9sYcAjmDgn8r in range(len(vIZKhbfsXmWAyUVecrNOz95LQ[0:-1])):
			if vIZKhbfsXmWAyUVecrNOz95LQ[FVW0I9sYcAjmDgn8r]+'=' in H2HMwT4JFz7rDkPZmRjcX: g4Y0BXLxCpuojKP1SAUtcq7TwN2 = vIZKhbfsXmWAyUVecrNOz95LQ[FVW0I9sYcAjmDgn8r+1]
		HHXeMqVOshPcW3tULa5v = H2HMwT4JFz7rDkPZmRjcX+'&'+g4Y0BXLxCpuojKP1SAUtcq7TwN2+'=0'
		DoSfCckGA9BQe = JPnr9ICqkDyV+'&'+g4Y0BXLxCpuojKP1SAUtcq7TwN2+'=0'
		A7AEKRlF6Hf3eWVxY0NdwgsMPCc = HHXeMqVOshPcW3tULa5v.strip('&')+'___'+DoSfCckGA9BQe.strip('&')
		woj78rBnbLlmZWIy19iPHFCf5 = BrbZhHKJ0jnIe2lumE9M(JPnr9ICqkDyV,'modified_filters')
		bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = url+'/smartemadfilter?'+woj78rBnbLlmZWIy19iPHFCf5
	elif type=='ALL_ITEMS_FILTER':
		WUSylLup41cYkhVXGtq = BrbZhHKJ0jnIe2lumE9M(H2HMwT4JFz7rDkPZmRjcX,'modified_values')
		WUSylLup41cYkhVXGtq = XnQbsZF0Ouh8p7zCdUN(WUSylLup41cYkhVXGtq)
		if JPnr9ICqkDyV!='': JPnr9ICqkDyV = BrbZhHKJ0jnIe2lumE9M(JPnr9ICqkDyV,'modified_filters')
		if JPnr9ICqkDyV=='': bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = url
		else: bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = url+'/smartemadfilter?'+JPnr9ICqkDyV
		bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = NewZb13oj4KLaqD0JzGPf6rYQ2ARn(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'أظهار قائمة الفيديو التي تم اختيارها ',bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,511)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+' [[   '+WUSylLup41cYkhVXGtq+'   ]]',bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,511)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	E3ErsLQfR4JXt = lAjOn69YLFxJNEvTrbfwkiXm2d(url)
	dict = {}
	for name,RTsbVE9CiQt,vsptNMP2ZQC in E3ErsLQfR4JXt:
		name = name.replace('--','')
		items = kvYFrVe3g8H7dNhIa(vsptNMP2ZQC)
		if '=' not in bJEs4IVAPdyUrhwCLv9k2YoOl8nt1: bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = url
		if type=='SPECIFIED_FILTER':
			if RTsbVE9CiQt not in vIZKhbfsXmWAyUVecrNOz95LQ: continue
			if g4Y0BXLxCpuojKP1SAUtcq7TwN2!=RTsbVE9CiQt: continue
			elif len(items)<2:
				if RTsbVE9CiQt==vIZKhbfsXmWAyUVecrNOz95LQ[-1]:
					url = NewZb13oj4KLaqD0JzGPf6rYQ2ARn(url)
					FxeaIH6wZpYb5mj1NAyBCG3Uko(url)
				else: LLJlTxDePyjoVKA(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,'SPECIFIED_FILTER___'+A7AEKRlF6Hf3eWVxY0NdwgsMPCc)
				return
			else:
				bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = NewZb13oj4KLaqD0JzGPf6rYQ2ARn(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1)
				if RTsbVE9CiQt==vIZKhbfsXmWAyUVecrNOz95LQ[-1]: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'الجميع',bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,511)
				else: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'الجميع',bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,515,'','',A7AEKRlF6Hf3eWVxY0NdwgsMPCc)
		elif type=='ALL_ITEMS_FILTER':
			if RTsbVE9CiQt not in lWF7u5qUtSak3B: continue
			HHXeMqVOshPcW3tULa5v = H2HMwT4JFz7rDkPZmRjcX+'&'+RTsbVE9CiQt+'=0'
			DoSfCckGA9BQe = JPnr9ICqkDyV+'&'+RTsbVE9CiQt+'=0'
			A7AEKRlF6Hf3eWVxY0NdwgsMPCc = HHXeMqVOshPcW3tULa5v+'___'+DoSfCckGA9BQe
			if   name=='type': name = 'النوع'
			elif name=='category': name = 'العمل'
			elif name=='foreign': name = 'اللغة'
			elif name=='year': name = 'السنة'
			elif name=='seasonal': name = 'الموسم'
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'الجميع: '+name,bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,514,'','',A7AEKRlF6Hf3eWVxY0NdwgsMPCc)
		dict[RTsbVE9CiQt] = {}
		for WoFrX46wzbCNp18,A5AMg7LY1HlOz0B82n in items:
			if A5AMg7LY1HlOz0B82n in eh2tDvRFWpLQI: continue
			if 'مصنفات أخرى' in A5AMg7LY1HlOz0B82n: continue
			if 'الكل' in A5AMg7LY1HlOz0B82n: continue
			if 'اللغة' in A5AMg7LY1HlOz0B82n: continue
			A5AMg7LY1HlOz0B82n = A5AMg7LY1HlOz0B82n.replace('قائمة ','')
			if   name=='type': name = 'النوع'
			elif name=='category': name = 'العمل'
			elif name=='foreign': name = 'اللغة'
			elif name=='year': name = 'السنة'
			elif name=='seasonal': name = 'الموسم'
			dict[RTsbVE9CiQt][WoFrX46wzbCNp18] = A5AMg7LY1HlOz0B82n
			HHXeMqVOshPcW3tULa5v = H2HMwT4JFz7rDkPZmRjcX+'&'+RTsbVE9CiQt+'='+A5AMg7LY1HlOz0B82n
			DoSfCckGA9BQe = JPnr9ICqkDyV+'&'+RTsbVE9CiQt+'='+WoFrX46wzbCNp18
			QQIzTLCXyhtZ7pRNnGq = HHXeMqVOshPcW3tULa5v+'___'+DoSfCckGA9BQe
			if name: title = A5AMg7LY1HlOz0B82n+' :'+name
			else: title = A5AMg7LY1HlOz0B82n
			if type=='ALL_ITEMS_FILTER': VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,url,514,'','',QQIzTLCXyhtZ7pRNnGq)
			elif type=='SPECIFIED_FILTER' and vIZKhbfsXmWAyUVecrNOz95LQ[-2]+'=' in H2HMwT4JFz7rDkPZmRjcX:
				QAKdHzO0rehbtyIc = sBUe7ExVNMKo(DoSfCckGA9BQe,url)
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,QAKdHzO0rehbtyIc,511)
			else: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,url,515,'','',QQIzTLCXyhtZ7pRNnGq)
	return
def BrbZhHKJ0jnIe2lumE9M(PPebqkulZUsx3GCLdnYvR,mode):
	PPebqkulZUsx3GCLdnYvR = PPebqkulZUsx3GCLdnYvR.replace('=&','=0&')
	PPebqkulZUsx3GCLdnYvR = PPebqkulZUsx3GCLdnYvR.strip('&')
	mVSjqdOvyf = {}
	if '=' in PPebqkulZUsx3GCLdnYvR:
		items = PPebqkulZUsx3GCLdnYvR.split('&')
		for ZA1fBenNahOR3xrkjvwYSVMy6JK5s in items:
			nmqEj60bcdSQoFPGa,WoFrX46wzbCNp18 = ZA1fBenNahOR3xrkjvwYSVMy6JK5s.split('=')
			mVSjqdOvyf[nmqEj60bcdSQoFPGa] = WoFrX46wzbCNp18
	DidZH6E0pJelcU9xMCBgyL2KvR = ''
	for key in lWF7u5qUtSak3B:
		if key in list(mVSjqdOvyf.keys()): WoFrX46wzbCNp18 = mVSjqdOvyf[key]
		else: WoFrX46wzbCNp18 = '0'
		if '%' not in WoFrX46wzbCNp18: WoFrX46wzbCNp18 = F8fMqZKB4APk(WoFrX46wzbCNp18)
		if mode=='modified_values' and WoFrX46wzbCNp18!='0': DidZH6E0pJelcU9xMCBgyL2KvR = DidZH6E0pJelcU9xMCBgyL2KvR+' + '+WoFrX46wzbCNp18
		elif mode=='modified_filters' and WoFrX46wzbCNp18!='0': DidZH6E0pJelcU9xMCBgyL2KvR = DidZH6E0pJelcU9xMCBgyL2KvR+'&'+key+'='+WoFrX46wzbCNp18
		elif mode=='all_filters': DidZH6E0pJelcU9xMCBgyL2KvR = DidZH6E0pJelcU9xMCBgyL2KvR+'&'+key+'='+WoFrX46wzbCNp18
	DidZH6E0pJelcU9xMCBgyL2KvR = DidZH6E0pJelcU9xMCBgyL2KvR.strip(' + ')
	DidZH6E0pJelcU9xMCBgyL2KvR = DidZH6E0pJelcU9xMCBgyL2KvR.strip('&')
	DidZH6E0pJelcU9xMCBgyL2KvR = DidZH6E0pJelcU9xMCBgyL2KvR.replace('=0','=')
	return DidZH6E0pJelcU9xMCBgyL2KvR
vIZKhbfsXmWAyUVecrNOz95LQ = []
lWF7u5qUtSak3B = []
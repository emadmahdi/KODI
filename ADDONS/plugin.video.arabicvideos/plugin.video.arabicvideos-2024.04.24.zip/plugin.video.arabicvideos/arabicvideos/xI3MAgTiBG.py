﻿# -*- coding: utf-8 -*-
from G6AHskJeqN import *
def VbgEajY4Bt2COpGDcPqI(H3HDqY5N4e0fWSXMikZ8CR7suUmJdx,zkGQSJENa5KuoiwvVMDRr):
	if zkGQSJENa5KuoiwvVMDRr=='': return
	if H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==1:
		ClfuYvb0GwZLUtx63Fg = XUYb0K2ghSyFs.getCurrentWindowDialogId()
		r8HR9PyejhDbvO = XUYb0K2ghSyFs.Window(ClfuYvb0GwZLUtx63Fg)
		zkGQSJENa5KuoiwvVMDRr = oQtFm9gzcADuxa(zkGQSJENa5KuoiwvVMDRr)
		r8HR9PyejhDbvO.getControl(311).setLabel(zkGQSJENa5KuoiwvVMDRr)
	if H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==0:
		EAdbsmyiqLtjhPlxG='X'
		if BLz7m2RkNrxXQwy1cGAp: c9c3TMGoX7jUt20JSWevLDRmF = isinstance(zkGQSJENa5KuoiwvVMDRr,str)
		else: c9c3TMGoX7jUt20JSWevLDRmF = isinstance(zkGQSJENa5KuoiwvVMDRr,unicode)
		if c9c3TMGoX7jUt20JSWevLDRmF==True: EAdbsmyiqLtjhPlxG='U'
		UUt4EJgO36FdDvyxkC2jVbmu=str(type(zkGQSJENa5KuoiwvVMDRr))+' '+zkGQSJENa5KuoiwvVMDRr+' '+EAdbsmyiqLtjhPlxG+' '
		for FVW0I9sYcAjmDgn8r in range(0,len(zkGQSJENa5KuoiwvVMDRr),1):
			UUt4EJgO36FdDvyxkC2jVbmu += hex(ord(zkGQSJENa5KuoiwvVMDRr[FVW0I9sYcAjmDgn8r])).replace('0x','')+' '
		zkGQSJENa5KuoiwvVMDRr = oQtFm9gzcADuxa(zkGQSJENa5KuoiwvVMDRr)
		EAdbsmyiqLtjhPlxG='X'
		if BLz7m2RkNrxXQwy1cGAp: c9c3TMGoX7jUt20JSWevLDRmF = isinstance(zkGQSJENa5KuoiwvVMDRr, str)
		else: c9c3TMGoX7jUt20JSWevLDRmF = isinstance(zkGQSJENa5KuoiwvVMDRr, unicode)
		if c9c3TMGoX7jUt20JSWevLDRmF==True: EAdbsmyiqLtjhPlxG='U'
		GY9kFH41Mcr0b7=str(type(zkGQSJENa5KuoiwvVMDRr))+' '+zkGQSJENa5KuoiwvVMDRr+' '+EAdbsmyiqLtjhPlxG+' '
		for FVW0I9sYcAjmDgn8r in range(0,len(zkGQSJENa5KuoiwvVMDRr),1):
			GY9kFH41Mcr0b7 += hex(ord(zkGQSJENa5KuoiwvVMDRr[FVW0I9sYcAjmDgn8r])).replace('0x','')+' '
	return
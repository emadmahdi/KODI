# -*- coding: utf-8 -*-
from G6AHskJeqN import *
baNWS6nfqTC5iX4Kl = 'SERIES4WATCH'
headers = { 'User-Agent' : '' }
teUPLFC3B8bArakwHVGsdhoIWDM49f = '_SFW_'
EZxQp1WOldMTvFU = AK5RqLhji4W1wt9VdrCD3PGeQM[baNWS6nfqTC5iX4Kl][0]
def VbgEajY4Bt2COpGDcPqI(mode,url,text):
	if   mode==210: ft3e2JBKQVXWlFPjaMhkEqGxvDg = eN02L7Tf5bQ()
	elif mode==211: ft3e2JBKQVXWlFPjaMhkEqGxvDg = sscM839DP1jWZ4zl6uIx0Kyn(url)
	elif mode==212: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HDxCnPKFhITpZmOsA4a0UL6(url)
	elif mode==213: ft3e2JBKQVXWlFPjaMhkEqGxvDg = o4oY13v5dWMcbilEDjKCnXNzHZ0(url)
	elif mode==214: ft3e2JBKQVXWlFPjaMhkEqGxvDg = wZjyoeJMUF(url)
	elif mode==215: ft3e2JBKQVXWlFPjaMhkEqGxvDg = qfhbD7JKinLvFNR5tsuHEATpeyS(url)
	elif mode==218: ft3e2JBKQVXWlFPjaMhkEqGxvDg = uGsCteIibkFrvzdZ()
	elif mode==219: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HjZcUIVAXFCqy9TfBWKtgY2(text)
	else: ft3e2JBKQVXWlFPjaMhkEqGxvDg = False
	return ft3e2JBKQVXWlFPjaMhkEqGxvDg
def uGsCteIibkFrvzdZ():
	message = 'هذا الموقع تغير بالكامل ... وبحاجة الى اعادة برمجة من الصفر ... والمبرمج حاليا مشغول ويعاني من وعكة صحية ... ولهذا سوف يبقى الموقع مغلق الى ما شاء الله'
	ZIOHgA3z0TBR('','','رسالة من المبرمج','الموقع تغير بالكامل',message)
	return
def eN02L7Tf5bQ():
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'بحث في الموقع','',219,'','','_REMEMBERRESULTS_')
	url = EZxQp1WOldMTvFU+'/getpostsPin?type=one&data=pin&limit=25'
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'المميزة',url,211)
	MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(IIiPCruL6dT8s1lqj47SzpVHnYNm,EZxQp1WOldMTvFU,'',headers,'','SERIES4WATCH-MENU-1st')
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('FiltersButtons(.*?)</div>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	vsptNMP2ZQC = XBuP6Op7y4K[0]
	items = My7Dwqvs6bfGNSIgX.findall('data-get="(.*?)".*?</i>(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	for BoEFz2WhUyvTgDeiZ,title in items:
		url = EZxQp1WOldMTvFU+'/getposts?type=one&data='+BoEFz2WhUyvTgDeiZ
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+title,url,211)
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('navigation-menu(.*?)</div>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	vsptNMP2ZQC = XBuP6Op7y4K[0]
	items = My7Dwqvs6bfGNSIgX.findall('href="(http.*?)">(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	eh2tDvRFWpLQI = ['مسلسلات انمي','الرئيسية']
	for BoEFz2WhUyvTgDeiZ,title in items:
		title = title.strip(' ')
		if not any(WoFrX46wzbCNp18 in title for WoFrX46wzbCNp18 in eh2tDvRFWpLQI):
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,211)
	return MK6ZT2zjC1SbmveNFqor
def sscM839DP1jWZ4zl6uIx0Kyn(url):
	MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(UuEtImzir9,url,'',headers,'','SERIES4WATCH-TITLES-1st')
	if 'getposts' in url or '/search?s=' in url: vsptNMP2ZQC = MK6ZT2zjC1SbmveNFqor
	else:
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('MediaGrid"(.*?)class="pagination"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if XBuP6Op7y4K: vsptNMP2ZQC = XBuP6Op7y4K[0]
		else: return
	items = My7Dwqvs6bfGNSIgX.findall('src="(.*?)".*?href="(.*?)".*?<h3>(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	y7y3d5Fbhv42ONmtwLZ0SerYoQq = []
	sMFW9ecd2nE = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for IcWzVO137wFvemn2QTq8yKs9,BoEFz2WhUyvTgDeiZ,title in items:
		if '/series/' in BoEFz2WhUyvTgDeiZ: continue
		BoEFz2WhUyvTgDeiZ = XnQbsZF0Ouh8p7zCdUN(BoEFz2WhUyvTgDeiZ).strip('/')
		title = PIfAumbGicwg5ye(title)
		title = title.strip(' ')
		if '/film/' in BoEFz2WhUyvTgDeiZ or any(WoFrX46wzbCNp18 in title for WoFrX46wzbCNp18 in sMFW9ecd2nE):
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,212,IcWzVO137wFvemn2QTq8yKs9)
		elif '/episode/' in BoEFz2WhUyvTgDeiZ and 'الحلقة' in title:
			ffhN7jAqe3Q4cR0Ukptzl = My7Dwqvs6bfGNSIgX.findall('(.*?) الحلقة \d+',title,My7Dwqvs6bfGNSIgX.DOTALL)
			if ffhN7jAqe3Q4cR0Ukptzl:
				title = '_MOD_' + ffhN7jAqe3Q4cR0Ukptzl[0]
				if title not in y7y3d5Fbhv42ONmtwLZ0SerYoQq:
					VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,213,IcWzVO137wFvemn2QTq8yKs9)
					y7y3d5Fbhv42ONmtwLZ0SerYoQq.append(title)
		else: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,213,IcWzVO137wFvemn2QTq8yKs9)
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('class="pagination(.*?)</div>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('<a href=["\'](http.*?)["\'].*?>(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title in items:
			BoEFz2WhUyvTgDeiZ = PIfAumbGicwg5ye(BoEFz2WhUyvTgDeiZ)
			title = PIfAumbGicwg5ye(title)
			title = title.replace('الصفحة ','')
			if title!='': VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'صفحة '+title,BoEFz2WhUyvTgDeiZ,211)
	return
def o4oY13v5dWMcbilEDjKCnXNzHZ0(url):
	O8OjLhe4VU7GEtKJwSA5zH9ZX,items,NbVDfM1PIpcZ = -1,[],[]
	MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(UuEtImzir9,url,'',headers,'','SERIES4WATCH-EPISODES-1st')
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('ti-list-numbered(.*?)</div>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		xAcIatGBYy0FLXroS1ig3Ts9KZ8P5 = ''.join(XBuP6Op7y4K)
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)"',xAcIatGBYy0FLXroS1ig3Ts9KZ8P5,My7Dwqvs6bfGNSIgX.DOTALL)
	items.append(url)
	items = set(items)
	for BoEFz2WhUyvTgDeiZ in items:
		BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ.strip('/')
		title = '_MOD_' + BoEFz2WhUyvTgDeiZ.split('/')[-1].replace('-',' ')
		aaBsTFzpoyDlh3EiMZWnYPqc7w = My7Dwqvs6bfGNSIgX.findall('الحلقة-(\d+)',BoEFz2WhUyvTgDeiZ.split('/')[-1],My7Dwqvs6bfGNSIgX.DOTALL)
		if aaBsTFzpoyDlh3EiMZWnYPqc7w: aaBsTFzpoyDlh3EiMZWnYPqc7w = aaBsTFzpoyDlh3EiMZWnYPqc7w[0]
		else: aaBsTFzpoyDlh3EiMZWnYPqc7w = '0'
		NbVDfM1PIpcZ.append([BoEFz2WhUyvTgDeiZ,title,aaBsTFzpoyDlh3EiMZWnYPqc7w])
	items = sorted(NbVDfM1PIpcZ, reverse=False, key=lambda key: int(key[2]))
	T7BCAQskW8DVoOXJ = str(items).count('/season/')
	O8OjLhe4VU7GEtKJwSA5zH9ZX = str(items).count('/episode/')
	if T7BCAQskW8DVoOXJ>1 and O8OjLhe4VU7GEtKJwSA5zH9ZX>0 and '/season/' not in url:
		for BoEFz2WhUyvTgDeiZ,title,aaBsTFzpoyDlh3EiMZWnYPqc7w in items:
			if '/season/' in BoEFz2WhUyvTgDeiZ: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,213)
	else:
		for BoEFz2WhUyvTgDeiZ,title,aaBsTFzpoyDlh3EiMZWnYPqc7w in items:
			if '/season/' not in BoEFz2WhUyvTgDeiZ: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,212)
	return
def HDxCnPKFhITpZmOsA4a0UL6(url):
	QQ2cE1FjUyxPonbDhaTkV6B3i = []
	tuHzpfZmLAdCObQS2k3 = url.split('/')
	MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(IIiPCruL6dT8s1lqj47SzpVHnYNm,url,'',headers,'','SERIES4WATCH-PLAY-1st')
	if '/watch/' in MK6ZT2zjC1SbmveNFqor:
		bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = url.replace(tuHzpfZmLAdCObQS2k3[3],'watch')
		wN6n7OZBoDkTvCi8LdbJjYV = YY0KEWamSIc46n3kbtuLgZV(IIiPCruL6dT8s1lqj47SzpVHnYNm,bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,'',headers,'','SERIES4WATCH-PLAY-2nd')
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('class="servers-list(.*?)</div>',wN6n7OZBoDkTvCi8LdbJjYV,My7Dwqvs6bfGNSIgX.DOTALL)
		if XBuP6Op7y4K:
			vsptNMP2ZQC = XBuP6Op7y4K[0]
			items = My7Dwqvs6bfGNSIgX.findall('data-embedd="(.*?)".*?server_image">\n(.*?)\n',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
			if items:
				id = My7Dwqvs6bfGNSIgX.findall('post_id=(.*?)"',wN6n7OZBoDkTvCi8LdbJjYV,My7Dwqvs6bfGNSIgX.DOTALL)
				if id:
					cyRC5wYOFEPj9T = id[0]
					for BoEFz2WhUyvTgDeiZ,title in items:
						BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU+'/?postid='+cyRC5wYOFEPj9T+'&serverid='+BoEFz2WhUyvTgDeiZ+'?named='+title+'__watch'
						QQ2cE1FjUyxPonbDhaTkV6B3i.append(BoEFz2WhUyvTgDeiZ)
			else:
				items = My7Dwqvs6bfGNSIgX.findall('data-embedd=".*?(http.*?)("|&quot;)',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
				for BoEFz2WhUyvTgDeiZ,wLWTRZQNlpACcvdFU3Vo in items:
					QQ2cE1FjUyxPonbDhaTkV6B3i.append(BoEFz2WhUyvTgDeiZ)
	if '/download/' in MK6ZT2zjC1SbmveNFqor:
		bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = url.replace(tuHzpfZmLAdCObQS2k3[3],'download')
		wN6n7OZBoDkTvCi8LdbJjYV = YY0KEWamSIc46n3kbtuLgZV(IIiPCruL6dT8s1lqj47SzpVHnYNm,bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,'',headers,'','SERIES4WATCH-PLAY-3rd')
		id = My7Dwqvs6bfGNSIgX.findall('postId:"(.*?)"',wN6n7OZBoDkTvCi8LdbJjYV,My7Dwqvs6bfGNSIgX.DOTALL)
		if id:
			cyRC5wYOFEPj9T = id[0]
			eIL9BxdTbZj = { 'User-Agent':'' , 'X-Requested-With':'XMLHttpRequest' }
			bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = EZxQp1WOldMTvFU + '/ajaxCenter?_action=getdownloadlinks&postId='+cyRC5wYOFEPj9T
			wN6n7OZBoDkTvCi8LdbJjYV = YY0KEWamSIc46n3kbtuLgZV(IIiPCruL6dT8s1lqj47SzpVHnYNm,bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,'',eIL9BxdTbZj,'','SERIES4WATCH-PLAY-4th')
			XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('<h3.*?(\d+)(.*?)</div>',wN6n7OZBoDkTvCi8LdbJjYV,My7Dwqvs6bfGNSIgX.DOTALL)
			if XBuP6Op7y4K:
				for SSxUv8rOzuNeC4y53K,vsptNMP2ZQC in XBuP6Op7y4K:
					items = My7Dwqvs6bfGNSIgX.findall('<td>(.*?)<.*?href="(.*?)"',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
					for name,BoEFz2WhUyvTgDeiZ in items:
						QQ2cE1FjUyxPonbDhaTkV6B3i.append(BoEFz2WhUyvTgDeiZ+'?named='+name+'__download'+'____'+SSxUv8rOzuNeC4y53K)
			else:
				XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('<h6(.*?)</table>',wN6n7OZBoDkTvCi8LdbJjYV,My7Dwqvs6bfGNSIgX.DOTALL)
				if not XBuP6Op7y4K: XBuP6Op7y4K = [wN6n7OZBoDkTvCi8LdbJjYV]
				for vsptNMP2ZQC in XBuP6Op7y4K:
					name = ''
					items = My7Dwqvs6bfGNSIgX.findall('href="(http.*?)"',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
					for BoEFz2WhUyvTgDeiZ in items:
						LkVZrOE4XBSN2Qex5PyHqC = '&&' + BoEFz2WhUyvTgDeiZ.split('/')[2].lower() + '&&'
						LkVZrOE4XBSN2Qex5PyHqC = LkVZrOE4XBSN2Qex5PyHqC.replace('.com&&','').replace('.co&&','')
						LkVZrOE4XBSN2Qex5PyHqC = LkVZrOE4XBSN2Qex5PyHqC.replace('.net&&','').replace('.org&&','')
						LkVZrOE4XBSN2Qex5PyHqC = LkVZrOE4XBSN2Qex5PyHqC.replace('.live&&','').replace('.online&&','')
						LkVZrOE4XBSN2Qex5PyHqC = LkVZrOE4XBSN2Qex5PyHqC.replace('&&hd.','').replace('&&www.','')
						LkVZrOE4XBSN2Qex5PyHqC = LkVZrOE4XBSN2Qex5PyHqC.replace('&&','')
						BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ + '?named=' + name + LkVZrOE4XBSN2Qex5PyHqC + '__download'
						QQ2cE1FjUyxPonbDhaTkV6B3i.append(BoEFz2WhUyvTgDeiZ)
	import t1kDWXQVpC
	t1kDWXQVpC.rqVt2xDi7jzJHBcPMRs6h0L(QQ2cE1FjUyxPonbDhaTkV6B3i,baNWS6nfqTC5iX4Kl,'video',url)
	return
def HjZcUIVAXFCqy9TfBWKtgY2(search):
	search,LQf3AeozSrai,showDialogs = X54MLovbG8nAEkB9J(search)
	if search=='': search = ViKAIsLurq83RSENayxWb()
	if search=='': return
	search = search.replace(' ','+')
	url = EZxQp1WOldMTvFU + '/search?s='+search
	sscM839DP1jWZ4zl6uIx0Kyn(url)
	return
# -*- coding: utf-8 -*-
import sys as ehpURIi6QBDOGu8qj5EYzXrsWHJ7
hEJlvpt9LRO = ehpURIi6QBDOGu8qj5EYzXrsWHJ7.version_info [0] == 2
RrwvuxJ2OXsWnE9fzYNPDqS = 2048
pS1kDZ93ogBi50Hm7elLhEcyFfTx = 7
def E6Xo0wuA9fdQKlGOI (Ovquk0bMSPEL1ciQ73BJ2Ae):
	global Xb8HYvTBqV5RFAhE3KwMjC
	G4LMt9nR3Se6xWNpPuJd = ord (Ovquk0bMSPEL1ciQ73BJ2Ae [-1])
	qkDvfXryhi7cSz5Ee4AtVn0 = Ovquk0bMSPEL1ciQ73BJ2Ae [:-1]
	FEcyWfSHeL5Kotpx = G4LMt9nR3Se6xWNpPuJd % len (qkDvfXryhi7cSz5Ee4AtVn0)
	FPhirCoHEGw3I05B = qkDvfXryhi7cSz5Ee4AtVn0 [:FEcyWfSHeL5Kotpx] + qkDvfXryhi7cSz5Ee4AtVn0 [FEcyWfSHeL5Kotpx:]
	if hEJlvpt9LRO:
		ffWep5hGgyVTXHL1SM = unicode () .join ([unichr (ord (DDX7Qar0kqlIAKHdwnEh) - RrwvuxJ2OXsWnE9fzYNPDqS - (XapSRJwDcy5TEK0QHZr6n + G4LMt9nR3Se6xWNpPuJd) % pS1kDZ93ogBi50Hm7elLhEcyFfTx) for XapSRJwDcy5TEK0QHZr6n, DDX7Qar0kqlIAKHdwnEh in enumerate (FPhirCoHEGw3I05B)])
	else:
		ffWep5hGgyVTXHL1SM = str () .join ([chr (ord (DDX7Qar0kqlIAKHdwnEh) - RrwvuxJ2OXsWnE9fzYNPDqS - (XapSRJwDcy5TEK0QHZr6n + G4LMt9nR3Se6xWNpPuJd) % pS1kDZ93ogBi50Hm7elLhEcyFfTx) for XapSRJwDcy5TEK0QHZr6n, DDX7Qar0kqlIAKHdwnEh in enumerate (FPhirCoHEGw3I05B)])
	return eval (ffWep5hGgyVTXHL1SM)
fY5wTlhtnOc0Er6sdy4k87b,C2jP0iLNGKnHu9xp,UnWjVbo503mEMv9KF=E6Xo0wuA9fdQKlGOI,E6Xo0wuA9fdQKlGOI,E6Xo0wuA9fdQKlGOI
jx7s8T0BFgODXLMzIYedf,UxS67uoGThbMwnfNRzy4gajLd23JH,QynMHGWA0blfqTUdxRh5Jzi2t=UnWjVbo503mEMv9KF,C2jP0iLNGKnHu9xp,fY5wTlhtnOc0Er6sdy4k87b
jSu5Cg2Ub1OAkZVs8Yoz,V2RbfGOBdcA6l8NTsPWzEyvS7,LgpdP3UjFRnlX=QynMHGWA0blfqTUdxRh5Jzi2t,UxS67uoGThbMwnfNRzy4gajLd23JH,jx7s8T0BFgODXLMzIYedf
gItVahxL0w,BmcLzCFjuIrZP5fwXH18aN6YS,qbPw1d3KimF=LgpdP3UjFRnlX,V2RbfGOBdcA6l8NTsPWzEyvS7,jSu5Cg2Ub1OAkZVs8Yoz
EAc8h2sINroQYvR3WH06Ji7MVpn,vvHpKfcqRnrFzjG,l0WAe1f7Bpi5ZXk=qbPw1d3KimF,BmcLzCFjuIrZP5fwXH18aN6YS,gItVahxL0w
YB5xyI7MaRslVpv,PPNA7jWqZgDnXKVvtuai1kQdsEoMb0,BK9OvRSjZbtx7kYyop1u6zrE2QeiFI=l0WAe1f7Bpi5ZXk,vvHpKfcqRnrFzjG,EAc8h2sINroQYvR3WH06Ji7MVpn
sRth5giAQzWlEVm7JOX,WMkAjB1RgN7q,NVS30xAdRFMIw1n9CislkE2=BK9OvRSjZbtx7kYyop1u6zrE2QeiFI,PPNA7jWqZgDnXKVvtuai1kQdsEoMb0,YB5xyI7MaRslVpv
NB6ZDMqe91yfKQ240WpbIntjxiY5z,k5dztomYyN3H,T6wRistc1SCo4hqObgumK=NVS30xAdRFMIw1n9CislkE2,WMkAjB1RgN7q,sRth5giAQzWlEVm7JOX
RqldvxFuM5GEQ2HAz93o7afBb0,rbjsM8cRFiuA1,nr5mZG89ICi6cgt4MfLJa0=T6wRistc1SCo4hqObgumK,k5dztomYyN3H,NB6ZDMqe91yfKQ240WpbIntjxiY5z
hhlbF1Sns5TrEN8QPCYmL4,FGDJwkEbTB5SoXujs3f,BoWHNb9daQVCF16A=nr5mZG89ICi6cgt4MfLJa0,rbjsM8cRFiuA1,RqldvxFuM5GEQ2HAz93o7afBb0
v5EA6TqHX3s4jzBMk,C2dgEDAKQGsvh,b05yftsZ6NYgIKP=BoWHNb9daQVCF16A,FGDJwkEbTB5SoXujs3f,hhlbF1Sns5TrEN8QPCYmL4
from G6AHskJeqN import *
baNWS6nfqTC5iX4Kl = fY5wTlhtnOc0Er6sdy4k87b(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪṅ")
h1CAK9wMq4GWjba = []
headers = {NVS30xAdRFMIw1n9CislkE2(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬṆ"):gItVahxL0w(u"ࠩࠪṇ")}
EEh3J5FH7RYLgVxyPoBfwO = [BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠪࡅࡐ࡝ࡁࡎࠩṈ"),b05yftsZ6NYgIKP(u"ࠫࡘࡎࡏࡐࡈࡐࡅ࡝࠭ṉ"),sRth5giAQzWlEVm7JOX(u"ࠬࡏࡆࡊࡎࡐࠫṊ"),FGDJwkEbTB5SoXujs3f(u"࠭ࡋࡂࡔࡅࡅࡑࡇࡔࡗࠩṋ"),NVS30xAdRFMIw1n9CislkE2(u"ࠧࡂࡎࡐࡅࡆࡘࡅࡇࠩṌ"),V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠨࡕࡋࡍࡆ࡜ࡏࡊࡅࡈࠫṍ"),gItVahxL0w(u"ࠩࡌࡔ࡙࡜ࠧṎ"),LgpdP3UjFRnlX(u"ࠪࡑ࠸࡛ࠧṏ")]
def rqVt2xDi7jzJHBcPMRs6h0L(Qki8AbTHYjzM2Ls76Gdr3eqo1Wn,source,type,url):
	if not Qki8AbTHYjzM2Ls76Gdr3eqo1Wn:
		Lmj1pfQk63XdoeH(LgpdP3UjFRnlX(u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩṐ"),Dwl0N6FKuVU8nB1mbisIrCzdO(baNWS6nfqTC5iX4Kl)+v5EA6TqHX3s4jzBMk(u"ࠬࠦࠠࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡨ࡬ࡲࡩ࡯࡮ࡨࠢࡹ࡭ࡩ࡫࡯ࠡࡨ࡬ࡰࡪࡹࠠࠡࠢࠣࡗ࡮ࡺࡥ࠻ࠢ࡞ࠤࠬṑ")+source+k5dztomYyN3H(u"࠭ࠠ࡞ࠢࠣࠤ࡚ࠥࡹࡱࡧ࠽ࠤࡠࠦࠧṒ")+type+hhlbF1Sns5TrEN8QPCYmL4(u"ࠧࠡ࡟ࠪṓ"))
		Ojefy76ABiX8TPqcDdxKzvZu2nCVRS = zPgNsqpJInt(RnqtMUa9Nh6peGEsBT,rbjsM8cRFiuA1(u"ࠨࡦ࡬ࡧࡹ࠭Ṕ"),NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬṕ"),l0WAe1f7Bpi5ZXk(u"ࠪࡗࡎ࡚ࡅࡔࡡࡈࡖࡗࡕࡒࡔࠩṖ"))
		CqbNIloiZf6MWEeRL = KBxPW9cX8dqtaUDG.strftime(QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠫࠪ࡟࠮ࠦ࡯࠱ࠩࡩࠦࠥࡉ࠼ࠨࡑࠬṗ"),KBxPW9cX8dqtaUDG.gmtime(SGB7KzblUa4gCZD1srqc))
		PcOUYpACoRnGhSWdiJV = CqbNIloiZf6MWEeRL,url
		key = source+NVS30xAdRFMIw1n9CislkE2(u"ࠬࠦࠠࠡࠢࠪṘ")+RhVj0vAt5kPHm+jSu5Cg2Ub1OAkZVs8Yoz(u"࠭ࠠࠡࠢࠣࠫṙ")+str(YSomBdvcNUMF3b8JDiCfrVW)
		mR4VLhryYT2koGU6iBX = BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠧࠨṚ")
		if key not in list(Ojefy76ABiX8TPqcDdxKzvZu2nCVRS.keys()): Ojefy76ABiX8TPqcDdxKzvZu2nCVRS[key] = [PcOUYpACoRnGhSWdiJV]
		else:
			if url not in str(Ojefy76ABiX8TPqcDdxKzvZu2nCVRS[key]): Ojefy76ABiX8TPqcDdxKzvZu2nCVRS[key].append(PcOUYpACoRnGhSWdiJV)
			else: mR4VLhryYT2koGU6iBX = PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠨ࡞ࡱࠤ์ึวࠡษ็ๅ๏ี๊้่ࠢ์ั๎ฯࠡใํࠤ็อฦๆหࠣห้็๊ะ์๋๋ฬะࠠศๆอ๎๊ࠥๅࠡฬ฼้้࠭ṛ")
		vvV2rFwRIb0e = k5dztomYyN3H(u"࠵ླྀ")
		for key in list(Ojefy76ABiX8TPqcDdxKzvZu2nCVRS.keys()):
			Ojefy76ABiX8TPqcDdxKzvZu2nCVRS[key] = list(set(Ojefy76ABiX8TPqcDdxKzvZu2nCVRS[key]))
			vvV2rFwRIb0e += len(Ojefy76ABiX8TPqcDdxKzvZu2nCVRS[key])
		ZIOHgA3z0TBR(C2dgEDAKQGsvh(u"ࠩࠪṜ"),C2jP0iLNGKnHu9xp(u"ࠪࠫṝ"),BoWHNb9daQVCF16A(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧṞ"),l0WAe1f7Bpi5ZXk(u"๊ࠬไฤีไࠤฬ๊ศา่ส้ัࠦไๆࠢํะิࠦๅๅใสฮࠥอไโ์า๎ํ࠭ṟ")+mR4VLhryYT2koGU6iBX+C2jP0iLNGKnHu9xp(u"࠭࡜࡯࡞ࡱࠤู้๊ๅ็ࠣห้ฮั็ษ่ะࠥ๐โ้็ࠣฬัู๋ࠡไสส๊ฯࠠษษ็ๅ๏ี๊้้สฮࠥอไห์่๊๊ࠣࠦอั่ࠣ์อࠠๆๆไหฯࠦแ๋ัํ์ࠥ๎ำ้ใࠣ๎฾ืึࠡ฻็๎่ࠦวๅสิ๊ฬ๋ฬࠡล้ࠤฯืำๅ๊ࠢิ์ࠦวๅไสส๊ฯࠠฦๆ์ࠤฬ๊ๅษำ่ะࠥ฿ๆะ็สࠤ๏฻ศฮࠢ฼ำิํวࠡ࠷ࠣๅ๏ี๊้้สฮࠬṠ")+RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠧ࡝ࡰ࡟ࡲࠬṡ")+QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠨ฻าำࠥอไโ์า๎ํํวหࠢไ๎ࠥอไใษษ้ฮࠦวๅฤ้ࠤ์๎ࠠ࠻ࠢࠣࠫṢ")+str(vvV2rFwRIb0e))
		if vvV2rFwRIb0e>=NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠻ཹ"):
			tLwvQlnjGpWsRVCN1 = mmwySO1P4jnKz5(BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠩࠪṣ"),BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠪࠫṤ"),RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠫࠬṥ"),UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨṦ"),UnWjVbo503mEMv9KF(u"࠭วๅสิ๊ฬ๋ฬࠡฮ่฽่ࠥวว็ฬࠤๆ๐็ศࠢ࠸ࠤๆ๐ฯ๋๊๊หฯࠦไๆࠢํะิࠦวๅสิ๊ฬ๋ฬࠡๆ๊ห๋ࠥไโษอࠤๆ๐ฯ๋๊ࠣ࠲࠳ࠦำ้ใࠣ๎็๎ๅࠡษ็ฬึ์วๆฮࠣห้ศๆࠡส่ืาࠦ็ั้ࠣห้่วว็ฬࠤࡡࡴ࡜࡯๊่ࠢࠥะั๋ัࠣษึูวๅ๊ࠢิ์ࠦวๅไสส๊ฯࠠใส็ࠤู๊อ่ษࠣษ้๏ࠠศๆ่ฬึ๋ฬࠡๆๆ๎ࠥ๐โ้็ࠣห้๋ศา็ฯࠤอ็อึ๊ࠢิ์ࠦวๅใํำ๏๎็ศฬࠣรࠦࠧࠧṧ"))
			if tLwvQlnjGpWsRVCN1==gItVahxL0w(u"࠱ེ"):
				VDyaOQ1KCF3MNBidmj5cUo2rz = rbjsM8cRFiuA1(u"ࠧࠨṨ")
				for key in list(Ojefy76ABiX8TPqcDdxKzvZu2nCVRS.keys()):
					VDyaOQ1KCF3MNBidmj5cUo2rz += nr5mZG89ICi6cgt4MfLJa0(u"ࠨ࡞ࡱࠫṩ")+key
					ZZceaFOs1jAbil = sorted(Ojefy76ABiX8TPqcDdxKzvZu2nCVRS[key],reverse=b05yftsZ6NYgIKP(u"ࡊࡦࡲࡳࡦᄔ"),key=lambda jU5Ya9rztHe2vBEc0nkT8XLZP: jU5Ya9rztHe2vBEc0nkT8XLZP[NVS30xAdRFMIw1n9CislkE2(u"࠱ཻ")])
					for CqbNIloiZf6MWEeRL,url in ZZceaFOs1jAbil:
						VDyaOQ1KCF3MNBidmj5cUo2rz += BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠩ࡟ࡲࠬṪ")+CqbNIloiZf6MWEeRL+YB5xyI7MaRslVpv(u"ࠪࠤࠥࠦࠠࠨṫ")+XnQbsZF0Ouh8p7zCdUN(url)
					VDyaOQ1KCF3MNBidmj5cUo2rz += PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠫࡡࡴ࡜࡯ࠩṬ")
				import gCUboaujSL
				tUEvo5HAfIjZgcdYxNJ8awu = gCUboaujSL.RR8P1CEUq6m(jSu5Cg2Ub1OAkZVs8Yoz(u"ࠬ࡜ࡩࡥࡧࡲࡷࠬṭ"),jx7s8T0BFgODXLMzIYedf(u"࠭ࠧṮ"),WMkAjB1RgN7q(u"ࡋࡧ࡬ࡴࡧᄕ"),BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠧࠨṯ"),b05yftsZ6NYgIKP(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡕࡒࡁ࡚ࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬṰ"),NVS30xAdRFMIw1n9CislkE2(u"ࠩࠪṱ"),VDyaOQ1KCF3MNBidmj5cUo2rz)
				if tUEvo5HAfIjZgcdYxNJ8awu: ZIOHgA3z0TBR(C2jP0iLNGKnHu9xp(u"ࠪࠫṲ"),l0WAe1f7Bpi5ZXk(u"ࠫࠬṳ"),jSu5Cg2Ub1OAkZVs8Yoz(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨṴ"),BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠭สๆࠢส่สืำศๆࠣฬ๋าวฮࠩṵ"))
				else: ZIOHgA3z0TBR(NVS30xAdRFMIw1n9CislkE2(u"ࠧࠨṶ"),sRth5giAQzWlEVm7JOX(u"ࠨࠩṷ"),PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬṸ"),sRth5giAQzWlEVm7JOX(u"ࠪๅู๊สࠡ฻่่๏ฯࠠศๆศีุอไࠨṹ"))
			if tLwvQlnjGpWsRVCN1!=-sRth5giAQzWlEVm7JOX(u"࠳ོ"):
				Ojefy76ABiX8TPqcDdxKzvZu2nCVRS = {}
				qkSCcaj2fg4VO7dl3G9IhJBs5DLx(RnqtMUa9Nh6peGEsBT,FGDJwkEbTB5SoXujs3f(u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧṺ"),UxS67uoGThbMwnfNRzy4gajLd23JH(u"࡙ࠬࡉࡕࡇࡖࡣࡊࡘࡒࡐࡔࡖࠫṻ"))
		if Ojefy76ABiX8TPqcDdxKzvZu2nCVRS: VZ8BTik93OqXLCh0fD7d2KUPpn4mH6(RnqtMUa9Nh6peGEsBT,jx7s8T0BFgODXLMzIYedf(u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩṼ"),qbPw1d3KimF(u"ࠧࡔࡋࡗࡉࡘࡥࡅࡓࡔࡒࡖࡘ࠭ṽ"),Ojefy76ABiX8TPqcDdxKzvZu2nCVRS,BZdvf7MIUxHQc3aCT)
		return
	Qki8AbTHYjzM2Ls76Gdr3eqo1Wn = list(set(Qki8AbTHYjzM2Ls76Gdr3eqo1Wn))
	wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = uov12bnqR9Z5txMjH3Xw(Qki8AbTHYjzM2Ls76Gdr3eqo1Wn,source)
	hYzFivVwnkBcHbXyx6jIA0SeC9Q = str(QQ2cE1FjUyxPonbDhaTkV6B3i).count(rbjsM8cRFiuA1(u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩṾ"))
	ggZYqd4l0O5mPBHDETi2Wxn3zUR = str(QQ2cE1FjUyxPonbDhaTkV6B3i).count(qbPw1d3KimF(u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭ṿ"))
	nn8Lj5NI4S6KbMXsFmEdkCh = len(QQ2cE1FjUyxPonbDhaTkV6B3i)-hYzFivVwnkBcHbXyx6jIA0SeC9Q-ggZYqd4l0O5mPBHDETi2Wxn3zUR
	lu2Kr3451AURVWewToNQzXtF6 = UxS67uoGThbMwnfNRzy4gajLd23JH(u"ู้ࠪอ็ะห࠽ࠫẀ")+str(hYzFivVwnkBcHbXyx6jIA0SeC9Q)+YB5xyI7MaRslVpv(u"ࠫࠥࠦࠠࠡฬะ้๏๊࠺ࠨẁ")+str(ggZYqd4l0O5mPBHDETi2Wxn3zUR)+v5EA6TqHX3s4jzBMk(u"ࠬࠦࠠࠡࠢฦาึ๏࠺ࠨẂ")+str(nn8Lj5NI4S6KbMXsFmEdkCh)
	if not QQ2cE1FjUyxPonbDhaTkV6B3i: FFryOE3KRpiuDQ,ptkR1Tydzs = QynMHGWA0blfqTUdxRh5Jzi2t(u"࠭ࡵ࡯ࡴࡨࡷࡴࡲࡶࡦࡦࠪẃ"),LgpdP3UjFRnlX(u"ࠧࠨẄ")
	else:
		add = l0WAe1f7Bpi5ZXk(u"࠳ཽ")
		if not any(WoFrX46wzbCNp18 in source for WoFrX46wzbCNp18 in EEh3J5FH7RYLgVxyPoBfwO):
			add = jSu5Cg2Ub1OAkZVs8Yoz(u"࠵ཾ")
			QQ2cE1FjUyxPonbDhaTkV6B3i = [v5EA6TqHX3s4jzBMk(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡡࡄࡐࡑࡥࡌࡊࡐࡎࡗࠬẅ")]+list(QQ2cE1FjUyxPonbDhaTkV6B3i)
			wlfZEzuRyYLvrp = [k5dztomYyN3H(u"ࠩไัฺࠦฬๆ์฼ࠤฬ๊ำ๋ำไีฬะࠧẆ")]+list(wlfZEzuRyYLvrp)
		while UnWjVbo503mEMv9KF(u"࡚ࡲࡶࡧᄖ"):
			ptkR1Tydzs,FFryOE3KRpiuDQ = EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠪࠫẇ"),jSu5Cg2Ub1OAkZVs8Yoz(u"ࠫࠬẈ")
			if add and len(QQ2cE1FjUyxPonbDhaTkV6B3i)==v5EA6TqHX3s4jzBMk(u"࠸ྀ"): GOtNfU3xQFkEhPouwA = BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠶ཿ")
			else: GOtNfU3xQFkEhPouwA = CnKwdteDG5BE8MTRhUpYIJm3NLrSgq(lu2Kr3451AURVWewToNQzXtF6,wlfZEzuRyYLvrp)
			if GOtNfU3xQFkEhPouwA==-PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"࠱ཱྀ"): FFryOE3KRpiuDQ = EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠬࡩࡡ࡯ࡥࡨࡰࡪࡪ࡟࠲ࡵࡷࡣࡲ࡫࡮ࡶࠩẉ")
			elif add and GOtNfU3xQFkEhPouwA==EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠱ྂ"):
				FFryOE3KRpiuDQ = V2RbfGOBdcA6l8NTsPWzEyvS7(u"࠭ࡣࡢࡰࡦࡩࡱ࡫ࡤࡠ࠴ࡱࡨࡤࡳࡥ࡯ࡷࠪẊ")
				ft3e2JBKQVXWlFPjaMhkEqGxvDg = LFiN2W4mglpj0G7UBhRY86saJIbe(wlfZEzuRyYLvrp[add:],QQ2cE1FjUyxPonbDhaTkV6B3i[add:],source)
				if ft3e2JBKQVXWlFPjaMhkEqGxvDg:
					vvLUhGQFEDNu1MC = []
					for oVtD9zvkFegZa1S3q,YYhjLTZwP8rN2VioJIM,tTyldokKZNE5r043CDpL,oIbfmcsZaHv4unXF,e8zPRixLCvJmdK7VgsqWHYp9ta in ft3e2JBKQVXWlFPjaMhkEqGxvDg:
						if e8zPRixLCvJmdK7VgsqWHYp9ta: vvLUhGQFEDNu1MC.append((oVtD9zvkFegZa1S3q,YYhjLTZwP8rN2VioJIM,tTyldokKZNE5r043CDpL,oIbfmcsZaHv4unXF,e8zPRixLCvJmdK7VgsqWHYp9ta))
					if vvLUhGQFEDNu1MC: wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i,errors,msjnlSMrQGJ4oLwE2d,NVHrZsqUp2 = zip(*vvLUhGQFEDNu1MC)
					else:
						ZIOHgA3z0TBR(jSu5Cg2Ub1OAkZVs8Yoz(u"ࠧࠨẋ"),C2dgEDAKQGsvh(u"ࠨࠩẌ"),PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬẍ"),BmcLzCFjuIrZP5fwXH18aN6YS(u"่้ࠪษำโࠢ็้ࠥ๐สๆࠢศ๎ัอฯࠡีํีๆืวหࠢฯ๎ิฯࠠโ์๋ࠣีอࠠศๆไ๎ิ๐่ࠡ࠰࠱ࠤาอ่ๅࠢฦ๊ࠥะศฮอࠣ฽๋ࠦ็ัษࠣห้็๊ะ์๋ࠤๆ๐ࠠๆ๊สๆ฾ࠦรฯำ์ࠫẎ"))
						FFryOE3KRpiuDQ = EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫẏ")
						break
					lu2Kr3451AURVWewToNQzXtF6 = FGDJwkEbTB5SoXujs3f(u"ࠬอไิ์ิๅึอสࠡษ็ะ๏ีษࠡࠪࠣࠫẐ")+str(len(QQ2cE1FjUyxPonbDhaTkV6B3i))+hhlbF1Sns5TrEN8QPCYmL4(u"࠭ࠠࠪࠩẑ")
					add = LgpdP3UjFRnlX(u"࠲ྃ")
					continue
			else:
				ft3e2JBKQVXWlFPjaMhkEqGxvDg = LFiN2W4mglpj0G7UBhRY86saJIbe([wlfZEzuRyYLvrp[GOtNfU3xQFkEhPouwA]],[QQ2cE1FjUyxPonbDhaTkV6B3i[GOtNfU3xQFkEhPouwA]],source)
				if ft3e2JBKQVXWlFPjaMhkEqGxvDg:
					title,BoEFz2WhUyvTgDeiZ,errors,msjnlSMrQGJ4oLwE2d,NVHrZsqUp2 = ft3e2JBKQVXWlFPjaMhkEqGxvDg[V2RbfGOBdcA6l8NTsPWzEyvS7(u"࠳྄")]
					if not NVHrZsqUp2 and not any(WoFrX46wzbCNp18 in source for WoFrX46wzbCNp18 in EEh3J5FH7RYLgVxyPoBfwO):
						errors,msjnlSMrQGJ4oLwE2d,NVHrZsqUp2 = b8bSAiymDHPXIWGdYvRg7eth2uTc(title,BoEFz2WhUyvTgDeiZ,source,l0WAe1f7Bpi5ZXk(u"࠴྅"))
						if errors==BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠧࡆ࡚ࡌࡘࡤࡇࡌࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬẒ"): return errors
					if rbjsM8cRFiuA1(u"ࠨีํีๆืࠧẓ") in title and BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠩ࠵้ัํ่ๅ࠴ࠪẔ") in title:
						Lmj1pfQk63XdoeH(UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨẕ"),Dwl0N6FKuVU8nB1mbisIrCzdO(baNWS6nfqTC5iX4Kl)+UnWjVbo503mEMv9KF(u"ࠫࠥࠦࠠࡖࡰ࡮ࡲࡴࡽ࡮ࠡࡵࡨࡰࡪࡩࡴࡦࡦࠣࡷࡪࡸࡶࡦࡴࠣࠤ࡙ࠥࡥࡳࡸࡨࡶ࠿࡛ࠦࠡࠩẖ")+title+V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠬࠦ࡝ࠡࠢࠣࡓࡷ࡯ࡧࡪࡰࡤࡰ࠿࡛ࠦࠡࠩẗ")+BoEFz2WhUyvTgDeiZ+k5dztomYyN3H(u"࠭ࠠ࡞ࠩẘ"))
						import gCUboaujSL
						gCUboaujSL.hDamHMyRj5wPpGSNl()
						FFryOE3KRpiuDQ = C2dgEDAKQGsvh(u"ࠧࡶࡰࡵࡩࡸࡵ࡬ࡷࡧࡧࠫẙ")
					else:
						FFryOE3KRpiuDQ,ptkR1Tydzs,iLIUfJZxbBAvczHmg2a = Jz1AmXNck68IZRpPhtOn7ogvij3(title,BoEFz2WhUyvTgDeiZ,errors,msjnlSMrQGJ4oLwE2d,NVHrZsqUp2,source,type)
			if FFryOE3KRpiuDQ in [FGDJwkEbTB5SoXujs3f(u"ࠨࡇ࡛ࡍ࡙ࡥࡁࡍࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ẚ"),nr5mZG89ICi6cgt4MfLJa0(u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧࠫẛ"),WMkAjB1RgN7q(u"ࠪࡴࡱࡧࡹࡪࡰࡪࠫẜ"),NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠫࡹ࡫ࡳࡵ࡫ࡱ࡫ࠬẝ"),BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠬࡩࡡ࡯ࡥࡨࡰࡪࡪ࡟࠲ࡵࡷࡣࡲ࡫࡮ࡶࠩẞ")] or len(QQ2cE1FjUyxPonbDhaTkV6B3i)==v5EA6TqHX3s4jzBMk(u"࠶྆")+add: break
			elif FFryOE3KRpiuDQ in [BoWHNb9daQVCF16A(u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭ẟ"),rbjsM8cRFiuA1(u"ࠧࡵ࡫ࡰࡩࡴࡻࡴࠨẠ"),vvHpKfcqRnrFzjG(u"ࠨࡶࡵ࡭ࡪࡪࠧạ")]: break
			elif FFryOE3KRpiuDQ not in [gItVahxL0w(u"ࠩࡦࡥࡳࡩࡥ࡭ࡧࡧࡣ࠷ࡴࡤࡠ࡯ࡨࡲࡺ࠭Ả"),BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠪ࡬ࡹࡺࡰࡴࠩả")]:
				if qbPw1d3KimF(u"ࠫࡡࡴࠧẤ") in ptkR1Tydzs: ptkR1Tydzs = FGDJwkEbTB5SoXujs3f(u"ࠬࡡࡌࡆࡈࡗࡡࠥࠦࠧấ")+ptkR1Tydzs.replace(T6wRistc1SCo4hqObgumK(u"࠭࡜࡯ࠩẦ"),BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠧ࡝ࡰ࡞ࡐࡊࡌࡔ࡞ࠢࠣࠫầ"))
				ZIOHgA3z0TBR(vvHpKfcqRnrFzjG(u"ࠨࠩẨ"),jSu5Cg2Ub1OAkZVs8Yoz(u"ࠩࠪẩ"),fY5wTlhtnOc0Er6sdy4k87b(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭Ẫ"),b05yftsZ6NYgIKP(u"ࠫฬ๊ำ๋ำไี๊ࠥๅࠡ์฼้้ࠦฬาสࠣื๏ืแาࠢ฽๎ึํࠧẫ")+fY5wTlhtnOc0Er6sdy4k87b(u"ࠬࡢ࡮ࠨẬ")+ptkR1Tydzs,profile=gItVahxL0w(u"࠭ࡣࡰࡰࡩ࡭ࡷࡳ࡟࡮ࡧࡧ࡭ࡺࡳࡦࡰࡰࡷࠫậ"))
	if FFryOE3KRpiuDQ==LgpdP3UjFRnlX(u"ࠧࡶࡰࡵࡩࡸࡵ࡬ࡷࡧࡧࠫẮ") and len(wlfZEzuRyYLvrp)>b05yftsZ6NYgIKP(u"࠶྇"): ZIOHgA3z0TBR(PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠨࠩắ"),b05yftsZ6NYgIKP(u"ࠩࠪẰ"),NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ằ"),rbjsM8cRFiuA1(u"ุࠫ๐ัโำ๋ࠣีอࠠศๆไ๎ิ๐่ࠡๆ่ࠤ๏฿ๅๅࠢฯีอࠦแ๋ัํ์ࠥเ๊า้ࠪẲ")+BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠬࡢ࡮ࠨẳ")+ptkR1Tydzs,profile=jSu5Cg2Ub1OAkZVs8Yoz(u"࠭ࡣࡰࡰࡩ࡭ࡷࡳ࡟࡮ࡧࡧ࡭ࡺࡳࡦࡰࡰࡷࠫẴ"))
	elif FFryOE3KRpiuDQ in [jx7s8T0BFgODXLMzIYedf(u"ࠧࡧࡣ࡬ࡰࡪࡪࠧẵ"),WMkAjB1RgN7q(u"ࠨࡶ࡬ࡱࡪࡵࡵࡵࠩẶ")] and ptkR1Tydzs!=UnWjVbo503mEMv9KF(u"ࠩࠪặ"): ZIOHgA3z0TBR(jSu5Cg2Ub1OAkZVs8Yoz(u"ࠪࠫẸ"),nr5mZG89ICi6cgt4MfLJa0(u"ࠫࠬẹ"),YB5xyI7MaRslVpv(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨẺ"),ptkR1Tydzs,profile=rbjsM8cRFiuA1(u"࠭ࡣࡰࡰࡩ࡭ࡷࡳ࡟࡮ࡧࡧ࡭ࡺࡳࡦࡰࡰࡷࠫẻ"))
	return FFryOE3KRpiuDQ
NNMBemflctYDdJ,MDNXtTu4bLvxIPW3H,eLvHNniSGkjF6Pdlpy8h9Qs203VTxJ,KcoRaFP3Dz,ppOrKkmPIgVchzof17uSaFi = [],[],[],[],[]
def LFiN2W4mglpj0G7UBhRY86saJIbe(breQmB38nWlfEc6CNT,Qki8AbTHYjzM2Ls76Gdr3eqo1Wn,source):
	global NNMBemflctYDdJ,MDNXtTu4bLvxIPW3H,eLvHNniSGkjF6Pdlpy8h9Qs203VTxJ,KcoRaFP3Dz,ppOrKkmPIgVchzof17uSaFi
	ft3e2JBKQVXWlFPjaMhkEqGxvDg,txr4zOdSyDJCKij3mveUf0XH,new = [],[],[]
	YRi6vEsJ05kd8Bo9UtbpzlVn2(NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࡆࡢ࡮ࡶࡩᄗ"),NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࡆࡢ࡮ࡶࡩᄗ"),NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࡆࡢ࡮ࡶࡩᄗ"))
	count = len(Qki8AbTHYjzM2Ls76Gdr3eqo1Wn)
	for Q0CPUzw94q3eD in range(count):
		NNMBemflctYDdJ.append(None)
		MDNXtTu4bLvxIPW3H.append(None)
		eLvHNniSGkjF6Pdlpy8h9Qs203VTxJ.append(None)
		KcoRaFP3Dz.append(None)
		ppOrKkmPIgVchzof17uSaFi.append(None)
		title = breQmB38nWlfEc6CNT[Q0CPUzw94q3eD]
		BoEFz2WhUyvTgDeiZ = Qki8AbTHYjzM2Ls76Gdr3eqo1Wn[Q0CPUzw94q3eD].strip(BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠧࠡࠩẼ")).strip(RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠨࠨࠪẽ")).strip(fY5wTlhtnOc0Er6sdy4k87b(u"ࠩࡂࠫẾ")).strip(BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠪ࠳ࠬế"))
		if count>YB5xyI7MaRslVpv(u"࠱ྈ"): gj7BGM5t3RZpA0vNixLqzwualb16(NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠫๆำีࠡีํีๆืࠠาไ่ࠤࠥ࠭Ề")+str(Q0CPUzw94q3eD+YB5xyI7MaRslVpv(u"࠱ྈ")),title)
		qPrGaOMd1DyUJ2Ai = BoEFz2WhUyvTgDeiZ.split(EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭ề"),vvHpKfcqRnrFzjG(u"࠲ྉ"))[rbjsM8cRFiuA1(u"࠲ྊ")]
		ZciU8Xb2tEajIg63uRP = zPgNsqpJInt(RnqtMUa9Nh6peGEsBT,jx7s8T0BFgODXLMzIYedf(u"࠭࡬ࡪࡵࡷࠫỂ"),WMkAjB1RgN7q(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡅࠩể"),qPrGaOMd1DyUJ2Ai)
		if ZciU8Xb2tEajIg63uRP and jSu5Cg2Ub1OAkZVs8Yoz(u"ࠨࡃࡎ࡛ࡆࡓࠧỄ") not in source:
			NNMBemflctYDdJ[Q0CPUzw94q3eD] = ZciU8Xb2tEajIg63uRP
		else:
			USEjfFOQeBgVwlNKWhmnP85G = iDocG6BXv7fT2z8UVOxgP.Thread(target=b8bSAiymDHPXIWGdYvRg7eth2uTc,args=(title,BoEFz2WhUyvTgDeiZ,source,Q0CPUzw94q3eD))
			USEjfFOQeBgVwlNKWhmnP85G.start()
			txr4zOdSyDJCKij3mveUf0XH.append(USEjfFOQeBgVwlNKWhmnP85G)
			new.append(Q0CPUzw94q3eD)
			KBxPW9cX8dqtaUDG.sleep(C2jP0iLNGKnHu9xp(u"࠳࠲࠼࠻ྋ"))
	timeout = gItVahxL0w(u"࠺࠵ྌ") if source==NVS30xAdRFMIw1n9CislkE2(u"ࠩࡄࡏ࡜ࡇࡍࠨễ") else l0WAe1f7Bpi5ZXk(u"࠸࠶ྍ")
	for USEjfFOQeBgVwlNKWhmnP85G in txr4zOdSyDJCKij3mveUf0XH: USEjfFOQeBgVwlNKWhmnP85G.join(timeout)
	for Q0CPUzw94q3eD in range(count):
		title = breQmB38nWlfEc6CNT[Q0CPUzw94q3eD]
		BoEFz2WhUyvTgDeiZ = Qki8AbTHYjzM2Ls76Gdr3eqo1Wn[Q0CPUzw94q3eD].strip(FGDJwkEbTB5SoXujs3f(u"ࠪࠤࠬỆ")).strip(fY5wTlhtnOc0Er6sdy4k87b(u"ࠫࠫ࠭ệ")).strip(RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠬࡅࠧỈ")).strip(FGDJwkEbTB5SoXujs3f(u"࠭࠯ࠨỉ"))
		if NNMBemflctYDdJ[Q0CPUzw94q3eD]: ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = NNMBemflctYDdJ[Q0CPUzw94q3eD]
		else: ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠧ࡝ࡰࡉࡥ࡮ࡲࡥࡥ࠼ࠣࠤ࡙࡯࡭ࡦࡱࡸࡸࠥ࠮ࠧỊ")+str(timeout)+k5dztomYyN3H(u"ࠨࠢࡶࡩࡨࡵ࡮ࡥࡵࠬࠫị"),[],[]
		ft3e2JBKQVXWlFPjaMhkEqGxvDg.append([title,BoEFz2WhUyvTgDeiZ,ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i])
		if Q0CPUzw94q3eD in new:
			qPrGaOMd1DyUJ2Ai = BoEFz2WhUyvTgDeiZ.split(gItVahxL0w(u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪỌ"),qbPw1d3KimF(u"࠷ྎ"))[sRth5giAQzWlEVm7JOX(u"࠰ྏ")]
			VZ8BTik93OqXLCh0fD7d2KUPpn4mH6(RnqtMUa9Nh6peGEsBT,rbjsM8cRFiuA1(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡈࠬọ"),qPrGaOMd1DyUJ2Ai,[ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i],UuEtImzir9)
	YRi6vEsJ05kd8Bo9UtbpzlVn2(NVS30xAdRFMIw1n9CislkE2(u"ࠫࠬỎ"),jx7s8T0BFgODXLMzIYedf(u"ࠬ࠭ỏ"),jx7s8T0BFgODXLMzIYedf(u"࠭ࠧỐ"))
	return ft3e2JBKQVXWlFPjaMhkEqGxvDg
def b8bSAiymDHPXIWGdYvRg7eth2uTc(LkVZrOE4XBSN2Qex5PyHqC,url,source,yyeS7VUtoclLQiWxwYMGj1dBvZr):
	global NNMBemflctYDdJ
	Lmj1pfQk63XdoeH(PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠧࡏࡑࡗࡍࡈࡋ࡟ࡍࡋࡑࡉࡘ࠭ố"),Dwl0N6FKuVU8nB1mbisIrCzdO(baNWS6nfqTC5iX4Kl)+FGDJwkEbTB5SoXujs3f(u"ࠨࠢࠣࠤࡗ࡫ࡳࡰ࡮ࡹ࡭ࡳ࡭ࠠࡴࡶࡤࡶࡹ࡫ࡤࠡࠢࠣࡗࡪࡲࡥࡤࡶࡨࡨ࠿࡛ࠦࠡࠩỒ")+LkVZrOE4XBSN2Qex5PyHqC+rbjsM8cRFiuA1(u"ࠩࠣࡡࠥࠦࠠࡐࡴ࡬࡫࡮ࡴࡡ࡭࠼ࠣ࡟ࠥ࠭ồ")+url+BoWHNb9daQVCF16A(u"ࠪࠤࡢ࠭Ổ"))
	BoEFz2WhUyvTgDeiZ,gV3Hz7qe5dcLmF46iub8PX1kKEat = url,NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠫࠬổ")
	YTpvNQm9JW5CbuBxhn1IoUwi86VljS = EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠬࡏࡎࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࠩỖ")
	ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = CXdjtkpE8UOhMJlVZuyWLm2Ivgb(url,source)
	if ptkR1Tydzs==nr5mZG89ICi6cgt4MfLJa0(u"࠭ࡅ࡙ࡋࡗࡣࡆࡒࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫỗ"):
		NNMBemflctYDdJ[yyeS7VUtoclLQiWxwYMGj1dBvZr] = v5EA6TqHX3s4jzBMk(u"ࠧࡆ࡚ࡌࡘࡤࡇࡌࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬỘ"),[],[]
		return NNMBemflctYDdJ[yyeS7VUtoclLQiWxwYMGj1dBvZr]
	elif YB5xyI7MaRslVpv(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫộ") in ptkR1Tydzs:
		gV3Hz7qe5dcLmF46iub8PX1kKEat = fY5wTlhtnOc0Er6sdy4k87b(u"ࠩ࡟ࡲࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦ࠱࠻ࠢࠣࡒࡪ࡫ࡤࠡࡇࡻࡸࡪࡸ࡮ࡢ࡮ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠬỚ")
		BoEFz2WhUyvTgDeiZ = CCcnROiKzWQ7VmjeD2Jg(QQ2cE1FjUyxPonbDhaTkV6B3i)[WMkAjB1RgN7q(u"࠱ྐ")]
		YTpvNQm9JW5CbuBxhn1IoUwi86VljS,gV3Hz7qe5dcLmF46iub8PX1kKEat,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = c0hbFemH7X(gV3Hz7qe5dcLmF46iub8PX1kKEat,BoEFz2WhUyvTgDeiZ,source,yyeS7VUtoclLQiWxwYMGj1dBvZr)
		if gV3Hz7qe5dcLmF46iub8PX1kKEat==BoWHNb9daQVCF16A(u"ࠪࡉ࡝ࡏࡔࡠࡃࡏࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨớ"): return gV3Hz7qe5dcLmF46iub8PX1kKEat,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i
	elif ptkR1Tydzs: gV3Hz7qe5dcLmF46iub8PX1kKEat = jx7s8T0BFgODXLMzIYedf(u"ࠫࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦ࠱࠻ࠢࠣࠫỜ")+ptkR1Tydzs.replace(v5EA6TqHX3s4jzBMk(u"ࠬࡢ࡮ࠨờ"),k5dztomYyN3H(u"࠭ࠧỞ")).replace(UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠧ࡝ࡴࠪở"),gItVahxL0w(u"ࠨࠩỠ"))[:sRth5giAQzWlEVm7JOX(u"࠺࠳ྑ")]
	if QQ2cE1FjUyxPonbDhaTkV6B3i:
		QQ2cE1FjUyxPonbDhaTkV6B3i = CCcnROiKzWQ7VmjeD2Jg(QQ2cE1FjUyxPonbDhaTkV6B3i)
		Lmj1pfQk63XdoeH(rbjsM8cRFiuA1(u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧỡ"),Dwl0N6FKuVU8nB1mbisIrCzdO(baNWS6nfqTC5iX4Kl)+hhlbF1Sns5TrEN8QPCYmL4(u"ࠪࠤࠥࠦࡒࡦࡵࡲࡰࡻ࡯࡮ࡨࠢࡶࡹࡨࡩࡥࡦࡦࡨࡨࠥࠦࠠࡔࡧ࡯ࡩࡨࡺࡥࡥ࠼ࠣ࡟ࠥ࠭Ợ")+LkVZrOE4XBSN2Qex5PyHqC+v5EA6TqHX3s4jzBMk(u"ࠫࠥࡣࠠࠡࠢࡕࡩࡸࡵ࡬ࡷࡧࡵ࠾ࠥࡡࠠࠨợ")+YTpvNQm9JW5CbuBxhn1IoUwi86VljS+l0WAe1f7Bpi5ZXk(u"ࠬࠦ࡝ࠡࠢࠣࡓࡷ࡯ࡧࡪࡰࡤࡰ࠿࡛ࠦࠡࠩỤ")+url+sRth5giAQzWlEVm7JOX(u"࠭ࠠ࡞ࠢࠣࠤࡑ࡯࡮࡬࠼ࠣ࡟ࠥ࠭ụ")+BoEFz2WhUyvTgDeiZ+BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠧࠡ࡟ࠣࠤࠥ࡜ࡩࡥࡧࡲࡷ࠿࡛ࠦࠡࠩỦ")+str(QQ2cE1FjUyxPonbDhaTkV6B3i)+BoWHNb9daQVCF16A(u"ࠨࠢࡠࠫủ"))
	else: Lmj1pfQk63XdoeH(nr5mZG89ICi6cgt4MfLJa0(u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧỨ"),Dwl0N6FKuVU8nB1mbisIrCzdO(baNWS6nfqTC5iX4Kl)+l0WAe1f7Bpi5ZXk(u"ࠪࠤࠥࠦࡒࡦࡵࡲࡰࡻ࡯࡮ࡨࠢࡩࡥ࡮ࡲࡥࡥࠢࠣࠤࡘ࡫࡬ࡦࡥࡷࡩࡩࡀࠠ࡜ࠢࠪứ")+LkVZrOE4XBSN2Qex5PyHqC+k5dztomYyN3H(u"ࠫࠥࡣࠠࠡࠢࡒࡶ࡮࡭ࡩ࡯ࡣ࡯࠾ࠥࡡࠠࠨỪ")+url+jx7s8T0BFgODXLMzIYedf(u"ࠬࠦ࡝ࠡࠢࠣࡐ࡮ࡴ࡫࠻ࠢ࡞ࠤࠬừ")+BoEFz2WhUyvTgDeiZ+C2dgEDAKQGsvh(u"࠭ࠠ࡞ࠢࠣࠤࡊࡸࡲࡰࡴࡶ࠾ࠥࡡࠠࠨỬ")+gV3Hz7qe5dcLmF46iub8PX1kKEat+T6wRistc1SCo4hqObgumK(u"ࠧࠡ࡟ࠪử"))
	gV3Hz7qe5dcLmF46iub8PX1kKEat = XnQbsZF0Ouh8p7zCdUN(gV3Hz7qe5dcLmF46iub8PX1kKEat)
	NNMBemflctYDdJ[yyeS7VUtoclLQiWxwYMGj1dBvZr] = gV3Hz7qe5dcLmF46iub8PX1kKEat,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i
	return gV3Hz7qe5dcLmF46iub8PX1kKEat,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i
def Jz1AmXNck68IZRpPhtOn7ogvij3(title,BoEFz2WhUyvTgDeiZ,ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i,source,type=FGDJwkEbTB5SoXujs3f(u"ࠨࠩỮ")):
	if ptkR1Tydzs==WMkAjB1RgN7q(u"ࠩࡈ࡜ࡎ࡚࡟ࡂࡎࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧữ"): return ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i
	elif QQ2cE1FjUyxPonbDhaTkV6B3i:
		while C2dgEDAKQGsvh(u"ࡕࡴࡸࡩᄘ"):
			if len(QQ2cE1FjUyxPonbDhaTkV6B3i)==jx7s8T0BFgODXLMzIYedf(u"࠴ྒ"): GOtNfU3xQFkEhPouwA = T6wRistc1SCo4hqObgumK(u"࠴ྒྷ")
			else: GOtNfU3xQFkEhPouwA = CnKwdteDG5BE8MTRhUpYIJm3NLrSgq(RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠪหำะัࠡษ็้้็ࠠศๆ่๊ฬูศ࠻ࠩỰ"), wlfZEzuRyYLvrp)
			if GOtNfU3xQFkEhPouwA==-l0WAe1f7Bpi5ZXk(u"࠶ྔ"): FFryOE3KRpiuDQ = C2dgEDAKQGsvh(u"ࠫࡹࡸࡩࡦࡦࠪự")
			else:
				EdVfXaF56Hc = QQ2cE1FjUyxPonbDhaTkV6B3i[GOtNfU3xQFkEhPouwA]
				Lmj1pfQk63XdoeH(LgpdP3UjFRnlX(u"ࠬࡔࡏࡕࡋࡆࡉࡤࡒࡉࡏࡇࡖࠫỲ"),Dwl0N6FKuVU8nB1mbisIrCzdO(baNWS6nfqTC5iX4Kl)+QynMHGWA0blfqTUdxRh5Jzi2t(u"࠭ࠠࠡࠢࡓࡰࡦࡿࡩ࡯ࡩࠣࡷࡹࡧࡲࡵࡧࡧࠤࠥࠦࡓࡦ࡮ࡨࡧࡹ࡫ࡤ࠻ࠢ࡞ࠤࠬỳ")+title+RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠧࠡ࡟ࠣࠤࠥࡕࡲࡪࡩ࡬ࡲࡦࡲ࠺ࠡ࡝ࠣࠫỴ")+BoEFz2WhUyvTgDeiZ+QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠨࠢࡠࠤࠥࠦࡖࡪࡦࡨࡳ࠿࡛ࠦࠡࠩỵ")+str(EdVfXaF56Hc)+FGDJwkEbTB5SoXujs3f(u"ࠩࠣࡡࠬỶ"))
				if T6wRistc1SCo4hqObgumK(u"ࠪࡱࡴࡹࡨࡢࡪࡧࡥ࠳࠭ỷ") in EdVfXaF56Hc and BoWHNb9daQVCF16A(u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩࡥ࡯ࡳ࡫ࡪࠫỸ") in EdVfXaF56Hc:
					Yf6yDJrH1COGRvF2o,XXxkpYnSUfE4A9jMu,iLIUfJZxbBAvczHmg2a = GZkH8K5lz2Ns(EdVfXaF56Hc)
					if iLIUfJZxbBAvczHmg2a: EdVfXaF56Hc = iLIUfJZxbBAvczHmg2a[jx7s8T0BFgODXLMzIYedf(u"࠶ྕ")]
					else: EdVfXaF56Hc = UnWjVbo503mEMv9KF(u"ࠬ࠭ỹ")
				if not EdVfXaF56Hc: FFryOE3KRpiuDQ = C2dgEDAKQGsvh(u"࠭ࡵ࡯ࡴࡨࡷࡴࡲࡶࡦࡦࠪỺ")
				else: FFryOE3KRpiuDQ = B0xcwKkMQ16mpSFRaVHPTzuhUZngLq(EdVfXaF56Hc,source,type)
			if FFryOE3KRpiuDQ in [jSu5Cg2Ub1OAkZVs8Yoz(u"ࠧࡱ࡮ࡤࡽ࡮ࡴࡧࠨỻ"),fY5wTlhtnOc0Er6sdy4k87b(u"ࠨࡶࡨࡷࡹ࡯࡮ࡨࠩỼ"),C2dgEDAKQGsvh(u"ࠩࡦࡥࡳࡩࡥ࡭ࡧࡧࡣ࠷ࡴࡤࡠ࡯ࡨࡲࡺ࠭ỽ")] or len(QQ2cE1FjUyxPonbDhaTkV6B3i)==hhlbF1Sns5TrEN8QPCYmL4(u"࠱ྖ"): break
			elif FFryOE3KRpiuDQ in [RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠪࡪࡦ࡯࡬ࡦࡦࠪỾ"),BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠫࡹ࡯࡭ࡦࡱࡸࡸࠬỿ"),FGDJwkEbTB5SoXujs3f(u"ࠬࡺࡲࡪࡧࡧࠫἀ")]: break
			else: ZIOHgA3z0TBR(YB5xyI7MaRslVpv(u"࠭ࠧἁ"),V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠧࠨἂ"),jSu5Cg2Ub1OAkZVs8Yoz(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫἃ"),sRth5giAQzWlEVm7JOX(u"ࠩส่๊๊แࠡๆ่ࠤ๏฿ๅๅࠢฯีอࠦๅๅใࠣ฾๏ื็ࠨἄ"))
	else:
		FFryOE3KRpiuDQ = rbjsM8cRFiuA1(u"ࠪࡹࡳࡸࡥࡴࡱ࡯ࡺࡪࡪࠧἅ")
		if REGCdFbgy4Vvu2ieLqNMlxntY(BoEFz2WhUyvTgDeiZ): FFryOE3KRpiuDQ = B0xcwKkMQ16mpSFRaVHPTzuhUZngLq(BoEFz2WhUyvTgDeiZ,source,type)
	return FFryOE3KRpiuDQ,ptkR1Tydzs,QQ2cE1FjUyxPonbDhaTkV6B3i
def KFZxhTpVJeqk1uDA(url,source):
	bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,zXrDfUVB51OhtqPKCAIEHlFY,LkVZrOE4XBSN2Qex5PyHqC,yZ1rhb6EugC4,bSxczpUtHewVDKa3EL4lm,type,WK75AGwvEzJZTNLQB1,LLnUyuiC2wRM0,PZjG9QsCtzpMg2TcE = url,qbPw1d3KimF(u"ࠫࠬἆ"),FGDJwkEbTB5SoXujs3f(u"ࠬ࠭ἇ"),NVS30xAdRFMIw1n9CislkE2(u"࠭ࠧἈ"),NVS30xAdRFMIw1n9CislkE2(u"ࠧࠨἉ"),v5EA6TqHX3s4jzBMk(u"ࠨࠩἊ"),qbPw1d3KimF(u"ࠩࠪἋ"),WMkAjB1RgN7q(u"ࠪࠫἌ"),k5dztomYyN3H(u"ࠫࠬἍ")
	if BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭Ἆ") in url:
		bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,zXrDfUVB51OhtqPKCAIEHlFY = url.split(C2dgEDAKQGsvh(u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧἏ"),UnWjVbo503mEMv9KF(u"࠲ྗ"))
		zXrDfUVB51OhtqPKCAIEHlFY = zXrDfUVB51OhtqPKCAIEHlFY+EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠧࡠࡡࠪἐ")+v5EA6TqHX3s4jzBMk(u"ࠨࡡࡢࠫἑ")+C2jP0iLNGKnHu9xp(u"ࠩࡢࡣࠬἒ")+jx7s8T0BFgODXLMzIYedf(u"ࠪࡣࡤ࠭ἓ")+gItVahxL0w(u"ࠫࡤࡥࠧἔ")
		bSxczpUtHewVDKa3EL4lm,type,WK75AGwvEzJZTNLQB1,LLnUyuiC2wRM0,PZjG9QsCtzpMg2TcE,mxM8XR1eQOyYcSkuH, = zXrDfUVB51OhtqPKCAIEHlFY.split(fY5wTlhtnOc0Er6sdy4k87b(u"ࠬࡥ࡟ࠨἕ"))[:vvHpKfcqRnrFzjG(u"࠸྘")]
	if not LLnUyuiC2wRM0: LLnUyuiC2wRM0 = FGDJwkEbTB5SoXujs3f(u"࠭࠰ࠨ἖")
	else: LLnUyuiC2wRM0 = LLnUyuiC2wRM0.replace(gItVahxL0w(u"ࠧࡱࠩ἗"),k5dztomYyN3H(u"ࠨࠩἘ")).replace(YB5xyI7MaRslVpv(u"ࠩࠣࠫἙ"),k5dztomYyN3H(u"ࠪࠫἚ"))
	bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = bJEs4IVAPdyUrhwCLv9k2YoOl8nt1.strip(EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠫࡄ࠭Ἓ")).strip(EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠬ࠵ࠧἜ")).strip(WMkAjB1RgN7q(u"࠭ࠦࠨἝ"))
	LkVZrOE4XBSN2Qex5PyHqC = ooq2D9xF8ZLpPBs(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,YB5xyI7MaRslVpv(u"ࠧࡩࡱࡶࡸࠬ἞"))
	if bSxczpUtHewVDKa3EL4lm: yZ1rhb6EugC4 = bSxczpUtHewVDKa3EL4lm
	else: yZ1rhb6EugC4 = LkVZrOE4XBSN2Qex5PyHqC
	yZ1rhb6EugC4 = ooq2D9xF8ZLpPBs(yZ1rhb6EugC4,UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠨࡰࡤࡱࡪ࠭἟"))
	bSxczpUtHewVDKa3EL4lm = bSxczpUtHewVDKa3EL4lm.replace(C2dgEDAKQGsvh(u"่ࠩฬฬฺัࠨἠ"),RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠪࠫἡ")).replace(EAc8h2sINroQYvR3WH06Ji7MVpn(u"ุࠫ๐ัโำࠪἢ"),hhlbF1Sns5TrEN8QPCYmL4(u"ࠬ࠭ἣ")).replace(gItVahxL0w(u"࠭วๅࠢࠪἤ"),b05yftsZ6NYgIKP(u"ࠧࠡࠩἥ")).replace(EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠨࠢࠣࠫἦ"),YB5xyI7MaRslVpv(u"ࠩࠣࠫἧ"))
	zXrDfUVB51OhtqPKCAIEHlFY = zXrDfUVB51OhtqPKCAIEHlFY.replace(LgpdP3UjFRnlX(u"้ࠪออิาࠩἨ"),rbjsM8cRFiuA1(u"ࠫࠬἩ")).replace(hhlbF1Sns5TrEN8QPCYmL4(u"ู๊ࠬาใิࠫἪ"),nr5mZG89ICi6cgt4MfLJa0(u"࠭ࠧἫ")).replace(T6wRistc1SCo4hqObgumK(u"ࠧศๆࠣࠫἬ"),qbPw1d3KimF(u"ࠨࠢࠪἭ")).replace(vvHpKfcqRnrFzjG(u"ࠩࠣࠤࠬἮ"),C2jP0iLNGKnHu9xp(u"ࠪࠤࠬἯ"))
	yZ1rhb6EugC4 = yZ1rhb6EugC4.replace(rbjsM8cRFiuA1(u"๊ࠫฮวีำࠪἰ"),BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠬ࠭ἱ")).replace(v5EA6TqHX3s4jzBMk(u"࠭ำ๋ำไีࠬἲ"),UnWjVbo503mEMv9KF(u"ࠧࠨἳ")).replace(PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠨษ็ࠤࠬἴ"),BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠩࠣࠫἵ")).replace(nr5mZG89ICi6cgt4MfLJa0(u"ࠪࠤࠥ࠭ἶ"),RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠫࠥ࠭ἷ"))
	return bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,zXrDfUVB51OhtqPKCAIEHlFY,LkVZrOE4XBSN2Qex5PyHqC,yZ1rhb6EugC4,bSxczpUtHewVDKa3EL4lm,type,WK75AGwvEzJZTNLQB1,LLnUyuiC2wRM0,PZjG9QsCtzpMg2TcE
def Rm4GY7530abVwJkUZEe(url,source):
	Z4FpMN1tVgK9LsaJeQ,bSxczpUtHewVDKa3EL4lm,n7F25fCI9B4zDSPoQpW,vSmUFNEZ37ITl9k,wjnoiFvq39XDVUA1uxH46YE,nuqHF7SQ3B8Yz,YTpvNQm9JW5CbuBxhn1IoUwi86VljS = C2dgEDAKQGsvh(u"ࠬ࠭Ἰ"),qbPw1d3KimF(u"࠭ࠧἹ"),None,None,None,None,None
	bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,zXrDfUVB51OhtqPKCAIEHlFY,LkVZrOE4XBSN2Qex5PyHqC,yZ1rhb6EugC4,bSxczpUtHewVDKa3EL4lm,type,WK75AGwvEzJZTNLQB1,LLnUyuiC2wRM0,PZjG9QsCtzpMg2TcE = KFZxhTpVJeqk1uDA(url,source)
	if PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨἺ") in url:
		if   type==jx7s8T0BFgODXLMzIYedf(u"ࠨࡧࡰࡦࡪࡪࠧἻ"): type = b05yftsZ6NYgIKP(u"ࠩࠣࠫἼ")+vvHpKfcqRnrFzjG(u"้ࠪๆ฼ไࠨἽ")
		elif type==v5EA6TqHX3s4jzBMk(u"ࠫࡼࡧࡴࡤࡪࠪἾ"): type = qbPw1d3KimF(u"ࠬࠦࠧἿ")+C2jP0iLNGKnHu9xp(u"࠭ࠥๆึส๋ิฯࠧὀ")
		elif type==qbPw1d3KimF(u"ࠧࡣࡱࡷ࡬ࠬὁ"): type = sRth5giAQzWlEVm7JOX(u"ࠨࠢࠪὂ")+b05yftsZ6NYgIKP(u"ࠩࠨฺ๊ࠩว่ัฬࠤํะอๆ์็ࠫὃ")
		elif type==l0WAe1f7Bpi5ZXk(u"ࠪࡨࡴࡽ࡮࡭ࡱࡤࡨࠬὄ"): type = NVS30xAdRFMIw1n9CislkE2(u"ࠫࠥ࠭ὅ")+PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠬࠫࠥࠦฬะ้๏๊ࠧ὆")
		elif type==WMkAjB1RgN7q(u"࠭ࠧ὇"): type = BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠧࠡࠩὈ")+gItVahxL0w(u"ࠨࠧࠨࠩࠪ࠭Ὁ")
		if WK75AGwvEzJZTNLQB1!=rbjsM8cRFiuA1(u"ࠩࠪὊ"):
			if LgpdP3UjFRnlX(u"ࠪࡱࡵ࠺ࠧὋ") not in WK75AGwvEzJZTNLQB1: WK75AGwvEzJZTNLQB1 = QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠫࠪ࠭Ὄ")+WK75AGwvEzJZTNLQB1
			WK75AGwvEzJZTNLQB1 = YB5xyI7MaRslVpv(u"ࠬࠦࠧὍ")+WK75AGwvEzJZTNLQB1
		if LLnUyuiC2wRM0!=jx7s8T0BFgODXLMzIYedf(u"࠭ࠧ὎"):
			LLnUyuiC2wRM0 = qbPw1d3KimF(u"ࠧࠦࠧࠨࠩࠪࠫࠥࠦࠧࠪ὏")+LLnUyuiC2wRM0
			LLnUyuiC2wRM0 = LgpdP3UjFRnlX(u"ࠨࠢࠪὐ")+LLnUyuiC2wRM0[-UnWjVbo503mEMv9KF(u"࠼ྙ"):]
	if   qbPw1d3KimF(u"ࠩࡄࡏࡔࡇࡍࠨὑ")		in source: nuqHF7SQ3B8Yz	= yZ1rhb6EugC4
	elif qbPw1d3KimF(u"ࠪࡅࡐ࡝ࡁࡎࠩὒ")		in source: n7F25fCI9B4zDSPoQpW	= l0WAe1f7Bpi5ZXk(u"ࠫࡦࡱࡷࡢ࡯ࠪὓ")
	elif qbPw1d3KimF(u"ࠬࡱࡡࡵ࡭ࡲࡹࡹ࡫ࠧὔ")		in LkVZrOE4XBSN2Qex5PyHqC: n7F25fCI9B4zDSPoQpW	= yZ1rhb6EugC4
	elif NVS30xAdRFMIw1n9CislkE2(u"࠭ࡰࡩࡱࡷࡳࡸ࠴ࡡࡱࡲ࠱࡫ࠬὕ")	in LkVZrOE4XBSN2Qex5PyHqC: n7F25fCI9B4zDSPoQpW	= yZ1rhb6EugC4
	elif YB5xyI7MaRslVpv(u"ࠧࡢࡴࡤࡦࡸ࡫ࡥࡥࠩὖ")		in source: n7F25fCI9B4zDSPoQpW	= yZ1rhb6EugC4
	elif b05yftsZ6NYgIKP(u"ࠨࡣ࡯ࡥࡷࡧࡢࠨὗ")		in LkVZrOE4XBSN2Qex5PyHqC: n7F25fCI9B4zDSPoQpW	= yZ1rhb6EugC4
	elif fY5wTlhtnOc0Er6sdy4k87b(u"ࠩࡩࡥࡸ࡫࡬ࠨ὘")		in LkVZrOE4XBSN2Qex5PyHqC: n7F25fCI9B4zDSPoQpW	= yZ1rhb6EugC4
	elif V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠪࡸ࠼ࡳࡥࡦ࡮ࠪὙ")		in LkVZrOE4XBSN2Qex5PyHqC: n7F25fCI9B4zDSPoQpW	= yZ1rhb6EugC4
	elif T6wRistc1SCo4hqObgumK(u"ࠫࡲࡵࡶࡴ࠶ࡸࠫ὚")		in bSxczpUtHewVDKa3EL4lm:   n7F25fCI9B4zDSPoQpW	= yZ1rhb6EugC4
	elif k5dztomYyN3H(u"ࠬࡳࡹࡦࡩࡼࡺ࡮ࡶࠧὛ")		in bSxczpUtHewVDKa3EL4lm:   n7F25fCI9B4zDSPoQpW	= yZ1rhb6EugC4
	elif sRth5giAQzWlEVm7JOX(u"࠭ࡦࡢ࡬ࡨࡶࠬ὜")		in bSxczpUtHewVDKa3EL4lm:   n7F25fCI9B4zDSPoQpW	= yZ1rhb6EugC4
	elif T6wRistc1SCo4hqObgumK(u"ࠧโฮิࠫὝ")			in bSxczpUtHewVDKa3EL4lm:   n7F25fCI9B4zDSPoQpW	= fY5wTlhtnOc0Er6sdy4k87b(u"ࠨࡨࡤ࡮ࡪࡸࠧ὞")
	elif qbPw1d3KimF(u"ࠩไุ่฽๊็ࠩὟ")		in bSxczpUtHewVDKa3EL4lm:   n7F25fCI9B4zDSPoQpW	= V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠪࡴࡦࡲࡥࡴࡶ࡬ࡲࡪ࠭ὠ")
	elif jSu5Cg2Ub1OAkZVs8Yoz(u"ࠫ࡬ࡪࡲࡪࡸࡨࠫὡ")		in bJEs4IVAPdyUrhwCLv9k2YoOl8nt1:   n7F25fCI9B4zDSPoQpW	= jx7s8T0BFgODXLMzIYedf(u"ࠬ࡭࡯ࡰࡩ࡯ࡩࠬὢ")
	elif FGDJwkEbTB5SoXujs3f(u"࠭࡭ࡺࡥ࡬ࡱࡦ࠭ὣ")		in bSxczpUtHewVDKa3EL4lm:   n7F25fCI9B4zDSPoQpW	= yZ1rhb6EugC4
	elif FGDJwkEbTB5SoXujs3f(u"ࠧࡸࡧࡦ࡭ࡲࡧࠧὤ")		in bSxczpUtHewVDKa3EL4lm:   n7F25fCI9B4zDSPoQpW	= yZ1rhb6EugC4
	elif T6wRistc1SCo4hqObgumK(u"ࠨࡥ࡬ࡱࡦࡴ࡯ࡸࠩὥ")		in bSxczpUtHewVDKa3EL4lm:   n7F25fCI9B4zDSPoQpW	= yZ1rhb6EugC4
	elif UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠩࡱࡩࡼࡩࡩ࡮ࡣࠪὦ")		in bSxczpUtHewVDKa3EL4lm:   n7F25fCI9B4zDSPoQpW	= yZ1rhb6EugC4
	elif T6wRistc1SCo4hqObgumK(u"ࠪࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮ࠨὧ")	in LkVZrOE4XBSN2Qex5PyHqC: n7F25fCI9B4zDSPoQpW	= yZ1rhb6EugC4
	elif T6wRistc1SCo4hqObgumK(u"ࠫࡧࡵ࡫ࡳࡣࠪὨ")		in LkVZrOE4XBSN2Qex5PyHqC: n7F25fCI9B4zDSPoQpW	= yZ1rhb6EugC4
	elif WMkAjB1RgN7q(u"ࠬࡺࡶࡧࡷࡱࠫὩ")		in LkVZrOE4XBSN2Qex5PyHqC: n7F25fCI9B4zDSPoQpW	= yZ1rhb6EugC4
	elif k5dztomYyN3H(u"࠭ࡴࡷ࡭ࡶࡥࠬὪ")		in LkVZrOE4XBSN2Qex5PyHqC: n7F25fCI9B4zDSPoQpW	= yZ1rhb6EugC4
	elif fY5wTlhtnOc0Er6sdy4k87b(u"ࠧࡢࡰࡤࡺ࡮ࡪࡺࠨὫ")		in LkVZrOE4XBSN2Qex5PyHqC: n7F25fCI9B4zDSPoQpW	= yZ1rhb6EugC4
	elif V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠨࡵ࡫ࡳࡴ࡬ࡰࡳࡱࠪὬ")		in LkVZrOE4XBSN2Qex5PyHqC: n7F25fCI9B4zDSPoQpW	= yZ1rhb6EugC4
	elif C2jP0iLNGKnHu9xp(u"ࠩࡶ࡬ࡦ࡮ࡩࡥ࠶ࡸࠫὭ")		in LkVZrOE4XBSN2Qex5PyHqC: nuqHF7SQ3B8Yz	= yZ1rhb6EugC4
	elif BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠪࡷ࡭ࡧࡨࡦࡦ࠷ࡹࠬὮ")		in LkVZrOE4XBSN2Qex5PyHqC: nuqHF7SQ3B8Yz	= yZ1rhb6EugC4
	elif qbPw1d3KimF(u"ࠫࡨ࡯࡭ࡢ࠶ࡸࠫὯ")		in LkVZrOE4XBSN2Qex5PyHqC: nuqHF7SQ3B8Yz	= yZ1rhb6EugC4
	elif b05yftsZ6NYgIKP(u"ࠬ࡫ࡧࡺࡰࡲࡻࠬὰ")		in LkVZrOE4XBSN2Qex5PyHqC: nuqHF7SQ3B8Yz	= yZ1rhb6EugC4
	elif EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠭ࡨࡢ࡮ࡤࡧ࡮ࡳࡡࠨά")		in LkVZrOE4XBSN2Qex5PyHqC: nuqHF7SQ3B8Yz	= yZ1rhb6EugC4
	elif l0WAe1f7Bpi5ZXk(u"ࠧࡤ࡫ࡰࡥࡦࡨࡤࡰࠩὲ")		in LkVZrOE4XBSN2Qex5PyHqC: nuqHF7SQ3B8Yz	= yZ1rhb6EugC4
	elif YB5xyI7MaRslVpv(u"ࠨࡻࡲࡹࡹࡻࠧέ")	 	in LkVZrOE4XBSN2Qex5PyHqC: n7F25fCI9B4zDSPoQpW	= fY5wTlhtnOc0Er6sdy4k87b(u"ࠩࡼࡳࡺࡺࡵࡣࡧࠪὴ")
	elif rbjsM8cRFiuA1(u"ࠪࡽ࠷ࡻ࠮ࡣࡧࠪή")	 	in LkVZrOE4XBSN2Qex5PyHqC: n7F25fCI9B4zDSPoQpW	= b05yftsZ6NYgIKP(u"ࠫࡾࡵࡵࡵࡷࡥࡩࠬὶ")
	elif BoWHNb9daQVCF16A(u"ࠬࡪ࠮ࡦࡩࡼࡦࡪࡹࡴ࠯ࡦࠪί")	in LkVZrOE4XBSN2Qex5PyHqC: n7F25fCI9B4zDSPoQpW	= qbPw1d3KimF(u"࠭ࡥࡨࡻࡥࡩࡸࡺࡶࡪࡲࠪὸ")
	elif nr5mZG89ICi6cgt4MfLJa0(u"ࠧࡦࡩࡼ࠲ࡧ࡫ࡳࡵࠩό")		in LkVZrOE4XBSN2Qex5PyHqC: n7F25fCI9B4zDSPoQpW	= jSu5Cg2Ub1OAkZVs8Yoz(u"ࠨࡧࡪࡽࡧ࡫ࡳࡵ࠳ࠪὺ")
	elif v5EA6TqHX3s4jzBMk(u"ࠩࡨ࡫ࡾࡨࡥࡴࡶࠪύ")		in LkVZrOE4XBSN2Qex5PyHqC: n7F25fCI9B4zDSPoQpW	= vvHpKfcqRnrFzjG(u"ࠪࡩ࡬ࡿࡢࡦࡵࡷ࠷ࠬὼ")
	elif fY5wTlhtnOc0Er6sdy4k87b(u"ࠫࡲࡵࡳࡩࡣ࡫ࡨࡦ࠭ώ")		in LkVZrOE4XBSN2Qex5PyHqC: n7F25fCI9B4zDSPoQpW	= hhlbF1Sns5TrEN8QPCYmL4(u"ࠬࡳ࡯ࡴࡪࡤ࡬ࡩࡧࠧ὾")
	elif l0WAe1f7Bpi5ZXk(u"࠭ࡦࡢࡥࡸࡰࡹࡿࡢࡰࡱ࡮ࡷࠬ὿")	in LkVZrOE4XBSN2Qex5PyHqC: n7F25fCI9B4zDSPoQpW	= hhlbF1Sns5TrEN8QPCYmL4(u"ࠧࡧࡣࡦࡹࡱࡺࡹࡣࡱࡲ࡯ࡸ࠭ᾀ")
	elif vvHpKfcqRnrFzjG(u"ࠨ࡫ࡱࡪࡱࡧ࡭࠯ࡥࡦࠫᾁ")	in LkVZrOE4XBSN2Qex5PyHqC: n7F25fCI9B4zDSPoQpW	= NVS30xAdRFMIw1n9CislkE2(u"ࠩ࡬ࡲ࡫ࡲࡡ࡮ࠩᾂ")
	elif NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠪࡦࡺࢀࡺࡷࡴ࡯ࠫᾃ")		in LkVZrOE4XBSN2Qex5PyHqC: n7F25fCI9B4zDSPoQpW	= BoWHNb9daQVCF16A(u"ࠫࡧࡻࡺࡻࡸࡵࡰࠬᾄ")
	elif PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠬࡧࡲࡢࡤ࡯ࡳࡦࡪࡳࠨᾅ")	in LkVZrOE4XBSN2Qex5PyHqC: vSmUFNEZ37ITl9k	= BmcLzCFjuIrZP5fwXH18aN6YS(u"࠭ࡡࡳࡣࡥࡰࡴࡧࡤࡴࠩᾆ")
	elif BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠧࡢࡴࡦ࡬࡮ࡼࡥࠨᾇ")		in LkVZrOE4XBSN2Qex5PyHqC: vSmUFNEZ37ITl9k	= BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠨࡣࡵࡧ࡭࡯ࡶࡦࠩᾈ")
	elif sRth5giAQzWlEVm7JOX(u"ࠩࡦࡥࡹࡩࡨ࠯࡫ࡶࠫᾉ")	 	in LkVZrOE4XBSN2Qex5PyHqC: vSmUFNEZ37ITl9k	= jSu5Cg2Ub1OAkZVs8Yoz(u"ࠪࡧࡦࡺࡣࡩࠩᾊ")
	elif EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠫ࡫࡯࡬ࡦࡴ࡬ࡳࠬᾋ")		in LkVZrOE4XBSN2Qex5PyHqC: vSmUFNEZ37ITl9k	= jSu5Cg2Ub1OAkZVs8Yoz(u"ࠬ࡬ࡩ࡭ࡧࡵ࡭ࡴ࠭ᾌ")
	elif NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠭ࡶࡪࡦࡥࡱࠬᾍ")		in LkVZrOE4XBSN2Qex5PyHqC: vSmUFNEZ37ITl9k	= b05yftsZ6NYgIKP(u"ࠧࡷ࡫ࡧࡦࡲ࠭ᾎ")
	elif vvHpKfcqRnrFzjG(u"ࠨࡸ࡬ࡨ࡭ࡪࠧᾏ")		in LkVZrOE4XBSN2Qex5PyHqC: nuqHF7SQ3B8Yz	= yZ1rhb6EugC4
	elif k5dztomYyN3H(u"ࠩࡰࡽࡻ࡯ࡤࠨᾐ")		in LkVZrOE4XBSN2Qex5PyHqC: nuqHF7SQ3B8Yz	= yZ1rhb6EugC4
	elif BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠪࡱࡾࡼࡩࡪࡦࠪᾑ")		in LkVZrOE4XBSN2Qex5PyHqC: nuqHF7SQ3B8Yz	= yZ1rhb6EugC4
	elif jx7s8T0BFgODXLMzIYedf(u"ࠫࡻ࡯ࡤࡦࡱࡥ࡭ࡳ࠭ᾒ")		in LkVZrOE4XBSN2Qex5PyHqC: vSmUFNEZ37ITl9k	= BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠬࡼࡩࡥࡧࡲࡦ࡮ࡴࠧᾓ")
	elif RqldvxFuM5GEQ2HAz93o7afBb0(u"࠭ࡧࡰࡸ࡬ࡨࠬᾔ")		in LkVZrOE4XBSN2Qex5PyHqC: vSmUFNEZ37ITl9k	= RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠧࡨࡱࡹ࡭ࡩ࠭ᾕ")
	elif WMkAjB1RgN7q(u"ࠨ࡮࡬࡭ࡻ࡯ࡤࡦࡱࠪᾖ") 	in LkVZrOE4XBSN2Qex5PyHqC: vSmUFNEZ37ITl9k	= BoWHNb9daQVCF16A(u"ࠩ࡯࡭࡮ࡼࡩࡥࡧࡲࠫᾗ")
	elif qbPw1d3KimF(u"ࠪࡱࡵ࠺ࡵࡱ࡮ࡲࡥࡩ࠭ᾘ")	in LkVZrOE4XBSN2Qex5PyHqC: vSmUFNEZ37ITl9k	= V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠫࡲࡶ࠴ࡶࡲ࡯ࡳࡦࡪࠧᾙ")
	elif QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠬࡶࡵࡣ࡮࡬ࡧࡻ࡯ࡤࡦࡱࠪᾚ")	in LkVZrOE4XBSN2Qex5PyHqC: vSmUFNEZ37ITl9k	= v5EA6TqHX3s4jzBMk(u"࠭ࡰࡶࡤ࡯࡭ࡨࡼࡩࡥࡧࡲࠫᾛ")
	elif NVS30xAdRFMIw1n9CislkE2(u"ࠧࡳࡣࡳ࡭ࡩࡼࡩࡥࡧࡲࠫᾜ") 	in LkVZrOE4XBSN2Qex5PyHqC: vSmUFNEZ37ITl9k	= qbPw1d3KimF(u"ࠨࡴࡤࡴ࡮ࡪࡶࡪࡦࡨࡳࠬᾝ")
	elif gItVahxL0w(u"ࠩࡷࡳࡵ࠺ࡴࡰࡲࠪᾞ")		in LkVZrOE4XBSN2Qex5PyHqC: vSmUFNEZ37ITl9k	= LgpdP3UjFRnlX(u"ࠪࡸࡴࡶ࠴ࡵࡱࡳࠫᾟ")
	elif C2dgEDAKQGsvh(u"ࠫࡺࡶࡰࠨᾠ") 			in LkVZrOE4XBSN2Qex5PyHqC: vSmUFNEZ37ITl9k	= LgpdP3UjFRnlX(u"ࠬࡻࡰࡣࡱࡰࠫᾡ")
	elif gItVahxL0w(u"࠭ࡵࡱࡤࠪᾢ") 			in LkVZrOE4XBSN2Qex5PyHqC: vSmUFNEZ37ITl9k	= k5dztomYyN3H(u"ࠧࡶࡲࡥࡳࡲ࠭ᾣ")
	elif FGDJwkEbTB5SoXujs3f(u"ࠨࡷࡴࡰࡴࡧࡤࠨᾤ") 		in LkVZrOE4XBSN2Qex5PyHqC: vSmUFNEZ37ITl9k	= jx7s8T0BFgODXLMzIYedf(u"ࠩࡸࡵࡱࡵࡡࡥࠩᾥ")
	elif k5dztomYyN3H(u"ࠪࡺࡨࡹࡴࡳࡧࡤࡱࠬᾦ") 	in LkVZrOE4XBSN2Qex5PyHqC: vSmUFNEZ37ITl9k	= WMkAjB1RgN7q(u"ࠫࡻࡩࡳࡵࡴࡨࡥࡲ࠭ᾧ")
	elif BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠬࡼࡩࡥࡤࡲࡦࠬᾨ")		in LkVZrOE4XBSN2Qex5PyHqC: vSmUFNEZ37ITl9k	= jSu5Cg2Ub1OAkZVs8Yoz(u"࠭ࡶࡪࡦࡥࡳࡧ࠭ᾩ")
	elif LgpdP3UjFRnlX(u"ࠧࡷ࡫ࡧࡳࡿࡧࠧᾪ") 		in LkVZrOE4XBSN2Qex5PyHqC: vSmUFNEZ37ITl9k	= NVS30xAdRFMIw1n9CislkE2(u"ࠨࡸ࡬ࡨࡴࢀࡡࠨᾫ")
	elif C2jP0iLNGKnHu9xp(u"ࠩࡺࡥࡹࡩࡨࡷ࡫ࡧࡩࡴ࠭ᾬ") 	in LkVZrOE4XBSN2Qex5PyHqC: vSmUFNEZ37ITl9k	= jx7s8T0BFgODXLMzIYedf(u"ࠪࡻࡦࡺࡣࡩࡸ࡬ࡨࡪࡵࠧᾭ")
	elif FGDJwkEbTB5SoXujs3f(u"ࠫࡼ࡯࡮ࡵࡸ࠱ࡰ࡮ࡼࡥࠨᾮ")	in LkVZrOE4XBSN2Qex5PyHqC: vSmUFNEZ37ITl9k	= EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠬࡽࡩ࡯ࡶࡹ࠲ࡱ࡯ࡶࡦࠩᾯ")
	elif BmcLzCFjuIrZP5fwXH18aN6YS(u"࠭ࡺࡪࡲࡳࡽࡸ࡮ࡡࡳࡧࠪᾰ")	in LkVZrOE4XBSN2Qex5PyHqC: vSmUFNEZ37ITl9k	= FGDJwkEbTB5SoXujs3f(u"ࠧࡻ࡫ࡳࡴࡾࡹࡨࡢࡴࡨࠫᾱ")
	elif sRth5giAQzWlEVm7JOX(u"ࠨࡪࡧ࠱ࡨࡪ࡮ࠨᾲ")		in LkVZrOE4XBSN2Qex5PyHqC: vSmUFNEZ37ITl9k	= V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠩ࡫ࡨ࠲ࡩࡤ࡯ࠩᾳ")
	if   n7F25fCI9B4zDSPoQpW:	Z4FpMN1tVgK9LsaJeQ,bSxczpUtHewVDKa3EL4lm = qbPw1d3KimF(u"ࠪาฬ฻ࠧᾴ"),n7F25fCI9B4zDSPoQpW
	elif nuqHF7SQ3B8Yz:		Z4FpMN1tVgK9LsaJeQ,bSxczpUtHewVDKa3EL4lm = jx7s8T0BFgODXLMzIYedf(u"๋ࠫࠪอะัࠪ᾵"),nuqHF7SQ3B8Yz
	elif vSmUFNEZ37ITl9k:		Z4FpMN1tVgK9LsaJeQ,bSxczpUtHewVDKa3EL4lm = rbjsM8cRFiuA1(u"ฺࠬࠫࠥษ่ࠤ๊฿ั้ใࠪᾶ"),vSmUFNEZ37ITl9k
	elif wjnoiFvq39XDVUA1uxH46YE:	Z4FpMN1tVgK9LsaJeQ,bSxczpUtHewVDKa3EL4lm = jSu5Cg2Ub1OAkZVs8Yoz(u"࠭ࠥࠦࠧ฼ห๊ࠦฮศำฯ๎ࠬᾷ"),wjnoiFvq39XDVUA1uxH46YE
	elif YTpvNQm9JW5CbuBxhn1IoUwi86VljS:	Z4FpMN1tVgK9LsaJeQ,bSxczpUtHewVDKa3EL4lm = BoWHNb9daQVCF16A(u"ࠧࠦࠧࠨࠩ฾อๅࠡะสีั๐ࠧᾸ"),yZ1rhb6EugC4
	else:			Z4FpMN1tVgK9LsaJeQ,bSxczpUtHewVDKa3EL4lm = qbPw1d3KimF(u"ࠨࠧࠨูࠩࠪࠫศ็้ࠣัํ่ๅࠩᾹ"),yZ1rhb6EugC4
	return Z4FpMN1tVgK9LsaJeQ,bSxczpUtHewVDKa3EL4lm,type,WK75AGwvEzJZTNLQB1,LLnUyuiC2wRM0
def CXdjtkpE8UOhMJlVZuyWLm2Ivgb(url,source):
	bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,nuqHF7SQ3B8Yz,LkVZrOE4XBSN2Qex5PyHqC,yZ1rhb6EugC4,bSxczpUtHewVDKa3EL4lm,type,WK75AGwvEzJZTNLQB1,LLnUyuiC2wRM0,PZjG9QsCtzpMg2TcE = KFZxhTpVJeqk1uDA(url,source)
	if   fY5wTlhtnOc0Er6sdy4k87b(u"ࠩࡄࡏࡔࡇࡍࠨᾺ")		in source: ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = qS2COlbni0(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,bSxczpUtHewVDKa3EL4lm)
	elif rbjsM8cRFiuA1(u"ࠪࡅࡐ࡝ࡁࡎࠩΆ")		in source: ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = AHyTtY8FEJ(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,type,LLnUyuiC2wRM0)
	elif BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠶࠭ᾼ")		in source: ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = NNuy3mrgVF(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1)
	elif nr5mZG89ICi6cgt4MfLJa0(u"ࠬࡉࡉࡎࡃ࠷࡙ࠬ᾽")		in source: ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = RGB6zqroux(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1)
	elif k5dztomYyN3H(u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡂࠨι")		in source: ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = j7ZSy5oc1m(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1)
	elif NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠧࡂࡔࡄࡆࡘࡋࡅࡅࠩ᾿")		in source: ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = YTJnkQy0SN(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1)
	elif T6wRistc1SCo4hqObgumK(u"ࠨࡅࡌࡑࡆࡇࡂࡅࡑࠪ῀")		in source: ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = lMz5pnymV7(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1)
	elif v5EA6TqHX3s4jzBMk(u"ࠩࡖࡌࡔࡌࡈࡂࠩ῁")		in source: ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = YvWs3LpDg8(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1)
	elif NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠵ࠬῂ")		in source: ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = iFbpAPx1an(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,PZjG9QsCtzpMg2TcE)
	elif fY5wTlhtnOc0Er6sdy4k87b(u"ࠫࡰࡧࡴ࡬ࡱࡸࡸࡪ࠭ῃ")		in LkVZrOE4XBSN2Qex5PyHqC: ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = FeR60HQSEZ(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1)
	elif WMkAjB1RgN7q(u"ࠬࡧ࡫ࡰࡣࡰ࠲ࡨࡧ࡭ࠨῄ")	in LkVZrOE4XBSN2Qex5PyHqC: ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = kkm9QT8Kbn(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1)
	elif V2RbfGOBdcA6l8NTsPWzEyvS7(u"࠭ࡡ࡭ࡣࡵࡥࡧ࠭῅")		in LkVZrOE4XBSN2Qex5PyHqC: ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = V4JKXwOforjx(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1)
	elif vvHpKfcqRnrFzjG(u"ࠧࡴࡪࡤ࡬࡮ࡪ࠴ࡶࠩῆ")		in LkVZrOE4XBSN2Qex5PyHqC: ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = XOVAKMYPIL(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1)
	elif hhlbF1Sns5TrEN8QPCYmL4(u"ࠨࡵ࡫ࡥ࡭࡫ࡤ࠵ࡷࠪῇ")		in LkVZrOE4XBSN2Qex5PyHqC: ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = XOVAKMYPIL(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1)
	elif rbjsM8cRFiuA1(u"ࠩࡨ࡫ࡾࡴ࡯ࡸࠩῈ")		in LkVZrOE4XBSN2Qex5PyHqC: ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = RUXamQHCMN(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1)
	elif jx7s8T0BFgODXLMzIYedf(u"ࠪࡸࡻ࡬ࡵ࡯ࠩΈ")		in LkVZrOE4XBSN2Qex5PyHqC: ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = jNaYJCozPl(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1)
	elif fY5wTlhtnOc0Er6sdy4k87b(u"ࠫࡹࡼ࡫ࡴࡣࠪῊ")		in LkVZrOE4XBSN2Qex5PyHqC: ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = jNaYJCozPl(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1)
	elif V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠬࡺࡶ࠮ࡨ࠱ࡧࡴࡳࠧΉ")		in LkVZrOE4XBSN2Qex5PyHqC: ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = jNaYJCozPl(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1)
	elif qbPw1d3KimF(u"࠭ࡨࡢ࡮ࡤࡧ࡮ࡳࡡࠨῌ")		in LkVZrOE4XBSN2Qex5PyHqC: ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = nSvp1c7TaC(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1)
	elif fY5wTlhtnOc0Er6sdy4k87b(u"ࠧࡴࡪࡲࡳ࡫ࡶࡲࡰࠩ῍")		in LkVZrOE4XBSN2Qex5PyHqC: ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = V5PYLF4G6Q(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1)
	elif YB5xyI7MaRslVpv(u"ࠨ࡯ࡼࡩ࡬ࡿࡶࡪࡲࠪ῎")		in LkVZrOE4XBSN2Qex5PyHqC: ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = G5GeI2DBORAT6CtaWz(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1)
	elif BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠩࡹࡷ࠹ࡻࠧ῏")			in LkVZrOE4XBSN2Qex5PyHqC: ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = b5bJkOI4c8(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1)
	elif LgpdP3UjFRnlX(u"ࠪࡪࡦࡰࡥࡳࠩῐ")		in LkVZrOE4XBSN2Qex5PyHqC: ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = FrmEf52pT4(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1)
	elif YB5xyI7MaRslVpv(u"ࠫࡨ࡯࡭ࡢࡰࡲࡻࠬῑ")		in LkVZrOE4XBSN2Qex5PyHqC: ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = nb2dEKuRFN(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1)
	elif fY5wTlhtnOc0Er6sdy4k87b(u"ࠬࡴࡥࡸࡥ࡬ࡱࡦ࠭ῒ")		in LkVZrOE4XBSN2Qex5PyHqC: ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = nb2dEKuRFN(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1)
	elif BoWHNb9daQVCF16A(u"࠭ࡣࡪ࡯ࡤ࠱ࡱ࡯ࡧࡩࡶࠪΐ")	in LkVZrOE4XBSN2Qex5PyHqC: ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = BkeL3UtRAW(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1)
	elif fY5wTlhtnOc0Er6sdy4k87b(u"ࠧࡤ࡫ࡰࡥࡱ࡯ࡧࡩࡶࠪ῔")	in LkVZrOE4XBSN2Qex5PyHqC: ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = BkeL3UtRAW(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1)
	elif b05yftsZ6NYgIKP(u"ࠨ࡯ࡼࡧ࡮ࡳࡡࠨ῕")		in LkVZrOE4XBSN2Qex5PyHqC: ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = xPDZYpvG74(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1)
	elif rbjsM8cRFiuA1(u"ࠩࡺࡩࡨ࡯࡭ࡢࠩῖ")		in LkVZrOE4XBSN2Qex5PyHqC: ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = qbHfJWnrKv(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1)
	elif BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠪࡦࡴࡱࡲࡢࠩῗ")		in LkVZrOE4XBSN2Qex5PyHqC: ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = KwC3gyFDv4(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1)
	elif BoWHNb9daQVCF16A(u"ࠫࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯ࠩῘ")	in LkVZrOE4XBSN2Qex5PyHqC: ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = fDYtH3JzIi(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1)
	elif gItVahxL0w(u"ࠬࡧࡲࡣ࡮࡬ࡳࡳࢀࠧῙ")		in LkVZrOE4XBSN2Qex5PyHqC: ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = zZjawg7d34(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1)
	elif T6wRistc1SCo4hqObgumK(u"࠭ࡤ࠯ࡧࡪࡽࡧ࡫ࡳࡵ࠰ࡧࠫῚ")	in LkVZrOE4XBSN2Qex5PyHqC: ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠧࠨΊ"),[sRth5giAQzWlEVm7JOX(u"ࠨࠩ῜")],[bJEs4IVAPdyUrhwCLv9k2YoOl8nt1]
	elif hhlbF1Sns5TrEN8QPCYmL4(u"ࠩࡨ࡫ࡾࡨࡥࡴࡶࠪ῝")		in LkVZrOE4XBSN2Qex5PyHqC: ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = LLWVaQmdit(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1)
	elif sRth5giAQzWlEVm7JOX(u"ࠪࡷࡪࡸࡩࡦࡵ࠷ࡻࡦࡺࡣࡩࠩ῞")	in LkVZrOE4XBSN2Qex5PyHqC: ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = llkjuqJVXU(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1)
	elif NVS30xAdRFMIw1n9CislkE2(u"ࠫࡺࡶࡢࡢ࡯ࠪ῟") 		in LkVZrOE4XBSN2Qex5PyHqC: ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = jSu5Cg2Ub1OAkZVs8Yoz(u"ࠬ࠭ῠ"),[NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠭ࠧῡ")],[bJEs4IVAPdyUrhwCLv9k2YoOl8nt1]
	else: ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = WMkAjB1RgN7q(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪῢ"),[UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠨࠩΰ")],[bJEs4IVAPdyUrhwCLv9k2YoOl8nt1]
	if ptkR1Tydzs!=C2dgEDAKQGsvh(u"ࠩࡈ࡜ࡎ࡚࡟ࡂࡎࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧῤ"): ptkR1Tydzs = T6wRistc1SCo4hqObgumK(u"ࠪࡊࡦ࡯࡬ࡦࡦ࠽ࠤࠥ࠭ῥ")+ptkR1Tydzs
	return ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i
def VcOwsuTkPYB7Z89AJI46(ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i):
	msjnlSMrQGJ4oLwE2d,NVHrZsqUp2 = [],[]
	for title,BoEFz2WhUyvTgDeiZ in zip(wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i):
		if REGCdFbgy4Vvu2ieLqNMlxntY(BoEFz2WhUyvTgDeiZ):
			msjnlSMrQGJ4oLwE2d.append(title)
			NVHrZsqUp2.append(BoEFz2WhUyvTgDeiZ)
	if not NVHrZsqUp2 and not ptkR1Tydzs: ptkR1Tydzs = qbPw1d3KimF(u"ࠫࡋࡧࡩ࡭ࡧࡧࠫῦ")
	return ptkR1Tydzs,msjnlSMrQGJ4oLwE2d,NVHrZsqUp2
def c0hbFemH7X(gV3Hz7qe5dcLmF46iub8PX1kKEat,url,source,yyeS7VUtoclLQiWxwYMGj1dBvZr):
	global NNMBemflctYDdJ,MDNXtTu4bLvxIPW3H,eLvHNniSGkjF6Pdlpy8h9Qs203VTxJ,KcoRaFP3Dz,ppOrKkmPIgVchzof17uSaFi
	CqbcsRzNpuZt6xrP2gHkXSA98ynj = []
	xzDBNT7org = (BmcLzCFjuIrZP5fwXH18aN6YS(u"࡚ࠬࡩ࡮ࡧࡲࡹࡹ࠭ῧ"),[],[])
	MDNXtTu4bLvxIPW3H[yyeS7VUtoclLQiWxwYMGj1dBvZr],eLvHNniSGkjF6Pdlpy8h9Qs203VTxJ[yyeS7VUtoclLQiWxwYMGj1dBvZr],KcoRaFP3Dz[yyeS7VUtoclLQiWxwYMGj1dBvZr],ppOrKkmPIgVchzof17uSaFi[yyeS7VUtoclLQiWxwYMGj1dBvZr] = xzDBNT7org,xzDBNT7org,xzDBNT7org,xzDBNT7org
	IPjqgCmFY7trfM = [WUwFftOoaKrQpe,dlM1QaDpPW5f4iJnT3beqRAuXkzO7L,MXf25YENpDBlV,tLQ1ylmi5ZvaDxc3w7YrhouRTkn8AP]
	for Q2tThSDqng6o1V3Xf in IPjqgCmFY7trfM:
		yiqSHXQnAPK = iDocG6BXv7fT2z8UVOxgP.Thread(target=Q2tThSDqng6o1V3Xf,args=(url,source,yyeS7VUtoclLQiWxwYMGj1dBvZr))
		yiqSHXQnAPK.start()
		if MDNXtTu4bLvxIPW3H[yyeS7VUtoclLQiWxwYMGj1dBvZr][V2RbfGOBdcA6l8NTsPWzEyvS7(u"࠴ྚ")]==vvHpKfcqRnrFzjG(u"࠭ࡅ࡙ࡋࡗࡣࡆࡒࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫῨ") or (not MDNXtTu4bLvxIPW3H[yyeS7VUtoclLQiWxwYMGj1dBvZr][V2RbfGOBdcA6l8NTsPWzEyvS7(u"࠴ྚ")] and MDNXtTu4bLvxIPW3H[yyeS7VUtoclLQiWxwYMGj1dBvZr][nr5mZG89ICi6cgt4MfLJa0(u"࠷ྛ")]): break
		if eLvHNniSGkjF6Pdlpy8h9Qs203VTxJ[yyeS7VUtoclLQiWxwYMGj1dBvZr][QynMHGWA0blfqTUdxRh5Jzi2t(u"࠶ྜ")]==v5EA6TqHX3s4jzBMk(u"ࠧࡆ࡚ࡌࡘࡤࡇࡌࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬῩ") or (not eLvHNniSGkjF6Pdlpy8h9Qs203VTxJ[yyeS7VUtoclLQiWxwYMGj1dBvZr][QynMHGWA0blfqTUdxRh5Jzi2t(u"࠶ྜ")] and eLvHNniSGkjF6Pdlpy8h9Qs203VTxJ[yyeS7VUtoclLQiWxwYMGj1dBvZr][qbPw1d3KimF(u"࠲ྜྷ")]): break
		if KcoRaFP3Dz[yyeS7VUtoclLQiWxwYMGj1dBvZr][fY5wTlhtnOc0Er6sdy4k87b(u"࠱ྞ")]==C2dgEDAKQGsvh(u"ࠨࡇ࡛ࡍ࡙ࡥࡁࡍࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭Ὺ") or (not KcoRaFP3Dz[yyeS7VUtoclLQiWxwYMGj1dBvZr][fY5wTlhtnOc0Er6sdy4k87b(u"࠱ྞ")] and KcoRaFP3Dz[yyeS7VUtoclLQiWxwYMGj1dBvZr][BoWHNb9daQVCF16A(u"࠴ྟ")]): break
		if ppOrKkmPIgVchzof17uSaFi[yyeS7VUtoclLQiWxwYMGj1dBvZr][UxS67uoGThbMwnfNRzy4gajLd23JH(u"࠳ྠ")]==jSu5Cg2Ub1OAkZVs8Yoz(u"ࠩࡈ࡜ࡎ࡚࡟ࡂࡎࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧΎ") or (not ppOrKkmPIgVchzof17uSaFi[yyeS7VUtoclLQiWxwYMGj1dBvZr][UxS67uoGThbMwnfNRzy4gajLd23JH(u"࠳ྠ")] and ppOrKkmPIgVchzof17uSaFi[yyeS7VUtoclLQiWxwYMGj1dBvZr][nr5mZG89ICi6cgt4MfLJa0(u"࠶ྡ")]): break
		KBxPW9cX8dqtaUDG.sleep(v5EA6TqHX3s4jzBMk(u"࠵࠴࠷࠶ྡྷ"))
		CqbcsRzNpuZt6xrP2gHkXSA98ynj.append(yiqSHXQnAPK)
	timeout,step = RqldvxFuM5GEQ2HAz93o7afBb0(u"࠳࠱ྤ"),YB5xyI7MaRslVpv(u"࠸ྣ")
	for xzDBNT7org in range(timeout//step):
		if MDNXtTu4bLvxIPW3H[yyeS7VUtoclLQiWxwYMGj1dBvZr][YB5xyI7MaRslVpv(u"࠱ྥ")]==qbPw1d3KimF(u"ࠪࡉ࡝ࡏࡔࡠࡃࡏࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨῬ") or (not MDNXtTu4bLvxIPW3H[yyeS7VUtoclLQiWxwYMGj1dBvZr][YB5xyI7MaRslVpv(u"࠱ྥ")] and MDNXtTu4bLvxIPW3H[yyeS7VUtoclLQiWxwYMGj1dBvZr][C2dgEDAKQGsvh(u"࠴ྦ")]): break
		if eLvHNniSGkjF6Pdlpy8h9Qs203VTxJ[yyeS7VUtoclLQiWxwYMGj1dBvZr][jx7s8T0BFgODXLMzIYedf(u"࠳ྦྷ")]==FGDJwkEbTB5SoXujs3f(u"ࠫࡊ࡞ࡉࡕࡡࡄࡐࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ῭") or (not eLvHNniSGkjF6Pdlpy8h9Qs203VTxJ[yyeS7VUtoclLQiWxwYMGj1dBvZr][jx7s8T0BFgODXLMzIYedf(u"࠳ྦྷ")] and eLvHNniSGkjF6Pdlpy8h9Qs203VTxJ[yyeS7VUtoclLQiWxwYMGj1dBvZr][QynMHGWA0blfqTUdxRh5Jzi2t(u"࠶ྨ")]): break
		if KcoRaFP3Dz[yyeS7VUtoclLQiWxwYMGj1dBvZr][jx7s8T0BFgODXLMzIYedf(u"࠵ྩ")]==gItVahxL0w(u"ࠬࡋࡘࡊࡖࡢࡅࡑࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ΅") or (not KcoRaFP3Dz[yyeS7VUtoclLQiWxwYMGj1dBvZr][jx7s8T0BFgODXLMzIYedf(u"࠵ྩ")] and KcoRaFP3Dz[yyeS7VUtoclLQiWxwYMGj1dBvZr][PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"࠸ྪ")]): break
		if ppOrKkmPIgVchzof17uSaFi[yyeS7VUtoclLQiWxwYMGj1dBvZr][FGDJwkEbTB5SoXujs3f(u"࠰ྫ")]==UnWjVbo503mEMv9KF(u"࠭ࡅ࡙ࡋࡗࡣࡆࡒࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ`") or (not ppOrKkmPIgVchzof17uSaFi[yyeS7VUtoclLQiWxwYMGj1dBvZr][FGDJwkEbTB5SoXujs3f(u"࠰ྫ")] and ppOrKkmPIgVchzof17uSaFi[yyeS7VUtoclLQiWxwYMGj1dBvZr][UnWjVbo503mEMv9KF(u"࠳ྫྷ")]): break
		KBxPW9cX8dqtaUDG.sleep(step)
	for yiqSHXQnAPK in CqbcsRzNpuZt6xrP2gHkXSA98ynj: yiqSHXQnAPK.join(BmcLzCFjuIrZP5fwXH18aN6YS(u"࠳ྭ"))
	if UnWjVbo503mEMv9KF(u"࠴ྮ"):
		Uo9MkNzmhij = UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠧࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡣ࠷࠭῰")
		ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = MDNXtTu4bLvxIPW3H[yyeS7VUtoclLQiWxwYMGj1dBvZr]
		QQ2cE1FjUyxPonbDhaTkV6B3i = CCcnROiKzWQ7VmjeD2Jg(QQ2cE1FjUyxPonbDhaTkV6B3i)
		NNMBemflctYDdJ[yyeS7VUtoclLQiWxwYMGj1dBvZr] = gV3Hz7qe5dcLmF46iub8PX1kKEat,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i
		if ptkR1Tydzs==T6wRistc1SCo4hqObgumK(u"ࠨࡇ࡛ࡍ࡙ࡥࡁࡍࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭῱"): return Uo9MkNzmhij,ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i
		gV3Hz7qe5dcLmF46iub8PX1kKEat += BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠩ࡟ࡲࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦ࠲࠻ࠢࠣࠫῲ")+ptkR1Tydzs.replace(qbPw1d3KimF(u"ࠪࡠࡳ࠭ῳ"),LgpdP3UjFRnlX(u"ࠫࠬῴ")).replace(v5EA6TqHX3s4jzBMk(u"ࠬࡢࡲࠨ῵"),PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"࠭ࠧῶ"))[:PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"࠼࠵ྯ")]
	if MDNXtTu4bLvxIPW3H[yyeS7VUtoclLQiWxwYMGj1dBvZr][V2RbfGOBdcA6l8NTsPWzEyvS7(u"࠵ྰ")]!=b05yftsZ6NYgIKP(u"ࠧࡆ࡚ࡌࡘࡤࡇࡌࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬῷ") and not MDNXtTu4bLvxIPW3H[yyeS7VUtoclLQiWxwYMGj1dBvZr][C2jP0iLNGKnHu9xp(u"࠸ྱ")]:
		Uo9MkNzmhij = C2jP0iLNGKnHu9xp(u"ࠨࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡤ࠹ࠧῸ")
		ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = eLvHNniSGkjF6Pdlpy8h9Qs203VTxJ[yyeS7VUtoclLQiWxwYMGj1dBvZr]
		QQ2cE1FjUyxPonbDhaTkV6B3i = CCcnROiKzWQ7VmjeD2Jg(QQ2cE1FjUyxPonbDhaTkV6B3i)
		NNMBemflctYDdJ[yyeS7VUtoclLQiWxwYMGj1dBvZr] = gV3Hz7qe5dcLmF46iub8PX1kKEat,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i
		if ptkR1Tydzs==FGDJwkEbTB5SoXujs3f(u"ࠩࡈ࡜ࡎ࡚࡟ࡂࡎࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧΌ"): return Uo9MkNzmhij,ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i
		gV3Hz7qe5dcLmF46iub8PX1kKEat += hhlbF1Sns5TrEN8QPCYmL4(u"ࠪࡠࡳࡘࡥࡴࡱ࡯ࡺࡪࡸࠠ࠴࠼ࠣࠤࠬῺ")+ptkR1Tydzs.replace(nr5mZG89ICi6cgt4MfLJa0(u"ࠫࡡࡴࠧΏ"),RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠬ࠭ῼ")).replace(QynMHGWA0blfqTUdxRh5Jzi2t(u"࠭࡜ࡳࠩ´"),RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠧࠨ῾"))[:BoWHNb9daQVCF16A(u"࠸࠱ྲ")]
	if eLvHNniSGkjF6Pdlpy8h9Qs203VTxJ[yyeS7VUtoclLQiWxwYMGj1dBvZr][BoWHNb9daQVCF16A(u"࠱ླ")]!=v5EA6TqHX3s4jzBMk(u"ࠨࡇ࡛ࡍ࡙ࡥࡁࡍࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭῿") and not eLvHNniSGkjF6Pdlpy8h9Qs203VTxJ[yyeS7VUtoclLQiWxwYMGj1dBvZr][nr5mZG89ICi6cgt4MfLJa0(u"࠴ྴ")]:
		Uo9MkNzmhij = gItVahxL0w(u"ࠫࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡠ࠶ࠪࠀ")
		ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = KcoRaFP3Dz[yyeS7VUtoclLQiWxwYMGj1dBvZr]
		QQ2cE1FjUyxPonbDhaTkV6B3i = CCcnROiKzWQ7VmjeD2Jg(QQ2cE1FjUyxPonbDhaTkV6B3i)
		NNMBemflctYDdJ[yyeS7VUtoclLQiWxwYMGj1dBvZr] = gV3Hz7qe5dcLmF46iub8PX1kKEat,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i
		if ptkR1Tydzs==UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠬࡋࡘࡊࡖࡢࡅࡑࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪࠁ"): return Uo9MkNzmhij,ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i
		gV3Hz7qe5dcLmF46iub8PX1kKEat += jx7s8T0BFgODXLMzIYedf(u"࠭࡜࡯ࡔࡨࡷࡴࡲࡶࡦࡴࠣ࠸࠿ࠦࠠࠨࠂ")+ptkR1Tydzs.replace(BoWHNb9daQVCF16A(u"ࠧ࡝ࡰࠪࠃ"),FGDJwkEbTB5SoXujs3f(u"ࠨࠩࠄ")).replace(k5dztomYyN3H(u"ࠩ࡟ࡶࠬࠅ"),FGDJwkEbTB5SoXujs3f(u"ࠪࠫࠆ"))[:EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠻࠴ྵ")]
	if KcoRaFP3Dz[yyeS7VUtoclLQiWxwYMGj1dBvZr][RqldvxFuM5GEQ2HAz93o7afBb0(u"࠴ྶ")]!=hhlbF1Sns5TrEN8QPCYmL4(u"ࠫࡊ࡞ࡉࡕࡡࡄࡐࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩࠇ") and not KcoRaFP3Dz[yyeS7VUtoclLQiWxwYMGj1dBvZr][BoWHNb9daQVCF16A(u"࠷ྷ")]:
		Uo9MkNzmhij = nr5mZG89ICi6cgt4MfLJa0(u"ࠬࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡡ࠸ࠫࠈ")
		ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = ppOrKkmPIgVchzof17uSaFi[yyeS7VUtoclLQiWxwYMGj1dBvZr]
		QQ2cE1FjUyxPonbDhaTkV6B3i = CCcnROiKzWQ7VmjeD2Jg(QQ2cE1FjUyxPonbDhaTkV6B3i)
		NNMBemflctYDdJ[yyeS7VUtoclLQiWxwYMGj1dBvZr] = gV3Hz7qe5dcLmF46iub8PX1kKEat,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i
		if ptkR1Tydzs==BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠭ࡅ࡙ࡋࡗࡣࡆࡒࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫࠉ"): return Uo9MkNzmhij,ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i
	if ppOrKkmPIgVchzof17uSaFi[yyeS7VUtoclLQiWxwYMGj1dBvZr][LgpdP3UjFRnlX(u"࠶ྸ")]!=QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠧࡆ࡚ࡌࡘࡤࡇࡌࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬࠊ") and not ppOrKkmPIgVchzof17uSaFi[yyeS7VUtoclLQiWxwYMGj1dBvZr][NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠲ྐྵ")]:
		gV3Hz7qe5dcLmF46iub8PX1kKEat += C2dgEDAKQGsvh(u"ࠨ࡞ࡱࡖࡪࡹ࡯࡭ࡸࡨࡶࠥ࠻࠺ࠡࠢࠪࠋ")+ptkR1Tydzs.replace(BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠩ࡟ࡲࠬࠌ"),LgpdP3UjFRnlX(u"ࠪࠫࠍ")).replace(WMkAjB1RgN7q(u"ࠫࡡࡸࠧࠎ"),vvHpKfcqRnrFzjG(u"ࠬ࠭ࠏ"))[:hhlbF1Sns5TrEN8QPCYmL4(u"࠹࠲ྺ")]
	NNMBemflctYDdJ[yyeS7VUtoclLQiWxwYMGj1dBvZr] = gV3Hz7qe5dcLmF46iub8PX1kKEat,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i
	return Uo9MkNzmhij,gV3Hz7qe5dcLmF46iub8PX1kKEat,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i
def WUwFftOoaKrQpe(url,source,yyeS7VUtoclLQiWxwYMGj1dBvZr):
	LkVZrOE4XBSN2Qex5PyHqC = ooq2D9xF8ZLpPBs(url,RqldvxFuM5GEQ2HAz93o7afBb0(u"࠭࡮ࡢ࡯ࡨࠫࠐ"))
	QQ2cE1FjUyxPonbDhaTkV6B3i = []
	if   C2jP0iLNGKnHu9xp(u"ࠧࡺࡱࡸࡸࡺ࠭ࠑ")		in LkVZrOE4XBSN2Qex5PyHqC: ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = yy16g9xBYs(url)
	elif YB5xyI7MaRslVpv(u"ࠨࡻ࠵ࡹ࠳ࡨࡥࠨࠒ")		in LkVZrOE4XBSN2Qex5PyHqC: ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = yy16g9xBYs(url)
	elif BoWHNb9daQVCF16A(u"ࠩࡪࡳࡴ࡭࡬ࡦࡷࡶࡩࡷࡩ࡯ࠨࠓ") in LkVZrOE4XBSN2Qex5PyHqC: ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = L5qMdzJrcVUhflKmbx1uGYse2nko(url)
	elif v5EA6TqHX3s4jzBMk(u"ࠪࡴ࡭ࡵࡴࡰࡵ࠱ࡥࡵࡶ࠮ࡨࠩࠔ")	in url   : ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = k4QV6jNLRpzX8iFKThPJq(url)
	elif V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠫࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯ࠩࠕ")	in LkVZrOE4XBSN2Qex5PyHqC: ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = fDYtH3JzIi(url)
	elif YB5xyI7MaRslVpv(u"ࠬࡳ࡯ࡴࡪࡤ࡬ࡩࡧࠧࠖ")		in LkVZrOE4XBSN2Qex5PyHqC: ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = GZkH8K5lz2Ns(url)
	elif BmcLzCFjuIrZP5fwXH18aN6YS(u"࠭ࡦࡢࡵࡨࡰ࡭ࡪࠧࠗ")		in url   : ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = NNuy3mrgVF(url)
	elif BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠧࡢࡴࡤࡦࡱࡵࡡࡥࡵࠪ࠘")	in LkVZrOE4XBSN2Qex5PyHqC: ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = Z70v4c2XlVg1mT9p(url)
	elif fY5wTlhtnOc0Er6sdy4k87b(u"ࠨࡣࡵࡧ࡭࡯ࡶࡦࠩ࠙")		in LkVZrOE4XBSN2Qex5PyHqC: ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = Y0fRB6iE8TMgvdy7pJFHoaN2L(url)
	elif vvHpKfcqRnrFzjG(u"ࠩࡥࡹࡿࢀࡶࡳ࡮ࠪࠚ")		in LkVZrOE4XBSN2Qex5PyHqC: ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = PP3Wsy2roiB91AeRYvmpLatnCKux(url)
	elif PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠪࡩ࠺ࡺࡳࡢࡴࠪࠛ")		in LkVZrOE4XBSN2Qex5PyHqC: ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = Iw2ph3Wnflme(url)
	elif BoWHNb9daQVCF16A(u"ࠫ࡫ࡧࡣࡶ࡮ࡷࡽࡧࡵ࡯࡬ࡵࠪࠜ")	in LkVZrOE4XBSN2Qex5PyHqC: ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = Wp8jSmfrtJ1N(url)
	elif YB5xyI7MaRslVpv(u"ࠬ࡯࡮ࡧ࡮ࡤࡱ࠳ࡩࡣࠨࠝ")	in LkVZrOE4XBSN2Qex5PyHqC: ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = Wp8jSmfrtJ1N(url)
	elif jx7s8T0BFgODXLMzIYedf(u"࠭ࡵࡱࡤࡤࡱࠬࠞ") 		in LkVZrOE4XBSN2Qex5PyHqC: ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = fY5wTlhtnOc0Er6sdy4k87b(u"ࠧࠨࠟ"),[UnWjVbo503mEMv9KF(u"ࠨࠩࠠ")],[url]
	elif jx7s8T0BFgODXLMzIYedf(u"ࠩ࡯࡭࡮ࡼࡩࡥࡧࡲࠫࠡ") 	in LkVZrOE4XBSN2Qex5PyHqC: ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = Wd7ostUkhD1OVGKq(url)
	elif b05yftsZ6NYgIKP(u"ࠪࡱࡵ࠺ࡵࡱ࡮ࡲࡥࡩ࠭ࠢ")	in LkVZrOE4XBSN2Qex5PyHqC: ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = vHFe64R5VgyCbfwU8s3dlQKTWzkEh(url)
	elif BoWHNb9daQVCF16A(u"ࠫࡷࡧࡰࡪࡦࡹ࡭ࡩ࡫࡯ࠨࠣ") 	in LkVZrOE4XBSN2Qex5PyHqC: ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = Y8FiDNf2u0gHPT1woEl4(url)
	elif WMkAjB1RgN7q(u"ࠬࡺ࡯ࡱ࠶ࡷࡳࡵ࠭ࠤ")		in LkVZrOE4XBSN2Qex5PyHqC: ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = rAqcWjYhX0PmyT(url)
	elif k5dztomYyN3H(u"࠭ࡵࡱࡤࠪࠥ") 			in LkVZrOE4XBSN2Qex5PyHqC: ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = jhJDUlesnFXRg(url)
	elif UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠧࡶࡲࡳࠫࠦ") 			in LkVZrOE4XBSN2Qex5PyHqC: ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = jhJDUlesnFXRg(url)
	elif NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠨࡷࡴࡰࡴࡧࡤࠨࠧ") 		in LkVZrOE4XBSN2Qex5PyHqC: ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = sCaYWEmAuBHDkfd(url)
	elif vvHpKfcqRnrFzjG(u"ࠩࡹࡧࡸࡺࡲࡦࡣࡰࠫࠨ") 	in LkVZrOE4XBSN2Qex5PyHqC: ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = z7YClWhdno2faTu4Hect5E(url)
	elif T6wRistc1SCo4hqObgumK(u"ࠪࡺ࡮ࡪࡢࡰࡤࠪࠩ")		in LkVZrOE4XBSN2Qex5PyHqC: ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = IRLc49Auh1ngx(url)
	elif b05yftsZ6NYgIKP(u"ࠫࡻ࡯ࡤࡰࡼࡤࠫࠪ") 		in LkVZrOE4XBSN2Qex5PyHqC: ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = I6ipEyfUNLPj94RZkGtMsHaJKdbcz(url)
	elif QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠬࡽࡡࡵࡥ࡫ࡺ࡮ࡪࡥࡰࠩࠫ") 	in LkVZrOE4XBSN2Qex5PyHqC: ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = qo9mk1TbKEZHdtR8PYehD4iBrz7(url)
	elif EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠭ࡷࡪࡰࡷࡺ࠳ࡲࡩࡷࡧࠪࠬ")	in LkVZrOE4XBSN2Qex5PyHqC: ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = aceQhl9M3K(url)
	elif UnWjVbo503mEMv9KF(u"ࠧࡻ࡫ࡳࡴࡾࡹࡨࡢࡴࡨࠫ࠭")	in LkVZrOE4XBSN2Qex5PyHqC: ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = f2k7oH0VAhqibEaKxnzclZQLwgm5RF(url)
	else: ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠨࠩ࠮"),[],[]
	global MDNXtTu4bLvxIPW3H
	if ptkR1Tydzs!=YB5xyI7MaRslVpv(u"ࠩࡈ࡜ࡎ࡚࡟ࡂࡎࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ࠯"): ptkR1Tydzs = LgpdP3UjFRnlX(u"ࠪࡊࡦ࡯࡬ࡦࡦ࠽ࠤࠥ࠭࠰")
	MDNXtTu4bLvxIPW3H[yyeS7VUtoclLQiWxwYMGj1dBvZr] = ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i
	return
def dlM1QaDpPW5f4iJnT3beqRAuXkzO7L(url,source,yyeS7VUtoclLQiWxwYMGj1dBvZr):
	ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠫࠬ࠱"),[],[]
	if REGCdFbgy4Vvu2ieLqNMlxntY(url): ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = UnWjVbo503mEMv9KF(u"ࠬ࠭࠲"),[v5EA6TqHX3s4jzBMk(u"࠭ࠧ࠳")],[url]
	if not QQ2cE1FjUyxPonbDhaTkV6B3i: ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = VlD5dQsI7CNeGTox9ZnPwaXyS(url)
	if not QQ2cE1FjUyxPonbDhaTkV6B3i: ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = QpY2NyZtvmRxgqsASO8wceob6W70(url)
	global eLvHNniSGkjF6Pdlpy8h9Qs203VTxJ
	if not QQ2cE1FjUyxPonbDhaTkV6B3i:
		if ptkR1Tydzs==C2jP0iLNGKnHu9xp(u"ࠧࡆ࡚ࡌࡘࡤࡇࡌࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ࠴"): ptkR1Tydzs = qbPw1d3KimF(u"ࠨࠩ࠵")
		eLvHNniSGkjF6Pdlpy8h9Qs203VTxJ[yyeS7VUtoclLQiWxwYMGj1dBvZr] = PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠩࡉࡥ࡮ࡲࡥࡥ࠼ࠣࠤࠬ࠶")+ptkR1Tydzs,[],[]
		return
	eLvHNniSGkjF6Pdlpy8h9Qs203VTxJ[yyeS7VUtoclLQiWxwYMGj1dBvZr] = ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i
	return
def MXf25YENpDBlV(url,source,yyeS7VUtoclLQiWxwYMGj1dBvZr):
	WFMmPzdINGnfvRC1BoeOpb5 = UnWjVbo503mEMv9KF(u"ࠪࠫ࠷")
	ft3e2JBKQVXWlFPjaMhkEqGxvDg = BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࡈࡤࡰࡸ࡫ᄙ")
	try:
		import resolveurl as KJYA9ncCip31QEHR
		ft3e2JBKQVXWlFPjaMhkEqGxvDg = KJYA9ncCip31QEHR.resolve(url)
	except Exception as DjPT7VotAqzF5HCBXLM0OE1: WFMmPzdINGnfvRC1BoeOpb5 = str(DjPT7VotAqzF5HCBXLM0OE1)
	global KcoRaFP3Dz
	if not ft3e2JBKQVXWlFPjaMhkEqGxvDg:
		if WFMmPzdINGnfvRC1BoeOpb5==BoWHNb9daQVCF16A(u"ࠫࠬ࠸"):
			WFMmPzdINGnfvRC1BoeOpb5 = N3JR6Bk5lVxnfGdgvQb.format_exc()
			if WFMmPzdINGnfvRC1BoeOpb5!=RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠬࡔ࡯࡯ࡧࡗࡽࡵ࡫࠺ࠡࡐࡲࡲࡪࡢ࡮ࠨ࠹"): ehpURIi6QBDOGu8qj5EYzXrsWHJ7.stderr.write(WFMmPzdINGnfvRC1BoeOpb5)
		ptkR1Tydzs = WFMmPzdINGnfvRC1BoeOpb5.splitlines()[-v5EA6TqHX3s4jzBMk(u"࠳ྻ")]
		KcoRaFP3Dz[yyeS7VUtoclLQiWxwYMGj1dBvZr] = jSu5Cg2Ub1OAkZVs8Yoz(u"࠭ࡆࡢ࡫࡯ࡩࡩࡀࠠࠡࠩ࠺")+ptkR1Tydzs,[],[]
		return
	KcoRaFP3Dz[yyeS7VUtoclLQiWxwYMGj1dBvZr] = jSu5Cg2Ub1OAkZVs8Yoz(u"ࠧࠨ࠻"),[RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠨࠩ࠼")],[ft3e2JBKQVXWlFPjaMhkEqGxvDg]
	return
def tLQ1ylmi5ZvaDxc3w7YrhouRTkn8AP(url,source,yyeS7VUtoclLQiWxwYMGj1dBvZr):
	WFMmPzdINGnfvRC1BoeOpb5 = BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠩࠪ࠽")
	ft3e2JBKQVXWlFPjaMhkEqGxvDg = jSu5Cg2Ub1OAkZVs8Yoz(u"ࡉࡥࡱࡹࡥᄚ")
	try:
		import yt_dlp as b9G76KHfIWCeqrlZ4h
		xx38kinvsNCbeQrPI = b9G76KHfIWCeqrlZ4h.YoutubeDL({RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠪࡲࡴࡥࡣࡰ࡮ࡲࡶࠬ࠾"): v5EA6TqHX3s4jzBMk(u"ࡘࡷࡻࡥᄛ")})
		ft3e2JBKQVXWlFPjaMhkEqGxvDg = xx38kinvsNCbeQrPI.extract_info(url,download=qbPw1d3KimF(u"ࡋࡧ࡬ࡴࡧᄜ"))
	except Exception as DjPT7VotAqzF5HCBXLM0OE1: WFMmPzdINGnfvRC1BoeOpb5 = str(DjPT7VotAqzF5HCBXLM0OE1)
	global ppOrKkmPIgVchzof17uSaFi
	if not ft3e2JBKQVXWlFPjaMhkEqGxvDg or BoWHNb9daQVCF16A(u"ࠫ࡫ࡵࡲ࡮ࡣࡷࡷࠬ࠿") not in list(ft3e2JBKQVXWlFPjaMhkEqGxvDg.keys()):
		if WFMmPzdINGnfvRC1BoeOpb5==gItVahxL0w(u"ࠬ࠭ࡀ"):
			WFMmPzdINGnfvRC1BoeOpb5 = N3JR6Bk5lVxnfGdgvQb.format_exc()
			if WFMmPzdINGnfvRC1BoeOpb5!=jSu5Cg2Ub1OAkZVs8Yoz(u"࠭ࡎࡰࡰࡨࡘࡾࡶࡥ࠻ࠢࡑࡳࡳ࡫࡜࡯ࠩࡁ"): ehpURIi6QBDOGu8qj5EYzXrsWHJ7.stderr.write(WFMmPzdINGnfvRC1BoeOpb5)
		ptkR1Tydzs = WFMmPzdINGnfvRC1BoeOpb5.splitlines()[-fY5wTlhtnOc0Er6sdy4k87b(u"࠴ྼ")]
		ppOrKkmPIgVchzof17uSaFi[yyeS7VUtoclLQiWxwYMGj1dBvZr] = NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠧࡇࡣ࡬ࡰࡪࡪ࠺ࠡࠢࠪࡂ")+ptkR1Tydzs,[],[]
	else:
		wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = [],[]
		for BoEFz2WhUyvTgDeiZ in ft3e2JBKQVXWlFPjaMhkEqGxvDg[YB5xyI7MaRslVpv(u"ࠨࡨࡲࡶࡲࡧࡴࡴࠩࡃ")]:
			wlfZEzuRyYLvrp.append(BoEFz2WhUyvTgDeiZ[fY5wTlhtnOc0Er6sdy4k87b(u"ࠩࡩࡳࡷࡳࡡࡵࠩࡄ")])
			QQ2cE1FjUyxPonbDhaTkV6B3i.append(BoEFz2WhUyvTgDeiZ[V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠪࡹࡷࡲࠧࡅ")])
		ppOrKkmPIgVchzof17uSaFi[yyeS7VUtoclLQiWxwYMGj1dBvZr] = nr5mZG89ICi6cgt4MfLJa0(u"ࠫࠬࡆ"),wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i
	return
def VlD5dQsI7CNeGTox9ZnPwaXyS(url):
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(f9Oum6c0FotxYn,v5EA6TqHX3s4jzBMk(u"ࠬࡍࡅࡕࠩࡇ"),url,fY5wTlhtnOc0Er6sdy4k87b(u"࠭ࠧࡈ"),fY5wTlhtnOc0Er6sdy4k87b(u"ࠧࠨࡉ"),vvHpKfcqRnrFzjG(u"ࠨࠩࡊ"),T6wRistc1SCo4hqObgumK(u"ࡌࡡ࡭ࡵࡨᄝ"),C2jP0iLNGKnHu9xp(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡘࡅࡅࡋࡕࡉࡈ࡚࡟ࡖࡔࡏ࠱࠶ࡹࡴࠨࡋ"))
	headers = xHb86g9WZqPwRfVjXD2JalzSIp.headers
	if YB5xyI7MaRslVpv(u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬࡌ") in list(headers.keys()):
		BoEFz2WhUyvTgDeiZ = xHb86g9WZqPwRfVjXD2JalzSIp.headers[LgpdP3UjFRnlX(u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭ࡍ")]
		if REGCdFbgy4Vvu2ieLqNMlxntY(BoEFz2WhUyvTgDeiZ): return l0WAe1f7Bpi5ZXk(u"ࠬ࠭ࡎ"),[QynMHGWA0blfqTUdxRh5Jzi2t(u"࠭ࠧࡏ")],[BoEFz2WhUyvTgDeiZ]
	return RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠧࡇࡣ࡬ࡰࡪࡪ࠺ࠡࠢࠪࡐ"),[],[]
def CCcnROiKzWQ7VmjeD2Jg(U13zMpCrR827fED6q4FKBoaLAs):
	if nr5mZG89ICi6cgt4MfLJa0(u"ࠨ࡮࡬ࡷࡹ࠭ࡑ") in str(type(U13zMpCrR827fED6q4FKBoaLAs)):
		NVHrZsqUp2 = []
		for BoEFz2WhUyvTgDeiZ in U13zMpCrR827fED6q4FKBoaLAs:
			if nr5mZG89ICi6cgt4MfLJa0(u"ࠩࡶࡸࡷ࠭ࡒ") in str(type(BoEFz2WhUyvTgDeiZ)): BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ.replace(jSu5Cg2Ub1OAkZVs8Yoz(u"ࠪࡠࡷ࠭ࡓ"),qbPw1d3KimF(u"ࠫࠬࡔ")).replace(vvHpKfcqRnrFzjG(u"ࠬࡢ࡮ࠨࡕ"),QynMHGWA0blfqTUdxRh5Jzi2t(u"࠭ࠧࡖ")).strip(UnWjVbo503mEMv9KF(u"ࠧࠡࠩࡗ"))
			NVHrZsqUp2.append(BoEFz2WhUyvTgDeiZ)
	else: NVHrZsqUp2 = U13zMpCrR827fED6q4FKBoaLAs.replace(C2jP0iLNGKnHu9xp(u"ࠨ࡞ࡵࠫࡘ"),nr5mZG89ICi6cgt4MfLJa0(u"࡙ࠩࠪ")).replace(EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠪࡠࡳ࡚࠭"),C2jP0iLNGKnHu9xp(u"࡛ࠫࠬ")).strip(BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠬࠦࠧ࡜"))
	return NVHrZsqUp2
def uov12bnqR9Z5txMjH3Xw(iLIUfJZxbBAvczHmg2a,source):
	rXPnclZvF5N4LjYd9k617IRb = IIiPCruL6dT8s1lqj47SzpVHnYNm
	data = zPgNsqpJInt(RnqtMUa9Nh6peGEsBT,UnWjVbo503mEMv9KF(u"࠭࡬ࡪࡵࡷࠫ࡝"),V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠧࡔࡇࡕ࡚ࡊࡘࡓࠨ࡞"),iLIUfJZxbBAvczHmg2a)
	if data:
		wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = list(zip(*data))
		return wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i
	wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i,OgXPWZFyEQr9iNalBwLe = [],[],[]
	for BoEFz2WhUyvTgDeiZ in iLIUfJZxbBAvczHmg2a:
		if l0WAe1f7Bpi5ZXk(u"ࠨ࠱࠲ࠫ࡟") not in BoEFz2WhUyvTgDeiZ: continue
		Z4FpMN1tVgK9LsaJeQ,bSxczpUtHewVDKa3EL4lm,type,WK75AGwvEzJZTNLQB1,LLnUyuiC2wRM0 = Rm4GY7530abVwJkUZEe(BoEFz2WhUyvTgDeiZ,source)
		LLnUyuiC2wRM0 = My7Dwqvs6bfGNSIgX.findall(NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠩ࡟ࡨ࠰࠭ࡠ"),LLnUyuiC2wRM0,My7Dwqvs6bfGNSIgX.DOTALL)
		if LLnUyuiC2wRM0: LLnUyuiC2wRM0 = int(LLnUyuiC2wRM0[WMkAjB1RgN7q(u"࠴྽")])
		else: LLnUyuiC2wRM0 = BmcLzCFjuIrZP5fwXH18aN6YS(u"࠵྾")
		LkVZrOE4XBSN2Qex5PyHqC = ooq2D9xF8ZLpPBs(BoEFz2WhUyvTgDeiZ,BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠪࡲࡦࡳࡥࠨࡡ"))
		OgXPWZFyEQr9iNalBwLe.append([Z4FpMN1tVgK9LsaJeQ,bSxczpUtHewVDKa3EL4lm,type,WK75AGwvEzJZTNLQB1,LLnUyuiC2wRM0,BoEFz2WhUyvTgDeiZ,LkVZrOE4XBSN2Qex5PyHqC])
	if OgXPWZFyEQr9iNalBwLe:
		PknXUslGtRfdI9bhTSNvLjJg5738ai = sorted(OgXPWZFyEQr9iNalBwLe,reverse=LgpdP3UjFRnlX(u"ࡔࡳࡷࡨᄞ"),key=lambda key: (key[sRth5giAQzWlEVm7JOX(u"࠸࿄")],key[vvHpKfcqRnrFzjG(u"࠰࿀")],key[UnWjVbo503mEMv9KF(u"࠴࿁")],key[YB5xyI7MaRslVpv(u"࠴࿂")],key[jSu5Cg2Ub1OAkZVs8Yoz(u"࠷྿")],key[NVS30xAdRFMIw1n9CislkE2(u"࠸࿃")],key[EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠻࿅")]))
		TfO968IJUmqNpCzA1 = []
		for PcOUYpACoRnGhSWdiJV in PknXUslGtRfdI9bhTSNvLjJg5738ai:
			if PcOUYpACoRnGhSWdiJV not in TfO968IJUmqNpCzA1:
				TfO968IJUmqNpCzA1.append(PcOUYpACoRnGhSWdiJV)
		for Z4FpMN1tVgK9LsaJeQ,bSxczpUtHewVDKa3EL4lm,type,WK75AGwvEzJZTNLQB1,LLnUyuiC2wRM0,BoEFz2WhUyvTgDeiZ,LkVZrOE4XBSN2Qex5PyHqC in TfO968IJUmqNpCzA1:
			if LLnUyuiC2wRM0: LLnUyuiC2wRM0 = str(LLnUyuiC2wRM0)
			else: LLnUyuiC2wRM0 = fY5wTlhtnOc0Er6sdy4k87b(u"ࠫࠬࡢ")
			title = V2RbfGOBdcA6l8NTsPWzEyvS7(u"ู๊ࠬาใิࠫࡣ")+vvHpKfcqRnrFzjG(u"࠭ࠠࠨࡤ")+type+gItVahxL0w(u"ࠧࠡࠩࡥ")+Z4FpMN1tVgK9LsaJeQ+LgpdP3UjFRnlX(u"ࠨࠢࠪࡦ")+LLnUyuiC2wRM0+PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠩࠣࠫࡧ")+WK75AGwvEzJZTNLQB1+hhlbF1Sns5TrEN8QPCYmL4(u"ࠪࠤࠬࡨ")+bSxczpUtHewVDKa3EL4lm
			if LkVZrOE4XBSN2Qex5PyHqC not in title: title = title+NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠫࠥ࠭ࡩ")+LkVZrOE4XBSN2Qex5PyHqC
			title = title.replace(v5EA6TqHX3s4jzBMk(u"ࠬࠫࠧࡪ"),V2RbfGOBdcA6l8NTsPWzEyvS7(u"࠭ࠧ࡫")).strip(v5EA6TqHX3s4jzBMk(u"ࠧࠡࠩ࡬")).replace(k5dztomYyN3H(u"ࠨࠢࠣࠫ࡭"),rbjsM8cRFiuA1(u"ࠩࠣࠫ࡮")).replace(k5dztomYyN3H(u"ࠪࠤࠥ࠭࡯"),C2dgEDAKQGsvh(u"ࠫࠥ࠭ࡰ")).replace(NVS30xAdRFMIw1n9CislkE2(u"ࠬࠦࠠࠨࡱ"),hhlbF1Sns5TrEN8QPCYmL4(u"࠭ࠠࠨࡲ"))
			if BoEFz2WhUyvTgDeiZ not in QQ2cE1FjUyxPonbDhaTkV6B3i:
				wlfZEzuRyYLvrp.append(title)
				QQ2cE1FjUyxPonbDhaTkV6B3i.append(BoEFz2WhUyvTgDeiZ)
		if QQ2cE1FjUyxPonbDhaTkV6B3i:
			data = list(zip(wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i))
			if data: VZ8BTik93OqXLCh0fD7d2KUPpn4mH6(RnqtMUa9Nh6peGEsBT,jx7s8T0BFgODXLMzIYedf(u"ࠧࡔࡇࡕ࡚ࡊࡘࡓࠨࡳ"),iLIUfJZxbBAvczHmg2a,data,rXPnclZvF5N4LjYd9k617IRb)
	return wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i
def V4JKXwOforjx(url):
	if NVS30xAdRFMIw1n9CislkE2(u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧࡴ") in url:
		wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = cChyAEtdaMvNXsurWwnSeBzFU2m(url)
		if QQ2cE1FjUyxPonbDhaTkV6B3i: return EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠩࠪࡵ"),wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i
		return WMkAjB1RgN7q(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡓ࠳ࡖ࠺ࠪࡶ"),[],[]
	return UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧࡷ"),[C2dgEDAKQGsvh(u"ࠬ࠭ࡸ")],[url]
def FeR60HQSEZ(url):
	Qki8AbTHYjzM2Ls76Gdr3eqo1Wn,breQmB38nWlfEc6CNT = [],[]
	if UxS67uoGThbMwnfNRzy4gajLd23JH(u"࠭࠯ࡷ࡫ࡧࡩࡴࡹ࠮࡮ࡲ࠷ࡃࡻ࡯ࡤ࠾ࠩࡹ") in url:
		xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,T6wRistc1SCo4hqObgumK(u"ࠧࡈࡇࡗࠫࡺ"),url,vvHpKfcqRnrFzjG(u"ࠨࠩࡻ"),YB5xyI7MaRslVpv(u"ࠩࠪࡼ"),T6wRistc1SCo4hqObgumK(u"ࡇࡣ࡯ࡷࡪᄟ"),NVS30xAdRFMIw1n9CislkE2(u"ࠪࠫࡽ"),NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡌࡃࡗࡏࡔ࡛ࡔࡆ࠯࠴ࡷࡹ࠭ࡾ"))
		if YB5xyI7MaRslVpv(u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧࡿ") in xHb86g9WZqPwRfVjXD2JalzSIp.headers:
			BoEFz2WhUyvTgDeiZ = xHb86g9WZqPwRfVjXD2JalzSIp.headers[NVS30xAdRFMIw1n9CislkE2(u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨࢀ")]
			Qki8AbTHYjzM2Ls76Gdr3eqo1Wn.append(BoEFz2WhUyvTgDeiZ)
			LkVZrOE4XBSN2Qex5PyHqC = ooq2D9xF8ZLpPBs(BoEFz2WhUyvTgDeiZ,qbPw1d3KimF(u"ࠧ࡯ࡣࡰࡩࠬࢁ"))
			breQmB38nWlfEc6CNT.append(LkVZrOE4XBSN2Qex5PyHqC)
	elif YB5xyI7MaRslVpv(u"ࠨ࡭ࡤࡸࡰࡵࡵࡵࡧ࠱ࡧࡴࡳࠧࢂ") in url:
		xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,fY5wTlhtnOc0Er6sdy4k87b(u"ࠩࡊࡉ࡙࠭ࢃ"),url,gItVahxL0w(u"ࠪࠫࢄ"),jx7s8T0BFgODXLMzIYedf(u"ࠫࠬࢅ"),PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠬ࠭ࢆ"),YB5xyI7MaRslVpv(u"࠭ࠧࢇ"),b05yftsZ6NYgIKP(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡏࡆ࡚ࡋࡐࡗࡗࡉ࠲࠸࡮ࡥࠩ࢈"))
		MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
		s6Wmzn9rJg4hfpa = My7Dwqvs6bfGNSIgX.findall(V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠨࠪࡨࡺࡦࡲ࡜ࠩࡨࡸࡲࡨࡺࡩࡰࡰ࡟ࠬࡵ࠲ࡡ࠭ࡥ࠯࡯࠱࡫ࠬࡥ࡞ࠬ࠲࠯ࡅ࡜ࠪ࡞ࠬ࠭࠳ࡂ࠯ࡴࡥࡵ࡭ࡵࡺ࠾ࠨࢉ"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if s6Wmzn9rJg4hfpa:
			s6Wmzn9rJg4hfpa = s6Wmzn9rJg4hfpa[UnWjVbo503mEMv9KF(u"࠶࿆")]
			zTxDQ1bdOZ = t5XjI6pYbBTMdmDwxrzS9qkF(s6Wmzn9rJg4hfpa)
			PbqcvoD89L6AX = My7Dwqvs6bfGNSIgX.findall(RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠩࡶࡳࡺࡸࡣࡦࡵ࠽ࠬࡡࡡ࠮ࠫࡁ࡟ࡡ࠮࠲ࠧࢊ"),zTxDQ1bdOZ,My7Dwqvs6bfGNSIgX.DOTALL)
			if PbqcvoD89L6AX:
				PbqcvoD89L6AX = PbqcvoD89L6AX[FGDJwkEbTB5SoXujs3f(u"࠰࿇")]
				PbqcvoD89L6AX = dWsa2A0O4o5BYiqGXhyKEbM(RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠪࡰ࡮ࡹࡴࠨࢋ"),PbqcvoD89L6AX)
				for dict in PbqcvoD89L6AX:
					BoEFz2WhUyvTgDeiZ = dict[RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠫ࡫࡯࡬ࡦࠩࢌ")]
					LLnUyuiC2wRM0 = dict[sRth5giAQzWlEVm7JOX(u"ࠬࡲࡡࡣࡧ࡯ࠫࢍ")]
					Qki8AbTHYjzM2Ls76Gdr3eqo1Wn.append(BoEFz2WhUyvTgDeiZ)
					LkVZrOE4XBSN2Qex5PyHqC = ooq2D9xF8ZLpPBs(BoEFz2WhUyvTgDeiZ,T6wRistc1SCo4hqObgumK(u"࠭࡮ࡢ࡯ࡨࠫࢎ"))
					breQmB38nWlfEc6CNT.append(LLnUyuiC2wRM0+rbjsM8cRFiuA1(u"ࠧࠡࠩ࢏")+LkVZrOE4XBSN2Qex5PyHqC)
		elif BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ࢐") in xHb86g9WZqPwRfVjXD2JalzSIp.headers:
			BoEFz2WhUyvTgDeiZ = xHb86g9WZqPwRfVjXD2JalzSIp.headers[V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ࢑")]
			Qki8AbTHYjzM2Ls76Gdr3eqo1Wn.append(BoEFz2WhUyvTgDeiZ)
			LkVZrOE4XBSN2Qex5PyHqC = ooq2D9xF8ZLpPBs(BoEFz2WhUyvTgDeiZ,NVS30xAdRFMIw1n9CislkE2(u"ࠪࡲࡦࡳࡥࠨ࢒"))
			breQmB38nWlfEc6CNT.append(LkVZrOE4XBSN2Qex5PyHqC)
		if UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠫࡄࡻࡲ࡭࠿࡫ࡸࡹࡶࡳ࠻࠱࠲ࡴ࡭ࡵࡴࡰࡵ࠱ࡥࡵࡶ࠮ࡨࡱࡲࠫ࢓") in url:
			BoEFz2WhUyvTgDeiZ = url.split(C2dgEDAKQGsvh(u"ࠬࡅࡵࡳ࡮ࡀࠫ࢔"))[UxS67uoGThbMwnfNRzy4gajLd23JH(u"࠲࿈")]
			BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ.split(EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠭ࠦࠨ࢕"))[fY5wTlhtnOc0Er6sdy4k87b(u"࠲࿉")]
			if BoEFz2WhUyvTgDeiZ:
				Qki8AbTHYjzM2Ls76Gdr3eqo1Wn.append(BoEFz2WhUyvTgDeiZ)
				breQmB38nWlfEc6CNT.append(PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠧࡱࡪࡲࡸࡴࡹࠠࡨࡱࡲ࡫ࡱ࡫ࠧ࢖"))
	else:
		Qki8AbTHYjzM2Ls76Gdr3eqo1Wn.append(url)
		LkVZrOE4XBSN2Qex5PyHqC = ooq2D9xF8ZLpPBs(url,YB5xyI7MaRslVpv(u"ࠨࡰࡤࡱࡪ࠭ࢗ"))
		breQmB38nWlfEc6CNT.append(LkVZrOE4XBSN2Qex5PyHqC)
	if not Qki8AbTHYjzM2Ls76Gdr3eqo1Wn: return EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡐࡇࡔࡌࡑࡘࡘࡊ࠭࢘"),[],[]
	elif len(Qki8AbTHYjzM2Ls76Gdr3eqo1Wn)==YB5xyI7MaRslVpv(u"࠴࿊"): BoEFz2WhUyvTgDeiZ = Qki8AbTHYjzM2Ls76Gdr3eqo1Wn[l0WAe1f7Bpi5ZXk(u"࠴࿋")]
	else:
		GOtNfU3xQFkEhPouwA = CnKwdteDG5BE8MTRhUpYIJm3NLrSgq(UnWjVbo503mEMv9KF(u"ࠪวำะัࠡษ็้้็ࠠศๆ่๊ฬูศࠨ࢙"),breQmB38nWlfEc6CNT)
		if GOtNfU3xQFkEhPouwA==-PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"࠶࿌"): return NVS30xAdRFMIw1n9CislkE2(u"ࠫࡊ࡞ࡉࡕࡡࡄࡐࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࢚ࠩ"),[],[]
		BoEFz2WhUyvTgDeiZ = Qki8AbTHYjzM2Ls76Gdr3eqo1Wn[GOtNfU3xQFkEhPouwA]
	return C2jP0iLNGKnHu9xp(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ࢛"),[jx7s8T0BFgODXLMzIYedf(u"࠭ࠧ࢜")],[BoEFz2WhUyvTgDeiZ]
def L5qMdzJrcVUhflKmbx1uGYse2nko(url):
	headers = {FGDJwkEbTB5SoXujs3f(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ࢝"):k5dztomYyN3H(u"ࠨࡍࡲࡨ࡮࠵ࠧ࢞")+str(YSomBdvcNUMF3b8JDiCfrVW)}
	for k3Om08MCgqQao4n1 in range(C2dgEDAKQGsvh(u"࠻࠰࿍")):
		KBxPW9cX8dqtaUDG.sleep(nr5mZG89ICi6cgt4MfLJa0(u"࠰࠯࠳࠳࠴࿎"))
		xHb86g9WZqPwRfVjXD2JalzSIp = vcmTsFNY8wG9Z2xg(BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠩࡊࡉ࡙࠭࢟"),url,BoWHNb9daQVCF16A(u"ࠪࠫࢠ"),headers,l0WAe1f7Bpi5ZXk(u"ࡈࡤࡰࡸ࡫ᄠ"),FGDJwkEbTB5SoXujs3f(u"ࠫࠬࢡ"),BoWHNb9daQVCF16A(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡉࡒࡓࡌࡒࡅࡖࡕࡈࡖࡈࡕࡎࡕࡇࡑࡘ࠲࠷ࡳࡵࠩࢢ"))
		if EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨࢣ") in list(xHb86g9WZqPwRfVjXD2JalzSIp.headers.keys()):
			BoEFz2WhUyvTgDeiZ = xHb86g9WZqPwRfVjXD2JalzSIp.headers[C2jP0iLNGKnHu9xp(u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩࢤ")]
			BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ+C2jP0iLNGKnHu9xp(u"ࠨࡾࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࡃࠧࢥ")+headers[UnWjVbo503mEMv9KF(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ࢦ")]
			return rbjsM8cRFiuA1(u"ࠪࠫࢧ"),[jx7s8T0BFgODXLMzIYedf(u"ࠫࠬࢨ")],[BoEFz2WhUyvTgDeiZ]
		if xHb86g9WZqPwRfVjXD2JalzSIp.code!=BmcLzCFjuIrZP5fwXH18aN6YS(u"࠵࠴࠼࿏"): break
	return WMkAjB1RgN7q(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡈࡑࡒࡋࡑࡋࡕࡔࡇࡕࡇࡔࡔࡔࡆࡐࡗࠫࢩ"),[],[]
def k4QV6jNLRpzX8iFKThPJq(url):
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠭ࡇࡆࡖࠪࢪ"),url,LgpdP3UjFRnlX(u"ࠧࠨࢫ"),FGDJwkEbTB5SoXujs3f(u"ࠨࠩࢬ"),fY5wTlhtnOc0Er6sdy4k87b(u"ࠩࠪࢭ"),V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠪࠫࢮ"),BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡑࡊࡒࡘࡔ࡙ࡇࡐࡑࡊࡐࡊ࠳࠱ࡴࡶࠪࢯ"))
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	BoEFz2WhUyvTgDeiZ = My7Dwqvs6bfGNSIgX.findall(gItVahxL0w(u"ࠬࠨࠨࡩࡶࡷࡴࡸࡀ࠯࠰ࡸ࡬ࡨࡪࡵ࠭ࡥࡱࡺࡲࡱࡵࡡࡥࡵ࠱࠮ࡄ࠯ࠢ࠭࠰࠭ࡃ࠱࠴ࠪࡀ࠮ࠫ࠲࠯ࡅࠩ࠭ࠩࢰ"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if BoEFz2WhUyvTgDeiZ:
		BoEFz2WhUyvTgDeiZ,LLnUyuiC2wRM0 = BoEFz2WhUyvTgDeiZ[hhlbF1Sns5TrEN8QPCYmL4(u"࠲࿐")]
		return WMkAjB1RgN7q(u"࠭ࠧࢱ"),[LLnUyuiC2wRM0],[BoEFz2WhUyvTgDeiZ]
	return qbPw1d3KimF(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡓࡌࡔ࡚ࡏࡔࡉࡒࡓࡌࡒࡅࠨࢲ"),[],[]
def NNuy3mrgVF(url):
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(f9Oum6c0FotxYn,BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠨࡉࡈࡘࠬࢳ"),url,T6wRistc1SCo4hqObgumK(u"ࠩࠪࢴ"),PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠪࠫࢵ"),nr5mZG89ICi6cgt4MfLJa0(u"ࠫࠬࢶ"),T6wRistc1SCo4hqObgumK(u"ࠬ࠭ࢷ"),T6wRistc1SCo4hqObgumK(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡉࡅࡘࡋࡌࡉࡆ࠴࠱࠶ࡹࡴࠨࢸ"))
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	MK6ZT2zjC1SbmveNFqor = wuvsjzM2pegnkIAS3(MK6ZT2zjC1SbmveNFqor)
	BoEFz2WhUyvTgDeiZ = My7Dwqvs6bfGNSIgX.findall(C2dgEDAKQGsvh(u"ࠧࠣࡨ࡬ࡰࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨࢹ"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if BoEFz2WhUyvTgDeiZ: return PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠨࠩࢺ"),[gItVahxL0w(u"ࠩࠪࢻ")],[BoEFz2WhUyvTgDeiZ[NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠳࿑")]]
	return RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡌࡁࡔࡇࡏࡌࡉ࠷ࠧࢼ"),[],[]
def YvWs3LpDg8(url):
	if EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠫ࠴ࡪ࡯ࡸࡰ࠱ࡴ࡭ࡶࠧࢽ") in url:
		xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(f9Oum6c0FotxYn,RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠬࡍࡅࡕࠩࢾ"),url,vvHpKfcqRnrFzjG(u"࠭ࠧࢿ"),NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠧࠨࣀ"),BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠨࠩࣁ"),BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠩࠪࣂ"),FGDJwkEbTB5SoXujs3f(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡓࡉࡑࡉࡌࡆ࠳࠱ࡴࡶࠪࣃ"))
		MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
		BoEFz2WhUyvTgDeiZ = My7Dwqvs6bfGNSIgX.findall(k5dztomYyN3H(u"ࠫࡻ࡯ࡤࡦࡱ࠰ࡻࡷࡧࡰࡱࡧࡵ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬࣄ"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		url = BoEFz2WhUyvTgDeiZ[k5dztomYyN3H(u"࠴࿒")]
	return nr5mZG89ICi6cgt4MfLJa0(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨࣅ"),[fY5wTlhtnOc0Er6sdy4k87b(u"࠭ࠧࣆ")],[url]
def RGB6zqroux(url):
	if FGDJwkEbTB5SoXujs3f(u"ࠧࡴࡧࡵࡺࡪࡸ࠮ࡱࡪࡳࠫࣇ") in url:
		xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(f9Oum6c0FotxYn,EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠨࡉࡈࡘࠬࣈ"),url,qbPw1d3KimF(u"ࠩࠪࣉ"),jx7s8T0BFgODXLMzIYedf(u"ࠪࠫ࣊"),vvHpKfcqRnrFzjG(u"ࠫࠬ࣋"),WMkAjB1RgN7q(u"ࠬ࠭࣌"),BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡆࡍࡒࡇ࠴ࡖ࠯࠴ࡷࡹ࠭࣍"))
		MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
		BoEFz2WhUyvTgDeiZ = My7Dwqvs6bfGNSIgX.findall(qbPw1d3KimF(u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ࣎"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ[EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠵࿓")]
		if QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠨࡪࡷࡸࡵ࣏࠭") in BoEFz2WhUyvTgDeiZ: return v5EA6TqHX3s4jzBMk(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗ࣐ࠬ"),[jx7s8T0BFgODXLMzIYedf(u"࣑ࠪࠫ")],[BoEFz2WhUyvTgDeiZ]
		return BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡃࡊࡏࡄ࠸࡚࣒࠭"),[],[]
	return V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ࣓"),[fY5wTlhtnOc0Er6sdy4k87b(u"࠭ࠧࣔ")],[url]
def RUXamQHCMN(url):
	bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,toAVQS46Fv8aJYyLf25KnkUNC = NgD0bJaq14yBnMYoziAmLj(url)
	eIL9BxdTbZj = {sRth5giAQzWlEVm7JOX(u"࡙ࠧ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪࠪࣕ"):WMkAjB1RgN7q(u"ࠨ࡚ࡐࡐࡍࡺࡴࡱࡔࡨࡵࡺ࡫ࡳࡵࠩࣖ"),BoWHNb9daQVCF16A(u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨࣗ"):jx7s8T0BFgODXLMzIYedf(u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥ࠽ࠣࡧ࡭ࡧࡲࡴࡧࡷࡁ࡚࡚ࡆ࠮࠺ࠪࣘ")}
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,YB5xyI7MaRslVpv(u"ࠫࡕࡕࡓࡕࠩࣙ"),bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,toAVQS46Fv8aJYyLf25KnkUNC,eIL9BxdTbZj,sRth5giAQzWlEVm7JOX(u"ࠬ࠭ࣚ"),BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠭ࠧࣛ"),nr5mZG89ICi6cgt4MfLJa0(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡉࡌ࡟ࡎࡐ࡙࠰࠵ࡸࡺࠧࣜ"))
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	BoEFz2WhUyvTgDeiZ = My7Dwqvs6bfGNSIgX.findall(PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࣝ"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if not BoEFz2WhUyvTgDeiZ: return sRth5giAQzWlEVm7JOX(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡊࡍ࡙ࡏࡑ࡚ࠫࣞ"),[],[]
	BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ[YB5xyI7MaRslVpv(u"࠶࿔")]
	return qbPw1d3KimF(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ࣟ"),[gItVahxL0w(u"ࠫࠬ࣠")],[BoEFz2WhUyvTgDeiZ]
def V5PYLF4G6Q(url):
	headers = {hhlbF1Sns5TrEN8QPCYmL4(u"ࠬ࡞࠭ࡓࡧࡴࡹࡪࡹࡴࡦࡦ࠰࡛࡮ࡺࡨࠨ࣡"):FGDJwkEbTB5SoXujs3f(u"࠭ࡘࡎࡎࡋࡸࡹࡶࡒࡦࡳࡸࡩࡸࡺࠧ࣢")}
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,NVS30xAdRFMIw1n9CislkE2(u"ࠧࡈࡇࡗࣣࠫ"),url,vvHpKfcqRnrFzjG(u"ࠨࠩࣤ"),headers,LgpdP3UjFRnlX(u"ࠩࠪࣥ"),T6wRistc1SCo4hqObgumK(u"ࣦࠪࠫ"),T6wRistc1SCo4hqObgumK(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡔࡊࡒࡓࡋࡖࡒࡐ࠯࠴ࡷࡹ࠭ࣧ"))
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	BoEFz2WhUyvTgDeiZ = My7Dwqvs6bfGNSIgX.findall(v5EA6TqHX3s4jzBMk(u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪࣨ"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL|My7Dwqvs6bfGNSIgX.IGNORECASE)
	if not BoEFz2WhUyvTgDeiZ: return BoWHNb9daQVCF16A(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡕࡋࡓࡔࡌࡐࡓࡑࣩࠪ"),[],[]
	BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ[BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠰࿕")]
	return QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ࣪"),[V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠨࠩ࣫")],[BoEFz2WhUyvTgDeiZ]
def nSvp1c7TaC(url):
	bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,toAVQS46Fv8aJYyLf25KnkUNC = NgD0bJaq14yBnMYoziAmLj(url)
	eIL9BxdTbZj = {QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ࣬"):V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥ࠽ࠣࡧ࡭ࡧࡲࡴࡧࡷࡁ࡚࡚ࡆ࠮࠺࣭ࠪ")}
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,T6wRistc1SCo4hqObgumK(u"ࠫࡕࡕࡓࡕ࣮ࠩ"),bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,toAVQS46Fv8aJYyLf25KnkUNC,eIL9BxdTbZj,UnWjVbo503mEMv9KF(u"࣯ࠬ࠭"),gItVahxL0w(u"ࣰ࠭ࠧ"),NVS30xAdRFMIw1n9CislkE2(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡌࡆࡒࡁࡄࡋࡐࡅ࠲࠷ࡳࡵࣱࠩ"))
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	BoEFz2WhUyvTgDeiZ = My7Dwqvs6bfGNSIgX.findall(RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠨࠩࠪࡀ࡮࡬ࡲࡢ࡯ࡨࠤࡸࡸࡣ࠾࡝ࠥࠫࡢ࠮࠮ࠫࡁࠬ࡟ࠧ࠭࡝ࠨࣲࠩࠪ"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL|My7Dwqvs6bfGNSIgX.IGNORECASE)
	if not BoEFz2WhUyvTgDeiZ: return T6wRistc1SCo4hqObgumK(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡍࡇࡌࡂࡅࡌࡑࡆ࠭ࣳ"),[],[]
	BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ[sRth5giAQzWlEVm7JOX(u"࠱࿖")]
	if k5dztomYyN3H(u"ࠪ࡬ࡹࡺࡰࠨࣴ") not in BoEFz2WhUyvTgDeiZ: BoEFz2WhUyvTgDeiZ = qbPw1d3KimF(u"ࠫ࡭ࡺࡴࡱ࠼ࠪࣵ")+BoEFz2WhUyvTgDeiZ
	return UnWjVbo503mEMv9KF(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨࣶ"),[T6wRistc1SCo4hqObgumK(u"࠭ࠧࣷ")],[BoEFz2WhUyvTgDeiZ]
def lMz5pnymV7(url):
	bOBQpgMudItXo,breQmB38nWlfEc6CNT,Qki8AbTHYjzM2Ls76Gdr3eqo1Wn = url,[],[]
	if QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠧ࠰ࡣ࡭ࡥࡽ࠵ࠧࣸ") in url:
		bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,toAVQS46Fv8aJYyLf25KnkUNC = NgD0bJaq14yBnMYoziAmLj(url)
		eIL9BxdTbZj = {vvHpKfcqRnrFzjG(u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࣹࠧ"):YB5xyI7MaRslVpv(u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤ࠼ࠢࡦ࡬ࡦࡸࡳࡦࡶࡀ࡙࡙ࡌ࠭࠹ࣺࠩ")}
		xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠪࡔࡔ࡙ࡔࠨࣻ"),bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,toAVQS46Fv8aJYyLf25KnkUNC,eIL9BxdTbZj,qbPw1d3KimF(u"ࠫࠬࣼ"),fY5wTlhtnOc0Er6sdy4k87b(u"ࠬ࠭ࣽ"),fY5wTlhtnOc0Er6sdy4k87b(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡆࡍࡒࡇࡁࡃࡆࡒ࠱࠶ࡹࡴࠨࣾ"))
		MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
		kcGf0WYwFujE9QN6zHTi = My7Dwqvs6bfGNSIgX.findall(YB5xyI7MaRslVpv(u"ࠧࠨࠩ࠿࡭࡫ࡸࡡ࡮ࡧ࠱࠮ࡄࡹࡲࡤ࠿࡞ࠦࠬࡣࠨ࠯ࠬࡂ࠭ࡠࠨࠧ࡞ࠩࠪࠫࣿ"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL|My7Dwqvs6bfGNSIgX.IGNORECASE)
		if kcGf0WYwFujE9QN6zHTi: bOBQpgMudItXo = kcGf0WYwFujE9QN6zHTi[BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠲࿗")]
	return LgpdP3UjFRnlX(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫऀ"),[EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠩࠪँ")],[bOBQpgMudItXo]
def jNaYJCozPl(url):
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,C2dgEDAKQGsvh(u"ࠪࡋࡊ࡚ࠧं"),url,UnWjVbo503mEMv9KF(u"ࠫࠬः"),gItVahxL0w(u"ࠬ࠭ऄ"),RqldvxFuM5GEQ2HAz93o7afBb0(u"࠭ࠧअ"),vvHpKfcqRnrFzjG(u"ࠧࠨआ"),PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡙࡜ࡆࡖࡐ࠰࠵ࡸࡺࠧइ"))
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	dziGn6K0Eu = My7Dwqvs6bfGNSIgX.findall(NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠤࡹࡥࡷࠦࡦࡴࡧࡵࡺࠥࡃ࠮ࠫࡁࠪࠬ࠳࠰࠿ࠪࠩࠥई"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL|My7Dwqvs6bfGNSIgX.IGNORECASE)
	if dziGn6K0Eu:
		dziGn6K0Eu = dziGn6K0Eu[sRth5giAQzWlEVm7JOX(u"࠳࿘")][jSu5Cg2Ub1OAkZVs8Yoz(u"࠶࿙"):]
		dziGn6K0Eu = NfzkjQicS24ZYLMWuXFRwV5Ea7.b64decode(dziGn6K0Eu)
		if BLz7m2RkNrxXQwy1cGAp: dziGn6K0Eu = dziGn6K0Eu.decode(C2jP0iLNGKnHu9xp(u"ࠪࡹࡹ࡬࠸ࠨउ"))
		BoEFz2WhUyvTgDeiZ = My7Dwqvs6bfGNSIgX.findall(UnWjVbo503mEMv9KF(u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩऊ"),dziGn6K0Eu,My7Dwqvs6bfGNSIgX.DOTALL)
	else: BoEFz2WhUyvTgDeiZ = QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠬ࠭ऋ")
	if not BoEFz2WhUyvTgDeiZ: return qbPw1d3KimF(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡖ࡙ࡊ࡚ࡔࠧऌ"),[],[]
	BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ[UxS67uoGThbMwnfNRzy4gajLd23JH(u"࠵࿚")]
	if PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠧࡩࡶࡷࡴࠬऍ") not in BoEFz2WhUyvTgDeiZ: BoEFz2WhUyvTgDeiZ = sRth5giAQzWlEVm7JOX(u"ࠨࡪࡷࡸࡵࡀࠧऎ")+BoEFz2WhUyvTgDeiZ
	return BoWHNb9daQVCF16A(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬए"),[EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠪࠫऐ")],[BoEFz2WhUyvTgDeiZ]
def G5GeI2DBORAT6CtaWz(url):
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(f9Oum6c0FotxYn,k5dztomYyN3H(u"ࠫࡌࡋࡔࠨऑ"),url,BoWHNb9daQVCF16A(u"ࠬ࠭ऒ"),vvHpKfcqRnrFzjG(u"࠭ࠧओ"),gItVahxL0w(u"ࠧࠨऔ"),V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠨࠩक"),WMkAjB1RgN7q(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡓ࡙ࡆࡉ࡜࡚ࡎࡖ࠭࠲ࡵࡷࠫख"))
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	BoEFz2WhUyvTgDeiZ = My7Dwqvs6bfGNSIgX.findall(qbPw1d3KimF(u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡧࡴࡲ࠭ࡴ࡯࠰࠵࠷ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨग"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if not BoEFz2WhUyvTgDeiZ: return T6wRistc1SCo4hqObgumK(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡍ࡚ࡇࡊ࡝࡛ࡏࡐࠨघ"),[],[]
	BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ[sRth5giAQzWlEVm7JOX(u"࠶࿛")]
	return EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨङ"),[NVS30xAdRFMIw1n9CislkE2(u"࠭ࠧच")],[BoEFz2WhUyvTgDeiZ]
def fDYtH3JzIi(url):
	id = url.split(LgpdP3UjFRnlX(u"ࠧ࠰ࠩछ"))[-k5dztomYyN3H(u"࠱࿜")]
	if hhlbF1Sns5TrEN8QPCYmL4(u"ࠨ࠱ࡨࡱࡧ࡫ࡤࠨज") in url: url = url.replace(gItVahxL0w(u"ࠩ࠲ࡩࡲࡨࡥࡥࠩझ"),k5dztomYyN3H(u"ࠪࠫञ"))
	url = url.replace(EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠫ࠳ࡩ࡯࡮࠱ࠪट"),V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠬ࠴ࡣࡰ࡯࠲ࡴࡱࡧࡹࡦࡴ࠲ࡱࡪࡺࡡࡥࡣࡷࡥ࠴࠭ठ"))
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(f9Oum6c0FotxYn,C2jP0iLNGKnHu9xp(u"࠭ࡇࡆࡖࠪड"),url,vvHpKfcqRnrFzjG(u"ࠧࠨढ"),vvHpKfcqRnrFzjG(u"ࠨࠩण"),rbjsM8cRFiuA1(u"ࠩࠪत"),RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠪࠫथ"),NVS30xAdRFMIw1n9CislkE2(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲࠷ࡳࡵࠩद"))
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	ptkR1Tydzs = b05yftsZ6NYgIKP(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒࠬध")
	DjPT7VotAqzF5HCBXLM0OE1 = My7Dwqvs6bfGNSIgX.findall(C2jP0iLNGKnHu9xp(u"࠭ࠢࡦࡴࡵࡳࡷࠨ࠮ࠫࡁࠥࡱࡪࡹࡳࡢࡩࡨࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧन"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if DjPT7VotAqzF5HCBXLM0OE1: ptkR1Tydzs = DjPT7VotAqzF5HCBXLM0OE1[C2dgEDAKQGsvh(u"࠱࿝")]
	url = My7Dwqvs6bfGNSIgX.findall(YB5xyI7MaRslVpv(u"ࠧࡹ࠯ࡰࡴࡪ࡭ࡕࡓࡎࠥ࠰ࠧࡻࡲ࡭ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫऩ"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if not url and ptkR1Tydzs:
		return ptkR1Tydzs,[],[]
	BoEFz2WhUyvTgDeiZ = url[C2jP0iLNGKnHu9xp(u"࠲࿞")].replace(UnWjVbo503mEMv9KF(u"ࠨ࡞࡟ࠫप"),qbPw1d3KimF(u"ࠩࠪफ"))
	XXxkpYnSUfE4A9jMu,iLIUfJZxbBAvczHmg2a = cChyAEtdaMvNXsurWwnSeBzFU2m(BoEFz2WhUyvTgDeiZ)
	eMw2JCRLdZVYbjrtOTGEBK7FyD0N5c = My7Dwqvs6bfGNSIgX.findall(gItVahxL0w(u"ࠪࠦࡴࡽ࡮ࡦࡴࠥ࠾ࢀࠨࡩࡥࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠰ࠧࡹࡣࡳࡧࡨࡲࡳࡧ࡭ࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠰ࠧࡻࡲ࡭ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫब"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if eMw2JCRLdZVYbjrtOTGEBK7FyD0N5c: yK4ERcm3HMJqNzvxs6n2XZeiFlkB,tnKsrhBIwcQoDq,ddFivEhlW2gGDS5ZI = eMw2JCRLdZVYbjrtOTGEBK7FyD0N5c[rbjsM8cRFiuA1(u"࠳࿟")]
	else: yK4ERcm3HMJqNzvxs6n2XZeiFlkB,tnKsrhBIwcQoDq,ddFivEhlW2gGDS5ZI = LgpdP3UjFRnlX(u"ࠫࠬभ"),NVS30xAdRFMIw1n9CislkE2(u"ࠬ࠭म"),PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"࠭ࠧय")
	ddFivEhlW2gGDS5ZI = ddFivEhlW2gGDS5ZI.replace(LgpdP3UjFRnlX(u"ࠧ࡝࠱ࠪर"),vvHpKfcqRnrFzjG(u"ࠨ࠱ࠪऱ"))
	tnKsrhBIwcQoDq = tW06wVMpReHfnj3KgzT2va(tnKsrhBIwcQoDq)
	wlfZEzuRyYLvrp = [C2jP0iLNGKnHu9xp(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࡔ࡝ࡎࡆࡔ࠽ࠤࠥ࠭ल")+tnKsrhBIwcQoDq+BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬळ")]+XXxkpYnSUfE4A9jMu
	QQ2cE1FjUyxPonbDhaTkV6B3i = [ddFivEhlW2gGDS5ZI]+iLIUfJZxbBAvczHmg2a
	GOtNfU3xQFkEhPouwA = CnKwdteDG5BE8MTRhUpYIJm3NLrSgq(BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠫฬิสาࠢส่๊๊แࠡษ็้๋อำษ࠼ࠣࠬࠬऴ")+str(len(QQ2cE1FjUyxPonbDhaTkV6B3i)-PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"࠵࿠"))+RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠬࠦๅๅใࠬࠫव"),wlfZEzuRyYLvrp)
	if GOtNfU3xQFkEhPouwA==-UxS67uoGThbMwnfNRzy4gajLd23JH(u"࠶࿡"): return WMkAjB1RgN7q(u"࠭ࡅ࡙ࡋࡗࡣࡆࡒࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫश"),[],[]
	elif GOtNfU3xQFkEhPouwA==rbjsM8cRFiuA1(u"࠶࿢"):
		h7StLmFTb1QuXl6YqIdEfayZ = ehpURIi6QBDOGu8qj5EYzXrsWHJ7.argv[BoWHNb9daQVCF16A(u"࠰࿣")]+rbjsM8cRFiuA1(u"ࠧࡀࡶࡼࡴࡪࡃࡦࡰ࡮ࡧࡩࡷࠬ࡭ࡰࡦࡨࡁ࠹࠶࠲ࠧࡷࡵࡰࡂ࠭ष")+ddFivEhlW2gGDS5ZI+BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠨࠨࡷࡩࡽࡺࡴ࠾ࠩस")+tnKsrhBIwcQoDq
		tUXmK5PeEH9SDq.executebuiltin(YB5xyI7MaRslVpv(u"ࠤࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳࡛ࡰࡥࡣࡷࡩ࠭ࠨह")+h7StLmFTb1QuXl6YqIdEfayZ+hhlbF1Sns5TrEN8QPCYmL4(u"ࠥ࠭ࠧऺ"))
		return jSu5Cg2Ub1OAkZVs8Yoz(u"ࠫࡊ࡞ࡉࡕࡡࡄࡐࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩऻ"),[],[]
	BoEFz2WhUyvTgDeiZ =  QQ2cE1FjUyxPonbDhaTkV6B3i[GOtNfU3xQFkEhPouwA]
	return BoWHNb9daQVCF16A(u"़ࠬ࠭"),[UnWjVbo503mEMv9KF(u"࠭ࠧऽ")],[BoEFz2WhUyvTgDeiZ]
def KwC3gyFDv4(BoEFz2WhUyvTgDeiZ):
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(f9Oum6c0FotxYn,C2jP0iLNGKnHu9xp(u"ࠧࡈࡇࡗࠫा"),BoEFz2WhUyvTgDeiZ,jx7s8T0BFgODXLMzIYedf(u"ࠨࠩि"),V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠩࠪी"),gItVahxL0w(u"ࠪࠫु"),hhlbF1Sns5TrEN8QPCYmL4(u"ࠫࠬू"),vvHpKfcqRnrFzjG(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡄࡒࡏࡗࡇ࠭࠲ࡵࡷࠫृ"))
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	if UnWjVbo503mEMv9KF(u"࠭࠮࡫ࡵࡲࡲࠬॄ") in BoEFz2WhUyvTgDeiZ: url = My7Dwqvs6bfGNSIgX.findall(LgpdP3UjFRnlX(u"ࠧࠣࡵࡵࡧࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧॅ"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	else: url = My7Dwqvs6bfGNSIgX.findall(nr5mZG89ICi6cgt4MfLJa0(u"ࠨࡵࡲࡹࡷࡩࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ॆ"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if not url: return vvHpKfcqRnrFzjG(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡇࡕࡋࡓࡃࠪे"),[],[]
	url = url[NVS30xAdRFMIw1n9CislkE2(u"࠱࿤")]
	if WMkAjB1RgN7q(u"ࠪ࡬ࡹࡺࡰࠨै") not in url: url = FGDJwkEbTB5SoXujs3f(u"ࠫ࡭ࡺࡴࡱ࠼ࠪॉ")+url
	return gItVahxL0w(u"ࠬ࠭ॊ"),[jx7s8T0BFgODXLMzIYedf(u"࠭ࠧो")],[url]
def GZkH8K5lz2Ns(url):
	headers = { EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫौ") : PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠨ्ࠩ") }
	if PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠩࡲࡴࡂࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡟ࡰࡴ࡬࡫ࠬॎ") in url:
		MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(f9Oum6c0FotxYn,url,UnWjVbo503mEMv9KF(u"ࠪࠫॏ"),headers,jSu5Cg2Ub1OAkZVs8Yoz(u"ࠫࠬॐ"),hhlbF1Sns5TrEN8QPCYmL4(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡏࡒࡗࡍࡇࡈࡅࡃ࠰࠵ࡸࡺࠧ॑"))
		items = My7Dwqvs6bfGNSIgX.findall(BmcLzCFjuIrZP5fwXH18aN6YS(u"࠭ࡤࡪࡴࡨࡧࡹࠦ࡬ࡪࡰ࡮࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁ॒ࠬࠦࠬ"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if items: return NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠧࠨ॓"),[PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠨࠩ॔")],[items[BmcLzCFjuIrZP5fwXH18aN6YS(u"࠲࿥")]]
		else:
			mR4VLhryYT2koGU6iBX = My7Dwqvs6bfGNSIgX.findall(QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡨࡶࡷࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧॕ"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
			if mR4VLhryYT2koGU6iBX:
				ZIOHgA3z0TBR(UnWjVbo503mEMv9KF(u"ࠪࠫॖ"),NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠫࠬॗ"),V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่์็฿ࠠศๆสู้๐ࠧक़"),mR4VLhryYT2koGU6iBX[sRth5giAQzWlEVm7JOX(u"࠳࿦")])
				return vvHpKfcqRnrFzjG(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࠧख़")+mR4VLhryYT2koGU6iBX[jx7s8T0BFgODXLMzIYedf(u"࠴࿧")],[],[]
	else:
		bdHQJiTCSFGgoXL3v2rMNAEn6y = BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠧ࡮ࡱࡹ࡭ࡿࡲࡡ࡯ࡦࠪग़")
		MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(f9Oum6c0FotxYn,url,NVS30xAdRFMIw1n9CislkE2(u"ࠨࠩज़"),headers,BoWHNb9daQVCF16A(u"ࠩࠪड़"),sRth5giAQzWlEVm7JOX(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡍࡐࡕࡋࡅࡍࡊࡁ࠮࠴ࡱࡨࠬढ़"))
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall(UnWjVbo503mEMv9KF(u"ࠫࡋࡵࡲ࡮ࠢࡰࡩࡹ࡮࡯ࡥ࠿ࠥࡔࡔ࡙ࡔࠣࠢࡤࡧࡹ࡯࡯࡯࠿࡟ࠫ࠭࠴ࠪࡀࠫ࡟ࠫ࠭࠴ࠪࡀࠫࡧ࡭ࡻ࠭फ़"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if not XBuP6Op7y4K: return jx7s8T0BFgODXLMzIYedf(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡎࡑࡖࡌࡆࡎࡄࡂࠩय़"),[],[]
		bOBQpgMudItXo = XBuP6Op7y4K[BoWHNb9daQVCF16A(u"࠵࿨")][BoWHNb9daQVCF16A(u"࠵࿨")]
		vsptNMP2ZQC = XBuP6Op7y4K[b05yftsZ6NYgIKP(u"࠰࿪")][C2dgEDAKQGsvh(u"࠷࿩")]
		if WMkAjB1RgN7q(u"࠭࠮ࡳࡣࡵࠫॠ") in vsptNMP2ZQC or qbPw1d3KimF(u"ࠧ࠯ࡼ࡬ࡴࠬॡ") in vsptNMP2ZQC: return BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡏࡒࡗࡍࡇࡈࡅࡃࠣࡒࡴࡺࠠࡢࠢࡹ࡭ࡩ࡫࡯ࠡࡨ࡬ࡰࡪ࠭ॢ"),[],[]
		items = My7Dwqvs6bfGNSIgX.findall(PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠩࡱࡥࡲ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡺࡦࡲࡵࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪॣ"),vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		tWha1P9LVeuNxpQUAB = {}
		for bSxczpUtHewVDKa3EL4lm,WoFrX46wzbCNp18 in items:
			tWha1P9LVeuNxpQUAB[bSxczpUtHewVDKa3EL4lm] = WoFrX46wzbCNp18
		data = xcWMv9b8dpTSq1IZ5eht(tWha1P9LVeuNxpQUAB)
		MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(f9Oum6c0FotxYn,bOBQpgMudItXo,data,headers,BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠪࠫ।"),WMkAjB1RgN7q(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡎࡑࡖࡌࡆࡎࡄࡂ࠯࠶ࡶࡩ࠭॥"))
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall(QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠬࡊ࡯ࡸࡰ࡯ࡳࡦࡪࠠࡗ࡫ࡧࡩࡴ࠴ࠪࡀࡩࡨࡸࡡ࠮࡜ࠨࠪ࠱࠮ࡄ࠯࡜ࠨ࠰࠭ࡃࡸࡵࡵࡳࡥࡨࡷ࠿࠮࠮ࠫࡁࠬ࡭ࡲࡧࡧࡦ࠼ࠪ०"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if not XBuP6Op7y4K: return l0WAe1f7Bpi5ZXk(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡏࡒࡗࡍࡇࡈࡅࡃࠪ१"),[],[]
		download = XBuP6Op7y4K[EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠱࿫")][EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠱࿫")]
		vsptNMP2ZQC = XBuP6Op7y4K[WMkAjB1RgN7q(u"࠳࿭")][fY5wTlhtnOc0Er6sdy4k87b(u"࠳࿬")]
		items = My7Dwqvs6bfGNSIgX.findall(sRth5giAQzWlEVm7JOX(u"ࠧࡧ࡫࡯ࡩ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠮ࠬ࡭ࡣࡥࡩࡱࡀࠢ࠯ࠬࡂࠦࢁ࠯ࠧ२"),vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		ebHN2cVyxIRKsuzk0L3,wlfZEzuRyYLvrp,e1dn7APL6DyaMuchQkG2EI5jSY,QQ2cE1FjUyxPonbDhaTkV6B3i,Bsb8AV0exmNPyL79l2k = [],[],[],[],[]
		for BoEFz2WhUyvTgDeiZ,title in items:
			if nr5mZG89ICi6cgt4MfLJa0(u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧ३") in BoEFz2WhUyvTgDeiZ:
				ebHN2cVyxIRKsuzk0L3,e1dn7APL6DyaMuchQkG2EI5jSY = cChyAEtdaMvNXsurWwnSeBzFU2m(BoEFz2WhUyvTgDeiZ)
				QQ2cE1FjUyxPonbDhaTkV6B3i = QQ2cE1FjUyxPonbDhaTkV6B3i + e1dn7APL6DyaMuchQkG2EI5jSY
				if ebHN2cVyxIRKsuzk0L3[NVS30xAdRFMIw1n9CislkE2(u"࠴࿮")]==jx7s8T0BFgODXLMzIYedf(u"ࠩ࠰࠵ࠬ४"): wlfZEzuRyYLvrp.append(UnWjVbo503mEMv9KF(u"ࠪࠤุ๐ัโำࠣาฬ฻ࠠࠨ५")+BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠫࡲ࠹ࡵ࠹ࠢࠪ६")+bdHQJiTCSFGgoXL3v2rMNAEn6y)
				else:
					for title in ebHN2cVyxIRKsuzk0L3:
						wlfZEzuRyYLvrp.append(PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠬࠦำ๋ำไีࠥิวึࠢࠪ७")+QynMHGWA0blfqTUdxRh5Jzi2t(u"࠭࡭࠴ࡷ࠻ࠤࠬ८")+bdHQJiTCSFGgoXL3v2rMNAEn6y+C2dgEDAKQGsvh(u"ࠧࠡࠩ९")+title)
			else:
				title = title.replace(hhlbF1Sns5TrEN8QPCYmL4(u"ࠨ࠮࡯ࡥࡧ࡫࡬࠻ࠤࠪ॰"),C2jP0iLNGKnHu9xp(u"ࠩࠪॱ"))
				title = title.strip(l0WAe1f7Bpi5ZXk(u"ࠪࠦࠬॲ"))
				title = b05yftsZ6NYgIKP(u"ู๊ࠫࠥาใิࠤࠥิวึࠢࠪॳ")+BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠬࠦ࡭ࡱ࠶ࠣࠫॴ")+bdHQJiTCSFGgoXL3v2rMNAEn6y+YB5xyI7MaRslVpv(u"࠭ࠠࠨॵ")+title
				wlfZEzuRyYLvrp.append(title)
				QQ2cE1FjUyxPonbDhaTkV6B3i.append(BoEFz2WhUyvTgDeiZ)
		BoEFz2WhUyvTgDeiZ = T6wRistc1SCo4hqObgumK(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡮ࡱࡶ࡬ࡦ࡮ࡤࡢ࠰ࡲࡲࡱ࡯࡮ࡦࠩॶ") + download
		MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(f9Oum6c0FotxYn,BoEFz2WhUyvTgDeiZ,RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠨࠩॷ"),headers,T6wRistc1SCo4hqObgumK(u"ࠩࠪॸ"),V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡍࡐࡕࡋࡅࡍࡊࡁ࠮࠷ࡷ࡬ࠬॹ"))
		items = My7Dwqvs6bfGNSIgX.findall(EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠦࡩࡵࡷ࡯࡮ࡲࡥࡩࡥࡶࡪࡦࡨࡳࡡ࠮ࠧࠩ࠰࠭ࡃ࠮࠭ࠬࠨࠪ࠱࠮ࡄ࠯ࠧ࠭ࠩࠫ࠲࠯ࡅࠩࠨ࠰࠭ࡃࡁࡺࡤ࠿ࠪ࠱࠮ࡄ࠯ࠬࠣॺ"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		for id,H3HDqY5N4e0fWSXMikZ8CR7suUmJdx,hash,SSxUv8rOzuNeC4y53K in items:
			title = vvHpKfcqRnrFzjG(u"ࠬࠦำ๋ำไีࠥะอๆ์็ࠤำอีࠡࠩॻ")+b05yftsZ6NYgIKP(u"࠭ࠠ࡮ࡲ࠷ࠤࠬॼ")+bdHQJiTCSFGgoXL3v2rMNAEn6y+UnWjVbo503mEMv9KF(u"ࠧࠡࠩॽ")+SSxUv8rOzuNeC4y53K.split(BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠨࡺࠪॾ"))[b05yftsZ6NYgIKP(u"࠶࿯")]
			BoEFz2WhUyvTgDeiZ = BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡰࡳࡸ࡮ࡡࡩࡦࡤ࠲ࡴࡴ࡬ࡪࡰࡨ࠳ࡩࡲ࠿ࡰࡲࡀࡨࡴࡽ࡮࡭ࡱࡤࡨࡤࡵࡲࡪࡩࠩ࡭ࡩࡃࠧॿ")+id+FGDJwkEbTB5SoXujs3f(u"ࠪࠪࡲࡵࡤࡦ࠿ࠪঀ")+H3HDqY5N4e0fWSXMikZ8CR7suUmJdx+PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠫࠫ࡮ࡡࡴࡪࡀࠫঁ")+hash
			Bsb8AV0exmNPyL79l2k.append(SSxUv8rOzuNeC4y53K)
			wlfZEzuRyYLvrp.append(title)
			QQ2cE1FjUyxPonbDhaTkV6B3i.append(BoEFz2WhUyvTgDeiZ)
		Bsb8AV0exmNPyL79l2k = set(Bsb8AV0exmNPyL79l2k)
		tY14O3BTUDZfsnVENzojxQm2yiHFWv,WlfPanyBiTud5 = [],[]
		for title in wlfZEzuRyYLvrp:
			khvs4LDVNyeBj7 = My7Dwqvs6bfGNSIgX.findall(QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠧࠦࠨ࡝ࡦ࠭ࡼࢁࡢࡤࠫࠫࠩࠪࠧং"),title+nr5mZG89ICi6cgt4MfLJa0(u"࠭ࠦࠧࠩঃ"),My7Dwqvs6bfGNSIgX.DOTALL)
			for SSxUv8rOzuNeC4y53K in Bsb8AV0exmNPyL79l2k:
				if khvs4LDVNyeBj7[BoWHNb9daQVCF16A(u"࠶࿰")] in SSxUv8rOzuNeC4y53K:
					title = title.replace(khvs4LDVNyeBj7[T6wRistc1SCo4hqObgumK(u"࠱࿲")],SSxUv8rOzuNeC4y53K.split(EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠧࡹࠩ঄"))[fY5wTlhtnOc0Er6sdy4k87b(u"࠱࿱")])
			tY14O3BTUDZfsnVENzojxQm2yiHFWv.append(title)
		for FVW0I9sYcAjmDgn8r in range(len(QQ2cE1FjUyxPonbDhaTkV6B3i)):
			items = My7Dwqvs6bfGNSIgX.findall(PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠣࠨࠩࠬ࠳࠰࠿ࠪࠪ࡟ࡨ࠯࠯ࠦࠧࠤঅ"),FGDJwkEbTB5SoXujs3f(u"ࠩࠩࠪࠬআ")+tY14O3BTUDZfsnVENzojxQm2yiHFWv[FVW0I9sYcAjmDgn8r]+V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠪࠪࠫ࠭ই"),My7Dwqvs6bfGNSIgX.DOTALL)
			WlfPanyBiTud5.append( [tY14O3BTUDZfsnVENzojxQm2yiHFWv[FVW0I9sYcAjmDgn8r],QQ2cE1FjUyxPonbDhaTkV6B3i[FVW0I9sYcAjmDgn8r],items[V2RbfGOBdcA6l8NTsPWzEyvS7(u"࠳࿴")][V2RbfGOBdcA6l8NTsPWzEyvS7(u"࠳࿴")],items[V2RbfGOBdcA6l8NTsPWzEyvS7(u"࠳࿴")][sRth5giAQzWlEVm7JOX(u"࠳࿳")]] )
		WlfPanyBiTud5 = sorted(WlfPanyBiTud5, key=lambda PesMFvXRrd1: PesMFvXRrd1[BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠷࿵")], reverse=BmcLzCFjuIrZP5fwXH18aN6YS(u"ࡗࡶࡺ࡫ᄡ"))
		WlfPanyBiTud5 = sorted(WlfPanyBiTud5, key=lambda PesMFvXRrd1: PesMFvXRrd1[RqldvxFuM5GEQ2HAz93o7afBb0(u"࠷࿶")], reverse=V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࡊࡦࡲࡳࡦᄢ"))
		wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = [],[]
		for FVW0I9sYcAjmDgn8r in range(len(WlfPanyBiTud5)):
			wlfZEzuRyYLvrp.append(WlfPanyBiTud5[FVW0I9sYcAjmDgn8r][FGDJwkEbTB5SoXujs3f(u"࠶࿷")])
			QQ2cE1FjUyxPonbDhaTkV6B3i.append(WlfPanyBiTud5[FVW0I9sYcAjmDgn8r][FGDJwkEbTB5SoXujs3f(u"࠱࿸")])
	if len(QQ2cE1FjUyxPonbDhaTkV6B3i)==rbjsM8cRFiuA1(u"࠱࿹"): return QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡍࡐࡕࡋࡅࡍࡊࡁࠨঈ"),[],[]
	return nr5mZG89ICi6cgt4MfLJa0(u"ࠬ࠭উ"),wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i
def Iw2ph3Wnflme(url):
	tuHzpfZmLAdCObQS2k3 = url.split(EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠭࠿ࠨঊ"))
	bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = tuHzpfZmLAdCObQS2k3[RqldvxFuM5GEQ2HAz93o7afBb0(u"࠲࿺")]
	headers = { BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫঋ") : RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠨࠩঌ") }
	MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(f9Oum6c0FotxYn,bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,T6wRistc1SCo4hqObgumK(u"ࠩࠪ঍"),headers,jx7s8T0BFgODXLMzIYedf(u"ࠪࠫ঎"),nr5mZG89ICi6cgt4MfLJa0(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆ࠷ࡗࡗࡆࡘ࠭࠲ࡵࡷࠫএ"))
	items = My7Dwqvs6bfGNSIgX.findall(vvHpKfcqRnrFzjG(u"ࠬࡖ࡬ࡦࡣࡶࡩࠥࡽࡡࡪࡶ࠱࠮ࡄ࡮ࡲࡦࡨࡀࡠࠬ࠮࠮ࠫࡁࠬࡠࠬ࠭ঐ"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	url = items[BmcLzCFjuIrZP5fwXH18aN6YS(u"࠳࿻")]
	return jx7s8T0BFgODXLMzIYedf(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ঑"),[LgpdP3UjFRnlX(u"ࠧࠨ঒")],[url]
def PP3Wsy2roiB91AeRYvmpLatnCKux(url):
	wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = [],[]
	headers = { UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬও") : UnWjVbo503mEMv9KF(u"ࠩࠪঔ") }
	MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(IIiPCruL6dT8s1lqj47SzpVHnYNm,url,BoWHNb9daQVCF16A(u"ࠪࠫক"),headers,jSu5Cg2Ub1OAkZVs8Yoz(u"ࠫࠬখ"),l0WAe1f7Bpi5ZXk(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡈࡄࡇ࡚ࡒࡔ࡚ࡄࡒࡓࡐ࡙࠭࠲ࡵࡷࠫগ"))
	bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = My7Dwqvs6bfGNSIgX.findall(UnWjVbo503mEMv9KF(u"࠭ࡲࡦࡦ࡬ࡶࡪࡩࡴࡠࡷࡵࡰ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ঘ"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if bJEs4IVAPdyUrhwCLv9k2YoOl8nt1: return QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠧࠨঙ"),[C2jP0iLNGKnHu9xp(u"ࠨࠩচ")],[bJEs4IVAPdyUrhwCLv9k2YoOl8nt1[BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠴࿼")]]
	else: return nr5mZG89ICi6cgt4MfLJa0(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡇ࡛࡚࡛ࡘࡕࡐࠬছ"),[],[]
def Wp8jSmfrtJ1N(url):
	wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = [],[]
	headers = { fY5wTlhtnOc0Er6sdy4k87b(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧজ") : BoWHNb9daQVCF16A(u"ࠫࠬঝ") }
	MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(IIiPCruL6dT8s1lqj47SzpVHnYNm,url,LgpdP3UjFRnlX(u"ࠬ࠭ঞ"),headers,BmcLzCFjuIrZP5fwXH18aN6YS(u"࠭ࠧট"),BoWHNb9daQVCF16A(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡊࡆࡉࡕࡍࡖ࡜ࡆࡔࡕࡋࡔ࠯࠴ࡷࡹ࠭ঠ"))
	bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = My7Dwqvs6bfGNSIgX.findall(fY5wTlhtnOc0Er6sdy4k87b(u"ࠨࡪࡵࡩ࡫ࠨࠬࠣࠪ࡫ࡸࡹ࠴ࠪࡀࠫࠥࠫড"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if bJEs4IVAPdyUrhwCLv9k2YoOl8nt1: return UnWjVbo503mEMv9KF(u"ࠩࠪঢ"),[BoWHNb9daQVCF16A(u"ࠪࠫণ")],[bJEs4IVAPdyUrhwCLv9k2YoOl8nt1[YB5xyI7MaRslVpv(u"࠵࿽")]]
	else: return YB5xyI7MaRslVpv(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡆࡂࡅࡘࡐ࡙࡟ࡂࡐࡑࡎࡗࠬত"),[],[]
def FrmEf52pT4(url):
	wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i,errno = [],[],jx7s8T0BFgODXLMzIYedf(u"ࠬ࠭থ")
	if NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠭࠯ࡸࡲ࠰ࡥࡩࡳࡩ࡯࠱ࠪদ") in url:
		bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,toAVQS46Fv8aJYyLf25KnkUNC = NgD0bJaq14yBnMYoziAmLj(url)
		eIL9BxdTbZj = {l0WAe1f7Bpi5ZXk(u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭ধ"):jx7s8T0BFgODXLMzIYedf(u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪ࠻ࠡࡥ࡫ࡥࡷࡹࡥࡵ࠿ࡘࡘࡋ࠳࠸ࠨন")}
		xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(f9Oum6c0FotxYn,sRth5giAQzWlEVm7JOX(u"ࠩࡓࡓࡘ࡚ࠧ঩"),bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,toAVQS46Fv8aJYyLf25KnkUNC,eIL9BxdTbZj,T6wRistc1SCo4hqObgumK(u"ࠪࠫপ"),fY5wTlhtnOc0Er6sdy4k87b(u"ࠫࠬফ"),T6wRistc1SCo4hqObgumK(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡈࡄࡎࡊࡘࡓࡉࡑ࡚࠱࠷ࡴࡤࠨব"))
		wN6n7OZBoDkTvCi8LdbJjYV = xHb86g9WZqPwRfVjXD2JalzSIp.content
		if wN6n7OZBoDkTvCi8LdbJjYV.startswith(QynMHGWA0blfqTUdxRh5Jzi2t(u"࠭ࡨࡵࡶࡳࠫভ")): bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = wN6n7OZBoDkTvCi8LdbJjYV
		else:
			QAKdHzO0rehbtyIc = My7Dwqvs6bfGNSIgX.findall(jx7s8T0BFgODXLMzIYedf(u"ࠧࠨࠩࡶࡶࡨࡃ࡛ࠨࠤࡠࠬ࠳࠰࠿ࠪ࡝ࠪࠦࡢ࠭ࠧࠨম"),wN6n7OZBoDkTvCi8LdbJjYV,My7Dwqvs6bfGNSIgX.DOTALL)
			if QAKdHzO0rehbtyIc:
				bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = QAKdHzO0rehbtyIc[LgpdP3UjFRnlX(u"࠶࿾")]
				QAKdHzO0rehbtyIc = My7Dwqvs6bfGNSIgX.findall(RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠨࡵࡲࡹࡷࡩࡥ࠾ࠪ࠱࠮ࡄ࠯࡛ࠧࠦࡠࠫয"),bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,My7Dwqvs6bfGNSIgX.DOTALL)
				if QAKdHzO0rehbtyIc:
					bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = XnQbsZF0Ouh8p7zCdUN(QAKdHzO0rehbtyIc[NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠰࿿")])
					return PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠩࠪর"),[rbjsM8cRFiuA1(u"ࠪࠫ঱")],[bJEs4IVAPdyUrhwCLv9k2YoOl8nt1]
	elif PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠫ࠴ࡲࡩ࡯࡭ࡶ࠳ࠬল") in url:
		xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(f9Oum6c0FotxYn,T6wRistc1SCo4hqObgumK(u"ࠬࡍࡅࡕࠩ঳"),url,RqldvxFuM5GEQ2HAz93o7afBb0(u"࠭ࠧ঴"),UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠧࠨ঵"),QynMHGWA0blfqTUdxRh5Jzi2t(u"࡙ࡸࡵࡦᄣ"),QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠨࠩশ"),qbPw1d3KimF(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡌࡁࡋࡇࡕࡗࡍࡕࡗ࠮࠳ࡶࡸࠬষ"))
		wN6n7OZBoDkTvCi8LdbJjYV = xHb86g9WZqPwRfVjXD2JalzSIp.content
		if sRth5giAQzWlEVm7JOX(u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬস") in list(xHb86g9WZqPwRfVjXD2JalzSIp.headers.keys()): bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = xHb86g9WZqPwRfVjXD2JalzSIp.headers[b05yftsZ6NYgIKP(u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭হ")]
		else: bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = My7Dwqvs6bfGNSIgX.findall(YB5xyI7MaRslVpv(u"ࠬ࡯ࡤ࠾ࠤ࡯࡭ࡳࡱࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ঺"),wN6n7OZBoDkTvCi8LdbJjYV,My7Dwqvs6bfGNSIgX.DOTALL)[sRth5giAQzWlEVm7JOX(u"࠱က")]
	if jSu5Cg2Ub1OAkZVs8Yoz(u"࠭࠯ࡷ࠱ࠪ঻") in bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 or YB5xyI7MaRslVpv(u"ࠧ࠰ࡨ࠲়ࠫ") in bJEs4IVAPdyUrhwCLv9k2YoOl8nt1:
		bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = bJEs4IVAPdyUrhwCLv9k2YoOl8nt1.replace(FGDJwkEbTB5SoXujs3f(u"ࠨ࠱ࡩ࠳ࠬঽ"),l0WAe1f7Bpi5ZXk(u"ࠩ࠲ࡥࡵ࡯࠯ࡴࡱࡸࡶࡨ࡫࠯ࠨা"))
		bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = bJEs4IVAPdyUrhwCLv9k2YoOl8nt1.replace(v5EA6TqHX3s4jzBMk(u"ࠪ࠳ࡻ࠵ࠧি"),jx7s8T0BFgODXLMzIYedf(u"ࠫ࠴ࡧࡰࡪ࠱ࡶࡳࡺࡸࡣࡦ࠱ࠪী"))
		xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(f9Oum6c0FotxYn,fY5wTlhtnOc0Er6sdy4k87b(u"ࠬࡖࡏࡔࡖࠪু"),bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠭ࠧূ"),QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠧࠨৃ"),C2dgEDAKQGsvh(u"ࠨࠩৄ"),nr5mZG89ICi6cgt4MfLJa0(u"ࠩࠪ৅"),FGDJwkEbTB5SoXujs3f(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡆࡂࡌࡈࡖࡘࡎࡏࡘ࠯࠶ࡶࡩ࠭৆"))
		wN6n7OZBoDkTvCi8LdbJjYV = xHb86g9WZqPwRfVjXD2JalzSIp.content
		items = My7Dwqvs6bfGNSIgX.findall(WMkAjB1RgN7q(u"ࠫࠧ࡬ࡩ࡭ࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠱ࠨ࡬ࡢࡤࡨࡰࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧে"),wN6n7OZBoDkTvCi8LdbJjYV,My7Dwqvs6bfGNSIgX.DOTALL)
		if items:
			for BoEFz2WhUyvTgDeiZ,title in items:
				BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ.replace(V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠬࡢ࡜ࠨৈ"),PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"࠭ࠧ৉"))
				wlfZEzuRyYLvrp.append(title)
				QQ2cE1FjUyxPonbDhaTkV6B3i.append(BoEFz2WhUyvTgDeiZ)
		else:
			items = My7Dwqvs6bfGNSIgX.findall(NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠧࠣࡨ࡬ࡰࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ৊"),wN6n7OZBoDkTvCi8LdbJjYV,My7Dwqvs6bfGNSIgX.DOTALL)
			if items:
				BoEFz2WhUyvTgDeiZ = items[RqldvxFuM5GEQ2HAz93o7afBb0(u"࠲ခ")]
				BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ.replace(V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠨ࡞࡟ࠫো"),nr5mZG89ICi6cgt4MfLJa0(u"ࠩࠪৌ"))
				wlfZEzuRyYLvrp.append(qbPw1d3KimF(u"্ࠪࠫ"))
				QQ2cE1FjUyxPonbDhaTkV6B3i.append(BoEFz2WhUyvTgDeiZ)
	else: return UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧৎ"),[fY5wTlhtnOc0Er6sdy4k87b(u"ࠬ࠭৏")],[bJEs4IVAPdyUrhwCLv9k2YoOl8nt1]
	if len(QQ2cE1FjUyxPonbDhaTkV6B3i)==sRth5giAQzWlEVm7JOX(u"࠳ဂ"): return T6wRistc1SCo4hqObgumK(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡈࡄࡎࡊࡘࡓࡉࡑ࡚ࠫ৐"),[],[]
	return RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠧࠨ৑"),wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i
def b5bJkOI4c8(url):
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(f9Oum6c0FotxYn,EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠨࡉࡈࡘࠬ৒"),url,b05yftsZ6NYgIKP(u"ࠩࠪ৓"),gItVahxL0w(u"ࠪࠫ৔"),jx7s8T0BFgODXLMzIYedf(u"ࠫࠬ৕"),v5EA6TqHX3s4jzBMk(u"ࠬ࠭৖"),EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡐࡓ࡛࡙࠴ࡖ࠯࠴ࡷࡹ࠭ৗ"))
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i,errno = [],[],BoWHNb9daQVCF16A(u"ࠧࠨ৘")
	if BoWHNb9daQVCF16A(u"ࠨࡲ࡯ࡥࡾ࡫ࡲࡠࡧࡰࡦࡪࡪ࠮ࡱࡪࡳࠫ৙") in url or BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠩ࠲ࡩࡲࡨࡥࡥ࠱ࠪ৚") in url:
		if PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠪࡴࡱࡧࡹࡦࡴࡢࡩࡲࡨࡥࡥ࠰ࡳ࡬ࡵ࠭৛") in url:
			bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = My7Dwqvs6bfGNSIgX.findall(C2jP0iLNGKnHu9xp(u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩড়"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
			bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = bJEs4IVAPdyUrhwCLv9k2YoOl8nt1[sRth5giAQzWlEVm7JOX(u"࠴ဃ")]
		else: bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = url
		if WMkAjB1RgN7q(u"ࠬࡳ࡯ࡷࡵ࠷ࡹࠬঢ়") not in bJEs4IVAPdyUrhwCLv9k2YoOl8nt1: return UnWjVbo503mEMv9KF(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ৞"),[BoWHNb9daQVCF16A(u"ࠧࠨয়")],[bJEs4IVAPdyUrhwCLv9k2YoOl8nt1]
		xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(f9Oum6c0FotxYn,jSu5Cg2Ub1OAkZVs8Yoz(u"ࠨࡉࡈࡘࠬৠ"),bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,WMkAjB1RgN7q(u"ࠩࠪৡ"),jSu5Cg2Ub1OAkZVs8Yoz(u"ࠪࠫৢ"),nr5mZG89ICi6cgt4MfLJa0(u"ࠫࠬৣ"),YB5xyI7MaRslVpv(u"ࠬ࠭৤"),EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡐࡓ࡛࡙࠴ࡖ࠯࠵ࡲࡩ࠭৥"))
		MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall(BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠧࡪࡦࡀࠦࡵࡲࡡࡺࡧࡵࠦ࠭࠴ࠪࡀࠫࡹ࡭ࡩ࡫࡯࡫ࡵࠪ০"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		vsptNMP2ZQC = XBuP6Op7y4K[k5dztomYyN3H(u"࠵င")]
		items = My7Dwqvs6bfGNSIgX.findall(jx7s8T0BFgODXLMzIYedf(u"ࠨ࠾ࡶࡳࡺࡸࡣࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡯ࡥࡧ࡫࡬࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ১"),vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		if items:
			for BoEFz2WhUyvTgDeiZ,GDL3q5vFjwIVrM2ElRZNd in items:
				wlfZEzuRyYLvrp.append(GDL3q5vFjwIVrM2ElRZNd)
				QQ2cE1FjUyxPonbDhaTkV6B3i.append(BoEFz2WhUyvTgDeiZ)
	elif jSu5Cg2Ub1OAkZVs8Yoz(u"ࠩࡰࡥ࡮ࡴ࡟ࡱ࡮ࡤࡽࡪࡸ࠮ࡱࡪࡳࠫ২") in url:
		bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = My7Dwqvs6bfGNSIgX.findall(WMkAjB1RgN7q(u"ࠪࡹࡷࡲ࠽ࠩ࠰࠭ࡃ࠮ࠨࠧ৩"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = bJEs4IVAPdyUrhwCLv9k2YoOl8nt1[LgpdP3UjFRnlX(u"࠶စ")]
		xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(f9Oum6c0FotxYn,EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠫࡌࡋࡔࠨ৪"),bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠬ࠭৫"),vvHpKfcqRnrFzjG(u"࠭ࠧ৬"),V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠧࠨ৭"),V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠨࠩ৮"),LgpdP3UjFRnlX(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡓࡏࡗࡕ࠷࡙࠲࠹ࡲࡥࠩ৯"))
		MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
		QAKdHzO0rehbtyIc = My7Dwqvs6bfGNSIgX.findall(vvHpKfcqRnrFzjG(u"ࠪࠦ࡫࡯࡬ࡦࠤ࠽ࠤࠧ࠮࠮ࠫࡁࠬࠦࠬৰ"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		QAKdHzO0rehbtyIc = QAKdHzO0rehbtyIc[T6wRistc1SCo4hqObgumK(u"࠰ဆ")]
		wlfZEzuRyYLvrp.append(V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠫࠬৱ"))
		QQ2cE1FjUyxPonbDhaTkV6B3i.append(QAKdHzO0rehbtyIc)
	elif FGDJwkEbTB5SoXujs3f(u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡟࡭࡫ࡱ࡯ࠬ৲") in url:
		bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = My7Dwqvs6bfGNSIgX.findall(V2RbfGOBdcA6l8NTsPWzEyvS7(u"࠭࠼ࡤࡧࡱࡸࡪࡸ࠾࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ৳"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if bJEs4IVAPdyUrhwCLv9k2YoOl8nt1:
			bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = bJEs4IVAPdyUrhwCLv9k2YoOl8nt1[V2RbfGOBdcA6l8NTsPWzEyvS7(u"࠱ဇ")]
			return hhlbF1Sns5TrEN8QPCYmL4(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ৴"),[rbjsM8cRFiuA1(u"ࠨࠩ৵")],[bJEs4IVAPdyUrhwCLv9k2YoOl8nt1]
	if len(QQ2cE1FjUyxPonbDhaTkV6B3i)==NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠲ဈ"): return BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡒࡕࡖࡔ࠶ࡘࠫ৶"),[],[]
	return k5dztomYyN3H(u"ࠪࠫ৷"),wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i
def j7ZSy5oc1m(url):
	if v5EA6TqHX3s4jzBMk(u"ࠫࡄ࡭ࡥࡵ࠿ࠪ৸") in url:
		BoEFz2WhUyvTgDeiZ = url.split(BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠬࡅࡧࡦࡶࡀࠫ৹"),UnWjVbo503mEMv9KF(u"࠴ဉ"))[UnWjVbo503mEMv9KF(u"࠴ဉ")]
		BoEFz2WhUyvTgDeiZ = NfzkjQicS24ZYLMWuXFRwV5Ea7.b64decode(BoEFz2WhUyvTgDeiZ)
		if BLz7m2RkNrxXQwy1cGAp: BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ.decode(qbPw1d3KimF(u"࠭ࡵࡵࡨ࠻ࠫ৺"),jSu5Cg2Ub1OAkZVs8Yoz(u"ࠧࡪࡩࡱࡳࡷ࡫ࠧ৻"))
		return UnWjVbo503mEMv9KF(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫৼ"),[jSu5Cg2Ub1OAkZVs8Yoz(u"ࠩࠪ৽")],[BoEFz2WhUyvTgDeiZ]
	website = AK5RqLhji4W1wt9VdrCD3PGeQM[rbjsM8cRFiuA1(u"ࠪࡇࡎࡓࡁࡄࡎࡘࡆࠬ৾")][l0WAe1f7Bpi5ZXk(u"࠴ည")]
	headers = {NVS30xAdRFMIw1n9CislkE2(u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ৿"):website}
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(SToQEHqGtMnAlFbCz4wxBDuOsmW7,BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠬࡍࡅࡕࠩ਀"),url,sRth5giAQzWlEVm7JOX(u"࠭ࠧਁ"),headers,v5EA6TqHX3s4jzBMk(u"ࠧࠨਂ"),UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠨࠩਃ"),UnWjVbo503mEMv9KF(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡉࡉࡎࡃࡆࡐ࡚ࡈ࠭࠳ࡰࡧࠫ਄"))
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	LkVZrOE4XBSN2Qex5PyHqC = ooq2D9xF8ZLpPBs(url,NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠪࡹࡷࡲࠧਅ"))
	BoEFz2WhUyvTgDeiZ = My7Dwqvs6bfGNSIgX.findall(C2dgEDAKQGsvh(u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩࡃ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨਆ"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if not BoEFz2WhUyvTgDeiZ: BoEFz2WhUyvTgDeiZ = My7Dwqvs6bfGNSIgX.findall(LgpdP3UjFRnlX(u"ࠧࡹ࡯ࡶࡴࡦࡩࡸࡀࠠ࡝࡝ࠪࠬ࠳࠰࠿ࠪࠩࠥਇ"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if not BoEFz2WhUyvTgDeiZ: BoEFz2WhUyvTgDeiZ = My7Dwqvs6bfGNSIgX.findall(FGDJwkEbTB5SoXujs3f(u"ࠨࡦࡪ࡮ࡨ࠾ࠬ࠮࠮ࠫࡁࠬࠫࠧਈ"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if BoEFz2WhUyvTgDeiZ:
		BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ[NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠵ဋ")]+NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠧࡽࡔࡨࡪࡪࡸࡥࡳ࠿ࠪਉ")+website
		return k5dztomYyN3H(u"ࠨࠩਊ"),[NVS30xAdRFMIw1n9CislkE2(u"ࠩࠪ਋")],[BoEFz2WhUyvTgDeiZ]
	if k5dztomYyN3H(u"ࠪࡲࡦࡳࡥ࠾ࠤ࡛ࡸࡴࡱࡥ࡯ࠤࠪ਌") in MK6ZT2zjC1SbmveNFqor:
		A2OxBdgP4KFojZMiGt = My7Dwqvs6bfGNSIgX.findall(gItVahxL0w(u"ࠫࡳࡧ࡭ࡦ࠿ࠥ࡜ࡹࡵ࡫ࡦࡰࠥࠤࡨࡵ࡮ࡵࡧࡱࡸࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭਍"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if A2OxBdgP4KFojZMiGt:
			BoEFz2WhUyvTgDeiZ = A2OxBdgP4KFojZMiGt[WMkAjB1RgN7q(u"࠶ဌ")]
			BoEFz2WhUyvTgDeiZ = NfzkjQicS24ZYLMWuXFRwV5Ea7.b64decode(BoEFz2WhUyvTgDeiZ)
			if BLz7m2RkNrxXQwy1cGAp: BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ.decode(BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠬࡻࡴࡧ࠺ࠪ਎"),v5EA6TqHX3s4jzBMk(u"࠭ࡩࡨࡰࡲࡶࡪ࠭ਏ"))
			BoEFz2WhUyvTgDeiZ = My7Dwqvs6bfGNSIgX.findall(NVS30xAdRFMIw1n9CislkE2(u"ࠧࡩࡶࡷࡴ࠳࠰࠿ࠩࡪࡷࡸࡵ࠴ࠪࡀࠫ࠯ࠫਐ"),BoEFz2WhUyvTgDeiZ,My7Dwqvs6bfGNSIgX.DOTALL)
			if BoEFz2WhUyvTgDeiZ:
				BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ[UnWjVbo503mEMv9KF(u"࠰ဍ")]+RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠨࡾࡕࡩ࡫࡫ࡲࡦࡴࡀࠫ਑")+website
				return l0WAe1f7Bpi5ZXk(u"ࠩࠪ਒"),[NVS30xAdRFMIw1n9CislkE2(u"ࠪࠫਓ")],[BoEFz2WhUyvTgDeiZ]
	return V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧਔ"),[BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠬ࠭ਕ")],[url]
def iFbpAPx1an(url,PZjG9QsCtzpMg2TcE):
	breQmB38nWlfEc6CNT,Qki8AbTHYjzM2Ls76Gdr3eqo1Wn = [],[]
	if EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠭࠯࠲࠱ࠪਖ") in url:
		BoEFz2WhUyvTgDeiZ = url.replace(qbPw1d3KimF(u"ࠧ࠰࠳࠲ࠫਗ"),BoWHNb9daQVCF16A(u"ࠨ࠱࠷࠳ࠬਘ"))
		xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(SToQEHqGtMnAlFbCz4wxBDuOsmW7,LgpdP3UjFRnlX(u"ࠩࡊࡉ࡙࠭ਙ"),BoEFz2WhUyvTgDeiZ,YB5xyI7MaRslVpv(u"ࠪࠫਚ"),hhlbF1Sns5TrEN8QPCYmL4(u"ࠫࠬਛ"),RqldvxFuM5GEQ2HAz93o7afBb0(u"ࡌࡡ࡭ࡵࡨᄤ"),YB5xyI7MaRslVpv(u"ࠬ࠭ਜ"),qbPw1d3KimF(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡈࡋ࡞ࡈࡅࡔࡖ࠴࠱࠶ࡹࡴࠨਝ"))
		wN6n7OZBoDkTvCi8LdbJjYV = xHb86g9WZqPwRfVjXD2JalzSIp.content
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall(NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠧ࠽ࡸ࡬ࡨࡪࡵࠨ࠯ࠬࡂ࠭ࡁ࠵ࡶࡪࡦࡨࡳࡃ࠭ਞ"),wN6n7OZBoDkTvCi8LdbJjYV,My7Dwqvs6bfGNSIgX.DOTALL)
		if XBuP6Op7y4K:
			vsptNMP2ZQC = XBuP6Op7y4K[NVS30xAdRFMIw1n9CislkE2(u"࠱ဎ")]
			items = My7Dwqvs6bfGNSIgX.findall(BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵ࡬ࡾࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧਟ"),vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
			for BoEFz2WhUyvTgDeiZ,LLnUyuiC2wRM0 in items:
				if BoEFz2WhUyvTgDeiZ not in Qki8AbTHYjzM2Ls76Gdr3eqo1Wn:
					Qki8AbTHYjzM2Ls76Gdr3eqo1Wn.append(BoEFz2WhUyvTgDeiZ)
					LkVZrOE4XBSN2Qex5PyHqC = ooq2D9xF8ZLpPBs(BoEFz2WhUyvTgDeiZ,sRth5giAQzWlEVm7JOX(u"ࠩࡱࡥࡲ࡫ࠧਠ"))
					breQmB38nWlfEc6CNT.append(LkVZrOE4XBSN2Qex5PyHqC+YB5xyI7MaRslVpv(u"ࠪࠤࠥ࠭ਡ")+LLnUyuiC2wRM0)
			return V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠫࠬਢ"),breQmB38nWlfEc6CNT,Qki8AbTHYjzM2Ls76Gdr3eqo1Wn
	elif RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠬ࠵ࡤ࠰ࠩਣ") in url:
		xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(SToQEHqGtMnAlFbCz4wxBDuOsmW7,rbjsM8cRFiuA1(u"࠭ࡇࡆࡖࠪਤ"),url,nr5mZG89ICi6cgt4MfLJa0(u"ࠧࠨਥ"),UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠨࠩਦ"),b05yftsZ6NYgIKP(u"ࠩࠪਧ"),LgpdP3UjFRnlX(u"ࠪࠫਨ"),UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆࡉ࡜ࡆࡊ࡙ࡔ࠲࠯࠵ࡲࡩ࠭਩"))
		wN6n7OZBoDkTvCi8LdbJjYV = xHb86g9WZqPwRfVjXD2JalzSIp.content
		BoEFz2WhUyvTgDeiZ = My7Dwqvs6bfGNSIgX.findall(BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠬࡂࡩࡧࡴࡤࡱࡪ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ਪ"),wN6n7OZBoDkTvCi8LdbJjYV,My7Dwqvs6bfGNSIgX.DOTALL)
		if BoEFz2WhUyvTgDeiZ:
			BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ[qbPw1d3KimF(u"࠲ဏ")].replace(jx7s8T0BFgODXLMzIYedf(u"࠭࠯࠲࠱ࠪਫ"),gItVahxL0w(u"ࠧ࠰࠶࠲ࠫਬ"))
			xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(SToQEHqGtMnAlFbCz4wxBDuOsmW7,BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠨࡉࡈࡘࠬਭ"),BoEFz2WhUyvTgDeiZ,V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠩࠪਮ"),WMkAjB1RgN7q(u"ࠪࠫਯ"),WMkAjB1RgN7q(u"ࡆࡢ࡮ࡶࡩᄥ"),BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠫࠬਰ"),rbjsM8cRFiuA1(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡇࡊ࡝ࡇࡋࡓࡕ࠳࠰࠷ࡷࡪࠧ਱"))
			wN6n7OZBoDkTvCi8LdbJjYV = xHb86g9WZqPwRfVjXD2JalzSIp.content
			BoEFz2WhUyvTgDeiZ = My7Dwqvs6bfGNSIgX.findall(C2dgEDAKQGsvh(u"࠭ࡣ࡭ࡣࡶࡷ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ਲ"),wN6n7OZBoDkTvCi8LdbJjYV,My7Dwqvs6bfGNSIgX.DOTALL)
			if BoEFz2WhUyvTgDeiZ: return BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪਲ਼"),[UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠨࠩ਴")],[BoEFz2WhUyvTgDeiZ[jSu5Cg2Ub1OAkZVs8Yoz(u"࠳တ")]]
	elif rbjsM8cRFiuA1(u"ࠩ࠲ࡶࡴࡲࡥ࠰ࠩਵ") in url:
		headers = {v5EA6TqHX3s4jzBMk(u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫਸ਼"):PZjG9QsCtzpMg2TcE}
		xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(f9Oum6c0FotxYn,l0WAe1f7Bpi5ZXk(u"ࠫࡌࡋࡔࠨ਷"),url,BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠬ࠭ਸ"),headers,NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࡇࡣ࡯ࡷࡪᄦ"),sRth5giAQzWlEVm7JOX(u"࠭ࠧਹ"),EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡉࡌ࡟ࡂࡆࡕࡗ࠵࠲࠺ࡴࡩࠩ਺"))
		BoEFz2WhUyvTgDeiZ = xHb86g9WZqPwRfVjXD2JalzSIp.headers[NVS30xAdRFMIw1n9CislkE2(u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ਻")]
		xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(f9Oum6c0FotxYn,WMkAjB1RgN7q(u"ࠩࡊࡉ਼࡙࠭"),BoEFz2WhUyvTgDeiZ,BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠪࠫ਽"),BoWHNb9daQVCF16A(u"ࠫࠬਾ"),jx7s8T0BFgODXLMzIYedf(u"ࠬ࠭ਿ"),jx7s8T0BFgODXLMzIYedf(u"࠭ࠧੀ"),k5dztomYyN3H(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡉࡌ࡟ࡂࡆࡕࡗ࠵࠲࠻ࡴࡩࠩੁ"))
		MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
		ptkR1Tydzs,breQmB38nWlfEc6CNT,Qki8AbTHYjzM2Ls76Gdr3eqo1Wn = R8y0kQhOcgX(BoEFz2WhUyvTgDeiZ,MK6ZT2zjC1SbmveNFqor)
		return ptkR1Tydzs,breQmB38nWlfEc6CNT,Qki8AbTHYjzM2Ls76Gdr3eqo1Wn
	elif UnWjVbo503mEMv9KF(u"ࠨ࠱ࡧࡳࡼࡴ࡬ࡰࡣࡧ࠳ࠬੂ") in url:
		bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = url.replace(BoWHNb9daQVCF16A(u"ࠩ࠲ࡨࡴࡽ࡮࡭ࡱࡤࡨ࠴࠭੃"),b05yftsZ6NYgIKP(u"ࠪ࠳ࡸࡩࡲࡪࡲࡷ࠳ࠬ੄"))
		eIL9BxdTbZj = {QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ੅"):PZjG9QsCtzpMg2TcE}
		xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(f9Oum6c0FotxYn,BoWHNb9daQVCF16A(u"ࠬࡍࡅࡕࠩ੆"),bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠭ࠧੇ"),eIL9BxdTbZj,WMkAjB1RgN7q(u"ࡈࡤࡰࡸ࡫ᄧ"),EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠧࠨੈ"),jx7s8T0BFgODXLMzIYedf(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡊࡍ࡙ࡃࡇࡖࡘ࠶࠳࠶ࡵࡪࠪ੉"))
		MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
		BoEFz2WhUyvTgDeiZ = My7Dwqvs6bfGNSIgX.findall(RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠩ࠿࡭࡫ࡸࡡ࡮ࡧ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ੊"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if BoEFz2WhUyvTgDeiZ:
			BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ[l0WAe1f7Bpi5ZXk(u"࠴ထ")]
			xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(f9Oum6c0FotxYn,nr5mZG89ICi6cgt4MfLJa0(u"ࠪࡋࡊ࡚ࠧੋ"),BoEFz2WhUyvTgDeiZ,BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠫࠬੌ"),eIL9BxdTbZj,k5dztomYyN3H(u"ࡉࡥࡱࡹࡥᄨ"),fY5wTlhtnOc0Er6sdy4k87b(u"੍ࠬ࠭"),vvHpKfcqRnrFzjG(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡈࡋ࡞ࡈࡅࡔࡖ࠴࠱࠼ࡺࡨࠨ੎"))
			MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
			BoEFz2WhUyvTgDeiZ = xHb86g9WZqPwRfVjXD2JalzSIp.headers[v5EA6TqHX3s4jzBMk(u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ੏")]
			xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(f9Oum6c0FotxYn,nr5mZG89ICi6cgt4MfLJa0(u"ࠨࡉࡈࡘࠬ੐"),BoEFz2WhUyvTgDeiZ,hhlbF1Sns5TrEN8QPCYmL4(u"ࠩࠪੑ"),eIL9BxdTbZj,C2dgEDAKQGsvh(u"ࡊࡦࡲࡳࡦᄩ"),C2jP0iLNGKnHu9xp(u"ࠪࠫ੒"),BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆࡉ࡜ࡆࡊ࡙ࡔ࠲࠯࠻ࡸ࡭࠭੓"))
			MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
			ptkR1Tydzs,breQmB38nWlfEc6CNT,Qki8AbTHYjzM2Ls76Gdr3eqo1Wn = R8y0kQhOcgX(BoEFz2WhUyvTgDeiZ,MK6ZT2zjC1SbmveNFqor)
			if Qki8AbTHYjzM2Ls76Gdr3eqo1Wn: return ptkR1Tydzs,breQmB38nWlfEc6CNT,Qki8AbTHYjzM2Ls76Gdr3eqo1Wn
	else: return EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ੔"),[b05yftsZ6NYgIKP(u"࠭ࠧ੕")],[url]
	return UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡈࡋ࡞ࡈࡅࡔࡖ࠴ࠫ੖"),[],[]
def LLWVaQmdit(url):
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(SToQEHqGtMnAlFbCz4wxBDuOsmW7,BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠨࡉࡈࡘࠬ੗"),url,UnWjVbo503mEMv9KF(u"ࠩࠪ੘"),T6wRistc1SCo4hqObgumK(u"ࠪࠫਖ਼"),qbPw1d3KimF(u"ࠫࠬਗ਼"),BoWHNb9daQVCF16A(u"ࠬ࠭ਜ਼"),jSu5Cg2Ub1OAkZVs8Yoz(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡈࡋ࡞ࡈࡅࡔࡖ࠶࠱࠶ࡹࡴࠨੜ"))
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	data = My7Dwqvs6bfGNSIgX.findall(v5EA6TqHX3s4jzBMk(u"ࠧࠣࡣࡦࡸ࡮ࡵ࡮ࠣ࠰࠭ࡃࡻࡧ࡬ࡶࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡶࡢ࡮ࡸࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡸࡤࡰࡺ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ੝"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if data:
		bNloL1cdIQeMaFxshtPv7R3V,id,FFS9Id7VOy5Xefb = data[rbjsM8cRFiuA1(u"࠵ဒ")]
		data = l0WAe1f7Bpi5ZXk(u"ࠨࡱࡳࡁࠬਫ਼")+bNloL1cdIQeMaFxshtPv7R3V+v5EA6TqHX3s4jzBMk(u"ࠩࠩ࡭ࡩࡃࠧ੟")+id+sRth5giAQzWlEVm7JOX(u"ࠪࠪ࡫ࡴࡡ࡮ࡧࡀࠫ੠")+FFS9Id7VOy5Xefb
		headers = {vvHpKfcqRnrFzjG(u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ੡"):qbPw1d3KimF(u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧࠫ੢")}
		xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(SToQEHqGtMnAlFbCz4wxBDuOsmW7,C2jP0iLNGKnHu9xp(u"࠭ࡐࡐࡕࡗࠫ੣"),url,data,headers,fY5wTlhtnOc0Er6sdy4k87b(u"ࠧࠨ੤"),BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠨࠩ੥"),LgpdP3UjFRnlX(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡋࡇ࡚ࡄࡈࡗ࡙࠹࠭࠳ࡰࡧࠫ੦"))
		MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
		BoEFz2WhUyvTgDeiZ = My7Dwqvs6bfGNSIgX.findall(NVS30xAdRFMIw1n9CislkE2(u"ࠪࠦࡷ࡫ࡦࡦࡴࡨࡶࠧࠦࡶࡢ࡮ࡸࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭੧"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if BoEFz2WhUyvTgDeiZ: return gItVahxL0w(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ੨"),[BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠬ࠭੩")],[BoEFz2WhUyvTgDeiZ[sRth5giAQzWlEVm7JOX(u"࠶ဓ")]]
	return BmcLzCFjuIrZP5fwXH18aN6YS(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡇࡊ࡝ࡇࡋࡓࡕ࠳ࠪ੪"),[],[]
def Uyd9BOm3hq(url):
	bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = url.split(l0WAe1f7Bpi5ZXk(u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ੫"),nr5mZG89ICi6cgt4MfLJa0(u"࠱န"))[BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠱ပ")].strip(WMkAjB1RgN7q(u"ࠨࡁࠪ੬")).strip(b05yftsZ6NYgIKP(u"ࠩ࠲ࠫ੭")).strip(BoWHNb9daQVCF16A(u"ࠪࠪࠬ੮"))
	wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i,items,QAKdHzO0rehbtyIc = [],[],[],sRth5giAQzWlEVm7JOX(u"ࠫࠬ੯")
	headers = { gItVahxL0w(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩੰ"):PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"࠭ࡍࡰࡼ࡬ࡰࡱࡧ࠯࠶࠰࠳ࠤ࠭࡝ࡩ࡯ࡦࡲࡻࡸࠦࡎࡕࠢ࠴࠴࠳࠶࠻࡙ࠡ࡬ࡲ࠻࠺࠻ࠡࡺ࠹࠸࠮࠭ੱ") }
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(f9Oum6c0FotxYn,YB5xyI7MaRslVpv(u"ࠧࡈࡇࡗࠫੲ"),bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠨࠩੳ"),headers,UnWjVbo503mEMv9KF(u"࡙ࡸࡵࡦᄪ"),C2jP0iLNGKnHu9xp(u"ࠩࠪੴ"),b05yftsZ6NYgIKP(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅࡈ࡛ࡅࡉࡘ࡚࠭࠲ࡵࡷࠫੵ"))
	if C2jP0iLNGKnHu9xp(u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭੶") in list(xHb86g9WZqPwRfVjXD2JalzSIp.headers.keys()): QAKdHzO0rehbtyIc = xHb86g9WZqPwRfVjXD2JalzSIp.headers[gItVahxL0w(u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ੷")]
	if FGDJwkEbTB5SoXujs3f(u"࠭ࡨࡵࡶࡳࠫ੸") in QAKdHzO0rehbtyIc:
		if k5dztomYyN3H(u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨ੹") in url: QAKdHzO0rehbtyIc = QAKdHzO0rehbtyIc.replace(WMkAjB1RgN7q(u"ࠨ࠱ࡩ࠳ࠬ੺"),T6wRistc1SCo4hqObgumK(u"ࠩ࠲ࡺ࠴࠭੻"))
		wnX7G9LyZ0ABRFqrsf = bJEs4IVAPdyUrhwCLv9k2YoOl8nt1.split(UnWjVbo503mEMv9KF(u"ࠪࡃࡕࡎࡐࡔࡋࡇࡁࠬ੼"))[UxS67uoGThbMwnfNRzy4gajLd23JH(u"࠳ဖ")]
		headers = { QynMHGWA0blfqTUdxRh5Jzi2t(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ੽"):headers[NVS30xAdRFMIw1n9CislkE2(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ੾")] , UxS67uoGThbMwnfNRzy4gajLd23JH(u"࠭ࡃࡰࡱ࡮࡭ࡪ࠭੿"):fY5wTlhtnOc0Er6sdy4k87b(u"ࠧࡑࡊࡓࡗࡎࡊ࠽ࠨ઀")+wnX7G9LyZ0ABRFqrsf }
		xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(f9Oum6c0FotxYn,T6wRistc1SCo4hqObgumK(u"ࠨࡉࡈࡘࠬઁ"),QAKdHzO0rehbtyIc,fY5wTlhtnOc0Er6sdy4k87b(u"ࠩࠪં"),headers,b05yftsZ6NYgIKP(u"ࡌࡡ࡭ࡵࡨᄫ"),BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠪࠫઃ"),gItVahxL0w(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠲ࡖࡌࡂ࡛࠰࠷ࡷࡪࠧ઄"))
		MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
		if UnWjVbo503mEMv9KF(u"ࠬ࠵ࡦ࠰ࠩઅ") in QAKdHzO0rehbtyIc: items = My7Dwqvs6bfGNSIgX.findall(PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"࠭࠼ࡩ࠴ࡁ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬઆ"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		elif BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠧ࠰ࡸ࠲ࠫઇ") in QAKdHzO0rehbtyIc: items = My7Dwqvs6bfGNSIgX.findall(b05yftsZ6NYgIKP(u"ࠨ࡫ࡧࡁࠧࡼࡩࡥࡧࡲࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬઈ"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if items: return [],[nr5mZG89ICi6cgt4MfLJa0(u"ࠩࠪઉ")],[ items[qbPw1d3KimF(u"࠳ဗ")] ]
		elif hhlbF1Sns5TrEN8QPCYmL4(u"ࠪࡀ࡭࠷࠾࠵࠲࠷ࡀ࠴࡮࠱࠿ࠩઊ") in MK6ZT2zjC1SbmveNFqor:
			return LgpdP3UjFRnlX(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤุ๐ัโำࠣห้็๊ะ์๋ࠤๆ๐็ࠡฯฯฬࠥ฼ฯࠡๅ๋ำ๏่ࠦๆืาี์ࠦๅ็ࠢส่ส์สา่อࠤฬ๊ฮศืฬࠤอ้ࠧઋ"),[],[]
	else: return EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡆࡉ࡜ࡆࡊ࡙ࡔࠨઌ"),[],[]
def llkjuqJVXU(BoEFz2WhUyvTgDeiZ):
	tuHzpfZmLAdCObQS2k3 = My7Dwqvs6bfGNSIgX.findall(vvHpKfcqRnrFzjG(u"࠭ࡰࡰࡵࡷ࡭ࡩࡃࠨ࠯ࠬࡂ࠭ࠫࡹࡥࡳࡸࡨࡶ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠬࠦࠨઍ"),BoEFz2WhUyvTgDeiZ+hhlbF1Sns5TrEN8QPCYmL4(u"ࠧࠧࠨࠪ઎"),My7Dwqvs6bfGNSIgX.DOTALL|My7Dwqvs6bfGNSIgX.IGNORECASE)
	IIi2NYTdvHzGUQ89EBLOgqr,p8hzHJnjC95karceyWxX = tuHzpfZmLAdCObQS2k3[NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠴ဘ")]
	url = UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡶࡩࡷ࡯ࡥࡴ࠶ࡺࡥࡹࡩࡨ࠯ࡰࡨࡸ࠴ࡧࡪࡢࡺࡆࡩࡳࡺࡥࡳࡁࡢࡥࡨࡺࡩࡰࡰࡀ࡫ࡪࡺࡳࡦࡴࡹࡩࡷࠬ࡟ࡱࡱࡶࡸࡤ࡯ࡤ࠾ࠩએ")+IIi2NYTdvHzGUQ89EBLOgqr+vvHpKfcqRnrFzjG(u"ࠩࠩࡷࡪࡸࡶࡦࡴ࡬ࡨࡂ࠭ઐ")+p8hzHJnjC95karceyWxX
	headers = { b05yftsZ6NYgIKP(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧઑ"):BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠫࠬ઒") , UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠬ࡞࠭ࡓࡧࡴࡹࡪࡹࡴࡦࡦ࠰࡛࡮ࡺࡨࠨઓ"):EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠭ࡘࡎࡎࡋࡸࡹࡶࡒࡦࡳࡸࡩࡸࡺࠧઔ") }
	bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = YY0KEWamSIc46n3kbtuLgZV(f9Oum6c0FotxYn,url,vvHpKfcqRnrFzjG(u"ࠧࠨક"),headers,NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠨࠩખ"),UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡙ࡅࡓࡋࡈࡗ࠹࡝ࡁࡕࡅࡋ࠱࠶ࡹࡴࠨગ"))
	return hhlbF1Sns5TrEN8QPCYmL4(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ઘ"),[jx7s8T0BFgODXLMzIYedf(u"ࠫࠬઙ")],[bJEs4IVAPdyUrhwCLv9k2YoOl8nt1]
def xPDZYpvG74(url):
	LkVZrOE4XBSN2Qex5PyHqC = ooq2D9xF8ZLpPBs(url,vvHpKfcqRnrFzjG(u"ࠬࡻࡲ࡭ࠩચ"))
	eIL9BxdTbZj = {NVS30xAdRFMIw1n9CislkE2(u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧછ"):LkVZrOE4XBSN2Qex5PyHqC,QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠧࡂࡥࡦࡩࡵࡺ࠭ࡆࡰࡦࡳࡩ࡯࡮ࡨࠩજ"):EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠨࡩࡽ࡭ࡵ࠲ࠠࡥࡧࡩࡰࡦࡺࡥࠨઝ")}
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(c1lwnq73vkXsVjEhFpeoZtD,LgpdP3UjFRnlX(u"ࠩࡊࡉ࡙࠭ઞ"),url,sRth5giAQzWlEVm7JOX(u"ࠪࠫટ"),eIL9BxdTbZj,gItVahxL0w(u"ࠫࠬઠ"),FGDJwkEbTB5SoXujs3f(u"ࠬ࠭ડ"),b05yftsZ6NYgIKP(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡐ࡝ࡈࡏࡍࡂ࠯࠴ࡷࡹ࠭ઢ"))
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall(v5EA6TqHX3s4jzBMk(u"ࠧࡱ࡮ࡤࡽࡪࡸ࠮ࡲࡷࡤࡰ࡮ࡺࡹࡴࡧ࡯ࡩࡨࡺ࡯ࡳࠪ࠱࠮ࡄ࠯ࡦࡰࡴࡰࡥࡹࡹ࠺ࠨણ"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = FGDJwkEbTB5SoXujs3f(u"ࠨࠩત")
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[NVS30xAdRFMIw1n9CislkE2(u"࠵မ")]
		items = My7Dwqvs6bfGNSIgX.findall(b05yftsZ6NYgIKP(u"ࠩࡩࡳࡷࡳࡡࡵ࠼ࠣࡠࠬ࠮࡜ࡥ࠰࠭ࡃ࠮ࡢࠧ࠭ࠢࡶࡶࡨࡀࠠࠣࠪ࠱࠮ࡄ࠯ࠢࠨથ"),vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = [],[]
		for title,BoEFz2WhUyvTgDeiZ in items:
			wlfZEzuRyYLvrp.append(title)
			QQ2cE1FjUyxPonbDhaTkV6B3i.append(BoEFz2WhUyvTgDeiZ)
		if len(QQ2cE1FjUyxPonbDhaTkV6B3i)==YB5xyI7MaRslVpv(u"࠷ယ"): bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = QQ2cE1FjUyxPonbDhaTkV6B3i[C2dgEDAKQGsvh(u"࠰ရ")]
		elif len(QQ2cE1FjUyxPonbDhaTkV6B3i)>vvHpKfcqRnrFzjG(u"࠲လ"):
			GOtNfU3xQFkEhPouwA = CnKwdteDG5BE8MTRhUpYIJm3NLrSgq(BoWHNb9daQVCF16A(u"ࠪวำะัࠡษ็้้็ࠠศๆ่๊ฬูศࠨદ"), wlfZEzuRyYLvrp)
			if GOtNfU3xQFkEhPouwA==-rbjsM8cRFiuA1(u"࠳ဝ"): return hhlbF1Sns5TrEN8QPCYmL4(u"ࠫࠬધ"),[],[]
			bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = QQ2cE1FjUyxPonbDhaTkV6B3i[GOtNfU3xQFkEhPouwA]
	else:
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall(rbjsM8cRFiuA1(u"ࠬࡹ࡯ࡶࡴࡦࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪન"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if XBuP6Op7y4K: bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = XBuP6Op7y4K[fY5wTlhtnOc0Er6sdy4k87b(u"࠳သ")]
	if not bJEs4IVAPdyUrhwCLv9k2YoOl8nt1: return NVS30xAdRFMIw1n9CislkE2(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡏ࡜ࡇࡎࡓࡁࠨ઩"),[],[]
	return b05yftsZ6NYgIKP(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪપ"),[WMkAjB1RgN7q(u"ࠨࠩફ")],[bJEs4IVAPdyUrhwCLv9k2YoOl8nt1]
def qbHfJWnrKv(url):
	LkVZrOE4XBSN2Qex5PyHqC = ooq2D9xF8ZLpPBs(url,nr5mZG89ICi6cgt4MfLJa0(u"ࠩࡸࡶࡱ࠭બ"))
	eIL9BxdTbZj = {C2jP0iLNGKnHu9xp(u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫભ"):LkVZrOE4XBSN2Qex5PyHqC,jx7s8T0BFgODXLMzIYedf(u"ࠫࡆࡩࡣࡦࡲࡷ࠱ࡊࡴࡣࡰࡦ࡬ࡲ࡬࠭મ"):NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠬ࡭ࡺࡪࡲ࠯ࠤࡩ࡫ࡦ࡭ࡣࡷࡩࠬય")}
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(c1lwnq73vkXsVjEhFpeoZtD,FGDJwkEbTB5SoXujs3f(u"࠭ࡇࡆࡖࠪર"),url,PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠧࠨ઱"),eIL9BxdTbZj,RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠨࠩલ"),nr5mZG89ICi6cgt4MfLJa0(u"ࠩࠪળ"),BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡗࡆࡅࡌࡑࡆ࠳࠱ࡴࡶࠪ઴"))
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall(UnWjVbo503mEMv9KF(u"ࠫࡵࡲࡡࡺࡧࡵ࠲ࡶࡻࡡ࡭࡫ࡷࡽࡸ࡫࡬ࡦࡥࡷࡳࡷ࠮࠮ࠫࡁࠬࡪࡴࡸ࡭ࡢࡶࡶ࠾ࠬવ"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠬ࠭શ")
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[jx7s8T0BFgODXLMzIYedf(u"࠴ဟ")]
		items = My7Dwqvs6bfGNSIgX.findall(v5EA6TqHX3s4jzBMk(u"࠭ࡦࡰࡴࡰࡥࡹࡀࠠ࡝ࠩࠫࡠࡩ࠴ࠪࡀࠫ࡟ࠫ࠱ࠦࡳࡳࡥ࠽ࠤࠧ࠮࠮ࠫࡁࠬࠦࠬષ"),vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = [],[]
		for title,BoEFz2WhUyvTgDeiZ in items:
			wlfZEzuRyYLvrp.append(title)
			QQ2cE1FjUyxPonbDhaTkV6B3i.append(BoEFz2WhUyvTgDeiZ)
		if len(QQ2cE1FjUyxPonbDhaTkV6B3i)==nr5mZG89ICi6cgt4MfLJa0(u"࠶ဠ"): bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = QQ2cE1FjUyxPonbDhaTkV6B3i[nr5mZG89ICi6cgt4MfLJa0(u"࠶အ")]
		elif len(QQ2cE1FjUyxPonbDhaTkV6B3i)>C2jP0iLNGKnHu9xp(u"࠱ဢ"):
			GOtNfU3xQFkEhPouwA = CnKwdteDG5BE8MTRhUpYIJm3NLrSgq(rbjsM8cRFiuA1(u"ࠧฤะอีࠥอไๆๆไࠤฬ๊ๅ็ษึฬࠬસ"), wlfZEzuRyYLvrp)
			if GOtNfU3xQFkEhPouwA==-BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠲ဣ"): return V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠨࠩહ"),[],[]
			bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = QQ2cE1FjUyxPonbDhaTkV6B3i[GOtNfU3xQFkEhPouwA]
	if not bJEs4IVAPdyUrhwCLv9k2YoOl8nt1:
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall(jx7s8T0BFgODXLMzIYedf(u"ࠩࡶࡳࡺࡸࡣࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ઺"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if XBuP6Op7y4K: bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = XBuP6Op7y4K[C2jP0iLNGKnHu9xp(u"࠲ဤ")]
	if not bJEs4IVAPdyUrhwCLv9k2YoOl8nt1: return l0WAe1f7Bpi5ZXk(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥ࡝ࡅࡄࡋࡐࡅࠬ઻"),[],[]
	return rbjsM8cRFiuA1(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ઼࡙ࠧ"),[sRth5giAQzWlEVm7JOX(u"ࠬ࠭ઽ")],[bJEs4IVAPdyUrhwCLv9k2YoOl8nt1]
def kkm9QT8Kbn(BoEFz2WhUyvTgDeiZ):
	tuHzpfZmLAdCObQS2k3 = My7Dwqvs6bfGNSIgX.findall(l0WAe1f7Bpi5ZXk(u"࠭ࠨࡩࡶࡷࡴ࠳࠰࠿ࠪ࡞ࡂࡴࡴࡹࡴࡪࡦࡀࠬ࠳࠰࠿ࠪࠨࡶࡩࡷࡼࡥࡳ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠩࠪࠬા"),BoEFz2WhUyvTgDeiZ+V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠧࠧࠨࠪિ"),My7Dwqvs6bfGNSIgX.DOTALL)
	url,IIi2NYTdvHzGUQ89EBLOgqr,p8hzHJnjC95karceyWxX = tuHzpfZmLAdCObQS2k3[sRth5giAQzWlEVm7JOX(u"࠳ဥ")]
	data = {V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠨࡲࡲࡷࡹࡥࡩࡥࠩી"):IIi2NYTdvHzGUQ89EBLOgqr,YB5xyI7MaRslVpv(u"ࠩࡶࡩࡷࡼࡥࡳࠩુ"):p8hzHJnjC95karceyWxX}
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,C2dgEDAKQGsvh(u"ࠪࡔࡔ࡙ࡔࠨૂ"),url,data,LgpdP3UjFRnlX(u"ࠫࠬૃ"),gItVahxL0w(u"ࠬ࠭ૄ"),qbPw1d3KimF(u"࠭ࠧૅ"),jx7s8T0BFgODXLMzIYedf(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡐࡕࡁࡎࡅࡄࡑ࠲࠷ࡳࡵࠩ૆"))
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = My7Dwqvs6bfGNSIgX.findall(V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠨ࡫ࡩࡶࡦࡳࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ે"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)[l0WAe1f7Bpi5ZXk(u"࠴ဦ")]
	return NVS30xAdRFMIw1n9CislkE2(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬૈ"),[fY5wTlhtnOc0Er6sdy4k87b(u"ࠪࠫૉ")],[bJEs4IVAPdyUrhwCLv9k2YoOl8nt1]
def BkeL3UtRAW(url):
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,NVS30xAdRFMIw1n9CislkE2(u"ࠫࡌࡋࡔࠨ૊"),url,v5EA6TqHX3s4jzBMk(u"ࠬ࠭ો"),gItVahxL0w(u"࠭ࠧૌ"),WMkAjB1RgN7q(u"ࠧࠨ્"),T6wRistc1SCo4hqObgumK(u"ࠨࠩ૎"),vvHpKfcqRnrFzjG(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡉࡉࡎࡃࡏࡍࡌࡎࡔ࠮࠳ࡶࡸࠬ૏"))
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	BoEFz2WhUyvTgDeiZ = My7Dwqvs6bfGNSIgX.findall(NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠪࡀ࡮࡬ࡲࡢ࡯ࡨ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫૐ"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if BoEFz2WhUyvTgDeiZ:
		BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ[C2jP0iLNGKnHu9xp(u"࠵ဧ")]
		if BoEFz2WhUyvTgDeiZ: return C2jP0iLNGKnHu9xp(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ૑"),[jSu5Cg2Ub1OAkZVs8Yoz(u"ࠬ࠭૒")],[BoEFz2WhUyvTgDeiZ]
	return YB5xyI7MaRslVpv(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡅࡌࡑࡆࡒࡉࡈࡊࡗࠫ૓"),[],[]
def RcVUhTGuSn(url):
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,v5EA6TqHX3s4jzBMk(u"ࠧࡈࡇࡗࠫ૔"),url,nr5mZG89ICi6cgt4MfLJa0(u"ࠨࠩ૕"),UnWjVbo503mEMv9KF(u"ࠩࠪ૖"),UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠪࠫ૗"),PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠫࠬ૘"),YB5xyI7MaRslVpv(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡅࡌࡑࡆࡉࡌࡖࡒ࠰࠵ࡸࡺࠧ૙"))
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	BoEFz2WhUyvTgDeiZ = My7Dwqvs6bfGNSIgX.findall(vvHpKfcqRnrFzjG(u"࠭࠼ࡊࡈࡕࡅࡒࡋࠠࡔࡔࡆࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ૚"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)[k5dztomYyN3H(u"࠶ဨ")]
	return C2jP0iLNGKnHu9xp(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ૛"),[LgpdP3UjFRnlX(u"ࠨࠩ૜")],[BoEFz2WhUyvTgDeiZ]
def nb2dEKuRFN(url):
	ulX0L8F7ZqcwGTJRMk = ooq2D9xF8ZLpPBs(url,jx7s8T0BFgODXLMzIYedf(u"ࠩࡸࡶࡱ࠭૝"))
	if QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠪ࡭ࡳࡪࡥࡹ࠿ࠪ૞") in url:
		headers = {C2dgEDAKQGsvh(u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ૟"):ulX0L8F7ZqcwGTJRMk}
		xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,LgpdP3UjFRnlX(u"ࠬࡍࡅࡕࠩૠ"),url,vvHpKfcqRnrFzjG(u"࠭ࠧૡ"),headers,vvHpKfcqRnrFzjG(u"ࠧࠨૢ"),hhlbF1Sns5TrEN8QPCYmL4(u"ࠨࠩૣ"),RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡉࡉࡎࡃࡑࡓ࡜࠳࠱ࡴࡶࠪ૤"))
		MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
		bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = My7Dwqvs6bfGNSIgX.findall(BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ૥"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if bJEs4IVAPdyUrhwCLv9k2YoOl8nt1:
			bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = bJEs4IVAPdyUrhwCLv9k2YoOl8nt1[BmcLzCFjuIrZP5fwXH18aN6YS(u"࠰ဩ")]
			if BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠫ࡭ࡺࡴࡱࠩ૦") not in bJEs4IVAPdyUrhwCLv9k2YoOl8nt1: bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = b05yftsZ6NYgIKP(u"ࠬ࡮ࡴࡵࡲ࠽ࠫ૧")+bJEs4IVAPdyUrhwCLv9k2YoOl8nt1
			if C2jP0iLNGKnHu9xp(u"࠭ࡣࡪ࡯ࡤࡲࡴࡽࠧ૨") in bJEs4IVAPdyUrhwCLv9k2YoOl8nt1:
				bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = bJEs4IVAPdyUrhwCLv9k2YoOl8nt1.replace(T6wRistc1SCo4hqObgumK(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࠩ૩"),fY5wTlhtnOc0Er6sdy4k87b(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࠩ૪"))
				xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,LgpdP3UjFRnlX(u"ࠩࡊࡉ࡙࠭૫"),bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,rbjsM8cRFiuA1(u"ࠪࠫ૬"),headers,T6wRistc1SCo4hqObgumK(u"ࠫࠬ૭"),gItVahxL0w(u"ࠬ࠭૮"),YB5xyI7MaRslVpv(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡆࡍࡒࡇࡎࡐ࡙࠰࠶ࡳࡪࠧ૯"))
				wN6n7OZBoDkTvCi8LdbJjYV = xHb86g9WZqPwRfVjXD2JalzSIp.content
				items = My7Dwqvs6bfGNSIgX.findall(hhlbF1Sns5TrEN8QPCYmL4(u"ࠧࡴࡱࡸࡶࡨ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴ࡫ࡽࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭૰"),wN6n7OZBoDkTvCi8LdbJjYV,My7Dwqvs6bfGNSIgX.DOTALL)
				wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = [],[]
				M0RTIYy1EUX = ooq2D9xF8ZLpPBs(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠨࡷࡵࡰࠬ૱"))
				for BoEFz2WhUyvTgDeiZ,LLnUyuiC2wRM0 in reversed(items):
					BoEFz2WhUyvTgDeiZ = M0RTIYy1EUX+BoEFz2WhUyvTgDeiZ+NVS30xAdRFMIw1n9CislkE2(u"ࠩࡿࡖࡪ࡬ࡥࡳࡧࡵࡁࠬ૲")+M0RTIYy1EUX
					wlfZEzuRyYLvrp.append(LLnUyuiC2wRM0)
					QQ2cE1FjUyxPonbDhaTkV6B3i.append(BoEFz2WhUyvTgDeiZ)
				return vvHpKfcqRnrFzjG(u"ࠪࠫ૳"),wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i
			else: return WMkAjB1RgN7q(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ૴"),[b05yftsZ6NYgIKP(u"ࠬ࠭૵")],[bJEs4IVAPdyUrhwCLv9k2YoOl8nt1]
	bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = url+fY5wTlhtnOc0Er6sdy4k87b(u"࠭ࡼࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠩ૶")+ulX0L8F7ZqcwGTJRMk
	if QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠧࡩࡶࡷࡴࠬ૷") not in bJEs4IVAPdyUrhwCLv9k2YoOl8nt1: bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠨࡪࡷࡸࡵࡀࠧ૸")+bJEs4IVAPdyUrhwCLv9k2YoOl8nt1
	return fY5wTlhtnOc0Er6sdy4k87b(u"ࠩࠪૹ"),[RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠪࠫૺ")],[bJEs4IVAPdyUrhwCLv9k2YoOl8nt1]
def QdlkcK2s1eCiHmJE(BoEFz2WhUyvTgDeiZ):
	ulX0L8F7ZqcwGTJRMk = ooq2D9xF8ZLpPBs(BoEFz2WhUyvTgDeiZ,FGDJwkEbTB5SoXujs3f(u"ࠫࡺࡸ࡬ࠨૻ"))
	if UnWjVbo503mEMv9KF(u"ࠬࡶ࡯ࡴࡶ࡬ࡨࠬૼ") in BoEFz2WhUyvTgDeiZ:
		tuHzpfZmLAdCObQS2k3 = My7Dwqvs6bfGNSIgX.findall(fY5wTlhtnOc0Er6sdy4k87b(u"࠭ࠨࡩࡶࡷࡴ࠳࠰࠿ࠪ࡞ࡂࡴࡴࡹࡴࡪࡦࡀࠬ࠳࠰࠿ࠪࠨࡶࡩࡷࡼࡥࡳ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠩࠪࠬ૽"),BoEFz2WhUyvTgDeiZ+WMkAjB1RgN7q(u"ࠧࠧࠨࠪ૾"),My7Dwqvs6bfGNSIgX.DOTALL)
		url,IIi2NYTdvHzGUQ89EBLOgqr,p8hzHJnjC95karceyWxX = tuHzpfZmLAdCObQS2k3[UxS67uoGThbMwnfNRzy4gajLd23JH(u"࠱ဪ")]
		data = {YB5xyI7MaRslVpv(u"ࠨ࡫ࡧࠫ૿"):IIi2NYTdvHzGUQ89EBLOgqr,BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠩࡶࡩࡷࡼࡥࡳࠩ଀"):p8hzHJnjC95karceyWxX}
		xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,qbPw1d3KimF(u"ࠪࡔࡔ࡙ࡔࠨଁ"),url,data,jx7s8T0BFgODXLMzIYedf(u"ࠫࠬଂ"),fY5wTlhtnOc0Er6sdy4k87b(u"ࠬ࠭ଃ"),LgpdP3UjFRnlX(u"࠭ࠧ଄"),UnWjVbo503mEMv9KF(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡇࡎࡓࡁࡏࡑ࡚࠱࠶ࡹࡴࠨଅ"))
		MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
		bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = My7Dwqvs6bfGNSIgX.findall(k5dztomYyN3H(u"ࠨ࡫ࡩࡶࡦࡳࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ଆ"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)[T6wRistc1SCo4hqObgumK(u"࠲ါ")]
		if EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠩࡦ࡭ࡲࡧ࡮ࡰࡹࠪଇ") in bJEs4IVAPdyUrhwCLv9k2YoOl8nt1:
			headers = {LgpdP3UjFRnlX(u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫଈ"):ulX0L8F7ZqcwGTJRMk,UxS67uoGThbMwnfNRzy4gajLd23JH(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨଉ"):jSu5Cg2Ub1OAkZVs8Yoz(u"ࠬ࠭ଊ")}
			xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,v5EA6TqHX3s4jzBMk(u"࠭ࡇࡆࡖࠪଋ"),bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,b05yftsZ6NYgIKP(u"ࠧࠨଌ"),headers,hhlbF1Sns5TrEN8QPCYmL4(u"ࠨࠩ଍"),b05yftsZ6NYgIKP(u"ࠩࠪ଎"),sRth5giAQzWlEVm7JOX(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡃࡊࡏࡄࡒࡔ࡝࠭࠳ࡰࡧࠫଏ"))
			wN6n7OZBoDkTvCi8LdbJjYV = xHb86g9WZqPwRfVjXD2JalzSIp.content
			items = My7Dwqvs6bfGNSIgX.findall(QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸ࡯ࡺࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪଐ"),wN6n7OZBoDkTvCi8LdbJjYV,My7Dwqvs6bfGNSIgX.DOTALL)
			wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = [],[]
			M0RTIYy1EUX = ooq2D9xF8ZLpPBs(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠬࡻࡲ࡭ࠩ଑"))
			for BoEFz2WhUyvTgDeiZ,LLnUyuiC2wRM0 in reversed(items):
				BoEFz2WhUyvTgDeiZ = M0RTIYy1EUX+BoEFz2WhUyvTgDeiZ+NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠭ࡼࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠩ଒")+M0RTIYy1EUX
				wlfZEzuRyYLvrp.append(LLnUyuiC2wRM0)
				QQ2cE1FjUyxPonbDhaTkV6B3i.append(BoEFz2WhUyvTgDeiZ)
			return jSu5Cg2Ub1OAkZVs8Yoz(u"ࠧࠨଓ"),wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i
		else: return BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫଔ"),[jx7s8T0BFgODXLMzIYedf(u"ࠩࠪକ")],[bJEs4IVAPdyUrhwCLv9k2YoOl8nt1]
	else:
		BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ+EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠪࢀࡗ࡫ࡦࡦࡴࡨࡶࡂ࠭ଖ")+ulX0L8F7ZqcwGTJRMk
		return C2jP0iLNGKnHu9xp(u"ࠫࠬଗ"),[v5EA6TqHX3s4jzBMk(u"ࠬ࠭ଘ")],[BoEFz2WhUyvTgDeiZ]
def zZjawg7d34(BoEFz2WhUyvTgDeiZ):
	if C2jP0iLNGKnHu9xp(u"࠭ࡰࡰࡵࡷ࡭ࡩ࠭ଙ") in BoEFz2WhUyvTgDeiZ:
		tuHzpfZmLAdCObQS2k3 = My7Dwqvs6bfGNSIgX.findall(FGDJwkEbTB5SoXujs3f(u"ࠧࡱࡱࡶࡸ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠬࡳࡦࡴࡹࡩࡷ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠦࠧࠩଚ"),BoEFz2WhUyvTgDeiZ+YB5xyI7MaRslVpv(u"ࠨࠨࠩࠫଛ"),My7Dwqvs6bfGNSIgX.DOTALL|My7Dwqvs6bfGNSIgX.IGNORECASE)
		IIi2NYTdvHzGUQ89EBLOgqr,p8hzHJnjC95karceyWxX = tuHzpfZmLAdCObQS2k3[T6wRistc1SCo4hqObgumK(u"࠳ာ")]
		rhVzNXUIOclRnkJ0uqPvxg5wi = ooq2D9xF8ZLpPBs(BoEFz2WhUyvTgDeiZ,C2jP0iLNGKnHu9xp(u"ࠩࡸࡶࡱ࠭ଜ"))
		url = rhVzNXUIOclRnkJ0uqPvxg5wi+YB5xyI7MaRslVpv(u"ࠪ࠳ࡦࡰࡡࡹࡅࡨࡲࡹ࡫ࡲࡀࡡࡤࡧࡹ࡯࡯࡯࠿ࡪࡩࡹࡹࡥࡳࡸࡨࡶࠫࡥࡰࡰࡵࡷࡣ࡮ࡪ࠽ࠨଝ")+IIi2NYTdvHzGUQ89EBLOgqr+gItVahxL0w(u"ࠫࠫࡹࡥࡳࡸࡨࡶ࡮ࡪ࠽ࠨଞ")+p8hzHJnjC95karceyWxX
		headers = { PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩଟ"):UxS67uoGThbMwnfNRzy4gajLd23JH(u"࠭ࠧଠ") , BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࡙ࠧ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪࠪଡ"):NVS30xAdRFMIw1n9CislkE2(u"ࠨ࡚ࡐࡐࡍࡺࡴࡱࡔࡨࡵࡺ࡫ࡳࡵࠩଢ") }
		bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = YY0KEWamSIc46n3kbtuLgZV(f9Oum6c0FotxYn,url,v5EA6TqHX3s4jzBMk(u"ࠩࠪଣ"),headers,l0WAe1f7Bpi5ZXk(u"ࠪࠫତ"),l0WAe1f7Bpi5ZXk(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡔࡅࡐࡎࡕࡎ࡛࠯࠴ࡷࡹ࠭ଥ"))
		bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = bJEs4IVAPdyUrhwCLv9k2YoOl8nt1.replace(k5dztomYyN3H(u"ࠬࡢ࡮ࠨଦ"),UnWjVbo503mEMv9KF(u"࠭ࠧଧ")).replace(jx7s8T0BFgODXLMzIYedf(u"ࠧ࡝ࡴࠪନ"),BoWHNb9daQVCF16A(u"ࠨࠩ଩"))
		return rbjsM8cRFiuA1(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬପ"),[sRth5giAQzWlEVm7JOX(u"ࠪࠫଫ")],[bJEs4IVAPdyUrhwCLv9k2YoOl8nt1]
	elif QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠫ࠴ࡸࡥࡥ࡫ࡵࡩࡨࡺ࠯ࠨବ") in BoEFz2WhUyvTgDeiZ:
		WWMqcL9yHEm = C2jP0iLNGKnHu9xp(u"࠴ိ")
		while RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠬ࠵ࡲࡦࡦ࡬ࡶࡪࡩࡴ࠰ࠩଭ") in BoEFz2WhUyvTgDeiZ and WWMqcL9yHEm<nr5mZG89ICi6cgt4MfLJa0(u"࠺ီ"):
			xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(IIiPCruL6dT8s1lqj47SzpVHnYNm,gItVahxL0w(u"࠭ࡇࡆࡖࠪମ"),BoEFz2WhUyvTgDeiZ,FGDJwkEbTB5SoXujs3f(u"ࠧࠨଯ"),hhlbF1Sns5TrEN8QPCYmL4(u"ࠨࠩର"),gItVahxL0w(u"ࠩࠪ଱"),k5dztomYyN3H(u"ࠪࠫଲ"),C2dgEDAKQGsvh(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡔࡅࡐࡎࡕࡎ࡛࠯࠵ࡲࡩ࠭ଳ"))
			if PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ଴") in list(xHb86g9WZqPwRfVjXD2JalzSIp.headers.keys()): BoEFz2WhUyvTgDeiZ = xHb86g9WZqPwRfVjXD2JalzSIp.headers[qbPw1d3KimF(u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨଵ")]
			WWMqcL9yHEm += BoWHNb9daQVCF16A(u"࠷ု")
		return b05yftsZ6NYgIKP(u"ࠧࠨଶ"),[RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠨࠩଷ")],[BoEFz2WhUyvTgDeiZ]
	else: return YB5xyI7MaRslVpv(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡆࡘࡂࡍࡋࡒࡒ࡟࠭ସ"),[],[]
def YTJnkQy0SN(url):
	LkVZrOE4XBSN2Qex5PyHqC = ooq2D9xF8ZLpPBs(url,NVS30xAdRFMIw1n9CislkE2(u"ࠪࡹࡷࡲࠧହ"))
	headers = {hhlbF1Sns5TrEN8QPCYmL4(u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ଺"):LkVZrOE4XBSN2Qex5PyHqC,NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ଻"):IeSGolOpBHM8U62m()}
	if C2jP0iLNGKnHu9xp(u"࠭࠯ࡦ࡯ࡥࡩࡩ࠳଼ࠧ") in url:
		MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(f9Oum6c0FotxYn,url,NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠧࠨଽ"),headers,T6wRistc1SCo4hqObgumK(u"ࠨࠩା"),LgpdP3UjFRnlX(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡒࡂࡄࡖࡉࡊࡊ࠭࠳ࡰࡧࠫି"))
		BoEFz2WhUyvTgDeiZ = My7Dwqvs6bfGNSIgX.findall(nr5mZG89ICi6cgt4MfLJa0(u"ࠪࡀࡸࡵࡵࡳࡥࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩୀ"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if BoEFz2WhUyvTgDeiZ:
			BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ[gItVahxL0w(u"࠰ူ")].replace(sRth5giAQzWlEVm7JOX(u"ࠫ࡭ࡺࡴࡱࡵࠪୁ"),l0WAe1f7Bpi5ZXk(u"ࠬ࡮ࡴࡵࡲࠪୂ"))
			return LgpdP3UjFRnlX(u"࠭ࠧୃ"),[BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠧࠨୄ")],[BoEFz2WhUyvTgDeiZ]
	else:
		c4eTspFg5VRx06lI = mORwgTnXBdQ7iCSHKf(IIiPCruL6dT8s1lqj47SzpVHnYNm,jSu5Cg2Ub1OAkZVs8Yoz(u"ࠨࡉࡈࡘࠬ୅"),url,qbPw1d3KimF(u"ࠩࠪ୆"),headers,EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠪࠫେ"),k5dztomYyN3H(u"ࠫࠬୈ"),rbjsM8cRFiuA1(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡕࡅࡇ࡙ࡅࡆࡆ࠰࠷ࡷࡪࠧ୉"))
		MK6ZT2zjC1SbmveNFqor = c4eTspFg5VRx06lI.content
		eIL9BxdTbZj = headers.copy()
		if BoWHNb9daQVCF16A(u"࠭࡟࡭ࡰ࡮ࡣࠬ୊") in str(c4eTspFg5VRx06lI.cookies):
			cookies = c4eTspFg5VRx06lI.cookies
			eIL9BxdTbZj[UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠧࡄࡱࡲ࡯࡮࡫ࠧୋ")] = XnQbsZF0Ouh8p7zCdUN(xcWMv9b8dpTSq1IZ5eht(cookies))
		BoEFz2WhUyvTgDeiZ = My7Dwqvs6bfGNSIgX.findall(BoWHNb9daQVCF16A(u"ࠨ࡮࡬ࡲࡰ࠴ࡨࡳࡧࡩࠤࡂࠦࠢࠩࡪࡷࡸࡵ࠴ࠪࡀࠫࠥࠫୌ"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if not BoEFz2WhUyvTgDeiZ: return jSu5Cg2Ub1OAkZVs8Yoz(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗ୍ࠬ"),[k5dztomYyN3H(u"ࠪࠫ୎")],[url]
		else:
			BoEFz2WhUyvTgDeiZ = XnQbsZF0Ouh8p7zCdUN(BoEFz2WhUyvTgDeiZ[k5dztomYyN3H(u"࠱ေ")])+PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠫࠫࡪ࠽࠲ࠩ୏")
			TOzKqRwpa6WrVMH8Pxy4X = mORwgTnXBdQ7iCSHKf(IIiPCruL6dT8s1lqj47SzpVHnYNm,NVS30xAdRFMIw1n9CislkE2(u"ࠬࡍࡅࡕࠩ୐"),BoEFz2WhUyvTgDeiZ,V2RbfGOBdcA6l8NTsPWzEyvS7(u"࠭ࠧ୑"),eIL9BxdTbZj,gItVahxL0w(u"ࠧࠨ୒"),C2jP0iLNGKnHu9xp(u"ࠨࠩ୓"),BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡒࡂࡄࡖࡉࡊࡊ࠭࠵ࡶ࡫ࠫ୔"))
			MK6ZT2zjC1SbmveNFqor = TOzKqRwpa6WrVMH8Pxy4X.content
			BoEFz2WhUyvTgDeiZ = My7Dwqvs6bfGNSIgX.findall(UnWjVbo503mEMv9KF(u"ࠪ࡭ࡩࡃࠢࡣࡶࡱࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭୕"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
			if BoEFz2WhUyvTgDeiZ:
				BoEFz2WhUyvTgDeiZ = XnQbsZF0Ouh8p7zCdUN(BoEFz2WhUyvTgDeiZ[LgpdP3UjFRnlX(u"࠲ဲ")])
				if jx7s8T0BFgODXLMzIYedf(u"ࠫࡲࡶ࠴ࠨୖ") in BoEFz2WhUyvTgDeiZ and jSu5Cg2Ub1OAkZVs8Yoz(u"ࠬ࠵ࡤ࠰ࠩୗ") in BoEFz2WhUyvTgDeiZ: return qbPw1d3KimF(u"࠭ࠧ୘"),[RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠧࠨ୙")],[BoEFz2WhUyvTgDeiZ]
				else: return C2dgEDAKQGsvh(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ୚"),[UnWjVbo503mEMv9KF(u"ࠩࠪ୛")],[BoEFz2WhUyvTgDeiZ]
	return FGDJwkEbTB5SoXujs3f(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡇࡒࡂࡄࡖࡉࡊࡊࠧଡ଼"),[],[]
def XOVAKMYPIL(BoEFz2WhUyvTgDeiZ):
	if sRth5giAQzWlEVm7JOX(u"ࠫࡤࡧࡣࡵ࡫ࡲࡲࡂ࡭ࡥࡵࡵࡨࡶࡻ࡫ࡲࠨଢ଼") in BoEFz2WhUyvTgDeiZ:
		headers = {jSu5Cg2Ub1OAkZVs8Yoz(u"ࠬ࡞࠭ࡓࡧࡴࡹࡪࡹࡴࡦࡦ࠰࡛࡮ࡺࡨࠨ୞"):PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"࠭ࡘࡎࡎࡋࡸࡹࡶࡒࡦࡳࡸࡩࡸࡺࠧୟ")}
		xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,b05yftsZ6NYgIKP(u"ࠧࡈࡇࡗࠫୠ"),BoEFz2WhUyvTgDeiZ,C2dgEDAKQGsvh(u"ࠨࠩୡ"),headers,hhlbF1Sns5TrEN8QPCYmL4(u"ࠩࠪୢ"),sRth5giAQzWlEVm7JOX(u"ࠪࠫୣ"),LgpdP3UjFRnlX(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡔࡊࡄࡌࡎࡊ࠴ࡖ࠯࠴ࡷࡹ࠭୤"))
		url = xHb86g9WZqPwRfVjXD2JalzSIp.content
		if url: return RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ୥"),[rbjsM8cRFiuA1(u"࠭ࠧ୦")],[url]
	else:
		tuHzpfZmLAdCObQS2k3 = My7Dwqvs6bfGNSIgX.findall(BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠧࡱࡱࡶࡸ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠬࡳࡦࡴࡹࡩࡷ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠤࠨ୧"),BoEFz2WhUyvTgDeiZ,My7Dwqvs6bfGNSIgX.DOTALL|My7Dwqvs6bfGNSIgX.IGNORECASE)
		if not tuHzpfZmLAdCObQS2k3: tuHzpfZmLAdCObQS2k3 = My7Dwqvs6bfGNSIgX.findall(l0WAe1f7Bpi5ZXk(u"ࠨࡡࡳࡳࡸࡺ࡟ࡪࡦࡀࠬ࠳࠰࠿ࠪࠨࡶࡩࡷࡼࡥࡳ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠧࠫ୨"),BoEFz2WhUyvTgDeiZ,My7Dwqvs6bfGNSIgX.DOTALL|My7Dwqvs6bfGNSIgX.IGNORECASE)
		IIi2NYTdvHzGUQ89EBLOgqr,p8hzHJnjC95karceyWxX = tuHzpfZmLAdCObQS2k3[BmcLzCFjuIrZP5fwXH18aN6YS(u"࠳ဳ")]
		LkVZrOE4XBSN2Qex5PyHqC = ooq2D9xF8ZLpPBs(BoEFz2WhUyvTgDeiZ,NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠩࡸࡶࡱ࠭୩"))
		url = LkVZrOE4XBSN2Qex5PyHqC+gItVahxL0w(u"ࠪ࠳ࡼࡶ࠭ࡤࡱࡱࡸࡪࡴࡴ࠰ࡶ࡫ࡩࡲ࡫ࡳ࠰ࡶ࡫ࡩࡲ࡫࠯ࡂ࡬ࡤࡼࡦࡺ࠯ࡔ࡫ࡱ࡫ࡱ࡫࠯ࡔࡧࡵࡺࡪࡸ࠮ࡱࡪࡳࠫ୪")
		data = {hhlbF1Sns5TrEN8QPCYmL4(u"ࠫ࡮ࡪࠧ୫"):IIi2NYTdvHzGUQ89EBLOgqr,BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠬ࡯ࠧ୬"):p8hzHJnjC95karceyWxX}
		headers = {k5dztomYyN3H(u"࠭ࡘ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡧࡧ࠱࡜࡯ࡴࡩࠩ୭"):C2jP0iLNGKnHu9xp(u"࡙ࠧࡏࡏࡌࡹࡺࡰࡓࡧࡴࡹࡪࡹࡴࠨ୮"),NVS30xAdRFMIw1n9CislkE2(u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ୯"):BoEFz2WhUyvTgDeiZ}
		xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,fY5wTlhtnOc0Er6sdy4k87b(u"ࠩࡓࡓࡘ࡚ࠧ୰"),url,data,headers,v5EA6TqHX3s4jzBMk(u"ࠪࠫୱ"),T6wRistc1SCo4hqObgumK(u"ࠫࠬ୲"),fY5wTlhtnOc0Er6sdy4k87b(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡕࡋࡅࡍࡏࡄ࠵ࡗ࠰࠶ࡳࡪࠧ୳"))
		wN6n7OZBoDkTvCi8LdbJjYV = xHb86g9WZqPwRfVjXD2JalzSIp.content
		bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = My7Dwqvs6bfGNSIgX.findall(YB5xyI7MaRslVpv(u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ୴"),wN6n7OZBoDkTvCi8LdbJjYV,My7Dwqvs6bfGNSIgX.DOTALL|My7Dwqvs6bfGNSIgX.IGNORECASE)
		if bJEs4IVAPdyUrhwCLv9k2YoOl8nt1:
			bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = bJEs4IVAPdyUrhwCLv9k2YoOl8nt1[BoWHNb9daQVCF16A(u"࠴ဴ")]
			return BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ୵"),[WMkAjB1RgN7q(u"ࠨࠩ୶")],[bJEs4IVAPdyUrhwCLv9k2YoOl8nt1]
	return fY5wTlhtnOc0Er6sdy4k87b(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡘࡎࡁࡉࡋࡇ࠸࡚࠭୷"),[],[]
def zzXrnhDNsmHevuPEyc(ooCI3Si0yG):
	ox4vh8rgJt7NsCZGQuIfkR2DKOb = bLEBi8IO7uU2x3htYDdVq95.getSetting(gItVahxL0w(u"ࠪࡥࡻ࠴ࡡ࡬ࡹࡤࡱ࠳ࡼࡥࡳ࡫ࡩ࡭ࡨࡧࡴࡪࡱࡱࠫ୸"))
	headers = {NVS30xAdRFMIw1n9CislkE2(u"ࠫࡈࡵ࡯࡬࡫ࡨࠫ୹"):ox4vh8rgJt7NsCZGQuIfkR2DKOb} if ox4vh8rgJt7NsCZGQuIfkR2DKOb else jx7s8T0BFgODXLMzIYedf(u"ࠬ࠭୺")
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(IIiPCruL6dT8s1lqj47SzpVHnYNm,hhlbF1Sns5TrEN8QPCYmL4(u"࠭ࡇࡆࡖࠪ୻"),ooCI3Si0yG,T6wRistc1SCo4hqObgumK(u"ࠧࠨ୼"),headers,UnWjVbo503mEMv9KF(u"ࠨࠩ୽"),hhlbF1Sns5TrEN8QPCYmL4(u"ࠩࠪ୾"),QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡂ࡚ࡒࡄࡗࡘࡥࡁࡌ࡙ࡄࡑࡤࡉࡁࡑࡖࡆࡌࡆ࠳࠱ࡴࡶࠪ୿"))
	f1NeV0xGma8K2ylqZQ6gcLkOTAXW74 = xHb86g9WZqPwRfVjXD2JalzSIp.content
	xYnN4ar210DsC9 = str(xHb86g9WZqPwRfVjXD2JalzSIp.headers)
	qTAjlPtUmxKn6aZJizCgHG9s0kS = xYnN4ar210DsC9+f1NeV0xGma8K2ylqZQ6gcLkOTAXW74
	if FGDJwkEbTB5SoXujs3f(u"ࠫ࠳ࡳࡰ࠵ࠩ஀") in qTAjlPtUmxKn6aZJizCgHG9s0kS: RnK9tpPmxGhlS0yVAJ71fjsTEIZ = fY5wTlhtnOc0Er6sdy4k87b(u"ࡔࡳࡷࡨᄬ")
	else:
		XhAmJIxOuE3kUyP8pTNnMbKSV,Ujugy9ASbcRxaVeCKJ,cCX7ITtgv6R4iKjyJ,ervZSYCA5l6DEBkdU,RnK9tpPmxGhlS0yVAJ71fjsTEIZ = fY5wTlhtnOc0Er6sdy4k87b(u"ࠬ࠭஁"),PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"࠭ࠧஂ"),BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠧࠨஃ"),rbjsM8cRFiuA1(u"ࠨࠩ஄"),BoWHNb9daQVCF16A(u"ࡇࡣ࡯ࡷࡪᄭ")
		captcha = My7Dwqvs6bfGNSIgX.findall(UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠩࡳࡥ࡬࡫࠭ࡳࡧࡧ࡭ࡷ࡫ࡣࡵ࠰࠭ࡃࡦࡩࡴࡪࡱࡱࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡥࡣࡷࡥ࠲ࡹࡩࡵࡧ࡮ࡩࡾࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧஅ"),f1NeV0xGma8K2ylqZQ6gcLkOTAXW74,My7Dwqvs6bfGNSIgX.DOTALL)
		if captcha: cCX7ITtgv6R4iKjyJ,ervZSYCA5l6DEBkdU = captcha[l0WAe1f7Bpi5ZXk(u"࠵ဵ")]
		PL1CFlczMXYDSep = AK5RqLhji4W1wt9VdrCD3PGeQM[WMkAjB1RgN7q(u"ࠪࡔ࡞࡚ࡈࡐࡐࠪஆ")][UnWjVbo503mEMv9KF(u"࠽ံ")]
		ggfedDsABTMIh = hvc2sXOB31KTLgiZaQUR9xuGjloYS(T6wRistc1SCo4hqObgumK(u"࠳࠳့"))
		if BmcLzCFjuIrZP5fwXH18aN6YS(u"࠱း"):
			data = {QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠫࡺࡹࡥࡳࠩஇ"):ggfedDsABTMIh,YB5xyI7MaRslVpv(u"ࠬࡼࡥࡳࡵ࡬ࡳࡳ࠭ஈ"):RhVj0vAt5kPHm,C2dgEDAKQGsvh(u"࠭ࡵࡳ࡮ࠪஉ"):ooCI3Si0yG,C2jP0iLNGKnHu9xp(u"ࠧ࡬ࡧࡼࠫஊ"):ervZSYCA5l6DEBkdU,BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠨ࡫ࡧࠫ஋"):l0WAe1f7Bpi5ZXk(u"ࠩࠪ஌"),l0WAe1f7Bpi5ZXk(u"ࠪ࡮ࡴࡨࠧ஍"):UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠫ࡬࡫ࡴࡶࡴ࡯ࡷࠬஎ")}
			xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(SToQEHqGtMnAlFbCz4wxBDuOsmW7,WMkAjB1RgN7q(u"ࠬࡖࡏࡔࡖࠪஏ"),PL1CFlczMXYDSep,data,jx7s8T0BFgODXLMzIYedf(u"࠭ࠧஐ"),V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠧࠨ஑"),FGDJwkEbTB5SoXujs3f(u"ࠨࠩஒ"),C2jP0iLNGKnHu9xp(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡈ࡙ࡑࡃࡖࡗࡤࡇࡋࡘࡃࡐࡣࡈࡇࡐࡕࡅࡋࡅ࠲࠸࡮ࡥࠩஓ"))
			MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
		MK6ZT2zjC1SbmveNFqor = k5dztomYyN3H(u"ࠪࠫஔ")
		if MK6ZT2zjC1SbmveNFqor.startswith(EAc8h2sINroQYvR3WH06Ji7MVpn(u"࡚ࠫࡘࡌࡔ࠿ࠪக")):
			U13zMpCrR827fED6q4FKBoaLAs = dWsa2A0O4o5BYiqGXhyKEbM(QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠬࡲࡩࡴࡶࠪ஖"),MK6ZT2zjC1SbmveNFqor.split(qbPw1d3KimF(u"࠭ࡕࡓࡎࡖࡁࠬ஗"),vvHpKfcqRnrFzjG(u"࠳္"))[vvHpKfcqRnrFzjG(u"࠳္")])
			for h5QaxwPF7SOu6fMBTGXRU2yn in U13zMpCrR827fED6q4FKBoaLAs:
				url = h5QaxwPF7SOu6fMBTGXRU2yn[C2dgEDAKQGsvh(u"ࠧࡶࡴ࡯ࠫ஘")]
				IkMc3VWz5SHlDgxn2h94fUtj = h5QaxwPF7SOu6fMBTGXRU2yn[BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠨ࡯ࡨࡸ࡭ࡵࡤࠨங")]
				data = h5QaxwPF7SOu6fMBTGXRU2yn[sRth5giAQzWlEVm7JOX(u"ࠩࡧࡥࡹࡧࠧச")]
				headers = h5QaxwPF7SOu6fMBTGXRU2yn[UnWjVbo503mEMv9KF(u"ࠪ࡬ࡪࡧࡤࡦࡴࡶࠫ஛")]
				xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(SToQEHqGtMnAlFbCz4wxBDuOsmW7,IkMc3VWz5SHlDgxn2h94fUtj,url,data,headers,vvHpKfcqRnrFzjG(u"ࠫࠬஜ"),v5EA6TqHX3s4jzBMk(u"ࠬ࠭஝"),v5EA6TqHX3s4jzBMk(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡅ࡝ࡕࡇࡓࡔࡡࡄࡏ࡜ࡇࡍࡠࡅࡄࡔ࡙ࡉࡈࡂ࠯࠶ࡶࡩ࠭ஞ"))
				f1NeV0xGma8K2ylqZQ6gcLkOTAXW74 = xHb86g9WZqPwRfVjXD2JalzSIp.content
				if jSu5Cg2Ub1OAkZVs8Yoz(u"ࠧ࠯࡯ࡳ࠸ࠬட") in f1NeV0xGma8K2ylqZQ6gcLkOTAXW74:
					RnK9tpPmxGhlS0yVAJ71fjsTEIZ = V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࡖࡵࡹࡪᄮ")
					break
				xYnN4ar210DsC9 = str(xHb86g9WZqPwRfVjXD2JalzSIp.headers)
				qTAjlPtUmxKn6aZJizCgHG9s0kS = xYnN4ar210DsC9+f1NeV0xGma8K2ylqZQ6gcLkOTAXW74
				XhAmJIxOuE3kUyP8pTNnMbKSV = My7Dwqvs6bfGNSIgX.findall(k5dztomYyN3H(u"ࠨࠪࡤ࡯ࡼࡧ࡭ࡗࡧࡵ࡭࡫࡯ࡣࡢࡶ࡬ࡳࡳࡢࡷࠬࠫ࠱࠮ࡄࠨࠨࡦࡻࡍ࠲࠯ࡅࠩࠣࠩ஠"),qTAjlPtUmxKn6aZJizCgHG9s0kS,My7Dwqvs6bfGNSIgX.DOTALL)
				Ujugy9ASbcRxaVeCKJ = My7Dwqvs6bfGNSIgX.findall(UnWjVbo503mEMv9KF(u"ࠩࡵࡩࡨࡧࡰࡵࡥ࡫ࡥ࠲ࡺ࡯࡬ࡧࡱ࠲࠯ࡅࠢࠩ࠲࠶ࡅ࠳࠰࠿ࠪࠤࠪ஡"),qTAjlPtUmxKn6aZJizCgHG9s0kS,My7Dwqvs6bfGNSIgX.DOTALL)
				if Ujugy9ASbcRxaVeCKJ: Ujugy9ASbcRxaVeCKJ = Ujugy9ASbcRxaVeCKJ[rbjsM8cRFiuA1(u"࠳်")]
				if XhAmJIxOuE3kUyP8pTNnMbKSV or Ujugy9ASbcRxaVeCKJ: break
		if not RnK9tpPmxGhlS0yVAJ71fjsTEIZ:
			if not XhAmJIxOuE3kUyP8pTNnMbKSV:
				if captcha and not Ujugy9ASbcRxaVeCKJ:
					if EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠵ျ"): Ujugy9ASbcRxaVeCKJ = f63TBbEDzOhCN7uywKxragnev0(ervZSYCA5l6DEBkdU,YB5xyI7MaRslVpv(u"ࠪࡥࡷ࠭஢"),ooCI3Si0yG)
					else:
						if not MK6ZT2zjC1SbmveNFqor.startswith(UnWjVbo503mEMv9KF(u"ࠫࡎࡊ࠽ࠨண")):
							data = {nr5mZG89ICi6cgt4MfLJa0(u"ࠬࡻࡳࡦࡴࠪத"):ggfedDsABTMIh,jSu5Cg2Ub1OAkZVs8Yoz(u"࠭ࡶࡦࡴࡶ࡭ࡴࡴࠧ஥"):RhVj0vAt5kPHm,vvHpKfcqRnrFzjG(u"ࠧࡶࡴ࡯ࠫ஦"):ooCI3Si0yG,jSu5Cg2Ub1OAkZVs8Yoz(u"ࠨ࡭ࡨࡽࠬ஧"):ervZSYCA5l6DEBkdU,LgpdP3UjFRnlX(u"ࠩ࡬ࡨࠬந"):BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠪࠫன"),k5dztomYyN3H(u"ࠫ࡯ࡵࡢࠨப"):PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠬ࡭ࡥࡵ࡫ࡧࠫ஫")}
							xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(SToQEHqGtMnAlFbCz4wxBDuOsmW7,l0WAe1f7Bpi5ZXk(u"࠭ࡐࡐࡕࡗࠫ஬"),PL1CFlczMXYDSep,data,sRth5giAQzWlEVm7JOX(u"ࠧࠨ஭"),C2jP0iLNGKnHu9xp(u"ࠨࠩம"),l0WAe1f7Bpi5ZXk(u"ࠩࠪய"),nr5mZG89ICi6cgt4MfLJa0(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡂ࡚ࡒࡄࡗࡘࡥࡁࡌ࡙ࡄࡑࡤࡉࡁࡑࡖࡆࡌࡆ࠳࠴ࡵࡪࠪர"))
							MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
						else: MK6ZT2zjC1SbmveNFqor = T6wRistc1SCo4hqObgumK(u"ࠫࡎࡊ࠽࠲࠴࠶࠸࠿ࡀ࠺࠻ࡖࡌࡑࡊࡕࡕࡕ࠿࠷࠹ࠬற")
						if MK6ZT2zjC1SbmveNFqor.startswith(WMkAjB1RgN7q(u"ࠬࡏࡄ࠾ࠩல")):
							PsjxChZSYw5QFpg2zTV = My7Dwqvs6bfGNSIgX.findall(FGDJwkEbTB5SoXujs3f(u"࠭ࡉࡅ࠿ࠫ࠲࠯ࡅࠩ࠻࠼࠽࠾࡙ࡏࡍࡆࡑࡘࡘࡂ࠮࠮ࠫࡁࠬࠨࠬள"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
							fk58nBLrgIi4W9oOpwq,bbeYVRCXkUzsmN39 = PsjxChZSYw5QFpg2zTV[NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠵ြ")]
							mR4VLhryYT2koGU6iBX = UxS67uoGThbMwnfNRzy4gajLd23JH(u"่ࠧา๊ࠤฬู๊ๆๆํอࠥะอหษฯࠤํ่สࠡ็้ࠤ࠶࠶ࠠฦๆ์ࠤࠬழ")+bbeYVRCXkUzsmN39+qbPw1d3KimF(u"ࠨࠢฮห๋๐ษࠨவ")
							hensWGjium8DSy3aVQEOdR95t = YYAhEtvLi5CnyHxIjJled3wWTO()
							hensWGjium8DSy3aVQEOdR95t.create(BmcLzCFjuIrZP5fwXH18aN6YS(u"่ࠩัฬ๎ไสࠢอะฬ๎าࠡใะูࠥษๆศࠢฦุ๊อๆ๊ࠡ็ืฯࠦศา่ส้ัࠦใ้็ห๎ํะัࠨஶ"),mR4VLhryYT2koGU6iBX)
							t6Gp1s0ky8 = KBxPW9cX8dqtaUDG.time()
							uCOm5gk1dMjUh097AfNPV8Eb,eZN7PigEDGxY2zBlWCJVQc6pv3 = fY5wTlhtnOc0Er6sdy4k87b(u"࠶ွ"),fY5wTlhtnOc0Er6sdy4k87b(u"࠶ွ")
							while uCOm5gk1dMjUh097AfNPV8Eb<int(bbeYVRCXkUzsmN39):
								M3QI1bliHdj7poRFV2OG(hensWGjium8DSy3aVQEOdR95t,int(uCOm5gk1dMjUh097AfNPV8Eb/int(bbeYVRCXkUzsmN39)*l0WAe1f7Bpi5ZXk(u"࠱࠱࠲ှ")),mR4VLhryYT2koGU6iBX,b05yftsZ6NYgIKP(u"ࠪࠫஷ"),bbeYVRCXkUzsmN39+RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠫࠥ࠵ࠠࠨஸ")+str(int(uCOm5gk1dMjUh097AfNPV8Eb))+PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠬࠦࠠฬษ้๎ฮ࠭ஹ"))
								if uCOm5gk1dMjUh097AfNPV8Eb>eZN7PigEDGxY2zBlWCJVQc6pv3+jSu5Cg2Ub1OAkZVs8Yoz(u"࠲࠲ဿ"):
									data = {b05yftsZ6NYgIKP(u"࠭ࡵࡴࡧࡵࠫ஺"):ggfedDsABTMIh,LgpdP3UjFRnlX(u"ࠧࡷࡧࡵࡷ࡮ࡵ࡮ࠨ஻"):RhVj0vAt5kPHm,l0WAe1f7Bpi5ZXk(u"ࠨࡷࡵࡰࠬ஼"):ooCI3Si0yG,BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠩ࡮ࡩࡾ࠭஽"):ervZSYCA5l6DEBkdU,YB5xyI7MaRslVpv(u"ࠪ࡭ࡩ࠭ா"):fk58nBLrgIi4W9oOpwq,gItVahxL0w(u"ࠫ࡯ࡵࡢࠨி"):hhlbF1Sns5TrEN8QPCYmL4(u"ࠬ࡭ࡥࡵࡶࡲ࡯ࡪࡴࠧீ")}
									xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(SToQEHqGtMnAlFbCz4wxBDuOsmW7,C2jP0iLNGKnHu9xp(u"࠭ࡐࡐࡕࡗࠫு"),PL1CFlczMXYDSep,data,BoWHNb9daQVCF16A(u"ࠧࠨூ"),FGDJwkEbTB5SoXujs3f(u"ࠨࠩ௃"),nr5mZG89ICi6cgt4MfLJa0(u"ࠩࠪ௄"),C2jP0iLNGKnHu9xp(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡂ࡚ࡒࡄࡗࡘࡥࡁࡌ࡙ࡄࡑࡤࡉࡁࡑࡖࡆࡌࡆ࠳࠵ࡵࡪࠪ௅"))
									MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
									if MK6ZT2zjC1SbmveNFqor.startswith(nr5mZG89ICi6cgt4MfLJa0(u"࡙ࠫࡕࡋࡆࡐࡀࠫெ")):
										Ujugy9ASbcRxaVeCKJ = MK6ZT2zjC1SbmveNFqor.split(hhlbF1Sns5TrEN8QPCYmL4(u"࡚ࠬࡏࡌࡇࡑࡁࠬே"),hhlbF1Sns5TrEN8QPCYmL4(u"࠳၀"))[hhlbF1Sns5TrEN8QPCYmL4(u"࠳၀")]
										break
									eZN7PigEDGxY2zBlWCJVQc6pv3 = uCOm5gk1dMjUh097AfNPV8Eb
								else: KBxPW9cX8dqtaUDG.sleep(FGDJwkEbTB5SoXujs3f(u"࠴၁"))
								uCOm5gk1dMjUh097AfNPV8Eb = KBxPW9cX8dqtaUDG.time()-t6Gp1s0ky8
							hensWGjium8DSy3aVQEOdR95t.close()
				if Ujugy9ASbcRxaVeCKJ:
					hhD5YS7lapOVA0GvR3LN2nXt6g = xHb86g9WZqPwRfVjXD2JalzSIp.cookies
					so9iw0MdTLyl6tXP2KHGIR4VAr = My7Dwqvs6bfGNSIgX.findall(LgpdP3UjFRnlX(u"࠭ࡡ࡬ࡹࡤࡱࡤࡹࡥࡴࡵ࡬ࡳࡳࡃࠨ࠯ࠬࡂ࠭ࡀ࠭ை"),qTAjlPtUmxKn6aZJizCgHG9s0kS,My7Dwqvs6bfGNSIgX.DOTALL)
					if qbPw1d3KimF(u"ࠧࡢ࡭ࡺࡥࡲࡥࡳࡦࡵࡶ࡭ࡴࡴࠧ௉") in list(hhD5YS7lapOVA0GvR3LN2nXt6g.keys()): so9iw0MdTLyl6tXP2KHGIR4VAr = hhD5YS7lapOVA0GvR3LN2nXt6g[LgpdP3UjFRnlX(u"ࠨࡣ࡮ࡻࡦࡳ࡟ࡴࡧࡶࡷ࡮ࡵ࡮ࠨொ")]
					elif so9iw0MdTLyl6tXP2KHGIR4VAr: so9iw0MdTLyl6tXP2KHGIR4VAr = so9iw0MdTLyl6tXP2KHGIR4VAr[QynMHGWA0blfqTUdxRh5Jzi2t(u"࠴၂")]
					captcha = My7Dwqvs6bfGNSIgX.findall(PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠩࡳࡥ࡬࡫࠭ࡳࡧࡧ࡭ࡷ࡫ࡣࡵ࠰࠭ࡃࡦࡩࡴࡪࡱࡱࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡥࡣࡷࡥ࠲ࡹࡩࡵࡧ࡮ࡩࡾࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧோ"),f1NeV0xGma8K2ylqZQ6gcLkOTAXW74,My7Dwqvs6bfGNSIgX.DOTALL)
					if captcha: cCX7ITtgv6R4iKjyJ,ervZSYCA5l6DEBkdU = captcha[NVS30xAdRFMIw1n9CislkE2(u"࠵၃")]
					if so9iw0MdTLyl6tXP2KHGIR4VAr and captcha:
						headers = {WMkAjB1RgN7q(u"ࠪࡇࡴࡵ࡫ࡪࡧࠪௌ"):fY5wTlhtnOc0Er6sdy4k87b(u"ࠫࡦࡱࡷࡢ࡯ࡢࡷࡪࡹࡳࡪࡱࡱࡁ்ࠬ")+so9iw0MdTLyl6tXP2KHGIR4VAr,EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭௎"):ooCI3Si0yG,EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ௏"):QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩ࠭ௐ")}
						data = qbPw1d3KimF(u"ࠨࡩ࠰ࡶࡪࡩࡡࡱࡶࡦ࡬ࡦ࠳ࡲࡦࡵࡳࡳࡳࡹࡥ࠾ࠩ௑")+Ujugy9ASbcRxaVeCKJ
						xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(IIiPCruL6dT8s1lqj47SzpVHnYNm,jx7s8T0BFgODXLMzIYedf(u"ࠩࡓࡓࡘ࡚ࠧ௒"),cCX7ITtgv6R4iKjyJ,data,headers,nr5mZG89ICi6cgt4MfLJa0(u"ࡉࡥࡱࡹࡥᄯ"),V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠪࠫ௓"),qbPw1d3KimF(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡃ࡛ࡓࡅࡘ࡙࡟ࡂࡍ࡚ࡅࡒࡥࡃࡂࡒࡗࡇࡍࡇ࠭࠷ࡶ࡫ࠫ௔"))
						f1NeV0xGma8K2ylqZQ6gcLkOTAXW74 = xHb86g9WZqPwRfVjXD2JalzSIp.content
						try: cookies = xHb86g9WZqPwRfVjXD2JalzSIp.cookies
						except: cookies = {}
						XhAmJIxOuE3kUyP8pTNnMbKSV = My7Dwqvs6bfGNSIgX.findall(V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠧ࠭ࠨࡢ࡭ࡺࡥࡲ࡜ࡥࡳ࡫ࡩ࡭ࡨࡧࡴࡪࡱࡱ࠲࠯ࡅࠩࠨ࠼ࠣࠫ࠭࠴ࠪࡀࠫࠪࠦ௕"),str(cookies),My7Dwqvs6bfGNSIgX.DOTALL)
			if XhAmJIxOuE3kUyP8pTNnMbKSV:
				bSxczpUtHewVDKa3EL4lm,XhAmJIxOuE3kUyP8pTNnMbKSV = XhAmJIxOuE3kUyP8pTNnMbKSV[rbjsM8cRFiuA1(u"࠶၄")]
				ox4vh8rgJt7NsCZGQuIfkR2DKOb = bSxczpUtHewVDKa3EL4lm+C2jP0iLNGKnHu9xp(u"࠭࠽ࠨ௖")+XhAmJIxOuE3kUyP8pTNnMbKSV
				bLEBi8IO7uU2x3htYDdVq95.setSetting(WMkAjB1RgN7q(u"ࠧࡢࡸ࠱ࡥࡰࡽࡡ࡮࠰ࡹࡩࡷ࡯ࡦࡪࡥࡤࡸ࡮ࡵ࡮ࠨௗ"),ox4vh8rgJt7NsCZGQuIfkR2DKOb)
				ZIOHgA3z0TBR(hhlbF1Sns5TrEN8QPCYmL4(u"ࠨࠩ௘"),vvHpKfcqRnrFzjG(u"ࠩࠪ௙"),BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭௚"),NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"๋ࠫาอหࠢ฼้้๐ษࠡใะูࠥษๆศࠢศุ๊อๆࠡ࠰࠱ࠤํ่วๆࠢส่อืๆศ็ฯࠤอิา็้ࠢฮฬฬฬ้ࠡำหࠥอไโฯุࠤ้้๊ࠡ์ึฮำีๅ่ษ่ࠣฬำโศࠢ࠱࠲ࠥ๎ไศࠢอ์ัีࠠฮษฯอ๊ࠥลฺษาอࠥํะศࠢส่ๆำีࠡๆ฼ำฮࠦรี้ิࠤࡡࡴ࡜࡯ࠢ฼่๊อࠠฤ่๋ࠣีอࠠศๆไัฺࠦำ้ใࠣ๎ฯ้ัาࠢไ๎ࠥำวๅหࠣฮ฿๐ัࠡำห฻ࠥอไอ้สึࠥฮวๅว้ฮึ์สࠡ࠰࠱ࠤศ๎ࠠฦูไหฦࠦัศ๊อีࠥอไฦ่อี๋ะࠠ࠯࠰ࠣวํࠦแึๆࠣื้้ࠠศๆิหํะัࠡ࠰࠱ࠤศ๎ࠠศีอาิอๅࠡࡘࡓࡒࠥษ่ࠡสิ์ู่๊ࠨ௛"))
				if T6wRistc1SCo4hqObgumK(u"ࠬ࠴࡭ࡱ࠶ࠪ௜") not in f1NeV0xGma8K2ylqZQ6gcLkOTAXW74:
					headers = {PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"࠭ࡃࡰࡱ࡮࡭ࡪ࠭௝"):ox4vh8rgJt7NsCZGQuIfkR2DKOb}
					xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(IIiPCruL6dT8s1lqj47SzpVHnYNm,QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠧࡈࡇࡗࠫ௞"),ooCI3Si0yG,QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠨࠩ௟"),headers,vvHpKfcqRnrFzjG(u"ࠩࠪ௠"),LgpdP3UjFRnlX(u"ࠪࠫ௡"),vvHpKfcqRnrFzjG(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡃ࡛ࡓࡅࡘ࡙࡟ࡂࡍ࡚ࡅࡒࡥࡃࡂࡒࡗࡇࡍࡇ࠭࠸ࡶ࡫ࠫ௢"))
					f1NeV0xGma8K2ylqZQ6gcLkOTAXW74 = xHb86g9WZqPwRfVjXD2JalzSIp.content
	if not RnK9tpPmxGhlS0yVAJ71fjsTEIZ and not ox4vh8rgJt7NsCZGQuIfkR2DKOb: ZIOHgA3z0TBR(BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠬ࠭௣"),V2RbfGOBdcA6l8NTsPWzEyvS7(u"࠭ࠧ௤"),k5dztomYyN3H(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ௥"),rbjsM8cRFiuA1(u"ࠨใื่ฯูࠦๆๆํอࠥ็อึࠢฦ๊ฬࠦร็ีส๊ࠥ࠴࠮ࠡฯส์้ࠦลฺษาอࠥอไฺ็็๎ฮࠦๅาหࠣวำื้ࠡสสืฯิฯศ็๊ࠣๆูࠠศๆไ๎ิ๐่ࠡล๋ࠤๆ๐ฯ๋๊ࠣ฾๏ื็ࠡ็้ࠤ๋็ำࠡษ็้ํู่ࠨ௦"))
	return f1NeV0xGma8K2ylqZQ6gcLkOTAXW74
def AHyTtY8FEJ(url,type,LLnUyuiC2wRM0):
	Qki8AbTHYjzM2Ls76Gdr3eqo1Wn,breQmB38nWlfEc6CNT = [],[]
	ooCI3Si0yG = url
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(IIiPCruL6dT8s1lqj47SzpVHnYNm,WMkAjB1RgN7q(u"ࠩࡊࡉ࡙࠭௧"),url,BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠪࠫ௨"),C2dgEDAKQGsvh(u"ࠫࠬ௩"),V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠬ࠭௪"),C2dgEDAKQGsvh(u"࠭ࠧ௫"),hhlbF1Sns5TrEN8QPCYmL4(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡐ࡝ࡁࡎ࠯࠴ࡷࡹ࠭௬"))
	wN6n7OZBoDkTvCi8LdbJjYV = xHb86g9WZqPwRfVjXD2JalzSIp.content
	if l0WAe1f7Bpi5ZXk(u"ࠨ࠱ࡺࡥࡹࡩࡨ࠰ࠩ௭") in wN6n7OZBoDkTvCi8LdbJjYV or jSu5Cg2Ub1OAkZVs8Yoz(u"ࠩ࠲ࡨࡴࡽ࡮࡭ࡱࡤࡨ࠴࠭௮") in wN6n7OZBoDkTvCi8LdbJjYV:
		xAcIatGBYy0FLXroS1ig3Ts9KZ8P5 = My7Dwqvs6bfGNSIgX.findall(rbjsM8cRFiuA1(u"ࠪࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠴ࠪࡀ࠾࠲ࡥࡃ࠭௯"),wN6n7OZBoDkTvCi8LdbJjYV,My7Dwqvs6bfGNSIgX.DOTALL)
		if xAcIatGBYy0FLXroS1ig3Ts9KZ8P5:
			for vsptNMP2ZQC in xAcIatGBYy0FLXroS1ig3Ts9KZ8P5:
				NVHrZsqUp2 = My7Dwqvs6bfGNSIgX.findall(NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ௰"),vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
				for BoEFz2WhUyvTgDeiZ,title in NVHrZsqUp2:
					if BoEFz2WhUyvTgDeiZ in Qki8AbTHYjzM2Ls76Gdr3eqo1Wn: continue
					if nr5mZG89ICi6cgt4MfLJa0(u"ࠬ࠵ࡷࡢࡶࡦ࡬࠴࠭௱") not in BoEFz2WhUyvTgDeiZ and k5dztomYyN3H(u"࠭࠯ࡥࡱࡺࡲࡱࡵࡡࡥ࠱ࠪ௲") not in BoEFz2WhUyvTgDeiZ: continue
					title = title.replace(rbjsM8cRFiuA1(u"ࠧ࠽࠱ࡶࡴࡦࡴ࠾ࠨ௳"),T6wRistc1SCo4hqObgumK(u"ࠨࠩ௴")).replace(BoWHNb9daQVCF16A(u"ࠩࠣ࠱ࠥ࠭௵"),FGDJwkEbTB5SoXujs3f(u"ࠪࠫ௶")).strip(l0WAe1f7Bpi5ZXk(u"ࠫࠥ࠭௷")).replace(UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠬࠦࠠࠨ௸"),sRth5giAQzWlEVm7JOX(u"࠭ࠠࠨ௹"))
					Qki8AbTHYjzM2Ls76Gdr3eqo1Wn.append(BoEFz2WhUyvTgDeiZ)
					breQmB38nWlfEc6CNT.append(title)
			GOtNfU3xQFkEhPouwA = UxS67uoGThbMwnfNRzy4gajLd23JH(u"࠰၅")
			if len(Qki8AbTHYjzM2Ls76Gdr3eqo1Wn)>LgpdP3UjFRnlX(u"࠲၆"):
				GOtNfU3xQFkEhPouwA = CnKwdteDG5BE8MTRhUpYIJm3NLrSgq(fY5wTlhtnOc0Er6sdy4k87b(u"ࠧษ฻ู๋ฬ๊ࠦฮฬสะࠥ࠼࠰ࠡอส๊๏ฯࠧ௺"),breQmB38nWlfEc6CNT)
				if GOtNfU3xQFkEhPouwA==-fY5wTlhtnOc0Er6sdy4k87b(u"࠳၇"): return RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡇࡦࡴࡣࡦ࡮ࡨࡨࠥࡇࡋࡘࡃࡐࠫ௻"),[],[]
			if GOtNfU3xQFkEhPouwA>=V2RbfGOBdcA6l8NTsPWzEyvS7(u"࠳၈"): ooCI3Si0yG = Qki8AbTHYjzM2Ls76Gdr3eqo1Wn[GOtNfU3xQFkEhPouwA]
	f1NeV0xGma8K2ylqZQ6gcLkOTAXW74 = zzXrnhDNsmHevuPEyc(ooCI3Si0yG)
	QQ2cE1FjUyxPonbDhaTkV6B3i,wlfZEzuRyYLvrp = [],[]
	if type==NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ௼"):
		PZ7dsmuSzkxq4FCNfW6B = My7Dwqvs6bfGNSIgX.findall(hhlbF1Sns5TrEN8QPCYmL4(u"ࠪࡦࡹࡴ࠭࡭ࡱࡤࡨࡪࡸ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ௽"),f1NeV0xGma8K2ylqZQ6gcLkOTAXW74,My7Dwqvs6bfGNSIgX.DOTALL)
		if PZ7dsmuSzkxq4FCNfW6B:
			BoEFz2WhUyvTgDeiZ = XnQbsZF0Ouh8p7zCdUN(PZ7dsmuSzkxq4FCNfW6B[jSu5Cg2Ub1OAkZVs8Yoz(u"࠴၉")])
			QQ2cE1FjUyxPonbDhaTkV6B3i.append(BoEFz2WhUyvTgDeiZ)
			wlfZEzuRyYLvrp.append(LLnUyuiC2wRM0)
	elif type==jx7s8T0BFgODXLMzIYedf(u"ࠫࡼࡧࡴࡤࡪࠪ௾"):
		NVHrZsqUp2 = My7Dwqvs6bfGNSIgX.findall(C2dgEDAKQGsvh(u"ࠬࡂࡳࡰࡷࡵࡧࡪ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵ࡬ࡾࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ௿"),f1NeV0xGma8K2ylqZQ6gcLkOTAXW74,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,size in NVHrZsqUp2:
			if not BoEFz2WhUyvTgDeiZ: continue
			if LLnUyuiC2wRM0 in size:
				wlfZEzuRyYLvrp.append(size)
				QQ2cE1FjUyxPonbDhaTkV6B3i.append(BoEFz2WhUyvTgDeiZ)
				break
		if not QQ2cE1FjUyxPonbDhaTkV6B3i:
			for BoEFz2WhUyvTgDeiZ,size in NVHrZsqUp2:
				if not BoEFz2WhUyvTgDeiZ: continue
				wlfZEzuRyYLvrp.append(size)
				QQ2cE1FjUyxPonbDhaTkV6B3i.append(BoEFz2WhUyvTgDeiZ)
	if not QQ2cE1FjUyxPonbDhaTkV6B3i: return gItVahxL0w(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡃࡎ࡛ࡆࡓࠧఀ"),[],[]
	return k5dztomYyN3H(u"ࠧࠨఁ"),wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i
def qS2COlbni0(url,bSxczpUtHewVDKa3EL4lm):
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,BoWHNb9daQVCF16A(u"ࠨࡉࡈࡘࠬం"),url,BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠩࠪః"),fY5wTlhtnOc0Er6sdy4k87b(u"ࠪࠫఄ"),C2jP0iLNGKnHu9xp(u"ࡘࡷࡻࡥᄰ"),BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠫࠬఅ"),V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡎࡓࡆࡓ࠭࠲ࡵࡷࠫఆ"))
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	cookies = xHb86g9WZqPwRfVjXD2JalzSIp.cookies
	if NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠭ࡧࡰ࡮࡬ࡲࡰ࠭ఇ") in list(cookies.keys()):
		ox4vh8rgJt7NsCZGQuIfkR2DKOb = cookies[UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠧࡨࡱ࡯࡭ࡳࡱࠧఈ")]
		ox4vh8rgJt7NsCZGQuIfkR2DKOb = XnQbsZF0Ouh8p7zCdUN(tW06wVMpReHfnj3KgzT2va(ox4vh8rgJt7NsCZGQuIfkR2DKOb))
		items = My7Dwqvs6bfGNSIgX.findall(QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠨࡴࡲࡹࡹ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩఉ"),ox4vh8rgJt7NsCZGQuIfkR2DKOb,My7Dwqvs6bfGNSIgX.DOTALL)
		bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = items[sRth5giAQzWlEVm7JOX(u"࠵၊")].replace(QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠩ࡟࠳ࠬఊ"),T6wRistc1SCo4hqObgumK(u"ࠪ࠳ࠬఋ"))
		bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = tW06wVMpReHfnj3KgzT2va(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1)
	else: bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = url
	if nr5mZG89ICi6cgt4MfLJa0(u"ࠫࡨࡧࡴࡤࡪ࠱࡭ࡸ࠭ఌ") in bJEs4IVAPdyUrhwCLv9k2YoOl8nt1:
		id = bJEs4IVAPdyUrhwCLv9k2YoOl8nt1.split(V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠬࠫ࠲ࡇࠩ఍"))[-NVS30xAdRFMIw1n9CislkE2(u"࠷။")]
		bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = fY5wTlhtnOc0Er6sdy4k87b(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡣࡢࡶࡦ࡬࠳࡯ࡳ࠰ࠩఎ")+id
		return qbPw1d3KimF(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪఏ"),[BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠨࠩఐ")],[bJEs4IVAPdyUrhwCLv9k2YoOl8nt1]
	else:
		website = AK5RqLhji4W1wt9VdrCD3PGeQM[fY5wTlhtnOc0Er6sdy4k87b(u"ࠩࡄࡏࡔࡇࡍࠨ఑")][PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"࠰၌")]
		xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠪࡋࡊ࡚ࠧఒ"),website,WMkAjB1RgN7q(u"ࠫࠬఓ"),fY5wTlhtnOc0Er6sdy4k87b(u"ࠬ࠭ఔ"),l0WAe1f7Bpi5ZXk(u"࡙ࡸࡵࡦᄱ"),fY5wTlhtnOc0Er6sdy4k87b(u"࠭ࠧక"),BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡐࡕࡁࡎ࠯࠵ࡲࡩ࠭ఖ"))
		vW50MxLtp148woe6NOF3XBVfPjn = xHb86g9WZqPwRfVjXD2JalzSIp.url
		u0OSKGElNL = bJEs4IVAPdyUrhwCLv9k2YoOl8nt1.split(PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠨ࠱ࠪగ"))[gItVahxL0w(u"࠳၍")]
		mVPfaTwv7WIZ8yNsAEh = vW50MxLtp148woe6NOF3XBVfPjn.split(sRth5giAQzWlEVm7JOX(u"ࠩ࠲ࠫఘ"))[NVS30xAdRFMIw1n9CislkE2(u"࠴၎")]
		QAKdHzO0rehbtyIc = bJEs4IVAPdyUrhwCLv9k2YoOl8nt1.replace(u0OSKGElNL,mVPfaTwv7WIZ8yNsAEh)
		headers = { T6wRistc1SCo4hqObgumK(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧఙ"):BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠫࠬచ") , BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠬ࡞࠭ࡓࡧࡴࡹࡪࡹࡴࡦࡦ࠰࡛࡮ࡺࡨࠨఛ"):BoWHNb9daQVCF16A(u"࠭ࡘࡎࡎࡋࡸࡹࡶࡒࡦࡳࡸࡩࡸࡺࠧజ") , C2dgEDAKQGsvh(u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨఝ"):QAKdHzO0rehbtyIc }
		xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(f9Oum6c0FotxYn,qbPw1d3KimF(u"ࠨࡒࡒࡗ࡙࠭ఞ"), QAKdHzO0rehbtyIc, sRth5giAQzWlEVm7JOX(u"ࠩࠪట"), headers, hhlbF1Sns5TrEN8QPCYmL4(u"ࡌࡡ࡭ࡵࡨᄲ"),V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠪࠫఠ"),gItVahxL0w(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡍࡒࡅࡒ࠳࠳ࡳࡦࠪడ"))
		MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
		items = My7Dwqvs6bfGNSIgX.findall(UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠬࡪࡩࡳࡧࡦࡸࡤࡲࡩ࡯࡭ࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬఢ"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL|My7Dwqvs6bfGNSIgX.IGNORECASE)
		if not items:
			items = My7Dwqvs6bfGNSIgX.findall(hhlbF1Sns5TrEN8QPCYmL4(u"࠭࠼ࡪࡨࡵࡥࡲ࡫࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧణ"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL|My7Dwqvs6bfGNSIgX.IGNORECASE)
			if not items:
				items = My7Dwqvs6bfGNSIgX.findall(BoWHNb9daQVCF16A(u"ࠧ࠽ࡧࡰࡦࡪࡪ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧత"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL|My7Dwqvs6bfGNSIgX.IGNORECASE)
		if items:
			BoEFz2WhUyvTgDeiZ = items[k5dztomYyN3H(u"࠳၏")].replace(V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠨ࡞࠲ࠫథ"),fY5wTlhtnOc0Er6sdy4k87b(u"ࠩ࠲ࠫద"))
			BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ.rstrip(qbPw1d3KimF(u"ࠪ࠳ࠬధ"))
			if QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠫ࡭ࡺࡴࡱࠩన") not in BoEFz2WhUyvTgDeiZ: BoEFz2WhUyvTgDeiZ = LgpdP3UjFRnlX(u"ࠬ࡮ࡴࡵࡲ࠽ࠫ఩") + BoEFz2WhUyvTgDeiZ
			BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ.replace(b05yftsZ6NYgIKP(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࠧప"),jx7s8T0BFgODXLMzIYedf(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࠩఫ"))
			if bSxczpUtHewVDKa3EL4lm==BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠨࠩబ"): ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠩࠪభ"),[BoWHNb9daQVCF16A(u"ࠪࠫమ")],[BoEFz2WhUyvTgDeiZ]
			else: ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧయ"),[YB5xyI7MaRslVpv(u"ࠬ࠭ర")],[BoEFz2WhUyvTgDeiZ]
		else: ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡃࡎࡓࡆࡓࠧఱ"),[],[]
		return ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i
def Y8FiDNf2u0gHPT1woEl4(url):
	headers = { WMkAjB1RgN7q(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫల") : vvHpKfcqRnrFzjG(u"ࠨࠩళ") }
	MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(f9Oum6c0FotxYn,url,UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠩࠪఴ"),headers,sRth5giAQzWlEVm7JOX(u"ࠪࠫవ"),YB5xyI7MaRslVpv(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡓࡃࡓࡍࡉ࡜ࡉࡅࡇࡒ࠱࠶ࡹࡴࠨశ"))
	items = My7Dwqvs6bfGNSIgX.findall(b05yftsZ6NYgIKP(u"ࠬࡂࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࡬ࡢࡤࡨࡰࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ష"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i,errno = [],[],LgpdP3UjFRnlX(u"࠭ࠧస")
	if items:
		for BoEFz2WhUyvTgDeiZ,GDL3q5vFjwIVrM2ElRZNd in items:
			wlfZEzuRyYLvrp.append(GDL3q5vFjwIVrM2ElRZNd)
			QQ2cE1FjUyxPonbDhaTkV6B3i.append(BoEFz2WhUyvTgDeiZ)
	if len(QQ2cE1FjUyxPonbDhaTkV6B3i)==C2jP0iLNGKnHu9xp(u"࠴ၐ"): return nr5mZG89ICi6cgt4MfLJa0(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡕࡅࡕࡏࡄࡗࡋࡇࡉࡔ࠭హ"),[],[]
	return NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠨࠩ఺"),wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i
def sCaYWEmAuBHDkfd(url):
	headers = {QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭఻"):k5dztomYyN3H(u"఼ࠪࠫ")}
	MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(f9Oum6c0FotxYn,url,qbPw1d3KimF(u"ࠫࠬఽ"),headers,qbPw1d3KimF(u"ࠬ࠭ా"),V2RbfGOBdcA6l8NTsPWzEyvS7(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡘࡕࡑࡕࡁࡅ࠯࠴ࡷࡹ࠭ి"))
	items = My7Dwqvs6bfGNSIgX.findall(rbjsM8cRFiuA1(u"ࠧࡴࡱࡸࡶࡨ࡫ࡳ࠻ࠢ࡟࡟ࠧ࠮࠮ࠫࡁࠬࠦࠬీ"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if items:
		url = items[C2jP0iLNGKnHu9xp(u"࠵ၑ")]+T6wRistc1SCo4hqObgumK(u"ࠨࡾࡕࡩ࡫࡫ࡲࡦࡴࡀࠫు")+url
		return RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠩࠪూ"),[gItVahxL0w(u"ࠪࠫృ")],[url]
	else: return V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡕࡒࡎࡒࡅࡉ࠭ౄ"),[],[]
def z7YClWhdno2faTu4Hect5E(url):
	url = url.strip(hhlbF1Sns5TrEN8QPCYmL4(u"ࠬ࠵ࠧ౅"))
	if fY5wTlhtnOc0Er6sdy4k87b(u"࠭࠯ࡦ࡯ࡥࡩࡩ࠵ࠧె") in url: id = url.split(QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠧ࠰ࠩే"))[UnWjVbo503mEMv9KF(u"࠺ၒ")]
	else: id = url.split(b05yftsZ6NYgIKP(u"ࠨ࠱ࠪై"))[-b05yftsZ6NYgIKP(u"࠱ၓ")]
	url = LgpdP3UjFRnlX(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡺࡨࡹࡴࡳࡧࡤࡱ࠳ࡺ࡯࠰ࡲ࡯ࡥࡾ࡫ࡲࡀࡨ࡬ࡨࡂ࠭౉") + id
	headers = { FGDJwkEbTB5SoXujs3f(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧొ") : l0WAe1f7Bpi5ZXk(u"ࠫࠬో") }
	MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(f9Oum6c0FotxYn,url,fY5wTlhtnOc0Er6sdy4k87b(u"ࠬ࠭ౌ"),headers,vvHpKfcqRnrFzjG(u"్࠭ࠧ"),vvHpKfcqRnrFzjG(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡚ࡈ࡙ࡔࡓࡇࡄࡑ࠲࠷ࡳࡵࠩ౎"))
	MK6ZT2zjC1SbmveNFqor = MK6ZT2zjC1SbmveNFqor.replace(qbPw1d3KimF(u"ࠨ࡞࡟ࠫ౏"),l0WAe1f7Bpi5ZXk(u"ࠩࠪ౐"))
	items = My7Dwqvs6bfGNSIgX.findall(EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠪࡪ࡮ࡲࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ౑"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if items: return jx7s8T0BFgODXLMzIYedf(u"ࠫࠬ౒"),[v5EA6TqHX3s4jzBMk(u"ࠬ࠭౓")],[ items[WMkAjB1RgN7q(u"࠱ၔ")] ]
	else: return C2dgEDAKQGsvh(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡘࡆࡗ࡙ࡘࡅࡂࡏࠪ౔"),[],[]
def I6ipEyfUNLPj94RZkGtMsHaJKdbcz(url):
	MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(f9Oum6c0FotxYn,url,FGDJwkEbTB5SoXujs3f(u"ࠧࠨౕ"),PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠨౖࠩ"),BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠩࠪ౗"),b05yftsZ6NYgIKP(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡖࡊࡆࡒ࡞ࡆ࠳࠱ࡴࡶࠪౘ"))
	items = My7Dwqvs6bfGNSIgX.findall(LgpdP3UjFRnlX(u"ࠫࡸࡸࡣ࠻ࠢࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡲࡡࡣࡧ࡯࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠱ࠦࡲࡦࡵ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫౙ"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = [],[]
	for BoEFz2WhUyvTgDeiZ,GDL3q5vFjwIVrM2ElRZNd,khvs4LDVNyeBj7 in items:
		wlfZEzuRyYLvrp.append(GDL3q5vFjwIVrM2ElRZNd+rbjsM8cRFiuA1(u"ࠬࠦࠧౚ")+khvs4LDVNyeBj7)
		QQ2cE1FjUyxPonbDhaTkV6B3i.append(BoEFz2WhUyvTgDeiZ)
	if len(QQ2cE1FjUyxPonbDhaTkV6B3i)==jSu5Cg2Ub1OAkZVs8Yoz(u"࠲ၕ"): return YB5xyI7MaRslVpv(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡘࡌࡈࡔࡠࡁࠨ౛"),[],[]
	return qbPw1d3KimF(u"ࠧࠨ౜"),wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i
def qo9mk1TbKEZHdtR8PYehD4iBrz7(url):
	MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(f9Oum6c0FotxYn,url,PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠨࠩౝ"),YB5xyI7MaRslVpv(u"ࠩࠪ౞"),BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠪࠫ౟"),jx7s8T0BFgODXLMzIYedf(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡘࡃࡗࡇࡍ࡜ࡉࡅࡇࡒ࠱࠶ࡹࡴࠨౠ"))
	items = My7Dwqvs6bfGNSIgX.findall(FGDJwkEbTB5SoXujs3f(u"ࠧࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡟ࡷ࡫ࡧࡩࡴࡢࠨࠨࠪ࠱࠮ࡄ࠯ࠧ࠭ࠩࠫ࠲࠯ࡅࠩࠨ࠮ࠪࠬ࠳࠰࠿ࠪࠩ࡟࠭ࡡࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀ࠱࠮ࡄࡂࡴࡥࡀࠫ࠲࠯ࡅࠩ࠭࠰࠭ࡃࡁ࠵ࡴࡥࡀࠥౡ"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	items = set(items)
	wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = [],[]
	for id,H3HDqY5N4e0fWSXMikZ8CR7suUmJdx,hash,GDL3q5vFjwIVrM2ElRZNd,khvs4LDVNyeBj7 in items:
		url = V2RbfGOBdcA6l8NTsPWzEyvS7(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡣࡷࡧ࡭ࡼࡩࡥࡧࡲ࠲ࡺࡹ࠯ࡥ࡮ࡂࡳࡵࡃࡤࡰࡹࡱࡰࡴࡧࡤࡠࡱࡵ࡭࡬ࠬࡩࡥ࠿ࠪౢ")+id+v5EA6TqHX3s4jzBMk(u"ࠧࠧ࡯ࡲࡨࡪࡃࠧౣ")+H3HDqY5N4e0fWSXMikZ8CR7suUmJdx+BoWHNb9daQVCF16A(u"ࠨࠨ࡫ࡥࡸ࡮࠽ࠨ౤")+hash
		MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(f9Oum6c0FotxYn,url,LgpdP3UjFRnlX(u"ࠩࠪ౥"),fY5wTlhtnOc0Er6sdy4k87b(u"ࠪࠫ౦"),gItVahxL0w(u"ࠫࠬ౧"),fY5wTlhtnOc0Er6sdy4k87b(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡙ࡄࡘࡈࡎࡖࡊࡆࡈࡓ࠲࠸࡮ࡥࠩ౨"))
		items = My7Dwqvs6bfGNSIgX.findall(UxS67uoGThbMwnfNRzy4gajLd23JH(u"࠭ࡤࡪࡴࡨࡧࡹࠦ࡬ࡪࡰ࡮࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ౩"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ in items:
			wlfZEzuRyYLvrp.append(GDL3q5vFjwIVrM2ElRZNd+PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠧࠡࠩ౪")+khvs4LDVNyeBj7)
			QQ2cE1FjUyxPonbDhaTkV6B3i.append(BoEFz2WhUyvTgDeiZ)
	if len(QQ2cE1FjUyxPonbDhaTkV6B3i)==WMkAjB1RgN7q(u"࠳ၖ"): return BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦ࡛ࠣࡆ࡚ࡃࡉࡘࡌࡈࡊࡕࠧ౫"),[],[]
	return YB5xyI7MaRslVpv(u"ࠩࠪ౬"),wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i
def jhJDUlesnFXRg(url):
	BoEFz2WhUyvTgDeiZ = PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠪࠫ౭")
	if fY5wTlhtnOc0Er6sdy4k87b(u"࠵ၗ") or k5dztomYyN3H(u"ࠫࡐ࡫ࡹ࠾ࠩ౮") not in url:
		bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = url.replace(vvHpKfcqRnrFzjG(u"ࠬࡻࡰࡣࡱࡰ࠲ࡱ࡯ࡶࡦࠩ౯"),RqldvxFuM5GEQ2HAz93o7afBb0(u"࠭ࡵࡱࡲࡲࡱ࠳ࡲࡩࡷࡧࠪ౰"))
		bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = bJEs4IVAPdyUrhwCLv9k2YoOl8nt1.split(UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠧ࠰ࠩ౱"))
		id = bJEs4IVAPdyUrhwCLv9k2YoOl8nt1[RqldvxFuM5GEQ2HAz93o7afBb0(u"࠸ၘ")]
		bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = gItVahxL0w(u"ࠨ࠱ࠪ౲").join(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1[C2jP0iLNGKnHu9xp(u"࠶ၙ"):C2jP0iLNGKnHu9xp(u"࠴ၚ")])
		tWha1P9LVeuNxpQUAB = {WMkAjB1RgN7q(u"ࠩ࡬ࡨࠬ౳"):id,BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠪࡳࡵ࠭౴"):C2jP0iLNGKnHu9xp(u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࠸ࠧ౵"),V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠬࡳࡥࡵࡪࡲࡨࡤ࡬ࡲࡦࡧࠪ౶"):C2jP0iLNGKnHu9xp(u"࠭ࡆࡳࡧࡨ࠯ࡉࡵࡷ࡯࡮ࡲࡥࡩ࠱ࠥ࠴ࡇࠨ࠷ࡊ࠭౷")}
		xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(f9Oum6c0FotxYn,UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠧࡑࡑࡖࡘࠬ౸"),bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,tWha1P9LVeuNxpQUAB,FGDJwkEbTB5SoXujs3f(u"ࠨࠩ౹"),QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠩࠪ౺"),rbjsM8cRFiuA1(u"ࠪࠫ౻"),BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡖࡒࡅࡓࡒ࠳࠱ࡴࡶࠪ౼"))
		if sRth5giAQzWlEVm7JOX(u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ౽") in list(xHb86g9WZqPwRfVjXD2JalzSIp.headers.keys()): BoEFz2WhUyvTgDeiZ = xHb86g9WZqPwRfVjXD2JalzSIp.headers[QynMHGWA0blfqTUdxRh5Jzi2t(u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ౾")]
		if not BoEFz2WhUyvTgDeiZ and xHb86g9WZqPwRfVjXD2JalzSIp.succeeded:
			MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
			BoEFz2WhUyvTgDeiZ = My7Dwqvs6bfGNSIgX.findall(FGDJwkEbTB5SoXujs3f(u"ࠧࡪࡦࡀࠦࡩ࡯ࡲࡦࡥࡷࡣࡱ࡯࡮࡬ࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ౿"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
			if BoEFz2WhUyvTgDeiZ: BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ[BmcLzCFjuIrZP5fwXH18aN6YS(u"࠱ၛ")]
	else:
		xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(f9Oum6c0FotxYn,l0WAe1f7Bpi5ZXk(u"ࠨࡉࡈࡘࠬಀ"),url,nr5mZG89ICi6cgt4MfLJa0(u"ࠩࠪಁ"),LgpdP3UjFRnlX(u"ࠪࠫಂ"),FGDJwkEbTB5SoXujs3f(u"ࠫࠬಃ"),BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠬ࠭಄"),EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡘࡔࡇࡕࡍ࠮࠴ࡱࡨࠬಅ"))
		if C2dgEDAKQGsvh(u"ࠧ࡭ࡱࡦࡥࡹ࡯࡯࡯ࠩಆ") in list(xHb86g9WZqPwRfVjXD2JalzSIp.headers.keys()): BoEFz2WhUyvTgDeiZ = xHb86g9WZqPwRfVjXD2JalzSIp.headers[C2dgEDAKQGsvh(u"ࠨ࡮ࡲࡧࡦࡺࡩࡰࡰࠪಇ")]
	if BoEFz2WhUyvTgDeiZ: return hhlbF1Sns5TrEN8QPCYmL4(u"ࠩࠪಈ"),[sRth5giAQzWlEVm7JOX(u"ࠪࠫಉ")],[BoEFz2WhUyvTgDeiZ]
	return vvHpKfcqRnrFzjG(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡕࡑࡄࡒࡑࠬಊ"),[],[]
def Wd7ostUkhD1OVGKq(url):
	headers = { rbjsM8cRFiuA1(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩಋ") : l0WAe1f7Bpi5ZXk(u"࠭ࠧಌ") }
	MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(f9Oum6c0FotxYn,url,LgpdP3UjFRnlX(u"ࠧࠨ಍"),headers,UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠨࠩಎ"),C2dgEDAKQGsvh(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡒࡉࡊࡘࡌࡈࡊࡕ࠭࠲ࡵࡷࠫಏ"))
	items = My7Dwqvs6bfGNSIgX.findall(NVS30xAdRFMIw1n9CislkE2(u"ࠪࡷࡴࡻࡲࡤࡧࡶ࠾࠳࠰࠿ࠣࠪ࠱࠮ࡄ࠯ࠢ࠭ࠤࠫ࠲࠯ࡅࠩࠣࠩಐ"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = [],[]
	if items:
		wlfZEzuRyYLvrp.append(k5dztomYyN3H(u"ࠫࡲࡶ࠴ࠨ಑"))
		QQ2cE1FjUyxPonbDhaTkV6B3i.append(items[UxS67uoGThbMwnfNRzy4gajLd23JH(u"࠳ၝ")][FGDJwkEbTB5SoXujs3f(u"࠳ၜ")])
		wlfZEzuRyYLvrp.append(EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠬࡳ࠳ࡶ࠺ࠪಒ"))
		QQ2cE1FjUyxPonbDhaTkV6B3i.append(items[NVS30xAdRFMIw1n9CislkE2(u"࠴ၞ")][NVS30xAdRFMIw1n9CislkE2(u"࠴ၞ")])
		return C2jP0iLNGKnHu9xp(u"࠭ࠧಓ"),wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i
	else: return YB5xyI7MaRslVpv(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡏࡍࡎ࡜ࡉࡅࡇࡒࠫಔ"),[],[]
def yy16g9xBYs(url):
	id = url.split(qbPw1d3KimF(u"ࠨ࠱ࠪಕ"))[-hhlbF1Sns5TrEN8QPCYmL4(u"࠶ၟ")]
	id = id.split(b05yftsZ6NYgIKP(u"ࠩࠩࠫಖ"))[UxS67uoGThbMwnfNRzy4gajLd23JH(u"࠶ၠ")]
	id = id.replace(hhlbF1Sns5TrEN8QPCYmL4(u"ࠪࡻࡦࡺࡣࡩࡁࡹࡁࠬಗ"),QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠫࠬಘ"))
	bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = AK5RqLhji4W1wt9VdrCD3PGeQM[UnWjVbo503mEMv9KF(u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭ಙ")][BoWHNb9daQVCF16A(u"࠰ၡ")]+NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠭࠯ࡸࡣࡷࡧ࡭ࡅࡶ࠾ࠩಚ")+id
	fcJYEedPmyt56xBIkMiSFqCh7vw2UK = RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡺࡱࡸࡸࡺ࠴ࡢࡦ࠱ࠪಛ")+id
	f6zJ3voP0lsySUguQOM8HNpA,ooACyWsxIHP8wkfb3,qFD6GyYO4nM,b8aHKFJ9V5XWI2YwSi6uemxBrqM = QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠨࠩಜ"),v5EA6TqHX3s4jzBMk(u"ࠩࠪಝ"),NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠪࠫಞ"),jSu5Cg2Ub1OAkZVs8Yoz(u"ࠫࠬಟ")
	for k3Om08MCgqQao4n1 in range(BmcLzCFjuIrZP5fwXH18aN6YS(u"࠶ၢ")):
		xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(SToQEHqGtMnAlFbCz4wxBDuOsmW7,WMkAjB1RgN7q(u"ࠬࡍࡅࡕࠩಠ"),bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,nr5mZG89ICi6cgt4MfLJa0(u"࠭ࠧಡ"),vvHpKfcqRnrFzjG(u"ࠧࠨಢ"),fY5wTlhtnOc0Er6sdy4k87b(u"ࠨࠩಣ"),k5dztomYyN3H(u"ࠩࠪತ"),nr5mZG89ICi6cgt4MfLJa0(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳࡙ࡐࡗࡗ࡙ࡇࡋ࠭࠲ࡵࡷࠫಥ"))
		MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
		if UnWjVbo503mEMv9KF(u"ࠫ࡮ࡺࡡࡨࠩದ") in MK6ZT2zjC1SbmveNFqor: break
		KBxPW9cX8dqtaUDG.sleep(BoWHNb9daQVCF16A(u"࠴ၣ"))
	sdKauTCwnh = My7Dwqvs6bfGNSIgX.findall(qbPw1d3KimF(u"ࠬࡼࡡࡳࠢࡼࡸࡎࡴࡩࡵ࡫ࡤࡰࡕࡲࡡࡺࡧࡵࡖࡪࡹࡰࡰࡰࡶࡩࠥࡃࠠࠩ࠰࠭ࡃ࠮ࡁ࠼࠰ࡵࡦࡶ࡮ࡶࡴ࠿ࠩಧ"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if sdKauTCwnh: sdKauTCwnh = sdKauTCwnh[k5dztomYyN3H(u"࠳ၤ")]
	else: sdKauTCwnh = MK6ZT2zjC1SbmveNFqor
	sdKauTCwnh = sdKauTCwnh.replace(C2dgEDAKQGsvh(u"࠭࡜࡝ࡷ࠳࠴࠷࠼ࠧನ"),EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠧࠧࠩ಩"))
	hJewSpndQCsY4bA = dWsa2A0O4o5BYiqGXhyKEbM(C2jP0iLNGKnHu9xp(u"ࠨࡦ࡬ࡧࡹ࠭ಪ"),sdKauTCwnh)
	wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = [jSu5Cg2Ub1OAkZVs8Yoz(u"ࠩหำํ์ࠠหำฯ้ฮ๊้ࠦฬํ์อ࠭ಫ")],[PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠪࠫಬ")]
	try:
		SZ279TnVPiXY = hJewSpndQCsY4bA[v5EA6TqHX3s4jzBMk(u"ࠫࡨࡧࡰࡵ࡫ࡲࡲࡸ࠭ಭ")][hhlbF1Sns5TrEN8QPCYmL4(u"ࠬࡶ࡬ࡢࡻࡨࡶࡈࡧࡰࡵ࡫ࡲࡲࡸ࡚ࡲࡢࡥ࡮ࡰ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩಮ")][gItVahxL0w(u"࠭ࡣࡢࡲࡷ࡭ࡴࡴࡔࡳࡣࡦ࡯ࡸ࠭ಯ")]
		for bEx7sYPSC01Jh3LayHI9Gci in SZ279TnVPiXY:
			BoEFz2WhUyvTgDeiZ = bEx7sYPSC01Jh3LayHI9Gci[k5dztomYyN3H(u"ࠧࡣࡣࡶࡩ࡚ࡸ࡬ࠨರ")]
			try: title = bEx7sYPSC01Jh3LayHI9Gci[BoWHNb9daQVCF16A(u"ࠨࡰࡤࡱࡪ࠭ಱ")][FGDJwkEbTB5SoXujs3f(u"ࠩࡶ࡭ࡲࡶ࡬ࡦࡖࡨࡼࡹ࠭ಲ")]
			except: title = bEx7sYPSC01Jh3LayHI9Gci[PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠪࡲࡦࡳࡥࠨಳ")][jSu5Cg2Ub1OAkZVs8Yoz(u"ࠫࡷࡻ࡮ࡴࠩ಴")][qbPw1d3KimF(u"࠴ၥ")][T6wRistc1SCo4hqObgumK(u"ࠬࡺࡥࡹࡶࡷࠫವ")]
			QQ2cE1FjUyxPonbDhaTkV6B3i.append(BoEFz2WhUyvTgDeiZ)
			wlfZEzuRyYLvrp.append(title)
	except: pass
	if len(wlfZEzuRyYLvrp)>BoWHNb9daQVCF16A(u"࠶ၦ"):
		GOtNfU3xQFkEhPouwA = CnKwdteDG5BE8MTRhUpYIJm3NLrSgq(l0WAe1f7Bpi5ZXk(u"࠭วฯฬิࠤฬ๊สาฮ่อࠥอไๆ่สือฯ࠺ࠨಶ"), wlfZEzuRyYLvrp)
		if GOtNfU3xQFkEhPouwA==-v5EA6TqHX3s4jzBMk(u"࠷ၧ"): return BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠧࡆ࡚ࡌࡘࡤࡇࡌࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬಷ"),[],[]
		elif GOtNfU3xQFkEhPouwA!=BoWHNb9daQVCF16A(u"࠰ၨ"):
			BoEFz2WhUyvTgDeiZ = QQ2cE1FjUyxPonbDhaTkV6B3i[GOtNfU3xQFkEhPouwA]+UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠨࠨࠪಸ")
			sPCWuwQ8zU15cRopBIaY = My7Dwqvs6bfGNSIgX.findall(rbjsM8cRFiuA1(u"ࠩࠩࠬ࡫ࡳࡴ࠾࠰࠭ࡃ࠮ࠬࠧಹ"),BoEFz2WhUyvTgDeiZ)
			if sPCWuwQ8zU15cRopBIaY: BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ.replace(sPCWuwQ8zU15cRopBIaY[fY5wTlhtnOc0Er6sdy4k87b(u"࠱ၩ")],UnWjVbo503mEMv9KF(u"ࠪࡪࡲࡺ࠽ࡷࡶࡷࠫ಺"))
			else: BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ+LgpdP3UjFRnlX(u"ࠫ࡫ࡳࡴ࠾ࡸࡷࡸࠬ಻")
			f6zJ3voP0lsySUguQOM8HNpA = BoEFz2WhUyvTgDeiZ.strip(v5EA6TqHX3s4jzBMk(u"಼ࠬࠬࠧ"))
	e2RqOQp3DzcTdm60B,kpHqBaPfy2LFs893rU,Gvre3YWRVjBmuH7K5lhN1XiFDEI,NWs2Rn7YFe0rOtw5f8zv49gkP,YLDAF5QTS2u4Isd0cBXrqM = [],[],[],[],[]
	try: ooACyWsxIHP8wkfb3 = hJewSpndQCsY4bA[C2dgEDAKQGsvh(u"࠭ࡳࡵࡴࡨࡥࡲ࡯࡮ࡨࡆࡤࡸࡦ࠭ಽ")][UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠧࡥࡣࡶ࡬ࡒࡧ࡮ࡪࡨࡨࡷࡹ࡛ࡲ࡭ࠩಾ")]
	except: pass
	try: qFD6GyYO4nM = hJewSpndQCsY4bA[C2dgEDAKQGsvh(u"ࠨࡵࡷࡶࡪࡧ࡭ࡪࡰࡪࡈࡦࡺࡡࠨಿ")][rbjsM8cRFiuA1(u"ࠩ࡫ࡰࡸࡓࡡ࡯࡫ࡩࡩࡸࡺࡕࡳ࡮ࠪೀ")]
	except: pass
	try: e2RqOQp3DzcTdm60B = hJewSpndQCsY4bA[gItVahxL0w(u"ࠪࡷࡹࡸࡥࡢ࡯࡬ࡲ࡬ࡊࡡࡵࡣࠪು")][BoWHNb9daQVCF16A(u"ࠫ࡫ࡵࡲ࡮ࡣࡷࡷࠬೂ")]
	except: pass
	try: kpHqBaPfy2LFs893rU = hJewSpndQCsY4bA[WMkAjB1RgN7q(u"ࠬࡹࡴࡳࡧࡤࡱ࡮ࡴࡧࡅࡣࡷࡥࠬೃ")][T6wRistc1SCo4hqObgumK(u"࠭ࡡࡥࡣࡳࡸ࡮ࡼࡥࡇࡱࡵࡱࡦࡺࡳࠨೄ")]
	except: pass
	m6piLTEJ14nbwurWYyHjR8F5I = e2RqOQp3DzcTdm60B+kpHqBaPfy2LFs893rU
	for dict in m6piLTEJ14nbwurWYyHjR8F5I:
		if BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠧࡪࡶࡤ࡫ࠬ೅") in list(dict.keys()): dict[BoWHNb9daQVCF16A(u"ࠨ࡫ࡷࡥ࡬࠭ೆ")] = str(dict[C2dgEDAKQGsvh(u"ࠩ࡬ࡸࡦ࡭ࠧೇ")])
		if UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠪࡪࡵࡹࠧೈ") in list(dict.keys()): dict[hhlbF1Sns5TrEN8QPCYmL4(u"ࠫ࡫ࡶࡳࠨ೉")] = str(dict[qbPw1d3KimF(u"ࠬ࡬ࡰࡴࠩೊ")])
		if BmcLzCFjuIrZP5fwXH18aN6YS(u"࠭࡭ࡪ࡯ࡨࡘࡾࡶࡥࠨೋ") in list(dict.keys()): dict[fY5wTlhtnOc0Er6sdy4k87b(u"ࠧࡵࡻࡳࡩࠬೌ")] = dict[BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠨ࡯࡬ࡱࡪ࡚ࡹࡱࡧ್ࠪ")]
		if BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠩࡤࡹࡩ࡯࡯ࡔࡣࡰࡴࡱ࡫ࡒࡢࡶࡨࠫ೎") in list(dict.keys()): dict[LgpdP3UjFRnlX(u"ࠪࡥࡺࡪࡩࡰࡡࡶࡥࡲࡶ࡬ࡦࡡࡵࡥࡹ࡫ࠧ೏")] = str(dict[BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠫࡦࡻࡤࡪࡱࡖࡥࡲࡶ࡬ࡦࡔࡤࡸࡪ࠭೐")])
		if V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠬࡧࡵࡥ࡫ࡲࡇ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬ೑") in list(dict.keys()): dict[YB5xyI7MaRslVpv(u"࠭ࡡࡶࡦ࡬ࡳࡤࡩࡨࡢࡰࡱࡩࡱࡹࠧ೒")] = str(dict[jx7s8T0BFgODXLMzIYedf(u"ࠧࡢࡷࡧ࡭ࡴࡉࡨࡢࡰࡱࡩࡱࡹࠧ೓")])
		if BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠨࡹ࡬ࡨࡹ࡮ࠧ೔") in list(dict.keys()): dict[LgpdP3UjFRnlX(u"ࠩࡶ࡭ࡿ࡫ࠧೕ")] = str(dict[WMkAjB1RgN7q(u"ࠪࡻ࡮ࡪࡴࡩࠩೖ")])+vvHpKfcqRnrFzjG(u"ࠫࡽ࠭೗")+str(dict[sRth5giAQzWlEVm7JOX(u"ࠬ࡮ࡥࡪࡩ࡫ࡸࠬ೘")])
		if T6wRistc1SCo4hqObgumK(u"࠭ࡩ࡯࡫ࡷࡖࡦࡴࡧࡦࠩ೙") in list(dict.keys()): dict[RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠧࡪࡰ࡬ࡸࠬ೚")] = dict[gItVahxL0w(u"ࠨ࡫ࡱ࡭ࡹࡘࡡ࡯ࡩࡨࠫ೛")][rbjsM8cRFiuA1(u"ࠩࡶࡸࡦࡸࡴࠨ೜")]+NVS30xAdRFMIw1n9CislkE2(u"ࠪ࠱ࠬೝ")+dict[nr5mZG89ICi6cgt4MfLJa0(u"ࠫ࡮ࡴࡩࡵࡔࡤࡲ࡬࡫ࠧೞ")][b05yftsZ6NYgIKP(u"ࠬ࡫࡮ࡥࠩ೟")]
		if V2RbfGOBdcA6l8NTsPWzEyvS7(u"࠭ࡩ࡯ࡦࡨࡼࡗࡧ࡮ࡨࡧࠪೠ") in list(dict.keys()): dict[b05yftsZ6NYgIKP(u"ࠧࡪࡰࡧࡩࡽ࠭ೡ")] = dict[V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠨ࡫ࡱࡨࡪࡾࡒࡢࡰࡪࡩࠬೢ")][UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠩࡶࡸࡦࡸࡴࠨೣ")]+FGDJwkEbTB5SoXujs3f(u"ࠪ࠱ࠬ೤")+dict[LgpdP3UjFRnlX(u"ࠫ࡮ࡴࡤࡦࡺࡕࡥࡳ࡭ࡥࠨ೥")][NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠬ࡫࡮ࡥࠩ೦")]
		if b05yftsZ6NYgIKP(u"࠭ࡡࡷࡧࡵࡥ࡬࡫ࡂࡪࡶࡵࡥࡹ࡫ࠧ೧") in list(dict.keys()): dict[LgpdP3UjFRnlX(u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ೨")] = dict[LgpdP3UjFRnlX(u"ࠨࡣࡹࡩࡷࡧࡧࡦࡄ࡬ࡸࡷࡧࡴࡦࠩ೩")]
		if PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ೪") in list(dict.keys()) and int(dict[l0WAe1f7Bpi5ZXk(u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ೫")])>b05yftsZ6NYgIKP(u"࠳࠴࠵࠷࠸࠲࠴࠵࠶ၪ"): del dict[WMkAjB1RgN7q(u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ೬")]
		if LgpdP3UjFRnlX(u"ࠬࡹࡩࡨࡰࡤࡸࡺࡸࡥࡄ࡫ࡳ࡬ࡪࡸࠧ೭") in list(dict.keys()):
			BaLSbE12oXgCsl = dict[QynMHGWA0blfqTUdxRh5Jzi2t(u"࠭ࡳࡪࡩࡱࡥࡹࡻࡲࡦࡅ࡬ࡴ࡭࡫ࡲࠨ೮")].split(EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠧࠧࠩ೯"))
			for ZA1fBenNahOR3xrkjvwYSVMy6JK5s in BaLSbE12oXgCsl:
				key,WoFrX46wzbCNp18 = ZA1fBenNahOR3xrkjvwYSVMy6JK5s.split(NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠨ࠿ࠪ೰"),YB5xyI7MaRslVpv(u"࠴ၫ"))
				dict[key] = XnQbsZF0Ouh8p7zCdUN(WoFrX46wzbCNp18)
		if C2dgEDAKQGsvh(u"ࠩࡸࡶࡱ࠭ೱ") in list(dict.keys()): dict[PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠪࡹࡷࡲࠧೲ")] = XnQbsZF0Ouh8p7zCdUN(dict[C2dgEDAKQGsvh(u"ࠫࡺࡸ࡬ࠨೳ")])
		Gvre3YWRVjBmuH7K5lhN1XiFDEI.append(dict)
	SjHwvazUfAGMQ9sTkY3IZOm0WLdo4P = BoWHNb9daQVCF16A(u"ࠬ࠭೴")
	if hhlbF1Sns5TrEN8QPCYmL4(u"࠭ࡳࡱ࠿ࡶ࡭࡬࠭೵") in sdKauTCwnh:
		AliC0ja492zfSI83ZX1RUs7uJpy = My7Dwqvs6bfGNSIgX.findall(jx7s8T0BFgODXLMzIYedf(u"ࠧࡴࡴࡦࡁࠧ࠮࠯ࡴ࠱ࡳࡰࡦࡿࡥࡳ࠱࡟ࡻ࠯ࡅ࠯ࡱ࡮ࡤࡽࡪࡸ࡟ࡪࡣࡶ࠲ࡻ࡬࡬ࡴࡧࡷ࠳ࡪࡴ࡟࠯࠰࠲ࡦࡦࡹࡥ࠯࡬ࡶ࠭ࠧ࠭೶"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if AliC0ja492zfSI83ZX1RUs7uJpy:
			AliC0ja492zfSI83ZX1RUs7uJpy = AK5RqLhji4W1wt9VdrCD3PGeQM[qbPw1d3KimF(u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩ೷")][FGDJwkEbTB5SoXujs3f(u"࠴ၬ")]+AliC0ja492zfSI83ZX1RUs7uJpy[FGDJwkEbTB5SoXujs3f(u"࠴ၬ")]
			xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(SToQEHqGtMnAlFbCz4wxBDuOsmW7,C2jP0iLNGKnHu9xp(u"ࠩࡊࡉ࡙࠭೸"),AliC0ja492zfSI83ZX1RUs7uJpy,v5EA6TqHX3s4jzBMk(u"ࠪࠫ೹"),FGDJwkEbTB5SoXujs3f(u"ࠫࠬ೺"),l0WAe1f7Bpi5ZXk(u"ࠬ࠭೻"),v5EA6TqHX3s4jzBMk(u"࠭ࠧ೼"),YB5xyI7MaRslVpv(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡝ࡔ࡛ࡔࡖࡄࡈ࠱࠷ࡴࡤࠨ೽"))
			SjHwvazUfAGMQ9sTkY3IZOm0WLdo4P = xHb86g9WZqPwRfVjXD2JalzSIp.content
			import youtube_signature.cipher as cFESG5413vDaQtdV8whegP2pL,youtube_signature.json_script_engine as OnuV9AXzRxDgvKoLZ5GcwN
			BaLSbE12oXgCsl = m2DSJrWi684jBznTFVObEHe7Mtpgo5.BaLSbE12oXgCsl.Cipher()
			BaLSbE12oXgCsl._object_cache = {}
			wWfNeCPxDM = BaLSbE12oXgCsl._load_javascript(SjHwvazUfAGMQ9sTkY3IZOm0WLdo4P)
			ccVJ23ELgCUD = dWsa2A0O4o5BYiqGXhyKEbM(vvHpKfcqRnrFzjG(u"ࠨࡵࡷࡶࠬ೾"),str(wWfNeCPxDM))
			bkZOqlJNowcgd3FG = m2DSJrWi684jBznTFVObEHe7Mtpgo5.dxBmyKfGrYRvAUDMtO60wcoZ.JsonScriptEngine(ccVJ23ELgCUD)
	for dict in Gvre3YWRVjBmuH7K5lhN1XiFDEI:
		url = dict[WMkAjB1RgN7q(u"ࠩࡸࡶࡱ࠭೿")]
		if UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠪࡷ࡮࡭࡮ࡢࡶࡸࡶࡪࡃࠧഀ") in url or url.count(LgpdP3UjFRnlX(u"ࠫࡸ࡯ࡧ࠾ࠩഁ"))>BmcLzCFjuIrZP5fwXH18aN6YS(u"࠶ၭ"):
			NWs2Rn7YFe0rOtw5f8zv49gkP.append(dict)
		elif SjHwvazUfAGMQ9sTkY3IZOm0WLdo4P and WMkAjB1RgN7q(u"ࠬࡹࠧം") in list(dict.keys()) and NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠭ࡳࡱࠩഃ") in list(dict.keys()):
			jcgX7RPfukKi = bkZOqlJNowcgd3FG.execute(dict[QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠧࡴࠩഄ")])
			if jcgX7RPfukKi!=dict[v5EA6TqHX3s4jzBMk(u"ࠨࡵࠪഅ")]:
				dict[YB5xyI7MaRslVpv(u"ࠩࡸࡶࡱ࠭ആ")] = url+LgpdP3UjFRnlX(u"ࠪࠪࠬഇ")+dict[C2dgEDAKQGsvh(u"ࠫࡸࡶࠧഈ")]+gItVahxL0w(u"ࠬࡃࠧഉ")+jcgX7RPfukKi
				NWs2Rn7YFe0rOtw5f8zv49gkP.append(dict)
	for dict in NWs2Rn7YFe0rOtw5f8zv49gkP:
		WK75AGwvEzJZTNLQB1,cDlWp4xIfZd1GKU8RPe,Dk29VeSBb5IqjKoLHXW0iyJOdfl,ssINGezFJnxfcU,RY1nwAZuNWLpgk942PCM,gg36CZRL8F = fY5wTlhtnOc0Er6sdy4k87b(u"࠭ࡵ࡯࡭ࡱࡳࡼࡴࠧഊ"),QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠧࡶࡰ࡮ࡲࡴࡽ࡮ࠨഋ"),NVS30xAdRFMIw1n9CislkE2(u"ࠨࡷࡱ࡯ࡳࡵࡷ࡯ࠩഌ"),QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠩࡘࡲࡰࡴ࡯ࡸࡰࠪ഍"),V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠪࠫഎ"),BoWHNb9daQVCF16A(u"ࠫ࠵࠭ഏ")
		try:
			SM47fskv3D5cATN6PgIHQ10omLBeZt = dict[T6wRistc1SCo4hqObgumK(u"ࠬࡺࡹࡱࡧࠪഐ")]
			SM47fskv3D5cATN6PgIHQ10omLBeZt = SM47fskv3D5cATN6PgIHQ10omLBeZt.replace(BmcLzCFjuIrZP5fwXH18aN6YS(u"࠭ࠫࠨ഑"),NVS30xAdRFMIw1n9CislkE2(u"ࠧࠨഒ"))
			items = My7Dwqvs6bfGNSIgX.findall(rbjsM8cRFiuA1(u"ࠨࠪ࠱࠮ࡄ࠯࠯ࠩ࠰࠭ࡃ࠮ࡁ࠮ࠫࡁࠥࠬ࠳࠰࠿ࠪࠤࠪഓ"),SM47fskv3D5cATN6PgIHQ10omLBeZt,My7Dwqvs6bfGNSIgX.DOTALL)
			ssINGezFJnxfcU,WK75AGwvEzJZTNLQB1,RY1nwAZuNWLpgk942PCM = items[T6wRistc1SCo4hqObgumK(u"࠶ၮ")]
			DwvjCRI9JxZbVEyBsTN = RY1nwAZuNWLpgk942PCM.split(nr5mZG89ICi6cgt4MfLJa0(u"ࠩ࠯ࠫഔ"))
			cDlWp4xIfZd1GKU8RPe = BoWHNb9daQVCF16A(u"ࠪࠫക")
			for ZA1fBenNahOR3xrkjvwYSVMy6JK5s in DwvjCRI9JxZbVEyBsTN: cDlWp4xIfZd1GKU8RPe += ZA1fBenNahOR3xrkjvwYSVMy6JK5s.split(LgpdP3UjFRnlX(u"ࠫ࠳࠭ഖ"))[jSu5Cg2Ub1OAkZVs8Yoz(u"࠰ၯ")]+BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠬ࠲ࠧഗ")
			cDlWp4xIfZd1GKU8RPe = cDlWp4xIfZd1GKU8RPe.strip(b05yftsZ6NYgIKP(u"࠭ࠬࠨഘ"))
			if C2dgEDAKQGsvh(u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨങ") in list(dict.keys()): gg36CZRL8F = str(float(dict[rbjsM8cRFiuA1(u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩച")]*LgpdP3UjFRnlX(u"࠲࠲ၰ"))//NVS30xAdRFMIw1n9CislkE2(u"࠳࠳࠶࠹ၱ")/LgpdP3UjFRnlX(u"࠲࠲ၰ"))+BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠩ࡮ࡦࡵࡹࠠࠡࠩഛ")
			else: gg36CZRL8F = PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠪࠫജ")
			if ssINGezFJnxfcU==QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠫࡹ࡫ࡸࡵࡶࠪഝ"): continue
			elif NVS30xAdRFMIw1n9CislkE2(u"ࠬ࠲ࠧഞ") in SM47fskv3D5cATN6PgIHQ10omLBeZt:
				ssINGezFJnxfcU = BmcLzCFjuIrZP5fwXH18aN6YS(u"࠭ࡁࠬࡘࠪട")
				Dk29VeSBb5IqjKoLHXW0iyJOdfl = WK75AGwvEzJZTNLQB1+BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠧࠡࠢࠪഠ")+gg36CZRL8F+dict[k5dztomYyN3H(u"ࠨࡵ࡬ࡾࡪ࠭ഡ")].split(RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠩࡻࠫഢ"))[LgpdP3UjFRnlX(u"࠴ၲ")]
			elif ssINGezFJnxfcU==BoWHNb9daQVCF16A(u"ࠪࡺ࡮ࡪࡥࡰࠩണ"):
				ssINGezFJnxfcU = EAc8h2sINroQYvR3WH06Ji7MVpn(u"࡛ࠫ࡯ࡤࡦࡱࠪത")
				Dk29VeSBb5IqjKoLHXW0iyJOdfl = gg36CZRL8F+dict[qbPw1d3KimF(u"ࠬࡹࡩࡻࡧࠪഥ")].split(BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠭ࡸࠨദ"))[BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠵ၳ")]+v5EA6TqHX3s4jzBMk(u"ࠧࠡࠢࠪധ")+dict[v5EA6TqHX3s4jzBMk(u"ࠨࡨࡳࡷࠬന")]+b05yftsZ6NYgIKP(u"ࠩࡩࡴࡸ࠭ഩ")+v5EA6TqHX3s4jzBMk(u"ࠪࠤࠥ࠭പ")+WK75AGwvEzJZTNLQB1
			elif ssINGezFJnxfcU==T6wRistc1SCo4hqObgumK(u"ࠫࡦࡻࡤࡪࡱࠪഫ"):
				ssINGezFJnxfcU = C2jP0iLNGKnHu9xp(u"ࠬࡇࡵࡥ࡫ࡲࠫബ")
				Dk29VeSBb5IqjKoLHXW0iyJOdfl = gg36CZRL8F+str(int(dict[hhlbF1Sns5TrEN8QPCYmL4(u"࠭ࡡࡶࡦ࡬ࡳࡤࡹࡡ࡮ࡲ࡯ࡩࡤࡸࡡࡵࡧࠪഭ")])/NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠶࠶࠰࠱ၴ"))+NVS30xAdRFMIw1n9CislkE2(u"ࠧ࡬ࡪࡽࠤࠥ࠭മ")+dict[QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠨࡣࡸࡨ࡮ࡵ࡟ࡤࡪࡤࡲࡳ࡫࡬ࡴࠩയ")]+NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠩࡦ࡬ࠬര")+NVS30xAdRFMIw1n9CislkE2(u"ࠪࠤࠥ࠭റ")+WK75AGwvEzJZTNLQB1
		except:
			WFMmPzdINGnfvRC1BoeOpb5 = N3JR6Bk5lVxnfGdgvQb.format_exc()
			if WFMmPzdINGnfvRC1BoeOpb5!=NVS30xAdRFMIw1n9CislkE2(u"ࠫࡓࡵ࡮ࡦࡖࡼࡴࡪࡀࠠࡏࡱࡱࡩࡡࡴࠧല"): ehpURIi6QBDOGu8qj5EYzXrsWHJ7.stderr.write(WFMmPzdINGnfvRC1BoeOpb5)
		if FGDJwkEbTB5SoXujs3f(u"ࠬࡪࡵࡳ࠿ࠪള") in dict[l0WAe1f7Bpi5ZXk(u"࠭ࡵࡳ࡮ࠪഴ")]: LEb1HQDAeFdsrNTnVgmXo9 = round(qbPw1d3KimF(u"࠱࠰࠸ၷ")+float(dict[BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠧࡶࡴ࡯ࠫവ")].split(FGDJwkEbTB5SoXujs3f(u"ࠨࡦࡸࡶࡂ࠭ശ"),V2RbfGOBdcA6l8NTsPWzEyvS7(u"࠷ၵ"))[V2RbfGOBdcA6l8NTsPWzEyvS7(u"࠷ၵ")].split(BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠩࠩࠫഷ"),V2RbfGOBdcA6l8NTsPWzEyvS7(u"࠷ၵ"))[NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠰ၶ")]))
		elif FGDJwkEbTB5SoXujs3f(u"ࠪࡥࡵࡶࡲࡰࡺࡇࡹࡷࡧࡴࡪࡱࡱࡑࡸ࠭സ") in list(dict.keys()): LEb1HQDAeFdsrNTnVgmXo9 = round(WMkAjB1RgN7q(u"࠲࠱࠹ၸ")+float(dict[hhlbF1Sns5TrEN8QPCYmL4(u"ࠫࡦࡶࡰࡳࡱࡻࡈࡺࡸࡡࡵ࡫ࡲࡲࡒࡹࠧഹ")])/hhlbF1Sns5TrEN8QPCYmL4(u"࠴࠴࠵࠶ၹ"))
		else: LEb1HQDAeFdsrNTnVgmXo9 = NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠬ࠶ࠧഺ")
		if C2jP0iLNGKnHu9xp(u"࠭ࡢࡪࡶࡵࡥࡹ࡫഻ࠧ") not in list(dict.keys()): gg36CZRL8F = dict[QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠧࡴ࡫ࡽࡩ഼ࠬ")].split(sRth5giAQzWlEVm7JOX(u"ࠨࡺࠪഽ"))[UnWjVbo503mEMv9KF(u"࠵ၺ")]
		else: gg36CZRL8F = dict[T6wRistc1SCo4hqObgumK(u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪാ")]
		if YB5xyI7MaRslVpv(u"ࠪ࡭ࡳ࡯ࡴࠨി") not in list(dict.keys()): dict[UnWjVbo503mEMv9KF(u"ࠫ࡮ࡴࡩࡵࠩീ")] = YB5xyI7MaRslVpv(u"ࠬ࠶࠭࠱ࠩു")
		dict[UxS67uoGThbMwnfNRzy4gajLd23JH(u"࠭ࡴࡪࡶ࡯ࡩࠬൂ")] = ssINGezFJnxfcU+k5dztomYyN3H(u"ࠧ࠻ࠢࠣࠫൃ")+Dk29VeSBb5IqjKoLHXW0iyJOdfl+BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠨࠢࠣࠬࠬൄ")+cDlWp4xIfZd1GKU8RPe+QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠩ࠯ࠫ൅")+dict[jSu5Cg2Ub1OAkZVs8Yoz(u"ࠪ࡭ࡹࡧࡧࠨെ")]+k5dztomYyN3H(u"ࠫ࠮࠭േ")
		dict[C2jP0iLNGKnHu9xp(u"ࠬࡷࡵࡢ࡮࡬ࡸࡾ࠭ൈ")] = Dk29VeSBb5IqjKoLHXW0iyJOdfl.split(l0WAe1f7Bpi5ZXk(u"࠭ࠠࠡࠩ൉"))[V2RbfGOBdcA6l8NTsPWzEyvS7(u"࠵ၻ")].split(QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠧ࡬ࡤࡳࡷࠬൊ"))[V2RbfGOBdcA6l8NTsPWzEyvS7(u"࠵ၻ")]
		dict[fY5wTlhtnOc0Er6sdy4k87b(u"ࠨࡶࡼࡴࡪ࠸ࠧോ")] = ssINGezFJnxfcU
		dict[vvHpKfcqRnrFzjG(u"ࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠫൌ")] = WK75AGwvEzJZTNLQB1
		dict[vvHpKfcqRnrFzjG(u"ࠪࡧࡴࡪࡥࡤࡵ്ࠪ")] = RY1nwAZuNWLpgk942PCM
		dict[BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠫࡩࡻࡲࡢࡶ࡬ࡳࡳ࠭ൎ")] = LEb1HQDAeFdsrNTnVgmXo9
		dict[C2dgEDAKQGsvh(u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭൏")] = gg36CZRL8F
		YLDAF5QTS2u4Isd0cBXrqM.append(dict)
	G1VIPYqtNys2bgo0HOx3,DlgXG236QL5bzJmsnjFPwV47HuqoBe,Bb5L8hP4wNSDtn,s4oilURCnFxGpT,kkuVnaAG4NiT7mXJ1UgoFlIOvdS2z = [],[],[],[],[]
	oLguGD8RQKbjyqa,nyFifQATVdZ4WC3quojsUHgk1r,RkFgradO0nGPcySphL8N,wyMAe3ku06Zc2QhisYDqfBSX5UaPz,LL0hEGJPgtuS98o4aVkTO = [],[],[],[],[]
	if ooACyWsxIHP8wkfb3:
		dict = {}
		dict[WMkAjB1RgN7q(u"࠭ࡴࡺࡲࡨ࠶ࠬ൐")] = NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠧࡂ࡙࠭ࠫ൑")
		dict[jSu5Cg2Ub1OAkZVs8Yoz(u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪ൒")] = l0WAe1f7Bpi5ZXk(u"ࠩࡰࡴࡩ࠭൓")
		dict[BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠪࡸ࡮ࡺ࡬ࡦࠩൔ")] = dict[fY5wTlhtnOc0Er6sdy4k87b(u"ࠫࡹࡿࡰࡦ࠴ࠪൕ")]+qbPw1d3KimF(u"ࠬࡀࠠࠡࠩൖ")+dict[BoWHNb9daQVCF16A(u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨൗ")]+WMkAjB1RgN7q(u"ࠧࠡࠢࠪ൘")+k5dztomYyN3H(u"ࠨฮ๋ำฮࠦะไ์ฬࠫ൙")
		dict[YB5xyI7MaRslVpv(u"ࠩࡸࡶࡱ࠭൚")] = ooACyWsxIHP8wkfb3
		dict[UnWjVbo503mEMv9KF(u"ࠪࡵࡺࡧ࡬ࡪࡶࡼࠫ൛")] = RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠫ࠵࠭൜")
		dict[l0WAe1f7Bpi5ZXk(u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭൝")] = hhlbF1Sns5TrEN8QPCYmL4(u"࠭࠹࠹࠹࠹࠹࠹࠹࠲࠲࠲ࠪ൞")
		YLDAF5QTS2u4Isd0cBXrqM.append(dict)
	if qFD6GyYO4nM:
		ebHN2cVyxIRKsuzk0L3,e1dn7APL6DyaMuchQkG2EI5jSY = cChyAEtdaMvNXsurWwnSeBzFU2m(qFD6GyYO4nM)
		NufCrUaTPHg475Y9MIdiB0JwZ = list(zip(ebHN2cVyxIRKsuzk0L3,e1dn7APL6DyaMuchQkG2EI5jSY))
		for title,BoEFz2WhUyvTgDeiZ in NufCrUaTPHg475Y9MIdiB0JwZ:
			dict = {}
			dict[sRth5giAQzWlEVm7JOX(u"ࠧࡵࡻࡳࡩ࠷࠭ൟ")] = UnWjVbo503mEMv9KF(u"ࠨࡃ࠮࡚ࠬൠ")
			dict[NVS30xAdRFMIw1n9CislkE2(u"ࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠫൡ")] = WMkAjB1RgN7q(u"ࠪࡱ࠸ࡻ࠸ࠨൢ")
			dict[T6wRistc1SCo4hqObgumK(u"ࠫࡺࡸ࡬ࠨൣ")] = BoEFz2WhUyvTgDeiZ
			if qbPw1d3KimF(u"ࠬࡱࡢࡱࡵࠪ൤") in title: dict[UnWjVbo503mEMv9KF(u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ൥")] = title.split(b05yftsZ6NYgIKP(u"ࠧ࡬ࡤࡳࡷࠬ൦"))[nr5mZG89ICi6cgt4MfLJa0(u"࠰ၽ")].rsplit(BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠨࠢࠣࠫ൧"))[-qbPw1d3KimF(u"࠷ၼ")]
			else: dict[fY5wTlhtnOc0Er6sdy4k87b(u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ൨")] = PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠪ࠵࠵࠭൩")
			if title.count(k5dztomYyN3H(u"ࠫࠥࠦࠧ൪"))>hhlbF1Sns5TrEN8QPCYmL4(u"࠲ၾ"):
				LLnUyuiC2wRM0 = title.rsplit(FGDJwkEbTB5SoXujs3f(u"ࠬࠦࠠࠨ൫"))[-rbjsM8cRFiuA1(u"࠵ၿ")]
				if LLnUyuiC2wRM0.isdigit(): dict[RqldvxFuM5GEQ2HAz93o7afBb0(u"࠭ࡱࡶࡣ࡯࡭ࡹࡿࠧ൬")] = LLnUyuiC2wRM0
				else: dict[WMkAjB1RgN7q(u"ࠧࡲࡷࡤࡰ࡮ࡺࡹࠨ൭")] = BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠨ࠲࠳࠴࠵࠭൮")
			if title==NVS30xAdRFMIw1n9CislkE2(u"ࠩ࠰࠵ࠬ൯"): dict[WMkAjB1RgN7q(u"ࠪࡸ࡮ࡺ࡬ࡦࠩ൰")] = dict[BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠫࡹࡿࡰࡦ࠴ࠪ൱")]+b05yftsZ6NYgIKP(u"ࠬࡀࠠࠡࠩ൲")+dict[nr5mZG89ICi6cgt4MfLJa0(u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨ൳")]+UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠧࠡࠢࠪ൴")+v5EA6TqHX3s4jzBMk(u"ࠨฮ๋ำฮࠦะไ์ฬࠫ൵")
			else: dict[BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠩࡷ࡭ࡹࡲࡥࠨ൶")] = dict[BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠪࡸࡾࡶࡥ࠳ࠩ൷")]+qbPw1d3KimF(u"ࠫ࠿ࠦࠠࠨ൸")+dict[NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧ൹")]+QynMHGWA0blfqTUdxRh5Jzi2t(u"࠭ࠠࠡࠩൺ")+dict[gItVahxL0w(u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨൻ")]+l0WAe1f7Bpi5ZXk(u"ࠨ࡭ࡥࡴࡸࠦࠠࠨർ")+dict[b05yftsZ6NYgIKP(u"ࠩࡴࡹࡦࡲࡩࡵࡻࠪൽ")]
			YLDAF5QTS2u4Isd0cBXrqM.append(dict)
	YLDAF5QTS2u4Isd0cBXrqM = sorted(YLDAF5QTS2u4Isd0cBXrqM,reverse=FGDJwkEbTB5SoXujs3f(u"ࡔࡳࡷࡨᄳ"),key=lambda key: float(key[WMkAjB1RgN7q(u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫൾ")]))
	if not YLDAF5QTS2u4Isd0cBXrqM:
		ZPXx9tplQ10D2skiFHqb = My7Dwqvs6bfGNSIgX.findall(UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠫࡨࡲࡡࡴࡵࡀࠦࡲ࡫ࡳࡴࡣࡪࡩࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧൿ"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		UUdtxEKOHDTq5YkcWLvg = My7Dwqvs6bfGNSIgX.findall(UnWjVbo503mEMv9KF(u"ࠬࠨࡰ࡭ࡣࡼࡩࡷࡋࡲࡳࡱࡵࡑࡪࡹࡳࡢࡩࡨࡖࡪࡴࡤࡦࡴࡨࡶࠧࡀ࡜ࡼࠤࡶࡹࡧࡸࡥࡢࡵࡲࡲࠧࡀ࡜ࡼࠤࡵࡹࡳࡹࠢ࠻࡞࡞ࡠࢀࠨࡴࡦࡺࡷࡸࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ඀"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		R9RpBFyY4IaZubcG8fNndJeHQ = My7Dwqvs6bfGNSIgX.findall(jx7s8T0BFgODXLMzIYedf(u"࠭ࠢࡱ࡮ࡤࡽࡪࡸࡅࡳࡴࡲࡶࡒ࡫ࡳࡴࡣࡪࡩࡗ࡫࡮ࡥࡧࡵࡩࡷࠨ࠺࡝ࡽࠥࡶࡪࡧࡳࡰࡰࠥ࠾ࢀࠨࡳࡪ࡯ࡳࡰࡪ࡚ࡥࡹࡶࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬඁ"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		NpwctnZDKokruHBSUxaTLOQG = My7Dwqvs6bfGNSIgX.findall(NVS30xAdRFMIw1n9CislkE2(u"ࠧࠣࡲ࡯ࡥࡾ࡫ࡲࡆࡴࡵࡳࡷࡓࡥࡴࡵࡤ࡫ࡪࡘࡥ࡯ࡦࡨࡶࡪࡸࠢ࠻࡞ࡾࠦࡸࡻࡢࡳࡧࡤࡷࡴࡴࠢ࠻ࡽࠥࡷ࡮ࡳࡰ࡭ࡧࡗࡩࡽࡺࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩං"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		try: ZPTH5x7VogQhSmKdqyvejf3WCGblI = hJewSpndQCsY4bA[BoWHNb9daQVCF16A(u"ࠨࡲ࡯ࡥࡾࡧࡢࡪ࡮࡬ࡸࡾ࡙ࡴࡢࡶࡸࡷࠬඃ")][BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠩࡨࡶࡷࡵࡲࡔࡥࡵࡩࡪࡴࠧ඄")][QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠪࡧࡴࡴࡦࡪࡴࡰࡈ࡮ࡧ࡬ࡰࡩࡕࡩࡳࡪࡥࡳࡧࡵࠫඅ")][l0WAe1f7Bpi5ZXk(u"ࠫࡹ࡯ࡴ࡭ࡧࠪආ")][EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠬࡸࡵ࡯ࡵࠪඇ")][b05yftsZ6NYgIKP(u"࠳ႀ")][PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"࠭ࡴࡦࡺࡷࡸࠬඈ")]
		except: ZPTH5x7VogQhSmKdqyvejf3WCGblI = hhlbF1Sns5TrEN8QPCYmL4(u"ࠧࠨඉ")
		try: MWrOIXwZ3F2K0dh419p6PTjkGQJc = hJewSpndQCsY4bA[gItVahxL0w(u"ࠨࡲ࡯ࡥࡾࡧࡢࡪ࡮࡬ࡸࡾ࡙ࡴࡢࡶࡸࡷࠬඊ")][BoWHNb9daQVCF16A(u"ࠩࡨࡶࡷࡵࡲࡔࡥࡵࡩࡪࡴࠧඋ")][RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠪࡧࡴࡴࡦࡪࡴࡰࡈ࡮ࡧ࡬ࡰࡩࡕࡩࡳࡪࡥࡳࡧࡵࠫඌ")][V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠫࡩ࡯ࡡ࡭ࡱࡪࡑࡪࡹࡳࡢࡩࡨࡷࠬඍ")][BoWHNb9daQVCF16A(u"࠴ႁ")][vvHpKfcqRnrFzjG(u"ࠬࡸࡵ࡯ࡵࠪඎ")][BoWHNb9daQVCF16A(u"࠴ႁ")][jSu5Cg2Ub1OAkZVs8Yoz(u"࠭ࡴࡦࡺࡷࡸࠬඏ")]
		except: MWrOIXwZ3F2K0dh419p6PTjkGQJc = RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠧࠨඐ")
		try: RRVL4cWBg9iat1byleI3kX25rju = hJewSpndQCsY4bA[BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠨࡲ࡯ࡥࡾࡧࡢࡪ࡮࡬ࡸࡾ࡙ࡴࡢࡶࡸࡷࠬඑ")][jx7s8T0BFgODXLMzIYedf(u"ࠩࡵࡩࡦࡹ࡯࡯ࠩඒ")]
		except: RRVL4cWBg9iat1byleI3kX25rju = C2dgEDAKQGsvh(u"ࠪࠫඓ")
		if ZPXx9tplQ10D2skiFHqb or UUdtxEKOHDTq5YkcWLvg or R9RpBFyY4IaZubcG8fNndJeHQ or NpwctnZDKokruHBSUxaTLOQG or ZPTH5x7VogQhSmKdqyvejf3WCGblI or MWrOIXwZ3F2K0dh419p6PTjkGQJc or RRVL4cWBg9iat1byleI3kX25rju:
			if   ZPXx9tplQ10D2skiFHqb: mR4VLhryYT2koGU6iBX = ZPXx9tplQ10D2skiFHqb[BmcLzCFjuIrZP5fwXH18aN6YS(u"࠵ႂ")]
			elif UUdtxEKOHDTq5YkcWLvg: mR4VLhryYT2koGU6iBX = UUdtxEKOHDTq5YkcWLvg[hhlbF1Sns5TrEN8QPCYmL4(u"࠶ႃ")]
			elif R9RpBFyY4IaZubcG8fNndJeHQ: mR4VLhryYT2koGU6iBX = R9RpBFyY4IaZubcG8fNndJeHQ[gItVahxL0w(u"࠰ႄ")]
			elif NpwctnZDKokruHBSUxaTLOQG: mR4VLhryYT2koGU6iBX = NpwctnZDKokruHBSUxaTLOQG[rbjsM8cRFiuA1(u"࠱ႅ")]
			elif ZPTH5x7VogQhSmKdqyvejf3WCGblI: mR4VLhryYT2koGU6iBX = ZPTH5x7VogQhSmKdqyvejf3WCGblI
			elif MWrOIXwZ3F2K0dh419p6PTjkGQJc: mR4VLhryYT2koGU6iBX = MWrOIXwZ3F2K0dh419p6PTjkGQJc
			elif RRVL4cWBg9iat1byleI3kX25rju: mR4VLhryYT2koGU6iBX = RRVL4cWBg9iat1byleI3kX25rju
			EZXQ31NfASuvbrjegoqw9zIpTLhFt = mR4VLhryYT2koGU6iBX.replace(nr5mZG89ICi6cgt4MfLJa0(u"ࠫࡡࡴࠧඔ"),BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠬ࠭ඕ")).strip(V2RbfGOBdcA6l8NTsPWzEyvS7(u"࠭ࠠࠨඖ"))
			skjEOUpmW3B9wiT1SyzZCIhP4tce = RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟๊ิฬࠦวๅใํำ๏๎ࠠโ์๊ࠤฺ๊ใๅหࠣ์็ี๋ࠠๅ๋๊ࠥเ๊า่่ࠢฬฬๅࠡๆห฽฻ࠦวๅ็ึฮำีๅ๋่ࠣวํฺ๋ࠦำ้ࠣฯ๎แาࠢส่ว์࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ඗")
			ZIOHgA3z0TBR(UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠨࠩ඘"),C2dgEDAKQGsvh(u"ࠩࠪ඙"),sRth5giAQzWlEVm7JOX(u"ࠪีุอไส่๊ࠢࠥอไๆ๊ๅ฽ࠥ๎วๅ็หี๊าࠧක"),skjEOUpmW3B9wiT1SyzZCIhP4tce+BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠫࡡࡴ࡜࡯ࠩඛ")+EZXQ31NfASuvbrjegoqw9zIpTLhFt)
			return gItVahxL0w(u"ࠬࡋࡲࡳࡱࡵࠤࠥࠦࠠ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤ࡞ࡕࡕࡕࡗࡅࡉࠥࡌࡡࡪ࡮ࡨࡨ࠿ࠦࠧග")+EZXQ31NfASuvbrjegoqw9zIpTLhFt,[],[]
		else: return EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠭ࡅࡳࡴࡲࡶࠥࠦࠠࠡ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥ࡟ࡏࡖࡖࡘࡆࡊࠦࡆࡢ࡫࡯ࡩࡩ࠭ඝ"),[],[]
	X4pqskrDzf,i0gyuRLBzC3mHqNhxF,eaNLuvclF7niE9stGom28g = [],[],[]
	for dict in YLDAF5QTS2u4Isd0cBXrqM:
		if dict[v5EA6TqHX3s4jzBMk(u"ࠧࡵࡻࡳࡩ࠷࠭ඞ")]==l0WAe1f7Bpi5ZXk(u"ࠨࡘ࡬ࡨࡪࡵࠧඟ"):
			G1VIPYqtNys2bgo0HOx3.append(dict[FGDJwkEbTB5SoXujs3f(u"ࠩࡷ࡭ࡹࡲࡥࠨච")])
			oLguGD8RQKbjyqa.append(dict)
		elif dict[UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠪࡸࡾࡶࡥ࠳ࠩඡ")]==v5EA6TqHX3s4jzBMk(u"ࠫࡆࡻࡤࡪࡱࠪජ"):
			DlgXG236QL5bzJmsnjFPwV47HuqoBe.append(dict[YB5xyI7MaRslVpv(u"ࠬࡺࡩࡵ࡮ࡨࠫඣ")])
			nyFifQATVdZ4WC3quojsUHgk1r.append(dict)
		elif dict[C2dgEDAKQGsvh(u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨඤ")]==UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠧ࡮ࡲࡧࠫඥ"):
			title = dict[NVS30xAdRFMIw1n9CislkE2(u"ࠨࡶ࡬ࡸࡱ࡫ࠧඦ")].replace(WMkAjB1RgN7q(u"ࠩࡄ࠯࡛ࡀࠠࠡࠩට"),qbPw1d3KimF(u"ࠪࠫඨ"))
			if RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬඩ") not in list(dict.keys()): gg36CZRL8F = UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠬ࠶ࠧඪ")
			else: gg36CZRL8F = dict[V2RbfGOBdcA6l8NTsPWzEyvS7(u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧණ")]
			X4pqskrDzf.append([dict,{},title,gg36CZRL8F])
		else:
			title = dict[v5EA6TqHX3s4jzBMk(u"ࠧࡵ࡫ࡷࡰࡪ࠭ඬ")].replace(nr5mZG89ICi6cgt4MfLJa0(u"ࠨࡃ࠮࡚࠿ࠦࠠࠨත"),sRth5giAQzWlEVm7JOX(u"ࠩࠪථ"))
			if rbjsM8cRFiuA1(u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫද") not in list(dict.keys()): gg36CZRL8F = V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠫ࠵࠭ධ")
			else: gg36CZRL8F = dict[RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭න")]
			X4pqskrDzf.append([dict,{},title,gg36CZRL8F])
			Bb5L8hP4wNSDtn.append(title)
			RkFgradO0nGPcySphL8N.append(dict)
		jaImoU6cWONJyu1STlQ0znFC7gGPZ = UnWjVbo503mEMv9KF(u"ࡕࡴࡸࡩᄴ")
		if qbPw1d3KimF(u"࠭ࡣࡰࡦࡨࡧࡸ࠭඲") in list(dict.keys()):
			if k5dztomYyN3H(u"ࠧࡢࡸ࠳ࠫඳ") in dict[gItVahxL0w(u"ࠨࡥࡲࡨࡪࡩࡳࠨප")]: jaImoU6cWONJyu1STlQ0znFC7gGPZ = l0WAe1f7Bpi5ZXk(u"ࡈࡤࡰࡸ࡫ᄵ")
			elif YSomBdvcNUMF3b8JDiCfrVW<l0WAe1f7Bpi5ZXk(u"࠳࠻ႆ"):
				if nr5mZG89ICi6cgt4MfLJa0(u"ࠩࡤࡺࡨ࠭ඵ") not in dict[YB5xyI7MaRslVpv(u"ࠪࡧࡴࡪࡥࡤࡵࠪබ")] and YB5xyI7MaRslVpv(u"ࠫࡲࡶ࠴ࡢࠩභ") not in dict[QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠬࡩ࡯ࡥࡧࡦࡷࠬම")]: jaImoU6cWONJyu1STlQ0znFC7gGPZ = nr5mZG89ICi6cgt4MfLJa0(u"ࡉࡥࡱࡹࡥᄶ")
		if dict[UxS67uoGThbMwnfNRzy4gajLd23JH(u"࠭ࡴࡺࡲࡨ࠶ࠬඹ")]==WMkAjB1RgN7q(u"ࠧࡗ࡫ࡧࡩࡴ࠭ය") and dict[UnWjVbo503mEMv9KF(u"ࠨ࡫ࡱ࡭ࡹ࠭ර")]!=qbPw1d3KimF(u"ࠩ࠳࠱࠵࠭඼") and jaImoU6cWONJyu1STlQ0znFC7gGPZ==jx7s8T0BFgODXLMzIYedf(u"ࡘࡷࡻࡥᄷ"):
			kkuVnaAG4NiT7mXJ1UgoFlIOvdS2z.append(dict[BoWHNb9daQVCF16A(u"ࠪࡸ࡮ࡺ࡬ࡦࠩල")])
			LL0hEGJPgtuS98o4aVkTO.append(dict)
		elif dict[v5EA6TqHX3s4jzBMk(u"ࠫࡹࡿࡰࡦ࠴ࠪ඾")]==YB5xyI7MaRslVpv(u"ࠬࡇࡵࡥ࡫ࡲࠫ඿") and dict[YB5xyI7MaRslVpv(u"࠭ࡩ࡯࡫ࡷࠫව")]!=C2dgEDAKQGsvh(u"ࠧ࠱࠯࠳ࠫශ") and jaImoU6cWONJyu1STlQ0znFC7gGPZ==NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࡙ࡸࡵࡦᄸ"):
			s4oilURCnFxGpT.append(dict[k5dztomYyN3H(u"ࠨࡶ࡬ࡸࡱ࡫ࠧෂ")])
			wyMAe3ku06Zc2QhisYDqfBSX5UaPz.append(dict)
	for psIOXU94u6kQHBMh0 in wyMAe3ku06Zc2QhisYDqfBSX5UaPz:
		mmsPl1A2gBjk79QzVIOJFbuXUR6 = psIOXU94u6kQHBMh0[V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪස")]
		for nz2pJBObTw8hlGWkQmIsfi3N5LV in LL0hEGJPgtuS98o4aVkTO:
			q5pELOAZWtsYJCul8cB = nz2pJBObTw8hlGWkQmIsfi3N5LV[b05yftsZ6NYgIKP(u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫහ")]
			gg36CZRL8F = q5pELOAZWtsYJCul8cB+mmsPl1A2gBjk79QzVIOJFbuXUR6
			title = nz2pJBObTw8hlGWkQmIsfi3N5LV[BoWHNb9daQVCF16A(u"ࠫࡹ࡯ࡴ࡭ࡧࠪළ")].replace(WMkAjB1RgN7q(u"ࠬ࡜ࡩࡥࡧࡲ࠾ࠥࠦࠧෆ"),C2dgEDAKQGsvh(u"࠭࡭ࡱࡦࠣࠤࠬ෇"))
			title = title.replace(nz2pJBObTw8hlGWkQmIsfi3N5LV[vvHpKfcqRnrFzjG(u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩ෈")]+C2dgEDAKQGsvh(u"ࠨࠢࠣࠫ෉"),jx7s8T0BFgODXLMzIYedf(u"්ࠩࠪ"))
			title = title.replace(str((float(q5pELOAZWtsYJCul8cB*BoWHNb9daQVCF16A(u"࠴࠴ႇ"))//NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠵࠵࠸࠴ႈ")/BoWHNb9daQVCF16A(u"࠴࠴ႇ")))+V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠪ࡯ࡧࡶࡳࠨ෋"),str((float(gg36CZRL8F*BoWHNb9daQVCF16A(u"࠴࠴ႇ"))//NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠵࠵࠸࠴ႈ")/BoWHNb9daQVCF16A(u"࠴࠴ႇ")))+gItVahxL0w(u"ࠫࡰࡨࡰࡴࠩ෌"))
			title = title+LgpdP3UjFRnlX(u"ࠬ࠮ࠧ෍")+psIOXU94u6kQHBMh0[BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠭ࡴࡪࡶ࡯ࡩࠬ෎")].split(NVS30xAdRFMIw1n9CislkE2(u"ࠧࠩࠩා"),YB5xyI7MaRslVpv(u"࠶ႉ"))[YB5xyI7MaRslVpv(u"࠶ႉ")]
			X4pqskrDzf.append([nz2pJBObTw8hlGWkQmIsfi3N5LV,psIOXU94u6kQHBMh0,title,gg36CZRL8F])
	X4pqskrDzf = sorted(X4pqskrDzf, reverse=v5EA6TqHX3s4jzBMk(u"࡚ࡲࡶࡧᄹ"), key=lambda key: float(key[NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠹ႊ")]))
	for nz2pJBObTw8hlGWkQmIsfi3N5LV,psIOXU94u6kQHBMh0,title,gg36CZRL8F in X4pqskrDzf:
		uAhDJdVjYn8 = nz2pJBObTw8hlGWkQmIsfi3N5LV[NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪැ")]
		if UnWjVbo503mEMv9KF(u"ࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠫෑ") in list(psIOXU94u6kQHBMh0.keys()):
			uAhDJdVjYn8 = YB5xyI7MaRslVpv(u"ࠪࡱࡵࡪࠧි")
		if uAhDJdVjYn8 not in eaNLuvclF7niE9stGom28g:
			eaNLuvclF7niE9stGom28g.append(uAhDJdVjYn8)
			i0gyuRLBzC3mHqNhxF.append([nz2pJBObTw8hlGWkQmIsfi3N5LV,psIOXU94u6kQHBMh0,title,gg36CZRL8F])
	m6aAu0YnxgKUFQ2JSI,N6iCF2GBe5MVgJ,hbd4AitlZpgYF1 = [],[],EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠰ႋ")
	tnKsrhBIwcQoDq,HA7cda1Npr0zw5ktODsM = NVS30xAdRFMIw1n9CislkE2(u"ࠫࠬී"),BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠬ࠭ු")
	try: tnKsrhBIwcQoDq = hJewSpndQCsY4bA[RqldvxFuM5GEQ2HAz93o7afBb0(u"࠭ࡶࡪࡦࡨࡳࡉ࡫ࡴࡢ࡫࡯ࡷࠬ෕")][FGDJwkEbTB5SoXujs3f(u"ࠧࡢࡷࡷ࡬ࡴࡸࠧූ")]
	except: tnKsrhBIwcQoDq = gItVahxL0w(u"ࠨࠩ෗")
	try: hfmBgV8rE5sXdKJpPjUFRDZNWY = hJewSpndQCsY4bA[BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠩࡹ࡭ࡩ࡫࡯ࡅࡧࡷࡥ࡮ࡲࡳࠨෘ")][WMkAjB1RgN7q(u"ࠪࡧ࡭ࡧ࡮࡯ࡧ࡯ࡍࡩ࠭ෙ")]
	except: hfmBgV8rE5sXdKJpPjUFRDZNWY = C2jP0iLNGKnHu9xp(u"ࠫࠬේ")
	if tnKsrhBIwcQoDq and hfmBgV8rE5sXdKJpPjUFRDZNWY:
		hbd4AitlZpgYF1 += gItVahxL0w(u"࠲ႌ")
		title = YB5xyI7MaRslVpv(u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࡐ࡙ࡑࡉࡗࡀࠠࠡࠩෛ")+tnKsrhBIwcQoDq+BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨො")
		BoEFz2WhUyvTgDeiZ = AK5RqLhji4W1wt9VdrCD3PGeQM[EAc8h2sINroQYvR3WH06Ji7MVpn(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨෝ")][vvHpKfcqRnrFzjG(u"࠲ႍ")]+C2jP0iLNGKnHu9xp(u"ࠨ࠱ࡦ࡬ࡦࡴ࡮ࡦ࡮࠲ࠫෞ")+hfmBgV8rE5sXdKJpPjUFRDZNWY
		m6aAu0YnxgKUFQ2JSI.append(title)
		N6iCF2GBe5MVgJ.append(BoEFz2WhUyvTgDeiZ)
		try: HA7cda1Npr0zw5ktODsM = hJewSpndQCsY4bA[fY5wTlhtnOc0Er6sdy4k87b(u"ࠩࡹ࡭ࡩ࡫࡯ࡅࡧࡷࡥ࡮ࡲࡳࠨෟ")][jSu5Cg2Ub1OAkZVs8Yoz(u"ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱ࠭෠")][BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡳࠨ෡")][-hhlbF1Sns5TrEN8QPCYmL4(u"࠴ႎ")][sRth5giAQzWlEVm7JOX(u"ࠬࡻࡲ࡭ࠩ෢")]
		except: pass
	for nz2pJBObTw8hlGWkQmIsfi3N5LV,psIOXU94u6kQHBMh0,title,gg36CZRL8F in i0gyuRLBzC3mHqNhxF:
		m6aAu0YnxgKUFQ2JSI.append(title) ; N6iCF2GBe5MVgJ.append(jSu5Cg2Ub1OAkZVs8Yoz(u"࠭ࡨࡪࡩ࡫ࡩࡸࡺࠧ෣"))
	if Bb5L8hP4wNSDtn: m6aAu0YnxgKUFQ2JSI.append(jx7s8T0BFgODXLMzIYedf(u"ࠧึ๊ิอࠥ๎ี้ฬ้ࠣาีฯสࠩ෤")) ; N6iCF2GBe5MVgJ.append(PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠨ࡯ࡸࡼࡪࡪࠧ෥"))
	if X4pqskrDzf: m6aAu0YnxgKUFQ2JSI.append(jSu5Cg2Ub1OAkZVs8Yoz(u"ุࠩ์ึฯ้ࠠื๋ฮࠥอไๆฬ๋ๅึ࠭෦")) ; N6iCF2GBe5MVgJ.append(l0WAe1f7Bpi5ZXk(u"ࠪࡥࡱࡲࠧ෧"))
	if kkuVnaAG4NiT7mXJ1UgoFlIOvdS2z: m6aAu0YnxgKUFQ2JSI.append(WMkAjB1RgN7q(u"ࠫࡲࡶࡤࠡษัฮึࠦวๅื๋ีฮ่ࠦศๆุ์ฯ࠭෨")) ; N6iCF2GBe5MVgJ.append(rbjsM8cRFiuA1(u"ࠬࡳࡰࡥࠩ෩"))
	if G1VIPYqtNys2bgo0HOx3: m6aAu0YnxgKUFQ2JSI.append(FGDJwkEbTB5SoXujs3f(u"࠭ี้ำฬࠤอี่็ุࠢ์ฯ࠭෪")) ; N6iCF2GBe5MVgJ.append(BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠧࡷ࡫ࡧࡩࡴ࠭෫"))
	if DlgXG236QL5bzJmsnjFPwV47HuqoBe: m6aAu0YnxgKUFQ2JSI.append(hhlbF1Sns5TrEN8QPCYmL4(u"ࠨื๋ฮࠥฮฯู้่ࠣํืษࠨ෬")) ; N6iCF2GBe5MVgJ.append(T6wRistc1SCo4hqObgumK(u"ࠩࡤࡹࡩ࡯࡯ࠨ෭"))
	sqOVnaRDT6oFp = QynMHGWA0blfqTUdxRh5Jzi2t(u"ࡆࡢ࡮ࡶࡩᄺ")
	while v5EA6TqHX3s4jzBMk(u"ࡕࡴࡸࡩᄻ"):
		GOtNfU3xQFkEhPouwA = CnKwdteDG5BE8MTRhUpYIJm3NLrSgq(fcJYEedPmyt56xBIkMiSFqCh7vw2UK, m6aAu0YnxgKUFQ2JSI)
		if GOtNfU3xQFkEhPouwA==-C2dgEDAKQGsvh(u"࠵ႏ"): return l0WAe1f7Bpi5ZXk(u"ࠪࡉ࡝ࡏࡔࡠࡃࡏࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ෮"),[],[]
		elif GOtNfU3xQFkEhPouwA==NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠵႐") and tnKsrhBIwcQoDq:
			BoEFz2WhUyvTgDeiZ = N6iCF2GBe5MVgJ[GOtNfU3xQFkEhPouwA]
			h7StLmFTb1QuXl6YqIdEfayZ = ehpURIi6QBDOGu8qj5EYzXrsWHJ7.argv[T6wRistc1SCo4hqObgumK(u"࠶႑")]+vvHpKfcqRnrFzjG(u"ࠫࡄࡺࡹࡱࡧࡀࡪࡴࡲࡤࡦࡴࠩࡱࡴࡪࡥ࠾࠳࠷࠵ࠫࡴࡡ࡮ࡧࡀࠫ෯")+F8fMqZKB4APk(tnKsrhBIwcQoDq)+C2dgEDAKQGsvh(u"ࠬࠬࡵࡳ࡮ࡀࠫ෰")+BoEFz2WhUyvTgDeiZ
			if HA7cda1Npr0zw5ktODsM: h7StLmFTb1QuXl6YqIdEfayZ = h7StLmFTb1QuXl6YqIdEfayZ+b05yftsZ6NYgIKP(u"࠭ࠦࡪ࡯ࡤ࡫ࡪࡃࠧ෱")+F8fMqZKB4APk(HA7cda1Npr0zw5ktODsM)
			tUXmK5PeEH9SDq.executebuiltin(V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠢࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱࡙ࡵࡪࡡࡵࡧࠫࠦෲ")+h7StLmFTb1QuXl6YqIdEfayZ+UnWjVbo503mEMv9KF(u"ࠣࠫࠥෳ"))
			return YB5xyI7MaRslVpv(u"ࠩࡈ࡜ࡎ࡚࡟ࡂࡎࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ෴"),[],[]
		vwnZ6hF0xpbt47o1f2VUily = N6iCF2GBe5MVgJ[GOtNfU3xQFkEhPouwA]
		BmsWvrytaKL768CA32xTkeqJRhldf = m6aAu0YnxgKUFQ2JSI[GOtNfU3xQFkEhPouwA]
		if vwnZ6hF0xpbt47o1f2VUily==LgpdP3UjFRnlX(u"ࠪࡨࡦࡹࡨࠨ෵"):
			b8aHKFJ9V5XWI2YwSi6uemxBrqM = ooACyWsxIHP8wkfb3
			break
		elif vwnZ6hF0xpbt47o1f2VUily in [T6wRistc1SCo4hqObgumK(u"ࠫࡦࡻࡤࡪࡱࠪ෶"),gItVahxL0w(u"ࠬࡼࡩࡥࡧࡲࠫ෷"),fY5wTlhtnOc0Er6sdy4k87b(u"࠭࡭ࡶࡺࡨࡨࠬ෸")]:
			if vwnZ6hF0xpbt47o1f2VUily==V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠧ࡮ࡷࡻࡩࡩ࠭෹"): wlfZEzuRyYLvrp,JnoiaZd9qY = Bb5L8hP4wNSDtn,RkFgradO0nGPcySphL8N
			elif vwnZ6hF0xpbt47o1f2VUily==NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠨࡸ࡬ࡨࡪࡵࠧ෺"): wlfZEzuRyYLvrp,JnoiaZd9qY = G1VIPYqtNys2bgo0HOx3,oLguGD8RQKbjyqa
			elif vwnZ6hF0xpbt47o1f2VUily==hhlbF1Sns5TrEN8QPCYmL4(u"ࠩࡤࡹࡩ࡯࡯ࠨ෻"): wlfZEzuRyYLvrp,JnoiaZd9qY = DlgXG236QL5bzJmsnjFPwV47HuqoBe,nyFifQATVdZ4WC3quojsUHgk1r
			GOtNfU3xQFkEhPouwA = CnKwdteDG5BE8MTRhUpYIJm3NLrSgq(RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠪหำะัࠡษ็้้็ࠠศๆ่๊ฬูศ࠻ࠩ෼"), wlfZEzuRyYLvrp)
			if GOtNfU3xQFkEhPouwA!=-YB5xyI7MaRslVpv(u"࠱႒"):
				b8aHKFJ9V5XWI2YwSi6uemxBrqM = JnoiaZd9qY[GOtNfU3xQFkEhPouwA][FGDJwkEbTB5SoXujs3f(u"ࠫࡺࡸ࡬ࠨ෽")]
				BmsWvrytaKL768CA32xTkeqJRhldf = wlfZEzuRyYLvrp[GOtNfU3xQFkEhPouwA]
				break
		elif vwnZ6hF0xpbt47o1f2VUily==b05yftsZ6NYgIKP(u"ࠬࡳࡰࡥࠩ෾"):
			GOtNfU3xQFkEhPouwA = CnKwdteDG5BE8MTRhUpYIJm3NLrSgq(nr5mZG89ICi6cgt4MfLJa0(u"࠭วฯฬิࠤั๎ฯสࠢสฺ่๎ัส࠼ࠪ෿"), kkuVnaAG4NiT7mXJ1UgoFlIOvdS2z)
			if GOtNfU3xQFkEhPouwA!=-BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠲႓"):
				BmsWvrytaKL768CA32xTkeqJRhldf = kkuVnaAG4NiT7mXJ1UgoFlIOvdS2z[GOtNfU3xQFkEhPouwA]
				AjPUXmefr7iaqMdVO6uCnt = LL0hEGJPgtuS98o4aVkTO[GOtNfU3xQFkEhPouwA]
				GOtNfU3xQFkEhPouwA = CnKwdteDG5BE8MTRhUpYIJm3NLrSgq(jSu5Cg2Ub1OAkZVs8Yoz(u"ࠧศะอีࠥา่ะหࠣห้฻่ห࠼ࠪ฀"), s4oilURCnFxGpT)
				if GOtNfU3xQFkEhPouwA!=-qbPw1d3KimF(u"࠳႔"):
					BmsWvrytaKL768CA32xTkeqJRhldf += WMkAjB1RgN7q(u"ࠨࠢ࠮ࠤࠬก")+s4oilURCnFxGpT[GOtNfU3xQFkEhPouwA]
					Wb1dVnH0rBxA9GELpvQjY = wyMAe3ku06Zc2QhisYDqfBSX5UaPz[GOtNfU3xQFkEhPouwA]
					sqOVnaRDT6oFp = UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࡖࡵࡹࡪᄼ")
					break
		elif vwnZ6hF0xpbt47o1f2VUily==k5dztomYyN3H(u"ࠩࡤࡰࡱ࠭ข"):
			xxRBGp6d12YV5eXIfC,xsUZguG1ELod8ybI3DJf,LsZcexz79EkSgw2RP,XVzZk8lJRcCS1B = list(zip(*X4pqskrDzf))
			GOtNfU3xQFkEhPouwA = CnKwdteDG5BE8MTRhUpYIJm3NLrSgq(fY5wTlhtnOc0Er6sdy4k87b(u"ࠪหำะัࠡษ็้้็ࠠศๆ่๊ฬูศ࠻ࠩฃ"), LsZcexz79EkSgw2RP)
			if GOtNfU3xQFkEhPouwA!=-RqldvxFuM5GEQ2HAz93o7afBb0(u"࠴႕"):
				BmsWvrytaKL768CA32xTkeqJRhldf = LsZcexz79EkSgw2RP[GOtNfU3xQFkEhPouwA]
				AjPUXmefr7iaqMdVO6uCnt = xxRBGp6d12YV5eXIfC[GOtNfU3xQFkEhPouwA]
				if jSu5Cg2Ub1OAkZVs8Yoz(u"ࠫࡲࡶࡤࠨค") in LsZcexz79EkSgw2RP[GOtNfU3xQFkEhPouwA] and AjPUXmefr7iaqMdVO6uCnt[FGDJwkEbTB5SoXujs3f(u"ࠬࡻࡲ࡭ࠩฅ")]!=ooACyWsxIHP8wkfb3:
					Wb1dVnH0rBxA9GELpvQjY = xsUZguG1ELod8ybI3DJf[GOtNfU3xQFkEhPouwA]
					sqOVnaRDT6oFp = T6wRistc1SCo4hqObgumK(u"ࡗࡶࡺ࡫ᄽ")
				else: b8aHKFJ9V5XWI2YwSi6uemxBrqM = AjPUXmefr7iaqMdVO6uCnt[PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"࠭ࡵࡳ࡮ࠪฆ")]
				break
		elif vwnZ6hF0xpbt47o1f2VUily==sRth5giAQzWlEVm7JOX(u"ࠧࡩ࡫ࡪ࡬ࡪࡹࡴࠨง"):
			xxRBGp6d12YV5eXIfC,xsUZguG1ELod8ybI3DJf,LsZcexz79EkSgw2RP,XVzZk8lJRcCS1B = list(zip(*i0gyuRLBzC3mHqNhxF))
			AjPUXmefr7iaqMdVO6uCnt = xxRBGp6d12YV5eXIfC[GOtNfU3xQFkEhPouwA-hbd4AitlZpgYF1]
			if EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠨ࡯ࡳࡨࠬจ") in LsZcexz79EkSgw2RP[GOtNfU3xQFkEhPouwA-hbd4AitlZpgYF1] and AjPUXmefr7iaqMdVO6uCnt[sRth5giAQzWlEVm7JOX(u"ࠩࡸࡶࡱ࠭ฉ")]!=ooACyWsxIHP8wkfb3:
				Wb1dVnH0rBxA9GELpvQjY = xsUZguG1ELod8ybI3DJf[GOtNfU3xQFkEhPouwA-hbd4AitlZpgYF1]
				sqOVnaRDT6oFp = v5EA6TqHX3s4jzBMk(u"ࡘࡷࡻࡥᄾ")
			else: b8aHKFJ9V5XWI2YwSi6uemxBrqM = AjPUXmefr7iaqMdVO6uCnt[jx7s8T0BFgODXLMzIYedf(u"ࠪࡹࡷࡲࠧช")]
			BmsWvrytaKL768CA32xTkeqJRhldf = LsZcexz79EkSgw2RP[GOtNfU3xQFkEhPouwA-hbd4AitlZpgYF1]
			break
	if not sqOVnaRDT6oFp: UQt86XuEy1igWn = b8aHKFJ9V5XWI2YwSi6uemxBrqM
	else: UQt86XuEy1igWn = BoWHNb9daQVCF16A(u"࡛ࠫ࡯ࡤࡦࡱ࠽ࠤࠬซ")+AjPUXmefr7iaqMdVO6uCnt[jx7s8T0BFgODXLMzIYedf(u"ࠬࡻࡲ࡭ࠩฌ")]+sRth5giAQzWlEVm7JOX(u"࠭ࠠࠬࠢࡄࡹࡩ࡯࡯࠻ࠢࠪญ")+Wb1dVnH0rBxA9GELpvQjY[k5dztomYyN3H(u"ࠧࡶࡴ࡯ࠫฎ")]
	if sqOVnaRDT6oFp:
		tkcBnumO1e3YxGR = int(AjPUXmefr7iaqMdVO6uCnt[C2jP0iLNGKnHu9xp(u"ࠨࡦࡸࡶࡦࡺࡩࡰࡰࠪฏ")])
		QCBnhozHlpMrj24K6GW75tc0O3 = int(Wb1dVnH0rBxA9GELpvQjY[UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠩࡧࡹࡷࡧࡴࡪࡱࡱࠫฐ")])
		LEb1HQDAeFdsrNTnVgmXo9 = str(max(tkcBnumO1e3YxGR,QCBnhozHlpMrj24K6GW75tc0O3))
		nIcWlLR7ZPwEf1rvC6obM48 = AjPUXmefr7iaqMdVO6uCnt[rbjsM8cRFiuA1(u"ࠪࡹࡷࡲࠧฑ")].replace(BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠫࠫ࠭ฒ"),UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠬࠬࡡ࡮ࡲ࠾ࠫณ"))
		JV106xdpBKgbq = Wb1dVnH0rBxA9GELpvQjY[k5dztomYyN3H(u"࠭ࡵࡳ࡮ࠪด")].replace(LgpdP3UjFRnlX(u"ࠧࠧࠩต"),T6wRistc1SCo4hqObgumK(u"ࠨࠨࡤࡱࡵࡁࠧถ"))
		mpd = UnWjVbo503mEMv9KF(u"ࠩ࠿ࡃࡽࡳ࡬ࠡࡸࡨࡶࡸ࡯࡯࡯࠿ࠥ࠵࠳࠶ࠢࠡࡧࡱࡧࡴࡪࡩ࡯ࡩࡀ࡚࡚ࠦࡆ࠮࠺ࠥࡃࡃࡢ࡮ࠨท")
		mpd += fY5wTlhtnOc0Er6sdy4k87b(u"ࠪࡀࡒࡖࡄࠡࡺࡰࡰࡳࡹ࠺ࡹࡵ࡬ࡁࠧ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰ࡺ࠷࠳ࡵࡲࡨ࠱࠵࠴࠵࠷࠯࡙ࡏࡏࡗࡨ࡮ࡥ࡮ࡣ࠰࡭ࡳࡹࡴࡢࡰࡦࡩࠧࠦࡸ࡮࡮ࡱࡷࡂࠨࡵࡳࡰ࠽ࡱࡵ࡫ࡧ࠻ࡦࡤࡷ࡭ࡀࡳࡤࡪࡨࡱࡦࡀ࡭ࡱࡦ࠽࠶࠵࠷࠱ࠣࠢࡻࡱࡱࡴࡳ࠻ࡺ࡯࡭ࡳࡱ࠽ࠣࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳ࡽ࠳࠯ࡱࡵ࡫࠴࠷࠹࠺࠻࠲ࡼࡱ࡯࡮࡬ࠤࠣࡼࡸ࡯࠺ࡴࡥ࡫ࡩࡲࡧࡌࡰࡥࡤࡸ࡮ࡵ࡮࠾ࠤࡸࡶࡳࡀ࡭ࡱࡧࡪ࠾ࡩࡧࡳࡩ࠼ࡶࡧ࡭࡫࡭ࡢ࠼ࡰࡴࡩࡀ࠲࠱࠳࠴ࠤ࡭ࡺࡴࡱ࠼࠲࠳ࡸࡺࡡ࡯ࡦࡤࡶࡩࡹ࠮ࡪࡵࡲ࠲ࡴࡸࡧ࠰࡫ࡷࡸ࡫࠵ࡐࡶࡤ࡯࡭ࡨࡲࡹࡂࡸࡤ࡭ࡱࡧࡢ࡭ࡧࡖࡸࡦࡴࡤࡢࡴࡧࡷ࠴ࡓࡐࡆࡉ࠰ࡈࡆ࡙ࡈࡠࡵࡦ࡬ࡪࡳࡡࡠࡨ࡬ࡰࡪࡹ࠯ࡅࡃࡖࡌ࠲ࡓࡐࡅ࠰ࡻࡷࡩࠨࠠ࡮࡫ࡱࡆࡺ࡬ࡦࡦࡴࡗ࡭ࡲ࡫࠽ࠣࡒࡗ࠵࠳࠻ࡓࠣࠢࡰࡩࡩ࡯ࡡࡑࡴࡨࡷࡪࡴࡴࡢࡶ࡬ࡳࡳࡊࡵࡳࡣࡷ࡭ࡴࡴ࠽ࠣࡒࡗࠫธ")+LEb1HQDAeFdsrNTnVgmXo9+PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠫࡘࠨࠠࡵࡻࡳࡩࡂࠨࡳࡵࡣࡷ࡭ࡨࠨࠠࡱࡴࡲࡪ࡮ࡲࡥࡴ࠿ࠥࡹࡷࡴ࠺࡮ࡲࡨ࡫࠿ࡪࡡࡴࡪ࠽ࡴࡷࡵࡦࡪ࡮ࡨ࠾࡮ࡹ࡯ࡧࡨ࠰ࡱࡦ࡯࡮࠻࠴࠳࠵࠶ࠨ࠾࡝ࡰࠪน")
		mpd += FGDJwkEbTB5SoXujs3f(u"ࠬࡂࡐࡦࡴ࡬ࡳࡩࡄ࡜࡯ࠩบ")
		mpd += UnWjVbo503mEMv9KF(u"࠭࠼ࡂࡦࡤࡴࡹࡧࡴࡪࡱࡱࡗࡪࡺࠠࡪࡦࡀࠦ࠵ࠨࠠ࡮࡫ࡰࡩ࡙ࡿࡰࡦ࠿ࠥࡺ࡮ࡪࡥࡰ࠱ࠪป")+AjPUXmefr7iaqMdVO6uCnt[V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩผ")]+jSu5Cg2Ub1OAkZVs8Yoz(u"ࠨࠤࠣࡷࡺࡨࡳࡦࡩࡰࡩࡳࡺࡁ࡭࡫ࡪࡲࡲ࡫࡮ࡵ࠿ࠥࡸࡷࡻࡥࠣࡀ࡟ࡲࠬฝ")
		mpd += b05yftsZ6NYgIKP(u"ࠩ࠿ࡖࡴࡲࡥࠡࡵࡦ࡬ࡪࡳࡥࡊࡦࡘࡶ࡮ࡃࠢࡶࡴࡱ࠾ࡲࡶࡥࡨ࠼ࡇࡅࡘࡎ࠺ࡳࡱ࡯ࡩ࠿࠸࠰࠲࠳ࠥࠤࡻࡧ࡬ࡶࡧࡀࠦࡲࡧࡩ࡯ࠤ࠲ࡂࡡࡴࠧพ")
		mpd += qbPw1d3KimF(u"ࠪࡀࡗ࡫ࡰࡳࡧࡶࡩࡳࡺࡡࡵ࡫ࡲࡲࠥ࡯ࡤ࠾ࠤࠪฟ")+AjPUXmefr7iaqMdVO6uCnt[RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠫ࡮ࡺࡡࡨࠩภ")]+C2dgEDAKQGsvh(u"ࠬࠨࠠࡤࡱࡧࡩࡨࡹ࠽ࠣࠩม")+AjPUXmefr7iaqMdVO6uCnt[C2dgEDAKQGsvh(u"࠭ࡣࡰࡦࡨࡧࡸ࠭ย")]+BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠧࠣࠢࡶࡸࡦࡸࡴࡘ࡫ࡷ࡬ࡘࡇࡐ࠾ࠤ࠴ࠦࠥࡨࡡ࡯ࡦࡺ࡭ࡩࡺࡨ࠾ࠤࠪร")+str(AjPUXmefr7iaqMdVO6uCnt[k5dztomYyN3H(u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩฤ")])+NVS30xAdRFMIw1n9CislkE2(u"ࠩࠥࠤࡼ࡯ࡤࡵࡪࡀࠦࠬล")+str(AjPUXmefr7iaqMdVO6uCnt[qbPw1d3KimF(u"ࠪࡻ࡮ࡪࡴࡩࠩฦ")])+vvHpKfcqRnrFzjG(u"ࠫࠧࠦࡨࡦ࡫ࡪ࡬ࡹࡃࠢࠨว")+str(AjPUXmefr7iaqMdVO6uCnt[LgpdP3UjFRnlX(u"ࠬ࡮ࡥࡪࡩ࡫ࡸࠬศ")])+C2dgEDAKQGsvh(u"࠭ࠢࠡࡨࡵࡥࡲ࡫ࡒࡢࡶࡨࡁࠧ࠭ษ")+AjPUXmefr7iaqMdVO6uCnt[jx7s8T0BFgODXLMzIYedf(u"ࠧࡧࡲࡶࠫส")]+jx7s8T0BFgODXLMzIYedf(u"ࠨࠤࡁࡠࡳ࠭ห")
		mpd += BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠩ࠿ࡆࡦࡹࡥࡖࡔࡏࡂࠬฬ")+nIcWlLR7ZPwEf1rvC6obM48+BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠪࡀ࠴ࡈࡡࡴࡧࡘࡖࡑࡄ࡜࡯ࠩอ")
		mpd += NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠫࡁ࡙ࡥࡨ࡯ࡨࡲࡹࡈࡡࡴࡧࠣ࡭ࡳࡪࡥࡹࡔࡤࡲ࡬࡫࠽ࠣࠩฮ")+AjPUXmefr7iaqMdVO6uCnt[FGDJwkEbTB5SoXujs3f(u"ࠬ࡯࡮ࡥࡧࡻࠫฯ")]+FGDJwkEbTB5SoXujs3f(u"࠭ࠢ࠿࡞ࡱࠫะ")
		mpd += NVS30xAdRFMIw1n9CislkE2(u"ࠧ࠽ࡋࡱ࡭ࡹ࡯ࡡ࡭࡫ࡽࡥࡹ࡯࡯࡯ࠢࡵࡥࡳ࡭ࡥ࠾ࠤࠪั")+AjPUXmefr7iaqMdVO6uCnt[l0WAe1f7Bpi5ZXk(u"ࠨ࡫ࡱ࡭ࡹ࠭า")]+jSu5Cg2Ub1OAkZVs8Yoz(u"ࠩࠥࠤ࠴ࡄ࡜࡯ࠩำ")
		mpd += hhlbF1Sns5TrEN8QPCYmL4(u"ࠪࡀ࠴࡙ࡥࡨ࡯ࡨࡲࡹࡈࡡࡴࡧࡁࡠࡳ࠭ิ")
		mpd += b05yftsZ6NYgIKP(u"ࠫࡁ࠵ࡒࡦࡲࡵࡩࡸ࡫࡮ࡵࡣࡷ࡭ࡴࡴ࠾࡝ࡰࠪี")
		mpd += EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠬࡂ࠯ࡂࡦࡤࡴࡹࡧࡴࡪࡱࡱࡗࡪࡺ࠾࡝ࡰࠪึ")
		mpd += l0WAe1f7Bpi5ZXk(u"࠭࠼ࡂࡦࡤࡴࡹࡧࡴࡪࡱࡱࡗࡪࡺࠠࡪࡦࡀࠦ࠶ࠨࠠ࡮࡫ࡰࡩ࡙ࡿࡰࡦ࠿ࠥࡥࡺࡪࡩࡰ࠱ࠪื")+Wb1dVnH0rBxA9GELpvQjY[FGDJwkEbTB5SoXujs3f(u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦุࠩ")]+jSu5Cg2Ub1OAkZVs8Yoz(u"ࠨࠤࠣࡷࡺࡨࡳࡦࡩࡰࡩࡳࡺࡁ࡭࡫ࡪࡲࡲ࡫࡮ࡵ࠿ࠥࡸࡷࡻࡥࠣࡀ࡟ࡲูࠬ")
		mpd += nr5mZG89ICi6cgt4MfLJa0(u"ࠩ࠿ࡖࡴࡲࡥࠡࡵࡦ࡬ࡪࡳࡥࡊࡦࡘࡶ࡮ࡃࠢࡶࡴࡱ࠾ࡲࡶࡥࡨ࠼ࡇࡅࡘࡎ࠺ࡳࡱ࡯ࡩ࠿࠸࠰࠲࠳ࠥࠤࡻࡧ࡬ࡶࡧࡀࠦࡲࡧࡩ࡯ࠤ࠲ࡂࡡࡴฺࠧ")
		mpd += gItVahxL0w(u"ࠪࡀࡗ࡫ࡰࡳࡧࡶࡩࡳࡺࡡࡵ࡫ࡲࡲࠥ࡯ࡤ࠾ࠤࠪ฻")+Wb1dVnH0rBxA9GELpvQjY[fY5wTlhtnOc0Er6sdy4k87b(u"ࠫ࡮ࡺࡡࡨࠩ฼")]+UnWjVbo503mEMv9KF(u"ࠬࠨࠠࡤࡱࡧࡩࡨࡹ࠽ࠣࠩ฽")+Wb1dVnH0rBxA9GELpvQjY[hhlbF1Sns5TrEN8QPCYmL4(u"࠭ࡣࡰࡦࡨࡧࡸ࠭฾")]+RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠧࠣࠢࡥࡥࡳࡪࡷࡪࡦࡷ࡬ࡂࠨ࠱࠴࠲࠷࠻࠺ࠨ࠾࡝ࡰࠪ฿")
		mpd += hhlbF1Sns5TrEN8QPCYmL4(u"ࠨ࠾ࡄࡹࡩ࡯࡯ࡄࡪࡤࡲࡳ࡫࡬ࡄࡱࡱࡪ࡮࡭ࡵࡳࡣࡷ࡭ࡴࡴࠠࡴࡥ࡫ࡩࡲ࡫ࡉࡥࡗࡵ࡭ࡂࠨࡵࡳࡰ࠽ࡱࡵ࡫ࡧ࠻ࡦࡤࡷ࡭ࡀ࠲࠴࠲࠳࠷࠿࠹࠺ࡢࡷࡧ࡭ࡴࡥࡣࡩࡣࡱࡲࡪࡲ࡟ࡤࡱࡱࡪ࡮࡭ࡵࡳࡣࡷ࡭ࡴࡴ࠺࠳࠲࠴࠵ࠧࠦࡶࡢ࡮ࡸࡩࡂࠨࠧเ")+Wb1dVnH0rBxA9GELpvQjY[fY5wTlhtnOc0Er6sdy4k87b(u"ࠩࡤࡹࡩ࡯࡯ࡠࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠪแ")]+BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠪࠦ࠴ࡄ࡜࡯ࠩโ")
		mpd += WMkAjB1RgN7q(u"ࠫࡁࡈࡡࡴࡧࡘࡖࡑࡄࠧใ")+JV106xdpBKgbq+jx7s8T0BFgODXLMzIYedf(u"ࠬࡂ࠯ࡃࡣࡶࡩ࡚ࡘࡌ࠿࡞ࡱࠫไ")
		mpd += YB5xyI7MaRslVpv(u"࠭࠼ࡔࡧࡪࡱࡪࡴࡴࡃࡣࡶࡩࠥ࡯࡮ࡥࡧࡻࡖࡦࡴࡧࡦ࠿ࠥࠫๅ")+Wb1dVnH0rBxA9GELpvQjY[FGDJwkEbTB5SoXujs3f(u"ࠧࡪࡰࡧࡩࡽ࠭ๆ")]+V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠨࠤࡁࡠࡳ࠭็")
		mpd += YB5xyI7MaRslVpv(u"ࠩ࠿ࡍࡳ࡯ࡴࡪࡣ࡯࡭ࡿࡧࡴࡪࡱࡱࠤࡷࡧ࡮ࡨࡧࡀ่ࠦࠬ")+Wb1dVnH0rBxA9GELpvQjY[nr5mZG89ICi6cgt4MfLJa0(u"ࠪ࡭ࡳ࡯ࡴࠨ้")]+jSu5Cg2Ub1OAkZVs8Yoz(u"ࠫࠧࠦ࠯࠿࡞ࡱ๊ࠫ")
		mpd += k5dztomYyN3H(u"ࠬࡂ࠯ࡔࡧࡪࡱࡪࡴࡴࡃࡣࡶࡩࡃࡢ࡮ࠨ๋")
		mpd += V2RbfGOBdcA6l8NTsPWzEyvS7(u"࠭࠼࠰ࡔࡨࡴࡷ࡫ࡳࡦࡰࡷࡥࡹ࡯࡯࡯ࡀ࡟ࡲࠬ์")
		mpd += BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠧ࠽࠱ࡄࡨࡦࡶࡴࡢࡶ࡬ࡳࡳ࡙ࡥࡵࡀ࡟ࡲࠬํ")
		mpd += WMkAjB1RgN7q(u"ࠨ࠾࠲ࡔࡪࡸࡩࡰࡦࡁࡠࡳ࠭๎")
		mpd += jx7s8T0BFgODXLMzIYedf(u"ࠩ࠿࠳ࡒࡖࡄ࠿࡞ࡱࠫ๏")
		if BLz7m2RkNrxXQwy1cGAp:
			import http.server as E6JK9RpQoWtxZ
			import http.client as dg1GufVwAMXH2lF96tZqUQ3jb45
		else:
			import BaseHTTPServer as E6JK9RpQoWtxZ
			import httplib as dg1GufVwAMXH2lF96tZqUQ3jb45
		class Mjthfz8iTvdecIFSl(E6JK9RpQoWtxZ.HTTPServer):
			def __init__(ooSGpJPmzf,ip=l0WAe1f7Bpi5ZXk(u"ࠪࡰࡴࡩࡡ࡭ࡪࡲࡷࡹ࠭๐"),port=LgpdP3UjFRnlX(u"࠹࠺࠶࠵࠶႖"),mpd=EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠫࡁࡄࠧ๑")):
				ooSGpJPmzf.ip = ip
				ooSGpJPmzf.port = port
				ooSGpJPmzf.mpd = mpd
				E6JK9RpQoWtxZ.HTTPServer.__init__(ooSGpJPmzf,(ooSGpJPmzf.ip,ooSGpJPmzf.port),pe8SCyTcA4xl9F0m6rs7DGOZivE12B)
				ooSGpJPmzf.mpdurl = sRth5giAQzWlEVm7JOX(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠭๒")+ip+NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠭࠺ࠨ๓")+str(port)+BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠧ࠰ࡻࡲࡹࡹࡻࡢࡦ࠰ࡰࡴࡩ࠭๔")
			def start(ooSGpJPmzf):
				ooSGpJPmzf.threads = AuHy92xSpftDB8R(v5EA6TqHX3s4jzBMk(u"ࡋࡧ࡬ࡴࡧᄿ"))
				ooSGpJPmzf.threads.Tkf6RY1UXJwNhHsgK(k5dztomYyN3H(u"࠶႗"),ooSGpJPmzf.MUTpuEsfCgS2VXN5WOJZrL4dHiIo)
			def MUTpuEsfCgS2VXN5WOJZrL4dHiIo(ooSGpJPmzf):
				ooSGpJPmzf.keeprunning = rbjsM8cRFiuA1(u"࡚ࡲࡶࡧᅀ")
				while ooSGpJPmzf.keeprunning:
					ooSGpJPmzf.handle_request()
			def stop(ooSGpJPmzf):
				ooSGpJPmzf.keeprunning = hhlbF1Sns5TrEN8QPCYmL4(u"ࡆࡢ࡮ࡶࡩᅁ")
				ooSGpJPmzf.gENHkefT7KbV()
			def QsCHwkUuIAd(ooSGpJPmzf):
				ooSGpJPmzf.stop()
				ooSGpJPmzf.sjOCEyDLImv7.close()
				ooSGpJPmzf.server_close()
			def aZHx5SE9XPUJw1hi4nsjVrypDK(ooSGpJPmzf,mpd):
				ooSGpJPmzf.mpd = mpd
			def gENHkefT7KbV(ooSGpJPmzf):
				W9YiR1FGTdzO3jByXPA70D = dg1GufVwAMXH2lF96tZqUQ3jb45.HTTPConnection(ooSGpJPmzf.ip+v5EA6TqHX3s4jzBMk(u"ࠨ࠼ࠪ๕")+str(ooSGpJPmzf.port))
				W9YiR1FGTdzO3jByXPA70D.request(vvHpKfcqRnrFzjG(u"ࠤࡋࡉࡆࡊࠢ๖"), hhlbF1Sns5TrEN8QPCYmL4(u"ࠥ࠳ࠧ๗"))
		class pe8SCyTcA4xl9F0m6rs7DGOZivE12B(E6JK9RpQoWtxZ.BaseHTTPRequestHandler):
			def sIZTlwWEr27vNUio(ooSGpJPmzf):
				ooSGpJPmzf.send_response(k5dztomYyN3H(u"࠸࠰࠱႘"))
				ooSGpJPmzf.send_header(FGDJwkEbTB5SoXujs3f(u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲ࡺࡹࡱࡧࠪ๘"),jx7s8T0BFgODXLMzIYedf(u"ࠬࡺࡥࡹࡶࡷ࠳ࡵࡲࡡࡪࡰࠪ๙"))
				ooSGpJPmzf.end_headers()
				ooSGpJPmzf.wfile.write(ooSGpJPmzf.LkVZrOE4XBSN2Qex5PyHqC.mpd.encode(gItVahxL0w(u"࠭ࡵࡵࡨ࠻ࠫ๚")))
				KBxPW9cX8dqtaUDG.sleep(V2RbfGOBdcA6l8NTsPWzEyvS7(u"࠱႙"))
				if ooSGpJPmzf.path==C2jP0iLNGKnHu9xp(u"ࠧ࠰ࡻࡲࡹࡹࡻࡢࡦ࠰ࡰࡴࡩ࠭๛"): ooSGpJPmzf.LkVZrOE4XBSN2Qex5PyHqC.QsCHwkUuIAd()
				if ooSGpJPmzf.path==l0WAe1f7Bpi5ZXk(u"ࠨ࠱ࡶ࡬ࡺࡺࡤࡰࡹࡱࠫ๜"): ooSGpJPmzf.LkVZrOE4XBSN2Qex5PyHqC.QsCHwkUuIAd()
			def j9vFo70XPkGhcxNd3b(ooSGpJPmzf):
				ooSGpJPmzf.send_response(EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠳࠲࠳ႚ"))
				ooSGpJPmzf.end_headers()
		fG1vtSko9Dnig = Mjthfz8iTvdecIFSl(UnWjVbo503mEMv9KF(u"ࠩ࠴࠶࠼࠴࠰࠯࠲࠱࠵ࠬ๝"),UxS67uoGThbMwnfNRzy4gajLd23JH(u"࠷࠸࠴࠺࠻ႛ"),mpd)
		b8aHKFJ9V5XWI2YwSi6uemxBrqM = fG1vtSko9Dnig.mpdurl
		fG1vtSko9Dnig.start()
	else: fG1vtSko9Dnig = NVS30xAdRFMIw1n9CislkE2(u"ࠪࠫ๞")
	if not b8aHKFJ9V5XWI2YwSi6uemxBrqM: return fY5wTlhtnOc0Er6sdy4k87b(u"ࠫࡊࡸࡲࡰࡴࠣࠤࠥࠦ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣ࡝ࡔ࡛ࡔࡖࡄࡈࠤࡋࡧࡩ࡭ࡧࡧࠫ๟"),[],[]
	return l0WAe1f7Bpi5ZXk(u"ࠬ࠭๠"),[FGDJwkEbTB5SoXujs3f(u"࠭ࠧ๡")],[[b8aHKFJ9V5XWI2YwSi6uemxBrqM,f6zJ3voP0lsySUguQOM8HNpA,fG1vtSko9Dnig]]
def IRLc49Auh1ngx(url):
	headers = { QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ๢") : UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠨࠩ๣") }
	MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(f9Oum6c0FotxYn,url,NVS30xAdRFMIw1n9CislkE2(u"ࠩࠪ๤"),headers,jSu5Cg2Ub1OAkZVs8Yoz(u"ࠪࠫ๥"),C2dgEDAKQGsvh(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡗࡋࡇࡆࡔࡈ࠭࠲ࡵࡷࠫ๦"))
	items = My7Dwqvs6bfGNSIgX.findall(v5EA6TqHX3s4jzBMk(u"ࠬ࡬ࡩ࡭ࡧ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠬ࠱ࡲࡡࡣࡧ࡯࠾ࠧ࠮࠮ࠫࡁࠬࠦࢁ࠯࡜ࡾࠩ๧"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	items = set(items)
	items = sorted(items, reverse=PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࡕࡴࡸࡩᅂ"), key=lambda key: key[nr5mZG89ICi6cgt4MfLJa0(u"࠵ႜ")])
	ebHN2cVyxIRKsuzk0L3,wlfZEzuRyYLvrp,e1dn7APL6DyaMuchQkG2EI5jSY,QQ2cE1FjUyxPonbDhaTkV6B3i = [],[],[],[]
	if not items: return RqldvxFuM5GEQ2HAz93o7afBb0(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡘࡌࡈࡇࡕࡂࠨ๨"),[],[]
	for BoEFz2WhUyvTgDeiZ,wLWTRZQNlpACcvdFU3Vo,GDL3q5vFjwIVrM2ElRZNd in items:
		BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ.replace(BoWHNb9daQVCF16A(u"ࠧࡩࡶࡷࡴࡸࡀࠧ๩"),jx7s8T0BFgODXLMzIYedf(u"ࠨࡪࡷࡸࡵࡀࠧ๪"))
		if NVS30xAdRFMIw1n9CislkE2(u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨ๫") in BoEFz2WhUyvTgDeiZ:
			ebHN2cVyxIRKsuzk0L3,e1dn7APL6DyaMuchQkG2EI5jSY = cChyAEtdaMvNXsurWwnSeBzFU2m(BoEFz2WhUyvTgDeiZ)
			QQ2cE1FjUyxPonbDhaTkV6B3i = QQ2cE1FjUyxPonbDhaTkV6B3i + e1dn7APL6DyaMuchQkG2EI5jSY
			if ebHN2cVyxIRKsuzk0L3[jx7s8T0BFgODXLMzIYedf(u"࠴ႝ")]==rbjsM8cRFiuA1(u"ࠪ࠱࠶࠭๬"): wlfZEzuRyYLvrp.append(C2dgEDAKQGsvh(u"ุࠫ๐ัโำࠣาฬ฻ࠧ๭")+v5EA6TqHX3s4jzBMk(u"ࠬࠦࠠࠡ࡯࠶ࡹ࠽࠭๮"))
			else:
				for title in ebHN2cVyxIRKsuzk0L3:
					wlfZEzuRyYLvrp.append(NVS30xAdRFMIw1n9CislkE2(u"࠭ำ๋ำไีࠥิวึࠩ๯")+RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠧࠡࠢࠣࠫ๰")+title)
		else:
			title = LgpdP3UjFRnlX(u"ࠨีํีๆืࠠฯษุࠫ๱")+WMkAjB1RgN7q(u"ࠩࠣࠤࠥࡳࡰ࠵ࠢࠣࠤࠬ๲")+GDL3q5vFjwIVrM2ElRZNd
			QQ2cE1FjUyxPonbDhaTkV6B3i.append(BoEFz2WhUyvTgDeiZ)
			wlfZEzuRyYLvrp.append(title)
	return C2jP0iLNGKnHu9xp(u"ࠪࠫ๳"),wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i
def R8y0kQhOcgX(url,MK6ZT2zjC1SbmveNFqor):
	breQmB38nWlfEc6CNT,Qki8AbTHYjzM2Ls76Gdr3eqo1Wn,EAWZTX0U8SHrxsfNQ4,rr6pcuETVCl9oqeX,NVHrZsqUp2 = [],[],[],[],[]
	BoEFz2WhUyvTgDeiZ = My7Dwqvs6bfGNSIgX.findall(vvHpKfcqRnrFzjG(u"ࠫࡁࡼࡩࡥࡧࡲࠤࡵࡸࡥ࡭ࡱࡤࡨ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ๴"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if BoEFz2WhUyvTgDeiZ and not REGCdFbgy4Vvu2ieLqNMlxntY(BoEFz2WhUyvTgDeiZ[nr5mZG89ICi6cgt4MfLJa0(u"࠵႞")]): BoEFz2WhUyvTgDeiZ = []
	if not BoEFz2WhUyvTgDeiZ: BoEFz2WhUyvTgDeiZ = My7Dwqvs6bfGNSIgX.findall(jx7s8T0BFgODXLMzIYedf(u"ࠬࡂࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ๵"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if BoEFz2WhUyvTgDeiZ and not REGCdFbgy4Vvu2ieLqNMlxntY(BoEFz2WhUyvTgDeiZ[sRth5giAQzWlEVm7JOX(u"࠶႟")]): BoEFz2WhUyvTgDeiZ = []
	if not BoEFz2WhUyvTgDeiZ: BoEFz2WhUyvTgDeiZ = My7Dwqvs6bfGNSIgX.findall(qbPw1d3KimF(u"࠭ࡤࡪࡴࡨࡧࡹࡥ࡬ࡪࡰ࡮࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ๶"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if BoEFz2WhUyvTgDeiZ and not REGCdFbgy4Vvu2ieLqNMlxntY(BoEFz2WhUyvTgDeiZ[UnWjVbo503mEMv9KF(u"࠰Ⴀ")]): BoEFz2WhUyvTgDeiZ = []
	if BoEFz2WhUyvTgDeiZ:
		BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ[BoWHNb9daQVCF16A(u"࠱Ⴁ")]
		title = BoEFz2WhUyvTgDeiZ.rsplit(BoWHNb9daQVCF16A(u"ࠧ࠯ࠩ๷"),b05yftsZ6NYgIKP(u"࠳Ⴂ"))[b05yftsZ6NYgIKP(u"࠳Ⴂ")]
		breQmB38nWlfEc6CNT.append(title)
		Qki8AbTHYjzM2Ls76Gdr3eqo1Wn.append(BoEFz2WhUyvTgDeiZ)
	else:
		xAcIatGBYy0FLXroS1ig3Ts9KZ8P5 = My7Dwqvs6bfGNSIgX.findall(qbPw1d3KimF(u"ࠨࡵࡲࡹࡷࡩࡥࡴ࠼ࠣ࠮࠭ࡢ࡛࠯ࠬࡂࡠࡢ࠯ࠧ๸"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if not xAcIatGBYy0FLXroS1ig3Ts9KZ8P5: xAcIatGBYy0FLXroS1ig3Ts9KZ8P5 = My7Dwqvs6bfGNSIgX.findall(rbjsM8cRFiuA1(u"ࠩࡹࡥࡷࠦࡳࡰࡷࡵࡧࡪࡹࠠ࠾ࠢࠫࡠࢀ࠴ࠪࡀ࡞ࢀ࠭ࠬ๹"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if not xAcIatGBYy0FLXroS1ig3Ts9KZ8P5: xAcIatGBYy0FLXroS1ig3Ts9KZ8P5 = My7Dwqvs6bfGNSIgX.findall(EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠪࡺࡦࡸࠠ࡫ࡹࠣࡁࠥ࠮࡜ࡼ࠰࠭ࡃࡡࢃࠩࠨ๺"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if not xAcIatGBYy0FLXroS1ig3Ts9KZ8P5: xAcIatGBYy0FLXroS1ig3Ts9KZ8P5 = My7Dwqvs6bfGNSIgX.findall(jSu5Cg2Ub1OAkZVs8Yoz(u"ࠫࡻࡧࡲࠡࡲ࡯ࡥࡾ࡫ࡲࠡ࠿ࠣ࠲࠯ࡅ࡜ࠩࠪ࡟ࡿ࠳࠰࠿࡝ࡿࠬࡠ࠮࠭๻"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if xAcIatGBYy0FLXroS1ig3Ts9KZ8P5:
			xAcIatGBYy0FLXroS1ig3Ts9KZ8P5 = xAcIatGBYy0FLXroS1ig3Ts9KZ8P5[jSu5Cg2Ub1OAkZVs8Yoz(u"࠳Ⴃ")]
			xAcIatGBYy0FLXroS1ig3Ts9KZ8P5 = My7Dwqvs6bfGNSIgX.sub(QynMHGWA0blfqTUdxRh5Jzi2t(u"ࡷ࠭ࠨ࡜࡞ࡾࡠ࠱ࡣ࡛࡝ࡶ࡟ࡷࡡࡴ࡜ࡳ࡟࠭࠭࠭ࡢࡷࠬ࡝࡟ࡸࡡࡹ࡝ࠫࠫ࠽ࠫ๼"),PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࡸࠧ࡝࠳ࠥࡠ࠷ࠨ࠺ࠨ๽"),xAcIatGBYy0FLXroS1ig3Ts9KZ8P5)
			xAcIatGBYy0FLXroS1ig3Ts9KZ8P5 = dWsa2A0O4o5BYiqGXhyKEbM(NVS30xAdRFMIw1n9CislkE2(u"ࠧࡥ࡫ࡦࡸࠬ๾"),xAcIatGBYy0FLXroS1ig3Ts9KZ8P5)
			if isinstance(xAcIatGBYy0FLXroS1ig3Ts9KZ8P5,dict): xAcIatGBYy0FLXroS1ig3Ts9KZ8P5 = [xAcIatGBYy0FLXroS1ig3Ts9KZ8P5]
			for vsptNMP2ZQC in xAcIatGBYy0FLXroS1ig3Ts9KZ8P5:
				zl3fbr91uaMyCx,BoEFz2WhUyvTgDeiZ = EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠨࠩ๿"),qbPw1d3KimF(u"ࠩࠪ຀")
				if isinstance(vsptNMP2ZQC,dict):
					keys = list(vsptNMP2ZQC.keys())
					if   FGDJwkEbTB5SoXujs3f(u"ࠪࡸࡾࡶࡥࠨກ") in keys: zl3fbr91uaMyCx = str(vsptNMP2ZQC[YB5xyI7MaRslVpv(u"ࠫࡹࡿࡰࡦࠩຂ")])
					if   EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠬ࡬ࡩ࡭ࡧࠪ຃") in keys: BoEFz2WhUyvTgDeiZ = vsptNMP2ZQC[fY5wTlhtnOc0Er6sdy4k87b(u"࠭ࡦࡪ࡮ࡨࠫຄ")]
					elif T6wRistc1SCo4hqObgumK(u"ࠧࡩ࡮ࡶࠫ຅") in keys: BoEFz2WhUyvTgDeiZ = vsptNMP2ZQC[EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠨࡪ࡯ࡷࠬຆ")]
					elif QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠩࡶࡶࡨ࠭ງ") in keys: BoEFz2WhUyvTgDeiZ = vsptNMP2ZQC[b05yftsZ6NYgIKP(u"ࠪࡷࡷࡩࠧຈ")]
					if   v5EA6TqHX3s4jzBMk(u"ࠫࡱࡧࡢࡦ࡮ࠪຉ") in keys: title = str(vsptNMP2ZQC[QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠬࡲࡡࡣࡧ࡯ࠫຊ")])
					elif hhlbF1Sns5TrEN8QPCYmL4(u"࠭ࡶࡪࡦࡨࡳࡤ࡮ࡥࡪࡩ࡫ࡸࠬ຋") in keys: title = str(vsptNMP2ZQC[gItVahxL0w(u"ࠧࡷ࡫ࡧࡩࡴࡥࡨࡦ࡫ࡪ࡬ࡹ࠭ຌ")])
					else: title = BoEFz2WhUyvTgDeiZ.rsplit(BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠨ࠰ࠪຍ"),jx7s8T0BFgODXLMzIYedf(u"࠵Ⴄ"))[jx7s8T0BFgODXLMzIYedf(u"࠵Ⴄ")]
				elif isinstance(vsptNMP2ZQC,str):
					BoEFz2WhUyvTgDeiZ = vsptNMP2ZQC
					title = BoEFz2WhUyvTgDeiZ.rsplit(EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠩ࠱ࠫຎ"),hhlbF1Sns5TrEN8QPCYmL4(u"࠶Ⴅ"))[hhlbF1Sns5TrEN8QPCYmL4(u"࠶Ⴅ")]
				if C2jP0iLNGKnHu9xp(u"࠷Ⴆ"):
					breQmB38nWlfEc6CNT.append(title+BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠪࠤࠥ࠭ຏ")+zl3fbr91uaMyCx)
					Qki8AbTHYjzM2Ls76Gdr3eqo1Wn.append(BoEFz2WhUyvTgDeiZ)
	for BoEFz2WhUyvTgDeiZ,title in zip(Qki8AbTHYjzM2Ls76Gdr3eqo1Wn,breQmB38nWlfEc6CNT):
		BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ.replace(qbPw1d3KimF(u"ࠫࡡࡢ࠯ࠨຐ"),QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠬ࠵ࠧຑ"))
		LkVZrOE4XBSN2Qex5PyHqC = ooq2D9xF8ZLpPBs(url,l0WAe1f7Bpi5ZXk(u"࠭ࡵࡳ࡮ࠪຒ"))
		rHqkc3e0CJ5VByi6vLs = IeSGolOpBHM8U62m()
		if PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠧࡩࡶࡷࡴࠬຓ") not in BoEFz2WhUyvTgDeiZ: BoEFz2WhUyvTgDeiZ = LkVZrOE4XBSN2Qex5PyHqC+BoEFz2WhUyvTgDeiZ
		if NVS30xAdRFMIw1n9CislkE2(u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧດ") in BoEFz2WhUyvTgDeiZ:
			headers = {NVS30xAdRFMIw1n9CislkE2(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ຕ"):rHqkc3e0CJ5VByi6vLs,C2dgEDAKQGsvh(u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫຖ"):LkVZrOE4XBSN2Qex5PyHqC}
			ZQmfM6qeVx3CX,Q9eFSKj7NqahmxgvJ8YRMfU = cChyAEtdaMvNXsurWwnSeBzFU2m(BoEFz2WhUyvTgDeiZ,headers)
			rr6pcuETVCl9oqeX += Q9eFSKj7NqahmxgvJ8YRMfU
			EAWZTX0U8SHrxsfNQ4 += ZQmfM6qeVx3CX
		else:
			BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ+l0WAe1f7Bpi5ZXk(u"ࠫࢁ࡛ࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ࠿ࠪທ")+rHqkc3e0CJ5VByi6vLs+nr5mZG89ICi6cgt4MfLJa0(u"ࠬࠬࡒࡦࡨࡨࡶࡪࡸ࠽ࠨຘ")+LkVZrOE4XBSN2Qex5PyHqC
			rr6pcuETVCl9oqeX.append(BoEFz2WhUyvTgDeiZ)
			EAWZTX0U8SHrxsfNQ4.append(title)
	ptkR1Tydzs,breQmB38nWlfEc6CNT,Qki8AbTHYjzM2Ls76Gdr3eqo1Wn = nr5mZG89ICi6cgt4MfLJa0(u"࠭ࠧນ"),[],[]
	if rr6pcuETVCl9oqeX: ptkR1Tydzs,breQmB38nWlfEc6CNT,Qki8AbTHYjzM2Ls76Gdr3eqo1Wn = FGDJwkEbTB5SoXujs3f(u"ࠧࠨບ"),EAWZTX0U8SHrxsfNQ4,rr6pcuETVCl9oqeX
	else:
		if vvHpKfcqRnrFzjG(u"ࠨ࠾ࠪປ") not in MK6ZT2zjC1SbmveNFqor and len(MK6ZT2zjC1SbmveNFqor)<QynMHGWA0blfqTUdxRh5Jzi2t(u"࠱࠱࠲Ⴇ") and MK6ZT2zjC1SbmveNFqor: ptkR1Tydzs = MK6ZT2zjC1SbmveNFqor
		else:
			msg = My7Dwqvs6bfGNSIgX.findall(UnWjVbo503mEMv9KF(u"ࠩ࠿ࡨ࡮ࡼࠠࡴࡶࡼࡰࡪࡃࠢ࠯ࠬࡂࠦࡃ࠮ࡆࡪ࡮ࡨ࠲࠯ࡅࠩ࠽ࠩຜ"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
			if not msg: msg = My7Dwqvs6bfGNSIgX.findall(C2jP0iLNGKnHu9xp(u"ࠪࡀࡩ࡯ࡶࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡸࡳࡣࡻ࡯ࡤࡦࡱࡢࡷࡹࡻࡢࡠࡶࡻࡸࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ຝ"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
			if not msg: msg = My7Dwqvs6bfGNSIgX.findall(RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠫࡁ࡮࠲࠿ࠪࡖࡳࡷࡸࡹ࠯ࠬࡂ࠭ࡁ࠭ພ"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
			if msg: ptkR1Tydzs = msg[V2RbfGOBdcA6l8NTsPWzEyvS7(u"࠱Ⴈ")]
	return ptkR1Tydzs,breQmB38nWlfEc6CNT,Qki8AbTHYjzM2Ls76Gdr3eqo1Wn
def R7qfnj3yDU8bH0p52FQX4(r3rNnGkLi9cIwy1J0ufvF,url):
	global iOG4XhAr3jzDtbTKY2csZF9a
	url = url.strip(YB5xyI7MaRslVpv(u"ࠬ࠵ࠧຟ"))
	zTxDQ1bdOZ,tWha1P9LVeuNxpQUAB = BmcLzCFjuIrZP5fwXH18aN6YS(u"࠭ࠧຠ"),{}
	headers = {gItVahxL0w(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫມ"):IeSGolOpBHM8U62m()}
	headers[NVS30xAdRFMIw1n9CislkE2(u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩຢ")] = ooq2D9xF8ZLpPBs(url,YB5xyI7MaRslVpv(u"ࠩࡸࡶࡱ࠭ຣ"))
	headers[BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠪࡅࡨࡩࡥࡱࡶ࠰ࡐࡦࡴࡧࡶࡣࡪࡩࠬ຤")] = WMkAjB1RgN7q(u"ࠫࡪࡴ࠭ࡖࡕ࠯ࡩࡳࡁࡱ࠾࠲࠱࠽ࠬລ")
	headers[fY5wTlhtnOc0Er6sdy4k87b(u"࡙ࠬࡥࡤ࠯ࡉࡩࡹࡩࡨ࠮ࡆࡨࡷࡹ࠭຦")] = LgpdP3UjFRnlX(u"࠭ࡩࡧࡴࡤࡱࡪ࠭ວ")
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(f9Oum6c0FotxYn,QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠧࡈࡇࡗࠫຨ"),url,C2jP0iLNGKnHu9xp(u"ࠨࠩຩ"),headers,vvHpKfcqRnrFzjG(u"ࠩࠪສ"),l0WAe1f7Bpi5ZXk(u"ࡈࡤࡰࡸ࡫ᅃ"),T6wRistc1SCo4hqObgumK(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡘࡔࡊࡄࡖࡎࡔࡇ࠮࠳ࡶࡸࠬຫ"))
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	TPw4M0cjln9J = xHb86g9WZqPwRfVjXD2JalzSIp.code
	if not isinstance(MK6ZT2zjC1SbmveNFqor,str): MK6ZT2zjC1SbmveNFqor = MK6ZT2zjC1SbmveNFqor.decode(BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠫࡺࡺࡦ࠹ࠩຬ"),vvHpKfcqRnrFzjG(u"ࠬ࡯ࡧ࡯ࡱࡵࡩࠬອ"))
	if WMkAjB1RgN7q(u"࠭ࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠩࡲ࠯ࡥ࠱ࡩࠬ࡬࠮ࡨ࠰ࠬຮ") in MK6ZT2zjC1SbmveNFqor:
		s6Wmzn9rJg4hfpa = My7Dwqvs6bfGNSIgX.findall(UnWjVbo503mEMv9KF(u"ࠧࠩࡧࡹࡥࡱࡢࠨࡧࡷࡱࡧࡹ࡯࡯࡯࡞ࠫࡴ࠱ࡧࠬࡤ࠮࡮࠰ࡪ࠲࡛ࡥࡴࡠ࠲࠯ࡅࠩ࠽࠱ࡶࡧࡷ࡯ࡰࡵࡀࠪຯ"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if s6Wmzn9rJg4hfpa:
			try: zTxDQ1bdOZ = t5XjI6pYbBTMdmDwxrzS9qkF(s6Wmzn9rJg4hfpa[rbjsM8cRFiuA1(u"࠲Ⴉ")])
			except: zTxDQ1bdOZ = NVS30xAdRFMIw1n9CislkE2(u"ࠨࠩະ")
	wN6n7OZBoDkTvCi8LdbJjYV = MK6ZT2zjC1SbmveNFqor+zTxDQ1bdOZ
	if C2dgEDAKQGsvh(u"ࠩࠥ࡭ࡩ࠸ࠢࠨັ") in wN6n7OZBoDkTvCi8LdbJjYV or jx7s8T0BFgODXLMzIYedf(u"ࠪࠦ࡮ࡪࠢࠨາ") in wN6n7OZBoDkTvCi8LdbJjYV:
		K5tJ4OBU3Yo = url.split(EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠫ࠴࠭ຳ"))[hhlbF1Sns5TrEN8QPCYmL4(u"࠶Ⴊ")].replace(NVS30xAdRFMIw1n9CislkE2(u"ࠬ࡫࡭ࡣࡧࡧ࠱ࠬິ"),FGDJwkEbTB5SoXujs3f(u"࠭ࠧີ")).replace(qbPw1d3KimF(u"ࠧ࠯ࡪࡷࡱࡱ࠭ຶ"),FGDJwkEbTB5SoXujs3f(u"ࠨࠩື"))
		if T6wRistc1SCo4hqObgumK(u"ࠩࠥ࡭ࡩ࠸ࠢࠨຸ") in wN6n7OZBoDkTvCi8LdbJjYV: tWha1P9LVeuNxpQUAB = {v5EA6TqHX3s4jzBMk(u"ࠪ࡭ࡩ࠸ູࠧ"):K5tJ4OBU3Yo,sRth5giAQzWlEVm7JOX(u"ࠫࡴࡶ຺ࠧ"):sRth5giAQzWlEVm7JOX(u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠲ࠨົ")}
		elif jSu5Cg2Ub1OAkZVs8Yoz(u"࠭ࠢࡪࡦࠥࠫຼ") in wN6n7OZBoDkTvCi8LdbJjYV: tWha1P9LVeuNxpQUAB = {UnWjVbo503mEMv9KF(u"ࠧࡪࡦࠪຽ"):K5tJ4OBU3Yo,V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠨࡱࡳࠫ຾"):v5EA6TqHX3s4jzBMk(u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧ࠶ࠬ຿")}
		eIL9BxdTbZj = headers.copy()
		eIL9BxdTbZj[YB5xyI7MaRslVpv(u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩເ")] = NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦࠪແ")
		TOzKqRwpa6WrVMH8Pxy4X = mORwgTnXBdQ7iCSHKf(f9Oum6c0FotxYn,WMkAjB1RgN7q(u"ࠬࡖࡏࡔࡖࠪໂ"),url,tWha1P9LVeuNxpQUAB,eIL9BxdTbZj,hhlbF1Sns5TrEN8QPCYmL4(u"࠭ࠧໃ"),NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࡉࡥࡱࡹࡥᅄ"),vvHpKfcqRnrFzjG(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡜ࡘࡎࡁࡓࡋࡑࡋ࠲࠸࡮ࡥࠩໄ"))
		wN6n7OZBoDkTvCi8LdbJjYV = TOzKqRwpa6WrVMH8Pxy4X.content
	WX30vQ8cajHl1bNJ,DAu6L8v3WfzjoT27wp0PiVmhS1B,QbAdnMDXLsfyulmW = R8y0kQhOcgX(url,wN6n7OZBoDkTvCi8LdbJjYV)
	iOG4XhAr3jzDtbTKY2csZF9a[r3rNnGkLi9cIwy1J0ufvF] = WX30vQ8cajHl1bNJ,DAu6L8v3WfzjoT27wp0PiVmhS1B,QbAdnMDXLsfyulmW,TPw4M0cjln9J
	return
iOG4XhAr3jzDtbTKY2csZF9a,EH2V0JdyKXT3f4p = {},k5dztomYyN3H(u"࠴Ⴋ")
def QpY2NyZtvmRxgqsASO8wceob6W70(url):
	global iOG4XhAr3jzDtbTKY2csZF9a,EH2V0JdyKXT3f4p
	NVHrZsqUp2,threads = [],[]
	EH2V0JdyKXT3f4p += LgpdP3UjFRnlX(u"࠶࠶࠰Ⴌ")
	hKcfAyab6ViGFvPUs = EH2V0JdyKXT3f4p
	NVHrZsqUp2.append([rbjsM8cRFiuA1(u"࠷Ⴍ"),url])
	iOG4XhAr3jzDtbTKY2csZF9a[hKcfAyab6ViGFvPUs+WMkAjB1RgN7q(u"࠱Ⴎ")] = [None,None,None,None]
	unB5asTpWA1HSIxJmRczqFi37r2 = iDocG6BXv7fT2z8UVOxgP.Thread(target=R7qfnj3yDU8bH0p52FQX4,args=(hKcfAyab6ViGFvPUs+UxS67uoGThbMwnfNRzy4gajLd23JH(u"࠲Ⴏ"),url))
	unB5asTpWA1HSIxJmRczqFi37r2.start()
	unB5asTpWA1HSIxJmRczqFi37r2.join(T6wRistc1SCo4hqObgumK(u"࠳࠳Ⴐ"))
	if not iOG4XhAr3jzDtbTKY2csZF9a[hKcfAyab6ViGFvPUs+nr5mZG89ICi6cgt4MfLJa0(u"࠴Ⴑ")][V2RbfGOBdcA6l8NTsPWzEyvS7(u"࠶Ⴒ")]:
		bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = url.replace(C2dgEDAKQGsvh(u"ࠨ࠱ࡨࡱࡧ࡫ࡤ࠮ࠩ໅"),hhlbF1Sns5TrEN8QPCYmL4(u"ࠩ࠲ࠫໆ"))
		tuHzpfZmLAdCObQS2k3 = My7Dwqvs6bfGNSIgX.findall(NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠪࡢ࠭࠴ࠪࡀ࠼࠲࠳࠳࠰࠿ࠪ࠱ࠫ࠲࠯ࡅࠩ࠰ࠪ࠱࠮ࡄ࠯ࠤࠨ໇"),bJEs4IVAPdyUrhwCLv9k2YoOl8nt1+RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠫ࠴່࠭"),My7Dwqvs6bfGNSIgX.DOTALL)
		start,QX3MoEPacTAvFRi7,end = tuHzpfZmLAdCObQS2k3[YB5xyI7MaRslVpv(u"࠵Ⴓ")]
		end = end.strip(fY5wTlhtnOc0Er6sdy4k87b(u"ࠬ࠵້ࠧ"))
		KCjF4hV57A3G8EM6tczWBqmHJo = len(QX3MoEPacTAvFRi7)<nr5mZG89ICi6cgt4MfLJa0(u"࠺Ⴔ") or QX3MoEPacTAvFRi7 in [gItVahxL0w(u"࠭ࡦࡪ࡮ࡨ໊ࠫ"),BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠧࡷ࡫ࡧࡩࡴ໋࠭"),BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠨࡸ࡬ࡨࡪࡵࡥ࡮ࡤࡨࡨࠬ໌"),qbPw1d3KimF(u"ࠩࡤ࡮ࡦࡾࠧໍ"),gItVahxL0w(u"ࠪ࡭࡫ࡸࡡ࡮ࡧࠪ໎"),sRth5giAQzWlEVm7JOX(u"ࠫࡲ࡯ࡲࡳࡱࡵࠫ໏")]
		if not KCjF4hV57A3G8EM6tczWBqmHJo: NVHrZsqUp2.append([NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠲Ⴕ"),start+V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠬ࠵ࡥ࡮ࡤࡨࡨ࠲࠭໐")+QX3MoEPacTAvFRi7+PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"࠭࠯ࠨ໑")+end])
		if end: NVHrZsqUp2.append([l0WAe1f7Bpi5ZXk(u"࠴Ⴖ"),start+QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠧ࠰ࠩ໒")+QX3MoEPacTAvFRi7+nr5mZG89ICi6cgt4MfLJa0(u"ࠨ࠱ࡨࡱࡧ࡫ࡤ࠮ࠩ໓")+end])
		if b05yftsZ6NYgIKP(u"ࠩ࠱࡬ࡹࡳ࡬ࠨ໔") in QX3MoEPacTAvFRi7:
			N4pLzjoQXE0kmneSuc = QX3MoEPacTAvFRi7.replace(jx7s8T0BFgODXLMzIYedf(u"ࠪ࠲࡭ࡺ࡭࡭ࠩ໕"),BoWHNb9daQVCF16A(u"ࠫࠬ໖"))
			NVHrZsqUp2.append([YB5xyI7MaRslVpv(u"࠶Ⴗ"),start+fY5wTlhtnOc0Er6sdy4k87b(u"ࠬ࠵ࠧ໗")+N4pLzjoQXE0kmneSuc+NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠭࠯ࠨ໘")+end])
			NVHrZsqUp2.append([FGDJwkEbTB5SoXujs3f(u"࠸Ⴘ"),start+jx7s8T0BFgODXLMzIYedf(u"ࠧ࠰ࡧࡰࡦࡪࡪ࠭ࠨ໙")+N4pLzjoQXE0kmneSuc+BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠨ࠱ࠪ໚")+end])
			if end: NVHrZsqUp2.append([BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠺Ⴙ"),start+LgpdP3UjFRnlX(u"ࠩ࠲ࠫ໛")+N4pLzjoQXE0kmneSuc+BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠪ࠳ࡪࡳࡢࡦࡦ࠰ࠫໜ")+end])
		elif V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠫ࠳࡮ࡴ࡮࡮ࠪໝ") in end:
			nDMCzU4BO9a3R = end.replace(rbjsM8cRFiuA1(u"ࠬ࠴ࡨࡵ࡯࡯ࠫໞ"),jx7s8T0BFgODXLMzIYedf(u"࠭ࠧໟ"))
			NVHrZsqUp2.append([qbPw1d3KimF(u"࠼Ⴚ"),start+jx7s8T0BFgODXLMzIYedf(u"ࠧ࠰ࠩ໠")+QX3MoEPacTAvFRi7+BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠨ࠱ࠪ໡")+nDMCzU4BO9a3R])
			if not KCjF4hV57A3G8EM6tczWBqmHJo: NVHrZsqUp2.append([WMkAjB1RgN7q(u"࠾Ⴛ"),start+WMkAjB1RgN7q(u"ࠩ࠲ࡩࡲࡨࡥࡥ࠯ࠪ໢")+QX3MoEPacTAvFRi7+BoWHNb9daQVCF16A(u"ࠪ࠳ࠬ໣")+nDMCzU4BO9a3R])
			NVHrZsqUp2.append([rbjsM8cRFiuA1(u"࠹Ⴜ"),start+QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠫ࠴࠭໤")+QX3MoEPacTAvFRi7+NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠬ࠵ࡥ࡮ࡤࡨࡨ࠲࠭໥")+nDMCzU4BO9a3R])
		else:
			if not KCjF4hV57A3G8EM6tczWBqmHJo: NVHrZsqUp2.append([YB5xyI7MaRslVpv(u"࠲࠲Ⴝ"),start+BmcLzCFjuIrZP5fwXH18aN6YS(u"࠭࠯ࠨ໦")+QX3MoEPacTAvFRi7+LgpdP3UjFRnlX(u"ࠧ࠯ࡪࡷࡱࡱ࠭໧")])
			if not KCjF4hV57A3G8EM6tczWBqmHJo: NVHrZsqUp2.append([fY5wTlhtnOc0Er6sdy4k87b(u"࠳࠴Ⴞ"),start+sRth5giAQzWlEVm7JOX(u"ࠨ࠱ࡨࡱࡧ࡫ࡤ࠮ࠩ໨")+QX3MoEPacTAvFRi7+EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠩ࠱࡬ࡹࡳ࡬ࠨ໩")])
			if end: NVHrZsqUp2.append([WMkAjB1RgN7q(u"࠴࠶Ⴟ"),start+BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠪ࠳ࠬ໪")+QX3MoEPacTAvFRi7+k5dztomYyN3H(u"ࠫ࠴࠭໫")+end+QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠬ࠴ࡨࡵ࡯࡯ࠫ໬")])
			if end: NVHrZsqUp2.append([C2jP0iLNGKnHu9xp(u"࠵࠸Ⴠ"),start+PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"࠭࠯ࠨ໭")+QX3MoEPacTAvFRi7+NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠧ࠰ࡧࡰࡦࡪࡪ࠭ࠨ໮")+end+jSu5Cg2Ub1OAkZVs8Yoz(u"ࠨ࠰࡫ࡸࡲࡲࠧ໯")])
		if KCjF4hV57A3G8EM6tczWBqmHJo and end:
			end = end.replace(WMkAjB1RgN7q(u"ࠩ࠲ࡩࡲࡨࡥࡥ࠯ࠪ໰"),NVS30xAdRFMIw1n9CislkE2(u"ࠪ࠳ࠬ໱"))
			NVHrZsqUp2.append([NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠶࠺Ⴡ"),start+BoWHNb9daQVCF16A(u"ࠫ࠴࠭໲")+end])
			NVHrZsqUp2.append([v5EA6TqHX3s4jzBMk(u"࠷࠵Ⴢ"),start+UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠬ࠵ࡥ࡮ࡤࡨࡨ࠲࠭໳")+end])
			if jx7s8T0BFgODXLMzIYedf(u"࠭࠮ࡩࡶࡰࡰࠬ໴") in end:
				nDMCzU4BO9a3R = end.replace(k5dztomYyN3H(u"ࠧ࠯ࡪࡷࡱࡱ࠭໵"),BoWHNb9daQVCF16A(u"ࠨࠩ໶"))
				NVHrZsqUp2.append([NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠱࠷Ⴣ"),start+k5dztomYyN3H(u"ࠩ࠲ࠫ໷")+nDMCzU4BO9a3R])
				NVHrZsqUp2.append([T6wRistc1SCo4hqObgumK(u"࠲࠹Ⴤ"),start+V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠪ࠳ࡪࡳࡢࡦࡦ࠰ࠫ໸")+nDMCzU4BO9a3R])
			else:
				NVHrZsqUp2.append([l0WAe1f7Bpi5ZXk(u"࠳࠻Ⴥ"),start+UnWjVbo503mEMv9KF(u"ࠫ࠴࠭໹")+end+WMkAjB1RgN7q(u"ࠬ࠴ࡨࡵ࡯࡯ࠫ໺")])
				NVHrZsqUp2.append([NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠴࠽჆"),start+fY5wTlhtnOc0Er6sdy4k87b(u"࠭࠯ࡦ࡯ࡥࡩࡩ࠳ࠧ໻")+end+b05yftsZ6NYgIKP(u"ࠧ࠯ࡪࡷࡱࡱ࠭໼")])
		g0gVaNZU5tlkP = []
		for cyRC5wYOFEPj9T,BoEFz2WhUyvTgDeiZ in NVHrZsqUp2[LgpdP3UjFRnlX(u"࠵Ⴧ"):]:
			iOG4XhAr3jzDtbTKY2csZF9a[hKcfAyab6ViGFvPUs+cyRC5wYOFEPj9T] = [None,None,None,None]
			fOwIUPZrC4v1la9E7sDjzduHAe = iDocG6BXv7fT2z8UVOxgP.Thread(target=R7qfnj3yDU8bH0p52FQX4,args=(hKcfAyab6ViGFvPUs+cyRC5wYOFEPj9T,BoEFz2WhUyvTgDeiZ))
			fOwIUPZrC4v1la9E7sDjzduHAe.start()
			g0gVaNZU5tlkP.append(fOwIUPZrC4v1la9E7sDjzduHAe)
			KBxPW9cX8dqtaUDG.sleep(BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠵࠴࠷࠶჈"))
		for fOwIUPZrC4v1la9E7sDjzduHAe in g0gVaNZU5tlkP: fOwIUPZrC4v1la9E7sDjzduHAe.join(hhlbF1Sns5TrEN8QPCYmL4(u"࠷࠰჉"))
	ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = qbPw1d3KimF(u"ࠨࠩ໽"),[],[]
	ll5Qv3n72dmJuxsg9FqyYkwcbI = []
	for cyRC5wYOFEPj9T,BoEFz2WhUyvTgDeiZ in NVHrZsqUp2:
		Qt9IndGlvROCbSVYWXN1aPxh,V1V58PWa4AQnM9LEv2pseZKDkXy,lHTVXWCQwvfG,J5fKPnMqXgQtWjeSZ2uLsITNV = iOG4XhAr3jzDtbTKY2csZF9a[hKcfAyab6ViGFvPUs+cyRC5wYOFEPj9T]
		if not QQ2cE1FjUyxPonbDhaTkV6B3i and lHTVXWCQwvfG: wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = V1V58PWa4AQnM9LEv2pseZKDkXy,lHTVXWCQwvfG
		if not ptkR1Tydzs and Qt9IndGlvROCbSVYWXN1aPxh: ptkR1Tydzs = Qt9IndGlvROCbSVYWXN1aPxh
		if J5fKPnMqXgQtWjeSZ2uLsITNV: ll5Qv3n72dmJuxsg9FqyYkwcbI.append(J5fKPnMqXgQtWjeSZ2uLsITNV)
	ll5Qv3n72dmJuxsg9FqyYkwcbI = list(set(ll5Qv3n72dmJuxsg9FqyYkwcbI))
	if not ptkR1Tydzs and len(ll5Qv3n72dmJuxsg9FqyYkwcbI)==PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"࠱჊"):
		TPw4M0cjln9J = ll5Qv3n72dmJuxsg9FqyYkwcbI[BoWHNb9daQVCF16A(u"࠱჋")]
		if TPw4M0cjln9J!=EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠴࠳࠴჌"):
			if TPw4M0cjln9J<T6wRistc1SCo4hqObgumK(u"࠳Ⴭ"): ptkR1Tydzs = T6wRistc1SCo4hqObgumK(u"࡙ࠩ࡭ࡩ࡫࡯ࠡࡲࡤ࡫ࡪ࠵ࡳࡦࡴࡹࡩࡷࠦࡩࡴࠢࡱࡳࡹࠦࡡࡤࡥࡨࡷࡸ࡯ࡢ࡭ࡧࠪ໾")
			else:
				ptkR1Tydzs = jx7s8T0BFgODXLMzIYedf(u"ࠪࡌ࡙࡚ࡐࠡࡇࡵࡶࡴࡸ࠺ࠡࠩ໿")+str(TPw4M0cjln9J)
				if BLz7m2RkNrxXQwy1cGAp: import http.client as dg1GufVwAMXH2lF96tZqUQ3jb45
				else: import httplib as dg1GufVwAMXH2lF96tZqUQ3jb45
				ptkR1Tydzs += sRth5giAQzWlEVm7JOX(u"ࠫࠥ࠮ࠠࠨༀ")+dg1GufVwAMXH2lF96tZqUQ3jb45.responses[TPw4M0cjln9J]+EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠬࠦࠩࠨ༁")
	KBxPW9cX8dqtaUDG.sleep(UxS67uoGThbMwnfNRzy4gajLd23JH(u"࠵჎"))
	return ptkR1Tydzs,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i
class PIcUtvFTmOih72zdKxjWDyoGrJqaM(XUYb0K2ghSyFs.WindowDialog):
	def __init__(ooSGpJPmzf, *args, **GN0zg1hmTcPpq8AvMBfJ3ELRj2Fs):
		lwOiWdIKk9 = XXRtDhYvWb35qnLBxIri7ScNUks0.path.join(QgRBJhSGd4uX7i, RqldvxFuM5GEQ2HAz93o7afBb0(u"࠭ࡲࡦࡵࡲࡹࡷࡩࡥࡴࠩ༂"), YB5xyI7MaRslVpv(u"ࠧࡳࡧࡦࡥࡵࡺࡣࡩࡣ࠵ࠫ༃"), vvHpKfcqRnrFzjG(u"ࠨࡦ࡬ࡥࡱࡵࡧࡣࡩ࠱ࡴࡳ࡭ࠧ༄"))
		Jq48uMaDZ01LU = XXRtDhYvWb35qnLBxIri7ScNUks0.path.join(QgRBJhSGd4uX7i, T6wRistc1SCo4hqObgumK(u"ࠩࡵࡩࡸࡵࡵࡳࡥࡨࡷࠬ༅"), QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠪࡶࡪࡩࡡࡱࡶࡦ࡬ࡦ࠸ࠧ༆"), BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠫࡸ࡫࡬ࡦࡥࡷࡩࡩ࠴ࡰ࡯ࡩࠪ༇"))
		jOwAd7VI504S8H2zoMcuB1m = XXRtDhYvWb35qnLBxIri7ScNUks0.path.join(QgRBJhSGd4uX7i, b05yftsZ6NYgIKP(u"ࠬࡸࡥࡴࡱࡸࡶࡨ࡫ࡳࠨ༈"), jx7s8T0BFgODXLMzIYedf(u"࠭ࡲࡦࡥࡤࡴࡹࡩࡨࡢ࠴ࠪ༉"), b05yftsZ6NYgIKP(u"ࠧࡣࡷࡷࡸࡴࡴࡦࡰ࠰ࡳࡲ࡬࠭༊"))
		xxtUHG8rDpQ4k = XXRtDhYvWb35qnLBxIri7ScNUks0.path.join(QgRBJhSGd4uX7i, v5EA6TqHX3s4jzBMk(u"ࠨࡴࡨࡷࡴࡻࡲࡤࡧࡶࠫ་"), BoWHNb9daQVCF16A(u"ࠩࡵࡩࡨࡧࡰࡵࡥ࡫ࡥ࠷࠭༌"), UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠪࡦࡺࡺࡴࡰࡰࡱࡪ࠳ࡶ࡮ࡨࠩ།"))
		g6zDym3xSLXBOQVFJ = XXRtDhYvWb35qnLBxIri7ScNUks0.path.join(QgRBJhSGd4uX7i, jx7s8T0BFgODXLMzIYedf(u"ࠫࡷ࡫ࡳࡰࡷࡵࡧࡪࡹࠧ༎"), PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠬࡸࡥࡤࡣࡳࡸࡨ࡮ࡡ࠳ࠩ༏"), EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠭ࡢࡶࡶࡷࡳࡳࡨࡧ࠯ࡲࡱ࡫ࠬ༐"))
		ooSGpJPmzf.cancelled = jx7s8T0BFgODXLMzIYedf(u"ࡊࡦࡲࡳࡦᅅ")
		ooSGpJPmzf.chk = [RqldvxFuM5GEQ2HAz93o7afBb0(u"࠶ა")] * PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"࠾჏")
		ooSGpJPmzf.chkbutton = [v5EA6TqHX3s4jzBMk(u"࠱გ")] * BoWHNb9daQVCF16A(u"࠹ბ")
		ooSGpJPmzf.chkstate = [fY5wTlhtnOc0Er6sdy4k87b(u"ࡋࡧ࡬ࡴࡧᅆ")] * qbPw1d3KimF(u"࠻დ")
		cwU82DfoJL, bSJpU0Gh9fL3KvsTuHNnk, gMUIoY2SpbydkF, IViQz4850uED1FwUsLKS = T6wRistc1SCo4hqObgumK(u"࠶࠺࠶ვ"), T6wRistc1SCo4hqObgumK(u"࠳ე"), EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠼࠶࠰ზ"), FGDJwkEbTB5SoXujs3f(u"࠽࠶࠱თ")
		f7PkbjI3c6h = cwU82DfoJL+gMUIoY2SpbydkF//vvHpKfcqRnrFzjG(u"࠲ი")
		B4k3aTO1RqzHtpMKUZnmrdyulCNh, fajFiz6l8HQtV1, L1L9Ebf8thuda3Kq2Y, DTYoks54alJNLFrehwb = jSu5Cg2Ub1OAkZVs8Yoz(u"࠵࠸࠹ლ"), qbPw1d3KimF(u"࠲࠴࠳კ"), hhlbF1Sns5TrEN8QPCYmL4(u"࠸࠴࠵მ"), hhlbF1Sns5TrEN8QPCYmL4(u"࠸࠴࠵მ")
		Qbq6jUg2TZ19IPlaiO = B4k3aTO1RqzHtpMKUZnmrdyulCNh+L1L9Ebf8thuda3Kq2Y//gItVahxL0w(u"࠶ნ")
		ssShB5eygTCJ6VGN, nE1z2lua08, N9NxZOzdehnPSyLv2ip, eEHjhfGX6lLB7Ywmt8ri = BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠷࠰࠱პ"), EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠶࠶࠷ჟ"), nr5mZG89ICi6cgt4MfLJa0(u"࠶࠻࠰ო"), QynMHGWA0blfqTUdxRh5Jzi2t(u"࠶࠲რ")
		bjU8s1BJr2PIRN6xDOYFVKEqnSd = f7PkbjI3c6h-N9NxZOzdehnPSyLv2ip-ssShB5eygTCJ6VGN//sRth5giAQzWlEVm7JOX(u"࠴ს")
		zVU3xoGt6e = f7PkbjI3c6h+ssShB5eygTCJ6VGN//NVS30xAdRFMIw1n9CislkE2(u"࠵ტ")
		Jvapmgsz3PeBjqkUywnYdG0xNOFRWh, qLMkYJPdl3ex7tuNAR6UKa, jReiIo30GtYyp, vi7RHIXlbcwaz6JVT5KQWUPENoG9 = sRth5giAQzWlEVm7JOX(u"࠷࠺࠻უ"), sRth5giAQzWlEVm7JOX(u"࠸࠶ფ"), EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠵࠱࠲ღ"), fY5wTlhtnOc0Er6sdy4k87b(u"࠻࠰ქ")
		BBlomCYZr4USIiR7b2TwzegD53X, EEmBhDNwTCiaX36rqIuOZ, CXQIhJDgRq4FPpiNBVATf3tY0Mv5G6, X2CUxPpmNnD = LgpdP3UjFRnlX(u"࠴࠷࠸ყ"), WMkAjB1RgN7q(u"࠻࠵ც"), YB5xyI7MaRslVpv(u"࠸࠴࠵ჩ"), UnWjVbo503mEMv9KF(u"࠷࠳შ")
		bBfsH9daL0wmq1n3 = l0WAe1f7Bpi5ZXk(u"࠵࠴࠹ძ")
		cwU82DfoJL, bSJpU0Gh9fL3KvsTuHNnk, gMUIoY2SpbydkF, IViQz4850uED1FwUsLKS = int(cwU82DfoJL*bBfsH9daL0wmq1n3), int(bSJpU0Gh9fL3KvsTuHNnk*bBfsH9daL0wmq1n3), int(gMUIoY2SpbydkF*bBfsH9daL0wmq1n3), int(IViQz4850uED1FwUsLKS*bBfsH9daL0wmq1n3)
		B4k3aTO1RqzHtpMKUZnmrdyulCNh, fajFiz6l8HQtV1, L1L9Ebf8thuda3Kq2Y, DTYoks54alJNLFrehwb = int(B4k3aTO1RqzHtpMKUZnmrdyulCNh*bBfsH9daL0wmq1n3), int(fajFiz6l8HQtV1*bBfsH9daL0wmq1n3), int(L1L9Ebf8thuda3Kq2Y*bBfsH9daL0wmq1n3), int(DTYoks54alJNLFrehwb*bBfsH9daL0wmq1n3)
		bjU8s1BJr2PIRN6xDOYFVKEqnSd, y7EjrAg94LowJdtSM8aXGsbYKTFC, P9PAQ8WKdrcoaSjmezVlInxLuY5R3T, z87PeKONUc1 = int(bjU8s1BJr2PIRN6xDOYFVKEqnSd*bBfsH9daL0wmq1n3), int(nE1z2lua08*bBfsH9daL0wmq1n3), int(N9NxZOzdehnPSyLv2ip*bBfsH9daL0wmq1n3), int(eEHjhfGX6lLB7Ywmt8ri*bBfsH9daL0wmq1n3)
		zVU3xoGt6e, RRUsbFrqoHXNC43MiW2pwJ, hO0UXt6mMq8, x4Bul8VqWfbksvC7T = int(zVU3xoGt6e*bBfsH9daL0wmq1n3), int(nE1z2lua08*bBfsH9daL0wmq1n3), int(N9NxZOzdehnPSyLv2ip*bBfsH9daL0wmq1n3), int(eEHjhfGX6lLB7Ywmt8ri*bBfsH9daL0wmq1n3)
		Jvapmgsz3PeBjqkUywnYdG0xNOFRWh, qLMkYJPdl3ex7tuNAR6UKa, jReiIo30GtYyp, vi7RHIXlbcwaz6JVT5KQWUPENoG9 = int(Jvapmgsz3PeBjqkUywnYdG0xNOFRWh*bBfsH9daL0wmq1n3), int(qLMkYJPdl3ex7tuNAR6UKa*bBfsH9daL0wmq1n3), int(jReiIo30GtYyp*bBfsH9daL0wmq1n3), int(vi7RHIXlbcwaz6JVT5KQWUPENoG9*bBfsH9daL0wmq1n3)
		BBlomCYZr4USIiR7b2TwzegD53X, EEmBhDNwTCiaX36rqIuOZ, CXQIhJDgRq4FPpiNBVATf3tY0Mv5G6, X2CUxPpmNnD = int(BBlomCYZr4USIiR7b2TwzegD53X*bBfsH9daL0wmq1n3), int(EEmBhDNwTCiaX36rqIuOZ*bBfsH9daL0wmq1n3), int(CXQIhJDgRq4FPpiNBVATf3tY0Mv5G6*bBfsH9daL0wmq1n3), int(X2CUxPpmNnD*bBfsH9daL0wmq1n3)
		GZkpHau58D7b0Eez = XUYb0K2ghSyFs.ControlImage(cwU82DfoJL, bSJpU0Gh9fL3KvsTuHNnk, gMUIoY2SpbydkF, IViQz4850uED1FwUsLKS, lwOiWdIKk9)
		ooSGpJPmzf.addControl(GZkpHau58D7b0Eez)
		ooSGpJPmzf.iteration = GN0zg1hmTcPpq8AvMBfJ3ELRj2Fs.get(C2dgEDAKQGsvh(u"ࠧࡪࡶࡨࡶࡦࡺࡩࡰࡰࠪ༑"))
		LCyAHeXWcDZ1woKkS4zb9sfh = sRth5giAQzWlEVm7JOX(u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ༒")+rbjsM8cRFiuA1(u"ࠩไัฺࠦร็ษࠣษู๋ว็ุ๋่ࠢะࠠา๊ห์ฯࠦࠠࠡࠢࠣࠤࠥࠦࠠࠨ༓")+sRth5giAQzWlEVm7JOX(u"ࠪห้๋อศ๊็อࠥืโๆࠢࠣࠫ༔")+str(ooSGpJPmzf.iteration)+FGDJwkEbTB5SoXujs3f(u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭༕")
		ooSGpJPmzf.strActionInfo = XUYb0K2ghSyFs.ControlLabel(Jvapmgsz3PeBjqkUywnYdG0xNOFRWh, qLMkYJPdl3ex7tuNAR6UKa, jReiIo30GtYyp, vi7RHIXlbcwaz6JVT5KQWUPENoG9, LCyAHeXWcDZ1woKkS4zb9sfh, LgpdP3UjFRnlX(u"ࠬ࡬࡯࡯ࡶ࠴࠷ࠬ༖"))
		ooSGpJPmzf.addControl(ooSGpJPmzf.strActionInfo)
		IcWzVO137wFvemn2QTq8yKs9 = XUYb0K2ghSyFs.ControlImage(B4k3aTO1RqzHtpMKUZnmrdyulCNh, fajFiz6l8HQtV1, L1L9Ebf8thuda3Kq2Y, DTYoks54alJNLFrehwb, GN0zg1hmTcPpq8AvMBfJ3ELRj2Fs.get(jSu5Cg2Ub1OAkZVs8Yoz(u"࠭ࡣࡢࡲࡷࡧ࡭ࡧࠧ༗")))
		ooSGpJPmzf.addControl(IcWzVO137wFvemn2QTq8yKs9)
		HH2DC3XpRKWx05JAj1vz = BoWHNb9daQVCF16A(u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟༘ࠪ")+GN0zg1hmTcPpq8AvMBfJ3ELRj2Fs.get(BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠨ࡯ࡶ࡫༙ࠬ"))+v5EA6TqHX3s4jzBMk(u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ༚")
		ooSGpJPmzf.strActionInfo = XUYb0K2ghSyFs.ControlLabel(BBlomCYZr4USIiR7b2TwzegD53X, EEmBhDNwTCiaX36rqIuOZ, CXQIhJDgRq4FPpiNBVATf3tY0Mv5G6, X2CUxPpmNnD, HH2DC3XpRKWx05JAj1vz, b05yftsZ6NYgIKP(u"ࠪࡪࡴࡴࡴ࠲࠵ࠪ༛"))
		ooSGpJPmzf.addControl(ooSGpJPmzf.strActionInfo)
		text = k5dztomYyN3H(u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ༜")+l0WAe1f7Bpi5ZXk(u"ࠬิั้ฮࠪ༝")+jx7s8T0BFgODXLMzIYedf(u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ༞")
		ooSGpJPmzf.cancelbutton = XUYb0K2ghSyFs.ControlButton(bjU8s1BJr2PIRN6xDOYFVKEqnSd, y7EjrAg94LowJdtSM8aXGsbYKTFC, P9PAQ8WKdrcoaSjmezVlInxLuY5R3T, z87PeKONUc1, text, focusTexture=g6zDym3xSLXBOQVFJ, noFocusTexture=jOwAd7VI504S8H2zoMcuB1m, alignment=nr5mZG89ICi6cgt4MfLJa0(u"࠸წ"))
		text = WMkAjB1RgN7q(u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ༟")+C2dgEDAKQGsvh(u"ࠨษึฮ๊ืวาࠩ༠")+hhlbF1Sns5TrEN8QPCYmL4(u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ༡")
		ooSGpJPmzf.okbutton = XUYb0K2ghSyFs.ControlButton(zVU3xoGt6e, RRUsbFrqoHXNC43MiW2pwJ, hO0UXt6mMq8, x4Bul8VqWfbksvC7T, text, focusTexture=g6zDym3xSLXBOQVFJ, noFocusTexture=jOwAd7VI504S8H2zoMcuB1m, alignment=QynMHGWA0blfqTUdxRh5Jzi2t(u"࠲ჭ"))
		ooSGpJPmzf.addControl(ooSGpJPmzf.okbutton)
		ooSGpJPmzf.addControl(ooSGpJPmzf.cancelbutton)
		TTAOtdu0cb, IcRwd0gEK9rek8OQZt2 = DTYoks54alJNLFrehwb//YB5xyI7MaRslVpv(u"࠴ხ"), L1L9Ebf8thuda3Kq2Y//YB5xyI7MaRslVpv(u"࠴ხ")
		for FVW0I9sYcAjmDgn8r in range(PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"࠻ჯ")):
			UQ6GkovwFrRYda8I0Bib4fJKLuM5t = FVW0I9sYcAjmDgn8r // qbPw1d3KimF(u"࠶ჰ")
			qUSrb80k6glRNGvdDo93WteYza = FVW0I9sYcAjmDgn8r % jSu5Cg2Ub1OAkZVs8Yoz(u"࠷ჱ")
			Xn0k2uJ6saFf3RxUyEKWZr4iLOS9YC = B4k3aTO1RqzHtpMKUZnmrdyulCNh + (IcRwd0gEK9rek8OQZt2 * qUSrb80k6glRNGvdDo93WteYza)
			AcWFQefOHE869 = fajFiz6l8HQtV1 + (TTAOtdu0cb * UQ6GkovwFrRYda8I0Bib4fJKLuM5t)
			ooSGpJPmzf.chk[FVW0I9sYcAjmDgn8r] = XUYb0K2ghSyFs.ControlImage(Xn0k2uJ6saFf3RxUyEKWZr4iLOS9YC, AcWFQefOHE869, IcRwd0gEK9rek8OQZt2, TTAOtdu0cb, Jq48uMaDZ01LU)
			ooSGpJPmzf.addControl(ooSGpJPmzf.chk[FVW0I9sYcAjmDgn8r])
			ooSGpJPmzf.chk[FVW0I9sYcAjmDgn8r].setVisible(vvHpKfcqRnrFzjG(u"ࡌࡡ࡭ࡵࡨᅇ"))
			ooSGpJPmzf.chkbutton[FVW0I9sYcAjmDgn8r] = XUYb0K2ghSyFs.ControlButton(Xn0k2uJ6saFf3RxUyEKWZr4iLOS9YC, AcWFQefOHE869, IcRwd0gEK9rek8OQZt2, TTAOtdu0cb, str(FVW0I9sYcAjmDgn8r + YB5xyI7MaRslVpv(u"࠶ჲ")), font=hhlbF1Sns5TrEN8QPCYmL4(u"ࠪࡪࡴࡴࡴ࠲࠵ࠪ༢"), focusTexture=jOwAd7VI504S8H2zoMcuB1m, noFocusTexture=xxtUHG8rDpQ4k)
			ooSGpJPmzf.addControl(ooSGpJPmzf.chkbutton[FVW0I9sYcAjmDgn8r])
		for FVW0I9sYcAjmDgn8r in range(NVS30xAdRFMIw1n9CislkE2(u"࠿ჳ")):
			CpImQJh5tod2gR0A3VXHujwsPcfYDe = (FVW0I9sYcAjmDgn8r // vvHpKfcqRnrFzjG(u"࠳ჴ")) * vvHpKfcqRnrFzjG(u"࠳ჴ")
			wOF85cx1lJzMmN6pDfXIdnT2 = CpImQJh5tod2gR0A3VXHujwsPcfYDe + (FVW0I9sYcAjmDgn8r + vvHpKfcqRnrFzjG(u"࠲ჵ")) % V2RbfGOBdcA6l8NTsPWzEyvS7(u"࠵ჶ")
			lMU7W3DP58t6hvFKXRsa4J0VG9 = CpImQJh5tod2gR0A3VXHujwsPcfYDe + (FVW0I9sYcAjmDgn8r - NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠴ჷ")) % T6wRistc1SCo4hqObgumK(u"࠷ჸ")
			JJqLSdBQAjuDFmvPns = (FVW0I9sYcAjmDgn8r - FGDJwkEbTB5SoXujs3f(u"࠹ჺ")) % hhlbF1Sns5TrEN8QPCYmL4(u"࠾ჹ")
			qHwzjOTKnh = (FVW0I9sYcAjmDgn8r + C2dgEDAKQGsvh(u"࠴ჼ")) % EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠹჻")
			ooSGpJPmzf.chkbutton[FVW0I9sYcAjmDgn8r].controlRight(ooSGpJPmzf.chkbutton[wOF85cx1lJzMmN6pDfXIdnT2])
			ooSGpJPmzf.chkbutton[FVW0I9sYcAjmDgn8r].controlLeft(ooSGpJPmzf.chkbutton[lMU7W3DP58t6hvFKXRsa4J0VG9])
			if FVW0I9sYcAjmDgn8r <= C2jP0iLNGKnHu9xp(u"࠴ჽ"):
				ooSGpJPmzf.chkbutton[FVW0I9sYcAjmDgn8r].controlUp(ooSGpJPmzf.okbutton)
			else:
				ooSGpJPmzf.chkbutton[FVW0I9sYcAjmDgn8r].controlUp(ooSGpJPmzf.chkbutton[JJqLSdBQAjuDFmvPns])
			if FVW0I9sYcAjmDgn8r >= hhlbF1Sns5TrEN8QPCYmL4(u"࠹ჾ"):
				ooSGpJPmzf.chkbutton[FVW0I9sYcAjmDgn8r].controlDown(ooSGpJPmzf.okbutton)
			else:
				ooSGpJPmzf.chkbutton[FVW0I9sYcAjmDgn8r].controlDown(ooSGpJPmzf.chkbutton[qHwzjOTKnh])
		ooSGpJPmzf.okbutton.controlLeft(ooSGpJPmzf.cancelbutton)
		ooSGpJPmzf.okbutton.controlRight(ooSGpJPmzf.cancelbutton)
		ooSGpJPmzf.cancelbutton.controlLeft(ooSGpJPmzf.okbutton)
		ooSGpJPmzf.cancelbutton.controlRight(ooSGpJPmzf.okbutton)
		ooSGpJPmzf.okbutton.controlDown(ooSGpJPmzf.chkbutton[T6wRistc1SCo4hqObgumK(u"࠶ჿ")])
		ooSGpJPmzf.okbutton.controlUp(ooSGpJPmzf.chkbutton[RqldvxFuM5GEQ2HAz93o7afBb0(u"࠽ᄀ")])
		ooSGpJPmzf.cancelbutton.controlDown(ooSGpJPmzf.chkbutton[NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠶ᄁ")])
		ooSGpJPmzf.cancelbutton.controlUp(ooSGpJPmzf.chkbutton[YB5xyI7MaRslVpv(u"࠶ᄂ")])
		ooSGpJPmzf.setFocus(ooSGpJPmzf.okbutton)
	def get(ooSGpJPmzf):
		ooSGpJPmzf.doModal()
		ooSGpJPmzf.close()
		if not ooSGpJPmzf.cancelled:
			return [FVW0I9sYcAjmDgn8r for FVW0I9sYcAjmDgn8r in range(T6wRistc1SCo4hqObgumK(u"࠺ᄃ")) if ooSGpJPmzf.chkstate[FVW0I9sYcAjmDgn8r]]
	def onControl(ooSGpJPmzf, Z1WjuvV4kQ):
		if Z1WjuvV4kQ.getId() == ooSGpJPmzf.okbutton.getId() and any(ooSGpJPmzf.chkstate):
			ooSGpJPmzf.close()
		elif Z1WjuvV4kQ.getId() == ooSGpJPmzf.cancelbutton.getId():
			ooSGpJPmzf.cancelled = RqldvxFuM5GEQ2HAz93o7afBb0(u"ࡔࡳࡷࡨᅈ")
			ooSGpJPmzf.close()
		else:
			GDL3q5vFjwIVrM2ElRZNd = Z1WjuvV4kQ.getLabel()
			if GDL3q5vFjwIVrM2ElRZNd.isnumeric():
				index = int(GDL3q5vFjwIVrM2ElRZNd) - BmcLzCFjuIrZP5fwXH18aN6YS(u"࠳ᄄ")
				ooSGpJPmzf.chkstate[index] = not ooSGpJPmzf.chkstate[index]
				ooSGpJPmzf.chk[index].setVisible(ooSGpJPmzf.chkstate[index])
	def onAction(ooSGpJPmzf, zhwa7mCjk69R8g5l4DcV):
		if zhwa7mCjk69R8g5l4DcV == UnWjVbo503mEMv9KF(u"࠴࠴ᄅ"):
			ooSGpJPmzf.cancelled = UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࡕࡴࡸࡩᅉ")
			ooSGpJPmzf.close()
def f63TBbEDzOhCN7uywKxragnev0(key,iOZ5nu0Y6Q4aqDUrElfIP9Tek,url):
	headers = {BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ༣"):url,RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠬࡇࡣࡤࡧࡳࡸ࠲ࡒࡡ࡯ࡩࡸࡥ࡬࡫ࠧ༤"):iOZ5nu0Y6Q4aqDUrElfIP9Tek}
	V38fctgolwq4Q75mspU9bejESzhOu = NVS30xAdRFMIw1n9CislkE2(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱࡫ࡴࡵࡧ࡭ࡧ࠱ࡧࡴࡳ࠯ࡳࡧࡦࡥࡵࡺࡣࡩࡣ࠲ࡥࡵ࡯࠯ࡧࡣ࡯ࡰࡧࡧࡣ࡬ࡁ࡮ࡁࠬ༥")+key
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(IIiPCruL6dT8s1lqj47SzpVHnYNm,vvHpKfcqRnrFzjG(u"ࠧࡈࡇࡗࠫ༦"),V38fctgolwq4Q75mspU9bejESzhOu,UnWjVbo503mEMv9KF(u"ࠨࠩ༧"),headers,T6wRistc1SCo4hqObgumK(u"ࠩࠪ༨"),NVS30xAdRFMIw1n9CislkE2(u"ࠪࠫ༩"),BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡈࡇࡗࡣࡗࡋࡃࡂࡒࡗࡇࡍࡇ࠲ࡠࡖࡒࡏࡊࡔ࠭࠲ࡵࡷࠫ༪"))
	Ujugy9ASbcRxaVeCKJ,iteration = hhlbF1Sns5TrEN8QPCYmL4(u"ࠬ࠭༫"),gItVahxL0w(u"࠴ᄆ")
	while NVS30xAdRFMIw1n9CislkE2(u"ࡖࡵࡹࡪᅊ"):
		MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
		tWha1P9LVeuNxpQUAB = My7Dwqvs6bfGNSIgX.findall(v5EA6TqHX3s4jzBMk(u"࠭ࠢࠩ࠱ࡵࡩࡨࡧࡰࡵࡥ࡫ࡥ࠴ࡧࡰࡪ࠴࠲ࡴࡦࡿ࡬ࡰࡣࡧ࡟ࡣࠨ࡝ࠬࠫࠪ༬"), MK6ZT2zjC1SbmveNFqor)
		iteration += T6wRistc1SCo4hqObgumK(u"࠶ᄇ")
		message = My7Dwqvs6bfGNSIgX.findall(k5dztomYyN3H(u"ࠧ࠽࡮ࡤࡦࡪࡲ࡛࡟ࡀࡠ࠯ࡨࡲࡡࡴࡵࡀࠦ࡫ࡨࡣ࠮࡫ࡰࡥ࡬࡫ࡳࡦ࡮ࡨࡧࡹ࠳࡭ࡦࡵࡶࡥ࡬࡫࠭ࡵࡧࡻࡸࠧࡡ࡞࠿࡟࠭ࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡱࡧࡢࡦ࡮ࡁࠫ༭"), MK6ZT2zjC1SbmveNFqor)
		if not message: message = My7Dwqvs6bfGNSIgX.findall(PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠨ࠾ࡧ࡭ࡻࡡ࡞࠿࡟࠮ࡧࡱࡧࡳࡴ࠿ࠥࡪࡧࡩ࠭ࡪ࡯ࡤ࡫ࡪࡹࡥ࡭ࡧࡦࡸ࠲ࡳࡥࡴࡵࡤ࡫ࡪ࠳ࡥࡳࡴࡲࡶࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ༮"), MK6ZT2zjC1SbmveNFqor)
		if not message:
			Ujugy9ASbcRxaVeCKJ = My7Dwqvs6bfGNSIgX.findall(hhlbF1Sns5TrEN8QPCYmL4(u"ࠩࡵࡩࡦࡪ࡯࡯࡮ࡼࡂ࠭࠴ࠪࡀࠫ࠿ࠫ༯"), MK6ZT2zjC1SbmveNFqor)[qbPw1d3KimF(u"࠶ᄈ")]
			break
		else:
			message = message[l0WAe1f7Bpi5ZXk(u"࠰ᄉ")]
			tWha1P9LVeuNxpQUAB = tWha1P9LVeuNxpQUAB[jSu5Cg2Ub1OAkZVs8Yoz(u"࠱ᄊ")]
		qXsyI1unfJj9HzDarBiNPQpcKh = My7Dwqvs6bfGNSIgX.findall(C2dgEDAKQGsvh(u"ࡵࠫࡳࡧ࡭ࡦ࠿ࠥࡧࠧࡢࡳࠬࡸࡤࡰࡺ࡫࠽ࠣࠪ࡞ࡢࠧࡣࠫࠪࠩ༰"), MK6ZT2zjC1SbmveNFqor)[vvHpKfcqRnrFzjG(u"࠲ᄋ")]
		uEv4mbzSY2r5kORW9tNa = LgpdP3UjFRnlX(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡪࡳࡴ࡭࡬ࡦ࠰ࡦࡳࡲࠫࡳࠨ༱") % (tWha1P9LVeuNxpQUAB.replace(BoWHNb9daQVCF16A(u"ࠬࠬࡡ࡮ࡲ࠾ࠫ༲"), YB5xyI7MaRslVpv(u"࠭ࠦࠨ༳")))
		message = My7Dwqvs6bfGNSIgX.sub(fY5wTlhtnOc0Er6sdy4k87b(u"ࠧ࠽࠱ࡂࠬࡩ࡯ࡶࡽࡵࡷࡶࡴࡴࡧࠪ࡝ࡡࡂࡢ࠰࠾ࠨ༴"), LgpdP3UjFRnlX(u"ࠨ༵ࠩ"), message)
		wwqxMRFespD2ol8rn3I = PIcUtvFTmOih72zdKxjWDyoGrJqaM(captcha=uEv4mbzSY2r5kORW9tNa, msg=message, iteration=iteration)
		NXbiDW4rLh859ZTf = wwqxMRFespD2ol8rn3I.get()
		if not NXbiDW4rLh859ZTf: break
		data = {nr5mZG89ICi6cgt4MfLJa0(u"ࠩࡦࠫ༶"): qXsyI1unfJj9HzDarBiNPQpcKh, sRth5giAQzWlEVm7JOX(u"ࠪࡶࡪࡹࡰࡰࡰࡶࡩ༷ࠬ"): NXbiDW4rLh859ZTf}
		xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(IIiPCruL6dT8s1lqj47SzpVHnYNm,V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠫࡕࡕࡓࡕࠩ༸"),V38fctgolwq4Q75mspU9bejESzhOu,data,headers,l0WAe1f7Bpi5ZXk(u"༹ࠬ࠭"),BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠭ࠧ༺"),rbjsM8cRFiuA1(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡋࡊ࡚࡟ࡓࡇࡆࡅࡕ࡚ࡃࡉࡃ࠵ࡣ࡙ࡕࡋࡆࡐ࠰࠶ࡳࡪࠧ༻"))
	return Ujugy9ASbcRxaVeCKJ
def Z70v4c2XlVg1mT9p(url):
	MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(f9Oum6c0FotxYn,url,PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠨࠩ༼"),rbjsM8cRFiuA1(u"ࠩࠪ༽"),V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠪࠫ༾"),nr5mZG89ICi6cgt4MfLJa0(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡔࡄࡆࡑࡕࡁࡅࡕ࠰࠵ࡸࡺࠧ༿"))
	items = My7Dwqvs6bfGNSIgX.findall(nr5mZG89ICi6cgt4MfLJa0(u"ࠬࡩ࡯࡭ࡱࡵࡁࠧࡸࡥࡥࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪཀ"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if items: return NVS30xAdRFMIw1n9CislkE2(u"࠭ࠧཁ"),[BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠧࠨག")],[ items[WMkAjB1RgN7q(u"࠳ᄌ")] ]
	else: return NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡅࡗࡇࡂࡍࡑࡄࡈࡘ࠭གྷ"),[],[]
def rAqcWjYhX0PmyT(url):
	return qbPw1d3KimF(u"ࠩࠪང"),[BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠪࠫཅ")],[ url ]
def f2k7oH0VAhqibEaKxnzclZQLwgm5RF(url):
	LkVZrOE4XBSN2Qex5PyHqC = url.split(T6wRistc1SCo4hqObgumK(u"ࠫ࠴࠭ཆ"))
	YfvexDltPRyV8Ibg9A3j = T6wRistc1SCo4hqObgumK(u"ࠬ࠵ࠧཇ").join(LkVZrOE4XBSN2Qex5PyHqC[RqldvxFuM5GEQ2HAz93o7afBb0(u"࠴ᄍ"):vvHpKfcqRnrFzjG(u"࠸ᄎ")])
	MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(f9Oum6c0FotxYn,url,LgpdP3UjFRnlX(u"࠭ࠧ཈"),nr5mZG89ICi6cgt4MfLJa0(u"ࠧࠨཉ"),NVS30xAdRFMIw1n9CislkE2(u"ࠨࠩཊ"),UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡠࡉࡑࡒ࡜ࡗࡍࡇࡒࡆ࠯࠴ࡷࡹ࠭ཋ"))
	items = My7Dwqvs6bfGNSIgX.findall(RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠪࡨࡱࡨࡵࡵࡶࡲࡲࡡ࠭࡜ࠪ࠰࡫ࡶࡪ࡬ࠠ࠾ࠢࠥࠬ࠳࠰࠿ࠪࠤࠣࡠ࠰ࠦ࡜ࠩࠪ࠱࠮ࡄ࠯ࠠ࡝ࠧࠣࠬ࠳࠰࠿ࠪࠢ࡟࠯ࠥ࠮࠮ࠫࡁࠬࠤࡡࠫࠠࠩ࠰࠭ࡃ࠮ࡢࠩࠡ࡞࠮ࠤࠧ࠮࠮ࠫࡁࠬࠦࠬཌ"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if items:
		Iwh7pS4CTEjZeO,pzYNuWHETc9orAef1BLmShsGRIw,OoW8aQ35s6TkSleGmyuw90PI,EX8TiGPOJnl07jwWdBYtz,wwYcRite8LAqdIaE5f9rm0,NIy6AVTjmDKR8EOs5cMHzBCxv39fi = items[hhlbF1Sns5TrEN8QPCYmL4(u"࠶ᄏ")]
		nmqEj60bcdSQoFPGa = int(pzYNuWHETc9orAef1BLmShsGRIw) % int(OoW8aQ35s6TkSleGmyuw90PI) + int(EX8TiGPOJnl07jwWdBYtz) % int(wwYcRite8LAqdIaE5f9rm0)
		url = YfvexDltPRyV8Ibg9A3j + Iwh7pS4CTEjZeO + str(nmqEj60bcdSQoFPGa) + NIy6AVTjmDKR8EOs5cMHzBCxv39fi
		return fY5wTlhtnOc0Er6sdy4k87b(u"ࠫࠬཌྷ"),[PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠬ࠭ཎ")],[url]
	else: return fY5wTlhtnOc0Er6sdy4k87b(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡ࡜ࡌࡔࡕ࡟ࡓࡉࡃࡕࡉࠬཏ"),[],[]
def vHFe64R5VgyCbfwU8s3dlQKTWzkEh(url):
	id = url.split(RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠧ࠰ࠩཐ"))[-BmcLzCFjuIrZP5fwXH18aN6YS(u"࠱ᄐ")]
	headers = { T6wRistc1SCo4hqObgumK(u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧད") : WMkAjB1RgN7q(u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤࠨདྷ") }
	tWha1P9LVeuNxpQUAB = { v5EA6TqHX3s4jzBMk(u"ࠥ࡭ࡩࠨན"):id , jSu5Cg2Ub1OAkZVs8Yoz(u"ࠦࡴࡶࠢཔ"):nr5mZG89ICi6cgt4MfLJa0(u"ࠧࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠲ࠣཕ") }
	h5QaxwPF7SOu6fMBTGXRU2yn = mORwgTnXBdQ7iCSHKf(f9Oum6c0FotxYn,NVS30xAdRFMIw1n9CislkE2(u"࠭ࡐࡐࡕࡗࠫབ"), url, tWha1P9LVeuNxpQUAB, headers, BoWHNb9daQVCF16A(u"ࠧࠨབྷ"),BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠨࠩམ"),RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡓࡐ࠵ࡗࡓࡐࡔࡇࡄ࠮࠳ࡶࡸࠬཙ"))
	if FGDJwkEbTB5SoXujs3f(u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬཚ") in list(h5QaxwPF7SOu6fMBTGXRU2yn.headers.keys()): BoEFz2WhUyvTgDeiZ = h5QaxwPF7SOu6fMBTGXRU2yn.headers[hhlbF1Sns5TrEN8QPCYmL4(u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭ཛ")]
	else: BoEFz2WhUyvTgDeiZ = url
	if BoEFz2WhUyvTgDeiZ: return T6wRistc1SCo4hqObgumK(u"ࠬ࠭ཛྷ"),[k5dztomYyN3H(u"࠭ࠧཝ")],[BoEFz2WhUyvTgDeiZ]
	else: return nr5mZG89ICi6cgt4MfLJa0(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡐࡔ࠹࡛ࡐࡍࡑࡄࡈࠬཞ"),[],[]
def aceQhl9M3K(url):
	MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(f9Oum6c0FotxYn,url,NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠨࠩཟ"),v5EA6TqHX3s4jzBMk(u"ࠩࠪའ"),T6wRistc1SCo4hqObgumK(u"ࠪࠫཡ"),gItVahxL0w(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡘࡋࡑࡘ࡛ࡒࡉࡗࡇ࠰࠵ࡸࡺࠧར"))
	items = My7Dwqvs6bfGNSIgX.findall(FGDJwkEbTB5SoXujs3f(u"ࠬࡳࡰ࠵࠼ࠣࡠࡠࡢࠧࠩ࠰࠭ࡃ࠮ࡢࠧࠨལ"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if items: return v5EA6TqHX3s4jzBMk(u"࠭ࠧཤ"),[BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠧࠨཥ")],[ items[C2dgEDAKQGsvh(u"࠱ᄑ")] ]
	else: return PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦ࡛ࠣࡎࡔࡔࡗࡎࡌ࡚ࡊ࠭ས"),[],[]
def Y0fRB6iE8TMgvdy7pJFHoaN2L(url):
	MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(f9Oum6c0FotxYn,url,YB5xyI7MaRslVpv(u"ࠩࠪཧ"),UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠪࠫཨ"),BoWHNb9daQVCF16A(u"ࠫࠬཀྵ"),jx7s8T0BFgODXLMzIYedf(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡕࡇࡍࡏࡖࡆ࠯࠴ࡷࡹ࠭ཪ"))
	items = My7Dwqvs6bfGNSIgX.findall(gItVahxL0w(u"࠭ࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫཫ"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if items:
		url = url = vvHpKfcqRnrFzjG(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡵࡧ࡭࡯ࡶࡦ࠰ࡲࡶ࡬࠭ཬ") + items[sRth5giAQzWlEVm7JOX(u"࠲ᄒ")]
		return QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠨࠩ཭"),[v5EA6TqHX3s4jzBMk(u"ࠩࠪ཮")],[ url ]
	else: return YB5xyI7MaRslVpv(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡇࡒࡄࡊࡌ࡚ࡊ࠭཯"),[],[]
def KLCHdjPzwSDxi9A72b3MBF5ec(url):
	MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(f9Oum6c0FotxYn,url,EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠫࠬ཰"),WMkAjB1RgN7q(u"ཱࠬ࠭"),BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ི࠭ࠧ"),YB5xyI7MaRslVpv(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡉࡘ࡚ࡒࡆࡃࡐ࠱࠶ࡹࡴࠨཱི"))
	items = My7Dwqvs6bfGNSIgX.findall(UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠨࡸ࡬ࡨࡪࡵࠠࡱࡴࡨࡰࡴࡧࡤ࠯ࠬࡂࡷࡷࡩ࠽࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨུ"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if items: return fY5wTlhtnOc0Er6sdy4k87b(u"ཱུࠩࠪ"),[UnWjVbo503mEMv9KF(u"ࠪࠫྲྀ")],[ items[EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠳ᄓ")] ]
	else: return hhlbF1Sns5TrEN8QPCYmL4(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡅࡔࡖࡕࡉࡆࡓࠧཷ"),[],[]
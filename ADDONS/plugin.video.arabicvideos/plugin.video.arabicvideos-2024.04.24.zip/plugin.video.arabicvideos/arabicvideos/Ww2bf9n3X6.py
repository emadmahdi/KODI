# -*- coding: utf-8 -*-
from G6AHskJeqN import *
baNWS6nfqTC5iX4Kl = 'LODYNET'
teUPLFC3B8bArakwHVGsdhoIWDM49f = '_LDN_'
EZxQp1WOldMTvFU = AK5RqLhji4W1wt9VdrCD3PGeQM[baNWS6nfqTC5iX4Kl][0]
eh2tDvRFWpLQI = ['الرئيسية','استفسارتكم و الطلبات']
def VbgEajY4Bt2COpGDcPqI(mode,url,text):
	if   mode==450: ft3e2JBKQVXWlFPjaMhkEqGxvDg = eN02L7Tf5bQ()
	elif mode==451: ft3e2JBKQVXWlFPjaMhkEqGxvDg = sscM839DP1jWZ4zl6uIx0Kyn(url,text)
	elif mode==452: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HDxCnPKFhITpZmOsA4a0UL6(url)
	elif mode==453: ft3e2JBKQVXWlFPjaMhkEqGxvDg = WWF1Rc6KZx(url)
	elif mode==454: ft3e2JBKQVXWlFPjaMhkEqGxvDg = o4oY13v5dWMcbilEDjKCnXNzHZ0(url)
	elif mode==459: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HjZcUIVAXFCqy9TfBWKtgY2(text)
	else: ft3e2JBKQVXWlFPjaMhkEqGxvDg = False
	return ft3e2JBKQVXWlFPjaMhkEqGxvDg
def eN02L7Tf5bQ():
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',EZxQp1WOldMTvFU,'','','','','LODYNET-MENU-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	xxE5BSyQkNsj = ooq2D9xF8ZLpPBs(EZxQp1WOldMTvFU,'url')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'بحث في الموقع','',459,'','','_REMEMBERRESULTS_')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'مثبتات لودي نت',xxE5BSyQkNsj,451,'','','featured')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'المضاف حديثا',xxE5BSyQkNsj,451,'','','latest')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"MainMenu"(.*?)"SiteSlider"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)">(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title in items:
			if BoEFz2WhUyvTgDeiZ=='#': continue
			if title in eh2tDvRFWpLQI: continue
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,451)
	return
def sscM839DP1jWZ4zl6uIx0Kyn(url,rwQsc9O3oGdFKbxPlNiM56S2pLUJ0=''):
	items = []
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'','','','','LODYNET-TITLES-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	if rwQsc9O3oGdFKbxPlNiM56S2pLUJ0=='featured':
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"SiteSlider"(.*?)"waves"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		vsptNMP2ZQC = XBuP6Op7y4K[0]
	elif rwQsc9O3oGdFKbxPlNiM56S2pLUJ0=='latest':
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"RecentPosts"(.*?)"pagination"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		vsptNMP2ZQC = XBuP6Op7y4K[0]
	elif '"ActorsList"' in MK6ZT2zjC1SbmveNFqor:
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"ActorsList"(.*?)"text/javascript"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)"(.*?)"ActorName">(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	elif rwQsc9O3oGdFKbxPlNiM56S2pLUJ0 in ['0','1','2']:
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"Section"(.*?)</li></ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		vsptNMP2ZQC = XBuP6Op7y4K[int(rwQsc9O3oGdFKbxPlNiM56S2pLUJ0)]
	else:
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"BlocksArea"(.*?)"text/javascript"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		vsptNMP2ZQC = XBuP6Op7y4K[0]
	if not items: items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?src="(.*?)".*?<h2>(.*?)</h2>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	y7y3d5Fbhv42ONmtwLZ0SerYoQq = []
	tkBQK76YMeUlRI1TomgECfA = ['مشاهدة','فيلم','اغنية','أغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for BoEFz2WhUyvTgDeiZ,IcWzVO137wFvemn2QTq8yKs9,title in items:
		if '"ActorsList"' in MK6ZT2zjC1SbmveNFqor and 'src=' in IcWzVO137wFvemn2QTq8yKs9:
			IcWzVO137wFvemn2QTq8yKs9 = My7Dwqvs6bfGNSIgX.findall('src="(.*?)"',IcWzVO137wFvemn2QTq8yKs9,My7Dwqvs6bfGNSIgX.DOTALL)
			IcWzVO137wFvemn2QTq8yKs9 = IcWzVO137wFvemn2QTq8yKs9[0]
		BoEFz2WhUyvTgDeiZ = XnQbsZF0Ouh8p7zCdUN(BoEFz2WhUyvTgDeiZ).strip('/')
		ffhN7jAqe3Q4cR0Ukptzl = My7Dwqvs6bfGNSIgX.findall('(.*?) حلقة \d+',title,My7Dwqvs6bfGNSIgX.DOTALL)
		if not ffhN7jAqe3Q4cR0Ukptzl: ffhN7jAqe3Q4cR0Ukptzl = My7Dwqvs6bfGNSIgX.findall('(.*?) الحلقة \d+',title,My7Dwqvs6bfGNSIgX.DOTALL)
		if set(title.split()) & set(tkBQK76YMeUlRI1TomgECfA) and 'مسلسل' not in title:
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,452,IcWzVO137wFvemn2QTq8yKs9)
		elif ffhN7jAqe3Q4cR0Ukptzl and 'حلقة' in title:
			title = '_MOD_' + ffhN7jAqe3Q4cR0Ukptzl[0]
			if title not in y7y3d5Fbhv42ONmtwLZ0SerYoQq:
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,453,IcWzVO137wFvemn2QTq8yKs9)
				y7y3d5Fbhv42ONmtwLZ0SerYoQq.append(title)
		else: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,453,IcWzVO137wFvemn2QTq8yKs9)
	if rwQsc9O3oGdFKbxPlNiM56S2pLUJ0 in ['','latest']:
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"pagination"(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if XBuP6Op7y4K:
			vsptNMP2ZQC = XBuP6Op7y4K[0]
			items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?>(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
			for BoEFz2WhUyvTgDeiZ,title in items:
				title = PIfAumbGicwg5ye(title)
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'صفحة '+title,BoEFz2WhUyvTgDeiZ,451)
	return
def WWF1Rc6KZx(url):
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'','','','','LODYNET-SEASONS-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	KRI8WExzA4p = My7Dwqvs6bfGNSIgX.findall('"CategorySubLinks"(.*?)</div>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if KRI8WExzA4p and 'href=' in str(KRI8WExzA4p):
		title = My7Dwqvs6bfGNSIgX.findall('<title>(.*?)-',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		title = title[0].strip(' ')
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,url,454)
		vsptNMP2ZQC = KRI8WExzA4p[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)">(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title in items:
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,454)
	else: o4oY13v5dWMcbilEDjKCnXNzHZ0(url)
	return
def o4oY13v5dWMcbilEDjKCnXNzHZ0(url):
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'','','','','LODYNET-EPISODES-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	kdYXhMN8Hpbt = My7Dwqvs6bfGNSIgX.findall('"BlocksArea"(.*?)"text/javascript"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if kdYXhMN8Hpbt:
		vsptNMP2ZQC = kdYXhMN8Hpbt[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?src="(.*?)".*?<h2>(.*?)</h2>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,IcWzVO137wFvemn2QTq8yKs9,title in items:
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,452,IcWzVO137wFvemn2QTq8yKs9)
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"pagination"(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if XBuP6Op7y4K:
			vsptNMP2ZQC = XBuP6Op7y4K[0]
			items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?>(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
			for BoEFz2WhUyvTgDeiZ,title in items:
				title = PIfAumbGicwg5ye(title)
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'صفحة '+title,BoEFz2WhUyvTgDeiZ,454)
	return
def HDxCnPKFhITpZmOsA4a0UL6(url):
	bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = url.replace('/movies/','/watch_movies/')
	bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = bJEs4IVAPdyUrhwCLv9k2YoOl8nt1.replace('/episodes/','/watch_episodes/')
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,'','','','','LODYNET-PLAY-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	xxE5BSyQkNsj = ooq2D9xF8ZLpPBs(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,'url')
	QQ2cE1FjUyxPonbDhaTkV6B3i = []
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"WatchTitle"(.*?)</aside>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('data-embed="(.*?)">(.*?)</li>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title in items:
			BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ+'?named='+title+'__watch'
			QQ2cE1FjUyxPonbDhaTkV6B3i.append(BoEFz2WhUyvTgDeiZ)
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"DownloadLinks"(.*?)"selary"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?<span>(.*?)</span>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,name in items:
			name = PIfAumbGicwg5ye(name)
			LLnUyuiC2wRM0 = My7Dwqvs6bfGNSIgX.findall('\d\d\d+',name,My7Dwqvs6bfGNSIgX.DOTALL)
			if LLnUyuiC2wRM0:
				LLnUyuiC2wRM0 = '____'+LLnUyuiC2wRM0[0]
				name = ''
			else: LLnUyuiC2wRM0 = ''
			BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ+'?named='+name+'__download'+LLnUyuiC2wRM0
			QQ2cE1FjUyxPonbDhaTkV6B3i.append(BoEFz2WhUyvTgDeiZ)
	import t1kDWXQVpC
	t1kDWXQVpC.rqVt2xDi7jzJHBcPMRs6h0L(QQ2cE1FjUyxPonbDhaTkV6B3i,baNWS6nfqTC5iX4Kl,'video',url)
	return
def HjZcUIVAXFCqy9TfBWKtgY2(search):
	search,LQf3AeozSrai,showDialogs = X54MLovbG8nAEkB9J(search)
	if search=='': search = ViKAIsLurq83RSENayxWb()
	if search=='': return
	search = search.replace(' ','+')
	url = EZxQp1WOldMTvFU+'/search/'+search
	sscM839DP1jWZ4zl6uIx0Kyn(url)
	return
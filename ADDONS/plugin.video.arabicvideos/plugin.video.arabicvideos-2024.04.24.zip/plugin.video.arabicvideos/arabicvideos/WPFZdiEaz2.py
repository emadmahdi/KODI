# -*- coding: utf-8 -*-
from G6AHskJeqN import *
baNWS6nfqTC5iX4Kl = 'EGYBEST4'
teUPLFC3B8bArakwHVGsdhoIWDM49f = '_EB4_'
EZxQp1WOldMTvFU = AK5RqLhji4W1wt9VdrCD3PGeQM[baNWS6nfqTC5iX4Kl][0]
eh2tDvRFWpLQI = ['ايجي بست','اتصل بنا','ايجي بست الاصلي','ايجي بست الجديد','ايجي بست البديل','egybest','موقع ايجي بست']
def VbgEajY4Bt2COpGDcPqI(mode,url,z3z9QgENFk5eMYB4,text):
	if   mode==800: ft3e2JBKQVXWlFPjaMhkEqGxvDg = eN02L7Tf5bQ()
	elif mode==801: ft3e2JBKQVXWlFPjaMhkEqGxvDg = sscM839DP1jWZ4zl6uIx0Kyn(url,z3z9QgENFk5eMYB4)
	elif mode==802: ft3e2JBKQVXWlFPjaMhkEqGxvDg = M25iOAH9NfalvyPEUuToG8qn(url)
	elif mode==803: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HDxCnPKFhITpZmOsA4a0UL6(url)
	elif mode==804: ft3e2JBKQVXWlFPjaMhkEqGxvDg = KLhEQr7SM4k6bfWeVaBy51sXpP(url)
	elif mode==806: ft3e2JBKQVXWlFPjaMhkEqGxvDg = rFZB0V49nigPyfKQHqcLXEs(url,z3z9QgENFk5eMYB4)
	elif mode==809: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HjZcUIVAXFCqy9TfBWKtgY2(text)
	else: ft3e2JBKQVXWlFPjaMhkEqGxvDg = False
	return ft3e2JBKQVXWlFPjaMhkEqGxvDg
def eN02L7Tf5bQ():
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'بحث في الموقع','',809,'','','_REMEMBERRESULTS_')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'فلتر',EZxQp1WOldMTvFU+'/trending',804,'','','_REMEMBERRESULTS_')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(IIiPCruL6dT8s1lqj47SzpVHnYNm,'GET',EZxQp1WOldMTvFU,'','','','','EGYBEST4-MENU-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('nav-categories(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)">(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title in items:
			title = title.strip(' ')
			if any(WoFrX46wzbCNp18 in title for WoFrX46wzbCNp18 in eh2tDvRFWpLQI): continue
			if 'http' not in BoEFz2WhUyvTgDeiZ: BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU+BoEFz2WhUyvTgDeiZ
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,801)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('mainContent(.*?)<footer>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('mainTitle.*?href="(.*?)".*?title="(.*?)"',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title in items:
			title = title.strip(' ')
			if any(WoFrX46wzbCNp18 in title for WoFrX46wzbCNp18 in eh2tDvRFWpLQI): continue
			if 'http' not in BoEFz2WhUyvTgDeiZ: BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU+BoEFz2WhUyvTgDeiZ
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,801,'','mainmenu')
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('main-menu(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)">(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title in items:
			title = title.strip(' ')
			if any(WoFrX46wzbCNp18 in title for WoFrX46wzbCNp18 in eh2tDvRFWpLQI): continue
			if 'http' not in BoEFz2WhUyvTgDeiZ: BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU+BoEFz2WhUyvTgDeiZ
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,801)
	return MK6ZT2zjC1SbmveNFqor
def rFZB0V49nigPyfKQHqcLXEs(url,type=''):
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'','','','','EGYBEST4-SEASONS_EPISODES-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('mainTitle.*?>(.*?)<(.*?)pageContent',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		Or0yBIEzGeCn6pkYDgRal78F,o93oJVvuQUY,items = '','',[]
		for name,vsptNMP2ZQC in XBuP6Op7y4K:
			if 'حلقات' in name: o93oJVvuQUY = vsptNMP2ZQC
			if 'مواسم' in name: Or0yBIEzGeCn6pkYDgRal78F = vsptNMP2ZQC
		if Or0yBIEzGeCn6pkYDgRal78F and not type:
			items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?img="(.*?)".*?"title">(.*?)<',Or0yBIEzGeCn6pkYDgRal78F,My7Dwqvs6bfGNSIgX.DOTALL)
			if len(items)>1:
				for BoEFz2WhUyvTgDeiZ,IcWzVO137wFvemn2QTq8yKs9,title in items:
					VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,806,IcWzVO137wFvemn2QTq8yKs9,'season')
		if o93oJVvuQUY and len(items)<2:
			items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?img="(.*?)".*?"title">(.*?)<',o93oJVvuQUY,My7Dwqvs6bfGNSIgX.DOTALL)
			if items:
				for BoEFz2WhUyvTgDeiZ,IcWzVO137wFvemn2QTq8yKs9,title in items:
					VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,803,IcWzVO137wFvemn2QTq8yKs9)
			else:
				items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)">(.*?)<',o93oJVvuQUY,My7Dwqvs6bfGNSIgX.DOTALL)
				for BoEFz2WhUyvTgDeiZ,title in items:
					VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,803)
	return
def sscM839DP1jWZ4zl6uIx0Kyn(url,type=''):
	qoR5F8fzNGvyY4dI6rjPOUlW,start,ssINGezFJnxfcU,select,r9ixWQPNzf4Be6TYqcHoRVwm8EM7a = 0,0,'','',''
	if 'pagination' in type:
		cpQysrOzk6K5PW,toAVQS46Fv8aJYyLf25KnkUNC = url.split('?next=page&')
		eIL9BxdTbZj = {'Content-Type':'application/x-www-form-urlencoded'}
		xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'POST',cpQysrOzk6K5PW,toAVQS46Fv8aJYyLf25KnkUNC,eIL9BxdTbZj,'','','EGYBEST4-TITLES-1st')
		MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
		wN6n7OZBoDkTvCi8LdbJjYV = 'secContent'+MK6ZT2zjC1SbmveNFqor+'<footer>'
	else:
		xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'','','','','EGYBEST4-TITLES-2nd')
		MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
		wN6n7OZBoDkTvCi8LdbJjYV = MK6ZT2zjC1SbmveNFqor
	items,LrPu5D8XJ1FpxhYvyz2l,PPebqkulZUsx3GCLdnYvR = [],False,False
	if not type and '/collections' not in url:
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('mainContent(.*?)</div>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if XBuP6Op7y4K:
			vsptNMP2ZQC = XBuP6Op7y4K[0]
			items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?</i>(.*?)</a>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
			for BoEFz2WhUyvTgDeiZ,title in items:
				title = title.strip(' ')
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,801,'','submenu')
				LrPu5D8XJ1FpxhYvyz2l = True
	if not LrPu5D8XJ1FpxhYvyz2l:
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('secContent(.*?)mainContent',wN6n7OZBoDkTvCi8LdbJjYV,My7Dwqvs6bfGNSIgX.DOTALL)
		if XBuP6Op7y4K:
			vsptNMP2ZQC = XBuP6Op7y4K[0]
			items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?img="(.*?)".*?"title">(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
			for BoEFz2WhUyvTgDeiZ,IcWzVO137wFvemn2QTq8yKs9,title in items:
				BoEFz2WhUyvTgDeiZ = XnQbsZF0Ouh8p7zCdUN(BoEFz2WhUyvTgDeiZ)
				IcWzVO137wFvemn2QTq8yKs9 = IcWzVO137wFvemn2QTq8yKs9.strip('\n')
				title = PIfAumbGicwg5ye(title)
				if '/series/' in BoEFz2WhUyvTgDeiZ and type=='season': VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,806,IcWzVO137wFvemn2QTq8yKs9,'season')
				elif '/series/' in BoEFz2WhUyvTgDeiZ: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,806,IcWzVO137wFvemn2QTq8yKs9)
				elif '/seasons/' in BoEFz2WhUyvTgDeiZ: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,801,IcWzVO137wFvemn2QTq8yKs9,'season')
				elif '/collections' in url: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,801,IcWzVO137wFvemn2QTq8yKs9,'collections')
				else: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,803,IcWzVO137wFvemn2QTq8yKs9)
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('loadMoreParams = (.*?);',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if XBuP6Op7y4K:
			vsptNMP2ZQC = XBuP6Op7y4K[0]
			xLTSPVp8zUgblio3vOq6sM027EF = dWsa2A0O4o5BYiqGXhyKEbM('dict',vsptNMP2ZQC)
			r9ixWQPNzf4Be6TYqcHoRVwm8EM7a = xLTSPVp8zUgblio3vOq6sM027EF['ajaxurl']
			c8xyLVFa6uoi = int(xLTSPVp8zUgblio3vOq6sM027EF['current_page'])+1
			iBf96x3loXqZp0mzcUQOVK5LyvAbtj = int(xLTSPVp8zUgblio3vOq6sM027EF['max_page'])
			TMkd3f1lhxvbsKWLeq4VGJN = xLTSPVp8zUgblio3vOq6sM027EF['posts'].replace('False','false').replace('True','true').replace('None','null')
			if c8xyLVFa6uoi<iBf96x3loXqZp0mzcUQOVK5LyvAbtj:
				toAVQS46Fv8aJYyLf25KnkUNC = 'action=loadmore&query='+F8fMqZKB4APk(TMkd3f1lhxvbsKWLeq4VGJN,'')+'&page='+str(c8xyLVFa6uoi)
				bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = r9ixWQPNzf4Be6TYqcHoRVwm8EM7a+'?next=page&'+toAVQS46Fv8aJYyLf25KnkUNC
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'جلب المزيد',bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,801,'','pagination_'+type)
		elif '?next=page&' in url:
			toAVQS46Fv8aJYyLf25KnkUNC,mfx4oMDwjFq3XTZiybLWRrk0pO = toAVQS46Fv8aJYyLf25KnkUNC.rsplit('=',1)
			mfx4oMDwjFq3XTZiybLWRrk0pO = int(mfx4oMDwjFq3XTZiybLWRrk0pO)+1
			bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = cpQysrOzk6K5PW+'?next=page&'+toAVQS46Fv8aJYyLf25KnkUNC+'='+str(mfx4oMDwjFq3XTZiybLWRrk0pO)
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'جلب المزيد',bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,801,'','pagination_'+type)
	return
def KLhEQr7SM4k6bfWeVaBy51sXpP(url):
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'','','','','EGYBEST4-FILTERS-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('sub_nav(.*?)secContent ',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		xAcIatGBYy0FLXroS1ig3Ts9KZ8P5 = My7Dwqvs6bfGNSIgX.findall('"current_opt">(.*?)<(.*?)</div>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for name,vsptNMP2ZQC in xAcIatGBYy0FLXroS1ig3Ts9KZ8P5:
			if 'التصنيف' in name: continue
			name = name.strip(' ')
			items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)">(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
			for BoEFz2WhUyvTgDeiZ,WoFrX46wzbCNp18 in items:
				title = name+':  '+WoFrX46wzbCNp18
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,801,'','filter')
	return
def HDxCnPKFhITpZmOsA4a0UL6(url):
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(SToQEHqGtMnAlFbCz4wxBDuOsmW7,'GET',url,'','','','','EGYBEST4-PLAY-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	ME2Q6F7u8Vp1km9ws = My7Dwqvs6bfGNSIgX.findall('<td>التصنيف</td>.*?">(.*?)<',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if ME2Q6F7u8Vp1km9ws and a97xrkSOefH5DbjXunq(baNWS6nfqTC5iX4Kl,url,ME2Q6F7u8Vp1km9ws): return
	Qki8AbTHYjzM2Ls76Gdr3eqo1Wn,uuseD16TiQ30VKlZxgm = [],[]
	lLawp58CZrkEozdDiPh7jRM3ceA = My7Dwqvs6bfGNSIgX.findall('postEmbed.*?post=(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if lLawp58CZrkEozdDiPh7jRM3ceA:
		NVHrZsqUp2 = NfzkjQicS24ZYLMWuXFRwV5Ea7.b64decode(lLawp58CZrkEozdDiPh7jRM3ceA[0])
		if BLz7m2RkNrxXQwy1cGAp: NVHrZsqUp2 = NVHrZsqUp2.decode('utf8')
		NVHrZsqUp2 = dWsa2A0O4o5BYiqGXhyKEbM('dict',NVHrZsqUp2)
		NVHrZsqUp2 = list(NVHrZsqUp2.values())
		for BoEFz2WhUyvTgDeiZ in NVHrZsqUp2:
			if BoEFz2WhUyvTgDeiZ not in uuseD16TiQ30VKlZxgm:
				uuseD16TiQ30VKlZxgm.append(BoEFz2WhUyvTgDeiZ)
				LkVZrOE4XBSN2Qex5PyHqC = ooq2D9xF8ZLpPBs(BoEFz2WhUyvTgDeiZ,'name')
				Qki8AbTHYjzM2Ls76Gdr3eqo1Wn.append(BoEFz2WhUyvTgDeiZ+'?named='+LkVZrOE4XBSN2Qex5PyHqC+'__watch')
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('pageContentDown(.*?)</table>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('<tr>.*?<td>[ a-zA-Z]*(\d{3,4})[ a-zA-Z]*</td>.*?href="(.*?)"',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for LLnUyuiC2wRM0,BoEFz2WhUyvTgDeiZ in items:
			if BoEFz2WhUyvTgDeiZ not in uuseD16TiQ30VKlZxgm:
				if '/?url=' in BoEFz2WhUyvTgDeiZ: BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ.split('/?url=')[1]
				uuseD16TiQ30VKlZxgm.append(BoEFz2WhUyvTgDeiZ)
				LkVZrOE4XBSN2Qex5PyHqC = ooq2D9xF8ZLpPBs(BoEFz2WhUyvTgDeiZ,'name')
				Qki8AbTHYjzM2Ls76Gdr3eqo1Wn.append(BoEFz2WhUyvTgDeiZ+'?named='+LkVZrOE4XBSN2Qex5PyHqC+'__download____'+LLnUyuiC2wRM0)
	import t1kDWXQVpC
	t1kDWXQVpC.rqVt2xDi7jzJHBcPMRs6h0L(Qki8AbTHYjzM2Ls76Gdr3eqo1Wn,baNWS6nfqTC5iX4Kl,'video',url)
	return
def HjZcUIVAXFCqy9TfBWKtgY2(search):
	search,LQf3AeozSrai,showDialogs = X54MLovbG8nAEkB9J(search)
	if not search: search = ViKAIsLurq83RSENayxWb()
	if not search: return
	ystIEd371fLkT50pcRUWi9olNDu = search.replace(' ','+')
	url = EZxQp1WOldMTvFU+'/?s='+ystIEd371fLkT50pcRUWi9olNDu
	sscM839DP1jWZ4zl6uIx0Kyn(url,'search')
	return
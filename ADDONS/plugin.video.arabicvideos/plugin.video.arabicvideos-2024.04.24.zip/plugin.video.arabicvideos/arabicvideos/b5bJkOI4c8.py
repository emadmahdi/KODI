# -*- coding: utf-8 -*-
from G6AHskJeqN import *
baNWS6nfqTC5iX4Kl = 'MOVS4U'
teUPLFC3B8bArakwHVGsdhoIWDM49f = '_M4U_'
EZxQp1WOldMTvFU = AK5RqLhji4W1wt9VdrCD3PGeQM[baNWS6nfqTC5iX4Kl][0]
eh2tDvRFWpLQI = ['انواع افلام','جودات افلام']
def VbgEajY4Bt2COpGDcPqI(mode,url,text):
	if   mode==380: ft3e2JBKQVXWlFPjaMhkEqGxvDg = eN02L7Tf5bQ()
	elif mode==381: ft3e2JBKQVXWlFPjaMhkEqGxvDg = sscM839DP1jWZ4zl6uIx0Kyn(url,text)
	elif mode==382: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HDxCnPKFhITpZmOsA4a0UL6(url)
	elif mode==383: ft3e2JBKQVXWlFPjaMhkEqGxvDg = o4oY13v5dWMcbilEDjKCnXNzHZ0(url)
	elif mode==389: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HjZcUIVAXFCqy9TfBWKtgY2(text)
	else: ft3e2JBKQVXWlFPjaMhkEqGxvDg = False
	return ft3e2JBKQVXWlFPjaMhkEqGxvDg
def eN02L7Tf5bQ():
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'بحث في الموقع','',389,'','','_REMEMBERRESULTS_')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'المميزة',EZxQp1WOldMTvFU,381,'','','featured')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'الجانبية',EZxQp1WOldMTvFU,381,'','','sider')
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(IIiPCruL6dT8s1lqj47SzpVHnYNm,'GET',EZxQp1WOldMTvFU,'','','','','MOVS4U-MENU-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	items = My7Dwqvs6bfGNSIgX.findall('<header>.*?<h2>(.*?)<',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	for DQlGE75goqn9fkJt0P8ihR in range(len(items)):
		title = items[DQlGE75goqn9fkJt0P8ihR]
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+title,EZxQp1WOldMTvFU,381,'','','latest'+str(DQlGE75goqn9fkJt0P8ihR))
	vsptNMP2ZQC = ''
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('class="menu"(.*?)id="contenedor"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K: vsptNMP2ZQC += XBuP6Op7y4K[0]
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('class="sidebar(.*?)aside',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K: vsptNMP2ZQC += XBuP6Op7y4K[0]
	items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)">(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	lErmvOQ4B6 = True
	for BoEFz2WhUyvTgDeiZ,title in items:
		title = PIfAumbGicwg5ye(title)
		if title=='الأعلى مشاهدة':
			if lErmvOQ4B6:
				title = 'الافلام '+title
				lErmvOQ4B6 = False
			else: title = 'المسلسلات '+title
		if title not in eh2tDvRFWpLQI:
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,381)
	return MK6ZT2zjC1SbmveNFqor
def sscM839DP1jWZ4zl6uIx0Kyn(url,type):
	vsptNMP2ZQC,items = [],[]
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'','','','','MOVS4U-TITLES-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	if type=='search':
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('class="search-page"(.*?)class="sidebar',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if XBuP6Op7y4K:
			vsptNMP2ZQC = XBuP6Op7y4K[0]
			items = My7Dwqvs6bfGNSIgX.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	elif type=='sider':
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('class="widget(.*?)class="widget',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		UbfIHgMwZAre = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?img src="(.*?)".*?<h3>(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		QQ2cE1FjUyxPonbDhaTkV6B3i,zY4Ib2VUSPeFEJMy9Rtij,wlfZEzuRyYLvrp = zip(*UbfIHgMwZAre)
		items = zip(zY4Ib2VUSPeFEJMy9Rtij,QQ2cE1FjUyxPonbDhaTkV6B3i,wlfZEzuRyYLvrp)
	elif type=='featured':
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('id="slider-movies-tvshows"(.*?)<header>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	elif 'latest' in type:
		DQlGE75goqn9fkJt0P8ihR = int(type[-1:])
		MK6ZT2zjC1SbmveNFqor = MK6ZT2zjC1SbmveNFqor.replace('<header>','<end><start>')
		MK6ZT2zjC1SbmveNFqor = MK6ZT2zjC1SbmveNFqor.replace('<div class="sidebar','<end><div class="sidebar')
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('<start>(.*?)<end>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		vsptNMP2ZQC = XBuP6Op7y4K[DQlGE75goqn9fkJt0P8ihR]
		if DQlGE75goqn9fkJt0P8ihR==2: items = My7Dwqvs6bfGNSIgX.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	else:
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('class="content"(.*?)class="(pagination|sidebar)',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if XBuP6Op7y4K:
			vsptNMP2ZQC = XBuP6Op7y4K[0][0]
			if '/collection/' in url:
				items = My7Dwqvs6bfGNSIgX.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
			elif '/quality/' in url:
				items = My7Dwqvs6bfGNSIgX.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	if not items and vsptNMP2ZQC:
		items = My7Dwqvs6bfGNSIgX.findall('img src="(.*?)".*?href=.*?href="(.*?)">(.*?)</div>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	y7y3d5Fbhv42ONmtwLZ0SerYoQq = []
	for IcWzVO137wFvemn2QTq8yKs9,BoEFz2WhUyvTgDeiZ,title in items:
		if 'serie' in title:
			title = My7Dwqvs6bfGNSIgX.findall('^(.*?)<.*?serie">(.*?)<',title,My7Dwqvs6bfGNSIgX.DOTALL)
			title = title[0][1]
			if title in y7y3d5Fbhv42ONmtwLZ0SerYoQq: continue
			y7y3d5Fbhv42ONmtwLZ0SerYoQq.append(title)
			title = '_MOD_'+title
		U2UaTcgBpsEZxKiRG1Xv8 = My7Dwqvs6bfGNSIgX.findall('^(.*?)<',title,My7Dwqvs6bfGNSIgX.DOTALL)
		if U2UaTcgBpsEZxKiRG1Xv8: title = U2UaTcgBpsEZxKiRG1Xv8[0]
		title = PIfAumbGicwg5ye(title)
		if '/tvshows/' in BoEFz2WhUyvTgDeiZ: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,383,IcWzVO137wFvemn2QTq8yKs9)
		elif '/episodes/' in BoEFz2WhUyvTgDeiZ: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,383,IcWzVO137wFvemn2QTq8yKs9)
		elif '/seasons/' in BoEFz2WhUyvTgDeiZ: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,383,IcWzVO137wFvemn2QTq8yKs9)
		elif '/collection/' in BoEFz2WhUyvTgDeiZ: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,381,IcWzVO137wFvemn2QTq8yKs9)
		else: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,382,IcWzVO137wFvemn2QTq8yKs9)
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('class="pagination".*?Page (.*?) of (.*?)<(.*?)</div>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		mBgChLXu2APer0a5H = XBuP6Op7y4K[0][0]
		aaqDKRmLGtrNZMfFgle56kCE = XBuP6Op7y4K[0][1]
		vsptNMP2ZQC = XBuP6Op7y4K[0][2]
		items = My7Dwqvs6bfGNSIgX.findall("href='(.*?)'.*?>(.*?)<",vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title in items:
			if title=='' or title==aaqDKRmLGtrNZMfFgle56kCE: continue
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'صفحة '+title,BoEFz2WhUyvTgDeiZ,381,'','',type)
		BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ.replace('/page/'+title+'/','/page/'+aaqDKRmLGtrNZMfFgle56kCE+'/')
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'اخر صفحة '+aaqDKRmLGtrNZMfFgle56kCE,BoEFz2WhUyvTgDeiZ,381,'','',type)
	return
def o4oY13v5dWMcbilEDjKCnXNzHZ0(url):
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'','','','','MOVS4U-EPISODES-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	ME2Q6F7u8Vp1km9ws = My7Dwqvs6bfGNSIgX.findall('class="C rated".*?>(.*?)<',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if ME2Q6F7u8Vp1km9ws and a97xrkSOefH5DbjXunq(baNWS6nfqTC5iX4Kl,url,ME2Q6F7u8Vp1km9ws,False):
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link',teUPLFC3B8bArakwHVGsdhoIWDM49f+'المسلسل للكبار والمبرمج منعه','',9999)
		return
	if '/episodes/' in url or '/tvshows/' in url:
		bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = My7Dwqvs6bfGNSIgX.findall('''class='item'><a href="(.*?)"''',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if bJEs4IVAPdyUrhwCLv9k2YoOl8nt1:
			bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = bJEs4IVAPdyUrhwCLv9k2YoOl8nt1[1]
			o4oY13v5dWMcbilEDjKCnXNzHZ0(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1)
			return
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('''class='episodios'(.*?)id="cast"''',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('''src='(.*?)'.*?class='numerando'>(.*?)<.*?href='(.*?)'>(.*?)<''',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for IcWzVO137wFvemn2QTq8yKs9,ffhN7jAqe3Q4cR0Ukptzl,BoEFz2WhUyvTgDeiZ,name in items:
			title = ffhN7jAqe3Q4cR0Ukptzl+' : '+name+' الحلقة'
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,382)
	return
def HDxCnPKFhITpZmOsA4a0UL6(url):
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'','','','','MOVS4U-PLAY-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	ME2Q6F7u8Vp1km9ws = My7Dwqvs6bfGNSIgX.findall('class="C rated".*?>(.*?)<',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if ME2Q6F7u8Vp1km9ws and a97xrkSOefH5DbjXunq(baNWS6nfqTC5iX4Kl,url,ME2Q6F7u8Vp1km9ws): return
	QQ2cE1FjUyxPonbDhaTkV6B3i = []
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('''id='player-option-1'(.*?)class=("sheader"|'pag_episodes')''',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0][0]
		items = My7Dwqvs6bfGNSIgX.findall("data-url='(.*?)'.*?class='server'>(.*?)<",vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title in items:
			BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ+'?named='+title+'__watch'
			QQ2cE1FjUyxPonbDhaTkV6B3i.append(BoEFz2WhUyvTgDeiZ)
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('class="remodal"(.*?)class="remodal-close"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('class="___dl_gdrive.*?href="(.*?)".*?">(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title in items:
			BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU+BoEFz2WhUyvTgDeiZ
			BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ+'?named='+title+'__download'
			QQ2cE1FjUyxPonbDhaTkV6B3i.append(BoEFz2WhUyvTgDeiZ)
	import t1kDWXQVpC
	t1kDWXQVpC.rqVt2xDi7jzJHBcPMRs6h0L(QQ2cE1FjUyxPonbDhaTkV6B3i,baNWS6nfqTC5iX4Kl,'video',url)
	return
def HjZcUIVAXFCqy9TfBWKtgY2(search):
	search,LQf3AeozSrai,showDialogs = X54MLovbG8nAEkB9J(search)
	if search=='': search = ViKAIsLurq83RSENayxWb()
	if search=='': return
	search = search.replace(' ','+')
	url = EZxQp1WOldMTvFU+'/?s='+search
	sscM839DP1jWZ4zl6uIx0Kyn(url,'search')
	return
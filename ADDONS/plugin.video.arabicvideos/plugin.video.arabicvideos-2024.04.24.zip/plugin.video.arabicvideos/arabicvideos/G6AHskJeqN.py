# -*- coding: utf-8 -*-
import sys as ehpURIi6QBDOGu8qj5EYzXrsWHJ7
hEJlvpt9LRO = ehpURIi6QBDOGu8qj5EYzXrsWHJ7.version_info [0] == 2
RrwvuxJ2OXsWnE9fzYNPDqS = 2048
pS1kDZ93ogBi50Hm7elLhEcyFfTx = 7
def E6Xo0wuA9fdQKlGOI (Ovquk0bMSPEL1ciQ73BJ2Ae):
	global Xb8HYvTBqV5RFAhE3KwMjC
	G4LMt9nR3Se6xWNpPuJd = ord (Ovquk0bMSPEL1ciQ73BJ2Ae [-1])
	qkDvfXryhi7cSz5Ee4AtVn0 = Ovquk0bMSPEL1ciQ73BJ2Ae [:-1]
	FEcyWfSHeL5Kotpx = G4LMt9nR3Se6xWNpPuJd % len (qkDvfXryhi7cSz5Ee4AtVn0)
	FPhirCoHEGw3I05B = qkDvfXryhi7cSz5Ee4AtVn0 [:FEcyWfSHeL5Kotpx] + qkDvfXryhi7cSz5Ee4AtVn0 [FEcyWfSHeL5Kotpx:]
	if hEJlvpt9LRO:
		ffWep5hGgyVTXHL1SM = unicode () .join ([unichr (ord (DDX7Qar0kqlIAKHdwnEh) - RrwvuxJ2OXsWnE9fzYNPDqS - (XapSRJwDcy5TEK0QHZr6n + G4LMt9nR3Se6xWNpPuJd) % pS1kDZ93ogBi50Hm7elLhEcyFfTx) for XapSRJwDcy5TEK0QHZr6n, DDX7Qar0kqlIAKHdwnEh in enumerate (FPhirCoHEGw3I05B)])
	else:
		ffWep5hGgyVTXHL1SM = str () .join ([chr (ord (DDX7Qar0kqlIAKHdwnEh) - RrwvuxJ2OXsWnE9fzYNPDqS - (XapSRJwDcy5TEK0QHZr6n + G4LMt9nR3Se6xWNpPuJd) % pS1kDZ93ogBi50Hm7elLhEcyFfTx) for XapSRJwDcy5TEK0QHZr6n, DDX7Qar0kqlIAKHdwnEh in enumerate (FPhirCoHEGw3I05B)])
	return eval (ffWep5hGgyVTXHL1SM)
fY5wTlhtnOc0Er6sdy4k87b,C2jP0iLNGKnHu9xp,UnWjVbo503mEMv9KF=E6Xo0wuA9fdQKlGOI,E6Xo0wuA9fdQKlGOI,E6Xo0wuA9fdQKlGOI
jx7s8T0BFgODXLMzIYedf,UxS67uoGThbMwnfNRzy4gajLd23JH,QynMHGWA0blfqTUdxRh5Jzi2t=UnWjVbo503mEMv9KF,C2jP0iLNGKnHu9xp,fY5wTlhtnOc0Er6sdy4k87b
jSu5Cg2Ub1OAkZVs8Yoz,V2RbfGOBdcA6l8NTsPWzEyvS7,LgpdP3UjFRnlX=QynMHGWA0blfqTUdxRh5Jzi2t,UxS67uoGThbMwnfNRzy4gajLd23JH,jx7s8T0BFgODXLMzIYedf
gItVahxL0w,BmcLzCFjuIrZP5fwXH18aN6YS,qbPw1d3KimF=LgpdP3UjFRnlX,V2RbfGOBdcA6l8NTsPWzEyvS7,jSu5Cg2Ub1OAkZVs8Yoz
EAc8h2sINroQYvR3WH06Ji7MVpn,vvHpKfcqRnrFzjG,l0WAe1f7Bpi5ZXk=qbPw1d3KimF,BmcLzCFjuIrZP5fwXH18aN6YS,gItVahxL0w
YB5xyI7MaRslVpv,PPNA7jWqZgDnXKVvtuai1kQdsEoMb0,BK9OvRSjZbtx7kYyop1u6zrE2QeiFI=l0WAe1f7Bpi5ZXk,vvHpKfcqRnrFzjG,EAc8h2sINroQYvR3WH06Ji7MVpn
sRth5giAQzWlEVm7JOX,WMkAjB1RgN7q,NVS30xAdRFMIw1n9CislkE2=BK9OvRSjZbtx7kYyop1u6zrE2QeiFI,PPNA7jWqZgDnXKVvtuai1kQdsEoMb0,YB5xyI7MaRslVpv
NB6ZDMqe91yfKQ240WpbIntjxiY5z,k5dztomYyN3H,T6wRistc1SCo4hqObgumK=NVS30xAdRFMIw1n9CislkE2,WMkAjB1RgN7q,sRth5giAQzWlEVm7JOX
RqldvxFuM5GEQ2HAz93o7afBb0,rbjsM8cRFiuA1,nr5mZG89ICi6cgt4MfLJa0=T6wRistc1SCo4hqObgumK,k5dztomYyN3H,NB6ZDMqe91yfKQ240WpbIntjxiY5z
hhlbF1Sns5TrEN8QPCYmL4,FGDJwkEbTB5SoXujs3f,BoWHNb9daQVCF16A=nr5mZG89ICi6cgt4MfLJa0,rbjsM8cRFiuA1,RqldvxFuM5GEQ2HAz93o7afBb0
v5EA6TqHX3s4jzBMk,C2dgEDAKQGsvh,b05yftsZ6NYgIKP=BoWHNb9daQVCF16A,FGDJwkEbTB5SoXujs3f,hhlbF1Sns5TrEN8QPCYmL4
from g9pDL1tYQU import *
import bidi.algorithm as mFS3RqXrOoUsMcx5GD0jKfI,bidi.mirror as V5ao9FGwjP1QpBndcTmHNXt,base64 as NfzkjQicS24ZYLMWuXFRwV5Ea7,requests as jYUlINd7Vk09LBeZFrunTaSgG
baNWS6nfqTC5iX4Kl = YB5xyI7MaRslVpv(u"ࠧࡍࡋࡅࡗ࡙࡝ࡏࠨ౿")
aaN3V2d6LKgSXOotH5n = {}
xx4viQhaOu6r0 = []
if BLz7m2RkNrxXQwy1cGAp:
	yef0QYHk1JaWrXKsUqNLnPwj3uDo = TZhCObz1wKHAV.translatePath(nr5mZG89ICi6cgt4MfLJa0(u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳ࡽࡨ࡭ࡤࠩಀ"))
	gK53PXkR96t7djpHeqEyL0 = TZhCObz1wKHAV.translatePath(FGDJwkEbTB5SoXujs3f(u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴࡮࡯࡮ࡧࠪಁ"))
	DbvFpXtLIqzmn7fyR6i = TZhCObz1wKHAV.translatePath(jx7s8T0BFgODXLMzIYedf(u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵࡬ࡰࡩࡳࡥࡹ࡮ࠧಂ"))
	VOtIzx9Mks5pl = XXRtDhYvWb35qnLBxIri7ScNUks0.path.join(gK53PXkR96t7djpHeqEyL0,PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭ಃ"),gItVahxL0w(u"ࠬࡊࡡࡵࡣࡥࡥࡸ࡫ࠧ಄"),UnWjVbo503mEMv9KF(u"࠭ࡁࡥࡦࡲࡲࡸ࠹࠳࠯ࡦࡥࠫಅ"))
	QSsM1G2TxwXoIh = XXRtDhYvWb35qnLBxIri7ScNUks0.path.join(gK53PXkR96t7djpHeqEyL0,sRth5giAQzWlEVm7JOX(u"ࠧࡶࡵࡨࡶࡩࡧࡴࡢࠩಆ"),QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠨࡆࡤࡸࡦࡨࡡࡴࡧࠪಇ"),NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࡙ࠩ࡭ࡪࡽࡍࡰࡦࡨࡷ࠻࠴ࡤࡣࠩಈ"))
	o1oN28gvAMLw5az = XXRtDhYvWb35qnLBxIri7ScNUks0.path.join(gK53PXkR96t7djpHeqEyL0,UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬಉ"),jx7s8T0BFgODXLMzIYedf(u"ࠫࡉࡧࡴࡢࡤࡤࡷࡪ࠭ಊ"),BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࡚ࠬࡥࡹࡶࡸࡶࡪࡹ࠱࠴࠰ࡧࡦࠬಋ"))
	OMFrsZopHK9m7w45bY01idRqBL = RqldvxFuM5GEQ2HAz93o7afBb0(u"ࡻࠧ࡝ࡷ࠳࠶ࡩ࠷ࠧಌ")
	from urllib.parse import quote as _pSB43T6lc10LbOYFqK
else:
	yef0QYHk1JaWrXKsUqNLnPwj3uDo = tUXmK5PeEH9SDq.translatePath(l0WAe1f7Bpi5ZXk(u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲ࡼࡧࡳࡣࠨ಍"))
	gK53PXkR96t7djpHeqEyL0 = tUXmK5PeEH9SDq.translatePath(FGDJwkEbTB5SoXujs3f(u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳࡭ࡵ࡭ࡦࠩಎ"))
	DbvFpXtLIqzmn7fyR6i = tUXmK5PeEH9SDq.translatePath(l0WAe1f7Bpi5ZXk(u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴ࡲ࡯ࡨࡲࡤࡸ࡭࠭ಏ"))
	VOtIzx9Mks5pl = XXRtDhYvWb35qnLBxIri7ScNUks0.path.join(gK53PXkR96t7djpHeqEyL0,k5dztomYyN3H(u"ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬಐ"),UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠫࡉࡧࡴࡢࡤࡤࡷࡪ࠭಑"),sRth5giAQzWlEVm7JOX(u"ࠬࡇࡤࡥࡱࡱࡷ࠷࠽࠮ࡥࡤࠪಒ"))
	QSsM1G2TxwXoIh = XXRtDhYvWb35qnLBxIri7ScNUks0.path.join(gK53PXkR96t7djpHeqEyL0,QynMHGWA0blfqTUdxRh5Jzi2t(u"࠭ࡵࡴࡧࡵࡨࡦࡺࡡࠨಓ"),RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠧࡅࡣࡷࡥࡧࡧࡳࡦࠩಔ"),k5dztomYyN3H(u"ࠨࡘ࡬ࡩࡼࡓ࡯ࡥࡧࡶ࠺࠳ࡪࡢࠨಕ"))
	o1oN28gvAMLw5az = XXRtDhYvWb35qnLBxIri7ScNUks0.path.join(gK53PXkR96t7djpHeqEyL0,UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫಖ"),LgpdP3UjFRnlX(u"ࠪࡈࡦࡺࡡࡣࡣࡶࡩࠬಗ"),LgpdP3UjFRnlX(u"࡙ࠫ࡫ࡸࡵࡷࡵࡩࡸ࠷࠳࠯ࡦࡥࠫಘ"))
	OMFrsZopHK9m7w45bY01idRqBL = T6wRistc1SCo4hqObgumK(u"ࡺ࠭࡜ࡶ࠲࠵ࡨ࠶࠭ಙ").encode(nr5mZG89ICi6cgt4MfLJa0(u"࠭ࡵࡵࡨ࠻ࠫಚ"))
	from urllib import quote as _pSB43T6lc10LbOYFqK
la7vIpTkr6w1ZW8XUNuCLKAMzi = XXRtDhYvWb35qnLBxIri7ScNUks0.path.join(DbvFpXtLIqzmn7fyR6i,YB5xyI7MaRslVpv(u"ࠧ࡬ࡱࡧ࡭࠳ࡲ࡯ࡨࠩಛ"))
WmQXf9gYFJckoUVN4LIuaBlbz = XXRtDhYvWb35qnLBxIri7ScNUks0.path.join(DbvFpXtLIqzmn7fyR6i,WMkAjB1RgN7q(u"ࠨ࡭ࡲࡨ࡮࠴࡯࡭ࡦ࠱ࡰࡴ࡭ࠧಜ"))
Hf6hzJEyo3xBV = XXRtDhYvWb35qnLBxIri7ScNUks0.path.join(IjYiO4u9HGmgw,v5EA6TqHX3s4jzBMk(u"ࠩ࡬ࡴࡹࡼ࠱ࡥࡣࡷࡥࡤࡥ࡟࠯ࡦࡥࠫಝ"))
cY1jEhtFDQ5urV62JwIGa4 = XXRtDhYvWb35qnLBxIri7ScNUks0.path.join(IjYiO4u9HGmgw,BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠪ࡭ࡵࡺࡶ࠳ࡦࡤࡸࡦࡥ࡟ࡠ࠰ࡧࡦࠬಞ"))
qjAo8OPDbGlsELmx = XXRtDhYvWb35qnLBxIri7ScNUks0.path.join(IjYiO4u9HGmgw,rbjsM8cRFiuA1(u"ࠫࡲ࠹ࡵࡥࡣࡷࡥࡤࡥ࡟࠯ࡦࡥࠫಟ"))
Z7A1STpeQGVJ = XXRtDhYvWb35qnLBxIri7ScNUks0.path.join(IjYiO4u9HGmgw,UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠬ࡬ࡡࡷࡱࡸࡶ࡮ࡺࡥࡴ࠰ࡧࡥࡹ࠭ಠ"))
veznPUcof0MuAIi73Sma = XXRtDhYvWb35qnLBxIri7ScNUks0.path.join(IjYiO4u9HGmgw,QynMHGWA0blfqTUdxRh5Jzi2t(u"࠭ࡩࡱࡶࡹࡪ࡮ࡲࡥࡠࡡࡢ࠲ࡩࡧࡴࠨಡ"))
LZ2ghOxQWdE3vco5eViyJ68Dn = XXRtDhYvWb35qnLBxIri7ScNUks0.path.join(IjYiO4u9HGmgw,LgpdP3UjFRnlX(u"ࠧ࡮࠵ࡸࡪ࡮ࡲࡥࡠࡡࡢ࠲ࡩࡧࡴࠨಢ"))
gcIBiFLSn0Hyb3joM15vPpwWJ = XXRtDhYvWb35qnLBxIri7ScNUks0.path.join(IjYiO4u9HGmgw,V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠨ࡫ࡰࡥ࡬࡫ࡳࠨಣ"))
hInCB0pQx69sW5HRmLow = XXRtDhYvWb35qnLBxIri7ScNUks0.path.join(gcIBiFLSn0Hyb3joM15vPpwWJ,vvHpKfcqRnrFzjG(u"ࠩࡧ࡭ࡦࡲ࡯ࡨࡵࠪತ"))
g8hAJGdbNesPyYErW0BfKa = XXRtDhYvWb35qnLBxIri7ScNUks0.path.join(hInCB0pQx69sW5HRmLow,nr5mZG89ICi6cgt4MfLJa0(u"ࠪࡨ࡮ࡧ࡬ࡰࡩࡢ࠴࠵࠶࠰ࡠ࠰ࡳࡲ࡬࠭ಥ"))
QgRBJhSGd4uX7i = OGJ60aCqcw4EvUBbxDMHkIYN.Addon().getAddonInfo(BoWHNb9daQVCF16A(u"ࠫࡵࡧࡴࡩࠩದ"))
pPQIefxX7FyvmAZbtRj = XXRtDhYvWb35qnLBxIri7ScNUks0.path.join(QgRBJhSGd4uX7i,UnWjVbo503mEMv9KF(u"ࠬ࡯ࡣࡰࡰ࠱ࡴࡳ࡭ࠧಧ"))
aVks5nZ3tMmCwI7zX9KfOqcQUH = XXRtDhYvWb35qnLBxIri7ScNUks0.path.join(QgRBJhSGd4uX7i,WMkAjB1RgN7q(u"࠭ࡴࡩࡷࡰࡦ࠳ࡶ࡮ࡨࠩನ"))
lawLYbnTSFkAV04hmfO5 = XXRtDhYvWb35qnLBxIri7ScNUks0.path.join(QgRBJhSGd4uX7i,V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠧࡧࡣࡱࡥࡷࡺ࠮ࡱࡰࡪࠫ಩"))
mSK4fLPqVJisj9dAIOv3nzErXBbF8 = XXRtDhYvWb35qnLBxIri7ScNUks0.path.join(QgRBJhSGd4uX7i,v5EA6TqHX3s4jzBMk(u"ࠨࡤࡤࡲࡳ࡫ࡲ࠯ࡲࡱ࡫ࠬಪ"))
fa98hqCrE2kweT3gZQ = XXRtDhYvWb35qnLBxIri7ScNUks0.path.join(QgRBJhSGd4uX7i,jx7s8T0BFgODXLMzIYedf(u"ࠩ࡯ࡥࡳࡪࡳࡤࡣࡳࡩ࠳ࡶ࡮ࡨࠩಫ"))
Vqaku0oRDbiJmCcdEKH28yPX7wY = XXRtDhYvWb35qnLBxIri7ScNUks0.path.join(QgRBJhSGd4uX7i,FGDJwkEbTB5SoXujs3f(u"ࠪࡴࡴࡹࡴࡦࡴ࠱ࡴࡳ࡭ࠧಬ"))
ARskT1fIxGDtCrNBv6PuhLX854JE = XXRtDhYvWb35qnLBxIri7ScNUks0.path.join(QgRBJhSGd4uX7i,UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠫࡨࡲࡥࡢࡴ࡯ࡳ࡬ࡵ࠮ࡱࡰࡪࠫಭ"))
aqcie5fsRvp6uItm = XXRtDhYvWb35qnLBxIri7ScNUks0.path.join(QgRBJhSGd4uX7i,BoWHNb9daQVCF16A(u"ࠬࡩ࡬ࡦࡣࡵࡥࡷࡺ࠮ࡱࡰࡪࠫಮ"))
BnmERuAU4zVg7HKJ3cs = XXRtDhYvWb35qnLBxIri7ScNUks0.path.join(QgRBJhSGd4uX7i,BoWHNb9daQVCF16A(u"࠭࡭ࡦࡰࡸ࠲ࡵࡴࡧࠨಯ"))
e9eWTrJdhbyOK5zg0BpL4xuv = XXRtDhYvWb35qnLBxIri7ScNUks0.path.join(QgRBJhSGd4uX7i,WMkAjB1RgN7q(u"ࠧࡤࡪࡤࡲ࡬࡫࡬ࡰࡩ࠱ࡸࡽࡺࠧರ"))
plygqUwWMPVORX0LYtejNDr8GI6bnK = XXRtDhYvWb35qnLBxIri7ScNUks0.path.join(gK53PXkR96t7djpHeqEyL0,PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠨࡣࡧࡨࡴࡴࡳࠨಱ"))
eKAwWngzpJDifIxT = XXRtDhYvWb35qnLBxIri7ScNUks0.path.join(gK53PXkR96t7djpHeqEyL0,UnWjVbo503mEMv9KF(u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫಲ"),qbPw1d3KimF(u"ࠪࡥࡩࡪ࡯࡯ࡡࡧࡥࡹࡧࠧಳ"),Kczs71doMyLHwN,BoWHNb9daQVCF16A(u"ࠫࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡸ࡮࡮ࠪ಴"))
s8sV4j7FOC0yvBctIe = XXRtDhYvWb35qnLBxIri7ScNUks0.path.join(yef0QYHk1JaWrXKsUqNLnPwj3uDo,T6wRistc1SCo4hqObgumK(u"ࠬࡳࡥࡥ࡫ࡤࠫವ"),qbPw1d3KimF(u"࠭ࡆࡰࡰࡷࡷࠬಶ"),RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠧࡢࡴ࡬ࡥࡱ࠴ࡴࡵࡨࠪಷ"))
HHm4q1SnPBZIf6wcap8zJoeDM7 = RqldvxFuM5GEQ2HAz93o7afBb0(u"࠸ᔘ")
iUgLYNaTzxo = [vvHpKfcqRnrFzjG(u"ࠨืไีࠬಸ"),NVS30xAdRFMIw1n9CislkE2(u"ࠩฦ์้࠭ಹ"),UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠪฯฬ์๊ࠨ಺"),fY5wTlhtnOc0Er6sdy4k87b(u"ࠫะอไฬࠩ಻"),PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠬืวษ฻಼ࠪ"),jx7s8T0BFgODXLMzIYedf(u"࠭ฮศ็ึࠫಽ"),WMkAjB1RgN7q(u"ࠧิษาืࠬಾ"),k5dztomYyN3H(u"ࠨีสฬ฾࠭ಿ"),PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠩฮห๊์ࠧೀ"),jSu5Cg2Ub1OAkZVs8Yoz(u"ࠪฮฬููࠨು"),FGDJwkEbTB5SoXujs3f(u"ࠫ฾อิาࠩೂ")]
TRC5Z9hlk6QxtcBrE = nr5mZG89ICi6cgt4MfLJa0(u"ࠬ⹁ࠠ⼞ࠢ⸭ࠤ⹀࠭ೃ")
j6kduJFMqPE5m38HspQwSgebr71 = [C2dgEDAKQGsvh(u"࡙࠭ࡕࡄࡢࡇࡍࡇࡎࡏࡇࡏࡗࠬೄ")]
GiYzPIubjTKaFCNdJ = [NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠧࡂࡔࡅࡐࡎࡕࡎ࡛ࠩ೅"),b05yftsZ6NYgIKP(u"ࠨࡃࡏࡏࡆ࡝ࡔࡉࡃࡕࠫೆ"),jSu5Cg2Ub1OAkZVs8Yoz(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࡙ࡍࡕ࠭ೇ"),YB5xyI7MaRslVpv(u"ࠪࡉࡌ࡟ࡄࡆࡃࡇࠫೈ"),l0WAe1f7Bpi5ZXk(u"ࠫࡒࡕࡖࡊ࡜ࡏࡅࡓࡊࠧ೉"),WMkAjB1RgN7q(u"ࠬࡓࡏࡗࡕ࠷࡙ࠬೊ"),UxS67uoGThbMwnfNRzy4gajLd23JH(u"࠭ࡍ࡚ࡅࡌࡑࡆ࠭ೋ"),k5dztomYyN3H(u"ࠧࡍࡃࡕࡓ࡟ࡇࠧೌ"),LgpdP3UjFRnlX(u"ࠨࡃࡏࡊࡆ࡚ࡉࡎࡋ್ࠪ"),WMkAjB1RgN7q(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠶ࠫ೎")]
GiYzPIubjTKaFCNdJ += [fY5wTlhtnOc0Er6sdy4k87b(u"ࠪࡌࡊࡒࡁࡍࠩ೏"),v5EA6TqHX3s4jzBMk(u"ࠫࡘࡋࡒࡊࡇࡖ࠸࡜ࡇࡔࡄࡊࠪ೐"),b05yftsZ6NYgIKP(u"ࠬࡇࡋࡐࡃࡐࡇࡆࡓࠧ೑"),v5EA6TqHX3s4jzBMk(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚ࠧ೒"),V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠧࡄࡋࡐࡅࡈࡒࡕࡑࠩ೓"),RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠨࡇࡊ࡝ࡓࡕࡗࠨ೔"),PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠩࡖࡌࡔࡕࡆࡑࡔࡒࠫೕ"),sRth5giAQzWlEVm7JOX(u"ࠪࡔࡆࡔࡅࡕࠩೖ"),NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠫࡈࡏࡍࡂ࠶ࡘࠫ೗"),v5EA6TqHX3s4jzBMk(u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡈࡗࡐࡔࡎࠫ೘")]
F3WquBa8osDVG6z9XhwNvEYI = [jx7s8T0BFgODXLMzIYedf(u"࠭ࡉࡑࡖ࡙ࠫ೙"),WMkAjB1RgN7q(u"ࠧࡊࡒࡗ࡚࠲ࡒࡉࡗࡇࠪ೚"),WMkAjB1RgN7q(u"ࠨࡋࡓࡘ࡛࠳ࡍࡐࡘࡌࡉࡘ࠭೛"),hhlbF1Sns5TrEN8QPCYmL4(u"ࠩࡌࡔ࡙࡜࠭ࡔࡇࡕࡍࡊ࡙ࠧ೜")]
F3WquBa8osDVG6z9XhwNvEYI += [gItVahxL0w(u"ࠪࡑ࠸࡛ࠧೝ"),FGDJwkEbTB5SoXujs3f(u"ࠫࡒ࠹ࡕ࠮ࡎࡌ࡚ࡊ࠭ೞ"),C2dgEDAKQGsvh(u"ࠬࡓ࠳ࡖ࠯ࡐࡓ࡛ࡏࡅࡔࠩ೟"),NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠭ࡍ࠴ࡗ࠰ࡗࡊࡘࡉࡆࡕࠪೠ")]
F3WquBa8osDVG6z9XhwNvEYI += [RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠧࡊࡈࡌࡐࡒ࠭ೡ"),LgpdP3UjFRnlX(u"ࠨࡋࡉࡍࡑࡓ࠭ࡂࡔࡄࡆࡎࡉࠧೢ"),BoWHNb9daQVCF16A(u"ࠩࡌࡊࡎࡒࡍ࠮ࡇࡑࡋࡑࡏࡓࡉࠩೣ")]
F3WquBa8osDVG6z9XhwNvEYI += [WMkAjB1RgN7q(u"ࠪࡅࡑࡇࡒࡂࡄࠪ೤"),hhlbF1Sns5TrEN8QPCYmL4(u"ࠫࡆࡑࡗࡂࡏࠪ೥"),vvHpKfcqRnrFzjG(u"ࠬࡇࡌࡎࡃࡄࡖࡊࡌࠧ೦"),qbPw1d3KimF(u"࠭ࡓࡉࡑࡒࡊࡒࡇࡘࠨ೧"),hhlbF1Sns5TrEN8QPCYmL4(u"ࠧࡂࡍࡒࡅࡒ࠭೨"),RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠨࡍࡄࡘࡐࡕࡔࡕࡘࠪ೩")]
F3WquBa8osDVG6z9XhwNvEYI += [BoWHNb9daQVCF16A(u"ࠩࡎࡅࡗࡈࡁࡍࡃࡗ࡚ࠬ೪"),LgpdP3UjFRnlX(u"ࠪࡆࡔࡑࡒࡂࠩ೫"),BoWHNb9daQVCF16A(u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠶࠭೬"),YB5xyI7MaRslVpv(u"ࠬࡇࡒࡂࡄࡌࡇ࡙ࡕࡏࡏࡕࠪ೭"),gItVahxL0w(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠱ࠨ೮"),fY5wTlhtnOc0Er6sdy4k87b(u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠳ࠩ೯")]
WWDMLct9dSelhuiHvTKbkXzC = [FGDJwkEbTB5SoXujs3f(u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩ೰"),rbjsM8cRFiuA1(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰࡚ࡎࡊࡅࡐࡕࠪೱ"),FGDJwkEbTB5SoXujs3f(u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱ࡕࡒࡁ࡚ࡎࡌࡗ࡙࡙ࠧೲ"),C2dgEDAKQGsvh(u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡉࡈࡂࡐࡑࡉࡑ࡙ࠧೳ")]
WWDMLct9dSelhuiHvTKbkXzC += [hhlbF1Sns5TrEN8QPCYmL4(u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐࠪ೴"),T6wRistc1SCo4hqObgumK(u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱࡛ࡏࡄࡆࡑࡖࠫ೵"),BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲ࡖࡌࡂ࡛ࡏࡍࡘ࡚ࡓࠨ೶"),LgpdP3UjFRnlX(u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡃࡉࡃࡑࡒࡊࡒࡓࠨ೷"),C2jP0iLNGKnHu9xp(u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡕࡑࡓࡍࡈ࡙ࠧ೸"),T6wRistc1SCo4hqObgumK(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡎࡌ࡚ࡊ࡙ࠧ೹")]
FFgVdSiY7PsMkAKZxJ5tCuyTj = [b05yftsZ6NYgIKP(u"ࠫࡋࡇࡊࡆࡔࡖࡌࡔ࡝ࠧ೺"),C2dgEDAKQGsvh(u"ࠬࡉࡉࡎࡃࡑࡓ࡜࠭೻"),rbjsM8cRFiuA1(u"࠭ࡌࡐࡆ࡜ࡒࡊ࡚ࠧ೼"),v5EA6TqHX3s4jzBMk(u"ࠧࡂࡔࡄࡆࡘࡋࡅࡅࠩ೽"),C2jP0iLNGKnHu9xp(u"ࠨࡕࡋࡅࡍࡏࡄࡏࡇ࡚ࡗࠬ೾")]
FFgVdSiY7PsMkAKZxJ5tCuyTj += [NVS30xAdRFMIw1n9CislkE2(u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘࠫ೿"),EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠪࡘ࡛ࡌࡕࡏࠩഀ"),BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠫ࡜ࡋࡃࡊࡏࡄࠫഁ"),C2dgEDAKQGsvh(u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡈࠧം")]
DuSHpYs3BTZUoXmJibWj2a = [UxS67uoGThbMwnfNRzy4gajLd23JH(u"࠭ࡃࡊࡏࡄࡅࡇࡊࡏࠨഃ"),WMkAjB1RgN7q(u"ࠧࡄࡋࡐࡅࡋࡇࡎࡔࠩഄ"),nr5mZG89ICi6cgt4MfLJa0(u"ࠨࡅࡌࡑࡆࡒࡉࡈࡊࡗࠫഅ"),qbPw1d3KimF(u"ࠩࡉࡓࡘ࡚ࡁࠨആ"),UnWjVbo503mEMv9KF(u"ࠪࡅࡍ࡝ࡁࡌࠩഇ"),BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠫࡋࡇࡂࡓࡃࡎࡅࠬഈ")]
DuSHpYs3BTZUoXmJibWj2a += [NVS30xAdRFMIw1n9CislkE2(u"࡙ࠬࡈࡐࡈࡋࡅࠬഉ"),hhlbF1Sns5TrEN8QPCYmL4(u"࠭ࡂࡓࡕࡗࡉࡏ࠭ഊ"),hhlbF1Sns5TrEN8QPCYmL4(u"࡚ࠧࡃࡔࡓ࡙࠭ഋ"),UnWjVbo503mEMv9KF(u"ࠨࡆࡕࡅࡒࡇࡓ࠸ࠩഌ"),EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠩࡆࡍࡒࡇ࠴࠱࠲ࠪ഍"),k5dztomYyN3H(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠸ࠬഎ"),EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠫࡍࡇࡌࡂࡅࡌࡑࡆ࠭ഏ")]
lMOnTZpS45a2jUqoYL8v9h0x3  = [RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠬࡇࡋࡘࡃࡐࠫഐ"),v5EA6TqHX3s4jzBMk(u"࠭ࡁࡍࡃࡕࡅࡇ࠭഑"),vvHpKfcqRnrFzjG(u"ࠧࡂࡔࡄࡆࡘࡋࡅࡅࠩഒ"),YB5xyI7MaRslVpv(u"ࠨࡄࡒࡏࡗࡇࠧഓ"),l0WAe1f7Bpi5ZXk(u"ࠩࡄࡏࡔࡇࡍࠨഔ"),PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠵ࠬക"),sRth5giAQzWlEVm7JOX(u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࠭ഖ"),C2dgEDAKQGsvh(u"ࠬࡌࡁࡃࡔࡄࡏࡆ࠭ഗ")]
lMOnTZpS45a2jUqoYL8v9h0x3 += [YB5xyI7MaRslVpv(u"࠭ࡃࡊࡏࡄࡊࡆࡔࡓࠨഘ"),YB5xyI7MaRslVpv(u"ࠧࡄࡋࡐࡅࡑࡏࡇࡉࡖࠪങ"),C2jP0iLNGKnHu9xp(u"ࠨࡅࡌࡑࡆࡔࡏࡘࠩച"),RqldvxFuM5GEQ2HAz93o7afBb0(u"࡚ࠩࡉࡈࡏࡍࡂࠩഛ"),b05yftsZ6NYgIKP(u"ࠪࡗࡍࡇࡈࡊࡆࡑࡉ࡜࡙ࠧജ"),UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠫࡋࡕࡓࡕࡃࠪഝ"),v5EA6TqHX3s4jzBMk(u"ࠬࡇࡈࡘࡃࡎࠫഞ")]
lMOnTZpS45a2jUqoYL8v9h0x3 += [LgpdP3UjFRnlX(u"࠭ࡆࡂࡌࡈࡖࡘࡎࡏࡘࠩട"),C2dgEDAKQGsvh(u"ࠧࡌࡃࡕࡆࡆࡒࡁࡕࡘࠪഠ"),BoWHNb9daQVCF16A(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠳ࠪഡ"),QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠵ࠫഢ"),NVS30xAdRFMIw1n9CislkE2(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠸ࠬണ"),BoWHNb9daQVCF16A(u"ࠫࡍࡇࡌࡂࡅࡌࡑࡆ࠭ത")]
lMOnTZpS45a2jUqoYL8v9h0x3 += [V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠬࡒࡏࡅ࡛ࡑࡉ࡙࠭ഥ"),WMkAjB1RgN7q(u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕࠨദ"),UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠧࡔࡊࡒࡓࡋࡓࡁ࡙ࠩധ"),NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠨࡖ࡙ࡊ࡚ࡔࠧന"),BoWHNb9daQVCF16A(u"ࠩࡆࡍࡒࡇࡁࡃࡆࡒࠫഩ"),YB5xyI7MaRslVpv(u"ࠪࡗࡍࡕࡆࡉࡃࠪപ")]
lMOnTZpS45a2jUqoYL8v9h0x3 += [b05yftsZ6NYgIKP(u"ࠫࡇࡘࡓࡕࡇࡍࠫഫ"),nr5mZG89ICi6cgt4MfLJa0(u"ࠬ࡟ࡁࡒࡑࡗࠫബ"),v5EA6TqHX3s4jzBMk(u"࠭ࡄࡓࡃࡐࡅࡘ࠽ࠧഭ"),WMkAjB1RgN7q(u"ࠧࡄࡋࡐࡅ࠹࠶࠰ࠨമ"),NVS30xAdRFMIw1n9CislkE2(u"ࠨࡃࡕࡅࡇࡏࡃࡕࡑࡒࡒࡘ࠭യ"),EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠩࡄࡐࡒࡇࡁࡓࡇࡉࠫര"),UnWjVbo503mEMv9KF(u"ࠪࡏࡆ࡚ࡋࡐࡖࡗ࡚ࠬറ")]
h7VEnSHOKTJNkC4Mdtolrbi  = [qbPw1d3KimF(u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯࡙ࡍࡉࡋࡏࡔࠩല"),b05yftsZ6NYgIKP(u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰ࡔࡑࡇ࡙ࡍࡋࡖࡘࡘ࠭ള"),RqldvxFuM5GEQ2HAz93o7afBb0(u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱ࡈࡎࡁࡏࡐࡈࡐࡘ࠭ഴ"),UnWjVbo503mEMv9KF(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲࡚ࡏࡑࡋࡆࡗࠬവ"),WMkAjB1RgN7q(u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡌࡊࡘࡈࡗࠬശ")]
h7VEnSHOKTJNkC4Mdtolrbi += [V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠩࡌࡊࡎࡒࡍ࠮ࡃࡕࡅࡇࡏࡃࠨഷ"),NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠪࡍࡋࡏࡌࡎ࠯ࡈࡒࡌࡒࡉࡔࡊࠪസ")]
h7VEnSHOKTJNkC4Mdtolrbi += [b05yftsZ6NYgIKP(u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲࡜ࡉࡅࡇࡒࡗࠬഹ"),jSu5Cg2Ub1OAkZVs8Yoz(u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡐࡍࡃ࡜ࡐࡎ࡙ࡔࡔࠩഺ"),jSu5Cg2Ub1OAkZVs8Yoz(u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡄࡊࡄࡒࡓࡋࡌࡔ഻ࠩ")]
h7VEnSHOKTJNkC4Mdtolrbi += [NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠧࡊࡒࡗ࡚࠲ࡒࡉࡗࡇ഼ࠪ"),sRth5giAQzWlEVm7JOX(u"ࠨࡋࡓࡘ࡛࠳ࡍࡐࡘࡌࡉࡘ࠭ഽ"),BoWHNb9daQVCF16A(u"ࠩࡌࡔ࡙࡜࠭ࡔࡇࡕࡍࡊ࡙ࠧാ")]
h7VEnSHOKTJNkC4Mdtolrbi += [jx7s8T0BFgODXLMzIYedf(u"ࠪࡑ࠸࡛࠭ࡍࡋ࡙ࡉࠬി"),T6wRistc1SCo4hqObgumK(u"ࠫࡒ࠹ࡕ࠮ࡏࡒ࡚ࡎࡋࡓࠨീ"),LgpdP3UjFRnlX(u"ࠬࡓ࠳ࡖ࠯ࡖࡉࡗࡏࡅࡔࠩു")]
FATYhcoXKzU = [UnWjVbo503mEMv9KF(u"࠭ࡍ࠴ࡗࠪൂ"),QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠧࡊࡒࡗ࡚ࠬൃ"),BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠭ൄ"),YB5xyI7MaRslVpv(u"ࠩࡌࡊࡎࡒࡍࠨ൅"),vvHpKfcqRnrFzjG(u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫെ")]
odSGnmzHxgF = lMOnTZpS45a2jUqoYL8v9h0x3+h7VEnSHOKTJNkC4Mdtolrbi
f4nPgrNMkXuoFbljyB6RWV = lMOnTZpS45a2jUqoYL8v9h0x3+FATYhcoXKzU
czHrbt5S1yNPB = lMOnTZpS45a2jUqoYL8v9h0x3+h7VEnSHOKTJNkC4Mdtolrbi
EeVF6sP7jzo3OJNBRM = F3WquBa8osDVG6z9XhwNvEYI+FFgVdSiY7PsMkAKZxJ5tCuyTj+DuSHpYs3BTZUoXmJibWj2a+WWDMLct9dSelhuiHvTKbkXzC
zzmwQTLFExKo63AJh = [
						BoWHNb9daQVCF16A(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࡙࠭ࡕࡋࡅࡗࡏࡎࡈ࠯࠴ࡷࡹ࠭േ")
						,NVS30xAdRFMIw1n9CislkE2(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡚ࡖࡌࡆࡘࡉࡏࡉ࠰࠶ࡳࡪࠧൈ")
						,l0WAe1f7Bpi5ZXk(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡐ࡙ࡑ࡚ࡉࡠ࡚ࡖࡌࡆࡘࡉࡏࡉ࠰࠵ࡸࡺࠧ൉")
						]
ANr5yaiVH3xW8YIJbCX6c = [
						v5EA6TqHX3s4jzBMk(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡕࡈࡒࡉࡥࡁࡏࡃࡏ࡝࡙ࡏࡃࡔࡡࡈ࡚ࡊࡔࡔ࠮࠳ࡶࡸࠬൊ")
						,FGDJwkEbTB5SoXujs3f(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡈ࡜࡙ࡘࡁࡄࡖࡢࡑ࠸࡛࠸࠮࠳ࡶࡸࠬോ")
						,k5dztomYyN3H(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡖࡆࡔࡄࡐࡏࡢ࡙ࡘࡋࡒࡂࡉࡈࡒ࡙࠳࠱ࡴࡶࠪൌ")
						,C2dgEDAKQGsvh(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡋࡔࡠࡒࡕࡓ࡝ࡏࡅࡔࡡࡏࡍࡘ࡚࠭࠲ࡵࡷ്ࠫ")
						,UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠫࡎࡖࡔࡗ࠯ࡆࡌࡊࡉࡋࡠࡃࡆࡇࡔ࡛ࡎࡕ࠯࠴ࡷࡹ࠭ൎ")
						,BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡆࡑࡏࡓࡈࡇࡔࡊࡑࡑ࠱࠶ࡹࡴࠨ൏")
						,b05yftsZ6NYgIKP(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡑࡒࡋࡑࡋ࡟ࡏࡇ࡚ࡣࡍࡕࡓࡕࡐࡄࡑࡊ࠳࠱ࡴࡶࠪ൐")
						,l0WAe1f7Bpi5ZXk(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡉࡒࡓࡌࡒࡅࡠࡐࡈ࡛ࡤࡎࡏࡔࡖࡑࡅࡒࡋ࠭࠴ࡴࡧࠫ൑")
						,FGDJwkEbTB5SoXujs3f(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡕࡉࡆࡊ࡟ࡂࡎࡏࡣࡆࡊࡄࡐࡐࡖࡣ࡝ࡓࡌ࠮࠳ࡶࡸࠬ൒")
						,NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡍࡏࡐࡉࡏࡉ࡚࡙ࡅࡓࡅࡒࡒ࡙ࡋࡎࡕ࠯࠴ࡷࡹ࠭൓")
						,C2dgEDAKQGsvh(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡂ࡚ࡒࡄࡗࡘࡥࡁࡌ࡙ࡄࡑࡤࡉࡁࡑࡖࡆࡌࡆ࠳࠳ࡳࡦࠪൔ")
						,v5EA6TqHX3s4jzBMk(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡃ࡛ࡓࡅࡘ࡙࡟ࡂࡍ࡚ࡅࡒࡥࡃࡂࡒࡗࡇࡍࡇ࠭࠶ࡶ࡫ࠫൕ")
						,gItVahxL0w(u"ࠬࡋࡌࡄࡋࡑࡉࡒࡇ࠭ࡔࡇࡄࡖࡈࡎ࠭࠲ࡵࡷࠫൖ")
						,sRth5giAQzWlEVm7JOX(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡛ࡗࡍࡇࡒࡊࡐࡊ࠱࠶ࡹࡴࠨൗ")
						,vvHpKfcqRnrFzjG(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡜ࡘࡎࡁࡓࡋࡑࡋ࠲࠸࡮ࡥࠩ൘")
						]
LMalnNAQePRTyUc2pm9FoKG = ANr5yaiVH3xW8YIJbCX6c+[
				 NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡓࡖࡔ࡞࡙ࡠࡖࡈࡗ࡙࠳࠱ࡴࡶࠪ൙")
				,nr5mZG89ICi6cgt4MfLJa0(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡓࡕࡋࡎࡖࡔࡏࡣࡍ࡚ࡔࡑࡕࡓࡖࡔ࡞ࡉࡆࡕ࠰࠵ࡸࡺࠧ൚")
				,EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤ࡝ࡅࡃࡒࡕࡓ࡝ࡏࡅࡔ࠯࠴ࡷࡹ࠭൛")
				,RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡕࡐࡆࡐࡘࡖࡑࡥࡗࡆࡄࡓࡖࡔ࡞ࡉࡆࡕ࠰࠶ࡳࡪࠧ൜")
				,YB5xyI7MaRslVpv(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡘࡇࡅࡔࡗࡕࡘ࡚ࡖࡒ࠱࠶ࡹࡴࠨ൝")
				,l0WAe1f7Bpi5ZXk(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠ࡙ࡈࡆࡕࡘࡏ࡙࡛ࡗࡓ࠲࠸࡮ࡥࠩ൞")
				,LgpdP3UjFRnlX(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡑࡓࡉࡓ࡛ࡒࡍࡡࡎࡔࡗࡕࡘ࡚ࡅࡒࡑ࠲࠷ࡳࡵࠩൟ")
				,RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢࡏࡕࡘࡏ࡙࡛ࡆࡓࡒ࠳࠲࡯ࡦࠪൠ")
				,NVS30xAdRFMIw1n9CislkE2(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡓࡕࡋࡎࡖࡔࡏࡣࡐࡖࡒࡐ࡚࡜ࡇࡔࡓ࠭࠴ࡴࡧࠫൡ")
				,YB5xyI7MaRslVpv(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡈࡎࡅࡄࡍࡢࡌ࡙࡚ࡐࡔࡡࡓࡖࡔ࡞ࡉࡆࡕ࠰࠵ࡸࡺࠧൢ")
				,WMkAjB1RgN7q(u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠳ࡈࡕࡖࡓࡗࡤ࡚ࡅࡔࡖ࠰࠵ࡸࡺࠧൣ")
				,EAc8h2sINroQYvR3WH06Ji7MVpn(u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙࠭ࡕࡇࡖࡘࡤࡇࡌࡍࡡ࡚ࡉࡇ࡙ࡉࡕࡇࡖ࠱࠶ࡹࡴࠨ൤")
				,b05yftsZ6NYgIKP(u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓ࠮ࡖࡈࡗ࡙ࡥࡁࡍࡎࡢ࡛ࡊࡈࡓࡊࡖࡈࡗ࠲࠸࡮ࡥࠩ൥")
				,BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࡘࡗࡆࡍࡅࡠࡔࡈࡔࡔࡘࡔ࠮࠳ࡶࡸࠬ൦")
				,YB5xyI7MaRslVpv(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡓࡔࡍࡌࡆࡡࡗࡖࡆࡔࡓࡍࡃࡗࡉ࠲࠷ࡳࡵࠩ൧")
				,C2jP0iLNGKnHu9xp(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡖࡊ࡜ࡅࡓࡕࡒࡣ࡙ࡘࡁࡏࡕࡏࡅ࡙ࡋ࠭࠲ࡵࡷࠫ൨")
				]
HcyxqSkeNf8ROumTbVKCZLjdvB2 = [RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠪ࠼࠳࠾࠮࠹࠰࠻ࠫ൩"),BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠫ࠶࠴࠱࠯࠳࠱࠵ࠬ൪"),rbjsM8cRFiuA1(u"ࠬ࠷࠮࠱࠰࠳࠲࠶࠭൫"),BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠭࠸࠯࠺࠱࠸࠳࠺ࠧ൬"),RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠧ࠳࠲࠻࠲࠻࠽࠮࠳࠴࠵࠲࠷࠸࠲ࠨ൭"),BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠨ࠴࠳࠼࠳࠼࠷࠯࠴࠵࠴࠳࠸࠲࠱ࠩ൮")]
AK5RqLhji4W1wt9VdrCD3PGeQM = {
			 C2dgEDAKQGsvh(u"ࠩࡄࡏࡔࡇࡍࠨ൯")		:[T6wRistc1SCo4hqObgumK(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡱ࠮ࡴࡸ࠲ࡳࡱࡪࠧ൰")]
			,NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠫࡆࡎࡗࡂࡍࠪ൱")		:[C2dgEDAKQGsvh(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡࡴ࠰ࡤ࡬ࡼࡧ࡫ࡵࡸ࠱ࡲࡪࡺࠧ൲")]
			,jSu5Cg2Ub1OAkZVs8Yoz(u"࠭ࡁࡌ࡙ࡄࡑࠬ൳")		:[T6wRistc1SCo4hqObgumK(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣ࡮࠲ࡸࡼࠧ൴")]
			,b05yftsZ6NYgIKP(u"ࠨࡃࡏࡅࡗࡇࡂࠨ൵")		:[V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡺࡴࡪ࠮ࡢ࡮ࡤࡶࡦࡨ࠮ࡤࡱࡰࠫ൶")]
			,LgpdP3UjFRnlX(u"ࠪࡅࡑࡌࡁࡕࡋࡐࡍࠬ൷")		:[nr5mZG89ICi6cgt4MfLJa0(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡦࡲࡦࡢࡶ࡬ࡱ࡮࠴ࡴࡷࠩ൸")]
			,qbPw1d3KimF(u"ࠬࡇࡌࡎࡃࡄࡖࡊࡌࠧ൹")		:[sRth5giAQzWlEVm7JOX(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢ࡮ࡰࡥࡦࡸࡥࡧ࠰ࡦ࡬ࠬൺ")]
			,FGDJwkEbTB5SoXujs3f(u"ࠧࡂࡔࡄࡆࡎࡉࡔࡐࡑࡑࡗࠬൻ")	:[QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳ࡧࡲࡢࡤ࡬ࡧ࠲ࡺ࡯ࡰࡰࡶ࠲ࡨࡵ࡭ࠨർ")]
			,PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠩࡄࡖࡆࡈࡓࡆࡇࡇࠫൽ")		:[BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡸࡡࡣࡵࡨࡩࡩ࠴࡮ࡦࡶࠪൾ")]
			,fY5wTlhtnOc0Er6sdy4k87b(u"ࠫࡇࡕࡋࡓࡃࠪൿ")		:[NVS30xAdRFMIw1n9CislkE2(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡹࡨࡰࡱࡩࡺࡴࡪ࠮ࡤࡱࡰࠫ඀")]
			,NVS30xAdRFMIw1n9CislkE2(u"࠭ࡂࡓࡕࡗࡉࡏ࠭ඁ")		:[T6wRistc1SCo4hqObgumK(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡤࡵࡷࡹ࡫ࡪ࠯ࡥࡲࡱࠬං")]
			,UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠨࡅࡌࡑࡆ࠺࠰࠱ࠩඃ")		:[vvHpKfcqRnrFzjG(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡧ࡮ࡳࡡ࠵࠲࠳࠲ࡨࡵ࡭ࠨ඄")]
			,BoWHNb9daQVCF16A(u"ࠪࡇࡎࡓࡁ࠵ࡗࠪඅ")		:[PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࠷ࡣࡪ࡯ࡤ࠸ࡺ࠴ࡣࡰ࡯ࠪආ")]
			,hhlbF1Sns5TrEN8QPCYmL4(u"ࠬࡉࡉࡎࡃࡄࡆࡉࡕࠧඇ")		:[fY5wTlhtnOc0Er6sdy4k87b(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡤ࡫ࡰࡥ࠸ࡨࡤࡰ࠰ࡦࡳࡲ࠭ඈ")]
			,FGDJwkEbTB5SoXujs3f(u"ࠧࡄࡋࡐࡅࡈࡒࡕࡃࠩඉ")		:[BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡦ࡭ࡲࡧࡣ࡭ࡷࡥ࠲ࡼࡧࡴࡤࡪࠪඊ")]
			,BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅ࡛ࡔࡘࡋࠨඋ")	:[BoWHNb9daQVCF16A(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡹࡼࡶ࠯ࡥ࡬ࡱࡦࡩ࡬ࡶࡤ࠱ࡷ࡭ࡵࡰࠨඌ")]
			,BoWHNb9daQVCF16A(u"ࠫࡈࡏࡍࡂࡈࡄࡒࡘ࠭ඍ")		:[BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡧ࡮ࡳࡡࡧࡣࡱࡷ࠳ࡩ࡯࡮ࠩඎ")]
			,RqldvxFuM5GEQ2HAz93o7afBb0(u"࠭ࡃࡊࡏࡄࡐࡎࡍࡈࡕࠩඏ")	:[v5EA6TqHX3s4jzBMk(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹ࠵࠺࠳ࡳࡹ࠮ࡥ࡬ࡱࡦ࠴࡮ࡦࡶࠪඐ")]
			,rbjsM8cRFiuA1(u"ࠨࡅࡌࡑࡆࡔࡏࡘࠩඑ")		:[gItVahxL0w(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡧ࡮ࡳࡡ࡯ࡱࡺ࠲ࡨࡩࠧඒ")]
			,BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎࠨඓ")	:[v5EA6TqHX3s4jzBMk(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴ࠮ࡤࡱࡰࠫඔ"),BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡧࡳࡣࡳ࡬ࡶࡲ࠮ࡢࡲ࡬࠲ࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯࠰ࡦࡳࡲ࠭ඕ")]
			,sRth5giAQzWlEVm7JOX(u"࠭ࡄࡓࡃࡐࡅࡘ࠽ࠧඖ")		:[LgpdP3UjFRnlX(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡦ࠲ࡩࡸࡡ࡮ࡣࡶ࠻࠳ࡩ࡯࡮ࠩ඗")]
			,QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠳ࠪ඘")		:[nr5mZG89ICi6cgt4MfLJa0(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩ࡬ࡿࡢࡦࡵࡷ࠲࡭ࡵ࡭ࡦࡵࠪ඙")]
			,BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠶ࠬක")		:[WMkAjB1RgN7q(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫ࡧࡺࡤࡨࡷࡹ࠴ࡷࡦࡤࡦࡥࡲ࠭ඛ")]
			,nr5mZG89ICi6cgt4MfLJa0(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠹ࠧග")		:[PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡪࡧࡪࡽࡧ࡫ࡳࡵ࠰ࡥ࡭ࡩ࠭ඝ")]
			,WMkAjB1RgN7q(u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠵ࠩඞ")		:[V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨ࡫ࡾ࠳ࡢࡦࡵࡷ࠲ࡳ࡫ࡴࠨඟ")]
			,UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠩࡈࡋ࡞ࡊࡅࡂࡆࠪච")		:[YB5xyI7MaRslVpv(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪ࡭ࡹࡥࡧࡤࡨ࠳ࡲࡩࡷࡧࠪඡ")]
			,l0WAe1f7Bpi5ZXk(u"ࠫࡊࡒࡃࡊࡐࡈࡑࡆ࠭ජ")		:[LgpdP3UjFRnlX(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥ࡭ࡥ࡬ࡲࡪࡳࡡ࠯ࡥࡲࡱࠬඣ")]
			,b05yftsZ6NYgIKP(u"࠭ࡆࡂࡄࡕࡅࡐࡇࠧඤ")		:[jSu5Cg2Ub1OAkZVs8Yoz(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡨࡤࡦࡷࡱࡡ࠯ࡥࡲࡱࠬඥ")]
			,k5dztomYyN3H(u"ࠨࡈࡄࡎࡊࡘࡓࡉࡑ࡚ࠫඦ")	:[BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡪࡦࡰࡥࡳ࠰ࡶ࡬ࡴࡽࠧට")]
			,UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠵ࠬඨ")		:[T6wRistc1SCo4hqObgumK(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡩࡥࡸ࡫࡬ࡩࡦࡺࡥࡹࡩࡨ࠯ࡶࡲࡴࠬඩ")]
			,LgpdP3UjFRnlX(u"ࠬࡌࡁࡔࡇࡏࡌࡉ࠸ࠧඪ")		:[C2dgEDAKQGsvh(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡵ࡯ࡥ࠳࡬ࡡࡴࡧ࡯࡬ࡩ࠴ࡣ࡭ࡱࡸࡨࠬණ")]
			,jSu5Cg2Ub1OAkZVs8Yoz(u"ࠧࡇࡑࡖࡘࡆ࠭ඬ")		:[T6wRistc1SCo4hqObgumK(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻ࡯࠴ࡦࡰࡵࡷࡥ࠲ࡺࡶ࠯ࡰࡨࡸࠬත")]
			,UnWjVbo503mEMv9KF(u"ࠩࡋࡅࡑࡇࡃࡊࡏࡄࠫථ")		:[PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡭ࡧ࡬ࡢࡥ࡬ࡱࡦ࠴࡭ࡦࡦ࡬ࡥࠬද")]
			,hhlbF1Sns5TrEN8QPCYmL4(u"ࠫࡎࡌࡉࡍࡏࠪධ")		:[v5EA6TqHX3s4jzBMk(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡࡳ࠰࡬ࡪ࡮ࡲ࡭ࡵࡸ࠱࡭ࡷ࠭න"),rbjsM8cRFiuA1(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦࡰ࠱࡭࡫࡯࡬࡮ࡶࡹ࠲࡮ࡸࠧ඲"),gItVahxL0w(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡨࡤ࠲࡮࡬ࡩ࡭࡯ࡷࡺ࠳࡯ࡲࠨඳ"),sRth5giAQzWlEVm7JOX(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡩࡥ࠷࠴ࡩࡧ࡫࡯ࡱࡹࡼ࠮ࡪࡴࠪප"),WMkAjB1RgN7q(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠼࠷࠳࠷࠹࠱࠰࠵࠸࠳࠷࠲࠳ࠩඵ")]
			,V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠪࡏࡆࡘࡂࡂࡎࡄࡘ࡛࠭බ")	:[NVS30xAdRFMIw1n9CislkE2(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱࡡࡳࡤࡤࡰࡦ࠳ࡴࡷ࠰࡬ࡵࠬභ")]
			,C2dgEDAKQGsvh(u"ࠬࡑࡁࡕࡍࡒࡘ࡙࡜ࠧම")		:[jx7s8T0BFgODXLMzIYedf(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡨࡱࡲ࠲ࡰ࡯ࡴ࡬ࡱࡷ࠲ࡹࡼࠧඹ")]
			,WMkAjB1RgN7q(u"ࠧࡌࡑࡇࡍࡊࡓࡁࡅࡡࡄࡔࡕ࠭ය")	:[FGDJwkEbTB5SoXujs3f(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡷ࡭ࡳࡿ࠮ࡤࡥ࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨࠬර"),V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳ࠳࠲࠴࠼࠳࡬ࡷࡴ࠰ࡶࡸࡴࡸࡥࠨ඼")]
			,FGDJwkEbTB5SoXujs3f(u"ࠪࡐࡔࡊ࡙ࡏࡇࡗࠫල")		:[EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡲ࡯ࡥࡻࡱࡩࡹ࠴ࡣࡢ࡯ࠪ඾")]
			,NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠬࡖࡁࡏࡇࡗࠫ඿")		:[UxS67uoGThbMwnfNRzy4gajLd23JH(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱ࡴࡦࡴࡥࡵ࠰ࡦࡳ࠳࡯࡬ࠨව")]
			,RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖࠩශ")		:[LgpdP3UjFRnlX(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡶ࡬ࡪ࠺ࡵ࠯ࡤࡨࡸࠬෂ")]
			,UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠩࡖࡌࡆࡎࡉࡅࡐࡈ࡛ࡘ࠭ස")	:[NVS30xAdRFMIw1n9CislkE2(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪ࠴ࡳࡩ࠶ࡸ࠲ࡳ࡫ࡷࡴࠩහ")]
			,WMkAjB1RgN7q(u"ࠫࡘࡎࡏࡇࡊࡄࠫළ")		:[nr5mZG89ICi6cgt4MfLJa0(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡶࡪࡦ࠱ࡷ࡭ࡵࡦࡩࡣ࠱ࡸࡻ࠭ෆ")]
			,EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠭ࡓࡉࡑࡒࡊࡒࡇࡘࠨ෇")		:[l0WAe1f7Bpi5ZXk(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡵ࡫ࡳࡴ࡬࡭ࡢࡺ࠱ࡧࡴࡳࠧ෈"),EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡶࡸࡦࡺࡩࡤ࠰ࡶ࡬ࡴࡵࡦ࡮ࡣࡻ࠲ࡨࡵ࡭ࠨ෉"),vvHpKfcqRnrFzjG(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡷ࡭ࡵ࡯ࡧ࡯ࡤࡼ࠳ࡧࡺࡶࡴࡨࡩࡩ࡭ࡥ࠯ࡰࡨࡸ්ࠬ")]
			,rbjsM8cRFiuA1(u"ࠪࡘ࡛ࡌࡕࡏࠩ෋")		:[C2dgEDAKQGsvh(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹ࠮ࡵࡸࡩࡹࡳ࠴࡭ࡦࠩ෌")]
			,EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠬ࡝ࡅࡄࡋࡐࡅࠬ෍")		:[QynMHGWA0blfqTUdxRh5Jzi2t(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡹࡰ࠰࠱࠲࠳࠭࠮ࡰࡽࡩࡧࡩࡡ࠶ࡩࡧ࠻ࡴࡪࡥ࠱ࡤ࡬࡫ࡱ࡮࠮࡮ࡻࡦ࡭࡮ࡳࡡ࠮ࡹࡨࡧ࡮࡯࡭ࡢ࠰ࡶ࡬ࡴࡶࠧ෎")]
			,fY5wTlhtnOc0Er6sdy4k87b(u"࡚ࠧࡃࡔࡓ࡙࠭ා")		:[T6wRistc1SCo4hqObgumK(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡼ࠲ࡾࡧࡱࡰࡶ࠱ࡸࡻ࠭ැ")]
			,vvHpKfcqRnrFzjG(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪෑ")		:[rbjsM8cRFiuA1(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡦࡳࡲ࠭ි")]
			,fY5wTlhtnOc0Er6sdy4k87b(u"ࠫࡗࡋࡐࡐࡕࠪී")		:[UnWjVbo503mEMv9KF(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡰࡨࡸࡱ࡯ࡦࡺ࠰ࡤࡴࡵ࠵ࡋࡐࡆࡌࡖࡊࡖࡏ࠰ࡃࡇࡈࡔࡔࡓ࠰ࡣࡧࡨࡴࡴࡳ࠯ࡺࡰࡰࠬු"),UxS67uoGThbMwnfNRzy4gajLd23JH(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡱࡩࡹࡲࡩࡧࡻ࠱ࡥࡵࡶ࠯ࡌࡑࡇࡍࡗࡋࡐࡐ࠱ࡄࡈࡉࡕࡎࡔ࠳࠻࠳ࡦࡪࡤࡰࡰࡶ࠵࠽࠴ࡸ࡮࡮ࠪ෕"),NVS30xAdRFMIw1n9CislkE2(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡲࡪࡺ࡬ࡪࡨࡼ࠲ࡦࡶࡰ࠰ࡍࡒࡈࡎࡘࡅࡑࡑ࠲ࡅࡉࡊࡏࡏࡕ࠴࠽࠴ࡧࡤࡥࡱࡱࡷ࠶࠿࠮ࡹ࡯࡯ࠫූ")]
			,WMkAjB1RgN7q(u"ࠨࡔࡈࡔࡔ࡙࡟ࡃࡍࡓࠫ෗")	:[l0WAe1f7Bpi5ZXk(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡲࡦࡲࡲ࠲ࡺࡱ࠮ࡵࡱ࠲ࡅࡉࡊࡏࡏࡕ࠲ࡥࡩࡪ࡯࡯ࡵ࠱ࡼࡲࡲࠧෘ"),NVS30xAdRFMIw1n9CislkE2(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡳࡧࡳࡳ࠳ࡻ࡫࠯ࡶࡲ࠳ࡆࡊࡄࡐࡐࡖ࠵࠽࠵ࡡࡥࡦࡲࡲࡸ࠷࠸࠯ࡺࡰࡰࠬෙ"),T6wRistc1SCo4hqObgumK(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡴࡨࡴࡴ࠴ࡵ࡬࠰ࡷࡳ࠴ࡇࡄࡅࡑࡑࡗ࠶࠿࠯ࡢࡦࡧࡳࡳࡹ࠱࠺࠰ࡻࡱࡱ࠭ේ")]
			,fY5wTlhtnOc0Er6sdy4k87b(u"࡙ࠬࡏࡖࡔࡆࡉࡘ࠭ෛ")		:[BmcLzCFjuIrZP5fwXH18aN6YS(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠱ࡴࡾࡺࡨࡰࡰࡤࡲࡾࡽࡨࡦࡴࡨ࠲ࡨࡵ࡭࠰࡭ࡲࡨ࡮࠭ො"),jSu5Cg2Ub1OAkZVs8Yoz(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡷࡺࡸࡧࡦ࠰ࡶ࡬ࠬෝ"),V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡳ࡫ࡴ࡭࡫ࡩࡽ࠳ࡧࡰࡱ࠱ࡎࡓࡉࡏࡒࡆࡒࡒࠫෞ")]
			}
if qbPw1d3KimF(u"࠵ᔙ"):
	AK5RqLhji4W1wt9VdrCD3PGeQM[v5EA6TqHX3s4jzBMk(u"ࠩࡓ࡝࡙ࡎࡏࡏࠩෟ")] = [fY5wTlhtnOc0Er6sdy4k87b(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲ࡰ࡮ࡹࡴࡱ࡮ࡤࡽࠬ෠"),RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡷࡧࡵࡧࡪࡲ࠮ࡢࡲࡳ࠳ࡺࡹࡡࡨࡧࡵࡩࡵࡵࡲࡵࠩ෡"),BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡸࡨࡶࡨ࡫࡬࠯ࡣࡳࡴ࠴ࡹࡥ࡯ࡦࡨࡱࡦ࡯࡬ࠨ෢"),YB5xyI7MaRslVpv(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵ࡧࡦࡶࡰࡩࡸࡹࡡࡨࡧࡶࠫ෣"),vvHpKfcqRnrFzjG(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡺࡪࡸࡣࡦ࡮࠱ࡥࡵࡶ࠯ࡨࡧࡷ࡭ࡸࡲࡡ࡮࡫ࡦࠫ෤"),sRth5giAQzWlEVm7JOX(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡻ࡫ࡲࡤࡧ࡯࠲ࡦࡶࡰ࠰ࡩࡨࡸࡶࡻࡥࡴࡶ࡬ࡳࡳࡹࠧ෥"),rbjsM8cRFiuA1(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡼࡥࡳࡥࡨࡰ࠳ࡧࡰࡱ࠱ࡪࡩࡹࡱ࡮ࡰࡹࡱࡩࡷࡸ࡯ࡳࡵࠪ෦"),LgpdP3UjFRnlX(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲ࡧࡦࡶࡴࡤࡪࡤࠫ෧"),BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡷࡧࡵࡧࡪࡲ࠮ࡢࡲࡳ࠳ࡹ࡫ࡳࡵ࡫ࡱ࡫ࠬ෨"),C2dgEDAKQGsvh(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡸࡨࡶࡨ࡫࡬࠯ࡣࡳࡴ࠴࡭ࡥࡵࡵ࡬ࡸࡪࡹࡵࡳ࡮ࡶࠫ෩")]
	AK5RqLhji4W1wt9VdrCD3PGeQM[jSu5Cg2Ub1OAkZVs8Yoz(u"࠭ࡐ࡚ࡖࡋࡓࡓࡥࡂࡌࡒࠪ෪")] = [FGDJwkEbTB5SoXujs3f(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡸ࡯࠳ࡺ࡯࠰࡮࡬ࡷࡹࡶ࡬ࡢࡻࠪ෫"),jx7s8T0BFgODXLMzIYedf(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡹࡰ࠴ࡴࡰ࠱ࡸࡷࡦ࡭ࡥࡳࡧࡳࡳࡷࡺࠧ෬"),BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡺࡱ࠮ࡵࡱ࠲ࡷࡪࡴࡤࡦ࡯ࡤ࡭ࡱ࠭෭"),LgpdP3UjFRnlX(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡻ࡫࠯ࡶࡲ࠳࡬࡫ࡴ࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩ෮"),gItVahxL0w(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡵ࡬࠰ࡷࡳ࠴࡭ࡥࡵ࡫ࡶࡰࡦࡳࡩࡤࠩ෯"),sRth5giAQzWlEVm7JOX(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡶ࡭࠱ࡸࡴ࠵ࡧࡦࡶࡴࡹࡪࡹࡴࡪࡱࡱࡷࠬ෰"),LgpdP3UjFRnlX(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡷ࡮࠲ࡹࡵ࠯ࡨࡧࡷ࡯ࡳࡵࡷ࡯ࡧࡵࡶࡴࡸࡳࠨ෱"),l0WAe1f7Bpi5ZXk(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡸ࡯࠳ࡺ࡯࠰ࡥࡤࡴࡹࡩࡨࡢࠩෲ"),gItVahxL0w(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡹࡰ࠴ࡴࡰ࠱ࡷࡩࡸࡺࡩ࡯ࡩࠪෳ"),nr5mZG89ICi6cgt4MfLJa0(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡺࡱ࠮ࡵࡱ࠲࡫ࡪࡺࡳࡪࡶࡨࡷࡺࡸ࡬ࡴࠩ෴")]
else:
	AK5RqLhji4W1wt9VdrCD3PGeQM[k5dztomYyN3H(u"ࠪࡔ࡞࡚ࡈࡐࡐࠪ෵")] = [l0WAe1f7Bpi5ZXk(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡲࡩࡴࡶࡳࡰࡦࡿࠧ෶"),gItVahxL0w(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡵࡴࡣࡪࡩࡷ࡫ࡰࡰࡴࡷࠫ෷"),l0WAe1f7Bpi5ZXk(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡴࡧࡱࡨࡪࡳࡡࡪ࡮ࠪ෸"),T6wRistc1SCo4hqObgumK(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸࡲ࡫ࡳࡴࡣࡪࡩࡸ࠭෹"),C2dgEDAKQGsvh(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹ࡯ࡳ࡭ࡣࡰ࡭ࡨ࠭෺"),FGDJwkEbTB5SoXujs3f(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺࡱࡶࡧࡶࡸ࡮ࡵ࡮ࡴࠩ෻"),b05yftsZ6NYgIKP(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴ࡬ࡰࡲࡻࡳ࡫ࡲࡳࡱࡵࡷࠬ෼"),NVS30xAdRFMIw1n9CislkE2(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡩࡡࡱࡶࡦ࡬ࡦ࠭෽"),UnWjVbo503mEMv9KF(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡴࡦࡵࡷ࡭ࡳ࡭ࠧ෾"),BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷࡷ࡮ࡺࡥࡴࡷࡵࡰࡸ࠭෿")]
	AK5RqLhji4W1wt9VdrCD3PGeQM[BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠧࡑ࡛ࡗࡌࡔࡔ࡟ࡃࡍࡓࠫ฀")] = [l0WAe1f7Bpi5ZXk(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱࡯࡭ࡸࡺࡰ࡭ࡣࡼࠫก"),V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡹࡸࡧࡧࡦࡴࡨࡴࡴࡸࡴࠨข"),NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡸ࡫࡮ࡥࡧࡰࡥ࡮ࡲࠧฃ"),jx7s8T0BFgODXLMzIYedf(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵ࡯ࡨࡷࡸࡧࡧࡦࡵࠪค"),BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶ࡬ࡷࡱࡧ࡭ࡪࡥࠪฅ"),v5EA6TqHX3s4jzBMk(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ࠭ฆ"),T6wRistc1SCo4hqObgumK(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸࡰࡴ࡯ࡸࡰࡨࡶࡷࡵࡲࡴࠩง"),BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡦࡥࡵࡺࡣࡩࡣࠪจ"),NVS30xAdRFMIw1n9CislkE2(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡸࡪࡹࡴࡪࡰࡪࠫฉ"),vvHpKfcqRnrFzjG(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴࡴ࡫ࡷࡩࡸࡻࡲ࡭ࡵࠪช")]
JZsTvyp54E37Mf6ASIhU = [BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠫࡑࡏࡓࡕࡒࡏࡅ࡞࠭ซ"),jx7s8T0BFgODXLMzIYedf(u"ࠬࡘࡅࡑࡑࡕࡘࡘ࠭ฌ"),hhlbF1Sns5TrEN8QPCYmL4(u"࠭ࡅࡎࡃࡌࡐࡘ࠭ญ"),BoWHNb9daQVCF16A(u"ࠧࡎࡇࡖࡗࡆࡍࡅࡔࠩฎ"),hhlbF1Sns5TrEN8QPCYmL4(u"ࠨࡋࡖࡐࡆࡓࡉࡄࡕࠪฏ"),YB5xyI7MaRslVpv(u"ࠩࡔ࡙ࡊ࡙ࡔࡊࡑࡑࡗࠬฐ"),WMkAjB1RgN7q(u"ࠪࡏࡓࡕࡗࡏࡇࡕࡖࡔࡘࡓࠨฑ"),LgpdP3UjFRnlX(u"ࠫࡈࡇࡐࡕࡅࡋࡅࠬฒ"),NVS30xAdRFMIw1n9CislkE2(u"࡚ࠬࡅࡔࡖࡌࡒࡌ࠭ณ"),FGDJwkEbTB5SoXujs3f(u"࠭ࡓࡊࡖࡈࡗ࡚ࡘࡌࡔࠩด")]
cGLksumPzEjOWMvNe1l2F5C3hB4t = [NVS30xAdRFMIw1n9CislkE2(u"ࠧࡂࡆࡇࡓࡓ࡙ࠧต"),UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠨࡃࡇࡈࡔࡔࡓ࠲࠺ࠪถ"),WMkAjB1RgN7q(u"ࠩࡄࡈࡉࡕࡎࡔ࠳࠼ࠫท")]
class FpTnboD75R8hgcuqCJ4NjQ(WCMztebpRjHu8LnvXUJq6IOi2):
	def __init__(LtRNhYpbuV5lzG7,*aargs,**kkwargs):
		LtRNhYpbuV5lzG7.choiceID = -qbPw1d3KimF(u"࠶ᔚ")
	def onClick(LtRNhYpbuV5lzG7,CgRMV6OpfumiJvw):
		if CgRMV6OpfumiJvw>=k5dztomYyN3H(u"࠿࠰࠲࠲ᔛ"): LtRNhYpbuV5lzG7.choiceID = CgRMV6OpfumiJvw-k5dztomYyN3H(u"࠿࠰࠲࠲ᔛ")
		LtRNhYpbuV5lzG7.vupOEiRhMNsJlez()
	def pjPrKJvlHgTGF0fwhVX3es(LtRNhYpbuV5lzG7,*aargs):
		LtRNhYpbuV5lzG7.button0,LtRNhYpbuV5lzG7.button1,LtRNhYpbuV5lzG7.button2 = aargs[rbjsM8cRFiuA1(u"࠱ᔝ")],aargs[EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠱ᔜ")],aargs[BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠴ᔞ")]
		LtRNhYpbuV5lzG7.header,LtRNhYpbuV5lzG7.text = aargs[b05yftsZ6NYgIKP(u"࠶ᔟ")],aargs[C2dgEDAKQGsvh(u"࠸ᔠ")]
		LtRNhYpbuV5lzG7.profile,LtRNhYpbuV5lzG7.direction = aargs[BmcLzCFjuIrZP5fwXH18aN6YS(u"࠺ᔡ")],aargs[WMkAjB1RgN7q(u"࠼ᔢ")]
		LtRNhYpbuV5lzG7.buttonstimeout,LtRNhYpbuV5lzG7.closetimeout = aargs[hhlbF1Sns5TrEN8QPCYmL4(u"࠸ᔤ")],aargs[gItVahxL0w(u"࠸ᔣ")]
		if LtRNhYpbuV5lzG7.buttonstimeout>qbPw1d3KimF(u"࠲ᔥ") or LtRNhYpbuV5lzG7.closetimeout>qbPw1d3KimF(u"࠲ᔥ"): LtRNhYpbuV5lzG7.enable_progressbar = FGDJwkEbTB5SoXujs3f(u"ࡘࡷࡻࡥខ")
		else: LtRNhYpbuV5lzG7.enable_progressbar = C2jP0iLNGKnHu9xp(u"ࡋࡧ࡬ࡴࡧគ")
		LtRNhYpbuV5lzG7.image_filename = g8hAJGdbNesPyYErW0BfKa.replace(BoWHNb9daQVCF16A(u"ࠪࡣ࠵࠶࠰࠱ࡡࠪธ"),k5dztomYyN3H(u"ࠫࡤ࠭น")+str(KBxPW9cX8dqtaUDG.time())+v5EA6TqHX3s4jzBMk(u"ࠬࡥࠧบ"))
		LtRNhYpbuV5lzG7.image_filename = LtRNhYpbuV5lzG7.image_filename.replace(YB5xyI7MaRslVpv(u"࠭࡜࡝ࠩป"),T6wRistc1SCo4hqObgumK(u"ࠧ࡝࡞࡟ࡠࠬผ")).replace(V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠨ࠱࠲ࠫฝ"),k5dztomYyN3H(u"ࠩ࠲࠳࠴࠵ࠧพ"))
		LtRNhYpbuV5lzG7.image_height = OWF8qHVQx7Ci(LtRNhYpbuV5lzG7.button0,LtRNhYpbuV5lzG7.button1,LtRNhYpbuV5lzG7.button2,LtRNhYpbuV5lzG7.header,LtRNhYpbuV5lzG7.text,LtRNhYpbuV5lzG7.profile,LtRNhYpbuV5lzG7.direction,LtRNhYpbuV5lzG7.enable_progressbar,LtRNhYpbuV5lzG7.image_filename)
		LtRNhYpbuV5lzG7.show()
		LtRNhYpbuV5lzG7.getControl(PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"࠼࠴࠺࠶ᔦ")).setImage(LtRNhYpbuV5lzG7.image_filename)
		LtRNhYpbuV5lzG7.getControl(nr5mZG89ICi6cgt4MfLJa0(u"࠽࠵࠻࠰ᔧ")).setHeight(LtRNhYpbuV5lzG7.image_height)
		if not LtRNhYpbuV5lzG7.button1 and LtRNhYpbuV5lzG7.button0 and LtRNhYpbuV5lzG7.button2: LtRNhYpbuV5lzG7.getControl(C2jP0iLNGKnHu9xp(u"࠿࠰࠲࠴ᔩ")).setPosition(-EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠲࠳࠲ᔪ"),RqldvxFuM5GEQ2HAz93o7afBb0(u"࠵ᔨ"))
		return LtRNhYpbuV5lzG7.image_filename,LtRNhYpbuV5lzG7.image_height
	def yW3zaDkOu79SU8ZVlEhM5omFTpwNA(LtRNhYpbuV5lzG7):
		if LtRNhYpbuV5lzG7.buttonstimeout:
			LtRNhYpbuV5lzG7.th1 = iDocG6BXv7fT2z8UVOxgP.Thread(target=LtRNhYpbuV5lzG7.DfzkVpwNS1ghEnclYimP,args=())
			LtRNhYpbuV5lzG7.th1.start()
		else: LtRNhYpbuV5lzG7.mMTbJKVkdHEPu70R1wfxo4yDqhg()
	def DfzkVpwNS1ghEnclYimP(LtRNhYpbuV5lzG7):
		LtRNhYpbuV5lzG7.getControl(sRth5giAQzWlEVm7JOX(u"࠺࠲࠵࠴ᔫ")).setEnabled(UxS67uoGThbMwnfNRzy4gajLd23JH(u"࡚ࡲࡶࡧឃ"))
		for k3Om08MCgqQao4n1 in range(hhlbF1Sns5TrEN8QPCYmL4(u"࠳ᔬ"),LtRNhYpbuV5lzG7.buttonstimeout+hhlbF1Sns5TrEN8QPCYmL4(u"࠳ᔬ")):
			KBxPW9cX8dqtaUDG.sleep(C2dgEDAKQGsvh(u"࠴ᔭ"))
			E3unjcqAOK2Tz7V8iPCSGF5 = int(BoWHNb9daQVCF16A(u"࠵࠵࠶ᔮ")*k3Om08MCgqQao4n1/LtRNhYpbuV5lzG7.buttonstimeout)
			LtRNhYpbuV5lzG7.pLukQXhj0rPe(E3unjcqAOK2Tz7V8iPCSGF5)
			if LtRNhYpbuV5lzG7.choiceID>hhlbF1Sns5TrEN8QPCYmL4(u"࠵ᔯ"): break
		LtRNhYpbuV5lzG7.mMTbJKVkdHEPu70R1wfxo4yDqhg()
	def sWAaHXdOP8(LtRNhYpbuV5lzG7):
		if LtRNhYpbuV5lzG7.closetimeout:
			LtRNhYpbuV5lzG7.th2 = iDocG6BXv7fT2z8UVOxgP.Thread(target=LtRNhYpbuV5lzG7.SCelmNajfTu,args=())
			LtRNhYpbuV5lzG7.th2.start()
		else: LtRNhYpbuV5lzG7.mMTbJKVkdHEPu70R1wfxo4yDqhg()
	def SCelmNajfTu(LtRNhYpbuV5lzG7):
		LtRNhYpbuV5lzG7.getControl(k5dztomYyN3H(u"࠿࠰࠳࠲ᔰ")).setEnabled(BmcLzCFjuIrZP5fwXH18aN6YS(u"ࡔࡳࡷࡨង"))
		KBxPW9cX8dqtaUDG.sleep(LtRNhYpbuV5lzG7.buttonstimeout)
		for k3Om08MCgqQao4n1 in range(LtRNhYpbuV5lzG7.closetimeout-sRth5giAQzWlEVm7JOX(u"࠱ᔱ"),-sRth5giAQzWlEVm7JOX(u"࠱ᔱ"),-sRth5giAQzWlEVm7JOX(u"࠱ᔱ")):
			KBxPW9cX8dqtaUDG.sleep(gItVahxL0w(u"࠲ᔲ"))
			E3unjcqAOK2Tz7V8iPCSGF5 = int(BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠳࠳࠴ᔳ")*k3Om08MCgqQao4n1/LtRNhYpbuV5lzG7.closetimeout)
			LtRNhYpbuV5lzG7.pLukQXhj0rPe(E3unjcqAOK2Tz7V8iPCSGF5)
			if LtRNhYpbuV5lzG7.choiceID>BoWHNb9daQVCF16A(u"࠳ᔴ"): break
		if LtRNhYpbuV5lzG7.closetimeout>WMkAjB1RgN7q(u"࠴ᔵ"): LtRNhYpbuV5lzG7.choiceID = T6wRistc1SCo4hqObgumK(u"࠶࠶ᔶ")
		LtRNhYpbuV5lzG7.vupOEiRhMNsJlez()
	def pLukQXhj0rPe(LtRNhYpbuV5lzG7,E3unjcqAOK2Tz7V8iPCSGF5):
		LtRNhYpbuV5lzG7.precent = E3unjcqAOK2Tz7V8iPCSGF5
		LtRNhYpbuV5lzG7.getControl(qbPw1d3KimF(u"࠿࠰࠳࠲ᔷ")).setPercent(LtRNhYpbuV5lzG7.precent)
	def mMTbJKVkdHEPu70R1wfxo4yDqhg(LtRNhYpbuV5lzG7):
		if LtRNhYpbuV5lzG7.button0: LtRNhYpbuV5lzG7.getControl(EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠹࠱࠳࠳ᔸ")).setEnabled(sRth5giAQzWlEVm7JOX(u"ࡕࡴࡸࡩច"))
		if LtRNhYpbuV5lzG7.button1: LtRNhYpbuV5lzG7.getControl(YB5xyI7MaRslVpv(u"࠺࠲࠴࠵ᔹ")).setEnabled(BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࡖࡵࡹࡪឆ"))
		if LtRNhYpbuV5lzG7.button2: LtRNhYpbuV5lzG7.getControl(YB5xyI7MaRslVpv(u"࠻࠳࠵࠷ᔺ")).setEnabled(QynMHGWA0blfqTUdxRh5Jzi2t(u"ࡗࡶࡺ࡫ជ"))
	def vupOEiRhMNsJlez(LtRNhYpbuV5lzG7):
		LtRNhYpbuV5lzG7.close()
		try: XXRtDhYvWb35qnLBxIri7ScNUks0.remove(LtRNhYpbuV5lzG7.image_filename)
		except: pass
class AuHy92xSpftDB8R():
	def __init__(LtRNhYpbuV5lzG7,showDialogs=gItVahxL0w(u"ࡋࡧ࡬ࡴࡧញ"),logErrors=YB5xyI7MaRslVpv(u"ࡘࡷࡻࡥឈ")):
		LtRNhYpbuV5lzG7.showDialogs = showDialogs
		LtRNhYpbuV5lzG7.logErrors = logErrors
		LtRNhYpbuV5lzG7.finishedLIST,LtRNhYpbuV5lzG7.failedLIST = [],[]
		LtRNhYpbuV5lzG7.statusDICT,LtRNhYpbuV5lzG7.resultsDICT = {},{}
		LtRNhYpbuV5lzG7.processesLIST = []
		LtRNhYpbuV5lzG7.starttimeDICT,LtRNhYpbuV5lzG7.finishtimeDICT,LtRNhYpbuV5lzG7.elpasedtimeDICT = {},{},{}
	def iRtBAskTZXufJLh8Yox6UQcCrjdHg(LtRNhYpbuV5lzG7,HHSczv3E0A1JgipTBqYCPwR,jCXJ2qtIM6sx0TW9HNovk,*aargs):
		HHSczv3E0A1JgipTBqYCPwR = str(HHSczv3E0A1JgipTBqYCPwR)
		LtRNhYpbuV5lzG7.statusDICT[HHSczv3E0A1JgipTBqYCPwR] = jSu5Cg2Ub1OAkZVs8Yoz(u"ࠪࡶࡺࡴ࡮ࡪࡰࡪࠫฟ")
		if LtRNhYpbuV5lzG7.showDialogs: gj7BGM5t3RZpA0vNixLqzwualb16(T6wRistc1SCo4hqObgumK(u"ࠫࠬภ"),HHSczv3E0A1JgipTBqYCPwR)
		vvyxX6HiqILSp = iDocG6BXv7fT2z8UVOxgP.Thread(target=LtRNhYpbuV5lzG7.zHTVa6opEZyPB,args=(HHSczv3E0A1JgipTBqYCPwR,jCXJ2qtIM6sx0TW9HNovk,aargs))
		LtRNhYpbuV5lzG7.processesLIST.append(vvyxX6HiqILSp)
		return vvyxX6HiqILSp
	def Tkf6RY1UXJwNhHsgK(LtRNhYpbuV5lzG7,HHSczv3E0A1JgipTBqYCPwR,jCXJ2qtIM6sx0TW9HNovk,*aargs):
		vvyxX6HiqILSp = LtRNhYpbuV5lzG7.iRtBAskTZXufJLh8Yox6UQcCrjdHg(HHSczv3E0A1JgipTBqYCPwR,jCXJ2qtIM6sx0TW9HNovk,*aargs)
		vvyxX6HiqILSp.start()
	def zHTVa6opEZyPB(LtRNhYpbuV5lzG7,HHSczv3E0A1JgipTBqYCPwR,jCXJ2qtIM6sx0TW9HNovk,aargs):
		HHSczv3E0A1JgipTBqYCPwR = str(HHSczv3E0A1JgipTBqYCPwR)
		LtRNhYpbuV5lzG7.starttimeDICT[HHSczv3E0A1JgipTBqYCPwR] = KBxPW9cX8dqtaUDG.time()
		try:
			LtRNhYpbuV5lzG7.resultsDICT[HHSczv3E0A1JgipTBqYCPwR] = jCXJ2qtIM6sx0TW9HNovk(*aargs)
			if jx7s8T0BFgODXLMzIYedf(u"ࠬࡕࡐࡆࡐࡘࡖࡑ࠭ม") in str(jCXJ2qtIM6sx0TW9HNovk) and not LtRNhYpbuV5lzG7.resultsDICT[HHSczv3E0A1JgipTBqYCPwR].succeeded:
				PapzBZgIekhJ5Fq8rDR2wOxTnu(BoWHNb9daQVCF16A(u"࠭ࡆࡰࡴࡦࡩࡩࠦࡥࡹ࡫ࡷࠤࡩࡻࡥࠡࡶࡲࠤࡹ࡮ࡲࡦࡣࡧࡩࡩࠦࡏࡑࡇࡑ࡙ࡗࡒࠠࡧࡣ࡬ࡰࠬย"))
			LtRNhYpbuV5lzG7.finishedLIST.append(HHSczv3E0A1JgipTBqYCPwR)
			LtRNhYpbuV5lzG7.statusDICT[HHSczv3E0A1JgipTBqYCPwR] = gItVahxL0w(u"ࠧࡧ࡫ࡱ࡭ࡸ࡮ࡥࡥࠩร")
		except Exception as Kx45lGUDX6Ejpk9Qs3nvfLuWNATBY:
			if LtRNhYpbuV5lzG7.logErrors:
				WFMmPzdINGnfvRC1BoeOpb5 = N3JR6Bk5lVxnfGdgvQb.format_exc()
				if WFMmPzdINGnfvRC1BoeOpb5!=qbPw1d3KimF(u"ࠨࡐࡲࡲࡪ࡚ࡹࡱࡧ࠽ࠤࡓࡵ࡮ࡦ࡞ࡱࠫฤ"): ehpURIi6QBDOGu8qj5EYzXrsWHJ7.stderr.write(WFMmPzdINGnfvRC1BoeOpb5)
			LtRNhYpbuV5lzG7.failedLIST.append(HHSczv3E0A1JgipTBqYCPwR)
			LtRNhYpbuV5lzG7.statusDICT[HHSczv3E0A1JgipTBqYCPwR] = sRth5giAQzWlEVm7JOX(u"ࠩࡩࡥ࡮ࡲࡥࡥࠩล")
		LtRNhYpbuV5lzG7.finishtimeDICT[HHSczv3E0A1JgipTBqYCPwR] = KBxPW9cX8dqtaUDG.time()
		LtRNhYpbuV5lzG7.elpasedtimeDICT[HHSczv3E0A1JgipTBqYCPwR] = LtRNhYpbuV5lzG7.finishtimeDICT[HHSczv3E0A1JgipTBqYCPwR] - LtRNhYpbuV5lzG7.starttimeDICT[HHSczv3E0A1JgipTBqYCPwR]
	def x0vO68YI9NHnPhMWzQqpR(LtRNhYpbuV5lzG7):
		for Ih7dgV1GOcKbe48HLixv05fpDwSzkE in LtRNhYpbuV5lzG7.processesLIST:
			Ih7dgV1GOcKbe48HLixv05fpDwSzkE.start()
	def cyAHC69tsxaNzYP2GbpvQj54(LtRNhYpbuV5lzG7):
		while hhlbF1Sns5TrEN8QPCYmL4(u"ࠪࡶࡺࡴ࡮ࡪࡰࡪࠫฦ") in list(LtRNhYpbuV5lzG7.statusDICT.values()): KBxPW9cX8dqtaUDG.sleep(NVS30xAdRFMIw1n9CislkE2(u"࠴ᔻ"))
def NiK6ZP5gOYsQEnvFI10CU():
	IYQKBPdHujwLMlVDE19 = bLEBi8IO7uU2x3htYDdVq95.getSetting(BoWHNb9daQVCF16A(u"ࠫࡦࡼ࠮ࡷࡧࡵࡷ࡮ࡵ࡮ࠨว"))
	if IYQKBPdHujwLMlVDE19==RhVj0vAt5kPHm:
		yyZG19KvbstgMOuj,BgNpRKyQaUWS0dtqVMlwHLo = fY5wTlhtnOc0Er6sdy4k87b(u"ࠬࡔࡏࡠࡗࡓࡈࡆ࡚ࡅࠨศ"),LgpdP3UjFRnlX(u"ࡌࡡ࡭ࡵࡨដ")
		return yyZG19KvbstgMOuj,BgNpRKyQaUWS0dtqVMlwHLo
	try: XXRtDhYvWb35qnLBxIri7ScNUks0.makedirs(IjYiO4u9HGmgw)
	except: pass
	yyZG19KvbstgMOuj,BgNpRKyQaUWS0dtqVMlwHLo = NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠭ࡆࡖࡎࡏࡣ࡚ࡖࡄࡂࡖࡈࠫษ"),BoWHNb9daQVCF16A(u"ࡔࡳࡷࡨឋ")
	xVt8kScLrI = [k5dztomYyN3H(u"ࠧ࠹࠰࠸࠲࠵࠭ส"),k5dztomYyN3H(u"ࠨ࠴࠳࠶࠶࠴࠱࠱࠰࠴࠽ࠬห"),BoWHNb9daQVCF16A(u"ࠩ࠵࠴࠷࠷࠮࠲࠳࠱࠶࠹ࡧࠧฬ"),EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠪ࠶࠵࠸࠱࠯࠳࠵࠲࠸࠶ࠧอ"),NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠫ࠷࠶࠲࠳࠰࠳࠶࠳࠶࠲ࠨฮ"),YB5xyI7MaRslVpv(u"ࠬ࠸࠰࠳࠴࠱࠵࠵࠴࠲࠳ࠩฯ"),BmcLzCFjuIrZP5fwXH18aN6YS(u"࠭࠲࠱࠴࠶࠲࠵࠹࠮࠱࠸ࠪะ"),b05yftsZ6NYgIKP(u"ࠧ࠳࠲࠵࠷࠳࠶࠵࠯࠳࠹ࠫั"),b05yftsZ6NYgIKP(u"ࠨ࠴࠳࠶࠸࠴࠰࠷࠰࠳࠺ࠬา"),YB5xyI7MaRslVpv(u"ࠩ࠵࠴࠷࠹࠮࠲࠲࠱࠶࠽࠭ำ"),UnWjVbo503mEMv9KF(u"ࠪ࠶࠵࠸࠴࠯࠲࠴࠲࠶࠺ࠧิ")]
	faKvUx3HdwIAO2BbuWVLco69GEy = xVt8kScLrI[-YB5xyI7MaRslVpv(u"࠵ᔼ")]
	w8jF6ev0SuzcgdhrMWibNkPZH3OABT = pscSMYFzgT95ehr0okO7(faKvUx3HdwIAO2BbuWVLco69GEy)
	FKup5VAby63 = pscSMYFzgT95ehr0okO7(RhVj0vAt5kPHm)
	if FKup5VAby63>w8jF6ev0SuzcgdhrMWibNkPZH3OABT:
		yyZG19KvbstgMOuj = jSu5Cg2Ub1OAkZVs8Yoz(u"ࠫࡘࡏࡍࡑࡎࡈࡣ࡚ࡖࡄࡂࡖࡈࠫี")
	return yyZG19KvbstgMOuj,BgNpRKyQaUWS0dtqVMlwHLo
def XMkeJVNx6Btc7pqzrsWa9bP():
	if QynMHGWA0blfqTUdxRh5Jzi2t(u"࠶ᔽ"):
		E3B8nIfD5ciypjZ94ObAv1P = nr5mZG89ICi6cgt4MfLJa0(u"࠶ᔾ")
		for JsNYaEqGDOVRQ1XSHCMvyri8PBgLe,mqkyFQwTH09UsdS2,ICrG9yhsUjHlxT68z7 in XXRtDhYvWb35qnLBxIri7ScNUks0.walk(gcIBiFLSn0Hyb3joM15vPpwWJ,topdown=nr5mZG89ICi6cgt4MfLJa0(u"ࡇࡣ࡯ࡷࡪឌ")):
			E3B8nIfD5ciypjZ94ObAv1P += len(ICrG9yhsUjHlxT68z7)
	if E3B8nIfD5ciypjZ94ObAv1P>v5EA6TqHX3s4jzBMk(u"࠵࠱࠲࠳ᔿ"): SSRbfdTHKi1ngDyzeGt5X(gcIBiFLSn0Hyb3joM15vPpwWJ,sRth5giAQzWlEVm7JOX(u"ࡗࡶࡺ࡫ណ"),v5EA6TqHX3s4jzBMk(u"ࡈࡤࡰࡸ࡫ឍ"))
	return
def BAk1NiuR7H2sVl6(IlpZ3itqN15kDozB6QA4JTE):
	global AK5RqLhji4W1wt9VdrCD3PGeQM
	if IlpZ3itqN15kDozB6QA4JTE:
		FE6mI1Sc7GC = zPgNsqpJInt(RnqtMUa9Nh6peGEsBT,UnWjVbo503mEMv9KF(u"ࠬࡪࡩࡤࡶࠪึ"),qbPw1d3KimF(u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩื"),qbPw1d3KimF(u"ࠧࡔࡋࡗࡉࡘ࡛ࡒࡍࡕุࠪ"))
		if FE6mI1Sc7GC:
			AK5RqLhji4W1wt9VdrCD3PGeQM = FE6mI1Sc7GC.copy()
			return
	qmr7vLh1EW = AK5RqLhji4W1wt9VdrCD3PGeQM[gItVahxL0w(u"ࠨࡒ࡜ࡘࡍࡕࡎࠨู")][YB5xyI7MaRslVpv(u"࠺ᕀ")]
	ggfedDsABTMIh = hvc2sXOB31KTLgiZaQUR9xuGjloYS(C2jP0iLNGKnHu9xp(u"࠵࠵ᕁ"),T6wRistc1SCo4hqObgumK(u"ࡘࡷࡻࡥត"))
	XQ6bCdRgwsz3H1heoj9Zicq70OnBlA = {T6wRistc1SCo4hqObgumK(u"ࠩࡸࡷࡪࡸฺࠧ"):ggfedDsABTMIh,BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫ฻"):RhVj0vAt5kPHm}
	UMNteoHlkEy3Yf = mORwgTnXBdQ7iCSHKf(SToQEHqGtMnAlFbCz4wxBDuOsmW7,BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠫࡕࡕࡓࡕࠩ฼"),qmr7vLh1EW,XQ6bCdRgwsz3H1heoj9Zicq70OnBlA,UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠬ࠭฽"),T6wRistc1SCo4hqObgumK(u"࠭ࠧ฾"),C2dgEDAKQGsvh(u"ࠧࠨ฿"),LgpdP3UjFRnlX(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡘࡔࡉࡇࡔࡆࡡ࡚ࡉࡇ࡙ࡉࡕࡇࡖࡣ࡚ࡘࡌࡔ࠯࠴ࡷࡹ࠭เ"))
	if UMNteoHlkEy3Yf.succeeded:
		global NEW_SITESURLS
		exec(UMNteoHlkEy3Yf.content,globals(),locals())
		AK5RqLhji4W1wt9VdrCD3PGeQM.update(NEW_SITESURLS)
		VZ8BTik93OqXLCh0fD7d2KUPpn4mH6(RnqtMUa9Nh6peGEsBT,rbjsM8cRFiuA1(u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬแ"),fY5wTlhtnOc0Er6sdy4k87b(u"ࠪࡗࡎ࡚ࡅࡔࡗࡕࡐࡘ࠭โ"),AK5RqLhji4W1wt9VdrCD3PGeQM,BZdvf7MIUxHQc3aCT)
	return
def hSjJ9C1FZo5VzWwl2tRP(q0HETPprhGgacmbJ4jD,GDL3q5vFjwIVrM2ElRZNd):
	BAk1NiuR7H2sVl6(UnWjVbo503mEMv9KF(u"࡙ࡸࡵࡦថ"))
	tUEvo5HAfIjZgcdYxNJ8awu,OXHVSz957gsf3cKw,pZbHmRVkwf2aIUqJYOSjr943B0MnP5 = qbPw1d3KimF(u"ࡔࡳࡷࡨធ"),QynMHGWA0blfqTUdxRh5Jzi2t(u"ࡌࡡ࡭ࡵࡨទ"),QynMHGWA0blfqTUdxRh5Jzi2t(u"ࡌࡡ࡭ࡵࡨទ")
	EAdbsmyiqLtjhPlxG,gg37KuOokaYFs8qTiezZn1tJ4jLr6,FrwM7qSAvnPOoEkUYKBZI,hT9FozLnDCgvPG0EXyJa7,WrXzD4kdcPJvuwTgyFNoUS5bBVm,WMGuOVe86zTqa4inIY2Q,QHDcUO2xtS4CmF,ezSE9fBuvT,yPoqtK3i7zHulhZJDWYsnLxvT0 = q0HETPprhGgacmbJ4jD
	h8PATfY3gnbWylpxd = EAdbsmyiqLtjhPlxG,gg37KuOokaYFs8qTiezZn1tJ4jLr6,FrwM7qSAvnPOoEkUYKBZI,hT9FozLnDCgvPG0EXyJa7,WrXzD4kdcPJvuwTgyFNoUS5bBVm,WMGuOVe86zTqa4inIY2Q,QHDcUO2xtS4CmF,hhlbF1Sns5TrEN8QPCYmL4(u"ࠫࠬใ"),yPoqtK3i7zHulhZJDWYsnLxvT0
	ndl0BskyaFqDxH9eJOZY7TgvVbXAt = int(hT9FozLnDCgvPG0EXyJa7)
	SpFBy8XPHD6Vh92sMiRgaxkUG = int(ndl0BskyaFqDxH9eJOZY7TgvVbXAt%C2dgEDAKQGsvh(u"࠴࠴ᕂ"))
	WrI1XaHkSE7iKbOxJ8Nz9qFC = int(ndl0BskyaFqDxH9eJOZY7TgvVbXAt/k5dztomYyN3H(u"࠵࠵ᕃ"))
	etOfYpsR2kb7LmlHF = bLEBi8IO7uU2x3htYDdVq95.getSetting(LgpdP3UjFRnlX(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯࡯ࡨࡲࡺࡹࡣࡢࡥ࡫ࡩࠬไ"))
	if not etOfYpsR2kb7LmlHF: bLEBi8IO7uU2x3htYDdVq95.setSetting(V2RbfGOBdcA6l8NTsPWzEyvS7(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡰࡩࡳࡻࡳࡤࡣࡦ࡬ࡪ࠭ๅ"),gItVahxL0w(u"ࠧࡂࡗࡗࡓࠬๆ"))
	PpfKXEts0bcojCandF5,BgNpRKyQaUWS0dtqVMlwHLo = NiK6ZP5gOYsQEnvFI10CU()
	if BgNpRKyQaUWS0dtqVMlwHLo:
		ZIOHgA3z0TBR(T6wRistc1SCo4hqObgumK(u"ࠨࠩ็"),NVS30xAdRFMIw1n9CislkE2(u"่ࠩࠪ"),BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั้࠭"),EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠫฯ๋ࠠหฯา๎ะࠦวๅสิ๊ฬ๋ฬࠡใํࠤัํวำๅ࡟ࡲส๊้ࠡษ็ษฺีวาࠢิๆ๊ࡀ࡜࡯࡞ࡱ๊ࠫ")+RhVj0vAt5kPHm)
		qkSCcaj2fg4VO7dl3G9IhJBs5DLx(RnqtMUa9Nh6peGEsBT,qbPw1d3KimF(u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࠨ๋"),WMkAjB1RgN7q(u"࠭ࡑࡖࡇࡖࡘࡎࡕࡎࡔࠩ์"))
		qkSCcaj2fg4VO7dl3G9IhJBs5DLx(RnqtMUa9Nh6peGEsBT,QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪํ"),BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠨࡃࡏࡐࡤࡇࡄࡅࡑࡑࡗࡤ࡞ࡍࡍࠩ๎"))
		qkSCcaj2fg4VO7dl3G9IhJBs5DLx(RnqtMUa9Nh6peGEsBT,C2jP0iLNGKnHu9xp(u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬ๏"),FGDJwkEbTB5SoXujs3f(u"ࠪࡗࡎ࡚ࡅࡔࡡࡑࡅࡒࡋࡓࠨ๐"))
		qkSCcaj2fg4VO7dl3G9IhJBs5DLx(RnqtMUa9Nh6peGEsBT,jx7s8T0BFgODXLMzIYedf(u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧ๑"),EAc8h2sINroQYvR3WH06Ji7MVpn(u"࡙ࠬࡉࡕࡇࡖࡣࡈࡎࡅࡄࡍࠪ๒"))
		qkSCcaj2fg4VO7dl3G9IhJBs5DLx(RnqtMUa9Nh6peGEsBT,EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩ๓"),sRth5giAQzWlEVm7JOX(u"ࠧࡔࡋࡗࡉࡘࡥࡖࡆࡔࡌࡊ࡞࠭๔"))
		bLEBi8IO7uU2x3htYDdVq95.setSetting(BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠨࡣࡹ࠲࡭ࡵࡳࡵ࠰ࡩࡳࡸࡺࡡࠨ๕"),k5dztomYyN3H(u"ࠩࠪ๖"))
		bLEBi8IO7uU2x3htYDdVq95.setSetting(UnWjVbo503mEMv9KF(u"ࠪࡥࡻ࠴ࡨࡰࡵࡷ࠲࡫ࡧࡢࡳࡣ࡮ࡥࠬ๗"),k5dztomYyN3H(u"ࠫࠬ๘"))
		bLEBi8IO7uU2x3htYDdVq95.setSetting(V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠬࡧࡶ࠯ࡪࡲࡷࡹ࠴ࡳࡩࡣ࡫࡭ࡩ࠺ࡵࠨ๙"),jSu5Cg2Ub1OAkZVs8Yoz(u"࠭ࠧ๚"))
		bLEBi8IO7uU2x3htYDdVq95.setSetting(nr5mZG89ICi6cgt4MfLJa0(u"ࠧࡢࡸ࠱࡬ࡴࡹࡴ࠯ࡨࡤࡷࡪࡲࡨࡥ࠳ࠪ๛"),k5dztomYyN3H(u"ࠨࠩ๜"))
		bLEBi8IO7uU2x3htYDdVq95.setSetting(LgpdP3UjFRnlX(u"ࠩࡤࡺ࠳ࡶࡲࡪࡸࡶ࠵ࠬ๝"),C2dgEDAKQGsvh(u"ࠪࠫ๞"))
		bLEBi8IO7uU2x3htYDdVq95.setSetting(UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠫࡦࡼ࠮ࡱࡴ࡬ࡺࡸ࠸ࠧ๟"),fY5wTlhtnOc0Er6sdy4k87b(u"ࠬ࠭๠"))
		bLEBi8IO7uU2x3htYDdVq95.setSetting(NVS30xAdRFMIw1n9CislkE2(u"࠭ࡡࡷ࠰ࡳࡩࡷ࡯࡯ࡥ࠰࡬ࡲ࡫ࡵࡳࠨ๡"),RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠧࠨ๢"))
		bLEBi8IO7uU2x3htYDdVq95.setSetting(sRth5giAQzWlEVm7JOX(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮࡭ࡱࡱ࡫ࠬ๣"),l0WAe1f7Bpi5ZXk(u"ࠩࠪ๤"))
		bLEBi8IO7uU2x3htYDdVq95.setSetting(FGDJwkEbTB5SoXujs3f(u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰ࡵࡩ࡬ࡻ࡬ࡢࡴࠪ๥"),YB5xyI7MaRslVpv(u"ࠫࠬ๦"))
		bLEBi8IO7uU2x3htYDdVq95.setSetting(QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠬࡧࡶ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮࠲ࡲ࡫ࡳࡴࡣࡪࡩࡸ࠭๧"),b05yftsZ6NYgIKP(u"࠭ࠧ๨"))
		bLEBi8IO7uU2x3htYDdVq95.setSetting(C2dgEDAKQGsvh(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴ࡱࡶࡧࡶࡸ࡮ࡵ࡮ࡴࠩ๩"),UnWjVbo503mEMv9KF(u"ࠨࠩ๪"))
		bLEBi8IO7uU2x3htYDdVq95.setSetting(BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠩࡤࡺ࠳࡬ࡡࡪ࡮ࡨࡨ࠳ࡹࡣࡢࡴࡳࡩࡵࡸ࡯ࡹࡻ࠴ࠫ๫"),gItVahxL0w(u"ࠪࠫ๬"))
		bLEBi8IO7uU2x3htYDdVq95.setSetting(fY5wTlhtnOc0Er6sdy4k87b(u"ࠫࡦࡼ࠮ࡧࡣ࡬ࡰࡪࡪ࠮ࡴࡥࡤࡶࡵ࡫ࡰࡳࡱࡻࡽ࠷࠭๭"),BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠬ࠭๮"))
		bLEBi8IO7uU2x3htYDdVq95.setSetting(C2jP0iLNGKnHu9xp(u"࠭ࡡࡷ࠰ࡩࡥ࡮ࡲࡥࡥ࠰ࡶࡧࡦࡸࡰࡦࡲࡵࡳࡽࡿ࠳ࠨ๯"),C2jP0iLNGKnHu9xp(u"ࠧࠨ๰"))
		bLEBi8IO7uU2x3htYDdVq95.setSetting(YB5xyI7MaRslVpv(u"ࠨࡣࡹ࠲࡫ࡧࡩ࡭ࡧࡧ࠲ࡸࡩࡡࡳࡲࡨࡴࡷࡵࡸࡺ࠶ࠪ๱"),vvHpKfcqRnrFzjG(u"ࠩࠪ๲"))
		import gCUboaujSL
		if PpfKXEts0bcojCandF5==sRth5giAQzWlEVm7JOX(u"ࠪࡗࡎࡓࡐࡍࡇࡢ࡙ࡕࡊࡁࡕࡇࠪ๳"):
			Lmj1pfQk63XdoeH(vvHpKfcqRnrFzjG(u"ࠫࡓࡕࡔࡊࡅࡈࠫ๴"),RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠬ࠴ࠠࠡࡃࡵࡥࡧ࡯ࡣࡗ࡫ࡧࡩࡴࡹࠠࡖࡲࡧࡥࡹ࡫ࠠࡕࡻࡳࡩ࠿ࠦࠠࡔࡋࡐࡔࡑࡋࠠࡖࡒࡇࡅ࡙ࡋࠠࠡࠢࡓࡥࡹ࡮࠺ࠡ࡝ࠣࠫ๵")+SzGukeylg5Nsr9M20WIan+NVS30xAdRFMIw1n9CislkE2(u"࠭ࠠ࡞ࠩ๶"))
			qkSCcaj2fg4VO7dl3G9IhJBs5DLx(RnqtMUa9Nh6peGEsBT,hhlbF1Sns5TrEN8QPCYmL4(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡖࡍ࡙ࡋࡓࠨ๷"))
			qkSCcaj2fg4VO7dl3G9IhJBs5DLx(RnqtMUa9Nh6peGEsBT,EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡍࡕ࡚ࡖࠨ๸"))
			qkSCcaj2fg4VO7dl3G9IhJBs5DLx(RnqtMUa9Nh6peGEsBT,RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡒ࠹ࡕࠨ๹"))
			a69aolrYsnGEukv5Li(BmcLzCFjuIrZP5fwXH18aN6YS(u"ࡕࡴࡸࡩន"),[RnqtMUa9Nh6peGEsBT])
		else:
			Lmj1pfQk63XdoeH(EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ๺"),rbjsM8cRFiuA1(u"ࠫ࠳ࠦࠠࡂࡴࡤࡦ࡮ࡩࡖࡪࡦࡨࡳࡸࠦࡕࡱࡦࡤࡸࡪࠦࡔࡺࡲࡨ࠾ࠥࠦࡆࡖࡎࡏࠤ࡚ࡖࡄࡂࡖࡈࠤࠥࠦࡐࡢࡶ࡫࠾ࠥࡡࠠࠨ๻")+SzGukeylg5Nsr9M20WIan+UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠬࠦ࡝ࠨ๼"))
			ZIOHgA3z0TBR(WMkAjB1RgN7q(u"࠭ࠧ๽"),nr5mZG89ICi6cgt4MfLJa0(u"ࠧࠨ๾"),T6wRistc1SCo4hqObgumK(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ๿"),PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠩอ้ࠥะหษ์อࠤศ๎ࠠหฯา๎ะࠦวๅวุำฬืࠠศๆฯำ๏ีࠠๅสิ๊ฬ๋ฬࠡษ็ๅ๏ี๊้้สฮࠥอไฺำห๎ฮࠦ࠮ࠡล๋ࠤฯ๋ࠠๆีะࠤ่อิࠡษ็ฬึ์วๆฮࠣࡠࡳࡢ࡮ࠡีํๆํ๋ࠠศๆล๊ࠥอไษำ้ห๊าࠠษส฼ฺࠥอไโฯู๋ฬะࠠๅุ่หู๋ࠦๆๆࠣห้ฮั็ษ่ะࠥฮี้ำฬࠤฺำ๊ฮหࠣ์๊ะใศ็็อࠬ຀"))
			a69aolrYsnGEukv5Li(T6wRistc1SCo4hqObgumK(u"ࡈࡤࡰࡸ࡫ប"),[])
			ooMyveu1YHBOkXcpfF2jqCVl(T6wRistc1SCo4hqObgumK(u"ࡉࡥࡱࡹࡥផ"))
			gCUboaujSL.U6xNL2AEyOIk()
			gCUboaujSL.wOF6QJqepnRYNgv5cos13ljDtZzGd(BoWHNb9daQVCF16A(u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡣࡧࡥࡵࡺࡩࡷࡧࠪກ"),nr5mZG89ICi6cgt4MfLJa0(u"ࡊࡦࡲࡳࡦព"))
			gCUboaujSL.wOF6QJqepnRYNgv5cos13ljDtZzGd(rbjsM8cRFiuA1(u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡵࡸࡲࡶࠧຂ"),fY5wTlhtnOc0Er6sdy4k87b(u"ࡋࡧ࡬ࡴࡧភ"))
			gCUboaujSL.tqY8WmB1FcPoUywflAhuMeRD3QHzjb(k5dztomYyN3H(u"ࡌࡡ࡭ࡵࡨម"))
			gCUboaujSL.d4f1LnKCFGXirMJjc3RUN8yITWlx5(PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࡆࡢ࡮ࡶࡩយ"))
			gCUboaujSL.QgnzujScYkv9TZlOKD6r51LBP(BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪ຃"),QynMHGWA0blfqTUdxRh5Jzi2t(u"࠭ࡥ࡯ࡣࡥࡰࡪ࠭ຄ"),BmcLzCFjuIrZP5fwXH18aN6YS(u"ࡇࡣ࡯ࡷࡪរ"))
			try:
				ylvCMShVTEZFnABROprd0uceb = XXRtDhYvWb35qnLBxIri7ScNUks0.path.join(gK53PXkR96t7djpHeqEyL0,b05yftsZ6NYgIKP(u"ࠧࡶࡵࡨࡶࡩࡧࡴࡢࠩ຅"),hhlbF1Sns5TrEN8QPCYmL4(u"ࠨࡣࡧࡨࡴࡴ࡟ࡥࡣࡷࡥࠬຆ"),qbPw1d3KimF(u"ࠩࡶࡧࡷ࡯ࡰࡵ࠰ࡰࡳࡩࡻ࡬ࡦ࠰ࡵࡩࡸࡵ࡬ࡷࡧࡸࡶࡱ࠭ງ"),PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠪࡷࡪࡺࡴࡪࡰࡪࡷ࠳ࡾ࡭࡭ࠩຈ"))
				gqZ2MEfe5Kv9WPYrdmBFi7TNxXG = OGJ60aCqcw4EvUBbxDMHkIYN.Addon(id=sRth5giAQzWlEVm7JOX(u"ࠫࡸࡩࡲࡪࡲࡷ࠲ࡲࡵࡤࡶ࡮ࡨ࠲ࡷ࡫ࡳࡰ࡮ࡹࡩࡺࡸ࡬ࠨຉ"))
				gqZ2MEfe5Kv9WPYrdmBFi7TNxXG.setSetting(gItVahxL0w(u"ࠬࡧࡶ࠯ࡣࡸࡸࡴࡥࡰࡪࡥ࡮ࠫຊ"),BmcLzCFjuIrZP5fwXH18aN6YS(u"࠭ࡦࡢ࡮ࡶࡩࠬ຋"))
			except: pass
			try:
				ylvCMShVTEZFnABROprd0uceb = XXRtDhYvWb35qnLBxIri7ScNUks0.path.join(gK53PXkR96t7djpHeqEyL0,jSu5Cg2Ub1OAkZVs8Yoz(u"ࠧࡶࡵࡨࡶࡩࡧࡴࡢࠩຌ"),fY5wTlhtnOc0Er6sdy4k87b(u"ࠨࡣࡧࡨࡴࡴ࡟ࡥࡣࡷࡥࠬຍ"),NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠩࡶࡧࡷ࡯ࡰࡵ࠰ࡰࡳࡩࡻ࡬ࡦ࠰ࡼࡸ࠲ࡪ࡬ࡱࠩຎ"),PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠪࡷࡪࡺࡴࡪࡰࡪࡷ࠳ࡾ࡭࡭ࠩຏ"))
				gqZ2MEfe5Kv9WPYrdmBFi7TNxXG = OGJ60aCqcw4EvUBbxDMHkIYN.Addon(id=jSu5Cg2Ub1OAkZVs8Yoz(u"ࠫࡸࡩࡲࡪࡲࡷ࠲ࡲࡵࡤࡶ࡮ࡨ࠲ࡾࡺ࠭ࡥ࡮ࡳࠫຐ"))
				gqZ2MEfe5Kv9WPYrdmBFi7TNxXG.setSetting(UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠬࡧࡶ࠯ࡸ࡬ࡨࡪࡵ࡟ࡲࡷࡤࡰ࡮ࡺࡹࠨຑ"),BoWHNb9daQVCF16A(u"࠭࠳ࠨຒ"))
			except: pass
			try:
				ylvCMShVTEZFnABROprd0uceb = XXRtDhYvWb35qnLBxIri7ScNUks0.path.join(gK53PXkR96t7djpHeqEyL0,WMkAjB1RgN7q(u"ࠧࡶࡵࡨࡶࡩࡧࡴࡢࠩຓ"),jx7s8T0BFgODXLMzIYedf(u"ࠨࡣࡧࡨࡴࡴ࡟ࡥࡣࡷࡥࠬດ"),BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡢࡦࡤࡴࡹ࡯ࡶࡦࠩຕ"),C2dgEDAKQGsvh(u"ࠪࡷࡪࡺࡴࡪࡰࡪࡷ࠳ࡾ࡭࡭ࠩຖ"))
				gqZ2MEfe5Kv9WPYrdmBFi7TNxXG = OGJ60aCqcw4EvUBbxDMHkIYN.Addon(id=l0WAe1f7Bpi5ZXk(u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡤࡨࡦࡶࡴࡪࡸࡨࠫທ"))
				gqZ2MEfe5Kv9WPYrdmBFi7TNxXG.setSetting(T6wRistc1SCo4hqObgumK(u"ࠬࡧࡶ࠯ࡕࡗࡖࡊࡇࡍࡔࡇࡏࡉࡈ࡚ࡉࡐࡐࠪຘ"),l0WAe1f7Bpi5ZXk(u"࠭࠲ࠨນ"))
			except: pass
		AqLgT4S6FExHi1kZ5smy7a0hRX = anzmoyTgUd(Cjda4zr3pXghVKDR)
		AqLgT4S6FExHi1kZ5smy7a0hRX = anzmoyTgUd(Z7A1STpeQGVJ)
		bLEBi8IO7uU2x3htYDdVq95.setSetting(WMkAjB1RgN7q(u"ࠧࡢࡸ࠱ࡺࡪࡸࡳࡪࡱࡱࠫບ"),RhVj0vAt5kPHm)
		gCUboaujSL.vg4e75WtcYXk0SJyM(PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࡈࡤࡰࡸ࡫ល"))
		return
	zJwPBdKbhsfqD5vX = bLEBi8IO7uU2x3htYDdVq95.getSetting(UnWjVbo503mEMv9KF(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡷ࡫ࡦࡳࡧࡶ࡬ࠬປ"))
	HHQYtifTDV = GETmdevAqQ(GDL3q5vFjwIVrM2ElRZNd)
	SXmIKu9NvQ7xrJbAD13T = GETmdevAqQ(gg37KuOokaYFs8qTiezZn1tJ4jLr6)
	X0DBFl5Pe7n6O9 = [jSu5Cg2Ub1OAkZVs8Yoz(u"࠵ᕋ"),FGDJwkEbTB5SoXujs3f(u"࠷࠵ᕅ"),l0WAe1f7Bpi5ZXk(u"࠱࠸ᕆ"),UnWjVbo503mEMv9KF(u"࠲࠻ᕇ"),FGDJwkEbTB5SoXujs3f(u"࠷࠼ᕄ"),hhlbF1Sns5TrEN8QPCYmL4(u"࠷࠹ᕊ"),C2dgEDAKQGsvh(u"࠷࠳ᕈ"),hhlbF1Sns5TrEN8QPCYmL4(u"࠸࠷ᕉ")]
	ugSh8On0AV1YNIy7TceLF35fR = [vvHpKfcqRnrFzjG(u"࠶ᕓ"),C2dgEDAKQGsvh(u"࠱࠶ᕍ"),BoWHNb9daQVCF16A(u"࠲࠹ᕎ"),FGDJwkEbTB5SoXujs3f(u"࠳࠼ᕏ"),C2jP0iLNGKnHu9xp(u"࠸࠶ᕌ"),QynMHGWA0blfqTUdxRh5Jzi2t(u"࠸࠺ᕒ"),fY5wTlhtnOc0Er6sdy4k87b(u"࠸࠴ᕐ"),jx7s8T0BFgODXLMzIYedf(u"࠹࠸ᕑ")]
	mRe3yGTwjYO8Ci1t7cx9nXVMgf = WrI1XaHkSE7iKbOxJ8Nz9qFC not in ugSh8On0AV1YNIy7TceLF35fR
	LP8kt7nEG2WsIcOvYXSd4r5 = WrI1XaHkSE7iKbOxJ8Nz9qFC in [BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠵࠷ᕗ"),nr5mZG89ICi6cgt4MfLJa0(u"࠲࠹ᕔ"),jx7s8T0BFgODXLMzIYedf(u"࠹࠴ᕖ"),BoWHNb9daQVCF16A(u"࠸࠴ᕕ")]
	FPBkSZmlU3n6g1LO4x = ndl0BskyaFqDxH9eJOZY7TgvVbXAt in [BmcLzCFjuIrZP5fwXH18aN6YS(u"࠷࠼࠵ᕙ"),UxS67uoGThbMwnfNRzy4gajLd23JH(u"࠶࠼࠶ᕘ")]
	BARfpCqGy9ZHtTFO1jI = (mRe3yGTwjYO8Ci1t7cx9nXVMgf or LP8kt7nEG2WsIcOvYXSd4r5) and not FPBkSZmlU3n6g1LO4x
	opW8l0r45SzqhQ = zJwPBdKbhsfqD5vX!=LgpdP3UjFRnlX(u"ࠩࡕࡉࡋࡘࡅࡔࡊࡈࡈࠬຜ") and (zJwPBdKbhsfqD5vX or not ezSE9fBuvT)
	H8hPSVipqgjXl = sRth5giAQzWlEVm7JOX(u"ࠪࡸࡾࡶࡥ࠾ࠩຝ") in zJwPBdKbhsfqD5vX
	vmGg52xdI9 = ndl0BskyaFqDxH9eJOZY7TgvVbXAt in [gItVahxL0w(u"࠳࠹࠵ᕤ"),NVS30xAdRFMIw1n9CislkE2(u"࠴࠺࠷ᕥ"),WMkAjB1RgN7q(u"࠵࠻࠹ᕦ"),UxS67uoGThbMwnfNRzy4gajLd23JH(u"࠶࠼࠴ᕠ"),LgpdP3UjFRnlX(u"࠷࠶࠶ᕡ"),LgpdP3UjFRnlX(u"࠱࠷࠸ᕢ"),v5EA6TqHX3s4jzBMk(u"࠲࠸࠺ᕣ"),gItVahxL0w(u"࠵࠻࠾ᕟ"),QynMHGWA0blfqTUdxRh5Jzi2t(u"࠸࠸࠴ᕜ"),BmcLzCFjuIrZP5fwXH18aN6YS(u"࠽࠶࠳ᕚ"),jSu5Cg2Ub1OAkZVs8Yoz(u"࠷࠷࠵ᕛ"),jSu5Cg2Ub1OAkZVs8Yoz(u"࠹࠹࠸ᕝ"),WMkAjB1RgN7q(u"࠺࠺࠺ᕞ")]
	HjZcUIVAXFCqy9TfBWKtgY2 = SpFBy8XPHD6Vh92sMiRgaxkUG==BoWHNb9daQVCF16A(u"࠾ᕧ") or ndl0BskyaFqDxH9eJOZY7TgvVbXAt in [WMkAjB1RgN7q(u"࠱࠵࠷ᕩ"),jSu5Cg2Ub1OAkZVs8Yoz(u"࠷࠴࠺ᕫ"),qbPw1d3KimF(u"࠶࠴࠶ᕪ"),jx7s8T0BFgODXLMzIYedf(u"࠺࠵ᕨ")]
	v8UfhSwjp5tX0WP = not vmGg52xdI9
	CKVtYx3mFE6ByT70 = not HjZcUIVAXFCqy9TfBWKtgY2
	VtI0boasjHerg = HHQYtifTDV in [hhlbF1Sns5TrEN8QPCYmL4(u"ࠫࠬພ"),WMkAjB1RgN7q(u"ࠬ࠴࠮ࠨຟ")]
	AlEm7D51avQeqyd8 = VtI0boasjHerg or v8UfhSwjp5tX0WP
	ZZ3qPie6Sw0Fb9vy = VtI0boasjHerg or CKVtYx3mFE6ByT70 or H8hPSVipqgjXl
	Y2Ue1dWVxl = ndl0BskyaFqDxH9eJOZY7TgvVbXAt not in [YB5xyI7MaRslVpv(u"࠲࠷࠲ᕰ"),b05yftsZ6NYgIKP(u"࠵࠺࠶ᕬ"),b05yftsZ6NYgIKP(u"࠳࠸࠸ᕱ"),C2dgEDAKQGsvh(u"࠷࠽࠰ᕮ"),jSu5Cg2Ub1OAkZVs8Yoz(u"࠷࠸࠶ᕭ"),QynMHGWA0blfqTUdxRh5Jzi2t(u"࠻࠴࠱ᕯ")]
	if etOfYpsR2kb7LmlHF==C2jP0iLNGKnHu9xp(u"࠭ࡓࡕࡑࡓࠫຠ"): D89FUTowvkHPnb41 = HjZcUIVAXFCqy9TfBWKtgY2 or vmGg52xdI9
	else: D89FUTowvkHPnb41 = QynMHGWA0blfqTUdxRh5Jzi2t(u"ࡗࡶࡺ࡫វ")
	OGH7jQYKSd = WrI1XaHkSE7iKbOxJ8Nz9qFC in [WMkAjB1RgN7q(u"࠺࠸ᕳ"),b05yftsZ6NYgIKP(u"࠹࠸ᕲ")]
	DTvx7XFH834A = ndl0BskyaFqDxH9eJOZY7TgvVbXAt in [PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"࠶࠽࠶ᕴ"),T6wRistc1SCo4hqObgumK(u"࠼࠸࠰ᕵ")]
	JJNHvZCdr6haYASR = not OGH7jQYKSd and not DTvx7XFH834A
	K53ZDraoSh7VuI64JeWLqCYB = AlEm7D51avQeqyd8 and ZZ3qPie6Sw0Fb9vy and Y2Ue1dWVxl and D89FUTowvkHPnb41 and JJNHvZCdr6haYASR
	DogSxX1Hie = Y2Ue1dWVxl and D89FUTowvkHPnb41 and JJNHvZCdr6haYASR
	V5OHQA3qYIwp0BTD2tNW4m = DogSxX1Hie
	ZpcH2XUBJujAKqv = bLEBi8IO7uU2x3htYDdVq95.getSetting(hhlbF1Sns5TrEN8QPCYmL4(u"ࠧࡢࡸ࠱ࡰࡦࡴࡧࡶࡣࡪࡩ࠳ࡶࡲࡰࡸ࡬ࡨࡪࡸࠧມ"))
	c4oFda8RgQ = bLEBi8IO7uU2x3htYDdVq95.getSetting(rbjsM8cRFiuA1(u"ࠨࡣࡹ࠲ࡱࡧ࡮ࡨࡷࡤ࡫ࡪ࠴ࡣࡰࡦࡨࠫຢ"))
	if UxS67uoGThbMwnfNRzy4gajLd23JH(u"࠷ᕶ") and opW8l0r45SzqhQ and K53ZDraoSh7VuI64JeWLqCYB:
		qEX4y0ZW6CrSAGibe = zPgNsqpJInt(RnqtMUa9Nh6peGEsBT,EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠩ࡯࡭ࡸࡺࠧຣ"),UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠪࡑࡊࡔࡕࡔࡡࡆࡅࡈࡎࡅࡠࠩ຤")+ZpcH2XUBJujAKqv+hhlbF1Sns5TrEN8QPCYmL4(u"ࠫࡤ࠭ລ")+c4oFda8RgQ,h8PATfY3gnbWylpxd)
		if qEX4y0ZW6CrSAGibe:
			Lmj1pfQk63XdoeH(EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠬ࠭຦"),gItVahxL0w(u"࠭࠮ࠡࠢࡐࡉࡓ࡛ࡓࡠࡅࡄࡇࡍࡋ࡟ࠨວ")+ZpcH2XUBJujAKqv+UnWjVbo503mEMv9KF(u"ࠧࡠࠩຨ")+c4oFda8RgQ+sRth5giAQzWlEVm7JOX(u"ࠨࠢࠣࠤࡑࡵࡡࡥ࡫ࡱ࡫ࠥࡳࡥ࡯ࡷࠣࡪࡷࡵ࡭ࠡࡥࡤࡧ࡭࡫ࠧຩ"))
			if EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠱ᕷ") and H8hPSVipqgjXl:
				vIpwqFefTdQVcOxzE63imKM4oLXgbt = []
				from sz35WLBk4K import min2xGoHEy67RY1hS8L0CwtsfzWlp
				from wfQhx1AiCD import U74i5rCBLYbymIQFOV,nvlhoJtjfRTSMANVO1HDCBcgPxI
				QQXCqdlYw0mG8yo = min2xGoHEy67RY1hS8L0CwtsfzWlp
				a863k2OWvVjDSY = U74i5rCBLYbymIQFOV()
				xjKWuihBc4vAnSDM = zJwPBdKbhsfqD5vX
				GVhwaKWUiHYLXPTuSJ,jjgUJo5bDxKlGBh8V4I1Cdpi,L0JdOojQqcZxg,UoZRlwci8b3d09JVyzmxXF,hjsxAlmagLTtczS,APMdHupewh9BnE3lxc1jb0rzNm2,W5yLHpC3kGR,C1Lqv2dWkZeVtc,t8NHMuTh2JK0C1xZwn4RPqBeOWyad = cIa9Spry0oqE(xjKWuihBc4vAnSDM)
				Y4kM0IzXTC2LlHjtBsab = GVhwaKWUiHYLXPTuSJ,jjgUJo5bDxKlGBh8V4I1Cdpi,L0JdOojQqcZxg,UoZRlwci8b3d09JVyzmxXF,hjsxAlmagLTtczS,APMdHupewh9BnE3lxc1jb0rzNm2,W5yLHpC3kGR,RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠩࠪສ"),t8NHMuTh2JK0C1xZwn4RPqBeOWyad
				for O2AhQFeK5b16NU4SGXLMB9ip7uaW in qEX4y0ZW6CrSAGibe:
					C904CiQLxZJn7HbufzUR3qDEXV = O2AhQFeK5b16NU4SGXLMB9ip7uaW[LgpdP3UjFRnlX(u"ࠪࡱࡪࡴࡵࡊࡶࡨࡱࠬຫ")]
					if C904CiQLxZJn7HbufzUR3qDEXV==Y4kM0IzXTC2LlHjtBsab or O2AhQFeK5b16NU4SGXLMB9ip7uaW[WMkAjB1RgN7q(u"ࠫࡲࡵࡤࡦࠩຬ")] in [C2dgEDAKQGsvh(u"࠴࠹࠹ᕹ"),vvHpKfcqRnrFzjG(u"࠳࠹࠳ᕸ")]:
						O2AhQFeK5b16NU4SGXLMB9ip7uaW = xB3NS9bTCqO(C904CiQLxZJn7HbufzUR3qDEXV,QQXCqdlYw0mG8yo,a863k2OWvVjDSY)
						if O2AhQFeK5b16NU4SGXLMB9ip7uaW[YB5xyI7MaRslVpv(u"ࠬ࡬ࡡࡷࡱࡵ࡭ࡹ࡫ࡳࠨອ")]:
							cc9AByUHsSqh0naTg2Gz = nvlhoJtjfRTSMANVO1HDCBcgPxI(a863k2OWvVjDSY,C904CiQLxZJn7HbufzUR3qDEXV,O2AhQFeK5b16NU4SGXLMB9ip7uaW[WMkAjB1RgN7q(u"࠭࡮ࡦࡹࡳࡥࡹ࡮ࠧຮ")])
							O2AhQFeK5b16NU4SGXLMB9ip7uaW[PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠧࡤࡱࡱࡸࡪࡾࡴࡠ࡯ࡨࡲࡺ࠭ຯ")] = cc9AByUHsSqh0naTg2Gz+O2AhQFeK5b16NU4SGXLMB9ip7uaW[NVS30xAdRFMIw1n9CislkE2(u"ࠨࡥࡲࡲࡹ࡫ࡸࡵࡡࡰࡩࡳࡻࠧະ")]
					vIpwqFefTdQVcOxzE63imKM4oLXgbt.append(O2AhQFeK5b16NU4SGXLMB9ip7uaW)
				bLEBi8IO7uU2x3htYDdVq95.setSetting(BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡸࡥࡧࡴࡨࡷ࡭࠭ັ"),C2dgEDAKQGsvh(u"ࠪࠫາ"))
				if EAdbsmyiqLtjhPlxG==jSu5Cg2Ub1OAkZVs8Yoz(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫຳ"): VZ8BTik93OqXLCh0fD7d2KUPpn4mH6(RnqtMUa9Nh6peGEsBT,jSu5Cg2Ub1OAkZVs8Yoz(u"ࠬࡓࡅࡏࡗࡖࡣࡈࡇࡃࡉࡇࡢࠫິ")+ZpcH2XUBJujAKqv+jx7s8T0BFgODXLMzIYedf(u"࠭࡟ࠨີ")+c4oFda8RgQ,h8PATfY3gnbWylpxd,vIpwqFefTdQVcOxzE63imKM4oLXgbt,UuEtImzir9)
			else: vIpwqFefTdQVcOxzE63imKM4oLXgbt = qEX4y0ZW6CrSAGibe
			if EAdbsmyiqLtjhPlxG==QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧຶ") and HHQYtifTDV!=hhlbF1Sns5TrEN8QPCYmL4(u"ࠨ࠰࠱ࠫື") and BARfpCqGy9ZHtTFO1jI: ivqDg9QFCIArMf1PO7WwU3lR()
			dBmpzjIUyLoVQR = VsShzn5wMuYP(h8PATfY3gnbWylpxd,vIpwqFefTdQVcOxzE63imKM4oLXgbt,tUEvo5HAfIjZgcdYxNJ8awu,OXHVSz957gsf3cKw,pZbHmRVkwf2aIUqJYOSjr943B0MnP5)
			return
	elif EAdbsmyiqLtjhPlxG==rbjsM8cRFiuA1(u"ࠩࡩࡳࡱࡪࡥࡳຸࠩ") and zJwPBdKbhsfqD5vX==l0WAe1f7Bpi5ZXk(u"ࠪࡖࡊࡌࡒࡆࡕࡋࡉࡉູ࠭") and DogSxX1Hie:
		qkSCcaj2fg4VO7dl3G9IhJBs5DLx(RnqtMUa9Nh6peGEsBT,NVS30xAdRFMIw1n9CislkE2(u"ࠫࡒࡋࡎࡖࡕࡢࡇࡆࡉࡈࡆࡡ຺ࠪ")+ZpcH2XUBJujAKqv+UnWjVbo503mEMv9KF(u"ࠬࡥࠧົ")+c4oFda8RgQ,h8PATfY3gnbWylpxd)
	if ezSE9fBuvT:
		if v5EA6TqHX3s4jzBMk(u"࠭࡟ࠨຼ") in ezSE9fBuvT: HcTPpV91FdW,hcfLvQzsGq4Y9E3tWboTe = ezSE9fBuvT.split(BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠧࡠࠩຽ"),nr5mZG89ICi6cgt4MfLJa0(u"࠴ᕺ"))
		else: HcTPpV91FdW,hcfLvQzsGq4Y9E3tWboTe = ezSE9fBuvT,hhlbF1Sns5TrEN8QPCYmL4(u"ࠨࠩ຾")
		if HcTPpV91FdW in [k5dztomYyN3H(u"ࠩ࠴ࠫ຿"),QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠪ࠶ࠬເ"),C2jP0iLNGKnHu9xp(u"ࠫ࠸࠭ແ"),qbPw1d3KimF(u"ࠬ࠺ࠧໂ"),NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠭࠵ࠨໃ")] and hcfLvQzsGq4Y9E3tWboTe:
			from wfQhx1AiCD import xxny2PLvbheWg
			xxny2PLvbheWg(ezSE9fBuvT)
			bLEBi8IO7uU2x3htYDdVq95.setSetting(C2jP0iLNGKnHu9xp(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡶࡪ࡬ࡲࡦࡵ࡫ࠫໄ"),SzGukeylg5Nsr9M20WIan)
			tUXmK5PeEH9SDq.executebuiltin(NVS30xAdRFMIw1n9CislkE2(u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬ࠬ໅"))
			return
		elif HcTPpV91FdW==jSu5Cg2Ub1OAkZVs8Yoz(u"ࠩ࠹ࠫໆ"):
			if hcfLvQzsGq4Y9E3tWboTe==YB5xyI7MaRslVpv(u"ࠪࡈࡔ࡝ࡎࡍࡑࡄࡈࠬ໇"): gj7BGM5t3RZpA0vNixLqzwualb16(YB5xyI7MaRslVpv(u"ࠫ๏ืฬ๊ࠢส่ฬ์สูษิ່ࠫ"),vvHpKfcqRnrFzjG(u"ࠬาวา์ࠣๅา฻ࠠๆๆไࠤฬ๊สฮ็ํ่້ࠬ"),KBxPW9cX8dqtaUDG=v5EA6TqHX3s4jzBMk(u"࠵࠺࠶࠰ᕻ"))
			elif hcfLvQzsGq4Y9E3tWboTe==qbPw1d3KimF(u"࠭ࡄࡆࡎࡈࡘࡊ໊࠭"): ndl0BskyaFqDxH9eJOZY7TgvVbXAt = C2jP0iLNGKnHu9xp(u"࠸࠹࠴ᕼ")
			ft3e2JBKQVXWlFPjaMhkEqGxvDg = uu970x1YwvLq6crQhsHeOj(EAdbsmyiqLtjhPlxG,SXmIKu9NvQ7xrJbAD13T,FrwM7qSAvnPOoEkUYKBZI,ndl0BskyaFqDxH9eJOZY7TgvVbXAt,WrXzD4kdcPJvuwTgyFNoUS5bBVm,WMGuOVe86zTqa4inIY2Q,QHDcUO2xtS4CmF,ezSE9fBuvT,yPoqtK3i7zHulhZJDWYsnLxvT0)
			tUXmK5PeEH9SDq.executebuiltin(BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫໋ࠫ"))
			return
		elif ezSE9fBuvT==NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠨ࠹ࠪ໌"):
			from OesqjQaWuv import ivAPY3Fo1M
			ivAPY3Fo1M()
			tUXmK5PeEH9SDq.executebuiltin(sRth5giAQzWlEVm7JOX(u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡘࡥࡧࡴࡨࡷ࡭࠭ໍ"))
			return
		elif ezSE9fBuvT==vvHpKfcqRnrFzjG(u"ࠪ࠼ࠬ໎"):
			tUXmK5PeEH9SDq.executebuiltin(C2jP0iLNGKnHu9xp(u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡖࡲࡧࡥࡹ࡫ࠨࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠪ໏")+Kczs71doMyLHwN+NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠬࡅ࡭ࡰࡦࡨࡁࠬ໐")+str(hT9FozLnDCgvPG0EXyJa7)+UnWjVbo503mEMv9KF(u"࠭ࠦࡵࡻࡳࡩࡂ࡬࡯࡭ࡦࡨࡶ࠮࠭໑"))
			return
		elif ezSE9fBuvT==FGDJwkEbTB5SoXujs3f(u"ࠧ࠺ࠩ໒"):
			bLEBi8IO7uU2x3htYDdVq95.setSetting(hhlbF1Sns5TrEN8QPCYmL4(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡷ࡫ࡦࡳࡧࡶ࡬ࠬ໓"),v5EA6TqHX3s4jzBMk(u"ࠩࡕࡉࡖ࡛ࡅࡔࡖࡈࡈࠬ໔"))
			tUXmK5PeEH9SDq.executebuiltin(LgpdP3UjFRnlX(u"ࠪࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡒࡦࡨࡵࡩࡸ࡮ࠧ໕"))
			return
	if bLEBi8IO7uU2x3htYDdVq95.getSetting(nr5mZG89ICi6cgt4MfLJa0(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡩࡶࡷࡴࡨࡧࡣࡩࡧࠪ໖")) not in [QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠬࡇࡕࡕࡑࠪ໗"),RqldvxFuM5GEQ2HAz93o7afBb0(u"࠭ࡓࡕࡑࡓࠫ໘"),sRth5giAQzWlEVm7JOX(u"ࠧࡍࡋࡐࡍ࡙ࡋࡄࠨ໙")]:
		bLEBi8IO7uU2x3htYDdVq95.setSetting(UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲࡭ࡺࡴࡱࡥࡤࡧ࡭࡫ࠧ໚"),V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠩࡄ࡙࡙ࡕࠧ໛"))
	if not bLEBi8IO7uU2x3htYDdVq95.getSetting(PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠪࡥࡻ࠴ࡤ࡯ࡵࠪໜ")): bLEBi8IO7uU2x3htYDdVq95.setSetting(T6wRistc1SCo4hqObgumK(u"ࠫࡦࡼ࠮ࡥࡰࡶࠫໝ"),HcyxqSkeNf8ROumTbVKCZLjdvB2[NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠶ᕽ")])
	ZIF98f4SswHLDNOkVtqjCuop17Tz(f9Oum6c0FotxYn)
	E0N2x1FOh7Vol8Krwa3WCmJj = bLEBi8IO7uU2x3htYDdVq95.getSetting(YB5xyI7MaRslVpv(u"ࠬࡧࡶ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮࠲ࡷ࡫ࡧࡶ࡮ࡤࡶࠬໞ"))
	E0N2x1FOh7Vol8Krwa3WCmJj = PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"࠰ᕾ") if not E0N2x1FOh7Vol8Krwa3WCmJj else int(E0N2x1FOh7Vol8Krwa3WCmJj)
	if not E0N2x1FOh7Vol8Krwa3WCmJj or not EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠱ᕿ")<=SGB7KzblUa4gCZD1srqc-E0N2x1FOh7Vol8Krwa3WCmJj<=UuEtImzir9:
		BAk1NiuR7H2sVl6(rbjsM8cRFiuA1(u"ࡊࡦࡲࡳࡦឝ"))
		vvyxX6HiqILSp = iDocG6BXv7fT2z8UVOxgP.Thread(target=XMkeJVNx6Btc7pqzrsWa9bP)
		vvyxX6HiqILSp.start()
		bLEBi8IO7uU2x3htYDdVq95.setSetting(BmcLzCFjuIrZP5fwXH18aN6YS(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡸࡥࡨࡷ࡯ࡥࡷ࠭ໟ"),str(SGB7KzblUa4gCZD1srqc))
	hEr78MBJwDn9X4F5TU0pco = bLEBi8IO7uU2x3htYDdVq95.getSetting(PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴࡬ࡰࡰࡪࠫ໠"))
	hEr78MBJwDn9X4F5TU0pco = V2RbfGOBdcA6l8NTsPWzEyvS7(u"࠲ᖀ") if not hEr78MBJwDn9X4F5TU0pco else int(hEr78MBJwDn9X4F5TU0pco)
	if not hEr78MBJwDn9X4F5TU0pco or not YB5xyI7MaRslVpv(u"࠳ᖁ")<=SGB7KzblUa4gCZD1srqc-hEr78MBJwDn9X4F5TU0pco<=IIiPCruL6dT8s1lqj47SzpVHnYNm:
		import gCUboaujSL
		gCUboaujSL.IEsKWSj05CNO(sRth5giAQzWlEVm7JOX(u"ࡌࡡ࡭ࡵࡨស"),C2jP0iLNGKnHu9xp(u"࡙ࡸࡵࡦឞ"))
		bLEBi8IO7uU2x3htYDdVq95.setSetting(qbPw1d3KimF(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮࡭ࡱࡱ࡫ࠬ໡"),str(SGB7KzblUa4gCZD1srqc))
	xFm1fHlbW2N74irt0hjLEwgOS = mVx80hrNLHnf5bkGgD7y(bLEBi8IO7uU2x3htYDdVq95.getSetting(QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠩࡤࡺ࠳ࡶࡥࡳ࡫ࡲࡨ࠳࡯࡮ࡧࡱࡶࠫ໢")))
	xFm1fHlbW2N74irt0hjLEwgOS = BoWHNb9daQVCF16A(u"࠴ᖂ") if not xFm1fHlbW2N74irt0hjLEwgOS else int(xFm1fHlbW2N74irt0hjLEwgOS)
	HHG6MFP0TYjqXSQUOsA5WVvp9wC = mVx80hrNLHnf5bkGgD7y(bLEBi8IO7uU2x3htYDdVq95.getSetting(jSu5Cg2Ub1OAkZVs8Yoz(u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰ࡴࡹࡪࡹࡴࡪࡱࡱࡷࠬ໣")))
	HHG6MFP0TYjqXSQUOsA5WVvp9wC = b05yftsZ6NYgIKP(u"࠵ᖃ") if not HHG6MFP0TYjqXSQUOsA5WVvp9wC else int(HHG6MFP0TYjqXSQUOsA5WVvp9wC)
	if not xFm1fHlbW2N74irt0hjLEwgOS or not HHG6MFP0TYjqXSQUOsA5WVvp9wC or not jSu5Cg2Ub1OAkZVs8Yoz(u"࠶ᖄ")<=SGB7KzblUa4gCZD1srqc-HHG6MFP0TYjqXSQUOsA5WVvp9wC<=xFm1fHlbW2N74irt0hjLEwgOS:
		txgVkJB69bOce87oWqXYaAjD0R = hhlbF1Sns5TrEN8QPCYmL4(u"࠱ᖅ")
		k8O9vJKsF7TqWNh6YjidXQomnf30I = RqldvxFuM5GEQ2HAz93o7afBb0(u"ࡇࡣ࡯ࡷࡪឡ") if jjwPCAGBnWFIl2L0(WMkAjB1RgN7q(u"ࠫࡔ࡚࠱࠺ࡌࡘ࠴ࡽࡈࡔࡖ࡮ࡇ࡜ࠬ໤")) else hhlbF1Sns5TrEN8QPCYmL4(u"ࡔࡳࡷࡨហ")
		if k8O9vJKsF7TqWNh6YjidXQomnf30I:
			JEUhp7OfCsPMIcBeL5Xz8nl4 = GGWFyslIXMqOpfZTdc95Y2467B1J8e(NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࡖࡵࡹࡪអ"))
			if len(JEUhp7OfCsPMIcBeL5Xz8nl4)>v5EA6TqHX3s4jzBMk(u"࠲ᖆ"):
				Lmj1pfQk63XdoeH(jx7s8T0BFgODXLMzIYedf(u"ࠬࡔࡏࡕࡋࡆࡉࠬ໥"),YB5xyI7MaRslVpv(u"࠭࠮ࠡࠢࡖ࡬ࡴࡽࡩ࡯ࡩࠣࡕࡺ࡫ࡳࡵ࡫ࡲࡲࠥࠦࠠࡑࡣࡷ࡬࠿࡛ࠦࠡࠩ໦")+SzGukeylg5Nsr9M20WIan+fY5wTlhtnOc0Er6sdy4k87b(u"ࠧࠡ࡟ࠪ໧"))
				HHSczv3E0A1JgipTBqYCPwR,ggfedDsABTMIh,WPUxzqgnlY7aVGkA2RsSt1r5X4pHjJ,D0nq5FW8AJKejN91PO,RsKWNOw4Dg91bT7SdazF,ag6Mwkfe2YZ5CdTNOLjyob3 = JEUhp7OfCsPMIcBeL5Xz8nl4[b05yftsZ6NYgIKP(u"࠲ᖇ")]
				AwFTJdHzeUl6,Hj2wTEArt3yZaL67dCXIxSp = D0nq5FW8AJKejN91PO.split(k5dztomYyN3H(u"ࠨ࡞ࡱ࠿ࡀ࠭໨"))
				del JEUhp7OfCsPMIcBeL5Xz8nl4[NVS30xAdRFMIw1n9CislkE2(u"࠳ᖈ")]
				J7M3oyXdHcnO1Sab = SS503hkALwlNIvHYW7jb.sample(JEUhp7OfCsPMIcBeL5Xz8nl4,WMkAjB1RgN7q(u"࠵ᖉ"))
				HHSczv3E0A1JgipTBqYCPwR,ggfedDsABTMIh,WPUxzqgnlY7aVGkA2RsSt1r5X4pHjJ,D0nq5FW8AJKejN91PO,RsKWNOw4Dg91bT7SdazF,ag6Mwkfe2YZ5CdTNOLjyob3 = J7M3oyXdHcnO1Sab[FGDJwkEbTB5SoXujs3f(u"࠵ᖊ")]
				WPUxzqgnlY7aVGkA2RsSt1r5X4pHjJ = C2jP0iLNGKnHu9xp(u"ࠩ࡞ࡖ࡙ࡒ࡝࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠣ࠾ࠥ࠭໩")+HHSczv3E0A1JgipTBqYCPwR+C2jP0iLNGKnHu9xp(u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ໪")+WPUxzqgnlY7aVGkA2RsSt1r5X4pHjJ
				RsKWNOw4Dg91bT7SdazF = T6wRistc1SCo4hqObgumK(u"ࠫสืำศๆࠣีุอไสࠢ็่๊ฮัๆฮࠪ໫")
				TRC5Z9hlk6QxtcBrE = BoWHNb9daQVCF16A(u"ࠬอไหสิ฽ฬะࠧ໬")
				button0,button1 = D0nq5FW8AJKejN91PO,RsKWNOw4Dg91bT7SdazF
				DDgrys4UPlf2a6oRMqiG = [button0,button1,TRC5Z9hlk6QxtcBrE]
				pJeD0ljE7GMsr6uXahTokcnHb = b05yftsZ6NYgIKP(u"࠷ᖋ") if jjwPCAGBnWFIl2L0(QynMHGWA0blfqTUdxRh5Jzi2t(u"࠭ࡗࡔࡗࡕࡊ࡙࠷࠹ࡒࡖࡈࡊ࡟࡞ࠧ໭")) else rbjsM8cRFiuA1(u"࠱࠱ᖌ")
				D6LK2dzYZMco = -gItVahxL0w(u"࠺ᖍ")
				while D6LK2dzYZMco<BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠲ᖎ"):
					aSL1opHz3E = SS503hkALwlNIvHYW7jb.sample(DDgrys4UPlf2a6oRMqiG,BoWHNb9daQVCF16A(u"࠶ᖏ"))
					D6LK2dzYZMco = Uu0ZdNAP1BWc28lR(NVS30xAdRFMIw1n9CislkE2(u"ࠧࠨ໮"),aSL1opHz3E[UnWjVbo503mEMv9KF(u"࠵ᖑ")],aSL1opHz3E[qbPw1d3KimF(u"࠵ᖐ")],aSL1opHz3E[jSu5Cg2Ub1OAkZVs8Yoz(u"࠸ᖒ")],AwFTJdHzeUl6,WPUxzqgnlY7aVGkA2RsSt1r5X4pHjJ,jx7s8T0BFgODXLMzIYedf(u"ࠨࡥࡲࡲ࡫࡯ࡲ࡮ࡡࡥ࡭࡬࡬࡯࡯ࡶࠪ໯"),pJeD0ljE7GMsr6uXahTokcnHb,BmcLzCFjuIrZP5fwXH18aN6YS(u"࠶࠱ᖓ"))
					if D6LK2dzYZMco==NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠲࠲ᖔ"): break
					from gCUboaujSL import EEbGBNzAQydpnq,b3MUYKf9RupWmrl
					if D6LK2dzYZMco>=jx7s8T0BFgODXLMzIYedf(u"࠳ᖖ") and aSL1opHz3E[D6LK2dzYZMco]==DDgrys4UPlf2a6oRMqiG[WMkAjB1RgN7q(u"࠳ᖕ")]:
						EEbGBNzAQydpnq()
						if D6LK2dzYZMco>=k5dztomYyN3H(u"࠵ᖘ"): D6LK2dzYZMco = -gItVahxL0w(u"࠽ᖗ")
					elif D6LK2dzYZMco>=C2jP0iLNGKnHu9xp(u"࠶ᖙ") and aSL1opHz3E[D6LK2dzYZMco]==DDgrys4UPlf2a6oRMqiG[BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠲ᖚ")]:
						b3MUYKf9RupWmrl(BoWHNb9daQVCF16A(u"ࡉࡥࡱࡹࡥឣ"))
					if D6LK2dzYZMco==-NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠲ᖛ"): ZIOHgA3z0TBR(FGDJwkEbTB5SoXujs3f(u"ࠩࠪ໰"),l0WAe1f7Bpi5ZXk(u"ࠪࠫ໱"),NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ໲"),QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ฯำ๋ะࠥิืฤ࡝࠲ࡇࡔࡒࡏࡓ࡟࡟ࡲ๊ࠥไฯำ๋ะࠥอไึฯํัࠥษฮหำࠣ์ฬำฯࠡ็้ࠤฬ๊รอ๊หอࠥอไๆฬ๋ๅึฯࠧ໳"))
				txgVkJB69bOce87oWqXYaAjD0R = hhlbF1Sns5TrEN8QPCYmL4(u"࠳ᖜ")
			else: txgVkJB69bOce87oWqXYaAjD0R = T6wRistc1SCo4hqObgumK(u"࠳ᖝ")
		bLEBi8IO7uU2x3htYDdVq95.setSetting(QynMHGWA0blfqTUdxRh5Jzi2t(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡷࡵࡦࡵࡷ࡭ࡴࡴࡳࠨ໴"),UnJu5mvBrPKqOidwpNcjAbh(SGB7KzblUa4gCZD1srqc))
		VZ8BTik93OqXLCh0fD7d2KUPpn4mH6(RnqtMUa9Nh6peGEsBT,C2jP0iLNGKnHu9xp(u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪ໵"),FGDJwkEbTB5SoXujs3f(u"ࠨࡕࡌࡘࡊ࡙࡟ࡏࡃࡐࡉࡘ࠭໶"),txgVkJB69bOce87oWqXYaAjD0R,BZdvf7MIUxHQc3aCT)
	ft3e2JBKQVXWlFPjaMhkEqGxvDg = uu970x1YwvLq6crQhsHeOj(EAdbsmyiqLtjhPlxG,SXmIKu9NvQ7xrJbAD13T,FrwM7qSAvnPOoEkUYKBZI,hT9FozLnDCgvPG0EXyJa7,WrXzD4kdcPJvuwTgyFNoUS5bBVm,WMGuOVe86zTqa4inIY2Q,QHDcUO2xtS4CmF,ezSE9fBuvT,yPoqtK3i7zHulhZJDWYsnLxvT0)
	if l0WAe1f7Bpi5ZXk(u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ໷") in QHDcUO2xtS4CmF: OXHVSz957gsf3cKw = fY5wTlhtnOc0Er6sdy4k87b(u"ࡘࡷࡻࡥឤ")
	if EAdbsmyiqLtjhPlxG==v5EA6TqHX3s4jzBMk(u"ࠪࡪࡴࡲࡤࡦࡴࠪ໸"):
		if HHQYtifTDV!=b05yftsZ6NYgIKP(u"ࠫ࠳࠴ࠧ໹") and BARfpCqGy9ZHtTFO1jI: ivqDg9QFCIArMf1PO7WwU3lR()
		if n6ReHNYovBwFxiuJ>-NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠵ᖞ"):
			if (zPgNsqpJInt(RnqtMUa9Nh6peGEsBT,nr5mZG89ICi6cgt4MfLJa0(u"ࠬ࡯࡮ࡵࠩ໺"),C2dgEDAKQGsvh(u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩ໻"),C2jP0iLNGKnHu9xp(u"ࠧࡔࡋࡗࡉࡘࡥࡎࡂࡏࡈࡗࠬ໼")) or ndl0BskyaFqDxH9eJOZY7TgvVbXAt not in X0DBFl5Pe7n6O9) and not jjwPCAGBnWFIl2L0(NVS30xAdRFMIw1n9CislkE2(u"ࠨࡅࡗࡉ࠾ࡊࡓ࠲࠻࡙࡙࠵࡜ࡓ࡙ࠩ໽")):
				from sz35WLBk4K import min2xGoHEy67RY1hS8L0CwtsfzWlp
				qEX4y0ZW6CrSAGibe = nUA4GswYhy(min2xGoHEy67RY1hS8L0CwtsfzWlp)
				dBmpzjIUyLoVQR = VsShzn5wMuYP(h8PATfY3gnbWylpxd,qEX4y0ZW6CrSAGibe,tUEvo5HAfIjZgcdYxNJ8awu,OXHVSz957gsf3cKw,pZbHmRVkwf2aIUqJYOSjr943B0MnP5)
				if b05yftsZ6NYgIKP(u"࠶ᖟ") and qEX4y0ZW6CrSAGibe and V5OHQA3qYIwp0BTD2tNW4m:
					VZ8BTik93OqXLCh0fD7d2KUPpn4mH6(RnqtMUa9Nh6peGEsBT,BoWHNb9daQVCF16A(u"ࠩࡐࡉࡓ࡛ࡓࡠࡅࡄࡇࡍࡋ࡟ࠨ໾")+ZpcH2XUBJujAKqv+b05yftsZ6NYgIKP(u"ࠪࡣࠬ໿")+c4oFda8RgQ,h8PATfY3gnbWylpxd,qEX4y0ZW6CrSAGibe,UuEtImzir9)
			else:
				VMKAudnbXHORPj.addDirectoryItem(n6ReHNYovBwFxiuJ,RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࠧༀ")+Kczs71doMyLHwN+UnWjVbo503mEMv9KF(u"ࠬ࠵࠿ࡵࡻࡳࡩࡂࡲࡩ࡯࡭ࠩࡱࡴࡪࡥ࠾࠷࠳࠴ࠬ༁"),XUYb0K2ghSyFs.ListItem(BoWHNb9daQVCF16A(u"࠭ไะ์ๆࠤฺ๊ใๅห้๋ࠣࠦฬ่ษี็ࠬ༂")))
				VMKAudnbXHORPj.addDirectoryItem(n6ReHNYovBwFxiuJ,YB5xyI7MaRslVpv(u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠪ༃")+Kczs71doMyLHwN+jx7s8T0BFgODXLMzIYedf(u"ࠨ࠱ࡂࡸࡾࡶࡥ࠾࡮࡬ࡲࡰࠬ࡭ࡰࡦࡨࡁ࠺࠶࠰ࠨ༄"),XUYb0K2ghSyFs.ListItem(k5dztomYyN3H(u"ࠩฦๅฯำࠠๅฬๅีศࠦวๅฬไหฺ๐ไࠨ༅")))
			VMKAudnbXHORPj.endOfDirectory(n6ReHNYovBwFxiuJ,tUEvo5HAfIjZgcdYxNJ8awu,OXHVSz957gsf3cKw,pZbHmRVkwf2aIUqJYOSjr943B0MnP5)
	return
def ZIF98f4SswHLDNOkVtqjCuop17Tz(az8LxV1UHGTYBp):
	MMSPxEmhlJkRuf70F3dt = RqldvxFuM5GEQ2HAz93o7afBb0(u"ࡌࡡ࡭ࡵࡨឦ") if az8LxV1UHGTYBp else WMkAjB1RgN7q(u"࡙ࡸࡵࡦឥ")
	if not MMSPxEmhlJkRuf70F3dt:
		PI6gBKxh9nQZR31SUiuVGT2v = mVx80hrNLHnf5bkGgD7y(bLEBi8IO7uU2x3htYDdVq95.getSetting(UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰ࡰࡩࡸࡹࡡࡨࡧࡶࠫ༆")))
		PI6gBKxh9nQZR31SUiuVGT2v = hhlbF1Sns5TrEN8QPCYmL4(u"࠶ᖠ") if not PI6gBKxh9nQZR31SUiuVGT2v else int(PI6gBKxh9nQZR31SUiuVGT2v)
		if not PI6gBKxh9nQZR31SUiuVGT2v or not qbPw1d3KimF(u"࠰ᖡ")<=SGB7KzblUa4gCZD1srqc-PI6gBKxh9nQZR31SUiuVGT2v<=az8LxV1UHGTYBp: MMSPxEmhlJkRuf70F3dt = l0WAe1f7Bpi5ZXk(u"ࡔࡳࡷࡨឧ")
	if not MMSPxEmhlJkRuf70F3dt:
		xEigKW0c1RCUDnFo2b3vwuABdjLQ = bLEBi8IO7uU2x3htYDdVq95.getSetting(RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩ༇"))
		if xEigKW0c1RCUDnFo2b3vwuABdjLQ in [rbjsM8cRFiuA1(u"ࠬ࠭༈"),BoWHNb9daQVCF16A(u"࠭ࡏࡍࡆࡢࡘࡔࡥࡅࡓࡔࡒࡖࠬ༉"),T6wRistc1SCo4hqObgumK(u"ࠧࡏࡇ࡚ࡣ࡙ࡕ࡟ࡆࡔࡕࡓࡗ࠭༊")]: MMSPxEmhlJkRuf70F3dt = QynMHGWA0blfqTUdxRh5Jzi2t(u"ࡕࡴࡸࡩឨ")
	if not MMSPxEmhlJkRuf70F3dt:
		from hashlib import md5 as UPTJpd3eoxqc6DgQ8X5bCu2IARm
		VTtyliOIEx1rnHBqJsf3QwAS4ac = bLEBi8IO7uU2x3htYDdVq95.getSetting(BoWHNb9daQVCF16A(u"ࠨࡣࡹ࠲ࡵࡸࡩࡷࡵ࠴ࠫ་"))
		Ubwy7kR8p9ZEHtX6d = bLEBi8IO7uU2x3htYDdVq95.getSetting(NVS30xAdRFMIw1n9CislkE2(u"ࠩࡤࡺ࠳ࡶࡲࡪࡸࡶ࠶ࠬ༌"))
		ZFUPDjAempKQrWB7nb8 = UPTJpd3eoxqc6DgQ8X5bCu2IARm(V2RbfGOBdcA6l8NTsPWzEyvS7(u"࠶ᖢ")*VTtyliOIEx1rnHBqJsf3QwAS4ac.encode(BoWHNb9daQVCF16A(u"ࠪࡹࡹ࡬࠸ࠨ།"))).hexdigest()
		ZFUPDjAempKQrWB7nb8 = UPTJpd3eoxqc6DgQ8X5bCu2IARm(fY5wTlhtnOc0Er6sdy4k87b(u"࠳࠷ᖣ")*ZFUPDjAempKQrWB7nb8.encode(v5EA6TqHX3s4jzBMk(u"ࠫࡺࡺࡦ࠹ࠩ༎"))).hexdigest()
		ZFUPDjAempKQrWB7nb8 = UPTJpd3eoxqc6DgQ8X5bCu2IARm(LgpdP3UjFRnlX(u"࠴࠽ᖤ")*ZFUPDjAempKQrWB7nb8.encode(C2dgEDAKQGsvh(u"ࠬࡻࡴࡧ࠺ࠪ༏"))).hexdigest()
		if ZFUPDjAempKQrWB7nb8!=Ubwy7kR8p9ZEHtX6d: MMSPxEmhlJkRuf70F3dt = NVS30xAdRFMIw1n9CislkE2(u"ࡖࡵࡹࡪឩ")
	if MMSPxEmhlJkRuf70F3dt: bbvwO2iulBaz0QjMcEsrypR6xLX = bMABswNzQganI1kmReiOdjLypS3(BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࡉࡥࡱࡹࡥឪ"))
	return
def uu970x1YwvLq6crQhsHeOj(EAdbsmyiqLtjhPlxG,gg37KuOokaYFs8qTiezZn1tJ4jLr6,qmr7vLh1EW,hT9FozLnDCgvPG0EXyJa7,QFrVYJkywEsXquMNz,z3z9QgENFk5eMYB4,QHDcUO2xtS4CmF,ezSE9fBuvT,yPoqtK3i7zHulhZJDWYsnLxvT0):
	ndl0BskyaFqDxH9eJOZY7TgvVbXAt = int(hT9FozLnDCgvPG0EXyJa7)
	WrI1XaHkSE7iKbOxJ8Nz9qFC = int(ndl0BskyaFqDxH9eJOZY7TgvVbXAt//k5dztomYyN3H(u"࠵࠵ᖥ"))
	if   WrI1XaHkSE7iKbOxJ8Nz9qFC==V2RbfGOBdcA6l8NTsPWzEyvS7(u"࠵ᖦ"):  from gCUboaujSL 		import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,QHDcUO2xtS4CmF)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==jSu5Cg2Ub1OAkZVs8Yoz(u"࠷ᖧ"):  from m2biKLFy9j 		import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,qmr7vLh1EW,QHDcUO2xtS4CmF)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==sRth5giAQzWlEVm7JOX(u"࠲ᖨ"):  from wwcbEpKRoJ 			import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,qmr7vLh1EW,z3z9QgENFk5eMYB4,QHDcUO2xtS4CmF)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==sRth5giAQzWlEVm7JOX(u"࠴ᖩ"):  from mnvCWUE47k 			import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,qmr7vLh1EW,z3z9QgENFk5eMYB4,QHDcUO2xtS4CmF)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==sRth5giAQzWlEVm7JOX(u"࠶ᖪ"):  from euTyFV9CtL 		import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,qmr7vLh1EW,QHDcUO2xtS4CmF,z3z9QgENFk5eMYB4)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==UnWjVbo503mEMv9KF(u"࠸ᖫ"):  from ssOuZYjF2h 		import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,qmr7vLh1EW,QHDcUO2xtS4CmF)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==v5EA6TqHX3s4jzBMk(u"࠺ᖬ"):  from oy2gMwbCnW 		import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,qmr7vLh1EW,QHDcUO2xtS4CmF)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==v5EA6TqHX3s4jzBMk(u"࠼ᖭ"):  from qS2COlbni0 			import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,qmr7vLh1EW,QHDcUO2xtS4CmF)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==FGDJwkEbTB5SoXujs3f(u"࠾ᖮ"):  from nSvp1c7TaC 		import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,qmr7vLh1EW,QHDcUO2xtS4CmF)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠹ᖯ"):  from U3fWvysXri		import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,qmr7vLh1EW,QHDcUO2xtS4CmF)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==b05yftsZ6NYgIKP(u"࠲࠲ᖰ"): from jexwNETf0R 		import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,qmr7vLh1EW)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"࠳࠴ᖱ"): from XOVAKMYPIL 		import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,qmr7vLh1EW,QHDcUO2xtS4CmF)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==T6wRistc1SCo4hqObgumK(u"࠴࠶ᖲ"): from Uyd9BOm3hq 		import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,qmr7vLh1EW,z3z9QgENFk5eMYB4,QHDcUO2xtS4CmF)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"࠵࠸ᖳ"): from PFEHN9up2j		import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,qmr7vLh1EW,z3z9QgENFk5eMYB4,QHDcUO2xtS4CmF)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==v5EA6TqHX3s4jzBMk(u"࠶࠺ᖴ"): from yy16g9xBYs 		import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,qmr7vLh1EW,QHDcUO2xtS4CmF,EAdbsmyiqLtjhPlxG,z3z9QgENFk5eMYB4,gg37KuOokaYFs8qTiezZn1tJ4jLr6,QFrVYJkywEsXquMNz)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==C2dgEDAKQGsvh(u"࠷࠵ᖵ"): from gCUboaujSL 		import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,QHDcUO2xtS4CmF)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠱࠷ᖶ"): from vmGg52xdI9		import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,qmr7vLh1EW,QHDcUO2xtS4CmF,z3z9QgENFk5eMYB4,yPoqtK3i7zHulhZJDWYsnLxvT0)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==WMkAjB1RgN7q(u"࠲࠹ᖷ"): from gCUboaujSL 		import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,QHDcUO2xtS4CmF)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==qbPw1d3KimF(u"࠳࠻ᖸ"): from b1t0cOugsP		import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,qmr7vLh1EW,QHDcUO2xtS4CmF)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==YB5xyI7MaRslVpv(u"࠴࠽ᖹ"): from gCUboaujSL 		import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,QHDcUO2xtS4CmF)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==WMkAjB1RgN7q(u"࠶࠵ᖺ"): from zZjawg7d34		import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,qmr7vLh1EW,QHDcUO2xtS4CmF)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==BoWHNb9daQVCF16A(u"࠷࠷ᖻ"): from llkjuqJVXU	import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,qmr7vLh1EW,QHDcUO2xtS4CmF)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==v5EA6TqHX3s4jzBMk(u"࠸࠲ᖼ"): from b10YZJFD9T		import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,qmr7vLh1EW,z3z9QgENFk5eMYB4,QHDcUO2xtS4CmF)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==YB5xyI7MaRslVpv(u"࠲࠴ᖽ"): from OJR51gj7FS	import zfogEMcGC60	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = zfogEMcGC60(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,qmr7vLh1EW,QHDcUO2xtS4CmF,EAdbsmyiqLtjhPlxG,z3z9QgENFk5eMYB4,yPoqtK3i7zHulhZJDWYsnLxvT0)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==BmcLzCFjuIrZP5fwXH18aN6YS(u"࠳࠶ᖾ"): from AHyTtY8FEJ 			import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,qmr7vLh1EW,QHDcUO2xtS4CmF)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==BmcLzCFjuIrZP5fwXH18aN6YS(u"࠴࠸ᖿ"): from YTJnkQy0SN 		import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,qmr7vLh1EW,QHDcUO2xtS4CmF)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==v5EA6TqHX3s4jzBMk(u"࠵࠺ᗀ"): from sz35WLBk4K 			import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,qmr7vLh1EW,QHDcUO2xtS4CmF)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==vvHpKfcqRnrFzjG(u"࠶࠼ᗁ"): from wfQhx1AiCD	import zfogEMcGC60	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = zfogEMcGC60(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,ezSE9fBuvT)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==nr5mZG89ICi6cgt4MfLJa0(u"࠷࠾ᗂ"): from OJR51gj7FS	import zfogEMcGC60	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = zfogEMcGC60(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,qmr7vLh1EW,QHDcUO2xtS4CmF,EAdbsmyiqLtjhPlxG,z3z9QgENFk5eMYB4,yPoqtK3i7zHulhZJDWYsnLxvT0)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠸࠹ᗃ"): from PUApVYoKJq	import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,qmr7vLh1EW,z3z9QgENFk5eMYB4,QHDcUO2xtS4CmF)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==gItVahxL0w(u"࠳࠱ᗄ"): from nb2dEKuRFN		import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,qmr7vLh1EW,QHDcUO2xtS4CmF)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==sRth5giAQzWlEVm7JOX(u"࠴࠳ᗅ"): from RRhb5T0SZN		import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,qmr7vLh1EW,QHDcUO2xtS4CmF)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==RqldvxFuM5GEQ2HAz93o7afBb0(u"࠵࠵ᗆ"): from eaC31XohSd		import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,qmr7vLh1EW,QHDcUO2xtS4CmF)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==BmcLzCFjuIrZP5fwXH18aN6YS(u"࠶࠷ᗇ"): from NREgAj46Ve		import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,qmr7vLh1EW)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==C2dgEDAKQGsvh(u"࠷࠹ᗈ"): from gCUboaujSL 		import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,QHDcUO2xtS4CmF)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==V2RbfGOBdcA6l8NTsPWzEyvS7(u"࠸࠻ᗉ"): from kkm9QT8Kbn		import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,qmr7vLh1EW,QHDcUO2xtS4CmF)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==hhlbF1Sns5TrEN8QPCYmL4(u"࠹࠶ᗊ"): from xPDZYpvG74			import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,qmr7vLh1EW,QHDcUO2xtS4CmF)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==FGDJwkEbTB5SoXujs3f(u"࠳࠸ᗋ"): from KwC3gyFDv4			import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,qmr7vLh1EW,QHDcUO2xtS4CmF)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠴࠺ᗌ"): from b5bJkOI4c8 		import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,qmr7vLh1EW,QHDcUO2xtS4CmF)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==WMkAjB1RgN7q(u"࠵࠼ᗍ"): from FrmEf52pT4		import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,qmr7vLh1EW,QHDcUO2xtS4CmF)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠷࠴ᗎ"): from fDYtH3JzIi	import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,qmr7vLh1EW,QHDcUO2xtS4CmF,EAdbsmyiqLtjhPlxG,z3z9QgENFk5eMYB4)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==gItVahxL0w(u"࠸࠶ᗏ"): from fDYtH3JzIi	import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,qmr7vLh1EW,QHDcUO2xtS4CmF,EAdbsmyiqLtjhPlxG,z3z9QgENFk5eMYB4)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==YB5xyI7MaRslVpv(u"࠹࠸ᗐ"): from RGB6zqroux			import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,qmr7vLh1EW,QHDcUO2xtS4CmF)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==LgpdP3UjFRnlX(u"࠺࠳ᗑ"): from RUXamQHCMN			import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,qmr7vLh1EW,QHDcUO2xtS4CmF)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==v5EA6TqHX3s4jzBMk(u"࠴࠵ᗒ"): from thnVAoRm7i		import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,qmr7vLh1EW,QHDcUO2xtS4CmF)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==QynMHGWA0blfqTUdxRh5Jzi2t(u"࠵࠷ᗓ"): from Ww2bf9n3X6		import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,qmr7vLh1EW,QHDcUO2xtS4CmF)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==NVS30xAdRFMIw1n9CislkE2(u"࠶࠹ᗔ"): from jNaYJCozPl			import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,qmr7vLh1EW,QHDcUO2xtS4CmF)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠷࠻ᗕ"): from BkeL3UtRAW		import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,qmr7vLh1EW,QHDcUO2xtS4CmF)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==vvHpKfcqRnrFzjG(u"࠸࠽ᗖ"): from V5PYLF4G6Q		import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,qmr7vLh1EW,QHDcUO2xtS4CmF)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==vvHpKfcqRnrFzjG(u"࠹࠿ᗗ"): from RcVUhTGuSn		import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,qmr7vLh1EW,QHDcUO2xtS4CmF)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==jSu5Cg2Ub1OAkZVs8Yoz(u"࠻࠰ᗘ"): from gCUboaujSL 		import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,QHDcUO2xtS4CmF)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==qbPw1d3KimF(u"࠵࠲ᗙ"): from oB0nmKMW4h 		import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,qmr7vLh1EW,QHDcUO2xtS4CmF)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==rbjsM8cRFiuA1(u"࠶࠴ᗚ"): from oB0nmKMW4h 		import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,qmr7vLh1EW,QHDcUO2xtS4CmF)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==jSu5Cg2Ub1OAkZVs8Yoz(u"࠷࠶ᗛ"): from sz35WLBk4K 			import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,qmr7vLh1EW,QHDcUO2xtS4CmF)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==NVS30xAdRFMIw1n9CislkE2(u"࠸࠸ᗜ"): from OesqjQaWuv	import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,qmr7vLh1EW,QHDcUO2xtS4CmF,z3z9QgENFk5eMYB4)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==QynMHGWA0blfqTUdxRh5Jzi2t(u"࠹࠺ᗝ"): from lMz5pnymV7 		import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,qmr7vLh1EW,QHDcUO2xtS4CmF)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==qbPw1d3KimF(u"࠺࠼ᗞ"): from qbHfJWnrKv			import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,qmr7vLh1EW,QHDcUO2xtS4CmF)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==BmcLzCFjuIrZP5fwXH18aN6YS(u"࠻࠷ᗟ"): from NNuy3mrgVF		import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,qmr7vLh1EW,QHDcUO2xtS4CmF)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==k5dztomYyN3H(u"࠵࠹ᗠ"): from fzvqVB3ckA		import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,qmr7vLh1EW,QHDcUO2xtS4CmF)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==LgpdP3UjFRnlX(u"࠶࠻ᗡ"): from En3hKe5PRa		import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,qmr7vLh1EW,QHDcUO2xtS4CmF)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠸࠳ᗢ"): from B2nUyjObRW			import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,qmr7vLh1EW,QHDcUO2xtS4CmF)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==UxS67uoGThbMwnfNRzy4gajLd23JH(u"࠹࠵ᗣ"): from OQb7Na9162			import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,qmr7vLh1EW,QHDcUO2xtS4CmF)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==LgpdP3UjFRnlX(u"࠺࠷ᗤ"): from ydRc0bjKop		import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,qmr7vLh1EW,QHDcUO2xtS4CmF)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==WMkAjB1RgN7q(u"࠻࠹ᗥ"): from JJrykEjtmX	import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,qmr7vLh1EW,QHDcUO2xtS4CmF)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==T6wRistc1SCo4hqObgumK(u"࠼࠴ᗦ"): from YvWs3LpDg8			import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,qmr7vLh1EW,QHDcUO2xtS4CmF)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==BoWHNb9daQVCF16A(u"࠶࠶ᗧ"): from t7ln5dkPDA			import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,qmr7vLh1EW,QHDcUO2xtS4CmF)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==V2RbfGOBdcA6l8NTsPWzEyvS7(u"࠷࠸ᗨ"): from A28AzUCctK			import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,qmr7vLh1EW,QHDcUO2xtS4CmF)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==T6wRistc1SCo4hqObgumK(u"࠸࠺ᗩ"): from FeR60HQSEZ		import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,qmr7vLh1EW,QHDcUO2xtS4CmF)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==qbPw1d3KimF(u"࠹࠼ᗪ"): from APs8IgpkVw		import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,qmr7vLh1EW,QHDcUO2xtS4CmF)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==rbjsM8cRFiuA1(u"࠺࠾ᗫ"): from H51bOV6EjZ		import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,qmr7vLh1EW,QHDcUO2xtS4CmF)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==QynMHGWA0blfqTUdxRh5Jzi2t(u"࠼࠶ᗬ"): from YumHoLDAij			import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,qmr7vLh1EW,QHDcUO2xtS4CmF)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==k5dztomYyN3H(u"࠽࠱ᗭ"): from F9HnjCOwhi	import zfogEMcGC60	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = zfogEMcGC60(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,qmr7vLh1EW,QHDcUO2xtS4CmF,EAdbsmyiqLtjhPlxG,z3z9QgENFk5eMYB4,yPoqtK3i7zHulhZJDWYsnLxvT0)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==T6wRistc1SCo4hqObgumK(u"࠷࠳ᗮ"): from F9HnjCOwhi	import zfogEMcGC60	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = zfogEMcGC60(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,qmr7vLh1EW,QHDcUO2xtS4CmF,EAdbsmyiqLtjhPlxG,z3z9QgENFk5eMYB4,yPoqtK3i7zHulhZJDWYsnLxvT0)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==FGDJwkEbTB5SoXujs3f(u"࠸࠵ᗯ"): from ka4bKidFX0	import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,qmr7vLh1EW,QHDcUO2xtS4CmF)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==C2dgEDAKQGsvh(u"࠹࠷ᗰ"): from OGH7jQYKSd		import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==LgpdP3UjFRnlX(u"࠺࠹ᗱ"): from OGH7jQYKSd		import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==WMkAjB1RgN7q(u"࠻࠻ᗲ"): from vmGg52xdI9		import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,qmr7vLh1EW,QHDcUO2xtS4CmF,z3z9QgENFk5eMYB4,yPoqtK3i7zHulhZJDWYsnLxvT0)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠼࠽ᗳ"): from iFbpAPx1an 		import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,qmr7vLh1EW,z3z9QgENFk5eMYB4,QHDcUO2xtS4CmF)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==jx7s8T0BFgODXLMzIYedf(u"࠽࠸ᗴ"): from UgSz2QtnM0 		import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,qmr7vLh1EW,z3z9QgENFk5eMYB4,QHDcUO2xtS4CmF)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==YB5xyI7MaRslVpv(u"࠷࠺ᗵ"): from LLWVaQmdit 		import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,qmr7vLh1EW,z3z9QgENFk5eMYB4,QHDcUO2xtS4CmF)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==LgpdP3UjFRnlX(u"࠹࠲ᗶ"): from WPFZdiEaz2 		import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,qmr7vLh1EW,z3z9QgENFk5eMYB4,QHDcUO2xtS4CmF)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==BoWHNb9daQVCF16A(u"࠺࠴ᗷ"): from UUYFfLwvgu 		import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,qmr7vLh1EW,QHDcUO2xtS4CmF)
	elif WrI1XaHkSE7iKbOxJ8Nz9qFC==sRth5giAQzWlEVm7JOX(u"࠻࠶ᗸ"): from j7ZSy5oc1m		import VbgEajY4Bt2COpGDcPqI	; ft3e2JBKQVXWlFPjaMhkEqGxvDg = VbgEajY4Bt2COpGDcPqI(ndl0BskyaFqDxH9eJOZY7TgvVbXAt,qmr7vLh1EW,z3z9QgENFk5eMYB4,QHDcUO2xtS4CmF)
	else: ft3e2JBKQVXWlFPjaMhkEqGxvDg = None
	return ft3e2JBKQVXWlFPjaMhkEqGxvDg
def kpASjm2iFqNCb4c5I(H7agXMdxq32DwufZ,ag6Mwkfe2YZ5CdTNOLjyob3,iW6eqtHJGnzFhTSgduj7Pys2w,showDialogs):
	xvH1PfgscOb0Bw9Ljn = bLEBi8IO7uU2x3htYDdVq95.getSetting(sRth5giAQzWlEVm7JOX(u"࠭ࡡࡷ࠰࡯ࡥࡳ࡭ࡵࡢࡩࡨ࠲ࡹࡸࡡ࡯ࡵ࡯ࡥࡹ࡫ࠧ༐"))
	bLEBi8IO7uU2x3htYDdVq95.setSetting(WMkAjB1RgN7q(u"ࠧࡢࡸ࠱ࡰࡦࡴࡧࡶࡣࡪࡩ࠳ࡺࡲࡢࡰࡶࡰࡦࡺࡥࠨ༑"),YB5xyI7MaRslVpv(u"ࠨࠩ༒"))
	if fY5wTlhtnOc0Er6sdy4k87b(u"ࠩ࠰ࠫ༓") in iW6eqtHJGnzFhTSgduj7Pys2w: bo1dqzR8JIwlThvDcyU4jf = iW6eqtHJGnzFhTSgduj7Pys2w.split(b05yftsZ6NYgIKP(u"ࠪ࠱ࠬ༔"),v5EA6TqHX3s4jzBMk(u"࠵ᗹ"))[BmcLzCFjuIrZP5fwXH18aN6YS(u"࠵ᗺ")]
	else: bo1dqzR8JIwlThvDcyU4jf = iW6eqtHJGnzFhTSgduj7Pys2w
	rkHULoDN2XnFEwuPSWMpYm0cC7R3 = H7agXMdxq32DwufZ in [k5dztomYyN3H(u"࠹ᗾ"),sRth5giAQzWlEVm7JOX(u"࠱࠲࠲࠳࠵ᗼ"),QynMHGWA0blfqTUdxRh5Jzi2t(u"࠷࠱࠱࠲࠵ᗻ"),jx7s8T0BFgODXLMzIYedf(u"࠲࠲࠳࠹࠹ᗽ")]
	Y9BevOsKyHqo5EhPbm2n = ag6Mwkfe2YZ5CdTNOLjyob3.lower()
	N3XtD4lwSYLI6xT0RvHOzbaGr = H7agXMdxq32DwufZ in [v5EA6TqHX3s4jzBMk(u"࠳ᗿ"),UxS67uoGThbMwnfNRzy4gajLd23JH(u"࠷࠰࠵ᘂ"),NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠵࠵࠶࠶࠲ᘀ"),vvHpKfcqRnrFzjG(u"࠶࠷࠱ᘁ")]
	ggWv8w7PMF9a6Bico = EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠫࡧࡲ࡯ࡤ࡭ࡨࡨࠥࡨࡹࠡࡥ࡯ࡳࡺࡪࡦ࡭ࡣࡵࡩࠬ༕") in Y9BevOsKyHqo5EhPbm2n
	RoJny9O7tdmpUFM = UnWjVbo503mEMv9KF(u"ࠬࡨ࡬ࡰࡥ࡮ࡩࡩࠦࡢࡺࠢ࠸ࠤࡸ࡫ࡣࡰࡰࡧࡷࠥࡨࡲࡰࡹࡶࡩࡷࠦࡣࡩࡧࡦ࡯ࠬ༖") in Y9BevOsKyHqo5EhPbm2n
	YYfOZa0oNiRAF4mewsbh = b05yftsZ6NYgIKP(u"࠭ࡢ࡭ࡱࡦ࡯ࡪࡪࠠࡣࡻࠣࡶࡪࡩࡡࡱࡶࡦ࡬ࡦ࠭༗") in Y9BevOsKyHqo5EhPbm2n
	zzmyaNslBTVW = jSu5Cg2Ub1OAkZVs8Yoz(u"ࠧࡣ࡮ࡲࡧࡰ࡫ࡤࠡࡤࡼࠤࡨࡲ࡯ࡶࡦࡩࡰࡦࡸࡥࠡࡵࡨࡧࡺࡸࡩࡵࡻࠣࡧ࡭࡫ࡣ࡬༘ࠩ") in Y9BevOsKyHqo5EhPbm2n
	NMWlwz87p6EmSGx2Uy1i9h4VfCrnI = bLEBi8IO7uU2x3htYDdVq95.getSetting(sRth5giAQzWlEVm7JOX(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡺࡹࡥࡱࡴࡲࡼࡾ༙࠭"))
	h7cjS8YXyNqgQPsk4WLlG3x = bLEBi8IO7uU2x3htYDdVq95.getSetting(UnWjVbo503mEMv9KF(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡦࡱࡷࠬ༚"))
	WIHtXSMQyzumo8FLYcCfw = QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠪๅู๊ࠠโ์ࠣืาฮࠠศๆุๅาฯࠠๆ่ࠣห้หๆหำ้ฮࠬ༛")
	YyiLTwVKmXFObS7kfC = hhlbF1Sns5TrEN8QPCYmL4(u"ࠫࡊࡸࡲࡰࡴࠣࠫ༜")+str(H7agXMdxq32DwufZ)+RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠬࡀࠠࠨ༝")+ag6Mwkfe2YZ5CdTNOLjyob3
	YyiLTwVKmXFObS7kfC = XnQbsZF0Ouh8p7zCdUN(YyiLTwVKmXFObS7kfC)
	if N3XtD4lwSYLI6xT0RvHOzbaGr or ggWv8w7PMF9a6Bico or RoJny9O7tdmpUFM or YYfOZa0oNiRAF4mewsbh or zzmyaNslBTVW:
		WIHtXSMQyzumo8FLYcCfw += C2dgEDAKQGsvh(u"࠭ࠠ࠯ࠢส่๊๎โฺࠢไ๎์ࠦออสฺࠣิࠦใ้ัํࠤ๊฻ฯา้ࠣห้หๆหำ้ฮࠥอไฯษุࠤอ้ࠠฤ๊ࠣฬฬ๊ๅ้ไ฼ࡠࡳ࠭༞")
	if rkHULoDN2XnFEwuPSWMpYm0cC7R3: WIHtXSMQyzumo8FLYcCfw += PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠧࠡ࠰่ࠣิ๐ใࠡะฺวࠥࡊࡎࡔ๋้ࠢ฾์ว่ࠢอ฽ีืࠠหำฯ้ฮࠦวิ็ࠣห้๋่ใ฻ࠣษ้๏ࠠาไ่๋ࡡࡴࠧ༟")
	YyiLTwVKmXFObS7kfC = v5EA6TqHX3s4jzBMk(u"ࠨ࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭༠")+YyiLTwVKmXFObS7kfC+C2dgEDAKQGsvh(u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ༡")
	if NMWlwz87p6EmSGx2Uy1i9h4VfCrnI==PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠪࡅࡘࡑࠧ༢") or h7cjS8YXyNqgQPsk4WLlG3x==k5dztomYyN3H(u"ࠫࡆ࡙ࡋࠨ༣"):
		WIHtXSMQyzumo8FLYcCfw += EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠬࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟๊่ࠥะั๋ัࠣว๋๊ࠦฮษ๋่ࠥอไษำ้ห๊าࠠฦื็หาࠦวๅ็ื็้ฯࠠ࠯࠰ࠣว๊ࠦสา์าࠤสืำศๆࠣีุอไสࠢฦ์ࠥิืฤࠢศ่๎ࠦวๅ็หี๊าࠠภࠣࠤ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ༤")
	QIEqzVMA59NtdyjD0e8PcJalx = BmcLzCFjuIrZP5fwXH18aN6YS(u"ࡊࡦࡲࡳࡦឫ")
	if showDialogs and iW6eqtHJGnzFhTSgduj7Pys2w not in ANr5yaiVH3xW8YIJbCX6c:
		if NMWlwz87p6EmSGx2Uy1i9h4VfCrnI==BmcLzCFjuIrZP5fwXH18aN6YS(u"࠭ࡁࡔࡍࠪ༥") or h7cjS8YXyNqgQPsk4WLlG3x==QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠧࡂࡕࡎࠫ༦"):
			D6LK2dzYZMco = Uu0ZdNAP1BWc28lR(l0WAe1f7Bpi5ZXk(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ༧"),WMkAjB1RgN7q(u"ࠩัีําࠧ༨"),nr5mZG89ICi6cgt4MfLJa0(u"ࠪษึูวๅࠢ็่๊ฮัๆฮࠪ༩"),gItVahxL0w(u"ࠫส฻ไศฯࠣห้๋ิไๆฬࠫ༪"),bo1dqzR8JIwlThvDcyU4jf+LgpdP3UjFRnlX(u"ࠬࠦࠠࠡࠩ༫")+nnYoO8rQaHmc57IA1MVSi(bo1dqzR8JIwlThvDcyU4jf),WIHtXSMQyzumo8FLYcCfw+jSu5Cg2Ub1OAkZVs8Yoz(u"࠭࡜࡯ࠩ༬")+YyiLTwVKmXFObS7kfC)
			if D6LK2dzYZMco==l0WAe1f7Bpi5ZXk(u"࠱ᘃ"):
				from gCUboaujSL import EEbGBNzAQydpnq
				EEbGBNzAQydpnq()
			elif D6LK2dzYZMco==gItVahxL0w(u"࠳ᘄ"): QIEqzVMA59NtdyjD0e8PcJalx = b05yftsZ6NYgIKP(u"࡙ࡸࡵࡦឬ")
		else: ZIOHgA3z0TBR(sRth5giAQzWlEVm7JOX(u"ࠧࠨ༭"),nr5mZG89ICi6cgt4MfLJa0(u"ࠨࠩ༮"),bo1dqzR8JIwlThvDcyU4jf+v5EA6TqHX3s4jzBMk(u"ࠩࠣࠤࠥ࠭༯")+nnYoO8rQaHmc57IA1MVSi(bo1dqzR8JIwlThvDcyU4jf),WIHtXSMQyzumo8FLYcCfw,YyiLTwVKmXFObS7kfC)
	bLEBi8IO7uU2x3htYDdVq95.setSetting(fY5wTlhtnOc0Er6sdy4k87b(u"ࠪࡥࡻ࠴࡬ࡢࡰࡪࡹࡦ࡭ࡥ࠯ࡶࡵࡥࡳࡹ࡬ࡢࡶࡨࠫ༰"),xvH1PfgscOb0Bw9Ljn)
	return QIEqzVMA59NtdyjD0e8PcJalx
def a69aolrYsnGEukv5Li(kpRPIdmg87bhiUVjyDc9BC=T6wRistc1SCo4hqObgumK(u"ࡌࡡ࡭ࡵࡨឭ"),gxP086fATb3zyWe=[]):
	IaGPbHKSWkimVLeNQ7fMBRs283 = [Cjda4zr3pXghVKDR,Z7A1STpeQGVJ]+gxP086fATb3zyWe
	for MVQo7cbNdaril0FG6Pp in XXRtDhYvWb35qnLBxIri7ScNUks0.listdir(IjYiO4u9HGmgw):
		if kpRPIdmg87bhiUVjyDc9BC and (MVQo7cbNdaril0FG6Pp.startswith(sRth5giAQzWlEVm7JOX(u"ࠫ࡮ࡶࡴࡷࠩ༱")) or MVQo7cbNdaril0FG6Pp.startswith(V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠬࡳ࠳ࡶࠩ༲"))): continue
		if MVQo7cbNdaril0FG6Pp.startswith(nr5mZG89ICi6cgt4MfLJa0(u"࠭ࡦࡪ࡮ࡨࡣࠬ༳")): continue
		p7uIBAEonwgl3i = XXRtDhYvWb35qnLBxIri7ScNUks0.path.join(IjYiO4u9HGmgw,MVQo7cbNdaril0FG6Pp)
		if p7uIBAEonwgl3i in IaGPbHKSWkimVLeNQ7fMBRs283: continue
		try: XXRtDhYvWb35qnLBxIri7ScNUks0.remove(p7uIBAEonwgl3i)
		except: pass
	if gcIBiFLSn0Hyb3joM15vPpwWJ not in IaGPbHKSWkimVLeNQ7fMBRs283: SSRbfdTHKi1ngDyzeGt5X(gcIBiFLSn0Hyb3joM15vPpwWJ,YB5xyI7MaRslVpv(u"ࡕࡴࡸࡩឯ"),rbjsM8cRFiuA1(u"ࡆࡢ࡮ࡶࡩឮ"))
	KBxPW9cX8dqtaUDG.sleep(NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠳ᘅ"))
	return
def EjHlNJqX2ckge1dAPtwnZbYp5i8(ZZRqrIWeBVb4,ww2vqCObJMBYRUaDyuWQ0,qmr7vLh1EW,AqLgT4S6FExHi1kZ5smy7a0hRX,ib6URTIJnFlgVwXsQAN0ZGD4k9c3ph,IXuCzdlqv9WRAkLSt,showDialogs,iW6eqtHJGnzFhTSgduj7Pys2w,T1haiwEgF2p7bnBJzVXRPUjrds=b05yftsZ6NYgIKP(u"ࡖࡵࡹࡪឰ"),sVWmClxtR10p=b05yftsZ6NYgIKP(u"ࡖࡵࡹࡪឰ")):
	qmr7vLh1EW = qmr7vLh1EW+BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠧࡽࡾࡐࡽࡕࡸ࡯ࡹࡻࡘࡶࡱࡃࠧ༴")+ZZRqrIWeBVb4
	UMNteoHlkEy3Yf = mORwgTnXBdQ7iCSHKf(IIiPCruL6dT8s1lqj47SzpVHnYNm,ww2vqCObJMBYRUaDyuWQ0,qmr7vLh1EW,AqLgT4S6FExHi1kZ5smy7a0hRX,ib6URTIJnFlgVwXsQAN0ZGD4k9c3ph,IXuCzdlqv9WRAkLSt,showDialogs,iW6eqtHJGnzFhTSgduj7Pys2w,T1haiwEgF2p7bnBJzVXRPUjrds,sVWmClxtR10p)
	if qmr7vLh1EW in UMNteoHlkEy3Yf.content: UMNteoHlkEy3Yf.succeeded = jSu5Cg2Ub1OAkZVs8Yoz(u"ࡉࡥࡱࡹࡥឱ")
	if not UMNteoHlkEy3Yf.succeeded:
		PapzBZgIekhJ5Fq8rDR2wOxTnu(gItVahxL0w(u"ࠨࡊࡗࡘࡕࠦࡒࡦࡳࡸࡩࡸࡺࠠࡇࡣ࡬ࡰࡺࡸࡥࠨ༵"))
	return UMNteoHlkEy3Yf
def rwg53p6b0yU(qmr7vLh1EW):
	UMNteoHlkEy3Yf = mORwgTnXBdQ7iCSHKf(f9Oum6c0FotxYn,EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠩࡊࡉ࡙࠭༶"),qmr7vLh1EW,FGDJwkEbTB5SoXujs3f(u"༷ࠪࠫ"),RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠫࠬ༸"),BoWHNb9daQVCF16A(u"࡙ࡸࡵࡦឳ"),b05yftsZ6NYgIKP(u"༹ࠬ࠭"),PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡇࡗࡣࡕࡘࡏ࡙ࡋࡈࡗࡤࡒࡉࡔࡖ࠰࠵ࡸࡺࠧ༺"),BoWHNb9daQVCF16A(u"࡙ࡸࡵࡦឳ"),NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࡊࡦࡲࡳࡦឲ"))
	UqG5PJM8gSki2 = []
	if UMNteoHlkEy3Yf.succeeded:
		qqThxfYXnogSpAiJ7GkcLz = UMNteoHlkEy3Yf.content
		vK3wB4l92yVdPc0beAahgNJXID = My7Dwqvs6bfGNSIgX.findall(k5dztomYyN3H(u"ࠧࠡࠪ࠱࠮ࡄ࠯ࠠ࡝ࡦࡾ࠵࠱࠹ࡽ࡮ࡵࠪ༻"),qqThxfYXnogSpAiJ7GkcLz)
		if vK3wB4l92yVdPc0beAahgNJXID: qqThxfYXnogSpAiJ7GkcLz = YB5xyI7MaRslVpv(u"ࠨ࡞ࡱࠫ༼").join(vK3wB4l92yVdPc0beAahgNJXID)
		hNiVUOX8SD62ybZ5mgC = qqThxfYXnogSpAiJ7GkcLz.replace(sRth5giAQzWlEVm7JOX(u"ࠩ࡟ࡶࠬ༽"),UnWjVbo503mEMv9KF(u"ࠪࠫ༾")).strip(BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠫࡡࡴࠧ༿")).split(EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠬࡢ࡮ࠨཀ"))
		UqG5PJM8gSki2 = []
		for ZZRqrIWeBVb4 in hNiVUOX8SD62ybZ5mgC:
			if ZZRqrIWeBVb4.count(NVS30xAdRFMIw1n9CislkE2(u"࠭࠮ࠨཁ"))==V2RbfGOBdcA6l8NTsPWzEyvS7(u"࠶ᘆ"): UqG5PJM8gSki2.append(ZZRqrIWeBVb4)
	return UqG5PJM8gSki2
def pzGctwNK4xhaCTI6X7u(*aargs):
	orkADXeBn6jcQhZ01t = NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡳ࡭࠳ࡶࡲࡰࡺࡼࡷࡨࡸࡡࡱࡧ࠱ࡧࡴࡳ࠯ࡷ࠴࠲ࡃࡷ࡫ࡱࡶࡧࡶࡸࡂࡪࡩࡴࡲ࡯ࡥࡾࡶࡲࡰࡺ࡬ࡩࡸࠬࡰࡳࡱࡻࡽࡹࡿࡰࡦ࠿࡫ࡸࡹࡶࠦࡵ࡫ࡰࡩࡴࡻࡴ࠾࠳࠳࠴࠵࠶ࠦࡴࡵ࡯ࡁࡾ࡫ࡳࠧ࡮࡬ࡱ࡮ࡺ࠽࠲࠲ࠩࡧࡴࡻ࡮ࡵࡴࡼࡁࡓࡒࠬࡃࡇ࠯ࡈࡊ࠲ࡆࡓ࠮ࡊࡆ࠱࡚ࡒࠨག")
	eOQfpiIqULTKoCR = hhlbF1Sns5TrEN8QPCYmL4(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡵࡥࡼ࠴ࡧࡪࡶ࡫ࡹࡧࡻࡳࡦࡴࡦࡳࡳࡺࡥ࡯ࡶ࠱ࡧࡴࡳ࠯ࡳࡱࡲࡷࡹ࡫ࡲ࡬࡫ࡧ࠳ࡴࡶࡥ࡯ࡲࡵࡳࡽࡿ࡬ࡪࡵࡷ࠳ࡲࡧࡩ࡯࠱ࡋࡘ࡙ࡖࡓ࠯ࡶࡻࡸࠬགྷ")
	bLYUPBq18zuG6mMN4EwaHs = rwg53p6b0yU(eOQfpiIqULTKoCR)
	UqG5PJM8gSki2 = rwg53p6b0yU(orkADXeBn6jcQhZ01t)
	qCsehIFN8nToRzLE3 = bLYUPBq18zuG6mMN4EwaHs+UqG5PJM8gSki2
	Lmj1pfQk63XdoeH(fY5wTlhtnOc0Er6sdy4k87b(u"ࠩࡑࡓ࡙ࡏࡃࡆࡡࡏࡍࡓࡋࡓࠨང"),Dwl0N6FKuVU8nB1mbisIrCzdO(baNWS6nfqTC5iX4Kl)+UnWjVbo503mEMv9KF(u"ࠪࠤࠥࠦࡇࡰࡶࠣࡴࡷࡵࡸࡪࡧࡶࠤࡱ࡯ࡳࡵࠢࠣࠤ࠶ࡹࡴࠬ࠴ࡱࡨ࠿࡛ࠦࠡࠩཅ")+str(len(bLYUPBq18zuG6mMN4EwaHs))+C2dgEDAKQGsvh(u"ࠫ࠰࠭ཆ")+str(len(UqG5PJM8gSki2))+V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠬࠦ࡝ࠨཇ"))
	ZZRqrIWeBVb4 = bLEBi8IO7uU2x3htYDdVq95.getSetting(UxS67uoGThbMwnfNRzy4gajLd23JH(u"࠭ࡡࡷ࠰ࡳࡶࡴࡾࡹ࠯࡮ࡤࡷࡹ࠭཈"))
	UMNteoHlkEy3Yf = U5uGTZvbxOmKaDspiCLcg()
	bLEBi8IO7uU2x3htYDdVq95.setSetting(b05yftsZ6NYgIKP(u"ࠧࡢࡸ࠱ࡴࡷࡵࡸࡺ࠰࡯ࡥࡸࡺࠧཉ"),C2dgEDAKQGsvh(u"ࠨࠩཊ"))
	if ZZRqrIWeBVb4 or qCsehIFN8nToRzLE3:
		HHSczv3E0A1JgipTBqYCPwR,bbeYVRCXkUzsmN39 = k5dztomYyN3H(u"࠴ᘇ"),rbjsM8cRFiuA1(u"࠶࠶ᘈ")
		B5dcejsDhN2AFqVbHZ8Q = len(qCsehIFN8nToRzLE3)
		BSK6Qmckv74Weon3RpMGr = bbeYVRCXkUzsmN39
		if B5dcejsDhN2AFqVbHZ8Q>BSK6Qmckv74Weon3RpMGr: hulmt7Cp2J01sF6niToW5OfxSB8 = BSK6Qmckv74Weon3RpMGr
		else: hulmt7Cp2J01sF6niToW5OfxSB8 = B5dcejsDhN2AFqVbHZ8Q
		R7poCGnAed65bD0qJOImUvWkajPlxz = SS503hkALwlNIvHYW7jb.sample(qCsehIFN8nToRzLE3,hulmt7Cp2J01sF6niToW5OfxSB8)
		if ZZRqrIWeBVb4: R7poCGnAed65bD0qJOImUvWkajPlxz = [ZZRqrIWeBVb4]+R7poCGnAed65bD0qJOImUvWkajPlxz
		dzCjwPArNgFSkLuH0cXo4 = AuHy92xSpftDB8R(PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࡌࡡ࡭ࡵࡨ឴"),PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࡌࡡ࡭ࡵࡨ឴"))
		TTLQDONupiB6q = KBxPW9cX8dqtaUDG.time()
		while KBxPW9cX8dqtaUDG.time()-TTLQDONupiB6q<=bbeYVRCXkUzsmN39 and not dzCjwPArNgFSkLuH0cXo4.finishedLIST:
			if HHSczv3E0A1JgipTBqYCPwR<hulmt7Cp2J01sF6niToW5OfxSB8:
				ZZRqrIWeBVb4 = R7poCGnAed65bD0qJOImUvWkajPlxz[HHSczv3E0A1JgipTBqYCPwR]
				dzCjwPArNgFSkLuH0cXo4.Tkf6RY1UXJwNhHsgK(HHSczv3E0A1JgipTBqYCPwR,EjHlNJqX2ckge1dAPtwnZbYp5i8,ZZRqrIWeBVb4,*aargs)
			KBxPW9cX8dqtaUDG.sleep(BoWHNb9daQVCF16A(u"࠶࠮࠸࠷ᘉ"))
			HHSczv3E0A1JgipTBqYCPwR += WMkAjB1RgN7q(u"࠱ᘊ")
			Lmj1pfQk63XdoeH(jSu5Cg2Ub1OAkZVs8Yoz(u"ࠩࡑࡓ࡙ࡏࡃࡆࠩཋ"),Dwl0N6FKuVU8nB1mbisIrCzdO(baNWS6nfqTC5iX4Kl)+v5EA6TqHX3s4jzBMk(u"ࠪࠤࠥࠦࡔࡳࡻ࡬ࡲ࡬ࡀࠠࠡࠢࡓࡶࡴࡾࡹ࠻ࠢ࡞ࠤࠬཌ")+ZZRqrIWeBVb4+BoWHNb9daQVCF16A(u"ࠫࠥࡣࠧཌྷ"))
		finishedLIST = dzCjwPArNgFSkLuH0cXo4.finishedLIST
		if finishedLIST:
			resultsDICT = dzCjwPArNgFSkLuH0cXo4.resultsDICT
			HwApQB6DnvVcebtmzi9MGafg = finishedLIST[WMkAjB1RgN7q(u"࠱ᘋ")]
			UMNteoHlkEy3Yf = resultsDICT[HwApQB6DnvVcebtmzi9MGafg]
			ZZRqrIWeBVb4 = R7poCGnAed65bD0qJOImUvWkajPlxz[int(HwApQB6DnvVcebtmzi9MGafg)]
			bLEBi8IO7uU2x3htYDdVq95.setSetting(EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠬࡧࡶ࠯ࡲࡵࡳࡽࡿ࠮࡭ࡣࡶࡸࠬཎ"),ZZRqrIWeBVb4)
			if HwApQB6DnvVcebtmzi9MGafg!=nr5mZG89ICi6cgt4MfLJa0(u"࠲ᘌ"): Lmj1pfQk63XdoeH(BmcLzCFjuIrZP5fwXH18aN6YS(u"࠭ࡎࡐࡖࡌࡇࡊࡥࡌࡊࡐࡈࡗࠬཏ"),Dwl0N6FKuVU8nB1mbisIrCzdO(baNWS6nfqTC5iX4Kl)+jSu5Cg2Ub1OAkZVs8Yoz(u"ࠧࠡࠢࠣࡗࡺࡩࡣࡦࡵࡶ࠾ࠥࠦࠠࡑࡴࡲࡼࡾࡀࠠ࡜ࠢࠪཐ")+ZZRqrIWeBVb4+NVS30xAdRFMIw1n9CislkE2(u"ࠨࠢࡠࠫད"))
			else: Lmj1pfQk63XdoeH(QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠩࡑࡓ࡙ࡏࡃࡆࡡࡏࡍࡓࡋࡓࠨདྷ"),Dwl0N6FKuVU8nB1mbisIrCzdO(baNWS6nfqTC5iX4Kl)+jx7s8T0BFgODXLMzIYedf(u"ࠪࠤࠥࠦࡓࡶࡥࡦࡩࡸࡹ࠺ࠡࠢࠣࡗࡦࡼࡥࡥࠢࡳࡶࡴࡾࡹ࠻ࠢ࡞ࠤࠬན")+ZZRqrIWeBVb4+UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠫࠥࡣࠧཔ"))
	return UMNteoHlkEy3Yf
def uYqVHxoztm3A5hBb7CIrgPZ(TKqMD4sua2vfi9nt5rxJ3j,WiQBzwAIa6GvLC79Jr3h0F5uosjbRy):
	PPtwhC61ajNgWXyuRIzMUiKnQv3T = TKqMD4sua2vfi9nt5rxJ3j.create_connection
	def GXfMBxbQN0zK4O5to7CaPFlkT(oVsIbEDCBY7GguwPLimxOlcySK,*aargs,**kkwargs):
		qyx6o5afd0kreACVWbuG,nmLNruPizehkcGl = oVsIbEDCBY7GguwPLimxOlcySK
		ip = t0KUXWFosQBprcveO4Ra(qyx6o5afd0kreACVWbuG,WiQBzwAIa6GvLC79Jr3h0F5uosjbRy)
		if ip: qyx6o5afd0kreACVWbuG = ip[hhlbF1Sns5TrEN8QPCYmL4(u"࠳ᘍ")]
		else:
			if WiQBzwAIa6GvLC79Jr3h0F5uosjbRy in HcyxqSkeNf8ROumTbVKCZLjdvB2: HcyxqSkeNf8ROumTbVKCZLjdvB2.remove(WiQBzwAIa6GvLC79Jr3h0F5uosjbRy)
			if HcyxqSkeNf8ROumTbVKCZLjdvB2:
				oSf7hrKJAFXZCmHd = HcyxqSkeNf8ROumTbVKCZLjdvB2[WMkAjB1RgN7q(u"࠴ᘎ")]
				ip = t0KUXWFosQBprcveO4Ra(qyx6o5afd0kreACVWbuG,oSf7hrKJAFXZCmHd)
				if ip: qyx6o5afd0kreACVWbuG = ip[fY5wTlhtnOc0Er6sdy4k87b(u"࠵ᘏ")]
		oVsIbEDCBY7GguwPLimxOlcySK = (qyx6o5afd0kreACVWbuG,nmLNruPizehkcGl)
		return PPtwhC61ajNgWXyuRIzMUiKnQv3T(oVsIbEDCBY7GguwPLimxOlcySK,*aargs,**kkwargs)
	TKqMD4sua2vfi9nt5rxJ3j.create_connection = GXfMBxbQN0zK4O5to7CaPFlkT
	return PPtwhC61ajNgWXyuRIzMUiKnQv3T
def yZqLUJdN3WK(qmr7vLh1EW):
	vV9KfCGZsWEhO4argY08LNn6iTjMF2,kozr9XFshWxlgy3i = qmr7vLh1EW.split(BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠬ࠵ࠧཕ"))[nr5mZG89ICi6cgt4MfLJa0(u"࠲ᘑ")],fY5wTlhtnOc0Er6sdy4k87b(u"࠾࠰ᘐ")
	if vvHpKfcqRnrFzjG(u"࠭࠺ࠨབ") in vV9KfCGZsWEhO4argY08LNn6iTjMF2: vV9KfCGZsWEhO4argY08LNn6iTjMF2,kozr9XFshWxlgy3i = vV9KfCGZsWEhO4argY08LNn6iTjMF2.split(NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠧ࠻ࠩབྷ"))
	D2DHtA8LGX9JnvmKW7FzCbl = vvHpKfcqRnrFzjG(u"ࠨ࠱ࠪམ")+NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠩ࠲ࠫཙ").join(qmr7vLh1EW.split(LgpdP3UjFRnlX(u"ࠪ࠳ࠬཚ"))[V2RbfGOBdcA6l8NTsPWzEyvS7(u"࠴ᘒ"):])
	h5QaxwPF7SOu6fMBTGXRU2yn = RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠫࡌࡋࡔࠡࠩཛ")+D2DHtA8LGX9JnvmKW7FzCbl+NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠬࠦࡈࡕࡖࡓ࠳࠶࠴࠱࡝ࡴ࡟ࡲࠬཛྷ")
	h5QaxwPF7SOu6fMBTGXRU2yn += b05yftsZ6NYgIKP(u"࠭ࡈࡰࡵࡷ࠾ࠥ࠭ཝ")+vV9KfCGZsWEhO4argY08LNn6iTjMF2+PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠧ࡝ࡴ࡟ࡲࠬཞ")
	h5QaxwPF7SOu6fMBTGXRU2yn += NVS30xAdRFMIw1n9CislkE2(u"ࠨ࡞ࡵࡠࡳ࠭ཟ")
	from socket import socket as sjOCEyDLImv7,AF_INET as om54gkLrHi6DqAQ0M,SOCK_STREAM as yAQdIO8psN2zSqX1KFW5BL
	try:
		XUdB7t6bFhmrV = sjOCEyDLImv7(om54gkLrHi6DqAQ0M,yAQdIO8psN2zSqX1KFW5BL)
		XUdB7t6bFhmrV.connect((vV9KfCGZsWEhO4argY08LNn6iTjMF2,kozr9XFshWxlgy3i))
		XUdB7t6bFhmrV.send(h5QaxwPF7SOu6fMBTGXRU2yn.encode(v5EA6TqHX3s4jzBMk(u"ࠩࡸࡸ࡫࠾ࠧའ")))
		llDFwqcunKWZQjMsVB7yJLv9AdogG = XUdB7t6bFhmrV.recv(FGDJwkEbTB5SoXujs3f(u"࠷࠴࠾࠼ᘔ")*UxS67uoGThbMwnfNRzy4gajLd23JH(u"࠳࠳࠶࠹ᘓ"))
		qqThxfYXnogSpAiJ7GkcLz = repr(llDFwqcunKWZQjMsVB7yJLv9AdogG)
	except: qqThxfYXnogSpAiJ7GkcLz = jSu5Cg2Ub1OAkZVs8Yoz(u"ࠪࠫཡ")
	return qqThxfYXnogSpAiJ7GkcLz
def ooq2D9xF8ZLpPBs(db276WrGJTP8KhjCaZq,EAdbsmyiqLtjhPlxG):
	if jSu5Cg2Ub1OAkZVs8Yoz(u"ࠫ࠳࠭ར") not in db276WrGJTP8KhjCaZq: return db276WrGJTP8KhjCaZq
	db276WrGJTP8KhjCaZq = db276WrGJTP8KhjCaZq+k5dztomYyN3H(u"ࠬ࠵ࠧལ")
	Cv2cKFjauVqDByfZeI3O,lORxwPiXu2F18 = db276WrGJTP8KhjCaZq.split(T6wRistc1SCo4hqObgumK(u"࠭࠮ࠨཤ"),NVS30xAdRFMIw1n9CislkE2(u"࠵ᘕ"))
	ccyEYQ8KrqxZgPXWi4BO,iz86H49GW31ukRQ0IYSZgJcFMar = lORxwPiXu2F18.split(v5EA6TqHX3s4jzBMk(u"ࠧ࠰ࠩཥ"),NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠶ᘖ"))
	TIVwNYi9bCgDf7PQS0O = Cv2cKFjauVqDByfZeI3O+b05yftsZ6NYgIKP(u"ࠨ࠰ࠪས")+ccyEYQ8KrqxZgPXWi4BO
	if EAdbsmyiqLtjhPlxG in [k5dztomYyN3H(u"ࠩ࡫ࡳࡸࡺࠧཧ"),gItVahxL0w(u"ࠪࡲࡦࡳࡥࠨཨ")] and C2jP0iLNGKnHu9xp(u"ࠫ࠴࠭ཀྵ") in TIVwNYi9bCgDf7PQS0O: TIVwNYi9bCgDf7PQS0O = TIVwNYi9bCgDf7PQS0O.rsplit(b05yftsZ6NYgIKP(u"ࠬ࠵ࠧཪ"),BmcLzCFjuIrZP5fwXH18aN6YS(u"࠷ᘗ"))[BmcLzCFjuIrZP5fwXH18aN6YS(u"࠷ᘗ")]
	if EAdbsmyiqLtjhPlxG==v5EA6TqHX3s4jzBMk(u"࠭࡮ࡢ࡯ࡨࠫཫ") and BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠧ࠯ࠩཬ") in TIVwNYi9bCgDf7PQS0O:
		HMkizCI5OsTjY8x9mGt = TIVwNYi9bCgDf7PQS0O.split(vvHpKfcqRnrFzjG(u"ࠨ࠰ࠪ཭"))
		wwCFA0VjJa = len(HMkizCI5OsTjY8x9mGt)
		if wwCFA0VjJa<=QynMHGWA0blfqTUdxRh5Jzi2t(u"࠳ᘙ") or EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠩࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴࠧ཮") in TIVwNYi9bCgDf7PQS0O: HMkizCI5OsTjY8x9mGt = HMkizCI5OsTjY8x9mGt[PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"࠰ᘘ")]
		elif wwCFA0VjJa>=v5EA6TqHX3s4jzBMk(u"࠶ᘛ"): HMkizCI5OsTjY8x9mGt = HMkizCI5OsTjY8x9mGt[sRth5giAQzWlEVm7JOX(u"࠳ᘚ")]
		if len(HMkizCI5OsTjY8x9mGt)>WMkAjB1RgN7q(u"࠵ᘜ"): TIVwNYi9bCgDf7PQS0O = HMkizCI5OsTjY8x9mGt
	return TIVwNYi9bCgDf7PQS0O
def gEYUZMaD6vB(JuCQrTA2jyEfawP6k9t8dN):
	DqzAgHZX4K3Brinxacv9e = repr(JuCQrTA2jyEfawP6k9t8dN.encode(NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠪࡹࡹ࡬࠸ࠨ཯"))).replace(BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠦࠬࠨ཰"),hhlbF1Sns5TrEN8QPCYmL4(u"ཱࠬ࠭"))
	return DqzAgHZX4K3Brinxacv9e
def oQtFm9gzcADuxa(hgMQ60jGJfpRse7H):
	meHxbWjvVIt9TNYhD83Fa250 = vvHpKfcqRnrFzjG(u"ི࠭ࠧ")
	if V8fmEML1b0PeaRZySnzh3H5J9: hgMQ60jGJfpRse7H = hgMQ60jGJfpRse7H.decode(b05yftsZ6NYgIKP(u"ࠧࡶࡶࡩ࠼ཱིࠬ"))
	from unicodedata import decomposition as huDqM5dOIfAR7rlQwz6b8Ug
	for zzi1ZcAUIXyNst2b8GdR7JFeHEhw in hgMQ60jGJfpRse7H:
		if   zzi1ZcAUIXyNst2b8GdR7JFeHEhw==WMkAjB1RgN7q(u"ࡶࠩลུࠫ"): f9JscCjSqg2yH5pGORwlYh = gItVahxL0w(u"ࠩ࡟ࡠࡺ࠶࠶࠳࠴ཱུࠪ")
		elif zzi1ZcAUIXyNst2b8GdR7JFeHEhw==nr5mZG89ICi6cgt4MfLJa0(u"ࡸࠫศ࠭ྲྀ"): f9JscCjSqg2yH5pGORwlYh = BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠫࡡࡢࡵ࠱࠸࠵࠷ࠬཷ")
		elif zzi1ZcAUIXyNst2b8GdR7JFeHEhw==EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࡺ࠭ฤࠨླྀ"): f9JscCjSqg2yH5pGORwlYh = b05yftsZ6NYgIKP(u"࠭࡜࡝ࡷ࠳࠺࠷࠺ࠧཹ")
		elif zzi1ZcAUIXyNst2b8GdR7JFeHEhw==BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࡵࠨวེࠪ"): f9JscCjSqg2yH5pGORwlYh = nr5mZG89ICi6cgt4MfLJa0(u"ࠨ࡞࡟ࡹ࠵࠼࠲࠶ཻࠩ")
		elif zzi1ZcAUIXyNst2b8GdR7JFeHEhw==nr5mZG89ICi6cgt4MfLJa0(u"ࡷࠪสོࠬ"): f9JscCjSqg2yH5pGORwlYh = b05yftsZ6NYgIKP(u"ࠪࡠࡡࡻ࠰࠷࠴࠹ཽࠫ")
		else:
			urc2pGY7SNIyXtgZzxlFOEfkwBT4 = huDqM5dOIfAR7rlQwz6b8Ug(zzi1ZcAUIXyNst2b8GdR7JFeHEhw)
			if jSu5Cg2Ub1OAkZVs8Yoz(u"ࠫࠥ࠭ཾ") in urc2pGY7SNIyXtgZzxlFOEfkwBT4: f9JscCjSqg2yH5pGORwlYh = hhlbF1Sns5TrEN8QPCYmL4(u"ࠬࡢ࡜ࡶࠩཿ")+urc2pGY7SNIyXtgZzxlFOEfkwBT4.split(nr5mZG89ICi6cgt4MfLJa0(u"࠭ࠠࠨྀ"),vvHpKfcqRnrFzjG(u"࠶ᘝ"))[vvHpKfcqRnrFzjG(u"࠶ᘝ")]
			else:
				f9JscCjSqg2yH5pGORwlYh = C2jP0iLNGKnHu9xp(u"ࠧ࠱࠲࠳࠴ཱྀࠬ")+hex(ord(zzi1ZcAUIXyNst2b8GdR7JFeHEhw)).replace(NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠨ࠲ࡻࠫྂ"),YB5xyI7MaRslVpv(u"ࠩࠪྃ"))
				f9JscCjSqg2yH5pGORwlYh = PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠪࡠࡡࡻ྄ࠧ")+f9JscCjSqg2yH5pGORwlYh[-BoWHNb9daQVCF16A(u"࠺ᘞ"):]
		meHxbWjvVIt9TNYhD83Fa250 += f9JscCjSqg2yH5pGORwlYh
	meHxbWjvVIt9TNYhD83Fa250 = meHxbWjvVIt9TNYhD83Fa250.replace(jx7s8T0BFgODXLMzIYedf(u"ࠫࡡࡢࡵ࠱࠸ࡆࡇࠬ྅"),fY5wTlhtnOc0Er6sdy4k87b(u"ࠬࡢ࡜ࡶ࠲࠹࠸࠾࠭྆"))
	if V8fmEML1b0PeaRZySnzh3H5J9: meHxbWjvVIt9TNYhD83Fa250 = meHxbWjvVIt9TNYhD83Fa250.decode(BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠭ࡵ࡯࡫ࡦࡳࡩ࡫࡟ࡦࡵࡦࡥࡵ࡫ࠧ྇")).encode(rbjsM8cRFiuA1(u"ࠧࡶࡶࡩ࠼ࠬྈ"))
	else: meHxbWjvVIt9TNYhD83Fa250 = meHxbWjvVIt9TNYhD83Fa250.encode(rbjsM8cRFiuA1(u"ࠨࡷࡷࡪ࠽࠭ྉ")).decode(LgpdP3UjFRnlX(u"ࠩࡸࡲ࡮ࡩ࡯ࡥࡧࡢࡩࡸࡩࡡࡱࡧࠪྊ"))
	return meHxbWjvVIt9TNYhD83Fa250
def ViKAIsLurq83RSENayxWb(header=l0WAe1f7Bpi5ZXk(u"่ࠪํำษࠡษ็้ๆอส๋ฯࠪྋ"),default=C2jP0iLNGKnHu9xp(u"ࠫࠬྌ"),sgd82lVUoKH0ONMXAcn4JBbYzP6xum=NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࡆࡢ࡮ࡶࡩ឵"),source=C2jP0iLNGKnHu9xp(u"ࠬ࠭ྍ")):
	QHDcUO2xtS4CmF = BkuRaZzd5YxWceCfLT(header,default,type=XUYb0K2ghSyFs.INPUT_ALPHANUM)
	QHDcUO2xtS4CmF = QHDcUO2xtS4CmF.replace(T6wRistc1SCo4hqObgumK(u"࠭ࠠࠡࠩྎ"),C2dgEDAKQGsvh(u"ࠧࠡࠩྏ")).replace(vvHpKfcqRnrFzjG(u"ࠨࠢࠣࠫྐ"),C2dgEDAKQGsvh(u"ࠩࠣࠫྑ")).replace(T6wRistc1SCo4hqObgumK(u"ࠪࠤࠥ࠭ྒ"),gItVahxL0w(u"ࠫࠥ࠭ྒྷ"))
	if not QHDcUO2xtS4CmF and not sgd82lVUoKH0ONMXAcn4JBbYzP6xum:
		Lmj1pfQk63XdoeH(rbjsM8cRFiuA1(u"ࠬࡔࡏࡕࡋࡆࡉࠬྔ"),FGDJwkEbTB5SoXujs3f(u"࠭࠮ࠡࠢࡎࡩࡾࡨ࡯ࡢࡴࡧࠤࡪࡴࡴࡳࡻࠣࡧࡦࡴࡣࡦ࡮ࡨࡨ࠿ࠦࠠࠡࠤࠪྕ")+QHDcUO2xtS4CmF+vvHpKfcqRnrFzjG(u"ࠧࠣࠩྖ"))
		ZIOHgA3z0TBR(C2jP0iLNGKnHu9xp(u"ࠨࠩྗ"),rbjsM8cRFiuA1(u"ࠩࠪ྘"),NVS30xAdRFMIw1n9CislkE2(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ྙ"),l0WAe1f7Bpi5ZXk(u"ࠫฯ๋ࠠฦๆ฽หฦࠦวๅวาาฬ๊ࠧྚ"))
		return gItVahxL0w(u"ࠬ࠭ྛ")
	if QHDcUO2xtS4CmF not in [LgpdP3UjFRnlX(u"࠭ࠧྜ"),RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠧࠡࠩྜྷ")]:
		QHDcUO2xtS4CmF = QHDcUO2xtS4CmF.strip(NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠨࠢࠪྞ"))
		QHDcUO2xtS4CmF = oQtFm9gzcADuxa(QHDcUO2xtS4CmF)
	if source!=RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠩࡖࡉࡗ࡜ࡉࡄࡇࡖࠫྟ") and a97xrkSOefH5DbjXunq(BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠪࡏࡊ࡟ࡂࡐࡃࡕࡈࠬྠ"),qbPw1d3KimF(u"ࠫࠬྡ"),[QHDcUO2xtS4CmF],PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࡇࡣ࡯ࡷࡪា")):
		Lmj1pfQk63XdoeH(C2dgEDAKQGsvh(u"ࠬࡔࡏࡕࡋࡆࡉࠬྡྷ"),NVS30xAdRFMIw1n9CislkE2(u"࠭࠮ࠡࠢࡎࡩࡾࡨ࡯ࡢࡴࡧࠤࡪࡴࡴࡳࡻࠣࡦࡱࡵࡣ࡬ࡧࡧ࠾ࠥࠦࠠࠣࠩྣ")+QHDcUO2xtS4CmF+PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠧࠣࠩྤ"))
		ZIOHgA3z0TBR(BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠨࠩྥ"),LgpdP3UjFRnlX(u"ࠩࠪྦ"),v5EA6TqHX3s4jzBMk(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ྦྷ"),l0WAe1f7Bpi5ZXk(u"ࠫฬ์สࠡๅอฬฯࠦใๅ็ฬࠤศ๎ࠠาไ่ࠤ้ํฺࠠๆสๆฮࠦศฤใ็ห๊ࠦไๅๅหหึࠦแใูࠣ࠲࠳่่ࠦาสࠤฬ๊ศา่ส้ัࠦไศࠢํื๊ำࠠษษึฮำีวๆ๊ࠢ็ีอࠠไๆ่หฯ࠭ྨ"))
		return YB5xyI7MaRslVpv(u"ࠬ࠭ྩ")
	Lmj1pfQk63XdoeH(UxS67uoGThbMwnfNRzy4gajLd23JH(u"࠭ࡎࡐࡖࡌࡇࡊ࠭ྪ"),hhlbF1Sns5TrEN8QPCYmL4(u"ࠧ࠯ࠢࠣࡏࡪࡿࡢࡰࡣࡵࡨࠥ࡫࡮ࡵࡴࡼࠤࡦࡲ࡬ࡰࡹࡨࡨ࠿ࠦࠠࠡࠤࠪྫ")+QHDcUO2xtS4CmF+BoWHNb9daQVCF16A(u"ࠨࠤࠪྫྷ"))
	return QHDcUO2xtS4CmF
def cChyAEtdaMvNXsurWwnSeBzFU2m(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,eIL9BxdTbZj={}):
	qmr7vLh1EW,xfuZ0AJ8twcNp2H6adMsDR,BBqyRvJdCfXe6ro29EcL,BATdlOca83wHmyIkMp0j29Jg = bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,{},{},hhlbF1Sns5TrEN8QPCYmL4(u"ࠩࠪྭ")
	if RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠪࢀࠬྮ") in bJEs4IVAPdyUrhwCLv9k2YoOl8nt1: qmr7vLh1EW,xfuZ0AJ8twcNp2H6adMsDR = NgD0bJaq14yBnMYoziAmLj(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,b05yftsZ6NYgIKP(u"ࠫࢁ࠭ྯ"))
	XCNQUaLgbW6PkVY = list(set(list(eIL9BxdTbZj.keys())+list(xfuZ0AJ8twcNp2H6adMsDR.keys())))
	for bS0qeWcgmnV in XCNQUaLgbW6PkVY:
		if bS0qeWcgmnV in list(xfuZ0AJ8twcNp2H6adMsDR.keys()): BBqyRvJdCfXe6ro29EcL[bS0qeWcgmnV] = xfuZ0AJ8twcNp2H6adMsDR[bS0qeWcgmnV]
		else: BBqyRvJdCfXe6ro29EcL[bS0qeWcgmnV] = eIL9BxdTbZj[bS0qeWcgmnV]
	if hhlbF1Sns5TrEN8QPCYmL4(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩྰ") not in XCNQUaLgbW6PkVY: BBqyRvJdCfXe6ro29EcL[NVS30xAdRFMIw1n9CislkE2(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪྱ")] = IeSGolOpBHM8U62m()
	if BoWHNb9daQVCF16A(u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨྲ") not in XCNQUaLgbW6PkVY: BBqyRvJdCfXe6ro29EcL[LgpdP3UjFRnlX(u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩླ")] = ooq2D9xF8ZLpPBs(qmr7vLh1EW,k5dztomYyN3H(u"ࠩࡸࡶࡱ࠭ྴ"))
	if k5dztomYyN3H(u"ࠪࡅࡨࡩࡥࡱࡶ࠰ࡐࡦࡴࡧࡶࡣࡪࡩࠬྵ") not in XCNQUaLgbW6PkVY: BBqyRvJdCfXe6ro29EcL[sRth5giAQzWlEVm7JOX(u"ࠫࡆࡩࡣࡦࡲࡷ࠱ࡑࡧ࡮ࡨࡷࡤ࡫ࡪ࠭ྶ")] = QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠬ࡫࡮࠮ࡗࡖ࠰ࡪࡴ࠻ࡲ࠿࠳࠲࠾࠭ྷ")
	for bS0qeWcgmnV in list(BBqyRvJdCfXe6ro29EcL.keys()): BATdlOca83wHmyIkMp0j29Jg += T6wRistc1SCo4hqObgumK(u"࠭ࠦࠨྸ")+bS0qeWcgmnV+PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠧ࠾ࠩྐྵ")+BBqyRvJdCfXe6ro29EcL[bS0qeWcgmnV]
	if BATdlOca83wHmyIkMp0j29Jg: BATdlOca83wHmyIkMp0j29Jg = C2dgEDAKQGsvh(u"ࠨࡾࠪྺ")+BATdlOca83wHmyIkMp0j29Jg[UnWjVbo503mEMv9KF(u"࠱ᘟ"):]
	UMNteoHlkEy3Yf = mORwgTnXBdQ7iCSHKf(c1lwnq73vkXsVjEhFpeoZtD,QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠩࡊࡉ࡙࠭ྻ"),qmr7vLh1EW,l0WAe1f7Bpi5ZXk(u"ࠪࠫྼ"),BBqyRvJdCfXe6ro29EcL,jSu5Cg2Ub1OAkZVs8Yoz(u"ࠫࠬ྽"),BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠬ࠭྾"),NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡆ࡚ࡗࡖࡆࡉࡔࡠࡏ࠶࡙࠽࠳࠱ࡴࡶࠪ྿"),jx7s8T0BFgODXLMzIYedf(u"ࡈࡤࡰࡸ࡫ិ"),jx7s8T0BFgODXLMzIYedf(u"ࡈࡤࡰࡸ࡫ិ"))
	qqThxfYXnogSpAiJ7GkcLz = UMNteoHlkEy3Yf.content
	if QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠧࡔࡖࡕࡉࡆࡓ࠭ࡊࡐࡉࠫ࿀") not in qqThxfYXnogSpAiJ7GkcLz: return [T6wRistc1SCo4hqObgumK(u"ࠨ࠯࠴ࠫ࿁")],[qmr7vLh1EW+BATdlOca83wHmyIkMp0j29Jg]
	if NVS30xAdRFMIw1n9CislkE2(u"ࠩࡗ࡝ࡕࡋ࠽ࡂࡗࡇࡍࡔ࠭࿂") in qqThxfYXnogSpAiJ7GkcLz: return [QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠪ࠱࠶࠭࿃")],[qmr7vLh1EW+BATdlOca83wHmyIkMp0j29Jg]
	if gItVahxL0w(u"࡙ࠫ࡟ࡐࡆ࠿࡙ࡍࡉࡋࡏࠨ࿄") in qqThxfYXnogSpAiJ7GkcLz: return [jx7s8T0BFgODXLMzIYedf(u"ࠬ࠳࠱ࠨ࿅")],[qmr7vLh1EW+BATdlOca83wHmyIkMp0j29Jg]
	wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i,gsWzHGqNO9UTe3,dbmKExfDiApk = [],[],[],[]
	p1GZLhkOD64IX = My7Dwqvs6bfGNSIgX.findall(vvHpKfcqRnrFzjG(u"࠭ࠣࡆ࡚ࡗ࠱࡝࠳ࡓࡕࡔࡈࡅࡒ࠳ࡉࡏࡈ࠽ࠬ࠳࠰࠿ࠪ࡝࡟ࡶࡡࡴ࡝ࠬࠪ࠱࠮ࡄ࠯࡛࡝ࡴ࡟ࡲࡢ࠱࿆ࠧ"),qqThxfYXnogSpAiJ7GkcLz+UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠧ࡝ࡰࠪ࿇"),My7Dwqvs6bfGNSIgX.DOTALL)
	if not p1GZLhkOD64IX: return [hhlbF1Sns5TrEN8QPCYmL4(u"ࠨ࠯࠴ࠫ࿈")],[qmr7vLh1EW+BATdlOca83wHmyIkMp0j29Jg]
	for KkP7tcharOiu2ydX4RvgjTw,db276WrGJTP8KhjCaZq in p1GZLhkOD64IX:
		Cq3Xgux1Ose2olScU0NtYLbhz,gg36CZRL8F,LLnUyuiC2wRM0 = {},-BoWHNb9daQVCF16A(u"࠲ᘠ"),-BoWHNb9daQVCF16A(u"࠲ᘠ")
		nScjHafTt3Xho0lyZsp = BoWHNb9daQVCF16A(u"ࠩࠪ࿉")
		XVl5g94ZuhxtRLjAMkO7 = KkP7tcharOiu2ydX4RvgjTw.split(b05yftsZ6NYgIKP(u"ࠪ࠰ࠬ࿊"))
		for FatuQ5gf41DEVHjxBMKwbnyd7ziSl in XVl5g94ZuhxtRLjAMkO7:
			if V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠫࡂ࠭࿋") in FatuQ5gf41DEVHjxBMKwbnyd7ziSl:
				bS0qeWcgmnV,NByYDKZRbSpV8UtXaEJl30z2 = FatuQ5gf41DEVHjxBMKwbnyd7ziSl.split(sRth5giAQzWlEVm7JOX(u"ࠬࡃࠧ࿌"),rbjsM8cRFiuA1(u"࠳ᘡ"))
				Cq3Xgux1Ose2olScU0NtYLbhz[bS0qeWcgmnV.lower()] = NByYDKZRbSpV8UtXaEJl30z2
		if NVS30xAdRFMIw1n9CislkE2(u"࠭ࡡࡷࡧࡵࡥ࡬࡫࠭ࡣࡣࡱࡨࡼ࡯ࡤࡵࡪࠪ࿍") in KkP7tcharOiu2ydX4RvgjTw.lower():
			gg36CZRL8F = int(Cq3Xgux1Ose2olScU0NtYLbhz[QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠧࡢࡸࡨࡶࡦ࡭ࡥ࠮ࡤࡤࡲࡩࡽࡩࡥࡶ࡫ࠫ࿎")])//NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠴࠴࠷࠺ᘢ")
			nScjHafTt3Xho0lyZsp += str(gg36CZRL8F)+l0WAe1f7Bpi5ZXk(u"ࠨ࡭ࡥࡴࡸࠦࠠࠨ࿏")
		elif UnWjVbo503mEMv9KF(u"ࠩࡥࡥࡳࡪࡷࡪࡦࡷ࡬ࠬ࿐") in KkP7tcharOiu2ydX4RvgjTw.lower():
			gg36CZRL8F = int(Cq3Xgux1Ose2olScU0NtYLbhz[EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠪࡦࡦࡴࡤࡸ࡫ࡧࡸ࡭࠭࿑")])//NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠵࠵࠸࠴ᘣ")
			nScjHafTt3Xho0lyZsp += str(gg36CZRL8F)+EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠫࡰࡨࡰࡴࠢࠣࠫ࿒")
		if l0WAe1f7Bpi5ZXk(u"ࠬࡸࡥࡴࡱ࡯ࡹࡹ࡯࡯࡯ࠩ࿓") in KkP7tcharOiu2ydX4RvgjTw.lower():
			LLnUyuiC2wRM0 = int(Cq3Xgux1Ose2olScU0NtYLbhz[NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠭ࡲࡦࡵࡲࡰࡺࡺࡩࡰࡰࠪ࿔")].split(NVS30xAdRFMIw1n9CislkE2(u"ࠧࡹࠩ࿕"))[YB5xyI7MaRslVpv(u"࠶ᘤ")])
			nScjHafTt3Xho0lyZsp += str(LLnUyuiC2wRM0)+T6wRistc1SCo4hqObgumK(u"ࠨࠢࠣࠫ࿖")
		nScjHafTt3Xho0lyZsp = nScjHafTt3Xho0lyZsp.strip(qbPw1d3KimF(u"ࠩࠣࠤࠬ࿗"))
		if not nScjHafTt3Xho0lyZsp: nScjHafTt3Xho0lyZsp = rbjsM8cRFiuA1(u"࡙ࠪࡳࡱ࡮ࡰࡹࡱࠫ࿘")
		if not db276WrGJTP8KhjCaZq.startswith(fY5wTlhtnOc0Er6sdy4k87b(u"ࠫ࡭ࡺࡴࡱࠩ࿙")):
			if db276WrGJTP8KhjCaZq.startswith(FGDJwkEbTB5SoXujs3f(u"ࠬ࠵࠯ࠨ࿚")): db276WrGJTP8KhjCaZq = qmr7vLh1EW.split(b05yftsZ6NYgIKP(u"࠭࠺ࠨ࿛"),WMkAjB1RgN7q(u"࠷ᘥ"))[b05yftsZ6NYgIKP(u"࠰ᘦ")]+YB5xyI7MaRslVpv(u"ࠧ࠻ࠩ࿜")+db276WrGJTP8KhjCaZq
			elif db276WrGJTP8KhjCaZq.startswith(QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠨ࠱ࠪ࿝")): db276WrGJTP8KhjCaZq = ooq2D9xF8ZLpPBs(qmr7vLh1EW,qbPw1d3KimF(u"ࠩࡸࡶࡱ࠭࿞"))+db276WrGJTP8KhjCaZq
			else: db276WrGJTP8KhjCaZq = qmr7vLh1EW.rsplit(BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠪ࠳ࠬ࿟"),jx7s8T0BFgODXLMzIYedf(u"࠲ᘧ"))[BmcLzCFjuIrZP5fwXH18aN6YS(u"࠲ᘨ")]+UnWjVbo503mEMv9KF(u"ࠫ࠴࠭࿠")+db276WrGJTP8KhjCaZq
		if BoWHNb9daQVCF16A(u"ࠬࡶࡲࡰࡩࡵࡩࡸࡹࡩࡷࡧ࠰ࡹࡷ࡯ࠧ࿡") in list(Cq3Xgux1Ose2olScU0NtYLbhz.keys()):
			bOBQpgMudItXo = Cq3Xgux1Ose2olScU0NtYLbhz[nr5mZG89ICi6cgt4MfLJa0(u"࠭ࡰࡳࡱࡪࡶࡪࡹࡳࡪࡸࡨ࠱ࡺࡸࡩࠨ࿢")]
			bOBQpgMudItXo = bOBQpgMudItXo.replace(BoWHNb9daQVCF16A(u"ࠧࠣࠩ࿣"),YB5xyI7MaRslVpv(u"ࠨࠩ࿤")).replace(RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠤࠪࠦ࿥"),qbPw1d3KimF(u"ࠪࠫ࿦")).split(jSu5Cg2Ub1OAkZVs8Yoz(u"ࠫࠨ࠭࿧"),V2RbfGOBdcA6l8NTsPWzEyvS7(u"࠴ᘩ"))[sRth5giAQzWlEVm7JOX(u"࠴ᘪ")]
			OzADck17lfuHqG2SYi = REGCdFbgy4Vvu2ieLqNMlxntY(bOBQpgMudItXo)
			if OzADck17lfuHqG2SYi: U2UaTcgBpsEZxKiRG1Xv8 = nScjHafTt3Xho0lyZsp+C2dgEDAKQGsvh(u"ࠬࠦࠠࠨ࿨")+OzADck17lfuHqG2SYi
			else: U2UaTcgBpsEZxKiRG1Xv8 = nScjHafTt3Xho0lyZsp
			U2UaTcgBpsEZxKiRG1Xv8 = U2UaTcgBpsEZxKiRG1Xv8+WMkAjB1RgN7q(u"࠭ࠠࠡࡒࡵࡳ࡬ࡸࡥࡴࡵ࡬ࡺࡪ࠭࿩")
			U2UaTcgBpsEZxKiRG1Xv8 = U2UaTcgBpsEZxKiRG1Xv8+b05yftsZ6NYgIKP(u"ࠧࠡࠢࠪ࿪")+ooq2D9xF8ZLpPBs(bOBQpgMudItXo,qbPw1d3KimF(u"ࠨࡰࡤࡱࡪ࠭࿫"))
			wlfZEzuRyYLvrp.append(U2UaTcgBpsEZxKiRG1Xv8)
			QQ2cE1FjUyxPonbDhaTkV6B3i.append(bOBQpgMudItXo)
			gsWzHGqNO9UTe3.append(LLnUyuiC2wRM0)
			dbmKExfDiApk.append(gg36CZRL8F)
		db276WrGJTP8KhjCaZq = db276WrGJTP8KhjCaZq.split(NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠩࠦࠫ࿬"),UnWjVbo503mEMv9KF(u"࠶ᘫ"))[NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠶ᘬ")]
		OzADck17lfuHqG2SYi = REGCdFbgy4Vvu2ieLqNMlxntY(db276WrGJTP8KhjCaZq)
		if OzADck17lfuHqG2SYi: nScjHafTt3Xho0lyZsp = nScjHafTt3Xho0lyZsp+BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠪࠤࠥ࠭࿭")+OzADck17lfuHqG2SYi
		nScjHafTt3Xho0lyZsp = nScjHafTt3Xho0lyZsp+gItVahxL0w(u"ࠫࠥࠦࠧ࿮")+ooq2D9xF8ZLpPBs(db276WrGJTP8KhjCaZq,PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠬࡴࡡ࡮ࡧࠪ࿯"))
		wlfZEzuRyYLvrp.append(nScjHafTt3Xho0lyZsp)
		QQ2cE1FjUyxPonbDhaTkV6B3i.append(db276WrGJTP8KhjCaZq)
		gsWzHGqNO9UTe3.append(LLnUyuiC2wRM0)
		dbmKExfDiApk.append(gg36CZRL8F)
	nRxp0IUZQB9cgqy6f7A5Xa = list(zip(wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i,gsWzHGqNO9UTe3,dbmKExfDiApk))
	nRxp0IUZQB9cgqy6f7A5Xa = sorted(nRxp0IUZQB9cgqy6f7A5Xa, reverse=EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࡗࡶࡺ࡫ី"), key=lambda key: key[C2dgEDAKQGsvh(u"࠳ᘭ")])
	wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i,gsWzHGqNO9UTe3,dbmKExfDiApk = list(zip(*nRxp0IUZQB9cgqy6f7A5Xa))
	wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = list(wlfZEzuRyYLvrp),list(QQ2cE1FjUyxPonbDhaTkV6B3i)
	iLIUfJZxbBAvczHmg2a = []
	for db276WrGJTP8KhjCaZq in QQ2cE1FjUyxPonbDhaTkV6B3i: iLIUfJZxbBAvczHmg2a.append(db276WrGJTP8KhjCaZq+BATdlOca83wHmyIkMp0j29Jg)
	return wlfZEzuRyYLvrp,iLIUfJZxbBAvczHmg2a
def t0KUXWFosQBprcveO4Ra(qyx6o5afd0kreACVWbuG,WiQBzwAIa6GvLC79Jr3h0F5uosjbRy=vvHpKfcqRnrFzjG(u"࠭ࠧ࿰")):
	if not WiQBzwAIa6GvLC79Jr3h0F5uosjbRy: WiQBzwAIa6GvLC79Jr3h0F5uosjbRy = HcyxqSkeNf8ROumTbVKCZLjdvB2[QynMHGWA0blfqTUdxRh5Jzi2t(u"࠱ᘮ")]
	if qyx6o5afd0kreACVWbuG.replace(NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠧ࠯ࠩ࿱"),EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠨࠩ࿲")).isdigit(): return [qyx6o5afd0kreACVWbuG]
	from struct import pack as fsBME6txarzU9CS0D,unpack_from as UUQdSm0Oi6XkDbvyzPoBAVpqjfJ
	from socket import socket as sjOCEyDLImv7,AF_INET as om54gkLrHi6DqAQ0M,SOCK_DGRAM as b3e1xXD0mBMEJwjUdsfZ6L9YhWOVrG
	try:
		lfg4uekFI9AhryQOxHZ7 = fsBME6txarzU9CS0D(jSu5Cg2Ub1OAkZVs8Yoz(u"ࠤࡁࡌࠧ࿳"), qbPw1d3KimF(u"࠳࠵࠴࠹࠿ᘯ"))
		lfg4uekFI9AhryQOxHZ7 += fsBME6txarzU9CS0D(rbjsM8cRFiuA1(u"ࠥࡂࡍࠨ࿴"), UnWjVbo503mEMv9KF(u"࠵࠹࠻ᘰ"))
		lfg4uekFI9AhryQOxHZ7 += fsBME6txarzU9CS0D(V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠦࡃࡎࠢ࿵"), UxS67uoGThbMwnfNRzy4gajLd23JH(u"࠵ᘱ"))
		lfg4uekFI9AhryQOxHZ7 += fsBME6txarzU9CS0D(vvHpKfcqRnrFzjG(u"ࠧࡄࡈࠣ࿶"), b05yftsZ6NYgIKP(u"࠵ᘲ"))
		lfg4uekFI9AhryQOxHZ7 += fsBME6txarzU9CS0D(rbjsM8cRFiuA1(u"ࠨ࠾ࡉࠤ࿷"), C2dgEDAKQGsvh(u"࠶ᘳ"))
		lfg4uekFI9AhryQOxHZ7 += fsBME6txarzU9CS0D(k5dztomYyN3H(u"ࠢ࠿ࡊࠥ࿸"), b05yftsZ6NYgIKP(u"࠰ᘴ"))
		if BLz7m2RkNrxXQwy1cGAp: bZSnre0iT7jgX = qyx6o5afd0kreACVWbuG.split(k5dztomYyN3H(u"ࠨ࠰ࠪ࿹"))
		else: bZSnre0iT7jgX = qyx6o5afd0kreACVWbuG.decode(jx7s8T0BFgODXLMzIYedf(u"ࠩࡸࡸ࡫࠾ࠧ࿺")).split(C2dgEDAKQGsvh(u"ࠪ࠲ࠬ࿻"))
		for FIZPjUufCdhRmOtXlAE3sS in bZSnre0iT7jgX:
			APdqD7UTX6xavcW = FIZPjUufCdhRmOtXlAE3sS.encode(qbPw1d3KimF(u"ࠫࡺࡺࡦ࠹ࠩ࿼"))
			lfg4uekFI9AhryQOxHZ7 += fsBME6txarzU9CS0D(BoWHNb9daQVCF16A(u"ࠧࡈࠢ࿽"), len(FIZPjUufCdhRmOtXlAE3sS))
			for OXsMYLoZGRf3jAPC in FIZPjUufCdhRmOtXlAE3sS:
				lfg4uekFI9AhryQOxHZ7 += fsBME6txarzU9CS0D(C2jP0iLNGKnHu9xp(u"ࠨࡣࠣ࿾"), OXsMYLoZGRf3jAPC.encode(YB5xyI7MaRslVpv(u"ࠧࡶࡶࡩ࠼ࠬ࿿")))
		lfg4uekFI9AhryQOxHZ7 += fsBME6txarzU9CS0D(jx7s8T0BFgODXLMzIYedf(u"ࠣࡄࠥက"), v5EA6TqHX3s4jzBMk(u"࠱ᘵ"))
		lfg4uekFI9AhryQOxHZ7 += fsBME6txarzU9CS0D(V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠤࡁࡌࠧခ"), l0WAe1f7Bpi5ZXk(u"࠳ᘶ"))
		lfg4uekFI9AhryQOxHZ7 += fsBME6txarzU9CS0D(PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠥࡂࡍࠨဂ"), BoWHNb9daQVCF16A(u"࠴ᘷ"))
		ayZ5ApzsqU4m3nYgcj = sjOCEyDLImv7(om54gkLrHi6DqAQ0M,b3e1xXD0mBMEJwjUdsfZ6L9YhWOVrG)
		ayZ5ApzsqU4m3nYgcj.sendto(bytes(lfg4uekFI9AhryQOxHZ7), (WiQBzwAIa6GvLC79Jr3h0F5uosjbRy, rbjsM8cRFiuA1(u"࠹࠸ᘸ")))
		ayZ5ApzsqU4m3nYgcj.settimeout(jSu5Cg2Ub1OAkZVs8Yoz(u"࠻ᘹ"))
		AqLgT4S6FExHi1kZ5smy7a0hRX, X8blAB1RIsFqZgK3T6mj2 = ayZ5ApzsqU4m3nYgcj.recvfrom(hhlbF1Sns5TrEN8QPCYmL4(u"࠷࠰࠳࠶ᘺ"))
		ayZ5ApzsqU4m3nYgcj.close()
		f7IXxMea2RqwyLz = UUQdSm0Oi6XkDbvyzPoBAVpqjfJ(UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠦࡃࡎࡈࡉࡊࡋࡌࠧဃ"), AqLgT4S6FExHi1kZ5smy7a0hRX, V2RbfGOBdcA6l8NTsPWzEyvS7(u"࠰ᘻ"))
		mCDaShcroBIHFspug = f7IXxMea2RqwyLz[LgpdP3UjFRnlX(u"࠴ᘼ")]
		pvdKkX8QJbYj4AuZCTUI3BH6OGS9 = len(qyx6o5afd0kreACVWbuG)+NVS30xAdRFMIw1n9CislkE2(u"࠳࠻ᘽ")
		D0nq5FW8AJKejN91PO = []
		for _9z26fxH0VUnlF4R in range(mCDaShcroBIHFspug):
			nDKCstcLeiYB1zWkIF0j = pvdKkX8QJbYj4AuZCTUI3BH6OGS9
			cLztueEBo5qrRTDpFHIfCKW = EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠴ᘾ")
			FjTB104H5D2Ed7ypCfgJcnkGuh3AiY = RqldvxFuM5GEQ2HAz93o7afBb0(u"ࡊࡦࡲࡳࡦឹ")
			while BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࡙ࡸࡵࡦឺ"):
				OXsMYLoZGRf3jAPC = UUQdSm0Oi6XkDbvyzPoBAVpqjfJ(T6wRistc1SCo4hqObgumK(u"ࠧࡄࡂࠣင"), AqLgT4S6FExHi1kZ5smy7a0hRX, nDKCstcLeiYB1zWkIF0j)[jx7s8T0BFgODXLMzIYedf(u"࠴ᘿ")]
				if OXsMYLoZGRf3jAPC == fY5wTlhtnOc0Er6sdy4k87b(u"࠵ᙀ"):
					nDKCstcLeiYB1zWkIF0j += hhlbF1Sns5TrEN8QPCYmL4(u"࠷ᙁ")
					break
				if OXsMYLoZGRf3jAPC >= C2jP0iLNGKnHu9xp(u"࠱࠺࠴ᙂ"):
					Gcj1oNqOJmLyMZKW26AbDIQf = UUQdSm0Oi6XkDbvyzPoBAVpqjfJ(jSu5Cg2Ub1OAkZVs8Yoz(u"ࠨ࠾ࡃࠤစ"), AqLgT4S6FExHi1kZ5smy7a0hRX, nDKCstcLeiYB1zWkIF0j + gItVahxL0w(u"࠲ᙃ"))[jx7s8T0BFgODXLMzIYedf(u"࠲ᙄ")]
					nDKCstcLeiYB1zWkIF0j = ((OXsMYLoZGRf3jAPC << LgpdP3UjFRnlX(u"࠼ᙆ")) + Gcj1oNqOJmLyMZKW26AbDIQf - 0xc000) - EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠴ᙅ")
					FjTB104H5D2Ed7ypCfgJcnkGuh3AiY = v5EA6TqHX3s4jzBMk(u"࡚ࡲࡶࡧុ")
				nDKCstcLeiYB1zWkIF0j += UnWjVbo503mEMv9KF(u"࠶ᙇ")
				if FjTB104H5D2Ed7ypCfgJcnkGuh3AiY == QynMHGWA0blfqTUdxRh5Jzi2t(u"ࡆࡢ࡮ࡶࡩូ"): cLztueEBo5qrRTDpFHIfCKW += UxS67uoGThbMwnfNRzy4gajLd23JH(u"࠷ᙈ")
			if FjTB104H5D2Ed7ypCfgJcnkGuh3AiY == NVS30xAdRFMIw1n9CislkE2(u"ࡕࡴࡸࡩួ"): cLztueEBo5qrRTDpFHIfCKW += fY5wTlhtnOc0Er6sdy4k87b(u"࠱ᙉ")
			pvdKkX8QJbYj4AuZCTUI3BH6OGS9 = pvdKkX8QJbYj4AuZCTUI3BH6OGS9 + cLztueEBo5qrRTDpFHIfCKW
			yn3R7YXzAxNH0cIK1T = UUQdSm0Oi6XkDbvyzPoBAVpqjfJ(V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠢ࠿ࡊࡋࡍࡍࠨဆ"), AqLgT4S6FExHi1kZ5smy7a0hRX, pvdKkX8QJbYj4AuZCTUI3BH6OGS9)
			pvdKkX8QJbYj4AuZCTUI3BH6OGS9 = pvdKkX8QJbYj4AuZCTUI3BH6OGS9 + rbjsM8cRFiuA1(u"࠲࠲ᙊ")
			jGKC8EQFs4Lx2DcmkYP5Z90eqRM = yn3R7YXzAxNH0cIK1T[v5EA6TqHX3s4jzBMk(u"࠲ᙋ")]
			oMvXf23VG4iPx = yn3R7YXzAxNH0cIK1T[C2jP0iLNGKnHu9xp(u"࠶ᙌ")]
			if jGKC8EQFs4Lx2DcmkYP5Z90eqRM == UxS67uoGThbMwnfNRzy4gajLd23JH(u"࠵ᙍ"):
				pN5Ekw7rtQc0O = UUQdSm0Oi6XkDbvyzPoBAVpqjfJ(k5dztomYyN3H(u"ࠣࡀࠥဇ")+FGDJwkEbTB5SoXujs3f(u"ࠤࡅࠦဈ")*oMvXf23VG4iPx, AqLgT4S6FExHi1kZ5smy7a0hRX, pvdKkX8QJbYj4AuZCTUI3BH6OGS9)
				ip = T6wRistc1SCo4hqObgumK(u"ࠪࠫဉ")
				for OXsMYLoZGRf3jAPC in pN5Ekw7rtQc0O: ip += str(OXsMYLoZGRf3jAPC) + C2dgEDAKQGsvh(u"ࠫ࠳࠭ည")
				ip = ip[YB5xyI7MaRslVpv(u"࠶ᙏ"):-nr5mZG89ICi6cgt4MfLJa0(u"࠶ᙎ")]
				D0nq5FW8AJKejN91PO.append(ip)
			if jGKC8EQFs4Lx2DcmkYP5Z90eqRM in [BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠳ᙒ"),b05yftsZ6NYgIKP(u"࠵ᙓ"),rbjsM8cRFiuA1(u"࠹ᙔ"),nr5mZG89ICi6cgt4MfLJa0(u"࠻ᙕ"),V2RbfGOBdcA6l8NTsPWzEyvS7(u"࠱࠶ᙐ"),jx7s8T0BFgODXLMzIYedf(u"࠳࠺ᙑ")]: pvdKkX8QJbYj4AuZCTUI3BH6OGS9 = pvdKkX8QJbYj4AuZCTUI3BH6OGS9 + oMvXf23VG4iPx
	except: D0nq5FW8AJKejN91PO = []
	if not D0nq5FW8AJKejN91PO: Lmj1pfQk63XdoeH(C2jP0iLNGKnHu9xp(u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪဋ"),Dwl0N6FKuVU8nB1mbisIrCzdO(baNWS6nfqTC5iX4Kl)+BmcLzCFjuIrZP5fwXH18aN6YS(u"࠭ࠠࠡࠢࡇࡒࡘࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࠡࡨࡤ࡭ࡱ࡫ࡤࠡࠢࠣࡌࡴࡹࡴ࠻ࠢ࡞ࠤࠬဌ")+qyx6o5afd0kreACVWbuG+BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠧࠡ࡟ࠪဍ"))
	return D0nq5FW8AJKejN91PO
def a97xrkSOefH5DbjXunq(baNWS6nfqTC5iX4Kl,qmr7vLh1EW,ME2Q6F7u8Vp1km9ws,showDialogs=gItVahxL0w(u"ࡖࡵࡹࡪើ")):
	if ME2Q6F7u8Vp1km9ws:
		BHItePiG6LnUrqRE4FywVg = [YB5xyI7MaRslVpv(u"ࠨๅหหึ࠭ဎ"),sRth5giAQzWlEVm7JOX(u"ࠩหห้เࠧဏ"),BoWHNb9daQVCF16A(u"ࠪࡥࡩࡻ࡬ࡵࠩတ"),jSu5Cg2Ub1OAkZVs8Yoz(u"ࠫࡽࡾࠧထ"),WMkAjB1RgN7q(u"ࠬࡹࡥࡹࠩဒ")]
		if baNWS6nfqTC5iX4Kl!=T6wRistc1SCo4hqObgumK(u"࠭ࡂࡐࡍࡕࡅࠬဓ"):
			BHItePiG6LnUrqRE4FywVg += [UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠧࡳ࠼ࠪန"),rbjsM8cRFiuA1(u"ࠨࡴ࠰ࠫပ"),C2jP0iLNGKnHu9xp(u"ࠩ࠰ࡱࡦ࠭ဖ")]
			BHItePiG6LnUrqRE4FywVg += [BoWHNb9daQVCF16A(u"ࠪ࠾ࡷ࠭ဗ"),nr5mZG89ICi6cgt4MfLJa0(u"ࠫ࠲ࡸࠧဘ"),C2jP0iLNGKnHu9xp(u"ࠬࡳࡡ࠮ࠩမ")]
		for xMWO2IzwVSlsyURBQmvFdX6 in ME2Q6F7u8Vp1km9ws:
			if UnWjVbo503mEMv9KF(u"࠭ࡧࡦࡶ࠱ࡴ࡭ࡶ࠿ࠨယ") in xMWO2IzwVSlsyURBQmvFdX6: continue
			if C2dgEDAKQGsvh(u"ࠧฮๆๅอࠬရ") in xMWO2IzwVSlsyURBQmvFdX6: continue
			xMWO2IzwVSlsyURBQmvFdX6 = xMWO2IzwVSlsyURBQmvFdX6.lower()
			if V8fmEML1b0PeaRZySnzh3H5J9: xMWO2IzwVSlsyURBQmvFdX6 = xMWO2IzwVSlsyURBQmvFdX6.decode(UnWjVbo503mEMv9KF(u"ࠨࡷࡷࡪ࠽࠭လ")).encode(NVS30xAdRFMIw1n9CislkE2(u"ࠩࡸࡸ࡫࠾ࠧဝ"))
			xMWO2IzwVSlsyURBQmvFdX6 = xMWO2IzwVSlsyURBQmvFdX6.replace(PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠪ࠾ࠬသ"),C2jP0iLNGKnHu9xp(u"ࠫࠬဟ"))
			WDLq8hUsBm57dIiCNHo6MTbKjt = My7Dwqvs6bfGNSIgX.findall(fY5wTlhtnOc0Er6sdy4k87b(u"ࠬ࠮࠱࡜࠷࠰࠽ࡢ࠱ࡼ࠳࡝࠳࠱࠸ࡣࠫࠪࠩဠ"),xMWO2IzwVSlsyURBQmvFdX6,My7Dwqvs6bfGNSIgX.DOTALL)
			pprzDLcn8WhdKjoTy = k5dztomYyN3H(u"ࡉࡥࡱࡹࡥឿ")
			for yFZNmOeVh6cnuP31IWaKAQdsGRJSL in WDLq8hUsBm57dIiCNHo6MTbKjt:
				if len(yFZNmOeVh6cnuP31IWaKAQdsGRJSL)==FGDJwkEbTB5SoXujs3f(u"࠸ᙖ"):
					pprzDLcn8WhdKjoTy = NVS30xAdRFMIw1n9CislkE2(u"ࡘࡷࡻࡥៀ")
					break
			if RqldvxFuM5GEQ2HAz93o7afBb0(u"࠭࡮ࡰࡶࠣࡶࡦࡺࡥࡥࠩအ") in xMWO2IzwVSlsyURBQmvFdX6: continue
			elif BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠧࡶࡰࡵࡥࡹ࡫ࡤࠨဢ") in xMWO2IzwVSlsyURBQmvFdX6: continue
			elif RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠨ฼ํี๋ࠥี็ใࠪဣ") in xMWO2IzwVSlsyURBQmvFdX6: continue
			elif jjwPCAGBnWFIl2L0(C2dgEDAKQGsvh(u"ࠩࡅࡘࡊࡾࡐࡗ࠳࠼ࡗࡗ࡜ࡎࡖࡗ࡯࡚ࡉ࡜ࡅࡗࡇ࡛ࠫဤ")): continue
			elif xMWO2IzwVSlsyURBQmvFdX6 in [jx7s8T0BFgODXLMzIYedf(u"ࠪࡶࠬဥ")] or pprzDLcn8WhdKjoTy or any(WoFrX46wzbCNp18 in xMWO2IzwVSlsyURBQmvFdX6 for WoFrX46wzbCNp18 in BHItePiG6LnUrqRE4FywVg):
				Lmj1pfQk63XdoeH(PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩဦ"),Dwl0N6FKuVU8nB1mbisIrCzdO(baNWS6nfqTC5iX4Kl)+v5EA6TqHX3s4jzBMk(u"ࠬࠦࠠࠡࡄ࡯ࡳࡨࡱࡥࡥࠢࡤࡨࡺࡲࡴࡴࠢࡹ࡭ࡩ࡫࡯࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫဧ")+qmr7vLh1EW+k5dztomYyN3H(u"࠭ࠠ࡞ࠩဨ"))
				if showDialogs: gj7BGM5t3RZpA0vNixLqzwualb16(C2jP0iLNGKnHu9xp(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪဩ"),BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠨษ็ๅ๏ี๊้ࠢ็่่ฮวาࠢไๆ฼่ࠦฤ่สࠤ๊์ูห้ࠪဪ"))
				return BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࡙ࡸࡵࡦេ")
	return rbjsM8cRFiuA1(u"ࡌࡡ࡭ࡵࡨែ")
def ZIOHgA3z0TBR(*aargs,**kkwargs):
	if aargs:
		direction = aargs[hhlbF1Sns5TrEN8QPCYmL4(u"࠰ᙗ")]
		yWb8NnAZ39RqXm2Si = aargs[V2RbfGOBdcA6l8NTsPWzEyvS7(u"࠲ᙘ")]
		if not direction: direction = FGDJwkEbTB5SoXujs3f(u"ࠩࡦࡩࡳࡺࡥࡳࠩါ")
		if not yWb8NnAZ39RqXm2Si: yWb8NnAZ39RqXm2Si = NVS30xAdRFMIw1n9CislkE2(u"ࠪหุะๅาษิࠫာ")
		TVesFAuq9Q = aargs[WMkAjB1RgN7q(u"࠴ᙙ")]
		QHDcUO2xtS4CmF = WMkAjB1RgN7q(u"ࠫࡡࡴࠧိ").join(aargs[FGDJwkEbTB5SoXujs3f(u"࠶ᙚ"):])
	else: direction,yWb8NnAZ39RqXm2Si,TVesFAuq9Q,QHDcUO2xtS4CmF = jx7s8T0BFgODXLMzIYedf(u"ࠬ࠭ီ"),YB5xyI7MaRslVpv(u"࠭ࡏࡌࠩု"),C2jP0iLNGKnHu9xp(u"ࠧࠨူ"),WMkAjB1RgN7q(u"ࠨࠩေ")
	Uu0ZdNAP1BWc28lR(direction,QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠩࠪဲ"),yWb8NnAZ39RqXm2Si,EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠪࠫဳ"),TVesFAuq9Q,QHDcUO2xtS4CmF,**kkwargs)
	return
def mmwySO1P4jnKz5(*aargs,**kkwargs):
	direction = aargs[jx7s8T0BFgODXLMzIYedf(u"࠴ᙛ")]
	aDl4PymxiOQIGhucgRn6wEWSH = aargs[FGDJwkEbTB5SoXujs3f(u"࠶ᙜ")]
	j5JMRrcb8dCsHmW = aargs[QynMHGWA0blfqTUdxRh5Jzi2t(u"࠸ᙝ")]
	if j5JMRrcb8dCsHmW or aDl4PymxiOQIGhucgRn6wEWSH: wBu8roviH7IMxjmUGh562JA = LgpdP3UjFRnlX(u"ࡔࡳࡷࡨៃ")
	else: wBu8roviH7IMxjmUGh562JA = C2jP0iLNGKnHu9xp(u"ࡇࡣ࡯ࡷࡪោ")
	TVesFAuq9Q = aargs[QynMHGWA0blfqTUdxRh5Jzi2t(u"࠳ᙞ")]
	QHDcUO2xtS4CmF = aargs[C2dgEDAKQGsvh(u"࠵ᙟ")]
	if not direction: direction = sRth5giAQzWlEVm7JOX(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫဴ")
	if not aDl4PymxiOQIGhucgRn6wEWSH: aDl4PymxiOQIGhucgRn6wEWSH = jSu5Cg2Ub1OAkZVs8Yoz(u"้ࠬไศࠢࠣࡒࡴ࠭ဵ")
	if not j5JMRrcb8dCsHmW: j5JMRrcb8dCsHmW = FGDJwkEbTB5SoXujs3f(u"࠭ๆฺ็ࠣࠤ࡞࡫ࡳࠨံ")
	if len(aargs)>=v5EA6TqHX3s4jzBMk(u"࠹ᙡ"): QHDcUO2xtS4CmF += fY5wTlhtnOc0Er6sdy4k87b(u"ࠧ࡝ࡰ့ࠪ")+aargs[RqldvxFuM5GEQ2HAz93o7afBb0(u"࠷ᙠ")]
	if len(aargs)>=hhlbF1Sns5TrEN8QPCYmL4(u"࠻ᙢ"): QHDcUO2xtS4CmF += vvHpKfcqRnrFzjG(u"ࠨ࡞ࡱࠫး")+aargs[C2dgEDAKQGsvh(u"࠻ᙣ")]
	D6LK2dzYZMco = Uu0ZdNAP1BWc28lR(direction,aDl4PymxiOQIGhucgRn6wEWSH,hhlbF1Sns5TrEN8QPCYmL4(u"္ࠩࠪ"),j5JMRrcb8dCsHmW,TVesFAuq9Q,QHDcUO2xtS4CmF,**kkwargs)
	if D6LK2dzYZMco==-qbPw1d3KimF(u"࠷ᙤ") and wBu8roviH7IMxjmUGh562JA: D6LK2dzYZMco = -qbPw1d3KimF(u"࠷ᙤ")
	elif D6LK2dzYZMco==-QynMHGWA0blfqTUdxRh5Jzi2t(u"࠱ᙥ") and not wBu8roviH7IMxjmUGh562JA: D6LK2dzYZMco = YB5xyI7MaRslVpv(u"ࡈࡤࡰࡸ࡫ៅ")
	elif D6LK2dzYZMco==v5EA6TqHX3s4jzBMk(u"࠱ᙦ"): D6LK2dzYZMco = UnWjVbo503mEMv9KF(u"ࡉࡥࡱࡹࡥំ")
	elif D6LK2dzYZMco==sRth5giAQzWlEVm7JOX(u"࠴ᙧ"): D6LK2dzYZMco = gItVahxL0w(u"ࡘࡷࡻࡥះ")
	return D6LK2dzYZMco
def CnKwdteDG5BE8MTRhUpYIJm3NLrSgq(*aargs,**kkwargs):
	return XUYb0K2ghSyFs.Dialog().select(*aargs,**kkwargs)
def gj7BGM5t3RZpA0vNixLqzwualb16(*aargs,**kkwargs):
	TVesFAuq9Q = aargs[NVS30xAdRFMIw1n9CislkE2(u"࠳ᙨ")]
	QHDcUO2xtS4CmF = aargs[k5dztomYyN3H(u"࠵ᙩ")]
	if EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠪࡸ࡮ࡳࡥࠨ်") in list(kkwargs.keys()): Rkm7B8WTKDxngYe45PG = kkwargs[UnWjVbo503mEMv9KF(u"ࠫࡹ࡯࡭ࡦࠩျ")]
	else: Rkm7B8WTKDxngYe45PG = EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠶࠶࠰࠱ᙪ")
	if len(aargs)>jSu5Cg2Ub1OAkZVs8Yoz(u"࠸ᙫ") and YB5xyI7MaRslVpv(u"ࠬࡺࡩ࡮ࡧࠪြ") not in aargs[jSu5Cg2Ub1OAkZVs8Yoz(u"࠸ᙫ")]: profile = aargs[jSu5Cg2Ub1OAkZVs8Yoz(u"࠸ᙫ")]
	else: profile = T6wRistc1SCo4hqObgumK(u"࠭࡮ࡰࡶ࡬ࡪ࡮ࡩࡡࡵ࡫ࡲࡲࠬွ")
	gBmxIfHWOh = WCMztebpRjHu8LnvXUJq6IOi2(sRth5giAQzWlEVm7JOX(u"ࠧࡅ࡫ࡤࡰࡴ࡭ࡎࡰࡶ࡬ࡪ࡮ࡩࡡࡵ࡫ࡲࡲࡎࡳࡡࡨࡧ࠱ࡼࡲࡲࠧှ"),QgRBJhSGd4uX7i,vvHpKfcqRnrFzjG(u"ࠨࡆࡨࡪࡦࡻ࡬ࡵࠩဿ"),BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠩ࠺࠶࠵ࡶࠧ၀"))
	image_filename = g8hAJGdbNesPyYErW0BfKa.replace(v5EA6TqHX3s4jzBMk(u"ࠪࡣ࠵࠶࠰࠱ࡡࠪ၁"),qbPw1d3KimF(u"ࠫࡤ࠭၂")+str(KBxPW9cX8dqtaUDG.time())+T6wRistc1SCo4hqObgumK(u"ࠬࡥࠧ၃"))
	image_filename = image_filename.replace(EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠭࡜࡝ࠩ၄"),sRth5giAQzWlEVm7JOX(u"ࠧ࡝࡞࡟ࡠࠬ၅")).replace(vvHpKfcqRnrFzjG(u"ࠨ࠱࠲ࠫ၆"),V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠩ࠲࠳࠴࠵ࠧ၇"))
	image_height = OWF8qHVQx7Ci(UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠪࠫ၈"),YB5xyI7MaRslVpv(u"ࠫࠬ၉"),NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠬ࠭၊"),TVesFAuq9Q,QHDcUO2xtS4CmF,profile,k5dztomYyN3H(u"࠭࡬ࡦࡨࡷࠫ။"),C2dgEDAKQGsvh(u"ࡋࡧ࡬ࡴࡧៈ"),image_filename)
	gBmxIfHWOh.show()
	if profile==RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠧ࡯ࡱࡷ࡭࡫࡯ࡣࡢࡶ࡬ࡳࡳࡥࡴࡸࡱ࡫ࡥࡱ࡬ࡳࠨ၌"):
		gBmxIfHWOh.getControl(sRth5giAQzWlEVm7JOX(u"࠺࠲࠷࠴᙭")).setHeight(WMkAjB1RgN7q(u"࠲࠲࠷ᙬ"))
		gBmxIfHWOh.getControl(jx7s8T0BFgODXLMzIYedf(u"࠽࠵࠺࠰ᙰ")).setPosition(V2RbfGOBdcA6l8NTsPWzEyvS7(u"࠷࠸᙮"),-NVS30xAdRFMIw1n9CislkE2(u"࠻࠴ᙯ"))
		gBmxIfHWOh.getControl(v5EA6TqHX3s4jzBMk(u"࠾࠶࠵࠱ᙱ")).setPosition(v5EA6TqHX3s4jzBMk(u"࠷࠲࠱ᙲ"),-v5EA6TqHX3s4jzBMk(u"࠶࠱ᙳ"))
		gBmxIfHWOh.getControl(sRth5giAQzWlEVm7JOX(u"࠷࠴࠵ᙶ")).setPosition(LgpdP3UjFRnlX(u"࠺࠲ᙴ"),-qbPw1d3KimF(u"࠵࠸ᙵ"))
	gBmxIfHWOh.getControl(vvHpKfcqRnrFzjG(u"࠸࠵࠷ᙷ")).setVisible(FGDJwkEbTB5SoXujs3f(u"ࡌࡡ࡭ࡵࡨ៉"))
	gBmxIfHWOh.getControl(k5dztomYyN3H(u"࠹࠶࠲ᙸ")).setVisible(C2dgEDAKQGsvh(u"ࡆࡢ࡮ࡶࡩ៊"))
	gBmxIfHWOh.getControl(vvHpKfcqRnrFzjG(u"࠿࠰࠶࠲ᙹ")).setImage(image_filename)
	gBmxIfHWOh.getControl(PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"࠹࠱࠷࠳ᙺ")).setHeight(image_height)
	vvyxX6HiqILSp = iDocG6BXv7fT2z8UVOxgP.Thread(target=mgkYxGeSp9vIHWaXdFqUKD084c,args=(gBmxIfHWOh,image_filename,Rkm7B8WTKDxngYe45PG))
	vvyxX6HiqILSp.start()
	return
def mgkYxGeSp9vIHWaXdFqUKD084c(gBmxIfHWOh,image_filename,Rkm7B8WTKDxngYe45PG):
	KBxPW9cX8dqtaUDG.sleep(Rkm7B8WTKDxngYe45PG//UnWjVbo503mEMv9KF(u"࠲࠲࠳࠴࠳࠶ᙻ"))
	KBxPW9cX8dqtaUDG.sleep(QynMHGWA0blfqTUdxRh5Jzi2t(u"࠲࠱࠵࠵࠶ᙼ"))
	if XXRtDhYvWb35qnLBxIri7ScNUks0.path.exists(image_filename):
		try: XXRtDhYvWb35qnLBxIri7ScNUks0.remove(image_filename)
		except: pass
	return
def S3KjEaY4lGZDnRFugP0(*aargs,**kkwargs):
	TVesFAuq9Q,QHDcUO2xtS4CmF,profile,direction = NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠨࠩ၍"),C2dgEDAKQGsvh(u"ࠩࠪ၎"),jSu5Cg2Ub1OAkZVs8Yoz(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹࡥ࡬ࡰࡰࡪࠫ၏"),PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠫࡱ࡫ࡦࡵࠩၐ")
	if len(aargs)>=C2jP0iLNGKnHu9xp(u"࠴ᙽ"): TVesFAuq9Q = aargs[EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠴ᙾ")]
	if len(aargs)>=YB5xyI7MaRslVpv(u"࠸ "): QHDcUO2xtS4CmF = aargs[BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠶ᙿ")]
	if len(aargs)>=rbjsM8cRFiuA1(u"࠳ᚁ"): profile = aargs[fY5wTlhtnOc0Er6sdy4k87b(u"࠳ᚂ")]
	if len(aargs)>=sRth5giAQzWlEVm7JOX(u"࠷ᚄ"): direction = aargs[fY5wTlhtnOc0Er6sdy4k87b(u"࠵ᚃ")]
	return bFnD6Nh75IQcKrTke3gux4PvwRGUfS(direction,TVesFAuq9Q,QHDcUO2xtS4CmF,profile)
def QdvjYklOtMC4PBGRFq26giphZL1Kr(*aargs,**kkwargs):
	return XUYb0K2ghSyFs.Dialog().contextmenu(*aargs,**kkwargs)
def O2Q9vWtcByH0jDNnrxbUdkLm(*aargs,**kkwargs):
	return XUYb0K2ghSyFs.Dialog().browseSingle(*aargs,**kkwargs)
def BkuRaZzd5YxWceCfLT(*aargs,**kkwargs):
	return XUYb0K2ghSyFs.Dialog().input(*aargs,**kkwargs)
def YYAhEtvLi5CnyHxIjJled3wWTO(*aargs,**kkwargs):
	return XUYb0K2ghSyFs.DialogProgress(*aargs,**kkwargs)
def NZrI2wknju57PlJaDoRziLVm1(mtcNCsHRAe0oFTIDuYb6PqK):
	if YSomBdvcNUMF3b8JDiCfrVW>NVS30xAdRFMIw1n9CislkE2(u"࠵࠼࠴࠹࠺ᚅ"): gBmxIfHWOh = BoWHNb9daQVCF16A(u"ࠬࡨࡵࡴࡻࡧ࡭ࡦࡲ࡯ࡨࡰࡲࡧࡦࡴࡣࡦ࡮ࠪၑ")
	else: gBmxIfHWOh = EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠭ࡢࡶࡵࡼࡨ࡮ࡧ࡬ࡰࡩࠪၒ")
	mtcNCsHRAe0oFTIDuYb6PqK = mtcNCsHRAe0oFTIDuYb6PqK.lower()
	if mtcNCsHRAe0oFTIDuYb6PqK==UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠧࡴࡶࡤࡶࡹ࠭ၓ"): tUXmK5PeEH9SDq.executebuiltin(qbPw1d3KimF(u"ࠨࡃࡦࡸ࡮ࡼࡡࡵࡧ࡚࡭ࡳࡪ࡯ࡸࠪࠪၔ")+gBmxIfHWOh+PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠩࠬࠫၕ"))
	elif mtcNCsHRAe0oFTIDuYb6PqK==V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠪࡷࡹࡵࡰࠨၖ"): tUXmK5PeEH9SDq.executebuiltin(hhlbF1Sns5TrEN8QPCYmL4(u"ࠫࡉ࡯ࡡ࡭ࡱࡪ࠲ࡈࡲ࡯ࡴࡧࠫࠫၗ")+gBmxIfHWOh+RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠬ࠯ࠧၘ"))
	return
def Uu0ZdNAP1BWc28lR(direction,button0=l0WAe1f7Bpi5ZXk(u"࠭ࠧၙ"),button1=b05yftsZ6NYgIKP(u"ࠧࠨၚ"),button2=C2jP0iLNGKnHu9xp(u"ࠨࠩၛ"),TVesFAuq9Q=gItVahxL0w(u"ࠩࠪၜ"),QHDcUO2xtS4CmF=EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠪࠫၝ"),profile=EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠫࡨࡵ࡮ࡧ࡫ࡵࡱࡤࡨࡩࡨࡨࡲࡲࡹ࠭ၞ"),uK1rWvBHlNILsfd06hVZgFXAo7k=gItVahxL0w(u"࠵ᚆ"),xv3uMXZoJL9ES1me6Rjp=gItVahxL0w(u"࠵ᚆ")):
	if not direction: direction = RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬၟ")
	gBmxIfHWOh = FpTnboD75R8hgcuqCJ4NjQ(QynMHGWA0blfqTUdxRh5Jzi2t(u"࠭ࡄࡪࡣ࡯ࡳ࡬ࡉ࡯࡯ࡨ࡬ࡶࡲ࡚ࡨࡳࡧࡨࡆࡺࡺࡴࡰࡰࡶ࠲ࡽࡳ࡬ࠨၠ"),QgRBJhSGd4uX7i,RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠧࡅࡧࡩࡥࡺࡲࡴࠨၡ"),PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠨ࠹࠵࠴ࡵ࠭ၢ"))
	gBmxIfHWOh.pjPrKJvlHgTGF0fwhVX3es(button0,button1,button2,TVesFAuq9Q,QHDcUO2xtS4CmF,profile,direction,uK1rWvBHlNILsfd06hVZgFXAo7k,xv3uMXZoJL9ES1me6Rjp)
	if uK1rWvBHlNILsfd06hVZgFXAo7k>k5dztomYyN3H(u"࠶ᚇ"): gBmxIfHWOh.yW3zaDkOu79SU8ZVlEhM5omFTpwNA()
	if xv3uMXZoJL9ES1me6Rjp>EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠰ᚈ"): gBmxIfHWOh.sWAaHXdOP8()
	if uK1rWvBHlNILsfd06hVZgFXAo7k==vvHpKfcqRnrFzjG(u"࠱ᚉ") and xv3uMXZoJL9ES1me6Rjp==vvHpKfcqRnrFzjG(u"࠱ᚉ"): gBmxIfHWOh.mMTbJKVkdHEPu70R1wfxo4yDqhg()
	gBmxIfHWOh.doModal()
	D6LK2dzYZMco = gBmxIfHWOh.choiceID
	return D6LK2dzYZMco
def bFnD6Nh75IQcKrTke3gux4PvwRGUfS(direction,TVesFAuq9Q,QHDcUO2xtS4CmF,profile=gItVahxL0w(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࡤࡲ࡯࡯ࡩࠪၣ")):
	if not direction: direction = RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠪࡰࡪ࡬ࡴࠨၤ")
	gBmxIfHWOh = WCMztebpRjHu8LnvXUJq6IOi2(qbPw1d3KimF(u"ࠫࡉ࡯ࡡ࡭ࡱࡪࡘࡪࡾࡴࡗ࡫ࡨࡻࡪࡸࡆࡶ࡮࡯ࡗࡨࡸࡥࡦࡰ࠱ࡼࡲࡲࠧၥ"),QgRBJhSGd4uX7i,PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠬࡊࡥࡧࡣࡸࡰࡹ࠭ၦ"),T6wRistc1SCo4hqObgumK(u"࠭࠷࠳࠲ࡳࠫၧ"))
	image_filename = g8hAJGdbNesPyYErW0BfKa.replace(b05yftsZ6NYgIKP(u"ࠧࡠ࠲࠳࠴࠵ࡥࠧၨ"),QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠨࡡࠪၩ")+str(KBxPW9cX8dqtaUDG.time())+C2dgEDAKQGsvh(u"ࠩࡢࠫၪ"))
	image_filename = image_filename.replace(qbPw1d3KimF(u"ࠪࡠࡡ࠭ၫ"),k5dztomYyN3H(u"ࠫࡡࡢ࡜࡝ࠩၬ")).replace(YB5xyI7MaRslVpv(u"ࠬ࠵࠯ࠨၭ"),b05yftsZ6NYgIKP(u"࠭࠯࠰࠱࠲ࠫၮ"))
	image_height = OWF8qHVQx7Ci(C2jP0iLNGKnHu9xp(u"ࠧࠨၯ"),FGDJwkEbTB5SoXujs3f(u"ࠨࠩၰ"),C2jP0iLNGKnHu9xp(u"ࠩࠪၱ"),TVesFAuq9Q,QHDcUO2xtS4CmF,profile,direction,V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࡇࡣ࡯ࡷࡪ់"),image_filename)
	gBmxIfHWOh.show()
	gBmxIfHWOh.getControl(l0WAe1f7Bpi5ZXk(u"࠻࠳࠹࠵ᚊ")).setHeight(image_height)
	gBmxIfHWOh.getControl(vvHpKfcqRnrFzjG(u"࠼࠴࠺࠶ᚋ")).setImage(image_filename)
	hkWxfe4FqyKaiR = gBmxIfHWOh.doModal()
	try: XXRtDhYvWb35qnLBxIri7ScNUks0.remove(image_filename)
	except: pass
	return hkWxfe4FqyKaiR
def IeSGolOpBHM8U62m(W4f3aKFgwYmEHsi2Btrdo=gItVahxL0w(u"ࡖࡵࡹࡪ៌")):
	if W4f3aKFgwYmEHsi2Btrdo:
		rHqkc3e0CJ5VByi6vLs = zPgNsqpJInt(RnqtMUa9Nh6peGEsBT,l0WAe1f7Bpi5ZXk(u"ࠪࡷࡹࡸࠧၲ"),l0WAe1f7Bpi5ZXk(u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧၳ"),T6wRistc1SCo4hqObgumK(u"࡛ࠬࡓࡆࡔࡄࡋࡊࡔࡔࠨၴ"))
		if rHqkc3e0CJ5VByi6vLs: return rHqkc3e0CJ5VByi6vLs
	QHDcUO2xtS4CmF = jSu5Cg2Ub1OAkZVs8Yoz(u"࠭ࠧၵ")
	if C2dgEDAKQGsvh(u"࠴ᚌ") and UMNteoHlkEy3Yf.succeeded:
		qqThxfYXnogSpAiJ7GkcLz = UMNteoHlkEy3Yf.content
		ssuJokZgUN2SDTVMHQeyb3Idm0F = qqThxfYXnogSpAiJ7GkcLz.count(BoWHNb9daQVCF16A(u"ࠧࡎࡱࡽ࡭ࡱࡲࡡࠨၶ"))
		if ssuJokZgUN2SDTVMHQeyb3Idm0F>FGDJwkEbTB5SoXujs3f(u"࠽࠶ᚍ"):
			QHDcUO2xtS4CmF = My7Dwqvs6bfGNSIgX.findall(UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠨࡩࡨࡸ࠲ࡺࡨࡦ࠯࡯࡭ࡸࡺ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪၷ"),qqThxfYXnogSpAiJ7GkcLz,My7Dwqvs6bfGNSIgX.DOTALL)
			QHDcUO2xtS4CmF = QHDcUO2xtS4CmF[UxS67uoGThbMwnfNRzy4gajLd23JH(u"࠶ᚎ")]
	if not QHDcUO2xtS4CmF:
		wtQ9f3WJxGLsvkHRVp = XXRtDhYvWb35qnLBxIri7ScNUks0.path.join(QgRBJhSGd4uX7i,WMkAjB1RgN7q(u"ࠩࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨၸ"),nr5mZG89ICi6cgt4MfLJa0(u"ࠪࡹࡸ࡫ࡲࡢࡩࡨࡲࡹࡹ࠮ࡵࡺࡷࠫၹ"))
		QHDcUO2xtS4CmF = open(wtQ9f3WJxGLsvkHRVp,b05yftsZ6NYgIKP(u"ࠫࡷࡨࠧၺ")).read()
		if BLz7m2RkNrxXQwy1cGAp: QHDcUO2xtS4CmF = QHDcUO2xtS4CmF.decode(WMkAjB1RgN7q(u"ࠬࡻࡴࡧ࠺ࠪၻ"))
		QHDcUO2xtS4CmF = QHDcUO2xtS4CmF.replace(fY5wTlhtnOc0Er6sdy4k87b(u"࠭࡜ࡳࠩၼ"),WMkAjB1RgN7q(u"ࠧࠨၽ"))
	bve8xiEt3DMnzjYT9XBGQ = My7Dwqvs6bfGNSIgX.findall(BoWHNb9daQVCF16A(u"ࠨࠪࡐࡳࡿ࡯࡬࡭ࡣ࠱࠮ࡄ࠯࡜࡯ࠩၾ"),QHDcUO2xtS4CmF,My7Dwqvs6bfGNSIgX.DOTALL)
	WWOG2H6VMwQ1p = []
	for KkP7tcharOiu2ydX4RvgjTw in bve8xiEt3DMnzjYT9XBGQ:
		npBMvuPfNmR7x4d6 = KkP7tcharOiu2ydX4RvgjTw.lower()
		if FGDJwkEbTB5SoXujs3f(u"ࠩࡤࡲࡩࡸ࡯ࡪࡦࠪၿ") in npBMvuPfNmR7x4d6: continue
		if T6wRistc1SCo4hqObgumK(u"ࠪࡹࡧࡻ࡮ࡵࡷࠪႀ") in npBMvuPfNmR7x4d6: continue
		if k5dztomYyN3H(u"ࠫ࡮ࡶࡨࡰࡰࡨࠫႁ") in npBMvuPfNmR7x4d6: continue
		if C2dgEDAKQGsvh(u"ࠬࡩࡲࡰࡵࠪႂ") in npBMvuPfNmR7x4d6: continue
		WWOG2H6VMwQ1p.append(KkP7tcharOiu2ydX4RvgjTw)
	rHqkc3e0CJ5VByi6vLs = SS503hkALwlNIvHYW7jb.sample(WWOG2H6VMwQ1p,k5dztomYyN3H(u"࠱ᚏ"))
	rHqkc3e0CJ5VByi6vLs = rHqkc3e0CJ5VByi6vLs[QynMHGWA0blfqTUdxRh5Jzi2t(u"࠱ᚐ")]
	VZ8BTik93OqXLCh0fD7d2KUPpn4mH6(RnqtMUa9Nh6peGEsBT,jx7s8T0BFgODXLMzIYedf(u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩႃ"),C2dgEDAKQGsvh(u"ࠧࡖࡕࡈࡖࡆࡍࡅࡏࡖࠪႄ"),rHqkc3e0CJ5VByi6vLs,UuEtImzir9)
	return rHqkc3e0CJ5VByi6vLs
def IhzTf3wxBDQcmHRgrjN7qEi8kn(WFMmPzdINGnfvRC1BoeOpb5=k5dztomYyN3H(u"ࠨࠩႅ")):
	if not WFMmPzdINGnfvRC1BoeOpb5: WFMmPzdINGnfvRC1BoeOpb5 = N3JR6Bk5lVxnfGdgvQb.format_exc()
	if WFMmPzdINGnfvRC1BoeOpb5!=jx7s8T0BFgODXLMzIYedf(u"ࠩࡑࡳࡳ࡫ࡔࡺࡲࡨ࠾ࠥࡔ࡯࡯ࡧ࡟ࡲࠬႆ") and fY5wTlhtnOc0Er6sdy4k87b(u"ࠪࡗࡾࡹࡴࡦ࡯ࡈࡼ࡮ࡺࠧႇ") not in WFMmPzdINGnfvRC1BoeOpb5: ehpURIi6QBDOGu8qj5EYzXrsWHJ7.stderr.write(WFMmPzdINGnfvRC1BoeOpb5)
	p1GZLhkOD64IX = WFMmPzdINGnfvRC1BoeOpb5.splitlines()
	tnOo1QlfFN98JVG6vreRLxb0 = p1GZLhkOD64IX[-T6wRistc1SCo4hqObgumK(u"࠳ᚑ")]
	KxS5CnGZlAwDrpv = open(la7vIpTkr6w1ZW8XUNuCLKAMzi,qbPw1d3KimF(u"ࠫࡷࡨࠧႈ")).read()
	if BLz7m2RkNrxXQwy1cGAp: KxS5CnGZlAwDrpv = KxS5CnGZlAwDrpv.decode(jSu5Cg2Ub1OAkZVs8Yoz(u"ࠬࡻࡴࡧ࠺ࠪႉ"))
	KxS5CnGZlAwDrpv = KxS5CnGZlAwDrpv[-BmcLzCFjuIrZP5fwXH18aN6YS(u"࠻࠴࠵࠶ᚒ"):]
	t0p7jNyWB8rLfEn9oJe1m3TvZ = V2RbfGOBdcA6l8NTsPWzEyvS7(u"࠭࠽ࠨႊ")*LgpdP3UjFRnlX(u"࠵࠵࠶ᚓ")
	if t0p7jNyWB8rLfEn9oJe1m3TvZ in KxS5CnGZlAwDrpv: KxS5CnGZlAwDrpv = KxS5CnGZlAwDrpv.rsplit(t0p7jNyWB8rLfEn9oJe1m3TvZ,vvHpKfcqRnrFzjG(u"࠶ᚔ"))[vvHpKfcqRnrFzjG(u"࠶ᚔ")]
	if tnOo1QlfFN98JVG6vreRLxb0 in KxS5CnGZlAwDrpv: KxS5CnGZlAwDrpv = KxS5CnGZlAwDrpv.rsplit(tnOo1QlfFN98JVG6vreRLxb0,jSu5Cg2Ub1OAkZVs8Yoz(u"࠷ᚕ"))[C2dgEDAKQGsvh(u"࠰ᚖ")]
	PbqcvoD89L6AX = My7Dwqvs6bfGNSIgX.findall(vvHpKfcqRnrFzjG(u"ࠧࠩࡕࡲࡹࡷࡩࡥࡽࡏࡲࡨࡪ࠯࠺ࠡ࡞࡞ࠤ࠭࠴ࠪࡀࠫࠣࡠࡢ࠭ႋ"),KxS5CnGZlAwDrpv,My7Dwqvs6bfGNSIgX.DOTALL)
	for jhyutP0Iwnv4,iW6eqtHJGnzFhTSgduj7Pys2w in reversed(PbqcvoD89L6AX):
		if iW6eqtHJGnzFhTSgduj7Pys2w: break
	else: iW6eqtHJGnzFhTSgduj7Pys2w = vvHpKfcqRnrFzjG(u"ࠨࡐࡒࡘ࡙ࠥࡐࡆࡅࡌࡊࡎࡋࡄࠨႌ")
	ATaJM8UXj5kvWeLnP01,KkP7tcharOiu2ydX4RvgjTw,jCXJ2qtIM6sx0TW9HNovk = v5EA6TqHX3s4jzBMk(u"ႍࠩࠪ"),UnWjVbo503mEMv9KF(u"ࠪࠫႎ"),FGDJwkEbTB5SoXujs3f(u"ࠫࠬႏ")
	c93ivmW7UNo8aSzuQ1bFCkM = NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠬࡡࡒࡕࡎࡠ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢอไฯูฦ࠾࡛ࠥࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ႐")+tnOo1QlfFN98JVG6vreRLxb0
	mxM8XR1eQOyYcSkuH = v5EA6TqHX3s4jzBMk(u"࡛࠭ࡓࡖࡏࡡࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣวๅ็ุำึࡀࠠࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ႑")+iW6eqtHJGnzFhTSgduj7Pys2w
	for k1ULW4zFiaEq8OGNmYT5H3fXCyP2rA in reversed(p1GZLhkOD64IX):
		if NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠧࡇ࡫࡯ࡩࠥࠨࠧ႒") in k1ULW4zFiaEq8OGNmYT5H3fXCyP2rA and vvHpKfcqRnrFzjG(u"ࠨࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧ႓") in k1ULW4zFiaEq8OGNmYT5H3fXCyP2rA: break
	k1ULW4zFiaEq8OGNmYT5H3fXCyP2rA = My7Dwqvs6bfGNSIgX.findall(l0WAe1f7Bpi5ZXk(u"ࠩࡉ࡭ࡱ࡫ࠠࠣࠪ࠱࠮ࡄ࠯ࠢ࡝࠮ࠣࡰ࡮ࡴࡥࠡࠪ࠱࠮ࡄ࠯࡜࠭ࠢ࡬ࡲࠥ࠮࠮ࠫࡁࠬࠨࠬ႔"),k1ULW4zFiaEq8OGNmYT5H3fXCyP2rA,My7Dwqvs6bfGNSIgX.DOTALL)
	if k1ULW4zFiaEq8OGNmYT5H3fXCyP2rA:
		ATaJM8UXj5kvWeLnP01,KkP7tcharOiu2ydX4RvgjTw,jCXJ2qtIM6sx0TW9HNovk = k1ULW4zFiaEq8OGNmYT5H3fXCyP2rA[BoWHNb9daQVCF16A(u"࠱ᚗ")]
		if PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠪ࠳ࠬ႕") in ATaJM8UXj5kvWeLnP01: ATaJM8UXj5kvWeLnP01 = ATaJM8UXj5kvWeLnP01.rsplit(vvHpKfcqRnrFzjG(u"ࠫ࠴࠭႖"),v5EA6TqHX3s4jzBMk(u"࠳ᚘ"))[v5EA6TqHX3s4jzBMk(u"࠳ᚘ")]
		else: ATaJM8UXj5kvWeLnP01 = ATaJM8UXj5kvWeLnP01.rsplit(NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠬࡢ࡜ࠨ႗"),b05yftsZ6NYgIKP(u"࠴ᚙ"))[b05yftsZ6NYgIKP(u"࠴ᚙ")]
		ixdXh8DteLKRZn315uI = YB5xyI7MaRslVpv(u"࡛࠭ࡓࡖࡏࡡࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣวๅ็็ๅ࠿ࠦࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ႘")+ATaJM8UXj5kvWeLnP01
		boHr12d9V4GJ8CjRQyhDNks = T6wRistc1SCo4hqObgumK(u"ࠧ࡜ࡔࡗࡐࡢࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ศๆึ฻ึࡀࠠࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ႙")+KkP7tcharOiu2ydX4RvgjTw
		xI3Ohpz4vMS7cdWRBQLCuKi = BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠨ࡝ࡕࡘࡑࡣ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ษ็้่อๆ࠻ࠢࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬႚ")+jCXJ2qtIM6sx0TW9HNovk
		UKECneomT7Jg4qGxQhaWjA = ixdXh8DteLKRZn315uI+rbjsM8cRFiuA1(u"ࠩ࡟ࡲࠬႛ")+boHr12d9V4GJ8CjRQyhDNks+YB5xyI7MaRslVpv(u"ࠪࡠࡳ࠭ႜ")+xI3Ohpz4vMS7cdWRBQLCuKi+fY5wTlhtnOc0Er6sdy4k87b(u"ࠫࡡࡴࠧႝ")+mxM8XR1eQOyYcSkuH+vvHpKfcqRnrFzjG(u"ࠬࡢ࡮ࠨ႞")+c93ivmW7UNo8aSzuQ1bFCkM
		On4vqcF8hAHx = boHr12d9V4GJ8CjRQyhDNks+V2RbfGOBdcA6l8NTsPWzEyvS7(u"࠭࡜࡯ࠩ႟")+mxM8XR1eQOyYcSkuH+BoWHNb9daQVCF16A(u"ࠧ࡝ࡰࠪႠ")+c93ivmW7UNo8aSzuQ1bFCkM+hhlbF1Sns5TrEN8QPCYmL4(u"ࠨ࡞ࡱࠫႡ")+ixdXh8DteLKRZn315uI+NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠩ࡟ࡲࠬႢ")+xI3Ohpz4vMS7cdWRBQLCuKi
		EVDTUHaQZB54mYO6r9Fzkj1XquSLwP = boHr12d9V4GJ8CjRQyhDNks+NVS30xAdRFMIw1n9CislkE2(u"ࠪࡠࡳ࠭Ⴃ")+c93ivmW7UNo8aSzuQ1bFCkM+V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠫࡡࡴࠧႤ")+ixdXh8DteLKRZn315uI+C2jP0iLNGKnHu9xp(u"ࠬࡢ࡮ࠨႥ")+xI3Ohpz4vMS7cdWRBQLCuKi
	else:
		ixdXh8DteLKRZn315uI,boHr12d9V4GJ8CjRQyhDNks,xI3Ohpz4vMS7cdWRBQLCuKi = V2RbfGOBdcA6l8NTsPWzEyvS7(u"࠭ࠧႦ"),NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠧࠨႧ"),V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠨࠩႨ")
		UKECneomT7Jg4qGxQhaWjA = mxM8XR1eQOyYcSkuH+v5EA6TqHX3s4jzBMk(u"ࠩ࡟ࡲࡡࡴࠧႩ")+c93ivmW7UNo8aSzuQ1bFCkM
		On4vqcF8hAHx = mxM8XR1eQOyYcSkuH+v5EA6TqHX3s4jzBMk(u"ࠪࡠࡳࡢ࡮ࠨႪ")+c93ivmW7UNo8aSzuQ1bFCkM
		EVDTUHaQZB54mYO6r9Fzkj1XquSLwP = c93ivmW7UNo8aSzuQ1bFCkM
	Koj29tSbeJ67N5FZiB = LgpdP3UjFRnlX(u"ࠫาีหࠡะฺวࠥเ๊า่ࠢๆฺ๎ฯࠨႫ")+BoWHNb9daQVCF16A(u"ࠬࡢ࡮ࠨႬ")
	A7lOhdMkI1UeVqit9fvXwgNBPS0 = ETpwot7H9kVWI5SJzcYLuyRrF()
	VMHlv2hZWwLikUPuJEF3K = []
	ft3e2JBKQVXWlFPjaMhkEqGxvDg = A7lOhdMkI1UeVqit9fvXwgNBPS0[k5dztomYyN3H(u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫႭ")]
	FKup5VAby63 = pscSMYFzgT95ehr0okO7(RhVj0vAt5kPHm)
	if sRth5giAQzWlEVm7JOX(u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬႮ") in list(A7lOhdMkI1UeVqit9fvXwgNBPS0.keys()):
		for IYQKBPdHujwLMlVDE19,be75OEQadWyY0XC1,sdHBNiDAm5bMCU4kXKwcYEonF in ft3e2JBKQVXWlFPjaMhkEqGxvDg: VMHlv2hZWwLikUPuJEF3K = max(VMHlv2hZWwLikUPuJEF3K,be75OEQadWyY0XC1)
		if FKup5VAby63<VMHlv2hZWwLikUPuJEF3K:
			TVesFAuq9Q = RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠨไ่ࠤอะอะ์ฮࠤฬ๊ศา่ส้ัࠦโษๆࠣษึูวๅࠢส่ศิืศร่้๋ࠣศา็ฯࠫႯ")
			D6LK2dzYZMco = Uu0ZdNAP1BWc28lR(NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠩࡵ࡭࡬࡮ࡴࠨႰ"),QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠪษึูวๅࠢศ่๎ࠦวๅ็หี๊าࠧႱ"),EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠫฯำฯ๋อࠪႲ"),BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠬิั้ฮࠪႳ"),Koj29tSbeJ67N5FZiB+TVesFAuq9Q,UKECneomT7Jg4qGxQhaWjA)
			if D6LK2dzYZMco==UnWjVbo503mEMv9KF(u"࠴ᚚ"):
				tLwvQlnjGpWsRVCN1 = mmwySO1P4jnKz5(C2dgEDAKQGsvh(u"࠭ࡣࡦࡰࡷࡩࡷ࠭Ⴔ"),BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠧฯำ๋ะࠬႵ"),v5EA6TqHX3s4jzBMk(u"ࠨฬะำ๏ัࠧႶ"),fY5wTlhtnOc0Er6sdy4k87b(u"ࠩࠪႷ"),TVesFAuq9Q)
				if tLwvQlnjGpWsRVCN1==gItVahxL0w(u"࠶᚛"): D6LK2dzYZMco = gItVahxL0w(u"࠶᚛")
			if D6LK2dzYZMco==C2jP0iLNGKnHu9xp(u"࠷᚜"):
				import gCUboaujSL
				gCUboaujSL.IEsKWSj05CNO(C2jP0iLNGKnHu9xp(u"ࡗࡶࡺ࡫៍"),C2jP0iLNGKnHu9xp(u"ࡗࡶࡺ࡫៍"))
			return
	WClaUIQ8JmHR7cdNOz = zPgNsqpJInt(RnqtMUa9Nh6peGEsBT,RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠪࡰ࡮ࡹࡴࠨႸ"),gItVahxL0w(u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧႹ"),EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠬࡇࡌࡍࡡࡖࡉࡓ࡚࡟ࡆࡔࡕࡓࡗ࡙ࠧႺ"))
	if not WClaUIQ8JmHR7cdNOz: WClaUIQ8JmHR7cdNOz = []
	On4vqcF8hAHx = On4vqcF8hAHx.replace(gItVahxL0w(u"࠭࡜࡯ࠩႻ"),BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠧ࡝࡞ࡱࠫႼ")).replace(LgpdP3UjFRnlX(u"ࠨ࡝ࡕࡘࡑࡣࠧႽ"),QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠩࠪႾ")).replace(NVS30xAdRFMIw1n9CislkE2(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭Ⴟ"),NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠫࠬჀ")).replace(PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧჁ"),PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"࠭ࠧჂ"))
	EVDTUHaQZB54mYO6r9Fzkj1XquSLwP = EVDTUHaQZB54mYO6r9Fzkj1XquSLwP.replace(fY5wTlhtnOc0Er6sdy4k87b(u"ࠧ࡝ࡰࠪჃ"),YB5xyI7MaRslVpv(u"ࠨ࡞࡟ࡲࠬჄ")).replace(gItVahxL0w(u"ࠩ࡞ࡖ࡙ࡒ࡝ࠨჅ"),NVS30xAdRFMIw1n9CislkE2(u"ࠪࠫ჆")).replace(qbPw1d3KimF(u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧჇ"),gItVahxL0w(u"ࠬ࠭჈")).replace(k5dztomYyN3H(u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ჉"),NVS30xAdRFMIw1n9CislkE2(u"ࠧࠨ჊"))
	jP9DBu0QpOsEYrd2ANVbTtUK1R6ZGw = RhVj0vAt5kPHm+EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠨ࠼࠽ࠫ჋")+EVDTUHaQZB54mYO6r9Fzkj1XquSLwP
	if jP9DBu0QpOsEYrd2ANVbTtUK1R6ZGw in WClaUIQ8JmHR7cdNOz:
		TVesFAuq9Q = sRth5giAQzWlEVm7JOX(u"ࠩ็ๆิࠦโๆฬࠣห๋ะࠠิษหๆฬࠦศฦำึห้ࠦ็ัษࠣห้ิืฤࠢศ่๎ࠦวๅ็หี๊าࠧ჌")
		ZIOHgA3z0TBR(V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠪࡶ࡮࡭ࡨࡵࠩჍ"),sRth5giAQzWlEVm7JOX(u"ࠫࠬ჎"),Koj29tSbeJ67N5FZiB+TVesFAuq9Q,UKECneomT7Jg4qGxQhaWjA)
		return
	mBi3Hxj4wCR96lWkJcfZunDh5p = str(YSomBdvcNUMF3b8JDiCfrVW).split(V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠬ࠴ࠧ჏"))[sRth5giAQzWlEVm7JOX(u"࠰᚝")]
	qmr7vLh1EW = AK5RqLhji4W1wt9VdrCD3PGeQM[gItVahxL0w(u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭ა")][k5dztomYyN3H(u"࠷᚞")]
	UMNteoHlkEy3Yf = mORwgTnXBdQ7iCSHKf(f9Oum6c0FotxYn,LgpdP3UjFRnlX(u"ࠧࡑࡑࡖࡘࠬბ"),qmr7vLh1EW,LgpdP3UjFRnlX(u"ࠨࠩგ"),V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠩࠪდ"),v5EA6TqHX3s4jzBMk(u"ࠪࠫე"),RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠫࠬვ"),fY5wTlhtnOc0Er6sdy4k87b(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡓࡉࡑ࡚ࡣࡊ࡞ࡉࡕࡡࡈࡖࡗࡕࡒࡔ࠯࠴ࡷࡹ࠭ზ"),k5dztomYyN3H(u"ࡊࡦࡲࡳࡦ៎"),k5dztomYyN3H(u"ࡊࡦࡲࡳࡦ៎"))
	qqThxfYXnogSpAiJ7GkcLz = UMNteoHlkEy3Yf.content
	K4cbWCpYix70DAkjweGurN6XSnO12I = My7Dwqvs6bfGNSIgX.findall(k5dztomYyN3H(u"࠭ࡓࡕࡃࡕࡘ࠿ࡀࡓࡕࡃࡕࡘࡠࡢࡲ࡝ࡰࡠ࠯࠿ࡀࠨ࠯ࠬࡂ࠭ࡠࡢࡲ࡝ࡰࡠ࠯࠿ࡀࠨ࠯ࠬࡂ࠭ࡠࡢࡲ࡝ࡰࡠ࠯࠿ࡀࠨ࠯ࠬࡂ࠭ࡠࡢࡲ࡝ࡰࡠ࠯࠿ࡀࠨ࠯ࠬࡂ࠭ࡠࡢࡲ࡝ࡰࡠ࠯ࡊࡔࡄ࠻࠼ࡈࡒࡉ࠭თ"),qqThxfYXnogSpAiJ7GkcLz,My7Dwqvs6bfGNSIgX.DOTALL)
	for r7rvIoHXj6LQKG2FUd,uoPGzeJKydEU5q,yEgL5uSaCXWfnmrMRV0U8i,XoHGqTiQhRlw4x53p in K4cbWCpYix70DAkjweGurN6XSnO12I:
		r7rvIoHXj6LQKG2FUd = r7rvIoHXj6LQKG2FUd.split(BoWHNb9daQVCF16A(u"ࠧࠬࠩი"))
		yEgL5uSaCXWfnmrMRV0U8i = yEgL5uSaCXWfnmrMRV0U8i.split(qbPw1d3KimF(u"ࠨ࠭ࠪკ"))
		XoHGqTiQhRlw4x53p = XoHGqTiQhRlw4x53p.split(l0WAe1f7Bpi5ZXk(u"ࠩ࠮ࠫლ"))
		if KkP7tcharOiu2ydX4RvgjTw in r7rvIoHXj6LQKG2FUd and tnOo1QlfFN98JVG6vreRLxb0==uoPGzeJKydEU5q and RhVj0vAt5kPHm in yEgL5uSaCXWfnmrMRV0U8i and mBi3Hxj4wCR96lWkJcfZunDh5p in XoHGqTiQhRlw4x53p:
			TVesFAuq9Q = NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"๋ࠪีอࠠศๆั฻ศࠦๅฺำ๋ๅࠥ๎ำ๋฻ส่ัࠦศศๆศูิอัࠡษ็ๆฬีๅࠨმ")
			tLwvQlnjGpWsRVCN1 = mmwySO1P4jnKz5(EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠫࡷ࡯ࡧࡩࡶࠪნ"),RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠬิั้ฮࠪო"),T6wRistc1SCo4hqObgumK(u"࠭ลาีส่ࠥหไ๊ࠢส่๊ฮัๆฮࠪპ"),Koj29tSbeJ67N5FZiB+TVesFAuq9Q,UKECneomT7Jg4qGxQhaWjA)
			if tLwvQlnjGpWsRVCN1==RqldvxFuM5GEQ2HAz93o7afBb0(u"࠳᚟"): ZIOHgA3z0TBR(UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠧࡤࡧࡱࡸࡪࡸࠧჟ"),gItVahxL0w(u"ࠨࠩრ"),V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠩࠪს"),TVesFAuq9Q)
			return
	TVesFAuq9Q = vvHpKfcqRnrFzjG(u"ࠪห้ืฬศรࠣษึูวๅ๊ࠢิฬࠦวๅะฺวࠥหไ๊ࠢส่๊ฮัๆฮࠪტ")
	ZIOHgA3z0TBR(sRth5giAQzWlEVm7JOX(u"ࠫࡷ࡯ࡧࡩࡶࠪუ"),UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠬหัิษ็ࠤส๊้ࠡษ็้อืๅอࠩფ"),Koj29tSbeJ67N5FZiB+TVesFAuq9Q,UKECneomT7Jg4qGxQhaWjA)
	tLwvQlnjGpWsRVCN1 = mmwySO1P4jnKz5(l0WAe1f7Bpi5ZXk(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ქ"),EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠧࠨღ"),LgpdP3UjFRnlX(u"ࠨࠩყ"),k5dztomYyN3H(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬშ"),QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠪืํ็๋ࠠฬ่ࠤสืำศๆࠣืั๊ࠠศๆฦา฼อม๊ࠡส่ฬูสฯัส้ࠥหไ๊ࠢส่๊ฮัๆฮ่่ࠣ๐๋ࠠ฻ิๅࠥอไๆสิ้ัࠦร๋่ࠣ์๊ะ้๊ࠡๆ๎ๆ่ࠦๅ็สิฬࠦอึๆอࠤ์ึ็ࠡษ็ู้้ไสࠢ็ว๋ࠦวๅ็หี๊าࠠๅษࠣ๎฾๊ๅࠡษ็฾๏ฮ้ࠠๆสࠤ๏ูสุ์฼ࠤฬ฻ไศฯู้้ࠣไส๋๋ࠢํࠦไศࠢํ฽ึ็ࠠไ์ไࠤ฽ํัห๋่๊ࠢอะศࠢ฻๋ึะ้ࠠ็อํࠥ฾็าฬ๋ࠣีํࠠศๆุ่่๊ษࠡ࠰๋้ࠣࠦสา์าࠤศืำศๆࠣหู้ฬๅࠢยࠫჩ"))
	if tLwvQlnjGpWsRVCN1==NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠴ᚠ"): SLujV8UBJvsF9fwgqQ7y = QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠫࡤࡖࡒࡐࡄࡏࡉࡒࡥࠧც")
	else:
		ZIOHgA3z0TBR(qbPw1d3KimF(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬძ"),l0WAe1f7Bpi5ZXk(u"࠭ࠧწ"),nr5mZG89ICi6cgt4MfLJa0(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪჭ"),v5EA6TqHX3s4jzBMk(u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠฮ๊ࠦลๅ฼สลࠥหัิษ็ࠤฬ๊ฮุล࡞࠳ࡈࡕࡌࡐࡔࡠࡠࡳ๊ร็ࠢส่๊ฮัๆฮ่ࠣฬฺ๊ࠦๆ่ࠤฬฺ๊๋สࠣ์้อ๋ࠠีอ฻๏฿ࠠฦื็หาࠦวๅะฺวࠥฮฯ้่ࠣืั๊ࠠศๆฦา฼อมࠡษ็ิ๏ࠦๅไฬ๋ฬࠥ็๊่ࠢฯ้๏฿ࠠหใสู๏๊่ࠠาสࠤฬ๊ฮุลࠣ์฿๐ั่่๊ࠢࠥอไฤะฺหฦ࠭ხ"))
		return
	mKBurDQaSIn1Aydsc9LvbF5EZf = On4vqcF8hAHx
	from gCUboaujSL import RR8P1CEUq6m
	tUEvo5HAfIjZgcdYxNJ8awu = RR8P1CEUq6m(fY5wTlhtnOc0Er6sdy4k87b(u"ࠩࡈࡶࡷࡵࡲࡴࠩჯ"),mKBurDQaSIn1Aydsc9LvbF5EZf,vvHpKfcqRnrFzjG(u"࡙ࡸࡵࡦ៏"),EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠪࠫჰ"),jSu5Cg2Ub1OAkZVs8Yoz(u"ࠫࡊࡓࡁࡊࡎ࠰ࡊࡗࡕࡍ࠮ࡕࡋࡓ࡜ࡥࡅ࡙ࡋࡗࡣࡊࡘࡒࡐࡔࡖࠫჱ"),SLujV8UBJvsF9fwgqQ7y)
	if tUEvo5HAfIjZgcdYxNJ8awu and SLujV8UBJvsF9fwgqQ7y:
		WClaUIQ8JmHR7cdNOz.append(jP9DBu0QpOsEYrd2ANVbTtUK1R6ZGw)
		VZ8BTik93OqXLCh0fD7d2KUPpn4mH6(RnqtMUa9Nh6peGEsBT,fY5wTlhtnOc0Er6sdy4k87b(u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨჲ"),v5EA6TqHX3s4jzBMk(u"࠭ࡁࡍࡎࡢࡗࡊࡔࡔࡠࡇࡕࡖࡔࡘࡓࠨჳ"),WClaUIQ8JmHR7cdNOz,BZdvf7MIUxHQc3aCT)
	return
def Hlb8M75Eu9figKarnPWNctZOhvjC(AqLgT4S6FExHi1kZ5smy7a0hRX):
	if BLz7m2RkNrxXQwy1cGAp: AqLgT4S6FExHi1kZ5smy7a0hRX = AqLgT4S6FExHi1kZ5smy7a0hRX.encode(jSu5Cg2Ub1OAkZVs8Yoz(u"ࠧࡶࡶࡩ࠼ࠬჴ"))
	MVQo7cbNdaril0FG6Pp = EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠨࡵ࠽ࡠࡡ࠶࠰࠱࠲ࡨࡱࡦࡪ࡟ࠨჵ")+str(KBxPW9cX8dqtaUDG.time())+NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠩ࠱ࡨࡦࡺࠧჶ")
	open(MVQo7cbNdaril0FG6Pp,C2jP0iLNGKnHu9xp(u"ࠪࡻࡧ࠭ჷ")).write(AqLgT4S6FExHi1kZ5smy7a0hRX)
	return
def GGWFyslIXMqOpfZTdc95Y2467B1J8e(IlpZ3itqN15kDozB6QA4JTE):
	if IlpZ3itqN15kDozB6QA4JTE:
		JEUhp7OfCsPMIcBeL5Xz8nl4 = zPgNsqpJInt(RnqtMUa9Nh6peGEsBT,b05yftsZ6NYgIKP(u"ࠫࡱ࡯ࡳࡵࠩჸ"),nr5mZG89ICi6cgt4MfLJa0(u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࠨჹ"),nr5mZG89ICi6cgt4MfLJa0(u"࠭ࡑࡖࡇࡖࡘࡎࡕࡎࡔࠩჺ"))
		if JEUhp7OfCsPMIcBeL5Xz8nl4: return JEUhp7OfCsPMIcBeL5Xz8nl4
	qmr7vLh1EW = AK5RqLhji4W1wt9VdrCD3PGeQM[UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠧࡑ࡛ࡗࡌࡔࡔࠧ჻")][sRth5giAQzWlEVm7JOX(u"࠹ᚡ")]
	ggfedDsABTMIh = hvc2sXOB31KTLgiZaQUR9xuGjloYS(hhlbF1Sns5TrEN8QPCYmL4(u"࠸࠸ᚢ"),IlpZ3itqN15kDozB6QA4JTE)
	jZLmif48dFVOW1 = xFP4v9DfhOV8yo()
	KTL7OP3spfChQm9n8UudYMDt = jZLmif48dFVOW1.split(k5dztomYyN3H(u"ࠨ࠮ࠪჼ"))[b05yftsZ6NYgIKP(u"࠸ᚣ")]
	hfa8xlLke7s = XXRtDhYvWb35qnLBxIri7ScNUks0.path.join(QgRBJhSGd4uX7i,RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠩࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨჽ"))
	qbenlV5uFd38OfRC6LchNji = mnjYwRBF97ZdqW8Xl0CzkQcsvJH()
	XQ6bCdRgwsz3H1heoj9Zicq70OnBlA = {qbPw1d3KimF(u"ࠪࡹࡸ࡫ࡲࠨჾ"):ggfedDsABTMIh,V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲࠬჿ"):RhVj0vAt5kPHm,YB5xyI7MaRslVpv(u"ࠬࡩ࡯ࡶࡰࡷࡶࡾ࠭ᄀ"):KTL7OP3spfChQm9n8UudYMDt,fY5wTlhtnOc0Er6sdy4k87b(u"࠭ࡩࡥࡵࠪᄁ"):UnJu5mvBrPKqOidwpNcjAbh(qbenlV5uFd38OfRC6LchNji)}
	UMNteoHlkEy3Yf = mORwgTnXBdQ7iCSHKf(SToQEHqGtMnAlFbCz4wxBDuOsmW7,WMkAjB1RgN7q(u"ࠧࡑࡑࡖࡘࠬᄂ"),qmr7vLh1EW,XQ6bCdRgwsz3H1heoj9Zicq70OnBlA,l0WAe1f7Bpi5ZXk(u"ࠨࠩᄃ"),V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠩࠪᄄ"),jx7s8T0BFgODXLMzIYedf(u"ࠪࠫᄅ"),PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡅࡕࡡࡔ࡙ࡊ࡙ࡔࡊࡑࡑࡗ࠲࠷ࡳࡵࠩᄆ"))
	JEUhp7OfCsPMIcBeL5Xz8nl4 = []
	if UMNteoHlkEy3Yf.succeeded:
		qqThxfYXnogSpAiJ7GkcLz = UMNteoHlkEy3Yf.content
		JEUhp7OfCsPMIcBeL5Xz8nl4 = qqThxfYXnogSpAiJ7GkcLz.replace(FGDJwkEbTB5SoXujs3f(u"ࠬࡢ࡜ࡳࠩᄇ"),jSu5Cg2Ub1OAkZVs8Yoz(u"࠭࡜࡯ࠩᄈ")).replace(BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠧ࡝࡞ࡱࠫᄉ"),BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠨ࡞ࡱࠫᄊ")).replace(qbPw1d3KimF(u"ࠩ࡟ࡶࡡࡴࠧᄋ"),v5EA6TqHX3s4jzBMk(u"ࠪࡠࡳ࠭ᄌ")).replace(sRth5giAQzWlEVm7JOX(u"ࠫࡡࡸࠧᄍ"),LgpdP3UjFRnlX(u"ࠬࡢ࡮ࠨᄎ"))
		JEUhp7OfCsPMIcBeL5Xz8nl4 = My7Dwqvs6bfGNSIgX.findall(gItVahxL0w(u"࠭ࡓࡕࡃࡕࡘ࠿ࡀࡓࡕࡃࡕࡘ࠿ࡀࠨ࡝ࡦ࠮࠭࠿ࡀࠨ࠯ࠬࡂ࠭ࡡࡴ࠺࠻ࠪ࠱࠮ࡄ࠯࡜࡯࠼࠽ࠬ࠳࠰࠿ࠪ࡞ࡱ࠾࠿࠮࠮ࠫࡁࠬࡠࡳࡀ࠺ࠩ࠰࠭ࡃ࠮ࡢ࡮ࡆࡐࡇ࠾࠿ࡋࡎࡅࠩᄏ"),JEUhp7OfCsPMIcBeL5Xz8nl4,My7Dwqvs6bfGNSIgX.DOTALL)
		if JEUhp7OfCsPMIcBeL5Xz8nl4:
			JEUhp7OfCsPMIcBeL5Xz8nl4 = sorted(JEUhp7OfCsPMIcBeL5Xz8nl4,reverse=v5EA6TqHX3s4jzBMk(u"ࡌࡡ࡭ࡵࡨ័"),key=lambda key: int(key[C2jP0iLNGKnHu9xp(u"࠰ᚤ")]))
			HHSczv3E0A1JgipTBqYCPwR,ggfedDsABTMIh,WPUxzqgnlY7aVGkA2RsSt1r5X4pHjJ,D0nq5FW8AJKejN91PO,RsKWNOw4Dg91bT7SdazF,ag6Mwkfe2YZ5CdTNOLjyob3 = JEUhp7OfCsPMIcBeL5Xz8nl4[nr5mZG89ICi6cgt4MfLJa0(u"࠱ᚥ")]
			qTLcR9Y6BwGWsIXOZ2 = ag6Mwkfe2YZ5CdTNOLjyob3 if jjwPCAGBnWFIl2L0(UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠧࡎࡖ࠳࠹ࡍ࡞࠰࡭ࡖࡗࡉࡋࡔࡓࡖࡐࡩ࡙ࡊ࡜ࡓࡔࡗ࠼ࡉ࡝࠭ᄐ")) else WPUxzqgnlY7aVGkA2RsSt1r5X4pHjJ
			bLEBi8IO7uU2x3htYDdVq95.setSetting(LgpdP3UjFRnlX(u"ࠨࡣࡹ࠲ࡵ࡫ࡲࡪࡱࡧ࠲࡮ࡴࡦࡰࡵࠪᄑ"),qTLcR9Y6BwGWsIXOZ2)
			VZ8BTik93OqXLCh0fD7d2KUPpn4mH6(RnqtMUa9Nh6peGEsBT,T6wRistc1SCo4hqObgumK(u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬᄒ"),WMkAjB1RgN7q(u"ࠪࡕ࡚ࡋࡓࡕࡋࡒࡒࡘ࠭ᄓ"),JEUhp7OfCsPMIcBeL5Xz8nl4,UuEtImzir9)
			bLEBi8IO7uU2x3htYDdVq95.setSetting(UnWjVbo503mEMv9KF(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ࠭ᄔ"),UnJu5mvBrPKqOidwpNcjAbh(SGB7KzblUa4gCZD1srqc))
	return JEUhp7OfCsPMIcBeL5Xz8nl4
def wJ3eVs2RACuYPWEavOqKhlGj(XVl5g94ZuhxtRLjAMkO7,rr9fiqh2yKD=fY5wTlhtnOc0Er6sdy4k87b(u"࠲ᚦ"),eemI3SnLb5NFDjW4uKRo8CMrXZAYx=fY5wTlhtnOc0Er6sdy4k87b(u"࠲ᚦ")):
	if rr9fiqh2yKD and not eemI3SnLb5NFDjW4uKRo8CMrXZAYx: eemI3SnLb5NFDjW4uKRo8CMrXZAYx = len(XVl5g94ZuhxtRLjAMkO7)//rr9fiqh2yKD
	UPCOLqt6JmkN7Sw24V98izj,k3Om08MCgqQao4n1,nnzHUvw6s07xyEqXkuh5pR1Cj = [],-UnWjVbo503mEMv9KF(u"࠴ᚧ"),vvHpKfcqRnrFzjG(u"࠴ᚨ")
	for FatuQ5gf41DEVHjxBMKwbnyd7ziSl in XVl5g94ZuhxtRLjAMkO7:
		if nnzHUvw6s07xyEqXkuh5pR1Cj%eemI3SnLb5NFDjW4uKRo8CMrXZAYx==BmcLzCFjuIrZP5fwXH18aN6YS(u"࠵ᚩ"):
			k3Om08MCgqQao4n1 += nr5mZG89ICi6cgt4MfLJa0(u"࠷ᚪ")
			UPCOLqt6JmkN7Sw24V98izj.append([])
		UPCOLqt6JmkN7Sw24V98izj[k3Om08MCgqQao4n1].append(FatuQ5gf41DEVHjxBMKwbnyd7ziSl)
		nnzHUvw6s07xyEqXkuh5pR1Cj += l0WAe1f7Bpi5ZXk(u"࠱ᚫ")
	return UPCOLqt6JmkN7Sw24V98izj
def Aaq43fy1ozvXu27HEbFITdhU9D(MVQo7cbNdaril0FG6Pp,AqLgT4S6FExHi1kZ5smy7a0hRX):
	M7LVXIUhsB2Jnjxy = XXRtDhYvWb35qnLBxIri7ScNUks0.path.join(IjYiO4u9HGmgw,MVQo7cbNdaril0FG6Pp)
	if v5EA6TqHX3s4jzBMk(u"࠲ᚬ") or v5EA6TqHX3s4jzBMk(u"ࠬࡏࡐࡕࡘࡢࠫᄕ") not in MVQo7cbNdaril0FG6Pp or NVS30xAdRFMIw1n9CislkE2(u"࠭ࡍ࠴ࡗࡢࠫᄖ") not in MVQo7cbNdaril0FG6Pp: QHDcUO2xtS4CmF = str(AqLgT4S6FExHi1kZ5smy7a0hRX)
	else:
		UPCOLqt6JmkN7Sw24V98izj = wJ3eVs2RACuYPWEavOqKhlGj(AqLgT4S6FExHi1kZ5smy7a0hRX,fY5wTlhtnOc0Er6sdy4k87b(u"࠺ᚭ"))
		QHDcUO2xtS4CmF = NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠧࠨᄗ")
		for ww5EnDCV0foiPyIqZ in UPCOLqt6JmkN7Sw24V98izj:
			QHDcUO2xtS4CmF += str(ww5EnDCV0foiPyIqZ)+UnWjVbo503mEMv9KF(u"ࠨ࡞ࡱࡠࡳࡃ࠽࠾࠿࡟ࡲࡡࡴࠧᄘ")
		QHDcUO2xtS4CmF = QHDcUO2xtS4CmF.strip(NVS30xAdRFMIw1n9CislkE2(u"ࠩ࡟ࡲࡡࡴ࠽࠾࠿ࡀࡠࡳࡢ࡮ࠨᄙ"))
	NvHcgpGbUDiuoFTVmfJ8B9Rh4 = DDeKqnGoBpLH1d6civ8JgN4V.compress(QHDcUO2xtS4CmF)
	open(M7LVXIUhsB2Jnjxy,vvHpKfcqRnrFzjG(u"ࠪࡻࡧ࠭ᄚ")).write(NvHcgpGbUDiuoFTVmfJ8B9Rh4)
	return
def bvW3uq6VkOiCGopjQz2s4(plWqMa0QgKcbR5n8L1GVozyek3,MVQo7cbNdaril0FG6Pp):
	if plWqMa0QgKcbR5n8L1GVozyek3==sRth5giAQzWlEVm7JOX(u"ࠫࡩ࡯ࡣࡵࠩᄛ"): AqLgT4S6FExHi1kZ5smy7a0hRX = {}
	elif plWqMa0QgKcbR5n8L1GVozyek3==C2dgEDAKQGsvh(u"ࠬࡲࡩࡴࡶࠪᄜ"): AqLgT4S6FExHi1kZ5smy7a0hRX = []
	elif plWqMa0QgKcbR5n8L1GVozyek3==RqldvxFuM5GEQ2HAz93o7afBb0(u"࠭ࡳࡵࡴࠪᄝ"): AqLgT4S6FExHi1kZ5smy7a0hRX = UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠧࠨᄞ")
	elif plWqMa0QgKcbR5n8L1GVozyek3==b05yftsZ6NYgIKP(u"ࠨ࡫ࡱࡸࠬᄟ"): AqLgT4S6FExHi1kZ5smy7a0hRX = sRth5giAQzWlEVm7JOX(u"࠳ᚮ")
	else: AqLgT4S6FExHi1kZ5smy7a0hRX = None
	M7LVXIUhsB2Jnjxy = XXRtDhYvWb35qnLBxIri7ScNUks0.path.join(IjYiO4u9HGmgw,MVQo7cbNdaril0FG6Pp)
	NvHcgpGbUDiuoFTVmfJ8B9Rh4 = open(M7LVXIUhsB2Jnjxy,C2dgEDAKQGsvh(u"ࠩࡵࡦࠬᄠ")).read()
	QHDcUO2xtS4CmF = DDeKqnGoBpLH1d6civ8JgN4V.decompress(NvHcgpGbUDiuoFTVmfJ8B9Rh4)
	if qbPw1d3KimF(u"ࠪࡠࡳࡢ࡮࠾࠿ࡀࡁࡡࡴ࡜࡯ࠩᄡ") not in QHDcUO2xtS4CmF: AqLgT4S6FExHi1kZ5smy7a0hRX = eval(QHDcUO2xtS4CmF)
	else:
		UPCOLqt6JmkN7Sw24V98izj = QHDcUO2xtS4CmF.split(WMkAjB1RgN7q(u"ࠫࡡࡴ࡜࡯࠿ࡀࡁࡂࡢ࡮࡝ࡰࠪᄢ"))
		del QHDcUO2xtS4CmF
		AqLgT4S6FExHi1kZ5smy7a0hRX = []
		JJcW5nfAj1lso9uxCw8Tmqdh = AuHy92xSpftDB8R()
		HHSczv3E0A1JgipTBqYCPwR = fY5wTlhtnOc0Er6sdy4k87b(u"࠴ᚯ")
		for ww5EnDCV0foiPyIqZ in UPCOLqt6JmkN7Sw24V98izj:
			JJcW5nfAj1lso9uxCw8Tmqdh.iRtBAskTZXufJLh8Yox6UQcCrjdHg(str(HHSczv3E0A1JgipTBqYCPwR),eval,ww5EnDCV0foiPyIqZ)
			HHSczv3E0A1JgipTBqYCPwR += qbPw1d3KimF(u"࠶ᚰ")
		del UPCOLqt6JmkN7Sw24V98izj
		JJcW5nfAj1lso9uxCw8Tmqdh.x0vO68YI9NHnPhMWzQqpR()
		JJcW5nfAj1lso9uxCw8Tmqdh.cyAHC69tsxaNzYP2GbpvQj54()
		PPxBtur2Oys31QbIDc8n6USMG = list(JJcW5nfAj1lso9uxCw8Tmqdh.resultsDICT.keys())
		jGgSDfqchBRW3Q9PTwsmlEu1XYt2 = sorted(PPxBtur2Oys31QbIDc8n6USMG,reverse=b05yftsZ6NYgIKP(u"ࡆࡢ࡮ࡶࡩ៑"),key=lambda key: int(key))
		for HHSczv3E0A1JgipTBqYCPwR in jGgSDfqchBRW3Q9PTwsmlEu1XYt2:
			AqLgT4S6FExHi1kZ5smy7a0hRX += JJcW5nfAj1lso9uxCw8Tmqdh.resultsDICT[HHSczv3E0A1JgipTBqYCPwR]
	return AqLgT4S6FExHi1kZ5smy7a0hRX
def ewrfuTac8NV6jLhdp7G41txMWE5(Kczs71doMyLHwN):
	PHXkFSTV8UYDqK25Ixep6htrvOB = XXRtDhYvWb35qnLBxIri7ScNUks0.path.join(gK53PXkR96t7djpHeqEyL0,EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠬࡧࡤࡥࡱࡱࡷࠬᄣ"),Kczs71doMyLHwN,b05yftsZ6NYgIKP(u"࠭ࡡࡥࡦࡲࡲ࠳ࡾ࡭࡭ࠩᄤ"))
	try: yxz1fnbG67kCB0VMOXR5Z3DLp8iU = open(PHXkFSTV8UYDqK25Ixep6htrvOB,v5EA6TqHX3s4jzBMk(u"ࠧࡳࡤࠪᄥ")).read()
	except:
		glBybGjkfLSZcR3zd0tK6Hu9i = XXRtDhYvWb35qnLBxIri7ScNUks0.path.join(yef0QYHk1JaWrXKsUqNLnPwj3uDo,jSu5Cg2Ub1OAkZVs8Yoz(u"ࠨࡣࡧࡨࡴࡴࡳࠨᄦ"),Kczs71doMyLHwN,C2jP0iLNGKnHu9xp(u"ࠩࡤࡨࡩࡵ࡮࠯ࡺࡰࡰࠬᄧ"))
		try: yxz1fnbG67kCB0VMOXR5Z3DLp8iU = open(glBybGjkfLSZcR3zd0tK6Hu9i,C2jP0iLNGKnHu9xp(u"ࠪࡶࡧ࠭ᄨ")).read()
		except: return v5EA6TqHX3s4jzBMk(u"ࠫࠬᄩ"),[]
	if BLz7m2RkNrxXQwy1cGAp: yxz1fnbG67kCB0VMOXR5Z3DLp8iU = yxz1fnbG67kCB0VMOXR5Z3DLp8iU.decode(FGDJwkEbTB5SoXujs3f(u"ࠬࡻࡴࡧ࠺ࠪᄪ"))
	i1jL5OC6DbzgTs2xMXl = My7Dwqvs6bfGNSIgX.findall(RqldvxFuM5GEQ2HAz93o7afBb0(u"࠭ࡩࡥ࠿࠱࠮ࡄࡼࡥࡳࡵ࡬ࡳࡳࡃ࡛࡝ࠤ࡟ࠫࡢ࠮࠮ࠫࡁࠬ࡟ࡡࠨ࡜ࠨ࡟ࠪᄫ"),yxz1fnbG67kCB0VMOXR5Z3DLp8iU,My7Dwqvs6bfGNSIgX.DOTALL|My7Dwqvs6bfGNSIgX.IGNORECASE)
	if not i1jL5OC6DbzgTs2xMXl: return BoWHNb9daQVCF16A(u"ࠧࠨᄬ"),[]
	upzHG0dkRjDK4YEg9xa7Fn5wfeUyb,QiXl64yzYnWwIEUb0uN5RmHgO = i1jL5OC6DbzgTs2xMXl[YB5xyI7MaRslVpv(u"࠶ᚱ")],pscSMYFzgT95ehr0okO7(i1jL5OC6DbzgTs2xMXl[YB5xyI7MaRslVpv(u"࠶ᚱ")])
	return upzHG0dkRjDK4YEg9xa7Fn5wfeUyb,QiXl64yzYnWwIEUb0uN5RmHgO
def ETpwot7H9kVWI5SJzcYLuyRrF():
	d96dkyzQ7B0 = zPgNsqpJInt(RnqtMUa9Nh6peGEsBT,C2dgEDAKQGsvh(u"ࠨࡦ࡬ࡧࡹ࠭ᄭ"),v5EA6TqHX3s4jzBMk(u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬᄮ"),C2dgEDAKQGsvh(u"ࠪࡅࡑࡒ࡟ࡂࡆࡇࡓࡓ࡙࡟࡙ࡏࡏࠫᄯ"))
	if d96dkyzQ7B0: return d96dkyzQ7B0
	A7lOhdMkI1UeVqit9fvXwgNBPS0,d96dkyzQ7B0 = {},{}
	PbqcvoD89L6AX = [AK5RqLhji4W1wt9VdrCD3PGeQM[NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠫࡗࡋࡐࡐࡕࠪᄰ")][FGDJwkEbTB5SoXujs3f(u"࠰ᚲ")]]
	if YSomBdvcNUMF3b8JDiCfrVW>EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠳࠺࠲࠾࠿ᚴ"): PbqcvoD89L6AX.append(AK5RqLhji4W1wt9VdrCD3PGeQM[k5dztomYyN3H(u"ࠬࡘࡅࡑࡑࡖࠫᄱ")][EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠲ᚳ")])
	if BLz7m2RkNrxXQwy1cGAp: PbqcvoD89L6AX.append(AK5RqLhji4W1wt9VdrCD3PGeQM[qbPw1d3KimF(u"࠭ࡒࡆࡒࡒࡗࠬᄲ")][LgpdP3UjFRnlX(u"࠵ᚵ")])
	for d6UyhrzbWaf3mDERqpotMQwKvNZk in PbqcvoD89L6AX:
		UMNteoHlkEy3Yf = mORwgTnXBdQ7iCSHKf(SToQEHqGtMnAlFbCz4wxBDuOsmW7,b05yftsZ6NYgIKP(u"ࠧࡈࡇࡗࠫᄳ"),d6UyhrzbWaf3mDERqpotMQwKvNZk,EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠨࠩᄴ"),WMkAjB1RgN7q(u"ࠩࠪᄵ"),gItVahxL0w(u"ࠪࠫᄶ"),v5EA6TqHX3s4jzBMk(u"ࠫࠬᄷ"),v5EA6TqHX3s4jzBMk(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡒࡆࡃࡇࡣࡆࡒࡌࡠࡃࡇࡈࡔࡔࡓࡠ࡚ࡐࡐ࠲࠷ࡳࡵࠩᄸ"))
		if UMNteoHlkEy3Yf.succeeded:
			qqThxfYXnogSpAiJ7GkcLz = UMNteoHlkEy3Yf.content
			ZJuXCIlN5bAWxTry = d6UyhrzbWaf3mDERqpotMQwKvNZk.rsplit(UxS67uoGThbMwnfNRzy4gajLd23JH(u"࠭࠯ࠨᄹ"),sRth5giAQzWlEVm7JOX(u"࠵ᚶ"))[FGDJwkEbTB5SoXujs3f(u"࠵ᚷ")]
			eiPkaWsDM2gdLIG = My7Dwqvs6bfGNSIgX.findall(QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠧࡪࡦࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡶࡦࡴࡶ࡭ࡴࡴ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᄺ"),qqThxfYXnogSpAiJ7GkcLz,My7Dwqvs6bfGNSIgX.DOTALL|My7Dwqvs6bfGNSIgX.IGNORECASE)
			for Kczs71doMyLHwN,aTFbW06jcYyPkls in eiPkaWsDM2gdLIG:
				iBMcH4rgQJn5WlVEI = ZJuXCIlN5bAWxTry+NVS30xAdRFMIw1n9CislkE2(u"ࠨ࠱ࠪᄻ")+Kczs71doMyLHwN+nr5mZG89ICi6cgt4MfLJa0(u"ࠩ࠲ࠫᄼ")+Kczs71doMyLHwN+UnWjVbo503mEMv9KF(u"ࠪ࠱ࠬᄽ")+aTFbW06jcYyPkls+v5EA6TqHX3s4jzBMk(u"ࠫ࠳ࢀࡩࡱࠩᄾ")
				if Kczs71doMyLHwN not in list(A7lOhdMkI1UeVqit9fvXwgNBPS0.keys()):
					A7lOhdMkI1UeVqit9fvXwgNBPS0[Kczs71doMyLHwN] = []
					d96dkyzQ7B0[Kczs71doMyLHwN] = []
				cJiO3AdH5Lfrm1BjVvtS = pscSMYFzgT95ehr0okO7(aTFbW06jcYyPkls)
				A7lOhdMkI1UeVqit9fvXwgNBPS0[Kczs71doMyLHwN].append((aTFbW06jcYyPkls,cJiO3AdH5Lfrm1BjVvtS,iBMcH4rgQJn5WlVEI))
	for Kczs71doMyLHwN in list(A7lOhdMkI1UeVqit9fvXwgNBPS0.keys()):
		d96dkyzQ7B0[Kczs71doMyLHwN] = sorted(A7lOhdMkI1UeVqit9fvXwgNBPS0[Kczs71doMyLHwN],reverse=BoWHNb9daQVCF16A(u"ࡕࡴࡸࡩ្"),key=lambda key: key[b05yftsZ6NYgIKP(u"࠷ᚸ")])
	VZ8BTik93OqXLCh0fD7d2KUPpn4mH6(RnqtMUa9Nh6peGEsBT,V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࠨᄿ"),nr5mZG89ICi6cgt4MfLJa0(u"࠭ࡁࡍࡎࡢࡅࡉࡊࡏࡏࡕࡢ࡜ࡒࡒࠧᅀ"),d96dkyzQ7B0,UuEtImzir9)
	return d96dkyzQ7B0
def pscSMYFzgT95ehr0okO7(aTFbW06jcYyPkls):
	cJiO3AdH5Lfrm1BjVvtS = []
	VhIpru58Ns = aTFbW06jcYyPkls.split(hhlbF1Sns5TrEN8QPCYmL4(u"ࠧ࠯ࠩᅁ"))
	for rWVUZC3861QysBJw4DA5eRal in VhIpru58Ns:
		APdqD7UTX6xavcW = My7Dwqvs6bfGNSIgX.findall(jx7s8T0BFgODXLMzIYedf(u"ࠨ࡞ࡧ࠯ࢁࡡ࡜ࠬ࡞࠰ࡥ࠲ࢀࡁ࠮࡜ࡠ࠯ࠬᅂ"),rWVUZC3861QysBJw4DA5eRal,My7Dwqvs6bfGNSIgX.DOTALL)
		B8kXz0CUtDVZhS = []
		for FIZPjUufCdhRmOtXlAE3sS in APdqD7UTX6xavcW:
			if FIZPjUufCdhRmOtXlAE3sS.isdigit(): FIZPjUufCdhRmOtXlAE3sS = int(FIZPjUufCdhRmOtXlAE3sS)
			B8kXz0CUtDVZhS.append(FIZPjUufCdhRmOtXlAE3sS)
		cJiO3AdH5Lfrm1BjVvtS.append(B8kXz0CUtDVZhS)
	return cJiO3AdH5Lfrm1BjVvtS
def cZaDdnTvES5eCqpMbxgwut4(cJiO3AdH5Lfrm1BjVvtS):
	aTFbW06jcYyPkls = hhlbF1Sns5TrEN8QPCYmL4(u"ࠩࠪᅃ")
	for rWVUZC3861QysBJw4DA5eRal in cJiO3AdH5Lfrm1BjVvtS:
		for FIZPjUufCdhRmOtXlAE3sS in rWVUZC3861QysBJw4DA5eRal: aTFbW06jcYyPkls += str(FIZPjUufCdhRmOtXlAE3sS)
		aTFbW06jcYyPkls += gItVahxL0w(u"ࠪ࠲ࠬᅄ")
	aTFbW06jcYyPkls = aTFbW06jcYyPkls.strip(jx7s8T0BFgODXLMzIYedf(u"ࠫ࠳࠭ᅅ"))
	return aTFbW06jcYyPkls
def DdTjzlVGwQ9mJo(Oyo3Rj7VFn0):
	fsKS5t6mhrx0 = {}
	A7lOhdMkI1UeVqit9fvXwgNBPS0 = ETpwot7H9kVWI5SJzcYLuyRrF()
	nIH1hbpoGlZi3UPMrBf6djDFzsYNR = NbOMplyJ89Vv1zHEt(Oyo3Rj7VFn0)
	for Kczs71doMyLHwN in Oyo3Rj7VFn0:
		if Kczs71doMyLHwN not in list(A7lOhdMkI1UeVqit9fvXwgNBPS0.keys()): continue
		d96dkyzQ7B0 = A7lOhdMkI1UeVqit9fvXwgNBPS0[Kczs71doMyLHwN]
		JtWAalqO4MX8i9n,VezMRKIp7PUtlf,dLZyrJ5WHC6IQMvxbRTEPlDgS = d96dkyzQ7B0[hhlbF1Sns5TrEN8QPCYmL4(u"࠰ᚹ")]
		NsAFJ59SBuMIdoXYvaUWpLC,veU18auIm3r6liqOLEd5wTJDksyz4N = ewrfuTac8NV6jLhdp7G41txMWE5(Kczs71doMyLHwN)
		SS1HxaQnjU,emvc4qSiO80AFRJXMCh1 = nIH1hbpoGlZi3UPMrBf6djDFzsYNR[Kczs71doMyLHwN]
		ffIETO017x6cUH3wR = VezMRKIp7PUtlf>veU18auIm3r6liqOLEd5wTJDksyz4N and SS1HxaQnjU
		ttRZ9D4Ssngb = UnWjVbo503mEMv9KF(u"ࡖࡵࡹࡪ៓")
		if not SS1HxaQnjU: UaxvEYyZX2Btu1T7DG = C2jP0iLNGKnHu9xp(u"ࠬࡳࡩࡴࡵ࡬ࡲ࡬࠭ᅆ")
		elif not emvc4qSiO80AFRJXMCh1: UaxvEYyZX2Btu1T7DG = hhlbF1Sns5TrEN8QPCYmL4(u"࠭ࡤࡪࡵࡤࡦࡱ࡫ࡤࠨᅇ")
		elif ffIETO017x6cUH3wR: UaxvEYyZX2Btu1T7DG = RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠧࡰ࡮ࡧࠫᅈ")
		else:
			UaxvEYyZX2Btu1T7DG = NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠨࡩࡲࡳࡩ࠭ᅉ")
			ttRZ9D4Ssngb = v5EA6TqHX3s4jzBMk(u"ࡉࡥࡱࡹࡥ។")
		fsKS5t6mhrx0[Kczs71doMyLHwN] = (ttRZ9D4Ssngb,NsAFJ59SBuMIdoXYvaUWpLC,veU18auIm3r6liqOLEd5wTJDksyz4N,JtWAalqO4MX8i9n,VezMRKIp7PUtlf,UaxvEYyZX2Btu1T7DG,dLZyrJ5WHC6IQMvxbRTEPlDgS)
	return fsKS5t6mhrx0
def M3QI1bliHdj7poRFV2OG(hensWGjium8DSy3aVQEOdR95t,ooWYnSJrQ9,eyNz9k8IDYRdWsqP=v5EA6TqHX3s4jzBMk(u"ࠩࠪᅊ"),boHr12d9V4GJ8CjRQyhDNks=PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠪࠫᅋ"),r7rvIoHXj6LQKG2FUd=RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠫࠬᅌ")):
	if V8fmEML1b0PeaRZySnzh3H5J9: hensWGjium8DSy3aVQEOdR95t.update(ooWYnSJrQ9,eyNz9k8IDYRdWsqP,boHr12d9V4GJ8CjRQyhDNks,r7rvIoHXj6LQKG2FUd)
	else: hensWGjium8DSy3aVQEOdR95t.update(ooWYnSJrQ9,eyNz9k8IDYRdWsqP+l0WAe1f7Bpi5ZXk(u"ࠬࡢ࡮ࠨᅍ")+boHr12d9V4GJ8CjRQyhDNks+BoWHNb9daQVCF16A(u"࠭࡜࡯ࠩᅎ")+r7rvIoHXj6LQKG2FUd)
	return
def t5XjI6pYbBTMdmDwxrzS9qkF(s6Wmzn9rJg4hfpa):
	def WD4MOzm8pruh(SEe6gf8Pb3N,tUunlg3F1qhOVDQ7vr,VwNU6cJb1n0dhvfk=qbPw1d3KimF(u"ࠢ࠱࠳࠵࠷࠹࠻࠶࠸࠺࠼ࡥࡧࡩࡤࡦࡨࡪ࡬࡮ࡰ࡫࡭࡯ࡱࡳࡵࡷࡲࡴࡶࡸࡺࡼࡾࡹࡻࡃࡅࡇࡉࡋࡆࡈࡊࡌࡎࡐࡒࡍࡏࡑࡓࡕࡗ࡙ࡔࡖࡘ࡚࡜࡞ࡠࠢᅏ")):
		return ((SEe6gf8Pb3N == nr5mZG89ICi6cgt4MfLJa0(u"࠱ᚺ")) and VwNU6cJb1n0dhvfk[nr5mZG89ICi6cgt4MfLJa0(u"࠱ᚺ")]) or (WD4MOzm8pruh(SEe6gf8Pb3N // tUunlg3F1qhOVDQ7vr, tUunlg3F1qhOVDQ7vr, VwNU6cJb1n0dhvfk).lstrip(VwNU6cJb1n0dhvfk[nr5mZG89ICi6cgt4MfLJa0(u"࠱ᚺ")]) + VwNU6cJb1n0dhvfk[SEe6gf8Pb3N % tUunlg3F1qhOVDQ7vr])
	def aa2dxQWH7Dr8KjkNlA(HgxuSOzyIjJGmDLCUw9AXsnqiYp1r, xhIMnjFbcKD, qfFZ5QSOedhUiK46N, BuoDzXv3I87GctOaTWVxQ5jUs, HhXl7ZE153jJeOWix0dvU2Gq=None, DtzW0B4cmRrL17ue2CpS9xIKhVU=None, MBqiICgzRX5tYGEL3m17a=None):
		while (qfFZ5QSOedhUiK46N):
			qfFZ5QSOedhUiK46N-=C2jP0iLNGKnHu9xp(u"࠳ᚻ")
			if (BuoDzXv3I87GctOaTWVxQ5jUs[qfFZ5QSOedhUiK46N]): HgxuSOzyIjJGmDLCUw9AXsnqiYp1r = My7Dwqvs6bfGNSIgX.sub(BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠣ࡞࡟ࡦࠧᅐ") + WD4MOzm8pruh(qfFZ5QSOedhUiK46N, xhIMnjFbcKD) + YB5xyI7MaRslVpv(u"ࠤ࡟ࡠࡧࠨᅑ"),  BuoDzXv3I87GctOaTWVxQ5jUs[qfFZ5QSOedhUiK46N], HgxuSOzyIjJGmDLCUw9AXsnqiYp1r)
		return HgxuSOzyIjJGmDLCUw9AXsnqiYp1r
	s6Wmzn9rJg4hfpa = s6Wmzn9rJg4hfpa.split(BoWHNb9daQVCF16A(u"ࠪࢁ࠭࠭ᅒ"))[gItVahxL0w(u"࠴ᚼ")]
	s6Wmzn9rJg4hfpa = s6Wmzn9rJg4hfpa.rsplit(C2jP0iLNGKnHu9xp(u"ࠫࡸࡶ࡬ࡪࡶࠪᅓ"))[hhlbF1Sns5TrEN8QPCYmL4(u"࠴ᚽ")]+k5dztomYyN3H(u"ࠧࡹࡰ࡭࡫ࡷࠬࠬࢂࠧࠪࠫࠥᅔ")
	zTxDQ1bdOZ = eval(BoWHNb9daQVCF16A(u"࠭ࡵ࡯ࡲࡤࡧࡰ࠮ࠧᅕ")+s6Wmzn9rJg4hfpa,{k5dztomYyN3H(u"ࠧࡣࡣࡶࡩࡓ࠭ᅖ"):WD4MOzm8pruh,BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠨࡷࡱࡴࡦࡩ࡫ࠨᅗ"):aa2dxQWH7Dr8KjkNlA})
	return zTxDQ1bdOZ
def trYkjXDeo7J2M(qmr7vLh1EW,Wt2xizMpTmCZ4=sRth5giAQzWlEVm7JOX(u"ࠩࠪᅘ")):
	if Wt2xizMpTmCZ4==C2dgEDAKQGsvh(u"ࠪࡰࡴࡽࡥࡳࠩᅙ"): qmr7vLh1EW = My7Dwqvs6bfGNSIgX.sub(QynMHGWA0blfqTUdxRh5Jzi2t(u"ࡶ࡛ࠬࠫ࠱࠯࠼ࡅ࠲ࡠ࡝ࡼ࠴ࢀࠫᅚ"),lambda ggLti7Q4N3e2ql6: ggLti7Q4N3e2ql6.group(C2dgEDAKQGsvh(u"࠵ᚾ")).lower(),qmr7vLh1EW)
	elif Wt2xizMpTmCZ4==RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠬࡻࡰࡱࡧࡵࠫᅛ"): qmr7vLh1EW = My7Dwqvs6bfGNSIgX.sub(V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࡸࠧࠦ࡝࠳࠱࠾ࡧ࠭ࡻ࡟ࡾ࠶ࢂ࠭ᅜ"),lambda ggLti7Q4N3e2ql6: ggLti7Q4N3e2ql6.group(k5dztomYyN3H(u"࠶ᚿ")).upper(),qmr7vLh1EW)
	return qmr7vLh1EW
def NbOMplyJ89Vv1zHEt(Oyo3Rj7VFn0):
	tMRz609DulpCXGOJq,dduFgaz623 = UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࡊࡦࡲࡳࡦ៕"),UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࡊࡦࡲࡳࡦ៕")
	W9YiR1FGTdzO3jByXPA70D = LLuOT2NGmXvS4C1WRyod8sQtIhV70a.connect(VOtIzx9Mks5pl)
	W9YiR1FGTdzO3jByXPA70D.text_factory = str
	CCJpwYUsTN1cBIz5PH = W9YiR1FGTdzO3jByXPA70D.cursor()
	if len(Oyo3Rj7VFn0)==b05yftsZ6NYgIKP(u"࠱ᛀ"): RRB1l2GrSk64x = C2jP0iLNGKnHu9xp(u"ࠧࠩࠤࠪᅝ")+Oyo3Rj7VFn0[vvHpKfcqRnrFzjG(u"࠱ᛁ")]+C2dgEDAKQGsvh(u"ࠨࠤࠬࠫᅞ")
	else: RRB1l2GrSk64x = str(tuple(Oyo3Rj7VFn0))
	CCJpwYUsTN1cBIz5PH.execute(UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠩࡖࡉࡑࡋࡃࡕࠢࡤࡨࡩࡵ࡮ࡊࡆ࠯ࡩࡳࡧࡢ࡭ࡧࡧࠤࡋࡘࡏࡎࠢ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨࠥ࡝ࡈࡆࡔࡈࠤࡦࡪࡤࡰࡰࡌࡈࠥࡏࡎࠡࠩᅟ")+RRB1l2GrSk64x+UnWjVbo503mEMv9KF(u"ࠪࠤࡀ࠭ᅠ"))
	lKSnCUAjhE = CCJpwYUsTN1cBIz5PH.fetchall()
	nIH1hbpoGlZi3UPMrBf6djDFzsYNR = {}
	for Kczs71doMyLHwN in Oyo3Rj7VFn0: nIH1hbpoGlZi3UPMrBf6djDFzsYNR[Kczs71doMyLHwN] = (hhlbF1Sns5TrEN8QPCYmL4(u"ࡋࡧ࡬ࡴࡧ៖"),hhlbF1Sns5TrEN8QPCYmL4(u"ࡋࡧ࡬ࡴࡧ៖"))
	for Kczs71doMyLHwN,dduFgaz623 in lKSnCUAjhE:
		tMRz609DulpCXGOJq = jSu5Cg2Ub1OAkZVs8Yoz(u"࡚ࡲࡶࡧៗ")
		dduFgaz623 = dduFgaz623==UxS67uoGThbMwnfNRzy4gajLd23JH(u"࠳ᛂ")
		nIH1hbpoGlZi3UPMrBf6djDFzsYNR[Kczs71doMyLHwN] = (tMRz609DulpCXGOJq,dduFgaz623)
	W9YiR1FGTdzO3jByXPA70D.close()
	return nIH1hbpoGlZi3UPMrBf6djDFzsYNR
def anzmoyTgUd(ATaJM8UXj5kvWeLnP01):
	ft3e2JBKQVXWlFPjaMhkEqGxvDg = k5dztomYyN3H(u"ࠫࠬᅡ")
	if XXRtDhYvWb35qnLBxIri7ScNUks0.path.exists(ATaJM8UXj5kvWeLnP01):
		icrzLnv703mP = open(ATaJM8UXj5kvWeLnP01,RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠬࡸࡢࠨᅢ")).read()
		if BLz7m2RkNrxXQwy1cGAp: icrzLnv703mP = icrzLnv703mP.decode(NVS30xAdRFMIw1n9CislkE2(u"࠭ࡵࡵࡨ࠻ࠫᅣ"))
		JW5NrsknRSzoKbOlaUXyv6mu = dWsa2A0O4o5BYiqGXhyKEbM(C2jP0iLNGKnHu9xp(u"ࠧࡥ࡫ࡦࡸࠬᅤ"),icrzLnv703mP)
		if JW5NrsknRSzoKbOlaUXyv6mu:
			ft3e2JBKQVXWlFPjaMhkEqGxvDg = {}
			for bS0qeWcgmnV in JW5NrsknRSzoKbOlaUXyv6mu.keys():
				ft3e2JBKQVXWlFPjaMhkEqGxvDg[bS0qeWcgmnV] = []
				for o9mtNIkfug5ysUqlPTh in JW5NrsknRSzoKbOlaUXyv6mu[bS0qeWcgmnV]:
					EAdbsmyiqLtjhPlxG,gg37KuOokaYFs8qTiezZn1tJ4jLr6,qmr7vLh1EW,hT9FozLnDCgvPG0EXyJa7,QFrVYJkywEsXquMNz,z3z9QgENFk5eMYB4,QHDcUO2xtS4CmF,ezSE9fBuvT,yPoqtK3i7zHulhZJDWYsnLxvT0 = T6wRistc1SCo4hqObgumK(u"ࠨࠩᅥ"),BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠩࠪᅦ"),qbPw1d3KimF(u"ࠪࠫᅧ"),QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠫࠬᅨ"),LgpdP3UjFRnlX(u"ࠬ࠭ᅩ"),BoWHNb9daQVCF16A(u"࠭ࠧᅪ"),RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠧࠨᅫ"),WMkAjB1RgN7q(u"ࠨࠩᅬ"),gItVahxL0w(u"ࠩࠪᅭ")
					EAdbsmyiqLtjhPlxG = o9mtNIkfug5ysUqlPTh[UxS67uoGThbMwnfNRzy4gajLd23JH(u"࠳ᛃ")]
					gg37KuOokaYFs8qTiezZn1tJ4jLr6 = o9mtNIkfug5ysUqlPTh[YB5xyI7MaRslVpv(u"࠵ᛄ")]
					gg37KuOokaYFs8qTiezZn1tJ4jLr6 = GETmdevAqQ(gg37KuOokaYFs8qTiezZn1tJ4jLr6)
					qmr7vLh1EW = o9mtNIkfug5ysUqlPTh[k5dztomYyN3H(u"࠷ᛅ")]
					hT9FozLnDCgvPG0EXyJa7 = o9mtNIkfug5ysUqlPTh[NVS30xAdRFMIw1n9CislkE2(u"࠹ᛆ")]
					QFrVYJkywEsXquMNz = o9mtNIkfug5ysUqlPTh[v5EA6TqHX3s4jzBMk(u"࠴ᛇ")]
					z3z9QgENFk5eMYB4 = o9mtNIkfug5ysUqlPTh[hhlbF1Sns5TrEN8QPCYmL4(u"࠶ᛈ")]
					if len(o9mtNIkfug5ysUqlPTh)>sRth5giAQzWlEVm7JOX(u"࠸ᛉ"): QHDcUO2xtS4CmF = o9mtNIkfug5ysUqlPTh[sRth5giAQzWlEVm7JOX(u"࠸ᛉ")]
					if len(o9mtNIkfug5ysUqlPTh)>BmcLzCFjuIrZP5fwXH18aN6YS(u"࠺ᛊ"): ezSE9fBuvT = o9mtNIkfug5ysUqlPTh[BmcLzCFjuIrZP5fwXH18aN6YS(u"࠺ᛊ")]
					if len(o9mtNIkfug5ysUqlPTh)>FGDJwkEbTB5SoXujs3f(u"࠼ᛋ"): yPoqtK3i7zHulhZJDWYsnLxvT0 = o9mtNIkfug5ysUqlPTh[FGDJwkEbTB5SoXujs3f(u"࠼ᛋ")]
					if ATaJM8UXj5kvWeLnP01==Z7A1STpeQGVJ: AXQwLBYjHJSRW43hbTca = EAdbsmyiqLtjhPlxG,gg37KuOokaYFs8qTiezZn1tJ4jLr6,qmr7vLh1EW,hT9FozLnDCgvPG0EXyJa7,QFrVYJkywEsXquMNz,z3z9QgENFk5eMYB4,QHDcUO2xtS4CmF,nr5mZG89ICi6cgt4MfLJa0(u"ࠪࠫᅮ"),yPoqtK3i7zHulhZJDWYsnLxvT0
					else: AXQwLBYjHJSRW43hbTca = EAdbsmyiqLtjhPlxG,gg37KuOokaYFs8qTiezZn1tJ4jLr6,qmr7vLh1EW,hT9FozLnDCgvPG0EXyJa7,QFrVYJkywEsXquMNz,z3z9QgENFk5eMYB4,QHDcUO2xtS4CmF,ezSE9fBuvT,yPoqtK3i7zHulhZJDWYsnLxvT0
					ft3e2JBKQVXWlFPjaMhkEqGxvDg[bS0qeWcgmnV].append(AXQwLBYjHJSRW43hbTca)
		FtZSrKTsDbx2Jh5nM487WfXil0ON6a = str(ft3e2JBKQVXWlFPjaMhkEqGxvDg)
		if BLz7m2RkNrxXQwy1cGAp: FtZSrKTsDbx2Jh5nM487WfXil0ON6a = FtZSrKTsDbx2Jh5nM487WfXil0ON6a.encode(UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠫࡺࡺࡦ࠹ࠩᅯ"))
		open(ATaJM8UXj5kvWeLnP01,BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠬࡽࡢࠨᅰ")).write(FtZSrKTsDbx2Jh5nM487WfXil0ON6a)
	return ft3e2JBKQVXWlFPjaMhkEqGxvDg
def RB0138fEQHwDFGn(bo1dqzR8JIwlThvDcyU4jf):
	GxyUjfHswTrNiBE5tI = bo1dqzR8JIwlThvDcyU4jf.split(T6wRistc1SCo4hqObgumK(u"࠭࠭ࠨᅱ"),EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠶ᛌ"))[jx7s8T0BFgODXLMzIYedf(u"࠶ᛍ")]
	JoakAQ4uiT5,dZT40j7heA1zsu3Nak,rrFcwfjUW34gaDKp2mHNB58Azbs = NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠧࠨᅲ"),l0WAe1f7Bpi5ZXk(u"ࠨࠩᅳ"),LgpdP3UjFRnlX(u"ࠩࠪᅴ")
	if   GxyUjfHswTrNiBE5tI==C2dgEDAKQGsvh(u"ࠪࡅࡍ࡝ࡁࡌࠩᅵ")		:	from OQb7Na9162			import eN02L7Tf5bQ as JoakAQ4uiT5,HjZcUIVAXFCqy9TfBWKtgY2 as dZT40j7heA1zsu3Nak,teUPLFC3B8bArakwHVGsdhoIWDM49f as rrFcwfjUW34gaDKp2mHNB58Azbs
	elif GxyUjfHswTrNiBE5tI==YB5xyI7MaRslVpv(u"ࠫࡆࡑࡏࡂࡏࠪᅶ")		:	from qS2COlbni0			import eN02L7Tf5bQ as JoakAQ4uiT5,HjZcUIVAXFCqy9TfBWKtgY2 as dZT40j7heA1zsu3Nak,teUPLFC3B8bArakwHVGsdhoIWDM49f as rrFcwfjUW34gaDKp2mHNB58Azbs
	elif GxyUjfHswTrNiBE5tI==C2dgEDAKQGsvh(u"ࠬࡇࡋࡐࡃࡐࡇࡆࡓࠧᅷ")	:	from kkm9QT8Kbn		import eN02L7Tf5bQ as JoakAQ4uiT5,HjZcUIVAXFCqy9TfBWKtgY2 as dZT40j7heA1zsu3Nak,teUPLFC3B8bArakwHVGsdhoIWDM49f as rrFcwfjUW34gaDKp2mHNB58Azbs
	elif GxyUjfHswTrNiBE5tI==QynMHGWA0blfqTUdxRh5Jzi2t(u"࠭ࡁࡌ࡙ࡄࡑࠬᅸ")		:	from AHyTtY8FEJ			import eN02L7Tf5bQ as JoakAQ4uiT5,HjZcUIVAXFCqy9TfBWKtgY2 as dZT40j7heA1zsu3Nak,teUPLFC3B8bArakwHVGsdhoIWDM49f as rrFcwfjUW34gaDKp2mHNB58Azbs
	elif GxyUjfHswTrNiBE5tI==b05yftsZ6NYgIKP(u"ࠧࡂࡎࡄࡖࡆࡈࠧᅹ")	:	from m2biKLFy9j			import eN02L7Tf5bQ as JoakAQ4uiT5,HjZcUIVAXFCqy9TfBWKtgY2 as dZT40j7heA1zsu3Nak,teUPLFC3B8bArakwHVGsdhoIWDM49f as rrFcwfjUW34gaDKp2mHNB58Azbs
	elif GxyUjfHswTrNiBE5tI==LgpdP3UjFRnlX(u"ࠨࡃࡏࡊࡆ࡚ࡉࡎࡋࠪᅺ")	:	from oy2gMwbCnW		import eN02L7Tf5bQ as JoakAQ4uiT5,HjZcUIVAXFCqy9TfBWKtgY2 as dZT40j7heA1zsu3Nak,teUPLFC3B8bArakwHVGsdhoIWDM49f as rrFcwfjUW34gaDKp2mHNB58Azbs
	elif GxyUjfHswTrNiBE5tI==BoWHNb9daQVCF16A(u"ࠩࡄࡐࡐࡇࡗࡕࡊࡄࡖࠬᅻ")	: 	from PFEHN9up2j		import eN02L7Tf5bQ as JoakAQ4uiT5,HjZcUIVAXFCqy9TfBWKtgY2 as dZT40j7heA1zsu3Nak,teUPLFC3B8bArakwHVGsdhoIWDM49f as rrFcwfjUW34gaDKp2mHNB58Azbs
	elif GxyUjfHswTrNiBE5tI==T6wRistc1SCo4hqObgumK(u"ࠪࡅࡑࡓࡁࡂࡔࡈࡊࠬᅼ")	:	from euTyFV9CtL		import eN02L7Tf5bQ as JoakAQ4uiT5,HjZcUIVAXFCqy9TfBWKtgY2 as dZT40j7heA1zsu3Nak,teUPLFC3B8bArakwHVGsdhoIWDM49f as rrFcwfjUW34gaDKp2mHNB58Azbs
	elif GxyUjfHswTrNiBE5tI==gItVahxL0w(u"ࠫࡆࡘࡁࡃࡋࡆࡘࡔࡕࡎࡔࠩᅽ"):	from ka4bKidFX0	import eN02L7Tf5bQ as JoakAQ4uiT5,HjZcUIVAXFCqy9TfBWKtgY2 as dZT40j7heA1zsu3Nak,teUPLFC3B8bArakwHVGsdhoIWDM49f as rrFcwfjUW34gaDKp2mHNB58Azbs
	elif GxyUjfHswTrNiBE5tI==gItVahxL0w(u"ࠬࡇࡒࡂࡄࡖࡉࡊࡊࠧᅾ")	:	from YTJnkQy0SN		import eN02L7Tf5bQ as JoakAQ4uiT5,HjZcUIVAXFCqy9TfBWKtgY2 as dZT40j7heA1zsu3Nak,teUPLFC3B8bArakwHVGsdhoIWDM49f as rrFcwfjUW34gaDKp2mHNB58Azbs
	elif GxyUjfHswTrNiBE5tI==rbjsM8cRFiuA1(u"࠭ࡂࡐࡍࡕࡅࠬᅿ")		:	from KwC3gyFDv4			import eN02L7Tf5bQ as JoakAQ4uiT5,HjZcUIVAXFCqy9TfBWKtgY2 as dZT40j7heA1zsu3Nak,teUPLFC3B8bArakwHVGsdhoIWDM49f as rrFcwfjUW34gaDKp2mHNB58Azbs
	elif GxyUjfHswTrNiBE5tI==UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠧࡃࡔࡖࡘࡊࡐࠧᆀ")	:	from t7ln5dkPDA			import eN02L7Tf5bQ as JoakAQ4uiT5,HjZcUIVAXFCqy9TfBWKtgY2 as dZT40j7heA1zsu3Nak,teUPLFC3B8bArakwHVGsdhoIWDM49f as rrFcwfjUW34gaDKp2mHNB58Azbs
	elif GxyUjfHswTrNiBE5tI==UnWjVbo503mEMv9KF(u"ࠨࡅࡌࡑࡆ࠺࠰࠱ࠩᆁ")	:	from H51bOV6EjZ		import eN02L7Tf5bQ as JoakAQ4uiT5,HjZcUIVAXFCqy9TfBWKtgY2 as dZT40j7heA1zsu3Nak,teUPLFC3B8bArakwHVGsdhoIWDM49f as rrFcwfjUW34gaDKp2mHNB58Azbs
	elif GxyUjfHswTrNiBE5tI==gItVahxL0w(u"ࠩࡆࡍࡒࡇ࠴ࡖࠩᆂ")	:	from RGB6zqroux			import eN02L7Tf5bQ as JoakAQ4uiT5,HjZcUIVAXFCqy9TfBWKtgY2 as dZT40j7heA1zsu3Nak,teUPLFC3B8bArakwHVGsdhoIWDM49f as rrFcwfjUW34gaDKp2mHNB58Azbs
	elif GxyUjfHswTrNiBE5tI==QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠪࡇࡎࡓࡁࡂࡄࡇࡓࠬᆃ")	:	from lMz5pnymV7		import eN02L7Tf5bQ as JoakAQ4uiT5,HjZcUIVAXFCqy9TfBWKtgY2 as dZT40j7heA1zsu3Nak,teUPLFC3B8bArakwHVGsdhoIWDM49f as rrFcwfjUW34gaDKp2mHNB58Azbs
	elif GxyUjfHswTrNiBE5tI==nr5mZG89ICi6cgt4MfLJa0(u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࡝ࡏࡓࡍࠪᆄ"):	from JJrykEjtmX	import eN02L7Tf5bQ as JoakAQ4uiT5,HjZcUIVAXFCqy9TfBWKtgY2 as dZT40j7heA1zsu3Nak,teUPLFC3B8bArakwHVGsdhoIWDM49f as rrFcwfjUW34gaDKp2mHNB58Azbs
	elif GxyUjfHswTrNiBE5tI==C2dgEDAKQGsvh(u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡈࠧᆅ"):		from j7ZSy5oc1m		import eN02L7Tf5bQ as JoakAQ4uiT5,HjZcUIVAXFCqy9TfBWKtgY2 as dZT40j7heA1zsu3Nak,teUPLFC3B8bArakwHVGsdhoIWDM49f as rrFcwfjUW34gaDKp2mHNB58Azbs
	elif GxyUjfHswTrNiBE5tI==k5dztomYyN3H(u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡐࠨᆆ")	:	from RcVUhTGuSn		import eN02L7Tf5bQ as JoakAQ4uiT5,HjZcUIVAXFCqy9TfBWKtgY2 as dZT40j7heA1zsu3Nak,teUPLFC3B8bArakwHVGsdhoIWDM49f as rrFcwfjUW34gaDKp2mHNB58Azbs
	elif GxyUjfHswTrNiBE5tI==BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠧࡄࡋࡐࡅࡋࡇࡎࡔࠩᆇ")	:	from U3fWvysXri		import eN02L7Tf5bQ as JoakAQ4uiT5,HjZcUIVAXFCqy9TfBWKtgY2 as dZT40j7heA1zsu3Nak,teUPLFC3B8bArakwHVGsdhoIWDM49f as rrFcwfjUW34gaDKp2mHNB58Azbs
	elif GxyUjfHswTrNiBE5tI==qbPw1d3KimF(u"ࠨࡅࡌࡑࡆࡒࡉࡈࡊࡗࠫᆈ")	:	from BkeL3UtRAW		import eN02L7Tf5bQ as JoakAQ4uiT5,HjZcUIVAXFCqy9TfBWKtgY2 as dZT40j7heA1zsu3Nak,teUPLFC3B8bArakwHVGsdhoIWDM49f as rrFcwfjUW34gaDKp2mHNB58Azbs
	elif GxyUjfHswTrNiBE5tI==gItVahxL0w(u"ࠩࡆࡍࡒࡇࡎࡐ࡙ࠪᆉ")	:	from nb2dEKuRFN		import eN02L7Tf5bQ as JoakAQ4uiT5,HjZcUIVAXFCqy9TfBWKtgY2 as dZT40j7heA1zsu3Nak,teUPLFC3B8bArakwHVGsdhoIWDM49f as rrFcwfjUW34gaDKp2mHNB58Azbs
	elif GxyUjfHswTrNiBE5tI==b05yftsZ6NYgIKP(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎࠨᆊ"):	from fDYtH3JzIi	import eN02L7Tf5bQ as JoakAQ4uiT5,HjZcUIVAXFCqy9TfBWKtgY2 as dZT40j7heA1zsu3Nak,teUPLFC3B8bArakwHVGsdhoIWDM49f as rrFcwfjUW34gaDKp2mHNB58Azbs
	elif GxyUjfHswTrNiBE5tI==v5EA6TqHX3s4jzBMk(u"ࠫࡉࡘࡁࡎࡃࡖ࠻ࠬᆋ")	:	from APs8IgpkVw		import eN02L7Tf5bQ as JoakAQ4uiT5,HjZcUIVAXFCqy9TfBWKtgY2 as dZT40j7heA1zsu3Nak,teUPLFC3B8bArakwHVGsdhoIWDM49f as rrFcwfjUW34gaDKp2mHNB58Azbs
	elif GxyUjfHswTrNiBE5tI==WMkAjB1RgN7q(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠭ᆌ")	:	from Uyd9BOm3hq		import eN02L7Tf5bQ as JoakAQ4uiT5,HjZcUIVAXFCqy9TfBWKtgY2 as dZT40j7heA1zsu3Nak,teUPLFC3B8bArakwHVGsdhoIWDM49f as rrFcwfjUW34gaDKp2mHNB58Azbs
	elif GxyUjfHswTrNiBE5tI==C2dgEDAKQGsvh(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠱ࠨᆍ")	:	from iFbpAPx1an		import eN02L7Tf5bQ as JoakAQ4uiT5,HjZcUIVAXFCqy9TfBWKtgY2 as dZT40j7heA1zsu3Nak,teUPLFC3B8bArakwHVGsdhoIWDM49f as rrFcwfjUW34gaDKp2mHNB58Azbs
	elif GxyUjfHswTrNiBE5tI==QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠳ࠩᆎ")	:	from UgSz2QtnM0		import eN02L7Tf5bQ as JoakAQ4uiT5,HjZcUIVAXFCqy9TfBWKtgY2 as dZT40j7heA1zsu3Nak,teUPLFC3B8bArakwHVGsdhoIWDM49f as rrFcwfjUW34gaDKp2mHNB58Azbs
	elif GxyUjfHswTrNiBE5tI==rbjsM8cRFiuA1(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠵ࠪᆏ")	:	from LLWVaQmdit		import eN02L7Tf5bQ as JoakAQ4uiT5,HjZcUIVAXFCqy9TfBWKtgY2 as dZT40j7heA1zsu3Nak,teUPLFC3B8bArakwHVGsdhoIWDM49f as rrFcwfjUW34gaDKp2mHNB58Azbs
	elif GxyUjfHswTrNiBE5tI==C2dgEDAKQGsvh(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠷ࠫᆐ")	:	from WPFZdiEaz2		import eN02L7Tf5bQ as JoakAQ4uiT5,HjZcUIVAXFCqy9TfBWKtgY2 as dZT40j7heA1zsu3Nak,teUPLFC3B8bArakwHVGsdhoIWDM49f as rrFcwfjUW34gaDKp2mHNB58Azbs
	elif GxyUjfHswTrNiBE5tI==FGDJwkEbTB5SoXujs3f(u"ࠪࡉࡌ࡟ࡄࡆࡃࡇࠫᆑ")	:	from thnVAoRm7i		import eN02L7Tf5bQ as JoakAQ4uiT5,HjZcUIVAXFCqy9TfBWKtgY2 as dZT40j7heA1zsu3Nak,teUPLFC3B8bArakwHVGsdhoIWDM49f as rrFcwfjUW34gaDKp2mHNB58Azbs
	elif GxyUjfHswTrNiBE5tI==jSu5Cg2Ub1OAkZVs8Yoz(u"ࠫࡊࡍ࡙ࡏࡑ࡚ࠫᆒ")	:	from RUXamQHCMN			import eN02L7Tf5bQ as JoakAQ4uiT5,HjZcUIVAXFCqy9TfBWKtgY2 as dZT40j7heA1zsu3Nak,teUPLFC3B8bArakwHVGsdhoIWDM49f as rrFcwfjUW34gaDKp2mHNB58Azbs
	elif GxyUjfHswTrNiBE5tI==BoWHNb9daQVCF16A(u"ࠬࡌࡁࡃࡔࡄࡏࡆ࠭ᆓ")	:	from ydRc0bjKop		import eN02L7Tf5bQ as JoakAQ4uiT5,HjZcUIVAXFCqy9TfBWKtgY2 as dZT40j7heA1zsu3Nak,teUPLFC3B8bArakwHVGsdhoIWDM49f as rrFcwfjUW34gaDKp2mHNB58Azbs
	elif GxyUjfHswTrNiBE5tI==k5dztomYyN3H(u"࠭ࡆࡂࡌࡈࡖࡘࡎࡏࡘࠩᆔ")	:	from FrmEf52pT4		import eN02L7Tf5bQ as JoakAQ4uiT5,HjZcUIVAXFCqy9TfBWKtgY2 as dZT40j7heA1zsu3Nak,teUPLFC3B8bArakwHVGsdhoIWDM49f as rrFcwfjUW34gaDKp2mHNB58Azbs
	elif GxyUjfHswTrNiBE5tI==b05yftsZ6NYgIKP(u"ࠧࡇࡃࡖࡉࡑࡎࡄ࠲ࠩᆕ")	:	from NNuy3mrgVF		import eN02L7Tf5bQ as JoakAQ4uiT5,HjZcUIVAXFCqy9TfBWKtgY2 as dZT40j7heA1zsu3Nak,teUPLFC3B8bArakwHVGsdhoIWDM49f as rrFcwfjUW34gaDKp2mHNB58Azbs
	elif GxyUjfHswTrNiBE5tI==rbjsM8cRFiuA1(u"ࠨࡈࡄࡗࡊࡒࡈࡅ࠴ࠪᆖ")	:	from En3hKe5PRa		import eN02L7Tf5bQ as JoakAQ4uiT5,HjZcUIVAXFCqy9TfBWKtgY2 as dZT40j7heA1zsu3Nak,teUPLFC3B8bArakwHVGsdhoIWDM49f as rrFcwfjUW34gaDKp2mHNB58Azbs
	elif GxyUjfHswTrNiBE5tI==nr5mZG89ICi6cgt4MfLJa0(u"ࠩࡉࡓࡘ࡚ࡁࠨᆗ")		:	from B2nUyjObRW			import eN02L7Tf5bQ as JoakAQ4uiT5,HjZcUIVAXFCqy9TfBWKtgY2 as dZT40j7heA1zsu3Nak,teUPLFC3B8bArakwHVGsdhoIWDM49f as rrFcwfjUW34gaDKp2mHNB58Azbs
	elif GxyUjfHswTrNiBE5tI==gItVahxL0w(u"ࠪࡌࡆࡒࡁࡄࡋࡐࡅࠬᆘ")	:	from nSvp1c7TaC		import eN02L7Tf5bQ as JoakAQ4uiT5,HjZcUIVAXFCqy9TfBWKtgY2 as dZT40j7heA1zsu3Nak,teUPLFC3B8bArakwHVGsdhoIWDM49f as rrFcwfjUW34gaDKp2mHNB58Azbs
	elif GxyUjfHswTrNiBE5tI==gItVahxL0w(u"ࠫࡎࡌࡉࡍࡏࠪᆙ")		:	from wwcbEpKRoJ			import eN02L7Tf5bQ as JoakAQ4uiT5,HjZcUIVAXFCqy9TfBWKtgY2 as dZT40j7heA1zsu3Nak,teUPLFC3B8bArakwHVGsdhoIWDM49f as rrFcwfjUW34gaDKp2mHNB58Azbs
	elif GxyUjfHswTrNiBE5tI==LgpdP3UjFRnlX(u"ࠬࡏࡐࡕࡘࠪᆚ")		:	from OJR51gj7FS	import X8BnqH7u1wJkIvPaQ5zlp6cfoVMW2N as JoakAQ4uiT5,aMRpBNWSu05t as dZT40j7heA1zsu3Nak,ggzjQfBhqdOYNE as rrFcwfjUW34gaDKp2mHNB58Azbs
	elif GxyUjfHswTrNiBE5tI==jSu5Cg2Ub1OAkZVs8Yoz(u"࠭ࡋࡂࡔࡅࡅࡑࡇࡔࡗࠩᆛ")	:	from eaC31XohSd		import eN02L7Tf5bQ as JoakAQ4uiT5,HjZcUIVAXFCqy9TfBWKtgY2 as dZT40j7heA1zsu3Nak,teUPLFC3B8bArakwHVGsdhoIWDM49f as rrFcwfjUW34gaDKp2mHNB58Azbs
	elif GxyUjfHswTrNiBE5tI==BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠧࡌࡃࡗࡏࡔ࡚ࡔࡗࠩᆜ")	:	from UUYFfLwvgu		import eN02L7Tf5bQ as JoakAQ4uiT5,HjZcUIVAXFCqy9TfBWKtgY2 as dZT40j7heA1zsu3Nak,teUPLFC3B8bArakwHVGsdhoIWDM49f as rrFcwfjUW34gaDKp2mHNB58Azbs
	elif GxyUjfHswTrNiBE5tI==C2jP0iLNGKnHu9xp(u"ࠨࡍࡄࡘࡐࡕࡕࡕࡇࠪᆝ")	:	from FeR60HQSEZ		import eN02L7Tf5bQ as JoakAQ4uiT5,HjZcUIVAXFCqy9TfBWKtgY2 as dZT40j7heA1zsu3Nak,teUPLFC3B8bArakwHVGsdhoIWDM49f as rrFcwfjUW34gaDKp2mHNB58Azbs
	elif GxyUjfHswTrNiBE5tI==BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠩࡏࡅࡗࡕ࡚ࡂࠩᆞ")	:	from YumHoLDAij			import eN02L7Tf5bQ as JoakAQ4uiT5,HjZcUIVAXFCqy9TfBWKtgY2 as dZT40j7heA1zsu3Nak,teUPLFC3B8bArakwHVGsdhoIWDM49f as rrFcwfjUW34gaDKp2mHNB58Azbs
	elif GxyUjfHswTrNiBE5tI==V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠪࡐࡔࡊ࡙ࡏࡇࡗࠫᆟ")	:	from Ww2bf9n3X6		import eN02L7Tf5bQ as JoakAQ4uiT5,HjZcUIVAXFCqy9TfBWKtgY2 as dZT40j7heA1zsu3Nak,teUPLFC3B8bArakwHVGsdhoIWDM49f as rrFcwfjUW34gaDKp2mHNB58Azbs
	elif GxyUjfHswTrNiBE5tI==C2jP0iLNGKnHu9xp(u"ࠫࡒ࠹ࡕࠨᆠ")		:	from F9HnjCOwhi	import X8BnqH7u1wJkIvPaQ5zlp6cfoVMW2N as JoakAQ4uiT5,aMRpBNWSu05t as dZT40j7heA1zsu3Nak,ggzjQfBhqdOYNE as rrFcwfjUW34gaDKp2mHNB58Azbs
	elif GxyUjfHswTrNiBE5tI==gItVahxL0w(u"ࠬࡓࡏࡗࡕ࠷࡙ࠬᆡ")	:	from b5bJkOI4c8			import eN02L7Tf5bQ as JoakAQ4uiT5,HjZcUIVAXFCqy9TfBWKtgY2 as dZT40j7heA1zsu3Nak,teUPLFC3B8bArakwHVGsdhoIWDM49f as rrFcwfjUW34gaDKp2mHNB58Azbs
	elif GxyUjfHswTrNiBE5tI==jx7s8T0BFgODXLMzIYedf(u"࠭ࡍ࡚ࡅࡌࡑࡆ࠭ᆢ")	:	from xPDZYpvG74			import eN02L7Tf5bQ as JoakAQ4uiT5,HjZcUIVAXFCqy9TfBWKtgY2 as dZT40j7heA1zsu3Nak,teUPLFC3B8bArakwHVGsdhoIWDM49f as rrFcwfjUW34gaDKp2mHNB58Azbs
	elif GxyUjfHswTrNiBE5tI==C2jP0iLNGKnHu9xp(u"ࠧࡑࡃࡑࡉ࡙࠭ᆣ")		:	from mnvCWUE47k			import eN02L7Tf5bQ as JoakAQ4uiT5,HjZcUIVAXFCqy9TfBWKtgY2 as dZT40j7heA1zsu3Nak,teUPLFC3B8bArakwHVGsdhoIWDM49f as rrFcwfjUW34gaDKp2mHNB58Azbs
	elif GxyUjfHswTrNiBE5tI==RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠨࡕࡋࡅࡍࡏࡄ࠵ࡗࠪᆤ")	:	from XOVAKMYPIL		import eN02L7Tf5bQ as JoakAQ4uiT5,HjZcUIVAXFCqy9TfBWKtgY2 as dZT40j7heA1zsu3Nak,teUPLFC3B8bArakwHVGsdhoIWDM49f as rrFcwfjUW34gaDKp2mHNB58Azbs
	elif GxyUjfHswTrNiBE5tI==C2jP0iLNGKnHu9xp(u"ࠩࡖࡌࡆࡎࡉࡅࡐࡈ࡛ࡘ࠭ᆥ"):	from fzvqVB3ckA		import eN02L7Tf5bQ as JoakAQ4uiT5,HjZcUIVAXFCqy9TfBWKtgY2 as dZT40j7heA1zsu3Nak,teUPLFC3B8bArakwHVGsdhoIWDM49f as rrFcwfjUW34gaDKp2mHNB58Azbs
	elif GxyUjfHswTrNiBE5tI==rbjsM8cRFiuA1(u"ࠪࡗࡍࡏࡁࡗࡑࡌࡇࡊ࠭ᆦ")	:	from RRhb5T0SZN		import eN02L7Tf5bQ as JoakAQ4uiT5,HjZcUIVAXFCqy9TfBWKtgY2 as dZT40j7heA1zsu3Nak,teUPLFC3B8bArakwHVGsdhoIWDM49f as rrFcwfjUW34gaDKp2mHNB58Azbs
	elif GxyUjfHswTrNiBE5tI==LgpdP3UjFRnlX(u"ࠫࡘࡎࡏࡇࡊࡄࠫᆧ")	:	from YvWs3LpDg8			import eN02L7Tf5bQ as JoakAQ4uiT5,HjZcUIVAXFCqy9TfBWKtgY2 as dZT40j7heA1zsu3Nak,teUPLFC3B8bArakwHVGsdhoIWDM49f as rrFcwfjUW34gaDKp2mHNB58Azbs
	elif GxyUjfHswTrNiBE5tI==T6wRistc1SCo4hqObgumK(u"࡙ࠬࡈࡐࡑࡉࡑࡆ࡞ࠧᆨ")	:	from ssOuZYjF2h		import eN02L7Tf5bQ as JoakAQ4uiT5,HjZcUIVAXFCqy9TfBWKtgY2 as dZT40j7heA1zsu3Nak,teUPLFC3B8bArakwHVGsdhoIWDM49f as rrFcwfjUW34gaDKp2mHNB58Azbs
	elif GxyUjfHswTrNiBE5tI==vvHpKfcqRnrFzjG(u"࠭ࡓࡉࡑࡒࡊࡕࡘࡏࠨᆩ")	:	from V5PYLF4G6Q		import eN02L7Tf5bQ as JoakAQ4uiT5,HjZcUIVAXFCqy9TfBWKtgY2 as dZT40j7heA1zsu3Nak,teUPLFC3B8bArakwHVGsdhoIWDM49f as rrFcwfjUW34gaDKp2mHNB58Azbs
	elif GxyUjfHswTrNiBE5tI==FGDJwkEbTB5SoXujs3f(u"ࠧࡕࡘࡉ࡙ࡓ࠭ᆪ")		:	from jNaYJCozPl			import eN02L7Tf5bQ as JoakAQ4uiT5,HjZcUIVAXFCqy9TfBWKtgY2 as dZT40j7heA1zsu3Nak,teUPLFC3B8bArakwHVGsdhoIWDM49f as rrFcwfjUW34gaDKp2mHNB58Azbs
	elif GxyUjfHswTrNiBE5tI==LgpdP3UjFRnlX(u"ࠨ࡙ࡈࡇࡎࡓࡁࠨᆫ")	:	from qbHfJWnrKv			import eN02L7Tf5bQ as JoakAQ4uiT5,HjZcUIVAXFCqy9TfBWKtgY2 as dZT40j7heA1zsu3Nak,teUPLFC3B8bArakwHVGsdhoIWDM49f as rrFcwfjUW34gaDKp2mHNB58Azbs
	elif GxyUjfHswTrNiBE5tI==l0WAe1f7Bpi5ZXk(u"ࠩ࡜ࡅࡖࡕࡔࠨᆬ")		:	from A28AzUCctK			import eN02L7Tf5bQ as JoakAQ4uiT5,HjZcUIVAXFCqy9TfBWKtgY2 as dZT40j7heA1zsu3Nak,teUPLFC3B8bArakwHVGsdhoIWDM49f as rrFcwfjUW34gaDKp2mHNB58Azbs
	elif GxyUjfHswTrNiBE5tI==EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫᆭ")	:	from yy16g9xBYs		import eN02L7Tf5bQ as JoakAQ4uiT5,HjZcUIVAXFCqy9TfBWKtgY2 as dZT40j7heA1zsu3Nak,teUPLFC3B8bArakwHVGsdhoIWDM49f as rrFcwfjUW34gaDKp2mHNB58Azbs
	elif GxyUjfHswTrNiBE5tI==FGDJwkEbTB5SoXujs3f(u"ࠫ࡞࡚ࡂࡠࡅࡋࡅࡓࡔࡅࡍࡕࠪᆮ"):	from PUApVYoKJq	import eN02L7Tf5bQ as JoakAQ4uiT5
	return JoakAQ4uiT5,dZT40j7heA1zsu3Nak,rrFcwfjUW34gaDKp2mHNB58Azbs
def PKwAyEMig2N6eb(G6HzqxPk7e4JaFj8WOmfv,ib6URTIJnFlgVwXsQAN0ZGD4k9c3ph,showDialogs):
	Lmj1pfQk63XdoeH(l0WAe1f7Bpi5ZXk(u"ࠬࡔࡏࡕࡋࡆࡉࠬᆯ"),k5dztomYyN3H(u"࠭࠮ࠡࠢࡇࡳࡼࡴ࡬ࡰࡣࡧ࡭ࡳ࡭࠺ࠡ࡝ࠣࠫᆰ")+G6HzqxPk7e4JaFj8WOmfv+b05yftsZ6NYgIKP(u"ࠧࠡ࡟ࠣࠤࠥࡎࡥࡢࡦࡨࡶࡸࡀࠠ࡜ࠢࠪᆱ")+str(ib6URTIJnFlgVwXsQAN0ZGD4k9c3ph)+C2jP0iLNGKnHu9xp(u"ࠨࠢࡠࠫᆲ"))
	hensWGjium8DSy3aVQEOdR95t = YYAhEtvLi5CnyHxIjJled3wWTO()
	hensWGjium8DSy3aVQEOdR95t.create(EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬᆳ"),C2dgEDAKQGsvh(u"ࠪ๎ัื๊ࠡษ็ฦ๋ࠦแฮืࠣห้๋ไโࠢส่๊฽ไ้สࠣฮา๋๊ๅ้ࠣ์อ฿ฯ่ษࠣืํ็ࠠหสาวࠥ฿ๅๅ์ฬࠤั๊ศࠡษ็้้็ࠠๆ่ࠣห้หๆหำ้ฮࠬᆴ"))
	dCyLYDlUz6WwrkEIxuRj = QynMHGWA0blfqTUdxRh5Jzi2t(u"࠱࠱࠴࠷ᛎ")*QynMHGWA0blfqTUdxRh5Jzi2t(u"࠱࠱࠴࠷ᛎ")
	RdyJnkPxTLtS = NVS30xAdRFMIw1n9CislkE2(u"࠲ᛏ")*dCyLYDlUz6WwrkEIxuRj
	UMNteoHlkEy3Yf = jYUlINd7Vk09LBeZFrunTaSgG.get(G6HzqxPk7e4JaFj8WOmfv,stream=PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࡔࡳࡷࡨ៘"),headers=ib6URTIJnFlgVwXsQAN0ZGD4k9c3ph)
	KUvHMtV3i5yN28uT = UMNteoHlkEy3Yf.headers
	UMNteoHlkEy3Yf.close()
	Mu4jPZ5F62hf93Yp = bytes()
	if not KUvHMtV3i5yN28uT:
		if showDialogs: ZIOHgA3z0TBR(l0WAe1f7Bpi5ZXk(u"ࠫࠬᆵ"),T6wRistc1SCo4hqObgumK(u"ࠬ࠭ᆶ"),PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᆷ"),vvHpKfcqRnrFzjG(u"ࠧศๆหี๋อๅอࠢ็้ࠥ๐สๆๅ้ࠤ๊์ࠠหฯ่๎้ࠦวๅ็็ๅࠥอไๆู็์อ่ࠦศๆึฬอࠦโะࠢํ็ํ์ฺ่ࠠา็๋ࠥิไๆฬࠤๆ๐ࠠศๆศ๊ฯืๆหࠢส่ำอีࠡสๆࠤ࠳ࠦฬาสࠣฮา๋๊ๅࠢส่๊๊แࠡ็ิอࠥษฮา๋ࠪᆸ"))
		hensWGjium8DSy3aVQEOdR95t.close()
	else:
		if nr5mZG89ICi6cgt4MfLJa0(u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡏࡩࡳ࡭ࡴࡩࠩᆹ") not in list(KUvHMtV3i5yN28uT.keys()): IK5fGtena0wOLJq7MyDAUBmv = C2dgEDAKQGsvh(u"࠲ᛐ")
		else: IK5fGtena0wOLJq7MyDAUBmv = int(KUvHMtV3i5yN28uT[EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡐࡪࡴࡧࡵࡪࠪᆺ")])
		JnHuUOtVDhkXziPWj8YIRr = str(int(WMkAjB1RgN7q(u"࠵࠵࠶࠰ᛒ")*IK5fGtena0wOLJq7MyDAUBmv/dCyLYDlUz6WwrkEIxuRj)/gItVahxL0w(u"࠴࠴࠵࠶࠮࠱ᛑ"))
		uUTvk6wEFlXW = int(IK5fGtena0wOLJq7MyDAUBmv/RdyJnkPxTLtS)+fY5wTlhtnOc0Er6sdy4k87b(u"࠶ᛓ")
		if jSu5Cg2Ub1OAkZVs8Yoz(u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱ࡗࡧ࡮ࡨࡧࠪᆻ") in list(KUvHMtV3i5yN28uT.keys()) and IK5fGtena0wOLJq7MyDAUBmv>dCyLYDlUz6WwrkEIxuRj:
			tte4c36B0gPudfqY = UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࡕࡴࡸࡩ៙")
			QJhoBTPIqWU = []
			QVlmM1Us8WThiY6Z = BoWHNb9daQVCF16A(u"࠷࠰ᛔ")
			QJhoBTPIqWU.append(str(hhlbF1Sns5TrEN8QPCYmL4(u"࠱ᛖ")*IK5fGtena0wOLJq7MyDAUBmv//QVlmM1Us8WThiY6Z)+BoWHNb9daQVCF16A(u"ࠫ࠲࠭ᆼ")+str(jSu5Cg2Ub1OAkZVs8Yoz(u"࠱ᛕ")*IK5fGtena0wOLJq7MyDAUBmv//QVlmM1Us8WThiY6Z-jSu5Cg2Ub1OAkZVs8Yoz(u"࠱ᛕ")))
			QJhoBTPIqWU.append(str(BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠳ᛗ")*IK5fGtena0wOLJq7MyDAUBmv//QVlmM1Us8WThiY6Z)+RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠬ࠳ࠧᆽ")+str(NVS30xAdRFMIw1n9CislkE2(u"࠵ᛘ")*IK5fGtena0wOLJq7MyDAUBmv//QVlmM1Us8WThiY6Z-BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠳ᛗ")))
			QJhoBTPIqWU.append(str(QynMHGWA0blfqTUdxRh5Jzi2t(u"࠸ᛛ")*IK5fGtena0wOLJq7MyDAUBmv//QVlmM1Us8WThiY6Z)+sRth5giAQzWlEVm7JOX(u"࠭࠭ࠨᆾ")+str(C2dgEDAKQGsvh(u"࠸ᛚ")*IK5fGtena0wOLJq7MyDAUBmv//QVlmM1Us8WThiY6Z-BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠵ᛙ")))
			QJhoBTPIqWU.append(str(v5EA6TqHX3s4jzBMk(u"࠴ᛝ")*IK5fGtena0wOLJq7MyDAUBmv//QVlmM1Us8WThiY6Z)+BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠧ࠮ࠩᆿ")+str(fY5wTlhtnOc0Er6sdy4k87b(u"࠶ᛞ")*IK5fGtena0wOLJq7MyDAUBmv//QVlmM1Us8WThiY6Z-BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠱ᛜ")))
			QJhoBTPIqWU.append(str(BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠹ᛡ")*IK5fGtena0wOLJq7MyDAUBmv//QVlmM1Us8WThiY6Z)+jSu5Cg2Ub1OAkZVs8Yoz(u"ࠨ࠯ࠪᇀ")+str(jx7s8T0BFgODXLMzIYedf(u"࠹ᛠ")*IK5fGtena0wOLJq7MyDAUBmv//QVlmM1Us8WThiY6Z-UnWjVbo503mEMv9KF(u"࠴ᛟ")))
			QJhoBTPIqWU.append(str(l0WAe1f7Bpi5ZXk(u"࠵ᛣ")*IK5fGtena0wOLJq7MyDAUBmv//QVlmM1Us8WThiY6Z)+NVS30xAdRFMIw1n9CislkE2(u"ࠩ࠰ࠫᇁ")+str(C2dgEDAKQGsvh(u"࠷ᛤ")*IK5fGtena0wOLJq7MyDAUBmv//QVlmM1Us8WThiY6Z-vvHpKfcqRnrFzjG(u"࠷ᛢ")))
			QJhoBTPIqWU.append(str(BmcLzCFjuIrZP5fwXH18aN6YS(u"࠺ᛧ")*IK5fGtena0wOLJq7MyDAUBmv//QVlmM1Us8WThiY6Z)+BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠪ࠱ࠬᇂ")+str(rbjsM8cRFiuA1(u"࠺ᛦ")*IK5fGtena0wOLJq7MyDAUBmv//QVlmM1Us8WThiY6Z-qbPw1d3KimF(u"࠳ᛥ")))
			QJhoBTPIqWU.append(str(T6wRistc1SCo4hqObgumK(u"࠷ᛪ")*IK5fGtena0wOLJq7MyDAUBmv//QVlmM1Us8WThiY6Z)+UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠫ࠲࠭ᇃ")+str(gItVahxL0w(u"࠾ᛩ")*IK5fGtena0wOLJq7MyDAUBmv//QVlmM1Us8WThiY6Z-nr5mZG89ICi6cgt4MfLJa0(u"࠶ᛨ")))
			QJhoBTPIqWU.append(str(NVS30xAdRFMIw1n9CislkE2(u"࠺᛬")*IK5fGtena0wOLJq7MyDAUBmv//QVlmM1Us8WThiY6Z)+qbPw1d3KimF(u"ࠬ࠳ࠧᇄ")+str(YB5xyI7MaRslVpv(u"࠺᛫")*IK5fGtena0wOLJq7MyDAUBmv//QVlmM1Us8WThiY6Z-EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠴᛭")))
			QJhoBTPIqWU.append(str(nr5mZG89ICi6cgt4MfLJa0(u"࠽ᛮ")*IK5fGtena0wOLJq7MyDAUBmv//QVlmM1Us8WThiY6Z)+v5EA6TqHX3s4jzBMk(u"࠭࠭ࠨᇅ"))
			tDpULBzkI5 = float(uUTvk6wEFlXW)/QVlmM1Us8WThiY6Z
			OwT5Q0LcpZ = tDpULBzkI5/int(gItVahxL0w(u"࠶ᛯ")+tDpULBzkI5)
		else:
			tte4c36B0gPudfqY = jx7s8T0BFgODXLMzIYedf(u"ࡈࡤࡰࡸ࡫៚")
			QVlmM1Us8WThiY6Z = sRth5giAQzWlEVm7JOX(u"࠷ᛰ")
			OwT5Q0LcpZ = jx7s8T0BFgODXLMzIYedf(u"࠱ᛱ")
		Lmj1pfQk63XdoeH(BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠧࡏࡑࡗࡍࡈࡋࠧᇆ"),l0WAe1f7Bpi5ZXk(u"ࠨ࠰ࠣࠤࡉࡵࡷ࡯࡮ࡲࡥࡩࠦࡵࡴ࡫ࡱ࡫ࠥࡸࡡ࡯ࡩࡨࡷ࠿࡛ࠦࠡࠩᇇ")+str(tte4c36B0gPudfqY)+jx7s8T0BFgODXLMzIYedf(u"ࠩࠣࡡࠥࠦࠠࡅࡱࡺࡲࡱࡵࡡࡥࠢࡶ࡭ࡿ࡫࠺ࠡ࡝ࠣࠫᇈ")+str(IK5fGtena0wOLJq7MyDAUBmv)+b05yftsZ6NYgIKP(u"ࠪࠤࡢ࠭ᇉ"))
		k3Om08MCgqQao4n1,P9vUHwZfKuphl = C2dgEDAKQGsvh(u"࠱ᛲ"),C2dgEDAKQGsvh(u"࠱ᛲ")
		for nnzHUvw6s07xyEqXkuh5pR1Cj in range(QVlmM1Us8WThiY6Z):
			eIL9BxdTbZj = ib6URTIJnFlgVwXsQAN0ZGD4k9c3ph.copy()
			if tte4c36B0gPudfqY: eIL9BxdTbZj[WMkAjB1RgN7q(u"ࠫࡗࡧ࡮ࡨࡧࠪᇊ")] = UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠬࡨࡹࡵࡧࡶࡁࠬᇋ")+QJhoBTPIqWU[nnzHUvw6s07xyEqXkuh5pR1Cj]
			UMNteoHlkEy3Yf = jYUlINd7Vk09LBeZFrunTaSgG.get(G6HzqxPk7e4JaFj8WOmfv,stream=sRth5giAQzWlEVm7JOX(u"ࡗࡶࡺ࡫៛"),headers=eIL9BxdTbZj,timeout=V2RbfGOBdcA6l8NTsPWzEyvS7(u"࠵࠳࠴ᛳ"))
			for C3x157NmcFwQa4 in UMNteoHlkEy3Yf.iter_content(chunk_size=RdyJnkPxTLtS):
				if hensWGjium8DSy3aVQEOdR95t.iscanceled():
					Lmj1pfQk63XdoeH(EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠭ࡎࡐࡖࡌࡇࡊ࠭ᇌ"),UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠧ࠯ࠢࠣࡈࡴࡽ࡮࡭ࡱࡤࡨࠥࡉࡡ࡯ࡥࡨࡰࡪࡪࠧᇍ"))
					break
				k3Om08MCgqQao4n1 += OwT5Q0LcpZ
				Mu4jPZ5F62hf93Yp += C3x157NmcFwQa4
				if not P9vUHwZfKuphl: P9vUHwZfKuphl = len(C3x157NmcFwQa4)
				if IK5fGtena0wOLJq7MyDAUBmv: M3QI1bliHdj7poRFV2OG(hensWGjium8DSy3aVQEOdR95t,QynMHGWA0blfqTUdxRh5Jzi2t(u"࠴࠴࠵ᛴ")*k3Om08MCgqQao4n1//uUTvk6wEFlXW,T6wRistc1SCo4hqObgumK(u"ࠨฮ็ฬࠥอไๆๆไ࠾࠲ࠦวๅฮีลࠥืโๆࠩᇎ"),str(WMkAjB1RgN7q(u"࠵࠵࠶࠮࠱ᛵ")*P9vUHwZfKuphl*k3Om08MCgqQao4n1//RdyJnkPxTLtS//WMkAjB1RgN7q(u"࠵࠵࠶࠮࠱ᛵ"))+qbPw1d3KimF(u"ࠩࠣ࠳ࠥ࠭ᇏ")+JnHuUOtVDhkXziPWj8YIRr+C2dgEDAKQGsvh(u"ࠪࠤࡒࡈࠧᇐ"))
				else: M3QI1bliHdj7poRFV2OG(hensWGjium8DSy3aVQEOdR95t,P9vUHwZfKuphl*k3Om08MCgqQao4n1//RdyJnkPxTLtS,rbjsM8cRFiuA1(u"ࠫั๊ศࠡษ็้้็࠺࠮ࠩᇑ"),str(T6wRistc1SCo4hqObgumK(u"࠶࠶࠰࠯࠲ᛶ")*P9vUHwZfKuphl*k3Om08MCgqQao4n1//RdyJnkPxTLtS//T6wRistc1SCo4hqObgumK(u"࠶࠶࠰࠯࠲ᛶ"))+BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠬࠦࡍࡃࠩᇒ"))
			UMNteoHlkEy3Yf.close()
		hensWGjium8DSy3aVQEOdR95t.close()
		if len(Mu4jPZ5F62hf93Yp)<IK5fGtena0wOLJq7MyDAUBmv and IK5fGtena0wOLJq7MyDAUBmv>k5dztomYyN3H(u"࠶ᛷ"):
			Lmj1pfQk63XdoeH(UxS67uoGThbMwnfNRzy4gajLd23JH(u"࠭ࡎࡐࡖࡌࡇࡊ࠭ᇓ"),QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠧ࠯ࠢࠣࡈࡴࡽ࡮࡭ࡱࡤࡨࠥ࡬ࡡࡪ࡮ࡨࡨࠥࡵࡲࠡࡥࡤࡲࡨ࡫࡬ࡦࡦࠣࡥࡹࡀࠠ࡜ࠢࠪᇔ")+str(len(Mu4jPZ5F62hf93Yp)//dCyLYDlUz6WwrkEIxuRj)+l0WAe1f7Bpi5ZXk(u"ࠨࠢࡐࡆࠥࡣࠠࠡࠢࡉࡶࡴࡳࠠࡵࡱࡷࡥࡱࠦ࡯ࡧ࠼ࠣ࡟ࠥ࠭ᇕ")+JnHuUOtVDhkXziPWj8YIRr+PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠩࠣࡑࡇࠦ࡝ࠨᇖ"))
			D6LK2dzYZMco = Uu0ZdNAP1BWc28lR(BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠪࠫᇗ"),nr5mZG89ICi6cgt4MfLJa0(u"ࠫสฺ๊ศรࠣ์ำื่อࠩᇘ"),jSu5Cg2Ub1OAkZVs8Yoz(u"ࠬอำหะาห๊ࠦวๅ็็ๅࠥอไ็ษๅูࠬᇙ"),hhlbF1Sns5TrEN8QPCYmL4(u"࠭ลฺษาอࠥาไษࠢส่๊๊แࠨᇚ"),NVS30xAdRFMIw1n9CislkE2(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᇛ"),FGDJwkEbTB5SoXujs3f(u"ࠨใื่ࠥ็๊ࠡฮ็ฬࠥอไๆๆไࠤࡡࡴࠠๅๆฦืๆࠦอะอࠣา฼ษࠠโ์ࠣฮา๋๊ๅࠢส่๊๊แࠡ࡞ࡱࠤฯ๋ࠠอๆหࠤࠬᇜ")+str(len(Mu4jPZ5F62hf93Yp)//dCyLYDlUz6WwrkEIxuRj)+C2jP0iLNGKnHu9xp(u"้ࠩࠣ๏เวษษํฮ๋ࠥๆࠡ็ฯ้ํ฿ࠠࠨᇝ")+JnHuUOtVDhkXziPWj8YIRr+k5dztomYyN3H(u"ࠪࠤ๊๐ฺศสส๎ฯࠦ࡜࡯ࠢฯีอࠦฬๅสࠣห้๋ไโ่ࠢีฮࠦรฯำ์ࠤࡡࡴ่ࠠๆࠣฮึ๐ฯࠡษึฮำีวๆࠢส่๊๊แࠡษ็๊ฬ่ีࠡมࠤࠥࠬᇞ"))
			if D6LK2dzYZMco==sRth5giAQzWlEVm7JOX(u"࠲ᛸ"): Mu4jPZ5F62hf93Yp = PKwAyEMig2N6eb(G6HzqxPk7e4JaFj8WOmfv,ib6URTIJnFlgVwXsQAN0ZGD4k9c3ph,showDialogs)
			elif D6LK2dzYZMco==LgpdP3UjFRnlX(u"࠲᛹"): Lmj1pfQk63XdoeH(EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠫࡓࡕࡔࡊࡅࡈࠫᇟ"),V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠬ࠴ࠠࠡࡐࡲࡸࠥࡩ࡯࡮ࡲ࡯ࡩࡹ࡫ࡤࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࡨࡨࠥ࡬ࡩ࡭ࡧࠣ࡭ࡸࠦࡡࡤࡥࡨࡴࡹ࡫ࡤࠡࡣࡱࡨࠥࡽࡩ࡭࡮ࠣࡦࡪࠦࡵࡴࡧࡧࠫᇠ"))
			else: return QynMHGWA0blfqTUdxRh5Jzi2t(u"࠭ࠧᇡ")
			if not Mu4jPZ5F62hf93Yp: return nr5mZG89ICi6cgt4MfLJa0(u"ࠧࠨᇢ")
		else: Lmj1pfQk63XdoeH(WMkAjB1RgN7q(u"ࠨࡐࡒࡘࡎࡉࡅࠨᇣ"),l0WAe1f7Bpi5ZXk(u"ࠩ࠱ࠤࠥࡊ࡯ࡸࡰ࡯ࡳࡦࡪࠠࡔࡷࡦࡧࡪ࡫ࡤࡦࡦ࠱ࠤࠥࠦࡆࡪ࡮ࡨࠤࡘ࡯ࡺࡦ࠼ࠣ࡟ࠥ࠭ᇤ")+JnHuUOtVDhkXziPWj8YIRr+FGDJwkEbTB5SoXujs3f(u"ࠪࠤࡒࡈࠠ࡞ࠩᇥ"))
	return Mu4jPZ5F62hf93Yp
def s31yoBPpW4Cf(baNWS6nfqTC5iX4Kl):
	return UMNteoHlkEy3Yf
def xFP4v9DfhOV8yo(ip=C2dgEDAKQGsvh(u"ࠫࠬᇦ")):
	UXwK0QkvAiHptTe4bP1L5Za9JhlVxO,KTL7OP3spfChQm9n8UudYMDt,uaTX96nvZ2dHB7cNpW380xr,nqPT146ysDmR,SQ4FIH59BnJR3WqTiyGZhfMrkc,yews0quX8Wb3CkPYov = UnWjVbo503mEMv9KF(u"ࠬ࠭ᇧ"),nr5mZG89ICi6cgt4MfLJa0(u"࠭ࠧᇨ"),LgpdP3UjFRnlX(u"ࠧࠨᇩ"),NVS30xAdRFMIw1n9CislkE2(u"ࠨࠩᇪ"),rbjsM8cRFiuA1(u"ࠩࠪᇫ"),hhlbF1Sns5TrEN8QPCYmL4(u"ࠪࠫᇬ")
	qmr7vLh1EW = fY5wTlhtnOc0Er6sdy4k87b(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࡮ࡶࡷࡩࡱ࠱࡭ࡸ࠵ࠧᇭ")+ip+WMkAjB1RgN7q(u"ࠬࡅ࡯ࡶࡶࡳࡹࡹࡃࡪࡴࡱࡱࠪ࡫࡯ࡥ࡭ࡦࡶࡁ࡮ࡶࠬࡤࡱࡱࡸ࡮ࡴࡥ࡯ࡶ࠯ࡧࡴࡻ࡮ࡵࡴࡼ࠰ࡨࡵࡵ࡯ࡶࡵࡽࡤࡩ࡯ࡥࡧ࠯ࡶࡪ࡭ࡩࡰࡰ࠯ࡧ࡮ࡺࡹ࠭ࡶ࡬ࡱࡪࢀ࡯࡯ࡧࠪᇮ")
	ib6URTIJnFlgVwXsQAN0ZGD4k9c3ph = {jSu5Cg2Ub1OAkZVs8Yoz(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪᇯ"):jx7s8T0BFgODXLMzIYedf(u"ࠧࠨᇰ")}
	UMNteoHlkEy3Yf = mORwgTnXBdQ7iCSHKf(f9Oum6c0FotxYn,UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠨࡉࡈࡘࠬᇱ"),qmr7vLh1EW,BoWHNb9daQVCF16A(u"ࠩࠪᇲ"),ib6URTIJnFlgVwXsQAN0ZGD4k9c3ph,fY5wTlhtnOc0Er6sdy4k87b(u"ࠪࠫᇳ"),BoWHNb9daQVCF16A(u"ࠫࠬᇴ"),b05yftsZ6NYgIKP(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡆࡑࡏࡓࡈࡇࡔࡊࡑࡑ࠱࠶ࡹࡴࠨᇵ"))
	if not UMNteoHlkEy3Yf.succeeded: jZLmif48dFVOW1 = ip+jx7s8T0BFgODXLMzIYedf(u"࠭ࠬࠨᇶ")+UXwK0QkvAiHptTe4bP1L5Za9JhlVxO+nr5mZG89ICi6cgt4MfLJa0(u"ࠧ࠭ࠩᇷ")+KTL7OP3spfChQm9n8UudYMDt+WMkAjB1RgN7q(u"ࠨ࠮ࠪᇸ")+nqPT146ysDmR+C2dgEDAKQGsvh(u"ࠩ࠯ࠫᇹ")+SQ4FIH59BnJR3WqTiyGZhfMrkc+PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠪ࠰ࠬᇺ")+yews0quX8Wb3CkPYov
	else:
		qqThxfYXnogSpAiJ7GkcLz = UMNteoHlkEy3Yf.content
		qqThxfYXnogSpAiJ7GkcLz = My7Dwqvs6bfGNSIgX.findall(rbjsM8cRFiuA1(u"ࠫࡡࢁ࠮ࠫࡁ࡟ࢁࡡࢃࠧᇻ"),qqThxfYXnogSpAiJ7GkcLz,My7Dwqvs6bfGNSIgX.DOTALL)
		if qqThxfYXnogSpAiJ7GkcLz:
			qqThxfYXnogSpAiJ7GkcLz = qqThxfYXnogSpAiJ7GkcLz[jx7s8T0BFgODXLMzIYedf(u"࠲᛺")]
			iQbuc3OM06BwPnGpsa = dWsa2A0O4o5BYiqGXhyKEbM(YB5xyI7MaRslVpv(u"ࠬࡪࡩࡤࡶࠪᇼ"),qqThxfYXnogSpAiJ7GkcLz)
			NnbJWYvlRyFmU9 = list(iQbuc3OM06BwPnGpsa.keys())
			if jx7s8T0BFgODXLMzIYedf(u"࠭ࡩࡱࠩᇽ") in NnbJWYvlRyFmU9: ip = iQbuc3OM06BwPnGpsa[LgpdP3UjFRnlX(u"ࠧࡪࡲࠪᇾ")]
			if EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠨࡥࡲࡲࡹ࡯࡮ࡦࡰࡷࠫᇿ") in NnbJWYvlRyFmU9: UXwK0QkvAiHptTe4bP1L5Za9JhlVxO = iQbuc3OM06BwPnGpsa[T6wRistc1SCo4hqObgumK(u"ࠩࡦࡳࡳࡺࡩ࡯ࡧࡱࡸࠬሀ")]
			if EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠪࡧࡴࡻ࡮ࡵࡴࡼࠫሁ") in NnbJWYvlRyFmU9: KTL7OP3spfChQm9n8UudYMDt = iQbuc3OM06BwPnGpsa[b05yftsZ6NYgIKP(u"ࠫࡨࡵࡵ࡯ࡶࡵࡽࠬሂ")]
			if LgpdP3UjFRnlX(u"ࠬࡩ࡯ࡶࡰࡷࡶࡾࡥࡣࡰࡦࡨࠫሃ") in NnbJWYvlRyFmU9: uaTX96nvZ2dHB7cNpW380xr = iQbuc3OM06BwPnGpsa[qbPw1d3KimF(u"࠭ࡣࡰࡷࡱࡸࡷࡿ࡟ࡤࡱࡧࡩࠬሄ")]
			if BoWHNb9daQVCF16A(u"ࠧࡳࡧࡪ࡭ࡴࡴࠧህ") in NnbJWYvlRyFmU9: nqPT146ysDmR = iQbuc3OM06BwPnGpsa[PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠨࡴࡨ࡫࡮ࡵ࡮ࠨሆ")]
			if qbPw1d3KimF(u"ࠩࡦ࡭ࡹࡿࠧሇ") in NnbJWYvlRyFmU9: SQ4FIH59BnJR3WqTiyGZhfMrkc = iQbuc3OM06BwPnGpsa[gItVahxL0w(u"ࠪࡧ࡮ࡺࡹࠨለ")]
			if vvHpKfcqRnrFzjG(u"ࠫࡹ࡯࡭ࡦࡼࡲࡲࡪ࠭ሉ") in NnbJWYvlRyFmU9:
				yews0quX8Wb3CkPYov = iQbuc3OM06BwPnGpsa[C2dgEDAKQGsvh(u"ࠬࡺࡩ࡮ࡧࡽࡳࡳ࡫ࠧሊ")][b05yftsZ6NYgIKP(u"࠭ࡵࡵࡥࠪላ")]
				if yews0quX8Wb3CkPYov[RqldvxFuM5GEQ2HAz93o7afBb0(u"࠳᛻")] not in [FGDJwkEbTB5SoXujs3f(u"ࠧ࠮ࠩሌ"),vvHpKfcqRnrFzjG(u"ࠨ࠭ࠪል")]: yews0quX8Wb3CkPYov = v5EA6TqHX3s4jzBMk(u"ࠩ࠮ࠫሎ")+yews0quX8Wb3CkPYov
			jZLmif48dFVOW1 = ip+EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠪ࠰ࠬሏ")+UXwK0QkvAiHptTe4bP1L5Za9JhlVxO+C2dgEDAKQGsvh(u"ࠫ࠱࠭ሐ")+KTL7OP3spfChQm9n8UudYMDt+WMkAjB1RgN7q(u"ࠬ࠲ࠧሑ")+nqPT146ysDmR+v5EA6TqHX3s4jzBMk(u"࠭ࠬࠨሒ")+SQ4FIH59BnJR3WqTiyGZhfMrkc+RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠧ࠭ࠩሓ")+yews0quX8Wb3CkPYov
			if BLz7m2RkNrxXQwy1cGAp: jZLmif48dFVOW1 = jZLmif48dFVOW1.encode(v5EA6TqHX3s4jzBMk(u"ࠨࡷࡷࡪ࠽࠭ሔ")).decode(NVS30xAdRFMIw1n9CislkE2(u"ࠩࡸࡲ࡮ࡩ࡯ࡥࡧࡢࡩࡸࡩࡡࡱࡧࠪሕ"))
	jZLmif48dFVOW1 = tW06wVMpReHfnj3KgzT2va(jZLmif48dFVOW1)
	return jZLmif48dFVOW1
def X54MLovbG8nAEkB9J(H36kU9RhCjqAe5VZ):
	c6odFlJB82zyfs1v,showDialogs = EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠪࠫሖ"),PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࡘࡷࡻࡥៜ")
	if H36kU9RhCjqAe5VZ.count(FGDJwkEbTB5SoXujs3f(u"ࠫࡤ࠭ሗ"))>=hhlbF1Sns5TrEN8QPCYmL4(u"࠶᛼"):
		H36kU9RhCjqAe5VZ,c6odFlJB82zyfs1v = H36kU9RhCjqAe5VZ.split(jSu5Cg2Ub1OAkZVs8Yoz(u"ࠬࡥࠧመ"),T6wRistc1SCo4hqObgumK(u"࠶᛽"))
		c6odFlJB82zyfs1v = FGDJwkEbTB5SoXujs3f(u"࠭࡟ࠨሙ")+c6odFlJB82zyfs1v
		if C2dgEDAKQGsvh(u"ࠧࡠࡐࡒࡈࡎࡇࡌࡐࡉࡖࡣࠬሚ") in c6odFlJB82zyfs1v: showDialogs = LgpdP3UjFRnlX(u"ࡋࡧ࡬ࡴࡧ៝")
		else: showDialogs = V2RbfGOBdcA6l8NTsPWzEyvS7(u"࡚ࡲࡶࡧ៞")
	return H36kU9RhCjqAe5VZ,c6odFlJB82zyfs1v,showDialogs
def mnjYwRBF97ZdqW8Xl0CzkQcsvJH():
	hfa8xlLke7s = XXRtDhYvWb35qnLBxIri7ScNUks0.path.join(QgRBJhSGd4uX7i,BoWHNb9daQVCF16A(u"ࠨࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧማ"))
	qbenlV5uFd38OfRC6LchNji = BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠶᛾")
	if XXRtDhYvWb35qnLBxIri7ScNUks0.path.exists(hfa8xlLke7s):
		for MVQo7cbNdaril0FG6Pp in XXRtDhYvWb35qnLBxIri7ScNUks0.listdir(hfa8xlLke7s):
			if QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠩ࠱ࡴࡾࡵࠧሜ") in MVQo7cbNdaril0FG6Pp: continue
			if NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠪࡣࡤࡶࡹࡤࡣࡦ࡬ࡪࡥ࡟ࠨም") in MVQo7cbNdaril0FG6Pp: continue
			ucwkq5lERhZUgxeYQtpMTr0F6LX = XXRtDhYvWb35qnLBxIri7ScNUks0.path.join(hfa8xlLke7s,MVQo7cbNdaril0FG6Pp)
			HHpJgQV3IwWl18h02,ssuJokZgUN2SDTVMHQeyb3Idm0F = SIG93nyQ6qCPRdkwijWlsM(ucwkq5lERhZUgxeYQtpMTr0F6LX)
			qbenlV5uFd38OfRC6LchNji += HHpJgQV3IwWl18h02
	return qbenlV5uFd38OfRC6LchNji
def bMABswNzQganI1kmReiOdjLypS3(showDialogs):
	i0MUvEDCalnOjuyw8JIqNLpZWP = bLEBi8IO7uU2x3htYDdVq95.getSetting(gItVahxL0w(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩሞ"))
	QKmlNZfGM1j09aBkbTU = zPgNsqpJInt(RnqtMUa9Nh6peGEsBT,rbjsM8cRFiuA1(u"ࠬࡹࡴࡳࠩሟ"),YB5xyI7MaRslVpv(u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩሠ"),sRth5giAQzWlEVm7JOX(u"ࠧࡎࡇࡖࡗࡆࡍࡅࡔࠩሡ"))
	IMVvhsnENdkWL,RyLVhnsZQwPudgB5Oqekx = i0MUvEDCalnOjuyw8JIqNLpZWP,QKmlNZfGM1j09aBkbTU
	AyYwV9s3aQ4xqECUKiTcf1m6,X304trs1dnV2wSGI5vT = PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠨࠩሢ"),qbPw1d3KimF(u"ࠩࠪሣ")
	if b05yftsZ6NYgIKP(u"࠱᛿"):
		qmr7vLh1EW = AK5RqLhji4W1wt9VdrCD3PGeQM[b05yftsZ6NYgIKP(u"ࠪࡔ࡞࡚ࡈࡐࡐࠪሤ")][vvHpKfcqRnrFzjG(u"࠴ᜀ")]
		ggfedDsABTMIh = hvc2sXOB31KTLgiZaQUR9xuGjloYS(hhlbF1Sns5TrEN8QPCYmL4(u"࠵࠵ᜁ"))
		jZLmif48dFVOW1 = xFP4v9DfhOV8yo()
		KTL7OP3spfChQm9n8UudYMDt = jZLmif48dFVOW1.split(rbjsM8cRFiuA1(u"ࠫ࠱࠭ሥ"))[T6wRistc1SCo4hqObgumK(u"࠵ᜂ")]
		qbenlV5uFd38OfRC6LchNji = mnjYwRBF97ZdqW8Xl0CzkQcsvJH()
		XQ6bCdRgwsz3H1heoj9Zicq70OnBlA = {BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠬࡻࡳࡦࡴࠪሦ"):ggfedDsABTMIh,WMkAjB1RgN7q(u"࠭ࡶࡦࡴࡶ࡭ࡴࡴࠧሧ"):RhVj0vAt5kPHm,nr5mZG89ICi6cgt4MfLJa0(u"ࠧࡤࡱࡸࡲࡹࡸࡹࠨረ"):KTL7OP3spfChQm9n8UudYMDt,C2dgEDAKQGsvh(u"ࠨ࡫ࡧࡷࠬሩ"):UnJu5mvBrPKqOidwpNcjAbh(qbenlV5uFd38OfRC6LchNji)}
		UMNteoHlkEy3Yf = mORwgTnXBdQ7iCSHKf(SToQEHqGtMnAlFbCz4wxBDuOsmW7,PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠩࡓࡓࡘ࡚ࠧሪ"),qmr7vLh1EW,XQ6bCdRgwsz3H1heoj9Zicq70OnBlA,BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠪࠫራ"),WMkAjB1RgN7q(u"ࠫࠬሬ"),C2dgEDAKQGsvh(u"ࠬ࠭ር"),BoWHNb9daQVCF16A(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡇࡗࡣࡒࡋࡓࡔࡃࡊࡉࡘ࠳࠱ࡴࡶࠪሮ"))
		if not UMNteoHlkEy3Yf.succeeded:
			if i0MUvEDCalnOjuyw8JIqNLpZWP in [l0WAe1f7Bpi5ZXk(u"ࠧࠨሯ"),rbjsM8cRFiuA1(u"ࠨࡐࡈ࡛ࠬሰ")]: IMVvhsnENdkWL = fY5wTlhtnOc0Er6sdy4k87b(u"ࠩࡑࡉ࡜ࡥࡔࡐࡡࡈࡖࡗࡕࡒࠨሱ")
			elif i0MUvEDCalnOjuyw8JIqNLpZWP==sRth5giAQzWlEVm7JOX(u"ࠪࡓࡑࡊࠧሲ"): IMVvhsnENdkWL = BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠫࡔࡒࡄࡠࡖࡒࡣࡊࡘࡒࡐࡔࠪሳ")
		else:
			zTqiDFKCOj0E1A9NZs2GQb = UMNteoHlkEy3Yf.content
			zTqiDFKCOj0E1A9NZs2GQb = dWsa2A0O4o5BYiqGXhyKEbM(PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠬࡲࡩࡴࡶࠪሴ"),zTqiDFKCOj0E1A9NZs2GQb)
			zTqiDFKCOj0E1A9NZs2GQb = sorted(zTqiDFKCOj0E1A9NZs2GQb,reverse=C2jP0iLNGKnHu9xp(u"ࡔࡳࡷࡨ៟"),key=lambda key: int(key[C2jP0iLNGKnHu9xp(u"࠴ᜃ")]))
			X304trs1dnV2wSGI5vT,RyLVhnsZQwPudgB5Oqekx = hhlbF1Sns5TrEN8QPCYmL4(u"࠭ࠧስ"),PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠧࠨሶ")
			for Gjtm3oqn0ZdBlD2I,vvGlet98Cbf2ma,mKBurDQaSIn1Aydsc9LvbF5EZf in zTqiDFKCOj0E1A9NZs2GQb:
				if Gjtm3oqn0ZdBlD2I==jSu5Cg2Ub1OAkZVs8Yoz(u"ࠨ࠲ࠪሷ"):
					X304trs1dnV2wSGI5vT += mKBurDQaSIn1Aydsc9LvbF5EZf+C2dgEDAKQGsvh(u"ࠩ࠽࠾ࠬሸ")
					continue
				if RyLVhnsZQwPudgB5Oqekx: RyLVhnsZQwPudgB5Oqekx += qbPw1d3KimF(u"ࠪࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣ࡜࡯࡞ࡱࠫሹ")
				DDe0269MWmqkFpurdbfZ3y = mKBurDQaSIn1Aydsc9LvbF5EZf.split(T6wRistc1SCo4hqObgumK(u"ࠫࡡࡴࠧሺ"))[fY5wTlhtnOc0Er6sdy4k87b(u"࠵ᜄ")]
				n7F25fCI9B4zDSPoQpW = PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠬืำศๆฬࠤำอีสࠢ็็ࠥ็โุࠩሻ") if vvGlet98Cbf2ma else BmcLzCFjuIrZP5fwXH18aN6YS(u"࠭ࠧሼ")
				RyLVhnsZQwPudgB5Oqekx += mKBurDQaSIn1Aydsc9LvbF5EZf.replace(DDe0269MWmqkFpurdbfZ3y,NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪሽ")+DDe0269MWmqkFpurdbfZ3y+n7F25fCI9B4zDSPoQpW+gItVahxL0w(u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪሾ"))+UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠩ࡟ࡲࠬሿ")
			RyLVhnsZQwPudgB5Oqekx = gItVahxL0w(u"ࠪࡠࡳ࠭ቀ")+RyLVhnsZQwPudgB5Oqekx+hhlbF1Sns5TrEN8QPCYmL4(u"ࠫࡡࡴ࡜࡯ࠩቁ")
			X304trs1dnV2wSGI5vT = X304trs1dnV2wSGI5vT.strip(rbjsM8cRFiuA1(u"ࠬࡀ࠺ࠨቂ"))
			AyYwV9s3aQ4xqECUKiTcf1m6 = bLEBi8IO7uU2x3htYDdVq95.getSetting(b05yftsZ6NYgIKP(u"࠭ࡡࡷ࠰ࡳࡶ࡮ࡼࡳ࠲ࠩቃ"))
			if RyLVhnsZQwPudgB5Oqekx==QKmlNZfGM1j09aBkbTU and i0MUvEDCalnOjuyw8JIqNLpZWP in [sRth5giAQzWlEVm7JOX(u"ࠧࡐࡎࡇࠫቄ"),NVS30xAdRFMIw1n9CislkE2(u"ࠨࡑࡏࡈࡤ࡚ࡏࡠࡇࡕࡖࡔࡘࠧቅ")]: IMVvhsnENdkWL = QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠩࡒࡐࡉ࠭ቆ")
			else: IMVvhsnENdkWL = RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠪࡒࡊ࡝ࠧቇ")
			VZ8BTik93OqXLCh0fD7d2KUPpn4mH6(RnqtMUa9Nh6peGEsBT,WMkAjB1RgN7q(u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧቈ"),fY5wTlhtnOc0Er6sdy4k87b(u"ࠬࡓࡅࡔࡕࡄࡋࡊ࡙ࠧ቉"),RyLVhnsZQwPudgB5Oqekx,BZdvf7MIUxHQc3aCT)
			bLEBi8IO7uU2x3htYDdVq95.setSetting(k5dztomYyN3H(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡳࡥࡴࡵࡤ࡫ࡪࡹࠧቊ"),UnJu5mvBrPKqOidwpNcjAbh(SGB7KzblUa4gCZD1srqc))
			bLEBi8IO7uU2x3htYDdVq95.setSetting(T6wRistc1SCo4hqObgumK(u"ࠧࡢࡸ࠱ࡴࡷ࡯ࡶࡴ࠳ࠪቋ"),X304trs1dnV2wSGI5vT)
			from hashlib import md5 as UPTJpd3eoxqc6DgQ8X5bCu2IARm
			ZFUPDjAempKQrWB7nb8 = UPTJpd3eoxqc6DgQ8X5bCu2IARm(jSu5Cg2Ub1OAkZVs8Yoz(u"࠻ᜅ")*X304trs1dnV2wSGI5vT.encode(v5EA6TqHX3s4jzBMk(u"ࠨࡷࡷࡪ࠽࠭ቌ"))).hexdigest()
			ZFUPDjAempKQrWB7nb8 = UPTJpd3eoxqc6DgQ8X5bCu2IARm(jx7s8T0BFgODXLMzIYedf(u"࠱࠵ᜆ")*ZFUPDjAempKQrWB7nb8.encode(hhlbF1Sns5TrEN8QPCYmL4(u"ࠩࡸࡸ࡫࠾ࠧቍ"))).hexdigest()
			ZFUPDjAempKQrWB7nb8 = UPTJpd3eoxqc6DgQ8X5bCu2IARm(jx7s8T0BFgODXLMzIYedf(u"࠲࠻ᜇ")*ZFUPDjAempKQrWB7nb8.encode(l0WAe1f7Bpi5ZXk(u"ࠪࡹࡹ࡬࠸ࠨ቎"))).hexdigest()
			bLEBi8IO7uU2x3htYDdVq95.setSetting(BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠫࡦࡼ࠮ࡱࡴ࡬ࡺࡸ࠸ࠧ቏"),ZFUPDjAempKQrWB7nb8)
	if showDialogs:
		if IMVvhsnENdkWL in [jx7s8T0BFgODXLMzIYedf(u"ࠬࡕࡌࡅࡡࡗࡓࡤࡋࡒࡓࡑࡕࠫቐ"),k5dztomYyN3H(u"࠭ࡎࡆ࡙ࡢࡘࡔࡥࡅࡓࡔࡒࡖࠬቑ")]:
			ZIOHgA3z0TBR(v5EA6TqHX3s4jzBMk(u"ࠧࠨቒ"),nr5mZG89ICi6cgt4MfLJa0(u"ࠨࠩቓ"),FGDJwkEbTB5SoXujs3f(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬቔ"),PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"๋๋ࠪอใࠡ็ื็้ฯࠠโ์ࠣะ์อาไ๋๋ࠢ๏ࠦไ๋ีอࠤ๊์ࠠศๆหี๋อๅอࠢ࠱࠲ࠥํะ่ࠢสฺ่๊ใๅหࠣๆิ๊ࠦไ๊้ࠤุฮศ่ษࠣห้หๆหำ้ฮࠥอไฯษุࠤอ้ࠠฤ๊ࠣห้ืว้ฬิࠤฬ๊ฮศืࠣฬ่ࠦรุ้่่๊ࠢษࠡใํࠤฬ๊ริๆส็ࠥ฿ๆะๅࠪቕ"))
		else:
			bFnD6Nh75IQcKrTke3gux4PvwRGUfS(jSu5Cg2Ub1OAkZVs8Yoz(u"ࠫࡷ࡯ࡧࡩࡶࠪቖ"),fY5wTlhtnOc0Er6sdy4k87b(u"ࠬืำศศ็ࠤ๊์ࠠศๆ่ฬึ๋ฬࠡว็ํ๋ࠥำหะา้๏ࠦวๅสิ๊ฬ๋ฬࠨ቗"),RyLVhnsZQwPudgB5Oqekx,BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࡡ࡯ࡳࡳ࡭ࠧቘ"))
			IMVvhsnENdkWL = FGDJwkEbTB5SoXujs3f(u"ࠧࡐࡎࡇࠫ቙")
	if IMVvhsnENdkWL!=i0MUvEDCalnOjuyw8JIqNLpZWP:
		bLEBi8IO7uU2x3htYDdVq95.setSetting(qbPw1d3KimF(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡲ࡫ࡳࡴࡣࡪࡩࡸ࠭ቚ"),IMVvhsnENdkWL)
		tUXmK5PeEH9SDq.executebuiltin(fY5wTlhtnOc0Er6sdy4k87b(u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡘࡥࡧࡴࡨࡷ࡭࠭ቛ"))
	bbvwO2iulBaz0QjMcEsrypR6xLX = k5dztomYyN3H(u"ࡖࡵࡹࡪ១") if X304trs1dnV2wSGI5vT!=AyYwV9s3aQ4xqECUKiTcf1m6 else jx7s8T0BFgODXLMzIYedf(u"ࡇࡣ࡯ࡷࡪ០")
	if bbvwO2iulBaz0QjMcEsrypR6xLX:
		gj7BGM5t3RZpA0vNixLqzwualb16(v5EA6TqHX3s4jzBMk(u"๊ࠪัำสࠡ฻่่๏ฯࠧቜ"),NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠫฯำฯ๋อࠣห้฻ไศฯํหฯ࠭ቝ"),KBxPW9cX8dqtaUDG=YB5xyI7MaRslVpv(u"࠹࠸࠴ᜈ"))
		PapzBZgIekhJ5Fq8rDR2wOxTnu(T6wRistc1SCo4hqObgumK(u"ࠬࡌ࡯ࡳࡥࡨࡨࠥ࡫ࡸࡪࡶࠣࡸࡴࠦࡡࡱࡲ࡯ࡽࠥࡴࡥࡸࠢࡳࡶ࡮ࡼࡩ࡭ࡧࡪࡩࡸ࠭቞"))
	return bbvwO2iulBaz0QjMcEsrypR6xLX
def r8D6ZdSgBKywTfJ39qlYsk1Qp0VnU(qyx6o5afd0kreACVWbuG,nmLNruPizehkcGl):
	from socket import socket as sjOCEyDLImv7,AF_INET as om54gkLrHi6DqAQ0M,SOCK_STREAM as yAQdIO8psN2zSqX1KFW5BL
	ayZ5ApzsqU4m3nYgcj = sjOCEyDLImv7(om54gkLrHi6DqAQ0M,yAQdIO8psN2zSqX1KFW5BL)
	ayZ5ApzsqU4m3nYgcj.settimeout(C2dgEDAKQGsvh(u"࠴ᜉ"))
	r0IUeJ3ZE2OGiCdbPKRx1VTlWL,AfJNu4CWLyOrXBKeQam3lUq0pbIv = RqldvxFuM5GEQ2HAz93o7afBb0(u"ࡗࡶࡺ࡫២"),nr5mZG89ICi6cgt4MfLJa0(u"࠴ᜊ")
	TTLQDONupiB6q = KBxPW9cX8dqtaUDG.time()
	try: ayZ5ApzsqU4m3nYgcj.connect((qyx6o5afd0kreACVWbuG,nmLNruPizehkcGl))
	except: r0IUeJ3ZE2OGiCdbPKRx1VTlWL = UnWjVbo503mEMv9KF(u"ࡊࡦࡲࡳࡦ៣")
	C91C3dcMhJDkRX = KBxPW9cX8dqtaUDG.time()
	if r0IUeJ3ZE2OGiCdbPKRx1VTlWL: AfJNu4CWLyOrXBKeQam3lUq0pbIv = C91C3dcMhJDkRX-TTLQDONupiB6q
	return AfJNu4CWLyOrXBKeQam3lUq0pbIv
def ooMyveu1YHBOkXcpfF2jqCVl(showDialogs):
	if showDialogs:
		tLwvQlnjGpWsRVCN1 = mmwySO1P4jnKz5(NVS30xAdRFMIw1n9CislkE2(u"࠭ࠧ቟"),qbPw1d3KimF(u"ࠧࠨበ"),PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠨࠩቡ"),fY5wTlhtnOc0Er6sdy4k87b(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬቢ"),k5dztomYyN3H(u"ࠪืํ็๋ࠠไ๋้ࠥอไษำ้ห๊าࠠศๆล๊ࠥฮลึๆสัࠥ๎ส็ฺํๅࠥาๅ๋฻ࠣๆํอูะࠢส่อ๐ว็ษอࠤํอไไษืࠤฬ๊ๅิฬัำ๊ฯࠠโ์ࠣห้ฮั็ษ่ะࠥ࠴࠮้ࠡ็ࠤฯื๊ะࠢอุ฿๐ไࠡ฻่่๏ฯࠠศๆอ๊฽๐แࠡษ็ฦ๋ࠦฟࠢࠩባ"))
	else: tLwvQlnjGpWsRVCN1 = NVS30xAdRFMIw1n9CislkE2(u"࡙ࡸࡵࡦ៤")
	if tLwvQlnjGpWsRVCN1==YB5xyI7MaRslVpv(u"࠶ᜋ"):
		for MVQo7cbNdaril0FG6Pp in XXRtDhYvWb35qnLBxIri7ScNUks0.listdir(IjYiO4u9HGmgw):
			if MVQo7cbNdaril0FG6Pp.endswith(k5dztomYyN3H(u"ࠫ࠳ࡪࡢࠨቤ")) and C2dgEDAKQGsvh(u"ࠬࡪࡡࡵࡣࠪብ") in MVQo7cbNdaril0FG6Pp:
				GTYRu9hVKZoHOyUt4w2ilpLqA = XXRtDhYvWb35qnLBxIri7ScNUks0.path.join(IjYiO4u9HGmgw,MVQo7cbNdaril0FG6Pp)
				try: W9YiR1FGTdzO3jByXPA70D,CCJpwYUsTN1cBIz5PH = syJIkO4GZvPcSl(GTYRu9hVKZoHOyUt4w2ilpLqA)
				except: return
				CCJpwYUsTN1cBIz5PH.execute(b05yftsZ6NYgIKP(u"࠭ࡐࡓࡃࡊࡑࡆࠦࡩ࡯ࡶࡨ࡫ࡷ࡯ࡴࡺࡡࡦ࡬ࡪࡩ࡫࠼ࠩቦ"))
				CCJpwYUsTN1cBIz5PH.execute(QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠧࡑࡔࡄࡋࡒࡇࠠࡰࡲࡷ࡭ࡲ࡯ࡺࡦ࠽ࠪቧ"))
				CCJpwYUsTN1cBIz5PH.execute(WMkAjB1RgN7q(u"ࠨࡘࡄࡇ࡚࡛ࡍ࠼ࠩቨ"))
				W9YiR1FGTdzO3jByXPA70D.commit()
				W9YiR1FGTdzO3jByXPA70D.close()
		if showDialogs:
			ZIOHgA3z0TBR(WMkAjB1RgN7q(u"ࠩࠪቩ"),BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠪࠫቪ"),LgpdP3UjFRnlX(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧቫ"),vvHpKfcqRnrFzjG(u"ࠬะๅหࠢห๊ัออࠡ฻่่๏ฯࠠฦื็หา่ࠦห่฻๎ๆࠦฬๆ์฼ࠤ็๎วฺัࠣห้ฮ๊ศ่สฮࠥ๎วๅๅสุࠥอไๆีอาิ๋ษࠡใํࠤฬ๊ศา่ส้ั࠭ቬ"))
	return
def YRi6vEsJ05kd8Bo9UtbpzlVn2(qXxnDuZ23L,SoscNgunyY3I0Bh5w,showDialogs):
	if qXxnDuZ23L!=None:
		global HZnJAMjTeVYU
		HZnJAMjTeVYU = qXxnDuZ23L
	if SoscNgunyY3I0Bh5w!=None:
		global yZa5lX0JRhOKD2Fig4pxm
		yZa5lX0JRhOKD2Fig4pxm = SoscNgunyY3I0Bh5w
	if showDialogs!=None:
		global YBnLP7DkXpG5zSusIQFxe
		YBnLP7DkXpG5zSusIQFxe = showDialogs
	return
HZnJAMjTeVYU,yZa5lX0JRhOKD2Fig4pxm,YBnLP7DkXpG5zSusIQFxe = NVS30xAdRFMIw1n9CislkE2(u"࠭ࠧቭ"),l0WAe1f7Bpi5ZXk(u"ࠧࠨቮ"),NVS30xAdRFMIw1n9CislkE2(u"ࠨࠩቯ")
def CLB6WYc9NP(ww2vqCObJMBYRUaDyuWQ0,qmr7vLh1EW,data,headers,allow_redirects,showDialogs,iW6eqtHJGnzFhTSgduj7Pys2w,T1haiwEgF2p7bnBJzVXRPUjrds,sVWmClxtR10p):
	if showDialogs==k5dztomYyN3H(u"ࠩࠪተ"): KKqZXkwNI5uP3vU9jrbJoyg = NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࡚ࡲࡶࡧ៥") if YBnLP7DkXpG5zSusIQFxe==EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠪࠫቱ") else YBnLP7DkXpG5zSusIQFxe
	else: KKqZXkwNI5uP3vU9jrbJoyg = BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࡕࡴࡸࡩ៧") if showDialogs else YB5xyI7MaRslVpv(u"ࡆࡢ࡮ࡶࡩ៦")
	if sVWmClxtR10p==EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠫࠬቲ"): Hc6aUQPngo07iKjNGr = NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࡖࡵࡹࡪ៨") if yZa5lX0JRhOKD2Fig4pxm==FGDJwkEbTB5SoXujs3f(u"ࠬ࠭ታ") else yZa5lX0JRhOKD2Fig4pxm
	else: Hc6aUQPngo07iKjNGr = qbPw1d3KimF(u"ࡘࡷࡻࡥ៪") if sVWmClxtR10p else WMkAjB1RgN7q(u"ࡉࡥࡱࡹࡥ៩")
	if T1haiwEgF2p7bnBJzVXRPUjrds==C2dgEDAKQGsvh(u"࠭ࠧቴ"): zDq8xpdJFG4tfaWkC = T6wRistc1SCo4hqObgumK(u"࡙ࡸࡵࡦ៫") if HZnJAMjTeVYU==BoWHNb9daQVCF16A(u"ࠧࠨት") else HZnJAMjTeVYU
	else: zDq8xpdJFG4tfaWkC = BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࡔࡳࡷࡨ៭") if T1haiwEgF2p7bnBJzVXRPUjrds else UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࡌࡡ࡭ࡵࡨ៬")
	if allow_redirects==C2jP0iLNGKnHu9xp(u"ࠨࠩቶ"): qjSK1N24JItMUwm5 = k5dztomYyN3H(u"ࡕࡴࡸࡩ៮")
	else: qjSK1N24JItMUwm5 = l0WAe1f7Bpi5ZXk(u"ࡗࡶࡺ࡫៰") if allow_redirects else BoWHNb9daQVCF16A(u"ࡈࡤࡰࡸ࡫៯")
	if data==None: toAVQS46Fv8aJYyLf25KnkUNC = None
	elif data==qbPw1d3KimF(u"ࠩࠪቷ"): toAVQS46Fv8aJYyLf25KnkUNC = {}
	else: toAVQS46Fv8aJYyLf25KnkUNC = data
	if headers==None: eIL9BxdTbZj = None
	elif headers==LgpdP3UjFRnlX(u"ࠪࠫቸ"): eIL9BxdTbZj = {}
	else: eIL9BxdTbZj = headers
	return ww2vqCObJMBYRUaDyuWQ0,qmr7vLh1EW,toAVQS46Fv8aJYyLf25KnkUNC,eIL9BxdTbZj,qjSK1N24JItMUwm5,KKqZXkwNI5uP3vU9jrbJoyg,iW6eqtHJGnzFhTSgduj7Pys2w,zDq8xpdJFG4tfaWkC,Hc6aUQPngo07iKjNGr
def vcmTsFNY8wG9Z2xg(ww2vqCObJMBYRUaDyuWQ0,qmr7vLh1EW,AqLgT4S6FExHi1kZ5smy7a0hRX,ib6URTIJnFlgVwXsQAN0ZGD4k9c3ph,IXuCzdlqv9WRAkLSt,showDialogs,iW6eqtHJGnzFhTSgduj7Pys2w,T1haiwEgF2p7bnBJzVXRPUjrds=BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠫࠬቹ"),sVWmClxtR10p=qbPw1d3KimF(u"ࠬ࠭ቺ")):
	xLTSPVp8zUgblio3vOq6sM027EF = CLB6WYc9NP(ww2vqCObJMBYRUaDyuWQ0,qmr7vLh1EW,AqLgT4S6FExHi1kZ5smy7a0hRX,ib6URTIJnFlgVwXsQAN0ZGD4k9c3ph,IXuCzdlqv9WRAkLSt,showDialogs,iW6eqtHJGnzFhTSgduj7Pys2w,T1haiwEgF2p7bnBJzVXRPUjrds,sVWmClxtR10p)
	ww2vqCObJMBYRUaDyuWQ0,qmr7vLh1EW,toAVQS46Fv8aJYyLf25KnkUNC,eIL9BxdTbZj,qjSK1N24JItMUwm5,KKqZXkwNI5uP3vU9jrbJoyg,iW6eqtHJGnzFhTSgduj7Pys2w,zDq8xpdJFG4tfaWkC,Hc6aUQPngo07iKjNGr = xLTSPVp8zUgblio3vOq6sM027EF
	J7OuGs2tvS4IapcCTr = list(eIL9BxdTbZj.keys())
	if BmcLzCFjuIrZP5fwXH18aN6YS(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪቻ") not in J7OuGs2tvS4IapcCTr: eIL9BxdTbZj[BoWHNb9daQVCF16A(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫቼ")] = NVS30xAdRFMIw1n9CislkE2(u"ࠨࡂࡃࡄࡘࡑࡉࡑࡡࡋࡉࡆࡊࡅࡓࡂࡃࡄࠬች")
	bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,eG5xjWgRUhC8f,RRfNT13COItMrPdJlEgq,nnDRPzg7XWmorOjQMtU5hxH = I1zAN6ZaFrhSfMojPKTLmiG2(qmr7vLh1EW)
	WiQBzwAIa6GvLC79Jr3h0F5uosjbRy = bLEBi8IO7uU2x3htYDdVq95.getSetting(hhlbF1Sns5TrEN8QPCYmL4(u"ࠩࡤࡺ࠳ࡪ࡮ࡴࠩቾ"))
	h7cjS8YXyNqgQPsk4WLlG3x = bLEBi8IO7uU2x3htYDdVq95.getSetting(NVS30xAdRFMIw1n9CislkE2(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡵࡴࡧࡧࡲࡸ࠭ቿ"))
	NMWlwz87p6EmSGx2Uy1i9h4VfCrnI = bLEBi8IO7uU2x3htYDdVq95.getSetting(WMkAjB1RgN7q(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡵࡨࡴࡷࡵࡸࡺࠩኀ"))
	AGVb2MJg3aSkB = [qbPw1d3KimF(u"ࠬࡹࡣࡳࡣࡳࡩࡷࡧࡰࡪࠩኁ"),QynMHGWA0blfqTUdxRh5Jzi2t(u"࠭ࡳࡤࡴࡤࡴࡪࡵࡰࡴࠩኂ"),vvHpKfcqRnrFzjG(u"ࠧࡴࡥࡵࡥࡵ࡯࡮ࡨࡣࡱࡸࠬኃ"),FGDJwkEbTB5SoXujs3f(u"ࠨࡵࡦࡶࡦࡶࡥࡶࡲࠪኄ"),hhlbF1Sns5TrEN8QPCYmL4(u"ࠩࡶࡧࡷࡧࡰࡦ࠰ࡧࡳࠬኅ")]
	GGBaUXTPRxz1Jn2yp48dVvs5O3Wc6Q = hhlbF1Sns5TrEN8QPCYmL4(u"࡙ࡸࡵࡦ៲") if any(WoFrX46wzbCNp18 in qmr7vLh1EW for WoFrX46wzbCNp18 in AGVb2MJg3aSkB) else rbjsM8cRFiuA1(u"ࡊࡦࡲࡳࡦ៱")
	if T6wRistc1SCo4hqObgumK(u"ࠪࠪࡺࡸ࡬࠾ࠩኆ") in bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 and GGBaUXTPRxz1Jn2yp48dVvs5O3Wc6Q: dCLtUe1Q0f = bJEs4IVAPdyUrhwCLv9k2YoOl8nt1.rsplit(RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠫࠫࡻࡲ࡭࠿ࠪኇ"),l0WAe1f7Bpi5ZXk(u"࠷ᜌ"))[l0WAe1f7Bpi5ZXk(u"࠷ᜌ")]
	else: dCLtUe1Q0f = EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠬ࠭ኈ")
	K32HrlQLWMiyUcOd = AK5RqLhji4W1wt9VdrCD3PGeQM[nr5mZG89ICi6cgt4MfLJa0(u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭኉")]
	ZP1Vsjb6xznUcoQFltvme = bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 in K32HrlQLWMiyUcOd or dCLtUe1Q0f in K32HrlQLWMiyUcOd
	IdeysJLtzqXGVviU0T = AK5RqLhji4W1wt9VdrCD3PGeQM[sRth5giAQzWlEVm7JOX(u"ࠧࡓࡇࡓࡓࡘ࠭ኊ")]
	oP03Ci9DnF1t2EXg4A6L = bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 in IdeysJLtzqXGVviU0T or dCLtUe1Q0f in IdeysJLtzqXGVviU0T
	OHdwbjqtmVCgv1pcBR96Qxf5AoyKD = ZP1Vsjb6xznUcoQFltvme or oP03Ci9DnF1t2EXg4A6L
	jRcobP6zyKhDZGMm = eG5xjWgRUhC8f==None and RRfNT13COItMrPdJlEgq==None and not GGBaUXTPRxz1Jn2yp48dVvs5O3Wc6Q
	if jRcobP6zyKhDZGMm and OHdwbjqtmVCgv1pcBR96Qxf5AoyKD:
		if ZP1Vsjb6xznUcoQFltvme:
			rrpPxfFk93bR4 = K32HrlQLWMiyUcOd.index(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1)
			fHzMLJKg7BYTbqX4Sea3d1s2vAZOw = AK5RqLhji4W1wt9VdrCD3PGeQM[gItVahxL0w(u"ࠨࡒ࡜ࡘࡍࡕࡎࡠࡄࡎࡔࠬኋ")][rrpPxfFk93bR4]
			t3BcCYTsvR = JZsTvyp54E37Mf6ASIhU[rrpPxfFk93bR4]
		elif oP03Ci9DnF1t2EXg4A6L:
			rrpPxfFk93bR4 = IdeysJLtzqXGVviU0T.index(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1)
			fHzMLJKg7BYTbqX4Sea3d1s2vAZOw = AK5RqLhji4W1wt9VdrCD3PGeQM[l0WAe1f7Bpi5ZXk(u"ࠩࡕࡉࡕࡕࡓࡠࡄࡎࡔࠬኌ")][rrpPxfFk93bR4]
			t3BcCYTsvR = cGLksumPzEjOWMvNe1l2F5C3hB4t[rrpPxfFk93bR4]
	if RRfNT13COItMrPdJlEgq==YB5xyI7MaRslVpv(u"ࠪࠫኍ"): RRfNT13COItMrPdJlEgq = WiQBzwAIa6GvLC79Jr3h0F5uosjbRy
	elif RRfNT13COItMrPdJlEgq==None and h7cjS8YXyNqgQPsk4WLlG3x in [rbjsM8cRFiuA1(u"ࠫࡆ࡛ࡔࡐࠩ኎"),gItVahxL0w(u"ࠬࡇࡃࡄࡇࡓࡘࡊࡊࠧ኏")] and zDq8xpdJFG4tfaWkC: RRfNT13COItMrPdJlEgq = WiQBzwAIa6GvLC79Jr3h0F5uosjbRy
	n7odetkK9SuTR5gi2U3NH0ELDxf8 = bJEs4IVAPdyUrhwCLv9k2YoOl8nt1==AK5RqLhji4W1wt9VdrCD3PGeQM[l0WAe1f7Bpi5ZXk(u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭ነ")][QynMHGWA0blfqTUdxRh5Jzi2t(u"࠷ᜍ")]
	if ZP1Vsjb6xznUcoQFltvme or oP03Ci9DnF1t2EXg4A6L: bbeYVRCXkUzsmN39 = RqldvxFuM5GEQ2HAz93o7afBb0(u"࠲࠷ᜎ")
	elif iW6eqtHJGnzFhTSgduj7Pys2w in ANr5yaiVH3xW8YIJbCX6c: bbeYVRCXkUzsmN39 = BmcLzCFjuIrZP5fwXH18aN6YS(u"࠳࠳ᜏ")
	elif iW6eqtHJGnzFhTSgduj7Pys2w==RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡔࡈ࡚ࡊࡘࡓࡐࡡࡗࡖࡆࡔࡓࡍࡃࡗࡉ࠲࠷ࡳࡵࠩኑ"): bbeYVRCXkUzsmN39 = vvHpKfcqRnrFzjG(u"࠵࠴ᜐ")
	elif iW6eqtHJGnzFhTSgduj7Pys2w==sRth5giAQzWlEVm7JOX(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡓࡔࡍࡌࡆࡡࡗࡖࡆࡔࡓࡍࡃࡗࡉ࠲࠷ࡳࡵࠩኒ"): bbeYVRCXkUzsmN39 = BmcLzCFjuIrZP5fwXH18aN6YS(u"࠶࠵ᜑ")
	elif qbPw1d3KimF(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡋࡘࡃࡐࠫና") in iW6eqtHJGnzFhTSgduj7Pys2w: bbeYVRCXkUzsmN39 = BmcLzCFjuIrZP5fwXH18aN6YS(u"࠼࠶ᜒ")
	elif sRth5giAQzWlEVm7JOX(u"ࠪࡗࡍࡕࡆࡉࡃࠪኔ") in iW6eqtHJGnzFhTSgduj7Pys2w: bbeYVRCXkUzsmN39 = C2jP0iLNGKnHu9xp(u"࠽࠵ᜓ")
	elif fY5wTlhtnOc0Er6sdy4k87b(u"ࠫࡈࡏࡍࡂ࠶ࡘࠫን") in iW6eqtHJGnzFhTSgduj7Pys2w: bbeYVRCXkUzsmN39 = fY5wTlhtnOc0Er6sdy4k87b(u"࠲࠶᜔")
	elif k5dztomYyN3H(u"ࠬࡇࡈࡘࡃࡎࠫኖ") in iW6eqtHJGnzFhTSgduj7Pys2w: bbeYVRCXkUzsmN39 = l0WAe1f7Bpi5ZXk(u"࠳࠲᜕")
	elif V2RbfGOBdcA6l8NTsPWzEyvS7(u"࠭ࡃࡊࡏࡄࡐࡎࡍࡈࡕࠩኗ") in iW6eqtHJGnzFhTSgduj7Pys2w: bbeYVRCXkUzsmN39 = EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠴࠳᜖")
	elif BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠧࡄࡋࡐࡅࡈࡒࡕࡃ࡙ࡒࡖࡐ࠭ኘ") in iW6eqtHJGnzFhTSgduj7Pys2w: bbeYVRCXkUzsmN39 = RqldvxFuM5GEQ2HAz93o7afBb0(u"࠶࠴᜗")
	elif nr5mZG89ICi6cgt4MfLJa0(u"ࠨࡃࡎࡓࡆࡓࠧኙ") in iW6eqtHJGnzFhTSgduj7Pys2w: bbeYVRCXkUzsmN39 = rbjsM8cRFiuA1(u"࠶࠺᜘")
	elif gItVahxL0w(u"ࠩࡄࡏ࡜ࡇࡍࠨኚ") in iW6eqtHJGnzFhTSgduj7Pys2w: bbeYVRCXkUzsmN39 = BoWHNb9daQVCF16A(u"࠸࠶᜙")
	elif C2dgEDAKQGsvh(u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠵ࠬኛ") in iW6eqtHJGnzFhTSgduj7Pys2w: bbeYVRCXkUzsmN39 = k5dztomYyN3H(u"࠸࠰᜚")
	elif BoWHNb9daQVCF16A(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠸࠭ኜ") in iW6eqtHJGnzFhTSgduj7Pys2w: bbeYVRCXkUzsmN39 = BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠶࠱᜛")
	elif C2dgEDAKQGsvh(u"ࠬࡎࡁࡍࡃࡆࡍࡒࡇࠧኝ") in iW6eqtHJGnzFhTSgduj7Pys2w: bbeYVRCXkUzsmN39 = fY5wTlhtnOc0Er6sdy4k87b(u"࠵࠲᜜")
	else: bbeYVRCXkUzsmN39 = BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠳࠸᜝")
	if BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕࠨኞ") in iW6eqtHJGnzFhTSgduj7Pys2w and not toAVQS46Fv8aJYyLf25KnkUNC and BoWHNb9daQVCF16A(u"ࠧࠧࠩኟ") not in bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 and WMkAjB1RgN7q(u"ࠨࡁࠪአ") not in bJEs4IVAPdyUrhwCLv9k2YoOl8nt1: bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = bJEs4IVAPdyUrhwCLv9k2YoOl8nt1.rstrip(gItVahxL0w(u"ࠩ࠲ࠫኡ"))+RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠪ࠳ࠬኢ")
	AtD7Q3TkzreHS = (eG5xjWgRUhC8f!=None)
	rBLt7SNJKgGnsH = (RRfNT13COItMrPdJlEgq!=None and h7cjS8YXyNqgQPsk4WLlG3x!=BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠫࡘ࡚ࡏࡑࠩኣ"))
	if GGBaUXTPRxz1Jn2yp48dVvs5O3Wc6Q: bbeYVRCXkUzsmN39 = EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠹࠴᜞")
	if AtD7Q3TkzreHS and not GGBaUXTPRxz1Jn2yp48dVvs5O3Wc6Q: gj7BGM5t3RZpA0vNixLqzwualb16(FGDJwkEbTB5SoXujs3f(u"ࠬะแฺ์็ࠤอื่ไีํࠤึ่ๅࠨኤ"),eG5xjWgRUhC8f)
	elif rBLt7SNJKgGnsH: gj7BGM5t3RZpA0vNixLqzwualb16(BoWHNb9daQVCF16A(u"࠭สโ฻ํ่ࠥࡊࡎࡔࠢิๆ๊࠭እ"),RRfNT13COItMrPdJlEgq)
	if AtD7Q3TkzreHS:
		hNiVUOX8SD62ybZ5mgC = {C2dgEDAKQGsvh(u"ࠢࡩࡶࡷࡴࠧኦ"):eG5xjWgRUhC8f,qbPw1d3KimF(u"ࠣࡪࡷࡸࡵࡹࠢኧ"):eG5xjWgRUhC8f}
		BJON4ETWfxqv = eG5xjWgRUhC8f
	else: hNiVUOX8SD62ybZ5mgC,BJON4ETWfxqv = {},UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠩࠪከ")
	if rBLt7SNJKgGnsH:
		import urllib3.util.connection as TKqMD4sua2vfi9nt5rxJ3j
		PPtwhC61ajNgWXyuRIzMUiKnQv3T = uYqVHxoztm3A5hBb7CIrgPZ(TKqMD4sua2vfi9nt5rxJ3j,WiQBzwAIa6GvLC79Jr3h0F5uosjbRy)
	jMa8ep9rlVfgoWYD1x2KsnJHI,mxM8XR1eQOyYcSkuH,Q8e7GvtsDJqZT,oWpmUZd0Qb46vN7RTjgOixutSHe,dwbeP59FZWzMyUxBgSpqtuI4n,verify = qjSK1N24JItMUwm5,iW6eqtHJGnzFhTSgduj7Pys2w,ww2vqCObJMBYRUaDyuWQ0,v5EA6TqHX3s4jzBMk(u"ࡌࡡ࡭ࡵࡨ៳"),v5EA6TqHX3s4jzBMk(u"ࡌࡡ࡭ࡵࡨ៳"),nnDRPzg7XWmorOjQMtU5hxH
	if n7odetkK9SuTR5gi2U3NH0ELDxf8: dwbeP59FZWzMyUxBgSpqtuI4n = jx7s8T0BFgODXLMzIYedf(u"ࡔࡳࡷࡨ៴")
	if OHdwbjqtmVCgv1pcBR96Qxf5AoyKD or qjSK1N24JItMUwm5: jMa8ep9rlVfgoWYD1x2KsnJHI = sRth5giAQzWlEVm7JOX(u"ࡇࡣ࡯ࡷࡪ៵")
	if ZP1Vsjb6xznUcoQFltvme: Q8e7GvtsDJqZT = YB5xyI7MaRslVpv(u"ࠪࡔࡔ࡙ࡔࠨኩ")
	H7agXMdxq32DwufZ,ag6Mwkfe2YZ5CdTNOLjyob3 = -k5dztomYyN3H(u"࠵ᜟ"),UxS67uoGThbMwnfNRzy4gajLd23JH(u"࡚ࠫࡴ࡫࡯ࡱࡺࡲࠥࡋࡲࡳࡱࡵࠫኪ")
	for k3Om08MCgqQao4n1 in range(hhlbF1Sns5TrEN8QPCYmL4(u"࠾ᜠ")):
		BBxHc7SZakNEb0YmfwCDyRqI = NVS30xAdRFMIw1n9CislkE2(u"ࡖࡵࡹࡪ៶")
		tUEvo5HAfIjZgcdYxNJ8awu = NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࡉࡥࡱࡹࡥ៷")
		try:
			if k3Om08MCgqQao4n1: mxM8XR1eQOyYcSkuH = C2jP0iLNGKnHu9xp(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔ࠯࠴ࡷࡹ࠭ካ")
			if GGBaUXTPRxz1Jn2yp48dVvs5O3Wc6Q or not AtD7Q3TkzreHS: GGDIbyLQYfvdjAMi9(sRth5giAQzWlEVm7JOX(u"࠭ࡒࡆࡓࡘࡉࡘ࡚ࡓࠡࠢࡒࡔࡊࡔ࡟ࡖࡔࡏࠫኬ"),bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,toAVQS46Fv8aJYyLf25KnkUNC,eIL9BxdTbZj,mxM8XR1eQOyYcSkuH,Q8e7GvtsDJqZT)
			try: UMNteoHlkEy3Yf.close()
			except: pass
			QAKdHzO0rehbtyIc = bJEs4IVAPdyUrhwCLv9k2YoOl8nt1
			UMNteoHlkEy3Yf = jYUlINd7Vk09LBeZFrunTaSgG.request(Q8e7GvtsDJqZT,bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,data=toAVQS46Fv8aJYyLf25KnkUNC,headers=eIL9BxdTbZj,verify=verify,allow_redirects=jMa8ep9rlVfgoWYD1x2KsnJHI,timeout=bbeYVRCXkUzsmN39,proxies=hNiVUOX8SD62ybZ5mgC)
			if NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠹࠰࠱ᜡ")<=UMNteoHlkEy3Yf.status_code<=l0WAe1f7Bpi5ZXk(u"࠳࠺࠻ᜢ"):
				if not oWpmUZd0Qb46vN7RTjgOixutSHe:
					A3zxM6Zdb9n = list(UMNteoHlkEy3Yf.headers.keys())
					if FGDJwkEbTB5SoXujs3f(u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩክ") in A3zxM6Zdb9n: bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = UMNteoHlkEy3Yf.headers[UnWjVbo503mEMv9KF(u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪኮ")]
					elif EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠩ࡯ࡳࡨࡧࡴࡪࡱࡱࠫኯ") in A3zxM6Zdb9n: bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = UMNteoHlkEy3Yf.headers[NVS30xAdRFMIw1n9CislkE2(u"ࠪࡰࡴࡩࡡࡵ࡫ࡲࡲࠬኰ")]
					else: oWpmUZd0Qb46vN7RTjgOixutSHe = LgpdP3UjFRnlX(u"ࡘࡷࡻࡥ៸")
					if not oWpmUZd0Qb46vN7RTjgOixutSHe: bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = bJEs4IVAPdyUrhwCLv9k2YoOl8nt1.encode(gItVahxL0w(u"ࠫࡱࡧࡴࡪࡰ࠰࠵ࠬ኱"),fY5wTlhtnOc0Er6sdy4k87b(u"ࠬ࡯ࡧ࡯ࡱࡵࡩࠬኲ")).decode(WMkAjB1RgN7q(u"࠭ࡵࡵࡨ࠻ࠫኳ"),YB5xyI7MaRslVpv(u"ࠧࡪࡩࡱࡳࡷ࡫ࠧኴ"))
					if OHdwbjqtmVCgv1pcBR96Qxf5AoyKD and UMNteoHlkEy3Yf.status_code==UnWjVbo503mEMv9KF(u"࠴࠲࠺ᜣ"):
						jMa8ep9rlVfgoWYD1x2KsnJHI = qjSK1N24JItMUwm5
						Q8e7GvtsDJqZT = ww2vqCObJMBYRUaDyuWQ0
						oWpmUZd0Qb46vN7RTjgOixutSHe = sRth5giAQzWlEVm7JOX(u"࡙ࡸࡵࡦ៹")
						OihTKel5MgapQBf7EG6c1I
				if not oWpmUZd0Qb46vN7RTjgOixutSHe or qjSK1N24JItMUwm5:
					if UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠨࡪࡷࡸࡵ࠭ኵ") not in bJEs4IVAPdyUrhwCLv9k2YoOl8nt1:
						TIVwNYi9bCgDf7PQS0O = ooq2D9xF8ZLpPBs(QAKdHzO0rehbtyIc,QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠩࡸࡶࡱ࠭኶"))
						bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = TIVwNYi9bCgDf7PQS0O+hhlbF1Sns5TrEN8QPCYmL4(u"ࠪ࠳ࠬ኷")+bJEs4IVAPdyUrhwCLv9k2YoOl8nt1.lstrip(jx7s8T0BFgODXLMzIYedf(u"ࠫ࠴࠭ኸ"))
				if not oWpmUZd0Qb46vN7RTjgOixutSHe and qjSK1N24JItMUwm5 and not REGCdFbgy4Vvu2ieLqNMlxntY(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1): epdDNMWwgV
			elif C2dgEDAKQGsvh(u"࠸࠹࠵ᜥ")<=UMNteoHlkEy3Yf.status_code<=T6wRistc1SCo4hqObgumK(u"࠷࠼࠽ᜤ"):
				UMNteoHlkEy3Yf.reason = UMNteoHlkEy3Yf.content
				dwbeP59FZWzMyUxBgSpqtuI4n = LgpdP3UjFRnlX(u"࡚ࡲࡶࡧ៺")
			QAKdHzO0rehbtyIc = UMNteoHlkEy3Yf.url
			H7agXMdxq32DwufZ = UMNteoHlkEy3Yf.status_code
			ag6Mwkfe2YZ5CdTNOLjyob3 = UMNteoHlkEy3Yf.reason
			UMNteoHlkEy3Yf.raise_for_status()
			tUEvo5HAfIjZgcdYxNJ8awu = rbjsM8cRFiuA1(u"ࡔࡳࡷࡨ៻")
		except jYUlINd7Vk09LBeZFrunTaSgG.exceptions.HTTPError as Kx45lGUDX6Ejpk9Qs3nvfLuWNATBY:
			pass
		except jYUlINd7Vk09LBeZFrunTaSgG.exceptions.Timeout as Kx45lGUDX6Ejpk9Qs3nvfLuWNATBY:
			if V8fmEML1b0PeaRZySnzh3H5J9: ag6Mwkfe2YZ5CdTNOLjyob3 = str(Kx45lGUDX6Ejpk9Qs3nvfLuWNATBY.message).split(QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠬࡀࠠࠨኹ"))[BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠵ᜦ")]
			else: ag6Mwkfe2YZ5CdTNOLjyob3 = str(Kx45lGUDX6Ejpk9Qs3nvfLuWNATBY).split(C2dgEDAKQGsvh(u"࠭࠺ࠡࠩኺ"))[V2RbfGOBdcA6l8NTsPWzEyvS7(u"࠶ᜧ")]
		except jYUlINd7Vk09LBeZFrunTaSgG.exceptions.ConnectionError as Kx45lGUDX6Ejpk9Qs3nvfLuWNATBY:
			try: tnOo1QlfFN98JVG6vreRLxb0 = Kx45lGUDX6Ejpk9Qs3nvfLuWNATBY.message[NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠶ᜨ")]
			except: tnOo1QlfFN98JVG6vreRLxb0 = str(Kx45lGUDX6Ejpk9Qs3nvfLuWNATBY)
			yg2k8qerPuGAZ0Ocapl = My7Dwqvs6bfGNSIgX.findall(WMkAjB1RgN7q(u"ࠢ࡝࡝ࡈࡶࡷࡴ࡯ࠡࠪ࡟ࡨ࠰࠯࡜࡞ࠢࠫ࠲࠯ࡅࠩࠨࠤኻ"),tnOo1QlfFN98JVG6vreRLxb0)
			if not yg2k8qerPuGAZ0Ocapl: yg2k8qerPuGAZ0Ocapl = My7Dwqvs6bfGNSIgX.findall(FGDJwkEbTB5SoXujs3f(u"ࠣ࠮ࠣࡩࡷࡸ࡯ࡳ࡞ࠫࠬࡡࡪࠫࠪ࠮ࠣࠫ࠭࠴ࠪࡀࠫࠪࠦኼ"),tnOo1QlfFN98JVG6vreRLxb0)
			if not yg2k8qerPuGAZ0Ocapl:
				GCTSgsF3JZADb = My7Dwqvs6bfGNSIgX.findall(v5EA6TqHX3s4jzBMk(u"ࠤ࠽ࠤ࠭࠴ࠪࡀࠫ࠽࠲࠯ࡅࠨ࡝ࡦ࠮࠭࠿ࠨኽ"),tnOo1QlfFN98JVG6vreRLxb0)
				if GCTSgsF3JZADb: yg2k8qerPuGAZ0Ocapl = [GCTSgsF3JZADb[WMkAjB1RgN7q(u"࠱ᜪ")][BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠱ᜩ")],GCTSgsF3JZADb[WMkAjB1RgN7q(u"࠱ᜪ")][WMkAjB1RgN7q(u"࠱ᜪ")]]
			if not yg2k8qerPuGAZ0Ocapl: yg2k8qerPuGAZ0Ocapl = My7Dwqvs6bfGNSIgX.findall(WMkAjB1RgN7q(u"ࠥ࠾࠭ࡢࡤࠬࠫ࠽ࠤ࠭࠴ࠪࡀࠫࠪࠦኾ"),tnOo1QlfFN98JVG6vreRLxb0)
			if not yg2k8qerPuGAZ0Ocapl: yg2k8qerPuGAZ0Ocapl = My7Dwqvs6bfGNSIgX.findall(NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠦࠥ࠮࡜ࡥ࠭ࠬࡡࠥ࠮࠮ࠫࡁࠬࠫࠧ኿"),tnOo1QlfFN98JVG6vreRLxb0)
			try: H7agXMdxq32DwufZ,ag6Mwkfe2YZ5CdTNOLjyob3 = yg2k8qerPuGAZ0Ocapl[UxS67uoGThbMwnfNRzy4gajLd23JH(u"࠲ᜫ")]
			except: H7agXMdxq32DwufZ,ag6Mwkfe2YZ5CdTNOLjyob3 = -vvHpKfcqRnrFzjG(u"࠵ᜬ"),tnOo1QlfFN98JVG6vreRLxb0
			if jx7s8T0BFgODXLMzIYedf(u"ࠬ࠳ࡍࡆࡐࡘ࠱ࠬዀ") in iW6eqtHJGnzFhTSgduj7Pys2w or vvHpKfcqRnrFzjG(u"࠭࠭ࡔࡇࡄࡖࡈࡎ࠭ࠨ዁") in iW6eqtHJGnzFhTSgduj7Pys2w:
				BAk1NiuR7H2sVl6(PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࡇࡣ࡯ࡷࡪ៼"))
				gj7BGM5t3RZpA0vNixLqzwualb16(YB5xyI7MaRslVpv(u"ࠧ็ฮะฮࠥ฿ๅๅ์ฬࠫዂ"),sRth5giAQzWlEVm7JOX(u"ࠨฬะำ๏ัࠠา๊สฬ฼ࠦวๅ็๋ห็฿ࠧዃ"),KBxPW9cX8dqtaUDG=C2dgEDAKQGsvh(u"࠻࠺࠶ᜭ"))
				PapzBZgIekhJ5Fq8rDR2wOxTnu(b05yftsZ6NYgIKP(u"ࠩࡉࡳࡷࡩࡥࡥࠢࡨࡼ࡮ࡺࠠࡵࡱࠣࡥࡵࡶ࡬ࡺࠢࡱࡩࡼࠦࡷࡦࡤࡶ࡭ࡹ࡫ࡳࠡࡪࡲࡷࡹࡹࠠ࡯ࡣࡰࡩࡸ࠭ዄ"))
		except jYUlINd7Vk09LBeZFrunTaSgG.exceptions.RequestException as Kx45lGUDX6Ejpk9Qs3nvfLuWNATBY:
			if V8fmEML1b0PeaRZySnzh3H5J9: ag6Mwkfe2YZ5CdTNOLjyob3 = Kx45lGUDX6Ejpk9Qs3nvfLuWNATBY.message
			else: ag6Mwkfe2YZ5CdTNOLjyob3 = str(Kx45lGUDX6Ejpk9Qs3nvfLuWNATBY)
		except:
			BBxHc7SZakNEb0YmfwCDyRqI = vvHpKfcqRnrFzjG(u"ࡈࡤࡰࡸ࡫៽")
			try: H7agXMdxq32DwufZ = UMNteoHlkEy3Yf.status_code
			except: pass
			try: ag6Mwkfe2YZ5CdTNOLjyob3 = UMNteoHlkEy3Yf.reason
			except: pass
		ag6Mwkfe2YZ5CdTNOLjyob3 = str(ag6Mwkfe2YZ5CdTNOLjyob3)
		Lmj1pfQk63XdoeH(RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠪࡒࡔ࡚ࡉࡄࡇࠪዅ"),v5EA6TqHX3s4jzBMk(u"ࠫ࠳ࠦࠠࡐࡒࡈࡒ࡚ࡘࡌࡠࡔࡈࡕ࡚ࡋࡓࡕࡕࠣࠤࡗࡋࡓࡑࡑࡑࡗࡊࠦࠠࡄࡱࡧࡩ࠿࡛ࠦࠡࠩ዆")+str(H7agXMdxq32DwufZ)+jx7s8T0BFgODXLMzIYedf(u"ࠬࠦ࡝ࠡࠢࠣࡖࡪࡧࡳࡰࡰ࠽ࠤࡠࠦࠧ዇")+ag6Mwkfe2YZ5CdTNOLjyob3+LgpdP3UjFRnlX(u"࠭ࠠ࡞ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨወ")+iW6eqtHJGnzFhTSgduj7Pys2w+v5EA6TqHX3s4jzBMk(u"ࠧࠡ࡟ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭ዉ")+qmr7vLh1EW+WMkAjB1RgN7q(u"ࠨࠢࡠࠫዊ"))
		if jRcobP6zyKhDZGMm and OHdwbjqtmVCgv1pcBR96Qxf5AoyKD and BBxHc7SZakNEb0YmfwCDyRqI and not dwbeP59FZWzMyUxBgSpqtuI4n and H7agXMdxq32DwufZ!=BmcLzCFjuIrZP5fwXH18aN6YS(u"࠷࠶࠰ᜮ"):
			bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = fHzMLJKg7BYTbqX4Sea3d1s2vAZOw
			dwbeP59FZWzMyUxBgSpqtuI4n = gItVahxL0w(u"ࡗࡶࡺ࡫៾")
			continue
		if BBxHc7SZakNEb0YmfwCDyRqI: break
	if RRfNT13COItMrPdJlEgq!=None and h7cjS8YXyNqgQPsk4WLlG3x!=BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠩࡖࡘࡔࡖࠧዋ"): TKqMD4sua2vfi9nt5rxJ3j.create_connection = PPtwhC61ajNgWXyuRIzMUiKnQv3T
	if h7cjS8YXyNqgQPsk4WLlG3x==UnWjVbo503mEMv9KF(u"ࠪࡅࡑ࡝ࡁ࡚ࡕࠪዌ") and zDq8xpdJFG4tfaWkC: RRfNT13COItMrPdJlEgq = None
	if not tUEvo5HAfIjZgcdYxNJ8awu and eG5xjWgRUhC8f==None and iW6eqtHJGnzFhTSgduj7Pys2w not in ANr5yaiVH3xW8YIJbCX6c:
		WFMmPzdINGnfvRC1BoeOpb5 = N3JR6Bk5lVxnfGdgvQb.format_exc()
		if WFMmPzdINGnfvRC1BoeOpb5!=BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠫࡓࡵ࡮ࡦࡖࡼࡴࡪࡀࠠࡏࡱࡱࡩࡡࡴࠧው"): ehpURIi6QBDOGu8qj5EYzXrsWHJ7.stderr.write(WFMmPzdINGnfvRC1BoeOpb5)
	TOzKqRwpa6WrVMH8Pxy4X = U5uGTZvbxOmKaDspiCLcg()
	if GGBaUXTPRxz1Jn2yp48dVvs5O3Wc6Q: QAKdHzO0rehbtyIc = dCLtUe1Q0f
	TOzKqRwpa6WrVMH8Pxy4X.url = QAKdHzO0rehbtyIc
	TOzKqRwpa6WrVMH8Pxy4X.scrape = GGBaUXTPRxz1Jn2yp48dVvs5O3Wc6Q
	try: g1WVsCvmfTj7xpGHBb52F3hLDck = UMNteoHlkEy3Yf.content
	except: g1WVsCvmfTj7xpGHBb52F3hLDck = BoWHNb9daQVCF16A(u"ࠬ࠭ዎ")
	try: BBqyRvJdCfXe6ro29EcL = UMNteoHlkEy3Yf.headers
	except: BBqyRvJdCfXe6ro29EcL = {}
	try: A08TKYrQaiJWGm = UMNteoHlkEy3Yf.cookies.get_dict()
	except: A08TKYrQaiJWGm = {}
	try: UMNteoHlkEy3Yf.close()
	except: pass
	if BLz7m2RkNrxXQwy1cGAp:
		try: g1WVsCvmfTj7xpGHBb52F3hLDck = g1WVsCvmfTj7xpGHBb52F3hLDck.decode(qbPw1d3KimF(u"࠭ࡵࡵࡨ࠻ࠫዏ"))
		except: pass
	H7agXMdxq32DwufZ = int(H7agXMdxq32DwufZ)
	TOzKqRwpa6WrVMH8Pxy4X.code = H7agXMdxq32DwufZ
	TOzKqRwpa6WrVMH8Pxy4X.reason = ag6Mwkfe2YZ5CdTNOLjyob3
	TOzKqRwpa6WrVMH8Pxy4X.content = g1WVsCvmfTj7xpGHBb52F3hLDck
	TOzKqRwpa6WrVMH8Pxy4X.headers = BBqyRvJdCfXe6ro29EcL
	TOzKqRwpa6WrVMH8Pxy4X.cookies = A08TKYrQaiJWGm
	TOzKqRwpa6WrVMH8Pxy4X.succeeded = tUEvo5HAfIjZgcdYxNJ8awu
	TOzKqRwpa6WrVMH8Pxy4X.scrapernumber = BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠧࠨዐ")
	TOzKqRwpa6WrVMH8Pxy4X.scraperserver = jx7s8T0BFgODXLMzIYedf(u"ࠨࠩዑ")
	TOzKqRwpa6WrVMH8Pxy4X.scraperurl = k5dztomYyN3H(u"ࠩࠪዒ")
	if V8fmEML1b0PeaRZySnzh3H5J9 or isinstance(TOzKqRwpa6WrVMH8Pxy4X.content,str): A4lFyBz3wR5i = TOzKqRwpa6WrVMH8Pxy4X.content.lower()
	else: A4lFyBz3wR5i = jx7s8T0BFgODXLMzIYedf(u"ࠪࠫዓ")
	F1LtjSdUrKpG9kXsWYAOxvTe = (C2dgEDAKQGsvh(u"ࠫࡨࡲ࡯ࡶࡦࡩࡰࡦࡸࡥࠨዔ") in A4lFyBz3wR5i or BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠬ࡭࡯ࡰࡩ࡯ࡩࠬዕ") in A4lFyBz3wR5i) and A4lFyBz3wR5i.count(v5EA6TqHX3s4jzBMk(u"࠭ࡲࡦࡥࡤࡴࡹࡩࡨࡢࠩዖ"))>C2dgEDAKQGsvh(u"࠸ᜯ") and LgpdP3UjFRnlX(u"ࠧࡇࡃࡖࡉࡑࡎࡄ࠲ࠩ዗") not in iW6eqtHJGnzFhTSgduj7Pys2w and WMkAjB1RgN7q(u"ࠨࡴࡨࡧࡦࡶࡴࡤࡪࡤ࠱ࡹࡵ࡫ࡦࡰࠪዘ") not in A4lFyBz3wR5i and not GGBaUXTPRxz1Jn2yp48dVvs5O3Wc6Q
	if H7agXMdxq32DwufZ==b05yftsZ6NYgIKP(u"࠲࠱࠲ᜰ") and F1LtjSdUrKpG9kXsWYAOxvTe: TOzKqRwpa6WrVMH8Pxy4X.succeeded = qbPw1d3KimF(u"ࡊࡦࡲࡳࡦ៿")
	if TOzKqRwpa6WrVMH8Pxy4X.succeeded and jRcobP6zyKhDZGMm and OHdwbjqtmVCgv1pcBR96Qxf5AoyKD:
		if n7odetkK9SuTR5gi2U3NH0ELDxf8: t3BcCYTsvR = NVS30xAdRFMIw1n9CislkE2(u"ࠩࡆࡅࡕ࡚ࡃࡉࡃࠪዙ")+toAVQS46Fv8aJYyLf25KnkUNC[hhlbF1Sns5TrEN8QPCYmL4(u"ࠪ࡮ࡴࡨࠧዚ")].upper().replace(LgpdP3UjFRnlX(u"ࠫࡌࡋࡔࠨዛ"),gItVahxL0w(u"ࠬ࠭ዜ"))
		yuJ6MIgav237VYzWUpwsilGktqd95r = KfuaVn4XrSGTUtLIw(t3BcCYTsvR)
	if not TOzKqRwpa6WrVMH8Pxy4X.succeeded and jRcobP6zyKhDZGMm:
		yyT01vaXKQLDcer = (qbPw1d3KimF(u"࠭ࡣ࡭ࡱࡸࡨ࡫ࡲࡡࡳࡧࠪዝ") in A4lFyBz3wR5i and nr5mZG89ICi6cgt4MfLJa0(u"ࠧࡳࡣࡼࠤ࡮ࡪ࠺ࠡࠩዞ") in A4lFyBz3wR5i)
		CD2iTUVPed4JuwmWayf3zHGjBrgb = (LgpdP3UjFRnlX(u"ࠨ࠷ࠣࡷࡪࡩࠧዟ") in A4lFyBz3wR5i and vvHpKfcqRnrFzjG(u"ࠩࡥࡶࡴࡽࡳࡦࡴࠪዠ") in A4lFyBz3wR5i)
		p32vhXrIlRTKJL4goFdQbHaDBE = (H7agXMdxq32DwufZ in [FGDJwkEbTB5SoXujs3f(u"࠵࠲࠶ᜱ")] and V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠪࡩࡷࡸ࡯ࡳࠢࡦࡳࡩ࡫࠺ࠡ࠳࠳࠶࠵࠭ዡ") in A4lFyBz3wR5i)
		SJqnC5Bg7D3hEoecv2TbxjNQHls6rd = (YB5xyI7MaRslVpv(u"ࠫࡤࡩࡦࡠࡥ࡫ࡰࡤ࠭ዢ") in A4lFyBz3wR5i and k5dztomYyN3H(u"ࠬࡩࡨࡢ࡮࡯ࡩࡳ࡭ࡥ࠮ࠩዣ") in A4lFyBz3wR5i)
		if   F1LtjSdUrKpG9kXsWYAOxvTe: ag6Mwkfe2YZ5CdTNOLjyob3 = RqldvxFuM5GEQ2HAz93o7afBb0(u"࠭ࡂ࡭ࡱࡦ࡯ࡪࡪࠠࡣࡻࠣࡶࡪࡩࡡࡱࡶࡦ࡬ࡦ࠭ዤ")
		elif yyT01vaXKQLDcer: ag6Mwkfe2YZ5CdTNOLjyob3 = NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠧࡃ࡮ࡲࡧࡰ࡫ࡤࠡࡤࡼࠤࡨࡲ࡯ࡶࡦࡩࡰࡦࡸࡥࠨዥ")
		elif CD2iTUVPed4JuwmWayf3zHGjBrgb: ag6Mwkfe2YZ5CdTNOLjyob3 = qbPw1d3KimF(u"ࠨࡄ࡯ࡳࡨࡱࡥࡥࠢࡥࡽࠥ࠻ࠠࡴࡧࡦࡳࡳࡪࡳࠡࡤࡵࡳࡼࡹࡥࡳࠢࡦ࡬ࡪࡩ࡫ࠨዦ")
		elif p32vhXrIlRTKJL4goFdQbHaDBE: ag6Mwkfe2YZ5CdTNOLjyob3 = nr5mZG89ICi6cgt4MfLJa0(u"ࠩࡅࡰࡴࡩ࡫ࡦࡦࠣࡦࡾࠦࡣ࡭ࡱࡸࡨ࡫ࡲࡡࡳࡧࠣࡥࡨࡩࡥࡴࡵࠣࡨࡪࡴࡩࡦࡦࠪዧ")
		elif SJqnC5Bg7D3hEoecv2TbxjNQHls6rd: ag6Mwkfe2YZ5CdTNOLjyob3 = v5EA6TqHX3s4jzBMk(u"ࠪࡆࡱࡵࡣ࡬ࡧࡧࠤࡧࡿࠠࡤ࡮ࡲࡹࡩ࡬࡬ࡢࡴࡨࠤࡸ࡫ࡣࡶࡴ࡬ࡸࡾࠦࡣࡩࡧࡦ࡯ࠬየ")
		else: ag6Mwkfe2YZ5CdTNOLjyob3 = str(ag6Mwkfe2YZ5CdTNOLjyob3)
		if iW6eqtHJGnzFhTSgduj7Pys2w in zzmwQTLFExKo63AJh: pass
		elif iW6eqtHJGnzFhTSgduj7Pys2w in ANr5yaiVH3xW8YIJbCX6c:
			Lmj1pfQk63XdoeH(nr5mZG89ICi6cgt4MfLJa0(u"ࠫࡓࡕࡔࡊࡅࡈࡣࡑࡏࡎࡆࡕࠪዩ"),Dwl0N6FKuVU8nB1mbisIrCzdO(baNWS6nfqTC5iX4Kl)+nr5mZG89ICi6cgt4MfLJa0(u"ࠬࠦࠠࡅ࡫ࡵࡩࡨࡺࠠࡤࡱࡱࡲࡪࡩࡴࡪࡱࡱࠤ࡫ࡧࡩ࡭ࡧࡧࠤࠥࠦࡃࡰࡦࡨ࠾ࠥࡡࠠࠨዪ")+str(H7agXMdxq32DwufZ)+jSu5Cg2Ub1OAkZVs8Yoz(u"࠭ࠠ࡞ࠢࠣࡖࡪࡧࡳࡰࡰ࠽ࠤࡠࠦࠧያ")+ag6Mwkfe2YZ5CdTNOLjyob3+PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠧࠡ࡟ࠣࠤ࡙ࠥ࡯ࡶࡴࡦࡩ࠿࡛ࠦࠡࠩዬ")+iW6eqtHJGnzFhTSgduj7Pys2w+LgpdP3UjFRnlX(u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧይ")+bJEs4IVAPdyUrhwCLv9k2YoOl8nt1+v5EA6TqHX3s4jzBMk(u"ࠩࠣࡡࠬዮ"))
		else: Lmj1pfQk63XdoeH(UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨዯ"),Dwl0N6FKuVU8nB1mbisIrCzdO(baNWS6nfqTC5iX4Kl)+EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠫࠥࠦࠠࡅ࡫ࡵࡩࡨࡺࠠࡤࡱࡱࡲࡪࡩࡴࡪࡱࡱࠤ࡫ࡧࡩ࡭ࡧࡧࠤࠥࠦࡃࡰࡦࡨ࠾ࠥࡡࠠࠨደ")+str(H7agXMdxq32DwufZ)+RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠬࠦ࡝ࠡࠢࡕࡩࡦࡹ࡯࡯࠼ࠣ࡟ࠥ࠭ዱ")+ag6Mwkfe2YZ5CdTNOLjyob3+PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"࠭ࠠ࡞ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨዲ")+iW6eqtHJGnzFhTSgduj7Pys2w+UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠧࠡ࡟ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭ዳ")+bJEs4IVAPdyUrhwCLv9k2YoOl8nt1+EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠨࠢࡠࠫዴ"))
		BIoZXmFxlw3RWr0 = dCLtUe1Q0f if GGBaUXTPRxz1Jn2yp48dVvs5O3Wc6Q else XnQbsZF0Ouh8p7zCdUN(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1)
		if V8fmEML1b0PeaRZySnzh3H5J9 and isinstance(BIoZXmFxlw3RWr0,unicode): BIoZXmFxlw3RWr0 = BIoZXmFxlw3RWr0.encode(FGDJwkEbTB5SoXujs3f(u"ࠩࡸࡸ࡫࠾ࠧድ"))
		if OHdwbjqtmVCgv1pcBR96Qxf5AoyKD: BIoZXmFxlw3RWr0 = BIoZXmFxlw3RWr0.split(hhlbF1Sns5TrEN8QPCYmL4(u"ࠪ࠳ࠬዶ"))[-BmcLzCFjuIrZP5fwXH18aN6YS(u"࠳ᜲ")]
		MEDAXujV903GgsUwKxhCt4YFrvmQ = str(ag6Mwkfe2YZ5CdTNOLjyob3)+b05yftsZ6NYgIKP(u"ࠫࡡࡴࠨࠡࠩዷ")+BIoZXmFxlw3RWr0+gItVahxL0w(u"ࠬࠦࠩࠨዸ")
		if H7agXMdxq32DwufZ in [-BoWHNb9daQVCF16A(u"࠴ᜳ"),-LgpdP3UjFRnlX(u"࠶᜴")] or F1LtjSdUrKpG9kXsWYAOxvTe or yyT01vaXKQLDcer or CD2iTUVPed4JuwmWayf3zHGjBrgb or p32vhXrIlRTKJL4goFdQbHaDBE or SJqnC5Bg7D3hEoecv2TbxjNQHls6rd:
			TOzKqRwpa6WrVMH8Pxy4X.code = -rbjsM8cRFiuA1(u"࠸᜵")
			TOzKqRwpa6WrVMH8Pxy4X.reason = ag6Mwkfe2YZ5CdTNOLjyob3
			if Hc6aUQPngo07iKjNGr:
				v7vwGSMHyJ4NEPBfx = hvM0qAJpxu84Zg175KDYaW(ww2vqCObJMBYRUaDyuWQ0,bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,toAVQS46Fv8aJYyLf25KnkUNC,eIL9BxdTbZj,qjSK1N24JItMUwm5,KKqZXkwNI5uP3vU9jrbJoyg,iW6eqtHJGnzFhTSgduj7Pys2w,H7agXMdxq32DwufZ,ag6Mwkfe2YZ5CdTNOLjyob3)
				if v7vwGSMHyJ4NEPBfx.succeeded: return v7vwGSMHyJ4NEPBfx
		tLwvQlnjGpWsRVCN1 = WMkAjB1RgN7q(u"࡙ࡸࡵࡦ᠀")
		if (h7cjS8YXyNqgQPsk4WLlG3x==gItVahxL0w(u"࠭ࡁࡔࡍࠪዹ") or NMWlwz87p6EmSGx2Uy1i9h4VfCrnI==hhlbF1Sns5TrEN8QPCYmL4(u"ࠧࡂࡕࡎࠫዺ")) and (zDq8xpdJFG4tfaWkC or Hc6aUQPngo07iKjNGr):
			tLwvQlnjGpWsRVCN1 = kpASjm2iFqNCb4c5I(H7agXMdxq32DwufZ,MEDAXujV903GgsUwKxhCt4YFrvmQ,iW6eqtHJGnzFhTSgduj7Pys2w,KKqZXkwNI5uP3vU9jrbJoyg)
			if tLwvQlnjGpWsRVCN1 and h7cjS8YXyNqgQPsk4WLlG3x==EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠨࡃࡖࡏࠬዻ"): h7cjS8YXyNqgQPsk4WLlG3x = UnWjVbo503mEMv9KF(u"ࠩࡄࡇࡈࡋࡐࡕࡇࡇࠫዼ")
			else: h7cjS8YXyNqgQPsk4WLlG3x = LgpdP3UjFRnlX(u"ࠪࡖࡊࡐࡅࡄࡖࡈࡈࠬዽ")
			if tLwvQlnjGpWsRVCN1 and NMWlwz87p6EmSGx2Uy1i9h4VfCrnI==PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠫࡆ࡙ࡋࠨዾ"): NMWlwz87p6EmSGx2Uy1i9h4VfCrnI = BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠬࡇࡃࡄࡇࡓࡘࡊࡊࠧዿ")
			else: NMWlwz87p6EmSGx2Uy1i9h4VfCrnI = hhlbF1Sns5TrEN8QPCYmL4(u"࠭ࡒࡆࡌࡈࡇ࡙ࡋࡄࠨጀ")
			bLEBi8IO7uU2x3htYDdVq95.setSetting(NVS30xAdRFMIw1n9CislkE2(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡹࡸ࡫ࡤ࡯ࡵࠪጁ"),h7cjS8YXyNqgQPsk4WLlG3x)
			bLEBi8IO7uU2x3htYDdVq95.setSetting(gItVahxL0w(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡺࡹࡥࡱࡴࡲࡼࡾ࠭ጂ"),NMWlwz87p6EmSGx2Uy1i9h4VfCrnI)
		if tLwvQlnjGpWsRVCN1:
			f2zsPmKiL4W1gMI9lhG = T6wRistc1SCo4hqObgumK(u"࡚ࡲࡶࡧ᠁")
			if H7agXMdxq32DwufZ==T6wRistc1SCo4hqObgumK(u"࠾᜶") and NVS30xAdRFMIw1n9CislkE2(u"ࠩ࡫ࡸࡹࡶࡳࠨጃ") in bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 and f2zsPmKiL4W1gMI9lhG:
				if KKqZXkwNI5uP3vU9jrbJoyg: gj7BGM5t3RZpA0vNixLqzwualb16(C2jP0iLNGKnHu9xp(u"ࠪฮๆ฿๊ๅࠢไัฺࠦิ่ษาอࠥอไหึไ๎ึࠦࡓࡔࡎࠪጄ"),UxS67uoGThbMwnfNRzy4gajLd23JH(u"้ࠫหีๅษะࠤฺ๊ใๅหࠣห้หๆหำ้๎ฯ࠭ጅ"),KBxPW9cX8dqtaUDG=FGDJwkEbTB5SoXujs3f(u"࠲࠱࠲࠳᜷"))
				QAKdHzO0rehbtyIc = bJEs4IVAPdyUrhwCLv9k2YoOl8nt1+qbPw1d3KimF(u"ࠬࢂࡼࡏࡱ࡙ࡩࡷ࡯ࡦࡺࡕࡖࡐࠬጆ")
				yuJ6MIgav237VYzWUpwsilGktqd95r = vcmTsFNY8wG9Z2xg(ww2vqCObJMBYRUaDyuWQ0,QAKdHzO0rehbtyIc,AqLgT4S6FExHi1kZ5smy7a0hRX,ib6URTIJnFlgVwXsQAN0ZGD4k9c3ph,IXuCzdlqv9WRAkLSt,KKqZXkwNI5uP3vU9jrbJoyg,BmcLzCFjuIrZP5fwXH18aN6YS(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠࡔࡈࡕ࡚ࡋࡓࡕࡕ࠰࠶ࡳࡪࠧጇ"))
				if yuJ6MIgav237VYzWUpwsilGktqd95r.succeeded:
					TOzKqRwpa6WrVMH8Pxy4X = yuJ6MIgav237VYzWUpwsilGktqd95r
					Lmj1pfQk63XdoeH(UnWjVbo503mEMv9KF(u"ࠧࡏࡑࡗࡍࡈࡋ࡟ࡍࡋࡑࡉࡘ࠭ገ"),Dwl0N6FKuVU8nB1mbisIrCzdO(baNWS6nfqTC5iX4Kl)+UnWjVbo503mEMv9KF(u"ࠨࠢࠣࠤࡘࡻࡣࡤࡧࡨࡨࡪࡪࠠࡶࡵ࡬ࡲ࡬ࠦࡓࡔࡎ࠽ࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪጉ")+iW6eqtHJGnzFhTSgduj7Pys2w+rbjsM8cRFiuA1(u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨጊ")+qmr7vLh1EW+NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠪࠤࡢ࠭ጋ"))
					if KKqZXkwNI5uP3vU9jrbJoyg: gj7BGM5t3RZpA0vNixLqzwualb16(qbPw1d3KimF(u"๋ࠫาวฮࠢหหุะฮะษ่ࠤࡘ࡙ࡌࠨጌ"),BmcLzCFjuIrZP5fwXH18aN6YS(u"๊ࠬลึๆสั๋ࠥิไๆฬࠤฬ๊ล็ฬิ๊๏ะࠧግ"),KBxPW9cX8dqtaUDG=RqldvxFuM5GEQ2HAz93o7afBb0(u"࠳࠲࠳࠴᜸"))
				else:
					Lmj1pfQk63XdoeH(PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫጎ"),Dwl0N6FKuVU8nB1mbisIrCzdO(baNWS6nfqTC5iX4Kl)+vvHpKfcqRnrFzjG(u"ࠧࠡࠢࠣࡊࡦ࡯࡬ࡦࡦࠣࡹࡸ࡯࡮ࡨࠢࡖࡗࡑࡀࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭ጏ")+iW6eqtHJGnzFhTSgduj7Pys2w+UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧጐ")+qmr7vLh1EW+l0WAe1f7Bpi5ZXk(u"ࠩࠣࡡࠬ጑"))
					if KKqZXkwNI5uP3vU9jrbJoyg: gj7BGM5t3RZpA0vNixLqzwualb16(v5EA6TqHX3s4jzBMk(u"ࠪๅู๊ࠠษษึฮำีวๆࠢࡖࡗࡑ࠭ጒ"),jx7s8T0BFgODXLMzIYedf(u"้ࠫหีๅษะࠤฺ๊ใๅหࠣห้หๆหำ้๎ฯ࠭ጓ"),KBxPW9cX8dqtaUDG=hhlbF1Sns5TrEN8QPCYmL4(u"࠴࠳࠴࠵᜹"))
			if not TOzKqRwpa6WrVMH8Pxy4X.succeeded and NMWlwz87p6EmSGx2Uy1i9h4VfCrnI in [BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠬࡇࡕࡕࡑࠪጔ"),hhlbF1Sns5TrEN8QPCYmL4(u"࠭ࡁࡄࡅࡈࡔ࡙ࡋࡄࠨጕ")] and Hc6aUQPngo07iKjNGr:
				if KKqZXkwNI5uP3vU9jrbJoyg: gj7BGM5t3RZpA0vNixLqzwualb16(RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠧหใ฼๎้ࠦำ๋ำไีฬะࠠษำ๋็ุ๐ࠧ጖"),LgpdP3UjFRnlX(u"ࠨๆศู้ออࠡ็ื็้ฯࠠศๆศ๊ฯืๆ๋ฬࠪ጗"),KBxPW9cX8dqtaUDG=FGDJwkEbTB5SoXujs3f(u"࠵࠴࠵࠶᜺"))
				yuJ6MIgav237VYzWUpwsilGktqd95r = pzGctwNK4xhaCTI6X7u(ww2vqCObJMBYRUaDyuWQ0,bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,AqLgT4S6FExHi1kZ5smy7a0hRX,ib6URTIJnFlgVwXsQAN0ZGD4k9c3ph,IXuCzdlqv9WRAkLSt,KKqZXkwNI5uP3vU9jrbJoyg,iW6eqtHJGnzFhTSgduj7Pys2w)
				if yuJ6MIgav237VYzWUpwsilGktqd95r.succeeded:
					TOzKqRwpa6WrVMH8Pxy4X = yuJ6MIgav237VYzWUpwsilGktqd95r
					Lmj1pfQk63XdoeH(BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠩࡑࡓ࡙ࡏࡃࡆࡡࡏࡍࡓࡋࡓࠨጘ"),Dwl0N6FKuVU8nB1mbisIrCzdO(baNWS6nfqTC5iX4Kl)+WMkAjB1RgN7q(u"ࠪࠤࠥࠦࡐࡳࡱࡻ࡭ࡪࡹࠠࡴࡷࡦࡧࡪ࡫ࡤࡦࡦ࠽ࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪጙ")+iW6eqtHJGnzFhTSgduj7Pys2w+gItVahxL0w(u"ࠫࠥࡣࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪጚ")+qmr7vLh1EW+qbPw1d3KimF(u"ࠬࠦ࡝ࠨጛ"))
					if KKqZXkwNI5uP3vU9jrbJoyg: gj7BGM5t3RZpA0vNixLqzwualb16(C2jP0iLNGKnHu9xp(u"࠭ๆอษะࠤุ๐ัโำสฮࠥฮั้ๅึ๎ࠬጜ"),C2dgEDAKQGsvh(u"ࠧๅวุ่ฬำࠠๆึๆ่ฮࠦวๅว้ฮึ์๊หࠩጝ"),KBxPW9cX8dqtaUDG=l0WAe1f7Bpi5ZXk(u"࠶࠵࠶࠰᜻"))
				else:
					Lmj1pfQk63XdoeH(fY5wTlhtnOc0Er6sdy4k87b(u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭ጞ"),Dwl0N6FKuVU8nB1mbisIrCzdO(baNWS6nfqTC5iX4Kl)+sRth5giAQzWlEVm7JOX(u"ࠩࠣࠤࠥࡖࡲࡰࡺ࡬ࡩࡸࠦࡦࡢ࡫࡯ࡩࡩࡀࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭ጟ")+iW6eqtHJGnzFhTSgduj7Pys2w+k5dztomYyN3H(u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩጠ")+qmr7vLh1EW+rbjsM8cRFiuA1(u"ࠫࠥࡣࠧጡ"))
					if KKqZXkwNI5uP3vU9jrbJoyg: gj7BGM5t3RZpA0vNixLqzwualb16(qbPw1d3KimF(u"ࠬ็ิๅࠢึ๎ึ็ัศฬࠣฬึ๎ใิ์ࠪጢ"),hhlbF1Sns5TrEN8QPCYmL4(u"࠭ไฦื็หาࠦๅีๅ็อࠥอไฦ่อี๋๐สࠨጣ"),KBxPW9cX8dqtaUDG=T6wRistc1SCo4hqObgumK(u"࠷࠶࠰࠱᜼"))
			if not TOzKqRwpa6WrVMH8Pxy4X.succeeded and h7cjS8YXyNqgQPsk4WLlG3x in [BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠧࡂࡗࡗࡓࠬጤ"),UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠨࡃࡆࡇࡊࡖࡔࡆࡆࠪጥ")] and zDq8xpdJFG4tfaWkC:
				if KKqZXkwNI5uP3vU9jrbJoyg: gj7BGM5t3RZpA0vNixLqzwualb16(QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠩอๅ฾๐ไࠡีํีๆืࠠࡅࡐࡖࠫጦ"),jSu5Cg2Ub1OAkZVs8Yoz(u"่ࠪส฻ไศฯู้้ࠣไสࠢส่ส์สา่ํฮࠬጧ"),KBxPW9cX8dqtaUDG=gItVahxL0w(u"࠸࠰࠱࠲᜽"))
				QAKdHzO0rehbtyIc = bJEs4IVAPdyUrhwCLv9k2YoOl8nt1+QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠫࢁࢂࡍࡺࡆࡑࡗ࡚ࡸ࡬࠾ࠩጨ")
				yuJ6MIgav237VYzWUpwsilGktqd95r = vcmTsFNY8wG9Z2xg(ww2vqCObJMBYRUaDyuWQ0,QAKdHzO0rehbtyIc,AqLgT4S6FExHi1kZ5smy7a0hRX,ib6URTIJnFlgVwXsQAN0ZGD4k9c3ph,IXuCzdlqv9WRAkLSt,KKqZXkwNI5uP3vU9jrbJoyg,hhlbF1Sns5TrEN8QPCYmL4(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔ࠯࠷ࡸ࡭࠭ጩ"))
				if yuJ6MIgav237VYzWUpwsilGktqd95r.succeeded:
					TOzKqRwpa6WrVMH8Pxy4X = yuJ6MIgav237VYzWUpwsilGktqd95r
					Lmj1pfQk63XdoeH(RqldvxFuM5GEQ2HAz93o7afBb0(u"࠭ࡎࡐࡖࡌࡇࡊࡥࡌࡊࡐࡈࡗࠬጪ"),Dwl0N6FKuVU8nB1mbisIrCzdO(baNWS6nfqTC5iX4Kl)+C2dgEDAKQGsvh(u"ࠧࠡࠢࠣࡈࡓ࡙ࠠࡴࡷࡦࡧࡪ࡫ࡤࡦࡦ࠽ࠤࠥࠦࡄࡏࡕ࠽ࠤࡠࠦࠧጫ")+WiQBzwAIa6GvLC79Jr3h0F5uosjbRy+EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠨࠢࡠࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪጬ")+iW6eqtHJGnzFhTSgduj7Pys2w+b05yftsZ6NYgIKP(u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨጭ")+qmr7vLh1EW+QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠪࠤࡢ࠭ጮ"))
					if KKqZXkwNI5uP3vU9jrbJoyg: gj7BGM5t3RZpA0vNixLqzwualb16(FGDJwkEbTB5SoXujs3f(u"๋ࠫาวฮࠢึ๎ึ็ัࠡࡆࡑࡗࠬጯ"),qbPw1d3KimF(u"๊ࠬลึๆสั๋ࠥิไๆฬࠤฬ๊ล็ฬิ๊๏ะࠧጰ"),KBxPW9cX8dqtaUDG=NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠲࠱࠲࠳᜾"))
				else:
					Lmj1pfQk63XdoeH(nr5mZG89ICi6cgt4MfLJa0(u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫጱ"),Dwl0N6FKuVU8nB1mbisIrCzdO(baNWS6nfqTC5iX4Kl)+T6wRistc1SCo4hqObgumK(u"ࠧࠡࠢࠣࡈࡓ࡙ࠠࡧࡣ࡬ࡰࡪࡪ࠺ࠡࠢࠣࡈࡓ࡙࠺ࠡ࡝ࠣࠫጲ")+WiQBzwAIa6GvLC79Jr3h0F5uosjbRy+NVS30xAdRFMIw1n9CislkE2(u"ࠨࠢࡠࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪጳ")+iW6eqtHJGnzFhTSgduj7Pys2w+BoWHNb9daQVCF16A(u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨጴ")+qmr7vLh1EW+LgpdP3UjFRnlX(u"ࠪࠤࡢ࠭ጵ"))
					if KKqZXkwNI5uP3vU9jrbJoyg: gj7BGM5t3RZpA0vNixLqzwualb16(l0WAe1f7Bpi5ZXk(u"ࠫๆฺไࠡีํีๆืࠠࡅࡐࡖࠫጶ"),rbjsM8cRFiuA1(u"๊ࠬลึๆสั๋ࠥิไๆฬࠤฬ๊ล็ฬิ๊๏ะࠧጷ"),KBxPW9cX8dqtaUDG=gItVahxL0w(u"࠳࠲࠳࠴᜿"))
		if NMWlwz87p6EmSGx2Uy1i9h4VfCrnI==v5EA6TqHX3s4jzBMk(u"࠭ࡒࡆࡌࡈࡇ࡙ࡋࡄࠨጸ") or h7cjS8YXyNqgQPsk4WLlG3x==NVS30xAdRFMIw1n9CislkE2(u"ࠧࡓࡇࡍࡉࡈ࡚ࡅࡅࠩጹ"): KKqZXkwNI5uP3vU9jrbJoyg = BoWHNb9daQVCF16A(u"ࡆࡢ࡮ࡶࡩ᠂")
		if not TOzKqRwpa6WrVMH8Pxy4X.succeeded:
			if KKqZXkwNI5uP3vU9jrbJoyg: QIEqzVMA59NtdyjD0e8PcJalx = kpASjm2iFqNCb4c5I(H7agXMdxq32DwufZ,MEDAXujV903GgsUwKxhCt4YFrvmQ,iW6eqtHJGnzFhTSgduj7Pys2w,KKqZXkwNI5uP3vU9jrbJoyg)
			if H7agXMdxq32DwufZ!=WMkAjB1RgN7q(u"࠴࠳࠴ᝀ") and iW6eqtHJGnzFhTSgduj7Pys2w not in LMalnNAQePRTyUc2pm9FoKG and hhlbF1Sns5TrEN8QPCYmL4(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࠬጺ") not in iW6eqtHJGnzFhTSgduj7Pys2w:
				PapzBZgIekhJ5Fq8rDR2wOxTnu(jx7s8T0BFgODXLMzIYedf(u"ࠩࡉࡳࡷࡩࡥࡥࠢࡨࡼ࡮ࡺࠠࡥࡷࡨࠤࡹࡵࠠ࡯ࡧࡷࡻࡴࡸ࡫ࠡ࡫ࡶࡷࡺ࡫ࡳࠡࡹ࡬ࡸ࡭ࡀࠠࠨጻ")+iW6eqtHJGnzFhTSgduj7Pys2w)
	if bLEBi8IO7uU2x3htYDdVq95.getSetting(BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡵࡴࡧࡧࡲࡸ࠭ጼ")) not in [fY5wTlhtnOc0Er6sdy4k87b(u"ࠫࡆ࡛ࡔࡐࠩጽ"),k5dztomYyN3H(u"࡙ࠬࡔࡐࡒࠪጾ"),FGDJwkEbTB5SoXujs3f(u"࠭ࡁࡔࡍࠪጿ")]: bLEBi8IO7uU2x3htYDdVq95.setSetting(jx7s8T0BFgODXLMzIYedf(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡹࡸ࡫ࡤ࡯ࡵࠪፀ"),BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠨࡃࡖࡏࠬፁ"))
	if bLEBi8IO7uU2x3htYDdVq95.getSetting(qbPw1d3KimF(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡲࡵࡳࡽࡿࠧፂ")) not in [BoWHNb9daQVCF16A(u"ࠪࡅ࡚࡚ࡏࠨፃ"),V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠫࡘ࡚ࡏࡑࠩፄ"),qbPw1d3KimF(u"ࠬࡇࡓࡌࠩፅ")]: bLEBi8IO7uU2x3htYDdVq95.setSetting(k5dztomYyN3H(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡸࡷࡪࡶࡲࡰࡺࡼࠫፆ"),BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠧࡂࡕࡎࠫፇ"))
	return TOzKqRwpa6WrVMH8Pxy4X
def hvM0qAJpxu84Zg175KDYaW(ww2vqCObJMBYRUaDyuWQ0,bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,toAVQS46Fv8aJYyLf25KnkUNC,eIL9BxdTbZj,qjSK1N24JItMUwm5,KKqZXkwNI5uP3vU9jrbJoyg,iW6eqtHJGnzFhTSgduj7Pys2w,H7agXMdxq32DwufZ,ag6Mwkfe2YZ5CdTNOLjyob3):
	gj7BGM5t3RZpA0vNixLqzwualb16(RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠨสาวฯูࠦๆๆํอࠥะฬศ๊ีࠤฬ๊ออสࠪፈ"),YB5xyI7MaRslVpv(u"ࠩࠪፉ"),KBxPW9cX8dqtaUDG=LgpdP3UjFRnlX(u"࠺࠹࠵ᝁ"))
	Lmj1pfQk63XdoeH(EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠪࡒࡔ࡚ࡉࡄࡇࡢࡐࡎࡔࡅࡔࠩፊ"),Dwl0N6FKuVU8nB1mbisIrCzdO(baNWS6nfqTC5iX4Kl)+UnWjVbo503mEMv9KF(u"ࠫࠥࠦࠠࠡࡖࡵࡽ࡮ࡴࡧࠡࡤࡼࡴࡦࡹࡳࡪࡰࡪࠤࡧࡲ࡯ࡤ࡭࡬ࡲ࡬ࠦࠠࠡࡅࡲࡨࡪࡀࠠ࡜ࠢࠪፋ")+str(H7agXMdxq32DwufZ)+hhlbF1Sns5TrEN8QPCYmL4(u"ࠬࠦ࡝ࠡࠢࡕࡩࡦࡹ࡯࡯࠼ࠣ࡟ࠥ࠭ፌ")+ag6Mwkfe2YZ5CdTNOLjyob3+l0WAe1f7Bpi5ZXk(u"࠭ࠠ࡞ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨፍ")+iW6eqtHJGnzFhTSgduj7Pys2w+RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠧࠡ࡟ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭ፎ")+bJEs4IVAPdyUrhwCLv9k2YoOl8nt1+gItVahxL0w(u"ࠨࠢࡠࠫፏ"))
	yXF6n5DJoBg2VQN4vSkhlr = bLEBi8IO7uU2x3htYDdVq95.getSetting(RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠩࡤࡺ࠳࡬ࡡࡪ࡮ࡨࡨ࠳ࡹࡣࡢࡴࡳࡩࡵࡸ࡯ࡹࡻ࠴ࠫፐ"))
	UEZji4DYlHM5Fd2JIwBCG3 = bLEBi8IO7uU2x3htYDdVq95.getSetting(LgpdP3UjFRnlX(u"ࠪࡥࡻ࠴ࡦࡢ࡫࡯ࡩࡩ࠴ࡳࡤࡣࡵࡴࡪࡶࡲࡰࡺࡼ࠶ࠬፑ"))
	uNCisgDOmrIU7oLYpEwP0b53zKBTn = bLEBi8IO7uU2x3htYDdVq95.getSetting(NVS30xAdRFMIw1n9CislkE2(u"ࠫࡦࡼ࠮ࡧࡣ࡬ࡰࡪࡪ࠮ࡴࡥࡤࡶࡵ࡫ࡰࡳࡱࡻࡽ࠸࠭ፒ"))
	SSZUYtX1kOgReiI = bLEBi8IO7uU2x3htYDdVq95.getSetting(BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠬࡧࡶ࠯ࡨࡤ࡭ࡱ࡫ࡤ࠯ࡵࡦࡥࡷࡶࡥࡱࡴࡲࡼࡾ࠺ࠧፓ"))
	yXF6n5DJoBg2VQN4vSkhlr = BmcLzCFjuIrZP5fwXH18aN6YS(u"࠴ᝂ") if not yXF6n5DJoBg2VQN4vSkhlr else int(yXF6n5DJoBg2VQN4vSkhlr)
	UEZji4DYlHM5Fd2JIwBCG3 = NVS30xAdRFMIw1n9CislkE2(u"࠵ᝃ") if not UEZji4DYlHM5Fd2JIwBCG3 else int(UEZji4DYlHM5Fd2JIwBCG3)
	uNCisgDOmrIU7oLYpEwP0b53zKBTn = qbPw1d3KimF(u"࠶ᝄ") if not uNCisgDOmrIU7oLYpEwP0b53zKBTn else int(uNCisgDOmrIU7oLYpEwP0b53zKBTn)
	SSZUYtX1kOgReiI = hhlbF1Sns5TrEN8QPCYmL4(u"࠰ᝅ") if not SSZUYtX1kOgReiI else int(SSZUYtX1kOgReiI)
	eiAcEDUhyBqvxwN = yXF6n5DJoBg2VQN4vSkhlr>LgpdP3UjFRnlX(u"࠴ᝆ") and UEZji4DYlHM5Fd2JIwBCG3>LgpdP3UjFRnlX(u"࠴ᝆ") and uNCisgDOmrIU7oLYpEwP0b53zKBTn>LgpdP3UjFRnlX(u"࠴ᝆ") and SSZUYtX1kOgReiI>LgpdP3UjFRnlX(u"࠴ᝆ")
	if eiAcEDUhyBqvxwN:
		bLEBi8IO7uU2x3htYDdVq95.setSetting(rbjsM8cRFiuA1(u"࠭ࡡࡷ࠰ࡩࡥ࡮ࡲࡥࡥ࠰ࡶࡧࡦࡸࡰࡦࡲࡵࡳࡽࡿ࠱ࠨፔ"),EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠧࠨፕ"))
		bLEBi8IO7uU2x3htYDdVq95.setSetting(RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠨࡣࡹ࠲࡫ࡧࡩ࡭ࡧࡧ࠲ࡸࡩࡡࡳࡲࡨࡴࡷࡵࡸࡺ࠴ࠪፖ"),v5EA6TqHX3s4jzBMk(u"ࠩࠪፗ"))
		bLEBi8IO7uU2x3htYDdVq95.setSetting(BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠪࡥࡻ࠴ࡦࡢ࡫࡯ࡩࡩ࠴ࡳࡤࡣࡵࡴࡪࡶࡲࡰࡺࡼ࠷ࠬፘ"),rbjsM8cRFiuA1(u"ࠫࠬፙ"))
		bLEBi8IO7uU2x3htYDdVq95.setSetting(RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠬࡧࡶ࠯ࡨࡤ࡭ࡱ࡫ࡤ࠯ࡵࡦࡥࡷࡶࡥࡱࡴࡲࡼࡾ࠺ࠧፚ"),YB5xyI7MaRslVpv(u"࠭ࠧ፛"))
	ddmwe1gLh0oRiVZpMzXO5KEW = []
	if eiAcEDUhyBqvxwN or yXF6n5DJoBg2VQN4vSkhlr<=UnWjVbo503mEMv9KF(u"࠶ᝈ"): ddmwe1gLh0oRiVZpMzXO5KEW += [BmcLzCFjuIrZP5fwXH18aN6YS(u"࠳ᝇ"),BmcLzCFjuIrZP5fwXH18aN6YS(u"࠳ᝇ"),BmcLzCFjuIrZP5fwXH18aN6YS(u"࠳ᝇ"),BmcLzCFjuIrZP5fwXH18aN6YS(u"࠳ᝇ")]
	if eiAcEDUhyBqvxwN or UEZji4DYlHM5Fd2JIwBCG3<=fY5wTlhtnOc0Er6sdy4k87b(u"࠷ᝉ"): ddmwe1gLh0oRiVZpMzXO5KEW += [NVS30xAdRFMIw1n9CislkE2(u"࠷ᝊ"),NVS30xAdRFMIw1n9CislkE2(u"࠷ᝊ")]
	if eiAcEDUhyBqvxwN or uNCisgDOmrIU7oLYpEwP0b53zKBTn<=BmcLzCFjuIrZP5fwXH18aN6YS(u"࠹ᝋ"): ddmwe1gLh0oRiVZpMzXO5KEW += [BmcLzCFjuIrZP5fwXH18aN6YS(u"࠹ᝋ")]
	if not eIL9BxdTbZj and (eiAcEDUhyBqvxwN or SSZUYtX1kOgReiI<=FGDJwkEbTB5SoXujs3f(u"࠳ᝌ")): ddmwe1gLh0oRiVZpMzXO5KEW += [BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠵ᝍ"),BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠵ᝍ"),BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠵ᝍ"),BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠵ᝍ"),BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠵ᝍ"),BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠵ᝍ"),BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠵ᝍ"),BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠵ᝍ")]
	if WMkAjB1RgN7q(u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖࠩ፜") in iW6eqtHJGnzFhTSgduj7Pys2w: VPru1RnTbOJgCzilc = BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠶ᝎ")
	else:
		y86DWh5H2FlKrToedpbx = bLEBi8IO7uU2x3htYDdVq95.getSetting(UnWjVbo503mEMv9KF(u"ࠨࡣࡹ࠲ࡵࡸ࡯ࡹࡻ࠱ࡷࡨࡸࡡࡱࡧࡧࡳ࠹࠭፝"))
		Kg63Jt05iaCoudD = bLEBi8IO7uU2x3htYDdVq95.getSetting(gItVahxL0w(u"ࠩࡤࡺ࠳ࡶࡲࡰࡺࡼ࠲ࡸࡩࡲࡢࡲࡨࡨࡴ࠻ࠧ፞"))
		y86DWh5H2FlKrToedpbx = hhlbF1Sns5TrEN8QPCYmL4(u"࠼࠽࠾࠿ᝏ") if not y86DWh5H2FlKrToedpbx else int(y86DWh5H2FlKrToedpbx)
		Kg63Jt05iaCoudD = FGDJwkEbTB5SoXujs3f(u"࠽࠾࠿࠹ᝐ") if not Kg63Jt05iaCoudD else int(Kg63Jt05iaCoudD)
		if y86DWh5H2FlKrToedpbx>BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠷࠶ᝑ"): ddmwe1gLh0oRiVZpMzXO5KEW.append(QynMHGWA0blfqTUdxRh5Jzi2t(u"࠺ᝒ"))
		if Kg63Jt05iaCoudD>FGDJwkEbTB5SoXujs3f(u"࠳࠲᝔"): ddmwe1gLh0oRiVZpMzXO5KEW.append(rbjsM8cRFiuA1(u"࠵ᝓ"))
		VPru1RnTbOJgCzilc = SS503hkALwlNIvHYW7jb.sample(ddmwe1gLh0oRiVZpMzXO5KEW,C2jP0iLNGKnHu9xp(u"࠳᝕"))[hhlbF1Sns5TrEN8QPCYmL4(u"࠳᝖")]
	if VPru1RnTbOJgCzilc==b05yftsZ6NYgIKP(u"࠵᝗"):
		scraperserver = WMkAjB1RgN7q(u"ࠪࡷࡨࡸࡡࡱ࡫ࡱ࡫ࡦࡴࡴࠨ፟")
		fwinqZAl8BtcksWbEHh7 = jx7s8T0BFgODXLMzIYedf(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡸࡩࡲࡢࡲ࡬ࡲ࡬ࡧ࡮ࡵࠨࡳࡶࡴࡾࡹࡠࡥࡲࡹࡳࡺࡲࡺ࠿ࡄࡉࠫࡨࡲࡰࡹࡶࡩࡷࡃࡦࡢ࡮ࡶࡩࠫ࡬࡯ࡳࡹࡤࡶࡩࡥࡨࡦࡣࡧࡩࡷࡹ࠽ࡵࡴࡸࡩ࠿࠸ࡢ࠴࠶࠳ࡥ࠻࠾࠹࠱ࡣ࠸࠸࠵࠷ࡤࡣࡥ࠶࠻࠷ࡩ࠱࠲࠶࠸ࡨ࠾࠼࠲ࡦ࠺ࡃࡴࡷࡵࡸࡺ࠰ࡶࡧࡷࡧࡰࡪࡰࡪࡥࡳࡺ࠮ࡤࡱࡰ࠾࠽࠶࠸࠱ࠩ፠")
		UnFC90p8KGPSwHJrV = bJEs4IVAPdyUrhwCLv9k2YoOl8nt1+UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠬࢂࡼࡎࡻࡓࡶࡴࡾࡹࡖࡴ࡯ࡁࠬ፡")+fwinqZAl8BtcksWbEHh7+b05yftsZ6NYgIKP(u"࠭ࡼࡽࡐࡲ࡚ࡪࡸࡩࡧࡻࡖࡗࡑ࠭።")
		v7vwGSMHyJ4NEPBfx = vcmTsFNY8wG9Z2xg(ww2vqCObJMBYRUaDyuWQ0,UnFC90p8KGPSwHJrV,toAVQS46Fv8aJYyLf25KnkUNC,eIL9BxdTbZj,qjSK1N24JItMUwm5,KKqZXkwNI5uP3vU9jrbJoyg,iW6eqtHJGnzFhTSgduj7Pys2w,BoWHNb9daQVCF16A(u"ࡇࡣ࡯ࡷࡪ᠃"),BoWHNb9daQVCF16A(u"ࡇࡣ࡯ࡷࡪ᠃"))
		OcBEDKjFTmeWPQzHgMv = NVS30xAdRFMIw1n9CislkE2(u"ࠧࠨ፣") if v7vwGSMHyJ4NEPBfx.succeeded else str(yXF6n5DJoBg2VQN4vSkhlr+l0WAe1f7Bpi5ZXk(u"࠶᝘"))
		bLEBi8IO7uU2x3htYDdVq95.setSetting(qbPw1d3KimF(u"ࠨࡣࡹ࠲࡫ࡧࡩ࡭ࡧࡧ࠲ࡸࡩࡡࡳࡲࡨࡴࡷࡵࡸࡺ࠳ࠪ፤"),OcBEDKjFTmeWPQzHgMv)
	elif VPru1RnTbOJgCzilc==NVS30xAdRFMIw1n9CislkE2(u"࠸᝙"):
		scraperserver = v5EA6TqHX3s4jzBMk(u"ࠩࡶࡧࡷࡧࡰࡦࡱࡳࡷࠬ፥")
		fwinqZAl8BtcksWbEHh7 = BoWHNb9daQVCF16A(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡷࡨࡸࡡࡱࡧࡲࡴࡸ࠴࡫ࡦࡧࡳࡣ࡭࡫ࡡࡥࡧࡵࡷࡂࡺࡲࡶࡧ࠽ࡦ࠷ࡩ࠲ࡧࡥ࠸࠽࠲࠾ࡦࡥ࠲࠰࠸ࡨ࠸ࡤ࠮࠻࠴࠺ࡨ࠳ࡢࡤ࠹࠶࠻࠾࠾࠰ࡤࡧ࠵ࡥࡅࡶࡲࡰࡺࡼ࠲ࡸࡩࡲࡢࡲࡨࡳࡵࡹ࠮ࡪࡱ࠽࠹࠸࠻࠳ࠨ፦")
		UnFC90p8KGPSwHJrV = bJEs4IVAPdyUrhwCLv9k2YoOl8nt1+FGDJwkEbTB5SoXujs3f(u"ࠫࢁࢂࡍࡺࡒࡵࡳࡽࡿࡕࡳ࡮ࡀࠫ፧")+fwinqZAl8BtcksWbEHh7+hhlbF1Sns5TrEN8QPCYmL4(u"ࠬࢂࡼࡏࡱ࡙ࡩࡷ࡯ࡦࡺࡕࡖࡐࠬ፨")
		v7vwGSMHyJ4NEPBfx = vcmTsFNY8wG9Z2xg(ww2vqCObJMBYRUaDyuWQ0,UnFC90p8KGPSwHJrV,toAVQS46Fv8aJYyLf25KnkUNC,eIL9BxdTbZj,qjSK1N24JItMUwm5,KKqZXkwNI5uP3vU9jrbJoyg,iW6eqtHJGnzFhTSgduj7Pys2w,QynMHGWA0blfqTUdxRh5Jzi2t(u"ࡈࡤࡰࡸ࡫᠄"),QynMHGWA0blfqTUdxRh5Jzi2t(u"ࡈࡤࡰࡸ࡫᠄"))
		OcBEDKjFTmeWPQzHgMv = v5EA6TqHX3s4jzBMk(u"࠭ࠧ፩") if v7vwGSMHyJ4NEPBfx.succeeded else str(UEZji4DYlHM5Fd2JIwBCG3+l0WAe1f7Bpi5ZXk(u"࠱᝚"))
		bLEBi8IO7uU2x3htYDdVq95.setSetting(nr5mZG89ICi6cgt4MfLJa0(u"ࠧࡢࡸ࠱ࡪࡦ࡯࡬ࡦࡦ࠱ࡷࡨࡧࡲࡱࡧࡳࡶࡴࡾࡹ࠳ࠩ፪"),OcBEDKjFTmeWPQzHgMv)
	elif VPru1RnTbOJgCzilc==jSu5Cg2Ub1OAkZVs8Yoz(u"࠴᝛"):
		scraperserver = b05yftsZ6NYgIKP(u"ࠨࡵࡦࡶࡦࡶࡥࡳࡣࡳ࡭ࠬ፫")
		fwinqZAl8BtcksWbEHh7 = EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡶࡧࡷࡧࡰࡦࡴࡤࡴ࡮࠴࡫ࡦࡧࡳࡣ࡭࡫ࡡࡥࡧࡵࡷࡂࡺࡲࡶࡧ࠽࠻࠻ࡨ࠴ࡧࡥ࠶࠸࡫ࡩࡤ࠲࠻ࡧ࠽ࡨ࠻࠵ࡢ࠳࠸ࡪ࠸࠼࠰࠵ࡥࡧ࠽࠶࠺ࡣࡁࡲࡵࡳࡽࡿ࠭ࡴࡧࡵࡺࡪࡸ࠮ࡴࡥࡵࡥࡵ࡫ࡲࡢࡲ࡬࠲ࡨࡵ࡭࠻࠺࠳࠴࠶࠭፬")
		UnFC90p8KGPSwHJrV = bJEs4IVAPdyUrhwCLv9k2YoOl8nt1+jx7s8T0BFgODXLMzIYedf(u"ࠪࢀࢁࡓࡹࡑࡴࡲࡼࡾ࡛ࡲ࡭࠿ࠪ፭")+fwinqZAl8BtcksWbEHh7+b05yftsZ6NYgIKP(u"ࠫࢁࢂࡎࡰࡘࡨࡶ࡮࡬ࡹࡔࡕࡏࠫ፮")
		v7vwGSMHyJ4NEPBfx = vcmTsFNY8wG9Z2xg(ww2vqCObJMBYRUaDyuWQ0,UnFC90p8KGPSwHJrV,toAVQS46Fv8aJYyLf25KnkUNC,eIL9BxdTbZj,qjSK1N24JItMUwm5,KKqZXkwNI5uP3vU9jrbJoyg,iW6eqtHJGnzFhTSgduj7Pys2w,BmcLzCFjuIrZP5fwXH18aN6YS(u"ࡉࡥࡱࡹࡥ᠅"),BmcLzCFjuIrZP5fwXH18aN6YS(u"ࡉࡥࡱࡹࡥ᠅"))
		OcBEDKjFTmeWPQzHgMv = gItVahxL0w(u"ࠬ࠭፯") if v7vwGSMHyJ4NEPBfx.succeeded else str(uNCisgDOmrIU7oLYpEwP0b53zKBTn+BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠳᝜"))
		bLEBi8IO7uU2x3htYDdVq95.setSetting(BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠭ࡡࡷ࠰ࡩࡥ࡮ࡲࡥࡥ࠰ࡶࡧࡦࡸࡰࡦࡲࡵࡳࡽࡿ࠳ࠨ፰"),OcBEDKjFTmeWPQzHgMv)
	elif VPru1RnTbOJgCzilc==QynMHGWA0blfqTUdxRh5Jzi2t(u"࠷᝝"):
		scraperserver = EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠧࡴࡥࡵࡥࡵ࡫ࡵࡱࠩ፱")
		QAKdHzO0rehbtyIc = bJEs4IVAPdyUrhwCLv9k2YoOl8nt1.replace(jx7s8T0BFgODXLMzIYedf(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࠪ፲"),C2jP0iLNGKnHu9xp(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࠪ፳"))
		UnFC90p8KGPSwHJrV = FGDJwkEbTB5SoXujs3f(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡥࡵ࡯࠮ࡴࡥࡵࡥࡵ࡫ࡵࡱ࠰ࡦࡳࡲ࠵࠿ࡢࡲ࡬ࡣࡰ࡫ࡹ࠾࠳࡙ࡒࡸࡓࡴࡍ࠳ࡲࡆࡗ࡞࡫ࡔࡐࡆࡦࡈࡓࡊ࠲ࡍ࡛࡝ࡏࡰࡪ࠱ࡦ࡭࡞ࡼࠬ࡫ࡦࡧࡳࡣ࡭࡫ࡡࡥࡧࡵࡷࡂ࡬ࡡ࡭ࡵࡨࠪࡺࡸ࡬࠾ࠩ፴")+QAKdHzO0rehbtyIc
		v7vwGSMHyJ4NEPBfx = vcmTsFNY8wG9Z2xg(NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠫࡌࡋࡔࠨ፵"),UnFC90p8KGPSwHJrV,toAVQS46Fv8aJYyLf25KnkUNC,eIL9BxdTbZj,qjSK1N24JItMUwm5,KKqZXkwNI5uP3vU9jrbJoyg,iW6eqtHJGnzFhTSgduj7Pys2w,NVS30xAdRFMIw1n9CislkE2(u"ࡊࡦࡲࡳࡦ᠆"),NVS30xAdRFMIw1n9CislkE2(u"ࡊࡦࡲࡳࡦ᠆"))
		OcBEDKjFTmeWPQzHgMv = BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠬ࠭፶") if v7vwGSMHyJ4NEPBfx.succeeded else str(SSZUYtX1kOgReiI+WMkAjB1RgN7q(u"࠵᝞"))
		bLEBi8IO7uU2x3htYDdVq95.setSetting(vvHpKfcqRnrFzjG(u"࠭ࡡࡷ࠰ࡩࡥ࡮ࡲࡥࡥ࠰ࡶࡧࡦࡸࡰࡦࡲࡵࡳࡽࡿ࠴ࠨ፷"),OcBEDKjFTmeWPQzHgMv)
	elif VPru1RnTbOJgCzilc==UnWjVbo503mEMv9KF(u"࠾࠿࠹࠵᝟"):
		scraperserver = BoWHNb9daQVCF16A(u"ࠧࡴࡥࡵࡥࡵ࡫࠮ࡥࡱ࠴ࠫ፸")
		fwinqZAl8BtcksWbEHh7 = BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡥࡦ࠶࠻࠹ࡡࡣ࠳ࡨ࠹࠵࠺࠴ࡥ࠴ࡦࡥ࠺ࡪ࠵ࡥ࠵ࡩ࠽ࡪ࠹ࡣ࠴࠺࠹ࡩࡨࡧ࠱࠲࠲࠻࠷࠽࠿ࡡ࠸࠵࠽ࡧࡺࡹࡴࡰ࡯ࡋࡩࡦࡪࡥࡳࡵࡀࡸࡷࡻࡥࡁࡲࡵࡳࡽࡿ࠮ࡴࡥࡵࡥࡵ࡫࠮ࡥࡱ࠽࠼࠵࠾࠰ࠨ፹")
		UnFC90p8KGPSwHJrV = bJEs4IVAPdyUrhwCLv9k2YoOl8nt1+QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠩࡿࢀࡒࡿࡐࡳࡱࡻࡽ࡚ࡸ࡬࠾ࠩ፺")+fwinqZAl8BtcksWbEHh7+nr5mZG89ICi6cgt4MfLJa0(u"ࠪࢀࢁࡔ࡯ࡗࡧࡵ࡭࡫ࡿࡓࡔࡎࠪ፻")
		v7vwGSMHyJ4NEPBfx = vcmTsFNY8wG9Z2xg(ww2vqCObJMBYRUaDyuWQ0,UnFC90p8KGPSwHJrV,toAVQS46Fv8aJYyLf25KnkUNC,eIL9BxdTbZj,qjSK1N24JItMUwm5,KKqZXkwNI5uP3vU9jrbJoyg,iW6eqtHJGnzFhTSgduj7Pys2w,C2jP0iLNGKnHu9xp(u"ࡋࡧ࡬ࡴࡧ᠇"),C2jP0iLNGKnHu9xp(u"ࡋࡧ࡬ࡴࡧ᠇"))
		if PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠫࡘࡩࡲࡢࡲࡨ࠲ࡩࡵ࠭ࡓࡧࡰࡥ࡮ࡴࡩ࡯ࡩ࠰ࡇࡷ࡫ࡤࡪࡶࡶࠫ፼") in list(v7vwGSMHyJ4NEPBfx.headers.keys()):
			pJR2OmswKDaBXNkFG8ctzHjyM = v7vwGSMHyJ4NEPBfx.headers[YB5xyI7MaRslVpv(u"࡙ࠬࡣࡳࡣࡳࡩ࠳ࡪ࡯࠮ࡔࡨࡱࡦ࡯࡮ࡪࡰࡪ࠱ࡈࡸࡥࡥ࡫ࡷࡷࠬ፽")]
			bLEBi8IO7uU2x3htYDdVq95.setSetting(C2dgEDAKQGsvh(u"࠭ࡡࡷ࠰ࡳࡶࡴࡾࡹ࠯ࡵࡦࡶࡦࡶࡥࡥࡱ࠷ࠫ፾"),pJR2OmswKDaBXNkFG8ctzHjyM)
	elif VPru1RnTbOJgCzilc==UxS67uoGThbMwnfNRzy4gajLd23JH(u"࠿࠹࠺࠷ᝠ"):
		scraperserver = BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠧࡴࡥࡵࡥࡵ࡫࠮ࡥࡱ࠵ࠫ፿")
		fwinqZAl8BtcksWbEHh7 = jSu5Cg2Ub1OAkZVs8Yoz(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳ࡦ࠷ࡩ࠹ࡡࡦ࠳࠻࠹ࡩ࡬࠴ࡣࡨ࠹ࡥ࡫࠻࠳࠴ࡥ࠺࠴࠹࠶ࡢ࠴࠶࠺ࡧ࠾࡫࠹࠺ࡤࡨ࠸࠻࠼ࡡࡦ࠻࠽ࡧࡺࡹࡴࡰ࡯ࡋࡩࡦࡪࡥࡳࡵࡀࡸࡷࡻࡥࡁࡲࡵࡳࡽࡿ࠮ࡴࡥࡵࡥࡵ࡫࠮ࡥࡱ࠽࠼࠵࠾࠰ࠨᎀ")
		UnFC90p8KGPSwHJrV = bJEs4IVAPdyUrhwCLv9k2YoOl8nt1+YB5xyI7MaRslVpv(u"ࠩࡿࢀࡒࡿࡐࡳࡱࡻࡽ࡚ࡸ࡬࠾ࠩᎁ")+fwinqZAl8BtcksWbEHh7+QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠪࢀࢁࡔ࡯ࡗࡧࡵ࡭࡫ࡿࡓࡔࡎࠪᎂ")
		v7vwGSMHyJ4NEPBfx = vcmTsFNY8wG9Z2xg(ww2vqCObJMBYRUaDyuWQ0,UnFC90p8KGPSwHJrV,toAVQS46Fv8aJYyLf25KnkUNC,eIL9BxdTbZj,qjSK1N24JItMUwm5,KKqZXkwNI5uP3vU9jrbJoyg,iW6eqtHJGnzFhTSgduj7Pys2w,l0WAe1f7Bpi5ZXk(u"ࡌࡡ࡭ࡵࡨ᠈"),l0WAe1f7Bpi5ZXk(u"ࡌࡡ࡭ࡵࡨ᠈"))
		if qbPw1d3KimF(u"ࠫࡘࡩࡲࡢࡲࡨ࠲ࡩࡵ࠭ࡓࡧࡰࡥ࡮ࡴࡩ࡯ࡩ࠰ࡇࡷ࡫ࡤࡪࡶࡶࠫᎃ") in list(v7vwGSMHyJ4NEPBfx.headers.keys()):
			pJR2OmswKDaBXNkFG8ctzHjyM = v7vwGSMHyJ4NEPBfx.headers[C2dgEDAKQGsvh(u"࡙ࠬࡣࡳࡣࡳࡩ࠳ࡪ࡯࠮ࡔࡨࡱࡦ࡯࡮ࡪࡰࡪ࠱ࡈࡸࡥࡥ࡫ࡷࡷࠬᎄ")]
			bLEBi8IO7uU2x3htYDdVq95.setSetting(l0WAe1f7Bpi5ZXk(u"࠭ࡡࡷ࠰ࡳࡶࡴࡾࡹ࠯ࡵࡦࡶࡦࡶࡥࡥࡱ࠸ࠫᎅ"),pJR2OmswKDaBXNkFG8ctzHjyM)
	elif VPru1RnTbOJgCzilc==sRth5giAQzWlEVm7JOX(u"࠹࠺࠻࠶ᝡ"):
		scraperserver = UnWjVbo503mEMv9KF(u"ࠧࡴࡥࡵࡥࡵ࡯࡮ࡨࡴࡲࡦࡴࡺࠧᎆ")
		UnFC90p8KGPSwHJrV = C2jP0iLNGKnHu9xp(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡣࡳ࡭࠳ࡹࡣࡳࡣࡳ࡭ࡳ࡭ࡲࡰࡤࡲࡸ࠳ࡩ࡯࡮࠱ࡂࡸࡴࡱࡥ࡯࠿ࡤ࠸࡫࠽ࡦࡣ࠳࠷࠱࠷ࡪࡥࡧ࠯࠷࠴࠼࠷࠭࠹࠸࠷ࡦ࠲࠸࠲ࡦ࠵࠵࠺࠹ࡪ࠴ࡥࡦࡦࠪࡵࡸ࡯ࡹࡻࡆࡳࡺࡴࡴࡳࡻࡀࡎࡔࠬࡵࡳ࡮ࡀࠫᎇ")+F8fMqZKB4APk(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1)
		v7vwGSMHyJ4NEPBfx = vcmTsFNY8wG9Z2xg(EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠩࡊࡉ࡙࠭ᎈ"),UnFC90p8KGPSwHJrV,toAVQS46Fv8aJYyLf25KnkUNC,eIL9BxdTbZj,qjSK1N24JItMUwm5,KKqZXkwNI5uP3vU9jrbJoyg,iW6eqtHJGnzFhTSgduj7Pys2w,LgpdP3UjFRnlX(u"ࡆࡢ࡮ࡶࡩ᠉"),LgpdP3UjFRnlX(u"ࡆࡢ࡮ࡶࡩ᠉"))
		try:
			import json as C56R029JKDm
			v7vwGSMHyJ4NEPBfx.content = C56R029JKDm.dumps(v7vwGSMHyJ4NEPBfx.content)[b05yftsZ6NYgIKP(u"ࠪࡶࡪࡹࡵ࡭ࡶࠪᎉ")]
		except: pass
	elif VPru1RnTbOJgCzilc==YB5xyI7MaRslVpv(u"࠺࠻࠼࠵ᝢ"):
		scraperserver = LgpdP3UjFRnlX(u"ࠫࡸࡩࡲࡢࡲࡨࡳࡵࡹࠧᎊ")
		UnFC90p8KGPSwHJrV = EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡰࡳࡱࡻࡽ࠳ࡹࡣࡳࡣࡳࡩࡴࡶࡳ࠯࡫ࡲ࠳ࡻ࠷࠯ࡀࡣࡳ࡭ࡤࡱࡥࡺ࠿ࡥ࠶ࡨ࠸ࡦࡤ࠷࠼࠱࠽࡬ࡤ࠱࠯࠷ࡧ࠷ࡪ࠭࠺࠳࠹ࡧ࠲ࡨࡣ࠸࠵࠺࠽࠽࠶ࡣࡦ࠴ࡤࠪࡺࡸ࡬࠾ࠩᎋ")+bJEs4IVAPdyUrhwCLv9k2YoOl8nt1
		v7vwGSMHyJ4NEPBfx = vcmTsFNY8wG9Z2xg(k5dztomYyN3H(u"࠭ࡇࡆࡖࠪᎌ"),UnFC90p8KGPSwHJrV,toAVQS46Fv8aJYyLf25KnkUNC,eIL9BxdTbZj,qjSK1N24JItMUwm5,KKqZXkwNI5uP3vU9jrbJoyg,iW6eqtHJGnzFhTSgduj7Pys2w,UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࡇࡣ࡯ࡷࡪ᠊"),UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࡇࡣ࡯ࡷࡪ᠊"))
	else: scraperserver,UnFC90p8KGPSwHJrV = T6wRistc1SCo4hqObgumK(u"ࠧࠨᎍ"),gItVahxL0w(u"ࠨࠩᎎ")
	v7vwGSMHyJ4NEPBfx.scrapernumber = str(VPru1RnTbOJgCzilc)
	v7vwGSMHyJ4NEPBfx.scraperserver = scraperserver
	v7vwGSMHyJ4NEPBfx.scraperurl = UnFC90p8KGPSwHJrV
	uEsCzJoZ5fe7VgrkG = jSu5Cg2Ub1OAkZVs8Yoz(u"ࠩึ๎ึ็ัࠡำๅ้ࠥ࠭ᎏ")+v7vwGSMHyJ4NEPBfx.scrapernumber
	if v7vwGSMHyJ4NEPBfx.succeeded:
		Lmj1pfQk63XdoeH(jSu5Cg2Ub1OAkZVs8Yoz(u"ࠪࡒࡔ࡚ࡉࡄࡇࡢࡐࡎࡔࡅࡔࠩ᎐"),Dwl0N6FKuVU8nB1mbisIrCzdO(baNWS6nfqTC5iX4Kl)+jSu5Cg2Ub1OAkZVs8Yoz(u"ࠫࠥࠦࠠࠡࡕࡸࡧࡨ࡫ࡥࡥࡧࡧࠤࡧࡿࡰࡢࡵࡶ࡭ࡳ࡭ࠠࡣ࡮ࡲࡧࡰ࡯࡮ࡨࠢࠣࠤࡘ࡫ࡲࡷࡧࡵ࠾ࠥࡡࠠࠨ᎑")+scraperserver+NVS30xAdRFMIw1n9CislkE2(u"ࠬࠦ࡝ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧ᎒")+iW6eqtHJGnzFhTSgduj7Pys2w+sRth5giAQzWlEVm7JOX(u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ᎓")+bJEs4IVAPdyUrhwCLv9k2YoOl8nt1+QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠧࠡ࡟ࠪ᎔"))
		gj7BGM5t3RZpA0vNixLqzwualb16(l0WAe1f7Bpi5ZXk(u"ࠨ่ฯัฯูࠦๆๆํอࠥะฬศ๊ีࠤฬ๊ออสࠪ᎕"),uEsCzJoZ5fe7VgrkG,KBxPW9cX8dqtaUDG=nr5mZG89ICi6cgt4MfLJa0(u"࠹࠸࠴ᝣ"))
	else:
		Lmj1pfQk63XdoeH(hhlbF1Sns5TrEN8QPCYmL4(u"ࠩࡑࡓ࡙ࡏࡃࡆࡡࡏࡍࡓࡋࡓࠨ᎖"),Dwl0N6FKuVU8nB1mbisIrCzdO(baNWS6nfqTC5iX4Kl)+BoWHNb9daQVCF16A(u"ࠪࠤࠥࠦࠠࡇࡣ࡬ࡰࡪࡪࠠࡣࡻࡳࡥࡸࡹࡩ࡯ࡩࠣࡦࡱࡵࡣ࡬࡫ࡱ࡫ࠥࠦࠠࡔࡧࡵࡺࡪࡸ࠺ࠡ࡝ࠣࠫ᎗")+scraperserver+sRth5giAQzWlEVm7JOX(u"ࠫࠥࡣࠠࠡࠢࡆࡳࡩ࡫࠺ࠡ࡝ࠣࠫ᎘")+str(v7vwGSMHyJ4NEPBfx.code)+nr5mZG89ICi6cgt4MfLJa0(u"ࠬࠦ࡝ࠡࠢࡕࡩࡦࡹ࡯࡯࠼ࠣ࡟ࠥ࠭᎙")+v7vwGSMHyJ4NEPBfx.reason+EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠭ࠠ࡞ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨ᎚")+iW6eqtHJGnzFhTSgduj7Pys2w+EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠧࠡ࡟ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭᎛")+bJEs4IVAPdyUrhwCLv9k2YoOl8nt1+UnWjVbo503mEMv9KF(u"ࠨࠢࡠࠫ᎜"))
		gj7BGM5t3RZpA0vNixLqzwualb16(BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠩไุ้ะฺࠠ็็๎ฮࠦสอษ๋ึࠥอไฮฮหࠫ᎝"),uEsCzJoZ5fe7VgrkG,KBxPW9cX8dqtaUDG=fY5wTlhtnOc0Er6sdy4k87b(u"࠺࠹࠵ᝤ"))
	return v7vwGSMHyJ4NEPBfx
def mORwgTnXBdQ7iCSHKf(f0KUlmeMpWgFsPk16On,ww2vqCObJMBYRUaDyuWQ0,qmr7vLh1EW,AqLgT4S6FExHi1kZ5smy7a0hRX,ib6URTIJnFlgVwXsQAN0ZGD4k9c3ph,IXuCzdlqv9WRAkLSt,showDialogs,iW6eqtHJGnzFhTSgduj7Pys2w,T1haiwEgF2p7bnBJzVXRPUjrds=WMkAjB1RgN7q(u"ࠪࠫ᎞"),sVWmClxtR10p=jSu5Cg2Ub1OAkZVs8Yoz(u"ࠫࠬ᎟")):
	bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,eG5xjWgRUhC8f,RRfNT13COItMrPdJlEgq,nnDRPzg7XWmorOjQMtU5hxH = I1zAN6ZaFrhSfMojPKTLmiG2(qmr7vLh1EW)
	FatuQ5gf41DEVHjxBMKwbnyd7ziSl = ww2vqCObJMBYRUaDyuWQ0,bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,AqLgT4S6FExHi1kZ5smy7a0hRX,ib6URTIJnFlgVwXsQAN0ZGD4k9c3ph,IXuCzdlqv9WRAkLSt
	if f0KUlmeMpWgFsPk16On:
		UMNteoHlkEy3Yf = zPgNsqpJInt(RnqtMUa9Nh6peGEsBT,rbjsM8cRFiuA1(u"ࠬࡸࡥࡴࡲࡲࡲࡸ࡫ࠧᎠ"),sRth5giAQzWlEVm7JOX(u"࠭ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔࠩᎡ"),FatuQ5gf41DEVHjxBMKwbnyd7ziSl)
		if UMNteoHlkEy3Yf.succeeded:
			GGDIbyLQYfvdjAMi9(YB5xyI7MaRslVpv(u"ࠧࡓࡇࡔ࡙ࡊ࡙ࡔࡔࠢࠣࡖࡊࡇࡄࡠࡅࡄࡇࡍࡋࠧᎢ"),bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,AqLgT4S6FExHi1kZ5smy7a0hRX,ib6URTIJnFlgVwXsQAN0ZGD4k9c3ph,iW6eqtHJGnzFhTSgduj7Pys2w,ww2vqCObJMBYRUaDyuWQ0)
			return UMNteoHlkEy3Yf
	UMNteoHlkEy3Yf = vcmTsFNY8wG9Z2xg(ww2vqCObJMBYRUaDyuWQ0,qmr7vLh1EW,AqLgT4S6FExHi1kZ5smy7a0hRX,ib6URTIJnFlgVwXsQAN0ZGD4k9c3ph,IXuCzdlqv9WRAkLSt,showDialogs,iW6eqtHJGnzFhTSgduj7Pys2w,T1haiwEgF2p7bnBJzVXRPUjrds,sVWmClxtR10p)
	if UMNteoHlkEy3Yf.succeeded:
		if rbjsM8cRFiuA1(u"ࠨࡅࡌࡑࡆࡔࡏࡘࠩᎣ") in iW6eqtHJGnzFhTSgduj7Pys2w: UMNteoHlkEy3Yf.content = wuvsjzM2pegnkIAS3(UMNteoHlkEy3Yf.content)
		if UMNteoHlkEy3Yf.scrape: f0KUlmeMpWgFsPk16On = IIiPCruL6dT8s1lqj47SzpVHnYNm
		if f0KUlmeMpWgFsPk16On: VZ8BTik93OqXLCh0fD7d2KUPpn4mH6(RnqtMUa9Nh6peGEsBT,PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠩࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗࠬᎤ"),FatuQ5gf41DEVHjxBMKwbnyd7ziSl,UMNteoHlkEy3Yf,f0KUlmeMpWgFsPk16On)
	return UMNteoHlkEy3Yf
def YY0KEWamSIc46n3kbtuLgZV(f0KUlmeMpWgFsPk16On,qmr7vLh1EW,AqLgT4S6FExHi1kZ5smy7a0hRX,ib6URTIJnFlgVwXsQAN0ZGD4k9c3ph,showDialogs,iW6eqtHJGnzFhTSgduj7Pys2w):
	if not AqLgT4S6FExHi1kZ5smy7a0hRX or isinstance(AqLgT4S6FExHi1kZ5smy7a0hRX,dict): ww2vqCObJMBYRUaDyuWQ0 = jx7s8T0BFgODXLMzIYedf(u"ࠪࡋࡊ࡚ࠧᎥ")
	else:
		ww2vqCObJMBYRUaDyuWQ0 = PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠫࡕࡕࡓࡕࠩᎦ")
		AqLgT4S6FExHi1kZ5smy7a0hRX = XnQbsZF0Ouh8p7zCdUN(AqLgT4S6FExHi1kZ5smy7a0hRX)
		KpnbcdJ1yG986elNhBZz,AqLgT4S6FExHi1kZ5smy7a0hRX = NgD0bJaq14yBnMYoziAmLj(AqLgT4S6FExHi1kZ5smy7a0hRX)
	UMNteoHlkEy3Yf = mORwgTnXBdQ7iCSHKf(f0KUlmeMpWgFsPk16On,ww2vqCObJMBYRUaDyuWQ0,qmr7vLh1EW,AqLgT4S6FExHi1kZ5smy7a0hRX,ib6URTIJnFlgVwXsQAN0ZGD4k9c3ph,BmcLzCFjuIrZP5fwXH18aN6YS(u"ࡖࡵࡹࡪ᠋"),showDialogs,iW6eqtHJGnzFhTSgduj7Pys2w)
	qqThxfYXnogSpAiJ7GkcLz = UMNteoHlkEy3Yf.content
	qqThxfYXnogSpAiJ7GkcLz = str(qqThxfYXnogSpAiJ7GkcLz)
	return qqThxfYXnogSpAiJ7GkcLz
def I1zAN6ZaFrhSfMojPKTLmiG2(qmr7vLh1EW):
	G3oy27k0MUjJ9R6ON4vhieTdLlnCDu = qmr7vLh1EW.split(NVS30xAdRFMIw1n9CislkE2(u"ࠬࢂࡼࠨᎧ"))
	bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,eG5xjWgRUhC8f,RRfNT13COItMrPdJlEgq,nnDRPzg7XWmorOjQMtU5hxH = G3oy27k0MUjJ9R6ON4vhieTdLlnCDu[b05yftsZ6NYgIKP(u"࠴ᝥ")],None,None,YB5xyI7MaRslVpv(u"ࡗࡶࡺ࡫᠌")
	for FatuQ5gf41DEVHjxBMKwbnyd7ziSl in G3oy27k0MUjJ9R6ON4vhieTdLlnCDu:
		if vvHpKfcqRnrFzjG(u"࠭ࡍࡺࡒࡵࡳࡽࡿࡕࡳ࡮ࡀࠫᎨ") in FatuQ5gf41DEVHjxBMKwbnyd7ziSl: eG5xjWgRUhC8f = FatuQ5gf41DEVHjxBMKwbnyd7ziSl[rbjsM8cRFiuA1(u"࠶࠷ᝦ"):]
		elif qbPw1d3KimF(u"ࠧࡎࡻࡇࡒࡘ࡛ࡲ࡭࠿ࠪᎩ") in FatuQ5gf41DEVHjxBMKwbnyd7ziSl: RRfNT13COItMrPdJlEgq = FatuQ5gf41DEVHjxBMKwbnyd7ziSl[qbPw1d3KimF(u"࠿ᝧ"):]
		elif NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠨࡐࡲ࡚ࡪࡸࡩࡧࡻࡖࡗࡑ࠭Ꭺ") in FatuQ5gf41DEVHjxBMKwbnyd7ziSl: nnDRPzg7XWmorOjQMtU5hxH = C2dgEDAKQGsvh(u"ࡊࡦࡲࡳࡦ᠍")
	return bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,eG5xjWgRUhC8f,RRfNT13COItMrPdJlEgq,nnDRPzg7XWmorOjQMtU5hxH
def GETmdevAqQ(gg37KuOokaYFs8qTiezZn1tJ4jLr6):
	f6238qx1LCoPMwFe9uJ,bo1dqzR8JIwlThvDcyU4jf,sYyEIj49B0 = PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠩࠪᎫ"),BoWHNb9daQVCF16A(u"ࠪࠫᎬ"),C2jP0iLNGKnHu9xp(u"ࠫࠬᎭ")
	gg37KuOokaYFs8qTiezZn1tJ4jLr6 = gg37KuOokaYFs8qTiezZn1tJ4jLr6.replace(u8c5pQm3iRwvxESj7PUrO,hhlbF1Sns5TrEN8QPCYmL4(u"ࠬ࠭Ꭾ")).replace(rcek0gbPZ6lmJwSaTNso,EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠭ࠧᎯ"))
	AwKc1kuJ7V = My7Dwqvs6bfGNSIgX.findall(vvHpKfcqRnrFzjG(u"ࠧࠩ࠰ࠬࡠࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡢ࡝ࠩ࡞ࡺࡠࡼࡢࡷࠪࠢ࠮ࡠࡠࡢ࠯ࡄࡑࡏࡓࡗࡢ࡝ࠩ࠰࠭ࡃ࠮ࠪࠧᎰ"),gg37KuOokaYFs8qTiezZn1tJ4jLr6,My7Dwqvs6bfGNSIgX.DOTALL)
	if AwKc1kuJ7V: f6238qx1LCoPMwFe9uJ,bo1dqzR8JIwlThvDcyU4jf,gg37KuOokaYFs8qTiezZn1tJ4jLr6 = AwKc1kuJ7V[YB5xyI7MaRslVpv(u"࠰ᝨ")]
	if f6238qx1LCoPMwFe9uJ not in [T6wRistc1SCo4hqObgumK(u"ࠨࠢࠪᎱ"),FGDJwkEbTB5SoXujs3f(u"ࠩ࠯ࠫᎲ"),BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠪࠫᎳ")]: sYyEIj49B0 = V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠫࡤࡓࡏࡅࡡࠪᎴ")
	if bo1dqzR8JIwlThvDcyU4jf: bo1dqzR8JIwlThvDcyU4jf = gItVahxL0w(u"ࠬࡥࠧᎵ")+bo1dqzR8JIwlThvDcyU4jf+FGDJwkEbTB5SoXujs3f(u"࠭࡟ࠨᎶ")
	gg37KuOokaYFs8qTiezZn1tJ4jLr6 = bo1dqzR8JIwlThvDcyU4jf+sYyEIj49B0+gg37KuOokaYFs8qTiezZn1tJ4jLr6
	return gg37KuOokaYFs8qTiezZn1tJ4jLr6
def zu3wbS2VXEhgxUYGKmIqpOosT(f0KUlmeMpWgFsPk16On,ww2vqCObJMBYRUaDyuWQ0,qmr7vLh1EW,mmbVs9Zxelkr1,U3hzXe74mgwrD,oHJAU7WrycN5pVLdEzqu,ib6URTIJnFlgVwXsQAN0ZGD4k9c3ph=b05yftsZ6NYgIKP(u"ࠧࠨᎷ")):
	kR7uT3ODNFs8ZJo = ooq2D9xF8ZLpPBs(qmr7vLh1EW,vvHpKfcqRnrFzjG(u"ࠨࡷࡵࡰࠬᎸ"))
	DDF6QtRKsqm7JSdjgNM = bLEBi8IO7uU2x3htYDdVq95.getSetting(NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠩࡤࡺ࠳࡮࡯ࡴࡶ࠱ࠫᎹ")+mmbVs9Zxelkr1)
	if kR7uT3ODNFs8ZJo==DDF6QtRKsqm7JSdjgNM: bLEBi8IO7uU2x3htYDdVq95.setSetting(hhlbF1Sns5TrEN8QPCYmL4(u"ࠪࡥࡻ࠴ࡨࡰࡵࡷ࠲ࠬᎺ")+mmbVs9Zxelkr1,EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠫࠬᎻ"))
	if DDF6QtRKsqm7JSdjgNM: QAKdHzO0rehbtyIc = qmr7vLh1EW.replace(kR7uT3ODNFs8ZJo,DDF6QtRKsqm7JSdjgNM)
	else:
		QAKdHzO0rehbtyIc = qmr7vLh1EW
		DDF6QtRKsqm7JSdjgNM = kR7uT3ODNFs8ZJo
	yuJ6MIgav237VYzWUpwsilGktqd95r = mORwgTnXBdQ7iCSHKf(f0KUlmeMpWgFsPk16On,ww2vqCObJMBYRUaDyuWQ0,QAKdHzO0rehbtyIc,jx7s8T0BFgODXLMzIYedf(u"ࠬ࠭Ꮌ"),ib6URTIJnFlgVwXsQAN0ZGD4k9c3ph,b05yftsZ6NYgIKP(u"࠭ࠧᎽ"),C2dgEDAKQGsvh(u"ࠧࠨᎾ"),vvHpKfcqRnrFzjG(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡓࡔࡍࡌࡆࡡࡑࡉ࡜ࡥࡈࡐࡕࡗࡒࡆࡓࡅ࠮࠳ࡶࡸࠬᎿ"))
	qqThxfYXnogSpAiJ7GkcLz = yuJ6MIgav237VYzWUpwsilGktqd95r.content
	if BLz7m2RkNrxXQwy1cGAp:
		try: qqThxfYXnogSpAiJ7GkcLz = qqThxfYXnogSpAiJ7GkcLz.decode(T6wRistc1SCo4hqObgumK(u"ࠩࡸࡸ࡫࠾ࠧᏀ"),YB5xyI7MaRslVpv(u"ࠪ࡭࡬ࡴ࡯ࡳࡧࠪᏁ"))
		except: pass
	if not yuJ6MIgav237VYzWUpwsilGktqd95r.succeeded or oHJAU7WrycN5pVLdEzqu not in qqThxfYXnogSpAiJ7GkcLz:
		U3hzXe74mgwrD = U3hzXe74mgwrD.replace(gItVahxL0w(u"ࠫࠥ࠭Ꮒ"),T6wRistc1SCo4hqObgumK(u"ࠬ࠱ࠧᏃ"))
		bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = vvHpKfcqRnrFzjG(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲࡬ࡵ࡯ࡨ࡮ࡨ࠲ࡨࡵ࡭࠰ࡵࡨࡥࡷࡩࡨࡀࡳࡀࠫᏄ")+U3hzXe74mgwrD
		eIL9BxdTbZj = {nr5mZG89ICi6cgt4MfLJa0(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫᏅ"):LgpdP3UjFRnlX(u"ࠨࠩᏆ")}
		TOzKqRwpa6WrVMH8Pxy4X = mORwgTnXBdQ7iCSHKf(f0KUlmeMpWgFsPk16On,ww2vqCObJMBYRUaDyuWQ0,bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,jx7s8T0BFgODXLMzIYedf(u"ࠩࠪᏇ"),eIL9BxdTbZj,hhlbF1Sns5TrEN8QPCYmL4(u"ࠪࠫᏈ"),vvHpKfcqRnrFzjG(u"ࠫࠬᏉ"),C2dgEDAKQGsvh(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡐࡑࡊࡐࡊࡥࡎࡆ࡙ࡢࡌࡔ࡙ࡔࡏࡃࡐࡉ࠲࠸࡮ࡥࠩᏊ"))
		if TOzKqRwpa6WrVMH8Pxy4X.succeeded:
			qqThxfYXnogSpAiJ7GkcLz = TOzKqRwpa6WrVMH8Pxy4X.content
			if BLz7m2RkNrxXQwy1cGAp:
				try: qqThxfYXnogSpAiJ7GkcLz = qqThxfYXnogSpAiJ7GkcLz.decode(sRth5giAQzWlEVm7JOX(u"࠭ࡵࡵࡨ࠻ࠫᏋ"),PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠧࡪࡩࡱࡳࡷ࡫ࠧᏌ"))
				except: pass
			NVHrZsqUp2 = My7Dwqvs6bfGNSIgX.findall(jx7s8T0BFgODXLMzIYedf(u"ࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥ࠳ࡡࡽࠪ࡝ࡁ࠱࠮ࡄ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩࠣࠩᏍ"),qqThxfYXnogSpAiJ7GkcLz,My7Dwqvs6bfGNSIgX.DOTALL)
			CCyzXsnVlg = [DDF6QtRKsqm7JSdjgNM]
			YYVb8eR2oxaP3AJTE1NvnyHIGcDCdM = [NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠩࡤࡴࡰ࠭Ꮞ"),C2jP0iLNGKnHu9xp(u"ࠪ࡫ࡴࡵࡧ࡭ࡧࠪᏏ"),vvHpKfcqRnrFzjG(u"ࠫࡹࡽࡩࡵࡶࡨࡶࠬᏐ"),l0WAe1f7Bpi5ZXk(u"ࠬࡿ࡯ࡶࡶࡸࡦࡪ࠭Ꮡ"),jx7s8T0BFgODXLMzIYedf(u"࠭ࡦࡢࡥࡨࡦࡴࡵ࡫ࠨᏒ"),C2dgEDAKQGsvh(u"ࠧࡱࡪࡳࠫᏓ"),WMkAjB1RgN7q(u"ࠨࡣࡷࡰࡦࡷࠧᏔ"),nr5mZG89ICi6cgt4MfLJa0(u"ࠩࡶ࡭ࡹ࡫ࡩ࡯ࡦ࡬ࡧࡪࡹࠧᏕ"),l0WAe1f7Bpi5ZXk(u"ࠪࡷࡺࡸ࠮࡭ࡻࠪᏖ"),fY5wTlhtnOc0Er6sdy4k87b(u"ࠫࡧࡲ࡯ࡨࡵࡳࡳࡹ࠭Ꮧ"),FGDJwkEbTB5SoXujs3f(u"ࠬ࡯࡮ࡧࡱࡵࡱࡪࡸࠧᏘ"),UnWjVbo503mEMv9KF(u"࠭ࡳࡪࡶࡨࡰ࡮ࡱࡥࠨᏙ"),V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠧࡪࡰࡶࡸࡦ࡭ࡲࡢ࡯ࠪᏚ"),v5EA6TqHX3s4jzBMk(u"ࠨࡵࡱࡥࡵࡩࡨࡢࡶࠪᏛ"),jx7s8T0BFgODXLMzIYedf(u"ࠩ࡫ࡸࡹࡶ࠭ࡦࡳࡸ࡭ࡻ࠭Ꮬ"),WMkAjB1RgN7q(u"ࠪࡪࡦࡹࡥ࡭ࡲ࡯ࡹࡸ࠭Ꮭ")]
			for db276WrGJTP8KhjCaZq in NVHrZsqUp2:
				if any(WoFrX46wzbCNp18 in db276WrGJTP8KhjCaZq for WoFrX46wzbCNp18 in YYVb8eR2oxaP3AJTE1NvnyHIGcDCdM): continue
				DDF6QtRKsqm7JSdjgNM = ooq2D9xF8ZLpPBs(db276WrGJTP8KhjCaZq,rbjsM8cRFiuA1(u"ࠫࡺࡸ࡬ࠨᏞ"))
				if DDF6QtRKsqm7JSdjgNM in CCyzXsnVlg: continue
				if len(CCyzXsnVlg)==v5EA6TqHX3s4jzBMk(u"࠺ᝩ"):
					Lmj1pfQk63XdoeH(k5dztomYyN3H(u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪᏟ"),Dwl0N6FKuVU8nB1mbisIrCzdO(baNWS6nfqTC5iX4Kl)+T6wRistc1SCo4hqObgumK(u"࠭ࠠࠡࠢࡊࡳࡴ࡭࡬ࡦࠢࡧ࡭ࡩࠦ࡮ࡰࡶࠣࡪ࡮ࡴࡤࠡࡣࠣࡲࡪࡽࠠࡩࡱࡶࡸࡳࡧ࡭ࡦࠢࠣࠤࡘ࡯ࡴࡦ࠼ࠣ࡟ࠥ࠭Ꮰ")+mmbVs9Zxelkr1+FGDJwkEbTB5SoXujs3f(u"ࠧࠡ࡟ࠣࠤࡔࡲࡤ࠻ࠢ࡞ࠤࠬᏡ")+kR7uT3ODNFs8ZJo+l0WAe1f7Bpi5ZXk(u"ࠨࠢࡠࠫᏢ"))
					bLEBi8IO7uU2x3htYDdVq95.setSetting(jSu5Cg2Ub1OAkZVs8Yoz(u"ࠩࡤࡺ࠳࡮࡯ࡴࡶ࠱ࠫᏣ")+mmbVs9Zxelkr1,T6wRistc1SCo4hqObgumK(u"ࠪࠫᏤ"))
					break
				CCyzXsnVlg.append(DDF6QtRKsqm7JSdjgNM)
				QAKdHzO0rehbtyIc = qmr7vLh1EW.replace(kR7uT3ODNFs8ZJo,DDF6QtRKsqm7JSdjgNM)
				yuJ6MIgav237VYzWUpwsilGktqd95r = mORwgTnXBdQ7iCSHKf(f0KUlmeMpWgFsPk16On,ww2vqCObJMBYRUaDyuWQ0,QAKdHzO0rehbtyIc,NVS30xAdRFMIw1n9CislkE2(u"ࠫࠬᏥ"),ib6URTIJnFlgVwXsQAN0ZGD4k9c3ph,jx7s8T0BFgODXLMzIYedf(u"ࠬ࠭Ꮶ"),UnWjVbo503mEMv9KF(u"࠭ࠧᏧ"),EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡉࡒࡓࡌࡒࡅࡠࡐࡈ࡛ࡤࡎࡏࡔࡖࡑࡅࡒࡋ࠭࠴ࡴࡧࠫᏨ"))
				qqThxfYXnogSpAiJ7GkcLz = yuJ6MIgav237VYzWUpwsilGktqd95r.content
				if yuJ6MIgav237VYzWUpwsilGktqd95r.succeeded and oHJAU7WrycN5pVLdEzqu in qqThxfYXnogSpAiJ7GkcLz:
					Lmj1pfQk63XdoeH(NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠨࡐࡒࡘࡎࡉࡅࡠࡎࡌࡒࡊ࡙ࠧᏩ"),Dwl0N6FKuVU8nB1mbisIrCzdO(baNWS6nfqTC5iX4Kl)+WMkAjB1RgN7q(u"ࠩࠣࠤࠥࡍ࡯ࡰࡩ࡯ࡩࠥ࡬࡯ࡶࡰࡧࠤࡦࠦ࡮ࡦࡹࠣ࡬ࡴࡹࡴ࡯ࡣࡰࡩࠥࠦࠠࡔ࡫ࡷࡩ࠿࡛ࠦࠡࠩᏪ")+mmbVs9Zxelkr1+NVS30xAdRFMIw1n9CislkE2(u"ࠪࠤࡢࠦࠠࠡࡐࡨࡻ࠿࡛ࠦࠡࠩᏫ")+DDF6QtRKsqm7JSdjgNM+fY5wTlhtnOc0Er6sdy4k87b(u"ࠫࠥࡣࠠࠡࡑ࡯ࡨ࠿࡛ࠦࠡࠩᏬ")+kR7uT3ODNFs8ZJo+C2jP0iLNGKnHu9xp(u"ࠬࠦ࡝ࠨᏭ"))
					bLEBi8IO7uU2x3htYDdVq95.setSetting(gItVahxL0w(u"࠭ࡡࡷ࠰࡫ࡳࡸࡺ࠮ࠨᏮ")+mmbVs9Zxelkr1,DDF6QtRKsqm7JSdjgNM)
					break
	return DDF6QtRKsqm7JSdjgNM,QAKdHzO0rehbtyIc,yuJ6MIgav237VYzWUpwsilGktqd95r
def nnYoO8rQaHmc57IA1MVSi(QHDcUO2xtS4CmF):
	KpLo5Zqc9YFW = {
	 QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠧࡰ࡮ࡧࠫᏯ")			:YB5xyI7MaRslVpv(u"ࠨไา๎๊࠭Ᏸ")
	,qbPw1d3KimF(u"ࠩࡧ࡭ࡸࡧࡢ࡭ࡧࡧࠫᏱ")		:fY5wTlhtnOc0Er6sdy4k87b(u"้ࠪฯ๎โโࠩᏲ")
	,qbPw1d3KimF(u"ࠫࡲ࡯ࡳࡴ࡫ࡱ࡫ࠬᏳ")		:EAc8h2sINroQYvR3WH06Ji7MVpn(u"๋ࠬแใ๊าࠫᏴ")
	,jSu5Cg2Ub1OAkZVs8Yoz(u"࠭ࡧࡰࡱࡧࠫᏵ")			:sRth5giAQzWlEVm7JOX(u"ࠧอ์าࠫ᏶")
	,PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨ᏷")		:BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠩไุ้࠭ᏸ")
	,vvHpKfcqRnrFzjG(u"ࠪࡪࡴࡲࡤࡦࡴࠪᏹ")		:FGDJwkEbTB5SoXujs3f(u"๊ࠫาไะࠩᏺ")
	,BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠬࡼࡩࡥࡧࡲࠫᏻ")		:C2dgEDAKQGsvh(u"࠭แ๋ัํ์ࠬᏼ")
	,WMkAjB1RgN7q(u"ࠧ࡭࡫ࡹࡩࠬᏽ")			:C2jP0iLNGKnHu9xp(u"ࠨไ้หฮ࠭᏾")
	,LgpdP3UjFRnlX(u"ࠩࡤ࡯ࡴࡧ࡭ࠨ᏿")		:UnWjVbo503mEMv9KF(u"้ࠪํู่ࠡลๆ์ฬ๋ࠠศๆๅำ๏๋ࠧ᐀")
	,rbjsM8cRFiuA1(u"ࠫࡦࡱࡷࡢ࡯ࠪᐁ")		:PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"๋่ࠬใ฻ࠣว่๎วๆࠢส่ัี๊ะࠩᐂ")
	,NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠭ࡡ࡬ࡱࡤࡱࡨࡧ࡭ࠨᐃ")		:vvHpKfcqRnrFzjG(u"ࠧๆ๊ๅ฽ࠥษใ้ษ่ࠤ่อๅࠨᐄ")
	,NVS30xAdRFMIw1n9CislkE2(u"ࠨࡣ࡯ࡥࡷࡧࡢࠨᐅ")		:jSu5Cg2Ub1OAkZVs8Yoz(u"่ࠩ์็฿ࠠไๆࠣห้฿ัษࠩᐆ")
	,fY5wTlhtnOc0Er6sdy4k87b(u"ࠪࡥࡱ࡬ࡡࡵ࡫ࡰ࡭ࠬᐇ")		:fY5wTlhtnOc0Er6sdy4k87b(u"๊ࠫ๎โฺࠢส่๊์ศาࠢส่ๆอืๆ์ࠪᐈ")
	,k5dztomYyN3H(u"ࠬࡧ࡬࡬ࡣࡺࡸ࡭ࡧࡲࠨᐉ")	:jx7s8T0BFgODXLMzIYedf(u"࠭ๅ้ไ฼ࠤ็์วสࠢส่่๎หาࠩᐊ")
	,vvHpKfcqRnrFzjG(u"ࠧࡢ࡮ࡰࡥࡦࡸࡥࡧࠩᐋ")		:NVS30xAdRFMIw1n9CislkE2(u"ࠨ็๋ๆ฾ࠦโ็ษฬࠤฬ๊ๅฺษิๅࠬᐌ")
	,LgpdP3UjFRnlX(u"ࠩࡤࡶࡧࡲࡩࡰࡰࡽࠫᐍ")		:NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"้ࠪํู่ࠡ฻ิฬ๊๊้่ࠥีࠫᐎ")
	,EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠫࡪ࡭ࡹࡣࡧࡶࡸࡻ࡯ࡰࠨᐏ")	:BmcLzCFjuIrZP5fwXH18aN6YS(u"๋่ࠬใ฻ࠣห๏า๊ࠡสํืฯࠦࡶࡪࡲࠪᐐ")
	,NVS30xAdRFMIw1n9CislkE2(u"࠭ࡥ࡭ࡥ࡬ࡲࡪࡳࡡࠨᐑ")		:fY5wTlhtnOc0Er6sdy4k87b(u"ࠧๆ๊ๅ฽ࠥอไิ์้้ฬ࠭ᐒ")
	,YB5xyI7MaRslVpv(u"ࠨࡪࡨࡰࡦࡲࠧᐓ")		:rbjsM8cRFiuA1(u"่ࠩ์็฿่ࠠๆส่ࠥ๐่ห์๋ฬࠬᐔ")
	,rbjsM8cRFiuA1(u"ࠪࡧ࡮ࡳࡡࡧࡣࡱࡷࠬᐕ")		:UxS67uoGThbMwnfNRzy4gajLd23JH(u"๊ࠫ๎โฺࠢึ๎๊อࠠโษ้ึࠬᐖ")
	,C2dgEDAKQGsvh(u"ࠬࡹࡨࡢࡪ࡬ࡨ࠹ࡻࠧᐗ")		:k5dztomYyN3H(u"࠭ๅ้ไ฼ࠤูอ็ะࠢไ์ึ๐่ࠨᐘ")
	,l0WAe1f7Bpi5ZXk(u"ࠧࡴࡪࡲࡳ࡫ࡳࡡࡹࠩᐙ")		:v5EA6TqHX3s4jzBMk(u"ࠨ็๋ๆ฾ࠦิ้ใ้ࠣฬ้ำࠨᐚ")
	,NVS30xAdRFMIw1n9CislkE2(u"ࠩࡤࡶࡦࡨࡳࡦࡧࡧࠫᐛ")		:V2RbfGOBdcA6l8NTsPWzEyvS7(u"้ࠪํู่ࠡ฻ิฬู๊๋ࠥัࠪᐜ")
	,l0WAe1f7Bpi5ZXk(u"ࠫࡨ࡯࡭ࡢࡰࡲࡻࠬᐝ")		:UxS67uoGThbMwnfNRzy4gajLd23JH(u"๋่ࠬใ฻ࠣื๏๋ว่ࠡส์ࠬᐞ")
	,C2jP0iLNGKnHu9xp(u"࠭࡫ࡢࡴࡥࡥࡱࡧࡴࡷࠩᐟ")	:qbPw1d3KimF(u"ࠧๆ๊ๅ฽่ࠥๆศหࠣ็ึฮไศรࠪᐠ")
	,fY5wTlhtnOc0Er6sdy4k87b(u"ࠨࡻࡷࡦࡤࡩࡨࡢࡰࡱࡩࡱࡹࠧᐡ")	:YB5xyI7MaRslVpv(u"่ࠩ์ฬู่ࠡ์๋ฮ๏๎ศࠨᐢ")
	,PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠪࡱࡾࡩࡩ࡮ࡣࠪᐣ")		:jSu5Cg2Ub1OAkZVs8Yoz(u"๊ࠫ๎โฺ่ࠢห๏ࠦำ๋็สࠫᐤ")
	,nr5mZG89ICi6cgt4MfLJa0(u"ࠬࡽࡥࡤ࡫ࡰࡥࠬᐥ")		:BmcLzCFjuIrZP5fwXH18aN6YS(u"࠭ๅ้ไ฼ࠤํ๐ࠠิ์่หࠬᐦ")
	,C2dgEDAKQGsvh(u"ࠧࡧࡣࡶࡩࡱ࡮ࡤ࠲ࠩᐧ")		:WMkAjB1RgN7q(u"ࠨ็๋ๆ฾ࠦแศื็ࠤฬ๊ร้ๆࠪᐨ")
	,l0WAe1f7Bpi5ZXk(u"ࠩࡩࡥࡸ࡫࡬ࡩࡦ࠵ࠫᐩ")		:EAc8h2sINroQYvR3WH06Ji7MVpn(u"้ࠪํู่ࠡใสู้ࠦวๅอส๊๏࠭ᐪ")
	,C2jP0iLNGKnHu9xp(u"ࠫࡧࡵ࡫ࡳࡣࠪᐫ")		:l0WAe1f7Bpi5ZXk(u"๋่ࠬใ฻ࠣฬ่ืวࠨᐬ")
	,NVS30xAdRFMIw1n9CislkE2(u"࠭ࡣࡪ࡯ࡤࡥࡧࡪ࡯ࠨᐭ")		:rbjsM8cRFiuA1(u"ࠧๆ๊ๅ฽ู๊ࠥๆษࠣ฽อี่ࠨᐮ")
	,jSu5Cg2Ub1OAkZVs8Yoz(u"ࠨ࡮࡬ࡺࡪࡺࡶࠨᐯ")		:NVS30xAdRFMIw1n9CislkE2(u"่่ࠩๆ࠭ᐰ")
	,UnWjVbo503mEMv9KF(u"ࠪࡰ࡮ࡨࡲࡢࡴࡼࠫᐱ")		:nr5mZG89ICi6cgt4MfLJa0(u"๊๊ࠫแࠨᐲ")
	,nr5mZG89ICi6cgt4MfLJa0(u"ࠬࡳ࡯ࡷࡵ࠷ࡹࠬᐳ")		:NVS30xAdRFMIw1n9CislkE2(u"࠭ๅ้ไ฼ࠤ๊๎แำࠢไ์ึ๐่ࠨᐴ")
	,RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠧࡧࡣ࡭ࡩࡷࡹࡨࡰࡹࠪᐵ")	:T6wRistc1SCo4hqObgumK(u"ࠨ็๋ๆ฾ࠦแอำุࠣํ࠭ᐶ")
	,jx7s8T0BFgODXLMzIYedf(u"ࠩࡨ࡫ࡾࡨࡥࡴࡶࠪᐷ")		:fY5wTlhtnOc0Er6sdy4k87b(u"้ࠪํู่ࠡษํะ๏ࠦศ๋ีอࠫᐸ")
	,RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠫࡪ࡭ࡹࡣࡧࡶࡸ࠶࠭ᐹ")		:b05yftsZ6NYgIKP(u"๋่ࠬใ฻ࠣห๏า๊ࠡสํืฯࠦ࠱ࠨᐺ")
	,YB5xyI7MaRslVpv(u"࠭ࡥࡨࡻࡥࡩࡸࡺ࠲ࠨᐻ")		:v5EA6TqHX3s4jzBMk(u"ࠧๆ๊ๅ฽ࠥอ๊อ์ࠣฬ๏ูสࠡ࠴ࠪᐼ")
	,WMkAjB1RgN7q(u"ࠨࡧࡪࡽࡧ࡫ࡳࡵ࠵ࠪᐽ")		:T6wRistc1SCo4hqObgumK(u"่ࠩ์็฿ࠠศ์ฯ๎ࠥฮ๊ิฬࠣ࠷ࠬᐾ")
	,UnWjVbo503mEMv9KF(u"ࠪࡩ࡬ࡿࡢࡦࡵࡷ࠸ࠬᐿ")		:FGDJwkEbTB5SoXujs3f(u"๊ࠫ๎โฺࠢส๎ั๐ࠠษ์ึฮࠥ࠺ࠧᑀ")
	,jSu5Cg2Ub1OAkZVs8Yoz(u"ࠬࡩࡩ࡮ࡣ࠷ࡹࠬᑁ")		:PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"࠭ๅ้ไ฼ࠤุ๐ๅศࠢไ์ึ๐่ࠨᑂ")
	,PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠧࡦࡩࡼࡲࡴࡽࠧᑃ")		:gItVahxL0w(u"ࠨ็๋ๆ฾ࠦล๋ฮํࠤ๋อ่ࠨᑄ")
	,UnWjVbo503mEMv9KF(u"ࠩࡨ࡫ࡾࡪࡥࡢࡦࠪᑅ")		:fY5wTlhtnOc0Er6sdy4k87b(u"้ࠪํู่ࠡวํะ๏ࠦฯ๋ัࠪᑆ")
	,C2jP0iLNGKnHu9xp(u"ࠫ࡭ࡧ࡬ࡢࡥ࡬ࡱࡦ࠭ᑇ")		:NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"๋่ࠬใ฻๋้ࠣอࠠิ์่หࠬᑈ")
	,T6wRistc1SCo4hqObgumK(u"࠭࡬ࡰࡦࡼࡲࡪࡺࠧᑉ")		:FGDJwkEbTB5SoXujs3f(u"ࠧๆ๊ๅ฽๊่ࠥะ์๊ࠣฯ࠭ᑊ")
	,jSu5Cg2Ub1OAkZVs8Yoz(u"ࠨࡶࡹࡪࡺࡴࠧᑋ")		:RqldvxFuM5GEQ2HAz93o7afBb0(u"่ࠩ์็฿ࠠห์ไ๎ࠥ็ว็ࠩᑌ")
	,fY5wTlhtnOc0Er6sdy4k87b(u"ࠪࡧ࡮ࡳࡡ࡭࡫ࡪ࡬ࡹ࠭ᑍ")	:YB5xyI7MaRslVpv(u"๊ࠫ๎โฺࠢึ๎๊อࠠๅษํฮࠬᑎ")
	,v5EA6TqHX3s4jzBMk(u"ࠬࡹࡨࡢࡪ࡬ࡨࡳ࡫ࡷࡴࠩᑏ")	:UxS67uoGThbMwnfNRzy4gajLd23JH(u"࠭ๅ้ไ฼ࠤูอ็ะ้ࠢ๎ํุࠧᑐ")
	,PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠧࡧࡱࡶࡸࡦ࠭ᑑ")		:sRth5giAQzWlEVm7JOX(u"ࠨ็๋ๆ฾ࠦแ้ีอหࠬᑒ")
	,PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠩࡤ࡬ࡼࡧ࡫ࠨᑓ")		:C2dgEDAKQGsvh(u"้ࠪํู่ࠡล๊์ฬ้ࠠห์ไ๎ࠬᑔ")
	,C2dgEDAKQGsvh(u"ࠫ࡫ࡧࡢࡳࡣ࡮ࡥࠬᑕ")		:b05yftsZ6NYgIKP(u"๋่ࠬใ฻ࠣๅอืใสࠩᑖ")
	,BoWHNb9daQVCF16A(u"࠭ࡣࡪ࡯ࡤࡧࡱࡻࡢࡸࡱࡵ࡯ࠬᑗ")	:BoWHNb9daQVCF16A(u"ࠧๆ๊ๅ฽ู๊ࠥๆษࠣ็้๎ศࠡ฻่่ࠬᑘ")
	,BoWHNb9daQVCF16A(u"ࠨࡥ࡬ࡱࡦࡩ࡬ࡶࡤࠪᑙ")		:C2jP0iLNGKnHu9xp(u"่ࠩ์็฿ࠠิ์่ห้ࠥไ้สࠪᑚ")
	,EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠪࡷ࡭ࡵࡦࡩࡣࠪᑛ")		:PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"๊ࠫ๎โฺࠢื์ๆํวࠡฬํๅ๏࠭ᑜ")
	,vvHpKfcqRnrFzjG(u"ࠬࡨࡲࡴࡶࡨ࡮ࠬᑝ")		:k5dztomYyN3H(u"࠭ๅ้ไ฼ࠤอืำห์ฯࠫᑞ")
	,fY5wTlhtnOc0Er6sdy4k87b(u"ࠧࡤ࡫ࡰࡥ࠹࠶࠰ࠨᑟ")		:LgpdP3UjFRnlX(u"ࠨ็๋ๆ฾ࠦำ๋็สࠤ࠹࠶࠰ࠨᑠ")
	,WMkAjB1RgN7q(u"ࠩ࡯ࡥࡷࡵࡺࡢࠩᑡ")		:UnWjVbo503mEMv9KF(u"้ࠪํู่ࠡๆสีํุวࠨᑢ")
	,v5EA6TqHX3s4jzBMk(u"ࠫࡾࡧࡱࡰࡶࠪᑣ")		:k5dztomYyN3H(u"๋่ࠬใ฻ࠣ๎ฬ่่หࠩᑤ")
	,NVS30xAdRFMIw1n9CislkE2(u"࠭࡫ࡢࡶ࡮ࡳࡺࡺࡥࠨᑥ")		:jSu5Cg2Ub1OAkZVs8Yoz(u"ࠧๆ๊ๅ฽้ࠥสไ๊อࠫᑦ")
	,UnWjVbo503mEMv9KF(u"ࠨ࡭ࡤࡸࡰࡵࡴࡵࡸࠪᑧ")		:YB5xyI7MaRslVpv(u"่ࠩ์็฿ࠠไฬๆ์ฯࠦส๋ใํࠫᑨ")
	,fY5wTlhtnOc0Er6sdy4k87b(u"ࠪࡥࡷࡧࡢࡪࡥࡷࡳࡴࡴࡳࠨᑩ")	:sRth5giAQzWlEVm7JOX(u"๊ࠫ๎โฺࠢอ์ฺุ๋ࠠำห๎ฮ࠭ᑪ")
	,BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠬࡪࡲࡢ࡯ࡤࡷ࠼࠭ᑫ")		:RqldvxFuM5GEQ2HAz93o7afBb0(u"࠭ๅ้ไ฼ࠤิืวๆษูࠣา࠭ᑬ")
	,BoWHNb9daQVCF16A(u"ࠧࡴࡪࡲࡳ࡫ࡶࡲࡰࠩᑭ")		:vvHpKfcqRnrFzjG(u"ࠨ็๋ๆ฾ࠦิ้ใࠣฬึ๎ࠧᑮ")
	,RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠩ࡬ࡪ࡮ࡲ࡭ࠨᑯ")				:BmcLzCFjuIrZP5fwXH18aN6YS(u"้ࠪํู่ࠡไ้หฮࠦย๋ࠢไ๎้๋ࠧᑰ")
	,UnWjVbo503mEMv9KF(u"ࠫ࡮࡬ࡩ࡭࡯࠰ࡥࡷࡧࡢࡪࡥࠪᑱ")			:qbPw1d3KimF(u"๋่ࠬใ฻ࠣๆ๋อษࠡฤํࠤๆ๐ไๆࠢ฼ีอ๐ࠧᑲ")
	,fY5wTlhtnOc0Er6sdy4k87b(u"࠭ࡩࡧ࡫࡯ࡱ࠲࡫࡮ࡨ࡮࡬ࡷ࡭࠭ᑳ")		:EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠧๆ๊ๅ฽่ࠥๆศหࠣฦ๏ࠦแ๋ๆ่ࠤฬ์ฬๅ์ี๎ࠬᑴ")
	,FGDJwkEbTB5SoXujs3f(u"ࠨࡲࡤࡲࡪࡺࠧᑵ")				:fY5wTlhtnOc0Er6sdy4k87b(u"่ࠩ์็฿ࠠษษ้๎ฯ࠭ᑶ")
	,WMkAjB1RgN7q(u"ࠪࡴࡦࡴࡥࡵ࠯ࡰࡳࡻ࡯ࡥࡴࠩᑷ")			:NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"๊ࠫ๎โฺࠢหห๋๐สࠡษไ่ฬ๋ࠧᑸ")
	,WMkAjB1RgN7q(u"ࠬࡶࡡ࡯ࡧࡷ࠱ࡸ࡫ࡲࡪࡧࡶࠫᑹ")			:v5EA6TqHX3s4jzBMk(u"࠭ๅ้ไ฼ࠤออๆ๋ฬุ้๊ࠣำๅษอࠫᑺ")
	,rbjsM8cRFiuA1(u"ࠧࡺࡱࡸࡸࡺࡨࡥࠨᑻ")				:WMkAjB1RgN7q(u"ࠨ็๋ๆ฾๊้ࠦฬํ์อ࠭ᑼ")
	,BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠩࡼࡳࡺࡺࡵࡣࡧ࠰ࡺ࡮ࡪࡥࡰࡵࠪᑽ")		:WMkAjB1RgN7q(u"้ࠪํู่ࠡ์๋ฮ๏๎ศࠡใํำ๏๎็ศฬࠪᑾ")
	,b05yftsZ6NYgIKP(u"ࠫࡾࡵࡵࡵࡷࡥࡩ࠲ࡶ࡬ࡢࡻ࡯࡭ࡸࡺࡳࠨᑿ")	:T6wRistc1SCo4hqObgumK(u"๋่ࠬใ฻ࠣ๎ํะ๊้สࠣๆํอฦๆࠩᒀ")
	,fY5wTlhtnOc0Er6sdy4k87b(u"࠭ࡹࡰࡷࡷࡹࡧ࡫࠭ࡤࡪࡤࡲࡳ࡫࡬ࡴࠩᒁ")		:C2jP0iLNGKnHu9xp(u"ࠧๆ๊ๅ฽ࠥ๐่ห์๋ฬ่ࠥๆ้ษอࠫᒂ")
	,UnWjVbo503mEMv9KF(u"ࠨࡵ࡫࡭ࡦࡼ࡯ࡪࡥࡨࠫᒃ")			:l0WAe1f7Bpi5ZXk(u"่ࠩ์็฿ࠠึ๊อࠤฬ๊ิ๋฻ฬࠫᒄ")
	,sRth5giAQzWlEVm7JOX(u"ࠪࡷ࡭࡯ࡡࡷࡱ࡬ࡧࡪ࠳ࡰࡦࡴࡶࡳࡳࡹࠧᒅ")	:k5dztomYyN3H(u"๊ࠫ๎โฺุࠢ์ฯࠦวๅึํ฽ฮࠦโศำษࠫᒆ")
	,v5EA6TqHX3s4jzBMk(u"ࠬࡹࡨࡪࡣࡹࡳ࡮ࡩࡥ࠮ࡣ࡯ࡦࡺࡳࡳࠨᒇ")		:EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠭ๅ้ไ฼ࠤฺ๎สࠡษ็ุ๏฿ษࠡษ็ฬํ๋ࠧᒈ")
	,vvHpKfcqRnrFzjG(u"ࠧࡴࡪ࡬ࡥࡻࡵࡩࡤࡧ࠰ࡥࡺࡪࡩࡰࡵࠪᒉ")		:PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠨ็๋ๆ฾ࠦี้ฬࠣหฺฺ้๊หูࠣํะ๊ศฬࠪᒊ")
	,QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠩࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴࠧᒋ")			:FGDJwkEbTB5SoXujs3f(u"้ࠪํู่ࠡัํ่๏ࠦๅ้ึ้ࠫᒌ")
	,YB5xyI7MaRslVpv(u"ࠫࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯࠯ࡹ࡭ࡩ࡫࡯ࡴࠩᒍ")	:FGDJwkEbTB5SoXujs3f(u"๋่ࠬใ฻ࠣำ๏๊๊ࠡ็ุ๋๋ࠦแ๋ัํ์์อสࠨᒎ")
	,nr5mZG89ICi6cgt4MfLJa0(u"࠭ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱ࠱ࡵࡲࡡࡺ࡮࡬ࡷࡹࡹࠧᒏ"):l0WAe1f7Bpi5ZXk(u"ࠧๆ๊ๅ฽ࠥี๊ๅ์้ࠣํฺๆࠡไ๋หห๋ࠧᒐ")
	,b05yftsZ6NYgIKP(u"ࠨࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠳ࡣࡩࡣࡱࡲࡪࡲࡳࠨᒑ")	:v5EA6TqHX3s4jzBMk(u"่ࠩ์็฿ࠠะ์็๎๋่ࠥี่ࠣๆ๋๎วหࠩᒒ")
	,qbPw1d3KimF(u"ࠪࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮࠮ࡶࡲࡴ࡮ࡩࡳࠨᒓ")	:rbjsM8cRFiuA1(u"๊ࠫ๎โฺࠢา๎้๐ࠠๆ๊ื๊๋่ࠥศุํ฽ࠬᒔ")
	,UnWjVbo503mEMv9KF(u"ࠬ࡯ࡰࡵࡸࠪᒕ")					:gItVahxL0w(u"࠭ࡉࡑࡖ࡙ࠫᒖ")
	,vvHpKfcqRnrFzjG(u"ࠧࡪࡲࡷࡺ࠲ࡲࡩࡷࡧࠪᒗ")			:C2dgEDAKQGsvh(u"ࠨࡋࡓࡘ࡛ࠦโ็๊สฮࠬᒘ")
	,WMkAjB1RgN7q(u"ࠩ࡬ࡴࡹࡼ࠭࡮ࡱࡹ࡭ࡪࡹࠧᒙ")			:BoWHNb9daQVCF16A(u"ࠪࡍࡕ࡚ࡖࠡลไ่ฬ๋ࠧᒚ")
	,UnWjVbo503mEMv9KF(u"ࠫ࡮ࡶࡴࡷ࠯ࡶࡩࡷ࡯ࡥࡴࠩᒛ")			:PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠬࡏࡐࡕࡘุ้๊ࠣำๅษอࠫᒜ")
	,hhlbF1Sns5TrEN8QPCYmL4(u"࠭࡭࠴ࡷࠪᒝ")					:vvHpKfcqRnrFzjG(u"ࠧࡎ࠵ࡘࠫᒞ")
	,EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠨ࡯࠶ࡹ࠲ࡲࡩࡷࡧࠪᒟ")				:rbjsM8cRFiuA1(u"ࠩࡐ࠷࡚ࠦโ็๊สฮࠬᒠ")
	,jx7s8T0BFgODXLMzIYedf(u"ࠪࡱ࠸ࡻ࠭࡮ࡱࡹ࡭ࡪࡹࠧᒡ")			:l0WAe1f7Bpi5ZXk(u"ࠫࡒ࠹ࡕࠡลไ่ฬ๋ࠧᒢ")
	,PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠬࡳ࠳ࡶ࠯ࡶࡩࡷ࡯ࡥࡴࠩᒣ")			:jx7s8T0BFgODXLMzIYedf(u"࠭ࡍ࠴ࡗุ้๊ࠣำๅษอࠫᒤ")
	}
	try: hkWxfe4FqyKaiR = KpLo5Zqc9YFW[QHDcUO2xtS4CmF.lower()]
	except: hkWxfe4FqyKaiR = jSu5Cg2Ub1OAkZVs8Yoz(u"ࠧࠨᒥ")
	return hkWxfe4FqyKaiR
def PapzBZgIekhJ5Fq8rDR2wOxTnu(mKBurDQaSIn1Aydsc9LvbF5EZf=YB5xyI7MaRslVpv(u"ࠨࠩᒦ")):
	V69VaywMFGd()
	if not mKBurDQaSIn1Aydsc9LvbF5EZf: mKBurDQaSIn1Aydsc9LvbF5EZf = k5dztomYyN3H(u"ࠩࡉࡳࡷࡩࡥࡥࠢࡈࡼ࡮ࡺࠧᒧ")
	Lmj1pfQk63XdoeH(V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠪࠫᒨ"),T6wRistc1SCo4hqObgumK(u"ࠫࡡࡴࠧᒩ")+mKBurDQaSIn1Aydsc9LvbF5EZf+BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠬࡢ࡮ࠨᒪ"))
	raise SystemExit
def F8fMqZKB4APk(qmr7vLh1EW,sBbnDfJqEwgyaIckuo6XRZW=RqldvxFuM5GEQ2HAz93o7afBb0(u"࠭࠺࠰ࠩᒫ")):
	return _pSB43T6lc10LbOYFqK(qmr7vLh1EW,sBbnDfJqEwgyaIckuo6XRZW)
def ddmOnHp1RljKZ0PeNzvysiIrYU4utQ(IsYRnpThJG1i):
	if IsYRnpThJG1i in [UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠧࠨᒬ"),NVS30xAdRFMIw1n9CislkE2(u"ࠨ࠲ࠪᒭ"),k5dztomYyN3H(u"࠲ᝪ")]: return FGDJwkEbTB5SoXujs3f(u"ࠩࠪᒮ")
	IsYRnpThJG1i = int(IsYRnpThJG1i)
	Xxtrabswf09QYDUNkgPh8qvu = IsYRnpThJG1i^IIiPCruL6dT8s1lqj47SzpVHnYNm
	uzfFY6BIrO0dSc75lV = IsYRnpThJG1i^UuEtImzir9
	lRTI3Dq2huP70n = IsYRnpThJG1i^f9Oum6c0FotxYn
	hkWxfe4FqyKaiR = str(Xxtrabswf09QYDUNkgPh8qvu)+str(uzfFY6BIrO0dSc75lV)+str(lRTI3Dq2huP70n)
	return hkWxfe4FqyKaiR
def pTI6mYcMvNs(IsYRnpThJG1i):
	if IsYRnpThJG1i in [UnWjVbo503mEMv9KF(u"ࠪࠫᒯ"),YB5xyI7MaRslVpv(u"ࠫ࠵࠭ᒰ"),LgpdP3UjFRnlX(u"࠳ᝫ")]: return PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠬ࠭ᒱ")
	IsYRnpThJG1i = str(IsYRnpThJG1i)
	hkWxfe4FqyKaiR = UnWjVbo503mEMv9KF(u"࠭ࠧᒲ")
	if len(IsYRnpThJG1i)==FGDJwkEbTB5SoXujs3f(u"࠵࠺ᝬ"):
		Xxtrabswf09QYDUNkgPh8qvu,uzfFY6BIrO0dSc75lV,lRTI3Dq2huP70n = IsYRnpThJG1i[sRth5giAQzWlEVm7JOX(u"࠶ᝮ"):FGDJwkEbTB5SoXujs3f(u"࠴ᝯ")],IsYRnpThJG1i[FGDJwkEbTB5SoXujs3f(u"࠴ᝯ"):k5dztomYyN3H(u"࠾᝭")],IsYRnpThJG1i[k5dztomYyN3H(u"࠾᝭"):]
		Xxtrabswf09QYDUNkgPh8qvu = int(Xxtrabswf09QYDUNkgPh8qvu)^f9Oum6c0FotxYn
		uzfFY6BIrO0dSc75lV = int(uzfFY6BIrO0dSc75lV)^UuEtImzir9
		lRTI3Dq2huP70n = int(lRTI3Dq2huP70n)^IIiPCruL6dT8s1lqj47SzpVHnYNm
		if Xxtrabswf09QYDUNkgPh8qvu==uzfFY6BIrO0dSc75lV==lRTI3Dq2huP70n: hkWxfe4FqyKaiR = str(Xxtrabswf09QYDUNkgPh8qvu*rbjsM8cRFiuA1(u"࠷࠲ᝰ"))
	return hkWxfe4FqyKaiR
def UnJu5mvBrPKqOidwpNcjAbh(IsYRnpThJG1i,gvLS7FIG34x5U1J9VdNjbBC=V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠧ࠷࠵࠻࠸࠶࠾࠲࠴ࠩᒳ")):
	if IsYRnpThJG1i==k5dztomYyN3H(u"ࠨࠩᒴ"): return nr5mZG89ICi6cgt4MfLJa0(u"ࠩࠪᒵ")
	IsYRnpThJG1i = int(IsYRnpThJG1i)+int(gvLS7FIG34x5U1J9VdNjbBC)
	Xxtrabswf09QYDUNkgPh8qvu = IsYRnpThJG1i^IIiPCruL6dT8s1lqj47SzpVHnYNm
	uzfFY6BIrO0dSc75lV = IsYRnpThJG1i^UuEtImzir9
	lRTI3Dq2huP70n = IsYRnpThJG1i^f9Oum6c0FotxYn
	hkWxfe4FqyKaiR = str(Xxtrabswf09QYDUNkgPh8qvu)+str(uzfFY6BIrO0dSc75lV)+str(lRTI3Dq2huP70n)
	return hkWxfe4FqyKaiR
def mVx80hrNLHnf5bkGgD7y(IsYRnpThJG1i,gvLS7FIG34x5U1J9VdNjbBC=T6wRistc1SCo4hqObgumK(u"ࠪ࠺࠸࠾࠴࠲࠺࠵࠷ࠬᒶ")):
	if IsYRnpThJG1i==rbjsM8cRFiuA1(u"ࠫࠬᒷ"): return BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠬ࠭ᒸ")
	IsYRnpThJG1i = str(IsYRnpThJG1i)
	wwCFA0VjJa = int(len(IsYRnpThJG1i)/v5EA6TqHX3s4jzBMk(u"࠵᝱"))
	Xxtrabswf09QYDUNkgPh8qvu = int(IsYRnpThJG1i[LgpdP3UjFRnlX(u"࠳ᝲ"):wwCFA0VjJa])^IIiPCruL6dT8s1lqj47SzpVHnYNm
	uzfFY6BIrO0dSc75lV = int(IsYRnpThJG1i[wwCFA0VjJa:T6wRistc1SCo4hqObgumK(u"࠶ᝳ")*wwCFA0VjJa])^UuEtImzir9
	lRTI3Dq2huP70n = int(IsYRnpThJG1i[vvHpKfcqRnrFzjG(u"࠸᝵")*wwCFA0VjJa:NVS30xAdRFMIw1n9CislkE2(u"࠸᝴")*wwCFA0VjJa])^f9Oum6c0FotxYn
	hkWxfe4FqyKaiR = jSu5Cg2Ub1OAkZVs8Yoz(u"࠭ࠧᒹ")
	if Xxtrabswf09QYDUNkgPh8qvu==uzfFY6BIrO0dSc75lV==lRTI3Dq2huP70n: hkWxfe4FqyKaiR = str(int(Xxtrabswf09QYDUNkgPh8qvu)-int(gvLS7FIG34x5U1J9VdNjbBC))
	return hkWxfe4FqyKaiR
def x5VP6sIEj8OFuv1Y3mtUMfB7qRlCXd(BlgEahu7f5yptCFwdW):
	JJr825O7Aw3YeUGMqdWkxfl0u6SZ = AK5RqLhji4W1wt9VdrCD3PGeQM[v5EA6TqHX3s4jzBMk(u"ࠧࡑ࡛ࡗࡌࡔࡔࠧᒺ")][LgpdP3UjFRnlX(u"࠸᝶")]
	zAs8PWQk52VL9iaZwEcyOjm = hvc2sXOB31KTLgiZaQUR9xuGjloYS(gItVahxL0w(u"࠴࠴᝷"))
	XE1m2OlTPjKg = XXRtDhYvWb35qnLBxIri7ScNUks0.path.join(QgRBJhSGd4uX7i,jx7s8T0BFgODXLMzIYedf(u"ࠨࡴࡨࡷࡴࡻࡲࡤࡧࡶࠫᒻ"),vvHpKfcqRnrFzjG(u"ࠩࡶ࡯࡮ࡴࡳࠨᒼ"),rbjsM8cRFiuA1(u"ࠪࡈࡪ࡬ࡡࡶ࡮ࡷࠫᒽ"),rbjsM8cRFiuA1(u"ࠫ࠼࠸࠰ࡱࠩᒾ"),FGDJwkEbTB5SoXujs3f(u"ࠬࡊࡩࡢ࡮ࡲ࡫ࡈࡵ࡮ࡧ࡫ࡵࡱ࡙࡮ࡲࡦࡧࡅࡹࡹࡺ࡯࡯ࡵ࠱ࡼࡲࡲࠧᒿ"))
	fqrc1SU2xACKDv46REBmJpwy,Hc4ohrvsmpPX = SIG93nyQ6qCPRdkwijWlsM(XE1m2OlTPjKg)
	fqrc1SU2xACKDv46REBmJpwy = UnJu5mvBrPKqOidwpNcjAbh(fqrc1SU2xACKDv46REBmJpwy,qbPw1d3KimF(u"࠭࠱࠳࠳࠻࠷࠶࠾࠵࠴ࠩᓀ"))
	HECreS1dtwzDoq2P7G9FMA8Zx = {b05yftsZ6NYgIKP(u"ࠧࡪࡦࡶࠫᓁ"):k5dztomYyN3H(u"ࠨࡆࡌࡅࡑࡕࡇࠨᓂ"),b05yftsZ6NYgIKP(u"ࠩࡸࡷࡷ࠭ᓃ"):zAs8PWQk52VL9iaZwEcyOjm,RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠪࡺࡪࡸࠧᓄ"):RhVj0vAt5kPHm,FGDJwkEbTB5SoXujs3f(u"ࠫࡸࡩࡲࠨᓅ"):BlgEahu7f5yptCFwdW,nr5mZG89ICi6cgt4MfLJa0(u"ࠬࡹࡩࡻࠩᓆ"):fqrc1SU2xACKDv46REBmJpwy}
	jcFIzWOZiVGxa7Hr8pP1vb = {WMkAjB1RgN7q(u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬᓇ"):b05yftsZ6NYgIKP(u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩ࠭ᓈ")}
	TM3nsZ1w0yCAFp2ievIgSm = mORwgTnXBdQ7iCSHKf(UuEtImzir9,qbPw1d3KimF(u"ࠨࡒࡒࡗ࡙࠭ᓉ"),JJr825O7Aw3YeUGMqdWkxfl0u6SZ,HECreS1dtwzDoq2P7G9FMA8Zx,jcFIzWOZiVGxa7Hr8pP1vb,RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠩࠪᓊ"),fY5wTlhtnOc0Er6sdy4k87b(u"ࠪࠫᓋ"),NVS30xAdRFMIw1n9CislkE2(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲࡙ࡈࡐ࡙ࡢࡔࡑࡇ࡙ࡠࡆࡌࡅࡑࡕࡇ࠮࠳ࡶࡸࠬᓌ"))
	JXFSIEYxeMPpd7y538 = TM3nsZ1w0yCAFp2ievIgSm.content
	try:
		if not JXFSIEYxeMPpd7y538: EzphZgunUil
		xV2Gi5FWvRJAhXCNHjq1Y = dWsa2A0O4o5BYiqGXhyKEbM(RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠬࡪࡩࡤࡶࠪᓍ"),JXFSIEYxeMPpd7y538)
		WWaBo6eLKFdlt3yZfsrSVcGb = xV2Gi5FWvRJAhXCNHjq1Y[NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠭࡭ࡴࡩࠪᓎ")]
		eT6hOmL3SgDu5UjkVGrZbfv4C = xV2Gi5FWvRJAhXCNHjq1Y[NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠧࡴࡧࡦࠫᓏ")]
		nTq5j0zl1xgkiyWD = xV2Gi5FWvRJAhXCNHjq1Y[l0WAe1f7Bpi5ZXk(u"ࠨࡵࡷࡴࠬᓐ")]
		eT6hOmL3SgDu5UjkVGrZbfv4C = int(mVx80hrNLHnf5bkGgD7y(eT6hOmL3SgDu5UjkVGrZbfv4C,NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠩ࠴࠶࠶࠾࠳࠲࠺࠸࠷ࠬᓑ")))
		nTq5j0zl1xgkiyWD = int(mVx80hrNLHnf5bkGgD7y(nTq5j0zl1xgkiyWD,qbPw1d3KimF(u"ࠪ࠵࠷࠷࠸࠴࠳࠻࠹࠸࠭ᓒ")))
		for LHDlNFinObKfq9sw7IEtoSPj2pzJGc in range(eT6hOmL3SgDu5UjkVGrZbfv4C,EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠲᝸"),-nTq5j0zl1xgkiyWD):
			if not eval(BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠫࡽࡨ࡭ࡤ࠰ࡓࡰࡦࡿࡥࡳࠪࠬ࠲࡮ࡹࡐ࡭ࡣࡼ࡭ࡳ࡭ࡖࡪࡦࡨࡳ࠭࠯ࠧᓓ"),{C2dgEDAKQGsvh(u"ࠬࡾࡢ࡮ࡥࠪᓔ"):tUXmK5PeEH9SDq}): EzphZgunUil
			gj7BGM5t3RZpA0vNixLqzwualb16(l0WAe1f7Bpi5ZXk(u"࠭ศศไํࠤ้๊สอำหอࠥ๎วๅใะูࠬᓕ"),str(LHDlNFinObKfq9sw7IEtoSPj2pzJGc)+k5dztomYyN3H(u"ࠧࠡࠢฮห๋๐ษࠨᓖ"),KBxPW9cX8dqtaUDG=C2jP0iLNGKnHu9xp(u"࠶࠴࠵᝹")*nTq5j0zl1xgkiyWD)
			tUXmK5PeEH9SDq.sleep(WMkAjB1RgN7q(u"࠵࠵࠶࠰᝺")*nTq5j0zl1xgkiyWD)
		if eval(BoWHNb9daQVCF16A(u"ࠨࡺࡥࡱࡨ࠴ࡐ࡭ࡣࡼࡩࡷ࠮ࠩ࠯࡫ࡶࡔࡱࡧࡹࡪࡰࡪ࡚࡮ࡪࡥࡰࠪࠬࠫᓗ"),{k5dztomYyN3H(u"ࠩࡻࡦࡲࡩࠧᓘ"):tUXmK5PeEH9SDq}):
			WWaBo6eLKFdlt3yZfsrSVcGb = WWaBo6eLKFdlt3yZfsrSVcGb.replace(C2jP0iLNGKnHu9xp(u"ࠪࡠࡳ࠭ᓙ"),fY5wTlhtnOc0Er6sdy4k87b(u"ࠫࡡࡢ࡮ࠨᓚ")).replace(V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠬࡢࡲࠨᓛ"),rbjsM8cRFiuA1(u"࠭࡜࡝ࡴࠪᓜ"))
			ZIOHgA3z0TBR(sRth5giAQzWlEVm7JOX(u"ࠧࠨᓝ"),NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠨะิ์ั࠭ᓞ"),sRth5giAQzWlEVm7JOX(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬᓟ"),WWaBo6eLKFdlt3yZfsrSVcGb)
		EzphZgunUil
	except: exec(NVS30xAdRFMIw1n9CislkE2(u"ࠪࡼࡧࡳࡣ࠯ࡒ࡯ࡥࡾ࡫ࡲࠩࠫ࠱ࡷࡹࡵࡰࠩࠫࠪᓠ"),{NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠫࡽࡨ࡭ࡤࠩᓡ"):tUXmK5PeEH9SDq})
	return
def G8CFYarLe1():
	exec(sRth5giAQzWlEVm7JOX(u"ࠬ࠭ࠧࠎࠌࡷࡶࡾࡀࠍࠋࠋࡺ࡭ࡳࡪ࡯ࡸ࠳࠵࠷ࠥࡃࠠࡹࡤࡰࡧ࡬ࡻࡩ࠯࡙࡬ࡲࡩࡵࡷࠩ࠳࠳࠴࠷࠻ࠩࠎࠌࠌࡻ࡭࡯࡬ࡦࠢࡗࡶࡺ࡫࠺ࠎࠌࠌࠍࡽࡨ࡭ࡤ࠰ࡶࡰࡪ࡫ࡰࠩ࠳࠳࠴࠵࠯ࠍࠋࠋࠌࡸࡷࡿ࠺ࠡࡹ࡬ࡲࡩࡵࡷ࠲࠴࠶࠲࡬࡫ࡴࡇࡱࡦࡹࡸ࠮࠱࠱࠲࠵࠹࠮ࠓࠊࠊࠋࡨࡼࡨ࡫ࡰࡵ࠼ࠣࡦࡷ࡫ࡡ࡬ࠏࠍࠍࡿࡩࡲࡦࡣࡷࡩࡤ࡫ࡲࡰࡴࡵࠑࠏ࡫ࡸࡤࡧࡳࡸ࠿ࠦࡸࡣ࡯ࡦ࠲ࡕࡲࡡࡺࡧࡵࠬ࠮࠴ࡳࡵࡱࡳࠬ࠮ࠓࠊࠨࠩࠪᓢ"),{rbjsM8cRFiuA1(u"࠭ࡸࡣ࡯ࡦ࡫ࡺ࡯ࠧᓣ"):XUYb0K2ghSyFs,NVS30xAdRFMIw1n9CislkE2(u"ࠧࡹࡤࡰࡧࠬᓤ"):tUXmK5PeEH9SDq})
	return
def SIG93nyQ6qCPRdkwijWlsM(ATaJM8UXj5kvWeLnP01):
	HHpJgQV3IwWl18h02,ssuJokZgUN2SDTVMHQeyb3Idm0F = v5EA6TqHX3s4jzBMk(u"࠵᝻"),v5EA6TqHX3s4jzBMk(u"࠵᝻")
	if XXRtDhYvWb35qnLBxIri7ScNUks0.path.exists(ATaJM8UXj5kvWeLnP01):
		try: HHpJgQV3IwWl18h02 = XXRtDhYvWb35qnLBxIri7ScNUks0.path.getsize(ATaJM8UXj5kvWeLnP01)
		except: pass
		if not HHpJgQV3IwWl18h02:
			try: HHpJgQV3IwWl18h02 = XXRtDhYvWb35qnLBxIri7ScNUks0.stat(ATaJM8UXj5kvWeLnP01).st_size
			except: pass
		if not HHpJgQV3IwWl18h02:
			try:
				from pathlib import Path as XmtKLw7sOSYzN9fh
				HHpJgQV3IwWl18h02 = XmtKLw7sOSYzN9fh(ATaJM8UXj5kvWeLnP01).stat().st_size
			except: pass
		if HHpJgQV3IwWl18h02: ssuJokZgUN2SDTVMHQeyb3Idm0F = gItVahxL0w(u"࠷᝼")
	return HHpJgQV3IwWl18h02,ssuJokZgUN2SDTVMHQeyb3Idm0F
def SSRbfdTHKi1ngDyzeGt5X(gQMRO5btr6ClWqdLuS8wHD7FYy0G,TTSPbCuecdx5t0LYrE,showDialogs):
	if showDialogs:
		tLwvQlnjGpWsRVCN1 = mmwySO1P4jnKz5(hhlbF1Sns5TrEN8QPCYmL4(u"ࠨࠩᓥ"),jx7s8T0BFgODXLMzIYedf(u"ࠩࠪᓦ"),C2dgEDAKQGsvh(u"ࠪࠫᓧ"),nr5mZG89ICi6cgt4MfLJa0(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᓨ"),gQMRO5btr6ClWqdLuS8wHD7FYy0G+RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠬࡢ࡮࡝ࡰࠪᓩ")+QynMHGWA0blfqTUdxRh5Jzi2t(u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞้็ࠤฯื๊ะ่ࠢืาࠦ็ัษࠣห้๋ฬๅัࠣรࠦࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᓪ"))
		if tLwvQlnjGpWsRVCN1!=UxS67uoGThbMwnfNRzy4gajLd23JH(u"࠱᝽"): return
	tnOo1QlfFN98JVG6vreRLxb0 = nr5mZG89ICi6cgt4MfLJa0(u"ࡋࡧ࡬ࡴࡧ᠎")
	if XXRtDhYvWb35qnLBxIri7ScNUks0.path.exists(gQMRO5btr6ClWqdLuS8wHD7FYy0G):
		for JsNYaEqGDOVRQ1XSHCMvyri8PBgLe,mqkyFQwTH09UsdS2,ICrG9yhsUjHlxT68z7 in XXRtDhYvWb35qnLBxIri7ScNUks0.walk(gQMRO5btr6ClWqdLuS8wHD7FYy0G,topdown=FGDJwkEbTB5SoXujs3f(u"ࡌࡡ࡭ࡵࡨ᠏")):
			for ATaJM8UXj5kvWeLnP01 in ICrG9yhsUjHlxT68z7:
				M7LVXIUhsB2Jnjxy = XXRtDhYvWb35qnLBxIri7ScNUks0.path.join(JsNYaEqGDOVRQ1XSHCMvyri8PBgLe,ATaJM8UXj5kvWeLnP01)
				try: XXRtDhYvWb35qnLBxIri7ScNUks0.remove(M7LVXIUhsB2Jnjxy)
				except Exception as Kx45lGUDX6Ejpk9Qs3nvfLuWNATBY:
					if showDialogs and not tnOo1QlfFN98JVG6vreRLxb0: ZIOHgA3z0TBR(vvHpKfcqRnrFzjG(u"ࠧࠨᓫ"),PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠨࠩᓬ"),NVS30xAdRFMIw1n9CislkE2(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬᓭ"),str(Kx45lGUDX6Ejpk9Qs3nvfLuWNATBY))
					tnOo1QlfFN98JVG6vreRLxb0 = LgpdP3UjFRnlX(u"ࡔࡳࡷࡨ᠐")
			if TTSPbCuecdx5t0LYrE:
				for dir in mqkyFQwTH09UsdS2:
					yIMvRCaGHxQncLs = XXRtDhYvWb35qnLBxIri7ScNUks0.path.join(JsNYaEqGDOVRQ1XSHCMvyri8PBgLe,dir)
					try: XXRtDhYvWb35qnLBxIri7ScNUks0.rmdir(yIMvRCaGHxQncLs)
					except: pass
		if TTSPbCuecdx5t0LYrE:
			try: XXRtDhYvWb35qnLBxIri7ScNUks0.rmdir(JsNYaEqGDOVRQ1XSHCMvyri8PBgLe)
			except: pass
	if showDialogs and not tnOo1QlfFN98JVG6vreRLxb0:
		ZIOHgA3z0TBR(NVS30xAdRFMIw1n9CislkE2(u"ࠪࠫᓮ"),qbPw1d3KimF(u"ࠫࠬᓯ"),qbPw1d3KimF(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᓰ"),l0WAe1f7Bpi5ZXk(u"࠭สๆࠢสู่๊อࠡส้ะฬำࠧᓱ"))
		bLEBi8IO7uU2x3htYDdVq95.setSetting(qbPw1d3KimF(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡶࡪ࡬ࡲࡦࡵ࡫ࠫᓲ"),UnWjVbo503mEMv9KF(u"ࠨࡕࡒࡑࡊ࡚ࡈࡊࡐࡊࠫᓳ"))
		tUXmK5PeEH9SDq.executebuiltin(EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡘࡥࡧࡴࡨࡷ࡭࠭ᓴ"))
	return
def V69VaywMFGd(WFMmPzdINGnfvRC1BoeOpb5=qbPw1d3KimF(u"ࠪࠫᓵ")):
	NZrI2wknju57PlJaDoRziLVm1(NVS30xAdRFMIw1n9CislkE2(u"ࠫࡸࡺ࡯ࡱࠩᓶ"))
	if WFMmPzdINGnfvRC1BoeOpb5:
		xvH1PfgscOb0Bw9Ljn = bLEBi8IO7uU2x3htYDdVq95.getSetting(BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠬࡧࡶ࠯࡮ࡤࡲ࡬ࡻࡡࡨࡧ࠱ࡸࡷࡧ࡮ࡴ࡮ࡤࡸࡪ࠭ᓷ"))
		bLEBi8IO7uU2x3htYDdVq95.setSetting(V2RbfGOBdcA6l8NTsPWzEyvS7(u"࠭ࡡࡷ࠰࡯ࡥࡳ࡭ࡵࡢࡩࡨ࠲ࡹࡸࡡ࡯ࡵ࡯ࡥࡹ࡫ࠧᓸ"),FGDJwkEbTB5SoXujs3f(u"ࠧࠨᓹ"))
		IhzTf3wxBDQcmHRgrjN7qEi8kn(WFMmPzdINGnfvRC1BoeOpb5)
		bLEBi8IO7uU2x3htYDdVq95.setSetting(gItVahxL0w(u"ࠨࡣࡹ࠲ࡱࡧ࡮ࡨࡷࡤ࡫ࡪ࠴ࡴࡳࡣࡱࡷࡱࡧࡴࡦࠩᓺ"),xvH1PfgscOb0Bw9Ljn)
	zJwPBdKbhsfqD5vX = bLEBi8IO7uU2x3htYDdVq95.getSetting(fY5wTlhtnOc0Er6sdy4k87b(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡸࡥࡧࡴࡨࡷ࡭࠭ᓻ"))
	if zJwPBdKbhsfqD5vX==T6wRistc1SCo4hqObgumK(u"ࠪࡖࡊࡗࡕࡆࡕࡗࡉࡉ࠭ᓼ"): bLEBi8IO7uU2x3htYDdVq95.setSetting(NVS30xAdRFMIw1n9CislkE2(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡳࡧࡩࡶࡪࡹࡨࠨᓽ"),BoWHNb9daQVCF16A(u"ࠬࡘࡅࡇࡔࡈࡗࡍࡋࡄࠨᓾ"))
	elif zJwPBdKbhsfqD5vX==WMkAjB1RgN7q(u"࠭ࡒࡆࡈࡕࡉࡘࡎࡅࡅࠩᓿ"): bLEBi8IO7uU2x3htYDdVq95.setSetting(sRth5giAQzWlEVm7JOX(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡶࡪ࡬ࡲࡦࡵ࡫ࠫᔀ"),k5dztomYyN3H(u"ࠨࠩᔁ"))
	if bLEBi8IO7uU2x3htYDdVq95.getSetting(T6wRistc1SCo4hqObgumK(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡦࡱࡷࠬᔂ")) not in [v5EA6TqHX3s4jzBMk(u"ࠪࡅ࡚࡚ࡏࠨᔃ"),k5dztomYyN3H(u"ࠫࡘ࡚ࡏࡑࠩᔄ"),rbjsM8cRFiuA1(u"ࠬࡇࡓࡌࠩᔅ")]: bLEBi8IO7uU2x3htYDdVq95.setSetting(PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡸࡷࡪࡪ࡮ࡴࠩᔆ"),YB5xyI7MaRslVpv(u"ࠧࡂࡕࡎࠫᔇ"))
	if bLEBi8IO7uU2x3htYDdVq95.getSetting(sRth5giAQzWlEVm7JOX(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡺࡹࡥࡱࡴࡲࡼࡾ࠭ᔈ")) not in [jx7s8T0BFgODXLMzIYedf(u"ࠩࡄ࡙࡙ࡕࠧᔉ"),NVS30xAdRFMIw1n9CislkE2(u"ࠪࡗ࡙ࡕࡐࠨᔊ"),jx7s8T0BFgODXLMzIYedf(u"ࠫࡆ࡙ࡋࠨᔋ")]: bLEBi8IO7uU2x3htYDdVq95.setSetting(WMkAjB1RgN7q(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡷࡶࡩࡵࡸ࡯ࡹࡻࠪᔌ"),rbjsM8cRFiuA1(u"࠭ࡁࡔࡍࠪᔍ"))
	jrdW1HU0fOqmZVigyeuw9txY = bLEBi8IO7uU2x3htYDdVq95.getSetting(NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠧࡢࡸ࠱ࡱࡾࡹ࡫ࡪࡰ࠱ࡺ࡮࡫ࡷ࡮ࡱࡧࡩࠬᔎ"))
	ox3AQF7vIVBRjkD9 = tUXmK5PeEH9SDq.executeJSONRPC(gItVahxL0w(u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡔࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡊࡩࡹ࡙ࡥࡵࡶ࡬ࡲ࡬࡜ࡡ࡭ࡷࡨࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡶࡩࡹࡺࡩ࡯ࡩࠥ࠾ࠧࡲ࡯ࡰ࡭ࡤࡲࡩ࡬ࡥࡦ࡮࠱ࡷࡰ࡯࡮ࠣࡿࢀࠫᔏ"))
	if vvHpKfcqRnrFzjG(u"ࠩࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄࠨᔐ") in str(ox3AQF7vIVBRjkD9) and jrdW1HU0fOqmZVigyeuw9txY in [UnWjVbo503mEMv9KF(u"ࠪࡉࡒࡇࡄࠡࡎ࡬ࡷࡹ࠭ᔑ"),EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠫࡊࡓࡁࡅࠢࡊࡥࡱࡲࡥࡳࡻࠪᔒ")]:
		KBxPW9cX8dqtaUDG.sleep(UnWjVbo503mEMv9KF(u"࠱࠰࠴࠴࠵᝾"))
		tUXmK5PeEH9SDq.executebuiltin(UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡕࡨࡸ࡛࡯ࡥࡸࡏࡲࡨࡪ࠮࠰ࠪࠩᔓ"))
	if vvHpKfcqRnrFzjG(u"࠳ក") and n6ReHNYovBwFxiuJ>-vvHpKfcqRnrFzjG(u"࠳᝿"):
		VMKAudnbXHORPj.setResolvedUrl(n6ReHNYovBwFxiuJ,UnWjVbo503mEMv9KF(u"ࡇࡣ࡯ࡷࡪ᠑"),XUYb0K2ghSyFs.ListItem())
		tUEvo5HAfIjZgcdYxNJ8awu,OXHVSz957gsf3cKw,pZbHmRVkwf2aIUqJYOSjr943B0MnP5 = k5dztomYyN3H(u"ࡈࡤࡰࡸ࡫᠒"),k5dztomYyN3H(u"ࡈࡤࡰࡸ࡫᠒"),k5dztomYyN3H(u"ࡈࡤࡰࡸ࡫᠒")
		VMKAudnbXHORPj.endOfDirectory(n6ReHNYovBwFxiuJ,tUEvo5HAfIjZgcdYxNJ8awu,OXHVSz957gsf3cKw,pZbHmRVkwf2aIUqJYOSjr943B0MnP5)
	return
def MPEKR1d2NIxFWaS(f0KUlmeMpWgFsPk16On,ww2vqCObJMBYRUaDyuWQ0,qmr7vLh1EW,AqLgT4S6FExHi1kZ5smy7a0hRX,ib6URTIJnFlgVwXsQAN0ZGD4k9c3ph,iW6eqtHJGnzFhTSgduj7Pys2w):
	bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,eG5xjWgRUhC8f,RRfNT13COItMrPdJlEgq,nnDRPzg7XWmorOjQMtU5hxH = I1zAN6ZaFrhSfMojPKTLmiG2(qmr7vLh1EW)
	FatuQ5gf41DEVHjxBMKwbnyd7ziSl = ww2vqCObJMBYRUaDyuWQ0,bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,AqLgT4S6FExHi1kZ5smy7a0hRX,ib6URTIJnFlgVwXsQAN0ZGD4k9c3ph
	if f0KUlmeMpWgFsPk16On:
		qqThxfYXnogSpAiJ7GkcLz = zPgNsqpJInt(RnqtMUa9Nh6peGEsBT,LgpdP3UjFRnlX(u"࠭ࡳࡵࡴࠪᔔ"),UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠧࡐࡒࡈࡒ࡚ࡘࡌࡠࡗࡕࡐࡑࡏࡂࠨᔕ"),FatuQ5gf41DEVHjxBMKwbnyd7ziSl)
		if qqThxfYXnogSpAiJ7GkcLz:
			GGDIbyLQYfvdjAMi9(sRth5giAQzWlEVm7JOX(u"ࠨࡗࡕࡐࡑࡏࡂࠡࠢࡕࡉࡆࡊ࡟ࡄࡃࡆࡌࡊ࠭ᔖ"),qmr7vLh1EW,AqLgT4S6FExHi1kZ5smy7a0hRX,ib6URTIJnFlgVwXsQAN0ZGD4k9c3ph,iW6eqtHJGnzFhTSgduj7Pys2w,ww2vqCObJMBYRUaDyuWQ0)
			return qqThxfYXnogSpAiJ7GkcLz
	qqThxfYXnogSpAiJ7GkcLz = KNGXqQl2C9beWRL71FMwVxfU(ww2vqCObJMBYRUaDyuWQ0,qmr7vLh1EW,AqLgT4S6FExHi1kZ5smy7a0hRX,ib6URTIJnFlgVwXsQAN0ZGD4k9c3ph,iW6eqtHJGnzFhTSgduj7Pys2w)
	if qqThxfYXnogSpAiJ7GkcLz and f0KUlmeMpWgFsPk16On: VZ8BTik93OqXLCh0fD7d2KUPpn4mH6(RnqtMUa9Nh6peGEsBT,C2jP0iLNGKnHu9xp(u"ࠩࡒࡔࡊࡔࡕࡓࡎࡢ࡙ࡗࡒࡌࡊࡄࠪᔗ"),FatuQ5gf41DEVHjxBMKwbnyd7ziSl,qqThxfYXnogSpAiJ7GkcLz,f0KUlmeMpWgFsPk16On)
	return qqThxfYXnogSpAiJ7GkcLz
from rqgUeajx8A import *
# -*- coding: utf-8 -*-
from G6AHskJeqN import *
baNWS6nfqTC5iX4Kl = 'SHAHIDNEWS'
teUPLFC3B8bArakwHVGsdhoIWDM49f = '_SHN_'
EZxQp1WOldMTvFU = AK5RqLhji4W1wt9VdrCD3PGeQM[baNWS6nfqTC5iX4Kl][0]
eh2tDvRFWpLQI = ['قنوات فضائية','فارسكو','Show more']
def VbgEajY4Bt2COpGDcPqI(mode,url,text):
	if   mode==580: ft3e2JBKQVXWlFPjaMhkEqGxvDg = eN02L7Tf5bQ()
	elif mode==581: ft3e2JBKQVXWlFPjaMhkEqGxvDg = sscM839DP1jWZ4zl6uIx0Kyn(url,text)
	elif mode==582: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HDxCnPKFhITpZmOsA4a0UL6(url)
	elif mode==583: ft3e2JBKQVXWlFPjaMhkEqGxvDg = o4oY13v5dWMcbilEDjKCnXNzHZ0(url,text)
	elif mode==584: ft3e2JBKQVXWlFPjaMhkEqGxvDg = M25iOAH9NfalvyPEUuToG8qn(url)
	elif mode==589: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HjZcUIVAXFCqy9TfBWKtgY2(text)
	else: ft3e2JBKQVXWlFPjaMhkEqGxvDg = False
	return ft3e2JBKQVXWlFPjaMhkEqGxvDg
def eN02L7Tf5bQ():
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',EZxQp1WOldMTvFU,'','','','','SHAHIDNEWS-MENU-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'بحث في الموقع','',589,'','','_REMEMBERRESULTS_')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('/category.php">(.*?)"navslide-divider"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	vsptNMP2ZQC = XBuP6Op7y4K[0]
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall("'dropdown-menu'(.*?)</ul>",MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	for iiBEzXVNFDhfj36 in XBuP6Op7y4K: vsptNMP2ZQC = vsptNMP2ZQC.replace(iiBEzXVNFDhfj36,'')
	items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?>(.*?)</a>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	for BoEFz2WhUyvTgDeiZ,title in items:
		if title in eh2tDvRFWpLQI: continue
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,584)
	return
def M25iOAH9NfalvyPEUuToG8qn(url):
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'','','','','SHAHIDNEWS-SUBMENU-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	KRI8WExzA4p = My7Dwqvs6bfGNSIgX.findall('"caret"(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if KRI8WExzA4p:
		vsptNMP2ZQC = KRI8WExzA4p[0]
		vsptNMP2ZQC = vsptNMP2ZQC.replace('"presentation"','</ul>')
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		if not XBuP6Op7y4K: XBuP6Op7y4K = [('',vsptNMP2ZQC)]
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] فرز أو فلتر أو ترتيب [/COLOR]','',9999)
		for bN5qWnCM903cj4zHxEasi1pBY7ZdrR,vsptNMP2ZQC in XBuP6Op7y4K:
			items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?>(.*?)</a>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
			if bN5qWnCM903cj4zHxEasi1pBY7ZdrR: bN5qWnCM903cj4zHxEasi1pBY7ZdrR = bN5qWnCM903cj4zHxEasi1pBY7ZdrR+': '
			for BoEFz2WhUyvTgDeiZ,title in items:
				title = bN5qWnCM903cj4zHxEasi1pBY7ZdrR+title
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,581)
	kdYXhMN8Hpbt = My7Dwqvs6bfGNSIgX.findall('"pm-category-subcats"(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if kdYXhMN8Hpbt:
		vsptNMP2ZQC = kdYXhMN8Hpbt[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)">(.*?)</a>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		if len(items)<30:
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
			for BoEFz2WhUyvTgDeiZ,title in items:
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,581)
	if not KRI8WExzA4p and not kdYXhMN8Hpbt: sscM839DP1jWZ4zl6uIx0Kyn(url)
	return
def sscM839DP1jWZ4zl6uIx0Kyn(url,h5QaxwPF7SOu6fMBTGXRU2yn=''):
	xxE5BSyQkNsj = ooq2D9xF8ZLpPBs(url,'url')
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'','','','','SHAHIDNEWS-TITLES-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	items = []
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('(data-echo=".*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if not XBuP6Op7y4K: XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"BlocksList"(.*?)"titleSectionCon"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if not XBuP6Op7y4K: XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('id="pm-grid"(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if not XBuP6Op7y4K: XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('id="pm-related"(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if not XBuP6Op7y4K: return
	vsptNMP2ZQC = XBuP6Op7y4K[0]
	if not items: items = My7Dwqvs6bfGNSIgX.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	if not items: items = My7Dwqvs6bfGNSIgX.findall('src="(.*?)".*?href="(.*?)".*?>(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	y7y3d5Fbhv42ONmtwLZ0SerYoQq = []
	tkBQK76YMeUlRI1TomgECfA = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for IcWzVO137wFvemn2QTq8yKs9,BoEFz2WhUyvTgDeiZ,title in items:
		BoEFz2WhUyvTgDeiZ = XnQbsZF0Ouh8p7zCdUN(BoEFz2WhUyvTgDeiZ).strip('/')
		if 'http' not in BoEFz2WhUyvTgDeiZ: BoEFz2WhUyvTgDeiZ = xxE5BSyQkNsj+'/'+BoEFz2WhUyvTgDeiZ.strip('/')
		if 'http' not in IcWzVO137wFvemn2QTq8yKs9: IcWzVO137wFvemn2QTq8yKs9 = xxE5BSyQkNsj+'/'+IcWzVO137wFvemn2QTq8yKs9.strip('/')
		ffhN7jAqe3Q4cR0Ukptzl = My7Dwqvs6bfGNSIgX.findall('(.*?) الحلقة \d+',title,My7Dwqvs6bfGNSIgX.DOTALL)
		if any(WoFrX46wzbCNp18 in title for WoFrX46wzbCNp18 in tkBQK76YMeUlRI1TomgECfA):
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,582,IcWzVO137wFvemn2QTq8yKs9)
		elif ffhN7jAqe3Q4cR0Ukptzl and 'الحلقة' in title:
			title = '_MOD_' + ffhN7jAqe3Q4cR0Ukptzl[0]
			if title not in y7y3d5Fbhv42ONmtwLZ0SerYoQq:
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,583,IcWzVO137wFvemn2QTq8yKs9)
				y7y3d5Fbhv42ONmtwLZ0SerYoQq.append(title)
		elif '/movseries/' in BoEFz2WhUyvTgDeiZ:
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,581,IcWzVO137wFvemn2QTq8yKs9)
		else: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,583,IcWzVO137wFvemn2QTq8yKs9)
	if h5QaxwPF7SOu6fMBTGXRU2yn not in ['featured_movies','featured_series']:
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"pagination(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if XBuP6Op7y4K:
			vsptNMP2ZQC = XBuP6Op7y4K[0]
			items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?>(.*?)</a>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
			for BoEFz2WhUyvTgDeiZ,title in items:
				if BoEFz2WhUyvTgDeiZ=='#': continue
				BoEFz2WhUyvTgDeiZ = xxE5BSyQkNsj+'/'+BoEFz2WhUyvTgDeiZ.strip('/')
				title = PIfAumbGicwg5ye(title)
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'صفحة '+title,BoEFz2WhUyvTgDeiZ,581)
		g7gdVaoK3PHGpJ1YBxvTSUkz = My7Dwqvs6bfGNSIgX.findall('showmore" href="(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if g7gdVaoK3PHGpJ1YBxvTSUkz:
			BoEFz2WhUyvTgDeiZ = g7gdVaoK3PHGpJ1YBxvTSUkz[0]
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'مشاهدة المزيد',BoEFz2WhUyvTgDeiZ,581)
	return
def o4oY13v5dWMcbilEDjKCnXNzHZ0(url,b0z14BOJQMs):
	xxE5BSyQkNsj = ooq2D9xF8ZLpPBs(url,'url')
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'','','','','SHAHIDNEWS-EPISODES-2nd')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	KRI8WExzA4p = My7Dwqvs6bfGNSIgX.findall('nav-seasons"(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	items = []
	uq1Ayb0IlosZdzU54jBTnRK9 = False
	if KRI8WExzA4p and not b0z14BOJQMs:
		vsptNMP2ZQC = KRI8WExzA4p[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)">(.*?)</a>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for b0z14BOJQMs,title in items:
			b0z14BOJQMs = b0z14BOJQMs.strip('#')
			if len(items)>1: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,url,583,'','',b0z14BOJQMs)
			else: uq1Ayb0IlosZdzU54jBTnRK9 = True
	else: uq1Ayb0IlosZdzU54jBTnRK9 = True
	kdYXhMN8Hpbt = My7Dwqvs6bfGNSIgX.findall('id="'+b0z14BOJQMs+'"(.*?)</div>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if kdYXhMN8Hpbt and uq1Ayb0IlosZdzU54jBTnRK9:
		vsptNMP2ZQC = kdYXhMN8Hpbt[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?">(.*?)</a>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		if items:
			for BoEFz2WhUyvTgDeiZ,title in items:
				BoEFz2WhUyvTgDeiZ = xxE5BSyQkNsj+'/'+BoEFz2WhUyvTgDeiZ.strip('/')
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,582)
		else:
			items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?title="(.*?)".*?image:url\((.*?)\)',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
			for BoEFz2WhUyvTgDeiZ,title,IcWzVO137wFvemn2QTq8yKs9 in items:
				if 'http' not in BoEFz2WhUyvTgDeiZ: BoEFz2WhUyvTgDeiZ = xxE5BSyQkNsj+'/'+BoEFz2WhUyvTgDeiZ.strip('/')
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,582)
	return
def HDxCnPKFhITpZmOsA4a0UL6(url):
	xxE5BSyQkNsj = ooq2D9xF8ZLpPBs(url,'url')
	QQ2cE1FjUyxPonbDhaTkV6B3i = []
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'','','','','SHAHIDNEWS-PLAY-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	BoEFz2WhUyvTgDeiZ = My7Dwqvs6bfGNSIgX.findall('"Playerholder".*?href="(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ[0]
	if BoEFz2WhUyvTgDeiZ and 'http' not in BoEFz2WhUyvTgDeiZ: BoEFz2WhUyvTgDeiZ = 'http:'+BoEFz2WhUyvTgDeiZ
	hash = BoEFz2WhUyvTgDeiZ.split('hash=')[1]
	tuHzpfZmLAdCObQS2k3 = hash.split('__')
	B8kXz0CUtDVZhS = []
	for F6Q8eBGhXzKwoyN in tuHzpfZmLAdCObQS2k3:
		try:
			F6Q8eBGhXzKwoyN = NfzkjQicS24ZYLMWuXFRwV5Ea7.b64decode(F6Q8eBGhXzKwoyN+'=')
			if BLz7m2RkNrxXQwy1cGAp: F6Q8eBGhXzKwoyN = F6Q8eBGhXzKwoyN.decode('utf8')
			B8kXz0CUtDVZhS.append(F6Q8eBGhXzKwoyN)
		except: pass
	NVHrZsqUp2 = '>'.join(B8kXz0CUtDVZhS)
	NVHrZsqUp2 = NVHrZsqUp2.splitlines()
	if 'farsol' not in str(NVHrZsqUp2):
		for BoEFz2WhUyvTgDeiZ in NVHrZsqUp2:
			title,BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ.split(' => ')
			BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ+'?named='+title+'__watch'
			QQ2cE1FjUyxPonbDhaTkV6B3i.append(BoEFz2WhUyvTgDeiZ)
		import t1kDWXQVpC
		t1kDWXQVpC.rqVt2xDi7jzJHBcPMRs6h0L(QQ2cE1FjUyxPonbDhaTkV6B3i,baNWS6nfqTC5iX4Kl,'video',url)
	else:
		title,BoEFz2WhUyvTgDeiZ = NVHrZsqUp2[0].split(' => ')
		ZIOHgA3z0TBR('','','رسالة من المبرمج','هذا الفيديو غير متوفر الآن'+'\n'+'يرجى المحاولة لاحقا'+'\n\n'+title)
	return
def HjZcUIVAXFCqy9TfBWKtgY2(search):
	search,LQf3AeozSrai,showDialogs = X54MLovbG8nAEkB9J(search)
	if search=='': search = ViKAIsLurq83RSENayxWb()
	if search=='': return
	search = search.replace(' ','+')
	url = EZxQp1WOldMTvFU+'/search.php?keywords='+search
	sscM839DP1jWZ4zl6uIx0Kyn(url)
	return
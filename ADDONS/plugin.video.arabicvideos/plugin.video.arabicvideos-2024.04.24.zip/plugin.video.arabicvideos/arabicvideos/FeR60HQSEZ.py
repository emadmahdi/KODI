# -*- coding: utf-8 -*-
from G6AHskJeqN import *
baNWS6nfqTC5iX4Kl = 'KATKOUTE'
teUPLFC3B8bArakwHVGsdhoIWDM49f = '_KTK_'
EZxQp1WOldMTvFU = AK5RqLhji4W1wt9VdrCD3PGeQM[baNWS6nfqTC5iX4Kl][0]
eh2tDvRFWpLQI = ['الصفحة الرئيسية','Sign in','الأقسام']
def VbgEajY4Bt2COpGDcPqI(mode,url,text):
	if   mode==670: ft3e2JBKQVXWlFPjaMhkEqGxvDg = eN02L7Tf5bQ()
	elif mode==671: ft3e2JBKQVXWlFPjaMhkEqGxvDg = sscM839DP1jWZ4zl6uIx0Kyn(url,text)
	elif mode==672: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HDxCnPKFhITpZmOsA4a0UL6(url)
	elif mode==673: ft3e2JBKQVXWlFPjaMhkEqGxvDg = CbkBOWecfqN8Jajp1Dd(url,text)
	elif mode==674: ft3e2JBKQVXWlFPjaMhkEqGxvDg = M25iOAH9NfalvyPEUuToG8qn(url)
	elif mode==679: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HjZcUIVAXFCqy9TfBWKtgY2(text)
	else: ft3e2JBKQVXWlFPjaMhkEqGxvDg = False
	return ft3e2JBKQVXWlFPjaMhkEqGxvDg
def eN02L7Tf5bQ():
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',EZxQp1WOldMTvFU,'','','','','KATKOUTE-MENU-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'بحث في الموقع','',679,'','','_REMEMBERRESULTS_')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"navslide-divider"(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)">(.*?)</a>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title in items:
			if title in eh2tDvRFWpLQI: continue
			if title=='الأقسام': mode = 675
			else: mode = 674
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,mode)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	items = WeRdrIQhcKkPU(EZxQp1WOldMTvFU+'/watch/browse.html')
	for BoEFz2WhUyvTgDeiZ,IcWzVO137wFvemn2QTq8yKs9,title in items:
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,674,IcWzVO137wFvemn2QTq8yKs9)
	return
def WeRdrIQhcKkPU(url):
	kkAK8c2b6l = zPgNsqpJInt(RnqtMUa9Nh6peGEsBT,'list','KATKOUTE','CATEGORIES')
	if kkAK8c2b6l: return kkAK8c2b6l
	kkAK8c2b6l = []
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(SToQEHqGtMnAlFbCz4wxBDuOsmW7,'GET',url,'','','','','KATKOUTE-CATEGORIES-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"category-header"(.*?)<footer>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		kkAK8c2b6l = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?src="(.*?)" alt="(.*?)"',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		if kkAK8c2b6l: VZ8BTik93OqXLCh0fD7d2KUPpn4mH6(RnqtMUa9Nh6peGEsBT,'KATKOUTE','CATEGORIES',kkAK8c2b6l,IIiPCruL6dT8s1lqj47SzpVHnYNm)
	return kkAK8c2b6l
def M25iOAH9NfalvyPEUuToG8qn(url):
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'','','','','KATKOUTE-SUBMENU-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	KRI8WExzA4p = My7Dwqvs6bfGNSIgX.findall('"caret"(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if KRI8WExzA4p:
		vsptNMP2ZQC = KRI8WExzA4p[0]
		vsptNMP2ZQC = vsptNMP2ZQC.replace('"presentation"','</ul>')
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		if not XBuP6Op7y4K: XBuP6Op7y4K = [('',vsptNMP2ZQC)]
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] فرز أو فلتر أو ترتيب [/COLOR]','',9999)
		for bN5qWnCM903cj4zHxEasi1pBY7ZdrR,vsptNMP2ZQC in XBuP6Op7y4K:
			items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?>(.*?)</a>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
			if bN5qWnCM903cj4zHxEasi1pBY7ZdrR: bN5qWnCM903cj4zHxEasi1pBY7ZdrR = bN5qWnCM903cj4zHxEasi1pBY7ZdrR+': '
			for BoEFz2WhUyvTgDeiZ,title in items:
				title = bN5qWnCM903cj4zHxEasi1pBY7ZdrR+title
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,671)
	kdYXhMN8Hpbt = My7Dwqvs6bfGNSIgX.findall('"pm-category-subcats"(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if kdYXhMN8Hpbt:
		vsptNMP2ZQC = kdYXhMN8Hpbt[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)">(.*?)</a>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		if len(items)<30:
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
			for BoEFz2WhUyvTgDeiZ,title in items:
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,671)
	if not KRI8WExzA4p and not kdYXhMN8Hpbt: sscM839DP1jWZ4zl6uIx0Kyn(url)
	return
def sscM839DP1jWZ4zl6uIx0Kyn(url,h5QaxwPF7SOu6fMBTGXRU2yn=''):
	if h5QaxwPF7SOu6fMBTGXRU2yn=='ajax-search':
		url,search = url.split('?',1)
		data = 'queryString='+search
		headers = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'POST',url,data,headers,'','','KATKOUTE-TITLES-1st')
	else:
		xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'','','','','KATKOUTE-TITLES-2nd')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	vsptNMP2ZQC,items = '',[]
	xxE5BSyQkNsj = ooq2D9xF8ZLpPBs(url,'url')
	if h5QaxwPF7SOu6fMBTGXRU2yn=='ajax-search':
		vsptNMP2ZQC = MK6ZT2zjC1SbmveNFqor
		zE1FBZLDvygwGdkef74lnRJVXCUqKH = My7Dwqvs6bfGNSIgX.findall('href="(.*?)">(.*?)</a>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title in zE1FBZLDvygwGdkef74lnRJVXCUqKH: items.append(('',BoEFz2WhUyvTgDeiZ,title))
	elif h5QaxwPF7SOu6fMBTGXRU2yn=='featured':
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"pm-video-watch-featured"(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if XBuP6Op7y4K: vsptNMP2ZQC = XBuP6Op7y4K[0]
	elif h5QaxwPF7SOu6fMBTGXRU2yn=='new_episodes':
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"row pm-ul-browse-videos(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if XBuP6Op7y4K: vsptNMP2ZQC = XBuP6Op7y4K[0]
	elif h5QaxwPF7SOu6fMBTGXRU2yn=='new_movies':
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"row pm-ul-browse-videos(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if len(XBuP6Op7y4K)>1: vsptNMP2ZQC = XBuP6Op7y4K[1]
	elif h5QaxwPF7SOu6fMBTGXRU2yn=='featured_series':
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"home-series-list"(.*?)</div>[\t|\n]*</div>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if XBuP6Op7y4K: vsptNMP2ZQC = XBuP6Op7y4K[0]
		zE1FBZLDvygwGdkef74lnRJVXCUqKH = My7Dwqvs6bfGNSIgX.findall('href="(.*?)">(.*?)</a>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title in zE1FBZLDvygwGdkef74lnRJVXCUqKH: items.append(('',BoEFz2WhUyvTgDeiZ,title))
	else:
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('(data-echo=".*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if XBuP6Op7y4K: vsptNMP2ZQC = XBuP6Op7y4K[0]
	if vsptNMP2ZQC and not items: items = My7Dwqvs6bfGNSIgX.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	if not items: return
	y7y3d5Fbhv42ONmtwLZ0SerYoQq = []
	tkBQK76YMeUlRI1TomgECfA = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية','فلم']
	for IcWzVO137wFvemn2QTq8yKs9,BoEFz2WhUyvTgDeiZ,title in items:
		ffhN7jAqe3Q4cR0Ukptzl = My7Dwqvs6bfGNSIgX.findall('(.*?) (الحلقة|حلقة).\d+',title,My7Dwqvs6bfGNSIgX.DOTALL)
		if any(WoFrX46wzbCNp18 in title for WoFrX46wzbCNp18 in tkBQK76YMeUlRI1TomgECfA):
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,672,IcWzVO137wFvemn2QTq8yKs9)
		elif h5QaxwPF7SOu6fMBTGXRU2yn=='new_episodes':
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,672,IcWzVO137wFvemn2QTq8yKs9)
		elif ffhN7jAqe3Q4cR0Ukptzl:
			title = '_MOD_' + ffhN7jAqe3Q4cR0Ukptzl[0][0]
			if title not in y7y3d5Fbhv42ONmtwLZ0SerYoQq:
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,673,IcWzVO137wFvemn2QTq8yKs9)
				y7y3d5Fbhv42ONmtwLZ0SerYoQq.append(title)
		elif '/movseries/' in BoEFz2WhUyvTgDeiZ:
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,671,IcWzVO137wFvemn2QTq8yKs9)
		else: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,673,IcWzVO137wFvemn2QTq8yKs9)
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"pagination(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?>(.*?)</a>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title in items:
			if BoEFz2WhUyvTgDeiZ=='#': continue
			if 'http' not in BoEFz2WhUyvTgDeiZ:
				bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = url.rsplit('/',1)[0]
				BoEFz2WhUyvTgDeiZ = bJEs4IVAPdyUrhwCLv9k2YoOl8nt1+'/'+BoEFz2WhUyvTgDeiZ.strip('/')
			title = PIfAumbGicwg5ye(title)
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'صفحة '+title,BoEFz2WhUyvTgDeiZ,671,'','',h5QaxwPF7SOu6fMBTGXRU2yn)
	return
def CbkBOWecfqN8Jajp1Dd(url,b0z14BOJQMs):
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+'تشغيل الفيديو',url,672)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	kkAK8c2b6l = WeRdrIQhcKkPU(EZxQp1WOldMTvFU+'/watch/browse.html')
	eiDqCvPdwA2,wTARYM2qbmjL,CTt2qewJl8N4rgIvMRHDhWVnYjaip = zip(*kkAK8c2b6l)
	jjfPQV4Azuqoi2Sdm7s0kL = []
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'','','','','KATKOUTE-EPISODES-2nd')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"row pm-video-heading"(.*?)id="player"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		NVHrZsqUp2 = My7Dwqvs6bfGNSIgX.findall('class="myButton".*?href="(.*?)".*?<b>(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title in NVHrZsqUp2:
			if BoEFz2WhUyvTgDeiZ not in eiDqCvPdwA2:
				ZA1fBenNahOR3xrkjvwYSVMy6JK5s = (BoEFz2WhUyvTgDeiZ,title)
				jjfPQV4Azuqoi2Sdm7s0kL.append(ZA1fBenNahOR3xrkjvwYSVMy6JK5s)
		if len(jjfPQV4Azuqoi2Sdm7s0kL)==1:
			BoEFz2WhUyvTgDeiZ,title = jjfPQV4Azuqoi2Sdm7s0kL[0]
			sscM839DP1jWZ4zl6uIx0Kyn(BoEFz2WhUyvTgDeiZ,'new_episodes')
			return
		else:
			for BoEFz2WhUyvTgDeiZ,title in jjfPQV4Azuqoi2Sdm7s0kL:
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,671,'','','new_episodes')
	if not jjfPQV4Azuqoi2Sdm7s0kL: sscM839DP1jWZ4zl6uIx0Kyn(url,'new_episodes')
	return
def HDxCnPKFhITpZmOsA4a0UL6(url):
	Qki8AbTHYjzM2Ls76Gdr3eqo1Wn = []
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'','','','','KATKOUTE-PLAY-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('sources:(.*?)flashplayer',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		NVHrZsqUp2 = My7Dwqvs6bfGNSIgX.findall('file: "(.*?)".*?label: "(.*?)"',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,LLnUyuiC2wRM0 in NVHrZsqUp2:
			BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ+'?named=__watch__'+LLnUyuiC2wRM0
			Qki8AbTHYjzM2Ls76Gdr3eqo1Wn.append(BoEFz2WhUyvTgDeiZ)
	NVHrZsqUp2 = My7Dwqvs6bfGNSIgX.findall('"embedded-video".*?src="(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if not NVHrZsqUp2: NVHrZsqUp2 = My7Dwqvs6bfGNSIgX.findall("file: '(.*?)'",MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if NVHrZsqUp2:
		BoEFz2WhUyvTgDeiZ = NVHrZsqUp2[0]
		if 'http' not in BoEFz2WhUyvTgDeiZ: BoEFz2WhUyvTgDeiZ = 'http:'+BoEFz2WhUyvTgDeiZ
		Qki8AbTHYjzM2Ls76Gdr3eqo1Wn.append(BoEFz2WhUyvTgDeiZ+'?named=__embed')
	import t1kDWXQVpC
	t1kDWXQVpC.rqVt2xDi7jzJHBcPMRs6h0L(Qki8AbTHYjzM2Ls76Gdr3eqo1Wn,baNWS6nfqTC5iX4Kl,'video',url)
	return
def HjZcUIVAXFCqy9TfBWKtgY2(search):
	search,LQf3AeozSrai,showDialogs = X54MLovbG8nAEkB9J(search)
	if search=='': search = ViKAIsLurq83RSENayxWb()
	if search=='': return
	search = search.replace(' ','+')
	url = EZxQp1WOldMTvFU+'/watch/search.php?keywords='+search
	sscM839DP1jWZ4zl6uIx0Kyn(url,'search')
	return
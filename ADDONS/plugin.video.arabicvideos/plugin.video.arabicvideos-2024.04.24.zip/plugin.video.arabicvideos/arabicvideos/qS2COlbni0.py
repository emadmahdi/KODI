# -*- coding: utf-8 -*-
from G6AHskJeqN import *
headers = { 'User-Agent' : '' }
baNWS6nfqTC5iX4Kl = 'AKOAM'
teUPLFC3B8bArakwHVGsdhoIWDM49f = '_AKO_'
EZxQp1WOldMTvFU = AK5RqLhji4W1wt9VdrCD3PGeQM[baNWS6nfqTC5iX4Kl][0]
m2JRnEFaPW9 = ['فيلم','كليب','العرض الاسبوعي','مسرحية','مسرحيه','اغنية','اعلان','لقاء']
def VbgEajY4Bt2COpGDcPqI(mode,url,text):
	if   mode==70: ft3e2JBKQVXWlFPjaMhkEqGxvDg = eN02L7Tf5bQ()
	elif mode==71: ft3e2JBKQVXWlFPjaMhkEqGxvDg = WeRdrIQhcKkPU(url)
	elif mode==72: ft3e2JBKQVXWlFPjaMhkEqGxvDg = sscM839DP1jWZ4zl6uIx0Kyn(url,text)
	elif mode==73: ft3e2JBKQVXWlFPjaMhkEqGxvDg = aROcD9lSxqj7FtL3bvmrBAf6H(url)
	elif mode==74: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HDxCnPKFhITpZmOsA4a0UL6(url)
	elif mode==79: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HjZcUIVAXFCqy9TfBWKtgY2(text)
	else: ft3e2JBKQVXWlFPjaMhkEqGxvDg = False
	return ft3e2JBKQVXWlFPjaMhkEqGxvDg
def eN02L7Tf5bQ():
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'بحث في الموقع','',79,'','','_REMEMBERRESULTS_')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'سلسلة افلام','',79,'','','سلسلة افلام')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'سلاسل منوعة','',79,'','','سلسلة')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	eh2tDvRFWpLQI = ['الكتب و الابحاث','الكورسات التعليمية','الألعاب','البرامج','الاجهزة اللوحية','الصور و الخلفيات','المصارعة الحرة']
	MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(IIiPCruL6dT8s1lqj47SzpVHnYNm,EZxQp1WOldMTvFU,'',headers,'','AKOAM-MENU-1st')
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('class="partions"(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)">(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title in items:
			if title not in eh2tDvRFWpLQI:
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,71)
	return MK6ZT2zjC1SbmveNFqor
def WeRdrIQhcKkPU(url):
	MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(IIiPCruL6dT8s1lqj47SzpVHnYNm,url,'',headers,'','AKOAM-CATEGORIES-1st')
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('sect_parts(.*?)</div>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?>(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title in items:
			title = title.strip(' ')
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,72)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'جميع الفروع',url,72)
	else: sscM839DP1jWZ4zl6uIx0Kyn(url,'')
	return
def sscM839DP1jWZ4zl6uIx0Kyn(url,type):
	MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(UuEtImzir9,url,'',headers,True,'AKOAM-TITLES-1st')
	items = []
	if type=='featured':
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('section_title featured_title(.*?)subjects-crousel',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)"><div class="subject_box.*?src="(.*?)".*?<h3.*?>(.*?)</h3>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	elif type=='search':
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('akoam_result(.*?)<script',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?background-image: url\((.*?)\).*?<h1>(.*?)</h1>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	elif type=='more':
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('section_title more_title(.*?)footer_bottom_services',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	else:
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('navigation(.*?)<script',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if not items and XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('div class="subject_box.*?href="(.*?)".*?src="(.*?)".*?<h3.*?>(.*?)</h3>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	for BoEFz2WhUyvTgDeiZ,IcWzVO137wFvemn2QTq8yKs9,title in items:
		if 'توضيح هام' in title: continue
		title = title.replace('\n','').strip(' ')
		title = PIfAumbGicwg5ye(title)
		if any(WoFrX46wzbCNp18 in title for WoFrX46wzbCNp18 in m2JRnEFaPW9): VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,73,IcWzVO137wFvemn2QTq8yKs9)
		else: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,73,IcWzVO137wFvemn2QTq8yKs9)
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('class="pagination"(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall("</li><li >.*?href='(.*?)'>(.*?)<",vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title in items:
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'صفحة '+title,BoEFz2WhUyvTgDeiZ,72,'','',type)
	return
def KpEMLJNhecCY(url):
	MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(IIiPCruL6dT8s1lqj47SzpVHnYNm,url,'',headers,True,'AKOAM-SECTIONS-2nd')
	bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = My7Dwqvs6bfGNSIgX.findall('"href","(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = bJEs4IVAPdyUrhwCLv9k2YoOl8nt1[1]
	return bJEs4IVAPdyUrhwCLv9k2YoOl8nt1
def aROcD9lSxqj7FtL3bvmrBAf6H(url):
	MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(UuEtImzir9,url,'',headers,True,'AKOAM-SECTIONS-1st')
	FY9mi3Iwe1 = My7Dwqvs6bfGNSIgX.findall('"(https*://akwam.net/\w+.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	fas8b05ROHCYNe4BrxG = My7Dwqvs6bfGNSIgX.findall('"(https*://underurl.com/\w+.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if FY9mi3Iwe1 or fas8b05ROHCYNe4BrxG:
		if FY9mi3Iwe1: QAKdHzO0rehbtyIc = FY9mi3Iwe1[0]
		elif fas8b05ROHCYNe4BrxG: QAKdHzO0rehbtyIc = KpEMLJNhecCY(fas8b05ROHCYNe4BrxG[0])
		QAKdHzO0rehbtyIc = XnQbsZF0Ouh8p7zCdUN(QAKdHzO0rehbtyIc)
		import AHyTtY8FEJ
		if '/series/' in QAKdHzO0rehbtyIc or '/shows/' in QAKdHzO0rehbtyIc: AHyTtY8FEJ.o4oY13v5dWMcbilEDjKCnXNzHZ0(QAKdHzO0rehbtyIc)
		else: AHyTtY8FEJ.HDxCnPKFhITpZmOsA4a0UL6(QAKdHzO0rehbtyIc)
		return
	ME2Q6F7u8Vp1km9ws = My7Dwqvs6bfGNSIgX.findall('محتوى الفيلم.*?>.*?(\w*?)\W*?<',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if ME2Q6F7u8Vp1km9ws and a97xrkSOefH5DbjXunq(baNWS6nfqTC5iX4Kl,url,ME2Q6F7u8Vp1km9ws): return
	items = My7Dwqvs6bfGNSIgX.findall('<br />\n<a href="(.*?)".*?<span style="color:.*?">(.*?)</span>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	for BoEFz2WhUyvTgDeiZ,title in items:
		title = PIfAumbGicwg5ye(title)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,73)
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('class="sub_title".*?<h1.*?>(.*?)</h1>.*?class="main_img".*?src="(.*?)".*?ad-300-250(.*?)ako-feedback',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if not XBuP6Op7y4K:
		gj7BGM5t3RZpA0vNixLqzwualb16('خطأ خارجي','لا يوجد ملف فيديو')
		return
	name,IcWzVO137wFvemn2QTq8yKs9,vsptNMP2ZQC = XBuP6Op7y4K[0]
	name = name.strip(' ')
	if 'sub_epsiode_title' in vsptNMP2ZQC:
		items = My7Dwqvs6bfGNSIgX.findall('sub_epsiode_title">(.*?)</h2>.*?sub_file_title.*?>(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	else:
		wxvJue1Xr3FcUj = My7Dwqvs6bfGNSIgX.findall('sub_file_title\'>(.*?) - <i>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		items = []
		for filename in wxvJue1Xr3FcUj:
			items.append( ('رابط التشغيل',filename) )
	if not items: items = [ ('رابط التشغيل','') ]
	count = 0
	wlfZEzuRyYLvrp,RfiqVyj0BLnorgcUMm7Az48NHQ2 = [],[]
	size = len(items)
	for title,filename in items:
		WK75AGwvEzJZTNLQB1 = ''
		if ' - ' in filename: filename = filename.split(' - ')[0]
		else: filename = 'dummy.zip'
		if '.' in filename: WK75AGwvEzJZTNLQB1 = filename.split('.')[-1]
		title = title.replace('\n','').strip(' ')
		wlfZEzuRyYLvrp.append(title)
		RfiqVyj0BLnorgcUMm7Az48NHQ2.append(count)
		count += 1
	if size>0:
		if any(WoFrX46wzbCNp18 in name for WoFrX46wzbCNp18 in m2JRnEFaPW9):
			if size==1:
				GOtNfU3xQFkEhPouwA = 0
			else:
				GOtNfU3xQFkEhPouwA = CnKwdteDG5BE8MTRhUpYIJm3NLrSgq('اختر الفيديو المناسب:', wlfZEzuRyYLvrp)
				if GOtNfU3xQFkEhPouwA == -1: return
			HDxCnPKFhITpZmOsA4a0UL6(url+'?section='+str(1+RfiqVyj0BLnorgcUMm7Az48NHQ2[size-GOtNfU3xQFkEhPouwA-1]))
		else:
			for FVW0I9sYcAjmDgn8r in reversed(range(size)):
				title = name + ' - ' + wlfZEzuRyYLvrp[FVW0I9sYcAjmDgn8r]
				title = title.replace('\n','').strip(' ')
				BoEFz2WhUyvTgDeiZ = url + '?section='+str(size-FVW0I9sYcAjmDgn8r)
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,74,IcWzVO137wFvemn2QTq8yKs9)
	else:
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+'الرابط ليس فيديو','',9999,IcWzVO137wFvemn2QTq8yKs9)
	return
def HDxCnPKFhITpZmOsA4a0UL6(url):
	bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,ffhN7jAqe3Q4cR0Ukptzl = url.split('?section=')
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,'',headers,True,'','AKOAM-PLAY_AKOAM-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('ad-300-250.*?ad-300-250(.*?)ako-feedback',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	mTiBYzE2IZ9Q3NehoCSqW6U5D = XBuP6Op7y4K[0].replace("'direct_link_box",'"direct_link_box epsoide_box')
	mTiBYzE2IZ9Q3NehoCSqW6U5D = mTiBYzE2IZ9Q3NehoCSqW6U5D + 'direct_link_box'
	xAcIatGBYy0FLXroS1ig3Ts9KZ8P5 = My7Dwqvs6bfGNSIgX.findall('epsoide_box(.*?)direct_link_box',mTiBYzE2IZ9Q3NehoCSqW6U5D,My7Dwqvs6bfGNSIgX.DOTALL)
	ffhN7jAqe3Q4cR0Ukptzl = len(xAcIatGBYy0FLXroS1ig3Ts9KZ8P5)-int(ffhN7jAqe3Q4cR0Ukptzl)
	vsptNMP2ZQC = xAcIatGBYy0FLXroS1ig3Ts9KZ8P5[ffhN7jAqe3Q4cR0Ukptzl]
	Qki8AbTHYjzM2Ls76Gdr3eqo1Wn = []
	i24gN6OshvFkr = {'1423075862':'dailymotion','1477487601':'estream','1505328404':'streamango',
		'1423080015':'flashx','1458117295':'openload','1423079306':'vimple','1430052371':'ok.ru',
		'1477488213':'thevid','1558278006':'uqload','1477487990':'vidtodo'}
	items = My7Dwqvs6bfGNSIgX.findall("class='download_btn.*?href='(.*?)'",vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	for BoEFz2WhUyvTgDeiZ in items:
		Qki8AbTHYjzM2Ls76Gdr3eqo1Wn.append(BoEFz2WhUyvTgDeiZ+'?named=________akoam')
	items = My7Dwqvs6bfGNSIgX.findall('background-image: url\((.*?)\).*?href=\'(.*?)\'',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	for KQfjmY8knpWBSADXyH6blsZVEgt9,BoEFz2WhUyvTgDeiZ in items:
		KQfjmY8knpWBSADXyH6blsZVEgt9 = KQfjmY8knpWBSADXyH6blsZVEgt9.split('/')[-1]
		KQfjmY8knpWBSADXyH6blsZVEgt9 = KQfjmY8knpWBSADXyH6blsZVEgt9.split('.')[0]
		if KQfjmY8knpWBSADXyH6blsZVEgt9 in i24gN6OshvFkr:
			Qki8AbTHYjzM2Ls76Gdr3eqo1Wn.append(BoEFz2WhUyvTgDeiZ+'?named='+i24gN6OshvFkr[KQfjmY8knpWBSADXyH6blsZVEgt9]+'________akoam')
		else: Qki8AbTHYjzM2Ls76Gdr3eqo1Wn.append(BoEFz2WhUyvTgDeiZ+'?named='+KQfjmY8knpWBSADXyH6blsZVEgt9+'________akoam')
	if not Qki8AbTHYjzM2Ls76Gdr3eqo1Wn:
		message = My7Dwqvs6bfGNSIgX.findall('sub-no-file.*?\n(.*?)\n',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		if message: ZIOHgA3z0TBR('','','رسالة من الموقع الاصلي',message[0])
	else:
		import t1kDWXQVpC
		t1kDWXQVpC.rqVt2xDi7jzJHBcPMRs6h0L(Qki8AbTHYjzM2Ls76Gdr3eqo1Wn,baNWS6nfqTC5iX4Kl,'video',url)
	return
def HjZcUIVAXFCqy9TfBWKtgY2(search):
	search,LQf3AeozSrai,showDialogs = X54MLovbG8nAEkB9J(search)
	if search=='': search = ViKAIsLurq83RSENayxWb()
	if search=='': return
	ystIEd371fLkT50pcRUWi9olNDu = search.replace(' ','%20')
	url = EZxQp1WOldMTvFU + '/search/'+ystIEd371fLkT50pcRUWi9olNDu
	ft3e2JBKQVXWlFPjaMhkEqGxvDg = sscM839DP1jWZ4zl6uIx0Kyn(url,'search')
	return
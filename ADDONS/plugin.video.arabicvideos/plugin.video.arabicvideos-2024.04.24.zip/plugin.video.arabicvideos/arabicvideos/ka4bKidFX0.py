# -*- coding: utf-8 -*-
from G6AHskJeqN import *
baNWS6nfqTC5iX4Kl = 'ARABICTOONS'
teUPLFC3B8bArakwHVGsdhoIWDM49f = '_ART_'
EZxQp1WOldMTvFU = AK5RqLhji4W1wt9VdrCD3PGeQM[baNWS6nfqTC5iX4Kl][0]
def VbgEajY4Bt2COpGDcPqI(mode,url,text):
	if   mode==730: ft3e2JBKQVXWlFPjaMhkEqGxvDg = eN02L7Tf5bQ()
	elif mode==731: ft3e2JBKQVXWlFPjaMhkEqGxvDg = sscM839DP1jWZ4zl6uIx0Kyn(url)
	elif mode==732: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HDxCnPKFhITpZmOsA4a0UL6(url)
	elif mode==733: ft3e2JBKQVXWlFPjaMhkEqGxvDg = o4oY13v5dWMcbilEDjKCnXNzHZ0(url)
	elif mode==734: ft3e2JBKQVXWlFPjaMhkEqGxvDg = tHuh9djYScDRU2Wb(url)
	elif mode==735: ft3e2JBKQVXWlFPjaMhkEqGxvDg = lbKGcAv1o5ei6E(url)
	elif mode==739: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HjZcUIVAXFCqy9TfBWKtgY2(text)
	else: ft3e2JBKQVXWlFPjaMhkEqGxvDg = False
	return ft3e2JBKQVXWlFPjaMhkEqGxvDg
def eN02L7Tf5bQ():
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'بحث في الموقع','',739,'','','_REMEMBERRESULTS_')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'مسلسلات مميزة',EZxQp1WOldMTvFU+'/top.php',735)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'مسلسلات',EZxQp1WOldMTvFU+'/cartoon.php',734)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'افلام',EZxQp1WOldMTvFU+'/movies.php',731)
	return
def tHuh9djYScDRU2Wb(url):
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'الكل',url,731)
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'','','','','ARABICTOONS-SERIES_SUBMENU-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('label="navigation"(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall("href='(.*?)'>(.*?)</a>",vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title in items:
			BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU+'/'+BoEFz2WhUyvTgDeiZ
			title = 'حرف '+title
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,731)
	return
def lbKGcAv1o5ei6E(url):
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'','','','','ARABICTOONS-SERIES_FEATURED-2nd')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('class="slider"(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('title="(.*?)" href="(.*?)".*?src="(.*?)"',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for title,BoEFz2WhUyvTgDeiZ,IcWzVO137wFvemn2QTq8yKs9 in items:
			BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU+'/'+BoEFz2WhUyvTgDeiZ
			IcWzVO137wFvemn2QTq8yKs9 = EZxQp1WOldMTvFU+'/'+IcWzVO137wFvemn2QTq8yKs9
			title = title.strip(' ')
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,733,IcWzVO137wFvemn2QTq8yKs9)
	return
def sscM839DP1jWZ4zl6uIx0Kyn(url):
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'','','','','ARABICTOONS-TITLES-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall("class='moviesBlocks(.*?)navigation",MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	vsptNMP2ZQC = XBuP6Op7y4K[0]
	items = My7Dwqvs6bfGNSIgX.findall('class="movie".*?href="(.*?)".*?src="(.*?)".*?<b>(.*?)</b>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	for BoEFz2WhUyvTgDeiZ,IcWzVO137wFvemn2QTq8yKs9,title in items:
		BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU+'/'+BoEFz2WhUyvTgDeiZ
		IcWzVO137wFvemn2QTq8yKs9 = EZxQp1WOldMTvFU+'/'+IcWzVO137wFvemn2QTq8yKs9
		title = title.strip(' ')
		if 'movies.php' in url: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,732,IcWzVO137wFvemn2QTq8yKs9)
		else: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,733,IcWzVO137wFvemn2QTq8yKs9)
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"pagination(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[-1]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?>(.*?)</a>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title in items:
			BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU+'/'+BoEFz2WhUyvTgDeiZ
			title = title.strip(' ')
			title = PIfAumbGicwg5ye(title)
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'صفحة '+title,BoEFz2WhUyvTgDeiZ,731)
	return
def o4oY13v5dWMcbilEDjKCnXNzHZ0(url):
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'','','','','ARABICTOONS-EPISODES-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall("class='moviesBlocks(.*?)script",MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('class="movie".*?title="(.*?)".*?href="(.*?)".*?src="(.*?)".*?<b>(.*?)</b>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for title,BoEFz2WhUyvTgDeiZ,IcWzVO137wFvemn2QTq8yKs9,IsYRnpThJG1i in items:
			BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU+'/'+BoEFz2WhUyvTgDeiZ
			IcWzVO137wFvemn2QTq8yKs9 = EZxQp1WOldMTvFU+'/'+IcWzVO137wFvemn2QTq8yKs9
			title = title.strip(' ')
			title = title+' '+IsYRnpThJG1i.strip(' ')
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,732,IcWzVO137wFvemn2QTq8yKs9)
	return
def HDxCnPKFhITpZmOsA4a0UL6(url):
	Qki8AbTHYjzM2Ls76Gdr3eqo1Wn = []
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'','','','','ARABICTOONS-PLAY-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	NVHrZsqUp2 = My7Dwqvs6bfGNSIgX.findall('source src="(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if NVHrZsqUp2:
		BoEFz2WhUyvTgDeiZ = NVHrZsqUp2[0]
		if 'Referer=' not in BoEFz2WhUyvTgDeiZ: BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ+'|Referer=https://www.arabic-toons.com'
		Qki8AbTHYjzM2Ls76Gdr3eqo1Wn.append(BoEFz2WhUyvTgDeiZ+'?named=__embed')
	import t1kDWXQVpC
	t1kDWXQVpC.rqVt2xDi7jzJHBcPMRs6h0L(Qki8AbTHYjzM2Ls76Gdr3eqo1Wn,baNWS6nfqTC5iX4Kl,'video',url)
	return
def HjZcUIVAXFCqy9TfBWKtgY2(search):
	search,LQf3AeozSrai,showDialogs = X54MLovbG8nAEkB9J(search)
	if search=='': search = ViKAIsLurq83RSENayxWb()
	if search=='': return
	search = search.replace(' ','%20')
	QQ2cE1FjUyxPonbDhaTkV6B3i = ['','m']
	YNuW90vpw8rBSTU = ['مسلسلات','افلام']
	if showDialogs:
		GOtNfU3xQFkEhPouwA = CnKwdteDG5BE8MTRhUpYIJm3NLrSgq('اختر النوع المطلوب:', YNuW90vpw8rBSTU)
		if GOtNfU3xQFkEhPouwA==-1: return
	else: GOtNfU3xQFkEhPouwA = 0
	type = QQ2cE1FjUyxPonbDhaTkV6B3i[GOtNfU3xQFkEhPouwA]
	url = EZxQp1WOldMTvFU+'/livesearch.php?'+type+'&q='+search
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'','','','','ARABICTOONS-SEARCH-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)">(.*?)<',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	for BoEFz2WhUyvTgDeiZ,title in items:
		BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU+'/'+BoEFz2WhUyvTgDeiZ
		title = title.strip(' ')
		if type=='m': VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,732)
		else: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,733)
	return
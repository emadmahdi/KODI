# -*- coding: utf-8 -*-
from G6AHskJeqN import *
baNWS6nfqTC5iX4Kl = 'ALARAB'
headers = {'User-Agent':''}
teUPLFC3B8bArakwHVGsdhoIWDM49f = '_KLA_'
EZxQp1WOldMTvFU = AK5RqLhji4W1wt9VdrCD3PGeQM[baNWS6nfqTC5iX4Kl][0]
def VbgEajY4Bt2COpGDcPqI(mode,url,text):
	if   mode==10: ft3e2JBKQVXWlFPjaMhkEqGxvDg = eN02L7Tf5bQ()
	elif mode==11: ft3e2JBKQVXWlFPjaMhkEqGxvDg = sscM839DP1jWZ4zl6uIx0Kyn(url)
	elif mode==12: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HDxCnPKFhITpZmOsA4a0UL6(url)
	elif mode==13: ft3e2JBKQVXWlFPjaMhkEqGxvDg = o4oY13v5dWMcbilEDjKCnXNzHZ0(url)
	elif mode==14: ft3e2JBKQVXWlFPjaMhkEqGxvDg = jteCU2z0EY4J6dFA()
	elif mode==15: ft3e2JBKQVXWlFPjaMhkEqGxvDg = mgcB2YbhyjzJ8GIlAuxX()
	elif mode==16: ft3e2JBKQVXWlFPjaMhkEqGxvDg = mosdODYVzftbkKHBS9rv0y()
	elif mode==19: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HjZcUIVAXFCqy9TfBWKtgY2(text)
	else: ft3e2JBKQVXWlFPjaMhkEqGxvDg = False
	return ft3e2JBKQVXWlFPjaMhkEqGxvDg
def eN02L7Tf5bQ():
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'بحث في الموقع','',19,'','','_REMEMBERRESULTS_')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'آخر الإضافات','',14)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'مسلسلات رمضان','',15)
	MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(IIiPCruL6dT8s1lqj47SzpVHnYNm,EZxQp1WOldMTvFU,'',headers,'','ALARAB-MENU-1st')
	XBuP6Op7y4K=My7Dwqvs6bfGNSIgX.findall('id="nav-slider"(.*?)</div>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	gZXK6R7wjFOxCBsYJpb350rGStLa = XBuP6Op7y4K[0]
	items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?>(.*?)<',gZXK6R7wjFOxCBsYJpb350rGStLa,My7Dwqvs6bfGNSIgX.DOTALL)
	for BoEFz2WhUyvTgDeiZ,title in items:
		BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU+BoEFz2WhUyvTgDeiZ
		title = title.strip(' ')
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,11)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('id="navbar"(.*?)</div>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	iiBEzXVNFDhfj36 = XBuP6Op7y4K[0]
	items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?>(.*?)<',iiBEzXVNFDhfj36,My7Dwqvs6bfGNSIgX.DOTALL)
	for BoEFz2WhUyvTgDeiZ,title in items:
		BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU+BoEFz2WhUyvTgDeiZ
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,11)
	return MK6ZT2zjC1SbmveNFqor
def mgcB2YbhyjzJ8GIlAuxX():
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'جميع المسلسلات العربية',EZxQp1WOldMTvFU+'/view-8/مسلسلات-عربية',11)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'مسلسلات السنة الأخيرة','',16)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'مسلسلات رمضان الأخيرة 1',EZxQp1WOldMTvFU+'/view-8/مسلسلات-رمضان-2022',11)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'مسلسلات رمضان الأخيرة 2',EZxQp1WOldMTvFU+'/view-8/مسلسلات-رمضان-2023',11)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'مسلسلات رمضان 2023',EZxQp1WOldMTvFU+'/ramadan2023/مصرية',11)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'مسلسلات رمضان 2022',EZxQp1WOldMTvFU+'/ramadan2022/مصرية',11)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'مسلسلات رمضان 2021',EZxQp1WOldMTvFU+'/ramadan2021/مصرية',11)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'مسلسلات رمضان 2020',EZxQp1WOldMTvFU+'/ramadan2020/مصرية',11)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'مسلسلات رمضان 2019',EZxQp1WOldMTvFU+'/ramadan2019/مصرية',11)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'مسلسلات رمضان 2018',EZxQp1WOldMTvFU+'/ramadan2018/مصرية',11)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'مسلسلات رمضان 2017',EZxQp1WOldMTvFU+'/ramadan2017/مصرية',11)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'مسلسلات رمضان 2016',EZxQp1WOldMTvFU+'/ramadan2016/مصرية',11)
	return
def jteCU2z0EY4J6dFA():
	MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(UuEtImzir9,EZxQp1WOldMTvFU,'',headers,True,'ALARAB-LATEST-1st')
	XBuP6Op7y4K=My7Dwqvs6bfGNSIgX.findall('heading-top(.*?)div class=',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	vsptNMP2ZQC = XBuP6Op7y4K[0]+XBuP6Op7y4K[1]
	items=My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?data-src="(.*?)" alt="(.*?)"',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	for BoEFz2WhUyvTgDeiZ,IcWzVO137wFvemn2QTq8yKs9,title in items:
		url = EZxQp1WOldMTvFU + BoEFz2WhUyvTgDeiZ
		if 'series' in url: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,url,11,IcWzVO137wFvemn2QTq8yKs9)
		else: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,url,12,IcWzVO137wFvemn2QTq8yKs9)
	return
def sscM839DP1jWZ4zl6uIx0Kyn(url):
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'',headers,True,True,'ALARAB-TITLES-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('video-category(.*?)right_content',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if not XBuP6Op7y4K: return
	vsptNMP2ZQC = XBuP6Op7y4K[0]
	RnK9tpPmxGhlS0yVAJ71fjsTEIZ = False
	items = My7Dwqvs6bfGNSIgX.findall('video-box.*?href="(.*?)".*?src="(http.*?)" alt="(.*?)"',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	y7y3d5Fbhv42ONmtwLZ0SerYoQq,NbVDfM1PIpcZ = [],[]
	for BoEFz2WhUyvTgDeiZ,IcWzVO137wFvemn2QTq8yKs9,title in items:
		if title=='': title = BoEFz2WhUyvTgDeiZ.split('/')[-1].replace('-',' ')
		aaBsTFzpoyDlh3EiMZWnYPqc7w = My7Dwqvs6bfGNSIgX.findall('(\d+)',title,My7Dwqvs6bfGNSIgX.DOTALL)
		if aaBsTFzpoyDlh3EiMZWnYPqc7w: aaBsTFzpoyDlh3EiMZWnYPqc7w = int(aaBsTFzpoyDlh3EiMZWnYPqc7w[0])
		else: aaBsTFzpoyDlh3EiMZWnYPqc7w = 0
		NbVDfM1PIpcZ.append([IcWzVO137wFvemn2QTq8yKs9,BoEFz2WhUyvTgDeiZ,title,aaBsTFzpoyDlh3EiMZWnYPqc7w])
	NbVDfM1PIpcZ = sorted(NbVDfM1PIpcZ, reverse=True, key=lambda key: key[3])
	for IcWzVO137wFvemn2QTq8yKs9,BoEFz2WhUyvTgDeiZ,title,aaBsTFzpoyDlh3EiMZWnYPqc7w in NbVDfM1PIpcZ:
		BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU + BoEFz2WhUyvTgDeiZ
		title = title.replace('مشاهدة مسلسل','مسلسل')
		title = title.replace('مشاهدة المسلسل','المسلسل')
		title = title.replace('مشاهدة فيلم','فيلم')
		title = title.replace('مشاهدة الفيلم','الفيلم')
		title = title.replace('مباشرة كواليتي','')
		title = title.replace('عالية على العرب','')
		title = title.replace('مشاهدة مباشرة','')
		title = title.replace('اون لاين','')
		title = title.replace('اونلاين','')
		title = title.replace('بجودة عالية','')
		title = title.replace('جودة عالية','')
		title = title.replace('بدون تحميل','')
		title = title.replace('على العرب','')
		title = title.replace('مباشرة','')
		title = title.strip(' ').replace('  ',' ').replace('  ',' ')
		title = '_MOD_'+title
		U2UaTcgBpsEZxKiRG1Xv8 = title
		if '/q/' in url and ('الحلقة' in title or 'الحلقه' in title):
			ffhN7jAqe3Q4cR0Ukptzl = My7Dwqvs6bfGNSIgX.findall('(.*?) الحلقة \d+',title,My7Dwqvs6bfGNSIgX.DOTALL)
			if ffhN7jAqe3Q4cR0Ukptzl: U2UaTcgBpsEZxKiRG1Xv8 = ffhN7jAqe3Q4cR0Ukptzl[0]
		if U2UaTcgBpsEZxKiRG1Xv8 not in y7y3d5Fbhv42ONmtwLZ0SerYoQq:
			y7y3d5Fbhv42ONmtwLZ0SerYoQq.append(U2UaTcgBpsEZxKiRG1Xv8)
			if '/q/' in url and ('الحلقة' in title or 'الحلقه' in title):
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+U2UaTcgBpsEZxKiRG1Xv8,BoEFz2WhUyvTgDeiZ,13,IcWzVO137wFvemn2QTq8yKs9)
				RnK9tpPmxGhlS0yVAJ71fjsTEIZ = True
			elif 'series' in BoEFz2WhUyvTgDeiZ:
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,11,IcWzVO137wFvemn2QTq8yKs9)
				RnK9tpPmxGhlS0yVAJ71fjsTEIZ = True
			else:
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,12,IcWzVO137wFvemn2QTq8yKs9)
				RnK9tpPmxGhlS0yVAJ71fjsTEIZ = True
	if RnK9tpPmxGhlS0yVAJ71fjsTEIZ:
		items = My7Dwqvs6bfGNSIgX.findall('tsc_3d_button red.*?href="(.*?)" title="(.*?)"',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,z3z9QgENFk5eMYB4 in items:
			url = EZxQp1WOldMTvFU + BoEFz2WhUyvTgDeiZ
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+z3z9QgENFk5eMYB4,url,11)
	return
def o4oY13v5dWMcbilEDjKCnXNzHZ0(url):
	MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(UuEtImzir9,url,'',headers,True,'ALARAB-EPISODES-1st')
	FCljOwM3Sg6Bt4Vo = My7Dwqvs6bfGNSIgX.findall('href="(/series.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = EZxQp1WOldMTvFU+FCljOwM3Sg6Bt4Vo[0]
	ft3e2JBKQVXWlFPjaMhkEqGxvDg = sscM839DP1jWZ4zl6uIx0Kyn(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1)
	return
def HDxCnPKFhITpZmOsA4a0UL6(url):
	QQ2cE1FjUyxPonbDhaTkV6B3i = []
	MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(f9Oum6c0FotxYn,url,'',headers,True,'ALARAB-PLAY-1st')
	bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = My7Dwqvs6bfGNSIgX.findall('class="resp-iframe" src="(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if bJEs4IVAPdyUrhwCLv9k2YoOl8nt1:
		bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = bJEs4IVAPdyUrhwCLv9k2YoOl8nt1[0]
		NVHrZsqUp2 = My7Dwqvs6bfGNSIgX.findall('^(http.*?)(http.*?)$',bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,My7Dwqvs6bfGNSIgX.DOTALL)
		if NVHrZsqUp2:
			lErmvOQ4B6 = NVHrZsqUp2[0][0]
			UuWn0bC4xehpg2kFqD96BjIfQrPl,lRTI3Dq2huP70n = NVHrZsqUp2[0][1].rsplit('/',1)
			QAKdHzO0rehbtyIc = UuWn0bC4xehpg2kFqD96BjIfQrPl+'?named=__watch'
			QQ2cE1FjUyxPonbDhaTkV6B3i.append(QAKdHzO0rehbtyIc)
			UnFC90p8KGPSwHJrV = lErmvOQ4B6+lRTI3Dq2huP70n
		else:
			wN6n7OZBoDkTvCi8LdbJjYV = YY0KEWamSIc46n3kbtuLgZV(IIiPCruL6dT8s1lqj47SzpVHnYNm,bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,'',headers,False,'ALARAB-PLAY-2nd')
			bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = My7Dwqvs6bfGNSIgX.findall('"src": "(.*?)"',wN6n7OZBoDkTvCi8LdbJjYV,My7Dwqvs6bfGNSIgX.DOTALL)
			if bJEs4IVAPdyUrhwCLv9k2YoOl8nt1:
				bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = bJEs4IVAPdyUrhwCLv9k2YoOl8nt1[0]+'?named=__watch__m3u8'
				QQ2cE1FjUyxPonbDhaTkV6B3i.append(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1)
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('searchBox(.*?)<style>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = My7Dwqvs6bfGNSIgX.findall('href="(.*?)"',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		if bJEs4IVAPdyUrhwCLv9k2YoOl8nt1:
			bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = bJEs4IVAPdyUrhwCLv9k2YoOl8nt1[0]+'?named=__watch'
			QQ2cE1FjUyxPonbDhaTkV6B3i.append(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1)
	import t1kDWXQVpC
	t1kDWXQVpC.rqVt2xDi7jzJHBcPMRs6h0L(QQ2cE1FjUyxPonbDhaTkV6B3i,baNWS6nfqTC5iX4Kl,'video',url)
	return
def mosdODYVzftbkKHBS9rv0y():
	MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(IIiPCruL6dT8s1lqj47SzpVHnYNm,EZxQp1WOldMTvFU,'',headers,True,'ALARAB-RAMADAN-1st')
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('id="content_sec"(.*?)id="left_content"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	vsptNMP2ZQC = XBuP6Op7y4K[0]
	items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?>(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	GKSzHX8kBd = My7Dwqvs6bfGNSIgX.findall('/ramadan([0-9]+)/',str(items),My7Dwqvs6bfGNSIgX.DOTALL)
	GKSzHX8kBd = GKSzHX8kBd[0]
	for BoEFz2WhUyvTgDeiZ,title in items:
		url = EZxQp1WOldMTvFU+BoEFz2WhUyvTgDeiZ
		title = title.strip(' ')+' '+GKSzHX8kBd
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,url,11)
	return
def HjZcUIVAXFCqy9TfBWKtgY2(search):
	search,LQf3AeozSrai,showDialogs = X54MLovbG8nAEkB9J(search)
	if search=='': search = ViKAIsLurq83RSENayxWb()
	if search=='': return
	ystIEd371fLkT50pcRUWi9olNDu = search.replace(' ','+')
	url = EZxQp1WOldMTvFU + "/q/" + ystIEd371fLkT50pcRUWi9olNDu
	ft3e2JBKQVXWlFPjaMhkEqGxvDg = sscM839DP1jWZ4zl6uIx0Kyn(url)
	return
# -*- coding: utf-8 -*-
import sys as ehpURIi6QBDOGu8qj5EYzXrsWHJ7
hEJlvpt9LRO = ehpURIi6QBDOGu8qj5EYzXrsWHJ7.version_info [0] == 2
RrwvuxJ2OXsWnE9fzYNPDqS = 2048
pS1kDZ93ogBi50Hm7elLhEcyFfTx = 7
def E6Xo0wuA9fdQKlGOI (Ovquk0bMSPEL1ciQ73BJ2Ae):
	global Xb8HYvTBqV5RFAhE3KwMjC
	G4LMt9nR3Se6xWNpPuJd = ord (Ovquk0bMSPEL1ciQ73BJ2Ae [-1])
	qkDvfXryhi7cSz5Ee4AtVn0 = Ovquk0bMSPEL1ciQ73BJ2Ae [:-1]
	FEcyWfSHeL5Kotpx = G4LMt9nR3Se6xWNpPuJd % len (qkDvfXryhi7cSz5Ee4AtVn0)
	FPhirCoHEGw3I05B = qkDvfXryhi7cSz5Ee4AtVn0 [:FEcyWfSHeL5Kotpx] + qkDvfXryhi7cSz5Ee4AtVn0 [FEcyWfSHeL5Kotpx:]
	if hEJlvpt9LRO:
		ffWep5hGgyVTXHL1SM = unicode () .join ([unichr (ord (DDX7Qar0kqlIAKHdwnEh) - RrwvuxJ2OXsWnE9fzYNPDqS - (XapSRJwDcy5TEK0QHZr6n + G4LMt9nR3Se6xWNpPuJd) % pS1kDZ93ogBi50Hm7elLhEcyFfTx) for XapSRJwDcy5TEK0QHZr6n, DDX7Qar0kqlIAKHdwnEh in enumerate (FPhirCoHEGw3I05B)])
	else:
		ffWep5hGgyVTXHL1SM = str () .join ([chr (ord (DDX7Qar0kqlIAKHdwnEh) - RrwvuxJ2OXsWnE9fzYNPDqS - (XapSRJwDcy5TEK0QHZr6n + G4LMt9nR3Se6xWNpPuJd) % pS1kDZ93ogBi50Hm7elLhEcyFfTx) for XapSRJwDcy5TEK0QHZr6n, DDX7Qar0kqlIAKHdwnEh in enumerate (FPhirCoHEGw3I05B)])
	return eval (ffWep5hGgyVTXHL1SM)
fY5wTlhtnOc0Er6sdy4k87b,C2jP0iLNGKnHu9xp,UnWjVbo503mEMv9KF=E6Xo0wuA9fdQKlGOI,E6Xo0wuA9fdQKlGOI,E6Xo0wuA9fdQKlGOI
jx7s8T0BFgODXLMzIYedf,UxS67uoGThbMwnfNRzy4gajLd23JH,QynMHGWA0blfqTUdxRh5Jzi2t=UnWjVbo503mEMv9KF,C2jP0iLNGKnHu9xp,fY5wTlhtnOc0Er6sdy4k87b
jSu5Cg2Ub1OAkZVs8Yoz,V2RbfGOBdcA6l8NTsPWzEyvS7,LgpdP3UjFRnlX=QynMHGWA0blfqTUdxRh5Jzi2t,UxS67uoGThbMwnfNRzy4gajLd23JH,jx7s8T0BFgODXLMzIYedf
gItVahxL0w,BmcLzCFjuIrZP5fwXH18aN6YS,qbPw1d3KimF=LgpdP3UjFRnlX,V2RbfGOBdcA6l8NTsPWzEyvS7,jSu5Cg2Ub1OAkZVs8Yoz
EAc8h2sINroQYvR3WH06Ji7MVpn,vvHpKfcqRnrFzjG,l0WAe1f7Bpi5ZXk=qbPw1d3KimF,BmcLzCFjuIrZP5fwXH18aN6YS,gItVahxL0w
YB5xyI7MaRslVpv,PPNA7jWqZgDnXKVvtuai1kQdsEoMb0,BK9OvRSjZbtx7kYyop1u6zrE2QeiFI=l0WAe1f7Bpi5ZXk,vvHpKfcqRnrFzjG,EAc8h2sINroQYvR3WH06Ji7MVpn
sRth5giAQzWlEVm7JOX,WMkAjB1RgN7q,NVS30xAdRFMIw1n9CislkE2=BK9OvRSjZbtx7kYyop1u6zrE2QeiFI,PPNA7jWqZgDnXKVvtuai1kQdsEoMb0,YB5xyI7MaRslVpv
NB6ZDMqe91yfKQ240WpbIntjxiY5z,k5dztomYyN3H,T6wRistc1SCo4hqObgumK=NVS30xAdRFMIw1n9CislkE2,WMkAjB1RgN7q,sRth5giAQzWlEVm7JOX
RqldvxFuM5GEQ2HAz93o7afBb0,rbjsM8cRFiuA1,nr5mZG89ICi6cgt4MfLJa0=T6wRistc1SCo4hqObgumK,k5dztomYyN3H,NB6ZDMqe91yfKQ240WpbIntjxiY5z
hhlbF1Sns5TrEN8QPCYmL4,FGDJwkEbTB5SoXujs3f,BoWHNb9daQVCF16A=nr5mZG89ICi6cgt4MfLJa0,rbjsM8cRFiuA1,RqldvxFuM5GEQ2HAz93o7afBb0
v5EA6TqHX3s4jzBMk,C2dgEDAKQGsvh,b05yftsZ6NYgIKP=BoWHNb9daQVCF16A,FGDJwkEbTB5SoXujs3f,hhlbF1Sns5TrEN8QPCYmL4
from g9pDL1tYQU import *
baNWS6nfqTC5iX4Kl = C2jP0iLNGKnHu9xp(u"ࠧࡊࡐࡌࡘࠬᚤ")
Lmj1pfQk63XdoeH(gItVahxL0w(u"ࠨࡐࡒࡘࡎࡉࡅࠨᚥ"),BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠩࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠩᚦ"))
q0HETPprhGgacmbJ4jD = cIa9Spry0oqE(SzGukeylg5Nsr9M20WIan)
EAdbsmyiqLtjhPlxG,gg37KuOokaYFs8qTiezZn1tJ4jLr6,qmr7vLh1EW,hT9FozLnDCgvPG0EXyJa7,QFrVYJkywEsXquMNz,z3z9QgENFk5eMYB4,QHDcUO2xtS4CmF,ezSE9fBuvT,yPoqtK3i7zHulhZJDWYsnLxvT0 = q0HETPprhGgacmbJ4jD
ndl0BskyaFqDxH9eJOZY7TgvVbXAt = int(hT9FozLnDCgvPG0EXyJa7)
GDL3q5vFjwIVrM2ElRZNd = tUXmK5PeEH9SDq.getInfoLabel(nr5mZG89ICi6cgt4MfLJa0(u"ࠪࡐ࡮ࡹࡴࡊࡶࡨࡱ࠳ࡒࡡࡣࡧ࡯ࠫᚧ"))
GDL3q5vFjwIVrM2ElRZNd = GDL3q5vFjwIVrM2ElRZNd.replace(u8c5pQm3iRwvxESj7PUrO,gItVahxL0w(u"ࠫࠬᚨ")).replace(rcek0gbPZ6lmJwSaTNso,rbjsM8cRFiuA1(u"ࠬ࠭ᚩ"))
if ndl0BskyaFqDxH9eJOZY7TgvVbXAt==YB5xyI7MaRslVpv(u"࠵࠺࠵ᛑ"): mKBurDQaSIn1Aydsc9LvbF5EZf = b05yftsZ6NYgIKP(u"࡙࠭ࠠࠡࠢࡩࡷࡹࡩࡰࡰ࠽ࠤࡠࠦࠧᚪ")+RhVj0vAt5kPHm+C2dgEDAKQGsvh(u"ࠧࠡ࡟ࠣࠤࠥࡑ࡯ࡥ࡫࠽ࠤࡠࠦࠧᚫ")+UUpr8jLiyQJ5l3VTow7hfu+BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠨࠢࡠࠫᚬ")
else:
	DXH4p0GhMeb7ocazQFt = XnQbsZF0Ouh8p7zCdUN(SzGukeylg5Nsr9M20WIan).replace(gItVahxL0w(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬᚭ"),UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠪࠫᚮ")).replace(YB5xyI7MaRslVpv(u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧᚯ"),v5EA6TqHX3s4jzBMk(u"ࠬ࠭ᚰ"))
	DXH4p0GhMeb7ocazQFt = DXH4p0GhMeb7ocazQFt.replace(LgpdP3UjFRnlX(u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨᚱ"),NVS30xAdRFMIw1n9CislkE2(u"ࠧࠨᚲ")).strip(hhlbF1Sns5TrEN8QPCYmL4(u"ࠨࠢࠪᚳ"))
	DXH4p0GhMeb7ocazQFt = DXH4p0GhMeb7ocazQFt.replace(C2jP0iLNGKnHu9xp(u"ࠩࠣࠤࠥࠦࠧᚴ"),BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠪࠤࠬᚵ")).replace(vvHpKfcqRnrFzjG(u"ࠫࠥࠦࠠࠨᚶ"),jSu5Cg2Ub1OAkZVs8Yoz(u"ࠬࠦࠧᚷ")).replace(b05yftsZ6NYgIKP(u"࠭ࠠࠡࠩᚸ"),k5dztomYyN3H(u"ࠧࠡࠩᚹ"))
	mKBurDQaSIn1Aydsc9LvbF5EZf = nr5mZG89ICi6cgt4MfLJa0(u"ࠨࠢࠣࠤࡑࡧࡢࡦ࡮࠽ࠤࡠࠦࠧᚺ")+GDL3q5vFjwIVrM2ElRZNd+PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠩࠣࡡࠥࠦࠠࡎࡱࡧࡩ࠿࡛ࠦࠡࠩᚻ")+hT9FozLnDCgvPG0EXyJa7+RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠪࠤࡢࠦࠠࠡࡒࡤࡸ࡭ࡀࠠ࡜ࠢࠪᚼ")+DXH4p0GhMeb7ocazQFt+NVS30xAdRFMIw1n9CislkE2(u"ࠫࠥࡣࠧᚽ")
Lmj1pfQk63XdoeH(nr5mZG89ICi6cgt4MfLJa0(u"ࠬࡔࡏࡕࡋࡆࡉࠬᚾ"),Dwl0N6FKuVU8nB1mbisIrCzdO(baNWS6nfqTC5iX4Kl)+mKBurDQaSIn1Aydsc9LvbF5EZf)
IYQKBPdHujwLMlVDE19 = bLEBi8IO7uU2x3htYDdVq95.getSetting(NVS30xAdRFMIw1n9CislkE2(u"࠭ࡡࡷ࠰ࡹࡩࡷࡹࡩࡰࡰࠪᚿ"))
BgNpRKyQaUWS0dtqVMlwHLo = nr5mZG89ICi6cgt4MfLJa0(u"ࡈࡤࡰࡸ࡫ᛗ") if IYQKBPdHujwLMlVDE19==RhVj0vAt5kPHm else hhlbF1Sns5TrEN8QPCYmL4(u"ࡕࡴࡸࡩᛖ")
if not BgNpRKyQaUWS0dtqVMlwHLo and ndl0BskyaFqDxH9eJOZY7TgvVbXAt in [b05yftsZ6NYgIKP(u"࠶࠸࠻ᛒ"),v5EA6TqHX3s4jzBMk(u"࠼࠷࠵ᛓ")]:
	S8UKq3VcpRgBMdT1hknl4voHfr = str(yPoqtK3i7zHulhZJDWYsnLxvT0[rbjsM8cRFiuA1(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᛀ")])
	baNWS6nfqTC5iX4Kl = T6wRistc1SCo4hqObgumK(u"ࠨࡋࡓࡘ࡛࠭ᛁ") if ndl0BskyaFqDxH9eJOZY7TgvVbXAt==V2RbfGOBdcA6l8NTsPWzEyvS7(u"࠸࠳࠶ᛔ") else FGDJwkEbTB5SoXujs3f(u"ࠩࡐ࠷࡚࠭ᛂ")
	VtcQzmeS6CRJBDW47 = baNWS6nfqTC5iX4Kl.lower()
	rHqkc3e0CJ5VByi6vLs = bLEBi8IO7uU2x3htYDdVq95.getSetting(sRth5giAQzWlEVm7JOX(u"ࠪࡥࡻ࠴ࠧᛃ")+VtcQzmeS6CRJBDW47+LgpdP3UjFRnlX(u"ࠫ࠳ࡻࡳࡦࡴࡤ࡫ࡪࡴࡴࡠࠩᛄ")+S8UKq3VcpRgBMdT1hknl4voHfr)
	PZjG9QsCtzpMg2TcE = bLEBi8IO7uU2x3htYDdVq95.getSetting(WMkAjB1RgN7q(u"ࠬࡧࡶ࠯ࠩᛅ")+VtcQzmeS6CRJBDW47+b05yftsZ6NYgIKP(u"࠭࠮ࡳࡧࡩࡩࡷ࡫ࡲࡠࠩᛆ")+S8UKq3VcpRgBMdT1hknl4voHfr)
	if rHqkc3e0CJ5VByi6vLs or PZjG9QsCtzpMg2TcE:
		qmr7vLh1EW += C2jP0iLNGKnHu9xp(u"ࠧࡽࠩᛇ")
		if rHqkc3e0CJ5VByi6vLs: qmr7vLh1EW += QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠨࠨࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࡃࠧᛈ")+rHqkc3e0CJ5VByi6vLs
		if PZjG9QsCtzpMg2TcE: qmr7vLh1EW += gItVahxL0w(u"ࠩࠩࡖࡪ࡬ࡥࡳࡧࡵࡁࠬᛉ")+PZjG9QsCtzpMg2TcE
		qmr7vLh1EW = qmr7vLh1EW.replace(QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠪࢀࠫ࠭ᛊ"),v5EA6TqHX3s4jzBMk(u"ࠫࢁ࠭ᛋ"))
	j5w2pahcNqXd8JKyROiPu = bLEBi8IO7uU2x3htYDdVq95.getSetting(jx7s8T0BFgODXLMzIYedf(u"ࠬࡧࡶ࠯ࠩᛌ")+VtcQzmeS6CRJBDW47+LgpdP3UjFRnlX(u"࠭࠮ࡴࡧࡵࡺࡪࡸ࡟ࠨᛍ")+S8UKq3VcpRgBMdT1hknl4voHfr)
	if j5w2pahcNqXd8JKyROiPu:
		HatGX9moKUgNehufE2cQJA = My7Dwqvs6bfGNSIgX.findall(BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠧ࠻࠱࠲ࠬ࠳࠰࠿ࠪ࠱ࠪᛎ"),qmr7vLh1EW,My7Dwqvs6bfGNSIgX.DOTALL)
		qmr7vLh1EW = qmr7vLh1EW.replace(HatGX9moKUgNehufE2cQJA[vvHpKfcqRnrFzjG(u"࠰ᛕ")],j5w2pahcNqXd8JKyROiPu)
	B0xcwKkMQ16mpSFRaVHPTzuhUZngLq(qmr7vLh1EW,baNWS6nfqTC5iX4Kl,EAdbsmyiqLtjhPlxG)
else:
	from G6AHskJeqN import NZrI2wknju57PlJaDoRziLVm1,hSjJ9C1FZo5VzWwl2tRP,V69VaywMFGd
	WFMmPzdINGnfvRC1BoeOpb5 = C2jP0iLNGKnHu9xp(u"ࠨࠩᛏ")
	NZrI2wknju57PlJaDoRziLVm1(l0WAe1f7Bpi5ZXk(u"ࠩࡶࡸࡦࡸࡴࠨᛐ"))
	try: hSjJ9C1FZo5VzWwl2tRP(q0HETPprhGgacmbJ4jD,GDL3q5vFjwIVrM2ElRZNd)
	except Exception as tnOo1QlfFN98JVG6vreRLxb0: WFMmPzdINGnfvRC1BoeOpb5 = N3JR6Bk5lVxnfGdgvQb.format_exc()
	V69VaywMFGd(WFMmPzdINGnfvRC1BoeOpb5)
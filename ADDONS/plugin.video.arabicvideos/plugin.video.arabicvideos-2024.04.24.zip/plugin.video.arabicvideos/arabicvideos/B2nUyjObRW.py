# -*- coding: utf-8 -*-
from G6AHskJeqN import *
baNWS6nfqTC5iX4Kl = 'FOSTA'
teUPLFC3B8bArakwHVGsdhoIWDM49f = '_FST_'
EZxQp1WOldMTvFU = AK5RqLhji4W1wt9VdrCD3PGeQM[baNWS6nfqTC5iX4Kl][0]
eh2tDvRFWpLQI = ['الصفحة الرئيسية','Sign in','تجهيز الحلقات القادمة']
def VbgEajY4Bt2COpGDcPqI(mode,url,text):
	if   mode==600: ft3e2JBKQVXWlFPjaMhkEqGxvDg = eN02L7Tf5bQ()
	elif mode==601: ft3e2JBKQVXWlFPjaMhkEqGxvDg = sscM839DP1jWZ4zl6uIx0Kyn(url,text)
	elif mode==602: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HDxCnPKFhITpZmOsA4a0UL6(url)
	elif mode==603: ft3e2JBKQVXWlFPjaMhkEqGxvDg = CbkBOWecfqN8Jajp1Dd(url,text)
	elif mode==604: ft3e2JBKQVXWlFPjaMhkEqGxvDg = M25iOAH9NfalvyPEUuToG8qn(url)
	elif mode==609: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HjZcUIVAXFCqy9TfBWKtgY2(text)
	else: ft3e2JBKQVXWlFPjaMhkEqGxvDg = False
	return ft3e2JBKQVXWlFPjaMhkEqGxvDg
def eN02L7Tf5bQ():
	xxE5BSyQkNsj,url,xHb86g9WZqPwRfVjXD2JalzSIp = zu3wbS2VXEhgxUYGKmIqpOosT(SToQEHqGtMnAlFbCz4wxBDuOsmW7,'GET',EZxQp1WOldMTvFU,'fosta','فوستا fosta','fosta.azureedge.net')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'بحث في الموقع','',609,'','','_REMEMBERRESULTS_')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'جديد الحلقات',xxE5BSyQkNsj,601,'','','new_episodes')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'جديد الأفلام',xxE5BSyQkNsj,601,'','','new_movies')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'المسلسلات المميزة',xxE5BSyQkNsj,601,'','','featured_series')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"navslide-wrap"(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if not XBuP6Op7y4K:
		ZIOHgA3z0TBR('','','موقع فوستا','البرنامج لم يستطيع إيجاد عنوان الموقع أو تصميم الموقع تغير')
		return
	vsptNMP2ZQC = XBuP6Op7y4K[0]
	items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?</i>(.*?)</a>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	for BoEFz2WhUyvTgDeiZ,title in items:
		if title in eh2tDvRFWpLQI: continue
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,604)
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('/category.php">(.*?)"navslide-divider"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	vsptNMP2ZQC = XBuP6Op7y4K[0]
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall("'dropdown-menu'(.*?)</ul>",MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	for iiBEzXVNFDhfj36 in XBuP6Op7y4K: vsptNMP2ZQC = vsptNMP2ZQC.replace(iiBEzXVNFDhfj36,'')
	items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?>(.*?)</a>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	for BoEFz2WhUyvTgDeiZ,title in items:
		if title in eh2tDvRFWpLQI: continue
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,604)
	return
def M25iOAH9NfalvyPEUuToG8qn(url):
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'','','','','FOSTA-SUBMENU-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	KRI8WExzA4p = My7Dwqvs6bfGNSIgX.findall('"caret"(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if KRI8WExzA4p:
		vsptNMP2ZQC = KRI8WExzA4p[0]
		vsptNMP2ZQC = vsptNMP2ZQC.replace('"presentation"','</ul>')
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		if not XBuP6Op7y4K: XBuP6Op7y4K = [('',vsptNMP2ZQC)]
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] فرز أو فلتر أو ترتيب [/COLOR]','',9999)
		for bN5qWnCM903cj4zHxEasi1pBY7ZdrR,vsptNMP2ZQC in XBuP6Op7y4K:
			items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?>(.*?)</a>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
			if bN5qWnCM903cj4zHxEasi1pBY7ZdrR: bN5qWnCM903cj4zHxEasi1pBY7ZdrR = bN5qWnCM903cj4zHxEasi1pBY7ZdrR+': '
			for BoEFz2WhUyvTgDeiZ,title in items:
				title = bN5qWnCM903cj4zHxEasi1pBY7ZdrR+title
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,601)
	kdYXhMN8Hpbt = My7Dwqvs6bfGNSIgX.findall('"pm-category-subcats"(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if kdYXhMN8Hpbt:
		vsptNMP2ZQC = kdYXhMN8Hpbt[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)">(.*?)</a>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		if len(items)<30:
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
			for BoEFz2WhUyvTgDeiZ,title in items:
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,601)
	if not KRI8WExzA4p and not kdYXhMN8Hpbt: sscM839DP1jWZ4zl6uIx0Kyn(url)
	return
def sscM839DP1jWZ4zl6uIx0Kyn(url,h5QaxwPF7SOu6fMBTGXRU2yn=''):
	if h5QaxwPF7SOu6fMBTGXRU2yn=='ajax-search':
		url,search = url.split('?',1)
		data = 'queryString='+search
		headers = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'POST',url,data,headers,'','','FOSTA-TITLES-1st')
	else:
		xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'','','','','FOSTA-TITLES-2nd')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	vsptNMP2ZQC,items = '',[]
	xxE5BSyQkNsj = ooq2D9xF8ZLpPBs(url,'url')
	if h5QaxwPF7SOu6fMBTGXRU2yn=='ajax-search':
		vsptNMP2ZQC = MK6ZT2zjC1SbmveNFqor
		zE1FBZLDvygwGdkef74lnRJVXCUqKH = My7Dwqvs6bfGNSIgX.findall('href="(.*?)">(.*?)</a>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title in zE1FBZLDvygwGdkef74lnRJVXCUqKH: items.append(('',BoEFz2WhUyvTgDeiZ,title))
	elif h5QaxwPF7SOu6fMBTGXRU2yn=='featured':
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"pm-video-watch-featured"(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if XBuP6Op7y4K: vsptNMP2ZQC = XBuP6Op7y4K[0]
	elif h5QaxwPF7SOu6fMBTGXRU2yn=='new_episodes':
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"row pm-ul-browse-videos(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if XBuP6Op7y4K: vsptNMP2ZQC = XBuP6Op7y4K[0]
	elif h5QaxwPF7SOu6fMBTGXRU2yn=='new_movies':
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"row pm-ul-browse-videos(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if len(XBuP6Op7y4K)>1: vsptNMP2ZQC = XBuP6Op7y4K[1]
	elif h5QaxwPF7SOu6fMBTGXRU2yn=='featured_series':
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"home-series-list"(.*?)</div>[\t|\n]*</div>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if XBuP6Op7y4K: vsptNMP2ZQC = XBuP6Op7y4K[0]
		zE1FBZLDvygwGdkef74lnRJVXCUqKH = My7Dwqvs6bfGNSIgX.findall('href="(.*?)">(.*?)</a>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title in zE1FBZLDvygwGdkef74lnRJVXCUqKH: items.append(('',BoEFz2WhUyvTgDeiZ,title))
	else:
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('(data-echo=".*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if XBuP6Op7y4K: vsptNMP2ZQC = XBuP6Op7y4K[0]
	if vsptNMP2ZQC and not items: items = My7Dwqvs6bfGNSIgX.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	if not items: return
	y7y3d5Fbhv42ONmtwLZ0SerYoQq = []
	tkBQK76YMeUlRI1TomgECfA = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for IcWzVO137wFvemn2QTq8yKs9,BoEFz2WhUyvTgDeiZ,title in items:
		ffhN7jAqe3Q4cR0Ukptzl = My7Dwqvs6bfGNSIgX.findall('(.*?) (الحلقة|حلقة).\d+',title,My7Dwqvs6bfGNSIgX.DOTALL)
		if any(WoFrX46wzbCNp18 in title for WoFrX46wzbCNp18 in tkBQK76YMeUlRI1TomgECfA):
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,602,IcWzVO137wFvemn2QTq8yKs9)
		elif h5QaxwPF7SOu6fMBTGXRU2yn=='new_episodes':
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,602,IcWzVO137wFvemn2QTq8yKs9)
		elif ffhN7jAqe3Q4cR0Ukptzl:
			title = '_MOD_' + ffhN7jAqe3Q4cR0Ukptzl[0][0]
			if title not in y7y3d5Fbhv42ONmtwLZ0SerYoQq:
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,603,IcWzVO137wFvemn2QTq8yKs9)
				y7y3d5Fbhv42ONmtwLZ0SerYoQq.append(title)
		else: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,603,IcWzVO137wFvemn2QTq8yKs9)
	if 1:
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"pagination(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if XBuP6Op7y4K:
			vsptNMP2ZQC = XBuP6Op7y4K[0]
			items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?>(.*?)</a>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
			for BoEFz2WhUyvTgDeiZ,title in items:
				if BoEFz2WhUyvTgDeiZ=='#': continue
				BoEFz2WhUyvTgDeiZ = xxE5BSyQkNsj+'/'+BoEFz2WhUyvTgDeiZ.strip('/')
				title = PIfAumbGicwg5ye(title)
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'صفحة '+title,BoEFz2WhUyvTgDeiZ,601)
	return
def CbkBOWecfqN8Jajp1Dd(url,b0z14BOJQMs):
	xxE5BSyQkNsj = ooq2D9xF8ZLpPBs(url,'url')
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'','','','','FOSTA-EPISODES-2nd')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	KRI8WExzA4p = My7Dwqvs6bfGNSIgX.findall('"SeasonsBox"(.*?)"SeasonsEpisodesMain',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	QFrVYJkywEsXquMNz = My7Dwqvs6bfGNSIgX.findall('"series-header".*?src="(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if QFrVYJkywEsXquMNz: IcWzVO137wFvemn2QTq8yKs9 = QFrVYJkywEsXquMNz[0]
	else: IcWzVO137wFvemn2QTq8yKs9 = ''
	items = []
	uq1Ayb0IlosZdzU54jBTnRK9 = False
	if KRI8WExzA4p and not b0z14BOJQMs:
		vsptNMP2ZQC = KRI8WExzA4p[0]
		items = My7Dwqvs6bfGNSIgX.findall('''onclick="openCity\(event, '(.*?)'\)">(.*?)</button>''',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for b0z14BOJQMs,title in items:
			b0z14BOJQMs = b0z14BOJQMs.strip('#')
			if len(items)>1: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,url,603,IcWzVO137wFvemn2QTq8yKs9,'',b0z14BOJQMs)
			else: uq1Ayb0IlosZdzU54jBTnRK9 = True
	else: uq1Ayb0IlosZdzU54jBTnRK9 = True
	kdYXhMN8Hpbt = My7Dwqvs6bfGNSIgX.findall('id="'+b0z14BOJQMs+'"(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if kdYXhMN8Hpbt and uq1Ayb0IlosZdzU54jBTnRK9:
		vsptNMP2ZQC = kdYXhMN8Hpbt[0]
		zE1FBZLDvygwGdkef74lnRJVXCUqKH = My7Dwqvs6bfGNSIgX.findall('''href=['"](.*?)['"]><li><em>(.*?)</span>''',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		items = []
		for BoEFz2WhUyvTgDeiZ,title in zE1FBZLDvygwGdkef74lnRJVXCUqKH: items.append((BoEFz2WhUyvTgDeiZ,title,IcWzVO137wFvemn2QTq8yKs9))
		if not items: items = My7Dwqvs6bfGNSIgX.findall('"thumbnail".*?href="(.*?)" title="(.*?)".*?src="(.*?)"',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title,IcWzVO137wFvemn2QTq8yKs9 in items:
			BoEFz2WhUyvTgDeiZ = xxE5BSyQkNsj+'/'+BoEFz2WhUyvTgDeiZ.strip('/')
			title = title.replace('</em><span>',' ')
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,602,IcWzVO137wFvemn2QTq8yKs9)
	return
def HDxCnPKFhITpZmOsA4a0UL6(url):
	Qki8AbTHYjzM2Ls76Gdr3eqo1Wn,TfO968IJUmqNpCzA1 = [],[]
	bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = url.replace('watch.php','play.php')
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,'','','','','FOSTA-PLAY-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"WatchList"(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('embed-url="(.*?)".*?<strong>(.*?)</strong>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title in items:
			if BoEFz2WhUyvTgDeiZ not in TfO968IJUmqNpCzA1:
				TfO968IJUmqNpCzA1.append(BoEFz2WhUyvTgDeiZ)
				LkVZrOE4XBSN2Qex5PyHqC = ooq2D9xF8ZLpPBs(BoEFz2WhUyvTgDeiZ,'name')
				BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ+'?named='+LkVZrOE4XBSN2Qex5PyHqC+'__watch'
				Qki8AbTHYjzM2Ls76Gdr3eqo1Wn.append(BoEFz2WhUyvTgDeiZ)
	BoEFz2WhUyvTgDeiZ = My7Dwqvs6bfGNSIgX.findall('<iframe src="(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if BoEFz2WhUyvTgDeiZ:
		BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ[0]
		if BoEFz2WhUyvTgDeiZ not in TfO968IJUmqNpCzA1:
			TfO968IJUmqNpCzA1.append(BoEFz2WhUyvTgDeiZ)
			LkVZrOE4XBSN2Qex5PyHqC = ooq2D9xF8ZLpPBs(BoEFz2WhUyvTgDeiZ,'name')
			BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ+'?named='+LkVZrOE4XBSN2Qex5PyHqC+'__embed'
			Qki8AbTHYjzM2Ls76Gdr3eqo1Wn.append(BoEFz2WhUyvTgDeiZ)
	bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = url.replace('watch.php','download.php')
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,'','','',False,'FOSTA-PLAY-2nd')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"downList"(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('download-url="(.*?)".*?<span>(.*?)</span>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title in items:
			if BoEFz2WhUyvTgDeiZ not in TfO968IJUmqNpCzA1:
				TfO968IJUmqNpCzA1.append(BoEFz2WhUyvTgDeiZ)
				LkVZrOE4XBSN2Qex5PyHqC = ooq2D9xF8ZLpPBs(BoEFz2WhUyvTgDeiZ,'name')
				BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ+'?named='+LkVZrOE4XBSN2Qex5PyHqC+'__download'
				Qki8AbTHYjzM2Ls76Gdr3eqo1Wn.append(BoEFz2WhUyvTgDeiZ)
	import t1kDWXQVpC
	t1kDWXQVpC.rqVt2xDi7jzJHBcPMRs6h0L(Qki8AbTHYjzM2Ls76Gdr3eqo1Wn,baNWS6nfqTC5iX4Kl,'video',url)
	return
def HjZcUIVAXFCqy9TfBWKtgY2(search):
	search,LQf3AeozSrai,showDialogs = X54MLovbG8nAEkB9J(search)
	if search=='': search = ViKAIsLurq83RSENayxWb()
	if search=='': return
	search = search.replace(' ','+')
	url = EZxQp1WOldMTvFU+'/search.php?keywords='+search
	xxE5BSyQkNsj,bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,TOzKqRwpa6WrVMH8Pxy4X = zu3wbS2VXEhgxUYGKmIqpOosT(SToQEHqGtMnAlFbCz4wxBDuOsmW7,'GET',url,'fosta','فوستا fosta','fosta.azureedge.net')
	sscM839DP1jWZ4zl6uIx0Kyn(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,'search')
	return
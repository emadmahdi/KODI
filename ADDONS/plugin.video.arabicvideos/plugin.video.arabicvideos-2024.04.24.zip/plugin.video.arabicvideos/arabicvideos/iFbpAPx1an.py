# -*- coding: utf-8 -*-
from G6AHskJeqN import *
baNWS6nfqTC5iX4Kl = 'EGYBEST1'
teUPLFC3B8bArakwHVGsdhoIWDM49f = '_EB1_'
EZxQp1WOldMTvFU = AK5RqLhji4W1wt9VdrCD3PGeQM[baNWS6nfqTC5iX4Kl][0]
eh2tDvRFWpLQI = ['مكتبتي','ايجي بست']
def VbgEajY4Bt2COpGDcPqI(mode,url,z3z9QgENFk5eMYB4,text):
	if   mode==770: ft3e2JBKQVXWlFPjaMhkEqGxvDg = eN02L7Tf5bQ()
	elif mode==771: ft3e2JBKQVXWlFPjaMhkEqGxvDg = sscM839DP1jWZ4zl6uIx0Kyn(url,z3z9QgENFk5eMYB4)
	elif mode==772: ft3e2JBKQVXWlFPjaMhkEqGxvDg = M25iOAH9NfalvyPEUuToG8qn(url)
	elif mode==773: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HDxCnPKFhITpZmOsA4a0UL6(url)
	elif mode==774: ft3e2JBKQVXWlFPjaMhkEqGxvDg = LLJlTxDePyjoVKA(url,'FULL_FILTER___'+text)
	elif mode==775: ft3e2JBKQVXWlFPjaMhkEqGxvDg = LLJlTxDePyjoVKA(url,'DEFINED_FILTER___'+text)
	elif mode==776: ft3e2JBKQVXWlFPjaMhkEqGxvDg = rFZB0V49nigPyfKQHqcLXEs(url,z3z9QgENFk5eMYB4)
	elif mode==779: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HjZcUIVAXFCqy9TfBWKtgY2(text,url)
	else: ft3e2JBKQVXWlFPjaMhkEqGxvDg = False
	return ft3e2JBKQVXWlFPjaMhkEqGxvDg
def eN02L7Tf5bQ():
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'بحث في الموقع','',779,'','','_REMEMBERRESULTS_')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(IIiPCruL6dT8s1lqj47SzpVHnYNm,'GET',EZxQp1WOldMTvFU,'','','','','EGYBEST1-MENU-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('nav-list(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?<span>(.*?)</span>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title in items:
			title = title.strip(' ')
			if any(WoFrX46wzbCNp18 in title for WoFrX46wzbCNp18 in eh2tDvRFWpLQI): continue
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,771)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('main-article(.*?)social-box',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('main-title.*?">(.*?)<.*?href="(.*?)"',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for title,BoEFz2WhUyvTgDeiZ in items:
			title = title.strip(' ')
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,771,'','mainmenu')
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('main-menu(.*?)</div></div>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)">(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title in items:
			title = title.strip(' ')
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,771)
	return MK6ZT2zjC1SbmveNFqor
def rFZB0V49nigPyfKQHqcLXEs(url,type=''):
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'','','','','EGYBEST1-SEASONS_EPISODES-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('main-article".*?">(.*?)<(.*?)article',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		Or0yBIEzGeCn6pkYDgRal78F,o93oJVvuQUY,items = '','',[]
		for name,vsptNMP2ZQC in XBuP6Op7y4K:
			if 'حلقات' in name: o93oJVvuQUY = vsptNMP2ZQC
			if 'مواسم' in name: Or0yBIEzGeCn6pkYDgRal78F = vsptNMP2ZQC
		if Or0yBIEzGeCn6pkYDgRal78F and not type:
			items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?data-src="(.*?)".*?"title">(.*?)<',Or0yBIEzGeCn6pkYDgRal78F,My7Dwqvs6bfGNSIgX.DOTALL)
			if len(items)>1:
				for BoEFz2WhUyvTgDeiZ,IcWzVO137wFvemn2QTq8yKs9,title in items:
					VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,776,IcWzVO137wFvemn2QTq8yKs9,'season')
		if o93oJVvuQUY and len(items)<2:
			items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?data-src="(.*?)".*?title="(.*?)"',o93oJVvuQUY,My7Dwqvs6bfGNSIgX.DOTALL)
			if items:
				for BoEFz2WhUyvTgDeiZ,IcWzVO137wFvemn2QTq8yKs9,title in items:
					VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,773,IcWzVO137wFvemn2QTq8yKs9)
			else:
				items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)">(.*?)<',o93oJVvuQUY,My7Dwqvs6bfGNSIgX.DOTALL)
				for BoEFz2WhUyvTgDeiZ,title in items:
					VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,773)
	return
def sscM839DP1jWZ4zl6uIx0Kyn(url,type=''):
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'','','','','EGYBEST1-TITLES-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	items,LrPu5D8XJ1FpxhYvyz2l,PPebqkulZUsx3GCLdnYvR = [],False,False
	if not type:
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('main-content(.*?)</div>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if XBuP6Op7y4K:
			vsptNMP2ZQC = XBuP6Op7y4K[0]
			items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?</i>(.*?)</a>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
			for BoEFz2WhUyvTgDeiZ,title in items:
				title = title.strip(' ')
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,771,'','submenu')
				LrPu5D8XJ1FpxhYvyz2l = True
	if not type and 'p=' not in url:
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('searchform(.*?)</form>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if XBuP6Op7y4K:
			if LrPu5D8XJ1FpxhYvyz2l: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'فلتر محدد',url,775,'','filter')
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'فلتر كامل',url,774,'','filter')
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'بحث',url,779)
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
			PPebqkulZUsx3GCLdnYvR = True
	if not LrPu5D8XJ1FpxhYvyz2l:
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('blocks(.*?)article',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if XBuP6Op7y4K:
			vsptNMP2ZQC = XBuP6Op7y4K[0]
			items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?src="(.*?)".*?class="title">(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
			for BoEFz2WhUyvTgDeiZ,IcWzVO137wFvemn2QTq8yKs9,title in items:
				IcWzVO137wFvemn2QTq8yKs9 = IcWzVO137wFvemn2QTq8yKs9.strip('\n')
				BoEFz2WhUyvTgDeiZ = XnQbsZF0Ouh8p7zCdUN(BoEFz2WhUyvTgDeiZ)
				if '/serie/' in BoEFz2WhUyvTgDeiZ: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,776,IcWzVO137wFvemn2QTq8yKs9,'season')
				else: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,773,IcWzVO137wFvemn2QTq8yKs9)
			z3z9QgENFk5eMYB4 = '1'
			if 'p=' in url: url,z3z9QgENFk5eMYB4 = url.split('p=',1)
			W9YiR1FGTdzO3jByXPA70D = '&' if '?' in url else '?'
			url = url+W9YiR1FGTdzO3jByXPA70D
			url = url.replace('?&','?')
			if len(items)==40:
				url = url+'p='+str(int(z3z9QgENFk5eMYB4)+1)
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'الصفحة التالية',url,771)
			elif z3z9QgENFk5eMYB4!='1':
				url = url+'p='+str(int(z3z9QgENFk5eMYB4)-1)
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'الصفحة السابقة',url,771)
	return
def HDxCnPKFhITpZmOsA4a0UL6(url):
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(SToQEHqGtMnAlFbCz4wxBDuOsmW7,'GET',url,'','','','','EGYBEST1-PLAY-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	ME2Q6F7u8Vp1km9ws = My7Dwqvs6bfGNSIgX.findall('<label>التصنيف</label>.*?">(.*?)<',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if ME2Q6F7u8Vp1km9ws and a97xrkSOefH5DbjXunq(baNWS6nfqTC5iX4Kl,url,ME2Q6F7u8Vp1km9ws): return
	breQmB38nWlfEc6CNT,Qki8AbTHYjzM2Ls76Gdr3eqo1Wn,uuseD16TiQ30VKlZxgm = [],[],[]
	BoEFz2WhUyvTgDeiZ = My7Dwqvs6bfGNSIgX.findall('download-section.*?action="(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if BoEFz2WhUyvTgDeiZ:
		BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ[0]
		if BoEFz2WhUyvTgDeiZ not in uuseD16TiQ30VKlZxgm:
			uuseD16TiQ30VKlZxgm.append(BoEFz2WhUyvTgDeiZ)
			Qki8AbTHYjzM2Ls76Gdr3eqo1Wn.append(BoEFz2WhUyvTgDeiZ+'?named=__embed______'+F8fMqZKB4APk(url))
	xAcIatGBYy0FLXroS1ig3Ts9KZ8P5 = My7Dwqvs6bfGNSIgX.findall('WatchServers(.*?)</div>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	for vsptNMP2ZQC in xAcIatGBYy0FLXroS1ig3Ts9KZ8P5:
		NVHrZsqUp2 = My7Dwqvs6bfGNSIgX.findall("url='(.*?)'.*?>(.*?)<",vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,LkVZrOE4XBSN2Qex5PyHqC in NVHrZsqUp2:
			if BoEFz2WhUyvTgDeiZ not in uuseD16TiQ30VKlZxgm:
				uuseD16TiQ30VKlZxgm.append(BoEFz2WhUyvTgDeiZ)
				Qki8AbTHYjzM2Ls76Gdr3eqo1Wn.append(BoEFz2WhUyvTgDeiZ+'?named='+LkVZrOE4XBSN2Qex5PyHqC+'__both______'+F8fMqZKB4APk(url))
	import t1kDWXQVpC
	t1kDWXQVpC.rqVt2xDi7jzJHBcPMRs6h0L(Qki8AbTHYjzM2Ls76Gdr3eqo1Wn,baNWS6nfqTC5iX4Kl,'video',url)
	return
def HjZcUIVAXFCqy9TfBWKtgY2(search,url=''):
	search,LQf3AeozSrai,showDialogs = X54MLovbG8nAEkB9J(search)
	if not search: search = ViKAIsLurq83RSENayxWb()
	if not search: return
	ystIEd371fLkT50pcRUWi9olNDu = search.replace(' ','%20')
	if not url: url = EZxQp1WOldMTvFU+'/search?query='+ystIEd371fLkT50pcRUWi9olNDu
	else: url = url+'?title='+ystIEd371fLkT50pcRUWi9olNDu+'&genre=&year=&lang='
	sscM839DP1jWZ4zl6uIx0Kyn(url,'search')
	return
def lAjOn69YLFxJNEvTrbfwkiXm2d(url):
	url = url.split('/smartemadfilter?')[0]
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(IIiPCruL6dT8s1lqj47SzpVHnYNm,'GET',url,'','','','','EGYBEST1-GET_FILTERS_BLOCKS-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	E3ErsLQfR4JXt = []
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('form-row(.*?)</form>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		E3ErsLQfR4JXt = My7Dwqvs6bfGNSIgX.findall('select name="(.*?)".*?value>(.*?)<(.*?)</select',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		yaIcBHGsnqtQ8,P9pVfsQSTg7IraUGeKLWwxdz,xAcIatGBYy0FLXroS1ig3Ts9KZ8P5 = zip(*E3ErsLQfR4JXt)
		E3ErsLQfR4JXt = zip(P9pVfsQSTg7IraUGeKLWwxdz,yaIcBHGsnqtQ8,xAcIatGBYy0FLXroS1ig3Ts9KZ8P5)
	return E3ErsLQfR4JXt
def kvYFrVe3g8H7dNhIa(vsptNMP2ZQC):
	items = My7Dwqvs6bfGNSIgX.findall('value="(.*?)">(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	return items
def Dm3ydMnCxH49R(url):
	url = url.replace('/smartemadfilter?','?title=&')
	return url
eymLcfnNAQpBaU7 = ['year','lang','genre']
mQJHz26sAG = ['year','lang','genre']
def LLJlTxDePyjoVKA(url,filter):
	url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter=='': H2HMwT4JFz7rDkPZmRjcX,JPnr9ICqkDyV = '',''
	else: H2HMwT4JFz7rDkPZmRjcX,JPnr9ICqkDyV = filter.split('___')
	if type=='DEFINED_FILTER':
		if mQJHz26sAG[0]+'=' not in H2HMwT4JFz7rDkPZmRjcX: g4Y0BXLxCpuojKP1SAUtcq7TwN2 = mQJHz26sAG[0]
		for FVW0I9sYcAjmDgn8r in range(len(mQJHz26sAG[0:-1])):
			if mQJHz26sAG[FVW0I9sYcAjmDgn8r]+'=' in H2HMwT4JFz7rDkPZmRjcX: g4Y0BXLxCpuojKP1SAUtcq7TwN2 = mQJHz26sAG[FVW0I9sYcAjmDgn8r+1]
		HHXeMqVOshPcW3tULa5v = H2HMwT4JFz7rDkPZmRjcX+'&'+g4Y0BXLxCpuojKP1SAUtcq7TwN2+'=0'
		DoSfCckGA9BQe = JPnr9ICqkDyV+'&'+g4Y0BXLxCpuojKP1SAUtcq7TwN2+'=0'
		A7AEKRlF6Hf3eWVxY0NdwgsMPCc = HHXeMqVOshPcW3tULa5v.strip('&')+'___'+DoSfCckGA9BQe.strip('&')
		woj78rBnbLlmZWIy19iPHFCf5 = BrbZhHKJ0jnIe2lumE9M(JPnr9ICqkDyV,'all')
		bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = url+'/smartemadfilter?'+woj78rBnbLlmZWIy19iPHFCf5
	elif type=='FULL_FILTER':
		WUSylLup41cYkhVXGtq = BrbZhHKJ0jnIe2lumE9M(H2HMwT4JFz7rDkPZmRjcX,'modified_values')
		WUSylLup41cYkhVXGtq = XnQbsZF0Ouh8p7zCdUN(WUSylLup41cYkhVXGtq)
		if JPnr9ICqkDyV: JPnr9ICqkDyV = BrbZhHKJ0jnIe2lumE9M(JPnr9ICqkDyV,'all')
		if not JPnr9ICqkDyV: bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = url
		else: bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = url+'/smartemadfilter?'+JPnr9ICqkDyV
		QAKdHzO0rehbtyIc = Dm3ydMnCxH49R(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'أظهار قائمة الفيديو التي تم اختيارها ',QAKdHzO0rehbtyIc,771,'','filter')
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+' [[   '+WUSylLup41cYkhVXGtq+'   ]]',QAKdHzO0rehbtyIc,771,'','filter')
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	E3ErsLQfR4JXt = lAjOn69YLFxJNEvTrbfwkiXm2d(url)
	dict = {}
	for name,RTsbVE9CiQt,vsptNMP2ZQC in E3ErsLQfR4JXt:
		name = name.replace('كل ','')
		items = kvYFrVe3g8H7dNhIa(vsptNMP2ZQC)
		if '=' not in bJEs4IVAPdyUrhwCLv9k2YoOl8nt1: bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = url
		if type=='DEFINED_FILTER':
			if g4Y0BXLxCpuojKP1SAUtcq7TwN2!=RTsbVE9CiQt: continue
			elif len(items)<2:
				if RTsbVE9CiQt==mQJHz26sAG[-1]:
					QAKdHzO0rehbtyIc = Dm3ydMnCxH49R(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1)
					sscM839DP1jWZ4zl6uIx0Kyn(QAKdHzO0rehbtyIc)
				else: LLJlTxDePyjoVKA(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,'DEFINED_FILTER___'+A7AEKRlF6Hf3eWVxY0NdwgsMPCc)
				return
			else:
				if RTsbVE9CiQt==mQJHz26sAG[-1]:
					QAKdHzO0rehbtyIc = Dm3ydMnCxH49R(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1)
					VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'الجميع ',QAKdHzO0rehbtyIc,771,'','filter')
				else: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'الجميع ',bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,775,'','',A7AEKRlF6Hf3eWVxY0NdwgsMPCc)
		elif type=='FULL_FILTER':
			HHXeMqVOshPcW3tULa5v = H2HMwT4JFz7rDkPZmRjcX+'&'+RTsbVE9CiQt+'=0'
			DoSfCckGA9BQe = JPnr9ICqkDyV+'&'+RTsbVE9CiQt+'=0'
			A7AEKRlF6Hf3eWVxY0NdwgsMPCc = HHXeMqVOshPcW3tULa5v+'___'+DoSfCckGA9BQe
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'الجميع :'+name,bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,774,'','',A7AEKRlF6Hf3eWVxY0NdwgsMPCc)
		dict[RTsbVE9CiQt] = {}
		for WoFrX46wzbCNp18,A5AMg7LY1HlOz0B82n in items:
			if not WoFrX46wzbCNp18: continue
			if A5AMg7LY1HlOz0B82n in eh2tDvRFWpLQI: continue
			dict[RTsbVE9CiQt][WoFrX46wzbCNp18] = A5AMg7LY1HlOz0B82n
			HHXeMqVOshPcW3tULa5v = H2HMwT4JFz7rDkPZmRjcX+'&'+RTsbVE9CiQt+'='+A5AMg7LY1HlOz0B82n
			DoSfCckGA9BQe = JPnr9ICqkDyV+'&'+RTsbVE9CiQt+'='+WoFrX46wzbCNp18
			QQIzTLCXyhtZ7pRNnGq = HHXeMqVOshPcW3tULa5v+'___'+DoSfCckGA9BQe
			title = A5AMg7LY1HlOz0B82n+' :'#+dict[RTsbVE9CiQt]['0']
			title = A5AMg7LY1HlOz0B82n+' :'+name
			if type=='FULL_FILTER': VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,url,774,'','',QQIzTLCXyhtZ7pRNnGq)
			elif type=='DEFINED_FILTER' and mQJHz26sAG[-2]+'=' in H2HMwT4JFz7rDkPZmRjcX:
				woj78rBnbLlmZWIy19iPHFCf5 = BrbZhHKJ0jnIe2lumE9M(DoSfCckGA9BQe,'modified_filters')
				bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = url+'/smartemadfilter?'+woj78rBnbLlmZWIy19iPHFCf5
				QAKdHzO0rehbtyIc = Dm3ydMnCxH49R(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1)
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,QAKdHzO0rehbtyIc,771,'','filter')
			elif type=='DEFINED_FILTER': VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,url,775,'','',QQIzTLCXyhtZ7pRNnGq)
	return
def BrbZhHKJ0jnIe2lumE9M(PPebqkulZUsx3GCLdnYvR,mode):
	PPebqkulZUsx3GCLdnYvR = PPebqkulZUsx3GCLdnYvR.replace('=&','=0&')
	PPebqkulZUsx3GCLdnYvR = PPebqkulZUsx3GCLdnYvR.strip('&')
	mVSjqdOvyf = {}
	if '=' in PPebqkulZUsx3GCLdnYvR:
		items = PPebqkulZUsx3GCLdnYvR.split('&')
		for ZA1fBenNahOR3xrkjvwYSVMy6JK5s in items:
			nmqEj60bcdSQoFPGa,WoFrX46wzbCNp18 = ZA1fBenNahOR3xrkjvwYSVMy6JK5s.split('=')
			mVSjqdOvyf[nmqEj60bcdSQoFPGa] = WoFrX46wzbCNp18
	DidZH6E0pJelcU9xMCBgyL2KvR = ''
	for key in eymLcfnNAQpBaU7:
		if key in list(mVSjqdOvyf.keys()): WoFrX46wzbCNp18 = mVSjqdOvyf[key]
		else: WoFrX46wzbCNp18 = '0'
		if '%' not in WoFrX46wzbCNp18: WoFrX46wzbCNp18 = F8fMqZKB4APk(WoFrX46wzbCNp18)
		if mode=='modified_values' and WoFrX46wzbCNp18!='0': DidZH6E0pJelcU9xMCBgyL2KvR = DidZH6E0pJelcU9xMCBgyL2KvR+' + '+WoFrX46wzbCNp18
		elif mode=='modified_filters' and WoFrX46wzbCNp18!='0': DidZH6E0pJelcU9xMCBgyL2KvR = DidZH6E0pJelcU9xMCBgyL2KvR+'&'+key+'='+WoFrX46wzbCNp18
		elif mode=='all': DidZH6E0pJelcU9xMCBgyL2KvR = DidZH6E0pJelcU9xMCBgyL2KvR+'&'+key+'='+WoFrX46wzbCNp18
	DidZH6E0pJelcU9xMCBgyL2KvR = DidZH6E0pJelcU9xMCBgyL2KvR.strip(' + ')
	DidZH6E0pJelcU9xMCBgyL2KvR = DidZH6E0pJelcU9xMCBgyL2KvR.strip('&')
	DidZH6E0pJelcU9xMCBgyL2KvR = DidZH6E0pJelcU9xMCBgyL2KvR.replace('=0','=')
	return DidZH6E0pJelcU9xMCBgyL2KvR
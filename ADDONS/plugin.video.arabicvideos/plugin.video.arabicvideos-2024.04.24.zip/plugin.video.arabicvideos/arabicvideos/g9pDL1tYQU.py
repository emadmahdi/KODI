# -*- coding: utf-8 -*-
import sys as ehpURIi6QBDOGu8qj5EYzXrsWHJ7
hEJlvpt9LRO = ehpURIi6QBDOGu8qj5EYzXrsWHJ7.version_info [0] == 2
RrwvuxJ2OXsWnE9fzYNPDqS = 2048
pS1kDZ93ogBi50Hm7elLhEcyFfTx = 7
def E6Xo0wuA9fdQKlGOI (Ovquk0bMSPEL1ciQ73BJ2Ae):
	global Xb8HYvTBqV5RFAhE3KwMjC
	G4LMt9nR3Se6xWNpPuJd = ord (Ovquk0bMSPEL1ciQ73BJ2Ae [-1])
	qkDvfXryhi7cSz5Ee4AtVn0 = Ovquk0bMSPEL1ciQ73BJ2Ae [:-1]
	FEcyWfSHeL5Kotpx = G4LMt9nR3Se6xWNpPuJd % len (qkDvfXryhi7cSz5Ee4AtVn0)
	FPhirCoHEGw3I05B = qkDvfXryhi7cSz5Ee4AtVn0 [:FEcyWfSHeL5Kotpx] + qkDvfXryhi7cSz5Ee4AtVn0 [FEcyWfSHeL5Kotpx:]
	if hEJlvpt9LRO:
		ffWep5hGgyVTXHL1SM = unicode () .join ([unichr (ord (DDX7Qar0kqlIAKHdwnEh) - RrwvuxJ2OXsWnE9fzYNPDqS - (XapSRJwDcy5TEK0QHZr6n + G4LMt9nR3Se6xWNpPuJd) % pS1kDZ93ogBi50Hm7elLhEcyFfTx) for XapSRJwDcy5TEK0QHZr6n, DDX7Qar0kqlIAKHdwnEh in enumerate (FPhirCoHEGw3I05B)])
	else:
		ffWep5hGgyVTXHL1SM = str () .join ([chr (ord (DDX7Qar0kqlIAKHdwnEh) - RrwvuxJ2OXsWnE9fzYNPDqS - (XapSRJwDcy5TEK0QHZr6n + G4LMt9nR3Se6xWNpPuJd) % pS1kDZ93ogBi50Hm7elLhEcyFfTx) for XapSRJwDcy5TEK0QHZr6n, DDX7Qar0kqlIAKHdwnEh in enumerate (FPhirCoHEGw3I05B)])
	return eval (ffWep5hGgyVTXHL1SM)
fY5wTlhtnOc0Er6sdy4k87b,C2jP0iLNGKnHu9xp,UnWjVbo503mEMv9KF=E6Xo0wuA9fdQKlGOI,E6Xo0wuA9fdQKlGOI,E6Xo0wuA9fdQKlGOI
jx7s8T0BFgODXLMzIYedf,UxS67uoGThbMwnfNRzy4gajLd23JH,QynMHGWA0blfqTUdxRh5Jzi2t=UnWjVbo503mEMv9KF,C2jP0iLNGKnHu9xp,fY5wTlhtnOc0Er6sdy4k87b
jSu5Cg2Ub1OAkZVs8Yoz,V2RbfGOBdcA6l8NTsPWzEyvS7,LgpdP3UjFRnlX=QynMHGWA0blfqTUdxRh5Jzi2t,UxS67uoGThbMwnfNRzy4gajLd23JH,jx7s8T0BFgODXLMzIYedf
gItVahxL0w,BmcLzCFjuIrZP5fwXH18aN6YS,qbPw1d3KimF=LgpdP3UjFRnlX,V2RbfGOBdcA6l8NTsPWzEyvS7,jSu5Cg2Ub1OAkZVs8Yoz
EAc8h2sINroQYvR3WH06Ji7MVpn,vvHpKfcqRnrFzjG,l0WAe1f7Bpi5ZXk=qbPw1d3KimF,BmcLzCFjuIrZP5fwXH18aN6YS,gItVahxL0w
YB5xyI7MaRslVpv,PPNA7jWqZgDnXKVvtuai1kQdsEoMb0,BK9OvRSjZbtx7kYyop1u6zrE2QeiFI=l0WAe1f7Bpi5ZXk,vvHpKfcqRnrFzjG,EAc8h2sINroQYvR3WH06Ji7MVpn
sRth5giAQzWlEVm7JOX,WMkAjB1RgN7q,NVS30xAdRFMIw1n9CislkE2=BK9OvRSjZbtx7kYyop1u6zrE2QeiFI,PPNA7jWqZgDnXKVvtuai1kQdsEoMb0,YB5xyI7MaRslVpv
NB6ZDMqe91yfKQ240WpbIntjxiY5z,k5dztomYyN3H,T6wRistc1SCo4hqObgumK=NVS30xAdRFMIw1n9CislkE2,WMkAjB1RgN7q,sRth5giAQzWlEVm7JOX
RqldvxFuM5GEQ2HAz93o7afBb0,rbjsM8cRFiuA1,nr5mZG89ICi6cgt4MfLJa0=T6wRistc1SCo4hqObgumK,k5dztomYyN3H,NB6ZDMqe91yfKQ240WpbIntjxiY5z
hhlbF1Sns5TrEN8QPCYmL4,FGDJwkEbTB5SoXujs3f,BoWHNb9daQVCF16A=nr5mZG89ICi6cgt4MfLJa0,rbjsM8cRFiuA1,RqldvxFuM5GEQ2HAz93o7afBb0
v5EA6TqHX3s4jzBMk,C2dgEDAKQGsvh,b05yftsZ6NYgIKP=BoWHNb9daQVCF16A,FGDJwkEbTB5SoXujs3f,hhlbF1Sns5TrEN8QPCYmL4
import xbmc as tUXmK5PeEH9SDq,re as My7Dwqvs6bfGNSIgX,sys as ehpURIi6QBDOGu8qj5EYzXrsWHJ7,xbmcaddon as OGJ60aCqcw4EvUBbxDMHkIYN,random as SS503hkALwlNIvHYW7jb,os as XXRtDhYvWb35qnLBxIri7ScNUks0,xbmcvfs as TZhCObz1wKHAV,time as KBxPW9cX8dqtaUDG,pickle as XpRd3moWCYIQLDn51FS,zlib as DDeKqnGoBpLH1d6civ8JgN4V,xbmcgui as XUYb0K2ghSyFs,xbmcplugin as VMKAudnbXHORPj,sqlite3 as LLuOT2NGmXvS4C1WRyod8sQtIhV70a,traceback as N3JR6Bk5lVxnfGdgvQb,threading as iDocG6BXv7fT2z8UVOxgP
baNWS6nfqTC5iX4Kl = C2jP0iLNGKnHu9xp(u"ࠫࡑࡏࡂࡔࡑࡑࡉࠬਰ")
QgRBJhSGd4uX7i = OGJ60aCqcw4EvUBbxDMHkIYN.Addon().getAddonInfo(jx7s8T0BFgODXLMzIYedf(u"ࠬࡶࡡࡵࡪࠪ਱"))
HoKdjpmUzAC2LWVNeEDcrlJhgRfbMZ = XXRtDhYvWb35qnLBxIri7ScNUks0.path.join(QgRBJhSGd4uX7i,BmcLzCFjuIrZP5fwXH18aN6YS(u"࠭ࡰࡢࡥ࡮ࡥ࡬࡫ࡳࠨਲ"))
ehpURIi6QBDOGu8qj5EYzXrsWHJ7.path.append(HoKdjpmUzAC2LWVNeEDcrlJhgRfbMZ)
UUpr8jLiyQJ5l3VTow7hfu = tUXmK5PeEH9SDq.getInfoLabel(l0WAe1f7Bpi5ZXk(u"ࠢࡔࡻࡶࡸࡪࡳ࠮ࡃࡷ࡬ࡰࡩ࡜ࡥࡳࡵ࡬ࡳࡳࠨਲ਼"))
YSomBdvcNUMF3b8JDiCfrVW = My7Dwqvs6bfGNSIgX.findall(UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠨࠪ࡟ࡨࡡࡪ࡜࠯࡞ࡧ࠭ࠬ਴"),UUpr8jLiyQJ5l3VTow7hfu,My7Dwqvs6bfGNSIgX.DOTALL)
YSomBdvcNUMF3b8JDiCfrVW = float(YSomBdvcNUMF3b8JDiCfrVW[C2dgEDAKQGsvh(u"࠱ం")])
J9hVSHKexDN = tUXmK5PeEH9SDq.Player
WCMztebpRjHu8LnvXUJq6IOi2 = XUYb0K2ghSyFs.WindowXMLDialog
V8fmEML1b0PeaRZySnzh3H5J9 = YSomBdvcNUMF3b8JDiCfrVW<FGDJwkEbTB5SoXujs3f(u"࠳࠼ః")
BLz7m2RkNrxXQwy1cGAp = YSomBdvcNUMF3b8JDiCfrVW>PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"࠴࠼࠳࠿࠹ఄ")
if BLz7m2RkNrxXQwy1cGAp:
	cNzmj3fQZGvBo7hd8ACH = tUXmK5PeEH9SDq.LOGINFO
	u8c5pQm3iRwvxESj7PUrO,rcek0gbPZ6lmJwSaTNso = EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࡷࠪࡠࡺ࠸࠰࠳ࡣࠪਵ"),vvHpKfcqRnrFzjG(u"ࡸࠫࡡࡻ࠲࠱࠴ࡥࠫਸ਼")
	yGlIC3Pjr42JBeikmV6Z1FapgYA = TZhCObz1wKHAV.translatePath(sRth5giAQzWlEVm7JOX(u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯ࡵࡧࡰࡴࠬ਷"))
	from urllib.parse import unquote as _VQzFIY8uqU3SE9
else:
	cNzmj3fQZGvBo7hd8ACH = tUXmK5PeEH9SDq.LOGNOTICE
	u8c5pQm3iRwvxESj7PUrO,rcek0gbPZ6lmJwSaTNso = EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࡺ࠭࡜ࡶ࠴࠳࠶ࡦ࠭ਸ").encode(k5dztomYyN3H(u"࠭ࡵࡵࡨ࠻ࠫਹ")),sRth5giAQzWlEVm7JOX(u"ࡵࠨ࡞ࡸ࠶࠵࠸ࡢࠨ਺").encode(gItVahxL0w(u"ࠨࡷࡷࡪ࠽࠭਻"))
	yGlIC3Pjr42JBeikmV6Z1FapgYA = tUXmK5PeEH9SDq.translatePath(T6wRistc1SCo4hqObgumK(u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴ࡺࡥ࡮ࡲ਼ࠪ"))
	from urllib import unquote as _VQzFIY8uqU3SE9
anyWGKVFb6MH5eUxPrX8jZk = gItVahxL0w(u"࠺࠵అ")
p6l2Pum7aFtrhUHgXTE5w0n = NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠻࠶ఆ")*anyWGKVFb6MH5eUxPrX8jZk
TgAfXBWbo7 = LgpdP3UjFRnlX(u"࠸࠴ఇ")*p6l2Pum7aFtrhUHgXTE5w0n
bN2AKcC1yYJMjs = BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠳࠱ఈ")*TgAfXBWbo7
SToQEHqGtMnAlFbCz4wxBDuOsmW7 = b05yftsZ6NYgIKP(u"࠱ఉ")
c1lwnq73vkXsVjEhFpeoZtD = T6wRistc1SCo4hqObgumK(u"࠵࠳ఊ")*anyWGKVFb6MH5eUxPrX8jZk
f9Oum6c0FotxYn = UxS67uoGThbMwnfNRzy4gajLd23JH(u"࠵ఋ")*p6l2Pum7aFtrhUHgXTE5w0n
UuEtImzir9 = nr5mZG89ICi6cgt4MfLJa0(u"࠵࠻ఌ")*p6l2Pum7aFtrhUHgXTE5w0n
IIiPCruL6dT8s1lqj47SzpVHnYNm = YB5xyI7MaRslVpv(u"࠸఍")*TgAfXBWbo7
HTNv70wWuCxtU = V2RbfGOBdcA6l8NTsPWzEyvS7(u"࠹࠰ఎ")*TgAfXBWbo7
BZdvf7MIUxHQc3aCT = qbPw1d3KimF(u"࠱࠳ఏ")*bN2AKcC1yYJMjs
JeTgfEOCQS8mtloPc3dr1hxX = sRth5giAQzWlEVm7JOX(u"࠲ఐ")*p6l2Pum7aFtrhUHgXTE5w0n
Kczs71doMyLHwN = ehpURIi6QBDOGu8qj5EYzXrsWHJ7.argv[vvHpKfcqRnrFzjG(u"࠲఑")].split(BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠪ࠳ࠬ਽"))[hhlbF1Sns5TrEN8QPCYmL4(u"࠵ఒ")]
n6ReHNYovBwFxiuJ = int(ehpURIi6QBDOGu8qj5EYzXrsWHJ7.argv[vvHpKfcqRnrFzjG(u"࠵ఓ")])
SzGukeylg5Nsr9M20WIan = ehpURIi6QBDOGu8qj5EYzXrsWHJ7.argv[RqldvxFuM5GEQ2HAz93o7afBb0(u"࠷ఔ")]
TEAjR5GV06JxWMg = Kczs71doMyLHwN.split(LgpdP3UjFRnlX(u"ࠫ࠳࠭ਾ"))[YB5xyI7MaRslVpv(u"࠸క")]
RhVj0vAt5kPHm = tUXmK5PeEH9SDq.getInfoLabel(V2RbfGOBdcA6l8NTsPWzEyvS7(u"࡙ࠬࡹࡴࡶࡨࡱ࠳ࡇࡤࡥࡱࡱ࡚ࡪࡸࡳࡪࡱࡱࠬࠬਿ")+Kczs71doMyLHwN+UxS67uoGThbMwnfNRzy4gajLd23JH(u"࠭ࠩࠨੀ"))
IjYiO4u9HGmgw = XXRtDhYvWb35qnLBxIri7ScNUks0.path.join(yGlIC3Pjr42JBeikmV6Z1FapgYA,Kczs71doMyLHwN)
RnqtMUa9Nh6peGEsBT = XXRtDhYvWb35qnLBxIri7ScNUks0.path.join(IjYiO4u9HGmgw,BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠧ࡮ࡣ࡬ࡲࡩࡧࡴࡢ࠰ࡧࡦࠬੁ"))
Cjda4zr3pXghVKDR = XXRtDhYvWb35qnLBxIri7ScNUks0.path.join(IjYiO4u9HGmgw,jSu5Cg2Ub1OAkZVs8Yoz(u"ࠨ࡮ࡤࡷࡹࡼࡩࡥࡧࡲࡷ࠳ࡪࡡࡵࠩੂ"))
SGB7KzblUa4gCZD1srqc = int(KBxPW9cX8dqtaUDG.time())
bLEBi8IO7uU2x3htYDdVq95 = OGJ60aCqcw4EvUBbxDMHkIYN.Addon(id=Kczs71doMyLHwN)
def NgD0bJaq14yBnMYoziAmLj(qmr7vLh1EW,t0p7jNyWB8rLfEn9oJe1m3TvZ=C2dgEDAKQGsvh(u"ࠩࡂࠫ੃")):
	if l0WAe1f7Bpi5ZXk(u"ࠪࡁࠬ੄") in qmr7vLh1EW:
		if t0p7jNyWB8rLfEn9oJe1m3TvZ in qmr7vLh1EW: bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,suezhDPWfJiyFTcgRM9kr = qmr7vLh1EW.split(t0p7jNyWB8rLfEn9oJe1m3TvZ,nr5mZG89ICi6cgt4MfLJa0(u"࠱ఖ"))
		else: bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,suezhDPWfJiyFTcgRM9kr = NVS30xAdRFMIw1n9CislkE2(u"ࠫࠬ੅"),qmr7vLh1EW
		suezhDPWfJiyFTcgRM9kr = suezhDPWfJiyFTcgRM9kr.split(RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠬࠬࠧ੆"))
		toAVQS46Fv8aJYyLf25KnkUNC = {}
		for tuIVMwm60eg in suezhDPWfJiyFTcgRM9kr:
			bS0qeWcgmnV,NByYDKZRbSpV8UtXaEJl30z2 = tuIVMwm60eg.split(gItVahxL0w(u"࠭࠽ࠨੇ"),jSu5Cg2Ub1OAkZVs8Yoz(u"࠲గ"))
			toAVQS46Fv8aJYyLf25KnkUNC[bS0qeWcgmnV] = NByYDKZRbSpV8UtXaEJl30z2
	else: bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,toAVQS46Fv8aJYyLf25KnkUNC = qmr7vLh1EW,{}
	return bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,toAVQS46Fv8aJYyLf25KnkUNC
def XnQbsZF0Ouh8p7zCdUN(qmr7vLh1EW):
	return _VQzFIY8uqU3SE9(qmr7vLh1EW)
def cIa9Spry0oqE(EfJQnXyqBU4GI):
	f3ajgd6WT91ciYMJFvPLX8u4 = {T6wRistc1SCo4hqObgumK(u"ࠧࡵࡻࡳࡩࠬੈ"):nr5mZG89ICi6cgt4MfLJa0(u"ࠨࠩ੉"),b05yftsZ6NYgIKP(u"ࠩࡰࡳࡩ࡫ࠧ੊"):FGDJwkEbTB5SoXujs3f(u"ࠪࠫੋ"),v5EA6TqHX3s4jzBMk(u"ࠫࡺࡸ࡬ࠨੌ"):b05yftsZ6NYgIKP(u"੍ࠬ࠭"),hhlbF1Sns5TrEN8QPCYmL4(u"࠭ࡴࡦࡺࡷࠫ੎"):rbjsM8cRFiuA1(u"ࠧࠨ੏"),FGDJwkEbTB5SoXujs3f(u"ࠨࡲࡤ࡫ࡪ࠭੐"):BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠩࠪੑ"),nr5mZG89ICi6cgt4MfLJa0(u"ࠪࡲࡦࡳࡥࠨ੒"):vvHpKfcqRnrFzjG(u"ࠫࠬ੓"),C2jP0iLNGKnHu9xp(u"ࠬ࡯࡭ࡢࡩࡨࠫ੔"):b05yftsZ6NYgIKP(u"࠭ࠧ੕"),T6wRistc1SCo4hqObgumK(u"ࠧࡤࡱࡱࡸࡪࡾࡴࠨ੖"):qbPw1d3KimF(u"ࠨࠩ੗"),C2jP0iLNGKnHu9xp(u"ࠩ࡬ࡲ࡫ࡵࡤࡪࡥࡷࠫ੘"):sRth5giAQzWlEVm7JOX(u"ࠪࠫਖ਼")}
	if C2dgEDAKQGsvh(u"ࠫࡄ࠭ਗ਼") in EfJQnXyqBU4GI: EfJQnXyqBU4GI = EfJQnXyqBU4GI.split(UnWjVbo503mEMv9KF(u"ࠬࡅࠧਜ਼"),jSu5Cg2Ub1OAkZVs8Yoz(u"࠳ఘ"))[jSu5Cg2Ub1OAkZVs8Yoz(u"࠳ఘ")]
	bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,CFrdhtGku52LAIQl4Siz3OWE = NgD0bJaq14yBnMYoziAmLj(EfJQnXyqBU4GI)
	aargs = dict(list(f3ajgd6WT91ciYMJFvPLX8u4.items())+list(CFrdhtGku52LAIQl4Siz3OWE.items()))
	meQp9gRv2XEwlZIJ6hnjx14 = aargs[WMkAjB1RgN7q(u"࠭࡭ࡰࡦࡨࠫੜ")]
	FrwM7qSAvnPOoEkUYKBZI = XnQbsZF0Ouh8p7zCdUN(aargs[QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠧࡶࡴ࡯ࠫ੝")])
	TZuiArS8UjVkW5Yol = XnQbsZF0Ouh8p7zCdUN(aargs[b05yftsZ6NYgIKP(u"ࠨࡶࡨࡼࡹ࠭ਫ਼")])
	WMGuOVe86zTqa4inIY2Q = XnQbsZF0Ouh8p7zCdUN(aargs[v5EA6TqHX3s4jzBMk(u"ࠩࡳࡥ࡬࡫ࠧ੟")])
	lveMNOXYtUdkhLP6AQ = XnQbsZF0Ouh8p7zCdUN(aargs[hhlbF1Sns5TrEN8QPCYmL4(u"ࠪࡸࡾࡶࡥࠨ੠")])
	SXmIKu9NvQ7xrJbAD13T = XnQbsZF0Ouh8p7zCdUN(aargs[sRth5giAQzWlEVm7JOX(u"ࠫࡳࡧ࡭ࡦࠩ੡")])
	WrXzD4kdcPJvuwTgyFNoUS5bBVm = XnQbsZF0Ouh8p7zCdUN(aargs[LgpdP3UjFRnlX(u"ࠬ࡯࡭ࡢࡩࡨࠫ੢")])
	O6KChzkWMQD4xZE1X = aargs[T6wRistc1SCo4hqObgumK(u"࠭ࡣࡰࡰࡷࡩࡽࡺࠧ੣")]
	aiJjUnC0te6WgIXBclN2FEmvpf5PV = XnQbsZF0Ouh8p7zCdUN(aargs[V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠧࡪࡰࡩࡳࡩ࡯ࡣࡵࠩ੤")])
	if aiJjUnC0te6WgIXBclN2FEmvpf5PV: aiJjUnC0te6WgIXBclN2FEmvpf5PV = eval(aiJjUnC0te6WgIXBclN2FEmvpf5PV)
	else: aiJjUnC0te6WgIXBclN2FEmvpf5PV = {}
	if not meQp9gRv2XEwlZIJ6hnjx14: lveMNOXYtUdkhLP6AQ = hhlbF1Sns5TrEN8QPCYmL4(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ੥") ; meQp9gRv2XEwlZIJ6hnjx14 = vvHpKfcqRnrFzjG(u"ࠩ࠵࠺࠵࠭੦")
	return lveMNOXYtUdkhLP6AQ,SXmIKu9NvQ7xrJbAD13T,FrwM7qSAvnPOoEkUYKBZI,meQp9gRv2XEwlZIJ6hnjx14,WrXzD4kdcPJvuwTgyFNoUS5bBVm,WMGuOVe86zTqa4inIY2Q,TZuiArS8UjVkW5Yol,O6KChzkWMQD4xZE1X,aiJjUnC0te6WgIXBclN2FEmvpf5PV
def Dwl0N6FKuVU8nB1mbisIrCzdO(baNWS6nfqTC5iX4Kl):
	RyuGVnJS0xFXQjh4i9WYIOrBeH7Kql = ehpURIi6QBDOGu8qj5EYzXrsWHJ7._getframe(PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"࠴ఙ")).f_code.co_name
	if not baNWS6nfqTC5iX4Kl or not RyuGVnJS0xFXQjh4i9WYIOrBeH7Kql or RyuGVnJS0xFXQjh4i9WYIOrBeH7Kql==sRth5giAQzWlEVm7JOX(u"ࠪࡀࡲࡵࡤࡶ࡮ࡨࡂࠬ੧"):
		return UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠫࡠࠦࠧ੨")+TEAjR5GV06JxWMg.upper()+b05yftsZ6NYgIKP(u"ࠬ࠳ࠧ੩")+RhVj0vAt5kPHm+UxS67uoGThbMwnfNRzy4gajLd23JH(u"࠭࠭ࠨ੪")+str(YSomBdvcNUMF3b8JDiCfrVW)+BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠧࠡ࡟ࠪ੫")
	return LgpdP3UjFRnlX(u"ࠨ࠰ࠣࠤࠬ੬")+RyuGVnJS0xFXQjh4i9WYIOrBeH7Kql
def Lmj1pfQk63XdoeH(e3ygDGtXjSIZoVqTxEbuUOlw2f,mKBurDQaSIn1Aydsc9LvbF5EZf):
	if V8fmEML1b0PeaRZySnzh3H5J9: mKBurDQaSIn1Aydsc9LvbF5EZf = mKBurDQaSIn1Aydsc9LvbF5EZf.decode(LgpdP3UjFRnlX(u"ࠩࡸࡸ࡫࠾ࠧ੭")).encode(LgpdP3UjFRnlX(u"ࠪࡹࡹ࡬࠸ࠨ੮"))
	coUGrVKyqOJHAnPE = cNzmj3fQZGvBo7hd8ACH
	p1GZLhkOD64IX = [b05yftsZ6NYgIKP(u"ࠫࠬ੯"),jx7s8T0BFgODXLMzIYedf(u"ࠬ࠭ੰ")]
	if e3ygDGtXjSIZoVqTxEbuUOlw2f: mKBurDQaSIn1Aydsc9LvbF5EZf = mKBurDQaSIn1Aydsc9LvbF5EZf.replace(C2jP0iLNGKnHu9xp(u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩੱ"),NVS30xAdRFMIw1n9CislkE2(u"ࠧࠨੲ")).replace(YB5xyI7MaRslVpv(u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫੳ"),NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠩࠪੴ")).replace(NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬੵ"),gItVahxL0w(u"ࠫࠬ੶"))
	else: e3ygDGtXjSIZoVqTxEbuUOlw2f = vvHpKfcqRnrFzjG(u"ࠬࡔࡏࡕࡋࡆࡉࠬ੷")
	eKA03NCFH5aS1W,t0p7jNyWB8rLfEn9oJe1m3TvZ,hbd4AitlZpgYF1 = fY5wTlhtnOc0Er6sdy4k87b(u"࠭ࠠࠡࠢࠣࠫ੸"),WMkAjB1RgN7q(u"ࠧࠡࠢࠣࠫ੹"),jSu5Cg2Ub1OAkZVs8Yoz(u"ࠨࠩ੺")
	if EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠩࡈࡖࡗࡕࡒࠨ੻") in e3ygDGtXjSIZoVqTxEbuUOlw2f: coUGrVKyqOJHAnPE = tUXmK5PeEH9SDq.LOGERROR
	if e3ygDGtXjSIZoVqTxEbuUOlw2f==BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨ੼"):
		mKBurDQaSIn1Aydsc9LvbF5EZf = mKBurDQaSIn1Aydsc9LvbF5EZf+t0p7jNyWB8rLfEn9oJe1m3TvZ
		p1GZLhkOD64IX = mKBurDQaSIn1Aydsc9LvbF5EZf.split(t0p7jNyWB8rLfEn9oJe1m3TvZ)
		hbd4AitlZpgYF1 = eKA03NCFH5aS1W
	elif e3ygDGtXjSIZoVqTxEbuUOlw2f==nr5mZG89ICi6cgt4MfLJa0(u"ࠫࡓࡕࡔࡊࡅࡈࡣࡑࡏࡎࡆࡕࠪ੽"):
		mKBurDQaSIn1Aydsc9LvbF5EZf = mKBurDQaSIn1Aydsc9LvbF5EZf.replace(WMkAjB1RgN7q(u"ࠬ࠴ࠧ੾")+t0p7jNyWB8rLfEn9oJe1m3TvZ,BoWHNb9daQVCF16A(u"࠭࠮ࠡࠢࠪ੿"))
		p1GZLhkOD64IX = mKBurDQaSIn1Aydsc9LvbF5EZf.split(t0p7jNyWB8rLfEn9oJe1m3TvZ)
		p1GZLhkOD64IX[V2RbfGOBdcA6l8NTsPWzEyvS7(u"࠵ఛ")] = vvHpKfcqRnrFzjG(u"ࠧ࠯ࠩ઀")+p1GZLhkOD64IX[V2RbfGOBdcA6l8NTsPWzEyvS7(u"࠵ఛ")][EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠵చ"):]
		hbd4AitlZpgYF1 = eKA03NCFH5aS1W+t0p7jNyWB8rLfEn9oJe1m3TvZ
	elif e3ygDGtXjSIZoVqTxEbuUOlw2f in [l0WAe1f7Bpi5ZXk(u"ࠨࡐࡒࡘࡎࡉࡅࠨઁ"),vvHpKfcqRnrFzjG(u"ࠩࡈࡖࡗࡕࡒࠨં")]: p1GZLhkOD64IX = mKBurDQaSIn1Aydsc9LvbF5EZf.split(eKA03NCFH5aS1W)
	hbd4AitlZpgYF1 += C2dgEDAKQGsvh(u"࠼జ")*eKA03NCFH5aS1W
	UtM0wb254JFyZgN9nE7 = V2RbfGOBdcA6l8NTsPWzEyvS7(u"࠳ఝ")*eKA03NCFH5aS1W
	if YSomBdvcNUMF3b8JDiCfrVW>fY5wTlhtnOc0Er6sdy4k87b(u"࠳࠺࠲࠾࠿ట"): hbd4AitlZpgYF1 += hhlbF1Sns5TrEN8QPCYmL4(u"࠲࠳ఞ")*l0WAe1f7Bpi5ZXk(u"ࠪࠤࠬઃ")
	ZZqJH6Q8XyzBC2KILAOSwrEYUho = p1GZLhkOD64IX[YB5xyI7MaRslVpv(u"࠳ఠ")]
	for KkP7tcharOiu2ydX4RvgjTw in p1GZLhkOD64IX[sRth5giAQzWlEVm7JOX(u"࠵డ"):]:
		if BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠫࡡࡴࠧ઄") in KkP7tcharOiu2ydX4RvgjTw: KkP7tcharOiu2ydX4RvgjTw = KkP7tcharOiu2ydX4RvgjTw.replace(BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠬࡢ࡮ࠨઅ"),jx7s8T0BFgODXLMzIYedf(u"࠭࡜࡯ࠩઆ")+eKA03NCFH5aS1W+eKA03NCFH5aS1W)
		UtM0wb254JFyZgN9nE7 += eKA03NCFH5aS1W
		ZZqJH6Q8XyzBC2KILAOSwrEYUho += C2jP0iLNGKnHu9xp(u"ࠧ࡝ࡴࠪઇ")+hbd4AitlZpgYF1+UtM0wb254JFyZgN9nE7+KkP7tcharOiu2ydX4RvgjTw
	ZZqJH6Q8XyzBC2KILAOSwrEYUho += FGDJwkEbTB5SoXujs3f(u"ࠨࠢࡢࠫઈ")
	if BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠩࠨࠫઉ") in ZZqJH6Q8XyzBC2KILAOSwrEYUho: ZZqJH6Q8XyzBC2KILAOSwrEYUho = XnQbsZF0Ouh8p7zCdUN(ZZqJH6Q8XyzBC2KILAOSwrEYUho)
	tUXmK5PeEH9SDq.log(ZZqJH6Q8XyzBC2KILAOSwrEYUho,level=coUGrVKyqOJHAnPE)
	return
def syJIkO4GZvPcSl(GTYRu9hVKZoHOyUt4w2ilpLqA):
	W9YiR1FGTdzO3jByXPA70D = LLuOT2NGmXvS4C1WRyod8sQtIhV70a.connect(GTYRu9hVKZoHOyUt4w2ilpLqA)
	CCJpwYUsTN1cBIz5PH = W9YiR1FGTdzO3jByXPA70D.cursor()
	CCJpwYUsTN1cBIz5PH.execute(C2dgEDAKQGsvh(u"ࠪࡔࡗࡇࡇࡎࡃࠣࡥࡺࡺ࡯࡮ࡣࡷ࡭ࡨࡥࡩ࡯ࡦࡨࡼࡂࡴ࡯࠼ࠩઊ"))
	CCJpwYUsTN1cBIz5PH.execute(fY5wTlhtnOc0Er6sdy4k87b(u"ࠫࡕࡘࡁࡈࡏࡄࠤ࡫ࡵࡲࡦ࡫ࡪࡲࡤࡱࡥࡺࡵࡀࡲࡴࡁࠧઋ"))
	CCJpwYUsTN1cBIz5PH.execute(EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠬࡖࡒࡂࡉࡐࡅࠥ࡯ࡧ࡯ࡱࡵࡩࡤࡩࡨࡦࡥ࡮ࡣࡨࡵ࡮ࡴࡶࡵࡥ࡮ࡴࡴࡴ࠿ࡼࡩࡸࡁࠧઌ"))
	CCJpwYUsTN1cBIz5PH.execute(v5EA6TqHX3s4jzBMk(u"࠭ࡐࡓࡃࡊࡑࡆࠦࡪࡰࡷࡵࡲࡦࡲ࡟࡮ࡱࡧࡩࡂࡕࡆࡇ࠽ࠪઍ"))
	CCJpwYUsTN1cBIz5PH.execute(qbPw1d3KimF(u"ࠧࡑࡔࡄࡋࡒࡇࠠࡵࡧࡰࡴࡤࡹࡴࡰࡴࡨࡁࡒࡋࡍࡐࡔ࡜࠿ࠬ઎"))
	CCJpwYUsTN1cBIz5PH.execute(V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠨࡒࡕࡅࡌࡓࡁࠡࡵࡼࡲࡨ࡮ࡲࡰࡰࡲࡹࡸࡃࡏࡇࡈ࠾ࠫએ"))
	W9YiR1FGTdzO3jByXPA70D.text_factory = str
	return W9YiR1FGTdzO3jByXPA70D,CCJpwYUsTN1cBIz5PH
def qkSCcaj2fg4VO7dl3G9IhJBs5DLx(GTYRu9hVKZoHOyUt4w2ilpLqA,g9Pmj2VpAznvZQFGH5O,a1LKjn02CPXht9VcvElgfeboFTm=None):
	try: W9YiR1FGTdzO3jByXPA70D,CCJpwYUsTN1cBIz5PH = syJIkO4GZvPcSl(GTYRu9hVKZoHOyUt4w2ilpLqA)
	except: return
	if a1LKjn02CPXht9VcvElgfeboFTm==None: CCJpwYUsTN1cBIz5PH.execute(EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠩࡇࡖࡔࡖࠠࡕࡃࡅࡐࡊࠦࡉࡇࠢࡈ࡜ࡎ࡙ࡔࡔࠢࠥࠫઐ")+g9Pmj2VpAznvZQFGH5O+UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠪࠦࠥࡁࠧઑ"))
	else:
		uCf5OH3DhwXknNQrqbT8t1JIip = (str(a1LKjn02CPXht9VcvElgfeboFTm),)
		try:
			if l0WAe1f7Bpi5ZXk(u"ࠫࠪ࠭઒") in a1LKjn02CPXht9VcvElgfeboFTm: CCJpwYUsTN1cBIz5PH.execute(T6wRistc1SCo4hqObgumK(u"ࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࠦࠬઓ")+g9Pmj2VpAznvZQFGH5O+BoWHNb9daQVCF16A(u"࡙࠭ࠢࠡࡋࡉࡗࡋࠠࡤࡱ࡯ࡹࡲࡴࠠ࡭࡫࡮ࡩࠥࡅࠠ࠼ࠩઔ"),uCf5OH3DhwXknNQrqbT8t1JIip)
			else: CCJpwYUsTN1cBIz5PH.execute(C2dgEDAKQGsvh(u"ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥࠨࠧક")+g9Pmj2VpAznvZQFGH5O+YB5xyI7MaRslVpv(u"ࠨࠤ࡛ࠣࡍࡋࡒࡆࠢࡦࡳࡱࡻ࡭࡯ࠢࡀࠤࡄࠦ࠻ࠨખ"),uCf5OH3DhwXknNQrqbT8t1JIip)
		except: pass
	W9YiR1FGTdzO3jByXPA70D.commit()
	W9YiR1FGTdzO3jByXPA70D.close()
	return
class Sdy6aU0utYrxJjQLbDM9KNRAckhvT(): pass
class U5uGTZvbxOmKaDspiCLcg(Sdy6aU0utYrxJjQLbDM9KNRAckhvT):
	def __init__(LtRNhYpbuV5lzG7):
		LtRNhYpbuV5lzG7.url = BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠩࠪગ")
		LtRNhYpbuV5lzG7.code = -LgpdP3UjFRnlX(u"࠾࠿ఢ")
		LtRNhYpbuV5lzG7.reason = C2dgEDAKQGsvh(u"ࠪࠫઘ")
		LtRNhYpbuV5lzG7.content = UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠫࠬઙ")
		LtRNhYpbuV5lzG7.headers = {}
		LtRNhYpbuV5lzG7.cookies = {}
		LtRNhYpbuV5lzG7.succeeded = LgpdP3UjFRnlX(u"ࡆࡢ࡮ࡶࡩ౪")
def mN9XAls0LP32WQJhdDnT1jBgkUu(EAdbsmyiqLtjhPlxG):
	if EAdbsmyiqLtjhPlxG==YB5xyI7MaRslVpv(u"ࠬࡪࡩࡤࡶࠪચ"): AqLgT4S6FExHi1kZ5smy7a0hRX = {}
	elif EAdbsmyiqLtjhPlxG==FGDJwkEbTB5SoXujs3f(u"࠭࡬ࡪࡵࡷࠫછ"): AqLgT4S6FExHi1kZ5smy7a0hRX = []
	elif EAdbsmyiqLtjhPlxG==T6wRistc1SCo4hqObgumK(u"ࠧࡴࡶࡵࠫજ"): AqLgT4S6FExHi1kZ5smy7a0hRX = LgpdP3UjFRnlX(u"ࠨࠩઝ")
	elif EAdbsmyiqLtjhPlxG==jSu5Cg2Ub1OAkZVs8Yoz(u"ࠩ࡬ࡲࡹ࠭ઞ"): AqLgT4S6FExHi1kZ5smy7a0hRX = FGDJwkEbTB5SoXujs3f(u"࠶ణ")
	elif EAdbsmyiqLtjhPlxG==jx7s8T0BFgODXLMzIYedf(u"ࠪࡶࡪࡹࡰࡰࡰࡶࡩࠬટ"): AqLgT4S6FExHi1kZ5smy7a0hRX = U5uGTZvbxOmKaDspiCLcg()
	elif not EAdbsmyiqLtjhPlxG: AqLgT4S6FExHi1kZ5smy7a0hRX = None
	else: AqLgT4S6FExHi1kZ5smy7a0hRX = None
	return AqLgT4S6FExHi1kZ5smy7a0hRX
def jjwPCAGBnWFIl2L0(oJirYQlPaHEzZmX):
	from hashlib import md5 as UPTJpd3eoxqc6DgQ8X5bCu2IARm
	p4s7crBFSY = bLEBi8IO7uU2x3htYDdVq95.getSetting(FGDJwkEbTB5SoXujs3f(u"ࠫࡦࡼ࠮ࡱࡴ࡬ࡺࡸ࠷ࠧઠ"))
	PPnk8u9bCc = hvc2sXOB31KTLgiZaQUR9xuGjloYS(NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠳࠳త")).splitlines()
	bbDTzJLcM4Z0 = vvHpKfcqRnrFzjG(u"࠱థ")
	for BNtJhszborkDPj8GXge in [SGB7KzblUa4gCZD1srqc,SGB7KzblUa4gCZD1srqc-f9Oum6c0FotxYn]:
		k8Icog2BMGbdfZLq1Jn6H7SvOzR9 = str(BNtJhszborkDPj8GXge*BoWHNb9daQVCF16A(u"࠵࠵࠶࠰࠱࠲࠱࠴న")/V2RbfGOBdcA6l8NTsPWzEyvS7(u"࠷࠷࠷࠶࠰࠱ధ"))[vvHpKfcqRnrFzjG(u"࠲ద"):gItVahxL0w(u"࠹఩")]
		if k8Icog2BMGbdfZLq1Jn6H7SvOzR9!=bbDTzJLcM4Z0:
			for IL9HcN80i3CJEW6QtSMvUlAXsp in PPnk8u9bCc:
				uST0zONoGKn6m9y = FGDJwkEbTB5SoXujs3f(u"ࠬ࡞࠱࠺ࠩડ")+oJirYQlPaHEzZmX+QynMHGWA0blfqTUdxRh5Jzi2t(u"࠭࠱࠹࠿ࠪઢ")+IL9HcN80i3CJEW6QtSMvUlAXsp[-FGDJwkEbTB5SoXujs3f(u"࠸࠴ప"):]+RhVj0vAt5kPHm+k8Icog2BMGbdfZLq1Jn6H7SvOzR9
				uST0zONoGKn6m9y = UPTJpd3eoxqc6DgQ8X5bCu2IARm(uST0zONoGKn6m9y.encode(C2jP0iLNGKnHu9xp(u"ࠧࡶࡶࡩ࠼ࠬણ"))).hexdigest()[:QynMHGWA0blfqTUdxRh5Jzi2t(u"࠳࠳ఫ")]
				if uST0zONoGKn6m9y in p4s7crBFSY: return WMkAjB1RgN7q(u"ࡕࡴࡸࡩ౫")
			bbDTzJLcM4Z0 = k8Icog2BMGbdfZLq1Jn6H7SvOzR9
	return rbjsM8cRFiuA1(u"ࡈࡤࡰࡸ࡫౬")
def zPgNsqpJInt(GTYRu9hVKZoHOyUt4w2ilpLqA,plWqMa0QgKcbR5n8L1GVozyek3,g9Pmj2VpAznvZQFGH5O,a1LKjn02CPXht9VcvElgfeboFTm=None):
	AqLgT4S6FExHi1kZ5smy7a0hRX = mN9XAls0LP32WQJhdDnT1jBgkUu(plWqMa0QgKcbR5n8L1GVozyek3)
	f0KUlmeMpWgFsPk16On = bLEBi8IO7uU2x3htYDdVq95.getSetting(NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲࡭ࡺࡴࡱࡥࡤࡧ࡭࡫ࠧત"))
	if g9Pmj2VpAznvZQFGH5O!=UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬથ") and GTYRu9hVKZoHOyUt4w2ilpLqA==RnqtMUa9Nh6peGEsBT:
		if f0KUlmeMpWgFsPk16On==C2dgEDAKQGsvh(u"ࠪࡗ࡙ࡕࡐࠨદ"): return AqLgT4S6FExHi1kZ5smy7a0hRX
		zJwPBdKbhsfqD5vX = bLEBi8IO7uU2x3htYDdVq95.getSetting(NVS30xAdRFMIw1n9CislkE2(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡳࡧࡩࡶࡪࡹࡨࠨધ"))
		if zJwPBdKbhsfqD5vX==QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠬࡘࡅࡇࡔࡈࡗࡍࡋࡄࠨન"):
			qkSCcaj2fg4VO7dl3G9IhJBs5DLx(GTYRu9hVKZoHOyUt4w2ilpLqA,g9Pmj2VpAznvZQFGH5O,a1LKjn02CPXht9VcvElgfeboFTm)
			return AqLgT4S6FExHi1kZ5smy7a0hRX
	tV6zXgjH7IYmZ9sbO = WMkAjB1RgN7q(u"࠱బ")
	if f0KUlmeMpWgFsPk16On==UxS67uoGThbMwnfNRzy4gajLd23JH(u"࠭ࡌࡊࡏࡌࡘࡊࡊࠧ઩"): tV6zXgjH7IYmZ9sbO = JeTgfEOCQS8mtloPc3dr1hxX
	try: W9YiR1FGTdzO3jByXPA70D,CCJpwYUsTN1cBIz5PH = syJIkO4GZvPcSl(GTYRu9hVKZoHOyUt4w2ilpLqA)
	except: return AqLgT4S6FExHi1kZ5smy7a0hRX
	i9ieLC7woU1RXpaxVDA0 = T6wRistc1SCo4hqObgumK(u"ࡗࡶࡺ࡫౭")
	try: CCJpwYUsTN1cBIz5PH.execute(FGDJwkEbTB5SoXujs3f(u"ࠧࡔࡇࡏࡉࡈ࡚ࠠࠫࠢࡉࡖࡔࡓࠠࠣࠩપ")+g9Pmj2VpAznvZQFGH5O+v5EA6TqHX3s4jzBMk(u"ࠨࠤࠣࡐࡎࡓࡉࡕࠢ࠴ࠤࡀ࠭ફ"))
	except: i9ieLC7woU1RXpaxVDA0 = rbjsM8cRFiuA1(u"ࡊࡦࡲࡳࡦ౮")
	if i9ieLC7woU1RXpaxVDA0:
		if tV6zXgjH7IYmZ9sbO: CCJpwYUsTN1cBIz5PH.execute(T6wRistc1SCo4hqObgumK(u"ࠩࡇࡉࡑࡋࡔࡆࠢࡉࡖࡔࡓࠠࠣࠩબ")+g9Pmj2VpAznvZQFGH5O+BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠪࠦࠥ࡝ࡈࡆࡔࡈࠤࡪࡾࡰࡪࡴࡼࡂࠬભ")+str(SGB7KzblUa4gCZD1srqc+tV6zXgjH7IYmZ9sbO)+jx7s8T0BFgODXLMzIYedf(u"ࠫࠥࡁࠧમ"))
		W9YiR1FGTdzO3jByXPA70D.commit()
		CCJpwYUsTN1cBIz5PH.execute(sRth5giAQzWlEVm7JOX(u"ࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࠦࠬય")+g9Pmj2VpAznvZQFGH5O+EAc8h2sINroQYvR3WH06Ji7MVpn(u"࡙࠭ࠢࠡࡋࡉࡗࡋࠠࡦࡺࡳ࡭ࡷࡿ࠼ࠨર")+str(SGB7KzblUa4gCZD1srqc)+v5EA6TqHX3s4jzBMk(u"ࠧࠡ࠽ࠪ઱"))
		W9YiR1FGTdzO3jByXPA70D.commit()
		if a1LKjn02CPXht9VcvElgfeboFTm:
			uCf5OH3DhwXknNQrqbT8t1JIip = (str(a1LKjn02CPXht9VcvElgfeboFTm),)
			CCJpwYUsTN1cBIz5PH.execute(RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠨࡕࡈࡐࡊࡉࡔࠡࡦࡤࡸࡦࠦࡆࡓࡑࡐࠤࠧ࠭લ")+g9Pmj2VpAznvZQFGH5O+NVS30xAdRFMIw1n9CislkE2(u"ࠩࠥࠤ࡜ࡎࡅࡓࡇࠣࡧࡴࡲࡵ࡮ࡰࠣࡁࠥࡅࠠ࠼ࠩળ"),uCf5OH3DhwXknNQrqbT8t1JIip)
			lKSnCUAjhE = CCJpwYUsTN1cBIz5PH.fetchall()
			if lKSnCUAjhE:
				try:
					QHDcUO2xtS4CmF = DDeKqnGoBpLH1d6civ8JgN4V.decompress(lKSnCUAjhE[qbPw1d3KimF(u"࠲భ")][qbPw1d3KimF(u"࠲భ")])
					AqLgT4S6FExHi1kZ5smy7a0hRX = XpRd3moWCYIQLDn51FS.loads(QHDcUO2xtS4CmF)
				except: pass
		else:
			CCJpwYUsTN1cBIz5PH.execute(qbPw1d3KimF(u"ࠪࡗࡊࡒࡅࡄࡖࠣࡧࡴࡲࡵ࡮ࡰ࠯ࡨࡦࡺࡡࠡࡈࡕࡓࡒࠦࠢࠨ઴")+g9Pmj2VpAznvZQFGH5O+NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠫࠧࠦ࠻ࠨવ"))
			lKSnCUAjhE = CCJpwYUsTN1cBIz5PH.fetchall()
			if lKSnCUAjhE:
				AqLgT4S6FExHi1kZ5smy7a0hRX,eQYbyhTWijwExkN52LDmaUpgt = {},[]
				for RndBcuA5l986ZDsTbh3if,toAVQS46Fv8aJYyLf25KnkUNC in lKSnCUAjhE:
					ty842nqSiZglc6GoEPdTMAjLvRBOxm = DDeKqnGoBpLH1d6civ8JgN4V.decompress(toAVQS46Fv8aJYyLf25KnkUNC)
					toAVQS46Fv8aJYyLf25KnkUNC = XpRd3moWCYIQLDn51FS.loads(ty842nqSiZglc6GoEPdTMAjLvRBOxm)
					AqLgT4S6FExHi1kZ5smy7a0hRX[RndBcuA5l986ZDsTbh3if] = toAVQS46Fv8aJYyLf25KnkUNC
					eQYbyhTWijwExkN52LDmaUpgt.append(RndBcuA5l986ZDsTbh3if)
				if eQYbyhTWijwExkN52LDmaUpgt:
					AqLgT4S6FExHi1kZ5smy7a0hRX[T6wRistc1SCo4hqObgumK(u"ࠬࡥ࡟ࡔࡇࡔ࡙ࡊࡔࡃࡆࡆࡢࡇࡔࡒࡕࡎࡐࡖࡣࡤ࠭શ")] = eQYbyhTWijwExkN52LDmaUpgt
					if plWqMa0QgKcbR5n8L1GVozyek3==T6wRistc1SCo4hqObgumK(u"࠭࡬ࡪࡵࡷࠫષ"): AqLgT4S6FExHi1kZ5smy7a0hRX = eQYbyhTWijwExkN52LDmaUpgt
	W9YiR1FGTdzO3jByXPA70D.close()
	return AqLgT4S6FExHi1kZ5smy7a0hRX
class b4OhDw65jdr7XiPq(J9hVSHKexDN):
	def __init__(LtRNhYpbuV5lzG7): pass
	def FF038EQdJXixAZGUjmHPt(LtRNhYpbuV5lzG7,BlgEahu7f5yptCFwdW):
		LtRNhYpbuV5lzG7.kduPflYAphRKrzcnjOm7agDT139 = jjwPCAGBnWFIl2L0(b05yftsZ6NYgIKP(u"ࠧࡄࡖࡈ࠽ࡉ࡙࠱࠺ࡘࡘ࠴࡛࡙ࡘࠨસ"))
		LtRNhYpbuV5lzG7.JlXzHEZ1jx98wNFr0MsY6mAKe = jjwPCAGBnWFIl2L0(YB5xyI7MaRslVpv(u"ࠨ࡙ࡖ࡙ࡗࡌࡔ࠲࠻ࡔࡘࡊࡌ࡚࡙ࠩહ"))
		LtRNhYpbuV5lzG7.Rt0SXBrIAF2sb3zfixLcCHPa5We = jjwPCAGBnWFIl2L0(rbjsM8cRFiuA1(u"ࠩࡅࡘࡊࡾࡐࡗ࠳࠼࡙ࡗ࡜ࡎࡖࡕࡘ࠹ࡍ࡞ࠧ઺"))
		LtRNhYpbuV5lzG7.zEYqUpKhFlw = sRth5giAQzWlEVm7JOX(u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠫ઻") if LtRNhYpbuV5lzG7.kduPflYAphRKrzcnjOm7agDT139 else V2RbfGOBdcA6l8NTsPWzEyvS7(u"઼ࠫࠬ")
		LtRNhYpbuV5lzG7.BlgEahu7f5yptCFwdW = BlgEahu7f5yptCFwdW
		if not LtRNhYpbuV5lzG7.JlXzHEZ1jx98wNFr0MsY6mAKe:
			from G6AHskJeqN import ZIF98f4SswHLDNOkVtqjCuop17Tz
			ZIF98f4SswHLDNOkVtqjCuop17Tz(c1lwnq73vkXsVjEhFpeoZtD)
	def onPlayBackStopped(LtRNhYpbuV5lzG7): LtRNhYpbuV5lzG7.zEYqUpKhFlw = qbPw1d3KimF(u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬઽ")
	def onPlayBackError(LtRNhYpbuV5lzG7): LtRNhYpbuV5lzG7.zEYqUpKhFlw = NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭ા")
	def onPlayBackEnded(LtRNhYpbuV5lzG7): LtRNhYpbuV5lzG7.zEYqUpKhFlw = fY5wTlhtnOc0Er6sdy4k87b(u"ࠧࡧࡣ࡬ࡰࡪࡪࠧિ")
	def onPlayBackStarted(LtRNhYpbuV5lzG7):
		LtRNhYpbuV5lzG7.zEYqUpKhFlw = l0WAe1f7Bpi5ZXk(u"ࠨࡵࡷࡥࡷࡺࡥࡥࠩી")
		yM8t7GThKSbHCpJN = iDocG6BXv7fT2z8UVOxgP.Thread(target=LtRNhYpbuV5lzG7.KxBjJeL4zpnG9crkCw5u6qAM7P,args=())
		yM8t7GThKSbHCpJN.start()
	def onAVStarted(LtRNhYpbuV5lzG7):
		if LtRNhYpbuV5lzG7.JlXzHEZ1jx98wNFr0MsY6mAKe: LtRNhYpbuV5lzG7.zEYqUpKhFlw = V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠩࡳࡰࡦࡿࡩ࡯ࡩࠪુ")
		else: LtRNhYpbuV5lzG7.zEYqUpKhFlw = BoWHNb9daQVCF16A(u"ࠪࡸࡪࡹࡴࡪࡰࡪࠫૂ")
	def KxBjJeL4zpnG9crkCw5u6qAM7P(LtRNhYpbuV5lzG7):
		from G6AHskJeqN import x5VP6sIEj8OFuv1Y3mtUMfB7qRlCXd,G8CFYarLe1,NZrI2wknju57PlJaDoRziLVm1
		NZrI2wknju57PlJaDoRziLVm1(PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠫࡸࡺ࡯ࡱࠩૃ"))
		XLJ1ewbEKqOnyM = LgpdP3UjFRnlX(u"࠳మ")
		while not eval(PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠬࡾࡢ࡮ࡥ࠱ࡔࡱࡧࡹࡦࡴࠫ࠭࠳࡯ࡳࡑ࡮ࡤࡽ࡮ࡴࡧࡗ࡫ࡧࡩࡴ࠮ࠩࠨૄ"),{T6wRistc1SCo4hqObgumK(u"࠭ࡸࡣ࡯ࡦࠫૅ"):tUXmK5PeEH9SDq}) and LtRNhYpbuV5lzG7.zEYqUpKhFlw==C2jP0iLNGKnHu9xp(u"ࠧࡴࡶࡤࡶࡹ࡫ࡤࠨ૆"):
			tUXmK5PeEH9SDq.sleep(C2dgEDAKQGsvh(u"࠵࠵࠶࠰య"))
			XLJ1ewbEKqOnyM += sRth5giAQzWlEVm7JOX(u"࠶ర")
			if XLJ1ewbEKqOnyM>hhlbF1Sns5TrEN8QPCYmL4(u"࠼࠰ఱ"): return
		if LtRNhYpbuV5lzG7.kduPflYAphRKrzcnjOm7agDT139: LtRNhYpbuV5lzG7.zEYqUpKhFlw = NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠨࡤ࡯ࡳࡨࡱࡥࡥࠩે")
		elif LtRNhYpbuV5lzG7.JlXzHEZ1jx98wNFr0MsY6mAKe: LtRNhYpbuV5lzG7.zEYqUpKhFlw = k5dztomYyN3H(u"ࠩࡳࡰࡦࡿࡩ࡯ࡩࠪૈ")
		elif LtRNhYpbuV5lzG7.Rt0SXBrIAF2sb3zfixLcCHPa5We:
			LtRNhYpbuV5lzG7.zEYqUpKhFlw = jx7s8T0BFgODXLMzIYedf(u"ࠪࡸࡪࡹࡴࡪࡰࡪࠫૉ")
			DOjUSRIxeiF1KCQz = iDocG6BXv7fT2z8UVOxgP.Thread(target=x5VP6sIEj8OFuv1Y3mtUMfB7qRlCXd,args=(LtRNhYpbuV5lzG7.BlgEahu7f5yptCFwdW,))
			DOjUSRIxeiF1KCQz.start()
			lPsoKJc605YgUAhb4dBiperD8CtS = iDocG6BXv7fT2z8UVOxgP.Thread(target=G8CFYarLe1,args=())
			lPsoKJc605YgUAhb4dBiperD8CtS.start()
		else: LtRNhYpbuV5lzG7.zEYqUpKhFlw = T6wRistc1SCo4hqObgumK(u"ࠫࡧࡲ࡯ࡤ࡭ࡨࡨࠬ૊")
def QQhD5Cmw680kvPEBcarV():
	ddgBVAuzijxRM316,pqoZt0hKDTC73jU6MeWIl = fY5wTlhtnOc0Er6sdy4k87b(u"ࠬ࠭ો"),rbjsM8cRFiuA1(u"࠭ࠧૌ")
	xI9CNW0lESvmw = tUXmK5PeEH9SDq.getInfoLabel(jx7s8T0BFgODXLMzIYedf(u"ࠧࡔࡻࡶࡸࡪࡳ࠮ࡇࡴ࡬ࡩࡳࡪ࡬ࡺࡐࡤࡱࡪ્࠭"))
	try:
		PKJRLUx3nwOZBYE1V2Mpe7Sg9DfHFX = open(C2jP0iLNGKnHu9xp(u"ࠨ࠱ࡳࡶࡴࡩ࠯ࡤࡲࡸ࡭ࡳ࡬࡯ࠨ૎"),NVS30xAdRFMIw1n9CislkE2(u"ࠩࡵࡦࠬ૏")).read()
		if BLz7m2RkNrxXQwy1cGAp: PKJRLUx3nwOZBYE1V2Mpe7Sg9DfHFX = PKJRLUx3nwOZBYE1V2Mpe7Sg9DfHFX.decode(b05yftsZ6NYgIKP(u"ࠪࡹࡹ࡬࠸ࠨૐ"))
		ZZuJwaULIl8EP4Hc1yVFYWqK = My7Dwqvs6bfGNSIgX.findall(v5EA6TqHX3s4jzBMk(u"ࠫࡘ࡫ࡲࡪࡣ࡯࠲࠯ࡅ࠺ࠡࠪ࠱࠮ࡄ࠯ࠤࠨ૑"),PKJRLUx3nwOZBYE1V2Mpe7Sg9DfHFX,My7Dwqvs6bfGNSIgX.IGNORECASE)
		if ZZuJwaULIl8EP4Hc1yVFYWqK: ddgBVAuzijxRM316 = ZZuJwaULIl8EP4Hc1yVFYWqK[gItVahxL0w(u"࠰ల")]
	except: pass
	try:
		import subprocess as AWYxCeLTy0atb2pwV8XoEBkHv4d
		Ih7dgV1GOcKbe48HLixv05fpDwSzkE = AWYxCeLTy0atb2pwV8XoEBkHv4d.Popen(UnWjVbo503mEMv9KF(u"ࠬࡹࡴࡢࡶࠣ࠱ࡨ࡛ࠦࠢࠡࠧࠤࠧࠦ࠯ࡴࡶࡲࡶࡦ࡭ࡥ࠰ࡧࡰࡹࡱࡧࡴࡦࡦ࠲࠴ࠥࡁࠠࡴࡶࡤࡸࠥ࠳ࡣࠡࠤࠣࠩ࡜ࠦࠢࠡ࠱ࡹࡥࡷ࠵࡬ࡰࡩࠪ૒"),shell=sRth5giAQzWlEVm7JOX(u"࡙ࡸࡵࡦ౯"),stdin=AWYxCeLTy0atb2pwV8XoEBkHv4d.PIPE,stdout=AWYxCeLTy0atb2pwV8XoEBkHv4d.PIPE,stderr=AWYxCeLTy0atb2pwV8XoEBkHv4d.PIPE)
		VVljw6CSBvaQGN2g = Ih7dgV1GOcKbe48HLixv05fpDwSzkE.stdout.read()
		if VVljw6CSBvaQGN2g:
			if BLz7m2RkNrxXQwy1cGAp:
				VVljw6CSBvaQGN2g = VVljw6CSBvaQGN2g.decode(PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"࠭ࡵࡵࡨ࠻ࠫ૓"),b05yftsZ6NYgIKP(u"ࠧࡪࡩࡱࡳࡷ࡫ࠧ૔"))
			r9Tcz0p5XSj = My7Dwqvs6bfGNSIgX.findall(vvHpKfcqRnrFzjG(u"ࠨࠢࠫࡠࡩࢁ࠱࠱ࡿࠬࠤࠬ૕"),VVljw6CSBvaQGN2g,My7Dwqvs6bfGNSIgX.IGNORECASE)
			if r9Tcz0p5XSj: pqoZt0hKDTC73jU6MeWIl = min(r9Tcz0p5XSj)
	except: pass
	return xI9CNW0lESvmw,ddgBVAuzijxRM316,pqoZt0hKDTC73jU6MeWIl
def hvc2sXOB31KTLgiZaQUR9xuGjloYS(wwCFA0VjJa,YErXiIBtZav12wfxJMpeG=WMkAjB1RgN7q(u"࡚ࡲࡶࡧ౰")):
	BRdelEfUhzGownbsxFApqV7ZMgr = C2jP0iLNGKnHu9xp(u"ࡔࡳࡷࡨ౱")
	if YErXiIBtZav12wfxJMpeG:
		tDUvS9X7CrF1sOukTjNJw = zPgNsqpJInt(RnqtMUa9Nh6peGEsBT,qbPw1d3KimF(u"ࠩ࡯࡭ࡸࡺࠧ૖"),BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭૗"),rbjsM8cRFiuA1(u"ࠫࡘࡏࡔࡆࡕࡢࡇࡍࡋࡃࡌࠩ૘"))
		if tDUvS9X7CrF1sOukTjNJw:
			PPnk8u9bCc,C7jXxmIT2vRPr1kBEsiaMb3KLOngJ6,IJp7MglK6TBuQm4dqU3F,vFOsmh04fAz = tDUvS9X7CrF1sOukTjNJw
			BRdelEfUhzGownbsxFApqV7ZMgr = zPgNsqpJInt(RnqtMUa9Nh6peGEsBT,T6wRistc1SCo4hqObgumK(u"ࠬࡲࡩࡴࡶࠪ૙"),qbPw1d3KimF(u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩ૚"),b05yftsZ6NYgIKP(u"ࠧࡔࡋࡗࡉࡘࡥࡖࡆࡔࡌࡊ࡞࠭૛"))
			if BRdelEfUhzGownbsxFApqV7ZMgr: xI9CNW0lESvmw,ddgBVAuzijxRM316,pqoZt0hKDTC73jU6MeWIl = BRdelEfUhzGownbsxFApqV7ZMgr
			else: xI9CNW0lESvmw,ddgBVAuzijxRM316,pqoZt0hKDTC73jU6MeWIl = QQhD5Cmw680kvPEBcarV()
			if (C7jXxmIT2vRPr1kBEsiaMb3KLOngJ6,IJp7MglK6TBuQm4dqU3F,vFOsmh04fAz)==(xI9CNW0lESvmw,ddgBVAuzijxRM316,pqoZt0hKDTC73jU6MeWIl): return gItVahxL0w(u"ࠨ࡞ࡱࠫ૜").join(PPnk8u9bCc)
	if BRdelEfUhzGownbsxFApqV7ZMgr: xI9CNW0lESvmw,ddgBVAuzijxRM316,pqoZt0hKDTC73jU6MeWIl = QQhD5Cmw680kvPEBcarV()
	global NNUlZS5nw20Aua,F4FakM8IBcKysozT
	NNUlZS5nw20Aua,F4FakM8IBcKysozT,EFC6Zw3h2atrnc0qI = sRth5giAQzWlEVm7JOX(u"ࠩࠪ૝"),k5dztomYyN3H(u"ࠪࠫ૞"),YB5xyI7MaRslVpv(u"ࠫࠬ૟")
	wwCFA0VjJa = wwCFA0VjJa//b05yftsZ6NYgIKP(u"࠳ళ")
	iDocG6BXv7fT2z8UVOxgP.Thread(target=AFKwVobIO5kiPvceu26EgdCjnY).start()
	iDocG6BXv7fT2z8UVOxgP.Thread(target=DDMUyPQKeH7lZY8vAsdtgbVjnB).start()
	for k3Om08MCgqQao4n1 in range(hhlbF1Sns5TrEN8QPCYmL4(u"࠳࠳ఴ")):
		KBxPW9cX8dqtaUDG.sleep(WMkAjB1RgN7q(u"࠳࠲࠺వ"))
		if not EFC6Zw3h2atrnc0qI:
			try:
				u4CFiaIV15owUA = tUXmK5PeEH9SDq.getInfoLabel(jSu5Cg2Ub1OAkZVs8Yoz(u"ࠬࡔࡥࡵࡹࡲࡶࡰ࠴ࡍࡢࡥࡄࡨࡩࡸࡥࡴࡵࠪૠ"))
				if u4CFiaIV15owUA.count(BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠭࠺ࠨૡ"))==FGDJwkEbTB5SoXujs3f(u"࠺ష") and u4CFiaIV15owUA.count(BoWHNb9daQVCF16A(u"ࠧ࠱ࠩૢ"))<EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠽శ"):
					u4CFiaIV15owUA = u4CFiaIV15owUA.lower().replace(b05yftsZ6NYgIKP(u"ࠨ࠼ࠪૣ"),V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠩࠪ૤"))
					EFC6Zw3h2atrnc0qI = str(int(u4CFiaIV15owUA,RqldvxFuM5GEQ2HAz93o7afBb0(u"࠷࠶స")))
			except: pass
		if NNUlZS5nw20Aua and F4FakM8IBcKysozT and EFC6Zw3h2atrnc0qI: break
	CRV4yuYeNl3ZmLEcaT = [NNUlZS5nw20Aua,F4FakM8IBcKysozT,EFC6Zw3h2atrnc0qI,UnWjVbo503mEMv9KF(u"ࠪࠫ૥"),FGDJwkEbTB5SoXujs3f(u"ࠫࠬ૦"),YB5xyI7MaRslVpv(u"ࠬ࠶࠰࠲࠳࠵࠶࠸࠹࠴࠵࠷࠸࠺࠻࠽࠷ࠨ૧")]
	if ddgBVAuzijxRM316 or pqoZt0hKDTC73jU6MeWIl:
		from hashlib import md5 as UPTJpd3eoxqc6DgQ8X5bCu2IARm
		FFx3enDQ8kBKEL = [(NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠵఺"),ddgBVAuzijxRM316),(YB5xyI7MaRslVpv(u"࠵హ"),pqoZt0hKDTC73jU6MeWIl)]
		for bS0qeWcgmnV,NByYDKZRbSpV8UtXaEJl30z2 in FFx3enDQ8kBKEL:
			NByYDKZRbSpV8UtXaEJl30z2 = NByYDKZRbSpV8UtXaEJl30z2.strip(fY5wTlhtnOc0Er6sdy4k87b(u"࠭࠰ࠨ૨"))
			if NByYDKZRbSpV8UtXaEJl30z2:
				if BLz7m2RkNrxXQwy1cGAp: NByYDKZRbSpV8UtXaEJl30z2 = NByYDKZRbSpV8UtXaEJl30z2.encode(v5EA6TqHX3s4jzBMk(u"ࠧࡶࡶࡩ࠼ࠬ૩"))
				NByYDKZRbSpV8UtXaEJl30z2 = str(int(UPTJpd3eoxqc6DgQ8X5bCu2IARm(NByYDKZRbSpV8UtXaEJl30z2).hexdigest(),gItVahxL0w(u"࠵࠹఻")))
				C81LYHEyO2SWNjoPJXc9Gzi3FVa = [int(NByYDKZRbSpV8UtXaEJl30z2[CweoHxrj4Qip2u3S7GkR8:CweoHxrj4Qip2u3S7GkR8+l0WAe1f7Bpi5ZXk(u"࠵࠺ఽ")]) for CweoHxrj4Qip2u3S7GkR8 in range(len(NByYDKZRbSpV8UtXaEJl30z2)) if CweoHxrj4Qip2u3S7GkR8%l0WAe1f7Bpi5ZXk(u"࠵࠺ఽ")==nr5mZG89ICi6cgt4MfLJa0(u"࠳఼")]
				CRV4yuYeNl3ZmLEcaT[bS0qeWcgmnV-jSu5Cg2Ub1OAkZVs8Yoz(u"࠶ా")] = str(sum(C81LYHEyO2SWNjoPJXc9Gzi3FVa))
	PPnk8u9bCc,P3PnvmZ1iX7uSbsUg6 = [],EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࡇࡣ࡯ࡷࡪ౲")
	for erEgVKM2qCStTop3zRPXAOaF8Ji56 in range(len(CRV4yuYeNl3ZmLEcaT)):
		C81LYHEyO2SWNjoPJXc9Gzi3FVa = CRV4yuYeNl3ZmLEcaT[erEgVKM2qCStTop3zRPXAOaF8Ji56]
		if not C81LYHEyO2SWNjoPJXc9Gzi3FVa: continue
		if P3PnvmZ1iX7uSbsUg6 and C81LYHEyO2SWNjoPJXc9Gzi3FVa==CRV4yuYeNl3ZmLEcaT[-FGDJwkEbTB5SoXujs3f(u"࠷ి")]: continue
		P3PnvmZ1iX7uSbsUg6 = sRth5giAQzWlEVm7JOX(u"ࡖࡵࡹࡪ౳")
		C81LYHEyO2SWNjoPJXc9Gzi3FVa = RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠨ࠲ࠪ૪")*wwCFA0VjJa+C81LYHEyO2SWNjoPJXc9Gzi3FVa
		C81LYHEyO2SWNjoPJXc9Gzi3FVa = C81LYHEyO2SWNjoPJXc9Gzi3FVa[-wwCFA0VjJa:]
		IgbzRlkt72ha,V14VSTPKu8tAFdyZbz = NVS30xAdRFMIw1n9CislkE2(u"ࠩࠪ૫"),b05yftsZ6NYgIKP(u"ࠪࠫ૬")
		u2CmBgdZwfX6ElMJOk0Q4xD8U = str(int(C2jP0iLNGKnHu9xp(u"ࠫ࠾࠭૭")*(wwCFA0VjJa+LgpdP3UjFRnlX(u"࠱ీ")))-int(C81LYHEyO2SWNjoPJXc9Gzi3FVa))[-wwCFA0VjJa:]
		for Q0CPUzw94q3eD in list(range(C2jP0iLNGKnHu9xp(u"࠱ు"),wwCFA0VjJa,C2jP0iLNGKnHu9xp(u"࠶ూ"))):
			IgbzRlkt72ha += u2CmBgdZwfX6ElMJOk0Q4xD8U[Q0CPUzw94q3eD:Q0CPUzw94q3eD+QynMHGWA0blfqTUdxRh5Jzi2t(u"࠷ృ")]+BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠬ࠳ࠧ૮")
			V14VSTPKu8tAFdyZbz += str(sum(map(int,C81LYHEyO2SWNjoPJXc9Gzi3FVa[Q0CPUzw94q3eD:Q0CPUzw94q3eD+LgpdP3UjFRnlX(u"࠹౅")]))%FGDJwkEbTB5SoXujs3f(u"࠵࠵ౄ"))
		IL9HcN80i3CJEW6QtSMvUlAXsp = str(erEgVKM2qCStTop3zRPXAOaF8Ji56)+IgbzRlkt72ha+V14VSTPKu8tAFdyZbz
		PPnk8u9bCc.append(IL9HcN80i3CJEW6QtSMvUlAXsp)
	VZ8BTik93OqXLCh0fD7d2KUPpn4mH6(RnqtMUa9Nh6peGEsBT,jx7s8T0BFgODXLMzIYedf(u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩ૯"),C2dgEDAKQGsvh(u"ࠧࡔࡋࡗࡉࡘࡥࡖࡆࡔࡌࡊ࡞࠭૰"),[xI9CNW0lESvmw,ddgBVAuzijxRM316,pqoZt0hKDTC73jU6MeWIl],UuEtImzir9)
	VZ8BTik93OqXLCh0fD7d2KUPpn4mH6(RnqtMUa9Nh6peGEsBT,l0WAe1f7Bpi5ZXk(u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫ૱"),gItVahxL0w(u"ࠩࡖࡍ࡙ࡋࡓࡠࡅࡋࡉࡈࡑࠧ૲"),[PPnk8u9bCc,xI9CNW0lESvmw,ddgBVAuzijxRM316,pqoZt0hKDTC73jU6MeWIl],IIiPCruL6dT8s1lqj47SzpVHnYNm)
	return NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠪࡠࡳ࠭૳").join(PPnk8u9bCc)
def GGDIbyLQYfvdjAMi9(EAdbsmyiqLtjhPlxG,qmr7vLh1EW,AqLgT4S6FExHi1kZ5smy7a0hRX,ib6URTIJnFlgVwXsQAN0ZGD4k9c3ph,iW6eqtHJGnzFhTSgduj7Pys2w,ww2vqCObJMBYRUaDyuWQ0):
	eIL9BxdTbZj = str(ib6URTIJnFlgVwXsQAN0ZGD4k9c3ph)[C2jP0iLNGKnHu9xp(u"࠶ె"):l0WAe1f7Bpi5ZXk(u"࠲࠶࠲ే")].replace(T6wRistc1SCo4hqObgumK(u"ࠫࡡࡴࠧ૴"),C2dgEDAKQGsvh(u"ࠬࡢ࡜࡯ࠩ૵")).replace(vvHpKfcqRnrFzjG(u"࠭࡜ࡳࠩ૶"),NVS30xAdRFMIw1n9CislkE2(u"ࠧ࡝࡞ࡵࠫ૷")).replace(C2dgEDAKQGsvh(u"ࠨࠢࠣࠤࠥ࠭૸"),k5dztomYyN3H(u"ࠩࠣࠫૹ")).replace(BoWHNb9daQVCF16A(u"ࠪࠤࠥࠦࠧૺ"),vvHpKfcqRnrFzjG(u"ࠫࠥ࠭ૻ"))
	if len(str(ib6URTIJnFlgVwXsQAN0ZGD4k9c3ph))>BmcLzCFjuIrZP5fwXH18aN6YS(u"࠳࠷࠳ై"): eIL9BxdTbZj = eIL9BxdTbZj+jx7s8T0BFgODXLMzIYedf(u"ࠬࠦ࠮࠯࠰ࠪૼ")
	toAVQS46Fv8aJYyLf25KnkUNC = str(AqLgT4S6FExHi1kZ5smy7a0hRX)[UxS67uoGThbMwnfNRzy4gajLd23JH(u"࠲౉"):WMkAjB1RgN7q(u"࠵࠹࠵ొ")].replace(V2RbfGOBdcA6l8NTsPWzEyvS7(u"࠭࡜࡯ࠩ૽"),WMkAjB1RgN7q(u"ࠧ࡝࡞ࡱࠫ૾")).replace(jSu5Cg2Ub1OAkZVs8Yoz(u"ࠨ࡞ࡵࠫ૿"),v5EA6TqHX3s4jzBMk(u"ࠩ࡟ࡠࡷ࠭଀")).replace(FGDJwkEbTB5SoXujs3f(u"ࠪࠤࠥࠦࠠࠨଁ"),nr5mZG89ICi6cgt4MfLJa0(u"ࠫࠥ࠭ଂ")).replace(nr5mZG89ICi6cgt4MfLJa0(u"ࠬࠦࠠࠡࠩଃ"),b05yftsZ6NYgIKP(u"࠭ࠠࠨ଄"))
	if len(str(AqLgT4S6FExHi1kZ5smy7a0hRX))>UnWjVbo503mEMv9KF(u"࠶࠺࠶ో"): toAVQS46Fv8aJYyLf25KnkUNC = toAVQS46Fv8aJYyLf25KnkUNC+T6wRistc1SCo4hqObgumK(u"ࠧࠡ࠰࠱࠲ࠬଅ")
	Lmj1pfQk63XdoeH(rbjsM8cRFiuA1(u"ࠨࡐࡒࡘࡎࡉࡅࠨଆ"),jSu5Cg2Ub1OAkZVs8Yoz(u"ࠩ࠱ࠤࠥࡕࡐࡆࡐࡘࡖࡑࡥࠧଇ")+EAdbsmyiqLtjhPlxG+l0WAe1f7Bpi5ZXk(u"ࠪࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭ଈ")+qmr7vLh1EW+fY5wTlhtnOc0Er6sdy4k87b(u"ࠫࠥࡣࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭ଉ")+iW6eqtHJGnzFhTSgduj7Pys2w+NVS30xAdRFMIw1n9CislkE2(u"ࠬࠦ࡝ࠡࠢࠣࡑࡪࡺࡨࡰࡦ࠽ࠤࡠࠦࠧଊ")+ww2vqCObJMBYRUaDyuWQ0+UnWjVbo503mEMv9KF(u"࠭ࠠ࡞ࠢࠣࠤࡍ࡫ࡡࡥࡧࡵࡷ࠿࡛ࠦࠡࠩଋ")+str(eIL9BxdTbZj)+QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠧࠡ࡟ࠣࠤࠥࡊࡡࡵࡣ࠽ࠤࡠࠦࠧଌ")+toAVQS46Fv8aJYyLf25KnkUNC+l0WAe1f7Bpi5ZXk(u"ࠨࠢࡠࠫ଍"))
	return
def AFKwVobIO5kiPvceu26EgdCjnY():
	global NNUlZS5nw20Aua
	import getmac82 as AeT0wMuhkRomy2Ij9XVCzW8gYn
	try:
		ll8c74dUF1VgwI = AeT0wMuhkRomy2Ij9XVCzW8gYn.get_mac_address()
		if ll8c74dUF1VgwI.count(fY5wTlhtnOc0Er6sdy4k87b(u"ࠩ࠽ࠫ଎"))==C2jP0iLNGKnHu9xp(u"࠻్") and ll8c74dUF1VgwI.count(l0WAe1f7Bpi5ZXk(u"ࠪ࠴ࠬଏ"))<UxS67uoGThbMwnfNRzy4gajLd23JH(u"࠾ౌ"):
			ll8c74dUF1VgwI = ll8c74dUF1VgwI.lower().replace(jx7s8T0BFgODXLMzIYedf(u"ࠫ࠿࠭ଐ"),sRth5giAQzWlEVm7JOX(u"ࠬ࠭଑"))
			NNUlZS5nw20Aua = str(int(ll8c74dUF1VgwI,jx7s8T0BFgODXLMzIYedf(u"࠱࠷౎")))
	except: pass
	return
def DDMUyPQKeH7lZY8vAsdtgbVjnB():
	global F4FakM8IBcKysozT
	import getmac94 as OsvMofTVj8LUrxWmH2Z1kFP
	try:
		WQXp3VfIdnv8ecYy12RZHzbDSEm = OsvMofTVj8LUrxWmH2Z1kFP.get_mac_address()
		if WQXp3VfIdnv8ecYy12RZHzbDSEm.count(NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠭࠺ࠨ଒"))==l0WAe1f7Bpi5ZXk(u"࠷౐") and WQXp3VfIdnv8ecYy12RZHzbDSEm.count(qbPw1d3KimF(u"ࠧ࠱ࠩଓ"))<k5dztomYyN3H(u"࠺౏"):
			WQXp3VfIdnv8ecYy12RZHzbDSEm = WQXp3VfIdnv8ecYy12RZHzbDSEm.lower().replace(FGDJwkEbTB5SoXujs3f(u"ࠨ࠼ࠪଔ"),EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠩࠪକ"))
			F4FakM8IBcKysozT = str(int(WQXp3VfIdnv8ecYy12RZHzbDSEm,BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠴࠺౑")))
	except: pass
	return
def KNGXqQl2C9beWRL71FMwVxfU(ww2vqCObJMBYRUaDyuWQ0,qmr7vLh1EW,AqLgT4S6FExHi1kZ5smy7a0hRX=EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠪࠫଖ"),ib6URTIJnFlgVwXsQAN0ZGD4k9c3ph=V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠫࠬଗ"),iW6eqtHJGnzFhTSgduj7Pys2w=V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠬ࠭ଘ")):
	GGDIbyLQYfvdjAMi9(BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠭ࡕࡓࡎࡏࡍࡇࠦࠠࡐࡒࡈࡒࡤ࡛ࡒࡍࠩଙ"),qmr7vLh1EW,AqLgT4S6FExHi1kZ5smy7a0hRX,ib6URTIJnFlgVwXsQAN0ZGD4k9c3ph,iW6eqtHJGnzFhTSgduj7Pys2w,ww2vqCObJMBYRUaDyuWQ0)
	if BLz7m2RkNrxXQwy1cGAp: import urllib.request as NZf1lnL5uchprA4Xm2v
	else: import urllib2 as NZf1lnL5uchprA4Xm2v
	if not ib6URTIJnFlgVwXsQAN0ZGD4k9c3ph: ib6URTIJnFlgVwXsQAN0ZGD4k9c3ph = {UnWjVbo503mEMv9KF(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫଚ"):UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠨࠩଛ")}
	if not AqLgT4S6FExHi1kZ5smy7a0hRX: AqLgT4S6FExHi1kZ5smy7a0hRX = {}
	if ww2vqCObJMBYRUaDyuWQ0==UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠩࡊࡉ࡙࠭ଜ"):
		qmr7vLh1EW = qmr7vLh1EW+rbjsM8cRFiuA1(u"ࠪࡃࠬଝ")+xcWMv9b8dpTSq1IZ5eht(AqLgT4S6FExHi1kZ5smy7a0hRX)
		AqLgT4S6FExHi1kZ5smy7a0hRX = None
	elif ww2vqCObJMBYRUaDyuWQ0==l0WAe1f7Bpi5ZXk(u"ࠫࡕࡕࡓࡕࠩଞ") and BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠬࡰࡳࡰࡰࠪଟ") in str(ib6URTIJnFlgVwXsQAN0ZGD4k9c3ph):
		from json import dumps as zNnYrJKZ9PRt68BTmfhpwCoixu2d
		AqLgT4S6FExHi1kZ5smy7a0hRX = zNnYrJKZ9PRt68BTmfhpwCoixu2d(AqLgT4S6FExHi1kZ5smy7a0hRX)
		AqLgT4S6FExHi1kZ5smy7a0hRX = str(AqLgT4S6FExHi1kZ5smy7a0hRX).encode(LgpdP3UjFRnlX(u"࠭ࡵࡵࡨ࠻ࠫଠ"))
	elif ww2vqCObJMBYRUaDyuWQ0==LgpdP3UjFRnlX(u"ࠧࡑࡑࡖࡘࠬଡ"):
		AqLgT4S6FExHi1kZ5smy7a0hRX = xcWMv9b8dpTSq1IZ5eht(AqLgT4S6FExHi1kZ5smy7a0hRX)
		AqLgT4S6FExHi1kZ5smy7a0hRX = AqLgT4S6FExHi1kZ5smy7a0hRX.encode(l0WAe1f7Bpi5ZXk(u"ࠨࡷࡷࡪ࠽࠭ଢ"))
	try:
		j3Xkzu6tLMHxPGBr7idQp2eg45TV = NZf1lnL5uchprA4Xm2v.Request(qmr7vLh1EW,headers=ib6URTIJnFlgVwXsQAN0ZGD4k9c3ph,data=AqLgT4S6FExHi1kZ5smy7a0hRX)
		UMNteoHlkEy3Yf = NZf1lnL5uchprA4Xm2v.urlopen(j3Xkzu6tLMHxPGBr7idQp2eg45TV)
		qqThxfYXnogSpAiJ7GkcLz = UMNteoHlkEy3Yf.read()
		H7agXMdxq32DwufZ,ag6Mwkfe2YZ5CdTNOLjyob3 = BmcLzCFjuIrZP5fwXH18aN6YS(u"࠶࠵࠶౒"),gItVahxL0w(u"ࠩࡒࡏࠬଣ")
	except:
		qqThxfYXnogSpAiJ7GkcLz = WMkAjB1RgN7q(u"ࠪࠫତ")
		H7agXMdxq32DwufZ,ag6Mwkfe2YZ5CdTNOLjyob3 = -gItVahxL0w(u"࠶౓"),jx7s8T0BFgODXLMzIYedf(u"࡚ࠫࡴ࡫࡯ࡱࡺࡲࠥࡋࡲࡳࡱࡵࠫଥ")
	Lmj1pfQk63XdoeH(vvHpKfcqRnrFzjG(u"ࠬࡔࡏࡕࡋࡆࡉࠬଦ"),YB5xyI7MaRslVpv(u"࠭࠮ࠡࠢࡒࡔࡊࡔࡕࡓࡎࡢ࡙ࡗࡒࡌࡊࡄࠣࠤࡗࡋࡓࡑࡑࡑࡗࡊࠦࠠࡄࡱࡧࡩ࠿࡛ࠦࠡࠩଧ")+str(H7agXMdxq32DwufZ)+l0WAe1f7Bpi5ZXk(u"ࠧࠡ࡟ࠣࠤࠥࡘࡥࡢࡵࡲࡲ࠿࡛ࠦࠡࠩନ")+ag6Mwkfe2YZ5CdTNOLjyob3+WMkAjB1RgN7q(u"ࠨࠢࡠࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪ଩")+iW6eqtHJGnzFhTSgduj7Pys2w+V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨପ")+qmr7vLh1EW+k5dztomYyN3H(u"ࠪࠤࡢ࠭ଫ"))
	if qqThxfYXnogSpAiJ7GkcLz and BLz7m2RkNrxXQwy1cGAp: qqThxfYXnogSpAiJ7GkcLz = qqThxfYXnogSpAiJ7GkcLz.decode(l0WAe1f7Bpi5ZXk(u"ࠫࡺࡺࡦ࠹ࠩବ"))
	return qqThxfYXnogSpAiJ7GkcLz
def KfuaVn4XrSGTUtLIw(Qs9gmTdLzOnaAvJ14KXCqyYFu,y3x2J6Nr8LgCGjdWuV=PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠬ࠭ଭ")):
	e1Waf3HObrA = str(SS503hkALwlNIvHYW7jb.randrange(RqldvxFuM5GEQ2HAz93o7afBb0(u"࠷࠱࠲࠳࠴࠵࠶࠷࠱࠲࠳࠴౔"),C2jP0iLNGKnHu9xp(u"࠹࠺࠻࠼࠽࠾࠿࠹࠺࠻࠼࠽ౕ")))
	ib6URTIJnFlgVwXsQAN0ZGD4k9c3ph = {FGDJwkEbTB5SoXujs3f(u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬମ"):WMkAjB1RgN7q(u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡰࡳࡰࡰࠪଯ")}
	j3LxpvKiHam8yROVwnMdseUo = {	C2dgEDAKQGsvh(u"ࠣࡷࡶࡩࡷࡥࡩࡥࠤର"):hvc2sXOB31KTLgiZaQUR9xuGjloYS(YB5xyI7MaRslVpv(u"࠵࠵౗")).splitlines()[PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"࠳ౘ")][-jSu5Cg2Ub1OAkZVs8Yoz(u"࠳࠶ౖ"):],
				WMkAjB1RgN7q(u"ࠤࡲࡷࡤࡼࡥࡳࡵ࡬ࡳࡳࠨ଱"):str(YSomBdvcNUMF3b8JDiCfrVW),
				BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠥࡥࡵࡶ࡟ࡷࡧࡵࡷ࡮ࡵ࡮ࠣଲ"):RhVj0vAt5kPHm,
				QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠦࡩ࡫ࡶࡪࡥࡨࡣ࡫ࡧ࡭ࡪ࡮ࡼࠦଳ"):RhVj0vAt5kPHm,
				l0WAe1f7Bpi5ZXk(u"ࠧ࡫ࡶࡦࡰࡷࡣࡹࡿࡰࡦࠤ଴"):Qs9gmTdLzOnaAvJ14KXCqyYFu,
				EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠨࡰ࡭ࡣࡷࡪࡴࡸ࡭ࠣଵ"): RhVj0vAt5kPHm,
				sRth5giAQzWlEVm7JOX(u"ࠢࡤࡣࡵࡶ࡮࡫ࡲࠣଶ"):vvHpKfcqRnrFzjG(u"ࠣࡃࡕࡅࡇࡏࡃࡠࡘࡌࡈࡊࡕࡓࠣଷ"),
				qbPw1d3KimF(u"ࠤࡨࡺࡪࡴࡴࡠࡲࡵࡳࡵ࡫ࡲࡵ࡫ࡨࡷࠧସ"):{b05yftsZ6NYgIKP(u"ࠥࡉࡻ࡫࡮ࡵࡡࡑࡥࡲ࡫ࠢହ"):Qs9gmTdLzOnaAvJ14KXCqyYFu},
				nr5mZG89ICi6cgt4MfLJa0(u"ࠦࡺࡹࡥࡳࡡࡳࡶࡴࡶࡥࡳࡶ࡬ࡩࡸࠨ଺"): {PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"࡛ࠧࡳࡦࡴࡢࡉࡻ࡫࡮ࡵࡡࡑࡥࡲ࡫ࠢ଻"):Qs9gmTdLzOnaAvJ14KXCqyYFu},
				V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠨࠤࡴ࡭࡬ࡴࡤࡻࡳࡦࡴࡢࡴࡷࡵࡰࡦࡴࡷ࡭ࡪࡹ࡟ࡴࡻࡱࡧ଼ࠧ"):vvHpKfcqRnrFzjG(u"ࡉࡥࡱࡹࡥ౴"),
				EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠢࡪࡲࠥଽ"): V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠣࠦࡵࡩࡲࡵࡴࡦࠤା")
			}
	if not y3x2J6Nr8LgCGjdWuV: UHsy0A9ehNmIdtqzaiP62 = [j3LxpvKiHam8yROVwnMdseUo]
	else:
		wiW3Jd8sup6IN4 = j3LxpvKiHam8yROVwnMdseUo.copy()
		wiW3Jd8sup6IN4[hhlbF1Sns5TrEN8QPCYmL4(u"ࠩࡨࡺࡪࡴࡴࡠࡶࡼࡴࡪ࠭ି")] = y3x2J6Nr8LgCGjdWuV
		wiW3Jd8sup6IN4[b05yftsZ6NYgIKP(u"ࠪࡩࡻ࡫࡮ࡵࡡࡳࡶࡴࡶࡥࡳࡶ࡬ࡩࡸ࠭ୀ")] = {hhlbF1Sns5TrEN8QPCYmL4(u"ࠦࡊࡼࡥ࡯ࡶࡢࡒࡦࡳࡥࠣୁ"):y3x2J6Nr8LgCGjdWuV}
		wiW3Jd8sup6IN4[LgpdP3UjFRnlX(u"ࠬࡻࡳࡦࡴࡢࡴࡷࡵࡰࡦࡴࡷ࡭ࡪࡹࠧୂ")] = {RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠨࡕࡴࡧࡵࡣࡊࡼࡥ࡯ࡶࡢࡒࡦࡳࡥࠣୃ"):y3x2J6Nr8LgCGjdWuV}
		UHsy0A9ehNmIdtqzaiP62 = [j3LxpvKiHam8yROVwnMdseUo,wiW3Jd8sup6IN4]
	AqLgT4S6FExHi1kZ5smy7a0hRX = {k5dztomYyN3H(u"ࠢࡢࡲ࡬ࡣࡰ࡫ࡹࠣୄ"):qbPw1d3KimF(u"ࠨ࠴࠸࠸ࡩࡪ࠳ࡢ࠶࠳࠽ࡩ࠾ࡢ࠷࠺࠴ࡨ࠹࡫࠱࠲࠹ࡨࡩ࠼࠾ࡣࡦࡤࡩ࠶࠾࠭୅"),
			sRth5giAQzWlEVm7JOX(u"ࠤ࡬ࡲࡸ࡫ࡲࡵࡡ࡬ࡨࠧ୆"):e1Waf3HObrA,
			PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠥࡩࡻ࡫࡮ࡵࡵࠥେ"): UHsy0A9ehNmIdtqzaiP62
		}
	qmr7vLh1EW = BoWHNb9daQVCF16A(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡰࡪ࠴࠱ࡥࡲࡶ࡬ࡪࡶࡸࡨࡪ࠴ࡣࡰ࡯࠲࠶࠴࡮ࡴࡵࡲࡤࡴ࡮࠭ୈ")
	qqThxfYXnogSpAiJ7GkcLz = KNGXqQl2C9beWRL71FMwVxfU(QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠬࡖࡏࡔࡖࠪ୉"),qmr7vLh1EW,AqLgT4S6FExHi1kZ5smy7a0hRX,ib6URTIJnFlgVwXsQAN0ZGD4k9c3ph,UxS67uoGThbMwnfNRzy4gajLd23JH(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡔࡇࡑࡈࡤࡇࡎࡂࡎ࡜ࡘࡎࡉࡓࡠࡇ࡙ࡉࡓ࡚࠭࠲ࡵࡷࠫ୊"))
	return qqThxfYXnogSpAiJ7GkcLz
def dWsa2A0O4o5BYiqGXhyKEbM(plWqMa0QgKcbR5n8L1GVozyek3,QHDcUO2xtS4CmF):
	QHDcUO2xtS4CmF = QHDcUO2xtS4CmF.replace(UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠧ࡯ࡷ࡯ࡰࠬୋ"),BoWHNb9daQVCF16A(u"ࠨࡐࡲࡲࡪ࠭ୌ"))
	QHDcUO2xtS4CmF = QHDcUO2xtS4CmF.replace(NVS30xAdRFMIw1n9CislkE2(u"ࠩࡷࡶࡺ࡫୍ࠧ"),NVS30xAdRFMIw1n9CislkE2(u"ࠪࡘࡷࡻࡥࠨ୎"))
	QHDcUO2xtS4CmF = QHDcUO2xtS4CmF.replace(sRth5giAQzWlEVm7JOX(u"ࠫ࡫ࡧ࡬ࡴࡧࠪ୏"),LgpdP3UjFRnlX(u"ࠬࡌࡡ࡭ࡵࡨࠫ୐"))
	QHDcUO2xtS4CmF = QHDcUO2xtS4CmF.replace(BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠭࡜࠰ࠩ୑"),T6wRistc1SCo4hqObgumK(u"ࠧ࠰ࠩ୒"))
	try: ty842nqSiZglc6GoEPdTMAjLvRBOxm = eval(QHDcUO2xtS4CmF)
	except: ty842nqSiZglc6GoEPdTMAjLvRBOxm = mN9XAls0LP32WQJhdDnT1jBgkUu(plWqMa0QgKcbR5n8L1GVozyek3)
	return ty842nqSiZglc6GoEPdTMAjLvRBOxm
def ivqDg9QFCIArMf1PO7WwU3lR():
	EAdbsmyiqLtjhPlxG,gg37KuOokaYFs8qTiezZn1tJ4jLr6,qmr7vLh1EW,hT9FozLnDCgvPG0EXyJa7,QFrVYJkywEsXquMNz,z3z9QgENFk5eMYB4,QHDcUO2xtS4CmF,ezSE9fBuvT,yPoqtK3i7zHulhZJDWYsnLxvT0 = cIa9Spry0oqE(SzGukeylg5Nsr9M20WIan)
	AwKc1kuJ7V = My7Dwqvs6bfGNSIgX.findall(YB5xyI7MaRslVpv(u"ࠨ࡞ࡧࡠࡩࡀ࡜ࡥ࡞ࡧࠤࡡࡡ࠯ࡄࡑࡏࡓࡗࡢ࡝ࠨ୓"),gg37KuOokaYFs8qTiezZn1tJ4jLr6,My7Dwqvs6bfGNSIgX.DOTALL)
	if AwKc1kuJ7V: gg37KuOokaYFs8qTiezZn1tJ4jLr6 = gg37KuOokaYFs8qTiezZn1tJ4jLr6.split(AwKc1kuJ7V[YB5xyI7MaRslVpv(u"࠵ౚ")],BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠵ౙ"))[BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠵ౙ")]
	CqbNIloiZf6MWEeRL = KBxPW9cX8dqtaUDG.strftime(gItVahxL0w(u"ࠩࡢࠩࡲ࠴ࠥࡥࡡࠨࡌ࠿ࠫࡍࡠࠩ୔"),KBxPW9cX8dqtaUDG.localtime(SGB7KzblUa4gCZD1srqc))
	gg37KuOokaYFs8qTiezZn1tJ4jLr6 = gg37KuOokaYFs8qTiezZn1tJ4jLr6+CqbNIloiZf6MWEeRL
	q0HETPprhGgacmbJ4jD = EAdbsmyiqLtjhPlxG,gg37KuOokaYFs8qTiezZn1tJ4jLr6,qmr7vLh1EW,hT9FozLnDCgvPG0EXyJa7,QFrVYJkywEsXquMNz,z3z9QgENFk5eMYB4,QHDcUO2xtS4CmF,ezSE9fBuvT,yPoqtK3i7zHulhZJDWYsnLxvT0
	if XXRtDhYvWb35qnLBxIri7ScNUks0.path.exists(Cjda4zr3pXghVKDR):
		icrzLnv703mP = open(Cjda4zr3pXghVKDR,BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠪࡶࡧ࠭୕")).read()
		if BLz7m2RkNrxXQwy1cGAp: icrzLnv703mP = icrzLnv703mP.decode(V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠫࡺࡺࡦ࠹ࠩୖ"))
		icrzLnv703mP = dWsa2A0O4o5BYiqGXhyKEbM(qbPw1d3KimF(u"ࠬࡪࡩࡤࡶࠪୗ"),icrzLnv703mP)
	else: icrzLnv703mP = {}
	FtZSrKTsDbx2Jh5nM487WfXil0ON6a = {}
	for qSCfIJ6bEOuD5Lac4mevTjkzZgyHnd in list(icrzLnv703mP.keys()):
		if qSCfIJ6bEOuD5Lac4mevTjkzZgyHnd!=EAdbsmyiqLtjhPlxG: FtZSrKTsDbx2Jh5nM487WfXil0ON6a[qSCfIJ6bEOuD5Lac4mevTjkzZgyHnd] = icrzLnv703mP[qSCfIJ6bEOuD5Lac4mevTjkzZgyHnd]
		else:
			if gg37KuOokaYFs8qTiezZn1tJ4jLr6 and gg37KuOokaYFs8qTiezZn1tJ4jLr6!=EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠭࠮࠯ࠩ୘"):
				G7noR4QrEhe0 = icrzLnv703mP[qSCfIJ6bEOuD5Lac4mevTjkzZgyHnd]
				if q0HETPprhGgacmbJ4jD in G7noR4QrEhe0:
					gMous1DWl97JdE5h6n0CFjeLZkq = G7noR4QrEhe0.index(q0HETPprhGgacmbJ4jD)
					del G7noR4QrEhe0[gMous1DWl97JdE5h6n0CFjeLZkq]
				lsSvZMNpBrH78OtKiEezXgbUY = [q0HETPprhGgacmbJ4jD]+G7noR4QrEhe0
				lsSvZMNpBrH78OtKiEezXgbUY = lsSvZMNpBrH78OtKiEezXgbUY[:UxS67uoGThbMwnfNRzy4gajLd23JH(u"࠻࠰౛")]
				FtZSrKTsDbx2Jh5nM487WfXil0ON6a[qSCfIJ6bEOuD5Lac4mevTjkzZgyHnd] = lsSvZMNpBrH78OtKiEezXgbUY
			else: FtZSrKTsDbx2Jh5nM487WfXil0ON6a[qSCfIJ6bEOuD5Lac4mevTjkzZgyHnd] = icrzLnv703mP[qSCfIJ6bEOuD5Lac4mevTjkzZgyHnd]
	if EAdbsmyiqLtjhPlxG not in list(FtZSrKTsDbx2Jh5nM487WfXil0ON6a.keys()): FtZSrKTsDbx2Jh5nM487WfXil0ON6a[EAdbsmyiqLtjhPlxG] = [q0HETPprhGgacmbJ4jD]
	FtZSrKTsDbx2Jh5nM487WfXil0ON6a = str(FtZSrKTsDbx2Jh5nM487WfXil0ON6a)
	if BLz7m2RkNrxXQwy1cGAp: FtZSrKTsDbx2Jh5nM487WfXil0ON6a = FtZSrKTsDbx2Jh5nM487WfXil0ON6a.encode(jx7s8T0BFgODXLMzIYedf(u"ࠧࡶࡶࡩ࠼ࠬ୙"))
	open(Cjda4zr3pXghVKDR,l0WAe1f7Bpi5ZXk(u"ࠨࡹࡥࠫ୚")).write(FtZSrKTsDbx2Jh5nM487WfXil0ON6a)
	return
def VZ8BTik93OqXLCh0fD7d2KUPpn4mH6(GTYRu9hVKZoHOyUt4w2ilpLqA,g9Pmj2VpAznvZQFGH5O,a1LKjn02CPXht9VcvElgfeboFTm,AqLgT4S6FExHi1kZ5smy7a0hRX,rXPnclZvF5N4LjYd9k617IRb,Of7rWvaYuSqznE2is16=BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࡊࡦࡲࡳࡦ౵")):
	f0KUlmeMpWgFsPk16On = bLEBi8IO7uU2x3htYDdVq95.getSetting(k5dztomYyN3H(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳࡮ࡴࡵࡲࡦࡥࡨ࡮ࡥࠨ୛"))
	if f0KUlmeMpWgFsPk16On==EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠪࡐࡎࡓࡉࡕࡇࡇࠫଡ଼") and rXPnclZvF5N4LjYd9k617IRb>JeTgfEOCQS8mtloPc3dr1hxX: rXPnclZvF5N4LjYd9k617IRb = JeTgfEOCQS8mtloPc3dr1hxX
	if Of7rWvaYuSqznE2is16:
		TTLQDONupiB6q,kdizpIZj1fqeuPslGXF4y6gLESwTU = [],[]
		for k3Om08MCgqQao4n1 in range(len(a1LKjn02CPXht9VcvElgfeboFTm)):
			QHDcUO2xtS4CmF = XpRd3moWCYIQLDn51FS.dumps(AqLgT4S6FExHi1kZ5smy7a0hRX[k3Om08MCgqQao4n1])
			VVsPT29gZw0LCY = DDeKqnGoBpLH1d6civ8JgN4V.compress(QHDcUO2xtS4CmF)
			TTLQDONupiB6q.append((a1LKjn02CPXht9VcvElgfeboFTm[k3Om08MCgqQao4n1],))
			kdizpIZj1fqeuPslGXF4y6gLESwTU.append((rXPnclZvF5N4LjYd9k617IRb+SGB7KzblUa4gCZD1srqc,str(a1LKjn02CPXht9VcvElgfeboFTm[k3Om08MCgqQao4n1]),VVsPT29gZw0LCY))
	else:
		QHDcUO2xtS4CmF = XpRd3moWCYIQLDn51FS.dumps(AqLgT4S6FExHi1kZ5smy7a0hRX)
		NvHcgpGbUDiuoFTVmfJ8B9Rh4 = DDeKqnGoBpLH1d6civ8JgN4V.compress(QHDcUO2xtS4CmF)
	try: W9YiR1FGTdzO3jByXPA70D,CCJpwYUsTN1cBIz5PH = syJIkO4GZvPcSl(GTYRu9hVKZoHOyUt4w2ilpLqA)
	except: return
	while FGDJwkEbTB5SoXujs3f(u"࡙ࡸࡵࡦ౶"):
		try:
			CCJpwYUsTN1cBIz5PH.execute(BoWHNb9daQVCF16A(u"ࠫࡇࡋࡇࡊࡐࠣࡍࡒࡓࡅࡅࡋࡄࡘࡊࠦࡔࡓࡃࡑࡗࡆࡉࡔࡊࡑࡑࠤࡀ࠭ଢ଼"))
			break
		except: KBxPW9cX8dqtaUDG.sleep(YB5xyI7MaRslVpv(u"࠰࠯࠷౜"))
	CCJpwYUsTN1cBIz5PH.execute(sRth5giAQzWlEVm7JOX(u"ࠬࡉࡒࡆࡃࡗࡉ࡚ࠥࡁࡃࡎࡈࠤࡎࡌࠠࡏࡑࡗࠤࡊ࡞ࡉࡔࡖࡖࠤࠧ࠭୞")+g9Pmj2VpAznvZQFGH5O+BoWHNb9daQVCF16A(u"࠭ࠢࠡࠪࡨࡼࡵ࡯ࡲࡺ࠮ࡦࡳࡱࡻ࡭࡯࠮ࡧࡥࡹࡧࠩࠡ࠽ࠪୟ"))
	if Of7rWvaYuSqznE2is16:
		CCJpwYUsTN1cBIz5PH.executemany(C2jP0iLNGKnHu9xp(u"ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥࠨࠧୠ")+g9Pmj2VpAznvZQFGH5O+jx7s8T0BFgODXLMzIYedf(u"ࠨࠤ࡛ࠣࡍࡋࡒࡆࠢࡦࡳࡱࡻ࡭࡯ࠢࡀࠤࡄࠦ࠻ࠨୡ"),TTLQDONupiB6q)
		CCJpwYUsTN1cBIz5PH.executemany(nr5mZG89ICi6cgt4MfLJa0(u"ࠩࡌࡒࡘࡋࡒࡕࠢࡌࡒ࡙ࡕࠠࠣࠩୢ")+g9Pmj2VpAznvZQFGH5O+vvHpKfcqRnrFzjG(u"ࠪࠦࠥ࡜ࡁࡍࡗࡈࡗࠥ࠮࠿࠭ࡁ࠯ࡃ࠮ࠦ࠻ࠨୣ"),kdizpIZj1fqeuPslGXF4y6gLESwTU)
	else:
		if rXPnclZvF5N4LjYd9k617IRb:
			uCf5OH3DhwXknNQrqbT8t1JIip = (str(a1LKjn02CPXht9VcvElgfeboFTm),)
			CCJpwYUsTN1cBIz5PH.execute(WMkAjB1RgN7q(u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࠥࠫ୤")+g9Pmj2VpAznvZQFGH5O+PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠬࠨࠠࡘࡊࡈࡖࡊࠦࡣࡰ࡮ࡸࡱࡳࠦ࠽ࠡࡁࠣ࠿ࠬ୥"),uCf5OH3DhwXknNQrqbT8t1JIip)
			uCf5OH3DhwXknNQrqbT8t1JIip = (rXPnclZvF5N4LjYd9k617IRb+SGB7KzblUa4gCZD1srqc,str(a1LKjn02CPXht9VcvElgfeboFTm),NvHcgpGbUDiuoFTVmfJ8B9Rh4)
			CCJpwYUsTN1cBIz5PH.execute(T6wRistc1SCo4hqObgumK(u"࠭ࡉࡏࡕࡈࡖ࡙ࠦࡉࡏࡖࡒࠤࠧ࠭୦")+g9Pmj2VpAznvZQFGH5O+PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"࡙ࠧࠣࠢࡅࡑ࡛ࡅࡔࠢࠫࡃ࠱ࡅࠬࡀࠫࠣ࠿ࠬ୧"),uCf5OH3DhwXknNQrqbT8t1JIip)
		else:
			uCf5OH3DhwXknNQrqbT8t1JIip = (NvHcgpGbUDiuoFTVmfJ8B9Rh4,str(a1LKjn02CPXht9VcvElgfeboFTm))
			CCJpwYUsTN1cBIz5PH.execute(qbPw1d3KimF(u"ࠨࡗࡓࡈࡆ࡚ࡅࠡࠤࠪ୨")+g9Pmj2VpAznvZQFGH5O+UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠩࠥࠤࡘࡋࡔࠡࡦࡤࡸࡦࠦ࠽ࠡࡁ࡛ࠣࡍࡋࡒࡆࠢࡦࡳࡱࡻ࡭࡯ࠢࡀࠤࡄࠦ࠻ࠨ୩"),uCf5OH3DhwXknNQrqbT8t1JIip)
	W9YiR1FGTdzO3jByXPA70D.commit()
	W9YiR1FGTdzO3jByXPA70D.close()
	return
def xcWMv9b8dpTSq1IZ5eht(AqLgT4S6FExHi1kZ5smy7a0hRX):
	if BLz7m2RkNrxXQwy1cGAp: import urllib.parse as MYiIjdfZmN8lO
	else: import urllib as MYiIjdfZmN8lO
	MBrZWSpjkAXKeQm8h = MYiIjdfZmN8lO.urlencode(AqLgT4S6FExHi1kZ5smy7a0hRX)
	return MBrZWSpjkAXKeQm8h
zEYqUpKhFlw = RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠪࠫ୪")
def B0xcwKkMQ16mpSFRaVHPTzuhUZngLq(QAKdHzO0rehbtyIc,Dj051Gb2vsNOkuoTg=LgpdP3UjFRnlX(u"ࠫࠬ୫"),lveMNOXYtUdkhLP6AQ=PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠬ࠭୬")):
	Wdlo9EBTGLeY2ux = Dj051Gb2vsNOkuoTg not in [BmcLzCFjuIrZP5fwXH18aN6YS(u"࠭ࡍ࠴ࡗࠪ୭"),vvHpKfcqRnrFzjG(u"ࠧࡊࡒࡗ࡚ࠬ୮")]
	global zEYqUpKhFlw
	if not lveMNOXYtUdkhLP6AQ: lveMNOXYtUdkhLP6AQ = LgpdP3UjFRnlX(u"ࠨࡸ࡬ࡨࡪࡵࠧ୯")
	zEYqUpKhFlw,TTI09H7J5O,fG1vtSko9Dnig = UnWjVbo503mEMv9KF(u"ࠩࡦࡥࡳࡩࡥ࡭ࡧࡧ࠴ࠬ୰"),BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠪࠫୱ"),FGDJwkEbTB5SoXujs3f(u"ࠫࠬ୲")
	if len(QAKdHzO0rehbtyIc)==gItVahxL0w(u"࠴ౝ"):
		qmr7vLh1EW,uqGsld6kwze,fG1vtSko9Dnig = QAKdHzO0rehbtyIc
		if uqGsld6kwze: TTI09H7J5O = fY5wTlhtnOc0Er6sdy4k87b(u"ࠬࠦࠠࠡࡕࡸࡦࡹ࡯ࡴ࡭ࡧ࠽ࠤࡠࠦࠧ୳")+uqGsld6kwze+v5EA6TqHX3s4jzBMk(u"࠭ࠠ࡞ࠩ୴")
	else: qmr7vLh1EW,uqGsld6kwze,fG1vtSko9Dnig = QAKdHzO0rehbtyIc,PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠧࠨ୵"),FGDJwkEbTB5SoXujs3f(u"ࠨࠩ୶")
	qmr7vLh1EW = qmr7vLh1EW.replace(hhlbF1Sns5TrEN8QPCYmL4(u"ࠩࠨ࠶࠵࠭୷"),jx7s8T0BFgODXLMzIYedf(u"ࠪࠤࠬ୸"))
	OzADck17lfuHqG2SYi = REGCdFbgy4Vvu2ieLqNMlxntY(qmr7vLh1EW)
	if Dj051Gb2vsNOkuoTg not in [jx7s8T0BFgODXLMzIYedf(u"ࠫࡉࡕࡗࡏࡎࡒࡅࡉ࠭୹"),jSu5Cg2Ub1OAkZVs8Yoz(u"ࠬࡏࡐࡕࡘࠪ୺")]:
		if Dj051Gb2vsNOkuoTg!=sRth5giAQzWlEVm7JOX(u"࠭ࡄࡐ࡙ࡑࡐࡔࡇࡄࠨ୻"): qmr7vLh1EW = qmr7vLh1EW.replace(RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠧࠡࠩ୼"),l0WAe1f7Bpi5ZXk(u"ࠨࠧ࠵࠴ࠬ୽"))
		Lmj1pfQk63XdoeH(b05yftsZ6NYgIKP(u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ୾"),Dwl0N6FKuVU8nB1mbisIrCzdO(baNWS6nfqTC5iX4Kl)+jSu5Cg2Ub1OAkZVs8Yoz(u"ࠪࠤࠥࠦࡐࡳࡧࡳࡥࡷ࡯࡮ࡨࠢࡷࡳࠥࡶ࡬ࡢࡻ࠲ࡨࡴࡽ࡮࡭ࡱࡤࡨࠥࡼࡩࡥࡧࡲࠤࠥࠦࡖࡪࡦࡨࡳ࠿࡛ࠦࠡࠩ୿")+qmr7vLh1EW+BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠫࠥࡣࠧ஀")+TTI09H7J5O)
		if OzADck17lfuHqG2SYi==UnWjVbo503mEMv9KF(u"ࠬ࠴࡭࠴ࡷ࠻ࠫ஁") and Dj051Gb2vsNOkuoTg not in [jSu5Cg2Ub1OAkZVs8Yoz(u"࠭ࡉࡑࡖ࡙ࠫஂ"),b05yftsZ6NYgIKP(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨஃ")]:
			from G6AHskJeqN import cChyAEtdaMvNXsurWwnSeBzFU2m,CnKwdteDG5BE8MTRhUpYIJm3NLrSgq,gj7BGM5t3RZpA0vNixLqzwualb16
			wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = cChyAEtdaMvNXsurWwnSeBzFU2m(qmr7vLh1EW)
			ssuJokZgUN2SDTVMHQeyb3Idm0F = len(QQ2cE1FjUyxPonbDhaTkV6B3i)
			if ssuJokZgUN2SDTVMHQeyb3Idm0F>jSu5Cg2Ub1OAkZVs8Yoz(u"࠳౞"):
				GOtNfU3xQFkEhPouwA = CnKwdteDG5BE8MTRhUpYIJm3NLrSgq(RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠨษัฮึࠦวๅ็็ๅࠥอไๆ่สือࡀࠠࠩࠩ஄")+str(ssuJokZgUN2SDTVMHQeyb3Idm0F)+sRth5giAQzWlEVm7JOX(u"้้ࠩࠣ็ࠩࠨஅ"), wlfZEzuRyYLvrp)
				if GOtNfU3xQFkEhPouwA==-sRth5giAQzWlEVm7JOX(u"࠴౟"):
					gj7BGM5t3RZpA0vNixLqzwualb16(LgpdP3UjFRnlX(u"ࠪษ้เวยࠢ฼้้๐ษࠡฬื฾๏๊ࠠศๆไ๎ิ๐่ࠨஆ"),NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠫࡈࡧ࡮ࡤࡧ࡯ࠫஇ"))
					return zEYqUpKhFlw
			else: GOtNfU3xQFkEhPouwA = k5dztomYyN3H(u"࠴ౠ")
			qmr7vLh1EW = QQ2cE1FjUyxPonbDhaTkV6B3i[GOtNfU3xQFkEhPouwA]
			if wlfZEzuRyYLvrp[WMkAjB1RgN7q(u"࠵ౡ")]!=C2dgEDAKQGsvh(u"ࠬ࠳࠱ࠨஈ"):
				Lmj1pfQk63XdoeH(vvHpKfcqRnrFzjG(u"࠭ࡎࡐࡖࡌࡇࡊ࠭உ"),Dwl0N6FKuVU8nB1mbisIrCzdO(baNWS6nfqTC5iX4Kl)+jx7s8T0BFgODXLMzIYedf(u"࡚ࠧࠡࠢࠣ࡮ࡪࡥࡰࠢࡖࡩࡱ࡫ࡣࡵࡧࡧࠤࠥࠦࡓࡦ࡮ࡨࡧࡹ࡯࡯࡯࠼ࠣ࡟ࠥ࠭ஊ")+wlfZEzuRyYLvrp[GOtNfU3xQFkEhPouwA]+C2jP0iLNGKnHu9xp(u"ࠨࠢࡠࠤࠥࠦࡖࡪࡦࡨࡳ࠿࡛ࠦࠡࠩ஋")+qmr7vLh1EW+jx7s8T0BFgODXLMzIYedf(u"ࠩࠣࡡࠬ஌"))
		if FGDJwkEbTB5SoXujs3f(u"ࠪ࠳࡮࡬ࡩ࡭࡯࠲ࠫ஍") in qmr7vLh1EW: qmr7vLh1EW = qmr7vLh1EW+qbPw1d3KimF(u"ࠫࢁ࡛ࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ࠿ࠩࠫஎ")
		elif YB5xyI7MaRslVpv(u"ࠬ࡮ࡴࡵࡲࠪஏ") in qmr7vLh1EW.lower() and C2jP0iLNGKnHu9xp(u"࠭࠯ࡥࡣࡶ࡬࠴࠭ஐ") not in qmr7vLh1EW and FGDJwkEbTB5SoXujs3f(u"ࠧࡺࡱࡸࡸࡺࡨࡥ࠯࡯ࡳࡨࠬ஑") not in qmr7vLh1EW:
			if nr5mZG89ICi6cgt4MfLJa0(u"ࠨࡸࡨࡶ࡮࡬ࡹࡱࡧࡨࡶࡂ࠭ஒ") not in qmr7vLh1EW and PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࠫஓ") in qmr7vLh1EW.lower():
				if nr5mZG89ICi6cgt4MfLJa0(u"ࠪࢀࠬஔ") not in qmr7vLh1EW: qmr7vLh1EW = qmr7vLh1EW+nr5mZG89ICi6cgt4MfLJa0(u"ࠫࢁࡼࡥࡳ࡫ࡩࡽࡵ࡫ࡥࡳ࠿ࡩࡥࡱࡹࡥࠨக")
				else: qmr7vLh1EW = qmr7vLh1EW+vvHpKfcqRnrFzjG(u"ࠬࠬࡶࡦࡴ࡬ࡪࡾࡶࡥࡦࡴࡀࡪࡦࡲࡳࡦࠩ஖")
			if YB5xyI7MaRslVpv(u"࠭ࡵࡴࡧࡵ࠱ࡦ࡭ࡥ࡯ࡶࠪ஗") not in qmr7vLh1EW.lower() and Dj051Gb2vsNOkuoTg not in [WMkAjB1RgN7q(u"ࠧࡊࡒࡗ࡚ࠬ஘"),rbjsM8cRFiuA1(u"ࠨࡏ࠶࡙ࠬங")]:
				if rbjsM8cRFiuA1(u"ࠩࡿࠫச") not in qmr7vLh1EW: qmr7vLh1EW = qmr7vLh1EW+C2jP0iLNGKnHu9xp(u"ࠪࢀ࡚ࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴ࠾ࠨࠪ஛")
				else: qmr7vLh1EW = qmr7vLh1EW+jSu5Cg2Ub1OAkZVs8Yoz(u"࡛ࠫࠫࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ࠿ࠩࠫஜ")
	Lmj1pfQk63XdoeH(fY5wTlhtnOc0Er6sdy4k87b(u"ࠬࡔࡏࡕࡋࡆࡉࡤࡒࡉࡏࡇࡖࠫ஝"),Dwl0N6FKuVU8nB1mbisIrCzdO(baNWS6nfqTC5iX4Kl)+YB5xyI7MaRslVpv(u"࠭ࠠࠡࠢࡊࡳࡹࠦࡦࡪࡰࡤࡰࠥࡻࡲ࡭ࠢࠣࠤ࡛࡯ࡤࡦࡱ࠽ࠤࡠࠦࠧஞ")+qmr7vLh1EW+RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠧࠡ࡟ࠪட"))
	T9GBdnhrvq = XUYb0K2ghSyFs.ListItem()
	lveMNOXYtUdkhLP6AQ,SXmIKu9NvQ7xrJbAD13T,FrwM7qSAvnPOoEkUYKBZI,meQp9gRv2XEwlZIJ6hnjx14,WrXzD4kdcPJvuwTgyFNoUS5bBVm,WMGuOVe86zTqa4inIY2Q,TZuiArS8UjVkW5Yol,O6KChzkWMQD4xZE1X,aiJjUnC0te6WgIXBclN2FEmvpf5PV = cIa9Spry0oqE(SzGukeylg5Nsr9M20WIan)
	if Dj051Gb2vsNOkuoTg not in [jSu5Cg2Ub1OAkZVs8Yoz(u"ࠨࡆࡒ࡛ࡓࡒࡏࡂࡆࠪ஠"),hhlbF1Sns5TrEN8QPCYmL4(u"ࠩࡌࡔ࡙࡜ࠧ஡")]:
		if V8fmEML1b0PeaRZySnzh3H5J9: p1gbPYy8qE0m4ju = vvHpKfcqRnrFzjG(u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭ࡢࡦࡧࡳࡳ࠭஢")
		else: p1gbPYy8qE0m4ju = C2jP0iLNGKnHu9xp(u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮ࠩண")
		T9GBdnhrvq.setProperty(p1gbPYy8qE0m4ju, LgpdP3UjFRnlX(u"ࠬ࠭த"))
		T9GBdnhrvq.setMimeType(QynMHGWA0blfqTUdxRh5Jzi2t(u"࠭࡭ࡪ࡯ࡨ࠳ࡽ࠳ࡴࡺࡲࡨࠫ஥"))
		if YSomBdvcNUMF3b8JDiCfrVW<QynMHGWA0blfqTUdxRh5Jzi2t(u"࠸࠰ౢ"): T9GBdnhrvq.setInfo(BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠧࡷ࡫ࡧࡩࡴ࠭஦"),{V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠨ࡯ࡨࡨ࡮ࡧࡴࡺࡲࡨࠫ஧"):k5dztomYyN3H(u"ࠩࡰࡳࡻ࡯ࡥࠨந")})
		else:
			mma7HylpdKhzvF6sNVoMXu9Y = T9GBdnhrvq.getVideoInfoTag()
			mma7HylpdKhzvF6sNVoMXu9Y.setMediaType(PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠪࡱࡴࡼࡩࡦࠩன"))
		T9GBdnhrvq.setArt({V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠫࡹ࡮ࡵ࡮ࡤࠪப"):WrXzD4kdcPJvuwTgyFNoUS5bBVm,QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠬࡶ࡯ࡴࡶࡨࡶࠬ஫"):WrXzD4kdcPJvuwTgyFNoUS5bBVm,nr5mZG89ICi6cgt4MfLJa0(u"࠭ࡢࡢࡰࡱࡩࡷ࠭஬"):WrXzD4kdcPJvuwTgyFNoUS5bBVm,l0WAe1f7Bpi5ZXk(u"ࠧࡧࡣࡱࡥࡷࡺࠧ஭"):WrXzD4kdcPJvuwTgyFNoUS5bBVm,WMkAjB1RgN7q(u"ࠨࡥ࡯ࡩࡦࡸࡡࡳࡶࠪம"):WrXzD4kdcPJvuwTgyFNoUS5bBVm,l0WAe1f7Bpi5ZXk(u"ࠩࡦࡰࡪࡧࡲ࡭ࡱࡪࡳࠬய"):WrXzD4kdcPJvuwTgyFNoUS5bBVm,nr5mZG89ICi6cgt4MfLJa0(u"ࠪࡰࡦࡴࡤࡴࡥࡤࡴࡪ࠭ர"):WrXzD4kdcPJvuwTgyFNoUS5bBVm,YB5xyI7MaRslVpv(u"ࠫ࡮ࡩ࡯࡯ࠩற"):WrXzD4kdcPJvuwTgyFNoUS5bBVm})
		if OzADck17lfuHqG2SYi in [PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠬ࠴࡭ࡱࡦࠪல"),YB5xyI7MaRslVpv(u"࠭࠮࡮࠵ࡸ࠼ࠬள")]: T9GBdnhrvq.setContentLookup(jSu5Cg2Ub1OAkZVs8Yoz(u"࡚ࡲࡶࡧ౷"))
		else: T9GBdnhrvq.setContentLookup(qbPw1d3KimF(u"ࡆࡢ࡮ࡶࡩ౸"))
		from gCUboaujSL import wOF6QJqepnRYNgv5cos13ljDtZzGd
		if BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠧࡳࡶࡰࡴࠬழ") in qmr7vLh1EW:
			wOF6QJqepnRYNgv5cos13ljDtZzGd(rbjsM8cRFiuA1(u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡲࡵ࡯ࡳࠫவ"),rbjsM8cRFiuA1(u"ࡇࡣ࡯ࡷࡪ౹"))
		elif OzADck17lfuHqG2SYi==b05yftsZ6NYgIKP(u"ࠩ࠱ࡱࡵࡪࠧஶ") or l0WAe1f7Bpi5ZXk(u"ࠪ࠳ࡩࡧࡳࡩ࠱ࠪஷ") in qmr7vLh1EW:
			wOF6QJqepnRYNgv5cos13ljDtZzGd(C2dgEDAKQGsvh(u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡤࡨࡦࡶࡴࡪࡸࡨࠫஸ"),v5EA6TqHX3s4jzBMk(u"ࡈࡤࡰࡸ࡫౺"))
			T9GBdnhrvq.setProperty(p1gbPYy8qE0m4ju,WMkAjB1RgN7q(u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡥࡩࡧࡰࡵ࡫ࡹࡩࠬஹ"))
			T9GBdnhrvq.setProperty(b05yftsZ6NYgIKP(u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠴࡭ࡢࡰ࡬ࡪࡪࡹࡴࡠࡶࡼࡴࡪ࠭஺"),UnWjVbo503mEMv9KF(u"ࠧ࡮ࡲࡧࠫ஻"))
		if uqGsld6kwze:
			T9GBdnhrvq.setSubtitles([uqGsld6kwze])
	if lveMNOXYtUdkhLP6AQ==C2dgEDAKQGsvh(u"ࠨࡸ࡬ࡨࡪࡵࠧ஼") and Dj051Gb2vsNOkuoTg==LgpdP3UjFRnlX(u"ࠩࡇࡓ࡜ࡔࡌࡐࡃࡇࠫ஽"):
		zEYqUpKhFlw = PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠪࡴࡱࡧࡹࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪா")
		Dj051Gb2vsNOkuoTg = YB5xyI7MaRslVpv(u"ࠫࡕࡒࡁ࡚ࡡࡇࡐࡤࡌࡉࡍࡇࡖࠫி")
	elif lveMNOXYtUdkhLP6AQ==nr5mZG89ICi6cgt4MfLJa0(u"ࠬࡼࡩࡥࡧࡲࠫீ") and O6KChzkWMQD4xZE1X.startswith(C2dgEDAKQGsvh(u"࠭࠶ࠨு")):
		zEYqUpKhFlw = rbjsM8cRFiuA1(u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥࠩூ")
		Dj051Gb2vsNOkuoTg = Dj051Gb2vsNOkuoTg+UnWjVbo503mEMv9KF(u"ࠨࡡࡇࡐࠬ௃")
	if zEYqUpKhFlw!=BoWHNb9daQVCF16A(u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ௄"): ivqDg9QFCIArMf1PO7WwU3lR()
	SKRa2rnO5LiTs = b4OhDw65jdr7XiPq()
	SKRa2rnO5LiTs.FF038EQdJXixAZGUjmHPt(Dj051Gb2vsNOkuoTg)
	if SKRa2rnO5LiTs.zEYqUpKhFlw: return WMkAjB1RgN7q(u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠫ௅")
	if lveMNOXYtUdkhLP6AQ==C2jP0iLNGKnHu9xp(u"ࠫࡻ࡯ࡤࡦࡱࠪெ") and not O6KChzkWMQD4xZE1X.startswith(BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠬ࠼ࠧே")):
		T9GBdnhrvq.setPath(qmr7vLh1EW)
		Lmj1pfQk63XdoeH(FGDJwkEbTB5SoXujs3f(u"࠭ࡎࡐࡖࡌࡇࡊ࠭ை"),Dwl0N6FKuVU8nB1mbisIrCzdO(baNWS6nfqTC5iX4Kl)+gItVahxL0w(u"࡚ࠧࠡࠢࠣ࡮ࡪࡥࡰࠢࡳࡰࡦࡿࠠࡶࡵ࡬ࡲ࡬ࠦࡳࡦࡶࡕࡩࡸࡵ࡬ࡷࡧࡧ࡙ࡷࡲࠨࠪࠢࠣࠤ࡛࡯ࡤࡦࡱ࠽ࠤࡠࠦࠧ௉")+qmr7vLh1EW+EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠨࠢࡠࠫொ"))
		VMKAudnbXHORPj.setResolvedUrl(n6ReHNYovBwFxiuJ,UnWjVbo503mEMv9KF(u"ࡗࡶࡺ࡫౻"),T9GBdnhrvq)
	elif lveMNOXYtUdkhLP6AQ==sRth5giAQzWlEVm7JOX(u"ࠩ࡯࡭ࡻ࡫ࠧோ"):
		Lmj1pfQk63XdoeH(QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠪࡒࡔ࡚ࡉࡄࡇࠪௌ"),Dwl0N6FKuVU8nB1mbisIrCzdO(baNWS6nfqTC5iX4Kl)+jx7s8T0BFgODXLMzIYedf(u"ࠫࠥࠦࠠࡍ࡫ࡹࡩࠥࡶ࡬ࡢࡻࠣࡹࡸ࡯࡮ࡨࠢࡳࡰࡦࡿࠨࠪࠢࠣࠤ࡛࡯ࡤࡦࡱ࠽ࠤࡠ்ࠦࠧ")+qmr7vLh1EW+UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠬࠦ࡝ࠨ௎"))
		SKRa2rnO5LiTs.play(qmr7vLh1EW,T9GBdnhrvq)
	tUEvo5HAfIjZgcdYxNJ8awu = EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࡊࡦࡲࡳࡦ౼")
	if zEYqUpKhFlw==rbjsM8cRFiuA1(u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤࠨ௏"):
		from NREgAj46Ve import oocnhjEKO9UpfkVgtPXyMCmwL
		tUEvo5HAfIjZgcdYxNJ8awu = oocnhjEKO9UpfkVgtPXyMCmwL(qmr7vLh1EW,OzADck17lfuHqG2SYi,Dj051Gb2vsNOkuoTg)
		if tUEvo5HAfIjZgcdYxNJ8awu: ivqDg9QFCIArMf1PO7WwU3lR()
	else:
		bbeYVRCXkUzsmN39,zEYqUpKhFlw,uImC4zJL8g6X,oxw1COaQSry5J9TNh7kvPHDnbWlp,XcBW4h8YEbAzRqtK6 = sRth5giAQzWlEVm7JOX(u"࠰ౣ"),jx7s8T0BFgODXLMzIYedf(u"ࠧࡵࡴ࡬ࡩࡩ࠭ௐ"),RqldvxFuM5GEQ2HAz93o7afBb0(u"ࡋࡧ࡬ࡴࡧ౽"),jx7s8T0BFgODXLMzIYedf(u"࠳࠳࠴࠵౥"),UnWjVbo503mEMv9KF(u"࠵࠷࠳࠴࠵౤")
		if Wdlo9EBTGLeY2ux: from G6AHskJeqN import gj7BGM5t3RZpA0vNixLqzwualb16
		while bbeYVRCXkUzsmN39<XcBW4h8YEbAzRqtK6:
			tUXmK5PeEH9SDq.sleep(oxw1COaQSry5J9TNh7kvPHDnbWlp)
			bbeYVRCXkUzsmN39 += oxw1COaQSry5J9TNh7kvPHDnbWlp
			if SKRa2rnO5LiTs.zEYqUpKhFlw==NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠨࡵࡷࡥࡷࡺࡥࡥࠩ௑") and not uImC4zJL8g6X:
				if Wdlo9EBTGLeY2ux: gj7BGM5t3RZpA0vNixLqzwualb16(QynMHGWA0blfqTUdxRh5Jzi2t(u"้ࠩะาะฺࠠ็็๎ฮࠦสี฼ํ่ࠥอไโ์า๎ํ࠭௒"),FGDJwkEbTB5SoXujs3f(u"ࠪࡗࡺࡩࡣࡦࡵࡶࠫ௓"),KBxPW9cX8dqtaUDG=BoWHNb9daQVCF16A(u"࠺࠹࠵౦"))
				Lmj1pfQk63XdoeH(fY5wTlhtnOc0Er6sdy4k87b(u"ࠫࡓࡕࡔࡊࡅࡈࡣࡑࡏࡎࡆࡕࠪ௔"),Dwl0N6FKuVU8nB1mbisIrCzdO(baNWS6nfqTC5iX4Kl)+BoWHNb9daQVCF16A(u"ࠬࠦࠠࠡࡕࡸࡧࡨ࡫ࡳࡴ࠼ࠣࠤ࡛࡯ࡤࡦࡱࠣࡷࡹࡧࡲࡵࡧࡧࠤࠥࠦࡖࡪࡦࡨࡳ࠿࡛ࠦࠡࠩ௕")+qmr7vLh1EW+UnWjVbo503mEMv9KF(u"࠭ࠠ࡞ࠩ௖")+TTI09H7J5O)
				uImC4zJL8g6X = UnWjVbo503mEMv9KF(u"࡚ࡲࡶࡧ౾")
			elif SKRa2rnO5LiTs.zEYqUpKhFlw in [fY5wTlhtnOc0Er6sdy4k87b(u"ࠧࡱ࡮ࡤࡽ࡮ࡴࡧࠨௗ"),QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠨࡶࡨࡷࡹ࡯࡮ࡨࠩ௘")]:
				Lmj1pfQk63XdoeH(PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠩࡑࡓ࡙ࡏࡃࡆࡡࡏࡍࡓࡋࡓࠨ௙"),Dwl0N6FKuVU8nB1mbisIrCzdO(baNWS6nfqTC5iX4Kl)+nr5mZG89ICi6cgt4MfLJa0(u"ࠪࠤࠥࠦࡓࡶࡥࡦࡩࡸࡹ࠺࡙ࠡࠢ࡭ࡩ࡫࡯ࠡࡲ࡯ࡥࡾ࡯࡮ࡨࠢࠣࠤ࡛࡯ࡤࡦࡱ࠽ࠤࡠࠦࠧ௚")+qmr7vLh1EW+BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠫࠥࡣࠧ௛")+TTI09H7J5O)
				break
			elif SKRa2rnO5LiTs.zEYqUpKhFlw==BoWHNb9daQVCF16A(u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬ௜"):
				Lmj1pfQk63XdoeH(YB5xyI7MaRslVpv(u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫ௝"),Dwl0N6FKuVU8nB1mbisIrCzdO(baNWS6nfqTC5iX4Kl)+PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠧࠡࠢࠣࡊࡦ࡯࡬ࡦࡦࠣࡴࡱࡧࡹࡪࡰࡪࠤࡻ࡯ࡤࡦࡱࠣࠤࠥ࡜ࡩࡥࡧࡲ࠾ࠥࡡࠠࠨ௞")+qmr7vLh1EW+v5EA6TqHX3s4jzBMk(u"ࠨࠢࡠࠫ௟")+TTI09H7J5O)
				if Wdlo9EBTGLeY2ux: gj7BGM5t3RZpA0vNixLqzwualb16(jSu5Cg2Ub1OAkZVs8Yoz(u"ࠩไุ้ะฺࠠ็็๎ฮࠦสี฼ํ่ࠥอไโ์า๎ํ࠭௠"),vvHpKfcqRnrFzjG(u"ࠪࡊࡦ࡯࡬ࡶࡴࡨࠫ௡"),KBxPW9cX8dqtaUDG=jSu5Cg2Ub1OAkZVs8Yoz(u"࠻࠺࠶౧"))
				break
			elif SKRa2rnO5LiTs.zEYqUpKhFlw==BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠫࡧࡲ࡯ࡤ࡭ࡨࡨࠬ௢"):
				Lmj1pfQk63XdoeH(NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠬࡋࡒࡓࡑࡕࠫ௣"),Dwl0N6FKuVU8nB1mbisIrCzdO(baNWS6nfqTC5iX4Kl)+V2RbfGOBdcA6l8NTsPWzEyvS7(u"࠭ࠠࠡࠢࡇࡩࡻ࡯ࡣࡦࠢ࡬ࡷࠥࡨ࡬ࡰࡥ࡮ࡩࡩࠦࠠࠡࡘ࡬ࡨࡪࡵ࠺ࠡ࡝ࠣࠫ௤")+qmr7vLh1EW+LgpdP3UjFRnlX(u"ࠧࠡ࡟ࠪ௥"))
				break
		else:
			if Wdlo9EBTGLeY2ux: gj7BGM5t3RZpA0vNixLqzwualb16(l0WAe1f7Bpi5ZXk(u"ࠨใื่ฯูࠦๆๆํอࠥะิ฻์็ࠤฬ๊แ๋ัํ์ࠬ௦"),v5EA6TqHX3s4jzBMk(u"ࠩࡗ࡭ࡲ࡫࡯ࡶࡶࠪ௧"),KBxPW9cX8dqtaUDG=nr5mZG89ICi6cgt4MfLJa0(u"࠼࠻࠰౨"))
			Lmj1pfQk63XdoeH(v5EA6TqHX3s4jzBMk(u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨ௨"),Dwl0N6FKuVU8nB1mbisIrCzdO(baNWS6nfqTC5iX4Kl)+C2dgEDAKQGsvh(u"ࠫࠥࠦࠠࡕ࡫ࡰࡩࡴࡻࡴ࠻࡙ࠢࠣࡳࡱ࡮ࡰࡹࡱࠤࡵࡸ࡯ࡣ࡮ࡨࡱࠥࠦࠠࡗ࡫ࡧࡩࡴࡀࠠ࡜ࠢࠪ௩")+qmr7vLh1EW+jx7s8T0BFgODXLMzIYedf(u"ࠬࠦ࡝ࠨ௪")+TTI09H7J5O)
			zEYqUpKhFlw = rbjsM8cRFiuA1(u"࠭ࡴࡪ࡯ࡨࡳࡺࡺࠧ௫")
	if zEYqUpKhFlw in [C2jP0iLNGKnHu9xp(u"ࠧࡱ࡮ࡤࡽࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ௬")] or SKRa2rnO5LiTs.zEYqUpKhFlw in [fY5wTlhtnOc0Er6sdy4k87b(u"ࠨࡲ࡯ࡥࡾ࡯࡮ࡨࠩ௭"),BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠩࡷࡩࡸࡺࡩ࡯ࡩࠪ௮")] or tUEvo5HAfIjZgcdYxNJ8awu:
		if SKRa2rnO5LiTs.zEYqUpKhFlw==BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠪࡸࡪࡹࡴࡪࡰࡪࠫ௯"): Dj051Gb2vsNOkuoTg = Dj051Gb2vsNOkuoTg+T6wRistc1SCo4hqObgumK(u"ࠫࡤ࡚ࡓࠨ௰")
		UMNteoHlkEy3Yf = KfuaVn4XrSGTUtLIw(Dj051Gb2vsNOkuoTg)
	else: exec(k5dztomYyN3H(u"ࠬ࡯࡭ࡱࡱࡵࡸࠥࡾࡢ࡮ࡥ࠾ࡼࡧࡳࡣ࠯ࡒ࡯ࡥࡾ࡫ࡲࠩࠫ࠱ࡷࡹࡵࡰࠩࠫࠪ௱"))
	return SKRa2rnO5LiTs.zEYqUpKhFlw
def REGCdFbgy4Vvu2ieLqNMlxntY(qmr7vLh1EW):
	if BLz7m2RkNrxXQwy1cGAp: from urllib.parse import urlparse
	else: from urlparse import urlparse
	path = urlparse(qmr7vLh1EW).path
	pOIBJQW9FzEaZi0N = RqldvxFuM5GEQ2HAz93o7afBb0(u"࠭ࠧ௲") if qbPw1d3KimF(u"ࠧ࠯ࠩ௳") not in path else path.rsplit(k5dztomYyN3H(u"ࠨ࠰ࠪ௴"),YB5xyI7MaRslVpv(u"࠷౩"))[YB5xyI7MaRslVpv(u"࠷౩")]
	if pOIBJQW9FzEaZi0N in [sRth5giAQzWlEVm7JOX(u"ࠩࡤࡺ࡮࠭௵"),NVS30xAdRFMIw1n9CislkE2(u"ࠪࡸࡸ࠭௶"),BoWHNb9daQVCF16A(u"ࠫࡦࡧࡣࠨ௷"),jx7s8T0BFgODXLMzIYedf(u"ࠬࡳࡰ࠵ࠩ௸"),qbPw1d3KimF(u"࠭࡭࠴ࡷࠪ௹"),NVS30xAdRFMIw1n9CislkE2(u"ࠧ࡮࠵ࡸ࠼ࠬ௺"),hhlbF1Sns5TrEN8QPCYmL4(u"ࠨ࡯ࡳࡨࠬ௻"),v5EA6TqHX3s4jzBMk(u"ࠩࡰ࡯ࡻ࠭௼"),jx7s8T0BFgODXLMzIYedf(u"ࠪࡪࡱࡼࠧ௽"),LgpdP3UjFRnlX(u"ࠫࡲࡶ࠳ࠨ௾"),BoWHNb9daQVCF16A(u"ࠬࡽࡥࡣ࡯ࠪ௿")]: return YB5xyI7MaRslVpv(u"࠭࠮ࠨఀ")+pOIBJQW9FzEaZi0N
	return C2dgEDAKQGsvh(u"ࠧࠨఁ")
# -*- coding: utf-8 -*-
from G6AHskJeqN import *
baNWS6nfqTC5iX4Kl = 'SHOOFMAX'
teUPLFC3B8bArakwHVGsdhoIWDM49f = '_SHM_'
EZxQp1WOldMTvFU = AK5RqLhji4W1wt9VdrCD3PGeQM[baNWS6nfqTC5iX4Kl][0]
oHxnAT1DzYQv = AK5RqLhji4W1wt9VdrCD3PGeQM[baNWS6nfqTC5iX4Kl][1]
aA1tX3Sy6lfxQ = AK5RqLhji4W1wt9VdrCD3PGeQM[baNWS6nfqTC5iX4Kl][2]
def VbgEajY4Bt2COpGDcPqI(mode,url,text):
	if   mode==50: ft3e2JBKQVXWlFPjaMhkEqGxvDg = eN02L7Tf5bQ()
	elif mode==51: ft3e2JBKQVXWlFPjaMhkEqGxvDg = sscM839DP1jWZ4zl6uIx0Kyn(url)
	elif mode==52: ft3e2JBKQVXWlFPjaMhkEqGxvDg = o4oY13v5dWMcbilEDjKCnXNzHZ0(url)
	elif mode==53: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HDxCnPKFhITpZmOsA4a0UL6(url)
	elif mode==55: ft3e2JBKQVXWlFPjaMhkEqGxvDg = VxXsiROkQbYNP7C()
	elif mode==56: ft3e2JBKQVXWlFPjaMhkEqGxvDg = H1AIVpPdGFKl32ti9vCxk0saQjMu()
	elif mode==57: ft3e2JBKQVXWlFPjaMhkEqGxvDg = KLhEQr7SM4k6bfWeVaBy51sXpP(url,1)
	elif mode==58: ft3e2JBKQVXWlFPjaMhkEqGxvDg = KLhEQr7SM4k6bfWeVaBy51sXpP(url,2)
	elif mode==59: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HjZcUIVAXFCqy9TfBWKtgY2(text)
	else: ft3e2JBKQVXWlFPjaMhkEqGxvDg = False
	return ft3e2JBKQVXWlFPjaMhkEqGxvDg
def eN02L7Tf5bQ():
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'بحث في الموقع','',59,'','','_REMEMBERRESULTS_')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'المسلسلات','',56)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'الافلام','',55)
	return ''
def VxXsiROkQbYNP7C():
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'أفلام مرتبة بسنة الإنتاج',EZxQp1WOldMTvFU+'/movie/1/yop',57)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'أفلام مرتبة بالأفضل تقييم',EZxQp1WOldMTvFU+'/movie/1/review',57)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'أفلام مرتبة بالأكثر مشاهدة',EZxQp1WOldMTvFU+'/movie/1/views',57)
	return
def H1AIVpPdGFKl32ti9vCxk0saQjMu():
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'مسلسلات مرتبة بسنة الإنتاج',EZxQp1WOldMTvFU+'/series/1/yop',57)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'مسلسلات مرتبة بالأفضل تقييم',EZxQp1WOldMTvFU+'/series/1/review',57)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'مسلسلات مرتبة بالأكثر مشاهدة',EZxQp1WOldMTvFU+'/series/1/views',57)
	return
def sscM839DP1jWZ4zl6uIx0Kyn(url):
	if '?' in url:
		tuHzpfZmLAdCObQS2k3 = url.split('?')
		url = tuHzpfZmLAdCObQS2k3[0]
		filter = '?' + F8fMqZKB4APk(tuHzpfZmLAdCObQS2k3[1],'=&:/%')
	else: filter = ''
	type,z3z9QgENFk5eMYB4,sort = url.split('/')[-3:]
	if sort in ['yop','review','views']:
		if type=='movie': FjDbpLOVQBJZToN='فيلم'
		elif type=='series': FjDbpLOVQBJZToN='مسلسل'
		url = EZxQp1WOldMTvFU + '/genre/filter/' + F8fMqZKB4APk(FjDbpLOVQBJZToN) + '/' + z3z9QgENFk5eMYB4 + '/' + sort + filter
		MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(UuEtImzir9,url,'','','','SHOOFMAX-TITLES-1st')
		items = My7Dwqvs6bfGNSIgX.findall('"pid":(.*?),.*?"ptitle":"(.*?)".+?"pepisodes":(.*?),"presbase":"(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		iaApe0uGM95o3TX1rtOnUW2Hx=0
		for id,title,ii0Fy13vhAY8s52jgpcNqBZoHL,IcWzVO137wFvemn2QTq8yKs9 in items:
			iaApe0uGM95o3TX1rtOnUW2Hx += 1
			IcWzVO137wFvemn2QTq8yKs9 = aA1tX3Sy6lfxQ + '/v2/img/program/main/' + IcWzVO137wFvemn2QTq8yKs9 + '-2.jpg'
			BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU + '/program/' + id
			if type=='movie': VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,53,IcWzVO137wFvemn2QTq8yKs9)
			if type=='series': VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'مسلسل '+title,BoEFz2WhUyvTgDeiZ+'?ep='+ii0Fy13vhAY8s52jgpcNqBZoHL+'='+title+'='+IcWzVO137wFvemn2QTq8yKs9,52,IcWzVO137wFvemn2QTq8yKs9)
	else:
		if type=='movie': FjDbpLOVQBJZToN='movies'
		elif type=='series': FjDbpLOVQBJZToN='series'
		url = oHxnAT1DzYQv + '/json/selected/' + sort + '-' + FjDbpLOVQBJZToN + '-WW.json'
		MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(UuEtImzir9,url,'','','','SHOOFMAX-TITLES-2nd')
		items = My7Dwqvs6bfGNSIgX.findall('"ref":(.*?),"ep":(.*?),"base":"(.*?)","title":"(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		iaApe0uGM95o3TX1rtOnUW2Hx=0
		for id,ii0Fy13vhAY8s52jgpcNqBZoHL,IcWzVO137wFvemn2QTq8yKs9,title in items:
			iaApe0uGM95o3TX1rtOnUW2Hx += 1
			IcWzVO137wFvemn2QTq8yKs9 = oHxnAT1DzYQv + '/img/program/' + IcWzVO137wFvemn2QTq8yKs9 + '-2.jpg'
			BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU + '/program/' + id
			if type=='movie': VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,53,IcWzVO137wFvemn2QTq8yKs9)
			elif type=='series': VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'مسلسل '+title,BoEFz2WhUyvTgDeiZ+'?ep='+ii0Fy13vhAY8s52jgpcNqBZoHL+'='+title+'='+IcWzVO137wFvemn2QTq8yKs9,52,IcWzVO137wFvemn2QTq8yKs9)
	title='صفحة '
	if iaApe0uGM95o3TX1rtOnUW2Hx==16:
		for sQd8Tjic9h in range(1,13) :
			if not z3z9QgENFk5eMYB4==str(sQd8Tjic9h):
				url = EZxQp1WOldMTvFU+'/genre/filter/'+type+'/'+str(sQd8Tjic9h)+'/'+sort+filter
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title+str(sQd8Tjic9h),url,51)
	return
def o4oY13v5dWMcbilEDjKCnXNzHZ0(url):
	tuHzpfZmLAdCObQS2k3 = url.split('=')
	ii0Fy13vhAY8s52jgpcNqBZoHL = int(tuHzpfZmLAdCObQS2k3[1])
	name = XnQbsZF0Ouh8p7zCdUN(tuHzpfZmLAdCObQS2k3[2])
	name = name.replace('_MOD_مسلسل ','')
	IcWzVO137wFvemn2QTq8yKs9 = tuHzpfZmLAdCObQS2k3[3]
	url = url.split('?')[0]
	if ii0Fy13vhAY8s52jgpcNqBZoHL==0:
		MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(UuEtImzir9,url,'','','','SHOOFMAX-EPISODES-1st')
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('<select(.*?)</select>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('option value="(.*?)"',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		ii0Fy13vhAY8s52jgpcNqBZoHL = int(items[-1])
	for ffhN7jAqe3Q4cR0Ukptzl in range(ii0Fy13vhAY8s52jgpcNqBZoHL,0,-1):
		BoEFz2WhUyvTgDeiZ = url + '?ep=' + str(ffhN7jAqe3Q4cR0Ukptzl)
		title = '_MOD_مسلسل '+name+' - الحلقة '+str(ffhN7jAqe3Q4cR0Ukptzl)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,53,IcWzVO137wFvemn2QTq8yKs9)
	return
def HDxCnPKFhITpZmOsA4a0UL6(url):
	MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(IIiPCruL6dT8s1lqj47SzpVHnYNm,url,'','','','SHOOFMAX-PLAY-1st')
	UMC7vtBHpLJzN8gQKjVSXwi1dxkG = My7Dwqvs6bfGNSIgX.findall('متوفر على شوف ماكس بعد.*?moment\("(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if UMC7vtBHpLJzN8gQKjVSXwi1dxkG:
		KBxPW9cX8dqtaUDG = UMC7vtBHpLJzN8gQKjVSXwi1dxkG[1].replace('T','    ')
		ZIOHgA3z0TBR('','','رسالة من الموقع الأصلي','هذا الفيديو سيكون متوفر على شوف ماكس بعد هذا الوقت'+'\n'+KBxPW9cX8dqtaUDG)
		return
	yTSoHlPMA9784I0nJhmNt5iUF,DF5K07IptRXWh = [],[]
	Qp7myGJPX9IjYS1b = My7Dwqvs6bfGNSIgX.findall('var origin_link = "(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)[0]
	McIE25AuPJC9eDQ8w = My7Dwqvs6bfGNSIgX.findall('var backup_origin_link = "(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)[0]
	NVHrZsqUp2 = My7Dwqvs6bfGNSIgX.findall('hls: (.*?)_link\+"(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	for LkVZrOE4XBSN2Qex5PyHqC,BoEFz2WhUyvTgDeiZ in NVHrZsqUp2:
		if 'backup' in LkVZrOE4XBSN2Qex5PyHqC:
			LkVZrOE4XBSN2Qex5PyHqC = 'backup server'
			url = McIE25AuPJC9eDQ8w + BoEFz2WhUyvTgDeiZ
		else:
			LkVZrOE4XBSN2Qex5PyHqC = 'main server'
			url = Qp7myGJPX9IjYS1b + BoEFz2WhUyvTgDeiZ
		if '.m3u8' in url:
			yTSoHlPMA9784I0nJhmNt5iUF.append(url)
			DF5K07IptRXWh.append('m3u8  '+LkVZrOE4XBSN2Qex5PyHqC)
	NVHrZsqUp2 = My7Dwqvs6bfGNSIgX.findall('mp4:.*?_link.*?\t(.*?)_link\+"(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	NVHrZsqUp2 += My7Dwqvs6bfGNSIgX.findall('mp4:.*?\t(.*?)_link\+"(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	for LkVZrOE4XBSN2Qex5PyHqC,BoEFz2WhUyvTgDeiZ in NVHrZsqUp2:
		filename = BoEFz2WhUyvTgDeiZ.split('/')[-1]
		filename = filename.replace('fallback','')
		filename = filename.replace('.mp4','')
		filename = filename.replace('-','')
		if 'backup' in LkVZrOE4XBSN2Qex5PyHqC:
			LkVZrOE4XBSN2Qex5PyHqC = 'backup server'
			url = McIE25AuPJC9eDQ8w + BoEFz2WhUyvTgDeiZ
		else:
			LkVZrOE4XBSN2Qex5PyHqC = 'main server'
			url = Qp7myGJPX9IjYS1b + BoEFz2WhUyvTgDeiZ
		yTSoHlPMA9784I0nJhmNt5iUF.append(url)
		DF5K07IptRXWh.append('mp4  '+LkVZrOE4XBSN2Qex5PyHqC+'  '+filename)
	GOtNfU3xQFkEhPouwA = CnKwdteDG5BE8MTRhUpYIJm3NLrSgq('Select Video Quality:', DF5K07IptRXWh)
	if GOtNfU3xQFkEhPouwA == -1 : return
	url = yTSoHlPMA9784I0nJhmNt5iUF[GOtNfU3xQFkEhPouwA]
	B0xcwKkMQ16mpSFRaVHPTzuhUZngLq(url,baNWS6nfqTC5iX4Kl,'video')
	return
def KLhEQr7SM4k6bfWeVaBy51sXpP(url,type):
	if 'series' in url: bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = EZxQp1WOldMTvFU + '/genre/مسلسل'
	else: bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = EZxQp1WOldMTvFU + '/genre/فيلم'
	bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = F8fMqZKB4APk(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1)
	MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(IIiPCruL6dT8s1lqj47SzpVHnYNm,bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,'','','','SHOOFMAX-FILTERS-1st')
	if type==1: XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('subgenre(.*?)div',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	elif type==2: XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('country(.*?)div',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	vsptNMP2ZQC = XBuP6Op7y4K[0]
	items = My7Dwqvs6bfGNSIgX.findall('option value="(.*?)">(.*?)</option',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	if type==1:
		for x1RXfjcOQrzI,title in items:
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,url+'?subgenre='+x1RXfjcOQrzI,58)
	elif type==2:
		url,x1RXfjcOQrzI = url.split('?')
		for KTL7OP3spfChQm9n8UudYMDt,title in items:
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,url+'?country='+KTL7OP3spfChQm9n8UudYMDt+'&'+x1RXfjcOQrzI,51)
	return
def HjZcUIVAXFCqy9TfBWKtgY2(search):
	search,LQf3AeozSrai,showDialogs = X54MLovbG8nAEkB9J(search)
	if not search: search = ViKAIsLurq83RSENayxWb()
	if not search: return
	ystIEd371fLkT50pcRUWi9olNDu = search.replace(' ','%20')
	url = EZxQp1WOldMTvFU+'/search?q='+ystIEd371fLkT50pcRUWi9olNDu
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'','',True,'','SHOOFMAX-SEARCH-2nd')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('general-body(.*?)search-bottom-padding',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	vsptNMP2ZQC = XBuP6Op7y4K[0]
	items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?background-image: url\((.*?)\).*?<span>(.*?)</span>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	if items:
		for BoEFz2WhUyvTgDeiZ,IcWzVO137wFvemn2QTq8yKs9,title in items:
			url = EZxQp1WOldMTvFU + BoEFz2WhUyvTgDeiZ
			if '/program/' in url:
				if '?ep=' in url:
					title = '_MOD_مسلسل '+title
					url = url.replace('?ep=1','?ep=0')
					url = url+'='+F8fMqZKB4APk(title)+'='+IcWzVO137wFvemn2QTq8yKs9
					VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,url,52,IcWzVO137wFvemn2QTq8yKs9)
				else:
					title = '_MOD_فيلم '+title
					VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,url,53,IcWzVO137wFvemn2QTq8yKs9)
	return
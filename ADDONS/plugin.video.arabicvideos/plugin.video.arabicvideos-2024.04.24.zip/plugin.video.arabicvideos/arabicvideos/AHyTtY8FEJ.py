# -*- coding: utf-8 -*-
from G6AHskJeqN import *
headers = { 'User-Agent' : '' }
baNWS6nfqTC5iX4Kl = 'AKWAM'
teUPLFC3B8bArakwHVGsdhoIWDM49f = '_AKW_'
EZxQp1WOldMTvFU = AK5RqLhji4W1wt9VdrCD3PGeQM[baNWS6nfqTC5iX4Kl][0]
QQVLDC6gs8TXnh = ''
eh2tDvRFWpLQI = ['ألعاب','المصارعة الحرة','القران الكريم','الكتب و الابحاث','الصور و الخلفيات','المسلسلات الاذاعية']
def VbgEajY4Bt2COpGDcPqI(mode,url,text):
	if   mode==240: ft3e2JBKQVXWlFPjaMhkEqGxvDg = eN02L7Tf5bQ()
	elif mode==241: ft3e2JBKQVXWlFPjaMhkEqGxvDg = sscM839DP1jWZ4zl6uIx0Kyn(url,text)
	elif mode==242: ft3e2JBKQVXWlFPjaMhkEqGxvDg = o4oY13v5dWMcbilEDjKCnXNzHZ0(url)
	elif mode==243: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HDxCnPKFhITpZmOsA4a0UL6(url)
	elif mode==244: ft3e2JBKQVXWlFPjaMhkEqGxvDg = LLJlTxDePyjoVKA(url,'FILTERS___'+text)
	elif mode==245: ft3e2JBKQVXWlFPjaMhkEqGxvDg = LLJlTxDePyjoVKA(url,'CATEGORIES___'+text)
	elif mode==246: ft3e2JBKQVXWlFPjaMhkEqGxvDg = Xxa4Ef8z0bUCeq2gDNhdH5(url)
	elif mode==247: ft3e2JBKQVXWlFPjaMhkEqGxvDg = kkwOGtEscDKbfNUjIXL(url)
	elif mode==248: ft3e2JBKQVXWlFPjaMhkEqGxvDg = Qxuk51dcg60NyfTWqZnF7oz()
	elif mode==249: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HjZcUIVAXFCqy9TfBWKtgY2(text)
	else: ft3e2JBKQVXWlFPjaMhkEqGxvDg = False
	return ft3e2JBKQVXWlFPjaMhkEqGxvDg
def Qxuk51dcg60NyfTWqZnF7oz():
	ZIOHgA3z0TBR('','','رسالة من المبرمج','هذا الموقع "أكوام الجديد" في بعض الأحيان فيه نوع من الحجب ضد البرامج . وهذا يسبب مشكلة في تشغيل الفيديوهات . هذه المشكلة سببها من الموقع الأصلي وهي تظهر وتختفي بصورة عشوائية')
	return
def eN02L7Tf5bQ():
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',EZxQp1WOldMTvFU,'',headers,'','','AKWAM-MENU-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	kQpzjq4YruIXZg209HdN = My7Dwqvs6bfGNSIgX.findall('home-site-btn-container.*?href="(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if kQpzjq4YruIXZg209HdN: kQpzjq4YruIXZg209HdN = kQpzjq4YruIXZg209HdN[0]
	else: kQpzjq4YruIXZg209HdN = EZxQp1WOldMTvFU
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',kQpzjq4YruIXZg209HdN,'',headers,'','','AKWAM-MENU-2nd')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'بحث في الموقع','',249,'','','_REMEMBERRESULTS_')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'فلتر محدد',EZxQp1WOldMTvFU,246)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'فلتر كامل',EZxQp1WOldMTvFU,247)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'المميزة',kQpzjq4YruIXZg209HdN,241,'','','featured')
	recent = My7Dwqvs6bfGNSIgX.findall('recently-container.*?href="(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	BoEFz2WhUyvTgDeiZ = recent[0]
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'أضيف حديثا',BoEFz2WhUyvTgDeiZ,241)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('mb-4 d-flex align-items-center.*?href="(.*?)".*?class="header-link text-white">(.*?)<.*?class="menu"(.*?)</div>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	for BoEFz2WhUyvTgDeiZ,name,vsptNMP2ZQC in XBuP6Op7y4K:
		if name in eh2tDvRFWpLQI: continue
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+name,BoEFz2WhUyvTgDeiZ,241)
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)">(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title in items:
			if title in eh2tDvRFWpLQI: continue
			title = name+' '+title
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,241)
	return
def Xxa4Ef8z0bUCeq2gDNhdH5(website=''):
	MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(IIiPCruL6dT8s1lqj47SzpVHnYNm,EZxQp1WOldMTvFU,'',headers,'','AKWAM-MENU-1st')
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('class="menu(.*?)<nav',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?text">(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title in items:
			if title not in eh2tDvRFWpLQI:
				title = title+' مصنفة'
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,245)
		if website=='': VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	return MK6ZT2zjC1SbmveNFqor
def kkwOGtEscDKbfNUjIXL(website=''):
	MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(IIiPCruL6dT8s1lqj47SzpVHnYNm,EZxQp1WOldMTvFU,'',headers,'','AKWAM-MENU-1st')
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('class="menu(.*?)<nav',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?text">(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title in items:
			if title not in eh2tDvRFWpLQI:
				title = title+' مفلترة'
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,244)
		if website=='': VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	return MK6ZT2zjC1SbmveNFqor
def sscM839DP1jWZ4zl6uIx0Kyn(url,type=''):
	MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(UuEtImzir9,url,'',headers,True,'AKWAM-TITLES-1st')
	if type=='featured': XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('swiper-container(.*?)swiper-button-prev',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	else: XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('class="widget"(.*?)main-footer',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('data-src="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		if not items:
			items = My7Dwqvs6bfGNSIgX.findall('src="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for IcWzVO137wFvemn2QTq8yKs9,BoEFz2WhUyvTgDeiZ,title in items:
			if '/series/' in BoEFz2WhUyvTgDeiZ or '/shows/' in BoEFz2WhUyvTgDeiZ:
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,242,IcWzVO137wFvemn2QTq8yKs9)
			elif '/movies/' in BoEFz2WhUyvTgDeiZ:
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,243,IcWzVO137wFvemn2QTq8yKs9)
			elif '/games/' not in BoEFz2WhUyvTgDeiZ:
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,243,IcWzVO137wFvemn2QTq8yKs9)
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('pagination(.*?)</div>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?>(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title in items:
			if title=='&lsaquo;': title = 'سابقة'
			if title=='&rsaquo;': title = 'لاحقة'
			BoEFz2WhUyvTgDeiZ = PIfAumbGicwg5ye(BoEFz2WhUyvTgDeiZ)
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'صفحة '+title,BoEFz2WhUyvTgDeiZ,241)
	return
def HjZcUIVAXFCqy9TfBWKtgY2(search):
	search,LQf3AeozSrai,showDialogs = X54MLovbG8nAEkB9J(search)
	if search=='': search = ViKAIsLurq83RSENayxWb()
	if search=='': return
	ystIEd371fLkT50pcRUWi9olNDu = search.replace(' ','%20')
	url = EZxQp1WOldMTvFU + '/search?q='+ystIEd371fLkT50pcRUWi9olNDu
	ft3e2JBKQVXWlFPjaMhkEqGxvDg = sscM839DP1jWZ4zl6uIx0Kyn(url)
	return
def o4oY13v5dWMcbilEDjKCnXNzHZ0(url):
	MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(UuEtImzir9,url,'',headers,True,'AKWAM-EPISODES-1st')
	if '-episodes">' not in MK6ZT2zjC1SbmveNFqor:
		IcWzVO137wFvemn2QTq8yKs9 = tUXmK5PeEH9SDq.getInfoLabel('ListItem.Icon')
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+'رابط التشغيل',url,243,IcWzVO137wFvemn2QTq8yKs9)
	else:
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('-episodes">(.*?)<div class="widget-4',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		o93oJVvuQUY = My7Dwqvs6bfGNSIgX.findall('href="(http.*?)".*?>(.*?)<.*?src="(.*?)"',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title,IcWzVO137wFvemn2QTq8yKs9 in o93oJVvuQUY:
			title = title.replace('  ',' ')
			if 'الحلقات' in title or 'مواسم اخرى' in title: continue
			if '/series/' in BoEFz2WhUyvTgDeiZ: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,242,IcWzVO137wFvemn2QTq8yKs9)
			else: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,243,IcWzVO137wFvemn2QTq8yKs9)
	return
def HDxCnPKFhITpZmOsA4a0UL6(url):
	MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(IIiPCruL6dT8s1lqj47SzpVHnYNm,url,'',headers,True,'AKWAM-PLAY-1st')
	ME2Q6F7u8Vp1km9ws = My7Dwqvs6bfGNSIgX.findall('badge-danger.*?>(.*?)<',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if ME2Q6F7u8Vp1km9ws and a97xrkSOefH5DbjXunq(baNWS6nfqTC5iX4Kl,url,ME2Q6F7u8Vp1km9ws): return
	DDgrys4UPlf2a6oRMqiG = My7Dwqvs6bfGNSIgX.findall('li><a href="#(.*?)".*?>(.*?)<',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	QQ2cE1FjUyxPonbDhaTkV6B3i,wlfZEzuRyYLvrp,xAcIatGBYy0FLXroS1ig3Ts9KZ8P5,ayJf25679SxLkmCAs = [],[],[],[]
	if DDgrys4UPlf2a6oRMqiG:
		WK75AGwvEzJZTNLQB1 = 'mp4'
		for yWb8NnAZ39RqXm2Si,LLnUyuiC2wRM0 in DDgrys4UPlf2a6oRMqiG:
			XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('tab-content quality" id="'+yWb8NnAZ39RqXm2Si+'".*?</div>.\s*</div>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
			vsptNMP2ZQC = XBuP6Op7y4K[0]
			xAcIatGBYy0FLXroS1ig3Ts9KZ8P5.append(vsptNMP2ZQC)
			ayJf25679SxLkmCAs.append(LLnUyuiC2wRM0)
	else:
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('class="qualities(.*?)<h3.*?>(.*?)<',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if not XBuP6Op7y4K:
			ZIOHgA3z0TBR('','','رسالة من المبرمج','لا يوجد ملف فيديو في هذا الرابط')
			return
		else:
			vsptNMP2ZQC,filename = XBuP6Op7y4K[0]
			Jv3hwKiE1tCxajp0dZF4Gm2ykXz = ['zip','rar','txt','pdf','htm','tar','iso','html']
			WK75AGwvEzJZTNLQB1 = filename.rsplit('.',1)[1].strip(' ')
			if WK75AGwvEzJZTNLQB1 in Jv3hwKiE1tCxajp0dZF4Gm2ykXz:
				ZIOHgA3z0TBR('','','رسالة من المبرمج','الملف ليس فيديو ولا صوت')
				return
		xAcIatGBYy0FLXroS1ig3Ts9KZ8P5.append(vsptNMP2ZQC)
		ayJf25679SxLkmCAs.append('')
	for FVW0I9sYcAjmDgn8r in range(len(xAcIatGBYy0FLXroS1ig3Ts9KZ8P5)):
		NVHrZsqUp2 = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?icon-(.*?)"',xAcIatGBYy0FLXroS1ig3Ts9KZ8P5[FVW0I9sYcAjmDgn8r],My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,bbSXyVxPjO243 in NVHrZsqUp2:
			if 'torrent' in bbSXyVxPjO243: continue
			elif 'download' in bbSXyVxPjO243: type = 'download'
			elif 'play' in bbSXyVxPjO243: type = 'watch'
			else: type = 'unknown'
			BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ+'?named=__'+type+'____'+ayJf25679SxLkmCAs[FVW0I9sYcAjmDgn8r]+'__akwam'
			QQ2cE1FjUyxPonbDhaTkV6B3i.append(BoEFz2WhUyvTgDeiZ)
	import t1kDWXQVpC
	t1kDWXQVpC.rqVt2xDi7jzJHBcPMRs6h0L(QQ2cE1FjUyxPonbDhaTkV6B3i,baNWS6nfqTC5iX4Kl,'video',url)
	return
def LLJlTxDePyjoVKA(url,filter):
	vIZKhbfsXmWAyUVecrNOz95LQ = ['section','category','year','rating']
	if '?' in url: url = url.split('?')[0]
	type,filter = filter.split('___',1)
	if filter=='': H2HMwT4JFz7rDkPZmRjcX,JPnr9ICqkDyV = '',''
	else: H2HMwT4JFz7rDkPZmRjcX,JPnr9ICqkDyV = filter.split('___')
	if type=='CATEGORIES':
		if vIZKhbfsXmWAyUVecrNOz95LQ[0]+'=' not in H2HMwT4JFz7rDkPZmRjcX: g4Y0BXLxCpuojKP1SAUtcq7TwN2 = vIZKhbfsXmWAyUVecrNOz95LQ[0]
		for FVW0I9sYcAjmDgn8r in range(len(vIZKhbfsXmWAyUVecrNOz95LQ[0:-1])):
			if vIZKhbfsXmWAyUVecrNOz95LQ[FVW0I9sYcAjmDgn8r]+'=' in H2HMwT4JFz7rDkPZmRjcX: g4Y0BXLxCpuojKP1SAUtcq7TwN2 = vIZKhbfsXmWAyUVecrNOz95LQ[FVW0I9sYcAjmDgn8r+1]
		HHXeMqVOshPcW3tULa5v = H2HMwT4JFz7rDkPZmRjcX+'&'+g4Y0BXLxCpuojKP1SAUtcq7TwN2+'=0'
		DoSfCckGA9BQe = JPnr9ICqkDyV+'&'+g4Y0BXLxCpuojKP1SAUtcq7TwN2+'=0'
		A7AEKRlF6Hf3eWVxY0NdwgsMPCc = HHXeMqVOshPcW3tULa5v.strip('&')+'___'+DoSfCckGA9BQe.strip('&')
		woj78rBnbLlmZWIy19iPHFCf5 = BrbZhHKJ0jnIe2lumE9M(JPnr9ICqkDyV,'all')
		bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = url+'?'+woj78rBnbLlmZWIy19iPHFCf5
	elif type=='FILTERS':
		WUSylLup41cYkhVXGtq = BrbZhHKJ0jnIe2lumE9M(H2HMwT4JFz7rDkPZmRjcX,'modified_values')
		WUSylLup41cYkhVXGtq = XnQbsZF0Ouh8p7zCdUN(WUSylLup41cYkhVXGtq)
		if JPnr9ICqkDyV!='': JPnr9ICqkDyV = BrbZhHKJ0jnIe2lumE9M(JPnr9ICqkDyV,'all')
		if JPnr9ICqkDyV=='': bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = url
		else: bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = url+'?'+JPnr9ICqkDyV
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'أظهار قائمة الفيديو التي تم اختيارها',bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,241,'','1')
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+' [[   '+WUSylLup41cYkhVXGtq+'   ]]',bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,241,'','1')
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(IIiPCruL6dT8s1lqj47SzpVHnYNm,url,'',headers,True,'AKWAM-FILTERS_MENU-1st')
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('<form id(.*?)</form>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	vsptNMP2ZQC = XBuP6Op7y4K[0]
	E3ErsLQfR4JXt = My7Dwqvs6bfGNSIgX.findall('<select.*?name="(.*?)".*?">(.*?)<(.*?)</select>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	dict = {}
	for RTsbVE9CiQt,name,vsptNMP2ZQC in E3ErsLQfR4JXt:
		items = My7Dwqvs6bfGNSIgX.findall('<option(.*?)>(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		if '=' not in bJEs4IVAPdyUrhwCLv9k2YoOl8nt1: bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = url
		if type=='CATEGORIES':
			if g4Y0BXLxCpuojKP1SAUtcq7TwN2!=RTsbVE9CiQt: continue
			elif len(items)<=1:
				if RTsbVE9CiQt==vIZKhbfsXmWAyUVecrNOz95LQ[-1]: sscM839DP1jWZ4zl6uIx0Kyn(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1)
				else: LLJlTxDePyjoVKA(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,'CATEGORIES___'+A7AEKRlF6Hf3eWVxY0NdwgsMPCc)
				return
			else:
				if RTsbVE9CiQt==vIZKhbfsXmWAyUVecrNOz95LQ[-1]: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'الجميع',bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,241,'','1')
				else: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'الجميع',bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,245,'','',A7AEKRlF6Hf3eWVxY0NdwgsMPCc)
		elif type=='FILTERS':
			HHXeMqVOshPcW3tULa5v = H2HMwT4JFz7rDkPZmRjcX+'&'+RTsbVE9CiQt+'=0'
			DoSfCckGA9BQe = JPnr9ICqkDyV+'&'+RTsbVE9CiQt+'=0'
			A7AEKRlF6Hf3eWVxY0NdwgsMPCc = HHXeMqVOshPcW3tULa5v+'___'+DoSfCckGA9BQe
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'الجميع : '+name,bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,244,'','',A7AEKRlF6Hf3eWVxY0NdwgsMPCc)
		dict[RTsbVE9CiQt] = {}
		for WoFrX46wzbCNp18,A5AMg7LY1HlOz0B82n in items:
			if A5AMg7LY1HlOz0B82n in eh2tDvRFWpLQI: continue
			if 'value' not in WoFrX46wzbCNp18: WoFrX46wzbCNp18 = A5AMg7LY1HlOz0B82n
			else: WoFrX46wzbCNp18 = My7Dwqvs6bfGNSIgX.findall('"(.*?)"',WoFrX46wzbCNp18,My7Dwqvs6bfGNSIgX.DOTALL)[0]
			dict[RTsbVE9CiQt][WoFrX46wzbCNp18] = A5AMg7LY1HlOz0B82n
			HHXeMqVOshPcW3tULa5v = H2HMwT4JFz7rDkPZmRjcX+'&'+RTsbVE9CiQt+'='+A5AMg7LY1HlOz0B82n
			DoSfCckGA9BQe = JPnr9ICqkDyV+'&'+RTsbVE9CiQt+'='+WoFrX46wzbCNp18
			QQIzTLCXyhtZ7pRNnGq = HHXeMqVOshPcW3tULa5v+'___'+DoSfCckGA9BQe
			title = A5AMg7LY1HlOz0B82n+' : '#+dict[RTsbVE9CiQt]['0']
			title = A5AMg7LY1HlOz0B82n+' : '+name
			if type=='FILTERS': VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,url,244,'','',QQIzTLCXyhtZ7pRNnGq)
			elif type=='CATEGORIES' and vIZKhbfsXmWAyUVecrNOz95LQ[-2]+'=' in H2HMwT4JFz7rDkPZmRjcX:
				woj78rBnbLlmZWIy19iPHFCf5 = BrbZhHKJ0jnIe2lumE9M(DoSfCckGA9BQe,'all')
				QAKdHzO0rehbtyIc = url+'?'+woj78rBnbLlmZWIy19iPHFCf5
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,QAKdHzO0rehbtyIc,241,'','1')
			else: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,url,245,'','',QQIzTLCXyhtZ7pRNnGq)
	return
def BrbZhHKJ0jnIe2lumE9M(PPebqkulZUsx3GCLdnYvR,mode):
	PPebqkulZUsx3GCLdnYvR = PPebqkulZUsx3GCLdnYvR.strip('&')
	mVSjqdOvyf = {}
	if '=' in PPebqkulZUsx3GCLdnYvR:
		items = PPebqkulZUsx3GCLdnYvR.split('&')
		for ZA1fBenNahOR3xrkjvwYSVMy6JK5s in items:
			nmqEj60bcdSQoFPGa,WoFrX46wzbCNp18 = ZA1fBenNahOR3xrkjvwYSVMy6JK5s.split('=')
			mVSjqdOvyf[nmqEj60bcdSQoFPGa] = WoFrX46wzbCNp18
	DidZH6E0pJelcU9xMCBgyL2KvR = ''
	lWF7u5qUtSak3B = ['section','category','rating','year','language','formats','quality']
	for key in lWF7u5qUtSak3B:
		if key in list(mVSjqdOvyf.keys()): WoFrX46wzbCNp18 = mVSjqdOvyf[key]
		else: WoFrX46wzbCNp18 = '0'
		if mode=='modified_values' and WoFrX46wzbCNp18!='0': DidZH6E0pJelcU9xMCBgyL2KvR = DidZH6E0pJelcU9xMCBgyL2KvR+' + '+WoFrX46wzbCNp18
		elif mode=='modified_filters' and WoFrX46wzbCNp18!='0': DidZH6E0pJelcU9xMCBgyL2KvR = DidZH6E0pJelcU9xMCBgyL2KvR+'&'+key+'='+WoFrX46wzbCNp18
		elif mode=='all': DidZH6E0pJelcU9xMCBgyL2KvR = DidZH6E0pJelcU9xMCBgyL2KvR+'&'+key+'='+WoFrX46wzbCNp18
	DidZH6E0pJelcU9xMCBgyL2KvR = DidZH6E0pJelcU9xMCBgyL2KvR.strip(' + ')
	DidZH6E0pJelcU9xMCBgyL2KvR = DidZH6E0pJelcU9xMCBgyL2KvR.strip('&')
	return DidZH6E0pJelcU9xMCBgyL2KvR
# -*- coding: utf-8 -*-
from G6AHskJeqN import *
baNWS6nfqTC5iX4Kl = 'CIMAFANS'
headers = { 'User-Agent' : '' }
teUPLFC3B8bArakwHVGsdhoIWDM49f = '_CMF_'
EZxQp1WOldMTvFU = AK5RqLhji4W1wt9VdrCD3PGeQM[baNWS6nfqTC5iX4Kl][0]
def VbgEajY4Bt2COpGDcPqI(mode,url,text):
	if   mode==90: ft3e2JBKQVXWlFPjaMhkEqGxvDg = eN02L7Tf5bQ()
	elif mode==91: ft3e2JBKQVXWlFPjaMhkEqGxvDg = TJZvpKG2we(url)
	elif mode==92: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HDxCnPKFhITpZmOsA4a0UL6(url)
	elif mode==94: ft3e2JBKQVXWlFPjaMhkEqGxvDg = jteCU2z0EY4J6dFA()
	elif mode==95: ft3e2JBKQVXWlFPjaMhkEqGxvDg = o4oY13v5dWMcbilEDjKCnXNzHZ0(url)
	elif mode==99: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HjZcUIVAXFCqy9TfBWKtgY2(text)
	else: ft3e2JBKQVXWlFPjaMhkEqGxvDg = False
	return ft3e2JBKQVXWlFPjaMhkEqGxvDg
def eN02L7Tf5bQ():
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'بحث في الموقع','',99,'','','_REMEMBERRESULTS_')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'المضاف حديثا','',94)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'الأحدث',EZxQp1WOldMTvFU+'/?type=latest',91)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'الأعلى تقيماً',EZxQp1WOldMTvFU+'/?type=imdb',91)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'الأكثر مشاهدة',EZxQp1WOldMTvFU+'/?type=view',91)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'المثبت',EZxQp1WOldMTvFU+'/?type=pin',91)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'جديد الأفلام',EZxQp1WOldMTvFU+'/?type=newMovies',91)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'جديد الحلقات',EZxQp1WOldMTvFU+'/?type=newEpisodes',91)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(IIiPCruL6dT8s1lqj47SzpVHnYNm,EZxQp1WOldMTvFU,'',headers,'','CIMAFANS-MENU-1st')
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('class="mainmenu(.*?)nav',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	vsptNMP2ZQC = XBuP6Op7y4K[0]
	items = My7Dwqvs6bfGNSIgX.findall('<li><a href="(.*?)".*?>(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	eh2tDvRFWpLQI = ['افلام للكبار فقط']
	for BoEFz2WhUyvTgDeiZ,title in items:
		title = title.strip(' ')
		if not any(WoFrX46wzbCNp18 in title for WoFrX46wzbCNp18 in eh2tDvRFWpLQI):
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,91)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('class="f-cats"(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	vsptNMP2ZQC = XBuP6Op7y4K[0]
	items = My7Dwqvs6bfGNSIgX.findall('<li><a href="(.*?)".*?>(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	for BoEFz2WhUyvTgDeiZ,title in items:
		title = title.strip(' ')
		if not any(WoFrX46wzbCNp18 in title for WoFrX46wzbCNp18 in eh2tDvRFWpLQI):
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,91)
	return MK6ZT2zjC1SbmveNFqor
def TJZvpKG2we(url):
	if '/search.php' in url:
		url,search = url.split('?t=')
		headers = { 'User-Agent' : '' , 'Content-Type' : 'application/x-www-form-urlencoded' }
		data = { 't' : search }
		xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'POST',url,data,headers,'','','CIMAFANS-ITEMS-1st')
		MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	else:
		headers = { 'User-Agent' : '' }
		MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(UuEtImzir9,url,'',headers,'','CIMAFANS-ITEMS-2nd')
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('id="movies-items(.*?)class="listfoot"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K: vsptNMP2ZQC = XBuP6Op7y4K[0]
	else: vsptNMP2ZQC = ''
	items = My7Dwqvs6bfGNSIgX.findall('background-image:url\((.*?)\).*?href="(.*?)".*?movie-title">(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	y7y3d5Fbhv42ONmtwLZ0SerYoQq = []
	for IcWzVO137wFvemn2QTq8yKs9,BoEFz2WhUyvTgDeiZ,title in items:
		if 'الحلقة' in title and '/c/' not in url and '/cat/' not in url:
			ffhN7jAqe3Q4cR0Ukptzl = My7Dwqvs6bfGNSIgX.findall('(.*?) الحلقة [0-9]+',title,My7Dwqvs6bfGNSIgX.DOTALL)
			if ffhN7jAqe3Q4cR0Ukptzl:
				title = '_MOD_'+ffhN7jAqe3Q4cR0Ukptzl[0]
				if title not in y7y3d5Fbhv42ONmtwLZ0SerYoQq:
					VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,95,IcWzVO137wFvemn2QTq8yKs9)
					y7y3d5Fbhv42ONmtwLZ0SerYoQq.append(title)
		elif '/video/' in BoEFz2WhUyvTgDeiZ: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,92,IcWzVO137wFvemn2QTq8yKs9)
		else: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,91,IcWzVO137wFvemn2QTq8yKs9)
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('class="pagination(.*?)div',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('<a href="(.*?)".*?>(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title in items:
			title = PIfAumbGicwg5ye(title)
			title = title.replace('الصفحة ','')
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'صفحة '+title,BoEFz2WhUyvTgDeiZ,91)
	return
def o4oY13v5dWMcbilEDjKCnXNzHZ0(url):
	MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(UuEtImzir9,url,'',headers,'','CIMAFANS-EPISODES-1st')
	IcWzVO137wFvemn2QTq8yKs9 = My7Dwqvs6bfGNSIgX.findall('img src="(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	IcWzVO137wFvemn2QTq8yKs9 = IcWzVO137wFvemn2QTq8yKs9[0]
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('id="episodes-panel(.*?)div',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		name = My7Dwqvs6bfGNSIgX.findall('itemprop="title">(.*?)<',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if name: name = name[1]
		else:
			name = tUXmK5PeEH9SDq.getInfoLabel('ListItem.Label')
			if '[/COLOR]' in name: name = name.split('[/COLOR]',1)[1]
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?name">(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title in items:
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+name+' - '+title,BoEFz2WhUyvTgDeiZ,92,IcWzVO137wFvemn2QTq8yKs9)
	else:
		AwKc1kuJ7V = My7Dwqvs6bfGNSIgX.findall('class="movietitle"><a href="(.*?)">(.*?)<',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if AwKc1kuJ7V: BoEFz2WhUyvTgDeiZ,title = AwKc1kuJ7V[0]
		else: BoEFz2WhUyvTgDeiZ,title = url,name
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,92,IcWzVO137wFvemn2QTq8yKs9)
	return
def HDxCnPKFhITpZmOsA4a0UL6(url):
	QQ2cE1FjUyxPonbDhaTkV6B3i,rUBO1RZhI9LVvjlozNeEFJ8dT = [],[]
	MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(UuEtImzir9,url,'',headers,'','CIMAFANS-PLAY-1st')
	ME2Q6F7u8Vp1km9ws = My7Dwqvs6bfGNSIgX.findall('text-shadow: none;">(.*?)<',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if ME2Q6F7u8Vp1km9ws and a97xrkSOefH5DbjXunq(baNWS6nfqTC5iX4Kl,url,ME2Q6F7u8Vp1km9ws): return
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('id="links-panel(.*?)div',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)"',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ in items:
			BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ+'?__download'
			QQ2cE1FjUyxPonbDhaTkV6B3i.append(BoEFz2WhUyvTgDeiZ)
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('nav-tabs"(.*?)video-panel-more',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('id="(.*?)".*?embed src="(.*?)"',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for id,BoEFz2WhUyvTgDeiZ in items:
			title = 'سيرفر '+id
			BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ+'?named='+title+'__watch'
			QQ2cE1FjUyxPonbDhaTkV6B3i.append(BoEFz2WhUyvTgDeiZ)
		items = My7Dwqvs6bfGNSIgX.findall('data-server-src="(.*?)"',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ in items:
			if 'http' not in BoEFz2WhUyvTgDeiZ: BoEFz2WhUyvTgDeiZ = 'http:'+BoEFz2WhUyvTgDeiZ
			BoEFz2WhUyvTgDeiZ = XnQbsZF0Ouh8p7zCdUN(BoEFz2WhUyvTgDeiZ)
			QQ2cE1FjUyxPonbDhaTkV6B3i.append(BoEFz2WhUyvTgDeiZ)
	import t1kDWXQVpC
	t1kDWXQVpC.rqVt2xDi7jzJHBcPMRs6h0L(QQ2cE1FjUyxPonbDhaTkV6B3i,baNWS6nfqTC5iX4Kl,'video',url)
	return
def jteCU2z0EY4J6dFA():
	MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(UuEtImzir9,EZxQp1WOldMTvFU,'',headers,'','CIMAFANS-LATEST-1st')
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('id="index-last-movie(.*?)id="index-slider-movie',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	vsptNMP2ZQC = XBuP6Op7y4K[0]
	items = My7Dwqvs6bfGNSIgX.findall('src="(.*?)".*?href="(.*?)" title="(.*?)"',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	for IcWzVO137wFvemn2QTq8yKs9,BoEFz2WhUyvTgDeiZ,title in items:
		if '/video/' in BoEFz2WhUyvTgDeiZ: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,92,IcWzVO137wFvemn2QTq8yKs9)
		else: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,91,IcWzVO137wFvemn2QTq8yKs9)
	return
def HjZcUIVAXFCqy9TfBWKtgY2(search):
	search,LQf3AeozSrai,showDialogs = X54MLovbG8nAEkB9J(search)
	if search=='': search = ViKAIsLurq83RSENayxWb()
	if search=='': return
	search = search.replace(' ','+')
	url = EZxQp1WOldMTvFU + '/search.php?t='+search
	TJZvpKG2we(url)
	return
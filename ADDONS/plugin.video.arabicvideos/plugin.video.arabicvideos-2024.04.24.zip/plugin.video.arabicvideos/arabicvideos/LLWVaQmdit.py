# -*- coding: utf-8 -*-
from G6AHskJeqN import *
baNWS6nfqTC5iX4Kl = 'EGYBEST3'
teUPLFC3B8bArakwHVGsdhoIWDM49f = '_EB3_'
EZxQp1WOldMTvFU = AK5RqLhji4W1wt9VdrCD3PGeQM[baNWS6nfqTC5iX4Kl][0]
eh2tDvRFWpLQI = ['المصارعة الحرة','ايجي بست','التصميم الجديد','عروض المصارعة','مكتبتي','ايجي بست الجديد','ايجي بست البديل','egybest','موقع ايجي بست','موقع نتفليكس']
def VbgEajY4Bt2COpGDcPqI(mode,url,z3z9QgENFk5eMYB4,text):
	if   mode==790: ft3e2JBKQVXWlFPjaMhkEqGxvDg = eN02L7Tf5bQ()
	elif mode==791: ft3e2JBKQVXWlFPjaMhkEqGxvDg = sscM839DP1jWZ4zl6uIx0Kyn(url,z3z9QgENFk5eMYB4)
	elif mode==792: ft3e2JBKQVXWlFPjaMhkEqGxvDg = M25iOAH9NfalvyPEUuToG8qn(url)
	elif mode==793: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HDxCnPKFhITpZmOsA4a0UL6(url)
	elif mode==796: ft3e2JBKQVXWlFPjaMhkEqGxvDg = rFZB0V49nigPyfKQHqcLXEs(url,z3z9QgENFk5eMYB4)
	elif mode==799: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HjZcUIVAXFCqy9TfBWKtgY2(text)
	else: ft3e2JBKQVXWlFPjaMhkEqGxvDg = False
	return ft3e2JBKQVXWlFPjaMhkEqGxvDg
def eN02L7Tf5bQ():
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(IIiPCruL6dT8s1lqj47SzpVHnYNm,'GET',EZxQp1WOldMTvFU,'','','','','EGYBEST3-MENU-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('list-pages(.*?)fa-folder',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?<span>(.*?)</span>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title in items:
			title = title.strip(' ')
			if any(WoFrX46wzbCNp18 in title for WoFrX46wzbCNp18 in eh2tDvRFWpLQI): continue
			if 'http' not in BoEFz2WhUyvTgDeiZ: BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU+BoEFz2WhUyvTgDeiZ
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,791)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('main-article(.*?)social-box',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('main-title.*?">(.*?)<.*?href="(.*?)"',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for title,BoEFz2WhUyvTgDeiZ in items:
			title = title.strip(' ')
			if any(WoFrX46wzbCNp18 in title for WoFrX46wzbCNp18 in eh2tDvRFWpLQI): continue
			if 'http' not in BoEFz2WhUyvTgDeiZ: BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU+BoEFz2WhUyvTgDeiZ
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,791,'','mainmenu')
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('main-menu(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)">(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title in items:
			title = title.strip(' ')
			if any(WoFrX46wzbCNp18 in title for WoFrX46wzbCNp18 in eh2tDvRFWpLQI): continue
			if 'http' not in BoEFz2WhUyvTgDeiZ: BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU+BoEFz2WhUyvTgDeiZ
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,791)
	return MK6ZT2zjC1SbmveNFqor
def rFZB0V49nigPyfKQHqcLXEs(url,type=''):
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'','','','','EGYBEST3-SEASONS_EPISODES-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('main-article".*?">(.*?)<(.*?)article',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		Or0yBIEzGeCn6pkYDgRal78F,o93oJVvuQUY,items = '','',[]
		for name,vsptNMP2ZQC in XBuP6Op7y4K:
			if 'حلقات' in name: o93oJVvuQUY = vsptNMP2ZQC
			if 'مواسم' in name: Or0yBIEzGeCn6pkYDgRal78F = vsptNMP2ZQC
		if Or0yBIEzGeCn6pkYDgRal78F and not type:
			items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?data-src="(.*?)".*?"title">(.*?)<',Or0yBIEzGeCn6pkYDgRal78F,My7Dwqvs6bfGNSIgX.DOTALL)
			if len(items)>1:
				for BoEFz2WhUyvTgDeiZ,IcWzVO137wFvemn2QTq8yKs9,title in items:
					VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,796,IcWzVO137wFvemn2QTq8yKs9,'season')
		if o93oJVvuQUY and len(items)<2:
			items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?data-src="(.*?)".*?class="title">(.*?)<',o93oJVvuQUY,My7Dwqvs6bfGNSIgX.DOTALL)
			if items:
				for BoEFz2WhUyvTgDeiZ,IcWzVO137wFvemn2QTq8yKs9,title in items:
					VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,793,IcWzVO137wFvemn2QTq8yKs9)
			else:
				items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)">(.*?)<',o93oJVvuQUY,My7Dwqvs6bfGNSIgX.DOTALL)
				for BoEFz2WhUyvTgDeiZ,title in items:
					VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,793)
	return
def sscM839DP1jWZ4zl6uIx0Kyn(url,type=''):
	qoR5F8fzNGvyY4dI6rjPOUlW,start,ssINGezFJnxfcU,select,r9ixWQPNzf4Be6TYqcHoRVwm8EM7a = 0,0,'','',''
	if 'pagination' in type:
		cpQysrOzk6K5PW,data = NgD0bJaq14yBnMYoziAmLj(url)
		qoR5F8fzNGvyY4dI6rjPOUlW = int(data['limit'])
		start = int(data['start'])
		ssINGezFJnxfcU = data['type']
		select = data['select']
		toAVQS46Fv8aJYyLf25KnkUNC = 'limit='+str(qoR5F8fzNGvyY4dI6rjPOUlW)+'&start='+str(start)+'&type='+ssINGezFJnxfcU+'&select='+select
		eIL9BxdTbZj = {'Content-Type':'application/x-www-form-urlencoded'}
		xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'POST',cpQysrOzk6K5PW,toAVQS46Fv8aJYyLf25KnkUNC,eIL9BxdTbZj,'','','EGYBEST3-TITLES-1st')
		MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
		wN6n7OZBoDkTvCi8LdbJjYV = 'blocks'+MK6ZT2zjC1SbmveNFqor+'article'
	else:
		xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'','','','','EGYBEST3-TITLES-2nd')
		MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
		wN6n7OZBoDkTvCi8LdbJjYV = MK6ZT2zjC1SbmveNFqor
		code = My7Dwqvs6bfGNSIgX.findall("<script>(var.*?=.*?;var.*?=.*?;var.*?=.*?;var.*?=.*?;var.*?=.*?);</script>",MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if code:
			code = code[0].replace('var','').replace(' ','').replace("'",'').replace(';','&')
			wLWTRZQNlpACcvdFU3Vo,data = NgD0bJaq14yBnMYoziAmLj('?'+code)
			qoR5F8fzNGvyY4dI6rjPOUlW = int(data['limit'])
			start = int(data['start'])
			ssINGezFJnxfcU = data['type']
			select = data['select']
			r9ixWQPNzf4Be6TYqcHoRVwm8EM7a = data['ajaxurl']
			toAVQS46Fv8aJYyLf25KnkUNC = 'limit='+str(qoR5F8fzNGvyY4dI6rjPOUlW)+'&start='+str(start)+'&type='+ssINGezFJnxfcU+'&select='+select
			cpQysrOzk6K5PW = EZxQp1WOldMTvFU+r9ixWQPNzf4Be6TYqcHoRVwm8EM7a
			eIL9BxdTbZj = {'Content-Type':'application/x-www-form-urlencoded'}
			xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'POST',cpQysrOzk6K5PW,toAVQS46Fv8aJYyLf25KnkUNC,eIL9BxdTbZj,'','','EGYBEST3-TITLES-3rd')
			wN6n7OZBoDkTvCi8LdbJjYV = xHb86g9WZqPwRfVjXD2JalzSIp.content
			wN6n7OZBoDkTvCi8LdbJjYV = 'blocks'+wN6n7OZBoDkTvCi8LdbJjYV+'article'
	items,LrPu5D8XJ1FpxhYvyz2l,PPebqkulZUsx3GCLdnYvR = [],False,False
	if not type:
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('main-content(.*?)</div>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if XBuP6Op7y4K:
			vsptNMP2ZQC = XBuP6Op7y4K[0]
			items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?</i>(.*?)</a>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
			for BoEFz2WhUyvTgDeiZ,title in items:
				title = title.strip(' ')
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,791,'','submenu')
				LrPu5D8XJ1FpxhYvyz2l = True
	if not type:
		PPebqkulZUsx3GCLdnYvR = KLhEQr7SM4k6bfWeVaBy51sXpP(MK6ZT2zjC1SbmveNFqor)
	if not LrPu5D8XJ1FpxhYvyz2l and not PPebqkulZUsx3GCLdnYvR:
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('blocks(.*?)article',wN6n7OZBoDkTvCi8LdbJjYV,My7Dwqvs6bfGNSIgX.DOTALL)
		if XBuP6Op7y4K:
			vsptNMP2ZQC = XBuP6Op7y4K[0]
			items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?src="(.*?)".*?class="title">(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
			for BoEFz2WhUyvTgDeiZ,IcWzVO137wFvemn2QTq8yKs9,title in items:
				IcWzVO137wFvemn2QTq8yKs9 = IcWzVO137wFvemn2QTq8yKs9.strip('\n')
				BoEFz2WhUyvTgDeiZ = XnQbsZF0Ouh8p7zCdUN(BoEFz2WhUyvTgDeiZ)
				if '/selary/' in BoEFz2WhUyvTgDeiZ: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,791,IcWzVO137wFvemn2QTq8yKs9)
				elif 'مسلسل' in BoEFz2WhUyvTgDeiZ and 'حلقة' not in BoEFz2WhUyvTgDeiZ: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,796,IcWzVO137wFvemn2QTq8yKs9)
				elif 'موسم' in BoEFz2WhUyvTgDeiZ and 'حلقة' not in BoEFz2WhUyvTgDeiZ: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,796,IcWzVO137wFvemn2QTq8yKs9)
				else: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,793,IcWzVO137wFvemn2QTq8yKs9)
		KKkapdn7Slo50RfXYTGJ6cgZ = 12
		data = My7Dwqvs6bfGNSIgX.findall('class="(load-more.*?)<',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if len(items)==KKkapdn7Slo50RfXYTGJ6cgZ and (data or 'pagination' in type):
			toAVQS46Fv8aJYyLf25KnkUNC = 'limit='+str(KKkapdn7Slo50RfXYTGJ6cgZ)+'&start='+str(start+KKkapdn7Slo50RfXYTGJ6cgZ)+'&type='+ssINGezFJnxfcU+'&select='+select
			bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = cpQysrOzk6K5PW+'?next=page&'+toAVQS46Fv8aJYyLf25KnkUNC
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'المزيد',bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,791,'','pagination_'+type)
	return
def KLhEQr7SM4k6bfWeVaBy51sXpP(MK6ZT2zjC1SbmveNFqor):
	PPebqkulZUsx3GCLdnYvR = False
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('main-article(.*?)article',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		xAcIatGBYy0FLXroS1ig3Ts9KZ8P5 = My7Dwqvs6bfGNSIgX.findall('data-tax="(.*?)".*?<span>(.*?)<(.*?)</ul>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		if xAcIatGBYy0FLXroS1ig3Ts9KZ8P5: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
		for g4Y0BXLxCpuojKP1SAUtcq7TwN2,name,vsptNMP2ZQC in xAcIatGBYy0FLXroS1ig3Ts9KZ8P5:
			name = name.strip(' ')
			items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)">(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
			for BoEFz2WhUyvTgDeiZ,WoFrX46wzbCNp18 in items:
				title = name+':  '+WoFrX46wzbCNp18
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,791,'','filter')
				PPebqkulZUsx3GCLdnYvR = True
	return PPebqkulZUsx3GCLdnYvR
def HDxCnPKFhITpZmOsA4a0UL6(url):
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(SToQEHqGtMnAlFbCz4wxBDuOsmW7,'GET',url,'','','','','EGYBEST3-PLAY-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	Qki8AbTHYjzM2Ls76Gdr3eqo1Wn,uuseD16TiQ30VKlZxgm = [],[]
	items = My7Dwqvs6bfGNSIgX.findall('server-item.*?data-code="(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	for lLawp58CZrkEozdDiPh7jRM3ceA in items:
		o0oyKvMLHRDb3z2J = NfzkjQicS24ZYLMWuXFRwV5Ea7.b64decode(lLawp58CZrkEozdDiPh7jRM3ceA)
		if BLz7m2RkNrxXQwy1cGAp: o0oyKvMLHRDb3z2J = o0oyKvMLHRDb3z2J.decode('utf8')
		BoEFz2WhUyvTgDeiZ = My7Dwqvs6bfGNSIgX.findall('src="(.*?)"',o0oyKvMLHRDb3z2J,My7Dwqvs6bfGNSIgX.DOTALL)
		if BoEFz2WhUyvTgDeiZ:
			BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ[0]
			if BoEFz2WhUyvTgDeiZ not in uuseD16TiQ30VKlZxgm:
				uuseD16TiQ30VKlZxgm.append(BoEFz2WhUyvTgDeiZ)
				LkVZrOE4XBSN2Qex5PyHqC = ooq2D9xF8ZLpPBs(BoEFz2WhUyvTgDeiZ,'name')
				Qki8AbTHYjzM2Ls76Gdr3eqo1Wn.append(BoEFz2WhUyvTgDeiZ+'?named='+LkVZrOE4XBSN2Qex5PyHqC+'__watch')
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('class="downloads(.*?)</section>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('"tr flex-start".*?<div>[ a-zA-Z]*(\d{3,4})[ a-zA-Z]*</div>.*?href="(.*?)"',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for LLnUyuiC2wRM0,BoEFz2WhUyvTgDeiZ in items:
			if BoEFz2WhUyvTgDeiZ not in uuseD16TiQ30VKlZxgm:
				if '/?url=' in BoEFz2WhUyvTgDeiZ: BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ.split('/?url=')[1]
				uuseD16TiQ30VKlZxgm.append(BoEFz2WhUyvTgDeiZ)
				LkVZrOE4XBSN2Qex5PyHqC = ooq2D9xF8ZLpPBs(BoEFz2WhUyvTgDeiZ,'name')
				Qki8AbTHYjzM2Ls76Gdr3eqo1Wn.append(BoEFz2WhUyvTgDeiZ+'?named='+LkVZrOE4XBSN2Qex5PyHqC+'__download____'+LLnUyuiC2wRM0)
	import t1kDWXQVpC
	t1kDWXQVpC.rqVt2xDi7jzJHBcPMRs6h0L(Qki8AbTHYjzM2Ls76Gdr3eqo1Wn,baNWS6nfqTC5iX4Kl,'video',url)
	return
def HjZcUIVAXFCqy9TfBWKtgY2(text):
	return
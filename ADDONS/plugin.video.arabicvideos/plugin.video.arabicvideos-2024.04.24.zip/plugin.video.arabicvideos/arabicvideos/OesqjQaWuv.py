# -*- coding: utf-8 -*-
from G6AHskJeqN import *
baNWS6nfqTC5iX4Kl = 'GLOBALSEARCH'
teUPLFC3B8bArakwHVGsdhoIWDM49f = '_GLS_'
def VbgEajY4Bt2COpGDcPqI(H3HDqY5N4e0fWSXMikZ8CR7suUmJdx,SCakygtHx0AUXbO3emswB9F8,Gfsr6KpyVRovQmB8xcXUJ,z3z9QgENFk5eMYB4):
	if   H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==540: ft3e2JBKQVXWlFPjaMhkEqGxvDg = eN02L7Tf5bQ()
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==541: ft3e2JBKQVXWlFPjaMhkEqGxvDg = SC5MRP8Ef1FaOspVctdeY(Gfsr6KpyVRovQmB8xcXUJ)
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==542: ft3e2JBKQVXWlFPjaMhkEqGxvDg = k3BLKoEYRFJZWnIN(Gfsr6KpyVRovQmB8xcXUJ,SCakygtHx0AUXbO3emswB9F8,z3z9QgENFk5eMYB4)
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==549: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HjZcUIVAXFCqy9TfBWKtgY2(Gfsr6KpyVRovQmB8xcXUJ)
	else: ft3e2JBKQVXWlFPjaMhkEqGxvDg = False
	return ft3e2JBKQVXWlFPjaMhkEqGxvDg
def eN02L7Tf5bQ():
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','بحث جديد','',549)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008]==== كلمات مخزنة ====[/COLOR]','',9999)
	ffMHQogy9uKIU5TwF3aVBWxs = zPgNsqpJInt(RnqtMUa9Nh6peGEsBT,'dict','GLOBALSEARCH_SITES')
	if ffMHQogy9uKIU5TwF3aVBWxs:
		ffMHQogy9uKIU5TwF3aVBWxs = ffMHQogy9uKIU5TwF3aVBWxs['__SEQUENCED_COLUMNS__']
		for J05JvhlNWgdBnH1SOzYFey3Pw9u in reversed(ffMHQogy9uKIU5TwF3aVBWxs):
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',J05JvhlNWgdBnH1SOzYFey3Pw9u,'',549,'','',J05JvhlNWgdBnH1SOzYFey3Pw9u)
	return
def HjZcUIVAXFCqy9TfBWKtgY2(J05JvhlNWgdBnH1SOzYFey3Pw9u):
	if not J05JvhlNWgdBnH1SOzYFey3Pw9u:
		J05JvhlNWgdBnH1SOzYFey3Pw9u = ViKAIsLurq83RSENayxWb()
		if not J05JvhlNWgdBnH1SOzYFey3Pw9u: return
		J05JvhlNWgdBnH1SOzYFey3Pw9u = J05JvhlNWgdBnH1SOzYFey3Pw9u.lower()
	SzODUMcwsHkNf4IlY = J05JvhlNWgdBnH1SOzYFey3Pw9u.replace(teUPLFC3B8bArakwHVGsdhoIWDM49f,'')
	Uj7WBECu5wX8a3K(SzODUMcwsHkNf4IlY)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','عمل بحث جماعي - '+SzODUMcwsHkNf4IlY,'search_sites',542,'','',SzODUMcwsHkNf4IlY)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','نتائج البحث مفصلة - '+SzODUMcwsHkNf4IlY,'opened_sites',542,'','',SzODUMcwsHkNf4IlY)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','نتائج البحث مقسمة - '+SzODUMcwsHkNf4IlY,'listed_sites',542,'','',SzODUMcwsHkNf4IlY)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','بحث منفرد - '+SzODUMcwsHkNf4IlY,'',541,'','',SzODUMcwsHkNf4IlY)
	return
def Uj7WBECu5wX8a3K(NNdxfjUH6SGiDRu):
	GGZ8KMmH3DYxUv = zPgNsqpJInt(RnqtMUa9Nh6peGEsBT,'list','GLOBALSEARCH_SITES',NNdxfjUH6SGiDRu)
	ytZxQO0WNrMpj4 = zPgNsqpJInt(RnqtMUa9Nh6peGEsBT,'list','GLOBALSEARCH_SITES',teUPLFC3B8bArakwHVGsdhoIWDM49f+NNdxfjUH6SGiDRu)
	qkSCcaj2fg4VO7dl3G9IhJBs5DLx(RnqtMUa9Nh6peGEsBT,'GLOBALSEARCH_SITES',NNdxfjUH6SGiDRu)
	qkSCcaj2fg4VO7dl3G9IhJBs5DLx(RnqtMUa9Nh6peGEsBT,'GLOBALSEARCH_SITES',teUPLFC3B8bArakwHVGsdhoIWDM49f+NNdxfjUH6SGiDRu)
	McAWVyh3D8m = GGZ8KMmH3DYxUv+ytZxQO0WNrMpj4
	if McAWVyh3D8m: NNdxfjUH6SGiDRu = teUPLFC3B8bArakwHVGsdhoIWDM49f+NNdxfjUH6SGiDRu
	VZ8BTik93OqXLCh0fD7d2KUPpn4mH6(RnqtMUa9Nh6peGEsBT,'GLOBALSEARCH_SITES',NNdxfjUH6SGiDRu,McAWVyh3D8m,HTNv70wWuCxtU)
	return
def ivAPY3Fo1M():
	tLwvQlnjGpWsRVCN1 = mmwySO1P4jnKz5('','','','رسالة من المبرمج','هل تريد مسح جميع كلمات البحث المخزنة في البرنامج ؟!!')
	if tLwvQlnjGpWsRVCN1!=1: return
	qkSCcaj2fg4VO7dl3G9IhJBs5DLx(RnqtMUa9Nh6peGEsBT,'GLOBALSEARCH_SITES')
	qkSCcaj2fg4VO7dl3G9IhJBs5DLx(RnqtMUa9Nh6peGEsBT,'GLOBALSEARCH_OPENED')
	qkSCcaj2fg4VO7dl3G9IhJBs5DLx(RnqtMUa9Nh6peGEsBT,'GLOBALSEARCH_CLOSED')
	ZIOHgA3z0TBR('','','رسالة من المبرمج','تم بنجاح مسح جميع كلمات البحث المخزنة في البرنامج')
	return
def k3BLKoEYRFJZWnIN(mMdUNZvQ5V,FhnackY1VEXD8oHqfl3bO,bo1dqzR8JIwlThvDcyU4jf=''):
	ggJWmUQyaD4ONBifYe,KQdxkYIrTezsRa8lim5jNODE,CnurEb51Oo8FpXUIvmN0T,uWBjIlmtXJQ,mhBiQCNG0E67sxUWzY3AeOdP,SvbDs9ArxQfhpcG36Rl,hd3iCjBnNGAUzlKWEsqx2c4e = [],[],[],{},{},{},{}
	if FhnackY1VEXD8oHqfl3bO!='search_sites':
		if FhnackY1VEXD8oHqfl3bO=='listed_sites': CnurEb51Oo8FpXUIvmN0T = zPgNsqpJInt(RnqtMUa9Nh6peGEsBT,'list','GLOBALSEARCH_SITES',teUPLFC3B8bArakwHVGsdhoIWDM49f+mMdUNZvQ5V)
		elif FhnackY1VEXD8oHqfl3bO=='opened_sites': CnurEb51Oo8FpXUIvmN0T = zPgNsqpJInt(RnqtMUa9Nh6peGEsBT,'list','GLOBALSEARCH_OPENED',mMdUNZvQ5V)
		elif FhnackY1VEXD8oHqfl3bO=='closed_sites': CnurEb51Oo8FpXUIvmN0T = zPgNsqpJInt(RnqtMUa9Nh6peGEsBT,'list','GLOBALSEARCH_CLOSED',(bo1dqzR8JIwlThvDcyU4jf,mMdUNZvQ5V))
	if not CnurEb51Oo8FpXUIvmN0T:
		ZPXx9tplQ10D2skiFHqb = 'هذا البحث غير موجود في كاش البرنامج \n\n\n'
		UUdtxEKOHDTq5YkcWLvg = 'هل تريد الآن البحث في جميع المواقع عن \n "[COLOR FFFFFF00] '+mMdUNZvQ5V+' [/COLOR]" \n علما أن هذا البحث قد يحتاج بعض الوقت'
		if FhnackY1VEXD8oHqfl3bO=='search_sites': mR4VLhryYT2koGU6iBX = UUdtxEKOHDTq5YkcWLvg
		else: mR4VLhryYT2koGU6iBX = ZPXx9tplQ10D2skiFHqb+UUdtxEKOHDTq5YkcWLvg
		tLwvQlnjGpWsRVCN1 = mmwySO1P4jnKz5('','','','رسالة من المبرمج',mR4VLhryYT2koGU6iBX)
		if tLwvQlnjGpWsRVCN1!=1: return
		YRi6vEsJ05kd8Bo9UtbpzlVn2(False,False,False)
		Lmj1pfQk63XdoeH('NOTICE',Dwl0N6FKuVU8nB1mbisIrCzdO(baNWS6nfqTC5iX4Kl)+'   Search For: [ '+mMdUNZvQ5V+' ]')
		Pgd3rY8O1URkvnyQxeE = 1
		for bo1dqzR8JIwlThvDcyU4jf in odSGnmzHxgF:
			uWBjIlmtXJQ[bo1dqzR8JIwlThvDcyU4jf] = []
			khALrUNtziB3gX = '_NODIALOGS_'
			if '-' in bo1dqzR8JIwlThvDcyU4jf: khALrUNtziB3gX = khALrUNtziB3gX+'_REMEMBERRESULTS__'+bo1dqzR8JIwlThvDcyU4jf+'_'
			JoakAQ4uiT5,dZT40j7heA1zsu3Nak,rrFcwfjUW34gaDKp2mHNB58Azbs = RB0138fEQHwDFGn(bo1dqzR8JIwlThvDcyU4jf)
			if Pgd3rY8O1URkvnyQxeE:
				KBxPW9cX8dqtaUDG.sleep(0.75)
				hd3iCjBnNGAUzlKWEsqx2c4e[bo1dqzR8JIwlThvDcyU4jf] = iDocG6BXv7fT2z8UVOxgP.Thread(target=dZT40j7heA1zsu3Nak,args=(mMdUNZvQ5V+khALrUNtziB3gX,))
				hd3iCjBnNGAUzlKWEsqx2c4e[bo1dqzR8JIwlThvDcyU4jf].start()
			else: dZT40j7heA1zsu3Nak(mMdUNZvQ5V+khALrUNtziB3gX)
			gj7BGM5t3RZpA0vNixLqzwualb16(nnYoO8rQaHmc57IA1MVSi(bo1dqzR8JIwlThvDcyU4jf),'',KBxPW9cX8dqtaUDG=1000)
		if Pgd3rY8O1URkvnyQxeE:
			KBxPW9cX8dqtaUDG.sleep(2)
			for bo1dqzR8JIwlThvDcyU4jf in odSGnmzHxgF:
				hd3iCjBnNGAUzlKWEsqx2c4e[bo1dqzR8JIwlThvDcyU4jf].join(10)
			KBxPW9cX8dqtaUDG.sleep(2)
		for bo1dqzR8JIwlThvDcyU4jf in odSGnmzHxgF:
			JoakAQ4uiT5,dZT40j7heA1zsu3Nak,rrFcwfjUW34gaDKp2mHNB58Azbs = RB0138fEQHwDFGn(bo1dqzR8JIwlThvDcyU4jf)
			for q0HETPprhGgacmbJ4jD in xx4viQhaOu6r0:
				dM2SkzwnVKc3FUPDl9BE,bSxczpUtHewVDKa3EL4lm,SCakygtHx0AUXbO3emswB9F8,H3HDqY5N4e0fWSXMikZ8CR7suUmJdx,QFrVYJkywEsXquMNz,z3z9QgENFk5eMYB4,Gfsr6KpyVRovQmB8xcXUJ,ezSE9fBuvT,yPoqtK3i7zHulhZJDWYsnLxvT0 = q0HETPprhGgacmbJ4jD
				if rrFcwfjUW34gaDKp2mHNB58Azbs in bSxczpUtHewVDKa3EL4lm:
					if 'IPTV-' in bo1dqzR8JIwlThvDcyU4jf and (239>=H3HDqY5N4e0fWSXMikZ8CR7suUmJdx>=230 or 289>=H3HDqY5N4e0fWSXMikZ8CR7suUmJdx>=280):
						if q0HETPprhGgacmbJ4jD in uWBjIlmtXJQ['IPTV-LIVE']: continue
						if q0HETPprhGgacmbJ4jD in uWBjIlmtXJQ['IPTV-MOVIES']: continue
						if q0HETPprhGgacmbJ4jD in uWBjIlmtXJQ['IPTV-SERIES']: continue
						if 'صفحة' not in bSxczpUtHewVDKa3EL4lm:
							if   dM2SkzwnVKc3FUPDl9BE=='live': bo1dqzR8JIwlThvDcyU4jf = 'IPTV-LIVE'
							elif dM2SkzwnVKc3FUPDl9BE=='video': bo1dqzR8JIwlThvDcyU4jf = 'IPTV-MOVIES'
							elif dM2SkzwnVKc3FUPDl9BE=='folder': bo1dqzR8JIwlThvDcyU4jf = 'IPTV-SERIES'
						else:
							if   'LIVE' in SCakygtHx0AUXbO3emswB9F8: bo1dqzR8JIwlThvDcyU4jf = 'IPTV-LIVE'
							elif 'MOVIES' in SCakygtHx0AUXbO3emswB9F8: bo1dqzR8JIwlThvDcyU4jf = 'IPTV-MOVIES'
							elif 'SERIES' in SCakygtHx0AUXbO3emswB9F8: bo1dqzR8JIwlThvDcyU4jf = 'IPTV-SERIES'
					elif 'M3U-' in bo1dqzR8JIwlThvDcyU4jf and 729>=H3HDqY5N4e0fWSXMikZ8CR7suUmJdx>=710:
						if q0HETPprhGgacmbJ4jD in uWBjIlmtXJQ['M3U-LIVE']: continue
						if q0HETPprhGgacmbJ4jD in uWBjIlmtXJQ['M3U-MOVIES']: continue
						if q0HETPprhGgacmbJ4jD in uWBjIlmtXJQ['M3U-SERIES']: continue
						if 'صفحة' not in bSxczpUtHewVDKa3EL4lm:
							if   dM2SkzwnVKc3FUPDl9BE=='live': bo1dqzR8JIwlThvDcyU4jf = 'M3U-LIVE'
							elif dM2SkzwnVKc3FUPDl9BE=='video': bo1dqzR8JIwlThvDcyU4jf = 'M3U-MOVIES'
							elif dM2SkzwnVKc3FUPDl9BE=='folder': bo1dqzR8JIwlThvDcyU4jf = 'M3U-SERIES'
						else:
							if   'LIVE' in SCakygtHx0AUXbO3emswB9F8: bo1dqzR8JIwlThvDcyU4jf = 'M3U-LIVE'
							elif 'MOVIES' in SCakygtHx0AUXbO3emswB9F8: bo1dqzR8JIwlThvDcyU4jf = 'M3U-MOVIES'
							elif 'SERIES' in SCakygtHx0AUXbO3emswB9F8: bo1dqzR8JIwlThvDcyU4jf = 'M3U-SERIES'
					elif 'YOUTUBE-' in bo1dqzR8JIwlThvDcyU4jf and 149>=H3HDqY5N4e0fWSXMikZ8CR7suUmJdx>=140:
						if q0HETPprhGgacmbJ4jD in uWBjIlmtXJQ['YOUTUBE-CHANNELS']: continue
						if q0HETPprhGgacmbJ4jD in uWBjIlmtXJQ['YOUTUBE-PLAYLISTS']: continue
						if q0HETPprhGgacmbJ4jD in uWBjIlmtXJQ['YOUTUBE-VIDEOS']: continue
						if 'صفحة أخرى' in bSxczpUtHewVDKa3EL4lm or ':: ' in bSxczpUtHewVDKa3EL4lm:
							continue
						else:
							if   H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==144 and 'USER' in bSxczpUtHewVDKa3EL4lm: bo1dqzR8JIwlThvDcyU4jf = 'YOUTUBE-CHANNELS'
							elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==144 and 'CHNL' in bSxczpUtHewVDKa3EL4lm: bo1dqzR8JIwlThvDcyU4jf = 'YOUTUBE-CHANNELS'
							elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==144 and 'LIST' in bSxczpUtHewVDKa3EL4lm: bo1dqzR8JIwlThvDcyU4jf = 'YOUTUBE-PLAYLISTS'
							elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==143: bo1dqzR8JIwlThvDcyU4jf = 'YOUTUBE-VIDEOS'
							else: continue
					elif 'DAILYMOTION-' in bo1dqzR8JIwlThvDcyU4jf and 419>=H3HDqY5N4e0fWSXMikZ8CR7suUmJdx>=400:
						if q0HETPprhGgacmbJ4jD in uWBjIlmtXJQ['DAILYMOTION-PLAYLISTS']: continue
						if q0HETPprhGgacmbJ4jD in uWBjIlmtXJQ['DAILYMOTION-CHANNELS']: continue
						if q0HETPprhGgacmbJ4jD in uWBjIlmtXJQ['DAILYMOTION-VIDEOS']: continue
						if q0HETPprhGgacmbJ4jD in uWBjIlmtXJQ['DAILYMOTION-TOPICS']: continue
						if   H3HDqY5N4e0fWSXMikZ8CR7suUmJdx in [401,405]: bo1dqzR8JIwlThvDcyU4jf = 'DAILYMOTION-PLAYLISTS'
						elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx in [402,406]: bo1dqzR8JIwlThvDcyU4jf = 'DAILYMOTION-CHANNELS'
						elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx in [404]: bo1dqzR8JIwlThvDcyU4jf = 'DAILYMOTION-VIDEOS'
						elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx in [415]: bo1dqzR8JIwlThvDcyU4jf = 'DAILYMOTION-LIVES'
						elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx in [412,413]: bo1dqzR8JIwlThvDcyU4jf = 'DAILYMOTION-TOPICS'
					elif 'PANET-' in bo1dqzR8JIwlThvDcyU4jf and 39>=H3HDqY5N4e0fWSXMikZ8CR7suUmJdx>=30:
						if q0HETPprhGgacmbJ4jD in uWBjIlmtXJQ['PANET-SERIES']: continue
						if q0HETPprhGgacmbJ4jD in uWBjIlmtXJQ['PANET-MOVIES']: continue
						if   H3HDqY5N4e0fWSXMikZ8CR7suUmJdx in [32,39]: bo1dqzR8JIwlThvDcyU4jf = 'PANET-SERIES'
						elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx in [33,39]: bo1dqzR8JIwlThvDcyU4jf = 'PANET-MOVIES'
					elif 'IFILM-' in bo1dqzR8JIwlThvDcyU4jf and 29>=H3HDqY5N4e0fWSXMikZ8CR7suUmJdx>=20:
						if q0HETPprhGgacmbJ4jD in uWBjIlmtXJQ['IFILM-ARABIC']: continue
						if q0HETPprhGgacmbJ4jD in uWBjIlmtXJQ['IFILM-ENGLISH']: continue
						if   '/ar.' in SCakygtHx0AUXbO3emswB9F8: bo1dqzR8JIwlThvDcyU4jf = 'IFILM-ARABIC'
						elif '/en.' in SCakygtHx0AUXbO3emswB9F8: bo1dqzR8JIwlThvDcyU4jf = 'IFILM-ENGLISH'
					uWBjIlmtXJQ[bo1dqzR8JIwlThvDcyU4jf].append(q0HETPprhGgacmbJ4jD)
		xx4viQhaOu6r0[:] = []
		for bo1dqzR8JIwlThvDcyU4jf in list(uWBjIlmtXJQ.keys()):
			mhBiQCNG0E67sxUWzY3AeOdP[bo1dqzR8JIwlThvDcyU4jf] = []
			SvbDs9ArxQfhpcG36Rl[bo1dqzR8JIwlThvDcyU4jf] = []
			for dM2SkzwnVKc3FUPDl9BE,bSxczpUtHewVDKa3EL4lm,SCakygtHx0AUXbO3emswB9F8,H3HDqY5N4e0fWSXMikZ8CR7suUmJdx,QFrVYJkywEsXquMNz,z3z9QgENFk5eMYB4,Gfsr6KpyVRovQmB8xcXUJ,ezSE9fBuvT,yPoqtK3i7zHulhZJDWYsnLxvT0 in uWBjIlmtXJQ[bo1dqzR8JIwlThvDcyU4jf]:
				q0HETPprhGgacmbJ4jD = (dM2SkzwnVKc3FUPDl9BE,bSxczpUtHewVDKa3EL4lm,SCakygtHx0AUXbO3emswB9F8,H3HDqY5N4e0fWSXMikZ8CR7suUmJdx,QFrVYJkywEsXquMNz,z3z9QgENFk5eMYB4,Gfsr6KpyVRovQmB8xcXUJ,ezSE9fBuvT,yPoqtK3i7zHulhZJDWYsnLxvT0)
				if 'صفحة' in bSxczpUtHewVDKa3EL4lm and dM2SkzwnVKc3FUPDl9BE=='folder': SvbDs9ArxQfhpcG36Rl[bo1dqzR8JIwlThvDcyU4jf].append(q0HETPprhGgacmbJ4jD)
				else: mhBiQCNG0E67sxUWzY3AeOdP[bo1dqzR8JIwlThvDcyU4jf].append(q0HETPprhGgacmbJ4jD)
		KvTMOmLFBWqhzxy2S0fC = [('link','[COLOR FFC89008]مواقع سيرفرات خاصة - قليلة المشاكل[/COLOR]','',157,'','','','','')]
		for bo1dqzR8JIwlThvDcyU4jf in EeVF6sP7jzo3OJNBRM:
			if bo1dqzR8JIwlThvDcyU4jf==FFgVdSiY7PsMkAKZxJ5tCuyTj[0]: KvTMOmLFBWqhzxy2S0fC = [('link','[COLOR FFC89008]مواقع سيرفرات خاصة وعامة - كثيرة المشاكل[/COLOR]','',157,'','','','','')]
			elif bo1dqzR8JIwlThvDcyU4jf==DuSHpYs3BTZUoXmJibWj2a[0]: KvTMOmLFBWqhzxy2S0fC = [('link','[COLOR FFC89008]مواقع سيرفرات عامة - كثيرة المشاكل[/COLOR]','',157,'','','','','')]
			elif bo1dqzR8JIwlThvDcyU4jf==WWDMLct9dSelhuiHvTKbkXzC[0]: KvTMOmLFBWqhzxy2S0fC = [('link','[COLOR FFC89008]مواقع سيرفرات خاصة - قليلة المشاكل[/COLOR]','',157,'','','','','')]
			if bo1dqzR8JIwlThvDcyU4jf not in mhBiQCNG0E67sxUWzY3AeOdP.keys(): continue
			if mhBiQCNG0E67sxUWzY3AeOdP[bo1dqzR8JIwlThvDcyU4jf]:
				t2dVGcPF4IaTw = nnYoO8rQaHmc57IA1MVSi(bo1dqzR8JIwlThvDcyU4jf)
				gZNFe4OavrcXwp95JEWMkh2BIi = [('link','[COLOR FFFFFF00]===== '+t2dVGcPF4IaTw+' =====[/COLOR]','',9999,'','','','','')]
				if 0: bpNYDvEsHTi9rMJwWxeKg1lSq = mMdUNZvQ5V+' - '+'بحث'+' '+t2dVGcPF4IaTw
				else: bpNYDvEsHTi9rMJwWxeKg1lSq = 'بحث'+' '+t2dVGcPF4IaTw+' - '+mMdUNZvQ5V
				if len(mhBiQCNG0E67sxUWzY3AeOdP[bo1dqzR8JIwlThvDcyU4jf])<8: nGFb5kyqPZMSIY1x4hjzD = []
				else:
					y7o5TMRx6l4ICd2eAZ8z = '[COLOR FFC89008]'+bpNYDvEsHTi9rMJwWxeKg1lSq+'[/COLOR]'
					nGFb5kyqPZMSIY1x4hjzD = [('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+y7o5TMRx6l4ICd2eAZ8z,'closed_sites',542,'',bo1dqzR8JIwlThvDcyU4jf,mMdUNZvQ5V,'','')]
				MDWRojy0Y8Qf2nAJ3aGBI9XeqVOvEL = mhBiQCNG0E67sxUWzY3AeOdP[bo1dqzR8JIwlThvDcyU4jf]+SvbDs9ArxQfhpcG36Rl[bo1dqzR8JIwlThvDcyU4jf]
				KQdxkYIrTezsRa8lim5jNODE += KvTMOmLFBWqhzxy2S0fC+gZNFe4OavrcXwp95JEWMkh2BIi+MDWRojy0Y8Qf2nAJ3aGBI9XeqVOvEL[:7]+nGFb5kyqPZMSIY1x4hjzD
				Ou29pZWeXiMl0jN = [('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+bpNYDvEsHTi9rMJwWxeKg1lSq,'closed_sites',542,'',bo1dqzR8JIwlThvDcyU4jf,mMdUNZvQ5V,'','')]
				ggJWmUQyaD4ONBifYe += KvTMOmLFBWqhzxy2S0fC+Ou29pZWeXiMl0jN
				KvTMOmLFBWqhzxy2S0fC = []
				VZ8BTik93OqXLCh0fD7d2KUPpn4mH6(RnqtMUa9Nh6peGEsBT,'GLOBALSEARCH_CLOSED',(bo1dqzR8JIwlThvDcyU4jf,mMdUNZvQ5V),MDWRojy0Y8Qf2nAJ3aGBI9XeqVOvEL,HTNv70wWuCxtU)
		VZ8BTik93OqXLCh0fD7d2KUPpn4mH6(RnqtMUa9Nh6peGEsBT,'GLOBALSEARCH_OPENED',mMdUNZvQ5V,KQdxkYIrTezsRa8lim5jNODE,HTNv70wWuCxtU)
		qkSCcaj2fg4VO7dl3G9IhJBs5DLx(RnqtMUa9Nh6peGEsBT,'GLOBALSEARCH_SITES',mMdUNZvQ5V)
		VZ8BTik93OqXLCh0fD7d2KUPpn4mH6(RnqtMUa9Nh6peGEsBT,'GLOBALSEARCH_SITES',teUPLFC3B8bArakwHVGsdhoIWDM49f+mMdUNZvQ5V,ggJWmUQyaD4ONBifYe,HTNv70wWuCxtU)
		ZIOHgA3z0TBR('','','رسالة من المبرمج','البحث الجماعي انتهى بنجاح \n\n تم تخزين النتائج في كاش البرنامج لمدة ثلاثين يوم لكي تستطيع العودة إليها بدون عمل بحث جديد')
		if FhnackY1VEXD8oHqfl3bO=='listed_sites' and ggJWmUQyaD4ONBifYe: CnurEb51Oo8FpXUIvmN0T = ggJWmUQyaD4ONBifYe
		else: CnurEb51Oo8FpXUIvmN0T = KQdxkYIrTezsRa8lim5jNODE
	if FhnackY1VEXD8oHqfl3bO!='search_sites':
		for dM2SkzwnVKc3FUPDl9BE,bSxczpUtHewVDKa3EL4lm,SCakygtHx0AUXbO3emswB9F8,H3HDqY5N4e0fWSXMikZ8CR7suUmJdx,QFrVYJkywEsXquMNz,z3z9QgENFk5eMYB4,Gfsr6KpyVRovQmB8xcXUJ,ezSE9fBuvT,yPoqtK3i7zHulhZJDWYsnLxvT0 in CnurEb51Oo8FpXUIvmN0T:
			if FhnackY1VEXD8oHqfl3bO in ['listed_sites','opened_sites'] and 'صفحة' in bSxczpUtHewVDKa3EL4lm and dM2SkzwnVKc3FUPDl9BE=='folder': continue
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX(dM2SkzwnVKc3FUPDl9BE,bSxczpUtHewVDKa3EL4lm,SCakygtHx0AUXbO3emswB9F8,H3HDqY5N4e0fWSXMikZ8CR7suUmJdx,QFrVYJkywEsXquMNz,z3z9QgENFk5eMYB4,Gfsr6KpyVRovQmB8xcXUJ,ezSE9fBuvT,yPoqtK3i7zHulhZJDWYsnLxvT0)
	YRi6vEsJ05kd8Bo9UtbpzlVn2('','','')
	return
def SC5MRP8Ef1FaOspVctdeY(mMdUNZvQ5V=''):
	J05JvhlNWgdBnH1SOzYFey3Pw9u,khALrUNtziB3gX,showDialogs = X54MLovbG8nAEkB9J(mMdUNZvQ5V)
	if not J05JvhlNWgdBnH1SOzYFey3Pw9u:
		J05JvhlNWgdBnH1SOzYFey3Pw9u = ViKAIsLurq83RSENayxWb()
		if not J05JvhlNWgdBnH1SOzYFey3Pw9u: return
		J05JvhlNWgdBnH1SOzYFey3Pw9u = J05JvhlNWgdBnH1SOzYFey3Pw9u.lower()
	Lmj1pfQk63XdoeH('NOTICE',Dwl0N6FKuVU8nB1mbisIrCzdO(baNWS6nfqTC5iX4Kl)+'   Search For: [ '+J05JvhlNWgdBnH1SOzYFey3Pw9u+' ]')
	ystIEd371fLkT50pcRUWi9olNDu = J05JvhlNWgdBnH1SOzYFey3Pw9u+khALrUNtziB3gX
	if 0: AXSoLUNgC9tykasI0q4xTzcJ8lPQdi,SzODUMcwsHkNf4IlY = J05JvhlNWgdBnH1SOzYFey3Pw9u+' - ',''
	else: AXSoLUNgC9tykasI0q4xTzcJ8lPQdi,SzODUMcwsHkNf4IlY = '',' - '+J05JvhlNWgdBnH1SOzYFey3Pw9u
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008]مواقع سيرفرات خاصة - قليلة المشاكل[/COLOR]','',157)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','_M3U_'+AXSoLUNgC9tykasI0q4xTzcJ8lPQdi+'بحث M3U'+SzODUMcwsHkNf4IlY,'',719,'','',ystIEd371fLkT50pcRUWi9olNDu)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','_IPT_'+AXSoLUNgC9tykasI0q4xTzcJ8lPQdi+'بحث IPTV'+SzODUMcwsHkNf4IlY,'',239,'','',ystIEd371fLkT50pcRUWi9olNDu)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','_BKR_'+AXSoLUNgC9tykasI0q4xTzcJ8lPQdi+'بحث موقع بكرا'+SzODUMcwsHkNf4IlY,'',379,'','',ystIEd371fLkT50pcRUWi9olNDu)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','_KLA_'+AXSoLUNgC9tykasI0q4xTzcJ8lPQdi+'بحث موقع كل العرب'+SzODUMcwsHkNf4IlY,'',19,'','',ystIEd371fLkT50pcRUWi9olNDu)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','_ART_'+AXSoLUNgC9tykasI0q4xTzcJ8lPQdi+'بحث موقع تونز عربية'+SzODUMcwsHkNf4IlY,'',739,'','',ystIEd371fLkT50pcRUWi9olNDu)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','_KRB_'+AXSoLUNgC9tykasI0q4xTzcJ8lPQdi+'بحث موقع قناة كربلاء'+SzODUMcwsHkNf4IlY,'',329,'','',ystIEd371fLkT50pcRUWi9olNDu)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','_FH1_'+AXSoLUNgC9tykasI0q4xTzcJ8lPQdi+'بحث موقع فاصل الأول'+SzODUMcwsHkNf4IlY,'',579,'','',ystIEd371fLkT50pcRUWi9olNDu)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','_KTV_'+AXSoLUNgC9tykasI0q4xTzcJ8lPQdi+'بحث موقع كتكوت تيفي'+SzODUMcwsHkNf4IlY,'',819,'','',ystIEd371fLkT50pcRUWi9olNDu)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','_EB1_'+AXSoLUNgC9tykasI0q4xTzcJ8lPQdi+'بحث موقع ايجي بيست 1'+SzODUMcwsHkNf4IlY,'',779,'','',ystIEd371fLkT50pcRUWi9olNDu)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','_EB2_'+AXSoLUNgC9tykasI0q4xTzcJ8lPQdi+'بحث موقع ايجي بيست 2'+SzODUMcwsHkNf4IlY,'',789,'','',ystIEd371fLkT50pcRUWi9olNDu)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','_IFL_'+AXSoLUNgC9tykasI0q4xTzcJ8lPQdi+'  بحث موقع قناة آي فيلم'+SzODUMcwsHkNf4IlY+'  ','',29,'','',ystIEd371fLkT50pcRUWi9olNDu)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','_AKO_'+AXSoLUNgC9tykasI0q4xTzcJ8lPQdi+'بحث موقع أكوام القديم'+SzODUMcwsHkNf4IlY,'',79,'','',ystIEd371fLkT50pcRUWi9olNDu)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','_AKW_'+AXSoLUNgC9tykasI0q4xTzcJ8lPQdi+'بحث موقع أكوام الجديد'+SzODUMcwsHkNf4IlY,'',249,'','',ystIEd371fLkT50pcRUWi9olNDu)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','_MRF_'+AXSoLUNgC9tykasI0q4xTzcJ8lPQdi+'بحث موقع قناة المعارف'+SzODUMcwsHkNf4IlY,'',49,'','',ystIEd371fLkT50pcRUWi9olNDu)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','_SHM_'+AXSoLUNgC9tykasI0q4xTzcJ8lPQdi+'بحث موقع شوف ماكس'+SzODUMcwsHkNf4IlY,'',59,'','',ystIEd371fLkT50pcRUWi9olNDu)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008]مواقع سيرفرات خاصة وعامة - كثيرة المشاكل[/COLOR]','',157)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','_FJS_'+AXSoLUNgC9tykasI0q4xTzcJ8lPQdi+' بحث موقع فجر شو'+SzODUMcwsHkNf4IlY+' ','',399,'','',ystIEd371fLkT50pcRUWi9olNDu)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','_TVF_'+AXSoLUNgC9tykasI0q4xTzcJ8lPQdi+'بحث موقع تيفي فان'+SzODUMcwsHkNf4IlY,'',469,'','',ystIEd371fLkT50pcRUWi9olNDu)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','_LDN_'+AXSoLUNgC9tykasI0q4xTzcJ8lPQdi+'بحث موقع لودي نت'+SzODUMcwsHkNf4IlY,'',459,'','',ystIEd371fLkT50pcRUWi9olNDu)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','_CMN_'+AXSoLUNgC9tykasI0q4xTzcJ8lPQdi+'بحث موقع سيما ناو'+SzODUMcwsHkNf4IlY,'',309,'','',ystIEd371fLkT50pcRUWi9olNDu)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','_WCM_'+AXSoLUNgC9tykasI0q4xTzcJ8lPQdi+'بحث موقع وي سيما'+SzODUMcwsHkNf4IlY,'',569,'','',ystIEd371fLkT50pcRUWi9olNDu)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','_SHN_'+AXSoLUNgC9tykasI0q4xTzcJ8lPQdi+'بحث موقع شاهد نيوز'+SzODUMcwsHkNf4IlY,'',589,'','',ystIEd371fLkT50pcRUWi9olNDu+'_NODIALOGS_')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','_ARS_'+AXSoLUNgC9tykasI0q4xTzcJ8lPQdi+'بحث موقع عرب سييد'+SzODUMcwsHkNf4IlY,'',259,'','',ystIEd371fLkT50pcRUWi9olNDu)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','_CCB_'+AXSoLUNgC9tykasI0q4xTzcJ8lPQdi+'بحث موقع سيما كلوب'+SzODUMcwsHkNf4IlY,'',829,'','',ystIEd371fLkT50pcRUWi9olNDu)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','_SH4_'+AXSoLUNgC9tykasI0q4xTzcJ8lPQdi+'بحث موقع شاهد فوريو'+SzODUMcwsHkNf4IlY,'',119,'','',ystIEd371fLkT50pcRUWi9olNDu+'_NODIALOGS_')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','_SHT_'+AXSoLUNgC9tykasI0q4xTzcJ8lPQdi+'بحث موقع شوفها تيفي'+SzODUMcwsHkNf4IlY,'',649,'','',ystIEd371fLkT50pcRUWi9olNDu)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008]مواقع سيرفرات عامة - كثيرة المشاكل[/COLOR]','',157)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','_FST_'+AXSoLUNgC9tykasI0q4xTzcJ8lPQdi+'بحث موقع فوستا'+SzODUMcwsHkNf4IlY,'',609,'','',ystIEd371fLkT50pcRUWi9olNDu)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','_FBK_'+AXSoLUNgC9tykasI0q4xTzcJ8lPQdi+'بحث موقع فبركة'+SzODUMcwsHkNf4IlY,'',629,'','',ystIEd371fLkT50pcRUWi9olNDu)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','_YQT_'+AXSoLUNgC9tykasI0q4xTzcJ8lPQdi+'بحث موقع ياقوت'+SzODUMcwsHkNf4IlY,'',669,'','',ystIEd371fLkT50pcRUWi9olNDu)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','_BRS_'+AXSoLUNgC9tykasI0q4xTzcJ8lPQdi+'بحث موقع برستيج'+SzODUMcwsHkNf4IlY,'',659,'','',ystIEd371fLkT50pcRUWi9olNDu)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','_HLC_'+AXSoLUNgC9tykasI0q4xTzcJ8lPQdi+'بحث موقع هلا سيما'+SzODUMcwsHkNf4IlY,'',89,'','',ystIEd371fLkT50pcRUWi9olNDu)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','_DR7_'+AXSoLUNgC9tykasI0q4xTzcJ8lPQdi+'بحث موقع دراما صح'+SzODUMcwsHkNf4IlY,'',689,'','',ystIEd371fLkT50pcRUWi9olNDu)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','_CMF_'+AXSoLUNgC9tykasI0q4xTzcJ8lPQdi+'بحث موقع سيما فانز'+SzODUMcwsHkNf4IlY,'',99,'','',ystIEd371fLkT50pcRUWi9olNDu)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','_CML_'+AXSoLUNgC9tykasI0q4xTzcJ8lPQdi+'بحث موقع سيما لايت'+SzODUMcwsHkNf4IlY,'',479,'','',ystIEd371fLkT50pcRUWi9olNDu)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','_ABD_'+AXSoLUNgC9tykasI0q4xTzcJ8lPQdi+'بحث موقع سيما عبدو'+SzODUMcwsHkNf4IlY,'',559,'','',ystIEd371fLkT50pcRUWi9olNDu)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','_C4H_'+AXSoLUNgC9tykasI0q4xTzcJ8lPQdi+'بحث موقع سيما 400'+SzODUMcwsHkNf4IlY,'',699,'','',ystIEd371fLkT50pcRUWi9olNDu)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','_AHK_'+AXSoLUNgC9tykasI0q4xTzcJ8lPQdi+'بحث موقع أهواك تيفي'+SzODUMcwsHkNf4IlY,'',619,'','',ystIEd371fLkT50pcRUWi9olNDu)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','_EB4_'+AXSoLUNgC9tykasI0q4xTzcJ8lPQdi+'بحث موقع ايجي بيست 4'+SzODUMcwsHkNf4IlY,'',809,'','',ystIEd371fLkT50pcRUWi9olNDu)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008]مواقع سيرفرات خاصة - قليلة المشاكل[/COLOR]','',157)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','_YUT_'+AXSoLUNgC9tykasI0q4xTzcJ8lPQdi+'بحث موقع يوتيوب'+SzODUMcwsHkNf4IlY,'',149,'','',ystIEd371fLkT50pcRUWi9olNDu)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','_DLM_'+AXSoLUNgC9tykasI0q4xTzcJ8lPQdi+'بحث موقع ديلي موشن'+SzODUMcwsHkNf4IlY,'',409,'','',ystIEd371fLkT50pcRUWi9olNDu)
	return
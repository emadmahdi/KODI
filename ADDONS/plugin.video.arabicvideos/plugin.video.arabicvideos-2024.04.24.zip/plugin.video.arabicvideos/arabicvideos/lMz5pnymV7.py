# -*- coding: utf-8 -*-
from G6AHskJeqN import *
baNWS6nfqTC5iX4Kl = 'CIMAABDO'
teUPLFC3B8bArakwHVGsdhoIWDM49f = '_ABD_'
EZxQp1WOldMTvFU = AK5RqLhji4W1wt9VdrCD3PGeQM[baNWS6nfqTC5iX4Kl][0]
eh2tDvRFWpLQI = ['الرئيسية']
def VbgEajY4Bt2COpGDcPqI(mode,url,text):
	if   mode==550: ft3e2JBKQVXWlFPjaMhkEqGxvDg = eN02L7Tf5bQ()
	elif mode==551: ft3e2JBKQVXWlFPjaMhkEqGxvDg = sscM839DP1jWZ4zl6uIx0Kyn(url,text)
	elif mode==552: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HDxCnPKFhITpZmOsA4a0UL6(url)
	elif mode==553: ft3e2JBKQVXWlFPjaMhkEqGxvDg = o4oY13v5dWMcbilEDjKCnXNzHZ0(url)
	elif mode==559: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HjZcUIVAXFCqy9TfBWKtgY2(text)
	else: ft3e2JBKQVXWlFPjaMhkEqGxvDg = False
	return ft3e2JBKQVXWlFPjaMhkEqGxvDg
def eN02L7Tf5bQ():
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',EZxQp1WOldMTvFU+'/home','','','','','CIMAABDO-MENU-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	xxE5BSyQkNsj = ooq2D9xF8ZLpPBs(EZxQp1WOldMTvFU,'url')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'بحث في الموقع','',559,'','','_REMEMBERRESULTS_')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'اخترنا لك',xxE5BSyQkNsj+'/home',551,'','','featured')
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('main-content(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	vsptNMP2ZQC = XBuP6Op7y4K[0]
	items = My7Dwqvs6bfGNSIgX.findall('data-name="(.*?)".*?</i>(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	for rwQsc9O3oGdFKbxPlNiM56S2pLUJ0,title in items:
		BoEFz2WhUyvTgDeiZ = xxE5BSyQkNsj+'/ajax/getItem?item='+rwQsc9O3oGdFKbxPlNiM56S2pLUJ0+'&Ajax=1'
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,551)
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"nav-main"(.*?)</nav>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	vsptNMP2ZQC = XBuP6Op7y4K[0]
	items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)">(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	for BoEFz2WhUyvTgDeiZ,title in items:
		if BoEFz2WhUyvTgDeiZ=='#': continue
		if title in eh2tDvRFWpLQI: continue
		if 'مسلسل ' in title: continue
		if 'أحدث' in title: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,551)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	for BoEFz2WhUyvTgDeiZ,title in items:
		if BoEFz2WhUyvTgDeiZ=='#': continue
		if title in eh2tDvRFWpLQI: continue
		if 'مسلسل ' in title: continue
		if 'أحدث' not in title: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,551)
	return
def sscM839DP1jWZ4zl6uIx0Kyn(url,rwQsc9O3oGdFKbxPlNiM56S2pLUJ0=''):
	items = []
	if '/ajax/getItem' in url or '/ajax/loadMore' in url:
		bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,toAVQS46Fv8aJYyLf25KnkUNC = NgD0bJaq14yBnMYoziAmLj(url)
		eIL9BxdTbZj = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'POST',bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,toAVQS46Fv8aJYyLf25KnkUNC,eIL9BxdTbZj,'','','CIMAABDO-TITLES-1st')
		MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
		XBuP6Op7y4K = [MK6ZT2zjC1SbmveNFqor]
	else:
		xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'','','','','CIMAABDO-TITLES-2nd')
		MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
		if rwQsc9O3oGdFKbxPlNiM56S2pLUJ0=='featured':
			XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"container"(.*?)"container"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
			vsptNMP2ZQC = XBuP6Op7y4K[0]
			items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		elif '"section-post mb-10"' in MK6ZT2zjC1SbmveNFqor:
			XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"section-post mb-10"(.*?)"container"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		else:
			XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('<article(.*?)"pagination"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if not XBuP6Op7y4K: return
	vsptNMP2ZQC = XBuP6Op7y4K[0]
	if not items:
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)" title="(.*?)".*?data-original="(.*?)"',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		if not items: items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	y7y3d5Fbhv42ONmtwLZ0SerYoQq = []
	tkBQK76YMeUlRI1TomgECfA = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for BoEFz2WhUyvTgDeiZ,title,IcWzVO137wFvemn2QTq8yKs9 in items:
		BoEFz2WhUyvTgDeiZ = XnQbsZF0Ouh8p7zCdUN(BoEFz2WhUyvTgDeiZ).strip('/')
		ffhN7jAqe3Q4cR0Ukptzl = My7Dwqvs6bfGNSIgX.findall('(.*?) الحلقة \d+',title,My7Dwqvs6bfGNSIgX.DOTALL)
		if 'سلاسل' not in url and any(WoFrX46wzbCNp18 in title for WoFrX46wzbCNp18 in tkBQK76YMeUlRI1TomgECfA):
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,552,IcWzVO137wFvemn2QTq8yKs9)
		elif ffhN7jAqe3Q4cR0Ukptzl and 'الحلقة' in title:
			title = '_MOD_' + ffhN7jAqe3Q4cR0Ukptzl[0]
			if title not in y7y3d5Fbhv42ONmtwLZ0SerYoQq:
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,553,IcWzVO137wFvemn2QTq8yKs9)
				y7y3d5Fbhv42ONmtwLZ0SerYoQq.append(title)
		elif '/movies/' in BoEFz2WhUyvTgDeiZ:
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,551,IcWzVO137wFvemn2QTq8yKs9)
		else: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,553,IcWzVO137wFvemn2QTq8yKs9)
	if rwQsc9O3oGdFKbxPlNiM56S2pLUJ0=='':
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"pagination"(.*?)<footer',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if XBuP6Op7y4K:
			vsptNMP2ZQC = XBuP6Op7y4K[0]
			items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?>(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
			for BoEFz2WhUyvTgDeiZ,title in items:
				if BoEFz2WhUyvTgDeiZ=="": continue
				if title!='': VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'صفحة '+title,BoEFz2WhUyvTgDeiZ,551)
	if '/ajax/getItem' in url or '/ajax/loadMore' in url:
		if '/ajax/getItem' in url:
			url = url.replace('/ajax/getItem','/ajax/loadMore')+'&offset=20'
		elif '/ajax/loadMore' in url:
			url,offset = url.split('&offset=')
			offset = int(offset)+20
			url = url+'&offset='+str(offset)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'هناك المزيد',url,551)
	return
def o4oY13v5dWMcbilEDjKCnXNzHZ0(url):
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'','','','','CIMAABDO-EPISODES-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	KRI8WExzA4p = My7Dwqvs6bfGNSIgX.findall('"getSeasonsBySeries(.*?)"container"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	kdYXhMN8Hpbt = My7Dwqvs6bfGNSIgX.findall('"list-episodes"(.*?)"container"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if KRI8WExzA4p and '/series/' not in url:
		vsptNMP2ZQC = KRI8WExzA4p[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title,IcWzVO137wFvemn2QTq8yKs9 in items:
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,553,IcWzVO137wFvemn2QTq8yKs9)
	elif kdYXhMN8Hpbt:
		IcWzVO137wFvemn2QTq8yKs9 = My7Dwqvs6bfGNSIgX.findall('"image" src="(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		IcWzVO137wFvemn2QTq8yKs9 = IcWzVO137wFvemn2QTq8yKs9[0]
		vsptNMP2ZQC = kdYXhMN8Hpbt[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)" title="(.*?)"',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title in items:
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,552,IcWzVO137wFvemn2QTq8yKs9)
	return
def HDxCnPKFhITpZmOsA4a0UL6(url):
	QAKdHzO0rehbtyIc = url.replace('/movies/','/watch_movies/')
	QAKdHzO0rehbtyIc = QAKdHzO0rehbtyIc.replace('/episodes/','/watch_episodes/')
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',QAKdHzO0rehbtyIc,'','','','','CIMAABDO-PLAY-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	xxE5BSyQkNsj = ooq2D9xF8ZLpPBs(QAKdHzO0rehbtyIc,'url')
	Qki8AbTHYjzM2Ls76Gdr3eqo1Wn = []
	BoEFz2WhUyvTgDeiZ = My7Dwqvs6bfGNSIgX.findall('''<iframe.*?src=["'](.*?)["']''',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if BoEFz2WhUyvTgDeiZ:
		BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ[0]
		LkVZrOE4XBSN2Qex5PyHqC = ooq2D9xF8ZLpPBs(BoEFz2WhUyvTgDeiZ,'url')
		Qki8AbTHYjzM2Ls76Gdr3eqo1Wn.append(BoEFz2WhUyvTgDeiZ+'?named='+LkVZrOE4XBSN2Qex5PyHqC+'__embed')
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"servers"(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		IIi2NYTdvHzGUQ89EBLOgqr = My7Dwqvs6bfGNSIgX.findall('postID = "(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		IIi2NYTdvHzGUQ89EBLOgqr = IIi2NYTdvHzGUQ89EBLOgqr[0]
		items = My7Dwqvs6bfGNSIgX.findall("getPlayer\('(.*?)'.*?</i>(.*?)</a>",vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		if items:
			for LkVZrOE4XBSN2Qex5PyHqC,title in items:
				title = title.replace('\n','').strip(' ')
				BoEFz2WhUyvTgDeiZ = xxE5BSyQkNsj+'/ajax/getPlayer?server='+LkVZrOE4XBSN2Qex5PyHqC+'&postID='+IIi2NYTdvHzGUQ89EBLOgqr+'&Ajax=1'
				BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ+'?named='+title+'__watch'
				Qki8AbTHYjzM2Ls76Gdr3eqo1Wn.append(BoEFz2WhUyvTgDeiZ)
		else:
			items = My7Dwqvs6bfGNSIgX.findall("getPlayerByName\('(.*?)','(.*?)'.*?\"server\">(.*?)</a>",vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
			LkVZrOE4XBSN2Qex5PyHqC,wge8mxLqFRIZWt0u7BDMOvrY,title = items[0]
			BoEFz2WhUyvTgDeiZ = xxE5BSyQkNsj+'/ajax/getPlayerByName?server='+LkVZrOE4XBSN2Qex5PyHqC+'&multipleServers='+wge8mxLqFRIZWt0u7BDMOvrY+'&postID='+IIi2NYTdvHzGUQ89EBLOgqr+'&Ajax=1'
			bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,toAVQS46Fv8aJYyLf25KnkUNC = NgD0bJaq14yBnMYoziAmLj(BoEFz2WhUyvTgDeiZ)
			eIL9BxdTbZj = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
			xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'POST',bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,toAVQS46Fv8aJYyLf25KnkUNC,eIL9BxdTbZj,'','','CIMAABDO-PLAY-2nd')
			MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
			kcGf0WYwFujE9QN6zHTi = My7Dwqvs6bfGNSIgX.findall('''<iframe src=["'](.*?)["']''',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL|My7Dwqvs6bfGNSIgX.IGNORECASE)
			bOBQpgMudItXo = kcGf0WYwFujE9QN6zHTi[0] if kcGf0WYwFujE9QN6zHTi else ''
			if '/iframe/' in bOBQpgMudItXo:
				eIL9BxdTbZj = {}
				eIL9BxdTbZj['X-Inertia-Partial-Component'] = 'files/mirror/video'
				eIL9BxdTbZj['X-Inertia'] = 'true'
				eIL9BxdTbZj['X-Inertia-Partial-Data'] = 'streams'
				eIL9BxdTbZj['X-Inertia-Version'] = '4ea9342db443a2734c79cdb60534d32f'
				xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',bOBQpgMudItXo,'',eIL9BxdTbZj,'','','CIMAABDO-PLAY-3rd')
				MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
				V0qzBuXDvtTZCQ = dWsa2A0O4o5BYiqGXhyKEbM('dict',MK6ZT2zjC1SbmveNFqor)
				groups = V0qzBuXDvtTZCQ['props']['streams']['data']
				for group in groups:
					LLnUyuiC2wRM0 = group['label'].replace(' (source)','')
					escEwMBJiDP63bqdzmg4fu1xNYtCA = group['mirrors']
					for UU12xKkCLDBF in escEwMBJiDP63bqdzmg4fu1xNYtCA:
						LkVZrOE4XBSN2Qex5PyHqC = UU12xKkCLDBF['driver']
						BoEFz2WhUyvTgDeiZ = 'http:'+UU12xKkCLDBF['link']+'?named='+LkVZrOE4XBSN2Qex5PyHqC+'__watch____'+LLnUyuiC2wRM0
						Qki8AbTHYjzM2Ls76Gdr3eqo1Wn.append(BoEFz2WhUyvTgDeiZ)
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"downs"(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)" title="(.*?)"',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,name in items:
			BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ+'?named='+name+'__download'
			if 'http' not in BoEFz2WhUyvTgDeiZ: BoEFz2WhUyvTgDeiZ = 'http:'+BoEFz2WhUyvTgDeiZ
			Qki8AbTHYjzM2Ls76Gdr3eqo1Wn.append(BoEFz2WhUyvTgDeiZ)
	import t1kDWXQVpC
	t1kDWXQVpC.rqVt2xDi7jzJHBcPMRs6h0L(Qki8AbTHYjzM2Ls76Gdr3eqo1Wn,baNWS6nfqTC5iX4Kl,'video',url)
	return
def HjZcUIVAXFCqy9TfBWKtgY2(search):
	search,LQf3AeozSrai,showDialogs = X54MLovbG8nAEkB9J(search)
	if search=='': search = ViKAIsLurq83RSENayxWb()
	if search=='': return
	search = search.replace(' ','-')
	url = EZxQp1WOldMTvFU+'/search/'+search+'.html'
	sscM839DP1jWZ4zl6uIx0Kyn(url)
	return
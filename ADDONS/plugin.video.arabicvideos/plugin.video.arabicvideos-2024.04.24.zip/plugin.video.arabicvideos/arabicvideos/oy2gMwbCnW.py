# -*- coding: utf-8 -*-
from G6AHskJeqN import *
baNWS6nfqTC5iX4Kl = 'ALFATIMI'
teUPLFC3B8bArakwHVGsdhoIWDM49f = '_FTM_'
EZxQp1WOldMTvFU = AK5RqLhji4W1wt9VdrCD3PGeQM[baNWS6nfqTC5iX4Kl][0]
sOUmzHinJKeN = ['1239','1250','1245','20','1259','218','485','1238','1258','292']
t72m61cFYBWidKAv5IhH8nyS = ['3030','628']
def VbgEajY4Bt2COpGDcPqI(mode,url,text):
	if   mode==60: ft3e2JBKQVXWlFPjaMhkEqGxvDg = eN02L7Tf5bQ()
	elif mode==61: ft3e2JBKQVXWlFPjaMhkEqGxvDg = sscM839DP1jWZ4zl6uIx0Kyn(url,text)
	elif mode==62: ft3e2JBKQVXWlFPjaMhkEqGxvDg = o4oY13v5dWMcbilEDjKCnXNzHZ0(url)
	elif mode==63: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HDxCnPKFhITpZmOsA4a0UL6(url)
	elif mode==64: ft3e2JBKQVXWlFPjaMhkEqGxvDg = nZDlmYqOKVIaXR6JLPGeuQSj(text)
	elif mode==69: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HjZcUIVAXFCqy9TfBWKtgY2(text)
	else: ft3e2JBKQVXWlFPjaMhkEqGxvDg = False
	return ft3e2JBKQVXWlFPjaMhkEqGxvDg
def eN02L7Tf5bQ():
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'بحث في الموقع','',69,'','','_REMEMBERRESULTS_')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'ما يتم مشاهدته الان',EZxQp1WOldMTvFU,64,'','','recent_viewed_vids')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'الاكثر مشاهدة',EZxQp1WOldMTvFU,64,'','','most_viewed_vids')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'اضيفت مؤخرا',EZxQp1WOldMTvFU,64,'','','recently_added_vids')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'فيديو عشوائي',EZxQp1WOldMTvFU,64,'','','random_vids')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'افلام ومسلسلات',EZxQp1WOldMTvFU,61,'','','-1')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'البرامج الدينية',EZxQp1WOldMTvFU,61,'','','-2')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'English Videos',EZxQp1WOldMTvFU,61,'','','-3')
	return ''
def sscM839DP1jWZ4zl6uIx0Kyn(url,g4Y0BXLxCpuojKP1SAUtcq7TwN2):
	f8HmhaGZJX = ''
	if g4Y0BXLxCpuojKP1SAUtcq7TwN2 not in ['-1','-2','-3']: f8HmhaGZJX = '?cat='+g4Y0BXLxCpuojKP1SAUtcq7TwN2
	bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = EZxQp1WOldMTvFU+'/menu_level.php'+f8HmhaGZJX
	MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(UuEtImzir9,bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,'','','','ALFATIMI-TITLES-1st')
	items = My7Dwqvs6bfGNSIgX.findall('href=\'(.*?)\'.*?>(.*?)<.*?>(.*?)</span>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	atkMuVCwg4,RnK9tpPmxGhlS0yVAJ71fjsTEIZ = False,False
	for BoEFz2WhUyvTgDeiZ,title,count in items:
		title = PIfAumbGicwg5ye(title)
		title = title.strip(' ')
		if 'http' not in BoEFz2WhUyvTgDeiZ: BoEFz2WhUyvTgDeiZ = 'http:'+BoEFz2WhUyvTgDeiZ
		f8HmhaGZJX = My7Dwqvs6bfGNSIgX.findall('cat=(.*?)&',BoEFz2WhUyvTgDeiZ,My7Dwqvs6bfGNSIgX.DOTALL)[0]
		if g4Y0BXLxCpuojKP1SAUtcq7TwN2==f8HmhaGZJX: atkMuVCwg4 = True
		elif atkMuVCwg4 	or (g4Y0BXLxCpuojKP1SAUtcq7TwN2=='-1' and f8HmhaGZJX in sOUmzHinJKeN)  						or (g4Y0BXLxCpuojKP1SAUtcq7TwN2=='-2' and f8HmhaGZJX not in t72m61cFYBWidKAv5IhH8nyS and f8HmhaGZJX not in sOUmzHinJKeN)  						or (g4Y0BXLxCpuojKP1SAUtcq7TwN2=='-3' and f8HmhaGZJX in t72m61cFYBWidKAv5IhH8nyS):
							if count=='1': VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,63)
							else: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,61,'','',f8HmhaGZJX)
							RnK9tpPmxGhlS0yVAJ71fjsTEIZ = True
	if not RnK9tpPmxGhlS0yVAJ71fjsTEIZ: o4oY13v5dWMcbilEDjKCnXNzHZ0(url)
	return
def o4oY13v5dWMcbilEDjKCnXNzHZ0(url):
	MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(UuEtImzir9,url,'','',True,'ALFATIMI-EPISODES-1st')
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('pagination(.*?)id="footer',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	vsptNMP2ZQC = XBuP6Op7y4K[0]
	items = My7Dwqvs6bfGNSIgX.findall('grid_view.*?src="(.*?)".*?title="(.*?)".*?<h2.*?href="(.*?)"',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	BoEFz2WhUyvTgDeiZ = ''
	for IcWzVO137wFvemn2QTq8yKs9,title,BoEFz2WhUyvTgDeiZ in items:
		title = title.replace('Add','').replace('to Quicklist','').strip(' ')
		if 'http' not in BoEFz2WhUyvTgDeiZ: BoEFz2WhUyvTgDeiZ = 'http:'+BoEFz2WhUyvTgDeiZ
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,63,IcWzVO137wFvemn2QTq8yKs9)
	XBuP6Op7y4K=My7Dwqvs6bfGNSIgX.findall('(.*?)div',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	vsptNMP2ZQC=XBuP6Op7y4K[0]
	vsptNMP2ZQC=My7Dwqvs6bfGNSIgX.findall('pagination(.*?)</div>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)[0]
	items=My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?>(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = url.split('?')[0]
	for BoEFz2WhUyvTgDeiZ,mfx4oMDwjFq3XTZiybLWRrk0pO in items:
		BoEFz2WhUyvTgDeiZ = bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 + BoEFz2WhUyvTgDeiZ
		title = PIfAumbGicwg5ye(mfx4oMDwjFq3XTZiybLWRrk0pO)
		title = 'صفحة ' + title
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,62)
	return BoEFz2WhUyvTgDeiZ
def HDxCnPKFhITpZmOsA4a0UL6(url):
	if 'videos.php' in url: url = o4oY13v5dWMcbilEDjKCnXNzHZ0(url)
	MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(IIiPCruL6dT8s1lqj47SzpVHnYNm,url,'','',True,'ALFATIMI-PLAY-1st')
	items = My7Dwqvs6bfGNSIgX.findall('playlistfile:"(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	url = items[0]
	if 'http' not in url: url = 'http:'+url
	B0xcwKkMQ16mpSFRaVHPTzuhUZngLq(url,baNWS6nfqTC5iX4Kl,'video')
	return
def nZDlmYqOKVIaXR6JLPGeuQSj(g4Y0BXLxCpuojKP1SAUtcq7TwN2):
	tWha1P9LVeuNxpQUAB = { 'mode' : g4Y0BXLxCpuojKP1SAUtcq7TwN2 }
	url = 'http://alfatimi.tv/ajax.php'
	headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
	data = xcWMv9b8dpTSq1IZ5eht(tWha1P9LVeuNxpQUAB)
	MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(f9Oum6c0FotxYn,url,data,headers,True,'ALFATIMI-MOSTS-1st')
	items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?title="(.*?)".*?src="(.*?)".*?href',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	for BoEFz2WhUyvTgDeiZ,title,IcWzVO137wFvemn2QTq8yKs9 in items:
		title = title.strip(' ')
		if 'http' not in BoEFz2WhUyvTgDeiZ: BoEFz2WhUyvTgDeiZ = 'http:'+BoEFz2WhUyvTgDeiZ
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,63,IcWzVO137wFvemn2QTq8yKs9)
	return
def HjZcUIVAXFCqy9TfBWKtgY2(search):
	search,LQf3AeozSrai,showDialogs = X54MLovbG8nAEkB9J(search)
	if search=='': search = ViKAIsLurq83RSENayxWb()
	if search=='': return
	ystIEd371fLkT50pcRUWi9olNDu = search.replace(' ','+')
	url = EZxQp1WOldMTvFU + '/search_result.php?query=' + ystIEd371fLkT50pcRUWi9olNDu
	o4oY13v5dWMcbilEDjKCnXNzHZ0(url)
	return
# -*- coding: utf-8 -*-
from G6AHskJeqN import *
baNWS6nfqTC5iX4Kl = 'CIMALIGHT'
teUPLFC3B8bArakwHVGsdhoIWDM49f = '_CML_'
EZxQp1WOldMTvFU = AK5RqLhji4W1wt9VdrCD3PGeQM[baNWS6nfqTC5iX4Kl][0]
eh2tDvRFWpLQI = ['قنوات فضائية']
def VbgEajY4Bt2COpGDcPqI(mode,url,text):
	if   mode==470: ft3e2JBKQVXWlFPjaMhkEqGxvDg = eN02L7Tf5bQ()
	elif mode==471: ft3e2JBKQVXWlFPjaMhkEqGxvDg = sscM839DP1jWZ4zl6uIx0Kyn(url,text)
	elif mode==472: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HDxCnPKFhITpZmOsA4a0UL6(url)
	elif mode==473: ft3e2JBKQVXWlFPjaMhkEqGxvDg = CbkBOWecfqN8Jajp1Dd(url,text)
	elif mode==474: ft3e2JBKQVXWlFPjaMhkEqGxvDg = M25iOAH9NfalvyPEUuToG8qn(url)
	elif mode==479: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HjZcUIVAXFCqy9TfBWKtgY2(text)
	else: ft3e2JBKQVXWlFPjaMhkEqGxvDg = False
	return ft3e2JBKQVXWlFPjaMhkEqGxvDg
def eN02L7Tf5bQ():
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',EZxQp1WOldMTvFU,'','','','','CIMALIGHT-MENU-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	xxE5BSyQkNsj = My7Dwqvs6bfGNSIgX.findall('"url": "(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	xxE5BSyQkNsj = xxE5BSyQkNsj[0].strip('/')
	xxE5BSyQkNsj = ooq2D9xF8ZLpPBs(xxE5BSyQkNsj,'url')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'بحث في الموقع','',479,'','','_REMEMBERRESULTS_')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"content"(.*?)</div>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	vsptNMP2ZQC = XBuP6Op7y4K[0]
	items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?</i>(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	for BoEFz2WhUyvTgDeiZ,title in items:
		title = title.replace('  ','').strip(' ')
		BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ.replace('cat=online-movies1','cat=online-movies')
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,474)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('/category.php">(.*?)"navslide-divider"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	vsptNMP2ZQC = XBuP6Op7y4K[0]
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall("'dropdown-menu'(.*?)</ul>",MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?>(.*?)</a>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	for BoEFz2WhUyvTgDeiZ,title in items:
		if title in eh2tDvRFWpLQI: continue
		if 'مسلسل ' in title: continue
		if 'برنامج ' in title: continue
		if 'للكبار' in title: continue
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,474)
	return
def M25iOAH9NfalvyPEUuToG8qn(url):
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'','','','','CIMALIGHT-TITLES-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	if 'topvideos.php' in url: XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"caret"(.*?)id="pm-grid"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	else: XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"caret"(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?>(.*?)</a>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title in items:
			if 'topvideos.php' in BoEFz2WhUyvTgDeiZ:
				if 'topvideos.php?c=english-movies' in BoEFz2WhUyvTgDeiZ: continue
				if 'topvideos.php?c=online-movies1' in BoEFz2WhUyvTgDeiZ: continue
				if 'topvideos.php?c=misc' in BoEFz2WhUyvTgDeiZ: continue
				if 'topvideos.php?c=tv-channel' in BoEFz2WhUyvTgDeiZ: continue
				if 'منذ البداية' in title and 'do=rating' not in BoEFz2WhUyvTgDeiZ: continue
			else: title = 'ترتيب باستخدام:  '+title
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,471)
	else: sscM839DP1jWZ4zl6uIx0Kyn(url)
	return
def sscM839DP1jWZ4zl6uIx0Kyn(url,h5QaxwPF7SOu6fMBTGXRU2yn=''):
	xxE5BSyQkNsj = ooq2D9xF8ZLpPBs(url,'url')
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'','','','','CIMALIGHT-TITLES-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	items = []
	if h5QaxwPF7SOu6fMBTGXRU2yn=='featured_movies':
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"container-fluid"(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?"title">(.*?)</div>.*?image:url\(\'(.*?)\'\)',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		NVHrZsqUp2,msjnlSMrQGJ4oLwE2d,MMt97vogZJX3qlxLCRQe5 = zip(*items)
		items = zip(MMt97vogZJX3qlxLCRQe5,NVHrZsqUp2,msjnlSMrQGJ4oLwE2d)
	elif h5QaxwPF7SOu6fMBTGXRU2yn=='featured_series':
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('المسلسلات المميزة(.*?)<style>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?title="(.*?)".*?image:url\(\'(.*?)\'\)',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		NVHrZsqUp2,msjnlSMrQGJ4oLwE2d,MMt97vogZJX3qlxLCRQe5 = zip(*items)
		items = zip(MMt97vogZJX3qlxLCRQe5,NVHrZsqUp2,msjnlSMrQGJ4oLwE2d)
	else:
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('(data-echo=".*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if not XBuP6Op7y4K: XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"BlocksList"(.*?)"titleSectionCon"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if not XBuP6Op7y4K: XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('id="pm-grid"(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if not XBuP6Op7y4K: XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('id="pm-related"(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if not XBuP6Op7y4K: XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('pm-ul-browse-videos(.*?)clearfix',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if not XBuP6Op7y4K: return
		vsptNMP2ZQC = XBuP6Op7y4K[0]
	if not items: items = My7Dwqvs6bfGNSIgX.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	if not items: items = My7Dwqvs6bfGNSIgX.findall('src="(.*?)".*?href="(.*?)".*?>(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	y7y3d5Fbhv42ONmtwLZ0SerYoQq = []
	tkBQK76YMeUlRI1TomgECfA = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for IcWzVO137wFvemn2QTq8yKs9,BoEFz2WhUyvTgDeiZ,title in items:
		BoEFz2WhUyvTgDeiZ = XnQbsZF0Ouh8p7zCdUN(BoEFz2WhUyvTgDeiZ).strip('/')
		title = title.replace('ماي سيما','').replace('مشاهدة','').strip(' ').replace('  ',' ')
		if 'http' not in BoEFz2WhUyvTgDeiZ: BoEFz2WhUyvTgDeiZ = xxE5BSyQkNsj+'/'+BoEFz2WhUyvTgDeiZ.strip('/')
		if 'http' not in IcWzVO137wFvemn2QTq8yKs9: IcWzVO137wFvemn2QTq8yKs9 = xxE5BSyQkNsj+'/'+IcWzVO137wFvemn2QTq8yKs9.strip('/')
		ffhN7jAqe3Q4cR0Ukptzl = My7Dwqvs6bfGNSIgX.findall('(.*?) (الحلقة|حلقة) \d+',title,My7Dwqvs6bfGNSIgX.DOTALL)
		if any(WoFrX46wzbCNp18 in title for WoFrX46wzbCNp18 in tkBQK76YMeUlRI1TomgECfA):
			title = '_MOD_'+title
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,472,IcWzVO137wFvemn2QTq8yKs9)
		elif ffhN7jAqe3Q4cR0Ukptzl and 'حلقة' in title:
			title = '_MOD_'+ffhN7jAqe3Q4cR0Ukptzl[0][0]
			if title not in y7y3d5Fbhv42ONmtwLZ0SerYoQq:
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,473,IcWzVO137wFvemn2QTq8yKs9)
				y7y3d5Fbhv42ONmtwLZ0SerYoQq.append(title)
		elif '/movseries/' in BoEFz2WhUyvTgDeiZ:
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,471,IcWzVO137wFvemn2QTq8yKs9)
		else: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,473,IcWzVO137wFvemn2QTq8yKs9)
	if h5QaxwPF7SOu6fMBTGXRU2yn not in ['featured_movies','featured_series']:
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"pagination(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if XBuP6Op7y4K:
			vsptNMP2ZQC = XBuP6Op7y4K[0]
			items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?>(.*?)</a>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
			for BoEFz2WhUyvTgDeiZ,title in items:
				if BoEFz2WhUyvTgDeiZ=='#': continue
				BoEFz2WhUyvTgDeiZ = xxE5BSyQkNsj+'/'+BoEFz2WhUyvTgDeiZ.strip('/')
				title = PIfAumbGicwg5ye(title)
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'صفحة '+title,BoEFz2WhUyvTgDeiZ,471)
		g7gdVaoK3PHGpJ1YBxvTSUkz = My7Dwqvs6bfGNSIgX.findall('showmore" href="(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if g7gdVaoK3PHGpJ1YBxvTSUkz:
			BoEFz2WhUyvTgDeiZ = g7gdVaoK3PHGpJ1YBxvTSUkz[0]
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'مشاهدة المزيد',BoEFz2WhUyvTgDeiZ,471)
	return
def CbkBOWecfqN8Jajp1Dd(url,b0z14BOJQMs):
	xxE5BSyQkNsj = ooq2D9xF8ZLpPBs(url,'url')
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'','','','','CIMALIGHT-EPISODES-2nd')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	KRI8WExzA4p = My7Dwqvs6bfGNSIgX.findall('"SeasonsBox"(.*?)</div>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	items = []
	if KRI8WExzA4p and not b0z14BOJQMs:
		IcWzVO137wFvemn2QTq8yKs9 = My7Dwqvs6bfGNSIgX.findall('"series-header".*?src="(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		IcWzVO137wFvemn2QTq8yKs9 = IcWzVO137wFvemn2QTq8yKs9[0]
		vsptNMP2ZQC = KRI8WExzA4p[0]
		items = My7Dwqvs6bfGNSIgX.findall('openCity\(event\, \'(.*?)\'\)".*?>(.*?)</button>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		if len(items)==1: b0z14BOJQMs = items[0][0]
		elif len(items)>1:
			for b0z14BOJQMs,title in items: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,url,473,IcWzVO137wFvemn2QTq8yKs9,'',b0z14BOJQMs)
	kdYXhMN8Hpbt = My7Dwqvs6bfGNSIgX.findall('id="'+b0z14BOJQMs+'"(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if kdYXhMN8Hpbt and len(items)<2:
		IcWzVO137wFvemn2QTq8yKs9 = My7Dwqvs6bfGNSIgX.findall('"series-header".*?src="(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		IcWzVO137wFvemn2QTq8yKs9 = IcWzVO137wFvemn2QTq8yKs9[0]
		vsptNMP2ZQC = kdYXhMN8Hpbt[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)" title="(.*?)"',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		if items:
			for BoEFz2WhUyvTgDeiZ,title in items:
				title = title.replace('ماي سيما','').replace('مسلسل','').strip(' ')
				if 'http' not in BoEFz2WhUyvTgDeiZ: BoEFz2WhUyvTgDeiZ = xxE5BSyQkNsj+'/'+BoEFz2WhUyvTgDeiZ.strip('/')
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,472,IcWzVO137wFvemn2QTq8yKs9)
		else:
			items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?title="(.*?)".*?image:url\((.*?)\)',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
			for BoEFz2WhUyvTgDeiZ,title,IcWzVO137wFvemn2QTq8yKs9 in items:
				if 'http' not in BoEFz2WhUyvTgDeiZ: BoEFz2WhUyvTgDeiZ = xxE5BSyQkNsj+'/'+BoEFz2WhUyvTgDeiZ.strip('/')
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,472,IcWzVO137wFvemn2QTq8yKs9)
	if 'id="pm-related"' in MK6ZT2zjC1SbmveNFqor:
		if items: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'مواضيع ذات صلة',url,471)
	return
def HDxCnPKFhITpZmOsA4a0UL6(url):
	QQ2cE1FjUyxPonbDhaTkV6B3i = []
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'','','','','CIMALIGHT-PLAY-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('<div itemprop="description">(.*?)href=',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		ME2Q6F7u8Vp1km9ws = My7Dwqvs6bfGNSIgX.findall('<p>(.*?)</p>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		if ME2Q6F7u8Vp1km9ws and a97xrkSOefH5DbjXunq(baNWS6nfqTC5iX4Kl,url,ME2Q6F7u8Vp1km9ws,True): return
	bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = url.replace('/watch.php','/play.php')
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,'','','','','CIMALIGHT-PLAY-2nd')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	JA1NWoYtev78MVzx6Xg09u = []
	BoEFz2WhUyvTgDeiZ = My7Dwqvs6bfGNSIgX.findall('"embedURL" href="(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if BoEFz2WhUyvTgDeiZ:
		BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ[0]
		if BoEFz2WhUyvTgDeiZ and BoEFz2WhUyvTgDeiZ not in JA1NWoYtev78MVzx6Xg09u:
			JA1NWoYtev78MVzx6Xg09u.append(BoEFz2WhUyvTgDeiZ)
			BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ+'?named=__embed'
			if 'http' not in BoEFz2WhUyvTgDeiZ: BoEFz2WhUyvTgDeiZ = 'http:'+BoEFz2WhUyvTgDeiZ
			QQ2cE1FjUyxPonbDhaTkV6B3i.append(BoEFz2WhUyvTgDeiZ)
	items = My7Dwqvs6bfGNSIgX.findall("<iframe src='(.*?)'.*?<strong>(.*?)</strong>",MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	for BoEFz2WhUyvTgDeiZ,title in items:
		if BoEFz2WhUyvTgDeiZ not in JA1NWoYtev78MVzx6Xg09u:
			JA1NWoYtev78MVzx6Xg09u.append(BoEFz2WhUyvTgDeiZ)
			BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ+'?named='+title+'__watch'
			if 'http' not in BoEFz2WhUyvTgDeiZ: BoEFz2WhUyvTgDeiZ = 'http:'+BoEFz2WhUyvTgDeiZ
			QQ2cE1FjUyxPonbDhaTkV6B3i.append(BoEFz2WhUyvTgDeiZ)
	bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = url.replace('/watch.php','/downloads.php')
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,'','','','','CIMALIGHT-PLAY-3rd')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"downloadlist"(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?<strong>(.*?)</strong>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title in items:
			if BoEFz2WhUyvTgDeiZ not in JA1NWoYtev78MVzx6Xg09u:
				JA1NWoYtev78MVzx6Xg09u.append(BoEFz2WhUyvTgDeiZ)
				BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ+'?named='+title+'__download'
				if 'http' not in BoEFz2WhUyvTgDeiZ: BoEFz2WhUyvTgDeiZ = 'http:'+BoEFz2WhUyvTgDeiZ
				QQ2cE1FjUyxPonbDhaTkV6B3i.append(BoEFz2WhUyvTgDeiZ)
	import t1kDWXQVpC
	t1kDWXQVpC.rqVt2xDi7jzJHBcPMRs6h0L(QQ2cE1FjUyxPonbDhaTkV6B3i,baNWS6nfqTC5iX4Kl,'video',url)
	return
def HjZcUIVAXFCqy9TfBWKtgY2(search):
	search,LQf3AeozSrai,showDialogs = X54MLovbG8nAEkB9J(search)
	if search=='': search = ViKAIsLurq83RSENayxWb()
	if search=='': return
	search = search.replace(' ','+')
	url = EZxQp1WOldMTvFU+'/search.php?keywords='+search
	sscM839DP1jWZ4zl6uIx0Kyn(url)
	return
# -*- coding: utf-8 -*-
from G6AHskJeqN import *
baNWS6nfqTC5iX4Kl = 'CIMA4U'
headers = {'User-Agent':''}
teUPLFC3B8bArakwHVGsdhoIWDM49f = '_C4U_'
EZxQp1WOldMTvFU = AK5RqLhji4W1wt9VdrCD3PGeQM[baNWS6nfqTC5iX4Kl][0]
eh2tDvRFWpLQI = ['مصارعة حرة','اخري','اخرى','الرئيسية','بدون إختيار','افلام','مسلسلات']
def VbgEajY4Bt2COpGDcPqI(mode,url,text):
	if   mode==420: ft3e2JBKQVXWlFPjaMhkEqGxvDg = eN02L7Tf5bQ()
	elif mode==421: ft3e2JBKQVXWlFPjaMhkEqGxvDg = sscM839DP1jWZ4zl6uIx0Kyn(url,text)
	elif mode==422: ft3e2JBKQVXWlFPjaMhkEqGxvDg = WWF1Rc6KZx(url)
	elif mode==423: ft3e2JBKQVXWlFPjaMhkEqGxvDg = o4oY13v5dWMcbilEDjKCnXNzHZ0(url)
	elif mode==424: ft3e2JBKQVXWlFPjaMhkEqGxvDg = LLJlTxDePyjoVKA(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==425: ft3e2JBKQVXWlFPjaMhkEqGxvDg = LLJlTxDePyjoVKA(url,'SPECIFIED_FILTER___'+text)
	elif mode==426: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HDxCnPKFhITpZmOsA4a0UL6(url)
	elif mode==427: ft3e2JBKQVXWlFPjaMhkEqGxvDg = u9ECGV25pJqdslHj34TnML7IWK(url)
	elif mode==429: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HjZcUIVAXFCqy9TfBWKtgY2(text)
	else: ft3e2JBKQVXWlFPjaMhkEqGxvDg = False
	return ft3e2JBKQVXWlFPjaMhkEqGxvDg
def eN02L7Tf5bQ():
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',EZxQp1WOldMTvFU,'','','','','CIMA4U-MENU-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	xxE5BSyQkNsj = My7Dwqvs6bfGNSIgX.findall('href="(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	xxE5BSyQkNsj = xxE5BSyQkNsj[0].strip('/')
	xxE5BSyQkNsj = ooq2D9xF8ZLpPBs(xxE5BSyQkNsj,'url')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'بحث في الموقع','',429,'','','_REMEMBERRESULTS_')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'فلتر محدد',xxE5BSyQkNsj,425)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'فلتر كامل',xxE5BSyQkNsj,424)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'الرئيسية',xxE5BSyQkNsj,421)
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('NavigationMenu(.*?)</div>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	vsptNMP2ZQC = XBuP6Op7y4K[0]
	items = My7Dwqvs6bfGNSIgX.findall('href="*(.*?)"*>(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	for BoEFz2WhUyvTgDeiZ,title in items:
		if title in eh2tDvRFWpLQI: continue
		if '/actors' in BoEFz2WhUyvTgDeiZ: title = 'أفلام النجوم'
		elif '/netflix' in BoEFz2WhUyvTgDeiZ: title = 'أفلام ومسلسلات نيتفلكس'
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,421)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'قائمة تفصيلية',xxE5BSyQkNsj,427)
	return
def u9ECGV25pJqdslHj34TnML7IWK(website=''):
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',EZxQp1WOldMTvFU,'','','','','CIMA4U-MENU-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('FilteringTitle(.*?)PageTitle',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	vsptNMP2ZQC = XBuP6Op7y4K[0]
	items = My7Dwqvs6bfGNSIgX.findall('data-tax="*(.*?)"* data-id="*(.*?)[">]*<a href="*(.*?)[">]+.*?</div>(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	for g4Y0BXLxCpuojKP1SAUtcq7TwN2,id,BoEFz2WhUyvTgDeiZ,title in items:
		if title in eh2tDvRFWpLQI: continue
		if 'netflix-movies' in BoEFz2WhUyvTgDeiZ: title = 'أفلام نيتفلكس'
		elif 'series-netflix' in BoEFz2WhUyvTgDeiZ: title = 'مسلسلات نيتفلكس'
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,421,'','',g4Y0BXLxCpuojKP1SAUtcq7TwN2+'|'+id)
	return
def sscM839DP1jWZ4zl6uIx0Kyn(url,rwQsc9O3oGdFKbxPlNiM56S2pLUJ0=''):
	if '/HomepageLoader/' in url: url = url.strip('/')+'/mpaa/family/'
	items = []
	xxE5BSyQkNsj = ooq2D9xF8ZLpPBs(url,'url')
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'',headers,'','','CIMA4U-TITLES-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	if not rwQsc9O3oGdFKbxPlNiM56S2pLUJ0 or '|' in rwQsc9O3oGdFKbxPlNiM56S2pLUJ0:
		if '|' not in rwQsc9O3oGdFKbxPlNiM56S2pLUJ0: asTe7z8WxFOQf = ''
		else: asTe7z8WxFOQf = '/archive/'+rwQsc9O3oGdFKbxPlNiM56S2pLUJ0
		t0p7jNyWB8rLfEn9oJe1m3TvZ = False
		if 'PinSlider' in MK6ZT2zjC1SbmveNFqor:
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'المميزة',url,421,'','','featured')
			t0p7jNyWB8rLfEn9oJe1m3TvZ = True
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('PageTitle(.*?)PageContent',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if XBuP6Op7y4K:
			iiBEzXVNFDhfj36 = XBuP6Op7y4K[0]
			zE1FBZLDvygwGdkef74lnRJVXCUqKH = My7Dwqvs6bfGNSIgX.findall('data-tab="(.*?)".*?<span>(.*?)<',iiBEzXVNFDhfj36,My7Dwqvs6bfGNSIgX.DOTALL)
			for J73raNFgQVe08ibxRXc,U2UaTcgBpsEZxKiRG1Xv8 in zE1FBZLDvygwGdkef74lnRJVXCUqKH:
				bOBQpgMudItXo = xxE5BSyQkNsj+'/ajaxcenter/action/HomepageLoader/tab/'+J73raNFgQVe08ibxRXc+asTe7z8WxFOQf+'/'
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+U2UaTcgBpsEZxKiRG1Xv8,bOBQpgMudItXo,421)
				t0p7jNyWB8rLfEn9oJe1m3TvZ = True
		if t0p7jNyWB8rLfEn9oJe1m3TvZ: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	if rwQsc9O3oGdFKbxPlNiM56S2pLUJ0=='featured':
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('PinSlider(.*?)MultiFilter',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if not XBuP6Op7y4K: XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('PinSlider(.*?)PageTitle',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if XBuP6Op7y4K: vsptNMP2ZQC = XBuP6Op7y4K[0]
		else: vsptNMP2ZQC = ''
	elif '/HomepageLoader/' in url or '/searchcenter/' in url:
		vsptNMP2ZQC = MK6ZT2zjC1SbmveNFqor
	elif '/filter/' in url:
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('PageContent(.*?)class="*pagination"*',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		vsptNMP2ZQC = XBuP6Op7y4K[0]
	elif '/actors' in url:
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('PageContent(.*?)class="*pagination"*',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="*(.*?)[">]+.*?image:url\((.*?)\).*?ActorName">(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	else:
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('Cima4uBlocks(.*?)</li></ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if XBuP6Op7y4K: vsptNMP2ZQC = XBuP6Op7y4K[0]
		else: vsptNMP2ZQC = ''
	if not items: items = My7Dwqvs6bfGNSIgX.findall('class="*MovieBlock"*.*?href="*(.*?)[">]+.*?image:url\((.*?)\).*?image.*?BoxTitleInfo.*?</div></div>(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	if not items: items = My7Dwqvs6bfGNSIgX.findall('class="MovieBlock".*?href="(.*?)".*?data-image="(.*?)".*?alt="(.*?)"',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	y7y3d5Fbhv42ONmtwLZ0SerYoQq = []
	for BoEFz2WhUyvTgDeiZ,IcWzVO137wFvemn2QTq8yKs9,title in items:
		if not title: continue
		if '?news=' in BoEFz2WhUyvTgDeiZ: continue
		title = title.replace('مشاهدة ','')
		title = PIfAumbGicwg5ye(title)
		ffhN7jAqe3Q4cR0Ukptzl = My7Dwqvs6bfGNSIgX.findall('(.*?) حلقة \d+',title,My7Dwqvs6bfGNSIgX.DOTALL)
		if ffhN7jAqe3Q4cR0Ukptzl and 'حلقة' in title:
			title = '_MOD_' + ffhN7jAqe3Q4cR0Ukptzl[0]
			if title not in y7y3d5Fbhv42ONmtwLZ0SerYoQq:
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,422,IcWzVO137wFvemn2QTq8yKs9)
				y7y3d5Fbhv42ONmtwLZ0SerYoQq.append(title)
		elif '/actor/' in BoEFz2WhUyvTgDeiZ: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,421,IcWzVO137wFvemn2QTq8yKs9)
		else: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,422,IcWzVO137wFvemn2QTq8yKs9)
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('pagination(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K and rwQsc9O3oGdFKbxPlNiM56S2pLUJ0!='featured':
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('href=[\'\"](.*?)[\'\"]>(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title in items:
			title = PIfAumbGicwg5ye(title)
			title = title.replace('الصفحة ','')
			if title!='': VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'صفحة '+title,BoEFz2WhUyvTgDeiZ,421)
	g7gdVaoK3PHGpJ1YBxvTSUkz = My7Dwqvs6bfGNSIgX.findall('</li><a href="(.*?)".*?>(.*?)<',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if g7gdVaoK3PHGpJ1YBxvTSUkz:
		BoEFz2WhUyvTgDeiZ,title = g7gdVaoK3PHGpJ1YBxvTSUkz[0]
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,421)
	return
def WWF1Rc6KZx(url):
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'','','','','CIMA4U-SEASONS-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('class="WatchNow".*?href="(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		url = XBuP6Op7y4K[0]
		xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'','','','','CIMA4U-SEASONS-2nd')
		MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('SeasonsSections(.*?)</div></div></div>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if '/tag/' in url or '/actor' in url:
		sscM839DP1jWZ4zl6uIx0Kyn(url)
	elif XBuP6Op7y4K:
		IcWzVO137wFvemn2QTq8yKs9 = tUXmK5PeEH9SDq.getInfoLabel('ListItem.Thumb')
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall("href='(.*?)'>(.*?)<",vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		AyOoeEJt6Kg7SVRG9 = ['مسلسل','موسم','برنامج','حلقة']
		for BoEFz2WhUyvTgDeiZ,title in items:
			if any(WoFrX46wzbCNp18 in title for WoFrX46wzbCNp18 in AyOoeEJt6Kg7SVRG9):
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,423,IcWzVO137wFvemn2QTq8yKs9)
			else: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,426,IcWzVO137wFvemn2QTq8yKs9)
	else: o4oY13v5dWMcbilEDjKCnXNzHZ0(url)
	return
def o4oY13v5dWMcbilEDjKCnXNzHZ0(url):
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'','','','','CIMA4U-EPISODES-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	IcWzVO137wFvemn2QTq8yKs9 = My7Dwqvs6bfGNSIgX.findall('"background-image:url\((.*?)\)',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if IcWzVO137wFvemn2QTq8yKs9: IcWzVO137wFvemn2QTq8yKs9 = IcWzVO137wFvemn2QTq8yKs9[0]
	else: IcWzVO137wFvemn2QTq8yKs9 = ''
	MnacHlNXuFr8WPhbZOt40Q = My7Dwqvs6bfGNSIgX.findall('EpisodesSection(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if MnacHlNXuFr8WPhbZOt40Q:
		vsptNMP2ZQC = MnacHlNXuFr8WPhbZOt40Q[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)"><em>(.*?)<.*?<span>(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title,ffhN7jAqe3Q4cR0Ukptzl in items:
			title = title+' '+ffhN7jAqe3Q4cR0Ukptzl
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,426,IcWzVO137wFvemn2QTq8yKs9)
	else: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+'رابط التشغيل',url,426,IcWzVO137wFvemn2QTq8yKs9)
	return
def HDxCnPKFhITpZmOsA4a0UL6(url):
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'',headers,'','','CIMA4U-PLAY-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	kVwxsIzvfqhbR9JNoX = xHb86g9WZqPwRfVjXD2JalzSIp.url
	if V8fmEML1b0PeaRZySnzh3H5J9: kVwxsIzvfqhbR9JNoX = kVwxsIzvfqhbR9JNoX.encode('utf8')
	xxE5BSyQkNsj = ooq2D9xF8ZLpPBs(kVwxsIzvfqhbR9JNoX,'url')
	QQ2cE1FjUyxPonbDhaTkV6B3i = []
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('WatchSection(.*?)</div></div>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('data-link="(.*?)".*? />(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for p8hzHJnjC95karceyWxX,title in items:
			title = title.strip(' ')
			if 'myvid' in title.lower(): title = 'خاص '+title
			BoEFz2WhUyvTgDeiZ = xxE5BSyQkNsj+'/structure/server.php?id='+p8hzHJnjC95karceyWxX+'?named='+title+'__watch'
			BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ.replace('\r','')
			QQ2cE1FjUyxPonbDhaTkV6B3i.append(BoEFz2WhUyvTgDeiZ)
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('DownloadServers(.*?)</div></div>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*? />(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title in items:
			title = title.strip(' ')
			if 'myvid' in title.lower(): U2UaTcgBpsEZxKiRG1Xv8 = '__خاص'
			else: U2UaTcgBpsEZxKiRG1Xv8 = ''
			BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ+'?named='+title+'__download'+U2UaTcgBpsEZxKiRG1Xv8
			BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ.replace('\r','')
			QQ2cE1FjUyxPonbDhaTkV6B3i.append(BoEFz2WhUyvTgDeiZ)
	import t1kDWXQVpC
	t1kDWXQVpC.rqVt2xDi7jzJHBcPMRs6h0L(QQ2cE1FjUyxPonbDhaTkV6B3i,baNWS6nfqTC5iX4Kl,'video',url)
	return
def HjZcUIVAXFCqy9TfBWKtgY2(search):
	search,LQf3AeozSrai,showDialogs = X54MLovbG8nAEkB9J(search)
	if search=='': search = ViKAIsLurq83RSENayxWb()
	if search=='': return
	search = search.replace(' ','+')
	url = EZxQp1WOldMTvFU+'/Search?q='+search
	sscM839DP1jWZ4zl6uIx0Kyn(url,'search')
	return
def lAjOn69YLFxJNEvTrbfwkiXm2d(url):
	if 'smartemadfilter' not in url: url = ooq2D9xF8ZLpPBs(url,'url')
	else: url = url.split('/smartemadfilter?')[0]
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'','','','','CIMA4U-GET_FILTERS_BLOCKS-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('MultiFilter(.*?)PageTitle',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	vsptNMP2ZQC = XBuP6Op7y4K[0]
	E3ErsLQfR4JXt = My7Dwqvs6bfGNSIgX.findall('Hoverable.*?<span>(.*?)</span>.*?"all".*?(data-tax="(.*?)".*?)</ul>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	return E3ErsLQfR4JXt
def kvYFrVe3g8H7dNhIa(vsptNMP2ZQC):
	items = My7Dwqvs6bfGNSIgX.findall('data-id="(.*?)".*?</div>(.*?)</a>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	return items
def NewZb13oj4KLaqD0JzGPf6rYQ2ARn(url):
	ulX0L8F7ZqcwGTJRMk = url.split('/smartemadfilter?')[0]
	M0RTIYy1EUX = ooq2D9xF8ZLpPBs(url,'url')
	url = url.replace(ulX0L8F7ZqcwGTJRMk,M0RTIYy1EUX)
	url = url.replace('/smartemadfilter?','/ajaxcenter/action/HomepageLoader/')
	url = url.replace('=','/').replace('&','/')
	url = url+'/'
	return url
vIZKhbfsXmWAyUVecrNOz95LQ = ['category','types','release-year']
lWF7u5qUtSak3B = ['Quality','release-year','types','category']
def LLJlTxDePyjoVKA(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter=='': H2HMwT4JFz7rDkPZmRjcX,JPnr9ICqkDyV = '',''
	else: H2HMwT4JFz7rDkPZmRjcX,JPnr9ICqkDyV = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if '/category/' in url:
			global vIZKhbfsXmWAyUVecrNOz95LQ
			vIZKhbfsXmWAyUVecrNOz95LQ = vIZKhbfsXmWAyUVecrNOz95LQ[1:]
		if vIZKhbfsXmWAyUVecrNOz95LQ[0]+'=' not in H2HMwT4JFz7rDkPZmRjcX: g4Y0BXLxCpuojKP1SAUtcq7TwN2 = vIZKhbfsXmWAyUVecrNOz95LQ[0]
		for FVW0I9sYcAjmDgn8r in range(len(vIZKhbfsXmWAyUVecrNOz95LQ[0:-1])):
			if vIZKhbfsXmWAyUVecrNOz95LQ[FVW0I9sYcAjmDgn8r]+'=' in H2HMwT4JFz7rDkPZmRjcX: g4Y0BXLxCpuojKP1SAUtcq7TwN2 = vIZKhbfsXmWAyUVecrNOz95LQ[FVW0I9sYcAjmDgn8r+1]
		HHXeMqVOshPcW3tULa5v = H2HMwT4JFz7rDkPZmRjcX+'&'+g4Y0BXLxCpuojKP1SAUtcq7TwN2+'=0'
		DoSfCckGA9BQe = JPnr9ICqkDyV+'&'+g4Y0BXLxCpuojKP1SAUtcq7TwN2+'=0'
		A7AEKRlF6Hf3eWVxY0NdwgsMPCc = HHXeMqVOshPcW3tULa5v.strip('&')+'___'+DoSfCckGA9BQe.strip('&')
		woj78rBnbLlmZWIy19iPHFCf5 = BrbZhHKJ0jnIe2lumE9M(JPnr9ICqkDyV,'modified_filters')
		bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = url+'/smartemadfilter?'+woj78rBnbLlmZWIy19iPHFCf5
	elif type=='ALL_ITEMS_FILTER':
		WUSylLup41cYkhVXGtq = BrbZhHKJ0jnIe2lumE9M(H2HMwT4JFz7rDkPZmRjcX,'modified_values')
		WUSylLup41cYkhVXGtq = XnQbsZF0Ouh8p7zCdUN(WUSylLup41cYkhVXGtq)
		if JPnr9ICqkDyV!='': JPnr9ICqkDyV = BrbZhHKJ0jnIe2lumE9M(JPnr9ICqkDyV,'modified_filters')
		if JPnr9ICqkDyV=='': bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = url
		else: bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = url+'/smartemadfilter?'+JPnr9ICqkDyV
		bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = NewZb13oj4KLaqD0JzGPf6rYQ2ARn(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'أظهار قائمة الفيديو التي تم اختيارها ',bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,421,'','','filter')
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+' [[   '+WUSylLup41cYkhVXGtq+'   ]]',bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,421,'','','filter')
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	E3ErsLQfR4JXt = lAjOn69YLFxJNEvTrbfwkiXm2d(url)
	dict = {}
	for name,vsptNMP2ZQC,RTsbVE9CiQt in E3ErsLQfR4JXt:
		if '/category/' in url and RTsbVE9CiQt=='category': continue
		name = name.replace('--','')
		items = kvYFrVe3g8H7dNhIa(vsptNMP2ZQC)
		if '=' not in bJEs4IVAPdyUrhwCLv9k2YoOl8nt1: bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = url
		if type=='SPECIFIED_FILTER':
			if g4Y0BXLxCpuojKP1SAUtcq7TwN2!=RTsbVE9CiQt: continue
			elif len(items)<2:
				if RTsbVE9CiQt==vIZKhbfsXmWAyUVecrNOz95LQ[-1]:
					url = NewZb13oj4KLaqD0JzGPf6rYQ2ARn(url)
					sscM839DP1jWZ4zl6uIx0Kyn(url)
				else: LLJlTxDePyjoVKA(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,'SPECIFIED_FILTER___'+A7AEKRlF6Hf3eWVxY0NdwgsMPCc)
				return
			else:
				bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = NewZb13oj4KLaqD0JzGPf6rYQ2ARn(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1)
				if RTsbVE9CiQt==vIZKhbfsXmWAyUVecrNOz95LQ[-1]: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'الجميع',bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,421,'','','filter')
				else: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'الجميع',bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,425,'','',A7AEKRlF6Hf3eWVxY0NdwgsMPCc)
		elif type=='ALL_ITEMS_FILTER':
			HHXeMqVOshPcW3tULa5v = H2HMwT4JFz7rDkPZmRjcX+'&'+RTsbVE9CiQt+'=0'
			DoSfCckGA9BQe = JPnr9ICqkDyV+'&'+RTsbVE9CiQt+'=0'
			A7AEKRlF6Hf3eWVxY0NdwgsMPCc = HHXeMqVOshPcW3tULa5v+'___'+DoSfCckGA9BQe
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'الجميع :'+name,bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,424,'','',A7AEKRlF6Hf3eWVxY0NdwgsMPCc)
		dict[RTsbVE9CiQt] = {}
		for WoFrX46wzbCNp18,A5AMg7LY1HlOz0B82n in items:
			if WoFrX46wzbCNp18=='196533': A5AMg7LY1HlOz0B82n = 'أفلام نيتفلكس'
			elif WoFrX46wzbCNp18=='196531': A5AMg7LY1HlOz0B82n = 'مسلسلات نيتفلكس'
			if A5AMg7LY1HlOz0B82n in eh2tDvRFWpLQI: continue
			dict[RTsbVE9CiQt][WoFrX46wzbCNp18] = A5AMg7LY1HlOz0B82n
			HHXeMqVOshPcW3tULa5v = H2HMwT4JFz7rDkPZmRjcX+'&'+RTsbVE9CiQt+'='+A5AMg7LY1HlOz0B82n
			DoSfCckGA9BQe = JPnr9ICqkDyV+'&'+RTsbVE9CiQt+'='+WoFrX46wzbCNp18
			QQIzTLCXyhtZ7pRNnGq = HHXeMqVOshPcW3tULa5v+'___'+DoSfCckGA9BQe
			title = A5AMg7LY1HlOz0B82n+' :'#+dict[RTsbVE9CiQt]['0']
			title = A5AMg7LY1HlOz0B82n+' :'+name
			if type=='ALL_ITEMS_FILTER': VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,url,424,'','',QQIzTLCXyhtZ7pRNnGq)
			elif type=='SPECIFIED_FILTER' and vIZKhbfsXmWAyUVecrNOz95LQ[-2]+'=' in H2HMwT4JFz7rDkPZmRjcX:
				woj78rBnbLlmZWIy19iPHFCf5 = BrbZhHKJ0jnIe2lumE9M(DoSfCckGA9BQe,'modified_filters')
				QAKdHzO0rehbtyIc = url+'/smartemadfilter?'+woj78rBnbLlmZWIy19iPHFCf5
				QAKdHzO0rehbtyIc = NewZb13oj4KLaqD0JzGPf6rYQ2ARn(QAKdHzO0rehbtyIc)
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,QAKdHzO0rehbtyIc,421,'','','filter')
			else: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,url,425,'','',QQIzTLCXyhtZ7pRNnGq)
	return
def BrbZhHKJ0jnIe2lumE9M(PPebqkulZUsx3GCLdnYvR,mode):
	PPebqkulZUsx3GCLdnYvR = PPebqkulZUsx3GCLdnYvR.replace('=&','=0&')
	PPebqkulZUsx3GCLdnYvR = PPebqkulZUsx3GCLdnYvR.strip('&')
	mVSjqdOvyf = {}
	if '=' in PPebqkulZUsx3GCLdnYvR:
		items = PPebqkulZUsx3GCLdnYvR.split('&')
		for ZA1fBenNahOR3xrkjvwYSVMy6JK5s in items:
			nmqEj60bcdSQoFPGa,WoFrX46wzbCNp18 = ZA1fBenNahOR3xrkjvwYSVMy6JK5s.split('=')
			mVSjqdOvyf[nmqEj60bcdSQoFPGa] = WoFrX46wzbCNp18
	DidZH6E0pJelcU9xMCBgyL2KvR = ''
	for key in lWF7u5qUtSak3B:
		if key in list(mVSjqdOvyf.keys()): WoFrX46wzbCNp18 = mVSjqdOvyf[key]
		else: WoFrX46wzbCNp18 = '0'
		if '%' not in WoFrX46wzbCNp18: WoFrX46wzbCNp18 = F8fMqZKB4APk(WoFrX46wzbCNp18)
		if mode=='modified_values' and WoFrX46wzbCNp18!='0': DidZH6E0pJelcU9xMCBgyL2KvR = DidZH6E0pJelcU9xMCBgyL2KvR+' + '+WoFrX46wzbCNp18
		elif mode=='modified_filters' and WoFrX46wzbCNp18!='0': DidZH6E0pJelcU9xMCBgyL2KvR = DidZH6E0pJelcU9xMCBgyL2KvR+'&'+key+'='+WoFrX46wzbCNp18
		elif mode=='all': DidZH6E0pJelcU9xMCBgyL2KvR = DidZH6E0pJelcU9xMCBgyL2KvR+'&'+key+'='+WoFrX46wzbCNp18
	DidZH6E0pJelcU9xMCBgyL2KvR = DidZH6E0pJelcU9xMCBgyL2KvR.strip(' + ')
	DidZH6E0pJelcU9xMCBgyL2KvR = DidZH6E0pJelcU9xMCBgyL2KvR.strip('&')
	DidZH6E0pJelcU9xMCBgyL2KvR = DidZH6E0pJelcU9xMCBgyL2KvR.replace('=0','=')
	return DidZH6E0pJelcU9xMCBgyL2KvR
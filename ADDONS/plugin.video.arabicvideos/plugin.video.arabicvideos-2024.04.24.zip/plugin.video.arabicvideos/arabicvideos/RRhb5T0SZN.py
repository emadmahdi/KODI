# -*- coding: utf-8 -*-
from G6AHskJeqN import *
baNWS6nfqTC5iX4Kl = 'SHIAVOICE'
teUPLFC3B8bArakwHVGsdhoIWDM49f = '_SHV_'
EZxQp1WOldMTvFU = AK5RqLhji4W1wt9VdrCD3PGeQM[baNWS6nfqTC5iX4Kl][0]
headers = {'User-Agent':None}
def VbgEajY4Bt2COpGDcPqI(mode,url,text):
	if   mode==310: ft3e2JBKQVXWlFPjaMhkEqGxvDg = eN02L7Tf5bQ()
	elif mode==311: ft3e2JBKQVXWlFPjaMhkEqGxvDg = sscM839DP1jWZ4zl6uIx0Kyn(url)
	elif mode==312: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HDxCnPKFhITpZmOsA4a0UL6(url)
	elif mode==313: ft3e2JBKQVXWlFPjaMhkEqGxvDg = MyDAlJkeUtco3GP6TSV(url)
	elif mode==314: ft3e2JBKQVXWlFPjaMhkEqGxvDg = jteCU2z0EY4J6dFA(text)
	elif mode==319: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HjZcUIVAXFCqy9TfBWKtgY2(text)
	else: ft3e2JBKQVXWlFPjaMhkEqGxvDg = False
	return ft3e2JBKQVXWlFPjaMhkEqGxvDg
def eN02L7Tf5bQ():
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'بحث في الموقع','',319,'','','_REMEMBERRESULTS_')
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(IIiPCruL6dT8s1lqj47SzpVHnYNm,'GET',EZxQp1WOldMTvFU,'','','','','SHIAVOICE-MENU-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('id="menulinks"(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	vsptNMP2ZQC = XBuP6Op7y4K[0]
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	items = My7Dwqvs6bfGNSIgX.findall('<h5>(.*?)</h5>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL|My7Dwqvs6bfGNSIgX.IGNORECASE)
	for DQlGE75goqn9fkJt0P8ihR in range(len(items)):
		title = items[DQlGE75goqn9fkJt0P8ihR].strip(' ')
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+title,EZxQp1WOldMTvFU,314,'','',str(DQlGE75goqn9fkJt0P8ihR+1))
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'مقاطع شهر',EZxQp1WOldMTvFU,314,'','','0')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?<B>(.*?)</B>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	for BoEFz2WhUyvTgDeiZ,title in items:
		BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU+'/'+BoEFz2WhUyvTgDeiZ
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,311)
	return MK6ZT2zjC1SbmveNFqor
def jteCU2z0EY4J6dFA(DQlGE75goqn9fkJt0P8ihR):
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(f9Oum6c0FotxYn,'GET',EZxQp1WOldMTvFU,'','','','','SHIAVOICE-LATEST-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	if DQlGE75goqn9fkJt0P8ihR=='0':
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('class="tab-content"(.*?)</table>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?title="(.*?)".*?</i>(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,name,title in items:
			BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU+'/'+BoEFz2WhUyvTgDeiZ
			title = title.strip(' ')
			name = name.strip(' ')
			title = title+' ('+name+')'
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,312)
	elif DQlGE75goqn9fkJt0P8ihR in ['1','2','3']:
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('(<h5>.*?)<div class="col-lg',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		kAJ40qZt5YdEMe9SQwm = int(DQlGE75goqn9fkJt0P8ihR)-1
		vsptNMP2ZQC = XBuP6Op7y4K[kAJ40qZt5YdEMe9SQwm]
		if DQlGE75goqn9fkJt0P8ihR=='1': items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?src="(.*?)".*?<strong>(.*?)<.*?</i>(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		else: items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?src="(.*?)".*?<strong>(.*?)<.*?href=".*?">(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,IcWzVO137wFvemn2QTq8yKs9,title,name in items:
			IcWzVO137wFvemn2QTq8yKs9 = EZxQp1WOldMTvFU+'/'+IcWzVO137wFvemn2QTq8yKs9
			BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU+'/'+BoEFz2WhUyvTgDeiZ
			title = title.strip(' ')
			name = name.strip(' ')
			title = title+' ('+name+')'
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,311,IcWzVO137wFvemn2QTq8yKs9)
	elif DQlGE75goqn9fkJt0P8ihR in ['4','5','6']:
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('(<h5>.*?)</table>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		DQlGE75goqn9fkJt0P8ihR = int(DQlGE75goqn9fkJt0P8ihR)-4
		vsptNMP2ZQC = XBuP6Op7y4K[DQlGE75goqn9fkJt0P8ihR]
		items = My7Dwqvs6bfGNSIgX.findall('src="(.*?)".*?href="(.*?)".*?title="(.*?)".*?<strong.*?>(.*?)</strong>.*?-cell">(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for IcWzVO137wFvemn2QTq8yKs9,BoEFz2WhUyvTgDeiZ,mNldo9CrLIXJkbWAzEpD56,title,bdHQJiTCSFGgoXL3v2rMNAEn6y in items:
			IcWzVO137wFvemn2QTq8yKs9 = EZxQp1WOldMTvFU+'/'+IcWzVO137wFvemn2QTq8yKs9
			BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU+'/'+BoEFz2WhUyvTgDeiZ
			title = title.strip(' ')
			mNldo9CrLIXJkbWAzEpD56 = mNldo9CrLIXJkbWAzEpD56.strip(' ')
			bdHQJiTCSFGgoXL3v2rMNAEn6y = bdHQJiTCSFGgoXL3v2rMNAEn6y.strip(' ')
			if mNldo9CrLIXJkbWAzEpD56: name = mNldo9CrLIXJkbWAzEpD56
			else: name = bdHQJiTCSFGgoXL3v2rMNAEn6y
			title = title+' ('+name+')'
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,312,IcWzVO137wFvemn2QTq8yKs9)
	return
def sscM839DP1jWZ4zl6uIx0Kyn(url):
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'','','','','SHIAVOICE-TITLES-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('ibox-heading"(.*?)class="float-right',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	vsptNMP2ZQC = XBuP6Op7y4K[0]
	if 'catsum-mobile' in vsptNMP2ZQC:
		items = My7Dwqvs6bfGNSIgX.findall('src="(.*?)".*?href="(.*?)".*?<strong>(.*?)</strong>.*?catsum-mobile">(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		if items:
			for IcWzVO137wFvemn2QTq8yKs9,BoEFz2WhUyvTgDeiZ,title,count in items:
				IcWzVO137wFvemn2QTq8yKs9 = EZxQp1WOldMTvFU+'/'+IcWzVO137wFvemn2QTq8yKs9
				BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU+'/'+BoEFz2WhUyvTgDeiZ
				count = count.replace(' الصوتية: ',':')
				title = title.strip(' ')
				title = title+' ('+count+')'
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,311,IcWzVO137wFvemn2QTq8yKs9)
	else:
		items = My7Dwqvs6bfGNSIgX.findall('" href="(.*?)".*?</i>(.*?)</a>.*?">(.*?)<.*?<span.*?<span.*?<span.*?">(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title,UAxSTHBoeRhMJQPXVZDsEzN1qnWc,LEb1HQDAeFdsrNTnVgmXo9 in items:
			if title=='' or UAxSTHBoeRhMJQPXVZDsEzN1qnWc=='': continue
			BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU+'/'+BoEFz2WhUyvTgDeiZ
			title = title+' ('+LEb1HQDAeFdsrNTnVgmXo9+')'
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,312)
	if not items: o4oY13v5dWMcbilEDjKCnXNzHZ0(MK6ZT2zjC1SbmveNFqor)
	return
def o4oY13v5dWMcbilEDjKCnXNzHZ0(MK6ZT2zjC1SbmveNFqor):
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('class="ibox-content"(.*?)class="pagination',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	vsptNMP2ZQC = XBuP6Op7y4K[0]
	items = My7Dwqvs6bfGNSIgX.findall('href="(http.*?)".*?</i>(.*?)<.*?cell">(.*?)<.*?cell">(.*?)<.*?cell">(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	for BoEFz2WhUyvTgDeiZ,title,name,count,LEb1HQDAeFdsrNTnVgmXo9 in items:
		BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU+'/'+BoEFz2WhUyvTgDeiZ
		title = title.strip(' ')
		name = name.strip(' ')
		title = title+' ('+name+')'
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,312,'',LEb1HQDAeFdsrNTnVgmXo9)
	return
def MyDAlJkeUtco3GP6TSV(url):
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'','','','','SHIAVOICE-SEARCH_ITEMS-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('class="ibox-content p-1"(.*?)class="ibox-content"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if not XBuP6Op7y4K:
		sscM839DP1jWZ4zl6uIx0Kyn(url)
		return
	vsptNMP2ZQC = XBuP6Op7y4K[0]
	items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?<strong>(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	for BoEFz2WhUyvTgDeiZ,title in items:
		BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU+'/'+BoEFz2WhUyvTgDeiZ
		title = title.strip(' ')
		if '/play-' in BoEFz2WhUyvTgDeiZ: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,312)
		else: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,311)
	return
def HDxCnPKFhITpZmOsA4a0UL6(url):
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(f9Oum6c0FotxYn,'GET',url,'','','','','SHIAVOICE-PLAY-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	BoEFz2WhUyvTgDeiZ = My7Dwqvs6bfGNSIgX.findall('<audio.*?src="(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if not BoEFz2WhUyvTgDeiZ: BoEFz2WhUyvTgDeiZ = My7Dwqvs6bfGNSIgX.findall('<video.*?src="(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU+BoEFz2WhUyvTgDeiZ[0]
	B0xcwKkMQ16mpSFRaVHPTzuhUZngLq(BoEFz2WhUyvTgDeiZ,baNWS6nfqTC5iX4Kl,'video')
	return
def HjZcUIVAXFCqy9TfBWKtgY2(search):
	search,LQf3AeozSrai,showDialogs = X54MLovbG8nAEkB9J(search)
	if search=='': search = ViKAIsLurq83RSENayxWb()
	if search=='': return
	search = search.replace(' ','+')
	kkZTP0dU7EQzyXOpo = ['&t=a','&t=c','&t=s']
	if showDialogs:
		FX0Jbn9eWBq1lGK6V = ['قارئ','إصدار / مجلد','مقطع الصوتي']
		GOtNfU3xQFkEhPouwA = CnKwdteDG5BE8MTRhUpYIJm3NLrSgq('موقع صوت الشيعة - أختر البحث', FX0Jbn9eWBq1lGK6V)
		if GOtNfU3xQFkEhPouwA == -1: return
	elif '_SHIAVOICE-PERSONS_' in LQf3AeozSrai: GOtNfU3xQFkEhPouwA = 0
	elif '_SHIAVOICE-ALBUMS_' in LQf3AeozSrai: GOtNfU3xQFkEhPouwA = 1
	elif '_SHIAVOICE-AUDIOS_' in LQf3AeozSrai: GOtNfU3xQFkEhPouwA = 2
	else: return
	type = kkZTP0dU7EQzyXOpo[GOtNfU3xQFkEhPouwA]
	url = EZxQp1WOldMTvFU+'/search.php?q='+search+type
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'','','','','SHIAVOICE-SEARCH-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('class="ibox-content"(.*?)class="ibox-content"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		if GOtNfU3xQFkEhPouwA in [0,1]:
			items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?src="(.*?)".*?href=".*?">(.*?)<.*?">(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
			for BoEFz2WhUyvTgDeiZ,IcWzVO137wFvemn2QTq8yKs9,title,name in items:
				title = title.strip(' ')
				name = name.strip(' ')
				title = title+' ('+name+')'
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,313,IcWzVO137wFvemn2QTq8yKs9)
		elif GOtNfU3xQFkEhPouwA==2:
			items = My7Dwqvs6bfGNSIgX.findall('href="(http.*?)".*?</i>(.*?)</a></td><td>(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
			for BoEFz2WhUyvTgDeiZ,title,name in items:
				title = title.strip(' ')
				name = name.strip(' ')
				title = title+' ('+name+')'
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,312)
	return
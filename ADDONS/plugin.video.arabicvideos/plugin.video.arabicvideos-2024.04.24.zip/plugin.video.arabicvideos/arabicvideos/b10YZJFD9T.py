# -*- coding: utf-8 -*-
from G6AHskJeqN import *
baNWS6nfqTC5iX4Kl = 'EGYBESTVIP'
teUPLFC3B8bArakwHVGsdhoIWDM49f = '_EGV_'
EZxQp1WOldMTvFU = AK5RqLhji4W1wt9VdrCD3PGeQM[baNWS6nfqTC5iX4Kl][0]
def VbgEajY4Bt2COpGDcPqI(mode,url,z3z9QgENFk5eMYB4,text):
	if   mode==220: ft3e2JBKQVXWlFPjaMhkEqGxvDg = eN02L7Tf5bQ()
	elif mode==221: ft3e2JBKQVXWlFPjaMhkEqGxvDg = sscM839DP1jWZ4zl6uIx0Kyn(url,z3z9QgENFk5eMYB4)
	elif mode==222: ft3e2JBKQVXWlFPjaMhkEqGxvDg = M25iOAH9NfalvyPEUuToG8qn(url)
	elif mode==223: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HDxCnPKFhITpZmOsA4a0UL6(url)
	elif mode==224: ft3e2JBKQVXWlFPjaMhkEqGxvDg = LLJlTxDePyjoVKA(url)
	elif mode==229: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HjZcUIVAXFCqy9TfBWKtgY2(text)
	else: ft3e2JBKQVXWlFPjaMhkEqGxvDg = False
	return ft3e2JBKQVXWlFPjaMhkEqGxvDg
def eN02L7Tf5bQ():
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'بحث في الموقع','',229,'','','_REMEMBERRESULTS_')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(IIiPCruL6dT8s1lqj47SzpVHnYNm,'GET',EZxQp1WOldMTvFU,'','','','','EGYBEST-MENU-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('class="i i-home"(.*?)</div>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)"(.*?)</a>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title in items:
			if '</i>' in title: title = title.split('</i>')[1]
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,222)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('class="ba(.*?)<script',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('pda bdb"><strong>(.*?)<.*?href="(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		for title,BoEFz2WhUyvTgDeiZ in items:
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,221)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?>(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title in items:
			if 'html' not in BoEFz2WhUyvTgDeiZ: continue
			if not BoEFz2WhUyvTgDeiZ.endswith('/'): VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,221)
	return MK6ZT2zjC1SbmveNFqor
def M25iOAH9NfalvyPEUuToG8qn(url):
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(IIiPCruL6dT8s1lqj47SzpVHnYNm,'GET',url,'','','','','EGYBESTVIP-SUBMENU-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('class="rs_scroll"(.*?)</div>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	vsptNMP2ZQC = XBuP6Op7y4K[0]
	items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?</i>(.*?)</a>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	for BoEFz2WhUyvTgDeiZ,title in items:
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,224)
	return
def LLJlTxDePyjoVKA(url):
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'الجميع',url,221)
	MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(IIiPCruL6dT8s1lqj47SzpVHnYNm,url,'','','','EGYBESTVIP-FILTERS_MENU-1st')
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('class="sub_nav(.*?)id="movies',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".+?>(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title in items:
			if BoEFz2WhUyvTgDeiZ=='#': name = title
			else:
				title = title + '  :  ' + 'فلتر ' + name
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,221)
	else: sscM839DP1jWZ4zl6uIx0Kyn(url)
	return
def sscM839DP1jWZ4zl6uIx0Kyn(url,z3z9QgENFk5eMYB4='1'):
	if z3z9QgENFk5eMYB4=='': z3z9QgENFk5eMYB4 = '1'
	if '/search' in url or '?' in url: bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = url + '&'
	else: bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = url + '?'
	bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 + 'page=' + z3z9QgENFk5eMYB4
	MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(UuEtImzir9,bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,'','','','EGYBESTVIP-TITLES-1st')
	if '/season' in url:
		XBuP6Op7y4K=My7Dwqvs6bfGNSIgX.findall('class="pda"(.*?)div',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		vsptNMP2ZQC = XBuP6Op7y4K[-1]
	elif '/series/' in url:
		XBuP6Op7y4K=My7Dwqvs6bfGNSIgX.findall('class="owl-carousel owl-carousel(.*?)div',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		vsptNMP2ZQC = XBuP6Op7y4K[0]
	else:
		XBuP6Op7y4K=My7Dwqvs6bfGNSIgX.findall('id="movies(.*?)</div>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		vsptNMP2ZQC = XBuP6Op7y4K[-1]
	items = My7Dwqvs6bfGNSIgX.findall('<a href="(.*?)".*?src="(.*?)".*?title">(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	for BoEFz2WhUyvTgDeiZ,IcWzVO137wFvemn2QTq8yKs9,title in items:
		title = PIfAumbGicwg5ye(title)
		if '/movie/' in BoEFz2WhUyvTgDeiZ or '/episode' in BoEFz2WhUyvTgDeiZ:
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ.rstrip('/'),223,IcWzVO137wFvemn2QTq8yKs9)
		else:
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,221,IcWzVO137wFvemn2QTq8yKs9)
	if len(items)>=16:
		HNG0YTamvdCiIt2g = ['/movies','/tv','/search','/trending']
		z3z9QgENFk5eMYB4 = int(z3z9QgENFk5eMYB4)
		if any(WoFrX46wzbCNp18 in url for WoFrX46wzbCNp18 in HNG0YTamvdCiIt2g):
			for ttpGk2RKTzau8QFyZovb6d in range(0,1000,100):
				if int(z3z9QgENFk5eMYB4/100)*100==ttpGk2RKTzau8QFyZovb6d:
					for FVW0I9sYcAjmDgn8r in range(ttpGk2RKTzau8QFyZovb6d,ttpGk2RKTzau8QFyZovb6d+100,10):
						if int(z3z9QgENFk5eMYB4/10)*10==FVW0I9sYcAjmDgn8r:
							for KAH74mzCaMQkgxuJ3iNFsLGjXh in range(FVW0I9sYcAjmDgn8r,FVW0I9sYcAjmDgn8r+10,1):
								if not z3z9QgENFk5eMYB4==KAH74mzCaMQkgxuJ3iNFsLGjXh and KAH74mzCaMQkgxuJ3iNFsLGjXh!=0:
									VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'صفحة '+str(KAH74mzCaMQkgxuJ3iNFsLGjXh),url,221,'',str(KAH74mzCaMQkgxuJ3iNFsLGjXh))
						elif FVW0I9sYcAjmDgn8r!=0: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'صفحة '+str(FVW0I9sYcAjmDgn8r),url,221,'',str(FVW0I9sYcAjmDgn8r))
						else: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'صفحة '+str(1),url,221,'',str(1))
				elif ttpGk2RKTzau8QFyZovb6d!=0: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'صفحة '+str(ttpGk2RKTzau8QFyZovb6d),url,221,'',str(ttpGk2RKTzau8QFyZovb6d))
				else: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'صفحة '+str(1),url,221)
	return
def HDxCnPKFhITpZmOsA4a0UL6(url):
	wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = [],[]
	MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(IIiPCruL6dT8s1lqj47SzpVHnYNm,url,'','','','EGYBESTVIP-PLAY-1st')
	ME2Q6F7u8Vp1km9ws = My7Dwqvs6bfGNSIgX.findall('<td>التصنيف</td>.*?">(.*?)<',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if ME2Q6F7u8Vp1km9ws and a97xrkSOefH5DbjXunq(baNWS6nfqTC5iX4Kl,url,ME2Q6F7u8Vp1km9ws): return
	mj6Sw8JteAr5zbsWic,u3uqSNbACv = '',''
	xJkZ1pD5GmQdAyito4IjbTKFMuP,VnU6DwrpfkSaTsv = MK6ZT2zjC1SbmveNFqor,MK6ZT2zjC1SbmveNFqor
	rdfOwejPv3bcyAtM58 = My7Dwqvs6bfGNSIgX.findall('show_dl api" href="(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if rdfOwejPv3bcyAtM58:
		for BoEFz2WhUyvTgDeiZ in rdfOwejPv3bcyAtM58:
			if '/watch/' in BoEFz2WhUyvTgDeiZ: mj6Sw8JteAr5zbsWic = BoEFz2WhUyvTgDeiZ
			elif '/download/' in BoEFz2WhUyvTgDeiZ: u3uqSNbACv = BoEFz2WhUyvTgDeiZ
		if mj6Sw8JteAr5zbsWic!='': xJkZ1pD5GmQdAyito4IjbTKFMuP = YY0KEWamSIc46n3kbtuLgZV(IIiPCruL6dT8s1lqj47SzpVHnYNm,mj6Sw8JteAr5zbsWic,'','','','EGYBESTVIP-PLAY-2nd')
		if u3uqSNbACv!='': VnU6DwrpfkSaTsv = YY0KEWamSIc46n3kbtuLgZV(IIiPCruL6dT8s1lqj47SzpVHnYNm,u3uqSNbACv,'','','','EGYBESTVIP-PLAY-3rd')
	NZByvbqADMoFzt2Q5m8LsJUH = My7Dwqvs6bfGNSIgX.findall('id="video".*?data-src="(.*?)"',xJkZ1pD5GmQdAyito4IjbTKFMuP,My7Dwqvs6bfGNSIgX.DOTALL)
	if NZByvbqADMoFzt2Q5m8LsJUH:
		bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = NZByvbqADMoFzt2Q5m8LsJUH[0]
		if bJEs4IVAPdyUrhwCLv9k2YoOl8nt1!='' and 'uploaded.egybest.download' in bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 and '/?id=_' not in bJEs4IVAPdyUrhwCLv9k2YoOl8nt1:
			wN6n7OZBoDkTvCi8LdbJjYV = YY0KEWamSIc46n3kbtuLgZV(IIiPCruL6dT8s1lqj47SzpVHnYNm,bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,'','','','EGYBESTVIP-PLAY-4th')
			TFZgy6WoC9HQjMnDimI1EwzP74Y = My7Dwqvs6bfGNSIgX.findall('source src="(.*?)" title="(.*?)"',wN6n7OZBoDkTvCi8LdbJjYV,My7Dwqvs6bfGNSIgX.DOTALL)
			if TFZgy6WoC9HQjMnDimI1EwzP74Y:
				for BoEFz2WhUyvTgDeiZ,LLnUyuiC2wRM0 in TFZgy6WoC9HQjMnDimI1EwzP74Y:
					QQ2cE1FjUyxPonbDhaTkV6B3i.append(BoEFz2WhUyvTgDeiZ+'?named=ed.egybest.do__watch__mp4__'+LLnUyuiC2wRM0)
			else:
				LkVZrOE4XBSN2Qex5PyHqC = bJEs4IVAPdyUrhwCLv9k2YoOl8nt1.split('/')[2]
				QQ2cE1FjUyxPonbDhaTkV6B3i.append(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1+'?named='+LkVZrOE4XBSN2Qex5PyHqC+'__watch')
		elif bJEs4IVAPdyUrhwCLv9k2YoOl8nt1!='':
			LkVZrOE4XBSN2Qex5PyHqC = bJEs4IVAPdyUrhwCLv9k2YoOl8nt1.split('/')[2]
			QQ2cE1FjUyxPonbDhaTkV6B3i.append(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1+'?named='+LkVZrOE4XBSN2Qex5PyHqC+'__watch')
	KaFWhBj2rqiC8b3glJD = My7Dwqvs6bfGNSIgX.findall('<table class="dls_table(.*?)</table>',VnU6DwrpfkSaTsv,My7Dwqvs6bfGNSIgX.DOTALL)
	if KaFWhBj2rqiC8b3glJD:
		KaFWhBj2rqiC8b3glJD = KaFWhBj2rqiC8b3glJD[0]
		gkPA0fYRNjZi6nwe7 = My7Dwqvs6bfGNSIgX.findall('<td>.*?<td>(.*?)<.*?href="(.*?)"',KaFWhBj2rqiC8b3glJD,My7Dwqvs6bfGNSIgX.DOTALL)
		if gkPA0fYRNjZi6nwe7:
			for LLnUyuiC2wRM0,BoEFz2WhUyvTgDeiZ in gkPA0fYRNjZi6nwe7:
				if 'myegyvip' not in BoEFz2WhUyvTgDeiZ: continue
				if BoEFz2WhUyvTgDeiZ.count('/')>=2:
					LkVZrOE4XBSN2Qex5PyHqC = BoEFz2WhUyvTgDeiZ.split('/')[2]
					QQ2cE1FjUyxPonbDhaTkV6B3i.append(BoEFz2WhUyvTgDeiZ+'?named='+LkVZrOE4XBSN2Qex5PyHqC+'__download__mp4__'+LLnUyuiC2wRM0)
	lsSvZMNpBrH78OtKiEezXgbUY = []
	for BoEFz2WhUyvTgDeiZ in QQ2cE1FjUyxPonbDhaTkV6B3i:
		lsSvZMNpBrH78OtKiEezXgbUY.append(BoEFz2WhUyvTgDeiZ)
	import t1kDWXQVpC
	t1kDWXQVpC.rqVt2xDi7jzJHBcPMRs6h0L(lsSvZMNpBrH78OtKiEezXgbUY,baNWS6nfqTC5iX4Kl,'video',url)
	return
def HjZcUIVAXFCqy9TfBWKtgY2(search):
	search,LQf3AeozSrai,showDialogs = X54MLovbG8nAEkB9J(search)
	if search=='': search = ViKAIsLurq83RSENayxWb()
	if search=='': return
	ystIEd371fLkT50pcRUWi9olNDu = search.replace(' ','+')
	MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(f9Oum6c0FotxYn,EZxQp1WOldMTvFU,'','','','EGYBESTVIP-SEARCH-1st')
	Ujugy9ASbcRxaVeCKJ = My7Dwqvs6bfGNSIgX.findall('name="_token" value="(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if Ujugy9ASbcRxaVeCKJ:
		url = EZxQp1WOldMTvFU+'/search?_token='+Ujugy9ASbcRxaVeCKJ[0]+'&q='+ystIEd371fLkT50pcRUWi9olNDu
		sscM839DP1jWZ4zl6uIx0Kyn(url)
	return
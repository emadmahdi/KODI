# -*- coding: utf-8 -*-
from G6AHskJeqN import *
DaZhLqOIc24x6wv57YUlF3NgCzpGeX = 'FAVORITES'
def zfogEMcGC60(H3HDqY5N4e0fWSXMikZ8CR7suUmJdx,UpKk12xHzSv8qyFChrZ3B7c):
	if   H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==270: fM9jDUciIqk2SutLy5Y4ngE3aWlOe = X8BnqH7u1wJkIvPaQ5zlp6cfoVMW2N(UpKk12xHzSv8qyFChrZ3B7c)
	else: fM9jDUciIqk2SutLy5Y4ngE3aWlOe = False
	return fM9jDUciIqk2SutLy5Y4ngE3aWlOe
def xxny2PLvbheWg(HMdmFA6wzOC0GEoa9rlt27biPn):
	if not HMdmFA6wzOC0GEoa9rlt27biPn: return
	if '_' in HMdmFA6wzOC0GEoa9rlt27biPn: UpKk12xHzSv8qyFChrZ3B7c,PPAumXrzV4aTNnSWFyZdp1iD = HMdmFA6wzOC0GEoa9rlt27biPn.split('_',1)
	else: UpKk12xHzSv8qyFChrZ3B7c,PPAumXrzV4aTNnSWFyZdp1iD = HMdmFA6wzOC0GEoa9rlt27biPn,''
	if   PPAumXrzV4aTNnSWFyZdp1iD=='UP1'	: o4IYRJXnZF1(UpKk12xHzSv8qyFChrZ3B7c,True,1)
	elif PPAumXrzV4aTNnSWFyZdp1iD=='DOWN1'	: o4IYRJXnZF1(UpKk12xHzSv8qyFChrZ3B7c,False,1)
	elif PPAumXrzV4aTNnSWFyZdp1iD=='UP4'	: o4IYRJXnZF1(UpKk12xHzSv8qyFChrZ3B7c,True,4)
	elif PPAumXrzV4aTNnSWFyZdp1iD=='DOWN4'	: o4IYRJXnZF1(UpKk12xHzSv8qyFChrZ3B7c,False,4)
	elif PPAumXrzV4aTNnSWFyZdp1iD=='ADD1'	: cwPARiE5egXMv26(UpKk12xHzSv8qyFChrZ3B7c)
	elif PPAumXrzV4aTNnSWFyZdp1iD=='REMOVE1': gSEKLHkOnpijDMlJqsF(UpKk12xHzSv8qyFChrZ3B7c)
	elif PPAumXrzV4aTNnSWFyZdp1iD=='DELETELIST': fHcsiCE0GeMV3vwjRK(UpKk12xHzSv8qyFChrZ3B7c)
	return
def X8BnqH7u1wJkIvPaQ5zlp6cfoVMW2N(UpKk12xHzSv8qyFChrZ3B7c):
	QEAlki3W6jJfg0Xdh1VoSRyvuxbC = U74i5rCBLYbymIQFOV()
	if UpKk12xHzSv8qyFChrZ3B7c in list(QEAlki3W6jJfg0Xdh1VoSRyvuxbC.keys()):
		try:
			jPnutFiW4w5c7pDav = QEAlki3W6jJfg0Xdh1VoSRyvuxbC[UpKk12xHzSv8qyFChrZ3B7c]
			for dM2SkzwnVKc3FUPDl9BE,bSxczpUtHewVDKa3EL4lm,SCakygtHx0AUXbO3emswB9F8,H3HDqY5N4e0fWSXMikZ8CR7suUmJdx,MofmxtNlUaORA0K1uJv6S8g,EoulZdO2FQmDYrqNbA1kagMp,Gfsr6KpyVRovQmB8xcXUJ,HMdmFA6wzOC0GEoa9rlt27biPn,InkN7SpoMudDGJ6K in jPnutFiW4w5c7pDav:
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX(dM2SkzwnVKc3FUPDl9BE,bSxczpUtHewVDKa3EL4lm,SCakygtHx0AUXbO3emswB9F8,H3HDqY5N4e0fWSXMikZ8CR7suUmJdx,MofmxtNlUaORA0K1uJv6S8g,EoulZdO2FQmDYrqNbA1kagMp,Gfsr6KpyVRovQmB8xcXUJ,HMdmFA6wzOC0GEoa9rlt27biPn,InkN7SpoMudDGJ6K)
		except:
			QEAlki3W6jJfg0Xdh1VoSRyvuxbC = anzmoyTgUd(Z7A1STpeQGVJ)
			jPnutFiW4w5c7pDav = QEAlki3W6jJfg0Xdh1VoSRyvuxbC[UpKk12xHzSv8qyFChrZ3B7c]
			for dM2SkzwnVKc3FUPDl9BE,bSxczpUtHewVDKa3EL4lm,SCakygtHx0AUXbO3emswB9F8,H3HDqY5N4e0fWSXMikZ8CR7suUmJdx,MofmxtNlUaORA0K1uJv6S8g,EoulZdO2FQmDYrqNbA1kagMp,Gfsr6KpyVRovQmB8xcXUJ,HMdmFA6wzOC0GEoa9rlt27biPn,InkN7SpoMudDGJ6K in jPnutFiW4w5c7pDav:
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX(dM2SkzwnVKc3FUPDl9BE,bSxczpUtHewVDKa3EL4lm,SCakygtHx0AUXbO3emswB9F8,H3HDqY5N4e0fWSXMikZ8CR7suUmJdx,MofmxtNlUaORA0K1uJv6S8g,EoulZdO2FQmDYrqNbA1kagMp,Gfsr6KpyVRovQmB8xcXUJ,HMdmFA6wzOC0GEoa9rlt27biPn,InkN7SpoMudDGJ6K)
	return
def cwPARiE5egXMv26(UpKk12xHzSv8qyFChrZ3B7c):
	dM2SkzwnVKc3FUPDl9BE,bSxczpUtHewVDKa3EL4lm,SCakygtHx0AUXbO3emswB9F8,H3HDqY5N4e0fWSXMikZ8CR7suUmJdx,MofmxtNlUaORA0K1uJv6S8g,EoulZdO2FQmDYrqNbA1kagMp,Gfsr6KpyVRovQmB8xcXUJ,HMdmFA6wzOC0GEoa9rlt27biPn,InkN7SpoMudDGJ6K = cIa9Spry0oqE(SzGukeylg5Nsr9M20WIan)
	SFVu351C6NLHgM7 = dM2SkzwnVKc3FUPDl9BE,bSxczpUtHewVDKa3EL4lm,SCakygtHx0AUXbO3emswB9F8,H3HDqY5N4e0fWSXMikZ8CR7suUmJdx,MofmxtNlUaORA0K1uJv6S8g,EoulZdO2FQmDYrqNbA1kagMp,Gfsr6KpyVRovQmB8xcXUJ,'',InkN7SpoMudDGJ6K
	QEAlki3W6jJfg0Xdh1VoSRyvuxbC = U74i5rCBLYbymIQFOV()
	Q9dgmVbYPa = {}
	for WZ2wJMGIzqPjFdObguRNKaBU in list(QEAlki3W6jJfg0Xdh1VoSRyvuxbC.keys()):
		if WZ2wJMGIzqPjFdObguRNKaBU!=UpKk12xHzSv8qyFChrZ3B7c: Q9dgmVbYPa[WZ2wJMGIzqPjFdObguRNKaBU] = QEAlki3W6jJfg0Xdh1VoSRyvuxbC[WZ2wJMGIzqPjFdObguRNKaBU]
		else:
			if bSxczpUtHewVDKa3EL4lm and bSxczpUtHewVDKa3EL4lm!='..':
				FMwtHh9r5XOlWsvSZDb = QEAlki3W6jJfg0Xdh1VoSRyvuxbC[WZ2wJMGIzqPjFdObguRNKaBU]
				if SFVu351C6NLHgM7 in FMwtHh9r5XOlWsvSZDb:
					F5MvchsruD = FMwtHh9r5XOlWsvSZDb.index(SFVu351C6NLHgM7)
					del FMwtHh9r5XOlWsvSZDb[F5MvchsruD]
				AX7BK8fde5ho4mqgDQ1ic0ZJCFw = FMwtHh9r5XOlWsvSZDb+[SFVu351C6NLHgM7]
				Q9dgmVbYPa[WZ2wJMGIzqPjFdObguRNKaBU] = AX7BK8fde5ho4mqgDQ1ic0ZJCFw
			else: Q9dgmVbYPa[WZ2wJMGIzqPjFdObguRNKaBU] = QEAlki3W6jJfg0Xdh1VoSRyvuxbC[WZ2wJMGIzqPjFdObguRNKaBU]
	if UpKk12xHzSv8qyFChrZ3B7c not in list(Q9dgmVbYPa.keys()): Q9dgmVbYPa[UpKk12xHzSv8qyFChrZ3B7c] = [SFVu351C6NLHgM7]
	DDWYJ9udC1 = str(Q9dgmVbYPa)
	if BLz7m2RkNrxXQwy1cGAp: DDWYJ9udC1 = DDWYJ9udC1.encode('utf8')
	open(Z7A1STpeQGVJ,'wb').write(DDWYJ9udC1)
	return
def gSEKLHkOnpijDMlJqsF(UpKk12xHzSv8qyFChrZ3B7c):
	dM2SkzwnVKc3FUPDl9BE,bSxczpUtHewVDKa3EL4lm,SCakygtHx0AUXbO3emswB9F8,H3HDqY5N4e0fWSXMikZ8CR7suUmJdx,MofmxtNlUaORA0K1uJv6S8g,EoulZdO2FQmDYrqNbA1kagMp,Gfsr6KpyVRovQmB8xcXUJ,HMdmFA6wzOC0GEoa9rlt27biPn,InkN7SpoMudDGJ6K = cIa9Spry0oqE(SzGukeylg5Nsr9M20WIan)
	SFVu351C6NLHgM7 = dM2SkzwnVKc3FUPDl9BE,bSxczpUtHewVDKa3EL4lm,SCakygtHx0AUXbO3emswB9F8,H3HDqY5N4e0fWSXMikZ8CR7suUmJdx,MofmxtNlUaORA0K1uJv6S8g,EoulZdO2FQmDYrqNbA1kagMp,Gfsr6KpyVRovQmB8xcXUJ,'',InkN7SpoMudDGJ6K
	QEAlki3W6jJfg0Xdh1VoSRyvuxbC = U74i5rCBLYbymIQFOV()
	if UpKk12xHzSv8qyFChrZ3B7c in list(QEAlki3W6jJfg0Xdh1VoSRyvuxbC.keys()) and SFVu351C6NLHgM7 in QEAlki3W6jJfg0Xdh1VoSRyvuxbC[UpKk12xHzSv8qyFChrZ3B7c]:
		QEAlki3W6jJfg0Xdh1VoSRyvuxbC[UpKk12xHzSv8qyFChrZ3B7c].remove(SFVu351C6NLHgM7)
		if len(QEAlki3W6jJfg0Xdh1VoSRyvuxbC[UpKk12xHzSv8qyFChrZ3B7c])==0: del QEAlki3W6jJfg0Xdh1VoSRyvuxbC[UpKk12xHzSv8qyFChrZ3B7c]
		DDWYJ9udC1 = str(QEAlki3W6jJfg0Xdh1VoSRyvuxbC)
		if BLz7m2RkNrxXQwy1cGAp: DDWYJ9udC1 = DDWYJ9udC1.encode('utf8')
		open(Z7A1STpeQGVJ,'wb').write(DDWYJ9udC1)
	return
def o4IYRJXnZF1(UpKk12xHzSv8qyFChrZ3B7c,trc7bEU5xyRMgpHBK8iZN0haFv,mba2KBSp7EZTL9JshHVAMn41):
	dM2SkzwnVKc3FUPDl9BE,bSxczpUtHewVDKa3EL4lm,SCakygtHx0AUXbO3emswB9F8,H3HDqY5N4e0fWSXMikZ8CR7suUmJdx,MofmxtNlUaORA0K1uJv6S8g,EoulZdO2FQmDYrqNbA1kagMp,Gfsr6KpyVRovQmB8xcXUJ,HMdmFA6wzOC0GEoa9rlt27biPn,InkN7SpoMudDGJ6K = cIa9Spry0oqE(SzGukeylg5Nsr9M20WIan)
	SFVu351C6NLHgM7 = dM2SkzwnVKc3FUPDl9BE,bSxczpUtHewVDKa3EL4lm,SCakygtHx0AUXbO3emswB9F8,H3HDqY5N4e0fWSXMikZ8CR7suUmJdx,MofmxtNlUaORA0K1uJv6S8g,EoulZdO2FQmDYrqNbA1kagMp,Gfsr6KpyVRovQmB8xcXUJ,'',InkN7SpoMudDGJ6K
	QEAlki3W6jJfg0Xdh1VoSRyvuxbC = U74i5rCBLYbymIQFOV()
	if UpKk12xHzSv8qyFChrZ3B7c in list(QEAlki3W6jJfg0Xdh1VoSRyvuxbC.keys()):
		FMwtHh9r5XOlWsvSZDb = QEAlki3W6jJfg0Xdh1VoSRyvuxbC[UpKk12xHzSv8qyFChrZ3B7c]
		if SFVu351C6NLHgM7 not in FMwtHh9r5XOlWsvSZDb: return
		DlVeTymZPB68wv = len(FMwtHh9r5XOlWsvSZDb)
		for NnacyGSwPsCe18JuHpz0XQRt in range(0,mba2KBSp7EZTL9JshHVAMn41):
			i7aIBzdWlT0mCSZyHe5G = FMwtHh9r5XOlWsvSZDb.index(SFVu351C6NLHgM7)
			if trc7bEU5xyRMgpHBK8iZN0haFv: SSj5FGr3v9mYKtJEOWx = i7aIBzdWlT0mCSZyHe5G-1
			else: SSj5FGr3v9mYKtJEOWx = i7aIBzdWlT0mCSZyHe5G+1
			if SSj5FGr3v9mYKtJEOWx>=DlVeTymZPB68wv: SSj5FGr3v9mYKtJEOWx = SSj5FGr3v9mYKtJEOWx-DlVeTymZPB68wv
			if SSj5FGr3v9mYKtJEOWx<0: SSj5FGr3v9mYKtJEOWx = SSj5FGr3v9mYKtJEOWx+DlVeTymZPB68wv
			FMwtHh9r5XOlWsvSZDb.insert(SSj5FGr3v9mYKtJEOWx, FMwtHh9r5XOlWsvSZDb.pop(i7aIBzdWlT0mCSZyHe5G))
		QEAlki3W6jJfg0Xdh1VoSRyvuxbC[UpKk12xHzSv8qyFChrZ3B7c] = FMwtHh9r5XOlWsvSZDb
		DDWYJ9udC1 = str(QEAlki3W6jJfg0Xdh1VoSRyvuxbC)
		if BLz7m2RkNrxXQwy1cGAp: DDWYJ9udC1 = DDWYJ9udC1.encode('utf8')
		open(Z7A1STpeQGVJ,'wb').write(DDWYJ9udC1)
	return
def fHcsiCE0GeMV3vwjRK(UpKk12xHzSv8qyFChrZ3B7c):
	UHx5YQ3FogO87NB0mrXRthi = mmwySO1P4jnKz5('center','','','رسالة من المبرمج','هل تريد فعلا مسح جميع محتويات قائمة المفضلة '+UpKk12xHzSv8qyFChrZ3B7c+' ؟!')
	if UHx5YQ3FogO87NB0mrXRthi!=1: return
	QEAlki3W6jJfg0Xdh1VoSRyvuxbC = U74i5rCBLYbymIQFOV()
	if UpKk12xHzSv8qyFChrZ3B7c in list(QEAlki3W6jJfg0Xdh1VoSRyvuxbC.keys()):
		del QEAlki3W6jJfg0Xdh1VoSRyvuxbC[UpKk12xHzSv8qyFChrZ3B7c]
		DDWYJ9udC1 = str(QEAlki3W6jJfg0Xdh1VoSRyvuxbC)
		if BLz7m2RkNrxXQwy1cGAp: DDWYJ9udC1 = DDWYJ9udC1.encode('utf8')
		open(Z7A1STpeQGVJ,'wb').write(DDWYJ9udC1)
		ZIOHgA3z0TBR('','','رسالة من المبرمج','تم مسح جميع محتويات قائمة المفضلة '+UpKk12xHzSv8qyFChrZ3B7c)
	return
def U74i5rCBLYbymIQFOV():
	QEAlki3W6jJfg0Xdh1VoSRyvuxbC = {}
	if XXRtDhYvWb35qnLBxIri7ScNUks0.path.exists(Z7A1STpeQGVJ):
		rrSyzoYXGZmc = open(Z7A1STpeQGVJ,'rb').read()
		if BLz7m2RkNrxXQwy1cGAp: rrSyzoYXGZmc = rrSyzoYXGZmc.decode('utf8')
		QEAlki3W6jJfg0Xdh1VoSRyvuxbC = dWsa2A0O4o5BYiqGXhyKEbM('dict',rrSyzoYXGZmc)
	return QEAlki3W6jJfg0Xdh1VoSRyvuxbC
def nvlhoJtjfRTSMANVO1HDCBcgPxI(QEAlki3W6jJfg0Xdh1VoSRyvuxbC,SFVu351C6NLHgM7,kDZRwOYfIJqa8Tnh7):
	dM2SkzwnVKc3FUPDl9BE,bSxczpUtHewVDKa3EL4lm,SCakygtHx0AUXbO3emswB9F8,H3HDqY5N4e0fWSXMikZ8CR7suUmJdx,MofmxtNlUaORA0K1uJv6S8g,EoulZdO2FQmDYrqNbA1kagMp,Gfsr6KpyVRovQmB8xcXUJ,HMdmFA6wzOC0GEoa9rlt27biPn,InkN7SpoMudDGJ6K = SFVu351C6NLHgM7
	if not H3HDqY5N4e0fWSXMikZ8CR7suUmJdx: dM2SkzwnVKc3FUPDl9BE,H3HDqY5N4e0fWSXMikZ8CR7suUmJdx = 'folder','260'
	xsDFR5PVWXhpwMnyI3bgTfa1U,UpKk12xHzSv8qyFChrZ3B7c = [],''
	if 'context=' in SzGukeylg5Nsr9M20WIan:
		FYC1nIuVchKx8ka2w9ei0BtWm = My7Dwqvs6bfGNSIgX.findall('context=(\d+)',SzGukeylg5Nsr9M20WIan,My7Dwqvs6bfGNSIgX.DOTALL)
		if FYC1nIuVchKx8ka2w9ei0BtWm: UpKk12xHzSv8qyFChrZ3B7c = str(FYC1nIuVchKx8ka2w9ei0BtWm[0])
	if H3HDqY5N4e0fWSXMikZ8CR7suUmJdx=='270':
		UpKk12xHzSv8qyFChrZ3B7c = HMdmFA6wzOC0GEoa9rlt27biPn
		if UpKk12xHzSv8qyFChrZ3B7c in list(QEAlki3W6jJfg0Xdh1VoSRyvuxbC.keys()):
			xsDFR5PVWXhpwMnyI3bgTfa1U.append(('مسح قائمة مفضلة '+UpKk12xHzSv8qyFChrZ3B7c,'RunPlugin('+kDZRwOYfIJqa8Tnh7+'&context='+UpKk12xHzSv8qyFChrZ3B7c+'_DELETELIST'+')'))
	else:
		if UpKk12xHzSv8qyFChrZ3B7c in list(QEAlki3W6jJfg0Xdh1VoSRyvuxbC.keys()):
			count = len(QEAlki3W6jJfg0Xdh1VoSRyvuxbC[UpKk12xHzSv8qyFChrZ3B7c])
			if count>1: xsDFR5PVWXhpwMnyI3bgTfa1U.append(('تحريك 1 للأعلى','RunPlugin('+kDZRwOYfIJqa8Tnh7+'&context='+UpKk12xHzSv8qyFChrZ3B7c+'_UP1)'))
			if count>4: xsDFR5PVWXhpwMnyI3bgTfa1U.append(('تحريك 4 للأعلى','RunPlugin('+kDZRwOYfIJqa8Tnh7+'&context='+UpKk12xHzSv8qyFChrZ3B7c+'_UP4)'))
			if count>1: xsDFR5PVWXhpwMnyI3bgTfa1U.append(('تحريك 1 للأسفل','RunPlugin('+kDZRwOYfIJqa8Tnh7+'&context='+UpKk12xHzSv8qyFChrZ3B7c+'_DOWN1)'))
			if count>4: xsDFR5PVWXhpwMnyI3bgTfa1U.append(('تحريك 4 للأسفل','RunPlugin('+kDZRwOYfIJqa8Tnh7+'&context='+UpKk12xHzSv8qyFChrZ3B7c+'_DOWN4)'))
		for UpKk12xHzSv8qyFChrZ3B7c in ['1','2','3','4','5']:
			if UpKk12xHzSv8qyFChrZ3B7c in list(QEAlki3W6jJfg0Xdh1VoSRyvuxbC.keys()) and SFVu351C6NLHgM7 in QEAlki3W6jJfg0Xdh1VoSRyvuxbC[UpKk12xHzSv8qyFChrZ3B7c]:
				xsDFR5PVWXhpwMnyI3bgTfa1U.append(('مسح من مفضلة '+UpKk12xHzSv8qyFChrZ3B7c,'RunPlugin('+kDZRwOYfIJqa8Tnh7+'&context='+UpKk12xHzSv8qyFChrZ3B7c+'_REMOVE1)'))
			else: xsDFR5PVWXhpwMnyI3bgTfa1U.append(('إضافة لمفضلة '+UpKk12xHzSv8qyFChrZ3B7c,'RunPlugin('+kDZRwOYfIJqa8Tnh7+'&context='+UpKk12xHzSv8qyFChrZ3B7c+'_ADD1)'))
	o796DAnOFQh2iP4aZEJCluBW3 = []
	for nbV8oXLAjBs7dkCPZc6mzUgE,CuoKlgPysUx4ArOId0jb7cNQqDTL in xsDFR5PVWXhpwMnyI3bgTfa1U:
		nbV8oXLAjBs7dkCPZc6mzUgE = '[COLOR FFFFFF00]'+nbV8oXLAjBs7dkCPZc6mzUgE+'[/COLOR]'
		o796DAnOFQh2iP4aZEJCluBW3.append((nbV8oXLAjBs7dkCPZc6mzUgE,CuoKlgPysUx4ArOId0jb7cNQqDTL,))
	return o796DAnOFQh2iP4aZEJCluBW3
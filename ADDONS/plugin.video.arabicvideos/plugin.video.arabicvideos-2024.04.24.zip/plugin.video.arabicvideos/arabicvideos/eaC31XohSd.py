# -*- coding: utf-8 -*-
from G6AHskJeqN import *
baNWS6nfqTC5iX4Kl = 'KARBALATV'
teUPLFC3B8bArakwHVGsdhoIWDM49f = '_KRB_'
EZxQp1WOldMTvFU = AK5RqLhji4W1wt9VdrCD3PGeQM[baNWS6nfqTC5iX4Kl][0]
headers = {'User-Agent':''}
def VbgEajY4Bt2COpGDcPqI(mode,url,text):
	if   mode==320: ft3e2JBKQVXWlFPjaMhkEqGxvDg = eN02L7Tf5bQ()
	elif mode==321: ft3e2JBKQVXWlFPjaMhkEqGxvDg = sscM839DP1jWZ4zl6uIx0Kyn(url)
	elif mode==322: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HDxCnPKFhITpZmOsA4a0UL6(url)
	elif mode==329: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HjZcUIVAXFCqy9TfBWKtgY2(text)
	else: ft3e2JBKQVXWlFPjaMhkEqGxvDg = False
	return ft3e2JBKQVXWlFPjaMhkEqGxvDg
def eN02L7Tf5bQ():
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'بحث في الموقع','',329,'','','_REMEMBERRESULTS_')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(IIiPCruL6dT8s1lqj47SzpVHnYNm,'GET',EZxQp1WOldMTvFU+'/video.php','',headers,'','','KARBALATV-MENU-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('class="icono-plus"(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	vsptNMP2ZQC = XBuP6Op7y4K[0]
	items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)">(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	for BoEFz2WhUyvTgDeiZ,title in items:
		if title=='المكتبة المرئية': continue
		BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU+BoEFz2WhUyvTgDeiZ
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,321)
	return MK6ZT2zjC1SbmveNFqor
def sscM839DP1jWZ4zl6uIx0Kyn(url):
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'',headers,'','','KARBALATV-TITLES-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('class="container"(.*?)class="footer',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	vsptNMP2ZQC = XBuP6Op7y4K[0]
	items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?url\((.*?)\).*?pd5">(.*?)<.*?<h3.*?">(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	if not items: items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?src="(.*?)".*?alt="(.*?)".*?<p.*?>(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	for BoEFz2WhUyvTgDeiZ,IcWzVO137wFvemn2QTq8yKs9,count,title in items:
		count = count.replace('عدد ','').replace(' ','')
		BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ.replace('/','')
		IcWzVO137wFvemn2QTq8yKs9 = IcWzVO137wFvemn2QTq8yKs9.replace("'",'')
		if '.php' not in BoEFz2WhUyvTgDeiZ: BoEFz2WhUyvTgDeiZ = 'video.php'+BoEFz2WhUyvTgDeiZ
		BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU+'/'+BoEFz2WhUyvTgDeiZ
		IcWzVO137wFvemn2QTq8yKs9 = EZxQp1WOldMTvFU+IcWzVO137wFvemn2QTq8yKs9
		title = title.strip(' ')
		title = title+' ('+count+')'
		if 'video.php' in BoEFz2WhUyvTgDeiZ: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,321,IcWzVO137wFvemn2QTq8yKs9)
		elif 'watch.php' in BoEFz2WhUyvTgDeiZ: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,322,IcWzVO137wFvemn2QTq8yKs9)
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('class="pagination(.*?)class="footer',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)">(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title in items:
			BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU+'/video.php'+BoEFz2WhUyvTgDeiZ
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'صفحة '+title,BoEFz2WhUyvTgDeiZ,321)
	return
def HDxCnPKFhITpZmOsA4a0UL6(url):
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(f9Oum6c0FotxYn,'GET',url,'',headers,'','','KARBALATV-PLAY-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	BoEFz2WhUyvTgDeiZ = My7Dwqvs6bfGNSIgX.findall('<video.*?src="(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU+BoEFz2WhUyvTgDeiZ[0]
	B0xcwKkMQ16mpSFRaVHPTzuhUZngLq(BoEFz2WhUyvTgDeiZ,baNWS6nfqTC5iX4Kl,'video')
	return
def HjZcUIVAXFCqy9TfBWKtgY2(search):
	search,LQf3AeozSrai,showDialogs = X54MLovbG8nAEkB9J(search)
	if search=='': search = ViKAIsLurq83RSENayxWb()
	if search=='': return
	search = search.replace(' ','+')
	url = EZxQp1WOldMTvFU+'/search.php?q='+search
	sscM839DP1jWZ4zl6uIx0Kyn(url)
	return
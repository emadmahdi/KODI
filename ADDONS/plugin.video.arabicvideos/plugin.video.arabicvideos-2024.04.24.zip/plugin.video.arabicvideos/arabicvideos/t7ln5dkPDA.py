# -*- coding: utf-8 -*-
from G6AHskJeqN import *
baNWS6nfqTC5iX4Kl = 'BRSTEJ'
teUPLFC3B8bArakwHVGsdhoIWDM49f = '_BRS_'
EZxQp1WOldMTvFU = AK5RqLhji4W1wt9VdrCD3PGeQM[baNWS6nfqTC5iX4Kl][0]
eh2tDvRFWpLQI = ['الصفحة الرئيسية','Sign in','الاقسام','عرض المزيد']
def VbgEajY4Bt2COpGDcPqI(mode,url,text):
	if   mode==650: ft3e2JBKQVXWlFPjaMhkEqGxvDg = eN02L7Tf5bQ()
	elif mode==651: ft3e2JBKQVXWlFPjaMhkEqGxvDg = sscM839DP1jWZ4zl6uIx0Kyn(url,text)
	elif mode==652: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HDxCnPKFhITpZmOsA4a0UL6(url)
	elif mode==653: ft3e2JBKQVXWlFPjaMhkEqGxvDg = CbkBOWecfqN8Jajp1Dd(url,text)
	elif mode==654: ft3e2JBKQVXWlFPjaMhkEqGxvDg = M25iOAH9NfalvyPEUuToG8qn(url)
	elif mode==659: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HjZcUIVAXFCqy9TfBWKtgY2(text)
	else: ft3e2JBKQVXWlFPjaMhkEqGxvDg = False
	return ft3e2JBKQVXWlFPjaMhkEqGxvDg
def eN02L7Tf5bQ():
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',EZxQp1WOldMTvFU,'','','','','BRSTEJ-MENU-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'بحث في الموقع','',659,'','','_REMEMBERRESULTS_')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'جديد الحلقات',EZxQp1WOldMTvFU,651,'','','new_episodes')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'مسلسلات مميزة',EZxQp1WOldMTvFU,651,'','','featured_series')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"navslide-divider"(.*?)"navslide-divider"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	vsptNMP2ZQC = XBuP6Op7y4K[0]
	items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?>(.*?)</',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	for BoEFz2WhUyvTgDeiZ,title in items:
		if title in eh2tDvRFWpLQI: continue
		title = title.replace('<b>','').strip(' ')
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,654)
	return
def M25iOAH9NfalvyPEUuToG8qn(url):
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'','','','','BRSTEJ-SUBMENU-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	KRI8WExzA4p = My7Dwqvs6bfGNSIgX.findall('"caret"(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if KRI8WExzA4p:
		vsptNMP2ZQC = KRI8WExzA4p[0]
		vsptNMP2ZQC = vsptNMP2ZQC.replace('"presentation"','</ul>')
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		if not XBuP6Op7y4K: XBuP6Op7y4K = [('',vsptNMP2ZQC)]
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] فرز أو فلتر أو ترتيب [/COLOR]','',9999)
		for bN5qWnCM903cj4zHxEasi1pBY7ZdrR,vsptNMP2ZQC in XBuP6Op7y4K:
			items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?>(.*?)</a>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
			if bN5qWnCM903cj4zHxEasi1pBY7ZdrR: bN5qWnCM903cj4zHxEasi1pBY7ZdrR = bN5qWnCM903cj4zHxEasi1pBY7ZdrR+': '
			for BoEFz2WhUyvTgDeiZ,title in items:
				title = bN5qWnCM903cj4zHxEasi1pBY7ZdrR+title
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,651)
	kdYXhMN8Hpbt = My7Dwqvs6bfGNSIgX.findall('"pm-category-subcats"(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if kdYXhMN8Hpbt:
		vsptNMP2ZQC = kdYXhMN8Hpbt[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)">(.*?)</a>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		if len(items)<30:
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
			for BoEFz2WhUyvTgDeiZ,title in items:
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,651)
	if not KRI8WExzA4p and not kdYXhMN8Hpbt: sscM839DP1jWZ4zl6uIx0Kyn(url)
	return
def sscM839DP1jWZ4zl6uIx0Kyn(url,h5QaxwPF7SOu6fMBTGXRU2yn=''):
	if h5QaxwPF7SOu6fMBTGXRU2yn=='ajax-search':
		url,search = url.split('?',1)
		data = 'queryString='+search
		headers = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'POST',url,data,headers,'','','BRSTEJ-TITLES-1st')
	else:
		xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'','','','','BRSTEJ-TITLES-2nd')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	vsptNMP2ZQC,items = '',[]
	xxE5BSyQkNsj = ooq2D9xF8ZLpPBs(url,'url')
	if h5QaxwPF7SOu6fMBTGXRU2yn=='ajax-search':
		vsptNMP2ZQC = MK6ZT2zjC1SbmveNFqor
		zE1FBZLDvygwGdkef74lnRJVXCUqKH = My7Dwqvs6bfGNSIgX.findall('href="(.*?)">(.*?)</a>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title in zE1FBZLDvygwGdkef74lnRJVXCUqKH: items.append(('',BoEFz2WhUyvTgDeiZ,title))
	elif h5QaxwPF7SOu6fMBTGXRU2yn=='featured':
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"pm-video-watch-featured"(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if XBuP6Op7y4K: vsptNMP2ZQC = XBuP6Op7y4K[0]
	elif h5QaxwPF7SOu6fMBTGXRU2yn=='new_episodes':
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"row pm-ul-browse-videos(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if XBuP6Op7y4K: vsptNMP2ZQC = XBuP6Op7y4K[0]
	elif h5QaxwPF7SOu6fMBTGXRU2yn=='new_movies':
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"row pm-ul-browse-videos(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if len(XBuP6Op7y4K)>1: vsptNMP2ZQC = XBuP6Op7y4K[1]
	elif h5QaxwPF7SOu6fMBTGXRU2yn=='featured_series':
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"ba mgb table full"(.*?)"clearfix"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if XBuP6Op7y4K: vsptNMP2ZQC = XBuP6Op7y4K[0]
		zE1FBZLDvygwGdkef74lnRJVXCUqKH = My7Dwqvs6bfGNSIgX.findall('href="(.*?)" title="(.*?)"',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title in zE1FBZLDvygwGdkef74lnRJVXCUqKH: items.append(('',BoEFz2WhUyvTgDeiZ,title))
	else:
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('(data-echo=".*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if XBuP6Op7y4K: vsptNMP2ZQC = XBuP6Op7y4K[0]
	if vsptNMP2ZQC and not items: items = My7Dwqvs6bfGNSIgX.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	if not items: return
	y7y3d5Fbhv42ONmtwLZ0SerYoQq = []
	tkBQK76YMeUlRI1TomgECfA = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for IcWzVO137wFvemn2QTq8yKs9,BoEFz2WhUyvTgDeiZ,title in items:
		title = title.strip(' ')
		ffhN7jAqe3Q4cR0Ukptzl = My7Dwqvs6bfGNSIgX.findall('(.*?) (الحلقة|حلقة).\d+',title,My7Dwqvs6bfGNSIgX.DOTALL)
		if any(WoFrX46wzbCNp18 in title for WoFrX46wzbCNp18 in tkBQK76YMeUlRI1TomgECfA):
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,652,IcWzVO137wFvemn2QTq8yKs9)
		elif h5QaxwPF7SOu6fMBTGXRU2yn=='new_episodes':
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,652,IcWzVO137wFvemn2QTq8yKs9)
		elif ffhN7jAqe3Q4cR0Ukptzl:
			title = '_MOD_' + ffhN7jAqe3Q4cR0Ukptzl[0][0]
			if title not in y7y3d5Fbhv42ONmtwLZ0SerYoQq:
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,653,IcWzVO137wFvemn2QTq8yKs9)
				y7y3d5Fbhv42ONmtwLZ0SerYoQq.append(title)
		else: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,653,IcWzVO137wFvemn2QTq8yKs9)
	if 1:
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"pagination(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if XBuP6Op7y4K:
			vsptNMP2ZQC = XBuP6Op7y4K[0]
			items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?>(.*?)</a>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
			for BoEFz2WhUyvTgDeiZ,title in items:
				if BoEFz2WhUyvTgDeiZ=='#': continue
				BoEFz2WhUyvTgDeiZ = xxE5BSyQkNsj+'/'+BoEFz2WhUyvTgDeiZ.strip('/')
				title = PIfAumbGicwg5ye(title)
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'صفحة '+title,BoEFz2WhUyvTgDeiZ,651)
	return
def CbkBOWecfqN8Jajp1Dd(url,b0z14BOJQMs):
	xxE5BSyQkNsj = ooq2D9xF8ZLpPBs(url,'url')
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'','','','','BRSTEJ-EPISODES-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	KRI8WExzA4p = My7Dwqvs6bfGNSIgX.findall('"SeasonsBox"(.*?)"SeasonsEpisodesMain',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	QFrVYJkywEsXquMNz = My7Dwqvs6bfGNSIgX.findall('"series-header".*?src="(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if QFrVYJkywEsXquMNz: IcWzVO137wFvemn2QTq8yKs9 = QFrVYJkywEsXquMNz[0]
	else: IcWzVO137wFvemn2QTq8yKs9 = ''
	items = []
	uq1Ayb0IlosZdzU54jBTnRK9 = False
	if KRI8WExzA4p and not b0z14BOJQMs:
		vsptNMP2ZQC = KRI8WExzA4p[0]
		items = My7Dwqvs6bfGNSIgX.findall('''openCity\(event, '(.*?)'\).*?>(.*?)</button>''',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		if not items: items = My7Dwqvs6bfGNSIgX.findall('data-serie="(.*?)".*?>(.*?)</',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for b0z14BOJQMs,title in items:
			b0z14BOJQMs = b0z14BOJQMs.strip('#')
			if len(items)>1: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,url,653,IcWzVO137wFvemn2QTq8yKs9,'',b0z14BOJQMs)
			else: uq1Ayb0IlosZdzU54jBTnRK9 = True
	else: uq1Ayb0IlosZdzU54jBTnRK9 = True
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"SeasonsEpisodesMain(.*?</div>).</div>.</div>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	vsptNMP2ZQC = XBuP6Op7y4K[0]
	kdYXhMN8Hpbt = My7Dwqvs6bfGNSIgX.findall('id="'+b0z14BOJQMs+'"(.*?)</ul>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	if not kdYXhMN8Hpbt: kdYXhMN8Hpbt = My7Dwqvs6bfGNSIgX.findall('data-serie="'+b0z14BOJQMs+'"(.*?)</div>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	if not kdYXhMN8Hpbt: kdYXhMN8Hpbt = My7Dwqvs6bfGNSIgX.findall('id="Season'+b0z14BOJQMs+'"(.*?)</ul>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	if kdYXhMN8Hpbt and uq1Ayb0IlosZdzU54jBTnRK9:
		vsptNMP2ZQC = kdYXhMN8Hpbt[0]
		zE1FBZLDvygwGdkef74lnRJVXCUqKH = My7Dwqvs6bfGNSIgX.findall("href='(.*?)'><li><em>(.*?)</span>",vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		if not zE1FBZLDvygwGdkef74lnRJVXCUqKH: zE1FBZLDvygwGdkef74lnRJVXCUqKH = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?<em>(.*?)</span>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		items = []
		for BoEFz2WhUyvTgDeiZ,title in zE1FBZLDvygwGdkef74lnRJVXCUqKH: items.append((BoEFz2WhUyvTgDeiZ,title,IcWzVO137wFvemn2QTq8yKs9))
		if not items: items = My7Dwqvs6bfGNSIgX.findall('"thumbnail".*?href="(.*?)" title="(.*?)".*?src="(.*?)"',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title,IcWzVO137wFvemn2QTq8yKs9 in items:
			BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ.strip('./')
			BoEFz2WhUyvTgDeiZ = xxE5BSyQkNsj+'/'+BoEFz2WhUyvTgDeiZ.strip('/')
			title = title.replace('</em><span>',' ')
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,652,IcWzVO137wFvemn2QTq8yKs9)
	return
def HDxCnPKFhITpZmOsA4a0UL6(url):
	QQ2cE1FjUyxPonbDhaTkV6B3i,YNuW90vpw8rBSTU,Qki8AbTHYjzM2Ls76Gdr3eqo1Wn = [],[],[]
	bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = url.replace('/watch.php','/play.php')
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,'','','','','BRSTEJ-PLAY-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('id="Playerholder"(.*?)</div>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		BoEFz2WhUyvTgDeiZ = My7Dwqvs6bfGNSIgX.findall('<iframe src="(.*?)"',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		if BoEFz2WhUyvTgDeiZ:
			BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ[0]
			YNuW90vpw8rBSTU.append('?named=__embed')
			QQ2cE1FjUyxPonbDhaTkV6B3i.append(BoEFz2WhUyvTgDeiZ)
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('id="player"(.*?)</div>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		NVHrZsqUp2 = My7Dwqvs6bfGNSIgX.findall('''data-embed-url=['"](.*?)['"].*?</span>(.*?)</button>''',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title in NVHrZsqUp2:
			title = title.strip(' ')
			if BoEFz2WhUyvTgDeiZ not in QQ2cE1FjUyxPonbDhaTkV6B3i:
				YNuW90vpw8rBSTU.append('?named='+title+'__watch')
				QQ2cE1FjUyxPonbDhaTkV6B3i.append(BoEFz2WhUyvTgDeiZ)
	nRxp0IUZQB9cgqy6f7A5Xa = zip(QQ2cE1FjUyxPonbDhaTkV6B3i,YNuW90vpw8rBSTU)
	for BoEFz2WhUyvTgDeiZ,name in nRxp0IUZQB9cgqy6f7A5Xa: Qki8AbTHYjzM2Ls76Gdr3eqo1Wn.append(BoEFz2WhUyvTgDeiZ+name)
	import t1kDWXQVpC
	t1kDWXQVpC.rqVt2xDi7jzJHBcPMRs6h0L(Qki8AbTHYjzM2Ls76Gdr3eqo1Wn,baNWS6nfqTC5iX4Kl,'video',url)
	return
def HjZcUIVAXFCqy9TfBWKtgY2(search):
	search,LQf3AeozSrai,showDialogs = X54MLovbG8nAEkB9J(search)
	if search=='': search = ViKAIsLurq83RSENayxWb()
	if search=='': return
	search = search.replace(' ','+')
	url = EZxQp1WOldMTvFU+'/search.php?keywords='+search
	sscM839DP1jWZ4zl6uIx0Kyn(url,'search')
	return
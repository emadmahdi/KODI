# -*- coding: utf-8 -*-
from G6AHskJeqN import *
baNWS6nfqTC5iX4Kl = 'SHAHID4U'
teUPLFC3B8bArakwHVGsdhoIWDM49f = '_SH4_'
EZxQp1WOldMTvFU = AK5RqLhji4W1wt9VdrCD3PGeQM[baNWS6nfqTC5iX4Kl][0]
eh2tDvRFWpLQI = ['عروض مصارعة','الكل','افلام','javascript','مصارعة حرة']
def VbgEajY4Bt2COpGDcPqI(mode,url,text):
	if   mode==110: ft3e2JBKQVXWlFPjaMhkEqGxvDg = eN02L7Tf5bQ()
	elif mode==111: ft3e2JBKQVXWlFPjaMhkEqGxvDg = sscM839DP1jWZ4zl6uIx0Kyn(url,text)
	elif mode==112: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HDxCnPKFhITpZmOsA4a0UL6(url)
	elif mode==113: ft3e2JBKQVXWlFPjaMhkEqGxvDg = o4oY13v5dWMcbilEDjKCnXNzHZ0(url,True)
	elif mode==114: ft3e2JBKQVXWlFPjaMhkEqGxvDg = LLJlTxDePyjoVKA(url,'FULL_FILTER___'+text)
	elif mode==115: ft3e2JBKQVXWlFPjaMhkEqGxvDg = LLJlTxDePyjoVKA(url,'DEFINED_FILTER___'+text)
	elif mode==116: ft3e2JBKQVXWlFPjaMhkEqGxvDg = o4oY13v5dWMcbilEDjKCnXNzHZ0(url,False)
	elif mode==119: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HjZcUIVAXFCqy9TfBWKtgY2(text)
	else: ft3e2JBKQVXWlFPjaMhkEqGxvDg = False
	return ft3e2JBKQVXWlFPjaMhkEqGxvDg
def eN02L7Tf5bQ():
	headers = {'User-Agent':IeSGolOpBHM8U62m(True)}
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(SToQEHqGtMnAlFbCz4wxBDuOsmW7,'GET',EZxQp1WOldMTvFU,'',headers,'','','SHAHID4U-MENU-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	xxE5BSyQkNsj = EZxQp1WOldMTvFU
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'بحث في الموقع','',119,'','','_REMEMBERRESULTS_')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'فلتر محدد',xxE5BSyQkNsj,115)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'فلتر كامل',xxE5BSyQkNsj,114)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'المميزة',xxE5BSyQkNsj,111,'','','featured')
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('simple-filter(.*?)adv-filter',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if not XBuP6Op7y4K:
		ZIOHgA3z0TBR('','','موقع شاهد فوريو','البرنامج لم يستطيع إيجاد عنوان الموقع أو تصميم الموقع تغير')
		return
	else:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('location = \'(.*?)\'.*?src="(.*?)".*?<h3>(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for filter,IcWzVO137wFvemn2QTq8yKs9,title in items:
			url = xxE5BSyQkNsj+filter
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+title,url,111,IcWzVO137wFvemn2QTq8yKs9,'',filter)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('class="dropdown"(.*?)<script>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?>(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title in items:
			title = title.replace('\n','').replace('\r','').strip(' ')
			if title in eh2tDvRFWpLQI: continue
			if 'http' not in BoEFz2WhUyvTgDeiZ: BoEFz2WhUyvTgDeiZ = xxE5BSyQkNsj+BoEFz2WhUyvTgDeiZ
			if 'netflix' in BoEFz2WhUyvTgDeiZ: title = 'نيتفلكس'
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,111)
	return MK6ZT2zjC1SbmveNFqor
def sscM839DP1jWZ4zl6uIx0Kyn(url,rwQsc9O3oGdFKbxPlNiM56S2pLUJ0='',xHb86g9WZqPwRfVjXD2JalzSIp=''):
	headers = {'User-Agent':IeSGolOpBHM8U62m(True)}
	if not xHb86g9WZqPwRfVjXD2JalzSIp: xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'',headers,'','','SHAHID4U-TITLES-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	XBuP6Op7y4K,items,y7y3d5Fbhv42ONmtwLZ0SerYoQq = [],[],[]
	if rwQsc9O3oGdFKbxPlNiM56S2pLUJ0=='featured': XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('glide__slides(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	else: XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('shows-container(.*?)pagination',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if not XBuP6Op7y4K: return
	vsptNMP2ZQC = XBuP6Op7y4K[0]
	if not items: items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?url\((.*?)\).*?"title">(.*?)</h4>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	tkBQK76YMeUlRI1TomgECfA = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for BoEFz2WhUyvTgDeiZ,IcWzVO137wFvemn2QTq8yKs9,title in items:
		if 'javascript' in BoEFz2WhUyvTgDeiZ: continue
		BoEFz2WhUyvTgDeiZ = XnQbsZF0Ouh8p7zCdUN(BoEFz2WhUyvTgDeiZ).strip('/')
		title = PIfAumbGicwg5ye(title)
		title = title.strip(' ')
		ffhN7jAqe3Q4cR0Ukptzl = My7Dwqvs6bfGNSIgX.findall('(.*?) الحلقة \d+',title,My7Dwqvs6bfGNSIgX.DOTALL)
		if '/film/' in BoEFz2WhUyvTgDeiZ or 'فيلم' in BoEFz2WhUyvTgDeiZ or any(WoFrX46wzbCNp18 in title for WoFrX46wzbCNp18 in tkBQK76YMeUlRI1TomgECfA):
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,112,IcWzVO137wFvemn2QTq8yKs9)
		elif ffhN7jAqe3Q4cR0Ukptzl and 'الحلقة' in title and '/list' not in url:
			title = '_MOD_' + ffhN7jAqe3Q4cR0Ukptzl[0]
			if title not in y7y3d5Fbhv42ONmtwLZ0SerYoQq:
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,113,IcWzVO137wFvemn2QTq8yKs9)
				y7y3d5Fbhv42ONmtwLZ0SerYoQq.append(title)
		elif '/actor/' in BoEFz2WhUyvTgDeiZ:
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,111,IcWzVO137wFvemn2QTq8yKs9)
		elif '/series/' in BoEFz2WhUyvTgDeiZ and '/list' not in url:
			BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ+'/list'
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,111,IcWzVO137wFvemn2QTq8yKs9)
		elif '/list' in url and 'حلقة' in title:
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,112,IcWzVO137wFvemn2QTq8yKs9)
		else: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,113,IcWzVO137wFvemn2QTq8yKs9)
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"pagination"(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		if rwQsc9O3oGdFKbxPlNiM56S2pLUJ0!='search': items = My7Dwqvs6bfGNSIgX.findall('(updateQuery).*?>(.+?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		else: items = My7Dwqvs6bfGNSIgX.findall('<li>.*?href="(.*?)">(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title in items:
			if rwQsc9O3oGdFKbxPlNiM56S2pLUJ0!='search':
				title = title.replace('\n','').replace('\r','')
				if '?' in url: BoEFz2WhUyvTgDeiZ = url+'&page='+title
				else: BoEFz2WhUyvTgDeiZ = url+'?page='+title
			title = PIfAumbGicwg5ye(title)
			if title: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'صفحة '+title,BoEFz2WhUyvTgDeiZ,111,'','',rwQsc9O3oGdFKbxPlNiM56S2pLUJ0)
	return
def o4oY13v5dWMcbilEDjKCnXNzHZ0(url,ZTa0VhtXBHjy3L):
	headers = {'User-Agent':IeSGolOpBHM8U62m(True)}
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'',headers,'','','SHAHID4U-EPISODES-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('items d-flex(.*?)</div>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if len(XBuP6Op7y4K)>1:
		if '/season/' in XBuP6Op7y4K[0]: Or0yBIEzGeCn6pkYDgRal78F,o93oJVvuQUY = XBuP6Op7y4K[0],XBuP6Op7y4K[1]
		else: Or0yBIEzGeCn6pkYDgRal78F,o93oJVvuQUY = XBuP6Op7y4K[1],XBuP6Op7y4K[0]
	else: Or0yBIEzGeCn6pkYDgRal78F,o93oJVvuQUY = XBuP6Op7y4K[0],XBuP6Op7y4K[0]
	for k3Om08MCgqQao4n1 in range(2):
		if ZTa0VhtXBHjy3L: mode,type,vsptNMP2ZQC = 116,'folder',Or0yBIEzGeCn6pkYDgRal78F
		else: mode,type,vsptNMP2ZQC = 112,'video',o93oJVvuQUY
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?span.*?">(.*?)<.*?span.*?">(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		if ZTa0VhtXBHjy3L and len(items)<2:
			ZTa0VhtXBHjy3L = False
			continue
		for BoEFz2WhUyvTgDeiZ,yXskwRgtdJ,U2UaTcgBpsEZxKiRG1Xv8 in items:
			title = yXskwRgtdJ+' '+U2UaTcgBpsEZxKiRG1Xv8
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX(type,teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,mode)
		break
	if not items and '/episodes' in MK6ZT2zjC1SbmveNFqor:
		MnacHlNXuFr8WPhbZOt40Q = My7Dwqvs6bfGNSIgX.findall('class="breadcrumb"(.*?)</div>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if MnacHlNXuFr8WPhbZOt40Q:
			vsptNMP2ZQC = MnacHlNXuFr8WPhbZOt40Q[0]
			NVHrZsqUp2 = My7Dwqvs6bfGNSIgX.findall('href="(.*?)"',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
			if len(NVHrZsqUp2)>2:
				BoEFz2WhUyvTgDeiZ = NVHrZsqUp2[2]+'list'
				sscM839DP1jWZ4zl6uIx0Kyn(BoEFz2WhUyvTgDeiZ)
	return
def HDxCnPKFhITpZmOsA4a0UL6(url):
	headers = {'User-Agent':IeSGolOpBHM8U62m(True)}
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(IIiPCruL6dT8s1lqj47SzpVHnYNm,'GET',url,'',headers,'','','SHAHID4U-PLAY-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('class="actions(.*?)</div>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if not XBuP6Op7y4K: return
	vsptNMP2ZQC = XBuP6Op7y4K[0]
	NVHrZsqUp2 = My7Dwqvs6bfGNSIgX.findall('href="(.*?)"',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	FFhMR5JUc8XbmlVONaYp = '/watch/' in vsptNMP2ZQC
	download = '/download/' in vsptNMP2ZQC
	if   FFhMR5JUc8XbmlVONaYp and not download: rox0PTJ34whNgakRWZzu2bijXlOUsQ,AhciOCIG2L = NVHrZsqUp2[0],''
	elif not FFhMR5JUc8XbmlVONaYp and download: rox0PTJ34whNgakRWZzu2bijXlOUsQ,AhciOCIG2L = '',NVHrZsqUp2[0]
	elif FFhMR5JUc8XbmlVONaYp and download: rox0PTJ34whNgakRWZzu2bijXlOUsQ,AhciOCIG2L = NVHrZsqUp2[0],NVHrZsqUp2[1]
	else: rox0PTJ34whNgakRWZzu2bijXlOUsQ,AhciOCIG2L = '',''
	QQ2cE1FjUyxPonbDhaTkV6B3i = []
	if FFhMR5JUc8XbmlVONaYp:
		xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(IIiPCruL6dT8s1lqj47SzpVHnYNm,'GET',rox0PTJ34whNgakRWZzu2bijXlOUsQ,'',headers,'','','SHAHID4U-PLAY-2nd')
		wN6n7OZBoDkTvCi8LdbJjYV = xHb86g9WZqPwRfVjXD2JalzSIp.content
		kdYXhMN8Hpbt = My7Dwqvs6bfGNSIgX.findall('let servers(.*?)player',wN6n7OZBoDkTvCi8LdbJjYV,My7Dwqvs6bfGNSIgX.DOTALL|My7Dwqvs6bfGNSIgX.IGNORECASE)
		if kdYXhMN8Hpbt:
			iiBEzXVNFDhfj36 = kdYXhMN8Hpbt[0]
			zE1FBZLDvygwGdkef74lnRJVXCUqKH = My7Dwqvs6bfGNSIgX.findall('"name":"(.*?)".*?"url":"(.*?)"',iiBEzXVNFDhfj36,My7Dwqvs6bfGNSIgX.DOTALL)
			for title,BoEFz2WhUyvTgDeiZ in zE1FBZLDvygwGdkef74lnRJVXCUqKH:
				BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ.replace('\\/','/')
				BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ+'?named='+title+'__watch'
				QQ2cE1FjUyxPonbDhaTkV6B3i.append(BoEFz2WhUyvTgDeiZ)
	if download:
		xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(IIiPCruL6dT8s1lqj47SzpVHnYNm,'GET',AhciOCIG2L,'',headers,'','','SHAHID4U-PLAY-3rd')
		wN6n7OZBoDkTvCi8LdbJjYV = xHb86g9WZqPwRfVjXD2JalzSIp.content
		kdYXhMN8Hpbt = My7Dwqvs6bfGNSIgX.findall('"servers"(.*?)info-container',wN6n7OZBoDkTvCi8LdbJjYV,My7Dwqvs6bfGNSIgX.DOTALL)
		if kdYXhMN8Hpbt:
			iiBEzXVNFDhfj36 = kdYXhMN8Hpbt[0]
			zE1FBZLDvygwGdkef74lnRJVXCUqKH = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?<span>(.*?)<.*?</i>.*?<span>(.*?)<',iiBEzXVNFDhfj36,My7Dwqvs6bfGNSIgX.DOTALL)
			for BoEFz2WhUyvTgDeiZ,title,LLnUyuiC2wRM0 in zE1FBZLDvygwGdkef74lnRJVXCUqKH:
				BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ+'?named='+title+'__download'+'____'+LLnUyuiC2wRM0
				QQ2cE1FjUyxPonbDhaTkV6B3i.append(BoEFz2WhUyvTgDeiZ)
	import t1kDWXQVpC
	t1kDWXQVpC.rqVt2xDi7jzJHBcPMRs6h0L(QQ2cE1FjUyxPonbDhaTkV6B3i,baNWS6nfqTC5iX4Kl,'video',url)
	return
def HjZcUIVAXFCqy9TfBWKtgY2(search):
	search,LQf3AeozSrai,showDialogs = X54MLovbG8nAEkB9J(search)
	if not search:
		search = ViKAIsLurq83RSENayxWb()
		if not search: return
	search = search.replace(' ','+')
	url = EZxQp1WOldMTvFU+'/search?s='+search
	sscM839DP1jWZ4zl6uIx0Kyn(url,'search')
	return
def lAjOn69YLFxJNEvTrbfwkiXm2d(url):
	url = url.split('/smartemadfilter?')[0]
	headers = {'User-Agent':IeSGolOpBHM8U62m(True)}
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(IIiPCruL6dT8s1lqj47SzpVHnYNm,'GET',url,'',headers,'','','SHAHID4U-GET_FILTERS_BLOCKS-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	E3ErsLQfR4JXt = []
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('adv-filter(.*?)shows-container',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		E3ErsLQfR4JXt = My7Dwqvs6bfGNSIgX.findall('''updateQuery\('(.*?)'.*?value>(.*?)<(.*?)</select''',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		yaIcBHGsnqtQ8,P9pVfsQSTg7IraUGeKLWwxdz,xAcIatGBYy0FLXroS1ig3Ts9KZ8P5 = zip(*E3ErsLQfR4JXt)
		E3ErsLQfR4JXt = zip(P9pVfsQSTg7IraUGeKLWwxdz,yaIcBHGsnqtQ8,xAcIatGBYy0FLXroS1ig3Ts9KZ8P5)
	return E3ErsLQfR4JXt
def kvYFrVe3g8H7dNhIa(vsptNMP2ZQC):
	items = My7Dwqvs6bfGNSIgX.findall('value="(.*?)".*?>\s*(.*?)\s*<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	return items
def Dm3ydMnCxH49R(url):
	if '/smartemadfilter?' not in url: url = url+'/smartemadfilter?'
	ulX0L8F7ZqcwGTJRMk = url.split('/smartemadfilter?')[0]
	M0RTIYy1EUX = ooq2D9xF8ZLpPBs(url,'url')
	url = url.replace(ulX0L8F7ZqcwGTJRMk,M0RTIYy1EUX)
	url = url.replace('/smartemadfilter?','/?')
	return url
eymLcfnNAQpBaU7 = ['quality','year','genre','category']
mQJHz26sAG = ['category','genre','year']
def LLJlTxDePyjoVKA(url,filter):
	url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter=='': H2HMwT4JFz7rDkPZmRjcX,JPnr9ICqkDyV = '',''
	else: H2HMwT4JFz7rDkPZmRjcX,JPnr9ICqkDyV = filter.split('___')
	if type=='DEFINED_FILTER':
		if mQJHz26sAG[0]+'=' not in H2HMwT4JFz7rDkPZmRjcX: g4Y0BXLxCpuojKP1SAUtcq7TwN2 = mQJHz26sAG[0]
		for FVW0I9sYcAjmDgn8r in range(len(mQJHz26sAG[0:-1])):
			if mQJHz26sAG[FVW0I9sYcAjmDgn8r]+'=' in H2HMwT4JFz7rDkPZmRjcX: g4Y0BXLxCpuojKP1SAUtcq7TwN2 = mQJHz26sAG[FVW0I9sYcAjmDgn8r+1]
		HHXeMqVOshPcW3tULa5v = H2HMwT4JFz7rDkPZmRjcX+'&'+g4Y0BXLxCpuojKP1SAUtcq7TwN2+'=0'
		DoSfCckGA9BQe = JPnr9ICqkDyV+'&'+g4Y0BXLxCpuojKP1SAUtcq7TwN2+'=0'
		A7AEKRlF6Hf3eWVxY0NdwgsMPCc = HHXeMqVOshPcW3tULa5v.strip('&')+'___'+DoSfCckGA9BQe.strip('&')
		woj78rBnbLlmZWIy19iPHFCf5 = BrbZhHKJ0jnIe2lumE9M(JPnr9ICqkDyV,'modified_filters')
		bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = url+'/smartemadfilter?'+woj78rBnbLlmZWIy19iPHFCf5
	elif type=='FULL_FILTER':
		WUSylLup41cYkhVXGtq = BrbZhHKJ0jnIe2lumE9M(H2HMwT4JFz7rDkPZmRjcX,'modified_values')
		WUSylLup41cYkhVXGtq = XnQbsZF0Ouh8p7zCdUN(WUSylLup41cYkhVXGtq)
		if JPnr9ICqkDyV!='': JPnr9ICqkDyV = BrbZhHKJ0jnIe2lumE9M(JPnr9ICqkDyV,'modified_filters')
		if JPnr9ICqkDyV=='': bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = url
		else: bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = url+'/smartemadfilter?'+JPnr9ICqkDyV
		QAKdHzO0rehbtyIc = Dm3ydMnCxH49R(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'أظهار قائمة الفيديو التي تم اختيارها ',QAKdHzO0rehbtyIc,111)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+' [[   '+WUSylLup41cYkhVXGtq+'   ]]',QAKdHzO0rehbtyIc,111)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	E3ErsLQfR4JXt = lAjOn69YLFxJNEvTrbfwkiXm2d(url)
	dict = {}
	for name,RTsbVE9CiQt,vsptNMP2ZQC in E3ErsLQfR4JXt:
		name = name.replace('كل ','')
		items = kvYFrVe3g8H7dNhIa(vsptNMP2ZQC)
		if '=' not in bJEs4IVAPdyUrhwCLv9k2YoOl8nt1: bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = url
		if type=='DEFINED_FILTER':
			if g4Y0BXLxCpuojKP1SAUtcq7TwN2!=RTsbVE9CiQt: continue
			elif len(items)<2:
				if RTsbVE9CiQt==mQJHz26sAG[-1]:
					QAKdHzO0rehbtyIc = Dm3ydMnCxH49R(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1)
					sscM839DP1jWZ4zl6uIx0Kyn(QAKdHzO0rehbtyIc)
				else: LLJlTxDePyjoVKA(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,'DEFINED_FILTER___'+A7AEKRlF6Hf3eWVxY0NdwgsMPCc)
				return
			else:
				if RTsbVE9CiQt==mQJHz26sAG[-1]:
					QAKdHzO0rehbtyIc = Dm3ydMnCxH49R(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1)
					VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'الجميع',QAKdHzO0rehbtyIc,111)
				else: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'الجميع',bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,115,'','',A7AEKRlF6Hf3eWVxY0NdwgsMPCc)
		elif type=='FULL_FILTER':
			HHXeMqVOshPcW3tULa5v = H2HMwT4JFz7rDkPZmRjcX+'&'+RTsbVE9CiQt+'=0'
			DoSfCckGA9BQe = JPnr9ICqkDyV+'&'+RTsbVE9CiQt+'=0'
			A7AEKRlF6Hf3eWVxY0NdwgsMPCc = HHXeMqVOshPcW3tULa5v+'___'+DoSfCckGA9BQe
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'الجميع :'+name,bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,114,'','',A7AEKRlF6Hf3eWVxY0NdwgsMPCc)
		dict[RTsbVE9CiQt] = {}
		for WoFrX46wzbCNp18,A5AMg7LY1HlOz0B82n in items:
			if WoFrX46wzbCNp18=='196533': A5AMg7LY1HlOz0B82n = 'أفلام نيتفلكس'
			elif WoFrX46wzbCNp18=='196531': A5AMg7LY1HlOz0B82n = 'مسلسلات نيتفلكس'
			if A5AMg7LY1HlOz0B82n in eh2tDvRFWpLQI: continue
			dict[RTsbVE9CiQt][WoFrX46wzbCNp18] = A5AMg7LY1HlOz0B82n
			HHXeMqVOshPcW3tULa5v = H2HMwT4JFz7rDkPZmRjcX+'&'+RTsbVE9CiQt+'='+A5AMg7LY1HlOz0B82n
			DoSfCckGA9BQe = JPnr9ICqkDyV+'&'+RTsbVE9CiQt+'='+WoFrX46wzbCNp18
			QQIzTLCXyhtZ7pRNnGq = HHXeMqVOshPcW3tULa5v+'___'+DoSfCckGA9BQe
			title = A5AMg7LY1HlOz0B82n+' :'#+dict[RTsbVE9CiQt]['0']
			title = A5AMg7LY1HlOz0B82n+' :'+name
			if type=='FULL_FILTER': VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,url,114,'','',QQIzTLCXyhtZ7pRNnGq)
			elif type=='DEFINED_FILTER' and mQJHz26sAG[-2]+'=' in H2HMwT4JFz7rDkPZmRjcX:
				woj78rBnbLlmZWIy19iPHFCf5 = BrbZhHKJ0jnIe2lumE9M(DoSfCckGA9BQe,'modified_filters')
				bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = url+'/smartemadfilter?'+woj78rBnbLlmZWIy19iPHFCf5
				QAKdHzO0rehbtyIc = Dm3ydMnCxH49R(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1)
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,QAKdHzO0rehbtyIc,111)
			else: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,url,115,'','',QQIzTLCXyhtZ7pRNnGq)
	return
def BrbZhHKJ0jnIe2lumE9M(PPebqkulZUsx3GCLdnYvR,mode):
	PPebqkulZUsx3GCLdnYvR = PPebqkulZUsx3GCLdnYvR.replace('=&','=0&')
	PPebqkulZUsx3GCLdnYvR = PPebqkulZUsx3GCLdnYvR.strip('&')
	mVSjqdOvyf = {}
	if '=' in PPebqkulZUsx3GCLdnYvR:
		items = PPebqkulZUsx3GCLdnYvR.split('&')
		for ZA1fBenNahOR3xrkjvwYSVMy6JK5s in items:
			nmqEj60bcdSQoFPGa,WoFrX46wzbCNp18 = ZA1fBenNahOR3xrkjvwYSVMy6JK5s.split('=')
			mVSjqdOvyf[nmqEj60bcdSQoFPGa] = WoFrX46wzbCNp18
	DidZH6E0pJelcU9xMCBgyL2KvR = ''
	for key in eymLcfnNAQpBaU7:
		if key in list(mVSjqdOvyf.keys()): WoFrX46wzbCNp18 = mVSjqdOvyf[key]
		else: WoFrX46wzbCNp18 = '0'
		if '%' not in WoFrX46wzbCNp18: WoFrX46wzbCNp18 = F8fMqZKB4APk(WoFrX46wzbCNp18)
		if mode=='modified_values' and WoFrX46wzbCNp18!='0': DidZH6E0pJelcU9xMCBgyL2KvR = DidZH6E0pJelcU9xMCBgyL2KvR+' + '+WoFrX46wzbCNp18
		elif mode=='modified_filters' and WoFrX46wzbCNp18!='0': DidZH6E0pJelcU9xMCBgyL2KvR = DidZH6E0pJelcU9xMCBgyL2KvR+'&'+key+'='+WoFrX46wzbCNp18
		elif mode=='all': DidZH6E0pJelcU9xMCBgyL2KvR = DidZH6E0pJelcU9xMCBgyL2KvR+'&'+key+'='+WoFrX46wzbCNp18
	DidZH6E0pJelcU9xMCBgyL2KvR = DidZH6E0pJelcU9xMCBgyL2KvR.strip(' + ')
	DidZH6E0pJelcU9xMCBgyL2KvR = DidZH6E0pJelcU9xMCBgyL2KvR.strip('&')
	DidZH6E0pJelcU9xMCBgyL2KvR = DidZH6E0pJelcU9xMCBgyL2KvR.replace('=0','=')
	return DidZH6E0pJelcU9xMCBgyL2KvR
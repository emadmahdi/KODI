# -*- coding: utf-8 -*-
from G6AHskJeqN import *
baNWS6nfqTC5iX4Kl = 'DAILYMOTION'
teUPLFC3B8bArakwHVGsdhoIWDM49f = '_DLM_'
EZxQp1WOldMTvFU = AK5RqLhji4W1wt9VdrCD3PGeQM[baNWS6nfqTC5iX4Kl][0]
oHxnAT1DzYQv = AK5RqLhji4W1wt9VdrCD3PGeQM[baNWS6nfqTC5iX4Kl][1]
def VbgEajY4Bt2COpGDcPqI(mode,url,text,type,z3z9QgENFk5eMYB4):
	if	 mode==400: ft3e2JBKQVXWlFPjaMhkEqGxvDg = eN02L7Tf5bQ()
	elif mode==401: ft3e2JBKQVXWlFPjaMhkEqGxvDg = XXtZ359rCBMzJYGuO4HlRTkVUIhjeL(url,text)
	elif mode==402: ft3e2JBKQVXWlFPjaMhkEqGxvDg = EFBu9AIHbZPrYLqpjMTzJf6yGmD(url,text)
	elif mode==403: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HDxCnPKFhITpZmOsA4a0UL6(url,text)
	elif mode==404: ft3e2JBKQVXWlFPjaMhkEqGxvDg = BaMWl5Ok0GegsIq(text,z3z9QgENFk5eMYB4)
	elif mode==405: ft3e2JBKQVXWlFPjaMhkEqGxvDg = APBvkDuV4Uo0d(text,z3z9QgENFk5eMYB4)
	elif mode==406: ft3e2JBKQVXWlFPjaMhkEqGxvDg = NFW240C675SUvbZX1DJVcHQalygRO(text,z3z9QgENFk5eMYB4)
	elif mode==407: ft3e2JBKQVXWlFPjaMhkEqGxvDg = tzFjTchElySPfsrZp4(url,z3z9QgENFk5eMYB4)
	elif mode==408: ft3e2JBKQVXWlFPjaMhkEqGxvDg = FynAxLzWU9RG8QY(url,z3z9QgENFk5eMYB4)
	elif mode==409: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HjZcUIVAXFCqy9TfBWKtgY2(text,z3z9QgENFk5eMYB4)
	elif mode==411: ft3e2JBKQVXWlFPjaMhkEqGxvDg = QbNMPn7KJWifIDUcavq1jLXFu(url,text)
	elif mode==412: ft3e2JBKQVXWlFPjaMhkEqGxvDg = adJCuz9rn5Xvhm2ysLlIN(text,z3z9QgENFk5eMYB4)
	elif mode==413: ft3e2JBKQVXWlFPjaMhkEqGxvDg = eI4DVyR2oOXk3(url,z3z9QgENFk5eMYB4)
	elif mode==414: ft3e2JBKQVXWlFPjaMhkEqGxvDg = U4UK6M9TfB3SgVHYAXFkI(text)
	elif mode==415: ft3e2JBKQVXWlFPjaMhkEqGxvDg = wwn4VTBcLFh0sNftUEHpg(text,z3z9QgENFk5eMYB4)
	else: ft3e2JBKQVXWlFPjaMhkEqGxvDg = False
	return ft3e2JBKQVXWlFPjaMhkEqGxvDg
def eN02L7Tf5bQ():
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'الرئيسية','',414)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'بحث في الموقع','',409,'','','_REMEMBERRESULTS_')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'بحث عن فيديوهات','',409,'','videos?sortBy=','_REMEMBERRESULTS_')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'بحث عن آخر الفيديوهات','',409,'','videos?sortBy=RECENT','_REMEMBERRESULTS_')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'بحث عن الفيديوهات الأكثر مشاهدة','',409,'','videos?sortBy=VIEW_COUNT','_REMEMBERRESULTS_')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'بحث عن قوائم التشغيل','',409,'','playlists','_REMEMBERRESULTS_')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'بحث عن قنوات','',409,'','channels','_REMEMBERRESULTS_')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'بحث عن مواضيع','',409,'','topics','_REMEMBERRESULTS_')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'بحث عن بث حي','',409,'','lives','_REMEMBERRESULTS_')
	return
def EFBu9AIHbZPrYLqpjMTzJf6yGmD(url,cc65AJFLqWMQBVls3UvegRHGb9):
	if '/dm_' in url:
		xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(f9Oum6c0FotxYn,'GET',url,'','',False,'','DAILYMOTION-CHANNELS_SUBMENU-1st',False,False)
		headers = xHb86g9WZqPwRfVjXD2JalzSIp.headers
		if 'Location' in list(headers.keys()): url = EZxQp1WOldMTvFU+headers['Location']
	cc65AJFLqWMQBVls3UvegRHGb9 = '[COLOR FFC89008]'+cc65AJFLqWMQBVls3UvegRHGb9+'[/COLOR]'
	cc65AJFLqWMQBVls3UvegRHGb9 = gImzaniMWhu8J(cc65AJFLqWMQBVls3UvegRHGb9)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+':: بث حي',url,411,'','','channel_lives_now')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+':: آخر الفيديوهات',url+'/videos',408)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+':: الأكثر مشاهدة',url+'/videos?sort=visited',408)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+':: المميزة',url,411,'','','channel_featured_videos')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+':: قوائم التشغيل',url+'/playlists',407)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+':: قوائم التشغيل أبجدية',url+'/playlists?sort=alphaaz',407)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+':: قنوات ذات صلة',url,411,'','','channel_related_channel')
	return
def gImzaniMWhu8J(title):
	title = title.rstrip('\\').strip(' ').replace('\\\\','\\')
	title = tW06wVMpReHfnj3KgzT2va(title)
	return title
def HDxCnPKFhITpZmOsA4a0UL6(url,eMw2JCRLdZVYbjrtOTGEBK7FyD0N5c):
	import t1kDWXQVpC
	t1kDWXQVpC.rqVt2xDi7jzJHBcPMRs6h0L([url],baNWS6nfqTC5iX4Kl,'video',url)
	return
def BaMWl5Ok0GegsIq(search,z3z9QgENFk5eMYB4=''):
	if z3z9QgENFk5eMYB4=='': z3z9QgENFk5eMYB4 = '1'
	if 'sortBy=' in search: sort = search.split('sortBy=')[1].split('&')[0]
	else: sort = ''
	search = search.split('/videos')[0]
	h5QaxwPF7SOu6fMBTGXRU2yn = '{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeVideos":true,"page":mypagenumber,"limit":mypagelimitmysortmethod},"query":"fragment VIDEO_BASE_FRAGMENT on Video {\n  id\n  xid\n  title\n  createdAt\n  stats {\n    views {\n      total\n      __typename\n    }\n    __typename\n  }\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  duration\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  __typename\n}\n\nfragment VIDEO_WATCH_LATER_FRAGMENT on Video {\n  id\n  isInWatchLater\n  __typename\n}\n\nfragment CHANNEL_BASE_FRAG on Channel {\n  accountType\n  id\n  xid\n  name\n  displayName\n  isFollowed\n  thumbnailx60: logoURL(size: \"x60\")\n  thumbnailx120: logoURL(size: \"x120\")\n  thumbnailx240: logoURL(size: \"x240\")\n  thumbnailx720: logoURL(size: \"x720\")\n  __typename\n}\n\nfragment PLAYLIST_BASE_FRAG on Collection {\n  id\n  xid\n  name\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  description\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  stats {\n    videos {\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nquery SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {\n  search {\n    id\n    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...VIDEO_BASE_FRAGMENT\n          ...VIDEO_WATCH_LATER_FRAGMENT\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...CHANNEL_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...PLAYLIST_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	h5QaxwPF7SOu6fMBTGXRU2yn = h5QaxwPF7SOu6fMBTGXRU2yn.replace('mysearchwords',search)
	h5QaxwPF7SOu6fMBTGXRU2yn = h5QaxwPF7SOu6fMBTGXRU2yn.replace('mypagelimit','40')
	h5QaxwPF7SOu6fMBTGXRU2yn = h5QaxwPF7SOu6fMBTGXRU2yn.replace('mypagenumber',z3z9QgENFk5eMYB4)
	if sort=='': h5QaxwPF7SOu6fMBTGXRU2yn = h5QaxwPF7SOu6fMBTGXRU2yn.replace('mysortmethod','')
	else: h5QaxwPF7SOu6fMBTGXRU2yn = h5QaxwPF7SOu6fMBTGXRU2yn.replace('mysortmethod',',"sortByVideos":"'+sort+'"')
	url = EZxQp1WOldMTvFU+'/search/'+search+'/videos'
	MK6ZT2zjC1SbmveNFqor = OSYhRAPzwE3o9(h5QaxwPF7SOu6fMBTGXRU2yn)
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"videos"(.*?)"VideoConnection"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('"node".*?"xid":"(.*?)","title":"(.*?)".*?"name":"(.*?)".*?"displayName":"(.*?)".*?"duration":(.*?),.*?"thumbnailx240":"(.*?)"',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for id,title,mgcEXNFSCihQ,cc65AJFLqWMQBVls3UvegRHGb9,LEb1HQDAeFdsrNTnVgmXo9,IcWzVO137wFvemn2QTq8yKs9 in items:
			if '"' in id: id = id.replace('"','')
			if '"' in title: title = title.replace('"','')
			if '"' in IcWzVO137wFvemn2QTq8yKs9: IcWzVO137wFvemn2QTq8yKs9 = IcWzVO137wFvemn2QTq8yKs9.replace('"','')
			if '"' in LEb1HQDAeFdsrNTnVgmXo9: LEb1HQDAeFdsrNTnVgmXo9 = LEb1HQDAeFdsrNTnVgmXo9.replace('"','')
			if '"' in mgcEXNFSCihQ: mgcEXNFSCihQ = mgcEXNFSCihQ.replace('"','')
			if '"' in cc65AJFLqWMQBVls3UvegRHGb9: cc65AJFLqWMQBVls3UvegRHGb9 = cc65AJFLqWMQBVls3UvegRHGb9.replace('"','')
			BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU+'/video/'+id
			title = gImzaniMWhu8J(title)
			eMw2JCRLdZVYbjrtOTGEBK7FyD0N5c = mgcEXNFSCihQ+'::'+cc65AJFLqWMQBVls3UvegRHGb9
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,403,IcWzVO137wFvemn2QTq8yKs9,LEb1HQDAeFdsrNTnVgmXo9,eMw2JCRLdZVYbjrtOTGEBK7FyD0N5c)
		if '"hasNextPage":true' in MK6ZT2zjC1SbmveNFqor:
			z3z9QgENFk5eMYB4 = str(int(z3z9QgENFk5eMYB4)+1)
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'صفحة '+z3z9QgENFk5eMYB4,url,404,'',z3z9QgENFk5eMYB4,search)
	return
def APBvkDuV4Uo0d(search,z3z9QgENFk5eMYB4=''):
	if z3z9QgENFk5eMYB4=='': z3z9QgENFk5eMYB4 = '1'
	h5QaxwPF7SOu6fMBTGXRU2yn = '{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":true,"shouldIncludeVideos":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {\n  id\n  xid\n  title\n  createdAt\n  stats {\n    views {\n      total\n      __typename\n    }\n    __typename\n  }\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  duration\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  __typename\n}\n\nfragment VIDEO_WATCH_LATER_FRAGMENT on Video {\n  id\n  isInWatchLater\n  __typename\n}\n\nfragment CHANNEL_BASE_FRAG on Channel {\n  accountType\n  id\n  xid\n  name\n  displayName\n  isFollowed\n  thumbnailx60: logoURL(size: \"x60\")\n  thumbnailx120: logoURL(size: \"x120\")\n  thumbnailx240: logoURL(size: \"x240\")\n  thumbnailx720: logoURL(size: \"x720\")\n  __typename\n}\n\nfragment PLAYLIST_BASE_FRAG on Collection {\n  id\n  xid\n  name\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  description\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  stats {\n    videos {\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nquery SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {\n  search {\n    id\n    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...VIDEO_BASE_FRAGMENT\n          ...VIDEO_WATCH_LATER_FRAGMENT\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...CHANNEL_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...PLAYLIST_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	h5QaxwPF7SOu6fMBTGXRU2yn = h5QaxwPF7SOu6fMBTGXRU2yn.replace('mysearchwords',search)
	h5QaxwPF7SOu6fMBTGXRU2yn = h5QaxwPF7SOu6fMBTGXRU2yn.replace('mypagelimit','40')
	h5QaxwPF7SOu6fMBTGXRU2yn = h5QaxwPF7SOu6fMBTGXRU2yn.replace('mypagenumber',z3z9QgENFk5eMYB4)
	url = EZxQp1WOldMTvFU+'/search/'+search+'/playlists'
	MK6ZT2zjC1SbmveNFqor = OSYhRAPzwE3o9(h5QaxwPF7SOu6fMBTGXRU2yn)
	items = My7Dwqvs6bfGNSIgX.findall('"node".*?"xid":"(.*?)".*?"name":"(.*?)".*?"xid":"(.*?)".*?"name":"(.*?)".*?"displayName":"(.*?)".*?"thumbnailx240":"(.*?)".*?"total":(.*?),',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	for id,name,mZ7eF8QKqri6T2pVOSDX1YNg,mgcEXNFSCihQ,cc65AJFLqWMQBVls3UvegRHGb9,IcWzVO137wFvemn2QTq8yKs9,count in items:
		if '"' in mZ7eF8QKqri6T2pVOSDX1YNg: mZ7eF8QKqri6T2pVOSDX1YNg = mZ7eF8QKqri6T2pVOSDX1YNg.replace('"','')
		if '"' in mgcEXNFSCihQ: mgcEXNFSCihQ = mgcEXNFSCihQ.replace('"','')
		if '"' in cc65AJFLqWMQBVls3UvegRHGb9: cc65AJFLqWMQBVls3UvegRHGb9 = cc65AJFLqWMQBVls3UvegRHGb9.replace('"','')
		if '"' in id: id = id.replace('"','')
		if '"' in name: name = name.replace('"','')
		if '"' in IcWzVO137wFvemn2QTq8yKs9: IcWzVO137wFvemn2QTq8yKs9 = IcWzVO137wFvemn2QTq8yKs9.replace('"','')
		if '"' in count: count = count.replace('"','')
		BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU+'/playlist/'+id
		title = 'LIST'+count+':  '+name
		title = gImzaniMWhu8J(title)
		eMw2JCRLdZVYbjrtOTGEBK7FyD0N5c = mgcEXNFSCihQ+'::'+cc65AJFLqWMQBVls3UvegRHGb9
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,401,IcWzVO137wFvemn2QTq8yKs9,'',eMw2JCRLdZVYbjrtOTGEBK7FyD0N5c)
	if '"hasNextPage":true' in MK6ZT2zjC1SbmveNFqor:
		z3z9QgENFk5eMYB4 = str(int(z3z9QgENFk5eMYB4)+1)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'صفحة '+z3z9QgENFk5eMYB4,url,405,'',z3z9QgENFk5eMYB4,search)
	return
def NFW240C675SUvbZX1DJVcHQalygRO(search,z3z9QgENFk5eMYB4=''):
	if z3z9QgENFk5eMYB4=='': z3z9QgENFk5eMYB4 = '1'
	h5QaxwPF7SOu6fMBTGXRU2yn = '{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":true,"shouldIncludePlaylists":false,"shouldIncludeVideos":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {\n  id\n  xid\n  title\n  createdAt\n  stats {\n    views {\n      total\n      __typename\n    }\n    __typename\n  }\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  duration\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  __typename\n}\n\nfragment VIDEO_WATCH_LATER_FRAGMENT on Video {\n  id\n  isInWatchLater\n  __typename\n}\n\nfragment CHANNEL_BASE_FRAG on Channel {\n  accountType\n  id\n  xid\n  name\n  displayName\n  isFollowed\n  thumbnailx60: logoURL(size: \"x60\")\n  thumbnailx120: logoURL(size: \"x120\")\n  thumbnailx240: logoURL(size: \"x240\")\n  thumbnailx720: logoURL(size: \"x720\")\n  __typename\n}\n\nfragment PLAYLIST_BASE_FRAG on Collection {\n  id\n  xid\n  name\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  description\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  stats {\n    videos {\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nquery SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {\n  search {\n    id\n    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...VIDEO_BASE_FRAGMENT\n          ...VIDEO_WATCH_LATER_FRAGMENT\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...CHANNEL_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...PLAYLIST_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	h5QaxwPF7SOu6fMBTGXRU2yn = h5QaxwPF7SOu6fMBTGXRU2yn.replace('mysearchwords',search)
	h5QaxwPF7SOu6fMBTGXRU2yn = h5QaxwPF7SOu6fMBTGXRU2yn.replace('mypagelimit','40')
	h5QaxwPF7SOu6fMBTGXRU2yn = h5QaxwPF7SOu6fMBTGXRU2yn.replace('mypagenumber',z3z9QgENFk5eMYB4)
	url = EZxQp1WOldMTvFU+'/search/'+search+'/channels'
	MK6ZT2zjC1SbmveNFqor = OSYhRAPzwE3o9(h5QaxwPF7SOu6fMBTGXRU2yn)
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"channels"(.*?)"ChannelConnection"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('"node".*?"name":"(.*?)".*?"displayName":"(.*?)".*?"thumbnailx240":"(.*?)"',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for id,name,IcWzVO137wFvemn2QTq8yKs9 in items:
			if '"' in id: id = id.replace('"','')
			if '"' in name: name = name.replace('"','')
			if '"' in IcWzVO137wFvemn2QTq8yKs9: IcWzVO137wFvemn2QTq8yKs9 = IcWzVO137wFvemn2QTq8yKs9.replace('"','')
			BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU+'/'+id
			title = 'CHNL:  '+name
			title = gImzaniMWhu8J(title)
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,402,IcWzVO137wFvemn2QTq8yKs9,'',name)
		if '"hasNextPage":true' in MK6ZT2zjC1SbmveNFqor:
			z3z9QgENFk5eMYB4 = str(int(z3z9QgENFk5eMYB4)+1)
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'صفحة '+z3z9QgENFk5eMYB4,url,406,'',z3z9QgENFk5eMYB4,search)
	return
def U4UK6M9TfB3SgVHYAXFkI(ayQAfRK5BHuoLmXq0eVlnWcT):
	h5QaxwPF7SOu6fMBTGXRU2yn = '{"operationName":"HOME_QUERY","variables":{"space":"nextplore"},"query":"fragment TOPIC_BASE_FRAG on Topic {\n  id\n  xid\n  name\n  thumbnail: coverURL(size: \"x532\")\n  coverURL: coverURL(size: \"x532\")\n  isFollowed\n  whitelistStatus {\n    id\n    isWhitelisted\n    __typename\n  }\n  __typename\n}\n\nquery HOME_QUERY($space: String!) {\n  home: views {\n    id\n    neon {\n      id\n      sections(space: $space) {\n        edges {\n          node {\n            id\n            name\n            title\n            description\n            groupingType\n            type\n            relatedComponent {\n              __typename\n              ... on Collection {\n                id\n                xid\n                __typename\n              }\n              ... on Channel {\n                id\n                xid\n                name\n                displayName\n                logoURL(size: \"x60\")\n                __typename\n              }\n              ... on Topic {\n                id\n                __typename\n                ...TOPIC_BASE_FRAG\n              }\n            }\n            components {\n              edges {\n                node {\n                  __typename\n                  ... on Video {\n                    id\n                    xid\n                    title\n                    thumbnailx60: thumbnailURL(size: \"x60\")\n                    thumbnailx120: thumbnailURL(size: \"x120\")\n                    thumbnailx240: thumbnailURL(size: \"x240\")\n                    thumbnailx360: thumbnailURL(size: \"x360\")\n                    thumbnailx480: thumbnailURL(size: \"x480\")\n                    thumbnailx720: thumbnailURL(size: \"x720\")\n                    aspectRatio\n                    createdAt\n                    channel {\n                      id\n                      xid\n                      name\n                      displayName\n                      logoURLx25: logoURL(size: \"x25\")\n                      accountType\n                      __typename\n                    }\n                    description\n                    duration\n                    __typename\n                  }\n                  ... on Live {\n                    id\n                    xid\n                    title\n                    thumbnailx60: thumbnailURL(size: \"x60\")\n                    thumbnailx120: thumbnailURL(size: \"x120\")\n                    thumbnailx240: thumbnailURL(size: \"x240\")\n                    thumbnailx360: thumbnailURL(size: \"x360\")\n                    thumbnailx480: thumbnailURL(size: \"x480\")\n                    thumbnailx720: thumbnailURL(size: \"x720\")\n                    aspectRatio\n                    createdAt\n                    channel {\n                      id\n                      xid\n                      name\n                      displayName\n                      logoURLx25: logoURL(size: \"x25\")\n                      accountType\n                      __typename\n                    }\n                    startAt\n                    __typename\n                  }\n                }\n                __typename\n              }\n              __typename\n            }\n            __typename\n          }\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	sdKauTCwnh = OSYhRAPzwE3o9(h5QaxwPF7SOu6fMBTGXRU2yn)
	if sdKauTCwnh:
		OzFoge0T2NKInQGEhXWM = dWsa2A0O4o5BYiqGXhyKEbM('dict',sdKauTCwnh)
		i8h5PeKrRC = OzFoge0T2NKInQGEhXWM['data']['home']['neon']['sections']['edges']
		if not ayQAfRK5BHuoLmXq0eVlnWcT:
			UTMuWpif4qAeLC71Pw = []
			for s9so2kR8pICV16 in i8h5PeKrRC:
				rWVUZC3861QysBJw4DA5eRal = s9so2kR8pICV16['node']['title']
				if rWVUZC3861QysBJw4DA5eRal not in UTMuWpif4qAeLC71Pw: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+rWVUZC3861QysBJw4DA5eRal,'',414,'','',rWVUZC3861QysBJw4DA5eRal)
				UTMuWpif4qAeLC71Pw.append(rWVUZC3861QysBJw4DA5eRal)
		else:
			for s9so2kR8pICV16 in i8h5PeKrRC:
				rWVUZC3861QysBJw4DA5eRal = s9so2kR8pICV16['node']['title']
				if rWVUZC3861QysBJw4DA5eRal==ayQAfRK5BHuoLmXq0eVlnWcT:
					ylfFsd9eWOX3iJzh4cNp = s9so2kR8pICV16['node']['components']['edges']
					for nnp4jJA1vgmaLHGZ in ylfFsd9eWOX3iJzh4cNp:
						LEb1HQDAeFdsrNTnVgmXo9 = str(nnp4jJA1vgmaLHGZ['node']['duration'])
						title = tW06wVMpReHfnj3KgzT2va(nnp4jJA1vgmaLHGZ['node']['title'])
						title = title.replace('\/','/')
						etMoY2HKSwjrdb5IV = nnp4jJA1vgmaLHGZ['node']['xid']
						IcWzVO137wFvemn2QTq8yKs9 = nnp4jJA1vgmaLHGZ['node']['thumbnailx480']
						IcWzVO137wFvemn2QTq8yKs9 = IcWzVO137wFvemn2QTq8yKs9.replace('\/','/')
						BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU+'/video/'+etMoY2HKSwjrdb5IV
						VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,403,IcWzVO137wFvemn2QTq8yKs9,LEb1HQDAeFdsrNTnVgmXo9)
	return
def wwn4VTBcLFh0sNftUEHpg(search,z3z9QgENFk5eMYB4=''):
	if z3z9QgENFk5eMYB4=='': z3z9QgENFk5eMYB4 = '1'
	h5QaxwPF7SOu6fMBTGXRU2yn = '{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeTopics":false,"shouldIncludeVideos":false,"shouldIncludeLives":true,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {\n  id\n  xid\n  title\n  createdAt\n  stats {\n    id\n    views {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  duration\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  aspectRatio\n  __typename\n}\n\nfragment VIDEO_FAVORITES_FRAGMENT on Media {\n  __typename\n  ... on Video {\n    id\n    viewerEngagement {\n      id\n      favorited\n      __typename\n    }\n    __typename\n  }\n  ... on Live {\n    id\n    viewerEngagement {\n      id\n      favorited\n      __typename\n    }\n    __typename\n  }\n}\n\nfragment CHANNEL_BASE_FRAG on Channel {\n  accountType\n  id\n  xid\n  name\n  displayName\n  isFollowed\n  thumbnailx60: logoURL(size: \"x60\")\n  thumbnailx120: logoURL(size: \"x120\")\n  thumbnailx240: logoURL(size: \"x240\")\n  thumbnailx720: logoURL(size: \"x720\")\n  __typename\n}\n\nfragment PLAYLIST_BASE_FRAG on Collection {\n  id\n  xid\n  name\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  description\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  stats {\n    id\n    videos {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nfragment TOPIC_BASE_FRAG on Topic {\n  id\n  xid\n  name\n  videos(sort: \"recent\", first: 5) {\n    pageInfo {\n      hasNextPage\n      nextPage\n      __typename\n    }\n    edges {\n      node {\n        id\n        ...VIDEO_BASE_FRAGMENT\n        ...VIDEO_FAVORITES_FRAGMENT\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  stats {\n    id\n    videos {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nquery SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeTopics: Boolean!, $shouldIncludeLives: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {\n  search {\n    id\n    videos(\n      query: $query\n      first: $limit\n      page: $page\n      sort: $sortByVideos\n      durationMin: $durationMinVideos\n      durationMax: $durationMaxVideos\n      createdAfter: $createdAfterVideos\n    ) @include(if: $shouldIncludeVideos) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...VIDEO_BASE_FRAGMENT\n          ...VIDEO_FAVORITES_FRAGMENT\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    lives(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeLives) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          xid\n          title\n          thumbnail: thumbnailURL(size: \"x240\")\n          thumbnailx60: thumbnailURL(size: \"x60\")\n          thumbnailx120: thumbnailURL(size: \"x120\")\n          thumbnailx240: thumbnailURL(size: \"x240\")\n          thumbnailx720: thumbnailURL(size: \"x720\")\n          audienceCount\n          aspectRatio\n          isOnAir\n          channel {\n            id\n            xid\n            name\n            displayName\n            accountType\n            __typename\n          }\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...CHANNEL_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...PLAYLIST_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    topics(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeTopics) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...TOPIC_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	h5QaxwPF7SOu6fMBTGXRU2yn = h5QaxwPF7SOu6fMBTGXRU2yn.replace('mysearchwords',search)
	h5QaxwPF7SOu6fMBTGXRU2yn = h5QaxwPF7SOu6fMBTGXRU2yn.replace('mypagelimit','40')
	h5QaxwPF7SOu6fMBTGXRU2yn = h5QaxwPF7SOu6fMBTGXRU2yn.replace('mypagenumber',z3z9QgENFk5eMYB4)
	url = EZxQp1WOldMTvFU+'/search/'+search+'/lives'
	sdKauTCwnh = OSYhRAPzwE3o9(h5QaxwPF7SOu6fMBTGXRU2yn)
	if sdKauTCwnh:
		OzFoge0T2NKInQGEhXWM = dWsa2A0O4o5BYiqGXhyKEbM('dict',sdKauTCwnh)
		try: i8h5PeKrRC = OzFoge0T2NKInQGEhXWM['data']['search']['lives']['edges']
		except: i8h5PeKrRC = []
		for s9so2kR8pICV16 in i8h5PeKrRC:
			name = s9so2kR8pICV16['node']['title']
			etMoY2HKSwjrdb5IV = s9so2kR8pICV16['node']['xid']
			BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU+'/video/'+etMoY2HKSwjrdb5IV
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('live',teUPLFC3B8bArakwHVGsdhoIWDM49f+'LIVE: '+name,BoEFz2WhUyvTgDeiZ,403)
		if '"hasNextPage":true' in sdKauTCwnh:
			z3z9QgENFk5eMYB4 = str(int(z3z9QgENFk5eMYB4)+1)
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'صفحة '+z3z9QgENFk5eMYB4,url,415,'',z3z9QgENFk5eMYB4,search)
	return
def adJCuz9rn5Xvhm2ysLlIN(search,z3z9QgENFk5eMYB4=''):
	if z3z9QgENFk5eMYB4=='': z3z9QgENFk5eMYB4 = '1'
	h5QaxwPF7SOu6fMBTGXRU2yn = '{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeTopics":true,"shouldIncludeVideos":false,"shouldIncludeLives":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {\n  id\n  xid\n  title\n  createdAt\n  stats {\n    id\n    views {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  duration\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  aspectRatio\n  __typename\n}\n\nfragment VIDEO_FAVORITES_FRAGMENT on Media {\n  __typename\n  ... on Video {\n    id\n    isInWatchLater\n    __typename\n  }\n  ... on Live {\n    id\n    isInWatchLater\n    __typename\n  }\n}\n\nfragment CHANNEL_BASE_FRAG on Channel {\n  accountType\n  id\n  xid\n  name\n  displayName\n  isFollowed\n  thumbnailx60: logoURL(size: \"x60\")\n  thumbnailx120: logoURL(size: \"x120\")\n  thumbnailx240: logoURL(size: \"x240\")\n  thumbnailx720: logoURL(size: \"x720\")\n  __typename\n}\n\nfragment PLAYLIST_BASE_FRAG on Collection {\n  id\n  xid\n  name\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  description\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  stats {\n    id\n    videos {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nfragment TOPIC_BASE_FRAG on Topic {\n  id\n  xid\n  name\n  videos(sort: \"recent\", first: 5) {\n    pageInfo {\n      hasNextPage\n      nextPage\n      __typename\n    }\n    edges {\n      node {\n        id\n        ...VIDEO_BASE_FRAGMENT\n        ...VIDEO_FAVORITES_FRAGMENT\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  stats {\n    id\n    videos {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nquery SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeTopics: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {\n  search {\n    id\n    videos(\n      query: $query\n      first: $limit\n      page: $page\n      sort: $sortByVideos\n      durationMin: $durationMinVideos\n      durationMax: $durationMaxVideos\n      createdAfter: $createdAfterVideos\n    ) @include(if: $shouldIncludeVideos) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...VIDEO_BASE_FRAGMENT\n          ...VIDEO_FAVORITES_FRAGMENT\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...CHANNEL_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...PLAYLIST_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    topics(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeTopics) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...TOPIC_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	h5QaxwPF7SOu6fMBTGXRU2yn = h5QaxwPF7SOu6fMBTGXRU2yn.replace('mysearchwords',search)
	h5QaxwPF7SOu6fMBTGXRU2yn = h5QaxwPF7SOu6fMBTGXRU2yn.replace('mypagelimit','40')
	h5QaxwPF7SOu6fMBTGXRU2yn = h5QaxwPF7SOu6fMBTGXRU2yn.replace('mypagenumber',z3z9QgENFk5eMYB4)
	url = EZxQp1WOldMTvFU+'/search/'+search+'/topics'
	sdKauTCwnh = OSYhRAPzwE3o9(h5QaxwPF7SOu6fMBTGXRU2yn)
	if sdKauTCwnh:
		OzFoge0T2NKInQGEhXWM = dWsa2A0O4o5BYiqGXhyKEbM('dict',sdKauTCwnh)
		try: i8h5PeKrRC = OzFoge0T2NKInQGEhXWM['data']['search']['topics']['edges']
		except: i8h5PeKrRC = []
		for s9so2kR8pICV16 in i8h5PeKrRC:
			name = s9so2kR8pICV16['node']['name']
			etMoY2HKSwjrdb5IV = s9so2kR8pICV16['node']['xid']
			BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU+'/topic/'+etMoY2HKSwjrdb5IV
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'TOPIC: '+name,BoEFz2WhUyvTgDeiZ,413)
		if '"hasNextPage":true' in sdKauTCwnh:
			z3z9QgENFk5eMYB4 = str(int(z3z9QgENFk5eMYB4)+1)
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'صفحة '+z3z9QgENFk5eMYB4,url,412,'',z3z9QgENFk5eMYB4,search)
	return
def eI4DVyR2oOXk3(url,z3z9QgENFk5eMYB4=''):
	if z3z9QgENFk5eMYB4=='': z3z9QgENFk5eMYB4 = '1'
	etMoY2HKSwjrdb5IV = url.split('/')[-1]
	h5QaxwPF7SOu6fMBTGXRU2yn = '{"operationName":"DISCOVERY_TOPIC_MAIN_QUERY","variables":{"page":mypagenumber,"xid":"mytopicid"},"query":"fragment TOPIC_VIDEO_FRAGMENT on Video {\n  id\n  xid\n  title\n  duration\n  isLiked\n  isInWatchLater\n  isCreatedForKids\n  createdAt\n  isExplicit\n  videoHeight: height\n  videoWidth: width\n  category\n  channel {\n    id\n    xid\n    name\n    displayName\n    logoURLx25: logoURL(size: \"x25\")\n    logoURL(size: \"x60\")\n    accountType\n    __typename\n  }\n  stats {\n    id\n    views {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  language {\n    id\n    codeAlpha2\n    __typename\n  }\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx360: thumbnailURL(size: \"x360\")\n  thumbnailx480: thumbnailURL(size: \"x480\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  bestAvailableQuality\n  aspectRatio\n  isPublished\n  __typename\n}\n\nquery DISCOVERY_TOPIC_MAIN_QUERY($xid: String!, $page: Int = 1) {\n  topic(xid: $xid) {\n    id\n    xid\n    name\n    videos(sort: \"recent\", first: 30, page: $page) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      edges {\n        node {\n          id\n          ...TOPIC_VIDEO_FRAGMENT\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	h5QaxwPF7SOu6fMBTGXRU2yn = h5QaxwPF7SOu6fMBTGXRU2yn.replace('mytopicid',etMoY2HKSwjrdb5IV)
	h5QaxwPF7SOu6fMBTGXRU2yn = h5QaxwPF7SOu6fMBTGXRU2yn.replace('mypagenumber',z3z9QgENFk5eMYB4)
	sdKauTCwnh = OSYhRAPzwE3o9(h5QaxwPF7SOu6fMBTGXRU2yn)
	if sdKauTCwnh:
		OzFoge0T2NKInQGEhXWM = dWsa2A0O4o5BYiqGXhyKEbM('dict',sdKauTCwnh)
		i8h5PeKrRC = OzFoge0T2NKInQGEhXWM['data']['topic']['videos']['edges']
		for s9so2kR8pICV16 in i8h5PeKrRC:
			LEb1HQDAeFdsrNTnVgmXo9 = str(s9so2kR8pICV16['node']['duration'])
			title = tW06wVMpReHfnj3KgzT2va(s9so2kR8pICV16['node']['title'])
			title = title.replace('\/','/')
			etMoY2HKSwjrdb5IV = s9so2kR8pICV16['node']['xid']
			IcWzVO137wFvemn2QTq8yKs9 = s9so2kR8pICV16['node']['thumbnailx480']
			IcWzVO137wFvemn2QTq8yKs9 = IcWzVO137wFvemn2QTq8yKs9.replace('\/','/')
			BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU+'/video/'+etMoY2HKSwjrdb5IV
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,403,IcWzVO137wFvemn2QTq8yKs9,LEb1HQDAeFdsrNTnVgmXo9)
		if '"hasNextPage":true' in sdKauTCwnh:
			z3z9QgENFk5eMYB4 = str(int(z3z9QgENFk5eMYB4)+1)
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'صفحة '+z3z9QgENFk5eMYB4,url,413,'',z3z9QgENFk5eMYB4)
	return
def XXtZ359rCBMzJYGuO4HlRTkVUIhjeL(url,eMw2JCRLdZVYbjrtOTGEBK7FyD0N5c):
	id = url.split('/')[-1]
	mgcEXNFSCihQ,cc65AJFLqWMQBVls3UvegRHGb9 = eMw2JCRLdZVYbjrtOTGEBK7FyD0N5c.split('::',1)
	BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU+'/'+mgcEXNFSCihQ
	cc65AJFLqWMQBVls3UvegRHGb9 = gImzaniMWhu8J(cc65AJFLqWMQBVls3UvegRHGb9)
	title = '[COLOR FFC89008]OWNER:  '+cc65AJFLqWMQBVls3UvegRHGb9+'[/COLOR]'
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,402,'','',cc65AJFLqWMQBVls3UvegRHGb9)
	h5QaxwPF7SOu6fMBTGXRU2yn = '{"operationName":"DISCOVERY_QUEUE_QUERY","variables":{"collectionXid":"myplaylistid","videoXid":"x7s7qbn"},"query":"query DISCOVERY_QUEUE_QUERY($videoXid: String!, $collectionXid: String, $device: String, $videoCountPerSection: Int) {\n  views {\n    id\n    neon {\n      id\n      sections(device: $device, space: \"watching\", followingChannelXids: [], followingTopicXids: [], watchedVideoXids: [], context: {mediaXid: $videoXid, collectionXid: $collectionXid}, first: 20) {\n        edges {\n          node {\n            id\n            name\n            groupingType\n            relatedComponent {\n              ... on Channel {\n                __typename\n                id\n                xid\n                name\n                displayName\n                logoURL(size: \"x60\")\n                logoURLx25: logoURL(size: \"x25\")\n              }\n              ... on Topic {\n                __typename\n                id\n                xid\n                name\n                names {\n                  edges {\n                    node {\n                      id\n                      name\n                      language {\n                        id\n                        codeAlpha2\n                        __typename\n                      }\n                      __typename\n                    }\n                    __typename\n                  }\n                  __typename\n                }\n              }\n              ... on Collection {\n                __typename\n                id\n                xid\n                name\n              }\n              __typename\n            }\n            components(first: $videoCountPerSection) {\n              metadata {\n                algorithm {\n                  name\n                  version\n                  uuid\n                  __typename\n                }\n                __typename\n              }\n              edges {\n                node {\n                  ... on Video {\n                    __typename\n                    id\n                    xid\n                    title\n                    duration\n                    thumbnailx60: thumbnailURL(size: \"x60\")\n                    thumbnailx120: thumbnailURL(size: \"x120\")\n                    thumbnailx240: thumbnailURL(size: \"x240\")\n                    thumbnailx720: thumbnailURL(size: \"x720\")\n                    channel {\n                      id\n                      xid\n                      accountType\n                      displayName\n                      logoURLx25: logoURL(size: \"x25\")\n                      logoURL(size: \"x60\")\n                      __typename\n                    }\n                  }\n                  ... on Channel {\n                    __typename\n                    id\n                    xid\n                    name\n                    displayName\n                    accountType\n                    logoURL(size: \"x60\")\n                  }\n                  __typename\n                }\n                __typename\n              }\n              __typename\n            }\n            __typename\n          }\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	h5QaxwPF7SOu6fMBTGXRU2yn = h5QaxwPF7SOu6fMBTGXRU2yn.replace('myplaylistid',id)
	MK6ZT2zjC1SbmveNFqor = OSYhRAPzwE3o9(h5QaxwPF7SOu6fMBTGXRU2yn)
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"collection_videos"(.*?)"SectionEdge"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('"node".*?"xid":"(.*?)".*?"title":"(.*?)".*?"duration":(.*?),.*?"thumbnailx240":"(.*?)".*?"xid":"(.*?)".*?"displayName":"(.*?)"',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for id,title,LEb1HQDAeFdsrNTnVgmXo9,IcWzVO137wFvemn2QTq8yKs9,mgcEXNFSCihQ,cc65AJFLqWMQBVls3UvegRHGb9 in items:
			if '"' in id: id = id.replace('"','')
			if '"' in title: title = title.replace('"','')
			if '"' in IcWzVO137wFvemn2QTq8yKs9: IcWzVO137wFvemn2QTq8yKs9 = IcWzVO137wFvemn2QTq8yKs9.replace('"','')
			if '"' in LEb1HQDAeFdsrNTnVgmXo9: LEb1HQDAeFdsrNTnVgmXo9 = LEb1HQDAeFdsrNTnVgmXo9.replace('"','')
			if '"' in mgcEXNFSCihQ: mgcEXNFSCihQ = mgcEXNFSCihQ.replace('"','')
			if '"' in cc65AJFLqWMQBVls3UvegRHGb9: cc65AJFLqWMQBVls3UvegRHGb9 = cc65AJFLqWMQBVls3UvegRHGb9.replace('"','')
			BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU+'/video/'+id
			title = gImzaniMWhu8J(title)
			eMw2JCRLdZVYbjrtOTGEBK7FyD0N5c = mgcEXNFSCihQ+'::'+cc65AJFLqWMQBVls3UvegRHGb9
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,403,IcWzVO137wFvemn2QTq8yKs9,LEb1HQDAeFdsrNTnVgmXo9,eMw2JCRLdZVYbjrtOTGEBK7FyD0N5c)
	return
def FynAxLzWU9RG8QY(url,z3z9QgENFk5eMYB4=''):
	if z3z9QgENFk5eMYB4=='': z3z9QgENFk5eMYB4 = '1'
	cyRC5wYOFEPj9T = url.split('/')[-2]
	if 'sort=' in url: sort = url.split('sort=')[1].split('&')[0]
	else: sort = 'recent'
	h5QaxwPF7SOu6fMBTGXRU2yn = '{"operationName":"CHANNEL_VIDEOS_QUERY","variables":{"channel_xid":"mychannelid","sort":"mysortmethod","page":mypagenumber},"query":"fragment CHANNEL_BASE_FRAGMENT on Channel {\n  id\n  xid\n  name\n  displayName\n  isArtist\n  logoURL(size: \"x60\")\n  isFollowed\n  accountType\n  __typename\n}\n\nfragment CHANNEL_IMAGES_FRAGMENT on Channel {\n  id\n  coverURLx375: coverURL(size: \"x375\")\n  __typename\n}\n\nfragment CHANNEL_UPDATED_FRAGMENT on Channel {\n  id\n  isFollowed\n  stats {\n    views {\n      total\n      __typename\n    }\n    followers {\n      total\n      __typename\n    }\n    videos {\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nfragment CHANNEL_COMPLETE_FRAGMENT on Channel {\n  id\n  ...CHANNEL_BASE_FRAGMENT\n  ...CHANNEL_IMAGES_FRAGMENT\n  ...CHANNEL_UPDATED_FRAGMENT\n  description\n  coverURL1024x: coverURL(size: \"1024x\")\n  coverURL1920x: coverURL(size: \"1920x\")\n  externalLinks {\n    facebookURL\n    twitterURL\n    websiteURL\n    instagramURL\n    __typename\n  }\n  __typename\n}\n\nfragment CHANNEL_FRAGMENT on Channel {\n  accountType\n  id\n  xid\n  name\n  displayName\n  isArtist\n  logoURL(size: \"x60\")\n  coverURLx375: coverURL(size: \"x375\")\n  isFollowed\n  stats {\n    views {\n      total\n      __typename\n    }\n    followers {\n      total\n      __typename\n    }\n    videos {\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nfragment VIDEO_FRAGMENT on Video {\n  id\n  xid\n  title\n  viewCount\n  duration\n  createdAt\n  isInWatchLater\n  channel {\n    id\n    ...CHANNEL_FRAGMENT\n    __typename\n  }\n  thumbURLx240: thumbnailURL(size: \"x240\")\n  thumbURLx360: thumbnailURL(size: \"x360\")\n  thumbURLx480: thumbnailURL(size: \"x480\")\n  thumbURLx720: thumbnailURL(size: \"x720\")\n  __typename\n}\n\nquery CHANNEL_VIDEOS_QUERY($channel_xid: String!, $sort: String, $page: Int!) {\n  channel(xid: $channel_xid) {\n    id\n    ...CHANNEL_COMPLETE_FRAGMENT\n    channel_videos_all_videos: videos(sort: $sort, page: $page, first: mypagelimit) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      edges {\n        node {\n          id\n          ...VIDEO_FRAGMENT\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	h5QaxwPF7SOu6fMBTGXRU2yn = h5QaxwPF7SOu6fMBTGXRU2yn.replace('mychannelid',cyRC5wYOFEPj9T)
	h5QaxwPF7SOu6fMBTGXRU2yn = h5QaxwPF7SOu6fMBTGXRU2yn.replace('mypagelimit','40')
	h5QaxwPF7SOu6fMBTGXRU2yn = h5QaxwPF7SOu6fMBTGXRU2yn.replace('mypagenumber',z3z9QgENFk5eMYB4)
	h5QaxwPF7SOu6fMBTGXRU2yn = h5QaxwPF7SOu6fMBTGXRU2yn.replace('mysortmethod',sort)
	MK6ZT2zjC1SbmveNFqor = OSYhRAPzwE3o9(h5QaxwPF7SOu6fMBTGXRU2yn)
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"channel_videos_all_videos"(.*?)"VideoConnection"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('"node".*?"xid":"(.*?)".*?"title":"(.*?)".*?"duration":(.*?),.*?"name":"(.*?)".*?"displayName":"(.*?)".*?"thumbURLx240":"(.*?)"',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for id,title,LEb1HQDAeFdsrNTnVgmXo9,mgcEXNFSCihQ,cc65AJFLqWMQBVls3UvegRHGb9,IcWzVO137wFvemn2QTq8yKs9 in items:
			if '"' in id: id = id.replace('"','')
			if '"' in title: title = title.replace('"','')
			if '"' in IcWzVO137wFvemn2QTq8yKs9: IcWzVO137wFvemn2QTq8yKs9 = IcWzVO137wFvemn2QTq8yKs9.replace('"','')
			if '"' in LEb1HQDAeFdsrNTnVgmXo9: LEb1HQDAeFdsrNTnVgmXo9 = LEb1HQDAeFdsrNTnVgmXo9.replace('"','')
			if '"' in mgcEXNFSCihQ: mgcEXNFSCihQ = mgcEXNFSCihQ.replace('"','')
			if '"' in cc65AJFLqWMQBVls3UvegRHGb9: cc65AJFLqWMQBVls3UvegRHGb9 = cc65AJFLqWMQBVls3UvegRHGb9.replace('"','')
			BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU+'/video/'+id
			title = gImzaniMWhu8J(title)
			eMw2JCRLdZVYbjrtOTGEBK7FyD0N5c = mgcEXNFSCihQ+'::'+cc65AJFLqWMQBVls3UvegRHGb9
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,403,IcWzVO137wFvemn2QTq8yKs9,LEb1HQDAeFdsrNTnVgmXo9,eMw2JCRLdZVYbjrtOTGEBK7FyD0N5c)
		if '"hasNextPage":true' in MK6ZT2zjC1SbmveNFqor:
			z3z9QgENFk5eMYB4 = str(int(z3z9QgENFk5eMYB4)+1)
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'صفحة '+z3z9QgENFk5eMYB4,url,408,'',z3z9QgENFk5eMYB4)
	return
def tzFjTchElySPfsrZp4(url,z3z9QgENFk5eMYB4=''):
	if z3z9QgENFk5eMYB4=='': z3z9QgENFk5eMYB4 = '1'
	cyRC5wYOFEPj9T = url.split('/')[-2]
	if 'sort=' in url: sort = url.split('sort=')[1].split('&')[0]
	else: sort = 'recent'
	h5QaxwPF7SOu6fMBTGXRU2yn = '{"operationName":"CHANNEL_COLLECTIONS_QUERY","variables":{"channel_xid":"mychannelid","sort":"mysortmethod","page":mypagenumber},"query":"fragment CHANNEL_BASE_FRAGMENT on Channel {\n  id\n  xid\n  name\n  displayName\n  isArtist\n  logoURL(size: \"x60\")\n  isFollowed\n  accountType\n  __typename\n}\n\nfragment CHANNEL_IMAGES_FRAGMENT on Channel {\n  id\n  coverURLx375: coverURL(size: \"x375\")\n  __typename\n}\n\nfragment CHANNEL_UPDATED_FRAGMENT on Channel {\n  id\n  isFollowed\n  stats {\n    views {\n      total\n      __typename\n    }\n    followers {\n      total\n      __typename\n    }\n    videos {\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nfragment CHANNEL_COMPLETE_FRAGMENT on Channel {\n  id\n  ...CHANNEL_BASE_FRAGMENT\n  ...CHANNEL_IMAGES_FRAGMENT\n  ...CHANNEL_UPDATED_FRAGMENT\n  description\n  coverURL1024x: coverURL(size: \"1024x\")\n  coverURL1920x: coverURL(size: \"1920x\")\n  externalLinks {\n    facebookURL\n    twitterURL\n    websiteURL\n    instagramURL\n    __typename\n  }\n  __typename\n}\n\nfragment CHANNEL_FRAGMENT on Channel {\n  accountType\n  id\n  xid\n  name\n  displayName\n  isArtist\n  logoURL(size: \"x60\")\n  coverURLx375: coverURL(size: \"x375\")\n  isFollowed\n  stats {\n    views {\n      total\n      __typename\n    }\n    followers {\n      total\n      __typename\n    }\n    videos {\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nquery CHANNEL_COLLECTIONS_QUERY($channel_xid: String!, $sort: String, $page: Int!) {\n  channel(xid: $channel_xid) {\n    id\n    ...CHANNEL_COMPLETE_FRAGMENT\n    channel_playlist_collections: collections(sort: $sort, page: $page, first: mypagelimit) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      edges {\n        node {\n          id\n          xid\n          updatedAt\n          name\n          description\n          thumbURLx240: thumbnailURL(size: \"x240\")\n          thumbURLx360: thumbnailURL(size: \"x360\")\n          thumbURLx480: thumbnailURL(size: \"x480\")\n          stats {\n            videos {\n              total\n              __typename\n            }\n            __typename\n          }\n          channel {\n            id\n            ...CHANNEL_FRAGMENT\n            __typename\n          }\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	h5QaxwPF7SOu6fMBTGXRU2yn = h5QaxwPF7SOu6fMBTGXRU2yn.replace('mychannelid',cyRC5wYOFEPj9T)
	h5QaxwPF7SOu6fMBTGXRU2yn = h5QaxwPF7SOu6fMBTGXRU2yn.replace('mypagelimit','40')
	h5QaxwPF7SOu6fMBTGXRU2yn = h5QaxwPF7SOu6fMBTGXRU2yn.replace('mypagenumber',z3z9QgENFk5eMYB4)
	h5QaxwPF7SOu6fMBTGXRU2yn = h5QaxwPF7SOu6fMBTGXRU2yn.replace('mysortmethod',sort)
	MK6ZT2zjC1SbmveNFqor = OSYhRAPzwE3o9(h5QaxwPF7SOu6fMBTGXRU2yn)
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"channel_playlist_collections"(.*?)"CollectionConnection"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('"node".*?"xid":"(.*?)".*?"name":"(.*?)".*?"thumbURLx240":"(.*?)".*?"total":(.*?),.*?"xid":"(.*?)".*?"name":"(.*?)".*?"displayName":"(.*?)"',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for id,name,IcWzVO137wFvemn2QTq8yKs9,count,mZ7eF8QKqri6T2pVOSDX1YNg,mgcEXNFSCihQ,cc65AJFLqWMQBVls3UvegRHGb9 in items:
			if '"' in id: id = id.replace('"','')
			if '"' in name: name = name.replace('"','')
			if '"' in IcWzVO137wFvemn2QTq8yKs9: IcWzVO137wFvemn2QTq8yKs9 = IcWzVO137wFvemn2QTq8yKs9.replace('"','')
			if '"' in count: count = count.replace('"','')
			if '"' in mZ7eF8QKqri6T2pVOSDX1YNg: mZ7eF8QKqri6T2pVOSDX1YNg = mZ7eF8QKqri6T2pVOSDX1YNg.replace('"','')
			if '"' in mgcEXNFSCihQ: mgcEXNFSCihQ = mgcEXNFSCihQ.replace('"','')
			if '"' in cc65AJFLqWMQBVls3UvegRHGb9: cc65AJFLqWMQBVls3UvegRHGb9 = cc65AJFLqWMQBVls3UvegRHGb9.replace('"','')
			BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU+'/playlist/'+id
			title = 'LIST'+count+':  '+name
			title = gImzaniMWhu8J(title)
			eMw2JCRLdZVYbjrtOTGEBK7FyD0N5c = mgcEXNFSCihQ+'::'+cc65AJFLqWMQBVls3UvegRHGb9
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,401,IcWzVO137wFvemn2QTq8yKs9,'',eMw2JCRLdZVYbjrtOTGEBK7FyD0N5c)
		if '"hasNextPage":true' in MK6ZT2zjC1SbmveNFqor:
			z3z9QgENFk5eMYB4 = str(int(z3z9QgENFk5eMYB4)+1)
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'صفحة '+z3z9QgENFk5eMYB4,url,407,'',z3z9QgENFk5eMYB4)
	return
def QbNMPn7KJWifIDUcavq1jLXFu(url,FgtKokRNcC2vaq4):
	cyRC5wYOFEPj9T = url.split('/')[3]
	h5QaxwPF7SOu6fMBTGXRU2yn = '{"operationName":"CHANNEL_QUERY_DESKTOP","variables":{"channel_name":"mychannelid","relatedChannels":100},"query":"fragment CHANNEL_FRAGMENT on Channel {\n  accountType\n  id\n  xid\n  name\n  displayName\n  isArtist\n  logoURL(size: \"x60\")\n  coverURLx375: coverURL(size: \"x375\")\n  isFollowed\n  stats {\n    id\n    views {\n      id\n      total\n      __typename\n    }\n    followers {\n      id\n      total\n      __typename\n    }\n    videos {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nfragment LIVE_FRAGMENT on Live {\n  id\n  xid\n  title\n  startAt\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx360: thumbnailURL(size: \"x360\")\n  thumbnailx480: thumbnailURL(size: \"x480\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  channel {\n    id\n    ...CHANNEL_FRAGMENT\n    __typename\n  }\n  __typename\n}\n\nfragment VIDEO_FRAGMENT on Video {\n  id\n  xid\n  title\n  viewCount\n  duration\n  createdAt\n  isInWatchLater\n  channel {\n    id\n    ...CHANNEL_FRAGMENT\n    __typename\n  }\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx360: thumbnailURL(size: \"x360\")\n  thumbnailx480: thumbnailURL(size: \"x480\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  __typename\n}\n\nfragment CHANNEL_MAIN_FRAGMENT on Channel {\n  id\n  xid\n  name\n  displayName\n  description\n  accountType\n  isArtist\n  logoURL(size: \"x60\")\n  coverURL1024x: coverURL(size: \"1024x\")\n  coverURL1920x: coverURL(size: \"1920x\")\n  isFollowed\n  tagline\n  country {\n    id\n    codeAlpha2\n    __typename\n  }\n  stats {\n    id\n    views {\n      id\n      total\n      __typename\n    }\n    followers {\n      id\n      total\n      __typename\n    }\n    videos {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  externalLinks {\n    id\n    facebookURL\n    twitterURL\n    websiteURL\n    instagramURL\n    pinterestURL\n    __typename\n  }\n  channel_lives_now: lives(first: 4, isOnAir: true) {\n    edges {\n      node {\n        id\n        ...LIVE_FRAGMENT\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  channel_lives_scheduled: lives(first: 4, startIn: 7200) {\n    edges {\n      node {\n        id\n        ...LIVE_FRAGMENT\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  channel_featured_videos: videos(first: 4, isFeatured: true) {\n    edges {\n      node {\n        id\n        ...VIDEO_FRAGMENT\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  channel_all_videos: videos(first: 4) {\n    edges {\n      node {\n        id\n        ...VIDEO_FRAGMENT\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  channel_most_viewed: videos(first: 4, sort: \"visited\") {\n    edges {\n      node {\n        id\n        ...VIDEO_FRAGMENT\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  channel_collections: collections(first: 4) {\n    edges {\n      node {\n        id\n        xid\n        name\n        description\n        stats {\n          id\n          videos {\n            id\n            total\n            __typename\n          }\n          __typename\n        }\n        thumbnailx240: thumbnailURL(size: \"x240\")\n        thumbnailx360: thumbnailURL(size: \"x360\")\n        thumbnailx480: thumbnailURL(size: \"x480\")\n        channel {\n          id\n          ...CHANNEL_FRAGMENT\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  channel_related_channel: networkChannels(\n    hasPublicVideos: true\n    first: $relatedChannels\n  ) {\n    edges {\n      node {\n        id\n        ...CHANNEL_FRAGMENT\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nquery CHANNEL_QUERY_DESKTOP($channel_name: String!, $relatedChannels: Int) {\n  channel(name: $channel_name) {\n    id\n    ...CHANNEL_MAIN_FRAGMENT\n    __typename\n  }\n}\n"}'
	h5QaxwPF7SOu6fMBTGXRU2yn = h5QaxwPF7SOu6fMBTGXRU2yn.replace('mychannelid',cyRC5wYOFEPj9T)
	MK6ZT2zjC1SbmveNFqor = OSYhRAPzwE3o9(h5QaxwPF7SOu6fMBTGXRU2yn)
	import json as C56R029JKDm
	a0bVsG92iWyzdAqvcwPETL = C56R029JKDm.loads(MK6ZT2zjC1SbmveNFqor)
	try: items = a0bVsG92iWyzdAqvcwPETL['data']['channel'][FgtKokRNcC2vaq4]['edges']
	except: items = []
	if not items: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link',teUPLFC3B8bArakwHVGsdhoIWDM49f+'لا توجد نتائج','',9999)
	else:
		for ZA1fBenNahOR3xrkjvwYSVMy6JK5s in items:
			it6ATP1zuNm = ZA1fBenNahOR3xrkjvwYSVMy6JK5s['node']
			etMoY2HKSwjrdb5IV = it6ATP1zuNm['xid']
			keys = list(it6ATP1zuNm.keys())
			sCDK2RtgOLX4axWkm = it6ATP1zuNm['__typename'].lower()
			if sCDK2RtgOLX4axWkm=='channel':
				name = it6ATP1zuNm['name']
				uyk4Kecd8G3xpYXW2PHibM = it6ATP1zuNm['displayName']
				title = 'CHNL:  '+uyk4Kecd8G3xpYXW2PHibM
				IcWzVO137wFvemn2QTq8yKs9 = it6ATP1zuNm['coverURLx375']
			else:
				name = it6ATP1zuNm['channel']['name']
				uyk4Kecd8G3xpYXW2PHibM = it6ATP1zuNm['channel']['displayName']
				title = it6ATP1zuNm['title']
				IcWzVO137wFvemn2QTq8yKs9 = it6ATP1zuNm['thumbnailx360']
				if sCDK2RtgOLX4axWkm=='live': title = 'LIVE:  '+title
			title = gImzaniMWhu8J(title)
			eMw2JCRLdZVYbjrtOTGEBK7FyD0N5c = name+'::'+uyk4Kecd8G3xpYXW2PHibM
			if V8fmEML1b0PeaRZySnzh3H5J9:
				title = title.encode('utf8')
				eMw2JCRLdZVYbjrtOTGEBK7FyD0N5c = eMw2JCRLdZVYbjrtOTGEBK7FyD0N5c.encode('utf8')
			if sCDK2RtgOLX4axWkm=='channel':
				BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU+'/'+etMoY2HKSwjrdb5IV
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,402,IcWzVO137wFvemn2QTq8yKs9,'',eMw2JCRLdZVYbjrtOTGEBK7FyD0N5c)
			else:
				if sCDK2RtgOLX4axWkm=='video': LEb1HQDAeFdsrNTnVgmXo9 = str(it6ATP1zuNm['duration'])
				else: LEb1HQDAeFdsrNTnVgmXo9 = ''
				BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU+'/video/'+etMoY2HKSwjrdb5IV
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX(sCDK2RtgOLX4axWkm,teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,403,IcWzVO137wFvemn2QTq8yKs9,LEb1HQDAeFdsrNTnVgmXo9,eMw2JCRLdZVYbjrtOTGEBK7FyD0N5c)
	return
def OSYhRAPzwE3o9(h5QaxwPF7SOu6fMBTGXRU2yn):
	h5QaxwPF7SOu6fMBTGXRU2yn = h5QaxwPF7SOu6fMBTGXRU2yn.replace(' \"',' \\"')
	h5QaxwPF7SOu6fMBTGXRU2yn = h5QaxwPF7SOu6fMBTGXRU2yn.replace('\", ','\\", ')
	h5QaxwPF7SOu6fMBTGXRU2yn = h5QaxwPF7SOu6fMBTGXRU2yn.replace('\n','\\n')
	h5QaxwPF7SOu6fMBTGXRU2yn = h5QaxwPF7SOu6fMBTGXRU2yn.replace('")','\\")')
	fog5ASHc6QJY7 = VlQH3vRDo1kf0mFNCMBEbzGJ()
	headers = {"Authorization":fog5ASHc6QJY7,"Origin":EZxQp1WOldMTvFU}
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(f9Oum6c0FotxYn,'POST',oHxnAT1DzYQv,h5QaxwPF7SOu6fMBTGXRU2yn,headers,'','','DAILYMOTION-GET_PAGEDATA-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	return MK6ZT2zjC1SbmveNFqor
def VlQH3vRDo1kf0mFNCMBEbzGJ():
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(f9Oum6c0FotxYn,'GET',EZxQp1WOldMTvFU,'','','','','DAILYMOTION-GET_AUTHINTICATION-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	aZUyFnOCzk4BDMlp6eEm1L7h9bjwg = My7Dwqvs6bfGNSIgX.findall('var r="(.*?)",o="(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	NNbAGhpsWftdl9C2ZqOK4MSLgIJ,VCPfnWvISoN = aZUyFnOCzk4BDMlp6eEm1L7h9bjwg[-1]
	KFBXNzSDui42bg = 'https://graphql.api.dailymotion.com/oauth/token'
	HWuK7SrEhDMyjF6Vf = 'client_credentials'
	data = {'client_id':NNbAGhpsWftdl9C2ZqOK4MSLgIJ,'client_secret':VCPfnWvISoN,'grant_type':HWuK7SrEhDMyjF6Vf}
	headers = {'Content-Type':'application/x-www-form-urlencoded'}
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(f9Oum6c0FotxYn,'POST',KFBXNzSDui42bg,data,headers,'','','DAILYMOTION-GET_AUTHINTICATION-2nd')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	aZUyFnOCzk4BDMlp6eEm1L7h9bjwg = My7Dwqvs6bfGNSIgX.findall('"access_token": *"(.*?)".*?"token_type": *"(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	KvdfaC2Awsn0WyzLRep9Bl1T,e6am90XLud = aZUyFnOCzk4BDMlp6eEm1L7h9bjwg[0]
	fog5ASHc6QJY7 = e6am90XLud+" "+KvdfaC2Awsn0WyzLRep9Bl1T
	return fog5ASHc6QJY7
def HjZcUIVAXFCqy9TfBWKtgY2(search,type=''):
	search,LQf3AeozSrai,showDialogs = X54MLovbG8nAEkB9J(search)
	if not type and showDialogs:
		D6j1Q2Ox09W3oRaNTivecM = ['بحث عن فيديوهات','بحث عن آخر الفيديوهات','بحث عن الفيديوهات الاكثر مشاهدة','(جيد للمسلسلات) بحث عن قوائم تشغيل','بحث عن قنوات','بحث عن مواضيع','بحث عن بث حي']
		GOtNfU3xQFkEhPouwA = CnKwdteDG5BE8MTRhUpYIJm3NLrSgq('موقع ديلي موشن - اختر البحث',D6j1Q2Ox09W3oRaNTivecM)
		if GOtNfU3xQFkEhPouwA==-1: return
		elif GOtNfU3xQFkEhPouwA==0: type = 'videos?sortBy='
		elif GOtNfU3xQFkEhPouwA==1: type = 'videos?sortBy=RECENT'
		elif GOtNfU3xQFkEhPouwA==2: type = 'videos?sortBy=VIEW_COUNT'
		elif GOtNfU3xQFkEhPouwA==3: type = 'playlists'
		elif GOtNfU3xQFkEhPouwA==4: type = 'channels'
		elif GOtNfU3xQFkEhPouwA==5: type = 'topics'
		elif GOtNfU3xQFkEhPouwA==6: type = 'lives'
	elif '_DAILYMOTION-VIDEOS_' in LQf3AeozSrai: type = 'videos?sortBy='
	elif '_DAILYMOTION-PLAYLISTS_' in LQf3AeozSrai: type = 'playlists'
	elif '_DAILYMOTION-CHANNELS_' in LQf3AeozSrai: type = 'channels'
	elif '_DAILYMOTION-TOPICS_' in LQf3AeozSrai: type = 'topics'
	elif '_DAILYMOTION-LIVES_' in LQf3AeozSrai: type = 'lives'
	if not search:
		search = ViKAIsLurq83RSENayxWb()
		if not search: return
	if BLz7m2RkNrxXQwy1cGAp: search = search.encode('utf8').decode('raw_unicode_escape')
	if 'videos' in type: BaMWl5Ok0GegsIq(search+'/'+type)
	elif 'playlists' in type: APBvkDuV4Uo0d(search)
	elif 'channels' in type: NFW240C675SUvbZX1DJVcHQalygRO(search)
	elif 'topics' in type: adJCuz9rn5Xvhm2ysLlIN(search)
	elif 'lives' in type: wwn4VTBcLFh0sNftUEHpg(search)
	return
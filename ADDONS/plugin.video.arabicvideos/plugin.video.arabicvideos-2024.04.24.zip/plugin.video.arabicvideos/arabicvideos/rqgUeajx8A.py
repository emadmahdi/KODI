# -*- coding: utf-8 -*-
from G6AHskJeqN import *
from PIL import ImageDraw as UPTJpd3eoxqc6DgQ8X5bCu2IARm,ImageFont as zNnYrJKZ9PRt68BTmfhpwCoixu2d,Image as om54gkLrHi6DqAQ0M
from arabic_reshaper import ArabicReshaper as yAQdIO8psN2zSqX1KFW5BL
DaZhLqOIc24x6wv57YUlF3NgCzpGeX = 'EXCLUDES'
def aFGbsnwC9406LZv8QHDhtcj1ATozi(bSxczpUtHewVDKa3EL4lm,QvYmunyI2p1M):
	QvYmunyI2p1M = QvYmunyI2p1M.replace('[COLOR FFC89008]','').replace(' [/COLOR]','')[1:]
	tNOlYJhVv8XUFiGHrdLCeas3EBy0 = My7Dwqvs6bfGNSIgX.findall('[a-zA-Z]',bSxczpUtHewVDKa3EL4lm,My7Dwqvs6bfGNSIgX.DOTALL)
	if 'بحث IPTV - ' in bSxczpUtHewVDKa3EL4lm: bSxczpUtHewVDKa3EL4lm = bSxczpUtHewVDKa3EL4lm.replace('بحث IPTV - ',rcek0gbPZ6lmJwSaTNso+'بحث IPTV - '+rcek0gbPZ6lmJwSaTNso)
	elif ' IPTV' in bSxczpUtHewVDKa3EL4lm and QvYmunyI2p1M=='IPT': bSxczpUtHewVDKa3EL4lm = rcek0gbPZ6lmJwSaTNso+bSxczpUtHewVDKa3EL4lm
	elif 'بحث M3U - ' in bSxczpUtHewVDKa3EL4lm: bSxczpUtHewVDKa3EL4lm = bSxczpUtHewVDKa3EL4lm.replace('بحث M3U - ',rcek0gbPZ6lmJwSaTNso+'بحث M3U - '+rcek0gbPZ6lmJwSaTNso)
	elif ' M3U' in bSxczpUtHewVDKa3EL4lm and QvYmunyI2p1M=='M3U': bSxczpUtHewVDKa3EL4lm = rcek0gbPZ6lmJwSaTNso+bSxczpUtHewVDKa3EL4lm
	elif 'بحث ' in bSxczpUtHewVDKa3EL4lm and ' - ' in bSxczpUtHewVDKa3EL4lm: bSxczpUtHewVDKa3EL4lm = rcek0gbPZ6lmJwSaTNso+bSxczpUtHewVDKa3EL4lm
	elif not tNOlYJhVv8XUFiGHrdLCeas3EBy0:
		vKeFYUbxhDdN1pa3jRZnJ = My7Dwqvs6bfGNSIgX.findall('^( *?)(.*?)( *?)$',bSxczpUtHewVDKa3EL4lm)
		ArLM3zWEGF7fdb4tluVXh06,Wr9ktfaIzFplhqgoJ1R03Qe,loTmGicWdvYxJ = vKeFYUbxhDdN1pa3jRZnJ[0]
		reuEmZAoLRYQjXxWt = My7Dwqvs6bfGNSIgX.findall('^([!-~])',Wr9ktfaIzFplhqgoJ1R03Qe)
		if reuEmZAoLRYQjXxWt: bSxczpUtHewVDKa3EL4lm = ArLM3zWEGF7fdb4tluVXh06+u8c5pQm3iRwvxESj7PUrO+Wr9ktfaIzFplhqgoJ1R03Qe+loTmGicWdvYxJ
		else: bSxczpUtHewVDKa3EL4lm = loTmGicWdvYxJ+rcek0gbPZ6lmJwSaTNso+Wr9ktfaIzFplhqgoJ1R03Qe+ArLM3zWEGF7fdb4tluVXh06
	else:
		if 1:
			IlWBbhqM6gdytsNL = bSxczpUtHewVDKa3EL4lm
			OpkVZ5fMAXlNzmYB6ye9aI3gHs = mFS3RqXrOoUsMcx5GD0jKfI.get_display(bSxczpUtHewVDKa3EL4lm,base_dir='L')
			if V8fmEML1b0PeaRZySnzh3H5J9: IlWBbhqM6gdytsNL = IlWBbhqM6gdytsNL.decode('utf8')
			if V8fmEML1b0PeaRZySnzh3H5J9: OpkVZ5fMAXlNzmYB6ye9aI3gHs = OpkVZ5fMAXlNzmYB6ye9aI3gHs.decode('utf8')
			QlBnZ6vpesSFO5zMHdGuDy = IlWBbhqM6gdytsNL.split(' ')
			Fj7nksz5Jy2PHGqI6bf = OpkVZ5fMAXlNzmYB6ye9aI3gHs.split(' ')
			FYwk8L9Rs1myN3ZjnzuiJ,jSbaTcHC4BWenLKGz9xXIwiNksJu,ZvJrdXDsQN6OwfaV9AWt7UEgRk,i73LIKSv4EVky5MeqD2 = [],[],'',''
			EpbrlWCht3DsvJKi2LneNoP = zip(QlBnZ6vpesSFO5zMHdGuDy,Fj7nksz5Jy2PHGqI6bf)
			for DcXlkz8gw0SCQ94fENx,yIxcbfRoned7Ka2itA in EpbrlWCht3DsvJKi2LneNoP:
				if DcXlkz8gw0SCQ94fENx==yIxcbfRoned7Ka2itA=='' and i73LIKSv4EVky5MeqD2:
					ZvJrdXDsQN6OwfaV9AWt7UEgRk += ' '
					continue
				if DcXlkz8gw0SCQ94fENx==yIxcbfRoned7Ka2itA:
					DPajMzNlqJyhY7gGrbXAtIV1oZHdw = 'EN'
					if i73LIKSv4EVky5MeqD2==DPajMzNlqJyhY7gGrbXAtIV1oZHdw: ZvJrdXDsQN6OwfaV9AWt7UEgRk += ' '+DcXlkz8gw0SCQ94fENx
					elif DcXlkz8gw0SCQ94fENx:
						if ZvJrdXDsQN6OwfaV9AWt7UEgRk:
							jSbaTcHC4BWenLKGz9xXIwiNksJu.append(ZvJrdXDsQN6OwfaV9AWt7UEgRk)
							FYwk8L9Rs1myN3ZjnzuiJ.append('')
						ZvJrdXDsQN6OwfaV9AWt7UEgRk = DcXlkz8gw0SCQ94fENx
				else:
					DPajMzNlqJyhY7gGrbXAtIV1oZHdw = 'AR'
					if i73LIKSv4EVky5MeqD2==DPajMzNlqJyhY7gGrbXAtIV1oZHdw: ZvJrdXDsQN6OwfaV9AWt7UEgRk += ' '+DcXlkz8gw0SCQ94fENx
					elif DcXlkz8gw0SCQ94fENx:
						if ZvJrdXDsQN6OwfaV9AWt7UEgRk:
							FYwk8L9Rs1myN3ZjnzuiJ.append(ZvJrdXDsQN6OwfaV9AWt7UEgRk)
							jSbaTcHC4BWenLKGz9xXIwiNksJu.append('')
						ZvJrdXDsQN6OwfaV9AWt7UEgRk = DcXlkz8gw0SCQ94fENx
				i73LIKSv4EVky5MeqD2 = DPajMzNlqJyhY7gGrbXAtIV1oZHdw
			if DPajMzNlqJyhY7gGrbXAtIV1oZHdw=='EN':
				FYwk8L9Rs1myN3ZjnzuiJ.append(ZvJrdXDsQN6OwfaV9AWt7UEgRk)
				jSbaTcHC4BWenLKGz9xXIwiNksJu.append('')
			else:
				jSbaTcHC4BWenLKGz9xXIwiNksJu.append(ZvJrdXDsQN6OwfaV9AWt7UEgRk)
				FYwk8L9Rs1myN3ZjnzuiJ.append('')
			z9zESDOlcn0T = ''
			EpbrlWCht3DsvJKi2LneNoP = zip(FYwk8L9Rs1myN3ZjnzuiJ,jSbaTcHC4BWenLKGz9xXIwiNksJu)
			for D3gch2mfLoRNpVE,Rh7DXQWTAvEuqOZ2Lpoxz3lgYi in EpbrlWCht3DsvJKi2LneNoP:
				if D3gch2mfLoRNpVE: z9zESDOlcn0T += ' '+D3gch2mfLoRNpVE
				else:
					reuEmZAoLRYQjXxWt = My7Dwqvs6bfGNSIgX.findall('([!-~]) *$',Rh7DXQWTAvEuqOZ2Lpoxz3lgYi)
					if reuEmZAoLRYQjXxWt:
						reuEmZAoLRYQjXxWt = reuEmZAoLRYQjXxWt[0]
						try:
							cD7E0wFRdeyHaCjunOr6AGh9 = V5ao9FGwjP1QpBndcTmHNXt.MIRRORED[reuEmZAoLRYQjXxWt]
							vKeFYUbxhDdN1pa3jRZnJ = My7Dwqvs6bfGNSIgX.findall('^( *?)(.*?)( *?)$',Rh7DXQWTAvEuqOZ2Lpoxz3lgYi)
							if vKeFYUbxhDdN1pa3jRZnJ: ArLM3zWEGF7fdb4tluVXh06,Rh7DXQWTAvEuqOZ2Lpoxz3lgYi,loTmGicWdvYxJ = vKeFYUbxhDdN1pa3jRZnJ[0]
							Rh7DXQWTAvEuqOZ2Lpoxz3lgYi = ArLM3zWEGF7fdb4tluVXh06+cD7E0wFRdeyHaCjunOr6AGh9+Rh7DXQWTAvEuqOZ2Lpoxz3lgYi[:-1]+loTmGicWdvYxJ
						except: pass
					z9zESDOlcn0T += ' '+Rh7DXQWTAvEuqOZ2Lpoxz3lgYi
			bSxczpUtHewVDKa3EL4lm = z9zESDOlcn0T[1:]
			if V8fmEML1b0PeaRZySnzh3H5J9: bSxczpUtHewVDKa3EL4lm = bSxczpUtHewVDKa3EL4lm.encode('utf8')
		else:
			if V8fmEML1b0PeaRZySnzh3H5J9: bSxczpUtHewVDKa3EL4lm = bSxczpUtHewVDKa3EL4lm.decode('utf8')
			bSxczpUtHewVDKa3EL4lm = mFS3RqXrOoUsMcx5GD0jKfI.get_display(bSxczpUtHewVDKa3EL4lm)
			IlWBbhqM6gdytsNL,OpkVZ5fMAXlNzmYB6ye9aI3gHs = bSxczpUtHewVDKa3EL4lm,bSxczpUtHewVDKa3EL4lm
			if 1:
				i73LIKSv4EVky5MeqD2,ZUJlbNABu23Sx1QW5dnPehGLv = '',[]
				t7Q2MdGvkFD68 = bSxczpUtHewVDKa3EL4lm.split(' ')
				for Df0mXPEObavl6jzCyxp in t7Q2MdGvkFD68:
					if not Df0mXPEObavl6jzCyxp:
						if ZUJlbNABu23Sx1QW5dnPehGLv: ZUJlbNABu23Sx1QW5dnPehGLv[-1] += ' '
						else: ZUJlbNABu23Sx1QW5dnPehGLv.append('')
						continue
					fPeldZbHRMUv60GmXp = My7Dwqvs6bfGNSIgX.findall('[!-~]',Df0mXPEObavl6jzCyxp[0])
					if fPeldZbHRMUv60GmXp==i73LIKSv4EVky5MeqD2 and ZUJlbNABu23Sx1QW5dnPehGLv: ZUJlbNABu23Sx1QW5dnPehGLv[-1] += ' '+Df0mXPEObavl6jzCyxp
					else:
						if ZUJlbNABu23Sx1QW5dnPehGLv:
							tsQUbJMxwBZ2O7Xe0aFlmjhdH5k = My7Dwqvs6bfGNSIgX.findall('[^!-~]',ZUJlbNABu23Sx1QW5dnPehGLv[-1])
							if tsQUbJMxwBZ2O7Xe0aFlmjhdH5k:
								ZUJlbNABu23Sx1QW5dnPehGLv[-1] = mFS3RqXrOoUsMcx5GD0jKfI.get_display(ZUJlbNABu23Sx1QW5dnPehGLv[-1])
								WMNwYpyalVgE = My7Dwqvs6bfGNSIgX.findall('^ +',ZUJlbNABu23Sx1QW5dnPehGLv[-1])
								if WMNwYpyalVgE: ZUJlbNABu23Sx1QW5dnPehGLv[-1] = ZUJlbNABu23Sx1QW5dnPehGLv[-1].lstrip(' ')+WMNwYpyalVgE[0]
						ZUJlbNABu23Sx1QW5dnPehGLv.append(Df0mXPEObavl6jzCyxp)
					i73LIKSv4EVky5MeqD2 = fPeldZbHRMUv60GmXp
				if ZUJlbNABu23Sx1QW5dnPehGLv: ZUJlbNABu23Sx1QW5dnPehGLv[-1] = mFS3RqXrOoUsMcx5GD0jKfI.get_display(ZUJlbNABu23Sx1QW5dnPehGLv[-1])
				bSxczpUtHewVDKa3EL4lm = ' '.join(ZUJlbNABu23Sx1QW5dnPehGLv)
			if V8fmEML1b0PeaRZySnzh3H5J9: bSxczpUtHewVDKa3EL4lm = bSxczpUtHewVDKa3EL4lm.encode('utf8')
	return bSxczpUtHewVDKa3EL4lm
def xB3NS9bTCqO(SFVu351C6NLHgM7,AzdUPKpDGxE1sjIcMOoR78f2Q9,aYEzIedpxihB8otjJDPbS):
	dM2SkzwnVKc3FUPDl9BE,bSxczpUtHewVDKa3EL4lm,SCakygtHx0AUXbO3emswB9F8,H3HDqY5N4e0fWSXMikZ8CR7suUmJdx,MofmxtNlUaORA0K1uJv6S8g,eb1dHx054KGYmOQf3g,UwfRtv74eO0qnJh5H9KQkAYG,HMdmFA6wzOC0GEoa9rlt27biPn,InkN7SpoMudDGJ6K = SFVu351C6NLHgM7
	H3HDqY5N4e0fWSXMikZ8CR7suUmJdx = int(H3HDqY5N4e0fWSXMikZ8CR7suUmJdx)
	gg1ErNnLj7b9DkdRxlFqmJ0Q4XHh = My7Dwqvs6bfGNSIgX.findall('(_(\d\d\.\d\d)_(\d\d\:\d\d)_)',bSxczpUtHewVDKa3EL4lm,My7Dwqvs6bfGNSIgX.DOTALL)
	if gg1ErNnLj7b9DkdRxlFqmJ0Q4XHh:
		gg1ErNnLj7b9DkdRxlFqmJ0Q4XHh,X3XfTy89O2EqDls0nSpBedYjPMIkh,rP6vUnSXbLgE2m04B8RVeDYx = gg1ErNnLj7b9DkdRxlFqmJ0Q4XHh[0]
		bSxczpUtHewVDKa3EL4lm = bSxczpUtHewVDKa3EL4lm.replace(gg1ErNnLj7b9DkdRxlFqmJ0Q4XHh,'')
	FIQWPRLXlOV1xTY75sSBoC6npvi = bSxczpUtHewVDKa3EL4lm
	QvYmunyI2p1M = My7Dwqvs6bfGNSIgX.findall('^_(\w\w\w)_(.*?)$',bSxczpUtHewVDKa3EL4lm,My7Dwqvs6bfGNSIgX.DOTALL)
	if QvYmunyI2p1M:
		QvYmunyI2p1M,bSxczpUtHewVDKa3EL4lm = QvYmunyI2p1M[0]
		EVvTaGg7UeMyQBJnoIfSilY4N6j = '_MOD_' in bSxczpUtHewVDKa3EL4lm
		j4OBPfZchRSD1FI = dM2SkzwnVKc3FUPDl9BE=='folder'
		if EVvTaGg7UeMyQBJnoIfSilY4N6j and j4OBPfZchRSD1FI: hIfxLy01wqHeAcTkVDlE5jCFMPzGv = ';'
		elif EVvTaGg7UeMyQBJnoIfSilY4N6j and not j4OBPfZchRSD1FI: hIfxLy01wqHeAcTkVDlE5jCFMPzGv = OMFrsZopHK9m7w45bY01idRqBL
		elif not EVvTaGg7UeMyQBJnoIfSilY4N6j and j4OBPfZchRSD1FI: hIfxLy01wqHeAcTkVDlE5jCFMPzGv = ','
		elif not EVvTaGg7UeMyQBJnoIfSilY4N6j and not j4OBPfZchRSD1FI: hIfxLy01wqHeAcTkVDlE5jCFMPzGv = ' '
		bSxczpUtHewVDKa3EL4lm = bSxczpUtHewVDKa3EL4lm.replace('_MOD_','')
		QvYmunyI2p1M = hIfxLy01wqHeAcTkVDlE5jCFMPzGv+'[COLOR FFC89008]'+QvYmunyI2p1M+' [/COLOR]'
	else: QvYmunyI2p1M = ''
	if gg1ErNnLj7b9DkdRxlFqmJ0Q4XHh:
		if V8fmEML1b0PeaRZySnzh3H5J9:
			gg1ErNnLj7b9DkdRxlFqmJ0Q4XHh = '[COLOR FFFFFF00]'+X3XfTy89O2EqDls0nSpBedYjPMIkh+' '+rP6vUnSXbLgE2m04B8RVeDYx+'[/COLOR]'
			if QvYmunyI2p1M: bSxczpUtHewVDKa3EL4lm = gg1ErNnLj7b9DkdRxlFqmJ0Q4XHh+' '+rcek0gbPZ6lmJwSaTNso+QvYmunyI2p1M+bSxczpUtHewVDKa3EL4lm
			else: bSxczpUtHewVDKa3EL4lm = gg1ErNnLj7b9DkdRxlFqmJ0Q4XHh+rcek0gbPZ6lmJwSaTNso+bSxczpUtHewVDKa3EL4lm+' '
		elif BLz7m2RkNrxXQwy1cGAp:
			if QvYmunyI2p1M:
				gg1ErNnLj7b9DkdRxlFqmJ0Q4XHh = '[COLOR FFFFFF00]'+X3XfTy89O2EqDls0nSpBedYjPMIkh+' '+rP6vUnSXbLgE2m04B8RVeDYx+'[/COLOR]'
				bSxczpUtHewVDKa3EL4lm = gg1ErNnLj7b9DkdRxlFqmJ0Q4XHh+' '+QvYmunyI2p1M+bSxczpUtHewVDKa3EL4lm
			else:
				gg1ErNnLj7b9DkdRxlFqmJ0Q4XHh = '[COLOR FFFFFF00]'+rP6vUnSXbLgE2m04B8RVeDYx+' '+X3XfTy89O2EqDls0nSpBedYjPMIkh+'[/COLOR]'
				bSxczpUtHewVDKa3EL4lm = bSxczpUtHewVDKa3EL4lm+' '+rcek0gbPZ6lmJwSaTNso+gg1ErNnLj7b9DkdRxlFqmJ0Q4XHh
	elif QvYmunyI2p1M:
		bSxczpUtHewVDKa3EL4lm = aFGbsnwC9406LZv8QHDhtcj1ATozi(bSxczpUtHewVDKa3EL4lm,QvYmunyI2p1M)
		bSxczpUtHewVDKa3EL4lm = QvYmunyI2p1M+bSxczpUtHewVDKa3EL4lm
	SFVu351C6NLHgM7 = dM2SkzwnVKc3FUPDl9BE,FIQWPRLXlOV1xTY75sSBoC6npvi,SCakygtHx0AUXbO3emswB9F8,str(H3HDqY5N4e0fWSXMikZ8CR7suUmJdx),MofmxtNlUaORA0K1uJv6S8g,eb1dHx054KGYmOQf3g,UwfRtv74eO0qnJh5H9KQkAYG,HMdmFA6wzOC0GEoa9rlt27biPn,InkN7SpoMudDGJ6K
	WGAEcZQTHI2vnFuqMPadteU = {'type':'','mode':'','url':'','text':'','page':'','name':'','image':'','context':'','infodict':''}
	WGAEcZQTHI2vnFuqMPadteU['name'] = F8fMqZKB4APk(FIQWPRLXlOV1xTY75sSBoC6npvi)
	WGAEcZQTHI2vnFuqMPadteU['type'] = dM2SkzwnVKc3FUPDl9BE.strip(' ')
	WGAEcZQTHI2vnFuqMPadteU['mode'] = str(H3HDqY5N4e0fWSXMikZ8CR7suUmJdx).strip(' ')
	if dM2SkzwnVKc3FUPDl9BE=='folder' and eb1dHx054KGYmOQf3g: WGAEcZQTHI2vnFuqMPadteU['page'] = F8fMqZKB4APk(eb1dHx054KGYmOQf3g.strip(' '))
	if HMdmFA6wzOC0GEoa9rlt27biPn: WGAEcZQTHI2vnFuqMPadteU['context'] = HMdmFA6wzOC0GEoa9rlt27biPn.strip(' ')
	if UwfRtv74eO0qnJh5H9KQkAYG: WGAEcZQTHI2vnFuqMPadteU['text'] = F8fMqZKB4APk(UwfRtv74eO0qnJh5H9KQkAYG.strip(' '))
	if MofmxtNlUaORA0K1uJv6S8g: WGAEcZQTHI2vnFuqMPadteU['image'] = F8fMqZKB4APk(MofmxtNlUaORA0K1uJv6S8g.strip(' '))
	if InkN7SpoMudDGJ6K:
		InkN7SpoMudDGJ6K = str(InkN7SpoMudDGJ6K)
		WGAEcZQTHI2vnFuqMPadteU['infodict'] = F8fMqZKB4APk(InkN7SpoMudDGJ6K.strip(' '))
		InkN7SpoMudDGJ6K = eval(InkN7SpoMudDGJ6K)
	else: InkN7SpoMudDGJ6K = {}
	if SCakygtHx0AUXbO3emswB9F8: WGAEcZQTHI2vnFuqMPadteU['url'] = F8fMqZKB4APk(SCakygtHx0AUXbO3emswB9F8.strip(' '))
	Om3xJ8HAlP6TiDnpkMfC4jEhQotwr1 = {'name':'','context_menu':'','plot':'','stars':'','image':'','type':'','isFolder':'','newpath':'','duration':''}
	cUgXpKno8eG2Lih = []
	WgQxNTbK4jSIaFtv52Ei3n = 'plugin://'+Kczs71doMyLHwN+'/?type='+WGAEcZQTHI2vnFuqMPadteU['type']+'&mode='+WGAEcZQTHI2vnFuqMPadteU['mode']
	if WGAEcZQTHI2vnFuqMPadteU['page']: WgQxNTbK4jSIaFtv52Ei3n += '&page='+WGAEcZQTHI2vnFuqMPadteU['page']
	if WGAEcZQTHI2vnFuqMPadteU['name']: WgQxNTbK4jSIaFtv52Ei3n += '&name='+WGAEcZQTHI2vnFuqMPadteU['name']
	if WGAEcZQTHI2vnFuqMPadteU['text']: WgQxNTbK4jSIaFtv52Ei3n += '&text='+WGAEcZQTHI2vnFuqMPadteU['text']
	if WGAEcZQTHI2vnFuqMPadteU['infodict']: WgQxNTbK4jSIaFtv52Ei3n += '&infodict='+WGAEcZQTHI2vnFuqMPadteU['infodict']
	if WGAEcZQTHI2vnFuqMPadteU['image']: WgQxNTbK4jSIaFtv52Ei3n += '&image='+WGAEcZQTHI2vnFuqMPadteU['image']
	if WGAEcZQTHI2vnFuqMPadteU['url']: WgQxNTbK4jSIaFtv52Ei3n += '&url='+WGAEcZQTHI2vnFuqMPadteU['url']
	if H3HDqY5N4e0fWSXMikZ8CR7suUmJdx!=265: Om3xJ8HAlP6TiDnpkMfC4jEhQotwr1['favorites'] = True
	else: Om3xJ8HAlP6TiDnpkMfC4jEhQotwr1['favorites'] = False
	if WGAEcZQTHI2vnFuqMPadteU['context']: WgQxNTbK4jSIaFtv52Ei3n += '&context='+WGAEcZQTHI2vnFuqMPadteU['context']
	if H3HDqY5N4e0fWSXMikZ8CR7suUmJdx in [235,238] and dM2SkzwnVKc3FUPDl9BE=='live' and 'EPG' in HMdmFA6wzOC0GEoa9rlt27biPn:
		bbp1DQgnd9rwqYGISXlNH7cWv3 = 'plugin://'+Kczs71doMyLHwN+'?mode=238&text=SHORT_EPG&url='+SCakygtHx0AUXbO3emswB9F8
		gg9F1EkqMCmJx2ij3K = '[COLOR FFFFFF00]البرامج القادمة[/COLOR]'
		ZiYIXckh5FR6J3WOvUdGCN = (gg9F1EkqMCmJx2ij3K,'RunPlugin('+bbp1DQgnd9rwqYGISXlNH7cWv3+')')
		cUgXpKno8eG2Lih.append(ZiYIXckh5FR6J3WOvUdGCN)
	if H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==265:
		hhjauwSbpDy53z0Gc4HT = AzdUPKpDGxE1sjIcMOoR78f2Q9(UwfRtv74eO0qnJh5H9KQkAYG,True)
		if hhjauwSbpDy53z0Gc4HT>0:
			bbp1DQgnd9rwqYGISXlNH7cWv3 = 'plugin://'+Kczs71doMyLHwN+'?mode=266&text='+UwfRtv74eO0qnJh5H9KQkAYG
			gg9F1EkqMCmJx2ij3K = '[COLOR FFFFFF00]مسح قائمة آخر 50 '+nnYoO8rQaHmc57IA1MVSi(UwfRtv74eO0qnJh5H9KQkAYG)+'[/COLOR]'
			ZiYIXckh5FR6J3WOvUdGCN = (gg9F1EkqMCmJx2ij3K,'RunPlugin('+bbp1DQgnd9rwqYGISXlNH7cWv3+')')
			cUgXpKno8eG2Lih.append(ZiYIXckh5FR6J3WOvUdGCN)
	if dM2SkzwnVKc3FUPDl9BE=='video' and H3HDqY5N4e0fWSXMikZ8CR7suUmJdx!=331:
		bbp1DQgnd9rwqYGISXlNH7cWv3 = WgQxNTbK4jSIaFtv52Ei3n+'&context=6_DOWNLOAD'
		gg9F1EkqMCmJx2ij3K = '[COLOR FFFFFF00]تحميل ملف الفيديو[/COLOR]'
		ZiYIXckh5FR6J3WOvUdGCN = (gg9F1EkqMCmJx2ij3K,'RunPlugin('+bbp1DQgnd9rwqYGISXlNH7cWv3+')')
		cUgXpKno8eG2Lih.append(ZiYIXckh5FR6J3WOvUdGCN)
	if H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==331:
		bbp1DQgnd9rwqYGISXlNH7cWv3 = WgQxNTbK4jSIaFtv52Ei3n+'&context=6_DELETE'
		gg9F1EkqMCmJx2ij3K = '[COLOR FFFFFF00]حذف ملف الفيديو[/COLOR]'
		ZiYIXckh5FR6J3WOvUdGCN = (gg9F1EkqMCmJx2ij3K,'RunPlugin('+bbp1DQgnd9rwqYGISXlNH7cWv3+')')
		cUgXpKno8eG2Lih.append(ZiYIXckh5FR6J3WOvUdGCN)
	if dM2SkzwnVKc3FUPDl9BE=='folder' and H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==540:
		mmDeV3LrdI4NBJYcWOvSk9yhK = zPgNsqpJInt(RnqtMUa9Nh6peGEsBT,'list','GLOBALSEARCH_SITES')
		if mmDeV3LrdI4NBJYcWOvSk9yhK:
			bbp1DQgnd9rwqYGISXlNH7cWv3 = 'plugin://'+Kczs71doMyLHwN+'?context=7'
			gg9F1EkqMCmJx2ij3K = '[COLOR FFFFFF00]مسح جميع كلمات البحث[/COLOR]'
			ZiYIXckh5FR6J3WOvUdGCN = (gg9F1EkqMCmJx2ij3K,'RunPlugin('+bbp1DQgnd9rwqYGISXlNH7cWv3+')')
			cUgXpKno8eG2Lih.append(ZiYIXckh5FR6J3WOvUdGCN)
	gaAkhq1xs0wcfZ = [9990,2,7,100,151,159,176,196,199,230,239,260,261,262,263,264,265,267,270,290,330,341,346,348,501,505,510,540,710,719,761,762]
	if H3HDqY5N4e0fWSXMikZ8CR7suUmJdx not in gaAkhq1xs0wcfZ:
		bbp1DQgnd9rwqYGISXlNH7cWv3 = 'plugin://'+Kczs71doMyLHwN+'?context=8&mode=260'
		gg9F1EkqMCmJx2ij3K = '[COLOR FFFFFF00]القائمة الرئيسية[/COLOR]'
		ZiYIXckh5FR6J3WOvUdGCN = (gg9F1EkqMCmJx2ij3K,'RunPlugin('+bbp1DQgnd9rwqYGISXlNH7cWv3+')')
		cUgXpKno8eG2Lih.append(ZiYIXckh5FR6J3WOvUdGCN)
	OOESMxZKNdQ34qhcYzBDe6HkmrIwF = [0,150,160,170,190,260,280,330,340,410,500,520,530,560,760]
	if H3HDqY5N4e0fWSXMikZ8CR7suUmJdx%10 and H3HDqY5N4e0fWSXMikZ8CR7suUmJdx!=9990:
		HSfbGjm3oXZPJAyuRNvIOaEzD1T = H3HDqY5N4e0fWSXMikZ8CR7suUmJdx-H3HDqY5N4e0fWSXMikZ8CR7suUmJdx%10
		if HSfbGjm3oXZPJAyuRNvIOaEzD1T==280: HSfbGjm3oXZPJAyuRNvIOaEzD1T = 230
		if HSfbGjm3oXZPJAyuRNvIOaEzD1T==410: HSfbGjm3oXZPJAyuRNvIOaEzD1T = 400
		if HSfbGjm3oXZPJAyuRNvIOaEzD1T==520: HSfbGjm3oXZPJAyuRNvIOaEzD1T = 510
		if HSfbGjm3oXZPJAyuRNvIOaEzD1T not in OOESMxZKNdQ34qhcYzBDe6HkmrIwF:
			bbp1DQgnd9rwqYGISXlNH7cWv3 = 'plugin://'+Kczs71doMyLHwN+'?context=8&mode='+str(HSfbGjm3oXZPJAyuRNvIOaEzD1T)
			gg9F1EkqMCmJx2ij3K = '[COLOR FFFFFF00]قائمة الموقع[/COLOR]'
			ZiYIXckh5FR6J3WOvUdGCN = (gg9F1EkqMCmJx2ij3K,'RunPlugin('+bbp1DQgnd9rwqYGISXlNH7cWv3+')')
			cUgXpKno8eG2Lih.append(ZiYIXckh5FR6J3WOvUdGCN)
	bbp1DQgnd9rwqYGISXlNH7cWv3 = WgQxNTbK4jSIaFtv52Ei3n+'&context=9'
	gg9F1EkqMCmJx2ij3K = '[COLOR FFFFFF00]تحديث القائمة[/COLOR]'
	ZiYIXckh5FR6J3WOvUdGCN = (gg9F1EkqMCmJx2ij3K,'RunPlugin('+bbp1DQgnd9rwqYGISXlNH7cWv3+')')
	cUgXpKno8eG2Lih.append(ZiYIXckh5FR6J3WOvUdGCN)
	if dM2SkzwnVKc3FUPDl9BE in ['link','video','live']: RcPp0U34IohTNSfwjbvgxt8WDLuei = False
	elif dM2SkzwnVKc3FUPDl9BE=='folder': RcPp0U34IohTNSfwjbvgxt8WDLuei = True
	Om3xJ8HAlP6TiDnpkMfC4jEhQotwr1['name'] = bSxczpUtHewVDKa3EL4lm
	Om3xJ8HAlP6TiDnpkMfC4jEhQotwr1['context_menu'] = cUgXpKno8eG2Lih
	if 'plot' in list(InkN7SpoMudDGJ6K.keys()): Om3xJ8HAlP6TiDnpkMfC4jEhQotwr1['plot'] = InkN7SpoMudDGJ6K['plot']
	if 'stars' in list(InkN7SpoMudDGJ6K.keys()): Om3xJ8HAlP6TiDnpkMfC4jEhQotwr1['stars'] = InkN7SpoMudDGJ6K['stars']
	if MofmxtNlUaORA0K1uJv6S8g: Om3xJ8HAlP6TiDnpkMfC4jEhQotwr1['image'] = MofmxtNlUaORA0K1uJv6S8g
	if dM2SkzwnVKc3FUPDl9BE=='video' and eb1dHx054KGYmOQf3g:
		lqTyzjAbofHw1tiaFh7rO = My7Dwqvs6bfGNSIgX.findall('[\d:]+',eb1dHx054KGYmOQf3g,My7Dwqvs6bfGNSIgX.DOTALL)
		if lqTyzjAbofHw1tiaFh7rO:
			lqTyzjAbofHw1tiaFh7rO = '0:0:0:0:0:'+lqTyzjAbofHw1tiaFh7rO[0]
			GpRJb7qFgjW,k2i4Jp8ATmCNVD,IPB9dQakL12wrxGbJy3pZzfT,QSlgqvI8LhjJRxy,vKWiLVJGwZyoatm85dlOMY0PxhTjp = lqTyzjAbofHw1tiaFh7rO.rsplit(':',4)
			Malk1Vctjb82pfPFYr6 = int(k2i4Jp8ATmCNVD)*24*p6l2Pum7aFtrhUHgXTE5w0n+int(IPB9dQakL12wrxGbJy3pZzfT)*p6l2Pum7aFtrhUHgXTE5w0n+int(QSlgqvI8LhjJRxy)*60+int(vKWiLVJGwZyoatm85dlOMY0PxhTjp)
			Om3xJ8HAlP6TiDnpkMfC4jEhQotwr1['duration'] = Malk1Vctjb82pfPFYr6
	Om3xJ8HAlP6TiDnpkMfC4jEhQotwr1['type'] = dM2SkzwnVKc3FUPDl9BE
	Om3xJ8HAlP6TiDnpkMfC4jEhQotwr1['isFolder'] = RcPp0U34IohTNSfwjbvgxt8WDLuei
	Om3xJ8HAlP6TiDnpkMfC4jEhQotwr1['newpath'] = WgQxNTbK4jSIaFtv52Ei3n
	Om3xJ8HAlP6TiDnpkMfC4jEhQotwr1['menuItem'] = SFVu351C6NLHgM7
	Om3xJ8HAlP6TiDnpkMfC4jEhQotwr1['mode'] = H3HDqY5N4e0fWSXMikZ8CR7suUmJdx
	return Om3xJ8HAlP6TiDnpkMfC4jEhQotwr1
def nUA4GswYhy(AzdUPKpDGxE1sjIcMOoR78f2Q9):
	yyuwkfvhPiIFtZqES = []
	from wfQhx1AiCD import U74i5rCBLYbymIQFOV,nvlhoJtjfRTSMANVO1HDCBcgPxI
	aYEzIedpxihB8otjJDPbS = U74i5rCBLYbymIQFOV()
	for SFVu351C6NLHgM7 in xx4viQhaOu6r0:
		Om3xJ8HAlP6TiDnpkMfC4jEhQotwr1 = xB3NS9bTCqO(SFVu351C6NLHgM7,AzdUPKpDGxE1sjIcMOoR78f2Q9,aYEzIedpxihB8otjJDPbS)
		if Om3xJ8HAlP6TiDnpkMfC4jEhQotwr1['favorites']:
			WgwHVypGYjckZ4 = nvlhoJtjfRTSMANVO1HDCBcgPxI(aYEzIedpxihB8otjJDPbS,Om3xJ8HAlP6TiDnpkMfC4jEhQotwr1['menuItem'],Om3xJ8HAlP6TiDnpkMfC4jEhQotwr1['newpath'])
			Om3xJ8HAlP6TiDnpkMfC4jEhQotwr1['context_menu'] = WgwHVypGYjckZ4+Om3xJ8HAlP6TiDnpkMfC4jEhQotwr1['context_menu']
		yyuwkfvhPiIFtZqES.append(Om3xJ8HAlP6TiDnpkMfC4jEhQotwr1)
	return yyuwkfvhPiIFtZqES
def mmaSpfqEjXykOZuzVLn2W6ihYC(Zb6XVxojEdJCGWBYnFm9qIpu):
	hIfxLy01wqHeAcTkVDlE5jCFMPzGv,yUxHVdeArcmkinf, = [],''
	for mK69jMeAkOl1I3tF5HGPJRgr in Zb6XVxojEdJCGWBYnFm9qIpu:
		if not mK69jMeAkOl1I3tF5HGPJRgr: hIfxLy01wqHeAcTkVDlE5jCFMPzGv.append('')
		else: break
	Zb6XVxojEdJCGWBYnFm9qIpu = Zb6XVxojEdJCGWBYnFm9qIpu[len(hIfxLy01wqHeAcTkVDlE5jCFMPzGv):]
	Gfsr6KpyVRovQmB8xcXUJ = '\n\n\n\n'.join(Zb6XVxojEdJCGWBYnFm9qIpu)
	Gfsr6KpyVRovQmB8xcXUJ = Gfsr6KpyVRovQmB8xcXUJ.replace('===== ===== =====','000001')
	Gfsr6KpyVRovQmB8xcXUJ = Gfsr6KpyVRovQmB8xcXUJ.replace('[COLOR FFC89008]','000002')
	Gfsr6KpyVRovQmB8xcXUJ = Gfsr6KpyVRovQmB8xcXUJ.replace('[COLOR FFFFFF00]','000003')
	Gfsr6KpyVRovQmB8xcXUJ = Gfsr6KpyVRovQmB8xcXUJ.replace('[/COLOR]','000004')
	Gfsr6KpyVRovQmB8xcXUJ = Gfsr6KpyVRovQmB8xcXUJ.replace('[RIGHT]','000005')
	yyeS7VUtoclLQiWxwYMGj1dBvZr = 100000
	w4JpdetBvk9 = {}
	d9WIMPevBo71 = My7Dwqvs6bfGNSIgX.findall('http.*?[\r\n ]',Gfsr6KpyVRovQmB8xcXUJ,My7Dwqvs6bfGNSIgX.DOTALL)
	for TDLIzg3PjhHw9 in d9WIMPevBo71:
		yyeS7VUtoclLQiWxwYMGj1dBvZr += 1
		Gfsr6KpyVRovQmB8xcXUJ = Gfsr6KpyVRovQmB8xcXUJ.replace(TDLIzg3PjhHw9,str(yyeS7VUtoclLQiWxwYMGj1dBvZr))
		w4JpdetBvk9[str(yyeS7VUtoclLQiWxwYMGj1dBvZr)] = TDLIzg3PjhHw9
	for NnacyGSwPsCe18JuHpz0XQRt in range(0,len(Gfsr6KpyVRovQmB8xcXUJ),4800):
		bbtGIinEQm3O9UoCsLr6lYRcNpSj5e = Gfsr6KpyVRovQmB8xcXUJ[NnacyGSwPsCe18JuHpz0XQRt:NnacyGSwPsCe18JuHpz0XQRt+4800]
		Ll6IpqSv2JZytKiMBWEPzrb9Hcx35n = bLEBi8IO7uU2x3htYDdVq95.getSetting('av.language.code')
		SCakygtHx0AUXbO3emswB9F8 = 'https://translator-api.glosbe.com/translateByLangDetect?sourceLang=ar&targetLang='+Ll6IpqSv2JZytKiMBWEPzrb9Hcx35n
		LM6unUr13ZYpOfPRkNXHE = {'Content-Type':'text/plain'}
		llvE0P6BGtj = bbtGIinEQm3O9UoCsLr6lYRcNpSj5e.encode('utf8')
		JgLvsu6wx9n3VbQhk7KXylHm = mORwgTnXBdQ7iCSHKf(SToQEHqGtMnAlFbCz4wxBDuOsmW7,'POST',SCakygtHx0AUXbO3emswB9F8,llvE0P6BGtj,LM6unUr13ZYpOfPRkNXHE,'','','LIBRARY-GLOSBE_TRANSLATE-1st')
		if JgLvsu6wx9n3VbQhk7KXylHm.succeeded:
			qUWIbEBP2tlNaSL = JgLvsu6wx9n3VbQhk7KXylHm.content
			IxGuNdpBbU4 = dWsa2A0O4o5BYiqGXhyKEbM('str',qUWIbEBP2tlNaSL)
			if IxGuNdpBbU4:
				IxGuNdpBbU4 = IxGuNdpBbU4['translation']
				IxGuNdpBbU4 = tW06wVMpReHfnj3KgzT2va(IxGuNdpBbU4)
				for rBLZ3RjCdy8KWk5t in range(len(IxGuNdpBbU4)):
					yUxHVdeArcmkinf += IxGuNdpBbU4[rBLZ3RjCdy8KWk5t][0]
	yUxHVdeArcmkinf = yUxHVdeArcmkinf.replace('000001','===== ===== =====')
	yUxHVdeArcmkinf = yUxHVdeArcmkinf.replace('000002','[COLOR FFC89008]')
	yUxHVdeArcmkinf = yUxHVdeArcmkinf.replace('000003','[COLOR FFFFFF00]')
	yUxHVdeArcmkinf = yUxHVdeArcmkinf.replace('000004','[/COLOR]')
	yUxHVdeArcmkinf = yUxHVdeArcmkinf.replace('000005','[RIGHT]')
	for yyeS7VUtoclLQiWxwYMGj1dBvZr in list(w4JpdetBvk9.keys()):
		TDLIzg3PjhHw9 = w4JpdetBvk9[yyeS7VUtoclLQiWxwYMGj1dBvZr]
		yUxHVdeArcmkinf = yUxHVdeArcmkinf.replace(yyeS7VUtoclLQiWxwYMGj1dBvZr,TDLIzg3PjhHw9)
	yUxHVdeArcmkinf = yUxHVdeArcmkinf.split('\n\n\n\n')
	return hIfxLy01wqHeAcTkVDlE5jCFMPzGv+yUxHVdeArcmkinf
def yFHYLU2WjO1iDlEg36hctxap(Zb6XVxojEdJCGWBYnFm9qIpu):
	hIfxLy01wqHeAcTkVDlE5jCFMPzGv,yUxHVdeArcmkinf, = [],''
	for mK69jMeAkOl1I3tF5HGPJRgr in Zb6XVxojEdJCGWBYnFm9qIpu:
		if not mK69jMeAkOl1I3tF5HGPJRgr: hIfxLy01wqHeAcTkVDlE5jCFMPzGv.append('')
		else: break
	Zb6XVxojEdJCGWBYnFm9qIpu = Zb6XVxojEdJCGWBYnFm9qIpu[len(hIfxLy01wqHeAcTkVDlE5jCFMPzGv):]
	Gfsr6KpyVRovQmB8xcXUJ = '\\n\\n\\n\\n'.join(Zb6XVxojEdJCGWBYnFm9qIpu)
	Gfsr6KpyVRovQmB8xcXUJ = Gfsr6KpyVRovQmB8xcXUJ.replace('كلا','no')
	Gfsr6KpyVRovQmB8xcXUJ = Gfsr6KpyVRovQmB8xcXUJ.replace('استمرار','continue')
	Gfsr6KpyVRovQmB8xcXUJ = Gfsr6KpyVRovQmB8xcXUJ.replace('===== ===== =====','000001')
	Gfsr6KpyVRovQmB8xcXUJ = Gfsr6KpyVRovQmB8xcXUJ.replace('[COLOR FFC89008]','000002')
	Gfsr6KpyVRovQmB8xcXUJ = Gfsr6KpyVRovQmB8xcXUJ.replace('[COLOR FFFFFF00]','000003')
	Gfsr6KpyVRovQmB8xcXUJ = Gfsr6KpyVRovQmB8xcXUJ.replace('[/COLOR]','000004')
	Gfsr6KpyVRovQmB8xcXUJ = Gfsr6KpyVRovQmB8xcXUJ.replace('[RIGHT]','000005')
	Gfsr6KpyVRovQmB8xcXUJ = Gfsr6KpyVRovQmB8xcXUJ.replace('[CENTER]','000006')
	Gfsr6KpyVRovQmB8xcXUJ = Gfsr6KpyVRovQmB8xcXUJ.replace('[RTL]','000007')
	Gfsr6KpyVRovQmB8xcXUJ = Gfsr6KpyVRovQmB8xcXUJ.replace("'","\\\\\\'")
	Gfsr6KpyVRovQmB8xcXUJ = Gfsr6KpyVRovQmB8xcXUJ.replace('"','\\\\\\"')
	Gfsr6KpyVRovQmB8xcXUJ = Gfsr6KpyVRovQmB8xcXUJ.replace('\n','\\n')
	Gfsr6KpyVRovQmB8xcXUJ = Gfsr6KpyVRovQmB8xcXUJ.replace('\r','\\\\r')
	for NnacyGSwPsCe18JuHpz0XQRt in range(0,len(Gfsr6KpyVRovQmB8xcXUJ),4800):
		bbtGIinEQm3O9UoCsLr6lYRcNpSj5e = Gfsr6KpyVRovQmB8xcXUJ[NnacyGSwPsCe18JuHpz0XQRt:NnacyGSwPsCe18JuHpz0XQRt+4800]
		SCakygtHx0AUXbO3emswB9F8 = 'https://translate.google.com/_/TranslateWebserverUi/data/batchexecute'
		LM6unUr13ZYpOfPRkNXHE = {'Content-Type':'application/x-www-form-urlencoded'}
		Ll6IpqSv2JZytKiMBWEPzrb9Hcx35n = bLEBi8IO7uU2x3htYDdVq95.getSetting('av.language.code')
		llvE0P6BGtj = 'f.req='+F8fMqZKB4APk('[[["MkEWBc","[[\\"'+bbtGIinEQm3O9UoCsLr6lYRcNpSj5e+'\\",\\"ar\\",\\"'+Ll6IpqSv2JZytKiMBWEPzrb9Hcx35n+'\\",1],[]]",null,"generic"]]]','')
		llvE0P6BGtj = llvE0P6BGtj.replace('%5Cn','%5C%5Cn')
		JgLvsu6wx9n3VbQhk7KXylHm = mORwgTnXBdQ7iCSHKf(SToQEHqGtMnAlFbCz4wxBDuOsmW7,'POST',SCakygtHx0AUXbO3emswB9F8,llvE0P6BGtj,LM6unUr13ZYpOfPRkNXHE,'','','LIBRARY-GOOGLE_TRANSLATE-1st')
		if JgLvsu6wx9n3VbQhk7KXylHm.succeeded:
			qUWIbEBP2tlNaSL = JgLvsu6wx9n3VbQhk7KXylHm.content
			qUWIbEBP2tlNaSL = qUWIbEBP2tlNaSL.split('\n')[-1]
			IxGuNdpBbU4 = dWsa2A0O4o5BYiqGXhyKEbM('str',qUWIbEBP2tlNaSL)[0][2]
			if IxGuNdpBbU4:
				IxGuNdpBbU4 = dWsa2A0O4o5BYiqGXhyKEbM('str',IxGuNdpBbU4)[1][0][0][5]
				IxGuNdpBbU4 = tW06wVMpReHfnj3KgzT2va(IxGuNdpBbU4)
				for rBLZ3RjCdy8KWk5t in range(len(IxGuNdpBbU4)):
					yUxHVdeArcmkinf += IxGuNdpBbU4[rBLZ3RjCdy8KWk5t][0]
	yUxHVdeArcmkinf = yUxHVdeArcmkinf.replace('00000','0000').replace('0000','000')
	yUxHVdeArcmkinf = yUxHVdeArcmkinf.replace('0001','===== ===== =====')
	yUxHVdeArcmkinf = yUxHVdeArcmkinf.replace('0002','[COLOR FFC89008]')
	yUxHVdeArcmkinf = yUxHVdeArcmkinf.replace('0003','[COLOR FFFFFF00]')
	yUxHVdeArcmkinf = yUxHVdeArcmkinf.replace('0004','[/COLOR]')
	yUxHVdeArcmkinf = yUxHVdeArcmkinf.replace('0005','[RIGHT]')
	yUxHVdeArcmkinf = yUxHVdeArcmkinf.replace('0006','[CENTER]')
	yUxHVdeArcmkinf = yUxHVdeArcmkinf.replace('0007','[RTL]')
	yUxHVdeArcmkinf = yUxHVdeArcmkinf.split('\n\n\n\n')
	return hIfxLy01wqHeAcTkVDlE5jCFMPzGv+yUxHVdeArcmkinf
def jUIXlhTc4NtobAL1g2xDa6myp5QJ(Zb6XVxojEdJCGWBYnFm9qIpu):
	hIfxLy01wqHeAcTkVDlE5jCFMPzGv,NfF2ZElCPbz3Gmy6dR = [],[]
	for mK69jMeAkOl1I3tF5HGPJRgr in Zb6XVxojEdJCGWBYnFm9qIpu:
		if not mK69jMeAkOl1I3tF5HGPJRgr: hIfxLy01wqHeAcTkVDlE5jCFMPzGv.append('')
		else: break
	Zb6XVxojEdJCGWBYnFm9qIpu = Zb6XVxojEdJCGWBYnFm9qIpu[len(hIfxLy01wqHeAcTkVDlE5jCFMPzGv):]
	Gfsr6KpyVRovQmB8xcXUJ = '\n\n\n\n'.join(Zb6XVxojEdJCGWBYnFm9qIpu)
	Gfsr6KpyVRovQmB8xcXUJ = Gfsr6KpyVRovQmB8xcXUJ.replace('كلا','no')
	Gfsr6KpyVRovQmB8xcXUJ = Gfsr6KpyVRovQmB8xcXUJ.replace('استمرار','continue')
	Gfsr6KpyVRovQmB8xcXUJ = Gfsr6KpyVRovQmB8xcXUJ.replace('أدناه','below')
	Gfsr6KpyVRovQmB8xcXUJ = Gfsr6KpyVRovQmB8xcXUJ.replace('[COLOR FFC89008]','00001')
	Gfsr6KpyVRovQmB8xcXUJ = Gfsr6KpyVRovQmB8xcXUJ.replace('[COLOR FFFFFF00]','00002')
	Gfsr6KpyVRovQmB8xcXUJ = Gfsr6KpyVRovQmB8xcXUJ.replace('[/COLOR]','00003')
	Gfsr6KpyVRovQmB8xcXUJ = Gfsr6KpyVRovQmB8xcXUJ.replace('=====','00004')
	Gfsr6KpyVRovQmB8xcXUJ = Gfsr6KpyVRovQmB8xcXUJ.replace(',','00005')
	Gfsr6KpyVRovQmB8xcXUJ = Gfsr6KpyVRovQmB8xcXUJ.replace('[RTL]','00009')
	Gfsr6KpyVRovQmB8xcXUJ = Gfsr6KpyVRovQmB8xcXUJ.replace('[CENTER]','0000A')
	Gfsr6KpyVRovQmB8xcXUJ = Gfsr6KpyVRovQmB8xcXUJ.replace('\r','0000B')
	Zb6XVxojEdJCGWBYnFm9qIpu = Gfsr6KpyVRovQmB8xcXUJ.split('\n')
	Gfsr6KpyVRovQmB8xcXUJ,yUxHVdeArcmkinf = '',''
	for mK69jMeAkOl1I3tF5HGPJRgr in Zb6XVxojEdJCGWBYnFm9qIpu:
		if len(Gfsr6KpyVRovQmB8xcXUJ+mK69jMeAkOl1I3tF5HGPJRgr)<1800: Gfsr6KpyVRovQmB8xcXUJ += '\n'+mK69jMeAkOl1I3tF5HGPJRgr
		else:
			NfF2ZElCPbz3Gmy6dR.append(Gfsr6KpyVRovQmB8xcXUJ)
			Gfsr6KpyVRovQmB8xcXUJ = mK69jMeAkOl1I3tF5HGPJRgr
	NfF2ZElCPbz3Gmy6dR.append(Gfsr6KpyVRovQmB8xcXUJ)
	from json import dumps as huDqM5dOIfAR7rlQwz6b8Ug
	for mK69jMeAkOl1I3tF5HGPJRgr in NfF2ZElCPbz3Gmy6dR:
		LM6unUr13ZYpOfPRkNXHE = {'Content-Type':'application/json','User-Agent':''}
		SCakygtHx0AUXbO3emswB9F8 = 'https://api.reverso.net/translate/v1/translation'
		Ll6IpqSv2JZytKiMBWEPzrb9Hcx35n = bLEBi8IO7uU2x3htYDdVq95.getSetting('av.language.code')
		llvE0P6BGtj = {"format":"text","from":"ara","to":Ll6IpqSv2JZytKiMBWEPzrb9Hcx35n,"input":mK69jMeAkOl1I3tF5HGPJRgr,"options":{"sentenceSplitter":True,"origin":"translation.web","contextResults":False,"languageDetection":False}}
		llvE0P6BGtj = huDqM5dOIfAR7rlQwz6b8Ug(llvE0P6BGtj)
		JgLvsu6wx9n3VbQhk7KXylHm = mORwgTnXBdQ7iCSHKf(SToQEHqGtMnAlFbCz4wxBDuOsmW7,'POST',SCakygtHx0AUXbO3emswB9F8,llvE0P6BGtj,LM6unUr13ZYpOfPRkNXHE,'','','LIBRARY-REVERSO_TRANSLATE-1st')
		if JgLvsu6wx9n3VbQhk7KXylHm.succeeded:
			qUWIbEBP2tlNaSL = JgLvsu6wx9n3VbQhk7KXylHm.content
			qUWIbEBP2tlNaSL = dWsa2A0O4o5BYiqGXhyKEbM('dict',qUWIbEBP2tlNaSL)
			yUxHVdeArcmkinf += '\n'+''.join(qUWIbEBP2tlNaSL['translation'])
	yUxHVdeArcmkinf = yUxHVdeArcmkinf[2:]
	yUxHVdeArcmkinf = yUxHVdeArcmkinf.replace('000000','00000').replace('00000','0000').replace('0000','000')
	yUxHVdeArcmkinf = yUxHVdeArcmkinf.replace('0001','[COLOR FFC89008]')
	yUxHVdeArcmkinf = yUxHVdeArcmkinf.replace('0002','[COLOR FFFFFF00]')
	yUxHVdeArcmkinf = yUxHVdeArcmkinf.replace('0003','[/COLOR]')
	yUxHVdeArcmkinf = yUxHVdeArcmkinf.replace('0004','=====')
	yUxHVdeArcmkinf = yUxHVdeArcmkinf.replace('0005',',')
	yUxHVdeArcmkinf = yUxHVdeArcmkinf.replace('0009','[RTL]')
	yUxHVdeArcmkinf = yUxHVdeArcmkinf.replace('000A','[CENTER]')
	yUxHVdeArcmkinf = yUxHVdeArcmkinf.replace('000B','\r')
	yUxHVdeArcmkinf = yUxHVdeArcmkinf.split('\n\n\n\n')
	return hIfxLy01wqHeAcTkVDlE5jCFMPzGv+yUxHVdeArcmkinf
def II5RxkE86THdOhoDML2Zbgc(Zb6XVxojEdJCGWBYnFm9qIpu):
	eVpsc23G48QbgJDF5WPhfA1qNi7v = bLEBi8IO7uU2x3htYDdVq95.getSetting('av.language.translate')
	if not eVpsc23G48QbgJDF5WPhfA1qNi7v or not Zb6XVxojEdJCGWBYnFm9qIpu: return Zb6XVxojEdJCGWBYnFm9qIpu
	p3l4qwtsKIfmbZja8dHTPJvMGVrNO6 = bLEBi8IO7uU2x3htYDdVq95.getSetting('av.language.provider')
	Ll6IpqSv2JZytKiMBWEPzrb9Hcx35n = bLEBi8IO7uU2x3htYDdVq95.getSetting('av.language.code')
	zJA9qMcCkebLl3sKtu45FRSU = Ll6IpqSv2JZytKiMBWEPzrb9Hcx35n+'__'+str(Zb6XVxojEdJCGWBYnFm9qIpu)
	bLEBi8IO7uU2x3htYDdVq95.setSetting('av.language.translate','')
	yUxHVdeArcmkinf = zPgNsqpJInt(RnqtMUa9Nh6peGEsBT,'list','TRANSLATE_'+p3l4qwtsKIfmbZja8dHTPJvMGVrNO6,zJA9qMcCkebLl3sKtu45FRSU)
	if not yUxHVdeArcmkinf:
		if p3l4qwtsKIfmbZja8dHTPJvMGVrNO6=='GOOGLE': yUxHVdeArcmkinf = yFHYLU2WjO1iDlEg36hctxap(Zb6XVxojEdJCGWBYnFm9qIpu)
		elif p3l4qwtsKIfmbZja8dHTPJvMGVrNO6=='REVERSO': yUxHVdeArcmkinf = jUIXlhTc4NtobAL1g2xDa6myp5QJ(Zb6XVxojEdJCGWBYnFm9qIpu)
		elif p3l4qwtsKIfmbZja8dHTPJvMGVrNO6=='GLOSBE': yUxHVdeArcmkinf = mmaSpfqEjXykOZuzVLn2W6ihYC(Zb6XVxojEdJCGWBYnFm9qIpu)
		if len(Zb6XVxojEdJCGWBYnFm9qIpu)==len(yUxHVdeArcmkinf):
			VZ8BTik93OqXLCh0fD7d2KUPpn4mH6(RnqtMUa9Nh6peGEsBT,'TRANSLATE_'+p3l4qwtsKIfmbZja8dHTPJvMGVrNO6,zJA9qMcCkebLl3sKtu45FRSU,yUxHVdeArcmkinf,HTNv70wWuCxtU)
		else:
			yUxHVdeArcmkinf = Zb6XVxojEdJCGWBYnFm9qIpu
			gj7BGM5t3RZpA0vNixLqzwualb16('الترجمة فشلت','Translation Failed')
	bLEBi8IO7uU2x3htYDdVq95.setSetting('av.language.translate','1')
	return yUxHVdeArcmkinf
def VsShzn5wMuYP(SFVu351C6NLHgM7,yyuwkfvhPiIFtZqES,a5MrRBdG4wpAYmej0ZgUyh,Y04awemGVro1bvxzCsQLp3XyAg,XXTAwt71EI):
	dM2SkzwnVKc3FUPDl9BE,bSxczpUtHewVDKa3EL4lm,SCakygtHx0AUXbO3emswB9F8,H3HDqY5N4e0fWSXMikZ8CR7suUmJdx,MofmxtNlUaORA0K1uJv6S8g,EoulZdO2FQmDYrqNbA1kagMp,Gfsr6KpyVRovQmB8xcXUJ,HMdmFA6wzOC0GEoa9rlt27biPn,InkN7SpoMudDGJ6K = SFVu351C6NLHgM7
	FLHxM5flhiwm = []
	eVpsc23G48QbgJDF5WPhfA1qNi7v = bLEBi8IO7uU2x3htYDdVq95.getSetting('av.language.translate')
	if eVpsc23G48QbgJDF5WPhfA1qNi7v:
		IIvoPtXQeEpd,OItXR4TmKQJzibLkAp,eH2PEANlufZBJLqwoY7GaC = [],[],[]
		if not FLHxM5flhiwm:
			for Om3xJ8HAlP6TiDnpkMfC4jEhQotwr1 in yyuwkfvhPiIFtZqES:
				bSxczpUtHewVDKa3EL4lm = Om3xJ8HAlP6TiDnpkMfC4jEhQotwr1['name'].replace(rcek0gbPZ6lmJwSaTNso,'').replace(u8c5pQm3iRwvxESj7PUrO,'')
				gg1ErNnLj7b9DkdRxlFqmJ0Q4XHh = My7Dwqvs6bfGNSIgX.findall('^(\[COLOR FFFFFF00\])(\d\d.\d\d) (\d\d.\d\d)(\[/COLOR\]) (.*?)$',bSxczpUtHewVDKa3EL4lm,My7Dwqvs6bfGNSIgX.DOTALL)
				if gg1ErNnLj7b9DkdRxlFqmJ0Q4XHh:
					hIfxLy01wqHeAcTkVDlE5jCFMPzGv,X3XfTy89O2EqDls0nSpBedYjPMIkh,rP6vUnSXbLgE2m04B8RVeDYx,IuxVP8B9b5aKmNQ2MlchDoGJLdW,bSxczpUtHewVDKa3EL4lm = gg1ErNnLj7b9DkdRxlFqmJ0Q4XHh[0]
					gg1ErNnLj7b9DkdRxlFqmJ0Q4XHh = hIfxLy01wqHeAcTkVDlE5jCFMPzGv+X3XfTy89O2EqDls0nSpBedYjPMIkh+' '+rP6vUnSXbLgE2m04B8RVeDYx+IuxVP8B9b5aKmNQ2MlchDoGJLdW+' '
				else:
					gg1ErNnLj7b9DkdRxlFqmJ0Q4XHh = My7Dwqvs6bfGNSIgX.findall('^(.*?) (\[COLOR FFFFFF00\])(\d\d.\d\d) (\d\d.\d\d)(\[/COLOR\])$',bSxczpUtHewVDKa3EL4lm,My7Dwqvs6bfGNSIgX.DOTALL)
					if gg1ErNnLj7b9DkdRxlFqmJ0Q4XHh:
						bSxczpUtHewVDKa3EL4lm,hIfxLy01wqHeAcTkVDlE5jCFMPzGv,rP6vUnSXbLgE2m04B8RVeDYx,X3XfTy89O2EqDls0nSpBedYjPMIkh,IuxVP8B9b5aKmNQ2MlchDoGJLdW = gg1ErNnLj7b9DkdRxlFqmJ0Q4XHh[0]
						gg1ErNnLj7b9DkdRxlFqmJ0Q4XHh = hIfxLy01wqHeAcTkVDlE5jCFMPzGv+X3XfTy89O2EqDls0nSpBedYjPMIkh+' '+rP6vUnSXbLgE2m04B8RVeDYx+IuxVP8B9b5aKmNQ2MlchDoGJLdW+' '
					else: gg1ErNnLj7b9DkdRxlFqmJ0Q4XHh = ''
				QvYmunyI2p1M = My7Dwqvs6bfGNSIgX.findall('^(.\[COLOR FFC89008\]\w\w\w \[/COLOR\])(.*?)$',bSxczpUtHewVDKa3EL4lm,My7Dwqvs6bfGNSIgX.DOTALL)
				if QvYmunyI2p1M: QvYmunyI2p1M,bSxczpUtHewVDKa3EL4lm = QvYmunyI2p1M[0]
				else: QvYmunyI2p1M = ''
				IIvoPtXQeEpd.append(gg1ErNnLj7b9DkdRxlFqmJ0Q4XHh+QvYmunyI2p1M)
				OItXR4TmKQJzibLkAp.append(bSxczpUtHewVDKa3EL4lm)
			eH2PEANlufZBJLqwoY7GaC = II5RxkE86THdOhoDML2Zbgc(OItXR4TmKQJzibLkAp)
			if eH2PEANlufZBJLqwoY7GaC:
				for NnacyGSwPsCe18JuHpz0XQRt in range(len(yyuwkfvhPiIFtZqES)):
					Om3xJ8HAlP6TiDnpkMfC4jEhQotwr1 = yyuwkfvhPiIFtZqES[NnacyGSwPsCe18JuHpz0XQRt]
					Om3xJ8HAlP6TiDnpkMfC4jEhQotwr1['name'] = IIvoPtXQeEpd[NnacyGSwPsCe18JuHpz0XQRt]+eH2PEANlufZBJLqwoY7GaC[NnacyGSwPsCe18JuHpz0XQRt]
					FLHxM5flhiwm.append(Om3xJ8HAlP6TiDnpkMfC4jEhQotwr1)
	if FLHxM5flhiwm: yyuwkfvhPiIFtZqES = FLHxM5flhiwm
	KNAfHCgO93X8u52iGwI,EzcUWRy8mot7wfYKPH3pxT,BH6WOCSifProeIsQDnRhqxaAX8 = [],0,0
	e42eV0xluFCPhpfB8w176LyAinUav = XXRtDhYvWb35qnLBxIri7ScNUks0.path.join(gcIBiFLSn0Hyb3joM15vPpwWJ,H3HDqY5N4e0fWSXMikZ8CR7suUmJdx)
	try: eegz3Xw0Os9L2KdGVjoJiQPUR4l = XXRtDhYvWb35qnLBxIri7ScNUks0.listdir(e42eV0xluFCPhpfB8w176LyAinUav)
	except:
		try: XXRtDhYvWb35qnLBxIri7ScNUks0.makedirs(e42eV0xluFCPhpfB8w176LyAinUav)
		except: pass
		eegz3Xw0Os9L2KdGVjoJiQPUR4l = []
	VdAi5frsIJ70 = tto9IZkKWD('menu_item')
	for Om3xJ8HAlP6TiDnpkMfC4jEhQotwr1 in yyuwkfvhPiIFtZqES:
		bSxczpUtHewVDKa3EL4lm = Om3xJ8HAlP6TiDnpkMfC4jEhQotwr1['name']
		cUgXpKno8eG2Lih = Om3xJ8HAlP6TiDnpkMfC4jEhQotwr1['context_menu']
		Sq2tew7PfsIYMyXVjWv = Om3xJ8HAlP6TiDnpkMfC4jEhQotwr1['plot']
		bTn92AWhOxVoq1ZYly30 = Om3xJ8HAlP6TiDnpkMfC4jEhQotwr1['stars']
		MofmxtNlUaORA0K1uJv6S8g = Om3xJ8HAlP6TiDnpkMfC4jEhQotwr1['image']
		dM2SkzwnVKc3FUPDl9BE = Om3xJ8HAlP6TiDnpkMfC4jEhQotwr1['type']
		lqTyzjAbofHw1tiaFh7rO = Om3xJ8HAlP6TiDnpkMfC4jEhQotwr1['duration']
		RcPp0U34IohTNSfwjbvgxt8WDLuei = Om3xJ8HAlP6TiDnpkMfC4jEhQotwr1['isFolder']
		WgQxNTbK4jSIaFtv52Ei3n = Om3xJ8HAlP6TiDnpkMfC4jEhQotwr1['newpath']
		C2v1ZJX3LgMmQxyNbDPnhiq7SEtc = XUYb0K2ghSyFs.ListItem(bSxczpUtHewVDKa3EL4lm)
		C2v1ZJX3LgMmQxyNbDPnhiq7SEtc.addContextMenuItems(cUgXpKno8eG2Lih)
		if MofmxtNlUaORA0K1uJv6S8g: C2v1ZJX3LgMmQxyNbDPnhiq7SEtc.setArt({'icon':MofmxtNlUaORA0K1uJv6S8g,'thumb':MofmxtNlUaORA0K1uJv6S8g,'fanart':MofmxtNlUaORA0K1uJv6S8g,'banner':MofmxtNlUaORA0K1uJv6S8g,'clearart':MofmxtNlUaORA0K1uJv6S8g,'poster':MofmxtNlUaORA0K1uJv6S8g,'clearlogo':MofmxtNlUaORA0K1uJv6S8g,'landscape':MofmxtNlUaORA0K1uJv6S8g})
		else:
			bSxczpUtHewVDKa3EL4lm = E4L13O2bxwRDSX(bSxczpUtHewVDKa3EL4lm)
			bSxczpUtHewVDKa3EL4lm = hQd4Ygra5ZHWiP0UuJpj7TfI(bSxczpUtHewVDKa3EL4lm)
			ky9TrVex5FDYlMAuWHGBUvmpI4oq7j = bSxczpUtHewVDKa3EL4lm+'.png'
			default = True
			if ky9TrVex5FDYlMAuWHGBUvmpI4oq7j in eegz3Xw0Os9L2KdGVjoJiQPUR4l:
				e3eFv20QzgfE5plOSbstAMKwHVGYq = XXRtDhYvWb35qnLBxIri7ScNUks0.path.join(e42eV0xluFCPhpfB8w176LyAinUav,ky9TrVex5FDYlMAuWHGBUvmpI4oq7j)
				C2v1ZJX3LgMmQxyNbDPnhiq7SEtc.setArt({'icon':e3eFv20QzgfE5plOSbstAMKwHVGYq,'thumb':e3eFv20QzgfE5plOSbstAMKwHVGYq,'fanart':e3eFv20QzgfE5plOSbstAMKwHVGYq,'banner':e3eFv20QzgfE5plOSbstAMKwHVGYq,'clearart':e3eFv20QzgfE5plOSbstAMKwHVGYq,'poster':e3eFv20QzgfE5plOSbstAMKwHVGYq,'clearlogo':e3eFv20QzgfE5plOSbstAMKwHVGYq,'landscape':e3eFv20QzgfE5plOSbstAMKwHVGYq})
				default = False
			elif EzcUWRy8mot7wfYKPH3pxT<60 and BH6WOCSifProeIsQDnRhqxaAX8<5:
				e3eFv20QzgfE5plOSbstAMKwHVGYq = XXRtDhYvWb35qnLBxIri7ScNUks0.path.join(e42eV0xluFCPhpfB8w176LyAinUav,ky9TrVex5FDYlMAuWHGBUvmpI4oq7j)
				try:
					UTAYyMngpBCHKo8NLc = Sou2BEAGcLMTCh7bDXQ3W(VdAi5frsIJ70,'','','','',bSxczpUtHewVDKa3EL4lm,'menu_item','center',False,e3eFv20QzgfE5plOSbstAMKwHVGYq)
					C2v1ZJX3LgMmQxyNbDPnhiq7SEtc.setArt({'icon':e3eFv20QzgfE5plOSbstAMKwHVGYq,'thumb':e3eFv20QzgfE5plOSbstAMKwHVGYq,'fanart':e3eFv20QzgfE5plOSbstAMKwHVGYq,'banner':e3eFv20QzgfE5plOSbstAMKwHVGYq,'clearart':e3eFv20QzgfE5plOSbstAMKwHVGYq,'poster':e3eFv20QzgfE5plOSbstAMKwHVGYq,'clearlogo':e3eFv20QzgfE5plOSbstAMKwHVGYq,'landscape':e3eFv20QzgfE5plOSbstAMKwHVGYq})
					EzcUWRy8mot7wfYKPH3pxT += 1
					default = False
				except: BH6WOCSifProeIsQDnRhqxaAX8 += 1
			if default: C2v1ZJX3LgMmQxyNbDPnhiq7SEtc.setArt({'icon':pPQIefxX7FyvmAZbtRj,'thumb':aVks5nZ3tMmCwI7zX9KfOqcQUH,'fanart':lawLYbnTSFkAV04hmfO5,'banner':mSK4fLPqVJisj9dAIOv3nzErXBbF8,'clearart':aqcie5fsRvp6uItm,'poster':Vqaku0oRDbiJmCcdEKH28yPX7wY,'clearlogo':ARskT1fIxGDtCrNBv6PuhLX854JE,'landscape':fa98hqCrE2kweT3gZQ})
		if YSomBdvcNUMF3b8JDiCfrVW<20:
			if Sq2tew7PfsIYMyXVjWv: C2v1ZJX3LgMmQxyNbDPnhiq7SEtc.setInfo('video',{'Plot':Sq2tew7PfsIYMyXVjWv,'PlotOutline':Sq2tew7PfsIYMyXVjWv})
			if bTn92AWhOxVoq1ZYly30: C2v1ZJX3LgMmQxyNbDPnhiq7SEtc.setInfo('video',{'Rating':bTn92AWhOxVoq1ZYly30})
			if not MofmxtNlUaORA0K1uJv6S8g:
				C2v1ZJX3LgMmQxyNbDPnhiq7SEtc.setInfo('video',{'Title':bSxczpUtHewVDKa3EL4lm})
			if dM2SkzwnVKc3FUPDl9BE=='video':
				C2v1ZJX3LgMmQxyNbDPnhiq7SEtc.setInfo('video',{'mediatype':'movie'})
				if lqTyzjAbofHw1tiaFh7rO: C2v1ZJX3LgMmQxyNbDPnhiq7SEtc.setInfo('video',{'duration':lqTyzjAbofHw1tiaFh7rO})
				C2v1ZJX3LgMmQxyNbDPnhiq7SEtc.setProperty('IsPlayable','true')
		else:
			wweoUHsxcK = C2v1ZJX3LgMmQxyNbDPnhiq7SEtc.getVideoInfoTag()
			if bTn92AWhOxVoq1ZYly30: wweoUHsxcK.setRating(float(bTn92AWhOxVoq1ZYly30))
			if not MofmxtNlUaORA0K1uJv6S8g:
				wweoUHsxcK.setTitle(bSxczpUtHewVDKa3EL4lm)
			if dM2SkzwnVKc3FUPDl9BE=='video':
				wweoUHsxcK.setMediaType('tvshow')
				if lqTyzjAbofHw1tiaFh7rO: wweoUHsxcK.setDuration(lqTyzjAbofHw1tiaFh7rO)
				C2v1ZJX3LgMmQxyNbDPnhiq7SEtc.setProperty('IsPlayable','true')
		KNAfHCgO93X8u52iGwI.append((WgQxNTbK4jSIaFtv52Ei3n,C2v1ZJX3LgMmQxyNbDPnhiq7SEtc,RcPp0U34IohTNSfwjbvgxt8WDLuei))
	VMKAudnbXHORPj.setContent(n6ReHNYovBwFxiuJ,'tvshows')
	i3Zcv9YXfOANbuEGxTFIpy4JaB1 = VMKAudnbXHORPj.addDirectoryItems(n6ReHNYovBwFxiuJ,KNAfHCgO93X8u52iGwI)
	VMKAudnbXHORPj.endOfDirectory(n6ReHNYovBwFxiuJ,a5MrRBdG4wpAYmej0ZgUyh,Y04awemGVro1bvxzCsQLp3XyAg,XXTAwt71EI)
	return i3Zcv9YXfOANbuEGxTFIpy4JaB1
def VQhpA0sF5GbRSZyEBrzkoJ68HWLX(dM2SkzwnVKc3FUPDl9BE,bSxczpUtHewVDKa3EL4lm,SCakygtHx0AUXbO3emswB9F8,H3HDqY5N4e0fWSXMikZ8CR7suUmJdx,MofmxtNlUaORA0K1uJv6S8g='',EoulZdO2FQmDYrqNbA1kagMp='',Gfsr6KpyVRovQmB8xcXUJ='',HMdmFA6wzOC0GEoa9rlt27biPn='',InkN7SpoMudDGJ6K={}):
	bSxczpUtHewVDKa3EL4lm = bSxczpUtHewVDKa3EL4lm.replace('\r','').replace('\n','').replace('\t','')
	SCakygtHx0AUXbO3emswB9F8 = SCakygtHx0AUXbO3emswB9F8.replace('\r','').replace('\n','').replace('\t','')
	if '_SCRIPT_' in bSxczpUtHewVDKa3EL4lm: DaZhLqOIc24x6wv57YUlF3NgCzpGeX,bSxczpUtHewVDKa3EL4lm = bSxczpUtHewVDKa3EL4lm.split('_SCRIPT_',1)
	else: DaZhLqOIc24x6wv57YUlF3NgCzpGeX,bSxczpUtHewVDKa3EL4lm = '',bSxczpUtHewVDKa3EL4lm
	if DaZhLqOIc24x6wv57YUlF3NgCzpGeX:
		pQUAuxTrkl5RCe9JFXw2M41EgB = bSxczpUtHewVDKa3EL4lm
		if not pQUAuxTrkl5RCe9JFXw2M41EgB: pQUAuxTrkl5RCe9JFXw2M41EgB = '....'
		elif pQUAuxTrkl5RCe9JFXw2M41EgB.count('_')>1: pQUAuxTrkl5RCe9JFXw2M41EgB = pQUAuxTrkl5RCe9JFXw2M41EgB.split('_',2)[2]
		pQUAuxTrkl5RCe9JFXw2M41EgB = pQUAuxTrkl5RCe9JFXw2M41EgB.replace(' ','')
		pQUAuxTrkl5RCe9JFXw2M41EgB = pQUAuxTrkl5RCe9JFXw2M41EgB.replace('ـ','').replace('ة','ه').replace('ؤ','و')
		pQUAuxTrkl5RCe9JFXw2M41EgB = pQUAuxTrkl5RCe9JFXw2M41EgB.replace('أ','ا').replace('إ','ا').replace('آ','ا')
		pQUAuxTrkl5RCe9JFXw2M41EgB = pQUAuxTrkl5RCe9JFXw2M41EgB.replace('لأ','لا').replace('لإ','لا').replace('لآ','لا')
		pQUAuxTrkl5RCe9JFXw2M41EgB = pQUAuxTrkl5RCe9JFXw2M41EgB.replace('َ','').replace('ً','').replace('ُ','').replace('ٌ','')
		pQUAuxTrkl5RCe9JFXw2M41EgB = pQUAuxTrkl5RCe9JFXw2M41EgB.replace('ِ','').replace('ٍ','').replace('ْ','').replace('ّ','')
		pQUAuxTrkl5RCe9JFXw2M41EgB = pQUAuxTrkl5RCe9JFXw2M41EgB.replace('|','').replace('~','')
		pQUAuxTrkl5RCe9JFXw2M41EgB = pQUAuxTrkl5RCe9JFXw2M41EgB.replace('اون لاين','').replace('سيما لايت','')
		pFjk01OaG4tuH8DlvZLgyoPwqE2h = ['العاب','خيال','البوم','الان','اطفال','حاليه','الغاز','صالح','الدين','مواليد','العالم','اعمال']
		if not any(ZWdUEIjMmA2OCi in pQUAuxTrkl5RCe9JFXw2M41EgB for ZWdUEIjMmA2OCi in pFjk01OaG4tuH8DlvZLgyoPwqE2h): pQUAuxTrkl5RCe9JFXw2M41EgB = pQUAuxTrkl5RCe9JFXw2M41EgB.replace('ال','')
		pQUAuxTrkl5RCe9JFXw2M41EgB = pQUAuxTrkl5RCe9JFXw2M41EgB.replace('اخري','اخرى').replace('اجنبى','اجنبي').replace('عائليه','عائلي')
		pQUAuxTrkl5RCe9JFXw2M41EgB = pQUAuxTrkl5RCe9JFXw2M41EgB.replace('اجنبيه','اجنبي').replace('عربيه','عربي').replace('رومانسيه','رومانسي')
		pQUAuxTrkl5RCe9JFXw2M41EgB = pQUAuxTrkl5RCe9JFXw2M41EgB.replace('غربيه','غربي').replace('و مسلسلات','مسلسلات').replace('اغانى','اغاني')
		pQUAuxTrkl5RCe9JFXw2M41EgB = pQUAuxTrkl5RCe9JFXw2M41EgB.replace('تاريخي','تاريخ').replace('خيال علمي','خيال').replace('موسيقيه','موسيقى')
		pQUAuxTrkl5RCe9JFXw2M41EgB = pQUAuxTrkl5RCe9JFXw2M41EgB.replace('هندى','هندي').replace('هنديه','هندي').replace('وثائقيه','وثائقي')
		pQUAuxTrkl5RCe9JFXw2M41EgB = pQUAuxTrkl5RCe9JFXw2M41EgB.replace('تليفزيونيه','تلفزيون').replace('تلفزيونيه','تلفزيون').replace('و كرتون','وكرتون')
		pQUAuxTrkl5RCe9JFXw2M41EgB = pQUAuxTrkl5RCe9JFXw2M41EgB.replace('الحاليه','حاليه').replace('موسیقي','موسيقى').replace('الانمي','انمي')
		pQUAuxTrkl5RCe9JFXw2M41EgB = pQUAuxTrkl5RCe9JFXw2M41EgB.replace('المسلسلات','مسلسلات').replace('البرامج','برامج').replace('كارتون','كرتون')
		pQUAuxTrkl5RCe9JFXw2M41EgB = pQUAuxTrkl5RCe9JFXw2M41EgB.replace('حروب','حرب').replace('الاناشيد','اناشيد').replace('اسيويه','اسيوي')
		pQUAuxTrkl5RCe9JFXw2M41EgB = pQUAuxTrkl5RCe9JFXw2M41EgB.replace('عربى','عربي').replace('تركى','تركي').replace('تركيه','تركي')
		pQUAuxTrkl5RCe9JFXw2M41EgB = pQUAuxTrkl5RCe9JFXw2M41EgB.replace('رياضي','رياضة').replace('رياضه','رياضة').replace('اسيويه','اسيوي')
		pQUAuxTrkl5RCe9JFXw2M41EgB = pQUAuxTrkl5RCe9JFXw2M41EgB.replace('كوميدى','كوميدي').replace('كوميديه','كوميدي').replace('انيمي','انمي')
		pQUAuxTrkl5RCe9JFXw2M41EgB = pQUAuxTrkl5RCe9JFXw2M41EgB.replace('انيميشن','انميشن').replace('انمى','انميشن').replace('انمي','انميشن')
		pQUAuxTrkl5RCe9JFXw2M41EgB = pQUAuxTrkl5RCe9JFXw2M41EgB.replace('انميشنشن','انميشن').replace('الانميشن','انميشن').replace('افلام مسلسلات','افلام ومسلسلات')
		pQUAuxTrkl5RCe9JFXw2M41EgB = pQUAuxTrkl5RCe9JFXw2M41EgB.replace('  ',' ').strip(' ')
		DaZhLqOIc24x6wv57YUlF3NgCzpGeX = '_LST_'+nnYoO8rQaHmc57IA1MVSi(DaZhLqOIc24x6wv57YUlF3NgCzpGeX)
		if pQUAuxTrkl5RCe9JFXw2M41EgB not in list(aaN3V2d6LKgSXOotH5n.keys()): aaN3V2d6LKgSXOotH5n[pQUAuxTrkl5RCe9JFXw2M41EgB] = {}
		aaN3V2d6LKgSXOotH5n[pQUAuxTrkl5RCe9JFXw2M41EgB][DaZhLqOIc24x6wv57YUlF3NgCzpGeX] = [dM2SkzwnVKc3FUPDl9BE,bSxczpUtHewVDKa3EL4lm,SCakygtHx0AUXbO3emswB9F8,H3HDqY5N4e0fWSXMikZ8CR7suUmJdx,MofmxtNlUaORA0K1uJv6S8g,EoulZdO2FQmDYrqNbA1kagMp,Gfsr6KpyVRovQmB8xcXUJ,HMdmFA6wzOC0GEoa9rlt27biPn,InkN7SpoMudDGJ6K]
	xx4viQhaOu6r0.append([dM2SkzwnVKc3FUPDl9BE,bSxczpUtHewVDKa3EL4lm,SCakygtHx0AUXbO3emswB9F8,H3HDqY5N4e0fWSXMikZ8CR7suUmJdx,MofmxtNlUaORA0K1uJv6S8g,EoulZdO2FQmDYrqNbA1kagMp,Gfsr6KpyVRovQmB8xcXUJ,HMdmFA6wzOC0GEoa9rlt27biPn,InkN7SpoMudDGJ6K])
	return
def PIfAumbGicwg5ye(mo2DWLtg4qdpFiuBnYkVJPwvR0):
	if BLz7m2RkNrxXQwy1cGAp: from html import unescape as _WBQThZReowMO3ySPqltgKDuHjF
	else:
		from HTMLParser import HTMLParser as Blbj5rNFn69qGwLCEhd
		_WBQThZReowMO3ySPqltgKDuHjF = Blbj5rNFn69qGwLCEhd().unescape
	if '&' in mo2DWLtg4qdpFiuBnYkVJPwvR0 and ';' in mo2DWLtg4qdpFiuBnYkVJPwvR0:
		if V8fmEML1b0PeaRZySnzh3H5J9: mo2DWLtg4qdpFiuBnYkVJPwvR0 = mo2DWLtg4qdpFiuBnYkVJPwvR0.decode('utf8')
		mo2DWLtg4qdpFiuBnYkVJPwvR0 = _WBQThZReowMO3ySPqltgKDuHjF(mo2DWLtg4qdpFiuBnYkVJPwvR0)
		if V8fmEML1b0PeaRZySnzh3H5J9: mo2DWLtg4qdpFiuBnYkVJPwvR0 = mo2DWLtg4qdpFiuBnYkVJPwvR0.encode('utf8')
	return mo2DWLtg4qdpFiuBnYkVJPwvR0
def tW06wVMpReHfnj3KgzT2va(mo2DWLtg4qdpFiuBnYkVJPwvR0):
	if '\\u' in mo2DWLtg4qdpFiuBnYkVJPwvR0:
		if V8fmEML1b0PeaRZySnzh3H5J9: mo2DWLtg4qdpFiuBnYkVJPwvR0 = mo2DWLtg4qdpFiuBnYkVJPwvR0.decode('unicode_escape','ignore').encode('utf8')
		elif BLz7m2RkNrxXQwy1cGAp: mo2DWLtg4qdpFiuBnYkVJPwvR0 = mo2DWLtg4qdpFiuBnYkVJPwvR0.encode('utf8').decode('unicode_escape','ignore')
	return mo2DWLtg4qdpFiuBnYkVJPwvR0
def OWF8qHVQx7Ci(HNdLKF67cp9EiO3Tn1,rRZV8w1FLS6yo0gkY7N,SHL3CzReqgf7DOnw1i40hs,ocY74KkgBbLVMmxIQiXPtG6AdRH9l8,Gfsr6KpyVRovQmB8xcXUJ,lnreTDGIK4fHuVUW,rI1UyhFJVswuloxaHT,NcDoIKkzULEW,M7hjNpoG8Qm4x):
	Rxt7AYLrcKNm4syJiBhDM2eG19FTuS = tto9IZkKWD(lnreTDGIK4fHuVUW)
	UTAYyMngpBCHKo8NLc = Sou2BEAGcLMTCh7bDXQ3W(Rxt7AYLrcKNm4syJiBhDM2eG19FTuS,HNdLKF67cp9EiO3Tn1,rRZV8w1FLS6yo0gkY7N,SHL3CzReqgf7DOnw1i40hs,ocY74KkgBbLVMmxIQiXPtG6AdRH9l8,Gfsr6KpyVRovQmB8xcXUJ,lnreTDGIK4fHuVUW,rI1UyhFJVswuloxaHT,NcDoIKkzULEW,M7hjNpoG8Qm4x)
	return UTAYyMngpBCHKo8NLc
def tto9IZkKWD(lnreTDGIK4fHuVUW):
	HhucNM0d863V7oY = 5
	P7SCdWtv2pFD8XN605kquTZ = 20
	jbKY83FS2z9 = 20
	DDSwE6mYF8J = 0
	p8G0XzRB2cLP4lsrtvx9M = 'center'
	QEsxjzvYNiRuo8Sh = 0
	f1n6FqWOtomYV3QhIkbjc0iPaslN = 19
	vWpSPVkb8EotiLCfU4KNeGF7rZm = 30
	apfEjz5hOCDvxFlr3wokGAsMLW = 8
	VRzF6QwmyidAbY5O0aEgshHu = True
	GkumSnDgwZH9TzUltsxWR = 375
	xxfe863VPg7 = 410
	AAXB1zuQwnKGlxb59D6Oi = 50
	ow7gW6cU1klXbjMe = 280
	wg9ihyFuDmo5btXOrMGlEjnceAsW = 28
	gwRsCM4rTLZfeuv1 = 5
	emOcMxzu5qNafyPWXwoi6 = 0
	DAJ0Ngkix5oTyjSPHLW3Ze7K8 = 31
	fNyXjSb8aI4rBl95VAGcHDvpo = [36,32,28]
	if lnreTDGIK4fHuVUW in ['notification','notification_twohalfs']:
		if lnreTDGIK4fHuVUW=='notification_twohalfs':
			CCcQ94N8pLrxeKnioF,nnotlQJrjUq72AP6XRkMyh3HI5WE4 = 'UPPER',720
			p8G0XzRB2cLP4lsrtvx9M = 'right'
			VRzF6QwmyidAbY5O0aEgshHu = True
			DDSwE6mYF8J = 10
		else:
			CCcQ94N8pLrxeKnioF,nnotlQJrjUq72AP6XRkMyh3HI5WE4 = 97+20,720
			p8G0XzRB2cLP4lsrtvx9M = 'left'
			VRzF6QwmyidAbY5O0aEgshHu = False
		fNyXjSb8aI4rBl95VAGcHDvpo = [33,33,33]
		jbKY83FS2z9 = 20
		P7SCdWtv2pFD8XN605kquTZ = 0
		vWpSPVkb8EotiLCfU4KNeGF7rZm = 20
		f1n6FqWOtomYV3QhIkbjc0iPaslN = 25+10
	elif lnreTDGIK4fHuVUW=='menu_item':
		fNyXjSb8aI4rBl95VAGcHDvpo,CCcQ94N8pLrxeKnioF,nnotlQJrjUq72AP6XRkMyh3HI5WE4 = [48,44,40],200,400
		vWpSPVkb8EotiLCfU4KNeGF7rZm,f1n6FqWOtomYV3QhIkbjc0iPaslN,P7SCdWtv2pFD8XN605kquTZ = 0,0,-16
		Ed7I9xaZLspCzRlvr6tjHOM8W = om54gkLrHi6DqAQ0M.open(BnmERuAU4zVg7HKJ3cs)
		x4hZ2QBwSio6m3lL = om54gkLrHi6DqAQ0M.new('RGBA',(200,200),(255,0,0,255))
	elif lnreTDGIK4fHuVUW=='confirm_smallfont': fNyXjSb8aI4rBl95VAGcHDvpo,CCcQ94N8pLrxeKnioF,nnotlQJrjUq72AP6XRkMyh3HI5WE4 = [28,24,20],500,900
	elif lnreTDGIK4fHuVUW=='confirm_mediumfont': fNyXjSb8aI4rBl95VAGcHDvpo,CCcQ94N8pLrxeKnioF,nnotlQJrjUq72AP6XRkMyh3HI5WE4 = [32,28,24],500,900
	elif lnreTDGIK4fHuVUW=='confirm_bigfont': fNyXjSb8aI4rBl95VAGcHDvpo,CCcQ94N8pLrxeKnioF,nnotlQJrjUq72AP6XRkMyh3HI5WE4 = [36,32,28],500,900
	elif lnreTDGIK4fHuVUW=='textview_bigfont': CCcQ94N8pLrxeKnioF,nnotlQJrjUq72AP6XRkMyh3HI5WE4 = 740,1270
	elif lnreTDGIK4fHuVUW=='textview_bigfont_long': CCcQ94N8pLrxeKnioF,nnotlQJrjUq72AP6XRkMyh3HI5WE4 = 'UPPER',1270
	elif lnreTDGIK4fHuVUW=='textview_smallfont': fNyXjSb8aI4rBl95VAGcHDvpo,CCcQ94N8pLrxeKnioF,nnotlQJrjUq72AP6XRkMyh3HI5WE4 = [28,23,18],740,1270
	elif lnreTDGIK4fHuVUW=='textview_smallfont_long': fNyXjSb8aI4rBl95VAGcHDvpo,CCcQ94N8pLrxeKnioF,nnotlQJrjUq72AP6XRkMyh3HI5WE4 = [28,23,18],'UPPER',1270
	FmU5J7xQEjzg9KXTLbMHkc1 = fNyXjSb8aI4rBl95VAGcHDvpo[0]
	N8tnyMu0vFJjDxhBz57dk6 = fNyXjSb8aI4rBl95VAGcHDvpo[1]
	rwDXm2LcdJ7UVPFZznMbIkRBg = fNyXjSb8aI4rBl95VAGcHDvpo[2]
	uu2MXfBDUadrpTRNV = zNnYrJKZ9PRt68BTmfhpwCoixu2d.truetype(s8sV4j7FOC0yvBctIe,size=FmU5J7xQEjzg9KXTLbMHkc1)
	NwSOWc4UxvRmg95ih3lPG6k = zNnYrJKZ9PRt68BTmfhpwCoixu2d.truetype(s8sV4j7FOC0yvBctIe,size=N8tnyMu0vFJjDxhBz57dk6)
	vBEf9YhwAq7sWzRLuO = zNnYrJKZ9PRt68BTmfhpwCoixu2d.truetype(s8sV4j7FOC0yvBctIe,size=rwDXm2LcdJ7UVPFZznMbIkRBg)
	z4MDvHZ18GlBTAYcyS = om54gkLrHi6DqAQ0M.new('RGBA',(100,100),(255,255,255,0))
	jXxpQCH6ya0BubwvMnc3lmr = UPTJpd3eoxqc6DgQ8X5bCu2IARm.Draw(z4MDvHZ18GlBTAYcyS)
	iid32jDgYT,lRjD4zY8Ewmt = jXxpQCH6ya0BubwvMnc3lmr.textsize('HHH BBB 888 000',font=NwSOWc4UxvRmg95ih3lPG6k)
	oFx8A5tWE9BhkbU2eDiSdrjIC6MY7,thHaANULRCcwdTfKrsS7g2pYZ0eW6 = jXxpQCH6ya0BubwvMnc3lmr.textsize('HHH BBB 888 000',font=uu2MXfBDUadrpTRNV)
	ZgAj7lEIkiWcwyPadNBv3hU = {'delete_harakat':False,'support_ligatures':True,'ARABIC LIGATURE ALLAH':False}
	eKPnI3vajlJEixFYz0BdC4Z = yAQdIO8psN2zSqX1KFW5BL(configuration=ZgAj7lEIkiWcwyPadNBv3hU)
	Rxt7AYLrcKNm4syJiBhDM2eG19FTuS = {}
	u3uFRlQOdJyLh = locals()
	for S2igRNm4wsYJqv7FVWxa06A in u3uFRlQOdJyLh: Rxt7AYLrcKNm4syJiBhDM2eG19FTuS[S2igRNm4wsYJqv7FVWxa06A] = u3uFRlQOdJyLh[S2igRNm4wsYJqv7FVWxa06A]
	return Rxt7AYLrcKNm4syJiBhDM2eG19FTuS
def Sou2BEAGcLMTCh7bDXQ3W(Rxt7AYLrcKNm4syJiBhDM2eG19FTuS,HNdLKF67cp9EiO3Tn1,rRZV8w1FLS6yo0gkY7N,SHL3CzReqgf7DOnw1i40hs,ocY74KkgBbLVMmxIQiXPtG6AdRH9l8,Gfsr6KpyVRovQmB8xcXUJ,lnreTDGIK4fHuVUW,rI1UyhFJVswuloxaHT,NcDoIKkzULEW,M7hjNpoG8Qm4x):
	for S2igRNm4wsYJqv7FVWxa06A in Rxt7AYLrcKNm4syJiBhDM2eG19FTuS: globals()[S2igRNm4wsYJqv7FVWxa06A] = Rxt7AYLrcKNm4syJiBhDM2eG19FTuS[S2igRNm4wsYJqv7FVWxa06A]
	global wg9ihyFuDmo5btXOrMGlEjnceAsW,gwRsCM4rTLZfeuv1
	eVpsc23G48QbgJDF5WPhfA1qNi7v = bLEBi8IO7uU2x3htYDdVq95.getSetting('av.language.translate')
	if eVpsc23G48QbgJDF5WPhfA1qNi7v:
		if HNdLKF67cp9EiO3Tn1=='نعم  Yes': HNdLKF67cp9EiO3Tn1 = 'Yes'
		elif HNdLKF67cp9EiO3Tn1=='كلا  No': HNdLKF67cp9EiO3Tn1 = 'No'
		if rRZV8w1FLS6yo0gkY7N=='نعم  Yes': rRZV8w1FLS6yo0gkY7N = 'Yes'
		elif rRZV8w1FLS6yo0gkY7N=='كلا  No': rRZV8w1FLS6yo0gkY7N = 'No'
		if SHL3CzReqgf7DOnw1i40hs=='نعم  Yes': SHL3CzReqgf7DOnw1i40hs = 'Yes'
		elif SHL3CzReqgf7DOnw1i40hs=='كلا  No': SHL3CzReqgf7DOnw1i40hs = 'No'
		fM9jDUciIqk2SutLy5Y4ngE3aWlOe = II5RxkE86THdOhoDML2Zbgc([HNdLKF67cp9EiO3Tn1,rRZV8w1FLS6yo0gkY7N,SHL3CzReqgf7DOnw1i40hs,ocY74KkgBbLVMmxIQiXPtG6AdRH9l8,Gfsr6KpyVRovQmB8xcXUJ])
		if fM9jDUciIqk2SutLy5Y4ngE3aWlOe: HNdLKF67cp9EiO3Tn1,rRZV8w1FLS6yo0gkY7N,SHL3CzReqgf7DOnw1i40hs,ocY74KkgBbLVMmxIQiXPtG6AdRH9l8,Gfsr6KpyVRovQmB8xcXUJ = fM9jDUciIqk2SutLy5Y4ngE3aWlOe
	if V8fmEML1b0PeaRZySnzh3H5J9:
		Gfsr6KpyVRovQmB8xcXUJ = Gfsr6KpyVRovQmB8xcXUJ.decode('utf8')
		ocY74KkgBbLVMmxIQiXPtG6AdRH9l8 = ocY74KkgBbLVMmxIQiXPtG6AdRH9l8.decode('utf8')
		HNdLKF67cp9EiO3Tn1 = HNdLKF67cp9EiO3Tn1.decode('utf8')
		rRZV8w1FLS6yo0gkY7N = rRZV8w1FLS6yo0gkY7N.decode('utf8')
		SHL3CzReqgf7DOnw1i40hs = SHL3CzReqgf7DOnw1i40hs.decode('utf8')
	E9NAYx1hjrOkCcpKd4XR3lQGnM5i = ocY74KkgBbLVMmxIQiXPtG6AdRH9l8.count('\n')+1
	O24sM0x3SRPD = P7SCdWtv2pFD8XN605kquTZ+E9NAYx1hjrOkCcpKd4XR3lQGnM5i*(thHaANULRCcwdTfKrsS7g2pYZ0eW6+DDSwE6mYF8J)-DDSwE6mYF8J
	if Gfsr6KpyVRovQmB8xcXUJ:
		gg2aLGkvXe3FQhjEmUr = nnotlQJrjUq72AP6XRkMyh3HI5WE4-vWpSPVkb8EotiLCfU4KNeGF7rZm*2
		C8769CInkNbAmLR = lRjD4zY8Ewmt+apfEjz5hOCDvxFlr3wokGAsMLW
		HACDuEi0QqRp7XfGwm = eKPnI3vajlJEixFYz0BdC4Z.reshape(Gfsr6KpyVRovQmB8xcXUJ)
		if VRzF6QwmyidAbY5O0aEgshHu:
			OmTLuAziFD = R5v7qnrCN1DQmcXIMtbOTG(HACDuEi0QqRp7XfGwm,N8tnyMu0vFJjDxhBz57dk6,gg2aLGkvXe3FQhjEmUr,C8769CInkNbAmLR)
			nmB7E5KfNiG2ekrvVPduTltwhS6 = pDV5FIX7w8(OmTLuAziFD)
			IS9hKwjQGRXODPakyfqrW = nmB7E5KfNiG2ekrvVPduTltwhS6.count('\n')+1
			if IS9hKwjQGRXODPakyfqrW<6:
				a80zfp9NQMPLyJ7 = gg2aLGkvXe3FQhjEmUr
				OmTLuAziFD = R5v7qnrCN1DQmcXIMtbOTG(HACDuEi0QqRp7XfGwm,N8tnyMu0vFJjDxhBz57dk6,a80zfp9NQMPLyJ7,C8769CInkNbAmLR)
				nmB7E5KfNiG2ekrvVPduTltwhS6 = pDV5FIX7w8(OmTLuAziFD)
				IS9hKwjQGRXODPakyfqrW = nmB7E5KfNiG2ekrvVPduTltwhS6.count('\n')+1
			Ggc56VorIEH = f1n6FqWOtomYV3QhIkbjc0iPaslN+IS9hKwjQGRXODPakyfqrW*C8769CInkNbAmLR-apfEjz5hOCDvxFlr3wokGAsMLW
		else:
			Ggc56VorIEH = f1n6FqWOtomYV3QhIkbjc0iPaslN+lRjD4zY8Ewmt
			nmB7E5KfNiG2ekrvVPduTltwhS6 = HACDuEi0QqRp7XfGwm.split('\n')[0]
			OmTLuAziFD = HACDuEi0QqRp7XfGwm.split('\n')[0]
	else: Ggc56VorIEH = f1n6FqWOtomYV3QhIkbjc0iPaslN
	mtf5ehz4aP6y = emOcMxzu5qNafyPWXwoi6+DAJ0Ngkix5oTyjSPHLW3Ze7K8
	if NcDoIKkzULEW:
		sbMwcP4ulqDf = xxfe863VPg7-GkumSnDgwZH9TzUltsxWR
		mtf5ehz4aP6y += sbMwcP4ulqDf
	else: sbMwcP4ulqDf = 0
	if HNdLKF67cp9EiO3Tn1 or rRZV8w1FLS6yo0gkY7N or SHL3CzReqgf7DOnw1i40hs: mtf5ehz4aP6y += AAXB1zuQwnKGlxb59D6Oi
	if CCcQ94N8pLrxeKnioF!='UPPER': UTAYyMngpBCHKo8NLc = CCcQ94N8pLrxeKnioF
	else: UTAYyMngpBCHKo8NLc = O24sM0x3SRPD+Ggc56VorIEH+mtf5ehz4aP6y
	TDrRytixInf2v4H = UTAYyMngpBCHKo8NLc-O24sM0x3SRPD-mtf5ehz4aP6y-f1n6FqWOtomYV3QhIkbjc0iPaslN
	z4MDvHZ18GlBTAYcyS = om54gkLrHi6DqAQ0M.new('RGBA',(nnotlQJrjUq72AP6XRkMyh3HI5WE4,UTAYyMngpBCHKo8NLc),(255,255,255,0))
	jXxpQCH6ya0BubwvMnc3lmr = UPTJpd3eoxqc6DgQ8X5bCu2IARm.Draw(z4MDvHZ18GlBTAYcyS)
	if not rRZV8w1FLS6yo0gkY7N and HNdLKF67cp9EiO3Tn1 and SHL3CzReqgf7DOnw1i40hs:
		wg9ihyFuDmo5btXOrMGlEjnceAsW += 105
		gwRsCM4rTLZfeuv1 -= 110
	if ocY74KkgBbLVMmxIQiXPtG6AdRH9l8:
		J8V7i9MbRmTwqgsNdOpvCFK5lAa0 = P7SCdWtv2pFD8XN605kquTZ
		ocY74KkgBbLVMmxIQiXPtG6AdRH9l8 = mFS3RqXrOoUsMcx5GD0jKfI.get_display(eKPnI3vajlJEixFYz0BdC4Z.reshape(ocY74KkgBbLVMmxIQiXPtG6AdRH9l8))
		Zb6XVxojEdJCGWBYnFm9qIpu = ocY74KkgBbLVMmxIQiXPtG6AdRH9l8.splitlines()
		for mK69jMeAkOl1I3tF5HGPJRgr in Zb6XVxojEdJCGWBYnFm9qIpu:
			if mK69jMeAkOl1I3tF5HGPJRgr:
				t297FihLEJIUNOCodzM1lYsHDpZ4,dx6fgHcZ3N92mKrYjqCAQ = jXxpQCH6ya0BubwvMnc3lmr.textsize(mK69jMeAkOl1I3tF5HGPJRgr,font=uu2MXfBDUadrpTRNV)
				if p8G0XzRB2cLP4lsrtvx9M=='center': b74Cq50zBKP9IAkmHuRS1UgVE = HhucNM0d863V7oY+(nnotlQJrjUq72AP6XRkMyh3HI5WE4-t297FihLEJIUNOCodzM1lYsHDpZ4)/2
				elif p8G0XzRB2cLP4lsrtvx9M=='right': b74Cq50zBKP9IAkmHuRS1UgVE = HhucNM0d863V7oY+nnotlQJrjUq72AP6XRkMyh3HI5WE4-t297FihLEJIUNOCodzM1lYsHDpZ4-jbKY83FS2z9
				elif p8G0XzRB2cLP4lsrtvx9M=='left': b74Cq50zBKP9IAkmHuRS1UgVE = HhucNM0d863V7oY+jbKY83FS2z9
				jXxpQCH6ya0BubwvMnc3lmr.text((b74Cq50zBKP9IAkmHuRS1UgVE,J8V7i9MbRmTwqgsNdOpvCFK5lAa0),mK69jMeAkOl1I3tF5HGPJRgr,font=uu2MXfBDUadrpTRNV,fill='yellow')
			J8V7i9MbRmTwqgsNdOpvCFK5lAa0 += FmU5J7xQEjzg9KXTLbMHkc1+DDSwE6mYF8J
	if HNdLKF67cp9EiO3Tn1 or rRZV8w1FLS6yo0gkY7N or SHL3CzReqgf7DOnw1i40hs:
		kgqVEosu1FaxRYNPCMJ = O24sM0x3SRPD+TDrRytixInf2v4H+f1n6FqWOtomYV3QhIkbjc0iPaslN+sbMwcP4ulqDf+emOcMxzu5qNafyPWXwoi6
		if HNdLKF67cp9EiO3Tn1:
			HNdLKF67cp9EiO3Tn1 = mFS3RqXrOoUsMcx5GD0jKfI.get_display(eKPnI3vajlJEixFYz0BdC4Z.reshape(HNdLKF67cp9EiO3Tn1))
			PMXCuydE5VmeI14q7oAzQJGlHpr3K,Crk31YRj84iGEMJ5cT = jXxpQCH6ya0BubwvMnc3lmr.textsize(HNdLKF67cp9EiO3Tn1,font=vBEf9YhwAq7sWzRLuO)
			h3zqR7xov86LH04CnreiYmPQIJsEU = wg9ihyFuDmo5btXOrMGlEjnceAsW+0*(gwRsCM4rTLZfeuv1+ow7gW6cU1klXbjMe)+(ow7gW6cU1klXbjMe-PMXCuydE5VmeI14q7oAzQJGlHpr3K)/2
			jXxpQCH6ya0BubwvMnc3lmr.text((h3zqR7xov86LH04CnreiYmPQIJsEU,kgqVEosu1FaxRYNPCMJ),HNdLKF67cp9EiO3Tn1,font=vBEf9YhwAq7sWzRLuO,fill='yellow')
		if rRZV8w1FLS6yo0gkY7N:
			rRZV8w1FLS6yo0gkY7N = mFS3RqXrOoUsMcx5GD0jKfI.get_display(eKPnI3vajlJEixFYz0BdC4Z.reshape(rRZV8w1FLS6yo0gkY7N))
			kmHY1TzQ58i0Z9,fGPWrQU8mZISNDu4YC2 = jXxpQCH6ya0BubwvMnc3lmr.textsize(rRZV8w1FLS6yo0gkY7N,font=vBEf9YhwAq7sWzRLuO)
			nnHb7CSQTDdV = wg9ihyFuDmo5btXOrMGlEjnceAsW+1*(gwRsCM4rTLZfeuv1+ow7gW6cU1klXbjMe)+(ow7gW6cU1klXbjMe-kmHY1TzQ58i0Z9)/2
			jXxpQCH6ya0BubwvMnc3lmr.text((nnHb7CSQTDdV,kgqVEosu1FaxRYNPCMJ),rRZV8w1FLS6yo0gkY7N,font=vBEf9YhwAq7sWzRLuO,fill='yellow')
		if SHL3CzReqgf7DOnw1i40hs:
			SHL3CzReqgf7DOnw1i40hs = mFS3RqXrOoUsMcx5GD0jKfI.get_display(eKPnI3vajlJEixFYz0BdC4Z.reshape(SHL3CzReqgf7DOnw1i40hs))
			H17wvsFMtja2,iiwXxJTFIQDRlEp4s = jXxpQCH6ya0BubwvMnc3lmr.textsize(SHL3CzReqgf7DOnw1i40hs,font=vBEf9YhwAq7sWzRLuO)
			AYP5EChqprFioLy7VKUb = wg9ihyFuDmo5btXOrMGlEjnceAsW+2*(gwRsCM4rTLZfeuv1+ow7gW6cU1klXbjMe)+(ow7gW6cU1klXbjMe-H17wvsFMtja2)/2
			jXxpQCH6ya0BubwvMnc3lmr.text((AYP5EChqprFioLy7VKUb,kgqVEosu1FaxRYNPCMJ),SHL3CzReqgf7DOnw1i40hs,font=vBEf9YhwAq7sWzRLuO,fill='yellow')
	if Gfsr6KpyVRovQmB8xcXUJ:
		xVIyjFquQrfXZ23Bsd,VyDUJxXNfvgGb2e61MAHE8 = [],[]
		OmTLuAziFD = mnTj4MrPWk3FaLYub5d2xptE(OmTLuAziFD)
		u1BVXt6ofWbwdnsvaLRx2 = OmTLuAziFD.split('_sss__newline_')
		for Ns2gLXDpq46nv9Ef in u1BVXt6ofWbwdnsvaLRx2:
			JNXOovVBeCgbPMDd57WjG2fs = rI1UyhFJVswuloxaHT
			if   '_sss__lineleft_' in Ns2gLXDpq46nv9Ef: JNXOovVBeCgbPMDd57WjG2fs = 'left'
			elif '_sss__lineright_' in Ns2gLXDpq46nv9Ef: JNXOovVBeCgbPMDd57WjG2fs = 'right'
			elif '_sss__linecenter_' in Ns2gLXDpq46nv9Ef: JNXOovVBeCgbPMDd57WjG2fs = 'center'
			z5lI76QwmJxFP8kE = Ns2gLXDpq46nv9Ef
			N9flRMF5VKwUpEyS0BPnqT3r4kYdt = My7Dwqvs6bfGNSIgX.findall('_sss__.*?_',Ns2gLXDpq46nv9Ef,My7Dwqvs6bfGNSIgX.DOTALL)
			for ljTCgLAW4iKuDNaGMcw0rv3Eos in N9flRMF5VKwUpEyS0BPnqT3r4kYdt: z5lI76QwmJxFP8kE = z5lI76QwmJxFP8kE.replace(ljTCgLAW4iKuDNaGMcw0rv3Eos,'')
			if z5lI76QwmJxFP8kE=='': t297FihLEJIUNOCodzM1lYsHDpZ4,dx6fgHcZ3N92mKrYjqCAQ = 0,C8769CInkNbAmLR
			else: t297FihLEJIUNOCodzM1lYsHDpZ4,dx6fgHcZ3N92mKrYjqCAQ = jXxpQCH6ya0BubwvMnc3lmr.textsize(z5lI76QwmJxFP8kE,font=NwSOWc4UxvRmg95ih3lPG6k)
			if   JNXOovVBeCgbPMDd57WjG2fs=='left': ZDdalFPqNRp4k7IgEB5U6w = QEsxjzvYNiRuo8Sh+vWpSPVkb8EotiLCfU4KNeGF7rZm
			elif JNXOovVBeCgbPMDd57WjG2fs=='right': ZDdalFPqNRp4k7IgEB5U6w = QEsxjzvYNiRuo8Sh+vWpSPVkb8EotiLCfU4KNeGF7rZm+gg2aLGkvXe3FQhjEmUr-t297FihLEJIUNOCodzM1lYsHDpZ4
			elif JNXOovVBeCgbPMDd57WjG2fs=='center': ZDdalFPqNRp4k7IgEB5U6w = QEsxjzvYNiRuo8Sh+vWpSPVkb8EotiLCfU4KNeGF7rZm+(gg2aLGkvXe3FQhjEmUr-t297FihLEJIUNOCodzM1lYsHDpZ4)/2
			if ZDdalFPqNRp4k7IgEB5U6w<vWpSPVkb8EotiLCfU4KNeGF7rZm: ZDdalFPqNRp4k7IgEB5U6w = QEsxjzvYNiRuo8Sh+vWpSPVkb8EotiLCfU4KNeGF7rZm
			xVIyjFquQrfXZ23Bsd.append(ZDdalFPqNRp4k7IgEB5U6w)
			VyDUJxXNfvgGb2e61MAHE8.append(t297FihLEJIUNOCodzM1lYsHDpZ4)
		ZDdalFPqNRp4k7IgEB5U6w = xVIyjFquQrfXZ23Bsd[0]
		S8wmcPFeiGl4jHVKd = OmTLuAziFD.split('_sss_')
		FNx0KusTX7ELMi = (255,255,255,255)
		wBERJUx0sZn = FNx0KusTX7ELMi
		dCRp3aMz0VIb,GY7sVbJOy2jA8Sq0M6 = 0,0
		lrjLXDkmRIuPtZBSeWs2pM8wCN = False
		G8kmanyph7B6HZseflXrbT1 = 0
		jiMv2NyrmbWnaldo = O24sM0x3SRPD+f1n6FqWOtomYV3QhIkbjc0iPaslN/2
		if Ggc56VorIEH<(TDrRytixInf2v4H+f1n6FqWOtomYV3QhIkbjc0iPaslN):
			AHOpeRkumbrZcDQM3 = (TDrRytixInf2v4H+f1n6FqWOtomYV3QhIkbjc0iPaslN-Ggc56VorIEH)/2
			jiMv2NyrmbWnaldo = O24sM0x3SRPD+f1n6FqWOtomYV3QhIkbjc0iPaslN+AHOpeRkumbrZcDQM3-lRjD4zY8Ewmt/2
		for mK69jMeAkOl1I3tF5HGPJRgr in S8wmcPFeiGl4jHVKd:
			if not mK69jMeAkOl1I3tF5HGPJRgr or (mK69jMeAkOl1I3tF5HGPJRgr and ord(mK69jMeAkOl1I3tF5HGPJRgr[0])==65279): continue
			ooAh170MY5KCrvfRSiPJkb3VLW = mK69jMeAkOl1I3tF5HGPJRgr.split('_newline_',1)
			KAp0HXgzjTByiuGcovZ8dQeDEP = mK69jMeAkOl1I3tF5HGPJRgr.split('_newcolor',1)
			T1fp8ex4rjXkOABKEgRZl9UFo5wz = mK69jMeAkOl1I3tF5HGPJRgr.split('_endcolor_',1)
			IIYJAnPpilQOVF6XRB = mK69jMeAkOl1I3tF5HGPJRgr.split('_linertl_',1)
			NocSyI96BCfZ8GwX7m2 = mK69jMeAkOl1I3tF5HGPJRgr.split('_lineleft_',1)
			viOBH8EZNramh2J = mK69jMeAkOl1I3tF5HGPJRgr.split('_lineright_',1)
			J38HA0FkBpU5oMeZQxY = mK69jMeAkOl1I3tF5HGPJRgr.split('_linecenter_',1)
			if len(ooAh170MY5KCrvfRSiPJkb3VLW)>1:
				G8kmanyph7B6HZseflXrbT1 += 1
				mK69jMeAkOl1I3tF5HGPJRgr = ooAh170MY5KCrvfRSiPJkb3VLW[1]
				dCRp3aMz0VIb = 0
				ZDdalFPqNRp4k7IgEB5U6w = xVIyjFquQrfXZ23Bsd[G8kmanyph7B6HZseflXrbT1]
				GY7sVbJOy2jA8Sq0M6 += C8769CInkNbAmLR
				lrjLXDkmRIuPtZBSeWs2pM8wCN = False
			elif len(KAp0HXgzjTByiuGcovZ8dQeDEP)>1:
				mK69jMeAkOl1I3tF5HGPJRgr = KAp0HXgzjTByiuGcovZ8dQeDEP[1]
				wBERJUx0sZn = mK69jMeAkOl1I3tF5HGPJRgr[0:8]
				wBERJUx0sZn = '#'+wBERJUx0sZn[2:]
				mK69jMeAkOl1I3tF5HGPJRgr = mK69jMeAkOl1I3tF5HGPJRgr[9:]
			elif len(T1fp8ex4rjXkOABKEgRZl9UFo5wz)>1:
				mK69jMeAkOl1I3tF5HGPJRgr = T1fp8ex4rjXkOABKEgRZl9UFo5wz[1]
				wBERJUx0sZn = FNx0KusTX7ELMi
			elif len(IIYJAnPpilQOVF6XRB)>1:
				mK69jMeAkOl1I3tF5HGPJRgr = IIYJAnPpilQOVF6XRB[1]
				lrjLXDkmRIuPtZBSeWs2pM8wCN = True
				dCRp3aMz0VIb = VyDUJxXNfvgGb2e61MAHE8[G8kmanyph7B6HZseflXrbT1]
			elif len(NocSyI96BCfZ8GwX7m2)>1: mK69jMeAkOl1I3tF5HGPJRgr = NocSyI96BCfZ8GwX7m2[1]
			elif len(viOBH8EZNramh2J)>1: mK69jMeAkOl1I3tF5HGPJRgr = viOBH8EZNramh2J[1]
			elif len(J38HA0FkBpU5oMeZQxY)>1: mK69jMeAkOl1I3tF5HGPJRgr = J38HA0FkBpU5oMeZQxY[1]
			if mK69jMeAkOl1I3tF5HGPJRgr:
				DTLKazvpiPRbWe = jiMv2NyrmbWnaldo+GY7sVbJOy2jA8Sq0M6
				mK69jMeAkOl1I3tF5HGPJRgr = mFS3RqXrOoUsMcx5GD0jKfI.get_display(mK69jMeAkOl1I3tF5HGPJRgr)
				t297FihLEJIUNOCodzM1lYsHDpZ4,dx6fgHcZ3N92mKrYjqCAQ = jXxpQCH6ya0BubwvMnc3lmr.textsize(mK69jMeAkOl1I3tF5HGPJRgr,font=NwSOWc4UxvRmg95ih3lPG6k)
				if lrjLXDkmRIuPtZBSeWs2pM8wCN: dCRp3aMz0VIb -= t297FihLEJIUNOCodzM1lYsHDpZ4
				JcHB4SqjwAXUTkQzhMn1Ydx = ZDdalFPqNRp4k7IgEB5U6w+dCRp3aMz0VIb
				jXxpQCH6ya0BubwvMnc3lmr.text((JcHB4SqjwAXUTkQzhMn1Ydx,DTLKazvpiPRbWe),mK69jMeAkOl1I3tF5HGPJRgr,font=NwSOWc4UxvRmg95ih3lPG6k,fill=wBERJUx0sZn)
				if lnreTDGIK4fHuVUW=='menu_item':
					jXxpQCH6ya0BubwvMnc3lmr.text((JcHB4SqjwAXUTkQzhMn1Ydx+1,DTLKazvpiPRbWe+1),mK69jMeAkOl1I3tF5HGPJRgr,font=NwSOWc4UxvRmg95ih3lPG6k,fill=wBERJUx0sZn)
				if not lrjLXDkmRIuPtZBSeWs2pM8wCN: dCRp3aMz0VIb += t297FihLEJIUNOCodzM1lYsHDpZ4
				if DTLKazvpiPRbWe>TDrRytixInf2v4H+C8769CInkNbAmLR: break
	if lnreTDGIK4fHuVUW=='menu_item':
		z4MDvHZ18GlBTAYcyS = z4MDvHZ18GlBTAYcyS.resize((200,200))
		sfZvYVI5PnaoykW3jKdL278iJA = Ed7I9xaZLspCzRlvr6tjHOM8W.copy()
		sfZvYVI5PnaoykW3jKdL278iJA.paste(x4hZ2QBwSio6m3lL,(0,0),mask=z4MDvHZ18GlBTAYcyS)
	else: sfZvYVI5PnaoykW3jKdL278iJA = z4MDvHZ18GlBTAYcyS
	if V8fmEML1b0PeaRZySnzh3H5J9: M7hjNpoG8Qm4x = M7hjNpoG8Qm4x.decode('utf8')
	try: sfZvYVI5PnaoykW3jKdL278iJA.save(M7hjNpoG8Qm4x)
	except:
		WvMjRTruLYbs = XXRtDhYvWb35qnLBxIri7ScNUks0.path.dirname(M7hjNpoG8Qm4x)
		try: XXRtDhYvWb35qnLBxIri7ScNUks0.makedirs(WvMjRTruLYbs)
		except: pass
		sfZvYVI5PnaoykW3jKdL278iJA.save(M7hjNpoG8Qm4x)
	return UTAYyMngpBCHKo8NLc
def R5v7qnrCN1DQmcXIMtbOTG(sfF2iRbGaMTnAJqdyB4e8NPjVZ,ccPrfyuJj3m94qLK6MWepgQ,SSTj4cV7fHezIaR3xbl6snXgd12,Zw4p27OtUEScV1kLgHR):
	KHh79pMoJ352Tawkq4GlxFUIZPjzAn,G7fYjqxiaKCPlyhOItW,lQeNz2pft3 = '',0,15000
	sfF2iRbGaMTnAJqdyB4e8NPjVZ = sfF2iRbGaMTnAJqdyB4e8NPjVZ.replace('[COLOR ','[COLOR:::')
	F2INAhrfPStQ7Ex8KbwzVqiskyHmR = zNnYrJKZ9PRt68BTmfhpwCoixu2d.truetype(s8sV4j7FOC0yvBctIe,size=ccPrfyuJj3m94qLK6MWepgQ)
	SSTj4cV7fHezIaR3xbl6snXgd12 -= ccPrfyuJj3m94qLK6MWepgQ*2
	z4MDvHZ18GlBTAYcyS = om54gkLrHi6DqAQ0M.new('RGBA',(SSTj4cV7fHezIaR3xbl6snXgd12,99),(255,255,255,0))
	jXxpQCH6ya0BubwvMnc3lmr = UPTJpd3eoxqc6DgQ8X5bCu2IARm.Draw(z4MDvHZ18GlBTAYcyS)
	for vcPRQmUTw1WoZu in sfF2iRbGaMTnAJqdyB4e8NPjVZ.splitlines():
		G7fYjqxiaKCPlyhOItW += Zw4p27OtUEScV1kLgHR
		KK57Gcpy8b4S0jtJhAxrwNTOV6X,l57l6bxYfcTWMq = 0,''
		for Df0mXPEObavl6jzCyxp in vcPRQmUTw1WoZu.split(' '):
			l8ZhqgMB5Kd3UxeCRiyLsQ = pDV5FIX7w8(' '+Df0mXPEObavl6jzCyxp)
			TYI2EomNfKpMj1sW,iDM2WaZIwS = jXxpQCH6ya0BubwvMnc3lmr.textsize(l8ZhqgMB5Kd3UxeCRiyLsQ,font=F2INAhrfPStQ7Ex8KbwzVqiskyHmR)
			if KK57Gcpy8b4S0jtJhAxrwNTOV6X+TYI2EomNfKpMj1sW<SSTj4cV7fHezIaR3xbl6snXgd12:
				if not l57l6bxYfcTWMq: l57l6bxYfcTWMq += Df0mXPEObavl6jzCyxp
				else: l57l6bxYfcTWMq += ' '+Df0mXPEObavl6jzCyxp
				KK57Gcpy8b4S0jtJhAxrwNTOV6X += TYI2EomNfKpMj1sW
			else:
				if TYI2EomNfKpMj1sW<SSTj4cV7fHezIaR3xbl6snXgd12:
					l57l6bxYfcTWMq += '\n '+Df0mXPEObavl6jzCyxp
					G7fYjqxiaKCPlyhOItW += Zw4p27OtUEScV1kLgHR
					KK57Gcpy8b4S0jtJhAxrwNTOV6X = TYI2EomNfKpMj1sW
				else:
					while TYI2EomNfKpMj1sW>SSTj4cV7fHezIaR3xbl6snXgd12:
						for NnacyGSwPsCe18JuHpz0XQRt in range(1,len(' '+Df0mXPEObavl6jzCyxp),1):
							T0Ps7tDvgzIEZN6LU = ' '+Df0mXPEObavl6jzCyxp[:NnacyGSwPsCe18JuHpz0XQRt]
							dyVj2Y0A3E = Df0mXPEObavl6jzCyxp[NnacyGSwPsCe18JuHpz0XQRt:]
							LszRQ3lC7Sn = pDV5FIX7w8(T0Ps7tDvgzIEZN6LU)
							HsKTjvAdVp5cYf2J9Ml41,Vo2U1OIt6FQpsG0E = jXxpQCH6ya0BubwvMnc3lmr.textsize(LszRQ3lC7Sn,font=F2INAhrfPStQ7Ex8KbwzVqiskyHmR)
							if KK57Gcpy8b4S0jtJhAxrwNTOV6X+HsKTjvAdVp5cYf2J9Ml41>SSTj4cV7fHezIaR3xbl6snXgd12:
								jaoJfuB3KElTe = TYI2EomNfKpMj1sW-HsKTjvAdVp5cYf2J9Ml41
								l57l6bxYfcTWMq += T0Ps7tDvgzIEZN6LU+'\n'
								G7fYjqxiaKCPlyhOItW += Zw4p27OtUEScV1kLgHR
								TYI2EomNfKpMj1sW = jaoJfuB3KElTe
								if jaoJfuB3KElTe>SSTj4cV7fHezIaR3xbl6snXgd12:
									KK57Gcpy8b4S0jtJhAxrwNTOV6X = 0
									Df0mXPEObavl6jzCyxp = dyVj2Y0A3E
								else:
									KK57Gcpy8b4S0jtJhAxrwNTOV6X = jaoJfuB3KElTe
									l57l6bxYfcTWMq += dyVj2Y0A3E
								break
				if G7fYjqxiaKCPlyhOItW>lQeNz2pft3: break
		KHh79pMoJ352Tawkq4GlxFUIZPjzAn += '\n'+l57l6bxYfcTWMq
		if G7fYjqxiaKCPlyhOItW>lQeNz2pft3: break
	KHh79pMoJ352Tawkq4GlxFUIZPjzAn = KHh79pMoJ352Tawkq4GlxFUIZPjzAn[1:]
	KHh79pMoJ352Tawkq4GlxFUIZPjzAn = KHh79pMoJ352Tawkq4GlxFUIZPjzAn.replace('[COLOR:::','[COLOR ')
	return KHh79pMoJ352Tawkq4GlxFUIZPjzAn
def pDV5FIX7w8(Df0mXPEObavl6jzCyxp):
	if '[' in Df0mXPEObavl6jzCyxp and ']' in Df0mXPEObavl6jzCyxp:
		N9flRMF5VKwUpEyS0BPnqT3r4kYdt = ['[/COLOR]','[/RTL]','[/LEFT]','[/RIGHT]','[/CENTER]','[RTL]','[LEFT]','[RIGHT]','[CENTER]']
		SFwHpdAgIMfu9m0esO2n = My7Dwqvs6bfGNSIgX.findall('\[COLOR .*?\]',Df0mXPEObavl6jzCyxp,My7Dwqvs6bfGNSIgX.DOTALL)
		MfDparZL0Oc1 = My7Dwqvs6bfGNSIgX.findall('\[COLOR:::.*?\]',Df0mXPEObavl6jzCyxp,My7Dwqvs6bfGNSIgX.DOTALL)
		KKElsQ5yb8WT = N9flRMF5VKwUpEyS0BPnqT3r4kYdt+SFwHpdAgIMfu9m0esO2n+MfDparZL0Oc1
		for ljTCgLAW4iKuDNaGMcw0rv3Eos in KKElsQ5yb8WT: Df0mXPEObavl6jzCyxp = Df0mXPEObavl6jzCyxp.replace(ljTCgLAW4iKuDNaGMcw0rv3Eos,'')
	return Df0mXPEObavl6jzCyxp
def mnTj4MrPWk3FaLYub5d2xptE(Gfsr6KpyVRovQmB8xcXUJ):
	Gfsr6KpyVRovQmB8xcXUJ = Gfsr6KpyVRovQmB8xcXUJ.replace('\n','_sss__newline_')
	Gfsr6KpyVRovQmB8xcXUJ = Gfsr6KpyVRovQmB8xcXUJ.replace('[RTL]','_sss__linertl_')
	Gfsr6KpyVRovQmB8xcXUJ = Gfsr6KpyVRovQmB8xcXUJ.replace('[LEFT]','_sss__lineleft_')
	Gfsr6KpyVRovQmB8xcXUJ = Gfsr6KpyVRovQmB8xcXUJ.replace('[RIGHT]','_sss__lineright_')
	Gfsr6KpyVRovQmB8xcXUJ = Gfsr6KpyVRovQmB8xcXUJ.replace('[CENTER]','_sss__linecenter_')
	Gfsr6KpyVRovQmB8xcXUJ = Gfsr6KpyVRovQmB8xcXUJ.replace('[/COLOR]','_sss__endcolor_')
	lIgWotSxVQm2dKPrkzJ65 = My7Dwqvs6bfGNSIgX.findall('\[COLOR (.*?)\]',Gfsr6KpyVRovQmB8xcXUJ,My7Dwqvs6bfGNSIgX.DOTALL)
	for WGcLP9alVZD in lIgWotSxVQm2dKPrkzJ65: Gfsr6KpyVRovQmB8xcXUJ = Gfsr6KpyVRovQmB8xcXUJ.replace('[COLOR '+WGcLP9alVZD+']','_sss__newcolor'+WGcLP9alVZD+'_')
	return Gfsr6KpyVRovQmB8xcXUJ
def E4L13O2bxwRDSX(bSxczpUtHewVDKa3EL4lm=''):
	if not bSxczpUtHewVDKa3EL4lm: bSxczpUtHewVDKa3EL4lm = tUXmK5PeEH9SDq.getInfoLabel('ListItem.Label')
	bSxczpUtHewVDKa3EL4lm = bSxczpUtHewVDKa3EL4lm.replace('[/COLOR]','')
	bSxczpUtHewVDKa3EL4lm = bSxczpUtHewVDKa3EL4lm.replace('    ',' ').replace('   ',' ').replace('  ',' ').strip(' ')
	bSxczpUtHewVDKa3EL4lm = bSxczpUtHewVDKa3EL4lm.replace('[COLOR FFFFFF00]','').replace('[COLOR FFC89008]','')
	FYC1nIuVchKx8ka2w9ei0BtWm = My7Dwqvs6bfGNSIgX.findall('\d\d:\d\d ',bSxczpUtHewVDKa3EL4lm,My7Dwqvs6bfGNSIgX.DOTALL)
	if FYC1nIuVchKx8ka2w9ei0BtWm: bSxczpUtHewVDKa3EL4lm = bSxczpUtHewVDKa3EL4lm.split(FYC1nIuVchKx8ka2w9ei0BtWm[0],1)[1]
	if not bSxczpUtHewVDKa3EL4lm: bSxczpUtHewVDKa3EL4lm = 'Main Menu'
	return bSxczpUtHewVDKa3EL4lm
def hQd4Ygra5ZHWiP0UuJpj7TfI(OJ0YcMKXfR2G5):
	bZsS0DBfzJid9vohR2HrWxwQFKpek = ''.join(NnacyGSwPsCe18JuHpz0XQRt for NnacyGSwPsCe18JuHpz0XQRt in OJ0YcMKXfR2G5 if NnacyGSwPsCe18JuHpz0XQRt not in '\/":*?<>|'+OMFrsZopHK9m7w45bY01idRqBL)
	return bZsS0DBfzJid9vohR2HrWxwQFKpek
def wuvsjzM2pegnkIAS3(EoulZdO2FQmDYrqNbA1kagMp):
	llvE0P6BGtj = My7Dwqvs6bfGNSIgX.findall("adilbo_HTML_encoder(.*?)/g.....(.*?)\)",EoulZdO2FQmDYrqNbA1kagMp,My7Dwqvs6bfGNSIgX.S)
	if llvE0P6BGtj:
		uuo0icStNGpnFrKBk2VQHYX5g8,RrF3CPIap4Ubj62eMgK5ct8vW = llvE0P6BGtj[0]
		uuo0icStNGpnFrKBk2VQHYX5g8 = My7Dwqvs6bfGNSIgX.findall("=[\r\n\s\t]+'(.*?)';", uuo0icStNGpnFrKBk2VQHYX5g8, My7Dwqvs6bfGNSIgX.S)[0]
		if uuo0icStNGpnFrKBk2VQHYX5g8 and RrF3CPIap4Ubj62eMgK5ct8vW:
			mSs1FMhHq8 = uuo0icStNGpnFrKBk2VQHYX5g8.replace("'",'').replace("+",'').replace("\n",'').replace("\r",'')
			Y1Qu0ZsHSPGrV = mSs1FMhHq8.split('.')
			EoulZdO2FQmDYrqNbA1kagMp = ''
			for bbdhX9QR1E7fCSM in Y1Qu0ZsHSPGrV:
				xKhduz4MwXytP = NfzkjQicS24ZYLMWuXFRwV5Ea7.b64decode(bbdhX9QR1E7fCSM+'==').decode('utf8')
				kTe70iyqFrfhwzGgoLRbHl6dtcV8 = My7Dwqvs6bfGNSIgX.findall('\d+', xKhduz4MwXytP, My7Dwqvs6bfGNSIgX.S)
				if kTe70iyqFrfhwzGgoLRbHl6dtcV8:
					DaRM9Ncuo178PZFik2jYIy4 = int(kTe70iyqFrfhwzGgoLRbHl6dtcV8[0])
					DaRM9Ncuo178PZFik2jYIy4 += int(RrF3CPIap4Ubj62eMgK5ct8vW)
					EoulZdO2FQmDYrqNbA1kagMp = EoulZdO2FQmDYrqNbA1kagMp + chr(DaRM9Ncuo178PZFik2jYIy4)
			if BLz7m2RkNrxXQwy1cGAp: EoulZdO2FQmDYrqNbA1kagMp = EoulZdO2FQmDYrqNbA1kagMp.encode('iso-8859-1').decode('utf8')
	return EoulZdO2FQmDYrqNbA1kagMp
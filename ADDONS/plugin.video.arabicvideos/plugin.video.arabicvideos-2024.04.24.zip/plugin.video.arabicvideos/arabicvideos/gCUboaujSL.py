# -*- coding: utf-8 -*-
import sys as ehpURIi6QBDOGu8qj5EYzXrsWHJ7
hEJlvpt9LRO = ehpURIi6QBDOGu8qj5EYzXrsWHJ7.version_info [0] == 2
RrwvuxJ2OXsWnE9fzYNPDqS = 2048
pS1kDZ93ogBi50Hm7elLhEcyFfTx = 7
def E6Xo0wuA9fdQKlGOI (Ovquk0bMSPEL1ciQ73BJ2Ae):
	global Xb8HYvTBqV5RFAhE3KwMjC
	G4LMt9nR3Se6xWNpPuJd = ord (Ovquk0bMSPEL1ciQ73BJ2Ae [-1])
	qkDvfXryhi7cSz5Ee4AtVn0 = Ovquk0bMSPEL1ciQ73BJ2Ae [:-1]
	FEcyWfSHeL5Kotpx = G4LMt9nR3Se6xWNpPuJd % len (qkDvfXryhi7cSz5Ee4AtVn0)
	FPhirCoHEGw3I05B = qkDvfXryhi7cSz5Ee4AtVn0 [:FEcyWfSHeL5Kotpx] + qkDvfXryhi7cSz5Ee4AtVn0 [FEcyWfSHeL5Kotpx:]
	if hEJlvpt9LRO:
		ffWep5hGgyVTXHL1SM = unicode () .join ([unichr (ord (DDX7Qar0kqlIAKHdwnEh) - RrwvuxJ2OXsWnE9fzYNPDqS - (XapSRJwDcy5TEK0QHZr6n + G4LMt9nR3Se6xWNpPuJd) % pS1kDZ93ogBi50Hm7elLhEcyFfTx) for XapSRJwDcy5TEK0QHZr6n, DDX7Qar0kqlIAKHdwnEh in enumerate (FPhirCoHEGw3I05B)])
	else:
		ffWep5hGgyVTXHL1SM = str () .join ([chr (ord (DDX7Qar0kqlIAKHdwnEh) - RrwvuxJ2OXsWnE9fzYNPDqS - (XapSRJwDcy5TEK0QHZr6n + G4LMt9nR3Se6xWNpPuJd) % pS1kDZ93ogBi50Hm7elLhEcyFfTx) for XapSRJwDcy5TEK0QHZr6n, DDX7Qar0kqlIAKHdwnEh in enumerate (FPhirCoHEGw3I05B)])
	return eval (ffWep5hGgyVTXHL1SM)
fY5wTlhtnOc0Er6sdy4k87b,C2jP0iLNGKnHu9xp,UnWjVbo503mEMv9KF=E6Xo0wuA9fdQKlGOI,E6Xo0wuA9fdQKlGOI,E6Xo0wuA9fdQKlGOI
jx7s8T0BFgODXLMzIYedf,UxS67uoGThbMwnfNRzy4gajLd23JH,QynMHGWA0blfqTUdxRh5Jzi2t=UnWjVbo503mEMv9KF,C2jP0iLNGKnHu9xp,fY5wTlhtnOc0Er6sdy4k87b
jSu5Cg2Ub1OAkZVs8Yoz,V2RbfGOBdcA6l8NTsPWzEyvS7,LgpdP3UjFRnlX=QynMHGWA0blfqTUdxRh5Jzi2t,UxS67uoGThbMwnfNRzy4gajLd23JH,jx7s8T0BFgODXLMzIYedf
gItVahxL0w,BmcLzCFjuIrZP5fwXH18aN6YS,qbPw1d3KimF=LgpdP3UjFRnlX,V2RbfGOBdcA6l8NTsPWzEyvS7,jSu5Cg2Ub1OAkZVs8Yoz
EAc8h2sINroQYvR3WH06Ji7MVpn,vvHpKfcqRnrFzjG,l0WAe1f7Bpi5ZXk=qbPw1d3KimF,BmcLzCFjuIrZP5fwXH18aN6YS,gItVahxL0w
YB5xyI7MaRslVpv,PPNA7jWqZgDnXKVvtuai1kQdsEoMb0,BK9OvRSjZbtx7kYyop1u6zrE2QeiFI=l0WAe1f7Bpi5ZXk,vvHpKfcqRnrFzjG,EAc8h2sINroQYvR3WH06Ji7MVpn
sRth5giAQzWlEVm7JOX,WMkAjB1RgN7q,NVS30xAdRFMIw1n9CislkE2=BK9OvRSjZbtx7kYyop1u6zrE2QeiFI,PPNA7jWqZgDnXKVvtuai1kQdsEoMb0,YB5xyI7MaRslVpv
NB6ZDMqe91yfKQ240WpbIntjxiY5z,k5dztomYyN3H,T6wRistc1SCo4hqObgumK=NVS30xAdRFMIw1n9CislkE2,WMkAjB1RgN7q,sRth5giAQzWlEVm7JOX
RqldvxFuM5GEQ2HAz93o7afBb0,rbjsM8cRFiuA1,nr5mZG89ICi6cgt4MfLJa0=T6wRistc1SCo4hqObgumK,k5dztomYyN3H,NB6ZDMqe91yfKQ240WpbIntjxiY5z
hhlbF1Sns5TrEN8QPCYmL4,FGDJwkEbTB5SoXujs3f,BoWHNb9daQVCF16A=nr5mZG89ICi6cgt4MfLJa0,rbjsM8cRFiuA1,RqldvxFuM5GEQ2HAz93o7afBb0
v5EA6TqHX3s4jzBMk,C2dgEDAKQGsvh,b05yftsZ6NYgIKP=BoWHNb9daQVCF16A,FGDJwkEbTB5SoXujs3f,hhlbF1Sns5TrEN8QPCYmL4
from G6AHskJeqN import *
baNWS6nfqTC5iX4Kl = jx7s8T0BFgODXLMzIYedf(u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗࠬᅋ")
def VbgEajY4Bt2COpGDcPqI(H3HDqY5N4e0fWSXMikZ8CR7suUmJdx,Gfsr6KpyVRovQmB8xcXUJ=rbjsM8cRFiuA1(u"ࠫࠬᅌ")):
	if   H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==  fY5wTlhtnOc0Er6sdy4k87b(u"࠱ᖔ"): Q2h6jc0CxLP7gNmT5(Gfsr6KpyVRovQmB8xcXUJ)
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==  jx7s8T0BFgODXLMzIYedf(u"࠴ᖕ"): EEbGBNzAQydpnq(Gfsr6KpyVRovQmB8xcXUJ)
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==  NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠶ᖖ"): RjgqLCpNkzswlxAcfH5F6ObMia()
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==  gItVahxL0w(u"࠸ᖗ"): tqY8WmB1FcPoUywflAhuMeRD3QHzjb(Gfsr6KpyVRovQmB8xcXUJ)
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==  l0WAe1f7Bpi5ZXk(u"࠺ᖘ"): jghfSmIHsJXL7KDZqOrQYtP6a()
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==  NVS30xAdRFMIw1n9CislkE2(u"࠼ᖙ"): b2kPsA3vynO7wuSYliqItrZj()
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==  EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠷ᖚ"): IEsKWSj05CNO(LgpdP3UjFRnlX(u"࡙ࡸࡵࡦᙇ"),LgpdP3UjFRnlX(u"࡙ࡸࡵࡦᙇ"))
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==  V2RbfGOBdcA6l8NTsPWzEyvS7(u"࠹ᖛ"): db5A6DcvpNWHtRMsPxyVj1o()
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==  T6wRistc1SCo4hqObgumK(u"࠻ᖜ"): WVDogpG6fZQu9cOBJ5T1UYn()
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==l0WAe1f7Bpi5ZXk(u"࠴࠹࠵ᖝ"): R5RjoSGKpVM3yqwQlT1z()
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==C2dgEDAKQGsvh(u"࠵࠺࠷ᖞ"): jrQbZYTylP9wdD()
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==BmcLzCFjuIrZP5fwXH18aN6YS(u"࠶࠻࠲ᖟ"): hOZ4eyGTKUtCEj7RmHkJp()
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==UnWjVbo503mEMv9KF(u"࠷࠵࠴ᖠ"): bjJm7InvPNhAHVCWra6L()
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==v5EA6TqHX3s4jzBMk(u"࠱࠶࠶ᖡ"): c7ykfWCNJE()
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==C2dgEDAKQGsvh(u"࠲࠷࠸ᖢ"): qLwTxrPust3kKHoQ1Ei2()
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠳࠸࠺ᖣ"): hDamHMyRj5wPpGSNl()
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==qbPw1d3KimF(u"࠴࠹࠼ᖤ"): pG3vnS7UCkhJ5NEgFl2ca0zjuIo()
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==b05yftsZ6NYgIKP(u"࠵࠺࠾ᖥ"): F5SWNut9y0ex()
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==UxS67uoGThbMwnfNRzy4gajLd23JH(u"࠶࠻࠹ᖦ"): ZZbNcGadDXtfl5u(hhlbF1Sns5TrEN8QPCYmL4(u"࡚ࡲࡶࡧᙈ"))
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==BmcLzCFjuIrZP5fwXH18aN6YS(u"࠷࠷࠱ᖧ"): DD2rxjXUJT94w5BLGYNl6hquPbofaA()
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==v5EA6TqHX3s4jzBMk(u"࠱࠸࠳ᖨ"): AXuG6ptzaRWxHhFcNlk()
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==rbjsM8cRFiuA1(u"࠲࠹࠵ᖩ"): XXxnNcKp7dbeERrhJQf(Gfsr6KpyVRovQmB8xcXUJ,BmcLzCFjuIrZP5fwXH18aN6YS(u"ࡔࡳࡷࡨᙉ"),BmcLzCFjuIrZP5fwXH18aN6YS(u"ࡔࡳࡷࡨᙉ"))
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==NVS30xAdRFMIw1n9CislkE2(u"࠳࠺࠷ᖪ"): wOF6QJqepnRYNgv5cos13ljDtZzGd(b05yftsZ6NYgIKP(u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡥࡩࡧࡰࡵ࡫ࡹࡩࠬᅍ"),RqldvxFuM5GEQ2HAz93o7afBb0(u"ࡕࡴࡸࡩᙊ"))
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==qbPw1d3KimF(u"࠴࠻࠹ᖫ"): wOF6QJqepnRYNgv5cos13ljDtZzGd(LgpdP3UjFRnlX(u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡷࡺ࡭ࡱࠩᅎ"),T6wRistc1SCo4hqObgumK(u"ࡖࡵࡹࡪᙋ"))
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==BmcLzCFjuIrZP5fwXH18aN6YS(u"࠵࠼࠻ᖬ"): CU5hx3On7jXVTKfz1amYycMAwF()
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==hhlbF1Sns5TrEN8QPCYmL4(u"࠶࠽࠶ᖭ"): qMQsrkg5v3cASY09()
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==nr5mZG89ICi6cgt4MfLJa0(u"࠷࠷࠸ᖮ"): puPlgNxOnLDQobyhvfGr6E0jY7iJHT(FGDJwkEbTB5SoXujs3f(u"ࠧࡴࡥࡵ࡭ࡵࡺ࠮࡮ࡱࡧࡹࡱ࡫࠮ࡳࡧࡶࡳࡱࡼࡥࡶࡴ࡯ࠫᅏ"))
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==l0WAe1f7Bpi5ZXk(u"࠱࠸࠺ᖯ"): puPlgNxOnLDQobyhvfGr6E0jY7iJHT(NVS30xAdRFMIw1n9CislkE2(u"ࠨࡵࡦࡶ࡮ࡶࡴ࠯࡯ࡲࡨࡺࡲࡥ࠯ࡻࡷ࠱ࡩࡲࡰࠨᅐ"))
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==vvHpKfcqRnrFzjG(u"࠲࠹࠼ᖰ"): puPlgNxOnLDQobyhvfGr6E0jY7iJHT(C2dgEDAKQGsvh(u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡻࡲࡹࡹࡻࡢࡦࠩᅑ"))
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==vvHpKfcqRnrFzjG(u"࠳࠼࠴ᖱ"): O6Ei5cYHAQqXjwFBmLo()
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==l0WAe1f7Bpi5ZXk(u"࠴࠽࠶ᖲ"): ZZ06uGgKCsEiTMqBaOPz9Rx()
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==nr5mZG89ICi6cgt4MfLJa0(u"࠵࠾࠸ᖳ"): T98N0pY4F6KdDOf()
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==C2jP0iLNGKnHu9xp(u"࠶࠿࠳ᖴ"): eDLCX2WOuiT1tcZgKd()
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==T6wRistc1SCo4hqObgumK(u"࠷࠹࠵ᖵ"): UnphcNYbEl9GI7uBxK()
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==gItVahxL0w(u"࠱࠺࠷ᖶ"): Av3xKlbkMYo8uLg6W0s()
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==RqldvxFuM5GEQ2HAz93o7afBb0(u"࠲࠻࠹ᖷ"): w2hmZWy0ICp8()
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==qbPw1d3KimF(u"࠳࠼࠻ᖸ"): zzbyHOoPWkBtKXa6xJdlLvqNA2h()
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==l0WAe1f7Bpi5ZXk(u"࠴࠽࠽ᖹ"): u4LipQtlOr7U85()
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==vvHpKfcqRnrFzjG(u"࠵࠾࠿ᖺ"): kQFMEBGpT5ruUDR3()
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==YB5xyI7MaRslVpv(u"࠸࠺࠰ᖻ"): PkYhfZbdFH3vQDerxw8(Gfsr6KpyVRovQmB8xcXUJ)
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==RqldvxFuM5GEQ2HAz93o7afBb0(u"࠹࠴࠲ᖼ"): U6xNL2AEyOIk()
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==T6wRistc1SCo4hqObgumK(u"࠳࠵࠴ᖽ"): EcAQY4p1JWq05XFRL()
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==T6wRistc1SCo4hqObgumK(u"࠴࠶࠶ᖾ"): AGIP3Z0vE4khW1cD2KisRS()
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==V2RbfGOBdcA6l8NTsPWzEyvS7(u"࠵࠷࠸ᖿ"): WBAycQPip8(BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࡗࡶࡺ࡫ᙌ"))
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==BoWHNb9daQVCF16A(u"࠶࠸࠺ᗀ"): dWVEwKUxJsr3oDpTNP1XA5()
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==T6wRistc1SCo4hqObgumK(u"࠷࠹࠼ᗁ"): b3MUYKf9RupWmrl(RqldvxFuM5GEQ2HAz93o7afBb0(u"ࡊࡦࡲࡳࡦᙍ"))
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==C2dgEDAKQGsvh(u"࠸࠺࠷ᗂ"): d4f1LnKCFGXirMJjc3RUN8yITWlx5(k5dztomYyN3H(u"࡙ࡸࡵࡦᙎ"))
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==T6wRistc1SCo4hqObgumK(u"࠹࠴࠹ᗃ"): GpzB4AmWqfZoankDQbOS()
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==RqldvxFuM5GEQ2HAz93o7afBb0(u"࠳࠵࠻ᗄ"): pass
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==BmcLzCFjuIrZP5fwXH18aN6YS(u"࠶࠲࠳ᗅ"): bRIaQctzqWikTBCo()
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==NVS30xAdRFMIw1n9CislkE2(u"࠷࠳࠵ᗆ"): ry4Nf1jDcTqap2leOWQZv960IGwnKM()
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==FGDJwkEbTB5SoXujs3f(u"࠸࠴࠷ᗇ"): uo5vRMrFcYsJwL7(b05yftsZ6NYgIKP(u"ࠪࡷࡰ࡯࡮࠯࡯ࡨࡸࡷࡵࡰࡰ࡮࡬ࡷࡊࡓࡁࡅࠩᅒ"),fY5wTlhtnOc0Er6sdy4k87b(u"࡚ࡲࡶࡧᙏ"))
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==jSu5Cg2Ub1OAkZVs8Yoz(u"࠹࠵࠹ᗈ"): bzfSI7tVkLRUmOBYa0GeK(Cjda4zr3pXghVKDR)
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==FGDJwkEbTB5SoXujs3f(u"࠺࠶࠴ᗉ"): bzfSI7tVkLRUmOBYa0GeK(Z7A1STpeQGVJ)
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==hhlbF1Sns5TrEN8QPCYmL4(u"࠻࠰࠶ᗊ"): ffJqy0SRBUAWMQD6v()
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠵࠱࠸ᗋ"): ooMyveu1YHBOkXcpfF2jqCVl(BmcLzCFjuIrZP5fwXH18aN6YS(u"ࡔࡳࡷࡨᙐ"))
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==vvHpKfcqRnrFzjG(u"࠶࠲࠺ᗌ"): QgnzujScYkv9TZlOKD6r51LBP(Gfsr6KpyVRovQmB8xcXUJ,k5dztomYyN3H(u"ࠫࠬᅓ"),RqldvxFuM5GEQ2HAz93o7afBb0(u"ࡕࡴࡸࡩᙑ"))
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==V2RbfGOBdcA6l8NTsPWzEyvS7(u"࠷࠳࠼ᗍ"): Mqua0WrQFmI4XGd()
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==UnWjVbo503mEMv9KF(u"࠸࠴࠾ᗎ"): vmFPqB0pfr8T521()
	return
def vmFPqB0pfr8T521():
	tLwvQlnjGpWsRVCN1 = mmwySO1P4jnKz5(BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠬ࠭ᅔ"),jSu5Cg2Ub1OAkZVs8Yoz(u"࠭ࠧᅕ"),NVS30xAdRFMIw1n9CislkE2(u"ࠧࠨᅖ"),UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᅗ"),BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"๊่ࠩࠥะั๋ัࠣๅ฾๊วࠡ็ึัࠥาๅ๋฻ࠣษ฾ีวะษอࠤฬ๊ศา่ส้ัࠦ࠮࠯ุ๋้ࠢำࠠอ็ํ฽๋ࠥไโษอࠤฬ๊ศา่ส้ัࠦวๅไา๎๊ฯࠠ࠯࠰่่ࠣ๐๋ࠠ฻๋ำࠥอไษำ้ห๊าࠠฦๆ์ࠤาอไสࠢสฺ่็ัࠡ࠰࠱ࠤ๏฿ๆ๋ࠢอะิ๐ฯࠡษ็ฬึ์วๆฮࠣ์ฯ฻แ๋ำ๊ࠤํ๎ึฺ้ࠣฬาอไสࠢส่๊฻ๆฺࠢส่ฯ๐ุ้ࠠ฼๋ฬࠦวๅ็หี๊าࠠภࠣࠤࠫᅘ"))
	if tLwvQlnjGpWsRVCN1:
		WBAycQPip8(v5EA6TqHX3s4jzBMk(u"ࡈࡤࡰࡸ࡫ᙒ"))
		SSRbfdTHKi1ngDyzeGt5X(IjYiO4u9HGmgw,vvHpKfcqRnrFzjG(u"ࡘࡷࡻࡥᙔ"),qbPw1d3KimF(u"ࡉࡥࡱࡹࡥᙓ"))
		ZIOHgA3z0TBR(T6wRistc1SCo4hqObgumK(u"ࠪࠫᅙ"),b05yftsZ6NYgIKP(u"ࠫࠬᅚ"),gItVahxL0w(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᅛ"),LgpdP3UjFRnlX(u"࠭สๆ่ࠢืาࠦฬๆ์฼ࠤฬ๊ๅๅใสฮࠥอไใัํ้ฮࠦไๅสิ๊ฬ๋ฬࠡ࠰࠱ࠤํ฿วะࠢส่อืๆศ็ฯࠤสู๊้๊ࠡ฽๏ฯࠠศๆุๅึࠦ࠮࠯ฺ๋ࠢ฾๐ษࠡษ็ฺ้์ูࠨᅜ"))
	return
def QgnzujScYkv9TZlOKD6r51LBP(Kczs71doMyLHwN,zD6u9s725C0pwYUKiGlMbTBWd4,showDialogs):
	W9YiR1FGTdzO3jByXPA70D = LLuOT2NGmXvS4C1WRyod8sQtIhV70a.connect(VOtIzx9Mks5pl)
	W9YiR1FGTdzO3jByXPA70D.text_factory = str
	CCJpwYUsTN1cBIz5PH = W9YiR1FGTdzO3jByXPA70D.cursor()
	if V8fmEML1b0PeaRZySnzh3H5J9: GLyoeIh5YcSN9P8D = sRth5giAQzWlEVm7JOX(u"ࠧࡣ࡮ࡤࡧࡰࡲࡩࡴࡶࠪᅝ")
	else: GLyoeIh5YcSN9P8D = PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠨࡷࡳࡨࡦࡺࡥࡠࡴࡸࡰࡪࡹࠧᅞ")
	CCJpwYUsTN1cBIz5PH.execute(WMkAjB1RgN7q(u"ࠩࡖࡉࡑࡋࡃࡕࠢ࠭ࠤࡋࡘࡏࡎࠢࠪᅟ")+GLyoeIh5YcSN9P8D+FGDJwkEbTB5SoXujs3f(u"ࠪࠤ࡜ࡎࡅࡓࡇࠣࡥࡩࡪ࡯࡯ࡋࡇࠤࡂࠦࠢࠨᅠ")+Kczs71doMyLHwN+fY5wTlhtnOc0Er6sdy4k87b(u"ࠫࠧࠦ࠻ࠨᅡ"))
	lKSnCUAjhE = CCJpwYUsTN1cBIz5PH.fetchall()
	if lKSnCUAjhE and zD6u9s725C0pwYUKiGlMbTBWd4 in [v5EA6TqHX3s4jzBMk(u"ࠬ࠭ᅢ"),jx7s8T0BFgODXLMzIYedf(u"࠭ࡥ࡯ࡣࡥࡰࡪ࠭ᅣ")]:
		tLwvQlnjGpWsRVCN1 = mmwySO1P4jnKz5(NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠧࠨᅤ"),RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠨࠩᅥ"),v5EA6TqHX3s4jzBMk(u"ࠩࠪᅦ"),sRth5giAQzWlEVm7JOX(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ᅧ"),C2dgEDAKQGsvh(u"ࠫฬ๊สฮัํฯࠥอไฤ๊อ์๊อส๋ๅํࠤ้หึศใฬࠤࡡࡴࠠࠨᅨ")+Kczs71doMyLHwN+gItVahxL0w(u"ࠬࠦ࡜࡯࡞ࡱࠤࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠๆฬ๋ๆๆ่ࠦๅษࠣ๎฾๋ไࠡ࠰࠱ࠤ์๊ࠠหำํำࠥะแฺ์็๋ࠥอไร่ࠣรࠦࠧࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠢ࡟ࡲࡡࡴࠠหีอ฻๏฿ࠠฦ์ๅหๆํࠠษี๊์้ฯฺ่ࠠาࠤฬู๊้ัฬࠤส๊้้ࠡำ๋ࠥอไีษือࠥอไๆ๊ฯ์ิฯࠠโ์ࠣๆฬฬๅสࠢัำ๊อสࠡสิ๊ฬ๋ฬࠡ฻่หิ࠭ᅩ"))
		if tLwvQlnjGpWsRVCN1!=BoWHNb9daQVCF16A(u"࠵ᗏ"): return
		CCJpwYUsTN1cBIz5PH.execute(RqldvxFuM5GEQ2HAz93o7afBb0(u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࠬᅪ")+GLyoeIh5YcSN9P8D+NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࡙ࠧࠡࡋࡉࡗࡋࠠࡢࡦࡧࡳࡳࡏࡄࠡ࠿ࠣࠦࠬᅫ")+Kczs71doMyLHwN+WMkAjB1RgN7q(u"ࠨࠤࠣ࠿ࠬᅬ"))
	elif zD6u9s725C0pwYUKiGlMbTBWd4 in [RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠩࠪᅭ"),sRth5giAQzWlEVm7JOX(u"ࠪࡨ࡮ࡹࡡࡣ࡮ࡨࠫᅮ")]:
		tLwvQlnjGpWsRVCN1 = mmwySO1P4jnKz5(C2jP0iLNGKnHu9xp(u"ࠫࠬᅯ"),qbPw1d3KimF(u"ࠬ࠭ᅰ"),C2jP0iLNGKnHu9xp(u"࠭ࠧᅱ"),NVS30xAdRFMIw1n9CislkE2(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᅲ"),NVS30xAdRFMIw1n9CislkE2(u"ࠨษ็ฮาี๊ฬࠢส่ศ๎ส้็สฮ๏้๊ࠡๆศฺฬ็ษࠡ࡞ࡱࠤࠬᅳ")+Kczs71doMyLHwN+b05yftsZ6NYgIKP(u"ࠩࠣࡠࡳࡢ࡮ࠡ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤ๊็ูๅ๋ࠢ๎฾๋ไࠡ࠰࠱ࠤ์๊ࠠหำํำࠥห๊ใษไ๋ࠥอไร่ࠣรࠦࠧࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠢ࡟ࡲࡡࡴࠠหีอ฻๏฿ࠠหใ฼๎้ํࠠษี๊์้ฯฺ่ࠠาࠤฬู๊้ัฬࠤส๊้้ࠡำ๋ࠥอไีษือࠥอไๆ๊ฯ์ิฯࠠโ์ࠣๆฬฬๅสࠢัำ๊อสࠡสิ๊ฬ๋ฬࠡ฻่หิ࠭ᅴ"))
		if tLwvQlnjGpWsRVCN1!=WMkAjB1RgN7q(u"࠶ᗐ"): return
		if V8fmEML1b0PeaRZySnzh3H5J9: CCJpwYUsTN1cBIz5PH.execute(WMkAjB1RgN7q(u"ࠪࡍࡓ࡙ࡅࡓࡖࠣࡍࡓ࡚ࡏࠡࡤ࡯ࡥࡨࡱ࡬ࡪࡵࡷࠤ࠭ࡧࡤࡥࡱࡱࡍࡉ࠯ࠠࡗࡃࡏ࡙ࡊ࡙ࠠࠩࠤࠪᅵ")+Kczs71doMyLHwN+FGDJwkEbTB5SoXujs3f(u"ࠫࠧ࠯ࠠ࠼ࠩᅶ"))
		else: CCJpwYUsTN1cBIz5PH.execute(sRth5giAQzWlEVm7JOX(u"ࠬࡏࡎࡔࡇࡕࡘࠥࡏࡎࡕࡑࠣࡹࡵࡪࡡࡵࡧࡢࡶࡺࡲࡥࡴࠢࠫࡥࡩࡪ࡯࡯ࡋࡇ࠰ࡺࡶࡤࡢࡶࡨࡖࡺࡲࡥ࡙ࠪࠢࡅࡑ࡛ࡅࡔࠢࠫࠦࠬᅷ")+Kczs71doMyLHwN+b05yftsZ6NYgIKP(u"࠭ࠢ࠭࠳ࠬࠤࡀ࠭ᅸ"))
	W9YiR1FGTdzO3jByXPA70D.commit()
	W9YiR1FGTdzO3jByXPA70D.close()
	KBxPW9cX8dqtaUDG.sleep(UxS67uoGThbMwnfNRzy4gajLd23JH(u"࠷ᗑ"))
	tUXmK5PeEH9SDq.executebuiltin(v5EA6TqHX3s4jzBMk(u"ࠧࡖࡲࡧࡥࡹ࡫ࡌࡰࡥࡤࡰࡆࡪࡤࡰࡰࡶࠫᅹ"))
	KBxPW9cX8dqtaUDG.sleep(UnWjVbo503mEMv9KF(u"࠱ᗒ"))
	if showDialogs: ZIOHgA3z0TBR(T6wRistc1SCo4hqObgumK(u"ࠨࠩᅺ"),BoWHNb9daQVCF16A(u"ࠩࠪᅻ"),V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ᅼ"),k5dztomYyN3H(u"ࠫฯ๋สࠡษ็฽๊๊๊สࠢห๊ัออࠨᅽ"))
	if zD6u9s725C0pwYUKiGlMbTBWd4 in [BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠬ࠭ᅾ"),C2dgEDAKQGsvh(u"࠭ࡥ࡯ࡣࡥࡰࡪ࠭ᅿ")]: ZZbNcGadDXtfl5u(showDialogs)
	return
def ffJqy0SRBUAWMQD6v():
	qkSCcaj2fg4VO7dl3G9IhJBs5DLx(RnqtMUa9Nh6peGEsBT,hhlbF1Sns5TrEN8QPCYmL4(u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪᆀ"),QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠨࡓࡘࡉࡘ࡚ࡉࡐࡐࡖࠫᆁ"))
	JEUhp7OfCsPMIcBeL5Xz8nl4 = GGWFyslIXMqOpfZTdc95Y2467B1J8e(fY5wTlhtnOc0Er6sdy4k87b(u"ࡋࡧ࡬ࡴࡧᙕ"))
	Ani5f2TRG3YImEFq = nr5mZG89ICi6cgt4MfLJa0(u"ࠩ࡟ࡲࠬᆂ")
	pPdgOFhRCfxHJ5suMG = jx7s8T0BFgODXLMzIYedf(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢࠦ࠭࠮࠯࠰࠱ࠥ࠳࠭࠮࠯࠰ࠤ࠲࠳࠭࠮࠯ࠣ࠱࠲࠳࠭࠮ࠢ࠰࠱࠲࠳࠭ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᆃ")
	tknQZe0hF6om8 = EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠫࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢࡢ࡮࡝ࡰࠪᆄ")
	for id,ggfedDsABTMIh,WPUxzqgnlY7aVGkA2RsSt1r5X4pHjJ,D0nq5FW8AJKejN91PO,RsKWNOw4Dg91bT7SdazF,reason in reversed(JEUhp7OfCsPMIcBeL5Xz8nl4):
		if id==sRth5giAQzWlEVm7JOX(u"ࠬ࠶ࠧᆅ"):
			AwFTJdHzeUl6,Hj2wTEArt3yZaL67dCXIxSp = D0nq5FW8AJKejN91PO.split(qbPw1d3KimF(u"࠭࡜࡯࠽࠾ࠫᆆ"))
			continue
		if Ani5f2TRG3YImEFq!=EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠧ࡝ࡰࠪᆇ"): Ani5f2TRG3YImEFq += tknQZe0hF6om8
		ZPXx9tplQ10D2skiFHqb = jSu5Cg2Ub1OAkZVs8Yoz(u"ࠨ࡝ࡕࡘࡑࡣ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩᆈ")+id+vvHpKfcqRnrFzjG(u"ࠩࠣ࠾ࠥ࠭ᆉ")+PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠪหู้ฤศๆࠣ࠾ࠥ࠭ᆊ")+k5dztomYyN3H(u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᆋ")+WPUxzqgnlY7aVGkA2RsSt1r5X4pHjJ
		UUdtxEKOHDTq5YkcWLvg = WMkAjB1RgN7q(u"ࠬࡢ࡮࡜ࡔࡗࡐࡢࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ศๆฯ์ฬฮࠠ࠻ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᆌ")+D0nq5FW8AJKejN91PO
		R9RpBFyY4IaZubcG8fNndJeHQ = gItVahxL0w(u"࡛࠭ࡓࡖࡏࡡࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣวๅะฺวࠥࡀࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᆍ")+RsKWNOw4Dg91bT7SdazF
		NpwctnZDKokruHBSUxaTLOQG = C2dgEDAKQGsvh(u"ࠧ࡝ࡰ࡞ࡖ࡙ࡒ࡝࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟สุ่ฮศࠡ࠼ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬᆎ")+reason
		Ani5f2TRG3YImEFq += ZPXx9tplQ10D2skiFHqb+UUdtxEKOHDTq5YkcWLvg+l0WAe1f7Bpi5ZXk(u"ࠨ࡞ࡱࠫᆏ")+pPdgOFhRCfxHJ5suMG+C2dgEDAKQGsvh(u"ࠩ࡟ࡲࠬᆐ")+R9RpBFyY4IaZubcG8fNndJeHQ+NpwctnZDKokruHBSUxaTLOQG+sRth5giAQzWlEVm7JOX(u"ࠪࡠࡳ࠭ᆑ")
	bFnD6Nh75IQcKrTke3gux4PvwRGUfS(YB5xyI7MaRslVpv(u"ࠫࡷ࡯ࡧࡩࡶࠪᆒ"),Hj2wTEArt3yZaL67dCXIxSp,Ani5f2TRG3YImEFq,b05yftsZ6NYgIKP(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࡠ࡮ࡲࡲ࡬࠭ᆓ"))
	return
def bzfSI7tVkLRUmOBYa0GeK(file):
	if file==Z7A1STpeQGVJ: y8FlmIHxp6MsvN10U = jx7s8T0BFgODXLMzIYedf(u"࠭โ้ษษ้ࠥอไๆใู่ฮ࠭ᆔ")
	elif file==Cjda4zr3pXghVKDR: y8FlmIHxp6MsvN10U = WMkAjB1RgN7q(u"ࠧใ๊สส๊ࠦยฯำࠣห้็๊ะ์๋๋ฬะࠧᆕ")
	vwnZ6hF0xpbt47o1f2VUily = Uu0ZdNAP1BWc28lR(BoWHNb9daQVCF16A(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨᆖ"),NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"่ࠩืา࠭ᆗ"),b05yftsZ6NYgIKP(u"ࠪษฺ๊วฮࠩᆘ"),RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠫำื่อࠩᆙ"),fY5wTlhtnOc0Er6sdy4k87b(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᆚ"),NVS30xAdRFMIw1n9CislkE2(u"࠭็ๅࠢอี๏ีࠠฦื็หาࠦๅๅใࠣࠫᆛ")+y8FlmIHxp6MsvN10U+fY5wTlhtnOc0Er6sdy4k87b(u"ࠧࠡล่ࠤฯื๊ะ่ࠢืาࠦวๅ็็ๅࠥลࠧᆜ"))
	if vwnZ6hF0xpbt47o1f2VUily==sRth5giAQzWlEVm7JOX(u"࠱ᗓ"):
		if XXRtDhYvWb35qnLBxIri7ScNUks0.path.exists(file):
			try: XXRtDhYvWb35qnLBxIri7ScNUks0.remove(file)
			except: pass
		ZIOHgA3z0TBR(qbPw1d3KimF(u"ࠨࠩᆝ"),T6wRistc1SCo4hqObgumK(u"ࠩࠪᆞ"),hhlbF1Sns5TrEN8QPCYmL4(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ᆟ"),T6wRistc1SCo4hqObgumK(u"ࠫฯ๋ࠠๆีะࠤ๊๊แࠡࠩᆠ")+y8FlmIHxp6MsvN10U)
	elif vwnZ6hF0xpbt47o1f2VUily==jSu5Cg2Ub1OAkZVs8Yoz(u"࠳ᗔ"):
		data = anzmoyTgUd(file)
		ZIOHgA3z0TBR(EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠬ࠭ᆡ"),FGDJwkEbTB5SoXujs3f(u"࠭ࠧᆢ"),v5EA6TqHX3s4jzBMk(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᆣ"),k5dztomYyN3H(u"ࠨฬ่ࠤส฻ไศฯ้้ࠣ็ࠠࠨᆤ")+y8FlmIHxp6MsvN10U)
	return
def ry4Nf1jDcTqap2leOWQZv960IGwnKM():
	if YSomBdvcNUMF3b8JDiCfrVW<jx7s8T0BFgODXLMzIYedf(u"࠴࠼ᗕ"):
		mR4VLhryYT2koGU6iBX = BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠩ็่ศูแࠡล้ฮࠥะำหะา้ࠥหีะษิࠤ่๎ฯ๋ࠢๅำ๏๋ࠠาไ่ࠤࠬᆥ")+str(YSomBdvcNUMF3b8JDiCfrVW)+BoWHNb9daQVCF16A(u"ࠪࠤํ๊็ัษࠣห้่่ศศ่ࠤฬ๊ๅึ๊ิอ๊ࠥวࠡฬ฼ู้้ࠦ็ัๆࠤ࠳ࠦ็ั้ࠣห้๋๊ำหࠣฮ๊้ๆไ่๊ࠢࠥืฤ๋หࠣๆํอฦๆࠢส่ๆ๐ฯ๋๊๊หฯࠦแ๋ࠢหี๋อๅอࠢ฼้ฬีࠠษึๆ่ࠥ฻่าࠢหำ้อࠠๆ่ࠣห้้สศสฬࠤ࠳ࠦไฦื็หาࠦวๅ็ื็้ฯࠠใ็ࠣฬฯำฯ๋อࠣฬึ์วๆฮࠣ็ํี๊ࠡว็ํࠥห๊ࠡวุำฬืࠠาไ่๋ࠥษูๅ๋้๋ࠣࠦ࠱࠹࠰࠳ࠫᆦ")
		ZIOHgA3z0TBR(T6wRistc1SCo4hqObgumK(u"ࠫࠬᆧ"),YB5xyI7MaRslVpv(u"ࠬ࠭ᆨ"),NVS30xAdRFMIw1n9CislkE2(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᆩ"),mR4VLhryYT2koGU6iBX)
		return
	ox3AQF7vIVBRjkD9 = tUXmK5PeEH9SDq.executeJSONRPC(T6wRistc1SCo4hqObgumK(u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡓࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡉࡨࡸࡘ࡫ࡴࡵ࡫ࡱ࡫࡛ࡧ࡬ࡶࡧࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡵࡨࡸࡹ࡯࡮ࡨࠤ࠽ࠦࡱࡵ࡯࡬ࡣࡱࡨ࡫࡫ࡥ࡭࠰ࡶ࡯࡮ࡴࠢࡾࡿࠪᆪ"))
	fsKS5t6mhrx0 = DdTjzlVGwQ9mJo([rbjsM8cRFiuA1(u"ࠨࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊࠧᆫ")])
	ttRZ9D4Ssngb,ilMg42mrB6Cy,IpBtwv095Pa37TGdDon,IkoEQKqr7OytGxvWe6hdRL,dtVSoXkgu4WnE0lcZN7O,aI9E3JeQ8h7MsHAW1OG,BmHVKEQ8zAsIeOMjx2dLlJuUwPZgYG = fsKS5t6mhrx0[hhlbF1Sns5TrEN8QPCYmL4(u"ࠩࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄࠨᆬ")]
	if ttRZ9D4Ssngb or k5dztomYyN3H(u"ࠪࡷࡰ࡯࡮࠯࡯ࡨࡸࡷࡵࡰࡰ࡮࡬ࡷࡊࡓࡁࡅࠩᆭ") not in str(ox3AQF7vIVBRjkD9):
		ZIOHgA3z0TBR(BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠫࠬᆮ"),QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠬ࠭ᆯ"),YB5xyI7MaRslVpv(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᆰ"),RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠧศๆๅ์ฬฬๅࠡษ็ฺ้๎ัสࠢอ฽๊๊ࠠโไฺࠤ๊฿ࠠอๆาࠤ๊ะั้สุู๋่ࠦๆษาࠤ࠳ࠦ็ั้ࠣห้่่ศศ่ࠤฯ๋ใ็ๅ้๋ࠣࠦัล์ฬࠤ็๎วว็ࠣฬึ์วๆฮࠣ฽๊อฯࠡสื็้ࠦี้ำࠣฬิ๊วࠡ็้ࠤฬ๊ใหษหอࠬᆱ"))
		tUEvo5HAfIjZgcdYxNJ8awu = uo5vRMrFcYsJwL7(NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠨࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊࠧᆲ"),v5EA6TqHX3s4jzBMk(u"࡚ࡲࡶࡧᙖ"))
		if not tUEvo5HAfIjZgcdYxNJ8awu: return
	vg4e75WtcYXk0SJyM(FGDJwkEbTB5SoXujs3f(u"ࡔࡳࡷࡨᙗ"))
	return
def vg4e75WtcYXk0SJyM(showDialogs=EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࡕࡴࡸࡩᙘ")):
	ox3AQF7vIVBRjkD9 = tUXmK5PeEH9SDq.executeJSONRPC(YB5xyI7MaRslVpv(u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡕࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡋࡪࡺࡓࡦࡶࡷ࡭ࡳ࡭ࡖࡢ࡮ࡸࡩࠧ࠲ࠢࡪࡦࠥ࠾࠶࠲ࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡷࡪࡺࡴࡪࡰࡪࠦ࠿ࠨ࡬ࡰࡱ࡮ࡥࡳࡪࡦࡦࡧ࡯࠲ࡸࡱࡩ࡯ࠤࢀࢁࠬᆳ"))
	if WMkAjB1RgN7q(u"ࠪࡷࡰ࡯࡮࠯࡯ࡨࡸࡷࡵࡰࡰ࡮࡬ࡷࡊࡓࡁࡅࠩᆴ") not in str(ox3AQF7vIVBRjkD9):
		if showDialogs:
			ZIOHgA3z0TBR(PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠫࠬᆵ"),fY5wTlhtnOc0Er6sdy4k87b(u"ࠬ࠭ᆶ"),UnWjVbo503mEMv9KF(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᆷ"),C2jP0iLNGKnHu9xp(u"ࠧๅๆฦืๆࠦฬ่ษี็๊ࠥวࠡ์ึฮำีๅࠡฮ็ำ๋ࠥสา๊ห์ฺู้ࠠ็สำࠥ࠴ࠠศๆๅ์ฬฬๅࠡษ็ฺ้๎ัสࠢอ฽๊๊ࠠโไฺࠤ๊฿ࠠอๆาࠤ๊ะั้สุู๋่ࠦๆษาࠤ࠳ࠦ็ั้ࠣห้่่ศศ่ࠤฯ๋ใ็ๅ้๋ࠣࠦัล์ฬࠤ็๎วว็ࠣฬึ์วๆฮࠣ฽๊อฯࠡสื็้ࠦี้ำࠣฬิ๊วࠡ็้ࠤฬ๊ใหษหอࠬᆸ"))
		return
	kuBhaKFAef2 = XXRtDhYvWb35qnLBxIri7ScNUks0.path.join(gK53PXkR96t7djpHeqEyL0,V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠨࡣࡧࡨࡴࡴࡳࠨᆹ"),BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠩࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄࠨᆺ"),NVS30xAdRFMIw1n9CislkE2(u"ࠪ࠻࠷࠶ࡰࠨᆻ"),sRth5giAQzWlEVm7JOX(u"ࠫࡒࡿࡖࡪࡦࡨࡳࡓࡧࡶ࠯ࡺࡰࡰࠬᆼ"))
	if not XXRtDhYvWb35qnLBxIri7ScNUks0.path.exists(kuBhaKFAef2): return
	icrzLnv703mP = open(kuBhaKFAef2,sRth5giAQzWlEVm7JOX(u"ࠬࡸࡢࠨᆽ")).read()
	if BLz7m2RkNrxXQwy1cGAp: icrzLnv703mP = icrzLnv703mP.decode(rbjsM8cRFiuA1(u"࠭ࡵࡵࡨ࠻ࠫᆾ"))
	vHxkNogKuEDVJwztGURMbps76Cr0 = My7Dwqvs6bfGNSIgX.findall(BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠧ࠽ࡸ࡬ࡩࡼࡹ࠾ࠩ࡞ࡧ࠯࠱ࡢࡤࠬ࠮࡟ࡨ࠰࠯ࠬࠩ࠰࠭ࡃ࠮ࡂ࠯ࡷ࡫ࡨࡻࡸࡄࠧᆿ"),icrzLnv703mP,My7Dwqvs6bfGNSIgX.DOTALL)
	Ky5lJN3QZtx4POjuXgCsIEM8Tfcovi,bbd1OKj89GBrFiQuoh4kV0 = vHxkNogKuEDVJwztGURMbps76Cr0[V2RbfGOBdcA6l8NTsPWzEyvS7(u"࠴ᗖ")]
	yzLj24SG9f8D = v5EA6TqHX3s4jzBMk(u"ࠨ࠾ࡹ࡭ࡪࡽࡳ࠿ࠩᇀ")+Ky5lJN3QZtx4POjuXgCsIEM8Tfcovi+UnWjVbo503mEMv9KF(u"ࠩ࠯ࠫᇁ")+bbd1OKj89GBrFiQuoh4kV0+V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠪࡀ࠴ࡼࡩࡦࡹࡶࡂࠬᇂ")
	if showDialogs:
		rXKBEjHt3Gd5 = tUXmK5PeEH9SDq.getInfoLabel(jx7s8T0BFgODXLMzIYedf(u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡗ࡫ࡨࡻࡲࡵࡤࡦࠩᇃ"))
		if rXKBEjHt3Gd5==BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠬࡋࡍࡂࡆࠣࡐ࡮ࡹࡴࠨᇄ"): jrdW1HU0fOqmZVigyeuw9txY = v5EA6TqHX3s4jzBMk(u"࠭โ้ษษ้ࠥอไไฬสฬฮ࠭ᇅ")
		elif rXKBEjHt3Gd5==nr5mZG89ICi6cgt4MfLJa0(u"ࠧࡆࡏࡄࡈࠥࡍࡡ࡭࡮ࡨࡶࡾ࠭ᇆ"): jrdW1HU0fOqmZVigyeuw9txY = PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠨไ๋หห๋ࠠศๆุ์ึ࠭ᇇ")
		else: jrdW1HU0fOqmZVigyeuw9txY = BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠩๅ์ฬฬๅࠡลัี๎࠭ᇈ")
		vwnZ6hF0xpbt47o1f2VUily = Uu0ZdNAP1BWc28lR(fY5wTlhtnOc0Er6sdy4k87b(u"ࠪࡧࡪࡴࡴࡦࡴࠪᇉ"),l0WAe1f7Bpi5ZXk(u"ࠫ็๎วว็ࠣวำื้ࠨᇊ"),UnWjVbo503mEMv9KF(u"่่ࠬศศ่ࠤฬ๊ใหษหอࠬᇋ"),NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠭โ้ษษ้ࠥอไึ๊ิࠫᇌ"),WMkAjB1RgN7q(u"ࠧศ่อࠤาอไ๋ษࠣฮุะฮะ็ࠣࠫᇍ")+jrdW1HU0fOqmZVigyeuw9txY,UnWjVbo503mEMv9KF(u"ࠨษ้ฮࠥอไร่ࠣฮุะฮะ็ࠣห้หีะษิࠤฬ๊รฯ์ิࠤ้าไะ่ࠢฮึ๎ศ้ๆึࠤ฾๋วะࠢ࠱ࠤํํะศ่ࠢ฽๋อ็ࠡษ้็ࠥะำหูํ฽ࠥอำหะาห๊ࠦวๅไ๋หห๋ࠠศๆู่ํืษࠡสา่ฬࠦๅ็ࠢๅ์ฬฬๅࠡษ็็ฯอศสࠢ࠱ࠤํษ๊ืษࠣฮุะื๋฻ࠣษ๏่วโ้สࠤๆ๐ࠠฤ์ࠣ์็ะࠠหึสลࠥࡢ࡮࡝ࡰࠣ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢࠦรฯฬิࠤฬ๊ย็้ࠢ์฾ࠦวๅไ๋หห๋ࠠศๆอ๎ࠥะั๋ัࠣวุะฮะษ่๋ฬࠦฟࠢ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᇎ"))
		if vwnZ6hF0xpbt47o1f2VUily==C2dgEDAKQGsvh(u"࠶ᗗ"): KjDu78BgOF64zYAPCWfQmZeLlhs = BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠩࡈࡑࡆࡊࠠࡍ࡫ࡶࡸࠬᇏ")
		elif vwnZ6hF0xpbt47o1f2VUily==UxS67uoGThbMwnfNRzy4gajLd23JH(u"࠸ᗘ"): KjDu78BgOF64zYAPCWfQmZeLlhs = b05yftsZ6NYgIKP(u"ࠪࡉࡒࡇࡄࠡࡉࡤࡰࡱ࡫ࡲࡺࠩᇐ")
		else: KjDu78BgOF64zYAPCWfQmZeLlhs = RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠫࠬᇑ")
	else:
		rXKBEjHt3Gd5 = bLEBi8IO7uU2x3htYDdVq95.getSetting(RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠬࡧࡶ࠯࡯ࡼࡷࡰ࡯࡮࠯ࡸ࡬ࡩࡼࡳ࡯ࡥࡧࠪᇒ"))
		if   rXKBEjHt3Gd5==NVS30xAdRFMIw1n9CislkE2(u"࠭ࠧᇓ"): vwnZ6hF0xpbt47o1f2VUily = NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠰ᗙ")
		elif rXKBEjHt3Gd5==LgpdP3UjFRnlX(u"ࠧࡆࡏࡄࡈࠥࡒࡩࡴࡶࠪᇔ"): vwnZ6hF0xpbt47o1f2VUily = qbPw1d3KimF(u"࠲ᗚ")
		elif rXKBEjHt3Gd5==qbPw1d3KimF(u"ࠨࡇࡐࡅࡉࠦࡇࡢ࡮࡯ࡩࡷࡿࠧᇕ"): vwnZ6hF0xpbt47o1f2VUily = V2RbfGOBdcA6l8NTsPWzEyvS7(u"࠴ᗛ")
		KjDu78BgOF64zYAPCWfQmZeLlhs = rXKBEjHt3Gd5
	if   vwnZ6hF0xpbt47o1f2VUily==V2RbfGOBdcA6l8NTsPWzEyvS7(u"࠳ᗜ"): esc3QEmfZg896d0aX = b05yftsZ6NYgIKP(u"ࠩ࠸࠹࠱࠻࠴࠵࠮࠸࠹࠺࠭ᇖ")
	elif vwnZ6hF0xpbt47o1f2VUily==l0WAe1f7Bpi5ZXk(u"࠵ᗝ"): esc3QEmfZg896d0aX = PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠪ࠹࠹࠺ࠬ࠶࠷࠸࠰࠺࠻ࠧᇗ")
	elif vwnZ6hF0xpbt47o1f2VUily==gItVahxL0w(u"࠷ᗞ"): esc3QEmfZg896d0aX = NVS30xAdRFMIw1n9CislkE2(u"ࠫ࠺࠻࠵࠭࠷࠸࠰࠺࠺࠴ࠨᇘ")
	else: return
	bLEBi8IO7uU2x3htYDdVq95.setSetting(NVS30xAdRFMIw1n9CislkE2(u"ࠬࡧࡶ࠯࡯ࡼࡷࡰ࡯࡮࠯ࡸ࡬ࡩࡼࡳ࡯ࡥࡧࠪᇙ"),KjDu78BgOF64zYAPCWfQmZeLlhs)
	gLQE84PyheqmuiNwBnRaS = jSu5Cg2Ub1OAkZVs8Yoz(u"࠭࠼ࡷ࡫ࡨࡻࡸࡄࠧᇚ")+esc3QEmfZg896d0aX+YB5xyI7MaRslVpv(u"ࠧ࠭ࠩᇛ")+bbd1OKj89GBrFiQuoh4kV0+C2jP0iLNGKnHu9xp(u"ࠨ࠾࠲ࡺ࡮࡫ࡷࡴࡀࠪᇜ")
	FtZSrKTsDbx2Jh5nM487WfXil0ON6a = icrzLnv703mP.replace(yzLj24SG9f8D,gLQE84PyheqmuiNwBnRaS)
	if BLz7m2RkNrxXQwy1cGAp: FtZSrKTsDbx2Jh5nM487WfXil0ON6a = FtZSrKTsDbx2Jh5nM487WfXil0ON6a.encode(b05yftsZ6NYgIKP(u"ࠩࡸࡸ࡫࠾ࠧᇝ"))
	open(kuBhaKFAef2,l0WAe1f7Bpi5ZXk(u"ࠪࡻࡧ࠭ᇞ")).write(FtZSrKTsDbx2Jh5nM487WfXil0ON6a)
	Lmj1pfQk63XdoeH(BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠫࡓࡕࡔࡊࡅࡈࠫᇟ"),FGDJwkEbTB5SoXujs3f(u"ࠬ࠴ࠠࠡࡕ࡮࡭ࡳࠦࡄࡦࡨࡤࡹࡱࡺࠠࡗ࡫ࡨࡻࡸࡀࠠ࡜ࠢࠪᇠ")+esc3QEmfZg896d0aX+fY5wTlhtnOc0Er6sdy4k87b(u"࠭ࠠ࡞ࠩᇡ"))
	if showDialogs: tUXmK5PeEH9SDq.executebuiltin(UnWjVbo503mEMv9KF(u"ࠧࡓࡧ࡯ࡳࡦࡪࡓ࡬࡫ࡱࠬ࠮࠭ᇢ"))
	return
def bRIaQctzqWikTBCo():
	tLwvQlnjGpWsRVCN1 = mmwySO1P4jnKz5(UnWjVbo503mEMv9KF(u"ࠨࠩᇣ"),V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠩࠪᇤ"),BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠪࠫᇥ"),RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᇦ"),fY5wTlhtnOc0Er6sdy4k87b(u"ࠬฮั็ษ่ะࠥ฿ๅศัࠣๅ๏ํࠠๆึๆ่ฮูࠦ็ัๆࠤ࠳࠴࠮ࠡว่หࠥษไฦืาหึࠦโะ์่ࠤ࠳࠴࠮ࠡล๋ࠤฬ์สࠡ็่๊ํ฿ࠠๆ่ࠣหุะฮะษ่ࠤฬ๊ศา่ส้ัࠦ࠮࠯࠰ࠣวํࠦไะ์ๆࠤฺ๊ใๅหࠣวำื้ࠡฬัูࠥา็ศิๆࠤศ์ส๊ࠡ็หࠥะฮึࠢหๆ๏ฯࠠฯๆๅࠤฬ๊ไ่ࠢ࡟ࡲࡡࡴࠠฮษ๋่ࠥะอะ์ฮࠤฬ๊ศา่ส้ัࠦร้ࠢสฮฺ๊ࠠษษ็้อืๅอࠢ็้฾ืแสࠢึฬอࠦวๅ็ื็้ฯฺ่ࠠา็ࠥ࠴࠮࠯๊่ࠢࠥะั๋ัࠣๅา฻ࠠศๆอัิ๐หศฬࠣห้ศๆࠡมࠪᇧ"))
	if tLwvQlnjGpWsRVCN1==BoWHNb9daQVCF16A(u"࠷ᗟ"): IEsKWSj05CNO(FGDJwkEbTB5SoXujs3f(u"ࡖࡵࡹࡪᙙ"),FGDJwkEbTB5SoXujs3f(u"ࡖࡵࡹࡪᙙ"))
	return
def db5A6DcvpNWHtRMsPxyVj1o():
	ZIOHgA3z0TBR(sRth5giAQzWlEVm7JOX(u"࠭ࠧᇨ"),C2jP0iLNGKnHu9xp(u"ࠧࠨᇩ"),rbjsM8cRFiuA1(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᇪ"),QynMHGWA0blfqTUdxRh5Jzi2t(u"๊ࠩิฬࠦวๅ็๋ๆ฾ࠦๅ฻ๆๅࠤ๊์ࠠศๆู่ิื้ࠠ฼ํีู๋ࠥา๊ไࠤ๊ะ๊ࠡ์ิะ฾ࠦไๅ฻่่ࠬᇫ"))
	return
def GpzB4AmWqfZoankDQbOS():
	ZPXx9tplQ10D2skiFHqb = RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢะูะษาࠤู๐ูสࠢล่๋ࠥอๆัุ่ࠣ์ษࠡ࠴࠳࠶࠶ࠦ࠺ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᇬ")
	ZPXx9tplQ10D2skiFHqb += V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠫฬ๊ๅ้ไ฼ࠤศีๆศ้ࠣๅ๏ํࠠฦฯุหห๐ษࠡๆ฼ำิࠦวๅึํ฽ฮࠦแ๋ࠢส่฾อไๆࠢอ้ࠥาๅฺ้สࠤ๊์ࠠอ็ํ฽ࠥอไๆืสำึࠦวๅ็อ์ๆืษࠡใํࠤฬ๊ล็ฬิ๊ฯࠦวๅไา๎๊ฯ้ࠠษ็ะิ๐ฯสࠢส่า้่ๆ์ฬࠤํอไ฻์ิࠤา้่ๆ์ฬࠤํ๋ๆࠡฮ่๎฾ࠦฯ้ๆࠣห้฿วๅ็ࠣฯ๊ࠦสๆࠢอ์า๐ฯ่ษࠣ์าูวษࠢส่๊฿ฯๅࠢะือࠦำไษ้ࠤิ๎ไࠡษ็฽ฬ๊ๅࠡๆึ๊ฮࠦ࠲࠱࠴࠴ࠤํํ๊ࠡษ็ษา฻วว์ฬࠤฬ๊รฮัฮࠤํอไฤึ่่ࠥอไห์ࠣฮู๊ࠦๆๆ๊หࠥ็๊ࠡษ็ื๋๎วหࠢส่฾ฺัสࠢส่๊อึ๋หࠪᇭ")
	ZPXx9tplQ10D2skiFHqb += BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠬࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟࡫ࡸࡹࡶࡳ࠻࠱࠲ࡸ࡮ࡴࡹ࠯ࡥࡦ࠳ࡸ࡮ࡩࡢࡥࡲࡹࡳࡺ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨᇮ")
	UUdtxEKOHDTq5YkcWLvg = jx7s8T0BFgODXLMzIYedf(u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞สิ๊ฬ๋ฬࠡึิ๎฼ࠦวๅ็ึ่๊ࠦ࠺ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᇯ")
	UUdtxEKOHDTq5YkcWLvg += BoWHNb9daQVCF16A(u"่๊ࠧࠣ฽ออัสࠢ฼๊ࠥฮั็ษ่ะࠥ๐่โำ้ࠣ฾๊่ๆษอࠤาูวษ์ฬࠤ่ั๊าหࠣฮ์๋ࠠอ็ํ฽ࠥอไๆี็้๏์ࠠๆอ็ࠤศ๎โศฬࠣห้฻ไศหࠣ์ศ๎โศฬࠣห้้ำ้ใࠣ์ฬ๊ฮิ๊ไࠤํฺใๅࠢส่็๋ั๊ࠡฦ์็อสࠡษ็ๆ๊ื้ࠠลํฺฬ๊้ࠦใิࠤึส๊สࠢส่์๊วๅࠢไ๎ࠥาๅ๋฻ࠣำํ๊ࠠศๆ฼ห้๋้ࠠลํฺฬࠦแ๋้ࠣฮ็๎๊ๆ่ࠢ๎้อฯ๋๋๋ࠢัื๊๊ࠡไ๎์ࠦรุ๋สࠤอำห๊ࠡๅีฬวษࠡษ็ๆึศๆ๊ࠡฦ๎฻อࠠโ์๊ࠤฬูสฯษิอࠥ๎สโษว่ࠥ๎แ๋้ࠣว็๎วๅุ่๊ࠢ๎ศสࠢ็่ศ๋วๆࠢ฼่๏่ࠦฤ็๋ีࠥษฮา๋ࠣฮ์๋ࠠไๆุ้๊ࠣๅࠡ࠰ࠣห้ฮั็ษ่ะ๋ࠥให๊หࠤอฺ๊สࠢฯหๆอࠠิๅิฬฯ่๋ࠦีอาิ๋ࠠ็ฺส้ࠥ๎๊็ั๋ึࠥะอหࠢห๎หฯ้ࠠ์้ำํุࠠไษฯ๎ฯ่ࠦๆะุูࠥ็โุࠢ็วัําสࠢส่ํ๐ๆะ๊ีࠤ࠳ࠦวๅ็๋ๆ฾ࠦวๅำึ้๏ࠦไๅสิ๊ฬ๋ฬ้๋ࠡࠫᇰ")
	UUdtxEKOHDTq5YkcWLvg += nr5mZG89ICi6cgt4MfLJa0(u"ࠨ࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡴࡪࡰࡼ࠲ࡨࡩ࠯࡮ࡷࡶࡰ࡮ࡳࡲࡶ࡮ࡨࡶࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᇱ")
	mR4VLhryYT2koGU6iBX = qbPw1d3KimF(u"ࠩ࡞ࡖ࡙ࡒ࡝ࠨᇲ")+ZPXx9tplQ10D2skiFHqb+T6wRistc1SCo4hqObgumK(u"ࠪࡠࡳࡢ࡮࡝ࡰ࡞ࡖ࡙ࡒ࡝ࠨᇳ")+UUdtxEKOHDTq5YkcWLvg
	bFnD6Nh75IQcKrTke3gux4PvwRGUfS(UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠫࡷ࡯ࡧࡩࡶࠪᇴ"),jx7s8T0BFgODXLMzIYedf(u"ࠬ࠭ᇵ"),mR4VLhryYT2koGU6iBX)
	return
def b3MUYKf9RupWmrl(IlpZ3itqN15kDozB6QA4JTE):
	ZIF98f4SswHLDNOkVtqjCuop17Tz(SToQEHqGtMnAlFbCz4wxBDuOsmW7)
	JEUhp7OfCsPMIcBeL5Xz8nl4 = GGWFyslIXMqOpfZTdc95Y2467B1J8e(IlpZ3itqN15kDozB6QA4JTE)
	id,ggfedDsABTMIh,WPUxzqgnlY7aVGkA2RsSt1r5X4pHjJ,D0nq5FW8AJKejN91PO,RsKWNOw4Dg91bT7SdazF,reason = JEUhp7OfCsPMIcBeL5Xz8nl4[PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"࠰ᗠ")]
	AwFTJdHzeUl6,Hj2wTEArt3yZaL67dCXIxSp = D0nq5FW8AJKejN91PO.split(rbjsM8cRFiuA1(u"࠭࡜࡯࠽࠾ࠫᇶ"))
	UUdtxEKOHDTq5YkcWLvg,R9RpBFyY4IaZubcG8fNndJeHQ,NpwctnZDKokruHBSUxaTLOQG = RsKWNOw4Dg91bT7SdazF.split(EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠧ࡝ࡰ࠾࠿ࠬᇷ"))
	ChnzLMTX3iHUQ12kwJE = BmcLzCFjuIrZP5fwXH18aN6YS(u"ࡗࡶࡺ࡫ᙚ")
	while ChnzLMTX3iHUQ12kwJE:
		ervK1cENpsYUB9 = Uu0ZdNAP1BWc28lR(l0WAe1f7Bpi5ZXk(u"ࠨࠩᇸ"),BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠩัีําࠧᇹ"),WMkAjB1RgN7q(u"ࠪษึูวๅࠢิืฬ๊ษࠡๆ็้อืๅอࠩᇺ"),WMkAjB1RgN7q(u"ࠫ็อฦๆหࠣห้ะศา฻สฮࠬᇻ"),gItVahxL0w(u"๊ࠬล๋ไสๅࠥอไฦ฻็ห๋อสࠡ࠼ࠣࠤฯฮัฺࠢฦ์ࠥอๅิฯࠣห้ฮั็ษ่ะࠬᇼ"),UUdtxEKOHDTq5YkcWLvg)
		if ervK1cENpsYUB9==qbPw1d3KimF(u"࠳ᗡ"): ptFvhk3X6nq8QJMyGjr0D = Uu0ZdNAP1BWc28lR(T6wRistc1SCo4hqObgumK(u"࠭ࠧᇽ"),PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠧࠨᇾ"),v5EA6TqHX3s4jzBMk(u"ࠨ฻๋ำฮ࠭ᇿ"),RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠩࠪሀ"),T6wRistc1SCo4hqObgumK(u"้ࠪอีรࠡษ็ฮอืูࠡ฼ํี่ࠥวษๆ่้ࠣ์โศึࠪሁ"),R9RpBFyY4IaZubcG8fNndJeHQ,fY5wTlhtnOc0Er6sdy4k87b(u"ࠫࡨࡵ࡮ࡧ࡫ࡵࡱࡤࡹ࡭ࡢ࡮࡯ࡪࡴࡴࡴࠨሂ"))
		elif ervK1cENpsYUB9==jx7s8T0BFgODXLMzIYedf(u"࠳ᗢ"): EEbGBNzAQydpnq()
		else: ChnzLMTX3iHUQ12kwJE = YB5xyI7MaRslVpv(u"ࡊࡦࡲࡳࡦᙛ")
	tUXmK5PeEH9SDq.executebuiltin(QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠩሃ"))
	return
def WBAycQPip8(showDialogs):
	tLwvQlnjGpWsRVCN1 = qbPw1d3KimF(u"࡙ࡸࡵࡦᙜ")
	if showDialogs: tLwvQlnjGpWsRVCN1 = mmwySO1P4jnKz5(UnWjVbo503mEMv9KF(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ሄ"),sRth5giAQzWlEVm7JOX(u"ࠧࠨህ"),RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠨࠩሆ"),gItVahxL0w(u"ࠩึศฬ๊ࠧሇ"),hhlbF1Sns5TrEN8QPCYmL4(u"๋้ࠪࠦร็ฬ้ࠣฯษใะ๋ࠢฮึ๐ฯࠡ็ึัࠥ๎สึใํีࠥาๅ๋฻ࠣษ฾ีวะษอࠤอืๆศ็ฯࠤ฾๋วะࠢ็่ๆ๐ฯ๋๊๊หฯࠦวๅ฻ิฬ๏ฯࠠ࠯ࠢะ๎ะࠦสฺ๊าࠤัฺ๋๊ࠢส่ส฿ฯศัสฮࠥหไฺ๊๋ࠢ฾๐ษࠡฬฮฬ๏ะࠠศๆหี๋อๅอࠢยࠫለ"))
	if tLwvQlnjGpWsRVCN1:
		tUEvo5HAfIjZgcdYxNJ8awu = V2RbfGOBdcA6l8NTsPWzEyvS7(u"࡚ࡲࡶࡧᙝ")
		if XXRtDhYvWb35qnLBxIri7ScNUks0.path.exists(eKAwWngzpJDifIxT):
			try: XXRtDhYvWb35qnLBxIri7ScNUks0.remove(eKAwWngzpJDifIxT)
			except: tUEvo5HAfIjZgcdYxNJ8awu = v5EA6TqHX3s4jzBMk(u"ࡆࡢ࡮ࡶࡩᙞ")
		if showDialogs:
			if tUEvo5HAfIjZgcdYxNJ8awu: ZIOHgA3z0TBR(WMkAjB1RgN7q(u"ࠫࠬሉ"),UnWjVbo503mEMv9KF(u"ࠬ࠭ሊ"),sRth5giAQzWlEVm7JOX(u"࠭ࠧላ"),EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠧห็ࠣฬ๋าวฮ่ࠢืา่ࠦหืไ๎ึࠦๅๅใࠣษ฾ีวะษอࠤอืๆศ็ฯࠤ฾๋วะࠢ็่ๆ๐ฯ๋๊๊หฯࠦวๅ฻ิฬ๏ฯࠧሌ"))
			else: ZIOHgA3z0TBR(WMkAjB1RgN7q(u"ࠨࠩል"),QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠩࠪሎ"),C2jP0iLNGKnHu9xp(u"ࠪࠫሏ"),LgpdP3UjFRnlX(u"้๊ࠫริใࠣๅู๊สࠡ฻่่๏ฯࠠๆีะࠤ๊๊แࠡษ็ษ฾ีวะษอࠫሐ"))
	return
def dWVEwKUxJsr3oDpTNP1XA5():
	O6Ei5cYHAQqXjwFBmLo()
	G40GZcDt12A8hqEaONykIMmvs = bLEBi8IO7uU2x3htYDdVq95.getSetting(jx7s8T0BFgODXLMzIYedf(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡪࡷࡸࡵࡩࡡࡤࡪࡨࠫሑ"))
	mR4VLhryYT2koGU6iBX = {}
	mR4VLhryYT2koGU6iBX[YB5xyI7MaRslVpv(u"࠭ࡁࡖࡖࡒࠫሒ")] = NVS30xAdRFMIw1n9CislkE2(u"ࠧศๆๆหูࠦวๅฬ็ๆฬฬ๊ࠡ์฼้้࠭ሓ")
	mR4VLhryYT2koGU6iBX[jx7s8T0BFgODXLMzIYedf(u"ࠨࡕࡗࡓࡕ࠭ሔ")] = LgpdP3UjFRnlX(u"ࠩส่่อิࠡ็อ์็็ࠠห็ส้ฬ่ࠦษษ็็ฬ๋ไࠨሕ")
	mR4VLhryYT2koGU6iBX[NVS30xAdRFMIw1n9CislkE2(u"ࠪࡐࡎࡓࡉࡕࡇࡇࠫሖ")] = LgpdP3UjFRnlX(u"่ࠫอิࠡฮาห่ࠥี๋ำࠣห้๋ฯ๊ࠢ࠱ࠤࠬሗ")+str(JeTgfEOCQS8mtloPc3dr1hxX/k5dztomYyN3H(u"࠹࠴ᗣ"))+YB5xyI7MaRslVpv(u"ࠬࠦฯใ์ๅอࠥ็โุࠩመ")
	VElpd7xoYw5fJBGqbKM = mR4VLhryYT2koGU6iBX[G40GZcDt12A8hqEaONykIMmvs]
	vwnZ6hF0xpbt47o1f2VUily = Uu0ZdNAP1BWc28lR(UxS67uoGThbMwnfNRzy4gajLd23JH(u"࠭ࠧሙ"),BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠧไษืࠤࠬሚ")+str(JeTgfEOCQS8mtloPc3dr1hxX/BoWHNb9daQVCF16A(u"࠺࠵ᗤ"))+BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠨࠢาๆ๏่ษࠨማ"),l0WAe1f7Bpi5ZXk(u"ࠩอุ฿๐ไࠡฬ็ๆฬฬ๊ࠨሜ"),UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠪษ๏่วโࠢๆห๊๊ࠧም"),VElpd7xoYw5fJBGqbKM,V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠫ์๊ࠠหำํำࠥอำหะาห๊ࠦวๅๅสุࠥอไัๅํࠤฬ๊สๅไสส๏ࠦรๆࠢอี๏ีࠠฦ์ๅหๆࠦวๅๅสุࠥฮวๅๅส้้ࠦรๆࠢอี๏ีࠠไษืࠤ฾๋ั่ࠢๅู๏ืࠠอัสࠤฤࠧࠧሞ"))
	if vwnZ6hF0xpbt47o1f2VUily==jSu5Cg2Ub1OAkZVs8Yoz(u"࠵ᗥ"): B5LsFYO0DnqmfGzjVKxHW = V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠬࡒࡉࡎࡋࡗࡉࡉ࠭ሟ")
	elif vwnZ6hF0xpbt47o1f2VUily==BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠷ᗦ"): B5LsFYO0DnqmfGzjVKxHW = EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠭ࡁࡖࡖࡒࠫሠ")
	elif vwnZ6hF0xpbt47o1f2VUily==EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠲ᗧ"): B5LsFYO0DnqmfGzjVKxHW = jx7s8T0BFgODXLMzIYedf(u"ࠧࡔࡖࡒࡔࠬሡ")
	else: B5LsFYO0DnqmfGzjVKxHW = WMkAjB1RgN7q(u"ࠨࠩሢ")
	if B5LsFYO0DnqmfGzjVKxHW:
		bLEBi8IO7uU2x3htYDdVq95.setSetting(BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳࡮ࡴࡵࡲࡦࡥࡨ࡮ࡥࠨሣ"),B5LsFYO0DnqmfGzjVKxHW)
		KnFpIONcSmzGHLD = mR4VLhryYT2koGU6iBX[B5LsFYO0DnqmfGzjVKxHW]
		ZIOHgA3z0TBR(sRth5giAQzWlEVm7JOX(u"ࠪࠫሤ"),T6wRistc1SCo4hqObgumK(u"ࠫࠬሥ"),vvHpKfcqRnrFzjG(u"ࠬ࠭ሦ"),KnFpIONcSmzGHLD)
	return
def AGIP3Z0vE4khW1cD2KisRS():
	mR4VLhryYT2koGU6iBX = {}
	mR4VLhryYT2koGU6iBX[EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠭ࡁࡖࡖࡒࠫሧ")] = RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠧิ์ิๅึࠦࡄࡏࡕࠣห้ะไใษษ๎ࠥ๐ูๆๆ࠽ࠤࠬረ")
	mR4VLhryYT2koGU6iBX[sRth5giAQzWlEVm7JOX(u"ࠨࡃࡖࡏࠬሩ")] = vvHpKfcqRnrFzjG(u"ࠩึ๎ึ็ัࠡࡆࡑࡗฺู๊ࠥ็็ࠤอ฿ฯࠡษ็ื๊ออࠡๆ๊࠾ࠥ࠭ሪ")
	mR4VLhryYT2koGU6iBX[BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠪࡗ࡙ࡕࡐࠨራ")] = NVS30xAdRFMIw1n9CislkE2(u"ุࠫ๐ัโำࠣࡈࡓ࡙ࠠๆฬ๋ๆๆࠦสๆษ่หࠥ๎ศศๆๆห๊๊ࠧሬ")
	oS9r0ln4WxuTMGECd = bLEBi8IO7uU2x3htYDdVq95.getSetting(v5EA6TqHX3s4jzBMk(u"ࠬࡧࡶ࠯ࡦࡱࡷࠬር"))
	G40GZcDt12A8hqEaONykIMmvs = bLEBi8IO7uU2x3htYDdVq95.getSetting(qbPw1d3KimF(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡸࡷࡪࡪ࡮ࡴࠩሮ"))
	VElpd7xoYw5fJBGqbKM = mR4VLhryYT2koGU6iBX[G40GZcDt12A8hqEaONykIMmvs]+oS9r0ln4WxuTMGECd
	vwnZ6hF0xpbt47o1f2VUily = Uu0ZdNAP1BWc28lR(nr5mZG89ICi6cgt4MfLJa0(u"ࠧࠨሯ"),v5EA6TqHX3s4jzBMk(u"ࠨฬื฾๏ฺ๊่ࠠาࠤฬ๊ๅ้ษไๆฮ࠭ሰ"),C2jP0iLNGKnHu9xp(u"ࠩอุ฿๐ไࠡฬ็ๆฬฬ๊ࠨሱ"),NVS30xAdRFMIw1n9CislkE2(u"ࠪษ๏่วโࠢๆห๊๊ࠧሲ"),VElpd7xoYw5fJBGqbKM,FGDJwkEbTB5SoXujs3f(u"ุࠫ๐ัโำࠣࡈࡓ่๊࡙ࠠࠣะ์อาࠡใํࠤฬ๊ล็ฬิ๊๏ะ๋ࠠไ๋้ࠥฮสฮ๊ํ่ࠥษำๆษฤࠤฬ๊ๅ้ษๅ฽ࠥ๎วๅีํีๆืวหࠢศ่๎ࠦราไส้ࠥ๎ู็ัࠣฬ฾฼ࠠศๆ้หุ๊ࠦใ๊่ࠤอำฬษ๋้๋ࠢ฿้ࠠฯูีࠥฮูืࠢส่๊๎วใ฻ࠣ࠲๊ࠥสี฼ํู่๊ࠥาใิࠤࡉࡔࡓࠡไ่ࠤออฮห์สีࠥอไิ์ิๅึࠦวๅ็้หุฮࠠฤ๊ࠣๆ๊ࠦศฦ์ๅหๆํࠠษษ็็ฬ๋ไࠨሳ"))
	if vwnZ6hF0xpbt47o1f2VUily==vvHpKfcqRnrFzjG(u"࠱ᗨ"): B5LsFYO0DnqmfGzjVKxHW = EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠬࡇࡓࡌࠩሴ")
	elif vwnZ6hF0xpbt47o1f2VUily==k5dztomYyN3H(u"࠳ᗩ"): B5LsFYO0DnqmfGzjVKxHW = gItVahxL0w(u"࠭ࡁࡖࡖࡒࠫስ")
	elif vwnZ6hF0xpbt47o1f2VUily==jx7s8T0BFgODXLMzIYedf(u"࠵ᗪ"): B5LsFYO0DnqmfGzjVKxHW = l0WAe1f7Bpi5ZXk(u"ࠧࡔࡖࡒࡔࠬሶ")
	if vwnZ6hF0xpbt47o1f2VUily in [EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠵ᗬ"),QynMHGWA0blfqTUdxRh5Jzi2t(u"࠵ᗫ")]:
		tLwvQlnjGpWsRVCN1 = mmwySO1P4jnKz5(BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨሷ"),NVS30xAdRFMIw1n9CislkE2(u"ࠩึ๎ึ็ั࠻ࠢࠪሸ")+HcyxqSkeNf8ROumTbVKCZLjdvB2[QynMHGWA0blfqTUdxRh5Jzi2t(u"࠷ᗭ")],jSu5Cg2Ub1OAkZVs8Yoz(u"ࠪื๏ืแา࠼ࠣࠫሹ")+HcyxqSkeNf8ROumTbVKCZLjdvB2[YB5xyI7MaRslVpv(u"࠰ᗮ")],v5EA6TqHX3s4jzBMk(u"ࠫࠬሺ"),V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠬษฮหษิࠤุ๐ัโำࠣࡈࡓ࡙ࠠศๆ่๊ฬูศࠡๆๆࠫሻ"))
		if tLwvQlnjGpWsRVCN1==UxS67uoGThbMwnfNRzy4gajLd23JH(u"࠲ᗯ"): DDF6QtRKsqm7JSdjgNM = HcyxqSkeNf8ROumTbVKCZLjdvB2[nr5mZG89ICi6cgt4MfLJa0(u"࠲ᗰ")]
		else: DDF6QtRKsqm7JSdjgNM = HcyxqSkeNf8ROumTbVKCZLjdvB2[BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠴ᗱ")]
	elif vwnZ6hF0xpbt47o1f2VUily==NVS30xAdRFMIw1n9CislkE2(u"࠶ᗲ"): DDF6QtRKsqm7JSdjgNM = RqldvxFuM5GEQ2HAz93o7afBb0(u"࠭ࠧሼ")
	else: B5LsFYO0DnqmfGzjVKxHW = UnWjVbo503mEMv9KF(u"ࠧࠨሽ")
	if B5LsFYO0DnqmfGzjVKxHW:
		bLEBi8IO7uU2x3htYDdVq95.setSetting(qbPw1d3KimF(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡺࡹࡥࡥࡰࡶࠫሾ"),B5LsFYO0DnqmfGzjVKxHW)
		bLEBi8IO7uU2x3htYDdVq95.setSetting(T6wRistc1SCo4hqObgumK(u"ࠩࡤࡺ࠳ࡪ࡮ࡴࠩሿ"),DDF6QtRKsqm7JSdjgNM)
		KnFpIONcSmzGHLD = mR4VLhryYT2koGU6iBX[B5LsFYO0DnqmfGzjVKxHW]+DDF6QtRKsqm7JSdjgNM
		ZIOHgA3z0TBR(sRth5giAQzWlEVm7JOX(u"ࠪࠫቀ"),YB5xyI7MaRslVpv(u"ࠫࠬቁ"),nr5mZG89ICi6cgt4MfLJa0(u"ࠬ࠭ቂ"),KnFpIONcSmzGHLD)
	return
def EcAQY4p1JWq05XFRL():
	G40GZcDt12A8hqEaONykIMmvs = bLEBi8IO7uU2x3htYDdVq95.getSetting(k5dztomYyN3H(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡸࡷࡪࡶࡲࡰࡺࡼࠫቃ"))
	mR4VLhryYT2koGU6iBX = {}
	mR4VLhryYT2koGU6iBX[RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠧࡂࡗࡗࡓࠬቄ")] = k5dztomYyN3H(u"ࠨษ็ฬึ๎ใิ์ࠣห้ะไใษษ๎ࠥาว่ิ่้ࠣ฿ๅๅࠩቅ")
	mR4VLhryYT2koGU6iBX[gItVahxL0w(u"ࠩࡄࡗࡐ࠭ቆ")] = NVS30xAdRFMIw1n9CislkE2(u"ࠪห้ฮั้ๅึ๎ฺู๊ࠥ็็ࠤอ฿ฯࠡษ็ื๊ออࠡๆ๊ࠫቇ")
	mR4VLhryYT2koGU6iBX[jx7s8T0BFgODXLMzIYedf(u"ࠫࡘ࡚ࡏࡑࠩቈ")] = b05yftsZ6NYgIKP(u"ࠬอไษำ๋็ุ๐ࠠๆฬ๋ๆๆࠦสๆษ่หࠥ๎ศศๆๆห๊๊ࠧ቉")
	VElpd7xoYw5fJBGqbKM = mR4VLhryYT2koGU6iBX[G40GZcDt12A8hqEaONykIMmvs]
	vwnZ6hF0xpbt47o1f2VUily = Uu0ZdNAP1BWc28lR(C2jP0iLNGKnHu9xp(u"࠭ࠧቊ"),T6wRistc1SCo4hqObgumK(u"ࠧหึ฽๎ู้ࠦ็ัࠣห้๋่ศใๅอࠬቋ"),NVS30xAdRFMIw1n9CislkE2(u"ࠨฬื฾๏๊ࠠหๆๅหห๐ࠧቌ"),hhlbF1Sns5TrEN8QPCYmL4(u"ࠩศ๎็อแࠡๅส้้࠭ቍ"),VElpd7xoYw5fJBGqbKM,BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠪห้ฮั้ๅึ๎ࠥํ่ࠡฮ๊หืࠦแ๋ࠢส่ส์สา่ํฮࠥ๐ูๆๆࠣ์ุ๐ืࠡสํ๊ࠥา็ศิๆࠤํอไฦ่อี๋๐สࠡ࠰๋ࠣํ๊ࠦิฬ็้ࠥ฽ไษษอ็ࠥ๎๊ใ๊่ࠤอูอษ้สࠤอีไศ่๊่ࠢࠦหๆࠢํฬ฾ั็ศࠢ็็ࠥ࠴่ࠠๆࠣฮึ๐ฯࠡฬื฾๏๊ࠠฤ็ࠣษ๏่วโࠢส่อื่ไีํࠤฤ࠭቎"))
	if vwnZ6hF0xpbt47o1f2VUily==YB5xyI7MaRslVpv(u"࠵ᗳ"): B5LsFYO0DnqmfGzjVKxHW = T6wRistc1SCo4hqObgumK(u"ࠫࡆ࡙ࡋࠨ቏")
	elif vwnZ6hF0xpbt47o1f2VUily==sRth5giAQzWlEVm7JOX(u"࠷ᗴ"): B5LsFYO0DnqmfGzjVKxHW = hhlbF1Sns5TrEN8QPCYmL4(u"ࠬࡇࡕࡕࡑࠪቐ")
	elif vwnZ6hF0xpbt47o1f2VUily==sRth5giAQzWlEVm7JOX(u"࠲ᗵ"): B5LsFYO0DnqmfGzjVKxHW = LgpdP3UjFRnlX(u"࠭ࡓࡕࡑࡓࠫቑ")
	else: B5LsFYO0DnqmfGzjVKxHW = EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠧࠨቒ")
	if B5LsFYO0DnqmfGzjVKxHW:
		bLEBi8IO7uU2x3htYDdVq95.setSetting(QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡺࡹࡥࡱࡴࡲࡼࡾ࠭ቓ"),B5LsFYO0DnqmfGzjVKxHW)
		KnFpIONcSmzGHLD = mR4VLhryYT2koGU6iBX[B5LsFYO0DnqmfGzjVKxHW]
		ZIOHgA3z0TBR(qbPw1d3KimF(u"ࠩࠪቔ"),C2dgEDAKQGsvh(u"ࠪࠫቕ"),V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠫࠬቖ"),KnFpIONcSmzGHLD)
	return
def Mqua0WrQFmI4XGd():
	etOfYpsR2kb7LmlHF = bLEBi8IO7uU2x3htYDdVq95.getSetting(b05yftsZ6NYgIKP(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯࡯ࡨࡲࡺࡹࡣࡢࡥ࡫ࡩࠬ቗"))
	if etOfYpsR2kb7LmlHF==gItVahxL0w(u"࠭ࡓࡕࡑࡓࠫቘ"): header = C2jP0iLNGKnHu9xp(u"ࠧหะี๎๋ࠦวๅไ๋หห๋ࠠๆฬ๋ๆๆ࠭቙")
	else: header = EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠨฬัึ๏์ࠠศๆๅ์ฬฬๅࠡ็ไ฽้࠭ቚ")
	tLwvQlnjGpWsRVCN1 = mmwySO1P4jnKz5(rbjsM8cRFiuA1(u"ࠩࠪቛ"),jSu5Cg2Ub1OAkZVs8Yoz(u"ࠪษ๏่วโࠩቜ"),jx7s8T0BFgODXLMzIYedf(u"ࠫฯ็ู๋ๆࠪቝ"),header,NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"่่ࠬศศ่ࠤฬ๊ศา่ส้ั๊ࠦห็ࠣฮาี๊ฬ้สࠤศ๎ส้็สฮ๏้๊ศࠢห฽ิࠦ࠱࠷ࠢึห฾ฯࠠๆ่ࠣวํ๊ࠠฤีอาิอๅࠡ࠰࠱ࠤํห๊ใษไࠤฯิา๋่ࠣห้่่ศศ่ࠤ๏สฯ๋ࠢศ่๎ࠦสฮัํฯ์อࠠโ์ࠣ็้ࠦๅาหࠣ๎ฯ๋ࠠศีอาิอๅࠡษ็ๆํอฦๆࠢ࠱࠲ࠥ๎็ัษࠣ๎ุฮศࠡสฺสࠥ็๊ࠡใอั่่ࠥศศ่ࠤฬ๊ศา่ส้ัࡢ࡮࡝ࡰ๋้ࠣࠦสา์าࠤฯ็ู๋ๆࠣว๊ࠦล๋ไสๅࠥะฮำ์้ࠤฬ๊โ้ษษ้ࠥลࠡࠢࠩ቞"))
	if tLwvQlnjGpWsRVCN1==-C2dgEDAKQGsvh(u"࠲ᗶ"): return
	elif tLwvQlnjGpWsRVCN1:
		bLEBi8IO7uU2x3htYDdVq95.setSetting(YB5xyI7MaRslVpv(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡰࡩࡳࡻࡳࡤࡣࡦ࡬ࡪ࠭቟"),QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠧࡂࡗࡗࡓࠬበ"))
		ZIOHgA3z0TBR(sRth5giAQzWlEVm7JOX(u"ࠨࠩቡ"),WMkAjB1RgN7q(u"ࠩࠪቢ"),vvHpKfcqRnrFzjG(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ባ"),qbPw1d3KimF(u"ࠫฯ๋ࠠหใ฼๎้ࠦสฯิํ๊ࠥอไใ๊สส๊࠭ቤ"))
	else:
		bLEBi8IO7uU2x3htYDdVq95.setSetting(LgpdP3UjFRnlX(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯࡯ࡨࡲࡺࡹࡣࡢࡥ࡫ࡩࠬብ"),v5EA6TqHX3s4jzBMk(u"࠭ࡓࡕࡑࡓࠫቦ"))
		ZIOHgA3z0TBR(LgpdP3UjFRnlX(u"ࠧࠨቧ"),NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠨࠩቨ"),BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬቩ"),nr5mZG89ICi6cgt4MfLJa0(u"ࠪฮ๊ࠦล๋ไสๅࠥะฮำ์้ࠤฬ๊โ้ษษ้ࠬቪ"))
	return
def Q2h6jc0CxLP7gNmT5(Gfsr6KpyVRovQmB8xcXUJ):
	if Gfsr6KpyVRovQmB8xcXUJ!=C2jP0iLNGKnHu9xp(u"ࠫࠬቫ"):
		Gfsr6KpyVRovQmB8xcXUJ = oQtFm9gzcADuxa(Gfsr6KpyVRovQmB8xcXUJ)
		Gfsr6KpyVRovQmB8xcXUJ = Gfsr6KpyVRovQmB8xcXUJ.decode(YB5xyI7MaRslVpv(u"ࠬࡻࡴࡧ࠺ࠪቬ")).encode(V2RbfGOBdcA6l8NTsPWzEyvS7(u"࠭ࡵࡵࡨ࠻ࠫቭ"))
		ClfuYvb0GwZLUtx63Fg = C2jP0iLNGKnHu9xp(u"࠳࠳࠵࠵࠹ᗷ")
		r8HR9PyejhDbvO = XUYb0K2ghSyFs.Window(ClfuYvb0GwZLUtx63Fg)
		r8HR9PyejhDbvO.getControl(PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"࠶࠵࠶ᗸ")).setLabel(Gfsr6KpyVRovQmB8xcXUJ)
	return
XpFd0qNKwvP7 = [
			 vvHpKfcqRnrFzjG(u"ࠢࡦࡺࡷࡩࡳࡹࡩࡰࡰࠣࠫࠬࠦࡩࡴࠢࡱࡳࡹࠦࡣࡶࡴࡵࡩࡳࡺ࡬ࡺࠢࡶࡹࡵࡶ࡯ࡳࡶࡨࡨࠧቮ")
			,NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠨࡅ࡫ࡩࡨࡱࡩ࡯ࡩࠣࡪࡴࡸࠠࡎࡣ࡯࡭ࡨ࡯࡯ࡶࡵࠣࡷࡨࡸࡩࡱࡶࡶࠫቯ")
			,FGDJwkEbTB5SoXujs3f(u"ࠩࡓ࡚ࡗࠦࡉࡑࡖ࡙ࠤࡘ࡯࡭ࡱ࡮ࡨࠤࡈࡲࡩࡦࡰࡷࠫተ")
			,nr5mZG89ICi6cgt4MfLJa0(u"࡙ࠪࡳࡱ࡮ࡰࡹࡱࠤ࡛࡯ࡤࡦࡱࠣࡍࡳ࡬࡯ࠡࡍࡨࡽࠬቱ")
			,V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠫࡹ࡮ࡩࡴࠢ࡫ࡥࡸ࡮ࠠࡧࡷࡱࡧࡹ࡯࡯࡯ࠢ࡬ࡷࠥࡨࡲࡰ࡭ࡨࡲࠬቲ")
			,C2jP0iLNGKnHu9xp(u"ࠬࡻࡳࡦࡵࠣࡴࡱࡧࡩ࡯ࠢࡋࡘ࡙ࡖࠠࡧࡱࡵࠤࡦࡪࡤ࠮ࡱࡱࠤࡩࡵࡷ࡯࡮ࡲࡥࡩࡹࠧታ")
			,b05yftsZ6NYgIKP(u"࠭ࡡࡥࡸࡤࡲࡨ࡫ࡤ࠮ࡷࡶࡥ࡬࡫࠮ࡩࡶࡰࡰࠬቴ")+fY5wTlhtnOc0Er6sdy4k87b(u"ࠧࠤࠩት")+QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠨࡵࡶࡰ࠲ࡽࡡࡳࡰ࡬ࡲ࡬ࡹࠧቶ")
			,rbjsM8cRFiuA1(u"ࠩࡌࡲࡸ࡫ࡣࡶࡴࡨࡖࡪࡷࡵࡦࡵࡷ࡛ࡦࡸ࡮ࡪࡰࡪ࠰ࠬቷ")
			,BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠪࡉࡷࡸ࡯ࡳࠢࡪࡩࡹࡺࡩ࡯ࡩࠣࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇ࠳ࡄࡳ࡯ࡥࡧࡨࡁ࠵ࠬࡴࡦࡺࡷࡸࡂ࠭ቸ")
			,l0WAe1f7Bpi5ZXk(u"ࠫࡼࡧࡲ࡯࡫ࡱ࡫ࡸ࠴ࡷࡢࡴࡱࠬࠬቹ")
			,l0WAe1f7Bpi5ZXk(u"ࠬࡤ࡞࡟ࡠࡡࠫቺ")
			,BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠭ࡌࡰࡣࡧ࡭ࡳ࡭ࠠࡴ࡭࡬ࡲࠥ࡬ࡩ࡭ࡧ࠽ࠫቻ")
			]
def pI0JbHhD4ZxvXmn5aercFz1flPBgC(PcOUYpACoRnGhSWdiJV):
	if vvHpKfcqRnrFzjG(u"ࠧࡍࡱࡤࡨ࡮ࡴࡧࠡࡵ࡮࡭ࡳࠦࡦࡪ࡮ࡨ࠾ࠬቼ") in PcOUYpACoRnGhSWdiJV and fY5wTlhtnOc0Er6sdy4k87b(u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭ች") in PcOUYpACoRnGhSWdiJV: return WMkAjB1RgN7q(u"ࡕࡴࡸࡩᙟ")
	for Gfsr6KpyVRovQmB8xcXUJ in XpFd0qNKwvP7:
		if Gfsr6KpyVRovQmB8xcXUJ in PcOUYpACoRnGhSWdiJV: return NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࡖࡵࡹࡪᙠ")
	return nr5mZG89ICi6cgt4MfLJa0(u"ࡉࡥࡱࡹࡥᙡ")
def TAiEC35tfFN9jBsg(data):
	data = data.replace(T6wRistc1SCo4hqObgumK(u"ࠩ࡟ࡶࡡࡴࠧቾ")+LgpdP3UjFRnlX(u"࠹࠶ᗹ")*NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠪࠤࠬቿ")+rbjsM8cRFiuA1(u"ࠫࡡࡸ࡜࡯ࠩኀ"),jSu5Cg2Ub1OAkZVs8Yoz(u"ࠬࡢࡲ࡝ࡰࠪኁ"))
	data = data.replace(nr5mZG89ICi6cgt4MfLJa0(u"࠭࡜࡯ࠩኂ")+UnWjVbo503mEMv9KF(u"࠺࠷ᗺ")*YB5xyI7MaRslVpv(u"ࠧࠡࠩኃ")+NVS30xAdRFMIw1n9CislkE2(u"ࠨ࡞ࡵࡠࡳ࠭ኄ"),QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠩ࡟ࡶࡡࡴࠧኅ"))
	data = data.replace(BoWHNb9daQVCF16A(u"ࠪࡠࡳ࠭ኆ")+PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"࠻࠱ᗻ")*rbjsM8cRFiuA1(u"ࠫࠥ࠭ኇ")+PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠬࡢ࡮ࠨኈ"),rbjsM8cRFiuA1(u"࠭࡜࡯ࠩ኉"))
	data = data.replace(jSu5Cg2Ub1OAkZVs8Yoz(u"ࠧ࡝ࡰࠪኊ")+hhlbF1Sns5TrEN8QPCYmL4(u"࠶࠳ᗽ")*hhlbF1Sns5TrEN8QPCYmL4(u"ࠨࠢࠪኋ"),C2dgEDAKQGsvh(u"ࠩ࡟ࡲࠬኌ")+hhlbF1Sns5TrEN8QPCYmL4(u"࠳࠲ᗼ")*fY5wTlhtnOc0Er6sdy4k87b(u"ࠪࠤࠬኍ"))
	data = data.replace(C2jP0iLNGKnHu9xp(u"ࠫࠥࡂࡧࡦࡰࡨࡶࡦࡲ࠾࠻ࠢࠪ኎"),PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠬࡀࠠࠨ኏"))
	toAVQS46Fv8aJYyLf25KnkUNC = C2dgEDAKQGsvh(u"࠭ࠧነ")
	for PcOUYpACoRnGhSWdiJV in data.splitlines():
		vupOEiRhMNsJlez = My7Dwqvs6bfGNSIgX.findall(RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠧࠡࠢࠣࠤࠥࡌࡩ࡭ࡧࠣࠦ࠭࠴ࠪࡀࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠴ࠩࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭ኑ"),PcOUYpACoRnGhSWdiJV,My7Dwqvs6bfGNSIgX.DOTALL)
		if vupOEiRhMNsJlez: PcOUYpACoRnGhSWdiJV = PcOUYpACoRnGhSWdiJV.replace(vupOEiRhMNsJlez[UxS67uoGThbMwnfNRzy4gajLd23JH(u"࠲ᗾ")],v5EA6TqHX3s4jzBMk(u"ࠨࠩኒ"))
		toAVQS46Fv8aJYyLf25KnkUNC += UnWjVbo503mEMv9KF(u"ࠩ࡟ࡲࠬና")+PcOUYpACoRnGhSWdiJV
	return toAVQS46Fv8aJYyLf25KnkUNC
def PkYhfZbdFH3vQDerxw8(gMGpH1PFuCkBbVUhAT5QzSxN9Kraj):
	if NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠪࡓࡑࡊࠧኔ") in gMGpH1PFuCkBbVUhAT5QzSxN9Kraj:
		cs64rjtOqFHIGUVbYw5iuznL80Z = WmQXf9gYFJckoUVN4LIuaBlbz
		header = hhlbF1Sns5TrEN8QPCYmL4(u"ࠫ็ืวยหࠣหู้ฬๅࠢส่็ี๊ๆࠢยࠫን")
	else:
		cs64rjtOqFHIGUVbYw5iuznL80Z = la7vIpTkr6w1ZW8XUNuCLKAMzi
		header = fY5wTlhtnOc0Er6sdy4k87b(u"่ࠬัศรฬࠤฬ๊ำอๆࠣห้ำวๅ์ࠣรࠬኖ")
	tLwvQlnjGpWsRVCN1 = mmwySO1P4jnKz5(WMkAjB1RgN7q(u"࠭ࠧኗ"),gItVahxL0w(u"ࠧࠨኘ"),k5dztomYyN3H(u"ࠨࠩኙ"),header,LgpdP3UjFRnlX(u"ࠩึะ้ࠦวๅลั฻ฬว๋ࠠฯอ์๏ࠦรุ๋สࠤ฾๊้ࠡีฯ่ࠥอไศีอาิอๅࠡ࠰ࠣ์ฬ๊วฬ่ํ๊ࠥ฼ั้ำํอ๊ࠥๅฺำไอ้๊ࠥโࠢะำะะࠠศๆุ่่๊ษ๊่ࠡหࠥํ่ࠡษ็้่อๆࠡษ็ิ๏ࠦำษสࠣัิ๎หࠡษ็ู้้ไสࠢ࠱ࠤ่๎ฯ๋ࠢํัฯ็ุࠡสึะ้๐ๆࠡ࠰ࠣห้ษ่ๅ๊ࠢ์ࠥอไิฮ็ࠤฬ๊อศๆํࠤํ็๊่่ࠢ฽้๎ๅศฬࠣฮอีรࠡ็้ิࠥฮฯศ์ฬࠤฬ๊สี฼ํ่ࠥอไฮษ็๎๊ࠥศา่ส้ัࠦใ้ัํࠤํอไ๊ࠢส่ว์ࠠ࠯ࠢฦ้ฬࠦวๅีฯ่ࠥอไใัํ้ࠥ็็้ࠢสุ่าไࠡษ็ืฬฮโࠡษ็ิ๏ࠦสๆࠢฯ้฾ํࠠๆ่ࠣฬึ์วๆฮࠣ็ํี๊ࠡไห่ࠥศฮาࠢศ฻ๆอมࠡๆ๊ࠤ࠳ࠦ็ๅࠢอี๏ีࠠศๆสืฯ๋ัศำࠣรࠬኚ"))
	if tLwvQlnjGpWsRVCN1!=jx7s8T0BFgODXLMzIYedf(u"࠴ᗿ"): return
	rlaqTwboPMcym0khV6niz2IJBHFu,WWMqcL9yHEm = [],NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠴ᘀ")
	size,count = SIG93nyQ6qCPRdkwijWlsM(cs64rjtOqFHIGUVbYw5iuznL80Z)
	file = open(cs64rjtOqFHIGUVbYw5iuznL80Z,EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠪࡶࡧ࠭ኛ"))
	if size>RqldvxFuM5GEQ2HAz93o7afBb0(u"࠷࠰࠱࠴࠳࠴ᘂ"): file.seek(-RqldvxFuM5GEQ2HAz93o7afBb0(u"࠶࠶࠰࠲࠲࠳ᘁ"),XXRtDhYvWb35qnLBxIri7ScNUks0.SEEK_END)
	data = file.read()
	file.close()
	if BLz7m2RkNrxXQwy1cGAp: data = data.decode(C2jP0iLNGKnHu9xp(u"ࠫࡺࡺࡦ࠹ࠩኜ"))
	data = TAiEC35tfFN9jBsg(data)
	p1GZLhkOD64IX = data.split(RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠬࡢ࡮ࠨኝ"))
	for PcOUYpACoRnGhSWdiJV in reversed(p1GZLhkOD64IX):
		xx9fC502el4yrms1bhXw = pI0JbHhD4ZxvXmn5aercFz1flPBgC(PcOUYpACoRnGhSWdiJV)
		if xx9fC502el4yrms1bhXw: continue
		PcOUYpACoRnGhSWdiJV = PcOUYpACoRnGhSWdiJV.replace(PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"࠭࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࡟ࠨኞ"),YB5xyI7MaRslVpv(u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ኟ"))
		PcOUYpACoRnGhSWdiJV = PcOUYpACoRnGhSWdiJV.replace(UnWjVbo503mEMv9KF(u"ࠨࡇࡕࡖࡔࡘ࠺ࠨአ"),jx7s8T0BFgODXLMzIYedf(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌ࠰࠱࠲࠳ࡡࡊࡘࡒࡐࡔ࠽࡟࠴ࡉࡏࡍࡑࡕࡡࠬኡ"))
		SSpn9grtNI = nr5mZG89ICi6cgt4MfLJa0(u"ࠪࠫኢ")
		RRQtLerl19fmxZ3sKoVSanyqTvDJP = My7Dwqvs6bfGNSIgX.findall(BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠫࡣ࠮࡜ࡥ࠭࠰ࠬࡡࡪࠫ࠮࡞ࡧ࠯ࠥࡢࡤࠬ࠼࡟ࡨ࠰ࡀ࡜ࡥ࠭࡟࠲ࡡࡪࠫࠪࠫࠫࠤ࡙ࡀ࡜ࡥ࠭ࠬࠫኣ"),PcOUYpACoRnGhSWdiJV,My7Dwqvs6bfGNSIgX.DOTALL)
		if RRQtLerl19fmxZ3sKoVSanyqTvDJP:
			PcOUYpACoRnGhSWdiJV = PcOUYpACoRnGhSWdiJV.replace(RRQtLerl19fmxZ3sKoVSanyqTvDJP[BmcLzCFjuIrZP5fwXH18aN6YS(u"࠱ᘄ")][BmcLzCFjuIrZP5fwXH18aN6YS(u"࠱ᘄ")],RRQtLerl19fmxZ3sKoVSanyqTvDJP[BmcLzCFjuIrZP5fwXH18aN6YS(u"࠱ᘄ")][v5EA6TqHX3s4jzBMk(u"࠱ᘃ")]).replace(RRQtLerl19fmxZ3sKoVSanyqTvDJP[BmcLzCFjuIrZP5fwXH18aN6YS(u"࠱ᘄ")][UxS67uoGThbMwnfNRzy4gajLd23JH(u"࠴ᘅ")],BoWHNb9daQVCF16A(u"ࠬ࠭ኤ"))
			SSpn9grtNI = RRQtLerl19fmxZ3sKoVSanyqTvDJP[UxS67uoGThbMwnfNRzy4gajLd23JH(u"࠴ᘇ")][jx7s8T0BFgODXLMzIYedf(u"࠴ᘆ")]
		else:
			RRQtLerl19fmxZ3sKoVSanyqTvDJP = My7Dwqvs6bfGNSIgX.findall(vvHpKfcqRnrFzjG(u"࠭࡞ࠩ࡞ࡧ࠯࠿ࡢࡤࠬ࠼࡟ࡨ࠰ࡢ࠮࡝ࡦ࠮࠭࠭ࠦࡔ࠻࡞ࡧ࠯࠮࠭እ"),PcOUYpACoRnGhSWdiJV,My7Dwqvs6bfGNSIgX.DOTALL)
			if RRQtLerl19fmxZ3sKoVSanyqTvDJP:
				PcOUYpACoRnGhSWdiJV = PcOUYpACoRnGhSWdiJV.replace(RRQtLerl19fmxZ3sKoVSanyqTvDJP[V2RbfGOBdcA6l8NTsPWzEyvS7(u"࠶ᘉ")][BoWHNb9daQVCF16A(u"࠶ᘈ")],vvHpKfcqRnrFzjG(u"ࠧࠨኦ"))
				SSpn9grtNI = RRQtLerl19fmxZ3sKoVSanyqTvDJP[WMkAjB1RgN7q(u"࠰ᘊ")][WMkAjB1RgN7q(u"࠰ᘊ")]
		if SSpn9grtNI: PcOUYpACoRnGhSWdiJV = PcOUYpACoRnGhSWdiJV.replace(SSpn9grtNI,RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫኧ")+SSpn9grtNI+nr5mZG89ICi6cgt4MfLJa0(u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫከ"))
		rlaqTwboPMcym0khV6niz2IJBHFu.append(PcOUYpACoRnGhSWdiJV)
		if len(str(rlaqTwboPMcym0khV6niz2IJBHFu))>l0WAe1f7Bpi5ZXk(u"࠶࠲࠴࠴࠵ᘋ"): break
	rlaqTwboPMcym0khV6niz2IJBHFu = reversed(rlaqTwboPMcym0khV6niz2IJBHFu)
	hbqpFfU6t7I = hhlbF1Sns5TrEN8QPCYmL4(u"ࠪࡠࡳ࠭ኩ").join(rlaqTwboPMcym0khV6niz2IJBHFu)
	bFnD6Nh75IQcKrTke3gux4PvwRGUfS(nr5mZG89ICi6cgt4MfLJa0(u"ࠫࡱ࡫ࡦࡵࠩኪ"),FGDJwkEbTB5SoXujs3f(u"ࠬศฮาࠢฦื฼ืࠠิฮ็ࠤฬ๊รฯูสลࠥ๎วๅษึฮำีวๆࠩካ"),hbqpFfU6t7I,LgpdP3UjFRnlX(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡵࡰࡥࡱࡲࡦࡰࡰࡷࡣࡱࡵ࡮ࡨࠩኬ"))
	return
def kQFMEBGpT5ruUDR3():
	a0lBywSP6DgRtnsHr9AjXW = open(e9eWTrJdhbyOK5zg0BpL4xuv,UnWjVbo503mEMv9KF(u"ࠧࡳࡤࠪክ")).read()
	if BLz7m2RkNrxXQwy1cGAp: a0lBywSP6DgRtnsHr9AjXW = a0lBywSP6DgRtnsHr9AjXW.decode(YB5xyI7MaRslVpv(u"ࠨࡷࡷࡪ࠽࠭ኮ"))
	a0lBywSP6DgRtnsHr9AjXW = a0lBywSP6DgRtnsHr9AjXW.replace(qbPw1d3KimF(u"ࠩ࡟ࡸࠬኯ"),NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠪࠤࠥࠦࠠࠡࠢࠣࠤࠬኰ"))
	fsKS5t6mhrx0 = My7Dwqvs6bfGNSIgX.findall(V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠫ࠭ࡼ࡜ࡥ࠰࠭ࡃ࠮ࡡ࡜࡯࡞ࡵࡡࠬ኱"),a0lBywSP6DgRtnsHr9AjXW,My7Dwqvs6bfGNSIgX.DOTALL)
	for PcOUYpACoRnGhSWdiJV in fsKS5t6mhrx0:
		a0lBywSP6DgRtnsHr9AjXW = a0lBywSP6DgRtnsHr9AjXW.replace(PcOUYpACoRnGhSWdiJV,hhlbF1Sns5TrEN8QPCYmL4(u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨኲ")+PcOUYpACoRnGhSWdiJV+k5dztomYyN3H(u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨኳ"))
	S3KjEaY4lGZDnRFugP0(BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠧศๆอ฾๏๐ัศฬࠣห้ษฮ๋ำฬࠤๆ๐ࠠศๆหีฬ๋ฬࠨኴ"),a0lBywSP6DgRtnsHr9AjXW)
	return
def u4LipQtlOr7U85():
	ZPXx9tplQ10D2skiFHqb = gItVahxL0w(u"ࠨส฼ฺࠥอไฤิิหึูࠦๅ๋ࠣห้ื๊ๆ๊อࠤ่๎ๆหำ๋่ࠥะ่โำࠣษ๊้ว็์ฬࠤฯ่ฯ๋็ࠣ์ฯษฮ๋ำࠣห้็๊ะ์๋ࠤํํะ่ࠢส่ศุัศำ๋ࠣ๏ࠦวๅลึ๋๊่ࠦศๆฦี็อๅࠡ็฼ࠤอ฿ึ๊ࠡๆห้ะวๅ์ࠪኵ")
	UUdtxEKOHDTq5YkcWLvg = PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠩ็ฮ็ี๊ๆࠢส่ๆ๐ฯ๋๊ࠣหุะฮะ็ࠣหู้็ๆࠢส่๏๋๊็๋่ࠢฯษฮ๋ำ๊ࠤฬูสฯั่ࠤฬ๊ำ่็ࠣห้๐ำศำࠣ࠲ࠥษๅศࠢ฼ำฮࠦวิ้่ࠤ๊ะสศๆํอࠥ็็ั้ࠣฮ็๎ๅࠡสอัึ๐ใࠡษ็ๅ๏ี๊้ࠢห์็ะࠠศๅหี๋ࠥๆ๊ࠡๅฮࠥอไิ้่ࠤฬ๊่ศฯาࠤ࠳ࠦรๆษࠣหู้็ๆࠢส่ศ฿ไ๊๋ࠢห้ษำโๆࠣๅ์๎๋ࠠฯิ็ࠥอไโ์า๎ํࠦลๅ๋ࠣห้ษๅศ็ࠣวํࠦลๅ๋ࠣห้๎ัศรࠣ์้้ๆࠡสๅๅืฯࠠไสํีฮ࠭኶")
	R9RpBFyY4IaZubcG8fNndJeHQ = UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠪว๊อࠠศๆฦี็อๅࠡใ๊๎ࠥะำหะา้๊ࠥไหไา๎๊่ࠦศๆอวำ๐ั๊ࠡ็็๋ࠦศๆไาหึูࠦะัࠣห้ั่ศ่ํࠤํอไะไสส็ࠦ࠮ࠡ็ฮ่ฬࠦัใ็ࠣ࠹࠹࠺ࠠห฻้๎ࠥ࠻ࠠะไสส็่ࠦࠡ࠶࠷ࠤะอๆ๋หࠣษ้๏ࠠศๆฦ้ฬ๋ࠠฤ๊ࠣษ้๏ࠠศๆ๋ีฬวࠠษฯึฬࠥอำหะาห๊้ࠠๅๆึ๋๊ࠦวๅ์่๎๋ࠦร้ࠢึ๋๊ࠦวๅ์ึหึ࠭኷")
	mR4VLhryYT2koGU6iBX = ZPXx9tplQ10D2skiFHqb+NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠫ࠿ࠦࠧኸ")+UUdtxEKOHDTq5YkcWLvg+UnWjVbo503mEMv9KF(u"ࠬࠦ࠮ࠡࠩኹ")+R9RpBFyY4IaZubcG8fNndJeHQ
	bFnD6Nh75IQcKrTke3gux4PvwRGUfS(PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ኺ"),FGDJwkEbTB5SoXujs3f(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪኻ"),mR4VLhryYT2koGU6iBX,b05yftsZ6NYgIKP(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫኼ"))
	return
def RR8P1CEUq6m(type,mR4VLhryYT2koGU6iBX,showDialogs=vvHpKfcqRnrFzjG(u"ࡘࡷࡻࡥᙢ"),url=jSu5Cg2Ub1OAkZVs8Yoz(u"ࠩࠪኽ"),iW6eqtHJGnzFhTSgduj7Pys2w=k5dztomYyN3H(u"ࠪࠫኾ"),Gfsr6KpyVRovQmB8xcXUJ=EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠫࠬ኿"),VDyaOQ1KCF3MNBidmj5cUo2rz=l0WAe1f7Bpi5ZXk(u"ࠬ࠭ዀ")):
	dluP8Jc7jNg2BMDfaOvRnyx3Tqe4h = hhlbF1Sns5TrEN8QPCYmL4(u"࡙ࡸࡵࡦᙣ")
	if not jjwPCAGBnWFIl2L0(C2dgEDAKQGsvh(u"࠭ࡃࡕࡇ࠼ࡈࡘ࠷࠹ࡗࡗ࠳࡚ࡘ࡞ࠧ዁")):
		if showDialogs:
			G7Nzc5afvT3C = (NVS30xAdRFMIw1n9CislkE2(u"ࠧศๆึ฻ึࡀࠧዂ") in mR4VLhryYT2koGU6iBX and b05yftsZ6NYgIKP(u"ࠨษ็้่อๆ࠻ࠩዃ") in mR4VLhryYT2koGU6iBX and V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠩส่๊๊แ࠻ࠩዄ") in mR4VLhryYT2koGU6iBX and gItVahxL0w(u"ࠪห้ิืฤࠩዅ") in mR4VLhryYT2koGU6iBX and T6wRistc1SCo4hqObgumK(u"ࠫฬ๊ๅึัิ࠾ࠬ዆") in mR4VLhryYT2koGU6iBX)
			if not G7Nzc5afvT3C: dluP8Jc7jNg2BMDfaOvRnyx3Tqe4h = mmwySO1P4jnKz5(PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ዇"),YB5xyI7MaRslVpv(u"࠭ࠧወ"),sRth5giAQzWlEVm7JOX(u"ࠧࠨዉ"),BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠨ้็ࠤฯืำๅ๊ࠢิ์ࠦวๅำึห้ฯࠠฦๆ์ࠤฬ๊ๅษำ่ะࠬዊ"),mR4VLhryYT2koGU6iBX.replace(QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠩ࡟ࡠࡳ࠭ዋ"),gItVahxL0w(u"ࠪࡠࡳ࠭ዌ")))
	elif showDialogs:
		mR4VLhryYT2koGU6iBX = BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠫࡡࡢ࡮ห็ุ้ࠣำࠠศๆิืฬ๊ษ࡝࡞ࡱฮ๊ࠦๅิฯࠣีุอไส࡞࡟ࡲฯ๋ࠠๆีะࠤฬ๊ัิษ็อࡡࡢ࡮ห็ุ้ࠣำࠠศๆิืฬ๊ษ࡝࡞ࡱฮ๊ࠦๅิฯࠣห้ืำศๆฬࠫው")
		DxVl4LIwUbCRzyTah2Huo0s = mmwySO1P4jnKz5(jSu5Cg2Ub1OAkZVs8Yoz(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬዎ"),vvHpKfcqRnrFzjG(u"࠭ࠧዏ"),jx7s8T0BFgODXLMzIYedf(u"ࠧࠨዐ"),v5EA6TqHX3s4jzBMk(u"ࠨฬ่ࠤู๊อࠡำึห้ะใࠨዑ")+k5dztomYyN3H(u"ࠩࠣࠤ࠶࠵࠵ࠨዒ"),C2jP0iLNGKnHu9xp(u"๋้ࠪࠦสา์าࠤสืำศๆࠣีุอไสࠢไหึเษࠨዓ"))
		j9j8CXBQkl = mmwySO1P4jnKz5(QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫዔ"),jx7s8T0BFgODXLMzIYedf(u"ࠬ࠭ዕ"),v5EA6TqHX3s4jzBMk(u"࠭ࠧዖ"),BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠧห็ุ้ࠣำࠠาีส่ฯ้ࠧ዗")+gItVahxL0w(u"ࠨࠢࠣ࠶࠴࠻ࠧዘ"),fY5wTlhtnOc0Er6sdy4k87b(u"๊่ࠩࠥะั๋ัࠣษึูวๅࠢิืฬ๊ษࠡใสี฿ฯࠧዙ"))
		L476YCQd8HXZ = mmwySO1P4jnKz5(jSu5Cg2Ub1OAkZVs8Yoz(u"ࠪࡧࡪࡴࡴࡦࡴࠪዚ"),QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠫࠬዛ"),jSu5Cg2Ub1OAkZVs8Yoz(u"ࠬ࠭ዜ"),sRth5giAQzWlEVm7JOX(u"࠭สๆ่ࠢืาࠦัิษ็ฮ่࠭ዝ")+l0WAe1f7Bpi5ZXk(u"ࠧࠡࠢ࠶࠳࠺࠭ዞ"),LgpdP3UjFRnlX(u"ࠨ้็ࠤฯื๊ะࠢศีุอไࠡำึห้ฯࠠโษิ฾ฮ࠭ዟ"))
		RH08LJS4xBzANZbYIin9 = mmwySO1P4jnKz5(vvHpKfcqRnrFzjG(u"ࠩࡦࡩࡳࡺࡥࡳࠩዠ"),k5dztomYyN3H(u"ࠪࠫዡ"),QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠫࠬዢ"),QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠬะๅࠡ็ึัࠥืำศๆอ็ࠬዣ")+sRth5giAQzWlEVm7JOX(u"࠭ࠠࠡ࠶࠲࠹ࠬዤ"),YB5xyI7MaRslVpv(u"่ࠧๆࠣฮึ๐ฯࠡวิืฬ๊ࠠาีส่ฮࠦแศำ฽อࠬዥ"))
		dluP8Jc7jNg2BMDfaOvRnyx3Tqe4h = mmwySO1P4jnKz5(UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨዦ"),NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠩࠪዧ"),QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠪࠫየ"),UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠫฯ๋ࠠๆีะࠤึูวๅฬๆࠫዩ")+fY5wTlhtnOc0Er6sdy4k87b(u"ࠬࠦࠠ࠶࠱࠸ࠫዪ"),b05yftsZ6NYgIKP(u"࠭็ๅࠢอี๏ีࠠฦำึห้ࠦัิษ็อࠥ็วา฼ฬࠫያ"))
	ggfedDsABTMIh = hvc2sXOB31KTLgiZaQUR9xuGjloYS(sRth5giAQzWlEVm7JOX(u"࠵࠵ᘌ"),v5EA6TqHX3s4jzBMk(u"ࡌࡡ࡭ࡵࡨᙤ"))
	XXWp48gSztHMbv2nA1aT3YRfL5CG = vvHpKfcqRnrFzjG(u"ࠧࡂࡘ࠽ࠤࠬዬ")+ggfedDsABTMIh+FGDJwkEbTB5SoXujs3f(u"ࠨ࠯ࠪይ")+type
	SLujV8UBJvsF9fwgqQ7y = WMkAjB1RgN7q(u"ࡕࡴࡸࡩᙦ") if NVS30xAdRFMIw1n9CislkE2(u"ࠩࡢࡔࡗࡕࡂࡍࡇࡐࡣࠬዮ") in Gfsr6KpyVRovQmB8xcXUJ else V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࡆࡢ࡮ࡶࡩᙥ")
	if not dluP8Jc7jNg2BMDfaOvRnyx3Tqe4h:
		if showDialogs: ZIOHgA3z0TBR(UnWjVbo503mEMv9KF(u"ࠪࠫዯ"),LgpdP3UjFRnlX(u"ࠫࠬደ"),qbPw1d3KimF(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨዱ"),BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠭สๆࠢศ่฿อมࠡษ็ษึูวๅࠢห๊ฬวฺࠠๆ์ࠤ฼๊ศไࠩዲ"))
		return EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࡈࡤࡰࡸ࡫ᙧ")
	VVa8XOJSoQyW4du5 = tUXmK5PeEH9SDq.getInfoLabel(T6wRistc1SCo4hqObgumK(u"ࠧࡔࡻࡶࡸࡪࡳ࠮ࡇࡴ࡬ࡩࡳࡪ࡬ࡺࡐࡤࡱࡪ࠭ዳ"))
	mR4VLhryYT2koGU6iBX += qbPw1d3KimF(u"ࠨࠢ࡟ࡠࡳࡢ࡜࡯࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾ࠢ࡟ࡠࡳࡇࡤࡥࡱࡱࠤ࡛࡫ࡲࡴ࡫ࡲࡲ࠿ࠦࠧዴ")+RhVj0vAt5kPHm+jx7s8T0BFgODXLMzIYedf(u"ࠩࠣ࠾ࡡࡢ࡮ࠨድ")
	mR4VLhryYT2koGU6iBX += BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠪࡉࡲࡧࡩ࡭ࠢࡖࡩࡳࡪࡥࡳ࠼ࠣࠫዶ")+ggfedDsABTMIh+V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠫࠥࡀ࡜࡝ࡰࡎࡳࡩ࡯ࠠࡗࡧࡵࡷ࡮ࡵ࡮࠻ࠢࠪዷ")+UUpr8jLiyQJ5l3VTow7hfu+sRth5giAQzWlEVm7JOX(u"ࠬࠦ࠺࡝࡞ࡱࠫዸ")
	mR4VLhryYT2koGU6iBX += FGDJwkEbTB5SoXujs3f(u"࠭ࡋࡰࡦ࡬ࠤࡓࡧ࡭ࡦ࠼ࠣࠫዹ")+VVa8XOJSoQyW4du5
	jZLmif48dFVOW1 = xFP4v9DfhOV8yo()
	jZLmif48dFVOW1 = F8fMqZKB4APk(jZLmif48dFVOW1)
	if jZLmif48dFVOW1: mR4VLhryYT2koGU6iBX += sRth5giAQzWlEVm7JOX(u"ࠧࠡ࠼࡟ࡠࡳࡒ࡯ࡤࡣࡷ࡭ࡴࡴ࠺ࠡࠩዺ")+jZLmif48dFVOW1
	if url: mR4VLhryYT2koGU6iBX += UnWjVbo503mEMv9KF(u"ࠨࠢ࠽ࡠࡡࡴࡕࡓࡎ࠽ࠤࠬዻ")+url
	if iW6eqtHJGnzFhTSgduj7Pys2w: mR4VLhryYT2koGU6iBX += PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠩࠣ࠾ࡡࡢ࡮ࡔࡱࡸࡶࡨ࡫࠺ࠡࠩዼ")+iW6eqtHJGnzFhTSgduj7Pys2w
	mR4VLhryYT2koGU6iBX += C2dgEDAKQGsvh(u"ࠪࠤ࠿ࡢ࡜࡯ࠩዽ")
	if showDialogs: gj7BGM5t3RZpA0vNixLqzwualb16(V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠫัอั๋ࠢส่สืำศๆࠪዾ"),hhlbF1Sns5TrEN8QPCYmL4(u"ࠬอไาฮสลࠥอไศ่อ฼ฬืࠧዿ"))
	if VDyaOQ1KCF3MNBidmj5cUo2rz:
		hbqpFfU6t7I = VDyaOQ1KCF3MNBidmj5cUo2rz
		if BLz7m2RkNrxXQwy1cGAp: hbqpFfU6t7I = hbqpFfU6t7I.encode(gItVahxL0w(u"࠭ࡵࡵࡨ࠻ࠫጀ"))
		hbqpFfU6t7I = NfzkjQicS24ZYLMWuXFRwV5Ea7.b64encode(hbqpFfU6t7I)
	elif SLujV8UBJvsF9fwgqQ7y:
		if vvHpKfcqRnrFzjG(u"ࠧࡠࡒࡕࡓࡇࡒࡅࡎࡡࡒࡐࡉࡥࠧጁ") in Gfsr6KpyVRovQmB8xcXUJ: rrD7S6pjZ1es5ydmwWgXYU = WmQXf9gYFJckoUVN4LIuaBlbz
		else: rrD7S6pjZ1es5ydmwWgXYU = la7vIpTkr6w1ZW8XUNuCLKAMzi
		if not XXRtDhYvWb35qnLBxIri7ScNUks0.path.exists(rrD7S6pjZ1es5ydmwWgXYU):
			ZIOHgA3z0TBR(PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠨࠩጂ"),fY5wTlhtnOc0Er6sdy4k87b(u"ࠩࠪጃ"),LgpdP3UjFRnlX(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ጄ"),FGDJwkEbTB5SoXujs3f(u"ุࠫาไࠡษ็วำ฽วย๋ࠢห้อำหะาหฺ๊๋ࠦำ้ࠣํา่ะࠩጅ"))
			return qbPw1d3KimF(u"ࡉࡥࡱࡹࡥᙨ")
		rlaqTwboPMcym0khV6niz2IJBHFu,WWMqcL9yHEm = [],k5dztomYyN3H(u"࠳ᘍ")
		size,count = SIG93nyQ6qCPRdkwijWlsM(rrD7S6pjZ1es5ydmwWgXYU)
		file = open(rrD7S6pjZ1es5ydmwWgXYU,WMkAjB1RgN7q(u"ࠬࡸࡢࠨጆ"))
		if size>C2jP0iLNGKnHu9xp(u"࠷࠻࠰࠳࠲࠳ᘏ"): file.seek(-b05yftsZ6NYgIKP(u"࠶࠺࠶࠱࠱࠲ᘎ"),XXRtDhYvWb35qnLBxIri7ScNUks0.SEEK_END)
		data = file.read()
		file.close()
		data = data.decode(v5EA6TqHX3s4jzBMk(u"࠭ࡵࡵࡨ࠻ࠫጇ"))
		data = TAiEC35tfFN9jBsg(data)
		p1GZLhkOD64IX = data.splitlines()
		for PcOUYpACoRnGhSWdiJV in reversed(p1GZLhkOD64IX):
			xx9fC502el4yrms1bhXw = pI0JbHhD4ZxvXmn5aercFz1flPBgC(PcOUYpACoRnGhSWdiJV)
			if xx9fC502el4yrms1bhXw: continue
			RRQtLerl19fmxZ3sKoVSanyqTvDJP = My7Dwqvs6bfGNSIgX.findall(jSu5Cg2Ub1OAkZVs8Yoz(u"ࠧ࡟ࠪ࡟ࡨ࠰࠳ࠨ࡝ࡦ࠮࠱ࡡࡪࠫࠡ࡞ࡧ࠯࠿ࡢࡤࠬ࠼࡟ࡨ࠰ࡢ࠮࡝ࡦ࠮࠭࠮࠮ࠠࡕ࠼࡟ࡨ࠰࠯ࠧገ"),PcOUYpACoRnGhSWdiJV,My7Dwqvs6bfGNSIgX.DOTALL)
			if RRQtLerl19fmxZ3sKoVSanyqTvDJP:
				PcOUYpACoRnGhSWdiJV = PcOUYpACoRnGhSWdiJV.replace(RRQtLerl19fmxZ3sKoVSanyqTvDJP[LgpdP3UjFRnlX(u"࠰ᘑ")][LgpdP3UjFRnlX(u"࠰ᘑ")],RRQtLerl19fmxZ3sKoVSanyqTvDJP[LgpdP3UjFRnlX(u"࠰ᘑ")][UxS67uoGThbMwnfNRzy4gajLd23JH(u"࠷ᘐ")]).replace(RRQtLerl19fmxZ3sKoVSanyqTvDJP[LgpdP3UjFRnlX(u"࠰ᘑ")][RqldvxFuM5GEQ2HAz93o7afBb0(u"࠳ᘒ")],UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠨࠩጉ"))
			else:
				RRQtLerl19fmxZ3sKoVSanyqTvDJP = My7Dwqvs6bfGNSIgX.findall(T6wRistc1SCo4hqObgumK(u"ࠩࡡࠬࡡࡪࠫ࠻࡞ࡧ࠯࠿ࡢࡤࠬ࡞࠱ࡠࡩ࠱ࠩࠩࠢࡗ࠾ࡡࡪࠫࠪࠩጊ"),PcOUYpACoRnGhSWdiJV,My7Dwqvs6bfGNSIgX.DOTALL)
				if RRQtLerl19fmxZ3sKoVSanyqTvDJP: PcOUYpACoRnGhSWdiJV = PcOUYpACoRnGhSWdiJV.replace(RRQtLerl19fmxZ3sKoVSanyqTvDJP[jSu5Cg2Ub1OAkZVs8Yoz(u"࠳ᘔ")][gItVahxL0w(u"࠳ᘓ")],sRth5giAQzWlEVm7JOX(u"ࠪࠫጋ"))
			rlaqTwboPMcym0khV6niz2IJBHFu.append(PcOUYpACoRnGhSWdiJV)
			if len(str(rlaqTwboPMcym0khV6niz2IJBHFu))>LgpdP3UjFRnlX(u"࠵࠷࠷࠰࠱࠲ᘕ"): break
		rlaqTwboPMcym0khV6niz2IJBHFu = reversed(rlaqTwboPMcym0khV6niz2IJBHFu)
		hbqpFfU6t7I = jSu5Cg2Ub1OAkZVs8Yoz(u"ࠫࡡࡸ࡜࡯ࠩጌ").join(rlaqTwboPMcym0khV6niz2IJBHFu)
		hbqpFfU6t7I = hbqpFfU6t7I.encode(k5dztomYyN3H(u"ࠬࡻࡴࡧ࠺ࠪግ"))
		hbqpFfU6t7I = NfzkjQicS24ZYLMWuXFRwV5Ea7.b64encode(hbqpFfU6t7I)
	else: hbqpFfU6t7I = sRth5giAQzWlEVm7JOX(u"࠭ࠧጎ")
	url = AK5RqLhji4W1wt9VdrCD3PGeQM[b05yftsZ6NYgIKP(u"ࠧࡑ࡛ࡗࡌࡔࡔࠧጏ")][jSu5Cg2Ub1OAkZVs8Yoz(u"࠷ᘖ")]
	tWha1P9LVeuNxpQUAB = {hhlbF1Sns5TrEN8QPCYmL4(u"ࠨࡵࡸࡦ࡯࡫ࡣࡵࠩጐ"):XXWp48gSztHMbv2nA1aT3YRfL5CG,k5dztomYyN3H(u"ࠩࡰࡩࡸࡹࡡࡨࡧࠪ጑"):mR4VLhryYT2koGU6iBX,b05yftsZ6NYgIKP(u"ࠪࡰࡴ࡭ࡦࡪ࡮ࡨࠫጒ"):hbqpFfU6t7I}
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(SToQEHqGtMnAlFbCz4wxBDuOsmW7,k5dztomYyN3H(u"ࠫࡕࡕࡓࡕࠩጓ"),url,tWha1P9LVeuNxpQUAB,QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠬ࠭ጔ"),YB5xyI7MaRslVpv(u"࠭ࠧጕ"),C2jP0iLNGKnHu9xp(u"ࠧࠨ጖"),YB5xyI7MaRslVpv(u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕ࠰ࡗࡊࡔࡄࡠࡇࡐࡅࡎࡒ࠭࠲ࡵࡷࠫ጗"))
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	if jx7s8T0BFgODXLMzIYedf(u"ࠩࠥࡷࡺࡩࡣࡦࡧࡧࡩࡩࠨ࠺ࠡ࠳࠯ࠫጘ") in MK6ZT2zjC1SbmveNFqor: tUEvo5HAfIjZgcdYxNJ8awu = EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࡘࡷࡻࡥᙩ")
	else: tUEvo5HAfIjZgcdYxNJ8awu = jx7s8T0BFgODXLMzIYedf(u"ࡋࡧ࡬ࡴࡧᙪ")
	if showDialogs:
		if tUEvo5HAfIjZgcdYxNJ8awu:
			gj7BGM5t3RZpA0vNixLqzwualb16(hhlbF1Sns5TrEN8QPCYmL4(u"ࠪฮ๊ࠦวๅวิืฬ๊ࠧጙ"),NVS30xAdRFMIw1n9CislkE2(u"ࠫอ์ฬศฯࠪጚ"))
			ZIOHgA3z0TBR(RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠬ࠭ጛ"),b05yftsZ6NYgIKP(u"࠭ࠧጜ"),PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠧࡎࡧࡶࡷࡦ࡭ࡥࠡࡵࡨࡲࡹ࠭ጝ"),UnWjVbo503mEMv9KF(u"ࠨฬ่ࠤสืำศๆࠣห้ืำศๆฬࠤอ์ฬศฯࠪጞ"))
		else:
			gj7BGM5t3RZpA0vNixLqzwualb16(EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠩ็่ศูแࠨጟ"),nr5mZG89ICi6cgt4MfLJa0(u"ࠪๅู๊ࠠโ์ࠣห้หัิษ็ࠫጠ"))
			ZIOHgA3z0TBR(RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠫࠬጡ"),UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠬ࠭ጢ"),LgpdP3UjFRnlX(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩጣ"),QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠧฯูฦࠤํ็ิๅࠢไ๎ࠥหัิษ็ࠤฬ๊ัิษ็อࠬጤ"))
	return tUEvo5HAfIjZgcdYxNJ8awu
def jrQbZYTylP9wdD():
	ZPXx9tplQ10D2skiFHqb = PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠨ࠳࠱ࠤࠥࠦࡉࡧࠢࡼࡳࡺࠦࡨࡢࡸࡨࠤࡵࡸ࡯ࡣ࡮ࡨࡱࠥࡽࡩࡵࡪࠣࡅࡷࡧࡢࡪࡥࠣࡸࡪࡾࡴࡵࠢࡷ࡬ࡪࡴࠠࡨࡱࠣࡸࡴࠦࠢࡌࡱࡧ࡭ࠥࡏ࡮ࡵࡧࡵࡪࡦࡩࡥࠡࡕࡨࡸࡹ࡯࡮ࡨࡵࠥࠤࡦࡴࡤࠡࡥ࡫ࡥࡳ࡭ࡥࠡࡶ࡫ࡩࠥ࡬࡯࡯ࡶࠣࡸࡴࠦࠢࡂࡴ࡬ࡥࡱࠨࠧጥ")
	UUdtxEKOHDTq5YkcWLvg = V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠩ࠴࠲ࠥࠦࠠฦาสࠤ้ี๊ไุ่่๊ࠢษࠡใํࠤฬ๊รฮำไࠤฬู๊าสํอࠥ็วั้หࠤส๊้ࠡว฼ำฬีวห๋ࠢหัํษࠡๅ๋ำ๏ࠦหๆࠢ฽๎ึࠦวๅะฺࠤฬ๊ๅิฬัำ๊ࠦลๅ๋ࠣࠦࡆࡸࡩࡢ࡮ࠥࠫጦ")
	ZIOHgA3z0TBR(YB5xyI7MaRslVpv(u"ࠪࠫጧ"),k5dztomYyN3H(u"ࠫࠬጨ"),jx7s8T0BFgODXLMzIYedf(u"ࠬࡇࡲࡢࡤ࡬ࡧࠥࡖࡲࡰࡤ࡯ࡩࡲ࠭ጩ"),ZPXx9tplQ10D2skiFHqb+jx7s8T0BFgODXLMzIYedf(u"࠭࡜࡯࡞ࡱࠫጪ")+UUdtxEKOHDTq5YkcWLvg)
	ZPXx9tplQ10D2skiFHqb = NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠧ࠳࠰ࠣࠤࠥࡏࡦࠡࡻࡲࡹࠥࡩࡡ࡯࡞ࠪࡸࠥ࡬ࡩ࡯ࡦࠣࠦࡆࡸࡩࡢ࡮ࠥࠤ࡫ࡵ࡮ࡵࠢࡷ࡬ࡪࡴࠠࡤࡪࡤࡲ࡬࡫ࠠࡵࡪࡨࠤࡸࡱࡩ࡯ࠢࡤࡲࡩࠦࡴࡩࡧࡱࠤࡨ࡮ࡡ࡯ࡩࡨࠤࡹ࡮ࡥࠡࡨࡲࡲࡹ࠭ጫ")
	UUdtxEKOHDTq5YkcWLvg = nr5mZG89ICi6cgt4MfLJa0(u"ࠨ࠴࠱ࠤࠥࠦลัษ่๊ࠣࠦสอัࠣห้ิืࠡࠤࡄࡶ࡮ࡧ࡬ࠣࠢไๆ๊ࠦศห฼ํ๎ึࠦวๅฮ็ำࠥัๅࠡไ่ࠤอะฺ๋ำࠣห้ิืࠡษ็ุ้ะฮะ็ࠣษ้๏ࠠࠣࡃࡵ࡭ࡦࡲࠢࠨጬ")
	ZIOHgA3z0TBR(v5EA6TqHX3s4jzBMk(u"ࠩࠪጭ"),C2dgEDAKQGsvh(u"ࠪࠫጮ"),PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠫࡋࡵ࡮ࡵࠢࡓࡶࡴࡨ࡬ࡦ࡯ࠪጯ"),ZPXx9tplQ10D2skiFHqb+b05yftsZ6NYgIKP(u"ࠬࡢ࡮࡝ࡰࠪጰ")+UUdtxEKOHDTq5YkcWLvg)
	ZPXx9tplQ10D2skiFHqb = C2dgEDAKQGsvh(u"࠭࠳࠯ࠢࠣࠤࡎ࡬ࠠࡺࡱࡸࠤࡩࡵ࡮࡝ࠩࡷࠤ࡭ࡧࡶࡦࠢࡄࡶࡦࡨࡩࡤࠢࡎࡩࡾࡨ࡯ࡢࡴࡧࠤࡹ࡮ࡥ࡯ࠢࡪࡳࠥࡺ࡯ࠡࠤࡎࡳࡩ࡯ࠠࡊࡰࡷࡩࡷ࡬ࡡࡤࡧࠣࡗࡪࡺࡴࡪࡰࡪࡷࠧࠦࡡ࡯ࡦࠣࡧ࡭ࡧ࡮ࡨࡧࠣࡸ࡭࡫ࠠࡳࡧࡪ࡭ࡴࡴࡡ࡭ࠢࡶࡩࡹࡺࡩ࡯ࡩࡶࠫጱ")
	UUdtxEKOHDTq5YkcWLvg = YB5xyI7MaRslVpv(u"ࠧ࠴࠰ࠣࠤࠥหะศࠢ็้ࠥ๐ใ็ࠢ็ำ๏้ࠠๅ๊ะอ๋ࠥแศฬํัࠥ฿ัษ์ฬࠤๆอะ่สࠣษ้๏ࠠฦ฻าหิอส๊ࠡสะ์ฯࠠไ๊า๎ࠥัๅࠡ฼ํีࠥหูะษาหฯࠦวๅ็้฻็ฯࠠศๆฯ฾ึอแ๋หࠪጲ")
	ZIOHgA3z0TBR(rbjsM8cRFiuA1(u"ࠨࠩጳ"),b05yftsZ6NYgIKP(u"ࠩࠪጴ"),T6wRistc1SCo4hqObgumK(u"ࠪࡊࡴࡴࡴࠡࡒࡵࡳࡧࡲࡥ࡮ࠩጵ"),ZPXx9tplQ10D2skiFHqb+hhlbF1Sns5TrEN8QPCYmL4(u"ࠫࡡࡴ࡜࡯ࠩጶ")+UUdtxEKOHDTq5YkcWLvg)
	tLwvQlnjGpWsRVCN1 = mmwySO1P4jnKz5(EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬጷ"),qbPw1d3KimF(u"࠭ࠧጸ"),rbjsM8cRFiuA1(u"ࠧࠨጹ"),gItVahxL0w(u"ࠨࡈࡲࡲࡹࠦࡳࡦࡶࡷ࡭ࡳ࡭ࡳࠨጺ"),v5EA6TqHX3s4jzBMk(u"ࠩࡇࡳࠥࡿ࡯ࡶࠢࡺࡥࡳࡺࠠࡵࡱࠣ࡫ࡴࠦࡴࡰࠢࠥࡏࡴࡪࡩࠡࡋࡱࡸࡪࡸࡦࡢࡥࡨࠤࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸࠨࠠ࡯ࡱࡺࠤࡄ࠭ጻ")+BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠪࡠࡳࡢ࡮ࠨጼ")+UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠫ์๊ࠠหำํำࠥอไั้สฬࠥหไ๊ࠢ็์าฯࠠฦ฻าหิอส๊ࠡสะ์ฯࠠไ๊า๎ࠥษไร่ยࠫጽ"))
	if tLwvQlnjGpWsRVCN1==hhlbF1Sns5TrEN8QPCYmL4(u"࠷ᘗ"): b2kPsA3vynO7wuSYliqItrZj()
	return
def bjJm7InvPNhAHVCWra6L():
	ZIOHgA3z0TBR(LgpdP3UjFRnlX(u"ࠬ࠭ጾ"),YB5xyI7MaRslVpv(u"࠭ࠧጿ"),gItVahxL0w(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪፀ"),NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠨ฼ส่ออࠠศๆึฬอࠦ็้่๊ࠢࠥอไๆ๊ๅ฽ࠥอไฤื็๎ࠥอไๆ฼ำ๎๊ࠥไษำ้ห๊า้ࠠๆ็ฮศ้ฯࠡไ่ࠤอะิ฻์็ࠤฬ๊ัศสฺࠤฬ๊ะ๋ࠢ็หࠥ๐ูๆๆࠣฯ๊ࠦโๆࠢหษึูวๅุ่่๊ࠢษࠡว็ํࠥอไๆสิ้ัࠦๅ็ࠢส่็อฦๆหࠣห้ืฦ๋ีํอ๊ࠥไษำ้ห๊าࠧፁ"))
	return
def c7ykfWCNJE():
	mR4VLhryYT2koGU6iBX = gItVahxL0w(u"๊ࠩิฬࠦวๅสิ๊ฬ๋ฬࠡ็ัฺูࠦแใู่้ࠣเษࠡษ็฽ึฮ๊ส๋่่ࠢ์่ࠠาสࠤ้อ๋ࠠ็้฽ࠥ๎ฬ้ั้ࠣํอโฺࠢไ๎์อࠠฤใ็ห๊่ࠦๆี็ื้อสࠡ็อีั๋ษࠡล๋ࠤ๊ีศๅฮฬࠤส๊้ࠡษ็่฿ฯࠠศๆ฼ีอ๐ษ๊ࠡส่๎ࠦไ฻ษอࠤฬิั๊๋่ࠢฬ๊้ࠦฮาࠤุฮศࠡๆ็ฮ่ืวาࠩፂ")
	ZIOHgA3z0TBR(jSu5Cg2Ub1OAkZVs8Yoz(u"ࠪࠫፃ"),sRth5giAQzWlEVm7JOX(u"ࠫࠬፄ"),b05yftsZ6NYgIKP(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨፅ"),mR4VLhryYT2koGU6iBX)
	return
def qLwTxrPust3kKHoQ1Ei2():
	mR4VLhryYT2koGU6iBX = jSu5Cg2Ub1OAkZVs8Yoz(u"࠭วๅำ๋หอ฽ࠠศๆห฻๏ฬษࠡๆสࠤ฾๊วให่ࠣ์อࠠษษ็ฬึ์วๆฮࠣ์฿อไษษࠣหู้ศษ๊ࠢ์๋ࠥๆࠡษ็้ํู่ࠡษ็วฺ๊๊ࠡษ็้฿ึ๊ࠡๆ็ฬึ์วๆฮࠪፆ")
	ZIOHgA3z0TBR(PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠧࠨፇ"),BoWHNb9daQVCF16A(u"ࠨࠩፈ"),UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬፉ"),mR4VLhryYT2koGU6iBX)
	return
def hDamHMyRj5wPpGSNl():
	mR4VLhryYT2koGU6iBX = C2jP0iLNGKnHu9xp(u"๋ࠪ๏ࠦำ๋ำไีฬะࠠๅษࠣ๎ุะื๋฻ࠣห้ฮั็ษ่ะࠥอำหะาห๊ํวࠡสึฬอࠦใ้่๊ห๋ࠥอๆ์ฬࠤ๊์ࠠศๆู่ิืࠠฤ๊ࠣฬาอฬสࠢศ่๎ࠦวีฬิห่ࠦัิ็ํࠤศ๎ࠠอัํำฮࠦร้ࠢ็หࠥ๐ูาใ๊หࠥอไษำ้ห๊าࠧፊ")
	ZIOHgA3z0TBR(T6wRistc1SCo4hqObgumK(u"ࠫࠬፋ"),b05yftsZ6NYgIKP(u"ࠬ࠭ፌ"),nr5mZG89ICi6cgt4MfLJa0(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩፍ"),hhlbF1Sns5TrEN8QPCYmL4(u"ࠧิ์ิๅึอสࠡีํสฮࠦร้่ࠢะ์๎ไสࠩፎ"),mR4VLhryYT2koGU6iBX)
	return
def pG3vnS7UCkhJ5NEgFl2ca0zjuIo():
	mR4VLhryYT2koGU6iBX = fY5wTlhtnOc0Er6sdy4k87b(u"ࠨษ็ื๏ืแาษอࠤฬู๊ศ็ฬࠤ์๐ࠠิ์ิๅึอสࠡะสีั๐ษ๊ࠡ฽๎ึࠦสศส฼อ๊ࠥไๆ๊ๅ฽ࠥอไฤื็๎ࠥ๎ฬๆ์฼ࠤฬ๊ๅ้ษๅ฽ࠥะำหะา้์อ้ࠠ฻สำฮࠦสไ๊้ࠤ๊าว็์ฬࠤํ๋ิศๅ็๋ฬࠦใฬ์ิอ๊ࠥว็ࠢส่ๆ๐ฯ๋๊๊หฯࠦแ๋้สࠤส๋วࠡสฺ๎หฯࠠฤ๊้๊ࠣ์ฺ่หࠣวํࠦๅฮา๋ๅฮࠦร้ࠢไ๎์อࠠๆึๆ่ฮࠦอใ๊ๅࠤฬ๊ๅๅๅํอࡡࡴ࡜࡯࡞ࡱหู้๊าใิหฯࠦวๅะสูฮࠦ็๋ࠢึ๎ึ็ัศฬࠣฮฬฮูสࠢ็่๊๎โฺࠢส่ศ฻ไุ๋๋้ࠢะฮะ็ฬࠤๆ๐ࠠๆ๊สๆ฾ࠦโๅ์็อࠥาฯศ๋ࠢ฽ฬีษࠡฬๆ์๋ࠦๅะใ๋฽ฮࠦวๅลฯีࠥษ่ࠡ์่่่ํวࠡษ็้ํู่ࠡษ็วฺ๊๊๊ࠡ็๋ีอࠠโ้ํࠤั๐ฯส้ࠢือ๐ว๊ࠡึี๏฿ษุ๊่ࠡฬ้ไ่ษࠣๆ้๐ไสࠢฯำฬ࠭ፏ")
	bFnD6Nh75IQcKrTke3gux4PvwRGUfS(k5dztomYyN3H(u"ࠩࡦࡩࡳࡺࡥࡳࠩፐ"),BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ፑ"),mR4VLhryYT2koGU6iBX,RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧፒ"))
	return
def F5SWNut9y0ex():
	ZPXx9tplQ10D2skiFHqb = rbjsM8cRFiuA1(u"ࠬอศห฻าࠤ฾์ࠠๆๆไหฯࠦวๅัๅอࠥอไฺษ็๎ฮ࠭ፓ")
	UUdtxEKOHDTq5YkcWLvg = nr5mZG89ICi6cgt4MfLJa0(u"࠭วษฬ฼ำࠥ฿ๆࠡ็็ๅฬะࠠฤๆࠣࡱ࠸ࡻ࠸ࠨፔ")
	R9RpBFyY4IaZubcG8fNndJeHQ = jSu5Cg2Ub1OAkZVs8Yoz(u"ࠧศสอ฽ิูࠦ็่่ࠢๆอสࠡษ็ฮา๋๊ๅ๋ࠢห้ีว้่็์ิࠦࡤࡰࡹࡱࡰࡴࡧࡤࠨፕ")
	ZIOHgA3z0TBR(v5EA6TqHX3s4jzBMk(u"ࠨࠩፖ"),nr5mZG89ICi6cgt4MfLJa0(u"ࠩࠪፗ"),BoWHNb9daQVCF16A(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ፘ"),ZPXx9tplQ10D2skiFHqb,UUdtxEKOHDTq5YkcWLvg,R9RpBFyY4IaZubcG8fNndJeHQ)
	return
def O6Ei5cYHAQqXjwFBmLo():
	UUdtxEKOHDTq5YkcWLvg = QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠫฬ๊ใศึ๋ࠣํࠦๅฯิ้ࠤ๊สโหࠢ็่๊฿ไ้็สฮࠥ๐ำหะา้์ࠦวๅสิ๊ฬ๋ฬࠡๆัึ๋ࠦีโฯสฮࠥอไฦ่อี๋๐ส๊ࠡิ์ฬฮืࠡษ็ๅ๏ี๊้้สฮ๊ࠥไ้ื๋่ࠥหไ๋้สࠤอูัฺหࠣ์อี่็ࠢศ๊ฯืๆ๋ฬࠣ์ฬ๊ศา่ส้ั๊ࠦๆีะ๋ฬࠦสๅไสส๏อࠠษ฻าࠤฬ์ส่ษฤࠤ฾๋ั่ษࠣ์ศ๐ึศࠢ฼๊ิࠦสฮัํฯࠥอไษำ้ห๊าࠠ࠯๋๋ࠢีอࠠศๆหี๋อๅอࠢํืฯิฯๆࠢึฬ฾ฯࠠฤ่๋ห฾ࠦไฺ็ิࠤฬ๊ใศึࠣ࠾ࠬፙ")
	UUdtxEKOHDTq5YkcWLvg += BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠬࡢ࡮࡝ࡰࠪፚ") + BmcLzCFjuIrZP5fwXH18aN6YS(u"࠭࠱࠯ࠢฮหอะࠠๅๆุๅาอสࠡษ็ฮ๏ࠦๅฺำ๋ๅࠥษๆ่ษ่ࠣฬࠦสห฼ํีࠥ์็ศศํหࠥ๎ๅะฬ๊ࠤࠬ፛") + str(BZdvf7MIUxHQc3aCT/NVS30xAdRFMIw1n9CislkE2(u"࠶࠱ᘘ")/NVS30xAdRFMIw1n9CislkE2(u"࠶࠱ᘘ")/PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"࠳࠶ᘙ")/PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"࠵࠳ᘚ")) + EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠧࠡึ๊ีࠬ፜")
	UUdtxEKOHDTq5YkcWLvg += nr5mZG89ICi6cgt4MfLJa0(u"ࠨ࡞ࡱࠫ፝") + hhlbF1Sns5TrEN8QPCYmL4(u"ࠩ࠵࠲ࠥาฯศฺࠢ์๏๊ࠠศๆ่ำ๎ࠦไๅืไัฬะࠠศๆ่ๅึ๎ึࠡล้๋ฬࠦไศࠢอฮ฿๐ั๊่ࠡำฯํࠠࠨ፞") + str(HTNv70wWuCxtU/jx7s8T0BFgODXLMzIYedf(u"࠹࠴ᘛ")/jx7s8T0BFgODXLMzIYedf(u"࠹࠴ᘛ")/jx7s8T0BFgODXLMzIYedf(u"࠶࠹ᘜ")) + gItVahxL0w(u"ࠪࠤ๏๎ๅࠨ፟")
	UUdtxEKOHDTq5YkcWLvg += gItVahxL0w(u"ࠫࡡࡴࠧ፠") + LgpdP3UjFRnlX(u"ࠬ࠹࠮ู๋ࠡ๎้ࠦวๅ็าํ๊ࠥไึใะหฯࠦวๅฬํࠤ๋อฯาษࠣฮฯเ๊า๋้ࠢิะ็ࠡࠩ፡") + str(IIiPCruL6dT8s1lqj47SzpVHnYNm/YB5xyI7MaRslVpv(u"࠻࠶ᘝ")/YB5xyI7MaRslVpv(u"࠻࠶ᘝ")/WMkAjB1RgN7q(u"࠸࠴ᘞ")) + BmcLzCFjuIrZP5fwXH18aN6YS(u"๋๊่࠭ࠠࠫ።")
	UUdtxEKOHDTq5YkcWLvg += sRth5giAQzWlEVm7JOX(u"ࠧ࡝ࡰࠪ፣") + BoWHNb9daQVCF16A(u"ࠨ࠶࠱ࠤ๊ะ่ิูࠣห้๋ฯ๊ࠢ็ฺ่็อศฬࠣห้ะ๊ࠡไาࠤฯะฺ๋ำࠣ์๊ีส่ࠢࠪ፤") + str(UuEtImzir9/UnWjVbo503mEMv9KF(u"࠶࠱ᘟ")/UnWjVbo503mEMv9KF(u"࠶࠱ᘟ")) + FGDJwkEbTB5SoXujs3f(u"ࠩࠣืฬ฿ษࠨ፥")
	UUdtxEKOHDTq5YkcWLvg += l0WAe1f7Bpi5ZXk(u"ࠪࡠࡳ࠭፦") + v5EA6TqHX3s4jzBMk(u"ࠫ࠺࠴ࠠใืํีࠥอไๆั์ࠤ้๊ีโฯสฮࠥอไห์ࠣฮฯเ๊าࠢาหห๋ว๊่ࠡำฯํࠠࠨ፧") + str(f9Oum6c0FotxYn/jx7s8T0BFgODXLMzIYedf(u"࠷࠲ᘠ")/jx7s8T0BFgODXLMzIYedf(u"࠷࠲ᘠ")) + qbPw1d3KimF(u"ࠬࠦำศ฻ฬࠫ፨")
	UUdtxEKOHDTq5YkcWLvg += NVS30xAdRFMIw1n9CislkE2(u"࠭࡜࡯ࠩ፩") + PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠧ࠷࠰ࠣะิอࠠใืํีࠥอไๆั์ࠤ้๊ีโฯสฮࠥอไห์ࠣฮฯเ๊าࠢๆฯ๏ืว๊่ࠡำฯํࠠࠨ፪") + str(c1lwnq73vkXsVjEhFpeoZtD/jSu5Cg2Ub1OAkZVs8Yoz(u"࠸࠳ᘡ")) + qbPw1d3KimF(u"ࠨࠢาๆ๏่ษࠨ፫")
	UUdtxEKOHDTq5YkcWLvg += l0WAe1f7Bpi5ZXk(u"ࠩ࡟ࡲࠬ፬") + C2dgEDAKQGsvh(u"ࠪ࠻࠳ࠦศะ๊้ࠤ่อิࠡๆ็ูๆำวหࠢส่ฯ๐ࠠหฬ฽๎ึࠦศิำ฼อࠥ๎ๅะฬ๊ࠤࠬ፭") + str(SToQEHqGtMnAlFbCz4wxBDuOsmW7) + qbPw1d3KimF(u"ࠫࠥีโ๋ไฬࠫ፮")
	UUdtxEKOHDTq5YkcWLvg += jSu5Cg2Ub1OAkZVs8Yoz(u"ࠬࡢ࡮࡝ࡰࠪ፯") + EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠭ๅฬๆส࠾ࠥ฻แฮษอࠤ็๎วว็ࠣห้ษแๅษ่ࠤํอไๆี็ื้อส๊ࠡส่า๊โศฬࠣ฽๊ื็ศࠢࠪ፰") + str(UuEtImzir9/NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠹࠴ᘢ")/NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠹࠴ᘢ")) + v5EA6TqHX3s4jzBMk(u"ࠧࠡีส฽ฮࠦ࠮ࠡล่ห่่ࠥศศ่ࠤศ์่ศ฻ࠣห้็๊ะ์๋๋ฬะࠠโ฻่ี์อࠠࠨ፱") + str(IIiPCruL6dT8s1lqj47SzpVHnYNm/NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠹࠴ᘢ")/NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠹࠴ᘢ")/LgpdP3UjFRnlX(u"࠶࠹ᘣ")) + NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠨࠢฦ๎ฬ๋ࠠ࠯ࠢฦ้ฬࠦๅๅใสฮࠥอไโ์า๎ํࠦแฺ็ิ๋ฬࠦࠧ፲") + str(f9Oum6c0FotxYn/NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠹࠴ᘢ")/NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠹࠴ᘢ")) + jx7s8T0BFgODXLMzIYedf(u"ࠩࠣืฬ฿ษࠡใๅ฻ࠥ࠴ࠠฤ็สࠤๆำีࠡำๅ้ࠥอไฦืาหึࠦแฺ็ิ๋ࠥ࠭፳") + str(c1lwnq73vkXsVjEhFpeoZtD/NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠹࠴ᘢ")) + C2dgEDAKQGsvh(u"ࠪࠤิ่๊ใหࠣ࠲ࠥษๅศࠢไัฺࠦวีฬิห่ࠦเࡊࡒࡗ࡚ࠥ็ูๆำ๊ࠤࠬ፴") + str(SToQEHqGtMnAlFbCz4wxBDuOsmW7) + BoWHNb9daQVCF16A(u"ࠫࠥีโ๋ไฬࠫ፵")
	bFnD6Nh75IQcKrTke3gux4PvwRGUfS(T6wRistc1SCo4hqObgumK(u"ࠬࡸࡩࡨࡪࡷࠫ፶"),YB5xyI7MaRslVpv(u"࠭ๅศ๊ࠢ์ࠥอไไษืࠤฬ๊ๅิฬัำ๊ࠦแ๋ࠢส่อืๆศ็ฯࠫ፷"),UUdtxEKOHDTq5YkcWLvg,jSu5Cg2Ub1OAkZVs8Yoz(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪ፸"))
	return
def ZZ06uGgKCsEiTMqBaOPz9Rx():
	mR4VLhryYT2koGU6iBX = WMkAjB1RgN7q(u"ࠨษ็ๅฬ฻ไสࠢอ฽๋๐ࠠๆฮ็ำࠥฮๆโีࠣหุ๋็ࠡษ็วฺ๊๊๊ࠡส่๋่ืสࠢอ฽๋๐ࠠฤ่ࠣห้อำๆࠢส่ศ฻ไ๋ࠢอ้ࠥะูะ์็๋ࠥ๎แศื็อࠥ๎ๆใูฬࠤฯ฿ๆ๊่ࠢะ้ี้ࠠฬ่ࠤฯ฿ฯ๋ๆࠣหุ๋็๊ࠡหำํ์ฺࠠๆส้ฮࠦสฺ่ํࠤ๊๊แࠡส้ๅุࠦวิ็๊ࠤฬ๊รึๆํࠫ፹")
	ZIOHgA3z0TBR(QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠩࠪ፺"),EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠪࠫ፻"),l0WAe1f7Bpi5ZXk(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ፼"),mR4VLhryYT2koGU6iBX)
	return
def T98N0pY4F6KdDOf():
	mR4VLhryYT2koGU6iBX = V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠬหะศ๋ࠢหัํสไุ่่๊ࠢษࠡใํࠤฬ๊ิษๅฬࠤํะๅࠡฯ็๋ฬࠦ࠮࠯࠰ࠣวํࠦว็ๅࠣฮ฽์ࠠฤ่ࠣห้๋่ใ฻ࠣห้ษีๅ์ࠣ็ฬ์ࠠโ์๊ࠤฺ๊ใๅห้ࠣษ่ส่๋ࠢฮ๊ࠦอๅ้สࠤ࠳࠴࠮ࠡใศิ๋ࠦฬาสุ้ࠣำࠠไษืࠤฬ๊ศา่ส้ัࠦไไ์ࠣ๎็๎ๅࠡษ็ฬึ์วๆฮࠣฬ฼๊ศࠡษ็ูๆำษࠡษ็ูา๐อส๋ࠢฮำุ๊็้สࠤอีไศ่๊ࠢࠥอไึใะอࠥอไใัํ้ฮ࠭፽")
	ZIOHgA3z0TBR(BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠭ࠧ፾"),C2jP0iLNGKnHu9xp(u"ࠧࠨ፿"),T6wRistc1SCo4hqObgumK(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᎀ"),mR4VLhryYT2koGU6iBX)
	return
def eDLCX2WOuiT1tcZgKd():
	mR4VLhryYT2koGU6iBX = sRth5giAQzWlEVm7JOX(u"ࠩส่฿ืึࠡ็้ࠤูํวะหࠣห้ะิโ์ิࠤ์๎ࠠื็ส๊ࠥ฻อส๋ࠢืึ๐ษࠡษ็้฾๊่ๆษอࠤฬ๊ๅหสสำ้ฯࠠษ์้ࠤฬ๊ศา่ส้ั่ࠦศๆ่์็฿ࠠศๆุ่ๆื้้ࠠำหࠥอไื็ส๊ࠥเ๊า่ࠢ฻้๎ศ๊ࠡ็หࠥำวอห่ࠣ์ูࠦ็ัࠣห้อสึษ็ࠤฬ๎ࠠศๆิฬ฼ࠦๅฺ่ࠢ์ฬู่ࠡษ็ๅ๏ี๊้้สฮࠥอไๆึไีฮ࠭ᎁ")
	ZIOHgA3z0TBR(hhlbF1Sns5TrEN8QPCYmL4(u"ࠪࠫᎂ"),NVS30xAdRFMIw1n9CislkE2(u"ࠫࠬᎃ"),b05yftsZ6NYgIKP(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᎄ"),mR4VLhryYT2koGU6iBX)
	return
def UnphcNYbEl9GI7uBxK():
	ZIOHgA3z0TBR(nr5mZG89ICi6cgt4MfLJa0(u"࠭ࠧᎅ"),YB5xyI7MaRslVpv(u"ࠧࠨᎆ"),UnWjVbo503mEMv9KF(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᎇ"),YB5xyI7MaRslVpv(u"ࠩ็็๏ฺ๊ࠦ็็ࠤ์ึวࠡษ็๊ํ฿ࠠๆ่ࠣห้็๊ะ์๋๋ฬะࠠ࡝ࡰࠣ๎ัฮࠠหใ฼๎้ࠦลืษไอࠥอำๆ้สࠤࡡࡴࠠࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡧࡤࡢࡲࡷ࡭ࡻ࡫ࠧᎈ"))
	wOF6QJqepnRYNgv5cos13ljDtZzGd(C2dgEDAKQGsvh(u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡣࡧࡥࡵࡺࡩࡷࡧࠪᎉ"),BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࡚ࡲࡶࡧᙫ"))
	return
def Av3xKlbkMYo8uLg6W0s():
	mR4VLhryYT2koGU6iBX  = V2RbfGOBdcA6l8NTsPWzEyvS7(u"๊ࠫสฮาษࠣๆฬ๋สࠡส฼ฺฺࠥัไษอࠤฬ๊ล็ฬิ๊ฯࠦวๅั๋่๏ࠦศุ้฼ࠤ฾อฦใูࠢำࠥอไษำส้ัࠦๅฬๆࠣ็ํี๊ࠡๆอื๊ำࠠโไฺࠤ้ฮูื่ࠢืฯิฯๆ์ࠣห้๋สึใะࠤออไะะ๋่๊ࠥๅ้ษๅ฽ࠥอไโ์า๎ํ࠭ᎊ")
	mR4VLhryYT2koGU6iBX += C2jP0iLNGKnHu9xp(u"่ࠬࠦ็ฬํะฮࠦไ่าสࠤฬู๊ศศๅࠤๆอๆ่ࠢอๆึ๐ศศࠢฯ้๏฿ࠠๆีอาิ๋๊ࠡสิ๊ฬ๋ฬࠡๅ๋ำ๏ࠦไศࠢํืฯ฽ฺ๊๊้ࠤฬ๊ฯฯ๊็ࠤ้าๅ๋฻้ࠣํอโฺࠢส่อืๆศ็ฯࠤาะ้ࠡ็฼ࠤฬูสฯัส้ࠬᎋ")
	mR4VLhryYT2koGU6iBX += nr5mZG89ICi6cgt4MfLJa0(u"࠭࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠไࠥࠦࡖࡑࡐࠣࠤศ๎ࠠࠡࡒࡵࡳࡽࡿࠠࠡล๋ࠤࠥࡊࡎࡔࠢࠣวํࠦร๋ࠢะ่ࠥฮำู๋ࠣฦำื࡛࠰ࡅࡒࡐࡔࡘ࡝࡝ࡰࠪᎌ")
	mR4VLhryYT2koGU6iBX += sRth5giAQzWlEVm7JOX(u"ࠧ࡝ࡰ็ห๋ࠦ็ัษ่๋๊ࠣࠦฮๆࠣห้๋ิไๆฬࠤํหๆๆษࠣๅ็฽ࠠิ์ๅ์๊ࠦศฦื็หาࠦศฺุࠣห้๋่ศไ฼ࠤํหูศไฬࠤ๊๎วใ฻ࠣหำื้ࠡๅส๊ฯࠦสฺ็็ࠤุอศใษࠣฬิ๎ๆࠡ็ืห่๊ࠧᎍ")
	bFnD6Nh75IQcKrTke3gux4PvwRGUfS(jSu5Cg2Ub1OAkZVs8Yoz(u"ࠨࡴ࡬࡫࡭ࡺࠧᎎ"),sRth5giAQzWlEVm7JOX(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬᎏ"),mR4VLhryYT2koGU6iBX,QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭᎐"))
	mR4VLhryYT2koGU6iBX = k5dztomYyN3H(u"ࠫฬ๊ๅ้ษๅ฽ࠥอไห์ࠣฮศััหࠢหห้฿ววไࠣ฽๋ีࠠษ฻ูࠤฬ๊ๆศี๋ࠣ๏ࡀࠧ᎑")
	mR4VLhryYT2koGU6iBX += fY5wTlhtnOc0Er6sdy4k87b(u"ࠬࡢ࡮ࠨ᎒")+jx7s8T0BFgODXLMzIYedf(u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࡣ࡮ࡳࡦࡳࠠࠡࡧࡪࡽࡧ࡫ࡳࡵࠢࠣࡩ࡬ࡿࡢࡦࡵࡷࡺ࡮ࡶࠠࠡ࡯ࡲࡺ࡮ࢀ࡬ࡢࡰࡧࠤࠥࡹࡥࡳ࡫ࡨࡷ࠹ࡽࡡࡵࡥ࡫ࠤࠥࡹࡨࡢࡪ࡬ࡨ࠹ࡻ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ᎓")
	mR4VLhryYT2koGU6iBX += b05yftsZ6NYgIKP(u"ࠧ࡝ࡰ࡟ࡲࠬ᎔")+V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠨษ็ำํ๊ࠠศๆอ๎ࠥะรฬำอࠤออไฺษษๆࠥ฿ๆะࠢห฽฻ࠦวๅ่สืࠥํ๊࠻ࠩ᎕")
	mR4VLhryYT2koGU6iBX += UnWjVbo503mEMv9KF(u"ࠩ࡟ࡲࠬ᎖")+NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ๋ีาࠢࠣห้้่๋ฬࠣࠤศ๋๊าๅสࠤ้ࠥๆะษࠣࠤๆืๆิษࠣࠤฬ๊๊้่ส๊ࠥࠦศา์ฺห๋๐วࠡษ็ษ๊อัศฬࠣว้๋ว็์สࠤึ๎ำ๋ษࠣห้๐วษษ้ࠤฬ๊ำฺ๊า๎ฮࠦั้็ส๊๏อ่๊ࠠ็๊ิอ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ᎗")
	mR4VLhryYT2koGU6iBX += NVS30xAdRFMIw1n9CislkE2(u"ࠫࡡࡴ࡜࡯ࠩ᎘")+vvHpKfcqRnrFzjG(u"ࠬอไๆสิ้ั่ࠦอัࠣ฻ึ๐โสࠢ็ฮัอ่ำࠢส่฾อฦใ๋่่ࠢ์็ศࠢอัฯอฬࠡฮ๊ำ้ࠥศ๋ำࠣ์ฬ๊ๅษำ่ะࠥ๐ุ็ࠢสฺ่๊ใๅหูࠣ฿๐ัส๋่ࠢฬࠦสิฬะๆࠥอไห฻หࠤๆหะศࠢ็ำ๏้ࠠๆึๆ่ฮࠦศศๆาาํ๊ࠠๅส฼ฺࠥอไๆ๊สๆ฾่ࠦฤ์ูห๊ࠥใ๋ࠢํฮ฻ำࠠฮฮ่ࠤฬ๊ๅีๅ็อࠥ࠭᎙")
	mR4VLhryYT2koGU6iBX += UnWjVbo503mEMv9KF(u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ษิื้ࠦัิษ็อ๋ࠥฤะสฬࠤส๊้ࠡษ็้อืๅอ๋ࠢห่ะศࠡใํ๋ฬࠦวิ็ࠣฬ้ีใ๊ࠡฦื๊อมࠡษ็้ํอโฺࠢส่ฯ๐ࠠๅษࠣฮุะื๋฻ࠣำำ๎ไ่ษ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ᎚")
	bFnD6Nh75IQcKrTke3gux4PvwRGUfS(PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠧࡳ࡫ࡪ࡬ࡹ࠭᎛"),jSu5Cg2Ub1OAkZVs8Yoz(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ᎜"),mR4VLhryYT2koGU6iBX,k5dztomYyN3H(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬ᎝"))
	return
def w2hmZWy0ICp8():
	ZIOHgA3z0TBR(gItVahxL0w(u"ࠪࠫ᎞"),LgpdP3UjFRnlX(u"ࠫࠬ᎟"),vvHpKfcqRnrFzjG(u"ࠬัไศอࠣ฻ึ่ࠠๅๆอ์ฬ฻ไࠡ็฼ࠤฬ๊ๅษำ่ะࠬᎠ"),nr5mZG89ICi6cgt4MfLJa0(u"࠭ราี็ࠤึูวๅหࠣวํࠦๅีๅ็อ๋ࠥๆࠡไสส๊ฯࠠฯั่หฯࠦ็ัษࠣห้ฮั็ษ่ะࡡࡴ࡜࡯ล๋ࠤออำหะาห๊ࠦวๅใํือ๎ใࠡลา๊ฬํ࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠ࡬ࡹࡺࡰ࠻࠱࠲ࡪࡦࡩࡥࡣࡱࡲ࡯࠳ࡩ࡯࡮࠱ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳ࠳࠲࠴࠼ࡠ࠵ࡃࡐࡎࡒࡖࡢࡢ࡮࡝ࡰฦ์ࠥฮวาีส่ࠥอ๊ๆ์็ࠤฬ๊้ࠡลา๊ฬํࠠࠡ࡞ࡱࠤࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷ࠷࠶࠱࠹ࡂࡪࡱࡦ࡯࡬࠯ࡥࡲࡱࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭Ꭱ"))
	return
def WVDogpG6fZQu9cOBJ5T1UYn():
	O6Ei5cYHAQqXjwFBmLo()
	tLwvQlnjGpWsRVCN1 = mmwySO1P4jnKz5(fY5wTlhtnOc0Er6sdy4k87b(u"ࠧࡤࡧࡱࡸࡪࡸࠧᎢ"),jx7s8T0BFgODXLMzIYedf(u"ࠨࠩᎣ"),v5EA6TqHX3s4jzBMk(u"ࠩࠪᎤ"),NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"๋้ࠪࠦสา์าࠤู๊อࠡฮ่๎฾ࠦวๅๅสุࠥลࠧᎥ"),FGDJwkEbTB5SoXujs3f(u"ࠫฬ๊ใศึࠣ๎ุืูࠡ฻่่ࠥอไษำ้ห๊า้ࠠ็ึั์ฺ๊ࠦ์าࠤุำศࠡษ็ูๆำวห่๊ࠢࠥอไฦ่อี๋ะฺ่ࠠาࠤฬ๊อศฮฬࠤส๊๊่ษࠣ์ฬ๊ๅิฯࠣ๎ฯ๋ࠠหๆๅหห๐วࠡ฻้ำࠥอๆห้สลࠥ฿ๅาࠢสฺ่็อศฬࠣ์ฬ๊ๅิฯ่ࠣฬ๊ࠦืำࠣ์๊๋ใ็ࠢํั้ࠦศฺุࠣห้๋ิศๅ็ࠫᎦ"))
	if tLwvQlnjGpWsRVCN1==qbPw1d3KimF(u"࠶ᘤ"):
		a69aolrYsnGEukv5Li(QynMHGWA0blfqTUdxRh5Jzi2t(u"ࡔࡳࡷࡨᙬ"))
		ZIOHgA3z0TBR(BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠬ࠭Ꭷ"),hhlbF1Sns5TrEN8QPCYmL4(u"࠭ࠧᎨ"),v5EA6TqHX3s4jzBMk(u"ࠧห็ุ้ࠣำࠠไษืࠤฬ๊ศา่ส้ัࠦศศๆๆห๊๊ࠧᎩ"),LgpdP3UjFRnlX(u"ࠨวำห้ࠥว็ฬࠣ฽๋ีใࠡ็ื็้ฯࠠโ์ࠣหาีࠠศๆ่์ฬู่ࠡใฯีอࠦวๅ็๋ๆ฾ࠦวๅฤ้ࠤ࠳࠴࠮๊ࠡฦิฬࠦวๅ็ื็้ฯࠠๆีอ้ึฯࠠโวำ๊ࠥอัิๆࠣห้๋ิไๆฬࠤส๊้ࠡษ็้อืๅอࠩᎪ"))
	return tLwvQlnjGpWsRVCN1
def tqY8WmB1FcPoUywflAhuMeRD3QHzjb(showDialogs=EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࡕࡴࡸࡩ᙭")):
	if not showDialogs: showDialogs = l0WAe1f7Bpi5ZXk(u"ࡖࡵࡹࡪ᙮")
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(SToQEHqGtMnAlFbCz4wxBDuOsmW7,BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠩࡊࡉ࡙࠭Ꭻ"),nr5mZG89ICi6cgt4MfLJa0(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪࡾࡡ࡮ࡲ࡯ࡩ࠳ࡩ࡯࡮ࠩᎬ"),b05yftsZ6NYgIKP(u"ࠫࠬᎭ"),FGDJwkEbTB5SoXujs3f(u"ࠬ࠭Ꭾ"),YB5xyI7MaRslVpv(u"ࡉࡥࡱࡹࡥᙯ"),l0WAe1f7Bpi5ZXk(u"࠭ࠧᎯ"),C2dgEDAKQGsvh(u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࡋࡘ࡙ࡖࡓࡠࡖࡈࡗ࡙࠳࠱ࡴࡶࠪᎰ"))
	if not xHb86g9WZqPwRfVjXD2JalzSIp.succeeded:
		x7QtSyu0hs = C2jP0iLNGKnHu9xp(u"ࡊࡦࡲࡳࡦᙰ")
		HHQYtifTDV = E4L13O2bxwRDSX()
		Lmj1pfQk63XdoeH(C2jP0iLNGKnHu9xp(u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭Ꮁ"),Dwl0N6FKuVU8nB1mbisIrCzdO(baNWS6nfqTC5iX4Kl)+v5EA6TqHX3s4jzBMk(u"ࠩࠣࠤࠥࡎࡔࡕࡒࡖࠤࡋࡧࡩ࡭ࡧࡧࠤࠥࠦࡌࡢࡤࡨࡰ࠿ࡡࠧᎲ")+HHQYtifTDV+RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠪࡡࠬᎳ"))
		if showDialogs: ZIOHgA3z0TBR(UnWjVbo503mEMv9KF(u"ࠫࠬᎴ"),l0WAe1f7Bpi5ZXk(u"ࠬ࠭Ꮅ"),UxS67uoGThbMwnfNRzy4gajLd23JH(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᎶ"),jx7s8T0BFgODXLMzIYedf(u"ࠧโฯุࠤฬ๊วหืส่ࠥอไๆึไีࠥ࠴࠮࠯ุ่่๊ࠢษࠡ࠰࠱࠲ࠥอไศฬุห้ࠦวๅ็ืๅึࠦࠨศๆิฬ฼ࠦวๅ็ืๅึ࠯ࠠๅษࠣ๎฾๋ไࠡ฻้ำู่ࠦๅ๋ࠣ็ํี๊ࠡ࠰࠱࠲ࠥ๎ู็ัๆࠤ่๎ฯ๋ࠢ฽๎ึࠦโศัิࠤ฾๊้ࠡษึฮำีวๆࠢส่๊๎วใ฻ࠣห้๋ิโำฬࠫᎷ"))
	else:
		x7QtSyu0hs = QynMHGWA0blfqTUdxRh5Jzi2t(u"࡙ࡸࡵࡦᙱ")
		if showDialogs: ZIOHgA3z0TBR(V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠨࠩᎸ"),BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠩࠪᎹ"),jSu5Cg2Ub1OAkZVs8Yoz(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭Ꮊ"),BoWHNb9daQVCF16A(u"ࠫั๐ฯࠡฮาหࠥ࠴࠮࠯ࠢส่ฬะีศๆࠣห้๋ิโำࠣࠬฬ๊ัษูࠣห้๋ิโำࠬࠤ๏฿ๅๅࠢ฼๊ิ้้ࠠษ็ฬึ์วๆฮࠣๆฬีัࠡ฻็ํࠥอำหะาห๊ࠦวๅ็๋ห็฿ࠠศๆุ่ๆืษࠨᎻ"))
	if not x7QtSyu0hs and showDialogs: hOZ4eyGTKUtCEj7RmHkJp()
	return x7QtSyu0hs
def hOZ4eyGTKUtCEj7RmHkJp():
	ZIOHgA3z0TBR(k5dztomYyN3H(u"ࠬ࠭Ꮌ"),gItVahxL0w(u"࠭ࠧᎽ"),hhlbF1Sns5TrEN8QPCYmL4(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᎾ"),b05yftsZ6NYgIKP(u"ࠨส฼ฺࠥอไๆ๊สๆ฾ࠦสฮฬสะࠥืศุุ่ࠢๆื้ࠠไาࠤ๏้่็ࠢฯ๋ฬุใࠡ฼ํี่ࠥวะำࠣ฽้๏ࠠศๆิฬ฼ࠦวๅ็ืๅึࠦร้๊๊ࠢฬ้ࠠๆึๆ่ฮࠦแ๋ࠢื๋ฬีษࠡษ็ฮู็๊าࠢส่ำอีสࠢห็ํี๊ࠡ฻้ำู่ࠦๅ็สࠤฬ์็ࠡฬ่ࠤๆำีࠡษ็ฬึ์วๆฮࠣ฽้๏ࠠไ๊า๎ࠥอไฦืาหึอสࠡ࡞ࡱࠤ࠶࠽࠮࠷ࠢࠣࠪࠥࠦ࠱࠹࠰࡞࠴࠲࠿࡝ࠡࠢࠩࠤࠥ࠷࠹࠯࡝࠳࠱࠸ࡣࠧᎿ"))
	r8C1gwklLD0AK()
	return
def EEbGBNzAQydpnq(Gfsr6KpyVRovQmB8xcXUJ=fY5wTlhtnOc0Er6sdy4k87b(u"ࠩࠪᏀ")):
	SLujV8UBJvsF9fwgqQ7y = EAc8h2sINroQYvR3WH06Ji7MVpn(u"࡚ࡲࡶࡧᙲ")
	if EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠪࡣࡕࡘࡏࡃࡎࡈࡑࡤ࠭Ꮑ") not in Gfsr6KpyVRovQmB8xcXUJ:
		SLujV8UBJvsF9fwgqQ7y = C2dgEDAKQGsvh(u"ࡆࡢ࡮ࡶࡩᙳ")
		vwnZ6hF0xpbt47o1f2VUily = Uu0ZdNAP1BWc28lR(C2jP0iLNGKnHu9xp(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫᏂ"),WMkAjB1RgN7q(u"ࠬิั้ฮࠪᏃ"),NVS30xAdRFMIw1n9CislkE2(u"࠭ลาีส่๋ࠥิไๆฬࠫᏄ"),v5EA6TqHX3s4jzBMk(u"ࠧฦำึห้ࠦัิษ็อࠬᏅ"),LgpdP3UjFRnlX(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᏆ"),BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"๊่ࠩࠥะั๋ัࠣว๋ࠦสาี็ࠤึูวๅหࠣษ้๏ࠠศๆ่ฬึ๋ฬࠡ࠰࠱ࠤศ๋ࠠหำํำࠥษๆࠡฬิื้ࠦๅีๅ็อ๋่ࠥอ๊าอࠥ็๊ࠡษ็ฬึ์วๆฮࠣรࠬᏇ"))
		if vwnZ6hF0xpbt47o1f2VUily in [-RqldvxFuM5GEQ2HAz93o7afBb0(u"࠷ᘥ"),FGDJwkEbTB5SoXujs3f(u"࠰ᘦ")]: return
		elif vwnZ6hF0xpbt47o1f2VUily==T6wRistc1SCo4hqObgumK(u"࠲ᘧ"):
			SLujV8UBJvsF9fwgqQ7y = k5dztomYyN3H(u"ࡕࡴࡸࡩᙴ")
			Gfsr6KpyVRovQmB8xcXUJ = NVS30xAdRFMIw1n9CislkE2(u"ࠪࡣࡕࡘࡏࡃࡎࡈࡑࡤ࠭Ꮘ")
	if SLujV8UBJvsF9fwgqQ7y:
		if NVS30xAdRFMIw1n9CislkE2(u"ࠫࡤࡖࡒࡐࡄࡏࡉࡒࡥࡏࡍࡆࡢࠫᏉ") not in Gfsr6KpyVRovQmB8xcXUJ:
			tLwvQlnjGpWsRVCN1 = mmwySO1P4jnKz5(RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬᏊ"),gItVahxL0w(u"࠭ࠧᏋ"),gItVahxL0w(u"ࠧࠨᏌ"),C2dgEDAKQGsvh(u"ࠨู๊฽ࠥอไๆึๆ่ฮࠦแ๋ࠢสุ่าไࠨᏍ"),jx7s8T0BFgODXLMzIYedf(u"ࠩๅฬ้ࠦลาีส่ࠥอไิฮ็ࠤ฾๊๊ไࠢฦ๊ࠥะใาำࠣࠤ๋็ำࠡษ็ๅ฾๊ࠠศๆำ๎ࠥษูุษๆࠤฬ๊ๅีๅ็อࠥ࠴ࠠๅๅํࠤ๏ะๅࠡฬึะ๏๊่ࠠา๊ࠤฬ๊ๅีๅ็อࠥ็๊ࠡีฯ่ࠥอไฤะฺหฦ่ࠦศๆสืฯิฯศ็ࠣ࠲ࠥ๎ศะ๊้ࠤ์ึวࠡษ็ฮุา๊ๅࠢึ์ๆࠦสาี็ࠤ๊๊แࠡๆสࠤๆอฦะห้๋ࠣํࠠๅว้๋๊ࠥวࠡ์ะฮํ๐ฺࠠๆ์ࠤฬ๊ๅีๅ็อࠥอไห์ࠣฮึ๐ฯࠡษ้ฮࠥอไฦส็ห฿ูࠦ็้สࠤ࠳ࠦ็ๅࠢๅ้ฯࠦศหๅิหึࠦวๅ็ื็้ฯࠠภࠩᏎ"))
			if tLwvQlnjGpWsRVCN1!=C2jP0iLNGKnHu9xp(u"࠳ᘨ"):
				ZIOHgA3z0TBR(YB5xyI7MaRslVpv(u"ࠪࠫᏏ"),EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠫࠬᏐ"),RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠬะๅࠡว็฾ฬวࠠศๆศีุอไࠨᏑ"),sRth5giAQzWlEVm7JOX(u"࠭ไๅลึๅࠥฮฯ้่ࠣฮุา๊ๅࠢสฺ่๊ใๅหࠣๅ๏ࠦำอๆࠣห้ษฮุษฤࠤํอไศีอาิอๅࠡใส๊ࠥอไๆสิ้ัࠦไศࠢํืฯ฽ฺ๊่ࠢ฽ึ็ษࠡษ็ู้้ไส๋่ࠢฬࠦอๅ้สࠤ้อๆࠡษ็้อืๅอࠢ็หࠥ๐ูๅ็ࠣห้เ๊ษࠩᏒ"))
				return
	ZIOHgA3z0TBR(l0WAe1f7Bpi5ZXk(u"ࠧࠨᏓ"),WMkAjB1RgN7q(u"ࠨࠩᏔ"),rbjsM8cRFiuA1(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬᏕ"),jx7s8T0BFgODXLMzIYedf(u"ࠪๅ๏ࠦวๅึสุฮࠦวๅไสำ๊ฯࠠฮษ๋่ࠥษๆࠡฬๆฮอࠦัิษ็อࠥหไ๊ࠢส่๊ฮัๆฮࠣ์ฬฺัฮࠢไ๎์อࠠศๆุ่่๊ษࠡล๋ࠤฬ๊ๅุ้๋฽ࠥ๎ลัษࠣวึีสࠡฮ๋หอࠦๅ็ࠢส่๊ฮัๆฮࠣๅสึๆࠡลๆฮอูࠦ็๊ส๊ࠥฮั๋ัๆࠤศ๊ลๅๅอีํ์๊ࠡษ็ษ๏๋๊ๅ๋ࠢฮี้ั๊ࠡ็หࠥะๆิ๋ࠣว๋ࠦวๅ็หี๊าࠠๅษࠣ๎฾๊ๅࠡษ็฾๏ฮࠧᏖ"))
	search = ViKAIsLurq83RSENayxWb(header=YB5xyI7MaRslVpv(u"ࠫ࡜ࡸࡩࡵࡧࠣࡥࠥࡳࡥࡴࡵࡤ࡫ࡪ࡫ࠠࠡࠢส็ฯฮࠠาีส่ฮ࠭Ꮧ"),source=baNWS6nfqTC5iX4Kl)
	if not search: return
	mR4VLhryYT2koGU6iBX = search
	if SLujV8UBJvsF9fwgqQ7y: type = C2dgEDAKQGsvh(u"ࠬࡖࡲࡰࡤ࡯ࡩࡲ࠭Ꮨ")
	else: type = EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠭ࡍࡦࡵࡶࡥ࡬࡫ࠧᏙ")
	tUEvo5HAfIjZgcdYxNJ8awu = RR8P1CEUq6m(type,mR4VLhryYT2koGU6iBX,gItVahxL0w(u"ࡖࡵࡹࡪᙵ"),sRth5giAQzWlEVm7JOX(u"ࠧࠨᏚ"),hhlbF1Sns5TrEN8QPCYmL4(u"ࠨࡇࡐࡅࡎࡒ࠭ࡇࡔࡒࡑ࠲࡛ࡓࡆࡔࡖࠫᏛ"),Gfsr6KpyVRovQmB8xcXUJ)
	return
def RjgqLCpNkzswlxAcfH5F6ObMia():
	Gfsr6KpyVRovQmB8xcXUJ = LgpdP3UjFRnlX(u"๊ࠩิฬࠦวๅสิ๊ฬ๋ฬࠡๆสࠤ๏๎ฬะࠢ็๋ࠥษ๊ࠡีํีๆื๋ࠠีอฺ๏็ࠠฤ์้ࠣาะ่๋ษอ࠲ࠥอไษำ้ห๊า๋ࠠีอาิ๋ࠠา๊สฬ฼่ࠦหุ่๎๋ࠦไๆฯอ์๏อสࠡ็ิๅํ฿ษࠡ฻็ํู๊ࠥาใิหฯࠦฮศำฯ๎ฮ࠴ࠠศๆหี๋อๅอࠢ฽๎ึࠦๅิฦ๋่ࠥ฿ๆࠡลํࠤ๊ำส้์สฮࠥะๅࠡฬะ้๏๊็ศࠢ฼่๎ࠦำ๋ำไีฬะ้ࠠ็๋ห็฿ࠠฯษิะ๏ฯࠠࠣ็๋ห็฿ุࠠำไࠤะอไฬࠤ࠱ࠤัฺ๋๊ࠢส่ศูๅศรࠣ์ฬ๊ๅศำๆหฯ่ࠦศๆุ์ึ่ࠦศๆู่๊๎ัศฬ๋ࠣ๏ࠦฮศืฬࠤออีฮษห๋ฬ࠴ࠠศๆหี๋อๅอࠢ็หࠥ๐ๆห้ๆࠤา่่ใࠢส่฼ฮู๊ࠡสฺ่๋ั๊ࠡๅห๋๎ๆࠡษ็ว้็๊สࠢ็่๊๊ใ๋หࠣห้ืโๆ์ฬࠤࡉࡓࡃࡂࠢศิฬࠦใศ่่ࠣิ๐ใࠡึๆ์๎ࠦฮศืฬࠤออไา๊สฬ฼่ࠦศๆอฺฬ๋๊็ࠢส่ำอัอ์ฬࠤๆอไาฮสลࠥอไห๊สู้ࠦๅฺࠢศำฬืษ้ࠡำ๋ࠥอไิ์ิๅึอส๊ࠡส่๊๎วใ฻ࠣห้ิวาฮํอ࠳ࠦ็ัษࠣห้ฮั็ษ่ะࠥํ่ࠡสหืฬ฽ษࠡ็อูๆำࠠๅ็๋ห็฿ࠠศๆ๋๎อ࠭Ꮬ")
	bFnD6Nh75IQcKrTke3gux4PvwRGUfS(NVS30xAdRFMIw1n9CislkE2(u"ࠪࡶ࡮࡭ࡨࡵࠩᏝ"),NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠫา่่ใࠢส่฼ฮู๊ࠡสฺ่๋ั๊ࠡๅห๋๎ๆࠡษ็ว้็๊สࠢ็่๊๊ใ๋หࠣห้ืโๆ์ฬࠫᏞ"),Gfsr6KpyVRovQmB8xcXUJ,T6wRistc1SCo4hqObgumK(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨᏟ"))
	Gfsr6KpyVRovQmB8xcXUJ = NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠭ࡔࡩ࡫ࡶࠤࡵࡸ࡯ࡨࡴࡤࡱࠥࡪ࡯ࡦࡵࠣࡲࡴࡺࠠࡩࡱࡶࡸࠥࡧ࡮ࡺࠢࡦࡳࡳࡺࡥ࡯ࡶࠣࡳࡳࠦࡡ࡯ࡻࠣࡷࡪࡸࡶࡦࡴ࠱ࠤࡎࡺࠠࡰࡰ࡯ࡽࠥࡻࡳࡦࡵࠣࡰ࡮ࡴ࡫ࡴࠢࡷࡳࠥ࡫࡭ࡣࡧࡧࡨࡪࡪࠠࡤࡱࡱࡸࡪࡴࡴࠡࡶ࡫ࡥࡹࠦࡷࡢࡵࠣࡹࡵࡲ࡯ࡢࡦࡨࡨࠥࡺ࡯ࠡࡲࡲࡴࡺࡲࡡࡳࠢࡲࡲࡱ࡯࡮ࡦࠢࡹ࡭ࡩ࡫࡯ࠡࡪࡲࡷࡹ࡯࡮ࡨࠢࡶ࡭ࡹ࡫ࡳ࠯ࠢࡄࡰࡱࠦࡴࡳࡣࡧࡩࡲࡧࡲ࡬ࡵ࠯ࠤࡻ࡯ࡤࡦࡱࡶ࠰ࠥࡺࡲࡢࡦࡨࠤࡳࡧ࡭ࡦࡵ࠯ࠤࡸ࡫ࡲࡷ࡫ࡦࡩࠥࡳࡡࡳ࡭ࡶ࠰ࠥࡩ࡯ࡱࡻࡵ࡭࡬࡮ࡴࡦࡦࠣࡻࡴࡸ࡫࠭ࠢ࡯ࡳ࡬ࡵࡳࠡࡴࡨࡪࡪࡸࡥ࡯ࡥࡨࡨࠥ࡮ࡥࡳࡧ࡬ࡲࠥࡨࡥ࡭ࡱࡱ࡫ࠥࡺ࡯ࠡࡶ࡫ࡩ࡮ࡸࠠࡳࡧࡶࡴࡪࡩࡴࡪࡸࡨࠤࡴࡽ࡮ࡦࡴࡶࠤ࠴ࠦࡣࡰ࡯ࡳࡥࡳ࡯ࡥࡴ࠰ࠣࡘ࡭࡫ࠠࡱࡴࡲ࡫ࡷࡧ࡭ࠡ࡫ࡶࠤࡳࡵࡴࠡࡴࡨࡷࡵࡵ࡮ࡴ࡫ࡥࡰࡪࠦࡦࡰࡴࠣࡻ࡭ࡧࡴࠡࡱࡷ࡬ࡪࡸࠠࡱࡧࡲࡴࡱ࡫ࠠࡶࡲ࡯ࡳࡦࡪࠠࡵࡱࠣ࠷ࡷࡪࠠࡱࡣࡵࡸࡾࠦࡳࡪࡶࡨࡷ࠳ࠦࡗࡦࠢࡸࡶ࡬࡫ࠠࡢ࡮࡯ࠤࡨࡵࡰࡺࡴ࡬࡫࡭ࡺࠠࡰࡹࡱࡩࡷࡹࠬࠡࡶࡲࠤࡷ࡫ࡣࡰࡩࡱ࡭ࡿ࡫ࠠࡵࡪࡤࡸࠥࡺࡨࡦࠢ࡯࡭ࡳࡱࡳࠡࡥࡲࡲࡹࡧࡩ࡯ࡧࡧࠤࡼ࡯ࡴࡩ࡫ࡱࠤࡹ࡮ࡩࡴࠢࡳࡶࡴ࡭ࡲࡢ࡯ࠣࡥࡷ࡫ࠠ࡭ࡱࡦࡥࡹ࡫ࡤࠡࡵࡲࡱࡪࡽࡨࡦࡴࡨࠤࡪࡲࡳࡦࠢࡲࡲࠥࡺࡨࡦࠢࡺࡩࡧࠦ࡯ࡳࠢࡹ࡭ࡩ࡫࡯ࠡࡧࡰࡦࡪࡪࡤࡦࡦࠣࡥࡷ࡫ࠠࡧࡴࡲࡱࠥࡵࡴࡩࡧࡵࠤࡻࡧࡲࡪࡱࡸࡷࠥࡹࡩࡵࡧࡶ࠲ࠥࡏࡦࠡࡻࡲࡹࠥ࡮ࡡࡷࡧࠣࡥࡳࡿࠠ࡭ࡧࡪࡥࡱࠦࡩࡴࡵࡸࡩࡸࠦࡰ࡭ࡧࡤࡷࡪࠦࡣࡰࡰࡷࡥࡨࡺࠠࡢࡲࡳࡶࡴࡶࡲࡪࡣࡷࡩࠥࡳࡥࡥ࡫ࡤࠤ࡫࡯࡬ࡦࠢࡲࡻࡳ࡫ࡲࡴࠢ࠲ࠤ࡭ࡵࡳࡵࡧࡵࡷ࠳ࠦࡔࡩ࡫ࡶࠤࡵࡸ࡯ࡨࡴࡤࡱࠥ࡯ࡳࠡࡵ࡬ࡱࡵࡲࡹࠡࡣࠣࡻࡪࡨࠠࡣࡴࡲࡻࡸ࡫ࡲ࠯ࠩᏠ")
	bFnD6Nh75IQcKrTke3gux4PvwRGUfS(vvHpKfcqRnrFzjG(u"ࠧ࡭ࡧࡩࡸࠬᏡ"),jx7s8T0BFgODXLMzIYedf(u"ࠨࡆ࡬࡫࡮ࡺࡡ࡭ࠢࡐ࡭ࡱࡲࡥ࡯ࡰ࡬ࡹࡲࠦࡃࡰࡲࡼࡶ࡮࡭ࡨࡵࠢࡄࡧࡹࠦࠨࡅࡏࡆࡅ࠮࠭Ꮲ"),Gfsr6KpyVRovQmB8xcXUJ,PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬᏣ"))
	return
def oKqF9psyZQPXlAcjMeHGk23fibE(Kczs71doMyLHwN):
	FFryOE3KRpiuDQ = tUXmK5PeEH9SDq.executeJSONRPC(UnWjVbo503mEMv9KF(u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡄࡨࡩࡵ࡮ࡴ࠰ࡖࡩࡹࡇࡤࡥࡱࡱࡉࡳࡧࡢ࡭ࡧࡧࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡤࡨࡩࡵ࡮ࡪࡦࠥ࠾ࠧ࠭Ꮴ")+Kczs71doMyLHwN+rbjsM8cRFiuA1(u"ࠫࠧ࠲ࠢࡦࡰࡤࡦࡱ࡫ࡤࠣ࠼ࡩࡥࡱࡹࡥࡾࡿࠪᏥ"))
	zJwPBdKbhsfqD5vX = PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࡗࡶࡺ࡫ᙶ")
	if zJwPBdKbhsfqD5vX:
		KBxPW9cX8dqtaUDG.sleep(EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠴ᘩ"))
		tUXmK5PeEH9SDq.executebuiltin(V2RbfGOBdcA6l8NTsPWzEyvS7(u"࡛ࠬࡰࡥࡣࡷࡩࡑࡵࡣࡢ࡮ࡄࡨࡩࡵ࡮ࡴࠩᏦ"))
		KBxPW9cX8dqtaUDG.sleep(qbPw1d3KimF(u"࠵ᘪ"))
	return
def AXuG6ptzaRWxHhFcNlk():
	ZIOHgA3z0TBR(C2jP0iLNGKnHu9xp(u"࠭ࠧᏧ"),sRth5giAQzWlEVm7JOX(u"ࠧࠨᏨ"),V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᏩ"),gItVahxL0w(u"ࠩส่อืๆศ็ฯࠤ้อ๋ࠠใะฺูࠥ็ศัฬࠤฬ๊สีใํีࠥ฿ๆะࠢส่ฬะีศๆࠣฬฬ๊ๅ้ษๅ฽ࠥอไๆึไีฮ่ࠦๅ้ำหࠥ็๊ࠡฯส่ࠥ๎ฬ้ัุࠣ์อฯสࠢ฽๎ึࠦีฮ์ะอࠥษ่ࠡ็้ฮ์๐ษࠡษ็ู้ออ๋หࠣวํࠦๅำ์ไอࠥ็ว็๊ࠢิฬࠦไ็ࠢํ์็็ࠠศๆิฬ฼ࠦวๅ็ืๅึ่ࠦๅ่ࠣ๎ํ่แࠡ฻่่ࠥอไษำ้ห๊าࠧᏪ"))
	eDLCX2WOuiT1tcZgKd()
	return
def r8C1gwklLD0AK():
	url = hhlbF1Sns5TrEN8QPCYmL4(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡱ࡮ࡸࡲࡰࡴࡶ࠲ࡰࡵࡤࡪ࠰ࡷࡺ࠴ࡸࡥ࡭ࡧࡤࡷࡪࡹ࠯ࡸ࡫ࡱࡨࡴࡽࡳ࠰ࡹ࡬ࡲ࠻࠺࠯ࠨᏫ")
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,k5dztomYyN3H(u"ࠫࡌࡋࡔࠨᏬ"),url,gItVahxL0w(u"ࠬ࠭Ꮽ"),hhlbF1Sns5TrEN8QPCYmL4(u"࠭ࠧᏮ"),YB5xyI7MaRslVpv(u"ࠧࠨᏯ"),v5EA6TqHX3s4jzBMk(u"ࠨࠩᏰ"),C2dgEDAKQGsvh(u"ࠩࡖࡉࡗ࡜ࡉࡄࡇࡖ࠱ࡘࡎࡏࡘࡡࡏࡅ࡙ࡋࡓࡕࡡࡎࡓࡉࡏ࡟ࡗࡇࡕࡗࡎࡕࡎ࠮࠳ࡶࡸࠬᏱ"))
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	lXOcVNhFsJS6o = My7Dwqvs6bfGNSIgX.findall(hhlbF1Sns5TrEN8QPCYmL4(u"ࠪࡸ࡮ࡺ࡬ࡦ࠿ࠥ࡯ࡴࡪࡩ࠮ࠪ࡟ࡨ࠰ࡢ࠮࡝ࡦ࠮࠱ࡠࡧ࠭ࡻࡃ࠰࡞ࡢ࠱ࠩ࠮ࠩᏲ"),MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	lXOcVNhFsJS6o = lXOcVNhFsJS6o[EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠵ᘫ")].split(fY5wTlhtnOc0Er6sdy4k87b(u"ࠫ࠲࠭Ᏻ"))[EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠵ᘫ")]
	PNOwMtBeHhfqiRXL8KjVad5A = str(YSomBdvcNUMF3b8JDiCfrVW)
	NpwctnZDKokruHBSUxaTLOQG = gItVahxL0w(u"ࠬࡡࡒࡕࡎࡠษฺีวาࠢๆ์ิ๐ࠠศๆฦา๏ืࠠศๆ่ฮํ็ัࠡษ็ฦ๋ࠦ็้ࠢ࠽ࠤࠥࠦࠧᏴ")+WMkAjB1RgN7q(u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩᏵ")+lXOcVNhFsJS6o+jx7s8T0BFgODXLMzIYedf(u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ᏶")
	NpwctnZDKokruHBSUxaTLOQG += NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠨ࡞ࡱࡠࡳ࠭᏷")+jx7s8T0BFgODXLMzIYedf(u"ࠩ࡞ࡖ࡙ࡒ࡝ฦืาหึࠦใ้ัํࠤฬ๊ะ๋ࠢส๊ฯࠦสิฬัำ๊ํ่๊ࠠࠣ࠾ࠥࠦࠠࠨᏸ")+BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭ᏹ")+PNOwMtBeHhfqiRXL8KjVad5A+C2dgEDAKQGsvh(u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᏺ")
	ZIOHgA3z0TBR(rbjsM8cRFiuA1(u"ࠬ࠭ᏻ"),EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠭ࠧᏼ"),sRth5giAQzWlEVm7JOX(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᏽ"),NpwctnZDKokruHBSUxaTLOQG)
	return
def qMQsrkg5v3cASY09():
	ZPXx9tplQ10D2skiFHqb,UUdtxEKOHDTq5YkcWLvg,R9RpBFyY4IaZubcG8fNndJeHQ,NpwctnZDKokruHBSUxaTLOQG,N3lCxorjYLwG6W,d1TsDUPYX8t3Rw4r7,XwxRegCbpS83ryOhtGQf0LTm12sai = UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠨࠩ᏾"),vvHpKfcqRnrFzjG(u"ࠩࠪ᏿"),C2dgEDAKQGsvh(u"ࠪࠫ᐀"),BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠫࠬᐁ"),YB5xyI7MaRslVpv(u"ࠬ࠭ᐂ"),NVS30xAdRFMIw1n9CislkE2(u"࠭ࠧᐃ"),sRth5giAQzWlEVm7JOX(u"ࠧࠨᐄ")
	tWha1P9LVeuNxpQUAB,BV0YXo5ug3lA7frHat6C1q9IvTU4ms,O2iXxq7CMHszh,Pyklfu0vM5JBegQ = {V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠨࡣࠪᐅ"):rbjsM8cRFiuA1(u"ࠩࡤࠫᐆ")},{},[],{}
	url = AK5RqLhji4W1wt9VdrCD3PGeQM[l0WAe1f7Bpi5ZXk(u"ࠪࡔ࡞࡚ࡈࡐࡐࠪᐇ")][BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠷ᘬ")]
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(c1lwnq73vkXsVjEhFpeoZtD,QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠫࡕࡕࡓࡕࠩᐈ"),url,tWha1P9LVeuNxpQUAB,BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠬ࠭ᐉ"),sRth5giAQzWlEVm7JOX(u"࠭ࠧᐊ"),sRth5giAQzWlEVm7JOX(u"ࠧࠨᐋ"),C2dgEDAKQGsvh(u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕ࠰࡙ࡘࡇࡇࡆࡡࡕࡉࡕࡕࡒࡕ࠯࠴ࡷࡹ࠭ᐌ"))
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	MK6ZT2zjC1SbmveNFqor = MK6ZT2zjC1SbmveNFqor.replace(v5EA6TqHX3s4jzBMk(u"ࠩࡘࡲ࡮ࡺࡥࡥࠢࡖࡸࡦࡺࡥࡴࠩᐍ"),RqldvxFuM5GEQ2HAz93o7afBb0(u"࡙ࠪࡘࡇࠧᐎ"))
	MK6ZT2zjC1SbmveNFqor = MK6ZT2zjC1SbmveNFqor.replace(hhlbF1Sns5TrEN8QPCYmL4(u"࡚ࠫࡴࡩࡵࡧࡧࠤࡐ࡯࡮ࡨࡦࡲࡱࠬᐏ"),jSu5Cg2Ub1OAkZVs8Yoz(u"࡛ࠬࡋࠨᐐ"))
	MK6ZT2zjC1SbmveNFqor = MK6ZT2zjC1SbmveNFqor.replace(PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"࠭ࡕ࡯࡫ࡷࡩࡩࠦࡁࡳࡣࡥࠤࡊࡳࡩࡳࡣࡷࡩࡸ࠭ᐑ"),UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠧࡖࡃࡈࠫᐒ"))
	MK6ZT2zjC1SbmveNFqor = MK6ZT2zjC1SbmveNFqor.replace(UnWjVbo503mEMv9KF(u"ࠨࡕࡤࡹࡩ࡯ࠠࡂࡴࡤࡦ࡮ࡧࠧᐓ"),QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠩࡎࡗࡆ࠭ᐔ"))
	MK6ZT2zjC1SbmveNFqor = MK6ZT2zjC1SbmveNFqor.replace(sRth5giAQzWlEVm7JOX(u"ࠪࡒࡴࡸࡴࡩࠢࡐࡥࡨ࡫ࡤࡰࡰ࡬ࡥࠬᐕ"),BoWHNb9daQVCF16A(u"ࠫࡓ࠴ࡍࡢࡥࡨࡨࡴࡴࡩࡢࠩᐖ"))
	MK6ZT2zjC1SbmveNFqor = MK6ZT2zjC1SbmveNFqor.replace(vvHpKfcqRnrFzjG(u"ࠬ࡝ࡥࡴࡶࡨࡶࡳࠦࡓࡢࡪࡤࡶࡦ࠭ᐗ"),vvHpKfcqRnrFzjG(u"࠭ࡗ࠯ࡕࡤ࡬ࡦࡸࡡࠨᐘ"))
	MK6ZT2zjC1SbmveNFqor = MK6ZT2zjC1SbmveNFqor.replace(hhlbF1Sns5TrEN8QPCYmL4(u"ࠧࡠࡡࡢࠫᐙ"),jSu5Cg2Ub1OAkZVs8Yoz(u"ࠨࠢࠣࠫᐚ"))
	try: Z86UEsW4NyMz2KFSnoBwx = dWsa2A0O4o5BYiqGXhyKEbM(nr5mZG89ICi6cgt4MfLJa0(u"ࠩ࡯࡭ࡸࡺࠧᐛ"),MK6ZT2zjC1SbmveNFqor)
	except:
		ZIOHgA3z0TBR(QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠪࠫᐜ"),NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠫࠬᐝ"),C2dgEDAKQGsvh(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᐞ"),fY5wTlhtnOc0Er6sdy4k87b(u"࠭แีๆࠣๅ๏ࠦฬๅส้ࠣาะ่๋ษอࠤฯ่ั๋ำࠣห้อำหะาห๊࠭ᐟ"))
		return
	urUOh1TnDA0I6PwvWFXgEq4zCo,q2jt6kyPspenwRuK9irmzMb,llSk6cnIxR0VrMyENzuboDadFtg = Z86UEsW4NyMz2KFSnoBwx
	Pyklfu0vM5JBegQ = {}
	xtcv7hjdD5I = [nr5mZG89ICi6cgt4MfLJa0(u"ࠧࡄࡃࡓࡘࡈࡎࡁࡊࡆࠪᐠ"),FGDJwkEbTB5SoXujs3f(u"ࠨࡅࡄࡔ࡙ࡉࡈࡂࡖࡒࡏࡊࡔࠧᐡ")]
	ggfX1zWaO4 = [T6wRistc1SCo4hqObgumK(u"ࠩࡄࡐࡑ࠭ᐢ"),nr5mZG89ICi6cgt4MfLJa0(u"ࠪࡔ࡞࡚ࡈࡐࡐࠪᐣ"),NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠫࡎࡔࡓࡕࡃࡏࡐࠬᐤ"),nr5mZG89ICi6cgt4MfLJa0(u"ࠬࡓࡅࡕࡔࡒࡔࡔࡒࡉࡔࠩᐥ"),hhlbF1Sns5TrEN8QPCYmL4(u"࠭ࡒࡆࡒࡒࡗࠬᐦ")]+xtcv7hjdD5I+JZsTvyp54E37Mf6ASIhU+cGLksumPzEjOWMvNe1l2F5C3hB4t
	for bo1dqzR8JIwlThvDcyU4jf,TT56MZe3cD0XOHIkKY7,fNuLcdpJsto9zUC in q2jt6kyPspenwRuK9irmzMb:
		fNuLcdpJsto9zUC = tW06wVMpReHfnj3KgzT2va(fNuLcdpJsto9zUC)
		fNuLcdpJsto9zUC = fNuLcdpJsto9zUC.strip(C2jP0iLNGKnHu9xp(u"ࠧࠡࠩᐧ")).strip(b05yftsZ6NYgIKP(u"ࠨࠢ࠱ࠫᐨ"))
		NpwctnZDKokruHBSUxaTLOQG += nr5mZG89ICi6cgt4MfLJa0(u"ࠩ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧᐩ")+bo1dqzR8JIwlThvDcyU4jf+QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠪ࠾ࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᐪ")+fNuLcdpJsto9zUC+C2jP0iLNGKnHu9xp(u"ࠫࡡࡴࠧᐫ")
		if TT56MZe3cD0XOHIkKY7.isdigit():
			Pyklfu0vM5JBegQ[bo1dqzR8JIwlThvDcyU4jf] = int(TT56MZe3cD0XOHIkKY7)
			if int(TT56MZe3cD0XOHIkKY7)>sRth5giAQzWlEVm7JOX(u"࠱࠱࠲ᘭ"): TT56MZe3cD0XOHIkKY7 = LgpdP3UjFRnlX(u"ࠬ࡮ࡩࡨࡪࡸࡷࡦ࡭ࡥࠨᐬ")
			else: TT56MZe3cD0XOHIkKY7 = C2jP0iLNGKnHu9xp(u"࠭࡬ࡰࡹࡸࡷࡦ࡭ࡥࠨᐭ")
		if bo1dqzR8JIwlThvDcyU4jf not in ggfX1zWaO4:
			if   TT56MZe3cD0XOHIkKY7==k5dztomYyN3H(u"ࠧࡩ࡫ࡪ࡬ࡺࡹࡡࡨࡧࠪᐮ"): ZPXx9tplQ10D2skiFHqb += vvHpKfcqRnrFzjG(u"ࠨࠢࠣࠫᐯ")+bo1dqzR8JIwlThvDcyU4jf
			elif TT56MZe3cD0XOHIkKY7==BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠩ࡯ࡳࡼࡻࡳࡢࡩࡨࠫᐰ"): UUdtxEKOHDTq5YkcWLvg += v5EA6TqHX3s4jzBMk(u"ࠪࠤࠥ࠭ᐱ")+bo1dqzR8JIwlThvDcyU4jf
	mRjIrf2tw9duTMqAlOns0yCeLiX,hWnmF8z5pKCaVJLMf1s0otuiBb9v6,oZJuNrijTnGdqhB = list(zip(*q2jt6kyPspenwRuK9irmzMb))
	for bo1dqzR8JIwlThvDcyU4jf in sorted(f4nPgrNMkXuoFbljyB6RWV):
		if bo1dqzR8JIwlThvDcyU4jf not in mRjIrf2tw9duTMqAlOns0yCeLiX:
			NpwctnZDKokruHBSUxaTLOQG += nr5mZG89ICi6cgt4MfLJa0(u"ࠫࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩᐲ")+bo1dqzR8JIwlThvDcyU4jf+BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠬࡀࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᐳ")+LgpdP3UjFRnlX(u"࠭ไศࠢํ์ัีࠧᐴ")+vvHpKfcqRnrFzjG(u"ࠧ࡝ࡰ࡟ࡲࠬᐵ")
			if bo1dqzR8JIwlThvDcyU4jf not in ggfX1zWaO4: R9RpBFyY4IaZubcG8fNndJeHQ += v5EA6TqHX3s4jzBMk(u"ࠨࠢࠣࠫᐶ")+bo1dqzR8JIwlThvDcyU4jf
	for fNuLcdpJsto9zUC,WWMqcL9yHEm in urUOh1TnDA0I6PwvWFXgEq4zCo:
		fNuLcdpJsto9zUC = tW06wVMpReHfnj3KgzT2va(fNuLcdpJsto9zUC)
		N3lCxorjYLwG6W += fNuLcdpJsto9zUC+v5EA6TqHX3s4jzBMk(u"ࠩ࠽ࠤࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧᐷ")+str(WWMqcL9yHEm)+QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠥࠦࠠࠨᐸ")
	ZPXx9tplQ10D2skiFHqb = ZPXx9tplQ10D2skiFHqb.strip(hhlbF1Sns5TrEN8QPCYmL4(u"ࠫࠥ࠭ᐹ"))
	UUdtxEKOHDTq5YkcWLvg = UUdtxEKOHDTq5YkcWLvg.strip(BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠬࠦࠧᐺ"))
	R9RpBFyY4IaZubcG8fNndJeHQ = R9RpBFyY4IaZubcG8fNndJeHQ.strip(hhlbF1Sns5TrEN8QPCYmL4(u"࠭ࠠࠨᐻ"))
	MWrOIXwZ3F2K0dh419p6PTjkGQJc = ZPXx9tplQ10D2skiFHqb+C2dgEDAKQGsvh(u"ࠧࠡࠢࠪᐼ")+UUdtxEKOHDTq5YkcWLvg
	ZPTH5x7VogQhSmKdqyvejf3WCGblI  = LgpdP3UjFRnlX(u"ࠨ็๋ห็฿ࠠ็ฮะࠤฬ๊ศา่ส้ัࠦศหึ฽๎้ࠦแ๋ัํ์์อสࠡใํࠤ࠸ࠦร๋ษ่ࠤฬ๊ๅศุํอࠬᐽ")+jx7s8T0BFgODXLMzIYedf(u"ࠩ࡟ࡲࠬᐾ")+fY5wTlhtnOc0Er6sdy4k87b(u"ࠪ์์ึวࠡ็฼๊ฬํࠠฦาสࠤ้ี๊ไุ่่๊ࠢษࠡใ๊๎๊๊ࠥิฬ้๋ࠣࠦวๅสิ๊ฬ๋ฬࠨᐿ")+k5dztomYyN3H(u"ࠫࡡࡴࠧᑀ")
	ZPTH5x7VogQhSmKdqyvejf3WCGblI += QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨᑁ")+MWrOIXwZ3F2K0dh419p6PTjkGQJc+nr5mZG89ICi6cgt4MfLJa0(u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝࡝ࡰ࡟ࡲࠬᑂ")
	ZPTH5x7VogQhSmKdqyvejf3WCGblI += jSu5Cg2Ub1OAkZVs8Yoz(u"ࠧๆ๊สๆ฾ࠦไๆࠢํุ฿๊ࠠศๆหี๋อๅอ่๊ࠢ์อࠠโ์า๎ํํวหࠢไ๎ࠥ࠹ࠠฤ์ส้ࠥอไๆษู๎ฮ࠭ᑃ")+UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠨ࡞ࡱࠫᑄ")+rbjsM8cRFiuA1(u"๋๋ࠩีอࠠๆ฻้ห์ࠦวฮฬ่ห้ࠦใษ์ิࠤํา่ะุ่่๊ࠢษࠡใํࠤฬ๊ศา่ส้ั࠭ᑅ")+EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠪࡠࡳ࠭ᑆ")
	ZPTH5x7VogQhSmKdqyvejf3WCGblI += rbjsM8cRFiuA1(u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧᑇ")+R9RpBFyY4IaZubcG8fNndJeHQ+YB5xyI7MaRslVpv(u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᑈ")
	MZNJ0TQ5s3HPq6n2FlmDOLE17ek,h6jM2PLKklu87Z,Tx0XymD1lc9PhL2dZnwEAjiIR,avJwyiGE2HCz6qVcB8ulbNh = C2dgEDAKQGsvh(u"࠱ᘮ"),C2dgEDAKQGsvh(u"࠱ᘮ"),C2dgEDAKQGsvh(u"࠱ᘮ"),C2dgEDAKQGsvh(u"࠱ᘮ")
	all = Pyklfu0vM5JBegQ[nr5mZG89ICi6cgt4MfLJa0(u"࠭ࡁࡍࡎࠪᑉ")]
	if jx7s8T0BFgODXLMzIYedf(u"ࠧࡑ࡛ࡗࡌࡔࡔࠧᑊ") in list(Pyklfu0vM5JBegQ.keys()): MZNJ0TQ5s3HPq6n2FlmDOLE17ek = Pyklfu0vM5JBegQ[jSu5Cg2Ub1OAkZVs8Yoz(u"ࠨࡒ࡜ࡘࡍࡕࡎࠨᑋ")]
	if qbPw1d3KimF(u"ࠩࡌࡒࡘ࡚ࡁࡍࡎࠪᑌ") in list(Pyklfu0vM5JBegQ.keys()): h6jM2PLKklu87Z = Pyklfu0vM5JBegQ[T6wRistc1SCo4hqObgumK(u"ࠪࡍࡓ࡙ࡔࡂࡎࡏࠫᑍ")]
	if rbjsM8cRFiuA1(u"ࠫࡒࡋࡔࡓࡑࡓࡓࡑࡏࡓࠨᑎ") in list(Pyklfu0vM5JBegQ.keys()): Tx0XymD1lc9PhL2dZnwEAjiIR = Pyklfu0vM5JBegQ[V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠬࡓࡅࡕࡔࡒࡔࡔࡒࡉࡔࠩᑏ")]
	if qbPw1d3KimF(u"࠭ࡒࡆࡒࡒࡗࠬᑐ") in list(Pyklfu0vM5JBegQ.keys()): avJwyiGE2HCz6qVcB8ulbNh = Pyklfu0vM5JBegQ[qbPw1d3KimF(u"ࠧࡓࡇࡓࡓࡘ࠭ᑑ")]
	WDYKgaUMpJnA0V = all-MZNJ0TQ5s3HPq6n2FlmDOLE17ek-h6jM2PLKklu87Z-Tx0XymD1lc9PhL2dZnwEAjiIR-avJwyiGE2HCz6qVcB8ulbNh
	wLWTRZQNlpACcvdFU3Vo,mlrse8LdvtyX9GUn = llSk6cnIxR0VrMyENzuboDadFtg[NVS30xAdRFMIw1n9CislkE2(u"࠲ᘯ")]
	wLWTRZQNlpACcvdFU3Vo,b3iAyfYrNwv6IgaMjWs0F9UX = llSk6cnIxR0VrMyENzuboDadFtg[qbPw1d3KimF(u"࠴ᘰ")]
	KQ94IBWYfRxSy = mlrse8LdvtyX9GUn-b3iAyfYrNwv6IgaMjWs0F9UX
	XwxRegCbpS83ryOhtGQf0LTm12sai += jx7s8T0BFgODXLMzIYedf(u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫᑒ")+str(b3iAyfYrNwv6IgaMjWs0F9UX)+l0WAe1f7Bpi5ZXk(u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᑓ")+T6wRistc1SCo4hqObgumK(u"ࠪห้฿ฯะࠢส่า่๊ใ์่้ࠣษฬ่ิฬࠤ࠿ࠦࠧᑔ")
	XwxRegCbpS83ryOhtGQf0LTm12sai += BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠫࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩᑕ")+str(KQ94IBWYfRxSy)+C2jP0iLNGKnHu9xp(u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᑖ")+NVS30xAdRFMIw1n9CislkE2(u"࠭ศศีอาิอๅࠡࡲࡵࡳࡽࡿࠠฤ๊ࠣࡺࡵࡴࠠ࠻ࠢࠪᑗ")
	XwxRegCbpS83ryOhtGQf0LTm12sai += V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠧ࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬᑘ")+str(mlrse8LdvtyX9GUn)+qbPw1d3KimF(u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᑙ")+k5dztomYyN3H(u"ࠩส่฾ีฯࠡษ็็้๐ࠠๅฮ่๎฾ࠦวๅลฯ๋ืฯࠠ࠻ࠢࠪᑚ")
	XwxRegCbpS83ryOhtGQf0LTm12sai += RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠪࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨᑛ")+str(len(llSk6cnIxR0VrMyENzuboDadFtg[BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠶ᘱ"):]))+UnWjVbo503mEMv9KF(u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᑜ")+rbjsM8cRFiuA1(u"ࠬ฿ฯะࠢส่ิ๎ไࠡษ็ฮ๏ࠦแ๋้สࠤศา็ำหࠣ࠾ࠥࡢ࡮࡝ࡰࠪᑝ")
	for KTL7OP3spfChQm9n8UudYMDt,ggfedDsABTMIh in llSk6cnIxR0VrMyENzuboDadFtg[NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠷ᘲ"):]:
		KTL7OP3spfChQm9n8UudYMDt = tW06wVMpReHfnj3KgzT2va(KTL7OP3spfChQm9n8UudYMDt)
		KTL7OP3spfChQm9n8UudYMDt = KTL7OP3spfChQm9n8UudYMDt.strip(jSu5Cg2Ub1OAkZVs8Yoz(u"࠭ࠠࠨᑞ")).strip(V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠧࠡ࠰ࠪᑟ"))
		XwxRegCbpS83ryOhtGQf0LTm12sai += KTL7OP3spfChQm9n8UudYMDt+jSu5Cg2Ub1OAkZVs8Yoz(u"ࠨ࠼ࠣ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭ᑠ")+str(ggfedDsABTMIh)+rbjsM8cRFiuA1(u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠤࠥࠦࠧᑡ")
	d1TsDUPYX8t3Rw4r7 += NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭ᑢ")+str(WDYKgaUMpJnA0V)+QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᑣ")+hhlbF1Sns5TrEN8QPCYmL4(u"ࠬ็๊ะ์๋๋ฬะࠠศึอ฾้ะࠠ࠻ࠢࠪᑤ")
	d1TsDUPYX8t3Rw4r7 += rbjsM8cRFiuA1(u"࠭࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫᑥ")+str(MZNJ0TQ5s3HPq6n2FlmDOLE17ek)+WMkAjB1RgN7q(u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᑦ")+PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠨู็ฬฬะࠠิ์ิๅึࠦศศ์ฮ์๋ࠦ࠺ࠡࠩᑧ")
	d1TsDUPYX8t3Rw4r7 += qbPw1d3KimF(u"ࠩ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧᑨ")+str(avJwyiGE2HCz6qVcB8ulbNh)+UnWjVbo503mEMv9KF(u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬᑩ")+LgpdP3UjFRnlX(u"ࠫ฼๊ศศฬࠣื๏ืแาࠢสู่๊ส้ั฼ࠤ࠿ࠦࠧᑪ")
	d1TsDUPYX8t3Rw4r7 += BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠬࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪᑫ")+str(h6jM2PLKklu87Z)+T6wRistc1SCo4hqObgumK(u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨᑬ")+YB5xyI7MaRslVpv(u"ࠧหอห๎ฯࠦสุสํๆ้่ࠥะ์ࠣ฽๊อฯࠡ࠼ࠣࠫᑭ")
	d1TsDUPYX8t3Rw4r7 += RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠨ࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭ᑮ")+str(Tx0XymD1lc9PhL2dZnwEAjiIR)+BoWHNb9daQVCF16A(u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᑯ")+C2dgEDAKQGsvh(u"ࠪฮะฮ๊หࠢฯ่ิࠦๅหำ๋ฬํ๊ำࠡ฻่หิࠦ࠺ࠡࠩᑰ")
	d1TsDUPYX8t3Rw4r7 += nr5mZG89ICi6cgt4MfLJa0(u"ࠫࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩᑱ")+str(len(urUOh1TnDA0I6PwvWFXgEq4zCo))+NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᑲ")+sRth5giAQzWlEVm7JOX(u"࠭ฯ้ๆุࠣ฿๊สࠡใํำ๏๎็ศฬࠣ࠾ࠥ࠭ᑳ")
	d1TsDUPYX8t3Rw4r7 += v5EA6TqHX3s4jzBMk(u"ࠧ࡝ࡰ࡟ࡲࠬᑴ")+N3lCxorjYLwG6W
	bFnD6Nh75IQcKrTke3gux4PvwRGUfS(jSu5Cg2Ub1OAkZVs8Yoz(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨᑵ"),rbjsM8cRFiuA1(u"ࠩ฼ำิࠦวๅลฯ๋ืฯࠠศๆอ๎ࠥอำหะา้ฯࠦ็ัษࠣห้ฮั็ษ่ะࠥ็๊ࠡ࠵ࠣว๏อๅࠡษ็้ฬ฼๊สࠢไ๎ࠥอไฺษ็้้ࠥไ่ࠩᑶ"),XwxRegCbpS83ryOhtGQf0LTm12sai,qbPw1d3KimF(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭ᑷ"))
	bFnD6Nh75IQcKrTke3gux4PvwRGUfS(UnWjVbo503mEMv9KF(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫᑸ"),QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠬ฿ฯะࠢส่ๆ๐ฯ๋๊๊หฯࠦวๅฬํࠤูเไ่ษ๋ࠣีอࠠศๆหี๋อๅอࠢไ๎ࠥ࠹ࠠฤ์ส้ࠥอไๆษู๎ฮࠦแ๋ࠢส่฾อไๆࠢๆ่์࠭ᑹ"),d1TsDUPYX8t3Rw4r7,b05yftsZ6NYgIKP(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩᑺ"))
	bFnD6Nh75IQcKrTke3gux4PvwRGUfS(YB5xyI7MaRslVpv(u"ࠧࡤࡧࡱࡸࡪࡸࠧᑻ"),BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠨ็๋ห็฿ࠠศึอ฾้ะࠠโ์ࠣ࠷ࠥษ๊ศ็ࠣห้๋วื์ฬࠤๆ๐ࠠศๆ฼ห้๋ࠠไๆ๊ࠫᑼ"),ZPTH5x7VogQhSmKdqyvejf3WCGblI,PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬᑽ"))
	bFnD6Nh75IQcKrTke3gux4PvwRGUfS(NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠪࡰࡪ࡬ࡴࠨᑾ"),LgpdP3UjFRnlX(u"ࠫศ฿ไ๊ࠢส่ิ๎ไࠡษ็ฮ๏ࠦแ๋ࠢ࠶ࠤศ๐วๆࠢส่๊อึ๋หࠣหุะฮะ็อࠤฬ๊ศา่ส้ั࠭ᑿ"),NpwctnZDKokruHBSUxaTLOQG,jSu5Cg2Ub1OAkZVs8Yoz(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࡠ࡮ࡲࡲ࡬࠭ᒀ"))
	return
def zzbyHOoPWkBtKXa6xJdlLvqNA2h():
	mR4VLhryYT2koGU6iBX = k5dztomYyN3H(u"࠭็ัษࠣห้ฮั็ษ่ะࠥ๐ูๆๆࠣหๆ฼ไࠡสสืฯิฯศ็ࠣะ้ีࠠไ๊า๎ࠥ࠮ࡋࡰࡦ࡬ࠤࡘࡱࡩ࡯ࠫࠣห้ึ๊ࠡษึ้์ࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄ࡜࠱ࡆࡓࡑࡕࡒ࡞࡞ࡱࡠࡳࡢ࡮๊่้่ࠡ์ࠠหอห๎ฯํࠠษษึฮำีวๆ่ࠢืฯ๎ฯฺࠢ฼้ฬีࠠࡆࡏࡄࡈࠥࡘࡥࡱࡱࡶ࡭ࡹࡵࡲࡺࠢฦ์ࠥะอๆ์็๋๋ࠥๆ࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡴࡨࡴࡴ࠴ࡵ࡬࠰ࡷࡳࡠ࠵ࡃࡐࡎࡒࡖࡢࡢ࡮࡝ࡰ࡟ࡲࠥํะ่ࠢส่ึูวๅหࠣ์฿๐ั่ษࠣ็ะ๐ัࠡ็๋ะํีษࠡใํࠤ็อฦๆหࠣาิ๋วหࠢส่อืๆศ็ฯࠤํอไๆิํำࠥษ๊ืษ้ࠣํา่ะࠢไ๎่ࠥวว็ฬࠤศา่ษหࠣห้ฮั็ษ่ะࠬᒁ")
	bFnD6Nh75IQcKrTke3gux4PvwRGUfS(v5EA6TqHX3s4jzBMk(u"ࠧࡤࡧࡱࡸࡪࡸࠧᒂ"),l0WAe1f7Bpi5ZXk(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᒃ"),mR4VLhryYT2koGU6iBX,FGDJwkEbTB5SoXujs3f(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬᒄ"))
	return
def U6xNL2AEyOIk():
	mR4VLhryYT2koGU6iBX = EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠪห้ืวษูํ๊ࠥษฯ็ษ๊ࠤๆ๐็ๆษࠣฮ฼ฮ๊ใࠢๆ์ิ๐ฺࠠ็สำࠥ๎็้ࠢ฼ฬฬืษࠡ฻้ࠤฯัศ๋ฬࠣ็ฬ๋ไࠡษ๋ฮํ๋วห์ๆ๎๊ࠥศา่ส้ัࠦใ้ัํࠤํู๋่ࠢสฺฬ็ษࠡ฻่หิࠦไๅใํำ๏๎็ศฬࠣห้฿ัษ์ฬࠤํู๋่ࠢสฺฬ็ษࠡฮ็ำ๋ࠥสา๊ห์ฺู้ࠠ็สำࠥ๎ๅฺ้ࠣห฻อแส่ࠢืฯ๎ฯฺࠢ฼้ฬี้ࠠใํ๋ࠥษ๊ืษࠣะ๊๐ูࠡษ฼ำฬีสࠡๅ๋ำ๏ࠦวๅ็ฺ่ํฮษࠡๆ฼้้ࠦศา่ส้ัูࠦๆษาࠤํ้ไ่ษࠣฮฯ๋ࠠศ๊อ์๊อส๋ๅํหࠥ๎ไศࠢอัฯอฬࠡลํࠤ๋๎ูࠡ็้ࠤฬ๊ฮษำฬࠤๆ๐ࠠไ๊า๎ࠥษ่ࠡษ็าอืษࠡใํࠤฯัศ๋ฬࠣว฻อแศฬࠣ็ํี๊ࠨᒅ")+vvHpKfcqRnrFzjG(u"ࠫࡡࡴࠧᒆ")+vvHpKfcqRnrFzjG(u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨᒇ")+AK5RqLhji4W1wt9VdrCD3PGeQM[BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠭ࡋࡐࡆࡌࡉࡒࡇࡄࡠࡃࡓࡔࠬᒈ")][gItVahxL0w(u"࠰ᘴ")]+jx7s8T0BFgODXLMzIYedf(u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠢࠣࠤࠥࠦࠠฤ๊ࠣࠤࠥࠦࠠࠡ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫᒉ")+AK5RqLhji4W1wt9VdrCD3PGeQM[EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠨࡍࡒࡈࡎࡋࡍࡂࡆࡢࡅࡕࡖࠧᒊ")][UxS67uoGThbMwnfNRzy4gajLd23JH(u"࠷ᘳ")]+hhlbF1Sns5TrEN8QPCYmL4(u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᒋ")
	mR4VLhryYT2koGU6iBX += nr5mZG89ICi6cgt4MfLJa0(u"ࠪࡠࡳࡢ࡮࡝ࡰส่ึอศุࠢฦำ๋อ็้๋ࠡࠤฬ๊ำ้ำึࠤฬ๊ะ๋ࠢํัฯอฬ่่ࠢำ๏ืࠠๆๆไหฯࠦใ้ัํࠤ้ะหษ์อࠤอืๆศ็ฯࠤ฾๋วะࠢหห้฽ั๋ไฬࠤฬ๊สใๆํำ๏ฯࠠศๆๅำ๏๋ษ࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬᒌ")+AK5RqLhji4W1wt9VdrCD3PGeQM[C2jP0iLNGKnHu9xp(u"ࠫࡘࡕࡕࡓࡅࡈࡗࠬᒍ")][l0WAe1f7Bpi5ZXk(u"࠲ᘵ")]+NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᒎ")
	mR4VLhryYT2koGU6iBX += vvHpKfcqRnrFzjG(u"࠭࡜࡯࡞ࡱࡠࡳาๅ๋฻้้ࠣ็วหࠢ฼้ฬีࠠๆ๊ฯ์ิฯࠠโ์ࠣห้๋่ใ฻ࠣวิ์ว่ࠩᒏ")+qbPw1d3KimF(u"ࠧ࡝ࡰࠪᒐ")+NVS30xAdRFMIw1n9CislkE2(u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫᒑ")+AK5RqLhji4W1wt9VdrCD3PGeQM[vvHpKfcqRnrFzjG(u"ࠩࡖࡓ࡚ࡘࡃࡆࡕࠪᒒ")][BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠴ᘶ")]+qbPw1d3KimF(u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬᒓ")
	bFnD6Nh75IQcKrTke3gux4PvwRGUfS(NVS30xAdRFMIw1n9CislkE2(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫᒔ"),k5dztomYyN3H(u"ࠬอไๆ๊สๆ฾ࠦวๅำึ้๏ฯࠠๅสิ๊ฬ๋ฬࠡ฻่หิࠦไๅใํำ๏๎็ศฬࠣห้฿ัษ์ฬࠫᒕ"),mR4VLhryYT2koGU6iBX,sRth5giAQzWlEVm7JOX(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩᒖ"))
	return
def puPlgNxOnLDQobyhvfGr6E0jY7iJHT(WIzguGjr6RBiLk):
	tUXmK5PeEH9SDq.executebuiltin(BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠧࡂࡦࡧࡳࡳ࠴ࡏࡱࡧࡱࡗࡪࡺࡴࡪࡰࡪࡷ࠭࠭ᒗ")+WIzguGjr6RBiLk+PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠨࠫࠪᒘ"), UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࡘࡷࡻࡥᙷ"))
	return
def b2kPsA3vynO7wuSYliqItrZj():
	NZrI2wknju57PlJaDoRziLVm1(sRth5giAQzWlEVm7JOX(u"ࠩࡶࡸࡴࡶࠧᒙ"))
	tUXmK5PeEH9SDq.executebuiltin(RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠥࡅࡨࡺࡩࡷࡣࡷࡩ࡜࡯࡮ࡥࡱࡺࠬࡎࡴࡴࡦࡴࡩࡥࡨ࡫ࡓࡦࡶࡷ࡭ࡳ࡭ࡳࠪࠤᒚ"))
	return
def jghfSmIHsJXL7KDZqOrQYtP6a():
	tUXmK5PeEH9SDq.executebuiltin(BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠫࡆࡪࡤࡰࡰ࠱ࡓࡵ࡫࡮ࡔࡧࡷࡸ࡮ࡴࡧࡴࠪ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡢࡦࡤࡴࡹ࡯ࡶࡦࠫࠪᒛ"), NVS30xAdRFMIw1n9CislkE2(u"࡙ࡸࡵࡦᙸ"))
	return
def ZZbNcGadDXtfl5u(showDialogs):
	if not showDialogs: tLwvQlnjGpWsRVCN1 = UnWjVbo503mEMv9KF(u"࡚ࡲࡶࡧᙹ")
	else: tLwvQlnjGpWsRVCN1 = mmwySO1P4jnKz5(vvHpKfcqRnrFzjG(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬᒜ"),UxS67uoGThbMwnfNRzy4gajLd23JH(u"࠭ࠧᒝ"),UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠧࠨᒞ"),nr5mZG89ICi6cgt4MfLJa0(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᒟ"),gItVahxL0w(u"ࠩหี๋อๅอࠢๆ์ิ๐๋ࠠไ๋้ࠥฮูๆๆํอࠥะอะ์ฮࠤัฺ๋๊ࠢส่ส฼วโษอࠤฯ๊โศศํห้ࠥไࠡ࠴࠷ࠤุอูส๋่่ࠢ์ࠠๆ็ๆ๊ࠥหฬาษฤ๋ฬࠦวๅฤ้ࠤ࠳ࠦ็ๅࠢอี๏ีࠠหฯา๎ะࠦฬๆ์฼ࠤส฼วโษอࠤ่๎ฯ๋ࠢส่ว์ࠠภࠩᒠ"))
	if tLwvQlnjGpWsRVCN1==b05yftsZ6NYgIKP(u"࠴ᘷ"):
		tUXmK5PeEH9SDq.executebuiltin(UxS67uoGThbMwnfNRzy4gajLd23JH(u"࡙ࠪࡵࡪࡡࡵࡧࡄࡨࡩࡵ࡮ࡓࡧࡳࡳࡸ࠭ᒡ"))
		if showDialogs: ZIOHgA3z0TBR(LgpdP3UjFRnlX(u"ࠫࠬᒢ"),qbPw1d3KimF(u"ࠬ࠭ᒣ"),l0WAe1f7Bpi5ZXk(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᒤ"),C2jP0iLNGKnHu9xp(u"ࠧห็ࠣษึูวๅฺ่ࠢอࠦลๅ๋ࠣฬึ์วๆฮࠣ็ํี๊ࠡษ็ิ๏ࠦแ๋ࠢฯ๋ฬุใࠡๆๆ๎ࠥ๐โ้็ࠣฬฯำฯ๋อࠣะ๊๐ูࠡวูหๆอสࠡๅ๋ำ๏ࠦ࠮ࠡส่หࠥ็๊่ษࠣฮาี๊ฬ๊ࠢิฬࠦวๅสิ๊ฬ๋ฬ๊ࠡอัิ๐หࠡ็ึฮํีูࠡ฻่หิࠦ࠮ࠡ์ิะ๎ࠦลฺูสล้่ࠥะ์ࠣ࠹ࠥีโศศๅࠤศ๎ࠠฤๅฮี๊ࠥใ๋ࠢํ๊์๐ฺࠠ็็๎ฮࠦวๅฬะำ๏ัࠧᒥ"))
		tUXmK5PeEH9SDq.executebuiltin(NVS30xAdRFMIw1n9CislkE2(u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬ࠬᒦ"))
	return
def DD2rxjXUJT94w5BLGYNl6hquPbofaA():
	ZIOHgA3z0TBR(l0WAe1f7Bpi5ZXk(u"ࠩࠪᒧ"),BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠪࠫᒨ"),YB5xyI7MaRslVpv(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᒩ"),jSu5Cg2Ub1OAkZVs8Yoz(u"๊ࠬๅิฯ้ࠣาะ่๋ษอࠤ็อฦๆหࠣ࠲ࠥอะ่สࠣษ้๏ࠠศๆๅหห๋ษࠡษ็ฮ๏ࠦสา์าࠤู๊อ่ษࠣ์้อࠠหัั่ࠥหไ๋้สࠤํ๊ใ็ࠢหหุะฮะษ่ࠤࠧอไๆษ๋ืࠧࠦร้ࠢࠥห้ื๊ๆ๊อࠦࠥอึ฻ูࠣ฽้๏ࠠศๆีีࠥา็สࠢส่๏๋๊็ࠢฦ์ࠥอำหะา้ࠥࠨวๅๅํฬํืฯ๋ࠣࠢห฻เืࠡ฻็ํࠥำัโࠢࠥࡇࠧࠦร้ࠢ฼่๎ࠦวื฼ฺࠤ฾๊้ࠡิิࠤࠧอไใษษ้ฮࠨࠠศๆำ๎ࠥ็๊ࠡฮ๊อࠥอไ๋็ํ๊ࠬᒪ"))
	return
def R5RjoSGKpVM3yqwQlT1z():
	ZIOHgA3z0TBR(UxS67uoGThbMwnfNRzy4gajLd23JH(u"࠭ࠧᒫ"),FGDJwkEbTB5SoXujs3f(u"ࠧࠨᒬ"),WMkAjB1RgN7q(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᒭ"),YB5xyI7MaRslVpv(u"ࠩ็่ฯ฿วๆๆ้ࠣ฾ࠦวๅ็ไฺ้ฯࠠ࠯ࠢสิ์ฮࠠฦๆ์ࠤฬ๊ัศสฺࠤฬ๊ะ๋ࠢอี๏ีࠠฦุสๅฯํࠠฤุ๊้ࠣำ็ࠡ็้ࠤ่ࠥวว็ฬࠤฬ๊ๅโุ็อࠥ๎ไไ่่ࠣฬࠦส็ไิࠤ฾๊๊่๋่ࠢฬࠦสี฼็๋ࠥ࠴้ࠠสสืฯิฯศ็ࠣࠦฬ๊ๅศ๊ึࠦࠥษ่ࠡࠤส่ึ๐ๅ้ฬࠥࠤฬ฼ฺุࠢ฼่๎ࠦวๅิิࠤัํษࠡษ็๎๊๐ๆࠡ࠰ࠣ์ศ๋วࠡสสืฯิฯศ็ࠣࠦฬ๊ใ๋ส๋ีิࠨࠠโษู฾฼ูࠦๅ๋ࠣัึ็ࠠࠣࡅࠥࠤศ๎ฺࠠๆ์ࠤืืࠠࠣษ็ๆฬฬๅสࠤࠣห้ึ๊ࠡใํࠤัํษࠡษ็๎๊๐ๆࠡ࠰ࠣ์๋็ำࠡษ็็้อๅ๊ࠡส่฼ื๊ใหࠣ฽๋ีࠠศๆอ฽ฬ๋ไࠡ็฼ࠤ๊ำส้์สฮ่่ࠥศศ่ࠤฬ๊ๅโุ็อࠬᒮ"))
	return
def d4f1LnKCFGXirMJjc3RUN8yITWlx5(showDialogs=fY5wTlhtnOc0Er6sdy4k87b(u"ࡔࡳࡷࡨᙺ")):
	UdJRFBbWi8Dv49PgSksZaKQ2Or3cE = [QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨ࠳ࡵࡴࡩࡧࡵࡷࠬᒯ"),qbPw1d3KimF(u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠴ࡧࡪࡶࡨࡩࠬᒰ"),WMkAjB1RgN7q(u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪ࠮ࡱࡻࡷ࡬ࡴࡴࡡ࡯ࡻࡺ࡬ࡪࡸࡥࠨᒱ"),FGDJwkEbTB5SoXujs3f(u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤ࠯ࡩ࡬ࡸ࡭ࡻࡢࠨᒲ"),fY5wTlhtnOc0Er6sdy4k87b(u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥ࠰ࡪ࡭ࡹ࡫ࡡࠨᒳ"),WMkAjB1RgN7q(u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦ࠱ࡧࡴࡪࡥࡣࡧࡵ࡫ࠬᒴ")]
	ZpQTNwl5Sx1Lkg7r8De = UdJRFBbWi8Dv49PgSksZaKQ2Or3cE+[YB5xyI7MaRslVpv(u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧࠫᒵ"),QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨᒶ"),v5EA6TqHX3s4jzBMk(u"ࠫࡸࡩࡲࡪࡲࡷ࠲ࡲࡵࡤࡶ࡮ࡨ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪᒷ"),sRth5giAQzWlEVm7JOX(u"ࠬࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇࠫᒸ"),YB5xyI7MaRslVpv(u"࠭ࡳ࡬࡫ࡱ࠲ࡵ࡮ࡥ࡯ࡱࡰࡩࡳࡧ࡬ࡆࡏࡄࡈࠬᒹ"),jSu5Cg2Ub1OAkZVs8Yoz(u"ࠧࡴࡥࡵ࡭ࡵࡺ࠮࡮ࡱࡧࡹࡱ࡫࠮ࡳࡧࡶࡳࡱࡼࡥࡶࡴ࡯ࠫᒺ"),UnWjVbo503mEMv9KF(u"ࠨࡵࡦࡶ࡮ࡶࡴ࠯࡯ࡲࡨࡺࡲࡥ࠯ࡻࡷ࠱ࡩࡲࡰࠨᒻ")]
	fsKS5t6mhrx0 = DdTjzlVGwQ9mJo([FGDJwkEbTB5SoXujs3f(u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧࠫᒼ")])
	hbeu7xTVDOMo5mgrjCFB6IcR09 = []
	for Kczs71doMyLHwN in [QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨࠬᒽ")]:
		if Kczs71doMyLHwN not in list(fsKS5t6mhrx0.keys()): continue
		ttRZ9D4Ssngb,NsAFJ59SBuMIdoXYvaUWpLC,IpBtwv095Pa37TGdDon,IkoEQKqr7OytGxvWe6hdRL,dtVSoXkgu4WnE0lcZN7O,aI9E3JeQ8h7MsHAW1OG,BmHVKEQ8zAsIeOMjx2dLlJuUwPZgYG = fsKS5t6mhrx0[Kczs71doMyLHwN]
		if not NsAFJ59SBuMIdoXYvaUWpLC or (NsAFJ59SBuMIdoXYvaUWpLC and ttRZ9D4Ssngb): hbeu7xTVDOMo5mgrjCFB6IcR09.append(Kczs71doMyLHwN)
	TS3cOuVwp6xBYtL = len(hbeu7xTVDOMo5mgrjCFB6IcR09)>BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠴ᘸ")
	W9YiR1FGTdzO3jByXPA70D = LLuOT2NGmXvS4C1WRyod8sQtIhV70a.connect(VOtIzx9Mks5pl)
	W9YiR1FGTdzO3jByXPA70D.text_factory = str
	CCJpwYUsTN1cBIz5PH = W9YiR1FGTdzO3jByXPA70D.cursor()
	YuU7efzivTr0HVg9ky5b8EdB = []
	for Kczs71doMyLHwN in UdJRFBbWi8Dv49PgSksZaKQ2Or3cE:
		CCJpwYUsTN1cBIz5PH.execute(v5EA6TqHX3s4jzBMk(u"ࠫࡘࡋࡌࡆࡅࡗࠤ࠯ࠦࡆࡓࡑࡐࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪࠠࡘࡊࡈࡖࡊࠦࡥ࡯ࡣࡥࡰࡪࡪࠠ࠾ࠢࠥ࠵ࠧࠦࡡ࡯ࡦࠣࡥࡩࡪ࡯࡯ࡋࡇࠤࡂࠦࠢࠨᒾ")+Kczs71doMyLHwN+qbPw1d3KimF(u"ࠬࠨࠠ࠼ࠩᒿ"))
		lKSnCUAjhE = CCJpwYUsTN1cBIz5PH.fetchall()
		if lKSnCUAjhE: YuU7efzivTr0HVg9ky5b8EdB.append(Kczs71doMyLHwN)
	LAYJwtbPGiZSXsKa7Hh3CxFn6 = len(YuU7efzivTr0HVg9ky5b8EdB)>UnWjVbo503mEMv9KF(u"࠵ᘹ")
	for Kczs71doMyLHwN in ZpQTNwl5Sx1Lkg7r8De:
		CCJpwYUsTN1cBIz5PH.execute(T6wRistc1SCo4hqObgumK(u"࠭ࡓࡆࡎࡈࡇ࡙ࠦ࡯ࡳ࡫ࡪ࡭ࡳࠦࡆࡓࡑࡐࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪࠠࡘࡊࡈࡖࡊࠦࡡࡥࡦࡲࡲࡎࡊࠠ࠾ࠢࠥࠫᓀ")+Kczs71doMyLHwN+V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠧࠣࠢ࠾ࠫᓁ"))
		L2LjfpWxzPU6qYaQ = CCJpwYUsTN1cBIz5PH.fetchall()
		if L2LjfpWxzPU6qYaQ and YB5xyI7MaRslVpv(u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦࠪᓂ") not in str(L2LjfpWxzPU6qYaQ): hbeu7xTVDOMo5mgrjCFB6IcR09.append(Kczs71doMyLHwN)
	FTwasf8MjeZCP3Jxpmh = len(hbeu7xTVDOMo5mgrjCFB6IcR09)>sRth5giAQzWlEVm7JOX(u"࠶ᘺ")
	hbeu7xTVDOMo5mgrjCFB6IcR09 = list(set(hbeu7xTVDOMo5mgrjCFB6IcR09))
	W9YiR1FGTdzO3jByXPA70D.close()
	ttRZ9D4Ssngb = UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࡇࡣ࡯ࡷࡪᙻ")
	if LAYJwtbPGiZSXsKa7Hh3CxFn6 or FTwasf8MjeZCP3Jxpmh:
		tLwvQlnjGpWsRVCN1 = mmwySO1P4jnKz5(BoWHNb9daQVCF16A(u"ࠩࡦࡩࡳࡺࡥࡳࠩᓃ"),EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠪࠫᓄ"),qbPw1d3KimF(u"ࠫࠬᓅ"),jSu5Cg2Ub1OAkZVs8Yoz(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᓆ"),UnWjVbo503mEMv9KF(u"࠭วๅสิ๊ฬ๋ฬ๊ࠡฯำ๋ࠥิไๆฬࠤๆ๐ࠠๆีอ์ิ฿ฺࠠ็สำࠥษ่ࠡ็ื็้ฯࠠโ์ࠣห้ะอะ์ฮࠤฬ๊สๅไสส๏ࠦไฦุสๅฬะࠠษำ้ห๊าฺࠠ็สำࠥࡢ࡮࡝ࡰࠣ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢࠦ็ๅࠢอี๏ีࠠฦื็หาࠦ็ั้ࠣห้๋ิไๆฬࠤฬ๊ย็ࠢย࡟࠴ࡉࡏࡍࡑࡕࡡࠬᓇ"))
		if tLwvQlnjGpWsRVCN1==QynMHGWA0blfqTUdxRh5Jzi2t(u"࠱ᘻ"):
			BwLIxd2ZqsXlvnfMcNT = nr5mZG89ICi6cgt4MfLJa0(u"ࡖࡵࡹࡪᙼ")
			if TS3cOuVwp6xBYtL:
				BwLIxd2ZqsXlvnfMcNT = XXxnNcKp7dbeERrhJQf(nr5mZG89ICi6cgt4MfLJa0(u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥࠩᓈ"),BmcLzCFjuIrZP5fwXH18aN6YS(u"ࡉࡥࡱࡹࡥᙽ"),BmcLzCFjuIrZP5fwXH18aN6YS(u"ࡉࡥࡱࡹࡥᙽ"))
			TSR70c51CdZLsBkIhpiEN2bgH6yUl = jx7s8T0BFgODXLMzIYedf(u"ࡘࡷࡻࡥᙾ")
			if LAYJwtbPGiZSXsKa7Hh3CxFn6:
				for Kczs71doMyLHwN in YuU7efzivTr0HVg9ky5b8EdB: oKqF9psyZQPXlAcjMeHGk23fibE(Kczs71doMyLHwN)
				TSR70c51CdZLsBkIhpiEN2bgH6yUl = rbjsM8cRFiuA1(u"࡙ࡸࡵࡦᙿ")
			YNnez40Evg1 = NVS30xAdRFMIw1n9CislkE2(u"࡚ࡲࡶࡧ ")
			if FTwasf8MjeZCP3Jxpmh:
				W9YiR1FGTdzO3jByXPA70D = LLuOT2NGmXvS4C1WRyod8sQtIhV70a.connect(VOtIzx9Mks5pl)
				W9YiR1FGTdzO3jByXPA70D.text_factory = str
				CCJpwYUsTN1cBIz5PH = W9YiR1FGTdzO3jByXPA70D.cursor()
				for Kczs71doMyLHwN in hbeu7xTVDOMo5mgrjCFB6IcR09:
					if BoWHNb9daQVCF16A(u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦ࠱ࠫᓉ") in Kczs71doMyLHwN: L2LjfpWxzPU6qYaQ = Kczs71doMyLHwN
					else: L2LjfpWxzPU6qYaQ = NVS30xAdRFMIw1n9CislkE2(u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧࠫᓊ")
					try: CCJpwYUsTN1cBIz5PH.execute(YB5xyI7MaRslVpv(u"࡙ࠪࡕࡊࡁࡕࡇࠣ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩࠦࡓࡆࡖࠣࡳࡷ࡯ࡧࡪࡰࠣࡁࠥࠨࠧᓋ")+L2LjfpWxzPU6qYaQ+NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠫࠧࠦࡗࡉࡇࡕࡉࠥࡧࡤࡥࡱࡱࡍࡉࠦ࠽ࠡࠤࠪᓌ")+Kczs71doMyLHwN+b05yftsZ6NYgIKP(u"ࠬࠨࠠ࠼ࠩᓍ"))
					except: YNnez40Evg1 = jSu5Cg2Ub1OAkZVs8Yoz(u"ࡆࡢ࡮ࡶࡩᚁ")
				W9YiR1FGTdzO3jByXPA70D.commit()
				W9YiR1FGTdzO3jByXPA70D.close()
			KBxPW9cX8dqtaUDG.sleep(hhlbF1Sns5TrEN8QPCYmL4(u"࠲ᘼ"))
			tUXmK5PeEH9SDq.executebuiltin(BmcLzCFjuIrZP5fwXH18aN6YS(u"࠭ࡕࡱࡦࡤࡸࡪࡒ࡯ࡤࡣ࡯ࡅࡩࡪ࡯࡯ࡵࠪᓎ"))
			KBxPW9cX8dqtaUDG.sleep(nr5mZG89ICi6cgt4MfLJa0(u"࠳ᘽ"))
			if BwLIxd2ZqsXlvnfMcNT or TSR70c51CdZLsBkIhpiEN2bgH6yUl or YNnez40Evg1:
				ttRZ9D4Ssngb = vvHpKfcqRnrFzjG(u"ࡇࡣ࡯ࡷࡪᚂ")
				ZIOHgA3z0TBR(l0WAe1f7Bpi5ZXk(u"ࠧࠨᓏ"),WMkAjB1RgN7q(u"ࠨࠩᓐ"),l0WAe1f7Bpi5ZXk(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬᓑ"),RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠪะ๏ีࠠ࠯࠰ࠣฮ๊ࠦศ็ฮสัࠥะแฺ์็ࠤํหีๅษะࠤฬ๊ๅิฬ๋ำ฾่ࠦศๆอัิ๐หࠡษ็ฮ้่วว์่ࠣัฺ๋๊ࠢศฺฬ็วหࠢหี๋อๅอࠢ฼้ฬีࠧᓒ"))
			else:
				ttRZ9D4Ssngb = PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࡖࡵࡹࡪᚃ")
				ZIOHgA3z0TBR(WMkAjB1RgN7q(u"ࠫࠬᓓ"),UnWjVbo503mEMv9KF(u"ࠬ࠭ᓔ"),sRth5giAQzWlEVm7JOX(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᓕ"),hhlbF1Sns5TrEN8QPCYmL4(u"ࠧๅๆฦืๆࠦ࠮࠯ࠢไุ้ะฺࠠ็็๎ฮࠦลึๆสั๋ࠥำห๊า฽ࠥ฿ๅศัࠣ์ส฻ไศฯࠣห้ะอะ์ฮࠤฬ๊สๅไสส๏ࠦไฦุสๅฬะࠠษำ้ห๊าฺࠠ็สำࠬᓖ"))
	elif showDialogs: ZIOHgA3z0TBR(jSu5Cg2Ub1OAkZVs8Yoz(u"ࠨࠩᓗ"),V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠩࠪᓘ"),BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ᓙ"),b05yftsZ6NYgIKP(u"ࠫั๐ฯࠡฮาหࠥ࠴࠮ࠡษ็ฬึ์วๆฮ่๊๊ࠣࠦอัู้้ࠣไสࠢไ๎๋ࠥำห๊า฽ࠥ฿ๅศัࠣวํࠦแ๋ࠢส่ฯำฯ๋อࠣห้ะไใษษ๎๊ࠥลืษไหฯࠦศา่ส้ัูࠦๆษาࠫᓚ"))
	return ttRZ9D4Ssngb
def uuOfKUhValq():
	FFLXuGhf8iN75MOjgxVvDKtwCH1Pl,knDINayLxqE,mypeAhUsg2B8SZDrqkbEf = qbPw1d3KimF(u"ࡉࡥࡱࡹࡥᚄ"),PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠬ࠭ᓛ"),PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"࠭ࠧᓜ")
	YIsoNiUyRwrOqeEKl9Xv3P7GHT,bbN8JRsixlVkwP5G1a07qeWd9Hgv,qq6tYuGHVpa2fByKFrm = l0WAe1f7Bpi5ZXk(u"ࡊࡦࡲࡳࡦᚅ"),C2jP0iLNGKnHu9xp(u"ࠧࠨᓝ"),V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠨࠩᓞ")
	Oyo3Rj7VFn0 = [NVS30xAdRFMIw1n9CislkE2(u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧᓟ"),v5EA6TqHX3s4jzBMk(u"ࠪࡷࡨࡸࡩࡱࡶ࠱ࡱࡴࡪࡵ࡭ࡧ࠱ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩᓠ"),nr5mZG89ICi6cgt4MfLJa0(u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠭ᓡ"),k5dztomYyN3H(u"ࠬࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇࠫᓢ")]
	fsKS5t6mhrx0 = DdTjzlVGwQ9mJo(Oyo3Rj7VFn0)
	for Kczs71doMyLHwN in Oyo3Rj7VFn0:
		if Kczs71doMyLHwN not in list(fsKS5t6mhrx0.keys()): continue
		ttRZ9D4Ssngb,NsAFJ59SBuMIdoXYvaUWpLC,veU18auIm3r6liqOLEd5wTJDksyz4N,JtWAalqO4MX8i9n,VezMRKIp7PUtlf,UaxvEYyZX2Btu1T7DG,dLZyrJ5WHC6IQMvxbRTEPlDgS = fsKS5t6mhrx0[Kczs71doMyLHwN]
		if Kczs71doMyLHwN==EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫᓣ"):
			YIsoNiUyRwrOqeEKl9Xv3P7GHT = ttRZ9D4Ssngb
			bbN8JRsixlVkwP5G1a07qeWd9Hgv = RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠧࠩࠩᓤ")+NsAFJ59SBuMIdoXYvaUWpLC+C2jP0iLNGKnHu9xp(u"ࠨࠢࠪᓥ")+nnYoO8rQaHmc57IA1MVSi(UaxvEYyZX2Btu1T7DG)+BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠩࠬࠫᓦ")
			qq6tYuGHVpa2fByKFrm = JtWAalqO4MX8i9n
		elif Kczs71doMyLHwN==BoWHNb9daQVCF16A(u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨࠬᓧ"):
			FFLXuGhf8iN75MOjgxVvDKtwCH1Pl = FFLXuGhf8iN75MOjgxVvDKtwCH1Pl or ttRZ9D4Ssngb
			knDINayLxqE += k5dztomYyN3H(u"ࠫࠥࠦࠬࠡࠢࠫࠫᓨ")+NsAFJ59SBuMIdoXYvaUWpLC+qbPw1d3KimF(u"ࠬࠦࠧᓩ")+nnYoO8rQaHmc57IA1MVSi(UaxvEYyZX2Btu1T7DG)+LgpdP3UjFRnlX(u"࠭ࠩࠨᓪ")
			mypeAhUsg2B8SZDrqkbEf += C2jP0iLNGKnHu9xp(u"ࠧࠡࠢ࠯ࠤࠥ࠭ᓫ")+JtWAalqO4MX8i9n
		elif Kczs71doMyLHwN==l0WAe1f7Bpi5ZXk(u"ࠨࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊࠧᓬ"):
			FRc410DE5mnXeCap7WkZI3uN28T = ttRZ9D4Ssngb
			AxXWai7OFC8Hb = k5dztomYyN3H(u"ࠩࠫࠫᓭ")+NsAFJ59SBuMIdoXYvaUWpLC+EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠪࠤࠬᓮ")+nnYoO8rQaHmc57IA1MVSi(UaxvEYyZX2Btu1T7DG)+k5dztomYyN3H(u"ࠫ࠮࠭ᓯ")
			ZTRukBwgotqA5ce16 = JtWAalqO4MX8i9n
	knDINayLxqE = knDINayLxqE.strip(hhlbF1Sns5TrEN8QPCYmL4(u"ࠬࠦࠠ࠭ࠢࠣࠫᓰ"))
	mypeAhUsg2B8SZDrqkbEf = mypeAhUsg2B8SZDrqkbEf.strip(v5EA6TqHX3s4jzBMk(u"࠭ࠠࠡ࠮ࠣࠤࠬᓱ"))
	QponsFKtGr9McgBRIW  = FGDJwkEbTB5SoXujs3f(u"ࠧ࡜ࡔࡗࡐࡢอไฦืาหึࠦวๅลั๎ึࠦไษำ้ห๊าฺࠠ็สำࠥอไๆฬ๋ๅึࠦวๅฤ้ࠤ์๎ࠠ࠻ࠢࠣࠤࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧᓲ")+qq6tYuGHVpa2fByKFrm+b05yftsZ6NYgIKP(u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᓳ")
	QponsFKtGr9McgBRIW += gItVahxL0w(u"ࠩ࡟ࡲࠬᓴ")+YB5xyI7MaRslVpv(u"ࠪ࡟ࡗ࡚ࡌ࡞ษ็ษฺีวาࠢส่ี๐ࠠศ่อࠤฯูสฯั่๋๊ࠥศา่ส้ัูࠦๆษาࠤ์๎ࠠ࠻ࠢࠣࠤࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧᓵ")+bbN8JRsixlVkwP5G1a07qeWd9Hgv+vvHpKfcqRnrFzjG(u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᓶ")
	QponsFKtGr9McgBRIW += C2dgEDAKQGsvh(u"ࠬࡢ࡮࡝ࡰࠪᓷ")+QynMHGWA0blfqTUdxRh5Jzi2t(u"࡛࠭ࡓࡖࡏࡡฬ๊ลึัสีࠥอไฤะํี๊ࠥๅิฬ๋ำ฾ูࠦๆษาࠤฬ๊ๅห๊ไีࠥอไร่๋ࠣํࠦ࠺ࠡࠢࠣ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭ᓸ")+mypeAhUsg2B8SZDrqkbEf+V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᓹ")
	QponsFKtGr9McgBRIW += QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠨ࡞ࡱࠫᓺ")+k5dztomYyN3H(u"ࠩ࡞ࡖ࡙ࡒ࡝ศๆศูิอัࠡษ็ิ๏ࠦว็ฬࠣฮุะฮะ็๊ࠤ้๋ำห๊า฽ࠥ฿ๅศั๋ࠣํࠦ࠺ࠡࠢࠣ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭ᓻ")+knDINayLxqE+qbPw1d3KimF(u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬᓼ")
	QponsFKtGr9McgBRIW += T6wRistc1SCo4hqObgumK(u"ࠫࡡࡴ࡜࡯ࠩᓽ")+BoWHNb9daQVCF16A(u"ࠬࡡࡒࡕࡎࡠห้หีะษิࠤฬ๊รฯ์ิࠤ้าไะ่ࠢฮึ๎ศ้ๆึࠤ฾๋วะࠢส่๊ะ่โำࠣห้ศๆ้๋ࠡࠤ࠿ࠦࠠࠡ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫᓾ")+ZTRukBwgotqA5ce16+C2dgEDAKQGsvh(u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨᓿ")
	QponsFKtGr9McgBRIW += LgpdP3UjFRnlX(u"ࠧ࡝ࡰࠪᔀ")+C2dgEDAKQGsvh(u"ࠨ࡝ࡕࡘࡑࡣวๅวุำฬืࠠศๆำ๎ࠥอๆหࠢอืฯิฯๆ้่ࠣั๊ฯࠡ็อีํฮ่ๅีࠣ฽๊อฯ้๋ࠡࠤ࠿ࠦࠠࠡ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫᔁ")+AxXWai7OFC8Hb+LgpdP3UjFRnlX(u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᔂ")
	ttRZ9D4Ssngb = (YIsoNiUyRwrOqeEKl9Xv3P7GHT or FFLXuGhf8iN75MOjgxVvDKtwCH1Pl)
	if ttRZ9D4Ssngb:
		header = b05yftsZ6NYgIKP(u"ࠪห้ืฬศรࠣฮาี๊ฬࠢศฺฬ็วหࠢๆ์ิ๐ࠠๅฯ็ࠤฬ๊ๅีษๆ่ࠬᔃ")
		ty842nqSiZglc6GoEPdTMAjLvRBOxm = jSu5Cg2Ub1OAkZVs8Yoz(u"ࠫฬ์สࠡสะหัฯࠠๅฬะำ๏ัࠠษำ้ห๊าฺࠠ็สำࠥษ่ࠡฬะำ๏ัࠠๆีอ์ิ฿ฺࠠ็สำࠬᔄ")
	else:
		header = BoWHNb9daQVCF16A(u"ࠬำวๅ์สࠤ้อ๋๊ࠠฯำࠥะอะ์ฮหฯࠦไษำ้ห๊าฺࠠ็สำࠥษ่ࠡ็ึฮํีูࠡ฻่หิ࠭ᔅ")
		ty842nqSiZglc6GoEPdTMAjLvRBOxm = l0WAe1f7Bpi5ZXk(u"࠭วๅำฯหฦࠦลษๆส฾ࠥอไๆสิ้ัูࠦ็ࠢสฺ่๊ใๅหࠣห้ะ๊ࠡฬ๋หัํใࠨᔆ")
	w8WimcjhaYC63GE4ot9g05 = C2dgEDAKQGsvh(u"ࠧๅๅํࠤ๏฿ๅๅࠢ฼๊ิ้ࠠศๆอัิ๐หࠡษ็ฮ้่วว์ࠣ๎ัฮࠠฤ่ࠣ๎่๎ๆࠡๆา๎่ࠦแ๋ࠢๆ์ิ๐࡜࡯็ึฮํีูࠡ฻่หิࠦࡅࡎࡃࡇࠤࡗ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹࠨᔇ")
	Oo4nZJDa3ldX5I0h6ezkL = QponsFKtGr9McgBRIW+UnWjVbo503mEMv9KF(u"ࠨ࡞ࡱࡠࡳ࠭ᔈ")+ty842nqSiZglc6GoEPdTMAjLvRBOxm+EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠩ࡟ࡲࡡࡴࠧᔉ")+w8WimcjhaYC63GE4ot9g05
	bFnD6Nh75IQcKrTke3gux4PvwRGUfS(NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠪࡶ࡮࡭ࡨࡵࠩᔊ"),header,Oo4nZJDa3ldX5I0h6ezkL,sRth5giAQzWlEVm7JOX(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧᔋ"))
	return
def IEsKWSj05CNO(showDialogs,L1jxptdCANHOQRYnG):
	qkSCcaj2fg4VO7dl3G9IhJBs5DLx(RnqtMUa9Nh6peGEsBT,BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࠨᔌ"),UnWjVbo503mEMv9KF(u"࠭ࡁࡍࡎࡢࡅࡉࡊࡏࡏࡕࡢ࡜ࡒࡒࠧᔍ"))
	if showDialogs:
		uuOfKUhValq()
		r8C1gwklLD0AK()
	if L1jxptdCANHOQRYnG:
		d4f1LnKCFGXirMJjc3RUN8yITWlx5(QynMHGWA0blfqTUdxRh5Jzi2t(u"ࡋࡧ࡬ࡴࡧᚆ"))
		x1ikPmoCzTwe = [NVS30xAdRFMIw1n9CislkE2(u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬᔎ"),YB5xyI7MaRslVpv(u"ࠨࡵࡦࡶ࡮ࡶࡴ࠯࡯ࡲࡨࡺࡲࡥ࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧᔏ"),nr5mZG89ICi6cgt4MfLJa0(u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧࠫᔐ"),V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠪࡷࡨࡸࡩࡱࡶ࠱ࡱࡴࡪࡵ࡭ࡧ࠱ࡶࡪࡹ࡯࡭ࡸࡨࡹࡷࡲࠧᔑ"),l0WAe1f7Bpi5ZXk(u"ࠫࡸࡩࡲࡪࡲࡷ࠲ࡲࡵࡤࡶ࡮ࡨ࠲ࡾࡺ࠭ࡥ࡮ࡳࠫᔒ")]
		for PNTCKVljpZqLFa7rYvSe in x1ikPmoCzTwe:
			tUEvo5HAfIjZgcdYxNJ8awu,n4XAGEzDHOsSKZv,NsAFJ59SBuMIdoXYvaUWpLC = XXxnNcKp7dbeERrhJQf(PNTCKVljpZqLFa7rYvSe,b05yftsZ6NYgIKP(u"ࡔࡳࡷࡨᚈ"),EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࡌࡡ࡭ࡵࡨᚇ"))
		ZZbNcGadDXtfl5u(showDialogs)
		tUXmK5PeEH9SDq.executebuiltin(jx7s8T0BFgODXLMzIYedf(u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠩᔓ"))
	return
def uo5vRMrFcYsJwL7(q6nDYuvXC4RFlOL=PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈࠬᔔ"),showDialogs=NVS30xAdRFMIw1n9CislkE2(u"ࡕࡴࡸࡩᚉ")):
	ox3AQF7vIVBRjkD9 = tUXmK5PeEH9SDq.executeJSONRPC(PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡓࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡉࡨࡸࡘ࡫ࡴࡵ࡫ࡱ࡫࡛ࡧ࡬ࡶࡧࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡵࡨࡸࡹ࡯࡮ࡨࠤ࠽ࠦࡱࡵ࡯࡬ࡣࡱࡨ࡫࡫ࡥ࡭࠰ࡶ࡯࡮ࡴࠢࡾࡿࠪᔕ"))
	import json as C56R029JKDm
	data = C56R029JKDm.loads(ox3AQF7vIVBRjkD9)
	x5fk6BeUvlyEL23Kab = data[RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠨࡴࡨࡷࡺࡲࡴࠨᔖ")][QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠩࡹࡥࡱࡻࡥࠨᔗ")]
	if V8fmEML1b0PeaRZySnzh3H5J9: x5fk6BeUvlyEL23Kab = x5fk6BeUvlyEL23Kab.encode(BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠪࡹࡹ࡬࠸ࠨᔘ"))
	if showDialogs:
		tLwvQlnjGpWsRVCN1 = mmwySO1P4jnKz5(l0WAe1f7Bpi5ZXk(u"ࠫࠬᔙ"),RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠬ࠭ᔚ"),k5dztomYyN3H(u"࠭ࠧᔛ"),C2jP0iLNGKnHu9xp(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᔜ"),C2dgEDAKQGsvh(u"ࠨ้็ࠤฯื๊ะࠢอ฾๏๐ัࠡฮ็ำࠥ࠭ᔝ")+x5fk6BeUvlyEL23Kab+k5dztomYyN3H(u"ࠩࠣห้ึ๊ࠡ็ึฮำีๅࠡษ็ฦ๋ࠦแ๋ࠢๆ์ิ๐ࠠฦๆ์ࠤฬ๊ลึัสีࠥอไฤะํี๊ࠥฬๅัࠣࠫᔞ")+q6nDYuvXC4RFlOL+PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠪࠤฤࠧࠧᔟ"))
		if tLwvQlnjGpWsRVCN1!=T6wRistc1SCo4hqObgumK(u"࠴ᘾ"): return hhlbF1Sns5TrEN8QPCYmL4(u"ࡈࡤࡰࡸ࡫ᚊ")
	tUEvo5HAfIjZgcdYxNJ8awu,n4XAGEzDHOsSKZv,Ua7jCv9ry804ziZtco = XXxnNcKp7dbeERrhJQf(q6nDYuvXC4RFlOL,RqldvxFuM5GEQ2HAz93o7afBb0(u"ࡉࡥࡱࡹࡥᚋ"),RqldvxFuM5GEQ2HAz93o7afBb0(u"ࡉࡥࡱࡹࡥᚋ"))
	if tUEvo5HAfIjZgcdYxNJ8awu:
		if showDialogs: ZIOHgA3z0TBR(EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠫࠬᔠ"),fY5wTlhtnOc0Er6sdy4k87b(u"ࠬ࠭ᔡ"),NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᔢ"),BoWHNb9daQVCF16A(u"ࠧห็อࠤ฾๋ไ๋หࠣฮะฮ๊หࠢส่ั๊ฯࠡษ็ะิ๐ฯ๊๊ࠡ์ࠥาว่ิ่้ࠣอำหะาห๊ࠦ࠮ࠡี๋ๅࠥ๐สๆࠢส่ว์ࠠห฼ํ๎ึࠦลฺัสำฬะࠠไ๊า๎๊ࠥใ๋ࠢํืฯ฿ๅๅࠢส่ั๊ฯࠡษ็ะิ๐ฯࠡสา่ฬࠦๅ็ࠢส่็ี๊ๆࠩᔣ"))
		FFryOE3KRpiuDQ = tUXmK5PeEH9SDq.executeJSONRPC(NVS30xAdRFMIw1n9CislkE2(u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡔࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡖࡩࡹ࡙ࡥࡵࡶ࡬ࡲ࡬࡜ࡡ࡭ࡷࡨࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡶࡩࡹࡺࡩ࡯ࡩࠥ࠾ࠧࡲ࡯ࡰ࡭ࡤࡲࡩ࡬ࡥࡦ࡮࠱ࡷࡰ࡯࡮ࠣ࠮ࠥࡺࡦࡲࡵࡦࠤ࠽ࠦࠬᔤ")+q6nDYuvXC4RFlOL+UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠩࠥࢁࢂ࠭ᔥ"))
		if BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠪࡓࡐ࠭ᔦ") in FFryOE3KRpiuDQ: tUEvo5HAfIjZgcdYxNJ8awu = BoWHNb9daQVCF16A(u"ࡘࡷࡻࡥᚌ")
		KBxPW9cX8dqtaUDG.sleep(RqldvxFuM5GEQ2HAz93o7afBb0(u"࠵ᘿ"))
		tUXmK5PeEH9SDq.executebuiltin(FGDJwkEbTB5SoXujs3f(u"ࠫࡘ࡫࡮ࡥࡅ࡯࡭ࡨࡱࠨ࠲࠳ࠬࠫᔧ"))
	elif showDialogs: ZIOHgA3z0TBR(BoWHNb9daQVCF16A(u"ࠬ࠭ᔨ"),EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠭ࠧᔩ"),rbjsM8cRFiuA1(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᔪ"),LgpdP3UjFRnlX(u"ࠨๆ็วุ็ࠠโึ็ฮࠥ฿ๅๅ์ฬࠤฯัศ๋ฬࠣ์ฯ็ู๋ๆࠣห้าไะࠢส่๊฽ไ้สࠪᔫ"))
	return tUEvo5HAfIjZgcdYxNJ8awu
def wOF6QJqepnRYNgv5cos13ljDtZzGd(Kczs71doMyLHwN,showDialogs=jx7s8T0BFgODXLMzIYedf(u"࡙ࡸࡵࡦᚍ")):
	if showDialogs==UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠩࠪᔬ"): showDialogs = jSu5Cg2Ub1OAkZVs8Yoz(u"࡚ࡲࡶࡧᚎ")
	nIH1hbpoGlZi3UPMrBf6djDFzsYNR = NbOMplyJ89Vv1zHEt([Kczs71doMyLHwN])
	SS1HxaQnjU,emvc4qSiO80AFRJXMCh1 = nIH1hbpoGlZi3UPMrBf6djDFzsYNR[Kczs71doMyLHwN]
	if emvc4qSiO80AFRJXMCh1:
		tUEvo5HAfIjZgcdYxNJ8awu = NVS30xAdRFMIw1n9CislkE2(u"ࡔࡳࡷࡨᚏ")
		if showDialogs: ZIOHgA3z0TBR(WMkAjB1RgN7q(u"ࠪࠫᔭ"),sRth5giAQzWlEVm7JOX(u"ࠫࠬᔮ"),UnWjVbo503mEMv9KF(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᔯ"),vvHpKfcqRnrFzjG(u"࠭แฮืࠣห้หึศใฬࠤࡡࡴࠠࠨᔰ")+Kczs71doMyLHwN+WMkAjB1RgN7q(u"ࠧࠡ࡞ࡱࠤ์ึ็ࠡล็ษ฻อแสࠢ฼๊ิ้ࠠๆ๊ฯ์ิฯ้ࠠ็ไ฽้ฯ้ࠠฮส๋ืฯࠠๅๆสืฯิฯศ็ࠪᔱ"))
	else:
		tUEvo5HAfIjZgcdYxNJ8awu = WMkAjB1RgN7q(u"ࡇࡣ࡯ࡷࡪᚐ")
		tLwvQlnjGpWsRVCN1 = mmwySO1P4jnKz5(BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨᔲ"),vvHpKfcqRnrFzjG(u"ࠩࠪᔳ"),b05yftsZ6NYgIKP(u"ࠪࠫᔴ"),C2dgEDAKQGsvh(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᔵ"),hhlbF1Sns5TrEN8QPCYmL4(u"ࠬ࠭ᔶ")+Kczs71doMyLHwN+C2dgEDAKQGsvh(u"࠭ࠠ࡝ࡰ๋ࠣีํࠠฤๆศฺฬ็ษࠡ฻้ำฺ่๋ࠦำ้ࠣๆ฿ไสࠢฦ์ࠥเ๊า่ࠢ์ั๎ฯสࠢ࠱ࠤ๏าศࠡฬฮฬ๏ะ็ศ๋ࠢฮๆ฿๊ๅ้สࠤ้้๊ࠡ์฼้้ࠦวๅสิ๊ฬ๋ฬࠡ฻้ำ่ࠦศึ๊ิอࠥ฻อ๋ฯฬࠤ࠳ࠦ็ๅࠢอี๏ีࠠหอห๎ฯ่ࠦหใ฼๎้ࠦ็ั้ࠣห้หึศใฬࠤฬ๊ย็ࠢยࠫᔷ"))
		if tLwvQlnjGpWsRVCN1==jSu5Cg2Ub1OAkZVs8Yoz(u"࠶ᙀ"):
			tUXmK5PeEH9SDq.executebuiltin(hhlbF1Sns5TrEN8QPCYmL4(u"ࠧࡊࡰࡶࡸࡦࡲ࡬ࡂࡦࡧࡳࡳ࠮ࠧᔸ")+Kczs71doMyLHwN+QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠨࠫࠪᔹ"))
			KBxPW9cX8dqtaUDG.sleep(gItVahxL0w(u"࠷ᙁ"))
			tUXmK5PeEH9SDq.executebuiltin(UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠩࡖࡩࡳࡪࡃ࡭࡫ࡦ࡯࠭࠷࠱ࠪࠩᔺ"))
			KBxPW9cX8dqtaUDG.sleep(hhlbF1Sns5TrEN8QPCYmL4(u"࠱ᙂ"))
			while tUXmK5PeEH9SDq.getCondVisibility(gItVahxL0w(u"࡛ࠪ࡮ࡴࡤࡰࡹ࠱ࡍࡸࡇࡣࡵ࡫ࡹࡩ࠭ࡶࡲࡰࡩࡵࡩࡸࡹࡤࡪࡣ࡯ࡳ࡬࠯ࠧᔻ")): KBxPW9cX8dqtaUDG.sleep(gItVahxL0w(u"࠲ᙃ"))
			FFryOE3KRpiuDQ = tUXmK5PeEH9SDq.executeJSONRPC(YB5xyI7MaRslVpv(u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡅࡩࡪ࡯࡯ࡵ࠱ࡗࡪࡺࡁࡥࡦࡲࡲࡊࡴࡡࡣ࡮ࡨࡨࠧ࠲ࠢࡪࡦࠥ࠾࠶࠲ࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡥࡩࡪ࡯࡯࡫ࡧࠦ࠿ࠨࠧᔼ")+Kczs71doMyLHwN+EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠬࠨࠬࠣࡧࡱࡥࡧࡲࡥࡥࠤ࠽ࡸࡷࡻࡥࡾࡿࠪᔽ"))
			if sRth5giAQzWlEVm7JOX(u"࠭ࡏࡌࠩᔾ") in FFryOE3KRpiuDQ:
				tUEvo5HAfIjZgcdYxNJ8awu = sRth5giAQzWlEVm7JOX(u"ࡖࡵࡹࡪᚑ")
				if showDialogs: ZIOHgA3z0TBR(V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠧࠨᔿ"),BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠨࠩᕀ"),QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬᕁ"),nr5mZG89ICi6cgt4MfLJa0(u"ࠪฮ๊ࠦแฮืࠣวํࠦสฬสํฮࠥษ่ࠡฬไ฽๏๊ࠠฤ๊ࠣฮาี๊ฬࠢส่ส฼วโหࠣห้๋ืๅ๊หอࠥ๎็๋ࠢส่ว์ࠠอษ๊ึฮࠦไๅษึฮำีวๆࠩᕂ"))
			elif showDialogs: ZIOHgA3z0TBR(b05yftsZ6NYgIKP(u"ࠫࠬᕃ"),fY5wTlhtnOc0Er6sdy4k87b(u"ࠬ࠭ᕄ"),C2jP0iLNGKnHu9xp(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᕅ"),k5dztomYyN3H(u"ࠧโึ็ࠤๆ๐ࠠหอห๎ฯࠦร้ࠢอๅ฾๐ไࠡล๋ࠤฯำฯ๋อࠣห้หึศใฬࠤฬ๊ๅุๆ๋ฬฮࠦ࠮๊ࠡส่า๊่๊ࠠࠣฮะฮ๊ห้สࠤํะแฺ์็๋ฬࠦๅ็ࠢัหึาࠠศๆหี๋อๅอࠩᕆ"))
	return tUEvo5HAfIjZgcdYxNJ8awu
def Q6SfBITNXDOevEkt54FsPH(Kczs71doMyLHwN,dLZyrJ5WHC6IQMvxbRTEPlDgS,showDialogs):
	tUEvo5HAfIjZgcdYxNJ8awu = v5EA6TqHX3s4jzBMk(u"ࡉࡥࡱࡹࡥᚒ")
	if showDialogs:
		tLwvQlnjGpWsRVCN1 = mmwySO1P4jnKz5(sRth5giAQzWlEVm7JOX(u"ࠨࠩᕇ"),rbjsM8cRFiuA1(u"ࠩࠪᕈ"),jSu5Cg2Ub1OAkZVs8Yoz(u"ࠪࠫᕉ"),YB5xyI7MaRslVpv(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᕊ"),WMkAjB1RgN7q(u"ู่ࠬโࠢํฮ๊ࠦวๅฤ้ࠤั๊ศࠡษ็้้็ࠠศๆฺ่฿๎ืࠡๆ็ษ฻อแสࠢส่๊฽ไ้สฬࠤ้้๊ࠡ์อ้ࠥะหษ์อ๋ࠥ฿ไ๊ࠢๆ์ิ๐ࠠ࠯ࠢส่๊๊แࠡไาࠤ๏้่็ࠢๆฬ๏ื้ࠠไาࠤ๏ำสศฮࠣฬ฾฼ࠠศๆ๋ๆฯࠦ࠮้ࠡ็ࠤฯื๊ะࠢอั๊๐ไࠡษ็้้็ࠠศๆล๊ࠥลࠡࠨᕋ"))
		if tLwvQlnjGpWsRVCN1!=NVS30xAdRFMIw1n9CislkE2(u"࠳ᙄ"): return fY5wTlhtnOc0Er6sdy4k87b(u"ࡊࡦࡲࡳࡦᚓ")
	OH8CRLjt3gWo0XknUF9J = PKwAyEMig2N6eb(dLZyrJ5WHC6IQMvxbRTEPlDgS,{},showDialogs)
	if OH8CRLjt3gWo0XknUF9J:
		yIMvRCaGHxQncLs = XXRtDhYvWb35qnLBxIri7ScNUks0.path.join(plygqUwWMPVORX0LYtejNDr8GI6bnK,Kczs71doMyLHwN)
		SSRbfdTHKi1ngDyzeGt5X(yIMvRCaGHxQncLs,V2RbfGOBdcA6l8NTsPWzEyvS7(u"࡚ࡲࡶࡧᚕ"),jSu5Cg2Ub1OAkZVs8Yoz(u"ࡋࡧ࡬ࡴࡧᚔ"))
		import zipfile as B0JpUEhiYwqLVeHGu56dNPZc7IWa,io as QQqKzcndgMtr2fZ0UW3CiAshLFO
		T5MuWLzEwq0Zgn6m7eD4BFtIS = QQqKzcndgMtr2fZ0UW3CiAshLFO.BytesIO(OH8CRLjt3gWo0XknUF9J)
		try:
			RSqOWlFTBoZ4iKn38jUyhLxPt6 = B0JpUEhiYwqLVeHGu56dNPZc7IWa.ZipFile(T5MuWLzEwq0Zgn6m7eD4BFtIS)
			RSqOWlFTBoZ4iKn38jUyhLxPt6.extractall(plygqUwWMPVORX0LYtejNDr8GI6bnK)
			KBxPW9cX8dqtaUDG.sleep(NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠴ᙅ"))
			tUXmK5PeEH9SDq.executebuiltin(fY5wTlhtnOc0Er6sdy4k87b(u"࠭ࡕࡱࡦࡤࡸࡪࡒ࡯ࡤࡣ࡯ࡅࡩࡪ࡯࡯ࡵࠪᕌ"))
			KBxPW9cX8dqtaUDG.sleep(RqldvxFuM5GEQ2HAz93o7afBb0(u"࠶ᙆ"))
			FFryOE3KRpiuDQ = tUXmK5PeEH9SDq.executeJSONRPC(WMkAjB1RgN7q(u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡁࡥࡦࡲࡲࡸ࠴ࡓࡦࡶࡄࡨࡩࡵ࡮ࡆࡰࡤࡦࡱ࡫ࡤࠣ࠮ࠥ࡭ࡩࠨ࠺࠲࠮ࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡡࡥࡦࡲࡲ࡮ࡪࠢ࠻ࠤࠪᕍ")+Kczs71doMyLHwN+UnWjVbo503mEMv9KF(u"ࠨࠤ࠯ࠦࡪࡴࡡࡣ࡮ࡨࡨࠧࡀࡴࡳࡷࡨࢁࢂ࠭ᕎ"))
			if k5dztomYyN3H(u"ࠩࡒࡏࠬᕏ") in FFryOE3KRpiuDQ: tUEvo5HAfIjZgcdYxNJ8awu = b05yftsZ6NYgIKP(u"ࡔࡳࡷࡨᚖ")
			qkSCcaj2fg4VO7dl3G9IhJBs5DLx(RnqtMUa9Nh6peGEsBT,nr5mZG89ICi6cgt4MfLJa0(u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭ᕐ"),fY5wTlhtnOc0Er6sdy4k87b(u"ࠫࡆࡊࡄࡐࡐࡖࡣࡉࡋࡔࡂࡋࡏࡗࠬᕑ"))
		except: tUEvo5HAfIjZgcdYxNJ8awu = BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࡇࡣ࡯ࡷࡪᚗ")
	if showDialogs:
		if tUEvo5HAfIjZgcdYxNJ8awu: ZIOHgA3z0TBR(qbPw1d3KimF(u"ࠬ࠭ᕒ"),C2jP0iLNGKnHu9xp(u"࠭ࠧᕓ"),gItVahxL0w(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᕔ"),PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠨฬ่ࠤอ์ฬศฯࠣฮะฮ๊หࠢส่ส฼วโหࠣห้๋ืๅ๊หอࠬᕕ"))
		else: ZIOHgA3z0TBR(NVS30xAdRFMIw1n9CislkE2(u"ࠩࠪᕖ"),gItVahxL0w(u"ࠪࠫᕗ"),EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᕘ"),QynMHGWA0blfqTUdxRh5Jzi2t(u"๊ࠬไฤีไࠤๆฺไหࠢ฼้้๐ษࠡฬฮฬ๏ะࠠศๆศฺฬ็ษࠡษ็้฼๊่ษหࠪᕙ"))
	return tUEvo5HAfIjZgcdYxNJ8awu
def XXxnNcKp7dbeERrhJQf(Kczs71doMyLHwN,showDialogs,NNnTyaPVSxJDt2GemCQH8EXd3jYL):
	tLwvQlnjGpWsRVCN1,tUEvo5HAfIjZgcdYxNJ8awu,n4XAGEzDHOsSKZv,NsAFJ59SBuMIdoXYvaUWpLC = qbPw1d3KimF(u"ࡗࡶࡺ࡫ᚙ"),WMkAjB1RgN7q(u"ࡈࡤࡰࡸ࡫ᚘ"),gItVahxL0w(u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭ᕚ"),BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠧࠨᕛ")
	fsKS5t6mhrx0 = DdTjzlVGwQ9mJo([Kczs71doMyLHwN])
	if Kczs71doMyLHwN in list(fsKS5t6mhrx0.keys()):
		ttRZ9D4Ssngb,NsAFJ59SBuMIdoXYvaUWpLC,veU18auIm3r6liqOLEd5wTJDksyz4N,JtWAalqO4MX8i9n,VezMRKIp7PUtlf,UaxvEYyZX2Btu1T7DG,dLZyrJ5WHC6IQMvxbRTEPlDgS = fsKS5t6mhrx0[Kczs71doMyLHwN]
		if UaxvEYyZX2Btu1T7DG==WMkAjB1RgN7q(u"ࠨࡩࡲࡳࡩ࠭ᕜ"):
			tUEvo5HAfIjZgcdYxNJ8awu,n4XAGEzDHOsSKZv = nr5mZG89ICi6cgt4MfLJa0(u"ࡘࡷࡻࡥᚚ"),YB5xyI7MaRslVpv(u"ࠩࡱࡳࡹ࡮ࡩ࡯ࡩࠪᕝ")
			if NNnTyaPVSxJDt2GemCQH8EXd3jYL: ZIOHgA3z0TBR(BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠪࠫᕞ"),UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠫࠬᕟ"),jx7s8T0BFgODXLMzIYedf(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᕠ"),v5EA6TqHX3s4jzBMk(u"࠭ฬ๋ัࠣะิอࠠ࠯࠰ࠣ็ํี๊ࠡ์ึฮำีๅࠡลัีࠥหีะษิࠤ๊ะ่โำࠣๅ๏ࠦๅ้ษๅ฽๋ࠥำห๊า฽ࠥ฿ๅศั่ࠣ์ึ็ࠡษ็ษ฻อแส࡞ࡱࡠࡳ࠭ᕡ")+Kczs71doMyLHwN)
		else:
			if showDialogs:
				if UaxvEYyZX2Btu1T7DG==UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠧࡥ࡫ࡶࡥࡧࡲࡥࡥࠩᕢ"): mR4VLhryYT2koGU6iBX = b05yftsZ6NYgIKP(u"ࠨ็อ์็็ษࠨᕣ")
				elif UaxvEYyZX2Btu1T7DG==NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠩࡲࡰࡩ࠭ᕤ"): mR4VLhryYT2koGU6iBX = BoWHNb9daQVCF16A(u"ࠪๆิ๐ๅสࠩᕥ")
				elif UaxvEYyZX2Btu1T7DG==NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠫࡲ࡯ࡳࡴ࡫ࡱ࡫ࠬᕦ"): mR4VLhryYT2koGU6iBX = C2dgEDAKQGsvh(u"ࠬเ๊า่ࠢฯอะษࠨᕧ")
				tLwvQlnjGpWsRVCN1 = mmwySO1P4jnKz5(T6wRistc1SCo4hqObgumK(u"࠭ࠧᕨ"),FGDJwkEbTB5SoXujs3f(u"ࠧࠨᕩ"),jx7s8T0BFgODXLMzIYedf(u"ࠨࠩᕪ"),gItVahxL0w(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬᕫ"),V2RbfGOBdcA6l8NTsPWzEyvS7(u"๋ࠪีํࠠศๆศฺฬ็ษࠡࠩᕬ")+mR4VLhryYT2koGU6iBX+LgpdP3UjFRnlX(u"ࠫࠥ࠴࠮้ࠡ็ࠤฯื๊ะࠢศู้ออ้ࠡำ๋ࠥอไๆึๆ่ฮࠦฟࠢ࡞ࡱࡠࡳ࠭ᕭ")+Kczs71doMyLHwN)
			if not tLwvQlnjGpWsRVCN1: n4XAGEzDHOsSKZv = BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠬࡩࡡ࡯ࡥࡨࡰࡪࡪࠧᕮ")
			else:
				if UaxvEYyZX2Btu1T7DG==gItVahxL0w(u"࠭ࡤࡪࡵࡤࡦࡱ࡫ࡤࠨᕯ"):
					ft3e2JBKQVXWlFPjaMhkEqGxvDg = tUXmK5PeEH9SDq.executeJSONRPC(QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡁࡥࡦࡲࡲࡸ࠴ࡓࡦࡶࡄࡨࡩࡵ࡮ࡆࡰࡤࡦࡱ࡫ࡤࠣ࠮ࠥ࡭ࡩࠨ࠺࠲࠮ࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡡࡥࡦࡲࡲ࡮ࡪࠢ࠻ࠤࠪᕰ")+Kczs71doMyLHwN+QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠨࠤ࠯ࠦࡪࡴࡡࡣ࡮ࡨࡨࠧࡀࡴࡳࡷࡨࢁࢂ࠭ᕱ"))
					if NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠩࡒࡏࠬᕲ") in ft3e2JBKQVXWlFPjaMhkEqGxvDg:
						tUEvo5HAfIjZgcdYxNJ8awu,n4XAGEzDHOsSKZv = fY5wTlhtnOc0Er6sdy4k87b(u"࡙ࡸࡵࡦ᚛"),hhlbF1Sns5TrEN8QPCYmL4(u"ࠪࡩࡳࡧࡢ࡭ࡧࡧࠫᕳ")
						if showDialogs: ZIOHgA3z0TBR(PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠫࠬᕴ"),hhlbF1Sns5TrEN8QPCYmL4(u"ࠬ࠭ᕵ"),nr5mZG89ICi6cgt4MfLJa0(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᕶ"),vvHpKfcqRnrFzjG(u"ࠧอ์าࠤัีวࠡ࠰࠱ࠤฬ๊ลืษไอ้ࠥว็ฬ้ࠣฯ๎โโหࠣ࠲࠳่ࠦใษ่ࠤฬ๊ศา่ส้ัࠦศหึ฽๎้ํว࡝ࡰ࡟ࡲࠬᕷ")+Kczs71doMyLHwN)
					elif showDialogs: ZIOHgA3z0TBR(rbjsM8cRFiuA1(u"ࠨࠩᕸ"),gItVahxL0w(u"ࠩࠪᕹ"),fY5wTlhtnOc0Er6sdy4k87b(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ᕺ"),RqldvxFuM5GEQ2HAz93o7afBb0(u"้๊ࠫริใࠣ࠲࠳ࠦวๅวูหๆฯࠠๆฬ๋ๆๆฯࠠ࠯࠰ࠣ์้๋๋ࠠีอ฻๏฿ࠠศๆหี๋อๅอࠢอุ฿๐ไ่ษ࡟ࡲࡡࡴࠧᕻ")+Kczs71doMyLHwN)
				elif UaxvEYyZX2Btu1T7DG in [EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠬࡵ࡬ࡥࠩᕼ"),WMkAjB1RgN7q(u"࠭࡭ࡪࡵࡶ࡭ࡳ࡭ࠧᕽ")]:
					tUEvo5HAfIjZgcdYxNJ8awu = Q6SfBITNXDOevEkt54FsPH(Kczs71doMyLHwN,dLZyrJ5WHC6IQMvxbRTEPlDgS,gItVahxL0w(u"ࡌࡡ࡭ࡵࡨ᚜"))
					if tUEvo5HAfIjZgcdYxNJ8awu:
						if UaxvEYyZX2Btu1T7DG==UnWjVbo503mEMv9KF(u"ࠧࡰ࡮ࡧࠫᕾ"): n4XAGEzDHOsSKZv = hhlbF1Sns5TrEN8QPCYmL4(u"ࠨࡷࡳࡨࡦࡺࡥࡥࠩᕿ")
						elif UaxvEYyZX2Btu1T7DG==PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠩࡰ࡭ࡸࡹࡩ࡯ࡩࠪᖀ"): n4XAGEzDHOsSKZv = BoWHNb9daQVCF16A(u"ࠪ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩ࠭ᖁ")
						NsAFJ59SBuMIdoXYvaUWpLC = JtWAalqO4MX8i9n
						if showDialogs:
							if n4XAGEzDHOsSKZv==jSu5Cg2Ub1OAkZVs8Yoz(u"ࠫࡺࡶࡤࡢࡶࡨࡨࠬᖂ"): ZIOHgA3z0TBR(YB5xyI7MaRslVpv(u"ࠬ࠭ᖃ"),b05yftsZ6NYgIKP(u"࠭ࠧᖄ"),PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᖅ"),UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠨฮํำࠥาฯศࠢ࠱࠲ࠥอไฦุสๅฮࠦใศ่อࠤ็ี๊ๆหࠣ࠲࠳่ࠦศๆหี๋อๅอࠢๅห๊ࠦศหฯา๎ะํว࡝ࡰ࡟ࡲࠬᖆ")+Kczs71doMyLHwN)
							elif n4XAGEzDHOsSKZv==BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠩ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨࠬᖇ"): ZIOHgA3z0TBR(YB5xyI7MaRslVpv(u"ࠪࠫᖈ"),UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠫࠬᖉ"),QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᖊ"),LgpdP3UjFRnlX(u"࠭ฬ๋ัࠣะิอࠠ࠯࠰ࠣห้หึศใฬࠤ้๋ࠠหๅ้ࠤ๊๎ฬ้ัฬࠤๆ๐ࠠไ๊า๎ࠥ࠴࠮๊ࠡส่อืๆศ็ฯࠤ็อๅࠡสอฯอ๐ส่ษ࡟ࡲࡡࡴࠧᖋ")+Kczs71doMyLHwN)
					elif showDialogs: ZIOHgA3z0TBR(b05yftsZ6NYgIKP(u"ࠧࠨᖌ"),NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠨࠩᖍ"),WMkAjB1RgN7q(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬᖎ"),V2RbfGOBdcA6l8NTsPWzEyvS7(u"่้ࠪษำโࠢ࠱࠲ࠥอไษำ้ห๊าࠠๅ็ࠣ๎ุะื๋฻ࠣฮาี๊ฬࠢฦ์ࠥะหษ์อࠤ์ึ็ࠡษ็ษ฻อแส࡞ࡱࡠࡳ࠭ᖏ")+Kczs71doMyLHwN)
	elif showDialogs: ZIOHgA3z0TBR(C2dgEDAKQGsvh(u"ࠫࠬᖐ"),nr5mZG89ICi6cgt4MfLJa0(u"ࠬ࠭ᖑ"),jSu5Cg2Ub1OAkZVs8Yoz(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᖒ"),BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠧๅๆฦืๆࠦ࠮࠯๊ࠢิ์ࠦวๅวูหๆฯࠠ฻์ิࠤ๊๎ฬ้ัฬࠤๆ๐ࠠๆ๊สๆ฾ࠦๅิฬ๋ำ฾ูࠦๆษาࠤ࠳࠴้ࠠๆ๊ิฬࠦไศࠢํืฯ฽ฺ๊ࠢส่อืๆศ็ฯࠤศ์๋ࠠไ๋้ࠥฮสฬสํฮࠥํะ่ࠢส่ส฼วโหࠣวํࠦสฮัํฯ์อ࡜࡯࡞ࡱࠫᖓ")+Kczs71doMyLHwN)
	return tUEvo5HAfIjZgcdYxNJ8awu,n4XAGEzDHOsSKZv,NsAFJ59SBuMIdoXYvaUWpLC
# -*- coding: utf-8 -*-
from G6AHskJeqN import *
baNWS6nfqTC5iX4Kl = 'SHOOFPRO'
teUPLFC3B8bArakwHVGsdhoIWDM49f = '_SHP_'
EZxQp1WOldMTvFU = AK5RqLhji4W1wt9VdrCD3PGeQM[baNWS6nfqTC5iX4Kl][0]
eh2tDvRFWpLQI = ['مصارعة','بث مباشر']
def VbgEajY4Bt2COpGDcPqI(mode,url,text):
	if   mode==480: ft3e2JBKQVXWlFPjaMhkEqGxvDg = eN02L7Tf5bQ()
	elif mode==481: ft3e2JBKQVXWlFPjaMhkEqGxvDg = sscM839DP1jWZ4zl6uIx0Kyn(url,text)
	elif mode==482: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HDxCnPKFhITpZmOsA4a0UL6(url)
	elif mode==483: ft3e2JBKQVXWlFPjaMhkEqGxvDg = o4oY13v5dWMcbilEDjKCnXNzHZ0(url,text)
	elif mode==489: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HjZcUIVAXFCqy9TfBWKtgY2(text,url)
	else: ft3e2JBKQVXWlFPjaMhkEqGxvDg = False
	return ft3e2JBKQVXWlFPjaMhkEqGxvDg
def eN02L7Tf5bQ():
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',EZxQp1WOldMTvFU,'','','','','SHOOFPRO-MENU-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	xxE5BSyQkNsj = My7Dwqvs6bfGNSIgX.findall('href="(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	xxE5BSyQkNsj = xxE5BSyQkNsj[0].strip('/')
	xxE5BSyQkNsj = ooq2D9xF8ZLpPBs(xxE5BSyQkNsj,'url')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'بحث في الموقع',xxE5BSyQkNsj,489,'','','_REMEMBERRESULTS_')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'أحدث المواضيع',xxE5BSyQkNsj,481)
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"navigation"(.*?)"myAccount"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	vsptNMP2ZQC = XBuP6Op7y4K[0]
	items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?</span>(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	for BoEFz2WhUyvTgDeiZ,title in items:
		if BoEFz2WhUyvTgDeiZ=='#': continue
		if title in eh2tDvRFWpLQI: continue
		title = PIfAumbGicwg5ye(title)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,481)
	return MK6ZT2zjC1SbmveNFqor
def sscM839DP1jWZ4zl6uIx0Kyn(url,OOkBjVAYL2i8ynmaXlz4MDeGK7Fq):
	items = []
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'','','','','SHOOFPRO-TITLES-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"post(.*?)"footer"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if not XBuP6Op7y4K: return
	vsptNMP2ZQC = XBuP6Op7y4K[0]
	items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)" title="(.*?)".*?image:url\((.*?)\)',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	y7y3d5Fbhv42ONmtwLZ0SerYoQq = []
	tkBQK76YMeUlRI1TomgECfA = ['مشاهدة','فيلم','اغنية','أغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	R7cdaz9YjVoU8HqT = '/'.join(OOkBjVAYL2i8ynmaXlz4MDeGK7Fq.strip('/').split('/')[4:]).split('-')
	for BoEFz2WhUyvTgDeiZ,title,IcWzVO137wFvemn2QTq8yKs9 in items:
		title = PIfAumbGicwg5ye(title)
		ffhN7jAqe3Q4cR0Ukptzl = My7Dwqvs6bfGNSIgX.findall('(.*?) حلقة \d+',title,My7Dwqvs6bfGNSIgX.DOTALL)
		if OOkBjVAYL2i8ynmaXlz4MDeGK7Fq:
			bOBQpgMudItXo = '/'.join(BoEFz2WhUyvTgDeiZ.strip('/').split('/')[4:]).split('-')
			ee34iOxP8FBSWJT = len([PesMFvXRrd1 for PesMFvXRrd1 in R7cdaz9YjVoU8HqT if PesMFvXRrd1 in bOBQpgMudItXo])
			if ee34iOxP8FBSWJT>2 and '/episodes/' in BoEFz2WhUyvTgDeiZ:
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,482,IcWzVO137wFvemn2QTq8yKs9)
		else:
			if not ffhN7jAqe3Q4cR0Ukptzl: ffhN7jAqe3Q4cR0Ukptzl = My7Dwqvs6bfGNSIgX.findall('(.*?) الحلقة \d+',title,My7Dwqvs6bfGNSIgX.DOTALL)
			if set(title.split()) & set(tkBQK76YMeUlRI1TomgECfA) and 'مسلسل' not in title:
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,482,IcWzVO137wFvemn2QTq8yKs9)
			elif ffhN7jAqe3Q4cR0Ukptzl and 'حلقة' in title:
				title = '_MOD_' + ffhN7jAqe3Q4cR0Ukptzl[0]
				if title not in y7y3d5Fbhv42ONmtwLZ0SerYoQq:
					VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,483,IcWzVO137wFvemn2QTq8yKs9,'',url)
					y7y3d5Fbhv42ONmtwLZ0SerYoQq.append(title)
			else: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,483,IcWzVO137wFvemn2QTq8yKs9,'',url)
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall("'pagination'(.*?)</div>",MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall("href='(.*?)'.*?>(.*?)</a>",vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title in items:
			title = PIfAumbGicwg5ye(title)
			title = title.replace('الصفحة ','')
			if title!='': VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'صفحة '+title,BoEFz2WhUyvTgDeiZ,481,'','',OOkBjVAYL2i8ynmaXlz4MDeGK7Fq)
	return
def o4oY13v5dWMcbilEDjKCnXNzHZ0(url,bJEs4IVAPdyUrhwCLv9k2YoOl8nt1):
	headers = {'X-Requested-With':'XMLHttpRequest'}
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'',headers,'','','SHOOFPRO-EPISODES-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	xxE5BSyQkNsj = ooq2D9xF8ZLpPBs(url,'url')
	IcWzVO137wFvemn2QTq8yKs9 = My7Dwqvs6bfGNSIgX.findall('"img-responsive" src="(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if IcWzVO137wFvemn2QTq8yKs9: IcWzVO137wFvemn2QTq8yKs9 = IcWzVO137wFvemn2QTq8yKs9[0]
	else: IcWzVO137wFvemn2QTq8yKs9 = tUXmK5PeEH9SDq.getInfoLabel('ListItem.Thumb')
	SfH8BWiT6obzZc90FPushmNl7 = True
	KRI8WExzA4p = My7Dwqvs6bfGNSIgX.findall('"listSeasons(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if KRI8WExzA4p and '/ajax/seasons' not in url:
		vsptNMP2ZQC = KRI8WExzA4p[0]
		count = vsptNMP2ZQC.count('data-slug=')
		if count==0: count = vsptNMP2ZQC.count('data-season=')
		if count>1:
			SfH8BWiT6obzZc90FPushmNl7 = False
			if 'data-slug="' in vsptNMP2ZQC:
				items = My7Dwqvs6bfGNSIgX.findall('data-slug="(.*?)">(.*?)</li>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
				for id,title in items:
					BoEFz2WhUyvTgDeiZ = xxE5BSyQkNsj+'/wp-content/themes/vo2021/temp/ajax/seasons2.php?slug='+id
					VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,483,IcWzVO137wFvemn2QTq8yKs9)
			else:
				items = My7Dwqvs6bfGNSIgX.findall('data-season="(.*?)">(.*?)</li>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
				for id,title in items:
					BoEFz2WhUyvTgDeiZ = xxE5BSyQkNsj+'/wp-content/themes/vo2021/temp/ajax/seasons.php?seriesID='+id
					VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,483,IcWzVO137wFvemn2QTq8yKs9)
	if SfH8BWiT6obzZc90FPushmNl7:
		vsptNMP2ZQC = ''
		if '/ajax/seasons' in url: vsptNMP2ZQC = MK6ZT2zjC1SbmveNFqor
		else:
			kdYXhMN8Hpbt = My7Dwqvs6bfGNSIgX.findall('"eplist"(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
			if kdYXhMN8Hpbt: vsptNMP2ZQC = kdYXhMN8Hpbt[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)" title="(.*?)"',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		if items:
			for BoEFz2WhUyvTgDeiZ,title in items:
				title = title.strip(' ')
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,482,IcWzVO137wFvemn2QTq8yKs9)
	if not xx4viQhaOu6r0: sscM839DP1jWZ4zl6uIx0Kyn(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,url)
	return
def HDxCnPKFhITpZmOsA4a0UL6(url):
	bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = url.strip('/')+'/?do=watch'
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,'','','','','SHOOFPRO-PLAY-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	QQ2cE1FjUyxPonbDhaTkV6B3i = []
	xxE5BSyQkNsj = ooq2D9xF8ZLpPBs(url,'url')
	GuQo8hCDmdBYNZRt5926LFMVwlJnA4 = My7Dwqvs6bfGNSIgX.findall('vo_postID = "(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if not GuQo8hCDmdBYNZRt5926LFMVwlJnA4: GuQo8hCDmdBYNZRt5926LFMVwlJnA4 = My7Dwqvs6bfGNSIgX.findall('\(this\.id\,0\,(.*?)\)',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	GuQo8hCDmdBYNZRt5926LFMVwlJnA4 = GuQo8hCDmdBYNZRt5926LFMVwlJnA4[0]
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"serversList"(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('id="(.*?)".*?">(.*?)</li>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for a80aUzWcZHwT6Lxt2VJiNYRQBjfSq,title in items:
			title = title.strip(' ')
			BoEFz2WhUyvTgDeiZ = xxE5BSyQkNsj+'/wp-content/themes/vo2021/temp/ajax/iframe2.php?id='+GuQo8hCDmdBYNZRt5926LFMVwlJnA4+'&video='+a80aUzWcZHwT6Lxt2VJiNYRQBjfSq[2:]+'?named='+title+'__watch'
			QQ2cE1FjUyxPonbDhaTkV6B3i.append(BoEFz2WhUyvTgDeiZ)
	BoEFz2WhUyvTgDeiZ = My7Dwqvs6bfGNSIgX.findall('"getEmbed".*?src="(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if BoEFz2WhUyvTgDeiZ:
		title = ooq2D9xF8ZLpPBs(BoEFz2WhUyvTgDeiZ[0],'url')
		BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ[0]+'?named='+title+'__embed'
		QQ2cE1FjUyxPonbDhaTkV6B3i.append(BoEFz2WhUyvTgDeiZ)
	bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = url.strip('/')+'/?do=download'
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,'','','','','SHOOFPRO-PLAY-2nd')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"table-responsive"(.*?)</table>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('<td>(.*?)</td>.*?href="(.*?)"',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for title,BoEFz2WhUyvTgDeiZ in items:
			title = title.strip(' ')
			if 'anavidz' in BoEFz2WhUyvTgDeiZ: U2UaTcgBpsEZxKiRG1Xv8 = '__خاص'
			else: U2UaTcgBpsEZxKiRG1Xv8 = ''
			BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ+'?named='+title+'__download'+U2UaTcgBpsEZxKiRG1Xv8
			QQ2cE1FjUyxPonbDhaTkV6B3i.append(BoEFz2WhUyvTgDeiZ)
	import t1kDWXQVpC
	t1kDWXQVpC.rqVt2xDi7jzJHBcPMRs6h0L(QQ2cE1FjUyxPonbDhaTkV6B3i,baNWS6nfqTC5iX4Kl,'video',url)
	return
def HjZcUIVAXFCqy9TfBWKtgY2(search,xxE5BSyQkNsj=''):
	search,LQf3AeozSrai,showDialogs = X54MLovbG8nAEkB9J(search)
	if search=='': search = ViKAIsLurq83RSENayxWb()
	if search=='': return
	search = search.replace(' ','+')
	if xxE5BSyQkNsj=='': xxE5BSyQkNsj = EZxQp1WOldMTvFU
	url = xxE5BSyQkNsj+'/search/'+search+'/'
	sscM839DP1jWZ4zl6uIx0Kyn(url,'')
	return
# -*- coding: utf-8 -*-
from G6AHskJeqN import *
baNWS6nfqTC5iX4Kl = 'IFILM'
teUPLFC3B8bArakwHVGsdhoIWDM49f = '_IFL_'
EZxQp1WOldMTvFU = AK5RqLhji4W1wt9VdrCD3PGeQM[baNWS6nfqTC5iX4Kl][0]
oHxnAT1DzYQv = AK5RqLhji4W1wt9VdrCD3PGeQM[baNWS6nfqTC5iX4Kl][1]
aA1tX3Sy6lfxQ = AK5RqLhji4W1wt9VdrCD3PGeQM[baNWS6nfqTC5iX4Kl][2]
iH1LdhmjFk6t2CeXBoKawPbrJlz8 = AK5RqLhji4W1wt9VdrCD3PGeQM[baNWS6nfqTC5iX4Kl][3]
def VbgEajY4Bt2COpGDcPqI(mode,url,z3z9QgENFk5eMYB4,text):
	if   mode==20: ft3e2JBKQVXWlFPjaMhkEqGxvDg = lNFfgBQJ5qKZH4snXzTES0MO()
	elif mode==21: ft3e2JBKQVXWlFPjaMhkEqGxvDg = eN02L7Tf5bQ(url)
	elif mode==22: ft3e2JBKQVXWlFPjaMhkEqGxvDg = sscM839DP1jWZ4zl6uIx0Kyn(url,z3z9QgENFk5eMYB4)
	elif mode==23: ft3e2JBKQVXWlFPjaMhkEqGxvDg = o4oY13v5dWMcbilEDjKCnXNzHZ0(url,z3z9QgENFk5eMYB4)
	elif mode==24: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HDxCnPKFhITpZmOsA4a0UL6(url,text)
	elif mode==25: ft3e2JBKQVXWlFPjaMhkEqGxvDg = D63AYefnLXrVWuCySU1z(url)
	elif mode==27: ft3e2JBKQVXWlFPjaMhkEqGxvDg = KK8gr6Iv04mjZXF(url)
	elif mode==28: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HXbMVyk6a2()
	elif mode==29: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HjZcUIVAXFCqy9TfBWKtgY2(text)
	else: ft3e2JBKQVXWlFPjaMhkEqGxvDg = False
	return ft3e2JBKQVXWlFPjaMhkEqGxvDg
def lNFfgBQJ5qKZH4snXzTES0MO():
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'عربي',EZxQp1WOldMTvFU,21,'','101')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'English',oHxnAT1DzYQv,21,'','101')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'فارسى',aA1tX3Sy6lfxQ,21,'','101')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'فارسى 2',iH1LdhmjFk6t2CeXBoKawPbrJlz8,21,'','101')
	return
def HXbMVyk6a2():
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('live',teUPLFC3B8bArakwHVGsdhoIWDM49f+'عربي',EZxQp1WOldMTvFU,27)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('live',teUPLFC3B8bArakwHVGsdhoIWDM49f+'English',oHxnAT1DzYQv,27)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('live',teUPLFC3B8bArakwHVGsdhoIWDM49f+'فارسى',aA1tX3Sy6lfxQ,27)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('live',teUPLFC3B8bArakwHVGsdhoIWDM49f+'فارسى 2',iH1LdhmjFk6t2CeXBoKawPbrJlz8,27)
	return
def eN02L7Tf5bQ(Kl6tPIJpUA4EsF):
	baNWS6nfqTC5iX4Kl = Kl6tPIJpUA4EsF
	if Kl6tPIJpUA4EsF=='IFILM-ARABIC': Kl6tPIJpUA4EsF = EZxQp1WOldMTvFU
	elif Kl6tPIJpUA4EsF=='IFILM-ENGLISH': Kl6tPIJpUA4EsF = oHxnAT1DzYQv
	else: baNWS6nfqTC5iX4Kl = ''
	iOZ5nu0Y6Q4aqDUrElfIP9Tek = Ax9UEHfdlb5stgGZVCv(Kl6tPIJpUA4EsF)
	if iOZ5nu0Y6Q4aqDUrElfIP9Tek=='ar' or baNWS6nfqTC5iX4Kl=='IFILM-ARABIC':
		HH93fvmtuUI8P4BCyEgA7r0oxp6WG = 'بحث في الموقع'
		mNldo9CrLIXJkbWAzEpD56 = 'مسلسلات - حالية'
		bdHQJiTCSFGgoXL3v2rMNAEn6y = 'مسلسلات - أحدث'
		YgpEXCDSivz3LNdUBF8 = 'مسلسلات - أبجدي'
		wyLP4ESAZQKJ81Xa63nR7lx = 'بث حي آي فيلم'
		TsLjAnQ3SpJWGmlh = 'أفلام'
		FFV1kTPX039OiAZJQsMB8Np = 'موسيقى'
		EzUDm94Zbc5KCoVJ0 = 'برامج'
	elif iOZ5nu0Y6Q4aqDUrElfIP9Tek=='en' or baNWS6nfqTC5iX4Kl=='IFILM-ENGLISH':
		HH93fvmtuUI8P4BCyEgA7r0oxp6WG = 'Search in site'
		mNldo9CrLIXJkbWAzEpD56 = 'Series - Current'
		bdHQJiTCSFGgoXL3v2rMNAEn6y = 'Series - Latest'
		YgpEXCDSivz3LNdUBF8 = 'Series - Alphabet'
		wyLP4ESAZQKJ81Xa63nR7lx = 'Live iFilm channel'
		TsLjAnQ3SpJWGmlh = 'Movies'
		FFV1kTPX039OiAZJQsMB8Np = 'Music'
		EzUDm94Zbc5KCoVJ0 = 'Shows'
	elif iOZ5nu0Y6Q4aqDUrElfIP9Tek in ['fa','fa2']:
		HH93fvmtuUI8P4BCyEgA7r0oxp6WG = 'جستجو در سایت'
		mNldo9CrLIXJkbWAzEpD56 = 'سريال - جاری'
		bdHQJiTCSFGgoXL3v2rMNAEn6y = 'سريال - آخرین'
		YgpEXCDSivz3LNdUBF8 = 'سريال - الفبا'
		wyLP4ESAZQKJ81Xa63nR7lx = 'پخش زنده اي فيلم'
		TsLjAnQ3SpJWGmlh = 'فيلم'
		FFV1kTPX039OiAZJQsMB8Np = 'موسيقى'
		EzUDm94Zbc5KCoVJ0 = 'برنامه ها'
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+HH93fvmtuUI8P4BCyEgA7r0oxp6WG,Kl6tPIJpUA4EsF,29,'','','_REMEMBERRESULTS_')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('live',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+wyLP4ESAZQKJ81Xa63nR7lx,Kl6tPIJpUA4EsF,27)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	us7LOaKdRDwxbt0lP = ['Series','Program','Music']
	MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(IIiPCruL6dT8s1lqj47SzpVHnYNm,Kl6tPIJpUA4EsF+'/home','','','','IFILM-MENU-1st')
	XBuP6Op7y4K=My7Dwqvs6bfGNSIgX.findall('button-menu(.*?)/Contact',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)">(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title in items:
			if any(WoFrX46wzbCNp18 in BoEFz2WhUyvTgDeiZ for WoFrX46wzbCNp18 in us7LOaKdRDwxbt0lP):
				url = Kl6tPIJpUA4EsF+BoEFz2WhUyvTgDeiZ
				if 'Series' in BoEFz2WhUyvTgDeiZ:
					VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+mNldo9CrLIXJkbWAzEpD56,url,22,'','100')
					VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+bdHQJiTCSFGgoXL3v2rMNAEn6y,url,22,'','101')
					VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+YgpEXCDSivz3LNdUBF8,url,22,'','201')
				elif 'Film' in BoEFz2WhUyvTgDeiZ: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+TsLjAnQ3SpJWGmlh,url,22,'','100')
				elif 'Music' in BoEFz2WhUyvTgDeiZ: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+FFV1kTPX039OiAZJQsMB8Np,url,25,'','101')
				elif 'Program' in BoEFz2WhUyvTgDeiZ: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+EzUDm94Zbc5KCoVJ0,url,22,'','101')
	return MK6ZT2zjC1SbmveNFqor
def D63AYefnLXrVWuCySU1z(url):
	Kl6tPIJpUA4EsF = dJxaZetAH2(url)
	MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(IIiPCruL6dT8s1lqj47SzpVHnYNm,url,'','','','IFILM-MUSIC_MENU-1st')
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('Music-tools-header(.*?)Music-body',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	vsptNMP2ZQC = XBuP6Op7y4K[0]
	title = My7Dwqvs6bfGNSIgX.findall('<p>(.*?)</p>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)[0]
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,url,22,'','101')
	items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)">(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	for BoEFz2WhUyvTgDeiZ,title in items:
		BoEFz2WhUyvTgDeiZ = Kl6tPIJpUA4EsF + BoEFz2WhUyvTgDeiZ
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,23,'','101')
	return
def sscM839DP1jWZ4zl6uIx0Kyn(url,z3z9QgENFk5eMYB4):
	Kl6tPIJpUA4EsF = dJxaZetAH2(url)
	iOZ5nu0Y6Q4aqDUrElfIP9Tek = Ax9UEHfdlb5stgGZVCv(url)
	type = url.split('/')[-1]
	HH03TPbAGV91QezuW5d8s = str(int(z3z9QgENFk5eMYB4)//100)
	z3z9QgENFk5eMYB4 = str(int(z3z9QgENFk5eMYB4)%100)
	if type=='Series' and z3z9QgENFk5eMYB4=='0':
		MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(UuEtImzir9,url,'','','','IFILM-TITLES-1st')
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('serial-body(.*?)class="row',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?src=(.*?)>.*?h3>(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,IcWzVO137wFvemn2QTq8yKs9,title in items:
			title = tW06wVMpReHfnj3KgzT2va(title)
			title = PIfAumbGicwg5ye(title)
			BoEFz2WhUyvTgDeiZ = Kl6tPIJpUA4EsF + BoEFz2WhUyvTgDeiZ
			IcWzVO137wFvemn2QTq8yKs9 = Kl6tPIJpUA4EsF + F8fMqZKB4APk(IcWzVO137wFvemn2QTq8yKs9)
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,23,IcWzVO137wFvemn2QTq8yKs9,HH03TPbAGV91QezuW5d8s+'01')
	iaApe0uGM95o3TX1rtOnUW2Hx=0
	if type=='Series': g4Y0BXLxCpuojKP1SAUtcq7TwN2='3'
	if type=='Film': g4Y0BXLxCpuojKP1SAUtcq7TwN2='5'
	if type=='Program': g4Y0BXLxCpuojKP1SAUtcq7TwN2='7'
	if type in ['Series','Program','Film'] and z3z9QgENFk5eMYB4!='0':
		bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = Kl6tPIJpUA4EsF+'/Home/PageingItem?category='+g4Y0BXLxCpuojKP1SAUtcq7TwN2+'&page='+z3z9QgENFk5eMYB4+'&size=30&orderby='+HH03TPbAGV91QezuW5d8s
		MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(UuEtImzir9,bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,'','','','IFILM-TITLES-2nd')
		items = My7Dwqvs6bfGNSIgX.findall('"Id":(.*?),"Title":(.*?),.+?"ImageAddress_S":"(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		for id,title,IcWzVO137wFvemn2QTq8yKs9 in items:
			title = tW06wVMpReHfnj3KgzT2va(title)
			title = title.replace('\\','')
			title = title.replace('"','')
			iaApe0uGM95o3TX1rtOnUW2Hx += 1
			BoEFz2WhUyvTgDeiZ = Kl6tPIJpUA4EsF + '/' + type + '/Content/' + id
			IcWzVO137wFvemn2QTq8yKs9 = Kl6tPIJpUA4EsF + F8fMqZKB4APk(IcWzVO137wFvemn2QTq8yKs9)
			if type=='Film': VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,24,IcWzVO137wFvemn2QTq8yKs9,HH03TPbAGV91QezuW5d8s+'01')
			else: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,23,IcWzVO137wFvemn2QTq8yKs9,HH03TPbAGV91QezuW5d8s+'01')
	if type=='Music':
		MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(UuEtImzir9,Kl6tPIJpUA4EsF+'/Music/Index?page='+z3z9QgENFk5eMYB4,'','','','IFILM-TITLES-3rd')
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('pagination-demo(.*?)pagination-demo',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?src="(.*?)".*?<h3>(.*?)</h3>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,IcWzVO137wFvemn2QTq8yKs9,title in items:
			iaApe0uGM95o3TX1rtOnUW2Hx += 1
			IcWzVO137wFvemn2QTq8yKs9 = Kl6tPIJpUA4EsF + IcWzVO137wFvemn2QTq8yKs9
			BoEFz2WhUyvTgDeiZ = Kl6tPIJpUA4EsF + BoEFz2WhUyvTgDeiZ
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,23,IcWzVO137wFvemn2QTq8yKs9,'101')
	if iaApe0uGM95o3TX1rtOnUW2Hx>20:
		title='صفحة '
		if iOZ5nu0Y6Q4aqDUrElfIP9Tek=='en': title = 'Page '
		if iOZ5nu0Y6Q4aqDUrElfIP9Tek=='fa': title = 'صفحه '
		if iOZ5nu0Y6Q4aqDUrElfIP9Tek=='fa2': title = 'صفحه '
		for sQd8Tjic9h in range(1,11) :
			if not z3z9QgENFk5eMYB4==str(sQd8Tjic9h):
				xVYplwas1qvnBdz = '0'+str(sQd8Tjic9h)
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title+str(sQd8Tjic9h),url,22,'',HH03TPbAGV91QezuW5d8s+xVYplwas1qvnBdz[-2:])
	return
def o4oY13v5dWMcbilEDjKCnXNzHZ0(url,z3z9QgENFk5eMYB4):
	if not z3z9QgENFk5eMYB4: z3z9QgENFk5eMYB4 = 0
	Kl6tPIJpUA4EsF = dJxaZetAH2(url)
	Dj051Gb2vsNOkuoTg = dJxaZetAH2(url)
	iOZ5nu0Y6Q4aqDUrElfIP9Tek = Ax9UEHfdlb5stgGZVCv(url)
	tuHzpfZmLAdCObQS2k3 = url.split('/')
	id,type = tuHzpfZmLAdCObQS2k3[-1],tuHzpfZmLAdCObQS2k3[3]
	HH03TPbAGV91QezuW5d8s = str(int(z3z9QgENFk5eMYB4)//100)
	z3z9QgENFk5eMYB4 = str(int(z3z9QgENFk5eMYB4)%100)
	iaApe0uGM95o3TX1rtOnUW2Hx = 0
	if type=='Series':
		MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(UuEtImzir9,url,'','','','IFILM-EPISODES-1st')
		items = My7Dwqvs6bfGNSIgX.findall('Comment_panel_Item.*?p>(.*?)<i.+?var inter_ = (.*?);.*?src="(.*?)\'.*?data-url="(.*?)\'',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		title = ' - الحلقة '
		if iOZ5nu0Y6Q4aqDUrElfIP9Tek=='en': title = ' - Episode '
		if iOZ5nu0Y6Q4aqDUrElfIP9Tek=='fa': title = ' - قسمت '
		if iOZ5nu0Y6Q4aqDUrElfIP9Tek=='fa2': title = ' - قسمت '
		if iOZ5nu0Y6Q4aqDUrElfIP9Tek=='fa': zBZ9i8X1GmP46s3WKAMyrLwtl = ''
		else: zBZ9i8X1GmP46s3WKAMyrLwtl = iOZ5nu0Y6Q4aqDUrElfIP9Tek
		usZnV9bNLDJY0SjcApPW3 = My7Dwqvs6bfGNSIgX.findall('data-video="(.*?)(\'.*?\'_)(.*?)">',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		for name,count,IcWzVO137wFvemn2QTq8yKs9,BoEFz2WhUyvTgDeiZ in items:
			for ffhN7jAqe3Q4cR0Ukptzl in range(int(count),0,-1):
				Hp3tM8gFIWL2ZhAzd = IcWzVO137wFvemn2QTq8yKs9 + zBZ9i8X1GmP46s3WKAMyrLwtl + id + '/' + str(ffhN7jAqe3Q4cR0Ukptzl) + '.png'
				mNldo9CrLIXJkbWAzEpD56 = name + title + str(ffhN7jAqe3Q4cR0Ukptzl)
				mNldo9CrLIXJkbWAzEpD56 = PIfAumbGicwg5ye(mNldo9CrLIXJkbWAzEpD56)
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+mNldo9CrLIXJkbWAzEpD56,url,24,Hp3tM8gFIWL2ZhAzd,'',str(ffhN7jAqe3Q4cR0Ukptzl))
	elif type=='Program':
		bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = Kl6tPIJpUA4EsF+'/Home/PageingAttachmentItem?id='+str(id)+'&page='+z3z9QgENFk5eMYB4+'&size=30&orderby=1'
		MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(UuEtImzir9,bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,'','','','IFILM-EPISODES-2nd')
		items = My7Dwqvs6bfGNSIgX.findall('Episode":(.*?),.*?ImageAddress_S":"(.*?)".*?VideoAddress":"(.*?)".*?Discription":"(.*?)".*?Caption":"(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		title = ' - الحلقة '
		if iOZ5nu0Y6Q4aqDUrElfIP9Tek=='en': title = ' - Episode '
		if iOZ5nu0Y6Q4aqDUrElfIP9Tek=='fa': title = ' - قسمت '
		if iOZ5nu0Y6Q4aqDUrElfIP9Tek=='fa2': title = ' - قسمت '
		for ffhN7jAqe3Q4cR0Ukptzl,IcWzVO137wFvemn2QTq8yKs9,BoEFz2WhUyvTgDeiZ,St63PvKhH0ai,name in items:
			iaApe0uGM95o3TX1rtOnUW2Hx += 1
			Hp3tM8gFIWL2ZhAzd = Dj051Gb2vsNOkuoTg + F8fMqZKB4APk(IcWzVO137wFvemn2QTq8yKs9)
			name = tW06wVMpReHfnj3KgzT2va(name)
			mNldo9CrLIXJkbWAzEpD56 = name + title + str(ffhN7jAqe3Q4cR0Ukptzl)
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+mNldo9CrLIXJkbWAzEpD56,bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,24,Hp3tM8gFIWL2ZhAzd,'',str(iaApe0uGM95o3TX1rtOnUW2Hx))
	elif type=='Music':
		if 'Content' in url and 'category' not in url:
			bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = Kl6tPIJpUA4EsF+'/Music/GetTracksBy?id='+str(id)+'&page='+z3z9QgENFk5eMYB4+'&size=30&type=0'
			MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(UuEtImzir9,bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,'','','','IFILM-EPISODES-3rd')
			items = My7Dwqvs6bfGNSIgX.findall('ImageAddress_S":"(.*?)".*?VoiceAddress":"(.*?)".*?Caption":"(.*?)","Title":"(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
			for IcWzVO137wFvemn2QTq8yKs9,BoEFz2WhUyvTgDeiZ,name,title in items:
				iaApe0uGM95o3TX1rtOnUW2Hx += 1
				Hp3tM8gFIWL2ZhAzd = Dj051Gb2vsNOkuoTg + F8fMqZKB4APk(IcWzVO137wFvemn2QTq8yKs9)
				mNldo9CrLIXJkbWAzEpD56 = name + ' - ' + title
				mNldo9CrLIXJkbWAzEpD56 = mNldo9CrLIXJkbWAzEpD56.strip(' ')
				mNldo9CrLIXJkbWAzEpD56 = tW06wVMpReHfnj3KgzT2va(mNldo9CrLIXJkbWAzEpD56)
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+mNldo9CrLIXJkbWAzEpD56,bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,24,Hp3tM8gFIWL2ZhAzd,'',str(iaApe0uGM95o3TX1rtOnUW2Hx))
		elif 'Clips' in url:
			bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = Kl6tPIJpUA4EsF+'/Music/GetTracksBy?id=0&page='+z3z9QgENFk5eMYB4+'&size=30&type=15'
			MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(UuEtImzir9,bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,'','','','IFILM-EPISODES-4th')
			items = My7Dwqvs6bfGNSIgX.findall('ImageAddress_S":"(.*?)".*?Caption":"(.*?)".*?VideoAddress":"(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
			for IcWzVO137wFvemn2QTq8yKs9,title,BoEFz2WhUyvTgDeiZ in items:
				iaApe0uGM95o3TX1rtOnUW2Hx += 1
				Hp3tM8gFIWL2ZhAzd = Dj051Gb2vsNOkuoTg + F8fMqZKB4APk(IcWzVO137wFvemn2QTq8yKs9)
				mNldo9CrLIXJkbWAzEpD56 = title.strip(' ')
				mNldo9CrLIXJkbWAzEpD56 = tW06wVMpReHfnj3KgzT2va(mNldo9CrLIXJkbWAzEpD56)
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+mNldo9CrLIXJkbWAzEpD56,bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,24,Hp3tM8gFIWL2ZhAzd,'',str(iaApe0uGM95o3TX1rtOnUW2Hx))
		elif 'category' in url:
			if 'category=6' in url:
				bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = Kl6tPIJpUA4EsF+'/Music/GetTracksBy?id=0&page='+z3z9QgENFk5eMYB4+'&size=30&type=6'
				MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(UuEtImzir9,bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,'','','','IFILM-EPISODES-5th')
			elif 'category=4' in url:
				bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = Kl6tPIJpUA4EsF+'/Music/GetTracksBy?id=0&page='+z3z9QgENFk5eMYB4+'&size=30&type=4'
				MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(UuEtImzir9,bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,'','','','IFILM-EPISODES-6th')
			items = My7Dwqvs6bfGNSIgX.findall('ImageAddress_S":"(.*?)".*?VoiceAddress":"(.*?)".*?Caption":"(.*?)","Title":"(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
			for IcWzVO137wFvemn2QTq8yKs9,BoEFz2WhUyvTgDeiZ,name,title in items:
				iaApe0uGM95o3TX1rtOnUW2Hx += 1
				Hp3tM8gFIWL2ZhAzd = Dj051Gb2vsNOkuoTg + F8fMqZKB4APk(IcWzVO137wFvemn2QTq8yKs9)
				mNldo9CrLIXJkbWAzEpD56 = name + ' - ' + title
				mNldo9CrLIXJkbWAzEpD56 = mNldo9CrLIXJkbWAzEpD56.strip(' ')
				mNldo9CrLIXJkbWAzEpD56 = tW06wVMpReHfnj3KgzT2va(mNldo9CrLIXJkbWAzEpD56)
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+mNldo9CrLIXJkbWAzEpD56,bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,24,Hp3tM8gFIWL2ZhAzd,'',str(iaApe0uGM95o3TX1rtOnUW2Hx))
	if type=='Music' or type=='Program':
		if iaApe0uGM95o3TX1rtOnUW2Hx>25:
			title='صفحة '
			if iOZ5nu0Y6Q4aqDUrElfIP9Tek=='en': title = ' Page '
			if iOZ5nu0Y6Q4aqDUrElfIP9Tek=='fa': title = ' صفحه '
			if iOZ5nu0Y6Q4aqDUrElfIP9Tek=='fa2': title = ' صفحه '
			for sQd8Tjic9h in range(1,11):
				if not z3z9QgENFk5eMYB4==str(sQd8Tjic9h):
					xVYplwas1qvnBdz = '0'+str(sQd8Tjic9h)
					VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title+str(sQd8Tjic9h),url,23,'',HH03TPbAGV91QezuW5d8s+xVYplwas1qvnBdz[-2:])
	return
def HDxCnPKFhITpZmOsA4a0UL6(url,ffhN7jAqe3Q4cR0Ukptzl):
	Dj051Gb2vsNOkuoTg = dJxaZetAH2(url)
	wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = [],[]
	MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(UuEtImzir9,url,'','','','IFILM-PLAY-1st')
	items = My7Dwqvs6bfGNSIgX.findall('data-video="(.*?)(\'.*?\'_)(.*?)">',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if items:
		iOZ5nu0Y6Q4aqDUrElfIP9Tek = Ax9UEHfdlb5stgGZVCv(url)
		tuHzpfZmLAdCObQS2k3 = url.split('/')
		id,type = tuHzpfZmLAdCObQS2k3[-1],tuHzpfZmLAdCObQS2k3[3]
		BoEFz2WhUyvTgDeiZ = items[0][0]+iOZ5nu0Y6Q4aqDUrElfIP9Tek+id+'/,'+ffhN7jAqe3Q4cR0Ukptzl+','+ffhN7jAqe3Q4cR0Ukptzl+'_'+items[0][2]
		wlfZEzuRyYLvrp.append('m3u8')
		QQ2cE1FjUyxPonbDhaTkV6B3i.append(BoEFz2WhUyvTgDeiZ)
	items = My7Dwqvs6bfGNSIgX.findall('data-url="(http.*?)(\'.*?\')(\..*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if items:
		iOZ5nu0Y6Q4aqDUrElfIP9Tek = Ax9UEHfdlb5stgGZVCv(url)
		tuHzpfZmLAdCObQS2k3 = url.split('/')
		id,type = tuHzpfZmLAdCObQS2k3[-1],tuHzpfZmLAdCObQS2k3[3]
		BoEFz2WhUyvTgDeiZ = items[0][0]+iOZ5nu0Y6Q4aqDUrElfIP9Tek+id+'/'+ffhN7jAqe3Q4cR0Ukptzl+items[0][2]
		wlfZEzuRyYLvrp.append('mp4 url')
		QQ2cE1FjUyxPonbDhaTkV6B3i.append(BoEFz2WhUyvTgDeiZ)
	items = My7Dwqvs6bfGNSIgX.findall('source src="(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	for BoEFz2WhUyvTgDeiZ in items:
		BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ.replace('//','/')
		wlfZEzuRyYLvrp.append('mp4 src')
		QQ2cE1FjUyxPonbDhaTkV6B3i.append(BoEFz2WhUyvTgDeiZ)
	items = My7Dwqvs6bfGNSIgX.findall('VideoAddress":"(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if items:
		BoEFz2WhUyvTgDeiZ = items[int(ffhN7jAqe3Q4cR0Ukptzl)-1]
		BoEFz2WhUyvTgDeiZ = Dj051Gb2vsNOkuoTg+F8fMqZKB4APk(BoEFz2WhUyvTgDeiZ)
		wlfZEzuRyYLvrp.append('mp4 address')
		QQ2cE1FjUyxPonbDhaTkV6B3i.append(BoEFz2WhUyvTgDeiZ)
	items = My7Dwqvs6bfGNSIgX.findall('VoiceAddress":"(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if items:
		BoEFz2WhUyvTgDeiZ = items[int(ffhN7jAqe3Q4cR0Ukptzl)-1]
		BoEFz2WhUyvTgDeiZ = Dj051Gb2vsNOkuoTg+F8fMqZKB4APk(BoEFz2WhUyvTgDeiZ)
		wlfZEzuRyYLvrp.append('mp3 address')
		QQ2cE1FjUyxPonbDhaTkV6B3i.append(BoEFz2WhUyvTgDeiZ)
	if len(QQ2cE1FjUyxPonbDhaTkV6B3i)==1: BoEFz2WhUyvTgDeiZ = QQ2cE1FjUyxPonbDhaTkV6B3i[0]
	else:
		GOtNfU3xQFkEhPouwA = CnKwdteDG5BE8MTRhUpYIJm3NLrSgq('اختر الفيديو المناسب:', wlfZEzuRyYLvrp)
		if GOtNfU3xQFkEhPouwA == -1 : return
		BoEFz2WhUyvTgDeiZ = QQ2cE1FjUyxPonbDhaTkV6B3i[GOtNfU3xQFkEhPouwA]
	B0xcwKkMQ16mpSFRaVHPTzuhUZngLq(BoEFz2WhUyvTgDeiZ,baNWS6nfqTC5iX4Kl,'video')
	return
def dJxaZetAH2(url):
	if EZxQp1WOldMTvFU in url: bo1dqzR8JIwlThvDcyU4jf = EZxQp1WOldMTvFU
	elif oHxnAT1DzYQv in url: bo1dqzR8JIwlThvDcyU4jf = oHxnAT1DzYQv
	elif aA1tX3Sy6lfxQ in url: bo1dqzR8JIwlThvDcyU4jf = aA1tX3Sy6lfxQ
	elif iH1LdhmjFk6t2CeXBoKawPbrJlz8 in url: bo1dqzR8JIwlThvDcyU4jf = iH1LdhmjFk6t2CeXBoKawPbrJlz8
	else: bo1dqzR8JIwlThvDcyU4jf = ''
	return bo1dqzR8JIwlThvDcyU4jf
def Ax9UEHfdlb5stgGZVCv(url):
	if   EZxQp1WOldMTvFU in url: iOZ5nu0Y6Q4aqDUrElfIP9Tek = 'ar'
	elif oHxnAT1DzYQv in url: iOZ5nu0Y6Q4aqDUrElfIP9Tek = 'en'
	elif aA1tX3Sy6lfxQ in url: iOZ5nu0Y6Q4aqDUrElfIP9Tek = 'fa'
	elif iH1LdhmjFk6t2CeXBoKawPbrJlz8 in url: iOZ5nu0Y6Q4aqDUrElfIP9Tek = 'fa2'
	else: iOZ5nu0Y6Q4aqDUrElfIP9Tek = ''
	return iOZ5nu0Y6Q4aqDUrElfIP9Tek
def KK8gr6Iv04mjZXF(url):
	iOZ5nu0Y6Q4aqDUrElfIP9Tek = Ax9UEHfdlb5stgGZVCv(url)
	bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = url + '/Home/Live'
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(IIiPCruL6dT8s1lqj47SzpVHnYNm,'GET',bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,'','','','','IFILM-LIVE-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	items = My7Dwqvs6bfGNSIgX.findall('source src="(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	QAKdHzO0rehbtyIc = items[0]
	B0xcwKkMQ16mpSFRaVHPTzuhUZngLq(QAKdHzO0rehbtyIc,baNWS6nfqTC5iX4Kl,'live')
	return
def HjZcUIVAXFCqy9TfBWKtgY2(search):
	search,LQf3AeozSrai,showDialogs = X54MLovbG8nAEkB9J(search)
	if not search:
		search = ViKAIsLurq83RSENayxWb()
		if not search: return
	ystIEd371fLkT50pcRUWi9olNDu = search.replace(' ','+')
	if showDialogs:
		rUBO1RZhI9LVvjlozNeEFJ8dT = [ EZxQp1WOldMTvFU , oHxnAT1DzYQv , aA1tX3Sy6lfxQ , iH1LdhmjFk6t2CeXBoKawPbrJlz8 ]
		YNuW90vpw8rBSTU = [ 'عربي' , 'English' , 'فارسى' , 'فارسى 2' ]
		GOtNfU3xQFkEhPouwA = CnKwdteDG5BE8MTRhUpYIJm3NLrSgq('اختر اللغة المناسبة:', YNuW90vpw8rBSTU)
		if GOtNfU3xQFkEhPouwA == -1 : return
		website = rUBO1RZhI9LVvjlozNeEFJ8dT[GOtNfU3xQFkEhPouwA]
	else:
		if '_IFILM-ARABIC_' in LQf3AeozSrai: website = EZxQp1WOldMTvFU
		elif '_IFILM-ENGLISH_' in LQf3AeozSrai: website = oHxnAT1DzYQv
		else: website = ''
	if not website: return
	iOZ5nu0Y6Q4aqDUrElfIP9Tek = Ax9UEHfdlb5stgGZVCv(website)
	bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = website + "/Home/Search?searchstring=" + ystIEd371fLkT50pcRUWi9olNDu
	MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(UuEtImzir9,bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,'','','','IFILM-SEARCH-1st')
	items = My7Dwqvs6bfGNSIgX.findall('"ImageAddress_S":"(.*?)".*?"CategoryId":(.*?),"Id":(.*?),"Title":"(.*?)",',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if items:
		for IcWzVO137wFvemn2QTq8yKs9,g4Y0BXLxCpuojKP1SAUtcq7TwN2,id,title in items:
			if g4Y0BXLxCpuojKP1SAUtcq7TwN2 in ['3','7']:
				title = title.replace('\\','')
				title = title.replace('"','')
				if g4Y0BXLxCpuojKP1SAUtcq7TwN2=='3':
					type = 'Series'
					if iOZ5nu0Y6Q4aqDUrElfIP9Tek=='ar': name = 'مسلسل : '
					elif iOZ5nu0Y6Q4aqDUrElfIP9Tek=='en': name = 'Series : '
					elif iOZ5nu0Y6Q4aqDUrElfIP9Tek=='fa': name = 'سريال ها : '
					elif iOZ5nu0Y6Q4aqDUrElfIP9Tek=='fa2': name = 'سريال ها : '
				elif g4Y0BXLxCpuojKP1SAUtcq7TwN2=='5':
					type = 'Film'
					if iOZ5nu0Y6Q4aqDUrElfIP9Tek=='ar': name = 'فيلم : '
					elif iOZ5nu0Y6Q4aqDUrElfIP9Tek=='en': name = 'Movie : '
					elif iOZ5nu0Y6Q4aqDUrElfIP9Tek=='fa': name = 'فيلم : '
					elif iOZ5nu0Y6Q4aqDUrElfIP9Tek=='fa2': name = 'فلم ها : '
				elif g4Y0BXLxCpuojKP1SAUtcq7TwN2=='7':
					type = 'Program'
					if iOZ5nu0Y6Q4aqDUrElfIP9Tek=='ar': name = 'برنامج : '
					elif iOZ5nu0Y6Q4aqDUrElfIP9Tek=='en': name = 'Program : '
					elif iOZ5nu0Y6Q4aqDUrElfIP9Tek=='fa': name = 'برنامه ها : '
					elif iOZ5nu0Y6Q4aqDUrElfIP9Tek=='fa2': name = 'برنامه ها : '
				title = name + title
				BoEFz2WhUyvTgDeiZ = website + '/' + type + '/Content/' + id
				IcWzVO137wFvemn2QTq8yKs9 = F8fMqZKB4APk(IcWzVO137wFvemn2QTq8yKs9)
				IcWzVO137wFvemn2QTq8yKs9 = website+IcWzVO137wFvemn2QTq8yKs9
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,23,IcWzVO137wFvemn2QTq8yKs9,'101')
	return
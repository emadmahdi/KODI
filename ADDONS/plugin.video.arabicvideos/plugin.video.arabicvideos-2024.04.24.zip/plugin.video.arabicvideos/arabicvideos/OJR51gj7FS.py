# -*- coding: utf-8 -*-
from G6AHskJeqN import *
DaZhLqOIc24x6wv57YUlF3NgCzpGeX = 'IPTV'
ggzjQfBhqdOYNE = '_IPT_'
ffA7Cx1LygY6VFsJvUn4DidpcM9t = [
		 'IGNORED'
		,'LIVE_UNKNOWN_GROUPED','LIVE_UNKNOWN_GROUPED_SORTED'
		,'VOD_UNKNOWN_GROUPED','VOD_UNKNOWN_GROUPED_SORTED'
		,'LIVE_ARCHIVED_GROUPED_SORTED','LIVE_EPG_GROUPED_SORTED','LIVE_TIMESHIFT_GROUPED_SORTED'
		,'LIVE_GROUPED','LIVE_GROUPED_SORTED'
		,'LIVE_ORIGINAL_GROUPED','LIVE_FROM_GROUP_SORTED','LIVE_FROM_NAME_SORTED'
		,'VOD_MOVIES_GROUPED','VOD_MOVIES_GROUPED_SORTED'
		,'VOD_SERIES_GROUPED','VOD_SERIES_GROUPED_SORTED'
		,'VOD_ORIGINAL_GROUPED','VOD_FROM_GROUP_SORTED','VOD_FROM_NAME_SORTED'
		]
def zfogEMcGC60(H3HDqY5N4e0fWSXMikZ8CR7suUmJdx,SCakygtHx0AUXbO3emswB9F8,Gfsr6KpyVRovQmB8xcXUJ,dM2SkzwnVKc3FUPDl9BE,EoulZdO2FQmDYrqNbA1kagMp,InkN7SpoMudDGJ6K):
	global ggzjQfBhqdOYNE
	try:
		j4OBPfZchRSD1FI = str(InkN7SpoMudDGJ6K['folder'])
		ggzjQfBhqdOYNE = '_IP'+j4OBPfZchRSD1FI+'_'
	except: j4OBPfZchRSD1FI = ''
	if   H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==230: fM9jDUciIqk2SutLy5Y4ngE3aWlOe = pYtH5e3TnfuINr8jmVMEka()
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==231: fM9jDUciIqk2SutLy5Y4ngE3aWlOe = JZeiyxc3z1HX7Ej(j4OBPfZchRSD1FI)
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==232: fM9jDUciIqk2SutLy5Y4ngE3aWlOe = tTEOCAkV4NMQXp6UrLi(j4OBPfZchRSD1FI)
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==233: fM9jDUciIqk2SutLy5Y4ngE3aWlOe = um1OcGXaBWrP(j4OBPfZchRSD1FI,SCakygtHx0AUXbO3emswB9F8,Gfsr6KpyVRovQmB8xcXUJ,EoulZdO2FQmDYrqNbA1kagMp)
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==234: fM9jDUciIqk2SutLy5Y4ngE3aWlOe = TJZvpKG2we(j4OBPfZchRSD1FI,SCakygtHx0AUXbO3emswB9F8,Gfsr6KpyVRovQmB8xcXUJ,EoulZdO2FQmDYrqNbA1kagMp)
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==235: fM9jDUciIqk2SutLy5Y4ngE3aWlOe = HDxCnPKFhITpZmOsA4a0UL6(j4OBPfZchRSD1FI,SCakygtHx0AUXbO3emswB9F8,dM2SkzwnVKc3FUPDl9BE)
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==236: fM9jDUciIqk2SutLy5Y4ngE3aWlOe = hSReUdq5l2oVmPc(j4OBPfZchRSD1FI,True)
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==237: fM9jDUciIqk2SutLy5Y4ngE3aWlOe = BBnfvTrlahNoF6CskYZqSp(j4OBPfZchRSD1FI,True)
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==238: fM9jDUciIqk2SutLy5Y4ngE3aWlOe = zzmKM5dNIpgCt4Z6VwUa8LsfD(j4OBPfZchRSD1FI,SCakygtHx0AUXbO3emswB9F8,Gfsr6KpyVRovQmB8xcXUJ)
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==239: fM9jDUciIqk2SutLy5Y4ngE3aWlOe = aMRpBNWSu05t(Gfsr6KpyVRovQmB8xcXUJ,j4OBPfZchRSD1FI,SCakygtHx0AUXbO3emswB9F8,EoulZdO2FQmDYrqNbA1kagMp)
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==280: fM9jDUciIqk2SutLy5Y4ngE3aWlOe = X8BnqH7u1wJkIvPaQ5zlp6cfoVMW2N(j4OBPfZchRSD1FI,True)
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==281: fM9jDUciIqk2SutLy5Y4ngE3aWlOe = qb2Po0XSgLl3tJ4EjkY87Kax(j4OBPfZchRSD1FI)
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==282: fM9jDUciIqk2SutLy5Y4ngE3aWlOe = SeMRTfP9WOs(j4OBPfZchRSD1FI)
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==283: fM9jDUciIqk2SutLy5Y4ngE3aWlOe = bc0Beo1pNISzfKu(j4OBPfZchRSD1FI)
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==285: fM9jDUciIqk2SutLy5Y4ngE3aWlOe = JcRXuOm9GHM71nL2oyBIz(j4OBPfZchRSD1FI,SCakygtHx0AUXbO3emswB9F8,Gfsr6KpyVRovQmB8xcXUJ)
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==286: fM9jDUciIqk2SutLy5Y4ngE3aWlOe = Mg76s9J8pfxWc(j4OBPfZchRSD1FI)
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==289: fM9jDUciIqk2SutLy5Y4ngE3aWlOe = V4hoOjAbFK(Gfsr6KpyVRovQmB8xcXUJ,j4OBPfZchRSD1FI,SCakygtHx0AUXbO3emswB9F8,EoulZdO2FQmDYrqNbA1kagMp)
	else: fM9jDUciIqk2SutLy5Y4ngE3aWlOe = False
	return fM9jDUciIqk2SutLy5Y4ngE3aWlOe
def pYtH5e3TnfuINr8jmVMEka():
	for j4OBPfZchRSD1FI in range(1,HHm4q1SnPBZIf6wcap8zJoeDM7+1):
		ggzjQfBhqdOYNE = '_IP'+str(j4OBPfZchRSD1FI)+'_'
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',ggzjQfBhqdOYNE+'قائمة مجلد '+iUgLYNaTzxo[j4OBPfZchRSD1FI],'',280,'','','','',{'folder':j4OBPfZchRSD1FI})
	return
def X8BnqH7u1wJkIvPaQ5zlp6cfoVMW2N(j4OBPfZchRSD1FI='',hQbe2Mlty3LrBixvd7mSg=''):
	if j4OBPfZchRSD1FI:
		KRge5I0ov8BM4yLFjVhpGJHx = {'folder':j4OBPfZchRSD1FI}
		lmDKLTA2eqIU814H76RBgPtywh = ''
	else:
		KRge5I0ov8BM4yLFjVhpGJHx = ''
		lmDKLTA2eqIU814H76RBgPtywh = ''
	evNi2u8SH90gTnVEYqZm = p13ciNHPqwljuY5KQIWfD6EOm(j4OBPfZchRSD1FI,hQbe2Mlty3LrBixvd7mSg)
	if not evNi2u8SH90gTnVEYqZm:
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link',ggzjQfBhqdOYNE+'[COLOR FFFFFF00] إضافة أو تغيير اشتراك'+lmDKLTA2eqIU814H76RBgPtywh+' [/COLOR]','',231,'','','','',KRge5I0ov8BM4yLFjVhpGJHx)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link',ggzjQfBhqdOYNE+'[COLOR FFFFFF00] جلب ملفات'+lmDKLTA2eqIU814H76RBgPtywh+' [/COLOR]','',232,'','','','',KRge5I0ov8BM4yLFjVhpGJHx)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	else:
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',ggzjQfBhqdOYNE+'بحث في الملفات'+lmDKLTA2eqIU814H76RBgPtywh,'',289,'','','_REMEMBERRESULTS_','',KRge5I0ov8BM4yLFjVhpGJHx)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',ggzjQfBhqdOYNE+'قنوات بدون جلب ملفات','XTREAM_LIVE_GROUPS',285,'','','','',KRge5I0ov8BM4yLFjVhpGJHx)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',ggzjQfBhqdOYNE+'قنوات مصنفة مرتبة'+lmDKLTA2eqIU814H76RBgPtywh,'LIVE_GROUPED_SORTED',233,'','','','',KRge5I0ov8BM4yLFjVhpGJHx)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',ggzjQfBhqdOYNE+'قنوات مصنفة من القسم'+lmDKLTA2eqIU814H76RBgPtywh,'LIVE_FROM_GROUP_SORTED',233,'','','','',KRge5I0ov8BM4yLFjVhpGJHx)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',ggzjQfBhqdOYNE+'قنوات مصنفة من الاسم'+lmDKLTA2eqIU814H76RBgPtywh,'LIVE_FROM_NAME_SORTED',233,'','','','',KRge5I0ov8BM4yLFjVhpGJHx)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',ggzjQfBhqdOYNE+'قنوات مصنفة بلا ترتيب'+lmDKLTA2eqIU814H76RBgPtywh,'LIVE_GROUPED',233,'','','','',KRge5I0ov8BM4yLFjVhpGJHx)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',ggzjQfBhqdOYNE+'قنوات بلا ترتيب'+lmDKLTA2eqIU814H76RBgPtywh,'LIVE_ORIGINAL_GROUPED',233,'','','','',KRge5I0ov8BM4yLFjVhpGJHx)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',ggzjQfBhqdOYNE+'قنوات مجهولة مرتبة'+lmDKLTA2eqIU814H76RBgPtywh,'LIVE_UNKNOWN_GROUPED_SORTED',233,'','','','',KRge5I0ov8BM4yLFjVhpGJHx)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',ggzjQfBhqdOYNE+'قنوات مجهولة بلا ترتيب'+lmDKLTA2eqIU814H76RBgPtywh,'LIVE_UNKNOWN_GROUPED',233,'','','','',KRge5I0ov8BM4yLFjVhpGJHx)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',ggzjQfBhqdOYNE+'أفلام بدون جلب ملفات','XTREAM_VOD_GROUPS',285,'','','','',KRge5I0ov8BM4yLFjVhpGJHx)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',ggzjQfBhqdOYNE+'أفلام مصنفة بلا ترتيب'+lmDKLTA2eqIU814H76RBgPtywh,'VOD_MOVIES_GROUPED',233,'','','','',KRge5I0ov8BM4yLFjVhpGJHx)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',ggzjQfBhqdOYNE+'أفلام مصنفة مرتبة'+lmDKLTA2eqIU814H76RBgPtywh,'VOD_MOVIES_GROUPED_SORTED',233,'','','','',KRge5I0ov8BM4yLFjVhpGJHx)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',ggzjQfBhqdOYNE+'مسلسلات بدون جلب ملفات','XTREAM_SERIES_GROUPS',285,'','','','',KRge5I0ov8BM4yLFjVhpGJHx)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',ggzjQfBhqdOYNE+'مسلسلات مصنفة بلا ترتيب'+lmDKLTA2eqIU814H76RBgPtywh,'VOD_SERIES_GROUPED',233,'','','','',KRge5I0ov8BM4yLFjVhpGJHx)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',ggzjQfBhqdOYNE+'مسلسلات مصنفة مرتبة'+lmDKLTA2eqIU814H76RBgPtywh,'VOD_SERIES_GROUPED_SORTED',233,'','','','',KRge5I0ov8BM4yLFjVhpGJHx)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',ggzjQfBhqdOYNE+'فيديوهات بلا ترتيب'+lmDKLTA2eqIU814H76RBgPtywh,'VOD_ORIGINAL_GROUPED',233,'','','','',KRge5I0ov8BM4yLFjVhpGJHx)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',ggzjQfBhqdOYNE+'فيديوهات مصنفة من القسم'+lmDKLTA2eqIU814H76RBgPtywh,'VOD_FROM_GROUP_SORTED',233,'','','','',KRge5I0ov8BM4yLFjVhpGJHx)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',ggzjQfBhqdOYNE+'فيديوهات مصنفة من الاسم'+lmDKLTA2eqIU814H76RBgPtywh,'VOD_FROM_NAME_SORTED',233,'','','','',KRge5I0ov8BM4yLFjVhpGJHx)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',ggzjQfBhqdOYNE+'فيديوهات مجهولة بلا ترتيب'+lmDKLTA2eqIU814H76RBgPtywh,'VOD_UNKNOWN_GROUPED',233,'','','','',KRge5I0ov8BM4yLFjVhpGJHx)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',ggzjQfBhqdOYNE+'فيديوهات مجهولة مرتبة'+lmDKLTA2eqIU814H76RBgPtywh,'VOD_UNKNOWN_GROUPED_SORTED',233,'','','','',KRge5I0ov8BM4yLFjVhpGJHx)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',ggzjQfBhqdOYNE+'برامج القنوات (جدول فقط)'+lmDKLTA2eqIU814H76RBgPtywh,'LIVE_EPG_GROUPED_SORTED',233,'','','','',KRge5I0ov8BM4yLFjVhpGJHx)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',ggzjQfBhqdOYNE+'أرشيف القنوات للأيام الماضية'+lmDKLTA2eqIU814H76RBgPtywh,'LIVE_TIMESHIFT_GROUPED_SORTED',233,'','','','',KRge5I0ov8BM4yLFjVhpGJHx)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',ggzjQfBhqdOYNE+'أرشيف برامج القنوات للأيام الماضية'+lmDKLTA2eqIU814H76RBgPtywh,'LIVE_ARCHIVED_GROUPED_SORTED',233,'','','','',KRge5I0ov8BM4yLFjVhpGJHx)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link',ggzjQfBhqdOYNE+'إضافة أو تغيير اشتراك'+lmDKLTA2eqIU814H76RBgPtywh,'',231,'','','','',KRge5I0ov8BM4yLFjVhpGJHx)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link',ggzjQfBhqdOYNE+'جلب ملفات'+lmDKLTA2eqIU814H76RBgPtywh,'',232,'','','','',KRge5I0ov8BM4yLFjVhpGJHx)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link',ggzjQfBhqdOYNE+'مسح ملفات'+lmDKLTA2eqIU814H76RBgPtywh,'',237,'','','','',KRge5I0ov8BM4yLFjVhpGJHx)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link',ggzjQfBhqdOYNE+'فحص اشتراك'+lmDKLTA2eqIU814H76RBgPtywh,'',236,'','','','',KRge5I0ov8BM4yLFjVhpGJHx)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link',ggzjQfBhqdOYNE+'عدد فيديوهات'+lmDKLTA2eqIU814H76RBgPtywh,'',281,'','','','',KRge5I0ov8BM4yLFjVhpGJHx)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link',ggzjQfBhqdOYNE+'Referer تغيير'+lmDKLTA2eqIU814H76RBgPtywh,'',286,'','','','',KRge5I0ov8BM4yLFjVhpGJHx)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link',ggzjQfBhqdOYNE+'User-Agent تغيير'+lmDKLTA2eqIU814H76RBgPtywh,'',283,'','','','',KRge5I0ov8BM4yLFjVhpGJHx)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link',ggzjQfBhqdOYNE+'استخدم السيرفر الأسرع'+lmDKLTA2eqIU814H76RBgPtywh,'',282,'','','','',KRge5I0ov8BM4yLFjVhpGJHx)
	return
def hSReUdq5l2oVmPc(j4OBPfZchRSD1FI,hQbe2Mlty3LrBixvd7mSg=True):
	MmbXp7rFy6ZkVwDiTl0Yd,iiwCDvBuGqFRJAUlmQok = False,''
	oXy71hNHqDOmGvpMeiSwF,GE9Rq4NlDCVLvbkyWnMXO = '',''
	xSMZTKVEpYdOtDLeb0j287mGH1hQJw,zqu2Z0UAlGn8hMVg6EY,oWBNIzOb9umU8yKAnQ,OSXxZcFAmD5pyouftzJ,BwbvnC70tPIdqJX = Ys9i82ha4yo1PjDZVz(j4OBPfZchRSD1FI)
	if OSXxZcFAmD5pyouftzJ=='': return False,'',''
	LM6unUr13ZYpOfPRkNXHE = zEDoGS5jrWMIJl(j4OBPfZchRSD1FI)
	if xSMZTKVEpYdOtDLeb0j287mGH1hQJw:
		JgLvsu6wx9n3VbQhk7KXylHm = mORwgTnXBdQ7iCSHKf(SToQEHqGtMnAlFbCz4wxBDuOsmW7,'GET',xSMZTKVEpYdOtDLeb0j287mGH1hQJw,'',LM6unUr13ZYpOfPRkNXHE,False,'','IPTV-CHECK_ACCOUNT-1st')
		qUWIbEBP2tlNaSL = JgLvsu6wx9n3VbQhk7KXylHm.content
		if JgLvsu6wx9n3VbQhk7KXylHm.succeeded:
			cbE5MYPVv3GNHCjZ7dte6,m8qxcYpJ5ybRiVlBTPhAQ,Sqpw5Ifa32xF,HFxLnPi25JTB9o7uIAO6V,YXtZpKonIkfs34WwHyxaTr2UQ = 0,0,'','',''
			try:
				KoZpQRdBiPcAIFh9C = dWsa2A0O4o5BYiqGXhyKEbM('dict',qUWIbEBP2tlNaSL)
				iiwCDvBuGqFRJAUlmQok = KoZpQRdBiPcAIFh9C['user_info']['status']
				MmbXp7rFy6ZkVwDiTl0Yd = True
				Sqpw5Ifa32xF = KoZpQRdBiPcAIFh9C['server_info']['time_now']
			except: pass
			if Sqpw5Ifa32xF:
				try:
					uQ4ngSVo6BXrKMsDz9hxtLY = KBxPW9cX8dqtaUDG.strptime(Sqpw5Ifa32xF,'%Y.%m.%d %H:%M:%S')
					cbE5MYPVv3GNHCjZ7dte6 = int(KBxPW9cX8dqtaUDG.mktime(uQ4ngSVo6BXrKMsDz9hxtLY))
					m8qxcYpJ5ybRiVlBTPhAQ = int(SGB7KzblUa4gCZD1srqc-cbE5MYPVv3GNHCjZ7dte6)
					m8qxcYpJ5ybRiVlBTPhAQ = int((m8qxcYpJ5ybRiVlBTPhAQ+900)/1800)*1800
				except: pass
				try:
					uQ4ngSVo6BXrKMsDz9hxtLY = KBxPW9cX8dqtaUDG.localtime(int(KoZpQRdBiPcAIFh9C['user_info']['created_at']))
					HFxLnPi25JTB9o7uIAO6V = KBxPW9cX8dqtaUDG.strftime('%Y.%m.%d %H:%M:%S',uQ4ngSVo6BXrKMsDz9hxtLY)
				except: pass
				try:
					uQ4ngSVo6BXrKMsDz9hxtLY = KBxPW9cX8dqtaUDG.localtime(int(KoZpQRdBiPcAIFh9C['user_info']['exp_date']))
					YXtZpKonIkfs34WwHyxaTr2UQ = KBxPW9cX8dqtaUDG.strftime('%Y.%m.%d %H:%M:%S',uQ4ngSVo6BXrKMsDz9hxtLY)
				except: pass
			bLEBi8IO7uU2x3htYDdVq95.setSetting('av.iptv.timestamp_'+j4OBPfZchRSD1FI,str(SGB7KzblUa4gCZD1srqc))
			bLEBi8IO7uU2x3htYDdVq95.setSetting('av.iptv.timediff_'+j4OBPfZchRSD1FI,str(m8qxcYpJ5ybRiVlBTPhAQ))
			try:
				iSOrGaR6YVJvyhLDUX1Mdxq = '"server_info":'+qUWIbEBP2tlNaSL.split('"server_info":')[1]
				iSOrGaR6YVJvyhLDUX1Mdxq = iSOrGaR6YVJvyhLDUX1Mdxq.replace(':',': ').replace(',',', ').replace('}}','}')
				D6DAcYCmJg = My7Dwqvs6bfGNSIgX.findall('"url": "(.*?)", "port": "(.*?)"',iSOrGaR6YVJvyhLDUX1Mdxq,My7Dwqvs6bfGNSIgX.DOTALL)
				oXy71hNHqDOmGvpMeiSwF,GE9Rq4NlDCVLvbkyWnMXO = D6DAcYCmJg[0]
			except: MmbXp7rFy6ZkVwDiTl0Yd = False
			if MmbXp7rFy6ZkVwDiTl0Yd and hQbe2Mlty3LrBixvd7mSg:
				max = KoZpQRdBiPcAIFh9C['user_info']['max_connections']
				DDlhbXVNMejzaGBcYH5WC8J4TAi = KoZpQRdBiPcAIFh9C['user_info']['active_cons']
				JNkog9yBK5Sb = KoZpQRdBiPcAIFh9C['user_info']['is_trial']
				B8Sa0LAs36RMp1 = xSMZTKVEpYdOtDLeb0j287mGH1hQJw.split('?',1)
				mR4VLhryYT2koGU6iBX = 'URL:  [COLOR FFC89008]'+xSMZTKVEpYdOtDLeb0j287mGH1hQJw+'[/COLOR]'
				mR4VLhryYT2koGU6iBX += '\n\nStatus:  '+'[COLOR FFC89008]'+iiwCDvBuGqFRJAUlmQok+'[/COLOR]'
				mR4VLhryYT2koGU6iBX += '\nTrial:    '+'[COLOR FFC89008]'+str(JNkog9yBK5Sb=='1')+'[/COLOR]'
				mR4VLhryYT2koGU6iBX += '\nCreated  At:  '+'[COLOR FFC89008]'+HFxLnPi25JTB9o7uIAO6V+'[/COLOR]'
				mR4VLhryYT2koGU6iBX += '\nExpiry Date:  '+'[COLOR FFC89008]'+YXtZpKonIkfs34WwHyxaTr2UQ+'[/COLOR]'
				mR4VLhryYT2koGU6iBX += '\nConnections   ( Active / Maximum ) :  '+'[COLOR FFC89008]'+DDlhbXVNMejzaGBcYH5WC8J4TAi+' / '+max+'[/COLOR]'
				mR4VLhryYT2koGU6iBX += '\nAllowed Outputs:   '+'[COLOR FFC89008]'+" , ".join(KoZpQRdBiPcAIFh9C['user_info']['allowed_output_formats'])+'[/COLOR]'
				mR4VLhryYT2koGU6iBX += '\n\n'+iSOrGaR6YVJvyhLDUX1Mdxq
				if iiwCDvBuGqFRJAUlmQok=='Active': S3KjEaY4lGZDnRFugP0('الاشتراك يعمل بدون مشاكل',mR4VLhryYT2koGU6iBX)
				else: S3KjEaY4lGZDnRFugP0('يبدو أن هناك مشكلة في الاشتراك',mR4VLhryYT2koGU6iBX)
	if xSMZTKVEpYdOtDLeb0j287mGH1hQJw and MmbXp7rFy6ZkVwDiTl0Yd and iiwCDvBuGqFRJAUlmQok=='Active':
		Lmj1pfQk63XdoeH('NOTICE','.  Checking IPTV URL   [ IPTV account is OK ]   [ '+xSMZTKVEpYdOtDLeb0j287mGH1hQJw+' ]')
		a5MrRBdG4wpAYmej0ZgUyh = True
	else:
		Lmj1pfQk63XdoeH('ERROR_LINES','Checking IPTV URL   [ Does not work ]   [ '+xSMZTKVEpYdOtDLeb0j287mGH1hQJw+' ]')
		if hQbe2Mlty3LrBixvd7mSg: ZIOHgA3z0TBR('','','فحص اشتراك ـIPTV','رابط اشتراك ـIPTV الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـIPTV وقم بإضافة رابط ـIPTV جديد أو قم بإصلاح الرابط القديم')
		a5MrRBdG4wpAYmej0ZgUyh = False
	return a5MrRBdG4wpAYmej0ZgUyh,oXy71hNHqDOmGvpMeiSwF,GE9Rq4NlDCVLvbkyWnMXO
def TJZvpKG2we(j4OBPfZchRSD1FI,ZKDblGPfQpu5XJvaBH08wC6t9,wRMeQljgZBqCKPm,qqLsbNxWJOdyeP7,hQbe2Mlty3LrBixvd7mSg=True):
	if not qqLsbNxWJOdyeP7: qqLsbNxWJOdyeP7 = '1'
	if not p13ciNHPqwljuY5KQIWfD6EOm(j4OBPfZchRSD1FI,hQbe2Mlty3LrBixvd7mSg): return
	byZ0dns5FPL4xBEXQgO7NwUCaH16 = MaVX8uHeBbmr3UYl(j4OBPfZchRSD1FI,ZKDblGPfQpu5XJvaBH08wC6t9)
	ccR9Mij6hCEuAJp8lVgxzWSXQ = zPgNsqpJInt(byZ0dns5FPL4xBEXQgO7NwUCaH16,'list',ZKDblGPfQpu5XJvaBH08wC6t9,wRMeQljgZBqCKPm)
	IuxVP8B9b5aKmNQ2MlchDoGJLdW = int(qqLsbNxWJOdyeP7)*100
	hIfxLy01wqHeAcTkVDlE5jCFMPzGv = IuxVP8B9b5aKmNQ2MlchDoGJLdW-100
	for HMdmFA6wzOC0GEoa9rlt27biPn,fUNpjldoZaw76vOe,SCakygtHx0AUXbO3emswB9F8,XSP02RovU3ChBsHIZyDzuiA in ccR9Mij6hCEuAJp8lVgxzWSXQ[hIfxLy01wqHeAcTkVDlE5jCFMPzGv:IuxVP8B9b5aKmNQ2MlchDoGJLdW]:
		t03SHjW6B7NGuerzpwnCOYqi = ('GROUPED' in ZKDblGPfQpu5XJvaBH08wC6t9 or ZKDblGPfQpu5XJvaBH08wC6t9=='ALL')
		vbFMHLmiWwsQylXp8n1SE5j = ('GROUPED' not in ZKDblGPfQpu5XJvaBH08wC6t9 and ZKDblGPfQpu5XJvaBH08wC6t9!='ALL')
		if t03SHjW6B7NGuerzpwnCOYqi or vbFMHLmiWwsQylXp8n1SE5j:
			if   'ARCHIVED'  in ZKDblGPfQpu5XJvaBH08wC6t9: xx4viQhaOu6r0.append(['folder',ggzjQfBhqdOYNE+fUNpjldoZaw76vOe,SCakygtHx0AUXbO3emswB9F8,238,XSP02RovU3ChBsHIZyDzuiA,'','ARCHIVED','',{'folder':j4OBPfZchRSD1FI}])
			elif 'EPG' 		 in ZKDblGPfQpu5XJvaBH08wC6t9: xx4viQhaOu6r0.append(['folder',ggzjQfBhqdOYNE+fUNpjldoZaw76vOe,SCakygtHx0AUXbO3emswB9F8,238,XSP02RovU3ChBsHIZyDzuiA,'','FULL_EPG','',{'folder':j4OBPfZchRSD1FI}])
			elif 'TIMESHIFT' in ZKDblGPfQpu5XJvaBH08wC6t9: xx4viQhaOu6r0.append(['folder',ggzjQfBhqdOYNE+fUNpjldoZaw76vOe,SCakygtHx0AUXbO3emswB9F8,238,XSP02RovU3ChBsHIZyDzuiA,'','TIMESHIFT','',{'folder':j4OBPfZchRSD1FI}])
			elif 'LIVE' 	 in ZKDblGPfQpu5XJvaBH08wC6t9: xx4viQhaOu6r0.append(['live',ggzjQfBhqdOYNE+fUNpjldoZaw76vOe,SCakygtHx0AUXbO3emswB9F8,235,XSP02RovU3ChBsHIZyDzuiA,'','',HMdmFA6wzOC0GEoa9rlt27biPn,{'folder':j4OBPfZchRSD1FI}])
			else: xx4viQhaOu6r0.append(['video',ggzjQfBhqdOYNE+fUNpjldoZaw76vOe,SCakygtHx0AUXbO3emswB9F8,235,XSP02RovU3ChBsHIZyDzuiA,'','','',{'folder':j4OBPfZchRSD1FI}])
	c2PYZqmOTMsHF = len(ccR9Mij6hCEuAJp8lVgxzWSXQ)
	ORiJ0ZCPYdkgTrEq3fwFXusIjS(j4OBPfZchRSD1FI,qqLsbNxWJOdyeP7,ZKDblGPfQpu5XJvaBH08wC6t9,234,c2PYZqmOTMsHF,wRMeQljgZBqCKPm)
	return
def rnjNdgD2cBKOF7MpUWQPvo(NYQJxSf3dobi8MsOmHelBI9):
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link',NYQJxSf3dobi8MsOmHelBI9+'هذه القائمة إما فارغة أو غير موجودة','',9999)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link',NYQJxSf3dobi8MsOmHelBI9+'أو الخدمة غير موجودة في اشتراكك','',9999)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link',NYQJxSf3dobi8MsOmHelBI9+'أو رابط IPTVـ الذي أنت أضفته غير صحيح','',9999)
	return
def um1OcGXaBWrP(j4OBPfZchRSD1FI,ZKDblGPfQpu5XJvaBH08wC6t9,wRMeQljgZBqCKPm,qqLsbNxWJOdyeP7,vpoIlR7HkV='',hQbe2Mlty3LrBixvd7mSg=True):
	if not qqLsbNxWJOdyeP7: qqLsbNxWJOdyeP7 = '1'
	NYQJxSf3dobi8MsOmHelBI9 = ggzjQfBhqdOYNE
	if not p13ciNHPqwljuY5KQIWfD6EOm(j4OBPfZchRSD1FI,hQbe2Mlty3LrBixvd7mSg): return False
	if '__SERIES__' in wRMeQljgZBqCKPm: dxPOCsV4rXS1aAMJ0ck8uy,hx8TSjV9Xl0Z = wRMeQljgZBqCKPm.split('__SERIES__')
	else: dxPOCsV4rXS1aAMJ0ck8uy,hx8TSjV9Xl0Z = wRMeQljgZBqCKPm,''
	byZ0dns5FPL4xBEXQgO7NwUCaH16 = MaVX8uHeBbmr3UYl(j4OBPfZchRSD1FI,ZKDblGPfQpu5XJvaBH08wC6t9)
	FsJxpOHaYEcNqGeDk05M3PI4hf = zPgNsqpJInt(byZ0dns5FPL4xBEXQgO7NwUCaH16,'list',ZKDblGPfQpu5XJvaBH08wC6t9,'__GROUPS__')
	if not FsJxpOHaYEcNqGeDk05M3PI4hf: return False
	sHUfri8A2xtDy5BeRvX4wJMQ9Z3 = []
	for D8fi02QU6oqce9E5jXZGrP1AbYWLC4,XSP02RovU3ChBsHIZyDzuiA in FsJxpOHaYEcNqGeDk05M3PI4hf:
		if vpoIlR7HkV:
			if '__SERIES__' in D8fi02QU6oqce9E5jXZGrP1AbYWLC4: NYQJxSf3dobi8MsOmHelBI9 = 'SERIES'
			elif '!!__UNKNOWN__!!' in D8fi02QU6oqce9E5jXZGrP1AbYWLC4: NYQJxSf3dobi8MsOmHelBI9 = 'UNKNOWN'
			elif 'LIVE' in ZKDblGPfQpu5XJvaBH08wC6t9: NYQJxSf3dobi8MsOmHelBI9 = 'LIVE'
			else: NYQJxSf3dobi8MsOmHelBI9 = 'VIDEOS'
			NYQJxSf3dobi8MsOmHelBI9 = ',[COLOR FFC89008]'+NYQJxSf3dobi8MsOmHelBI9+': [/COLOR]'
		if '__SERIES__' in D8fi02QU6oqce9E5jXZGrP1AbYWLC4: RLrNZpz9thqBK,JDm9duXPaMoFE = D8fi02QU6oqce9E5jXZGrP1AbYWLC4.split('__SERIES__')
		else: RLrNZpz9thqBK,JDm9duXPaMoFE = D8fi02QU6oqce9E5jXZGrP1AbYWLC4,''
		if not wRMeQljgZBqCKPm:
			if RLrNZpz9thqBK in sHUfri8A2xtDy5BeRvX4wJMQ9Z3: continue
			sHUfri8A2xtDy5BeRvX4wJMQ9Z3.append(RLrNZpz9thqBK)
			if 'RANDOM' in vpoIlR7HkV: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',NYQJxSf3dobi8MsOmHelBI9+RLrNZpz9thqBK,ZKDblGPfQpu5XJvaBH08wC6t9,167,'','1',D8fi02QU6oqce9E5jXZGrP1AbYWLC4,'',{'folder':j4OBPfZchRSD1FI})
			elif '__SERIES__' in D8fi02QU6oqce9E5jXZGrP1AbYWLC4: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',NYQJxSf3dobi8MsOmHelBI9+RLrNZpz9thqBK,ZKDblGPfQpu5XJvaBH08wC6t9,233,'','1',D8fi02QU6oqce9E5jXZGrP1AbYWLC4,'',{'folder':j4OBPfZchRSD1FI})
			else: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',NYQJxSf3dobi8MsOmHelBI9+RLrNZpz9thqBK,ZKDblGPfQpu5XJvaBH08wC6t9,234,'','1',D8fi02QU6oqce9E5jXZGrP1AbYWLC4,'',{'folder':j4OBPfZchRSD1FI})
		elif '__SERIES__' in D8fi02QU6oqce9E5jXZGrP1AbYWLC4 and RLrNZpz9thqBK==dxPOCsV4rXS1aAMJ0ck8uy:
			if JDm9duXPaMoFE in sHUfri8A2xtDy5BeRvX4wJMQ9Z3: continue
			sHUfri8A2xtDy5BeRvX4wJMQ9Z3.append(JDm9duXPaMoFE)
			if 'RANDOM' in vpoIlR7HkV: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',NYQJxSf3dobi8MsOmHelBI9+JDm9duXPaMoFE,ZKDblGPfQpu5XJvaBH08wC6t9,167,'','1',D8fi02QU6oqce9E5jXZGrP1AbYWLC4,'',{'folder':j4OBPfZchRSD1FI})
			else: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',NYQJxSf3dobi8MsOmHelBI9+JDm9duXPaMoFE,ZKDblGPfQpu5XJvaBH08wC6t9,234,XSP02RovU3ChBsHIZyDzuiA,'1',D8fi02QU6oqce9E5jXZGrP1AbYWLC4,'',{'folder':j4OBPfZchRSD1FI})
	xx4viQhaOu6r0[:] = sorted(xx4viQhaOu6r0,reverse=False,key=lambda S2igRNm4wsYJqv7FVWxa06A: S2igRNm4wsYJqv7FVWxa06A[1].lower())
	if not vpoIlR7HkV:
		IuxVP8B9b5aKmNQ2MlchDoGJLdW = int(qqLsbNxWJOdyeP7)*100
		hIfxLy01wqHeAcTkVDlE5jCFMPzGv = IuxVP8B9b5aKmNQ2MlchDoGJLdW-100
		c2PYZqmOTMsHF = len(xx4viQhaOu6r0)
		xx4viQhaOu6r0[:] = xx4viQhaOu6r0[hIfxLy01wqHeAcTkVDlE5jCFMPzGv:IuxVP8B9b5aKmNQ2MlchDoGJLdW]
		ORiJ0ZCPYdkgTrEq3fwFXusIjS(j4OBPfZchRSD1FI,qqLsbNxWJOdyeP7,ZKDblGPfQpu5XJvaBH08wC6t9,233,c2PYZqmOTMsHF,wRMeQljgZBqCKPm)
	return True
def zzmKM5dNIpgCt4Z6VwUa8LsfD(j4OBPfZchRSD1FI,SCakygtHx0AUXbO3emswB9F8,vhkUACqjSPf8tQmcLW):
	if not p13ciNHPqwljuY5KQIWfD6EOm(j4OBPfZchRSD1FI,True): return
	LM6unUr13ZYpOfPRkNXHE = zEDoGS5jrWMIJl(j4OBPfZchRSD1FI)
	cbE5MYPVv3GNHCjZ7dte6 = bLEBi8IO7uU2x3htYDdVq95.getSetting('av.iptv.timestamp_'+j4OBPfZchRSD1FI)
	if not cbE5MYPVv3GNHCjZ7dte6 or SGB7KzblUa4gCZD1srqc-int(cbE5MYPVv3GNHCjZ7dte6)>24*p6l2Pum7aFtrhUHgXTE5w0n:
		a5MrRBdG4wpAYmej0ZgUyh,oXy71hNHqDOmGvpMeiSwF,GE9Rq4NlDCVLvbkyWnMXO = hSReUdq5l2oVmPc(j4OBPfZchRSD1FI,False)
		if not a5MrRBdG4wpAYmej0ZgUyh: return
	m8qxcYpJ5ybRiVlBTPhAQ = int(bLEBi8IO7uU2x3htYDdVq95.getSetting('av.iptv.timediff_'+j4OBPfZchRSD1FI))
	oWBNIzOb9umU8yKAnQ = bLEBi8IO7uU2x3htYDdVq95.getSetting('av.iptv.server_'+j4OBPfZchRSD1FI)
	OSXxZcFAmD5pyouftzJ = bLEBi8IO7uU2x3htYDdVq95.getSetting('av.iptv.username_'+j4OBPfZchRSD1FI)
	BwbvnC70tPIdqJX = bLEBi8IO7uU2x3htYDdVq95.getSetting('av.iptv.password_'+j4OBPfZchRSD1FI)
	itzsNSxv6JF0YZWnjyc74lD = SCakygtHx0AUXbO3emswB9F8.split('/')
	rrKPOUI5dA6nEqyMJi = itzsNSxv6JF0YZWnjyc74lD[-1].replace('.ts','').replace('.m3u8','')
	if vhkUACqjSPf8tQmcLW=='SHORT_EPG': fayLEHlMJbrQOWemi = 'get_short_epg'
	else: fayLEHlMJbrQOWemi = 'get_simple_data_table'
	xSMZTKVEpYdOtDLeb0j287mGH1hQJw,zqu2Z0UAlGn8hMVg6EY,oWBNIzOb9umU8yKAnQ,OSXxZcFAmD5pyouftzJ,BwbvnC70tPIdqJX = Ys9i82ha4yo1PjDZVz(j4OBPfZchRSD1FI)
	if not OSXxZcFAmD5pyouftzJ: return
	QLaMl5X4Zzy = xSMZTKVEpYdOtDLeb0j287mGH1hQJw+'&action='+fayLEHlMJbrQOWemi+'&stream_id='+rrKPOUI5dA6nEqyMJi
	qUWIbEBP2tlNaSL = rYVbUm3On2PqBNL9E(SToQEHqGtMnAlFbCz4wxBDuOsmW7,QLaMl5X4Zzy,'',LM6unUr13ZYpOfPRkNXHE,'','IPTV-EPG_ITEMS-2nd')
	S27uaC4ZR1HB = dWsa2A0O4o5BYiqGXhyKEbM('dict',qUWIbEBP2tlNaSL)
	H94HrswiFcNdm = S27uaC4ZR1HB['epg_listings']
	y5j4Gh8VpT0eIdgBZFDOzcKN = []
	if vhkUACqjSPf8tQmcLW in ['ARCHIVED','TIMESHIFT']:
		for KoZpQRdBiPcAIFh9C in H94HrswiFcNdm:
			if KoZpQRdBiPcAIFh9C['has_archive']==1:
				y5j4Gh8VpT0eIdgBZFDOzcKN.append(KoZpQRdBiPcAIFh9C)
				if vhkUACqjSPf8tQmcLW in ['TIMESHIFT']: break
		if not y5j4Gh8VpT0eIdgBZFDOzcKN: return
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link',ggzjQfBhqdOYNE+'[COLOR FFC89008]الملفات الأولي بهذه القائمة قد لا تعمل[/COLOR]','',9999)
		if vhkUACqjSPf8tQmcLW in ['TIMESHIFT']:
			daFxClhpoAUfRBTiVts53MZkSIyg7H = 2
			tKD67qX8YUM23ynA4uo9mjZizk = daFxClhpoAUfRBTiVts53MZkSIyg7H*p6l2Pum7aFtrhUHgXTE5w0n
			y5j4Gh8VpT0eIdgBZFDOzcKN = []
			bRTkQ1fErsShiAomLW = int(int(KoZpQRdBiPcAIFh9C['start_timestamp'])/tKD67qX8YUM23ynA4uo9mjZizk)*tKD67qX8YUM23ynA4uo9mjZizk
			hkxoIdwn0g3t4up68ES = SGB7KzblUa4gCZD1srqc+tKD67qX8YUM23ynA4uo9mjZizk
			XaA2NQ7elIGymxb0u = int((hkxoIdwn0g3t4up68ES-bRTkQ1fErsShiAomLW)/p6l2Pum7aFtrhUHgXTE5w0n)
			for e3tYvEisRnJpNc5 in range(XaA2NQ7elIGymxb0u):
				if e3tYvEisRnJpNc5>=6:
					if e3tYvEisRnJpNc5%daFxClhpoAUfRBTiVts53MZkSIyg7H!=0: continue
					lqTyzjAbofHw1tiaFh7rO = tKD67qX8YUM23ynA4uo9mjZizk
				else: lqTyzjAbofHw1tiaFh7rO = tKD67qX8YUM23ynA4uo9mjZizk//2
				T34MYWCVFvfeX9OI = bRTkQ1fErsShiAomLW+e3tYvEisRnJpNc5*p6l2Pum7aFtrhUHgXTE5w0n
				KoZpQRdBiPcAIFh9C = {}
				KoZpQRdBiPcAIFh9C['title'] = ''
				uQ4ngSVo6BXrKMsDz9hxtLY = KBxPW9cX8dqtaUDG.localtime(T34MYWCVFvfeX9OI-m8qxcYpJ5ybRiVlBTPhAQ-p6l2Pum7aFtrhUHgXTE5w0n)
				KoZpQRdBiPcAIFh9C['start'] = KBxPW9cX8dqtaUDG.strftime('%Y.%m.%d %H:%M:%S',uQ4ngSVo6BXrKMsDz9hxtLY)
				KoZpQRdBiPcAIFh9C['start_timestamp'] = str(T34MYWCVFvfeX9OI)
				KoZpQRdBiPcAIFh9C['stop_timestamp'] = str(T34MYWCVFvfeX9OI+lqTyzjAbofHw1tiaFh7rO)
				y5j4Gh8VpT0eIdgBZFDOzcKN.append(KoZpQRdBiPcAIFh9C)
	elif vhkUACqjSPf8tQmcLW in ['SHORT_EPG','FULL_EPG']: y5j4Gh8VpT0eIdgBZFDOzcKN = H94HrswiFcNdm
	if vhkUACqjSPf8tQmcLW=='FULL_EPG' and len(y5j4Gh8VpT0eIdgBZFDOzcKN)>0:
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link',ggzjQfBhqdOYNE+'[COLOR FFC89008]هذه قائمة برامج القنوات (جدول فقط)ـ[/COLOR]','',9999)
	oR98ftizMm7cUaLVNknZO3P = []
	XSP02RovU3ChBsHIZyDzuiA = tUXmK5PeEH9SDq.getInfoLabel('ListItem.Icon')
	for KoZpQRdBiPcAIFh9C in y5j4Gh8VpT0eIdgBZFDOzcKN:
		fUNpjldoZaw76vOe = NfzkjQicS24ZYLMWuXFRwV5Ea7.b64decode(KoZpQRdBiPcAIFh9C['title'])
		if BLz7m2RkNrxXQwy1cGAp: fUNpjldoZaw76vOe = fUNpjldoZaw76vOe.decode('utf8')
		T34MYWCVFvfeX9OI = int(KoZpQRdBiPcAIFh9C['start_timestamp'])
		zSR4dtA1fiW = int(KoZpQRdBiPcAIFh9C['stop_timestamp'])
		lvd3soLJY15IuQO = str(int((zSR4dtA1fiW-T34MYWCVFvfeX9OI+59)/60))
		MAX0f7i5DhjbmH63gtoBKlVws = KoZpQRdBiPcAIFh9C['start'].replace(' ',':')
		uQ4ngSVo6BXrKMsDz9hxtLY = KBxPW9cX8dqtaUDG.localtime(T34MYWCVFvfeX9OI-p6l2Pum7aFtrhUHgXTE5w0n)
		TcqtwdPsho87WCajN = KBxPW9cX8dqtaUDG.strftime('%H:%M',uQ4ngSVo6BXrKMsDz9hxtLY)
		eWBATYhtHmKVXpGrQlucs2jvxMC = KBxPW9cX8dqtaUDG.strftime('%a',uQ4ngSVo6BXrKMsDz9hxtLY)
		if vhkUACqjSPf8tQmcLW=='SHORT_EPG': fUNpjldoZaw76vOe = '[COLOR FFFFFF00]'+TcqtwdPsho87WCajN+' ـ '+fUNpjldoZaw76vOe+'[/COLOR]'
		elif vhkUACqjSPf8tQmcLW=='TIMESHIFT': fUNpjldoZaw76vOe = eWBATYhtHmKVXpGrQlucs2jvxMC+' '+TcqtwdPsho87WCajN+' ('+lvd3soLJY15IuQO+'min)'
		else: fUNpjldoZaw76vOe = eWBATYhtHmKVXpGrQlucs2jvxMC+' '+TcqtwdPsho87WCajN+' ('+lvd3soLJY15IuQO+'min)   '+fUNpjldoZaw76vOe+' ـ'
		if vhkUACqjSPf8tQmcLW in ['ARCHIVED','FULL_EPG','TIMESHIFT']:
			u62r1l5VdAE3aiQ = oWBNIzOb9umU8yKAnQ+'/timeshift/'+OSXxZcFAmD5pyouftzJ+'/'+BwbvnC70tPIdqJX+'/'+lvd3soLJY15IuQO+'/'+MAX0f7i5DhjbmH63gtoBKlVws+'/'+rrKPOUI5dA6nEqyMJi+'.m3u8'
			if vhkUACqjSPf8tQmcLW=='FULL_EPG': VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link',ggzjQfBhqdOYNE+fUNpjldoZaw76vOe,u62r1l5VdAE3aiQ,9999,XSP02RovU3ChBsHIZyDzuiA,'','','',{'folder':j4OBPfZchRSD1FI})
			else: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',ggzjQfBhqdOYNE+fUNpjldoZaw76vOe,u62r1l5VdAE3aiQ,235,XSP02RovU3ChBsHIZyDzuiA,'','','',{'folder':j4OBPfZchRSD1FI})
		oR98ftizMm7cUaLVNknZO3P.append(fUNpjldoZaw76vOe)
	if vhkUACqjSPf8tQmcLW=='SHORT_EPG' and oR98ftizMm7cUaLVNknZO3P: llJQ4HBprjoEI0MzTUayqhb = QdvjYklOtMC4PBGRFq26giphZL1Kr(oR98ftizMm7cUaLVNknZO3P)
	return oR98ftizMm7cUaLVNknZO3P
def SeMRTfP9WOs(j4OBPfZchRSD1FI):
	if not p13ciNHPqwljuY5KQIWfD6EOm(j4OBPfZchRSD1FI,True): return
	oWBNIzOb9umU8yKAnQ,v0OAeRPSNZr4TJ6fsVlkdKnjMIXp,LMDf9GP431WXUlBtNZowv2as = '',0,0
	a5MrRBdG4wpAYmej0ZgUyh,oXy71hNHqDOmGvpMeiSwF,GE9Rq4NlDCVLvbkyWnMXO = hSReUdq5l2oVmPc(j4OBPfZchRSD1FI,False)
	if a5MrRBdG4wpAYmej0ZgUyh:
		KKFLSRTkBhPXE = t0KUXWFosQBprcveO4Ra(oXy71hNHqDOmGvpMeiSwF)
		v0OAeRPSNZr4TJ6fsVlkdKnjMIXp = r8D6ZdSgBKywTfJ39qlYsk1Qp0VnU(KKFLSRTkBhPXE[0],int(GE9Rq4NlDCVLvbkyWnMXO))
		byZ0dns5FPL4xBEXQgO7NwUCaH16 = MaVX8uHeBbmr3UYl(j4OBPfZchRSD1FI,'LIVE_GROUPED')
		KKy4Hz7QfmbuspErFdkUcj3JT = zPgNsqpJInt(byZ0dns5FPL4xBEXQgO7NwUCaH16,'list','LIVE_GROUPED')
		ccR9Mij6hCEuAJp8lVgxzWSXQ = zPgNsqpJInt(byZ0dns5FPL4xBEXQgO7NwUCaH16,'list','LIVE_GROUPED',KKy4Hz7QfmbuspErFdkUcj3JT[1])
		SCakygtHx0AUXbO3emswB9F8 = ccR9Mij6hCEuAJp8lVgxzWSXQ[0][2]
		SUhorjy03vIbglwkq9pEtn5iMTuGWf = My7Dwqvs6bfGNSIgX.findall('://(.*?)/',SCakygtHx0AUXbO3emswB9F8,My7Dwqvs6bfGNSIgX.DOTALL)
		SUhorjy03vIbglwkq9pEtn5iMTuGWf = SUhorjy03vIbglwkq9pEtn5iMTuGWf[0]
		if ':' in SUhorjy03vIbglwkq9pEtn5iMTuGWf: eYw8yMWDtjs,FFuSdD4K1CsgEPU9xQwn2 = SUhorjy03vIbglwkq9pEtn5iMTuGWf.split(':')
		else: eYw8yMWDtjs,FFuSdD4K1CsgEPU9xQwn2 = SUhorjy03vIbglwkq9pEtn5iMTuGWf,'80'
		UFActqiIMG7wdhSmoxl = t0KUXWFosQBprcveO4Ra(eYw8yMWDtjs)
		LMDf9GP431WXUlBtNZowv2as = r8D6ZdSgBKywTfJ39qlYsk1Qp0VnU(UFActqiIMG7wdhSmoxl[0],int(FFuSdD4K1CsgEPU9xQwn2))
	if v0OAeRPSNZr4TJ6fsVlkdKnjMIXp and LMDf9GP431WXUlBtNZowv2as:
		mR4VLhryYT2koGU6iBX = 'هل تريد استخدام السيرفر الأصلي أم السيرفر الأسرع ؟!!'
		mR4VLhryYT2koGU6iBX += '\n\n'+'وقت ضائع في السيرفر الأصلي'+'\n'+str(int(LMDf9GP431WXUlBtNZowv2as*1000))+' ملي ثانية'
		mR4VLhryYT2koGU6iBX += '\n\n'+'وقت ضائع في السيرفر البديل'+'\n'+str(int(v0OAeRPSNZr4TJ6fsVlkdKnjMIXp*1000))+' ملي ثانية'
		UHx5YQ3FogO87NB0mrXRthi = mmwySO1P4jnKz5('center','السيرفر الأصلي','السيرفر الأسرع','رسالة من المبرمج',mR4VLhryYT2koGU6iBX)
		if UHx5YQ3FogO87NB0mrXRthi==1 and v0OAeRPSNZr4TJ6fsVlkdKnjMIXp<LMDf9GP431WXUlBtNZowv2as: oWBNIzOb9umU8yKAnQ = oXy71hNHqDOmGvpMeiSwF+':'+GE9Rq4NlDCVLvbkyWnMXO
	else: ZIOHgA3z0TBR('','','رسالة من المبرمج','البرنامج لم يجد السيرفر البديل')
	bLEBi8IO7uU2x3htYDdVq95.setSetting('av.iptv.server_'+j4OBPfZchRSD1FI,oWBNIzOb9umU8yKAnQ)
	return
def HDxCnPKFhITpZmOsA4a0UL6(j4OBPfZchRSD1FI,SCakygtHx0AUXbO3emswB9F8,dM2SkzwnVKc3FUPDl9BE):
	jCV8QOIUZH071DYxNq = bLEBi8IO7uU2x3htYDdVq95.getSetting('av.iptv.useragent_'+j4OBPfZchRSD1FI)
	zC43IR2gNTQ68pqUOZlPSJADox7 = bLEBi8IO7uU2x3htYDdVq95.getSetting('av.iptv.referer_'+j4OBPfZchRSD1FI)
	if jCV8QOIUZH071DYxNq or zC43IR2gNTQ68pqUOZlPSJADox7:
		SCakygtHx0AUXbO3emswB9F8 += '|'
		if jCV8QOIUZH071DYxNq: SCakygtHx0AUXbO3emswB9F8 += '&User-Agent='+jCV8QOIUZH071DYxNq
		if zC43IR2gNTQ68pqUOZlPSJADox7: SCakygtHx0AUXbO3emswB9F8 += '&Referer='+zC43IR2gNTQ68pqUOZlPSJADox7
		SCakygtHx0AUXbO3emswB9F8 = SCakygtHx0AUXbO3emswB9F8.replace('|&','|')
	pAUzQ5MElLDR0gxym12f6o = bLEBi8IO7uU2x3htYDdVq95.getSetting('av.iptv.server_'+j4OBPfZchRSD1FI)
	if pAUzQ5MElLDR0gxym12f6o:
		k0z6GS2TBXrd1clHEathpqRvDmxL = My7Dwqvs6bfGNSIgX.findall('://(.*?)/',SCakygtHx0AUXbO3emswB9F8,My7Dwqvs6bfGNSIgX.DOTALL)
		SCakygtHx0AUXbO3emswB9F8 = SCakygtHx0AUXbO3emswB9F8.replace(k0z6GS2TBXrd1clHEathpqRvDmxL[0],pAUzQ5MElLDR0gxym12f6o)
	B0xcwKkMQ16mpSFRaVHPTzuhUZngLq(SCakygtHx0AUXbO3emswB9F8,DaZhLqOIc24x6wv57YUlF3NgCzpGeX,dM2SkzwnVKc3FUPDl9BE)
	return
def bc0Beo1pNISzfKu(j4OBPfZchRSD1FI):
	ZIOHgA3z0TBR('','','رسالة من المبرمج','تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـIPTV أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـIPTV تحتاج ـUser-Agent خاص')
	jCV8QOIUZH071DYxNq = bLEBi8IO7uU2x3htYDdVq95.getSetting('av.iptv.useragent_'+j4OBPfZchRSD1FI)
	SWGCusFOdEQcbR = mmwySO1P4jnKz5('center','استخدام الأصلي','تعديل القديم',jCV8QOIUZH071DYxNq,'هذا هو ـUser-Agent المستخدم حاليا مع ـIPTV الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـIPTV ؟!')
	if SWGCusFOdEQcbR==1: jCV8QOIUZH071DYxNq = ViKAIsLurq83RSENayxWb('أكتب ـIPTV User-Agent جديد',jCV8QOIUZH071DYxNq,True)
	else: jCV8QOIUZH071DYxNq = 'Unknown'
	if jCV8QOIUZH071DYxNq==' ':
		ZIOHgA3z0TBR('','','رسالة من المبرمج','غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	SWGCusFOdEQcbR = mmwySO1P4jnKz5('center','','',jCV8QOIUZH071DYxNq,'هل تريد استخدام هذا ـUser-Agent بدلا من  القديم ؟')
	if SWGCusFOdEQcbR!=1:
		ZIOHgA3z0TBR('','','رسالة من المبرمج','تم الإلغاء')
		return
	bLEBi8IO7uU2x3htYDdVq95.setSetting('av.iptv.useragent_'+j4OBPfZchRSD1FI,jCV8QOIUZH071DYxNq)
	WPjF76nHMOvQUA9Z(j4OBPfZchRSD1FI)
	return
def Mg76s9J8pfxWc(j4OBPfZchRSD1FI):
	ZIOHgA3z0TBR('','','رسالة من المبرمج','تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـIPTV أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـIPTV تحتاج ـReferer خاص')
	zC43IR2gNTQ68pqUOZlPSJADox7 = bLEBi8IO7uU2x3htYDdVq95.getSetting('av.iptv.referer_'+j4OBPfZchRSD1FI)
	SWGCusFOdEQcbR = mmwySO1P4jnKz5('center','استخدام الأصلي','تعديل القديم',zC43IR2gNTQ68pqUOZlPSJADox7,'هذا هو ـReferer المستخدم حاليا مع ـIPTV الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـIPTV ؟!')
	if SWGCusFOdEQcbR==1: zC43IR2gNTQ68pqUOZlPSJADox7 = ViKAIsLurq83RSENayxWb('أكتب ـIPTV Referer جديد',zC43IR2gNTQ68pqUOZlPSJADox7,True)
	else: zC43IR2gNTQ68pqUOZlPSJADox7 = ''
	if zC43IR2gNTQ68pqUOZlPSJADox7==' ':
		ZIOHgA3z0TBR('','','رسالة من المبرمج','غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	SWGCusFOdEQcbR = mmwySO1P4jnKz5('center','','',zC43IR2gNTQ68pqUOZlPSJADox7,'هل تريد استخدام هذا ـReferer بدلا من  القديم ؟')
	if SWGCusFOdEQcbR!=1:
		ZIOHgA3z0TBR('','','رسالة من المبرمج','تم الإلغاء')
		return
	bLEBi8IO7uU2x3htYDdVq95.setSetting('av.iptv.referer_'+j4OBPfZchRSD1FI,zC43IR2gNTQ68pqUOZlPSJADox7)
	WPjF76nHMOvQUA9Z(j4OBPfZchRSD1FI)
	return
def Ys9i82ha4yo1PjDZVz(j4OBPfZchRSD1FI,q67PrpY48UAzItiBLOc5W0=''):
	if not q67PrpY48UAzItiBLOc5W0: q67PrpY48UAzItiBLOc5W0 = bLEBi8IO7uU2x3htYDdVq95.getSetting('av.iptv.url_'+j4OBPfZchRSD1FI)
	oWBNIzOb9umU8yKAnQ = ooq2D9xF8ZLpPBs(q67PrpY48UAzItiBLOc5W0,'url')
	OSXxZcFAmD5pyouftzJ = My7Dwqvs6bfGNSIgX.findall('username=(.*?)&',q67PrpY48UAzItiBLOc5W0+'&',My7Dwqvs6bfGNSIgX.DOTALL)
	BwbvnC70tPIdqJX = My7Dwqvs6bfGNSIgX.findall('password=(.*?)&',q67PrpY48UAzItiBLOc5W0+'&',My7Dwqvs6bfGNSIgX.DOTALL)
	if not OSXxZcFAmD5pyouftzJ or not BwbvnC70tPIdqJX:
		ZIOHgA3z0TBR('','','فحص اشتراك ـIPTV','رابط اشتراك ـIPTV الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـIPTV وقم بإضافة رابط ـIPTV جديد أو قم بإصلاح الرابط القديم')
		return '','','','',''
	OSXxZcFAmD5pyouftzJ = OSXxZcFAmD5pyouftzJ[0]
	BwbvnC70tPIdqJX = BwbvnC70tPIdqJX[0]
	xSMZTKVEpYdOtDLeb0j287mGH1hQJw = oWBNIzOb9umU8yKAnQ+'/player_api.php?username='+OSXxZcFAmD5pyouftzJ+'&password='+BwbvnC70tPIdqJX
	zqu2Z0UAlGn8hMVg6EY = oWBNIzOb9umU8yKAnQ+'/get.php?username='+OSXxZcFAmD5pyouftzJ+'&password='+BwbvnC70tPIdqJX+'&type=m3u_plus'
	return xSMZTKVEpYdOtDLeb0j287mGH1hQJw,zqu2Z0UAlGn8hMVg6EY,oWBNIzOb9umU8yKAnQ,OSXxZcFAmD5pyouftzJ,BwbvnC70tPIdqJX
def I8IbXxwnoHfFzimR9SeK3(j4OBPfZchRSD1FI,pczyJPq4ledxXY8BamoQLFHgiOht=''):
	W2WxQMiK8NsSmGuXt9vbAVHC0crE = pczyJPq4ledxXY8BamoQLFHgiOht.replace('/','_').replace(':','_').replace('.','_')
	W2WxQMiK8NsSmGuXt9vbAVHC0crE = W2WxQMiK8NsSmGuXt9vbAVHC0crE.replace('?','_').replace('=','_').replace('&','_')
	W2WxQMiK8NsSmGuXt9vbAVHC0crE = XXRtDhYvWb35qnLBxIri7ScNUks0.path.join(IjYiO4u9HGmgw,W2WxQMiK8NsSmGuXt9vbAVHC0crE).strip('.m3u')+'.m3u'
	return W2WxQMiK8NsSmGuXt9vbAVHC0crE
def JZeiyxc3z1HX7Ej(j4OBPfZchRSD1FI):
	vpAeWEGd6208ubOh91 = bLEBi8IO7uU2x3htYDdVq95.getSetting('av.iptv.url_'+j4OBPfZchRSD1FI)
	C4qABEczpIHJ6LKM = True
	if vpAeWEGd6208ubOh91:
		SWGCusFOdEQcbR = Uu0ZdNAP1BWc28lR('center','كتابة جديد','تعديل القديم','مسح القديم','الرابط الحالي هو:','[COLOR FFC89008]'+vpAeWEGd6208ubOh91+'[/COLOR]'+'\n\n هذا هو رابط ـIPTV المسجل في البرنامج ... هل تريد تعديله أم تريد كتابة رابط جديد ؟!')
		if SWGCusFOdEQcbR==-1: return
		elif SWGCusFOdEQcbR==0: vpAeWEGd6208ubOh91 = ''
		elif SWGCusFOdEQcbR==2:
			SWGCusFOdEQcbR = mmwySO1P4jnKz5('center','','','رسالة من المبرمج','هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if SWGCusFOdEQcbR in [-1,0]: return
			ZIOHgA3z0TBR('','','رسالة من المبرمج','تم مسح الرابط')
			C4qABEczpIHJ6LKM = False
			eVCEAqoQtGdFfWO8v1U6 = ''
	if C4qABEczpIHJ6LKM:
		eVCEAqoQtGdFfWO8v1U6 = ViKAIsLurq83RSENayxWb('اكتب رابط ـIPTV كاملا',vpAeWEGd6208ubOh91)
		eVCEAqoQtGdFfWO8v1U6 = eVCEAqoQtGdFfWO8v1U6.strip(' ')
		if not eVCEAqoQtGdFfWO8v1U6:
			SWGCusFOdEQcbR = mmwySO1P4jnKz5('center','','','رسالة من المبرمج','لقد قمت بإدخال رابط فارغ .. هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if SWGCusFOdEQcbR in [-1,0]: return
			ZIOHgA3z0TBR('','','رسالة من المبرمج','تم مسح الرابط')
	else:
		xSMZTKVEpYdOtDLeb0j287mGH1hQJw,zqu2Z0UAlGn8hMVg6EY,oWBNIzOb9umU8yKAnQ,OSXxZcFAmD5pyouftzJ,BwbvnC70tPIdqJX = Ys9i82ha4yo1PjDZVz(j4OBPfZchRSD1FI,eVCEAqoQtGdFfWO8v1U6)
		if not OSXxZcFAmD5pyouftzJ: return
		mR4VLhryYT2koGU6iBX = 'هذه المعلومات تم أخذها من رابط ـIPTV الذي انت كتبته . هل تريد استخدامها ؟!\n'
		mR4VLhryYT2koGU6iBX += '\n[COLOR FFFFFF00]'+oWBNIzOb9umU8yKAnQ+'[/COLOR]عنوان السيرفر: '
		mR4VLhryYT2koGU6iBX += '\n[COLOR FFFFFF00]'+OSXxZcFAmD5pyouftzJ+'[/COLOR]اسم المستخدم: '
		mR4VLhryYT2koGU6iBX += '\n[COLOR FFFFFF00]'+BwbvnC70tPIdqJX+'[/COLOR]كلمة السر: '
		SWGCusFOdEQcbR = mmwySO1P4jnKz5('right','','','الرابط الجديد هو:','[COLOR FFC89008]'+eVCEAqoQtGdFfWO8v1U6+'[/COLOR]'+'\n\n'+mR4VLhryYT2koGU6iBX)
		if SWGCusFOdEQcbR!=1:
			ZIOHgA3z0TBR('','','رسالة من المبرمج','تم الإلغاء')
			return
	bLEBi8IO7uU2x3htYDdVq95.setSetting('av.iptv.url_'+j4OBPfZchRSD1FI,eVCEAqoQtGdFfWO8v1U6)
	bLEBi8IO7uU2x3htYDdVq95.setSetting('av.iptv.timestamp_'+j4OBPfZchRSD1FI,'')
	bLEBi8IO7uU2x3htYDdVq95.setSetting('av.iptv.timediff_'+j4OBPfZchRSD1FI,'')
	jCV8QOIUZH071DYxNq = bLEBi8IO7uU2x3htYDdVq95.getSetting('av.iptv.useragent_'+j4OBPfZchRSD1FI)
	if not jCV8QOIUZH071DYxNq: bLEBi8IO7uU2x3htYDdVq95.setSetting('av.iptv.useragent_'+j4OBPfZchRSD1FI,'Unknown')
	NOybur6YKUn4VFpg2lImE8ZLHeqfj = mmwySO1P4jnKz5('center','','','',eVCEAqoQtGdFfWO8v1U6+'\n\nتم تغير رابط اشتراك ـIPTV إلى هذا الرابط الجديد ... هل تريد فحص هذا الرابط الآن ؟')
	if NOybur6YKUn4VFpg2lImE8ZLHeqfj==1: a5MrRBdG4wpAYmej0ZgUyh,oXy71hNHqDOmGvpMeiSwF,GE9Rq4NlDCVLvbkyWnMXO = hSReUdq5l2oVmPc(j4OBPfZchRSD1FI,True)
	WPjF76nHMOvQUA9Z(j4OBPfZchRSD1FI)
	return
def USvb764Nr1LCJMexGdh0oO(Zb6XVxojEdJCGWBYnFm9qIpu,mm0wnvDRYLMoJ1b6FUOQlau,B9K5doTWwq0l2rvI,LbYUu2oFzCcHD18VxG,hhjauwSbpDy53z0Gc4HT,rBLZ3RjCdy8KWk5t,zqu2Z0UAlGn8hMVg6EY):
	ccR9Mij6hCEuAJp8lVgxzWSXQ,VVse9qN0ZXhfRKkyQAM = [],[]
	giefXKo0OAEhPnLGUb6qYjM = ['.avi','.mp4','.mkv','.mp3','.webm','.aac']
	for mK69jMeAkOl1I3tF5HGPJRgr in Zb6XVxojEdJCGWBYnFm9qIpu:
		if rBLZ3RjCdy8KWk5t%473==0:
			M3QI1bliHdj7poRFV2OG(LbYUu2oFzCcHD18VxG,40+int(10*rBLZ3RjCdy8KWk5t/hhjauwSbpDy53z0Gc4HT),'قراءة الفيديوهات','الفيديو رقم:-',str(rBLZ3RjCdy8KWk5t)+' / '+str(hhjauwSbpDy53z0Gc4HT))
			if LbYUu2oFzCcHD18VxG.iscanceled():
				LbYUu2oFzCcHD18VxG.close()
				return None,None,None
		SCakygtHx0AUXbO3emswB9F8 = My7Dwqvs6bfGNSIgX.findall('^(.*?)\n+((http|https|rtmp).*?)$',mK69jMeAkOl1I3tF5HGPJRgr,My7Dwqvs6bfGNSIgX.DOTALL)
		if SCakygtHx0AUXbO3emswB9F8:
			mK69jMeAkOl1I3tF5HGPJRgr,SCakygtHx0AUXbO3emswB9F8,GpRJb7qFgjW = SCakygtHx0AUXbO3emswB9F8[0]
			SCakygtHx0AUXbO3emswB9F8 = SCakygtHx0AUXbO3emswB9F8.replace('\n','')
			mK69jMeAkOl1I3tF5HGPJRgr = mK69jMeAkOl1I3tF5HGPJRgr.replace('\n','')
		else:
			VVse9qN0ZXhfRKkyQAM.append({'line':mK69jMeAkOl1I3tF5HGPJRgr})
			continue
		KFrNEilZTxm6qW3OH,HMdmFA6wzOC0GEoa9rlt27biPn,D8fi02QU6oqce9E5jXZGrP1AbYWLC4,fUNpjldoZaw76vOe,dM2SkzwnVKc3FUPDl9BE,bKpBIHvwm0EPOizCf = {},'','','','',False
		try:
			mK69jMeAkOl1I3tF5HGPJRgr,fUNpjldoZaw76vOe = mK69jMeAkOl1I3tF5HGPJRgr.rsplit('",',1)
			mK69jMeAkOl1I3tF5HGPJRgr = mK69jMeAkOl1I3tF5HGPJRgr+'"'
		except:
			try: mK69jMeAkOl1I3tF5HGPJRgr,fUNpjldoZaw76vOe = mK69jMeAkOl1I3tF5HGPJRgr.rsplit('1,',1)
			except: fUNpjldoZaw76vOe = ''
		KFrNEilZTxm6qW3OH['url'] = SCakygtHx0AUXbO3emswB9F8
		SFI2AxOa1G6Pg9X = My7Dwqvs6bfGNSIgX.findall(' (.*?)="(.*?)"',mK69jMeAkOl1I3tF5HGPJRgr,My7Dwqvs6bfGNSIgX.DOTALL)
		for S2igRNm4wsYJqv7FVWxa06A,ZWdUEIjMmA2OCi in SFI2AxOa1G6Pg9X:
			S2igRNm4wsYJqv7FVWxa06A = S2igRNm4wsYJqv7FVWxa06A.replace('"','').strip(' ')
			KFrNEilZTxm6qW3OH[S2igRNm4wsYJqv7FVWxa06A] = ZWdUEIjMmA2OCi.strip(' ')
		o1T34YfuvW6g0EmRsOr = list(KFrNEilZTxm6qW3OH.keys())
		if not fUNpjldoZaw76vOe:
			if 'name' in o1T34YfuvW6g0EmRsOr and KFrNEilZTxm6qW3OH['name']: fUNpjldoZaw76vOe = KFrNEilZTxm6qW3OH['name']
		KFrNEilZTxm6qW3OH['title'] = fUNpjldoZaw76vOe.strip(' ').replace('  ',' ').replace('  ',' ')
		if 'logo' in o1T34YfuvW6g0EmRsOr:
			KFrNEilZTxm6qW3OH['img'] = KFrNEilZTxm6qW3OH['logo']
			del KFrNEilZTxm6qW3OH['logo']
		else: KFrNEilZTxm6qW3OH['img'] = ''
		if 'group' in o1T34YfuvW6g0EmRsOr and KFrNEilZTxm6qW3OH['group']: D8fi02QU6oqce9E5jXZGrP1AbYWLC4 = KFrNEilZTxm6qW3OH['group']
		if any(WoFrX46wzbCNp18 in SCakygtHx0AUXbO3emswB9F8.lower() for WoFrX46wzbCNp18 in giefXKo0OAEhPnLGUb6qYjM):
			bKpBIHvwm0EPOizCf = True if 'm3u' not in SCakygtHx0AUXbO3emswB9F8 else False
		if bKpBIHvwm0EPOizCf or '__SERIES__' in D8fi02QU6oqce9E5jXZGrP1AbYWLC4 or '__MOVIES__' in D8fi02QU6oqce9E5jXZGrP1AbYWLC4:
			dM2SkzwnVKc3FUPDl9BE = 'VOD'
			if '__SERIES__' in D8fi02QU6oqce9E5jXZGrP1AbYWLC4: dM2SkzwnVKc3FUPDl9BE = dM2SkzwnVKc3FUPDl9BE+'_SERIES'
			elif '__MOVIES__' in D8fi02QU6oqce9E5jXZGrP1AbYWLC4: dM2SkzwnVKc3FUPDl9BE = dM2SkzwnVKc3FUPDl9BE+'_MOVIES'
			else: dM2SkzwnVKc3FUPDl9BE = dM2SkzwnVKc3FUPDl9BE+'_UNKNOWN'
			D8fi02QU6oqce9E5jXZGrP1AbYWLC4 = D8fi02QU6oqce9E5jXZGrP1AbYWLC4.replace('__SERIES__','').replace('__MOVIES__','')
		else:
			dM2SkzwnVKc3FUPDl9BE = 'LIVE'
			if fUNpjldoZaw76vOe in mm0wnvDRYLMoJ1b6FUOQlau: HMdmFA6wzOC0GEoa9rlt27biPn = HMdmFA6wzOC0GEoa9rlt27biPn+'_EPG'
			if fUNpjldoZaw76vOe in B9K5doTWwq0l2rvI: HMdmFA6wzOC0GEoa9rlt27biPn = HMdmFA6wzOC0GEoa9rlt27biPn+'_ARCHIVED'
			if not D8fi02QU6oqce9E5jXZGrP1AbYWLC4: dM2SkzwnVKc3FUPDl9BE = dM2SkzwnVKc3FUPDl9BE+'_UNKNOWN'
			else: dM2SkzwnVKc3FUPDl9BE = dM2SkzwnVKc3FUPDl9BE+HMdmFA6wzOC0GEoa9rlt27biPn
		D8fi02QU6oqce9E5jXZGrP1AbYWLC4 = D8fi02QU6oqce9E5jXZGrP1AbYWLC4.strip(' ').replace('  ',' ').replace('  ',' ')
		if 'LIVE_UNKNOWN' in dM2SkzwnVKc3FUPDl9BE: D8fi02QU6oqce9E5jXZGrP1AbYWLC4 = '!!__UNKNOWN_LIVE__!!'
		elif 'VOD_UNKNOWN' in dM2SkzwnVKc3FUPDl9BE: D8fi02QU6oqce9E5jXZGrP1AbYWLC4 = '!!__UNKNOWN_VOD__!!'
		elif 'VOD_SERIES' in dM2SkzwnVKc3FUPDl9BE:
			JCERjZiU96DhG3QBf7d0SxX1Nb = My7Dwqvs6bfGNSIgX.findall('(.*?) [Ss]\d+ +[Ee]\d+',KFrNEilZTxm6qW3OH['title'],My7Dwqvs6bfGNSIgX.DOTALL)
			if JCERjZiU96DhG3QBf7d0SxX1Nb: JCERjZiU96DhG3QBf7d0SxX1Nb = JCERjZiU96DhG3QBf7d0SxX1Nb[0]
			else: JCERjZiU96DhG3QBf7d0SxX1Nb = '!!__UNKNOWN_SERIES__!!'
			D8fi02QU6oqce9E5jXZGrP1AbYWLC4 = D8fi02QU6oqce9E5jXZGrP1AbYWLC4+'__SERIES__'+JCERjZiU96DhG3QBf7d0SxX1Nb
		if 'id' in o1T34YfuvW6g0EmRsOr: del KFrNEilZTxm6qW3OH['id']
		if 'ID' in o1T34YfuvW6g0EmRsOr: del KFrNEilZTxm6qW3OH['ID']
		if 'name' in o1T34YfuvW6g0EmRsOr: del KFrNEilZTxm6qW3OH['name']
		fUNpjldoZaw76vOe = KFrNEilZTxm6qW3OH['title']
		fUNpjldoZaw76vOe = tW06wVMpReHfnj3KgzT2va(fUNpjldoZaw76vOe)
		fUNpjldoZaw76vOe = OQUDcFd9CI8z47rywSuRX(fUNpjldoZaw76vOe)
		YYsquXxDLVOIF,D8fi02QU6oqce9E5jXZGrP1AbYWLC4 = KKAxZsWT95Mr0C(D8fi02QU6oqce9E5jXZGrP1AbYWLC4)
		bNHfp729xRsQYcy4evZAToqzMUIj,fUNpjldoZaw76vOe = KKAxZsWT95Mr0C(fUNpjldoZaw76vOe)
		KFrNEilZTxm6qW3OH['type'] = dM2SkzwnVKc3FUPDl9BE
		KFrNEilZTxm6qW3OH['context'] = HMdmFA6wzOC0GEoa9rlt27biPn
		KFrNEilZTxm6qW3OH['group'] = D8fi02QU6oqce9E5jXZGrP1AbYWLC4.upper()
		KFrNEilZTxm6qW3OH['title'] = fUNpjldoZaw76vOe.upper()
		KFrNEilZTxm6qW3OH['country'] = bNHfp729xRsQYcy4evZAToqzMUIj.upper()
		KFrNEilZTxm6qW3OH['language'] = YYsquXxDLVOIF.upper()
		ccR9Mij6hCEuAJp8lVgxzWSXQ.append(KFrNEilZTxm6qW3OH)
		rBLZ3RjCdy8KWk5t += 1
	return ccR9Mij6hCEuAJp8lVgxzWSXQ,rBLZ3RjCdy8KWk5t,VVse9qN0ZXhfRKkyQAM
def OQUDcFd9CI8z47rywSuRX(fUNpjldoZaw76vOe):
	fUNpjldoZaw76vOe = fUNpjldoZaw76vOe.replace('  ',' ').replace('  ',' ').replace('  ',' ')
	fUNpjldoZaw76vOe = fUNpjldoZaw76vOe.replace('||','|').replace('___',':').replace('--','-')
	fUNpjldoZaw76vOe = fUNpjldoZaw76vOe.replace('[[','[').replace(']]',']')
	fUNpjldoZaw76vOe = fUNpjldoZaw76vOe.replace('((','(').replace('))',')')
	fUNpjldoZaw76vOe = fUNpjldoZaw76vOe.replace('<<','<').replace('>>','>')
	fUNpjldoZaw76vOe = fUNpjldoZaw76vOe.strip(' ')
	return fUNpjldoZaw76vOe
def GGhxTXEHpIDoLRlb49v(AAJLSzYakZ8PlhBC1um,LbYUu2oFzCcHD18VxG):
	IbkRW67mYFx8so = {}
	for QUcTSkXCYr7PuIonlVxL3fZJG20t6 in ffA7Cx1LygY6VFsJvUn4DidpcM9t: IbkRW67mYFx8so[QUcTSkXCYr7PuIonlVxL3fZJG20t6] = []
	hhjauwSbpDy53z0Gc4HT = len(AAJLSzYakZ8PlhBC1um)
	LaIBEhPFvzMiH = str(hhjauwSbpDy53z0Gc4HT)
	rBLZ3RjCdy8KWk5t = 0
	VVse9qN0ZXhfRKkyQAM = []
	for KFrNEilZTxm6qW3OH in AAJLSzYakZ8PlhBC1um:
		if rBLZ3RjCdy8KWk5t%873==0:
			M3QI1bliHdj7poRFV2OG(LbYUu2oFzCcHD18VxG,50+int(5*rBLZ3RjCdy8KWk5t/hhjauwSbpDy53z0Gc4HT),'تصنيف الفيديوهات الغير مرتبة','الفيديو رقم:-',str(rBLZ3RjCdy8KWk5t)+' / '+LaIBEhPFvzMiH)
			if LbYUu2oFzCcHD18VxG.iscanceled():
				LbYUu2oFzCcHD18VxG.close()
				return None,None
		D8fi02QU6oqce9E5jXZGrP1AbYWLC4,HMdmFA6wzOC0GEoa9rlt27biPn,fUNpjldoZaw76vOe,SCakygtHx0AUXbO3emswB9F8,XSP02RovU3ChBsHIZyDzuiA = KFrNEilZTxm6qW3OH['group'],KFrNEilZTxm6qW3OH['context'],KFrNEilZTxm6qW3OH['title'],KFrNEilZTxm6qW3OH['url'],KFrNEilZTxm6qW3OH['img']
		bNHfp729xRsQYcy4evZAToqzMUIj,YYsquXxDLVOIF,QUcTSkXCYr7PuIonlVxL3fZJG20t6 = KFrNEilZTxm6qW3OH['country'],KFrNEilZTxm6qW3OH['language'],KFrNEilZTxm6qW3OH['type']
		S91gAEnjBJU4 = (D8fi02QU6oqce9E5jXZGrP1AbYWLC4,HMdmFA6wzOC0GEoa9rlt27biPn,fUNpjldoZaw76vOe,SCakygtHx0AUXbO3emswB9F8,XSP02RovU3ChBsHIZyDzuiA)
		gHfeWp7z1JjnQA05CDwLZmRG68 = False
		if 'LIVE' in QUcTSkXCYr7PuIonlVxL3fZJG20t6:
			if 'UNKNOWN' in QUcTSkXCYr7PuIonlVxL3fZJG20t6: IbkRW67mYFx8so['LIVE_UNKNOWN_GROUPED'].append(S91gAEnjBJU4)
			elif 'LIVE' in QUcTSkXCYr7PuIonlVxL3fZJG20t6: IbkRW67mYFx8so['LIVE_GROUPED'].append(S91gAEnjBJU4)
			else: gHfeWp7z1JjnQA05CDwLZmRG68 = True
			IbkRW67mYFx8so['LIVE_ORIGINAL_GROUPED'].append(S91gAEnjBJU4)
		elif 'VOD' in QUcTSkXCYr7PuIonlVxL3fZJG20t6:
			if 'UNKNOWN' in QUcTSkXCYr7PuIonlVxL3fZJG20t6: IbkRW67mYFx8so['VOD_UNKNOWN_GROUPED'].append(S91gAEnjBJU4)
			elif 'MOVIES' in QUcTSkXCYr7PuIonlVxL3fZJG20t6: IbkRW67mYFx8so['VOD_MOVIES_GROUPED'].append(S91gAEnjBJU4)
			elif 'SERIES' in QUcTSkXCYr7PuIonlVxL3fZJG20t6: IbkRW67mYFx8so['VOD_SERIES_GROUPED'].append(S91gAEnjBJU4)
			else: gHfeWp7z1JjnQA05CDwLZmRG68 = True
			IbkRW67mYFx8so['VOD_ORIGINAL_GROUPED'].append(S91gAEnjBJU4)
		else: gHfeWp7z1JjnQA05CDwLZmRG68 = True
		if gHfeWp7z1JjnQA05CDwLZmRG68: VVse9qN0ZXhfRKkyQAM.append(KFrNEilZTxm6qW3OH)
		rBLZ3RjCdy8KWk5t += 1
	ccMroVIazkF0Ujf52lg = sorted(AAJLSzYakZ8PlhBC1um,reverse=False,key=lambda S2igRNm4wsYJqv7FVWxa06A: S2igRNm4wsYJqv7FVWxa06A['title'].lower())
	del AAJLSzYakZ8PlhBC1um
	LaIBEhPFvzMiH = str(hhjauwSbpDy53z0Gc4HT)
	rBLZ3RjCdy8KWk5t = 0
	for KFrNEilZTxm6qW3OH in ccMroVIazkF0Ujf52lg:
		rBLZ3RjCdy8KWk5t += 1
		if rBLZ3RjCdy8KWk5t%873==0:
			M3QI1bliHdj7poRFV2OG(LbYUu2oFzCcHD18VxG,55+int(5*rBLZ3RjCdy8KWk5t/hhjauwSbpDy53z0Gc4HT),'تصنيف الفيديوهات المرتبة','الفيديو رقم:-',str(rBLZ3RjCdy8KWk5t)+' / '+LaIBEhPFvzMiH)
			if LbYUu2oFzCcHD18VxG.iscanceled():
				LbYUu2oFzCcHD18VxG.close()
				return None,None
		QUcTSkXCYr7PuIonlVxL3fZJG20t6 = KFrNEilZTxm6qW3OH['type']
		D8fi02QU6oqce9E5jXZGrP1AbYWLC4,HMdmFA6wzOC0GEoa9rlt27biPn,fUNpjldoZaw76vOe,SCakygtHx0AUXbO3emswB9F8,XSP02RovU3ChBsHIZyDzuiA = KFrNEilZTxm6qW3OH['group'],KFrNEilZTxm6qW3OH['context'],KFrNEilZTxm6qW3OH['title'],KFrNEilZTxm6qW3OH['url'],KFrNEilZTxm6qW3OH['img']
		bNHfp729xRsQYcy4evZAToqzMUIj,YYsquXxDLVOIF = KFrNEilZTxm6qW3OH['country'],KFrNEilZTxm6qW3OH['language']
		E8XxHJkfyFgCPtK0e37q6hZUu1n = (D8fi02QU6oqce9E5jXZGrP1AbYWLC4,HMdmFA6wzOC0GEoa9rlt27biPn+'_TIMESHIFT',fUNpjldoZaw76vOe,SCakygtHx0AUXbO3emswB9F8,XSP02RovU3ChBsHIZyDzuiA)
		S91gAEnjBJU4 = (D8fi02QU6oqce9E5jXZGrP1AbYWLC4,HMdmFA6wzOC0GEoa9rlt27biPn,fUNpjldoZaw76vOe,SCakygtHx0AUXbO3emswB9F8,XSP02RovU3ChBsHIZyDzuiA)
		eV3fw2mqP4l6HjGEJs70 = (bNHfp729xRsQYcy4evZAToqzMUIj,HMdmFA6wzOC0GEoa9rlt27biPn,fUNpjldoZaw76vOe,SCakygtHx0AUXbO3emswB9F8,XSP02RovU3ChBsHIZyDzuiA)
		LETv5123VRNyPF8otfxaDskM = (YYsquXxDLVOIF,HMdmFA6wzOC0GEoa9rlt27biPn,fUNpjldoZaw76vOe,SCakygtHx0AUXbO3emswB9F8,XSP02RovU3ChBsHIZyDzuiA)
		if 'LIVE' in QUcTSkXCYr7PuIonlVxL3fZJG20t6:
			if 'UNKNOWN' in QUcTSkXCYr7PuIonlVxL3fZJG20t6: IbkRW67mYFx8so['LIVE_UNKNOWN_GROUPED_SORTED'].append(S91gAEnjBJU4)
			else: IbkRW67mYFx8so['LIVE_GROUPED_SORTED'].append(S91gAEnjBJU4)
			if 'EPG'		in QUcTSkXCYr7PuIonlVxL3fZJG20t6: IbkRW67mYFx8so['LIVE_EPG_GROUPED_SORTED'].append(S91gAEnjBJU4)
			if 'ARCHIVED'	in QUcTSkXCYr7PuIonlVxL3fZJG20t6: IbkRW67mYFx8so['LIVE_ARCHIVED_GROUPED_SORTED'].append(S91gAEnjBJU4)
			if 'ARCHIVED'	in QUcTSkXCYr7PuIonlVxL3fZJG20t6: IbkRW67mYFx8so['LIVE_TIMESHIFT_GROUPED_SORTED'].append(E8XxHJkfyFgCPtK0e37q6hZUu1n)
			IbkRW67mYFx8so['LIVE_FROM_NAME_SORTED'].append(eV3fw2mqP4l6HjGEJs70)
			IbkRW67mYFx8so['LIVE_FROM_GROUP_SORTED'].append(LETv5123VRNyPF8otfxaDskM)
		elif 'VOD' in QUcTSkXCYr7PuIonlVxL3fZJG20t6:
			if   'UNKNOWN'	in QUcTSkXCYr7PuIonlVxL3fZJG20t6: IbkRW67mYFx8so['VOD_UNKNOWN_GROUPED_SORTED'].append(S91gAEnjBJU4)
			elif 'MOVIES'	in QUcTSkXCYr7PuIonlVxL3fZJG20t6: IbkRW67mYFx8so['VOD_MOVIES_GROUPED_SORTED'].append(S91gAEnjBJU4)
			elif 'SERIES'	in QUcTSkXCYr7PuIonlVxL3fZJG20t6: IbkRW67mYFx8so['VOD_SERIES_GROUPED_SORTED'].append(S91gAEnjBJU4)
			IbkRW67mYFx8so['VOD_FROM_NAME_SORTED'].append(eV3fw2mqP4l6HjGEJs70)
			IbkRW67mYFx8so['VOD_FROM_GROUP_SORTED'].append(LETv5123VRNyPF8otfxaDskM)
	return IbkRW67mYFx8so,VVse9qN0ZXhfRKkyQAM
def KKAxZsWT95Mr0C(fUNpjldoZaw76vOe):
	if len(fUNpjldoZaw76vOe)<3: return fUNpjldoZaw76vOe,fUNpjldoZaw76vOe
	DPajMzNlqJyhY7gGrbXAtIV1oZHdw,NSLMwqf59OJtGclxDg1pdTjPXA4b = '',''
	uuhasSrTbWZ2YvJ1m0DM8eALw3 = fUNpjldoZaw76vOe
	p7hkDzix9jBZMevsqrcKtoAbROlyP5 = fUNpjldoZaw76vOe[:1]
	leyJbpVgHv27Ks1 = fUNpjldoZaw76vOe[1:]
	if   p7hkDzix9jBZMevsqrcKtoAbROlyP5=='(': NSLMwqf59OJtGclxDg1pdTjPXA4b = ')'
	elif p7hkDzix9jBZMevsqrcKtoAbROlyP5=='[': NSLMwqf59OJtGclxDg1pdTjPXA4b = ']'
	elif p7hkDzix9jBZMevsqrcKtoAbROlyP5=='<': NSLMwqf59OJtGclxDg1pdTjPXA4b = '>'
	elif p7hkDzix9jBZMevsqrcKtoAbROlyP5=='|': NSLMwqf59OJtGclxDg1pdTjPXA4b = '|'
	if NSLMwqf59OJtGclxDg1pdTjPXA4b and (NSLMwqf59OJtGclxDg1pdTjPXA4b in leyJbpVgHv27Ks1):
		hqRPo31Qn2XyEBWJsu,Hr0MJ1w3VD4gbZ2 = leyJbpVgHv27Ks1.split(NSLMwqf59OJtGclxDg1pdTjPXA4b,1)
		DPajMzNlqJyhY7gGrbXAtIV1oZHdw = hqRPo31Qn2XyEBWJsu
		uuhasSrTbWZ2YvJ1m0DM8eALw3 = p7hkDzix9jBZMevsqrcKtoAbROlyP5+hqRPo31Qn2XyEBWJsu+NSLMwqf59OJtGclxDg1pdTjPXA4b+' '+Hr0MJ1w3VD4gbZ2
	elif fUNpjldoZaw76vOe.count('|')>=2:
		hqRPo31Qn2XyEBWJsu,Hr0MJ1w3VD4gbZ2 = fUNpjldoZaw76vOe.split('|',1)
		DPajMzNlqJyhY7gGrbXAtIV1oZHdw = hqRPo31Qn2XyEBWJsu
		uuhasSrTbWZ2YvJ1m0DM8eALw3 = hqRPo31Qn2XyEBWJsu+' |'+Hr0MJ1w3VD4gbZ2
	else:
		NSLMwqf59OJtGclxDg1pdTjPXA4b = My7Dwqvs6bfGNSIgX.findall('^\w{2}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',fUNpjldoZaw76vOe,My7Dwqvs6bfGNSIgX.DOTALL)
		if not NSLMwqf59OJtGclxDg1pdTjPXA4b: NSLMwqf59OJtGclxDg1pdTjPXA4b = My7Dwqvs6bfGNSIgX.findall('^\w{3}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',fUNpjldoZaw76vOe,My7Dwqvs6bfGNSIgX.DOTALL)
		if not NSLMwqf59OJtGclxDg1pdTjPXA4b: NSLMwqf59OJtGclxDg1pdTjPXA4b = My7Dwqvs6bfGNSIgX.findall('^\w{4}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',fUNpjldoZaw76vOe,My7Dwqvs6bfGNSIgX.DOTALL)
		if NSLMwqf59OJtGclxDg1pdTjPXA4b:
			hqRPo31Qn2XyEBWJsu,Hr0MJ1w3VD4gbZ2 = fUNpjldoZaw76vOe.split(NSLMwqf59OJtGclxDg1pdTjPXA4b[0],1)
			DPajMzNlqJyhY7gGrbXAtIV1oZHdw = hqRPo31Qn2XyEBWJsu
			uuhasSrTbWZ2YvJ1m0DM8eALw3 = hqRPo31Qn2XyEBWJsu+' '+NSLMwqf59OJtGclxDg1pdTjPXA4b[0]+' '+Hr0MJ1w3VD4gbZ2
	uuhasSrTbWZ2YvJ1m0DM8eALw3 = uuhasSrTbWZ2YvJ1m0DM8eALw3.replace('   ',' ').replace('  ',' ')
	DPajMzNlqJyhY7gGrbXAtIV1oZHdw = DPajMzNlqJyhY7gGrbXAtIV1oZHdw.replace('  ',' ')
	if not DPajMzNlqJyhY7gGrbXAtIV1oZHdw: DPajMzNlqJyhY7gGrbXAtIV1oZHdw = '!!__UNKNOWN__!!'
	DPajMzNlqJyhY7gGrbXAtIV1oZHdw = DPajMzNlqJyhY7gGrbXAtIV1oZHdw.strip(' ')
	uuhasSrTbWZ2YvJ1m0DM8eALw3 = uuhasSrTbWZ2YvJ1m0DM8eALw3.strip(' ')
	return DPajMzNlqJyhY7gGrbXAtIV1oZHdw,uuhasSrTbWZ2YvJ1m0DM8eALw3
def zEDoGS5jrWMIJl(j4OBPfZchRSD1FI):
	LM6unUr13ZYpOfPRkNXHE = {}
	jCV8QOIUZH071DYxNq = bLEBi8IO7uU2x3htYDdVq95.getSetting('av.iptv.useragent_'+j4OBPfZchRSD1FI)
	if jCV8QOIUZH071DYxNq: LM6unUr13ZYpOfPRkNXHE['User-Agent'] = jCV8QOIUZH071DYxNq
	zC43IR2gNTQ68pqUOZlPSJADox7 = bLEBi8IO7uU2x3htYDdVq95.getSetting('av.iptv.referer_'+j4OBPfZchRSD1FI)
	if zC43IR2gNTQ68pqUOZlPSJADox7: LM6unUr13ZYpOfPRkNXHE['Referer'] = zC43IR2gNTQ68pqUOZlPSJADox7
	return LM6unUr13ZYpOfPRkNXHE
def tTEOCAkV4NMQXp6UrLi(j4OBPfZchRSD1FI):
	global LbYUu2oFzCcHD18VxG,IbkRW67mYFx8so,CLfYQic6q5jUETktNRG3SzA48sgm,AGVyjS159f8,Y9Ps5kzS7WINDxg1,KKy4Hz7QfmbuspErFdkUcj3JT,xLpGfsu1bw,nix9Ehv4bW,ssR4mW1pEluSM6Xzwhg
	xSMZTKVEpYdOtDLeb0j287mGH1hQJw,zqu2Z0UAlGn8hMVg6EY,oWBNIzOb9umU8yKAnQ,OSXxZcFAmD5pyouftzJ,BwbvnC70tPIdqJX = Ys9i82ha4yo1PjDZVz(j4OBPfZchRSD1FI)
	if not OSXxZcFAmD5pyouftzJ: return
	LM6unUr13ZYpOfPRkNXHE = zEDoGS5jrWMIJl(j4OBPfZchRSD1FI)
	UHx5YQ3FogO87NB0mrXRthi = mmwySO1P4jnKz5('center','','','رسالة من المبرمج','جلب ملفات ـIPTV جديدة قد تحتاج عدة دقائق . هل تريد أن تجلب الملفات الآن ؟')
	if UHx5YQ3FogO87NB0mrXRthi!=1: return
	W2WxQMiK8NsSmGuXt9vbAVHC0crE = veznPUcof0MuAIi73Sma.replace('___','_'+j4OBPfZchRSD1FI)
	if 1:
		a5MrRBdG4wpAYmej0ZgUyh,oXy71hNHqDOmGvpMeiSwF,GE9Rq4NlDCVLvbkyWnMXO = hSReUdq5l2oVmPc(j4OBPfZchRSD1FI,False)
		if not a5MrRBdG4wpAYmej0ZgUyh:
			ZIOHgA3z0TBR('','','رسالة من المبرمج','فشل بسحب ملفات ـIPTV . أحتمال رابط ـIPTV غير صحيح أو قديم أو لا يعمل .. علما أن هذه الخدمة تحتاج اشتراك مدفوع وصحيح ويجب أن تضيف رابط الاشتراك بنفسك للبرنامج باستخدام قائمة ـIPTV الموجودة بهذا البرنامج')
			if not zqu2Z0UAlGn8hMVg6EY: Lmj1pfQk63XdoeH('ERROR_LINES',Dwl0N6FKuVU8nB1mbisIrCzdO(DaZhLqOIc24x6wv57YUlF3NgCzpGeX)+'   No IPTV URL found to download IPTV files')
			else: Lmj1pfQk63XdoeH('ERROR_LINES',Dwl0N6FKuVU8nB1mbisIrCzdO(DaZhLqOIc24x6wv57YUlF3NgCzpGeX)+'   Failed to download IPTV files')
			return
		RKFW1Vk2a7D5s8Of6UE0crQXNgq = PKwAyEMig2N6eb(zqu2Z0UAlGn8hMVg6EY,LM6unUr13ZYpOfPRkNXHE,True)
		if not RKFW1Vk2a7D5s8Of6UE0crQXNgq: return
		open(W2WxQMiK8NsSmGuXt9vbAVHC0crE,'wb').write(RKFW1Vk2a7D5s8Of6UE0crQXNgq)
	else: RKFW1Vk2a7D5s8Of6UE0crQXNgq = open(W2WxQMiK8NsSmGuXt9vbAVHC0crE,'rb').read()
	if BLz7m2RkNrxXQwy1cGAp and RKFW1Vk2a7D5s8Of6UE0crQXNgq: RKFW1Vk2a7D5s8Of6UE0crQXNgq = RKFW1Vk2a7D5s8Of6UE0crQXNgq.decode('utf8')
	LbYUu2oFzCcHD18VxG = YYAhEtvLi5CnyHxIjJled3wWTO()
	LbYUu2oFzCcHD18VxG.create('جلب ملفات ـIPTV جديدة','')
	M3QI1bliHdj7poRFV2OG(LbYUu2oFzCcHD18VxG,15,'تنظيف الملف الرئيسي','')
	RKFW1Vk2a7D5s8Of6UE0crQXNgq = RKFW1Vk2a7D5s8Of6UE0crQXNgq.replace('"tvg-','" tvg-')
	RKFW1Vk2a7D5s8Of6UE0crQXNgq = RKFW1Vk2a7D5s8Of6UE0crQXNgq.replace('َ','').replace('ً','').replace('ُ','').replace('ٌ','')
	RKFW1Vk2a7D5s8Of6UE0crQXNgq = RKFW1Vk2a7D5s8Of6UE0crQXNgq.replace('ّ','').replace('ِ','').replace('ٍ','').replace('ْ','')
	RKFW1Vk2a7D5s8Of6UE0crQXNgq = RKFW1Vk2a7D5s8Of6UE0crQXNgq.replace('group-title=','group=').replace('tvg-','')
	B9K5doTWwq0l2rvI,mm0wnvDRYLMoJ1b6FUOQlau = [],[]
	M3QI1bliHdj7poRFV2OG(LbYUu2oFzCcHD18VxG,20,'جلب الملفات الثانوية','الملف رقم:-','1 / 3')
	if LbYUu2oFzCcHD18VxG.iscanceled():
		LbYUu2oFzCcHD18VxG.close()
		return
	SCakygtHx0AUXbO3emswB9F8 = xSMZTKVEpYdOtDLeb0j287mGH1hQJw+'&action=get_series_categories'
	JgLvsu6wx9n3VbQhk7KXylHm = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',SCakygtHx0AUXbO3emswB9F8,'',LM6unUr13ZYpOfPRkNXHE,'','','IPTV-CREATE_STREAMS-1st')
	qUWIbEBP2tlNaSL = JgLvsu6wx9n3VbQhk7KXylHm.content
	qUWIbEBP2tlNaSL = tW06wVMpReHfnj3KgzT2va(qUWIbEBP2tlNaSL)
	i0pSJT1xqjfr6vl2ae3NbXGQP = My7Dwqvs6bfGNSIgX.findall('category_name":"(.*?)"',qUWIbEBP2tlNaSL,My7Dwqvs6bfGNSIgX.DOTALL)
	del qUWIbEBP2tlNaSL
	for D8fi02QU6oqce9E5jXZGrP1AbYWLC4 in i0pSJT1xqjfr6vl2ae3NbXGQP:
		D8fi02QU6oqce9E5jXZGrP1AbYWLC4 = D8fi02QU6oqce9E5jXZGrP1AbYWLC4.replace('\/','/')
		if V8fmEML1b0PeaRZySnzh3H5J9: D8fi02QU6oqce9E5jXZGrP1AbYWLC4 = D8fi02QU6oqce9E5jXZGrP1AbYWLC4.decode('utf8').encode('utf8')
		RKFW1Vk2a7D5s8Of6UE0crQXNgq = RKFW1Vk2a7D5s8Of6UE0crQXNgq.replace('group="'+D8fi02QU6oqce9E5jXZGrP1AbYWLC4+'"','group="__SERIES__'+D8fi02QU6oqce9E5jXZGrP1AbYWLC4+'"')
	del i0pSJT1xqjfr6vl2ae3NbXGQP
	M3QI1bliHdj7poRFV2OG(LbYUu2oFzCcHD18VxG,25,'جلب الملفات الثانوية','الملف رقم:-','2 / 3')
	if LbYUu2oFzCcHD18VxG.iscanceled():
		LbYUu2oFzCcHD18VxG.close()
		return
	SCakygtHx0AUXbO3emswB9F8 = xSMZTKVEpYdOtDLeb0j287mGH1hQJw+'&action=get_vod_categories'
	JgLvsu6wx9n3VbQhk7KXylHm = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',SCakygtHx0AUXbO3emswB9F8,'',LM6unUr13ZYpOfPRkNXHE,'','','IPTV-CREATE_STREAMS-2nd')
	qUWIbEBP2tlNaSL = JgLvsu6wx9n3VbQhk7KXylHm.content
	qUWIbEBP2tlNaSL = tW06wVMpReHfnj3KgzT2va(qUWIbEBP2tlNaSL)
	YN3yPtLOeFIHiRaTnWVE6 = My7Dwqvs6bfGNSIgX.findall('category_name":"(.*?)"',qUWIbEBP2tlNaSL,My7Dwqvs6bfGNSIgX.DOTALL)
	del qUWIbEBP2tlNaSL
	for D8fi02QU6oqce9E5jXZGrP1AbYWLC4 in YN3yPtLOeFIHiRaTnWVE6:
		D8fi02QU6oqce9E5jXZGrP1AbYWLC4 = D8fi02QU6oqce9E5jXZGrP1AbYWLC4.replace('\/','/')
		if V8fmEML1b0PeaRZySnzh3H5J9: D8fi02QU6oqce9E5jXZGrP1AbYWLC4 = D8fi02QU6oqce9E5jXZGrP1AbYWLC4.decode('utf8').encode('utf8')
		RKFW1Vk2a7D5s8Of6UE0crQXNgq = RKFW1Vk2a7D5s8Of6UE0crQXNgq.replace('group="'+D8fi02QU6oqce9E5jXZGrP1AbYWLC4+'"','group="__MOVIES__'+D8fi02QU6oqce9E5jXZGrP1AbYWLC4+'"')
	del YN3yPtLOeFIHiRaTnWVE6
	M3QI1bliHdj7poRFV2OG(LbYUu2oFzCcHD18VxG,30,'جلب الملفات الثانوية','الملف رقم:-','3 / 3')
	if LbYUu2oFzCcHD18VxG.iscanceled():
		LbYUu2oFzCcHD18VxG.close()
		return
	SCakygtHx0AUXbO3emswB9F8 = xSMZTKVEpYdOtDLeb0j287mGH1hQJw+'&action=get_live_streams'
	JgLvsu6wx9n3VbQhk7KXylHm = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',SCakygtHx0AUXbO3emswB9F8,'',LM6unUr13ZYpOfPRkNXHE,'','','IPTV-CREATE_STREAMS-3rd')
	qUWIbEBP2tlNaSL = JgLvsu6wx9n3VbQhk7KXylHm.content
	qUWIbEBP2tlNaSL = tW06wVMpReHfnj3KgzT2va(qUWIbEBP2tlNaSL)
	Fx6bmzQk0Rgwv2N8c3ZeXOdPMYJTBn = My7Dwqvs6bfGNSIgX.findall('"name":"(.*?)".*?"tv_archive":(.*?),',qUWIbEBP2tlNaSL,My7Dwqvs6bfGNSIgX.DOTALL)
	for bSxczpUtHewVDKa3EL4lm,xYQVK1J08e5ljdL4FhyMbqmTgaHDt in Fx6bmzQk0Rgwv2N8c3ZeXOdPMYJTBn:
		if xYQVK1J08e5ljdL4FhyMbqmTgaHDt=='1': B9K5doTWwq0l2rvI.append(bSxczpUtHewVDKa3EL4lm)
	del Fx6bmzQk0Rgwv2N8c3ZeXOdPMYJTBn
	xPW7LuvC2whQSKNM3GUVFAz5ac = My7Dwqvs6bfGNSIgX.findall('"name":"(.*?)".*?"epg_channel_id":(.*?),',qUWIbEBP2tlNaSL,My7Dwqvs6bfGNSIgX.DOTALL)
	del qUWIbEBP2tlNaSL
	for bSxczpUtHewVDKa3EL4lm,Xfn8QcslMT in xPW7LuvC2whQSKNM3GUVFAz5ac:
		if Xfn8QcslMT!='null': mm0wnvDRYLMoJ1b6FUOQlau.append(bSxczpUtHewVDKa3EL4lm)
	del xPW7LuvC2whQSKNM3GUVFAz5ac
	RKFW1Vk2a7D5s8Of6UE0crQXNgq = RKFW1Vk2a7D5s8Of6UE0crQXNgq.replace('\r','\n')
	Zb6XVxojEdJCGWBYnFm9qIpu = My7Dwqvs6bfGNSIgX.findall('NF:(.+?)'+'#'+'EXTI',RKFW1Vk2a7D5s8Of6UE0crQXNgq+'\n+'+'#'+'EXTINF:',My7Dwqvs6bfGNSIgX.DOTALL)
	if not Zb6XVxojEdJCGWBYnFm9qIpu:
		Lmj1pfQk63XdoeH('ERROR_LINES',Dwl0N6FKuVU8nB1mbisIrCzdO(DaZhLqOIc24x6wv57YUlF3NgCzpGeX)+'   Folder:'+j4OBPfZchRSD1FI+'   No video links found in IPTV file')
		ZIOHgA3z0TBR('','','رسالة من المبرمج','رابط ـIPTV الذي أنت أضفته لا توجد فيه فيديوهات .. احتمال رابط ـIPTV غير صحيح'+'\n'+'[COLOR FFFFFF00]'+'مجلد رقم '+j4OBPfZchRSD1FI)
		LbYUu2oFzCcHD18VxG.close()
		return
	sIYSCKqxRXbag8O6n = []
	for mK69jMeAkOl1I3tF5HGPJRgr in Zb6XVxojEdJCGWBYnFm9qIpu:
		jIDJ8gnauWysofKXC5O = mK69jMeAkOl1I3tF5HGPJRgr.lower()
		if 'adult' in jIDJ8gnauWysofKXC5O: continue
		if 'xxx' in jIDJ8gnauWysofKXC5O: continue
		sIYSCKqxRXbag8O6n.append(mK69jMeAkOl1I3tF5HGPJRgr)
	Zb6XVxojEdJCGWBYnFm9qIpu = sIYSCKqxRXbag8O6n
	del sIYSCKqxRXbag8O6n
	xQCkqG4UB8NbSnEsRVaX7M2J = 1024*1024
	txkZeIy78BSP6Av = 1+len(RKFW1Vk2a7D5s8Of6UE0crQXNgq)//xQCkqG4UB8NbSnEsRVaX7M2J//10
	del RKFW1Vk2a7D5s8Of6UE0crQXNgq
	BhqFUudGiWmCTSMVgO6p8za5A4Lts = len(Zb6XVxojEdJCGWBYnFm9qIpu)
	rNgvBdF806McJ7pZ = wJ3eVs2RACuYPWEavOqKhlGj(Zb6XVxojEdJCGWBYnFm9qIpu,txkZeIy78BSP6Av)
	del Zb6XVxojEdJCGWBYnFm9qIpu
	for NnacyGSwPsCe18JuHpz0XQRt in range(txkZeIy78BSP6Av):
		M3QI1bliHdj7poRFV2OG(LbYUu2oFzCcHD18VxG,35+int(5*NnacyGSwPsCe18JuHpz0XQRt/txkZeIy78BSP6Av),'تقطيع الملف الرئيسي','الجزء رقم:-',str(NnacyGSwPsCe18JuHpz0XQRt+1)+' / '+str(txkZeIy78BSP6Av))
		if LbYUu2oFzCcHD18VxG.iscanceled():
			LbYUu2oFzCcHD18VxG.close()
			return
		fKOtEXSYQazGyAU37kF = str(rNgvBdF806McJ7pZ[NnacyGSwPsCe18JuHpz0XQRt])
		if BLz7m2RkNrxXQwy1cGAp: fKOtEXSYQazGyAU37kF = fKOtEXSYQazGyAU37kF.encode('utf8')
		open(W2WxQMiK8NsSmGuXt9vbAVHC0crE+'.00'+str(NnacyGSwPsCe18JuHpz0XQRt),'wb').write(fKOtEXSYQazGyAU37kF)
	del rNgvBdF806McJ7pZ,fKOtEXSYQazGyAU37kF
	WeKs7knOBqgYaDi,AAJLSzYakZ8PlhBC1um,rBLZ3RjCdy8KWk5t = [],[],0
	for NnacyGSwPsCe18JuHpz0XQRt in range(txkZeIy78BSP6Av):
		if LbYUu2oFzCcHD18VxG.iscanceled():
			LbYUu2oFzCcHD18VxG.close()
			return
		fKOtEXSYQazGyAU37kF = open(W2WxQMiK8NsSmGuXt9vbAVHC0crE+'.00'+str(NnacyGSwPsCe18JuHpz0XQRt),'rb').read()
		KBxPW9cX8dqtaUDG.sleep(1)
		try: XXRtDhYvWb35qnLBxIri7ScNUks0.remove(W2WxQMiK8NsSmGuXt9vbAVHC0crE+'.00'+str(NnacyGSwPsCe18JuHpz0XQRt))
		except: pass
		if BLz7m2RkNrxXQwy1cGAp: fKOtEXSYQazGyAU37kF = fKOtEXSYQazGyAU37kF.decode('utf8')
		pVJdckr9iDtEbyPL2qCRISGeHTmXAK = dWsa2A0O4o5BYiqGXhyKEbM('list',fKOtEXSYQazGyAU37kF)
		del fKOtEXSYQazGyAU37kF
		ccR9Mij6hCEuAJp8lVgxzWSXQ,rBLZ3RjCdy8KWk5t,VVse9qN0ZXhfRKkyQAM = USvb764Nr1LCJMexGdh0oO(pVJdckr9iDtEbyPL2qCRISGeHTmXAK,mm0wnvDRYLMoJ1b6FUOQlau,B9K5doTWwq0l2rvI,LbYUu2oFzCcHD18VxG,BhqFUudGiWmCTSMVgO6p8za5A4Lts,rBLZ3RjCdy8KWk5t,zqu2Z0UAlGn8hMVg6EY)
		if LbYUu2oFzCcHD18VxG.iscanceled():
			LbYUu2oFzCcHD18VxG.close()
			return
		if not ccR9Mij6hCEuAJp8lVgxzWSXQ:
			LbYUu2oFzCcHD18VxG.close()
			return
		AAJLSzYakZ8PlhBC1um += ccR9Mij6hCEuAJp8lVgxzWSXQ
		WeKs7knOBqgYaDi += VVse9qN0ZXhfRKkyQAM
	del pVJdckr9iDtEbyPL2qCRISGeHTmXAK,ccR9Mij6hCEuAJp8lVgxzWSXQ
	IbkRW67mYFx8so,VVse9qN0ZXhfRKkyQAM = GGhxTXEHpIDoLRlb49v(AAJLSzYakZ8PlhBC1um,LbYUu2oFzCcHD18VxG)
	if LbYUu2oFzCcHD18VxG.iscanceled():
		LbYUu2oFzCcHD18VxG.close()
		return
	WeKs7knOBqgYaDi += VVse9qN0ZXhfRKkyQAM
	del AAJLSzYakZ8PlhBC1um,VVse9qN0ZXhfRKkyQAM
	AGVyjS159f8,Y9Ps5kzS7WINDxg1,KKy4Hz7QfmbuspErFdkUcj3JT,xLpGfsu1bw,nix9Ehv4bW = {},{},{},0,0
	uXlZJvRciNLMf6EWbIBs9SO3kUdhm2 = list(IbkRW67mYFx8so.keys())
	ssR4mW1pEluSM6Xzwhg = len(uXlZJvRciNLMf6EWbIBs9SO3kUdhm2)*3
	if 1:
		hd3iCjBnNGAUzlKWEsqx2c4e = {}
		for ZKDblGPfQpu5XJvaBH08wC6t9 in uXlZJvRciNLMf6EWbIBs9SO3kUdhm2:
			hd3iCjBnNGAUzlKWEsqx2c4e[ZKDblGPfQpu5XJvaBH08wC6t9] = iDocG6BXv7fT2z8UVOxgP.Thread(target=w2Zf9mFzyae6,args=(ZKDblGPfQpu5XJvaBH08wC6t9,))
			hd3iCjBnNGAUzlKWEsqx2c4e[ZKDblGPfQpu5XJvaBH08wC6t9].start()
		for ZKDblGPfQpu5XJvaBH08wC6t9 in uXlZJvRciNLMf6EWbIBs9SO3kUdhm2:
			hd3iCjBnNGAUzlKWEsqx2c4e[ZKDblGPfQpu5XJvaBH08wC6t9].join()
		if LbYUu2oFzCcHD18VxG.iscanceled():
			LbYUu2oFzCcHD18VxG.close()
			return
	else:
		for ZKDblGPfQpu5XJvaBH08wC6t9 in uXlZJvRciNLMf6EWbIBs9SO3kUdhm2:
			w2Zf9mFzyae6(ZKDblGPfQpu5XJvaBH08wC6t9)
			if LbYUu2oFzCcHD18VxG.iscanceled():
				LbYUu2oFzCcHD18VxG.close()
				return
	BBnfvTrlahNoF6CskYZqSp(j4OBPfZchRSD1FI,False)
	uXlZJvRciNLMf6EWbIBs9SO3kUdhm2 = list(AGVyjS159f8.keys())
	CLfYQic6q5jUETktNRG3SzA48sgm = 0
	if 1:
		hd3iCjBnNGAUzlKWEsqx2c4e = {}
		for ZKDblGPfQpu5XJvaBH08wC6t9 in uXlZJvRciNLMf6EWbIBs9SO3kUdhm2:
			hd3iCjBnNGAUzlKWEsqx2c4e[ZKDblGPfQpu5XJvaBH08wC6t9] = iDocG6BXv7fT2z8UVOxgP.Thread(target=okJPNAg04wSHQucE9,args=(j4OBPfZchRSD1FI,ZKDblGPfQpu5XJvaBH08wC6t9))
			hd3iCjBnNGAUzlKWEsqx2c4e[ZKDblGPfQpu5XJvaBH08wC6t9].start()
		for ZKDblGPfQpu5XJvaBH08wC6t9 in uXlZJvRciNLMf6EWbIBs9SO3kUdhm2:
			hd3iCjBnNGAUzlKWEsqx2c4e[ZKDblGPfQpu5XJvaBH08wC6t9].join()
		if LbYUu2oFzCcHD18VxG.iscanceled():
			LbYUu2oFzCcHD18VxG.close()
			return
	else:
		for ZKDblGPfQpu5XJvaBH08wC6t9 in uXlZJvRciNLMf6EWbIBs9SO3kUdhm2:
			okJPNAg04wSHQucE9(j4OBPfZchRSD1FI,ZKDblGPfQpu5XJvaBH08wC6t9)
			if LbYUu2oFzCcHD18VxG.iscanceled():
				LbYUu2oFzCcHD18VxG.close()
				return
	NnacyGSwPsCe18JuHpz0XQRt = 0
	ciH7ljuygwX6N = len(WeKs7knOBqgYaDi)
	byZ0dns5FPL4xBEXQgO7NwUCaH16 = MaVX8uHeBbmr3UYl(j4OBPfZchRSD1FI,'IGNORED')
	for V0RHyklaNiFB2O4MLCqW3XSeU in WeKs7knOBqgYaDi:
		if NnacyGSwPsCe18JuHpz0XQRt%27==0:
			M3QI1bliHdj7poRFV2OG(LbYUu2oFzCcHD18VxG,95+int(5*NnacyGSwPsCe18JuHpz0XQRt//ciH7ljuygwX6N),'تخزين المهملة','الفيديو رقم:-',str(NnacyGSwPsCe18JuHpz0XQRt)+' / '+str(ciH7ljuygwX6N))
			if LbYUu2oFzCcHD18VxG.iscanceled():
				LbYUu2oFzCcHD18VxG.close()
				return
		VZ8BTik93OqXLCh0fD7d2KUPpn4mH6(byZ0dns5FPL4xBEXQgO7NwUCaH16,'IGNORED',str(V0RHyklaNiFB2O4MLCqW3XSeU),'',BZdvf7MIUxHQc3aCT)
		NnacyGSwPsCe18JuHpz0XQRt += 1
	VZ8BTik93OqXLCh0fD7d2KUPpn4mH6(byZ0dns5FPL4xBEXQgO7NwUCaH16,'IGNORED','__COUNT__',str(ciH7ljuygwX6N),BZdvf7MIUxHQc3aCT)
	VZ8BTik93OqXLCh0fD7d2KUPpn4mH6(byZ0dns5FPL4xBEXQgO7NwUCaH16,'DUMMY','__DUMMY__','1',BZdvf7MIUxHQc3aCT)
	LbYUu2oFzCcHD18VxG.close()
	KBxPW9cX8dqtaUDG.sleep(1)
	LKWIJHPAFZwm = qb2Po0XSgLl3tJ4EjkY87Kax(j4OBPfZchRSD1FI,False)
	ZIOHgA3z0TBR('','','رسالة من المبرمج','[COLOR FFFFFF00]'+'تم جلب ملفات ـIPTV جديدة'+'[/COLOR]'+'\n\n'+LKWIJHPAFZwm)
	tUXmK5PeEH9SDq.executebuiltin('Container.Refresh')
	WPjF76nHMOvQUA9Z(j4OBPfZchRSD1FI)
	return
def w2Zf9mFzyae6(ZKDblGPfQpu5XJvaBH08wC6t9):
	global LbYUu2oFzCcHD18VxG,IbkRW67mYFx8so,CLfYQic6q5jUETktNRG3SzA48sgm,AGVyjS159f8,Y9Ps5kzS7WINDxg1,KKy4Hz7QfmbuspErFdkUcj3JT,xLpGfsu1bw,nix9Ehv4bW,ssR4mW1pEluSM6Xzwhg
	AGVyjS159f8[ZKDblGPfQpu5XJvaBH08wC6t9] = {}
	CzW7hd3IMBKJZUwVA1ElQkYyN,Teu9bUQf64kKot5CFaJhnm30g1MY = {},[]
	jkiBMmQeOp83zJ5cTvs0EIY = len(IbkRW67mYFx8so[ZKDblGPfQpu5XJvaBH08wC6t9])
	AGVyjS159f8[ZKDblGPfQpu5XJvaBH08wC6t9]['__COUNT__'] = jkiBMmQeOp83zJ5cTvs0EIY
	if jkiBMmQeOp83zJ5cTvs0EIY>0:
		mdgbEjtcNISUXLDs0xpWhalKfFJz,wuJCiNlXm8V,teLBVMCm3Ud6W5AF2XGxkuqIh7,bZQmLXH5MsRAyJYq2jg7K6B,HI3ad78wGupf = zip(*IbkRW67mYFx8so[ZKDblGPfQpu5XJvaBH08wC6t9])
		del wuJCiNlXm8V,teLBVMCm3Ud6W5AF2XGxkuqIh7,bZQmLXH5MsRAyJYq2jg7K6B
		V6QlgmHR5qhNCp7 = list(set(mdgbEjtcNISUXLDs0xpWhalKfFJz))
		for D8fi02QU6oqce9E5jXZGrP1AbYWLC4 in V6QlgmHR5qhNCp7:
			CzW7hd3IMBKJZUwVA1ElQkYyN[D8fi02QU6oqce9E5jXZGrP1AbYWLC4] = ''
			AGVyjS159f8[ZKDblGPfQpu5XJvaBH08wC6t9][D8fi02QU6oqce9E5jXZGrP1AbYWLC4] = []
		M3QI1bliHdj7poRFV2OG(LbYUu2oFzCcHD18VxG,60+int(15*nix9Ehv4bW//ssR4mW1pEluSM6Xzwhg),'تصنيع القوائم','الجزء رقم:-',str(nix9Ehv4bW)+' / '+str(ssR4mW1pEluSM6Xzwhg))
		if LbYUu2oFzCcHD18VxG.iscanceled(): return
		nix9Ehv4bW += 1
		aTOqiPBNfe6 = len(V6QlgmHR5qhNCp7)
		del V6QlgmHR5qhNCp7
		Teu9bUQf64kKot5CFaJhnm30g1MY = list(set(zip(mdgbEjtcNISUXLDs0xpWhalKfFJz,HI3ad78wGupf)))
		del mdgbEjtcNISUXLDs0xpWhalKfFJz,HI3ad78wGupf
		for D8fi02QU6oqce9E5jXZGrP1AbYWLC4,MofmxtNlUaORA0K1uJv6S8g in Teu9bUQf64kKot5CFaJhnm30g1MY:
			if not CzW7hd3IMBKJZUwVA1ElQkYyN[D8fi02QU6oqce9E5jXZGrP1AbYWLC4] and MofmxtNlUaORA0K1uJv6S8g: CzW7hd3IMBKJZUwVA1ElQkYyN[D8fi02QU6oqce9E5jXZGrP1AbYWLC4] = MofmxtNlUaORA0K1uJv6S8g
		M3QI1bliHdj7poRFV2OG(LbYUu2oFzCcHD18VxG,60+int(15*nix9Ehv4bW//ssR4mW1pEluSM6Xzwhg),'تصنيع القوائم','الجزء رقم:-',str(nix9Ehv4bW)+' / '+str(ssR4mW1pEluSM6Xzwhg))
		if LbYUu2oFzCcHD18VxG.iscanceled(): return
		nix9Ehv4bW += 1
		e6ezbOPUY7srVqH9vE4XkCA = list(CzW7hd3IMBKJZUwVA1ElQkYyN.keys())
		muHDeO4CM5ZiWqd39p06nhP = list(CzW7hd3IMBKJZUwVA1ElQkYyN.values())
		del CzW7hd3IMBKJZUwVA1ElQkYyN
		Teu9bUQf64kKot5CFaJhnm30g1MY = list(zip(e6ezbOPUY7srVqH9vE4XkCA,muHDeO4CM5ZiWqd39p06nhP))
		del e6ezbOPUY7srVqH9vE4XkCA,muHDeO4CM5ZiWqd39p06nhP
		Teu9bUQf64kKot5CFaJhnm30g1MY = sorted(Teu9bUQf64kKot5CFaJhnm30g1MY)
	else: nix9Ehv4bW += 2
	AGVyjS159f8[ZKDblGPfQpu5XJvaBH08wC6t9]['__GROUPS__'] = Teu9bUQf64kKot5CFaJhnm30g1MY
	del Teu9bUQf64kKot5CFaJhnm30g1MY
	for D8fi02QU6oqce9E5jXZGrP1AbYWLC4,HMdmFA6wzOC0GEoa9rlt27biPn,fUNpjldoZaw76vOe,SCakygtHx0AUXbO3emswB9F8,XSP02RovU3ChBsHIZyDzuiA in IbkRW67mYFx8so[ZKDblGPfQpu5XJvaBH08wC6t9]:
		AGVyjS159f8[ZKDblGPfQpu5XJvaBH08wC6t9][D8fi02QU6oqce9E5jXZGrP1AbYWLC4].append((HMdmFA6wzOC0GEoa9rlt27biPn,fUNpjldoZaw76vOe,SCakygtHx0AUXbO3emswB9F8,XSP02RovU3ChBsHIZyDzuiA))
	M3QI1bliHdj7poRFV2OG(LbYUu2oFzCcHD18VxG,60+int(15*nix9Ehv4bW//ssR4mW1pEluSM6Xzwhg),'تصنيع القوائم','الجزء رقم:-',str(nix9Ehv4bW)+' / '+str(ssR4mW1pEluSM6Xzwhg))
	if LbYUu2oFzCcHD18VxG.iscanceled(): return
	nix9Ehv4bW += 1
	del IbkRW67mYFx8so[ZKDblGPfQpu5XJvaBH08wC6t9]
	KKy4Hz7QfmbuspErFdkUcj3JT[ZKDblGPfQpu5XJvaBH08wC6t9] = list(AGVyjS159f8[ZKDblGPfQpu5XJvaBH08wC6t9].keys())
	Y9Ps5kzS7WINDxg1[ZKDblGPfQpu5XJvaBH08wC6t9] = len(KKy4Hz7QfmbuspErFdkUcj3JT[ZKDblGPfQpu5XJvaBH08wC6t9])
	xLpGfsu1bw += Y9Ps5kzS7WINDxg1[ZKDblGPfQpu5XJvaBH08wC6t9]
	return
def okJPNAg04wSHQucE9(j4OBPfZchRSD1FI,ZKDblGPfQpu5XJvaBH08wC6t9):
	global LbYUu2oFzCcHD18VxG,IbkRW67mYFx8so,CLfYQic6q5jUETktNRG3SzA48sgm,AGVyjS159f8,Y9Ps5kzS7WINDxg1,KKy4Hz7QfmbuspErFdkUcj3JT,xLpGfsu1bw,nix9Ehv4bW,ssR4mW1pEluSM6Xzwhg
	byZ0dns5FPL4xBEXQgO7NwUCaH16 = MaVX8uHeBbmr3UYl(j4OBPfZchRSD1FI,ZKDblGPfQpu5XJvaBH08wC6t9)
	for rBLZ3RjCdy8KWk5t in range(1+Y9Ps5kzS7WINDxg1[ZKDblGPfQpu5XJvaBH08wC6t9]//273):
		F5s6Y0pNgd7 = []
		DMp73Bsez1tNwb = KKy4Hz7QfmbuspErFdkUcj3JT[ZKDblGPfQpu5XJvaBH08wC6t9][0:273]
		for D8fi02QU6oqce9E5jXZGrP1AbYWLC4 in DMp73Bsez1tNwb:
			F5s6Y0pNgd7.append(AGVyjS159f8[ZKDblGPfQpu5XJvaBH08wC6t9][D8fi02QU6oqce9E5jXZGrP1AbYWLC4])
		VZ8BTik93OqXLCh0fD7d2KUPpn4mH6(byZ0dns5FPL4xBEXQgO7NwUCaH16,ZKDblGPfQpu5XJvaBH08wC6t9,DMp73Bsez1tNwb,F5s6Y0pNgd7,BZdvf7MIUxHQc3aCT,True)
		CLfYQic6q5jUETktNRG3SzA48sgm += len(DMp73Bsez1tNwb)
		M3QI1bliHdj7poRFV2OG(LbYUu2oFzCcHD18VxG,75+int(20*CLfYQic6q5jUETktNRG3SzA48sgm//xLpGfsu1bw),'تخزين القوائم','القائمة رقم:-',str(CLfYQic6q5jUETktNRG3SzA48sgm)+' / '+str(xLpGfsu1bw))
		if LbYUu2oFzCcHD18VxG.iscanceled(): return
		del KKy4Hz7QfmbuspErFdkUcj3JT[ZKDblGPfQpu5XJvaBH08wC6t9][0:273]
	del AGVyjS159f8[ZKDblGPfQpu5XJvaBH08wC6t9],KKy4Hz7QfmbuspErFdkUcj3JT[ZKDblGPfQpu5XJvaBH08wC6t9],Y9Ps5kzS7WINDxg1[ZKDblGPfQpu5XJvaBH08wC6t9]
	return
def qb2Po0XSgLl3tJ4EjkY87Kax(j4OBPfZchRSD1FI,hQbe2Mlty3LrBixvd7mSg=True):
	if not p13ciNHPqwljuY5KQIWfD6EOm(j4OBPfZchRSD1FI,hQbe2Mlty3LrBixvd7mSg): return
	r0mpBtPjWqG7u6o91AlKTR = 'رسالة من المبرمج'
	zrRihsBwG0b1kAvFd4m8oSq2E = MaVX8uHeBbmr3UYl(j4OBPfZchRSD1FI,'LIVE_ORIGINAL_GROUPED')
	Zrak1UCxinLz0IJBS8 = MaVX8uHeBbmr3UYl(j4OBPfZchRSD1FI,'VOD_ORIGINAL_GROUPED')
	ciH7ljuygwX6N = zPgNsqpJInt(zrRihsBwG0b1kAvFd4m8oSq2E,'int','IGNORED','__COUNT__')
	SCuozsg58G9WTw = zPgNsqpJInt(zrRihsBwG0b1kAvFd4m8oSq2E,'int','LIVE_ORIGINAL_GROUPED','__COUNT__')
	DvwkZPMfVAK = zPgNsqpJInt(Zrak1UCxinLz0IJBS8,'int','VOD_ORIGINAL_GROUPED','__COUNT__')
	ju4PCX3YvBMIDg = zPgNsqpJInt(zrRihsBwG0b1kAvFd4m8oSq2E,'int','LIVE_GROUPED','__COUNT__')
	PfH4Yq6j1n03rA = zPgNsqpJInt(zrRihsBwG0b1kAvFd4m8oSq2E,'int','LIVE_UNKNOWN_GROUPED','__COUNT__')
	iiJ1OoKYPgwqUlHLFIjxT3vuZerf = zPgNsqpJInt(zrRihsBwG0b1kAvFd4m8oSq2E,'int','VOD_MOVIES_GROUPED','__COUNT__')
	pmerX74F6dwZR9jSg = zPgNsqpJInt(Zrak1UCxinLz0IJBS8,'int','VOD_SERIES_GROUPED','__COUNT__')
	OFxw54qbgP6UJnIHstkiSvQ0 = zPgNsqpJInt(zrRihsBwG0b1kAvFd4m8oSq2E,'int','VOD_UNKNOWN_GROUPED','__COUNT__')
	KKy4Hz7QfmbuspErFdkUcj3JT = zPgNsqpJInt(Zrak1UCxinLz0IJBS8,'list','VOD_SERIES_GROUPED','__GROUPS__')
	hKlMoNpanUyTe2i = []
	for D8fi02QU6oqce9E5jXZGrP1AbYWLC4,XSP02RovU3ChBsHIZyDzuiA in KKy4Hz7QfmbuspErFdkUcj3JT:
		Mu6pAf1bv0HCEWaPTgBdGh = D8fi02QU6oqce9E5jXZGrP1AbYWLC4.split('__SERIES__')[1]
		hKlMoNpanUyTe2i.append(Mu6pAf1bv0HCEWaPTgBdGh)
	R3bQ5eo6rHJT8yMuIhtAYG = len(hKlMoNpanUyTe2i)
	c2PYZqmOTMsHF = int(iiJ1OoKYPgwqUlHLFIjxT3vuZerf)+int(pmerX74F6dwZR9jSg)+int(OFxw54qbgP6UJnIHstkiSvQ0)+int(PfH4Yq6j1n03rA)+int(ju4PCX3YvBMIDg)
	LKWIJHPAFZwm = ''
	LKWIJHPAFZwm += 'قنوات: '+str(ju4PCX3YvBMIDg)
	LKWIJHPAFZwm += '   .   أفلام: '+str(iiJ1OoKYPgwqUlHLFIjxT3vuZerf)
	LKWIJHPAFZwm += '\nمسلسلات: '+str(R3bQ5eo6rHJT8yMuIhtAYG)
	LKWIJHPAFZwm += '   .   حلقات: '+str(pmerX74F6dwZR9jSg)
	LKWIJHPAFZwm += '\nقنوات مجهولة: '+str(PfH4Yq6j1n03rA)
	LKWIJHPAFZwm += '   .   فيدوهات مجهولة: '+str(OFxw54qbgP6UJnIHstkiSvQ0)
	LKWIJHPAFZwm += '\nمجموع القنوات: '+str(SCuozsg58G9WTw)
	LKWIJHPAFZwm += '   .   مجموع الفيديوهات: '+str(DvwkZPMfVAK)
	LKWIJHPAFZwm += '\n\nمجموع المضافة: '+str(c2PYZqmOTMsHF)
	LKWIJHPAFZwm += '   .   مجموع المهملة: '+str(ciH7ljuygwX6N)
	if hQbe2Mlty3LrBixvd7mSg: ZIOHgA3z0TBR('center','',r0mpBtPjWqG7u6o91AlKTR,LKWIJHPAFZwm)
	z9IVvn2yCodaxfm8NrQZYcg = LKWIJHPAFZwm.replace('\n\n','\n')
	Lmj1pfQk63XdoeH('NOTICE','.  Counts of IPTV videos   Folder: '+j4OBPfZchRSD1FI+'\n'+z9IVvn2yCodaxfm8NrQZYcg)
	return LKWIJHPAFZwm
def BBnfvTrlahNoF6CskYZqSp(j4OBPfZchRSD1FI,hQbe2Mlty3LrBixvd7mSg=True):
	if hQbe2Mlty3LrBixvd7mSg:
		UHx5YQ3FogO87NB0mrXRthi = mmwySO1P4jnKz5('center','','','مسح ملفات ـIPTV','تستطيع في أي وقت الدخول إلى قائمة ـIPTV وجلب ملفات ـIPTV جديدة .. هل تريد الآن مسح الملفات القديمة المخزنة في البرنامج ؟!')
		if UHx5YQ3FogO87NB0mrXRthi!=1: return
		WnKdiOw8u9XoI = veznPUcof0MuAIi73Sma.replace('___','_'+j4OBPfZchRSD1FI)
		try: XXRtDhYvWb35qnLBxIri7ScNUks0.remove(WnKdiOw8u9XoI)
		except: pass
	WnKdiOw8u9XoI = Hf6hzJEyo3xBV.replace('___','_'+j4OBPfZchRSD1FI)
	try: XXRtDhYvWb35qnLBxIri7ScNUks0.remove(WnKdiOw8u9XoI)
	except: pass
	WnKdiOw8u9XoI = cY1jEhtFDQ5urV62JwIGa4.replace('___','_'+j4OBPfZchRSD1FI)
	try: XXRtDhYvWb35qnLBxIri7ScNUks0.remove(WnKdiOw8u9XoI)
	except: pass
	qkSCcaj2fg4VO7dl3G9IhJBs5DLx(RnqtMUa9Nh6peGEsBT,'SECTIONS_IPTV','SECTIONS_IPTV_'+j4OBPfZchRSD1FI)
	qkSCcaj2fg4VO7dl3G9IhJBs5DLx(RnqtMUa9Nh6peGEsBT,'SECTIONS_IPTV','SECTIONS_IPTV_ALL')
	ooMyveu1YHBOkXcpfF2jqCVl(False)
	WPjF76nHMOvQUA9Z(j4OBPfZchRSD1FI)
	if hQbe2Mlty3LrBixvd7mSg:
		ZIOHgA3z0TBR('','','رسالة من المبرمج','تم مسح جميع ملفات ـIPTV')
		tUXmK5PeEH9SDq.executebuiltin('Container.Refresh')
	return
def p13ciNHPqwljuY5KQIWfD6EOm(j4OBPfZchRSD1FI='',hQbe2Mlty3LrBixvd7mSg=True):
	if j4OBPfZchRSD1FI:
		byZ0dns5FPL4xBEXQgO7NwUCaH16 = MaVX8uHeBbmr3UYl(str(j4OBPfZchRSD1FI),'DUMMY')
		GpRJb7qFgjW = zPgNsqpJInt(byZ0dns5FPL4xBEXQgO7NwUCaH16,'str','DUMMY','__DUMMY__')
		if GpRJb7qFgjW: return True
	else:
		j4OBPfZchRSD1FI = '1'
		for lmDKLTA2eqIU814H76RBgPtywh in range(1,HHm4q1SnPBZIf6wcap8zJoeDM7+1):
			byZ0dns5FPL4xBEXQgO7NwUCaH16 = MaVX8uHeBbmr3UYl(str(lmDKLTA2eqIU814H76RBgPtywh),'DUMMY')
			GpRJb7qFgjW = zPgNsqpJInt(byZ0dns5FPL4xBEXQgO7NwUCaH16,'str','DUMMY','__DUMMY__')
			if GpRJb7qFgjW: return True
	if hQbe2Mlty3LrBixvd7mSg:
		ZIOHgA3z0TBR('','','رسالة من المبرمج','هذا الجزء من البرنامج يحتاج اشتراك IPTV مدفوع من شركة IPTV .. ونوع الرابط المطلوب هو  m3u .. وهذا مثال لتوضيح شكل الرابط المطلوب في هذا البرنامج  [COLOR FFC89008] \n\nhttp://xyz.xyz/get.php?username=xyz&password=xyz&type=m3u_plus [/COLOR]')
		r0mpBtPjWqG7u6o91AlKTR = 'إضافة وتغيير رابط '+iUgLYNaTzxo[1]+' (مجلد '+iUgLYNaTzxo[int(j4OBPfZchRSD1FI)]+')'
		UHx5YQ3FogO87NB0mrXRthi = mmwySO1P4jnKz5('','','',r0mpBtPjWqG7u6o91AlKTR,'لإضافة رابط IPTV .. أولا أفتح قائمة IPTV .. وثانيا أنقر على إضافة رابط أو اشتراك ـIPTV .. وثالثا أنقر على جلب ملفات ـIPTV \n\n هل تريد إضافة أو تغيير رابط IPTV الآن ؟!')
		if UHx5YQ3FogO87NB0mrXRthi==1: JZeiyxc3z1HX7Ej(j4OBPfZchRSD1FI)
	return False
def aMRpBNWSu05t(VL9QEcw2uj70SbqnK,j4OBPfZchRSD1FI='',ZKDblGPfQpu5XJvaBH08wC6t9='',qqLsbNxWJOdyeP7=''):
	if not qqLsbNxWJOdyeP7: qqLsbNxWJOdyeP7 = '1'
	J05JvhlNWgdBnH1SOzYFey3Pw9u,khALrUNtziB3gX,hQbe2Mlty3LrBixvd7mSg = X54MLovbG8nAEkB9J(VL9QEcw2uj70SbqnK)
	if not p13ciNHPqwljuY5KQIWfD6EOm(j4OBPfZchRSD1FI,hQbe2Mlty3LrBixvd7mSg): return
	if not J05JvhlNWgdBnH1SOzYFey3Pw9u:
		J05JvhlNWgdBnH1SOzYFey3Pw9u = ViKAIsLurq83RSENayxWb()
		if not J05JvhlNWgdBnH1SOzYFey3Pw9u: return
	J9H2njpRoKl8Px4 = ['','LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not ZKDblGPfQpu5XJvaBH08wC6t9:
		if not hQbe2Mlty3LrBixvd7mSg:
			if   '_IPTV-LIVE_' in khALrUNtziB3gX: ZKDblGPfQpu5XJvaBH08wC6t9 = J9H2njpRoKl8Px4[1]
			elif '_IPTV-MOVIES' in khALrUNtziB3gX: ZKDblGPfQpu5XJvaBH08wC6t9 = J9H2njpRoKl8Px4[2]
			elif '_IPTV-SERIES' in khALrUNtziB3gX: ZKDblGPfQpu5XJvaBH08wC6t9 = J9H2njpRoKl8Px4[3]
			else: ZKDblGPfQpu5XJvaBH08wC6t9 = J9H2njpRoKl8Px4[0]
		else:
			WDa9BEhrC5J4xvS6lIXUf0 = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			vwnZ6hF0xpbt47o1f2VUily = CnKwdteDG5BE8MTRhUpYIJm3NLrSgq('أختر البحث المناسب', WDa9BEhrC5J4xvS6lIXUf0)
			if vwnZ6hF0xpbt47o1f2VUily==-1: return
			ZKDblGPfQpu5XJvaBH08wC6t9 = J9H2njpRoKl8Px4[vwnZ6hF0xpbt47o1f2VUily]
	J05JvhlNWgdBnH1SOzYFey3Pw9u = J05JvhlNWgdBnH1SOzYFey3Pw9u+'_NODIALOGS_'
	if j4OBPfZchRSD1FI: V4hoOjAbFK(J05JvhlNWgdBnH1SOzYFey3Pw9u,j4OBPfZchRSD1FI,ZKDblGPfQpu5XJvaBH08wC6t9,qqLsbNxWJOdyeP7)
	else:
		for j4OBPfZchRSD1FI in range(1,HHm4q1SnPBZIf6wcap8zJoeDM7+1):
			V4hoOjAbFK(J05JvhlNWgdBnH1SOzYFey3Pw9u,str(j4OBPfZchRSD1FI),ZKDblGPfQpu5XJvaBH08wC6t9,qqLsbNxWJOdyeP7)
		xx4viQhaOu6r0[:] = sorted(xx4viQhaOu6r0,reverse=False,key=lambda S2igRNm4wsYJqv7FVWxa06A: S2igRNm4wsYJqv7FVWxa06A[1].lower())
	return
def V4hoOjAbFK(VL9QEcw2uj70SbqnK,j4OBPfZchRSD1FI,ZKDblGPfQpu5XJvaBH08wC6t9='',qqLsbNxWJOdyeP7=''):
	if not qqLsbNxWJOdyeP7: qqLsbNxWJOdyeP7 = '1'
	J05JvhlNWgdBnH1SOzYFey3Pw9u,khALrUNtziB3gX,hQbe2Mlty3LrBixvd7mSg = X54MLovbG8nAEkB9J(VL9QEcw2uj70SbqnK)
	if not j4OBPfZchRSD1FI: return
	if not p13ciNHPqwljuY5KQIWfD6EOm(j4OBPfZchRSD1FI,hQbe2Mlty3LrBixvd7mSg): return
	if not J05JvhlNWgdBnH1SOzYFey3Pw9u:
		J05JvhlNWgdBnH1SOzYFey3Pw9u = ViKAIsLurq83RSENayxWb()
		if not J05JvhlNWgdBnH1SOzYFey3Pw9u: return
	J9H2njpRoKl8Px4 = ['','LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not ZKDblGPfQpu5XJvaBH08wC6t9:
		if not hQbe2Mlty3LrBixvd7mSg:
			if   '_IPTV-LIVE_' in khALrUNtziB3gX: ZKDblGPfQpu5XJvaBH08wC6t9 = J9H2njpRoKl8Px4[1]
			elif '_IPTV-MOVIES' in khALrUNtziB3gX: ZKDblGPfQpu5XJvaBH08wC6t9 = J9H2njpRoKl8Px4[2]
			elif '_IPTV-SERIES' in khALrUNtziB3gX: ZKDblGPfQpu5XJvaBH08wC6t9 = J9H2njpRoKl8Px4[3]
			else: ZKDblGPfQpu5XJvaBH08wC6t9 = J9H2njpRoKl8Px4[0]
		else:
			WDa9BEhrC5J4xvS6lIXUf0 = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			vwnZ6hF0xpbt47o1f2VUily = CnKwdteDG5BE8MTRhUpYIJm3NLrSgq('أختر البحث المناسب', WDa9BEhrC5J4xvS6lIXUf0)
			if vwnZ6hF0xpbt47o1f2VUily==-1: return
			ZKDblGPfQpu5XJvaBH08wC6t9 = J9H2njpRoKl8Px4[vwnZ6hF0xpbt47o1f2VUily]
	yfecUj6qh5m7FGb1K = J05JvhlNWgdBnH1SOzYFey3Pw9u.lower()
	byZ0dns5FPL4xBEXQgO7NwUCaH16 = MaVX8uHeBbmr3UYl(j4OBPfZchRSD1FI,'SEARCH')
	fM9jDUciIqk2SutLy5Y4ngE3aWlOe = zPgNsqpJInt(byZ0dns5FPL4xBEXQgO7NwUCaH16,'list','SEARCH',(ZKDblGPfQpu5XJvaBH08wC6t9,yfecUj6qh5m7FGb1K))
	if not fM9jDUciIqk2SutLy5Y4ngE3aWlOe:
		uic63bhzm5VN7JvFUxygABt,xIGtWDmOrq8L20iJCkFlP4c = [],[]
		if not ZKDblGPfQpu5XJvaBH08wC6t9: H2HnLT8FClSet0u = [1,2,3,4,5]
		else: H2HnLT8FClSet0u = [J9H2njpRoKl8Px4.index(ZKDblGPfQpu5XJvaBH08wC6t9)]
		for NnacyGSwPsCe18JuHpz0XQRt in H2HnLT8FClSet0u:
			byZ0dns5FPL4xBEXQgO7NwUCaH16 = MaVX8uHeBbmr3UYl(j4OBPfZchRSD1FI,J9H2njpRoKl8Px4[NnacyGSwPsCe18JuHpz0XQRt])
			if NnacyGSwPsCe18JuHpz0XQRt!=3:
				ccR9Mij6hCEuAJp8lVgxzWSXQ = zPgNsqpJInt(byZ0dns5FPL4xBEXQgO7NwUCaH16,'dict',J9H2njpRoKl8Px4[NnacyGSwPsCe18JuHpz0XQRt])
				del ccR9Mij6hCEuAJp8lVgxzWSXQ['__COUNT__']
				del ccR9Mij6hCEuAJp8lVgxzWSXQ['__GROUPS__']
				del ccR9Mij6hCEuAJp8lVgxzWSXQ['__SEQUENCED_COLUMNS__']
				KKy4Hz7QfmbuspErFdkUcj3JT = list(ccR9Mij6hCEuAJp8lVgxzWSXQ.keys())
				for D8fi02QU6oqce9E5jXZGrP1AbYWLC4 in KKy4Hz7QfmbuspErFdkUcj3JT:
					for HMdmFA6wzOC0GEoa9rlt27biPn,fUNpjldoZaw76vOe,SCakygtHx0AUXbO3emswB9F8,XSP02RovU3ChBsHIZyDzuiA in ccR9Mij6hCEuAJp8lVgxzWSXQ[D8fi02QU6oqce9E5jXZGrP1AbYWLC4]:
						if yfecUj6qh5m7FGb1K in fUNpjldoZaw76vOe.lower(): xIGtWDmOrq8L20iJCkFlP4c.append((fUNpjldoZaw76vOe,SCakygtHx0AUXbO3emswB9F8,XSP02RovU3ChBsHIZyDzuiA))
					del ccR9Mij6hCEuAJp8lVgxzWSXQ[D8fi02QU6oqce9E5jXZGrP1AbYWLC4]
				del ccR9Mij6hCEuAJp8lVgxzWSXQ
			else: KKy4Hz7QfmbuspErFdkUcj3JT = zPgNsqpJInt(byZ0dns5FPL4xBEXQgO7NwUCaH16,'list',J9H2njpRoKl8Px4[NnacyGSwPsCe18JuHpz0XQRt],'__GROUPS__')
			for D8fi02QU6oqce9E5jXZGrP1AbYWLC4 in KKy4Hz7QfmbuspErFdkUcj3JT:
				try: D8fi02QU6oqce9E5jXZGrP1AbYWLC4,XSP02RovU3ChBsHIZyDzuiA = D8fi02QU6oqce9E5jXZGrP1AbYWLC4
				except: XSP02RovU3ChBsHIZyDzuiA = ''
				if yfecUj6qh5m7FGb1K in D8fi02QU6oqce9E5jXZGrP1AbYWLC4.lower():
					if NnacyGSwPsCe18JuHpz0XQRt!=3: tAm7QJIxDHluT2KU8dWrPv = D8fi02QU6oqce9E5jXZGrP1AbYWLC4
					else:
						RLrNZpz9thqBK,JDm9duXPaMoFE = D8fi02QU6oqce9E5jXZGrP1AbYWLC4.split('__SERIES__')
						if yfecUj6qh5m7FGb1K in RLrNZpz9thqBK.lower(): tAm7QJIxDHluT2KU8dWrPv = RLrNZpz9thqBK
						else: tAm7QJIxDHluT2KU8dWrPv = JDm9duXPaMoFE
					uic63bhzm5VN7JvFUxygABt.append((D8fi02QU6oqce9E5jXZGrP1AbYWLC4,tAm7QJIxDHluT2KU8dWrPv,J9H2njpRoKl8Px4[NnacyGSwPsCe18JuHpz0XQRt],XSP02RovU3ChBsHIZyDzuiA))
			del KKy4Hz7QfmbuspErFdkUcj3JT
		uic63bhzm5VN7JvFUxygABt = set(uic63bhzm5VN7JvFUxygABt)
		xIGtWDmOrq8L20iJCkFlP4c = set(xIGtWDmOrq8L20iJCkFlP4c)
		uic63bhzm5VN7JvFUxygABt = sorted(uic63bhzm5VN7JvFUxygABt,reverse=False,key=lambda S2igRNm4wsYJqv7FVWxa06A: S2igRNm4wsYJqv7FVWxa06A[1])
		xIGtWDmOrq8L20iJCkFlP4c = sorted(xIGtWDmOrq8L20iJCkFlP4c,reverse=False,key=lambda S2igRNm4wsYJqv7FVWxa06A: S2igRNm4wsYJqv7FVWxa06A[0])
		VZ8BTik93OqXLCh0fD7d2KUPpn4mH6(byZ0dns5FPL4xBEXQgO7NwUCaH16,'SEARCH',(ZKDblGPfQpu5XJvaBH08wC6t9,yfecUj6qh5m7FGb1K),(uic63bhzm5VN7JvFUxygABt,xIGtWDmOrq8L20iJCkFlP4c),BZdvf7MIUxHQc3aCT)
	else: uic63bhzm5VN7JvFUxygABt,xIGtWDmOrq8L20iJCkFlP4c = fM9jDUciIqk2SutLy5Y4ngE3aWlOe
	KKy4Hz7QfmbuspErFdkUcj3JT = len(uic63bhzm5VN7JvFUxygABt)
	jpl6PHGqiZhTNda9O1UQvftxmD0c = len(xIGtWDmOrq8L20iJCkFlP4c)
	EoulZdO2FQmDYrqNbA1kagMp = int(qqLsbNxWJOdyeP7)
	iiU6wBKnvIuyr1S = max(0,(EoulZdO2FQmDYrqNbA1kagMp-1)*100)
	RIJ70hd9LjY8GZtQ6 = max(0,EoulZdO2FQmDYrqNbA1kagMp*100)
	EcprTiMG5ns1kLbyx8SvA = max(0,iiU6wBKnvIuyr1S-KKy4Hz7QfmbuspErFdkUcj3JT)
	LLl1rheV4QHn = max(0,RIJ70hd9LjY8GZtQ6-KKy4Hz7QfmbuspErFdkUcj3JT)
	for D8fi02QU6oqce9E5jXZGrP1AbYWLC4,tAm7QJIxDHluT2KU8dWrPv,MEWaRF4IjV3,XSP02RovU3ChBsHIZyDzuiA in uic63bhzm5VN7JvFUxygABt[iiU6wBKnvIuyr1S:RIJ70hd9LjY8GZtQ6]:
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',ggzjQfBhqdOYNE+tAm7QJIxDHluT2KU8dWrPv,MEWaRF4IjV3,234,XSP02RovU3ChBsHIZyDzuiA,'1',D8fi02QU6oqce9E5jXZGrP1AbYWLC4,'',{'folder':j4OBPfZchRSD1FI})
	del uic63bhzm5VN7JvFUxygABt
	for fUNpjldoZaw76vOe,SCakygtHx0AUXbO3emswB9F8,XSP02RovU3ChBsHIZyDzuiA in xIGtWDmOrq8L20iJCkFlP4c[EcprTiMG5ns1kLbyx8SvA:LLl1rheV4QHn]:
		pSAvmPcJtjeVzG1 = REGCdFbgy4Vvu2ieLqNMlxntY(SCakygtHx0AUXbO3emswB9F8)
		dM2SkzwnVKc3FUPDl9BE = 'live'
		if '.mkv' in pSAvmPcJtjeVzG1 or 'VOD' in ZKDblGPfQpu5XJvaBH08wC6t9: dM2SkzwnVKc3FUPDl9BE = 'video'
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX(dM2SkzwnVKc3FUPDl9BE,ggzjQfBhqdOYNE+fUNpjldoZaw76vOe,SCakygtHx0AUXbO3emswB9F8,235,XSP02RovU3ChBsHIZyDzuiA,'','','',{'folder':j4OBPfZchRSD1FI})
	del xIGtWDmOrq8L20iJCkFlP4c
	ORiJ0ZCPYdkgTrEq3fwFXusIjS(j4OBPfZchRSD1FI,qqLsbNxWJOdyeP7,ZKDblGPfQpu5XJvaBH08wC6t9,239,KKy4Hz7QfmbuspErFdkUcj3JT+jpl6PHGqiZhTNda9O1UQvftxmD0c,J05JvhlNWgdBnH1SOzYFey3Pw9u+'_NODIALOGS_')
	return
def ORiJ0ZCPYdkgTrEq3fwFXusIjS(j4OBPfZchRSD1FI,qqLsbNxWJOdyeP7,ZKDblGPfQpu5XJvaBH08wC6t9,H3HDqY5N4e0fWSXMikZ8CR7suUmJdx,c2PYZqmOTMsHF,Gfsr6KpyVRovQmB8xcXUJ):
	if qqLsbNxWJOdyeP7!='1': VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',ggzjQfBhqdOYNE+'صفحة '+str(1),ZKDblGPfQpu5XJvaBH08wC6t9,H3HDqY5N4e0fWSXMikZ8CR7suUmJdx,'',str(1),Gfsr6KpyVRovQmB8xcXUJ,'',{'folder':j4OBPfZchRSD1FI})
	if not c2PYZqmOTMsHF: c2PYZqmOTMsHF = 0
	aejgp6fVMWQYlmsTcAH1JK4ZrI7wo = int(c2PYZqmOTMsHF/100)+1
	for EoulZdO2FQmDYrqNbA1kagMp in range(2,aejgp6fVMWQYlmsTcAH1JK4ZrI7wo):
		t03SHjW6B7NGuerzpwnCOYqi = (EoulZdO2FQmDYrqNbA1kagMp%10==0 or int(qqLsbNxWJOdyeP7)-4<EoulZdO2FQmDYrqNbA1kagMp<int(qqLsbNxWJOdyeP7)+4)
		vbFMHLmiWwsQylXp8n1SE5j = (t03SHjW6B7NGuerzpwnCOYqi and int(qqLsbNxWJOdyeP7)-40<EoulZdO2FQmDYrqNbA1kagMp<int(qqLsbNxWJOdyeP7)+40)
		if str(EoulZdO2FQmDYrqNbA1kagMp)!=qqLsbNxWJOdyeP7 and (EoulZdO2FQmDYrqNbA1kagMp%100==0 or vbFMHLmiWwsQylXp8n1SE5j):
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',ggzjQfBhqdOYNE+'صفحة '+str(EoulZdO2FQmDYrqNbA1kagMp),ZKDblGPfQpu5XJvaBH08wC6t9,H3HDqY5N4e0fWSXMikZ8CR7suUmJdx,'',str(EoulZdO2FQmDYrqNbA1kagMp),Gfsr6KpyVRovQmB8xcXUJ,'',{'folder':j4OBPfZchRSD1FI})
	if str(aejgp6fVMWQYlmsTcAH1JK4ZrI7wo)!=qqLsbNxWJOdyeP7: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',ggzjQfBhqdOYNE+'أخر صفحة '+str(aejgp6fVMWQYlmsTcAH1JK4ZrI7wo),ZKDblGPfQpu5XJvaBH08wC6t9,H3HDqY5N4e0fWSXMikZ8CR7suUmJdx,'',str(aejgp6fVMWQYlmsTcAH1JK4ZrI7wo),Gfsr6KpyVRovQmB8xcXUJ,'',{'folder':j4OBPfZchRSD1FI})
	return
def MaVX8uHeBbmr3UYl(j4OBPfZchRSD1FI,ZKDblGPfQpu5XJvaBH08wC6t9):
	if 'SERIES' in ZKDblGPfQpu5XJvaBH08wC6t9 or 'VOD_ORIGINAL' in ZKDblGPfQpu5XJvaBH08wC6t9: byZ0dns5FPL4xBEXQgO7NwUCaH16 = cY1jEhtFDQ5urV62JwIGa4
	else: byZ0dns5FPL4xBEXQgO7NwUCaH16 = Hf6hzJEyo3xBV
	byZ0dns5FPL4xBEXQgO7NwUCaH16 = byZ0dns5FPL4xBEXQgO7NwUCaH16.replace('___','_'+j4OBPfZchRSD1FI)
	return byZ0dns5FPL4xBEXQgO7NwUCaH16
def JcRXuOm9GHM71nL2oyBIz(j4OBPfZchRSD1FI,ZKDblGPfQpu5XJvaBH08wC6t9,wRMeQljgZBqCKPm):
	xSMZTKVEpYdOtDLeb0j287mGH1hQJw,zqu2Z0UAlGn8hMVg6EY,oWBNIzOb9umU8yKAnQ,OSXxZcFAmD5pyouftzJ,BwbvnC70tPIdqJX = Ys9i82ha4yo1PjDZVz(j4OBPfZchRSD1FI)
	if not OSXxZcFAmD5pyouftzJ: return
	LM6unUr13ZYpOfPRkNXHE = zEDoGS5jrWMIJl(j4OBPfZchRSD1FI)
	if   ZKDblGPfQpu5XJvaBH08wC6t9=='XTREAM_LIVE_GROUPS': SCakygtHx0AUXbO3emswB9F8 = xSMZTKVEpYdOtDLeb0j287mGH1hQJw+'&action=get_live_categories'
	elif ZKDblGPfQpu5XJvaBH08wC6t9=='XTREAM_VOD_GROUPS': SCakygtHx0AUXbO3emswB9F8 = xSMZTKVEpYdOtDLeb0j287mGH1hQJw+'&action=get_vod_categories'
	elif ZKDblGPfQpu5XJvaBH08wC6t9=='XTREAM_SERIES_GROUPS': SCakygtHx0AUXbO3emswB9F8 = xSMZTKVEpYdOtDLeb0j287mGH1hQJw+'&action=get_series_categories'
	elif ZKDblGPfQpu5XJvaBH08wC6t9=='XTREAM_LIVE_ITEMS': SCakygtHx0AUXbO3emswB9F8 = xSMZTKVEpYdOtDLeb0j287mGH1hQJw+'&action=get_live_streams&category_id='+wRMeQljgZBqCKPm
	elif ZKDblGPfQpu5XJvaBH08wC6t9=='XTREAM_VOD_ITEMS': SCakygtHx0AUXbO3emswB9F8 = xSMZTKVEpYdOtDLeb0j287mGH1hQJw+'&action=get_vod_streams&category_id='+wRMeQljgZBqCKPm
	elif ZKDblGPfQpu5XJvaBH08wC6t9=='XTREAM_SERIES_ITEMS': SCakygtHx0AUXbO3emswB9F8 = xSMZTKVEpYdOtDLeb0j287mGH1hQJw+'&action=get_series&category_id='+wRMeQljgZBqCKPm
	elif ZKDblGPfQpu5XJvaBH08wC6t9=='XTREAM_EPISODES': SCakygtHx0AUXbO3emswB9F8 = xSMZTKVEpYdOtDLeb0j287mGH1hQJw+'&action=get_series_info&series_id='+wRMeQljgZBqCKPm
	else: return
	JgLvsu6wx9n3VbQhk7KXylHm = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',SCakygtHx0AUXbO3emswB9F8,'',LM6unUr13ZYpOfPRkNXHE,'','','IPTV-XTREAM_MENUS-1st')
	qUWIbEBP2tlNaSL = JgLvsu6wx9n3VbQhk7KXylHm.content
	if V8fmEML1b0PeaRZySnzh3H5J9: qUWIbEBP2tlNaSL = qUWIbEBP2tlNaSL.decode('utf8').encode('utf8')
	IIdZRPaeG4s6Y7Lyi5bjFkN = dWsa2A0O4o5BYiqGXhyKEbM('list',qUWIbEBP2tlNaSL)
	if 'GROUPS' in ZKDblGPfQpu5XJvaBH08wC6t9:
		ZKDblGPfQpu5XJvaBH08wC6t9 = ZKDblGPfQpu5XJvaBH08wC6t9.replace('_GROUPS','_ITEMS')
		IIdZRPaeG4s6Y7Lyi5bjFkN = sorted(IIdZRPaeG4s6Y7Lyi5bjFkN,reverse=False,key=lambda S2igRNm4wsYJqv7FVWxa06A: S2igRNm4wsYJqv7FVWxa06A['category_name'].lower())
		for D8fi02QU6oqce9E5jXZGrP1AbYWLC4 in IIdZRPaeG4s6Y7Lyi5bjFkN:
			KFSVB47vELb3kD8lNfZia2 = D8fi02QU6oqce9E5jXZGrP1AbYWLC4['category_id']
			fUNpjldoZaw76vOe = D8fi02QU6oqce9E5jXZGrP1AbYWLC4['category_name']
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',ggzjQfBhqdOYNE+fUNpjldoZaw76vOe,ZKDblGPfQpu5XJvaBH08wC6t9,285,'','',str(KFSVB47vELb3kD8lNfZia2),'',{'folder':j4OBPfZchRSD1FI})
	elif ZKDblGPfQpu5XJvaBH08wC6t9=='XTREAM_SERIES_ITEMS':
		IIdZRPaeG4s6Y7Lyi5bjFkN = sorted(IIdZRPaeG4s6Y7Lyi5bjFkN,reverse=False,key=lambda S2igRNm4wsYJqv7FVWxa06A: S2igRNm4wsYJqv7FVWxa06A['name'].lower())
		for LLH49TepDw0kq7tdSj in IIdZRPaeG4s6Y7Lyi5bjFkN:
			fUNpjldoZaw76vOe = LLH49TepDw0kq7tdSj['name']
			MofmxtNlUaORA0K1uJv6S8g = LLH49TepDw0kq7tdSj['cover']
			KFSVB47vELb3kD8lNfZia2 = LLH49TepDw0kq7tdSj['series_id']
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',ggzjQfBhqdOYNE+fUNpjldoZaw76vOe,'XTREAM_EPISODES',285,MofmxtNlUaORA0K1uJv6S8g,'',str(KFSVB47vELb3kD8lNfZia2),'',{'folder':j4OBPfZchRSD1FI})
	elif ZKDblGPfQpu5XJvaBH08wC6t9=='XTREAM_EPISODES':
		MofmxtNlUaORA0K1uJv6S8g = IIdZRPaeG4s6Y7Lyi5bjFkN['info']['cover']
		bSxczpUtHewVDKa3EL4lm = IIdZRPaeG4s6Y7Lyi5bjFkN['info']['name']
		Jx0rCKm1ZaW = IIdZRPaeG4s6Y7Lyi5bjFkN['episodes']
		for Nk86oebBzr9YuiF32HAvjLqOV57wn in Jx0rCKm1ZaW:
			x7n4tKN3QFCgwGXpSiLv = Jx0rCKm1ZaW[Nk86oebBzr9YuiF32HAvjLqOV57wn]
			for SgkqzwOsdBHMXrWQlDptmT9F8 in x7n4tKN3QFCgwGXpSiLv:
				fUNpjldoZaw76vOe = SgkqzwOsdBHMXrWQlDptmT9F8['title']
				FYC1nIuVchKx8ka2w9ei0BtWm = My7Dwqvs6bfGNSIgX.findall('\d+.(S\d+E\d+)',fUNpjldoZaw76vOe,My7Dwqvs6bfGNSIgX.DOTALL)
				if FYC1nIuVchKx8ka2w9ei0BtWm: fUNpjldoZaw76vOe = bSxczpUtHewVDKa3EL4lm+' '+FYC1nIuVchKx8ka2w9ei0BtWm[0]
				KFSVB47vELb3kD8lNfZia2 = SgkqzwOsdBHMXrWQlDptmT9F8['id']
				nSzMJ8a4vwrfYh = SgkqzwOsdBHMXrWQlDptmT9F8['container_extension']
				SCakygtHx0AUXbO3emswB9F8 = xSMZTKVEpYdOtDLeb0j287mGH1hQJw.split('/player_api.php')[0]+'/series/'+OSXxZcFAmD5pyouftzJ+'/'+BwbvnC70tPIdqJX+'/'+str(KFSVB47vELb3kD8lNfZia2)+'.'+nSzMJ8a4vwrfYh
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',ggzjQfBhqdOYNE+fUNpjldoZaw76vOe,SCakygtHx0AUXbO3emswB9F8,235,MofmxtNlUaORA0K1uJv6S8g,'','','',{'folder':j4OBPfZchRSD1FI})
	elif 'ITEMS' in ZKDblGPfQpu5XJvaBH08wC6t9:
		dM2SkzwnVKc3FUPDl9BE = 'live' if 'LIVE' in ZKDblGPfQpu5XJvaBH08wC6t9 else 'video'
		IIdZRPaeG4s6Y7Lyi5bjFkN = sorted(IIdZRPaeG4s6Y7Lyi5bjFkN,reverse=False,key=lambda S2igRNm4wsYJqv7FVWxa06A: S2igRNm4wsYJqv7FVWxa06A['name'].lower())
		for Da6bWiks4V9AwBKnJRUp2Z8NGShzMj in IIdZRPaeG4s6Y7Lyi5bjFkN:
			fUNpjldoZaw76vOe = Da6bWiks4V9AwBKnJRUp2Z8NGShzMj['name']
			MofmxtNlUaORA0K1uJv6S8g = Da6bWiks4V9AwBKnJRUp2Z8NGShzMj['stream_icon']
			KFSVB47vELb3kD8lNfZia2 = Da6bWiks4V9AwBKnJRUp2Z8NGShzMj['stream_id']
			try:
				nSzMJ8a4vwrfYh = Da6bWiks4V9AwBKnJRUp2Z8NGShzMj['container_extension']
				if nSzMJ8a4vwrfYh: nSzMJ8a4vwrfYh = '.'+nSzMJ8a4vwrfYh
			except: nSzMJ8a4vwrfYh = ''
			if Da6bWiks4V9AwBKnJRUp2Z8NGShzMj['stream_type']=='live': QUcTSkXCYr7PuIonlVxL3fZJG20t6,QRLu6w2lIvdMpV7iNTgxDA4KnYjG8 = '','live'
			elif Da6bWiks4V9AwBKnJRUp2Z8NGShzMj['stream_type']=='movie': QUcTSkXCYr7PuIonlVxL3fZJG20t6,QRLu6w2lIvdMpV7iNTgxDA4KnYjG8 = 'movie/','video'
			SCakygtHx0AUXbO3emswB9F8 = xSMZTKVEpYdOtDLeb0j287mGH1hQJw.split('/player_api.php')[0]+'/'+QUcTSkXCYr7PuIonlVxL3fZJG20t6+OSXxZcFAmD5pyouftzJ+'/'+BwbvnC70tPIdqJX+'/'+str(KFSVB47vELb3kD8lNfZia2)+nSzMJ8a4vwrfYh
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX(dM2SkzwnVKc3FUPDl9BE,ggzjQfBhqdOYNE+fUNpjldoZaw76vOe,SCakygtHx0AUXbO3emswB9F8,235,MofmxtNlUaORA0K1uJv6S8g,'','','',{'folder':j4OBPfZchRSD1FI})
	return
def WPjF76nHMOvQUA9Z(j4OBPfZchRSD1FI):
	p3l4qwtsKIfmbZja8dHTPJvMGVrNO6 = bLEBi8IO7uU2x3htYDdVq95.getSetting('av.language.provider')
	Ll6IpqSv2JZytKiMBWEPzrb9Hcx35n = bLEBi8IO7uU2x3htYDdVq95.getSetting('av.language.code')
	qkSCcaj2fg4VO7dl3G9IhJBs5DLx(RnqtMUa9Nh6peGEsBT,'MENUS_CACHE_'+p3l4qwtsKIfmbZja8dHTPJvMGVrNO6+'_'+Ll6IpqSv2JZytKiMBWEPzrb9Hcx35n,'%_IP'+j4OBPfZchRSD1FI+'_%')
	return
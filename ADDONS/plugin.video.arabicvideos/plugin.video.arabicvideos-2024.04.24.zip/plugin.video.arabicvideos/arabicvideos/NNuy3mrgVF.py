# -*- coding: utf-8 -*-
from G6AHskJeqN import *
baNWS6nfqTC5iX4Kl = 'FASELHD1'
headers = {'User-Agent':''}
teUPLFC3B8bArakwHVGsdhoIWDM49f = '_FH1_'
EZxQp1WOldMTvFU = AK5RqLhji4W1wt9VdrCD3PGeQM[baNWS6nfqTC5iX4Kl][0]
eh2tDvRFWpLQI = ['جوائز الأوسكار','المراجعات','wwe']
def VbgEajY4Bt2COpGDcPqI(mode,url,text):
	if   mode==570: ft3e2JBKQVXWlFPjaMhkEqGxvDg = eN02L7Tf5bQ()
	elif mode==571: ft3e2JBKQVXWlFPjaMhkEqGxvDg = sscM839DP1jWZ4zl6uIx0Kyn(url,text)
	elif mode==572: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HDxCnPKFhITpZmOsA4a0UL6(url)
	elif mode==573: ft3e2JBKQVXWlFPjaMhkEqGxvDg = rFZB0V49nigPyfKQHqcLXEs(url,text)
	elif mode==576: ft3e2JBKQVXWlFPjaMhkEqGxvDg = hDWwUCIZYtLcszqARkx3KmMiXeV5u()
	elif mode==579: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HjZcUIVAXFCqy9TfBWKtgY2(text)
	else: ft3e2JBKQVXWlFPjaMhkEqGxvDg = False
	return ft3e2JBKQVXWlFPjaMhkEqGxvDg
def eN02L7Tf5bQ():
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link',teUPLFC3B8bArakwHVGsdhoIWDM49f+'لماذا الموقع بطيء','',576)
	xxE5BSyQkNsj,url,xHb86g9WZqPwRfVjXD2JalzSIp = zu3wbS2VXEhgxUYGKmIqpOosT(UuEtImzir9,'GET',EZxQp1WOldMTvFU,'faselhd1','فاصل إعلاني','dubbed-movies')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'بحث في الموقع',xxE5BSyQkNsj,579,'','','_REMEMBERRESULTS_')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'المميزة',xxE5BSyQkNsj,571,'','','featured1')
	items = My7Dwqvs6bfGNSIgX.findall('class="h3">(.*?)<.*?href="(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if not items:
		ZIOHgA3z0TBR('','','موقع فاصل الأول','البرنامج لم يستطيع إيجاد عنوان الموقع أو تصميم الموقع تغير')
		return
	for title,BoEFz2WhUyvTgDeiZ in items:
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,571,'','','details1')
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"menu-primary"(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		vUK80uOnNs = My7Dwqvs6bfGNSIgX.findall('<li (.*?)</li>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		VhIpru58Ns = ['','أفلام: ','مسلسلات: ','برامج: ','آسيوي: ','أنمي: ']
		k3Om08MCgqQao4n1 = 0
		for us7LOaKdRDwxbt0lP in vUK80uOnNs:
			if k3Om08MCgqQao4n1>0: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
			items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?>(.*?)<',us7LOaKdRDwxbt0lP,My7Dwqvs6bfGNSIgX.DOTALL)
			for BoEFz2WhUyvTgDeiZ,title in items:
				if BoEFz2WhUyvTgDeiZ=='#': continue
				if 'http' not in BoEFz2WhUyvTgDeiZ: BoEFz2WhUyvTgDeiZ = xxE5BSyQkNsj+BoEFz2WhUyvTgDeiZ
				if title=='': continue
				if any(WoFrX46wzbCNp18 in title.lower() for WoFrX46wzbCNp18 in eh2tDvRFWpLQI): continue
				title = VhIpru58Ns[k3Om08MCgqQao4n1]+title
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,571,'','','details2')
			k3Om08MCgqQao4n1 += 1
	return
def hDWwUCIZYtLcszqARkx3KmMiXeV5u():
	ZIOHgA3z0TBR('','','رسالة من المبرمج','موقع فاصل الأول بطيء من المصدر .. بسبب قيام أصحاب الموقع بإضافة فحص وتحقق أمني ضد هجوم البرامج وهجوم القراصنة على صفحات الموقع .. والوقت الضائع يذهب في محاولة تجاوز هذا الفحص واثبات أن هذا البرنامج هو مجرد متصفح للمواقع ولا يقوم بالهجوم على المواقع')
	return
def sscM839DP1jWZ4zl6uIx0Kyn(url,type=''):
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'','','','','FASELHD1-TITLES-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	kdYXhMN8Hpbt = My7Dwqvs6bfGNSIgX.findall('class="h4">(.*?)</div>(.*?)"container"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if not kdYXhMN8Hpbt: return
	if type=='filters':
		XBuP6Op7y4K = [MK6ZT2zjC1SbmveNFqor.replace('\\/','/').replace('\\"','"')]
	elif type=='featured1':
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"homeSlide"(.*?)"container"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall(' src="(.*?)".*? href="(.*?)">(.*?)</a>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		VZIuOLhil3qjRvJsM18me,NVHrZsqUp2,msjnlSMrQGJ4oLwE2d = zip(*items)
		items = zip(NVHrZsqUp2,VZIuOLhil3qjRvJsM18me,msjnlSMrQGJ4oLwE2d)
	elif type=='featured2':
		title,vsptNMP2ZQC = kdYXhMN8Hpbt[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*? data-src="(.*?)".*? alt="(.*?)"',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	elif type=='details2' and len(kdYXhMN8Hpbt)>1:
		title = kdYXhMN8Hpbt[0][0]
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,url,571,'','','featured2')
		title = kdYXhMN8Hpbt[1][0]
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,url,571,'','','details3')
		return
	else:
		title,vsptNMP2ZQC = kdYXhMN8Hpbt[-1]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*? data-src="(.*?)".*?"h1">(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	y7y3d5Fbhv42ONmtwLZ0SerYoQq = []
	for BoEFz2WhUyvTgDeiZ,IcWzVO137wFvemn2QTq8yKs9,title in items:
		if any(WoFrX46wzbCNp18 in title.lower() for WoFrX46wzbCNp18 in eh2tDvRFWpLQI): continue
		IcWzVO137wFvemn2QTq8yKs9 = tW06wVMpReHfnj3KgzT2va(IcWzVO137wFvemn2QTq8yKs9)
		IcWzVO137wFvemn2QTq8yKs9 = IcWzVO137wFvemn2QTq8yKs9.split('?resize=')[0]
		title = PIfAumbGicwg5ye(title)
		ffhN7jAqe3Q4cR0Ukptzl = My7Dwqvs6bfGNSIgX.findall('(.*?) (الحلقة|حلقة).\d+',title,My7Dwqvs6bfGNSIgX.DOTALL)
		if '/collections/' in BoEFz2WhUyvTgDeiZ:
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,571,IcWzVO137wFvemn2QTq8yKs9)
		elif ffhN7jAqe3Q4cR0Ukptzl and type=='':
			title = '_MOD_'+ffhN7jAqe3Q4cR0Ukptzl[0][0]
			title = title.strip(' –')
			if title not in y7y3d5Fbhv42ONmtwLZ0SerYoQq:
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,573,IcWzVO137wFvemn2QTq8yKs9)
				y7y3d5Fbhv42ONmtwLZ0SerYoQq.append(title)
		elif 'episodes/' in BoEFz2WhUyvTgDeiZ or 'movies/' in BoEFz2WhUyvTgDeiZ or 'hindi/' in BoEFz2WhUyvTgDeiZ:
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,572,IcWzVO137wFvemn2QTq8yKs9)
		else: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,573,IcWzVO137wFvemn2QTq8yKs9)
	if type=='filters':
		c8xyLVFa6uoi = My7Dwqvs6bfGNSIgX.findall('"more_button_page":(.*?),',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		if c8xyLVFa6uoi:
			count = c8xyLVFa6uoi[0]
			BoEFz2WhUyvTgDeiZ = url+'/offset/'+count
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'صفحة أخرى',BoEFz2WhUyvTgDeiZ,571,'','','filters')
	elif 'details' in type:
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall("class='pagination(.*?)</div>",MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if XBuP6Op7y4K:
			vsptNMP2ZQC = XBuP6Op7y4K[0]
			items = My7Dwqvs6bfGNSIgX.findall("href='(.*?)'.*?>(.*?)<",vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
			for BoEFz2WhUyvTgDeiZ,title in items:
				title = 'صفحة '+PIfAumbGicwg5ye(title)
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,571,'','','details4')
	return
def rFZB0V49nigPyfKQHqcLXEs(url,type=''):
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'','','','','FASELHD1-SEASONS_EPISODES-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	Or0yBIEzGeCn6pkYDgRal78F = False
	if not type:
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"seasonList"(.*?)"container"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if XBuP6Op7y4K:
			vsptNMP2ZQC = XBuP6Op7y4K[0]
			items = My7Dwqvs6bfGNSIgX.findall('href = \'(.*?)\'.*? data-src="(.*?)".*?alt="(.*?)".*?"title">(.*?)</div>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
			if len(items)>1:
				xxE5BSyQkNsj = ooq2D9xF8ZLpPBs(url,'url')
				Or0yBIEzGeCn6pkYDgRal78F = True
				for BoEFz2WhUyvTgDeiZ,IcWzVO137wFvemn2QTq8yKs9,name,title in items:
					name = PIfAumbGicwg5ye(name)
					if 'http' not in BoEFz2WhUyvTgDeiZ: BoEFz2WhUyvTgDeiZ = xxE5BSyQkNsj+BoEFz2WhUyvTgDeiZ
					title = name+' - '+title
					VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,573,IcWzVO137wFvemn2QTq8yKs9,'','episodes')
	if type=='episodes' or not Or0yBIEzGeCn6pkYDgRal78F:
		QFrVYJkywEsXquMNz = My7Dwqvs6bfGNSIgX.findall('"posterImg".*?src="(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if QFrVYJkywEsXquMNz: IcWzVO137wFvemn2QTq8yKs9 = QFrVYJkywEsXquMNz[0]
		else: IcWzVO137wFvemn2QTq8yKs9 = ''
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"epAll"(.*?)</div>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if XBuP6Op7y4K:
			vsptNMP2ZQC = XBuP6Op7y4K[0]
			items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?>(.*?)</a>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
			for BoEFz2WhUyvTgDeiZ,title in items:
				title = title.strip(' ')
				title = PIfAumbGicwg5ye(title)
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,572,IcWzVO137wFvemn2QTq8yKs9)
	return
def HDxCnPKFhITpZmOsA4a0UL6(url):
	Qki8AbTHYjzM2Ls76Gdr3eqo1Wn,aoYuIjAPW4LEqS,rr6pcuETVCl9oqeX = [],[],[]
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(f9Oum6c0FotxYn,'GET',url,'','','','','FASELHD1-PLAY-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	SSKNAfwnx0olOWULjQpm1 = My7Dwqvs6bfGNSIgX.findall('مستوى المشاهدة.*?">(.*?)</span>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if SSKNAfwnx0olOWULjQpm1:
		ME2Q6F7u8Vp1km9ws = My7Dwqvs6bfGNSIgX.findall('"tag">(.*?)</a>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if ME2Q6F7u8Vp1km9ws and a97xrkSOefH5DbjXunq(baNWS6nfqTC5iX4Kl,url,ME2Q6F7u8Vp1km9ws): return
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"videoRow"(.*?)</div>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('src="(.*?)"',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ in items:
			BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ.split('&img=')[0]
			Qki8AbTHYjzM2Ls76Gdr3eqo1Wn.append(BoEFz2WhUyvTgDeiZ+'?named=__embed')
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('class="streamHeader(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall("href = '(.*?)'.*?</i>(.*?)</a>",vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,name in items:
			BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ.split('&img=')[0]
			name = name.strip(' ')
			Qki8AbTHYjzM2Ls76Gdr3eqo1Wn.append(BoEFz2WhUyvTgDeiZ+'?named='+name+'__watch')
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('class="downloadLinks(.*?)blackwindow',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?</span>(.*?)</a>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,name in items:
			BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ.split('&img=')[0]
			Qki8AbTHYjzM2Ls76Gdr3eqo1Wn.append(BoEFz2WhUyvTgDeiZ+'?named='+name+'__download')
	for Xz0Ci5v2IdFfB4ptaySE8emlR7 in Qki8AbTHYjzM2Ls76Gdr3eqo1Wn:
		BoEFz2WhUyvTgDeiZ,name = Xz0Ci5v2IdFfB4ptaySE8emlR7.split('?named')
		if BoEFz2WhUyvTgDeiZ not in aoYuIjAPW4LEqS:
			aoYuIjAPW4LEqS.append(BoEFz2WhUyvTgDeiZ)
			rr6pcuETVCl9oqeX.append(Xz0Ci5v2IdFfB4ptaySE8emlR7)
	import t1kDWXQVpC
	t1kDWXQVpC.rqVt2xDi7jzJHBcPMRs6h0L(rr6pcuETVCl9oqeX,baNWS6nfqTC5iX4Kl,'video',url)
	return
def HjZcUIVAXFCqy9TfBWKtgY2(search):
	search,LQf3AeozSrai,showDialogs = X54MLovbG8nAEkB9J(search)
	if search=='': search = ViKAIsLurq83RSENayxWb()
	if search=='': return
	search = search.replace(' ','+')
	url = EZxQp1WOldMTvFU+'/?s='+search
	xxE5BSyQkNsj,bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,TOzKqRwpa6WrVMH8Pxy4X = zu3wbS2VXEhgxUYGKmIqpOosT(UuEtImzir9,'GET',url,'faselhd1','فاصل إعلاني','dubbed-movies')
	sscM839DP1jWZ4zl6uIx0Kyn(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,'details5')
	return
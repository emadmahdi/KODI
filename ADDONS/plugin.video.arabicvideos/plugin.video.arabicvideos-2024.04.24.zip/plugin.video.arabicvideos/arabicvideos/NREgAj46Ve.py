# -*- coding: utf-8 -*-
import sys as ehpURIi6QBDOGu8qj5EYzXrsWHJ7
hEJlvpt9LRO = ehpURIi6QBDOGu8qj5EYzXrsWHJ7.version_info [0] == 2
RrwvuxJ2OXsWnE9fzYNPDqS = 2048
pS1kDZ93ogBi50Hm7elLhEcyFfTx = 7
def E6Xo0wuA9fdQKlGOI (Ovquk0bMSPEL1ciQ73BJ2Ae):
	global Xb8HYvTBqV5RFAhE3KwMjC
	G4LMt9nR3Se6xWNpPuJd = ord (Ovquk0bMSPEL1ciQ73BJ2Ae [-1])
	qkDvfXryhi7cSz5Ee4AtVn0 = Ovquk0bMSPEL1ciQ73BJ2Ae [:-1]
	FEcyWfSHeL5Kotpx = G4LMt9nR3Se6xWNpPuJd % len (qkDvfXryhi7cSz5Ee4AtVn0)
	FPhirCoHEGw3I05B = qkDvfXryhi7cSz5Ee4AtVn0 [:FEcyWfSHeL5Kotpx] + qkDvfXryhi7cSz5Ee4AtVn0 [FEcyWfSHeL5Kotpx:]
	if hEJlvpt9LRO:
		ffWep5hGgyVTXHL1SM = unicode () .join ([unichr (ord (DDX7Qar0kqlIAKHdwnEh) - RrwvuxJ2OXsWnE9fzYNPDqS - (XapSRJwDcy5TEK0QHZr6n + G4LMt9nR3Se6xWNpPuJd) % pS1kDZ93ogBi50Hm7elLhEcyFfTx) for XapSRJwDcy5TEK0QHZr6n, DDX7Qar0kqlIAKHdwnEh in enumerate (FPhirCoHEGw3I05B)])
	else:
		ffWep5hGgyVTXHL1SM = str () .join ([chr (ord (DDX7Qar0kqlIAKHdwnEh) - RrwvuxJ2OXsWnE9fzYNPDqS - (XapSRJwDcy5TEK0QHZr6n + G4LMt9nR3Se6xWNpPuJd) % pS1kDZ93ogBi50Hm7elLhEcyFfTx) for XapSRJwDcy5TEK0QHZr6n, DDX7Qar0kqlIAKHdwnEh in enumerate (FPhirCoHEGw3I05B)])
	return eval (ffWep5hGgyVTXHL1SM)
fY5wTlhtnOc0Er6sdy4k87b,C2jP0iLNGKnHu9xp,UnWjVbo503mEMv9KF=E6Xo0wuA9fdQKlGOI,E6Xo0wuA9fdQKlGOI,E6Xo0wuA9fdQKlGOI
jx7s8T0BFgODXLMzIYedf,UxS67uoGThbMwnfNRzy4gajLd23JH,QynMHGWA0blfqTUdxRh5Jzi2t=UnWjVbo503mEMv9KF,C2jP0iLNGKnHu9xp,fY5wTlhtnOc0Er6sdy4k87b
jSu5Cg2Ub1OAkZVs8Yoz,V2RbfGOBdcA6l8NTsPWzEyvS7,LgpdP3UjFRnlX=QynMHGWA0blfqTUdxRh5Jzi2t,UxS67uoGThbMwnfNRzy4gajLd23JH,jx7s8T0BFgODXLMzIYedf
gItVahxL0w,BmcLzCFjuIrZP5fwXH18aN6YS,qbPw1d3KimF=LgpdP3UjFRnlX,V2RbfGOBdcA6l8NTsPWzEyvS7,jSu5Cg2Ub1OAkZVs8Yoz
EAc8h2sINroQYvR3WH06Ji7MVpn,vvHpKfcqRnrFzjG,l0WAe1f7Bpi5ZXk=qbPw1d3KimF,BmcLzCFjuIrZP5fwXH18aN6YS,gItVahxL0w
YB5xyI7MaRslVpv,PPNA7jWqZgDnXKVvtuai1kQdsEoMb0,BK9OvRSjZbtx7kYyop1u6zrE2QeiFI=l0WAe1f7Bpi5ZXk,vvHpKfcqRnrFzjG,EAc8h2sINroQYvR3WH06Ji7MVpn
sRth5giAQzWlEVm7JOX,WMkAjB1RgN7q,NVS30xAdRFMIw1n9CislkE2=BK9OvRSjZbtx7kYyop1u6zrE2QeiFI,PPNA7jWqZgDnXKVvtuai1kQdsEoMb0,YB5xyI7MaRslVpv
NB6ZDMqe91yfKQ240WpbIntjxiY5z,k5dztomYyN3H,T6wRistc1SCo4hqObgumK=NVS30xAdRFMIw1n9CislkE2,WMkAjB1RgN7q,sRth5giAQzWlEVm7JOX
RqldvxFuM5GEQ2HAz93o7afBb0,rbjsM8cRFiuA1,nr5mZG89ICi6cgt4MfLJa0=T6wRistc1SCo4hqObgumK,k5dztomYyN3H,NB6ZDMqe91yfKQ240WpbIntjxiY5z
hhlbF1Sns5TrEN8QPCYmL4,FGDJwkEbTB5SoXujs3f,BoWHNb9daQVCF16A=nr5mZG89ICi6cgt4MfLJa0,rbjsM8cRFiuA1,RqldvxFuM5GEQ2HAz93o7afBb0
v5EA6TqHX3s4jzBMk,C2dgEDAKQGsvh,b05yftsZ6NYgIKP=BoWHNb9daQVCF16A,FGDJwkEbTB5SoXujs3f,hhlbF1Sns5TrEN8QPCYmL4
from G6AHskJeqN import *
baNWS6nfqTC5iX4Kl = jSu5Cg2Ub1OAkZVs8Yoz(u"ࠨࡆࡒ࡛ࡓࡒࡏࡂࡆࠪज")
def VbgEajY4Bt2COpGDcPqI(H3HDqY5N4e0fWSXMikZ8CR7suUmJdx,SCakygtHx0AUXbO3emswB9F8):
	if   H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==sRth5giAQzWlEVm7JOX(u"࠷࠸࠶৪"): ft3e2JBKQVXWlFPjaMhkEqGxvDg = HYu0rdl6po()
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠸࠹࠱৫"): ft3e2JBKQVXWlFPjaMhkEqGxvDg = HDxCnPKFhITpZmOsA4a0UL6(SCakygtHx0AUXbO3emswB9F8)
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==BoWHNb9daQVCF16A(u"࠹࠳࠳৬"): ft3e2JBKQVXWlFPjaMhkEqGxvDg = f6Iubs9MacK()
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==jx7s8T0BFgODXLMzIYedf(u"࠳࠴࠵৭"): ft3e2JBKQVXWlFPjaMhkEqGxvDg = nn9ZYWFfQLCpjXRMGrBwAu()
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠴࠵࠷৮"): ft3e2JBKQVXWlFPjaMhkEqGxvDg = SSNfMTtxG45pJyPBFzIKqQ2eamgVh(SCakygtHx0AUXbO3emswB9F8)
	else: ft3e2JBKQVXWlFPjaMhkEqGxvDg = jSu5Cg2Ub1OAkZVs8Yoz(u"ࡋࡧ࡬ࡴࡧਜ")
	return ft3e2JBKQVXWlFPjaMhkEqGxvDg
def SSNfMTtxG45pJyPBFzIKqQ2eamgVh(yHSY9ekoEs):
	try: XXRtDhYvWb35qnLBxIri7ScNUks0.remove(yHSY9ekoEs.decode(gItVahxL0w(u"ࠩࡸࡸ࡫࠾ࠧझ")))
	except: XXRtDhYvWb35qnLBxIri7ScNUks0.remove(yHSY9ekoEs)
	return
def HDxCnPKFhITpZmOsA4a0UL6(SCakygtHx0AUXbO3emswB9F8):
	B0xcwKkMQ16mpSFRaVHPTzuhUZngLq(SCakygtHx0AUXbO3emswB9F8,baNWS6nfqTC5iX4Kl,QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠪࡺ࡮ࡪࡥࡰࠩञ"))
	return
def nn9ZYWFfQLCpjXRMGrBwAu():
	mR4VLhryYT2koGU6iBX = UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠫศึ็ษࠢศ่๎ࠦัศสฺࠤฬ๊แ๋ัํ์ࠥษ่ࠡษ็ูํะࠠโ์ࠣห้๋่ใ฻ࠣห้๋ืๅ๊หࠤะ๋ࠠฤุ฽฻ࠥ฿ไ๊ࠢีีࠥอไใษษ้ฮࠦวๅ์่๎๋ࠦหๆࠢฦาฯอัࠡࠤอั๊๐ไࠡ็็ๅฬะࠠโ์า๎ํࠨࠠฬ็ࠣหำะวาࠢาๆฮࠦวๅื๋ีฮ่ࠦศะอหึࠦๆ้฻้้ࠣ็ࠠศๆุ์ึฯ้ࠠส฼ำ์อࠠิ๊ไࠤ๏ฮฯฤࠢส่ฯำๅ๋ๆࠪट")
	ZIOHgA3z0TBR(PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠬ࠭ठ"),sRth5giAQzWlEVm7JOX(u"࠭ࠧड"),jSu5Cg2Ub1OAkZVs8Yoz(u"ุࠧำํๆฮࠦสฮ็ํ่ࠥอไๆๆไหฯ࠭ढ"),mR4VLhryYT2koGU6iBX)
	return
def HYu0rdl6po():
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX(QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠨ࡮࡬ࡲࡰ࠭ण"),RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ฼ื๊ใหࠣฮา๋๊ๅ่่ࠢๆอสࠡษ็ๅ๏ี๊้࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪत"),hhlbF1Sns5TrEN8QPCYmL4(u"ࠪࠫथ"),hhlbF1Sns5TrEN8QPCYmL4(u"࠵࠶࠷৯"))
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX(C2jP0iLNGKnHu9xp(u"ࠫࡱ࡯࡮࡬ࠩद"),NVS30xAdRFMIw1n9CislkE2(u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ห฼ํ๎ึࠦๅไษ้ࠤฯำๅ๋ๆࠣห้็๊ะ์๋๋ฬะ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨध"),sRth5giAQzWlEVm7JOX(u"࠭ࠧन"),b05yftsZ6NYgIKP(u"࠶࠷࠷ৰ"))
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX(C2dgEDAKQGsvh(u"ࠧ࡭࡫ࡱ࡯ࠬऩ"),v5EA6TqHX3s4jzBMk(u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪप"),fY5wTlhtnOc0Er6sdy4k87b(u"ࠩࠪफ"),RqldvxFuM5GEQ2HAz93o7afBb0(u"࠽࠾࠿࠹ৱ"))
	p9mXTOUMsi6Jznl = ECUFA4d2BVqw()
	C6bHM5iI7f30wdsaNkSPhvUo2EtmJg = XXRtDhYvWb35qnLBxIri7ScNUks0.stat(p9mXTOUMsi6Jznl).st_mtime
	ICrG9yhsUjHlxT68z7 = []
	if BLz7m2RkNrxXQwy1cGAp: L3p8cYkuqtySvmB07TH = XXRtDhYvWb35qnLBxIri7ScNUks0.listdir(p9mXTOUMsi6Jznl.encode(QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠪࡹࡹ࡬࠸ࠨब")))
	else: L3p8cYkuqtySvmB07TH = XXRtDhYvWb35qnLBxIri7ScNUks0.listdir(p9mXTOUMsi6Jznl.decode(jx7s8T0BFgODXLMzIYedf(u"ࠫࡺࡺࡦ࠹ࠩभ")))
	for OJ0YcMKXfR2G5 in L3p8cYkuqtySvmB07TH:
		if BLz7m2RkNrxXQwy1cGAp: OJ0YcMKXfR2G5 = OJ0YcMKXfR2G5.decode(EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠬࡻࡴࡧ࠺ࠪम"))
		if not OJ0YcMKXfR2G5.startswith(v5EA6TqHX3s4jzBMk(u"࠭ࡦࡪ࡮ࡨࡣࠬय")): continue
		xSBn3dvKOgM0j4pcNGIZrs7UFh1C = XXRtDhYvWb35qnLBxIri7ScNUks0.path.join(p9mXTOUMsi6Jznl,OJ0YcMKXfR2G5)
		C6bHM5iI7f30wdsaNkSPhvUo2EtmJg = XXRtDhYvWb35qnLBxIri7ScNUks0.path.getmtime(xSBn3dvKOgM0j4pcNGIZrs7UFh1C)
		ICrG9yhsUjHlxT68z7.append([OJ0YcMKXfR2G5,C6bHM5iI7f30wdsaNkSPhvUo2EtmJg])
	ICrG9yhsUjHlxT68z7 = sorted(ICrG9yhsUjHlxT68z7,reverse=T6wRistc1SCo4hqObgumK(u"࡚ࡲࡶࡧਝ"),key=lambda key: key[UxS67uoGThbMwnfNRzy4gajLd23JH(u"࠶৲")])
	for OJ0YcMKXfR2G5,C6bHM5iI7f30wdsaNkSPhvUo2EtmJg in ICrG9yhsUjHlxT68z7:
		if V8fmEML1b0PeaRZySnzh3H5J9:
			try: OJ0YcMKXfR2G5 = OJ0YcMKXfR2G5.decode(gItVahxL0w(u"ࠧࡶࡶࡩ࠼ࠬर"))
			except: pass
			OJ0YcMKXfR2G5 = OJ0YcMKXfR2G5.encode(T6wRistc1SCo4hqObgumK(u"ࠨࡷࡷࡪ࠽࠭ऱ"))
		xSBn3dvKOgM0j4pcNGIZrs7UFh1C = XXRtDhYvWb35qnLBxIri7ScNUks0.path.join(p9mXTOUMsi6Jznl,OJ0YcMKXfR2G5)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX(NVS30xAdRFMIw1n9CislkE2(u"ࠩࡹ࡭ࡩ࡫࡯ࠨल"),OJ0YcMKXfR2G5,xSBn3dvKOgM0j4pcNGIZrs7UFh1C,fY5wTlhtnOc0Er6sdy4k87b(u"࠹࠳࠲৳"))
	return
def ECUFA4d2BVqw():
	p9mXTOUMsi6Jznl = bLEBi8IO7uU2x3htYDdVq95.getSetting(qbPw1d3KimF(u"ࠪࡥࡻ࠴ࡤࡰࡹࡱࡰࡴࡧࡤ࠯ࡲࡤࡸ࡭࠭ळ"))
	if p9mXTOUMsi6Jznl: return p9mXTOUMsi6Jznl
	bLEBi8IO7uU2x3htYDdVq95.setSetting(NVS30xAdRFMIw1n9CislkE2(u"ࠫࡦࡼ࠮ࡥࡱࡺࡲࡱࡵࡡࡥ࠰ࡳࡥࡹ࡮ࠧऴ"),IjYiO4u9HGmgw)
	return IjYiO4u9HGmgw
def f6Iubs9MacK():
	p9mXTOUMsi6Jznl = ECUFA4d2BVqw()
	J017bFTSDpmhYwcuQ8yZaBjsC3On = mmwySO1P4jnKz5(fY5wTlhtnOc0Er6sdy4k87b(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬव"),WMkAjB1RgN7q(u"࠭ࠧश"),l0WAe1f7Bpi5ZXk(u"ࠧࠨष"),C2jP0iLNGKnHu9xp(u"ࠨ็ๆห๋ࠦสฯิํ๊๋ࠥไโษอࠤฬ๊สฮ็ํ่ࠬस"),C2dgEDAKQGsvh(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬह")+p9mXTOUMsi6Jznl+gItVahxL0w(u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࡡࡴ࡜࡯้ำหࠥํ่ࠡ็ๆห๋ࠦสฯิํ๊๋ࠥไโษอࠤฬ๊แ๋ัํ์ࠥอไห์ࠣฮา๋ไ่ษࠣห๋ะࠠษษึฮำีวๆ๊ࠢิฬࠦวๅสิ๊ฬ๋ฬࠡ࠰๋้ࠣࠦสา์าࠤฯเ๊๋ำࠣห้๋ใศ่ࠣรࠬऺ"))
	if J017bFTSDpmhYwcuQ8yZaBjsC3On==RqldvxFuM5GEQ2HAz93o7afBb0(u"࠱৴"):
		SmDyv4XkBALq7zN9gdeQr1tsJlT = O2Q9vWtcByH0jDNnrxbUdkLm(gItVahxL0w(u"࠴৵"),b05yftsZ6NYgIKP(u"๊้ࠫว็ࠢอั๊๐ไࠡ็็ๅฬะࠠศๆไ๎ิ๐่ࠨऻ"),hhlbF1Sns5TrEN8QPCYmL4(u"ࠬࡲ࡯ࡤࡣ࡯़ࠫ"),QynMHGWA0blfqTUdxRh5Jzi2t(u"࠭ࠧऽ"),vvHpKfcqRnrFzjG(u"ࡇࡣ࡯ࡷࡪਟ"),C2jP0iLNGKnHu9xp(u"ࡔࡳࡷࡨਞ"),p9mXTOUMsi6Jznl)
		tLwvQlnjGpWsRVCN1 = mmwySO1P4jnKz5(YB5xyI7MaRslVpv(u"ࠧࡤࡧࡱࡸࡪࡸࠧा"),V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠨࠩि"),nr5mZG89ICi6cgt4MfLJa0(u"ࠩࠪी"),UnWjVbo503mEMv9KF(u"้่ࠪอๆࠡฬัึ๏์ࠠๆๆไหฯࠦวๅฬะ้๏๊ࠧु"),EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧू")+p9mXTOUMsi6Jznl+v5EA6TqHX3s4jzBMk(u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣ࡜࡯࡞ࡱ๋ีอ่๊ࠠࠣห้๋ใศ่ࠣห้าฯ๋ั่ࠣฯิา๋่้้ࠣ็วหࠢส่ๆ๐ฯ๋๊ࠣห้ะ๊ࠡฬะ้้ํวࠡษ้ฮࠥฮวิฬัำฬ๋่ࠠาสࠤฬ๊ศา่ส้ัࠦ࠮้ࠡ็ࠤฯื๊ะࠢสืฯิฯศ็๊ࠤอีไศ่๊ࠢࠥอไๆๅส๊ࠥอไใัํ้ࠥลࠧृ"))
		if tLwvQlnjGpWsRVCN1==NVS30xAdRFMIw1n9CislkE2(u"࠳৶"):
			bLEBi8IO7uU2x3htYDdVq95.setSetting(jSu5Cg2Ub1OAkZVs8Yoz(u"࠭ࡡࡷ࠰ࡧࡳࡼࡴ࡬ࡰࡣࡧ࠲ࡵࡧࡴࡩࠩॄ"),SmDyv4XkBALq7zN9gdeQr1tsJlT)
			ZIOHgA3z0TBR(C2jP0iLNGKnHu9xp(u"ࠧࠨॅ"),NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠨࠩॆ"),NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬे"),EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠪฮ๊ࠦส฻์ํี๋ࠥใศ่ࠣฮำุ๊็ࠢส่๊๊แศฬࠣห้๋อๆๆฬࠫै"))
	return
def oocnhjEKO9UpfkVgtPXyMCmwL(SCakygtHx0AUXbO3emswB9F8,OzADck17lfuHqG2SYi=BoWHNb9daQVCF16A(u"ࠫࠬॉ"),website=b05yftsZ6NYgIKP(u"ࠬ࠭ॊ")):
	Lmj1pfQk63XdoeH(C2jP0iLNGKnHu9xp(u"࠭ࡎࡐࡖࡌࡇࡊ࠭ो"),Dwl0N6FKuVU8nB1mbisIrCzdO(baNWS6nfqTC5iX4Kl)+EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠧࠡࠢࠣࡔࡷ࡫ࡰࡢࡴ࡬ࡲ࡬ࠦࡴࡰࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧौ")+SCakygtHx0AUXbO3emswB9F8+V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠨࠢࡠ्ࠫ"))
	if not OzADck17lfuHqG2SYi: OzADck17lfuHqG2SYi = REGCdFbgy4Vvu2ieLqNMlxntY(SCakygtHx0AUXbO3emswB9F8)
	p9mXTOUMsi6Jznl = ECUFA4d2BVqw()
	HHQYtifTDV = E4L13O2bxwRDSX()
	OJ0YcMKXfR2G5 = HHQYtifTDV.replace(qbPw1d3KimF(u"ࠩࠣࠫॎ"),UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠪࡣࠬॏ"))
	OJ0YcMKXfR2G5 = hQd4Ygra5ZHWiP0UuJpj7TfI(OJ0YcMKXfR2G5)
	OJ0YcMKXfR2G5 = EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠫ࡫࡯࡬ࡦࡡࠪॐ")+str(int(SGB7KzblUa4gCZD1srqc))[-BoWHNb9daQVCF16A(u"࠷৷"):]+jx7s8T0BFgODXLMzIYedf(u"ࠬࡥࠧ॑")+OJ0YcMKXfR2G5+OzADck17lfuHqG2SYi
	AgY9Coc1NDyZHTjFQ2 = XXRtDhYvWb35qnLBxIri7ScNUks0.path.join(p9mXTOUMsi6Jznl,OJ0YcMKXfR2G5)
	LM6unUr13ZYpOfPRkNXHE = {}
	LM6unUr13ZYpOfPRkNXHE[UxS67uoGThbMwnfNRzy4gajLd23JH(u"࠭ࡁࡤࡥࡨࡴࡹ࠳ࡅ࡯ࡥࡲࡨ࡮ࡴࡧࠨ॒")] = v5EA6TqHX3s4jzBMk(u"ࠧࠨ॓")
	LM6unUr13ZYpOfPRkNXHE[qbPw1d3KimF(u"ࠨࡃࡦࡧࡪࡶࡴࠨ॔")] = gItVahxL0w(u"ࠩ࠭࠳࠯࠭ॕ")
	SCakygtHx0AUXbO3emswB9F8 = SCakygtHx0AUXbO3emswB9F8.replace(LgpdP3UjFRnlX(u"ࠪࡺࡪࡸࡩࡧࡻࡳࡩࡪࡸ࠽ࡧࡣ࡯ࡷࡪ࠭ॖ"),EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠫࠬॗ"))
	if qbPw1d3KimF(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ࠿ࠪक़") in SCakygtHx0AUXbO3emswB9F8:
		bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,rHqkc3e0CJ5VByi6vLs = SCakygtHx0AUXbO3emswB9F8.rsplit(T6wRistc1SCo4hqObgumK(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࡀࠫख़"),qbPw1d3KimF(u"࠵৸"))
		rHqkc3e0CJ5VByi6vLs = rHqkc3e0CJ5VByi6vLs.replace(NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠧࡽࠩग़"),NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠨࠩज़")).replace(LgpdP3UjFRnlX(u"ࠩࠩࠫड़"),BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠪࠫढ़"))
	else: bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,rHqkc3e0CJ5VByi6vLs = SCakygtHx0AUXbO3emswB9F8,None
	if not rHqkc3e0CJ5VByi6vLs: rHqkc3e0CJ5VByi6vLs = IeSGolOpBHM8U62m()
	if rHqkc3e0CJ5VByi6vLs: LM6unUr13ZYpOfPRkNXHE[C2jP0iLNGKnHu9xp(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨफ़")] = rHqkc3e0CJ5VByi6vLs
	if sRth5giAQzWlEVm7JOX(u"ࠬࡘࡥࡧࡧࡵࡩࡷࡃࠧय़") in bJEs4IVAPdyUrhwCLv9k2YoOl8nt1: bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,PZjG9QsCtzpMg2TcE = bJEs4IVAPdyUrhwCLv9k2YoOl8nt1.rsplit(NVS30xAdRFMIw1n9CislkE2(u"࠭ࡒࡦࡨࡨࡶࡪࡸ࠽ࠨॠ"),vvHpKfcqRnrFzjG(u"࠶৹"))
	else: bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,PZjG9QsCtzpMg2TcE = bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,UnWjVbo503mEMv9KF(u"ࠧࠨॡ")
	bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = bJEs4IVAPdyUrhwCLv9k2YoOl8nt1.strip(BoWHNb9daQVCF16A(u"ࠨࡾࠪॢ")).strip(l0WAe1f7Bpi5ZXk(u"ࠩࠩࠫॣ")).strip(sRth5giAQzWlEVm7JOX(u"ࠪࢀࠬ।")).strip(NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠫࠫ࠭॥"))
	PZjG9QsCtzpMg2TcE = PZjG9QsCtzpMg2TcE.replace(k5dztomYyN3H(u"ࠬࢂࠧ०"),UxS67uoGThbMwnfNRzy4gajLd23JH(u"࠭ࠧ१")).replace(FGDJwkEbTB5SoXujs3f(u"ࠧࠧࠩ२"),jx7s8T0BFgODXLMzIYedf(u"ࠨࠩ३"))
	if PZjG9QsCtzpMg2TcE:	LM6unUr13ZYpOfPRkNXHE[T6wRistc1SCo4hqObgumK(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ४")] = PZjG9QsCtzpMg2TcE
	Lmj1pfQk63XdoeH(rbjsM8cRFiuA1(u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ५"),Dwl0N6FKuVU8nB1mbisIrCzdO(baNWS6nfqTC5iX4Kl)+hhlbF1Sns5TrEN8QPCYmL4(u"ࠫࠥࠦࠠࡅࡱࡺࡲࡱࡵࡡࡥ࡫ࡱ࡫ࠥࡼࡩࡥࡧࡲࠤ࡫࡯࡬ࡦࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ६")+bJEs4IVAPdyUrhwCLv9k2YoOl8nt1+C2dgEDAKQGsvh(u"ࠬࠦ࡝ࠡࠢࠣࡌࡪࡧࡤࡦࡴࡶ࠾ࠥࡡࠠࠨ७")+str(LM6unUr13ZYpOfPRkNXHE)+sRth5giAQzWlEVm7JOX(u"࠭ࠠ࡞ࠢࠣࠤࡋ࡯࡬ࡦ࠼ࠣ࡟ࠥ࠭८")+AgY9Coc1NDyZHTjFQ2+PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠧࠡ࡟ࠪ९"))
	dCyLYDlUz6WwrkEIxuRj = RqldvxFuM5GEQ2HAz93o7afBb0(u"࠷࠰࠳࠶৺")*RqldvxFuM5GEQ2HAz93o7afBb0(u"࠷࠰࠳࠶৺")
	DpI3Fd9nGjs5POgcmtHTRZ = k5dztomYyN3H(u"࠰৻")
	try:
		qJPeHRihKuWCO2lxSAF1dnymLgr6 =	tUXmK5PeEH9SDq.getInfoLabel(WMkAjB1RgN7q(u"ࠨࡕࡼࡷࡹ࡫࡭࠯ࡈࡵࡩࡪ࡙ࡰࡢࡥࡨࠫ॰"))
		qJPeHRihKuWCO2lxSAF1dnymLgr6 = My7Dwqvs6bfGNSIgX.findall(T6wRistc1SCo4hqObgumK(u"ࠩ࡟ࡨ࠰࠭ॱ"),qJPeHRihKuWCO2lxSAF1dnymLgr6)
		DpI3Fd9nGjs5POgcmtHTRZ = int(qJPeHRihKuWCO2lxSAF1dnymLgr6[EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠱ৼ")])
	except: pass
	if not DpI3Fd9nGjs5POgcmtHTRZ:
		try:
			ryJSLzp9FKMbog3kiZqVEmvB = XXRtDhYvWb35qnLBxIri7ScNUks0.statvfs(p9mXTOUMsi6Jznl)
			DpI3Fd9nGjs5POgcmtHTRZ = ryJSLzp9FKMbog3kiZqVEmvB.f_frsize*ryJSLzp9FKMbog3kiZqVEmvB.f_bavail//dCyLYDlUz6WwrkEIxuRj
		except: pass
	if not DpI3Fd9nGjs5POgcmtHTRZ:
		try:
			ryJSLzp9FKMbog3kiZqVEmvB = XXRtDhYvWb35qnLBxIri7ScNUks0.fstatvfs(p9mXTOUMsi6Jznl)
			DpI3Fd9nGjs5POgcmtHTRZ = ryJSLzp9FKMbog3kiZqVEmvB.f_frsize*ryJSLzp9FKMbog3kiZqVEmvB.f_bavail//dCyLYDlUz6WwrkEIxuRj
		except: pass
	if not DpI3Fd9nGjs5POgcmtHTRZ:
		try:
			import shutil as eoNhVEgTzF
			vvV2rFwRIb0e,CIgPNxGLmZ3Qyf0O7aS9,qU5Z0V6uOv3bxNzm = eoNhVEgTzF.disk_usage(p9mXTOUMsi6Jznl)
			DpI3Fd9nGjs5POgcmtHTRZ = qU5Z0V6uOv3bxNzm//dCyLYDlUz6WwrkEIxuRj
		except: pass
	if not DpI3Fd9nGjs5POgcmtHTRZ:
		bFnD6Nh75IQcKrTke3gux4PvwRGUfS(C2dgEDAKQGsvh(u"ࠪࡶ࡮࡭ࡨࡵࠩॲ"),jSu5Cg2Ub1OAkZVs8Yoz(u"ู๊ࠫวฮหࠣห้ะฮำ์้ࠤ๊า็้ๆฬࠫॳ"),rbjsM8cRFiuA1(u"๊ࠬไฤีไࠤฬ๊ศา่ส้ัฺ๋ࠦำࠣๆฬีัࠡล้ࠤ๏ำฯะ่ࠢๆิอัࠡ็ึหาฯࠠศๆอาื๐ๆࠡษ็ๅฬืฺสࠢไ๎ࠥา็ศิๆࠤํ฿ไ๋้ࠣๅฬ์ࠠหฯ่๎้ࠦวๅใํำ๏๎็ศฬฺ่๋๊ࠣࠦ็็ࠤ฾์ฯไࠢศ่๎ࠦร็ࠢํๆํ๋ࠠๆสิ้ั๐ࠠษำ้ห๊าࠠไ๊า๎ࠥฮอๅ๊ࠢิ์ࠦวๅ็ื็้ฯࠠๅษ้ࠤฯำๅ๋ๆࠣห้็๊ะ์๋๋ฬะࠠใัࠣ๎ุฮศࠡษ่ฮ้อมࠡฮ๊หื้ࠠษษ็้้็วห๋๋ࠢีอࠠโ์๊ࠤำ฽่าหࠣ฽้๏ฺࠠ็็ࠤัํวำๅࠣฬฺ๎ัสุࠢั๏ำษ๊ࠡ็๋ีอࠠศๆึฬอࠦโศ็ࠣห้๋ศา็ฯࠤ๊สโหษࠣฬ๊์ูࠡษ็ฬึ์วๆฮ้๋ࠣࠦสฮ็ํ่ࠥอไโ์า๎ํํวหࠩॴ"),C2dgEDAKQGsvh(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩॵ"))
		Lmj1pfQk63XdoeH(NVS30xAdRFMIw1n9CislkE2(u"ࠧࡆࡔࡕࡓࡗࡥࡌࡊࡐࡈࡗࠬॶ"),Dwl0N6FKuVU8nB1mbisIrCzdO(baNWS6nfqTC5iX4Kl)+NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠨࠢࠣࠤ࡚ࡴࡡࡣ࡮ࡨࠤࡹࡵࠠࡥࡧࡷࡩࡷࡳࡩ࡯ࡧࠣࡸ࡭࡫ࠠࡥ࡫ࡶ࡯ࠥ࡬ࡲࡦࡧࠣࡷࡵࡧࡣࡦࠩॷ"))
		return EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࡈࡤࡰࡸ࡫ਠ")
	if OzADck17lfuHqG2SYi==NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨॸ"):
		wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = cChyAEtdaMvNXsurWwnSeBzFU2m(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,LM6unUr13ZYpOfPRkNXHE)
		if len(wlfZEzuRyYLvrp)==V2RbfGOBdcA6l8NTsPWzEyvS7(u"࠲৽"):
			gj7BGM5t3RZpA0vNixLqzwualb16(T6wRistc1SCo4hqObgumK(u"ࠪๅู๊ࠠโ์ࠣษ๏าวะ่่ࠢๆࠦวๅฬะ้๏๊ࠧॹ"),nr5mZG89ICi6cgt4MfLJa0(u"ࠫࠬॺ"))
			return v5EA6TqHX3s4jzBMk(u"ࡉࡥࡱࡹࡥਡ")
		elif len(wlfZEzuRyYLvrp)==vvHpKfcqRnrFzjG(u"࠴৾"): GOtNfU3xQFkEhPouwA = BmcLzCFjuIrZP5fwXH18aN6YS(u"࠴৿")
		elif len(wlfZEzuRyYLvrp)>RqldvxFuM5GEQ2HAz93o7afBb0(u"࠶਀"):
			GOtNfU3xQFkEhPouwA = CnKwdteDG5BE8MTRhUpYIJm3NLrSgq(T6wRistc1SCo4hqObgumK(u"ࠬอฮหำࠣห้๋ไโࠢส่๊์วิสࠪॻ"), wlfZEzuRyYLvrp)
			if GOtNfU3xQFkEhPouwA == -V2RbfGOBdcA6l8NTsPWzEyvS7(u"࠷ਁ") :
				gj7BGM5t3RZpA0vNixLqzwualb16(WMkAjB1RgN7q(u"࠭สๆࠢศ่฿อมࠡษ็ฮา๋๊ๅࠩॼ"),jx7s8T0BFgODXLMzIYedf(u"ࠧࠨॽ"))
				return BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࡊࡦࡲࡳࡦਢ")
		bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = QQ2cE1FjUyxPonbDhaTkV6B3i[GOtNfU3xQFkEhPouwA]
	KdfIHhJmEXFqbPj4 = BmcLzCFjuIrZP5fwXH18aN6YS(u"࠰ਂ")
	if OzADck17lfuHqG2SYi==T6wRistc1SCo4hqObgumK(u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧॾ"):
		AgY9Coc1NDyZHTjFQ2 = AgY9Coc1NDyZHTjFQ2.rsplit(BoWHNb9daQVCF16A(u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨॿ"))[EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠱ਃ")]+QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠪ࠲ࡲࡶ࠴ࠨঀ")
		JgLvsu6wx9n3VbQhk7KXylHm = mORwgTnXBdQ7iCSHKf(f9Oum6c0FotxYn,LgpdP3UjFRnlX(u"ࠫࡌࡋࡔࠨঁ"),bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠬ࠭ং"),LM6unUr13ZYpOfPRkNXHE,V2RbfGOBdcA6l8NTsPWzEyvS7(u"࠭ࠧঃ"),sRth5giAQzWlEVm7JOX(u"ࠧࠨ঄"),YB5xyI7MaRslVpv(u"ࠨࡆࡒ࡛ࡓࡒࡏࡂࡆ࠰ࡈࡔ࡝ࡎࡍࡑࡄࡈࡤ࡜ࡉࡅࡇࡒ࠱࠶ࡹࡴࠨঅ"))
		th8PjD1H65esM3 = JgLvsu6wx9n3VbQhk7KXylHm.content
		NVHrZsqUp2 = My7Dwqvs6bfGNSIgX.findall(BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠩࠦࡉ࡝࡚ࡉࡏࡈ࠽࠲࠯ࡅ࡛࡝ࡰ࡟ࡶࡢ࠮࠮ࠫࡁࠬ࡟ࡡࡴ࡜ࡳ࡟ࠪআ"),th8PjD1H65esM3+BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠪࡠࡳࡢࡲࠨই"),My7Dwqvs6bfGNSIgX.DOTALL)
		if not NVHrZsqUp2:
			Lmj1pfQk63XdoeH(BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩঈ"),Dwl0N6FKuVU8nB1mbisIrCzdO(baNWS6nfqTC5iX4Kl)+vvHpKfcqRnrFzjG(u"ࠬࠦࠠࠡࡖ࡫ࡩࠥࡳ࠳ࡶ࠺ࠣࡪ࡮ࡲࡥࠡࡦ࡬ࡨࠥࡴ࡯ࡵࠢ࡫ࡥࡻ࡫ࠠࡵࡪࡨࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩࠦ࡬ࡪࡰ࡮ࡷࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨউ")+bJEs4IVAPdyUrhwCLv9k2YoOl8nt1+LgpdP3UjFRnlX(u"࠭ࠠ࡞ࠩঊ"))
			return v5EA6TqHX3s4jzBMk(u"ࡋࡧ࡬ࡴࡧਣ")
		BoEFz2WhUyvTgDeiZ = NVHrZsqUp2[nr5mZG89ICi6cgt4MfLJa0(u"࠲਄")]
		if not BoEFz2WhUyvTgDeiZ.startswith(rbjsM8cRFiuA1(u"ࠧࡩࡶࡷࡴࠬঋ")):
			if BoEFz2WhUyvTgDeiZ.startswith(rbjsM8cRFiuA1(u"ࠨ࠱࠲ࠫঌ")): BoEFz2WhUyvTgDeiZ = bJEs4IVAPdyUrhwCLv9k2YoOl8nt1.split(v5EA6TqHX3s4jzBMk(u"ࠩ࠽ࠫ঍"),rbjsM8cRFiuA1(u"࠴ਅ"))[BoWHNb9daQVCF16A(u"࠴ਆ")]+EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠪ࠾ࠬ঎")+BoEFz2WhUyvTgDeiZ
			elif BoEFz2WhUyvTgDeiZ.startswith(l0WAe1f7Bpi5ZXk(u"ࠫ࠴࠭এ")): BoEFz2WhUyvTgDeiZ = ooq2D9xF8ZLpPBs(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,fY5wTlhtnOc0Er6sdy4k87b(u"ࠬࡻࡲ࡭ࠩঐ"))+BoEFz2WhUyvTgDeiZ
			else: BoEFz2WhUyvTgDeiZ = bJEs4IVAPdyUrhwCLv9k2YoOl8nt1.rsplit(WMkAjB1RgN7q(u"࠭࠯ࠨ঑"),BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"࠶ਇ"))[k5dztomYyN3H(u"࠶ਈ")]+BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠧ࠰ࠩ঒")+BoEFz2WhUyvTgDeiZ
		JgLvsu6wx9n3VbQhk7KXylHm = jYUlINd7Vk09LBeZFrunTaSgG.request(BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠨࡉࡈࡘࠬও"),BoEFz2WhUyvTgDeiZ,headers=LM6unUr13ZYpOfPRkNXHE,verify=V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࡌࡡ࡭ࡵࡨਤ"))
		zFIG8jTs0JOE = JgLvsu6wx9n3VbQhk7KXylHm.content
		SHasPO7bxeRIvlTAF3cE1NDntp = len(zFIG8jTs0JOE)
		uUTvk6wEFlXW = len(NVHrZsqUp2)
		KdfIHhJmEXFqbPj4 = SHasPO7bxeRIvlTAF3cE1NDntp*uUTvk6wEFlXW
	else:
		SHasPO7bxeRIvlTAF3cE1NDntp = vvHpKfcqRnrFzjG(u"࠱ਉ")*dCyLYDlUz6WwrkEIxuRj
		JgLvsu6wx9n3VbQhk7KXylHm = jYUlINd7Vk09LBeZFrunTaSgG.request(YB5xyI7MaRslVpv(u"ࠩࡊࡉ࡙࠭ঔ"),bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,headers=LM6unUr13ZYpOfPRkNXHE,verify=C2jP0iLNGKnHu9xp(u"ࡇࡣ࡯ࡷࡪਦ"),stream=hhlbF1Sns5TrEN8QPCYmL4(u"ࡔࡳࡷࡨਥ"))
		if jx7s8T0BFgODXLMzIYedf(u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱ࡑ࡫࡮ࡨࡶ࡫ࠫক") in JgLvsu6wx9n3VbQhk7KXylHm.headers: KdfIHhJmEXFqbPj4 = int(JgLvsu6wx9n3VbQhk7KXylHm.headers[PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲ࡒࡥ࡯ࡩࡷ࡬ࠬখ")])
		uUTvk6wEFlXW = int(KdfIHhJmEXFqbPj4//SHasPO7bxeRIvlTAF3cE1NDntp)
	JnHuUOtVDhkXziPWj8YIRr = int(KdfIHhJmEXFqbPj4//dCyLYDlUz6WwrkEIxuRj)+v5EA6TqHX3s4jzBMk(u"࠲ਊ")
	if KdfIHhJmEXFqbPj4<WMkAjB1RgN7q(u"࠴࠴࠴࠵࠶਋"):
		Lmj1pfQk63XdoeH(BmcLzCFjuIrZP5fwXH18aN6YS(u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪগ"),Dwl0N6FKuVU8nB1mbisIrCzdO(baNWS6nfqTC5iX4Kl)+gItVahxL0w(u"࡙࠭ࠠࠡࠢ࡭ࡩ࡫࡯ࠡࡨ࡬ࡰࡪࠦࡩࡴࠢࡷࡳࡴࠦࡳ࡮ࡣ࡯ࡰࠥࡵࡲࠡ࡫ࡷࠤ࡮ࡹࠠ࡮࠵ࡸ࠼ࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨঘ")+bJEs4IVAPdyUrhwCLv9k2YoOl8nt1+WMkAjB1RgN7q(u"ࠧࠡ࡟ࠣࠤࠥ࡜ࡩࡥࡧࡲࠤ࡫࡯࡬ࡦࠢࡶ࡭ࡿ࡫࠺ࠡ࡝ࠣࠫঙ")+str(JnHuUOtVDhkXziPWj8YIRr)+NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠨࠢࡐࡆࠥࡣࠠࠡࠢࡄࡺࡦ࡯࡬ࡢࡤ࡯ࡩࠥࡹࡩࡻࡧ࠽ࠤࡠࠦࠧচ")+str(DpI3Fd9nGjs5POgcmtHTRZ)+T6wRistc1SCo4hqObgumK(u"ࠩࠣࡑࡇࠦ࡝ࠡࠢࠣࡊ࡮ࡲࡥ࠻ࠢ࡞ࠤࠬছ")+AgY9Coc1NDyZHTjFQ2+PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠪࠤࡢ࠭জ"))
		ZIOHgA3z0TBR(UnWjVbo503mEMv9KF(u"ࠫࠬঝ"),jx7s8T0BFgODXLMzIYedf(u"ࠬ࠭ঞ"),QynMHGWA0blfqTUdxRh5Jzi2t(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩট"),k5dztomYyN3H(u"ࠧโึ็ࠤๆ๐ࠠๆ฻ิๅฮࠦออ็้้ࠣ็ࠠศๆไ๎ิ๐่ࠡล๋ࠤฬ๊ๅๅใูࠣ฿๐ัࠡฮาหࠥ๎ไ่าสࠤ้อ๋ࠠ็ๆ๊๊ࠥไษำ้ห๊าࠠหฯ่๎้ࠦ็ัษࠣห้๋ไโࠩঠ"))
		return hhlbF1Sns5TrEN8QPCYmL4(u"ࡈࡤࡰࡸ࡫ਧ")
	nmSbxlsPL2OhC46 = BmcLzCFjuIrZP5fwXH18aN6YS(u"࠷࠴࠵਌")
	IDBdbSg5Vl6K = DpI3Fd9nGjs5POgcmtHTRZ-JnHuUOtVDhkXziPWj8YIRr
	if IDBdbSg5Vl6K<nmSbxlsPL2OhC46:
		Lmj1pfQk63XdoeH(BoWHNb9daQVCF16A(u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭ড"),Dwl0N6FKuVU8nB1mbisIrCzdO(baNWS6nfqTC5iX4Kl)+jx7s8T0BFgODXLMzIYedf(u"ࠩࠣࠤࠥࡔ࡯ࡵࠢࡨࡲࡴࡻࡧࡩࠢࡧ࡭ࡸࡱࠠࡴࡲࡤࡧࡪࠦࡴࡰࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤࡹ࡮ࡥࠡࡸ࡬ࡨࡪࡵࠠࡧ࡫࡯ࡩࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨঢ")+bJEs4IVAPdyUrhwCLv9k2YoOl8nt1+PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠪࠤࡢࠦࠠࠡࡘ࡬ࡨࡪࡵࠠࡧ࡫࡯ࡩࠥࡹࡩࡻࡧ࠽ࠤࡠࠦࠧণ")+str(JnHuUOtVDhkXziPWj8YIRr)+V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠫࠥࡓࡂࠡ࡟ࠣࠤࠥࡇࡶࡢ࡫࡯ࡥࡧࡲࡥࠡࡵ࡬ࡾࡪࡀࠠ࡜ࠢࠪত")+str(DpI3Fd9nGjs5POgcmtHTRZ)+WMkAjB1RgN7q(u"ࠬࠦࡍࡃࠢ࠰ࠤࠬথ")+str(nmSbxlsPL2OhC46)+EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠭ࠠࡎࡄࠣࡡࠥࠦࠠࡇ࡫࡯ࡩ࠿࡛ࠦࠡࠩদ")+AgY9Coc1NDyZHTjFQ2+v5EA6TqHX3s4jzBMk(u"ࠧࠡ࡟ࠪধ"))
		ZIOHgA3z0TBR(BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠨࠩন"),BoWHNb9daQVCF16A(u"ࠩࠪ঩"),QynMHGWA0blfqTUdxRh5Jzi2t(u"่ࠪฬ๊้ࠦฮาࠤู๊วฮหࠣ็ฬ็๊สࠢ็่ฯำๅ๋ๆࠪপ"),BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠫฬ๊ๅๅใࠣห้๋ืๅ๊หࠤฯำๅ๋ๆ๊ࠤาาๅ่ࠢࠪফ")+str(JnHuUOtVDhkXziPWj8YIRr)+BoWHNb9daQVCF16A(u"ࠬࠦๅ๋฼สฬฬ๐ส๊ࠡฯ๋ฬุใࠡใํ๋๋ࠥำศฯฬࠤๆอั฻หࠣࠫব")+str(DpI3Fd9nGjs5POgcmtHTRZ)+RqldvxFuM5GEQ2HAz93o7afBb0(u"࠭ࠠๆ์฽หออ๊ห๋่้๋ࠢอศใ฻อࠥ฿ไ๊ࠢ฼้้ࠦฬ่ษี็ࠥฮฯู้่้ࠣอใๅࠢํะอࠦลษไสลࠥ࠭ভ")+str(nmSbxlsPL2OhC46)+BoWHNb9daQVCF16A(u"ࠧࠡ็ํ฾ฬฮว๋ฬࠣๅฬืฺสࠢาหห๋ว๊๊ࠡิฬࠦๅฺ่ส๋ࠥษๆࠡฮ๊หื้ࠠๅษࠣฮําฯࠡใํ๋๋ࠥำศฯฬࠤ่อแ๋ห่ࠣฯำๅ๋ๆ้้ࠣ็ࠠศๆไ๎ิ๐่ࠡษ็้฼๊่ษࠩম"))
		return QynMHGWA0blfqTUdxRh5Jzi2t(u"ࡉࡥࡱࡹࡥਨ")
	tLwvQlnjGpWsRVCN1 = mmwySO1P4jnKz5(NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨয"),UnWjVbo503mEMv9KF(u"ࠩࠪর"),sRth5giAQzWlEVm7JOX(u"ࠪࠫ঱"),C2jP0iLNGKnHu9xp(u"ࠫ์๊ࠠหำํำࠥะอๆ์็ࠤฬ๊ๅๅใࠣรࠬল"),v5EA6TqHX3s4jzBMk(u"ࠬอไๆๆไࠤฬ๊ๅุๆ๋ฬࠥำฬๆ้ࠣฮ็ื๊ษษࠣࠫ঳")+str(JnHuUOtVDhkXziPWj8YIRr)+b05yftsZ6NYgIKP(u"࠭ࠠๆ์฽หออ๊ห๋ࠢะ์อาไࠢไ๎์ࠦๅิษะอࠥ็วา฼ฬࠤฯ่ั๋สสࠤࠬ঴")+str(DpI3Fd9nGjs5POgcmtHTRZ)+k5dztomYyN3H(u"ࠧࠡ็ํ฾ฬฮว๋ฬࠣ์์ึวࠡษ็้้็ࠠใัࠣ๎าะวอࠢห฽฻ࠦวๅ๊ๅฮ๊ࠥไหฯ่๎้ࠦๅ็ࠢส่ส์สา่อࠤส๊้ࠡฮ๊หื้ࠠ࠯๊่ࠢࠥอๆห่ࠢฮศ้ฯ๊ࠡอี๏ีࠠศๆสืฯ๋ัศำࠣฬฯำๅ๋ๆ้้ࠣ็ࠠศๆไ๎ิ๐่ࠡมࠪ঵"))
	if tLwvQlnjGpWsRVCN1!=C2dgEDAKQGsvh(u"࠵਍"):
		ZIOHgA3z0TBR(l0WAe1f7Bpi5ZXk(u"ࠨࠩশ"),qbPw1d3KimF(u"ࠩࠪষ"),RqldvxFuM5GEQ2HAz93o7afBb0(u"ࠪࠫস"),BoWHNb9daQVCF16A(u"ࠫฯ๋ࠠฦๆ฽หฦูࠦๆๆํอࠥะอๆ์็ࠤ๊๊แࠡษ็ๅ๏ี๊้ࠩহ"))
		Lmj1pfQk63XdoeH(k5dztomYyN3H(u"ࠬࡔࡏࡕࡋࡆࡉࠬ঺"),Dwl0N6FKuVU8nB1mbisIrCzdO(baNWS6nfqTC5iX4Kl)+FGDJwkEbTB5SoXujs3f(u"࠭ࠠࠡࠢࡘࡷࡪࡸࠠࡳࡧࡩࡹࡸ࡫ࡤࠡࡶࡲࠤࡸࡺࡡࡳࡶࠣࡸ࡭࡫ࠠࡥࡱࡺࡲࡱࡵࡡࡥࠢࡲࡪࠥࡺࡨࡦࠢࡹ࡭ࡩ࡫࡯ࠡࡨ࡬ࡰࡪࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ঻")+bJEs4IVAPdyUrhwCLv9k2YoOl8nt1+jx7s8T0BFgODXLMzIYedf(u"ࠧࠡ࡟ࠣࠤࠥࡌࡩ࡭ࡧ࠽ࠤࡠ়ࠦࠧ")+AgY9Coc1NDyZHTjFQ2+vvHpKfcqRnrFzjG(u"ࠨࠢࡠࠫঽ"))
		return k5dztomYyN3H(u"ࡊࡦࡲࡳࡦ਩")
	Lmj1pfQk63XdoeH(BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠩࡑࡓ࡙ࡏࡃࡆࠩা"),Dwl0N6FKuVU8nB1mbisIrCzdO(baNWS6nfqTC5iX4Kl)+l0WAe1f7Bpi5ZXk(u"ࠪࠤࠥࠦࡄࡰࡹࡱࡰࡴࡧࡤࠡࡵࡷࡥࡷࡺࡥࡥࠢࡶࡹࡨࡩࡥࡴࡵࡩࡹࡱࡲࡹࠨি"))
	hensWGjium8DSy3aVQEOdR95t = YYAhEtvLi5CnyHxIjJled3wWTO()
	hensWGjium8DSy3aVQEOdR95t.create(AgY9Coc1NDyZHTjFQ2,UnWjVbo503mEMv9KF(u"ࠫฬ๊ำุำࠣๅํ่่๊้่ࠠࠣอๆࠡฬัึ๏์ࠠๆๆไࠤฬ๊แ๋ัํ์ࠬী"))
	rIwQRdXoub4F7qjkxJe0Cya2tKOl = v5EA6TqHX3s4jzBMk(u"࡙ࡸࡵࡦਪ")
	TTLQDONupiB6q = KBxPW9cX8dqtaUDG.time()
	if BLz7m2RkNrxXQwy1cGAp: WnKdiOw8u9XoI = open(AgY9Coc1NDyZHTjFQ2,jSu5Cg2Ub1OAkZVs8Yoz(u"ࠬࡽࡢࠨু"))
	else: WnKdiOw8u9XoI = open(AgY9Coc1NDyZHTjFQ2.decode(NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"࠭ࡵࡵࡨ࠻ࠫূ")),jx7s8T0BFgODXLMzIYedf(u"ࠧࡸࡤࠪৃ"))
	if OzADck17lfuHqG2SYi==YB5xyI7MaRslVpv(u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧৄ"):
		for k3Om08MCgqQao4n1 in range(EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠶਎"),uUTvk6wEFlXW+EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠶਎")):
			BoEFz2WhUyvTgDeiZ = NVHrZsqUp2[k3Om08MCgqQao4n1-T6wRistc1SCo4hqObgumK(u"࠷ਏ")]
			if not BoEFz2WhUyvTgDeiZ.startswith(rbjsM8cRFiuA1(u"ࠩ࡫ࡸࡹࡶࠧ৅")):
				if BoEFz2WhUyvTgDeiZ.startswith(BoWHNb9daQVCF16A(u"ࠪ࠳࠴࠭৆")): BoEFz2WhUyvTgDeiZ = bJEs4IVAPdyUrhwCLv9k2YoOl8nt1.split(NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠫ࠿࠭ে"),qbPw1d3KimF(u"࠱ਐ"))[hhlbF1Sns5TrEN8QPCYmL4(u"࠱਑")]+V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠬࡀࠧৈ")+BoEFz2WhUyvTgDeiZ
				elif BoEFz2WhUyvTgDeiZ.startswith(rbjsM8cRFiuA1(u"࠭࠯ࠨ৉")): BoEFz2WhUyvTgDeiZ = ooq2D9xF8ZLpPBs(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,jSu5Cg2Ub1OAkZVs8Yoz(u"ࠧࡶࡴ࡯ࠫ৊"))+BoEFz2WhUyvTgDeiZ
				else: BoEFz2WhUyvTgDeiZ = bJEs4IVAPdyUrhwCLv9k2YoOl8nt1.rsplit(jx7s8T0BFgODXLMzIYedf(u"ࠨ࠱ࠪো"),sRth5giAQzWlEVm7JOX(u"࠳਒"))[jx7s8T0BFgODXLMzIYedf(u"࠳ਓ")]+WMkAjB1RgN7q(u"ࠩ࠲ࠫৌ")+BoEFz2WhUyvTgDeiZ
			JgLvsu6wx9n3VbQhk7KXylHm = jYUlINd7Vk09LBeZFrunTaSgG.request(rbjsM8cRFiuA1(u"ࠪࡋࡊ্࡚ࠧ"),BoEFz2WhUyvTgDeiZ,headers=LM6unUr13ZYpOfPRkNXHE,verify=gItVahxL0w(u"ࡌࡡ࡭ࡵࡨਫ"))
			zFIG8jTs0JOE = JgLvsu6wx9n3VbQhk7KXylHm.content
			JgLvsu6wx9n3VbQhk7KXylHm.close()
			WnKdiOw8u9XoI.write(zFIG8jTs0JOE)
			C91C3dcMhJDkRX = KBxPW9cX8dqtaUDG.time()
			EEplCINHGS0dKg9qWAk = C91C3dcMhJDkRX-TTLQDONupiB6q
			FqLUH1CDt32MkpZP7GTY8XaExQ = EEplCINHGS0dKg9qWAk//k3Om08MCgqQao4n1
			VIywlS0ta19Av4CeNP3M = FqLUH1CDt32MkpZP7GTY8XaExQ*(uUTvk6wEFlXW+BmcLzCFjuIrZP5fwXH18aN6YS(u"࠵ਔ"))
			ziQseSI9WPl4fYJTyChKr3wMN2m6k = VIywlS0ta19Av4CeNP3M-EEplCINHGS0dKg9qWAk
			M3QI1bliHdj7poRFV2OG(hensWGjium8DSy3aVQEOdR95t,int(EAc8h2sINroQYvR3WH06Ji7MVpn(u"࠷࠰࠱ਖ")*k3Om08MCgqQao4n1//(uUTvk6wEFlXW+rbjsM8cRFiuA1(u"࠶ਕ"))),WMkAjB1RgN7q(u"ࠫฬ๊ำุำࠣๅํ่่๊้่ࠠࠣอๆࠡฬัึ๏์ࠠๆๆไࠤฬ๊แ๋ัํ์ࠬৎ"),NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠬาไษ่่ࠢๆࠦวๅใํำ๏๎࠺࠮ࠢส่ัุมࠡำๅ้ࠬ৏"),str(k3Om08MCgqQao4n1*SHasPO7bxeRIvlTAF3cE1NDntp//dCyLYDlUz6WwrkEIxuRj)+BmcLzCFjuIrZP5fwXH18aN6YS(u"࠭࠯ࠨ৐")+str(JnHuUOtVDhkXziPWj8YIRr)+v5EA6TqHX3s4jzBMk(u"ࠧࠡࡏࡅࠤ้ࠥࠦࠠไอࠤ๊ะศใ์࠽ࠤࠬ৑")+KBxPW9cX8dqtaUDG.strftime(b05yftsZ6NYgIKP(u"ࠣࠧࡋ࠾ࠪࡓ࠺ࠦࡕࠥ৒"),KBxPW9cX8dqtaUDG.gmtime(ziQseSI9WPl4fYJTyChKr3wMN2m6k))+UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠩࠣไࠬ৓"))
			if hensWGjium8DSy3aVQEOdR95t.iscanceled():
				rIwQRdXoub4F7qjkxJe0Cya2tKOl = BmcLzCFjuIrZP5fwXH18aN6YS(u"ࡆࡢ࡮ࡶࡩਬ")
				break
	else:
		k3Om08MCgqQao4n1 = FGDJwkEbTB5SoXujs3f(u"࠰ਗ")
		for zFIG8jTs0JOE in JgLvsu6wx9n3VbQhk7KXylHm.iter_content(chunk_size=SHasPO7bxeRIvlTAF3cE1NDntp):
			WnKdiOw8u9XoI.write(zFIG8jTs0JOE)
			k3Om08MCgqQao4n1 = k3Om08MCgqQao4n1+v5EA6TqHX3s4jzBMk(u"࠲ਘ")
			C91C3dcMhJDkRX = KBxPW9cX8dqtaUDG.time()
			EEplCINHGS0dKg9qWAk = C91C3dcMhJDkRX-TTLQDONupiB6q
			FqLUH1CDt32MkpZP7GTY8XaExQ = EEplCINHGS0dKg9qWAk/k3Om08MCgqQao4n1
			VIywlS0ta19Av4CeNP3M = FqLUH1CDt32MkpZP7GTY8XaExQ*(uUTvk6wEFlXW+YB5xyI7MaRslVpv(u"࠳ਙ"))
			ziQseSI9WPl4fYJTyChKr3wMN2m6k = VIywlS0ta19Av4CeNP3M-EEplCINHGS0dKg9qWAk
			M3QI1bliHdj7poRFV2OG(hensWGjium8DSy3aVQEOdR95t,int(UnWjVbo503mEMv9KF(u"࠵࠵࠶ਛ")*k3Om08MCgqQao4n1/(uUTvk6wEFlXW+jSu5Cg2Ub1OAkZVs8Yoz(u"࠴ਚ"))),LgpdP3UjFRnlX(u"ࠪหู้ืาࠢไ์็ࠦ็้่ࠢ็ฬ์ࠠหะี๎๋ࠦๅๅใࠣห้็๊ะ์๋ࠫ৔"),k5dztomYyN3H(u"ࠫั๊ศࠡ็็ๅࠥอไโ์า๎ํࡀ࠭ࠡษ็ะืวࠠาไ่ࠫ৕"),str(k3Om08MCgqQao4n1*SHasPO7bxeRIvlTAF3cE1NDntp//dCyLYDlUz6WwrkEIxuRj)+jSu5Cg2Ub1OAkZVs8Yoz(u"ࠬ࠵ࠧ৖")+str(JnHuUOtVDhkXziPWj8YIRr)+gItVahxL0w(u"࠭ࠠࡎࡄࠣࠤ่ࠥࠦใฬ้ࠣฯฮโ๋࠼ࠣࠫৗ")+KBxPW9cX8dqtaUDG.strftime(jSu5Cg2Ub1OAkZVs8Yoz(u"ࠢࠦࡊ࠽ࠩࡒࡀࠥࡔࠤ৘"),KBxPW9cX8dqtaUDG.gmtime(ziQseSI9WPl4fYJTyChKr3wMN2m6k))+EAc8h2sINroQYvR3WH06Ji7MVpn(u"ࠨࠢใࠫ৙"))
			if hensWGjium8DSy3aVQEOdR95t.iscanceled():
				rIwQRdXoub4F7qjkxJe0Cya2tKOl = WMkAjB1RgN7q(u"ࡇࡣ࡯ࡷࡪਭ")
				break
		JgLvsu6wx9n3VbQhk7KXylHm.close()
	WnKdiOw8u9XoI.close()
	hensWGjium8DSy3aVQEOdR95t.close()
	if not rIwQRdXoub4F7qjkxJe0Cya2tKOl:
		Lmj1pfQk63XdoeH(WMkAjB1RgN7q(u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ৚"),Dwl0N6FKuVU8nB1mbisIrCzdO(baNWS6nfqTC5iX4Kl)+vvHpKfcqRnrFzjG(u"ࠪࠤࠥࠦࡕࡴࡧࡵࠤࡨࡧ࡮ࡤࡧ࡯ࡩࡩ࠵ࡩ࡯ࡶࡨࡶࡷࡻࡰࡵࡧࡧࠤࡹ࡮ࡥࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࠣࡴࡷࡵࡣࡦࡵࡶࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ৛")+bJEs4IVAPdyUrhwCLv9k2YoOl8nt1+UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠫࠥࡣࠠࠡࠢࡉ࡭ࡱ࡫࠺ࠡ࡝ࠣࠫড়")+AgY9Coc1NDyZHTjFQ2+C2jP0iLNGKnHu9xp(u"ࠬࠦ࡝ࠨঢ়"))
		ZIOHgA3z0TBR(C2jP0iLNGKnHu9xp(u"࠭ࠧ৞"),UxS67uoGThbMwnfNRzy4gajLd23JH(u"ࠧࠨয়"),C2jP0iLNGKnHu9xp(u"ࠨࠩৠ"),YB5xyI7MaRslVpv(u"ࠩอ้ࠥหไ฻ษฤࠤ฾๋ไ๋หࠣฮา๋๊ๅ่่ࠢๆࠦวๅใํำ๏๎ࠧৡ"))
		return l0WAe1f7Bpi5ZXk(u"ࡖࡵࡹࡪਮ")
	Lmj1pfQk63XdoeH(BK9OvRSjZbtx7kYyop1u6zrE2QeiFI(u"ࠪࡒࡔ࡚ࡉࡄࡇࠪৢ"),Dwl0N6FKuVU8nB1mbisIrCzdO(baNWS6nfqTC5iX4Kl)+vvHpKfcqRnrFzjG(u"ࠫࠥࠦࠠࡗ࡫ࡧࡩࡴࠦࡦࡪ࡮ࡨࠤࡩࡵࡷ࡯࡮ࡲࡥࡩ࡫ࡤࠡࡵࡸࡧࡨ࡫ࡳࡴࡨࡸࡰࡱࡿࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪৣ")+bJEs4IVAPdyUrhwCLv9k2YoOl8nt1+BoWHNb9daQVCF16A(u"ࠬࠦ࡝ࠡࠢࠣࡊ࡮ࡲࡥ࠻ࠢ࡞ࠤࠬ৤")+AgY9Coc1NDyZHTjFQ2+vvHpKfcqRnrFzjG(u"࠭ࠠ࡞ࠩ৥"))
	ZIOHgA3z0TBR(V2RbfGOBdcA6l8NTsPWzEyvS7(u"ࠧࠨ০"),QynMHGWA0blfqTUdxRh5Jzi2t(u"ࠨࠩ১"),NB6ZDMqe91yfKQ240WpbIntjxiY5z(u"ࠩࠪ২"),PPNA7jWqZgDnXKVvtuai1kQdsEoMb0(u"ࠪฮ๊ࠦสฮ็ํ่๋ࠥไโࠢส่ๆ๐ฯ๋๊ࠣฬ๋าวฮࠩ৩"))
	return v5EA6TqHX3s4jzBMk(u"ࡗࡶࡺ࡫ਯ")
# -*- coding: utf-8 -*-
from G6AHskJeqN import *
baNWS6nfqTC5iX4Kl = 'FAJERSHOW'
teUPLFC3B8bArakwHVGsdhoIWDM49f = '_FJS_'
EZxQp1WOldMTvFU = AK5RqLhji4W1wt9VdrCD3PGeQM[baNWS6nfqTC5iX4Kl][0]
eh2tDvRFWpLQI = ['التصنيفات','انشاء حساب','طلبات الزوّار']
def VbgEajY4Bt2COpGDcPqI(mode,url,text):
	if   mode==390: ft3e2JBKQVXWlFPjaMhkEqGxvDg = eN02L7Tf5bQ()
	elif mode==391: ft3e2JBKQVXWlFPjaMhkEqGxvDg = sscM839DP1jWZ4zl6uIx0Kyn(url,text)
	elif mode==392: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HDxCnPKFhITpZmOsA4a0UL6(url)
	elif mode==393: ft3e2JBKQVXWlFPjaMhkEqGxvDg = o4oY13v5dWMcbilEDjKCnXNzHZ0(url)
	elif mode==399: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HjZcUIVAXFCqy9TfBWKtgY2(text)
	else: ft3e2JBKQVXWlFPjaMhkEqGxvDg = False
	return ft3e2JBKQVXWlFPjaMhkEqGxvDg
def eN02L7Tf5bQ():
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'بحث في الموقع','',399,'','','_REMEMBERRESULTS_')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(IIiPCruL6dT8s1lqj47SzpVHnYNm,'GET',EZxQp1WOldMTvFU,'','','','','FAJERSHOW-MENU-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	items = My7Dwqvs6bfGNSIgX.findall('<header>.*?<h2>(.*?)<',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	for DQlGE75goqn9fkJt0P8ihR in range(len(items)):
		title = items[DQlGE75goqn9fkJt0P8ihR]
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+title,EZxQp1WOldMTvFU,391,'','','latest'+str(DQlGE75goqn9fkJt0P8ihR))
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'مختارات عشوائية',EZxQp1WOldMTvFU,391,'','','randoms')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'أعلى الأفلام تقييماً',EZxQp1WOldMTvFU,391,'','','top_imdb_movies')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'أعلى المسلسلات تقييماً',EZxQp1WOldMTvFU,391,'','','top_imdb_series')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'أفلام مميزة',EZxQp1WOldMTvFU+'/movies',391,'','','featured_movies')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'مسلسلات مميزة',EZxQp1WOldMTvFU+'/tvshows',391,'','','featured_tvshows')
	vsptNMP2ZQC = ''
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('class="menu"(.*?)id="contenedor"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K: vsptNMP2ZQC += XBuP6Op7y4K[0]
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(IIiPCruL6dT8s1lqj47SzpVHnYNm,'GET',EZxQp1WOldMTvFU+'/movies','','','','','FAJERSHOW-MENU-2nd')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('class="releases"(.*?)aside',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K: vsptNMP2ZQC += XBuP6Op7y4K[0]
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)">(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	lErmvOQ4B6 = True
	for BoEFz2WhUyvTgDeiZ,title in items:
		title = PIfAumbGicwg5ye(title)
		if title=='الأعلى مشاهدة':
			if lErmvOQ4B6:
				title = 'الافلام '+title
				lErmvOQ4B6 = False
			else: title = 'المسلسلات '+title
		if title not in eh2tDvRFWpLQI:
			if title=='أفلام': VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+title,EZxQp1WOldMTvFU+'/movies',391,'','','all_movies_tvshows')
			elif title=='مسلسلات': VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+title,EZxQp1WOldMTvFU+'/tvshows',391,'','','all_movies_tvshows')
			else: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,391)
	return MK6ZT2zjC1SbmveNFqor
def sscM839DP1jWZ4zl6uIx0Kyn(url,type):
	vsptNMP2ZQC,items = [],[]
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'','','','','FAJERSHOW-TITLES-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	if type in ['featured_movies','featured_tvshows']:
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('class="content"(.*?)id="archive-content"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if XBuP6Op7y4K: vsptNMP2ZQC = XBuP6Op7y4K[0]
	elif type=='all_movies_tvshows':
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('id="archive-content"(.*?)class="pagination"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if XBuP6Op7y4K: vsptNMP2ZQC = XBuP6Op7y4K[0]
	elif type=='top_imdb_movies':
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall("class='top-imdb-list tleft(.*?)class='top-imdb-list tright",MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if XBuP6Op7y4K:
			vsptNMP2ZQC = XBuP6Op7y4K[0]
			items = My7Dwqvs6bfGNSIgX.findall("img src='(.*?)'.*?href='(.*?)'>(.*?)<",vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	elif type=='top_imdb_series':
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall("class='top-imdb-list tright(.*?)footer",MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if XBuP6Op7y4K:
			vsptNMP2ZQC = XBuP6Op7y4K[0]
			items = My7Dwqvs6bfGNSIgX.findall("img src='(.*?)'.*?href='(.*?)'>(.*?)<",vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	elif type=='search':
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('class="search-page"(.*?)class="sidebar',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if XBuP6Op7y4K:
			vsptNMP2ZQC = XBuP6Op7y4K[0]
			items = My7Dwqvs6bfGNSIgX.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	elif type=='sider':
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('class="widget(.*?)class="widget',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		nRxp0IUZQB9cgqy6f7A5Xa = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?img src="(.*?)".*?<h3>(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		QQ2cE1FjUyxPonbDhaTkV6B3i,zY4Ib2VUSPeFEJMy9Rtij,wlfZEzuRyYLvrp = zip(*nRxp0IUZQB9cgqy6f7A5Xa)
		items = zip(zY4Ib2VUSPeFEJMy9Rtij,QQ2cE1FjUyxPonbDhaTkV6B3i,wlfZEzuRyYLvrp)
	elif type=='randoms':
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('id="slider-movies-tvshows"(.*?)<header>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	elif 'latest' in type:
		DQlGE75goqn9fkJt0P8ihR = int(type[-1:])
		MK6ZT2zjC1SbmveNFqor = MK6ZT2zjC1SbmveNFqor.replace('<header>','<end><start>')
		MK6ZT2zjC1SbmveNFqor = MK6ZT2zjC1SbmveNFqor.replace('</div></div></div>','</div></div></div><end>')
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('<start>(.*?)<end>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		vsptNMP2ZQC = XBuP6Op7y4K[DQlGE75goqn9fkJt0P8ihR]
		if DQlGE75goqn9fkJt0P8ihR==6:
			nRxp0IUZQB9cgqy6f7A5Xa = My7Dwqvs6bfGNSIgX.findall('img src="(.*?)" alt="(.*?)".*?href="(.*?)"',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
			zY4Ib2VUSPeFEJMy9Rtij,wlfZEzuRyYLvrp,QQ2cE1FjUyxPonbDhaTkV6B3i = zip(*nRxp0IUZQB9cgqy6f7A5Xa)
			items = zip(zY4Ib2VUSPeFEJMy9Rtij,QQ2cE1FjUyxPonbDhaTkV6B3i,wlfZEzuRyYLvrp)
	else:
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('class="content"(.*?)class="(pagination|sidebar)',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if XBuP6Op7y4K:
			vsptNMP2ZQC = XBuP6Op7y4K[0][0]
			if '/collection/' in url:
				items = My7Dwqvs6bfGNSIgX.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
			elif '/quality/' in url:
				items = My7Dwqvs6bfGNSIgX.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	if not items and vsptNMP2ZQC:
		items = My7Dwqvs6bfGNSIgX.findall('img src="(.*?)".*?href=.*?href="(.*?)">(.*?)</div>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	y7y3d5Fbhv42ONmtwLZ0SerYoQq = []
	for IcWzVO137wFvemn2QTq8yKs9,BoEFz2WhUyvTgDeiZ,title in items:
		if 'src=' in title: continue
		if 'serie' in title:
			title = My7Dwqvs6bfGNSIgX.findall('^(.*?)<.*?serie">(.*?)<',title,My7Dwqvs6bfGNSIgX.DOTALL)
			title = title[0][1]
			if title in y7y3d5Fbhv42ONmtwLZ0SerYoQq: continue
			y7y3d5Fbhv42ONmtwLZ0SerYoQq.append(title)
			title = '_MOD_'+title
		U2UaTcgBpsEZxKiRG1Xv8 = My7Dwqvs6bfGNSIgX.findall('^(.*?)<',title,My7Dwqvs6bfGNSIgX.DOTALL)
		if U2UaTcgBpsEZxKiRG1Xv8: title = U2UaTcgBpsEZxKiRG1Xv8[0]
		title = PIfAumbGicwg5ye(title)
		if '/tvshows/' in BoEFz2WhUyvTgDeiZ: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,393,IcWzVO137wFvemn2QTq8yKs9)
		elif '/episodes/' in BoEFz2WhUyvTgDeiZ: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,393,IcWzVO137wFvemn2QTq8yKs9)
		elif '/seasons/' in BoEFz2WhUyvTgDeiZ: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,393,IcWzVO137wFvemn2QTq8yKs9)
		elif '/collection/' in BoEFz2WhUyvTgDeiZ: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,391,IcWzVO137wFvemn2QTq8yKs9)
		else: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,392,IcWzVO137wFvemn2QTq8yKs9)
	if type not in ['featured_movies','featured_tvshows']:
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"pagination"(.*?)</div>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if XBuP6Op7y4K:
			vsptNMP2ZQC = XBuP6Op7y4K[0]
			items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?>(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
			for BoEFz2WhUyvTgDeiZ,title in items:
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'صفحة '+title,BoEFz2WhUyvTgDeiZ,391,'','',type)
	return
def o4oY13v5dWMcbilEDjKCnXNzHZ0(url):
	LkVZrOE4XBSN2Qex5PyHqC = ooq2D9xF8ZLpPBs(url,'url')
	url = url.replace(LkVZrOE4XBSN2Qex5PyHqC,EZxQp1WOldMTvFU)
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'','','','','FAJERSHOW-EPISODES-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	ME2Q6F7u8Vp1km9ws = My7Dwqvs6bfGNSIgX.findall('class="C rated".*?>(.*?)<',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if ME2Q6F7u8Vp1km9ws and a97xrkSOefH5DbjXunq(baNWS6nfqTC5iX4Kl,url,ME2Q6F7u8Vp1km9ws): return
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('<ul class="episodios">(.*?)</ul></div></div></div>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('src="(.*?)".*?href="(.*?)">(.*?)</a>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for IcWzVO137wFvemn2QTq8yKs9,BoEFz2WhUyvTgDeiZ,title in items:
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,392,IcWzVO137wFvemn2QTq8yKs9)
	return
def HDxCnPKFhITpZmOsA4a0UL6(url):
	MK6ZT2zjC1SbmveNFqor = MPEKR1d2NIxFWaS(UuEtImzir9,'GET',url,'','','FAJERSHOW-PLAY-1st')
	ME2Q6F7u8Vp1km9ws = My7Dwqvs6bfGNSIgX.findall('class="C rated".*?>(.*?)<',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if ME2Q6F7u8Vp1km9ws and a97xrkSOefH5DbjXunq(baNWS6nfqTC5iX4Kl,url,ME2Q6F7u8Vp1km9ws): return
	QQ2cE1FjUyxPonbDhaTkV6B3i = []
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('id="player-option-1"(.*?)class=["|\'](sheader|pag_episodes)["|\']',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0][0]
		items = My7Dwqvs6bfGNSIgX.findall('data-type="(.*?)" data-post="(.*?)" data-nume="(.*?)".*?class="vid_title">(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for type,dq7XaIVrRYujxkB0CHKtl,UsH83LzgBSAm7OYnlEc,title in items:
			BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU+'/wp-admin/admin-ajax.php?action=doo_player_ajax&post='+dq7XaIVrRYujxkB0CHKtl+'&nume='+UsH83LzgBSAm7OYnlEc+'&type='+type
			BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ+'?named='+title+'__watch'
			QQ2cE1FjUyxPonbDhaTkV6B3i.append(BoEFz2WhUyvTgDeiZ)
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('''id=["']download["'] class(.*?)class=["']sbox["']''',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('''img src=["'](.*?)["'].*?href=["'](.*?)["'].*?["']quality["']>(.*?)<.*?<td>(.*?)<''',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for IcWzVO137wFvemn2QTq8yKs9,BoEFz2WhUyvTgDeiZ,LLnUyuiC2wRM0,iOZ5nu0Y6Q4aqDUrElfIP9Tek in items:
			if '=' in IcWzVO137wFvemn2QTq8yKs9:
				rhVzNXUIOclRnkJ0uqPvxg5wi = IcWzVO137wFvemn2QTq8yKs9.split('=')[1]
				title = ooq2D9xF8ZLpPBs(rhVzNXUIOclRnkJ0uqPvxg5wi,'host')
			else: title = ''
			title = iOZ5nu0Y6Q4aqDUrElfIP9Tek+' '+title
			BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ+'?named='+title+'__download____'+LLnUyuiC2wRM0
			QQ2cE1FjUyxPonbDhaTkV6B3i.append(BoEFz2WhUyvTgDeiZ)
	import t1kDWXQVpC
	t1kDWXQVpC.rqVt2xDi7jzJHBcPMRs6h0L(QQ2cE1FjUyxPonbDhaTkV6B3i,baNWS6nfqTC5iX4Kl,'video',url)
	return
def HjZcUIVAXFCqy9TfBWKtgY2(search):
	search,LQf3AeozSrai,showDialogs = X54MLovbG8nAEkB9J(search)
	if search=='': search = ViKAIsLurq83RSENayxWb()
	if search=='': return
	search = search.replace(' ','+')
	url = EZxQp1WOldMTvFU+'/?s='+search
	sscM839DP1jWZ4zl6uIx0Kyn(url,'search')
	return
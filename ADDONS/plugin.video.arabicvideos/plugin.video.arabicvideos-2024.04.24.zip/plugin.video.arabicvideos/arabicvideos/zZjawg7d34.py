# -*- coding: utf-8 -*-
from G6AHskJeqN import *
baNWS6nfqTC5iX4Kl = 'ARBLIONZ'
headers = { 'User-Agent' : '' }
teUPLFC3B8bArakwHVGsdhoIWDM49f = '_ARL_'
EZxQp1WOldMTvFU = AK5RqLhji4W1wt9VdrCD3PGeQM[baNWS6nfqTC5iX4Kl][0]
eh2tDvRFWpLQI = ['عروض المصارعة','الكل','الرئيسية','العاب','برامج كمبيوتر','موبايل و جوال','القسم الاسلامي']
def VbgEajY4Bt2COpGDcPqI(mode,url,text):
	if   mode==200: ft3e2JBKQVXWlFPjaMhkEqGxvDg = eN02L7Tf5bQ()
	elif mode==201: ft3e2JBKQVXWlFPjaMhkEqGxvDg = sscM839DP1jWZ4zl6uIx0Kyn(url)
	elif mode==202: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HDxCnPKFhITpZmOsA4a0UL6(url)
	elif mode==203: ft3e2JBKQVXWlFPjaMhkEqGxvDg = o4oY13v5dWMcbilEDjKCnXNzHZ0(url)
	elif mode==204: ft3e2JBKQVXWlFPjaMhkEqGxvDg = LLJlTxDePyjoVKA(url,'FILTERS___'+text)
	elif mode==205: ft3e2JBKQVXWlFPjaMhkEqGxvDg = LLJlTxDePyjoVKA(url,'CATEGORIES___'+text)
	elif mode==209: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HjZcUIVAXFCqy9TfBWKtgY2(text)
	else: ft3e2JBKQVXWlFPjaMhkEqGxvDg = False
	return ft3e2JBKQVXWlFPjaMhkEqGxvDg
def eN02L7Tf5bQ():
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'بحث في الموقع','',209,'','','_REMEMBERRESULTS_')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'فلتر محدد',EZxQp1WOldMTvFU,205)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'فلتر كامل',EZxQp1WOldMTvFU,204)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'مميزة',EZxQp1WOldMTvFU+'??trending',201)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'أفلام مميزة',EZxQp1WOldMTvFU+'??trending_movies',201)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'مسلسلات مميزة',EZxQp1WOldMTvFU+'??trending_series',201)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'الصفحة الرئيسية',EZxQp1WOldMTvFU+'??mainpage',201)
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(IIiPCruL6dT8s1lqj47SzpVHnYNm,'GET',EZxQp1WOldMTvFU,'',headers,True,'','ARBLIONZ-MENU-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('categories-tabs(.*?)MainRow',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('data-get="(.*?)".*?<h3>(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for filter,title in items:
			BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU+'/ajax/home/more?filter='+filter
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,201)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('navigation-menu(.*?)</div>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	vsptNMP2ZQC = XBuP6Op7y4K[0]
	items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?>(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	for BoEFz2WhUyvTgDeiZ,title in items:
		if 'http' not in BoEFz2WhUyvTgDeiZ: BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU+BoEFz2WhUyvTgDeiZ
		title = title.strip(' ')
		if not any(WoFrX46wzbCNp18 in title for WoFrX46wzbCNp18 in eh2tDvRFWpLQI):
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,201)
	return MK6ZT2zjC1SbmveNFqor
def sscM839DP1jWZ4zl6uIx0Kyn(url):
	if '??' in url: url,type = url.split('??')
	else: type = ''
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'',headers,True,'','ARBLIONZ-TITLES-2nd')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content.encode('utf8')
	if 'getposts' in url: XBuP6Op7y4K = [MK6ZT2zjC1SbmveNFqor]
	elif type=='trending':
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('MasterSlider(.*?)</div>\n *</div>\n *</div>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	elif type=='trending_movies':
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('Slider_1(.*?)</div>.</div>.</div>.</div>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	elif type=='trending_series':
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('Slider_2(.*?)</div>.</div>.</div>.</div>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	elif type=='111mainpage':
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('class="container page-content"(.*?)class="tabs"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	else:
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('page-content(.*?)main-footer',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if not XBuP6Op7y4K: return
	vsptNMP2ZQC = XBuP6Op7y4K[0]
	sMFW9ecd2nE = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	items = My7Dwqvs6bfGNSIgX.findall('content-box".*?src="(.*?)".*?href="(.*?)".*?<h3>(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	if not items:
		items = My7Dwqvs6bfGNSIgX.findall('SliderItem".*?href="(.*?)".*?image: url\((.*?)\).*?<h2>(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		NVHrZsqUp2,VZIuOLhil3qjRvJsM18me,msjnlSMrQGJ4oLwE2d = zip(*items)
		items = zip(VZIuOLhil3qjRvJsM18me,NVHrZsqUp2,msjnlSMrQGJ4oLwE2d)
	y7y3d5Fbhv42ONmtwLZ0SerYoQq = []
	for IcWzVO137wFvemn2QTq8yKs9,BoEFz2WhUyvTgDeiZ,title in items:
		if '/series/' in BoEFz2WhUyvTgDeiZ: continue
		BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ.strip('/')
		title = PIfAumbGicwg5ye(title)
		title = title.strip(' ')
		if '/film/' in BoEFz2WhUyvTgDeiZ or any(WoFrX46wzbCNp18 in title for WoFrX46wzbCNp18 in sMFW9ecd2nE):
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,202,IcWzVO137wFvemn2QTq8yKs9)
		elif '/episode/' in BoEFz2WhUyvTgDeiZ and 'الحلقة' in title:
			ffhN7jAqe3Q4cR0Ukptzl = My7Dwqvs6bfGNSIgX.findall('(.*?) الحلقة \d+',title,My7Dwqvs6bfGNSIgX.DOTALL)
			if ffhN7jAqe3Q4cR0Ukptzl:
				title = '_MOD_' + ffhN7jAqe3Q4cR0Ukptzl[0]
				if title not in y7y3d5Fbhv42ONmtwLZ0SerYoQq:
					VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,203,IcWzVO137wFvemn2QTq8yKs9)
					y7y3d5Fbhv42ONmtwLZ0SerYoQq.append(title)
		elif '/pack/' in BoEFz2WhUyvTgDeiZ:
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ+'/films',201,IcWzVO137wFvemn2QTq8yKs9)
		else: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,203,IcWzVO137wFvemn2QTq8yKs9)
	if type in ['','mainpage']:
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('class="pagination(.*?)</div>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if XBuP6Op7y4K:
			vsptNMP2ZQC = XBuP6Op7y4K[0]
			items = My7Dwqvs6bfGNSIgX.findall('href=["\'](http.*?)["\'].*?>(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
			for BoEFz2WhUyvTgDeiZ,title in items:
				BoEFz2WhUyvTgDeiZ = PIfAumbGicwg5ye(BoEFz2WhUyvTgDeiZ)
				title = PIfAumbGicwg5ye(title)
				title = title.replace('الصفحة ','')
				if 'search?s=' in url:
					E7LxfIm8ipnVTsy = BoEFz2WhUyvTgDeiZ.split('page=')[1]
					g792SR5b1VWcq6LmrpKGM4 = url.split('page=')[1]
					BoEFz2WhUyvTgDeiZ = url.replace('page='+g792SR5b1VWcq6LmrpKGM4,'page='+E7LxfIm8ipnVTsy)
				if title!='': VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'صفحة '+title,BoEFz2WhUyvTgDeiZ,201)
	return
def o4oY13v5dWMcbilEDjKCnXNzHZ0(url):
	O8OjLhe4VU7GEtKJwSA5zH9ZX,items,NbVDfM1PIpcZ = -1,[],[]
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'',headers,True,'','ARBLIONZ-EPISODES-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content.encode('utf8')
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('ti-list-numbered(.*?)</div>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		NbVDfM1PIpcZ = []
		xAcIatGBYy0FLXroS1ig3Ts9KZ8P5 = ''.join(XBuP6Op7y4K)
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)"',xAcIatGBYy0FLXroS1ig3Ts9KZ8P5,My7Dwqvs6bfGNSIgX.DOTALL)
	items.append(url)
	items = set(items)
	for BoEFz2WhUyvTgDeiZ in items:
		BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ.strip('/')
		title = '_MOD_' + BoEFz2WhUyvTgDeiZ.split('/')[-1].replace('-',' ')
		aaBsTFzpoyDlh3EiMZWnYPqc7w = My7Dwqvs6bfGNSIgX.findall('الحلقة-(\d+)',BoEFz2WhUyvTgDeiZ.split('/')[-1],My7Dwqvs6bfGNSIgX.DOTALL)
		if aaBsTFzpoyDlh3EiMZWnYPqc7w: aaBsTFzpoyDlh3EiMZWnYPqc7w = aaBsTFzpoyDlh3EiMZWnYPqc7w[0]
		else: aaBsTFzpoyDlh3EiMZWnYPqc7w = '0'
		NbVDfM1PIpcZ.append([BoEFz2WhUyvTgDeiZ,title,aaBsTFzpoyDlh3EiMZWnYPqc7w])
	items = sorted(NbVDfM1PIpcZ, reverse=False, key=lambda key: int(key[2]))
	T7BCAQskW8DVoOXJ = str(items).count('/season/')
	O8OjLhe4VU7GEtKJwSA5zH9ZX = str(items).count('/episode/')
	if T7BCAQskW8DVoOXJ>1 and O8OjLhe4VU7GEtKJwSA5zH9ZX>0 and '/season/' not in url:
		for BoEFz2WhUyvTgDeiZ,title,aaBsTFzpoyDlh3EiMZWnYPqc7w in items:
			if '/season/' in BoEFz2WhUyvTgDeiZ:
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,203)
	else:
		for BoEFz2WhUyvTgDeiZ,title,aaBsTFzpoyDlh3EiMZWnYPqc7w in items:
			if '/season/' not in BoEFz2WhUyvTgDeiZ:
				title = XnQbsZF0Ouh8p7zCdUN(title)
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,202)
	return
def HDxCnPKFhITpZmOsA4a0UL6(url):
	QQ2cE1FjUyxPonbDhaTkV6B3i = []
	tuHzpfZmLAdCObQS2k3 = url.split('/')
	vsdV2y56aAYDxzCrcoSu7M1Hm = EZxQp1WOldMTvFU
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(IIiPCruL6dT8s1lqj47SzpVHnYNm,'GET',url,'',headers,True,True,'ARBLIONZ-PLAY-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content.encode('utf8')
	id = My7Dwqvs6bfGNSIgX.findall('postId:"(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if not id: id = My7Dwqvs6bfGNSIgX.findall('post_id=(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if not id: id = My7Dwqvs6bfGNSIgX.findall('post-id="(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if id: id = id[0]
	if '/watch/' in MK6ZT2zjC1SbmveNFqor:
		bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = url.replace(tuHzpfZmLAdCObQS2k3[3],'watch')
		xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(IIiPCruL6dT8s1lqj47SzpVHnYNm,'GET',bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,'',headers,True,True,'ARBLIONZ-PLAY-2nd')
		wN6n7OZBoDkTvCi8LdbJjYV = xHb86g9WZqPwRfVjXD2JalzSIp.content.encode('utf8')
		CZHJvdnOghf3w0 = My7Dwqvs6bfGNSIgX.findall('data-embedd="(.*?)".*?alt="(.*?)"',wN6n7OZBoDkTvCi8LdbJjYV,My7Dwqvs6bfGNSIgX.DOTALL)
		zE1FBZLDvygwGdkef74lnRJVXCUqKH = My7Dwqvs6bfGNSIgX.findall('data-embedd=".*?(http.*?)("|&quot;)',wN6n7OZBoDkTvCi8LdbJjYV,My7Dwqvs6bfGNSIgX.DOTALL)
		eb7QSjE4JXpuPRLUVcM = My7Dwqvs6bfGNSIgX.findall('src=&quot;(.*?)&quot;.*?>(.*?)<',wN6n7OZBoDkTvCi8LdbJjYV,My7Dwqvs6bfGNSIgX.DOTALL|My7Dwqvs6bfGNSIgX.IGNORECASE)
		lR8aMvFzEHO1GLKre5p = My7Dwqvs6bfGNSIgX.findall('data-embedd="(.*?)">\n*.*?server_image">\n(.*?)\n',wN6n7OZBoDkTvCi8LdbJjYV)
		JJsAuXKrfCPH92IaT = My7Dwqvs6bfGNSIgX.findall('src=&quot;(.*?)&quot;.*?alt="(.*?)"',wN6n7OZBoDkTvCi8LdbJjYV,My7Dwqvs6bfGNSIgX.DOTALL|My7Dwqvs6bfGNSIgX.IGNORECASE)
		avKwNViMxsUbnyfGYL = My7Dwqvs6bfGNSIgX.findall('server="(.*?)".*?<span>(.*?)<',wN6n7OZBoDkTvCi8LdbJjYV,My7Dwqvs6bfGNSIgX.DOTALL|My7Dwqvs6bfGNSIgX.IGNORECASE)
		items = CZHJvdnOghf3w0+zE1FBZLDvygwGdkef74lnRJVXCUqKH+eb7QSjE4JXpuPRLUVcM+lR8aMvFzEHO1GLKre5p+JJsAuXKrfCPH92IaT+avKwNViMxsUbnyfGYL
		if not items:
			items = My7Dwqvs6bfGNSIgX.findall('<span>(.*?)</span>.*?src="(.*?)"',wN6n7OZBoDkTvCi8LdbJjYV,My7Dwqvs6bfGNSIgX.DOTALL|My7Dwqvs6bfGNSIgX.IGNORECASE)
			items = [(tUunlg3F1qhOVDQ7vr,xhIMnjFbcKD) for xhIMnjFbcKD,tUunlg3F1qhOVDQ7vr in items]
		for LkVZrOE4XBSN2Qex5PyHqC,title in items:
			if '.png' in LkVZrOE4XBSN2Qex5PyHqC: continue
			if '.jpg' in LkVZrOE4XBSN2Qex5PyHqC: continue
			if '&quot;' in LkVZrOE4XBSN2Qex5PyHqC: continue
			LLnUyuiC2wRM0 = My7Dwqvs6bfGNSIgX.findall('\d\d\d+',title,My7Dwqvs6bfGNSIgX.DOTALL)
			if LLnUyuiC2wRM0:
				LLnUyuiC2wRM0 = LLnUyuiC2wRM0[0]
				if LLnUyuiC2wRM0 in title: title = title.replace(LLnUyuiC2wRM0+'p','').replace(LLnUyuiC2wRM0,'').strip(' ')
				LLnUyuiC2wRM0 = '____'+LLnUyuiC2wRM0
			else: LLnUyuiC2wRM0 = ''
			if LkVZrOE4XBSN2Qex5PyHqC.isdigit():
				BoEFz2WhUyvTgDeiZ = vsdV2y56aAYDxzCrcoSu7M1Hm+'/?postid='+id+'&serverid='+LkVZrOE4XBSN2Qex5PyHqC+'?named='+title+'__watch'+LLnUyuiC2wRM0
			else:
				if 'http' not in LkVZrOE4XBSN2Qex5PyHqC: LkVZrOE4XBSN2Qex5PyHqC = 'http:'+LkVZrOE4XBSN2Qex5PyHqC
				LLnUyuiC2wRM0 = My7Dwqvs6bfGNSIgX.findall('\d\d\d+',title,My7Dwqvs6bfGNSIgX.DOTALL)
				if LLnUyuiC2wRM0: LLnUyuiC2wRM0 = '____'+LLnUyuiC2wRM0[0]
				else: LLnUyuiC2wRM0 = ''
				BoEFz2WhUyvTgDeiZ = LkVZrOE4XBSN2Qex5PyHqC+'?named=__watch'+LLnUyuiC2wRM0
			QQ2cE1FjUyxPonbDhaTkV6B3i.append(BoEFz2WhUyvTgDeiZ)
	if 'DownloadNow' in MK6ZT2zjC1SbmveNFqor:
		eIL9BxdTbZj = { 'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8' }
		bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = url+'/download'
		xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(IIiPCruL6dT8s1lqj47SzpVHnYNm,'GET',bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,'',eIL9BxdTbZj,True,'','ARBLIONZ-PLAY-3rd')
		wN6n7OZBoDkTvCi8LdbJjYV = xHb86g9WZqPwRfVjXD2JalzSIp.content.encode('utf8')
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('<ul class="download-items(.*?)</ul>',wN6n7OZBoDkTvCi8LdbJjYV,My7Dwqvs6bfGNSIgX.DOTALL)
		for vsptNMP2ZQC in XBuP6Op7y4K:
			items = My7Dwqvs6bfGNSIgX.findall('href="(http.*?)".*?<span>(.*?)<.*?<p>(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
			for BoEFz2WhUyvTgDeiZ,name,LLnUyuiC2wRM0 in items:
				BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ+'?named='+name+'__download'+'____'+LLnUyuiC2wRM0
				QQ2cE1FjUyxPonbDhaTkV6B3i.append(BoEFz2WhUyvTgDeiZ)
	elif '/download/' in MK6ZT2zjC1SbmveNFqor:
		eIL9BxdTbZj = { 'User-Agent':'' , 'X-Requested-With':'XMLHttpRequest' }
		bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = vsdV2y56aAYDxzCrcoSu7M1Hm + '/ajaxCenter?_action=getdownloadlinks&postId='+id
		xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(IIiPCruL6dT8s1lqj47SzpVHnYNm,'GET',bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,'',eIL9BxdTbZj,True,True,'ARBLIONZ-PLAY-4th')
		wN6n7OZBoDkTvCi8LdbJjYV = xHb86g9WZqPwRfVjXD2JalzSIp.content.encode('utf8')
		if 'download-btns' in wN6n7OZBoDkTvCi8LdbJjYV:
			eb7QSjE4JXpuPRLUVcM = My7Dwqvs6bfGNSIgX.findall('href="(.*?)"',wN6n7OZBoDkTvCi8LdbJjYV,My7Dwqvs6bfGNSIgX.DOTALL)
			for QAKdHzO0rehbtyIc in eb7QSjE4JXpuPRLUVcM:
				if '/page/' not in QAKdHzO0rehbtyIc and 'http' in QAKdHzO0rehbtyIc:
					QAKdHzO0rehbtyIc = QAKdHzO0rehbtyIc+'?named=__download'
					QQ2cE1FjUyxPonbDhaTkV6B3i.append(QAKdHzO0rehbtyIc)
				elif '/page/' in QAKdHzO0rehbtyIc:
					LLnUyuiC2wRM0 = ''
					xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(IIiPCruL6dT8s1lqj47SzpVHnYNm,'GET',QAKdHzO0rehbtyIc,'',headers,True,True,'ARBLIONZ-PLAY-5th')
					lBQGuWyhMJkzdwf1XcxKEqT = xHb86g9WZqPwRfVjXD2JalzSIp.content.encode('utf8')
					xAcIatGBYy0FLXroS1ig3Ts9KZ8P5 = My7Dwqvs6bfGNSIgX.findall('(<strong>.*?)-----',lBQGuWyhMJkzdwf1XcxKEqT,My7Dwqvs6bfGNSIgX.DOTALL)
					for EuGZ9PMtm7cfQOzrgoHU3e0i in xAcIatGBYy0FLXroS1ig3Ts9KZ8P5:
						NMTjykHQGs = ''
						lR8aMvFzEHO1GLKre5p = My7Dwqvs6bfGNSIgX.findall('<strong>(.*?)</strong>',EuGZ9PMtm7cfQOzrgoHU3e0i,My7Dwqvs6bfGNSIgX.DOTALL)
						for XSW50CQwKHLrqehAfcj in lR8aMvFzEHO1GLKre5p:
							ZA1fBenNahOR3xrkjvwYSVMy6JK5s = My7Dwqvs6bfGNSIgX.findall('\d\d\d+',XSW50CQwKHLrqehAfcj,My7Dwqvs6bfGNSIgX.DOTALL)
							if ZA1fBenNahOR3xrkjvwYSVMy6JK5s:
								LLnUyuiC2wRM0 = '____'+ZA1fBenNahOR3xrkjvwYSVMy6JK5s[0]
								break
						for XSW50CQwKHLrqehAfcj in reversed(lR8aMvFzEHO1GLKre5p):
							ZA1fBenNahOR3xrkjvwYSVMy6JK5s = My7Dwqvs6bfGNSIgX.findall('\w\w+',XSW50CQwKHLrqehAfcj,My7Dwqvs6bfGNSIgX.DOTALL)
							if ZA1fBenNahOR3xrkjvwYSVMy6JK5s:
								NMTjykHQGs = ZA1fBenNahOR3xrkjvwYSVMy6JK5s[0]
								break
						JJsAuXKrfCPH92IaT = My7Dwqvs6bfGNSIgX.findall('href="(.*?)"',EuGZ9PMtm7cfQOzrgoHU3e0i,My7Dwqvs6bfGNSIgX.DOTALL)
						for oCwT6jtnhXd95EA4 in JJsAuXKrfCPH92IaT:
							oCwT6jtnhXd95EA4 = oCwT6jtnhXd95EA4+'?named='+NMTjykHQGs+'__download'+LLnUyuiC2wRM0
							QQ2cE1FjUyxPonbDhaTkV6B3i.append(oCwT6jtnhXd95EA4)
		elif 'slow-motion' in wN6n7OZBoDkTvCi8LdbJjYV:
			wN6n7OZBoDkTvCi8LdbJjYV = wN6n7OZBoDkTvCi8LdbJjYV.replace('<h6 ','==END== ==START==')+'==END=='
			wN6n7OZBoDkTvCi8LdbJjYV = wN6n7OZBoDkTvCi8LdbJjYV.replace('<h3 ','==END== ==START==')+'==END=='
			talMyEx1onWGdT5NSVr9kHqj = My7Dwqvs6bfGNSIgX.findall('==START==(.*?)==END==',wN6n7OZBoDkTvCi8LdbJjYV,My7Dwqvs6bfGNSIgX.DOTALL)
			if talMyEx1onWGdT5NSVr9kHqj:
				for EuGZ9PMtm7cfQOzrgoHU3e0i in talMyEx1onWGdT5NSVr9kHqj:
					if 'href=' not in EuGZ9PMtm7cfQOzrgoHU3e0i: continue
					Q1KzCWfudPqT6sZB7IkF4wE2VRexy = ''
					lR8aMvFzEHO1GLKre5p = My7Dwqvs6bfGNSIgX.findall('slow-motion">(.*?)<',EuGZ9PMtm7cfQOzrgoHU3e0i,My7Dwqvs6bfGNSIgX.DOTALL)
					for XSW50CQwKHLrqehAfcj in lR8aMvFzEHO1GLKre5p:
						ZA1fBenNahOR3xrkjvwYSVMy6JK5s = My7Dwqvs6bfGNSIgX.findall('\d\d\d+',XSW50CQwKHLrqehAfcj,My7Dwqvs6bfGNSIgX.DOTALL)
						if ZA1fBenNahOR3xrkjvwYSVMy6JK5s:
							Q1KzCWfudPqT6sZB7IkF4wE2VRexy = '____'+ZA1fBenNahOR3xrkjvwYSVMy6JK5s[0]
							break
					lR8aMvFzEHO1GLKre5p = My7Dwqvs6bfGNSIgX.findall('<td>(.*?)</td>.*?href="(http.*?)"',EuGZ9PMtm7cfQOzrgoHU3e0i,My7Dwqvs6bfGNSIgX.DOTALL)
					if lR8aMvFzEHO1GLKre5p:
						for NMTjykHQGs,lHTVXWCQwvfG in lR8aMvFzEHO1GLKre5p:
							lHTVXWCQwvfG = lHTVXWCQwvfG+'?named='+NMTjykHQGs+'__download'+Q1KzCWfudPqT6sZB7IkF4wE2VRexy
							QQ2cE1FjUyxPonbDhaTkV6B3i.append(lHTVXWCQwvfG)
					else:
						lR8aMvFzEHO1GLKre5p = My7Dwqvs6bfGNSIgX.findall('href="(.*?http.*?)".*?name">(.*?)<',EuGZ9PMtm7cfQOzrgoHU3e0i,My7Dwqvs6bfGNSIgX.DOTALL)
						for lHTVXWCQwvfG,NMTjykHQGs in lR8aMvFzEHO1GLKre5p:
							lHTVXWCQwvfG = lHTVXWCQwvfG.strip(' ')+'?named='+NMTjykHQGs+'__download'+Q1KzCWfudPqT6sZB7IkF4wE2VRexy
							QQ2cE1FjUyxPonbDhaTkV6B3i.append(lHTVXWCQwvfG)
			else:
				lR8aMvFzEHO1GLKre5p = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?>(\w+)<',wN6n7OZBoDkTvCi8LdbJjYV,My7Dwqvs6bfGNSIgX.DOTALL)
				for lHTVXWCQwvfG,NMTjykHQGs in lR8aMvFzEHO1GLKre5p:
					lHTVXWCQwvfG = lHTVXWCQwvfG.strip(' ')+'?named='+NMTjykHQGs+'__download'
					QQ2cE1FjUyxPonbDhaTkV6B3i.append(lHTVXWCQwvfG)
	import t1kDWXQVpC
	t1kDWXQVpC.rqVt2xDi7jzJHBcPMRs6h0L(QQ2cE1FjUyxPonbDhaTkV6B3i,baNWS6nfqTC5iX4Kl,'video',url)
	return
def HjZcUIVAXFCqy9TfBWKtgY2(search):
	search,LQf3AeozSrai,showDialogs = X54MLovbG8nAEkB9J(search)
	if search=='': search = ViKAIsLurq83RSENayxWb()
	if search=='': return
	search = search.replace(' ','+')
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(IIiPCruL6dT8s1lqj47SzpVHnYNm,'GET',EZxQp1WOldMTvFU+'/alz','',headers,True,'','ARBLIONZ-SEARCH-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content.encode('utf8')
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('chevron-select(.*?)</div>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if showDialogs and XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('value="(.*?)".*?>(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		CnNsvLHqf31,aUMmwSXexcqN = [],[]
		for g4Y0BXLxCpuojKP1SAUtcq7TwN2,title in items:
			CnNsvLHqf31.append(g4Y0BXLxCpuojKP1SAUtcq7TwN2)
			aUMmwSXexcqN.append(title)
		GOtNfU3xQFkEhPouwA = CnKwdteDG5BE8MTRhUpYIJm3NLrSgq('اختر الفلتر المناسب:', aUMmwSXexcqN)
		if GOtNfU3xQFkEhPouwA == -1 : return
		g4Y0BXLxCpuojKP1SAUtcq7TwN2 = CnNsvLHqf31[GOtNfU3xQFkEhPouwA]
	else: g4Y0BXLxCpuojKP1SAUtcq7TwN2 = ''
	url = EZxQp1WOldMTvFU + '/search?s='+search+'&category='+g4Y0BXLxCpuojKP1SAUtcq7TwN2+'&page=1'
	sscM839DP1jWZ4zl6uIx0Kyn(url)
	return
def LLJlTxDePyjoVKA(url,filter):
	vIZKhbfsXmWAyUVecrNOz95LQ = ['category','release-year','genre','Quality']
	if '?' in url: url = url.split('/getposts?')[0]
	type,filter = filter.split('___',1)
	if filter=='': H2HMwT4JFz7rDkPZmRjcX,JPnr9ICqkDyV = '',''
	else: H2HMwT4JFz7rDkPZmRjcX,JPnr9ICqkDyV = filter.split('___')
	if type=='CATEGORIES':
		if vIZKhbfsXmWAyUVecrNOz95LQ[0]+'=' not in H2HMwT4JFz7rDkPZmRjcX: g4Y0BXLxCpuojKP1SAUtcq7TwN2 = vIZKhbfsXmWAyUVecrNOz95LQ[0]
		for FVW0I9sYcAjmDgn8r in range(len(vIZKhbfsXmWAyUVecrNOz95LQ[0:-1])):
			if vIZKhbfsXmWAyUVecrNOz95LQ[FVW0I9sYcAjmDgn8r]+'=' in H2HMwT4JFz7rDkPZmRjcX: g4Y0BXLxCpuojKP1SAUtcq7TwN2 = vIZKhbfsXmWAyUVecrNOz95LQ[FVW0I9sYcAjmDgn8r+1]
		HHXeMqVOshPcW3tULa5v = H2HMwT4JFz7rDkPZmRjcX+'&'+g4Y0BXLxCpuojKP1SAUtcq7TwN2+'=0'
		DoSfCckGA9BQe = JPnr9ICqkDyV+'&'+g4Y0BXLxCpuojKP1SAUtcq7TwN2+'=0'
		A7AEKRlF6Hf3eWVxY0NdwgsMPCc = HHXeMqVOshPcW3tULa5v.strip('&')+'___'+DoSfCckGA9BQe.strip('&')
		woj78rBnbLlmZWIy19iPHFCf5 = BrbZhHKJ0jnIe2lumE9M(JPnr9ICqkDyV,'modified_filters')
		bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = url+'/getposts?'+woj78rBnbLlmZWIy19iPHFCf5
	elif type=='FILTERS':
		WUSylLup41cYkhVXGtq = BrbZhHKJ0jnIe2lumE9M(H2HMwT4JFz7rDkPZmRjcX,'modified_values')
		WUSylLup41cYkhVXGtq = XnQbsZF0Ouh8p7zCdUN(WUSylLup41cYkhVXGtq)
		if JPnr9ICqkDyV!='': JPnr9ICqkDyV = BrbZhHKJ0jnIe2lumE9M(JPnr9ICqkDyV,'modified_filters')
		if JPnr9ICqkDyV=='': bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = url
		else: bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = url+'/getposts?'+JPnr9ICqkDyV
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'أظهار قائمة الفيديو التي تم اختيارها ',bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,201)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+' [[   '+WUSylLup41cYkhVXGtq+'   ]]',bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,201)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	MK6ZT2zjC1SbmveNFqor = YY0KEWamSIc46n3kbtuLgZV(IIiPCruL6dT8s1lqj47SzpVHnYNm,url+'/alz','',headers,'','ARBLIONZ-FILTERS_MENU-1st')
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('AjaxFilteringData(.*?)FilterWord',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	vsptNMP2ZQC = XBuP6Op7y4K[0]
	E3ErsLQfR4JXt = My7Dwqvs6bfGNSIgX.findall('</i>(.*?)<.*?data-forTax="(.*?)"(.*?)<h2',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	dict = {}
	for name,RTsbVE9CiQt,vsptNMP2ZQC in E3ErsLQfR4JXt:
		name = name.replace('اختيار ','')
		name = name.replace('سنة الإنتاج','السنة')
		items = My7Dwqvs6bfGNSIgX.findall('value="(.*?)".*?</div>(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		if '=' not in bJEs4IVAPdyUrhwCLv9k2YoOl8nt1: bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = url
		if type=='CATEGORIES':
			if g4Y0BXLxCpuojKP1SAUtcq7TwN2!=RTsbVE9CiQt: continue
			elif len(items)<=1:
				if RTsbVE9CiQt==vIZKhbfsXmWAyUVecrNOz95LQ[-1]: sscM839DP1jWZ4zl6uIx0Kyn(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1)
				else: LLJlTxDePyjoVKA(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,'CATEGORIES___'+A7AEKRlF6Hf3eWVxY0NdwgsMPCc)
				return
			else:
				if RTsbVE9CiQt==vIZKhbfsXmWAyUVecrNOz95LQ[-1]: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'الجميع ',bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,201)
				else: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'الجميع ',bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,205,'','',A7AEKRlF6Hf3eWVxY0NdwgsMPCc)
		elif type=='FILTERS':
			HHXeMqVOshPcW3tULa5v = H2HMwT4JFz7rDkPZmRjcX+'&'+RTsbVE9CiQt+'=0'
			DoSfCckGA9BQe = JPnr9ICqkDyV+'&'+RTsbVE9CiQt+'=0'
			A7AEKRlF6Hf3eWVxY0NdwgsMPCc = HHXeMqVOshPcW3tULa5v+'___'+DoSfCckGA9BQe
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'الجميع :'+name,bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,204,'','',A7AEKRlF6Hf3eWVxY0NdwgsMPCc)
		dict[RTsbVE9CiQt] = {}
		for WoFrX46wzbCNp18,A5AMg7LY1HlOz0B82n in items:
			A5AMg7LY1HlOz0B82n = A5AMg7LY1HlOz0B82n.replace('\n','')
			if A5AMg7LY1HlOz0B82n in eh2tDvRFWpLQI: continue
			dict[RTsbVE9CiQt][WoFrX46wzbCNp18] = A5AMg7LY1HlOz0B82n
			HHXeMqVOshPcW3tULa5v = H2HMwT4JFz7rDkPZmRjcX+'&'+RTsbVE9CiQt+'='+A5AMg7LY1HlOz0B82n
			DoSfCckGA9BQe = JPnr9ICqkDyV+'&'+RTsbVE9CiQt+'='+WoFrX46wzbCNp18
			QQIzTLCXyhtZ7pRNnGq = HHXeMqVOshPcW3tULa5v+'___'+DoSfCckGA9BQe
			title = A5AMg7LY1HlOz0B82n+' :'#+dict[RTsbVE9CiQt]['0']
			title = A5AMg7LY1HlOz0B82n+' :'+name
			if type=='FILTERS': VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,url,204,'','',QQIzTLCXyhtZ7pRNnGq)
			elif type=='CATEGORIES' and vIZKhbfsXmWAyUVecrNOz95LQ[-2]+'=' in H2HMwT4JFz7rDkPZmRjcX:
				woj78rBnbLlmZWIy19iPHFCf5 = BrbZhHKJ0jnIe2lumE9M(DoSfCckGA9BQe,'modified_filters')
				QAKdHzO0rehbtyIc = url+'/getposts?'+woj78rBnbLlmZWIy19iPHFCf5
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,QAKdHzO0rehbtyIc,201)
			else: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,url,205,'','',QQIzTLCXyhtZ7pRNnGq)
	return
def BrbZhHKJ0jnIe2lumE9M(PPebqkulZUsx3GCLdnYvR,mode):
	PPebqkulZUsx3GCLdnYvR = PPebqkulZUsx3GCLdnYvR.replace('=&','=0&')
	PPebqkulZUsx3GCLdnYvR = PPebqkulZUsx3GCLdnYvR.strip('&')
	mVSjqdOvyf = {}
	if '=' in PPebqkulZUsx3GCLdnYvR:
		items = PPebqkulZUsx3GCLdnYvR.split('&')
		for ZA1fBenNahOR3xrkjvwYSVMy6JK5s in items:
			nmqEj60bcdSQoFPGa,WoFrX46wzbCNp18 = ZA1fBenNahOR3xrkjvwYSVMy6JK5s.split('=')
			mVSjqdOvyf[nmqEj60bcdSQoFPGa] = WoFrX46wzbCNp18
	DidZH6E0pJelcU9xMCBgyL2KvR = ''
	lWF7u5qUtSak3B = ['category','release-year','genre','Quality']
	for key in lWF7u5qUtSak3B:
		if key in list(mVSjqdOvyf.keys()): WoFrX46wzbCNp18 = mVSjqdOvyf[key]
		else: WoFrX46wzbCNp18 = '0'
		if '%' not in WoFrX46wzbCNp18: WoFrX46wzbCNp18 = F8fMqZKB4APk(WoFrX46wzbCNp18)
		if mode=='modified_values' and WoFrX46wzbCNp18!='0': DidZH6E0pJelcU9xMCBgyL2KvR = DidZH6E0pJelcU9xMCBgyL2KvR+' + '+WoFrX46wzbCNp18
		elif mode=='modified_filters' and WoFrX46wzbCNp18!='0': DidZH6E0pJelcU9xMCBgyL2KvR = DidZH6E0pJelcU9xMCBgyL2KvR+'&'+key+'='+WoFrX46wzbCNp18
		elif mode=='all': DidZH6E0pJelcU9xMCBgyL2KvR = DidZH6E0pJelcU9xMCBgyL2KvR+'&'+key+'='+WoFrX46wzbCNp18
	DidZH6E0pJelcU9xMCBgyL2KvR = DidZH6E0pJelcU9xMCBgyL2KvR.strip(' + ')
	DidZH6E0pJelcU9xMCBgyL2KvR = DidZH6E0pJelcU9xMCBgyL2KvR.strip('&')
	DidZH6E0pJelcU9xMCBgyL2KvR = DidZH6E0pJelcU9xMCBgyL2KvR.replace('=0','=')
	DidZH6E0pJelcU9xMCBgyL2KvR = DidZH6E0pJelcU9xMCBgyL2KvR.replace('Quality','quality')
	return DidZH6E0pJelcU9xMCBgyL2KvR
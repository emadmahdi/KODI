# -*- coding: utf-8 -*-
from G6AHskJeqN import *
baNWS6nfqTC5iX4Kl = 'YOUTUBE'
teUPLFC3B8bArakwHVGsdhoIWDM49f = '_YUT_'
EZxQp1WOldMTvFU = AK5RqLhji4W1wt9VdrCD3PGeQM[baNWS6nfqTC5iX4Kl][0]
yys9qTIYchHwgaJ3C2 = 0
def VbgEajY4Bt2COpGDcPqI(mode,url,text,type,z3z9QgENFk5eMYB4,name,QFrVYJkywEsXquMNz):
	if	 mode==140: ft3e2JBKQVXWlFPjaMhkEqGxvDg = eN02L7Tf5bQ()
	elif mode==141: ft3e2JBKQVXWlFPjaMhkEqGxvDg = OMj0CGdnlyS6B9fx3WK(url,name,QFrVYJkywEsXquMNz)
	elif mode==143: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HDxCnPKFhITpZmOsA4a0UL6(url,type)
	elif mode==144: ft3e2JBKQVXWlFPjaMhkEqGxvDg = sscM839DP1jWZ4zl6uIx0Kyn(url,z3z9QgENFk5eMYB4,text)
	elif mode==145: ft3e2JBKQVXWlFPjaMhkEqGxvDg = iuAoJsgSL0XVRzqalHWtFMhOIG(url,z3z9QgENFk5eMYB4)
	elif mode==147: ft3e2JBKQVXWlFPjaMhkEqGxvDg = AFldBWUwyn2RuHKfZvLzO()
	elif mode==148: ft3e2JBKQVXWlFPjaMhkEqGxvDg = Pjv5aVrxEDfnhFo812GCl0tKS7i()
	elif mode==149: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HjZcUIVAXFCqy9TfBWKtgY2(text)
	else: ft3e2JBKQVXWlFPjaMhkEqGxvDg = False
	return ft3e2JBKQVXWlFPjaMhkEqGxvDg
def eN02L7Tf5bQ():
	if 0:
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'قائمة',EZxQp1WOldMTvFU+'/playlist?list=PLAj5Gs8FH8ZnUbF0RV-7G3BoqIyZA4uSA',144)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'شخص',EZxQp1WOldMTvFU+'/user/TCNofficial',144)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'موقع',EZxQp1WOldMTvFU+'/channel/UCq59aGNsq9bbhwVTq1Utvgw',144)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'حساب',EZxQp1WOldMTvFU+'/@TheSocialCTV',144)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'العاب',EZxQp1WOldMTvFU+'/gaming',144)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'افلام',EZxQp1WOldMTvFU+'/feed/storefront',144)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'مختارات',EZxQp1WOldMTvFU+'/feed/guide_builder',144)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'قصيرة',EZxQp1WOldMTvFU+'/shorts',144,'','','_REMEMBERRESULTS_')
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'تصفح',EZxQp1WOldMTvFU+'/youtubei/v1/guide?key=',144)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'رئيسية',EZxQp1WOldMTvFU+'',144)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'رائج',EZxQp1WOldMTvFU+'/feed/trending?bp=',144)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'بحث في الموقع','',149,'','','_REMEMBERRESULTS_')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'الرئيسية',EZxQp1WOldMTvFU+'',144)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'الرائجة',EZxQp1WOldMTvFU+'/feed/trending',144)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'التصفح',EZxQp1WOldMTvFU+'/youtubei/v1/guide?key=',144)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'القصيرة',EZxQp1WOldMTvFU+'/shorts',144,'','','_REMEMBERRESULTS_')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'مختارات يوتيوب',EZxQp1WOldMTvFU+'/feed/guide_builder',144)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'مختارات البرنامج','',290)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'بحث: قنوات عربية','',147)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'بحث: قنوات أجنبية','',148)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'بحث: افلام عربية',EZxQp1WOldMTvFU+'/results?search_query=فيلم',144)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'بحث: افلام اجنبية',EZxQp1WOldMTvFU+'/results?search_query=movie',144)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'بحث: مسرحيات عربية',EZxQp1WOldMTvFU+'/results?search_query=مسرحية',144)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'بحث: مسلسلات عربية',EZxQp1WOldMTvFU+'/results?search_query=مسلسل&sp=EgIQAw==',144)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'بحث: مسلسلات اجنبية',EZxQp1WOldMTvFU+'/results?search_query=series&sp=EgIQAw==',144)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'بحث: مسلسلات كارتون',EZxQp1WOldMTvFU+'/results?search_query=كارتون&sp=EgIQAw==',144)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'بحث: خطبة المرجعية',EZxQp1WOldMTvFU+'/results?search_query=قناة+كربلاء+الفضائية+خطبة+الجمعة&sp=CAISAhAB',144)
	return
def OMj0CGdnlyS6B9fx3WK(url,name,QFrVYJkywEsXquMNz):
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'CHNL:  '+name,url,144,QFrVYJkywEsXquMNz)
	return
def AFldBWUwyn2RuHKfZvLzO():
	sscM839DP1jWZ4zl6uIx0Kyn(EZxQp1WOldMTvFU+'/results?search_query=قناة+بث&sp=EgJAAQ==')
	return
def Pjv5aVrxEDfnhFo812GCl0tKS7i():
	sscM839DP1jWZ4zl6uIx0Kyn(EZxQp1WOldMTvFU+'/results?search_query=tv&sp=EgJAAQ==')
	return
def HDxCnPKFhITpZmOsA4a0UL6(url,type):
	url = url.split('&',1)[0]
	import t1kDWXQVpC
	t1kDWXQVpC.rqVt2xDi7jzJHBcPMRs6h0L([url],baNWS6nfqTC5iX4Kl,type,url)
	return
def ZlIcNVC4zWP5gGXxqTwto8(Zy3lCqAUj9LDfSEn0dJQ,url,gMous1DWl97JdE5h6n0CFjeLZkq):
	level,JwtElRBXZny3sY05m7jqINvViU9zSu,P5wyN7zRcUEGu9pfmqFHA4djLi,KTkINZBXljPYvUOyJhzq3wxe4 = gMous1DWl97JdE5h6n0CFjeLZkq.split('::')
	nn6usrGtaj2LXy9,wSa45k91WxVO = [],[]
	if '/youtubei/v1/browse' in url: nn6usrGtaj2LXy9.append("yccc['onResponseReceivedActions']")
	if '/youtubei/v1/search' in url: nn6usrGtaj2LXy9.append("yccc['onResponseReceivedCommands']")
	if level=='1': nn6usrGtaj2LXy9.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs'][0]['tabRenderer']['content']['richGridRenderer']['header']['feedFilterChipBarRenderer']['contents']")
	nn6usrGtaj2LXy9.append("yccc['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['contents']")
	nn6usrGtaj2LXy9.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs']")
	nn6usrGtaj2LXy9.append("yccc['entries']")
	nn6usrGtaj2LXy9.append("yccc['items'][3]['guideSectionRenderer']['items']")
	NaD6gRjLBqKWFY51,FznNTLoMP5q8sv2WeUruZBRbj6Jh,hnKs8d34a9Cz = MBWvjLtCNkbQ97RIw4KyHSVcEeDr(Zy3lCqAUj9LDfSEn0dJQ,'',nn6usrGtaj2LXy9)
	if level=='1' and NaD6gRjLBqKWFY51:
		if len(FznNTLoMP5q8sv2WeUruZBRbj6Jh)>1 and 'search_query' not in url:
			for hklGvBFSHupmAE5UVQ2zOcJ8 in range(len(FznNTLoMP5q8sv2WeUruZBRbj6Jh)):
				JwtElRBXZny3sY05m7jqINvViU9zSu = str(hklGvBFSHupmAE5UVQ2zOcJ8)
				nn6usrGtaj2LXy9 = []
				nn6usrGtaj2LXy9.append("yddd["+JwtElRBXZny3sY05m7jqINvViU9zSu+"]['reloadContinuationItemsCommand']['continuationItems']")
				nn6usrGtaj2LXy9.append("yddd["+JwtElRBXZny3sY05m7jqINvViU9zSu+"]['command']")
				nn6usrGtaj2LXy9.append("yddd["+JwtElRBXZny3sY05m7jqINvViU9zSu+"]")
				tUEvo5HAfIjZgcdYxNJ8awu,ZA1fBenNahOR3xrkjvwYSVMy6JK5s,aaBsTFzpoyDlh3EiMZWnYPqc7w = MBWvjLtCNkbQ97RIw4KyHSVcEeDr(FznNTLoMP5q8sv2WeUruZBRbj6Jh,'',nn6usrGtaj2LXy9)
				if tUEvo5HAfIjZgcdYxNJ8awu: wSa45k91WxVO.append([ZA1fBenNahOR3xrkjvwYSVMy6JK5s,url,'2::'+JwtElRBXZny3sY05m7jqINvViU9zSu+'::0::0'])
			nn6usrGtaj2LXy9.append("yccc['continuationEndpoint']")
			tUEvo5HAfIjZgcdYxNJ8awu,ZA1fBenNahOR3xrkjvwYSVMy6JK5s,aaBsTFzpoyDlh3EiMZWnYPqc7w = MBWvjLtCNkbQ97RIw4KyHSVcEeDr(Zy3lCqAUj9LDfSEn0dJQ,'',nn6usrGtaj2LXy9)
			if tUEvo5HAfIjZgcdYxNJ8awu and wSa45k91WxVO and 'continuationCommand' in list(ZA1fBenNahOR3xrkjvwYSVMy6JK5s.keys()):
				BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU+'/my_main_page_shorts_link'
				wSa45k91WxVO.append([ZA1fBenNahOR3xrkjvwYSVMy6JK5s,BoEFz2WhUyvTgDeiZ,'1::0::0::0'])
	return FznNTLoMP5q8sv2WeUruZBRbj6Jh,NaD6gRjLBqKWFY51,wSa45k91WxVO,hnKs8d34a9Cz
def zwh6fMNDGeH8LbVYK1XU0(Zy3lCqAUj9LDfSEn0dJQ,FznNTLoMP5q8sv2WeUruZBRbj6Jh,url,gMous1DWl97JdE5h6n0CFjeLZkq):
	level,JwtElRBXZny3sY05m7jqINvViU9zSu,P5wyN7zRcUEGu9pfmqFHA4djLi,KTkINZBXljPYvUOyJhzq3wxe4 = gMous1DWl97JdE5h6n0CFjeLZkq.split('::')
	nn6usrGtaj2LXy9,gd7HyTQlEJWFDeoiCkVRz0qpYa = [],[]
	nn6usrGtaj2LXy9.append("yddd[0]['itemSectionRenderer']['contents']")
	nn6usrGtaj2LXy9.append("yddd["+JwtElRBXZny3sY05m7jqINvViU9zSu+"]['reloadContinuationItemsCommand']['continuationItems']")
	nn6usrGtaj2LXy9.append("yddd[1]['reloadContinuationItemsCommand']['continuationItems']")
	if '/youtubei/v1/browse' in url: nn6usrGtaj2LXy9.append("yddd[0]['appendContinuationItemsAction']['continuationItems']")
	elif '/youtubei/v1/search' in url: nn6usrGtaj2LXy9.append("yddd[0]['appendContinuationItemsAction']['continuationItems'][0]['itemSectionRenderer']['contents']")
	nn6usrGtaj2LXy9.append("yddd["+JwtElRBXZny3sY05m7jqINvViU9zSu+"]['tabRenderer']['content']['sectionListRenderer']['contents']")
	if '/videos' in url or ('/shorts' in url and '/shorts/' not in url):
		nn6usrGtaj2LXy9.append("yddd["+JwtElRBXZny3sY05m7jqINvViU9zSu+"]['tabRenderer']['content']['richGridRenderer']['header']['feedFilterChipBarRenderer']['contents']")
	nn6usrGtaj2LXy9.append("yddd["+JwtElRBXZny3sY05m7jqINvViU9zSu+"]['tabRenderer']['content']['richGridRenderer']['contents']")
	nn6usrGtaj2LXy9.append("yddd["+JwtElRBXZny3sY05m7jqINvViU9zSu+"]['expandableTabRenderer']['content']['sectionListRenderer']['contents']")
	nn6usrGtaj2LXy9.append("yddd["+JwtElRBXZny3sY05m7jqINvViU9zSu+"]['richSectionRenderer']['content']['richShelfRenderer']['contents']")
	nn6usrGtaj2LXy9.append("yddd["+JwtElRBXZny3sY05m7jqINvViU9zSu+"]")
	HSInOVqc7m4xdUj81PzLYpAvNaw,eclFL1tQ3IkWmipq4a7AJfMZSbGw,jwQgHWsiKcqAue6PFRYdfk8B = MBWvjLtCNkbQ97RIw4KyHSVcEeDr(FznNTLoMP5q8sv2WeUruZBRbj6Jh,'',nn6usrGtaj2LXy9)
	if level=='2' and HSInOVqc7m4xdUj81PzLYpAvNaw:
		if len(eclFL1tQ3IkWmipq4a7AJfMZSbGw)>1:
			for hklGvBFSHupmAE5UVQ2zOcJ8 in range(len(eclFL1tQ3IkWmipq4a7AJfMZSbGw)):
				P5wyN7zRcUEGu9pfmqFHA4djLi = str(hklGvBFSHupmAE5UVQ2zOcJ8)
				nn6usrGtaj2LXy9 = []
				nn6usrGtaj2LXy9.append("yeee["+P5wyN7zRcUEGu9pfmqFHA4djLi+"]['richSectionRenderer']['content']")
				nn6usrGtaj2LXy9.append("yeee["+P5wyN7zRcUEGu9pfmqFHA4djLi+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['header']")
				nn6usrGtaj2LXy9.append("yeee["+P5wyN7zRcUEGu9pfmqFHA4djLi+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
				nn6usrGtaj2LXy9.append("yeee["+P5wyN7zRcUEGu9pfmqFHA4djLi+"]['itemSectionRenderer']['contents'][0]")
				nn6usrGtaj2LXy9.append("yeee["+P5wyN7zRcUEGu9pfmqFHA4djLi+"]['richItemRenderer']['content']")
				nn6usrGtaj2LXy9.append("yeee["+P5wyN7zRcUEGu9pfmqFHA4djLi+"]")
				tUEvo5HAfIjZgcdYxNJ8awu,ZA1fBenNahOR3xrkjvwYSVMy6JK5s,aaBsTFzpoyDlh3EiMZWnYPqc7w = MBWvjLtCNkbQ97RIw4KyHSVcEeDr(eclFL1tQ3IkWmipq4a7AJfMZSbGw,'',nn6usrGtaj2LXy9)
				if tUEvo5HAfIjZgcdYxNJ8awu: gd7HyTQlEJWFDeoiCkVRz0qpYa.append([ZA1fBenNahOR3xrkjvwYSVMy6JK5s,url,'3::'+JwtElRBXZny3sY05m7jqINvViU9zSu+'::'+P5wyN7zRcUEGu9pfmqFHA4djLi+'::0'])
			nn6usrGtaj2LXy9.append("yddd[0]['appendContinuationItemsAction']['continuationItems'][1]")
			nn6usrGtaj2LXy9.append("yddd[1]")
			tUEvo5HAfIjZgcdYxNJ8awu,ZA1fBenNahOR3xrkjvwYSVMy6JK5s,aaBsTFzpoyDlh3EiMZWnYPqc7w = MBWvjLtCNkbQ97RIw4KyHSVcEeDr(FznNTLoMP5q8sv2WeUruZBRbj6Jh,'',nn6usrGtaj2LXy9)
			if tUEvo5HAfIjZgcdYxNJ8awu and gd7HyTQlEJWFDeoiCkVRz0qpYa and 'continuationItemRenderer' in list(ZA1fBenNahOR3xrkjvwYSVMy6JK5s.keys()):
				gd7HyTQlEJWFDeoiCkVRz0qpYa.append([ZA1fBenNahOR3xrkjvwYSVMy6JK5s,url,'3::0::0::0'])
	return eclFL1tQ3IkWmipq4a7AJfMZSbGw,HSInOVqc7m4xdUj81PzLYpAvNaw,gd7HyTQlEJWFDeoiCkVRz0qpYa,jwQgHWsiKcqAue6PFRYdfk8B
def CukSF8VD6UzZrosl4mbP0OXyLxd(Zy3lCqAUj9LDfSEn0dJQ,eclFL1tQ3IkWmipq4a7AJfMZSbGw,url,gMous1DWl97JdE5h6n0CFjeLZkq):
	level,JwtElRBXZny3sY05m7jqINvViU9zSu,P5wyN7zRcUEGu9pfmqFHA4djLi,KTkINZBXljPYvUOyJhzq3wxe4 = gMous1DWl97JdE5h6n0CFjeLZkq.split('::')
	nn6usrGtaj2LXy9,e8ebiUrRXAN67BdKEc3Lq9 = [],[]
	nn6usrGtaj2LXy9.append("yeee["+P5wyN7zRcUEGu9pfmqFHA4djLi+"]['shelfRenderer']['content']['verticalListRenderer']['items']")
	nn6usrGtaj2LXy9.append("yeee["+P5wyN7zRcUEGu9pfmqFHA4djLi+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalMovieListRenderer']['items']")
	nn6usrGtaj2LXy9.append("yeee["+P5wyN7zRcUEGu9pfmqFHA4djLi+"]['itemSectionRenderer']['contents'][0]['reelShelfRenderer']['items']")
	nn6usrGtaj2LXy9.append("yeee["+P5wyN7zRcUEGu9pfmqFHA4djLi+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	nn6usrGtaj2LXy9.append("yeee["+P5wyN7zRcUEGu9pfmqFHA4djLi+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalListRenderer']['items']")
	nn6usrGtaj2LXy9.append("yeee["+P5wyN7zRcUEGu9pfmqFHA4djLi+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['expandedShelfContentsRenderer']['items']")
	nn6usrGtaj2LXy9.append("yeee["+P5wyN7zRcUEGu9pfmqFHA4djLi+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
	nn6usrGtaj2LXy9.append("yeee["+P5wyN7zRcUEGu9pfmqFHA4djLi+"]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	nn6usrGtaj2LXy9.append("yeee[0]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	nn6usrGtaj2LXy9.append("yeee[0]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	nn6usrGtaj2LXy9.append("yeee[0]['itemSectionRenderer']['contents'][0]['playlistVideoListRenderer']['contents']")
	nn6usrGtaj2LXy9.append("yeee["+P5wyN7zRcUEGu9pfmqFHA4djLi+"]['reelShelfRenderer']['items']")
	nn6usrGtaj2LXy9.append("yeee["+P5wyN7zRcUEGu9pfmqFHA4djLi+"]['richSectionRenderer']['content']['richShelfRenderer']['contents']")
	nn6usrGtaj2LXy9.append("yeee")
	LNy6dSQ0vKYCtOcImZ24qPW1rHo,LUMe6Qr1Dtol9uBWpgZR4,R4azfDlOWw8j6V = MBWvjLtCNkbQ97RIw4KyHSVcEeDr(eclFL1tQ3IkWmipq4a7AJfMZSbGw,'',nn6usrGtaj2LXy9)
	if level=='3' and LNy6dSQ0vKYCtOcImZ24qPW1rHo:
		if len(LUMe6Qr1Dtol9uBWpgZR4)>0:
			for hklGvBFSHupmAE5UVQ2zOcJ8 in range(len(LUMe6Qr1Dtol9uBWpgZR4)):
				KTkINZBXljPYvUOyJhzq3wxe4 = str(hklGvBFSHupmAE5UVQ2zOcJ8)
				nn6usrGtaj2LXy9 = []
				nn6usrGtaj2LXy9.append("yfff["+KTkINZBXljPYvUOyJhzq3wxe4+"]['richItemRenderer']['content']")
				nn6usrGtaj2LXy9.append("yfff["+KTkINZBXljPYvUOyJhzq3wxe4+"]['gameCardRenderer']['game']")
				nn6usrGtaj2LXy9.append("yfff["+KTkINZBXljPYvUOyJhzq3wxe4+"]['itemSectionRenderer']['contents'][0]")
				nn6usrGtaj2LXy9.append("yfff["+KTkINZBXljPYvUOyJhzq3wxe4+"]")
				tUEvo5HAfIjZgcdYxNJ8awu,ZA1fBenNahOR3xrkjvwYSVMy6JK5s,aaBsTFzpoyDlh3EiMZWnYPqc7w = MBWvjLtCNkbQ97RIw4KyHSVcEeDr(LUMe6Qr1Dtol9uBWpgZR4,'',nn6usrGtaj2LXy9)
				if tUEvo5HAfIjZgcdYxNJ8awu: e8ebiUrRXAN67BdKEc3Lq9.append([ZA1fBenNahOR3xrkjvwYSVMy6JK5s,url,'4::'+JwtElRBXZny3sY05m7jqINvViU9zSu+'::'+P5wyN7zRcUEGu9pfmqFHA4djLi+'::'+KTkINZBXljPYvUOyJhzq3wxe4])
	return LUMe6Qr1Dtol9uBWpgZR4,LNy6dSQ0vKYCtOcImZ24qPW1rHo,e8ebiUrRXAN67BdKEc3Lq9,R4azfDlOWw8j6V
def MBWvjLtCNkbQ97RIw4KyHSVcEeDr(Iwh7pS4CTEjZeO,pzYNuWHETc9orAef1BLmShsGRIw,exHwypJaVFlc57jCPvLWIzA0XOB6M):
	Zy3lCqAUj9LDfSEn0dJQ,pzYNuWHETc9orAef1BLmShsGRIw = Iwh7pS4CTEjZeO,pzYNuWHETc9orAef1BLmShsGRIw
	FznNTLoMP5q8sv2WeUruZBRbj6Jh,pzYNuWHETc9orAef1BLmShsGRIw = Iwh7pS4CTEjZeO,pzYNuWHETc9orAef1BLmShsGRIw
	eclFL1tQ3IkWmipq4a7AJfMZSbGw,pzYNuWHETc9orAef1BLmShsGRIw = Iwh7pS4CTEjZeO,pzYNuWHETc9orAef1BLmShsGRIw
	LUMe6Qr1Dtol9uBWpgZR4,pzYNuWHETc9orAef1BLmShsGRIw = Iwh7pS4CTEjZeO,pzYNuWHETc9orAef1BLmShsGRIw
	ZA1fBenNahOR3xrkjvwYSVMy6JK5s,GKMfL9ETonN6U = Iwh7pS4CTEjZeO,pzYNuWHETc9orAef1BLmShsGRIw
	count = len(exHwypJaVFlc57jCPvLWIzA0XOB6M)
	for k3Om08MCgqQao4n1 in range(count):
		try:
			rUaDMe3xuwbk1pAzZf45Ig7GnRXojB = eval(exHwypJaVFlc57jCPvLWIzA0XOB6M[k3Om08MCgqQao4n1])
			return True,rUaDMe3xuwbk1pAzZf45Ig7GnRXojB,k3Om08MCgqQao4n1+1
		except: pass
	return False,'',0
def sscM839DP1jWZ4zl6uIx0Kyn(url,gMous1DWl97JdE5h6n0CFjeLZkq='',data=''):
	wSa45k91WxVO,gd7HyTQlEJWFDeoiCkVRz0qpYa,e8ebiUrRXAN67BdKEc3Lq9 = [],[],[]
	if '::' not in gMous1DWl97JdE5h6n0CFjeLZkq: gMous1DWl97JdE5h6n0CFjeLZkq = '1::0::0::0'
	level,JwtElRBXZny3sY05m7jqINvViU9zSu,P5wyN7zRcUEGu9pfmqFHA4djLi,KTkINZBXljPYvUOyJhzq3wxe4 = gMous1DWl97JdE5h6n0CFjeLZkq.split('::')
	if level=='4': level,JwtElRBXZny3sY05m7jqINvViU9zSu,P5wyN7zRcUEGu9pfmqFHA4djLi,KTkINZBXljPYvUOyJhzq3wxe4 = '1',JwtElRBXZny3sY05m7jqINvViU9zSu,P5wyN7zRcUEGu9pfmqFHA4djLi,KTkINZBXljPYvUOyJhzq3wxe4
	data = data.replace('_REMEMBERRESULTS_','')
	MK6ZT2zjC1SbmveNFqor,Zy3lCqAUj9LDfSEn0dJQ,toAVQS46Fv8aJYyLf25KnkUNC = ppUnVZPokRe5cA7(url,data)
	gMous1DWl97JdE5h6n0CFjeLZkq = level+'::'+JwtElRBXZny3sY05m7jqINvViU9zSu+'::'+P5wyN7zRcUEGu9pfmqFHA4djLi+'::'+KTkINZBXljPYvUOyJhzq3wxe4
	if level in ['1','2','3']:
		FznNTLoMP5q8sv2WeUruZBRbj6Jh,NaD6gRjLBqKWFY51,wSa45k91WxVO,hnKs8d34a9Cz = ZlIcNVC4zWP5gGXxqTwto8(Zy3lCqAUj9LDfSEn0dJQ,url,gMous1DWl97JdE5h6n0CFjeLZkq)
		if not NaD6gRjLBqKWFY51: return
		KaNH53jqsdTylFh = len(wSa45k91WxVO)
		if KaNH53jqsdTylFh<2:
			if level=='1': level = '2'
			wSa45k91WxVO = []
	gMous1DWl97JdE5h6n0CFjeLZkq = level+'::'+JwtElRBXZny3sY05m7jqINvViU9zSu+'::'+P5wyN7zRcUEGu9pfmqFHA4djLi+'::'+KTkINZBXljPYvUOyJhzq3wxe4
	if level in ['2','3']:
		eclFL1tQ3IkWmipq4a7AJfMZSbGw,HSInOVqc7m4xdUj81PzLYpAvNaw,gd7HyTQlEJWFDeoiCkVRz0qpYa,jwQgHWsiKcqAue6PFRYdfk8B = zwh6fMNDGeH8LbVYK1XU0(Zy3lCqAUj9LDfSEn0dJQ,FznNTLoMP5q8sv2WeUruZBRbj6Jh,url,gMous1DWl97JdE5h6n0CFjeLZkq)
		if not HSInOVqc7m4xdUj81PzLYpAvNaw: return
		y1yHIOTgXVAGmhjdQ8rEL3CxKWF = len(gd7HyTQlEJWFDeoiCkVRz0qpYa)
		if y1yHIOTgXVAGmhjdQ8rEL3CxKWF<2:
			if level=='2': level = '3'
			gd7HyTQlEJWFDeoiCkVRz0qpYa = []
	gMous1DWl97JdE5h6n0CFjeLZkq = level+'::'+JwtElRBXZny3sY05m7jqINvViU9zSu+'::'+P5wyN7zRcUEGu9pfmqFHA4djLi+'::'+KTkINZBXljPYvUOyJhzq3wxe4
	if level in ['3']:
		LUMe6Qr1Dtol9uBWpgZR4,LNy6dSQ0vKYCtOcImZ24qPW1rHo,e8ebiUrRXAN67BdKEc3Lq9,R4azfDlOWw8j6V = CukSF8VD6UzZrosl4mbP0OXyLxd(Zy3lCqAUj9LDfSEn0dJQ,eclFL1tQ3IkWmipq4a7AJfMZSbGw,url,gMous1DWl97JdE5h6n0CFjeLZkq)
		if not LNy6dSQ0vKYCtOcImZ24qPW1rHo: return
		H0qmxGO3CNSnoVh1A5weaTF = len(e8ebiUrRXAN67BdKEc3Lq9)
	for ZA1fBenNahOR3xrkjvwYSVMy6JK5s,url,gMous1DWl97JdE5h6n0CFjeLZkq in wSa45k91WxVO+gd7HyTQlEJWFDeoiCkVRz0qpYa+e8ebiUrRXAN67BdKEc3Lq9:
		r0IUeJ3ZE2OGiCdbPKRx1VTlWL = l6SBvJFG3aDHre4pjtw5R0NIucY2M(ZA1fBenNahOR3xrkjvwYSVMy6JK5s,url,gMous1DWl97JdE5h6n0CFjeLZkq)
	return
def l6SBvJFG3aDHre4pjtw5R0NIucY2M(ZA1fBenNahOR3xrkjvwYSVMy6JK5s,url='',gMous1DWl97JdE5h6n0CFjeLZkq=''):
	if '::' in gMous1DWl97JdE5h6n0CFjeLZkq: level,JwtElRBXZny3sY05m7jqINvViU9zSu,P5wyN7zRcUEGu9pfmqFHA4djLi,KTkINZBXljPYvUOyJhzq3wxe4 = gMous1DWl97JdE5h6n0CFjeLZkq.split('::')
	else: level,JwtElRBXZny3sY05m7jqINvViU9zSu,P5wyN7zRcUEGu9pfmqFHA4djLi,KTkINZBXljPYvUOyJhzq3wxe4 = '1','0','0','0'
	tUEvo5HAfIjZgcdYxNJ8awu,title,BoEFz2WhUyvTgDeiZ,IcWzVO137wFvemn2QTq8yKs9,count,LEb1HQDAeFdsrNTnVgmXo9,eBQoDdKfNvnzm73GgYjAPJR,wnpe16R7MuEO0C,biZ1MBk7OxfyUPoSYl0Vw6nhT8q = JQvSljwGLBIuADxCkomKc3RN5gs(ZA1fBenNahOR3xrkjvwYSVMy6JK5s)
	F1LtjSdUrKpG9kXsWYAOxvTe = '/videos?' in BoEFz2WhUyvTgDeiZ or '/streams?' in BoEFz2WhUyvTgDeiZ or '/playlists?' in BoEFz2WhUyvTgDeiZ
	yyT01vaXKQLDcer = '/channels?' in BoEFz2WhUyvTgDeiZ or '/shorts?' in BoEFz2WhUyvTgDeiZ
	if F1LtjSdUrKpG9kXsWYAOxvTe or yyT01vaXKQLDcer: BoEFz2WhUyvTgDeiZ = url
	F1LtjSdUrKpG9kXsWYAOxvTe = 'watch?v=' not in BoEFz2WhUyvTgDeiZ and '/playlist?list=' not in BoEFz2WhUyvTgDeiZ
	yyT01vaXKQLDcer = '/gaming' not in BoEFz2WhUyvTgDeiZ  and '/feed/storefront' not in BoEFz2WhUyvTgDeiZ
	if gMous1DWl97JdE5h6n0CFjeLZkq[0:5]=='3::0::' and F1LtjSdUrKpG9kXsWYAOxvTe and yyT01vaXKQLDcer: BoEFz2WhUyvTgDeiZ = url
	if '/youtubei/v1/guide?key=' in url or '/gaming' in BoEFz2WhUyvTgDeiZ:
		level,JwtElRBXZny3sY05m7jqINvViU9zSu,P5wyN7zRcUEGu9pfmqFHA4djLi,KTkINZBXljPYvUOyJhzq3wxe4 = '1','0','0','0'
		gMous1DWl97JdE5h6n0CFjeLZkq = ''
	toAVQS46Fv8aJYyLf25KnkUNC = ''
	if '/youtubei/v1/browse' in BoEFz2WhUyvTgDeiZ or '/youtubei/v1/search' in BoEFz2WhUyvTgDeiZ or '/my_main_page_shorts_link' in url:
		data = bLEBi8IO7uU2x3htYDdVq95.getSetting('av.youtube.data')
		if data.count(':::')==4:
			NoHlnSQv1q,key,nyPa0pmt8kslDb6MoQSUZdzu5Oqf,h13lHnQYWrbZvij6akCPoIf0M8dJ,Ujugy9ASbcRxaVeCKJ = data.split(':::')
			toAVQS46Fv8aJYyLf25KnkUNC = NoHlnSQv1q+':::'+key+':::'+nyPa0pmt8kslDb6MoQSUZdzu5Oqf+':::'+h13lHnQYWrbZvij6akCPoIf0M8dJ+':::'+biZ1MBk7OxfyUPoSYl0Vw6nhT8q
			if '/my_main_page_shorts_link' in url and not BoEFz2WhUyvTgDeiZ: BoEFz2WhUyvTgDeiZ = url
			else: BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ+'?key='+key
	if not title:
		global yys9qTIYchHwgaJ3C2
		yys9qTIYchHwgaJ3C2 += 1
		title = 'فيديوهات '+str(yys9qTIYchHwgaJ3C2)
		gMous1DWl97JdE5h6n0CFjeLZkq = '3'+'::'+JwtElRBXZny3sY05m7jqINvViU9zSu+'::'+P5wyN7zRcUEGu9pfmqFHA4djLi+'::'+KTkINZBXljPYvUOyJhzq3wxe4
	if not tUEvo5HAfIjZgcdYxNJ8awu: return False
	elif 'searchPyvRenderer' in str(ZA1fBenNahOR3xrkjvwYSVMy6JK5s): return False
	elif '/about' in BoEFz2WhUyvTgDeiZ: return False
	elif '/community' in BoEFz2WhUyvTgDeiZ: return False
	elif 'continuationItemRenderer' in list(ZA1fBenNahOR3xrkjvwYSVMy6JK5s.keys()) or 'continuationCommand' in list(ZA1fBenNahOR3xrkjvwYSVMy6JK5s.keys()):
		if int(level)>1: level = str(int(level)-1)
		gMous1DWl97JdE5h6n0CFjeLZkq = level+'::'+JwtElRBXZny3sY05m7jqINvViU9zSu+'::'+P5wyN7zRcUEGu9pfmqFHA4djLi+'::'+KTkINZBXljPYvUOyJhzq3wxe4
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+':: '+'صفحة أخرى',BoEFz2WhUyvTgDeiZ,144,IcWzVO137wFvemn2QTq8yKs9,gMous1DWl97JdE5h6n0CFjeLZkq,toAVQS46Fv8aJYyLf25KnkUNC)
	elif '/search' in BoEFz2WhUyvTgDeiZ:
		title = ':: '+title
		gMous1DWl97JdE5h6n0CFjeLZkq = '3'+'::'+JwtElRBXZny3sY05m7jqINvViU9zSu+'::'+P5wyN7zRcUEGu9pfmqFHA4djLi+'::'+KTkINZBXljPYvUOyJhzq3wxe4
		url = url.replace('/search','')
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,url,145,'',gMous1DWl97JdE5h6n0CFjeLZkq,'_REMEMBERRESULTS_')
	elif 'search_query' in url and not BoEFz2WhUyvTgDeiZ:
		gMous1DWl97JdE5h6n0CFjeLZkq = '3'+'::'+JwtElRBXZny3sY05m7jqINvViU9zSu+'::'+P5wyN7zRcUEGu9pfmqFHA4djLi+'::'+KTkINZBXljPYvUOyJhzq3wxe4
		title = ':: '+title
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,url,144,IcWzVO137wFvemn2QTq8yKs9,gMous1DWl97JdE5h6n0CFjeLZkq,toAVQS46Fv8aJYyLf25KnkUNC)
	elif '/browse' in BoEFz2WhUyvTgDeiZ and url==EZxQp1WOldMTvFU:
		title = ':: '+title
		gMous1DWl97JdE5h6n0CFjeLZkq = '2::0::0::0'
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,144,IcWzVO137wFvemn2QTq8yKs9,gMous1DWl97JdE5h6n0CFjeLZkq,toAVQS46Fv8aJYyLf25KnkUNC)
	elif not BoEFz2WhUyvTgDeiZ and 'horizontalMovieListRenderer' in str(ZA1fBenNahOR3xrkjvwYSVMy6JK5s):
		title = ':: '+title
		gMous1DWl97JdE5h6n0CFjeLZkq = '3::0::0::0'
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,url,144,IcWzVO137wFvemn2QTq8yKs9,gMous1DWl97JdE5h6n0CFjeLZkq)
	elif 'messageRenderer' in str(ZA1fBenNahOR3xrkjvwYSVMy6JK5s):
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,'',9999)
	elif eBQoDdKfNvnzm73GgYjAPJR:
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('live',teUPLFC3B8bArakwHVGsdhoIWDM49f+eBQoDdKfNvnzm73GgYjAPJR+title,BoEFz2WhUyvTgDeiZ,143,IcWzVO137wFvemn2QTq8yKs9)
	elif '/playlist?list=' in BoEFz2WhUyvTgDeiZ:
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'LIST'+count+':  '+title,BoEFz2WhUyvTgDeiZ,144,IcWzVO137wFvemn2QTq8yKs9,gMous1DWl97JdE5h6n0CFjeLZkq)
	elif '/shorts/' in BoEFz2WhUyvTgDeiZ:
		BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ.split('&list=',1)[0]
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,143,IcWzVO137wFvemn2QTq8yKs9,LEb1HQDAeFdsrNTnVgmXo9)
	elif '/watch?v=' in BoEFz2WhUyvTgDeiZ:
		if '&list=' in BoEFz2WhUyvTgDeiZ and count:
			ww3OaG7qJCgHT8L6y = BoEFz2WhUyvTgDeiZ.split('&list=',1)[1]
			BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU+'/playlist?list='+ww3OaG7qJCgHT8L6y
			gMous1DWl97JdE5h6n0CFjeLZkq = '3::0::0::0'
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'LIST'+count+':  '+title,BoEFz2WhUyvTgDeiZ,144,IcWzVO137wFvemn2QTq8yKs9,gMous1DWl97JdE5h6n0CFjeLZkq)
		else:
			BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ.split('&list=',1)[0]
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,143,IcWzVO137wFvemn2QTq8yKs9,LEb1HQDAeFdsrNTnVgmXo9)
	elif '/channel/' in BoEFz2WhUyvTgDeiZ or '/c/' in BoEFz2WhUyvTgDeiZ or ('/@' in BoEFz2WhUyvTgDeiZ and BoEFz2WhUyvTgDeiZ.count('/')==3):
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'CHNL'+count+':  '+title,BoEFz2WhUyvTgDeiZ,144,IcWzVO137wFvemn2QTq8yKs9,gMous1DWl97JdE5h6n0CFjeLZkq)
	elif '/user/' in BoEFz2WhUyvTgDeiZ:
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'USER'+count+':  '+title,BoEFz2WhUyvTgDeiZ,144,IcWzVO137wFvemn2QTq8yKs9,gMous1DWl97JdE5h6n0CFjeLZkq)
	else:
		if not BoEFz2WhUyvTgDeiZ: BoEFz2WhUyvTgDeiZ = url
		title = ':: '+title
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,144,IcWzVO137wFvemn2QTq8yKs9,gMous1DWl97JdE5h6n0CFjeLZkq,toAVQS46Fv8aJYyLf25KnkUNC)
	return True
def JQvSljwGLBIuADxCkomKc3RN5gs(ZA1fBenNahOR3xrkjvwYSVMy6JK5s):
	tUEvo5HAfIjZgcdYxNJ8awu,title,BoEFz2WhUyvTgDeiZ,IcWzVO137wFvemn2QTq8yKs9,count,LEb1HQDAeFdsrNTnVgmXo9,eBQoDdKfNvnzm73GgYjAPJR,wnpe16R7MuEO0C,Ujugy9ASbcRxaVeCKJ = False,'','','','','','','',''
	if not isinstance(ZA1fBenNahOR3xrkjvwYSVMy6JK5s,dict): return tUEvo5HAfIjZgcdYxNJ8awu,title,BoEFz2WhUyvTgDeiZ,IcWzVO137wFvemn2QTq8yKs9,count,LEb1HQDAeFdsrNTnVgmXo9,eBQoDdKfNvnzm73GgYjAPJR,wnpe16R7MuEO0C,Ujugy9ASbcRxaVeCKJ
	for GSF2AQUXlc in list(ZA1fBenNahOR3xrkjvwYSVMy6JK5s.keys()):
		GKMfL9ETonN6U = ZA1fBenNahOR3xrkjvwYSVMy6JK5s[GSF2AQUXlc]
		if isinstance(GKMfL9ETonN6U,dict): break
	nn6usrGtaj2LXy9 = []
	nn6usrGtaj2LXy9.append("yrender['header']['richListHeaderRenderer']['title']['simpleText']")
	nn6usrGtaj2LXy9.append("yrender['header']['richListHeaderRenderer']['title']")
	nn6usrGtaj2LXy9.append("yrender['headline']['simpleText']")
	nn6usrGtaj2LXy9.append("yrender['unplayableText']['simpleText']")
	nn6usrGtaj2LXy9.append("yrender['formattedTitle']['simpleText']")
	nn6usrGtaj2LXy9.append("yrender['title']['simpleText']")
	nn6usrGtaj2LXy9.append("yrender['title']['runs'][0]['text']")
	nn6usrGtaj2LXy9.append("yrender['text']['simpleText']")
	nn6usrGtaj2LXy9.append("yrender['text']['runs'][0]['text']")
	nn6usrGtaj2LXy9.append("yrender['title']")
	nn6usrGtaj2LXy9.append("item['title']")
	nn6usrGtaj2LXy9.append("item['reelWatchEndpoint']['videoId']")
	tUEvo5HAfIjZgcdYxNJ8awu,title,aaBsTFzpoyDlh3EiMZWnYPqc7w = MBWvjLtCNkbQ97RIw4KyHSVcEeDr(ZA1fBenNahOR3xrkjvwYSVMy6JK5s,GKMfL9ETonN6U,nn6usrGtaj2LXy9)
	nn6usrGtaj2LXy9 = []
	nn6usrGtaj2LXy9.append("yrender['title']['runs'][0]['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	nn6usrGtaj2LXy9.append("yrender['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	nn6usrGtaj2LXy9.append("yrender['continuationEndpoint']['commandMetadata']['webCommandMetadata']['apiUrl']")
	nn6usrGtaj2LXy9.append("yrender['navigationEndpoint']['commandMetadata']['webCommandMetadata']['apiUrl']")
	nn6usrGtaj2LXy9.append("yrender['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	nn6usrGtaj2LXy9.append("item['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	nn6usrGtaj2LXy9.append("item['commandMetadata']['webCommandMetadata']['url']")
	tUEvo5HAfIjZgcdYxNJ8awu,BoEFz2WhUyvTgDeiZ,aaBsTFzpoyDlh3EiMZWnYPqc7w = MBWvjLtCNkbQ97RIw4KyHSVcEeDr(ZA1fBenNahOR3xrkjvwYSVMy6JK5s,GKMfL9ETonN6U,nn6usrGtaj2LXy9)
	nn6usrGtaj2LXy9 = []
	nn6usrGtaj2LXy9.append("yrender['thumbnail']['thumbnails'][0]['url']")
	nn6usrGtaj2LXy9.append("yrender['thumbnails'][0]['thumbnails'][0]['url']")
	nn6usrGtaj2LXy9.append("item['reelWatchEndpoint']['thumbnail']['thumbnails'][0]['url']")
	tUEvo5HAfIjZgcdYxNJ8awu,IcWzVO137wFvemn2QTq8yKs9,aaBsTFzpoyDlh3EiMZWnYPqc7w = MBWvjLtCNkbQ97RIw4KyHSVcEeDr(ZA1fBenNahOR3xrkjvwYSVMy6JK5s,GKMfL9ETonN6U,nn6usrGtaj2LXy9)
	nn6usrGtaj2LXy9 = []
	nn6usrGtaj2LXy9.append("yrender['videoCount']")
	nn6usrGtaj2LXy9.append("yrender['videoCountText']['runs'][0]['text']")
	nn6usrGtaj2LXy9.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayBottomPanelRenderer']['text']['runs'][0]['text']")
	tUEvo5HAfIjZgcdYxNJ8awu,count,aaBsTFzpoyDlh3EiMZWnYPqc7w = MBWvjLtCNkbQ97RIw4KyHSVcEeDr(ZA1fBenNahOR3xrkjvwYSVMy6JK5s,GKMfL9ETonN6U,nn6usrGtaj2LXy9)
	nn6usrGtaj2LXy9 = []
	nn6usrGtaj2LXy9.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['runs'][0]['text']")
	nn6usrGtaj2LXy9.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['simpleText']")
	nn6usrGtaj2LXy9.append("yrender['lengthText']['simpleText']")
	nn6usrGtaj2LXy9.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['icon']['iconType']")
	nn6usrGtaj2LXy9.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['style']")
	tUEvo5HAfIjZgcdYxNJ8awu,LEb1HQDAeFdsrNTnVgmXo9,aaBsTFzpoyDlh3EiMZWnYPqc7w = MBWvjLtCNkbQ97RIw4KyHSVcEeDr(ZA1fBenNahOR3xrkjvwYSVMy6JK5s,GKMfL9ETonN6U,nn6usrGtaj2LXy9)
	nn6usrGtaj2LXy9 = []
	nn6usrGtaj2LXy9.append("yrender['navigationEndpoint']['continuationCommand']['token']")
	nn6usrGtaj2LXy9.append("yrender['continuationEndpoint']['continuationCommand']['token']")
	tUEvo5HAfIjZgcdYxNJ8awu,Ujugy9ASbcRxaVeCKJ,aaBsTFzpoyDlh3EiMZWnYPqc7w = MBWvjLtCNkbQ97RIw4KyHSVcEeDr(ZA1fBenNahOR3xrkjvwYSVMy6JK5s,GKMfL9ETonN6U,nn6usrGtaj2LXy9)
	if 'LIVE' in LEb1HQDAeFdsrNTnVgmXo9: LEb1HQDAeFdsrNTnVgmXo9,eBQoDdKfNvnzm73GgYjAPJR = '','LIVE:  '
	if 'مباشر' in LEb1HQDAeFdsrNTnVgmXo9: LEb1HQDAeFdsrNTnVgmXo9,eBQoDdKfNvnzm73GgYjAPJR = '','LIVE:  '
	if 'badges' in list(GKMfL9ETonN6U.keys()):
		vpjoYRLzVE0FH6x43a8 = str(GKMfL9ETonN6U['badges'])
		if 'Free with Ads' in vpjoYRLzVE0FH6x43a8: wnpe16R7MuEO0C = '$:  '
		if 'LIVE' in vpjoYRLzVE0FH6x43a8: eBQoDdKfNvnzm73GgYjAPJR = 'LIVE:  '
		if 'Buy' in vpjoYRLzVE0FH6x43a8 or 'Rent' in vpjoYRLzVE0FH6x43a8: wnpe16R7MuEO0C = '$$:  '
		if gEYUZMaD6vB(u'مباشر') in vpjoYRLzVE0FH6x43a8: eBQoDdKfNvnzm73GgYjAPJR = 'LIVE:  '
		if gEYUZMaD6vB(u'شراء') in vpjoYRLzVE0FH6x43a8: wnpe16R7MuEO0C = '$$:  '
		if gEYUZMaD6vB(u'استئجار') in vpjoYRLzVE0FH6x43a8: wnpe16R7MuEO0C = '$$:  '
		if gEYUZMaD6vB(u'إعلانات') in vpjoYRLzVE0FH6x43a8: wnpe16R7MuEO0C = '$:  '
	BoEFz2WhUyvTgDeiZ = tW06wVMpReHfnj3KgzT2va(BoEFz2WhUyvTgDeiZ)
	if BoEFz2WhUyvTgDeiZ and 'http' not in BoEFz2WhUyvTgDeiZ: BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU+BoEFz2WhUyvTgDeiZ
	IcWzVO137wFvemn2QTq8yKs9 = IcWzVO137wFvemn2QTq8yKs9.split('?')[0]
	if  IcWzVO137wFvemn2QTq8yKs9 and 'http' not in IcWzVO137wFvemn2QTq8yKs9: IcWzVO137wFvemn2QTq8yKs9 = 'https:'+IcWzVO137wFvemn2QTq8yKs9
	title = tW06wVMpReHfnj3KgzT2va(title)
	if wnpe16R7MuEO0C: title = wnpe16R7MuEO0C+title
	LEb1HQDAeFdsrNTnVgmXo9 = LEb1HQDAeFdsrNTnVgmXo9.replace(',','')
	count = count.replace(',','')
	count = My7Dwqvs6bfGNSIgX.findall('\d+',count)
	if count: count = count[0]
	else: count = ''
	return True,title,BoEFz2WhUyvTgDeiZ,IcWzVO137wFvemn2QTq8yKs9,count,LEb1HQDAeFdsrNTnVgmXo9,eBQoDdKfNvnzm73GgYjAPJR,wnpe16R7MuEO0C,Ujugy9ASbcRxaVeCKJ
def ppUnVZPokRe5cA7(url,data='',h5QaxwPF7SOu6fMBTGXRU2yn=''):
	if h5QaxwPF7SOu6fMBTGXRU2yn=='': h5QaxwPF7SOu6fMBTGXRU2yn = 'ytInitialData'
	rHqkc3e0CJ5VByi6vLs = IeSGolOpBHM8U62m()
	eIL9BxdTbZj = {'User-Agent':rHqkc3e0CJ5VByi6vLs,'Cookie':'PREF=hl=ar'}
	global bLEBi8IO7uU2x3htYDdVq95
	if not data: data = bLEBi8IO7uU2x3htYDdVq95.getSetting('av.youtube.data')
	if data.count(':::')==4: NoHlnSQv1q,key,nyPa0pmt8kslDb6MoQSUZdzu5Oqf,h13lHnQYWrbZvij6akCPoIf0M8dJ,Ujugy9ASbcRxaVeCKJ = data.split(':::')
	else: NoHlnSQv1q,key,nyPa0pmt8kslDb6MoQSUZdzu5Oqf,h13lHnQYWrbZvij6akCPoIf0M8dJ,Ujugy9ASbcRxaVeCKJ = '','','','',''
	toAVQS46Fv8aJYyLf25KnkUNC = {"context":{"client":{"hl":"ar","clientName":"WEB","clientVersion":nyPa0pmt8kslDb6MoQSUZdzu5Oqf}}}
	if url==EZxQp1WOldMTvFU+'/shorts' or '/my_main_page_shorts_link' in url:
		url = EZxQp1WOldMTvFU+'/youtubei/v1/reel/reel_watch_sequence'+'?key='+key
		toAVQS46Fv8aJYyLf25KnkUNC['sequenceParams'] = NoHlnSQv1q
		toAVQS46Fv8aJYyLf25KnkUNC = str(toAVQS46Fv8aJYyLf25KnkUNC)
		xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(f9Oum6c0FotxYn,'POST',url,toAVQS46Fv8aJYyLf25KnkUNC,eIL9BxdTbZj,True,True,'YOUTUBE-GET_PAGE_DATA-1st')
	elif '/guide?key=' in url:
		url = EZxQp1WOldMTvFU+'/youtubei/v1/guide?key='+key
		toAVQS46Fv8aJYyLf25KnkUNC = str(toAVQS46Fv8aJYyLf25KnkUNC)
		xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(f9Oum6c0FotxYn,'POST',url,toAVQS46Fv8aJYyLf25KnkUNC,eIL9BxdTbZj,True,True,'YOUTUBE-GET_PAGE_DATA-3rd')
	elif 'key=' in url and NoHlnSQv1q:
		toAVQS46Fv8aJYyLf25KnkUNC['continuation'] = Ujugy9ASbcRxaVeCKJ
		toAVQS46Fv8aJYyLf25KnkUNC['context']['client']['visitorData'] = NoHlnSQv1q
		toAVQS46Fv8aJYyLf25KnkUNC = str(toAVQS46Fv8aJYyLf25KnkUNC)
		xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(f9Oum6c0FotxYn,'POST',url,toAVQS46Fv8aJYyLf25KnkUNC,eIL9BxdTbZj,True,True,'YOUTUBE-GET_PAGE_DATA-4th')
	elif 'ctoken=' in url and h13lHnQYWrbZvij6akCPoIf0M8dJ:
		eIL9BxdTbZj.update({'X-YouTube-Client-Name':'1','X-YouTube-Client-Version':nyPa0pmt8kslDb6MoQSUZdzu5Oqf})
		eIL9BxdTbZj.update({'Cookie':'VISITOR_INFO1_LIVE='+h13lHnQYWrbZvij6akCPoIf0M8dJ})
		xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(f9Oum6c0FotxYn,'GET',url,'',eIL9BxdTbZj,'','','YOUTUBE-GET_PAGE_DATA-5th')
	else:
		xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(f9Oum6c0FotxYn,'GET',url,'',eIL9BxdTbZj,'','','YOUTUBE-GET_PAGE_DATA-6th')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	AwKc1kuJ7V = My7Dwqvs6bfGNSIgX.findall('"innertubeApiKey".*?"(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL|My7Dwqvs6bfGNSIgX.I)
	if AwKc1kuJ7V: key = AwKc1kuJ7V[0]
	AwKc1kuJ7V = My7Dwqvs6bfGNSIgX.findall('"cver".*?"value".*?"(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL|My7Dwqvs6bfGNSIgX.I)
	if AwKc1kuJ7V: nyPa0pmt8kslDb6MoQSUZdzu5Oqf = AwKc1kuJ7V[0]
	AwKc1kuJ7V = My7Dwqvs6bfGNSIgX.findall('"visitorData".*?"(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL|My7Dwqvs6bfGNSIgX.I)
	if AwKc1kuJ7V: NoHlnSQv1q = AwKc1kuJ7V[0]
	cookies = xHb86g9WZqPwRfVjXD2JalzSIp.cookies
	if 'VISITOR_INFO1_LIVE' in list(cookies.keys()): h13lHnQYWrbZvij6akCPoIf0M8dJ = cookies['VISITOR_INFO1_LIVE']
	nIVjDQ0AwGaFqic6eRlxPNK3HOyWUS = NoHlnSQv1q+':::'+key+':::'+nyPa0pmt8kslDb6MoQSUZdzu5Oqf+':::'+h13lHnQYWrbZvij6akCPoIf0M8dJ+':::'+Ujugy9ASbcRxaVeCKJ
	if h5QaxwPF7SOu6fMBTGXRU2yn=='ytInitialData' and 'ytInitialData' in MK6ZT2zjC1SbmveNFqor:
		qKeCANPab2LFMRxdlJg4OSBircopZ = My7Dwqvs6bfGNSIgX.findall('window\["ytInitialData"\] = ({.*?});',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if not qKeCANPab2LFMRxdlJg4OSBircopZ: qKeCANPab2LFMRxdlJg4OSBircopZ = My7Dwqvs6bfGNSIgX.findall('var ytInitialData = ({.*?});',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		gTzA63iMfhc7lerFGkZ = dWsa2A0O4o5BYiqGXhyKEbM('str',qKeCANPab2LFMRxdlJg4OSBircopZ[0])
	elif h5QaxwPF7SOu6fMBTGXRU2yn=='ytInitialGuideData' and 'ytInitialGuideData' in MK6ZT2zjC1SbmveNFqor:
		qKeCANPab2LFMRxdlJg4OSBircopZ = My7Dwqvs6bfGNSIgX.findall('var ytInitialGuideData = ({.*?});',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		gTzA63iMfhc7lerFGkZ = dWsa2A0O4o5BYiqGXhyKEbM('str',qKeCANPab2LFMRxdlJg4OSBircopZ[0])
	elif '</script>' not in MK6ZT2zjC1SbmveNFqor: gTzA63iMfhc7lerFGkZ = dWsa2A0O4o5BYiqGXhyKEbM('str',MK6ZT2zjC1SbmveNFqor)
	else: gTzA63iMfhc7lerFGkZ = ''
	if 0:
		Zy3lCqAUj9LDfSEn0dJQ = str(gTzA63iMfhc7lerFGkZ)
		if BLz7m2RkNrxXQwy1cGAp: Zy3lCqAUj9LDfSEn0dJQ = Zy3lCqAUj9LDfSEn0dJQ.encode('utf8')
		open('S:\\0000emad.dat','wb').write(Zy3lCqAUj9LDfSEn0dJQ)
	bLEBi8IO7uU2x3htYDdVq95.setSetting('av.youtube.data',nIVjDQ0AwGaFqic6eRlxPNK3HOyWUS)
	return MK6ZT2zjC1SbmveNFqor,gTzA63iMfhc7lerFGkZ,nIVjDQ0AwGaFqic6eRlxPNK3HOyWUS
def iuAoJsgSL0XVRzqalHWtFMhOIG(url,gMous1DWl97JdE5h6n0CFjeLZkq):
	search = ViKAIsLurq83RSENayxWb()
	if not search: return
	search = search.replace(' ','+')
	bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = url+'/search?query='+search
	sscM839DP1jWZ4zl6uIx0Kyn(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,gMous1DWl97JdE5h6n0CFjeLZkq)
	return
def HjZcUIVAXFCqy9TfBWKtgY2(search):
	search,LQf3AeozSrai,showDialogs = X54MLovbG8nAEkB9J(search)
	if not search:
		search = ViKAIsLurq83RSENayxWb()
		if not search: return
	search = search.replace(' ','+')
	bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = EZxQp1WOldMTvFU+'/results?search_query='+search
	if not showDialogs:
		if '_YOUTUBE-VIDEOS_' in LQf3AeozSrai: YG52KvqnRAje70VB6FHy = '&sp=EgIQAQ%253D%253D'
		elif '_YOUTUBE-PLAYLISTS_' in LQf3AeozSrai: YG52KvqnRAje70VB6FHy = '&sp=EgIQAw%253D%253D'
		elif '_YOUTUBE-CHANNELS_' in LQf3AeozSrai: YG52KvqnRAje70VB6FHy = '&sp=EgIQAg%253D%253D'
		else: YG52KvqnRAje70VB6FHy = ''
		QAKdHzO0rehbtyIc = bJEs4IVAPdyUrhwCLv9k2YoOl8nt1+YG52KvqnRAje70VB6FHy
	else:
		swi31aSpUhu8BnyqHzA,VLUFypBuGD,U2UaTcgBpsEZxKiRG1Xv8 = [],[],''
		QJHxig8uj359LO = ['بدون ترتيب','ترتيب حسب مدى الصلة','ترتيب حسب تاريخ التحميل','ترتيب حسب عدد المشاهدات','ترتيب حسب التقييم']
		fuzLxYPMWc = ['','&sp=CAA%253D','&sp=CAI%253D','&sp=CAM%253D','&sp=CAE%253D']
		ppCbDLftGS5d9UjY = CnKwdteDG5BE8MTRhUpYIJm3NLrSgq('موقع يوتيوب - اختر الترتيب',QJHxig8uj359LO)
		if ppCbDLftGS5d9UjY == -1: return
		WuB7DsHA45cCMURlgqVKj8NnYdZIQ = fuzLxYPMWc[ppCbDLftGS5d9UjY]
		MK6ZT2zjC1SbmveNFqor,qfFZ5QSOedhUiK46N,data = ppUnVZPokRe5cA7(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1+WuB7DsHA45cCMURlgqVKj8NnYdZIQ)
		if qfFZ5QSOedhUiK46N:
			try:
				DtzW0B4cmRrL17ue2CpS9xIKhVU = qfFZ5QSOedhUiK46N['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['subMenu']['searchSubMenuRenderer']['groups']
				for ZdOyVpHDs2IAlbT0Ntkzaq4PLGm in range(len(DtzW0B4cmRrL17ue2CpS9xIKhVU)):
					group = DtzW0B4cmRrL17ue2CpS9xIKhVU[ZdOyVpHDs2IAlbT0Ntkzaq4PLGm]['searchFilterGroupRenderer']['filters']
					for pTsvU85nlcJbzmPNy in range(len(group)):
						GKMfL9ETonN6U = group[pTsvU85nlcJbzmPNy]['searchFilterRenderer']
						if 'navigationEndpoint' in list(GKMfL9ETonN6U.keys()):
							BoEFz2WhUyvTgDeiZ = GKMfL9ETonN6U['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']
							BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ.replace('\u0026','&')
							title = GKMfL9ETonN6U['tooltip']
							title = title.replace('البحث عن ','')
							if 'إزالة الفلتر' in title: continue
							if 'قائمة تشغيل' in title:
								title = 'جيد للمسلسلات '+title
								U2UaTcgBpsEZxKiRG1Xv8 = title
								bOBQpgMudItXo = BoEFz2WhUyvTgDeiZ
							if 'ترتيب حسب' in title: continue
							title = title.replace('Search for ','')
							if 'Remove' in title: continue
							if 'Playlist' in title:
								title = 'جيد للمسلسلات '+title
								U2UaTcgBpsEZxKiRG1Xv8 = title
								bOBQpgMudItXo = BoEFz2WhUyvTgDeiZ
							if 'Sort by' in title: continue
							swi31aSpUhu8BnyqHzA.append(tW06wVMpReHfnj3KgzT2va(title))
							VLUFypBuGD.append(BoEFz2WhUyvTgDeiZ)
			except: pass
		if not U2UaTcgBpsEZxKiRG1Xv8: SuBdhHj8XfLEkr5pmVCTnwRAZzyPQq = ''
		else:
			swi31aSpUhu8BnyqHzA = ['بدون فلتر',U2UaTcgBpsEZxKiRG1Xv8]+swi31aSpUhu8BnyqHzA
			VLUFypBuGD = ['',bOBQpgMudItXo]+VLUFypBuGD
			fdthjEURqgP836YC59JeOzNlHIw20 = CnKwdteDG5BE8MTRhUpYIJm3NLrSgq('موقع يوتيوب - اختر الفلتر',swi31aSpUhu8BnyqHzA)
			if fdthjEURqgP836YC59JeOzNlHIw20 == -1: return
			SuBdhHj8XfLEkr5pmVCTnwRAZzyPQq = VLUFypBuGD[fdthjEURqgP836YC59JeOzNlHIw20]
		if SuBdhHj8XfLEkr5pmVCTnwRAZzyPQq: QAKdHzO0rehbtyIc = EZxQp1WOldMTvFU+SuBdhHj8XfLEkr5pmVCTnwRAZzyPQq
		elif WuB7DsHA45cCMURlgqVKj8NnYdZIQ: QAKdHzO0rehbtyIc = bJEs4IVAPdyUrhwCLv9k2YoOl8nt1+WuB7DsHA45cCMURlgqVKj8NnYdZIQ
		else: QAKdHzO0rehbtyIc = bJEs4IVAPdyUrhwCLv9k2YoOl8nt1
	sscM839DP1jWZ4zl6uIx0Kyn(QAKdHzO0rehbtyIc)
	return
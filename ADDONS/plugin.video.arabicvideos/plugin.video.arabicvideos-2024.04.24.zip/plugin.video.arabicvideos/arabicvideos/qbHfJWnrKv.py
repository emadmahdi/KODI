# -*- coding: utf-8 -*-
from G6AHskJeqN import *
baNWS6nfqTC5iX4Kl = 'WECIMA'
headers = {'User-Agent':''}
teUPLFC3B8bArakwHVGsdhoIWDM49f = '_WCM_'
EZxQp1WOldMTvFU = AK5RqLhji4W1wt9VdrCD3PGeQM[baNWS6nfqTC5iX4Kl][0]
eh2tDvRFWpLQI = ['مصارعة حرة','wwe']
def VbgEajY4Bt2COpGDcPqI(mode,url,text):
	if   mode==560: ft3e2JBKQVXWlFPjaMhkEqGxvDg = eN02L7Tf5bQ()
	elif mode==561: ft3e2JBKQVXWlFPjaMhkEqGxvDg = sscM839DP1jWZ4zl6uIx0Kyn(url,text)
	elif mode==562: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HDxCnPKFhITpZmOsA4a0UL6(url)
	elif mode==563: ft3e2JBKQVXWlFPjaMhkEqGxvDg = o4oY13v5dWMcbilEDjKCnXNzHZ0(url,text)
	elif mode==564: ft3e2JBKQVXWlFPjaMhkEqGxvDg = LLJlTxDePyjoVKA(url,'CATEGORIES___'+text)
	elif mode==565: ft3e2JBKQVXWlFPjaMhkEqGxvDg = LLJlTxDePyjoVKA(url,'FILTERS___'+text)
	elif mode==566: ft3e2JBKQVXWlFPjaMhkEqGxvDg = M25iOAH9NfalvyPEUuToG8qn(url)
	elif mode==569: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HjZcUIVAXFCqy9TfBWKtgY2(text,url)
	else: ft3e2JBKQVXWlFPjaMhkEqGxvDg = False
	return ft3e2JBKQVXWlFPjaMhkEqGxvDg
def eN02L7Tf5bQ():
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'بحث في الموقع',EZxQp1WOldMTvFU,569,'','','_REMEMBERRESULTS_')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'فلتر محدد',EZxQp1WOldMTvFU+'/AjaxCenter/RightBar',564)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'فلتر كامل',EZxQp1WOldMTvFU+'/AjaxCenter/RightBar',565)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(IIiPCruL6dT8s1lqj47SzpVHnYNm,'GET',EZxQp1WOldMTvFU,'','','','','WECIMA-MENU-2nd')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('class="NavigationMenu"(.*?)class="ProductionsListButton"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('class="menu-item.*?href="(.*?)">(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title in items:
			if title=='': continue
			if any(WoFrX46wzbCNp18 in title.lower() for WoFrX46wzbCNp18 in eh2tDvRFWpLQI): continue
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,566)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('hoverable activable(.*?)hoverable activable',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?url\((.*?)\).*?span>(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,IcWzVO137wFvemn2QTq8yKs9,title in items:
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,566,IcWzVO137wFvemn2QTq8yKs9)
	return MK6ZT2zjC1SbmveNFqor
def M25iOAH9NfalvyPEUuToG8qn(url):
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(IIiPCruL6dT8s1lqj47SzpVHnYNm,'GET',url,'','','','','WECIMA-SUBMENU-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	if 'class="Slider--Grid"' in MK6ZT2zjC1SbmveNFqor:
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'المميزة',url,561,'','','featured')
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('class="list--Tabsui"(.*?)div',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?i>(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title in items:
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,561)
	return
def sscM839DP1jWZ4zl6uIx0Kyn(L0JdOojQqcZxg,type=''):
	if '::' in L0JdOojQqcZxg:
		QAKdHzO0rehbtyIc,url = L0JdOojQqcZxg.split('::')
		LkVZrOE4XBSN2Qex5PyHqC = ooq2D9xF8ZLpPBs(QAKdHzO0rehbtyIc,'url')
		url = LkVZrOE4XBSN2Qex5PyHqC+url
	else: url,QAKdHzO0rehbtyIc = L0JdOojQqcZxg,L0JdOojQqcZxg
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'','','','','WECIMA-TITLES-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	if type=='featured':
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('class="Slider--Grid"(.*?)class="list--Tabsui"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	elif type in ['filters','search']:
		XBuP6Op7y4K = [MK6ZT2zjC1SbmveNFqor.replace('\\/','/').replace('\\"','"')]
	else:
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"Grid--WecimaPosts"(.*?)"RightUI"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	y7y3d5Fbhv42ONmtwLZ0SerYoQq = []
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('"Thumb--GridItem".*?href="(.*?)" title="(.*?)".*?url\((.*?)\)',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title,IcWzVO137wFvemn2QTq8yKs9 in items:
			if any(WoFrX46wzbCNp18 in title.lower() for WoFrX46wzbCNp18 in eh2tDvRFWpLQI): continue
			IcWzVO137wFvemn2QTq8yKs9 = tW06wVMpReHfnj3KgzT2va(IcWzVO137wFvemn2QTq8yKs9)
			BoEFz2WhUyvTgDeiZ = tW06wVMpReHfnj3KgzT2va(BoEFz2WhUyvTgDeiZ)
			title = PIfAumbGicwg5ye(title)
			title = tW06wVMpReHfnj3KgzT2va(title)
			title = title.replace('مشاهدة ','')
			if '/series/' in BoEFz2WhUyvTgDeiZ: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,563,IcWzVO137wFvemn2QTq8yKs9)
			elif 'حلقة' in title:
				ffhN7jAqe3Q4cR0Ukptzl = My7Dwqvs6bfGNSIgX.findall('(.*?) +حلقة +\d+',title,My7Dwqvs6bfGNSIgX.DOTALL)
				if ffhN7jAqe3Q4cR0Ukptzl: title = '_MOD_' + ffhN7jAqe3Q4cR0Ukptzl[0]
				if title not in y7y3d5Fbhv42ONmtwLZ0SerYoQq:
					y7y3d5Fbhv42ONmtwLZ0SerYoQq.append(title)
					VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,563,IcWzVO137wFvemn2QTq8yKs9)
			else:
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,562,IcWzVO137wFvemn2QTq8yKs9)
		if type=='filters':
			c8xyLVFa6uoi = My7Dwqvs6bfGNSIgX.findall('"more_button_page":(.*?),',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
			if c8xyLVFa6uoi:
				count = c8xyLVFa6uoi[0]
				BoEFz2WhUyvTgDeiZ = url+'/offset/'+count
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'صفحة أخرى',BoEFz2WhUyvTgDeiZ,561,'','','filters')
		elif type=='':
			XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('class="pagination(.*?)</div>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
			if XBuP6Op7y4K:
				vsptNMP2ZQC = XBuP6Op7y4K[0]
				items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)">(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
				for BoEFz2WhUyvTgDeiZ,title in items:
					if 'http' not in BoEFz2WhUyvTgDeiZ: BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU+BoEFz2WhUyvTgDeiZ
					title = 'صفحة '+PIfAumbGicwg5ye(title)
					VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,561)
	return
def o4oY13v5dWMcbilEDjKCnXNzHZ0(url,type=''):
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'','','','','WECIMA-EPISODES-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	MK6ZT2zjC1SbmveNFqor = XnQbsZF0Ouh8p7zCdUN(MK6ZT2zjC1SbmveNFqor)
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('class="Seasons--Episodes"(.*?)</div>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if not type and XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)">(.*?)</a>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		if len(items)>1:
			for BoEFz2WhUyvTgDeiZ,title in items:
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,563,'','','episodes')
			return
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('class="Episodes--Seasons--Episodes(.*?)</singlesections>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?<episodeTitle>(.*?)</episodeTitle>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL|My7Dwqvs6bfGNSIgX.IGNORECASE)
		for BoEFz2WhUyvTgDeiZ,title in items:
			title = title.strip(' ')
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,562)
	if not xx4viQhaOu6r0:
		title = My7Dwqvs6bfGNSIgX.findall('<title>(.*?)<',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if title: title = title[0].replace(' - ماي سيما','').replace('مشاهدة ','')
		else: title = 'ملف التشغيل'
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,url,562)
	return
def HDxCnPKFhITpZmOsA4a0UL6(url):
	QQ2cE1FjUyxPonbDhaTkV6B3i = []
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(f9Oum6c0FotxYn,'GET',url,'','','','','WECIMA-PLAY-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	ME2Q6F7u8Vp1km9ws = My7Dwqvs6bfGNSIgX.findall('<span>التصنيف<.*?<a.*?">(.*?)<.*?">(.*?)<',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if ME2Q6F7u8Vp1km9ws:
		ME2Q6F7u8Vp1km9ws = [ME2Q6F7u8Vp1km9ws[0][0],ME2Q6F7u8Vp1km9ws[0][1]]
		if ME2Q6F7u8Vp1km9ws and a97xrkSOefH5DbjXunq(baNWS6nfqTC5iX4Kl,url,ME2Q6F7u8Vp1km9ws): return
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('class="WatchServersList"(.*?)class="WatchServersEmbed"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('data-url="(.*?)".*?strong>(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,name in items:
			if 'http' not in BoEFz2WhUyvTgDeiZ: BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU+BoEFz2WhUyvTgDeiZ
			if name=='سيرفر وي سيما': name = 'wecima'
			BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ+'?named='+name+'__watch'
			BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ.replace('\n','').replace('\r','')
			QQ2cE1FjUyxPonbDhaTkV6B3i.append(BoEFz2WhUyvTgDeiZ)
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('class="List--Download(.*?)</div>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?</i>(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,LLnUyuiC2wRM0 in items:
			if 'http' not in BoEFz2WhUyvTgDeiZ: BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU+BoEFz2WhUyvTgDeiZ
			LLnUyuiC2wRM0 = My7Dwqvs6bfGNSIgX.findall('\d\d\d+',LLnUyuiC2wRM0,My7Dwqvs6bfGNSIgX.DOTALL)
			if LLnUyuiC2wRM0: LLnUyuiC2wRM0 = '____'+LLnUyuiC2wRM0[0]
			else: LLnUyuiC2wRM0 = ''
			BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ+'?named=wecima'+'__download'+LLnUyuiC2wRM0
			BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ.replace('\n','').replace('\r','')
			QQ2cE1FjUyxPonbDhaTkV6B3i.append(BoEFz2WhUyvTgDeiZ)
	import t1kDWXQVpC
	t1kDWXQVpC.rqVt2xDi7jzJHBcPMRs6h0L(QQ2cE1FjUyxPonbDhaTkV6B3i,baNWS6nfqTC5iX4Kl,'video',url)
	return
def HjZcUIVAXFCqy9TfBWKtgY2(search,vsdV2y56aAYDxzCrcoSu7M1Hm=''):
	search,LQf3AeozSrai,showDialogs = X54MLovbG8nAEkB9J(search)
	if search=='': search = ViKAIsLurq83RSENayxWb()
	if search=='': return
	search = search.replace(' ','+')
	if not vsdV2y56aAYDxzCrcoSu7M1Hm:
		vsdV2y56aAYDxzCrcoSu7M1Hm = EZxQp1WOldMTvFU
	bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = vsdV2y56aAYDxzCrcoSu7M1Hm+'/AjaxCenter/Searching/'+search+'/'
	sscM839DP1jWZ4zl6uIx0Kyn(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,'search')
	return
def LLJlTxDePyjoVKA(L0JdOojQqcZxg,filter):
	if '??' in L0JdOojQqcZxg: url = L0JdOojQqcZxg.split('//getposts??')[0]
	else: url = L0JdOojQqcZxg
	filter = filter.replace('_FORGETRESULTS_','')
	type,filter = filter.split('___',1)
	if filter=='': H2HMwT4JFz7rDkPZmRjcX,JPnr9ICqkDyV = '',''
	else: H2HMwT4JFz7rDkPZmRjcX,JPnr9ICqkDyV = filter.split('___')
	if type=='CATEGORIES':
		if kEaCuLOYxJQI7btFwzV3P[0]+'==' not in H2HMwT4JFz7rDkPZmRjcX: g4Y0BXLxCpuojKP1SAUtcq7TwN2 = kEaCuLOYxJQI7btFwzV3P[0]
		for FVW0I9sYcAjmDgn8r in range(len(kEaCuLOYxJQI7btFwzV3P[0:-1])):
			if kEaCuLOYxJQI7btFwzV3P[FVW0I9sYcAjmDgn8r]+'==' in H2HMwT4JFz7rDkPZmRjcX: g4Y0BXLxCpuojKP1SAUtcq7TwN2 = kEaCuLOYxJQI7btFwzV3P[FVW0I9sYcAjmDgn8r+1]
		HHXeMqVOshPcW3tULa5v = H2HMwT4JFz7rDkPZmRjcX+'&&'+g4Y0BXLxCpuojKP1SAUtcq7TwN2+'==0'
		DoSfCckGA9BQe = JPnr9ICqkDyV+'&&'+g4Y0BXLxCpuojKP1SAUtcq7TwN2+'==0'
		A7AEKRlF6Hf3eWVxY0NdwgsMPCc = HHXeMqVOshPcW3tULa5v.strip('&&')+'___'+DoSfCckGA9BQe.strip('&&')
		woj78rBnbLlmZWIy19iPHFCf5 = BrbZhHKJ0jnIe2lumE9M(JPnr9ICqkDyV,'modified_filters')
		bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = url+'//getposts??'+woj78rBnbLlmZWIy19iPHFCf5
	elif type=='FILTERS':
		WUSylLup41cYkhVXGtq = BrbZhHKJ0jnIe2lumE9M(H2HMwT4JFz7rDkPZmRjcX,'modified_values')
		WUSylLup41cYkhVXGtq = XnQbsZF0Ouh8p7zCdUN(WUSylLup41cYkhVXGtq)
		if JPnr9ICqkDyV!='': JPnr9ICqkDyV = BrbZhHKJ0jnIe2lumE9M(JPnr9ICqkDyV,'modified_filters')
		if JPnr9ICqkDyV=='': bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = url
		else: bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = url+'//getposts??'+JPnr9ICqkDyV
		UnFC90p8KGPSwHJrV = onz7dgENVKPxB(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,L0JdOojQqcZxg)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'أظهار قائمة الفيديو التي تم اختيارها ',UnFC90p8KGPSwHJrV,561,'','','filters')
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+' [[   '+WUSylLup41cYkhVXGtq+'   ]]',UnFC90p8KGPSwHJrV,561,'','','filters')
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(IIiPCruL6dT8s1lqj47SzpVHnYNm,'GET',url,'','','','','WECIMA-FILTERS_MENU-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	MK6ZT2zjC1SbmveNFqor = MK6ZT2zjC1SbmveNFqor.replace('\\"','"').replace('\\/','/')
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('<wecima--filter(.*?)</wecima--filter>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if not XBuP6Op7y4K: return
	vsptNMP2ZQC = XBuP6Op7y4K[0]
	E3ErsLQfR4JXt = My7Dwqvs6bfGNSIgX.findall('taxonomy="(.*?)".*?<span>(.*?)<(.*?)<filterbox',vsptNMP2ZQC+'<filterbox',My7Dwqvs6bfGNSIgX.DOTALL)
	dict = {}
	for RTsbVE9CiQt,name,vsptNMP2ZQC in E3ErsLQfR4JXt:
		name = tW06wVMpReHfnj3KgzT2va(name)
		if 'interest' in RTsbVE9CiQt: continue
		items = My7Dwqvs6bfGNSIgX.findall('data-term="(.*?)".*?<txt>(.*?)</txt>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		if '==' not in bJEs4IVAPdyUrhwCLv9k2YoOl8nt1: bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = url
		if type=='CATEGORIES':
			if g4Y0BXLxCpuojKP1SAUtcq7TwN2!=RTsbVE9CiQt: continue
			elif len(items)<=1:
				if RTsbVE9CiQt==kEaCuLOYxJQI7btFwzV3P[-1]: sscM839DP1jWZ4zl6uIx0Kyn(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1)
				else: LLJlTxDePyjoVKA(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,'CATEGORIES___'+A7AEKRlF6Hf3eWVxY0NdwgsMPCc)
				return
			else:
				UnFC90p8KGPSwHJrV = onz7dgENVKPxB(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,L0JdOojQqcZxg)
				if RTsbVE9CiQt==kEaCuLOYxJQI7btFwzV3P[-1]:
					VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'الجميع',UnFC90p8KGPSwHJrV,561,'','','filters')
				else: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'الجميع',bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,564,'','',A7AEKRlF6Hf3eWVxY0NdwgsMPCc)
		elif type=='FILTERS':
			HHXeMqVOshPcW3tULa5v = H2HMwT4JFz7rDkPZmRjcX+'&&'+RTsbVE9CiQt+'==0'
			DoSfCckGA9BQe = JPnr9ICqkDyV+'&&'+RTsbVE9CiQt+'==0'
			A7AEKRlF6Hf3eWVxY0NdwgsMPCc = HHXeMqVOshPcW3tULa5v+'___'+DoSfCckGA9BQe
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+name+': الجميع',bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,565,'','',A7AEKRlF6Hf3eWVxY0NdwgsMPCc+'_FORGETRESULTS_')
		dict[RTsbVE9CiQt] = {}
		for WoFrX46wzbCNp18,A5AMg7LY1HlOz0B82n in items:
			name = tW06wVMpReHfnj3KgzT2va(name)
			A5AMg7LY1HlOz0B82n = tW06wVMpReHfnj3KgzT2va(A5AMg7LY1HlOz0B82n)
			if WoFrX46wzbCNp18=='r' or WoFrX46wzbCNp18=='nc-17': continue
			if any(WoFrX46wzbCNp18 in A5AMg7LY1HlOz0B82n.lower() for WoFrX46wzbCNp18 in eh2tDvRFWpLQI): continue
			if 'http' in A5AMg7LY1HlOz0B82n: continue
			if 'الكل' in A5AMg7LY1HlOz0B82n: continue
			if 'n-a' in WoFrX46wzbCNp18: continue
			if A5AMg7LY1HlOz0B82n=='': A5AMg7LY1HlOz0B82n = WoFrX46wzbCNp18
			yXskwRgtdJ = A5AMg7LY1HlOz0B82n
			mNldo9CrLIXJkbWAzEpD56 = My7Dwqvs6bfGNSIgX.findall('<name>(.*?)</name>',A5AMg7LY1HlOz0B82n,My7Dwqvs6bfGNSIgX.DOTALL)
			if mNldo9CrLIXJkbWAzEpD56: yXskwRgtdJ = mNldo9CrLIXJkbWAzEpD56[0]
			U2UaTcgBpsEZxKiRG1Xv8 = name+': '+yXskwRgtdJ
			dict[RTsbVE9CiQt][WoFrX46wzbCNp18] = U2UaTcgBpsEZxKiRG1Xv8
			HHXeMqVOshPcW3tULa5v = H2HMwT4JFz7rDkPZmRjcX+'&&'+RTsbVE9CiQt+'=='+yXskwRgtdJ
			DoSfCckGA9BQe = JPnr9ICqkDyV+'&&'+RTsbVE9CiQt+'=='+WoFrX46wzbCNp18
			QQIzTLCXyhtZ7pRNnGq = HHXeMqVOshPcW3tULa5v+'___'+DoSfCckGA9BQe
			if type=='FILTERS':
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+U2UaTcgBpsEZxKiRG1Xv8,url,565,'','',QQIzTLCXyhtZ7pRNnGq+'_FORGETRESULTS_')
			elif type=='CATEGORIES' and kEaCuLOYxJQI7btFwzV3P[-2]+'==' in H2HMwT4JFz7rDkPZmRjcX:
				woj78rBnbLlmZWIy19iPHFCf5 = BrbZhHKJ0jnIe2lumE9M(DoSfCckGA9BQe,'modified_filters')
				QAKdHzO0rehbtyIc = url+'//getposts??'+woj78rBnbLlmZWIy19iPHFCf5
				UnFC90p8KGPSwHJrV = onz7dgENVKPxB(QAKdHzO0rehbtyIc,L0JdOojQqcZxg)
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+U2UaTcgBpsEZxKiRG1Xv8,UnFC90p8KGPSwHJrV,561,'','','filters')
			else: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+U2UaTcgBpsEZxKiRG1Xv8,url,564,'','',QQIzTLCXyhtZ7pRNnGq)
	return
kEaCuLOYxJQI7btFwzV3P = ['genre','release-year','nation']
DlOqSAQowZ4 = ['mpaa','genre','release-year','category','Quality','interest','nation','language']
def onz7dgENVKPxB(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,QAKdHzO0rehbtyIc):
	if '/AjaxCenter/RightBar' in bJEs4IVAPdyUrhwCLv9k2YoOl8nt1: bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = bJEs4IVAPdyUrhwCLv9k2YoOl8nt1.replace('/AjaxCenter/RightBar','/AjaxCenter/Filtering')
	bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = bJEs4IVAPdyUrhwCLv9k2YoOl8nt1.replace('//getposts??','::/AjaxCenter/Filtering/')
	bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = bJEs4IVAPdyUrhwCLv9k2YoOl8nt1.replace('==','/')
	bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = bJEs4IVAPdyUrhwCLv9k2YoOl8nt1.replace('&&','/')
	return bJEs4IVAPdyUrhwCLv9k2YoOl8nt1
def BrbZhHKJ0jnIe2lumE9M(PPebqkulZUsx3GCLdnYvR,mode):
	PPebqkulZUsx3GCLdnYvR = PPebqkulZUsx3GCLdnYvR.strip('&&')
	mVSjqdOvyf,DidZH6E0pJelcU9xMCBgyL2KvR = {},''
	if '==' in PPebqkulZUsx3GCLdnYvR:
		items = PPebqkulZUsx3GCLdnYvR.split('&&')
		for ZA1fBenNahOR3xrkjvwYSVMy6JK5s in items:
			nmqEj60bcdSQoFPGa,WoFrX46wzbCNp18 = ZA1fBenNahOR3xrkjvwYSVMy6JK5s.split('==')
			mVSjqdOvyf[nmqEj60bcdSQoFPGa] = WoFrX46wzbCNp18
	for key in DlOqSAQowZ4:
		if key in list(mVSjqdOvyf.keys()): WoFrX46wzbCNp18 = mVSjqdOvyf[key]
		else: WoFrX46wzbCNp18 = '0'
		if '%' not in WoFrX46wzbCNp18: WoFrX46wzbCNp18 = F8fMqZKB4APk(WoFrX46wzbCNp18)
		if mode=='modified_values' and WoFrX46wzbCNp18!='0': DidZH6E0pJelcU9xMCBgyL2KvR = DidZH6E0pJelcU9xMCBgyL2KvR+' + '+WoFrX46wzbCNp18
		elif mode=='modified_filters' and WoFrX46wzbCNp18!='0': DidZH6E0pJelcU9xMCBgyL2KvR = DidZH6E0pJelcU9xMCBgyL2KvR+'&&'+key+'=='+WoFrX46wzbCNp18
		elif mode=='all': DidZH6E0pJelcU9xMCBgyL2KvR = DidZH6E0pJelcU9xMCBgyL2KvR+'&&'+key+'=='+WoFrX46wzbCNp18
	DidZH6E0pJelcU9xMCBgyL2KvR = DidZH6E0pJelcU9xMCBgyL2KvR.strip(' + ')
	DidZH6E0pJelcU9xMCBgyL2KvR = DidZH6E0pJelcU9xMCBgyL2KvR.strip('&&')
	return DidZH6E0pJelcU9xMCBgyL2KvR
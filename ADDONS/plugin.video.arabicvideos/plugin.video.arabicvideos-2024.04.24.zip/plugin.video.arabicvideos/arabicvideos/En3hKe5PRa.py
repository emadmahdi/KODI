# -*- coding: utf-8 -*-
from G6AHskJeqN import *
baNWS6nfqTC5iX4Kl = 'FASELHD2'
headers = {'User-Agent':''}
teUPLFC3B8bArakwHVGsdhoIWDM49f = '_FH2_'
EZxQp1WOldMTvFU = AK5RqLhji4W1wt9VdrCD3PGeQM[baNWS6nfqTC5iX4Kl][0]
eh2tDvRFWpLQI = ['wwe']
def VbgEajY4Bt2COpGDcPqI(mode,url,text):
	if   mode==590: ft3e2JBKQVXWlFPjaMhkEqGxvDg = eN02L7Tf5bQ()
	elif mode==591: ft3e2JBKQVXWlFPjaMhkEqGxvDg = sscM839DP1jWZ4zl6uIx0Kyn(url,text)
	elif mode==592: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HDxCnPKFhITpZmOsA4a0UL6(url)
	elif mode==593: ft3e2JBKQVXWlFPjaMhkEqGxvDg = rFZB0V49nigPyfKQHqcLXEs(url,text)
	elif mode==599: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HjZcUIVAXFCqy9TfBWKtgY2(text)
	else: ft3e2JBKQVXWlFPjaMhkEqGxvDg = False
	return ft3e2JBKQVXWlFPjaMhkEqGxvDg
def eN02L7Tf5bQ():
	xxE5BSyQkNsj = EZxQp1WOldMTvFU
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',xxE5BSyQkNsj,'','','','','FASELHD2-MENU-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'بحث في الموقع',xxE5BSyQkNsj,599,'','','_REMEMBERRESULTS_')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'المميزة',xxE5BSyQkNsj,591,'','','featured1')
	items = My7Dwqvs6bfGNSIgX.findall('<strong>(.*?)</strong>.*?href="(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	for title,BoEFz2WhUyvTgDeiZ in items:
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,591,'','','details1')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('main-menu"(.*?)header-social',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		vUK80uOnNs = My7Dwqvs6bfGNSIgX.findall('<li (.*?)</li>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for us7LOaKdRDwxbt0lP in vUK80uOnNs:
			items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?>(.*?)<',us7LOaKdRDwxbt0lP,My7Dwqvs6bfGNSIgX.DOTALL)
			for BoEFz2WhUyvTgDeiZ,title in items:
				if 'http' not in BoEFz2WhUyvTgDeiZ: BoEFz2WhUyvTgDeiZ = xxE5BSyQkNsj+BoEFz2WhUyvTgDeiZ
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,591,'','','details2')
	return MK6ZT2zjC1SbmveNFqor
def sscM839DP1jWZ4zl6uIx0Kyn(url,type=''):
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'','','','','FASELHD2-TITLES-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	Cc8ERvU6anBp0gFW = 0
	kdYXhMN8Hpbt = My7Dwqvs6bfGNSIgX.findall('"archive-slider(.*?)<h4>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if kdYXhMN8Hpbt: iiBEzXVNFDhfj36 = kdYXhMN8Hpbt[0]
	else: iiBEzXVNFDhfj36 = ''
	if type=='featured1':
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"slider-carousel"(.*?)</container>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall(' src="(.*?)".*?"slider-title">(.*?)<.*?<a href="(.*?)"',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		VZIuOLhil3qjRvJsM18me,msjnlSMrQGJ4oLwE2d,NVHrZsqUp2 = zip(*items)
		items = zip(NVHrZsqUp2,VZIuOLhil3qjRvJsM18me,msjnlSMrQGJ4oLwE2d)
	elif type=='featured2':
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?image:url\((.*?)\).*?<h3.*?>(.*?)</h3>',iiBEzXVNFDhfj36,My7Dwqvs6bfGNSIgX.DOTALL)
	elif type=='filters':
		XBuP6Op7y4K = [MK6ZT2zjC1SbmveNFqor.replace('\\/','/').replace('\\"','"')]
	elif type=='details2' and 'href' in iiBEzXVNFDhfj36:
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('<h4>(.*?)</h4>(.*?)</container>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'مميزة',url,591,'','','featured2')
		title = XBuP6Op7y4K[0][0]
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,url,591,'','','details3')
		return
	else:
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('<h4>(.*?)</h4>(.*?)</container>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		title,vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?image:url\((.*?)\).*?<h3.*?>(.*?)</h3>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	tkBQK76YMeUlRI1TomgECfA = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية','حلقة']
	y7y3d5Fbhv42ONmtwLZ0SerYoQq = []
	for BoEFz2WhUyvTgDeiZ,IcWzVO137wFvemn2QTq8yKs9,title in items:
		if any(WoFrX46wzbCNp18 in title.lower() for WoFrX46wzbCNp18 in eh2tDvRFWpLQI): continue
		title = title.strip(' ')
		title = PIfAumbGicwg5ye(title)
		ffhN7jAqe3Q4cR0Ukptzl = My7Dwqvs6bfGNSIgX.findall('(.*?) (الحلقة|حلقة).\d+',title,My7Dwqvs6bfGNSIgX.DOTALL)
		if '/movseries/' in BoEFz2WhUyvTgDeiZ:
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,591,IcWzVO137wFvemn2QTq8yKs9)
		elif ffhN7jAqe3Q4cR0Ukptzl and type=='':
			title = '_MOD_'+ffhN7jAqe3Q4cR0Ukptzl[0][0]
			if title not in y7y3d5Fbhv42ONmtwLZ0SerYoQq:
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,593,IcWzVO137wFvemn2QTq8yKs9)
				y7y3d5Fbhv42ONmtwLZ0SerYoQq.append(title)
		elif any(WoFrX46wzbCNp18 in title for WoFrX46wzbCNp18 in tkBQK76YMeUlRI1TomgECfA):
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,592,IcWzVO137wFvemn2QTq8yKs9)
		else: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,593,IcWzVO137wFvemn2QTq8yKs9)
	if type=='filters':
		c8xyLVFa6uoi = My7Dwqvs6bfGNSIgX.findall('"more_button_page":(.*?),',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		if c8xyLVFa6uoi:
			count = c8xyLVFa6uoi[0]
			BoEFz2WhUyvTgDeiZ = url+'/offset/'+count
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'صفحة أخرى',BoEFz2WhUyvTgDeiZ,591,'','','filters')
	elif 'details' in type:
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('class="pagination(.*?)</div>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if XBuP6Op7y4K:
			vsptNMP2ZQC = XBuP6Op7y4K[0]
			items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)">(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
			for BoEFz2WhUyvTgDeiZ,title in items:
				title = 'صفحة '+PIfAumbGicwg5ye(title)
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,591,'','','details4')
	return
def rFZB0V49nigPyfKQHqcLXEs(url,type=''):
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'','','','','FASELHD2-SEASONS_EPISODES-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	Or0yBIEzGeCn6pkYDgRal78F = False
	if not type:
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('<seasons(.*?)</seasons>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if XBuP6Op7y4K:
			vsptNMP2ZQC = XBuP6Op7y4K[0]
			items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?image:url\((.*?)\).*?<h3>(.*?)</h3>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
			if len(items)>1:
				xxE5BSyQkNsj = ooq2D9xF8ZLpPBs(url,'url')
				Or0yBIEzGeCn6pkYDgRal78F = True
				for BoEFz2WhUyvTgDeiZ,IcWzVO137wFvemn2QTq8yKs9,title in items:
					title = PIfAumbGicwg5ye(title)
					VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,593,IcWzVO137wFvemn2QTq8yKs9,'','episodes')
	if type=='episodes' or not Or0yBIEzGeCn6pkYDgRal78F:
		QFrVYJkywEsXquMNz = My7Dwqvs6bfGNSIgX.findall('<bkز*?image:url\((.*?)\)"></bk>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if QFrVYJkywEsXquMNz: IcWzVO137wFvemn2QTq8yKs9 = QFrVYJkywEsXquMNz[0]
		else: IcWzVO137wFvemn2QTq8yKs9 = ''
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('<all-episodes(.*?)</all-episodes>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if XBuP6Op7y4K:
			vsptNMP2ZQC = XBuP6Op7y4K[0]
			items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?>(.*?)</a>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
			for BoEFz2WhUyvTgDeiZ,title in items:
				title = title.strip(' ')
				title = PIfAumbGicwg5ye(title)
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,592,IcWzVO137wFvemn2QTq8yKs9)
	return
def HDxCnPKFhITpZmOsA4a0UL6(url):
	Qki8AbTHYjzM2Ls76Gdr3eqo1Wn,aoYuIjAPW4LEqS,rr6pcuETVCl9oqeX = [],[],[]
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(f9Oum6c0FotxYn,'GET',url,'','','','','FASELHD2-PLAY-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	SSKNAfwnx0olOWULjQpm1 = My7Dwqvs6bfGNSIgX.findall('العمر :.*?<strong">(.*?)</strong>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if SSKNAfwnx0olOWULjQpm1 and a97xrkSOefH5DbjXunq(baNWS6nfqTC5iX4Kl,url,SSKNAfwnx0olOWULjQpm1): return
	BoEFz2WhUyvTgDeiZ = My7Dwqvs6bfGNSIgX.findall('<iframe src="(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if BoEFz2WhUyvTgDeiZ:
		BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ[0]
		Qki8AbTHYjzM2Ls76Gdr3eqo1Wn.append(BoEFz2WhUyvTgDeiZ+'?named=__embed')
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('<slice-title(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('data-url="(.*?)".*?</i>(.*?)</li>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,name in items:
			name = name.strip(' ')
			Qki8AbTHYjzM2Ls76Gdr3eqo1Wn.append(BoEFz2WhUyvTgDeiZ+'?named='+name+'__watch')
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('<downloads(.*?)</downloads>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?</div>(.*?)</div>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,name in items:
			Qki8AbTHYjzM2Ls76Gdr3eqo1Wn.append(BoEFz2WhUyvTgDeiZ+'?named='+name+'__download')
	for Xz0Ci5v2IdFfB4ptaySE8emlR7 in Qki8AbTHYjzM2Ls76Gdr3eqo1Wn:
		BoEFz2WhUyvTgDeiZ,name = Xz0Ci5v2IdFfB4ptaySE8emlR7.split('?named')
		if BoEFz2WhUyvTgDeiZ not in aoYuIjAPW4LEqS:
			aoYuIjAPW4LEqS.append(BoEFz2WhUyvTgDeiZ)
			rr6pcuETVCl9oqeX.append(Xz0Ci5v2IdFfB4ptaySE8emlR7)
	import t1kDWXQVpC
	t1kDWXQVpC.rqVt2xDi7jzJHBcPMRs6h0L(rr6pcuETVCl9oqeX,baNWS6nfqTC5iX4Kl,'video',url)
	return
def HjZcUIVAXFCqy9TfBWKtgY2(search):
	search,LQf3AeozSrai,showDialogs = X54MLovbG8nAEkB9J(search)
	if search=='': search = ViKAIsLurq83RSENayxWb()
	if search=='': return
	search = search.replace(' ','+')
	xxE5BSyQkNsj = EZxQp1WOldMTvFU
	url = xxE5BSyQkNsj+'/?s='+search
	sscM839DP1jWZ4zl6uIx0Kyn(url,'details5')
	return
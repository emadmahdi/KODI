# -*- coding: utf-8 -*-
from G6AHskJeqN import *
baNWS6nfqTC5iX4Kl = 'LIVETV'
EZxQp1WOldMTvFU = AK5RqLhji4W1wt9VdrCD3PGeQM['PYTHON'][0]
def VbgEajY4Bt2COpGDcPqI(mode,url):
	if   mode==100: ft3e2JBKQVXWlFPjaMhkEqGxvDg = eN02L7Tf5bQ()
	elif mode==101: ft3e2JBKQVXWlFPjaMhkEqGxvDg = TJZvpKG2we('0',True)
	elif mode==102: ft3e2JBKQVXWlFPjaMhkEqGxvDg = TJZvpKG2we('1',True)
	elif mode==103: ft3e2JBKQVXWlFPjaMhkEqGxvDg = TJZvpKG2we('2',True)
	elif mode==104: ft3e2JBKQVXWlFPjaMhkEqGxvDg = TJZvpKG2we('3',True)
	elif mode==105: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HDxCnPKFhITpZmOsA4a0UL6(url)
	elif mode==106: ft3e2JBKQVXWlFPjaMhkEqGxvDg = TJZvpKG2we('4',True)
	else: ft3e2JBKQVXWlFPjaMhkEqGxvDg = False
	return ft3e2JBKQVXWlFPjaMhkEqGxvDg
def eN02L7Tf5bQ():
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','_M3U_'+'قوائم فيديوهات M3U','',762)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','_IPT_'+'قوائم فيديوهات IPTV','',761)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','_TV0_'+'قنوات من مواقعها الأصلية','',101)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','_TV4_'+'قنوات مختارة من يوتيوب','',106)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','_YUT_'+'قنوات عربية من يوتيوب','',147)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','_YUT_'+'قنوات أجنبية من يوتيوب','',148)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','_IFL_'+'  قناة آي فيلم من موقعهم  ','',28)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('live','_MRF_'+'قناة المعارف من موقعهم','',41)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('live','_PNT_'+'قناة هلا من موقع بانيت','',38)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','_TV1_'+'قنوات تلفزيونية عامة','',102)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','_TV2_'+'قنوات تلفزيونية خاصة','',103)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','_TV3_'+'قنوات تلفزيونية للفحص','',104)
	return
def TJZvpKG2we(us7LOaKdRDwxbt0lP,showDialogs=True):
	teUPLFC3B8bArakwHVGsdhoIWDM49f = '_TV'+us7LOaKdRDwxbt0lP+'_'
	ggfedDsABTMIh = hvc2sXOB31KTLgiZaQUR9xuGjloYS(32)
	tWha1P9LVeuNxpQUAB = {'id':'','user':ggfedDsABTMIh,'function':'list','menu':us7LOaKdRDwxbt0lP}
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(f9Oum6c0FotxYn,'POST',EZxQp1WOldMTvFU,tWha1P9LVeuNxpQUAB,'','','','LIVETV-ITEMS-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	items = My7Dwqvs6bfGNSIgX.findall('([^;\r\n]+?);;(.*?);;(.*?);;(.*?);;(.*?);;',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if items:
		for FVW0I9sYcAjmDgn8r in range(len(items)):
			name = items[FVW0I9sYcAjmDgn8r][3]
			start = name[0:2]
			start = start.replace('al','Al')
			start = start.replace('El','Al')
			start = start.replace('AL','Al')
			start = start.replace('EL','Al')
			name = start+name[2:]
			start = name[0:3]
			start = start.replace('Al-','Al')
			start = start.replace('Al ','Al')
			name = start+name[3:]
			items[FVW0I9sYcAjmDgn8r] = items[FVW0I9sYcAjmDgn8r][0],items[FVW0I9sYcAjmDgn8r][1],items[FVW0I9sYcAjmDgn8r][2],name,items[FVW0I9sYcAjmDgn8r][4]
		items = set(items)
		items = sorted(items, reverse=False, key=lambda key: key[0].lower())
		items = sorted(items, reverse=False, key=lambda key: key[3].lower())
		for iW6eqtHJGnzFhTSgduj7Pys2w,LkVZrOE4XBSN2Qex5PyHqC,cyRC5wYOFEPj9T,name,IcWzVO137wFvemn2QTq8yKs9 in items:
			if '#' in iW6eqtHJGnzFhTSgduj7Pys2w: continue
			if iW6eqtHJGnzFhTSgduj7Pys2w!='URL': name = name+'[COLOR FFC89008]   '+iW6eqtHJGnzFhTSgduj7Pys2w+'[/COLOR]'
			url = iW6eqtHJGnzFhTSgduj7Pys2w+';;'+LkVZrOE4XBSN2Qex5PyHqC+';;'+cyRC5wYOFEPj9T+';;'+us7LOaKdRDwxbt0lP
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('live',teUPLFC3B8bArakwHVGsdhoIWDM49f+''+name,url,105,IcWzVO137wFvemn2QTq8yKs9)
	else:
		if showDialogs: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link',teUPLFC3B8bArakwHVGsdhoIWDM49f+'هذه الخدمة مخصصة للمبرمج فقط','',9999)
	return
def HDxCnPKFhITpZmOsA4a0UL6(id):
	iW6eqtHJGnzFhTSgduj7Pys2w,LkVZrOE4XBSN2Qex5PyHqC,cyRC5wYOFEPj9T,us7LOaKdRDwxbt0lP = id.split(';;')
	url = ''
	ggfedDsABTMIh = hvc2sXOB31KTLgiZaQUR9xuGjloYS(32)
	if iW6eqtHJGnzFhTSgduj7Pys2w=='URL': url = cyRC5wYOFEPj9T
	elif iW6eqtHJGnzFhTSgduj7Pys2w=='YOUTUBE':
		url = AK5RqLhji4W1wt9VdrCD3PGeQM['YOUTUBE'][0]+'/watch?v='+cyRC5wYOFEPj9T
		import t1kDWXQVpC
		t1kDWXQVpC.rqVt2xDi7jzJHBcPMRs6h0L([url],baNWS6nfqTC5iX4Kl,'live',url)
		return
	elif iW6eqtHJGnzFhTSgduj7Pys2w=='GA':
		tWha1P9LVeuNxpQUAB = { 'id' : '', 'user' : ggfedDsABTMIh , 'function' : 'playGA1' , 'menu' : '' }
		xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(f9Oum6c0FotxYn,'GET',EZxQp1WOldMTvFU,tWha1P9LVeuNxpQUAB,'',False,'','LIVETV-PLAY-1st')
		if not xHb86g9WZqPwRfVjXD2JalzSIp.succeeded:
			ZIOHgA3z0TBR('','','رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
		cookies = xHb86g9WZqPwRfVjXD2JalzSIp.cookies
		so9iw0MdTLyl6tXP2KHGIR4VAr = cookies['ASP.NET_SessionId']
		url = xHb86g9WZqPwRfVjXD2JalzSIp.headers['Location']
		tWha1P9LVeuNxpQUAB = { 'id' : cyRC5wYOFEPj9T , 'user' : ggfedDsABTMIh , 'function' : 'playGA2' , 'menu' : '' }
		headers = { 'Cookie' : 'ASP.NET_SessionId='+so9iw0MdTLyl6tXP2KHGIR4VAr }
		xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(f9Oum6c0FotxYn,'GET',EZxQp1WOldMTvFU,tWha1P9LVeuNxpQUAB,headers,'','','LIVETV-PLAY-2nd')
		if not xHb86g9WZqPwRfVjXD2JalzSIp.succeeded:
			ZIOHgA3z0TBR('','','رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
		url = My7Dwqvs6bfGNSIgX.findall('resp":"(http.*?m3u8)(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		BoEFz2WhUyvTgDeiZ = url[0][0]
		xLTSPVp8zUgblio3vOq6sM027EF = url[0][1]
		jjCbk9ZI1HTEmhoecrD2QMBV07LYP = 'http://38.'+LkVZrOE4XBSN2Qex5PyHqC+'777/'+cyRC5wYOFEPj9T+'_HD.m3u8'+xLTSPVp8zUgblio3vOq6sM027EF
		OYrqhoNdKD8stewfpmBLM1UA4 = jjCbk9ZI1HTEmhoecrD2QMBV07LYP.replace('36:7','40:7').replace('_HD.m3u8','.m3u8')
		sK1wDZlTdBEhLcU6VeCgbNGamO = jjCbk9ZI1HTEmhoecrD2QMBV07LYP.replace('36:7','42:7').replace('_HD.m3u8','.m3u8')
		wlfZEzuRyYLvrp = ['HD','SD1','SD2']
		QQ2cE1FjUyxPonbDhaTkV6B3i = [jjCbk9ZI1HTEmhoecrD2QMBV07LYP,OYrqhoNdKD8stewfpmBLM1UA4,sK1wDZlTdBEhLcU6VeCgbNGamO]
		GOtNfU3xQFkEhPouwA = 0
		if GOtNfU3xQFkEhPouwA == -1: return
		else: url = QQ2cE1FjUyxPonbDhaTkV6B3i[GOtNfU3xQFkEhPouwA]
	elif iW6eqtHJGnzFhTSgduj7Pys2w=='NT':
		headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
		tWha1P9LVeuNxpQUAB = { 'id' : cyRC5wYOFEPj9T , 'user' : ggfedDsABTMIh , 'function' : 'playNT' , 'menu' : us7LOaKdRDwxbt0lP }
		xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(f9Oum6c0FotxYn,'POST', EZxQp1WOldMTvFU, tWha1P9LVeuNxpQUAB, headers, False,'','LIVETV-PLAY-3rd')
		if not xHb86g9WZqPwRfVjXD2JalzSIp.succeeded:
			ZIOHgA3z0TBR('','','رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
		url = xHb86g9WZqPwRfVjXD2JalzSIp.headers['Location']
		url = url.replace('%20',' ')
		url = url.replace('%3D','=')
		if 'Learn' in cyRC5wYOFEPj9T:
			url = url.replace('NTNNile','')
			url = url.replace('learning1','Learning')
	elif iW6eqtHJGnzFhTSgduj7Pys2w=='PL':
		tWha1P9LVeuNxpQUAB = { 'id' : cyRC5wYOFEPj9T , 'user' : ggfedDsABTMIh , 'function' : 'playPL' , 'menu' : us7LOaKdRDwxbt0lP }
		xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(f9Oum6c0FotxYn,'POST', EZxQp1WOldMTvFU, tWha1P9LVeuNxpQUAB, '',False,'','LIVETV-PLAY-4th')
		if not xHb86g9WZqPwRfVjXD2JalzSIp.succeeded:
			ZIOHgA3z0TBR('','','رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
		url = xHb86g9WZqPwRfVjXD2JalzSIp.headers['Location']
		headers = {'Referer':xHb86g9WZqPwRfVjXD2JalzSIp.headers['Referer']}
		xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(SToQEHqGtMnAlFbCz4wxBDuOsmW7,'POST',url, '',headers , '','','LIVETV-PLAY-5th')
		if not xHb86g9WZqPwRfVjXD2JalzSIp.succeeded:
			ZIOHgA3z0TBR('','','رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
		items = My7Dwqvs6bfGNSIgX.findall('source src="(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		url = items[0]
	elif iW6eqtHJGnzFhTSgduj7Pys2w in ['TA','FM','YU','WS1','WS2','RL1','RL2']:
		if iW6eqtHJGnzFhTSgduj7Pys2w=='TA': cyRC5wYOFEPj9T = id
		headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
		tWha1P9LVeuNxpQUAB = { 'id' : cyRC5wYOFEPj9T , 'user' : ggfedDsABTMIh , 'function' : 'play'+iW6eqtHJGnzFhTSgduj7Pys2w , 'menu' : us7LOaKdRDwxbt0lP }
		xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(f9Oum6c0FotxYn,'POST',EZxQp1WOldMTvFU,tWha1P9LVeuNxpQUAB,headers,'','','LIVETV-PLAY-6th')
		if not xHb86g9WZqPwRfVjXD2JalzSIp.succeeded:
			ZIOHgA3z0TBR('','','رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
		url = xHb86g9WZqPwRfVjXD2JalzSIp.headers['Location']
		if iW6eqtHJGnzFhTSgduj7Pys2w=='FM':
			xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(SToQEHqGtMnAlFbCz4wxBDuOsmW7,'GET', url, '', '', False,'','LIVETV-PLAY-7th')
			url = xHb86g9WZqPwRfVjXD2JalzSIp.headers['Location']
			url = url.replace('https','http')
	B0xcwKkMQ16mpSFRaVHPTzuhUZngLq(url,baNWS6nfqTC5iX4Kl,'live')
	return
# -*- coding: utf-8 -*-
from G6AHskJeqN import *
baNWS6nfqTC5iX4Kl = 'EGYNOW'
teUPLFC3B8bArakwHVGsdhoIWDM49f = '_EGN_'
EZxQp1WOldMTvFU = AK5RqLhji4W1wt9VdrCD3PGeQM[baNWS6nfqTC5iX4Kl][0]
eh2tDvRFWpLQI = ['عروض مصارعة','الكل','n/A','المزيد','قصة عشق']
def VbgEajY4Bt2COpGDcPqI(mode,url,text):
	if   mode==430: ft3e2JBKQVXWlFPjaMhkEqGxvDg = eN02L7Tf5bQ()
	elif mode==431: ft3e2JBKQVXWlFPjaMhkEqGxvDg = sscM839DP1jWZ4zl6uIx0Kyn(url,text)
	elif mode==432: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HDxCnPKFhITpZmOsA4a0UL6(url)
	elif mode==433: ft3e2JBKQVXWlFPjaMhkEqGxvDg = o4oY13v5dWMcbilEDjKCnXNzHZ0(url)
	elif mode==434: ft3e2JBKQVXWlFPjaMhkEqGxvDg = LLJlTxDePyjoVKA(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==435: ft3e2JBKQVXWlFPjaMhkEqGxvDg = LLJlTxDePyjoVKA(url,'SPECIFIED_FILTER___'+text)
	elif mode==436: ft3e2JBKQVXWlFPjaMhkEqGxvDg = M25iOAH9NfalvyPEUuToG8qn(url)
	elif mode==437: ft3e2JBKQVXWlFPjaMhkEqGxvDg = u9ECGV25pJqdslHj34TnML7IWK(url)
	elif mode==439: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HjZcUIVAXFCqy9TfBWKtgY2(text)
	else: ft3e2JBKQVXWlFPjaMhkEqGxvDg = False
	return ft3e2JBKQVXWlFPjaMhkEqGxvDg
def eN02L7Tf5bQ():
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',EZxQp1WOldMTvFU+'/films','','','','','EGYNOW-MENU-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	xxE5BSyQkNsj = My7Dwqvs6bfGNSIgX.findall('"canonical" href="(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	xxE5BSyQkNsj = xxE5BSyQkNsj[0].strip('/')
	xxE5BSyQkNsj = ooq2D9xF8ZLpPBs(xxE5BSyQkNsj,'url')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'بحث في الموقع','',439,'','','_REMEMBERRESULTS_')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'فلتر محدد',xxE5BSyQkNsj,435)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'فلتر كامل',xxE5BSyQkNsj,434)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'المضاف حديثا',xxE5BSyQkNsj,431)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'افلام اون لاين',xxE5BSyQkNsj+'/films1',436)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'مسلسلات اون لاين',xxE5BSyQkNsj+'/series-all1',436)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'قائمة تفصيلية',xxE5BSyQkNsj,437)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"SiteNavigation"(.*?)"Search"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	vsptNMP2ZQC = XBuP6Op7y4K[0]
	items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?>(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	for BoEFz2WhUyvTgDeiZ,title in items:
		if title in eh2tDvRFWpLQI: continue
		if title=='الرئيسية': continue
		if 'اون لاين' in title: continue
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,431)
	return
def u9ECGV25pJqdslHj34TnML7IWK(website=''):
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',website+'/films','','','','','EGYNOW-MENU-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	xxE5BSyQkNsj = My7Dwqvs6bfGNSIgX.findall('"canonical" href="(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	xxE5BSyQkNsj = xxE5BSyQkNsj[0].strip('/')
	xxE5BSyQkNsj = ooq2D9xF8ZLpPBs(xxE5BSyQkNsj,'url')
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"ListDroped"(.*?)"SearchingMaster"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	vsptNMP2ZQC = XBuP6Op7y4K[0]
	items = My7Dwqvs6bfGNSIgX.findall('data-tax="(.*?)" data-term="(.*?)" data-name="(.*?)"',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	for g4Y0BXLxCpuojKP1SAUtcq7TwN2,WoFrX46wzbCNp18,title in items:
		if title in eh2tDvRFWpLQI: continue
		BoEFz2WhUyvTgDeiZ = website+'/explore/?'+g4Y0BXLxCpuojKP1SAUtcq7TwN2+'='+WoFrX46wzbCNp18
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,431)
	return
def M25iOAH9NfalvyPEUuToG8qn(url):
	xxE5BSyQkNsj = ooq2D9xF8ZLpPBs(url,'url')
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'','','','','EGYNOW-SUBMENU-1st')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'الجميع',url,431)
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"titleSectionCon"(.*?)</div></div>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	vsptNMP2ZQC = XBuP6Op7y4K[0]
	items = My7Dwqvs6bfGNSIgX.findall('data-key="(.*?)".*?<em>(.*?)</em>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	for rwQsc9O3oGdFKbxPlNiM56S2pLUJ0,title in items:
		if title in eh2tDvRFWpLQI: continue
		bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = xxE5BSyQkNsj+'/wp-content/themes/EgyNowByElshaikh/Ajaxt/Movies/Keys.php?key='+rwQsc9O3oGdFKbxPlNiM56S2pLUJ0
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,431)
	return
def sscM839DP1jWZ4zl6uIx0Kyn(url,h5QaxwPF7SOu6fMBTGXRU2yn=''):
	xxE5BSyQkNsj = ooq2D9xF8ZLpPBs(url,'url')
	items = []
	if '/Terms.php' in url or '/Get.php' in url or '/Keys.php' in url:
		bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,toAVQS46Fv8aJYyLf25KnkUNC = NgD0bJaq14yBnMYoziAmLj(url)
		eIL9BxdTbZj = {'X-Requested-With':'XMLHttpRequest','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'POST',bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,toAVQS46Fv8aJYyLf25KnkUNC,eIL9BxdTbZj,'','','EGYNOW-TITLES-1st')
		MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
		vsptNMP2ZQC = MK6ZT2zjC1SbmveNFqor
	elif h5QaxwPF7SOu6fMBTGXRU2yn=='featured':
		xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'','','','','EGYNOW-TITLES-2nd')
		MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"MainSlider"(.*?)"MatchesTable"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('<a href="(.*?)" title="(.*?)".*?image: url\((.*?)\)',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	else:
		xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'','','','','EGYNOW-TITLES-2nd')
		MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"BlocksList"(.*?)"Paginate"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if not XBuP6Op7y4K: XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"BlocksList"(.*?)"titleSectionCon"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		vsptNMP2ZQC = XBuP6Op7y4K[0]
	if not items: items = My7Dwqvs6bfGNSIgX.findall('<a href="(.*?)" title="(.*?)".*?data-image="(.*?)"',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	y7y3d5Fbhv42ONmtwLZ0SerYoQq = []
	tkBQK76YMeUlRI1TomgECfA = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for BoEFz2WhUyvTgDeiZ,title,IcWzVO137wFvemn2QTq8yKs9 in items:
		BoEFz2WhUyvTgDeiZ = XnQbsZF0Ouh8p7zCdUN(BoEFz2WhUyvTgDeiZ).strip('/')
		title = PIfAumbGicwg5ye(title)
		ffhN7jAqe3Q4cR0Ukptzl = My7Dwqvs6bfGNSIgX.findall('(.*?) الحلقة \d+',title,My7Dwqvs6bfGNSIgX.DOTALL)
		if any(WoFrX46wzbCNp18 in title for WoFrX46wzbCNp18 in tkBQK76YMeUlRI1TomgECfA):
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,432,IcWzVO137wFvemn2QTq8yKs9)
		elif ffhN7jAqe3Q4cR0Ukptzl and 'الحلقة' in title:
			title = '_MOD_' + ffhN7jAqe3Q4cR0Ukptzl[0]
			if title not in y7y3d5Fbhv42ONmtwLZ0SerYoQq:
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,433,IcWzVO137wFvemn2QTq8yKs9)
				y7y3d5Fbhv42ONmtwLZ0SerYoQq.append(title)
		elif '/movseries/' in BoEFz2WhUyvTgDeiZ:
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,431,IcWzVO137wFvemn2QTq8yKs9)
		else: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,433,IcWzVO137wFvemn2QTq8yKs9)
	if h5QaxwPF7SOu6fMBTGXRU2yn!='featured':
		XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"Paginate"(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if XBuP6Op7y4K:
			vsptNMP2ZQC = XBuP6Op7y4K[0]
			items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)">(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
			for BoEFz2WhUyvTgDeiZ,title in items:
				if 'http' not in BoEFz2WhUyvTgDeiZ: BoEFz2WhUyvTgDeiZ = xxE5BSyQkNsj+BoEFz2WhUyvTgDeiZ
				BoEFz2WhUyvTgDeiZ = PIfAumbGicwg5ye(BoEFz2WhUyvTgDeiZ)
				title = PIfAumbGicwg5ye(title)
				if title!='': VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'صفحة '+title,BoEFz2WhUyvTgDeiZ,431)
		g7gdVaoK3PHGpJ1YBxvTSUkz = My7Dwqvs6bfGNSIgX.findall('showmore" href="(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if g7gdVaoK3PHGpJ1YBxvTSUkz:
			BoEFz2WhUyvTgDeiZ = g7gdVaoK3PHGpJ1YBxvTSUkz[0]
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'مشاهدة المزيد',BoEFz2WhUyvTgDeiZ,431)
	return
def o4oY13v5dWMcbilEDjKCnXNzHZ0(url):
	xxE5BSyQkNsj = ooq2D9xF8ZLpPBs(url,'url')
	KRI8WExzA4p,kdYXhMN8Hpbt = [],[]
	if 'Episodes.php' in url:
		bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,toAVQS46Fv8aJYyLf25KnkUNC = NgD0bJaq14yBnMYoziAmLj(url)
		eIL9BxdTbZj = {'X-Requested-With':'XMLHttpRequest','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'POST',bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,toAVQS46Fv8aJYyLf25KnkUNC,eIL9BxdTbZj,'','','EGYNOW-EPISODES-1st')
		MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
		kdYXhMN8Hpbt = [MK6ZT2zjC1SbmveNFqor]
	else:
		xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'','','','','EGYNOW-EPISODES-2nd')
		MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
		KRI8WExzA4p = My7Dwqvs6bfGNSIgX.findall('"SeasonsList"(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		kdYXhMN8Hpbt = My7Dwqvs6bfGNSIgX.findall('"EpisodesList"(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if KRI8WExzA4p:
		IcWzVO137wFvemn2QTq8yKs9 = My7Dwqvs6bfGNSIgX.findall('"og:image" content="(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		IcWzVO137wFvemn2QTq8yKs9 = IcWzVO137wFvemn2QTq8yKs9[0]
		vsptNMP2ZQC = KRI8WExzA4p[0]
		items = My7Dwqvs6bfGNSIgX.findall('data-id="(.*?)".*?data-season="(.*?)".*?">(.*?)</a>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for dq7XaIVrRYujxkB0CHKtl,flYPFRArOqHNzt4vmW8T,title in items:
			BoEFz2WhUyvTgDeiZ = xxE5BSyQkNsj+'/wp-content/themes/EgyNowByElshaikh/Ajaxt/Single/Episodes.php?'+'season='+flYPFRArOqHNzt4vmW8T+'&post_id='+dq7XaIVrRYujxkB0CHKtl
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,433,IcWzVO137wFvemn2QTq8yKs9)
	elif kdYXhMN8Hpbt:
		IcWzVO137wFvemn2QTq8yKs9 = tUXmK5PeEH9SDq.getInfoLabel('ListItem.Thumb')
		vsptNMP2ZQC = kdYXhMN8Hpbt[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?</i>(.*?)<em>(.*?)</em>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title,ffhN7jAqe3Q4cR0Ukptzl in items:
			title = title+' '+ffhN7jAqe3Q4cR0Ukptzl
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,432,IcWzVO137wFvemn2QTq8yKs9)
	return
def HDxCnPKFhITpZmOsA4a0UL6(url):
	bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = url+'/watch/'
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,'','','','','EGYNOW-PLAY-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	QQ2cE1FjUyxPonbDhaTkV6B3i = []
	xxE5BSyQkNsj = ooq2D9xF8ZLpPBs(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,'url')
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"container-servers"(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		GuQo8hCDmdBYNZRt5926LFMVwlJnA4 = My7Dwqvs6bfGNSIgX.findall('data-id="(.*?)"',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		if GuQo8hCDmdBYNZRt5926LFMVwlJnA4:
			GuQo8hCDmdBYNZRt5926LFMVwlJnA4 = GuQo8hCDmdBYNZRt5926LFMVwlJnA4[0]
			items = My7Dwqvs6bfGNSIgX.findall('data-server="(.*?)".*?<span>(.*?)</span>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
			for LkVZrOE4XBSN2Qex5PyHqC,title in items:
				BoEFz2WhUyvTgDeiZ = xxE5BSyQkNsj+'/wp-content/themes/EgyNowByElshaikh/Ajaxt/Single/Server.php?server='+LkVZrOE4XBSN2Qex5PyHqC+'&post_id='+GuQo8hCDmdBYNZRt5926LFMVwlJnA4+'?named='+title+'__watch'
				QQ2cE1FjUyxPonbDhaTkV6B3i.append(BoEFz2WhUyvTgDeiZ)
	yGj8rD2ecSkXKPz3gA = My7Dwqvs6bfGNSIgX.findall('"container-iframe"><iframe src="(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if yGj8rD2ecSkXKPz3gA:
		yGj8rD2ecSkXKPz3gA = yGj8rD2ecSkXKPz3gA[0].replace('\n','')
		title = ooq2D9xF8ZLpPBs(yGj8rD2ecSkXKPz3gA,'name')
		BoEFz2WhUyvTgDeiZ = yGj8rD2ecSkXKPz3gA+'?named='+title+'__embed'
		QQ2cE1FjUyxPonbDhaTkV6B3i.append(BoEFz2WhUyvTgDeiZ)
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('"container-download"(.*?)</ul>',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if XBuP6Op7y4K:
		vsptNMP2ZQC = XBuP6Op7y4K[0]
		items = My7Dwqvs6bfGNSIgX.findall('href="(.*?)".*?span>(.*?)<.*?em>(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for BoEFz2WhUyvTgDeiZ,title,LLnUyuiC2wRM0 in items:
			BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ.replace('\n','')
			if LLnUyuiC2wRM0!='': LLnUyuiC2wRM0 = '____'+LLnUyuiC2wRM0
			BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ+'?named='+title+'__download'+LLnUyuiC2wRM0
			QQ2cE1FjUyxPonbDhaTkV6B3i.append(BoEFz2WhUyvTgDeiZ)
	import t1kDWXQVpC
	t1kDWXQVpC.rqVt2xDi7jzJHBcPMRs6h0L(QQ2cE1FjUyxPonbDhaTkV6B3i,baNWS6nfqTC5iX4Kl,'video',url)
	return
def HjZcUIVAXFCqy9TfBWKtgY2(search):
	search,LQf3AeozSrai,showDialogs = X54MLovbG8nAEkB9J(search)
	if search=='': search = ViKAIsLurq83RSENayxWb()
	if search=='': return
	search = search.replace(' ','%20')
	url = EZxQp1WOldMTvFU+'/?s='+search
	sscM839DP1jWZ4zl6uIx0Kyn(url)
	return
def lAjOn69YLFxJNEvTrbfwkiXm2d(url):
	url = url.split('/smartemadfilter?')[0]
	xxE5BSyQkNsj = ooq2D9xF8ZLpPBs(url,'url')
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(IIiPCruL6dT8s1lqj47SzpVHnYNm,'GET',xxE5BSyQkNsj,'','','','','EGYNOW-GET_FILTERS_BLOCKS-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('("dropdown-button".*?)"SearchingMaster"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	vsptNMP2ZQC = XBuP6Op7y4K[0]
	E3ErsLQfR4JXt = My7Dwqvs6bfGNSIgX.findall('"dropdown-button".*?<em>(.*?)</em>(.*?data-tax="(.*?)".*?</div>)',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	return E3ErsLQfR4JXt
def kvYFrVe3g8H7dNhIa(vsptNMP2ZQC):
	items = My7Dwqvs6bfGNSIgX.findall('data-term="(\d+)" data-name="(.*?)"',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	return items
def NewZb13oj4KLaqD0JzGPf6rYQ2ARn(url):
	ulX0L8F7ZqcwGTJRMk = url.split('/smartemadfilter?')[0]
	M0RTIYy1EUX = ooq2D9xF8ZLpPBs(url,'url')
	url = url.replace(ulX0L8F7ZqcwGTJRMk,M0RTIYy1EUX)
	url = url.replace('/smartemadfilter?','/explore/?')
	return url
def QulOad5wbW(DoSfCckGA9BQe,url):
	woj78rBnbLlmZWIy19iPHFCf5 = BrbZhHKJ0jnIe2lumE9M(DoSfCckGA9BQe,'modified_filters')
	QAKdHzO0rehbtyIc = url+'/smartemadfilter?'+woj78rBnbLlmZWIy19iPHFCf5
	QAKdHzO0rehbtyIc = NewZb13oj4KLaqD0JzGPf6rYQ2ARn(QAKdHzO0rehbtyIc)
	return QAKdHzO0rehbtyIc
vIZKhbfsXmWAyUVecrNOz95LQ = ['category','country','genre','release-year']
lWF7u5qUtSak3B = ['quality','release-year','genre','category','language','country']
def LLJlTxDePyjoVKA(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter=='': H2HMwT4JFz7rDkPZmRjcX,JPnr9ICqkDyV = '',''
	else: H2HMwT4JFz7rDkPZmRjcX,JPnr9ICqkDyV = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if vIZKhbfsXmWAyUVecrNOz95LQ[0]+'=' not in H2HMwT4JFz7rDkPZmRjcX: g4Y0BXLxCpuojKP1SAUtcq7TwN2 = vIZKhbfsXmWAyUVecrNOz95LQ[0]
		for FVW0I9sYcAjmDgn8r in range(len(vIZKhbfsXmWAyUVecrNOz95LQ[0:-1])):
			if vIZKhbfsXmWAyUVecrNOz95LQ[FVW0I9sYcAjmDgn8r]+'=' in H2HMwT4JFz7rDkPZmRjcX: g4Y0BXLxCpuojKP1SAUtcq7TwN2 = vIZKhbfsXmWAyUVecrNOz95LQ[FVW0I9sYcAjmDgn8r+1]
		HHXeMqVOshPcW3tULa5v = H2HMwT4JFz7rDkPZmRjcX+'&'+g4Y0BXLxCpuojKP1SAUtcq7TwN2+'=0'
		DoSfCckGA9BQe = JPnr9ICqkDyV+'&'+g4Y0BXLxCpuojKP1SAUtcq7TwN2+'=0'
		A7AEKRlF6Hf3eWVxY0NdwgsMPCc = HHXeMqVOshPcW3tULa5v.strip('&')+'___'+DoSfCckGA9BQe.strip('&')
		woj78rBnbLlmZWIy19iPHFCf5 = BrbZhHKJ0jnIe2lumE9M(JPnr9ICqkDyV,'modified_filters')
		bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = url+'/smartemadfilter?'+woj78rBnbLlmZWIy19iPHFCf5
	elif type=='ALL_ITEMS_FILTER':
		WUSylLup41cYkhVXGtq = BrbZhHKJ0jnIe2lumE9M(H2HMwT4JFz7rDkPZmRjcX,'modified_values')
		WUSylLup41cYkhVXGtq = XnQbsZF0Ouh8p7zCdUN(WUSylLup41cYkhVXGtq)
		if JPnr9ICqkDyV!='': JPnr9ICqkDyV = BrbZhHKJ0jnIe2lumE9M(JPnr9ICqkDyV,'modified_filters')
		if JPnr9ICqkDyV=='': bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = url
		else: bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = url+'/smartemadfilter?'+JPnr9ICqkDyV
		bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = NewZb13oj4KLaqD0JzGPf6rYQ2ARn(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'أظهار قائمة الفيديو التي تم اختيارها ',bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,431)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+' [[   '+WUSylLup41cYkhVXGtq+'   ]]',bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,431)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	E3ErsLQfR4JXt = lAjOn69YLFxJNEvTrbfwkiXm2d(url)
	dict = {}
	for name,vsptNMP2ZQC,RTsbVE9CiQt in E3ErsLQfR4JXt:
		name = name.replace('--','')
		items = kvYFrVe3g8H7dNhIa(vsptNMP2ZQC)
		if '=' not in bJEs4IVAPdyUrhwCLv9k2YoOl8nt1: bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = url
		if type=='SPECIFIED_FILTER':
			if g4Y0BXLxCpuojKP1SAUtcq7TwN2!=RTsbVE9CiQt: continue
			elif len(items)<2:
				if RTsbVE9CiQt==vIZKhbfsXmWAyUVecrNOz95LQ[-1]:
					url = NewZb13oj4KLaqD0JzGPf6rYQ2ARn(url)
					sscM839DP1jWZ4zl6uIx0Kyn(url)
				else: LLJlTxDePyjoVKA(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,'SPECIFIED_FILTER___'+A7AEKRlF6Hf3eWVxY0NdwgsMPCc)
				return
			else:
				bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = NewZb13oj4KLaqD0JzGPf6rYQ2ARn(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1)
				if RTsbVE9CiQt==vIZKhbfsXmWAyUVecrNOz95LQ[-1]: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'الجميع ',bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,431)
				else: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'الجميع ',bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,435,'','',A7AEKRlF6Hf3eWVxY0NdwgsMPCc)
		elif type=='ALL_ITEMS_FILTER':
			HHXeMqVOshPcW3tULa5v = H2HMwT4JFz7rDkPZmRjcX+'&'+RTsbVE9CiQt+'=0'
			DoSfCckGA9BQe = JPnr9ICqkDyV+'&'+RTsbVE9CiQt+'=0'
			A7AEKRlF6Hf3eWVxY0NdwgsMPCc = HHXeMqVOshPcW3tULa5v+'___'+DoSfCckGA9BQe
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'الجميع :'+name,bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,434,'','',A7AEKRlF6Hf3eWVxY0NdwgsMPCc)
		dict[RTsbVE9CiQt] = {}
		for WoFrX46wzbCNp18,A5AMg7LY1HlOz0B82n in items:
			if WoFrX46wzbCNp18=='196533': A5AMg7LY1HlOz0B82n = 'أفلام نيتفلكس'
			elif WoFrX46wzbCNp18=='196531': A5AMg7LY1HlOz0B82n = 'مسلسلات نيتفلكس'
			if A5AMg7LY1HlOz0B82n in eh2tDvRFWpLQI: continue
			dict[RTsbVE9CiQt][WoFrX46wzbCNp18] = A5AMg7LY1HlOz0B82n
			HHXeMqVOshPcW3tULa5v = H2HMwT4JFz7rDkPZmRjcX+'&'+RTsbVE9CiQt+'='+A5AMg7LY1HlOz0B82n
			DoSfCckGA9BQe = JPnr9ICqkDyV+'&'+RTsbVE9CiQt+'='+WoFrX46wzbCNp18
			QQIzTLCXyhtZ7pRNnGq = HHXeMqVOshPcW3tULa5v+'___'+DoSfCckGA9BQe
			title = A5AMg7LY1HlOz0B82n+' :'#+dict[RTsbVE9CiQt]['0']
			title = A5AMg7LY1HlOz0B82n+' :'+name
			if type=='ALL_ITEMS_FILTER': VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,url,434,'','',QQIzTLCXyhtZ7pRNnGq)
			elif type=='SPECIFIED_FILTER' and vIZKhbfsXmWAyUVecrNOz95LQ[-2]+'=' in H2HMwT4JFz7rDkPZmRjcX:
				QAKdHzO0rehbtyIc = QulOad5wbW(DoSfCckGA9BQe,url)
				VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,QAKdHzO0rehbtyIc,431)
			else: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,url,435,'','',QQIzTLCXyhtZ7pRNnGq)
	return
def BrbZhHKJ0jnIe2lumE9M(PPebqkulZUsx3GCLdnYvR,mode):
	PPebqkulZUsx3GCLdnYvR = PPebqkulZUsx3GCLdnYvR.replace('=&','=0&')
	PPebqkulZUsx3GCLdnYvR = PPebqkulZUsx3GCLdnYvR.strip('&')
	mVSjqdOvyf = {}
	if '=' in PPebqkulZUsx3GCLdnYvR:
		items = PPebqkulZUsx3GCLdnYvR.split('&')
		for ZA1fBenNahOR3xrkjvwYSVMy6JK5s in items:
			nmqEj60bcdSQoFPGa,WoFrX46wzbCNp18 = ZA1fBenNahOR3xrkjvwYSVMy6JK5s.split('=')
			mVSjqdOvyf[nmqEj60bcdSQoFPGa] = WoFrX46wzbCNp18
	DidZH6E0pJelcU9xMCBgyL2KvR = ''
	for key in lWF7u5qUtSak3B:
		if key in list(mVSjqdOvyf.keys()): WoFrX46wzbCNp18 = mVSjqdOvyf[key]
		else: WoFrX46wzbCNp18 = '0'
		if '%' not in WoFrX46wzbCNp18: WoFrX46wzbCNp18 = F8fMqZKB4APk(WoFrX46wzbCNp18)
		if mode=='modified_values' and WoFrX46wzbCNp18!='0': DidZH6E0pJelcU9xMCBgyL2KvR = DidZH6E0pJelcU9xMCBgyL2KvR+' + '+WoFrX46wzbCNp18
		elif mode=='modified_filters' and WoFrX46wzbCNp18!='0': DidZH6E0pJelcU9xMCBgyL2KvR = DidZH6E0pJelcU9xMCBgyL2KvR+'&'+key+'='+WoFrX46wzbCNp18
		elif mode=='all_filters': DidZH6E0pJelcU9xMCBgyL2KvR = DidZH6E0pJelcU9xMCBgyL2KvR+'&'+key+'='+WoFrX46wzbCNp18
	DidZH6E0pJelcU9xMCBgyL2KvR = DidZH6E0pJelcU9xMCBgyL2KvR.strip(' + ')
	DidZH6E0pJelcU9xMCBgyL2KvR = DidZH6E0pJelcU9xMCBgyL2KvR.strip('&')
	DidZH6E0pJelcU9xMCBgyL2KvR = DidZH6E0pJelcU9xMCBgyL2KvR.replace('=0','=')
	return DidZH6E0pJelcU9xMCBgyL2KvR
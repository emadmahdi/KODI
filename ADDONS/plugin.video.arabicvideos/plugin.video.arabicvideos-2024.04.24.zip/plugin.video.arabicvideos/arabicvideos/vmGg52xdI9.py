# -*- coding: utf-8 -*-
from G6AHskJeqN import *
baNWS6nfqTC5iX4Kl = 'RANDOMS'
teUPLFC3B8bArakwHVGsdhoIWDM49f = '_LST_'
rQCcZ7utdLnPye8BAEm5 = 4
t9t6J7fWa1Kj3RCydlOcFhnHB = 10
def VbgEajY4Bt2COpGDcPqI(H3HDqY5N4e0fWSXMikZ8CR7suUmJdx,url,Gfsr6KpyVRovQmB8xcXUJ,z3z9QgENFk5eMYB4,yPoqtK3i7zHulhZJDWYsnLxvT0):
	try: S8UKq3VcpRgBMdT1hknl4voHfr = str(yPoqtK3i7zHulhZJDWYsnLxvT0['folder'])
	except: S8UKq3VcpRgBMdT1hknl4voHfr = ''
	if   H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==160: ft3e2JBKQVXWlFPjaMhkEqGxvDg = eN02L7Tf5bQ()
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==161: ft3e2JBKQVXWlFPjaMhkEqGxvDg = GJ34gia6jHLQ57X0N2(Gfsr6KpyVRovQmB8xcXUJ)
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==162: ft3e2JBKQVXWlFPjaMhkEqGxvDg = z2Jvojqg4BTHY3C9ydZsnPw1Ve8pWF(Gfsr6KpyVRovQmB8xcXUJ,162)
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==163: ft3e2JBKQVXWlFPjaMhkEqGxvDg = z2Jvojqg4BTHY3C9ydZsnPw1Ve8pWF(Gfsr6KpyVRovQmB8xcXUJ,163)
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==164: ft3e2JBKQVXWlFPjaMhkEqGxvDg = ffIE4P8WBaQbu2vygZzSJF6rV7(Gfsr6KpyVRovQmB8xcXUJ)
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==165: ft3e2JBKQVXWlFPjaMhkEqGxvDg = UGxZ2JzTPmp3w(url,Gfsr6KpyVRovQmB8xcXUJ)
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==166: ft3e2JBKQVXWlFPjaMhkEqGxvDg = YYQopOAvCRsMfqu01xVHNUnZ(url,Gfsr6KpyVRovQmB8xcXUJ)
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==167: ft3e2JBKQVXWlFPjaMhkEqGxvDg = wnNV7mhJFyu5At81iIbvdx4QT(url,Gfsr6KpyVRovQmB8xcXUJ)
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==168: ft3e2JBKQVXWlFPjaMhkEqGxvDg = s7lC0XnSY3dyx65PDF9g(url,Gfsr6KpyVRovQmB8xcXUJ)
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==761: ft3e2JBKQVXWlFPjaMhkEqGxvDg = qbeTI4KMNJFlLi3Z9BdH1QAx0py()
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==762: ft3e2JBKQVXWlFPjaMhkEqGxvDg = LLKY60pHRhMoAQ9D17TmI3jc()
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==763: ft3e2JBKQVXWlFPjaMhkEqGxvDg = QaN6cUHPMIzbqDlX5LGge(S8UKq3VcpRgBMdT1hknl4voHfr,Gfsr6KpyVRovQmB8xcXUJ,z3z9QgENFk5eMYB4)
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==764: ft3e2JBKQVXWlFPjaMhkEqGxvDg = AdzTBXypPLv6om1kI2NwYWieFR0E(S8UKq3VcpRgBMdT1hknl4voHfr,Gfsr6KpyVRovQmB8xcXUJ)
	elif H3HDqY5N4e0fWSXMikZ8CR7suUmJdx==765: ft3e2JBKQVXWlFPjaMhkEqGxvDg = KjIuirpXDNETqUdeOWaFS(S8UKq3VcpRgBMdT1hknl4voHfr,Gfsr6KpyVRovQmB8xcXUJ)
	else: ft3e2JBKQVXWlFPjaMhkEqGxvDg = False
	return ft3e2JBKQVXWlFPjaMhkEqGxvDg
def eN02L7Tf5bQ():
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','قنوات تلفزيون عشوائية','',161,'','','_LIVETV__RANDOM__REMEMBERRESULTS_')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','قسم عشوائي','',162,'','','_SITES__REMEMBERRESULTS_')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','فيديوهات عشوائية','',163,'','','_SITES__RANDOM__REMEMBERRESULTS_')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','فيديوهات بحث عشوائي','',164,'','','_SITES__RANDOM__REMEMBERRESULTS_')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','فيديوهات عشوائية من قسم','',763,'','','_SITES__RANDOM_')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','قنوات M3U عشوائية','',163,'','','_M3U__LIVE__RANDOM__REMEMBERRESULTS_')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','فيديوهات M3U عشوائية','',163,'','','_M3U__VOD__RANDOM__REMEMBERRESULTS_')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','قسم قنوات M3U عشوائي','',162,'','','_M3U__LIVE__REMEMBERRESULTS_')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','قسم فيديو M3U عشوائي','',162,'','','_M3U__VOD__REMEMBERRESULTS_')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','فيديوهات M3U بحث عشوائي','',164,'','','_M3U__RANDOM__REMEMBERRESULTS_')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','فيديوهات M3U عشوائية من قسم','',765,'','','_M3U__RANDOM__REMEMBERRESULTS_')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','قنوات IPTV عشوائية','',163,'','','_IPTV__LIVE__RANDOM__REMEMBERRESULTS_')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','فيديوهات IPTV عشوائية','',163,'','','_IPTV__VOD__RANDOM__REMEMBERRESULTS_')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','قسم قنوات IPTV عشوائي','',162,'','','_IPTV__LIVE__REMEMBERRESULTS_')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','قسم فيديو IPTV عشوائي','',162,'','','_IPTV__VOD__REMEMBERRESULTS_')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','فيديوهات IPTV بحث عشوائي','',164,'','','_IPTV__RANDOM__REMEMBERRESULTS_')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','فيديوهات IPTV عشوائية من قسم','',764,'','','_IPTV__RANDOM__REMEMBERRESULTS_')
	return
def qbeTI4KMNJFlLi3Z9BdH1QAx0py():
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','_IPT_'+'فيديوهات جميع IPTV','',764)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	for S8UKq3VcpRgBMdT1hknl4voHfr in range(1,HHm4q1SnPBZIf6wcap8zJoeDM7+1):
		teUPLFC3B8bArakwHVGsdhoIWDM49f = '_IP'+str(S8UKq3VcpRgBMdT1hknl4voHfr)+'_'
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+' فيديوهات مجلد '+iUgLYNaTzxo[S8UKq3VcpRgBMdT1hknl4voHfr],'',764,'','','','',{'folder':S8UKq3VcpRgBMdT1hknl4voHfr})
	return
def LLKY60pHRhMoAQ9D17TmI3jc():
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','_M3U_'+'فيديوهات جميع M3U','',765)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	for S8UKq3VcpRgBMdT1hknl4voHfr in range(1,HHm4q1SnPBZIf6wcap8zJoeDM7+1):
		teUPLFC3B8bArakwHVGsdhoIWDM49f = '_MU'+str(S8UKq3VcpRgBMdT1hknl4voHfr)+'_'
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+' فيديوهات مجلد '+iUgLYNaTzxo[S8UKq3VcpRgBMdT1hknl4voHfr],'',765,'','','','',{'folder':S8UKq3VcpRgBMdT1hknl4voHfr})
	return
def QQEjs1wKaNno7mcOYRM3(bo1dqzR8JIwlThvDcyU4jf):
	global oo9NZlBUeLaVh6gv0,OBw8KPbjiVp7LyghCMG1
	JoakAQ4uiT5,dZT40j7heA1zsu3Nak,rrFcwfjUW34gaDKp2mHNB58Azbs = RB0138fEQHwDFGn(bo1dqzR8JIwlThvDcyU4jf)
	try:
		if 'IFILM' in bo1dqzR8JIwlThvDcyU4jf: JoakAQ4uiT5(bo1dqzR8JIwlThvDcyU4jf)
		else: JoakAQ4uiT5()
		WWVRXl4xOdLFC3rIaYz9HpfESt1jK = False
	except:
		IhzTf3wxBDQcmHRgrjN7qEi8kn()
		WWVRXl4xOdLFC3rIaYz9HpfESt1jK = True
	bo1dqzR8JIwlThvDcyU4jf = nnYoO8rQaHmc57IA1MVSi(bo1dqzR8JIwlThvDcyU4jf)
	if WWVRXl4xOdLFC3rIaYz9HpfESt1jK:
		gj7BGM5t3RZpA0vNixLqzwualb16(bo1dqzR8JIwlThvDcyU4jf,'فشل للأسف',KBxPW9cX8dqtaUDG=2000)
		oo9NZlBUeLaVh6gv0 += 1
		OBw8KPbjiVp7LyghCMG1 += ' '+bo1dqzR8JIwlThvDcyU4jf
	else: gj7BGM5t3RZpA0vNixLqzwualb16(bo1dqzR8JIwlThvDcyU4jf,'',KBxPW9cX8dqtaUDG=1000)
	return
def LL4bBCfItMrPSzwHk6Do7Yl3vVg(r1NiHocRsy=True):
	global oo9NZlBUeLaVh6gv0,OBw8KPbjiVp7LyghCMG1
	if not r1NiHocRsy:
		global aaN3V2d6LKgSXOotH5n
		ft3e2JBKQVXWlFPjaMhkEqGxvDg = zPgNsqpJInt(RnqtMUa9Nh6peGEsBT,'dict','SECTIONS_SITES','SECTIONS_SITES_ALL')
		if ft3e2JBKQVXWlFPjaMhkEqGxvDg:
			aaN3V2d6LKgSXOotH5n = ft3e2JBKQVXWlFPjaMhkEqGxvDg
			return
	tLwvQlnjGpWsRVCN1 = mmwySO1P4jnKz5('center','','','رسالة من المبرمج','لكي تملئ هذه القائمة . البرنامج يحتاج أن يفحص جميع مواقع الفيديو التي في البرنامج لكي يستخرج منها فقط الأقسام الرئيسية . ثم يقوم البرنامج بخزن هذه الأقسام حتى لا تحتاج أن تملئها مرة أخرى . عملية ملئ جميع الأقسام تحتاج عادة أقل من 3 دقائق . هل تريد أن تجمع قائمة الأقسام الآن ؟')
	if tLwvQlnjGpWsRVCN1!=1: return
	YRi6vEsJ05kd8Bo9UtbpzlVn2(False,False,False)
	XzUQ0xJfhrI5clBZWe9OAt = xx4viQhaOu6r0
	oo9NZlBUeLaVh6gv0,OBw8KPbjiVp7LyghCMG1,threads = 0,'',{}
	for bo1dqzR8JIwlThvDcyU4jf in czHrbt5S1yNPB:
		KBxPW9cX8dqtaUDG.sleep(0.75)
		threads[bo1dqzR8JIwlThvDcyU4jf] = iDocG6BXv7fT2z8UVOxgP.Thread(target=QQEjs1wKaNno7mcOYRM3,args=(bo1dqzR8JIwlThvDcyU4jf,))
		threads[bo1dqzR8JIwlThvDcyU4jf].start()
		if oo9NZlBUeLaVh6gv0>=t9t6J7fWa1Kj3RCydlOcFhnHB: break
	else:
		for bo1dqzR8JIwlThvDcyU4jf in list(threads.keys()):
			threads[bo1dqzR8JIwlThvDcyU4jf].join()
	xx4viQhaOu6r0[:] = XzUQ0xJfhrI5clBZWe9OAt
	if oo9NZlBUeLaVh6gv0>=t9t6J7fWa1Kj3RCydlOcFhnHB: ZIOHgA3z0TBR('','','رسالة من المبرمج','لديك مشكلة في '+str(oo9NZlBUeLaVh6gv0)+' مواقع من مواقع البرنامج ... وسببها قد يكون عدم وجود إنترنيت في جهازك وهي:'+OBw8KPbjiVp7LyghCMG1)
	else:
		VZ8BTik93OqXLCh0fD7d2KUPpn4mH6(RnqtMUa9Nh6peGEsBT,'SECTIONS_SITES','SECTIONS_SITES_ALL',aaN3V2d6LKgSXOotH5n,BZdvf7MIUxHQc3aCT)
		ZIOHgA3z0TBR('','','رسالة من المبرمج','تم جلب جميع الأقسام المتوفرة في البرنامج')
	YRi6vEsJ05kd8Bo9UtbpzlVn2('','','')
	return
def ZXLkyubtMvUhnEpw085j(S8UKq3VcpRgBMdT1hknl4voHfr,khALrUNtziB3gX):
	IlpZ3itqN15kDozB6QA4JTE = False
	v1v4cjwhtfsi7OE9F6XxeNqz = xx4viQhaOu6r0
	xx4viQhaOu6r0[:] = []
	if IlpZ3itqN15kDozB6QA4JTE and '_CREATENEW_' not in khALrUNtziB3gX:
		ft3e2JBKQVXWlFPjaMhkEqGxvDg = zPgNsqpJInt(RnqtMUa9Nh6peGEsBT,'list','SECTIONS_IPTV','SECTIONS_IPTV_'+S8UKq3VcpRgBMdT1hknl4voHfr)
	elif '_LIVE_' not in khALrUNtziB3gX or '_VOD_' not in khALrUNtziB3gX:
		import OJR51gj7FS
		mR4VLhryYT2koGU6iBX = 'للأسف لديك مشكلة في هذا الموقع . ورسالة الخطأ كان فيها تفاصيل المشكلة . أذا المشكلة ليست حجب فجرب إرسال هذه المشكلة إلى المبرمج من قائمة خدمات البرنامج'
		if '_LIVE_' not in khALrUNtziB3gX:
			try: OJR51gj7FS.um1OcGXaBWrP(S8UKq3VcpRgBMdT1hknl4voHfr,'VOD_UNKNOWN_GROUPED_SORTED','','',khALrUNtziB3gX+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: ZIOHgA3z0TBR('','','موقع ـIPTV للفيديوهات',mR4VLhryYT2koGU6iBX)
			try: OJR51gj7FS.um1OcGXaBWrP(S8UKq3VcpRgBMdT1hknl4voHfr,'VOD_MOVIES_GROUPED_SORTED','','',khALrUNtziB3gX+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: ZIOHgA3z0TBR('','','موقع ـIPTV للفيديوهات',mR4VLhryYT2koGU6iBX)
			try: OJR51gj7FS.um1OcGXaBWrP(S8UKq3VcpRgBMdT1hknl4voHfr,'VOD_SERIES_GROUPED_SORTED','','',khALrUNtziB3gX+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: ZIOHgA3z0TBR('','','موقع ـIPTV للفيديوهات',mR4VLhryYT2koGU6iBX)
		if '_VOD_' not in khALrUNtziB3gX:
			try: OJR51gj7FS.um1OcGXaBWrP(S8UKq3VcpRgBMdT1hknl4voHfr,'LIVE_UNKNOWN_GROUPED_SORTED','','',khALrUNtziB3gX+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: ZIOHgA3z0TBR('','','موقع ـIPTV للقنوات',mR4VLhryYT2koGU6iBX)
			try: OJR51gj7FS.um1OcGXaBWrP(S8UKq3VcpRgBMdT1hknl4voHfr,'LIVE_GROUPED_SORTED','','',khALrUNtziB3gX+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: ZIOHgA3z0TBR('','','موقع ـIPTV للقنوات',mR4VLhryYT2koGU6iBX)
		ft3e2JBKQVXWlFPjaMhkEqGxvDg = xx4viQhaOu6r0
		if IlpZ3itqN15kDozB6QA4JTE: VZ8BTik93OqXLCh0fD7d2KUPpn4mH6(RnqtMUa9Nh6peGEsBT,'SECTIONS_IPTV','SECTIONS_IPTV_'+S8UKq3VcpRgBMdT1hknl4voHfr,ft3e2JBKQVXWlFPjaMhkEqGxvDg,BZdvf7MIUxHQc3aCT)
	xx4viQhaOu6r0[:] = v1v4cjwhtfsi7OE9F6XxeNqz
	return ft3e2JBKQVXWlFPjaMhkEqGxvDg
def ay4n5mIN9zu(S8UKq3VcpRgBMdT1hknl4voHfr,khALrUNtziB3gX):
	IlpZ3itqN15kDozB6QA4JTE = False
	v1v4cjwhtfsi7OE9F6XxeNqz = xx4viQhaOu6r0
	xx4viQhaOu6r0[:] = []
	if IlpZ3itqN15kDozB6QA4JTE and '_CREATENEW_' not in khALrUNtziB3gX:
		ft3e2JBKQVXWlFPjaMhkEqGxvDg = zPgNsqpJInt(RnqtMUa9Nh6peGEsBT,'list','SECTIONS_M3U','SECTIONS_M3U_'+S8UKq3VcpRgBMdT1hknl4voHfr)
	elif '_LIVE_' not in khALrUNtziB3gX or '_VOD_' not in khALrUNtziB3gX:
		import F9HnjCOwhi
		mR4VLhryYT2koGU6iBX = 'للأسف لديك مشكلة في هذا الموقع . ورسالة الخطأ كان فيها تفاصيل المشكلة . أذا المشكلة ليست حجب فجرب إرسال هذه المشكلة إلى المبرمج من قائمة خدمات البرنامج'
		if '_LIVE_' not in khALrUNtziB3gX:
			try: F9HnjCOwhi.um1OcGXaBWrP(S8UKq3VcpRgBMdT1hknl4voHfr,'VOD_UNKNOWN_GROUPED_SORTED','','',khALrUNtziB3gX+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: ZIOHgA3z0TBR('','','موقع ـM3U للفيديوهات',mR4VLhryYT2koGU6iBX)
			try: F9HnjCOwhi.um1OcGXaBWrP(S8UKq3VcpRgBMdT1hknl4voHfr,'VOD_MOVIES_GROUPED_SORTED','','',khALrUNtziB3gX+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: ZIOHgA3z0TBR('','','موقع ـM3U للفيديوهات',mR4VLhryYT2koGU6iBX)
			try: F9HnjCOwhi.um1OcGXaBWrP(S8UKq3VcpRgBMdT1hknl4voHfr,'VOD_SERIES_GROUPED_SORTED','','',khALrUNtziB3gX+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: ZIOHgA3z0TBR('','','موقع ـM3U للفيديوهات',mR4VLhryYT2koGU6iBX)
		if '_VOD_' not in khALrUNtziB3gX:
			try: F9HnjCOwhi.um1OcGXaBWrP(S8UKq3VcpRgBMdT1hknl4voHfr,'LIVE_UNKNOWN_GROUPED_SORTED','','',khALrUNtziB3gX+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: ZIOHgA3z0TBR('','','موقع ـM3U للقنوات',mR4VLhryYT2koGU6iBX)
			try: F9HnjCOwhi.um1OcGXaBWrP(S8UKq3VcpRgBMdT1hknl4voHfr,'LIVE_GROUPED_SORTED','','',khALrUNtziB3gX+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: ZIOHgA3z0TBR('','','موقع ـM3U للقنوات',mR4VLhryYT2koGU6iBX)
		ft3e2JBKQVXWlFPjaMhkEqGxvDg = xx4viQhaOu6r0
		if IlpZ3itqN15kDozB6QA4JTE: VZ8BTik93OqXLCh0fD7d2KUPpn4mH6(RnqtMUa9Nh6peGEsBT,'SECTIONS_M3U','SECTIONS_M3U_'+S8UKq3VcpRgBMdT1hknl4voHfr,ft3e2JBKQVXWlFPjaMhkEqGxvDg,BZdvf7MIUxHQc3aCT)
	xx4viQhaOu6r0[:] = v1v4cjwhtfsi7OE9F6XxeNqz
	return ft3e2JBKQVXWlFPjaMhkEqGxvDg
def QaN6cUHPMIzbqDlX5LGge(S8UKq3VcpRgBMdT1hknl4voHfr,khALrUNtziB3gX,rJ9zBOiMC6):
	if '_CREATENEW_' in khALrUNtziB3gX and rJ9zBOiMC6=='': LL4bBCfItMrPSzwHk6Do7Yl3vVg(True)
	elif rJ9zBOiMC6: LL4bBCfItMrPSzwHk6Do7Yl3vVg(False)
	W7fkzNwZAKR4rOtjd05 = khALrUNtziB3gX.replace('_CREATENEW_','').replace('_FORGETRESULTS_','').replace('_REMEMBERRESULTS_','')
	if not rJ9zBOiMC6:
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','تحديث هذه القائمة','',763,'','','_CREATENEW_'+W7fkzNwZAKR4rOtjd05,'',{'folder':S8UKq3VcpRgBMdT1hknl4voHfr})
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	kkAK8c2b6l = ['أفلام','مسلسلات','مسرحيات','برامج','أطفال وكرتون','رمضان','أحدث-أخر','سلاسل','موسيقى','أشهر-أكثر','الآن','ضحك','رياضة','نيتفلكس','ممثلين','بث حي','دينية','سنوات','أخرى']
	ptTA93uav5K6cL2HVF = ['افلام','movie','فيلم','فلم']
	kD16ElgoBYtJVFAUI = ['مسلسل','series']
	FV3pQdNSDJIHjG2qOnKezfAXh = ['مسارح','مسرحيات']
	C9vlpXxEq0IQ52SRV1nbwZyHaUO = ['برامج','show','تلفزيون','تليفزيون']
	VDFXYH15ge = ['انمي','كرتون','كارتون','kids','طفل','اطفال']
	mosdODYVzftbkKHBS9rv0y = ['رمضان']
	jteCU2z0EY4J6dFA = ['احدث','اخر','موخر','جديد','مضاف','حديث']
	WsJINe5CzH4qUD19yTm = ['سلاسل','سلسله']
	DvVs46E8IltR2gWF1hodAZ = ['اغاني','موسيقى','كليب','حفل','music']
	nYLsPCXv0cIUh9NeQSbk = ['اكثر','اشهر','مميزه','اعلى','مختاره','مختارات','اقوى']
	EE2GAgXBNi7bDO = ['الان','حالي','مثبت','رائج']
	hpqwvzSFe4t = ['ضحك','كوميدي']
	m0SrbT7ZFoplYugGjBwRV = ['رياضه','كوره','مصارعه','شوت','رياضة']
	C94MuFQWcNwVJ = ['نيتفلكس','netflix','نيتفليكس']
	EyGQOoM2R8irVc = ['ممثلين','اشخاص','نجوم']
	KK8gr6Iv04mjZXF = ['بث حي','live','قناه','قنوات']
	PsgGxZvyXijlYCmzrcSahw7Oe4Qt = ['دين','ادعيه','زيارات','لطميات','دعاء','قران','قصائد','رثاء','مرجعيه','اذان','اسلام','تواشيح','خطب','حوزوي','عتبات','مواليد','نواعي','عقائد','اناشيد']
	bQ4lfYR1g7IWatzpvP8MudxBEqZ = ['19','20','21','22','23','24','25','26']
	if not rJ9zBOiMC6:
		rJ9zBOiMC6 = 0
		for dkuVf3OIKrgp5oM8P in kkAK8c2b6l:
			rJ9zBOiMC6 += 1
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+dkuVf3OIKrgp5oM8P,'',763,'',str(rJ9zBOiMC6),W7fkzNwZAKR4rOtjd05,'',{'folder':S8UKq3VcpRgBMdT1hknl4voHfr})
	else:
		for bSxczpUtHewVDKa3EL4lm in sorted(list(aaN3V2d6LKgSXOotH5n.keys())):
			bdHQJiTCSFGgoXL3v2rMNAEn6y = bSxczpUtHewVDKa3EL4lm.lower()
			g4Y0BXLxCpuojKP1SAUtcq7TwN2 = []
			if any(WoFrX46wzbCNp18 in bdHQJiTCSFGgoXL3v2rMNAEn6y for WoFrX46wzbCNp18 in ptTA93uav5K6cL2HVF): g4Y0BXLxCpuojKP1SAUtcq7TwN2.append(1)
			if any(WoFrX46wzbCNp18 in bdHQJiTCSFGgoXL3v2rMNAEn6y for WoFrX46wzbCNp18 in kD16ElgoBYtJVFAUI): g4Y0BXLxCpuojKP1SAUtcq7TwN2.append(2)
			if any(WoFrX46wzbCNp18 in bdHQJiTCSFGgoXL3v2rMNAEn6y for WoFrX46wzbCNp18 in FV3pQdNSDJIHjG2qOnKezfAXh): g4Y0BXLxCpuojKP1SAUtcq7TwN2.append(3)
			if any(WoFrX46wzbCNp18 in bdHQJiTCSFGgoXL3v2rMNAEn6y for WoFrX46wzbCNp18 in C9vlpXxEq0IQ52SRV1nbwZyHaUO): g4Y0BXLxCpuojKP1SAUtcq7TwN2.append(4)
			if any(WoFrX46wzbCNp18 in bdHQJiTCSFGgoXL3v2rMNAEn6y for WoFrX46wzbCNp18 in VDFXYH15ge): g4Y0BXLxCpuojKP1SAUtcq7TwN2.append(5)
			if any(WoFrX46wzbCNp18 in bdHQJiTCSFGgoXL3v2rMNAEn6y for WoFrX46wzbCNp18 in mosdODYVzftbkKHBS9rv0y): g4Y0BXLxCpuojKP1SAUtcq7TwN2.append(6)
			if any(WoFrX46wzbCNp18 in bdHQJiTCSFGgoXL3v2rMNAEn6y for WoFrX46wzbCNp18 in jteCU2z0EY4J6dFA) and bdHQJiTCSFGgoXL3v2rMNAEn6y not in ['اخرى']: g4Y0BXLxCpuojKP1SAUtcq7TwN2.append(7)
			if any(WoFrX46wzbCNp18 in bdHQJiTCSFGgoXL3v2rMNAEn6y for WoFrX46wzbCNp18 in WsJINe5CzH4qUD19yTm): g4Y0BXLxCpuojKP1SAUtcq7TwN2.append(8)
			if any(WoFrX46wzbCNp18 in bdHQJiTCSFGgoXL3v2rMNAEn6y for WoFrX46wzbCNp18 in DvVs46E8IltR2gWF1hodAZ): g4Y0BXLxCpuojKP1SAUtcq7TwN2.append(9)
			if any(WoFrX46wzbCNp18 in bdHQJiTCSFGgoXL3v2rMNAEn6y for WoFrX46wzbCNp18 in nYLsPCXv0cIUh9NeQSbk): g4Y0BXLxCpuojKP1SAUtcq7TwN2.append(10)
			if any(WoFrX46wzbCNp18 in bdHQJiTCSFGgoXL3v2rMNAEn6y for WoFrX46wzbCNp18 in EE2GAgXBNi7bDO): g4Y0BXLxCpuojKP1SAUtcq7TwN2.append(11)
			if any(WoFrX46wzbCNp18 in bdHQJiTCSFGgoXL3v2rMNAEn6y for WoFrX46wzbCNp18 in hpqwvzSFe4t): g4Y0BXLxCpuojKP1SAUtcq7TwN2.append(12)
			if any(WoFrX46wzbCNp18 in bdHQJiTCSFGgoXL3v2rMNAEn6y for WoFrX46wzbCNp18 in m0SrbT7ZFoplYugGjBwRV): g4Y0BXLxCpuojKP1SAUtcq7TwN2.append(13)
			if any(WoFrX46wzbCNp18 in bdHQJiTCSFGgoXL3v2rMNAEn6y for WoFrX46wzbCNp18 in C94MuFQWcNwVJ): g4Y0BXLxCpuojKP1SAUtcq7TwN2.append(14)
			if any(WoFrX46wzbCNp18 in bdHQJiTCSFGgoXL3v2rMNAEn6y for WoFrX46wzbCNp18 in EyGQOoM2R8irVc): g4Y0BXLxCpuojKP1SAUtcq7TwN2.append(15)
			if any(WoFrX46wzbCNp18 in bdHQJiTCSFGgoXL3v2rMNAEn6y for WoFrX46wzbCNp18 in KK8gr6Iv04mjZXF): g4Y0BXLxCpuojKP1SAUtcq7TwN2.append(16)
			if any(WoFrX46wzbCNp18 in bdHQJiTCSFGgoXL3v2rMNAEn6y for WoFrX46wzbCNp18 in PsgGxZvyXijlYCmzrcSahw7Oe4Qt): g4Y0BXLxCpuojKP1SAUtcq7TwN2.append(17)
			if any(WoFrX46wzbCNp18 in bdHQJiTCSFGgoXL3v2rMNAEn6y for WoFrX46wzbCNp18 in bQ4lfYR1g7IWatzpvP8MudxBEqZ): g4Y0BXLxCpuojKP1SAUtcq7TwN2.append(18)
			if not g4Y0BXLxCpuojKP1SAUtcq7TwN2: g4Y0BXLxCpuojKP1SAUtcq7TwN2 = [19]
			for f8HmhaGZJX in g4Y0BXLxCpuojKP1SAUtcq7TwN2:
				if str(f8HmhaGZJX)==rJ9zBOiMC6:
					VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+bSxczpUtHewVDKa3EL4lm,bSxczpUtHewVDKa3EL4lm,166,'','',W7fkzNwZAKR4rOtjd05+'_REMEMBERRESULTS_')
	return
def AdzTBXypPLv6om1kI2NwYWieFR0E(S8UKq3VcpRgBMdT1hknl4voHfr,khALrUNtziB3gX):
	IlpZ3itqN15kDozB6QA4JTE = False
	if IlpZ3itqN15kDozB6QA4JTE:
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','تحديث هذه القائمة','',764,'','','_CREATENEW_','',{'folder':S8UKq3VcpRgBMdT1hknl4voHfr})
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	v1v4cjwhtfsi7OE9F6XxeNqz = xx4viQhaOu6r0[:]
	import OJR51gj7FS
	if S8UKq3VcpRgBMdT1hknl4voHfr:
		if not OJR51gj7FS.p13ciNHPqwljuY5KQIWfD6EOm(S8UKq3VcpRgBMdT1hknl4voHfr,True): return
		s2jOC1kwPafWtQ9MYbTSVhJgLmd = ZXLkyubtMvUhnEpw085j(S8UKq3VcpRgBMdT1hknl4voHfr,khALrUNtziB3gX)
		lsSvZMNpBrH78OtKiEezXgbUY = sorted(s2jOC1kwPafWtQ9MYbTSVhJgLmd,reverse=False,key=lambda key: key[1].lower())
	else:
		if not OJR51gj7FS.p13ciNHPqwljuY5KQIWfD6EOm('',True): return
		if IlpZ3itqN15kDozB6QA4JTE and '_CREATENEW_' not in khALrUNtziB3gX:
			lsSvZMNpBrH78OtKiEezXgbUY = zPgNsqpJInt(RnqtMUa9Nh6peGEsBT,'list','SECTIONS_IPTV','SECTIONS_IPTV_ALL')
		else:
			bWwqSoR6UOJB,lsSvZMNpBrH78OtKiEezXgbUY,s2jOC1kwPafWtQ9MYbTSVhJgLmd = [],[],[]
			for NQpFI3G2jS6w0dBEPHtOKy9VUx in range(1,HHm4q1SnPBZIf6wcap8zJoeDM7+1):
				lsSvZMNpBrH78OtKiEezXgbUY += ZXLkyubtMvUhnEpw085j(str(NQpFI3G2jS6w0dBEPHtOKy9VUx),khALrUNtziB3gX)
			for type,bSxczpUtHewVDKa3EL4lm,url,H3HDqY5N4e0fWSXMikZ8CR7suUmJdx,QFrVYJkywEsXquMNz,z3z9QgENFk5eMYB4,Gfsr6KpyVRovQmB8xcXUJ,ezSE9fBuvT,yPoqtK3i7zHulhZJDWYsnLxvT0 in lsSvZMNpBrH78OtKiEezXgbUY:
				if Gfsr6KpyVRovQmB8xcXUJ not in bWwqSoR6UOJB:
					bWwqSoR6UOJB.append(Gfsr6KpyVRovQmB8xcXUJ)
					p7dMFEPY0ANmcQSvgz = type,bSxczpUtHewVDKa3EL4lm,Gfsr6KpyVRovQmB8xcXUJ,165,QFrVYJkywEsXquMNz,z3z9QgENFk5eMYB4,khALrUNtziB3gX,ezSE9fBuvT,yPoqtK3i7zHulhZJDWYsnLxvT0
					s2jOC1kwPafWtQ9MYbTSVhJgLmd.append(p7dMFEPY0ANmcQSvgz)
			lsSvZMNpBrH78OtKiEezXgbUY = sorted(s2jOC1kwPafWtQ9MYbTSVhJgLmd,reverse=False,key=lambda key: key[1].lower())
			if IlpZ3itqN15kDozB6QA4JTE: VZ8BTik93OqXLCh0fD7d2KUPpn4mH6(RnqtMUa9Nh6peGEsBT,'SECTIONS_IPTV','SECTIONS_IPTV_ALL',lsSvZMNpBrH78OtKiEezXgbUY,BZdvf7MIUxHQc3aCT)
	xx4viQhaOu6r0[:] = v1v4cjwhtfsi7OE9F6XxeNqz+lsSvZMNpBrH78OtKiEezXgbUY
	tUXmK5PeEH9SDq.executebuiltin('Container.Refresh')
	return
def KjIuirpXDNETqUdeOWaFS(S8UKq3VcpRgBMdT1hknl4voHfr,khALrUNtziB3gX):
	IlpZ3itqN15kDozB6QA4JTE = False
	if IlpZ3itqN15kDozB6QA4JTE:
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','تحديث هذه القائمة','',765,'','','_CREATENEW_','',{'folder':S8UKq3VcpRgBMdT1hknl4voHfr})
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	v1v4cjwhtfsi7OE9F6XxeNqz = xx4viQhaOu6r0[:]
	import F9HnjCOwhi
	if S8UKq3VcpRgBMdT1hknl4voHfr:
		if not F9HnjCOwhi.p13ciNHPqwljuY5KQIWfD6EOm(S8UKq3VcpRgBMdT1hknl4voHfr,True): return
		s2jOC1kwPafWtQ9MYbTSVhJgLmd = ay4n5mIN9zu(S8UKq3VcpRgBMdT1hknl4voHfr,khALrUNtziB3gX)
		lsSvZMNpBrH78OtKiEezXgbUY = sorted(s2jOC1kwPafWtQ9MYbTSVhJgLmd,reverse=False,key=lambda key: key[1].lower())
	else:
		if not F9HnjCOwhi.p13ciNHPqwljuY5KQIWfD6EOm('',True): return
		if IlpZ3itqN15kDozB6QA4JTE and '_CREATENEW_' not in khALrUNtziB3gX:
			lsSvZMNpBrH78OtKiEezXgbUY = zPgNsqpJInt(RnqtMUa9Nh6peGEsBT,'list','SECTIONS_M3U','SECTIONS_M3U_ALL')
		else:
			bWwqSoR6UOJB,lsSvZMNpBrH78OtKiEezXgbUY,s2jOC1kwPafWtQ9MYbTSVhJgLmd = [],[],[]
			for NQpFI3G2jS6w0dBEPHtOKy9VUx in range(1,HHm4q1SnPBZIf6wcap8zJoeDM7+1):
				lsSvZMNpBrH78OtKiEezXgbUY += ay4n5mIN9zu(str(NQpFI3G2jS6w0dBEPHtOKy9VUx),khALrUNtziB3gX)
			for type,bSxczpUtHewVDKa3EL4lm,url,H3HDqY5N4e0fWSXMikZ8CR7suUmJdx,QFrVYJkywEsXquMNz,z3z9QgENFk5eMYB4,Gfsr6KpyVRovQmB8xcXUJ,ezSE9fBuvT,yPoqtK3i7zHulhZJDWYsnLxvT0 in lsSvZMNpBrH78OtKiEezXgbUY:
				if Gfsr6KpyVRovQmB8xcXUJ not in bWwqSoR6UOJB:
					bWwqSoR6UOJB.append(Gfsr6KpyVRovQmB8xcXUJ)
					p7dMFEPY0ANmcQSvgz = type,bSxczpUtHewVDKa3EL4lm,Gfsr6KpyVRovQmB8xcXUJ,165,QFrVYJkywEsXquMNz,z3z9QgENFk5eMYB4,khALrUNtziB3gX,ezSE9fBuvT,yPoqtK3i7zHulhZJDWYsnLxvT0
					s2jOC1kwPafWtQ9MYbTSVhJgLmd.append(p7dMFEPY0ANmcQSvgz)
			lsSvZMNpBrH78OtKiEezXgbUY = sorted(s2jOC1kwPafWtQ9MYbTSVhJgLmd,reverse=False,key=lambda key: key[1].lower())
			if IlpZ3itqN15kDozB6QA4JTE: VZ8BTik93OqXLCh0fD7d2KUPpn4mH6(RnqtMUa9Nh6peGEsBT,'SECTIONS_M3U','SECTIONS_M3U_ALL',lsSvZMNpBrH78OtKiEezXgbUY,BZdvf7MIUxHQc3aCT)
	xx4viQhaOu6r0[:] = v1v4cjwhtfsi7OE9F6XxeNqz+lsSvZMNpBrH78OtKiEezXgbUY
	tUXmK5PeEH9SDq.executebuiltin('Container.Refresh')
	return
def UGxZ2JzTPmp3w(group,khALrUNtziB3gX):
	IlpZ3itqN15kDozB6QA4JTE = False
	ft3e2JBKQVXWlFPjaMhkEqGxvDg = []
	D7uW1QmTbnY3BROdiNUFvKyJ0lZc8 = '_IPTV_' if 'IPTV' in khALrUNtziB3gX else '_M3U_'
	if IlpZ3itqN15kDozB6QA4JTE: ft3e2JBKQVXWlFPjaMhkEqGxvDg = zPgNsqpJInt(RnqtMUa9Nh6peGEsBT,'list','SECTIONS'+D7uW1QmTbnY3BROdiNUFvKyJ0lZc8[:-1],group)
	if not ft3e2JBKQVXWlFPjaMhkEqGxvDg:
		for S8UKq3VcpRgBMdT1hknl4voHfr in range(1,HHm4q1SnPBZIf6wcap8zJoeDM7+1):
			if IlpZ3itqN15kDozB6QA4JTE: ft3e2JBKQVXWlFPjaMhkEqGxvDg += zPgNsqpJInt(RnqtMUa9Nh6peGEsBT,'list','SECTIONS'+D7uW1QmTbnY3BROdiNUFvKyJ0lZc8[:-1],'SECTIONS'+D7uW1QmTbnY3BROdiNUFvKyJ0lZc8+str(S8UKq3VcpRgBMdT1hknl4voHfr))
			elif D7uW1QmTbnY3BROdiNUFvKyJ0lZc8=='_IPTV_': ft3e2JBKQVXWlFPjaMhkEqGxvDg += ZXLkyubtMvUhnEpw085j(str(S8UKq3VcpRgBMdT1hknl4voHfr),'_CREATENEW_')
			elif D7uW1QmTbnY3BROdiNUFvKyJ0lZc8=='_M3U_': ft3e2JBKQVXWlFPjaMhkEqGxvDg += ay4n5mIN9zu(str(S8UKq3VcpRgBMdT1hknl4voHfr),'_CREATENEW_')
		for type,bSxczpUtHewVDKa3EL4lm,url,H3HDqY5N4e0fWSXMikZ8CR7suUmJdx,QFrVYJkywEsXquMNz,z3z9QgENFk5eMYB4,Gfsr6KpyVRovQmB8xcXUJ,ezSE9fBuvT,yPoqtK3i7zHulhZJDWYsnLxvT0 in ft3e2JBKQVXWlFPjaMhkEqGxvDg:
			if Gfsr6KpyVRovQmB8xcXUJ==group: uu970x1YwvLq6crQhsHeOj(type,bSxczpUtHewVDKa3EL4lm,url,H3HDqY5N4e0fWSXMikZ8CR7suUmJdx,QFrVYJkywEsXquMNz,z3z9QgENFk5eMYB4,Gfsr6KpyVRovQmB8xcXUJ,ezSE9fBuvT,yPoqtK3i7zHulhZJDWYsnLxvT0)
		items,zE1FBZLDvygwGdkef74lnRJVXCUqKH = [],[]
		for type,bSxczpUtHewVDKa3EL4lm,url,H3HDqY5N4e0fWSXMikZ8CR7suUmJdx,QFrVYJkywEsXquMNz,z3z9QgENFk5eMYB4,Gfsr6KpyVRovQmB8xcXUJ,ezSE9fBuvT,yPoqtK3i7zHulhZJDWYsnLxvT0 in xx4viQhaOu6r0:
			uUWolxErnhD7zF1I5KB28gis = type,bSxczpUtHewVDKa3EL4lm[4:],url,H3HDqY5N4e0fWSXMikZ8CR7suUmJdx,QFrVYJkywEsXquMNz,z3z9QgENFk5eMYB4,Gfsr6KpyVRovQmB8xcXUJ,ezSE9fBuvT,''
			if uUWolxErnhD7zF1I5KB28gis not in zE1FBZLDvygwGdkef74lnRJVXCUqKH:
				zE1FBZLDvygwGdkef74lnRJVXCUqKH.append(uUWolxErnhD7zF1I5KB28gis)
				ZA1fBenNahOR3xrkjvwYSVMy6JK5s = type,bSxczpUtHewVDKa3EL4lm,url,H3HDqY5N4e0fWSXMikZ8CR7suUmJdx,QFrVYJkywEsXquMNz,z3z9QgENFk5eMYB4,Gfsr6KpyVRovQmB8xcXUJ,ezSE9fBuvT,yPoqtK3i7zHulhZJDWYsnLxvT0
				items.append(ZA1fBenNahOR3xrkjvwYSVMy6JK5s)
		ft3e2JBKQVXWlFPjaMhkEqGxvDg = sorted(items,reverse=False,key=lambda key: key[1].lower()[5:])
		if IlpZ3itqN15kDozB6QA4JTE: VZ8BTik93OqXLCh0fD7d2KUPpn4mH6(RnqtMUa9Nh6peGEsBT,'SECTIONS'+D7uW1QmTbnY3BROdiNUFvKyJ0lZc8[:-1],group,ft3e2JBKQVXWlFPjaMhkEqGxvDg,BZdvf7MIUxHQc3aCT)
	if '_RANDOM_' in khALrUNtziB3gX and len(ft3e2JBKQVXWlFPjaMhkEqGxvDg)>rQCcZ7utdLnPye8BAEm5:
		xx4viQhaOu6r0[:] = []
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','[[COLOR FFC89008]'+group+'[/COLOR] :القسم]',group,165,'','',D7uW1QmTbnY3BROdiNUFvKyJ0lZc8+'_RANDOM__FORGETRESULTS__REMEMBERRESULTS_')
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','إعادة الطلب العشوائي من نفس القسم',group,165,'','',D7uW1QmTbnY3BROdiNUFvKyJ0lZc8+'_RANDOM__FORGETRESULTS__REMEMBERRESULTS_')
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
		ft3e2JBKQVXWlFPjaMhkEqGxvDg = xx4viQhaOu6r0+SS503hkALwlNIvHYW7jb.sample(ft3e2JBKQVXWlFPjaMhkEqGxvDg,rQCcZ7utdLnPye8BAEm5)
	xx4viQhaOu6r0[:] = ft3e2JBKQVXWlFPjaMhkEqGxvDg
	tUXmK5PeEH9SDq.executebuiltin('Container.Refresh')
	return
def GJ34gia6jHLQ57X0N2(khALrUNtziB3gX):
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','إعادة طلب قنوات عشوائية','',161,'','','_FORGETRESULTS__REMEMBERRESULTS__LIVETV__RANDOM_')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	ldZI5zmPyOLEUpM1iRvoX94b = xx4viQhaOu6r0[:]
	xx4viQhaOu6r0[:] = []
	import jexwNETf0R
	jexwNETf0R.TJZvpKG2we('0',False)
	jexwNETf0R.TJZvpKG2we('1',False)
	jexwNETf0R.TJZvpKG2we('2',False)
	if '_RANDOM_' in khALrUNtziB3gX:
		xx4viQhaOu6r0[:] = BQHblqILZGwnO(xx4viQhaOu6r0)
		if len(xx4viQhaOu6r0)>rQCcZ7utdLnPye8BAEm5: xx4viQhaOu6r0[:] = SS503hkALwlNIvHYW7jb.sample(xx4viQhaOu6r0,rQCcZ7utdLnPye8BAEm5)
	xx4viQhaOu6r0[:] = ldZI5zmPyOLEUpM1iRvoX94b+xx4viQhaOu6r0
	return
def ffIE4P8WBaQbu2vygZzSJF6rV7(khALrUNtziB3gX):
	khALrUNtziB3gX = khALrUNtziB3gX.replace('_FORGETRESULTS_','').replace('_REMEMBERRESULTS_','')
	headers = { 'User-Agent' : '' }
	url = 'https://www.bestrandoms.com/random-arabic-words'
	data = {'quantity':'50'}
	data = xcWMv9b8dpTSq1IZ5eht(data)
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(c1lwnq73vkXsVjEhFpeoZtD,'GET',url,data,headers,'','','RANDOMS-RANDOM_VIDEOS_FROM_WORDS-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	XBuP6Op7y4K = My7Dwqvs6bfGNSIgX.findall('class="content"(.*?)class="clearfix"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	vsptNMP2ZQC = XBuP6Op7y4K[0]
	items = My7Dwqvs6bfGNSIgX.findall('<span>(.*?)</span>.*?<span>(.*?)</span>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	sP9g7u1QxRyYGvilBn5DJmatA,VVhZCuf1grxQc4H = list(zip(*items))
	hX6oIuvEf2V3nx5 = []
	znghZ3f4POYq5JW = [' ','"','`',',','.',':',';',"'",'-']
	Kf4glpviCZNTMW871 = VVhZCuf1grxQc4H+sP9g7u1QxRyYGvilBn5DJmatA
	for gLjeHFVsicRydI7vra6k4J in Kf4glpviCZNTMW871:
		if gLjeHFVsicRydI7vra6k4J in VVhZCuf1grxQc4H: llKaVOXfeF4N8CEjbZYWyw5R6ipc = 2
		if gLjeHFVsicRydI7vra6k4J in sP9g7u1QxRyYGvilBn5DJmatA: llKaVOXfeF4N8CEjbZYWyw5R6ipc = 4
		HqmzWPBjptgy2ToR17nMvJu = [FVW0I9sYcAjmDgn8r in gLjeHFVsicRydI7vra6k4J for FVW0I9sYcAjmDgn8r in znghZ3f4POYq5JW]
		if any(HqmzWPBjptgy2ToR17nMvJu):
			gMous1DWl97JdE5h6n0CFjeLZkq = HqmzWPBjptgy2ToR17nMvJu.index(True)
			KgdC0oXHfy2ljFe8sZDVEqt3mRv = znghZ3f4POYq5JW[gMous1DWl97JdE5h6n0CFjeLZkq]
			sW7IefTp5PEtUOvJg = ''
			if gLjeHFVsicRydI7vra6k4J.count(KgdC0oXHfy2ljFe8sZDVEqt3mRv)>1: RzhQ7YV58c6,HmNgMczv0sL6x45SVDPtqX,sW7IefTp5PEtUOvJg = gLjeHFVsicRydI7vra6k4J.split(KgdC0oXHfy2ljFe8sZDVEqt3mRv,2)
			else: RzhQ7YV58c6,HmNgMczv0sL6x45SVDPtqX = gLjeHFVsicRydI7vra6k4J.split(KgdC0oXHfy2ljFe8sZDVEqt3mRv,1)
			if len(RzhQ7YV58c6)>llKaVOXfeF4N8CEjbZYWyw5R6ipc: hX6oIuvEf2V3nx5.append(RzhQ7YV58c6.lower())
			if len(HmNgMczv0sL6x45SVDPtqX)>llKaVOXfeF4N8CEjbZYWyw5R6ipc: hX6oIuvEf2V3nx5.append(HmNgMczv0sL6x45SVDPtqX.lower())
			if len(sW7IefTp5PEtUOvJg)>llKaVOXfeF4N8CEjbZYWyw5R6ipc: hX6oIuvEf2V3nx5.append(sW7IefTp5PEtUOvJg.lower())
		elif len(gLjeHFVsicRydI7vra6k4J)>llKaVOXfeF4N8CEjbZYWyw5R6ipc: hX6oIuvEf2V3nx5.append(gLjeHFVsicRydI7vra6k4J.lower())
	for FVW0I9sYcAjmDgn8r in range(9): SS503hkALwlNIvHYW7jb.shuffle(hX6oIuvEf2V3nx5)
	if '_SITES_' in khALrUNtziB3gX:
		yOarw9bjceSmWdkZ6D7qtRIfAM2 = f4nPgrNMkXuoFbljyB6RWV
	elif '_IPTV_' in khALrUNtziB3gX:
		yOarw9bjceSmWdkZ6D7qtRIfAM2 = ['IPTV']
		import OJR51gj7FS
		if not OJR51gj7FS.p13ciNHPqwljuY5KQIWfD6EOm('',True): return
	elif '_M3U_' in khALrUNtziB3gX:
		yOarw9bjceSmWdkZ6D7qtRIfAM2 = ['M3U']
		import F9HnjCOwhi
		if not F9HnjCOwhi.p13ciNHPqwljuY5KQIWfD6EOm('',True): return
	count,XoIGseEj021t5J4H = 0,0
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','[  ] :البحث عن','',164,'','','_FORGETRESULTS__REMEMBERRESULTS_'+khALrUNtziB3gX)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','إعادة البحث العشوائي','',164,'','','_FORGETRESULTS__REMEMBERRESULTS_'+khALrUNtziB3gX)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	nnxSwtI2W35zKvsA = xx4viQhaOu6r0[:]
	xx4viQhaOu6r0[:] = []
	DO8bmtljcRk4C7xG0qUh3VZ1SAdKpT = []
	for gLjeHFVsicRydI7vra6k4J in hX6oIuvEf2V3nx5:
		HmNgMczv0sL6x45SVDPtqX = My7Dwqvs6bfGNSIgX.findall('[ \,\;\:\-\+\=\"\'\[\]\(\)\{\}\!\@'+'#'+'\$\%\^\&\*\_\<\>]',gLjeHFVsicRydI7vra6k4J,My7Dwqvs6bfGNSIgX.DOTALL)
		if HmNgMczv0sL6x45SVDPtqX: gLjeHFVsicRydI7vra6k4J = gLjeHFVsicRydI7vra6k4J.split(HmNgMczv0sL6x45SVDPtqX[0],1)[0]
		mB3lEKi1VHWj8nFdQ0U = gLjeHFVsicRydI7vra6k4J.replace('ّ','').replace('َ','').replace('ً','').replace('ُ','').replace('ٌ','')
		mB3lEKi1VHWj8nFdQ0U = mB3lEKi1VHWj8nFdQ0U.replace('ِ','').replace('ٍ','').replace('ْ','').replace('،','').replace('ـ','')
		if mB3lEKi1VHWj8nFdQ0U: DO8bmtljcRk4C7xG0qUh3VZ1SAdKpT.append(mB3lEKi1VHWj8nFdQ0U)
	KnYSGLTJFkbt = []
	for k3Om08MCgqQao4n1 in range(0,20):
		search = SS503hkALwlNIvHYW7jb.sample(DO8bmtljcRk4C7xG0qUh3VZ1SAdKpT,1)[0]
		if search in KnYSGLTJFkbt: continue
		KnYSGLTJFkbt.append(search)
		bo1dqzR8JIwlThvDcyU4jf = SS503hkALwlNIvHYW7jb.sample(yOarw9bjceSmWdkZ6D7qtRIfAM2,1)[0]
		Lmj1pfQk63XdoeH('NOTICE',Dwl0N6FKuVU8nB1mbisIrCzdO(baNWS6nfqTC5iX4Kl)+'   Random Video Search   site:'+str(bo1dqzR8JIwlThvDcyU4jf)+'  search:'+search)
		JoakAQ4uiT5,dZT40j7heA1zsu3Nak,rrFcwfjUW34gaDKp2mHNB58Azbs = RB0138fEQHwDFGn(bo1dqzR8JIwlThvDcyU4jf)
		dZT40j7heA1zsu3Nak(search+'_NODIALOGS_')
		if len(xx4viQhaOu6r0)>0: break
	search = search.replace('_MOD_','')
	nnxSwtI2W35zKvsA[0][1] = '[[COLOR FFC89008]'+search+'[/COLOR] :بحث عن]'
	xx4viQhaOu6r0[:] = BQHblqILZGwnO(xx4viQhaOu6r0)
	if len(xx4viQhaOu6r0)>rQCcZ7utdLnPye8BAEm5: xx4viQhaOu6r0[:] = SS503hkALwlNIvHYW7jb.sample(xx4viQhaOu6r0,rQCcZ7utdLnPye8BAEm5)
	xx4viQhaOu6r0[:] = nnxSwtI2W35zKvsA+xx4viQhaOu6r0
	return
def YYQopOAvCRsMfqu01xVHNUnZ(FFKVvb8IW0oDclexrYn5tP2q3M,khALrUNtziB3gX):
	FFKVvb8IW0oDclexrYn5tP2q3M = FFKVvb8IW0oDclexrYn5tP2q3M.replace('_MOD_','')
	khALrUNtziB3gX = khALrUNtziB3gX.replace('_FORGETRESULTS_','').replace('_REMEMBERRESULTS_','')
	LL4bBCfItMrPSzwHk6Do7Yl3vVg(False)
	if aaN3V2d6LKgSXOotH5n=={}: return
	if '_RANDOM_' in khALrUNtziB3gX:
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','[[COLOR FFC89008]'+FFKVvb8IW0oDclexrYn5tP2q3M+'[/COLOR] :القسم]',FFKVvb8IW0oDclexrYn5tP2q3M,166,'','','_FORGETRESULTS__REMEMBERRESULTS_'+khALrUNtziB3gX)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','إعادة الطلب العشوائي من نفس القسم',FFKVvb8IW0oDclexrYn5tP2q3M,166,'','','_FORGETRESULTS__REMEMBERRESULTS_'+khALrUNtziB3gX)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	for website in sorted(list(aaN3V2d6LKgSXOotH5n[FFKVvb8IW0oDclexrYn5tP2q3M].keys())):
		type,bSxczpUtHewVDKa3EL4lm,url,WrI1XaHkSE7iKbOxJ8Nz9qFC,QFrVYJkywEsXquMNz,z3z9QgENFk5eMYB4,Gfsr6KpyVRovQmB8xcXUJ,ezSE9fBuvT,yPoqtK3i7zHulhZJDWYsnLxvT0 = aaN3V2d6LKgSXOotH5n[FFKVvb8IW0oDclexrYn5tP2q3M][website]
		if '_RANDOM_' in khALrUNtziB3gX or len(aaN3V2d6LKgSXOotH5n[FFKVvb8IW0oDclexrYn5tP2q3M])==1:
			uu970x1YwvLq6crQhsHeOj(type,'',url,WrI1XaHkSE7iKbOxJ8Nz9qFC,'',z3z9QgENFk5eMYB4,Gfsr6KpyVRovQmB8xcXUJ,'','')
			xx4viQhaOu6r0[:] = BQHblqILZGwnO(xx4viQhaOu6r0)
			v1v4cjwhtfsi7OE9F6XxeNqz,lsSvZMNpBrH78OtKiEezXgbUY = xx4viQhaOu6r0[:3],xx4viQhaOu6r0[3:]
			for FVW0I9sYcAjmDgn8r in range(9): SS503hkALwlNIvHYW7jb.shuffle(lsSvZMNpBrH78OtKiEezXgbUY)
			if '_RANDOM_' in khALrUNtziB3gX: xx4viQhaOu6r0[:] = v1v4cjwhtfsi7OE9F6XxeNqz+lsSvZMNpBrH78OtKiEezXgbUY[:rQCcZ7utdLnPye8BAEm5]
			else: xx4viQhaOu6r0[:] = v1v4cjwhtfsi7OE9F6XxeNqz+lsSvZMNpBrH78OtKiEezXgbUY
		elif '_SITES_' in khALrUNtziB3gX: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',website,url,WrI1XaHkSE7iKbOxJ8Nz9qFC,QFrVYJkywEsXquMNz,z3z9QgENFk5eMYB4,Gfsr6KpyVRovQmB8xcXUJ,ezSE9fBuvT,yPoqtK3i7zHulhZJDWYsnLxvT0)
	return
def z2Jvojqg4BTHY3C9ydZsnPw1Ve8pWF(khALrUNtziB3gX,H3HDqY5N4e0fWSXMikZ8CR7suUmJdx):
	khALrUNtziB3gX = khALrUNtziB3gX.replace('_FORGETRESULTS_','').replace('_REMEMBERRESULTS_','')
	bSxczpUtHewVDKa3EL4lm,VpbvLoZDXlQtK = '',[]
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','[[COLOR FFC89008]'+bSxczpUtHewVDKa3EL4lm+'[/COLOR] :القسم]','',H3HDqY5N4e0fWSXMikZ8CR7suUmJdx,'','','_FORGETRESULTS__REMEMBERRESULTS_'+khALrUNtziB3gX)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','إعادة طلب قسم عشوائي','',H3HDqY5N4e0fWSXMikZ8CR7suUmJdx,'','','_FORGETRESULTS__REMEMBERRESULTS_'+khALrUNtziB3gX)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	v1v4cjwhtfsi7OE9F6XxeNqz = xx4viQhaOu6r0[:]
	xx4viQhaOu6r0[:] = []
	ft3e2JBKQVXWlFPjaMhkEqGxvDg = []
	if '_SITES_' in khALrUNtziB3gX:
		LL4bBCfItMrPSzwHk6Do7Yl3vVg(False)
		if aaN3V2d6LKgSXOotH5n=={}: return
		dVGSZiRh8JtWOUpkB6K3yf9mX = list(aaN3V2d6LKgSXOotH5n.keys())
		FFKVvb8IW0oDclexrYn5tP2q3M = SS503hkALwlNIvHYW7jb.sample(dVGSZiRh8JtWOUpkB6K3yf9mX,1)[0]
		hX6oIuvEf2V3nx5 = list(aaN3V2d6LKgSXOotH5n[FFKVvb8IW0oDclexrYn5tP2q3M].keys())
		website = SS503hkALwlNIvHYW7jb.sample(hX6oIuvEf2V3nx5,1)[0]
		type,bSxczpUtHewVDKa3EL4lm,url,WrI1XaHkSE7iKbOxJ8Nz9qFC,QFrVYJkywEsXquMNz,z3z9QgENFk5eMYB4,Gfsr6KpyVRovQmB8xcXUJ,ezSE9fBuvT,yPoqtK3i7zHulhZJDWYsnLxvT0 = aaN3V2d6LKgSXOotH5n[FFKVvb8IW0oDclexrYn5tP2q3M][website]
		Lmj1pfQk63XdoeH('NOTICE',Dwl0N6FKuVU8nB1mbisIrCzdO(baNWS6nfqTC5iX4Kl)+'   Random Category   website: '+website+'   name: '+bSxczpUtHewVDKa3EL4lm+'   url: '+url+'   mode: '+str(WrI1XaHkSE7iKbOxJ8Nz9qFC))
	elif '_IPTV_' in khALrUNtziB3gX:
		import OJR51gj7FS
		if not OJR51gj7FS.p13ciNHPqwljuY5KQIWfD6EOm('',True): return
		for S8UKq3VcpRgBMdT1hknl4voHfr in range(1,HHm4q1SnPBZIf6wcap8zJoeDM7+1):
			ft3e2JBKQVXWlFPjaMhkEqGxvDg += ZXLkyubtMvUhnEpw085j(str(S8UKq3VcpRgBMdT1hknl4voHfr),khALrUNtziB3gX)
		if not ft3e2JBKQVXWlFPjaMhkEqGxvDg: return
		type,bSxczpUtHewVDKa3EL4lm,url,WrI1XaHkSE7iKbOxJ8Nz9qFC,QFrVYJkywEsXquMNz,z3z9QgENFk5eMYB4,Gfsr6KpyVRovQmB8xcXUJ,ezSE9fBuvT,yPoqtK3i7zHulhZJDWYsnLxvT0 = SS503hkALwlNIvHYW7jb.sample(ft3e2JBKQVXWlFPjaMhkEqGxvDg,1)[0]
		Lmj1pfQk63XdoeH('NOTICE',Dwl0N6FKuVU8nB1mbisIrCzdO(baNWS6nfqTC5iX4Kl)+'   Random Category   name: '+bSxczpUtHewVDKa3EL4lm+'   url: '+url+'   mode: '+str(WrI1XaHkSE7iKbOxJ8Nz9qFC))
	elif '_M3U_' in khALrUNtziB3gX:
		import F9HnjCOwhi
		if not F9HnjCOwhi.p13ciNHPqwljuY5KQIWfD6EOm('',True): return
		for S8UKq3VcpRgBMdT1hknl4voHfr in range(1,HHm4q1SnPBZIf6wcap8zJoeDM7+1):
			ft3e2JBKQVXWlFPjaMhkEqGxvDg += ay4n5mIN9zu(str(S8UKq3VcpRgBMdT1hknl4voHfr),khALrUNtziB3gX)
		if not ft3e2JBKQVXWlFPjaMhkEqGxvDg: return
		type,bSxczpUtHewVDKa3EL4lm,url,WrI1XaHkSE7iKbOxJ8Nz9qFC,QFrVYJkywEsXquMNz,z3z9QgENFk5eMYB4,Gfsr6KpyVRovQmB8xcXUJ,ezSE9fBuvT,yPoqtK3i7zHulhZJDWYsnLxvT0 = SS503hkALwlNIvHYW7jb.sample(ft3e2JBKQVXWlFPjaMhkEqGxvDg,1)[0]
		Lmj1pfQk63XdoeH('NOTICE',Dwl0N6FKuVU8nB1mbisIrCzdO(baNWS6nfqTC5iX4Kl)+'   Random Category   name: '+bSxczpUtHewVDKa3EL4lm+'   url: '+url+'   mode: '+str(WrI1XaHkSE7iKbOxJ8Nz9qFC))
	nXOjwWdRq2GF = bSxczpUtHewVDKa3EL4lm
	NDZW4fag7it = []
	for FVW0I9sYcAjmDgn8r in range(0,10):
		if FVW0I9sYcAjmDgn8r>0: Lmj1pfQk63XdoeH('NOTICE',Dwl0N6FKuVU8nB1mbisIrCzdO(baNWS6nfqTC5iX4Kl)+'   Random Category   name: '+bSxczpUtHewVDKa3EL4lm+'   url: '+url+'   mode: '+str(WrI1XaHkSE7iKbOxJ8Nz9qFC))
		xx4viQhaOu6r0[:] = []
		if WrI1XaHkSE7iKbOxJ8Nz9qFC==234 and '__IPTVSeries__' in Gfsr6KpyVRovQmB8xcXUJ: WrI1XaHkSE7iKbOxJ8Nz9qFC = 233
		if WrI1XaHkSE7iKbOxJ8Nz9qFC==714 and '__M3USeries__' in Gfsr6KpyVRovQmB8xcXUJ: WrI1XaHkSE7iKbOxJ8Nz9qFC = 713
		if WrI1XaHkSE7iKbOxJ8Nz9qFC==144: WrI1XaHkSE7iKbOxJ8Nz9qFC = 291
		wLWTRZQNlpACcvdFU3Vo = uu970x1YwvLq6crQhsHeOj(type,bSxczpUtHewVDKa3EL4lm,url,WrI1XaHkSE7iKbOxJ8Nz9qFC,QFrVYJkywEsXquMNz,z3z9QgENFk5eMYB4,Gfsr6KpyVRovQmB8xcXUJ,ezSE9fBuvT,yPoqtK3i7zHulhZJDWYsnLxvT0)
		if '_IPTV_' in khALrUNtziB3gX and WrI1XaHkSE7iKbOxJ8Nz9qFC==167: del xx4viQhaOu6r0[:3]
		if '_M3U_' in khALrUNtziB3gX and WrI1XaHkSE7iKbOxJ8Nz9qFC==168: del xx4viQhaOu6r0[:3]
		VpbvLoZDXlQtK[:] = BQHblqILZGwnO(xx4viQhaOu6r0)
		if NDZW4fag7it and gEYUZMaD6vB(u'حلقة') in str(VpbvLoZDXlQtK) or gEYUZMaD6vB(u'حلقه') in str(VpbvLoZDXlQtK):
			bSxczpUtHewVDKa3EL4lm = nXOjwWdRq2GF
			VpbvLoZDXlQtK[:] = NDZW4fag7it
			break
		nXOjwWdRq2GF = bSxczpUtHewVDKa3EL4lm
		NDZW4fag7it = VpbvLoZDXlQtK
		if str(VpbvLoZDXlQtK).count('video')>0: break
		if str(VpbvLoZDXlQtK).count('live')>0: break
		if WrI1XaHkSE7iKbOxJ8Nz9qFC==233: break
		if WrI1XaHkSE7iKbOxJ8Nz9qFC==713: break
		if WrI1XaHkSE7iKbOxJ8Nz9qFC==291: break
		if VpbvLoZDXlQtK: type,bSxczpUtHewVDKa3EL4lm,url,WrI1XaHkSE7iKbOxJ8Nz9qFC,QFrVYJkywEsXquMNz,z3z9QgENFk5eMYB4,Gfsr6KpyVRovQmB8xcXUJ,ezSE9fBuvT,yPoqtK3i7zHulhZJDWYsnLxvT0 = SS503hkALwlNIvHYW7jb.sample(VpbvLoZDXlQtK,1)[0]
	if not bSxczpUtHewVDKa3EL4lm: bSxczpUtHewVDKa3EL4lm = '....'
	elif bSxczpUtHewVDKa3EL4lm.count('_')>1: bSxczpUtHewVDKa3EL4lm = bSxczpUtHewVDKa3EL4lm.split('_',2)[2]
	bSxczpUtHewVDKa3EL4lm = bSxczpUtHewVDKa3EL4lm.replace('UNKNOWN: ','')
	bSxczpUtHewVDKa3EL4lm = bSxczpUtHewVDKa3EL4lm.replace('_MOD_','')
	v1v4cjwhtfsi7OE9F6XxeNqz[0][1] = '[[COLOR FFC89008]'+bSxczpUtHewVDKa3EL4lm+'[/COLOR] :القسم]'
	for FVW0I9sYcAjmDgn8r in range(9): SS503hkALwlNIvHYW7jb.shuffle(VpbvLoZDXlQtK)
	if '_RANDOM_' in khALrUNtziB3gX: xx4viQhaOu6r0[:] = v1v4cjwhtfsi7OE9F6XxeNqz+VpbvLoZDXlQtK[:rQCcZ7utdLnPye8BAEm5]
	else: xx4viQhaOu6r0[:] = v1v4cjwhtfsi7OE9F6XxeNqz+VpbvLoZDXlQtK
	return
def wnNV7mhJFyu5At81iIbvdx4QT(gUHIqF3mTptPkc7Za9CrlM4,aaLqsEjgfXv3CrQS7):
	aaLqsEjgfXv3CrQS7 = aaLqsEjgfXv3CrQS7.replace('_FORGETRESULTS_','').replace('_REMEMBERRESULTS_','')
	TVBWxhIvUdX4alRpz1kfQZPuJ73m = aaLqsEjgfXv3CrQS7
	if '__IPTVSeries__' in aaLqsEjgfXv3CrQS7:
		TVBWxhIvUdX4alRpz1kfQZPuJ73m = aaLqsEjgfXv3CrQS7.split('__IPTVSeries__')[0]
		type = ',SERIES: '
	elif 'VOD' in gUHIqF3mTptPkc7Za9CrlM4: type = ',VIDEOS: '
	elif 'LIVE' in gUHIqF3mTptPkc7Za9CrlM4: type = ',LIVE: '
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','[[COLOR FFC89008]'+type+TVBWxhIvUdX4alRpz1kfQZPuJ73m+'[/COLOR] :القسم]',gUHIqF3mTptPkc7Za9CrlM4,167,'','','_FORGETRESULTS__REMEMBERRESULTS_'+aaLqsEjgfXv3CrQS7)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','إعادة الطلب العشوائي من نفس القسم',gUHIqF3mTptPkc7Za9CrlM4,167,'','','_FORGETRESULTS__REMEMBERRESULTS_'+aaLqsEjgfXv3CrQS7)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	import OJR51gj7FS
	for S8UKq3VcpRgBMdT1hknl4voHfr in range(1,HHm4q1SnPBZIf6wcap8zJoeDM7+1):
		if '__IPTVSeries__' in aaLqsEjgfXv3CrQS7: OJR51gj7FS.um1OcGXaBWrP(str(S8UKq3VcpRgBMdT1hknl4voHfr),gUHIqF3mTptPkc7Za9CrlM4,aaLqsEjgfXv3CrQS7,'',False)
		else: OJR51gj7FS.TJZvpKG2we(str(S8UKq3VcpRgBMdT1hknl4voHfr),gUHIqF3mTptPkc7Za9CrlM4,aaLqsEjgfXv3CrQS7,'',False)
	xx4viQhaOu6r0[:] = BQHblqILZGwnO(xx4viQhaOu6r0)
	if len(xx4viQhaOu6r0)>(rQCcZ7utdLnPye8BAEm5+3): xx4viQhaOu6r0[:] = xx4viQhaOu6r0[:3]+SS503hkALwlNIvHYW7jb.sample(xx4viQhaOu6r0[3:],rQCcZ7utdLnPye8BAEm5)
	return
def s7lC0XnSY3dyx65PDF9g(gUHIqF3mTptPkc7Za9CrlM4,aaLqsEjgfXv3CrQS7):
	aaLqsEjgfXv3CrQS7 = aaLqsEjgfXv3CrQS7.replace('_FORGETRESULTS_','').replace('_REMEMBERRESULTS_','')
	TVBWxhIvUdX4alRpz1kfQZPuJ73m = aaLqsEjgfXv3CrQS7
	if '__M3USeries__' in aaLqsEjgfXv3CrQS7:
		TVBWxhIvUdX4alRpz1kfQZPuJ73m = aaLqsEjgfXv3CrQS7.split('__M3USeries__')[0]
		type = ',SERIES: '
	elif 'VOD' in gUHIqF3mTptPkc7Za9CrlM4: type = ',VIDEOS: '
	elif 'LIVE' in gUHIqF3mTptPkc7Za9CrlM4: type = ',LIVE: '
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','[[COLOR FFC89008]'+type+TVBWxhIvUdX4alRpz1kfQZPuJ73m+'[/COLOR] :القسم]',gUHIqF3mTptPkc7Za9CrlM4,168,'','','_FORGETRESULTS__REMEMBERRESULTS_'+aaLqsEjgfXv3CrQS7)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder','إعادة الطلب العشوائي من نفس القسم',gUHIqF3mTptPkc7Za9CrlM4,168,'','','_FORGETRESULTS__REMEMBERRESULTS_'+aaLqsEjgfXv3CrQS7)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	import F9HnjCOwhi
	for S8UKq3VcpRgBMdT1hknl4voHfr in range(1,HHm4q1SnPBZIf6wcap8zJoeDM7+1):
		if '__M3USeries__' in aaLqsEjgfXv3CrQS7: F9HnjCOwhi.um1OcGXaBWrP(str(S8UKq3VcpRgBMdT1hknl4voHfr),gUHIqF3mTptPkc7Za9CrlM4,aaLqsEjgfXv3CrQS7,'',False)
		else: F9HnjCOwhi.TJZvpKG2we(str(S8UKq3VcpRgBMdT1hknl4voHfr),gUHIqF3mTptPkc7Za9CrlM4,aaLqsEjgfXv3CrQS7,'',False)
	xx4viQhaOu6r0[:] = BQHblqILZGwnO(xx4viQhaOu6r0)
	if len(xx4viQhaOu6r0)>(rQCcZ7utdLnPye8BAEm5+3): xx4viQhaOu6r0[:] = xx4viQhaOu6r0[:3]+SS503hkALwlNIvHYW7jb.sample(xx4viQhaOu6r0[3:],rQCcZ7utdLnPye8BAEm5)
	return
def BQHblqILZGwnO(xx4viQhaOu6r0):
	VpbvLoZDXlQtK = []
	for type,bSxczpUtHewVDKa3EL4lm,url,H3HDqY5N4e0fWSXMikZ8CR7suUmJdx,QFrVYJkywEsXquMNz,z3z9QgENFk5eMYB4,Gfsr6KpyVRovQmB8xcXUJ,ezSE9fBuvT,yPoqtK3i7zHulhZJDWYsnLxvT0 in xx4viQhaOu6r0:
		if 'صفحة' in bSxczpUtHewVDKa3EL4lm or 'صفحه' in bSxczpUtHewVDKa3EL4lm or 'page' in bSxczpUtHewVDKa3EL4lm.lower(): continue
		VpbvLoZDXlQtK.append([type,bSxczpUtHewVDKa3EL4lm,url,H3HDqY5N4e0fWSXMikZ8CR7suUmJdx,QFrVYJkywEsXquMNz,z3z9QgENFk5eMYB4,Gfsr6KpyVRovQmB8xcXUJ,ezSE9fBuvT,yPoqtK3i7zHulhZJDWYsnLxvT0])
	return VpbvLoZDXlQtK
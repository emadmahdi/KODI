﻿# -*- coding: utf-8 -*-
from G6AHskJeqN import *
baNWS6nfqTC5iX4Kl = 'ALMAAREF'
headers = {'User-Agent':''}
teUPLFC3B8bArakwHVGsdhoIWDM49f = '_MRF_'
EZxQp1WOldMTvFU = AK5RqLhji4W1wt9VdrCD3PGeQM[baNWS6nfqTC5iX4Kl][0]
eh2tDvRFWpLQI = ['التواصل الاجتماعي','صور التواصل الاجتماعي','أرشيف جميع البرامج']
def VbgEajY4Bt2COpGDcPqI(mode,url,text,z3z9QgENFk5eMYB4):
	if   mode==40: ft3e2JBKQVXWlFPjaMhkEqGxvDg = eN02L7Tf5bQ()
	elif mode==41: ft3e2JBKQVXWlFPjaMhkEqGxvDg = KK8gr6Iv04mjZXF()
	elif mode==42: ft3e2JBKQVXWlFPjaMhkEqGxvDg = ccQPRvWqfakzuNr7VpeK9Uxwi(text,z3z9QgENFk5eMYB4)
	elif mode==43: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HDxCnPKFhITpZmOsA4a0UL6(url)
	elif mode==44: ft3e2JBKQVXWlFPjaMhkEqGxvDg = sscM839DP1jWZ4zl6uIx0Kyn(text,z3z9QgENFk5eMYB4)
	elif mode==49: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HjZcUIVAXFCqy9TfBWKtgY2(text)
	else: ft3e2JBKQVXWlFPjaMhkEqGxvDg = False
	return ft3e2JBKQVXWlFPjaMhkEqGxvDg
def eN02L7Tf5bQ():
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'بحث في الموقع','',49)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('live',teUPLFC3B8bArakwHVGsdhoIWDM49f+'البث الحي لقناة المعارف','',41)
	ccQPRvWqfakzuNr7VpeK9Uxwi('','1')
	return
def DkconUtaeN1s8SL0Ru5XYQ(LQf3AeozSrai,aCSrmxQ4RcjdkbPswXN):
	search,sort,FCljOwM3Sg6Bt4Vo,g4Y0BXLxCpuojKP1SAUtcq7TwN2,gJSfpNXQqcvuARKseLm23VIGaUMB5 = '',[],[],[],[]
	wLWTRZQNlpACcvdFU3Vo,HZCxSom97kbMXKV = NgD0bJaq14yBnMYoziAmLj(LQf3AeozSrai)
	for A5AMg7LY1HlOz0B82n in list(HZCxSom97kbMXKV.keys()):
		WoFrX46wzbCNp18 = HZCxSom97kbMXKV[A5AMg7LY1HlOz0B82n]
		if not WoFrX46wzbCNp18: continue
		if   A5AMg7LY1HlOz0B82n=='sort': sort = [WoFrX46wzbCNp18]
		elif A5AMg7LY1HlOz0B82n=='series': FCljOwM3Sg6Bt4Vo = [WoFrX46wzbCNp18]
		elif A5AMg7LY1HlOz0B82n=='search': search = WoFrX46wzbCNp18
		elif A5AMg7LY1HlOz0B82n=='category': g4Y0BXLxCpuojKP1SAUtcq7TwN2 = [WoFrX46wzbCNp18]
		elif A5AMg7LY1HlOz0B82n=='specialist': gJSfpNXQqcvuARKseLm23VIGaUMB5 = [WoFrX46wzbCNp18]
	tWha1P9LVeuNxpQUAB = {"action":"facetwp_refresh","data":{"facets":{"search":search,"video_categories":g4Y0BXLxCpuojKP1SAUtcq7TwN2,"specialist":gJSfpNXQqcvuARKseLm23VIGaUMB5,"series":FCljOwM3Sg6Bt4Vo,"number":[],"sort_video":sort,"count":[],"pagination":[]},"frozen_facets":{},"template":"video_desktop_posts","extras":{"sort":"default"},"soft_refresh":0,"is_bfcache":1,"first_load":0,"paged":int(aCSrmxQ4RcjdkbPswXN)}}
	import json as C56R029JKDm
	tWha1P9LVeuNxpQUAB = C56R029JKDm.dumps(tWha1P9LVeuNxpQUAB)
	BoEFz2WhUyvTgDeiZ = 'https://almaaref.ch/wp-json/facetwp/v1/refresh'
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'POST',BoEFz2WhUyvTgDeiZ,tWha1P9LVeuNxpQUAB,'','','','ALMAAREF-REQUEST_DATA_PAGE-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	data = dWsa2A0O4o5BYiqGXhyKEbM('dict',MK6ZT2zjC1SbmveNFqor)
	return data
def ccQPRvWqfakzuNr7VpeK9Uxwi(LQf3AeozSrai,level):
	xAcIatGBYy0FLXroS1ig3Ts9KZ8P5 = DkconUtaeN1s8SL0Ru5XYQ(LQf3AeozSrai,'1')
	vsptNMP2ZQC = xAcIatGBYy0FLXroS1ig3Ts9KZ8P5['facets']
	if level=='1':
		vsptNMP2ZQC = vsptNMP2ZQC['video_categories']
		items = My7Dwqvs6bfGNSIgX.findall('<div(.*?)/div>',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for ZA1fBenNahOR3xrkjvwYSVMy6JK5s in items:
			AwKc1kuJ7V = My7Dwqvs6bfGNSIgX.findall('data-value=\\"(.*?)\\".*?display-value\\">(.*?)<',ZA1fBenNahOR3xrkjvwYSVMy6JK5s+'<',My7Dwqvs6bfGNSIgX.DOTALL)
			if not AwKc1kuJ7V: AwKc1kuJ7V = My7Dwqvs6bfGNSIgX.findall('data-value=\\"(.*?)\\">(.*?)<',ZA1fBenNahOR3xrkjvwYSVMy6JK5s+'<',My7Dwqvs6bfGNSIgX.DOTALL)
			g4Y0BXLxCpuojKP1SAUtcq7TwN2,title = AwKc1kuJ7V[0]
			if not LQf3AeozSrai: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+title,'',42,'','2','?category='+g4Y0BXLxCpuojKP1SAUtcq7TwN2)
			else: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,'',42,'','2',LQf3AeozSrai+'&category='+g4Y0BXLxCpuojKP1SAUtcq7TwN2)
	if level=='2':
		vsptNMP2ZQC = vsptNMP2ZQC['specialist']
		items = My7Dwqvs6bfGNSIgX.findall('value="(.*?)".*?>(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for gJSfpNXQqcvuARKseLm23VIGaUMB5,title in items:
			if not gJSfpNXQqcvuARKseLm23VIGaUMB5: title = title = 'الجميع'
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,'',42,'','3',LQf3AeozSrai+'&specialist='+gJSfpNXQqcvuARKseLm23VIGaUMB5)
	elif level=='3':
		vsptNMP2ZQC = vsptNMP2ZQC['series']
		items = My7Dwqvs6bfGNSIgX.findall('value="(.*?)".*?>(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for FCljOwM3Sg6Bt4Vo,title in items:
			if not FCljOwM3Sg6Bt4Vo: title = title = 'الجميع'
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,'',42,'','4',LQf3AeozSrai+'&series='+FCljOwM3Sg6Bt4Vo)
	elif level=='4':
		vsptNMP2ZQC = vsptNMP2ZQC['sort_video']
		items = My7Dwqvs6bfGNSIgX.findall('value="(.*?)".*?>(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
		for sort,title in items:
			if not sort: continue
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,'',44,'','1',LQf3AeozSrai+'&sort='+sort)
	return
def sscM839DP1jWZ4zl6uIx0Kyn(LQf3AeozSrai,aCSrmxQ4RcjdkbPswXN):
	xAcIatGBYy0FLXroS1ig3Ts9KZ8P5 = DkconUtaeN1s8SL0Ru5XYQ(LQf3AeozSrai,aCSrmxQ4RcjdkbPswXN)
	vsptNMP2ZQC = xAcIatGBYy0FLXroS1ig3Ts9KZ8P5['template']
	items = My7Dwqvs6bfGNSIgX.findall('src="(.*?)".*?href="(.*?)">(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	for IcWzVO137wFvemn2QTq8yKs9,BoEFz2WhUyvTgDeiZ,title in items:
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,43,IcWzVO137wFvemn2QTq8yKs9)
	vsptNMP2ZQC = xAcIatGBYy0FLXroS1ig3Ts9KZ8P5['facets']['pagination']
	items = My7Dwqvs6bfGNSIgX.findall('data-page="(.*?)">(.*?)<',vsptNMP2ZQC,My7Dwqvs6bfGNSIgX.DOTALL)
	for z3z9QgENFk5eMYB4,title in items:
		if aCSrmxQ4RcjdkbPswXN==z3z9QgENFk5eMYB4: continue
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'صفحة '+title,'',44,'',z3z9QgENFk5eMYB4,LQf3AeozSrai)
	return
def HDxCnPKFhITpZmOsA4a0UL6(url):
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(UuEtImzir9,'GET',url,'','','','','ALMAAREF-PLAY-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	BoEFz2WhUyvTgDeiZ = My7Dwqvs6bfGNSIgX.findall('<video src="(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if not BoEFz2WhUyvTgDeiZ: BoEFz2WhUyvTgDeiZ = My7Dwqvs6bfGNSIgX.findall('youtube_url.*?(http.*?)&',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	Qki8AbTHYjzM2Ls76Gdr3eqo1Wn = []
	if BoEFz2WhUyvTgDeiZ:
		BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ[0].replace('\/','/')
		Qki8AbTHYjzM2Ls76Gdr3eqo1Wn.append(BoEFz2WhUyvTgDeiZ)
	import t1kDWXQVpC
	t1kDWXQVpC.rqVt2xDi7jzJHBcPMRs6h0L(Qki8AbTHYjzM2Ls76Gdr3eqo1Wn,baNWS6nfqTC5iX4Kl,'video',url)
	return
def KK8gr6Iv04mjZXF():
	xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(IIiPCruL6dT8s1lqj47SzpVHnYNm,'GET',EZxQp1WOldMTvFU+'/بث-مباشر','','','','','ALMAAREF-LIVE-1st')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	url = My7Dwqvs6bfGNSIgX.findall('"svpPlayer".*?(http.*?)&',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	url = url[0].replace('\\','')
	B0xcwKkMQ16mpSFRaVHPTzuhUZngLq(url,baNWS6nfqTC5iX4Kl,'live')
	return
def HjZcUIVAXFCqy9TfBWKtgY2(search):
	search,LQf3AeozSrai,showDialogs = X54MLovbG8nAEkB9J(search)
	spjK2gydHzfam1c7l = False
	if search=='':
		search = ViKAIsLurq83RSENayxWb()
		spjK2gydHzfam1c7l = True
	if search=='': return
	if not spjK2gydHzfam1c7l: sscM839DP1jWZ4zl6uIx0Kyn('?search='+search,'1')
	else: ccQPRvWqfakzuNr7VpeK9Uxwi('?search='+search,'1')
	return
# -*- coding: utf-8 -*-
from G6AHskJeqN import *
baNWS6nfqTC5iX4Kl = 'YOUTUBE'
teUPLFC3B8bArakwHVGsdhoIWDM49f = '_YUT_'
EZxQp1WOldMTvFU = AK5RqLhji4W1wt9VdrCD3PGeQM[baNWS6nfqTC5iX4Kl][0]
def VbgEajY4Bt2COpGDcPqI(mode,url,text,type,z3z9QgENFk5eMYB4):
	if	 mode==140: ft3e2JBKQVXWlFPjaMhkEqGxvDg = eN02L7Tf5bQ()
	elif mode==143: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HDxCnPKFhITpZmOsA4a0UL6(url,type)
	elif mode==144: ft3e2JBKQVXWlFPjaMhkEqGxvDg = TJZvpKG2we(url,text,z3z9QgENFk5eMYB4)
	elif mode==145: ft3e2JBKQVXWlFPjaMhkEqGxvDg = iuAoJsgSL0XVRzqalHWtFMhOIG(url)
	elif mode==146: ft3e2JBKQVXWlFPjaMhkEqGxvDg = QPUsRMnE5Nvrx7CfTbaL(url)
	elif mode==147: ft3e2JBKQVXWlFPjaMhkEqGxvDg = AFldBWUwyn2RuHKfZvLzO()
	elif mode==148: ft3e2JBKQVXWlFPjaMhkEqGxvDg = Pjv5aVrxEDfnhFo812GCl0tKS7i()
	elif mode==149: ft3e2JBKQVXWlFPjaMhkEqGxvDg = HjZcUIVAXFCqy9TfBWKtgY2(text)
	else: ft3e2JBKQVXWlFPjaMhkEqGxvDg = False
	return ft3e2JBKQVXWlFPjaMhkEqGxvDg
def eN02L7Tf5bQ():
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'بحث في الموقع','',149,'','','_REMEMBERRESULTS_')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+'_YTC_'+'مواقع اختارها المبرمج','',290)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'مواقع اختارها يوتيوب',EZxQp1WOldMTvFU+'/feed/guide_builder',144)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'الصفحة الرئيسية',EZxQp1WOldMTvFU,144,'','','_REMEMBERRESULTS_')
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'المحتوى الرائج',EZxQp1WOldMTvFU+'/feed/trending',146)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'بحث: قنوات عربية','',147)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'بحث: قنوات أجنبية','',148)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'بحث: افلام عربية',EZxQp1WOldMTvFU+'/results?search_query=فيلم',144)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'بحث: افلام اجنبية',EZxQp1WOldMTvFU+'/results?search_query=movie',144)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'بحث: مسرحيات عربية',EZxQp1WOldMTvFU+'/results?search_query=مسرحية',144)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'بحث: مسلسلات عربية',EZxQp1WOldMTvFU+'/results?search_query=مسلسل&sp=EgIQAw==',144)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'بحث: مسلسلات اجنبية',EZxQp1WOldMTvFU+'/results?search_query=series&sp=EgIQAw==',144)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'بحث: مسلسلات كارتون',EZxQp1WOldMTvFU+'/results?search_query=كارتون&sp=EgIQAw==',144)
	VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',baNWS6nfqTC5iX4Kl+'_SCRIPT_'+teUPLFC3B8bArakwHVGsdhoIWDM49f+'بحث: خطبة المرجعية',EZxQp1WOldMTvFU+'/results?search_query=قناة+كربلاء+الفضائية+خطبة+الجمعة&sp=CAISAhAB',144)
	return
def AFldBWUwyn2RuHKfZvLzO():
	TJZvpKG2we(EZxQp1WOldMTvFU+'/results?search_query=قناة+بث&sp=EgJAAQ==')
	return
def Pjv5aVrxEDfnhFo812GCl0tKS7i():
	TJZvpKG2we(EZxQp1WOldMTvFU+'/results?search_query=tv&sp=EgJAAQ==')
	return
def HDxCnPKFhITpZmOsA4a0UL6(url,type):
	import t1kDWXQVpC
	t1kDWXQVpC.rqVt2xDi7jzJHBcPMRs6h0L([url],baNWS6nfqTC5iX4Kl,type,url)
	return
def QPUsRMnE5Nvrx7CfTbaL(url):
	MK6ZT2zjC1SbmveNFqor,CCJpwYUsTN1cBIz5PH,data = ppUnVZPokRe5cA7(url)
	YXpcSlTtZiyO3BDa = CCJpwYUsTN1cBIz5PH['contents']['twoColumnBrowseResultsRenderer']['tabs']
	for k3Om08MCgqQao4n1 in range(len(YXpcSlTtZiyO3BDa)):
		ZA1fBenNahOR3xrkjvwYSVMy6JK5s = YXpcSlTtZiyO3BDa[k3Om08MCgqQao4n1]
		l6SBvJFG3aDHre4pjtw5R0NIucY2M(ZA1fBenNahOR3xrkjvwYSVMy6JK5s,url,str(k3Om08MCgqQao4n1))
	l03yDLAaNWS4zOHJ8FBE1KXePoV = YXpcSlTtZiyO3BDa[0]['tabRenderer']['content']['sectionListRenderer']['contents']
	UTgRFsKZwWEJLzN = 0
	for k3Om08MCgqQao4n1 in range(len(l03yDLAaNWS4zOHJ8FBE1KXePoV)):
		ZA1fBenNahOR3xrkjvwYSVMy6JK5s = l03yDLAaNWS4zOHJ8FBE1KXePoV[k3Om08MCgqQao4n1]['itemSectionRenderer']['contents'][0]
		if list(ZA1fBenNahOR3xrkjvwYSVMy6JK5s['shelfRenderer']['content'].keys())[0]=='horizontalListRenderer': continue
		a5MrRBdG4wpAYmej0ZgUyh,title,BoEFz2WhUyvTgDeiZ,IcWzVO137wFvemn2QTq8yKs9,count,LEb1HQDAeFdsrNTnVgmXo9,eBQoDdKfNvnzm73GgYjAPJR,wnpe16R7MuEO0C = JQvSljwGLBIuADxCkomKc3RN5gs(ZA1fBenNahOR3xrkjvwYSVMy6JK5s)
		if not title:
			UTgRFsKZwWEJLzN += 1
			title = 'فيديوهات رائجة '+str(UTgRFsKZwWEJLzN)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,url,144,'',str(k3Om08MCgqQao4n1))
	key = My7Dwqvs6bfGNSIgX.findall('"innertubeApiKey":"(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = 'https://www.youtube.com/youtubei/v1/guide?key='+key[0]
	MK6ZT2zjC1SbmveNFqor,CCJpwYUsTN1cBIz5PH,toAVQS46Fv8aJYyLf25KnkUNC = ppUnVZPokRe5cA7(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1)
	for nnzHUvw6s07xyEqXkuh5pR1Cj in range(3,4):
		YXpcSlTtZiyO3BDa = CCJpwYUsTN1cBIz5PH['items'][nnzHUvw6s07xyEqXkuh5pR1Cj]['guideSectionRenderer']['items']
		for k3Om08MCgqQao4n1 in range(len(YXpcSlTtZiyO3BDa)):
			ZA1fBenNahOR3xrkjvwYSVMy6JK5s = YXpcSlTtZiyO3BDa[k3Om08MCgqQao4n1]
			if 'YouTube Premium' in str(ZA1fBenNahOR3xrkjvwYSVMy6JK5s): continue
			l6SBvJFG3aDHre4pjtw5R0NIucY2M(ZA1fBenNahOR3xrkjvwYSVMy6JK5s)
	return
def TJZvpKG2we(url,data='',index=0):
	global bLEBi8IO7uU2x3htYDdVq95
	if not data: data = bLEBi8IO7uU2x3htYDdVq95.getSetting('av.youtube.data')
	if index: index = int(index)
	else: index = 0
	data = data.replace('_REMEMBERRESULTS_','')
	MK6ZT2zjC1SbmveNFqor,CCJpwYUsTN1cBIz5PH,toAVQS46Fv8aJYyLf25KnkUNC = ppUnVZPokRe5cA7(url,data)
	cc65AJFLqWMQBVls3UvegRHGb9,Xef5VkCIWcu2rzpldg4iF = '',''
	eMw2JCRLdZVYbjrtOTGEBK7FyD0N5c = My7Dwqvs6bfGNSIgX.findall('"ownerName".*?":"(.*?)".*?"url":"(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if not eMw2JCRLdZVYbjrtOTGEBK7FyD0N5c: eMw2JCRLdZVYbjrtOTGEBK7FyD0N5c = My7Dwqvs6bfGNSIgX.findall('"videoOwner".*?"text":"(.*?)".*?"url":"(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if not eMw2JCRLdZVYbjrtOTGEBK7FyD0N5c: eMw2JCRLdZVYbjrtOTGEBK7FyD0N5c = My7Dwqvs6bfGNSIgX.findall('"channelMetadataRenderer":\{"title":"(.*?)".*?"ownerUrls":\["(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
	if eMw2JCRLdZVYbjrtOTGEBK7FyD0N5c:
		cc65AJFLqWMQBVls3UvegRHGb9 = '[COLOR FFC89008]'+eMw2JCRLdZVYbjrtOTGEBK7FyD0N5c[0][0]+'[/COLOR]'
		BoEFz2WhUyvTgDeiZ = eMw2JCRLdZVYbjrtOTGEBK7FyD0N5c[0][1]
		if 'http' not in BoEFz2WhUyvTgDeiZ: BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU+BoEFz2WhUyvTgDeiZ
		if 'list=' in url: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+cc65AJFLqWMQBVls3UvegRHGb9,BoEFz2WhUyvTgDeiZ,144)
	bzrVKSMwYZd8cet2I0sRGmf3DHQ7y = ['/search','/videos','/channels','/playlists','/featured','ss=','ctoken=','key=','bp=','shelf_id=']
	LLuSvF2GgKVTdf1y7caDqJIn = not any(WoFrX46wzbCNp18 in url for WoFrX46wzbCNp18 in bzrVKSMwYZd8cet2I0sRGmf3DHQ7y)
	if LLuSvF2GgKVTdf1y7caDqJIn and cc65AJFLqWMQBVls3UvegRHGb9:
		yXskwRgtdJ = 'البحث'
		U2UaTcgBpsEZxKiRG1Xv8 = 'قوائم التشغيل'
		oVtD9zvkFegZa1S3q = 'الفيديوهات'
		V1V58PWa4AQnM9LEv2pseZKDkXy = 'القنوات'
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link',teUPLFC3B8bArakwHVGsdhoIWDM49f+cc65AJFLqWMQBVls3UvegRHGb9,url,9999)
		if '"title":"بحث"' in MK6ZT2zjC1SbmveNFqor: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+yXskwRgtdJ,url,145,'','','_REMEMBERRESULTS_')
		if '"title":"قوائم التشغيل"' in MK6ZT2zjC1SbmveNFqor: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+U2UaTcgBpsEZxKiRG1Xv8,url+'/playlists',144)
		if '"title":"الفيديوهات"' in MK6ZT2zjC1SbmveNFqor: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+oVtD9zvkFegZa1S3q,url+'/videos',144)
		if '"title":"القنوات"' in MK6ZT2zjC1SbmveNFqor: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+V1V58PWa4AQnM9LEv2pseZKDkXy,url+'/channels',144)
		if '"title":"Search"' in MK6ZT2zjC1SbmveNFqor: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+yXskwRgtdJ,url,145,'','','_REMEMBERRESULTS_')
		if '"title":"Playlists"' in MK6ZT2zjC1SbmveNFqor: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+U2UaTcgBpsEZxKiRG1Xv8,url+'/playlists',144)
		if '"title":"Videos"' in MK6ZT2zjC1SbmveNFqor: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+oVtD9zvkFegZa1S3q,url+'/videos',144)
		if '"title":"Channels"' in MK6ZT2zjC1SbmveNFqor: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+V1V58PWa4AQnM9LEv2pseZKDkXy,url+'/channels',144)
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	if 'search_query' in url:
		YXpcSlTtZiyO3BDa = CCJpwYUsTN1cBIz5PH['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['contents']
		vwol17hKxPVNYH8XB = 0
		for FVW0I9sYcAjmDgn8r in range(len(YXpcSlTtZiyO3BDa)):
			if 'itemSectionRenderer' in list(YXpcSlTtZiyO3BDa[FVW0I9sYcAjmDgn8r].keys()):
				ZAhWMpO9mnR4Ht0zu2iwrPKI = YXpcSlTtZiyO3BDa[FVW0I9sYcAjmDgn8r]['itemSectionRenderer']
				KKkapdn7Slo50RfXYTGJ6cgZ = len(str(ZAhWMpO9mnR4Ht0zu2iwrPKI))
				if KKkapdn7Slo50RfXYTGJ6cgZ>vwol17hKxPVNYH8XB:
					vwol17hKxPVNYH8XB = KKkapdn7Slo50RfXYTGJ6cgZ
					Xef5VkCIWcu2rzpldg4iF = ZAhWMpO9mnR4Ht0zu2iwrPKI
		if vwol17hKxPVNYH8XB==0: return
	elif '&list=' in url or '/search?key=' in url or '/browse?key=' in url or 'ctoken=' in url or '/search' in url or url==EZxQp1WOldMTvFU:
		nn6usrGtaj2LXy9 = []
		nn6usrGtaj2LXy9.append("cc['onResponseReceivedCommands'][0]['appendContinuationItemsAction']['continuationItems'][0]['itemSectionRenderer']")
		nn6usrGtaj2LXy9.append("cc['onResponseReceivedActions'][0]['appendContinuationItemsAction']['continuationItems']")
		nn6usrGtaj2LXy9.append("cc[1]['response']['continuationContents']['sectionListContinuation']")
		nn6usrGtaj2LXy9.append("cc[1]['response']['continuationContents']['gridContinuation']['items']")
		nn6usrGtaj2LXy9.append("cc[1]['response']['continuationContents']['playlistVideoListContinuation']")
		nn6usrGtaj2LXy9.append("cc['contents']['twoColumnBrowseResultsRenderer']['tabs'][-1]['expandableTabRenderer']['content']['sectionListRenderer']")
		nn6usrGtaj2LXy9.append("cc['contents']['twoColumnBrowseResultsRenderer']['tabs'][0]['tabRenderer']['content']['richGridRenderer']")
		nn6usrGtaj2LXy9.append("cc['contents']['twoColumnWatchNextResults']['playlist']['playlist']")
		F4C8Ul30bkjI,Xef5VkCIWcu2rzpldg4iF = KAXcRDaTGCO6(CCJpwYUsTN1cBIz5PH,'',nn6usrGtaj2LXy9)
	if not Xef5VkCIWcu2rzpldg4iF:
		try:
			YXpcSlTtZiyO3BDa = CCJpwYUsTN1cBIz5PH['contents']['twoColumnBrowseResultsRenderer']['tabs']
			F1LtjSdUrKpG9kXsWYAOxvTe = '/videos' in url or '/playlists' in url or '/channels' in url
			fkZ7iy5HtnoY1 = '"title":"الفيديوهات"' in MK6ZT2zjC1SbmveNFqor or '"title":"قوائم التشغيل"' in MK6ZT2zjC1SbmveNFqor or '"title":"القنوات"' in MK6ZT2zjC1SbmveNFqor
			dDmP6oB19LplgZrwXOKuUhN7 = '"title":"Videos"' in MK6ZT2zjC1SbmveNFqor or '"title":"Playlists"' in MK6ZT2zjC1SbmveNFqor or '"title":"Channels"' in MK6ZT2zjC1SbmveNFqor
			if F1LtjSdUrKpG9kXsWYAOxvTe and (fkZ7iy5HtnoY1 or dDmP6oB19LplgZrwXOKuUhN7):
				for k3Om08MCgqQao4n1 in range(len(YXpcSlTtZiyO3BDa)):
					if 'tabRenderer' not in list(YXpcSlTtZiyO3BDa[k3Om08MCgqQao4n1].keys()): continue
					l03yDLAaNWS4zOHJ8FBE1KXePoV = YXpcSlTtZiyO3BDa[k3Om08MCgqQao4n1]['tabRenderer']
					try: R24eyATUzVEcMFi3SDkWbJjp8a = l03yDLAaNWS4zOHJ8FBE1KXePoV['content']['sectionListRenderer']['subMenu']['channelSubMenuRenderer']['contentTypeSubMenuItems'][k3Om08MCgqQao4n1]
					except: R24eyATUzVEcMFi3SDkWbJjp8a = l03yDLAaNWS4zOHJ8FBE1KXePoV
					try: BoEFz2WhUyvTgDeiZ = R24eyATUzVEcMFi3SDkWbJjp8a['endpoint']['commandMetadata']['webCommandMetadata']['url']
					except: continue
					if   '/videos'		in BoEFz2WhUyvTgDeiZ	and '/videos'		in url: l03yDLAaNWS4zOHJ8FBE1KXePoV = YXpcSlTtZiyO3BDa[k3Om08MCgqQao4n1] ; break
					elif '/playlists'	in BoEFz2WhUyvTgDeiZ	and '/playlists'	in url: l03yDLAaNWS4zOHJ8FBE1KXePoV = YXpcSlTtZiyO3BDa[k3Om08MCgqQao4n1] ; break
					elif '/channels'	in BoEFz2WhUyvTgDeiZ	and '/channels'		in url: l03yDLAaNWS4zOHJ8FBE1KXePoV = YXpcSlTtZiyO3BDa[k3Om08MCgqQao4n1] ; break
					else: l03yDLAaNWS4zOHJ8FBE1KXePoV = YXpcSlTtZiyO3BDa[0]
			elif 'bp=' in url: l03yDLAaNWS4zOHJ8FBE1KXePoV = YXpcSlTtZiyO3BDa[index]
			else: l03yDLAaNWS4zOHJ8FBE1KXePoV = YXpcSlTtZiyO3BDa[0]
			Xef5VkCIWcu2rzpldg4iF = l03yDLAaNWS4zOHJ8FBE1KXePoV['tabRenderer']['content']
		except: pass
	if not Xef5VkCIWcu2rzpldg4iF: return
	nn6usrGtaj2LXy9 = []
	nn6usrGtaj2LXy9.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['expandedShelfContentsRenderer']['items']")
	nn6usrGtaj2LXy9.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalMovieListRenderer']['items']")
	nn6usrGtaj2LXy9.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalListRenderer']['items']")
	nn6usrGtaj2LXy9.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	nn6usrGtaj2LXy9.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['shelfRenderer']['cards']")
	nn6usrGtaj2LXy9.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
	nn6usrGtaj2LXy9.append("ff['sectionListRenderer']['contents'][int(index)]['richSectionRenderer']['content']")
	if 'view=' not in url: nn6usrGtaj2LXy9.append("ff['sectionListRenderer']['subMenu']['channelSubMenuRenderer']['contentTypeSubMenuItems']")
	nn6usrGtaj2LXy9.append("ff['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['expandedShelfContentsRenderer']['items']")
	nn6usrGtaj2LXy9.append("ff['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	nn6usrGtaj2LXy9.append("ff['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['playlistVideoListRenderer']['contents']")
	nn6usrGtaj2LXy9.append("ff['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	nn6usrGtaj2LXy9.append("ff['sectionListRenderer']['contents']")
	nn6usrGtaj2LXy9.append("ff['sectionListRenderer']")
	nn6usrGtaj2LXy9.append("ff['richGridRenderer']['contents']")
	nn6usrGtaj2LXy9.append("ff['contents']")
	nn6usrGtaj2LXy9.append("ff")
	JuCQrTA2jyEfawP6k9t8dN = gEYUZMaD6vB(u'كل قوائم التشغيل')
	DqzAgHZX4K3Brinxacv9e = gEYUZMaD6vB(u'كل الفيديوهات')
	CjhbK9Sd82FmxYnpLUe = gEYUZMaD6vB(u'كل القنوات')
	dVGSZiRh8JtWOUpkB6K3yf9mX = [JuCQrTA2jyEfawP6k9t8dN,DqzAgHZX4K3Brinxacv9e,CjhbK9Sd82FmxYnpLUe,'All playlists','All videos','All channels']
	jXWywcUh4vLRBr1bFi7YnTxNJ,R24eyATUzVEcMFi3SDkWbJjp8a = KAXcRDaTGCO6(Xef5VkCIWcu2rzpldg4iF,index,nn6usrGtaj2LXy9)
	if 'list' in str(type(R24eyATUzVEcMFi3SDkWbJjp8a)) and any(WoFrX46wzbCNp18 in str(R24eyATUzVEcMFi3SDkWbJjp8a[0]) for WoFrX46wzbCNp18 in dVGSZiRh8JtWOUpkB6K3yf9mX): del R24eyATUzVEcMFi3SDkWbJjp8a[0]
	for P5wyN7zRcUEGu9pfmqFHA4djLi in range(len(R24eyATUzVEcMFi3SDkWbJjp8a)):
		nn6usrGtaj2LXy9 = []
		nn6usrGtaj2LXy9.append("gg[index2]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['header']")
		nn6usrGtaj2LXy9.append("gg[index2]['itemSectionRenderer']['header']")
		nn6usrGtaj2LXy9.append("gg[index2]['horizontalCardListRenderer']['header']")
		nn6usrGtaj2LXy9.append("gg[index2]['itemSectionRenderer']['contents'][0]")
		nn6usrGtaj2LXy9.append("gg[index2]['richSectionRenderer']['content']")
		nn6usrGtaj2LXy9.append("gg[index2]['richItemRenderer']['content']")
		nn6usrGtaj2LXy9.append("gg[index2]['gameCardRenderer']['game']")
		nn6usrGtaj2LXy9.append("gg[index2]")
		F4C8Ul30bkjI,ZA1fBenNahOR3xrkjvwYSVMy6JK5s = KAXcRDaTGCO6(R24eyATUzVEcMFi3SDkWbJjp8a,P5wyN7zRcUEGu9pfmqFHA4djLi,nn6usrGtaj2LXy9)
		l6SBvJFG3aDHre4pjtw5R0NIucY2M(ZA1fBenNahOR3xrkjvwYSVMy6JK5s,url,str(P5wyN7zRcUEGu9pfmqFHA4djLi))
		if F4C8Ul30bkjI=='4':
			try:
				zvwTcYXaE4PR3JkK = ZA1fBenNahOR3xrkjvwYSVMy6JK5s['shelfRenderer']['content']['horizontalMovieListRenderer']['items']
				for KTkINZBXljPYvUOyJhzq3wxe4 in range(len(zvwTcYXaE4PR3JkK)):
					uUWolxErnhD7zF1I5KB28gis = zvwTcYXaE4PR3JkK[KTkINZBXljPYvUOyJhzq3wxe4]
					l6SBvJFG3aDHre4pjtw5R0NIucY2M(uUWolxErnhD7zF1I5KB28gis)
			except: pass
	LrPu5D8XJ1FpxhYvyz2l = False
	if 'view=' not in url and jXWywcUh4vLRBr1bFi7YnTxNJ=='8': LrPu5D8XJ1FpxhYvyz2l = True
	if ':::' in toAVQS46Fv8aJYyLf25KnkUNC: NoHlnSQv1q,key,dxSyp5QX1TIHE9ZYN,nyPa0pmt8kslDb6MoQSUZdzu5Oqf,Ujugy9ASbcRxaVeCKJ,h13lHnQYWrbZvij6akCPoIf0M8dJ = toAVQS46Fv8aJYyLf25KnkUNC.split(':::')
	else: NoHlnSQv1q,key,dxSyp5QX1TIHE9ZYN,nyPa0pmt8kslDb6MoQSUZdzu5Oqf,Ujugy9ASbcRxaVeCKJ,h13lHnQYWrbZvij6akCPoIf0M8dJ = '','','','','',''
	bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,c8xyLVFa6uoi = '',''
	if xx4viQhaOu6r0:
		r8iw2a4ZfWkVDENoOK5p6JUYbxd0vH = str(xx4viQhaOu6r0[-1][1])
		if   teUPLFC3B8bArakwHVGsdhoIWDM49f+'CHNL' in r8iw2a4ZfWkVDENoOK5p6JUYbxd0vH: c8xyLVFa6uoi = 'CHANNELS'
		elif teUPLFC3B8bArakwHVGsdhoIWDM49f+'USER' in r8iw2a4ZfWkVDENoOK5p6JUYbxd0vH: c8xyLVFa6uoi = 'CHANNELS'
		elif teUPLFC3B8bArakwHVGsdhoIWDM49f+'LIST' in r8iw2a4ZfWkVDENoOK5p6JUYbxd0vH: c8xyLVFa6uoi = 'PLAYLISTS'
	if '"continuations"' in MK6ZT2zjC1SbmveNFqor and '&list=' not in url and not LrPu5D8XJ1FpxhYvyz2l and 'shelf_id' not in url:
		bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = EZxQp1WOldMTvFU+'/browse_ajax?ctoken='+dxSyp5QX1TIHE9ZYN
	elif '"token"' in MK6ZT2zjC1SbmveNFqor and 'bp=' not in url and 'search_query' in url or 'search?key=' in url:
		bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = EZxQp1WOldMTvFU+'/youtubei/v1/search?key='+key
	elif '"token"' in MK6ZT2zjC1SbmveNFqor and 'bp=' not in url:
		bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = EZxQp1WOldMTvFU+'/youtubei/v1/browse?key='+key
	if bJEs4IVAPdyUrhwCLv9k2YoOl8nt1: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'صفحة أخرى',bJEs4IVAPdyUrhwCLv9k2YoOl8nt1,144,c8xyLVFa6uoi,'',toAVQS46Fv8aJYyLf25KnkUNC)
	return
def KAXcRDaTGCO6(Iwh7pS4CTEjZeO,pzYNuWHETc9orAef1BLmShsGRIw,exHwypJaVFlc57jCPvLWIzA0XOB6M):
	CCJpwYUsTN1cBIz5PH = Iwh7pS4CTEjZeO
	Xef5VkCIWcu2rzpldg4iF,index = Iwh7pS4CTEjZeO,pzYNuWHETc9orAef1BLmShsGRIw
	R24eyATUzVEcMFi3SDkWbJjp8a,P5wyN7zRcUEGu9pfmqFHA4djLi = Iwh7pS4CTEjZeO,pzYNuWHETc9orAef1BLmShsGRIw
	ZA1fBenNahOR3xrkjvwYSVMy6JK5s,CuO4JzSiARQGbxUcdrYMnl5IX = Iwh7pS4CTEjZeO,pzYNuWHETc9orAef1BLmShsGRIw
	count = len(exHwypJaVFlc57jCPvLWIzA0XOB6M)
	for k3Om08MCgqQao4n1 in range(count):
		try:
			rUaDMe3xuwbk1pAzZf45Ig7GnRXojB = eval(exHwypJaVFlc57jCPvLWIzA0XOB6M[k3Om08MCgqQao4n1])
			return str(k3Om08MCgqQao4n1+1),rUaDMe3xuwbk1pAzZf45Ig7GnRXojB
		except: pass
	return '',''
def JQvSljwGLBIuADxCkomKc3RN5gs(ZA1fBenNahOR3xrkjvwYSVMy6JK5s):
	try: GSF2AQUXlc = list(ZA1fBenNahOR3xrkjvwYSVMy6JK5s.keys())[0]
	except: return False,'','','','','','',''
	a5MrRBdG4wpAYmej0ZgUyh,title,BoEFz2WhUyvTgDeiZ,IcWzVO137wFvemn2QTq8yKs9,count,LEb1HQDAeFdsrNTnVgmXo9,eBQoDdKfNvnzm73GgYjAPJR,wnpe16R7MuEO0C = False,'','','','','','',''
	CuO4JzSiARQGbxUcdrYMnl5IX = ZA1fBenNahOR3xrkjvwYSVMy6JK5s[GSF2AQUXlc]
	nn6usrGtaj2LXy9 = []
	nn6usrGtaj2LXy9.append("render['unplayableText']['simpleText']")
	nn6usrGtaj2LXy9.append("render['formattedTitle']['simpleText']")
	nn6usrGtaj2LXy9.append("render['title']['simpleText']")
	nn6usrGtaj2LXy9.append("render['title']['runs'][0]['text']")
	nn6usrGtaj2LXy9.append("render['text']['simpleText']")
	nn6usrGtaj2LXy9.append("render['text']['runs'][0]['text']")
	nn6usrGtaj2LXy9.append("render['title']")
	nn6usrGtaj2LXy9.append("item['title']")
	F4C8Ul30bkjI,title = KAXcRDaTGCO6(ZA1fBenNahOR3xrkjvwYSVMy6JK5s,CuO4JzSiARQGbxUcdrYMnl5IX,nn6usrGtaj2LXy9)
	nn6usrGtaj2LXy9 = []
	nn6usrGtaj2LXy9.append("render['title']['runs'][0]['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	nn6usrGtaj2LXy9.append("render['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	nn6usrGtaj2LXy9.append("render['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	nn6usrGtaj2LXy9.append("item['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	F4C8Ul30bkjI,BoEFz2WhUyvTgDeiZ = KAXcRDaTGCO6(ZA1fBenNahOR3xrkjvwYSVMy6JK5s,CuO4JzSiARQGbxUcdrYMnl5IX,nn6usrGtaj2LXy9)
	nn6usrGtaj2LXy9 = []
	nn6usrGtaj2LXy9.append("render['thumbnail']['thumbnails'][0]['url']")
	nn6usrGtaj2LXy9.append("render['thumbnails'][0]['thumbnails'][0]['url']")
	F4C8Ul30bkjI,IcWzVO137wFvemn2QTq8yKs9 = KAXcRDaTGCO6(ZA1fBenNahOR3xrkjvwYSVMy6JK5s,CuO4JzSiARQGbxUcdrYMnl5IX,nn6usrGtaj2LXy9)
	nn6usrGtaj2LXy9 = []
	nn6usrGtaj2LXy9.append("render['videoCount']")
	nn6usrGtaj2LXy9.append("render['videoCountText']['runs'][0]['text']")
	nn6usrGtaj2LXy9.append("render['thumbnailOverlays'][0]['thumbnailOverlayBottomPanelRenderer']['text']['runs'][0]['text']")
	F4C8Ul30bkjI,count = KAXcRDaTGCO6(ZA1fBenNahOR3xrkjvwYSVMy6JK5s,CuO4JzSiARQGbxUcdrYMnl5IX,nn6usrGtaj2LXy9)
	nn6usrGtaj2LXy9 = []
	nn6usrGtaj2LXy9.append("render['lengthText']['simpleText']")
	nn6usrGtaj2LXy9.append("render['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['simpleText']")
	nn6usrGtaj2LXy9.append("render['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['runs'][0]['text']")
	F4C8Ul30bkjI,LEb1HQDAeFdsrNTnVgmXo9 = KAXcRDaTGCO6(ZA1fBenNahOR3xrkjvwYSVMy6JK5s,CuO4JzSiARQGbxUcdrYMnl5IX,nn6usrGtaj2LXy9)
	if 'LIVE' in LEb1HQDAeFdsrNTnVgmXo9: LEb1HQDAeFdsrNTnVgmXo9,eBQoDdKfNvnzm73GgYjAPJR = '','LIVE:  '
	if 'مباشر' in LEb1HQDAeFdsrNTnVgmXo9: LEb1HQDAeFdsrNTnVgmXo9,eBQoDdKfNvnzm73GgYjAPJR = '','LIVE:  '
	if 'badges' in list(CuO4JzSiARQGbxUcdrYMnl5IX.keys()):
		vpjoYRLzVE0FH6x43a8 = str(CuO4JzSiARQGbxUcdrYMnl5IX['badges'])
		if 'Free with Ads' in vpjoYRLzVE0FH6x43a8: wnpe16R7MuEO0C = '$:'
		if 'LIVE NOW' in vpjoYRLzVE0FH6x43a8: eBQoDdKfNvnzm73GgYjAPJR = 'LIVE:  '
		if 'Buy' in vpjoYRLzVE0FH6x43a8 or 'Rent' in vpjoYRLzVE0FH6x43a8: wnpe16R7MuEO0C = '$$:'
		if gEYUZMaD6vB(u'مباشر') in vpjoYRLzVE0FH6x43a8: eBQoDdKfNvnzm73GgYjAPJR = 'LIVE:  '
		if gEYUZMaD6vB(u'شراء') in vpjoYRLzVE0FH6x43a8: wnpe16R7MuEO0C = '$$:'
		if gEYUZMaD6vB(u'استئجار') in vpjoYRLzVE0FH6x43a8: wnpe16R7MuEO0C = '$$:'
		if gEYUZMaD6vB(u'إعلانات') in vpjoYRLzVE0FH6x43a8: wnpe16R7MuEO0C = '$:'
	BoEFz2WhUyvTgDeiZ = tW06wVMpReHfnj3KgzT2va(BoEFz2WhUyvTgDeiZ)
	if BoEFz2WhUyvTgDeiZ and 'http' not in BoEFz2WhUyvTgDeiZ: BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU+BoEFz2WhUyvTgDeiZ
	IcWzVO137wFvemn2QTq8yKs9 = IcWzVO137wFvemn2QTq8yKs9.split('?')[0]
	if  IcWzVO137wFvemn2QTq8yKs9 and 'http' not in IcWzVO137wFvemn2QTq8yKs9: IcWzVO137wFvemn2QTq8yKs9 = 'https:'+IcWzVO137wFvemn2QTq8yKs9
	title = tW06wVMpReHfnj3KgzT2va(title)
	if wnpe16R7MuEO0C: title = wnpe16R7MuEO0C+'  '+title
	LEb1HQDAeFdsrNTnVgmXo9 = LEb1HQDAeFdsrNTnVgmXo9.replace(',','')
	count = count.replace(',','')
	count = My7Dwqvs6bfGNSIgX.findall('\d+',count)
	if count: count = count[0]
	else: count = ''
	return True,title,BoEFz2WhUyvTgDeiZ,IcWzVO137wFvemn2QTq8yKs9,count,LEb1HQDAeFdsrNTnVgmXo9,eBQoDdKfNvnzm73GgYjAPJR,wnpe16R7MuEO0C
def l6SBvJFG3aDHre4pjtw5R0NIucY2M(ZA1fBenNahOR3xrkjvwYSVMy6JK5s,url='',index=''):
	a5MrRBdG4wpAYmej0ZgUyh,title,BoEFz2WhUyvTgDeiZ,IcWzVO137wFvemn2QTq8yKs9,count,LEb1HQDAeFdsrNTnVgmXo9,eBQoDdKfNvnzm73GgYjAPJR,wnpe16R7MuEO0C = JQvSljwGLBIuADxCkomKc3RN5gs(ZA1fBenNahOR3xrkjvwYSVMy6JK5s)
	if not a5MrRBdG4wpAYmej0ZgUyh: return
	elif 'continuationItemRenderer' in str(ZA1fBenNahOR3xrkjvwYSVMy6JK5s): return
	elif 'searchPyvRenderer' in str(ZA1fBenNahOR3xrkjvwYSVMy6JK5s): return
	elif not BoEFz2WhUyvTgDeiZ and 'search_query' in url: return
	elif title and not BoEFz2WhUyvTgDeiZ and ('search_query' in url or 'horizontalMovieListRenderer' in str(ZA1fBenNahOR3xrkjvwYSVMy6JK5s) or url==EZxQp1WOldMTvFU):
		title = '=== '+title+' ==='
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,'',9999)
	elif title and 'messageRenderer' in str(ZA1fBenNahOR3xrkjvwYSVMy6JK5s):
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('link',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,'',9999)
	elif '/feed/trending' in BoEFz2WhUyvTgDeiZ: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,144,IcWzVO137wFvemn2QTq8yKs9,index)
	elif not title: return
	elif eBQoDdKfNvnzm73GgYjAPJR: VQhpA0sF5GbRSZyEBrzkoJ68HWLX('live',teUPLFC3B8bArakwHVGsdhoIWDM49f+eBQoDdKfNvnzm73GgYjAPJR+title,BoEFz2WhUyvTgDeiZ,143,IcWzVO137wFvemn2QTq8yKs9)
	elif 'watch?v=' in BoEFz2WhUyvTgDeiZ or '/shorts/' in BoEFz2WhUyvTgDeiZ:
		if '&list=' in BoEFz2WhUyvTgDeiZ and 'index=' not in BoEFz2WhUyvTgDeiZ:
			ww3OaG7qJCgHT8L6y = BoEFz2WhUyvTgDeiZ.split('&list=',1)[1]
			BoEFz2WhUyvTgDeiZ = EZxQp1WOldMTvFU+'/playlist?list='+ww3OaG7qJCgHT8L6y
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+'LIST'+count+':  '+title,BoEFz2WhUyvTgDeiZ,144,IcWzVO137wFvemn2QTq8yKs9)
		else:
			BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ.split('&list=',1)[0]
			VQhpA0sF5GbRSZyEBrzkoJ68HWLX('video',teUPLFC3B8bArakwHVGsdhoIWDM49f+title,BoEFz2WhUyvTgDeiZ,143,IcWzVO137wFvemn2QTq8yKs9,LEb1HQDAeFdsrNTnVgmXo9)
	else:
		type = ''
		if not BoEFz2WhUyvTgDeiZ: BoEFz2WhUyvTgDeiZ = url
		elif not any(WoFrX46wzbCNp18 in BoEFz2WhUyvTgDeiZ for WoFrX46wzbCNp18 in ['/videos','/playlists','/channels','/featured','ss=','bp=']):
			if '/channel/'	in BoEFz2WhUyvTgDeiZ or '/c/' in BoEFz2WhUyvTgDeiZ: type = 'CHNL'+count+':  '
			if '/user/' in BoEFz2WhUyvTgDeiZ: type = 'USER'+count+':  '
			index,JJFmwDZsKkEfXyIBihr67U1YVRco9G = '',''
		VQhpA0sF5GbRSZyEBrzkoJ68HWLX('folder',teUPLFC3B8bArakwHVGsdhoIWDM49f+type+title,BoEFz2WhUyvTgDeiZ,144,IcWzVO137wFvemn2QTq8yKs9,index)
	return
def ppUnVZPokRe5cA7(url,data='',h5QaxwPF7SOu6fMBTGXRU2yn=''):
	global bLEBi8IO7uU2x3htYDdVq95
	if not data: data = bLEBi8IO7uU2x3htYDdVq95.getSetting('av.youtube.data')
	if h5QaxwPF7SOu6fMBTGXRU2yn=='': h5QaxwPF7SOu6fMBTGXRU2yn = 'ytInitialData'
	rHqkc3e0CJ5VByi6vLs = IeSGolOpBHM8U62m()
	eIL9BxdTbZj = {'User-Agent':rHqkc3e0CJ5VByi6vLs,'Cookie':'PREF=hl=ar'}
	if ':::' in data: NoHlnSQv1q,key,dxSyp5QX1TIHE9ZYN,nyPa0pmt8kslDb6MoQSUZdzu5Oqf,Ujugy9ASbcRxaVeCKJ,h13lHnQYWrbZvij6akCPoIf0M8dJ = data.split(':::')
	else: NoHlnSQv1q,key,dxSyp5QX1TIHE9ZYN,nyPa0pmt8kslDb6MoQSUZdzu5Oqf,Ujugy9ASbcRxaVeCKJ,h13lHnQYWrbZvij6akCPoIf0M8dJ = '','','','','',''
	if 'guide?key=' in url:
		toAVQS46Fv8aJYyLf25KnkUNC = {}
		toAVQS46Fv8aJYyLf25KnkUNC['context'] = {"client":{"hl":"ar","clientName":"WEB","clientVersion":nyPa0pmt8kslDb6MoQSUZdzu5Oqf}}
		toAVQS46Fv8aJYyLf25KnkUNC = str(toAVQS46Fv8aJYyLf25KnkUNC)
		xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(f9Oum6c0FotxYn,'POST',url,toAVQS46Fv8aJYyLf25KnkUNC,eIL9BxdTbZj,True,True,'YOUTUBE-GET_PAGE_DATA-1st')
	elif 'key=' in url and NoHlnSQv1q:
		toAVQS46Fv8aJYyLf25KnkUNC = {'continuation':Ujugy9ASbcRxaVeCKJ}
		toAVQS46Fv8aJYyLf25KnkUNC['context'] = {"client":{"visitorData":NoHlnSQv1q,"clientName":"WEB","clientVersion":nyPa0pmt8kslDb6MoQSUZdzu5Oqf}}
		toAVQS46Fv8aJYyLf25KnkUNC = str(toAVQS46Fv8aJYyLf25KnkUNC)
		xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(f9Oum6c0FotxYn,'POST',url,toAVQS46Fv8aJYyLf25KnkUNC,eIL9BxdTbZj,True,True,'YOUTUBE-GET_PAGE_DATA-2nd')
	elif 'ctoken=' in url and h13lHnQYWrbZvij6akCPoIf0M8dJ:
		eIL9BxdTbZj.update({'X-YouTube-Client-Name':'1','X-YouTube-Client-Version':nyPa0pmt8kslDb6MoQSUZdzu5Oqf})
		eIL9BxdTbZj.update({'Cookie':'VISITOR_INFO1_LIVE='+h13lHnQYWrbZvij6akCPoIf0M8dJ})
		xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(f9Oum6c0FotxYn,'GET',url,'',eIL9BxdTbZj,'','','YOUTUBE-GET_PAGE_DATA-3rd')
	else:
		xHb86g9WZqPwRfVjXD2JalzSIp = mORwgTnXBdQ7iCSHKf(f9Oum6c0FotxYn,'GET',url,'',eIL9BxdTbZj,'','','YOUTUBE-GET_PAGE_DATA-4th')
	MK6ZT2zjC1SbmveNFqor = xHb86g9WZqPwRfVjXD2JalzSIp.content
	kcGf0WYwFujE9QN6zHTi = My7Dwqvs6bfGNSIgX.findall('"innertubeApiKey".*?"(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL|My7Dwqvs6bfGNSIgX.I)
	if kcGf0WYwFujE9QN6zHTi: key = kcGf0WYwFujE9QN6zHTi[0]
	kcGf0WYwFujE9QN6zHTi = My7Dwqvs6bfGNSIgX.findall('"cver".*?"value".*?"(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL|My7Dwqvs6bfGNSIgX.I)
	if kcGf0WYwFujE9QN6zHTi: nyPa0pmt8kslDb6MoQSUZdzu5Oqf = kcGf0WYwFujE9QN6zHTi[0]
	kcGf0WYwFujE9QN6zHTi = My7Dwqvs6bfGNSIgX.findall('"token".*?"(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL|My7Dwqvs6bfGNSIgX.I)
	if kcGf0WYwFujE9QN6zHTi: Ujugy9ASbcRxaVeCKJ = kcGf0WYwFujE9QN6zHTi[0]
	kcGf0WYwFujE9QN6zHTi = My7Dwqvs6bfGNSIgX.findall('"visitorData".*?"(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL|My7Dwqvs6bfGNSIgX.I)
	if kcGf0WYwFujE9QN6zHTi: NoHlnSQv1q = kcGf0WYwFujE9QN6zHTi[0]
	kcGf0WYwFujE9QN6zHTi = My7Dwqvs6bfGNSIgX.findall('"continuation".*?"(.*?)"',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL|My7Dwqvs6bfGNSIgX.I)
	if kcGf0WYwFujE9QN6zHTi: dxSyp5QX1TIHE9ZYN = kcGf0WYwFujE9QN6zHTi[0]
	cookies = xHb86g9WZqPwRfVjXD2JalzSIp.cookies
	if 'VISITOR_INFO1_LIVE' in list(cookies.keys()): h13lHnQYWrbZvij6akCPoIf0M8dJ = cookies['VISITOR_INFO1_LIVE']
	data = NoHlnSQv1q+':::'+key+':::'+dxSyp5QX1TIHE9ZYN+':::'+nyPa0pmt8kslDb6MoQSUZdzu5Oqf+':::'+Ujugy9ASbcRxaVeCKJ+':::'+h13lHnQYWrbZvij6akCPoIf0M8dJ
	if h5QaxwPF7SOu6fMBTGXRU2yn=='ytInitialData' and 'ytInitialData' in MK6ZT2zjC1SbmveNFqor:
		qKeCANPab2LFMRxdlJg4OSBircopZ = My7Dwqvs6bfGNSIgX.findall('window\["ytInitialData"\] = ({.*?});',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		if not qKeCANPab2LFMRxdlJg4OSBircopZ: qKeCANPab2LFMRxdlJg4OSBircopZ = My7Dwqvs6bfGNSIgX.findall('var ytInitialData = ({.*?});',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		gTzA63iMfhc7lerFGkZ = dWsa2A0O4o5BYiqGXhyKEbM('str',qKeCANPab2LFMRxdlJg4OSBircopZ[0])
	elif h5QaxwPF7SOu6fMBTGXRU2yn=='ytInitialGuideData' and 'ytInitialGuideData' in MK6ZT2zjC1SbmveNFqor:
		qKeCANPab2LFMRxdlJg4OSBircopZ = My7Dwqvs6bfGNSIgX.findall('var ytInitialGuideData = ({.*?});',MK6ZT2zjC1SbmveNFqor,My7Dwqvs6bfGNSIgX.DOTALL)
		gTzA63iMfhc7lerFGkZ = dWsa2A0O4o5BYiqGXhyKEbM('str',qKeCANPab2LFMRxdlJg4OSBircopZ[0])
	elif '</script>' not in MK6ZT2zjC1SbmveNFqor: gTzA63iMfhc7lerFGkZ = dWsa2A0O4o5BYiqGXhyKEbM('str',MK6ZT2zjC1SbmveNFqor)
	else: gTzA63iMfhc7lerFGkZ = ''
	bLEBi8IO7uU2x3htYDdVq95.setSetting('av.youtube.data',data)
	return MK6ZT2zjC1SbmveNFqor,gTzA63iMfhc7lerFGkZ,data
def iuAoJsgSL0XVRzqalHWtFMhOIG(url):
	search = ViKAIsLurq83RSENayxWb()
	if not search: return
	search = search.replace(' ','+')
	bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = url+'/search?query='+search
	TJZvpKG2we(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1)
	return
def HjZcUIVAXFCqy9TfBWKtgY2(search):
	search,LQf3AeozSrai,showDialogs = X54MLovbG8nAEkB9J(search)
	if not search:
		search = ViKAIsLurq83RSENayxWb()
		if not search: return
	search = search.replace(' ','+')
	bJEs4IVAPdyUrhwCLv9k2YoOl8nt1 = EZxQp1WOldMTvFU+'/results?search_query='+search
	if not showDialogs:
		if '_YOUTUBE-VIDEOS_' in LQf3AeozSrai: YG52KvqnRAje70VB6FHy = '&sp=EgIQAQ%253D%253D'
		elif '_YOUTUBE-PLAYLISTS_' in LQf3AeozSrai: YG52KvqnRAje70VB6FHy = '&sp=EgIQAw%253D%253D'
		elif '_YOUTUBE-CHANNELS_' in LQf3AeozSrai: YG52KvqnRAje70VB6FHy = '&sp=EgIQAg%253D%253D'
		QAKdHzO0rehbtyIc = bJEs4IVAPdyUrhwCLv9k2YoOl8nt1+YG52KvqnRAje70VB6FHy
	else:
		swi31aSpUhu8BnyqHzA,VLUFypBuGD,U2UaTcgBpsEZxKiRG1Xv8 = [],[],''
		QJHxig8uj359LO = ['بدون ترتيب','ترتيب حسب مدى الصلة','ترتيب حسب تاريخ التحميل','ترتيب حسب عدد المشاهدات','ترتيب حسب التقييم']
		fuzLxYPMWc = ['','&sp=CAA%253D','&sp=CAI%253D','&sp=CAM%253D','&sp=CAE%253D']
		ppCbDLftGS5d9UjY = CnKwdteDG5BE8MTRhUpYIJm3NLrSgq('موقع يوتيوب - اختر الترتيب',QJHxig8uj359LO)
		if ppCbDLftGS5d9UjY == -1: return
		WuB7DsHA45cCMURlgqVKj8NnYdZIQ = fuzLxYPMWc[ppCbDLftGS5d9UjY]
		MK6ZT2zjC1SbmveNFqor,qfFZ5QSOedhUiK46N,data = ppUnVZPokRe5cA7(bJEs4IVAPdyUrhwCLv9k2YoOl8nt1+WuB7DsHA45cCMURlgqVKj8NnYdZIQ)
		if qfFZ5QSOedhUiK46N:
			DtzW0B4cmRrL17ue2CpS9xIKhVU = qfFZ5QSOedhUiK46N['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['subMenu']['searchSubMenuRenderer']['groups']
			for ZdOyVpHDs2IAlbT0Ntkzaq4PLGm in range(len(DtzW0B4cmRrL17ue2CpS9xIKhVU)):
				group = DtzW0B4cmRrL17ue2CpS9xIKhVU[ZdOyVpHDs2IAlbT0Ntkzaq4PLGm]['searchFilterGroupRenderer']['filters']
				for pTsvU85nlcJbzmPNy in range(len(group)):
					CuO4JzSiARQGbxUcdrYMnl5IX = group[pTsvU85nlcJbzmPNy]['searchFilterRenderer']
					if 'navigationEndpoint' in list(CuO4JzSiARQGbxUcdrYMnl5IX.keys()):
						BoEFz2WhUyvTgDeiZ = CuO4JzSiARQGbxUcdrYMnl5IX['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']
						BoEFz2WhUyvTgDeiZ = BoEFz2WhUyvTgDeiZ.replace('\u0026','&')
						title = CuO4JzSiARQGbxUcdrYMnl5IX['tooltip']
						title = title.replace('البحث عن ','')
						if 'إزالة الفلتر' in title: continue
						if 'قائمة تشغيل' in title:
							title = 'جيد للمسلسلات '+title
							U2UaTcgBpsEZxKiRG1Xv8 = title
							bOBQpgMudItXo = BoEFz2WhUyvTgDeiZ
						if 'ترتيب حسب' in title: continue
						title = title.replace('Search for ','')
						if 'Remove' in title: continue
						if 'Playlist' in title:
							title = 'جيد للمسلسلات '+title
							U2UaTcgBpsEZxKiRG1Xv8 = title
							bOBQpgMudItXo = BoEFz2WhUyvTgDeiZ
						if 'Sort by' in title: continue
						swi31aSpUhu8BnyqHzA.append(tW06wVMpReHfnj3KgzT2va(title))
						VLUFypBuGD.append(BoEFz2WhUyvTgDeiZ)
		if not U2UaTcgBpsEZxKiRG1Xv8: SuBdhHj8XfLEkr5pmVCTnwRAZzyPQq = ''
		else:
			swi31aSpUhu8BnyqHzA = ['بدون فلتر',U2UaTcgBpsEZxKiRG1Xv8]+swi31aSpUhu8BnyqHzA
			VLUFypBuGD = ['',bOBQpgMudItXo]+VLUFypBuGD
			fdthjEURqgP836YC59JeOzNlHIw20 = CnKwdteDG5BE8MTRhUpYIJm3NLrSgq('موقع يوتيوب - اختر الفلتر',swi31aSpUhu8BnyqHzA)
			if fdthjEURqgP836YC59JeOzNlHIw20 == -1: return
			SuBdhHj8XfLEkr5pmVCTnwRAZzyPQq = VLUFypBuGD[fdthjEURqgP836YC59JeOzNlHIw20]
		if SuBdhHj8XfLEkr5pmVCTnwRAZzyPQq: QAKdHzO0rehbtyIc = EZxQp1WOldMTvFU+SuBdhHj8XfLEkr5pmVCTnwRAZzyPQq
		elif WuB7DsHA45cCMURlgqVKj8NnYdZIQ: QAKdHzO0rehbtyIc = bJEs4IVAPdyUrhwCLv9k2YoOl8nt1+WuB7DsHA45cCMURlgqVKj8NnYdZIQ
		else: QAKdHzO0rehbtyIc = bJEs4IVAPdyUrhwCLv9k2YoOl8nt1
	TJZvpKG2we(QAKdHzO0rehbtyIc)
	return
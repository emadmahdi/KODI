# -*- coding: utf-8 -*-
import sys as NMY5ULbwaETqKA0DROmj9
m8KE15h0DHd = NMY5ULbwaETqKA0DROmj9.version_info [0] == 2
t1RNJaOCWH5IxuQsLKpjc7XEz = 2048
OqAeWzNpQV8LbdJ3RgyYrHwi7ul = 7
def tTm0ia8Qb2 (oMbwE1Ylx8a6DuO):
	global CPTpZLU8sGyDc6Jf1
	arf8EqiSTNvudj7y = ord (oMbwE1Ylx8a6DuO [-1])
	r4sV17LKPJefkojxgD2 = oMbwE1Ylx8a6DuO [:-1]
	mxHagY81v2X9wPrLzo = arf8EqiSTNvudj7y % len (r4sV17LKPJefkojxgD2)
	ookCZcJLWpOVwfI2nvmBij = r4sV17LKPJefkojxgD2 [:mxHagY81v2X9wPrLzo] + r4sV17LKPJefkojxgD2 [mxHagY81v2X9wPrLzo:]
	if m8KE15h0DHd:
		yOIUBnGzud5c0gpwQjLDRJT = unicode () .join ([unichr (ord (aYvqX0A4spbDoKIOlC) - t1RNJaOCWH5IxuQsLKpjc7XEz - (OiWdCfvPue8gpVRHs + arf8EqiSTNvudj7y) % OqAeWzNpQV8LbdJ3RgyYrHwi7ul) for OiWdCfvPue8gpVRHs, aYvqX0A4spbDoKIOlC in enumerate (ookCZcJLWpOVwfI2nvmBij)])
	else:
		yOIUBnGzud5c0gpwQjLDRJT = str () .join ([chr (ord (aYvqX0A4spbDoKIOlC) - t1RNJaOCWH5IxuQsLKpjc7XEz - (OiWdCfvPue8gpVRHs + arf8EqiSTNvudj7y) % OqAeWzNpQV8LbdJ3RgyYrHwi7ul) for OiWdCfvPue8gpVRHs, aYvqX0A4spbDoKIOlC in enumerate (ookCZcJLWpOVwfI2nvmBij)])
	return eval (yOIUBnGzud5c0gpwQjLDRJT)
RRExPb74MfkvFgnQJjqi,ldwMpSemJOFNfK4zAXQD,hBsqZOS4KeXrWPJ6bo=tTm0ia8Qb2,tTm0ia8Qb2,tTm0ia8Qb2
fkv2TpxiwQ8N,cJ9LCM5NyfRP34mEtzs,CYT70UgEBmdL4ZFx8K=hBsqZOS4KeXrWPJ6bo,ldwMpSemJOFNfK4zAXQD,RRExPb74MfkvFgnQJjqi
xD6t0BKNXf9wjL2byH,kR2pcoit9DLWEGV,AvsERDt7cl2xM4jpKqy=CYT70UgEBmdL4ZFx8K,cJ9LCM5NyfRP34mEtzs,fkv2TpxiwQ8N
Lf36ITD5vkWU9tHCgn,eo7pnXvlUIsO3,TSK0kIafu3MeUqN=AvsERDt7cl2xM4jpKqy,kR2pcoit9DLWEGV,xD6t0BKNXf9wjL2byH
uESVvbkrwyjtinzasYm5FC,vbB3H47silUOn2oTq,bZjRKgUTEt70h=TSK0kIafu3MeUqN,eo7pnXvlUIsO3,Lf36ITD5vkWU9tHCgn
S4LWvwnlb8ay,IfPUeRBishE,fgQC9PGU6vSXszN2hOM3Ayle4=bZjRKgUTEt70h,vbB3H47silUOn2oTq,uESVvbkrwyjtinzasYm5FC
m7olUSiswfHByXECOYWJjzt,dflspC41Io3eMAkDaWJ,thqb7iZ0Vw=fgQC9PGU6vSXszN2hOM3Ayle4,IfPUeRBishE,S4LWvwnlb8ay
RR04cQvUTpItw,t0dvpNCrAR,rrvzVUGAcmxwuybph7=thqb7iZ0Vw,dflspC41Io3eMAkDaWJ,m7olUSiswfHByXECOYWJjzt
vl4AJXVyPYW9hrHua1CNjtpQEbFT,WT5lNHI8KteYsVS2hgwroPfzd74v,sLh2TcUYkv9S=rrvzVUGAcmxwuybph7,t0dvpNCrAR,RR04cQvUTpItw
lXvOLV8cw1,ZZmDIByEh6w,m9guIvfFSk0OjUiM36thpZG=sLh2TcUYkv9S,WT5lNHI8KteYsVS2hgwroPfzd74v,vl4AJXVyPYW9hrHua1CNjtpQEbFT
fxZHJRj6aXgpyC1GKF3bkI4VWsPT2,Ksp9cCGExNaevL71D,VlxX3fWmA0NFy=m9guIvfFSk0OjUiM36thpZG,ZZmDIByEh6w,lXvOLV8cw1
import xbmc as DDrEy89ujmP7gKNpJsVWQvRcA3IoUe,xbmcgui as ttkKp7oAiQC1PqfzcG5rUODbhBgR,sys as NMY5ULbwaETqKA0DROmj9,os as rjYyd7g5LpPqJfR,requests as ybf7KGeLzwR4pQXstT2avAZOlM,re as jjMPIg1cuma4Gf0BxUvCOHLTre,xbmcvfs as XYUNQlv9ABrgW,base64 as UgzAiVqDbEJMxRlHBs,time as TYFEJs3p7L0un
def UaXIwZCMOrD6JNuFcWf(request):
	TUpSPC4I7OZ0VDmthJEbrk56 = WT5lNHI8KteYsVS2hgwroPfzd74v(u"ࠫࡧࡻࡳࡺࡦ࡬ࡥࡱࡵࡧ࡯ࡱࡦࡥࡳࡩࡥ࡭ࠩࠀ")
	if request==WT5lNHI8KteYsVS2hgwroPfzd74v(u"ࠬࡹࡴࡢࡴࡷࠫࠁ"): DDrEy89ujmP7gKNpJsVWQvRcA3IoUe.executebuiltin(RRExPb74MfkvFgnQJjqi(u"࠭ࡁࡤࡶ࡬ࡺࡦࡺࡥࡘ࡫ࡱࡨࡴࡽࠨࠨࠂ")+TUpSPC4I7OZ0VDmthJEbrk56+bZjRKgUTEt70h(u"ࠧࠪࠩࠃ"))
	elif request==fkv2TpxiwQ8N(u"ࠨࡵࡷࡳࡵ࠭ࠄ"): DDrEy89ujmP7gKNpJsVWQvRcA3IoUe.executebuiltin(CYT70UgEBmdL4ZFx8K(u"ࠩࡇ࡭ࡦࡲ࡯ࡨ࠰ࡆࡰࡴࡹࡥࠩࠩࠅ")+TUpSPC4I7OZ0VDmthJEbrk56+eo7pnXvlUIsO3(u"ࠪ࠭ࠬࠆ"))
	return
def oHt1CcET0gMFpeZ(HXTusiJeaj7Mw8vPcx=ldwMpSemJOFNfK4zAXQD(u"้ࠫ๎อสࠢส่๊็วห์ะࠫࠇ"),pWebjPdO3F6UNR2Ss=AvsERDt7cl2xM4jpKqy(u"ࠬ࠭ࠈ")):
	LZS6vmnew9u854hpEf = ttkKp7oAiQC1PqfzcG5rUODbhBgR.Dialog().input(HXTusiJeaj7Mw8vPcx,pWebjPdO3F6UNR2Ss,type=ttkKp7oAiQC1PqfzcG5rUODbhBgR.INPUT_ALPHANUM)
	LZS6vmnew9u854hpEf = LZS6vmnew9u854hpEf.strip(kR2pcoit9DLWEGV(u"࠭ࠠࠨࠉ")).replace(lXvOLV8cw1(u"ࠧࠡࠢࠣࠤࠬࠊ"),Ksp9cCGExNaevL71D(u"ࠨࠢࠪࠋ")).replace(ldwMpSemJOFNfK4zAXQD(u"ࠩࠣࠤࠥ࠭ࠌ"),RRExPb74MfkvFgnQJjqi(u"ࠪࠤࠬࠍ")).replace(RR04cQvUTpItw(u"ࠫࠥࠦࠧࠎ"),eo7pnXvlUIsO3(u"ࠬࠦࠧࠏ"))
	return LZS6vmnew9u854hpEf
def GFSThKmp5iW3XJlCjnE6gf4y(text):
	HXTusiJeaj7Mw8vPcx = hBsqZOS4KeXrWPJ6bo(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩࠐ")
	if FKB0AE4MDXNCwGqnxpzt3yv6breIi: uvwfsLgQJroOU92VYWnhG5 = ttkKp7oAiQC1PqfzcG5rUODbhBgR.Dialog().yesno(HXTusiJeaj7Mw8vPcx,text,RR04cQvUTpItw(u"ࠧࠨࠑ"),WT5lNHI8KteYsVS2hgwroPfzd74v(u"ࠨࠩࠒ"),hBsqZOS4KeXrWPJ6bo(u"ࠩๆ่ฬ࠭ࠓ"),dflspC41Io3eMAkDaWJ(u"๊ࠪ฾๋ࠧࠔ"))
	else: uvwfsLgQJroOU92VYWnhG5 = ttkKp7oAiQC1PqfzcG5rUODbhBgR.Dialog().yesno(HXTusiJeaj7Mw8vPcx,text,fxZHJRj6aXgpyC1GKF3bkI4VWsPT2(u"่๊ࠫวࠨࠕ"),vbB3H47silUOn2oTq(u"ࠬ์ูๆࠩࠖ"))
	return uvwfsLgQJroOU92VYWnhG5
def p49BGXI0Noa8kFy1sQrSfOMgdnPT(IvC4z5JiRu1):
	uvwfsLgQJroOU92VYWnhG5 = GFSThKmp5iW3XJlCjnE6gf4y(RRExPb74MfkvFgnQJjqi(u"࠭โษๆࠣษึูวๅࠢึะ้ࠦวๅลั฻ฬว๋ࠠฮหࠤศ์ࠠหึ฽่ࠥฮั็ษ่ะࠥ฿ๅศัࠣ์ฯ์สูำࠣัฯ๏ࠠหฺ๊ี๊ࠥใࠡษ็ู้อใๅ๋ࠢห้ษฮุษฤࠤ࠳࠴ฺ่ࠠา๋ฬࠦำ๋ไ๋้้่ࠥะ์ࠣฬฯูฬ๋ๆ๋ࠣีํࠠศๆุ่ฬ้ไ๊ࠡส่ศิืศรࠣๅ๏ࠦำอๆࠣห้ษฮุษฤࠤ࠳࠴้ࠠส฼ำ์อࠠใ็ࠣฬสืำศๆࠣืั๊ࠠศๆฦา฼อมࠡๆ็้อืๅอࠢ࠱࠲ࠥํไࠡฬิ๎ิࠦวๅฤ้ࠤสืำศๆࠣืั๊ࠠศๆฦา฼อมࠡว็ํࠥอไๆสิ้ัࠦฟࠢࠩࠗ"))
	if uvwfsLgQJroOU92VYWnhG5==t0dvpNCrAR(u"࠱࢈") and rjYyd7g5LpPqJfR.path.exists(IvC4z5JiRu1):
		message = oHt1CcET0gMFpeZ(RR04cQvUTpItw(u"ࠧฤๅอฬࠥืำศๆอ็ࠥอไห์ࠣฮึ๐ฯࠡวิืฬ๊็ศ่ࠢ฽ูࠥฬๅࠢส่ศิืศรࠪ࠘"))
		UaXIwZCMOrD6JNuFcWf(eo7pnXvlUIsO3(u"ࠨࡵࡷࡥࡷࡺࠧ࠙"))
		DDVQsBUuMX = DDrEy89ujmP7gKNpJsVWQvRcA3IoUe.getInfoLabel(RR04cQvUTpItw(u"ࠩࡖࡽࡸࡺࡥ࡮࠰ࡄࡨࡩࡵ࡮ࡗࡧࡵࡷ࡮ࡵ࡮ࠩࠩࠚ")+fWTicU6stbaCEMB+AvsERDt7cl2xM4jpKqy(u"ࠪ࠭ࠬࠛ"))
		file = open(IvC4z5JiRu1,dflspC41Io3eMAkDaWJ(u"ࠫࡷࡨࠧࠜ"))
		EGZIaf4WHglTetu32SOrv = rjYyd7g5LpPqJfR.path.getsize(IvC4z5JiRu1)
		if EGZIaf4WHglTetu32SOrv>cJ9LCM5NyfRP34mEtzs(u"࠴࠲࠴࠴࠵࠶ࢉ"): file.seek(-cJ9LCM5NyfRP34mEtzs(u"࠴࠲࠴࠴࠵࠶ࢉ"),rjYyd7g5LpPqJfR.SEEK_END)
		data = file.read()
		file.close()
		data = data.decode(Lf36ITD5vkWU9tHCgn(u"ࠬࡻࡴࡧ࠺ࠪࠝ"))
		J1kvoKTU9r5sOn2HF3Mc6 = jjMPIg1cuma4Gf0BxUvCOHLTre.findall(fgQC9PGU6vSXszN2hOM3Ayle4(u"ࠨࠧࡶࡵࡨࡶࡤ࡯ࡤࠨ࠼ࠣࠫ࠭࠴ࠪࡀࠫࠪࠦࠞ"),data,jjMPIg1cuma4Gf0BxUvCOHLTre.DOTALL)
		if not J1kvoKTU9r5sOn2HF3Mc6: J1kvoKTU9r5sOn2HF3Mc6 = jjMPIg1cuma4Gf0BxUvCOHLTre.findall(fkv2TpxiwQ8N(u"ࠢࠨࡷࡶࡩࡷ࠭࠺ࠡࠩࠫ࠲࠯ࡅࠩࠨࠤࠟ"),data,jjMPIg1cuma4Gf0BxUvCOHLTre.DOTALL)
		if not J1kvoKTU9r5sOn2HF3Mc6: J1kvoKTU9r5sOn2HF3Mc6 = jjMPIg1cuma4Gf0BxUvCOHLTre.findall(Lf36ITD5vkWU9tHCgn(u"ࠨ࡞ࡧࡿ࠹ࢃ࠭࡝ࡦࡾ࠸ࢂ࠳࡜ࡥࡽ࠷ࢁ࠲ࡢࡤࡼ࠶ࢀ࠱ࡡࡪࡻ࠵ࡿࠪࠠ"),data,jjMPIg1cuma4Gf0BxUvCOHLTre.DOTALL)
		J1kvoKTU9r5sOn2HF3Mc6 = J1kvoKTU9r5sOn2HF3Mc6[Lf36ITD5vkWU9tHCgn(u"࠲ࢊ")] if J1kvoKTU9r5sOn2HF3Mc6 else fxZHJRj6aXgpyC1GKF3bkI4VWsPT2(u"ࠩ࠳࠴࠵࠶ࠧࠡ")
		J1kvoKTU9r5sOn2HF3Mc6 = J1kvoKTU9r5sOn2HF3Mc6.split(thqb7iZ0Vw(u"ࠪࡠࡳ࠭ࠢ"),TSK0kIafu3MeUqN(u"࠴ࢋ"))[t0dvpNCrAR(u"࠴ࢌ")]
		if FKB0AE4MDXNCwGqnxpzt3yv6breIi: J1kvoKTU9r5sOn2HF3Mc6 = J1kvoKTU9r5sOn2HF3Mc6.encode(vl4AJXVyPYW9hrHua1CNjtpQEbFT(u"ࠫࡺࡺࡦ࠹ࠩࠣ"))
		ZZcQEt6mYK528AdlFzyNniRPSCGJL = kR2pcoit9DLWEGV(u"ࠬࡇࡖ࠻ࠢࠪࠤ")+J1kvoKTU9r5sOn2HF3Mc6+lXvOLV8cw1(u"࠭࠭ࡆ࡯ࡨࡶ࡬࡫࡮ࡤࡻࠪࠥ")
		message += hBsqZOS4KeXrWPJ6bo(u"ࠧ࡝ࡰ࡟ࡲࡂࡃ࠽࠾ࠢࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡡࡴࡅ࡮ࡣ࡬ࡰ࡙ࠥࡥ࡯ࡦࡨࡶ࠿ࠦࠧࠦ")+J1kvoKTU9r5sOn2HF3Mc6+hBsqZOS4KeXrWPJ6bo(u"ࠨࠢ࠽ࠫࠧ")+lXvOLV8cw1(u"ࠩ࡟ࡲࠬࠨ")+cJ9LCM5NyfRP34mEtzs(u"ࠪࡅࡩࡪ࡯࡯࡙ࠢࡩࡷࡹࡩࡰࡰ࠽ࠤࠬࠩ")+DDVQsBUuMX+fgQC9PGU6vSXszN2hOM3Ayle4(u"ࠫࠥࡀ࡜࡯ࠩࠪ")
		data = data.encode(S4LWvwnlb8ay(u"ࠬࡻࡴࡧ࠺ࠪࠫ"))
		duXCWrLcijzvt4OsbxYe2mB = UgzAiVqDbEJMxRlHBs.b64encode(data)
		O6kXg4rpunY3yxCJFtMeW5smzSU = {VlxX3fWmA0NFy(u"࠭ࡳࡶࡤ࡭ࡩࡨࡺࠧࠬ"):ZZcQEt6mYK528AdlFzyNniRPSCGJL,CYT70UgEBmdL4ZFx8K(u"ࠧ࡮ࡧࡶࡷࡦ࡭ࡥࠨ࠭"):message,dflspC41Io3eMAkDaWJ(u"ࠨ࡮ࡲ࡫࡫࡯࡬ࡦࠩ࠮"):duXCWrLcijzvt4OsbxYe2mB}
		xpw5liVAeOGuRf14tW = Ksp9cCGExNaevL71D(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡼࡥࡳࡥࡨࡰ࠳ࡧࡰࡱ࠱ࡶࡩࡳࡪࡥ࡮ࡣ࡬ࡰࠬ࠯")
		GG8qLjoKNnVMrgxai4UueDC1Am = ybf7KGeLzwR4pQXstT2avAZOlM.request(RR04cQvUTpItw(u"ࠪࡔࡔ࡙ࡔࠨ࠰"),xpw5liVAeOGuRf14tW,data=O6kXg4rpunY3yxCJFtMeW5smzSU)
		UaXIwZCMOrD6JNuFcWf(TSK0kIafu3MeUqN(u"ࠫࡸࡺ࡯ࡱࠩ࠱"))
		if GG8qLjoKNnVMrgxai4UueDC1Am.status_code==S4LWvwnlb8ay(u"࠷࠶࠰ࢍ"): ttkKp7oAiQC1PqfzcG5rUODbhBgR.Dialog().ok(AvsERDt7cl2xM4jpKqy(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ࠲"),lXvOLV8cw1(u"࠭ฬ๋ัࠣ࠲࠳ࠦๆอฯอࠤ฾๋ไ๋หࠣษึูวๅࠢึะ้ࠦวๅลั฻ฬวࠧ࠳"))
		else: ttkKp7oAiQC1PqfzcG5rUODbhBgR.Dialog().ok(Ksp9cCGExNaevL71D(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ࠴"),CYT70UgEBmdL4ZFx8K(u"ࠨๆ็วุ็ࠠ࠯࠰ࠣๅู๊สࠡ฻่่๏ฯࠠฦำึห้ࠦำอๆࠣห้ษฮุษฤࠫ࠵"))
	return
def UU9AsLMSnNJ7acqiWk1fu3xFzgTPO():
	uvwfsLgQJroOU92VYWnhG5 = GFSThKmp5iW3XJlCjnE6gf4y(kR2pcoit9DLWEGV(u"่่ࠩๆࠦลฺัสำฬะࠠศๆหี๋อๅอࠢํัฯ๎๊ࠡ฻็ํู๋ࠥๅ๊่หฯࠦสฯืࠣฮาี๊ฬࠢส่อืๆศ็ฯࠤํะๆู์่ࠤ฾๋ไࠡษ็ฬึ์วๆฮࠣ࠲࠳ูࠦ็ัุ้ࠣำ่ࠠาสࠤฬ๊ๅๅใࠣื๏่่ๆࠢส่อืๆศ็ฯࠤอิไใ่่ࠢๆࠦฬะ์าࠤๆอั฻ࠢ࠱࠲ࠥํไࠡฬิ๎ิࠦวๅฤ้ࠤู๊อࠡ็็ๅࠥหูะษาหฯࠦวๅสิ๊ฬ๋ฬࠡมࠤࠫ࠶"))
	if uvwfsLgQJroOU92VYWnhG5==RRExPb74MfkvFgnQJjqi(u"࠷ࢎ"):
		wbOMKdQVf2P4hqRk6UpJn8 = lXvOLV8cw1(u"ࡖࡵࡹࡪ࢟")
		BC3LwVelRp = rjYyd7g5LpPqJfR.path.join(weGX9zCqsKBa,RR04cQvUTpItw(u"ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬ࠷"),vbB3H47silUOn2oTq(u"ࠫࡦࡪࡤࡰࡰࡢࡨࡦࡺࡡࠨ࠸"),fWTicU6stbaCEMB)
		ZWwYu739Pp0GNbJqVHOr1iC5 = rjYyd7g5LpPqJfR.path.join(BC3LwVelRp,AvsERDt7cl2xM4jpKqy(u"ࠬࡹࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡹ࡯࡯ࠫ࠹"))
		if rjYyd7g5LpPqJfR.path.exists(ZWwYu739Pp0GNbJqVHOr1iC5):
			try: rjYyd7g5LpPqJfR.remove(ZWwYu739Pp0GNbJqVHOr1iC5)
			except Exception as bYsHJR4G3rSfVKTXAycDit: wbOMKdQVf2P4hqRk6UpJn8 = vbB3H47silUOn2oTq(u"ࡉࡥࡱࡹࡥࢠ")
		if wbOMKdQVf2P4hqRk6UpJn8: ttkKp7oAiQC1PqfzcG5rUODbhBgR.Dialog().ok(VlxX3fWmA0NFy(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ࠺"),ZZmDIByEh6w(u"ࠧอ์าࠤ࠳࠴ࠠ็ฮะฮࠥ฿ๅๅ์ฬࠤู๊อࠡษ็้้็ࠧ࠻"))
		else: ttkKp7oAiQC1PqfzcG5rUODbhBgR.Dialog().ok(rrvzVUGAcmxwuybph7(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ࠼"),Ksp9cCGExNaevL71D(u"ࠩ็่ศูแࠡ࠰࠱ࠤๆฺไหࠢ฼้้๐ษࠡ็ึัࠥอไๆๆไࠫ࠽"))
	return
def bGnw32z58fQcs():
	uvwfsLgQJroOU92VYWnhG5 = GFSThKmp5iW3XJlCjnE6gf4y(RRExPb74MfkvFgnQJjqi(u"้ࠪั๊ฯࠡๅสุࠥอไษำ้ห๊า๋ࠠฯอ์๏ูࠦๅ๋้้ࠣ็วหࠢอาฺࠦส็ฺํ้ࠥ฿ๅๅࠢส่อืๆศ็ฯࠤ๊ัไࠡ็็ๅฬะࠠศๆ่ๅ฻๊ษ๊่่ࠡๆอสࠡࡋࡓࡘ่࡛ࠦࠡࡏ࠶࡙ࠥ๎ี้ำࠣห้่่ศศ่ࠤ࠳࠴ฺ่ࠠาࠤู๊อ้ࠡำหࠥอไๆฮ็ำู๊ࠥใ๊่ࠤฬ๊ศา่ส้ัࠦศฯๆๅࠤ๊าไะࠢฯำ๏ีࠠโษิ฾ࠥ࠴࠮้ࠡ็ࠤฯื๊ะࠢส่ว์ࠠๆีะࠤ๊าไะࠢๆหูࠦวๅสิ๊ฬ๋ฬࠡมࠤࠫ࠾"))
	if uvwfsLgQJroOU92VYWnhG5==uESVvbkrwyjtinzasYm5FC(u"࠱࢏"):
		if WW4dHKYOuI2k3MbpJ5RcDr6za1mlG: OaUVDy8buA = XYUNQlv9ABrgW.translatePath(RRExPb74MfkvFgnQJjqi(u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯ࡵࡧࡰࡴࠬ࠿"))
		else: OaUVDy8buA = DDrEy89ujmP7gKNpJsVWQvRcA3IoUe.translatePath(CYT70UgEBmdL4ZFx8K(u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰ࡶࡨࡱࡵ࠭ࡀ"))
		k0Kl3WfovtZHSImdjrOQCEGa = rjYyd7g5LpPqJfR.path.join(OaUVDy8buA,fWTicU6stbaCEMB)
		wbOMKdQVf2P4hqRk6UpJn8 = vl4AJXVyPYW9hrHua1CNjtpQEbFT(u"ࡘࡷࡻࡥࢡ")
		if rjYyd7g5LpPqJfR.path.exists(k0Kl3WfovtZHSImdjrOQCEGa):
			for fL1FAtaCuhoPNTc8MK,mmnqaQeTxyjzKGL4EHlfoWUCuVd,Va8yGKgbPuj7DmecIFsTv1 in rjYyd7g5LpPqJfR.walk(k0Kl3WfovtZHSImdjrOQCEGa,topdown=thqb7iZ0Vw(u"ࡋࡧ࡬ࡴࡧࢢ")):
				for Jitmvs6NeFZuVLMERXP in Va8yGKgbPuj7DmecIFsTv1:
					aTLJs5pqPDdObYo9fmS3 = rjYyd7g5LpPqJfR.path.join(fL1FAtaCuhoPNTc8MK,Jitmvs6NeFZuVLMERXP)
					try: rjYyd7g5LpPqJfR.remove(aTLJs5pqPDdObYo9fmS3)
					except Exception as bYsHJR4G3rSfVKTXAycDit: wbOMKdQVf2P4hqRk6UpJn8 = RR04cQvUTpItw(u"ࡌࡡ࡭ࡵࡨࢣ")
				for hwvE0sLlGktCqyJHO2 in mmnqaQeTxyjzKGL4EHlfoWUCuVd:
					YRVfktIQclDaFr6v9OKXHg5LuW = rjYyd7g5LpPqJfR.path.join(fL1FAtaCuhoPNTc8MK,hwvE0sLlGktCqyJHO2)
					try: rjYyd7g5LpPqJfR.rmdir(YRVfktIQclDaFr6v9OKXHg5LuW)
					except: pass
			try: rjYyd7g5LpPqJfR.rmdir(fL1FAtaCuhoPNTc8MK)
			except: pass
		if wbOMKdQVf2P4hqRk6UpJn8: ttkKp7oAiQC1PqfzcG5rUODbhBgR.Dialog().ok(ldwMpSemJOFNfK4zAXQD(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩࡁ"),fgQC9PGU6vSXszN2hOM3Ayle4(u"ࠧอ์าࠤ࠳࠴ࠠ็ฮะฮࠥ฿ๅๅ์ฬࠤู๊อࠡ็ฯ่ิࠦใศึࠣห้ฮั็ษ่ะࠬࡂ"))
		else: ttkKp7oAiQC1PqfzcG5rUODbhBgR.Dialog().ok(rrvzVUGAcmxwuybph7(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫࡃ"),lXvOLV8cw1(u"ࠩ็่ศูแࠡ࠰࠱ࠤๆฺไหࠢ฼้้๐ษࠡ็ึั๋ࠥฬๅัࠣ็ฬฺࠠศๆหี๋อๅอࠩࡄ"))
	return
def gg4YHhF6xy9ceWCL7qMVXaNdpifoDR():
	xpw5liVAeOGuRf14tW = fxZHJRj6aXgpyC1GKF3bkI4VWsPT2(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡳࡶࡴࡪࡩ࠳ࡹࡨ࠰࡭ࡲࡨ࡮࠵ࡥ࡮ࡣࡧࡣࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵ࠲ࡳࡱࡪ࠯ࡪࡰࡧࡩࡽ࠴ࡨࡵ࡯࡯ࠫࡅ")
	GG8qLjoKNnVMrgxai4UueDC1Am = ybf7KGeLzwR4pQXstT2avAZOlM.request(fxZHJRj6aXgpyC1GKF3bkI4VWsPT2(u"ࠫࡌࡋࡔࠨࡆ"),xpw5liVAeOGuRf14tW)
	r5ogiTH3mKIbsleahc7VdGjn0t = GG8qLjoKNnVMrgxai4UueDC1Am.content
	r5ogiTH3mKIbsleahc7VdGjn0t = r5ogiTH3mKIbsleahc7VdGjn0t.decode(m7olUSiswfHByXECOYWJjzt(u"ࠬࡻࡴࡧ࠺ࠪࡇ"))
	Va8yGKgbPuj7DmecIFsTv1 = jjMPIg1cuma4Gf0BxUvCOHLTre.findall(t0dvpNCrAR(u"࠭ࡨࡳࡧࡩࡁࠧࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࠭࠴ࠪࡀࠫ࠱ࡾ࡮ࡶࠢࠨࡈ"),r5ogiTH3mKIbsleahc7VdGjn0t,jjMPIg1cuma4Gf0BxUvCOHLTre.DOTALL)
	Va8yGKgbPuj7DmecIFsTv1 = sorted(Va8yGKgbPuj7DmecIFsTv1,reverse=m9guIvfFSk0OjUiM36thpZG(u"ࡔࡳࡷࡨࢤ"))
	yHaGUf0pIiY8cdPF = ttkKp7oAiQC1PqfzcG5rUODbhBgR.Dialog().select(TSK0kIafu3MeUqN(u"ࠧศะอีࠥอไฦืาหึࠦวๅาํࠤฯื๊ะࠢอฯอ๐ส่ࠩࡉ"),Va8yGKgbPuj7DmecIFsTv1)
	if yHaGUf0pIiY8cdPF==-RRExPb74MfkvFgnQJjqi(u"࠲࢐"): return
	filename = Va8yGKgbPuj7DmecIFsTv1[yHaGUf0pIiY8cdPF]
	if FKB0AE4MDXNCwGqnxpzt3yv6breIi: filename = filename.encode(fxZHJRj6aXgpyC1GKF3bkI4VWsPT2(u"ࠨࡷࡷࡪ࠽࠭ࡊ"))
	MxlIH4o3eu = xpw5liVAeOGuRf14tW.rsplit(m7olUSiswfHByXECOYWJjzt(u"ࠩ࠲ࠫࡋ"),S4LWvwnlb8ay(u"࠳࢑"))[S4LWvwnlb8ay(u"࠳࢒")]+RR04cQvUTpItw(u"ࠪ࠳ࠬࡌ")+thqb7iZ0Vw(u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࠫࡍ")+filename+RRExPb74MfkvFgnQJjqi(u"ࠬ࠴ࡺࡪࡲࠪࡎ")
	wbOMKdQVf2P4hqRk6UpJn8 = AvsERDt7cl2xM4jpKqy(u"ࡇࡣ࡯ࡷࡪࢥ")
	GG8qLjoKNnVMrgxai4UueDC1Am = ybf7KGeLzwR4pQXstT2avAZOlM.request(eo7pnXvlUIsO3(u"࠭ࡇࡆࡖࠪࡏ"),MxlIH4o3eu)
	if GG8qLjoKNnVMrgxai4UueDC1Am.status_code==RR04cQvUTpItw(u"࠶࠵࠶࢓"):
		WoVQTAnBl3qHNY2GCgjUuRFK9Md = GG8qLjoKNnVMrgxai4UueDC1Am.content
		import zipfile as QkPT9xeqb5mzhI,io as h2xpryYXBMmiGR0zgn3
		CQUXZvwn9FT = h2xpryYXBMmiGR0zgn3.BytesIO(WoVQTAnBl3qHNY2GCgjUuRFK9Md)
		jtzTrDdoqONGgMVEWswlCk = rjYyd7g5LpPqJfR.path.join(weGX9zCqsKBa,WT5lNHI8KteYsVS2hgwroPfzd74v(u"ࠧࡢࡦࡧࡳࡳࡹࠧࡐ"))
		xxiF3WbBgf = QkPT9xeqb5mzhI.ZipFile(CQUXZvwn9FT)
		xxiF3WbBgf.extractall(jtzTrDdoqONGgMVEWswlCk)
		TYFEJs3p7L0un.sleep(AvsERDt7cl2xM4jpKqy(u"࠶࢔"))
		DDrEy89ujmP7gKNpJsVWQvRcA3IoUe.executebuiltin(sLh2TcUYkv9S(u"ࠨࡗࡳࡨࡦࡺࡥࡍࡱࡦࡥࡱࡇࡤࡥࡱࡱࡷࠬࡑ"))
		TYFEJs3p7L0un.sleep(m9guIvfFSk0OjUiM36thpZG(u"࠷࢕"))
		fjT2ZREWNIr96BtlaoUh0S = DDrEy89ujmP7gKNpJsVWQvRcA3IoUe.executeJSONRPC(CYT70UgEBmdL4ZFx8K(u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡃࡧࡨࡴࡴࡳ࠯ࡕࡨࡸࡆࡪࡤࡰࡰࡈࡲࡦࡨ࡬ࡦࡦࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡣࡧࡨࡴࡴࡩࡥࠤ࠽ࠦࠬࡒ")+fWTicU6stbaCEMB+vl4AJXVyPYW9hrHua1CNjtpQEbFT(u"ࠪࠦ࠱ࠨࡥ࡯ࡣࡥࡰࡪࡪࠢ࠻ࡶࡵࡹࡪࢃࡽࠨࡓ"))
		if kR2pcoit9DLWEGV(u"ࠫࡔࡑࠧࡔ") in fjT2ZREWNIr96BtlaoUh0S: wbOMKdQVf2P4hqRk6UpJn8 = thqb7iZ0Vw(u"ࡖࡵࡹࡪࢦ")
	if wbOMKdQVf2P4hqRk6UpJn8: ttkKp7oAiQC1PqfzcG5rUODbhBgR.Dialog().ok(AvsERDt7cl2xM4jpKqy(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨࡕ"),kR2pcoit9DLWEGV(u"࠭ฬ๋ัࠣ࠲࠳ࠦๆอฯอࠤ฾๋ไ๋หࠣฮะฮ๊หࠢส่ส฻ฯศำࠣห้่ฯ๋็ࠣࡠࡳࡢ࡮ࠡࠩࡖ")+filename)
	else: ttkKp7oAiQC1PqfzcG5rUODbhBgR.Dialog().ok(vbB3H47silUOn2oTq(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪࡗ"),bZjRKgUTEt70h(u"ࠨๆ็วุ็ࠠ࠯࠰ࠣๅู๊สࠡ฻่่๏ฯࠠหอห๎ฯࠦวๅวุำฬืࠠศๆๅำ๏๋ࠠ࡝ࡰ࡟ࡲࠥ࠭ࡘ")+filename)
	n0qh1ZHlR9ioIQyrumkE25K3zgeY()
	return
def n0qh1ZHlR9ioIQyrumkE25K3zgeY(N2ukhIfFo7MXi45T9=None):
	if N2ukhIfFo7MXi45T9==None:
		uvwfsLgQJroOU92VYWnhG5 = GFSThKmp5iW3XJlCjnE6gf4y(hBsqZOS4KeXrWPJ6bo(u"ࠩะฮ๎๊ࠦษไ์ࠤฬ๊ลึัสีࠥอไใัํ้ࠥ็๊ࠡฮ๊หื้้ࠠๆสࠤ๏ะๅࠡฬะำ๏ั็ࠡล๋ฮํ๋วห์ๆ๎ฬࠦ࠮࠯ࠢํะอࠦร็ࠢอๆํ๋ࠠษวํๆฬ็ࠠศๆอัิ๐หࠡษ็วํะ่ๆษอ๎่๐ࠠ࠯࠰๋้ࠣࠦสา์าࠤส๐โศใࠣห้ะอะ์ฮࠤฬ๊ร้ฬ๋้ฬะ๊ไ์่้ࠣฮั็ษ่ะࠥลࠡࠨ࡙"))
		if uvwfsLgQJroOU92VYWnhG5 in [-rrvzVUGAcmxwuybph7(u"࠱࢖"),CYT70UgEBmdL4ZFx8K(u"࠱ࢗ")]: return
		N2ukhIfFo7MXi45T9 = sLh2TcUYkv9S(u"ࡘࡷࡻࡥࢨ") if uvwfsLgQJroOU92VYWnhG5==m7olUSiswfHByXECOYWJjzt(u"࠳࢘") else IfPUeRBishE(u"ࡉࡥࡱࡹࡥࢧ")
	if WW4dHKYOuI2k3MbpJ5RcDr6za1mlG: XQdIpLlxWs3KcFm = rjYyd7g5LpPqJfR.path.join(weGX9zCqsKBa,t0dvpNCrAR(u"ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥ࡚ࠬ"),IfPUeRBishE(u"ࠫࡉࡧࡴࡢࡤࡤࡷࡪ࡛࠭"),sLh2TcUYkv9S(u"ࠬࡇࡤࡥࡱࡱࡷ࠸࠹࠮ࡥࡤࠪ࡜"))
	else: XQdIpLlxWs3KcFm = rjYyd7g5LpPqJfR.path.join(weGX9zCqsKBa,kR2pcoit9DLWEGV(u"࠭ࡵࡴࡧࡵࡨࡦࡺࡡࠨ࡝"),fkv2TpxiwQ8N(u"ࠧࡅࡣࡷࡥࡧࡧࡳࡦࠩ࡞"),Ksp9cCGExNaevL71D(u"ࠨࡃࡧࡨࡴࡴࡳ࠳࠹࠱ࡨࡧ࠭࡟"))
	import sqlite3 as ukcMaAPSlHdWr2T
	wbOMKdQVf2P4hqRk6UpJn8 = dflspC41Io3eMAkDaWJ(u"ࡋࡧ࡬ࡴࡧࢩ")
	otI0iGq19DnuhTrRSLyj8xZ = lXvOLV8cw1(u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧࠫࡠ")
	Ssh6O0TnIgFYiBQp = RRExPb74MfkvFgnQJjqi(u"ࠪࡦࡱࡧࡣ࡬࡮࡬ࡷࡹ࠭ࡡ") if FKB0AE4MDXNCwGqnxpzt3yv6breIi else Ksp9cCGExNaevL71D(u"ࠫࡺࡶࡤࡢࡶࡨࡣࡷࡻ࡬ࡦࡵࠪࡢ")
	try:
		Rxu5WBneG2Lh = ukcMaAPSlHdWr2T.connect(XQdIpLlxWs3KcFm)
		Rxu5WBneG2Lh.text_factory = str
		RmeKvH8wrY3uf1LyOpJWZXIS2 = Rxu5WBneG2Lh.cursor()
		RmeKvH8wrY3uf1LyOpJWZXIS2.execute(fxZHJRj6aXgpyC1GKF3bkI4VWsPT2(u"࡙ࠬࡅࡍࡇࡆࡘࠥࡵࡲࡪࡩ࡬ࡲࠥࡌࡒࡐࡏࠣ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩࠦࡗࡉࡇࡕࡉࠥࡧࡤࡥࡱࡱࡍࡉࠦ࠽ࠡࠤࠪࡣ")+fWTicU6stbaCEMB+cJ9LCM5NyfRP34mEtzs(u"࠭ࠢࠡ࠽ࠪࡤ"))
		kkmTwFo6XCbeGYqBp5xtRL8QK31hn9 = RmeKvH8wrY3uf1LyOpJWZXIS2.fetchall()
		if kkmTwFo6XCbeGYqBp5xtRL8QK31hn9 and otI0iGq19DnuhTrRSLyj8xZ not in str(kkmTwFo6XCbeGYqBp5xtRL8QK31hn9): RmeKvH8wrY3uf1LyOpJWZXIS2.execute(Ksp9cCGExNaevL71D(u"ࠧࡖࡒࡇࡅ࡙ࡋࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦࠣࡗࡊ࡚ࠠࡰࡴ࡬࡫࡮ࡴࠠ࠾ࠢࠥࠫࡥ")+otI0iGq19DnuhTrRSLyj8xZ+Lf36ITD5vkWU9tHCgn(u"ࠨࠤ࡛ࠣࡍࡋࡒࡆࠢࡤࡨࡩࡵ࡮ࡊࡆࠣࡁࠥࠨࠧࡦ")+fWTicU6stbaCEMB+vl4AJXVyPYW9hrHua1CNjtpQEbFT(u"ࠩࠥࠤࡀ࠭ࡧ"))
		RmeKvH8wrY3uf1LyOpJWZXIS2.execute(thqb7iZ0Vw(u"ࠪࡗࡊࡒࡅࡄࡖࠣ࠮ࠥࡌࡒࡐࡏࠣࠫࡨ")+Ssh6O0TnIgFYiBQp+WT5lNHI8KteYsVS2hgwroPfzd74v(u"ࠫࠥ࡝ࡈࡆࡔࡈࠤࡦࡪࡤࡰࡰࡌࡈࠥࡃࠠࠣࠩࡩ")+fWTicU6stbaCEMB+fgQC9PGU6vSXszN2hOM3Ayle4(u"ࠬࠨࠠ࠼ࠩࡪ"))
		kkmTwFo6XCbeGYqBp5xtRL8QK31hn9 = RmeKvH8wrY3uf1LyOpJWZXIS2.fetchall()
		lJDN0V23AOoaLp716jkKufecZQ = fxZHJRj6aXgpyC1GKF3bkI4VWsPT2(u"ࡆࡢ࡮ࡶࡩࢫ") if kkmTwFo6XCbeGYqBp5xtRL8QK31hn9 else lXvOLV8cw1(u"࡚ࡲࡶࡧࢪ")
		if not lJDN0V23AOoaLp716jkKufecZQ and not N2ukhIfFo7MXi45T9: RmeKvH8wrY3uf1LyOpJWZXIS2.execute(RR04cQvUTpItw(u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࠬ࡫")+Ssh6O0TnIgFYiBQp+CYT70UgEBmdL4ZFx8K(u"࡙ࠧࠡࡋࡉࡗࡋࠠࡢࡦࡧࡳࡳࡏࡄࠡ࠿ࠣࠦࠬ࡬")+fWTicU6stbaCEMB+m7olUSiswfHByXECOYWJjzt(u"ࠨࠤࠣ࠿ࠬ࡭"))
		elif lJDN0V23AOoaLp716jkKufecZQ and N2ukhIfFo7MXi45T9:
			if FKB0AE4MDXNCwGqnxpzt3yv6breIi: RmeKvH8wrY3uf1LyOpJWZXIS2.execute(uESVvbkrwyjtinzasYm5FC(u"ࠩࡌࡒࡘࡋࡒࡕࠢࡌࡒ࡙ࡕࠠࠨ࡮")+Ssh6O0TnIgFYiBQp+thqb7iZ0Vw(u"ࠪࠤ࠭ࡧࡤࡥࡱࡱࡍࡉ࠯ࠠࡗࡃࡏ࡙ࡊ࡙ࠠࠩࠤࠪ࡯")+fWTicU6stbaCEMB+ZZmDIByEh6w(u"ࠫࠧ࠯ࠠ࠼ࠩࡰ"))
			else: RmeKvH8wrY3uf1LyOpJWZXIS2.execute(fkv2TpxiwQ8N(u"ࠬࡏࡎࡔࡇࡕࡘࠥࡏࡎࡕࡑࠣࠫࡱ")+Ssh6O0TnIgFYiBQp+RR04cQvUTpItw(u"࠭ࠠࠩࡣࡧࡨࡴࡴࡉࡅ࠮ࡸࡴࡩࡧࡴࡦࡔࡸࡰࡪ࠯ࠠࡗࡃࡏ࡙ࡊ࡙ࠠࠩࠤࠪࡲ")+fWTicU6stbaCEMB+thqb7iZ0Vw(u"ࠧࠣ࠮࠴࠭ࠥࡁࠧࡳ"))
		Rxu5WBneG2Lh.commit()
		Rxu5WBneG2Lh.close()
		wbOMKdQVf2P4hqRk6UpJn8 = AvsERDt7cl2xM4jpKqy(u"ࡕࡴࡸࡩࢬ")
	except: pass
	if wbOMKdQVf2P4hqRk6UpJn8:
		TYFEJs3p7L0un.sleep(ZZmDIByEh6w(u"࠴࢙"))
		DDrEy89ujmP7gKNpJsVWQvRcA3IoUe.executebuiltin(dflspC41Io3eMAkDaWJ(u"ࠨࡗࡳࡨࡦࡺࡥࡍࡱࡦࡥࡱࡇࡤࡥࡱࡱࡷࠬࡴ"))
		TYFEJs3p7L0un.sleep(lXvOLV8cw1(u"࠵࢚"))
		ttkKp7oAiQC1PqfzcG5rUODbhBgR.Dialog().ok(VlxX3fWmA0NFy(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬࡵ"),vbB3H47silUOn2oTq(u"ࠪะ๏ีࠠ࠯࠰๊ࠣัำสࠡษ็฽๊๊๊สࠩࡶ"))
	else: ttkKp7oAiQC1PqfzcG5rUODbhBgR.Dialog().ok(hBsqZOS4KeXrWPJ6bo(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧࡷ"),cJ9LCM5NyfRP34mEtzs(u"๊ࠬไฤีไࠤ࠳࠴ࠠโึ็ฮࠥอไฺ็็๎ฮ࠭ࡸ"))
	return
zAfNgSv32lC7kIOHqBV1c9 = NMY5ULbwaETqKA0DROmj9.argv[kR2pcoit9DLWEGV(u"࠶࢛")]
fWTicU6stbaCEMB = ZZmDIByEh6w(u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫࡹ")
EE71zPaYT2g3WsfyhDLOt0VoXxH = DDrEy89ujmP7gKNpJsVWQvRcA3IoUe.getInfoLabel(RR04cQvUTpItw(u"ࠢࡔࡻࡶࡸࡪࡳ࠮ࡃࡷ࡬ࡰࡩ࡜ࡥࡳࡵ࡬ࡳࡳࠨࡺ"))
is7LVrZpaI4MyDvkTmXFhtEG1 = jjMPIg1cuma4Gf0BxUvCOHLTre.findall(xD6t0BKNXf9wjL2byH(u"ࠨࠪ࡟ࡨࡡࡪ࡜࠯࡞ࡧ࠭ࠬࡻ"),EE71zPaYT2g3WsfyhDLOt0VoXxH,jjMPIg1cuma4Gf0BxUvCOHLTre.DOTALL)
is7LVrZpaI4MyDvkTmXFhtEG1 = float(is7LVrZpaI4MyDvkTmXFhtEG1[sLh2TcUYkv9S(u"࠶࢜")])
FKB0AE4MDXNCwGqnxpzt3yv6breIi = is7LVrZpaI4MyDvkTmXFhtEG1<t0dvpNCrAR(u"࠱࠺࢝")
WW4dHKYOuI2k3MbpJ5RcDr6za1mlG = is7LVrZpaI4MyDvkTmXFhtEG1>VlxX3fWmA0NFy(u"࠲࠺࠱࠽࠾࢞")
if WW4dHKYOuI2k3MbpJ5RcDr6za1mlG:
	LeGQjuHdE85Pa3s9Y0Di = XYUNQlv9ABrgW.translatePath(thqb7iZ0Vw(u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴ࡲ࡯ࡨࡲࡤࡸ࡭࠭ࡼ"))
	weGX9zCqsKBa = XYUNQlv9ABrgW.translatePath(bZjRKgUTEt70h(u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡨࡰ࡯ࡨࠫࡽ"))
else:
	LeGQjuHdE85Pa3s9Y0Di = DDrEy89ujmP7gKNpJsVWQvRcA3IoUe.translatePath(fkv2TpxiwQ8N(u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯࡭ࡱࡪࡴࡦࡺࡨࠨࡾ"))
	weGX9zCqsKBa = DDrEy89ujmP7gKNpJsVWQvRcA3IoUe.translatePath(t0dvpNCrAR(u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰ࡪࡲࡱࡪ࠭ࡿ"))
e8jKd1P0LGMZAxVH7gyJQcFIfn = rjYyd7g5LpPqJfR.path.join(LeGQjuHdE85Pa3s9Y0Di,VlxX3fWmA0NFy(u"࠭࡫ࡰࡦ࡬࠲ࡱࡵࡧࠨࢀ"))
lo9vOUYrGLDnEPdacNg1kjTKRyHA = rjYyd7g5LpPqJfR.path.join(LeGQjuHdE85Pa3s9Y0Di,dflspC41Io3eMAkDaWJ(u"ࠧ࡬ࡱࡧ࡭࠳ࡵ࡬ࡥ࠰࡯ࡳ࡬࠭ࢁ"))
if   zAfNgSv32lC7kIOHqBV1c9==sLh2TcUYkv9S(u"ࠨࡵࡨࡲࡩࡥ࡬ࡰࡩࡩ࡭ࡱ࡫ࠧࢂ")		: p49BGXI0Noa8kFy1sQrSfOMgdnPT(e8jKd1P0LGMZAxVH7gyJQcFIfn)
elif zAfNgSv32lC7kIOHqBV1c9==xD6t0BKNXf9wjL2byH(u"ࠩࡶࡩࡳࡪ࡟ࡰ࡮ࡧࡣࡱࡵࡧࡧ࡫࡯ࡩࠬࢃ")	: p49BGXI0Noa8kFy1sQrSfOMgdnPT(lo9vOUYrGLDnEPdacNg1kjTKRyHA)
elif zAfNgSv32lC7kIOHqBV1c9==fxZHJRj6aXgpyC1GKF3bkI4VWsPT2(u"ࠪࡨࡪࡲࡥࡵࡧࡢࡷࡪࡺࡴࡪࡰࡪࡷࠬࢄ")		: UU9AsLMSnNJ7acqiWk1fu3xFzgTPO()
elif zAfNgSv32lC7kIOHqBV1c9==eo7pnXvlUIsO3(u"ࠫࡩ࡫࡬ࡦࡶࡨࡣࡨࡧࡣࡩࡧࠪࢅ")		: bGnw32z58fQcs()
elif zAfNgSv32lC7kIOHqBV1c9==sLh2TcUYkv9S(u"ࠬ࡯࡮ࡴࡶࡤࡰࡱࡥ࡯࡭ࡦࡢࡺࡪࡸࡳࡪࡱࡱࠫࢆ")	: gg4YHhF6xy9ceWCL7qMVXaNdpifoDR()
elif zAfNgSv32lC7kIOHqBV1c9==ldwMpSemJOFNfK4zAXQD(u"࠭࡭ࡰࡦ࡬ࡪࡾࡥࡡࡶࡶࡲࡹࡵࡪࡡࡵࡧࠪࢇ")	: n0qh1ZHlR9ioIQyrumkE25K3zgeY()
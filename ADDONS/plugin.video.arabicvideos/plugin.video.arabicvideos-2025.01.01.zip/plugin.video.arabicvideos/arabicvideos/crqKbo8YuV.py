# -*- coding: utf-8 -*-
import sys as ytv0YaxDcRINurplWKg587Pwqz
LS5n9Ib81cvhApByQJa6GX4HTf = ytv0YaxDcRINurplWKg587Pwqz.version_info [0] == 2
FVDxSCW5MgK = 2048
o2SVZsYjxd4MPfLCRzv1Ime9XD6rhW = 7
def EnKbMAYoFJ (kc93hiPDm4MqAOaL):
	global BCEn6px5l4
	qR9DalTWtCBVeyYwiQg = ord (kc93hiPDm4MqAOaL [-1])
	SSe8FNopD7MI1EixsPTgl4v3YmfB6 = kc93hiPDm4MqAOaL [:-1]
	T2g7SpExkOcr8NUtfYyMB1d4usRw = qR9DalTWtCBVeyYwiQg % len (SSe8FNopD7MI1EixsPTgl4v3YmfB6)
	fxd3B46829KvYlTG17kUyLNJIbWDp0 = SSe8FNopD7MI1EixsPTgl4v3YmfB6 [:T2g7SpExkOcr8NUtfYyMB1d4usRw] + SSe8FNopD7MI1EixsPTgl4v3YmfB6 [T2g7SpExkOcr8NUtfYyMB1d4usRw:]
	if LS5n9Ib81cvhApByQJa6GX4HTf:
		nXV2GRHyP8dpugjML5sTE4OKN = unicode () .join ([unichr (ord (XXYULyZe1FgwdTVnSx2kHfDAsMClJ9) - FVDxSCW5MgK - (GPf6BlpctR + qR9DalTWtCBVeyYwiQg) % o2SVZsYjxd4MPfLCRzv1Ime9XD6rhW) for GPf6BlpctR, XXYULyZe1FgwdTVnSx2kHfDAsMClJ9 in enumerate (fxd3B46829KvYlTG17kUyLNJIbWDp0)])
	else:
		nXV2GRHyP8dpugjML5sTE4OKN = str () .join ([chr (ord (XXYULyZe1FgwdTVnSx2kHfDAsMClJ9) - FVDxSCW5MgK - (GPf6BlpctR + qR9DalTWtCBVeyYwiQg) % o2SVZsYjxd4MPfLCRzv1Ime9XD6rhW) for GPf6BlpctR, XXYULyZe1FgwdTVnSx2kHfDAsMClJ9 in enumerate (fxd3B46829KvYlTG17kUyLNJIbWDp0)])
	return eval (nXV2GRHyP8dpugjML5sTE4OKN)
hhqd6cnfNJiAaLKTPbst5RpMmZF2G,LyNiIHPOwD3hCUYEFM7,vODxLKW5Ql6r4Fbm8=EnKbMAYoFJ,EnKbMAYoFJ,EnKbMAYoFJ
xpT28sXu051,GGx4qyKP1vUtRghsE2WfaHLMXZ,PtkEvXAqif14G20QZsaSyT=vODxLKW5Ql6r4Fbm8,LyNiIHPOwD3hCUYEFM7,hhqd6cnfNJiAaLKTPbst5RpMmZF2G
SaB5hx3PZwXRLtKgrTfQvId,YzX407G1m8ER9OBpkeuqPIf6Ajrh5,EMO8gy4LrsNTh0knZwpSeU75APW=PtkEvXAqif14G20QZsaSyT,GGx4qyKP1vUtRghsE2WfaHLMXZ,xpT28sXu051
yJeq1BjfiO4NFuwIEzxVLK6b9s,ZchUJdM93pTA7zG5,CCUzMTgQjrHntoiGf16LXW5P8EdVu=EMO8gy4LrsNTh0knZwpSeU75APW,YzX407G1m8ER9OBpkeuqPIf6Ajrh5,SaB5hx3PZwXRLtKgrTfQvId
JZszNnIEMAx28Yao0yqhiXGKOPb,XrTw01KtLzbpoyMf,uuExaKGL7UONtevRd=CCUzMTgQjrHntoiGf16LXW5P8EdVu,ZchUJdM93pTA7zG5,yJeq1BjfiO4NFuwIEzxVLK6b9s
y6y5HtgXO4TkUbwVZ,sVzojQerUqX,tKNPiXfQ7HoAqndw3z9IL4E6VrGv1=uuExaKGL7UONtevRd,XrTw01KtLzbpoyMf,JZszNnIEMAx28Yao0yqhiXGKOPb
AbqCJZdWQP9j,Y41NvKfOroMzGB8sEHy7wbXlc5,hhQwbeiNLoqFjX90fB7aG8VAs=tKNPiXfQ7HoAqndw3z9IL4E6VrGv1,sVzojQerUqX,y6y5HtgXO4TkUbwVZ
IpC4qHXRuyNFjzWv,ppxP0Cg6N3JVELzjGKmkZ2qIlu,L90uqo28xEKSFUwYTcm51yRWZIkft=hhQwbeiNLoqFjX90fB7aG8VAs,Y41NvKfOroMzGB8sEHy7wbXlc5,AbqCJZdWQP9j
FRYcH4KL7e9gv5pEB,tELM0b9FzxuRI4J1CYcie7ZXsHBar,TlGXWLYsV1z=L90uqo28xEKSFUwYTcm51yRWZIkft,ppxP0Cg6N3JVELzjGKmkZ2qIlu,IpC4qHXRuyNFjzWv
ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n,HtK4o2sTPgA78U,zmcGfOdvAjsELeJlP=TlGXWLYsV1z,tELM0b9FzxuRI4J1CYcie7ZXsHBar,FRYcH4KL7e9gv5pEB
UO04GcM7oFd3kJbtKQZHRgI2jeyzCh,MgP8OjoaiWQEVG59,jXE2YHkswT8y=zmcGfOdvAjsELeJlP,HtK4o2sTPgA78U,ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n
from braVAkwfBN import *
sQU2GnRoMwLK8CBdfzmNr4jXyO = vODxLKW5Ql6r4Fbm8(u"࠭ࡒࡂࡐࡇࡓࡒ࡙ࠧᯪ")
ooQEi5O6tYsGVF8LU0TC3hgMeflBwH = ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠧࡠࡎࡖࡘࡤ࠭ᯫ")
KP7x1T4ZpAgc0Ld5r = pZWli1xqfVtvzuSU6ImNw53gBFsh
CnYt5VhgmUisdb = GGx4qyKP1vUtRghsE2WfaHLMXZ(u"࠵࠵ṗ")
def sHVM8YchrDjZAJ7(Cpf9s3c0Zngj7XE,url,U94JwhRgpXCOe5,zLEP9N4BOsVrXa,XC10geOnQtwrs):
	try: skyPuAlLvecbtRZfB0pzIGd34n7xX9 = str(XC10geOnQtwrs[Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᯬ")])
	except: skyPuAlLvecbtRZfB0pzIGd34n7xX9 = iiy37aKq0pCEIOwfcTh61xb4U
	if   Cpf9s3c0Zngj7XE==PtkEvXAqif14G20QZsaSyT(u"࠶࠼࠰Ṙ"): EA7FzO1kMZGQXDd2giB0cwLom = jihuS9LVAvTrClPapMbUEwfn8XN()
	elif Cpf9s3c0Zngj7XE==sVzojQerUqX(u"࠷࠶࠲ṙ"): EA7FzO1kMZGQXDd2giB0cwLom = kb640sj2JD3BNKWvrYzFAnqEP(U94JwhRgpXCOe5)
	elif Cpf9s3c0Zngj7XE==ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"࠱࠷࠴Ṛ"): EA7FzO1kMZGQXDd2giB0cwLom = UUE3o0bs9gSzHDcMXRaLtIYVfeNwjk(U94JwhRgpXCOe5,ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"࠱࠷࠴Ṛ"))
	elif Cpf9s3c0Zngj7XE==AbqCJZdWQP9j(u"࠲࠸࠶ṛ"): EA7FzO1kMZGQXDd2giB0cwLom = UUE3o0bs9gSzHDcMXRaLtIYVfeNwjk(U94JwhRgpXCOe5,AbqCJZdWQP9j(u"࠲࠸࠶ṛ"))
	elif Cpf9s3c0Zngj7XE==PtkEvXAqif14G20QZsaSyT(u"࠳࠹࠸Ṝ"): EA7FzO1kMZGQXDd2giB0cwLom = siVTrHfNKYu3BcS7z(U94JwhRgpXCOe5)
	elif Cpf9s3c0Zngj7XE==IpC4qHXRuyNFjzWv(u"࠴࠺࠺ṝ"): EA7FzO1kMZGQXDd2giB0cwLom = MrkvDNYdKzlF4byPLujXW7VGtB(url,U94JwhRgpXCOe5)
	elif Cpf9s3c0Zngj7XE==yJeq1BjfiO4NFuwIEzxVLK6b9s(u"࠵࠻࠼Ṟ"): EA7FzO1kMZGQXDd2giB0cwLom = n7mvgRkxu08izbcpH4BrD2lXyCGZ(url,U94JwhRgpXCOe5)
	elif Cpf9s3c0Zngj7XE==MgP8OjoaiWQEVG59(u"࠶࠼࠷ṟ"): EA7FzO1kMZGQXDd2giB0cwLom = sWi2cUgfOCEu0rQk13MAF5b(url,U94JwhRgpXCOe5)
	elif Cpf9s3c0Zngj7XE==AbqCJZdWQP9j(u"࠷࠶࠹Ṡ"): EA7FzO1kMZGQXDd2giB0cwLom = elvpHcCnarGE8LDwUSRM69Z(url,U94JwhRgpXCOe5)
	elif Cpf9s3c0Zngj7XE==GGx4qyKP1vUtRghsE2WfaHLMXZ(u"࠷࠷࠳ṡ"): EA7FzO1kMZGQXDd2giB0cwLom = TMpru3sUyk7I()
	elif Cpf9s3c0Zngj7XE==LyNiIHPOwD3hCUYEFM7(u"࠸࠸࠵Ṣ"): EA7FzO1kMZGQXDd2giB0cwLom = bBxI6JWeZn3NjoLfh()
	elif Cpf9s3c0Zngj7XE==ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"࠹࠹࠷ṣ"): EA7FzO1kMZGQXDd2giB0cwLom = yl4Pf2poLgmqT8VF0xwGKQrh1UEnHk(skyPuAlLvecbtRZfB0pzIGd34n7xX9,U94JwhRgpXCOe5,zLEP9N4BOsVrXa)
	elif Cpf9s3c0Zngj7XE==TlGXWLYsV1z(u"࠺࠺࠹Ṥ"): EA7FzO1kMZGQXDd2giB0cwLom = xxuwnQYU3vV7(skyPuAlLvecbtRZfB0pzIGd34n7xX9,U94JwhRgpXCOe5)
	elif Cpf9s3c0Zngj7XE==CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"࠻࠻࠻ṥ"): EA7FzO1kMZGQXDd2giB0cwLom = ogzuMapeTv7B(skyPuAlLvecbtRZfB0pzIGd34n7xX9,U94JwhRgpXCOe5)
	else: EA7FzO1kMZGQXDd2giB0cwLom = XrTw01KtLzbpoyMf(u"ࡈࡤࡰࡸ࡫Ế")
	return EA7FzO1kMZGQXDd2giB0cwLom
def jihuS9LVAvTrClPapMbUEwfn8XN():
	bP6z3OSLp7va(vODxLKW5Ql6r4Fbm8(u"ࠩࡩࡳࡱࡪࡥࡳࠩᯭ"),uuExaKGL7UONtevRd(u"ࠪๆ๋๎วหࠢอ่ๆุ๊้่ࠣ฽ู๎วว์ฬࠫᯮ"),iiy37aKq0pCEIOwfcTh61xb4U,tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"࠶࠼࠱Ṧ"),iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,MgP8OjoaiWQEVG59(u"ࠫࡤࡒࡉࡗࡇࡗ࡚ࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᯯ"))
	bP6z3OSLp7va(zmcGfOdvAjsELeJlP(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᯰ"),GGx4qyKP1vUtRghsE2WfaHLMXZ(u"࠭โิ็ࠣ฽ู๎วว์ࠪᯱ"),iiy37aKq0pCEIOwfcTh61xb4U,LyNiIHPOwD3hCUYEFM7(u"࠷࠶࠳ṧ"),iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,SaB5hx3PZwXRLtKgrTfQvId(u"ࠧࡠࡕࡌࡘࡊ࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢ᯲ࠫ"))
	bP6z3OSLp7va(FRYcH4KL7e9gv5pEB(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᯳"),CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠩไ๎ิ๐่่ษอࠤ฾ฺ่ศศํอࠬ᯴"),iiy37aKq0pCEIOwfcTh61xb4U,GGx4qyKP1vUtRghsE2WfaHLMXZ(u"࠱࠷࠵Ṩ"),iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,SaB5hx3PZwXRLtKgrTfQvId(u"ࠪࡣࡘࡏࡔࡆࡕࡢࡣࡗࡇࡎࡅࡑࡐࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ᯵"))
	bP6z3OSLp7va(ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ᯶"),vODxLKW5Ql6r4Fbm8(u"ࠬ็๊ะ์๋๋ฬะࠠษฯฮࠤ฾ฺ่ศศํࠫ᯷"),iiy37aKq0pCEIOwfcTh61xb4U,CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"࠲࠸࠷ṩ"),iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,SaB5hx3PZwXRLtKgrTfQvId(u"࠭࡟ࡔࡋࡗࡉࡘࡥ࡟ࡓࡃࡑࡈࡔࡓ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ᯸"))
	bP6z3OSLp7va(PtkEvXAqif14G20QZsaSyT(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᯹"),hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠨใํำ๏๎็ศฬࠣ฽ู๎วว์ฬࠤ๊์ࠠใี่ࠫ᯺"),iiy37aKq0pCEIOwfcTh61xb4U,UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"࠹࠹࠷Ṫ"),iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠩࡢࡗࡎ࡚ࡅࡔࡡࡢࡖࡆࡔࡄࡐࡏࡢࠫ᯻"))
	bP6z3OSLp7va(XrTw01KtLzbpoyMf(u"ࠪࡰ࡮ࡴ࡫ࠨ᯼"),PSwfZcdRYhpl5Igqz8xOEk67+MgP8OjoaiWQEVG59(u"ࠫࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࠪ᯽")+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"࠼࠽࠾࠿ṫ"))
	bP6z3OSLp7va(tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ᯾"),PtkEvXAqif14G20QZsaSyT(u"࠭โ็๊สฮࠥࡓ࠳ࡖࠢ฼ุํอฦ๋หࠪ᯿"),iiy37aKq0pCEIOwfcTh61xb4U,EMO8gy4LrsNTh0knZwpSeU75APW(u"࠵࠻࠹Ṭ"),iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,PtkEvXAqif14G20QZsaSyT(u"ࠧࡠࡏ࠶࡙ࡤࡥࡌࡊࡘࡈࡣࡤࡘࡁࡏࡆࡒࡑࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᰀ"))
	bP6z3OSLp7va(MgP8OjoaiWQEVG59(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᰁ"),ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠩไ๎ิ๐่่ษอࠤࡒ࠹ࡕࠡ฻ื์ฬฬ๊สࠩᰂ"),iiy37aKq0pCEIOwfcTh61xb4U,JZszNnIEMAx28Yao0yqhiXGKOPb(u"࠶࠼࠳ṭ"),iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠪࡣࡒ࠹ࡕࡠࡡ࡙ࡓࡉࡥ࡟ࡓࡃࡑࡈࡔࡓ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᰃ"))
	bP6z3OSLp7va(TlGXWLYsV1z(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᰄ"),hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"่ࠬำๆࠢๅ๊ํอสࠡࡏ࠶࡙ࠥ฿ิ้ษษ๎ࠬᰅ"),iiy37aKq0pCEIOwfcTh61xb4U,tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"࠷࠶࠳Ṯ"),iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,JZszNnIEMAx28Yao0yqhiXGKOPb(u"࠭࡟ࡎ࠵ࡘࡣࡤࡒࡉࡗࡇࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧᰆ"))
	bP6z3OSLp7va(jXE2YHkswT8y(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᰇ"),tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠨไึ้ࠥ็๊ะ์๋ࠤࡒ࠹ࡕࠡ฻ื์ฬฬ๊ࠨᰈ"),iiy37aKq0pCEIOwfcTh61xb4U,YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"࠱࠷࠴ṯ"),iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,sVzojQerUqX(u"ࠩࡢࡑ࠸࡛࡟ࡠࡘࡒࡈࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᰉ"))
	bP6z3OSLp7va(ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠪࡪࡴࡲࡤࡦࡴࠪᰊ"),GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠫๆ๐ฯ๋๊๊หฯࠦࡍ࠴ࡗࠣฬาัฺࠠึ๋หห๐ࠧᰋ"),iiy37aKq0pCEIOwfcTh61xb4U,LyNiIHPOwD3hCUYEFM7(u"࠲࠸࠷Ṱ"),iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠬࡥࡍ࠴ࡗࡢࡣࡗࡇࡎࡅࡑࡐࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᰌ"))
	bP6z3OSLp7va(tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᰍ"),XrTw01KtLzbpoyMf(u"ࠧโ์า๎ํํวหࠢࡐ࠷ู࡚ࠦี๊สส๏ฯࠠๆ่ࠣๆุ๋ࠧᰎ"),iiy37aKq0pCEIOwfcTh61xb4U,SaB5hx3PZwXRLtKgrTfQvId(u"࠹࠹࠹ṱ"),iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,sVzojQerUqX(u"ࠨࡡࡐ࠷࡚ࡥ࡟ࡓࡃࡑࡈࡔࡓ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᰏ"))
	bP6z3OSLp7va(TlGXWLYsV1z(u"ࠩ࡯࡭ࡳࡱࠧᰐ"),PSwfZcdRYhpl5Igqz8xOEk67+CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠪࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡࠩᰑ")+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"࠼࠽࠾࠿Ṳ"))
	bP6z3OSLp7va(ZchUJdM93pTA7zG5(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᰒ"),PtkEvXAqif14G20QZsaSyT(u"่ࠬๆ้ษอࠤࡎࡖࡔࡗࠢ฼ุํอฦ๋หࠪᰓ"),iiy37aKq0pCEIOwfcTh61xb4U,LyNiIHPOwD3hCUYEFM7(u"࠵࠻࠹ṳ"),iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"࠭࡟ࡊࡒࡗ࡚ࡤࡥࡌࡊࡘࡈࡣࡤࡘࡁࡏࡆࡒࡑࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᰔ"))
	bP6z3OSLp7va(TlGXWLYsV1z(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᰕ"),hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠨใํำ๏๎็ศฬࠣࡍࡕ࡚ࡖࠡ฻ื์ฬฬ๊สࠩᰖ"),iiy37aKq0pCEIOwfcTh61xb4U,TlGXWLYsV1z(u"࠶࠼࠳Ṵ"),iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,jXE2YHkswT8y(u"ࠩࡢࡍࡕ࡚ࡖࡠࡡ࡙ࡓࡉࡥ࡟ࡓࡃࡑࡈࡔࡓ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᰗ"))
	bP6z3OSLp7va(UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠪࡪࡴࡲࡤࡦࡴࠪᰘ"),uuExaKGL7UONtevRd(u"ࠫ็ูๅࠡไ้์ฬะࠠࡊࡒࡗ࡚ࠥ฿ิ้ษษ๎ࠬᰙ"),iiy37aKq0pCEIOwfcTh61xb4U,XrTw01KtLzbpoyMf(u"࠷࠶࠳ṵ"),iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,LyNiIHPOwD3hCUYEFM7(u"ࠬࡥࡉࡑࡖ࡙ࡣࡤࡒࡉࡗࡇࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧᰚ"))
	bP6z3OSLp7va(GGx4qyKP1vUtRghsE2WfaHLMXZ(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᰛ"),L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠧใี่ࠤๆ๐ฯ๋๊ࠣࡍࡕ࡚ࡖࠡ฻ื์ฬฬ๊ࠨᰜ"),iiy37aKq0pCEIOwfcTh61xb4U,y6y5HtgXO4TkUbwVZ(u"࠱࠷࠴Ṷ"),iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,jXE2YHkswT8y(u"ࠨࡡࡌࡔ࡙࡜࡟ࡠࡘࡒࡈࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᰝ"))
	bP6z3OSLp7va(JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠩࡩࡳࡱࡪࡥࡳࠩᰞ"),ZchUJdM93pTA7zG5(u"ࠪๅ๏ี๊้้สฮࠥࡏࡐࡕࡘࠣฬาัฺࠠึ๋หห๐ࠧᰟ"),iiy37aKq0pCEIOwfcTh61xb4U,tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"࠲࠸࠷ṷ"),iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠫࡤࡏࡐࡕࡘࡢࡣࡗࡇࡎࡅࡑࡐࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᰠ"))
	bP6z3OSLp7va(L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᰡ"),y6y5HtgXO4TkUbwVZ(u"࠭แ๋ัํ์์อสࠡࡋࡓࡘู࡛ࠦี๊สส๏ฯࠠๆ่ࠣๆุ๋ࠧᰢ"),iiy37aKq0pCEIOwfcTh61xb4U,TlGXWLYsV1z(u"࠹࠹࠸Ṹ"),iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠧࡠࡋࡓࡘ࡛ࡥ࡟ࡓࡃࡑࡈࡔࡓ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᰣ"))
	return
def TMpru3sUyk7I():
	bP6z3OSLp7va(CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᰤ"),AbqCJZdWQP9j(u"ࠩࡢࡍࡕ࡚࡟ࠨᰥ")+GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠪๅ๏ี๊้้สฮࠥาๅ๋฻ࠣࡍࡕ࡚ࡖࠨᰦ"),iiy37aKq0pCEIOwfcTh61xb4U,XrTw01KtLzbpoyMf(u"࠺࠺࠹ṹ"))
	bP6z3OSLp7va(ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠫࡱ࡯࡮࡬ࠩᰧ"),PSwfZcdRYhpl5Igqz8xOEk67+ZchUJdM93pTA7zG5(u"ࠬࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࠪᰨ")+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"࠽࠾࠿࠹Ṻ"))
	for skyPuAlLvecbtRZfB0pzIGd34n7xX9 in range(YYJQyRskpX8jv,IDxpbtWgzXHs3u08Q7nR6YerO+YYJQyRskpX8jv):
		ooQEi5O6tYsGVF8LU0TC3hgMeflBwH = SaB5hx3PZwXRLtKgrTfQvId(u"࠭࡟ࡊࡒࠪᰩ")+str(skyPuAlLvecbtRZfB0pzIGd34n7xX9)+ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠧࡠࠩᰪ")
		bP6z3OSLp7va(IpC4qHXRuyNFjzWv(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᰫ"),ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠩࠣๅ๏ี๊้้สฮ๋ࠥฬๅัࠣࠫᰬ")+T7Rtxv5SnE1O94dLBcVNKHDZbJQe[skyPuAlLvecbtRZfB0pzIGd34n7xX9],iiy37aKq0pCEIOwfcTh61xb4U,ZchUJdM93pTA7zG5(u"࠼࠼࠴ṻ"),iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,{YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠪࡪࡴࡲࡤࡦࡴࠪᰭ"):skyPuAlLvecbtRZfB0pzIGd34n7xX9})
	return
def bBxI6JWeZn3NjoLfh():
	bP6z3OSLp7va(CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᰮ"),PtkEvXAqif14G20QZsaSyT(u"ࠬࡥࡍ࠴ࡗࡢࠫᰯ")+SaB5hx3PZwXRLtKgrTfQvId(u"࠭แ๋ัํ์์อสࠡฮ่๎฾ࠦࡍ࠴ࡗࠪᰰ"),iiy37aKq0pCEIOwfcTh61xb4U,LyNiIHPOwD3hCUYEFM7(u"࠽࠶࠶Ṽ"))
	bP6z3OSLp7va(YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠧ࡭࡫ࡱ࡯ࠬᰱ"),PSwfZcdRYhpl5Igqz8xOEk67+hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠨ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥ࠭ᰲ")+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,AbqCJZdWQP9j(u"࠹࠺࠻࠼ṽ"))
	for skyPuAlLvecbtRZfB0pzIGd34n7xX9 in range(YYJQyRskpX8jv,IDxpbtWgzXHs3u08Q7nR6YerO+YYJQyRskpX8jv):
		ooQEi5O6tYsGVF8LU0TC3hgMeflBwH = hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠩࡢࡑ࡚࠭ᰳ")+str(skyPuAlLvecbtRZfB0pzIGd34n7xX9)+L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠪࡣࠬᰴ")
		bP6z3OSLp7va(AbqCJZdWQP9j(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᰵ"),ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+LyNiIHPOwD3hCUYEFM7(u"ࠬࠦแ๋ัํ์์อสࠡ็ฯ่ิࠦࠧᰶ")+T7Rtxv5SnE1O94dLBcVNKHDZbJQe[skyPuAlLvecbtRZfB0pzIGd34n7xX9],iiy37aKq0pCEIOwfcTh61xb4U,zmcGfOdvAjsELeJlP(u"࠸࠸࠸Ṿ"),iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,{LyNiIHPOwD3hCUYEFM7(u"࠭ࡦࡰ࡮ࡧࡩࡷ᰷࠭"):skyPuAlLvecbtRZfB0pzIGd34n7xX9})
	return
def w6lrVT74uiJMDdWAchvBL95(ekEOd3mqAThaBDUoIrntuGRjYW):
	global g5pwxY4L9ayDGfF,EEDFySi3IhZUoaVjTBWgle
	ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,lEgmdMxnfsXj,ZebIE2aQgrGn = GGkFKuWvn5q1wVmldgXz(ekEOd3mqAThaBDUoIrntuGRjYW)
	try:
		if GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠧࡊࡈࡌࡐࡒ࠭᰸") in ekEOd3mqAThaBDUoIrntuGRjYW: ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI(ekEOd3mqAThaBDUoIrntuGRjYW)
		else: ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI()
		Eb439nTwvHQIA8B5Cl1MzKheG6stN = HtK4o2sTPgA78U(u"ࡉࡥࡱࡹࡥế")
	except:
		STuF19IbYQR3gz()
		Eb439nTwvHQIA8B5Cl1MzKheG6stN = tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࡘࡷࡻࡥỀ")
	ekEOd3mqAThaBDUoIrntuGRjYW = aanoXVLTZqsIwitBdY0kcJS794FDg(ekEOd3mqAThaBDUoIrntuGRjYW)
	if Eb439nTwvHQIA8B5Cl1MzKheG6stN:
		YYkhEn5xTXLUevzCVNB16mR(ekEOd3mqAThaBDUoIrntuGRjYW,AbqCJZdWQP9j(u"ࠨใื่๊ࠥไฤีไࠫ᰹"),X2cQ5NCPvkMieBW7oASspFjE=ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"࠴࠳࠴࠵ṿ"))
		g5pwxY4L9ayDGfF += YYJQyRskpX8jv
		EEDFySi3IhZUoaVjTBWgle += iFBmE2MUIpSu34wsd7Rf6z+ekEOd3mqAThaBDUoIrntuGRjYW
	else: YYkhEn5xTXLUevzCVNB16mR(ekEOd3mqAThaBDUoIrntuGRjYW,iiy37aKq0pCEIOwfcTh61xb4U,X2cQ5NCPvkMieBW7oASspFjE=L90uqo28xEKSFUwYTcm51yRWZIkft(u"࠴࠴࠵࠶Ẁ"))
	return
def PPYAxHMiQIE(TwusK2njEaJe3hrt9DOQHXCpB4W0LG=TlGXWLYsV1z(u"࡙ࡸࡵࡦề")):
	global g5pwxY4L9ayDGfF,EEDFySi3IhZUoaVjTBWgle,EeCo9tOcL2dIZu75g
	if not TwusK2njEaJe3hrt9DOQHXCpB4W0LG:
		EeCo9tOcL2dIZu75g = QKzCiBOWZus1nSv(PdkZHNBlpg2b7DmX6qRiyVa,tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠩࡧ࡭ࡨࡺࠧ᰺"),y6y5HtgXO4TkUbwVZ(u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤ࡙ࡉࡕࡇࡖࠫ᰻"),ZchUJdM93pTA7zG5(u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡓࡊࡖࡈࡗࡤࡇࡌࡍࠩ᰼"))
		if EeCo9tOcL2dIZu75g: return
	U17QqF2gkI46 = A1AXKupEOfz(AbqCJZdWQP9j(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ᰽"),iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,EMO8gy4LrsNTh0knZwpSeU75APW(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ᰾"),FRYcH4KL7e9gv5pEB(u"ࠧๅๅํࠤฯ๋ไว๊ࠢิ์ࠦวๅไสส๊ฯࠠ࠯ࠢส่อืๆศ็ฯࠤ๏ำสศฮࠣว๋๊ࠦโฯุࠤัฺ๋๊่ࠢ์ฬู่ࠡษ็ๅ๏ี๊้ࠢส่ฯ๐ࠠโ์ࠣห้ฮั็ษ่ะ๊ࠥใ๋ࠢํืฯิัอ่๊ࠢ์อࠠโไฺࠤฬ๊รใีส้ࠥอไาศํื๏ฯࠠ࠯ࠢฮ้ࠥ๐โ้็ࠣห้ฮั็ษ่ะࠥฮฮำ่๋ࠣีํࠠศๆฦๆุอๅࠡฯอํ๊ࠥวࠡฬะฮฬาࠠฤ่ࠣฮ๊๊ฦ่ษ้ࠣึฯࠠฤะิํࠥ࠴ฺࠠ็็๎ฮࠦๅๅศࠣะ๊๐ูࠡษ็ว็ูวๆࠢอัฯอฬࠡ฻สำฮࠦรใๆ้๋ࠣࠦ࠳ࠡัๅหห่ࠠ࠯๊่ࠢࠥะั๋ัࠣว๋ࠦสอ็฼ࠤ็อฦๆหࠣห้ษโิษ่ࠤฬ๊ย็ࠢยࠫ᰿"))
	if U17QqF2gkI46!=YYJQyRskpX8jv: return
	qI2s0ZN7uj(y6y5HtgXO4TkUbwVZ(u"ࡌࡡ࡭ࡵࡨỂ"),y6y5HtgXO4TkUbwVZ(u"ࡌࡡ࡭ࡵࡨỂ"),y6y5HtgXO4TkUbwVZ(u"ࡌࡡ࡭ࡵࡨỂ"))
	CPs3pbEIj5xqchgJfZ7 = g6ghGH4aBEYkTl3vbJZ
	g5pwxY4L9ayDGfF,EEDFySi3IhZUoaVjTBWgle,threads = FGTfwsjNrB8DvKSZhLIQAb1JnO,iiy37aKq0pCEIOwfcTh61xb4U,{}
	for ekEOd3mqAThaBDUoIrntuGRjYW in bhCnG4zQdj:
		X2cQ5NCPvkMieBW7oASspFjE.sleep(YYJQyRskpX8jv)
		threads[ekEOd3mqAThaBDUoIrntuGRjYW] = EEehSFDLdpKBR3W1ga9PxrV.Thread(target=w6lrVT74uiJMDdWAchvBL95,args=(ekEOd3mqAThaBDUoIrntuGRjYW,))
		threads[ekEOd3mqAThaBDUoIrntuGRjYW].start()
		if g5pwxY4L9ayDGfF>=CnYt5VhgmUisdb: break
	else:
		for ekEOd3mqAThaBDUoIrntuGRjYW in list(threads.keys()): threads[ekEOd3mqAThaBDUoIrntuGRjYW].join()
	g6ghGH4aBEYkTl3vbJZ[:] = CPs3pbEIj5xqchgJfZ7
	if g5pwxY4L9ayDGfF>=CnYt5VhgmUisdb: bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ᱀"),LyNiIHPOwD3hCUYEFM7(u"ࠩ็ำ๏้ࠠๆึๆ่ฮࠦแ๋ࠢࠪ᱁")+str(g5pwxY4L9ayDGfF)+JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠪࠤ๊๎วใ฻้๋ࠣࠦๅ้ษๅ฽ࠥอไษำ้ห๊าࠠ࠯࠰࠱ࠤํูศษ้สࠤ็ี๋ࠠๅ๋๊ࠥ฿ฯๆ๋ࠢะํีࠠฦ่อี๋๐สࠡใํࠤัํวำๅࠣ์์๐࠺ࠨ᱂")+EEDFySi3IhZUoaVjTBWgle)
	else:
		EeCo9tOcL2dIZu75g = {}
		for ekEOd3mqAThaBDUoIrntuGRjYW in list(threads.keys()):
			try: dKjsboJ6NYLhRVOBXSA1 = DLTuRI6kd1K75q[ekEOd3mqAThaBDUoIrntuGRjYW]
			except: continue
			ekEOd3mqAThaBDUoIrntuGRjYW = sVzojQerUqX(u"ࠫࡤࡒࡓࡕࡡࠪ᱃")+aanoXVLTZqsIwitBdY0kcJS794FDg(ekEOd3mqAThaBDUoIrntuGRjYW)
			for synCYOiMR789twmfr,JJwnocyLUxHI2jlKF4Y,kMqh74TPvpSDar59xQUjAyVlHes,Cpf9s3c0Zngj7XE,GmrA8hvBgN4bDdEWXS9nVMtU,F50ngOyjSvAcVRtdafJsiBkP9Yx,U94JwhRgpXCOe5,YGNomIp2tDSR6ncf,BSmlfc08nJ in dKjsboJ6NYLhRVOBXSA1:
				if not JJwnocyLUxHI2jlKF4Y: JJwnocyLUxHI2jlKF4Y = MgP8OjoaiWQEVG59(u"ࠬ࠴࠮࠯࠰ࠪ᱄")
				else:
					if JJwnocyLUxHI2jlKF4Y.count(GGx4qyKP1vUtRghsE2WfaHLMXZ(u"࠭࡟ࠨ᱅"))>YYJQyRskpX8jv: JJwnocyLUxHI2jlKF4Y = JJwnocyLUxHI2jlKF4Y.split(UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠧࡠࠩ᱆"),nI2JK1RfsGWNY3OarEeMQZ)[nI2JK1RfsGWNY3OarEeMQZ]
					JJwnocyLUxHI2jlKF4Y = JJwnocyLUxHI2jlKF4Y.replace(y6y5HtgXO4TkUbwVZ(u"ࠨࢢࠪ᱇"),iiy37aKq0pCEIOwfcTh61xb4U).replace(tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠩࠣࡌࡉ࠭᱈"),iiy37aKq0pCEIOwfcTh61xb4U).replace(GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠪࡌࡉࠦࠧ᱉"),iiy37aKq0pCEIOwfcTh61xb4U)
					JJwnocyLUxHI2jlKF4Y = JJwnocyLUxHI2jlKF4Y.replace(ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠫๅ࠭᱊"),iiy37aKq0pCEIOwfcTh61xb4U).replace(xpT28sXu051(u"ࠬฯࠧ᱋"),sVzojQerUqX(u"࠭็ࠨ᱌")).replace(yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠧลࠩᱍ"),tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠨ๊ࠪᱎ"))
					JJwnocyLUxHI2jlKF4Y = JJwnocyLUxHI2jlKF4Y.replace(yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠩฦࠫᱏ"),GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠪหࠬ᱐")).replace(xpT28sXu051(u"ࠫส࠭᱑"),sVzojQerUqX(u"ࠬอࠧ᱒")).replace(y6y5HtgXO4TkUbwVZ(u"࠭ยࠨ᱓"),YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠧศࠩ᱔"))
					JJwnocyLUxHI2jlKF4Y = JJwnocyLUxHI2jlKF4Y.replace(vODxLKW5Ql6r4Fbm8(u"ࠨๆฦࠫ᱕"),jXE2YHkswT8y(u"ࠩ็หࠬ᱖")).replace(PtkEvXAqif14G20QZsaSyT(u"่ࠪส࠭᱗"),PtkEvXAqif14G20QZsaSyT(u"้ࠫอࠧ᱘")).replace(vODxLKW5Ql6r4Fbm8(u"๊ࠬยࠨ᱙"),CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"࠭ไศࠩᱚ"))
					JJwnocyLUxHI2jlKF4Y = JJwnocyLUxHI2jlKF4Y.replace(jXE2YHkswT8y(u"ࠧ๏ࠩᱛ"),iiy37aKq0pCEIOwfcTh61xb4U).replace(tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠨํࠪᱜ"),iiy37aKq0pCEIOwfcTh61xb4U).replace(zmcGfOdvAjsELeJlP(u"ࠩ๒ࠫᱝ"),iiy37aKq0pCEIOwfcTh61xb4U).replace(zmcGfOdvAjsELeJlP(u"ࠪ๐ࠬᱞ"),iiy37aKq0pCEIOwfcTh61xb4U)
					JJwnocyLUxHI2jlKF4Y = JJwnocyLUxHI2jlKF4Y.replace(tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠫ๕࠭ᱟ"),iiy37aKq0pCEIOwfcTh61xb4U).replace(ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠬ๓ࠧᱠ"),iiy37aKq0pCEIOwfcTh61xb4U).replace(uuExaKGL7UONtevRd(u"࠭๒ࠨᱡ"),iiy37aKq0pCEIOwfcTh61xb4U).replace(uuExaKGL7UONtevRd(u"ࠧ๒ࠩᱢ"),iiy37aKq0pCEIOwfcTh61xb4U)
					JJwnocyLUxHI2jlKF4Y = JJwnocyLUxHI2jlKF4Y.replace(GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠨࡾࠪᱣ"),iiy37aKq0pCEIOwfcTh61xb4U).replace(hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠩࢁࠫᱤ"),iiy37aKq0pCEIOwfcTh61xb4U)
					JJwnocyLUxHI2jlKF4Y = JJwnocyLUxHI2jlKF4Y.replace(JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠪหํ์ࠠๅษํ๊ࠬᱥ"),iiy37aKq0pCEIOwfcTh61xb4U).replace(FRYcH4KL7e9gv5pEB(u"ุࠫ๐ๅศࠢ็ห๏ะࠧᱦ"),iiy37aKq0pCEIOwfcTh61xb4U)
					AJR9ldxo4fTe = [FRYcH4KL7e9gv5pEB(u"ࠬอไฺษหࠫᱧ"),uuExaKGL7UONtevRd(u"࠭ฮ๋ษ็ࠫᱨ"),hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠧศๆห์๊࠭ᱩ"),GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠨษ็ห๋࠭ᱪ"),PtkEvXAqif14G20QZsaSyT(u"ࠩส฻ๆอไࠨᱫ"),xpT28sXu051(u"ࠪัฬ๊๊่ࠩᱬ"),AbqCJZdWQP9j(u"ࠫฬฺ๊ศิࠪᱭ"),sVzojQerUqX(u"ࠬ฻วๅฯࠪᱮ"),TlGXWLYsV1z(u"࠭วๅัํ๊ࠬᱯ"),tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠧๆ๊ส่๏ีࠧᱰ"),zmcGfOdvAjsELeJlP(u"ࠨษ็฽ฬ๊ๅࠨᱱ"),CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠩส฽๊อไࠨᱲ")]
					if not any(RoUcHZgQ3BkiYdCKFSu4TsfpW in JJwnocyLUxHI2jlKF4Y for RoUcHZgQ3BkiYdCKFSu4TsfpW in AJR9ldxo4fTe): JJwnocyLUxHI2jlKF4Y = JJwnocyLUxHI2jlKF4Y.replace(ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠪห้࠭ᱳ"),iiy37aKq0pCEIOwfcTh61xb4U)
					JJwnocyLUxHI2jlKF4Y = JJwnocyLUxHI2jlKF4Y.replace(FRYcH4KL7e9gv5pEB(u"ࠫฬิั๋ࠩᱴ"),UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠬอฮา๋ࠪᱵ")).replace(hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"࠭วอ่หํࠬᱶ"),L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠧศฮ้ฬ๏࠭ᱷ")).replace(y6y5HtgXO4TkUbwVZ(u"ࠨ฻สส้๐็ࠨᱸ"),xpT28sXu051(u"ࠩ฼หห๊๊ࠨᱹ"))
					JJwnocyLUxHI2jlKF4Y = JJwnocyLUxHI2jlKF4Y.replace(sVzojQerUqX(u"ࠪหั์ศ๋้ࠪᱺ"),xpT28sXu051(u"ࠫฬาๆษ์ࠪᱻ")).replace(AbqCJZdWQP9j(u"ࠬ฿ัษ์๊ࠫᱼ"),tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ู࠭าสํࠫᱽ")).replace(L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠧา๊่หู๋๊่ࠩ᱾"),UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠨำ๋้ฬ์ำ๋ࠩ᱿"))
					JJwnocyLUxHI2jlKF4Y = JJwnocyLUxHI2jlKF4Y.replace(MgP8OjoaiWQEVG59(u"ࠩ฽ีอ๐็ࠨᲀ"),zmcGfOdvAjsELeJlP(u"ࠪ฾ึฮ๊ࠨᲁ")).replace(uuExaKGL7UONtevRd(u"ࠫํࠦๅิๆึ่ฬะࠧᲂ"),HtK4o2sTPgA78U(u"๋ࠬำๅี็หฯ࠭ᲃ")).replace(yJeq1BjfiO4NFuwIEzxVLK6b9s(u"࠭ว฻ษ้ํࠬᲄ"),zmcGfOdvAjsELeJlP(u"ࠧศ฼ส๊๏࠭ᲅ"))
					JJwnocyLUxHI2jlKF4Y = JJwnocyLUxHI2jlKF4Y.replace(hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠨฬสี๏ิ๊ࠨᲆ"),ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠩอหึ๐ฮࠨᲇ")).replace(zmcGfOdvAjsELeJlP(u"ࠪา๏อไࠡ฻็้๏࠭ᲈ"),ZchUJdM93pTA7zG5(u"ࠫำ๐วๅࠩᲉ")).replace(L90uqo28xEKSFUwYTcm51yRWZIkft(u"๋่ࠬิ์ๅ๎์࠭ᲊ"),FRYcH4KL7e9gv5pEB(u"࠭ๅ้ีํๆ๎࠭᲋"))
					JJwnocyLUxHI2jlKF4Y = JJwnocyLUxHI2jlKF4Y.replace(AbqCJZdWQP9j(u"่่ࠧาํࠬ᲌"),L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠨ้้ำ๏࠭᲍")).replace(hhQwbeiNLoqFjX90fB7aG8VAs(u"๊๊ࠩิ๐็ࠨ᲎"),XrTw01KtLzbpoyMf(u"๋๋ࠪี๊ࠨ᲏")).replace(SaB5hx3PZwXRLtKgrTfQvId(u"ࠫํัววไํ๋ࠬᲐ"),xpT28sXu051(u"ࠬ๎หศศๅ๎ࠬᲑ"))
					JJwnocyLUxHI2jlKF4Y = JJwnocyLUxHI2jlKF4Y.replace(ZchUJdM93pTA7zG5(u"࠭สๅ์ไึ๏๎ๆ๋้ࠪᲒ"),L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠧหๆไึ๏๎ๆࠨᲓ")).replace(TlGXWLYsV1z(u"ࠨฬ็ๅื๐่็์๊ࠫᲔ"),jXE2YHkswT8y(u"ࠩอ่ๆุ๊้่ࠪᲕ")).replace(tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠪ์้ࠥัห๊้ࠫᲖ"),xpT28sXu051(u"ࠫํ้ัห๊้ࠫᲗ"))
					JJwnocyLUxHI2jlKF4Y = JJwnocyLUxHI2jlKF4Y.replace(CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠬอไฮษ็๎์࠭Ი"),hhQwbeiNLoqFjX90fB7aG8VAs(u"࠭อศๆํ๋ࠬᲙ")).replace(y6y5HtgXO4TkUbwVZ(u"ࠧๆ๊ึ໐็๐ࠧᲚ"),EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠨ็๋ื๏่้ࠨᲛ")).replace(sVzojQerUqX(u"ࠩส่ฬ์ๅ๋ࠩᲜ"),ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠪห๋๋๊ࠨᲝ"))
					JJwnocyLUxHI2jlKF4Y = JJwnocyLUxHI2jlKF4Y.replace(AbqCJZdWQP9j(u"ࠫฬ๊ๅิๆึ่ฬะࠧᲞ"),y6y5HtgXO4TkUbwVZ(u"๋ࠬำๅี็หฯ࠭Ჟ")).replace(hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"࠭วๅสิห๊าࠧᲠ"),EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠧษำส้ั࠭Ს")).replace(zmcGfOdvAjsELeJlP(u"ࠨๅสีฯ๎ๆࠨᲢ"),MgP8OjoaiWQEVG59(u"ࠩๆีฯ๎ๆࠨᲣ"))
					JJwnocyLUxHI2jlKF4Y = JJwnocyLUxHI2jlKF4Y.replace(yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠪัึ๎ศࠨᲤ"),yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠫาืศࠨᲥ")).replace(PtkEvXAqif14G20QZsaSyT(u"ࠬอไศ่สุ๏ีࠧᲦ"),hhQwbeiNLoqFjX90fB7aG8VAs(u"࠭ว็ษื๎ิ࠭Ყ")).replace(jXE2YHkswT8y(u"ࠧศีํ์๏ํࠧᲨ"),hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠨษึ๎ํ๐ࠧᲩ"))
					JJwnocyLUxHI2jlKF4Y = JJwnocyLUxHI2jlKF4Y.replace(L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠩ฼ีอ๏ࠧᲪ"),zmcGfOdvAjsELeJlP(u"ࠪ฽ึฮ๊ࠨᲫ")).replace(MgP8OjoaiWQEVG59(u"ࠫฯืใ๊ࠩᲬ"),XrTw01KtLzbpoyMf(u"ࠬะัไ์ࠪᲭ")).replace(yJeq1BjfiO4NFuwIEzxVLK6b9s(u"࠭สาๅํ๋ࠬᲮ"),PtkEvXAqif14G20QZsaSyT(u"ࠧหำๆ๎ࠬᲯ")).replace(tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠨษ็้฻อแࠨᲰ"),ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ฺ่ࠩฬ็ࠧᲱ"))
					JJwnocyLUxHI2jlKF4Y = JJwnocyLUxHI2jlKF4Y.replace(tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠪี๏อึ๋ࠩᲲ"),IpC4qHXRuyNFjzWv(u"ࠫึ๐วืหࠪᲳ")).replace(YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠬื๊ศุ๊ࠫᲴ"),L90uqo28xEKSFUwYTcm51yRWZIkft(u"࠭ั๋ษูอࠬᲵ")).replace(uuExaKGL7UONtevRd(u"ࠧศีํ์๏ํࠧᲶ"),ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠨษึ๎ํ๐ࠧᲷ"))
					JJwnocyLUxHI2jlKF4Y = JJwnocyLUxHI2jlKF4Y.replace(IpC4qHXRuyNFjzWv(u"ࠩๆ์๊๐ฯ๊ࠩᲸ"),FRYcH4KL7e9gv5pEB(u"ࠪ็ํ๋๊ะ์ࠪᲹ")).replace(XrTw01KtLzbpoyMf(u"่ࠫ๎ๅ๋ัํ๋ࠬᲺ"),L90uqo28xEKSFUwYTcm51yRWZIkft(u"้่ࠬๆ์า๎ࠬ᲻")).replace(UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"࠭ว็์่๎ࠬ᲼"),xpT28sXu051(u"ࠧศ่่๎ࠬᲽ"))
					JJwnocyLUxHI2jlKF4Y = JJwnocyLUxHI2jlKF4Y.replace(zmcGfOdvAjsELeJlP(u"ࠨษ้๎๊๐ิ็ࠩᲾ"),y6y5HtgXO4TkUbwVZ(u"ࠩส๊๊๐ิ็ࠩᲿ")).replace(ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠪห๋๋้ࠨ᳀"),IpC4qHXRuyNFjzWv(u"ࠫฬ์ๅ๋ึ้ࠫ᳁")).replace(jXE2YHkswT8y(u"ࠬอๆๆ์ࠪ᳂"),Y41NvKfOroMzGB8sEHy7wbXlc5(u"࠭ว็็ํุ๋࠭᳃"))
					JJwnocyLUxHI2jlKF4Y = JJwnocyLUxHI2jlKF4Y.replace(UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠧศ่่๎ู์ิ็ࠩ᳄"),JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠨษ้้๏ฺๆࠨ᳅")).replace(jXE2YHkswT8y(u"ࠩส่ฬ์ๅ๋ึ้ࠫ᳆"),LyNiIHPOwD3hCUYEFM7(u"ࠪห๋๋๊ี่ࠪ᳇")).replace(y6y5HtgXO4TkUbwVZ(u"ࠫฬ็ไศ็ุ้๊ࠣำๅษอࠫ᳈"),TlGXWLYsV1z(u"ࠬอแๅษ่ࠤํ๋ำๅี็หฯ࠭᳉"))
					JJwnocyLUxHI2jlKF4Y = JJwnocyLUxHI2jlKF4Y.replace(Wc5GekRC0HQLz7,iFBmE2MUIpSu34wsd7Rf6z).strip(tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"࠭࠭ࠨ᳊")).strip(iFBmE2MUIpSu34wsd7Rf6z)
				if JJwnocyLUxHI2jlKF4Y not in list(EeCo9tOcL2dIZu75g.keys()): EeCo9tOcL2dIZu75g[JJwnocyLUxHI2jlKF4Y] = {}
				EeCo9tOcL2dIZu75g[JJwnocyLUxHI2jlKF4Y][ekEOd3mqAThaBDUoIrntuGRjYW] = [synCYOiMR789twmfr,JJwnocyLUxHI2jlKF4Y,kMqh74TPvpSDar59xQUjAyVlHes,Cpf9s3c0Zngj7XE,GmrA8hvBgN4bDdEWXS9nVMtU,F50ngOyjSvAcVRtdafJsiBkP9Yx,U94JwhRgpXCOe5,YGNomIp2tDSR6ncf,BSmlfc08nJ]
		YMQXP2BGeK86CEb(PdkZHNBlpg2b7DmX6qRiyVa,AbqCJZdWQP9j(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡖࡍ࡙ࡋࡓࠨ᳋"),AbqCJZdWQP9j(u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡗࡎ࡚ࡅࡔࡡࡄࡐࡑ࠭᳌"),EeCo9tOcL2dIZu75g,VaeMF1mIjQ5iLtfGcB)
		bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ᳍"),UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠪฮ๊ࠦฬๅสࠣะ๊๐ูࠡษ็ว็ูวๆࠢส่๊ะ่โำฬࠤๆ๐ࠠศๆหี๋อๅอࠩ᳎"))
	qI2s0ZN7uj(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U)
	KEPGn8jNAtmDB2yS0kZiX4MCw()
	return
def ta70LOknIHDBZf8WU1GR(skyPuAlLvecbtRZfB0pzIGd34n7xX9,FG615TlEM78tKb):
	iQ2tN1nLmJH7GCchv4u0VoSKlb = LyNiIHPOwD3hCUYEFM7(u"ࡆࡢ࡮ࡶࡩể")
	hu4rXM9KgvPtmSkByDwOsR = g6ghGH4aBEYkTl3vbJZ
	g6ghGH4aBEYkTl3vbJZ[:] = []
	if iQ2tN1nLmJH7GCchv4u0VoSKlb and Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠫࡤࡉࡒࡆࡃࡗࡉࡓࡋࡗࡠࠩ᳏") not in FG615TlEM78tKb:
		EA7FzO1kMZGQXDd2giB0cwLom = QKzCiBOWZus1nSv(PdkZHNBlpg2b7DmX6qRiyVa,GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠬࡲࡩࡴࡶࠪ᳐"),CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡋࡓࡘ࡛࠭᳑"),UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡌࡔ࡙࡜࡟ࠨ᳒")+skyPuAlLvecbtRZfB0pzIGd34n7xX9)
	elif SaB5hx3PZwXRLtKgrTfQvId(u"ࠨࡡࡏࡍ࡛ࡋ࡟ࠨ᳓") not in FG615TlEM78tKb or EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠩࡢ࡚ࡔࡊ࡟ࠨ᳔") not in FG615TlEM78tKb:
		import uUbDljY0SN
		aZtYlicqMKUFPkBCX2AONHwJ4 = EMO8gy4LrsNTh0knZwpSeU75APW(u"่้ࠪษำโࠢ็ำ๏้ࠠๆึๆ่ฮࠦแ๋๊ࠢิฬࠦวๅ็๋ๆ฾ࠦ࠮๊ࠡิืฬ๊ษࠡษ็า฼ษࠠไษ้ࠤๆ๐็ศࠢอๅฬ฻๊ๅࠢสฺ่๊ใๅหࠣ࠲ࠥษะศࠢสฺ่๊ใๅห่ࠣ๏ูสࠡฯฯฬࠥ็ฬาสࠣษึูวๅ๊ࠢิ์ࠦวๅ็ื็้ฯࠠฦๆ์ࠤฬ๊ๅษำ่ะ๋ࠥๆࠡไสส๊ฯࠠฯั่หฯࠦวๅสิ๊ฬ๋ฬࠨ᳕")
		if SaB5hx3PZwXRLtKgrTfQvId(u"ࠫࡤࡒࡉࡗࡇࡢ᳖ࠫ") not in FG615TlEM78tKb:
			try: uUbDljY0SN.CFhvzLMJ5KiywpIfANxqgHGrloT(skyPuAlLvecbtRZfB0pzIGd34n7xX9,yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠬ࡜ࡏࡅࡡࡘࡒࡐࡔࡏࡘࡐࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇ᳗ࠫ"),iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,FG615TlEM78tKb+FRYcH4KL7e9gv5pEB(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢ᳘ࠫ"),EMO8gy4LrsNTh0knZwpSeU75APW(u"ࡇࡣ࡯ࡷࡪỄ"))
			except: bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠧๆ๊ๅ฽ࠥๆࡉࡑࡖ࡙ࠤ้๊แ๋ัํ์์อสࠨ᳙"),aZtYlicqMKUFPkBCX2AONHwJ4)
			try: uUbDljY0SN.CFhvzLMJ5KiywpIfANxqgHGrloT(skyPuAlLvecbtRZfB0pzIGd34n7xX9,ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠨࡘࡒࡈࡤࡓࡏࡗࡋࡈࡗࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭᳚"),iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,FG615TlEM78tKb+TlGXWLYsV1z(u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ᳛"),Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࡈࡤࡰࡸ࡫ễ"))
			except: bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,MgP8OjoaiWQEVG59(u"้ࠪํู่ࠡโࡌࡔ࡙࡜ࠠๅๆไ๎ิ๐่่ษอ᳜ࠫ"),aZtYlicqMKUFPkBCX2AONHwJ4)
			try: uUbDljY0SN.CFhvzLMJ5KiywpIfANxqgHGrloT(skyPuAlLvecbtRZfB0pzIGd34n7xX9,EMO8gy4LrsNTh0knZwpSeU75APW(u"࡛ࠫࡕࡄࡠࡕࡈࡖࡎࡋࡓࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅ᳝ࠩ"),iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,FG615TlEM78tKb+LyNiIHPOwD3hCUYEFM7(u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡ᳞ࠪ"),L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࡉࡥࡱࡹࡥỆ"))
			except: bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,FRYcH4KL7e9gv5pEB(u"࠭ๅ้ไ฼ࠤๅࡏࡐࡕࡘ่้ࠣ็๊ะ์๋๋ฬะ᳟ࠧ"),aZtYlicqMKUFPkBCX2AONHwJ4)
		if PtkEvXAqif14G20QZsaSyT(u"ࠧࡠࡘࡒࡈࡤ࠭᳠") not in FG615TlEM78tKb:
			try: uUbDljY0SN.CFhvzLMJ5KiywpIfANxqgHGrloT(skyPuAlLvecbtRZfB0pzIGd34n7xX9,Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠨࡎࡌ࡚ࡊࡥࡕࡏࡍࡑࡓ࡜ࡔ࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨ᳡"),iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,FG615TlEM78tKb+zmcGfOdvAjsELeJlP(u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥ᳢ࠧ"),GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࡊࡦࡲࡳࡦệ"))
			except: bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"้ࠪํู่ࠡโࡌࡔ࡙࡜ࠠๅๆๅ๊ํอสࠨ᳣"),aZtYlicqMKUFPkBCX2AONHwJ4)
			try: uUbDljY0SN.CFhvzLMJ5KiywpIfANxqgHGrloT(skyPuAlLvecbtRZfB0pzIGd34n7xX9,IpC4qHXRuyNFjzWv(u"ࠫࡑࡏࡖࡆࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆ᳤ࠪ"),iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,FG615TlEM78tKb+vODxLKW5Ql6r4Fbm8(u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡ᳥ࠪ"),FRYcH4KL7e9gv5pEB(u"ࡋࡧ࡬ࡴࡧỈ"))
			except: bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,TlGXWLYsV1z(u"࠭ๅ้ไ฼ࠤๅࡏࡐࡕࡘ่้่ࠣๆ้ษอ᳦ࠫ"),aZtYlicqMKUFPkBCX2AONHwJ4)
		EA7FzO1kMZGQXDd2giB0cwLom = g6ghGH4aBEYkTl3vbJZ
		if iQ2tN1nLmJH7GCchv4u0VoSKlb: YMQXP2BGeK86CEb(PdkZHNBlpg2b7DmX6qRiyVa,hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡌࡔ࡙࡜᳧ࠧ"),MgP8OjoaiWQEVG59(u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡍࡕ࡚ࡖࡠ᳨ࠩ")+skyPuAlLvecbtRZfB0pzIGd34n7xX9,EA7FzO1kMZGQXDd2giB0cwLom,VaeMF1mIjQ5iLtfGcB)
	g6ghGH4aBEYkTl3vbJZ[:] = hu4rXM9KgvPtmSkByDwOsR
	return EA7FzO1kMZGQXDd2giB0cwLom
def T3ksWRpfxniNg1z7lE69(skyPuAlLvecbtRZfB0pzIGd34n7xX9,FG615TlEM78tKb):
	iQ2tN1nLmJH7GCchv4u0VoSKlb = IpC4qHXRuyNFjzWv(u"ࡌࡡ࡭ࡵࡨỉ")
	hu4rXM9KgvPtmSkByDwOsR = g6ghGH4aBEYkTl3vbJZ
	g6ghGH4aBEYkTl3vbJZ[:] = []
	if iQ2tN1nLmJH7GCchv4u0VoSKlb and GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠩࡢࡇࡗࡋࡁࡕࡇࡑࡉ࡜ࡥࠧᳩ") not in FG615TlEM78tKb:
		EA7FzO1kMZGQXDd2giB0cwLom = QKzCiBOWZus1nSv(PdkZHNBlpg2b7DmX6qRiyVa,sVzojQerUqX(u"ࠪࡰ࡮ࡹࡴࠨᳪ"),hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡍ࠴ࡗࠪᳫ"),PtkEvXAqif14G20QZsaSyT(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡎ࠵ࡘࡣࠬᳬ")+skyPuAlLvecbtRZfB0pzIGd34n7xX9)
	elif TlGXWLYsV1z(u"࠭࡟ࡍࡋ࡙ࡉࡤ᳭࠭") not in FG615TlEM78tKb or HtK4o2sTPgA78U(u"ࠧࡠࡘࡒࡈࡤ࠭ᳮ") not in FG615TlEM78tKb:
		import FwKQq7S2Ce
		aZtYlicqMKUFPkBCX2AONHwJ4 = EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠨๆ็วุ็ࠠๅัํ็๋ࠥิไๆฬࠤๆ๐่ࠠาสࠤฬ๊ๅ้ไ฼ࠤ࠳่ࠦาีส่ฮࠦวๅะฺว้ࠥว็ࠢไ๎์อࠠหใสู๏๊ࠠศๆุ่่๊ษࠡ࠰ࠣวีอࠠศๆุ่่๊ษࠡๆํืฯࠦออสࠣๅัืศࠡวิืฬ๊่ࠠา๊ࠤฬ๊ๅีๅ็อࠥหไ๊ࠢส่๊ฮัๆฮ้๋ࠣࠦโศศ่อࠥิฯๆษอࠤฬ๊ศา่ส้ั࠭ᳯ")
		if sVzojQerUqX(u"ࠩࡢࡐࡎ࡜ࡅࡠࠩᳰ") not in FG615TlEM78tKb:
			try: FwKQq7S2Ce.CFhvzLMJ5KiywpIfANxqgHGrloT(skyPuAlLvecbtRZfB0pzIGd34n7xX9,GGx4qyKP1vUtRghsE2WfaHLMXZ(u"࡚ࠪࡔࡊ࡟ࡖࡐࡎࡒࡔ࡝ࡎࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩᳱ"),iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,FG615TlEM78tKb+UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᳲ"),ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࡆࡢ࡮ࡶࡩỊ"))
			except: bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"๋่ࠬใ฻ࠣไࡒ࠹ࡕࠡๆ็ๅ๏ี๊้้สฮࠬᳳ"),aZtYlicqMKUFPkBCX2AONHwJ4)
			try: FwKQq7S2Ce.CFhvzLMJ5KiywpIfANxqgHGrloT(skyPuAlLvecbtRZfB0pzIGd34n7xX9,LyNiIHPOwD3hCUYEFM7(u"࠭ࡖࡐࡆࡢࡑࡔ࡜ࡉࡆࡕࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫ᳴"),iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,FG615TlEM78tKb+ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᳵ"),y6y5HtgXO4TkUbwVZ(u"ࡇࡣ࡯ࡷࡪị"))
			except: bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,PtkEvXAqif14G20QZsaSyT(u"ࠨ็๋ๆ฾ࠦเࡎ࠵ࡘࠤ้๊แ๋ัํ์์อสࠨᳶ"),aZtYlicqMKUFPkBCX2AONHwJ4)
			try: FwKQq7S2Ce.CFhvzLMJ5KiywpIfANxqgHGrloT(skyPuAlLvecbtRZfB0pzIGd34n7xX9,YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"࡙ࠩࡓࡉࡥࡓࡆࡔࡌࡉࡘࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧ᳷"),iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,FG615TlEM78tKb+Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ᳸"),vODxLKW5Ql6r4Fbm8(u"ࡈࡤࡰࡸ࡫Ọ"))
			except: bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,xpT28sXu051(u"๊ࠫ๎โฺࠢใࡑ࠸࡛ࠠๅๆไ๎ิ๐่่ษอࠫ᳹"),aZtYlicqMKUFPkBCX2AONHwJ4)
		if MgP8OjoaiWQEVG59(u"ࠬࡥࡖࡐࡆࡢࠫᳺ") not in FG615TlEM78tKb:
			try: FwKQq7S2Ce.CFhvzLMJ5KiywpIfANxqgHGrloT(skyPuAlLvecbtRZfB0pzIGd34n7xX9,TlGXWLYsV1z(u"࠭ࡌࡊࡘࡈࡣ࡚ࡔࡋࡏࡑ࡚ࡒࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭᳻"),iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,FG615TlEM78tKb+zmcGfOdvAjsELeJlP(u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ᳼"),ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࡉࡥࡱࡹࡥọ"))
			except: bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,SaB5hx3PZwXRLtKgrTfQvId(u"ࠨ็๋ๆ฾ࠦเࡎ࠵ࡘࠤ้๊โ็๊สฮࠬ᳽"),aZtYlicqMKUFPkBCX2AONHwJ4)
			try: FwKQq7S2Ce.CFhvzLMJ5KiywpIfANxqgHGrloT(skyPuAlLvecbtRZfB0pzIGd34n7xX9,ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠩࡏࡍ࡛ࡋ࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨ᳾"),iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,FG615TlEM78tKb+HtK4o2sTPgA78U(u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ᳿"),yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࡊࡦࡲࡳࡦỎ"))
			except: bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,GGx4qyKP1vUtRghsE2WfaHLMXZ(u"๊ࠫ๎โฺࠢใࡑ࠸࡛ࠠๅๆๅ๊ํอสࠨᴀ"),aZtYlicqMKUFPkBCX2AONHwJ4)
		EA7FzO1kMZGQXDd2giB0cwLom = g6ghGH4aBEYkTl3vbJZ
		if iQ2tN1nLmJH7GCchv4u0VoSKlb: YMQXP2BGeK86CEb(PdkZHNBlpg2b7DmX6qRiyVa,ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡎ࠵ࡘࠫᴁ"),JZszNnIEMAx28Yao0yqhiXGKOPb(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡏ࠶࡙ࡤ࠭ᴂ")+skyPuAlLvecbtRZfB0pzIGd34n7xX9,EA7FzO1kMZGQXDd2giB0cwLom,VaeMF1mIjQ5iLtfGcB)
	g6ghGH4aBEYkTl3vbJZ[:] = hu4rXM9KgvPtmSkByDwOsR
	return EA7FzO1kMZGQXDd2giB0cwLom
def yl4Pf2poLgmqT8VF0xwGKQrh1UEnHk(skyPuAlLvecbtRZfB0pzIGd34n7xX9,FG615TlEM78tKb,kMr9s6e7phZlJ):
	qI2s0ZN7uj(None,None,Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࡋࡧ࡬ࡴࡧỏ"))
	if kMr9s6e7phZlJ: PPYAxHMiQIE(BF6QAiLUNHh7rKOugaw)
	elif vODxLKW5Ql6r4Fbm8(u"ࠧࡠࡅࡕࡉࡆ࡚ࡅࡏࡇ࡚ࡣࠬᴃ") in FG615TlEM78tKb and not kMr9s6e7phZlJ: PPYAxHMiQIE(rGPen6cSMHQkAywh8vqI9JXiD2)
	IvoHm2GsXcTrztuq53AiNlQkMK94 = FG615TlEM78tKb.replace(TlGXWLYsV1z(u"ࠨࡡࡆࡖࡊࡇࡔࡆࡐࡈ࡛ࡤ࠭ᴄ"),iiy37aKq0pCEIOwfcTh61xb4U).replace(tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᴅ"),iiy37aKq0pCEIOwfcTh61xb4U).replace(IpC4qHXRuyNFjzWv(u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧᴆ"),iiy37aKq0pCEIOwfcTh61xb4U)
	if not kMr9s6e7phZlJ:
		bP6z3OSLp7va(EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠫࡱ࡯࡮࡬ࠩᴇ"),uuExaKGL7UONtevRd(u"ࠬะอะ์ฮࠤ็อฦๆหࠣห้ษโิษ่ࠫᴈ"),iiy37aKq0pCEIOwfcTh61xb4U,EMO8gy4LrsNTh0knZwpSeU75APW(u"࠻࠻࠹ẁ"),iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"࠭࡟ࡄࡔࡈࡅ࡙ࡋࡎࡆ࡙ࡢࠫᴉ")+IvoHm2GsXcTrztuq53AiNlQkMK94,iiy37aKq0pCEIOwfcTh61xb4U,{yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᴊ"):skyPuAlLvecbtRZfB0pzIGd34n7xX9})
		bP6z3OSLp7va(sVzojQerUqX(u"ࠨ࡮࡬ࡲࡰ࠭ᴋ"),PSwfZcdRYhpl5Igqz8xOEk67+SaB5hx3PZwXRLtKgrTfQvId(u"ࠩࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦࠧᴌ")+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,y6y5HtgXO4TkUbwVZ(u"࠾࠿࠹࠺Ẃ"))
		dVFTrX63LKjk0Ba = [CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠪวๆ๊วๆࠩᴍ"),CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ู๊ࠫไิๆสฮࠬᴎ"),tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"๋ࠬำาฯํหฯ࠭ᴏ"),CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"࠭ศาษ่ะࠬᴐ"),EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠧฤูไห้่ࠦไำอ์๋࠭ᴑ"),UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠨำฺ่ฬ์ࠧᴒ"),TlGXWLYsV1z(u"ࠩฦัิั࠭ฤะิࠫᴓ"),hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠪื้อำๅࠩᴔ"),L90uqo28xEKSFUwYTcm51yRWZIkft(u"๊ࠫ๎ำ๋ไ์ࠫᴕ"),XrTw01KtLzbpoyMf(u"ࠬษิ่ำ࠰ว่ััࠨᴖ"),HtK4o2sTPgA78U(u"࠭วๅฤ้ࠫᴗ"),ZchUJdM93pTA7zG5(u"ࠧืฯๆࠫᴘ"),xpT28sXu051(u"ࠨำํห฻ฯࠧᴙ"),xpT28sXu051(u"้ࠩ๎ฯ็ไไีࠪᴚ"),TlGXWLYsV1z(u"้๊ࠪัไ๋่ࠪᴛ"),AbqCJZdWQP9j(u"ࠫอัࠠฮ์ࠪᴜ"),ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠬี๊็์ฬࠫᴝ"),jXE2YHkswT8y(u"࠭ำ็๊สฮࠬᴞ"),Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠧฤะิํࠬᴟ")]
		kMr9s6e7phZlJ = FGTfwsjNrB8DvKSZhLIQAb1JnO
		for o5LjUW1RicBMOVrdZqtFYGeKvsN73k in dVFTrX63LKjk0Ba:
			kMr9s6e7phZlJ += YYJQyRskpX8jv
			bP6z3OSLp7va(vODxLKW5Ql6r4Fbm8(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᴠ"),ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+o5LjUW1RicBMOVrdZqtFYGeKvsN73k,iiy37aKq0pCEIOwfcTh61xb4U,y6y5HtgXO4TkUbwVZ(u"࠽࠶࠴ẃ"),iiy37aKq0pCEIOwfcTh61xb4U,str(kMr9s6e7phZlJ),IvoHm2GsXcTrztuq53AiNlQkMK94,iiy37aKq0pCEIOwfcTh61xb4U,{y6y5HtgXO4TkUbwVZ(u"ࠩࡩࡳࡱࡪࡥࡳࠩᴡ"):skyPuAlLvecbtRZfB0pzIGd34n7xX9})
	else:
		qqU3jxJViAaCnf = [y6y5HtgXO4TkUbwVZ(u"ࠪหๆ๊วๆࠩᴢ"),tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠫࡲࡵࡶࡪࡧࠪᴣ"),AbqCJZdWQP9j(u"ࠬ็๊ๅ็ࠪᴤ"),tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"࠭แๅ็ࠪᴥ")]
		tN1Y9wIDQqrE6xMhkl = [FRYcH4KL7e9gv5pEB(u"ࠧๆี็ื้࠭ᴦ"),xpT28sXu051(u"ࠨࡵࡨࡶ࡮࡫ࡳࠨᴧ")]
		iRO4E1My0QVdtFJPL7Bhe53AC6TmGj = [Y41NvKfOroMzGB8sEHy7wbXlc5(u"่ࠩืฬือࠨᴨ"),ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ุ้ࠪือ๋ษอࠫᴩ")]
		kbP81YHE0sjloI = [AbqCJZdWQP9j(u"ࠫอืวๆฮࠪᴪ"),xpT28sXu051(u"ࠬࡹࡨࡰࡹࠪᴫ"),FRYcH4KL7e9gv5pEB(u"࠭สๅใี๎ํ์ࠧᴬ"),SaB5hx3PZwXRLtKgrTfQvId(u"ࠧหๆํๅื๐่็ࠩᴭ")]
		VV8tBcd1EfCA74Qins5Zmy = [AbqCJZdWQP9j(u"ࠨษ้้๏࠭ᴮ"),IpC4qHXRuyNFjzWv(u"ࠩๆีฯ๎ๆࠨᴯ"),hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠪ็ฬืส้่ࠪᴰ"),L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠫࡰ࡯ࡤࡴࠩᴱ"),Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠬ฽แๅࠩᴲ"),ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"࠭วุใส่ࠬᴳ")]
		ruXSznHvJWKUF = [uuExaKGL7UONtevRd(u"ࠧา็ูห๋࠭ᴴ")]
		GGbxVPw0MrO = [HtK4o2sTPgA78U(u"ࠨษะำะ࠭ᴵ"),jXE2YHkswT8y(u"ࠩสาึ࠭ᴶ"),tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"้ࠪํิัࠨᴷ"),AbqCJZdWQP9j(u"ࠫัี๊ะࠩᴸ"),UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"๋ࠬึศใࠪᴹ"),XrTw01KtLzbpoyMf(u"࠭อะ์ฮࠫᴺ")]
		swDY9o1NCX7mtcR3Vy8la = [HtK4o2sTPgA78U(u"ࠧิๆสื้࠭ᴻ"),CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠨี็ื้ํࠧᴼ")]
		RYqJ572y9vAcrU = [HtK4o2sTPgA78U(u"ࠩส฾ฬ์๊ࠨᴽ"),zmcGfOdvAjsELeJlP(u"้ࠪํู๊ใ๋ࠪᴾ"),TlGXWLYsV1z(u"่๊๊ࠫษࠩᴿ"),HtK4o2sTPgA78U(u"ࠬำแๅࠩᵀ"),CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"࠭࡭ࡶࡵ࡬ࡧࠬᵁ")]
		w8hsf9erXJ = [tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠧศๅฮีࠬᵂ"),yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠨษื๋ึ࠭ᵃ"),hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"่้ࠩ๏ุ็ࠨᵄ"),CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠪห฾๊้ࠨᵅ"),AbqCJZdWQP9j(u"๊ࠫิสศำ๊ࠫᵆ"),ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"๋ࠬฮหษิหฯ࠭ᵇ"),CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"࠭วใ๊์ࠫᵈ")]
		bczIhv9stYPHxNTG8RiX5 = [XrTw01KtLzbpoyMf(u"ࠧศๆส๊ࠬᵉ"),tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠨฯส่๏࠭ᵊ"),CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"่ࠩฯอะࠧᵋ"),zmcGfOdvAjsELeJlP(u"ࠪีฬฬฬࠨᵌ")]
		LBoZOI1WxV9kqzdK6n = [EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠫ฻ำใࠨᵍ"),jXE2YHkswT8y(u"้่ࠬๆ์า๎ࠬᵎ")]
		eyQu8NfoI1mEF4a0D = [vODxLKW5Ql6r4Fbm8(u"࠭ั๋ษู๋ࠬᵏ"),jXE2YHkswT8y(u"ࠧไ๊ิ๋ࠬᵐ"),PtkEvXAqif14G20QZsaSyT(u"ࠨ็ุหึ฿็ࠨᵑ"),UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠩื์ฯ࠭ᵒ"),EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠪี๏อึสࠩᵓ")]
		SPU5HV0bxyTL8dOFf = [ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"๋ࠫ๐สโๆๆืࠬᵔ"),ZchUJdM93pTA7zG5(u"ࠬࡴࡥࡵࡨ࡯࡭ࡽ࠭ᵕ"),SaB5hx3PZwXRLtKgrTfQvId(u"࠭ๆ๋ฬไ่๏้ำࠨᵖ")]
		vNK3wQ1O52pmfsYoqZMXLt = [PtkEvXAqif14G20QZsaSyT(u"ࠧๆ็ฮ่๏์ࠧᵗ"),MgP8OjoaiWQEVG59(u"ࠨษืาฬ฻ࠧᵘ"),uuExaKGL7UONtevRd(u"้ࠩะํ๋ࠧᵙ")]
		FaD6NxfSIbzZimr9d4wOjQMkYhn5 = [LyNiIHPOwD3hCUYEFM7(u"ࠪฬะࠦอ๋ࠩᵚ"),AbqCJZdWQP9j(u"ࠫࡱ࡯ࡶࡦࠩᵛ"),tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"่ࠬๆศ้ࠪᵜ"),jXE2YHkswT8y(u"࠭โ็๊สฮࠬᵝ")]
		wrpg82k16W0LTqv = [TlGXWLYsV1z(u"ࠧะ์้ࠫᵞ"),AbqCJZdWQP9j(u"ࠨษา฽๏ํࠧᵟ"),PtkEvXAqif14G20QZsaSyT(u"ࠩี๎ฬืวหࠩᵠ"),SaB5hx3PZwXRLtKgrTfQvId(u"่ࠪ฼๋๊ศฬࠪᵡ"),MgP8OjoaiWQEVG59(u"ࠫิ฿วยࠩᵢ"),L90uqo28xEKSFUwYTcm51yRWZIkft(u"่ࠬัศ่ࠪᵣ"),hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"࠭โึษษำࠬᵤ"),jXE2YHkswT8y(u"ࠧาอสลࠬᵥ"),MgP8OjoaiWQEVG59(u"ࠨ็ิะ฾๐็ࠨᵦ"),JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠩสิฬ์ࠧᵧ"),CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠪหุ๊วๆࠩᵨ"),zmcGfOdvAjsELeJlP(u"ࠫฯ๎วี์ะࠫᵩ"),GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠬิืษࠩᵪ"),zmcGfOdvAjsELeJlP(u"࠭อ้ิ๋๎ࠬᵫ"),CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ฺࠧฬหหฯ࠭ᵬ"),tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠨ็๋ห้๐ฯࠨᵭ"),ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"้ࠩ์ฬ฿๊ࠨᵮ"),vODxLKW5Ql6r4Fbm8(u"ࠪ฽็อฦะࠩᵯ"),jXE2YHkswT8y(u"ࠫฬ์วี์าࠫᵰ")]
		M85XcFxkITEyr3me = [tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠬ࠸࠰࠲࠲ࠪᵱ"),jXE2YHkswT8y(u"࠭࠲࠱࠳࠴ࠫᵲ"),MgP8OjoaiWQEVG59(u"ࠧ࠳࠲࠴࠶ࠬᵳ"),EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠨ࠴࠳࠵࠸࠭ᵴ"),CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠩ࠵࠴࠶࠺ࠧᵵ"),hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠪ࠶࠵࠷࠵ࠨᵶ"),hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠫ࠷࠶࠱࠷ࠩᵷ"),ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠬ࠸࠰࠲࠹ࠪᵸ"),uuExaKGL7UONtevRd(u"࠭࠲࠱࠳࠻ࠫᵹ"),uuExaKGL7UONtevRd(u"ࠧ࠳࠲࠴࠽ࠬᵺ"),TlGXWLYsV1z(u"ࠨ࠴࠳࠶࠵࠭ᵻ"),IpC4qHXRuyNFjzWv(u"ࠩ࠵࠴࠷࠷ࠧᵼ"),xpT28sXu051(u"ࠪ࠶࠵࠸࠲ࠨᵽ"),UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠫ࠷࠶࠲࠴ࠩᵾ"),JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠬ࠸࠰࠳࠶ࠪᵿ"),hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"࠭࠲࠱࠴࠸ࠫᶀ"),TlGXWLYsV1z(u"ࠧ࠳࠲࠵࠺ࠬᶁ"),XrTw01KtLzbpoyMf(u"ࠨ࠴࠳࠶࠼࠭ᶂ"),IpC4qHXRuyNFjzWv(u"ࠩ࠵࠴࠷࠾ࠧᶃ")]
		for JJwnocyLUxHI2jlKF4Y in sorted(list(EeCo9tOcL2dIZu75g.keys())):
			ccgt6lhpXynUR79P5ev = JJwnocyLUxHI2jlKF4Y.lower()
			RRIscyLmNH9dq2Dio3TSr = []
			if any(aasX2cby4Vo5rTgB in ccgt6lhpXynUR79P5ev for aasX2cby4Vo5rTgB in qqU3jxJViAaCnf): RRIscyLmNH9dq2Dio3TSr.append(YYJQyRskpX8jv)
			if any(aasX2cby4Vo5rTgB in ccgt6lhpXynUR79P5ev for aasX2cby4Vo5rTgB in tN1Y9wIDQqrE6xMhkl): RRIscyLmNH9dq2Dio3TSr.append(nI2JK1RfsGWNY3OarEeMQZ)
			if any(aasX2cby4Vo5rTgB in ccgt6lhpXynUR79P5ev for aasX2cby4Vo5rTgB in iRO4E1My0QVdtFJPL7Bhe53AC6TmGj): RRIscyLmNH9dq2Dio3TSr.append(iiCWLaJREureAlOkv)
			if any(aasX2cby4Vo5rTgB in ccgt6lhpXynUR79P5ev for aasX2cby4Vo5rTgB in kbP81YHE0sjloI): RRIscyLmNH9dq2Dio3TSr.append(pZWli1xqfVtvzuSU6ImNw53gBFsh)
			if any(aasX2cby4Vo5rTgB in ccgt6lhpXynUR79P5ev for aasX2cby4Vo5rTgB in VV8tBcd1EfCA74Qins5Zmy): RRIscyLmNH9dq2Dio3TSr.append(SaB5hx3PZwXRLtKgrTfQvId(u"࠵Ẅ"))
			if any(aasX2cby4Vo5rTgB in ccgt6lhpXynUR79P5ev for aasX2cby4Vo5rTgB in ruXSznHvJWKUF): RRIscyLmNH9dq2Dio3TSr.append(CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"࠷ẅ"))
			if any(aasX2cby4Vo5rTgB in ccgt6lhpXynUR79P5ev for aasX2cby4Vo5rTgB in GGbxVPw0MrO) and ccgt6lhpXynUR79P5ev not in [UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠪหำื้ࠨᶄ")]: RRIscyLmNH9dq2Dio3TSr.append(UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"࠹Ẇ"))
			if any(aasX2cby4Vo5rTgB in ccgt6lhpXynUR79P5ev for aasX2cby4Vo5rTgB in swDY9o1NCX7mtcR3Vy8la): RRIscyLmNH9dq2Dio3TSr.append(EMO8gy4LrsNTh0knZwpSeU75APW(u"࠻ẇ"))
			if any(aasX2cby4Vo5rTgB in ccgt6lhpXynUR79P5ev for aasX2cby4Vo5rTgB in RYqJ572y9vAcrU): RRIscyLmNH9dq2Dio3TSr.append(uuExaKGL7UONtevRd(u"࠽Ẉ"))
			if any(aasX2cby4Vo5rTgB in ccgt6lhpXynUR79P5ev for aasX2cby4Vo5rTgB in w8hsf9erXJ): RRIscyLmNH9dq2Dio3TSr.append(MgP8OjoaiWQEVG59(u"࠶࠶ẉ"))
			if any(aasX2cby4Vo5rTgB in ccgt6lhpXynUR79P5ev for aasX2cby4Vo5rTgB in bczIhv9stYPHxNTG8RiX5): RRIscyLmNH9dq2Dio3TSr.append(SaB5hx3PZwXRLtKgrTfQvId(u"࠷࠱Ẋ"))
			if any(aasX2cby4Vo5rTgB in ccgt6lhpXynUR79P5ev for aasX2cby4Vo5rTgB in LBoZOI1WxV9kqzdK6n): RRIscyLmNH9dq2Dio3TSr.append(zmcGfOdvAjsELeJlP(u"࠱࠳ẋ"))
			if any(aasX2cby4Vo5rTgB in ccgt6lhpXynUR79P5ev for aasX2cby4Vo5rTgB in eyQu8NfoI1mEF4a0D): RRIscyLmNH9dq2Dio3TSr.append(FRYcH4KL7e9gv5pEB(u"࠲࠵Ẍ"))
			if any(aasX2cby4Vo5rTgB in ccgt6lhpXynUR79P5ev for aasX2cby4Vo5rTgB in SPU5HV0bxyTL8dOFf): RRIscyLmNH9dq2Dio3TSr.append(ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"࠳࠷ẍ"))
			if any(aasX2cby4Vo5rTgB in ccgt6lhpXynUR79P5ev for aasX2cby4Vo5rTgB in vNK3wQ1O52pmfsYoqZMXLt): RRIscyLmNH9dq2Dio3TSr.append(IpC4qHXRuyNFjzWv(u"࠴࠹Ẏ"))
			if any(aasX2cby4Vo5rTgB in ccgt6lhpXynUR79P5ev for aasX2cby4Vo5rTgB in FaD6NxfSIbzZimr9d4wOjQMkYhn5): RRIscyLmNH9dq2Dio3TSr.append(CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"࠵࠻ẏ"))
			if any(aasX2cby4Vo5rTgB in ccgt6lhpXynUR79P5ev for aasX2cby4Vo5rTgB in wrpg82k16W0LTqv): RRIscyLmNH9dq2Dio3TSr.append(AbqCJZdWQP9j(u"࠶࠽Ẑ"))
			if any(aasX2cby4Vo5rTgB in ccgt6lhpXynUR79P5ev for aasX2cby4Vo5rTgB in M85XcFxkITEyr3me): RRIscyLmNH9dq2Dio3TSr.append(hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"࠷࠸ẑ"))
			if not RRIscyLmNH9dq2Dio3TSr: RRIscyLmNH9dq2Dio3TSr = [SaB5hx3PZwXRLtKgrTfQvId(u"࠱࠺Ẓ")]
			for uuhxaOqfPIY9Gm846KV in RRIscyLmNH9dq2Dio3TSr:
				if str(uuhxaOqfPIY9Gm846KV)==kMr9s6e7phZlJ:
					bP6z3OSLp7va(Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᶅ"),ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+JJwnocyLUxHI2jlKF4Y,JJwnocyLUxHI2jlKF4Y,IpC4qHXRuyNFjzWv(u"࠲࠸࠹ẓ"),iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,IvoHm2GsXcTrztuq53AiNlQkMK94+UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᶆ"))
	qI2s0ZN7uj(None,None,iiy37aKq0pCEIOwfcTh61xb4U)
	return
def xxuwnQYU3vV7(skyPuAlLvecbtRZfB0pzIGd34n7xX9,FG615TlEM78tKb):
	iQ2tN1nLmJH7GCchv4u0VoSKlb = MgP8OjoaiWQEVG59(u"ࡌࡡ࡭ࡵࡨỐ")
	if iQ2tN1nLmJH7GCchv4u0VoSKlb:
		bP6z3OSLp7va(CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"࠭࡬ࡪࡰ࡮ࠫᶇ"),sVzojQerUqX(u"ࠧหฯา๎ะࠦโศศ่อࠥษโิษ่ࠤࡎࡖࡔࡗࠩᶈ"),iiy37aKq0pCEIOwfcTh61xb4U,JZszNnIEMAx28Yao0yqhiXGKOPb(u"࠹࠹࠸Ẕ"),iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠨࡡࡆࡖࡊࡇࡔࡆࡐࡈ࡛ࡤ࠭ᶉ"),iiy37aKq0pCEIOwfcTh61xb4U,{EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠩࡩࡳࡱࡪࡥࡳࠩᶊ"):skyPuAlLvecbtRZfB0pzIGd34n7xX9})
		bP6z3OSLp7va(CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠪࡰ࡮ࡴ࡫ࠨᶋ"),PSwfZcdRYhpl5Igqz8xOEk67+tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠫࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡࠩᶌ")+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"࠼࠽࠾࠿ẕ"))
	hu4rXM9KgvPtmSkByDwOsR = g6ghGH4aBEYkTl3vbJZ[:]
	import uUbDljY0SN
	if skyPuAlLvecbtRZfB0pzIGd34n7xX9:
		if not uUbDljY0SN.whH63ZkMf7j5gsY(skyPuAlLvecbtRZfB0pzIGd34n7xX9,JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࡔࡳࡷࡨố")): return
		T1MEGXQuyB6W9fghbvrKN4S = ta70LOknIHDBZf8WU1GR(skyPuAlLvecbtRZfB0pzIGd34n7xX9,FG615TlEM78tKb)
		nFrfKgIy7dlN2HDCOR5AQJiL9X4pT = sorted(T1MEGXQuyB6W9fghbvrKN4S,reverse=tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࡇࡣ࡯ࡷࡪỒ"),key=lambda key: key[YYJQyRskpX8jv].lower())
	else:
		if not uUbDljY0SN.whH63ZkMf7j5gsY(iiy37aKq0pCEIOwfcTh61xb4U,tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࡖࡵࡹࡪồ")): return
		if iQ2tN1nLmJH7GCchv4u0VoSKlb and vODxLKW5Ql6r4Fbm8(u"ࠬࡥࡃࡓࡇࡄࡘࡊࡔࡅࡘࡡࠪᶍ") not in FG615TlEM78tKb:
			nFrfKgIy7dlN2HDCOR5AQJiL9X4pT = QKzCiBOWZus1nSv(PdkZHNBlpg2b7DmX6qRiyVa,JZszNnIEMAx28Yao0yqhiXGKOPb(u"࠭࡬ࡪࡵࡷࠫᶎ"),ZchUJdM93pTA7zG5(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡌࡔ࡙࡜ࠧᶏ"),UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡍࡕ࡚ࡖࡠࡃࡏࡐࠬᶐ"))
		else:
			NNMscEGqRdx9QOhDrnwl,nFrfKgIy7dlN2HDCOR5AQJiL9X4pT,T1MEGXQuyB6W9fghbvrKN4S = [],[],[]
			for VVnHrwM1lCpGUjXBteaqJP8 in range(YYJQyRskpX8jv,IDxpbtWgzXHs3u08Q7nR6YerO+YYJQyRskpX8jv):
				nFrfKgIy7dlN2HDCOR5AQJiL9X4pT += ta70LOknIHDBZf8WU1GR(str(VVnHrwM1lCpGUjXBteaqJP8),FG615TlEM78tKb)
			for type,JJwnocyLUxHI2jlKF4Y,url,Cpf9s3c0Zngj7XE,L95mrowGgdsD,zLEP9N4BOsVrXa,U94JwhRgpXCOe5,EALyNnv1Db4cUd8sQoZX2pmBVt7kM,XC10geOnQtwrs in nFrfKgIy7dlN2HDCOR5AQJiL9X4pT:
				if U94JwhRgpXCOe5 not in NNMscEGqRdx9QOhDrnwl:
					NNMscEGqRdx9QOhDrnwl.append(U94JwhRgpXCOe5)
					eJQEaCr0VDsRhqp7x = type,JJwnocyLUxHI2jlKF4Y,U94JwhRgpXCOe5,tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"࠵࠻࠻ẖ"),L95mrowGgdsD,zLEP9N4BOsVrXa,FG615TlEM78tKb,EALyNnv1Db4cUd8sQoZX2pmBVt7kM,XC10geOnQtwrs
					T1MEGXQuyB6W9fghbvrKN4S.append(eJQEaCr0VDsRhqp7x)
			nFrfKgIy7dlN2HDCOR5AQJiL9X4pT = sorted(T1MEGXQuyB6W9fghbvrKN4S,reverse=sVzojQerUqX(u"ࡉࡥࡱࡹࡥỔ"),key=lambda key: key[YYJQyRskpX8jv].lower())
			if iQ2tN1nLmJH7GCchv4u0VoSKlb: YMQXP2BGeK86CEb(PdkZHNBlpg2b7DmX6qRiyVa,AbqCJZdWQP9j(u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡎࡖࡔࡗࠩᶑ"),AbqCJZdWQP9j(u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡏࡐࡕࡘࡢࡅࡑࡒࠧᶒ"),nFrfKgIy7dlN2HDCOR5AQJiL9X4pT,VaeMF1mIjQ5iLtfGcB)
	g6ghGH4aBEYkTl3vbJZ[:] = hu4rXM9KgvPtmSkByDwOsR+nFrfKgIy7dlN2HDCOR5AQJiL9X4pT
	SqMHwb6X1Ph8jY7LBNkmtV4F5Jlspy(LyNiIHPOwD3hCUYEFM7(u"ࡊࡦࡲࡳࡦổ"))
	return
def ogzuMapeTv7B(skyPuAlLvecbtRZfB0pzIGd34n7xX9,FG615TlEM78tKb):
	iQ2tN1nLmJH7GCchv4u0VoSKlb = EMO8gy4LrsNTh0knZwpSeU75APW(u"ࡋࡧ࡬ࡴࡧỖ")
	if iQ2tN1nLmJH7GCchv4u0VoSKlb:
		bP6z3OSLp7va(HtK4o2sTPgA78U(u"ࠫࡱ࡯࡮࡬ࠩᶓ"),FRYcH4KL7e9gv5pEB(u"ࠬะอะ์ฮࠤ็อฦๆหࠣว็ูวๆࠢࡐ࠷࡚࠭ᶔ"),iiy37aKq0pCEIOwfcTh61xb4U,XrTw01KtLzbpoyMf(u"࠼࠼࠵ẗ"),iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,XrTw01KtLzbpoyMf(u"࠭࡟ࡄࡔࡈࡅ࡙ࡋࡎࡆ࡙ࡢࠫᶕ"),iiy37aKq0pCEIOwfcTh61xb4U,{tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᶖ"):skyPuAlLvecbtRZfB0pzIGd34n7xX9})
		bP6z3OSLp7va(Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠨ࡮࡬ࡲࡰ࠭ᶗ"),PSwfZcdRYhpl5Igqz8xOEk67+AbqCJZdWQP9j(u"ࠩࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦࠧᶘ")+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,AbqCJZdWQP9j(u"࠿࠹࠺࠻ẘ"))
	hu4rXM9KgvPtmSkByDwOsR = g6ghGH4aBEYkTl3vbJZ[:]
	import FwKQq7S2Ce
	if skyPuAlLvecbtRZfB0pzIGd34n7xX9:
		if not FwKQq7S2Ce.whH63ZkMf7j5gsY(skyPuAlLvecbtRZfB0pzIGd34n7xX9,UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"࡚ࡲࡶࡧỗ")): return
		T1MEGXQuyB6W9fghbvrKN4S = T3ksWRpfxniNg1z7lE69(skyPuAlLvecbtRZfB0pzIGd34n7xX9,FG615TlEM78tKb)
		nFrfKgIy7dlN2HDCOR5AQJiL9X4pT = sorted(T1MEGXQuyB6W9fghbvrKN4S,reverse=tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࡆࡢ࡮ࡶࡩỘ"),key=lambda key: key[YYJQyRskpX8jv].lower())
	else:
		if not FwKQq7S2Ce.whH63ZkMf7j5gsY(iiy37aKq0pCEIOwfcTh61xb4U,ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࡕࡴࡸࡩộ")): return
		if iQ2tN1nLmJH7GCchv4u0VoSKlb and EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠪࡣࡈࡘࡅࡂࡖࡈࡒࡊ࡝࡟ࠨᶙ") not in FG615TlEM78tKb:
			nFrfKgIy7dlN2HDCOR5AQJiL9X4pT = QKzCiBOWZus1nSv(PdkZHNBlpg2b7DmX6qRiyVa,HtK4o2sTPgA78U(u"ࠫࡱ࡯ࡳࡵࠩᶚ"),ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡎ࠵ࡘࠫᶛ"),MgP8OjoaiWQEVG59(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡏ࠶࡙ࡤࡇࡌࡍࠩᶜ"))
		else:
			NNMscEGqRdx9QOhDrnwl,nFrfKgIy7dlN2HDCOR5AQJiL9X4pT,T1MEGXQuyB6W9fghbvrKN4S = [],[],[]
			for VVnHrwM1lCpGUjXBteaqJP8 in range(YYJQyRskpX8jv,IDxpbtWgzXHs3u08Q7nR6YerO+YYJQyRskpX8jv):
				nFrfKgIy7dlN2HDCOR5AQJiL9X4pT += T3ksWRpfxniNg1z7lE69(str(VVnHrwM1lCpGUjXBteaqJP8),FG615TlEM78tKb)
			for type,JJwnocyLUxHI2jlKF4Y,url,Cpf9s3c0Zngj7XE,L95mrowGgdsD,zLEP9N4BOsVrXa,U94JwhRgpXCOe5,EALyNnv1Db4cUd8sQoZX2pmBVt7kM,XC10geOnQtwrs in nFrfKgIy7dlN2HDCOR5AQJiL9X4pT:
				if U94JwhRgpXCOe5 not in NNMscEGqRdx9QOhDrnwl:
					NNMscEGqRdx9QOhDrnwl.append(U94JwhRgpXCOe5)
					eJQEaCr0VDsRhqp7x = type,JJwnocyLUxHI2jlKF4Y,U94JwhRgpXCOe5,L90uqo28xEKSFUwYTcm51yRWZIkft(u"࠱࠷࠷ẙ"),L95mrowGgdsD,zLEP9N4BOsVrXa,FG615TlEM78tKb,EALyNnv1Db4cUd8sQoZX2pmBVt7kM,XC10geOnQtwrs
					T1MEGXQuyB6W9fghbvrKN4S.append(eJQEaCr0VDsRhqp7x)
			nFrfKgIy7dlN2HDCOR5AQJiL9X4pT = sorted(T1MEGXQuyB6W9fghbvrKN4S,reverse=EMO8gy4LrsNTh0knZwpSeU75APW(u"ࡈࡤࡰࡸ࡫Ớ"),key=lambda key: key[YYJQyRskpX8jv].lower())
			if iQ2tN1nLmJH7GCchv4u0VoSKlb: YMQXP2BGeK86CEb(PdkZHNBlpg2b7DmX6qRiyVa,xpT28sXu051(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡐ࠷࡚࠭ᶝ"),hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡑ࠸࡛࡟ࡂࡎࡏࠫᶞ"),nFrfKgIy7dlN2HDCOR5AQJiL9X4pT,VaeMF1mIjQ5iLtfGcB)
	g6ghGH4aBEYkTl3vbJZ[:] = hu4rXM9KgvPtmSkByDwOsR+nFrfKgIy7dlN2HDCOR5AQJiL9X4pT
	SqMHwb6X1Ph8jY7LBNkmtV4F5Jlspy(IpC4qHXRuyNFjzWv(u"ࡉࡥࡱࡹࡥớ"))
	return
def MrkvDNYdKzlF4byPLujXW7VGtB(group,FG615TlEM78tKb):
	iQ2tN1nLmJH7GCchv4u0VoSKlb = UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࡊࡦࡲࡳࡦỜ")
	EA7FzO1kMZGQXDd2giB0cwLom = []
	qXnbed7Jjf = L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠩࡢࡍࡕ࡚ࡖࡠࠩᶟ") if TlGXWLYsV1z(u"ࠪࡍࡕ࡚ࡖࠨᶠ") in FG615TlEM78tKb else xpT28sXu051(u"ࠫࡤࡓ࠳ࡖࡡࠪᶡ")
	if iQ2tN1nLmJH7GCchv4u0VoSKlb: EA7FzO1kMZGQXDd2giB0cwLom = QKzCiBOWZus1nSv(PdkZHNBlpg2b7DmX6qRiyVa,tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠬࡲࡩࡴࡶࠪᶢ"),jXE2YHkswT8y(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࠨᶣ")+qXnbed7Jjf[:-ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"࠲ẚ")],group)
	if not EA7FzO1kMZGQXDd2giB0cwLom:
		for skyPuAlLvecbtRZfB0pzIGd34n7xX9 in range(YYJQyRskpX8jv,IDxpbtWgzXHs3u08Q7nR6YerO+YYJQyRskpX8jv):
			if iQ2tN1nLmJH7GCchv4u0VoSKlb: EA7FzO1kMZGQXDd2giB0cwLom += QKzCiBOWZus1nSv(PdkZHNBlpg2b7DmX6qRiyVa,vODxLKW5Ql6r4Fbm8(u"ࠧ࡭࡫ࡶࡸࠬᶤ"),tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࠪᶥ")+qXnbed7Jjf[:-YYJQyRskpX8jv],SaB5hx3PZwXRLtKgrTfQvId(u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࠫᶦ")+qXnbed7Jjf+str(skyPuAlLvecbtRZfB0pzIGd34n7xX9))
			elif qXnbed7Jjf==XrTw01KtLzbpoyMf(u"ࠪࡣࡎࡖࡔࡗࡡࠪᶧ"): EA7FzO1kMZGQXDd2giB0cwLom += ta70LOknIHDBZf8WU1GR(str(skyPuAlLvecbtRZfB0pzIGd34n7xX9),hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠫࡤࡉࡒࡆࡃࡗࡉࡓࡋࡗࡠࠩᶨ"))
			elif qXnbed7Jjf==ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠬࡥࡍ࠴ࡗࡢࠫᶩ"): EA7FzO1kMZGQXDd2giB0cwLom += T3ksWRpfxniNg1z7lE69(str(skyPuAlLvecbtRZfB0pzIGd34n7xX9),IpC4qHXRuyNFjzWv(u"࠭࡟ࡄࡔࡈࡅ࡙ࡋࡎࡆ࡙ࡢࠫᶪ"))
		for type,JJwnocyLUxHI2jlKF4Y,url,Cpf9s3c0Zngj7XE,L95mrowGgdsD,zLEP9N4BOsVrXa,U94JwhRgpXCOe5,EALyNnv1Db4cUd8sQoZX2pmBVt7kM,XC10geOnQtwrs in EA7FzO1kMZGQXDd2giB0cwLom:
			if U94JwhRgpXCOe5==group: wA8ZcpVskTjEf5GdULPi4(type,JJwnocyLUxHI2jlKF4Y,url,Cpf9s3c0Zngj7XE,L95mrowGgdsD,zLEP9N4BOsVrXa,U94JwhRgpXCOe5,EALyNnv1Db4cUd8sQoZX2pmBVt7kM,XC10geOnQtwrs)
		items,lFmsiNI2UDoJBdVCQtqx4WPXb7 = [],[]
		for type,JJwnocyLUxHI2jlKF4Y,url,Cpf9s3c0Zngj7XE,L95mrowGgdsD,zLEP9N4BOsVrXa,U94JwhRgpXCOe5,EALyNnv1Db4cUd8sQoZX2pmBVt7kM,XC10geOnQtwrs in g6ghGH4aBEYkTl3vbJZ:
			DJiISnv76qUBhkyfdapx = type,JJwnocyLUxHI2jlKF4Y[pZWli1xqfVtvzuSU6ImNw53gBFsh:],url,Cpf9s3c0Zngj7XE,L95mrowGgdsD,zLEP9N4BOsVrXa,U94JwhRgpXCOe5,EALyNnv1Db4cUd8sQoZX2pmBVt7kM,iiy37aKq0pCEIOwfcTh61xb4U
			if DJiISnv76qUBhkyfdapx not in lFmsiNI2UDoJBdVCQtqx4WPXb7:
				lFmsiNI2UDoJBdVCQtqx4WPXb7.append(DJiISnv76qUBhkyfdapx)
				YXD9KNfjCaLwkcrvJxldn7I = type,JJwnocyLUxHI2jlKF4Y,url,Cpf9s3c0Zngj7XE,L95mrowGgdsD,zLEP9N4BOsVrXa,U94JwhRgpXCOe5,EALyNnv1Db4cUd8sQoZX2pmBVt7kM,XC10geOnQtwrs
				items.append(YXD9KNfjCaLwkcrvJxldn7I)
		EA7FzO1kMZGQXDd2giB0cwLom = sorted(items,reverse=UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࡋࡧ࡬ࡴࡧờ"),key=lambda key: key[YYJQyRskpX8jv].lower()[IpC4qHXRuyNFjzWv(u"࠷ẛ"):])
		if iQ2tN1nLmJH7GCchv4u0VoSKlb: YMQXP2BGeK86CEb(PdkZHNBlpg2b7DmX6qRiyVa,IpC4qHXRuyNFjzWv(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࠩᶫ")+qXnbed7Jjf[:-YYJQyRskpX8jv],group,EA7FzO1kMZGQXDd2giB0cwLom,VaeMF1mIjQ5iLtfGcB)
	if CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠨࡡࡕࡅࡓࡊࡏࡎࡡࠪᶬ") in FG615TlEM78tKb and len(EA7FzO1kMZGQXDd2giB0cwLom)>KP7x1T4ZpAgc0Ld5r:
		g6ghGH4aBEYkTl3vbJZ[:] = []
		bP6z3OSLp7va(ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠩࡩࡳࡱࡪࡥࡳࠩᶭ"),AbqCJZdWQP9j(u"ࠪ࡟ࠬᶮ")+PSwfZcdRYhpl5Igqz8xOEk67+group+YoQW601K4fMJcsreDnGVE5wUZIy7+XrTw01KtLzbpoyMf(u"ࠫࠥࡀวๅไึ้ࡢ࠭ᶯ"),group,ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"࠴࠺࠺ẜ"),iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,qXnbed7Jjf+ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠬࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᶰ"))
		bP6z3OSLp7va(ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᶱ"),ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠧฦ฻สำฮࠦวๅู็ฬࠥอไฺึ๋หห๐ࠠๆ่๊ࠣๆูࠠศๆๅื๊࠭ᶲ"),group,xpT28sXu051(u"࠵࠻࠻ẝ"),iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,qXnbed7Jjf+AbqCJZdWQP9j(u"ࠨࡡࡕࡅࡓࡊࡏࡎࡡࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧᶳ"))
		bP6z3OSLp7va(EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠩ࡯࡭ࡳࡱࠧᶴ"),PSwfZcdRYhpl5Igqz8xOEk67+hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠪࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠࠨᶵ")+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,y6y5HtgXO4TkUbwVZ(u"࠾࠿࠹࠺ẞ"))
		EA7FzO1kMZGQXDd2giB0cwLom = g6ghGH4aBEYkTl3vbJZ+ufTX72hK8Q63jSsJiqDm5.sample(EA7FzO1kMZGQXDd2giB0cwLom,KP7x1T4ZpAgc0Ld5r)
	g6ghGH4aBEYkTl3vbJZ[:] = EA7FzO1kMZGQXDd2giB0cwLom
	SqMHwb6X1Ph8jY7LBNkmtV4F5Jlspy(LyNiIHPOwD3hCUYEFM7(u"ࡌࡡ࡭ࡵࡨỞ"))
	return
def kb640sj2JD3BNKWvrYzFAnqEP(FG615TlEM78tKb):
	bP6z3OSLp7va(ZchUJdM93pTA7zG5(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᶶ"),tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠬหูศัฬࠤ฼๊ศࠡไ้์ฬะฺࠠึ๋หห๐ษࠨᶷ"),iiy37aKq0pCEIOwfcTh61xb4U,yJeq1BjfiO4NFuwIEzxVLK6b9s(u"࠷࠶࠲ẟ"),iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,jXE2YHkswT8y(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡑࡏࡖࡆࡖ࡙ࡣࡤࡘࡁࡏࡆࡒࡑࡤ࠭ᶸ"))
	bP6z3OSLp7va(PtkEvXAqif14G20QZsaSyT(u"ࠧ࡭࡫ࡱ࡯ࠬᶹ"),PSwfZcdRYhpl5Igqz8xOEk67+Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠨ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥ࠭ᶺ")+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,SaB5hx3PZwXRLtKgrTfQvId(u"࠹࠺࠻࠼Ạ"))
	eexfWpMDZTzcjqQ71 = g6ghGH4aBEYkTl3vbJZ[:]
	g6ghGH4aBEYkTl3vbJZ[:] = []
	import XgsrtIMz4H
	XgsrtIMz4H.rmEH1eAYBg8xPK(y6y5HtgXO4TkUbwVZ(u"ࠩ࠳ࠫᶻ"),uuExaKGL7UONtevRd(u"ࡆࡢ࡮ࡶࡩở"))
	XgsrtIMz4H.rmEH1eAYBg8xPK(AbqCJZdWQP9j(u"ࠪ࠵ࠬᶼ"),LyNiIHPOwD3hCUYEFM7(u"ࡇࡣ࡯ࡷࡪỠ"))
	XgsrtIMz4H.rmEH1eAYBg8xPK(zmcGfOdvAjsELeJlP(u"ࠫ࠷࠭ᶽ"),SaB5hx3PZwXRLtKgrTfQvId(u"ࡈࡤࡰࡸ࡫ỡ"))
	if sVzojQerUqX(u"ࠬࡥࡒࡂࡐࡇࡓࡒࡥࠧᶾ") in FG615TlEM78tKb:
		g6ghGH4aBEYkTl3vbJZ[:] = Ygx4eF6jNd5(g6ghGH4aBEYkTl3vbJZ)
		if len(g6ghGH4aBEYkTl3vbJZ)>KP7x1T4ZpAgc0Ld5r: g6ghGH4aBEYkTl3vbJZ[:] = ufTX72hK8Q63jSsJiqDm5.sample(g6ghGH4aBEYkTl3vbJZ,KP7x1T4ZpAgc0Ld5r)
	g6ghGH4aBEYkTl3vbJZ[:] = eexfWpMDZTzcjqQ71+g6ghGH4aBEYkTl3vbJZ
	return
def siVTrHfNKYu3BcS7z(FG615TlEM78tKb):
	FG615TlEM78tKb = FG615TlEM78tKb.replace(AbqCJZdWQP9j(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᶿ"),iiy37aKq0pCEIOwfcTh61xb4U).replace(CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ᷀"),iiy37aKq0pCEIOwfcTh61xb4U)
	headers = { GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ᷁") : iiy37aKq0pCEIOwfcTh61xb4U }
	url = AbqCJZdWQP9j(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡣࡧࡶࡸࡷࡧ࡮ࡥࡱࡰࡷ࠳ࡩ࡯࡮࠱ࡵࡥࡳࡪ࡯࡮࠯ࡤࡶࡦࡨࡩࡤ࠯ࡺࡳࡷࡪࡳࠨ᷂")
	data = {tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠪࡵࡺࡧ࡮ࡵ࡫ࡷࡽࠬ᷃"):GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠫ࠺࠶ࠧ᷄")}
	data = zzUnMebTFdNgB8hOwJmKxVj(data)
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(Qfob9ThC6ryqKkYZ,TlGXWLYsV1z(u"ࠬࡍࡅࡕࠩ᷅"),url,data,headers,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,y6y5HtgXO4TkUbwVZ(u"࠭ࡒࡂࡐࡇࡓࡒ࡙࠭ࡓࡃࡑࡈࡔࡓ࡟ࡗࡋࡇࡉࡔ࡙࡟ࡇࡔࡒࡑࡤ࡝ࡏࡓࡆࡖ࠱࠶ࡹࡴࠨ᷆"))
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall(zmcGfOdvAjsELeJlP(u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡤࡱࡱࡸࡪࡴࡴࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡣ࡭ࡧࡤࡶ࡫࡯ࡸࠣࠩ᷇"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[FGTfwsjNrB8DvKSZhLIQAb1JnO]
	items = dEyT9xhGjolYzLCH7460w3.findall(Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠨ࠾ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃ࠴ࠪࡀ࠾ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃ࠭᷈"),PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	LyRq6wUtSPoeJV5NhfX4AYkZCpcHT,cXuOslQMh0xyNbijoUn9YzmT5 = list(zip(*items))
	oYkjqL5mA1wUEp8fT34tVCKNOHia = []
	pBtHAZelFo17zRsci4Dhbf9q3dG = [iFBmE2MUIpSu34wsd7Rf6z,AbqCJZdWQP9j(u"ࠩࠥࠫ᷉"),L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠪࡤ᷊ࠬ"),ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠫ࠱࠭᷋"),y6y5HtgXO4TkUbwVZ(u"ࠬ࠴ࠧ᷌"),ZchUJdM93pTA7zG5(u"࠭࠺ࠨ᷍"),ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠧ࠼᷎ࠩ"),JZszNnIEMAx28Yao0yqhiXGKOPb(u"᷏ࠣࠩࠥ"),UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠩ࠰᷐ࠫ")]
	CIdTbJ9fOqe = cXuOslQMh0xyNbijoUn9YzmT5+LyRq6wUtSPoeJV5NhfX4AYkZCpcHT
	for iiNkXzVdDn0ZSwC in CIdTbJ9fOqe:
		if iiNkXzVdDn0ZSwC in cXuOslQMh0xyNbijoUn9YzmT5: rCeHY5bF3iQvoO9ymJT = nI2JK1RfsGWNY3OarEeMQZ
		if iiNkXzVdDn0ZSwC in LyRq6wUtSPoeJV5NhfX4AYkZCpcHT: rCeHY5bF3iQvoO9ymJT = pZWli1xqfVtvzuSU6ImNw53gBFsh
		UimY8cX0124lvRaCTVx3rjbG5oL = [iEfNKT3velFyGth80SA4pxbCRrVD in iiNkXzVdDn0ZSwC for iEfNKT3velFyGth80SA4pxbCRrVD in pBtHAZelFo17zRsci4Dhbf9q3dG]
		if any(UimY8cX0124lvRaCTVx3rjbG5oL):
			bsqXJ3iaf2dop5 = UimY8cX0124lvRaCTVx3rjbG5oL.index(vODxLKW5Ql6r4Fbm8(u"ࡗࡶࡺ࡫Ợ"))
			za8CByKl5eXr7oWLHSkiPmOb0cFu = pBtHAZelFo17zRsci4Dhbf9q3dG[bsqXJ3iaf2dop5]
			DcnIvx4WkueC3di6tKqzoGAR = iiy37aKq0pCEIOwfcTh61xb4U
			if iiNkXzVdDn0ZSwC.count(za8CByKl5eXr7oWLHSkiPmOb0cFu)>YYJQyRskpX8jv: dsGCrxwtmWq5zN19L8QP4D7j3V0,DC6G4gLXUZKScAdaY7IJtPsrTN,DcnIvx4WkueC3di6tKqzoGAR = iiNkXzVdDn0ZSwC.split(za8CByKl5eXr7oWLHSkiPmOb0cFu,nI2JK1RfsGWNY3OarEeMQZ)
			else: dsGCrxwtmWq5zN19L8QP4D7j3V0,DC6G4gLXUZKScAdaY7IJtPsrTN = iiNkXzVdDn0ZSwC.split(za8CByKl5eXr7oWLHSkiPmOb0cFu,YYJQyRskpX8jv)
			if len(dsGCrxwtmWq5zN19L8QP4D7j3V0)>rCeHY5bF3iQvoO9ymJT: oYkjqL5mA1wUEp8fT34tVCKNOHia.append(dsGCrxwtmWq5zN19L8QP4D7j3V0.lower())
			if len(DC6G4gLXUZKScAdaY7IJtPsrTN)>rCeHY5bF3iQvoO9ymJT: oYkjqL5mA1wUEp8fT34tVCKNOHia.append(DC6G4gLXUZKScAdaY7IJtPsrTN.lower())
			if len(DcnIvx4WkueC3di6tKqzoGAR)>rCeHY5bF3iQvoO9ymJT: oYkjqL5mA1wUEp8fT34tVCKNOHia.append(DcnIvx4WkueC3di6tKqzoGAR.lower())
		elif len(iiNkXzVdDn0ZSwC)>rCeHY5bF3iQvoO9ymJT: oYkjqL5mA1wUEp8fT34tVCKNOHia.append(iiNkXzVdDn0ZSwC.lower())
	for iEfNKT3velFyGth80SA4pxbCRrVD in range(ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"࠺ạ")): ufTX72hK8Q63jSsJiqDm5.shuffle(oYkjqL5mA1wUEp8fT34tVCKNOHia)
	if PtkEvXAqif14G20QZsaSyT(u"ࠪࡣࡘࡏࡔࡆࡕࡢࠫ᷑") in FG615TlEM78tKb:
		JIykaoAvC16KGulQwFDH5d = sdf5uU2hLnzVjQxcBJtGgP4EXyvOA
	elif TlGXWLYsV1z(u"ࠫࡤࡏࡐࡕࡘࡢࠫ᷒") in FG615TlEM78tKb:
		JIykaoAvC16KGulQwFDH5d = [MgP8OjoaiWQEVG59(u"ࠬࡏࡐࡕࡘࠪᷓ")]
		import uUbDljY0SN
		if not uUbDljY0SN.whH63ZkMf7j5gsY(iiy37aKq0pCEIOwfcTh61xb4U,sVzojQerUqX(u"ࡘࡷࡻࡥợ")): return
	elif AbqCJZdWQP9j(u"࠭࡟ࡎ࠵ࡘࡣࠬᷔ") in FG615TlEM78tKb:
		JIykaoAvC16KGulQwFDH5d = [UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠧࡎ࠵ࡘࠫᷕ")]
		import FwKQq7S2Ce
		if not FwKQq7S2Ce.whH63ZkMf7j5gsY(iiy37aKq0pCEIOwfcTh61xb4U,TlGXWLYsV1z(u"࡙ࡸࡵࡦỤ")): return
	count,GOk0zeE3ioFjPJhM52SKNx = FGTfwsjNrB8DvKSZhLIQAb1JnO,FGTfwsjNrB8DvKSZhLIQAb1JnO
	bP6z3OSLp7va(YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᷖ"),uuExaKGL7UONtevRd(u"ࠩ࡞ࠤࠥࡣࠠ࠻ษ็ฬาัฺ่ࠠࠪᷗ"),iiy37aKq0pCEIOwfcTh61xb4U,UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"࠳࠹࠸Ả"),iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᷘ")+FG615TlEM78tKb)
	bP6z3OSLp7va(UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᷙ"),XrTw01KtLzbpoyMf(u"ࠬหูศัฬࠤฬ๊ศฮอࠣห้฿ิ้ษษ๎ࠬᷚ"),iiy37aKq0pCEIOwfcTh61xb4U,zmcGfOdvAjsELeJlP(u"࠴࠺࠹ả"),iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,GGx4qyKP1vUtRghsE2WfaHLMXZ(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᷛ")+FG615TlEM78tKb)
	bP6z3OSLp7va(LyNiIHPOwD3hCUYEFM7(u"ࠧ࡭࡫ࡱ࡯ࠬᷜ"),PSwfZcdRYhpl5Igqz8xOEk67+CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠨ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥ࠭ᷝ")+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"࠽࠾࠿࠹Ấ"))
	ofMpet3k60lH1CEJ528TL4Wzcj = g6ghGH4aBEYkTl3vbJZ[:]
	g6ghGH4aBEYkTl3vbJZ[:] = []
	fTYZ3wjX8elI = []
	for iiNkXzVdDn0ZSwC in oYkjqL5mA1wUEp8fT34tVCKNOHia:
		DC6G4gLXUZKScAdaY7IJtPsrTN = dEyT9xhGjolYzLCH7460w3.findall(HtK4o2sTPgA78U(u"ࠩ࡞ࠤࡡ࠲࡜࠼࡞࠽ࡠ࠲ࡢࠫ࡝࠿࡟ࠦࡡ࠭࡜࡜࡞ࡠࡠ࠭ࡢࠩ࡝ࡽ࡟ࢁࡡࠧ࡜ࡁࠩᷞ")+HtK4o2sTPgA78U(u"ࠪࠧࠬᷟ")+tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠫࡡࠪ࡜ࠦ࡞ࡡࡠࠫࡢࠪ࡝ࡡ࡟ࡀࡡࡄ࡝ࠨᷠ"),iiNkXzVdDn0ZSwC,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if DC6G4gLXUZKScAdaY7IJtPsrTN: iiNkXzVdDn0ZSwC = iiNkXzVdDn0ZSwC.split(DC6G4gLXUZKScAdaY7IJtPsrTN[FGTfwsjNrB8DvKSZhLIQAb1JnO],YYJQyRskpX8jv)[FGTfwsjNrB8DvKSZhLIQAb1JnO]
		dRHzJENOuCiqtUBgSsoTDX = iiNkXzVdDn0ZSwC.replace(JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠬ๗ࠧᷡ"),iiy37aKq0pCEIOwfcTh61xb4U).replace(ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"࠭๎ࠨᷢ"),iiy37aKq0pCEIOwfcTh61xb4U).replace(yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠧ์ࠩᷣ"),iiy37aKq0pCEIOwfcTh61xb4U).replace(SaB5hx3PZwXRLtKgrTfQvId(u"ࠨ๑ࠪᷤ"),iiy37aKq0pCEIOwfcTh61xb4U).replace(AbqCJZdWQP9j(u"ࠩ๏ࠫᷥ"),iiy37aKq0pCEIOwfcTh61xb4U)
		dRHzJENOuCiqtUBgSsoTDX = dRHzJENOuCiqtUBgSsoTDX.replace(y6y5HtgXO4TkUbwVZ(u"ࠪ๔ࠬᷦ"),iiy37aKq0pCEIOwfcTh61xb4U).replace(SaB5hx3PZwXRLtKgrTfQvId(u"ࠫ๒࠭ᷧ"),iiy37aKq0pCEIOwfcTh61xb4U).replace(yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠬ๘ࠧᷨ"),iiy37aKq0pCEIOwfcTh61xb4U).replace(xpT28sXu051(u"࠭ฌࠨᷩ"),iiy37aKq0pCEIOwfcTh61xb4U).replace(GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠧแࠩᷪ"),iiy37aKq0pCEIOwfcTh61xb4U)
		if dRHzJENOuCiqtUBgSsoTDX: fTYZ3wjX8elI.append(dRHzJENOuCiqtUBgSsoTDX)
	Rl9AciGUj4gqNrHvTtKp62e7o = []
	for o6oXFxmE1bQC in range(FGTfwsjNrB8DvKSZhLIQAb1JnO,TlGXWLYsV1z(u"࠷࠶ấ")):
		search = ufTX72hK8Q63jSsJiqDm5.sample(fTYZ3wjX8elI,YYJQyRskpX8jv)[FGTfwsjNrB8DvKSZhLIQAb1JnO]
		if search in Rl9AciGUj4gqNrHvTtKp62e7o: continue
		Rl9AciGUj4gqNrHvTtKp62e7o.append(search)
		ekEOd3mqAThaBDUoIrntuGRjYW = ufTX72hK8Q63jSsJiqDm5.sample(JIykaoAvC16KGulQwFDH5d,YYJQyRskpX8jv)[FGTfwsjNrB8DvKSZhLIQAb1JnO]
		WKquk5EaNr4RzVf(q1rohYuwnfpVZUa98L2CtQzmAcB,IIZ4e82HBP0oTmtOgaWY7hsMz(sQU2GnRoMwLK8CBdfzmNr4jXyO)+LyNiIHPOwD3hCUYEFM7(u"ࠨࠢࠣࠤࡗࡧ࡮ࡥࡱࡰࠤ࡛࡯ࡤࡦࡱࠣࡗࡪࡧࡲࡤࡪࠣࠤࠥࡹࡩࡵࡧ࠽ࠫᷫ")+str(ekEOd3mqAThaBDUoIrntuGRjYW)+zmcGfOdvAjsELeJlP(u"ࠩࠣࠤࡸ࡫ࡡࡳࡥ࡫࠾ࠬᷬ")+search)
		ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,lEgmdMxnfsXj,ZebIE2aQgrGn = GGkFKuWvn5q1wVmldgXz(ekEOd3mqAThaBDUoIrntuGRjYW)
		lEgmdMxnfsXj(search+PtkEvXAqif14G20QZsaSyT(u"ࠪࡣࡓࡕࡄࡊࡃࡏࡓࡌ࡙࡟ࠨᷭ"))
		if len(g6ghGH4aBEYkTl3vbJZ)>FGTfwsjNrB8DvKSZhLIQAb1JnO: break
	search = search.replace(JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠫࡤࡓࡏࡅࡡࠪᷮ"),iiy37aKq0pCEIOwfcTh61xb4U)
	ofMpet3k60lH1CEJ528TL4Wzcj[FGTfwsjNrB8DvKSZhLIQAb1JnO][YYJQyRskpX8jv] = CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠬࡡࠧᷯ")+PSwfZcdRYhpl5Igqz8xOEk67+search+YoQW601K4fMJcsreDnGVE5wUZIy7+yJeq1BjfiO4NFuwIEzxVLK6b9s(u"࠭ࠠ࠻สะฯࠥ฿ๆ࡞ࠩᷰ")
	g6ghGH4aBEYkTl3vbJZ[:] = Ygx4eF6jNd5(g6ghGH4aBEYkTl3vbJZ)
	if len(g6ghGH4aBEYkTl3vbJZ)>KP7x1T4ZpAgc0Ld5r: g6ghGH4aBEYkTl3vbJZ[:] = ufTX72hK8Q63jSsJiqDm5.sample(g6ghGH4aBEYkTl3vbJZ,KP7x1T4ZpAgc0Ld5r)
	g6ghGH4aBEYkTl3vbJZ[:] = ofMpet3k60lH1CEJ528TL4Wzcj+g6ghGH4aBEYkTl3vbJZ
	return
def n7mvgRkxu08izbcpH4BrD2lXyCGZ(cTrZL0ve4mDlb8Bzu6wOy,FG615TlEM78tKb):
	cTrZL0ve4mDlb8Bzu6wOy = cTrZL0ve4mDlb8Bzu6wOy.replace(hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠧࡠࡏࡒࡈࡤ࠭ᷱ"),iiy37aKq0pCEIOwfcTh61xb4U)
	FG615TlEM78tKb = FG615TlEM78tKb.replace(sVzojQerUqX(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᷲ"),iiy37aKq0pCEIOwfcTh61xb4U).replace(ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᷳ"),iiy37aKq0pCEIOwfcTh61xb4U)
	PPYAxHMiQIE(L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࡌࡡ࡭ࡵࡨụ"))
	if not EeCo9tOcL2dIZu75g: return
	if ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠪࡣࡗࡇࡎࡅࡑࡐࡣࠬᷴ") in FG615TlEM78tKb:
		bP6z3OSLp7va(Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ᷵"),vODxLKW5Ql6r4Fbm8(u"ࠬࡡࠧ᷶")+PSwfZcdRYhpl5Igqz8xOEk67+cTrZL0ve4mDlb8Bzu6wOy+YoQW601K4fMJcsreDnGVE5wUZIy7+JZszNnIEMAx28Yao0yqhiXGKOPb(u"࠭ࠠ࠻ษ็ๆุ๋࡝ࠨ᷷"),cTrZL0ve4mDlb8Bzu6wOy,L90uqo28xEKSFUwYTcm51yRWZIkft(u"࠷࠶࠷Ầ"),iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣ᷸ࠬ")+FG615TlEM78tKb)
		bP6z3OSLp7va(hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᷹"),sVzojQerUqX(u"ࠩศ฽ฬีษࠡษ็฻้ฮࠠศๆ฼ุํอฦ๋่๊ࠢࠥ์แิࠢส่็ูๅࠨ᷺"),cTrZL0ve4mDlb8Bzu6wOy,zmcGfOdvAjsELeJlP(u"࠱࠷࠸ầ"),iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,HtK4o2sTPgA78U(u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ᷻")+FG615TlEM78tKb)
		bP6z3OSLp7va(UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠫࡱ࡯࡮࡬ࠩ᷼"),PSwfZcdRYhpl5Igqz8xOEk67+SaB5hx3PZwXRLtKgrTfQvId(u"ࠬࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾᷽ࠢࠪ")+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"࠺࠻࠼࠽Ẩ"))
	for website in sorted(list(EeCo9tOcL2dIZu75g[cTrZL0ve4mDlb8Bzu6wOy].keys())):
		type,JJwnocyLUxHI2jlKF4Y,url,xl0I9SsgtGu5E,L95mrowGgdsD,zLEP9N4BOsVrXa,U94JwhRgpXCOe5,EALyNnv1Db4cUd8sQoZX2pmBVt7kM,XC10geOnQtwrs = EeCo9tOcL2dIZu75g[cTrZL0ve4mDlb8Bzu6wOy][website]
		if EMO8gy4LrsNTh0knZwpSeU75APW(u"࠭࡟ࡓࡃࡑࡈࡔࡓ࡟ࠨ᷾") in FG615TlEM78tKb or len(EeCo9tOcL2dIZu75g[cTrZL0ve4mDlb8Bzu6wOy])==YYJQyRskpX8jv:
			wA8ZcpVskTjEf5GdULPi4(type,iiy37aKq0pCEIOwfcTh61xb4U,url,xl0I9SsgtGu5E,iiy37aKq0pCEIOwfcTh61xb4U,zLEP9N4BOsVrXa,U94JwhRgpXCOe5,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U)
			g6ghGH4aBEYkTl3vbJZ[:] = Ygx4eF6jNd5(g6ghGH4aBEYkTl3vbJZ)
			hu4rXM9KgvPtmSkByDwOsR,nFrfKgIy7dlN2HDCOR5AQJiL9X4pT = g6ghGH4aBEYkTl3vbJZ[:iiCWLaJREureAlOkv],g6ghGH4aBEYkTl3vbJZ[iiCWLaJREureAlOkv:]
			if yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠧࡠࡔࡄࡒࡉࡕࡍࡠ᷿ࠩ") in FG615TlEM78tKb:
				for iEfNKT3velFyGth80SA4pxbCRrVD in range(Y41NvKfOroMzGB8sEHy7wbXlc5(u"࠻ẩ")): ufTX72hK8Q63jSsJiqDm5.shuffle(nFrfKgIy7dlN2HDCOR5AQJiL9X4pT)
				g6ghGH4aBEYkTl3vbJZ[:] = hu4rXM9KgvPtmSkByDwOsR+nFrfKgIy7dlN2HDCOR5AQJiL9X4pT[:KP7x1T4ZpAgc0Ld5r]
			else: g6ghGH4aBEYkTl3vbJZ[:] = hu4rXM9KgvPtmSkByDwOsR+nFrfKgIy7dlN2HDCOR5AQJiL9X4pT
		elif LyNiIHPOwD3hCUYEFM7(u"ࠨࡡࡖࡍ࡙ࡋࡓࡠࠩḀ") in FG615TlEM78tKb: bP6z3OSLp7va(CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠩࡩࡳࡱࡪࡥࡳࠩḁ"),website,url,xl0I9SsgtGu5E,L95mrowGgdsD,zLEP9N4BOsVrXa,U94JwhRgpXCOe5,EALyNnv1Db4cUd8sQoZX2pmBVt7kM,XC10geOnQtwrs)
	return
def UUE3o0bs9gSzHDcMXRaLtIYVfeNwjk(FG615TlEM78tKb,Cpf9s3c0Zngj7XE):
	FG615TlEM78tKb = FG615TlEM78tKb.replace(uuExaKGL7UONtevRd(u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬḂ"),iiy37aKq0pCEIOwfcTh61xb4U).replace(PtkEvXAqif14G20QZsaSyT(u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨḃ"),iiy37aKq0pCEIOwfcTh61xb4U)
	JJwnocyLUxHI2jlKF4Y,nFrfKgIy7dlN2HDCOR5AQJiL9X4pT = iiy37aKq0pCEIOwfcTh61xb4U,[]
	bP6z3OSLp7va(ZchUJdM93pTA7zG5(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬḄ"),uuExaKGL7UONtevRd(u"࡛࠭ࠨḅ")+PSwfZcdRYhpl5Igqz8xOEk67+JJwnocyLUxHI2jlKF4Y+YoQW601K4fMJcsreDnGVE5wUZIy7+hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠧࠡ࠼ส่็ูๅ࡞ࠩḆ"),iiy37aKq0pCEIOwfcTh61xb4U,Cpf9s3c0Zngj7XE,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,TlGXWLYsV1z(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ḇ")+FG615TlEM78tKb)
	bP6z3OSLp7va(YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠩࡩࡳࡱࡪࡥࡳࠩḈ"),zmcGfOdvAjsELeJlP(u"ࠪษ฾อฯสฺ่ࠢอࠦโิ็ࠣ฽ู๎วว์ࠪḉ"),iiy37aKq0pCEIOwfcTh61xb4U,Cpf9s3c0Zngj7XE,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,uuExaKGL7UONtevRd(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩḊ")+FG615TlEM78tKb)
	bP6z3OSLp7va(HtK4o2sTPgA78U(u"ࠬࡲࡩ࡯࡭ࠪḋ"),PSwfZcdRYhpl5Igqz8xOEk67+TlGXWLYsV1z(u"࠭࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫḌ")+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,jXE2YHkswT8y(u"࠼࠽࠾࠿Ẫ"))
	hu4rXM9KgvPtmSkByDwOsR = g6ghGH4aBEYkTl3vbJZ[:]
	g6ghGH4aBEYkTl3vbJZ[:] = []
	EA7FzO1kMZGQXDd2giB0cwLom = []
	if vODxLKW5Ql6r4Fbm8(u"ࠧࡠࡕࡌࡘࡊ࡙࡟ࠨḍ") in FG615TlEM78tKb:
		PPYAxHMiQIE(IpC4qHXRuyNFjzWv(u"ࡆࡢ࡮ࡶࡩỦ"))
		if not EeCo9tOcL2dIZu75g: return
		zMVPrBA7jTHdgfk8lFJ = list(EeCo9tOcL2dIZu75g.keys())
		cTrZL0ve4mDlb8Bzu6wOy = ufTX72hK8Q63jSsJiqDm5.sample(zMVPrBA7jTHdgfk8lFJ,YYJQyRskpX8jv)[FGTfwsjNrB8DvKSZhLIQAb1JnO]
		oYkjqL5mA1wUEp8fT34tVCKNOHia = list(EeCo9tOcL2dIZu75g[cTrZL0ve4mDlb8Bzu6wOy].keys())
		website = ufTX72hK8Q63jSsJiqDm5.sample(oYkjqL5mA1wUEp8fT34tVCKNOHia,YYJQyRskpX8jv)[FGTfwsjNrB8DvKSZhLIQAb1JnO]
		type,JJwnocyLUxHI2jlKF4Y,url,xl0I9SsgtGu5E,L95mrowGgdsD,zLEP9N4BOsVrXa,U94JwhRgpXCOe5,EALyNnv1Db4cUd8sQoZX2pmBVt7kM,XC10geOnQtwrs = EeCo9tOcL2dIZu75g[cTrZL0ve4mDlb8Bzu6wOy][website]
		WKquk5EaNr4RzVf(q1rohYuwnfpVZUa98L2CtQzmAcB,IIZ4e82HBP0oTmtOgaWY7hsMz(sQU2GnRoMwLK8CBdfzmNr4jXyO)+SaB5hx3PZwXRLtKgrTfQvId(u"ࠨࠢࠣࠤࡗࡧ࡮ࡥࡱࡰࠤࡈࡧࡴࡦࡩࡲࡶࡾࠦࠠࠡࡹࡨࡦࡸ࡯ࡴࡦ࠼ࠣࠫḎ")+website+AbqCJZdWQP9j(u"ࠩࠣࠤࠥࡴࡡ࡮ࡧ࠽ࠤࠬḏ")+JJwnocyLUxHI2jlKF4Y+EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠪࠤࠥࠦࡵࡳ࡮࠽ࠤࠬḐ")+url+tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠫࠥࠦࠠ࡮ࡱࡧࡩ࠿ࠦࠧḑ")+str(xl0I9SsgtGu5E))
	elif MgP8OjoaiWQEVG59(u"ࠬࡥࡉࡑࡖ࡙ࡣࠬḒ") in FG615TlEM78tKb:
		import uUbDljY0SN
		if not uUbDljY0SN.whH63ZkMf7j5gsY(iiy37aKq0pCEIOwfcTh61xb4U,xpT28sXu051(u"ࡕࡴࡸࡩủ")): return
		for skyPuAlLvecbtRZfB0pzIGd34n7xX9 in range(YYJQyRskpX8jv,IDxpbtWgzXHs3u08Q7nR6YerO+YYJQyRskpX8jv):
			EA7FzO1kMZGQXDd2giB0cwLom += ta70LOknIHDBZf8WU1GR(str(skyPuAlLvecbtRZfB0pzIGd34n7xX9),FG615TlEM78tKb)
		if not EA7FzO1kMZGQXDd2giB0cwLom: return
		type,JJwnocyLUxHI2jlKF4Y,url,xl0I9SsgtGu5E,L95mrowGgdsD,zLEP9N4BOsVrXa,U94JwhRgpXCOe5,EALyNnv1Db4cUd8sQoZX2pmBVt7kM,XC10geOnQtwrs = ufTX72hK8Q63jSsJiqDm5.sample(EA7FzO1kMZGQXDd2giB0cwLom,YYJQyRskpX8jv)[FGTfwsjNrB8DvKSZhLIQAb1JnO]
		WKquk5EaNr4RzVf(q1rohYuwnfpVZUa98L2CtQzmAcB,IIZ4e82HBP0oTmtOgaWY7hsMz(sQU2GnRoMwLK8CBdfzmNr4jXyO)+sVzojQerUqX(u"࠭ࠠࠡࠢࡕࡥࡳࡪ࡯࡮ࠢࡆࡥࡹ࡫ࡧࡰࡴࡼࠤࠥࠦ࡮ࡢ࡯ࡨ࠾ࠥ࠭ḓ")+JJwnocyLUxHI2jlKF4Y+uuExaKGL7UONtevRd(u"ࠧࠡࠢࠣࡹࡷࡲ࠺ࠡࠩḔ")+url+EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠨࠢࠣࠤࡲࡵࡤࡦ࠼ࠣࠫḕ")+str(xl0I9SsgtGu5E))
	elif GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠩࡢࡑ࠸࡛࡟ࠨḖ") in FG615TlEM78tKb:
		import FwKQq7S2Ce
		if not FwKQq7S2Ce.whH63ZkMf7j5gsY(iiy37aKq0pCEIOwfcTh61xb4U,zmcGfOdvAjsELeJlP(u"ࡖࡵࡹࡪỨ")): return
		for skyPuAlLvecbtRZfB0pzIGd34n7xX9 in range(YYJQyRskpX8jv,IDxpbtWgzXHs3u08Q7nR6YerO+YYJQyRskpX8jv):
			EA7FzO1kMZGQXDd2giB0cwLom += T3ksWRpfxniNg1z7lE69(str(skyPuAlLvecbtRZfB0pzIGd34n7xX9),FG615TlEM78tKb)
		if not EA7FzO1kMZGQXDd2giB0cwLom: return
		type,JJwnocyLUxHI2jlKF4Y,url,xl0I9SsgtGu5E,L95mrowGgdsD,zLEP9N4BOsVrXa,U94JwhRgpXCOe5,EALyNnv1Db4cUd8sQoZX2pmBVt7kM,XC10geOnQtwrs = ufTX72hK8Q63jSsJiqDm5.sample(EA7FzO1kMZGQXDd2giB0cwLom,YYJQyRskpX8jv)[FGTfwsjNrB8DvKSZhLIQAb1JnO]
		WKquk5EaNr4RzVf(q1rohYuwnfpVZUa98L2CtQzmAcB,IIZ4e82HBP0oTmtOgaWY7hsMz(sQU2GnRoMwLK8CBdfzmNr4jXyO)+CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠪࠤࠥࠦࡒࡢࡰࡧࡳࡲࠦࡃࡢࡶࡨ࡫ࡴࡸࡹࠡࠢࠣࡲࡦࡳࡥ࠻ࠢࠪḗ")+JJwnocyLUxHI2jlKF4Y+TlGXWLYsV1z(u"ࠫࠥࠦࠠࡶࡴ࡯࠾ࠥ࠭Ḙ")+url+IpC4qHXRuyNFjzWv(u"ࠬࠦࠠࠡ࡯ࡲࡨࡪࡀࠠࠨḙ")+str(xl0I9SsgtGu5E))
	OOaWzD6w8YE4cyeA0hPQ7RT = JJwnocyLUxHI2jlKF4Y
	rH4FBV8LnSX2RMI = []
	for iEfNKT3velFyGth80SA4pxbCRrVD in range(FGTfwsjNrB8DvKSZhLIQAb1JnO,tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"࠵࠵ẫ")):
		if iEfNKT3velFyGth80SA4pxbCRrVD>FGTfwsjNrB8DvKSZhLIQAb1JnO: WKquk5EaNr4RzVf(q1rohYuwnfpVZUa98L2CtQzmAcB,IIZ4e82HBP0oTmtOgaWY7hsMz(sQU2GnRoMwLK8CBdfzmNr4jXyO)+tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"࠭ࠠࠡࠢࡕࡥࡳࡪ࡯࡮ࠢࡆࡥࡹ࡫ࡧࡰࡴࡼࠤࠥࠦ࡮ࡢ࡯ࡨ࠾ࠥ࠭Ḛ")+JJwnocyLUxHI2jlKF4Y+ZchUJdM93pTA7zG5(u"ࠧࠡࠢࠣࡹࡷࡲ࠺ࠡࠩḛ")+url+ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠨࠢࠣࠤࡲࡵࡤࡦ࠼ࠣࠫḜ")+str(xl0I9SsgtGu5E))
		g6ghGH4aBEYkTl3vbJZ[:] = []
		if xl0I9SsgtGu5E==YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"࠷࠹࠴Ậ") and Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠩࡢࡣࡎࡖࡔࡗࡕࡨࡶ࡮࡫ࡳࡠࡡࠪḝ") in U94JwhRgpXCOe5: xl0I9SsgtGu5E = FRYcH4KL7e9gv5pEB(u"࠸࠳࠴ậ")
		if xl0I9SsgtGu5E==TlGXWLYsV1z(u"࠷࠲࠶Ắ") and ZchUJdM93pTA7zG5(u"ࠪࡣࡤࡓ࠳ࡖࡕࡨࡶ࡮࡫ࡳࡠࡡࠪḞ") in U94JwhRgpXCOe5: xl0I9SsgtGu5E = XrTw01KtLzbpoyMf(u"࠸࠳࠶ắ")
		if xl0I9SsgtGu5E==ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"࠳࠷࠸Ằ"): xl0I9SsgtGu5E = XrTw01KtLzbpoyMf(u"࠵࠽࠶ằ")
		qBIUYtOjTAx0 = wA8ZcpVskTjEf5GdULPi4(type,JJwnocyLUxHI2jlKF4Y,url,xl0I9SsgtGu5E,L95mrowGgdsD,zLEP9N4BOsVrXa,U94JwhRgpXCOe5,EALyNnv1Db4cUd8sQoZX2pmBVt7kM,XC10geOnQtwrs)
		if tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠫࡤࡏࡐࡕࡘࡢࠫḟ") in FG615TlEM78tKb and xl0I9SsgtGu5E==hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"࠵࠻࠽Ẳ"): del g6ghGH4aBEYkTl3vbJZ[:iiCWLaJREureAlOkv]
		if ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠬࡥࡍ࠴ࡗࡢࠫḠ") in FG615TlEM78tKb and xl0I9SsgtGu5E==HtK4o2sTPgA78U(u"࠶࠼࠸ẳ"): del g6ghGH4aBEYkTl3vbJZ[:iiCWLaJREureAlOkv]
		nFrfKgIy7dlN2HDCOR5AQJiL9X4pT[:] = Ygx4eF6jNd5(g6ghGH4aBEYkTl3vbJZ)
		if rH4FBV8LnSX2RMI and Q5V784gMylUrz3T2ZhAYFKLnE(y6y5HtgXO4TkUbwVZ(u"ࡻࠧฮๆๅอࠬḡ")) in str(nFrfKgIy7dlN2HDCOR5AQJiL9X4pT) or Q5V784gMylUrz3T2ZhAYFKLnE(CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࡵࠨฯ็ๆ์࠭Ḣ")) in str(nFrfKgIy7dlN2HDCOR5AQJiL9X4pT):
			JJwnocyLUxHI2jlKF4Y = OOaWzD6w8YE4cyeA0hPQ7RT
			nFrfKgIy7dlN2HDCOR5AQJiL9X4pT[:] = rH4FBV8LnSX2RMI
			break
		OOaWzD6w8YE4cyeA0hPQ7RT = JJwnocyLUxHI2jlKF4Y
		rH4FBV8LnSX2RMI = nFrfKgIy7dlN2HDCOR5AQJiL9X4pT
		if str(nFrfKgIy7dlN2HDCOR5AQJiL9X4pT).count(AbqCJZdWQP9j(u"ࠨࡸ࡬ࡨࡪࡵࠧḣ"))>FGTfwsjNrB8DvKSZhLIQAb1JnO: break
		if str(nFrfKgIy7dlN2HDCOR5AQJiL9X4pT).count(tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠩ࡯࡭ࡻ࡫ࠧḤ"))>FGTfwsjNrB8DvKSZhLIQAb1JnO: break
		if xl0I9SsgtGu5E==ZchUJdM93pTA7zG5(u"࠸࠳࠴Ẵ"): break
		if xl0I9SsgtGu5E==jXE2YHkswT8y(u"࠷࠲࠵ẵ"): break
		if xl0I9SsgtGu5E==YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"࠳࠻࠴Ặ"): break
		if FRYcH4KL7e9gv5pEB(u"ࠪࡣࡗࡇࡎࡅࡑࡐࡣࠬḥ") in FG615TlEM78tKb and nFrfKgIy7dlN2HDCOR5AQJiL9X4pT: type,JJwnocyLUxHI2jlKF4Y,url,xl0I9SsgtGu5E,L95mrowGgdsD,zLEP9N4BOsVrXa,U94JwhRgpXCOe5,EALyNnv1Db4cUd8sQoZX2pmBVt7kM,XC10geOnQtwrs = ufTX72hK8Q63jSsJiqDm5.sample(nFrfKgIy7dlN2HDCOR5AQJiL9X4pT,YYJQyRskpX8jv)[FGTfwsjNrB8DvKSZhLIQAb1JnO]
	if not JJwnocyLUxHI2jlKF4Y: JJwnocyLUxHI2jlKF4Y = hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠫ࠳࠴࠮࠯ࠩḦ")
	elif JJwnocyLUxHI2jlKF4Y.count(YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠬࡥࠧḧ"))>YYJQyRskpX8jv: JJwnocyLUxHI2jlKF4Y = JJwnocyLUxHI2jlKF4Y.split(AbqCJZdWQP9j(u"࠭࡟ࠨḨ"),nI2JK1RfsGWNY3OarEeMQZ)[nI2JK1RfsGWNY3OarEeMQZ]
	JJwnocyLUxHI2jlKF4Y = JJwnocyLUxHI2jlKF4Y.replace(Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠧࡖࡐࡎࡒࡔ࡝ࡎ࠻ࠢࠪḩ"),iiy37aKq0pCEIOwfcTh61xb4U)
	JJwnocyLUxHI2jlKF4Y = JJwnocyLUxHI2jlKF4Y.replace(tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠨࡡࡐࡓࡉࡥࠧḪ"),iiy37aKq0pCEIOwfcTh61xb4U)
	hu4rXM9KgvPtmSkByDwOsR[FGTfwsjNrB8DvKSZhLIQAb1JnO][YYJQyRskpX8jv] = hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠩ࡞ࠫḫ")+PSwfZcdRYhpl5Igqz8xOEk67+JJwnocyLUxHI2jlKF4Y+YoQW601K4fMJcsreDnGVE5wUZIy7+HtK4o2sTPgA78U(u"ࠪࠤ࠿อไใี่ࡡࠬḬ")
	if FRYcH4KL7e9gv5pEB(u"ࠫࡤࡘࡁࡏࡆࡒࡑࡤ࠭ḭ") in FG615TlEM78tKb:
		for iEfNKT3velFyGth80SA4pxbCRrVD in range(YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"࠻ặ")): ufTX72hK8Q63jSsJiqDm5.shuffle(nFrfKgIy7dlN2HDCOR5AQJiL9X4pT)
		g6ghGH4aBEYkTl3vbJZ[:] = hu4rXM9KgvPtmSkByDwOsR+nFrfKgIy7dlN2HDCOR5AQJiL9X4pT[:KP7x1T4ZpAgc0Ld5r]
	else: g6ghGH4aBEYkTl3vbJZ[:] = hu4rXM9KgvPtmSkByDwOsR+nFrfKgIy7dlN2HDCOR5AQJiL9X4pT
	return
def sWi2cUgfOCEu0rQk13MAF5b(xu7Mi3GXcYVd,MkpKCwyeXmDhQ):
	MkpKCwyeXmDhQ = MkpKCwyeXmDhQ.replace(SaB5hx3PZwXRLtKgrTfQvId(u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧḮ"),iiy37aKq0pCEIOwfcTh61xb4U).replace(ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪḯ"),iiy37aKq0pCEIOwfcTh61xb4U)
	uuclWkLq8dyUzXMEF4DoGTaiOwHgt = MkpKCwyeXmDhQ
	if PtkEvXAqif14G20QZsaSyT(u"ࠧࡠࡡࡌࡔ࡙࡜ࡓࡦࡴ࡬ࡩࡸࡥ࡟ࠨḰ") in MkpKCwyeXmDhQ:
		uuclWkLq8dyUzXMEF4DoGTaiOwHgt = MkpKCwyeXmDhQ.split(LyNiIHPOwD3hCUYEFM7(u"ࠨࡡࡢࡍࡕ࡚ࡖࡔࡧࡵ࡭ࡪࡹ࡟ࡠࠩḱ"))[FGTfwsjNrB8DvKSZhLIQAb1JnO]
		type = IpC4qHXRuyNFjzWv(u"ࠩ࠯ࡗࡊࡘࡉࡆࡕ࠽ࠤࠬḲ")
	elif MgP8OjoaiWQEVG59(u"࡚ࠪࡔࡊࠧḳ") in xu7Mi3GXcYVd: type = y6y5HtgXO4TkUbwVZ(u"ࠫ࠱࡜ࡉࡅࡇࡒࡗ࠿ࠦࠧḴ")
	elif FRYcH4KL7e9gv5pEB(u"ࠬࡒࡉࡗࡇࠪḵ") in xu7Mi3GXcYVd: type = L90uqo28xEKSFUwYTcm51yRWZIkft(u"࠭ࠬࡍࡋ࡙ࡉ࠿ࠦࠧḶ")
	bP6z3OSLp7va(uuExaKGL7UONtevRd(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧḷ"),L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠨ࡝ࠪḸ")+PSwfZcdRYhpl5Igqz8xOEk67+type+uuclWkLq8dyUzXMEF4DoGTaiOwHgt+YoQW601K4fMJcsreDnGVE5wUZIy7+UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠩࠣ࠾ฬ๊โิ็ࡠࠫḹ"),xu7Mi3GXcYVd,tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"࠴࠺࠼Ẹ"),iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,XrTw01KtLzbpoyMf(u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨḺ")+MkpKCwyeXmDhQ)
	bP6z3OSLp7va(TlGXWLYsV1z(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫḻ"),MgP8OjoaiWQEVG59(u"ࠬหูศัฬࠤฬ๊ืๅสࠣห้฿ิ้ษษ๎๋ࠥๆ่ࠡไืࠥอไใี่ࠫḼ"),xu7Mi3GXcYVd,ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"࠵࠻࠽ẹ"),iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,sVzojQerUqX(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫḽ")+MkpKCwyeXmDhQ)
	bP6z3OSLp7va(LyNiIHPOwD3hCUYEFM7(u"ࠧ࡭࡫ࡱ࡯ࠬḾ"),PSwfZcdRYhpl5Igqz8xOEk67+hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠨ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥ࠭ḿ")+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,ZchUJdM93pTA7zG5(u"࠾࠿࠹࠺Ẻ"))
	import uUbDljY0SN
	for skyPuAlLvecbtRZfB0pzIGd34n7xX9 in range(YYJQyRskpX8jv,IDxpbtWgzXHs3u08Q7nR6YerO+YYJQyRskpX8jv):
		if hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠩࡢࡣࡎࡖࡔࡗࡕࡨࡶ࡮࡫ࡳࡠࡡࠪṀ") in MkpKCwyeXmDhQ: uUbDljY0SN.CFhvzLMJ5KiywpIfANxqgHGrloT(str(skyPuAlLvecbtRZfB0pzIGd34n7xX9),xu7Mi3GXcYVd,MkpKCwyeXmDhQ,iiy37aKq0pCEIOwfcTh61xb4U,jXE2YHkswT8y(u"ࡉࡥࡱࡹࡥứ"))
		else: uUbDljY0SN.rmEH1eAYBg8xPK(str(skyPuAlLvecbtRZfB0pzIGd34n7xX9),xu7Mi3GXcYVd,MkpKCwyeXmDhQ,iiy37aKq0pCEIOwfcTh61xb4U,CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࡊࡦࡲࡳࡦỪ"))
	g6ghGH4aBEYkTl3vbJZ[:] = Ygx4eF6jNd5(g6ghGH4aBEYkTl3vbJZ)
	if len(g6ghGH4aBEYkTl3vbJZ)>(KP7x1T4ZpAgc0Ld5r+iiCWLaJREureAlOkv): g6ghGH4aBEYkTl3vbJZ[:] = g6ghGH4aBEYkTl3vbJZ[:iiCWLaJREureAlOkv]+ufTX72hK8Q63jSsJiqDm5.sample(g6ghGH4aBEYkTl3vbJZ[iiCWLaJREureAlOkv:],KP7x1T4ZpAgc0Ld5r)
	return
def elvpHcCnarGE8LDwUSRM69Z(xu7Mi3GXcYVd,MkpKCwyeXmDhQ):
	MkpKCwyeXmDhQ = MkpKCwyeXmDhQ.replace(FRYcH4KL7e9gv5pEB(u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬṁ"),iiy37aKq0pCEIOwfcTh61xb4U).replace(AbqCJZdWQP9j(u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨṂ"),iiy37aKq0pCEIOwfcTh61xb4U)
	uuclWkLq8dyUzXMEF4DoGTaiOwHgt = MkpKCwyeXmDhQ
	if MgP8OjoaiWQEVG59(u"ࠬࡥ࡟ࡎ࠵ࡘࡗࡪࡸࡩࡦࡵࡢࡣࠬṃ") in MkpKCwyeXmDhQ:
		uuclWkLq8dyUzXMEF4DoGTaiOwHgt = MkpKCwyeXmDhQ.split(XrTw01KtLzbpoyMf(u"࠭࡟ࡠࡏ࠶࡙ࡘ࡫ࡲࡪࡧࡶࡣࡤ࠭Ṅ"))[FGTfwsjNrB8DvKSZhLIQAb1JnO]
		type = LyNiIHPOwD3hCUYEFM7(u"ࠧ࠭ࡕࡈࡖࡎࡋࡓ࠻ࠢࠪṅ")
	elif JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠨࡘࡒࡈࠬṆ") in xu7Mi3GXcYVd: type = SaB5hx3PZwXRLtKgrTfQvId(u"ࠩ࠯࡚ࡎࡊࡅࡐࡕ࠽ࠤࠬṇ")
	elif EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠪࡐࡎ࡜ࡅࠨṈ") in xu7Mi3GXcYVd: type = zmcGfOdvAjsELeJlP(u"ࠫ࠱ࡒࡉࡗࡇ࠽ࠤࠬṉ")
	bP6z3OSLp7va(MgP8OjoaiWQEVG59(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬṊ"),LyNiIHPOwD3hCUYEFM7(u"࡛࠭ࠨṋ")+PSwfZcdRYhpl5Igqz8xOEk67+type+uuclWkLq8dyUzXMEF4DoGTaiOwHgt+YoQW601K4fMJcsreDnGVE5wUZIy7+IpC4qHXRuyNFjzWv(u"ࠧࠡ࠼ส่็ูๅ࡞ࠩṌ"),xu7Mi3GXcYVd,jXE2YHkswT8y(u"࠷࠶࠹ẻ"),iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ṍ")+MkpKCwyeXmDhQ)
	bP6z3OSLp7va(uuExaKGL7UONtevRd(u"ࠩࡩࡳࡱࡪࡥࡳࠩṎ"),GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠪษ฾อฯสࠢส่฼๊ศࠡษ็฽ู๎วว์้๋ࠣࠦๆโีࠣห้่ำๆࠩṏ"),xu7Mi3GXcYVd,MgP8OjoaiWQEVG59(u"࠱࠷࠺Ẽ"),iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,TlGXWLYsV1z(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩṐ")+MkpKCwyeXmDhQ)
	bP6z3OSLp7va(LyNiIHPOwD3hCUYEFM7(u"ࠬࡲࡩ࡯࡭ࠪṑ"),PSwfZcdRYhpl5Igqz8xOEk67+YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"࠭࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫṒ")+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,SaB5hx3PZwXRLtKgrTfQvId(u"࠺࠻࠼࠽ẽ"))
	import FwKQq7S2Ce
	for skyPuAlLvecbtRZfB0pzIGd34n7xX9 in range(YYJQyRskpX8jv,IDxpbtWgzXHs3u08Q7nR6YerO+YYJQyRskpX8jv):
		if AbqCJZdWQP9j(u"ࠧࡠࡡࡐ࠷࡚࡙ࡥࡳ࡫ࡨࡷࡤࡥࠧṓ") in MkpKCwyeXmDhQ: FwKQq7S2Ce.CFhvzLMJ5KiywpIfANxqgHGrloT(str(skyPuAlLvecbtRZfB0pzIGd34n7xX9),xu7Mi3GXcYVd,MkpKCwyeXmDhQ,iiy37aKq0pCEIOwfcTh61xb4U,jXE2YHkswT8y(u"ࡋࡧ࡬ࡴࡧừ"))
		else: FwKQq7S2Ce.rmEH1eAYBg8xPK(str(skyPuAlLvecbtRZfB0pzIGd34n7xX9),xu7Mi3GXcYVd,MkpKCwyeXmDhQ,iiy37aKq0pCEIOwfcTh61xb4U,ZchUJdM93pTA7zG5(u"ࡌࡡ࡭ࡵࡨỬ"))
	g6ghGH4aBEYkTl3vbJZ[:] = Ygx4eF6jNd5(g6ghGH4aBEYkTl3vbJZ)
	if len(g6ghGH4aBEYkTl3vbJZ)>(KP7x1T4ZpAgc0Ld5r+iiCWLaJREureAlOkv): g6ghGH4aBEYkTl3vbJZ[:] = g6ghGH4aBEYkTl3vbJZ[:iiCWLaJREureAlOkv]+ufTX72hK8Q63jSsJiqDm5.sample(g6ghGH4aBEYkTl3vbJZ[iiCWLaJREureAlOkv:],KP7x1T4ZpAgc0Ld5r)
	return
def Ygx4eF6jNd5(g6ghGH4aBEYkTl3vbJZ):
	iALGDZcogM1YJpju6rOs9bB3XlU45 = []
	for type,JJwnocyLUxHI2jlKF4Y,url,Cpf9s3c0Zngj7XE,L95mrowGgdsD,zLEP9N4BOsVrXa,U94JwhRgpXCOe5,EALyNnv1Db4cUd8sQoZX2pmBVt7kM,XC10geOnQtwrs in g6ghGH4aBEYkTl3vbJZ:
		if ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠨืไัฮ࠭Ṕ") in JJwnocyLUxHI2jlKF4Y or ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ุࠩๅาํࠧṕ") in JJwnocyLUxHI2jlKF4Y or TlGXWLYsV1z(u"ࠪࡴࡦ࡭ࡥࠨṖ") in JJwnocyLUxHI2jlKF4Y.lower(): continue
		iALGDZcogM1YJpju6rOs9bB3XlU45.append([type,JJwnocyLUxHI2jlKF4Y,url,Cpf9s3c0Zngj7XE,L95mrowGgdsD,zLEP9N4BOsVrXa,U94JwhRgpXCOe5,EALyNnv1Db4cUd8sQoZX2pmBVt7kM,XC10geOnQtwrs])
	return iALGDZcogM1YJpju6rOs9bB3XlU45
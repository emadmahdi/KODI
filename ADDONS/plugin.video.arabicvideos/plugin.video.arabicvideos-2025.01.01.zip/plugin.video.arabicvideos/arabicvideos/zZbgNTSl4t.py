# -*- coding: utf-8 -*-
from braVAkwfBN import *
x25j0zbNOqAe4BgIoQtcd = 'EXCLUDES'
def ZxrNSndhFM1CXz(JJwnocyLUxHI2jlKF4Y,vZJ9OKH6ydYXurzbC5csFMkpw8):
	vZJ9OKH6ydYXurzbC5csFMkpw8 = vZJ9OKH6ydYXurzbC5csFMkpw8.replace(PSwfZcdRYhpl5Igqz8xOEk67,iiy37aKq0pCEIOwfcTh61xb4U).replace(' '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U)[1:]
	dp7PbyYaMgZUfSiGjhCDmk81 = dEyT9xhGjolYzLCH7460w3.findall('[a-zA-Z]',JJwnocyLUxHI2jlKF4Y,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if 'بحث IPTV - ' in JJwnocyLUxHI2jlKF4Y: JJwnocyLUxHI2jlKF4Y = JJwnocyLUxHI2jlKF4Y.replace('بحث IPTV - ',DApVioTIRMGX+'بحث IPTV - '+DApVioTIRMGX)
	elif ' IPTV' in JJwnocyLUxHI2jlKF4Y and vZJ9OKH6ydYXurzbC5csFMkpw8=='IPT': JJwnocyLUxHI2jlKF4Y = DApVioTIRMGX+JJwnocyLUxHI2jlKF4Y
	elif 'بحث M3U - ' in JJwnocyLUxHI2jlKF4Y: JJwnocyLUxHI2jlKF4Y = JJwnocyLUxHI2jlKF4Y.replace('بحث M3U - ',DApVioTIRMGX+'بحث M3U - '+DApVioTIRMGX)
	elif ' M3U' in JJwnocyLUxHI2jlKF4Y and vZJ9OKH6ydYXurzbC5csFMkpw8=='M3U': JJwnocyLUxHI2jlKF4Y = DApVioTIRMGX+JJwnocyLUxHI2jlKF4Y
	elif 'بحث ' in JJwnocyLUxHI2jlKF4Y and ' - ' in JJwnocyLUxHI2jlKF4Y: JJwnocyLUxHI2jlKF4Y = DApVioTIRMGX+JJwnocyLUxHI2jlKF4Y
	elif not dp7PbyYaMgZUfSiGjhCDmk81:
		bJkiuP41DfVh5vsFxS9RX7OGUalr = dEyT9xhGjolYzLCH7460w3.findall('^( *?)(.*?)( *?)$',JJwnocyLUxHI2jlKF4Y)
		fLkiWsdItMHmANae38huP5zKU,VWQ8M72Edqt,QEe7BKrc1hjf95bGY3oCdMLpPJn = bJkiuP41DfVh5vsFxS9RX7OGUalr[0]
		Mj21ba3KNTVd0XLe97RYuUhvOBw = dEyT9xhGjolYzLCH7460w3.findall('^([!-~])',VWQ8M72Edqt)
		if Mj21ba3KNTVd0XLe97RYuUhvOBw: JJwnocyLUxHI2jlKF4Y = fLkiWsdItMHmANae38huP5zKU+Ds9inqGKb5frAd2CzmWke61aMQ+VWQ8M72Edqt+QEe7BKrc1hjf95bGY3oCdMLpPJn
		else: JJwnocyLUxHI2jlKF4Y = QEe7BKrc1hjf95bGY3oCdMLpPJn+DApVioTIRMGX+VWQ8M72Edqt+fLkiWsdItMHmANae38huP5zKU
	else:
		import bidi.algorithm as k9WamxRu6M4K0qeEXY
		if 1:
			aIguEAKyCTWpGZBhOQqt = JJwnocyLUxHI2jlKF4Y
			llFZwkHrGJMxiagR = k9WamxRu6M4K0qeEXY.get_display(JJwnocyLUxHI2jlKF4Y,base_dir='L')
			if iELueYz3J1FmxaW7vc: aIguEAKyCTWpGZBhOQqt = aIguEAKyCTWpGZBhOQqt.decode(df6QpwGxuJVZr)
			if iELueYz3J1FmxaW7vc: llFZwkHrGJMxiagR = llFZwkHrGJMxiagR.decode(df6QpwGxuJVZr)
			cmUrPQwdxy = aIguEAKyCTWpGZBhOQqt.split(iFBmE2MUIpSu34wsd7Rf6z)
			Zj8JfvnwB2KLARrGmIq0W = llFZwkHrGJMxiagR.split(iFBmE2MUIpSu34wsd7Rf6z)
			c2cvI9GwyP3M0p8uCKQlmOtNV,llHAovZdEuLUzg8qSRk,Y4AvtJI6VgyQru,aTxs8mOkbrUI = [],[],iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U
			l4HWzQn5Bo8Prv7MKtbRjqSGaXLmU = zip(cmUrPQwdxy,Zj8JfvnwB2KLARrGmIq0W)
			for vsam4PCcUo683Z,wRADIq3QJg50ce4WpOLG in l4HWzQn5Bo8Prv7MKtbRjqSGaXLmU:
				if vsam4PCcUo683Z==wRADIq3QJg50ce4WpOLG==iiy37aKq0pCEIOwfcTh61xb4U and aTxs8mOkbrUI:
					Y4AvtJI6VgyQru += iFBmE2MUIpSu34wsd7Rf6z
					continue
				if vsam4PCcUo683Z==wRADIq3QJg50ce4WpOLG:
					qFDW3lkLsoApuBV1M = 'EN'
					if aTxs8mOkbrUI==qFDW3lkLsoApuBV1M: Y4AvtJI6VgyQru += iFBmE2MUIpSu34wsd7Rf6z+vsam4PCcUo683Z
					elif vsam4PCcUo683Z:
						if Y4AvtJI6VgyQru:
							llHAovZdEuLUzg8qSRk.append(Y4AvtJI6VgyQru)
							c2cvI9GwyP3M0p8uCKQlmOtNV.append(iiy37aKq0pCEIOwfcTh61xb4U)
						Y4AvtJI6VgyQru = vsam4PCcUo683Z
				else:
					qFDW3lkLsoApuBV1M = 'AR'
					if aTxs8mOkbrUI==qFDW3lkLsoApuBV1M: Y4AvtJI6VgyQru += iFBmE2MUIpSu34wsd7Rf6z+vsam4PCcUo683Z
					elif vsam4PCcUo683Z:
						if Y4AvtJI6VgyQru:
							c2cvI9GwyP3M0p8uCKQlmOtNV.append(Y4AvtJI6VgyQru)
							llHAovZdEuLUzg8qSRk.append(iiy37aKq0pCEIOwfcTh61xb4U)
						Y4AvtJI6VgyQru = vsam4PCcUo683Z
				aTxs8mOkbrUI = qFDW3lkLsoApuBV1M
			if qFDW3lkLsoApuBV1M=='EN':
				c2cvI9GwyP3M0p8uCKQlmOtNV.append(Y4AvtJI6VgyQru)
				llHAovZdEuLUzg8qSRk.append(iiy37aKq0pCEIOwfcTh61xb4U)
			else:
				llHAovZdEuLUzg8qSRk.append(Y4AvtJI6VgyQru)
				c2cvI9GwyP3M0p8uCKQlmOtNV.append(iiy37aKq0pCEIOwfcTh61xb4U)
			x0ZTVCSK1qcWG5LMzfvI3awOAnuXBU = iiy37aKq0pCEIOwfcTh61xb4U
			l4HWzQn5Bo8Prv7MKtbRjqSGaXLmU = zip(c2cvI9GwyP3M0p8uCKQlmOtNV,llHAovZdEuLUzg8qSRk)
			import bidi.mirror as nwZJHXWch8pLEfPUDSyqYAO
			for Z9Dy75ibBTUjJ,qWVJn6sUkHPrmiRfXD7 in l4HWzQn5Bo8Prv7MKtbRjqSGaXLmU:
				if Z9Dy75ibBTUjJ: x0ZTVCSK1qcWG5LMzfvI3awOAnuXBU += iFBmE2MUIpSu34wsd7Rf6z+Z9Dy75ibBTUjJ
				else:
					Mj21ba3KNTVd0XLe97RYuUhvOBw = dEyT9xhGjolYzLCH7460w3.findall('([!-~]) *$',qWVJn6sUkHPrmiRfXD7)
					if Mj21ba3KNTVd0XLe97RYuUhvOBw:
						Mj21ba3KNTVd0XLe97RYuUhvOBw = Mj21ba3KNTVd0XLe97RYuUhvOBw[0]
						try:
							pSoMOYJ5aNCcE63l1DmFsfIBh = nwZJHXWch8pLEfPUDSyqYAO.MIRRORED[Mj21ba3KNTVd0XLe97RYuUhvOBw]
							bJkiuP41DfVh5vsFxS9RX7OGUalr = dEyT9xhGjolYzLCH7460w3.findall('^( *?)(.*?)( *?)$',qWVJn6sUkHPrmiRfXD7)
							if bJkiuP41DfVh5vsFxS9RX7OGUalr: fLkiWsdItMHmANae38huP5zKU,qWVJn6sUkHPrmiRfXD7,QEe7BKrc1hjf95bGY3oCdMLpPJn = bJkiuP41DfVh5vsFxS9RX7OGUalr[0]
							qWVJn6sUkHPrmiRfXD7 = fLkiWsdItMHmANae38huP5zKU+pSoMOYJ5aNCcE63l1DmFsfIBh+qWVJn6sUkHPrmiRfXD7[:-1]+QEe7BKrc1hjf95bGY3oCdMLpPJn
						except: pass
					x0ZTVCSK1qcWG5LMzfvI3awOAnuXBU += iFBmE2MUIpSu34wsd7Rf6z+qWVJn6sUkHPrmiRfXD7
			JJwnocyLUxHI2jlKF4Y = x0ZTVCSK1qcWG5LMzfvI3awOAnuXBU[1:]
			if iELueYz3J1FmxaW7vc: JJwnocyLUxHI2jlKF4Y = JJwnocyLUxHI2jlKF4Y.encode(df6QpwGxuJVZr)
		else:
			if iELueYz3J1FmxaW7vc: JJwnocyLUxHI2jlKF4Y = JJwnocyLUxHI2jlKF4Y.decode(df6QpwGxuJVZr)
			JJwnocyLUxHI2jlKF4Y = k9WamxRu6M4K0qeEXY.get_display(JJwnocyLUxHI2jlKF4Y)
			aIguEAKyCTWpGZBhOQqt,llFZwkHrGJMxiagR = JJwnocyLUxHI2jlKF4Y,JJwnocyLUxHI2jlKF4Y
			if 1:
				aTxs8mOkbrUI,CJpbD5TAt13zjX7rEB80ueLWwqfsi = iiy37aKq0pCEIOwfcTh61xb4U,[]
				rupFwIGaqhXW24UE91CA0inQeo = JJwnocyLUxHI2jlKF4Y.split(iFBmE2MUIpSu34wsd7Rf6z)
				for MJuaOYAvsgHnPXp42V5bKLdB1jmEUy in rupFwIGaqhXW24UE91CA0inQeo:
					if not MJuaOYAvsgHnPXp42V5bKLdB1jmEUy:
						if CJpbD5TAt13zjX7rEB80ueLWwqfsi: CJpbD5TAt13zjX7rEB80ueLWwqfsi[-1] += iFBmE2MUIpSu34wsd7Rf6z
						else: CJpbD5TAt13zjX7rEB80ueLWwqfsi.append(iiy37aKq0pCEIOwfcTh61xb4U)
						continue
					MMA4jWDaYCP8REBLytOvmcJ0s1x = dEyT9xhGjolYzLCH7460w3.findall('[!-~]',MJuaOYAvsgHnPXp42V5bKLdB1jmEUy[0])
					if MMA4jWDaYCP8REBLytOvmcJ0s1x==aTxs8mOkbrUI and CJpbD5TAt13zjX7rEB80ueLWwqfsi: CJpbD5TAt13zjX7rEB80ueLWwqfsi[-1] += iFBmE2MUIpSu34wsd7Rf6z+MJuaOYAvsgHnPXp42V5bKLdB1jmEUy
					else:
						if CJpbD5TAt13zjX7rEB80ueLWwqfsi:
							T8od1tH26i4mINgXp9bM3ukEZ07Cv = dEyT9xhGjolYzLCH7460w3.findall('[^!-~]',CJpbD5TAt13zjX7rEB80ueLWwqfsi[-1])
							if T8od1tH26i4mINgXp9bM3ukEZ07Cv:
								CJpbD5TAt13zjX7rEB80ueLWwqfsi[-1] = k9WamxRu6M4K0qeEXY.get_display(CJpbD5TAt13zjX7rEB80ueLWwqfsi[-1])
								WH3x9M80KNZXS5Iah64uGcCJj2w = dEyT9xhGjolYzLCH7460w3.findall('^ +',CJpbD5TAt13zjX7rEB80ueLWwqfsi[-1])
								if WH3x9M80KNZXS5Iah64uGcCJj2w: CJpbD5TAt13zjX7rEB80ueLWwqfsi[-1] = CJpbD5TAt13zjX7rEB80ueLWwqfsi[-1].lstrip(iFBmE2MUIpSu34wsd7Rf6z)+WH3x9M80KNZXS5Iah64uGcCJj2w[0]
						CJpbD5TAt13zjX7rEB80ueLWwqfsi.append(MJuaOYAvsgHnPXp42V5bKLdB1jmEUy)
					aTxs8mOkbrUI = MMA4jWDaYCP8REBLytOvmcJ0s1x
				if CJpbD5TAt13zjX7rEB80ueLWwqfsi: CJpbD5TAt13zjX7rEB80ueLWwqfsi[-1] = k9WamxRu6M4K0qeEXY.get_display(CJpbD5TAt13zjX7rEB80ueLWwqfsi[-1])
				JJwnocyLUxHI2jlKF4Y = iFBmE2MUIpSu34wsd7Rf6z.join(CJpbD5TAt13zjX7rEB80ueLWwqfsi)
			if iELueYz3J1FmxaW7vc: JJwnocyLUxHI2jlKF4Y = JJwnocyLUxHI2jlKF4Y.encode(df6QpwGxuJVZr)
	return JJwnocyLUxHI2jlKF4Y
def mOlYsSNcyniA9(Qi2fSRlvnOdsN3DhybuEL8z754,SSBM9WCAtqjmyE5gO,cSAXLFYpH0M9gdlqIRx):
	synCYOiMR789twmfr,JJwnocyLUxHI2jlKF4Y,kMqh74TPvpSDar59xQUjAyVlHes,Cpf9s3c0Zngj7XE,GmrA8hvBgN4bDdEWXS9nVMtU,tRFsgQzEj2O3wC,LiVN2UT7XAQRujrZp1,YGNomIp2tDSR6ncf,BSmlfc08nJ = Qi2fSRlvnOdsN3DhybuEL8z754
	Cpf9s3c0Zngj7XE = int(Cpf9s3c0Zngj7XE)
	xXQEHnNz4DGCrbpd63mLaFOsZ0 = dEyT9xhGjolYzLCH7460w3.findall('(_(\d\d\.\d\d)_(\d\d\:\d\d)_)',JJwnocyLUxHI2jlKF4Y,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if xXQEHnNz4DGCrbpd63mLaFOsZ0:
		xXQEHnNz4DGCrbpd63mLaFOsZ0,My3LZsCBv6PVURi8SWhpcINfKzax,LEBVYcW7kh1Sn3CzTql = xXQEHnNz4DGCrbpd63mLaFOsZ0[0]
		JJwnocyLUxHI2jlKF4Y = JJwnocyLUxHI2jlKF4Y.replace(xXQEHnNz4DGCrbpd63mLaFOsZ0,iiy37aKq0pCEIOwfcTh61xb4U)
	BDSpV74ITroL = JJwnocyLUxHI2jlKF4Y
	vZJ9OKH6ydYXurzbC5csFMkpw8 = dEyT9xhGjolYzLCH7460w3.findall('^_(\w\w\w)_(.*?)$',JJwnocyLUxHI2jlKF4Y,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if vZJ9OKH6ydYXurzbC5csFMkpw8:
		vZJ9OKH6ydYXurzbC5csFMkpw8,JJwnocyLUxHI2jlKF4Y = vZJ9OKH6ydYXurzbC5csFMkpw8[0]
		FZnJXTQ2eGmipjNwVvzI = '_MOD_' in JJwnocyLUxHI2jlKF4Y
		QZEi0WbICGAXPzH876 = synCYOiMR789twmfr=='folder'
		if FZnJXTQ2eGmipjNwVvzI and QZEi0WbICGAXPzH876: HxOrYzlCXasuSdjBb = ';'
		elif FZnJXTQ2eGmipjNwVvzI and not QZEi0WbICGAXPzH876: HxOrYzlCXasuSdjBb = IrGVXjLSAaDgOm4lE80Q
		elif not FZnJXTQ2eGmipjNwVvzI and QZEi0WbICGAXPzH876: HxOrYzlCXasuSdjBb = ','
		elif not FZnJXTQ2eGmipjNwVvzI and not QZEi0WbICGAXPzH876: HxOrYzlCXasuSdjBb = iFBmE2MUIpSu34wsd7Rf6z
		JJwnocyLUxHI2jlKF4Y = JJwnocyLUxHI2jlKF4Y.replace('_MOD_',iiy37aKq0pCEIOwfcTh61xb4U)
		vZJ9OKH6ydYXurzbC5csFMkpw8 = HxOrYzlCXasuSdjBb+PSwfZcdRYhpl5Igqz8xOEk67+vZJ9OKH6ydYXurzbC5csFMkpw8+' '+YoQW601K4fMJcsreDnGVE5wUZIy7
	else: vZJ9OKH6ydYXurzbC5csFMkpw8 = iiy37aKq0pCEIOwfcTh61xb4U
	if xXQEHnNz4DGCrbpd63mLaFOsZ0:
		if iELueYz3J1FmxaW7vc:
			xXQEHnNz4DGCrbpd63mLaFOsZ0 = aqEsMBckT2bunGHfl48Wip+My3LZsCBv6PVURi8SWhpcINfKzax+iFBmE2MUIpSu34wsd7Rf6z+LEBVYcW7kh1Sn3CzTql+YoQW601K4fMJcsreDnGVE5wUZIy7
			if vZJ9OKH6ydYXurzbC5csFMkpw8: JJwnocyLUxHI2jlKF4Y = xXQEHnNz4DGCrbpd63mLaFOsZ0+iFBmE2MUIpSu34wsd7Rf6z+DApVioTIRMGX+vZJ9OKH6ydYXurzbC5csFMkpw8+JJwnocyLUxHI2jlKF4Y
			else: JJwnocyLUxHI2jlKF4Y = xXQEHnNz4DGCrbpd63mLaFOsZ0+DApVioTIRMGX+JJwnocyLUxHI2jlKF4Y+iFBmE2MUIpSu34wsd7Rf6z
		elif J1MoiYc7ZwzKS:
			if vZJ9OKH6ydYXurzbC5csFMkpw8:
				xXQEHnNz4DGCrbpd63mLaFOsZ0 = aqEsMBckT2bunGHfl48Wip+My3LZsCBv6PVURi8SWhpcINfKzax+iFBmE2MUIpSu34wsd7Rf6z+LEBVYcW7kh1Sn3CzTql+YoQW601K4fMJcsreDnGVE5wUZIy7
				JJwnocyLUxHI2jlKF4Y = xXQEHnNz4DGCrbpd63mLaFOsZ0+iFBmE2MUIpSu34wsd7Rf6z+vZJ9OKH6ydYXurzbC5csFMkpw8+JJwnocyLUxHI2jlKF4Y
			else:
				xXQEHnNz4DGCrbpd63mLaFOsZ0 = aqEsMBckT2bunGHfl48Wip+LEBVYcW7kh1Sn3CzTql+iFBmE2MUIpSu34wsd7Rf6z+My3LZsCBv6PVURi8SWhpcINfKzax+YoQW601K4fMJcsreDnGVE5wUZIy7
				JJwnocyLUxHI2jlKF4Y = JJwnocyLUxHI2jlKF4Y+iFBmE2MUIpSu34wsd7Rf6z+DApVioTIRMGX+xXQEHnNz4DGCrbpd63mLaFOsZ0
	elif vZJ9OKH6ydYXurzbC5csFMkpw8:
		JJwnocyLUxHI2jlKF4Y = ZxrNSndhFM1CXz(JJwnocyLUxHI2jlKF4Y,vZJ9OKH6ydYXurzbC5csFMkpw8)
		JJwnocyLUxHI2jlKF4Y = vZJ9OKH6ydYXurzbC5csFMkpw8+JJwnocyLUxHI2jlKF4Y
	Qi2fSRlvnOdsN3DhybuEL8z754 = synCYOiMR789twmfr,BDSpV74ITroL,kMqh74TPvpSDar59xQUjAyVlHes,str(Cpf9s3c0Zngj7XE),GmrA8hvBgN4bDdEWXS9nVMtU,tRFsgQzEj2O3wC,LiVN2UT7XAQRujrZp1,YGNomIp2tDSR6ncf,BSmlfc08nJ
	rDowCzKGSP4kJW2jp81 = {'type':iiy37aKq0pCEIOwfcTh61xb4U,'mode':iiy37aKq0pCEIOwfcTh61xb4U,'url':iiy37aKq0pCEIOwfcTh61xb4U,'text':iiy37aKq0pCEIOwfcTh61xb4U,'page':iiy37aKq0pCEIOwfcTh61xb4U,'name':iiy37aKq0pCEIOwfcTh61xb4U,'image':iiy37aKq0pCEIOwfcTh61xb4U,'context':iiy37aKq0pCEIOwfcTh61xb4U,'infodict':iiy37aKq0pCEIOwfcTh61xb4U}
	if J1MoiYc7ZwzKS: BDSpV74ITroL = BDSpV74ITroL.encode(df6QpwGxuJVZr,'ignore').decode(df6QpwGxuJVZr)
	rDowCzKGSP4kJW2jp81['name'] = YqdaDIig21wBTWJeUHbc(BDSpV74ITroL)
	rDowCzKGSP4kJW2jp81['type'] = synCYOiMR789twmfr.strip(iFBmE2MUIpSu34wsd7Rf6z)
	rDowCzKGSP4kJW2jp81['mode'] = str(Cpf9s3c0Zngj7XE).strip(iFBmE2MUIpSu34wsd7Rf6z)
	if synCYOiMR789twmfr=='folder' and tRFsgQzEj2O3wC: rDowCzKGSP4kJW2jp81['page'] = YqdaDIig21wBTWJeUHbc(tRFsgQzEj2O3wC.strip(iFBmE2MUIpSu34wsd7Rf6z))
	if YGNomIp2tDSR6ncf: rDowCzKGSP4kJW2jp81['context'] = YGNomIp2tDSR6ncf.strip(iFBmE2MUIpSu34wsd7Rf6z)
	if LiVN2UT7XAQRujrZp1: rDowCzKGSP4kJW2jp81['text'] = YqdaDIig21wBTWJeUHbc(LiVN2UT7XAQRujrZp1.strip(iFBmE2MUIpSu34wsd7Rf6z))
	if GmrA8hvBgN4bDdEWXS9nVMtU: rDowCzKGSP4kJW2jp81['image'] = YqdaDIig21wBTWJeUHbc(GmrA8hvBgN4bDdEWXS9nVMtU.strip(iFBmE2MUIpSu34wsd7Rf6z))
	if BSmlfc08nJ:
		BSmlfc08nJ = str(BSmlfc08nJ)
		rDowCzKGSP4kJW2jp81['infodict'] = YqdaDIig21wBTWJeUHbc(BSmlfc08nJ.strip(iFBmE2MUIpSu34wsd7Rf6z))
		BSmlfc08nJ = eval(BSmlfc08nJ)
	else: BSmlfc08nJ = {}
	if kMqh74TPvpSDar59xQUjAyVlHes: rDowCzKGSP4kJW2jp81['url'] = YqdaDIig21wBTWJeUHbc(kMqh74TPvpSDar59xQUjAyVlHes.strip(iFBmE2MUIpSu34wsd7Rf6z))
	pTGfY20EU8LO1eCjHMig5Z4NsKcJt = {'name':iiy37aKq0pCEIOwfcTh61xb4U,'context_menu':iiy37aKq0pCEIOwfcTh61xb4U,'plot':iiy37aKq0pCEIOwfcTh61xb4U,'stars':iiy37aKq0pCEIOwfcTh61xb4U,'image':iiy37aKq0pCEIOwfcTh61xb4U,'type':iiy37aKq0pCEIOwfcTh61xb4U,'isFolder':iiy37aKq0pCEIOwfcTh61xb4U,'newpath':iiy37aKq0pCEIOwfcTh61xb4U,'duration':iiy37aKq0pCEIOwfcTh61xb4U}
	bd98YKj0Foi4H3rUDsISJl2Mmfw = []
	nxtVhW5I7Kij8D6Zq = 'plugin://'+M8hQu61Uid+'/?type='+rDowCzKGSP4kJW2jp81['type']+'&mode='+rDowCzKGSP4kJW2jp81['mode']
	if rDowCzKGSP4kJW2jp81['page']: nxtVhW5I7Kij8D6Zq += '&page='+rDowCzKGSP4kJW2jp81['page']
	if rDowCzKGSP4kJW2jp81['name']: nxtVhW5I7Kij8D6Zq += '&name='+rDowCzKGSP4kJW2jp81['name']
	if rDowCzKGSP4kJW2jp81['text']: nxtVhW5I7Kij8D6Zq += '&text='+rDowCzKGSP4kJW2jp81['text']
	if rDowCzKGSP4kJW2jp81['infodict']: nxtVhW5I7Kij8D6Zq += '&infodict='+rDowCzKGSP4kJW2jp81['infodict']
	if rDowCzKGSP4kJW2jp81['image']: nxtVhW5I7Kij8D6Zq += '&image='+rDowCzKGSP4kJW2jp81['image']
	if rDowCzKGSP4kJW2jp81['url']: nxtVhW5I7Kij8D6Zq += '&url='+rDowCzKGSP4kJW2jp81['url']
	if Cpf9s3c0Zngj7XE!=265: pTGfY20EU8LO1eCjHMig5Z4NsKcJt['favorites'] = True
	else: pTGfY20EU8LO1eCjHMig5Z4NsKcJt['favorites'] = False
	if rDowCzKGSP4kJW2jp81['context']: nxtVhW5I7Kij8D6Zq += '&context='+rDowCzKGSP4kJW2jp81['context']
	if Cpf9s3c0Zngj7XE in [235,238] and synCYOiMR789twmfr=='live' and 'EPG' in YGNomIp2tDSR6ncf:
		bb2o7idJpxU = 'plugin://'+M8hQu61Uid+'?mode=238&text=SHORT_EPG&url='+kMqh74TPvpSDar59xQUjAyVlHes
		DKSLteOGkVN3pfl4sYWgJuvMmCA628 = aqEsMBckT2bunGHfl48Wip+'البرامج القادمة'+YoQW601K4fMJcsreDnGVE5wUZIy7
		bGT109i5tK3qVDRF = (DKSLteOGkVN3pfl4sYWgJuvMmCA628,'RunPlugin('+bb2o7idJpxU+')')
		bd98YKj0Foi4H3rUDsISJl2Mmfw.append(bGT109i5tK3qVDRF)
	if Cpf9s3c0Zngj7XE==265:
		Ih0XRyCBN6lKs = SSBM9WCAtqjmyE5gO(LiVN2UT7XAQRujrZp1,True)
		if Ih0XRyCBN6lKs>0:
			bb2o7idJpxU = 'plugin://'+M8hQu61Uid+'?mode=266&text='+LiVN2UT7XAQRujrZp1
			DKSLteOGkVN3pfl4sYWgJuvMmCA628 = aqEsMBckT2bunGHfl48Wip+'مسح قائمة آخر 50 '+aanoXVLTZqsIwitBdY0kcJS794FDg(LiVN2UT7XAQRujrZp1)+YoQW601K4fMJcsreDnGVE5wUZIy7
			bGT109i5tK3qVDRF = (DKSLteOGkVN3pfl4sYWgJuvMmCA628,'RunPlugin('+bb2o7idJpxU+')')
			bd98YKj0Foi4H3rUDsISJl2Mmfw.append(bGT109i5tK3qVDRF)
	if synCYOiMR789twmfr=='video' and Cpf9s3c0Zngj7XE!=331:
		bb2o7idJpxU = nxtVhW5I7Kij8D6Zq+'&context=6_DOWNLOAD'
		DKSLteOGkVN3pfl4sYWgJuvMmCA628 = aqEsMBckT2bunGHfl48Wip+'تحميل ملف الفيديو'+YoQW601K4fMJcsreDnGVE5wUZIy7
		bGT109i5tK3qVDRF = (DKSLteOGkVN3pfl4sYWgJuvMmCA628,'RunPlugin('+bb2o7idJpxU+')')
		bd98YKj0Foi4H3rUDsISJl2Mmfw.append(bGT109i5tK3qVDRF)
	if Cpf9s3c0Zngj7XE==331:
		bb2o7idJpxU = nxtVhW5I7Kij8D6Zq+'&context=6_DELETE'
		DKSLteOGkVN3pfl4sYWgJuvMmCA628 = aqEsMBckT2bunGHfl48Wip+'حذف ملف الفيديو'+YoQW601K4fMJcsreDnGVE5wUZIy7
		bGT109i5tK3qVDRF = (DKSLteOGkVN3pfl4sYWgJuvMmCA628,'RunPlugin('+bb2o7idJpxU+')')
		bd98YKj0Foi4H3rUDsISJl2Mmfw.append(bGT109i5tK3qVDRF)
	if synCYOiMR789twmfr=='folder' and Cpf9s3c0Zngj7XE==540:
		qPjUayf3bkoh = QKzCiBOWZus1nSv(PdkZHNBlpg2b7DmX6qRiyVa,'list','GLOBALSEARCH_SPLITTED_ALL')
		if qPjUayf3bkoh:
			bb2o7idJpxU = 'plugin://'+M8hQu61Uid+'?context=7'
			DKSLteOGkVN3pfl4sYWgJuvMmCA628 = aqEsMBckT2bunGHfl48Wip+'مسح كلمات بحث المواقع'+YoQW601K4fMJcsreDnGVE5wUZIy7
			bGT109i5tK3qVDRF = (DKSLteOGkVN3pfl4sYWgJuvMmCA628,'RunPlugin('+bb2o7idJpxU+')')
			bd98YKj0Foi4H3rUDsISJl2Mmfw.append(bGT109i5tK3qVDRF)
	if synCYOiMR789twmfr=='folder' and Cpf9s3c0Zngj7XE==1010:
		qPjUayf3bkoh = QKzCiBOWZus1nSv(PdkZHNBlpg2b7DmX6qRiyVa,'list','GLOBALSEARCH_SPLITTED_GOOGLE')
		if qPjUayf3bkoh:
			bb2o7idJpxU = 'plugin://'+M8hQu61Uid+'?context=10'
			DKSLteOGkVN3pfl4sYWgJuvMmCA628 = aqEsMBckT2bunGHfl48Wip+'مسح كلمات بحث جوجل'+YoQW601K4fMJcsreDnGVE5wUZIy7
			bGT109i5tK3qVDRF = (DKSLteOGkVN3pfl4sYWgJuvMmCA628,'RunPlugin('+bb2o7idJpxU+')')
			bd98YKj0Foi4H3rUDsISJl2Mmfw.append(bGT109i5tK3qVDRF)
	HYoeA9Vcqa0ShlN5EPd4s = [9990,9999,2,7,100,151,159,176,196,199,230,239,260,261,262,263,264,265,267,270,290,330,341,346,348,501,505,510,540,710,719,761,762,1010,1022]
	if Cpf9s3c0Zngj7XE not in HYoeA9Vcqa0ShlN5EPd4s:
		bb2o7idJpxU = 'plugin://'+M8hQu61Uid+'?context=8&mode=260'
		DKSLteOGkVN3pfl4sYWgJuvMmCA628 = aqEsMBckT2bunGHfl48Wip+'القائمة الرئيسية'+YoQW601K4fMJcsreDnGVE5wUZIy7
		bGT109i5tK3qVDRF = (DKSLteOGkVN3pfl4sYWgJuvMmCA628,'RunPlugin('+bb2o7idJpxU+')')
		bd98YKj0Foi4H3rUDsISJl2Mmfw.append(bGT109i5tK3qVDRF)
	celEihqNS4G3M2O5maXfI = [0,150,160,170,190,260,280,330,340,410,500,520,530,540,760,1010,9990]
	bbtLPDcHEafkI2RA9Z = Cpf9s3c0Zngj7XE-Cpf9s3c0Zngj7XE%10
	if Cpf9s3c0Zngj7XE%10:
		if bbtLPDcHEafkI2RA9Z==280: bbtLPDcHEafkI2RA9Z = 230
		if bbtLPDcHEafkI2RA9Z==410: bbtLPDcHEafkI2RA9Z = 400
		if bbtLPDcHEafkI2RA9Z==520: bbtLPDcHEafkI2RA9Z = 510
		if bbtLPDcHEafkI2RA9Z not in celEihqNS4G3M2O5maXfI:
			bb2o7idJpxU = 'plugin://'+M8hQu61Uid+'?context=8&mode='+str(bbtLPDcHEafkI2RA9Z)
			DKSLteOGkVN3pfl4sYWgJuvMmCA628 = aqEsMBckT2bunGHfl48Wip+'قائمة الموقع'+YoQW601K4fMJcsreDnGVE5wUZIy7
			bGT109i5tK3qVDRF = (DKSLteOGkVN3pfl4sYWgJuvMmCA628,'RunPlugin('+bb2o7idJpxU+')')
			bd98YKj0Foi4H3rUDsISJl2Mmfw.append(bGT109i5tK3qVDRF)
	bb2o7idJpxU = nxtVhW5I7Kij8D6Zq+'&context=9'
	DKSLteOGkVN3pfl4sYWgJuvMmCA628 = aqEsMBckT2bunGHfl48Wip+'تحديث القائمة'+YoQW601K4fMJcsreDnGVE5wUZIy7
	bGT109i5tK3qVDRF = (DKSLteOGkVN3pfl4sYWgJuvMmCA628,'RunPlugin('+bb2o7idJpxU+')')
	bd98YKj0Foi4H3rUDsISJl2Mmfw.append(bGT109i5tK3qVDRF)
	if synCYOiMR789twmfr in ['video','live']:
		bb2o7idJpxU = nxtVhW5I7Kij8D6Zq+'&context=18'
		DKSLteOGkVN3pfl4sYWgJuvMmCA628 = aqEsMBckT2bunGHfl48Wip+'إظهار قوائم الجودة'+YoQW601K4fMJcsreDnGVE5wUZIy7
		bGT109i5tK3qVDRF = (DKSLteOGkVN3pfl4sYWgJuvMmCA628,'RunPlugin('+bb2o7idJpxU+')')
		bd98YKj0Foi4H3rUDsISJl2Mmfw.append(bGT109i5tK3qVDRF)
	if synCYOiMR789twmfr in ['link','video','live']: PEaKrSG5W1RH7dUBw2nsFA = False
	elif synCYOiMR789twmfr=='folder': PEaKrSG5W1RH7dUBw2nsFA = True
	pTGfY20EU8LO1eCjHMig5Z4NsKcJt['name'] = JJwnocyLUxHI2jlKF4Y
	pTGfY20EU8LO1eCjHMig5Z4NsKcJt['context_menu'] = bd98YKj0Foi4H3rUDsISJl2Mmfw
	if 'plot' in list(BSmlfc08nJ.keys()): pTGfY20EU8LO1eCjHMig5Z4NsKcJt['plot'] = BSmlfc08nJ['plot']
	if 'stars' in list(BSmlfc08nJ.keys()): pTGfY20EU8LO1eCjHMig5Z4NsKcJt['stars'] = BSmlfc08nJ['stars']
	if GmrA8hvBgN4bDdEWXS9nVMtU: pTGfY20EU8LO1eCjHMig5Z4NsKcJt['image'] = GmrA8hvBgN4bDdEWXS9nVMtU
	if synCYOiMR789twmfr=='video' and tRFsgQzEj2O3wC:
		wkYquGBgtfiTI5Ph1UEZc4oJ08Q = dEyT9xhGjolYzLCH7460w3.findall('[\d:]+',tRFsgQzEj2O3wC,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if wkYquGBgtfiTI5Ph1UEZc4oJ08Q:
			wkYquGBgtfiTI5Ph1UEZc4oJ08Q = '0:0:0:0:0:'+wkYquGBgtfiTI5Ph1UEZc4oJ08Q[0]
			HrzYa61RN5hAVS9BtnJ3mDy,obAzi9w7lDyJ,nx0YrNhA1H4vigdJVGeabt,q32qiCSnokmL5f,CvBpgJ0xtQRNo8zLeIhWsij7 = wkYquGBgtfiTI5Ph1UEZc4oJ08Q.rsplit(':',4)
			SATEK5Hc3vyfw9gr = int(obAzi9w7lDyJ)*24*o5oKZNPi9CeVSI3DzBUEa8tGcAkvH+int(nx0YrNhA1H4vigdJVGeabt)*o5oKZNPi9CeVSI3DzBUEa8tGcAkvH+int(q32qiCSnokmL5f)*60+int(CvBpgJ0xtQRNo8zLeIhWsij7)
			pTGfY20EU8LO1eCjHMig5Z4NsKcJt['duration'] = SATEK5Hc3vyfw9gr
	pTGfY20EU8LO1eCjHMig5Z4NsKcJt['type'] = synCYOiMR789twmfr
	pTGfY20EU8LO1eCjHMig5Z4NsKcJt['isFolder'] = PEaKrSG5W1RH7dUBw2nsFA
	pTGfY20EU8LO1eCjHMig5Z4NsKcJt['newpath'] = nxtVhW5I7Kij8D6Zq
	pTGfY20EU8LO1eCjHMig5Z4NsKcJt['menuItem'] = Qi2fSRlvnOdsN3DhybuEL8z754
	pTGfY20EU8LO1eCjHMig5Z4NsKcJt['mode'] = Cpf9s3c0Zngj7XE
	return pTGfY20EU8LO1eCjHMig5Z4NsKcJt
def qa6vEkbJj4AhKTPlBY8(SSBM9WCAtqjmyE5gO):
	q4qrAvDcxHOdGTwoXgun,IrXjyqcp13l = [],iiy37aKq0pCEIOwfcTh61xb4U
	from LTAR3BSjNg import IkV3q9Q2jBYuhKTtzW01dFoCxL,ZurfTHXFnmM3t7CSogYJxjBhA
	cSAXLFYpH0M9gdlqIRx = IkV3q9Q2jBYuhKTtzW01dFoCxL()
	zCXZNsp6PT8Mhxnr5v0G71KaBdFR = OXsckY7RzjCag9A.getSetting('av.status.refresh')
	if CzWIqm1YAcEa9gTSZ30fk27 and (not zCXZNsp6PT8Mhxnr5v0G71KaBdFR or zCXZNsp6PT8Mhxnr5v0G71KaBdFR=='REFRESH_CACHE'): zCXZNsp6PT8Mhxnr5v0G71KaBdFR = QKzCiBOWZus1nSv(PdkZHNBlpg2b7DmX6qRiyVa,'str','FOLDERS_SORT',CzWIqm1YAcEa9gTSZ30fk27)
	if zCXZNsp6PT8Mhxnr5v0G71KaBdFR:
		if   '_PERM' in zCXZNsp6PT8Mhxnr5v0G71KaBdFR: IrXjyqcp13l = 'دائمي'
		elif '_TEMP' in zCXZNsp6PT8Mhxnr5v0G71KaBdFR: IrXjyqcp13l = 'مؤقت'
		if   '_REVERSED_' in zCXZNsp6PT8Mhxnr5v0G71KaBdFR: ccgt6lhpXynUR79P5ev = 'عكسي' ; g6ghGH4aBEYkTl3vbJZ[:] = reversed(g6ghGH4aBEYkTl3vbJZ)
		elif '_ASCENDED_' in zCXZNsp6PT8Mhxnr5v0G71KaBdFR: ccgt6lhpXynUR79P5ev = 'تصاعدي' ; g6ghGH4aBEYkTl3vbJZ[:] = sorted(g6ghGH4aBEYkTl3vbJZ,reverse=BF6QAiLUNHh7rKOugaw,key=lambda key:key[YYJQyRskpX8jv])
		elif '_DESCENDED_' in zCXZNsp6PT8Mhxnr5v0G71KaBdFR: ccgt6lhpXynUR79P5ev = 'تنازلي' ; g6ghGH4aBEYkTl3vbJZ[:] = sorted(g6ghGH4aBEYkTl3vbJZ,reverse=rGPen6cSMHQkAywh8vqI9JXiD2,key=lambda key:key[YYJQyRskpX8jv])
		elif '_RANDOMIZED_' in zCXZNsp6PT8Mhxnr5v0G71KaBdFR: ccgt6lhpXynUR79P5ev = 'عشوائي' ; ufTX72hK8Q63jSsJiqDm5.shuffle(g6ghGH4aBEYkTl3vbJZ)
	name = 'ترتيب '+ccgt6lhpXynUR79P5ev+iFBmE2MUIpSu34wsd7Rf6z+IrXjyqcp13l if IrXjyqcp13l else 'بدون ترتيب (أصلي)'
	name = aqEsMBckT2bunGHfl48Wip+name+YoQW601K4fMJcsreDnGVE5wUZIy7
	if zCXZNsp6PT8Mhxnr5v0G71KaBdFR in N9mPkX14E8VyHDSF: OXsckY7RzjCag9A.setSetting('av.status.refresh',iiy37aKq0pCEIOwfcTh61xb4U)
	EGJVsZy38Xx,Toe5N9znWjQHmP4whguld,smglbwR7x2oM,y3qATZDQOch6db5WjnmrguflU,L95mrowGgdsD,zLEP9N4BOsVrXa,XiWJ2PTqvds4pBNebVrt98x,EALyNnv1Db4cUd8sQoZX2pmBVt7kM,XC10geOnQtwrs = Q4APpMirastonc6Wh1v2XOH3K(CzWIqm1YAcEa9gTSZ30fk27)
	celEihqNS4G3M2O5maXfI = [0,150,160,170,190,260,280,330,340,410,500,520,530,540,760,1010,9990,1020]
	Cpf9s3c0Zngj7XE = int(y3qATZDQOch6db5WjnmrguflU)
	bbtLPDcHEafkI2RA9Z = Cpf9s3c0Zngj7XE-Cpf9s3c0Zngj7XE%10
	if Cpf9s3c0Zngj7XE%10 and bbtLPDcHEafkI2RA9Z not in celEihqNS4G3M2O5maXfI and len(g6ghGH4aBEYkTl3vbJZ)>1:
		g6ghGH4aBEYkTl3vbJZ[:] = [('link',name,'',533,'','',CzWIqm1YAcEa9gTSZ30fk27,'','')]+g6ghGH4aBEYkTl3vbJZ
	for Qi2fSRlvnOdsN3DhybuEL8z754 in g6ghGH4aBEYkTl3vbJZ:
		pTGfY20EU8LO1eCjHMig5Z4NsKcJt = mOlYsSNcyniA9(Qi2fSRlvnOdsN3DhybuEL8z754,SSBM9WCAtqjmyE5gO,cSAXLFYpH0M9gdlqIRx)
		if pTGfY20EU8LO1eCjHMig5Z4NsKcJt['favorites']:
			CdMuI72bLWVAvj8STKklNQEtZzUx5J = ZurfTHXFnmM3t7CSogYJxjBhA(cSAXLFYpH0M9gdlqIRx,pTGfY20EU8LO1eCjHMig5Z4NsKcJt['menuItem'],pTGfY20EU8LO1eCjHMig5Z4NsKcJt['newpath'])
			pTGfY20EU8LO1eCjHMig5Z4NsKcJt['context_menu'] = CdMuI72bLWVAvj8STKklNQEtZzUx5J+pTGfY20EU8LO1eCjHMig5Z4NsKcJt['context_menu']
		q4qrAvDcxHOdGTwoXgun.append(pTGfY20EU8LO1eCjHMig5Z4NsKcJt)
	return q4qrAvDcxHOdGTwoXgun
def zzDm5JQxsCj(UCOyxvPEBiwmbkLdzfDjIM4rp):
	HxOrYzlCXasuSdjBb,pM1NTPcsFv, = [],iiy37aKq0pCEIOwfcTh61xb4U
	for ALqPlOD34cfHQWk7ae0URbZotXNTFs in UCOyxvPEBiwmbkLdzfDjIM4rp:
		if not ALqPlOD34cfHQWk7ae0URbZotXNTFs: HxOrYzlCXasuSdjBb.append(iiy37aKq0pCEIOwfcTh61xb4U)
		else: break
	UCOyxvPEBiwmbkLdzfDjIM4rp = UCOyxvPEBiwmbkLdzfDjIM4rp[len(HxOrYzlCXasuSdjBb):]
	U94JwhRgpXCOe5 = '\n\n\n\n'.join(UCOyxvPEBiwmbkLdzfDjIM4rp)
	U94JwhRgpXCOe5 = U94JwhRgpXCOe5.replace('===== ===== =====','000001')
	U94JwhRgpXCOe5 = U94JwhRgpXCOe5.replace(PSwfZcdRYhpl5Igqz8xOEk67,'000002')
	U94JwhRgpXCOe5 = U94JwhRgpXCOe5.replace(aqEsMBckT2bunGHfl48Wip,'000003')
	U94JwhRgpXCOe5 = U94JwhRgpXCOe5.replace(YoQW601K4fMJcsreDnGVE5wUZIy7,'000004')
	U94JwhRgpXCOe5 = U94JwhRgpXCOe5.replace('[RIGHT]','000005')
	aqCScXK4Gg1Dkt5vHL38RJEBUZe = 100000
	faLlmDzBsPFIiYpnT972M0hKryOw = {}
	xgcfzXLawbFqpr8SiVlh5GmMRKjPQ = dEyT9xhGjolYzLCH7460w3.findall('http.*?[\r\n ]',U94JwhRgpXCOe5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	for mm91yEkqcbxN6pVrgRj in xgcfzXLawbFqpr8SiVlh5GmMRKjPQ:
		aqCScXK4Gg1Dkt5vHL38RJEBUZe += 1
		U94JwhRgpXCOe5 = U94JwhRgpXCOe5.replace(mm91yEkqcbxN6pVrgRj,str(aqCScXK4Gg1Dkt5vHL38RJEBUZe))
		faLlmDzBsPFIiYpnT972M0hKryOw[str(aqCScXK4Gg1Dkt5vHL38RJEBUZe)] = mm91yEkqcbxN6pVrgRj
	for mi7Q1WRhZUJF3GOczo in range(0,len(U94JwhRgpXCOe5),4800):
		MRQrL9JcFonOXS8BPKuhEAYebl04 = U94JwhRgpXCOe5[mi7Q1WRhZUJF3GOczo:mi7Q1WRhZUJF3GOczo+4800]
		pARIeP8YUMbf6nz5t7o0Wx = OXsckY7RzjCag9A.getSetting('av.language.code')
		kMqh74TPvpSDar59xQUjAyVlHes = 'https://translator-api.glosbe.com/translateByLangDetect?sourceLang=ar&targetLang='+pARIeP8YUMbf6nz5t7o0Wx
		qNojFLzuAkDZHEy1d4scer = {'Content-Type':'text/plain'}
		ZFnUCft13ez82KJkbQgvhIl = MRQrL9JcFonOXS8BPKuhEAYebl04.encode(df6QpwGxuJVZr)
		oikBndh2USEOV = MMCJxEfv0WUek(hI7SkXd94fFzAHNZCQoMqEutbnWP,'POST',kMqh74TPvpSDar59xQUjAyVlHes,ZFnUCft13ez82KJkbQgvhIl,qNojFLzuAkDZHEy1d4scer,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'LIBRARY-GLOSBE_TRANSLATE-1st')
		if oikBndh2USEOV.succeeded:
			JiUpSTZWMhHP = oikBndh2USEOV.content
			CgmRBw4koN = DeIL3qoa2UBtYPb('str',JiUpSTZWMhHP)
			if CgmRBw4koN:
				CgmRBw4koN = CgmRBw4koN['translation']
				CgmRBw4koN = vvmT3DLXkhPBwIaOAo6srZpEnRVJC(CgmRBw4koN)
				for jpouXixl9Oqzvg2V3k8ZayRJNsnI in range(len(CgmRBw4koN)):
					pM1NTPcsFv += CgmRBw4koN[jpouXixl9Oqzvg2V3k8ZayRJNsnI][0]
	pM1NTPcsFv = pM1NTPcsFv.replace('000001','===== ===== =====')
	pM1NTPcsFv = pM1NTPcsFv.replace('000002',PSwfZcdRYhpl5Igqz8xOEk67)
	pM1NTPcsFv = pM1NTPcsFv.replace('000003',aqEsMBckT2bunGHfl48Wip)
	pM1NTPcsFv = pM1NTPcsFv.replace('000004',YoQW601K4fMJcsreDnGVE5wUZIy7)
	pM1NTPcsFv = pM1NTPcsFv.replace('000005','[RIGHT]')
	for aqCScXK4Gg1Dkt5vHL38RJEBUZe in list(faLlmDzBsPFIiYpnT972M0hKryOw.keys()):
		mm91yEkqcbxN6pVrgRj = faLlmDzBsPFIiYpnT972M0hKryOw[aqCScXK4Gg1Dkt5vHL38RJEBUZe]
		pM1NTPcsFv = pM1NTPcsFv.replace(aqCScXK4Gg1Dkt5vHL38RJEBUZe,mm91yEkqcbxN6pVrgRj)
	pM1NTPcsFv = pM1NTPcsFv.split('\n\n\n\n')
	return HxOrYzlCXasuSdjBb+pM1NTPcsFv
def iXN8HVlJZbEIUjRB(UCOyxvPEBiwmbkLdzfDjIM4rp):
	HxOrYzlCXasuSdjBb,pM1NTPcsFv, = [],iiy37aKq0pCEIOwfcTh61xb4U
	for ALqPlOD34cfHQWk7ae0URbZotXNTFs in UCOyxvPEBiwmbkLdzfDjIM4rp:
		if not ALqPlOD34cfHQWk7ae0URbZotXNTFs: HxOrYzlCXasuSdjBb.append(iiy37aKq0pCEIOwfcTh61xb4U)
		else: break
	UCOyxvPEBiwmbkLdzfDjIM4rp = UCOyxvPEBiwmbkLdzfDjIM4rp[len(HxOrYzlCXasuSdjBb):]
	U94JwhRgpXCOe5 = '\\n\\n\\n\\n'.join(UCOyxvPEBiwmbkLdzfDjIM4rp)
	U94JwhRgpXCOe5 = U94JwhRgpXCOe5.replace('كلا','no')
	U94JwhRgpXCOe5 = U94JwhRgpXCOe5.replace('استمرار','continue')
	U94JwhRgpXCOe5 = U94JwhRgpXCOe5.replace('===== ===== =====','000001')
	U94JwhRgpXCOe5 = U94JwhRgpXCOe5.replace(PSwfZcdRYhpl5Igqz8xOEk67,'000002')
	U94JwhRgpXCOe5 = U94JwhRgpXCOe5.replace(aqEsMBckT2bunGHfl48Wip,'000003')
	U94JwhRgpXCOe5 = U94JwhRgpXCOe5.replace(YoQW601K4fMJcsreDnGVE5wUZIy7,'000004')
	U94JwhRgpXCOe5 = U94JwhRgpXCOe5.replace('[RIGHT]','000005')
	U94JwhRgpXCOe5 = U94JwhRgpXCOe5.replace('[CENTER]','000006')
	U94JwhRgpXCOe5 = U94JwhRgpXCOe5.replace('[RTL]','000007')
	U94JwhRgpXCOe5 = U94JwhRgpXCOe5.replace("'","\\\\\\'")
	U94JwhRgpXCOe5 = U94JwhRgpXCOe5.replace('"','\\\\\\"')
	U94JwhRgpXCOe5 = U94JwhRgpXCOe5.replace(OTlVEGYPSxsNaBdXUucqA3,'\\n')
	U94JwhRgpXCOe5 = U94JwhRgpXCOe5.replace(Mge0HhFk9Ic6sm5VR,'\\\\r')
	for mi7Q1WRhZUJF3GOczo in range(0,len(U94JwhRgpXCOe5),4800):
		MRQrL9JcFonOXS8BPKuhEAYebl04 = U94JwhRgpXCOe5[mi7Q1WRhZUJF3GOczo:mi7Q1WRhZUJF3GOczo+4800]
		kMqh74TPvpSDar59xQUjAyVlHes = 'https://translate.google.com/_/TranslateWebserverUi/data/batchexecute'
		qNojFLzuAkDZHEy1d4scer = {'Content-Type':'application/x-www-form-urlencoded'}
		pARIeP8YUMbf6nz5t7o0Wx = OXsckY7RzjCag9A.getSetting('av.language.code')
		ZFnUCft13ez82KJkbQgvhIl = 'f.req='+YqdaDIig21wBTWJeUHbc('[[["MkEWBc","[[\\"'+MRQrL9JcFonOXS8BPKuhEAYebl04+'\\",\\"ar\\",\\"'+pARIeP8YUMbf6nz5t7o0Wx+'\\",1],[]]",null,"generic"]]]',iiy37aKq0pCEIOwfcTh61xb4U)
		ZFnUCft13ez82KJkbQgvhIl = ZFnUCft13ez82KJkbQgvhIl.replace('%5Cn','%5C%5Cn')
		oikBndh2USEOV = MMCJxEfv0WUek(hI7SkXd94fFzAHNZCQoMqEutbnWP,'POST',kMqh74TPvpSDar59xQUjAyVlHes,ZFnUCft13ez82KJkbQgvhIl,qNojFLzuAkDZHEy1d4scer,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'LIBRARY-GOOGLE_TRANSLATE-1st')
		if oikBndh2USEOV.succeeded:
			JiUpSTZWMhHP = oikBndh2USEOV.content
			JiUpSTZWMhHP = JiUpSTZWMhHP.split(OTlVEGYPSxsNaBdXUucqA3)[-1]
			CgmRBw4koN = DeIL3qoa2UBtYPb('str',JiUpSTZWMhHP)[0][2]
			if CgmRBw4koN:
				CgmRBw4koN = DeIL3qoa2UBtYPb('str',CgmRBw4koN)[1][0][0][5]
				CgmRBw4koN = vvmT3DLXkhPBwIaOAo6srZpEnRVJC(CgmRBw4koN)
				for jpouXixl9Oqzvg2V3k8ZayRJNsnI in range(len(CgmRBw4koN)):
					pM1NTPcsFv += CgmRBw4koN[jpouXixl9Oqzvg2V3k8ZayRJNsnI][0]
	pM1NTPcsFv = pM1NTPcsFv.replace('00000','0000').replace('0000','000')
	pM1NTPcsFv = pM1NTPcsFv.replace('0001','===== ===== =====')
	pM1NTPcsFv = pM1NTPcsFv.replace('0002',PSwfZcdRYhpl5Igqz8xOEk67)
	pM1NTPcsFv = pM1NTPcsFv.replace('0003',aqEsMBckT2bunGHfl48Wip)
	pM1NTPcsFv = pM1NTPcsFv.replace('0004',YoQW601K4fMJcsreDnGVE5wUZIy7)
	pM1NTPcsFv = pM1NTPcsFv.replace('0005','[RIGHT]')
	pM1NTPcsFv = pM1NTPcsFv.replace('0006','[CENTER]')
	pM1NTPcsFv = pM1NTPcsFv.replace('0007','[RTL]')
	pM1NTPcsFv = pM1NTPcsFv.split('\n\n\n\n')
	return HxOrYzlCXasuSdjBb+pM1NTPcsFv
def eM0LCXWpRY8bU9HIQuaJqzf1o46w(UCOyxvPEBiwmbkLdzfDjIM4rp):
	HxOrYzlCXasuSdjBb,CK0iXf3FayusGp6Awn7ZtVQJeNE5o = [],[]
	for ALqPlOD34cfHQWk7ae0URbZotXNTFs in UCOyxvPEBiwmbkLdzfDjIM4rp:
		if not ALqPlOD34cfHQWk7ae0URbZotXNTFs: HxOrYzlCXasuSdjBb.append(iiy37aKq0pCEIOwfcTh61xb4U)
		else: break
	UCOyxvPEBiwmbkLdzfDjIM4rp = UCOyxvPEBiwmbkLdzfDjIM4rp[len(HxOrYzlCXasuSdjBb):]
	U94JwhRgpXCOe5 = '\n\n\n\n'.join(UCOyxvPEBiwmbkLdzfDjIM4rp)
	U94JwhRgpXCOe5 = U94JwhRgpXCOe5.replace('كلا','no')
	U94JwhRgpXCOe5 = U94JwhRgpXCOe5.replace('استمرار','continue')
	U94JwhRgpXCOe5 = U94JwhRgpXCOe5.replace('أدناه','below')
	U94JwhRgpXCOe5 = U94JwhRgpXCOe5.replace(PSwfZcdRYhpl5Igqz8xOEk67,'00001')
	U94JwhRgpXCOe5 = U94JwhRgpXCOe5.replace(aqEsMBckT2bunGHfl48Wip,'00002')
	U94JwhRgpXCOe5 = U94JwhRgpXCOe5.replace(YoQW601K4fMJcsreDnGVE5wUZIy7,'00003')
	U94JwhRgpXCOe5 = U94JwhRgpXCOe5.replace('=====','00004')
	U94JwhRgpXCOe5 = U94JwhRgpXCOe5.replace(',','00005')
	U94JwhRgpXCOe5 = U94JwhRgpXCOe5.replace('[RTL]','00009')
	U94JwhRgpXCOe5 = U94JwhRgpXCOe5.replace('[CENTER]','0000A')
	U94JwhRgpXCOe5 = U94JwhRgpXCOe5.replace(Mge0HhFk9Ic6sm5VR,'0000B')
	UCOyxvPEBiwmbkLdzfDjIM4rp = U94JwhRgpXCOe5.split(OTlVEGYPSxsNaBdXUucqA3)
	U94JwhRgpXCOe5,pM1NTPcsFv = iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U
	for ALqPlOD34cfHQWk7ae0URbZotXNTFs in UCOyxvPEBiwmbkLdzfDjIM4rp:
		if len(U94JwhRgpXCOe5+ALqPlOD34cfHQWk7ae0URbZotXNTFs)<1800: U94JwhRgpXCOe5 += OTlVEGYPSxsNaBdXUucqA3+ALqPlOD34cfHQWk7ae0URbZotXNTFs
		else:
			CK0iXf3FayusGp6Awn7ZtVQJeNE5o.append(U94JwhRgpXCOe5)
			U94JwhRgpXCOe5 = ALqPlOD34cfHQWk7ae0URbZotXNTFs
	CK0iXf3FayusGp6Awn7ZtVQJeNE5o.append(U94JwhRgpXCOe5)
	for ALqPlOD34cfHQWk7ae0URbZotXNTFs in CK0iXf3FayusGp6Awn7ZtVQJeNE5o:
		qNojFLzuAkDZHEy1d4scer = {'Content-Type':'application/json','User-Agent':iiy37aKq0pCEIOwfcTh61xb4U}
		kMqh74TPvpSDar59xQUjAyVlHes = 'https://api.reverso.net/translate/v1/translation'
		pARIeP8YUMbf6nz5t7o0Wx = OXsckY7RzjCag9A.getSetting('av.language.code')
		ZFnUCft13ez82KJkbQgvhIl = {"format":"text","from":"ara","to":pARIeP8YUMbf6nz5t7o0Wx,"input":ALqPlOD34cfHQWk7ae0URbZotXNTFs,"options":{"sentenceSplitter":True,"origin":"translation.web","contextResults":False,"languageDetection":False}}
		ZFnUCft13ez82KJkbQgvhIl = bHyN37Y82ZKVLOexBF.dumps(ZFnUCft13ez82KJkbQgvhIl)
		oikBndh2USEOV = MMCJxEfv0WUek(hI7SkXd94fFzAHNZCQoMqEutbnWP,'POST',kMqh74TPvpSDar59xQUjAyVlHes,ZFnUCft13ez82KJkbQgvhIl,qNojFLzuAkDZHEy1d4scer,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'LIBRARY-REVERSO_TRANSLATE-1st')
		if oikBndh2USEOV.succeeded:
			JiUpSTZWMhHP = oikBndh2USEOV.content
			JiUpSTZWMhHP = DeIL3qoa2UBtYPb('dict',JiUpSTZWMhHP)
			pM1NTPcsFv += OTlVEGYPSxsNaBdXUucqA3+iiy37aKq0pCEIOwfcTh61xb4U.join(JiUpSTZWMhHP['translation'])
	pM1NTPcsFv = pM1NTPcsFv[2:]
	pM1NTPcsFv = pM1NTPcsFv.replace('000000','00000').replace('00000','0000').replace('0000','000')
	pM1NTPcsFv = pM1NTPcsFv.replace('0001',PSwfZcdRYhpl5Igqz8xOEk67)
	pM1NTPcsFv = pM1NTPcsFv.replace('0002',aqEsMBckT2bunGHfl48Wip)
	pM1NTPcsFv = pM1NTPcsFv.replace('0003',YoQW601K4fMJcsreDnGVE5wUZIy7)
	pM1NTPcsFv = pM1NTPcsFv.replace('0004','=====')
	pM1NTPcsFv = pM1NTPcsFv.replace('0005',',')
	pM1NTPcsFv = pM1NTPcsFv.replace('0009','[RTL]')
	pM1NTPcsFv = pM1NTPcsFv.replace('000A','[CENTER]')
	pM1NTPcsFv = pM1NTPcsFv.replace('000B',Mge0HhFk9Ic6sm5VR)
	pM1NTPcsFv = pM1NTPcsFv.split('\n\n\n\n')
	return HxOrYzlCXasuSdjBb+pM1NTPcsFv
def KYcVJr7yP5kfhAFCbgQMzu(UCOyxvPEBiwmbkLdzfDjIM4rp):
	EHGw27fNoyb = OXsckY7RzjCag9A.getSetting('av.language.translate')
	if not EHGw27fNoyb or not UCOyxvPEBiwmbkLdzfDjIM4rp: return UCOyxvPEBiwmbkLdzfDjIM4rp
	XzhOTQymRcVY = OXsckY7RzjCag9A.getSetting('av.language.provider')
	pARIeP8YUMbf6nz5t7o0Wx = OXsckY7RzjCag9A.getSetting('av.language.code')
	YNcKEF7gSmLvQn = pARIeP8YUMbf6nz5t7o0Wx+'__'+str(UCOyxvPEBiwmbkLdzfDjIM4rp)
	OXsckY7RzjCag9A.setSetting('av.language.translate',iiy37aKq0pCEIOwfcTh61xb4U)
	pM1NTPcsFv = QKzCiBOWZus1nSv(PdkZHNBlpg2b7DmX6qRiyVa,'list','TRANSLATE_'+XzhOTQymRcVY,YNcKEF7gSmLvQn)
	if not pM1NTPcsFv:
		if XzhOTQymRcVY=='GOOGLE': pM1NTPcsFv = iXN8HVlJZbEIUjRB(UCOyxvPEBiwmbkLdzfDjIM4rp)
		elif XzhOTQymRcVY=='REVERSO': pM1NTPcsFv = eM0LCXWpRY8bU9HIQuaJqzf1o46w(UCOyxvPEBiwmbkLdzfDjIM4rp)
		elif XzhOTQymRcVY=='GLOSBE': pM1NTPcsFv = zzDm5JQxsCj(UCOyxvPEBiwmbkLdzfDjIM4rp)
		if len(UCOyxvPEBiwmbkLdzfDjIM4rp)==len(pM1NTPcsFv):
			YMQXP2BGeK86CEb(PdkZHNBlpg2b7DmX6qRiyVa,'TRANSLATE_'+XzhOTQymRcVY,YNcKEF7gSmLvQn,pM1NTPcsFv,ea84RQXsdLY9GIVjSzb)
		else:
			pM1NTPcsFv = UCOyxvPEBiwmbkLdzfDjIM4rp
			YYkhEn5xTXLUevzCVNB16mR('الترجمة فشلت','Translation Failed')
	OXsckY7RzjCag9A.setSetting('av.language.translate','1')
	return pM1NTPcsFv
def wZM73KAr9H4aV(Qi2fSRlvnOdsN3DhybuEL8z754,q4qrAvDcxHOdGTwoXgun,VsfSE7hTyxPUko,MM1pfeZINLmyPWdYwojzQK2b,UUzagAt7TOIkQXZdyC1SoLV50bfp):
	synCYOiMR789twmfr,JJwnocyLUxHI2jlKF4Y,kMqh74TPvpSDar59xQUjAyVlHes,Cpf9s3c0Zngj7XE,GmrA8hvBgN4bDdEWXS9nVMtU,F50ngOyjSvAcVRtdafJsiBkP9Yx,U94JwhRgpXCOe5,YGNomIp2tDSR6ncf,BSmlfc08nJ = Qi2fSRlvnOdsN3DhybuEL8z754
	KKP0Vr9ywNdYGFICh3Bg = []
	EHGw27fNoyb = OXsckY7RzjCag9A.getSetting('av.language.translate')
	if EHGw27fNoyb:
		rnglYvxfHWEpF,mEg1oZktWajb,eOAonmRWi25rwbB = [],[],[]
		if not KKP0Vr9ywNdYGFICh3Bg:
			for pTGfY20EU8LO1eCjHMig5Z4NsKcJt in q4qrAvDcxHOdGTwoXgun:
				JJwnocyLUxHI2jlKF4Y = pTGfY20EU8LO1eCjHMig5Z4NsKcJt['name'].replace(DApVioTIRMGX,iiy37aKq0pCEIOwfcTh61xb4U).replace(Ds9inqGKb5frAd2CzmWke61aMQ,iiy37aKq0pCEIOwfcTh61xb4U)
				xXQEHnNz4DGCrbpd63mLaFOsZ0 = dEyT9xhGjolYzLCH7460w3.findall('^(\[COLOR FFFFFF00\])(\d\d.\d\d) (\d\d.\d\d)(\[/COLOR\]) (.*?)$',JJwnocyLUxHI2jlKF4Y,dEyT9xhGjolYzLCH7460w3.DOTALL)
				if xXQEHnNz4DGCrbpd63mLaFOsZ0:
					HxOrYzlCXasuSdjBb,My3LZsCBv6PVURi8SWhpcINfKzax,LEBVYcW7kh1Sn3CzTql,ww9ibQEkrTvXoStlBRjGVLaeupqdc,JJwnocyLUxHI2jlKF4Y = xXQEHnNz4DGCrbpd63mLaFOsZ0[0]
					xXQEHnNz4DGCrbpd63mLaFOsZ0 = HxOrYzlCXasuSdjBb+My3LZsCBv6PVURi8SWhpcINfKzax+iFBmE2MUIpSu34wsd7Rf6z+LEBVYcW7kh1Sn3CzTql+ww9ibQEkrTvXoStlBRjGVLaeupqdc+iFBmE2MUIpSu34wsd7Rf6z
				else:
					xXQEHnNz4DGCrbpd63mLaFOsZ0 = dEyT9xhGjolYzLCH7460w3.findall('^(.*?) (\[COLOR FFFFFF00\])(\d\d.\d\d) (\d\d.\d\d)(\[/COLOR\])$',JJwnocyLUxHI2jlKF4Y,dEyT9xhGjolYzLCH7460w3.DOTALL)
					if xXQEHnNz4DGCrbpd63mLaFOsZ0:
						JJwnocyLUxHI2jlKF4Y,HxOrYzlCXasuSdjBb,LEBVYcW7kh1Sn3CzTql,My3LZsCBv6PVURi8SWhpcINfKzax,ww9ibQEkrTvXoStlBRjGVLaeupqdc = xXQEHnNz4DGCrbpd63mLaFOsZ0[0]
						xXQEHnNz4DGCrbpd63mLaFOsZ0 = HxOrYzlCXasuSdjBb+My3LZsCBv6PVURi8SWhpcINfKzax+iFBmE2MUIpSu34wsd7Rf6z+LEBVYcW7kh1Sn3CzTql+ww9ibQEkrTvXoStlBRjGVLaeupqdc+iFBmE2MUIpSu34wsd7Rf6z
					else: xXQEHnNz4DGCrbpd63mLaFOsZ0 = iiy37aKq0pCEIOwfcTh61xb4U
				vZJ9OKH6ydYXurzbC5csFMkpw8 = dEyT9xhGjolYzLCH7460w3.findall('^(.\[COLOR FFF08C1F\]\w\w\w \[/COLOR\])(.*?)$',JJwnocyLUxHI2jlKF4Y,dEyT9xhGjolYzLCH7460w3.DOTALL)
				if vZJ9OKH6ydYXurzbC5csFMkpw8: vZJ9OKH6ydYXurzbC5csFMkpw8,JJwnocyLUxHI2jlKF4Y = vZJ9OKH6ydYXurzbC5csFMkpw8[0]
				else: vZJ9OKH6ydYXurzbC5csFMkpw8 = iiy37aKq0pCEIOwfcTh61xb4U
				rnglYvxfHWEpF.append(xXQEHnNz4DGCrbpd63mLaFOsZ0+vZJ9OKH6ydYXurzbC5csFMkpw8)
				mEg1oZktWajb.append(JJwnocyLUxHI2jlKF4Y)
			eOAonmRWi25rwbB = KYcVJr7yP5kfhAFCbgQMzu(mEg1oZktWajb)
			if eOAonmRWi25rwbB:
				for mi7Q1WRhZUJF3GOczo in range(len(q4qrAvDcxHOdGTwoXgun)):
					pTGfY20EU8LO1eCjHMig5Z4NsKcJt = q4qrAvDcxHOdGTwoXgun[mi7Q1WRhZUJF3GOczo]
					pTGfY20EU8LO1eCjHMig5Z4NsKcJt['name'] = rnglYvxfHWEpF[mi7Q1WRhZUJF3GOczo]+eOAonmRWi25rwbB[mi7Q1WRhZUJF3GOczo]
					KKP0Vr9ywNdYGFICh3Bg.append(pTGfY20EU8LO1eCjHMig5Z4NsKcJt)
	if KKP0Vr9ywNdYGFICh3Bg: q4qrAvDcxHOdGTwoXgun = KKP0Vr9ywNdYGFICh3Bg
	r6rDCRJALzTGQm52pbyhwlUqx80H,PGsq4lFpJOLDT,KoY5jz0I1Pku3weCV6H8mgxq7 = [],0,0
	koUhAnjOz2x1CF = OXsckY7RzjCag9A.getSetting('av.status.menusimages')
	UEbgrSzkGiAatPnM = koUhAnjOz2x1CF!='STOP'
	tHzN1B5q6lgi7sXI2Vum = []
	if UEbgrSzkGiAatPnM:
		pZebygj5YH4AI1BQT7 = wkMR5x1gTWEQIc6qHCa.path.join(yBIA5N98RmP7pdzeS3s0gOH,Cpf9s3c0Zngj7XE)
		try: tHzN1B5q6lgi7sXI2Vum = wkMR5x1gTWEQIc6qHCa.listdir(pZebygj5YH4AI1BQT7)
		except:
			if not wkMR5x1gTWEQIc6qHCa.path.exists(pZebygj5YH4AI1BQT7):
				try: wkMR5x1gTWEQIc6qHCa.makedirs(pZebygj5YH4AI1BQT7)
				except: pass
	NsMK3YDbBqf6TI75zxdu9Zpm = bBTkyPgS6VzOZ('menu_item')
	q8tDhmy6zx7oZ = tHzN1B5q6lgi7sXI2Vum
	if iELueYz3J1FmxaW7vc and ytv0YaxDcRINurplWKg587Pwqz.platform=='win32':
		q8tDhmy6zx7oZ = []
		for C1C5N9Gfmso7BPvzSTw in tHzN1B5q6lgi7sXI2Vum:
			C1C5N9Gfmso7BPvzSTw = C1C5N9Gfmso7BPvzSTw.decode('windows-1256').encode(df6QpwGxuJVZr)
			q8tDhmy6zx7oZ.append(C1C5N9Gfmso7BPvzSTw)
	for pTGfY20EU8LO1eCjHMig5Z4NsKcJt in q4qrAvDcxHOdGTwoXgun:
		JJwnocyLUxHI2jlKF4Y = pTGfY20EU8LO1eCjHMig5Z4NsKcJt['name']
		if J1MoiYc7ZwzKS: JJwnocyLUxHI2jlKF4Y = JJwnocyLUxHI2jlKF4Y.encode(df6QpwGxuJVZr,'ignore').decode(df6QpwGxuJVZr)
		bd98YKj0Foi4H3rUDsISJl2Mmfw = pTGfY20EU8LO1eCjHMig5Z4NsKcJt['context_menu']
		wwuxoKREDs74VCcta6ph3 = pTGfY20EU8LO1eCjHMig5Z4NsKcJt['plot']
		J6zuYQT0dlDRrOi2p = pTGfY20EU8LO1eCjHMig5Z4NsKcJt['stars']
		GmrA8hvBgN4bDdEWXS9nVMtU = pTGfY20EU8LO1eCjHMig5Z4NsKcJt['image']
		synCYOiMR789twmfr = pTGfY20EU8LO1eCjHMig5Z4NsKcJt['type']
		wkYquGBgtfiTI5Ph1UEZc4oJ08Q = pTGfY20EU8LO1eCjHMig5Z4NsKcJt['duration']
		PEaKrSG5W1RH7dUBw2nsFA = pTGfY20EU8LO1eCjHMig5Z4NsKcJt['isFolder']
		nxtVhW5I7Kij8D6Zq = pTGfY20EU8LO1eCjHMig5Z4NsKcJt['newpath']
		sReYwyh6kKc7JviZ4p = OOYtyXB3o8K.ListItem(JJwnocyLUxHI2jlKF4Y)
		sReYwyh6kKc7JviZ4p.addContextMenuItems(bd98YKj0Foi4H3rUDsISJl2Mmfw)
		cx7vZOMjaPeyiFfh = False if UEbgrSzkGiAatPnM else True
		if GmrA8hvBgN4bDdEWXS9nVMtU:
			sReYwyh6kKc7JviZ4p.setArt({'icon':GmrA8hvBgN4bDdEWXS9nVMtU,'thumb':GmrA8hvBgN4bDdEWXS9nVMtU,'fanart':GmrA8hvBgN4bDdEWXS9nVMtU,'banner':GmrA8hvBgN4bDdEWXS9nVMtU,'clearart':GmrA8hvBgN4bDdEWXS9nVMtU,'poster':GmrA8hvBgN4bDdEWXS9nVMtU,'clearlogo':GmrA8hvBgN4bDdEWXS9nVMtU,'landscape':GmrA8hvBgN4bDdEWXS9nVMtU})
			cx7vZOMjaPeyiFfh = False
		elif not cx7vZOMjaPeyiFfh:
			cx7vZOMjaPeyiFfh = True
			JJwnocyLUxHI2jlKF4Y = mkT7KMxSV1PvEr5(BF6QAiLUNHh7rKOugaw,JJwnocyLUxHI2jlKF4Y)
			JJwnocyLUxHI2jlKF4Y = VzC7H3ty4U8GkD(JJwnocyLUxHI2jlKF4Y)
			nbps1ih4ogWv = JJwnocyLUxHI2jlKF4Y+'.png'
			J7QVSmZrqOg3wi8t0hnd9DjuMXvWU = wkMR5x1gTWEQIc6qHCa.path.join(pZebygj5YH4AI1BQT7,nbps1ih4ogWv)
			if nbps1ih4ogWv in q8tDhmy6zx7oZ:
				sReYwyh6kKc7JviZ4p.setArt({'icon':J7QVSmZrqOg3wi8t0hnd9DjuMXvWU,'thumb':J7QVSmZrqOg3wi8t0hnd9DjuMXvWU,'fanart':J7QVSmZrqOg3wi8t0hnd9DjuMXvWU,'banner':J7QVSmZrqOg3wi8t0hnd9DjuMXvWU,'clearart':J7QVSmZrqOg3wi8t0hnd9DjuMXvWU,'poster':J7QVSmZrqOg3wi8t0hnd9DjuMXvWU,'clearlogo':J7QVSmZrqOg3wi8t0hnd9DjuMXvWU,'landscape':J7QVSmZrqOg3wi8t0hnd9DjuMXvWU})
				cx7vZOMjaPeyiFfh = False
			elif PGsq4lFpJOLDT<40 and KoY5jz0I1Pku3weCV6H8mgxq7<=3:
				try:
					gYTxQJDfmECS18 = FOSZtfLwM64k37GxpiH(NsMK3YDbBqf6TI75zxdu9Zpm,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,JJwnocyLUxHI2jlKF4Y,'menu_item','center',False,J7QVSmZrqOg3wi8t0hnd9DjuMXvWU)
					sReYwyh6kKc7JviZ4p.setArt({'icon':J7QVSmZrqOg3wi8t0hnd9DjuMXvWU,'thumb':J7QVSmZrqOg3wi8t0hnd9DjuMXvWU,'fanart':J7QVSmZrqOg3wi8t0hnd9DjuMXvWU,'banner':J7QVSmZrqOg3wi8t0hnd9DjuMXvWU,'clearart':J7QVSmZrqOg3wi8t0hnd9DjuMXvWU,'poster':J7QVSmZrqOg3wi8t0hnd9DjuMXvWU,'clearlogo':J7QVSmZrqOg3wi8t0hnd9DjuMXvWU,'landscape':J7QVSmZrqOg3wi8t0hnd9DjuMXvWU})
					PGsq4lFpJOLDT += 1
					cx7vZOMjaPeyiFfh = False
					q8tDhmy6zx7oZ.append(nbps1ih4ogWv)
					if PGsq4lFpJOLDT==5: YYkhEn5xTXLUevzCVNB16mR('إضافة الكتابة لصور القائمة','انتظار',X2cQ5NCPvkMieBW7oASspFjE=500)
				except: KoY5jz0I1Pku3weCV6H8mgxq7 += 1
		if cx7vZOMjaPeyiFfh:
			sReYwyh6kKc7JviZ4p.setArt({'icon':NVyzGu2hnfiB61rP,'thumb':NVyzGu2hnfiB61rP,'fanart':NVyzGu2hnfiB61rP,'banner':NVyzGu2hnfiB61rP,'clearart':NVyzGu2hnfiB61rP,'poster':NVyzGu2hnfiB61rP,'clearlogo':NVyzGu2hnfiB61rP,'landscape':NVyzGu2hnfiB61rP})
		if ZD1J5rN8u2wzdgqoyULm4<20:
			if wwuxoKREDs74VCcta6ph3: sReYwyh6kKc7JviZ4p.setInfo('video',{'Plot':wwuxoKREDs74VCcta6ph3,'PlotOutline':wwuxoKREDs74VCcta6ph3})
			if J6zuYQT0dlDRrOi2p: sReYwyh6kKc7JviZ4p.setInfo('video',{'Rating':J6zuYQT0dlDRrOi2p})
			if not GmrA8hvBgN4bDdEWXS9nVMtU:
				sReYwyh6kKc7JviZ4p.setInfo('video',{'Title':JJwnocyLUxHI2jlKF4Y})
			if synCYOiMR789twmfr=='video':
				sReYwyh6kKc7JviZ4p.setInfo('video',{'mediatype':'tvshow'})
				if wkYquGBgtfiTI5Ph1UEZc4oJ08Q: sReYwyh6kKc7JviZ4p.setInfo('video',{'duration':wkYquGBgtfiTI5Ph1UEZc4oJ08Q})
				sReYwyh6kKc7JviZ4p.setProperty('IsPlayable','true')
		else:
			sgRJSbBuZIoqvHN = sReYwyh6kKc7JviZ4p.getVideoInfoTag()
			if J6zuYQT0dlDRrOi2p: sgRJSbBuZIoqvHN.setRating(float(J6zuYQT0dlDRrOi2p))
			if not GmrA8hvBgN4bDdEWXS9nVMtU:
				sgRJSbBuZIoqvHN.setTitle(JJwnocyLUxHI2jlKF4Y)
			if synCYOiMR789twmfr=='video':
				sgRJSbBuZIoqvHN.setMediaType('tvshow')
				if wkYquGBgtfiTI5Ph1UEZc4oJ08Q: sgRJSbBuZIoqvHN.setDuration(wkYquGBgtfiTI5Ph1UEZc4oJ08Q)
				sReYwyh6kKc7JviZ4p.setProperty('IsPlayable','true')
		r6rDCRJALzTGQm52pbyhwlUqx80H.append((nxtVhW5I7Kij8D6Zq,sReYwyh6kKc7JviZ4p,PEaKrSG5W1RH7dUBw2nsFA))
	dsBkaDQ16gtSnbrUXvl.setContent(Lwz8pPM60OCIBK7,'tvshows')
	xEaGeB2IjcMVpY79vlmtJ = dsBkaDQ16gtSnbrUXvl.addDirectoryItems(Lwz8pPM60OCIBK7,r6rDCRJALzTGQm52pbyhwlUqx80H)
	dsBkaDQ16gtSnbrUXvl.endOfDirectory(Lwz8pPM60OCIBK7,VsfSE7hTyxPUko,MM1pfeZINLmyPWdYwojzQK2b,UUzagAt7TOIkQXZdyC1SoLV50bfp)
	return xEaGeB2IjcMVpY79vlmtJ
def bP6z3OSLp7va(synCYOiMR789twmfr,JJwnocyLUxHI2jlKF4Y,kMqh74TPvpSDar59xQUjAyVlHes,Cpf9s3c0Zngj7XE,GmrA8hvBgN4bDdEWXS9nVMtU=iiy37aKq0pCEIOwfcTh61xb4U,F50ngOyjSvAcVRtdafJsiBkP9Yx=iiy37aKq0pCEIOwfcTh61xb4U,U94JwhRgpXCOe5=iiy37aKq0pCEIOwfcTh61xb4U,YGNomIp2tDSR6ncf=iiy37aKq0pCEIOwfcTh61xb4U,BSmlfc08nJ={}):
	JJwnocyLUxHI2jlKF4Y = JJwnocyLUxHI2jlKF4Y.replace(Mge0HhFk9Ic6sm5VR,iiy37aKq0pCEIOwfcTh61xb4U).replace(OTlVEGYPSxsNaBdXUucqA3,iiy37aKq0pCEIOwfcTh61xb4U).replace('\t',iiy37aKq0pCEIOwfcTh61xb4U)
	kMqh74TPvpSDar59xQUjAyVlHes = kMqh74TPvpSDar59xQUjAyVlHes.replace(Mge0HhFk9Ic6sm5VR,iiy37aKq0pCEIOwfcTh61xb4U).replace(OTlVEGYPSxsNaBdXUucqA3,iiy37aKq0pCEIOwfcTh61xb4U).replace('\t',iiy37aKq0pCEIOwfcTh61xb4U)
	if '_SCRIPT_' in JJwnocyLUxHI2jlKF4Y:
		x25j0zbNOqAe4BgIoQtcd,JJwnocyLUxHI2jlKF4Y = JJwnocyLUxHI2jlKF4Y.split('_SCRIPT_',YYJQyRskpX8jv)
		if x25j0zbNOqAe4BgIoQtcd not in list(DLTuRI6kd1K75q.keys()): DLTuRI6kd1K75q[x25j0zbNOqAe4BgIoQtcd] = []
		DLTuRI6kd1K75q[x25j0zbNOqAe4BgIoQtcd].append([synCYOiMR789twmfr,JJwnocyLUxHI2jlKF4Y,kMqh74TPvpSDar59xQUjAyVlHes,Cpf9s3c0Zngj7XE,GmrA8hvBgN4bDdEWXS9nVMtU,F50ngOyjSvAcVRtdafJsiBkP9Yx,U94JwhRgpXCOe5,YGNomIp2tDSR6ncf,BSmlfc08nJ])
	g6ghGH4aBEYkTl3vbJZ.append([synCYOiMR789twmfr,JJwnocyLUxHI2jlKF4Y,kMqh74TPvpSDar59xQUjAyVlHes,Cpf9s3c0Zngj7XE,GmrA8hvBgN4bDdEWXS9nVMtU,F50ngOyjSvAcVRtdafJsiBkP9Yx,U94JwhRgpXCOe5,YGNomIp2tDSR6ncf,BSmlfc08nJ])
	return
def JIY6A30UOsQboNVqCn(bfoOSGvpVsYumBJZC):
	if J1MoiYc7ZwzKS: from html import unescape as _mVeAa4Cz5lLJd8WGM1NqnIQhD0F
	else:
		from HTMLParser import HTMLParser as Jh8xWPYaIM2cdkgtB
		_mVeAa4Cz5lLJd8WGM1NqnIQhD0F = Jh8xWPYaIM2cdkgtB().unescape
	if '&' in bfoOSGvpVsYumBJZC and ';' in bfoOSGvpVsYumBJZC:
		if iELueYz3J1FmxaW7vc: bfoOSGvpVsYumBJZC = bfoOSGvpVsYumBJZC.decode(df6QpwGxuJVZr)
		bfoOSGvpVsYumBJZC = _mVeAa4Cz5lLJd8WGM1NqnIQhD0F(bfoOSGvpVsYumBJZC)
		if iELueYz3J1FmxaW7vc: bfoOSGvpVsYumBJZC = bfoOSGvpVsYumBJZC.encode(df6QpwGxuJVZr)
	return bfoOSGvpVsYumBJZC
def vvmT3DLXkhPBwIaOAo6srZpEnRVJC(bfoOSGvpVsYumBJZC):
	if '\\u' in bfoOSGvpVsYumBJZC:
		if iELueYz3J1FmxaW7vc: bfoOSGvpVsYumBJZC = bfoOSGvpVsYumBJZC.decode('unicode_escape','ignore').encode(df6QpwGxuJVZr)
		elif J1MoiYc7ZwzKS: bfoOSGvpVsYumBJZC = bfoOSGvpVsYumBJZC.encode(df6QpwGxuJVZr).decode('unicode_escape','ignore')
	return bfoOSGvpVsYumBJZC
def XV4nFRGIpg971ukM(RcJmGpx0qFjO4fzuylK8rkDhN,y3WZiaCjV98z6ROhmuXIwd,OUrZksDBdzLRChpM0XVE3,sd3zn48ftXjNWg,U94JwhRgpXCOe5,E7DfB9Yhb0RHvLlyeC8pPnWG,dSNcs3QZJwOUL2zhBuaHPpt,GCgswDpZF3,Hi5cI2hkSaJLZq80wypYC1U):
	uOSseqPxbh8m6lR3fN4Qci = wkMR5x1gTWEQIc6qHCa.path.dirname(Hi5cI2hkSaJLZq80wypYC1U)
	if not wkMR5x1gTWEQIc6qHCa.path.exists(uOSseqPxbh8m6lR3fN4Qci):
		try: wkMR5x1gTWEQIc6qHCa.makedirs(uOSseqPxbh8m6lR3fN4Qci)
		except: pass
	B64oeXsxtTkhwD2d0 = bBTkyPgS6VzOZ(E7DfB9Yhb0RHvLlyeC8pPnWG)
	gYTxQJDfmECS18 = FOSZtfLwM64k37GxpiH(B64oeXsxtTkhwD2d0,RcJmGpx0qFjO4fzuylK8rkDhN,y3WZiaCjV98z6ROhmuXIwd,OUrZksDBdzLRChpM0XVE3,sd3zn48ftXjNWg,U94JwhRgpXCOe5,E7DfB9Yhb0RHvLlyeC8pPnWG,dSNcs3QZJwOUL2zhBuaHPpt,GCgswDpZF3,Hi5cI2hkSaJLZq80wypYC1U)
	return gYTxQJDfmECS18
def bBTkyPgS6VzOZ(E7DfB9Yhb0RHvLlyeC8pPnWG):
	RvqCDiP0TKOo1HI = 5
	FXnBwDAIavfVsP = 20
	gyDk7z6dNtYwLPr = 20
	O74rSo1GV3QyKqEf = 0
	KVjWDMmcdoZzqBhYOH = 'center'
	NRZd8HKOPavXogF4WY5TpnCEus3 = 0
	IcuTxvPGAy738YeW0KmSN = 19
	UQ8lPYLcCKbmaZGdq = 30
	xOHIjh83JLrt6zcX0oRkqZKEysTS = 8
	QVuIO3RG0tMvTNmzdjlWPEJpw = True
	okQ58nUvswbtFJSRXjGicDeNr = 375
	U0syfgomMWuzHOdchr = 410
	DsM4I2chmgRwWtqe1E7XJ = 50
	bvXlnUo4TDjBeKCwy5FOau3Vf1H = 280
	PoOxKXHVsM7JnGS2A = 28
	UA0bzmWokQw2jpsi = 5
	hG4U9qEVOCTPN1RuKdxSY6BpZk5oi = 0
	SSGjD5Tzd6KA9aWVp1oZvI0t = 31
	okcfBX7F0z5Q9mExT3GV1AjPt = [36,32,28]
	from PIL import ImageDraw as rmlR3OKoLGeNs,ImageFont as g5gE4wnyMf0q9dVxjTRCSciWYo,Image as gp6bWnoXtrHawFMuE0PYZvkQ8JD
	if 'notification' in E7DfB9Yhb0RHvLlyeC8pPnWG:
		if E7DfB9Yhb0RHvLlyeC8pPnWG=='notification_regular':
			bbKFYcmpElNq = 117
			KVjWDMmcdoZzqBhYOH = 'left'
			QVuIO3RG0tMvTNmzdjlWPEJpw = False
		elif E7DfB9Yhb0RHvLlyeC8pPnWG=='notification_auto':
			bbKFYcmpElNq = 'UPPER'
			KVjWDMmcdoZzqBhYOH = 'right'
			O74rSo1GV3QyKqEf = 10
		bzJ2oTGcOXQu = 720
		okcfBX7F0z5Q9mExT3GV1AjPt = [33,33,33]
		gyDk7z6dNtYwLPr = 20
		FXnBwDAIavfVsP = 0
		UQ8lPYLcCKbmaZGdq = 20
		IcuTxvPGAy738YeW0KmSN = 35
	elif E7DfB9Yhb0RHvLlyeC8pPnWG=='menu_item':
		okcfBX7F0z5Q9mExT3GV1AjPt,bzJ2oTGcOXQu,bbKFYcmpElNq = [28,28,28],200,250
		NRZd8HKOPavXogF4WY5TpnCEus3,UQ8lPYLcCKbmaZGdq,IcuTxvPGAy738YeW0KmSN, = 0,-12,-30
		FXnBwDAIavfVsP = 0
		XVqfhxver0yUJd3ucMQWgYI1TiR = gp6bWnoXtrHawFMuE0PYZvkQ8JD.open(NVyzGu2hnfiB61rP)
		srGvfVOkgJhzUDZtyK0TB7lb5Nq = gp6bWnoXtrHawFMuE0PYZvkQ8JD.new('RGBA',(bzJ2oTGcOXQu,bbKFYcmpElNq),(255,0,0,255))
	elif E7DfB9Yhb0RHvLlyeC8pPnWG=='confirm_smallfont': okcfBX7F0z5Q9mExT3GV1AjPt,bbKFYcmpElNq,bzJ2oTGcOXQu = [28,24,20],500,900
	elif E7DfB9Yhb0RHvLlyeC8pPnWG=='confirm_mediumfont': okcfBX7F0z5Q9mExT3GV1AjPt,bbKFYcmpElNq,bzJ2oTGcOXQu = [32,28,24],500,900
	elif E7DfB9Yhb0RHvLlyeC8pPnWG=='confirm_bigfont': okcfBX7F0z5Q9mExT3GV1AjPt,bbKFYcmpElNq,bzJ2oTGcOXQu = [36,32,28],500,900
	elif E7DfB9Yhb0RHvLlyeC8pPnWG=='textview_bigfont': bbKFYcmpElNq,bzJ2oTGcOXQu = 740,1270
	elif E7DfB9Yhb0RHvLlyeC8pPnWG=='textview_bigfont_long': bbKFYcmpElNq,bzJ2oTGcOXQu = 'UPPER',1270
	elif E7DfB9Yhb0RHvLlyeC8pPnWG=='textview_smallfont': okcfBX7F0z5Q9mExT3GV1AjPt,bbKFYcmpElNq,bzJ2oTGcOXQu = [28,23,18],740,1270
	elif E7DfB9Yhb0RHvLlyeC8pPnWG=='textview_smallfont_long': okcfBX7F0z5Q9mExT3GV1AjPt,bbKFYcmpElNq,bzJ2oTGcOXQu = [28,23,18],'UPPER',1270
	Fl3Z8m7HpDOck0oszUaYhigC5,BBgtFZSTGzkQYsnV,k8kdwjYSVm3AD50oclUptsGKx = okcfBX7F0z5Q9mExT3GV1AjPt
	pp8fn3oE9K2eyAU = g5gE4wnyMf0q9dVxjTRCSciWYo.truetype(mwo4Z2LyxS3BeC5fbntE,size=Fl3Z8m7HpDOck0oszUaYhigC5)
	MpP3ugSKVmJrB0f47 = g5gE4wnyMf0q9dVxjTRCSciWYo.truetype(mwo4Z2LyxS3BeC5fbntE,size=BBgtFZSTGzkQYsnV)
	aarPieLXjWkSUuKmQzq = g5gE4wnyMf0q9dVxjTRCSciWYo.truetype(mwo4Z2LyxS3BeC5fbntE,size=k8kdwjYSVm3AD50oclUptsGKx)
	ccNxYIo7XtpP = bzJ2oTGcOXQu-UQ8lPYLcCKbmaZGdq*2
	hGd8i5kYqoPuaf9yV14cge3 = gp6bWnoXtrHawFMuE0PYZvkQ8JD.new('RGBA',(ccNxYIo7XtpP,100),(255,255,255,0))
	loPiEp9kCMh1A6H52q0XVv4 = rmlR3OKoLGeNs.Draw(hGd8i5kYqoPuaf9yV14cge3)
	QHYjfNCT23oc,XXb6O4vAWq9uBSVo = loPiEp9kCMh1A6H52q0XVv4.textsize('HHH BBB 888 000',font=pp8fn3oE9K2eyAU)
	fKyETSkh6G0nw7CMBtz1qe5xRUl,YxgMVA528nGkfvsNP3IjWTOBUS = loPiEp9kCMh1A6H52q0XVv4.textsize('HHH BBB 888 000',font=MpP3ugSKVmJrB0f47)
	cTnWzgFpuVUhX3RiZ5Oa = {'delete_harakat':False,'support_ligatures':True,'ARABIC LIGATURE ALLAH':False}
	from arabic_reshaper import ArabicReshaper as AARYiMGHkm8bnfrdXKah
	MMIHXDZRAlCzfeJ4NiT = AARYiMGHkm8bnfrdXKah(configuration=cTnWzgFpuVUhX3RiZ5Oa)
	B64oeXsxtTkhwD2d0 = {}
	PYK35o7hSgJRenCvBajW1M9sGfqi = locals()
	for cg8pNq2WQ6wszyjtC01JD in PYK35o7hSgJRenCvBajW1M9sGfqi: B64oeXsxtTkhwD2d0[cg8pNq2WQ6wszyjtC01JD] = PYK35o7hSgJRenCvBajW1M9sGfqi[cg8pNq2WQ6wszyjtC01JD]
	return B64oeXsxtTkhwD2d0
def FOSZtfLwM64k37GxpiH(B64oeXsxtTkhwD2d0,RcJmGpx0qFjO4fzuylK8rkDhN,y3WZiaCjV98z6ROhmuXIwd,OUrZksDBdzLRChpM0XVE3,sd3zn48ftXjNWg,U94JwhRgpXCOe5,E7DfB9Yhb0RHvLlyeC8pPnWG,dSNcs3QZJwOUL2zhBuaHPpt,GCgswDpZF3,Hi5cI2hkSaJLZq80wypYC1U):
	for cg8pNq2WQ6wszyjtC01JD in B64oeXsxtTkhwD2d0: globals()[cg8pNq2WQ6wszyjtC01JD] = B64oeXsxtTkhwD2d0[cg8pNq2WQ6wszyjtC01JD]
	global PoOxKXHVsM7JnGS2A,UA0bzmWokQw2jpsi
	if E7DfB9Yhb0RHvLlyeC8pPnWG!='menu_item':
		EHGw27fNoyb = OXsckY7RzjCag9A.getSetting('av.language.translate')
		if EHGw27fNoyb:
			if RcJmGpx0qFjO4fzuylK8rkDhN=='نعم  Yes': RcJmGpx0qFjO4fzuylK8rkDhN = 'Yes'
			elif RcJmGpx0qFjO4fzuylK8rkDhN=='كلا  No': RcJmGpx0qFjO4fzuylK8rkDhN = 'No'
			if y3WZiaCjV98z6ROhmuXIwd=='نعم  Yes': y3WZiaCjV98z6ROhmuXIwd = 'Yes'
			elif y3WZiaCjV98z6ROhmuXIwd=='كلا  No': y3WZiaCjV98z6ROhmuXIwd = 'No'
			if OUrZksDBdzLRChpM0XVE3=='نعم  Yes': OUrZksDBdzLRChpM0XVE3 = 'Yes'
			elif OUrZksDBdzLRChpM0XVE3=='كلا  No': OUrZksDBdzLRChpM0XVE3 = 'No'
			LcMSkexq718nIEaCGRgP = KYcVJr7yP5kfhAFCbgQMzu([RcJmGpx0qFjO4fzuylK8rkDhN,y3WZiaCjV98z6ROhmuXIwd,OUrZksDBdzLRChpM0XVE3,sd3zn48ftXjNWg,U94JwhRgpXCOe5])
			if LcMSkexq718nIEaCGRgP: RcJmGpx0qFjO4fzuylK8rkDhN,y3WZiaCjV98z6ROhmuXIwd,OUrZksDBdzLRChpM0XVE3,sd3zn48ftXjNWg,U94JwhRgpXCOe5 = LcMSkexq718nIEaCGRgP
	if iELueYz3J1FmxaW7vc:
		U94JwhRgpXCOe5 = U94JwhRgpXCOe5.decode(df6QpwGxuJVZr)
		sd3zn48ftXjNWg = sd3zn48ftXjNWg.decode(df6QpwGxuJVZr)
		RcJmGpx0qFjO4fzuylK8rkDhN = RcJmGpx0qFjO4fzuylK8rkDhN.decode(df6QpwGxuJVZr)
		y3WZiaCjV98z6ROhmuXIwd = y3WZiaCjV98z6ROhmuXIwd.decode(df6QpwGxuJVZr)
		OUrZksDBdzLRChpM0XVE3 = OUrZksDBdzLRChpM0XVE3.decode(df6QpwGxuJVZr)
	VA7tiZR4S3T6r1jyQzmOBdsW = sd3zn48ftXjNWg.count(OTlVEGYPSxsNaBdXUucqA3)+1
	vWGXbZl3DTq6F7tNpnKIfydrV = FXnBwDAIavfVsP+VA7tiZR4S3T6r1jyQzmOBdsW*(XXb6O4vAWq9uBSVo+O74rSo1GV3QyKqEf)-O74rSo1GV3QyKqEf
	if U94JwhRgpXCOe5:
		gCvIfYA61EbWGT = YxgMVA528nGkfvsNP3IjWTOBUS+xOHIjh83JLrt6zcX0oRkqZKEysTS
		IA5yKlFeg79O0Y1 = MMIHXDZRAlCzfeJ4NiT.reshape(U94JwhRgpXCOe5)
		if QVuIO3RG0tMvTNmzdjlWPEJpw:
			feOPgv5q3a2wuIAntyBSzFRk9GHrs = bbwia8CpFfq9QOJcdz1st(loPiEp9kCMh1A6H52q0XVv4,MpP3ugSKVmJrB0f47,IA5yKlFeg79O0Y1,BBgtFZSTGzkQYsnV,ccNxYIo7XtpP,gCvIfYA61EbWGT)
			FnCxIcH2gtU1GzSyQjP0K = Hdkb25KVscmBWAXnh(feOPgv5q3a2wuIAntyBSzFRk9GHrs)
			hc4uv0aLp2gTyd3mDrtS1qBONf6KQI = FnCxIcH2gtU1GzSyQjP0K.count(OTlVEGYPSxsNaBdXUucqA3)+1
			yyCEQpzFtTb61vfR7 = IcuTxvPGAy738YeW0KmSN+hc4uv0aLp2gTyd3mDrtS1qBONf6KQI*gCvIfYA61EbWGT-xOHIjh83JLrt6zcX0oRkqZKEysTS
		else:
			yyCEQpzFtTb61vfR7 = IcuTxvPGAy738YeW0KmSN+YxgMVA528nGkfvsNP3IjWTOBUS
			FnCxIcH2gtU1GzSyQjP0K = IA5yKlFeg79O0Y1.split(OTlVEGYPSxsNaBdXUucqA3)[0]
			feOPgv5q3a2wuIAntyBSzFRk9GHrs = IA5yKlFeg79O0Y1.split(OTlVEGYPSxsNaBdXUucqA3)[0]
	else: yyCEQpzFtTb61vfR7 = IcuTxvPGAy738YeW0KmSN
	CGwxcpVl6DuaT = hG4U9qEVOCTPN1RuKdxSY6BpZk5oi+SSGjD5Tzd6KA9aWVp1oZvI0t
	if GCgswDpZF3:
		eTXsV9vWqA1PztRUaok7FMyCESBc = U0syfgomMWuzHOdchr-okQ58nUvswbtFJSRXjGicDeNr
		CGwxcpVl6DuaT += eTXsV9vWqA1PztRUaok7FMyCESBc
	else: eTXsV9vWqA1PztRUaok7FMyCESBc = 0
	if RcJmGpx0qFjO4fzuylK8rkDhN or y3WZiaCjV98z6ROhmuXIwd or OUrZksDBdzLRChpM0XVE3: CGwxcpVl6DuaT += DsM4I2chmgRwWtqe1E7XJ
	gYTxQJDfmECS18 = bbKFYcmpElNq if bbKFYcmpElNq!='UPPER' else vWGXbZl3DTq6F7tNpnKIfydrV+yyCEQpzFtTb61vfR7+CGwxcpVl6DuaT
	hGd8i5kYqoPuaf9yV14cge3 = gp6bWnoXtrHawFMuE0PYZvkQ8JD.new('RGBA',(bzJ2oTGcOXQu,gYTxQJDfmECS18),(255,255,255,0))
	wtLyaXW4ob729P8sqYZNIDKk = rmlR3OKoLGeNs.Draw(hGd8i5kYqoPuaf9yV14cge3)
	gvUekJrwsDy = gYTxQJDfmECS18-vWGXbZl3DTq6F7tNpnKIfydrV-CGwxcpVl6DuaT-IcuTxvPGAy738YeW0KmSN
	if not y3WZiaCjV98z6ROhmuXIwd and RcJmGpx0qFjO4fzuylK8rkDhN and OUrZksDBdzLRChpM0XVE3:
		PoOxKXHVsM7JnGS2A += 105
		UA0bzmWokQw2jpsi -= 110
	import bidi.algorithm as k9WamxRu6M4K0qeEXY
	if sd3zn48ftXjNWg:
		w9PF31GMZgTJWxaiL = FXnBwDAIavfVsP
		sd3zn48ftXjNWg = k9WamxRu6M4K0qeEXY.get_display(MMIHXDZRAlCzfeJ4NiT.reshape(sd3zn48ftXjNWg))
		UCOyxvPEBiwmbkLdzfDjIM4rp = sd3zn48ftXjNWg.splitlines()
		for ALqPlOD34cfHQWk7ae0URbZotXNTFs in UCOyxvPEBiwmbkLdzfDjIM4rp:
			if ALqPlOD34cfHQWk7ae0URbZotXNTFs:
				ZtDS52qu9Rx4v3ybks7EWiN01FHAe,LLjciYF4JtUAe = wtLyaXW4ob729P8sqYZNIDKk.textsize(ALqPlOD34cfHQWk7ae0URbZotXNTFs,font=pp8fn3oE9K2eyAU)
				if KVjWDMmcdoZzqBhYOH=='center': h6YvAFy18oMBOqKzDnluNCwQ57p = RvqCDiP0TKOo1HI+(bzJ2oTGcOXQu-ZtDS52qu9Rx4v3ybks7EWiN01FHAe)/2
				elif KVjWDMmcdoZzqBhYOH=='right': h6YvAFy18oMBOqKzDnluNCwQ57p = RvqCDiP0TKOo1HI+bzJ2oTGcOXQu-ZtDS52qu9Rx4v3ybks7EWiN01FHAe-gyDk7z6dNtYwLPr
				elif KVjWDMmcdoZzqBhYOH=='left': h6YvAFy18oMBOqKzDnluNCwQ57p = RvqCDiP0TKOo1HI+gyDk7z6dNtYwLPr
				wtLyaXW4ob729P8sqYZNIDKk.text((h6YvAFy18oMBOqKzDnluNCwQ57p,w9PF31GMZgTJWxaiL),ALqPlOD34cfHQWk7ae0URbZotXNTFs,font=pp8fn3oE9K2eyAU,fill='yellow')
			w9PF31GMZgTJWxaiL += Fl3Z8m7HpDOck0oszUaYhigC5+O74rSo1GV3QyKqEf
	if RcJmGpx0qFjO4fzuylK8rkDhN or y3WZiaCjV98z6ROhmuXIwd or OUrZksDBdzLRChpM0XVE3:
		SUG2Z4YKCNay68PVEc0ivOQxfzp1 = vWGXbZl3DTq6F7tNpnKIfydrV+gvUekJrwsDy+IcuTxvPGAy738YeW0KmSN+eTXsV9vWqA1PztRUaok7FMyCESBc+hG4U9qEVOCTPN1RuKdxSY6BpZk5oi
		if RcJmGpx0qFjO4fzuylK8rkDhN:
			RcJmGpx0qFjO4fzuylK8rkDhN = k9WamxRu6M4K0qeEXY.get_display(MMIHXDZRAlCzfeJ4NiT.reshape(RcJmGpx0qFjO4fzuylK8rkDhN))
			lrcQkySxuMnLvRfaPqGT1D,FZ8IBRPU7wkCdL4HivQzurcJj = wtLyaXW4ob729P8sqYZNIDKk.textsize(RcJmGpx0qFjO4fzuylK8rkDhN,font=aarPieLXjWkSUuKmQzq)
			ZNFApXrEj0y3bzxSUWicBuqeK = PoOxKXHVsM7JnGS2A+0*(UA0bzmWokQw2jpsi+bvXlnUo4TDjBeKCwy5FOau3Vf1H)+(bvXlnUo4TDjBeKCwy5FOau3Vf1H-lrcQkySxuMnLvRfaPqGT1D)/2
			wtLyaXW4ob729P8sqYZNIDKk.text((ZNFApXrEj0y3bzxSUWicBuqeK,SUG2Z4YKCNay68PVEc0ivOQxfzp1),RcJmGpx0qFjO4fzuylK8rkDhN,font=aarPieLXjWkSUuKmQzq,fill='yellow')
		if y3WZiaCjV98z6ROhmuXIwd:
			y3WZiaCjV98z6ROhmuXIwd = k9WamxRu6M4K0qeEXY.get_display(MMIHXDZRAlCzfeJ4NiT.reshape(y3WZiaCjV98z6ROhmuXIwd))
			TgAUbLHcm1e,DKJ0LxWuMvmQX2ZsRcU5C = wtLyaXW4ob729P8sqYZNIDKk.textsize(y3WZiaCjV98z6ROhmuXIwd,font=aarPieLXjWkSUuKmQzq)
			SkEdYKG4Q8VFAwx9uJqRp7HPsy = PoOxKXHVsM7JnGS2A+1*(UA0bzmWokQw2jpsi+bvXlnUo4TDjBeKCwy5FOau3Vf1H)+(bvXlnUo4TDjBeKCwy5FOau3Vf1H-TgAUbLHcm1e)/2
			wtLyaXW4ob729P8sqYZNIDKk.text((SkEdYKG4Q8VFAwx9uJqRp7HPsy,SUG2Z4YKCNay68PVEc0ivOQxfzp1),y3WZiaCjV98z6ROhmuXIwd,font=aarPieLXjWkSUuKmQzq,fill='yellow')
		if OUrZksDBdzLRChpM0XVE3:
			OUrZksDBdzLRChpM0XVE3 = k9WamxRu6M4K0qeEXY.get_display(MMIHXDZRAlCzfeJ4NiT.reshape(OUrZksDBdzLRChpM0XVE3))
			CKgdJX953BoqQu6,tXnLKJpCQVmcHvPb3ki8B7ID9 = wtLyaXW4ob729P8sqYZNIDKk.textsize(OUrZksDBdzLRChpM0XVE3,font=aarPieLXjWkSUuKmQzq)
			OHskywLJ8Q7ox0Xcam934KUF = PoOxKXHVsM7JnGS2A+2*(UA0bzmWokQw2jpsi+bvXlnUo4TDjBeKCwy5FOau3Vf1H)+(bvXlnUo4TDjBeKCwy5FOau3Vf1H-CKgdJX953BoqQu6)/2
			wtLyaXW4ob729P8sqYZNIDKk.text((OHskywLJ8Q7ox0Xcam934KUF,SUG2Z4YKCNay68PVEc0ivOQxfzp1),OUrZksDBdzLRChpM0XVE3,font=aarPieLXjWkSUuKmQzq,fill='yellow')
	if U94JwhRgpXCOe5:
		PWbus4dJ2A7KeC19Ekj5HL,GnfbQriIMsNU = [],[]
		feOPgv5q3a2wuIAntyBSzFRk9GHrs = nwhYl94ZQuVD(feOPgv5q3a2wuIAntyBSzFRk9GHrs)
		bBVYlDrmv5GL8yj = feOPgv5q3a2wuIAntyBSzFRk9GHrs.split('_sss__newline_')
		for VnQ37ACd9BKUDXvgZl1 in bBVYlDrmv5GL8yj:
			XXGDMYkJdK2sfO = dSNcs3QZJwOUL2zhBuaHPpt
			if   '_sss__lineleft_' in VnQ37ACd9BKUDXvgZl1: XXGDMYkJdK2sfO = 'left'
			elif '_sss__lineright_' in VnQ37ACd9BKUDXvgZl1: XXGDMYkJdK2sfO = 'right'
			elif '_sss__linecenter_' in VnQ37ACd9BKUDXvgZl1: XXGDMYkJdK2sfO = 'center'
			ypNMjtBSe5WVfYhxQgnAUabc = VnQ37ACd9BKUDXvgZl1
			Z82GI0hlNowk9cmBM6z = dEyT9xhGjolYzLCH7460w3.findall('_sss__.*?_',VnQ37ACd9BKUDXvgZl1,dEyT9xhGjolYzLCH7460w3.DOTALL)
			for GVrkcyxHFuS in Z82GI0hlNowk9cmBM6z: ypNMjtBSe5WVfYhxQgnAUabc = ypNMjtBSe5WVfYhxQgnAUabc.replace(GVrkcyxHFuS,iiy37aKq0pCEIOwfcTh61xb4U)
			if ypNMjtBSe5WVfYhxQgnAUabc==iiy37aKq0pCEIOwfcTh61xb4U: ZtDS52qu9Rx4v3ybks7EWiN01FHAe,LLjciYF4JtUAe = 0,gCvIfYA61EbWGT
			else: ZtDS52qu9Rx4v3ybks7EWiN01FHAe,LLjciYF4JtUAe = wtLyaXW4ob729P8sqYZNIDKk.textsize(ypNMjtBSe5WVfYhxQgnAUabc,font=MpP3ugSKVmJrB0f47)
			if   XXGDMYkJdK2sfO=='left': m6SV7NgywJeZWI30RcbOnFq = NRZd8HKOPavXogF4WY5TpnCEus3+UQ8lPYLcCKbmaZGdq
			elif XXGDMYkJdK2sfO=='right': m6SV7NgywJeZWI30RcbOnFq = NRZd8HKOPavXogF4WY5TpnCEus3+UQ8lPYLcCKbmaZGdq+ccNxYIo7XtpP-ZtDS52qu9Rx4v3ybks7EWiN01FHAe
			elif XXGDMYkJdK2sfO=='center': m6SV7NgywJeZWI30RcbOnFq = NRZd8HKOPavXogF4WY5TpnCEus3+UQ8lPYLcCKbmaZGdq+(ccNxYIo7XtpP-ZtDS52qu9Rx4v3ybks7EWiN01FHAe)/2
			if m6SV7NgywJeZWI30RcbOnFq<UQ8lPYLcCKbmaZGdq: m6SV7NgywJeZWI30RcbOnFq = NRZd8HKOPavXogF4WY5TpnCEus3+UQ8lPYLcCKbmaZGdq
			PWbus4dJ2A7KeC19Ekj5HL.append(m6SV7NgywJeZWI30RcbOnFq)
			GnfbQriIMsNU.append(ZtDS52qu9Rx4v3ybks7EWiN01FHAe)
		m6SV7NgywJeZWI30RcbOnFq = PWbus4dJ2A7KeC19Ekj5HL[0]
		nUyLVCDXoIhfNr = feOPgv5q3a2wuIAntyBSzFRk9GHrs.split('_sss_')
		gTVjdYeJtGwpWlDic = (255,255,255,255)
		ddp4DtcjaUiyBgEkGhoef7 = gTVjdYeJtGwpWlDic
		xjBgp6IW79rAnFVE4GJh50oOMyeYD,bdVMIGDNfCjErgiKqmsUk4uo9Q = 0,0
		qqf0NsYbMpSmQHeVuJ3gOkZ = False
		WTPHmZ9AxQ53haBcv1sfEyYJGq8Ugl = 0
		pz8U0uq2l46CbVA = vWGXbZl3DTq6F7tNpnKIfydrV+IcuTxvPGAy738YeW0KmSN/2
		if yyCEQpzFtTb61vfR7<(gvUekJrwsDy+IcuTxvPGAy738YeW0KmSN):
			xxs1mclDvHOa6doz9 = (gvUekJrwsDy+IcuTxvPGAy738YeW0KmSN-yyCEQpzFtTb61vfR7)/2
			pz8U0uq2l46CbVA = vWGXbZl3DTq6F7tNpnKIfydrV+IcuTxvPGAy738YeW0KmSN+xxs1mclDvHOa6doz9-YxgMVA528nGkfvsNP3IjWTOBUS/2
		for ALqPlOD34cfHQWk7ae0URbZotXNTFs in nUyLVCDXoIhfNr:
			if not ALqPlOD34cfHQWk7ae0URbZotXNTFs or (ALqPlOD34cfHQWk7ae0URbZotXNTFs and ord(ALqPlOD34cfHQWk7ae0URbZotXNTFs[0])==65279): continue
			i7E4JCDSt2ojvk9F5 = ALqPlOD34cfHQWk7ae0URbZotXNTFs.split('_newline_',1)
			AYDWe4kHumacZf1FboP7G3K9Rz58q = ALqPlOD34cfHQWk7ae0URbZotXNTFs.split('_newcolor',1)
			y3yW48OnGRxgFXuwt5 = ALqPlOD34cfHQWk7ae0URbZotXNTFs.split('_endcolor_',1)
			JRHTjUnZ3Itcz = ALqPlOD34cfHQWk7ae0URbZotXNTFs.split('_linertl_',1)
			JJ2acLH019tZl = ALqPlOD34cfHQWk7ae0URbZotXNTFs.split('_lineleft_',1)
			HX5CiV6opSeqwL8OuFxm1RcAh = ALqPlOD34cfHQWk7ae0URbZotXNTFs.split('_lineright_',1)
			t5W302aN7qTKsQOupl4 = ALqPlOD34cfHQWk7ae0URbZotXNTFs.split('_linecenter_',1)
			if len(i7E4JCDSt2ojvk9F5)>1:
				WTPHmZ9AxQ53haBcv1sfEyYJGq8Ugl += 1
				ALqPlOD34cfHQWk7ae0URbZotXNTFs = i7E4JCDSt2ojvk9F5[1]
				xjBgp6IW79rAnFVE4GJh50oOMyeYD = 0
				m6SV7NgywJeZWI30RcbOnFq = PWbus4dJ2A7KeC19Ekj5HL[WTPHmZ9AxQ53haBcv1sfEyYJGq8Ugl]
				bdVMIGDNfCjErgiKqmsUk4uo9Q += gCvIfYA61EbWGT
				qqf0NsYbMpSmQHeVuJ3gOkZ = False
			elif len(AYDWe4kHumacZf1FboP7G3K9Rz58q)>1:
				ALqPlOD34cfHQWk7ae0URbZotXNTFs = AYDWe4kHumacZf1FboP7G3K9Rz58q[1]
				ddp4DtcjaUiyBgEkGhoef7 = ALqPlOD34cfHQWk7ae0URbZotXNTFs[0:8]
				ddp4DtcjaUiyBgEkGhoef7 = '#'+ddp4DtcjaUiyBgEkGhoef7[2:]
				ALqPlOD34cfHQWk7ae0URbZotXNTFs = ALqPlOD34cfHQWk7ae0URbZotXNTFs[9:]
			elif len(y3yW48OnGRxgFXuwt5)>1:
				ALqPlOD34cfHQWk7ae0URbZotXNTFs = y3yW48OnGRxgFXuwt5[1]
				ddp4DtcjaUiyBgEkGhoef7 = gTVjdYeJtGwpWlDic
			elif len(JRHTjUnZ3Itcz)>1:
				ALqPlOD34cfHQWk7ae0URbZotXNTFs = JRHTjUnZ3Itcz[1]
				qqf0NsYbMpSmQHeVuJ3gOkZ = True
				xjBgp6IW79rAnFVE4GJh50oOMyeYD = GnfbQriIMsNU[WTPHmZ9AxQ53haBcv1sfEyYJGq8Ugl]
			elif len(JJ2acLH019tZl)>1: ALqPlOD34cfHQWk7ae0URbZotXNTFs = JJ2acLH019tZl[1]
			elif len(HX5CiV6opSeqwL8OuFxm1RcAh)>1: ALqPlOD34cfHQWk7ae0URbZotXNTFs = HX5CiV6opSeqwL8OuFxm1RcAh[1]
			elif len(t5W302aN7qTKsQOupl4)>1: ALqPlOD34cfHQWk7ae0URbZotXNTFs = t5W302aN7qTKsQOupl4[1]
			if ALqPlOD34cfHQWk7ae0URbZotXNTFs:
				tNviK5BW4Q37uhf6poPSI0rgHn8 = pz8U0uq2l46CbVA+bdVMIGDNfCjErgiKqmsUk4uo9Q
				ALqPlOD34cfHQWk7ae0URbZotXNTFs = k9WamxRu6M4K0qeEXY.get_display(ALqPlOD34cfHQWk7ae0URbZotXNTFs)
				ZtDS52qu9Rx4v3ybks7EWiN01FHAe,LLjciYF4JtUAe = wtLyaXW4ob729P8sqYZNIDKk.textsize(ALqPlOD34cfHQWk7ae0URbZotXNTFs,font=MpP3ugSKVmJrB0f47)
				if qqf0NsYbMpSmQHeVuJ3gOkZ: xjBgp6IW79rAnFVE4GJh50oOMyeYD -= ZtDS52qu9Rx4v3ybks7EWiN01FHAe
				PAvImQplYy7 = m6SV7NgywJeZWI30RcbOnFq+xjBgp6IW79rAnFVE4GJh50oOMyeYD
				wtLyaXW4ob729P8sqYZNIDKk.text((PAvImQplYy7,tNviK5BW4Q37uhf6poPSI0rgHn8),ALqPlOD34cfHQWk7ae0URbZotXNTFs,font=MpP3ugSKVmJrB0f47,fill=ddp4DtcjaUiyBgEkGhoef7)
				if E7DfB9Yhb0RHvLlyeC8pPnWG=='menu_item': wtLyaXW4ob729P8sqYZNIDKk.text((PAvImQplYy7+1,tNviK5BW4Q37uhf6poPSI0rgHn8+1),ALqPlOD34cfHQWk7ae0URbZotXNTFs,font=MpP3ugSKVmJrB0f47,fill=ddp4DtcjaUiyBgEkGhoef7)
				if not qqf0NsYbMpSmQHeVuJ3gOkZ: xjBgp6IW79rAnFVE4GJh50oOMyeYD += ZtDS52qu9Rx4v3ybks7EWiN01FHAe
				if tNviK5BW4Q37uhf6poPSI0rgHn8>gvUekJrwsDy+gCvIfYA61EbWGT: break
	if E7DfB9Yhb0RHvLlyeC8pPnWG=='menu_item':
		yDs4u9Zc2hAwgCHJTnUxv8GVa1 = XVqfhxver0yUJd3ucMQWgYI1TiR.copy()
		X2cQ5NCPvkMieBW7oASspFjE.sleep(0.05)
		yDs4u9Zc2hAwgCHJTnUxv8GVa1.paste(srGvfVOkgJhzUDZtyK0TB7lb5Nq,(0,0),mask=hGd8i5kYqoPuaf9yV14cge3)
	else: yDs4u9Zc2hAwgCHJTnUxv8GVa1 = hGd8i5kYqoPuaf9yV14cge3
	if iELueYz3J1FmxaW7vc: Hi5cI2hkSaJLZq80wypYC1U = Hi5cI2hkSaJLZq80wypYC1U.decode(df6QpwGxuJVZr)
	try: yDs4u9Zc2hAwgCHJTnUxv8GVa1.save(Hi5cI2hkSaJLZq80wypYC1U)
	except UnicodeError:
		if iELueYz3J1FmxaW7vc:
			Hi5cI2hkSaJLZq80wypYC1U = Hi5cI2hkSaJLZq80wypYC1U.encode(df6QpwGxuJVZr)
			yDs4u9Zc2hAwgCHJTnUxv8GVa1.save(Hi5cI2hkSaJLZq80wypYC1U)
	return gYTxQJDfmECS18
def bbwia8CpFfq9QOJcdz1st(loPiEp9kCMh1A6H52q0XVv4,MpP3ugSKVmJrB0f47,ssGEgDMmxkVTi,isn9KJFaIMbPYSZ6mG72tCwRV0LBr,ccNxYIo7XtpP,Bi6ljqW4pnFK3NS0kYmJLgx1Uhursc):
	wtXE0BAdIQYmzahf8Sqvxcby,mEF4kqVjP5wMi0Q6,E7UTnBkWSoMt9NeVp = iiy37aKq0pCEIOwfcTh61xb4U,0,15000
	ssGEgDMmxkVTi = ssGEgDMmxkVTi.replace('[COLOR ','[COLOR:::')
	Vjf8M5ERFc = ccNxYIo7XtpP-isn9KJFaIMbPYSZ6mG72tCwRV0LBr*2
	for SkAqni8Du6wK in ssGEgDMmxkVTi.splitlines():
		mEF4kqVjP5wMi0Q6 += Bi6ljqW4pnFK3NS0kYmJLgx1Uhursc
		DpBZUnzxKkaHOvI9CFhQy1gqGE,xNkKv7f1lB8ESR2jmbV = 0,iiy37aKq0pCEIOwfcTh61xb4U
		for MJuaOYAvsgHnPXp42V5bKLdB1jmEUy in SkAqni8Du6wK.split(iFBmE2MUIpSu34wsd7Rf6z):
			myx5jYvbN3C10OeIoBlEu9 = Hdkb25KVscmBWAXnh(iFBmE2MUIpSu34wsd7Rf6z+MJuaOYAvsgHnPXp42V5bKLdB1jmEUy)
			pc8P3VS70tTgFsiwNHxvOWqmz6ah,aoR7pZiAYOVhq8W = loPiEp9kCMh1A6H52q0XVv4.textsize(myx5jYvbN3C10OeIoBlEu9,font=MpP3ugSKVmJrB0f47)
			if DpBZUnzxKkaHOvI9CFhQy1gqGE+pc8P3VS70tTgFsiwNHxvOWqmz6ah<Vjf8M5ERFc:
				if not xNkKv7f1lB8ESR2jmbV: xNkKv7f1lB8ESR2jmbV += MJuaOYAvsgHnPXp42V5bKLdB1jmEUy
				else: xNkKv7f1lB8ESR2jmbV += iFBmE2MUIpSu34wsd7Rf6z+MJuaOYAvsgHnPXp42V5bKLdB1jmEUy
				DpBZUnzxKkaHOvI9CFhQy1gqGE += pc8P3VS70tTgFsiwNHxvOWqmz6ah
			else:
				if pc8P3VS70tTgFsiwNHxvOWqmz6ah<Vjf8M5ERFc:
					xNkKv7f1lB8ESR2jmbV += '\n '+MJuaOYAvsgHnPXp42V5bKLdB1jmEUy
					mEF4kqVjP5wMi0Q6 += Bi6ljqW4pnFK3NS0kYmJLgx1Uhursc
					DpBZUnzxKkaHOvI9CFhQy1gqGE = pc8P3VS70tTgFsiwNHxvOWqmz6ah
				else:
					while pc8P3VS70tTgFsiwNHxvOWqmz6ah>Vjf8M5ERFc:
						for mi7Q1WRhZUJF3GOczo in range(1,len(iFBmE2MUIpSu34wsd7Rf6z+MJuaOYAvsgHnPXp42V5bKLdB1jmEUy),1):
							TTjJKHnwstOdeDPUV3fxucMoNgCW1a = iFBmE2MUIpSu34wsd7Rf6z+MJuaOYAvsgHnPXp42V5bKLdB1jmEUy[:mi7Q1WRhZUJF3GOczo]
							wJOoBMkZN1g = MJuaOYAvsgHnPXp42V5bKLdB1jmEUy[mi7Q1WRhZUJF3GOczo:]
							Z3G5DvzwT4pJX90dlcR = Hdkb25KVscmBWAXnh(TTjJKHnwstOdeDPUV3fxucMoNgCW1a)
							yP5XG3q10MFVheZEzmuD8g6UjiTn,AKe7rltvCTqu641Fx2IpPoJ = loPiEp9kCMh1A6H52q0XVv4.textsize(Z3G5DvzwT4pJX90dlcR,font=MpP3ugSKVmJrB0f47)
							if DpBZUnzxKkaHOvI9CFhQy1gqGE+yP5XG3q10MFVheZEzmuD8g6UjiTn>Vjf8M5ERFc:
								lm1bRDBhj7G4EyXZaYT = pc8P3VS70tTgFsiwNHxvOWqmz6ah-yP5XG3q10MFVheZEzmuD8g6UjiTn
								xNkKv7f1lB8ESR2jmbV += TTjJKHnwstOdeDPUV3fxucMoNgCW1a+OTlVEGYPSxsNaBdXUucqA3
								mEF4kqVjP5wMi0Q6 += Bi6ljqW4pnFK3NS0kYmJLgx1Uhursc
								pc8P3VS70tTgFsiwNHxvOWqmz6ah = lm1bRDBhj7G4EyXZaYT
								if lm1bRDBhj7G4EyXZaYT>Vjf8M5ERFc:
									DpBZUnzxKkaHOvI9CFhQy1gqGE = 0
									MJuaOYAvsgHnPXp42V5bKLdB1jmEUy = wJOoBMkZN1g
								else:
									DpBZUnzxKkaHOvI9CFhQy1gqGE = lm1bRDBhj7G4EyXZaYT
									xNkKv7f1lB8ESR2jmbV += wJOoBMkZN1g
								break
				if mEF4kqVjP5wMi0Q6>E7UTnBkWSoMt9NeVp: break
		wtXE0BAdIQYmzahf8Sqvxcby += OTlVEGYPSxsNaBdXUucqA3+xNkKv7f1lB8ESR2jmbV
		if mEF4kqVjP5wMi0Q6>E7UTnBkWSoMt9NeVp: break
	wtXE0BAdIQYmzahf8Sqvxcby = wtXE0BAdIQYmzahf8Sqvxcby[1:]
	wtXE0BAdIQYmzahf8Sqvxcby = wtXE0BAdIQYmzahf8Sqvxcby.replace('[COLOR:::','[COLOR ')
	return wtXE0BAdIQYmzahf8Sqvxcby
def Hdkb25KVscmBWAXnh(MJuaOYAvsgHnPXp42V5bKLdB1jmEUy):
	if '[' in MJuaOYAvsgHnPXp42V5bKLdB1jmEUy and ']' in MJuaOYAvsgHnPXp42V5bKLdB1jmEUy:
		Z82GI0hlNowk9cmBM6z = [YoQW601K4fMJcsreDnGVE5wUZIy7,'[/RTL]','[/LEFT]','[/RIGHT]','[/CENTER]','[RTL]','[LEFT]','[RIGHT]','[CENTER]']
		QChmySfOYA5sGVcHBaJX7jI = dEyT9xhGjolYzLCH7460w3.findall('\[COLOR .*?\]',MJuaOYAvsgHnPXp42V5bKLdB1jmEUy,dEyT9xhGjolYzLCH7460w3.DOTALL)
		PBIT3fKkujoSA7Xqxtlg6UyVm9 = dEyT9xhGjolYzLCH7460w3.findall('\[COLOR:::.*?\]',MJuaOYAvsgHnPXp42V5bKLdB1jmEUy,dEyT9xhGjolYzLCH7460w3.DOTALL)
		yyHbIr8RFkQ = Z82GI0hlNowk9cmBM6z+QChmySfOYA5sGVcHBaJX7jI+PBIT3fKkujoSA7Xqxtlg6UyVm9
		for GVrkcyxHFuS in yyHbIr8RFkQ: MJuaOYAvsgHnPXp42V5bKLdB1jmEUy = MJuaOYAvsgHnPXp42V5bKLdB1jmEUy.replace(GVrkcyxHFuS,iiy37aKq0pCEIOwfcTh61xb4U)
	return MJuaOYAvsgHnPXp42V5bKLdB1jmEUy
def nwhYl94ZQuVD(U94JwhRgpXCOe5):
	U94JwhRgpXCOe5 = U94JwhRgpXCOe5.replace(OTlVEGYPSxsNaBdXUucqA3,'_sss__newline_')
	U94JwhRgpXCOe5 = U94JwhRgpXCOe5.replace('[RTL]','_sss__linertl_')
	U94JwhRgpXCOe5 = U94JwhRgpXCOe5.replace('[LEFT]','_sss__lineleft_')
	U94JwhRgpXCOe5 = U94JwhRgpXCOe5.replace('[RIGHT]','_sss__lineright_')
	U94JwhRgpXCOe5 = U94JwhRgpXCOe5.replace('[CENTER]','_sss__linecenter_')
	U94JwhRgpXCOe5 = U94JwhRgpXCOe5.replace(YoQW601K4fMJcsreDnGVE5wUZIy7,'_sss__endcolor_')
	QQqm1wV3A4GgIJEu0 = dEyT9xhGjolYzLCH7460w3.findall('\[COLOR (.*?)\]',U94JwhRgpXCOe5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	for Flgdw0Y8LQKpTy in QQqm1wV3A4GgIJEu0: U94JwhRgpXCOe5 = U94JwhRgpXCOe5.replace('[COLOR '+Flgdw0Y8LQKpTy+']','_sss__newcolor'+Flgdw0Y8LQKpTy+'_')
	return U94JwhRgpXCOe5
def mkT7KMxSV1PvEr5(GqfWMs62rplPOn3uImACaUV,JJwnocyLUxHI2jlKF4Y=iiy37aKq0pCEIOwfcTh61xb4U):
	if not JJwnocyLUxHI2jlKF4Y: JJwnocyLUxHI2jlKF4Y = WwMgozBIC32n9d0tyfp.getInfoLabel('ListItem.Label')
	JJwnocyLUxHI2jlKF4Y = JJwnocyLUxHI2jlKF4Y.replace(hnVQObwUcR207fC,iFBmE2MUIpSu34wsd7Rf6z).replace(jHLaUg49SXC6JyTM,iFBmE2MUIpSu34wsd7Rf6z).replace(Wc5GekRC0HQLz7,iFBmE2MUIpSu34wsd7Rf6z).strip(iFBmE2MUIpSu34wsd7Rf6z)
	if GqfWMs62rplPOn3uImACaUV: JJwnocyLUxHI2jlKF4Y = JJwnocyLUxHI2jlKF4Y.replace('[COLOR ',iiy37aKq0pCEIOwfcTh61xb4U).replace(']',iiy37aKq0pCEIOwfcTh61xb4U)
	else: JJwnocyLUxHI2jlKF4Y = JJwnocyLUxHI2jlKF4Y.replace(aqEsMBckT2bunGHfl48Wip,iiy37aKq0pCEIOwfcTh61xb4U).replace(PSwfZcdRYhpl5Igqz8xOEk67,iiy37aKq0pCEIOwfcTh61xb4U).replace(MJSF94CaiBj2,iiy37aKq0pCEIOwfcTh61xb4U).replace(dis4E096qw,iiy37aKq0pCEIOwfcTh61xb4U)
	JJwnocyLUxHI2jlKF4Y = JJwnocyLUxHI2jlKF4Y.replace(OTlVEGYPSxsNaBdXUucqA3,iiy37aKq0pCEIOwfcTh61xb4U).replace(Mge0HhFk9Ic6sm5VR,iiy37aKq0pCEIOwfcTh61xb4U).replace(YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U)
	JJwnocyLUxHI2jlKF4Y = JJwnocyLUxHI2jlKF4Y.replace(DApVioTIRMGX,iiy37aKq0pCEIOwfcTh61xb4U).replace(Ds9inqGKb5frAd2CzmWke61aMQ,iiy37aKq0pCEIOwfcTh61xb4U)
	UpcLBl7ijrfhVy = dEyT9xhGjolYzLCH7460w3.findall('\d\d:\d\d ',JJwnocyLUxHI2jlKF4Y,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UpcLBl7ijrfhVy: JJwnocyLUxHI2jlKF4Y = JJwnocyLUxHI2jlKF4Y.split(UpcLBl7ijrfhVy[0],1)[1]
	if not JJwnocyLUxHI2jlKF4Y: JJwnocyLUxHI2jlKF4Y = 'Main Menu'
	return JJwnocyLUxHI2jlKF4Y
def VzC7H3ty4U8GkD(NTxA09tqrhpXbSfvCk5K):
	Hk3K4hlfCUFIv65ujn = iiy37aKq0pCEIOwfcTh61xb4U.join(mi7Q1WRhZUJF3GOczo for mi7Q1WRhZUJF3GOczo in NTxA09tqrhpXbSfvCk5K if mi7Q1WRhZUJF3GOczo not in '\/":*?<>|'+IrGVXjLSAaDgOm4lE80Q)
	return Hk3K4hlfCUFIv65ujn
def zJ1OjtAFPhK85MY2p7ZmVBowxgS(F50ngOyjSvAcVRtdafJsiBkP9Yx):
	ZFnUCft13ez82KJkbQgvhIl = dEyT9xhGjolYzLCH7460w3.findall("adilbo_HTML_encoder(.*?)/g.....(.*?)\)",F50ngOyjSvAcVRtdafJsiBkP9Yx,dEyT9xhGjolYzLCH7460w3.S)
	if ZFnUCft13ez82KJkbQgvhIl:
		qRzCLjlfGIha,DDAwC4kT7Lgzu = ZFnUCft13ez82KJkbQgvhIl[0]
		qRzCLjlfGIha = dEyT9xhGjolYzLCH7460w3.findall("=[\r\n\s\t]+'(.*?)';", qRzCLjlfGIha, dEyT9xhGjolYzLCH7460w3.S)[0]
		if qRzCLjlfGIha and DDAwC4kT7Lgzu:
			AACSiGkpgelTasNO4hn = qRzCLjlfGIha.replace("'",iiy37aKq0pCEIOwfcTh61xb4U).replace("+",iiy37aKq0pCEIOwfcTh61xb4U).replace("\n",iiy37aKq0pCEIOwfcTh61xb4U).replace("\r",iiy37aKq0pCEIOwfcTh61xb4U)
			Xh0Fr9lPKg3Za87mqVci1NfYQUOT = AACSiGkpgelTasNO4hn.split('.')
			F50ngOyjSvAcVRtdafJsiBkP9Yx = iiy37aKq0pCEIOwfcTh61xb4U
			for bf3VOPYN9aohGQAzeEFrmWDg5qB in Xh0Fr9lPKg3Za87mqVci1NfYQUOT:
				RpcKiYwWQ4PuEV0 = UodGe76Lu2IHTYPxBhjk1RpcaqrM.b64decode(bf3VOPYN9aohGQAzeEFrmWDg5qB+'==').decode(df6QpwGxuJVZr)
				nGOhdlHIZTEX9ibPVa4SKJ = dEyT9xhGjolYzLCH7460w3.findall('\d+', RpcKiYwWQ4PuEV0, dEyT9xhGjolYzLCH7460w3.S)
				if nGOhdlHIZTEX9ibPVa4SKJ:
					VJhutoFcPBrMDfg5EZ0y = int(nGOhdlHIZTEX9ibPVa4SKJ[0])
					VJhutoFcPBrMDfg5EZ0y += int(DDAwC4kT7Lgzu)
					F50ngOyjSvAcVRtdafJsiBkP9Yx = F50ngOyjSvAcVRtdafJsiBkP9Yx + chr(VJhutoFcPBrMDfg5EZ0y)
			if J1MoiYc7ZwzKS: F50ngOyjSvAcVRtdafJsiBkP9Yx = F50ngOyjSvAcVRtdafJsiBkP9Yx.encode('iso-8859-1').decode(df6QpwGxuJVZr)
	return F50ngOyjSvAcVRtdafJsiBkP9Yx
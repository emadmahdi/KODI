# -*- coding: utf-8 -*-
from braVAkwfBN import *
sQU2GnRoMwLK8CBdfzmNr4jXyO = 'GLOBALSEARCH'
ooQEi5O6tYsGVF8LU0TC3hgMeflBwH = '_GLS_'
def sHVM8YchrDjZAJ7(Cpf9s3c0Zngj7XE,kMqh74TPvpSDar59xQUjAyVlHes,U94JwhRgpXCOe5,zLEP9N4BOsVrXa):
	if   Cpf9s3c0Zngj7XE==540: EA7FzO1kMZGQXDd2giB0cwLom = jihuS9LVAvTrClPapMbUEwfn8XN()
	elif Cpf9s3c0Zngj7XE==541: EA7FzO1kMZGQXDd2giB0cwLom = z2uNLQTy5VPnqZJDCt3m6elMj8gWHd(U94JwhRgpXCOe5)
	elif Cpf9s3c0Zngj7XE==542: EA7FzO1kMZGQXDd2giB0cwLom = lHMrpxQJBIz3kwjsvOKd1P(U94JwhRgpXCOe5,kMqh74TPvpSDar59xQUjAyVlHes,zLEP9N4BOsVrXa)
	elif Cpf9s3c0Zngj7XE==543: EA7FzO1kMZGQXDd2giB0cwLom = JFOEeDi3whsykPNYWzv()
	elif Cpf9s3c0Zngj7XE==548: EA7FzO1kMZGQXDd2giB0cwLom = rZv31ayueijsOwGTg7VHSom0MX(kMqh74TPvpSDar59xQUjAyVlHes,U94JwhRgpXCOe5)
	elif Cpf9s3c0Zngj7XE==549: EA7FzO1kMZGQXDd2giB0cwLom = mUhJtHB9nw(U94JwhRgpXCOe5)
	else: EA7FzO1kMZGQXDd2giB0cwLom = False
	return EA7FzO1kMZGQXDd2giB0cwLom
def jihuS9LVAvTrClPapMbUEwfn8XN():
	bP6z3OSLp7va('folder','بحث جديد لجميع المواقع',iiy37aKq0pCEIOwfcTh61xb4U,549)
	bP6z3OSLp7va('link','كيف يعمل بحث جميع المواقع','',543)
	bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+'==== كلمات البحث المخزنة ===='+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	AGD5vOKL04tkUrn7aHYfbugsmje2ql = QKzCiBOWZus1nSv(PdkZHNBlpg2b7DmX6qRiyVa,'dict','GLOBALSEARCH_SPLITTED_ALL')
	if AGD5vOKL04tkUrn7aHYfbugsmje2ql:
		AGD5vOKL04tkUrn7aHYfbugsmje2ql = AGD5vOKL04tkUrn7aHYfbugsmje2ql['__SEQUENCED_COLUMNS__']
		for XoJdWFj2HL14SIhExcU in reversed(AGD5vOKL04tkUrn7aHYfbugsmje2ql):
			bP6z3OSLp7va('folder',XoJdWFj2HL14SIhExcU,iiy37aKq0pCEIOwfcTh61xb4U,549,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,XoJdWFj2HL14SIhExcU)
	return
def mUhJtHB9nw(XoJdWFj2HL14SIhExcU):
	if not XoJdWFj2HL14SIhExcU:
		XoJdWFj2HL14SIhExcU = TTBf6S08q1NKXd5v9wa()
		if not XoJdWFj2HL14SIhExcU: return
		XoJdWFj2HL14SIhExcU = XoJdWFj2HL14SIhExcU.lower()
	aKQTNif8Yw4s = XoJdWFj2HL14SIhExcU.replace(ooQEi5O6tYsGVF8LU0TC3hgMeflBwH,iiy37aKq0pCEIOwfcTh61xb4U)
	RJOu38mxiIjWA4qcP0EG6lUnabT(aKQTNif8Yw4s,'_ALL',True)
	bP6z3OSLp7va('link','بحث جماعي للمواقع - '+aKQTNif8Yw4s,'search_sites_all',542,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,aKQTNif8Yw4s)
	bP6z3OSLp7va('folder','بحث منفرد للمواقع - '+aKQTNif8Yw4s,iiy37aKq0pCEIOwfcTh61xb4U,541,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,aKQTNif8Yw4s)
	bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+'===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	bP6z3OSLp7va('folder','نتائج البحث مفصلة - '+aKQTNif8Yw4s,'opened_sites_all',542,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,aKQTNif8Yw4s)
	bP6z3OSLp7va('folder','نتائج البحث مقسمة - '+aKQTNif8Yw4s,'listed_sites_all',542,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,aKQTNif8Yw4s)
	return
def RJOu38mxiIjWA4qcP0EG6lUnabT(ANqaznULi2CmdT5j,ir8ygcFdPS12,LwFPTkWbr09uaQfY2xZo83tidm54):
	if ir8ygcFdPS12=='_ALL': AQG5otHIJ09TrqdvpEcu7wa4U = '_GLS_'
	elif ir8ygcFdPS12=='_GOOGLE': AQG5otHIJ09TrqdvpEcu7wa4U = '_GOS_'
	OEXaeLoT2vhGWR0Jfm18tbcBywCxp = QKzCiBOWZus1nSv(PdkZHNBlpg2b7DmX6qRiyVa,'list','GLOBALSEARCH_SPLITTED'+ir8ygcFdPS12,ANqaznULi2CmdT5j)
	CyNGBo8vLfDrSal6KXejdzx23E4tq = QKzCiBOWZus1nSv(PdkZHNBlpg2b7DmX6qRiyVa,'list','GLOBALSEARCH_SPLITTED'+ir8ygcFdPS12,AQG5otHIJ09TrqdvpEcu7wa4U+ANqaznULi2CmdT5j)
	Bcxq3nkvTU9iM(PdkZHNBlpg2b7DmX6qRiyVa,'GLOBALSEARCH_SPLITTED'+ir8ygcFdPS12,ANqaznULi2CmdT5j)
	Bcxq3nkvTU9iM(PdkZHNBlpg2b7DmX6qRiyVa,'GLOBALSEARCH_SPLITTED'+ir8ygcFdPS12,AQG5otHIJ09TrqdvpEcu7wa4U+ANqaznULi2CmdT5j)
	CqMALsJY0GmZxW3tB9adgo8SuhQ = OEXaeLoT2vhGWR0Jfm18tbcBywCxp+CyNGBo8vLfDrSal6KXejdzx23E4tq
	if CqMALsJY0GmZxW3tB9adgo8SuhQ and LwFPTkWbr09uaQfY2xZo83tidm54: ANqaznULi2CmdT5j = AQG5otHIJ09TrqdvpEcu7wa4U+ANqaznULi2CmdT5j
	YMQXP2BGeK86CEb(PdkZHNBlpg2b7DmX6qRiyVa,'GLOBALSEARCH_SPLITTED'+ir8ygcFdPS12,ANqaznULi2CmdT5j,CqMALsJY0GmZxW3tB9adgo8SuhQ,ea84RQXsdLY9GIVjSzb)
	return
def NjAfaewzlX(ir8ygcFdPS12):
	U17QqF2gkI46 = A1AXKupEOfz(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'رسالة من المبرمج','هل تريد مسح جميع كلمات البحث المخزنة في البرنامج ؟!!')
	if U17QqF2gkI46!=1: return
	Bcxq3nkvTU9iM(PdkZHNBlpg2b7DmX6qRiyVa,'GLOBALSEARCH_SPLITTED'+ir8ygcFdPS12)
	Bcxq3nkvTU9iM(PdkZHNBlpg2b7DmX6qRiyVa,'GLOBALSEARCH_DETAILED'+ir8ygcFdPS12)
	Bcxq3nkvTU9iM(PdkZHNBlpg2b7DmX6qRiyVa,'GLOBALSEARCH_DIVIDED'+ir8ygcFdPS12)
	if ir8ygcFdPS12=='_GOOGLE': Bcxq3nkvTU9iM(PdkZHNBlpg2b7DmX6qRiyVa,'GOOGLESEARCH_RESULTS')
	bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'رسالة من المبرمج','تم بنجاح مسح جميع كلمات البحث المخزنة في البرنامج')
	return
def lHMrpxQJBIz3kwjsvOKd1P(xP7Y24rlOy5zLh,wgkhczjbQKpa,kovBAzg3fVtiKb=iiy37aKq0pCEIOwfcTh61xb4U,uryBfhzpOw8GFZqo=uXtbUqcMdTFICQjGY7a63em,fHJZDohCVplWq4OgsB6={}):
	Tl0ShdQEA7xKY8vRb9HzZaBcL4,XWZYo3n5hUAc,y0vF6C3K1djZs9JwcIU5uWnx,EH9WYjkU67oSD,cL5pBywjAPY40 = [],{},{},{},{}
	if '_all' in wgkhczjbQKpa: ir8ygcFdPS12,Vl07OYWcxeMQwgpFAbJnLhRuBf2d6K,AQG5otHIJ09TrqdvpEcu7wa4U = '_ALL','_all','_GLS_'
	elif '_google' in wgkhczjbQKpa: ir8ygcFdPS12,Vl07OYWcxeMQwgpFAbJnLhRuBf2d6K,AQG5otHIJ09TrqdvpEcu7wa4U = '_GOOGLE','_google','_GOS_'
	if wgkhczjbQKpa in ['listed_sites'+Vl07OYWcxeMQwgpFAbJnLhRuBf2d6K,'opened_sites'+Vl07OYWcxeMQwgpFAbJnLhRuBf2d6K,'closed_sites'+Vl07OYWcxeMQwgpFAbJnLhRuBf2d6K]:
		if wgkhczjbQKpa=='listed_sites'+Vl07OYWcxeMQwgpFAbJnLhRuBf2d6K: Tl0ShdQEA7xKY8vRb9HzZaBcL4 = QKzCiBOWZus1nSv(PdkZHNBlpg2b7DmX6qRiyVa,'list','GLOBALSEARCH_SPLITTED'+ir8ygcFdPS12,AQG5otHIJ09TrqdvpEcu7wa4U+xP7Y24rlOy5zLh)
		elif wgkhczjbQKpa=='opened_sites'+Vl07OYWcxeMQwgpFAbJnLhRuBf2d6K: Tl0ShdQEA7xKY8vRb9HzZaBcL4 = QKzCiBOWZus1nSv(PdkZHNBlpg2b7DmX6qRiyVa,'list','GLOBALSEARCH_DETAILED'+ir8ygcFdPS12,xP7Y24rlOy5zLh)
		elif wgkhczjbQKpa=='closed_sites'+Vl07OYWcxeMQwgpFAbJnLhRuBf2d6K: Tl0ShdQEA7xKY8vRb9HzZaBcL4 = QKzCiBOWZus1nSv(PdkZHNBlpg2b7DmX6qRiyVa,'list','GLOBALSEARCH_DIVIDED'+ir8ygcFdPS12,(kovBAzg3fVtiKb,xP7Y24rlOy5zLh))
	if not Tl0ShdQEA7xKY8vRb9HzZaBcL4:
		ngZh3MbtFxsQAjGvyUJ67VN = 'هذا البحث غير موجود في كاش البرنامج \n\n\n'
		E8ZibMeyGK = 'هل تريد الآن البحث في جميع المواقع عن \n "'+aqEsMBckT2bunGHfl48Wip+iFBmE2MUIpSu34wsd7Rf6z+xP7Y24rlOy5zLh+iFBmE2MUIpSu34wsd7Rf6z+YoQW601K4fMJcsreDnGVE5wUZIy7+'" \n علما أن هذا البحث قد يحتاج بعض الوقت'
		if wgkhczjbQKpa=='search_sites'+Vl07OYWcxeMQwgpFAbJnLhRuBf2d6K: aZtYlicqMKUFPkBCX2AONHwJ4 = E8ZibMeyGK
		else: aZtYlicqMKUFPkBCX2AONHwJ4 = ngZh3MbtFxsQAjGvyUJ67VN+E8ZibMeyGK
		U17QqF2gkI46 = A1AXKupEOfz(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'رسالة من المبرمج',aZtYlicqMKUFPkBCX2AONHwJ4)
		if U17QqF2gkI46!=1: return
		qI2s0ZN7uj(False,False,False)
		WKquk5EaNr4RzVf(q1rohYuwnfpVZUa98L2CtQzmAcB,IIZ4e82HBP0oTmtOgaWY7hsMz(sQU2GnRoMwLK8CBdfzmNr4jXyO)+'   Search For: [ '+xP7Y24rlOy5zLh+' ]')
		JGYoxr8tFIia2cEXAO0h = 1
		for ekEOd3mqAThaBDUoIrntuGRjYW in uryBfhzpOw8GFZqo:
			CYSxZe4G5OL2EQAchPpByn3Xw8f0Wt = fHJZDohCVplWq4OgsB6[ekEOd3mqAThaBDUoIrntuGRjYW] if fHJZDohCVplWq4OgsB6 else xP7Y24rlOy5zLh
			try: ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,lEgmdMxnfsXj,ZebIE2aQgrGn = GGkFKuWvn5q1wVmldgXz(ekEOd3mqAThaBDUoIrntuGRjYW)
			except: continue
			XWZYo3n5hUAc[ekEOd3mqAThaBDUoIrntuGRjYW] = []
			FG615TlEM78tKb = '_NODIALOGS_'
			if '-' in ekEOd3mqAThaBDUoIrntuGRjYW: FG615TlEM78tKb = FG615TlEM78tKb+'_REMEMBERRESULTS__'+ekEOd3mqAThaBDUoIrntuGRjYW+'_'
			if JGYoxr8tFIia2cEXAO0h:
				X2cQ5NCPvkMieBW7oASspFjE.sleep(0.75)
				cL5pBywjAPY40[ekEOd3mqAThaBDUoIrntuGRjYW] = EEehSFDLdpKBR3W1ga9PxrV.Thread(target=lEgmdMxnfsXj,args=(CYSxZe4G5OL2EQAchPpByn3Xw8f0Wt+FG615TlEM78tKb,))
				cL5pBywjAPY40[ekEOd3mqAThaBDUoIrntuGRjYW].start()
			else: lEgmdMxnfsXj(CYSxZe4G5OL2EQAchPpByn3Xw8f0Wt+FG615TlEM78tKb)
			YYkhEn5xTXLUevzCVNB16mR(aanoXVLTZqsIwitBdY0kcJS794FDg(ekEOd3mqAThaBDUoIrntuGRjYW),iiy37aKq0pCEIOwfcTh61xb4U,X2cQ5NCPvkMieBW7oASspFjE=1000)
		if JGYoxr8tFIia2cEXAO0h:
			X2cQ5NCPvkMieBW7oASspFjE.sleep(2)
			for ekEOd3mqAThaBDUoIrntuGRjYW in uryBfhzpOw8GFZqo: cL5pBywjAPY40[ekEOd3mqAThaBDUoIrntuGRjYW].join(10)
			X2cQ5NCPvkMieBW7oASspFjE.sleep(2)
		for ekEOd3mqAThaBDUoIrntuGRjYW in uryBfhzpOw8GFZqo:
			try: ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,lEgmdMxnfsXj,ZebIE2aQgrGn = GGkFKuWvn5q1wVmldgXz(ekEOd3mqAThaBDUoIrntuGRjYW)
			except: continue
			for QL43gdorzFVS9DkUfbvB1X in g6ghGH4aBEYkTl3vbJZ:
				synCYOiMR789twmfr,JJwnocyLUxHI2jlKF4Y,kMqh74TPvpSDar59xQUjAyVlHes,Cpf9s3c0Zngj7XE,L95mrowGgdsD,zLEP9N4BOsVrXa,U94JwhRgpXCOe5,EALyNnv1Db4cUd8sQoZX2pmBVt7kM,XC10geOnQtwrs = QL43gdorzFVS9DkUfbvB1X
				if ZebIE2aQgrGn in JJwnocyLUxHI2jlKF4Y:
					if 'IPTV-' in ekEOd3mqAThaBDUoIrntuGRjYW and (239>=Cpf9s3c0Zngj7XE>=230 or 289>=Cpf9s3c0Zngj7XE>=280):
						if QL43gdorzFVS9DkUfbvB1X in XWZYo3n5hUAc['IPTV-LIVE']: continue
						if QL43gdorzFVS9DkUfbvB1X in XWZYo3n5hUAc['IPTV-MOVIES']: continue
						if QL43gdorzFVS9DkUfbvB1X in XWZYo3n5hUAc['IPTV-SERIES']: continue
						if 'صفحة' not in JJwnocyLUxHI2jlKF4Y:
							if   synCYOiMR789twmfr=='live': ekEOd3mqAThaBDUoIrntuGRjYW = 'IPTV-LIVE'
							elif synCYOiMR789twmfr=='video': ekEOd3mqAThaBDUoIrntuGRjYW = 'IPTV-MOVIES'
							elif synCYOiMR789twmfr=='folder': ekEOd3mqAThaBDUoIrntuGRjYW = 'IPTV-SERIES'
						else:
							if   'LIVE' in kMqh74TPvpSDar59xQUjAyVlHes: ekEOd3mqAThaBDUoIrntuGRjYW = 'IPTV-LIVE'
							elif 'MOVIES' in kMqh74TPvpSDar59xQUjAyVlHes: ekEOd3mqAThaBDUoIrntuGRjYW = 'IPTV-MOVIES'
							elif 'SERIES' in kMqh74TPvpSDar59xQUjAyVlHes: ekEOd3mqAThaBDUoIrntuGRjYW = 'IPTV-SERIES'
					elif 'M3U-' in ekEOd3mqAThaBDUoIrntuGRjYW and 729>=Cpf9s3c0Zngj7XE>=710:
						if QL43gdorzFVS9DkUfbvB1X in XWZYo3n5hUAc['M3U-LIVE']: continue
						if QL43gdorzFVS9DkUfbvB1X in XWZYo3n5hUAc['M3U-MOVIES']: continue
						if QL43gdorzFVS9DkUfbvB1X in XWZYo3n5hUAc['M3U-SERIES']: continue
						if 'صفحة' not in JJwnocyLUxHI2jlKF4Y:
							if   synCYOiMR789twmfr=='live': ekEOd3mqAThaBDUoIrntuGRjYW = 'M3U-LIVE'
							elif synCYOiMR789twmfr=='video': ekEOd3mqAThaBDUoIrntuGRjYW = 'M3U-MOVIES'
							elif synCYOiMR789twmfr=='folder': ekEOd3mqAThaBDUoIrntuGRjYW = 'M3U-SERIES'
						else:
							if   'LIVE' in kMqh74TPvpSDar59xQUjAyVlHes: ekEOd3mqAThaBDUoIrntuGRjYW = 'M3U-LIVE'
							elif 'MOVIES' in kMqh74TPvpSDar59xQUjAyVlHes: ekEOd3mqAThaBDUoIrntuGRjYW = 'M3U-MOVIES'
							elif 'SERIES' in kMqh74TPvpSDar59xQUjAyVlHes: ekEOd3mqAThaBDUoIrntuGRjYW = 'M3U-SERIES'
					elif 'YOUTUBE-' in ekEOd3mqAThaBDUoIrntuGRjYW and 149>=Cpf9s3c0Zngj7XE>=140:
						if QL43gdorzFVS9DkUfbvB1X in XWZYo3n5hUAc['YOUTUBE-CHANNELS']: continue
						if QL43gdorzFVS9DkUfbvB1X in XWZYo3n5hUAc['YOUTUBE-PLAYLISTS']: continue
						if QL43gdorzFVS9DkUfbvB1X in XWZYo3n5hUAc['YOUTUBE-VIDEOS']: continue
						if 'صفحة أخرى' in JJwnocyLUxHI2jlKF4Y or ':: ' in JJwnocyLUxHI2jlKF4Y:
							continue
						else:
							if   Cpf9s3c0Zngj7XE==144 and 'USER' in JJwnocyLUxHI2jlKF4Y: ekEOd3mqAThaBDUoIrntuGRjYW = 'YOUTUBE-CHANNELS'
							elif Cpf9s3c0Zngj7XE==144 and 'CHNL' in JJwnocyLUxHI2jlKF4Y: ekEOd3mqAThaBDUoIrntuGRjYW = 'YOUTUBE-CHANNELS'
							elif Cpf9s3c0Zngj7XE==144 and 'LIST' in JJwnocyLUxHI2jlKF4Y: ekEOd3mqAThaBDUoIrntuGRjYW = 'YOUTUBE-PLAYLISTS'
							elif Cpf9s3c0Zngj7XE==143: ekEOd3mqAThaBDUoIrntuGRjYW = 'YOUTUBE-VIDEOS'
							else: continue
					elif 'DAILYMOTION-' in ekEOd3mqAThaBDUoIrntuGRjYW and 419>=Cpf9s3c0Zngj7XE>=400:
						if QL43gdorzFVS9DkUfbvB1X in XWZYo3n5hUAc['DAILYMOTION-PLAYLISTS']: continue
						if QL43gdorzFVS9DkUfbvB1X in XWZYo3n5hUAc['DAILYMOTION-CHANNELS']: continue
						if QL43gdorzFVS9DkUfbvB1X in XWZYo3n5hUAc['DAILYMOTION-VIDEOS']: continue
						if QL43gdorzFVS9DkUfbvB1X in XWZYo3n5hUAc['DAILYMOTION-LIVES']: continue
						if QL43gdorzFVS9DkUfbvB1X in XWZYo3n5hUAc['DAILYMOTION-HASHTAGS']: continue
						if   Cpf9s3c0Zngj7XE in [401,405]: ekEOd3mqAThaBDUoIrntuGRjYW = 'DAILYMOTION-PLAYLISTS'
						elif Cpf9s3c0Zngj7XE in [402,406]: ekEOd3mqAThaBDUoIrntuGRjYW = 'DAILYMOTION-CHANNELS'
						elif Cpf9s3c0Zngj7XE in [404]: ekEOd3mqAThaBDUoIrntuGRjYW = 'DAILYMOTION-VIDEOS'
						elif Cpf9s3c0Zngj7XE in [415]: ekEOd3mqAThaBDUoIrntuGRjYW = 'DAILYMOTION-LIVES'
						elif Cpf9s3c0Zngj7XE in [416]: ekEOd3mqAThaBDUoIrntuGRjYW = 'DAILYMOTION-HASHTAGS'
					elif 'PANET-' in ekEOd3mqAThaBDUoIrntuGRjYW and 39>=Cpf9s3c0Zngj7XE>=30:
						if QL43gdorzFVS9DkUfbvB1X in XWZYo3n5hUAc['PANET-SERIES']: continue
						if QL43gdorzFVS9DkUfbvB1X in XWZYo3n5hUAc['PANET-MOVIES']: continue
						if   Cpf9s3c0Zngj7XE in [32,39]: ekEOd3mqAThaBDUoIrntuGRjYW = 'PANET-SERIES'
						elif Cpf9s3c0Zngj7XE in [33,39]: ekEOd3mqAThaBDUoIrntuGRjYW = 'PANET-MOVIES'
					elif 'IFILM-' in ekEOd3mqAThaBDUoIrntuGRjYW and 29>=Cpf9s3c0Zngj7XE>=20:
						if QL43gdorzFVS9DkUfbvB1X in XWZYo3n5hUAc['IFILM-ARABIC']: continue
						if QL43gdorzFVS9DkUfbvB1X in XWZYo3n5hUAc['IFILM-ENGLISH']: continue
						if   '/ar.' in kMqh74TPvpSDar59xQUjAyVlHes: ekEOd3mqAThaBDUoIrntuGRjYW = 'IFILM-ARABIC'
						elif '/en.' in kMqh74TPvpSDar59xQUjAyVlHes: ekEOd3mqAThaBDUoIrntuGRjYW = 'IFILM-ENGLISH'
					XWZYo3n5hUAc[ekEOd3mqAThaBDUoIrntuGRjYW].append(QL43gdorzFVS9DkUfbvB1X)
		for ekEOd3mqAThaBDUoIrntuGRjYW in list(XWZYo3n5hUAc.keys()):
			y0vF6C3K1djZs9JwcIU5uWnx[ekEOd3mqAThaBDUoIrntuGRjYW] = []
			EH9WYjkU67oSD[ekEOd3mqAThaBDUoIrntuGRjYW] = []
			for synCYOiMR789twmfr,JJwnocyLUxHI2jlKF4Y,kMqh74TPvpSDar59xQUjAyVlHes,Cpf9s3c0Zngj7XE,L95mrowGgdsD,zLEP9N4BOsVrXa,U94JwhRgpXCOe5,EALyNnv1Db4cUd8sQoZX2pmBVt7kM,XC10geOnQtwrs in XWZYo3n5hUAc[ekEOd3mqAThaBDUoIrntuGRjYW]:
				QL43gdorzFVS9DkUfbvB1X = (synCYOiMR789twmfr,JJwnocyLUxHI2jlKF4Y,kMqh74TPvpSDar59xQUjAyVlHes,Cpf9s3c0Zngj7XE,L95mrowGgdsD,zLEP9N4BOsVrXa,U94JwhRgpXCOe5,EALyNnv1Db4cUd8sQoZX2pmBVt7kM,XC10geOnQtwrs)
				if 'صفحة' in JJwnocyLUxHI2jlKF4Y and synCYOiMR789twmfr=='folder': EH9WYjkU67oSD[ekEOd3mqAThaBDUoIrntuGRjYW].append(QL43gdorzFVS9DkUfbvB1X)
				else: y0vF6C3K1djZs9JwcIU5uWnx[ekEOd3mqAThaBDUoIrntuGRjYW].append(QL43gdorzFVS9DkUfbvB1X)
		hdgL0AkzQ4cEIapYo8SfBNCHV9J,y2yaVq01fPr8mX = [],[]
		ttFYERwUizgPyOIq91d4WN = list(y0vF6C3K1djZs9JwcIU5uWnx.keys())
		Hlk8VWd5mBwhL6uxE = t624ZFj0bLTEvG1uImXpr7M83oJq(ttFYERwUizgPyOIq91d4WN)
		iVH9Ytw8FknvR6WIupe = []
		for ekEOd3mqAThaBDUoIrntuGRjYW in Hlk8VWd5mBwhL6uxE:
			if 'tuple' in str(type(ekEOd3mqAThaBDUoIrntuGRjYW)):
				iVH9Ytw8FknvR6WIupe = [ekEOd3mqAThaBDUoIrntuGRjYW]
				continue
			if ekEOd3mqAThaBDUoIrntuGRjYW not in uryBfhzpOw8GFZqo: continue
			if y0vF6C3K1djZs9JwcIU5uWnx[ekEOd3mqAThaBDUoIrntuGRjYW]:
				kvE5wLK86W3hXbZde = aanoXVLTZqsIwitBdY0kcJS794FDg(ekEOd3mqAThaBDUoIrntuGRjYW)
				EQyW9qPSj7e = [('link',aqEsMBckT2bunGHfl48Wip+'===== '+kvE5wLK86W3hXbZde+' ====='+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U)]
				if 0: d5CEYJ9bASFT = xP7Y24rlOy5zLh+' - '+'بحث'+iFBmE2MUIpSu34wsd7Rf6z+kvE5wLK86W3hXbZde
				else: d5CEYJ9bASFT = 'بحث'+iFBmE2MUIpSu34wsd7Rf6z+kvE5wLK86W3hXbZde+' - '+xP7Y24rlOy5zLh
				if len(y0vF6C3K1djZs9JwcIU5uWnx[ekEOd3mqAThaBDUoIrntuGRjYW])<8: DRgXxGvhAw9C8U7mj = []
				else:
					ZycLwGW9Pgl3dzmAn2tak = PSwfZcdRYhpl5Igqz8xOEk67+d5CEYJ9bASFT+YoQW601K4fMJcsreDnGVE5wUZIy7
					DRgXxGvhAw9C8U7mj = [('folder',AQG5otHIJ09TrqdvpEcu7wa4U+ZycLwGW9Pgl3dzmAn2tak,'closed_sites'+Vl07OYWcxeMQwgpFAbJnLhRuBf2d6K,542,iiy37aKq0pCEIOwfcTh61xb4U,ekEOd3mqAThaBDUoIrntuGRjYW,xP7Y24rlOy5zLh,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U)]
				nFSUM7QCcbIVet2jZ0pLoRJ8srWf = y0vF6C3K1djZs9JwcIU5uWnx[ekEOd3mqAThaBDUoIrntuGRjYW]+EH9WYjkU67oSD[ekEOd3mqAThaBDUoIrntuGRjYW]
				PEjFlSga2xTtB6RI = iVH9Ytw8FknvR6WIupe+EQyW9qPSj7e+nFSUM7QCcbIVet2jZ0pLoRJ8srWf[:7]+DRgXxGvhAw9C8U7mj
				hdgL0AkzQ4cEIapYo8SfBNCHV9J += PEjFlSga2xTtB6RI
				ial5L3v7KQZW8gsMc = [('folder',AQG5otHIJ09TrqdvpEcu7wa4U+d5CEYJ9bASFT,'closed_sites'+Vl07OYWcxeMQwgpFAbJnLhRuBf2d6K,542,iiy37aKq0pCEIOwfcTh61xb4U,ekEOd3mqAThaBDUoIrntuGRjYW,xP7Y24rlOy5zLh,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U)]
				LsiY3WZE4D1jc75vzBp8SamFb = iVH9Ytw8FknvR6WIupe+ial5L3v7KQZW8gsMc
				y2yaVq01fPr8mX += LsiY3WZE4D1jc75vzBp8SamFb
				YMQXP2BGeK86CEb(PdkZHNBlpg2b7DmX6qRiyVa,'GLOBALSEARCH_DIVIDED'+ir8ygcFdPS12,(ekEOd3mqAThaBDUoIrntuGRjYW,xP7Y24rlOy5zLh),nFSUM7QCcbIVet2jZ0pLoRJ8srWf,ea84RQXsdLY9GIVjSzb)
				iVH9Ytw8FknvR6WIupe = []
		YMQXP2BGeK86CEb(PdkZHNBlpg2b7DmX6qRiyVa,'GLOBALSEARCH_DETAILED'+ir8ygcFdPS12,xP7Y24rlOy5zLh,hdgL0AkzQ4cEIapYo8SfBNCHV9J,ea84RQXsdLY9GIVjSzb)
		Bcxq3nkvTU9iM(PdkZHNBlpg2b7DmX6qRiyVa,'GLOBALSEARCH_SPLITTED'+ir8ygcFdPS12,xP7Y24rlOy5zLh)
		YMQXP2BGeK86CEb(PdkZHNBlpg2b7DmX6qRiyVa,'GLOBALSEARCH_SPLITTED'+ir8ygcFdPS12,AQG5otHIJ09TrqdvpEcu7wa4U+xP7Y24rlOy5zLh,y2yaVq01fPr8mX,ea84RQXsdLY9GIVjSzb)
		bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'رسالة من المبرمج','البحث الجماعي انتهى بنجاح \n\n تم تخزين النتائج في كاش البرنامج لمدة ثلاثين يوم لكي تستطيع العودة إليها بدون عمل بحث جديد')
		Tl0ShdQEA7xKY8vRb9HzZaBcL4 = y2yaVq01fPr8mX if wgkhczjbQKpa=='listed_sites'+Vl07OYWcxeMQwgpFAbJnLhRuBf2d6K and y2yaVq01fPr8mX else hdgL0AkzQ4cEIapYo8SfBNCHV9J
	if wgkhczjbQKpa in ['listed_sites'+Vl07OYWcxeMQwgpFAbJnLhRuBf2d6K,'opened_sites'+Vl07OYWcxeMQwgpFAbJnLhRuBf2d6K,'closed_sites'+Vl07OYWcxeMQwgpFAbJnLhRuBf2d6K]:
		for synCYOiMR789twmfr,JJwnocyLUxHI2jlKF4Y,kMqh74TPvpSDar59xQUjAyVlHes,Cpf9s3c0Zngj7XE,L95mrowGgdsD,zLEP9N4BOsVrXa,U94JwhRgpXCOe5,EALyNnv1Db4cUd8sQoZX2pmBVt7kM,XC10geOnQtwrs in Tl0ShdQEA7xKY8vRb9HzZaBcL4:
			if wgkhczjbQKpa in ['listed_sites'+Vl07OYWcxeMQwgpFAbJnLhRuBf2d6K,'opened_sites'+Vl07OYWcxeMQwgpFAbJnLhRuBf2d6K] and 'صفحة' in JJwnocyLUxHI2jlKF4Y and synCYOiMR789twmfr=='folder': continue
			bP6z3OSLp7va(synCYOiMR789twmfr,JJwnocyLUxHI2jlKF4Y,kMqh74TPvpSDar59xQUjAyVlHes,Cpf9s3c0Zngj7XE,L95mrowGgdsD,zLEP9N4BOsVrXa,U94JwhRgpXCOe5,EALyNnv1Db4cUd8sQoZX2pmBVt7kM,XC10geOnQtwrs)
	qI2s0ZN7uj(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U)
	return
def z2uNLQTy5VPnqZJDCt3m6elMj8gWHd(search):
	Hlk8VWd5mBwhL6uxE = t624ZFj0bLTEvG1uImXpr7M83oJq(j5q8z4HT3cfhvK)
	for ekEOd3mqAThaBDUoIrntuGRjYW in Hlk8VWd5mBwhL6uxE:
		if '-' in ekEOd3mqAThaBDUoIrntuGRjYW: continue
		if 'tuple' in str(type(ekEOd3mqAThaBDUoIrntuGRjYW)):
			g6ghGH4aBEYkTl3vbJZ.append(ekEOd3mqAThaBDUoIrntuGRjYW)
			continue
		ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,lEgmdMxnfsXj,ZebIE2aQgrGn = GGkFKuWvn5q1wVmldgXz(ekEOd3mqAThaBDUoIrntuGRjYW)
		name = aanoXVLTZqsIwitBdY0kcJS794FDg(ekEOd3mqAThaBDUoIrntuGRjYW)+' - '+search
		bP6z3OSLp7va('folder',ZebIE2aQgrGn+name,ekEOd3mqAThaBDUoIrntuGRjYW,548,'','',search)
	return
def rZv31ayueijsOwGTg7VHSom0MX(ekEOd3mqAThaBDUoIrntuGRjYW,search):
	ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,lEgmdMxnfsXj,ZebIE2aQgrGn = GGkFKuWvn5q1wVmldgXz(ekEOd3mqAThaBDUoIrntuGRjYW)
	lEgmdMxnfsXj(search)
	return
def JFOEeDi3whsykPNYWzv():
	bb5kRv7jh3LaEVJtIfg('','','رسالة من المبرمج','هذا البحث يستخدم محركات البحث الصغيرة الموجودة في كل موقع من مواقع البرنامج .. ونتائج هذا البحث تعتمد على دقة وفعالية وبرمجة كل موقع منها\n\nللأسف هذه المحركات الصغيرة لا تفهم جميع تفاصيل الفيديوهات ولا تفهم طريقة تفكير البشر ولا تستطيع إصلاح الأخطاء الإملائية .. ولهذا هي تحتاج دقة كبيرة جدا في اختيار وكتابة كلمات البحث المناسبة الصحيحة الدقيقة حتى تجد لك طلبك')
	return
def oJkM80pA5lsHqYn7RNhextgmU4(xP7Y24rlOy5zLh=iiy37aKq0pCEIOwfcTh61xb4U):
	XoJdWFj2HL14SIhExcU,FG615TlEM78tKb,showDialogs = XkYnev3ZCA6ahO94(xP7Y24rlOy5zLh)
	if not XoJdWFj2HL14SIhExcU:
		XoJdWFj2HL14SIhExcU = TTBf6S08q1NKXd5v9wa()
		if not XoJdWFj2HL14SIhExcU: return
		XoJdWFj2HL14SIhExcU = XoJdWFj2HL14SIhExcU.lower()
	WKquk5EaNr4RzVf(q1rohYuwnfpVZUa98L2CtQzmAcB,IIZ4e82HBP0oTmtOgaWY7hsMz(sQU2GnRoMwLK8CBdfzmNr4jXyO)+'   Search For: [ '+XoJdWFj2HL14SIhExcU+' ]')
	VVOtdjT9AF4Wk3GECqHL = XoJdWFj2HL14SIhExcU+FG615TlEM78tKb
	if 0: X0nHZpVPaxIW,aKQTNif8Yw4s = XoJdWFj2HL14SIhExcU+' - ',iiy37aKq0pCEIOwfcTh61xb4U
	else: X0nHZpVPaxIW,aKQTNif8Yw4s = iiy37aKq0pCEIOwfcTh61xb4U,' - '+XoJdWFj2HL14SIhExcU
	bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+'مواقع سيرفرات خاصة - قليلة المشاكل'+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,157)
	bP6z3OSLp7va('folder','_M3U_'+X0nHZpVPaxIW+'بحث M3U'+aKQTNif8Yw4s,iiy37aKq0pCEIOwfcTh61xb4U,719,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,VVOtdjT9AF4Wk3GECqHL)
	bP6z3OSLp7va('folder','_IPT_'+X0nHZpVPaxIW+'بحث IPTV'+aKQTNif8Yw4s,iiy37aKq0pCEIOwfcTh61xb4U,239,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,VVOtdjT9AF4Wk3GECqHL)
	bP6z3OSLp7va('folder','_BKR_'+X0nHZpVPaxIW+'بحث موقع بكرا'+aKQTNif8Yw4s,iiy37aKq0pCEIOwfcTh61xb4U,379,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,VVOtdjT9AF4Wk3GECqHL)
	bP6z3OSLp7va('folder','_ART_'+X0nHZpVPaxIW+'بحث موقع تونز عربية'+aKQTNif8Yw4s,iiy37aKq0pCEIOwfcTh61xb4U,739,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,VVOtdjT9AF4Wk3GECqHL)
	bP6z3OSLp7va('folder','_KRB_'+X0nHZpVPaxIW+'بحث موقع قناة كربلاء'+aKQTNif8Yw4s,iiy37aKq0pCEIOwfcTh61xb4U,329,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,VVOtdjT9AF4Wk3GECqHL)
	bP6z3OSLp7va('folder','_FH2_'+X0nHZpVPaxIW+'بحث موقع فاصل الثاني'+aKQTNif8Yw4s,iiy37aKq0pCEIOwfcTh61xb4U,599,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,VVOtdjT9AF4Wk3GECqHL)
	bP6z3OSLp7va('folder','_KTV_'+X0nHZpVPaxIW+'بحث موقع كتكوت تيفي'+aKQTNif8Yw4s,iiy37aKq0pCEIOwfcTh61xb4U,819,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,VVOtdjT9AF4Wk3GECqHL)
	bP6z3OSLp7va('folder','_EB1_'+X0nHZpVPaxIW+'بحث موقع ايجي بيست 1'+aKQTNif8Yw4s,iiy37aKq0pCEIOwfcTh61xb4U,779,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,VVOtdjT9AF4Wk3GECqHL)
	bP6z3OSLp7va('folder','_EB2_'+X0nHZpVPaxIW+'بحث موقع ايجي بيست 2'+aKQTNif8Yw4s,iiy37aKq0pCEIOwfcTh61xb4U,789,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,VVOtdjT9AF4Wk3GECqHL)
	bP6z3OSLp7va('folder','_IFL_'+X0nHZpVPaxIW+'  بحث موقع قناة آي فيلم'+aKQTNif8Yw4s+Wc5GekRC0HQLz7,iiy37aKq0pCEIOwfcTh61xb4U,29,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,VVOtdjT9AF4Wk3GECqHL)
	bP6z3OSLp7va('folder','_AKO_'+X0nHZpVPaxIW+'بحث موقع أكوام القديم'+aKQTNif8Yw4s,iiy37aKq0pCEIOwfcTh61xb4U,79,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,VVOtdjT9AF4Wk3GECqHL)
	bP6z3OSLp7va('folder','_AKW_'+X0nHZpVPaxIW+'بحث موقع أكوام الجديد'+aKQTNif8Yw4s,iiy37aKq0pCEIOwfcTh61xb4U,249,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,VVOtdjT9AF4Wk3GECqHL)
	bP6z3OSLp7va('folder','_MRF_'+X0nHZpVPaxIW+'بحث موقع قناة المعارف'+aKQTNif8Yw4s,iiy37aKq0pCEIOwfcTh61xb4U,49,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,VVOtdjT9AF4Wk3GECqHL)
	bP6z3OSLp7va('folder','_SHM_'+X0nHZpVPaxIW+'بحث موقع شوف ماكس'+aKQTNif8Yw4s,iiy37aKq0pCEIOwfcTh61xb4U,59,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,VVOtdjT9AF4Wk3GECqHL)
	bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+'مواقع سيرفرات خاصة وعامة - كثيرة المشاكل'+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,157)
	bP6z3OSLp7va('folder','_LRZ_'+X0nHZpVPaxIW+'بحث موقع لاروزا'+aKQTNif8Yw4s,iiy37aKq0pCEIOwfcTh61xb4U,709,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,VVOtdjT9AF4Wk3GECqHL)
	bP6z3OSLp7va('folder','_FJS_'+X0nHZpVPaxIW+' بحث موقع فجر شو'+aKQTNif8Yw4s+iFBmE2MUIpSu34wsd7Rf6z,iiy37aKq0pCEIOwfcTh61xb4U,399,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,VVOtdjT9AF4Wk3GECqHL)
	bP6z3OSLp7va('folder','_TVF_'+X0nHZpVPaxIW+'بحث موقع تيفي فان'+aKQTNif8Yw4s,iiy37aKq0pCEIOwfcTh61xb4U,469,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,VVOtdjT9AF4Wk3GECqHL)
	bP6z3OSLp7va('folder','_LDN_'+X0nHZpVPaxIW+'بحث موقع لودي نت'+aKQTNif8Yw4s,iiy37aKq0pCEIOwfcTh61xb4U,459,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,VVOtdjT9AF4Wk3GECqHL)
	bP6z3OSLp7va('folder','_CMN_'+X0nHZpVPaxIW+'بحث موقع سيما ناو'+aKQTNif8Yw4s,iiy37aKq0pCEIOwfcTh61xb4U,309,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,VVOtdjT9AF4Wk3GECqHL)
	bP6z3OSLp7va('folder','_SHN_'+X0nHZpVPaxIW+'بحث موقع شاهد نيوز'+aKQTNif8Yw4s,iiy37aKq0pCEIOwfcTh61xb4U,589,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,VVOtdjT9AF4Wk3GECqHL+'_NODIALOGS_')
	bP6z3OSLp7va('folder','_ARS_'+X0nHZpVPaxIW+'بحث موقع عرب سييد'+aKQTNif8Yw4s,iiy37aKq0pCEIOwfcTh61xb4U,259,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,VVOtdjT9AF4Wk3GECqHL)
	bP6z3OSLp7va('folder','_CCB_'+X0nHZpVPaxIW+'بحث موقع سيما كلوب'+aKQTNif8Yw4s,iiy37aKq0pCEIOwfcTh61xb4U,829,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,VVOtdjT9AF4Wk3GECqHL)
	bP6z3OSLp7va('folder','_SH4_'+X0nHZpVPaxIW+'بحث موقع شاهد فوريو'+aKQTNif8Yw4s,iiy37aKq0pCEIOwfcTh61xb4U,119,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,VVOtdjT9AF4Wk3GECqHL+'_NODIALOGS_')
	bP6z3OSLp7va('folder','_SHT_'+X0nHZpVPaxIW+'بحث موقع شوفها تيفي'+aKQTNif8Yw4s,iiy37aKq0pCEIOwfcTh61xb4U,649,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,VVOtdjT9AF4Wk3GECqHL)
	bP6z3OSLp7va('folder','_WC1_'+X0nHZpVPaxIW+'بحث موقع وي سيما 1'+aKQTNif8Yw4s,iiy37aKq0pCEIOwfcTh61xb4U,569,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,VVOtdjT9AF4Wk3GECqHL)
	bP6z3OSLp7va('folder','_WC2_'+X0nHZpVPaxIW+'بحث موقع وي سيما 2'+aKQTNif8Yw4s,iiy37aKq0pCEIOwfcTh61xb4U,1009,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,VVOtdjT9AF4Wk3GECqHL)
	bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+'مواقع سيرفرات عامة - كثيرة المشاكل'+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,157)
	bP6z3OSLp7va('folder','_TKT_'+X0nHZpVPaxIW+'بحث موقع تكات'+aKQTNif8Yw4s,iiy37aKq0pCEIOwfcTh61xb4U,949,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,VVOtdjT9AF4Wk3GECqHL)
	bP6z3OSLp7va('folder','_FST_'+X0nHZpVPaxIW+'بحث موقع فوستا'+aKQTNif8Yw4s,iiy37aKq0pCEIOwfcTh61xb4U,609,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,VVOtdjT9AF4Wk3GECqHL)
	bP6z3OSLp7va('folder','_FBK_'+X0nHZpVPaxIW+'بحث موقع فبركة'+aKQTNif8Yw4s,iiy37aKq0pCEIOwfcTh61xb4U,629,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,VVOtdjT9AF4Wk3GECqHL)
	bP6z3OSLp7va('folder','_YQT_'+X0nHZpVPaxIW+'بحث موقع ياقوت'+aKQTNif8Yw4s,iiy37aKq0pCEIOwfcTh61xb4U,669,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,VVOtdjT9AF4Wk3GECqHL)
	bP6z3OSLp7va('folder','_SHB_'+X0nHZpVPaxIW+'بحث موقع شبكتي'+aKQTNif8Yw4s,iiy37aKq0pCEIOwfcTh61xb4U,969,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,VVOtdjT9AF4Wk3GECqHL)
	bP6z3OSLp7va('folder','_VRB_'+X0nHZpVPaxIW+'بحث موقع فاربون'+aKQTNif8Yw4s,iiy37aKq0pCEIOwfcTh61xb4U,879,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,VVOtdjT9AF4Wk3GECqHL)
	bP6z3OSLp7va('folder','_BRS_'+X0nHZpVPaxIW+'بحث موقع برستيج'+aKQTNif8Yw4s,iiy37aKq0pCEIOwfcTh61xb4U,659,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,VVOtdjT9AF4Wk3GECqHL)
	bP6z3OSLp7va('folder','_KRM_'+X0nHZpVPaxIW+'بحث موقع كرمالك'+aKQTNif8Yw4s,iiy37aKq0pCEIOwfcTh61xb4U,929,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,VVOtdjT9AF4Wk3GECqHL)
	bP6z3OSLp7va('folder','_ANZ_'+X0nHZpVPaxIW+'بحث موقع انمي زد'+aKQTNif8Yw4s,iiy37aKq0pCEIOwfcTh61xb4U,979,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,VVOtdjT9AF4Wk3GECqHL)
	bP6z3OSLp7va('folder','_FSK_'+X0nHZpVPaxIW+'بحث موقع فارسكو'+aKQTNif8Yw4s,iiy37aKq0pCEIOwfcTh61xb4U,999,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,VVOtdjT9AF4Wk3GECqHL)
	bP6z3OSLp7va('folder','_HLC_'+X0nHZpVPaxIW+'بحث موقع هلا سيما'+aKQTNif8Yw4s,iiy37aKq0pCEIOwfcTh61xb4U,89,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,VVOtdjT9AF4Wk3GECqHL)
	bP6z3OSLp7va('folder','_MST_'+X0nHZpVPaxIW+'بحث موقع المصطبة'+aKQTNif8Yw4s,iiy37aKq0pCEIOwfcTh61xb4U,869,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,VVOtdjT9AF4Wk3GECqHL)
	bP6z3OSLp7va('folder','_SNT_'+X0nHZpVPaxIW+'بحث موقع شوف نت'+aKQTNif8Yw4s,iiy37aKq0pCEIOwfcTh61xb4U,849,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,VVOtdjT9AF4Wk3GECqHL)
	bP6z3OSLp7va('folder','_DR7_'+X0nHZpVPaxIW+'بحث موقع دراما صح'+aKQTNif8Yw4s,iiy37aKq0pCEIOwfcTh61xb4U,689,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,VVOtdjT9AF4Wk3GECqHL)
	bP6z3OSLp7va('folder','_CFR_'+X0nHZpVPaxIW+'بحث موقع سيما فري'+aKQTNif8Yw4s,iiy37aKq0pCEIOwfcTh61xb4U,839,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,VVOtdjT9AF4Wk3GECqHL)
	bP6z3OSLp7va('folder','_CMF_'+X0nHZpVPaxIW+'بحث موقع سيما فانز'+aKQTNif8Yw4s,iiy37aKq0pCEIOwfcTh61xb4U,99,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,VVOtdjT9AF4Wk3GECqHL)
	bP6z3OSLp7va('folder','_CML_'+X0nHZpVPaxIW+'بحث موقع سيما لايت'+aKQTNif8Yw4s,iiy37aKq0pCEIOwfcTh61xb4U,479,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,VVOtdjT9AF4Wk3GECqHL)
	bP6z3OSLp7va('folder','_C4H_'+X0nHZpVPaxIW+'بحث موقع سيما 400'+aKQTNif8Yw4s,iiy37aKq0pCEIOwfcTh61xb4U,699,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,VVOtdjT9AF4Wk3GECqHL)
	bP6z3OSLp7va('folder','_ABD_'+X0nHZpVPaxIW+'بحث موقع سيما عبدو'+aKQTNif8Yw4s,iiy37aKq0pCEIOwfcTh61xb4U,559,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,VVOtdjT9AF4Wk3GECqHL)
	bP6z3OSLp7va('folder','_AKT_'+X0nHZpVPaxIW+'بحث موقع اكوام تيوب'+aKQTNif8Yw4s,iiy37aKq0pCEIOwfcTh61xb4U,859,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,VVOtdjT9AF4Wk3GECqHL)
	bP6z3OSLp7va('folder','_DCF_'+X0nHZpVPaxIW+'بحث موقع دراما كافيه'+aKQTNif8Yw4s,iiy37aKq0pCEIOwfcTh61xb4U,939,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,VVOtdjT9AF4Wk3GECqHL)
	bP6z3OSLp7va('folder','_FTV_'+X0nHZpVPaxIW+'بحث موقع فوشار تيفي'+aKQTNif8Yw4s,iiy37aKq0pCEIOwfcTh61xb4U,919,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,VVOtdjT9AF4Wk3GECqHL)
	bP6z3OSLp7va('folder','_CWB_'+X0nHZpVPaxIW+'بحث موقع سيما وبس'+aKQTNif8Yw4s,iiy37aKq0pCEIOwfcTh61xb4U,989,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,VVOtdjT9AF4Wk3GECqHL)
	bP6z3OSLp7va('folder','_AHK_'+X0nHZpVPaxIW+'بحث موقع أهواك تيفي'+aKQTNif8Yw4s,iiy37aKq0pCEIOwfcTh61xb4U,619,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,VVOtdjT9AF4Wk3GECqHL)
	bP6z3OSLp7va('folder','_SRT_'+X0nHZpVPaxIW+'بحث موقع سيريس تايم'+aKQTNif8Yw4s,iiy37aKq0pCEIOwfcTh61xb4U,899,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,VVOtdjT9AF4Wk3GECqHL)
	bP6z3OSLp7va('folder','_FVD_'+X0nHZpVPaxIW+'بحث موقع فوشار فيديو'+aKQTNif8Yw4s,iiy37aKq0pCEIOwfcTh61xb4U,909,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,VVOtdjT9AF4Wk3GECqHL)
	bP6z3OSLp7va('folder','_C4P_'+X0nHZpVPaxIW+'بحث موقع سيما فور بي'+aKQTNif8Yw4s,iiy37aKq0pCEIOwfcTh61xb4U,889,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,VVOtdjT9AF4Wk3GECqHL)
	bP6z3OSLp7va('folder','_EB4_'+X0nHZpVPaxIW+'بحث موقع ايجي بيست 4'+aKQTNif8Yw4s,iiy37aKq0pCEIOwfcTh61xb4U,809,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,VVOtdjT9AF4Wk3GECqHL)
	bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+'مواقع سيرفرات خاصة - قليلة المشاكل'+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,157)
	bP6z3OSLp7va('folder','_YUT_'+X0nHZpVPaxIW+'بحث موقع يوتيوب'+aKQTNif8Yw4s,iiy37aKq0pCEIOwfcTh61xb4U,149,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,VVOtdjT9AF4Wk3GECqHL)
	bP6z3OSLp7va('folder','_DLM_'+X0nHZpVPaxIW+'بحث موقع دايلي موشن'+aKQTNif8Yw4s,iiy37aKq0pCEIOwfcTh61xb4U,409,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,VVOtdjT9AF4Wk3GECqHL)
	return
# -*- coding: utf-8 -*-
from braVAkwfBN import *
sQU2GnRoMwLK8CBdfzmNr4jXyO = 'HALACIMA'
ooQEi5O6tYsGVF8LU0TC3hgMeflBwH = '_HLC_'
JaQEtCzDXgos1cdZN = gZ4LwbKaOm[sQU2GnRoMwLK8CBdfzmNr4jXyO][0]
a8GCLIuWNkS = ['مصارعة','احدث البرامج','احدث الالعاب','احدث الاغانى']
def sHVM8YchrDjZAJ7(mode,url,text):
	if   mode==80: EA7FzO1kMZGQXDd2giB0cwLom = jihuS9LVAvTrClPapMbUEwfn8XN()
	elif mode==81: EA7FzO1kMZGQXDd2giB0cwLom = AIQeNZP4FMDw9S(url,text)
	elif mode==82: EA7FzO1kMZGQXDd2giB0cwLom = TW6Z0zqaDl(url)
	elif mode==83: EA7FzO1kMZGQXDd2giB0cwLom = YNcMvoVF5swlDBJI7PL(url)
	elif mode==89: EA7FzO1kMZGQXDd2giB0cwLom = mUhJtHB9nw(text)
	else: EA7FzO1kMZGQXDd2giB0cwLom = False
	return EA7FzO1kMZGQXDd2giB0cwLom
def jihuS9LVAvTrClPapMbUEwfn8XN():
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',JaQEtCzDXgos1cdZN,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'HALACIMA-MENU-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	ffBG4TaQU8lVF26R = F82MvyX4ThI6sbnA3efDoVS(JaQEtCzDXgos1cdZN,'url')
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'بحث في الموقع',iiy37aKq0pCEIOwfcTh61xb4U,89,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'_REMEMBERRESULTS_')
	bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('main-content(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
	items = dEyT9xhGjolYzLCH7460w3.findall('data-name="(.*?)".*?</i>(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	for Ax2k5gsahJCBE30DfntcyXL7P,title in items:
		fCXyTlcmF4WuetVork = ffBG4TaQU8lVF26R+'/ajax/getItem?item='+Ax2k5gsahJCBE30DfntcyXL7P+'&Ajax=1'
		bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,81)
	bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"nav-main"(.*?)</nav>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
	items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)">(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	for fCXyTlcmF4WuetVork,title in items:
		if fCXyTlcmF4WuetVork=='#': continue
		if title in a8GCLIuWNkS: continue
		bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,81)
	return
def AIQeNZP4FMDw9S(url,Ax2k5gsahJCBE30DfntcyXL7P=iiy37aKq0pCEIOwfcTh61xb4U):
	items = []
	if '/ajax/getItem' in url or '/ajax/loadMore' in url:
		eCGwzSrqBmIv,EwsmJ67cCYDIlg = sFNjagPK4W(url)
		rzR9SN7ApZuQhTDWEX3V6ga = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'POST',eCGwzSrqBmIv,EwsmJ67cCYDIlg,rzR9SN7ApZuQhTDWEX3V6ga,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'HALACIMA-TITLES-1st')
		Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
		UUIohmv597bO83YCLgWS = [Vxz6OndPIX4g2kaRp7]
	else:
		oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'HALACIMA-TITLES-2nd')
		Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
		if Ax2k5gsahJCBE30DfntcyXL7P=='featured':
			UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"container"(.*?)"container"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
			PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
			items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		elif '"section-post mb-10"' in Vxz6OndPIX4g2kaRp7:
			UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"section-post mb-10"(.*?)"container"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		else:
			UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('<article(.*?)"pagination"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if not UUIohmv597bO83YCLgWS: return
	PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
	if not items:
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)" title="(.*?)".*?data-original="(.*?)"',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if not items: items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	u3Rztpl4VHO9GZ7jCBM65kvS = []
	mxXKsCgL5OoP1evURZ8SdIfpBrwu = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for fCXyTlcmF4WuetVork,title,C0dvhEbPWYlUtimM3x in items:
		fCXyTlcmF4WuetVork = a9I3YZjc6ySDPE4Kp(fCXyTlcmF4WuetVork).strip('/')
		zN7sZyFnw5JTE8 = dEyT9xhGjolYzLCH7460w3.findall('(.*?) الحلقة \d+',title,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if '/series/' in fCXyTlcmF4WuetVork:
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,83,C0dvhEbPWYlUtimM3x)
		elif 'سلاسل' not in url and any(aasX2cby4Vo5rTgB in title for aasX2cby4Vo5rTgB in mxXKsCgL5OoP1evURZ8SdIfpBrwu):
			bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,82,C0dvhEbPWYlUtimM3x)
		elif zN7sZyFnw5JTE8 and 'الحلقة' in title:
			title = '_MOD_' + zN7sZyFnw5JTE8[0]
			if title not in u3Rztpl4VHO9GZ7jCBM65kvS:
				bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,83,C0dvhEbPWYlUtimM3x)
				u3Rztpl4VHO9GZ7jCBM65kvS.append(title)
		elif '/movies/' in fCXyTlcmF4WuetVork:
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,81,C0dvhEbPWYlUtimM3x)
		else: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,83,C0dvhEbPWYlUtimM3x)
	if Ax2k5gsahJCBE30DfntcyXL7P==iiy37aKq0pCEIOwfcTh61xb4U:
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"pagination"(.*?)<footer',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if UUIohmv597bO83YCLgWS:
			PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
			items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?>(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
			for fCXyTlcmF4WuetVork,title in items:
				if fCXyTlcmF4WuetVork=="": continue
				if title!=iiy37aKq0pCEIOwfcTh61xb4U: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'صفحة '+title,fCXyTlcmF4WuetVork,81)
	if '/ajax/getItem' in url or '/ajax/loadMore' in url:
		if '/ajax/getItem' in url:
			url = url.replace('/ajax/getItem','/ajax/loadMore')+'&offset=20'
		elif '/ajax/loadMore' in url:
			url,offset = url.split('&offset=')
			offset = int(offset)+20
			url = url+'&offset='+str(offset)
		bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'هناك المزيد',url,81)
	return
def YNcMvoVF5swlDBJI7PL(url):
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'HALACIMA-EPISODES-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	HG5rE20ORdbqUKWewuZCJP4zoXF6g = dEyT9xhGjolYzLCH7460w3.findall('"getSeasonsBySeries(.*?)"container"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	eTov6CfDcRZVJEAq5BH = dEyT9xhGjolYzLCH7460w3.findall('"list-episodes"(.*?)"container"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if HG5rE20ORdbqUKWewuZCJP4zoXF6g and '/series/' not in url:
		PPH1sQtTkDBbnlYpZfo5 = HG5rE20ORdbqUKWewuZCJP4zoXF6g[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title,C0dvhEbPWYlUtimM3x in items:
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,83,C0dvhEbPWYlUtimM3x)
	elif eTov6CfDcRZVJEAq5BH:
		C0dvhEbPWYlUtimM3x = dEyT9xhGjolYzLCH7460w3.findall('"image" src="(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		C0dvhEbPWYlUtimM3x = C0dvhEbPWYlUtimM3x[0]
		PPH1sQtTkDBbnlYpZfo5 = eTov6CfDcRZVJEAq5BH[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)" title="(.*?)"',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title in items:
			bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,82,C0dvhEbPWYlUtimM3x)
	return
def TW6Z0zqaDl(url):
	eCGwzSrqBmIv = url.replace('/movies/','/watch_movies/')
	eCGwzSrqBmIv = eCGwzSrqBmIv.replace('/episodes/','/watch_episodes/')
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',eCGwzSrqBmIv,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'HALACIMA-PLAY-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	ffBG4TaQU8lVF26R = F82MvyX4ThI6sbnA3efDoVS(eCGwzSrqBmIv,'url')
	duef0gb3Mi1AV5WpN8 = []
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"servers"(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		VlX2C0mPxeyD8wZYKLuf = dEyT9xhGjolYzLCH7460w3.findall('postID = "(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		VlX2C0mPxeyD8wZYKLuf = VlX2C0mPxeyD8wZYKLuf[0]
		items = dEyT9xhGjolYzLCH7460w3.findall("getPlayer\('(.*?)'.*?</i>(.*?)</a>",PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for Zw4M5DUStdE6xp7GI,title in items:
			title = title.replace(OTlVEGYPSxsNaBdXUucqA3,iiy37aKq0pCEIOwfcTh61xb4U).strip(iFBmE2MUIpSu34wsd7Rf6z)
			fCXyTlcmF4WuetVork = ffBG4TaQU8lVF26R+'/ajax/getPlayer?server='+Zw4M5DUStdE6xp7GI+'&postID='+VlX2C0mPxeyD8wZYKLuf+'&Ajax=1'
			fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork+'?named='+title+'__watch'
			duef0gb3Mi1AV5WpN8.append(fCXyTlcmF4WuetVork)
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"downs"(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)" title="(.*?)"',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,name in items:
			fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork+'?named='+name+'__download'
			duef0gb3Mi1AV5WpN8.append(fCXyTlcmF4WuetVork)
	import lqBJGK8hXO
	lqBJGK8hXO.ZDg1HavwueT85mcAOorC4hnS(duef0gb3Mi1AV5WpN8,sQU2GnRoMwLK8CBdfzmNr4jXyO,'video',url)
	return
def mUhJtHB9nw(search):
	search,brFQp5vmgJWdZfEkCBOlu9c,showDialogs = XkYnev3ZCA6ahO94(search)
	if search==iiy37aKq0pCEIOwfcTh61xb4U: search = TTBf6S08q1NKXd5v9wa()
	if search==iiy37aKq0pCEIOwfcTh61xb4U: return
	search = search.replace(iFBmE2MUIpSu34wsd7Rf6z,'-')
	url = JaQEtCzDXgos1cdZN+'/search/'+search+'.html'
	AIQeNZP4FMDw9S(url)
	return
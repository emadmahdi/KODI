# -*- coding: utf-8 -*-
from braVAkwfBN import *
sQU2GnRoMwLK8CBdfzmNr4jXyO = 'ALFATIMI'
ooQEi5O6tYsGVF8LU0TC3hgMeflBwH = '_FTM_'
JaQEtCzDXgos1cdZN = gZ4LwbKaOm[sQU2GnRoMwLK8CBdfzmNr4jXyO][0]
OwmCBhEsPtazYSbD = ['1239','1250','1245','20','1259','218','485','1238','1258','292']
AlTY4dLu7soPbpZC0R5efK6UJ3O = ['3030','628']
def sHVM8YchrDjZAJ7(mode,url,text):
	if   mode==60: EA7FzO1kMZGQXDd2giB0cwLom = jihuS9LVAvTrClPapMbUEwfn8XN()
	elif mode==61: EA7FzO1kMZGQXDd2giB0cwLom = AIQeNZP4FMDw9S(url,text)
	elif mode==62: EA7FzO1kMZGQXDd2giB0cwLom = YNcMvoVF5swlDBJI7PL(url)
	elif mode==63: EA7FzO1kMZGQXDd2giB0cwLom = TW6Z0zqaDl(url)
	elif mode==64: EA7FzO1kMZGQXDd2giB0cwLom = His5Y4jD8962WNdLaEFBy(text)
	elif mode==69: EA7FzO1kMZGQXDd2giB0cwLom = mUhJtHB9nw(text)
	else: EA7FzO1kMZGQXDd2giB0cwLom = False
	return EA7FzO1kMZGQXDd2giB0cwLom
def jihuS9LVAvTrClPapMbUEwfn8XN():
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'بحث في الموقع',iiy37aKq0pCEIOwfcTh61xb4U,69,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'_REMEMBERRESULTS_')
	bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'ما يتم مشاهدته الان',JaQEtCzDXgos1cdZN,64,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'recent_viewed_vids')
	bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'الاكثر مشاهدة',JaQEtCzDXgos1cdZN,64,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'most_viewed_vids')
	bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'اضيفت مؤخرا',JaQEtCzDXgos1cdZN,64,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'recently_added_vids')
	bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'فيديو عشوائي',JaQEtCzDXgos1cdZN,64,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'random_vids')
	bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'افلام ومسلسلات',JaQEtCzDXgos1cdZN,61,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'-1')
	bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'البرامج الدينية',JaQEtCzDXgos1cdZN,61,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'-2')
	bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'English Videos',JaQEtCzDXgos1cdZN,61,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'-3')
	return iiy37aKq0pCEIOwfcTh61xb4U
def AIQeNZP4FMDw9S(url,RRIscyLmNH9dq2Dio3TSr):
	uuhxaOqfPIY9Gm846KV = iiy37aKq0pCEIOwfcTh61xb4U
	if RRIscyLmNH9dq2Dio3TSr not in ['-1','-2','-3']: uuhxaOqfPIY9Gm846KV = '?cat='+RRIscyLmNH9dq2Dio3TSr
	eCGwzSrqBmIv = JaQEtCzDXgos1cdZN+'/menu_level.php'+uuhxaOqfPIY9Gm846KV
	Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(PNjZMS7nxa9clHusz1,eCGwzSrqBmIv,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'ALFATIMI-TITLES-1st')
	items = dEyT9xhGjolYzLCH7460w3.findall('href=\'(.*?)\'.*?>(.*?)<.*?>(.*?)</span>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	FsL1ObSDHAchWqg3IrUxNR,ODImXaV12yknNJH4fp7Y = False,False
	for fCXyTlcmF4WuetVork,title,count in items:
		title = JIY6A30UOsQboNVqCn(title)
		title = title.strip(iFBmE2MUIpSu34wsd7Rf6z)
		if 'http' not in fCXyTlcmF4WuetVork: fCXyTlcmF4WuetVork = 'http:'+fCXyTlcmF4WuetVork
		uuhxaOqfPIY9Gm846KV = dEyT9xhGjolYzLCH7460w3.findall('cat=(.*?)&',fCXyTlcmF4WuetVork,dEyT9xhGjolYzLCH7460w3.DOTALL)[0]
		if RRIscyLmNH9dq2Dio3TSr==uuhxaOqfPIY9Gm846KV: FsL1ObSDHAchWqg3IrUxNR = True
		elif FsL1ObSDHAchWqg3IrUxNR 	or (RRIscyLmNH9dq2Dio3TSr=='-1' and uuhxaOqfPIY9Gm846KV in OwmCBhEsPtazYSbD)  						or (RRIscyLmNH9dq2Dio3TSr=='-2' and uuhxaOqfPIY9Gm846KV not in AlTY4dLu7soPbpZC0R5efK6UJ3O and uuhxaOqfPIY9Gm846KV not in OwmCBhEsPtazYSbD)  						or (RRIscyLmNH9dq2Dio3TSr=='-3' and uuhxaOqfPIY9Gm846KV in AlTY4dLu7soPbpZC0R5efK6UJ3O):
							if count=='1': bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,63)
							else: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,61,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,uuhxaOqfPIY9Gm846KV)
							ODImXaV12yknNJH4fp7Y = True
	if not ODImXaV12yknNJH4fp7Y: YNcMvoVF5swlDBJI7PL(url)
	return
def YNcMvoVF5swlDBJI7PL(url):
	Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(PNjZMS7nxa9clHusz1,url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,True,'ALFATIMI-EPISODES-1st')
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('pagination(.*?)id="footer',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
	items = dEyT9xhGjolYzLCH7460w3.findall('grid_view.*?src="(.*?)".*?title="(.*?)".*?<h2.*?href="(.*?)"',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	fCXyTlcmF4WuetVork = iiy37aKq0pCEIOwfcTh61xb4U
	for C0dvhEbPWYlUtimM3x,title,fCXyTlcmF4WuetVork in items:
		title = title.replace('Add',iiy37aKq0pCEIOwfcTh61xb4U).replace('to Quicklist',iiy37aKq0pCEIOwfcTh61xb4U).strip(iFBmE2MUIpSu34wsd7Rf6z)
		if 'http' not in fCXyTlcmF4WuetVork: fCXyTlcmF4WuetVork = 'http:'+fCXyTlcmF4WuetVork
		bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,63,C0dvhEbPWYlUtimM3x)
	UUIohmv597bO83YCLgWS=dEyT9xhGjolYzLCH7460w3.findall('(.*?)div',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	PPH1sQtTkDBbnlYpZfo5=UUIohmv597bO83YCLgWS[0]
	PPH1sQtTkDBbnlYpZfo5=dEyT9xhGjolYzLCH7460w3.findall('pagination(.*?)</div>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)[0]
	items=dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?>(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	eCGwzSrqBmIv = url.split('?')[0]
	for fCXyTlcmF4WuetVork,IIMp8kDh0zEeZJfyrtHBbRvjS in items:
		fCXyTlcmF4WuetVork = eCGwzSrqBmIv + fCXyTlcmF4WuetVork
		title = JIY6A30UOsQboNVqCn(IIMp8kDh0zEeZJfyrtHBbRvjS)
		title = 'صفحة ' + title
		bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,62)
	return fCXyTlcmF4WuetVork
def TW6Z0zqaDl(url):
	if 'videos.php' in url: url = YNcMvoVF5swlDBJI7PL(url)
	Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(Dxc7GChQwZ4kOlKHSbL06agnB,url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,True,'ALFATIMI-PLAY-1st')
	items = dEyT9xhGjolYzLCH7460w3.findall('playlistfile:"(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	url = items[0]
	if 'http' not in url: url = 'http:'+url
	PsD3IgluKFyvzMLoRT9j5hq2(url,sQU2GnRoMwLK8CBdfzmNr4jXyO,'video')
	return
def His5Y4jD8962WNdLaEFBy(RRIscyLmNH9dq2Dio3TSr):
	Si4j3bXGLeno0zfxlm9ZOcy = { 'mode' : RRIscyLmNH9dq2Dio3TSr }
	url = 'http://alfatimi.tv/ajax.php'
	headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
	data = zzUnMebTFdNgB8hOwJmKxVj(Si4j3bXGLeno0zfxlm9ZOcy)
	Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(r3rnfZ7cdxzNFebIRaLSG6B,url,data,headers,True,'ALFATIMI-MOSTS-1st')
	items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?title="(.*?)".*?src="(.*?)".*?href',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	for fCXyTlcmF4WuetVork,title,C0dvhEbPWYlUtimM3x in items:
		title = title.strip(iFBmE2MUIpSu34wsd7Rf6z)
		if 'http' not in fCXyTlcmF4WuetVork: fCXyTlcmF4WuetVork = 'http:'+fCXyTlcmF4WuetVork
		bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,63,C0dvhEbPWYlUtimM3x)
	return
def mUhJtHB9nw(search):
	search,brFQp5vmgJWdZfEkCBOlu9c,showDialogs = XkYnev3ZCA6ahO94(search)
	if search==iiy37aKq0pCEIOwfcTh61xb4U: search = TTBf6S08q1NKXd5v9wa()
	if search==iiy37aKq0pCEIOwfcTh61xb4U: return
	VVOtdjT9AF4Wk3GECqHL = search.replace(iFBmE2MUIpSu34wsd7Rf6z,'+')
	url = JaQEtCzDXgos1cdZN + '/search_result.php?query=' + VVOtdjT9AF4Wk3GECqHL
	YNcMvoVF5swlDBJI7PL(url)
	return
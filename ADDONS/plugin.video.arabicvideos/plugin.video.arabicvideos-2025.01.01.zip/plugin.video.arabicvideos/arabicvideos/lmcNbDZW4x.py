# -*- coding: utf-8 -*-
from braVAkwfBN import *
sQU2GnRoMwLK8CBdfzmNr4jXyO = 'LODYNET'
ooQEi5O6tYsGVF8LU0TC3hgMeflBwH = '_LDN_'
JaQEtCzDXgos1cdZN = gZ4LwbKaOm[sQU2GnRoMwLK8CBdfzmNr4jXyO][0]
a8GCLIuWNkS = ['الرئيسية','استفسارتكم و الطلبات']
def sHVM8YchrDjZAJ7(mode,url,text):
	if   mode==450: EA7FzO1kMZGQXDd2giB0cwLom = jihuS9LVAvTrClPapMbUEwfn8XN()
	elif mode==451: EA7FzO1kMZGQXDd2giB0cwLom = AIQeNZP4FMDw9S(url,text)
	elif mode==452: EA7FzO1kMZGQXDd2giB0cwLom = TW6Z0zqaDl(url)
	elif mode==453: EA7FzO1kMZGQXDd2giB0cwLom = Sm6cFjKyW8XTszNxi(url)
	elif mode==454: EA7FzO1kMZGQXDd2giB0cwLom = YNcMvoVF5swlDBJI7PL(url)
	elif mode==459: EA7FzO1kMZGQXDd2giB0cwLom = mUhJtHB9nw(text)
	else: EA7FzO1kMZGQXDd2giB0cwLom = False
	return EA7FzO1kMZGQXDd2giB0cwLom
def jihuS9LVAvTrClPapMbUEwfn8XN():
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',JaQEtCzDXgos1cdZN,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'LODYNET-MENU-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	ffBG4TaQU8lVF26R = F82MvyX4ThI6sbnA3efDoVS(JaQEtCzDXgos1cdZN,'url')
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'بحث في الموقع',iiy37aKq0pCEIOwfcTh61xb4U,459,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'_REMEMBERRESULTS_')
	bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'مثبتات لودي نت',ffBG4TaQU8lVF26R,451,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'featured')
	bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'المضاف حديثا',ffBG4TaQU8lVF26R,451,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'latest')
	bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"MainMenu"(.*?)"SiteSlider"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)">(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title in items:
			if fCXyTlcmF4WuetVork=='#': continue
			if title in a8GCLIuWNkS: continue
			bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,451)
	return
def AIQeNZP4FMDw9S(url,Ax2k5gsahJCBE30DfntcyXL7P=iiy37aKq0pCEIOwfcTh61xb4U):
	items = []
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'LODYNET-TITLES-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	if Ax2k5gsahJCBE30DfntcyXL7P=='featured':
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"SiteSlider"(.*?)"waves"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
	elif Ax2k5gsahJCBE30DfntcyXL7P=='latest':
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"RecentPosts"(.*?)"pagination"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
	elif '"ActorsList"' in Vxz6OndPIX4g2kaRp7:
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"ActorsList"(.*?)"text/javascript"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)"(.*?)"ActorName">(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	elif Ax2k5gsahJCBE30DfntcyXL7P in ['0','1','2']:
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"Section"(.*?)</li></ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[int(Ax2k5gsahJCBE30DfntcyXL7P)]
	else:
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"BlocksArea"(.*?)"text/javascript"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
	if not items: items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?src="(.*?)".*?<h2>(.*?)</h2>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	u3Rztpl4VHO9GZ7jCBM65kvS = []
	mxXKsCgL5OoP1evURZ8SdIfpBrwu = ['مشاهدة','فيلم','اغنية','أغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','حلقة']
	for fCXyTlcmF4WuetVork,C0dvhEbPWYlUtimM3x,title in items:
		if '"ActorsList"' in Vxz6OndPIX4g2kaRp7 and 'src=' in C0dvhEbPWYlUtimM3x:
			C0dvhEbPWYlUtimM3x = dEyT9xhGjolYzLCH7460w3.findall('src="(.*?)"',C0dvhEbPWYlUtimM3x,dEyT9xhGjolYzLCH7460w3.DOTALL)
			C0dvhEbPWYlUtimM3x = C0dvhEbPWYlUtimM3x[0]
		fCXyTlcmF4WuetVork = a9I3YZjc6ySDPE4Kp(fCXyTlcmF4WuetVork).strip('/')
		zN7sZyFnw5JTE8 = dEyT9xhGjolYzLCH7460w3.findall('(.*?) حلقة \d+',title,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if not zN7sZyFnw5JTE8: zN7sZyFnw5JTE8 = dEyT9xhGjolYzLCH7460w3.findall('(.*?) الحلقة \d+',title,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if set(title.split()) & set(mxXKsCgL5OoP1evURZ8SdIfpBrwu) and 'مسلسل' not in title:
			bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,452,C0dvhEbPWYlUtimM3x)
		elif zN7sZyFnw5JTE8 and 'حلقة' in title:
			title = '_MOD_' + zN7sZyFnw5JTE8[0]
			if title not in u3Rztpl4VHO9GZ7jCBM65kvS:
				bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,453,C0dvhEbPWYlUtimM3x)
				u3Rztpl4VHO9GZ7jCBM65kvS.append(title)
		elif '/category/' in fCXyTlcmF4WuetVork: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,451,C0dvhEbPWYlUtimM3x)
		else: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,453,C0dvhEbPWYlUtimM3x)
	if Ax2k5gsahJCBE30DfntcyXL7P in [iiy37aKq0pCEIOwfcTh61xb4U,'latest']:
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"pagination"(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if UUIohmv597bO83YCLgWS:
			PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
			items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?>(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
			for fCXyTlcmF4WuetVork,title in items:
				title = JIY6A30UOsQboNVqCn(title)
				bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'صفحة '+title,fCXyTlcmF4WuetVork,451)
	return
def Sm6cFjKyW8XTszNxi(url):
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'LODYNET-SEASONS-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	HG5rE20ORdbqUKWewuZCJP4zoXF6g = dEyT9xhGjolYzLCH7460w3.findall('"CategorySubLinks"(.*?)</div>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if HG5rE20ORdbqUKWewuZCJP4zoXF6g and 'href=' in str(HG5rE20ORdbqUKWewuZCJP4zoXF6g):
		title = dEyT9xhGjolYzLCH7460w3.findall('<title>(.*?)-',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		title = title[0].strip(iFBmE2MUIpSu34wsd7Rf6z)
		bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,url,454)
		PPH1sQtTkDBbnlYpZfo5 = HG5rE20ORdbqUKWewuZCJP4zoXF6g[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)">(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title in items:
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,454)
	else: YNcMvoVF5swlDBJI7PL(url)
	return
def YNcMvoVF5swlDBJI7PL(url):
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'LODYNET-EPISODES-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	eTov6CfDcRZVJEAq5BH = dEyT9xhGjolYzLCH7460w3.findall('"ListEpisodes"(.*?)</div>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if eTov6CfDcRZVJEAq5BH:
		C0dvhEbPWYlUtimM3x = dEyT9xhGjolYzLCH7460w3.findall('"og:image" content="(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		C0dvhEbPWYlUtimM3x = C0dvhEbPWYlUtimM3x[0] if C0dvhEbPWYlUtimM3x else iiy37aKq0pCEIOwfcTh61xb4U
		PPH1sQtTkDBbnlYpZfo5 = eTov6CfDcRZVJEAq5BH[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)" title="(.*?)"',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title in items: bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,452,C0dvhEbPWYlUtimM3x)
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"pagination"(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if UUIohmv597bO83YCLgWS:
			PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
			items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?>(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
			for fCXyTlcmF4WuetVork,title in items:
				title = JIY6A30UOsQboNVqCn(title)
				bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'صفحة '+title,fCXyTlcmF4WuetVork,454)
	return
def TW6Z0zqaDl(url):
	ff2PjlcCF5ZWyIUbVguMz,fwDKASjdbmGvouLTFke = [],[]
	eCGwzSrqBmIv = url.replace('/movies/','/watch_movies/')
	eCGwzSrqBmIv = eCGwzSrqBmIv.replace('/episodes/','/watch_episodes/')
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',eCGwzSrqBmIv,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'LODYNET-PLAY-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	fCXyTlcmF4WuetVork = dEyT9xhGjolYzLCH7460w3.findall('\'<iframe src="(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if fCXyTlcmF4WuetVork:
		fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork[0]
		if fCXyTlcmF4WuetVork not in fwDKASjdbmGvouLTFke:
			fwDKASjdbmGvouLTFke.append(fCXyTlcmF4WuetVork)
			Zw4M5DUStdE6xp7GI = F82MvyX4ThI6sbnA3efDoVS(fCXyTlcmF4WuetVork,'name')
			fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork+'?named='+Zw4M5DUStdE6xp7GI+'__embed'
			ff2PjlcCF5ZWyIUbVguMz.append(fCXyTlcmF4WuetVork)
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"AllServerWatch"(.*?)</div>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall("SwitchServer\(this, '(.*?)'\)\">(.*?)<",PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title in items:
			if fCXyTlcmF4WuetVork in fwDKASjdbmGvouLTFke: continue
			fwDKASjdbmGvouLTFke.append(fCXyTlcmF4WuetVork)
			fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork+'?named='+title+'__watch'
			ff2PjlcCF5ZWyIUbVguMz.append(fCXyTlcmF4WuetVork)
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"ListServerDownload"(.*?)</div>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)" title="(.*?)"',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,name in items:
			if fCXyTlcmF4WuetVork in fwDKASjdbmGvouLTFke: continue
			fwDKASjdbmGvouLTFke.append(fCXyTlcmF4WuetVork)
			name = JIY6A30UOsQboNVqCn(name)
			pMAWqrwP80lR = dEyT9xhGjolYzLCH7460w3.findall('\d\d\d+',name,dEyT9xhGjolYzLCH7460w3.DOTALL)
			if pMAWqrwP80lR:
				pMAWqrwP80lR = '____'+pMAWqrwP80lR[0]
				name = iiy37aKq0pCEIOwfcTh61xb4U
			else: pMAWqrwP80lR = iiy37aKq0pCEIOwfcTh61xb4U
			fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork+'?named='+name+'__download'+pMAWqrwP80lR
			ff2PjlcCF5ZWyIUbVguMz.append(fCXyTlcmF4WuetVork)
	import lqBJGK8hXO
	lqBJGK8hXO.ZDg1HavwueT85mcAOorC4hnS(ff2PjlcCF5ZWyIUbVguMz,sQU2GnRoMwLK8CBdfzmNr4jXyO,'video',url)
	return
def mUhJtHB9nw(search):
	search,brFQp5vmgJWdZfEkCBOlu9c,showDialogs = XkYnev3ZCA6ahO94(search)
	if search==iiy37aKq0pCEIOwfcTh61xb4U: search = TTBf6S08q1NKXd5v9wa()
	if search==iiy37aKq0pCEIOwfcTh61xb4U: return
	search = search.replace(iFBmE2MUIpSu34wsd7Rf6z,'+')
	url = JaQEtCzDXgos1cdZN+'/search/'+search
	AIQeNZP4FMDw9S(url)
	return
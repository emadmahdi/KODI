# -*- coding: utf-8 -*-
from braVAkwfBN import *
headers = { 'User-Agent' : iiy37aKq0pCEIOwfcTh61xb4U }
sQU2GnRoMwLK8CBdfzmNr4jXyO = 'AKOAMCAM'
ooQEi5O6tYsGVF8LU0TC3hgMeflBwH = '_AKC_'
JaQEtCzDXgos1cdZN = gZ4LwbKaOm[sQU2GnRoMwLK8CBdfzmNr4jXyO][0]
a8GCLIuWNkS = ['مصارعة']
def sHVM8YchrDjZAJ7(mode,url,text):
	if   mode==350: EA7FzO1kMZGQXDd2giB0cwLom = jihuS9LVAvTrClPapMbUEwfn8XN()
	elif mode==351: EA7FzO1kMZGQXDd2giB0cwLom = AIQeNZP4FMDw9S(url,text)
	elif mode==352: EA7FzO1kMZGQXDd2giB0cwLom = YNcMvoVF5swlDBJI7PL(url)
	elif mode==353: EA7FzO1kMZGQXDd2giB0cwLom = TW6Z0zqaDl(url)
	elif mode==354: EA7FzO1kMZGQXDd2giB0cwLom = chQHNdWgTSDjti8R9pJUf(url,'FILTERS___'+text)
	elif mode==355: EA7FzO1kMZGQXDd2giB0cwLom = chQHNdWgTSDjti8R9pJUf(url,'CATEGORIES___'+text)
	elif mode==356: EA7FzO1kMZGQXDd2giB0cwLom = t6tlwLNPW7qkI4geboF2mYd(url)
	elif mode==357: EA7FzO1kMZGQXDd2giB0cwLom = jHi7sKno9cG(url)
	elif mode==359: EA7FzO1kMZGQXDd2giB0cwLom = mUhJtHB9nw(text)
	else: EA7FzO1kMZGQXDd2giB0cwLom = False
	return EA7FzO1kMZGQXDd2giB0cwLom
def jihuS9LVAvTrClPapMbUEwfn8XN():
	bP6z3OSLp7va('link',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+aqEsMBckT2bunGHfl48Wip+'هذا الموقع مغلق'+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,8)
	bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'بحث في الموقع',iiy37aKq0pCEIOwfcTh61xb4U,359,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'_REMEMBERRESULTS_')
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'فلتر محدد',JaQEtCzDXgos1cdZN,356)
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'فلتر كامل',JaQEtCzDXgos1cdZN,357)
	bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(PNjZMS7nxa9clHusz1,JaQEtCzDXgos1cdZN,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,'AKOAMCAM-MENU-1st')
	eCGwzSrqBmIv = dEyT9xhGjolYzLCH7460w3.findall('recently-container.*?href="(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if eCGwzSrqBmIv: eCGwzSrqBmIv = eCGwzSrqBmIv[0]
	else: eCGwzSrqBmIv = JaQEtCzDXgos1cdZN
	bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'اضيف حديثا',eCGwzSrqBmIv,351)
	eCGwzSrqBmIv = dEyT9xhGjolYzLCH7460w3.findall('@id":"(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if eCGwzSrqBmIv: eCGwzSrqBmIv = eCGwzSrqBmIv[0]
	else: eCGwzSrqBmIv = JaQEtCzDXgos1cdZN
	bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'المميزة',eCGwzSrqBmIv,351,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'featured')
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('main-categories-list(.*?)main-categories-list',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?class="font.*?>(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title in items:
			if title not in a8GCLIuWNkS: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,351)
		bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('class="categories-box(.*?)<footer',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?">(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title in items:
			fCXyTlcmF4WuetVork = JIY6A30UOsQboNVqCn(fCXyTlcmF4WuetVork)
			if title not in a8GCLIuWNkS: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,351)
	return Vxz6OndPIX4g2kaRp7
def t6tlwLNPW7qkI4geboF2mYd(website=iiy37aKq0pCEIOwfcTh61xb4U):
	Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(Dxc7GChQwZ4kOlKHSbL06agnB,JaQEtCzDXgos1cdZN,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,'AKOAMCAM-MENU-1st')
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('class="menu(.*?)<nav',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?text">(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title in items:
			if title not in a8GCLIuWNkS:
				title = title+' مصنفة'
				bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,355)
		if website==iiy37aKq0pCEIOwfcTh61xb4U: bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	return Vxz6OndPIX4g2kaRp7
def jHi7sKno9cG(website=iiy37aKq0pCEIOwfcTh61xb4U):
	Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(Dxc7GChQwZ4kOlKHSbL06agnB,JaQEtCzDXgos1cdZN,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,'AKOAMCAM-MENU-1st')
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('class="menu(.*?)<nav',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?text">(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title in items:
			if title not in a8GCLIuWNkS:
				title = title+' مفلترة'
				bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,354)
		if website==iiy37aKq0pCEIOwfcTh61xb4U: bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	return Vxz6OndPIX4g2kaRp7
def AIQeNZP4FMDw9S(url,type=iiy37aKq0pCEIOwfcTh61xb4U):
	Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(hI7SkXd94fFzAHNZCQoMqEutbnWP,url,iiy37aKq0pCEIOwfcTh61xb4U,headers,True,'AKOAMCAM-TITLES-1st')
	if type=='featured': UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('swiper-container(.*?)swiper-button-prev',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	else: UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('class="container"(.*?)main-footer',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('xlink:href="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		u3Rztpl4VHO9GZ7jCBM65kvS = []
		for C0dvhEbPWYlUtimM3x,fCXyTlcmF4WuetVork,title in items:
			title = JIY6A30UOsQboNVqCn(title)
			if 'الحلقة' in title or 'الحلقه' in title:
				zN7sZyFnw5JTE8 = dEyT9xhGjolYzLCH7460w3.findall('(.*?) (الحلقة|الحلقه) \d+',title,dEyT9xhGjolYzLCH7460w3.DOTALL)
				if zN7sZyFnw5JTE8:
					title = '_MOD_' + zN7sZyFnw5JTE8[0][0]
					if title not in u3Rztpl4VHO9GZ7jCBM65kvS:
						bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,352,C0dvhEbPWYlUtimM3x)
						u3Rztpl4VHO9GZ7jCBM65kvS.append(title)
			elif 'مسلسل' in title:
				bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,352,C0dvhEbPWYlUtimM3x)
			else: bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,353,C0dvhEbPWYlUtimM3x)
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('pagination(.*?)</div>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href=["\'](.*?)["\'].*?>(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title in items:
			fCXyTlcmF4WuetVork = JIY6A30UOsQboNVqCn(fCXyTlcmF4WuetVork)
			title = JIY6A30UOsQboNVqCn(title)
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'صفحة '+title,fCXyTlcmF4WuetVork,351)
	return
def mUhJtHB9nw(search):
	search,brFQp5vmgJWdZfEkCBOlu9c,showDialogs = XkYnev3ZCA6ahO94(search)
	if search==iiy37aKq0pCEIOwfcTh61xb4U: search = TTBf6S08q1NKXd5v9wa()
	if search==iiy37aKq0pCEIOwfcTh61xb4U: return
	VVOtdjT9AF4Wk3GECqHL = search.replace(iFBmE2MUIpSu34wsd7Rf6z,'+')
	url = JaQEtCzDXgos1cdZN + '/?s='+VVOtdjT9AF4Wk3GECqHL
	EA7FzO1kMZGQXDd2giB0cwLom = AIQeNZP4FMDw9S(url)
	return
def YNcMvoVF5swlDBJI7PL(url):
	Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(PNjZMS7nxa9clHusz1,url,iiy37aKq0pCEIOwfcTh61xb4U,headers,True,'AKOAMCAM-EPISODES-1st')
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('text-white">الحلقات(.*?)<header',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		f9a8L1lCJvn6pIUuP = dEyT9xhGjolYzLCH7460w3.findall('href="(http.*?)".*?src="(.*?)".*?alt="(.*?)"',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,C0dvhEbPWYlUtimM3x,title in f9a8L1lCJvn6pIUuP:
			if 'الحلقة' in title or 'الحلقه' in title: bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,353,C0dvhEbPWYlUtimM3x)
	else:
		C0dvhEbPWYlUtimM3x = WwMgozBIC32n9d0tyfp.getInfoLabel('ListItem.Icon')
		if Vxz6OndPIX4g2kaRp7.count('<title>')>1: title = dEyT9xhGjolYzLCH7460w3.findall('<title>(.*?)<',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)[1]
		else: title = 'رابط التشغيل'
		bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,url,353,C0dvhEbPWYlUtimM3x)
	return
def TW6Z0zqaDl(url):
	duef0gb3Mi1AV5WpN8,A7Ap2wdlxM = [],[]
	c7MhGgVw9n2TWQKvD1itHXZBFSjs = MMCJxEfv0WUek(Dxc7GChQwZ4kOlKHSbL06agnB,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'AKOAMCAM-PLAY-1st')
	Vxz6OndPIX4g2kaRp7 = c7MhGgVw9n2TWQKvD1itHXZBFSjs.content
	VlX2C0mPxeyD8wZYKLuf = dEyT9xhGjolYzLCH7460w3.findall('post_id=(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if VlX2C0mPxeyD8wZYKLuf:
		VlX2C0mPxeyD8wZYKLuf = VlX2C0mPxeyD8wZYKLuf[0]
		headers = {'User-Agent':iiy37aKq0pCEIOwfcTh61xb4U,'Content-Type':'application/x-www-form-urlencoded'}
		data = {'post_id':VlX2C0mPxeyD8wZYKLuf}
		eCGwzSrqBmIv = JaQEtCzDXgos1cdZN+'/wp-content/themes/aflam8kkk/Inc/Ajax/Single/Watch.php'
		NcBWnVIKpqgPu7i8LJX = MMCJxEfv0WUek(Dxc7GChQwZ4kOlKHSbL06agnB,'POST',eCGwzSrqBmIv,data,headers,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'AKOAMCAM-PLAY-1st')
		z0spMAOfJElv6L1K9ae = NcBWnVIKpqgPu7i8LJX.content
		items = dEyT9xhGjolYzLCH7460w3.findall('data-server="(.*?)".*?class="text">(.*?)<',z0spMAOfJElv6L1K9ae,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for w7dRclJi29IUOqP,name in items:
			fCXyTlcmF4WuetVork = 'https://w.akoam.cam/wp-content/themes/aflam8kkk/Inc/Ajax/Single/Server.php'
			fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork+'?postid='+VlX2C0mPxeyD8wZYKLuf+'&serverid='+w7dRclJi29IUOqP+'?named='+name+'__watch'
			duef0gb3Mi1AV5WpN8.append(fCXyTlcmF4WuetVork)
			A7Ap2wdlxM.append(name)
		eCGwzSrqBmIv = JaQEtCzDXgos1cdZN+'/wp-content/themes/aflam8kkk/Inc/Ajax/Single/Download.php'
		NcBWnVIKpqgPu7i8LJX = MMCJxEfv0WUek(Dxc7GChQwZ4kOlKHSbL06agnB,'POST',eCGwzSrqBmIv,data,headers,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'AKOAMCAM-PLAY-1st')
		z0spMAOfJElv6L1K9ae = NcBWnVIKpqgPu7i8LJX.content
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?class="text">(.*?)<',z0spMAOfJElv6L1K9ae,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title in items:
			fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork.strip(iFBmE2MUIpSu34wsd7Rf6z)
			fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork+'?named='+title+'__download'
			duef0gb3Mi1AV5WpN8.append(fCXyTlcmF4WuetVork)
			A7Ap2wdlxM.append(title)
	import lqBJGK8hXO
	lqBJGK8hXO.ZDg1HavwueT85mcAOorC4hnS(duef0gb3Mi1AV5WpN8,sQU2GnRoMwLK8CBdfzmNr4jXyO,'video',url)
	return
def chQHNdWgTSDjti8R9pJUf(url,filter):
	JYMlXTc9DCZrohd = ['cat','genre','release-year','quality','orderby']
	if '?' in url: url = url.split('?')[0]
	type,filter = filter.split('___',1)
	if filter==iiy37aKq0pCEIOwfcTh61xb4U: Mhd9LWrfiF1EsASl6eP34uTp0qNGom,ovh6cXGg1qd85fn3CSJEisTlI7Yz = iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U
	else: Mhd9LWrfiF1EsASl6eP34uTp0qNGom,ovh6cXGg1qd85fn3CSJEisTlI7Yz = filter.split('___')
	if type=='CATEGORIES':
		if JYMlXTc9DCZrohd[0]+'=' not in Mhd9LWrfiF1EsASl6eP34uTp0qNGom: RRIscyLmNH9dq2Dio3TSr = JYMlXTc9DCZrohd[0]
		for iEfNKT3velFyGth80SA4pxbCRrVD in range(len(JYMlXTc9DCZrohd[0:-1])):
			if JYMlXTc9DCZrohd[iEfNKT3velFyGth80SA4pxbCRrVD]+'=' in Mhd9LWrfiF1EsASl6eP34uTp0qNGom: RRIscyLmNH9dq2Dio3TSr = JYMlXTc9DCZrohd[iEfNKT3velFyGth80SA4pxbCRrVD+1]
		HdFJThcNtWe3lb8n4OmaSwQ = Mhd9LWrfiF1EsASl6eP34uTp0qNGom+'&'+RRIscyLmNH9dq2Dio3TSr+'=0'
		vvlVH6JT9YDNPeSaRUkKCAwpr5uq = ovh6cXGg1qd85fn3CSJEisTlI7Yz+'&'+RRIscyLmNH9dq2Dio3TSr+'=0'
		cCZR4YdwUepABD9mQsubT8FgN = HdFJThcNtWe3lb8n4OmaSwQ.strip('&')+'___'+vvlVH6JT9YDNPeSaRUkKCAwpr5uq.strip('&')
		bPXk8KHyCUrifag = qJ8NQtuWARGjoZd9swfbH(ovh6cXGg1qd85fn3CSJEisTlI7Yz,'all')
		eCGwzSrqBmIv = url+'?'+bPXk8KHyCUrifag
	elif type=='FILTERS':
		GMQ6AxE012X9 = qJ8NQtuWARGjoZd9swfbH(Mhd9LWrfiF1EsASl6eP34uTp0qNGom,'modified_values')
		GMQ6AxE012X9 = a9I3YZjc6ySDPE4Kp(GMQ6AxE012X9)
		if ovh6cXGg1qd85fn3CSJEisTlI7Yz!=iiy37aKq0pCEIOwfcTh61xb4U: ovh6cXGg1qd85fn3CSJEisTlI7Yz = qJ8NQtuWARGjoZd9swfbH(ovh6cXGg1qd85fn3CSJEisTlI7Yz,'all')
		if ovh6cXGg1qd85fn3CSJEisTlI7Yz==iiy37aKq0pCEIOwfcTh61xb4U: eCGwzSrqBmIv = url
		else: eCGwzSrqBmIv = url+'?'+ovh6cXGg1qd85fn3CSJEisTlI7Yz
		bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'أظهار قائمة الفيديو التي تم اختيارها',eCGwzSrqBmIv,351,iiy37aKq0pCEIOwfcTh61xb4U,'1')
		bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+' [[   '+GMQ6AxE012X9+'   ]]',eCGwzSrqBmIv,351,iiy37aKq0pCEIOwfcTh61xb4U,'1')
		bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(Dxc7GChQwZ4kOlKHSbL06agnB,url,iiy37aKq0pCEIOwfcTh61xb4U,headers,True,'AKOAMCAM-FILTERS_MENU-1st')
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('<form id(.*?)</form>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
	n8nFIQBNaXD = dEyT9xhGjolYzLCH7460w3.findall('<select.*?name="(.*?)".*?">(.*?)<(.*?)</select>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	dict = {}
	for cWhMpFIbQU4D1Bi,name,PPH1sQtTkDBbnlYpZfo5 in n8nFIQBNaXD:
		items = dEyT9xhGjolYzLCH7460w3.findall('<option(.*?)>(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if '=' not in eCGwzSrqBmIv: eCGwzSrqBmIv = url
		if type=='CATEGORIES':
			if RRIscyLmNH9dq2Dio3TSr!=cWhMpFIbQU4D1Bi: continue
			elif len(items)<=1:
				if cWhMpFIbQU4D1Bi==JYMlXTc9DCZrohd[-1]: AIQeNZP4FMDw9S(eCGwzSrqBmIv)
				else: chQHNdWgTSDjti8R9pJUf(eCGwzSrqBmIv,'CATEGORIES___'+cCZR4YdwUepABD9mQsubT8FgN)
				return
			else:
				if cWhMpFIbQU4D1Bi==JYMlXTc9DCZrohd[-1]: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'الجميع',eCGwzSrqBmIv,351,iiy37aKq0pCEIOwfcTh61xb4U,'1')
				else: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'الجميع',eCGwzSrqBmIv,355,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,cCZR4YdwUepABD9mQsubT8FgN)
		elif type=='FILTERS':
			HdFJThcNtWe3lb8n4OmaSwQ = Mhd9LWrfiF1EsASl6eP34uTp0qNGom+'&'+cWhMpFIbQU4D1Bi+'=0'
			vvlVH6JT9YDNPeSaRUkKCAwpr5uq = ovh6cXGg1qd85fn3CSJEisTlI7Yz+'&'+cWhMpFIbQU4D1Bi+'=0'
			cCZR4YdwUepABD9mQsubT8FgN = HdFJThcNtWe3lb8n4OmaSwQ+'___'+vvlVH6JT9YDNPeSaRUkKCAwpr5uq
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'الجميع : '+name,eCGwzSrqBmIv,354,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,cCZR4YdwUepABD9mQsubT8FgN)
		dict[cWhMpFIbQU4D1Bi] = {}
		for aasX2cby4Vo5rTgB,KjsA38t0DCSmuLcaE in items:
			if KjsA38t0DCSmuLcaE in a8GCLIuWNkS: continue
			if 'value' not in aasX2cby4Vo5rTgB: aasX2cby4Vo5rTgB = KjsA38t0DCSmuLcaE
			else: aasX2cby4Vo5rTgB = dEyT9xhGjolYzLCH7460w3.findall('"(.*?)"',aasX2cby4Vo5rTgB,dEyT9xhGjolYzLCH7460w3.DOTALL)[0]
			dict[cWhMpFIbQU4D1Bi][aasX2cby4Vo5rTgB] = KjsA38t0DCSmuLcaE
			HdFJThcNtWe3lb8n4OmaSwQ = Mhd9LWrfiF1EsASl6eP34uTp0qNGom+'&'+cWhMpFIbQU4D1Bi+'='+KjsA38t0DCSmuLcaE
			vvlVH6JT9YDNPeSaRUkKCAwpr5uq = ovh6cXGg1qd85fn3CSJEisTlI7Yz+'&'+cWhMpFIbQU4D1Bi+'='+aasX2cby4Vo5rTgB
			kuyfTIwjRrhXUo = HdFJThcNtWe3lb8n4OmaSwQ+'___'+vvlVH6JT9YDNPeSaRUkKCAwpr5uq
			title = KjsA38t0DCSmuLcaE+' : '#+dict[cWhMpFIbQU4D1Bi]['0']
			title = KjsA38t0DCSmuLcaE+' : '+name
			if type=='FILTERS': bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,url,354,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,kuyfTIwjRrhXUo)
			elif type=='CATEGORIES' and JYMlXTc9DCZrohd[-2]+'=' in Mhd9LWrfiF1EsASl6eP34uTp0qNGom:
				bPXk8KHyCUrifag = qJ8NQtuWARGjoZd9swfbH(vvlVH6JT9YDNPeSaRUkKCAwpr5uq,'all')
				O5Pwg3UFyX0k9E = url+'?'+bPXk8KHyCUrifag
				bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,O5Pwg3UFyX0k9E,351,iiy37aKq0pCEIOwfcTh61xb4U,'1')
			else: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,url,355,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,kuyfTIwjRrhXUo)
	return
def qJ8NQtuWARGjoZd9swfbH(HSAqBpsb2jRLvk9lx147rzY,mode):
	HSAqBpsb2jRLvk9lx147rzY = HSAqBpsb2jRLvk9lx147rzY.strip('&')
	x8UiIH3WCTEpe = {}
	if '=' in HSAqBpsb2jRLvk9lx147rzY:
		items = HSAqBpsb2jRLvk9lx147rzY.split('&')
		for YXD9KNfjCaLwkcrvJxldn7I in items:
			xYkDXe5UjvETygJNLrRQ96mtp8BKGW,aasX2cby4Vo5rTgB = YXD9KNfjCaLwkcrvJxldn7I.split('=')
			x8UiIH3WCTEpe[xYkDXe5UjvETygJNLrRQ96mtp8BKGW] = aasX2cby4Vo5rTgB
	QAvGYocVXgzh9 = iiy37aKq0pCEIOwfcTh61xb4U
	a3aiAqYngfydR1XNJK975wl4jD = ['cat','genre','release-year','quality','orderby']
	for key in a3aiAqYngfydR1XNJK975wl4jD:
		if key in list(x8UiIH3WCTEpe.keys()): aasX2cby4Vo5rTgB = x8UiIH3WCTEpe[key]
		else: aasX2cby4Vo5rTgB = '0'
		if mode=='modified_values' and aasX2cby4Vo5rTgB!='0': QAvGYocVXgzh9 = QAvGYocVXgzh9+' + '+aasX2cby4Vo5rTgB
		elif mode=='modified_filters' and aasX2cby4Vo5rTgB!='0': QAvGYocVXgzh9 = QAvGYocVXgzh9+'&'+key+'='+aasX2cby4Vo5rTgB
		elif mode=='all': QAvGYocVXgzh9 = QAvGYocVXgzh9+'&'+key+'='+aasX2cby4Vo5rTgB
	QAvGYocVXgzh9 = QAvGYocVXgzh9.strip(' + ')
	QAvGYocVXgzh9 = QAvGYocVXgzh9.strip('&')
	return QAvGYocVXgzh9
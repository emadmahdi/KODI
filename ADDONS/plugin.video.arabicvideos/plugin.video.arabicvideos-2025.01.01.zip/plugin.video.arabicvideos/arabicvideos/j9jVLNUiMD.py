# -*- coding: utf-8 -*-
from braVAkwfBN import *
sQU2GnRoMwLK8CBdfzmNr4jXyO = 'FAJERSHOW'
ooQEi5O6tYsGVF8LU0TC3hgMeflBwH = '_FJS_'
JaQEtCzDXgos1cdZN = gZ4LwbKaOm[sQU2GnRoMwLK8CBdfzmNr4jXyO][0]
a8GCLIuWNkS = ['التصنيفات','انشاء حساب','طلبات الزوّار']
def sHVM8YchrDjZAJ7(mode,url,text):
	if   mode==390: EA7FzO1kMZGQXDd2giB0cwLom = jihuS9LVAvTrClPapMbUEwfn8XN()
	elif mode==391: EA7FzO1kMZGQXDd2giB0cwLom = AIQeNZP4FMDw9S(url,text)
	elif mode==392: EA7FzO1kMZGQXDd2giB0cwLom = TW6Z0zqaDl(url)
	elif mode==393: EA7FzO1kMZGQXDd2giB0cwLom = YNcMvoVF5swlDBJI7PL(url)
	elif mode==399: EA7FzO1kMZGQXDd2giB0cwLom = mUhJtHB9nw(text)
	else: EA7FzO1kMZGQXDd2giB0cwLom = False
	return EA7FzO1kMZGQXDd2giB0cwLom
def jihuS9LVAvTrClPapMbUEwfn8XN():
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'بحث في الموقع',iiy37aKq0pCEIOwfcTh61xb4U,399,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'_REMEMBERRESULTS_')
	bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(Dxc7GChQwZ4kOlKHSbL06agnB,'GET',JaQEtCzDXgos1cdZN,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'FAJERSHOW-MENU-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	items = dEyT9xhGjolYzLCH7460w3.findall('<header>.*?<h2>(.*?)<',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	for rxbivCFQ9aAnpckTUXYh65dH4 in range(len(items)):
		title = items[rxbivCFQ9aAnpckTUXYh65dH4]
		bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,JaQEtCzDXgos1cdZN,391,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'latest'+str(rxbivCFQ9aAnpckTUXYh65dH4))
	bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'مختارات عشوائية',JaQEtCzDXgos1cdZN,391,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'randoms')
	bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'أعلى الأفلام تقييماً',JaQEtCzDXgos1cdZN,391,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'top_imdb_movies')
	bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'أعلى المسلسلات تقييماً',JaQEtCzDXgos1cdZN,391,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'top_imdb_series')
	bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'أفلام مميزة',JaQEtCzDXgos1cdZN+'/movies',391,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'featured_movies')
	bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'مسلسلات مميزة',JaQEtCzDXgos1cdZN+'/tvshows',391,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'featured_tvshows')
	PPH1sQtTkDBbnlYpZfo5 = iiy37aKq0pCEIOwfcTh61xb4U
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('class="menu"(.*?)id="contenedor"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS: PPH1sQtTkDBbnlYpZfo5 += UUIohmv597bO83YCLgWS[0]
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(Dxc7GChQwZ4kOlKHSbL06agnB,'GET',JaQEtCzDXgos1cdZN+'/movies',iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'FAJERSHOW-MENU-2nd')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('class="releases"(.*?)aside',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS: PPH1sQtTkDBbnlYpZfo5 += UUIohmv597bO83YCLgWS[0]
	bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)">(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	wijqr6NndVsJmg = True
	for fCXyTlcmF4WuetVork,title in items:
		title = JIY6A30UOsQboNVqCn(title)
		if title=='الأعلى مشاهدة':
			if wijqr6NndVsJmg:
				title = 'الافلام '+title
				wijqr6NndVsJmg = False
			else: title = 'المسلسلات '+title
		if title not in a8GCLIuWNkS:
			if title=='أفلام': bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,JaQEtCzDXgos1cdZN+'/movies',391,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'all_movies_tvshows')
			elif title=='مسلسلات': bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,JaQEtCzDXgos1cdZN+'/tvshows',391,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'all_movies_tvshows')
			else: bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,391)
	return Vxz6OndPIX4g2kaRp7
def AIQeNZP4FMDw9S(url,type):
	PPH1sQtTkDBbnlYpZfo5,items = [],[]
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'FAJERSHOW-TITLES-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	if type in ['featured_movies','featured_tvshows']:
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('class="content"(.*?)id="archive-content"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if UUIohmv597bO83YCLgWS: PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
	elif type=='all_movies_tvshows':
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('id="archive-content"(.*?)class="pagination"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if UUIohmv597bO83YCLgWS: PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
	elif type=='top_imdb_movies':
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall("class='top-imdb-list tleft(.*?)class='top-imdb-list tright",Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if UUIohmv597bO83YCLgWS:
			PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
			items = dEyT9xhGjolYzLCH7460w3.findall("img src='(.*?)'.*?href='(.*?)'>(.*?)<",PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	elif type=='top_imdb_series':
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall("class='top-imdb-list tright(.*?)footer",Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if UUIohmv597bO83YCLgWS:
			PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
			items = dEyT9xhGjolYzLCH7460w3.findall("img src='(.*?)'.*?href='(.*?)'>(.*?)<",PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	elif type=='search':
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('class="search-page"(.*?)class="sidebar',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if UUIohmv597bO83YCLgWS:
			PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
			items = dEyT9xhGjolYzLCH7460w3.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	elif type=='sider':
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('class="widget(.*?)class="widget',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		c1CH6qPe8oZX3irhEgAzuxm5 = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?img src="(.*?)".*?<h3>(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		duef0gb3Mi1AV5WpN8,Xhv6TR9tW3M5wOnide0LEq1fF,A7Ap2wdlxM = zip(*c1CH6qPe8oZX3irhEgAzuxm5)
		items = zip(Xhv6TR9tW3M5wOnide0LEq1fF,duef0gb3Mi1AV5WpN8,A7Ap2wdlxM)
	elif type=='randoms':
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('id="slider-movies-tvshows"(.*?)<header>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	elif 'latest' in type:
		rxbivCFQ9aAnpckTUXYh65dH4 = int(type[-1:])
		Vxz6OndPIX4g2kaRp7 = Vxz6OndPIX4g2kaRp7.replace('<header>','<end><start>')
		Vxz6OndPIX4g2kaRp7 = Vxz6OndPIX4g2kaRp7.replace('</div></div></div>','</div></div></div><end>')
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('<start>(.*?)<end>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[rxbivCFQ9aAnpckTUXYh65dH4]
		if rxbivCFQ9aAnpckTUXYh65dH4==6:
			c1CH6qPe8oZX3irhEgAzuxm5 = dEyT9xhGjolYzLCH7460w3.findall('img src="(.*?)" alt="(.*?)".*?href="(.*?)"',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
			Xhv6TR9tW3M5wOnide0LEq1fF,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = zip(*c1CH6qPe8oZX3irhEgAzuxm5)
			items = zip(Xhv6TR9tW3M5wOnide0LEq1fF,duef0gb3Mi1AV5WpN8,A7Ap2wdlxM)
	else:
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('class="content"(.*?)class="(pagination|sidebar)',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if UUIohmv597bO83YCLgWS:
			PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0][0]
			if '/collection/' in url:
				items = dEyT9xhGjolYzLCH7460w3.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
			elif '/quality/' in url:
				items = dEyT9xhGjolYzLCH7460w3.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if not items and PPH1sQtTkDBbnlYpZfo5:
		items = dEyT9xhGjolYzLCH7460w3.findall('img src="(.*?)".*?href=.*?href="(.*?)">(.*?)</div>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	u3Rztpl4VHO9GZ7jCBM65kvS = []
	for C0dvhEbPWYlUtimM3x,fCXyTlcmF4WuetVork,title in items:
		if 'src=' in title: continue
		if 'serie' in title:
			title = dEyT9xhGjolYzLCH7460w3.findall('^(.*?)<.*?serie">(.*?)<',title,dEyT9xhGjolYzLCH7460w3.DOTALL)
			title = title[0][1]
			if title in u3Rztpl4VHO9GZ7jCBM65kvS: continue
			u3Rztpl4VHO9GZ7jCBM65kvS.append(title)
			title = '_MOD_'+title
		Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb = dEyT9xhGjolYzLCH7460w3.findall('^(.*?)<',title,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb: title = Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb[0]
		title = JIY6A30UOsQboNVqCn(title)
		if '/tvshows/' in fCXyTlcmF4WuetVork: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,393,C0dvhEbPWYlUtimM3x)
		elif '/episodes/' in fCXyTlcmF4WuetVork: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,393,C0dvhEbPWYlUtimM3x)
		elif '/seasons/' in fCXyTlcmF4WuetVork: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,393,C0dvhEbPWYlUtimM3x)
		elif '/collection/' in fCXyTlcmF4WuetVork: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,391,C0dvhEbPWYlUtimM3x)
		else: bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,392,C0dvhEbPWYlUtimM3x)
	if type not in ['featured_movies','featured_tvshows']:
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"pagination"(.*?)</div>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if UUIohmv597bO83YCLgWS:
			PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
			items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?>(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
			for fCXyTlcmF4WuetVork,title in items:
				bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'صفحة '+title,fCXyTlcmF4WuetVork,391,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,type)
	return
def YNcMvoVF5swlDBJI7PL(url):
	Zw4M5DUStdE6xp7GI = F82MvyX4ThI6sbnA3efDoVS(url,'url')
	url = url.replace(Zw4M5DUStdE6xp7GI,JaQEtCzDXgos1cdZN)
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'FAJERSHOW-EPISODES-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	UAhMnV3r89cWy7X1D05GBCwTqOP4p = dEyT9xhGjolYzLCH7460w3.findall('class="C rated".*?>(.*?)<',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UAhMnV3r89cWy7X1D05GBCwTqOP4p and IUF8hYKEGLmHDtXbuWNvnJ(sQU2GnRoMwLK8CBdfzmNr4jXyO,url,UAhMnV3r89cWy7X1D05GBCwTqOP4p): return
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('<ul class="episodios">(.*?)</ul></div></div></div>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('src="(.*?)".*?href="(.*?)">(.*?)</a>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for C0dvhEbPWYlUtimM3x,fCXyTlcmF4WuetVork,title in items:
			bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,392,C0dvhEbPWYlUtimM3x)
	return
def TW6Z0zqaDl(url):
	Vxz6OndPIX4g2kaRp7 = paTWAORBQdvnfDjmyMxShugelKzZ8(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'FAJERSHOW-PLAY-1st')
	UAhMnV3r89cWy7X1D05GBCwTqOP4p = dEyT9xhGjolYzLCH7460w3.findall('class="C rated".*?>(.*?)<',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UAhMnV3r89cWy7X1D05GBCwTqOP4p and IUF8hYKEGLmHDtXbuWNvnJ(sQU2GnRoMwLK8CBdfzmNr4jXyO,url,UAhMnV3r89cWy7X1D05GBCwTqOP4p): return
	duef0gb3Mi1AV5WpN8 = []
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('id="player-option-1"(.*?)class=["|\'](sheader|pag_episodes)["|\']',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0][0]
		items = dEyT9xhGjolYzLCH7460w3.findall('data-type="(.*?)" data-post="(.*?)" data-nume="(.*?)".*?class="vid_title">(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for type,H0BbXRwP5vOqS,lLYiX34OzImg5hxSNpDJtoPWw02bcE,title in items:
			fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN+'/wp-admin/admin-ajax.php?action=doo_player_ajax&post='+H0BbXRwP5vOqS+'&nume='+lLYiX34OzImg5hxSNpDJtoPWw02bcE+'&type='+type
			fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork+'?named='+title+'__watch'
			duef0gb3Mi1AV5WpN8.append(fCXyTlcmF4WuetVork)
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('''id=["']download["'] class(.*?)class=["']sbox["']''',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('''img src=["'](.*?)["'].*?href=["'](.*?)["'].*?["']quality["']>(.*?)<.*?<td>(.*?)<''',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for C0dvhEbPWYlUtimM3x,fCXyTlcmF4WuetVork,pMAWqrwP80lR,aN8jtOe3hcFP6fwRYnbg in items:
			if '=' in C0dvhEbPWYlUtimM3x:
				oGIOdU6Ci18xc3vkBNTm4efRzhLE = C0dvhEbPWYlUtimM3x.split('=')[1]
				title = F82MvyX4ThI6sbnA3efDoVS(oGIOdU6Ci18xc3vkBNTm4efRzhLE,'host')
			else: title = iiy37aKq0pCEIOwfcTh61xb4U
			title = aN8jtOe3hcFP6fwRYnbg+iFBmE2MUIpSu34wsd7Rf6z+title
			fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork+'?named='+title+'__download____'+pMAWqrwP80lR
			duef0gb3Mi1AV5WpN8.append(fCXyTlcmF4WuetVork)
	import lqBJGK8hXO
	lqBJGK8hXO.ZDg1HavwueT85mcAOorC4hnS(duef0gb3Mi1AV5WpN8,sQU2GnRoMwLK8CBdfzmNr4jXyO,'video',url)
	return
def mUhJtHB9nw(search):
	search,brFQp5vmgJWdZfEkCBOlu9c,showDialogs = XkYnev3ZCA6ahO94(search)
	if search==iiy37aKq0pCEIOwfcTh61xb4U: search = TTBf6S08q1NKXd5v9wa()
	if search==iiy37aKq0pCEIOwfcTh61xb4U: return
	search = search.replace(iFBmE2MUIpSu34wsd7Rf6z,'+')
	url = JaQEtCzDXgos1cdZN+'/?s='+search
	AIQeNZP4FMDw9S(url,'search')
	return
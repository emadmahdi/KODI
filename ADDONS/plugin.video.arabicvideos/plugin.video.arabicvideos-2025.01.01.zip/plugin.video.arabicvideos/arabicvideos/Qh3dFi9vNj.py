# -*- coding: utf-8 -*-
from braVAkwfBN import *
sQU2GnRoMwLK8CBdfzmNr4jXyO = 'MOVS4U'
ooQEi5O6tYsGVF8LU0TC3hgMeflBwH = '_M4U_'
JaQEtCzDXgos1cdZN = gZ4LwbKaOm[sQU2GnRoMwLK8CBdfzmNr4jXyO][0]
a8GCLIuWNkS = ['انواع افلام','جودات افلام']
def sHVM8YchrDjZAJ7(mode,url,text):
	if   mode==380: EA7FzO1kMZGQXDd2giB0cwLom = jihuS9LVAvTrClPapMbUEwfn8XN()
	elif mode==381: EA7FzO1kMZGQXDd2giB0cwLom = AIQeNZP4FMDw9S(url,text)
	elif mode==382: EA7FzO1kMZGQXDd2giB0cwLom = TW6Z0zqaDl(url)
	elif mode==383: EA7FzO1kMZGQXDd2giB0cwLom = YNcMvoVF5swlDBJI7PL(url)
	elif mode==389: EA7FzO1kMZGQXDd2giB0cwLom = mUhJtHB9nw(text)
	else: EA7FzO1kMZGQXDd2giB0cwLom = False
	return EA7FzO1kMZGQXDd2giB0cwLom
def jihuS9LVAvTrClPapMbUEwfn8XN():
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'بحث في الموقع',iiy37aKq0pCEIOwfcTh61xb4U,389,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'_REMEMBERRESULTS_')
	bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'المميزة',JaQEtCzDXgos1cdZN,381,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'featured')
	bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'الجانبية',JaQEtCzDXgos1cdZN,381,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'sider')
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(Dxc7GChQwZ4kOlKHSbL06agnB,'GET',JaQEtCzDXgos1cdZN,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'MOVS4U-MENU-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	items = dEyT9xhGjolYzLCH7460w3.findall('<header>.*?<h2>(.*?)<',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	for rxbivCFQ9aAnpckTUXYh65dH4 in range(len(items)):
		title = items[rxbivCFQ9aAnpckTUXYh65dH4]
		bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,JaQEtCzDXgos1cdZN,381,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'latest'+str(rxbivCFQ9aAnpckTUXYh65dH4))
	PPH1sQtTkDBbnlYpZfo5 = iiy37aKq0pCEIOwfcTh61xb4U
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('class="menu"(.*?)id="contenedor"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS: PPH1sQtTkDBbnlYpZfo5 += UUIohmv597bO83YCLgWS[0]
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('class="sidebar(.*?)aside',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS: PPH1sQtTkDBbnlYpZfo5 += UUIohmv597bO83YCLgWS[0]
	items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)">(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	wijqr6NndVsJmg = True
	for fCXyTlcmF4WuetVork,title in items:
		title = JIY6A30UOsQboNVqCn(title)
		if title=='الأعلى مشاهدة':
			if wijqr6NndVsJmg:
				title = 'الافلام '+title
				wijqr6NndVsJmg = False
			else: title = 'المسلسلات '+title
		if title not in a8GCLIuWNkS:
			bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,381)
	return Vxz6OndPIX4g2kaRp7
def AIQeNZP4FMDw9S(url,type):
	PPH1sQtTkDBbnlYpZfo5,items = [],[]
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'MOVS4U-TITLES-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	if type=='search':
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('class="search-page"(.*?)class="sidebar',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if UUIohmv597bO83YCLgWS:
			PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
			items = dEyT9xhGjolYzLCH7460w3.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	elif type=='sider':
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('class="widget(.*?)class="widget',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		omPqiVcpgQ = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?img src="(.*?)".*?<h3>(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		duef0gb3Mi1AV5WpN8,Xhv6TR9tW3M5wOnide0LEq1fF,A7Ap2wdlxM = zip(*omPqiVcpgQ)
		items = zip(Xhv6TR9tW3M5wOnide0LEq1fF,duef0gb3Mi1AV5WpN8,A7Ap2wdlxM)
	elif type=='featured':
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('id="slider-movies-tvshows"(.*?)<header>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	elif 'latest' in type:
		rxbivCFQ9aAnpckTUXYh65dH4 = int(type[-1:])
		Vxz6OndPIX4g2kaRp7 = Vxz6OndPIX4g2kaRp7.replace('<header>','<end><start>')
		Vxz6OndPIX4g2kaRp7 = Vxz6OndPIX4g2kaRp7.replace('<div class="sidebar','<end><div class="sidebar')
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('<start>(.*?)<end>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[rxbivCFQ9aAnpckTUXYh65dH4]
		if rxbivCFQ9aAnpckTUXYh65dH4==2: items = dEyT9xhGjolYzLCH7460w3.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	else:
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('class="content"(.*?)class="(pagination|sidebar)',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if UUIohmv597bO83YCLgWS:
			PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0][0]
			if '/collection/' in url:
				items = dEyT9xhGjolYzLCH7460w3.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
			elif '/quality/' in url:
				items = dEyT9xhGjolYzLCH7460w3.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if not items and PPH1sQtTkDBbnlYpZfo5:
		items = dEyT9xhGjolYzLCH7460w3.findall('img src="(.*?)".*?href=.*?href="(.*?)">(.*?)</div>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	u3Rztpl4VHO9GZ7jCBM65kvS = []
	for C0dvhEbPWYlUtimM3x,fCXyTlcmF4WuetVork,title in items:
		if 'serie' in title:
			title = dEyT9xhGjolYzLCH7460w3.findall('^(.*?)<.*?serie">(.*?)<',title,dEyT9xhGjolYzLCH7460w3.DOTALL)
			title = title[0][1]
			if title in u3Rztpl4VHO9GZ7jCBM65kvS: continue
			u3Rztpl4VHO9GZ7jCBM65kvS.append(title)
			title = '_MOD_'+title
		Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb = dEyT9xhGjolYzLCH7460w3.findall('^(.*?)<',title,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb: title = Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb[0]
		title = JIY6A30UOsQboNVqCn(title)
		if '/tvshows/' in fCXyTlcmF4WuetVork: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,383,C0dvhEbPWYlUtimM3x)
		elif '/episodes/' in fCXyTlcmF4WuetVork: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,383,C0dvhEbPWYlUtimM3x)
		elif '/seasons/' in fCXyTlcmF4WuetVork: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,383,C0dvhEbPWYlUtimM3x)
		elif '/collection/' in fCXyTlcmF4WuetVork: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,381,C0dvhEbPWYlUtimM3x)
		else: bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,382,C0dvhEbPWYlUtimM3x)
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('class="pagination".*?Page (.*?) of (.*?)<(.*?)</div>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		N9LvIBjWVH = UUIohmv597bO83YCLgWS[0][0]
		wrhOEuQk7yUnozZb0IK = UUIohmv597bO83YCLgWS[0][1]
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0][2]
		items = dEyT9xhGjolYzLCH7460w3.findall("href='(.*?)'.*?>(.*?)<",PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title in items:
			if title==iiy37aKq0pCEIOwfcTh61xb4U or title==wrhOEuQk7yUnozZb0IK: continue
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'صفحة '+title,fCXyTlcmF4WuetVork,381,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,type)
		fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork.replace('/page/'+title+'/','/page/'+wrhOEuQk7yUnozZb0IK+'/')
		bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'اخر صفحة '+wrhOEuQk7yUnozZb0IK,fCXyTlcmF4WuetVork,381,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,type)
	return
def YNcMvoVF5swlDBJI7PL(url):
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'MOVS4U-EPISODES-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	UAhMnV3r89cWy7X1D05GBCwTqOP4p = dEyT9xhGjolYzLCH7460w3.findall('class="C rated".*?>(.*?)<',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UAhMnV3r89cWy7X1D05GBCwTqOP4p and IUF8hYKEGLmHDtXbuWNvnJ(sQU2GnRoMwLK8CBdfzmNr4jXyO,url,UAhMnV3r89cWy7X1D05GBCwTqOP4p,False):
		bP6z3OSLp7va('link',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'المسلسل للكبار والمبرمج منعه',iiy37aKq0pCEIOwfcTh61xb4U,9999)
		return
	if '/episodes/' in url or '/tvshows/' in url:
		eCGwzSrqBmIv = dEyT9xhGjolYzLCH7460w3.findall('''class='item'><a href="(.*?)"''',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if eCGwzSrqBmIv:
			eCGwzSrqBmIv = eCGwzSrqBmIv[1]
			YNcMvoVF5swlDBJI7PL(eCGwzSrqBmIv)
			return
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('''class='episodios'(.*?)id="cast"''',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('''src='(.*?)'.*?class='numerando'>(.*?)<.*?href='(.*?)'>(.*?)<''',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for C0dvhEbPWYlUtimM3x,zN7sZyFnw5JTE8,fCXyTlcmF4WuetVork,name in items:
			title = zN7sZyFnw5JTE8+' : '+name+' الحلقة'
			bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,382)
	return
def TW6Z0zqaDl(url):
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'MOVS4U-PLAY-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	UAhMnV3r89cWy7X1D05GBCwTqOP4p = dEyT9xhGjolYzLCH7460w3.findall('class="C rated".*?>(.*?)<',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UAhMnV3r89cWy7X1D05GBCwTqOP4p and IUF8hYKEGLmHDtXbuWNvnJ(sQU2GnRoMwLK8CBdfzmNr4jXyO,url,UAhMnV3r89cWy7X1D05GBCwTqOP4p): return
	duef0gb3Mi1AV5WpN8 = []
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('''id='player-option-1'(.*?)class=("sheader"|'pag_episodes')''',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0][0]
		items = dEyT9xhGjolYzLCH7460w3.findall("data-url='(.*?)'.*?class='server'>(.*?)<",PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title in items:
			fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork+'?named='+title+'__watch'
			duef0gb3Mi1AV5WpN8.append(fCXyTlcmF4WuetVork)
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('class="remodal"(.*?)class="remodal-close"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('class="___dl_gdrive.*?href="(.*?)".*?">(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title in items:
			fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN+fCXyTlcmF4WuetVork
			fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork+'?named='+title+'__download'
			duef0gb3Mi1AV5WpN8.append(fCXyTlcmF4WuetVork)
	import lqBJGK8hXO
	lqBJGK8hXO.ZDg1HavwueT85mcAOorC4hnS(duef0gb3Mi1AV5WpN8,sQU2GnRoMwLK8CBdfzmNr4jXyO,'video',url)
	return
def mUhJtHB9nw(search):
	search,brFQp5vmgJWdZfEkCBOlu9c,showDialogs = XkYnev3ZCA6ahO94(search)
	if search==iiy37aKq0pCEIOwfcTh61xb4U: search = TTBf6S08q1NKXd5v9wa()
	if search==iiy37aKq0pCEIOwfcTh61xb4U: return
	search = search.replace(iFBmE2MUIpSu34wsd7Rf6z,'+')
	url = JaQEtCzDXgos1cdZN+'/?s='+search
	AIQeNZP4FMDw9S(url,'search')
	return
# -*- coding: utf-8 -*-
from braVAkwfBN import *
sQU2GnRoMwLK8CBdfzmNr4jXyO = 'CIMANOW'
ooQEi5O6tYsGVF8LU0TC3hgMeflBwH = '_CMN_'
JaQEtCzDXgos1cdZN = gZ4LwbKaOm[sQU2GnRoMwLK8CBdfzmNr4jXyO][0]
a8GCLIuWNkS = ['قائمتي']
def sHVM8YchrDjZAJ7(mode,url,text):
	if   mode==300: EA7FzO1kMZGQXDd2giB0cwLom = jihuS9LVAvTrClPapMbUEwfn8XN()
	elif mode==301: EA7FzO1kMZGQXDd2giB0cwLom = BaSyudevC40nsQHW5j7JX6RM9(url)
	elif mode==302: EA7FzO1kMZGQXDd2giB0cwLom = AIQeNZP4FMDw9S(url)
	elif mode==303: EA7FzO1kMZGQXDd2giB0cwLom = Sm6cFjKyW8XTszNxi(url)
	elif mode==304: EA7FzO1kMZGQXDd2giB0cwLom = YNcMvoVF5swlDBJI7PL(url)
	elif mode==305: EA7FzO1kMZGQXDd2giB0cwLom = TW6Z0zqaDl(url)
	elif mode==306: EA7FzO1kMZGQXDd2giB0cwLom = tUYsO8JiWnloFIZ29Evyw6GKXq()
	elif mode==309: EA7FzO1kMZGQXDd2giB0cwLom = mUhJtHB9nw(text)
	else: EA7FzO1kMZGQXDd2giB0cwLom = False
	return EA7FzO1kMZGQXDd2giB0cwLom
def jihuS9LVAvTrClPapMbUEwfn8XN():
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'بحث في الموقع',iiy37aKq0pCEIOwfcTh61xb4U,309,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'_REMEMBERRESULTS_')
	bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(Dxc7GChQwZ4kOlKHSbL06agnB,'GET',JaQEtCzDXgos1cdZN+'/home',iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'CIMANOW-MENU-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('<header>(.*?)</header>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
	items = dEyT9xhGjolYzLCH7460w3.findall('<li><a href="(.*?)">(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	for fCXyTlcmF4WuetVork,title in items:
		title = title.strip(iFBmE2MUIpSu34wsd7Rf6z)
		if not any(aasX2cby4Vo5rTgB in title for aasX2cby4Vo5rTgB in a8GCLIuWNkS):
			bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,301)
	bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	BaSyudevC40nsQHW5j7JX6RM9(JaQEtCzDXgos1cdZN+'/home',Vxz6OndPIX4g2kaRp7)
	return Vxz6OndPIX4g2kaRp7
def tUYsO8JiWnloFIZ29Evyw6GKXq():
	bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'رسالة من المبرمج','موقع سيما ناو بطيء من المصدر .. بسبب قيام أصحاب الموقع بتشفير محتويات جميع صفحات الموقع .. والوقت الضائع يذهب في معالجة تشفير الصفحات المشفرة قبل عرض محتوياتها في قوائم هذا البرنامج')
	return
def BaSyudevC40nsQHW5j7JX6RM9(url,Vxz6OndPIX4g2kaRp7=iiy37aKq0pCEIOwfcTh61xb4U):
	if not Vxz6OndPIX4g2kaRp7:
		oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(Dxc7GChQwZ4kOlKHSbL06agnB,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'CIMANOW-SUBMENU-1st')
		Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	rxbivCFQ9aAnpckTUXYh65dH4 = 0
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('(<section>.*?</section>)',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		for PPH1sQtTkDBbnlYpZfo5 in UUIohmv597bO83YCLgWS:
			rxbivCFQ9aAnpckTUXYh65dH4 += 1
			items = dEyT9xhGjolYzLCH7460w3.findall('<section>.<span>(.*?)<(.*?)href="(.*?)"',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
			for title,vv1ep0zcjbLI4NtGVSQ,fCXyTlcmF4WuetVork in items:
				title = title.strip(iFBmE2MUIpSu34wsd7Rf6z)
				if title==iiy37aKq0pCEIOwfcTh61xb4U: title = 'بووووو'
				if 'em><a' not in vv1ep0zcjbLI4NtGVSQ:
					if PPH1sQtTkDBbnlYpZfo5.count('/category/')>0:
						dVFTrX63LKjk0Ba = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)"',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
						for fCXyTlcmF4WuetVork in dVFTrX63LKjk0Ba:
							title = fCXyTlcmF4WuetVork.split('/')[-2]
							bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,301)
						continue
					else: fCXyTlcmF4WuetVork = url+'?sequence='+str(rxbivCFQ9aAnpckTUXYh65dH4)
				if not any(aasX2cby4Vo5rTgB in title for aasX2cby4Vo5rTgB in a8GCLIuWNkS):
					bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,302)
	else: AIQeNZP4FMDw9S(url,Vxz6OndPIX4g2kaRp7)
	return
def AIQeNZP4FMDw9S(url,Vxz6OndPIX4g2kaRp7=iiy37aKq0pCEIOwfcTh61xb4U):
	if Vxz6OndPIX4g2kaRp7==iiy37aKq0pCEIOwfcTh61xb4U:
		oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'CIMANOW-TITLES-1st')
		Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	if '?sequence=' in url:
		url,rxbivCFQ9aAnpckTUXYh65dH4 = url.split('?sequence=')
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('(<section>.*?</section>)',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[int(rxbivCFQ9aAnpckTUXYh65dH4)-1]
	else:
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"posts"(.*?)</body>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
	items = dEyT9xhGjolYzLCH7460w3.findall('<a.*?href="(.*?)"(.*?)data-src="(.*?)"',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	u3Rztpl4VHO9GZ7jCBM65kvS = []
	for fCXyTlcmF4WuetVork,data,C0dvhEbPWYlUtimM3x in items:
		title = dEyT9xhGjolYzLCH7460w3.findall('<em>(.*?)</em>(.*?)</li>.*?</em>(.*?)<em>',data,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if title: title = title[0][2].replace(OTlVEGYPSxsNaBdXUucqA3,iiy37aKq0pCEIOwfcTh61xb4U).strip(iFBmE2MUIpSu34wsd7Rf6z)
		if not title or title==iiy37aKq0pCEIOwfcTh61xb4U:
			title = dEyT9xhGjolYzLCH7460w3.findall('title">.*?</em>(.*?)<',data,dEyT9xhGjolYzLCH7460w3.DOTALL)
			if title: title = title[0].replace(OTlVEGYPSxsNaBdXUucqA3,iiy37aKq0pCEIOwfcTh61xb4U).strip(iFBmE2MUIpSu34wsd7Rf6z)
			if not title or title==iiy37aKq0pCEIOwfcTh61xb4U:
				title = dEyT9xhGjolYzLCH7460w3.findall('title">(.*?)<',data,dEyT9xhGjolYzLCH7460w3.DOTALL)
				title = title[0].replace(OTlVEGYPSxsNaBdXUucqA3,iiy37aKq0pCEIOwfcTh61xb4U).strip(iFBmE2MUIpSu34wsd7Rf6z)
		title = JIY6A30UOsQboNVqCn(title)
		title = title.replace(Wc5GekRC0HQLz7,iFBmE2MUIpSu34wsd7Rf6z)
		if title not in u3Rztpl4VHO9GZ7jCBM65kvS:
			u3Rztpl4VHO9GZ7jCBM65kvS.append(title)
			U462wftipjCPA1hLuGsKr8koxnd = fCXyTlcmF4WuetVork+data+C0dvhEbPWYlUtimM3x
			if '/selary/' in U462wftipjCPA1hLuGsKr8koxnd or 'مسلسل' in U462wftipjCPA1hLuGsKr8koxnd or '"episode"' in U462wftipjCPA1hLuGsKr8koxnd:
				if 'برامج' in data: title = 'برنامج '+title
				elif 'مسلسل' in data or 'موسم' in data: title = 'مسلسل '+title
				bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,303,C0dvhEbPWYlUtimM3x)
			else: bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,305,C0dvhEbPWYlUtimM3x)
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"pagination"(.*?)</div>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('<li><a href="(.*?)">(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title in items:
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'صفحة '+title,fCXyTlcmF4WuetVork,302)
	return
def Sm6cFjKyW8XTszNxi(url):
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'CIMANOW-SEASONS-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	name = dEyT9xhGjolYzLCH7460w3.findall('<title>(.*?)</title>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	name = name[0].replace('| سيما ناو',iiy37aKq0pCEIOwfcTh61xb4U).replace('Cima Now',iiy37aKq0pCEIOwfcTh61xb4U).strip(iFBmE2MUIpSu34wsd7Rf6z).replace(Wc5GekRC0HQLz7,iFBmE2MUIpSu34wsd7Rf6z)
	name = name.split('الحلقة')[0].strip(iFBmE2MUIpSu34wsd7Rf6z)
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('<section(.*?)</section>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)">(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if len(items)>1:
			for fCXyTlcmF4WuetVork,title in items:
				title = name+' - '+title.replace(OTlVEGYPSxsNaBdXUucqA3,iiy37aKq0pCEIOwfcTh61xb4U).strip(iFBmE2MUIpSu34wsd7Rf6z)
				bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,304)
		else: YNcMvoVF5swlDBJI7PL(url)
	return
def YNcMvoVF5swlDBJI7PL(url):
	if '/selary/' not in url: url = url.strip('/')+'/watching'
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'CIMANOW-EPISODES-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	if '/selary/' not in url:
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"episodes"(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)">(.*?)</a>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title in items:
			title = title.replace(OTlVEGYPSxsNaBdXUucqA3,iiy37aKq0pCEIOwfcTh61xb4U).strip(iFBmE2MUIpSu34wsd7Rf6z)
			title = 'الحلقة '+title
			bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,305)
	else:
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"details"(.*?)"related"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?src=.*?src="(.*?)".*?alt="(.*?)"',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,C0dvhEbPWYlUtimM3x,title in items:
			title = title.replace(OTlVEGYPSxsNaBdXUucqA3,iiy37aKq0pCEIOwfcTh61xb4U).strip(iFBmE2MUIpSu34wsd7Rf6z)
			bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,305,C0dvhEbPWYlUtimM3x)
	return
def TW6Z0zqaDl(url):
	eCGwzSrqBmIv = url+'watching/'
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(r3rnfZ7cdxzNFebIRaLSG6B,'GET',eCGwzSrqBmIv,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'CIMANOW-PLAY-5th')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	duef0gb3Mi1AV5WpN8 = []
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"download"(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?</i>(.*?)</a>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title in items:
			title = title.replace(OTlVEGYPSxsNaBdXUucqA3,iiy37aKq0pCEIOwfcTh61xb4U).strip(iFBmE2MUIpSu34wsd7Rf6z)
			pMAWqrwP80lR = dEyT9xhGjolYzLCH7460w3.findall('\d\d\d+',title,dEyT9xhGjolYzLCH7460w3.DOTALL)
			if pMAWqrwP80lR:
				pMAWqrwP80lR = '____'+pMAWqrwP80lR[0]
				title = F82MvyX4ThI6sbnA3efDoVS(fCXyTlcmF4WuetVork,'name')
			else: pMAWqrwP80lR = iiy37aKq0pCEIOwfcTh61xb4U
			hx0dU3Ki7AyEfkSZY6TmN2BwtX = fCXyTlcmF4WuetVork+'?named='+title+'__download'+pMAWqrwP80lR
			duef0gb3Mi1AV5WpN8.append(hx0dU3Ki7AyEfkSZY6TmN2BwtX)
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"watch"(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		P3tys0cXWbiIUKk7HQ6n89V = dEyT9xhGjolYzLCH7460w3.findall('"embed".*?src="(.*?)"',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork in P3tys0cXWbiIUKk7HQ6n89V:
			if 'http' not in fCXyTlcmF4WuetVork: fCXyTlcmF4WuetVork = 'http:'+fCXyTlcmF4WuetVork
			title = F82MvyX4ThI6sbnA3efDoVS(fCXyTlcmF4WuetVork,'name')
			fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork+'?named='+title+'__embed'
			duef0gb3Mi1AV5WpN8.append(fCXyTlcmF4WuetVork)
		P3tys0cXWbiIUKk7HQ6n89V = [JaQEtCzDXgos1cdZN+'/wp-content/themes/Cima%20Now%20New/core.php']
		if P3tys0cXWbiIUKk7HQ6n89V:
			items = dEyT9xhGjolYzLCH7460w3.findall('data-index="(.*?)".*?data-id="(.*?)".*?>(.*?)</li>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
			for bsqXJ3iaf2dop5,id,title in items:
				title = title.replace(OTlVEGYPSxsNaBdXUucqA3,iiy37aKq0pCEIOwfcTh61xb4U).strip(iFBmE2MUIpSu34wsd7Rf6z)
				fCXyTlcmF4WuetVork = P3tys0cXWbiIUKk7HQ6n89V[0]+'?action=switch&index='+bsqXJ3iaf2dop5+'&id='+id+'?named='+title+'__watch'
				duef0gb3Mi1AV5WpN8.append(fCXyTlcmF4WuetVork)
	import lqBJGK8hXO
	lqBJGK8hXO.ZDg1HavwueT85mcAOorC4hnS(duef0gb3Mi1AV5WpN8,sQU2GnRoMwLK8CBdfzmNr4jXyO,'video',url)
	return
def mUhJtHB9nw(search):
	search,brFQp5vmgJWdZfEkCBOlu9c,showDialogs = XkYnev3ZCA6ahO94(search)
	if search==iiy37aKq0pCEIOwfcTh61xb4U: search = TTBf6S08q1NKXd5v9wa()
	if search==iiy37aKq0pCEIOwfcTh61xb4U: return
	search = search.replace(iFBmE2MUIpSu34wsd7Rf6z,'+')
	url = JaQEtCzDXgos1cdZN + '/?s='+search
	AIQeNZP4FMDw9S(url)
	return
# -*- coding: utf-8 -*-
from braVAkwfBN import *
sQU2GnRoMwLK8CBdfzmNr4jXyO = 'BOKRA'
ooQEi5O6tYsGVF8LU0TC3hgMeflBwH = '_BKR_'
JaQEtCzDXgos1cdZN = gZ4LwbKaOm[sQU2GnRoMwLK8CBdfzmNr4jXyO][0]
headers = {'User-Agent':iiy37aKq0pCEIOwfcTh61xb4U}
a8GCLIuWNkS = ['افلام للكبار','بكرا TV']
def sHVM8YchrDjZAJ7(mode,url,text):
	if   mode==370: EA7FzO1kMZGQXDd2giB0cwLom = jihuS9LVAvTrClPapMbUEwfn8XN()
	elif mode==371: EA7FzO1kMZGQXDd2giB0cwLom = AIQeNZP4FMDw9S(url,text)
	elif mode==372: EA7FzO1kMZGQXDd2giB0cwLom = TW6Z0zqaDl(url)
	elif mode==374: EA7FzO1kMZGQXDd2giB0cwLom = g2gtKV0FWxR(url)
	elif mode==375: EA7FzO1kMZGQXDd2giB0cwLom = w8hsf9erXJ(url)
	elif mode==376: EA7FzO1kMZGQXDd2giB0cwLom = YYixrHelGgp(0,url)
	elif mode==377: EA7FzO1kMZGQXDd2giB0cwLom = YYixrHelGgp(1,url)
	elif mode==379: EA7FzO1kMZGQXDd2giB0cwLom = mUhJtHB9nw(text)
	else: EA7FzO1kMZGQXDd2giB0cwLom = False
	return EA7FzO1kMZGQXDd2giB0cwLom
def jihuS9LVAvTrClPapMbUEwfn8XN():
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(Dxc7GChQwZ4kOlKHSbL06agnB,'GET',JaQEtCzDXgos1cdZN,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'BOKRA-MENU-1st')
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'بحث في الموقع',iiy37aKq0pCEIOwfcTh61xb4U,379,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'_REMEMBERRESULTS_')
	bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('right-side(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)">(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title in items:
			fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN+fCXyTlcmF4WuetVork
			if not any(aasX2cby4Vo5rTgB in title for aasX2cby4Vo5rTgB in a8GCLIuWNkS):
				bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,371)
	bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'المميزة',JaQEtCzDXgos1cdZN,375)
	bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'الأحدث',JaQEtCzDXgos1cdZN,376)
	bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'قائمة الممثلين',JaQEtCzDXgos1cdZN,374)
	bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('class="container"(.*?)top-menu',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)">(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title in items[7:]:
			title = title.strip(iFBmE2MUIpSu34wsd7Rf6z)
			fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN+fCXyTlcmF4WuetVork
			if not any(aasX2cby4Vo5rTgB in title for aasX2cby4Vo5rTgB in a8GCLIuWNkS):
				bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,371)
		for fCXyTlcmF4WuetVork,title in items[0:7]:
			title = title.strip(iFBmE2MUIpSu34wsd7Rf6z)
			fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN+fCXyTlcmF4WuetVork
			if not any(aasX2cby4Vo5rTgB in title for aasX2cby4Vo5rTgB in a8GCLIuWNkS):
				bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,371)
	return
def g2gtKV0FWxR(website=iiy37aKq0pCEIOwfcTh61xb4U):
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(Dxc7GChQwZ4kOlKHSbL06agnB,'GET',JaQEtCzDXgos1cdZN,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'BOKRA-ACTORSMENU-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('class="row cat Tags"(.*?)</div>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)" title="(.*?)"',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title in items:
			if 'http' in fCXyTlcmF4WuetVork: continue
			else: fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN+fCXyTlcmF4WuetVork
			if not any(aasX2cby4Vo5rTgB in title for aasX2cby4Vo5rTgB in a8GCLIuWNkS):
				bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,371)
	return
def w8hsf9erXJ(website=iiy37aKq0pCEIOwfcTh61xb4U):
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(r3rnfZ7cdxzNFebIRaLSG6B,'GET',JaQEtCzDXgos1cdZN,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'BOKRA-FEATURED-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"MainContent"(.*?)main-title2',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(/vidpage_.*?)".*? src="(.*?)".*?<h3>(.*?)</h3>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,C0dvhEbPWYlUtimM3x,title in items:
			fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN+fCXyTlcmF4WuetVork
			if not any(aasX2cby4Vo5rTgB in title for aasX2cby4Vo5rTgB in a8GCLIuWNkS):
				C0dvhEbPWYlUtimM3x = C0dvhEbPWYlUtimM3x.replace('://',':///').replace('//','/').replace(iFBmE2MUIpSu34wsd7Rf6z,'%20')
				bP6z3OSLp7va('video',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,372,C0dvhEbPWYlUtimM3x)
	return
def YYixrHelGgp(id,website=iiy37aKq0pCEIOwfcTh61xb4U):
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(r3rnfZ7cdxzNFebIRaLSG6B,'GET',JaQEtCzDXgos1cdZN,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'BOKRA-WATCHINGNOW-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('main-title2(.*?)class="row',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[id]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*? src="(.*?)".*?<h4>(.*?)</h4>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,C0dvhEbPWYlUtimM3x,title in items:
			fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN+fCXyTlcmF4WuetVork
			if not any(aasX2cby4Vo5rTgB in title for aasX2cby4Vo5rTgB in a8GCLIuWNkS):
				C0dvhEbPWYlUtimM3x = C0dvhEbPWYlUtimM3x.replace('://',':///').replace('//','/').replace(iFBmE2MUIpSu34wsd7Rf6z,'%20')
				bP6z3OSLp7va('video',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,372,C0dvhEbPWYlUtimM3x)
	return
def AIQeNZP4FMDw9S(url,phDAJlISKQmV9dnB5tRsFTyecGwC3=iiy37aKq0pCEIOwfcTh61xb4U):
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'BOKRA-TITLES-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	if 'vidpage_' in url:
		fCXyTlcmF4WuetVork = dEyT9xhGjolYzLCH7460w3.findall('href="(/Album-.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if fCXyTlcmF4WuetVork:
			fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN+fCXyTlcmF4WuetVork[0]
			AIQeNZP4FMDw9S(fCXyTlcmF4WuetVork)
			return
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('class=" subcats"(.*?)class="col-md-3',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if phDAJlISKQmV9dnB5tRsFTyecGwC3==iiy37aKq0pCEIOwfcTh61xb4U and UUIohmv597bO83YCLgWS and UUIohmv597bO83YCLgWS[0].count('href')>1:
		bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'الجميع',url,371,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'titles')
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)" title="(.*?)"',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title in items:
			fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN+'/'+fCXyTlcmF4WuetVork
			title = title.strip(iFBmE2MUIpSu34wsd7Rf6z)
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,371)
	else:
		u3Rztpl4VHO9GZ7jCBM65kvS = []
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('class="col-md-3(.*?)col-xs-12',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if not UUIohmv597bO83YCLgWS: UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('class="col-sm-8"(.*?)col-xs-12',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if UUIohmv597bO83YCLgWS:
			PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
			items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?src="(.*?)".*?<h4>(.*?)</h4>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
			for fCXyTlcmF4WuetVork,C0dvhEbPWYlUtimM3x,title in items:
				fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN+fCXyTlcmF4WuetVork
				title = title.strip(iFBmE2MUIpSu34wsd7Rf6z)
				C0dvhEbPWYlUtimM3x = C0dvhEbPWYlUtimM3x.replace('://',':///').replace('//','/').replace(iFBmE2MUIpSu34wsd7Rf6z,'%20')
				if '/al_' in fCXyTlcmF4WuetVork:
					bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,371,C0dvhEbPWYlUtimM3x)
				elif 'الحلقة' in title and ('/Cat-' in url or '/Search/' in url):
					zN7sZyFnw5JTE8 = dEyT9xhGjolYzLCH7460w3.findall('(.*?) - +الحلقة +\d+',title,dEyT9xhGjolYzLCH7460w3.DOTALL)
					if zN7sZyFnw5JTE8: title = '_MOD_مسلسل '+zN7sZyFnw5JTE8[0]
					if title not in u3Rztpl4VHO9GZ7jCBM65kvS:
						u3Rztpl4VHO9GZ7jCBM65kvS.append(title)
						bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,371,C0dvhEbPWYlUtimM3x)
				else: bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,372,C0dvhEbPWYlUtimM3x)
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('class="pagination(.*?)</div>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if UUIohmv597bO83YCLgWS:
			PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
			items = dEyT9xhGjolYzLCH7460w3.findall('class="".*?href="(.*?)">(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
			for fCXyTlcmF4WuetVork,title in items:
				fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN+fCXyTlcmF4WuetVork
				title = 'صفحة '+JIY6A30UOsQboNVqCn(title)
				bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,371,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'titles')
	return
def TW6Z0zqaDl(url):
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(r3rnfZ7cdxzNFebIRaLSG6B,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'BOKRA-PLAY-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	UAhMnV3r89cWy7X1D05GBCwTqOP4p = dEyT9xhGjolYzLCH7460w3.findall('label-success mrg-btm-5 ">(.*?)<',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UAhMnV3r89cWy7X1D05GBCwTqOP4p and IUF8hYKEGLmHDtXbuWNvnJ(sQU2GnRoMwLK8CBdfzmNr4jXyO,url,UAhMnV3r89cWy7X1D05GBCwTqOP4p): return
	O5Pwg3UFyX0k9E = iiy37aKq0pCEIOwfcTh61xb4U
	eCGwzSrqBmIv = dEyT9xhGjolYzLCH7460w3.findall('var url = "(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if eCGwzSrqBmIv: eCGwzSrqBmIv = eCGwzSrqBmIv[0]
	else: eCGwzSrqBmIv = url.replace('/vidpage_','/Play/')
	if 'http' not in eCGwzSrqBmIv: eCGwzSrqBmIv = JaQEtCzDXgos1cdZN+eCGwzSrqBmIv
	eCGwzSrqBmIv = eCGwzSrqBmIv.strip('-')
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(Qfob9ThC6ryqKkYZ,'GET',eCGwzSrqBmIv,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'BOKRA-PLAY-2nd')
	z0spMAOfJElv6L1K9ae = oCJ8TdG2LwSIVcbaUnhB.content
	O5Pwg3UFyX0k9E = dEyT9xhGjolYzLCH7460w3.findall('src="(.*?)"',z0spMAOfJElv6L1K9ae,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if O5Pwg3UFyX0k9E:
		O5Pwg3UFyX0k9E = O5Pwg3UFyX0k9E[-1]
		if 'http' not in O5Pwg3UFyX0k9E: O5Pwg3UFyX0k9E = 'http:'+O5Pwg3UFyX0k9E
		if '/PLAY/' not in eCGwzSrqBmIv:
			if 'embed.min.js' in O5Pwg3UFyX0k9E:
				RXIkYDuCjE = dEyT9xhGjolYzLCH7460w3.findall('data-publisher-id="(.*?)" data-video-id="(.*?)"',z0spMAOfJElv6L1K9ae,dEyT9xhGjolYzLCH7460w3.DOTALL)
				if RXIkYDuCjE:
					Dg8x3vl7o5XpPSdOWmqHReiAb4F, eaVk4rgcYNyKf7wqH9p = RXIkYDuCjE[0]
					O5Pwg3UFyX0k9E = F82MvyX4ThI6sbnA3efDoVS(O5Pwg3UFyX0k9E,'url')+'/v2/'+Dg8x3vl7o5XpPSdOWmqHReiAb4F+'/config/'+eaVk4rgcYNyKf7wqH9p+'.json'
		import lqBJGK8hXO
		lqBJGK8hXO.ZDg1HavwueT85mcAOorC4hnS([O5Pwg3UFyX0k9E],sQU2GnRoMwLK8CBdfzmNr4jXyO,'video',url)
	return
def mUhJtHB9nw(search):
	search,brFQp5vmgJWdZfEkCBOlu9c,showDialogs = XkYnev3ZCA6ahO94(search)
	if search==iiy37aKq0pCEIOwfcTh61xb4U: search = TTBf6S08q1NKXd5v9wa()
	if search==iiy37aKq0pCEIOwfcTh61xb4U: return
	search = search.replace(iFBmE2MUIpSu34wsd7Rf6z,'+')
	url = JaQEtCzDXgos1cdZN+'/Search/'+search
	AIQeNZP4FMDw9S(url)
	return
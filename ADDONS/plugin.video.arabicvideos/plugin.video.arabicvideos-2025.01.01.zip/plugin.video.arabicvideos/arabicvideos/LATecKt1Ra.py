# -*- coding: utf-8 -*-
from braVAkwfBN import *
sQU2GnRoMwLK8CBdfzmNr4jXyO = 'DAILYMOTION'
ooQEi5O6tYsGVF8LU0TC3hgMeflBwH = '_DLM_'
JaQEtCzDXgos1cdZN = gZ4LwbKaOm[sQU2GnRoMwLK8CBdfzmNr4jXyO][0]
QSaKzorWqRMY8JkTtNdG1exb = gZ4LwbKaOm[sQU2GnRoMwLK8CBdfzmNr4jXyO][1]
def sHVM8YchrDjZAJ7(mode,url,text,type,zLEP9N4BOsVrXa):
	if	 mode==400: EA7FzO1kMZGQXDd2giB0cwLom = jihuS9LVAvTrClPapMbUEwfn8XN()
	elif mode==401: EA7FzO1kMZGQXDd2giB0cwLom = f7Ub2cBVroKCt(url,text)
	elif mode==402: EA7FzO1kMZGQXDd2giB0cwLom = qOc1NXfsHlA86ImCBiTjab(url,text)
	elif mode==403: EA7FzO1kMZGQXDd2giB0cwLom = TW6Z0zqaDl(url,text)
	elif mode==404: EA7FzO1kMZGQXDd2giB0cwLom = JRgswvixIT8(text,zLEP9N4BOsVrXa)
	elif mode==405: EA7FzO1kMZGQXDd2giB0cwLom = QuPihFMIDdg(text,zLEP9N4BOsVrXa)
	elif mode==406: EA7FzO1kMZGQXDd2giB0cwLom = Vqitn5ybGoRrgaUeT(text,zLEP9N4BOsVrXa)
	elif mode==407: EA7FzO1kMZGQXDd2giB0cwLom = x1V49dtl2zGayfZIRepuUDM0(url,zLEP9N4BOsVrXa)
	elif mode==408: EA7FzO1kMZGQXDd2giB0cwLom = NtrLa2SoMTWkeqQB(url,zLEP9N4BOsVrXa)
	elif mode==409: EA7FzO1kMZGQXDd2giB0cwLom = mUhJtHB9nw(text,zLEP9N4BOsVrXa)
	elif mode==411: EA7FzO1kMZGQXDd2giB0cwLom = KK9Gpc4yDEt6f0VegbnWRO7qrNhH(url,text)
	elif mode==414: EA7FzO1kMZGQXDd2giB0cwLom = MMvBbag1WpzRZHOD2X3tKGie5mc(text)
	elif mode==415: EA7FzO1kMZGQXDd2giB0cwLom = V9QC72mhkyEeoHM(text,zLEP9N4BOsVrXa)
	elif mode==416: EA7FzO1kMZGQXDd2giB0cwLom = OObFArCgyz(text,zLEP9N4BOsVrXa)
	elif mode==417: EA7FzO1kMZGQXDd2giB0cwLom = JQvxTRciOC(url,zLEP9N4BOsVrXa)
	else: EA7FzO1kMZGQXDd2giB0cwLom = False
	return EA7FzO1kMZGQXDd2giB0cwLom
def jihuS9LVAvTrClPapMbUEwfn8XN():
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'الرئيسية',iiy37aKq0pCEIOwfcTh61xb4U,414)
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'بحث في الموقع',iiy37aKq0pCEIOwfcTh61xb4U,409,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'_REMEMBERRESULTS_')
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'بحث عن فيديوهات',iiy37aKq0pCEIOwfcTh61xb4U,409,iiy37aKq0pCEIOwfcTh61xb4U,'videos?sortBy=','_REMEMBERRESULTS_')
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'بحث عن آخر الفيديوهات',iiy37aKq0pCEIOwfcTh61xb4U,409,iiy37aKq0pCEIOwfcTh61xb4U,'videos?sortBy=RECENT','_REMEMBERRESULTS_')
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'بحث عن الفيديوهات الأكثر مشاهدة',iiy37aKq0pCEIOwfcTh61xb4U,409,iiy37aKq0pCEIOwfcTh61xb4U,'videos?sortBy=VIEW_COUNT','_REMEMBERRESULTS_')
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'بحث عن قوائم التشغيل',iiy37aKq0pCEIOwfcTh61xb4U,409,iiy37aKq0pCEIOwfcTh61xb4U,'playlists','_REMEMBERRESULTS_')
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'بحث عن مستخدم',iiy37aKq0pCEIOwfcTh61xb4U,409,iiy37aKq0pCEIOwfcTh61xb4U,'channels','_REMEMBERRESULTS_')
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'بحث عن بث حي',iiy37aKq0pCEIOwfcTh61xb4U,409,iiy37aKq0pCEIOwfcTh61xb4U,'lives','_REMEMBERRESULTS_')
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'بحث عن هاشتاك',iiy37aKq0pCEIOwfcTh61xb4U,409,iiy37aKq0pCEIOwfcTh61xb4U,'hashtags','_REMEMBERRESULTS_')
	return
def qOc1NXfsHlA86ImCBiTjab(url,CIKVfX7vAi):
	if '/dm_' in url:
		oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(r3rnfZ7cdxzNFebIRaLSG6B,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,False,iiy37aKq0pCEIOwfcTh61xb4U,'DAILYMOTION-CHANNELS_SUBMENU-1st',False,False)
		headers = oCJ8TdG2LwSIVcbaUnhB.headers
		if 'Location' in list(headers.keys()): url = JaQEtCzDXgos1cdZN+headers['Location']
	CIKVfX7vAi = PSwfZcdRYhpl5Igqz8xOEk67+CIKVfX7vAi+YoQW601K4fMJcsreDnGVE5wUZIy7
	CIKVfX7vAi = rFqGlDAt8SQ(CIKVfX7vAi)
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+':: بث حي',url,411,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'channel_lives_now')
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+':: آخر الفيديوهات',url+'/videos',408)
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+':: الأكثر مشاهدة',url+'/videos?sort=visited',408)
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+':: المميزة',url,411,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'channel_featured_videos')
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+':: قوائم التشغيل',url+'/playlists',407)
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+':: قوائم التشغيل أبجدية',url+'/playlists?sort=alphaaz',407)
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+':: قنوات ذات صلة',url,411,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'channel_related_channel')
	return
def rFqGlDAt8SQ(title):
	title = title.rstrip('\\').strip(iFBmE2MUIpSu34wsd7Rf6z).replace('\\\\','\\')
	title = vvmT3DLXkhPBwIaOAo6srZpEnRVJC(title)
	return title
def TW6Z0zqaDl(url,w3Ocz1JhkdGN6MartBi82mHxpsW):
	import lqBJGK8hXO
	lqBJGK8hXO.ZDg1HavwueT85mcAOorC4hnS([url],sQU2GnRoMwLK8CBdfzmNr4jXyO,'video',url)
	return
def JRgswvixIT8(search,zLEP9N4BOsVrXa=iiy37aKq0pCEIOwfcTh61xb4U):
	if zLEP9N4BOsVrXa==iiy37aKq0pCEIOwfcTh61xb4U: zLEP9N4BOsVrXa = '1'
	if 'sortBy=' in search: sort = search.split('sortBy=')[1].split('&')[0]
	else: sort = iiy37aKq0pCEIOwfcTh61xb4U
	search = search.split('/videos')[0]
	lHDuLVCy8kvqB6Rxh4Gs5K = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeVideos":true,"page":mypagenumber,"limit":mypagelimitmysortmethod},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    views {      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment VIDEO_WATCH_LATER_FRAGMENT on Video {  id  isInWatchLater  __typename}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    videos {      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_WATCH_LATER_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	lHDuLVCy8kvqB6Rxh4Gs5K = lHDuLVCy8kvqB6Rxh4Gs5K.replace('mysearchwords',search)
	lHDuLVCy8kvqB6Rxh4Gs5K = lHDuLVCy8kvqB6Rxh4Gs5K.replace('mypagelimit','40')
	lHDuLVCy8kvqB6Rxh4Gs5K = lHDuLVCy8kvqB6Rxh4Gs5K.replace('mypagenumber',zLEP9N4BOsVrXa)
	if sort==iiy37aKq0pCEIOwfcTh61xb4U: lHDuLVCy8kvqB6Rxh4Gs5K = lHDuLVCy8kvqB6Rxh4Gs5K.replace('mysortmethod',iiy37aKq0pCEIOwfcTh61xb4U)
	else: lHDuLVCy8kvqB6Rxh4Gs5K = lHDuLVCy8kvqB6Rxh4Gs5K.replace('mysortmethod',',"sortByVideos":"'+sort+'"')
	url = JaQEtCzDXgos1cdZN+'/search/'+search+'/videos'
	Vxz6OndPIX4g2kaRp7 = lJj2EHGkVLAo1BOY70zF(lHDuLVCy8kvqB6Rxh4Gs5K,search)
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"videos"(.*?)"VideoConnection"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('"node":.*?"xid":"(.*?)",.*?"title":"(.*?)",.*?"name":"(.*?)",.*?"displayName":"(.*?)",.*?"duration":(.*?),".*?thumbnailx240":"(.*?)",',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for id,title,xmsw4p9VOT7,CIKVfX7vAi,Zt6GY7K2oFeAd5kTy3nJvDBpQr,C0dvhEbPWYlUtimM3x in items:
			C0dvhEbPWYlUtimM3x = C0dvhEbPWYlUtimM3x.replace('\/','/')
			fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN+'/video/'+id
			title = rFqGlDAt8SQ(title)
			w3Ocz1JhkdGN6MartBi82mHxpsW = xmsw4p9VOT7+'::'+CIKVfX7vAi
			bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,403,C0dvhEbPWYlUtimM3x,Zt6GY7K2oFeAd5kTy3nJvDBpQr,w3Ocz1JhkdGN6MartBi82mHxpsW)
		if '"hasNextPage":true' in Vxz6OndPIX4g2kaRp7:
			zLEP9N4BOsVrXa = str(int(zLEP9N4BOsVrXa)+1)
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'صفحة '+zLEP9N4BOsVrXa,url,404,iiy37aKq0pCEIOwfcTh61xb4U,zLEP9N4BOsVrXa,search)
	return
def QuPihFMIDdg(search,zLEP9N4BOsVrXa=iiy37aKq0pCEIOwfcTh61xb4U):
	if zLEP9N4BOsVrXa==iiy37aKq0pCEIOwfcTh61xb4U: zLEP9N4BOsVrXa = '1'
	lHDuLVCy8kvqB6Rxh4Gs5K = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":true,"shouldIncludeVideos":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    views {      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment VIDEO_WATCH_LATER_FRAGMENT on Video {  id  isInWatchLater  __typename}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    videos {      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_WATCH_LATER_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	lHDuLVCy8kvqB6Rxh4Gs5K = lHDuLVCy8kvqB6Rxh4Gs5K.replace('mysearchwords',search)
	lHDuLVCy8kvqB6Rxh4Gs5K = lHDuLVCy8kvqB6Rxh4Gs5K.replace('mypagelimit','40')
	lHDuLVCy8kvqB6Rxh4Gs5K = lHDuLVCy8kvqB6Rxh4Gs5K.replace('mypagenumber',zLEP9N4BOsVrXa)
	url = JaQEtCzDXgos1cdZN+'/search/'+search+'/playlists'
	Vxz6OndPIX4g2kaRp7 = lJj2EHGkVLAo1BOY70zF(lHDuLVCy8kvqB6Rxh4Gs5K,search)
	items = dEyT9xhGjolYzLCH7460w3.findall('"node".*?"xid":"(.*?)",.*?"name":"(.*?)",.*?"xid":"(.*?)",.*?"name":"(.*?)",.*?"displayName":"(.*?)",.*?"thumbnailx240":"(.*?)",.*?"total":(.*?),"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	for id,name,BDmNtsv3hMT2rxjKYZl6cG4gFU,xmsw4p9VOT7,CIKVfX7vAi,C0dvhEbPWYlUtimM3x,count in items:
		C0dvhEbPWYlUtimM3x = C0dvhEbPWYlUtimM3x.replace('\/','/')
		fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN+'/playlist/'+id
		title = 'LIST'+count+':  '+name
		title = rFqGlDAt8SQ(title)
		w3Ocz1JhkdGN6MartBi82mHxpsW = xmsw4p9VOT7+'::'+CIKVfX7vAi
		bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,401,C0dvhEbPWYlUtimM3x,iiy37aKq0pCEIOwfcTh61xb4U,w3Ocz1JhkdGN6MartBi82mHxpsW)
	if '"hasNextPage":true' in Vxz6OndPIX4g2kaRp7:
		zLEP9N4BOsVrXa = str(int(zLEP9N4BOsVrXa)+1)
		bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'صفحة '+zLEP9N4BOsVrXa,url,405,iiy37aKq0pCEIOwfcTh61xb4U,zLEP9N4BOsVrXa,search)
	return
def Vqitn5ybGoRrgaUeT(search,zLEP9N4BOsVrXa=iiy37aKq0pCEIOwfcTh61xb4U):
	if zLEP9N4BOsVrXa==iiy37aKq0pCEIOwfcTh61xb4U: zLEP9N4BOsVrXa = '1'
	lHDuLVCy8kvqB6Rxh4Gs5K = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":true,"shouldIncludePlaylists":false,"shouldIncludeVideos":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    views {      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment VIDEO_WATCH_LATER_FRAGMENT on Video {  id  isInWatchLater  __typename}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    videos {      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_WATCH_LATER_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	lHDuLVCy8kvqB6Rxh4Gs5K = lHDuLVCy8kvqB6Rxh4Gs5K.replace('mysearchwords',search)
	lHDuLVCy8kvqB6Rxh4Gs5K = lHDuLVCy8kvqB6Rxh4Gs5K.replace('mypagelimit','40')
	lHDuLVCy8kvqB6Rxh4Gs5K = lHDuLVCy8kvqB6Rxh4Gs5K.replace('mypagenumber',zLEP9N4BOsVrXa)
	url = JaQEtCzDXgos1cdZN+'/search/'+search+'/channels'
	Vxz6OndPIX4g2kaRp7 = lJj2EHGkVLAo1BOY70zF(lHDuLVCy8kvqB6Rxh4Gs5K,search)
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"channels"(.*?)"ChannelConnection"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('"node".*?"name":"(.*?)",.*?"displayName":"(.*?)",.*?"thumbnailx240":"(.*?)",',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for id,name,C0dvhEbPWYlUtimM3x in items:
			C0dvhEbPWYlUtimM3x = C0dvhEbPWYlUtimM3x.replace('\/','/')
			fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN+'/'+id
			title = 'USER:  '+name
			title = rFqGlDAt8SQ(title)
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,402,C0dvhEbPWYlUtimM3x,iiy37aKq0pCEIOwfcTh61xb4U,name)
		if '"hasNextPage":true' in Vxz6OndPIX4g2kaRp7:
			zLEP9N4BOsVrXa = str(int(zLEP9N4BOsVrXa)+1)
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'صفحة '+zLEP9N4BOsVrXa,url,406,iiy37aKq0pCEIOwfcTh61xb4U,zLEP9N4BOsVrXa,search)
	return
def MMvBbag1WpzRZHOD2X3tKGie5mc(iRXnqkxs51gwUT):
	lHDuLVCy8kvqB6Rxh4Gs5K = '''{"operationName":"HOME_QUERY","variables":{"space":"nextplore"},"query":"fragment TOPIC_BASE_FRAG on Topic {  id  xid  name  thumbnail: coverURL(size: \\"x532\\")  coverURL: coverURL(size: \\"x532\\")  isFollowed  whitelistStatus {    id    isWhitelisted    __typename  }  __typename}query HOME_QUERY($space: String!) {  home: views {    id    neon {      id      sections(space: $space) {        edges {          node {            id            name            title            description            groupingType            type            relatedComponent {              __typename              ... on Collection {                id                xid                __typename              }              ... on Channel {                id                xid                name                displayName                logoURL(size: \\"x60\\")                __typename              }              ... on Topic {                id                __typename                ...TOPIC_BASE_FRAG              }            }            components {              edges {                node {                  __typename                  ... on Video {                    id                    xid                    title                    thumbnailx60: thumbnailURL(size: \\"x60\\")                    thumbnailx120: thumbnailURL(size: \\"x120\\")                    thumbnailx240: thumbnailURL(size: \\"x240\\")                    thumbnailx360: thumbnailURL(size: \\"x360\\")                    thumbnailx480: thumbnailURL(size: \\"x480\\")                    thumbnailx720: thumbnailURL(size: \\"x720\\")                    aspectRatio                    createdAt                    channel {                      id                      xid                      name                      displayName                      logoURLx25: logoURL(size: \\"x25\\")                      accountType                      __typename                    }                    description                    duration                    __typename                  }                  ... on Live {                    id                    xid                    title                    thumbnailx60: thumbnailURL(size: \\"x60\\")                    thumbnailx120: thumbnailURL(size: \\"x120\\")                    thumbnailx240: thumbnailURL(size: \\"x240\\")                    thumbnailx360: thumbnailURL(size: \\"x360\\")                    thumbnailx480: thumbnailURL(size: \\"x480\\")                    thumbnailx720: thumbnailURL(size: \\"x720\\")                    aspectRatio                    createdAt                    channel {                      id                      xid                      name                      displayName                      logoURLx25: logoURL(size: \\"x25\\")                      accountType                      __typename                    }                    startAt                    __typename                  }                }                __typename              }              __typename            }            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	dLVhlByrevFDXbPKgcYmWR = lJj2EHGkVLAo1BOY70zF(lHDuLVCy8kvqB6Rxh4Gs5K)
	if dLVhlByrevFDXbPKgcYmWR:
		qvLKBSJ1inD = DeIL3qoa2UBtYPb('dict',dLVhlByrevFDXbPKgcYmWR)
		ElbU2unpLiOQDAcXwRe4mKM5S1W = qvLKBSJ1inD['data']['home']['neon']['sections']['edges']
		if not iRXnqkxs51gwUT:
			ykEQdf5Voza48jNh1q = []
			for MMKAQvR16eHBu7xkpjlno in ElbU2unpLiOQDAcXwRe4mKM5S1W:
				jT015I89yKiM3Xzl = MMKAQvR16eHBu7xkpjlno['node']['title']
				if jT015I89yKiM3Xzl not in ykEQdf5Voza48jNh1q: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+jT015I89yKiM3Xzl,iiy37aKq0pCEIOwfcTh61xb4U,414,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,jT015I89yKiM3Xzl)
				ykEQdf5Voza48jNh1q.append(jT015I89yKiM3Xzl)
		else:
			for MMKAQvR16eHBu7xkpjlno in ElbU2unpLiOQDAcXwRe4mKM5S1W:
				jT015I89yKiM3Xzl = MMKAQvR16eHBu7xkpjlno['node']['title']
				if jT015I89yKiM3Xzl==iRXnqkxs51gwUT:
					vv3pu9n48TIyZhJksD = MMKAQvR16eHBu7xkpjlno['node']['components']['edges']
					for MMjae6poZHKr8SQ3gl2f in vv3pu9n48TIyZhJksD:
						Zt6GY7K2oFeAd5kTy3nJvDBpQr = str(MMjae6poZHKr8SQ3gl2f['node']['duration'])
						title = vvmT3DLXkhPBwIaOAo6srZpEnRVJC(MMjae6poZHKr8SQ3gl2f['node']['title'])
						title = title.replace('\/','/')
						lDLFBqgd8Qx0EeIhZkuY94UCzH3A = MMjae6poZHKr8SQ3gl2f['node']['xid']
						C0dvhEbPWYlUtimM3x = MMjae6poZHKr8SQ3gl2f['node']['thumbnailx480']
						C0dvhEbPWYlUtimM3x = C0dvhEbPWYlUtimM3x.replace('\/','/')
						fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN+'/video/'+lDLFBqgd8Qx0EeIhZkuY94UCzH3A
						bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,403,C0dvhEbPWYlUtimM3x,Zt6GY7K2oFeAd5kTy3nJvDBpQr)
	return
def V9QC72mhkyEeoHM(search,zLEP9N4BOsVrXa=iiy37aKq0pCEIOwfcTh61xb4U):
	if zLEP9N4BOsVrXa==iiy37aKq0pCEIOwfcTh61xb4U: zLEP9N4BOsVrXa = '1'
	lHDuLVCy8kvqB6Rxh4Gs5K = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeTopics":false,"shouldIncludeVideos":false,"shouldIncludeLives":true,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    id    views {      id      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  aspectRatio  __typename}fragment VIDEO_FAVORITES_FRAGMENT on Media {  __typename  ... on Video {    id    viewerEngagement {      id      favorited      __typename    }    __typename  }  ... on Live {    id    viewerEngagement {      id      favorited      __typename    }    __typename  }}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}fragment TOPIC_BASE_FRAG on Topic {  id  xid  name  videos(sort: \\"recent\\", first: 5) {    pageInfo {      hasNextPage      nextPage      __typename    }    edges {      node {        id        ...VIDEO_BASE_FRAGMENT        ...VIDEO_FAVORITES_FRAGMENT        __typename      }      __typename    }    __typename  }  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeTopics: Boolean!, $shouldIncludeLives: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(      query: $query      first: $limit      page: $page      sort: $sortByVideos      durationMin: $durationMinVideos      durationMax: $durationMaxVideos      createdAfter: $createdAfterVideos    ) @include(if: $shouldIncludeVideos) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_FAVORITES_FRAGMENT          __typename        }        __typename      }      __typename    }    lives(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeLives) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          xid          title          thumbnail: thumbnailURL(size: \\"x240\\")          thumbnailx60: thumbnailURL(size: \\"x60\\")          thumbnailx120: thumbnailURL(size: \\"x120\\")          thumbnailx240: thumbnailURL(size: \\"x240\\")          thumbnailx720: thumbnailURL(size: \\"x720\\")          audienceCount          aspectRatio          isOnAir          channel {            id            xid            name            displayName            accountType            __typename          }          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    topics(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeTopics) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...TOPIC_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	lHDuLVCy8kvqB6Rxh4Gs5K = lHDuLVCy8kvqB6Rxh4Gs5K.replace('mysearchwords',search)
	lHDuLVCy8kvqB6Rxh4Gs5K = lHDuLVCy8kvqB6Rxh4Gs5K.replace('mypagelimit','40')
	lHDuLVCy8kvqB6Rxh4Gs5K = lHDuLVCy8kvqB6Rxh4Gs5K.replace('mypagenumber',zLEP9N4BOsVrXa)
	url = JaQEtCzDXgos1cdZN+'/search/'+search+'/lives'
	dLVhlByrevFDXbPKgcYmWR = lJj2EHGkVLAo1BOY70zF(lHDuLVCy8kvqB6Rxh4Gs5K,search)
	if dLVhlByrevFDXbPKgcYmWR:
		qvLKBSJ1inD = DeIL3qoa2UBtYPb('dict',dLVhlByrevFDXbPKgcYmWR)
		try: ElbU2unpLiOQDAcXwRe4mKM5S1W = qvLKBSJ1inD['data']['search']['lives']['edges']
		except: ElbU2unpLiOQDAcXwRe4mKM5S1W = []
		for MMKAQvR16eHBu7xkpjlno in ElbU2unpLiOQDAcXwRe4mKM5S1W:
			name = MMKAQvR16eHBu7xkpjlno['node']['title']
			name = vvmT3DLXkhPBwIaOAo6srZpEnRVJC(name)
			lDLFBqgd8Qx0EeIhZkuY94UCzH3A = MMKAQvR16eHBu7xkpjlno['node']['xid']
			fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN+'/video/'+lDLFBqgd8Qx0EeIhZkuY94UCzH3A
			bP6z3OSLp7va('live',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'LIVE: '+name,fCXyTlcmF4WuetVork,403)
		if '"hasNextPage":true' in dLVhlByrevFDXbPKgcYmWR:
			zLEP9N4BOsVrXa = str(int(zLEP9N4BOsVrXa)+1)
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'صفحة '+zLEP9N4BOsVrXa,url,415,iiy37aKq0pCEIOwfcTh61xb4U,zLEP9N4BOsVrXa,search)
	return
def gxVs2WtilOHzFuY0wGTjaqSB6npvCh(search,zLEP9N4BOsVrXa=iiy37aKq0pCEIOwfcTh61xb4U):
	if zLEP9N4BOsVrXa==iiy37aKq0pCEIOwfcTh61xb4U: zLEP9N4BOsVrXa = '1'
	lHDuLVCy8kvqB6Rxh4Gs5K = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeTopics":true,"shouldIncludeVideos":false,"shouldIncludeLives":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    id    views {      id      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  aspectRatio  __typename}fragment VIDEO_FAVORITES_FRAGMENT on Media {  __typename  ... on Video {    id    isInWatchLater    __typename  }  ... on Live {    id    isInWatchLater    __typename  }}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}fragment TOPIC_BASE_FRAG on Topic {  id  xid  name  videos(sort: \\"recent\\", first: 5) {    pageInfo {      hasNextPage      nextPage      __typename    }    edges {      node {        id        ...VIDEO_BASE_FRAGMENT        ...VIDEO_FAVORITES_FRAGMENT        __typename      }      __typename    }    __typename  }  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeTopics: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(      query: $query      first: $limit      page: $page      sort: $sortByVideos      durationMin: $durationMinVideos      durationMax: $durationMaxVideos      createdAfter: $createdAfterVideos    ) @include(if: $shouldIncludeVideos) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_FAVORITES_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    topics(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeTopics) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...TOPIC_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	lHDuLVCy8kvqB6Rxh4Gs5K = lHDuLVCy8kvqB6Rxh4Gs5K.replace('mysearchwords',search)
	lHDuLVCy8kvqB6Rxh4Gs5K = lHDuLVCy8kvqB6Rxh4Gs5K.replace('mypagelimit','40')
	lHDuLVCy8kvqB6Rxh4Gs5K = lHDuLVCy8kvqB6Rxh4Gs5K.replace('mypagenumber',zLEP9N4BOsVrXa)
	url = JaQEtCzDXgos1cdZN+'/search/'+search+'/topics'
	dLVhlByrevFDXbPKgcYmWR = lJj2EHGkVLAo1BOY70zF(lHDuLVCy8kvqB6Rxh4Gs5K,search)
	if dLVhlByrevFDXbPKgcYmWR:
		qvLKBSJ1inD = DeIL3qoa2UBtYPb('dict',dLVhlByrevFDXbPKgcYmWR)
		try: ElbU2unpLiOQDAcXwRe4mKM5S1W = qvLKBSJ1inD['data']['search']['topics']['edges']
		except: ElbU2unpLiOQDAcXwRe4mKM5S1W = []
		for MMKAQvR16eHBu7xkpjlno in ElbU2unpLiOQDAcXwRe4mKM5S1W:
			name = MMKAQvR16eHBu7xkpjlno['node']['name']
			lDLFBqgd8Qx0EeIhZkuY94UCzH3A = MMKAQvR16eHBu7xkpjlno['node']['xid']
			fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN+'/topic/'+lDLFBqgd8Qx0EeIhZkuY94UCzH3A
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'TOPIC: '+name,fCXyTlcmF4WuetVork,413)
		if '"hasNextPage":true' in dLVhlByrevFDXbPKgcYmWR:
			zLEP9N4BOsVrXa = str(int(zLEP9N4BOsVrXa)+1)
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'صفحة '+zLEP9N4BOsVrXa,url,412,iiy37aKq0pCEIOwfcTh61xb4U,zLEP9N4BOsVrXa,search)
	return
def GSvqQUMILmfzjZx92keKCEldhH(url,zLEP9N4BOsVrXa=iiy37aKq0pCEIOwfcTh61xb4U):
	if zLEP9N4BOsVrXa==iiy37aKq0pCEIOwfcTh61xb4U: zLEP9N4BOsVrXa = '1'
	lDLFBqgd8Qx0EeIhZkuY94UCzH3A = url.split('/')[-1]
	lHDuLVCy8kvqB6Rxh4Gs5K = '''{"operationName":"DISCOVERY_TOPIC_MAIN_QUERY","variables":{"page":mypagenumber,"xid":"mytopicid"},"query":"fragment TOPIC_VIDEO_FRAGMENT on Video {  id  xid  title  duration  isLiked  isInWatchLater  isCreatedForKids  createdAt  isExplicit  videoHeight: height  videoWidth: width  category  channel {    id    xid    name    displayName    logoURLx25: logoURL(size: \\"x25\\")    logoURL(size: \\"x60\\")    accountType    __typename  }  stats {    id    views {      id      total      __typename    }    __typename  }  language {    id    codeAlpha2    __typename  }  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  bestAvailableQuality  aspectRatio  isPublished  __typename}query DISCOVERY_TOPIC_MAIN_QUERY($xid: String!, $page: Int = 1) {  topic(xid: $xid) {    id    xid    name    videos(sort: \\"recent\\", first: 30, page: $page) {      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...TOPIC_VIDEO_FRAGMENT          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	lHDuLVCy8kvqB6Rxh4Gs5K = lHDuLVCy8kvqB6Rxh4Gs5K.replace('mytopicid',lDLFBqgd8Qx0EeIhZkuY94UCzH3A)
	lHDuLVCy8kvqB6Rxh4Gs5K = lHDuLVCy8kvqB6Rxh4Gs5K.replace('mypagenumber',zLEP9N4BOsVrXa)
	dLVhlByrevFDXbPKgcYmWR = lJj2EHGkVLAo1BOY70zF(lHDuLVCy8kvqB6Rxh4Gs5K)
	if dLVhlByrevFDXbPKgcYmWR:
		qvLKBSJ1inD = DeIL3qoa2UBtYPb('dict',dLVhlByrevFDXbPKgcYmWR)
		ElbU2unpLiOQDAcXwRe4mKM5S1W = qvLKBSJ1inD['data']['topic']['videos']['edges']
		for MMKAQvR16eHBu7xkpjlno in ElbU2unpLiOQDAcXwRe4mKM5S1W:
			Zt6GY7K2oFeAd5kTy3nJvDBpQr = str(MMKAQvR16eHBu7xkpjlno['node']['duration'])
			title = vvmT3DLXkhPBwIaOAo6srZpEnRVJC(MMKAQvR16eHBu7xkpjlno['node']['title'])
			title = title.replace('\/','/')
			lDLFBqgd8Qx0EeIhZkuY94UCzH3A = MMKAQvR16eHBu7xkpjlno['node']['xid']
			C0dvhEbPWYlUtimM3x = MMKAQvR16eHBu7xkpjlno['node']['thumbnailx480']
			C0dvhEbPWYlUtimM3x = C0dvhEbPWYlUtimM3x.replace('\/','/')
			fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN+'/video/'+lDLFBqgd8Qx0EeIhZkuY94UCzH3A
			bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,403,C0dvhEbPWYlUtimM3x,Zt6GY7K2oFeAd5kTy3nJvDBpQr)
		if '"hasNextPage":true' in dLVhlByrevFDXbPKgcYmWR:
			zLEP9N4BOsVrXa = str(int(zLEP9N4BOsVrXa)+1)
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'صفحة '+zLEP9N4BOsVrXa,url,413,iiy37aKq0pCEIOwfcTh61xb4U,zLEP9N4BOsVrXa)
	return
def f7Ub2cBVroKCt(url,w3Ocz1JhkdGN6MartBi82mHxpsW):
	id = url.split('/')[-1]
	xmsw4p9VOT7,CIKVfX7vAi = w3Ocz1JhkdGN6MartBi82mHxpsW.split('::',1)
	fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN+'/'+xmsw4p9VOT7
	CIKVfX7vAi = rFqGlDAt8SQ(CIKVfX7vAi)
	title = PSwfZcdRYhpl5Igqz8xOEk67+'OWNER:  '+CIKVfX7vAi+YoQW601K4fMJcsreDnGVE5wUZIy7
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,402,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,CIKVfX7vAi)
	lHDuLVCy8kvqB6Rxh4Gs5K = '''{"operationName":"DISCOVERY_QUEUE_QUERY","variables":{"collectionXid":"myplaylistid","videoXid":"x7s7qbn"},"query":"query DISCOVERY_QUEUE_QUERY($videoXid: String!, $collectionXid: String, $device: String, $videoCountPerSection: Int) {  views {    id    neon {      id      sections(device: $device, space: \\"watching\\", followingChannelXids: [], followingTopicXids: [], watchedVideoXids: [], context: {mediaXid: $videoXid, collectionXid: $collectionXid}, first: 20) {        edges {          node {            id            name            groupingType            relatedComponent {              ... on Channel {                __typename                id                xid                name                displayName                logoURL(size: \\"x60\\")                logoURLx25: logoURL(size: \\"x25\\")              }              ... on Topic {                __typename                id                xid                name                names {                  edges {                    node {                      id                      name                      language {                        id                        codeAlpha2                        __typename                      }                      __typename                    }                    __typename                  }                  __typename                }              }              ... on Collection {                __typename                id                xid                name              }              __typename            }            components(first: $videoCountPerSection) {              metadata {                algorithm {                  name                  version                  uuid                  __typename                }                __typename              }              edges {                node {                  ... on Video {                    __typename                    id                    xid                    title                    duration                    thumbnailx60: thumbnailURL(size: \\"x60\\")                    thumbnailx120: thumbnailURL(size: \\"x120\\")                    thumbnailx240: thumbnailURL(size: \\"x240\\")                    thumbnailx720: thumbnailURL(size: \\"x720\\")                    channel {                      id                      xid                      accountType                      displayName                      logoURLx25: logoURL(size: \\"x25\\")                      logoURL(size: \\"x60\\")                      __typename                    }                  }                  ... on Channel {                    __typename                    id                    xid                    name                    displayName                    accountType                    logoURL(size: \\"x60\\")                  }                  __typename                }                __typename              }              __typename            }            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	lHDuLVCy8kvqB6Rxh4Gs5K = lHDuLVCy8kvqB6Rxh4Gs5K.replace('myplaylistid',id)
	Vxz6OndPIX4g2kaRp7 = lJj2EHGkVLAo1BOY70zF(lHDuLVCy8kvqB6Rxh4Gs5K)
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"collection_videos"(.*?)"SectionEdge"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('"node".*?"xid":"(.*?)",.*?"title":"(.*?)",.*?"duration":(.*?),".*?thumbnailx240":"(.*?)",.*?"xid":"(.*?)",.*?"displayName":"(.*?)",',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for id,title,Zt6GY7K2oFeAd5kTy3nJvDBpQr,C0dvhEbPWYlUtimM3x,xmsw4p9VOT7,CIKVfX7vAi in items:
			C0dvhEbPWYlUtimM3x = C0dvhEbPWYlUtimM3x.replace('\/','/')
			fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN+'/video/'+id
			title = rFqGlDAt8SQ(title)
			w3Ocz1JhkdGN6MartBi82mHxpsW = xmsw4p9VOT7+'::'+CIKVfX7vAi
			bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,403,C0dvhEbPWYlUtimM3x,Zt6GY7K2oFeAd5kTy3nJvDBpQr,w3Ocz1JhkdGN6MartBi82mHxpsW)
	return
def NtrLa2SoMTWkeqQB(url,zLEP9N4BOsVrXa=iiy37aKq0pCEIOwfcTh61xb4U):
	if zLEP9N4BOsVrXa==iiy37aKq0pCEIOwfcTh61xb4U: zLEP9N4BOsVrXa = '1'
	qCVlj6LiNza2MbZosSecpWQGuJd7 = url.split('/')[-2]
	if 'sort=' in url: sort = url.split('sort=')[1].split('&')[0]
	else: sort = 'recent'
	lHDuLVCy8kvqB6Rxh4Gs5K = '''{"operationName":"CHANNEL_VIDEOS_QUERY","variables":{"channel_xid":"mychannelid","sort":"mysortmethod","page":mypagenumber},"query":"fragment CHANNEL_BASE_FRAGMENT on Channel {  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  isFollowed  accountType  __typename}fragment CHANNEL_IMAGES_FRAGMENT on Channel {  id  coverURLx375: coverURL(size: \\"x375\\")  __typename}fragment CHANNEL_UPDATED_FRAGMENT on Channel {  id  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}fragment CHANNEL_COMPLETE_FRAGMENT on Channel {  id  ...CHANNEL_BASE_FRAGMENT  ...CHANNEL_IMAGES_FRAGMENT  ...CHANNEL_UPDATED_FRAGMENT  description  coverURL1024x: coverURL(size: \\"1024x\\")  coverURL1920x: coverURL(size: \\"1920x\\")  externalLinks {    facebookURL    twitterURL    websiteURL    instagramURL    __typename  }  __typename}fragment CHANNEL_FRAGMENT on Channel {  accountType  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  coverURLx375: coverURL(size: \\"x375\\")  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}fragment VIDEO_FRAGMENT on Video {  id  xid  title  viewCount  duration  createdAt  isInWatchLater  channel {    id    ...CHANNEL_FRAGMENT    __typename  }  thumbURLx240: thumbnailURL(size: \\"x240\\")  thumbURLx360: thumbnailURL(size: \\"x360\\")  thumbURLx480: thumbnailURL(size: \\"x480\\")  thumbURLx720: thumbnailURL(size: \\"x720\\")  __typename}query CHANNEL_VIDEOS_QUERY($channel_xid: String!, $sort: String, $page: Int!) {  channel(xid: $channel_xid) {    id    ...CHANNEL_COMPLETE_FRAGMENT    channel_videos_all_videos: videos(sort: $sort, page: $page, first: mypagelimit) {      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...VIDEO_FRAGMENT          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	lHDuLVCy8kvqB6Rxh4Gs5K = lHDuLVCy8kvqB6Rxh4Gs5K.replace('mychannelid',qCVlj6LiNza2MbZosSecpWQGuJd7)
	lHDuLVCy8kvqB6Rxh4Gs5K = lHDuLVCy8kvqB6Rxh4Gs5K.replace('mypagelimit','40')
	lHDuLVCy8kvqB6Rxh4Gs5K = lHDuLVCy8kvqB6Rxh4Gs5K.replace('mypagenumber',zLEP9N4BOsVrXa)
	lHDuLVCy8kvqB6Rxh4Gs5K = lHDuLVCy8kvqB6Rxh4Gs5K.replace('mysortmethod',sort)
	Vxz6OndPIX4g2kaRp7 = lJj2EHGkVLAo1BOY70zF(lHDuLVCy8kvqB6Rxh4Gs5K)
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"channel_videos_all_videos"(.*?)"VideoConnection"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('"node".*?"xid":"(.*?)",.*?"title":"(.*?)",.*?"duration":(.*?),".*?name":"(.*?)",.*?"displayName":"(.*?)",.*?"thumbURLx240":"(.*?)",',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for id,title,Zt6GY7K2oFeAd5kTy3nJvDBpQr,xmsw4p9VOT7,CIKVfX7vAi,C0dvhEbPWYlUtimM3x in items:
			C0dvhEbPWYlUtimM3x = C0dvhEbPWYlUtimM3x.replace('\/','/')
			fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN+'/video/'+id
			title = rFqGlDAt8SQ(title)
			w3Ocz1JhkdGN6MartBi82mHxpsW = xmsw4p9VOT7+'::'+CIKVfX7vAi
			bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,403,C0dvhEbPWYlUtimM3x,Zt6GY7K2oFeAd5kTy3nJvDBpQr,w3Ocz1JhkdGN6MartBi82mHxpsW)
		if '"hasNextPage":true' in Vxz6OndPIX4g2kaRp7:
			zLEP9N4BOsVrXa = str(int(zLEP9N4BOsVrXa)+1)
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'صفحة '+zLEP9N4BOsVrXa,url,408,iiy37aKq0pCEIOwfcTh61xb4U,zLEP9N4BOsVrXa)
	return
def x1V49dtl2zGayfZIRepuUDM0(url,zLEP9N4BOsVrXa=iiy37aKq0pCEIOwfcTh61xb4U):
	if zLEP9N4BOsVrXa==iiy37aKq0pCEIOwfcTh61xb4U: zLEP9N4BOsVrXa = '1'
	qCVlj6LiNza2MbZosSecpWQGuJd7 = url.split('/')[-2]
	if 'sort=' in url: sort = url.split('sort=')[1].split('&')[0]
	else: sort = 'recent'
	lHDuLVCy8kvqB6Rxh4Gs5K = '''{"operationName":"CHANNEL_COLLECTIONS_QUERY","variables":{"channel_xid":"mychannelid","sort":"mysortmethod","page":mypagenumber},"query":"fragment CHANNEL_BASE_FRAGMENT on Channel {  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  isFollowed  accountType  __typename}fragment CHANNEL_IMAGES_FRAGMENT on Channel {  id  coverURLx375: coverURL(size: \\"x375\\")  __typename}fragment CHANNEL_UPDATED_FRAGMENT on Channel {  id  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}fragment CHANNEL_COMPLETE_FRAGMENT on Channel {  id  ...CHANNEL_BASE_FRAGMENT  ...CHANNEL_IMAGES_FRAGMENT  ...CHANNEL_UPDATED_FRAGMENT  description  coverURL1024x: coverURL(size: \\"1024x\\")  coverURL1920x: coverURL(size: \\"1920x\\")  externalLinks {    facebookURL    twitterURL    websiteURL    instagramURL    __typename  }  __typename}fragment CHANNEL_FRAGMENT on Channel {  accountType  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  coverURLx375: coverURL(size: \\"x375\\")  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}query CHANNEL_COLLECTIONS_QUERY($channel_xid: String!, $sort: String, $page: Int!) {  channel(xid: $channel_xid) {    id    ...CHANNEL_COMPLETE_FRAGMENT    channel_playlist_collections: collections(sort: $sort, page: $page, first: mypagelimit) {      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          xid          updatedAt          name          description          thumbURLx240: thumbnailURL(size: \\"x240\\")          thumbURLx360: thumbnailURL(size: \\"x360\\")          thumbURLx480: thumbnailURL(size: \\"x480\\")          stats {            videos {              total              __typename            }            __typename          }          channel {            id            ...CHANNEL_FRAGMENT            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	lHDuLVCy8kvqB6Rxh4Gs5K = lHDuLVCy8kvqB6Rxh4Gs5K.replace('mychannelid',qCVlj6LiNza2MbZosSecpWQGuJd7)
	lHDuLVCy8kvqB6Rxh4Gs5K = lHDuLVCy8kvqB6Rxh4Gs5K.replace('mypagelimit','40')
	lHDuLVCy8kvqB6Rxh4Gs5K = lHDuLVCy8kvqB6Rxh4Gs5K.replace('mypagenumber',zLEP9N4BOsVrXa)
	lHDuLVCy8kvqB6Rxh4Gs5K = lHDuLVCy8kvqB6Rxh4Gs5K.replace('mysortmethod',sort)
	Vxz6OndPIX4g2kaRp7 = lJj2EHGkVLAo1BOY70zF(lHDuLVCy8kvqB6Rxh4Gs5K)
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"channel_playlist_collections"(.*?)"CollectionConnection"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('"node".*?"xid":"(.*?)",.*?"name":"(.*?)",.*?"thumbURLx240":"(.*?)",.*?"total":(.*?),".*?xid":"(.*?)",.*?"name":"(.*?)",.*?"displayName":"(.*?)",',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for id,name,C0dvhEbPWYlUtimM3x,count,BDmNtsv3hMT2rxjKYZl6cG4gFU,xmsw4p9VOT7,CIKVfX7vAi in items:
			C0dvhEbPWYlUtimM3x = C0dvhEbPWYlUtimM3x.replace('\/','/')
			fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN+'/playlist/'+id
			title = 'LIST'+count+':  '+name
			title = rFqGlDAt8SQ(title)
			w3Ocz1JhkdGN6MartBi82mHxpsW = xmsw4p9VOT7+'::'+CIKVfX7vAi
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,401,C0dvhEbPWYlUtimM3x,iiy37aKq0pCEIOwfcTh61xb4U,w3Ocz1JhkdGN6MartBi82mHxpsW)
		if '"hasNextPage":true' in Vxz6OndPIX4g2kaRp7:
			zLEP9N4BOsVrXa = str(int(zLEP9N4BOsVrXa)+1)
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'صفحة '+zLEP9N4BOsVrXa,url,407,iiy37aKq0pCEIOwfcTh61xb4U,zLEP9N4BOsVrXa)
	return
def KK9Gpc4yDEt6f0VegbnWRO7qrNhH(url,NgkS5YOv4oEul):
	qCVlj6LiNza2MbZosSecpWQGuJd7 = url.split('/')[3]
	lHDuLVCy8kvqB6Rxh4Gs5K = '''{"operationName":"CHANNEL_QUERY_DESKTOP","variables":{"channel_name":"mychannelid","relatedChannels":100},"query":"fragment CHANNEL_FRAGMENT on Channel {  accountType  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  coverURLx375: coverURL(size: \\"x375\\")  isFollowed  stats {    id    views {      id      total      __typename    }    followers {      id      total      __typename    }    videos {      id      total      __typename    }    __typename  }  __typename}fragment LIVE_FRAGMENT on Live {  id  xid  title  startAt  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  channel {    id    ...CHANNEL_FRAGMENT    __typename  }  __typename}fragment VIDEO_FRAGMENT on Video {  id  xid  title  viewCount  duration  createdAt  isInWatchLater  channel {    id    ...CHANNEL_FRAGMENT    __typename  }  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment CHANNEL_MAIN_FRAGMENT on Channel {  id  xid  name  displayName  description  accountType  isArtist  logoURL(size: \\"x60\\")  coverURL1024x: coverURL(size: \\"1024x\\")  coverURL1920x: coverURL(size: \\"1920x\\")  isFollowed  tagline  country {    id    codeAlpha2    __typename  }  stats {    id    views {      id      total      __typename    }    followers {      id      total      __typename    }    videos {      id      total      __typename    }    __typename  }  externalLinks {    id    facebookURL    twitterURL    websiteURL    instagramURL    pinterestURL    __typename  }  channel_lives_now: lives(first: 4, isOnAir: true) {    edges {      node {        id        ...LIVE_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_lives_scheduled: lives(first: 4, startIn: 7200) {    edges {      node {        id        ...LIVE_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_featured_videos: videos(first: 4, isFeatured: true) {    edges {      node {        id        ...VIDEO_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_all_videos: videos(first: 4) {    edges {      node {        id        ...VIDEO_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_most_viewed: videos(first: 4, sort: \\"visited\\") {    edges {      node {        id        ...VIDEO_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_collections: collections(first: 4) {    edges {      node {        id        xid        name        description        stats {          id          videos {            id            total            __typename          }          __typename        }        thumbnailx240: thumbnailURL(size: \\"x240\\")        thumbnailx360: thumbnailURL(size: \\"x360\\")        thumbnailx480: thumbnailURL(size: \\"x480\\")        channel {          id          ...CHANNEL_FRAGMENT          __typename        }        __typename      }      __typename    }    __typename  }  channel_related_channel: networkChannels(    hasPublicVideos: true    first: $relatedChannels  ) {    edges {      node {        id        ...CHANNEL_FRAGMENT        __typename      }      __typename    }    __typename  }  __typename}query CHANNEL_QUERY_DESKTOP($channel_name: String!, $relatedChannels: Int) {  channel(name: $channel_name) {    id    ...CHANNEL_MAIN_FRAGMENT    __typename  }}"}'''
	lHDuLVCy8kvqB6Rxh4Gs5K = lHDuLVCy8kvqB6Rxh4Gs5K.replace('mychannelid',qCVlj6LiNza2MbZosSecpWQGuJd7)
	Vxz6OndPIX4g2kaRp7 = lJj2EHGkVLAo1BOY70zF(lHDuLVCy8kvqB6Rxh4Gs5K)
	MTjg1oEBGL3Zd5YzSUnrV = bHyN37Y82ZKVLOexBF.loads(Vxz6OndPIX4g2kaRp7)
	try: items = MTjg1oEBGL3Zd5YzSUnrV['data']['channel'][NgkS5YOv4oEul]['edges']
	except: items = []
	if not items: bP6z3OSLp7va('link',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'لا توجد نتائج',iiy37aKq0pCEIOwfcTh61xb4U,9999)
	else:
		for YXD9KNfjCaLwkcrvJxldn7I in items:
			Xxlu5McfzP2Irb = YXD9KNfjCaLwkcrvJxldn7I['node']
			lDLFBqgd8Qx0EeIhZkuY94UCzH3A = Xxlu5McfzP2Irb['xid']
			keys = list(Xxlu5McfzP2Irb.keys())
			MDPjG2qR4HcXTil51w8QNVOsh7dopv = Xxlu5McfzP2Irb['__typename'].lower()
			if MDPjG2qR4HcXTil51w8QNVOsh7dopv=='channel':
				name = Xxlu5McfzP2Irb['name']
				pACtVk0GyRYhDiUa4 = Xxlu5McfzP2Irb['displayName']
				title = 'USER:  '+pACtVk0GyRYhDiUa4
				C0dvhEbPWYlUtimM3x = Xxlu5McfzP2Irb['coverURLx375']
			else:
				name = Xxlu5McfzP2Irb['channel']['name']
				pACtVk0GyRYhDiUa4 = Xxlu5McfzP2Irb['channel']['displayName']
				title = Xxlu5McfzP2Irb['title']
				C0dvhEbPWYlUtimM3x = Xxlu5McfzP2Irb['thumbnailx360']
				if MDPjG2qR4HcXTil51w8QNVOsh7dopv=='live': title = 'LIVE:  '+title
			title = rFqGlDAt8SQ(title)
			w3Ocz1JhkdGN6MartBi82mHxpsW = name+'::'+pACtVk0GyRYhDiUa4
			if iELueYz3J1FmxaW7vc:
				title = title.encode(df6QpwGxuJVZr)
				w3Ocz1JhkdGN6MartBi82mHxpsW = w3Ocz1JhkdGN6MartBi82mHxpsW.encode(df6QpwGxuJVZr)
			C0dvhEbPWYlUtimM3x = C0dvhEbPWYlUtimM3x.replace('\/','/')
			if MDPjG2qR4HcXTil51w8QNVOsh7dopv=='channel':
				fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN+'/'+lDLFBqgd8Qx0EeIhZkuY94UCzH3A
				bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,402,C0dvhEbPWYlUtimM3x,iiy37aKq0pCEIOwfcTh61xb4U,w3Ocz1JhkdGN6MartBi82mHxpsW)
			else:
				if MDPjG2qR4HcXTil51w8QNVOsh7dopv=='video': Zt6GY7K2oFeAd5kTy3nJvDBpQr = str(Xxlu5McfzP2Irb['duration'])
				else: Zt6GY7K2oFeAd5kTy3nJvDBpQr = iiy37aKq0pCEIOwfcTh61xb4U
				fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN+'/video/'+lDLFBqgd8Qx0EeIhZkuY94UCzH3A
				bP6z3OSLp7va(MDPjG2qR4HcXTil51w8QNVOsh7dopv,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,403,C0dvhEbPWYlUtimM3x,Zt6GY7K2oFeAd5kTy3nJvDBpQr,w3Ocz1JhkdGN6MartBi82mHxpsW)
	return
def OObFArCgyz(search,zLEP9N4BOsVrXa=iiy37aKq0pCEIOwfcTh61xb4U):
	if zLEP9N4BOsVrXa==iiy37aKq0pCEIOwfcTh61xb4U: zLEP9N4BOsVrXa = '1'
	lHDuLVCy8kvqB6Rxh4Gs5K = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeHashtags":true,"shouldIncludeVideos":false,"shouldIncludeLives":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  duration  aspectRatio  thumbnail(height: PORTRAIT_240) {    id    url    __typename  }  creator {    id    xid    name    displayName    accountType    avatar(height: SQUARE_60) {      id      url      __typename    }    __typename  }  __typename}fragment CHANNEL_BASE_FRAG on Channel {  id  xid  name  displayName  accountType  isFollowed  avatar(height: SQUARE_120) {    id    url    __typename  }  followerEngagement {    id    followDate    __typename  }  metrics {    id    engagement {      id      followers {        edges {          node {            id            total            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  description  thumbnail(height: PORTRAIT_240) {    id    url    __typename  }  creator {    id    xid    name    displayName    accountType    avatar(height: SQUARE_60) {      id      url      __typename    }    __typename  }  metrics {    id    engagement {      id      videos(filter: {visibility: {eq: PUBLIC}}) {        edges {          node {            id            total            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }  __typename}fragment HASHTAG_BASE_FRAG on Hashtag {  id  xid  name  metrics {    id    engagement {      id      videos {        edges {          node {            id            total            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }  __typename}fragment LIVE_BASE_FRAGMENT on Live {  id  xid  title  audienceCount  aspectRatio  isOnAir  thumbnail(height: PORTRAIT_240) {    id    url    __typename  }  creator {    id    xid    name    displayName    accountType    avatar(height: SQUARE_60) {      id      url      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeHashtags: Boolean!, $shouldIncludeLives: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(      query: $query      first: $limit      page: $page      sort: $sortByVideos      durationMin: $durationMinVideos      durationMax: $durationMaxVideos      createdAfter: $createdAfterVideos    ) @include(if: $shouldIncludeVideos) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          __typename        }        __typename      }      __typename    }    lives(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeLives) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...LIVE_BASE_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    hashtags(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeHashtags) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...HASHTAG_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	lHDuLVCy8kvqB6Rxh4Gs5K = lHDuLVCy8kvqB6Rxh4Gs5K.replace('mysearchwords',search)
	lHDuLVCy8kvqB6Rxh4Gs5K = lHDuLVCy8kvqB6Rxh4Gs5K.replace('mypagelimit','40')
	lHDuLVCy8kvqB6Rxh4Gs5K = lHDuLVCy8kvqB6Rxh4Gs5K.replace('mypagenumber',zLEP9N4BOsVrXa)
	url = JaQEtCzDXgos1cdZN+'/search/'+search+'/hashtags'
	dLVhlByrevFDXbPKgcYmWR = lJj2EHGkVLAo1BOY70zF(lHDuLVCy8kvqB6Rxh4Gs5K,search)
	if dLVhlByrevFDXbPKgcYmWR:
		qvLKBSJ1inD = DeIL3qoa2UBtYPb('dict',dLVhlByrevFDXbPKgcYmWR)
		try: ElbU2unpLiOQDAcXwRe4mKM5S1W = qvLKBSJ1inD['data']['search']['hashtags']['edges']
		except: ElbU2unpLiOQDAcXwRe4mKM5S1W = []
		for MMKAQvR16eHBu7xkpjlno in ElbU2unpLiOQDAcXwRe4mKM5S1W:
			name = MMKAQvR16eHBu7xkpjlno['node']['name']
			name = vvmT3DLXkhPBwIaOAo6srZpEnRVJC(name)
			fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN+'/hashtag/'+name[1:]
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'HSHTG: '+name,fCXyTlcmF4WuetVork,417)
		if '"hasNextPage":true' in dLVhlByrevFDXbPKgcYmWR:
			zLEP9N4BOsVrXa = str(int(zLEP9N4BOsVrXa)+1)
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'صفحة '+zLEP9N4BOsVrXa,url,416,iiy37aKq0pCEIOwfcTh61xb4U,zLEP9N4BOsVrXa,search)
	return
def JQvxTRciOC(url,zLEP9N4BOsVrXa=iiy37aKq0pCEIOwfcTh61xb4U):
	if zLEP9N4BOsVrXa==iiy37aKq0pCEIOwfcTh61xb4U: zLEP9N4BOsVrXa = '1'
	name = url.split('/')[-1]
	lHDuLVCy8kvqB6Rxh4Gs5K = '''{"operationName":"HASHTAG_VIDEOS_QUERY","variables":{"hashtag_name":"#myhashtagname","page":mypagenumber},"query":"fragment FRAG_VIDEO_BASE on Video {  id  xid  title  description  thumbnail: thumbnailURL(size: \\"x240\\")  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  bestAvailableQuality  duration  createdAt  viewerEngagement {    id    liked    favorited    __typename  }  isExplicit  canDisplayAds  aspectRatio  stats {    id    views {      id      total      __typename    }    __typename  }  language {    id    codeAlpha2    __typename  }  videoHeight: height  videoWidth: width  __typename}fragment CHANNEL_BASE_FRAG on Channel {  id  xid  name  displayName  description  logoURL(size: \\"x25\\")  logoURLx60: logoURL(size: \\"x60\\")  coverURL(size: \\"x200\\")  coverURLx1024: coverURL(size: \\"1024x\\")  isFollowed  isArtist  accountType  __typename}fragment VIDEO_FRAG on Video {  id  ...FRAG_VIDEO_BASE  channel {    id    ...CHANNEL_BASE_FRAG    __typename  }  __typename}query HASHTAG_VIDEOS_QUERY($hashtag_name: String!, $page: Int!) {  contentFeed(    name: HASHTAG    filter: {name: {eq: $hashtag_name}, post: {eq: VIDEO}}    sort: {create: DESC}    page: $page    first: 30  ) {    totalCount    pageInfo {      hasNextPage      nextPage      __typename    }    edges {      node {        post {          ...VIDEO_FRAG          __typename        }        featured        __typename      }      __typename    }    __typename  }}"}'''
	lHDuLVCy8kvqB6Rxh4Gs5K = lHDuLVCy8kvqB6Rxh4Gs5K.replace('myhashtagname',name)
	lHDuLVCy8kvqB6Rxh4Gs5K = lHDuLVCy8kvqB6Rxh4Gs5K.replace('mypagenumber',zLEP9N4BOsVrXa)
	dLVhlByrevFDXbPKgcYmWR = lJj2EHGkVLAo1BOY70zF(lHDuLVCy8kvqB6Rxh4Gs5K)
	if dLVhlByrevFDXbPKgcYmWR:
		qvLKBSJ1inD = DeIL3qoa2UBtYPb('dict',dLVhlByrevFDXbPKgcYmWR)
		ElbU2unpLiOQDAcXwRe4mKM5S1W = qvLKBSJ1inD['data']['contentFeed']['edges']
		for MMKAQvR16eHBu7xkpjlno in ElbU2unpLiOQDAcXwRe4mKM5S1W:
			Zt6GY7K2oFeAd5kTy3nJvDBpQr = str(MMKAQvR16eHBu7xkpjlno['node']['post']['duration'])
			title = vvmT3DLXkhPBwIaOAo6srZpEnRVJC(MMKAQvR16eHBu7xkpjlno['node']['post']['title'])
			title = title.replace('\/','/')
			lDLFBqgd8Qx0EeIhZkuY94UCzH3A = MMKAQvR16eHBu7xkpjlno['node']['post']['xid']
			C0dvhEbPWYlUtimM3x = MMKAQvR16eHBu7xkpjlno['node']['post']['thumbnailx480']
			C0dvhEbPWYlUtimM3x = C0dvhEbPWYlUtimM3x.replace('\/','/')
			fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN+'/video/'+lDLFBqgd8Qx0EeIhZkuY94UCzH3A
			bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,403,C0dvhEbPWYlUtimM3x,Zt6GY7K2oFeAd5kTy3nJvDBpQr)
		if '"hasNextPage":true' in dLVhlByrevFDXbPKgcYmWR:
			zLEP9N4BOsVrXa = str(int(zLEP9N4BOsVrXa)+1)
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'صفحة '+zLEP9N4BOsVrXa,url,416,iiy37aKq0pCEIOwfcTh61xb4U,zLEP9N4BOsVrXa)
	return
def lJj2EHGkVLAo1BOY70zF(lHDuLVCy8kvqB6Rxh4Gs5K,search=iiy37aKq0pCEIOwfcTh61xb4U):
	if J1MoiYc7ZwzKS: lHDuLVCy8kvqB6Rxh4Gs5K = lHDuLVCy8kvqB6Rxh4Gs5K.encode(df6QpwGxuJVZr)
	Sc017hJyNzQeAjf = ElLYGOVs6xU2kcr81Q3u4fCJzhB0o5()
	headers = {"Authorization":Sc017hJyNzQeAjf,"Origin":JaQEtCzDXgos1cdZN,'Content-Type':'text/plain; charset=utf-8'}
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(r3rnfZ7cdxzNFebIRaLSG6B,'POST',QSaKzorWqRMY8JkTtNdG1exb,lHDuLVCy8kvqB6Rxh4Gs5K,headers,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'DAILYMOTION-GET_PAGEDATA-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	return Vxz6OndPIX4g2kaRp7
def ElLYGOVs6xU2kcr81Q3u4fCJzhB0o5():
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(r3rnfZ7cdxzNFebIRaLSG6B,'GET',JaQEtCzDXgos1cdZN,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'DAILYMOTION-GET_AUTHINTICATION-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	jjzOvMC1RVho65Td = dEyT9xhGjolYzLCH7460w3.findall('var r="(.*?)",o="(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	C789NGM6c5Vm3YXoLdI,SjIsR5fL8bFUYOCtWkvPl3z = jjzOvMC1RVho65Td[-1]
	ll1VidLYquRmh8UsGykEB = 'https://graphql.api.dailymotion.com/oauth/token'
	VXiWRLGQysTY2PFb = 'client_credentials'
	data = {'client_id':C789NGM6c5Vm3YXoLdI,'client_secret':SjIsR5fL8bFUYOCtWkvPl3z,'grant_type':VXiWRLGQysTY2PFb}
	headers = {'Content-Type':'application/x-www-form-urlencoded'}
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(r3rnfZ7cdxzNFebIRaLSG6B,'POST',ll1VidLYquRmh8UsGykEB,data,headers,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'DAILYMOTION-GET_AUTHINTICATION-2nd')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	jjzOvMC1RVho65Td = dEyT9xhGjolYzLCH7460w3.findall('"access_token": *"(.*?)".*?"token_type": *"(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	q0qMDVAu45hLctQp9gUKBGeN,Gr14Oq8woQtflsBC93XNj2YVD6ziK = jjzOvMC1RVho65Td[0]
	Sc017hJyNzQeAjf = Gr14Oq8woQtflsBC93XNj2YVD6ziK+" "+q0qMDVAu45hLctQp9gUKBGeN
	return Sc017hJyNzQeAjf
def mUhJtHB9nw(search,uuX8TYmVoFRlvpQ7LZ=iiy37aKq0pCEIOwfcTh61xb4U):
	search,brFQp5vmgJWdZfEkCBOlu9c,showDialogs = XkYnev3ZCA6ahO94(search)
	if not uuX8TYmVoFRlvpQ7LZ and showDialogs:
		kvJ7hNoZmKl4ARW = ['بحث عن فيديوهات','بحث عن آخر الفيديوهات','بحث عن الفيديوهات الاكثر مشاهدة','(جيد للمسلسلات) بحث عن قوائم تشغيل','بحث عن مستخدم','بحث عن بث حي','بحث عن هاشتاك']
		mmfrx2S5XqknFTDeRhj49LuYv1wW0 = ccv1mVPUsnr('موقع ديلي موشن - اختر البحث',kvJ7hNoZmKl4ARW)
		if mmfrx2S5XqknFTDeRhj49LuYv1wW0==-1: return
		elif mmfrx2S5XqknFTDeRhj49LuYv1wW0==0: uuX8TYmVoFRlvpQ7LZ = 'videos?sortBy='
		elif mmfrx2S5XqknFTDeRhj49LuYv1wW0==1: uuX8TYmVoFRlvpQ7LZ = 'videos?sortBy=RECENT'
		elif mmfrx2S5XqknFTDeRhj49LuYv1wW0==2: uuX8TYmVoFRlvpQ7LZ = 'videos?sortBy=VIEW_COUNT'
		elif mmfrx2S5XqknFTDeRhj49LuYv1wW0==3: uuX8TYmVoFRlvpQ7LZ = 'playlists'
		elif mmfrx2S5XqknFTDeRhj49LuYv1wW0==4: uuX8TYmVoFRlvpQ7LZ = 'channels'
		elif mmfrx2S5XqknFTDeRhj49LuYv1wW0==5: uuX8TYmVoFRlvpQ7LZ = 'lives'
		elif mmfrx2S5XqknFTDeRhj49LuYv1wW0==6: uuX8TYmVoFRlvpQ7LZ = 'hashtags'
	elif '_DAILYMOTION-VIDEOS_' in brFQp5vmgJWdZfEkCBOlu9c: uuX8TYmVoFRlvpQ7LZ = 'videos?sortBy='
	elif '_DAILYMOTION-PLAYLISTS_' in brFQp5vmgJWdZfEkCBOlu9c: uuX8TYmVoFRlvpQ7LZ = 'playlists'
	elif '_DAILYMOTION-CHANNELS_' in brFQp5vmgJWdZfEkCBOlu9c: uuX8TYmVoFRlvpQ7LZ = 'channels'
	elif '_DAILYMOTION-LIVES_' in brFQp5vmgJWdZfEkCBOlu9c: uuX8TYmVoFRlvpQ7LZ = 'lives'
	elif '_DAILYMOTION-HASHTAGS_' in brFQp5vmgJWdZfEkCBOlu9c: uuX8TYmVoFRlvpQ7LZ = 'hashtags'
	elif not uuX8TYmVoFRlvpQ7LZ: uuX8TYmVoFRlvpQ7LZ = 'videos?sortBy='
	if not search:
		search = TTBf6S08q1NKXd5v9wa()
		if not search: return
	if 'videos' in uuX8TYmVoFRlvpQ7LZ: JRgswvixIT8(search+'/'+uuX8TYmVoFRlvpQ7LZ)
	elif 'playlists' in uuX8TYmVoFRlvpQ7LZ: QuPihFMIDdg(search)
	elif 'channels' in uuX8TYmVoFRlvpQ7LZ: Vqitn5ybGoRrgaUeT(search)
	elif 'lives' in uuX8TYmVoFRlvpQ7LZ: V9QC72mhkyEeoHM(search)
	elif 'hashtags' in uuX8TYmVoFRlvpQ7LZ: OObFArCgyz(search)
	return
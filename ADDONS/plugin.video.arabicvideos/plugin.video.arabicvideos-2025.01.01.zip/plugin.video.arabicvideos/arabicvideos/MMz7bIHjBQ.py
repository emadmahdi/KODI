# -*- coding: utf-8 -*-
from braVAkwfBN import *
headers = {'User-Agent':iiy37aKq0pCEIOwfcTh61xb4U}
sQU2GnRoMwLK8CBdfzmNr4jXyO = 'PANET'
ooQEi5O6tYsGVF8LU0TC3hgMeflBwH = '_PNT_'
JaQEtCzDXgos1cdZN = gZ4LwbKaOm[sQU2GnRoMwLK8CBdfzmNr4jXyO][0]
def sHVM8YchrDjZAJ7(mode,url,zLEP9N4BOsVrXa,text):
	if   mode==30: EA7FzO1kMZGQXDd2giB0cwLom = jihuS9LVAvTrClPapMbUEwfn8XN()
	elif mode==31: EA7FzO1kMZGQXDd2giB0cwLom = hemvDOJkEw2FdCSgnL1VaR(url,'3')
	elif mode==32: EA7FzO1kMZGQXDd2giB0cwLom = rmEH1eAYBg8xPK(url)
	elif mode==33: EA7FzO1kMZGQXDd2giB0cwLom = TW6Z0zqaDl(url)
	elif mode==35: EA7FzO1kMZGQXDd2giB0cwLom = hemvDOJkEw2FdCSgnL1VaR(url,'1')
	elif mode==36: EA7FzO1kMZGQXDd2giB0cwLom = hemvDOJkEw2FdCSgnL1VaR(url,'2')
	elif mode==37: EA7FzO1kMZGQXDd2giB0cwLom = hemvDOJkEw2FdCSgnL1VaR(url,'4')
	elif mode==38: EA7FzO1kMZGQXDd2giB0cwLom = FaD6NxfSIbzZimr9d4wOjQMkYhn5()
	elif mode==39: EA7FzO1kMZGQXDd2giB0cwLom = mUhJtHB9nw(text,zLEP9N4BOsVrXa)
	else: EA7FzO1kMZGQXDd2giB0cwLom = False
	return EA7FzO1kMZGQXDd2giB0cwLom
def jihuS9LVAvTrClPapMbUEwfn8XN():
	bP6z3OSLp7va('live',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'قناة هلا من موقع بانيت',iiy37aKq0pCEIOwfcTh61xb4U,38)
	return iiy37aKq0pCEIOwfcTh61xb4U
def hemvDOJkEw2FdCSgnL1VaR(url,select=iiy37aKq0pCEIOwfcTh61xb4U):
	type = url.split('/')[3]
	if type=='mosalsalat':
		Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(Dxc7GChQwZ4kOlKHSbL06agnB,url,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,'PANET-CATEGORIES-1st')
		if select=='3':
			UUIohmv597bO83YCLgWS=dEyT9xhGjolYzLCH7460w3.findall('categoriesMenu(.*?)seriesForm',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
			PPH1sQtTkDBbnlYpZfo5= UUIohmv597bO83YCLgWS[0]
			items=dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)">(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
			for fCXyTlcmF4WuetVork,name in items:
				if 'كليبات مضحكة' in name: continue
				url = JaQEtCzDXgos1cdZN + fCXyTlcmF4WuetVork
				name = name.strip(iFBmE2MUIpSu34wsd7Rf6z)
				bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+name,url,32)
		if select=='4':
			UUIohmv597bO83YCLgWS=dEyT9xhGjolYzLCH7460w3.findall('video-details-panel(.*?)v></a></div>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
			PPH1sQtTkDBbnlYpZfo5= UUIohmv597bO83YCLgWS[0]
			items=dEyT9xhGjolYzLCH7460w3.findall('panet-thumbnail" href="(.*?)".*?src="(.*?)".*?panet-info">(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
			for fCXyTlcmF4WuetVork,C0dvhEbPWYlUtimM3x,title in items:
				url = JaQEtCzDXgos1cdZN + fCXyTlcmF4WuetVork
				title = title.strip(iFBmE2MUIpSu34wsd7Rf6z)
				bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,url,32,C0dvhEbPWYlUtimM3x)
	if type=='movies':
		Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(Dxc7GChQwZ4kOlKHSbL06agnB,url,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,'PANET-CATEGORIES-2nd')
		if select=='1':
			UUIohmv597bO83YCLgWS=dEyT9xhGjolYzLCH7460w3.findall('moviesGender(.*?)select',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
			PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
			items=dEyT9xhGjolYzLCH7460w3.findall('option><option value="(.*?)">(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
			for aasX2cby4Vo5rTgB,name in items:
				url = JaQEtCzDXgos1cdZN + '/movies/genre/' + aasX2cby4Vo5rTgB
				name = name.strip(iFBmE2MUIpSu34wsd7Rf6z)
				bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+name,url,32)
		elif select=='2':
			UUIohmv597bO83YCLgWS=dEyT9xhGjolYzLCH7460w3.findall('moviesActor(.*?)select',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
			PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
			items=dEyT9xhGjolYzLCH7460w3.findall('option><option value="(.*?)">(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
			for aasX2cby4Vo5rTgB,name in items:
				name = name.strip(iFBmE2MUIpSu34wsd7Rf6z)
				url = JaQEtCzDXgos1cdZN + '/movies/actor/' + aasX2cby4Vo5rTgB
				bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+name,url,32)
	return
def rmEH1eAYBg8xPK(url):
	type = url.split('/')[3]
	Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(PNjZMS7nxa9clHusz1,url,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,'PANET-ITEMS-1st')
	if 'home' in url: type='episodes'
	if type=='mosalsalat':
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('panet-thumbnails(.*?)panet-pagination',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if UUIohmv597bO83YCLgWS:
			PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
			items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)""><img src="(.*?)".*?h2>(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
			for fCXyTlcmF4WuetVork,C0dvhEbPWYlUtimM3x,name in items:
				url = JaQEtCzDXgos1cdZN + fCXyTlcmF4WuetVork
				name = name.strip(iFBmE2MUIpSu34wsd7Rf6z)
				bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+name,url,32,C0dvhEbPWYlUtimM3x)
	if type=='movies':
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('advBarMars(.+?)panet-pagination',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('panet-thumbnail.*?href="(.*?)"><img src="(.*?)" alt="(.+?)"',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,C0dvhEbPWYlUtimM3x,name in items:
			name = name.strip(iFBmE2MUIpSu34wsd7Rf6z)
			url = JaQEtCzDXgos1cdZN + fCXyTlcmF4WuetVork
			bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+name,url,33,C0dvhEbPWYlUtimM3x)
	if type=='episodes':
		zLEP9N4BOsVrXa = url.split('/')[-1]
		if zLEP9N4BOsVrXa=='1':
			UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('advBarMars(.+?)advBarMars',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
			PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
			items = dEyT9xhGjolYzLCH7460w3.findall('panet-thumbnail.*?href="(.*?)"><img src="(.*?)".*?panet-title">(.*?)</div.*?panet-info">(.*?)</div',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
			count = 0
			for fCXyTlcmF4WuetVork,C0dvhEbPWYlUtimM3x,zN7sZyFnw5JTE8,title in items:
				count += 1
				if count==10: break
				name = title + ' - ' + zN7sZyFnw5JTE8
				url = JaQEtCzDXgos1cdZN + fCXyTlcmF4WuetVork
				bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+name,url,33,C0dvhEbPWYlUtimM3x)
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('advBarMars.*?advBarMars(.+?)panet-pagination',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('panet-thumbnail.*?href="(.*?)""><img src="(.*?)".*?panet-title"><h2>(.*?)</h2.*?panet-info"><h2>(.*?)</h2',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,C0dvhEbPWYlUtimM3x,title,zN7sZyFnw5JTE8 in items:
			zN7sZyFnw5JTE8 = zN7sZyFnw5JTE8.strip(iFBmE2MUIpSu34wsd7Rf6z)
			title = title.strip(iFBmE2MUIpSu34wsd7Rf6z)
			name = title + ' - ' + zN7sZyFnw5JTE8
			url = JaQEtCzDXgos1cdZN + fCXyTlcmF4WuetVork
			bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+name,url,33,C0dvhEbPWYlUtimM3x)
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('glyphicon-chevron-right(.+?)data-revive-zoneid="4"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
	items = dEyT9xhGjolYzLCH7460w3.findall('<li><a href="(.*?)">(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	for fCXyTlcmF4WuetVork,zLEP9N4BOsVrXa in items:
		url = JaQEtCzDXgos1cdZN + fCXyTlcmF4WuetVork
		name = 'صفحة ' + zLEP9N4BOsVrXa
		bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+name,url,32)
	return
def TW6Z0zqaDl(url):
	if 'mosalsalat' in url:
		url = JaQEtCzDXgos1cdZN + '/mosalsalat/v1/seriesLink/' + url.split('/')[-1]
		oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(r3rnfZ7cdxzNFebIRaLSG6B,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'PANET-PLAY-1st')
		Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
		items = dEyT9xhGjolYzLCH7460w3.findall('url":"(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		url = items[0]
		url = url.replace('\/','/')
	else:
		oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(r3rnfZ7cdxzNFebIRaLSG6B,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'PANET-PLAY-2nd')
		Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
		items = dEyT9xhGjolYzLCH7460w3.findall('contentURL" content="(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		url = items[0]
	PsD3IgluKFyvzMLoRT9j5hq2(url,sQU2GnRoMwLK8CBdfzmNr4jXyO,'video')
	return
def mUhJtHB9nw(search,zLEP9N4BOsVrXa=iiy37aKq0pCEIOwfcTh61xb4U):
	search,brFQp5vmgJWdZfEkCBOlu9c,showDialogs = XkYnev3ZCA6ahO94(search)
	if not search:
		search = TTBf6S08q1NKXd5v9wa()
		if not search: return
	VVOtdjT9AF4Wk3GECqHL = search.replace(iFBmE2MUIpSu34wsd7Rf6z,'%20')
	AKsQiuk1hJ = ['movies','series']
	if not zLEP9N4BOsVrXa: zLEP9N4BOsVrXa = '1'
	else: zLEP9N4BOsVrXa,type = zLEP9N4BOsVrXa.split('/')
	if showDialogs:
		R62ZFAHJCl0YeQWEvMhprDi7mPVg3 = [ 'بحث عن افلام' , 'بحث عن مسلسلات']
		mmfrx2S5XqknFTDeRhj49LuYv1wW0 = ccv1mVPUsnr('موقع بانيت - اختر البحث', R62ZFAHJCl0YeQWEvMhprDi7mPVg3)
		if mmfrx2S5XqknFTDeRhj49LuYv1wW0 == -1 : return
		type = AKsQiuk1hJ[mmfrx2S5XqknFTDeRhj49LuYv1wW0]
	else:
		if '_PANET-MOVIES_' in brFQp5vmgJWdZfEkCBOlu9c: type = 'movies'
		elif '_PANET-SERIES_' in brFQp5vmgJWdZfEkCBOlu9c: type = 'series'
		else: return
	headers['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8'
	data = {'query':VVOtdjT9AF4Wk3GECqHL , 'searchDomain':type}
	if zLEP9N4BOsVrXa!='1': data['from'] = zLEP9N4BOsVrXa
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'POST',JaQEtCzDXgos1cdZN+'/search',data,headers,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'PANET-SEARCH-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	items=dEyT9xhGjolYzLCH7460w3.findall('title":"(.*?)".*?link":"(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if items:
		for title,fCXyTlcmF4WuetVork in items:
			url = JaQEtCzDXgos1cdZN + fCXyTlcmF4WuetVork.replace('\/','/')
			if '/movies/' in url: bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'فيلم '+title,url,33)
			elif '/series/' in url:
				url = url.replace('/series/','/mosalsalat/')
				bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'مسلسل '+title,url+'/1',32)
	count=dEyT9xhGjolYzLCH7460w3.findall('"total":(.*?)}',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if count:
		JD0cNSKG5YLTEhzfls = int(  (int(count[0])+9)   /10 )+1
		for IIMp8kDh0zEeZJfyrtHBbRvjS in range(1,JD0cNSKG5YLTEhzfls):
			IIMp8kDh0zEeZJfyrtHBbRvjS = str(IIMp8kDh0zEeZJfyrtHBbRvjS)
			if IIMp8kDh0zEeZJfyrtHBbRvjS!=zLEP9N4BOsVrXa:
				bP6z3OSLp7va('folder','صفحة '+IIMp8kDh0zEeZJfyrtHBbRvjS,iiy37aKq0pCEIOwfcTh61xb4U,39,iiy37aKq0pCEIOwfcTh61xb4U,IIMp8kDh0zEeZJfyrtHBbRvjS+'/'+type,search)
	return
def FaD6NxfSIbzZimr9d4wOjQMkYhn5():
	fCXyTlcmF4WuetVork = 'aHR0cDovL2dzdHJlYW00LnBhbmV0LmNvLmlsL2VkZ2VfYWJyL2hhbGFUVi9wbGF5bGlzdC5tM3U4'
	fCXyTlcmF4WuetVork = UodGe76Lu2IHTYPxBhjk1RpcaqrM.b64decode(fCXyTlcmF4WuetVork)
	fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork.decode(df6QpwGxuJVZr)
	PsD3IgluKFyvzMLoRT9j5hq2(fCXyTlcmF4WuetVork,sQU2GnRoMwLK8CBdfzmNr4jXyO,'live')
	return
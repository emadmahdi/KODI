# -*- coding: utf-8 -*-
from braVAkwfBN import *
sQU2GnRoMwLK8CBdfzmNr4jXyO = 'ARABSEED'
headers = {'User-Agent':FgJLkYac7lQxEbs()}
ooQEi5O6tYsGVF8LU0TC3hgMeflBwH = '_ARS_'
JaQEtCzDXgos1cdZN = gZ4LwbKaOm[sQU2GnRoMwLK8CBdfzmNr4jXyO][0]
a8GCLIuWNkS = ['الرئيسية','المضاف حديثاً','مصارعه','اعلن معنا – For ads','موبايلات','برامج كمبيوتر','العاب كمبيوتر','اسلاميات','اخرى','اقسام اخري','اشتراكات']
def sHVM8YchrDjZAJ7(mode,url,text):
	if   mode==250: EA7FzO1kMZGQXDd2giB0cwLom = jihuS9LVAvTrClPapMbUEwfn8XN()
	elif mode==251: EA7FzO1kMZGQXDd2giB0cwLom = AIQeNZP4FMDw9S(url,text)
	elif mode==252: EA7FzO1kMZGQXDd2giB0cwLom = TW6Z0zqaDl(url)
	elif mode==253: EA7FzO1kMZGQXDd2giB0cwLom = YNcMvoVF5swlDBJI7PL(url)
	elif mode==254: EA7FzO1kMZGQXDd2giB0cwLom = chQHNdWgTSDjti8R9pJUf(url,'CATEGORIES___'+text)
	elif mode==255: EA7FzO1kMZGQXDd2giB0cwLom = chQHNdWgTSDjti8R9pJUf(url,'FILTERS___'+text)
	elif mode==256: EA7FzO1kMZGQXDd2giB0cwLom = BaSyudevC40nsQHW5j7JX6RM9(url,text)
	elif mode==259: EA7FzO1kMZGQXDd2giB0cwLom = mUhJtHB9nw(text)
	else: EA7FzO1kMZGQXDd2giB0cwLom = False
	return EA7FzO1kMZGQXDd2giB0cwLom
def jihuS9LVAvTrClPapMbUEwfn8XN():
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(Dxc7GChQwZ4kOlKHSbL06agnB,'GET',JaQEtCzDXgos1cdZN+'/main',iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'ARABSEED-MENU-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'بحث في الموقع',iiy37aKq0pCEIOwfcTh61xb4U,259,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'_REMEMBERRESULTS_')
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'فلتر محدد',JaQEtCzDXgos1cdZN+'/category/اخرى',254)
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'فلتر كامل',JaQEtCzDXgos1cdZN+'/category/اخرى',255)
	bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'المميزة',JaQEtCzDXgos1cdZN+'/main',251,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'featured_main')
	bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'جديد الأفلام',JaQEtCzDXgos1cdZN+'/main',251,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'new_movies')
	bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'جديد الحلقات',JaQEtCzDXgos1cdZN+'/main',251,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'new_episodes')
	bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'المضاف حديثاً',JaQEtCzDXgos1cdZN+'/latest',251,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'lastest')
	bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	eTov6CfDcRZVJEAq5BH = dEyT9xhGjolYzLCH7460w3.findall('class="MenuHeader"(.*?)</div>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	U462wftipjCPA1hLuGsKr8koxnd = eTov6CfDcRZVJEAq5BH[0]
	lFmsiNI2UDoJBdVCQtqx4WPXb7 = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?>(.*?)<',U462wftipjCPA1hLuGsKr8koxnd,dEyT9xhGjolYzLCH7460w3.DOTALL)
	for fCXyTlcmF4WuetVork,title in lFmsiNI2UDoJBdVCQtqx4WPXb7:
		title = JIY6A30UOsQboNVqCn(title)
		if title not in a8GCLIuWNkS and title!=iiy37aKq0pCEIOwfcTh61xb4U:
			if 'http' not in fCXyTlcmF4WuetVork: fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN+fCXyTlcmF4WuetVork
			bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,256)
	return Vxz6OndPIX4g2kaRp7
def BaSyudevC40nsQHW5j7JX6RM9(url,type):
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'ARABSEED-SUBMENU-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	if 'class="SliderInSection' in Vxz6OndPIX4g2kaRp7: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'الأكثر مشاهدة',url,251,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'most')
	if 'class="MainSlides' in Vxz6OndPIX4g2kaRp7: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'المميزة',url,251,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'featured')
	if 'class="LinksList' in Vxz6OndPIX4g2kaRp7:
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('class="LinksList(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if UUIohmv597bO83YCLgWS:
			PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
			if len(UUIohmv597bO83YCLgWS)>1 and type=='new_episodes': PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[1]
			items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)"(.*?)</a>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
			for fCXyTlcmF4WuetVork,title in items:
				Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb = dEyT9xhGjolYzLCH7460w3.findall('</i>(.*?)<span>(.*?)<',title,dEyT9xhGjolYzLCH7460w3.DOTALL)
				try: QhNGvIF4YS2a5gxLAcy1k6VW3w = Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb[0][0].replace(OTlVEGYPSxsNaBdXUucqA3,iiy37aKq0pCEIOwfcTh61xb4U).strip(iFBmE2MUIpSu34wsd7Rf6z)
				except: QhNGvIF4YS2a5gxLAcy1k6VW3w = iiy37aKq0pCEIOwfcTh61xb4U
				try: ETsFOuqxalPA8WbRILYmrdt2UVZ5Gp = Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb[0][1].replace(OTlVEGYPSxsNaBdXUucqA3,iiy37aKq0pCEIOwfcTh61xb4U).strip(iFBmE2MUIpSu34wsd7Rf6z)
				except: ETsFOuqxalPA8WbRILYmrdt2UVZ5Gp = iiy37aKq0pCEIOwfcTh61xb4U
				Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb = QhNGvIF4YS2a5gxLAcy1k6VW3w+iFBmE2MUIpSu34wsd7Rf6z+ETsFOuqxalPA8WbRILYmrdt2UVZ5Gp
				if '<strong>' in title:
					NTd3kFotfKclXPC8 = dEyT9xhGjolYzLCH7460w3.findall('</i>(.*?)<',title,dEyT9xhGjolYzLCH7460w3.DOTALL)
					if NTd3kFotfKclXPC8: Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb = NTd3kFotfKclXPC8[0]
				if not Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb:
					NTd3kFotfKclXPC8 = dEyT9xhGjolYzLCH7460w3.findall('alt="(.*?)"',title,dEyT9xhGjolYzLCH7460w3.DOTALL)
					if NTd3kFotfKclXPC8: Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb = NTd3kFotfKclXPC8[0]
				if Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb:
					if 'key=' in fCXyTlcmF4WuetVork: type = fCXyTlcmF4WuetVork.split('key=')[1]
					else: type = 'newest'
					Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb = Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb.strip(iFBmE2MUIpSu34wsd7Rf6z)
					bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb,fCXyTlcmF4WuetVork,251,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,type)
	return
def AIQeNZP4FMDw9S(url,type):
	xR0giHpZE1TcFjb4GS2d3aOwULzMk,data,items = 'GET',iiy37aKq0pCEIOwfcTh61xb4U,[]
	if type=='filters':
		if '?' in url:
			tBmM8w7Lqsg9QRVUcOoxbFA1,EwsmJ67cCYDIlg = 'POST',{}
			eCGwzSrqBmIv,V4p9OiNGeDSfyx = url.split('?')
			Wbe8jlJaNdroOHgpm = V4p9OiNGeDSfyx.split('&')
			for FHgYoph3Crdti1vBMqTJ82WO in Wbe8jlJaNdroOHgpm:
				key,aasX2cby4Vo5rTgB = FHgYoph3Crdti1vBMqTJ82WO.split('=')
				EwsmJ67cCYDIlg[key] = aasX2cby4Vo5rTgB
			if Wbe8jlJaNdroOHgpm: xR0giHpZE1TcFjb4GS2d3aOwULzMk,url,data = tBmM8w7Lqsg9QRVUcOoxbFA1,eCGwzSrqBmIv,EwsmJ67cCYDIlg
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,xR0giHpZE1TcFjb4GS2d3aOwULzMk,url,data,headers,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'ARABSEED-TITLES-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	if type=='filters': UUIohmv597bO83YCLgWS = [Vxz6OndPIX4g2kaRp7]
	elif 'featured' in type: UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('class="MainSlides(.*?)class="LinksList',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	elif type=='new_movies': UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('جديد الافلام.*?class="SliderInSection"(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	elif type=='new_episodes': UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('جديد الحلقات.*?class="SliderInSection"(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	elif type=='most': UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('class="SliderInSection(.*?)class="LinksList',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	else: UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('class="Blocks-UL"(.*?)class="AboElSeed"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if 'featured' in type:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		CuMtvmpi3YGXVnq1 = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)" title="(.*?)".*?data-lazy.*? (src|data-image)="(.*?)"',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if CuMtvmpi3YGXVnq1:
			duef0gb3Mi1AV5WpN8,A7Ap2wdlxM,hl2Fx9TbJqdD3zr,Xhv6TR9tW3M5wOnide0LEq1fF = zip(*CuMtvmpi3YGXVnq1)
			items = zip(duef0gb3Mi1AV5WpN8,Xhv6TR9tW3M5wOnide0LEq1fF,A7Ap2wdlxM)
	else:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('LoadingArea.*? href="(.*?)".*? data-\w{3,5}="(.*?)".*? alt="(.*?)"',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	u3Rztpl4VHO9GZ7jCBM65kvS = []
	for fCXyTlcmF4WuetVork,C0dvhEbPWYlUtimM3x,title in items:
		if 'WWE' in title: continue
		title = JIY6A30UOsQboNVqCn(title)
		if 'الحلقة' in title:
			zN7sZyFnw5JTE8 = dEyT9xhGjolYzLCH7460w3.findall('(.*?) الحلقة \d+',title,dEyT9xhGjolYzLCH7460w3.DOTALL)
			if zN7sZyFnw5JTE8:
				title = '_MOD_' + zN7sZyFnw5JTE8[0]
				if title not in u3Rztpl4VHO9GZ7jCBM65kvS:
					u3Rztpl4VHO9GZ7jCBM65kvS.append(title)
					bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,253,C0dvhEbPWYlUtimM3x)
			else: bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,252,C0dvhEbPWYlUtimM3x)
		elif '/selary/' in fCXyTlcmF4WuetVork or 'مسلسل' in title:
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,253,C0dvhEbPWYlUtimM3x)
		else:
			bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,252,C0dvhEbPWYlUtimM3x)
	if type in ['newest','best','most']:
		items = dEyT9xhGjolYzLCH7460w3.findall('page-numbers" href="(.*?)">(.*?)<',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title in items:
			fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN+fCXyTlcmF4WuetVork
			fCXyTlcmF4WuetVork = JIY6A30UOsQboNVqCn(fCXyTlcmF4WuetVork)
			title = JIY6A30UOsQboNVqCn(title)
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'صفحة '+title,fCXyTlcmF4WuetVork,251,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,type)
	return
def YNcMvoVF5swlDBJI7PL(url):
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'ARABSEED-EPISODES-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	Vxz6OndPIX4g2kaRp7 = Vxz6OndPIX4g2kaRp7[10000:]
	items = dEyT9xhGjolYzLCH7460w3.findall('data-src="(.*?)".*?alt="(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if not items: return
	C0dvhEbPWYlUtimM3x,name = items[0]
	if 'الحلقة' in name: name = name.split('الحلقة')[0].strip(iFBmE2MUIpSu34wsd7Rf6z)
	elif 'حلقة' in name: name = name.split('حلقة')[0].strip(iFBmE2MUIpSu34wsd7Rf6z)
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('class="ContainerEpisodesList"(.*?)</div>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?<em>(.*?)</em>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,zN7sZyFnw5JTE8 in items:
			title = name+' - الحلقة رقم '+zN7sZyFnw5JTE8
			bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,252,C0dvhEbPWYlUtimM3x)
	else: bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'ملف التشغيل',url,252,C0dvhEbPWYlUtimM3x)
	return
def PxL4pOdKhH9(title,fCXyTlcmF4WuetVork):
	Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb = dEyT9xhGjolYzLCH7460w3.findall('[a-zA-Z-]+',title,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb: title = Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb[0]
	else: title = title+iFBmE2MUIpSu34wsd7Rf6z+F82MvyX4ThI6sbnA3efDoVS(fCXyTlcmF4WuetVork,'name')
	title = title.replace('عرب سيد',iiy37aKq0pCEIOwfcTh61xb4U).replace('مباشر',iiy37aKq0pCEIOwfcTh61xb4U).replace('مشاهدة',iiy37aKq0pCEIOwfcTh61xb4U)
	title = title.replace('ٍ',iiy37aKq0pCEIOwfcTh61xb4U)
	title = title.replace(Wc5GekRC0HQLz7,iFBmE2MUIpSu34wsd7Rf6z).replace(Wc5GekRC0HQLz7,iFBmE2MUIpSu34wsd7Rf6z)
	return title
def TW6Z0zqaDl(url):
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(Dxc7GChQwZ4kOlKHSbL06agnB,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'ARABSEED-PLAY-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	eCGwzSrqBmIv = oCJ8TdG2LwSIVcbaUnhB.url
	Zw4M5DUStdE6xp7GI = F82MvyX4ThI6sbnA3efDoVS(eCGwzSrqBmIv,'url')
	headers['Referer'] = Zw4M5DUStdE6xp7GI+'/'
	F5HaRJTqK7Situg2jpkOc,mnRxoUeDcA6HVZKizvwBu3LO8FS9PN,duef0gb3Mi1AV5WpN8 = iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,[]
	WIACFRwtbaDMmos = dEyT9xhGjolYzLCH7460w3.findall('class="WatchButtons".*?href="(.*?)" class="(watch.*?)".*?href="(.*?)" class="(download.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if WIACFRwtbaDMmos: F5HaRJTqK7Situg2jpkOc,phDAJlISKQmV9dnB5tRsFTyecGwC3,mnRxoUeDcA6HVZKizvwBu3LO8FS9PN,uuX8TYmVoFRlvpQ7LZ = WIACFRwtbaDMmos[0]
	else:
		WIACFRwtbaDMmos = dEyT9xhGjolYzLCH7460w3.findall('class="WatchButtons".*?href="(.*?)" class="(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if WIACFRwtbaDMmos:
			fCXyTlcmF4WuetVork,phDAJlISKQmV9dnB5tRsFTyecGwC3 = WIACFRwtbaDMmos[0]
			if 'watch' in phDAJlISKQmV9dnB5tRsFTyecGwC3: F5HaRJTqK7Situg2jpkOc = fCXyTlcmF4WuetVork
			else: mnRxoUeDcA6HVZKizvwBu3LO8FS9PN = fCXyTlcmF4WuetVork
	if F5HaRJTqK7Situg2jpkOc:
		oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(Dxc7GChQwZ4kOlKHSbL06agnB,'GET',F5HaRJTqK7Situg2jpkOc,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'ARABSEED-PLAY-2nd')
		Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('class="WatcherArea(.*?</ul>)',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if UUIohmv597bO83YCLgWS:
			I9AEfHClMt48yWB2U5vDNoa0 = UUIohmv597bO83YCLgWS[0]
			I9AEfHClMt48yWB2U5vDNoa0 = I9AEfHClMt48yWB2U5vDNoa0.replace('</ul>','<h3>')
			I9AEfHClMt48yWB2U5vDNoa0 = I9AEfHClMt48yWB2U5vDNoa0.replace('<h3>','<h3><h3>')
			ddfSDGyqEc = dEyT9xhGjolYzLCH7460w3.findall('<h3>.*?(\d+)(.*?)<h3>',I9AEfHClMt48yWB2U5vDNoa0,dEyT9xhGjolYzLCH7460w3.DOTALL)
			if not ddfSDGyqEc: ddfSDGyqEc = [(iiy37aKq0pCEIOwfcTh61xb4U,I9AEfHClMt48yWB2U5vDNoa0)]
			for pMAWqrwP80lR,PPH1sQtTkDBbnlYpZfo5 in ddfSDGyqEc:
				if pMAWqrwP80lR: pMAWqrwP80lR = '____'+pMAWqrwP80lR
				items = dEyT9xhGjolYzLCH7460w3.findall('data-link="(.*?)".*?<span>(.*?)</span>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
				for fCXyTlcmF4WuetVork,name in items:
					if 'http' not in fCXyTlcmF4WuetVork: fCXyTlcmF4WuetVork = 'http:'+fCXyTlcmF4WuetVork
					fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork+'?named='+name+'__watch'+pMAWqrwP80lR
					duef0gb3Mi1AV5WpN8.append(fCXyTlcmF4WuetVork)
		P3tys0cXWbiIUKk7HQ6n89V = dEyT9xhGjolYzLCH7460w3.findall('class="containerIframe".*? src="(.*?)".*? height="(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if not P3tys0cXWbiIUKk7HQ6n89V: P3tys0cXWbiIUKk7HQ6n89V = dEyT9xhGjolYzLCH7460w3.findall('class="containerIframe".*? SRC="(.*?)".*? HEIGHT="(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if P3tys0cXWbiIUKk7HQ6n89V:
			fCXyTlcmF4WuetVork,pMAWqrwP80lR = P3tys0cXWbiIUKk7HQ6n89V[0]
			name = F82MvyX4ThI6sbnA3efDoVS(fCXyTlcmF4WuetVork,'name')
			if '%' in pMAWqrwP80lR: fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork+'?named='+name+'__embed__'
			else: fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork+'?named='+name+'__embed____'+pMAWqrwP80lR
			duef0gb3Mi1AV5WpN8.append(fCXyTlcmF4WuetVork)
	if mnRxoUeDcA6HVZKizvwBu3LO8FS9PN:
		oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(Dxc7GChQwZ4kOlKHSbL06agnB,'GET',mnRxoUeDcA6HVZKizvwBu3LO8FS9PN,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'ARABSEED-PLAY-3rd')
		Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('class="DownloadArea(.*?)<script src=',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if UUIohmv597bO83YCLgWS:
			I9AEfHClMt48yWB2U5vDNoa0 = UUIohmv597bO83YCLgWS[0]
			ddfSDGyqEc = dEyT9xhGjolYzLCH7460w3.findall('class="DownloadServers(.*?)</ul>',I9AEfHClMt48yWB2U5vDNoa0,dEyT9xhGjolYzLCH7460w3.DOTALL)
			for PPH1sQtTkDBbnlYpZfo5 in ddfSDGyqEc:
				items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?<span>(.*?)</span>.*?<p>(.*?)</p>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
				for fCXyTlcmF4WuetVork,title,pMAWqrwP80lR in items:
					if not fCXyTlcmF4WuetVork: continue
					if 'reviewstation' in fCXyTlcmF4WuetVork: continue
					fCXyTlcmF4WuetVork = a9I3YZjc6ySDPE4Kp(fCXyTlcmF4WuetVork)
					fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork+'?named='+title+'__download____'+pMAWqrwP80lR
					duef0gb3Mi1AV5WpN8.append(fCXyTlcmF4WuetVork)
	I9IY1NFVZzDGf = str(duef0gb3Mi1AV5WpN8)
	SQBWX4lui2Uf7 = ['.zip?','.rar?','.txt?','.pdf?','.tar?','.iso?','.zip.','.rar.','.txt.','.pdf.','.tar.','.iso.']
	if any(aasX2cby4Vo5rTgB in I9IY1NFVZzDGf for aasX2cby4Vo5rTgB in SQBWX4lui2Uf7):
		bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'رسالة من المبرمج','جرب رابط مختلف لأن هذا الرابط ليس من نوع الروابط التي فيها ملفات فيديو .. لأن هذا الموقع فيه خدمات أخرى غير ملفات الفيديو')
		return
	import lqBJGK8hXO
	lqBJGK8hXO.ZDg1HavwueT85mcAOorC4hnS(duef0gb3Mi1AV5WpN8,sQU2GnRoMwLK8CBdfzmNr4jXyO,'video',url)
	return
def mUhJtHB9nw(search):
	search,brFQp5vmgJWdZfEkCBOlu9c,showDialogs = XkYnev3ZCA6ahO94(search)
	if not search: search = TTBf6S08q1NKXd5v9wa()
	if not search: return
	search = search.replace(iFBmE2MUIpSu34wsd7Rf6z,'+')
	url = JaQEtCzDXgos1cdZN+'/find/?find='+search
	AIQeNZP4FMDw9S(url,'search')
	return
def chQHNdWgTSDjti8R9pJUf(url,filter):
	if '??' in url: url = url.split('//getposts??')[0]
	type,filter = filter.split('___',1)
	if filter==iiy37aKq0pCEIOwfcTh61xb4U: Mhd9LWrfiF1EsASl6eP34uTp0qNGom,ovh6cXGg1qd85fn3CSJEisTlI7Yz = iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U
	else: Mhd9LWrfiF1EsASl6eP34uTp0qNGom,ovh6cXGg1qd85fn3CSJEisTlI7Yz = filter.split('___')
	if type=='CATEGORIES':
		if cgosvVF9rpwY[0]+'==' not in Mhd9LWrfiF1EsASl6eP34uTp0qNGom: RRIscyLmNH9dq2Dio3TSr = cgosvVF9rpwY[0]
		for iEfNKT3velFyGth80SA4pxbCRrVD in range(len(cgosvVF9rpwY[0:-1])):
			if cgosvVF9rpwY[iEfNKT3velFyGth80SA4pxbCRrVD]+'==' in Mhd9LWrfiF1EsASl6eP34uTp0qNGom: RRIscyLmNH9dq2Dio3TSr = cgosvVF9rpwY[iEfNKT3velFyGth80SA4pxbCRrVD+1]
		HdFJThcNtWe3lb8n4OmaSwQ = Mhd9LWrfiF1EsASl6eP34uTp0qNGom+'&&'+RRIscyLmNH9dq2Dio3TSr+'==0'
		vvlVH6JT9YDNPeSaRUkKCAwpr5uq = ovh6cXGg1qd85fn3CSJEisTlI7Yz+'&&'+RRIscyLmNH9dq2Dio3TSr+'==0'
		cCZR4YdwUepABD9mQsubT8FgN = HdFJThcNtWe3lb8n4OmaSwQ.strip('&&')+'___'+vvlVH6JT9YDNPeSaRUkKCAwpr5uq.strip('&&')
		bPXk8KHyCUrifag = qJ8NQtuWARGjoZd9swfbH(ovh6cXGg1qd85fn3CSJEisTlI7Yz,'modified_filters')
		eCGwzSrqBmIv = url+'//getposts??'+bPXk8KHyCUrifag
	elif type=='FILTERS':
		GMQ6AxE012X9 = qJ8NQtuWARGjoZd9swfbH(Mhd9LWrfiF1EsASl6eP34uTp0qNGom,'modified_values')
		GMQ6AxE012X9 = a9I3YZjc6ySDPE4Kp(GMQ6AxE012X9)
		if ovh6cXGg1qd85fn3CSJEisTlI7Yz!=iiy37aKq0pCEIOwfcTh61xb4U: ovh6cXGg1qd85fn3CSJEisTlI7Yz = qJ8NQtuWARGjoZd9swfbH(ovh6cXGg1qd85fn3CSJEisTlI7Yz,'modified_filters')
		if ovh6cXGg1qd85fn3CSJEisTlI7Yz==iiy37aKq0pCEIOwfcTh61xb4U: eCGwzSrqBmIv = url
		else: eCGwzSrqBmIv = url+'//getposts??'+ovh6cXGg1qd85fn3CSJEisTlI7Yz
		x93j25L6Agtsyfkh7 = IGDmVpkxJgPd3K2FjvByWu(eCGwzSrqBmIv)
		bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'أظهار قائمة الفيديو التي تم اختيارها ',x93j25L6Agtsyfkh7,251,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'filters')
		bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+' [[   '+GMQ6AxE012X9+'   ]]',x93j25L6Agtsyfkh7,251,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'filters')
		bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(Dxc7GChQwZ4kOlKHSbL06agnB,'POST',url,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'ARABSEED-FILTERS_MENU-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('class="TaxPageFilter"(.*?)class="TermBTNs"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
	bj9hXFE6muIgwvnAzUKrPH = dEyT9xhGjolYzLCH7460w3.findall('class="TaxPageFilterItem".*?<em>(.*?)</em>.*?data-tax="(.*?)"(.*?)</ul>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	s4DoRpUXAkSfaQcI = dEyT9xhGjolYzLCH7460w3.findall('class="RatingFilter".*?<h4>(.*?)</h4>.*?(<ul>)(.*?)</ul>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	n8nFIQBNaXD = bj9hXFE6muIgwvnAzUKrPH+s4DoRpUXAkSfaQcI
	dict = {}
	for name,cWhMpFIbQU4D1Bi,PPH1sQtTkDBbnlYpZfo5 in n8nFIQBNaXD:
		items = dEyT9xhGjolYzLCH7460w3.findall('data-name="(.*?)".*?data-tax="(.*?)".*?data-term="(.*?)"',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if name=='اخرى': name = 'الاقسام'
		if not items:
			lFmsiNI2UDoJBdVCQtqx4WPXb7 = dEyT9xhGjolYzLCH7460w3.findall('data-rate="(.*?)".*?<em>(.*?)</em>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
			items = []
			for KjsA38t0DCSmuLcaE,aasX2cby4Vo5rTgB in lFmsiNI2UDoJBdVCQtqx4WPXb7: items.append([KjsA38t0DCSmuLcaE,iiy37aKq0pCEIOwfcTh61xb4U,aasX2cby4Vo5rTgB])
			cWhMpFIbQU4D1Bi = 'rate'
			name = 'التقييم'
		else: cWhMpFIbQU4D1Bi = items[0][1]
		if '==' not in eCGwzSrqBmIv: eCGwzSrqBmIv = url
		if type=='CATEGORIES':
			if RRIscyLmNH9dq2Dio3TSr!=cWhMpFIbQU4D1Bi: continue
			elif len(items)<=1:
				if cWhMpFIbQU4D1Bi==cgosvVF9rpwY[-1]: AIQeNZP4FMDw9S(eCGwzSrqBmIv)
				else: chQHNdWgTSDjti8R9pJUf(eCGwzSrqBmIv,'CATEGORIES___'+cCZR4YdwUepABD9mQsubT8FgN)
				return
			else:
				x93j25L6Agtsyfkh7 = IGDmVpkxJgPd3K2FjvByWu(eCGwzSrqBmIv)
				if cWhMpFIbQU4D1Bi==cgosvVF9rpwY[-1]: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'الجميع ',x93j25L6Agtsyfkh7,251,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'filters')
				else: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'الجميع ',eCGwzSrqBmIv,254,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,cCZR4YdwUepABD9mQsubT8FgN)
		elif type=='FILTERS':
			HdFJThcNtWe3lb8n4OmaSwQ = Mhd9LWrfiF1EsASl6eP34uTp0qNGom+'&&'+cWhMpFIbQU4D1Bi+'==0'
			vvlVH6JT9YDNPeSaRUkKCAwpr5uq = ovh6cXGg1qd85fn3CSJEisTlI7Yz+'&&'+cWhMpFIbQU4D1Bi+'==0'
			cCZR4YdwUepABD9mQsubT8FgN = HdFJThcNtWe3lb8n4OmaSwQ+'___'+vvlVH6JT9YDNPeSaRUkKCAwpr5uq
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'الجميع :'+name,eCGwzSrqBmIv,255,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,cCZR4YdwUepABD9mQsubT8FgN)
		dict[cWhMpFIbQU4D1Bi] = {}
		for KjsA38t0DCSmuLcaE,qBIUYtOjTAx0,aasX2cby4Vo5rTgB in items:
			if KjsA38t0DCSmuLcaE in a8GCLIuWNkS: continue
			if 'الكل' in KjsA38t0DCSmuLcaE: continue
			KjsA38t0DCSmuLcaE = JIY6A30UOsQboNVqCn(KjsA38t0DCSmuLcaE)
			YhB0TkycFJxX2V3PDHW6NiA,Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb = KjsA38t0DCSmuLcaE,KjsA38t0DCSmuLcaE
			Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb = name+': '+YhB0TkycFJxX2V3PDHW6NiA
			dict[cWhMpFIbQU4D1Bi][aasX2cby4Vo5rTgB] = Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb
			HdFJThcNtWe3lb8n4OmaSwQ = Mhd9LWrfiF1EsASl6eP34uTp0qNGom+'&&'+cWhMpFIbQU4D1Bi+'=='+YhB0TkycFJxX2V3PDHW6NiA
			vvlVH6JT9YDNPeSaRUkKCAwpr5uq = ovh6cXGg1qd85fn3CSJEisTlI7Yz+'&&'+cWhMpFIbQU4D1Bi+'=='+aasX2cby4Vo5rTgB
			kuyfTIwjRrhXUo = HdFJThcNtWe3lb8n4OmaSwQ+'___'+vvlVH6JT9YDNPeSaRUkKCAwpr5uq
			if type=='FILTERS':
				bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb,url,255,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,kuyfTIwjRrhXUo)
			elif type=='CATEGORIES' and cgosvVF9rpwY[-2]+'==' in Mhd9LWrfiF1EsASl6eP34uTp0qNGom:
				bPXk8KHyCUrifag = qJ8NQtuWARGjoZd9swfbH(vvlVH6JT9YDNPeSaRUkKCAwpr5uq,'modified_filters')
				O5Pwg3UFyX0k9E = url+'//getposts??'+bPXk8KHyCUrifag
				x93j25L6Agtsyfkh7 = IGDmVpkxJgPd3K2FjvByWu(O5Pwg3UFyX0k9E)
				bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb,x93j25L6Agtsyfkh7,251,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'filters')
			else: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb,url,254,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,kuyfTIwjRrhXUo)
	return
cgosvVF9rpwY = ['category','country','release-year']
jwXQrSu2KecIVTn05 = ['category','country','genre','release-year','language','quality','rate']
def IGDmVpkxJgPd3K2FjvByWu(url):
	Fak1bN2PUK0fWJRnL3D6zESmy = '/wp-content/themes/Elshaikh2021/Ajaxat/Home/FilteringHome.php'
	url = url.replace('//getposts',Fak1bN2PUK0fWJRnL3D6zESmy)
	url = url.replace('/category/اخرى',iiy37aKq0pCEIOwfcTh61xb4U)
	if Fak1bN2PUK0fWJRnL3D6zESmy not in url: url = url+Fak1bN2PUK0fWJRnL3D6zESmy
	url = url.replace('release-year','year')
	url = url.replace('??','?')
	url = url.replace('&&','&')
	url = url.replace('==','=')
	return url
def qJ8NQtuWARGjoZd9swfbH(HSAqBpsb2jRLvk9lx147rzY,mode):
	HSAqBpsb2jRLvk9lx147rzY = HSAqBpsb2jRLvk9lx147rzY.strip('&&')
	x8UiIH3WCTEpe,QAvGYocVXgzh9 = {},iiy37aKq0pCEIOwfcTh61xb4U
	if '==' in HSAqBpsb2jRLvk9lx147rzY:
		items = HSAqBpsb2jRLvk9lx147rzY.split('&&')
		for YXD9KNfjCaLwkcrvJxldn7I in items:
			xYkDXe5UjvETygJNLrRQ96mtp8BKGW,aasX2cby4Vo5rTgB = YXD9KNfjCaLwkcrvJxldn7I.split('==')
			x8UiIH3WCTEpe[xYkDXe5UjvETygJNLrRQ96mtp8BKGW] = aasX2cby4Vo5rTgB
	for key in jwXQrSu2KecIVTn05:
		if key in list(x8UiIH3WCTEpe.keys()): aasX2cby4Vo5rTgB = x8UiIH3WCTEpe[key]
		else: aasX2cby4Vo5rTgB = '0'
		if '%' not in aasX2cby4Vo5rTgB: aasX2cby4Vo5rTgB = YqdaDIig21wBTWJeUHbc(aasX2cby4Vo5rTgB)
		if mode=='modified_values' and aasX2cby4Vo5rTgB!='0': QAvGYocVXgzh9 = QAvGYocVXgzh9+' + '+aasX2cby4Vo5rTgB
		elif mode=='modified_filters' and aasX2cby4Vo5rTgB!='0': QAvGYocVXgzh9 = QAvGYocVXgzh9+'&&'+key+'=='+aasX2cby4Vo5rTgB
		elif mode=='all': QAvGYocVXgzh9 = QAvGYocVXgzh9+'&&'+key+'=='+aasX2cby4Vo5rTgB
	QAvGYocVXgzh9 = QAvGYocVXgzh9.strip(' + ')
	QAvGYocVXgzh9 = QAvGYocVXgzh9.strip('&&')
	return QAvGYocVXgzh9
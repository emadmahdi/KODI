# -*- coding: utf-8 -*-
from braVAkwfBN import *
sQU2GnRoMwLK8CBdfzmNr4jXyO = 'EGYDEAD'
ooQEi5O6tYsGVF8LU0TC3hgMeflBwH = '_EGD_'
JaQEtCzDXgos1cdZN = gZ4LwbKaOm[sQU2GnRoMwLK8CBdfzmNr4jXyO][0]
a8GCLIuWNkS = ['مصارعة','احدث البرامج','احدث الالعاب','الرئيسية','احدث الاغانى']
def sHVM8YchrDjZAJ7(mode,url,text):
	if   mode==440: EA7FzO1kMZGQXDd2giB0cwLom = jihuS9LVAvTrClPapMbUEwfn8XN()
	elif mode==441: EA7FzO1kMZGQXDd2giB0cwLom = AIQeNZP4FMDw9S(url,text)
	elif mode==442: EA7FzO1kMZGQXDd2giB0cwLom = TW6Z0zqaDl(url)
	elif mode==443: EA7FzO1kMZGQXDd2giB0cwLom = YNcMvoVF5swlDBJI7PL(url)
	elif mode==449: EA7FzO1kMZGQXDd2giB0cwLom = mUhJtHB9nw(text)
	else: EA7FzO1kMZGQXDd2giB0cwLom = False
	return EA7FzO1kMZGQXDd2giB0cwLom
def jihuS9LVAvTrClPapMbUEwfn8XN():
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',JaQEtCzDXgos1cdZN,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'EGYDEAD-MENU-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	ffBG4TaQU8lVF26R = F82MvyX4ThI6sbnA3efDoVS(JaQEtCzDXgos1cdZN,'url')
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'بحث في الموقع',iiy37aKq0pCEIOwfcTh61xb4U,449,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'_REMEMBERRESULTS_')
	bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'الرئيسية',JaQEtCzDXgos1cdZN,441)
	bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('class="title_menu_right"(.*?)</div>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
	items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)">(.*?)</a>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	for fCXyTlcmF4WuetVork,title in items:
		if title in a8GCLIuWNkS: continue
		if fCXyTlcmF4WuetVork=='#': continue
		bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,441)
	return
def AIQeNZP4FMDw9S(url,MGUpOVcyHm3P9xC8ij76QlfY=iiy37aKq0pCEIOwfcTh61xb4U):
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'EGYDEAD-TITLES-2nd')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('class="list-related"(.*?)class="pagination"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
	items = dEyT9xhGjolYzLCH7460w3.findall('<li>.*?href="(.*?)".*?<h1>(.*?)</h1>.*?src="(.*?)"',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	for fCXyTlcmF4WuetVork,title,C0dvhEbPWYlUtimM3x in items:
		if '/url/' in fCXyTlcmF4WuetVork: continue
		elif '/season/' in fCXyTlcmF4WuetVork: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,443,C0dvhEbPWYlUtimM3x)
		elif '/episode/' in fCXyTlcmF4WuetVork: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,443,C0dvhEbPWYlUtimM3x)
		else: bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,442,C0dvhEbPWYlUtimM3x)
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('class="pagination"(.*?)</div>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)">(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title in items:
			title = JIY6A30UOsQboNVqCn(title)
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'صفحة '+title,fCXyTlcmF4WuetVork,441)
	return
def YNcMvoVF5swlDBJI7PL(url):
	data = {'View':1}
	headers = {'Content-Type':'application/x-www-form-urlencoded'}
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'POST',url,data,headers,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'EGYDEAD-EPISODES-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	HG5rE20ORdbqUKWewuZCJP4zoXF6g = dEyT9xhGjolYzLCH7460w3.findall('"seasons-list"(.*?)</div>.</div>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	eTov6CfDcRZVJEAq5BH = dEyT9xhGjolYzLCH7460w3.findall('"episodes-list"(.*?)</div>.</div>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if HG5rE20ORdbqUKWewuZCJP4zoXF6g:
		PPH1sQtTkDBbnlYpZfo5 = HG5rE20ORdbqUKWewuZCJP4zoXF6g[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title,C0dvhEbPWYlUtimM3x in items:
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,443,C0dvhEbPWYlUtimM3x)
	elif eTov6CfDcRZVJEAq5BH:
		C0dvhEbPWYlUtimM3x = dEyT9xhGjolYzLCH7460w3.findall('"og:image" content="(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		C0dvhEbPWYlUtimM3x = C0dvhEbPWYlUtimM3x[0]
		PPH1sQtTkDBbnlYpZfo5 = eTov6CfDcRZVJEAq5BH[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?>(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title in items:
			title = title.replace(OTlVEGYPSxsNaBdXUucqA3,iiy37aKq0pCEIOwfcTh61xb4U).strip(iFBmE2MUIpSu34wsd7Rf6z)
			bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,442,C0dvhEbPWYlUtimM3x)
	return
def TW6Z0zqaDl(url):
	data = {'View':1}
	headers = {'Content-Type':'application/x-www-form-urlencoded'}
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'POST',url,data,headers,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'EGYDEAD-PLAY-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	duef0gb3Mi1AV5WpN8 = []
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"watchAreaMaster"(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('data-link="(.*?)".*?<p>(.*?)</p>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title in items:
			title = title.replace(OTlVEGYPSxsNaBdXUucqA3,iiy37aKq0pCEIOwfcTh61xb4U).strip(iFBmE2MUIpSu34wsd7Rf6z)
			fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork+'?named='+title+'__watch'
			duef0gb3Mi1AV5WpN8.append(fCXyTlcmF4WuetVork)
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"donwload-servers-list"(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('"ser-name">(.*?)</span>.*?<em>(.*?)</em>.*?href="(.*?)"',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for title,pMAWqrwP80lR,fCXyTlcmF4WuetVork in items:
			fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork.replace(OTlVEGYPSxsNaBdXUucqA3,iiy37aKq0pCEIOwfcTh61xb4U)
			fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork+'?named='+title+'__download'+'____'+pMAWqrwP80lR
			duef0gb3Mi1AV5WpN8.append(fCXyTlcmF4WuetVork)
	import lqBJGK8hXO
	lqBJGK8hXO.ZDg1HavwueT85mcAOorC4hnS(duef0gb3Mi1AV5WpN8,sQU2GnRoMwLK8CBdfzmNr4jXyO,'video',url)
	return
def mUhJtHB9nw(search):
	search,brFQp5vmgJWdZfEkCBOlu9c,showDialogs = XkYnev3ZCA6ahO94(search)
	if search==iiy37aKq0pCEIOwfcTh61xb4U: search = TTBf6S08q1NKXd5v9wa()
	if search==iiy37aKq0pCEIOwfcTh61xb4U: return
	search = search.replace(iFBmE2MUIpSu34wsd7Rf6z,'+')
	url = JaQEtCzDXgos1cdZN+'/?s='+search
	AIQeNZP4FMDw9S(url)
	return
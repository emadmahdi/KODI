# -*- coding: utf-8 -*-
from braVAkwfBN import *
sQU2GnRoMwLK8CBdfzmNr4jXyO = 'ALARAB'
headers = {'User-Agent':iiy37aKq0pCEIOwfcTh61xb4U}
ooQEi5O6tYsGVF8LU0TC3hgMeflBwH = '_KLA_'
JaQEtCzDXgos1cdZN = gZ4LwbKaOm[sQU2GnRoMwLK8CBdfzmNr4jXyO][0]
def sHVM8YchrDjZAJ7(mode,url,text):
	if   mode==10: EA7FzO1kMZGQXDd2giB0cwLom = jihuS9LVAvTrClPapMbUEwfn8XN()
	elif mode==11: EA7FzO1kMZGQXDd2giB0cwLom = AIQeNZP4FMDw9S(url)
	elif mode==12: EA7FzO1kMZGQXDd2giB0cwLom = TW6Z0zqaDl(url)
	elif mode==13: EA7FzO1kMZGQXDd2giB0cwLom = YNcMvoVF5swlDBJI7PL(url)
	elif mode==14: EA7FzO1kMZGQXDd2giB0cwLom = GGbxVPw0MrO()
	elif mode==15: EA7FzO1kMZGQXDd2giB0cwLom = k1suLXGwhPzeUjmMnIgKRBflNp()
	elif mode==16: EA7FzO1kMZGQXDd2giB0cwLom = ruXSznHvJWKUF()
	elif mode==19: EA7FzO1kMZGQXDd2giB0cwLom = mUhJtHB9nw(text)
	else: EA7FzO1kMZGQXDd2giB0cwLom = False
	return EA7FzO1kMZGQXDd2giB0cwLom
def jihuS9LVAvTrClPapMbUEwfn8XN():
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'بحث في الموقع',iiy37aKq0pCEIOwfcTh61xb4U,19,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'_REMEMBERRESULTS_')
	bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'آخر الإضافات',iiy37aKq0pCEIOwfcTh61xb4U,14)
	bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'مسلسلات رمضان',iiy37aKq0pCEIOwfcTh61xb4U,15)
	Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(Dxc7GChQwZ4kOlKHSbL06agnB,JaQEtCzDXgos1cdZN,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,'ALARAB-MENU-1st')
	UUIohmv597bO83YCLgWS=dEyT9xhGjolYzLCH7460w3.findall('id="nav-slider"(.*?)</div>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	J0VcHi9vrsenoz7wKNFDG5Ej4 = UUIohmv597bO83YCLgWS[0]
	items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?>(.*?)<',J0VcHi9vrsenoz7wKNFDG5Ej4,dEyT9xhGjolYzLCH7460w3.DOTALL)
	for fCXyTlcmF4WuetVork,title in items:
		fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN+fCXyTlcmF4WuetVork
		title = title.strip(iFBmE2MUIpSu34wsd7Rf6z)
		bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,11)
	bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('id="navbar"(.*?)</div>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	U462wftipjCPA1hLuGsKr8koxnd = UUIohmv597bO83YCLgWS[0]
	items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?>(.*?)<',U462wftipjCPA1hLuGsKr8koxnd,dEyT9xhGjolYzLCH7460w3.DOTALL)
	for fCXyTlcmF4WuetVork,title in items:
		fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN+fCXyTlcmF4WuetVork
		bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,11)
	return Vxz6OndPIX4g2kaRp7
def k1suLXGwhPzeUjmMnIgKRBflNp():
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'جميع المسلسلات العربية',JaQEtCzDXgos1cdZN+'/view-8/مسلسلات-عربية',11)
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'مسلسلات السنة الأخيرة',iiy37aKq0pCEIOwfcTh61xb4U,16)
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'مسلسلات رمضان الأخيرة 1',JaQEtCzDXgos1cdZN+'/view-8/مسلسلات-رمضان-2022',11)
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'مسلسلات رمضان الأخيرة 2',JaQEtCzDXgos1cdZN+'/view-8/مسلسلات-رمضان-2023',11)
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'مسلسلات رمضان 2023',JaQEtCzDXgos1cdZN+'/ramadan2023/مصرية',11)
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'مسلسلات رمضان 2022',JaQEtCzDXgos1cdZN+'/ramadan2022/مصرية',11)
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'مسلسلات رمضان 2021',JaQEtCzDXgos1cdZN+'/ramadan2021/مصرية',11)
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'مسلسلات رمضان 2020',JaQEtCzDXgos1cdZN+'/ramadan2020/مصرية',11)
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'مسلسلات رمضان 2019',JaQEtCzDXgos1cdZN+'/ramadan2019/مصرية',11)
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'مسلسلات رمضان 2018',JaQEtCzDXgos1cdZN+'/ramadan2018/مصرية',11)
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'مسلسلات رمضان 2017',JaQEtCzDXgos1cdZN+'/ramadan2017/مصرية',11)
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'مسلسلات رمضان 2016',JaQEtCzDXgos1cdZN+'/ramadan2016/مصرية',11)
	return
def GGbxVPw0MrO():
	Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(PNjZMS7nxa9clHusz1,JaQEtCzDXgos1cdZN,iiy37aKq0pCEIOwfcTh61xb4U,headers,True,'ALARAB-LATEST-1st')
	UUIohmv597bO83YCLgWS=dEyT9xhGjolYzLCH7460w3.findall('heading-top(.*?)div class=',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]+UUIohmv597bO83YCLgWS[1]
	items=dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?data-src="(.*?)" alt="(.*?)"',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	for fCXyTlcmF4WuetVork,C0dvhEbPWYlUtimM3x,title in items:
		url = JaQEtCzDXgos1cdZN + fCXyTlcmF4WuetVork
		if 'series' in url: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,url,11,C0dvhEbPWYlUtimM3x)
		else: bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,url,12,C0dvhEbPWYlUtimM3x)
	return
def AIQeNZP4FMDw9S(url):
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,headers,True,True,'ALARAB-TITLES-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('video-category(.*?)right_content',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if not UUIohmv597bO83YCLgWS: return
	PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
	ODImXaV12yknNJH4fp7Y = False
	items = dEyT9xhGjolYzLCH7460w3.findall('video-box.*?href="(.*?)".*?src="(http.*?)" alt="(.*?)"',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	u3Rztpl4VHO9GZ7jCBM65kvS,v7CQL4K56PzGRO = [],[]
	for fCXyTlcmF4WuetVork,C0dvhEbPWYlUtimM3x,title in items:
		if title==iiy37aKq0pCEIOwfcTh61xb4U: title = fCXyTlcmF4WuetVork.split('/')[-1].replace('-',iFBmE2MUIpSu34wsd7Rf6z)
		MGUpOVcyHm3P9xC8ij76QlfY = dEyT9xhGjolYzLCH7460w3.findall('(\d+)',title,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if MGUpOVcyHm3P9xC8ij76QlfY: MGUpOVcyHm3P9xC8ij76QlfY = int(MGUpOVcyHm3P9xC8ij76QlfY[0])
		else: MGUpOVcyHm3P9xC8ij76QlfY = 0
		v7CQL4K56PzGRO.append([C0dvhEbPWYlUtimM3x,fCXyTlcmF4WuetVork,title,MGUpOVcyHm3P9xC8ij76QlfY])
	v7CQL4K56PzGRO = sorted(v7CQL4K56PzGRO, reverse=True, key=lambda key: key[3])
	for C0dvhEbPWYlUtimM3x,fCXyTlcmF4WuetVork,title,MGUpOVcyHm3P9xC8ij76QlfY in v7CQL4K56PzGRO:
		fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN + fCXyTlcmF4WuetVork
		title = title.replace('مشاهدة مسلسل','مسلسل')
		title = title.replace('مشاهدة المسلسل','المسلسل')
		title = title.replace('مشاهدة فيلم','فيلم')
		title = title.replace('مشاهدة الفيلم','الفيلم')
		title = title.replace('مباشرة كواليتي',iiy37aKq0pCEIOwfcTh61xb4U)
		title = title.replace('عالية على العرب',iiy37aKq0pCEIOwfcTh61xb4U)
		title = title.replace('مشاهدة مباشرة',iiy37aKq0pCEIOwfcTh61xb4U)
		title = title.replace('اون لاين',iiy37aKq0pCEIOwfcTh61xb4U)
		title = title.replace('اونلاين',iiy37aKq0pCEIOwfcTh61xb4U)
		title = title.replace('بجودة عالية',iiy37aKq0pCEIOwfcTh61xb4U)
		title = title.replace('جودة عالية',iiy37aKq0pCEIOwfcTh61xb4U)
		title = title.replace('بدون تحميل',iiy37aKq0pCEIOwfcTh61xb4U)
		title = title.replace('على العرب',iiy37aKq0pCEIOwfcTh61xb4U)
		title = title.replace('مباشرة',iiy37aKq0pCEIOwfcTh61xb4U)
		title = title.strip(iFBmE2MUIpSu34wsd7Rf6z).replace(Wc5GekRC0HQLz7,iFBmE2MUIpSu34wsd7Rf6z).replace(Wc5GekRC0HQLz7,iFBmE2MUIpSu34wsd7Rf6z)
		title = '_MOD_'+title
		Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb = title
		if '/q/' in url and ('الحلقة' in title or 'الحلقه' in title):
			zN7sZyFnw5JTE8 = dEyT9xhGjolYzLCH7460w3.findall('(.*?) الحلقة \d+',title,dEyT9xhGjolYzLCH7460w3.DOTALL)
			if zN7sZyFnw5JTE8: Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb = zN7sZyFnw5JTE8[0]
		if Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb not in u3Rztpl4VHO9GZ7jCBM65kvS:
			u3Rztpl4VHO9GZ7jCBM65kvS.append(Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb)
			if '/q/' in url and ('الحلقة' in title or 'الحلقه' in title):
				bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb,fCXyTlcmF4WuetVork,13,C0dvhEbPWYlUtimM3x)
				ODImXaV12yknNJH4fp7Y = True
			elif 'series' in fCXyTlcmF4WuetVork:
				bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,11,C0dvhEbPWYlUtimM3x)
				ODImXaV12yknNJH4fp7Y = True
			else:
				bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,12,C0dvhEbPWYlUtimM3x)
				ODImXaV12yknNJH4fp7Y = True
	if ODImXaV12yknNJH4fp7Y:
		items = dEyT9xhGjolYzLCH7460w3.findall('tsc_3d_button red.*?href="(.*?)" title="(.*?)"',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,zLEP9N4BOsVrXa in items:
			url = JaQEtCzDXgos1cdZN + fCXyTlcmF4WuetVork
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+zLEP9N4BOsVrXa,url,11)
	return
def YNcMvoVF5swlDBJI7PL(url):
	Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(PNjZMS7nxa9clHusz1,url,iiy37aKq0pCEIOwfcTh61xb4U,headers,True,'ALARAB-EPISODES-1st')
	vke8SjzmdDPgLcZ5hWrYtMHxqn = dEyT9xhGjolYzLCH7460w3.findall('href="(/series.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	eCGwzSrqBmIv = JaQEtCzDXgos1cdZN+vke8SjzmdDPgLcZ5hWrYtMHxqn[0]
	EA7FzO1kMZGQXDd2giB0cwLom = AIQeNZP4FMDw9S(eCGwzSrqBmIv)
	return
def TW6Z0zqaDl(url):
	duef0gb3Mi1AV5WpN8 = []
	Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(r3rnfZ7cdxzNFebIRaLSG6B,url,iiy37aKq0pCEIOwfcTh61xb4U,headers,True,'ALARAB-PLAY-1st')
	eCGwzSrqBmIv = dEyT9xhGjolYzLCH7460w3.findall('class="resp-iframe" src="(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if eCGwzSrqBmIv:
		eCGwzSrqBmIv = eCGwzSrqBmIv[0]
		P3tys0cXWbiIUKk7HQ6n89V = dEyT9xhGjolYzLCH7460w3.findall('^(http.*?)(http.*?)$',eCGwzSrqBmIv,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if P3tys0cXWbiIUKk7HQ6n89V:
			wijqr6NndVsJmg = P3tys0cXWbiIUKk7HQ6n89V[0][0]
			YYbrOepqn9G2,vvxLKEVDWg4Sy6B8wdlFr7i = P3tys0cXWbiIUKk7HQ6n89V[0][1].rsplit('/',1)
			O5Pwg3UFyX0k9E = YYbrOepqn9G2+'?named=__watch'
			duef0gb3Mi1AV5WpN8.append(O5Pwg3UFyX0k9E)
			x93j25L6Agtsyfkh7 = wijqr6NndVsJmg+vvxLKEVDWg4Sy6B8wdlFr7i
		else:
			z0spMAOfJElv6L1K9ae = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(Dxc7GChQwZ4kOlKHSbL06agnB,eCGwzSrqBmIv,iiy37aKq0pCEIOwfcTh61xb4U,headers,False,'ALARAB-PLAY-2nd')
			eCGwzSrqBmIv = dEyT9xhGjolYzLCH7460w3.findall('"src": "(.*?)"',z0spMAOfJElv6L1K9ae,dEyT9xhGjolYzLCH7460w3.DOTALL)
			if eCGwzSrqBmIv:
				eCGwzSrqBmIv = eCGwzSrqBmIv[0]+'?named=__watch__m3u8'
				duef0gb3Mi1AV5WpN8.append(eCGwzSrqBmIv)
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('searchBox(.*?)<style>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		eCGwzSrqBmIv = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)"',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if eCGwzSrqBmIv:
			eCGwzSrqBmIv = eCGwzSrqBmIv[0]+'?named=__watch'
			duef0gb3Mi1AV5WpN8.append(eCGwzSrqBmIv)
	import lqBJGK8hXO
	lqBJGK8hXO.ZDg1HavwueT85mcAOorC4hnS(duef0gb3Mi1AV5WpN8,sQU2GnRoMwLK8CBdfzmNr4jXyO,'video',url)
	return
def ruXSznHvJWKUF():
	Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(Dxc7GChQwZ4kOlKHSbL06agnB,JaQEtCzDXgos1cdZN,iiy37aKq0pCEIOwfcTh61xb4U,headers,True,'ALARAB-RAMADAN-1st')
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('id="content_sec"(.*?)id="left_content"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
	items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?>(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	CN7WFQsGAYJ0fcu5owRaI9mpxjXrhd = dEyT9xhGjolYzLCH7460w3.findall('/ramadan([0-9]+)/',str(items),dEyT9xhGjolYzLCH7460w3.DOTALL)
	CN7WFQsGAYJ0fcu5owRaI9mpxjXrhd = CN7WFQsGAYJ0fcu5owRaI9mpxjXrhd[0]
	for fCXyTlcmF4WuetVork,title in items:
		url = JaQEtCzDXgos1cdZN+fCXyTlcmF4WuetVork
		title = title.strip(iFBmE2MUIpSu34wsd7Rf6z)+iFBmE2MUIpSu34wsd7Rf6z+CN7WFQsGAYJ0fcu5owRaI9mpxjXrhd
		bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,url,11)
	return
def mUhJtHB9nw(search):
	search,brFQp5vmgJWdZfEkCBOlu9c,showDialogs = XkYnev3ZCA6ahO94(search)
	if search==iiy37aKq0pCEIOwfcTh61xb4U: search = TTBf6S08q1NKXd5v9wa()
	if search==iiy37aKq0pCEIOwfcTh61xb4U: return
	VVOtdjT9AF4Wk3GECqHL = search.replace(iFBmE2MUIpSu34wsd7Rf6z,'+')
	url = JaQEtCzDXgos1cdZN + "/q/" + VVOtdjT9AF4Wk3GECqHL
	EA7FzO1kMZGQXDd2giB0cwLom = AIQeNZP4FMDw9S(url)
	return
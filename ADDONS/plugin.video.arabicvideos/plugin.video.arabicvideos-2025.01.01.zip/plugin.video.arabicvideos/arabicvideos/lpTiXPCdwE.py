# -*- coding: utf-8 -*-
import sys as ytv0YaxDcRINurplWKg587Pwqz
LS5n9Ib81cvhApByQJa6GX4HTf = ytv0YaxDcRINurplWKg587Pwqz.version_info [0] == 2
FVDxSCW5MgK = 2048
o2SVZsYjxd4MPfLCRzv1Ime9XD6rhW = 7
def EnKbMAYoFJ (kc93hiPDm4MqAOaL):
	global BCEn6px5l4
	qR9DalTWtCBVeyYwiQg = ord (kc93hiPDm4MqAOaL [-1])
	SSe8FNopD7MI1EixsPTgl4v3YmfB6 = kc93hiPDm4MqAOaL [:-1]
	T2g7SpExkOcr8NUtfYyMB1d4usRw = qR9DalTWtCBVeyYwiQg % len (SSe8FNopD7MI1EixsPTgl4v3YmfB6)
	fxd3B46829KvYlTG17kUyLNJIbWDp0 = SSe8FNopD7MI1EixsPTgl4v3YmfB6 [:T2g7SpExkOcr8NUtfYyMB1d4usRw] + SSe8FNopD7MI1EixsPTgl4v3YmfB6 [T2g7SpExkOcr8NUtfYyMB1d4usRw:]
	if LS5n9Ib81cvhApByQJa6GX4HTf:
		nXV2GRHyP8dpugjML5sTE4OKN = unicode () .join ([unichr (ord (XXYULyZe1FgwdTVnSx2kHfDAsMClJ9) - FVDxSCW5MgK - (GPf6BlpctR + qR9DalTWtCBVeyYwiQg) % o2SVZsYjxd4MPfLCRzv1Ime9XD6rhW) for GPf6BlpctR, XXYULyZe1FgwdTVnSx2kHfDAsMClJ9 in enumerate (fxd3B46829KvYlTG17kUyLNJIbWDp0)])
	else:
		nXV2GRHyP8dpugjML5sTE4OKN = str () .join ([chr (ord (XXYULyZe1FgwdTVnSx2kHfDAsMClJ9) - FVDxSCW5MgK - (GPf6BlpctR + qR9DalTWtCBVeyYwiQg) % o2SVZsYjxd4MPfLCRzv1Ime9XD6rhW) for GPf6BlpctR, XXYULyZe1FgwdTVnSx2kHfDAsMClJ9 in enumerate (fxd3B46829KvYlTG17kUyLNJIbWDp0)])
	return eval (nXV2GRHyP8dpugjML5sTE4OKN)
hhqd6cnfNJiAaLKTPbst5RpMmZF2G,LyNiIHPOwD3hCUYEFM7,vODxLKW5Ql6r4Fbm8=EnKbMAYoFJ,EnKbMAYoFJ,EnKbMAYoFJ
xpT28sXu051,GGx4qyKP1vUtRghsE2WfaHLMXZ,PtkEvXAqif14G20QZsaSyT=vODxLKW5Ql6r4Fbm8,LyNiIHPOwD3hCUYEFM7,hhqd6cnfNJiAaLKTPbst5RpMmZF2G
SaB5hx3PZwXRLtKgrTfQvId,YzX407G1m8ER9OBpkeuqPIf6Ajrh5,EMO8gy4LrsNTh0knZwpSeU75APW=PtkEvXAqif14G20QZsaSyT,GGx4qyKP1vUtRghsE2WfaHLMXZ,xpT28sXu051
yJeq1BjfiO4NFuwIEzxVLK6b9s,ZchUJdM93pTA7zG5,CCUzMTgQjrHntoiGf16LXW5P8EdVu=EMO8gy4LrsNTh0knZwpSeU75APW,YzX407G1m8ER9OBpkeuqPIf6Ajrh5,SaB5hx3PZwXRLtKgrTfQvId
JZszNnIEMAx28Yao0yqhiXGKOPb,XrTw01KtLzbpoyMf,uuExaKGL7UONtevRd=CCUzMTgQjrHntoiGf16LXW5P8EdVu,ZchUJdM93pTA7zG5,yJeq1BjfiO4NFuwIEzxVLK6b9s
y6y5HtgXO4TkUbwVZ,sVzojQerUqX,tKNPiXfQ7HoAqndw3z9IL4E6VrGv1=uuExaKGL7UONtevRd,XrTw01KtLzbpoyMf,JZszNnIEMAx28Yao0yqhiXGKOPb
AbqCJZdWQP9j,Y41NvKfOroMzGB8sEHy7wbXlc5,hhQwbeiNLoqFjX90fB7aG8VAs=tKNPiXfQ7HoAqndw3z9IL4E6VrGv1,sVzojQerUqX,y6y5HtgXO4TkUbwVZ
IpC4qHXRuyNFjzWv,ppxP0Cg6N3JVELzjGKmkZ2qIlu,L90uqo28xEKSFUwYTcm51yRWZIkft=hhQwbeiNLoqFjX90fB7aG8VAs,Y41NvKfOroMzGB8sEHy7wbXlc5,AbqCJZdWQP9j
FRYcH4KL7e9gv5pEB,tELM0b9FzxuRI4J1CYcie7ZXsHBar,TlGXWLYsV1z=L90uqo28xEKSFUwYTcm51yRWZIkft,ppxP0Cg6N3JVELzjGKmkZ2qIlu,IpC4qHXRuyNFjzWv
ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n,HtK4o2sTPgA78U,zmcGfOdvAjsELeJlP=TlGXWLYsV1z,tELM0b9FzxuRI4J1CYcie7ZXsHBar,FRYcH4KL7e9gv5pEB
UO04GcM7oFd3kJbtKQZHRgI2jeyzCh,MgP8OjoaiWQEVG59,jXE2YHkswT8y=zmcGfOdvAjsELeJlP,HtK4o2sTPgA78U,ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n
from braVAkwfBN import *
sQU2GnRoMwLK8CBdfzmNr4jXyO = L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠩࡖࡉࡗ࡜ࡉࡄࡇࡖࠫຣ")
def sHVM8YchrDjZAJ7(Cpf9s3c0Zngj7XE,U94JwhRgpXCOe5=iiy37aKq0pCEIOwfcTh61xb4U):
	if   Cpf9s3c0Zngj7XE==UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"࠴ᇟ"): VAIDB3hNwiYHW(U94JwhRgpXCOe5)
	elif Cpf9s3c0Zngj7XE==EMO8gy4LrsNTh0knZwpSeU75APW(u"࠶ᇠ"): pass
	elif Cpf9s3c0Zngj7XE==IpC4qHXRuyNFjzWv(u"࠸ᇡ"): fmS1GJHNpqKyxE7u5bA(U94JwhRgpXCOe5)
	elif Cpf9s3c0Zngj7XE==FRYcH4KL7e9gv5pEB(u"࠳ᇢ"): ox0nXeNGCZcHL6BROUmfaJkqItErF()
	elif Cpf9s3c0Zngj7XE==zmcGfOdvAjsELeJlP(u"࠵ᇣ"): EEVYtKCnIFLef8(U94JwhRgpXCOe5)
	elif Cpf9s3c0Zngj7XE==L90uqo28xEKSFUwYTcm51yRWZIkft(u"࠷ᇤ"): orPqw1N4BxKDCSa7FXIgiW3s2l()
	elif Cpf9s3c0Zngj7XE==tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"࠹ᇥ"): inc0qJAsOf8dQCHgUG()
	elif Cpf9s3c0Zngj7XE==TlGXWLYsV1z(u"࠻ᇦ"): XyGJzjM74bEVSxHv()
	elif Cpf9s3c0Zngj7XE==SaB5hx3PZwXRLtKgrTfQvId(u"࠽ᇧ"): JJsf7Pon8TeLSV3MyuRpA21()
	elif Cpf9s3c0Zngj7XE==IpC4qHXRuyNFjzWv(u"࠿ᇨ"): qbEWmInyuwF98xPGBOVgvipohZ()
	elif Cpf9s3c0Zngj7XE==uuExaKGL7UONtevRd(u"࠱࠶࠲ᇩ"): xxvHEQlGXk3AehOKT54SYo()
	elif Cpf9s3c0Zngj7XE==PtkEvXAqif14G20QZsaSyT(u"࠲࠷࠴ᇪ"): THdUxh1SEo4PK()
	elif Cpf9s3c0Zngj7XE==EMO8gy4LrsNTh0knZwpSeU75APW(u"࠳࠸࠶ᇫ"): N8NmdpeEDcMnZ63()
	elif Cpf9s3c0Zngj7XE==ZchUJdM93pTA7zG5(u"࠴࠹࠸ᇬ"): uASQX6HdhcklsDNE87Gm2gaR()
	elif Cpf9s3c0Zngj7XE==EMO8gy4LrsNTh0knZwpSeU75APW(u"࠵࠺࠺ᇭ"): A95DBQhrxLCE1natIK()
	elif Cpf9s3c0Zngj7XE==xpT28sXu051(u"࠶࠻࠵ᇮ"): gKvNf10iFjdG9r6UnWuc()
	elif Cpf9s3c0Zngj7XE==ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"࠷࠵࠷ᇯ"): P7y4qelk6QXo3iWraFVhngZMBC0wU()
	elif Cpf9s3c0Zngj7XE==EMO8gy4LrsNTh0knZwpSeU75APW(u"࠱࠶࠹ᇰ"): slnBYPgWXq4MdDQ21yx36LFwIaci()
	elif Cpf9s3c0Zngj7XE==y6y5HtgXO4TkUbwVZ(u"࠲࠷࠻ᇱ"): dMJhEjli0I45Kb9VquwNv()
	elif Cpf9s3c0Zngj7XE==yJeq1BjfiO4NFuwIEzxVLK6b9s(u"࠳࠸࠽ᇲ"): x8mRHgVtiOylF(rGPen6cSMHQkAywh8vqI9JXiD2)
	elif Cpf9s3c0Zngj7XE==EMO8gy4LrsNTh0knZwpSeU75APW(u"࠴࠻࠵ᇳ"): dY0Bxclpf3k849zCJHvgm1q()
	elif Cpf9s3c0Zngj7XE==HtK4o2sTPgA78U(u"࠵࠼࠷ᇴ"): TV4nOeQNmRscB()
	elif Cpf9s3c0Zngj7XE==vODxLKW5Ql6r4Fbm8(u"࠶࠽࠲ᇵ"): yyZWqpR2rFDOwjXlxcCU53([U94JwhRgpXCOe5],rGPen6cSMHQkAywh8vqI9JXiD2,rGPen6cSMHQkAywh8vqI9JXiD2,BF6QAiLUNHh7rKOugaw)
	elif Cpf9s3c0Zngj7XE==JZszNnIEMAx28Yao0yqhiXGKOPb(u"࠷࠷࠴ᇶ"): nv2FxBURGbaTYX(CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡣࡧࡥࡵࡺࡩࡷࡧࠪ຤"),rGPen6cSMHQkAywh8vqI9JXiD2)
	elif Cpf9s3c0Zngj7XE==IpC4qHXRuyNFjzWv(u"࠱࠸࠶ᇷ"): nv2FxBURGbaTYX(ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡵࡸࡲࡶࠧລ"),rGPen6cSMHQkAywh8vqI9JXiD2)
	elif Cpf9s3c0Zngj7XE==PtkEvXAqif14G20QZsaSyT(u"࠲࠹࠸ᇸ"): WNbIztwmGTMgCr8FLVvyiKA()
	elif Cpf9s3c0Zngj7XE==tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"࠳࠺࠺ᇹ"): ZdltrAxUJp5DcgRETz8isS1()
	elif Cpf9s3c0Zngj7XE==AbqCJZdWQP9j(u"࠴࠻࠼ᇺ"): Go1VbKAenJHy5iP8c(MgP8OjoaiWQEVG59(u"ࠬࡹࡣࡳ࡫ࡳࡸ࠳ࡳ࡯ࡥࡷ࡯ࡩ࠳ࡸࡥࡴࡱ࡯ࡺࡪࡻࡲ࡭ࠩ຦"))
	elif Cpf9s3c0Zngj7XE==UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"࠵࠼࠿ᇻ"): Go1VbKAenJHy5iP8c(yJeq1BjfiO4NFuwIEzxVLK6b9s(u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠭ວ"))
	elif Cpf9s3c0Zngj7XE==AbqCJZdWQP9j(u"࠶࠿࠰ᇼ"): KKDcbX7IGg1Y()
	elif Cpf9s3c0Zngj7XE==TlGXWLYsV1z(u"࠷࠹࠲ᇽ"): x0YcHamuj7EyD1vJAQ6s5XPgS()
	elif Cpf9s3c0Zngj7XE==SaB5hx3PZwXRLtKgrTfQvId(u"࠱࠺࠴ᇾ"): Q9yNg2tHVxUMEfsn7A()
	elif Cpf9s3c0Zngj7XE==ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"࠲࠻࠶ᇿ"): Jcb5o3xKyLNXmgkIrwVeu()
	elif Cpf9s3c0Zngj7XE==tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"࠳࠼࠸ሀ"): BwqbG4onx0V3OE5sFH9PaSjIl()
	elif Cpf9s3c0Zngj7XE==GGx4qyKP1vUtRghsE2WfaHLMXZ(u"࠴࠽࠺ሁ"): GvhqOXzHiW1DoxnkLa49tAZU()
	elif Cpf9s3c0Zngj7XE==uuExaKGL7UONtevRd(u"࠵࠾࠼ሂ"): ymLtCKv1UwT40WDa()
	elif Cpf9s3c0Zngj7XE==UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"࠶࠿࠷ሃ"): ZbaCcAwHmTdDge0LFqknKvWOsJpM()
	elif Cpf9s3c0Zngj7XE==SaB5hx3PZwXRLtKgrTfQvId(u"࠷࠹࠹ሄ"): OHoiTSRwnrYGPz7B9uaUmbLlZD1vs()
	elif Cpf9s3c0Zngj7XE==MgP8OjoaiWQEVG59(u"࠱࠺࠻ህ"): klKMXD9rnqmgOwdaYH6z0uA3NBREy()
	elif Cpf9s3c0Zngj7XE==zmcGfOdvAjsELeJlP(u"࠴࠶࠳ሆ"): Vo9J52sOIeCaP(U94JwhRgpXCOe5)
	elif Cpf9s3c0Zngj7XE==IpC4qHXRuyNFjzWv(u"࠵࠷࠵ሇ"): ttVx0znGRokWf3JHYgasDlF()
	elif Cpf9s3c0Zngj7XE==EMO8gy4LrsNTh0knZwpSeU75APW(u"࠶࠸࠷ለ"): fHhZArdP16tcMkCD()
	elif Cpf9s3c0Zngj7XE==jXE2YHkswT8y(u"࠷࠹࠹ሉ"): Cm71hr2u5PH4YaoTLW()
	elif Cpf9s3c0Zngj7XE==sVzojQerUqX(u"࠸࠺࠴ሊ"): Cl6JEfTgOKmi5ASVLy(rGPen6cSMHQkAywh8vqI9JXiD2)
	elif Cpf9s3c0Zngj7XE==tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"࠹࠴࠶ላ"): oAjUTPLHF4ztnSwr1d2vEgJmDpcI7l()
	elif Cpf9s3c0Zngj7XE==uuExaKGL7UONtevRd(u"࠳࠵࠸ሌ"): yyWPISuOFtKBUXq8GQDwkCjf5xos(BF6QAiLUNHh7rKOugaw)
	elif Cpf9s3c0Zngj7XE==Y41NvKfOroMzGB8sEHy7wbXlc5(u"࠴࠶࠺ል"): SMxv29nWI0HbkqUEVrgymYO(rGPen6cSMHQkAywh8vqI9JXiD2)
	elif Cpf9s3c0Zngj7XE==MgP8OjoaiWQEVG59(u"࠵࠷࠼ሎ"): jhsqCSNvpoBF8LX3wG()
	elif Cpf9s3c0Zngj7XE==tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"࠶࠸࠾ሏ"): C98klhwSjxg4mEdzGrBFn6iMIXW1Hf(FRYcH4KL7e9gv5pEB(u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬຨ"),rGPen6cSMHQkAywh8vqI9JXiD2,rGPen6cSMHQkAywh8vqI9JXiD2)
	elif Cpf9s3c0Zngj7XE==xpT28sXu051(u"࠹࠵࠶ሐ"): Ly4KftNcbFYJmszxwDE1edTn6oM()
	elif Cpf9s3c0Zngj7XE==vODxLKW5Ql6r4Fbm8(u"࠺࠶࠱ሑ"): DeTzLykVpnAF()
	elif Cpf9s3c0Zngj7XE==GGx4qyKP1vUtRghsE2WfaHLMXZ(u"࠻࠰࠳ሒ"): ho0c2JuHRidU6C41()
	elif Cpf9s3c0Zngj7XE==HtK4o2sTPgA78U(u"࠵࠱࠵ሓ"): KXnmtUQqOz7rv6G4Z3CbVk1BFHEli(NWDbjPABRxu)
	elif Cpf9s3c0Zngj7XE==tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"࠶࠲࠷ሔ"): KXnmtUQqOz7rv6G4Z3CbVk1BFHEli(v05aOkM7NXBHuT3UpAdiPq4)
	elif Cpf9s3c0Zngj7XE==vODxLKW5Ql6r4Fbm8(u"࠷࠳࠹ሕ"): qr0lMuTBKGXNJHczmgI1nPRa8wYDxS()
	elif Cpf9s3c0Zngj7XE==tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"࠸࠴࠻ሖ"): pzdyLtNP8rYDiUacIf(rGPen6cSMHQkAywh8vqI9JXiD2)
	elif Cpf9s3c0Zngj7XE==UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"࠹࠵࠽ሗ"): EEApeJRCFBk()
	elif Cpf9s3c0Zngj7XE==y6y5HtgXO4TkUbwVZ(u"࠺࠶࠸መ"): mSlsn8a4QFJM()
	elif Cpf9s3c0Zngj7XE==L90uqo28xEKSFUwYTcm51yRWZIkft(u"࠻࠰࠺ሙ"): Nw3sWaFZPix14EI9TKgu0XjA()
	elif Cpf9s3c0Zngj7XE==ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"࠱࠱࠴࠳ሚ"): hXQlNb2KPzYLcVkZnR()
	elif Cpf9s3c0Zngj7XE==CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"࠲࠲࠵࠵ማ"): XXqI3Z87WkN0GLBzDR6JwtfasSPnxc()
	elif Cpf9s3c0Zngj7XE==UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"࠳࠳࠶࠷ሜ"): Go1VbKAenJHy5iP8c(sVzojQerUqX(u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭ຩ"))
	elif Cpf9s3c0Zngj7XE==HtK4o2sTPgA78U(u"࠴࠴࠷࠹ም"): QQmN8ErRvqKDPCs9tnHjbWzVAY()
	return
def QQmN8ErRvqKDPCs9tnHjbWzVAY():
	ttKWoIH83b = OXsckY7RzjCag9A.getSetting(AbqCJZdWQP9j(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡨࡩࡵࡴࡤࡸࡪ࠭ສ"))
	message = MgP8OjoaiWQEVG59(u"ࠪห้ืโๆࠢส่๊ำฯะࠢะห้๐ว้๋ࠡࠤ࠿ࠦࠠࠡࠩຫ")+str(ttKWoIH83b)+tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠫࠥࡱࡢࡱࡵࠪຬ") if ttKWoIH83b else FRYcH4KL7e9gv5pEB(u"ࠬอไอ๊าอࠥอไฤ๊อ์๊อส๋ๅํอ๋ࠥส้ไไอࠥำวๅ์สࠫອ")
	message = PSwfZcdRYhpl5Igqz8xOEk67+message+ZchUJdM93pTA7zG5(u"࠭࡜࡯้็ࠤฯื๊ะࠢส่ว์ࠠหึ฽๎้ࠦร้ࠢอ฾๏๐ัࠡำๅ้ࠥอไอ๊าอࠥอไฤ๊อ์๊อส๋ๅํอࠬຮ")+YoQW601K4fMJcsreDnGVE5wUZIy7
	RzBbfLYvm4Fgja7GcwCHMnX0K = Ny92sqomMkizpgKV1(vODxLKW5Ql6r4Fbm8(u"ࠧࡤࡧࡱࡸࡪࡸࠧຯ"),jXE2YHkswT8y(u"ࠨะิ์ั࠭ະ"),TlGXWLYsV1z(u"ࠩศ๎็อแࠨັ"),y6y5HtgXO4TkUbwVZ(u"ࠪฮูเ๊ๅࠩາ"),MgP8OjoaiWQEVG59(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧຳ"),GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠬอไอ๊าอࠥอไฤ๊อ์๊อส๋ๅํอࠥํ๊ࠡ฻่่๏ฯ๋ࠠไ๋้ࠥฮ็ศࠢส่อืๆศ็ฯࠤออฮห์สีࠥษูๅ๋ࠣะํีษࠡ็อ์ๆืษࠡๆิๆ๊ࠦวๅฮ๋ำฮࠦวๅาํࠤฬ์สࠡฬะำิํࠠโ์๋ࠣีํࠠศๆืหูฯࠠ࠯࠰ࠣ์์ึวࠡ็฼๊ฬํฺ่ࠠา้ฬࠦสใ๊่ࠤฬ์สࠡสอุ฿๐ไࠡใํำ๏๎ࠠโษ้ࠤฬ๊ศา่ส้ัࠦไ็ࠢํืศ๊ใࠡ฻้ࠤฬ๊ฬ้ัฬࠤฬ๊ส๋ࠢอี๏ี็ศࠢ็ว๋ࠦวๅสิ๊ฬ๋ฬࠡี๋ๅࠥ๐ฮหษิࠤฬ๊ฬ้ัฬࠤศ๎ส้็สฮ๏้๊ศࠢ࠱࠲ࠥ฿ไๆษࠣห๋ํ๋ࠠฮหࠤฬิส๋ษิࠤึ่ๅࠡฮ๋ำฮࠦี฻์ิࠤสึวࠡๅส๊ฯࠦวๅว้ฮึ์สࠡ฻้ำ่ࠦศุ์ษอࠥษ่ࠡไ็๎้ฯ࡜࡯࡞ࡱࠫິ")+message)
	if RzBbfLYvm4Fgja7GcwCHMnX0K in [-ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"࠵ሞ"),ZchUJdM93pTA7zG5(u"࠵ሟ")]: return
	if RzBbfLYvm4Fgja7GcwCHMnX0K==SaB5hx3PZwXRLtKgrTfQvId(u"࠷ሠ"):
		ttKWoIH83b = iiy37aKq0pCEIOwfcTh61xb4U
		bb5kRv7jh3LaEVJtIfg(hhQwbeiNLoqFjX90fB7aG8VAs(u"࠭ࠧີ"),IpC4qHXRuyNFjzWv(u"ࠧࠨຶ"),xpT28sXu051(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫື"),jXE2YHkswT8y(u"้ࠩะาะฺࠠ็็๎ฮࠦล๋ไสๅࠥอไอ๊าอࠥอไฤ๊อ์๊อส๋ๅํอຸࠬ"))
	else:
		items = [YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠪ࠶࠺࠶ࠠ࡬ࡤࡳࡷູࠬ"),TlGXWLYsV1z(u"ࠫ࠺࠶࠰ࠡ࡭ࡥࡴࡸ຺࠭"),sVzojQerUqX(u"ࠬ࠽࠵࠱ࠢ࡮ࡦࡵࡹࠧົ"),zmcGfOdvAjsELeJlP(u"࠭࠱࠱࠲࠳ࠤࡰࡨࡰࡴࠩຼ"),ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠧ࠲࠴࠸࠴ࠥࡱࡢࡱࡵࠪຽ"),ZchUJdM93pTA7zG5(u"ࠨ࠳࠸࠴࠵ࠦ࡫ࡣࡲࡶࠫ຾"),HtK4o2sTPgA78U(u"ࠩ࠴࠻࠺࠶ࠠ࡬ࡤࡳࡷࠬ຿"),UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠪ࠶࠵࠶࠰ࠡ࡭ࡥࡴࡸ࠭ເ"),JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠫ࠷࠻࠰࠱ࠢ࡮ࡦࡵࡹࠧແ"),hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠬ࠹࠰࠱࠲ࠣ࡯ࡧࡶࡳࠨໂ"),ZchUJdM93pTA7zG5(u"࠭࠳࠶࠲࠳ࠤࡰࡨࡰࡴࠩໃ"),Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠧ࠵࠲࠳࠴ࠥࡱࡢࡱࡵࠪໄ"),HtK4o2sTPgA78U(u"ࠨ࠶࠸࠴࠵ࠦ࡫ࡣࡲࡶࠫ໅"),GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠩ࠸࠴࠵࠶ࠠ࡬ࡤࡳࡷࠬໆ"),AbqCJZdWQP9j(u"ࠪ࠺࠵࠶࠰ࠡ࡭ࡥࡴࡸ࠭໇"),tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠫ࠼࠶࠰࠱ࠢ࡮ࡦࡵࡹ່ࠧ"),GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠬ࠾࠰࠱࠲ࠣ࡯ࡧࡶࡳࠨ້"),XrTw01KtLzbpoyMf(u"࠭࠹࠱࠲࠳ࠤࡰࡨࡰࡴ໊ࠩ"),FRYcH4KL7e9gv5pEB(u"ࠧ࠲࠲࠳࠴࠵ࠦ࡫ࡣࡲࡶ໋ࠫ"),SaB5hx3PZwXRLtKgrTfQvId(u"ࠨ࠳࠴࠴࠵࠶ࠠ࡬ࡤࡳࡷࠬ໌"),uuExaKGL7UONtevRd(u"ࠩ࠴࠶࠵࠶࠰ࠡ࡭ࡥࡴࡸ࠭ໍ"),zmcGfOdvAjsELeJlP(u"ࠪ࠽࠾࠿࠹࠺ࠢ࡮ࡦࡵࡹࠧ໎")]
		mmfrx2S5XqknFTDeRhj49LuYv1wW0 = ccv1mVPUsnr(UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠫฬิสาࠢส่ั๎ฯสࠢส่ศ๎ส้็สฮ๏้๊สࠢส่๊์วิสฬࠫ໏"),items)
		if mmfrx2S5XqknFTDeRhj49LuYv1wW0==-LyNiIHPOwD3hCUYEFM7(u"࠱ሡ"): return
		ttKWoIH83b = str(items[mmfrx2S5XqknFTDeRhj49LuYv1wW0][:-Y41NvKfOroMzGB8sEHy7wbXlc5(u"࠶ሢ")])
		bb5kRv7jh3LaEVJtIfg(ZchUJdM93pTA7zG5(u"ࠬ࠭໐"),hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"࠭ࠧ໑"),tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ໒"),AbqCJZdWQP9j(u"ࠨ่ฯัฯูࠦๆๆํอࠥะิ฻์็ࠤํะอะ์าࠤึ่ๅࠡษ็ะํีษࠡษ็วํะ่ๆษอ๎่๐ษ࡝ࡰ࡟ࡲࠬ໓")+PSwfZcdRYhpl5Igqz8xOEk67+ttKWoIH83b+uuExaKGL7UONtevRd(u"ࠩࠣ࡯ࡧࡶࡳࠨ໔")+YoQW601K4fMJcsreDnGVE5wUZIy7)
	OXsckY7RzjCag9A.setSetting(zmcGfOdvAjsELeJlP(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡢࡪࡶࡵࡥࡹ࡫ࠧ໕"),ttKWoIH83b)
	return
def XXqI3Z87WkN0GLBzDR6JwtfasSPnxc(f1uyjEq9hPiACzL5XsK=BF6QAiLUNHh7rKOugaw):
	g3xZ09E8heVCD5Hfonsi = pNO0reZBaLzh1Y9GMinuPHASg()
	XwATyRiUE4HLj = ZchUJdM93pTA7zG5(u"ࠫฬ๊สี฼ํ่ࠥอไๅษะๆࠥ๐ูๆๆࠪ໖") if g3xZ09E8heVCD5Hfonsi else uuExaKGL7UONtevRd(u"ࠬอไหึ฽๎้ࠦวๅๆสั็ࠦๅห๊ๅๅࠬ໗")
	RzBbfLYvm4Fgja7GcwCHMnX0K = Ny92sqomMkizpgKV1(TlGXWLYsV1z(u"࠭ࡣࡦࡰࡷࡩࡷ࠭໘"),XrTw01KtLzbpoyMf(u"ࠧฯำ๋ะࠬ໙"),hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠨวํๆฬ็ࠧ໚"),LyNiIHPOwD3hCUYEFM7(u"ࠩอุ฿๐ไࠨ໛"),y6y5HtgXO4TkUbwVZ(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ໜ"),PSwfZcdRYhpl5Igqz8xOEk67+XwATyRiUE4HLj+YoQW601K4fMJcsreDnGVE5wUZIy7+OTlVEGYPSxsNaBdXUucqA3+xpT28sXu051(u"ࠫ์ึ็ࠡษ็์฽๐แสࠢอะ฾๊ࠠไ๊า๎ࠥษ่ห๊่หฯ๐ใ๋ษࠣ๎็๎ๅࠡสอุ฿๐ไࠡษ็ๅ๏ี๊้ࠢส่้ออใࠢ࠱࠲ࠥหๅศࠢห฽ิࠦว็ฬ๊หฦࠦวๅใํำ๏๎ࠠศๆะห้๐ࠠษลๆ้้ํࠠ࠯࠰ࠣวํࠦศฺัࠣห้์โาࠢ฼่๎ࠦาาࠢࠥฮัอ่ำࠢศ่๎ࠦวๅๆสั็ࠨࠠ࠯࠰ࠣ์ศ๐ึศ่้่ࠢ์ࠠฦๆ฽หฦࠦวๅฬื฾๏๊ࠠศๆ็หา่ࠠษษ็๊็ืฺࠠๆ์ࠤืืࠠࠣวํๆฬ็ࠠศๆไ๎ิ๐่ࠣࠢ࠱࠲ࠥ๎รุ๋สࠤ๊๋ใ็ࠢส่ฬูสโษาอ๋ࠥๆࠡฬ฽๎๏ืࠠหำอ๎อࠦๅฮฬ๋๎ฬะࠠศๆๅ์ฬฬๅࠡ࠰࠱ࠤํิวึหࠣฮึะ๊ษࠢะ่็อสࠡษ็ุ้๊ำๅษอࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡษ็ฦ๋ࠦสี฼ํ่ࠥํะ่ࠢส่ํ฾๊โหࠣว๊ࠦล๋ไสๅ์อࠠภࠣࠤࠫໝ"))
	if RzBbfLYvm4Fgja7GcwCHMnX0K==YYJQyRskpX8jv: tqC0PngwO4pA = WwMgozBIC32n9d0tyfp.executeJSONRPC(uuExaKGL7UONtevRd(u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡓࡦࡶࡖࡩࡹࡺࡩ࡯ࡩ࡙ࡥࡱࡻࡥࠣ࠮ࠥ࡭ࡩࠨ࠺࠲࠮ࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡳࡦࡶࡷ࡭ࡳ࡭ࠢ࠻ࠤࡹ࡭ࡩ࡫࡯ࡱ࡮ࡤࡽࡪࡸ࠮ࡢࡷࡷࡳࡵࡲࡡࡺࡰࡨࡼࡹ࡯ࡴࡦ࡯ࠥ࠰ࠧࡼࡡ࡭ࡷࡨࠦ࠿ࡡ࡝ࡾࡿࠪໞ"))
	elif RzBbfLYvm4Fgja7GcwCHMnX0K==nI2JK1RfsGWNY3OarEeMQZ: tqC0PngwO4pA = WwMgozBIC32n9d0tyfp.executeJSONRPC(IpC4qHXRuyNFjzWv(u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾࡙ࠧࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡔࡧࡷࡗࡪࡺࡴࡪࡰࡪ࡚ࡦࡲࡵࡦࠤ࠯ࠦ࡮ࡪࠢ࠻࠳࠯ࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡴࡧࡷࡸ࡮ࡴࡧࠣ࠼ࠥࡺ࡮ࡪࡥࡰࡲ࡯ࡥࡾ࡫ࡲ࠯ࡣࡸࡸࡴࡶ࡬ࡢࡻࡱࡩࡽࡺࡩࡵࡧࡰࠦ࠱ࠨࡶࡢ࡮ࡸࡩࠧࡀ࡛࠲࡟ࢀࢁࠬໟ"))
	if RzBbfLYvm4Fgja7GcwCHMnX0K in [YYJQyRskpX8jv,nI2JK1RfsGWNY3OarEeMQZ]:
		if YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠧࡵࡴࡸࡩࠬ໠") in str(tqC0PngwO4pA): bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ໡"),GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠩอ้ฯࠦวๅ฻่่๏ฯࠠษ่ฯหา࠭໢"))
		else: bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,TlGXWLYsV1z(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭໣"),AbqCJZdWQP9j(u"้๊ࠫริใࠣห้฿ๅๅ์ฬࠤๆฺไหࠩ໤"))
	return
def hXQlNb2KPzYLcVkZnR():
	url = gZ4LwbKaOm[ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠬࡘࡅࡍࡇࡄࡗࡊ࡙ࠧ໥")][xpT28sXu051(u"࠲ሣ")]
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(hI7SkXd94fFzAHNZCQoMqEutbnWP,ZchUJdM93pTA7zG5(u"࠭ࡇࡆࡖࠪ໦"),url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,vODxLKW5Ql6r4Fbm8(u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࡌࡒࡘ࡚ࡁࡍࡎࡢࡓࡑࡊ࡟ࡓࡇࡏࡉࡆ࡙ࡅ࠮࠳ࡶࡸࠬ໧"))
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	frKzDoxVINlL397S = dEyT9xhGjolYzLCH7460w3.findall(YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠨࡪࡵࡩ࡫ࡃࠢࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࠨࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠴ࠪࡀࠫ࠱ࡾ࡮ࡶࠢࠨ໨"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	frKzDoxVINlL397S = sorted(frKzDoxVINlL397S,reverse=rGPen6cSMHQkAywh8vqI9JXiD2)
	mmfrx2S5XqknFTDeRhj49LuYv1wW0 = ccv1mVPUsnr(EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠩสาฯืࠠศๆศูิอัࠡษ็ิ๏ࠦสา์าࠤฯัศ๋ฬ๊ࠫ໩"),frKzDoxVINlL397S)
	if mmfrx2S5XqknFTDeRhj49LuYv1wW0>=JZszNnIEMAx28Yao0yqhiXGKOPb(u"࠳ሤ"):
		bvyzPrwZWUTO5uctLnV = url.rsplit(ZchUJdM93pTA7zG5(u"ࠪ࠳ࠬ໪"),YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"࠵ሥ"))[IpC4qHXRuyNFjzWv(u"࠵ሦ")]+UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠫ࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࠬ໫")+frKzDoxVINlL397S[mmfrx2S5XqknFTDeRhj49LuYv1wW0]+CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠬ࠴ࡺࡪࡲࠪ໬")
		succeeded = p6JieQVcbmWuIxroRA4v3fCdT(ZchUJdM93pTA7zG5(u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫ໭"),bvyzPrwZWUTO5uctLnV,xpT28sXu051(u"࡙ࡸࡵࡦቺ"))
		if succeeded:
			OXsckY7RzjCag9A.setSetting(SaB5hx3PZwXRLtKgrTfQvId(u"ࠧࡢࡸ࠱ࡺࡪࡸࡳࡪࡱࡱࠫ໮"),iiy37aKq0pCEIOwfcTh61xb4U)
			U17QqF2gkI46 = A1AXKupEOfz(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,zmcGfOdvAjsELeJlP(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ໯"),ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠩอ้ࠥะหษ์อࠤส฻ฯศำࠣๆิ๐ๅࠡๆ็ฬึ์วๆฮࠣ࠲࠳ࠦไไ่ࠣฬึ์วๆฮࠣ็ํี๊ࠡ์ๅ์๊ࠦร้ฬ๋้ฬะ๊ไ์สࠤอะอะ์ฮࠤัฺ๋๊ࠢส่อืวๆฮࠣฬฬูสฯัส้ࠥศฮาࠢศูิอัࠡ็อ์ๆืࠠ࠯࠰๋้ࠣࠦสา์าࠤฬ๊ย็ࠢศ๎็อแࠡษ็ฮาี๊ฬࠢส่ศ๎ส้็สฮ๏้๊ࠡๆ๊ิฬࠦวๅสิ๊ฬ๋ฬࠡมࠤࠥࠬ໰"))
			if U17QqF2gkI46: C98klhwSjxg4mEdzGrBFn6iMIXW1Hf(TlGXWLYsV1z(u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨ໱"),rGPen6cSMHQkAywh8vqI9JXiD2,rGPen6cSMHQkAywh8vqI9JXiD2)
	return
def EEApeJRCFBk():
	U17QqF2gkI46 = A1AXKupEOfz(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,uuExaKGL7UONtevRd(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ໲"),L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠬํไࠡฬิ๎ิࠦแฺๆสࠤู๊อࠡว฼ำฬีวหࠢส่อืๆศ็ฯࠤฬ๊ฮศืฬࠤอ๎โหࠢฯ่อࠦวๅฬะำ๏ัวหࠢ࠱࠲ࠥํะศࠢสู่๊อࠡี๋ๅࠥ๐ำษสࠣฮาี๊ฬࠢไ์ึ๐ࠠๅฮ่๎฾ู่ࠦษษๅࠥอไษำ้ห๊าࠠศๆอ๎ࠥะูห็าࠤ฾๊้ࠡ็ิ์ึ่ࠦใฬ้ࠣ฾๐ๆࠨ໳"))
	if U17QqF2gkI46:
		OXsckY7RzjCag9A.setSetting(y6y5HtgXO4TkUbwVZ(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡹࡨࡰࡴࡷࠫ໴"),iiy37aKq0pCEIOwfcTh61xb4U)
		OXsckY7RzjCag9A.setSetting(tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴ࡲࡦࡩࡸࡰࡦࡸࠧ໵"),iiy37aKq0pCEIOwfcTh61xb4U)
		OXsckY7RzjCag9A.setSetting(ZchUJdM93pTA7zG5(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮࡭ࡱࡱ࡫ࠬ໶"),iiy37aKq0pCEIOwfcTh61xb4U)
		OXsckY7RzjCag9A.setSetting(vODxLKW5Ql6r4Fbm8(u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯࡯ࡨࡷࡸࡧࡧࡦࡵࠪ໷"),iiy37aKq0pCEIOwfcTh61xb4U)
		OXsckY7RzjCag9A.setSetting(jXE2YHkswT8y(u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰ࡴࡹࡪࡹࡴࡪࡱࡱࡷࠬ໸"),iiy37aKq0pCEIOwfcTh61xb4U)
		bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,IpC4qHXRuyNFjzWv(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ໹"),FRYcH4KL7e9gv5pEB(u"ࠬะๅࠡ็ึัࠥหูะษาหฯࠦวๅสิ๊ฬ๋ฬࠡษ็าฬ฻ษࠡส๋ๆฯࠦฬๅสࠣห้ะอะ์ฮหฯࠦ࠮࠯๋ࠢืํ็๋ࠠไ๋้ࠥอไษำ้ห๊าࠠศๆล๊ࠥฮสฮัํฯࠥํะ่ࠢส่ส฿ฯศัสฮࠥ࠴࠮๊ࠡฦ๎฻อࠠหฯา๎ะู่ࠦษษๅࠥอไษำ้ห๊าࠠศๆอ๎ࠥะูห็าࠤ฾๊้ࠡษ็์็ะࠧ໺"))
		SqMHwb6X1Ph8jY7LBNkmtV4F5Jlspy(BF6QAiLUNHh7rKOugaw)
	return
def Nw3sWaFZPix14EI9TKgu0XjA():
	U17QqF2gkI46 = A1AXKupEOfz(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ໻"),TlGXWLYsV1z(u"่ࠧๆࠣฮึ๐ฯࠡใ฼่ฬࠦๅิฯࠣะ๊๐ูࠡว฼ำฬีวหࠢส่อืๆศ็ฯࠤ࠳࠴้ࠠ็ึัࠥาๅ๋฻้้ࠣ็วหࠢส่อืๆศ็ฯࠤฬ๊โะ์่อࠥ࠴࠮ࠡๆๆ๎ࠥ๐ู้ัࠣห้ฮั็ษ่ะࠥหไ๊ࠢะห้ฯࠠศๆุๅึࠦ࠮࠯ࠢํ฽๋๐ࠠหฮา๎ิࠦวๅสิ๊ฬ๋ฬ๊ࠡอูๆ๐ั่๋ࠢ์฻฿็ࠡสะห้ฯࠠศๆู่๋฿ࠠศๆอ๎ࠥ๎ึฺ้สࠤฬ๊ๅษำ่ะࠥลࠡࠢࠩ໼"))
	if U17QqF2gkI46:
		Cl6JEfTgOKmi5ASVLy(BF6QAiLUNHh7rKOugaw)
		TAkeulImazNdJwE9(StqmrCIJX4T623w5j9NEonxfQ,rGPen6cSMHQkAywh8vqI9JXiD2,BF6QAiLUNHh7rKOugaw)
		bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ໽"),GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠩอ้๋ࠥำฮࠢฯ้๏฿ࠠศๆ่่ๆอสࠡษ็ๆิ๐ๅสࠢ็่อืๆศ็ฯࠤ࠳࠴้ࠠ฻สำࠥอไษำ้ห๊าࠠฦๆ์ࠤํ฼ู๋หࠣห้฻แาࠢ࠱࠲ࠥ๎ึฺ์ฬࠤฬ๊ๅึ่฼ࠫ໾"))
	return
def qr0lMuTBKGXNJHczmgI1nPRa8wYDxS():
	Bcxq3nkvTU9iM(PdkZHNBlpg2b7DmX6qRiyVa,HtK4o2sTPgA78U(u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭໿"),XrTw01KtLzbpoyMf(u"ࠫࡖ࡛ࡅࡔࡖࡌࡓࡓ࡙ࠧༀ"))
	ddxk8CzNrlhiJtSeTDLVEa0c = QeY9sWZqAhDomcd3rMIp(BF6QAiLUNHh7rKOugaw)
	c7uAX1toOVima2UR5SnDzTG = OTlVEGYPSxsNaBdXUucqA3
	hhYb718GslzwN2D4C = aqEsMBckT2bunGHfl48Wip+zmcGfOdvAjsELeJlP(u"ࠬࠦ࠭࠮࠯࠰࠱ࠥ࠳࠭࠮࠯࠰ࠤ࠲࠳࠭࠮࠯ࠣ࠱࠲࠳࠭࠮ࠢ࠰࠱࠲࠳࠭ࠡࠩ༁")+YoQW601K4fMJcsreDnGVE5wUZIy7
	f8fqDilWELczvwnr3AX1gm = OTlVEGYPSxsNaBdXUucqA3+PSwfZcdRYhpl5Igqz8xOEk67+jXE2YHkswT8y(u"࠭ࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࠪ༂")+YoQW601K4fMJcsreDnGVE5wUZIy7+tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠧ࡝ࡰ࡟ࡲࠬ༃")
	for id,BBWS6VTi15YeM2bvJGXtxpslDhg8,bl81eAwQG63tZjRhSzX0dCIv,OC9lxzDodrFpvn8X6kMebAfE1tKS,GNzbpq6tvX1kZjgixEmSn,reason in reversed(ddxk8CzNrlhiJtSeTDLVEa0c):
		if id==HtK4o2sTPgA78U(u"ࠨ࠲ࠪ༄"):
			aRmuUoYczdTE4hbLO0JMqty,aS4kgtYoWwlFLs1m9 = OC9lxzDodrFpvn8X6kMebAfE1tKS.split(HtK4o2sTPgA78U(u"ࠩ࡟ࡲࡀࡁࠧ༅"))
			continue
		if c7uAX1toOVima2UR5SnDzTG!=OTlVEGYPSxsNaBdXUucqA3: c7uAX1toOVima2UR5SnDzTG += f8fqDilWELczvwnr3AX1gm
		ngZh3MbtFxsQAjGvyUJ67VN = AbqCJZdWQP9j(u"ࠪ࡟ࡗ࡚ࡌ࡞ࠩ༆")+aqEsMBckT2bunGHfl48Wip+id+MgP8OjoaiWQEVG59(u"ࠫࠥࡀࠠࠨ༇")+PtkEvXAqif14G20QZsaSyT(u"ࠬอไิฦส่ࠥࡀࠠࠨ༈")+YoQW601K4fMJcsreDnGVE5wUZIy7+bl81eAwQG63tZjRhSzX0dCIv
		E8ZibMeyGK = JZszNnIEMAx28Yao0yqhiXGKOPb(u"࠭࡜࡯࡝ࡕࡘࡑࡣࠧ༉")+aqEsMBckT2bunGHfl48Wip+AbqCJZdWQP9j(u"ࠧศๆฯ์ฬฮࠠ࠻ࠢࠪ༊")+YoQW601K4fMJcsreDnGVE5wUZIy7+OC9lxzDodrFpvn8X6kMebAfE1tKS
		dANSkE5C2gKL4z7DTmuXBFR = IpC4qHXRuyNFjzWv(u"ࠨ࡝ࡕࡘࡑࡣࠧ་")+aqEsMBckT2bunGHfl48Wip+y6y5HtgXO4TkUbwVZ(u"ࠩส่ำ฽รࠡ࠼ࠣࠫ༌")+YoQW601K4fMJcsreDnGVE5wUZIy7+GNzbpq6tvX1kZjgixEmSn
		ngWSHzwAk1r8oKB = hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠪࡠࡳࡡࡒࡕࡎࡠࠫ།")+aqEsMBckT2bunGHfl48Wip+IpC4qHXRuyNFjzWv(u"ࠫฬ๊ำษสࠣ࠾ࠥ࠭༎")+YoQW601K4fMJcsreDnGVE5wUZIy7+reason
		c7uAX1toOVima2UR5SnDzTG += ngZh3MbtFxsQAjGvyUJ67VN+E8ZibMeyGK+OTlVEGYPSxsNaBdXUucqA3+hhYb718GslzwN2D4C+OTlVEGYPSxsNaBdXUucqA3+dANSkE5C2gKL4z7DTmuXBFR+ngWSHzwAk1r8oKB+OTlVEGYPSxsNaBdXUucqA3
	ggULVKqsMZbc1ynfBC7(GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠬࡸࡩࡨࡪࡷࠫ༏"),aS4kgtYoWwlFLs1m9,c7uAX1toOVima2UR5SnDzTG,tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࡡ࡯ࡳࡳ࡭ࠧ༐"))
	return
def KXnmtUQqOz7rv6G4Z3CbVk1BFHEli(file):
	if file==v05aOkM7NXBHuT3UpAdiPq4: qc4AX1Mg9lW6Ro = IpC4qHXRuyNFjzWv(u"ࠧใ๊สส๊ࠦวๅ็ไฺ้ฯࠧ༑")
	elif file==NWDbjPABRxu: qc4AX1Mg9lW6Ro = YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠨไ๋หห๋ࠠระิࠤฬ๊แ๋ัํ์์อสࠨ༒")
	RzBbfLYvm4Fgja7GcwCHMnX0K = Ny92sqomMkizpgKV1(JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠩࡦࡩࡳࡺࡥࡳࠩ༓"),XrTw01KtLzbpoyMf(u"ุ้ࠪำࠧ༔"),y6y5HtgXO4TkUbwVZ(u"ࠫส฻ไศฯࠪ༕"),tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠬิั้ฮࠪ༖"),HtK4o2sTPgA78U(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ༗"),zmcGfOdvAjsELeJlP(u"่ࠧๆࠣฮึ๐ฯࠡวุ่ฬำࠠๆๆไࠤ༘ࠬ")+qc4AX1Mg9lW6Ro+UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠨࠢฦ้ࠥะั๋ัุ้ࠣำࠠศๆ่่ๆࠦฟࠨ༙"))
	if RzBbfLYvm4Fgja7GcwCHMnX0K==AbqCJZdWQP9j(u"࠶ሧ"):
		if wkMR5x1gTWEQIc6qHCa.path.exists(file):
			try: wkMR5x1gTWEQIc6qHCa.remove(file)
			except: pass
		bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ༚"),ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠪฮ๊ࠦๅิฯ้้ࠣ็ࠠࠨ༛")+qc4AX1Mg9lW6Ro)
	elif RzBbfLYvm4Fgja7GcwCHMnX0K==XrTw01KtLzbpoyMf(u"࠱ረ"):
		data = vvqB64XWVrb1kKJmC0xyNHiF7fOL(file)
		bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,xpT28sXu051(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ༜"),vODxLKW5Ql6r4Fbm8(u"ࠬะๅࠡวุ่ฬำࠠๆๆไࠤࠬ༝")+qc4AX1Mg9lW6Ro)
	return
def DeTzLykVpnAF():
	if ZD1J5rN8u2wzdgqoyULm4<yJeq1BjfiO4NFuwIEzxVLK6b9s(u"࠲࠺ሩ"):
		aZtYlicqMKUFPkBCX2AONHwJ4 = jXE2YHkswT8y(u"࠭ไๅลึๅࠥษๆหࠢอืฯิฯๆࠢศูิอัࠡๅ๋ำ๏ࠦโะ์่ࠤึ่ๅࠡࠩ༞")+str(ZD1J5rN8u2wzdgqoyULm4)+LyNiIHPOwD3hCUYEFM7(u"๊ࠧࠡ็๋ีอࠠศๆๅ์ฬฬๅࠡษ็ฺ้๎ัสࠢ็หࠥะูๆๆࠣ฽๋ีใࠡ࠰๋ࠣีํࠠศๆ่๎ืฯࠠห็ๆ๊่ࠦๅ็ࠢิศ๏ฯࠠใ๊สส๊ࠦวๅใํำ๏๎็ศฬࠣๅ๏ࠦศา่ส้ัูࠦๆษาࠤอฺใๅุࠢ์ึࠦศะๆสࠤ๊์ࠠศๆๆฮฬฮษࠡ࠰่ࠣส฻ไศฯࠣห้๋ิไๆฬࠤ็๋ࠠษฬะำ๏ัࠠษำ้ห๊าࠠไ๊า๎ࠥหไ๊ࠢศ๎ࠥหีะษิࠤึ่ๅ่ࠢฦ฽้๏ࠠๆ่ࠣ࠵࠽࠴࠰ࠨ༟")
		bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ༠"),aZtYlicqMKUFPkBCX2AONHwJ4)
		return
	Pwe2ycZtIx5FOrhuf = WwMgozBIC32n9d0tyfp.executeJSONRPC(ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡕࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡋࡪࡺࡓࡦࡶࡷ࡭ࡳ࡭ࡖࡢ࡮ࡸࡩࠧ࠲ࠢࡪࡦࠥ࠾࠶࠲ࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡷࡪࡺࡴࡪࡰࡪࠦ࠿ࠨ࡬ࡰࡱ࡮ࡥࡳࡪࡦࡦࡧ࡯࠲ࡸࡱࡩ࡯ࠤࢀࢁࠬ༡"))
	qQsCzJV2Wgr63in8YF1E0dXf9OSG = Mk1o9HmfhFYupBtdi3([PtkEvXAqif14G20QZsaSyT(u"ࠪࡷࡰ࡯࡮࠯࡯ࡨࡸࡷࡵࡰࡰ࡮࡬ࡷࡊࡓࡁࡅࠩ༢")])
	BCG6aEXrN0,TrNIMpGVPcHKwSYBey2dEktojF3m,i4HB0oGxJz,i7iZljt2REAQ3,Yd6yUzs7cfMS4tD1o,nnPvurpEaAbeLl,WTkUo7vujwBpFY2M0qJiLnmPg8fz = qQsCzJV2Wgr63in8YF1E0dXf9OSG[hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪ༣")]
	if BCG6aEXrN0 or L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠬࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇࠫ༤") not in str(Pwe2ycZtIx5FOrhuf):
		bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,JZszNnIEMAx28Yao0yqhiXGKOPb(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ༥"),XrTw01KtLzbpoyMf(u"ࠧศๆๅ์ฬฬๅࠡษ็ฺ้๎ัสࠢอ฽๊๊ࠠโไฺࠤ๊฿ࠠอๆาࠤ๊ะั้สุู๋่ࠦๆษาࠤ࠳ࠦ็ั้ࠣห้่่ศศ่ࠤฯ๋ใ็ๅ้๋ࠣࠦัล์ฬࠤ็๎วว็ࠣฬึ์วๆฮࠣ฽๊อฯࠡสื็้ࠦี้ำࠣฬิ๊วࠡ็้ࠤฬ๊ใหษหอࠬ༦"))
		M5qyIg2dZlm6FxH4tTPV79okNu0bCG = ho0c2JuHRidU6C41()
		if not M5qyIg2dZlm6FxH4tTPV79okNu0bCG: return
	gv0QrBSsWVdLY5TnNRwDy4kjeb(rGPen6cSMHQkAywh8vqI9JXiD2)
	return
def gv0QrBSsWVdLY5TnNRwDy4kjeb(showDialogs=rGPen6cSMHQkAywh8vqI9JXiD2):
	Pwe2ycZtIx5FOrhuf = WwMgozBIC32n9d0tyfp.executeJSONRPC(zmcGfOdvAjsELeJlP(u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡔࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡊࡩࡹ࡙ࡥࡵࡶ࡬ࡲ࡬࡜ࡡ࡭ࡷࡨࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡶࡩࡹࡺࡩ࡯ࡩࠥ࠾ࠧࡲ࡯ࡰ࡭ࡤࡲࡩ࡬ࡥࡦ࡮࠱ࡷࡰ࡯࡮ࠣࡿࢀࠫ༧"))
	if zmcGfOdvAjsELeJlP(u"ࠩࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄࠨ༨") not in str(Pwe2ycZtIx5FOrhuf):
		if showDialogs:
			bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭༩"),ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"้๊ࠫริใࠣะ์อาไࠢ็หࠥ๐ำหะา้ࠥาไะ่ࠢฮึ๎ศ้ๆึࠤ฾๋วะࠢ࠱ࠤฬ๊โ้ษษ้ࠥอไๆื๋ีฮࠦสฺ็็ࠤๆ่ืࠡ็฼ࠤั๊ฯࠡ็อีํฮ่ๅีࠣ฽๊อฯࠡ࠰๋ࠣีํࠠศๆๅ์ฬฬๅࠡฬ่็๋้ࠠๆ่ࠣีษ๐ษࠡไ๋หห๋ࠠษำ้ห๊าฺࠠ็สำࠥฮิไๆูࠣํืࠠษั็ห๋ࠥๆࠡษ็็ฯอศสࠩ༪"))
		return
	IgAlzW7nP1NdyF = wkMR5x1gTWEQIc6qHCa.path.join(Hyw4UJ6ephu,LyNiIHPOwD3hCUYEFM7(u"ࠬࡧࡤࡥࡱࡱࡷࠬ༫"),FRYcH4KL7e9gv5pEB(u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈࠬ༬"),ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠧ࠸࠴࠳ࡴࠬ༭"),hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠨࡏࡼ࡚࡮ࡪࡥࡰࡐࡤࡺ࠳ࡾ࡭࡭ࠩ༮"))
	if not wkMR5x1gTWEQIc6qHCa.path.exists(IgAlzW7nP1NdyF): return
	dQ960sl5X13MFwW24jEtCBR = open(IgAlzW7nP1NdyF,MgP8OjoaiWQEVG59(u"ࠩࡵࡦࠬ༯")).read()
	if J1MoiYc7ZwzKS: dQ960sl5X13MFwW24jEtCBR = dQ960sl5X13MFwW24jEtCBR.decode(df6QpwGxuJVZr)
	d1TLKe7Y9xDBVwqtoI8shn3 = dEyT9xhGjolYzLCH7460w3.findall(sVzojQerUqX(u"ࠪࡀࡻ࡯ࡥࡸࡵࡁࠬࡡࡪࠫ࠭࡞ࡧ࠯࠱ࡢࡤࠬࠫ࠯ࠬ࠳࠰࠿ࠪ࠾࠲ࡺ࡮࡫ࡷࡴࡀࠪ༰"),dQ960sl5X13MFwW24jEtCBR,dEyT9xhGjolYzLCH7460w3.DOTALL)
	mmD2IvAKkN60,ppyvVonThaiuWjXAczPt7CBJ2 = d1TLKe7Y9xDBVwqtoI8shn3[FGTfwsjNrB8DvKSZhLIQAb1JnO]
	iRLX0QKpNJFtV6axYWjfTZb = ZchUJdM93pTA7zG5(u"ࠫࡁࡼࡩࡦࡹࡶࡂࠬ༱")+mmD2IvAKkN60+AbqCJZdWQP9j(u"ࠬ࠲ࠧ༲")+ppyvVonThaiuWjXAczPt7CBJ2+UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"࠭࠼࠰ࡸ࡬ࡩࡼࡹ࠾ࠨ༳")
	if showDialogs:
		aatPRUBcJdKNrqSwMXTGjQCWg9 = WwMgozBIC32n9d0tyfp.getInfoLabel(tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱࡚࡮࡫ࡷ࡮ࡱࡧࡩࠬ༴"))
		if aatPRUBcJdKNrqSwMXTGjQCWg9==hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠨࡇࡐࡅࡉࠦࡌࡪࡵࡷ༵ࠫ"): EXSMU1qhPLlWp985KJfsFQRC = EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠩๅ์ฬฬๅࠡษ็็ฯอศสࠩ༶")
		elif aatPRUBcJdKNrqSwMXTGjQCWg9==UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠪࡉࡒࡇࡄࠡࡉࡤࡰࡱ࡫ࡲࡺ༷ࠩ"): EXSMU1qhPLlWp985KJfsFQRC = YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠫ็๎วว็ࠣห้฻่าࠩ༸")
		else: EXSMU1qhPLlWp985KJfsFQRC = ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"่่ࠬศศ่ࠤศิั๊༹ࠩ")
		RzBbfLYvm4Fgja7GcwCHMnX0K = Ny92sqomMkizpgKV1(EMO8gy4LrsNTh0knZwpSeU75APW(u"࠭ࡣࡦࡰࡷࡩࡷ࠭༺"),XrTw01KtLzbpoyMf(u"ࠧใ๊สส๊ࠦรฯำ์ࠫ༻"),jXE2YHkswT8y(u"ࠨไ๋หห๋ࠠศๆๆฮฬฮษࠨ༼"),uuExaKGL7UONtevRd(u"ࠩๅ์ฬฬๅࠡษ็ูํืࠧ༽"),MgP8OjoaiWQEVG59(u"ࠪห๋ะࠠฮษ็๎ฬࠦสิฬัำ๊ࠦࠧ༾")+EXSMU1qhPLlWp985KJfsFQRC,ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠫฬ์สࠡษ็ฦ๋ࠦสิฬัำ๊ࠦวๅวุำฬืࠠศๆฦา๏ืࠠๅฮ็ำ๋ࠥสา๊ห์ฺู้ࠠ็สำࠥ࠴้้ࠠำหู๋ࠥ็ษ๊ࠤฬ์ใࠡฬึฮ฼๐ูࠡษึฮำีวๆࠢส่็๎วว็ࠣห้๋ี้ำฬࠤอีไศ่๊่่ࠢࠥศศ่ࠤฬ๊ใหษหอࠥ࠴้ࠠลํฺฬࠦสิฬฺ๎฾ࠦล๋ไสๅ์อࠠโ์ࠣว๏่ࠦใฬࠣฮูอมࠡ࡞ࡱࡠࡳࠦࠧ༿")+aqEsMBckT2bunGHfl48Wip+PtkEvXAqif14G20QZsaSyT(u"ࠬࠦรฯฬิࠤฬ๊ย็้ࠢ์฾ࠦวๅไ๋หห๋ࠠศๆอ๎ࠥะั๋ัࠣวุะฮะษ่๋ฬࠦฟࠢࠩཀ")+YoQW601K4fMJcsreDnGVE5wUZIy7)
		if RzBbfLYvm4Fgja7GcwCHMnX0K==AbqCJZdWQP9j(u"࠳ሪ"): gIV0YPXebBpfDG3MlzsNo5SjLk = FRYcH4KL7e9gv5pEB(u"࠭ࡅࡎࡃࡇࠤࡑ࡯ࡳࡵࠩཁ")
		elif RzBbfLYvm4Fgja7GcwCHMnX0K==FRYcH4KL7e9gv5pEB(u"࠵ራ"): gIV0YPXebBpfDG3MlzsNo5SjLk = XrTw01KtLzbpoyMf(u"ࠧࡆࡏࡄࡈࠥࡍࡡ࡭࡮ࡨࡶࡾ࠭ག")
		else: gIV0YPXebBpfDG3MlzsNo5SjLk = iiy37aKq0pCEIOwfcTh61xb4U
	else:
		aatPRUBcJdKNrqSwMXTGjQCWg9 = OXsckY7RzjCag9A.getSetting(MgP8OjoaiWQEVG59(u"ࠨࡣࡹ࠲ࡲࡿࡳ࡬࡫ࡱ࠲ࡻ࡯ࡥࡸ࡯ࡲࡨࡪ࠭གྷ"))
		if   aatPRUBcJdKNrqSwMXTGjQCWg9==iiy37aKq0pCEIOwfcTh61xb4U: RzBbfLYvm4Fgja7GcwCHMnX0K = SaB5hx3PZwXRLtKgrTfQvId(u"࠴ሬ")
		elif aatPRUBcJdKNrqSwMXTGjQCWg9==Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠩࡈࡑࡆࡊࠠࡍ࡫ࡶࡸࠬང"): RzBbfLYvm4Fgja7GcwCHMnX0K = LyNiIHPOwD3hCUYEFM7(u"࠶ር")
		elif aatPRUBcJdKNrqSwMXTGjQCWg9==xpT28sXu051(u"ࠪࡉࡒࡇࡄࠡࡉࡤࡰࡱ࡫ࡲࡺࠩཅ"): RzBbfLYvm4Fgja7GcwCHMnX0K = JZszNnIEMAx28Yao0yqhiXGKOPb(u"࠸ሮ")
		gIV0YPXebBpfDG3MlzsNo5SjLk = aatPRUBcJdKNrqSwMXTGjQCWg9
	if   RzBbfLYvm4Fgja7GcwCHMnX0K==ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"࠰ሯ"): ltpnqIOsExaW4uw1cr = vODxLKW5Ql6r4Fbm8(u"ࠫ࠺࠻ࠬ࠶࠶࠷࠰࠺࠻࠵ࠨཆ")
	elif RzBbfLYvm4Fgja7GcwCHMnX0K==IpC4qHXRuyNFjzWv(u"࠲ሰ"): ltpnqIOsExaW4uw1cr = xpT28sXu051(u"ࠬ࠻࠴࠵࠮࠸࠹࠺࠲࠵࠶ࠩཇ")
	elif RzBbfLYvm4Fgja7GcwCHMnX0K==UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"࠴ሱ"): ltpnqIOsExaW4uw1cr = LyNiIHPOwD3hCUYEFM7(u"࠭࠵࠶࠷࠯࠹࠺࠲࠵࠵࠶ࠪ཈")
	else: return
	OXsckY7RzjCag9A.setSetting(y6y5HtgXO4TkUbwVZ(u"ࠧࡢࡸ࠱ࡱࡾࡹ࡫ࡪࡰ࠱ࡺ࡮࡫ࡷ࡮ࡱࡧࡩࠬཉ"),gIV0YPXebBpfDG3MlzsNo5SjLk)
	eAMqnRmXaxboQ89yHvKr7fPwSOY = PtkEvXAqif14G20QZsaSyT(u"ࠨ࠾ࡹ࡭ࡪࡽࡳ࠿ࠩཊ")+ltpnqIOsExaW4uw1cr+AbqCJZdWQP9j(u"ࠩ࠯ࠫཋ")+ppyvVonThaiuWjXAczPt7CBJ2+YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠪࡀ࠴ࡼࡩࡦࡹࡶࡂࠬཌ")
	kvysZqlKXSPC = dQ960sl5X13MFwW24jEtCBR.replace(iRLX0QKpNJFtV6axYWjfTZb,eAMqnRmXaxboQ89yHvKr7fPwSOY)
	if J1MoiYc7ZwzKS: kvysZqlKXSPC = kvysZqlKXSPC.encode(df6QpwGxuJVZr)
	open(IgAlzW7nP1NdyF,PtkEvXAqif14G20QZsaSyT(u"ࠫࡼࡨࠧཌྷ")).write(kvysZqlKXSPC)
	WKquk5EaNr4RzVf(q1rohYuwnfpVZUa98L2CtQzmAcB,GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠬ࠴࡜ࡵࡕ࡮࡭ࡳࠦࡄࡦࡨࡤࡹࡱࡺࠠࡗ࡫ࡨࡻࡸࡀࠠ࡜ࠢࠪཎ")+ltpnqIOsExaW4uw1cr+tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"࠭ࠠ࡞ࠩཏ"))
	if showDialogs: WwMgozBIC32n9d0tyfp.executebuiltin(tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠧࡓࡧ࡯ࡳࡦࡪࡓ࡬࡫ࡱࠬ࠮࠭ཐ"))
	return
def Ly4KftNcbFYJmszxwDE1edTn6oM():
	U17QqF2gkI46 = A1AXKupEOfz(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫད"),yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠩหี๋อๅอࠢ฼้ฬีࠠโ์๊ࠤฺ๊ใๅหࠣ฽๋ีใࠡ࠰࠱࠲ࠥหๅศࠢฦ่ส฻ฯศำࠣๆิ๐ๅࠡ࠰࠱࠲ࠥษ่ࠡษ้ฮ๋ࠥๅ็๊฼ࠤ๊์ࠠศีอาิอๅࠡษ็ฬึ์วๆฮࠣ࠲࠳࠴ࠠฤ๊่ࠣิ๐ใࠡ็ื็้ฯࠠฤะิํࠥะฮึࠢฯ๋ฬุใࠡล้ฮࠥ๎ไศࠢอาฺࠦศใ์ฬࠤำ๊โࠡษ็่์ࠦ࡜࡯࡞ࡱࠤาอ่ๅࠢอัิ๐หࠡษ็ฬึ์วๆฮࠣวํࠦวหื็ࠤออไๆสิ้ัࠦไๆ฻ิๅฮࠦำษสࠣห้๋ิไๆฬࠤ฾์ฯไࠢ࠱࠲࠳ࠦ็ๅࠢอี๏ีࠠโฯุࠤฬ๊สฮัํฯฬะࠠศๆล๊ࠥลࠧདྷ"))
	if U17QqF2gkI46==sVzojQerUqX(u"࠴ሲ"): XyGJzjM74bEVSxHv()
	return
def JJsf7Pon8TeLSV3MyuRpA21():
	bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,TlGXWLYsV1z(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ན"),TlGXWLYsV1z(u"ࠫ์ึวࠡษ็้ํู่ࠡ็฽่็ࠦๅ็ࠢส่๊฻ฯา๋ࠢ฾๏ืࠠๆ฻ิ์ๆࠦๅห์ࠣ๎ึาูࠡๆ็฽๊๊ࠧཔ"))
	return
def jhsqCSNvpoBF8LX3wG():
	ngZh3MbtFxsQAjGvyUJ67VN = aqEsMBckT2bunGHfl48Wip+tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠬะูะษาࠤู๐ูสࠢล่๋ࠥอๆัุ่ࠣ์ษࠡ࠴࠳࠶࠶ࠦ࠺ࠡࠩཕ")+YoQW601K4fMJcsreDnGVE5wUZIy7
	ngZh3MbtFxsQAjGvyUJ67VN += vODxLKW5Ql6r4Fbm8(u"࠭วๅ็๋ๆ฾ࠦระ่ส๋ࠥ็๊่ࠢศัฺอฦ๋ห่ࠣ฾ีฯࠡษ็ุ๏฿ษࠡใํࠤฬู๊ศๆ่ࠤฯ๋ࠠอ็฼๋ฬࠦๅ็ࠢฯ้๏฿ࠠศๆู่ฬีัࠡษ็้ฯ๎แาหࠣๅ๏ࠦวๅว้ฮึ์สࠡษ็ๆิ๐ๅส๋ࠢห้าฯ๋ัฬࠤฬ๊อไ๊่๎ฮ่ࠦศๆ฽๎ึࠦอไ๊่๎ฮ่ࠦๆ่ࠣะ๊๐ูࠡั๋่ࠥอไฺษ็้ࠥัๅࠡฬ่ࠤฯ๎อ๋ั๊หࠥ๎อิษหࠤฬ๊ๅฺั็ࠤาูศࠡีๆห๋ࠦฯ้ๆࠣห้฿วๅ็ุ่ࠣ์ษࠡ࠴࠳࠶࠶่่ࠦ์ࠣห้หอึษษ๎ฮࠦวๅละำะ่ࠦศๆฦุ๊๊ࠠศๆอ๎ࠥะๅࠡ฻่่์อࠠโ์ࠣหู้ๆ้ษอࠤฬู๊ีำฬࠤฬ๊ๅศุํอࠬབ")
	ngZh3MbtFxsQAjGvyUJ67VN += OTlVEGYPSxsNaBdXUucqA3+aqEsMBckT2bunGHfl48Wip+L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡶ࡬ࡲࡾ࠴ࡣࡤ࠱ࡶ࡬࡮ࡧࡣࡰࡷࡱࡸࠬབྷ")+YoQW601K4fMJcsreDnGVE5wUZIy7
	E8ZibMeyGK = aqEsMBckT2bunGHfl48Wip+ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠨสิ๊ฬ๋ฬࠡึิ๎฼ࠦวๅ็ึ่๊ࠦ࠺ࠡࠩམ")+YoQW601K4fMJcsreDnGVE5wUZIy7
	E8ZibMeyGK += JZszNnIEMAx28Yao0yqhiXGKOPb(u"๊ࠩ์ࠥ฿ศศำฬࠤ฾์ࠠษำ้ห๊า๋๊ࠠไีู๋ࠥๅ๊่หฯࠦอิษห๎ฮࠦใฬ์ิอࠥะ็ๆࠢฯ้๏฿ࠠศๆ่ื้๋๊็่ࠢฯ้ࠦร้ไสฮࠥอไึๆสอࠥ๎ร้ไสฮࠥอไไี๋ๅࠥ๎วๅะึ์ๆ่ࠦีๅ็ࠤฬ๊โๆำࠣ์ศ๎โศฬࠣห้่ๅา๋ࠢว๏฼วࠡ์๋ๅึࠦัล์ฬࠤฬ๊็ๅษ็ࠤๆ๐ࠠอ็ํ฽ࠥี่ๅࠢส่฾อไๆ๋ࠢว๏฼วࠡใํ๋ࠥะโ้์่ࠤ๊๐ไศัํࠤํํฬา์ࠣ์ๆ๐็ࠡลํฺฬࠦศฮอࠣ์็ืวยหࠣห้่ัร่ࠣ์ศ๐ึศࠢไ๎์ࠦวิฬัหึฯ้ࠠฬไหษ๊้ࠠใํ๋ࠥษโ้ษ็ࠤ๊์ำ้สฬࠤ้๊รๆษ่ࠤ฾๊๊๊ࠡฦ้ํืࠠฤะิํࠥะ็ๆࠢๆ่๋ࠥำๅ็ࠣ࠲ࠥอไษำ้ห๊าࠠๆๅอ์อࠦศๅ฼ฬࠤัอแศࠢึ็ึฮส๊ࠡํืฯิฯๆ้ࠢ฼ฬ๋้ࠠ์้ำํุࠠหฯอࠤอ๐ฦส๋ࠢ๎๋ี่ำࠢๆหั๐ส๊่ࠡาฺ฻ࠠโไฺࠤ้ษฬ่ิฬࠤฬ๊่๋่า์ืࠦ࠮ࠡษ็้ํู่ࠡษ็ีุ๋๊ࠡๆ็ฬึ์วๆฮ๋ࠣํ࠭ཙ")
	E8ZibMeyGK += OTlVEGYPSxsNaBdXUucqA3+aqEsMBckT2bunGHfl48Wip+sVzojQerUqX(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡹ࡯࡮ࡺ࠰ࡦࡧ࠴ࡳࡵࡴ࡮࡬ࡱࡷࡻ࡬ࡦࡴࠪཚ")+YoQW601K4fMJcsreDnGVE5wUZIy7
	aZtYlicqMKUFPkBCX2AONHwJ4 = LyNiIHPOwD3hCUYEFM7(u"ࠫࡠࡘࡔࡍ࡟ࠪཛ")+ngZh3MbtFxsQAjGvyUJ67VN+PtkEvXAqif14G20QZsaSyT(u"ࠬࡢ࡮࡝ࡰ࡟ࡲࡠࡘࡔࡍ࡟ࠪཛྷ")+E8ZibMeyGK
	ggULVKqsMZbc1ynfBC7(AbqCJZdWQP9j(u"࠭ࡲࡪࡩ࡫ࡸࠬཝ"),iiy37aKq0pCEIOwfcTh61xb4U,aZtYlicqMKUFPkBCX2AONHwJ4)
	return
def yyWPISuOFtKBUXq8GQDwkCjf5xos(iQ2tN1nLmJH7GCchv4u0VoSKlb):
	fNqmjxDcp1Q8tPsHiKhIg20au4FzAS(hI7SkXd94fFzAHNZCQoMqEutbnWP)
	ddxk8CzNrlhiJtSeTDLVEa0c = QeY9sWZqAhDomcd3rMIp(iQ2tN1nLmJH7GCchv4u0VoSKlb)
	for QihHpX3jKr in [SaB5hx3PZwXRLtKgrTfQvId(u"ࠧࡎࡇࡖࡗࡆࡍࡅࡔࠩཞ"),ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠨࡓࡘࡉࡘ࡚ࡉࡐࡐࡖࠫཟ"),GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠩࡐࡉࡘ࡙ࡁࡈࡇࡖࡣ࡙࡙ࠧའ"),MgP8OjoaiWQEVG59(u"ࠪࡕ࡚ࡋࡓࡕࡋࡒࡒࡘࡥࡔࡔࠩཡ")]:
		if QihHpX3jKr in RR80SbLUCimJrMV: RR80SbLUCimJrMV.remove(QihHpX3jKr)
	gE8olLZnXGx0NFrpQ4qvzhya67Djd(ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠫࡉࡕࡎࡂࡖࡌࡓࡓ࡙ࠧར"))
	id,BBWS6VTi15YeM2bvJGXtxpslDhg8,bl81eAwQG63tZjRhSzX0dCIv,OC9lxzDodrFpvn8X6kMebAfE1tKS,GNzbpq6tvX1kZjgixEmSn,reason = ddxk8CzNrlhiJtSeTDLVEa0c[FGTfwsjNrB8DvKSZhLIQAb1JnO]
	aRmuUoYczdTE4hbLO0JMqty,aS4kgtYoWwlFLs1m9 = OC9lxzDodrFpvn8X6kMebAfE1tKS.split(EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠬࡢ࡮࠼࠽ࠪལ"))
	E8ZibMeyGK,dANSkE5C2gKL4z7DTmuXBFR,ngWSHzwAk1r8oKB = GNzbpq6tvX1kZjgixEmSn.split(uuExaKGL7UONtevRd(u"࠭࡜࡯࠽࠾ࠫཤ"))
	uBD5S4sdvWOp0FynkZzU8xNI = rGPen6cSMHQkAywh8vqI9JXiD2
	while uBD5S4sdvWOp0FynkZzU8xNI:
		NszFydaDbgVM = Ny92sqomMkizpgKV1(iiy37aKq0pCEIOwfcTh61xb4U,LyNiIHPOwD3hCUYEFM7(u"ࠧฯำ๋ะࠬཥ"),hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠨวิืฬ๊ࠠาีส่ฮࠦไๅ็หี๊าࠧས"),GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠩๅหห๋ษࠡษ็ฮอืูศฬࠪཧ"),jXE2YHkswT8y(u"่ࠪส๐โศใࠣห้หูๅษ้หฯࠦ࠺ࠡࠢอฬึ฿ࠠฤ๊ࠣหู๊อࠡษ็ฬึ์วๆฮࠪཨ"),E8ZibMeyGK)
		if NszFydaDbgVM==xpT28sXu051(u"࠶ሳ"): NWnlyksQJwBexSHi0CUtr6FqTpm = Ny92sqomMkizpgKV1(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,SaB5hx3PZwXRLtKgrTfQvId(u"ࠫ฾๎ฯสࠩཀྵ"),iiy37aKq0pCEIOwfcTh61xb4U,HtK4o2sTPgA78U(u"๋ࠬศะลࠣห้ะศา฻ࠣ฾๏ืࠠใษห่๊ࠥไ็ไสุࠬཪ"),dANSkE5C2gKL4z7DTmuXBFR,EMO8gy4LrsNTh0knZwpSeU75APW(u"࠭ࡣࡰࡰࡩ࡭ࡷࡳ࡟ࡴ࡯ࡤࡰࡱ࡬࡯࡯ࡶࠪཫ"))
		elif NszFydaDbgVM==PtkEvXAqif14G20QZsaSyT(u"࠶ሴ"): fmS1GJHNpqKyxE7u5bA()
		else: uBD5S4sdvWOp0FynkZzU8xNI = BF6QAiLUNHh7rKOugaw
	if iQ2tN1nLmJH7GCchv4u0VoSKlb: SqMHwb6X1Ph8jY7LBNkmtV4F5Jlspy(BF6QAiLUNHh7rKOugaw)
	return
def Cl6JEfTgOKmi5ASVLy(showDialogs):
	U17QqF2gkI46 = rGPen6cSMHQkAywh8vqI9JXiD2
	if showDialogs: U17QqF2gkI46 = A1AXKupEOfz(y6y5HtgXO4TkUbwVZ(u"ࠧࡤࡧࡱࡸࡪࡸࠧཬ"),iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠨีวห้࠭཭"),JZszNnIEMAx28Yao0yqhiXGKOPb(u"๊่ࠩࠥษๆห่ࠢฮศ้ฯ๊ࠡอี๏ีࠠๆีะࠤํะีโ์ิࠤัฺ๋๊ࠢศ฽ิอฯศฬࠣฬึ์วๆฮࠣ฽๊อฯࠡๆ็ๅ๏ี๊้้สฮࠥอไฺำห๎ฮࠦ࠮ࠡฯํฯࠥะู้ัࠣะ๊๐ูࠡษ็ษ฾ีวะษอࠤสู๊้๊ࠡ฽๏ฯࠠหอห๎ฯࠦวๅสิ๊ฬ๋ฬࠡมࠪ཮"))
	if U17QqF2gkI46:
		M5qyIg2dZlm6FxH4tTPV79okNu0bCG = rGPen6cSMHQkAywh8vqI9JXiD2
		if wkMR5x1gTWEQIc6qHCa.path.exists(yO6VIi1bo5):
			try: wkMR5x1gTWEQIc6qHCa.remove(yO6VIi1bo5)
			except: M5qyIg2dZlm6FxH4tTPV79okNu0bCG = BF6QAiLUNHh7rKOugaw
		if showDialogs:
			if M5qyIg2dZlm6FxH4tTPV79okNu0bCG: bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,y6y5HtgXO4TkUbwVZ(u"ࠪฮ๊ࠦศ็ฮสั๋ࠥำฮ๋ࠢฮฺ็๊า่่ࠢๆࠦลฺัสำฬะࠠษำ้ห๊าฺࠠ็สำ๊ࠥไโ์า๎ํํวหࠢส่฾ืศ๋หࠪ཯"))
			else: bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,GGx4qyKP1vUtRghsE2WfaHLMXZ(u"้๊ࠫริใࠣๅู๊สࠡ฻่่๏ฯࠠๆีะࠤ๊๊แࠡษ็ษ฾ีวะษอࠫ཰"))
	return
def oAjUTPLHF4ztnSwr1d2vEgJmDpcI7l():
	KKDcbX7IGg1Y()
	MpS96gZW7YqzOLH = OXsckY7RzjCag9A.getSetting(IpC4qHXRuyNFjzWv(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡪࡷࡸࡵࡩࡡࡤࡪࡨཱࠫ"))
	aZtYlicqMKUFPkBCX2AONHwJ4 = {}
	aZtYlicqMKUFPkBCX2AONHwJ4[xpT28sXu051(u"࠭ࡁࡖࡖࡒིࠫ")] = PtkEvXAqif14G20QZsaSyT(u"ࠧศๆๆหูࠦวๅฬ็ๆฬฬ๊ࠡ์฼้้ཱི࠭")
	aZtYlicqMKUFPkBCX2AONHwJ4[ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠨࡕࡗࡓࡕུ࠭")] = YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠩส่่อิࠡ็อ์็็ࠠห็ส้ฬ่ࠦษษ็็ฬ๋ไࠨཱུ")
	aZtYlicqMKUFPkBCX2AONHwJ4[uuExaKGL7UONtevRd(u"ࠪࡐࡎࡓࡉࡕࡇࡇࠫྲྀ")] = JZszNnIEMAx28Yao0yqhiXGKOPb(u"่ࠫอิࠡฮาห่ࠥี๋ำࠣห้๋ฯ๊ࠢ࠱ࠤࠬཷ")+str(FvL8I2f4EX/ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"࠼࠰ስ"))+y6y5HtgXO4TkUbwVZ(u"ࠬࠦฯใ์ๅอࠥ็โุࠩླྀ")
	uuT69PRM5frd = aZtYlicqMKUFPkBCX2AONHwJ4[MpS96gZW7YqzOLH]
	RzBbfLYvm4Fgja7GcwCHMnX0K = Ny92sqomMkizpgKV1(iiy37aKq0pCEIOwfcTh61xb4U,zmcGfOdvAjsELeJlP(u"࠭ใศึࠣࠫཹ")+str(FvL8I2f4EX/Y41NvKfOroMzGB8sEHy7wbXlc5(u"࠶࠱ሶ"))+ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠧࠡัๅ๎็ฯེࠧ"),sVzojQerUqX(u"ࠨฬื฾๏๊ࠠหๆๅหห๐ཻࠧ"),AbqCJZdWQP9j(u"ࠩศ๎็อแࠡๅส้้ོ࠭"),uuT69PRM5frd,zmcGfOdvAjsELeJlP(u"๋้ࠪࠦสา์าࠤฬูสฯัส้ࠥอไไษืࠤฬ๊ะไ์ࠣห้ะไใษษ๎ࠥษๅࠡฬิ๎ิࠦล๋ไสๅࠥอไไษืࠤออไไษ่่ࠥษๅࠡฬิ๎ิࠦใศึࠣ฽๊ื็ࠡไุ๎ึࠦฬะษࠣรཽࠦ࠭"))
	if RzBbfLYvm4Fgja7GcwCHMnX0K==UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"࠱ሷ"): BpzVKCXx8k9q = ZchUJdM93pTA7zG5(u"ࠫࡑࡏࡍࡊࡖࡈࡈࠬཾ")
	elif RzBbfLYvm4Fgja7GcwCHMnX0K==YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"࠳ሸ"): BpzVKCXx8k9q = IpC4qHXRuyNFjzWv(u"ࠬࡇࡕࡕࡑࠪཿ")
	elif RzBbfLYvm4Fgja7GcwCHMnX0K==UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"࠵ሹ"): BpzVKCXx8k9q = jXE2YHkswT8y(u"࠭ࡓࡕࡑࡓྀࠫ")
	else: BpzVKCXx8k9q = iiy37aKq0pCEIOwfcTh61xb4U
	if BpzVKCXx8k9q:
		OXsckY7RzjCag9A.setSetting(ZchUJdM93pTA7zG5(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱࡬ࡹࡺࡰࡤࡣࡦ࡬ࡪཱྀ࠭"),BpzVKCXx8k9q)
		GchlMatQeS6msdZog8zqbYj2 = aZtYlicqMKUFPkBCX2AONHwJ4[BpzVKCXx8k9q]
		bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,GchlMatQeS6msdZog8zqbYj2)
	return
def Cm71hr2u5PH4YaoTLW():
	aZtYlicqMKUFPkBCX2AONHwJ4 = {}
	aZtYlicqMKUFPkBCX2AONHwJ4[MgP8OjoaiWQEVG59(u"ࠨࡃࡘࡘࡔ࠭ྂ")] = HtK4o2sTPgA78U(u"ࠩึ๎ึ็ัࠡࡆࡑࡗࠥอไหๆๅหห๐๋ࠠ฻่่࠿ࠦࠧྃ")
	aZtYlicqMKUFPkBCX2AONHwJ4[EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠪࡅࡘࡑ྄ࠧ")] = vODxLKW5Ql6r4Fbm8(u"ุࠫ๐ัโำࠣࡈࡓ࡙ࠠิ์฼้้ࠦศฺัࠣหู้ๅศฯ่ࠣ์ࡀࠠࠨ྅")
	aZtYlicqMKUFPkBCX2AONHwJ4[uuExaKGL7UONtevRd(u"࡙ࠬࡔࡐࡒࠪ྆")] = CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"࠭ำ๋ำไีࠥࡊࡎࡔ่ࠢฮํ่แࠡฬ่ห๊อ้ࠠสส่่อๅๅࠩ྇")
	pS0jG1UJfVW56FQutY2om = OXsckY7RzjCag9A.getSetting(IpC4qHXRuyNFjzWv(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡨࡳࡹࠧྈ"))
	MpS96gZW7YqzOLH = OXsckY7RzjCag9A.getSetting(PtkEvXAqif14G20QZsaSyT(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡺࡹࡥࡥࡰࡶࠫྉ"))
	uuT69PRM5frd = aZtYlicqMKUFPkBCX2AONHwJ4[MpS96gZW7YqzOLH]+pS0jG1UJfVW56FQutY2om
	RzBbfLYvm4Fgja7GcwCHMnX0K = Ny92sqomMkizpgKV1(iiy37aKq0pCEIOwfcTh61xb4U,SaB5hx3PZwXRLtKgrTfQvId(u"ࠩอุ฿๐ไࠡ฻้ำࠥอไๆ๊สๅ็ฯࠧྊ"),vODxLKW5Ql6r4Fbm8(u"ࠪฮูเ๊ๅࠢอ่็อฦ๋ࠩྋ"),SaB5hx3PZwXRLtKgrTfQvId(u"ࠫส๐โศใࠣ็ฬ๋ไࠨྌ"),uuT69PRM5frd,zmcGfOdvAjsELeJlP(u"ู๊ࠬาใิࠤࡉࡔࡓ้๋ࠡࠤัํวำࠢไ๎ࠥอไฦ่อี๋๐สࠡ์ๅ์๊ࠦศหฯ๋๎้ࠦริ็สลࠥอไๆ๊สๆ฾่ࠦศๆึ๎ึ็ัศฬࠣษ้๏ࠠฤำๅหฺ๊่่ࠦาࠤอ฿ึࠡษ็๊ฬู๋ࠠไ๋้ࠥฮออสࠣ์๊์ู๊ࠡะฺึࠦศฺุࠣห้๋่ศไ฼ࠤ࠳ࠦไหึ฽๎้ࠦำ๋ำไีࠥࡊࡎࡔࠢๅ้ࠥฮวฯฬํหึࠦวๅีํีๆืࠠศๆ่๊ฬูศࠡล๋ࠤ็๋ࠠษวํๆฬ็็ࠡสส่่อๅๅࠩྍ"))
	if RzBbfLYvm4Fgja7GcwCHMnX0K==vODxLKW5Ql6r4Fbm8(u"࠴ሺ"): BpzVKCXx8k9q = vODxLKW5Ql6r4Fbm8(u"࠭ࡁࡔࡍࠪྎ")
	elif RzBbfLYvm4Fgja7GcwCHMnX0K==tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"࠶ሻ"): BpzVKCXx8k9q = y6y5HtgXO4TkUbwVZ(u"ࠧࡂࡗࡗࡓࠬྏ")
	elif RzBbfLYvm4Fgja7GcwCHMnX0K==y6y5HtgXO4TkUbwVZ(u"࠸ሼ"): BpzVKCXx8k9q = y6y5HtgXO4TkUbwVZ(u"ࠨࡕࡗࡓࡕ࠭ྐ")
	if RzBbfLYvm4Fgja7GcwCHMnX0K in [LyNiIHPOwD3hCUYEFM7(u"࠱ሾ"),JZszNnIEMAx28Yao0yqhiXGKOPb(u"࠱ሽ")]:
		U17QqF2gkI46 = A1AXKupEOfz(hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠩࡦࡩࡳࡺࡥࡳࠩྑ"),LyNiIHPOwD3hCUYEFM7(u"ࠪื๏ืแา࠼ࠣࠫྒ")+cl6fApKxQTzywM27g[YYJQyRskpX8jv],Y41NvKfOroMzGB8sEHy7wbXlc5(u"ุࠫ๐ัโำ࠽ࠤࠬྒྷ")+cl6fApKxQTzywM27g[FGTfwsjNrB8DvKSZhLIQAb1JnO],iiy37aKq0pCEIOwfcTh61xb4U,JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠬษฮหษิࠤุ๐ัโำࠣࡈࡓ࡙ࠠศๆ่๊ฬูศࠡๆๆࠫྔ"))
		if U17QqF2gkI46==sVzojQerUqX(u"࠳ሿ"): WQ91kEDxupH0y6RBzt4MPh = cl6fApKxQTzywM27g[FGTfwsjNrB8DvKSZhLIQAb1JnO]
		else: WQ91kEDxupH0y6RBzt4MPh = cl6fApKxQTzywM27g[YYJQyRskpX8jv]
	elif RzBbfLYvm4Fgja7GcwCHMnX0K==MgP8OjoaiWQEVG59(u"࠵ቀ"): WQ91kEDxupH0y6RBzt4MPh = iiy37aKq0pCEIOwfcTh61xb4U
	else: BpzVKCXx8k9q = iiy37aKq0pCEIOwfcTh61xb4U
	if BpzVKCXx8k9q:
		OXsckY7RzjCag9A.setSetting(L90uqo28xEKSFUwYTcm51yRWZIkft(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡸࡷࡪࡪ࡮ࡴࠩྕ"),BpzVKCXx8k9q)
		OXsckY7RzjCag9A.setSetting(L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡨࡳࡹࠧྖ"),WQ91kEDxupH0y6RBzt4MPh)
		GchlMatQeS6msdZog8zqbYj2 = aZtYlicqMKUFPkBCX2AONHwJ4[BpzVKCXx8k9q]+WQ91kEDxupH0y6RBzt4MPh
		bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,GchlMatQeS6msdZog8zqbYj2)
	return
def fHhZArdP16tcMkCD():
	MpS96gZW7YqzOLH = OXsckY7RzjCag9A.getSetting(ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡺࡹࡥࡱࡴࡲࡼࡾ࠭ྗ"))
	aZtYlicqMKUFPkBCX2AONHwJ4 = {}
	aZtYlicqMKUFPkBCX2AONHwJ4[HtK4o2sTPgA78U(u"ࠩࡄ࡙࡙ࡕࠧ྘")] = JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠪห้ฮั้ๅึ๎ࠥอไหๆๅหห๐ࠠอษ๊ึ๊ࠥไฺ็็ࠫྙ")
	aZtYlicqMKUFPkBCX2AONHwJ4[zmcGfOdvAjsELeJlP(u"ࠫࡆ࡙ࡋࠨྚ")] = IpC4qHXRuyNFjzWv(u"ࠬอไษำ๋็ุ๐ࠠิ์฼้้ࠦศฺัࠣหู้ๅศฯ่ࠣ์࠭ྛ")
	aZtYlicqMKUFPkBCX2AONHwJ4[y6y5HtgXO4TkUbwVZ(u"࠭ࡓࡕࡑࡓࠫྜ")] = y6y5HtgXO4TkUbwVZ(u"ࠧศๆหีํ้ำ๋่ࠢฮํ่แࠡฬ่ห๊อ้ࠠสส่่อๅๅࠩྜྷ")
	uuT69PRM5frd = aZtYlicqMKUFPkBCX2AONHwJ4[MpS96gZW7YqzOLH]
	RzBbfLYvm4Fgja7GcwCHMnX0K = Ny92sqomMkizpgKV1(iiy37aKq0pCEIOwfcTh61xb4U,HtK4o2sTPgA78U(u"ࠨฬื฾๏ฺ๊่ࠠาࠤฬ๊ๅ้ษไๆฮ࠭ྞ"),jXE2YHkswT8y(u"ࠩอุ฿๐ไࠡฬ็ๆฬฬ๊ࠨྟ"),MgP8OjoaiWQEVG59(u"ࠪษ๏่วโࠢๆห๊๊ࠧྠ"),uuT69PRM5frd,PtkEvXAqif14G20QZsaSyT(u"ࠫฬ๊ศา๊ๆื๏ࠦ็้ࠢฯ๋ฬุࠠโ์ࠣห้หๆหำ้๎ฯฺ๊ࠦ็็ࠤํูุ๊ࠢห๎๋ࠦฬ่ษี็ࠥ๎วๅว้ฮึ์๊หࠢ࠱ࠤ์๎๋ࠠีอ่๊ࠦืๅสสฮ่่๋ࠦไ๋้ࠥฮำฮส๊หࠥฮฯๅษ้๋้ࠣࠠฬ็ࠣ๎อ฿ห่ษ่่ࠣࠦ࠮้ࠡ็ࠤฯื๊ะࠢอุ฿๐ไࠡล่ࠤส๐โศใࠣห้ฮั้ๅึ๎ࠥลࠧྡ"))
	if RzBbfLYvm4Fgja7GcwCHMnX0K==TlGXWLYsV1z(u"࠴ቁ"): BpzVKCXx8k9q = ZchUJdM93pTA7zG5(u"ࠬࡇࡓࡌࠩྡྷ")
	elif RzBbfLYvm4Fgja7GcwCHMnX0K==hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"࠶ቂ"): BpzVKCXx8k9q = EMO8gy4LrsNTh0knZwpSeU75APW(u"࠭ࡁࡖࡖࡒࠫྣ")
	elif RzBbfLYvm4Fgja7GcwCHMnX0K==hhQwbeiNLoqFjX90fB7aG8VAs(u"࠸ቃ"): BpzVKCXx8k9q = sVzojQerUqX(u"ࠧࡔࡖࡒࡔࠬྤ")
	else: BpzVKCXx8k9q = iiy37aKq0pCEIOwfcTh61xb4U
	if BpzVKCXx8k9q:
		OXsckY7RzjCag9A.setSetting(tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡺࡹࡥࡱࡴࡲࡼࡾ࠭ྥ"),BpzVKCXx8k9q)
		GchlMatQeS6msdZog8zqbYj2 = aZtYlicqMKUFPkBCX2AONHwJ4[BpzVKCXx8k9q]
		bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,GchlMatQeS6msdZog8zqbYj2)
	return
def mSlsn8a4QFJM():
	FZl8t1uPx3yszXYoe5CJ9GnfQ6TvB = OXsckY7RzjCag9A.getSetting(ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡳࡥ࡯ࡷࡶࡧࡦࡩࡨࡦࠩྦ"))
	if FZl8t1uPx3yszXYoe5CJ9GnfQ6TvB==tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠪࡗ࡙ࡕࡐࠨྦྷ"): header = TlGXWLYsV1z(u"ࠫฯิา๋่ࠣห้่่ศศ่ࠤ๊ะ่ใใࠪྨ")
	else: header = jXE2YHkswT8y(u"ࠬะฮำ์้ࠤฬ๊โ้ษษ้๋ࠥแฺๆࠪྩ")
	U17QqF2gkI46 = A1AXKupEOfz(iiy37aKq0pCEIOwfcTh61xb4U,SaB5hx3PZwXRLtKgrTfQvId(u"࠭ล๋ไสๅࠬྪ"),Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠧหใ฼๎้࠭ྫ"),header,AbqCJZdWQP9j(u"ࠨไ๋หห๋ࠠศๆหี๋อๅอࠢํฮ๊ࠦสฮัํฯ์อࠠฤ๊อ์๊อส๋ๅํหࠥฮูะࠢ࠴࠺ูࠥวฺห้๋ࠣࠦร้ๆࠣวุะฮะษ่ࠤ࠳࠴้ࠠวํๆฬ็ࠠหะี๎๋ࠦวๅไ๋หห๋๋ࠠฦา๎ࠥหไ๊ࠢอัิ๐ห่ษࠣๅ๏ࠦใๅ่ࠢีฮ๊ࠦห็ࠣหุะฮะษ่ࠤฬ๊โ้ษษ้ࠥ࠴࠮๊๊ࠡิฬ๊ࠦิสหࠤอ฽ฦࠡใํࠤๆะอࠡไ๋หห๋ࠠศๆหี๋อๅอ࡞ࡱࡠࡳࠦ็ๅࠢอี๏ีࠠหใ฼๎้ࠦรๆࠢศ๎็อแࠡฬัึ๏์ࠠศๆๅ์ฬฬๅࠡมࠤࠥࠬྫྷ"))
	if U17QqF2gkI46==-ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"࠱ቄ"): return
	elif U17QqF2gkI46:
		OXsckY7RzjCag9A.setSetting(LyNiIHPOwD3hCUYEFM7(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡳࡥ࡯ࡷࡶࡧࡦࡩࡨࡦࠩྭ"),PtkEvXAqif14G20QZsaSyT(u"ࠪࡅ࡚࡚ࡏࠨྮ"))
		bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧྯ"),ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠬะๅࠡฬไ฽๏๊ࠠหะี๎๋ࠦวๅไ๋หห๋ࠧྰ"))
	else:
		OXsckY7RzjCag9A.setSetting(vODxLKW5Ql6r4Fbm8(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡰࡩࡳࡻࡳࡤࡣࡦ࡬ࡪ࠭ྱ"),JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠧࡔࡖࡒࡔࠬྲ"))
		bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,y6y5HtgXO4TkUbwVZ(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫླ"),IpC4qHXRuyNFjzWv(u"ࠩอ้ࠥห๊ใษไࠤฯิา๋่ࠣห้่่ศศ่ࠫྴ"))
	return
def VAIDB3hNwiYHW(U94JwhRgpXCOe5):
	if U94JwhRgpXCOe5!=iiy37aKq0pCEIOwfcTh61xb4U:
		U94JwhRgpXCOe5 = gcN78Bi6TD1QZsyR(U94JwhRgpXCOe5)
		U94JwhRgpXCOe5 = U94JwhRgpXCOe5.decode(df6QpwGxuJVZr).encode(df6QpwGxuJVZr)
		hhXo0bDTcWEa8N1fB6Vl = JZszNnIEMAx28Yao0yqhiXGKOPb(u"࠲࠲࠴࠴࠸ቅ")
		ji4voyIO8bYap = OOYtyXB3o8K.Window(hhXo0bDTcWEa8N1fB6Vl)
		ji4voyIO8bYap.getControl(CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"࠵࠴࠵ቆ")).setLabel(U94JwhRgpXCOe5)
	return
lteHoiVygwY = [
			 jXE2YHkswT8y(u"ࠥࡩࡽࡺࡥ࡯ࡵ࡬ࡳࡳࠦࡡࡷࡵࡳࡥࡨ࡫ࡳ࠱ࠢ࡬ࡷࠥࡴ࡯ࡵࠢࡦࡹࡷࡸࡥ࡯ࡶ࡯ࡽࠥࡹࡵࡱࡲࡲࡶࡹ࡫ࡤࠣྵ")
			,TlGXWLYsV1z(u"ࠫࡈ࡮ࡥࡤ࡭࡬ࡲ࡬ࠦࡦࡰࡴࠣࡑࡦࡲࡩࡤ࡫ࡲࡹࡸࠦࡳࡤࡴ࡬ࡴࡹࡹࠧྶ")
			,hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠬࡖࡖࡓࠢࡌࡔ࡙࡜ࠠࡔ࡫ࡰࡴࡱ࡫ࠠࡄ࡮࡬ࡩࡳࡺࠧྷ")
			,yJeq1BjfiO4NFuwIEzxVLK6b9s(u"࠭ࡕ࡯࡭ࡱࡳࡼࡴࠠࡗ࡫ࡧࡩࡴࠦࡉ࡯ࡨࡲࠤࡐ࡫ࡹࠨྸ")
			,PtkEvXAqif14G20QZsaSyT(u"ࠧࡵࡪ࡬ࡷࠥ࡮ࡡࡴࡪࠣࡪࡺࡴࡣࡵ࡫ࡲࡲࠥ࡯ࡳࠡࡤࡵࡳࡰ࡫࡮ࠨྐྵ")
			,zmcGfOdvAjsELeJlP(u"ࠨࡷࡶࡩࡸࠦࡰ࡭ࡣ࡬ࡲࠥࡎࡔࡕࡒࠣࡪࡴࡸࠠࡢࡦࡧ࠱ࡴࡴࠠࡥࡱࡺࡲࡱࡵࡡࡥࡵࠪྺ")
			,AbqCJZdWQP9j(u"ࠩࡤࡨࡻࡧ࡮ࡤࡧࡧ࠱ࡺࡹࡡࡨࡧ࠱࡬ࡹࡳ࡬ࠨྻ")+PtkEvXAqif14G20QZsaSyT(u"ࠪࠧࠬྼ")+CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠫࡸࡹ࡬࠮ࡹࡤࡶࡳ࡯࡮ࡨࡵࠪ྽")
			,sVzojQerUqX(u"ࠬࡏ࡮ࡴࡧࡦࡹࡷ࡫ࡒࡦࡳࡸࡩࡸࡺࡗࡢࡴࡱ࡭ࡳ࡭ࠬࠨ྾")
			,hhQwbeiNLoqFjX90fB7aG8VAs(u"࠭ࡅࡳࡴࡲࡶࠥ࡭ࡥࡵࡶ࡬ࡲ࡬ࠦࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊ࠯ࡀ࡯ࡲࡨࡪ࡫࠽࠱ࠨࡷࡩࡽࡺࡴ࠾ࠩ྿")
			,JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠧࡸࡣࡵࡲ࡮ࡴࡧࡴ࠰ࡺࡥࡷࡴࠨࠨ࿀")
			,PtkEvXAqif14G20QZsaSyT(u"ࠨࡠࡡࡢࡣࡤࠧ࿁")
			,FRYcH4KL7e9gv5pEB(u"ࠩࡏࡳࡦࡪࡩ࡯ࡩࠣࡷࡰ࡯࡮ࠡࡨ࡬ࡰࡪࡀࠧ࿂")
			]
def RReQn8vY9d1WVakx0gN(FHgYoph3Crdti1vBMqTJ82WO):
	if hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠪࡐࡴࡧࡤࡪࡰࡪࠤࡸࡱࡩ࡯ࠢࡩ࡭ࡱ࡫࠺ࠨ࿃") in FHgYoph3Crdti1vBMqTJ82WO and uuExaKGL7UONtevRd(u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩ࿄") in FHgYoph3Crdti1vBMqTJ82WO: return rGPen6cSMHQkAywh8vqI9JXiD2
	for U94JwhRgpXCOe5 in lteHoiVygwY:
		if U94JwhRgpXCOe5 in FHgYoph3Crdti1vBMqTJ82WO: return rGPen6cSMHQkAywh8vqI9JXiD2
	return BF6QAiLUNHh7rKOugaw
def uNThYr7JM80cbikw(data):
	tbGlrZhILkypxqiw1TCjVO = hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"࠻ቈ") if J1MoiYc7ZwzKS else tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"࠴࠹ቇ")
	data = data.replace(GGx4qyKP1vUtRghsE2WfaHLMXZ(u"࠸࠶቉")*iFBmE2MUIpSu34wsd7Rf6z,tbGlrZhILkypxqiw1TCjVO*iFBmE2MUIpSu34wsd7Rf6z)
	data = data.replace(YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠬࠦ࠼ࡨࡧࡱࡩࡷࡧ࡬࠿࠼ࠣࠫ࿅"),UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"࠭࠺࿆ࠡࠩ"))
	EwsmJ67cCYDIlg = iiy37aKq0pCEIOwfcTh61xb4U
	for FHgYoph3Crdti1vBMqTJ82WO in data.splitlines():
		fwzulK4roX3tcZ7J2Fxbh = dEyT9xhGjolYzLCH7460w3.findall(CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠧࠡࠢࠣࠤࠥࡌࡩ࡭ࡧࠣࠦ࠭࠴ࠪࡀࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠴ࠩࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭࿇"),FHgYoph3Crdti1vBMqTJ82WO,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if fwzulK4roX3tcZ7J2Fxbh: FHgYoph3Crdti1vBMqTJ82WO = FHgYoph3Crdti1vBMqTJ82WO.replace(fwzulK4roX3tcZ7J2Fxbh[FGTfwsjNrB8DvKSZhLIQAb1JnO],iiy37aKq0pCEIOwfcTh61xb4U)
		EwsmJ67cCYDIlg += OTlVEGYPSxsNaBdXUucqA3+FHgYoph3Crdti1vBMqTJ82WO
	return EwsmJ67cCYDIlg
def Vo9J52sOIeCaP(rTbdAJlYapoe0n8mMEFx):
	if CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠨࡑࡏࡈࠬ࿈") in rTbdAJlYapoe0n8mMEFx:
		hNLOvuk3Yg76GQPX2Fxr01MWbUH = fftaeIcglCErxBsY3ORFh
		header = ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠩๅีฬวษࠡษ็ืั๊ࠠศๆๅำ๏๋ࠠภࠩ࿉")
	else:
		hNLOvuk3Yg76GQPX2Fxr01MWbUH = Ct1U8Ao9wucR
		header = ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠪๆึอมสࠢสุ่าไࠡษ็ัฬ๊๊ࠡมࠪ࿊")
	U17QqF2gkI46 = A1AXKupEOfz(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,header,MgP8OjoaiWQEVG59(u"ุࠫาไࠡษ็วำ฽วยࠢํัฯ๎๊ࠡลํฺฬูࠦๅ๋ࠣืั๊ࠠศๆสืฯิฯศ็ࠣ࠲ࠥ๎วๅษฮ๊๏์ࠠืำ๋ี๏ฯࠠๅ็฼ีๆฯࠠไ์ไࠤาีหหࠢสฺ่๊ใๅหࠣ์๊อ่๊ࠠࠣห้๋ใศ่ࠣห้ึ๊ࠡีหฬࠥำฯ้อࠣห้๋ิไๆฬࠤ࠳ࠦใ้ัํࠤ๏ำสโฺࠣฬุาไ๋่ࠣ࠲ࠥอไฤ๊็ࠤ์๎ࠠศๆึะ้ࠦวๅฯส่๏่ࠦโ์๊ࠤ๊฿ไ้็สฮࠥะศะล้๋ࠣึࠠษัส๎ฮࠦวๅฬื฾๏๊ࠠศๆะห้๐ࠠๅสิ๊ฬ๋ฬࠡๅ๋ำ๏่ࠦศๆ์ࠤฬ๊ย็ࠢ࠱ࠤศ๋วࠡษ็ืั๊ࠠศๆๅำ๏๋ࠠโ้๋ࠤฬ๊ำอๆࠣหู้วษไࠣห้ึ๊ࠡฬ่ࠤัู๋่่๊ࠢࠥฮั็ษ่ะ้่ࠥะ์ࠣๆอ๊ࠠระิࠤส฽แศร่ࠣ์ࠦ࠮้ࠡ็ࠤฯื๊ะࠢส่ฬูสๆำสีࠥลࠧ࿋"))
	if U17QqF2gkI46!=PtkEvXAqif14G20QZsaSyT(u"࠷ቊ"): return
	m7m0InQTWGjuSeRx,d95dmOUNYHZsquy = [],ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"࠰ቋ")
	size,count = MZ0QpfA1jaJgoWO2IndU(hNLOvuk3Yg76GQPX2Fxr01MWbUH)
	file = open(hNLOvuk3Yg76GQPX2Fxr01MWbUH,ZchUJdM93pTA7zG5(u"ࠬࡸࡢࠨ࿌"))
	if size>hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"࠳࠳࠴࠷࠶࠰ቍ"): file.seek(-XrTw01KtLzbpoyMf(u"࠲࠲࠳࠵࠵࠶ቌ"),wkMR5x1gTWEQIc6qHCa.SEEK_END)
	data = file.read()
	file.close()
	if J1MoiYc7ZwzKS: data = data.decode(df6QpwGxuJVZr)
	data = uNThYr7JM80cbikw(data)
	Wbe8jlJaNdroOHgpm = data.split(OTlVEGYPSxsNaBdXUucqA3)
	for FHgYoph3Crdti1vBMqTJ82WO in reversed(Wbe8jlJaNdroOHgpm):
		AHoXV2C4x9yzEShsdGI8w = RReQn8vY9d1WVakx0gN(FHgYoph3Crdti1vBMqTJ82WO)
		if AHoXV2C4x9yzEShsdGI8w: continue
		FHgYoph3Crdti1vBMqTJ82WO = FHgYoph3Crdti1vBMqTJ82WO.replace(L90uqo28xEKSFUwYTcm51yRWZIkft(u"࠭࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࡟ࠨ࿍"),aqEsMBckT2bunGHfl48Wip+IpC4qHXRuyNFjzWv(u"ࠧࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࠪ࿎")+YoQW601K4fMJcsreDnGVE5wUZIy7)
		FHgYoph3Crdti1vBMqTJ82WO = FHgYoph3Crdti1vBMqTJ82WO.replace(UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠨࡇࡕࡖࡔࡘ࠺ࠨ࿏"),AbqCJZdWQP9j(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌ࠰࠱࠲࠳ࡡࠬ࿐")+TlGXWLYsV1z(u"ࠪࡉࡗࡘࡏࡓ࠼ࠪ࿑")+YoQW601K4fMJcsreDnGVE5wUZIy7)
		xBfu3gkYoSDwm4na = iiy37aKq0pCEIOwfcTh61xb4U
		Z1hqbuQVesfpHBo98OlNLSPc3M5va = dEyT9xhGjolYzLCH7460w3.findall(TlGXWLYsV1z(u"ࠫࡣ࠮࡜ࡥ࠭࠰ࠬࡡࡪࠫ࠮࡞ࡧ࠯ࠥࡢࡤࠬ࠼࡟ࡨ࠰ࡀ࡜ࡥ࠭࡟࠲ࡡࡪࠫࠪࠫࠫࠤ࡙ࡀ࡜ࡥ࠭ࠬࠫ࿒"),FHgYoph3Crdti1vBMqTJ82WO,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if Z1hqbuQVesfpHBo98OlNLSPc3M5va:
			FHgYoph3Crdti1vBMqTJ82WO = FHgYoph3Crdti1vBMqTJ82WO.replace(Z1hqbuQVesfpHBo98OlNLSPc3M5va[FGTfwsjNrB8DvKSZhLIQAb1JnO][FGTfwsjNrB8DvKSZhLIQAb1JnO],Z1hqbuQVesfpHBo98OlNLSPc3M5va[FGTfwsjNrB8DvKSZhLIQAb1JnO][YYJQyRskpX8jv]).replace(Z1hqbuQVesfpHBo98OlNLSPc3M5va[FGTfwsjNrB8DvKSZhLIQAb1JnO][nI2JK1RfsGWNY3OarEeMQZ],iiy37aKq0pCEIOwfcTh61xb4U)
			xBfu3gkYoSDwm4na = Z1hqbuQVesfpHBo98OlNLSPc3M5va[FGTfwsjNrB8DvKSZhLIQAb1JnO][YYJQyRskpX8jv]
		else:
			Z1hqbuQVesfpHBo98OlNLSPc3M5va = dEyT9xhGjolYzLCH7460w3.findall(y6y5HtgXO4TkUbwVZ(u"ࠬࡤࠨ࡝ࡦ࠮࠾ࡡࡪࠫ࠻࡞ࡧ࠯ࡡ࠴࡜ࡥ࡚࠭ࠬࠬࠥ࠺࡝ࡦ࠮࠭ࠬ࿓"),FHgYoph3Crdti1vBMqTJ82WO,dEyT9xhGjolYzLCH7460w3.DOTALL)
			if Z1hqbuQVesfpHBo98OlNLSPc3M5va:
				FHgYoph3Crdti1vBMqTJ82WO = FHgYoph3Crdti1vBMqTJ82WO.replace(Z1hqbuQVesfpHBo98OlNLSPc3M5va[FGTfwsjNrB8DvKSZhLIQAb1JnO][YYJQyRskpX8jv],iiy37aKq0pCEIOwfcTh61xb4U)
				xBfu3gkYoSDwm4na = Z1hqbuQVesfpHBo98OlNLSPc3M5va[FGTfwsjNrB8DvKSZhLIQAb1JnO][FGTfwsjNrB8DvKSZhLIQAb1JnO]
		if xBfu3gkYoSDwm4na: FHgYoph3Crdti1vBMqTJ82WO = FHgYoph3Crdti1vBMqTJ82WO.replace(xBfu3gkYoSDwm4na,PSwfZcdRYhpl5Igqz8xOEk67+xBfu3gkYoSDwm4na+YoQW601K4fMJcsreDnGVE5wUZIy7)
		m7m0InQTWGjuSeRx.append(FHgYoph3Crdti1vBMqTJ82WO)
		if len(str(m7m0InQTWGjuSeRx))>TlGXWLYsV1z(u"࠸࠴࠶࠶࠰቎"): break
	m7m0InQTWGjuSeRx = reversed(m7m0InQTWGjuSeRx)
	CZbJ3tmk2DUNzMjRX6Oxqc4AKgEHsF = OTlVEGYPSxsNaBdXUucqA3.join(m7m0InQTWGjuSeRx)
	ggULVKqsMZbc1ynfBC7(SaB5hx3PZwXRLtKgrTfQvId(u"࠭࡬ࡦࡨࡷࠫ࿔"),UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠧระิࠤศูืาࠢึะ้ࠦวๅลั฻ฬว้ࠠษ็หุะฮะษ่ࠫ࿕"),CZbJ3tmk2DUNzMjRX6Oxqc4AKgEHsF,UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡷࡲࡧ࡬࡭ࡨࡲࡲࡹࡥ࡬ࡰࡰࡪࠫ࿖"))
	return
def klKMXD9rnqmgOwdaYH6z0uA3NBREy():
	bIjfgdyGLQcCHVzktrWs3E = open(viMfkPrbW6X,ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠩࡵࡦࠬ࿗")).read()
	if J1MoiYc7ZwzKS: bIjfgdyGLQcCHVzktrWs3E = bIjfgdyGLQcCHVzktrWs3E.decode(df6QpwGxuJVZr)
	bIjfgdyGLQcCHVzktrWs3E = bIjfgdyGLQcCHVzktrWs3E.replace(SaB5hx3PZwXRLtKgrTfQvId(u"ࠪࡠࡹ࠭࿘"),tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠫࠥࠦࠠࠡࠢࠣࠤࠥ࠭࿙"))
	qQsCzJV2Wgr63in8YF1E0dXf9OSG = dEyT9xhGjolYzLCH7460w3.findall(hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠬ࠮ࡶ࡝ࡦ࠱࠮ࡄ࠯࡛࡝ࡰ࡟ࡶࡢ࠭࿚"),bIjfgdyGLQcCHVzktrWs3E,dEyT9xhGjolYzLCH7460w3.DOTALL)
	for FHgYoph3Crdti1vBMqTJ82WO in qQsCzJV2Wgr63in8YF1E0dXf9OSG:
		bIjfgdyGLQcCHVzktrWs3E = bIjfgdyGLQcCHVzktrWs3E.replace(FHgYoph3Crdti1vBMqTJ82WO,aqEsMBckT2bunGHfl48Wip+FHgYoph3Crdti1vBMqTJ82WO+YoQW601K4fMJcsreDnGVE5wUZIy7)
	BBWHv8OyN6VudhF(FRYcH4KL7e9gv5pEB(u"࠭วๅฬ฽๎๏ืวหࠢส่ศิ๊าหࠣๅ๏ࠦวๅสิห๊าࠧ࿛"),bIjfgdyGLQcCHVzktrWs3E)
	return
def OHoiTSRwnrYGPz7B9uaUmbLlZD1vs():
	ngZh3MbtFxsQAjGvyUJ67VN = ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠧษ฻ูࠤฬ๊รำำสีࠥ฿ไ๊ࠢส่ึ๐ๅ้ฬࠣ็ํ์สา๊็ࠤฯ๎แาࠢศ้่อๆ๋หࠣฮ็ี๊ๆ๋ࠢฮศิ๊าࠢส่ๆ๐ฯ๋๊ࠣ์์ึ็ࠡษ็วืืวา๊ࠢ๎ࠥอไฤี๊้ࠥ๎วๅลิๆฬ๋ࠠๆ฻ࠣฬ฾฼้ࠠๅส่ฯอไ๋ࠩ࿜")
	E8ZibMeyGK = L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠨๆอๆิ๐ๅࠡษ็ๅ๏ี๊้ࠢสืฯิฯๆࠢสุ่ํๅࠡษ็๎๊๐ๆ๊ࠡ็ฮศิ๊า้ࠣหุะฮะ็ࠣหู้็ๆࠢส่๏ูวาࠢ࠱ࠤศ๋วࠡ฻าอࠥอำ่็้ࠣฯะวๅ์ฬࠤๆํะ่ࠢอๆํ๋ࠠษฬะี๏้ࠠศๆไ๎ิ๐่ࠡส๋ๆฯࠦวไสิࠤ๊์้ࠠไอࠤฬ๊ำ่็ࠣห้๎วฮัࠣ࠲ࠥษๅศࠢสุ่ํๅࠡษ็ว฾๊้๊ࠡส่ศูแๅࠢไ๋ํ๊ࠦฮำๆࠤฬ๊แ๋ัํ์ࠥหไ๊ࠢส่ศ๋วๆࠢฦ์ࠥหไ๊ࠢส่ํืวย๋่่ࠢ์ࠠษไไึฮࠦใษ์ิอࠬ࿝")
	dANSkE5C2gKL4z7DTmuXBFR = XrTw01KtLzbpoyMf(u"ࠩฦ้ฬࠦวๅลิๆฬ๋ࠠโ้ํࠤฯูสฯั่ࠤ้๊สใัํ้ࠥ๎วๅฬฦา๏ื้ࠠๆๆ๊ࠥฮๅใัสีࠥ฿ฯะࠢส่ะ๎ว็์ࠣ์ฬ๊ฯใษษๆࠥ࠴ࠠๆอ็หࠥืโๆࠢ࠸࠸࠹ࠦสฺ่ํࠤ࠺ࠦฯใษษๆࠥ๎ࠠ࠵࠶ࠣฯฬ์๊สࠢศ่๎ࠦวๅล่ห๊ࠦร้ࠢศ่๎ࠦวๅ๊ิหฦࠦศฮีหࠤฬูสฯัส้่ࠦไๅี๊้ࠥอไ๋็ํ๊ࠥษ่ࠡี๊้ࠥอไ๋ีสีࠬ࿞")
	aZtYlicqMKUFPkBCX2AONHwJ4 = ngZh3MbtFxsQAjGvyUJ67VN+hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠪ࠾ࠥ࠭࿟")+E8ZibMeyGK+uuExaKGL7UONtevRd(u"ࠫࠥ࠴ࠠࠨ࿠")+dANSkE5C2gKL4z7DTmuXBFR
	ggULVKqsMZbc1ynfBC7(tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ࿡"),ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ࿢"),aZtYlicqMKUFPkBCX2AONHwJ4,SaB5hx3PZwXRLtKgrTfQvId(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪ࿣"))
	return
def EmxZ2PWFGSaYQNkclpnVsR(type,aZtYlicqMKUFPkBCX2AONHwJ4,showDialogs=rGPen6cSMHQkAywh8vqI9JXiD2,url=iiy37aKq0pCEIOwfcTh61xb4U,VamqUtbfFn6MANy=iiy37aKq0pCEIOwfcTh61xb4U,U94JwhRgpXCOe5=iiy37aKq0pCEIOwfcTh61xb4U,G8hQ3CqBwpW7EZjzvesHxP=iiy37aKq0pCEIOwfcTh61xb4U):
	wZM3skLUvOHFG95zIathfcJmr1QpSP = rGPen6cSMHQkAywh8vqI9JXiD2
	if not IiCsQD91HF.bbrnyC5Bz9Vqgc0fFYuZ6QNEMvXK7:
		if showDialogs:
			L6LN9XjUWJ7chxyV = (XrTw01KtLzbpoyMf(u"ࠨษ็ื฼ื࠺ࠨ࿤") in aZtYlicqMKUFPkBCX2AONHwJ4 and tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠩส่๊้ว็࠼ࠪ࿥") in aZtYlicqMKUFPkBCX2AONHwJ4 and UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠪห้๋ไโ࠼ࠪ࿦") in aZtYlicqMKUFPkBCX2AONHwJ4 and xpT28sXu051(u"ࠫฬ๊ฮุลࠪ࿧") in aZtYlicqMKUFPkBCX2AONHwJ4 and ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠬอไๆืาี࠿࠭࿨") in aZtYlicqMKUFPkBCX2AONHwJ4)
			if not L6LN9XjUWJ7chxyV: wZM3skLUvOHFG95zIathfcJmr1QpSP = A1AXKupEOfz(hhQwbeiNLoqFjX90fB7aG8VAs(u"࠭ࡣࡦࡰࡷࡩࡷ࠭࿩"),iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,jXE2YHkswT8y(u"่ࠧๆࠣฮึูไ้ࠡำ๋ࠥอไาีส่ฮࠦลๅ๋ࠣห้๋ศา็ฯࠫ࿪"),aZtYlicqMKUFPkBCX2AONHwJ4.replace(PtkEvXAqif14G20QZsaSyT(u"ࠨ࡞࡟ࡲࠬ࿫"),OTlVEGYPSxsNaBdXUucqA3))
	elif showDialogs:
		aZtYlicqMKUFPkBCX2AONHwJ4 = ZchUJdM93pTA7zG5(u"ࠩ࡟ࡠࡳะๅࠡ็ึัࠥอไาีส่ฮࡢ࡜࡯ฬ่ࠤู๊อࠡำึห้ฯ࡜࡝ࡰอ้๋ࠥำฮࠢส่ึูวๅห࡟ࡠࡳะๅࠡ็ึัࠥอไาีส่ฮࡢ࡜࡯ฬ่ࠤู๊อࠡษ็ีุอไสࠩ࿬")
		PJr8EeiM2QhBW = A1AXKupEOfz(sVzojQerUqX(u"ࠪࡧࡪࡴࡴࡦࡴࠪ࿭"),iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠫฯ๋ࠠๆีะࠤึูวๅฬๆࠫ࿮")+IpC4qHXRuyNFjzWv(u"ࠬࠦࠠ࠲࠱࠸ࠫ࿯"),GGx4qyKP1vUtRghsE2WfaHLMXZ(u"࠭็ๅࠢอี๏ีࠠฦำึห้ࠦัิษ็อࠥ็วา฼ฬࠫ࿰"))
		Wea0JihFGmxTBDkP8Vq3XNoQ = A1AXKupEOfz(LyNiIHPOwD3hCUYEFM7(u"ࠧࡤࡧࡱࡸࡪࡸࠧ࿱"),iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠨฬ่ࠤู๊อࠡำึห้ะใࠨ࿲")+sVzojQerUqX(u"ࠩࠣࠤ࠷࠵࠵ࠨ࿳"),yJeq1BjfiO4NFuwIEzxVLK6b9s(u"๋้ࠪࠦสา์าࠤสืำศๆࠣีุอไสࠢไหึเษࠨ࿴"))
		KN4yZUaLtxR3C = A1AXKupEOfz(YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ࿵"),iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠬะๅࠡ็ึัࠥืำศๆอ็ࠬ࿶")+CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"࠭ࠠࠡ࠵࠲࠹ࠬ࿷"),EMO8gy4LrsNTh0knZwpSeU75APW(u"่ࠧๆࠣฮึ๐ฯࠡวิืฬ๊ࠠาีส่ฮࠦแศำ฽อࠬ࿸"))
		MNmarijdXI3oSVf7xwCPY4gtU0 = A1AXKupEOfz(CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ࿹"),iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,AbqCJZdWQP9j(u"ࠩอ้๋ࠥำฮࠢิืฬ๊สไࠩ࿺")+TlGXWLYsV1z(u"ࠪࠤࠥ࠺࠯࠶ࠩ࿻"),UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠫ์๊ࠠหำํำࠥหัิษ็ࠤึูวๅหࠣๅฬืฺสࠩ࿼"))
		wZM3skLUvOHFG95zIathfcJmr1QpSP = A1AXKupEOfz(tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ࿽"),iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,JZszNnIEMAx28Yao0yqhiXGKOPb(u"࠭สๆ่ࠢืาࠦัิษ็ฮ่࠭࿾")+y6y5HtgXO4TkUbwVZ(u"ࠧࠡࠢ࠸࠳࠺࠭࿿"),JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠨ้็ࠤฯื๊ะࠢศีุอไࠡำึห้ฯࠠโษิ฾ฮ࠭က"))
	BBWS6VTi15YeM2bvJGXtxpslDhg8 = GmTZdMqCPhJs3pUcgS4tBOki(BF6QAiLUNHh7rKOugaw)
	AIeYNTHPpZcol = yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠩࡄ࡚࠿ࠦࠧခ")+BBWS6VTi15YeM2bvJGXtxpslDhg8+JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠪ࠱ࠬဂ")+type
	fcBu5mjy96oVdizMUI = rGPen6cSMHQkAywh8vqI9JXiD2 if LyNiIHPOwD3hCUYEFM7(u"ࠫࡤࡖࡒࡐࡄࡏࡉࡒࡥࠧဃ") in U94JwhRgpXCOe5 else BF6QAiLUNHh7rKOugaw
	if not wZM3skLUvOHFG95zIathfcJmr1QpSP:
		if showDialogs: bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨင"),ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"࠭สๆࠢศ่฿อมࠡษ็ษึูวๅࠢห๊ฬวฺࠠๆ์ࠤ฼๊ศไࠩစ"))
		return BF6QAiLUNHh7rKOugaw
	aV32bZwOuP = WwMgozBIC32n9d0tyfp.getInfoLabel(L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠧࡔࡻࡶࡸࡪࡳ࠮ࡇࡴ࡬ࡩࡳࡪ࡬ࡺࡐࡤࡱࡪ࠭ဆ"))
	aZtYlicqMKUFPkBCX2AONHwJ4 += AbqCJZdWQP9j(u"ࠨࠢ࡟ࡠࡳࡢ࡜࡯࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾ࠢ࡟ࡠࡳࡇࡤࡥࡱࡱࠤ࡛࡫ࡲࡴ࡫ࡲࡲ࠿ࠦࠧဇ")+DdAjF5pBNL9IqPgkz0xhcQEfU+yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠩࠣ࠾ࡡࡢ࡮ࠨဈ")
	aZtYlicqMKUFPkBCX2AONHwJ4 += EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠪࡉࡲࡧࡩ࡭ࠢࡖࡩࡳࡪࡥࡳ࠼ࠣࠫဉ")+BBWS6VTi15YeM2bvJGXtxpslDhg8+uuExaKGL7UONtevRd(u"ࠫࠥࡀ࡜࡝ࡰࡎࡳࡩ࡯ࠠࡗࡧࡵࡷ࡮ࡵ࡮࠻ࠢࠪည")+MDPFS9ovE8daQwhKrI+y6y5HtgXO4TkUbwVZ(u"ࠬࠦ࠺࡝࡞ࡱࠫဋ")
	aZtYlicqMKUFPkBCX2AONHwJ4 += MgP8OjoaiWQEVG59(u"࠭ࡋࡰࡦ࡬ࠤࡓࡧ࡭ࡦ࠼ࠣࠫဌ")+aV32bZwOuP
	A35buNj8r7ydgkYsOQvW0 = hz5lWCRmTwgFV48NSMBPY9AKf()
	A35buNj8r7ydgkYsOQvW0 = YqdaDIig21wBTWJeUHbc(A35buNj8r7ydgkYsOQvW0)
	if A35buNj8r7ydgkYsOQvW0: aZtYlicqMKUFPkBCX2AONHwJ4 += Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠧࠡ࠼࡟ࡠࡳࡒ࡯ࡤࡣࡷ࡭ࡴࡴ࠺ࠡࠩဍ")+A35buNj8r7ydgkYsOQvW0
	if url: aZtYlicqMKUFPkBCX2AONHwJ4 += vODxLKW5Ql6r4Fbm8(u"ࠨࠢ࠽ࡠࡡࡴࡕࡓࡎ࠽ࠤࠬဎ")+url
	if VamqUtbfFn6MANy: aZtYlicqMKUFPkBCX2AONHwJ4 += FRYcH4KL7e9gv5pEB(u"ࠩࠣ࠾ࡡࡢ࡮ࡔࡱࡸࡶࡨ࡫࠺ࠡࠩဏ")+VamqUtbfFn6MANy
	aZtYlicqMKUFPkBCX2AONHwJ4 += ZchUJdM93pTA7zG5(u"ࠪࠤ࠿ࡢ࡜࡯ࠩတ")
	if showDialogs: YYkhEn5xTXLUevzCVNB16mR(hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠫัอั๋ࠢส่สืำศๆࠪထ"),Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠬอไาฮสลࠥอไศ่อ฼ฬืࠧဒ"))
	if G8hQ3CqBwpW7EZjzvesHxP:
		CZbJ3tmk2DUNzMjRX6Oxqc4AKgEHsF = G8hQ3CqBwpW7EZjzvesHxP
		if J1MoiYc7ZwzKS: CZbJ3tmk2DUNzMjRX6Oxqc4AKgEHsF = CZbJ3tmk2DUNzMjRX6Oxqc4AKgEHsF.encode(df6QpwGxuJVZr)
		CZbJ3tmk2DUNzMjRX6Oxqc4AKgEHsF = UodGe76Lu2IHTYPxBhjk1RpcaqrM.b64encode(CZbJ3tmk2DUNzMjRX6Oxqc4AKgEHsF)
	elif fcBu5mjy96oVdizMUI:
		if Y41NvKfOroMzGB8sEHy7wbXlc5(u"࠭࡟ࡑࡔࡒࡆࡑࡋࡍࡠࡑࡏࡈࡤ࠭ဓ") in U94JwhRgpXCOe5: SWiynDLZQI0ejaqXPlf7sKH1r9uC = fftaeIcglCErxBsY3ORFh
		else: SWiynDLZQI0ejaqXPlf7sKH1r9uC = Ct1U8Ao9wucR
		if not wkMR5x1gTWEQIc6qHCa.path.exists(SWiynDLZQI0ejaqXPlf7sKH1r9uC):
			bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,IpC4qHXRuyNFjzWv(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪန"),JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠨีฯ่ࠥอไฤะฺหฦ่ࠦศๆสืฯิฯศ็ࠣ฾๏ืࠠๆ๊ฯ์ิ࠭ပ"))
			return BF6QAiLUNHh7rKOugaw
		WKquk5EaNr4RzVf(q1rohYuwnfpVZUa98L2CtQzmAcB,L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠩ࠱ࡠࡹࡖࡲࡦࡲࡤࡶ࡮ࡴࡧࠡࡶࡲࠤࡸ࡫࡮ࡥࠢࡷ࡬ࡪࠦ࡬ࡰࡩࡩ࡭ࡱ࡫ࠧဖ"))
		m7m0InQTWGjuSeRx,d95dmOUNYHZsquy = [],IpC4qHXRuyNFjzWv(u"࠴቏")
		file = open(SWiynDLZQI0ejaqXPlf7sKH1r9uC,XrTw01KtLzbpoyMf(u"ࠪࡶࡧ࠭ဗ"))
		size,count = MZ0QpfA1jaJgoWO2IndU(SWiynDLZQI0ejaqXPlf7sKH1r9uC)
		if size>tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"࠸࠶࠱࠱࠲࠳ቐ"): file.seek(-tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"࠸࠶࠱࠱࠲࠳ቐ"),wkMR5x1gTWEQIc6qHCa.SEEK_END)
		data = file.read()
		file.close()
		data = data.decode(df6QpwGxuJVZr)
		data = uNThYr7JM80cbikw(data)
		Wbe8jlJaNdroOHgpm = data.splitlines()
		for FHgYoph3Crdti1vBMqTJ82WO in reversed(Wbe8jlJaNdroOHgpm):
			AHoXV2C4x9yzEShsdGI8w = RReQn8vY9d1WVakx0gN(FHgYoph3Crdti1vBMqTJ82WO)
			if AHoXV2C4x9yzEShsdGI8w: continue
			Z1hqbuQVesfpHBo98OlNLSPc3M5va = dEyT9xhGjolYzLCH7460w3.findall(HtK4o2sTPgA78U(u"ࠫࡣ࠮࡜ࡥ࠭࠰ࠬࡡࡪࠫ࠮࡞ࡧ࠯ࠥࡢࡤࠬ࠼࡟ࡨ࠰ࡀ࡜ࡥ࠭࡟࠲ࡡࡪࠫࠪࠫࠫࠤ࡙ࡀ࡜ࡥ࠭ࠬࠫဘ"),FHgYoph3Crdti1vBMqTJ82WO,dEyT9xhGjolYzLCH7460w3.DOTALL)
			if Z1hqbuQVesfpHBo98OlNLSPc3M5va:
				FHgYoph3Crdti1vBMqTJ82WO = FHgYoph3Crdti1vBMqTJ82WO.replace(Z1hqbuQVesfpHBo98OlNLSPc3M5va[FGTfwsjNrB8DvKSZhLIQAb1JnO][FGTfwsjNrB8DvKSZhLIQAb1JnO],Z1hqbuQVesfpHBo98OlNLSPc3M5va[FGTfwsjNrB8DvKSZhLIQAb1JnO][YYJQyRskpX8jv]).replace(Z1hqbuQVesfpHBo98OlNLSPc3M5va[FGTfwsjNrB8DvKSZhLIQAb1JnO][nI2JK1RfsGWNY3OarEeMQZ],iiy37aKq0pCEIOwfcTh61xb4U)
			else:
				Z1hqbuQVesfpHBo98OlNLSPc3M5va = dEyT9xhGjolYzLCH7460w3.findall(hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠬࡤࠨ࡝ࡦ࠮࠾ࡡࡪࠫ࠻࡞ࡧ࠯ࡡ࠴࡜ࡥ࡚࠭ࠬࠬࠥ࠺࡝ࡦ࠮࠭ࠬမ"),FHgYoph3Crdti1vBMqTJ82WO,dEyT9xhGjolYzLCH7460w3.DOTALL)
				if Z1hqbuQVesfpHBo98OlNLSPc3M5va: FHgYoph3Crdti1vBMqTJ82WO = FHgYoph3Crdti1vBMqTJ82WO.replace(Z1hqbuQVesfpHBo98OlNLSPc3M5va[FGTfwsjNrB8DvKSZhLIQAb1JnO][YYJQyRskpX8jv],iiy37aKq0pCEIOwfcTh61xb4U)
			m7m0InQTWGjuSeRx.append(FHgYoph3Crdti1vBMqTJ82WO)
			if len(str(m7m0InQTWGjuSeRx))>tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"࠸࠵࠲࠲࠳࠴ቑ"): break
		m7m0InQTWGjuSeRx = reversed(m7m0InQTWGjuSeRx)
		CZbJ3tmk2DUNzMjRX6Oxqc4AKgEHsF = ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"࠭࡜ࡳ࡞ࡱࠫယ").join(m7m0InQTWGjuSeRx)
		CZbJ3tmk2DUNzMjRX6Oxqc4AKgEHsF = CZbJ3tmk2DUNzMjRX6Oxqc4AKgEHsF.encode(df6QpwGxuJVZr)
		CZbJ3tmk2DUNzMjRX6Oxqc4AKgEHsF = UodGe76Lu2IHTYPxBhjk1RpcaqrM.b64encode(CZbJ3tmk2DUNzMjRX6Oxqc4AKgEHsF)
	else: CZbJ3tmk2DUNzMjRX6Oxqc4AKgEHsF = iiy37aKq0pCEIOwfcTh61xb4U
	url = gZ4LwbKaOm[hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠧࡑ࡛ࡗࡌࡔࡔࠧရ")][nI2JK1RfsGWNY3OarEeMQZ]
	Si4j3bXGLeno0zfxlm9ZOcy = {hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠨࡵࡸࡦ࡯࡫ࡣࡵࠩလ"):AIeYNTHPpZcol,PtkEvXAqif14G20QZsaSyT(u"ࠩࡰࡩࡸࡹࡡࡨࡧࠪဝ"):aZtYlicqMKUFPkBCX2AONHwJ4,ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠪࡰࡴ࡭ࡦࡪ࡮ࡨࠫသ"):CZbJ3tmk2DUNzMjRX6Oxqc4AKgEHsF}
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(hI7SkXd94fFzAHNZCQoMqEutbnWP,IpC4qHXRuyNFjzWv(u"ࠫࡕࡕࡓࡕࠩဟ"),url,Si4j3bXGLeno0zfxlm9ZOcy,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,hhQwbeiNLoqFjX90fB7aG8VAs(u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙࠭ࡔࡇࡑࡈࡤࡋࡍࡂࡋࡏ࠱࠶ࡹࡴࠨဠ"))
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	if xpT28sXu051(u"࠭ࠢࡴࡷࡦࡧࡪ࡫ࡤࡦࡦࠥ࠾ࠥ࠷ࠬࠨအ") in Vxz6OndPIX4g2kaRp7: M5qyIg2dZlm6FxH4tTPV79okNu0bCG = rGPen6cSMHQkAywh8vqI9JXiD2
	else: M5qyIg2dZlm6FxH4tTPV79okNu0bCG = BF6QAiLUNHh7rKOugaw
	if showDialogs:
		if M5qyIg2dZlm6FxH4tTPV79okNu0bCG:
			YYkhEn5xTXLUevzCVNB16mR(y6y5HtgXO4TkUbwVZ(u"ࠧห็ࠣห้หัิษ็ࠤอ์ฬศฯࠪဢ"),YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠨࡕࡸࡧࡨ࡫ࡳࡴࠩဣ"))
			bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠩࡐࡩࡸࡹࡡࡨࡧࠣࡷࡪࡴࡴࠨဤ"),ZchUJdM93pTA7zG5(u"ࠪฮ๊ࠦลาีส่ࠥอไาีส่ฮࠦศ็ฮสัࠬဥ"))
		else:
			YYkhEn5xTXLUevzCVNB16mR(L90uqo28xEKSFUwYTcm51yRWZIkft(u"้๊ࠫริใࠣๅู๊ࠠศๆศีุอไࠨဦ"),UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠬࡌࡡࡪ࡮ࡸࡶࡪ࠭ဧ"))
			bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,yJeq1BjfiO4NFuwIEzxVLK6b9s(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩဨ"),uuExaKGL7UONtevRd(u"ࠧฯูฦࠤํ็ิๅࠢไ๎ࠥหัิษ็ࠤฬ๊ัิษ็อࠬဩ"))
	return M5qyIg2dZlm6FxH4tTPV79okNu0bCG
def THdUxh1SEo4PK():
	ngZh3MbtFxsQAjGvyUJ67VN = vODxLKW5Ql6r4Fbm8(u"ࠨࡆࡲࠤࡾࡵࡵࠡࡹࡤࡲࡹࠦࡴࡰࠢࡷࡶࡦࡴࡳ࡭ࡣࡷࡩࠥࡳࡥ࡯ࡷࠣ࡭ࡹ࡫࡭ࡴࠢࡷࡳࠥࡧࠠ࡭ࡣࡱ࡫ࡺࡧࡧࡦࠢࡲࡸ࡭࡫ࡲࠡࡶ࡫ࡥࡳࠦࡁࡳࡣࡥ࡭ࡨࠦ࠮࠯ࠢࡒࡶࠥࡿ࡯ࡶࠢࡺࡥࡳࡺࠠࡵࡱࠣࡷ࡭ࡵࡷࠡࡃࡵࡥࡧ࡯ࡣࠡ࡮ࡨࡸࡹ࡫ࡲࡴࠢࡤࡲࡩࠦࡴࡦࡺࡷࠤࡄࠧࠧဪ")
	E8ZibMeyGK = hhQwbeiNLoqFjX90fB7aG8VAs(u"๊่ࠩࠥะั๋ัࠣฮึาๅสࠢๅ์ฬฬๅࠡษ็ฬึ์วๆฮࠣษ้๏ࠠๅ฼ฬࠤศิั๊ࠢ฽๎ึࠦวๅ฻ิฬ๏ฯࠠ࠯࠰ࠣว๊ࠦสา์าࠤส฾็ศำࠣห้ษอาใࠣ์ฬ๊ใหษหอࠥอไฺำห๎ฮࠦฟࠢࠩါ")
	Mj31nS0Be7h2g = Ny92sqomMkizpgKV1(zmcGfOdvAjsELeJlP(u"ࠪࡧࡪࡴࡴࡦࡴࠪာ"),xpT28sXu051(u"ࠫำื่อࠢࡈࡼ࡮ࡺࠧိ"),vODxLKW5Ql6r4Fbm8(u"࡚ࠬࡲࡢࡰࡶࡰࡦࡺࡥࠡฬิะ๊ฯࠧီ"),HtK4o2sTPgA78U(u"ู࠭าสํࠤࡆࡸࡡࡣ࡫ࡦࠫု"),Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪူ"),ngZh3MbtFxsQAjGvyUJ67VN+y6y5HtgXO4TkUbwVZ(u"ࠨ࡞ࡱࡠࡳ࠭ေ")+E8ZibMeyGK)
	if Mj31nS0Be7h2g in [-hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"࠱ቒ"),SaB5hx3PZwXRLtKgrTfQvId(u"࠱ቓ")]: return
	elif Mj31nS0Be7h2g==vODxLKW5Ql6r4Fbm8(u"࠳ቔ"):
		import TTOWYe76MF
		TTOWYe76MF.dxXsWYnBVM()
		return
	wuDFIQ9CVJjx0hcMgURvEz17Wr5LBO = MgP8OjoaiWQEVG59(u"࡚ࡲࡶࡧቻ")
	while wuDFIQ9CVJjx0hcMgURvEz17Wr5LBO:
		wuDFIQ9CVJjx0hcMgURvEz17Wr5LBO = LyNiIHPOwD3hCUYEFM7(u"ࡆࡢ࡮ࡶࡩቼ")
		message = ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠩศิฬูࠦ็ัๆࠤฺ๊ใๅหࠣๅ๏ࠦวๅละีๆࠦวๅ฻ิฬ๏ฯࠠโษำ๋อࠦลๅ๋ࠣࠦส฿ฯศัสฮࠥ๎วอ้ฬࠤ่๎ฯ๋ࠤࠣฯฺ๊๋ࠦำࠣห้ิืࠡว็ํࠥࠨࡁࡳ࡫ࡤࡰࠧࠦ࠮࠯ࠢศิฬࠦไๆࠢอะิࠦวๅะฺࠤࠧࡇࡲࡪࡣ࡯ࠦࠥ็ฺ๋ำࠣห้าไะࠢศ่๎ࠦร๋ࠢฯ่ิࠦหศ่ํࠤๆ๐็ࠡษ็า฼ࠦࠢࡂࡴ࡬ࡥࡱࠨࠠ࠯࠰ࠣฯ๊ࠦศฺั๊หࠥเ๊าࠢส่ำ฽ࠠฦๆ์ࠤࠧࡇࡲࡪࡣ࡯ࠦࠥࡢ࡮ࠡวำห๊่ࠥฮหࠣห้๋แศฬํัࠥอไฺำห๎ฮࠦไศࠢอ฼์ืࠠๅๅࠣ࠲࠳ࠦวั้หࠤส๊้ࠡࠤศ฽ิอฯศฬࠣ์ฬา็สࠢๆ์ิ๐ࠢࠡ࠰࠱ࠤะ๋ࠠ฻์ิࠤส฿ฯศัสฮࠥอไๆ๊ๅ฽ࠥอไอ฼ิหๆ๐ࠠ࡝ࡰ࡟ࡲࠥํไࠡฬิ๎ิࠦวๅฤ้ࠤๆะอࠡࠤศ฽ิอฯศฬࠣ์ฬา็สࠢๆ์ิ๐ࠢࠡมࠤࠫဲ")
		Mj31nS0Be7h2g = Ny92sqomMkizpgKV1(sVzojQerUqX(u"ࠪࡧࡪࡴࡴࡦࡴࠪဳ"),GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠫࡊࡾࡩࡵࠢัีําࠧဴ"),YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠬ࡟ࡥࡴ้ࠢ฽๊࠭ဵ"),uuExaKGL7UONtevRd(u"࠭ࡅ࡯ࡩ࡯࡭ࡸ࡮ࠠฦ่ฯ่๏ุ๊ࠨံ"),vODxLKW5Ql6r4Fbm8(u"ฺࠧั่ࠤ฽ํ่าࠢส่ศำัโ๋ࠢห้้สศสฬࠤฬู๊าสํอ့ࠬ"),message,profile=UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠨࡥࡲࡲ࡫࡯ࡲ࡮ࡡࡰࡩࡩ࡯ࡵ࡮ࡨࡲࡲࡹ࠭း"))
		if Mj31nS0Be7h2g==XrTw01KtLzbpoyMf(u"࠵ቕ"):
			message = hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠩࡌࡪࠥࡿ࡯ࡶࠢ࡫ࡥࡻ࡫ࠠࡱࡴࡲࡦࡱ࡫࡭ࠡࡹ࡬ࡸ࡭ࠦࡁࡳࡣࡥ࡭ࡨࠦ࡬ࡦࡶࡷࡩࡷࡹࠠࡵࡪࡨࡲࠥࡵࡰࡦࡰࠣࠦࡐࡵࡤࡪࠢࡌࡲࡹ࡫ࡲࡧࡣࡦࡩ࡙ࠥࡥࡵࡶ࡬ࡲ࡬ࡹࠢࠡࡣࡱࡨࠥࡩࡨࡢࡰࡪࡩࠥࡺࡨࡦࠢࡩࡳࡳࡺࠠࡵࡱࠣࠦࡆࡸࡩࡢ࡮ࠥࠤ࠳࠴ࠠࡊࡨࠣࡽࡴࡻࠠࡤࡣࡱࡠࠬࡺࠠࡧ࡫ࡱࡨࠥࠨࡁࡳ࡫ࡤࡰࠧࠦࡦࡰࡰࡷࠤࡹ࡮ࡥ࡯ࠢࡦ࡬ࡦࡴࡧࡦࠢࡷ࡬ࡪࠦࡳ࡬࡫ࡱࠤࡹࡵࠠࡢࡰࡼࠤࡴࡺࡨࡦࡴࠣࡷࡰ࡯࡮ࠡࡶ࡫ࡥࡹࠦࡨࡢࡸࡨࠤࡡࠨࡁࡳ࡫ࡤࡰࡡࠨࠠࡧࡱࡱࡸࠥ࠴࠮ࠡࡃࡱࡨࠥࡺࡨࡦࡰࠣࡧ࡭ࡧ࡮ࡨࡧࠣࡸ࡭࡫ࠠࡧࡱࡱࡸࠥࡺ࡯ࠡࠤࡄࡶ࡮ࡧ࡬ࠣࠢ࡟ࡲࠥࡏࡦࠡࡃࡵࡥࡧ࡯ࡣࠡࡍࡨࡽࡧࡵࡡࡳࡦࠣ࡭ࡸࠦ࡮ࡰࡶࠣࡥࡻࡧࡩ࡭ࡣࡥࡰࡪࠦ࠮࠯ࠢࡗ࡬ࡪࡴࠠࡰࡲࡨࡲࠥࠨࡋࡰࡦ࡬ࠤࡎࡴࡴࡦࡴࡩࡥࡨ࡫ࠠࡔࡧࡷࡸ࡮ࡴࡧࡴࠤࠣࡥࡳࡪࠠࡤࡪࡤࡲ࡬࡫ࠠࡵࡪࡨࠤࡷ࡫ࡧࡪࡱࡱࡥࡱࠦࡳࡦࡶࡷ࡭ࡳ࡭ࡳࠡ࡞ࡱࡠࡳࠦࡄࡰࠢࡼࡳࡺࠦࡷࡢࡰࡷࠤࡳࡵࡷࠡࡶࡲࠤࡴࡶࡥ࡯ࠢࡷ࡬ࡪࠦࠢࡌࡱࡧ࡭ࠥࡏ࡮ࡵࡧࡵࡪࡦࡩࡥࠡࡕࡨࡸࡹ࡯࡮ࡨࡵࠥࠤࡄ္ࠧࠧ")
			Mj31nS0Be7h2g = Ny92sqomMkizpgKV1(hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠪࡧࡪࡴࡴࡦࡴ်ࠪ"),xpT28sXu051(u"ࠫࡊࡾࡩࡵࠢัีําࠧျ"),EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠬ࡟ࡥࡴ้ࠢ฽๊࠭ြ"),IpC4qHXRuyNFjzWv(u"࠭ࡁࡳࡣࡥ࡭ࡨูࠦาสํࠫွ"),Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠧࡎ࡫ࡶࡷ࡮ࡴࡧࠡࡃࡵࡥࡧ࡯ࡣࠡࡈࡲࡲࡹࠦࠦࠡࡖࡨࡼࡹ࠭ှ"),message,profile=hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠨࡥࡲࡲ࡫࡯ࡲ࡮ࡡࡰࡩࡩ࡯ࡵ࡮ࡨࡲࡲࡹ࠭ဿ"))
			if Mj31nS0Be7h2g==Y41NvKfOroMzGB8sEHy7wbXlc5(u"࠶ቖ"): wuDFIQ9CVJjx0hcMgURvEz17Wr5LBO = ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࡕࡴࡸࡩች")
		if Mj31nS0Be7h2g==jXE2YHkswT8y(u"࠶቗"): inc0qJAsOf8dQCHgUG()
	return
def uASQX6HdhcklsDNE87Gm2gaR():
	bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ၀"),tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠪ฾ฬ๊ศศࠢสุ่ฮศ้๋ࠡࠤ๊์ࠠศๆ่์็฿ࠠศๆฦู้๐ࠠศๆ่฾ี๐ࠠๅๆหี๋อๅอ๋่้ࠢะรไัࠣๆ๊ࠦศหึ฽๎้ࠦวๅำสฬ฼ࠦวๅาํࠤ้อ๋ࠠ฻่่ࠥัๅࠡไ่ࠤอหัิษ็ࠤฺ๊ใๅหࠣษ้๏ࠠศๆ่ฬึ๋ฬࠡ็้ࠤฬ๊โศศ่อࠥอไาศํื๏ฯࠠๅๆหี๋อๅอࠩ၁"))
	return
def A95DBQhrxLCE1natIK():
	aZtYlicqMKUFPkBCX2AONHwJ4 = PtkEvXAqif14G20QZsaSyT(u"ࠫ์ึวࠡษ็ฬึ์วๆฮ้ࠣำ฻ีࠡใๅ฻๊ࠥไ฻หࠣห้฿ัษ์ฬࠤํ๊ใ็๊ࠢิฬࠦไศࠢํ้๋฿้ࠠฮ๋ำ๋่ࠥศไ฼ࠤๆ๐็ศࠢฦๅ้อๅ๊่ࠡืู้ไศฬ้ࠣฯืฬๆหࠣวํࠦๅะส็ะฮࠦลๅ๋ࠣหฺ้๊สࠢส่฾ืศ๋หࠣ์ฬ๊้ࠡๆ฽หฯࠦวฯำ์ࠤํ๊วࠡ์๋ะิࠦำษส่้ࠣะใาษิࠫ၂")
	bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,TlGXWLYsV1z(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ၃"),aZtYlicqMKUFPkBCX2AONHwJ4)
	return
def gKvNf10iFjdG9r6UnWuc():
	aZtYlicqMKUFPkBCX2AONHwJ4 = HtK4o2sTPgA78U(u"࠭วๅำ๋หอ฽ࠠศๆห฻๏ฬษࠡๆสࠤ฾๊วให่ࠣ์อࠠษษ็ฬึ์วๆฮࠣ์฿อไษษࠣหู้ศษ๊ࠢ์๋ࠥๆࠡษ็้ํู่ࠡษ็วฺ๊๊ࠡษ็้฿ึ๊ࠡๆ็ฬึ์วๆฮࠪ၄")
	bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,vODxLKW5Ql6r4Fbm8(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ၅"),aZtYlicqMKUFPkBCX2AONHwJ4)
	return
def P7y4qelk6QXo3iWraFVhngZMBC0wU():
	aZtYlicqMKUFPkBCX2AONHwJ4 = tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠨ้ํࠤุ๐ัโำสฮ๊ࠥวࠡ์ึฮ฼๐ูࠡษ็ฬึ์วๆฮࠣหุะฮะษ่๋ฬࠦศิสหࠤ่๎ๆ่ษ้ࠣา๋๊ส่๊ࠢࠥอไๆืาีࠥษ่ࠡสะหัฯࠠฦๆ์ࠤฬฺสาษๆࠤึูๅ๋ࠢฦ์ࠥาฯ๋ัฬࠤศ๎ࠠๅษࠣ๎฾ืแ่ษࠣห้ฮั็ษ่ะࠬ၆")
	bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,SaB5hx3PZwXRLtKgrTfQvId(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ၇"),FRYcH4KL7e9gv5pEB(u"ࠪื๏ืแาษอࠤุ๐ฦสࠢฦ์๋ࠥฬ่๊็อࠬ၈"),aZtYlicqMKUFPkBCX2AONHwJ4)
	return
def slnBYPgWXq4MdDQ21yx36LFwIaci():
	aZtYlicqMKUFPkBCX2AONHwJ4 = y6y5HtgXO4TkUbwVZ(u"ࠫฬ๊ำ๋ำไีฬะࠠศๆ฼ห๊ฯ่ࠠ์ࠣื๏ืแาษอࠤำอัอ์ฬࠤํเ๊าࠢอหอ฿ษࠡๆ็้ํู่ࠡษ็วฺ๊๊๊ࠡฯ้๏฿ࠠศๆ่์ฬู่ࠡฬึฮำีๅ่ษࠣ์฾อฯสࠢอ็ํ์ࠠๆฮส๊๏ฯ้ࠠ็ืห่๊็ศࠢๆฯ๏ืษࠡๆส๊ࠥอไโ์า๎ํํวหࠢไ๎์อࠠฦ็สࠤอ฽๊วหࠣวํࠦๅๆ่๋฽ฮࠦร้่ࠢัี๎แสࠢฦ์ࠥ็๊่ษู้้ࠣไสࠢะๆํ่ࠠศๆ่่่๐ษ࡝ࡰ࡟ࡲࡡࡴวๅีํีๆืวหࠢส่ำอีส๊ࠢ๎ู๊ࠥาใิหฯࠦสศส฼อ๊ࠥไๆ๊ๅ฽ࠥอไฤื็๎ࠥ๎ๅิฬัำ๊ฯࠠโ์้ࠣํอโฺࠢๅ่๏๊ษࠡฮาหࠥ๎ูศัฬࠤฯ้่็่ࠢำๆ๎ูสࠢส่ศาัࠡล๋ࠤ๏๋ไไ้สࠤฬ๊ๅ้ไ฼ࠤฬ๊รึๆํࠤํ๊็ัษࠣๅ์๐ࠠอ์าอࠥ์ำษ์สࠤํูั๋฻ฬࠤํ๋ิศๅ็๋ฬࠦโๅ์็อࠥาฯศࠩ၉")
	ggULVKqsMZbc1ynfBC7(LyNiIHPOwD3hCUYEFM7(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ၊"),LyNiIHPOwD3hCUYEFM7(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ။"),aZtYlicqMKUFPkBCX2AONHwJ4,xpT28sXu051(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪ၌"))
	return
def dMJhEjli0I45Kb9VquwNv():
	ngZh3MbtFxsQAjGvyUJ67VN = yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠨษหฮ฾ีฺ่้้ࠠࠣ็วหࠢส่ิ่ษࠡษ็฽ฬ๊๊สࠩ၍")
	E8ZibMeyGK = FRYcH4KL7e9gv5pEB(u"ࠩสฬฯ฿ฯࠡ฻้ࠤ๊๊แศฬࠣว้ࠦ࡭࠴ࡷ࠻ࠫ၎")
	dANSkE5C2gKL4z7DTmuXBFR = SaB5hx3PZwXRLtKgrTfQvId(u"ࠪหอะูะࠢ฼๊๋ࠥไโษอࠤฬ๊สฮ็ํ่ࠥ๎วๅัส์๋๊่ะࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ၏")
	bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧၐ"),ngZh3MbtFxsQAjGvyUJ67VN,E8ZibMeyGK,dANSkE5C2gKL4z7DTmuXBFR)
	return
def KKDcbX7IGg1Y():
	E8ZibMeyGK = vODxLKW5Ql6r4Fbm8(u"ࠬอไไษืࠤ์๎ࠠๆะี๊๋ࠥฤใฬู่้๋ࠣๅ๊่หฯ๊ࠦิฬัำ๊ํࠠศๆหี๋อๅอࠢ็าื์ࠠึใะหฯࠦวๅว้ฮึ์๊ห๋ࠢีํอศุࠢส่ๆ๐ฯ๋๊๊หฯࠦไๅุ๊์้ࠦลๅ์๊หࠥฮำา฻ฬࠤํฮฯ้่ࠣษ๋ะั็์อࠤํอไษำ้ห๊า๋ࠠ็ึั์อࠠหๆๅหห๐วࠡส฼ำࠥอๆห้สลࠥ฿ๅา้สࠤํษ๊ืษࠣ฽๋ีࠠหฯา๎ะࠦวๅสิ๊ฬ๋ฬࠡ࠰ࠣ์์ึวࠡษ็ฬึ์วๆฮࠣ๎ุะฮะ็ࠣือ฿ษࠡล้์ฬ฿ࠠๅ฻่ีࠥอไไษืࠤ࠿࠭ၑ")
	E8ZibMeyGK += tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"࠭࡜࡯࡞ࡱࠫၒ") + PtkEvXAqif14G20QZsaSyT(u"ࠧ࠲࠰ࠣฯฬฮสࠡๆ็ูๆำวหࠢส่ฯ๐ࠠๆ฻ิ์ๆࠦร็้สࠤ้อࠠหฬ฽๎ึࠦๆ่ษษ๎ฬ่ࠦๆัอ๋ࠥ࠭ၓ") + str(VaeMF1mIjQ5iLtfGcB/tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"࠼࠰ቘ")/tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"࠼࠰ቘ")/xpT28sXu051(u"࠲࠵቙")/L90uqo28xEKSFUwYTcm51yRWZIkft(u"࠴࠲ቚ")) + IpC4qHXRuyNFjzWv(u"ࠨࠢื๋ึ࠭ၔ")
	E8ZibMeyGK += OTlVEGYPSxsNaBdXUucqA3 + TlGXWLYsV1z(u"ࠩ࠵࠲ࠥาฯศฺࠢ์๏๊ࠠศๆ่ำ๎ࠦไๅืไัฬะࠠศๆ่ๅึ๎ึࠡล้๋ฬࠦไศࠢอฮ฿๐ั๊่ࠡำฯํࠠࠨၕ") + str(ea84RQXsdLY9GIVjSzb/XrTw01KtLzbpoyMf(u"࠸࠳ቛ")/XrTw01KtLzbpoyMf(u"࠸࠳ቛ")/CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"࠵࠸ቜ")) + HtK4o2sTPgA78U(u"ࠪࠤ๏๎ๅࠨၖ")
	E8ZibMeyGK += OTlVEGYPSxsNaBdXUucqA3 + jXE2YHkswT8y(u"ࠫ࠸࠴ุ๊ࠠํ่ࠥอไๆั์ࠤ้๊ีโฯสฮࠥอไห์๊ࠣฬีัศࠢอฮ฿๐ั๊่ࠡำฯํࠠࠨၗ") + str(Dxc7GChQwZ4kOlKHSbL06agnB/IpC4qHXRuyNFjzWv(u"࠺࠵ቝ")/IpC4qHXRuyNFjzWv(u"࠺࠵ቝ")/ZchUJdM93pTA7zG5(u"࠷࠺቞")) + LyNiIHPOwD3hCUYEFM7(u"๊้ࠬࠦ็ࠪၘ")
	E8ZibMeyGK += OTlVEGYPSxsNaBdXUucqA3 + tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"࠭࠴࠯่ࠢฮํูืࠡษ็้ิ๏ࠠๅๆุๅาอสࠡษ็ฮ๏ࠦโะࠢอฮ฿๐ั๊่ࠡำฯํࠠࠨၙ") + str(PNjZMS7nxa9clHusz1/y6y5HtgXO4TkUbwVZ(u"࠼࠰቟")/y6y5HtgXO4TkUbwVZ(u"࠼࠰቟")) + xpT28sXu051(u"ࠧࠡีส฽ฮ࠭ၚ")
	E8ZibMeyGK += OTlVEGYPSxsNaBdXUucqA3 + PtkEvXAqif14G20QZsaSyT(u"ࠨ࠷࠱ࠤ็฻๊าࠢส่๊ี้ࠡๆ็ูๆำวหࠢส่ฯ๐ࠠหฬ฽๎ึࠦฯศศ่หࠥ๎ๅะฬ๊ࠤࠬၛ") + str(r3rnfZ7cdxzNFebIRaLSG6B/EMO8gy4LrsNTh0knZwpSeU75APW(u"࠶࠱በ")/EMO8gy4LrsNTh0knZwpSeU75APW(u"࠶࠱በ")) + EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠩࠣืฬ฿ษࠨၜ")
	E8ZibMeyGK += OTlVEGYPSxsNaBdXUucqA3 + y6y5HtgXO4TkUbwVZ(u"ࠪ࠺࠳ࠦฬะษࠣๆฺ๐ัࠡษ็้ิ๏ࠠๅๆุๅาอสࠡษ็ฮ๏ࠦสห฼ํี้ࠥห๋ำสࠤํ๋ฯห้ࠣࠫၝ") + str(Qfob9ThC6ryqKkYZ/sVzojQerUqX(u"࠷࠲ቡ")) + ZchUJdM93pTA7zG5(u"ࠫࠥีโ๋ไฬࠫၞ")
	E8ZibMeyGK += OTlVEGYPSxsNaBdXUucqA3 + UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠬ࠽࠮ࠡสา์๋ࠦใศึ่้ࠣ฻แฮษอࠤฬ๊ส๋ࠢอฮ฿๐ัࠡสึี฾ฯ้ࠠ็าฮ์ࠦࠧၟ") + str(hI7SkXd94fFzAHNZCQoMqEutbnWP) + zmcGfOdvAjsELeJlP(u"࠭ࠠะไํๆฮ࠭ၠ")
	E8ZibMeyGK += UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠧ࡝ࡰ࡟ࡲࠬၡ") + MgP8OjoaiWQEVG59(u"ࠨ็ฮ่ฬࡀࠠึใะหฯࠦโ้ษษ้ࠥอไฤใ็ห๊่ࠦศๆ่ืู้ไศฬࠣ์ฬ๊อๅไสฮࠥ฿ๅา้สࠤࠬၢ") + str(PNjZMS7nxa9clHusz1/tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"࠸࠳ቢ")/tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"࠸࠳ቢ")) + zmcGfOdvAjsELeJlP(u"ࠩࠣืฬ฿ษࠡ࠰ࠣว๊อࠠใ๊สส๊ࠦร็๊ส฽ࠥอไโ์า๎ํํวหࠢไ฽๊ื็ศࠢࠪၣ") + str(Dxc7GChQwZ4kOlKHSbL06agnB/tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"࠸࠳ቢ")/tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"࠸࠳ቢ")/xpT28sXu051(u"࠵࠸ባ")) + tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠪࠤศ๐วๆࠢ࠱ࠤศ๋วࠡ็็ๅฬะࠠศๆไ๎ิ๐่ࠡใ฼้ึํวࠡࠩၤ") + str(r3rnfZ7cdxzNFebIRaLSG6B/tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"࠸࠳ቢ")/tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"࠸࠳ቢ")) + HtK4o2sTPgA78U(u"ูࠫࠥวฺหࠣๅ็฽ࠠ࠯ࠢฦ้ฬࠦแฮืࠣี็๋ࠠศๆศูิอัࠡใ฼้ึํࠠࠨၥ") + str(Qfob9ThC6ryqKkYZ/tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"࠸࠳ቢ")) + GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠬࠦฯใ์ๅอࠥ࠴ࠠฤ็สࠤๆำีࠡษืฮึอใࠡโࡌࡔ࡙࡜ࠠโ฻่ี์ࠦࠧၦ") + str(hI7SkXd94fFzAHNZCQoMqEutbnWP) + zmcGfOdvAjsELeJlP(u"࠭ࠠะไํๆฮ࠭ၧ")
	ggULVKqsMZbc1ynfBC7(vODxLKW5Ql6r4Fbm8(u"ࠧࡳ࡫ࡪ࡬ࡹ࠭ၨ"),AbqCJZdWQP9j(u"ࠨ็สࠤ์๎ࠠศๆๆหูࠦวๅ็ึฮำีๅࠡใํࠤฬ๊ศา่ส้ั࠭ၩ"),E8ZibMeyGK,UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬၪ"))
	return
def x0YcHamuj7EyD1vJAQ6s5XPgS():
	aZtYlicqMKUFPkBCX2AONHwJ4 = FRYcH4KL7e9gv5pEB(u"ࠪห้็วึๆฬࠤฯ฿ๆ๋่ࠢะ้ีࠠษ่ไืࠥอำๆ้ࠣห้ษีๅ์ࠣ์ฬ๊ๆใูฬࠤฯ฿ๆ๋ࠢฦ๊ࠥอไศี่ࠤฬ๊รึๆํࠤฯ๋ࠠห฻า๎้ํ้ࠠใสู้ฯ้่ࠠๅ฻ฮࠦสฺ่์ࠤ๊าไะ๋ࠢฮ๊ࠦสฺัํ่ࠥอำๆ้ࠣ์อี่็ࠢ฼่ฬ๋ษࠡฬ฼๊๏ࠦๅๅใࠣฬ๋็ำࠡษึ้์ࠦวๅลุ่๏࠭ၫ")
	bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,PtkEvXAqif14G20QZsaSyT(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧၬ"),aZtYlicqMKUFPkBCX2AONHwJ4)
	return
def Q9yNg2tHVxUMEfsn7A():
	aZtYlicqMKUFPkBCX2AONHwJ4 = FRYcH4KL7e9gv5pEB(u"ࠬหะศ๋ࠢหัํสไุ่่๊ࠢษࠡใํࠤฬ๊ิษๅฬࠤํะๅࠡฯ็๋ฬࠦ࠮࠯࠰ࠣวํࠦว็ๅࠣฮ฽์ࠠฤ่ࠣห้๋่ใ฻ࠣห้ษีๅ์ࠣ็ฬ์ࠠโ์๊ࠤฺ๊ใๅห้ࠣษ่ส่๋ࠢฮ๊ࠦอๅ้สࠤ࠳࠴࠮ࠡใศิ๋ࠦฬาสุ้ࠣำࠠไษืࠤฬ๊ศา่ส้ัࠦไไ์ࠣ๎็๎ๅࠡษ็ฬึ์วๆฮࠣฬ฼๊ศࠡษ็ูๆำษࠡษ็ูา๐อส๋ࠢฮำุ๊็้สࠤอีไศ่๊ࠢࠥอไึใะอࠥอไใัํ้ฮ࠭ၭ")
	bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,XrTw01KtLzbpoyMf(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩၮ"),aZtYlicqMKUFPkBCX2AONHwJ4)
	return
def Jcb5o3xKyLNXmgkIrwVeu():
	aZtYlicqMKUFPkBCX2AONHwJ4 = yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠧศๆ฽ี฻ࠦๅ็ࠢื๋ฬีษࠡษ็ฮู็๊า๊ࠢ์ࠥ฼ๅศู่ࠣาฯ้ࠠีิ๎ฮࠦวๅ็฼่ํ๋วหࠢส่๊ะศศั็อࠥฮ๊็ࠢส่อืๆศ็ฯࠤํอไๆ๊ๅ฽ࠥอไๆึไีࠥ๎็ัษࠣห้฼ๅศ่ࠣ฾๏ืࠠๆู็์อ่ࠦๅษࠣัฬาษࠡๆ๊ࠤ฾์ฯࠡษ็หฯ฻วๅࠢส์ࠥอไาสฺࠤ๊฿ࠠๆ๊สๆ฾ࠦวๅใํำ๏๎็ศฬࠣห้๋ิโำฬࠫၯ")
	bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫၰ"),aZtYlicqMKUFPkBCX2AONHwJ4)
	return
def BwqbG4onx0V3OE5sFH9PaSjIl():
	bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬၱ"),AbqCJZdWQP9j(u"่่ࠪ๐๋ࠠ฻่่ࠥํะศࠢส่๋๎ูࠡ็้ࠤฬ๊แ๋ัํ์์อสࠡ࡞ࡱࠤ๏าศࠡฬไ฽๏๊ࠠฦุสๅฮࠦวิ็๊หࠥࡢ࡮ࠡ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡡࡥࡣࡳࡸ࡮ࡼࡥࠨၲ"))
	nv2FxBURGbaTYX(XrTw01KtLzbpoyMf(u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡤࡨࡦࡶࡴࡪࡸࡨࠫၳ"),rGPen6cSMHQkAywh8vqI9JXiD2)
	return
def GvhqOXzHiW1DoxnkLa49tAZU():
	aZtYlicqMKUFPkBCX2AONHwJ4  = y6y5HtgXO4TkUbwVZ(u"๋ࠬฤฯำสࠤ็อๅหࠢห฽฻ࠦิาๅสฮࠥอไฦ่อี๋ะࠠศๆา์้๐ࠠษู๊฽ࠥ฿ววไฺࠣิࠦวๅสิห๊าࠠๆอ็ࠤ่๎ฯ๋ࠢ็ฮุ๋อࠡใๅ฻๊ࠥศฺุุ้ࠣะฮะ็ํࠤฬ๊ๅหืไัࠥฮวๅัั์้ࠦไๆ๊สๆ฾ࠦวๅใํำ๏๎ࠧၴ")
	aZtYlicqMKUFPkBCX2AONHwJ4 += zmcGfOdvAjsELeJlP(u"้่࠭ࠠอ๎ัฯࠠๅ้ำหࠥอไฺษษๆࠥ็ว็้ࠣฮ็ื๊ษษࠣะ๊๐ูࠡ็ึฮำีๅ๋ࠢหี๋อๅอࠢๆ์ิ๐ࠠๅษࠣ๎ุะื๋฻๋๊ࠥอไะะ๋่๊ࠥฬๆ์฼ࠤ๊๎วใ฻ࠣห้ฮั็ษ่ะࠥำส๊่ࠢ฽ࠥอำหะาห๊࠭ၵ")
	aZtYlicqMKUFPkBCX2AONHwJ4 += OTlVEGYPSxsNaBdXUucqA3+PSwfZcdRYhpl5Igqz8xOEk67+HtK4o2sTPgA78U(u"ࠧแ࡚ࠢࠣࡕࡔࠠࠡล๋ࠤࠥࡖࡲࡰࡺࡼࠤࠥษ่ࠡࠢࡇࡒࡘࠦࠠฤ๊ࠣว๏ࠦอๅࠢหื๏฽ࠠระิࠫၶ")+YoQW601K4fMJcsreDnGVE5wUZIy7+OTlVEGYPSxsNaBdXUucqA3
	aZtYlicqMKUFPkBCX2AONHwJ4 += HtK4o2sTPgA78U(u"ࠨ࡞ࡱ่ฬ์่ࠠาสࠤ้์๋ࠠฯ็ࠤฬ๊ๅีๅ็อࠥ๎ล็็สࠤๆ่ืࠡีํๆํ๋ࠠษวุ่ฬำࠠษ฻ูࠤฬ๊ๅ้ษๅ฽ࠥ๎ลฺษๅอ๋่ࠥศไ฼ࠤฬิั๊ࠢๆห๋ะࠠห฻ู่่ࠥวษไสࠤอี่็ุ่ࠢฬ้ไࠨၷ")
	ggULVKqsMZbc1ynfBC7(Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠩࡵ࡭࡬࡮ࡴࠨၸ"),TlGXWLYsV1z(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ၹ"),aZtYlicqMKUFPkBCX2AONHwJ4,TlGXWLYsV1z(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧၺ"))
	aZtYlicqMKUFPkBCX2AONHwJ4 = yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠬอไๆ๊สๆ฾ࠦวๅฬํࠤฯษหาฬࠣฬฬู๊ศศๅࠤ฾์ฯࠡส฼ฺࠥอไ็ษึࠤ์๐࠺ࠨၻ")
	aZtYlicqMKUFPkBCX2AONHwJ4 += OTlVEGYPSxsNaBdXUucqA3+PSwfZcdRYhpl5Igqz8xOEk67+uuExaKGL7UONtevRd(u"࠭ࡡ࡬ࡱࡤࡱࠥࠦࡥࡨࡻࡥࡩࡸࡺࠠࠡࡧࡪࡽࡧ࡫ࡳࡵࡸ࡬ࡴࠥࠦ࡭ࡰࡸ࡬ࡾࡱࡧ࡮ࡥࠢࠣࡷࡪࡸࡩࡦࡵ࠷ࡻࡦࡺࡣࡩࠢࠣࡷ࡭ࡧࡨࡪࡦ࠷ࡹࠬၼ")+YoQW601K4fMJcsreDnGVE5wUZIy7
	aZtYlicqMKUFPkBCX2AONHwJ4 += ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠧ࡝ࡰ࡟ࡲࠬၽ")+jXE2YHkswT8y(u"ࠨษ็ำํ๊ࠠศๆอ๎ࠥะรฬำอࠤออไฺษษๆࠥ฿ๆะࠢห฽฻ࠦวๅ่สืࠥํ๊࠻ࠩၾ")
	aZtYlicqMKUFPkBCX2AONHwJ4 += OTlVEGYPSxsNaBdXUucqA3+PSwfZcdRYhpl5Igqz8xOEk67+hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ู่ࠩึࠦࠠศๆๆ์๏ะࠠࠡล่๎ึ้วࠡࠢๆ๊ิอࠠࠡใิุ๊อࠠࠡษ็๎ํ์ว็ࠢࠣฬึ๐ืศ่ํหࠥอไฦ็สีฬะࠠฤๆ่ห๋๐วࠡำ๋ื๏อࠠศๆํหออๆࠡษ็ื฾๎ฯ๋หࠣีํ๋ว็์สࠤ์๎ไ็ัสࠫၿ")+YoQW601K4fMJcsreDnGVE5wUZIy7
	aZtYlicqMKUFPkBCX2AONHwJ4 += tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠪࡠࡳࡢ࡮ࠨႀ")+tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠫฬ๊ๅษำ่ะࠥ๎ฬะฺࠢี๏่ษࠡๆอะฬ๎าࠡษ็฽ฬฬโ๊ࠡ็็๋ํวࠡฬะฮฬาࠠอ้าࠤ่ฮ๊า๋ࠢห้๋ศา็ฯࠤ๏฾ๆࠡษ็ู้้ไสุࠢ฾๏ืษ๊ࠡ็หࠥะำหฯๅࠤฬ๊สฺสࠣๅสึวࠡๆา๎่ࠦๅีๅ็อࠥฮวๅัั์้ࠦไษ฻ูࠤฬ๊ๅ้ษๅ฽ࠥ๎รุ๋สࠤ้้๊ࠡ์อฺาࠦออ็ࠣห้๋ิไๆฬࠤࠬႁ")
	aZtYlicqMKUFPkBCX2AONHwJ4 += PSwfZcdRYhpl5Igqz8xOEk67+zmcGfOdvAjsELeJlP(u"ࠬอัิๆࠣีุอไส่ࠢศิฮษࠡว็ํࠥอไๆสิ้ั่ࠦศๅอฬࠥ็๊่ษࠣหุ๋ࠠษๆา็ࠥ๎ริ็สลࠥอไๆ๊สๆ฾ࠦวๅฬํࠤ้อࠠหีอ฻๏฿ࠠะะ๋่์อࠧႂ")+YoQW601K4fMJcsreDnGVE5wUZIy7
	ggULVKqsMZbc1ynfBC7(TlGXWLYsV1z(u"࠭ࡲࡪࡩ࡫ࡸࠬႃ"),TlGXWLYsV1z(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪႄ"),aZtYlicqMKUFPkBCX2AONHwJ4,MgP8OjoaiWQEVG59(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫႅ"))
	return
def ymLtCKv1UwT40WDa():
	bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠩฮ่ฬัุࠠำๅࠤ้๊ส้ษุู่๋ࠥࠡษ็้อืๅอࠩႆ"),uuExaKGL7UONtevRd(u"ࠪวึูไࠡำึห้ฯࠠฤู๊้้ࠣไส่๊่ࠢࠥวว็ฬࠤำีๅศฬ๋ࠣีอࠠศๆหี๋อๅอ࡞ࡱࡠࡳษ่ࠡสสืฯิฯศ็ࠣห้็๊ิส๋็ࠥษฯ็ษ๊ࡠࡳ࠭ႇ")+PSwfZcdRYhpl5Igqz8xOEk67+jXE2YHkswT8y(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࡫ࡧࡣࡦࡤࡲࡳࡰ࠴ࡣࡰ࡯࠲ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴ࠴࠳࠵࠽࠭ႈ")+YoQW601K4fMJcsreDnGVE5wUZIy7+UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠬࡢ࡮࡝ࡰฦ์ࠥฮวาีส่ࠥอ๊ๆ์็ࠤฬ๊้ࠡลา๊ฬํࠠࠡ࡞ࡱࠤࠬႉ")+PSwfZcdRYhpl5Igqz8xOEk67+tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"࠭ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷ࠷࠶࠱࠹ࡂࡪࡱࡦ࡯࡬࠯ࡥࡲࡱࠬႊ")+YoQW601K4fMJcsreDnGVE5wUZIy7)
	return
def qbEWmInyuwF98xPGBOVgvipohZ():
	KKDcbX7IGg1Y()
	U17QqF2gkI46 = A1AXKupEOfz(tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠧࡤࡧࡱࡸࡪࡸࠧႋ"),iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠨ้็ࠤฯื๊ะ่ࠢืาࠦฬๆ์฼ࠤฬ๊ใศึࠣรࠬႌ"),ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠩส่่อิࠡ์ึี฾ูࠦๆๆࠣห้ฮั็ษ่ะࠥ๎ๅิฯ๊ࠤ๏฿๊ะࠢึัอࠦวๅืไัฬะࠠๆ่ࠣห้หๆหำ้ฮࠥ฿ๆะࠢส่าอฬสࠢศ่๏ํว๊ࠡสู่๊อࠡ์อ้ࠥะไใษษ๎ฬูࠦ็ัࠣห๋ะ็ศรࠣ฽๊ืࠠศๆุๅาอส๊ࠡสู่๊อࠡๆสࠤ๏฼ั๊่้่ࠡ์๋ࠠฯ็ࠤอ฿ึࠡษ็ู้อใๅႍࠩ"))
	if U17QqF2gkI46==ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"࠵ቤ"):
		FkOnysh4X7mNU9(rGPen6cSMHQkAywh8vqI9JXiD2)
		bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,LyNiIHPOwD3hCUYEFM7(u"ࠪฮ๊ࠦๅิฯࠣ็ฬฺࠠศๆหี๋อๅอࠢหห้้วๆๆࠪႎ"),YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠫสึวࠡๅส๊ฯูࠦ็ัๆࠤฺ๊ใๅหࠣๅ๏ࠦวฮัࠣห้๋่ศไ฼ࠤๆาัษࠢส่๊๎โฺࠢส่ว์ࠠ࠯࠰࠱ࠤํษะศࠢสฺ่๊ใๅหุ้ࠣะๅาหࠣๅสึๆࠡษิื้ࠦวๅ็ื็้ฯࠠฦๆ์ࠤฬ๊ๅษำ่ะࠬႏ"))
	return U17QqF2gkI46
def EEVYtKCnIFLef8(showDialogs=rGPen6cSMHQkAywh8vqI9JXiD2):
	if not showDialogs: showDialogs = rGPen6cSMHQkAywh8vqI9JXiD2
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(hI7SkXd94fFzAHNZCQoMqEutbnWP,GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠬࡍࡅࡕࠩ႐"),YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦࡺࡤࡱࡵࡲࡥ࠯ࡥࡲࡱࠬ႑"),iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,BF6QAiLUNHh7rKOugaw,iiy37aKq0pCEIOwfcTh61xb4U,sVzojQerUqX(u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࡋࡘ࡙ࡖࡓࡠࡖࡈࡗ࡙࠳࠱ࡴࡶࠪ႒"))
	if not oCJ8TdG2LwSIVcbaUnhB.succeeded:
		EIJBARyVzlH7sWpqMNKke4cOuU = BF6QAiLUNHh7rKOugaw
		SWDcPHa03GEyls9UnN = mkT7KMxSV1PvEr5(BF6QAiLUNHh7rKOugaw)
		WKquk5EaNr4RzVf(uiza5vIyTWtUeB8sXwAVYMFpgjrk,IIZ4e82HBP0oTmtOgaWY7hsMz(sQU2GnRoMwLK8CBdfzmNr4jXyO)+MgP8OjoaiWQEVG59(u"ࠨࠢࠣࠤࡍ࡚ࡔࡑࡕࠣࡊࡦ࡯࡬ࡦࡦࠣࠤࠥࡒࡡࡣࡧ࡯࠾ࡠ࠭႓")+SWDcPHa03GEyls9UnN+sVzojQerUqX(u"ࠩࡠࠫ႔"))
		if showDialogs: bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭႕"),xpT28sXu051(u"ࠫๆำีࠡษ็หฯ฻วๅࠢสฺ่๊แาࠢ࠱࠲࠳ࠦๅีๅ็อࠥ࠴࠮࠯ࠢส่ฬะีศๆࠣห้๋ิโำࠣࠬฬ๊ัษูࠣห้๋ิโำࠬࠤ้อ๋ࠠ฻่่ࠥ฿ๆะๅࠣ฽้๏ࠠไ๊า๎ࠥ࠴࠮࠯๋ࠢ฽๋ีใࠡๅ๋ำ๏ฺ๋ࠦำࠣๆฬีัࠡ฻็ํࠥอำหะาห๊ࠦวๅ็๋ห็฿ࠠศๆุ่ๆืษࠨ႖"))
	else:
		EIJBARyVzlH7sWpqMNKke4cOuU = rGPen6cSMHQkAywh8vqI9JXiD2
		if showDialogs: bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,HtK4o2sTPgA78U(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ႗"),HtK4o2sTPgA78U(u"࠭ฬ๋ัࠣะิอࠠ࠯࠰࠱ࠤฬ๊วหืส่ࠥอไๆึไีࠥ࠮วๅำห฻ࠥอไๆึไี࠮ฺ๊ࠦ็็ࠤ฾์ฯไ๋ࠢห้ฮั็ษ่ะ่ࠥวะำࠣ฽้๏ࠠศีอาิอๅࠡษ็้ํอโฺࠢสฺ่๊แาหࠪ႘"))
	if not EIJBARyVzlH7sWpqMNKke4cOuU and showDialogs: N8NmdpeEDcMnZ63()
	return EIJBARyVzlH7sWpqMNKke4cOuU
def N8NmdpeEDcMnZ63():
	bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ႙"),jXE2YHkswT8y(u"ࠨส฼ฺࠥอไๆ๊สๆ฾ࠦสฮฬสะࠥืศุุ่ࠢๆื้ࠠไาࠤ๏้่็ࠢฯ๋ฬุใࠡ฼ํี่ࠥวะำࠣ฽้๏ࠠศๆิฬ฼ࠦวๅ็ืๅึࠦร้๊๊ࠢฬ้ࠠๆึๆ่ฮࠦแ๋ࠢื๋ฬีษࠡษ็ฮู็๊าࠢส่ำอีสࠢห็ํี๊ࠡ฻้ำู่ࠦๅ็สࠤฬ์็ࠡฬ่ࠤๆำีࠡษ็ฬึ์วๆฮࠣ฽้๏ࠠไ๊า๎ࠥอไฦืาหึอสࠡ࡞ࡱࠤ࠶࠽࠮࠷ࠢࠣࠪࠥࠦ࠱࠹࠰࡞࠴࠲࠿࡝ࠡࠢࠩࠤࠥ࠷࠹࠯࡝࠳࠱࠸ࡣࠧႚ"))
	yhTBUcFtLgo()
	return
def fmS1GJHNpqKyxE7u5bA(U94JwhRgpXCOe5=iiy37aKq0pCEIOwfcTh61xb4U):
	fcBu5mjy96oVdizMUI = rGPen6cSMHQkAywh8vqI9JXiD2
	if xpT28sXu051(u"ࠩࡢࡔࡗࡕࡂࡍࡇࡐࡣࠬႛ") not in U94JwhRgpXCOe5:
		fcBu5mjy96oVdizMUI = BF6QAiLUNHh7rKOugaw
		RzBbfLYvm4Fgja7GcwCHMnX0K = Ny92sqomMkizpgKV1(y6y5HtgXO4TkUbwVZ(u"ࠪࡧࡪࡴࡴࡦࡴࠪႜ"),tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠫำื่อࠩႝ"),XrTw01KtLzbpoyMf(u"ࠬหัิษ็ࠤฺ๊ใๅหࠪ႞"),HtK4o2sTPgA78U(u"࠭ลาีส่ࠥืำศๆฬࠫ႟"),CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪႠ"),SaB5hx3PZwXRLtKgrTfQvId(u"ࠨ้็ࠤฯื๊ะࠢฦ๊ࠥะัิๆࠣีุอไสࠢศ่๎ࠦวๅ็หี๊าࠠ࠯࠰ࠣว๊ࠦสา์าࠤศ์ࠠหำึ่๋ࠥิไๆฬࠤ๊๎ฬ้ัฬࠤๆ๐ࠠศๆหี๋อๅอࠢยࠫႡ"))
		if RzBbfLYvm4Fgja7GcwCHMnX0K in [-ZchUJdM93pTA7zG5(u"࠶ብ"),JZszNnIEMAx28Yao0yqhiXGKOPb(u"࠶ቦ")]: return
		elif RzBbfLYvm4Fgja7GcwCHMnX0K==UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"࠱ቧ"):
			fcBu5mjy96oVdizMUI = rGPen6cSMHQkAywh8vqI9JXiD2
			U94JwhRgpXCOe5 = LyNiIHPOwD3hCUYEFM7(u"ࠩࡢࡔࡗࡕࡂࡍࡇࡐࡣࠬႢ")
	if fcBu5mjy96oVdizMUI:
		if ZchUJdM93pTA7zG5(u"ࠪࡣࡕࡘࡏࡃࡎࡈࡑࡤࡕࡌࡅࡡࠪႣ") not in U94JwhRgpXCOe5:
			U17QqF2gkI46 = A1AXKupEOfz(LyNiIHPOwD3hCUYEFM7(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫႤ"),iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠬ๎ึฺࠢสฺ่๊ใๅหࠣๅ๏ࠦวๅีฯ่ࠬႥ"),uuExaKGL7UONtevRd(u"࠭โษๆࠣษึูวๅࠢสุ่าไࠡ฻็๎่ࠦร็ࠢอ็ึื่ࠠࠡไืࠥอไโ฻็ࠤฬ๊ะ๋ࠢฦ฽฼อใࠡษ็ู้้ไสࠢ࠱ࠤ้้๊ࠡ์อ้ࠥะำอ์็ࠤ์ึ็ࠡษ็ู้้ไสࠢไ๎ูࠥฬๅࠢส่ศิืศรࠣ์ฬ๊วิฬัำฬ๋ࠠ࠯๋ࠢฬิ๎ๆ้ࠡำหࠥอไหีฯ๎้ࠦำ้ใࠣฮึูไࠡ็็ๅ๊ࠥวࠡใสสิฯࠠๆ่๊ࠤ้หๆ่ࠢ็หࠥ๐อห๊ํࠤ฾๊้ࠡษ็ู้้ไสࠢส่ฯ๐ࠠหำํำࠥอๆหࠢส่สฮไศ฼ࠣ฽๋ํวࠡ࠰๋้ࠣࠦโๆฬࠣฬฯ้ัศำࠣห้๋ิไๆฬࠤฤ࠭Ⴆ"))
			if U17QqF2gkI46!=XrTw01KtLzbpoyMf(u"࠲ቨ"):
				bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,AbqCJZdWQP9j(u"ࠧห็ࠣษ้เวยࠢส่สืำศๆࠪႧ"),EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠨๆ็วุ็ࠠษั๋๊ࠥะำอ์็ࠤฬ๊ๅีๅ็อࠥ็๊ࠡีฯ่ࠥอไฤะฺหฦ่ࠦศๆสืฯิฯศ็ࠣๅฬ์ࠠศๆ่ฬึ๋ฬࠡๆสࠤ๏ูสุ์฼ࠤ๊฿ัโหࠣห้๋ิไๆฬࠤํ๊วࠡฯ็๋ฬࠦไศ่ࠣห้๋ศา็ฯࠤ้อ๋ࠠ฻็้ࠥอไ฻์หࠫႨ"))
				return
	bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬႩ"),CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠪๅ๏ࠦวๅึสุฮࠦวๅไสำ๊ฯࠠฮษ๋่ࠥษๆࠡฬๆฮอࠦัิษ็อࠥหไ๊ࠢส่๊ฮัๆฮࠣ์ฬฺัฮࠢไ๎์อࠠศๆุ่่๊ษࠡล๋ࠤฬ๊ๅุ้๋฽ࠥ๎ลัษࠣวึีสࠡฮ๋หอࠦๅ็ࠢส่๊ฮัๆฮࠣๅสึๆࠡลๆฮอูࠦ็๊ส๊ࠥฮั๋ัๆࠤศ๊ลๅๅอีํ์๊ࠡษ็ษ๏๋๊ๅ๋ࠢฮี้ั๊ࠡ็หࠥะๆิ๋ࠣว๋ࠦวๅ็หี๊าࠠๅษࠣ๎฾๊ๅࠡษ็฾๏ฮࠧႪ"))
	search = TTBf6S08q1NKXd5v9wa(header=YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠫ࡜ࡸࡩࡵࡧࠣࡥࠥࡳࡥࡴࡵࡤ࡫ࡪ࡫ࠠࠡࠢส็ฯฮࠠาีส่ฮ࠭Ⴋ"),source=sQU2GnRoMwLK8CBdfzmNr4jXyO)
	if not search: return
	aZtYlicqMKUFPkBCX2AONHwJ4 = search
	if fcBu5mjy96oVdizMUI: type = PtkEvXAqif14G20QZsaSyT(u"ࠬࡖࡲࡰࡤ࡯ࡩࡲ࠭Ⴌ")
	else: type = sVzojQerUqX(u"࠭ࡍࡦࡵࡶࡥ࡬࡫ࠧႭ")
	M5qyIg2dZlm6FxH4tTPV79okNu0bCG = EmxZ2PWFGSaYQNkclpnVsR(type,aZtYlicqMKUFPkBCX2AONHwJ4,rGPen6cSMHQkAywh8vqI9JXiD2,iiy37aKq0pCEIOwfcTh61xb4U,Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠧࡆࡏࡄࡍࡑ࠳ࡆࡓࡑࡐ࠱࡚࡙ࡅࡓࡕࠪႮ"),U94JwhRgpXCOe5)
	return
def ox0nXeNGCZcHL6BROUmfaJkqItErF():
	U94JwhRgpXCOe5 = MgP8OjoaiWQEVG59(u"ࠨ้ำหࠥอไษำ้ห๊าࠠๅษࠣ๎ําฯࠡๆ๊ࠤศ๐ࠠิ์ิๅึ๊ࠦิฬู๎ๆࠦร๋่ࠢัฯ๎๊ศฬ࠱ࠤฬ๊ศา่ส้ั๊ࠦิฬัำ๊ࠦั้ษห฻ࠥ๎สื็ํ๊๊ࠥๅฮฬ๋๎ฬะࠠๆำไ์฾ฯฺࠠๆ์ࠤุ๐ัโำสฮࠥิวาฮํอ࠳ࠦวๅสิ๊ฬ๋ฬࠡ฼ํี๋ࠥำล๊็ࠤ฾์ࠠฤ์้ࠣาะ่๋ษอࠤฯ๋ࠠหฯ่๎้ํวࠡ฻็ํู๊ࠥาใิหฯ่ࠦๆ๊สๆ฾ࠦฮศำฯ๎ฮࠦࠢๆ๊สๆ฾ࠦืาใࠣฯฬ๊หࠣ࠰ࠣะ๊๐ูࠡษ็วุ๋วย๋ࠢห้๋วาๅสฮࠥ๎วๅื๋ีࠥ๎วๅ็ุ้ํืวห๊ࠢ๎ࠥิวึหࠣฬฬ฻อศส๊ห࠳ࠦวๅสิ๊ฬ๋ฬࠡๆสࠤ๏์ส่ๅࠣั็๎โࠡษ็฻อ฿้ࠠษ็ู๊ื้ࠠไส๊ํ์ࠠศๆฦ่ๆ๐ษࠡๆ็้้้๊สࠢส่ึ่ๅ๋หࠣࡈࡒࡉࡁࠡวำห้ࠥว็ࠢ็ำ๏้ࠠีๅ๋ํࠥิวึหࠣฬฬ๊ั้ษห฻ࠥ๎วๅฬูห๊๐ๆࠡษ็าฬืฬ๋หࠣๅฬ๊ัอษฤࠤฬ๊ส้ษุู่๋ࠥࠡวาหึฯ่ࠠา๊ࠤฬ๊ำ๋ำไีฬะ้ࠠษ็้ํอโฺࠢส่ำอัอ์ฬ࠲ࠥํะศࠢส่อืๆศ็ฯࠤ์๎ࠠษสึห฼ฯࠠๆฬุๅาࠦไๆ๊สๆ฾ࠦวๅ๊ํฬࠬႯ")
	ggULVKqsMZbc1ynfBC7(AbqCJZdWQP9j(u"ࠩࡵ࡭࡬࡮ࡴࠨႰ"),HtK4o2sTPgA78U(u"ࠪั็๎โࠡษ็฻อ฿้ࠠษ็ู๊ื้ࠠไส๊ํ์ࠠศๆฦ่ๆ๐ษࠡๆ็้้้๊สࠢส่ึ่ๅ๋หࠪႱ"),U94JwhRgpXCOe5,UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧႲ"))
	U94JwhRgpXCOe5 = JZszNnIEMAx28Yao0yqhiXGKOPb(u"࡚ࠬࡨࡪࡵࠣࡴࡷࡵࡧࡳࡣࡰࠤࡩࡵࡥࡴࠢࡱࡳࡹࠦࡨࡰࡵࡷࠤࡦࡴࡹࠡࡥࡲࡲࡹ࡫࡮ࡵࠢࡲࡲࠥࡧ࡮ࡺࠢࡶࡩࡷࡼࡥࡳ࠰ࠣࡍࡹࠦ࡯࡯࡮ࡼࠤࡺࡹࡥࡴࠢ࡯࡭ࡳࡱࡳࠡࡶࡲࠤࡪࡳࡢࡦࡦࡧࡩࡩࠦࡣࡰࡰࡷࡩࡳࡺࠠࡵࡪࡤࡸࠥࡽࡡࡴࠢࡸࡴࡱࡵࡡࡥࡧࡧࠤࡹࡵࠠࡱࡱࡳࡹࡱࡧࡲࠡࡱࡱࡰ࡮ࡴࡥࠡࡸ࡬ࡨࡪࡵࠠࡩࡱࡶࡸ࡮ࡴࡧࠡࡵ࡬ࡸࡪࡹ࠮ࠡࡃ࡯ࡰࠥࡺࡲࡢࡦࡨࡱࡦࡸ࡫ࡴ࠮ࠣࡺ࡮ࡪࡥࡰࡵ࠯ࠤࡹࡸࡡࡥࡧࠣࡲࡦࡳࡥࡴ࠮ࠣࡷࡪࡸࡶࡪࡥࡨࠤࡲࡧࡲ࡬ࡵ࠯ࠤࡨࡵࡰࡺࡴ࡬࡫࡭ࡺࡥࡥࠢࡺࡳࡷࡱࠬࠡ࡮ࡲ࡫ࡴࡹࠠࡳࡧࡩࡩࡷ࡫࡮ࡤࡧࡧࠤ࡭࡫ࡲࡦ࡫ࡱࠤࡧ࡫࡬ࡰࡰࡪࠤࡹࡵࠠࡵࡪࡨ࡭ࡷࠦࡲࡦࡵࡳࡩࡨࡺࡩࡷࡧࠣࡳࡼࡴࡥࡳࡵࠣ࠳ࠥࡩ࡯࡮ࡲࡤࡲ࡮࡫ࡳ࠯ࠢࡗ࡬ࡪࠦࡰࡳࡱࡪࡶࡦࡳࠠࡪࡵࠣࡲࡴࡺࠠࡳࡧࡶࡴࡴࡴࡳࡪࡤ࡯ࡩࠥ࡬࡯ࡳࠢࡺ࡬ࡦࡺࠠࡰࡶ࡫ࡩࡷࠦࡰࡦࡱࡳࡰࡪࠦࡵࡱ࡮ࡲࡥࡩࠦࡴࡰࠢ࠶ࡶࡩࠦࡰࡢࡴࡷࡽࠥࡹࡩࡵࡧࡶ࠲ࠥ࡝ࡥࠡࡷࡵ࡫ࡪࠦࡡ࡭࡮ࠣࡧࡴࡶࡹࡳ࡫ࡪ࡬ࡹࠦ࡯ࡸࡰࡨࡶࡸ࠲ࠠࡵࡱࠣࡶࡪࡩ࡯ࡨࡰ࡬ࡾࡪࠦࡴࡩࡣࡷࠤࡹ࡮ࡥࠡ࡮࡬ࡲࡰࡹࠠࡤࡱࡱࡸࡦ࡯࡮ࡦࡦࠣࡻ࡮ࡺࡨࡪࡰࠣࡸ࡭࡯ࡳࠡࡲࡵࡳ࡬ࡸࡡ࡮ࠢࡤࡶࡪࠦ࡬ࡰࡥࡤࡸࡪࡪࠠࡴࡱࡰࡩࡼ࡮ࡥࡳࡧࠣࡩࡱࡹࡥࠡࡱࡱࠤࡹ࡮ࡥࠡࡹࡨࡦࠥࡵࡲࠡࡸ࡬ࡨࡪࡵࠠࡦ࡯ࡥࡩࡩࡪࡥࡥࠢࡤࡶࡪࠦࡦࡳࡱࡰࠤࡴࡺࡨࡦࡴࠣࡺࡦࡸࡩࡰࡷࡶࠤࡸ࡯ࡴࡦࡵ࠱ࠤࡎ࡬ࠠࡺࡱࡸࠤ࡭ࡧࡶࡦࠢࡤࡲࡾࠦ࡬ࡦࡩࡤࡰࠥ࡯ࡳࡴࡷࡨࡷࠥࡶ࡬ࡦࡣࡶࡩࠥࡩ࡯࡯ࡶࡤࡧࡹࠦࡡࡱࡲࡵࡳࡵࡸࡩࡢࡶࡨࠤࡲ࡫ࡤࡪࡣࠣࡪ࡮ࡲࡥࠡࡱࡺࡲࡪࡸࡳࠡ࠱ࠣ࡬ࡴࡹࡴࡦࡴࡶ࠲࡚ࠥࡨࡪࡵࠣࡴࡷࡵࡧࡳࡣࡰࠤ࡮ࡹࠠࡴ࡫ࡰࡴࡱࡿࠠࡢࠢࡺࡩࡧࠦࡢࡳࡱࡺࡷࡪࡸ࠮ࠨႳ")
	ggULVKqsMZbc1ynfBC7(HtK4o2sTPgA78U(u"࠭࡬ࡦࡨࡷࠫႴ"),tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠧࡅ࡫ࡪ࡭ࡹࡧ࡬ࠡࡏ࡬ࡰࡱ࡫࡮࡯࡫ࡸࡱࠥࡉ࡯ࡱࡻࡵ࡭࡬࡮ࡴࠡࡃࡦࡸࠥ࠮ࡄࡎࡅࡄ࠭ࠬႵ"),U94JwhRgpXCOe5,ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫႶ"))
	return
def TV4nOeQNmRscB():
	bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬႷ"),PtkEvXAqif14G20QZsaSyT(u"ࠪห้ฮั็ษ่ะ๊ࠥวࠡ์ไัฺࠦิ่ษาอࠥอไหึไ๎ึูࠦ็ัࠣห้อสึษ็ࠤออไๆ๊สๆ฾ࠦวๅ็ืๅึฯ้ࠠๆ๊ิฬࠦแ๋ࠢะห้่ࠦอ๊าࠤูํวะหࠣ฾๏ืࠠึฯํัฮࠦร้่๊ࠢฯํ๊สࠢสฺ่๊วฮ์ฬࠤศ๎ࠠๆิํๅฮࠦแศ่๋ࠣีอࠠๅ่ࠣ๎ํ่แࠡษ็ีอ฽ࠠศๆุ่ๆื้ࠠๆ้ࠤ๏๎โโࠢ฼้้ࠦวๅสิ๊ฬ๋ฬࠨႸ"))
	Jcb5o3xKyLNXmgkIrwVeu()
	return
def ZdltrAxUJp5DcgRETz8isS1():
	ngZh3MbtFxsQAjGvyUJ67VN,E8ZibMeyGK,dANSkE5C2gKL4z7DTmuXBFR,ngWSHzwAk1r8oKB,URMJYy0oNZOLXW5zxElIsBnFfr7Tb,a6nyIkEVsvc7ibXSm1feqCUT,UsaTN0fzgjFQqX5Znk3JVI4yv8oHA = iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U
	Si4j3bXGLeno0zfxlm9ZOcy,keJjC2v7OHD8SfV,CFPkcxLivfQ,ax5OLdDBYpuNtib4QKlf7nyHVRSs9 = {ZchUJdM93pTA7zG5(u"ࠫࡦ࠭Ⴙ"):UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠬࡧࠧႺ")},{},[],{}
	url = gZ4LwbKaOm[tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭Ⴛ")][YYJQyRskpX8jv]
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(Qfob9ThC6ryqKkYZ,MgP8OjoaiWQEVG59(u"ࠧࡑࡑࡖࡘࠬႼ"),url,Si4j3bXGLeno0zfxlm9ZOcy,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕ࠰࡙ࡘࡇࡇࡆࡡࡕࡉࡕࡕࡒࡕ࠯࠴ࡷࡹ࠭Ⴝ"))
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	Vxz6OndPIX4g2kaRp7 = Vxz6OndPIX4g2kaRp7.replace(MgP8OjoaiWQEVG59(u"ࠩࡘࡲ࡮ࡺࡥࡥࠢࡖࡸࡦࡺࡥࡴࠩႾ"),y6y5HtgXO4TkUbwVZ(u"࡙ࠪࡘࡇࠧႿ"))
	Vxz6OndPIX4g2kaRp7 = Vxz6OndPIX4g2kaRp7.replace(tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"࡚ࠫࡴࡩࡵࡧࡧࠤࡐ࡯࡮ࡨࡦࡲࡱࠬჀ"),UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"࡛ࠬࡋࠨჁ"))
	Vxz6OndPIX4g2kaRp7 = Vxz6OndPIX4g2kaRp7.replace(y6y5HtgXO4TkUbwVZ(u"࠭ࡕ࡯࡫ࡷࡩࡩࠦࡁࡳࡣࡥࠤࡊࡳࡩࡳࡣࡷࡩࡸ࠭Ⴢ"),jXE2YHkswT8y(u"ࠧࡖࡃࡈࠫჃ"))
	Vxz6OndPIX4g2kaRp7 = Vxz6OndPIX4g2kaRp7.replace(AbqCJZdWQP9j(u"ࠨࡕࡤࡹࡩ࡯ࠠࡂࡴࡤࡦ࡮ࡧࠧჄ"),IpC4qHXRuyNFjzWv(u"ࠩࡎࡗࡆ࠭Ⴥ"))
	Vxz6OndPIX4g2kaRp7 = Vxz6OndPIX4g2kaRp7.replace(uuExaKGL7UONtevRd(u"ࠪࡒࡴࡸࡴࡩࠢࡐࡥࡨ࡫ࡤࡰࡰ࡬ࡥࠬ჆"),IpC4qHXRuyNFjzWv(u"ࠫࡓ࠴ࡍࡢࡥࡨࡨࡴࡴࡩࡢࠩჇ"))
	Vxz6OndPIX4g2kaRp7 = Vxz6OndPIX4g2kaRp7.replace(AbqCJZdWQP9j(u"ࠬ࡝ࡥࡴࡶࡨࡶࡳࠦࡓࡢࡪࡤࡶࡦ࠭჈"),YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"࠭ࡗ࠯ࡕࡤ࡬ࡦࡸࡡࠨ჉"))
	Vxz6OndPIX4g2kaRp7 = Vxz6OndPIX4g2kaRp7.replace(ZchUJdM93pTA7zG5(u"ࠧࡠࡡࡢࠫ჊"),Wc5GekRC0HQLz7)
	try: yvRSfJYGgQjAs1x2k9Mhi7U = DeIL3qoa2UBtYPb(ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠨ࡮࡬ࡷࡹ࠭჋"),Vxz6OndPIX4g2kaRp7)
	except:
		bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,XrTw01KtLzbpoyMf(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ჌"),L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠪๅู๊ࠠโ์ࠣะ้ฮࠠๆฯอ์๏อสࠡฬๅี๏ืࠠศๆสืฯิฯศ็ࠪჍ"))
		return
	kQMrDAdLYGybljRqsmJIx5u,lOY5oKi8DnJmGIk2yau,rvdoZOyq3LmDkiTUCfQPuBGn = yvRSfJYGgQjAs1x2k9Mhi7U
	ax5OLdDBYpuNtib4QKlf7nyHVRSs9 = {}
	eUQ7Oy2XPTrpGgdzHWM = [FRYcH4KL7e9gv5pEB(u"ࠫࡈࡇࡐࡕࡅࡋࡅࡎࡊࠧ჎"),tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠬࡉࡁࡑࡖࡆࡌࡆ࡚ࡏࡌࡇࡑࠫ჏")]
	ZaxLWd8E4ecU3vq = [vODxLKW5Ql6r4Fbm8(u"࠭ࡁࡍࡎࠪა"),FRYcH4KL7e9gv5pEB(u"ࠧࡑ࡛ࡗࡌࡔࡔࠧბ"),IpC4qHXRuyNFjzWv(u"ࠨࡋࡑࡗ࡙ࡇࡌࡍࠩგ"),tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠩࡐࡉ࡙ࡘࡏࡑࡑࡏࡍࡘ࠭დ"),MgP8OjoaiWQEVG59(u"ࠪࡖࡊࡖࡏࡔࠩე")]+eUQ7Oy2XPTrpGgdzHWM+bjiw4aZJOKMtpkrAFWug0vx3LNd2Ec+gsteZDpHaMmyQkBwC
	for ekEOd3mqAThaBDUoIrntuGRjYW,NIldG3O0nYu,VvOAeW4oEqP2FNKfaUwCHybjQkd in lOY5oKi8DnJmGIk2yau:
		VvOAeW4oEqP2FNKfaUwCHybjQkd = vvmT3DLXkhPBwIaOAo6srZpEnRVJC(VvOAeW4oEqP2FNKfaUwCHybjQkd)
		VvOAeW4oEqP2FNKfaUwCHybjQkd = VvOAeW4oEqP2FNKfaUwCHybjQkd.strip(iFBmE2MUIpSu34wsd7Rf6z).strip(UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠫࠥ࠴ࠧვ"))
		ngWSHzwAk1r8oKB += OTlVEGYPSxsNaBdXUucqA3+aqEsMBckT2bunGHfl48Wip+ekEOd3mqAThaBDUoIrntuGRjYW+y6y5HtgXO4TkUbwVZ(u"ࠬࡀࠠࠨზ")+YoQW601K4fMJcsreDnGVE5wUZIy7+VvOAeW4oEqP2FNKfaUwCHybjQkd+OTlVEGYPSxsNaBdXUucqA3
		if NIldG3O0nYu.isdigit():
			ax5OLdDBYpuNtib4QKlf7nyHVRSs9[ekEOd3mqAThaBDUoIrntuGRjYW] = int(NIldG3O0nYu)
			if int(NIldG3O0nYu)>IpC4qHXRuyNFjzWv(u"࠳࠳࠴ቩ"): NIldG3O0nYu = sVzojQerUqX(u"࠭ࡨࡪࡩ࡫ࡹࡸࡧࡧࡦࠩთ")
			else: NIldG3O0nYu = TlGXWLYsV1z(u"ࠧ࡭ࡱࡺࡹࡸࡧࡧࡦࠩი")
		if ekEOd3mqAThaBDUoIrntuGRjYW not in ZaxLWd8E4ecU3vq:
			if   NIldG3O0nYu==hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠨࡪ࡬࡫࡭ࡻࡳࡢࡩࡨࠫკ"): ngZh3MbtFxsQAjGvyUJ67VN += Wc5GekRC0HQLz7+ekEOd3mqAThaBDUoIrntuGRjYW
			elif NIldG3O0nYu==Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠩ࡯ࡳࡼࡻࡳࡢࡩࡨࠫლ"): E8ZibMeyGK += Wc5GekRC0HQLz7+ekEOd3mqAThaBDUoIrntuGRjYW
	Pykg42Yu9lLcptGM,Cp0gwtTcIom3,HAgcDVk6nYJEizN = list(zip(*lOY5oKi8DnJmGIk2yau))
	for ekEOd3mqAThaBDUoIrntuGRjYW in sorted(sdf5uU2hLnzVjQxcBJtGgP4EXyvOA):
		if ekEOd3mqAThaBDUoIrntuGRjYW not in Pykg42Yu9lLcptGM:
			ngWSHzwAk1r8oKB += OTlVEGYPSxsNaBdXUucqA3+aqEsMBckT2bunGHfl48Wip+ekEOd3mqAThaBDUoIrntuGRjYW+Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠪ࠾ࠥ࠭მ")+YoQW601K4fMJcsreDnGVE5wUZIy7+tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"้ࠫอ๋๊ࠠฯำࠬნ")+yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠬࡢ࡮࡝ࡰࠪო")
			if ekEOd3mqAThaBDUoIrntuGRjYW not in ZaxLWd8E4ecU3vq: dANSkE5C2gKL4z7DTmuXBFR += Wc5GekRC0HQLz7+ekEOd3mqAThaBDUoIrntuGRjYW
	for VvOAeW4oEqP2FNKfaUwCHybjQkd,d95dmOUNYHZsquy in kQMrDAdLYGybljRqsmJIx5u:
		VvOAeW4oEqP2FNKfaUwCHybjQkd = vvmT3DLXkhPBwIaOAo6srZpEnRVJC(VvOAeW4oEqP2FNKfaUwCHybjQkd)
		URMJYy0oNZOLXW5zxElIsBnFfr7Tb += VvOAeW4oEqP2FNKfaUwCHybjQkd+LyNiIHPOwD3hCUYEFM7(u"࠭࠺ࠡࠩპ")+PSwfZcdRYhpl5Igqz8xOEk67+str(d95dmOUNYHZsquy)+YoQW601K4fMJcsreDnGVE5wUZIy7+Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠧࠡࠢࠣࠫჟ")
	ngZh3MbtFxsQAjGvyUJ67VN = ngZh3MbtFxsQAjGvyUJ67VN.strip(iFBmE2MUIpSu34wsd7Rf6z)
	E8ZibMeyGK = E8ZibMeyGK.strip(iFBmE2MUIpSu34wsd7Rf6z)
	dANSkE5C2gKL4z7DTmuXBFR = dANSkE5C2gKL4z7DTmuXBFR.strip(iFBmE2MUIpSu34wsd7Rf6z)
	ndc28qGFgoxVZ1YOeQs4wR = ngZh3MbtFxsQAjGvyUJ67VN+Wc5GekRC0HQLz7+E8ZibMeyGK
	eWfZ8zVxDEnvBpt7ALl3yITuhKa5M  = HtK4o2sTPgA78U(u"ࠨ็๋ห็฿ࠠ็ฮะࠤฬ๊ศา่ส้ัࠦศหึ฽๎้ࠦแ๋ัํ์์อสࠡใํࠤ࠸ࠦร๋ษ่ࠤฬ๊ๅศุํอࠬრ")+OTlVEGYPSxsNaBdXUucqA3+hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"๋๋ࠩีอࠠๆ฻้ห์ࠦลัษ่ࠣิ๐ใࠡ็ื็้ฯࠠโ้ํࠤ้๐ำห่๊ࠢࠥอไษำ้ห๊าࠧს")+OTlVEGYPSxsNaBdXUucqA3
	eWfZ8zVxDEnvBpt7ALl3yITuhKa5M += PSwfZcdRYhpl5Igqz8xOEk67+ndc28qGFgoxVZ1YOeQs4wR+YoQW601K4fMJcsreDnGVE5wUZIy7+yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠪࡠࡳࡢ࡮ࠨტ")
	eWfZ8zVxDEnvBpt7ALl3yITuhKa5M += YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"๊ࠫ๎วใ฻่๊๊ࠣࠦี฼็ࠤฬ๊ศา่ส้ัࠦๅ็้สࠤๆ๐ฯ๋๊๊หฯࠦแ๋ࠢ࠶ࠤศ๐วๆࠢส่๊อึ๋หࠪუ")+OTlVEGYPSxsNaBdXUucqA3+PtkEvXAqif14G20QZsaSyT(u"ࠬ๎็ัษ้ࠣ฾์ว่ࠢสัฯ๋วๅࠢๆฬ๏ื้ࠠฮ๋ำ๋ࠥิไๆฬࠤๆ๐ࠠศๆหี๋อๅอࠩფ")+OTlVEGYPSxsNaBdXUucqA3
	eWfZ8zVxDEnvBpt7ALl3yITuhKa5M += PSwfZcdRYhpl5Igqz8xOEk67+dANSkE5C2gKL4z7DTmuXBFR+YoQW601K4fMJcsreDnGVE5wUZIy7
	kU97twfAaGzjYFr0Dnibe5L2s68,mARzWphFnQtwDZHNM9,olmrODud3Nj50VFJc2XhRwTgxa1,TfW52JQyVc3ejl8MI = uuExaKGL7UONtevRd(u"࠳ቪ"),uuExaKGL7UONtevRd(u"࠳ቪ"),uuExaKGL7UONtevRd(u"࠳ቪ"),uuExaKGL7UONtevRd(u"࠳ቪ")
	all = ax5OLdDBYpuNtib4QKlf7nyHVRSs9[Y41NvKfOroMzGB8sEHy7wbXlc5(u"࠭ࡁࡍࡎࠪქ")]
	if XrTw01KtLzbpoyMf(u"ࠧࡑ࡛ࡗࡌࡔࡔࠧღ") in list(ax5OLdDBYpuNtib4QKlf7nyHVRSs9.keys()): kU97twfAaGzjYFr0Dnibe5L2s68 = ax5OLdDBYpuNtib4QKlf7nyHVRSs9[yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠨࡒ࡜ࡘࡍࡕࡎࠨყ")]
	if sVzojQerUqX(u"ࠩࡌࡒࡘ࡚ࡁࡍࡎࠪშ") in list(ax5OLdDBYpuNtib4QKlf7nyHVRSs9.keys()): mARzWphFnQtwDZHNM9 = ax5OLdDBYpuNtib4QKlf7nyHVRSs9[TlGXWLYsV1z(u"ࠪࡍࡓ࡙ࡔࡂࡎࡏࠫჩ")]
	if GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠫࡒࡋࡔࡓࡑࡓࡓࡑࡏࡓࠨც") in list(ax5OLdDBYpuNtib4QKlf7nyHVRSs9.keys()): olmrODud3Nj50VFJc2XhRwTgxa1 = ax5OLdDBYpuNtib4QKlf7nyHVRSs9[XrTw01KtLzbpoyMf(u"ࠬࡓࡅࡕࡔࡒࡔࡔࡒࡉࡔࠩძ")]
	if sVzojQerUqX(u"࠭ࡒࡆࡒࡒࡗࠬწ") in list(ax5OLdDBYpuNtib4QKlf7nyHVRSs9.keys()): TfW52JQyVc3ejl8MI = ax5OLdDBYpuNtib4QKlf7nyHVRSs9[IpC4qHXRuyNFjzWv(u"ࠧࡓࡇࡓࡓࡘ࠭ჭ")]
	tMa3Gzf0xqu2rH4gPwTFSCDcivOVN = all-kU97twfAaGzjYFr0Dnibe5L2s68-mARzWphFnQtwDZHNM9-olmrODud3Nj50VFJc2XhRwTgxa1-TfW52JQyVc3ejl8MI
	qBIUYtOjTAx0,M0Anbgytpmia = rvdoZOyq3LmDkiTUCfQPuBGn[FGTfwsjNrB8DvKSZhLIQAb1JnO]
	qBIUYtOjTAx0,xCnSQBeGiyVlKact12PqMUApr = rvdoZOyq3LmDkiTUCfQPuBGn[YYJQyRskpX8jv]
	eJ6CLb8OTQ5BtAINl1fX = M0Anbgytpmia-xCnSQBeGiyVlKact12PqMUApr
	UsaTN0fzgjFQqX5Znk3JVI4yv8oHA += aqEsMBckT2bunGHfl48Wip+str(xCnSQBeGiyVlKact12PqMUApr)+YoQW601K4fMJcsreDnGVE5wUZIy7+L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠨษ็฽ิีࠠศๆะๆ๏่๊ࠡๆ็วัําสࠢ࠽ࠤࠬხ")
	UsaTN0fzgjFQqX5Znk3JVI4yv8oHA += OTlVEGYPSxsNaBdXUucqA3+aqEsMBckT2bunGHfl48Wip+str(eJ6CLb8OTQ5BtAINl1fX)+YoQW601K4fMJcsreDnGVE5wUZIy7+TlGXWLYsV1z(u"ࠩหหุะฮะษ่ࠤࡵࡸ࡯ࡹࡻࠣวํࠦࡶࡱࡰࠣ࠾ࠥ࠭ჯ")
	UsaTN0fzgjFQqX5Znk3JVI4yv8oHA += OTlVEGYPSxsNaBdXUucqA3+aqEsMBckT2bunGHfl48Wip+str(M0Anbgytpmia)+YoQW601K4fMJcsreDnGVE5wUZIy7+zmcGfOdvAjsELeJlP(u"ࠪห้฿ฯะࠢส่่๊๊ࠡๆฯ้๏฿ࠠศๆฦะ์ุษࠡ࠼ࠣࠫჰ")
	UsaTN0fzgjFQqX5Znk3JVI4yv8oHA += OTlVEGYPSxsNaBdXUucqA3+aqEsMBckT2bunGHfl48Wip+str(len(rvdoZOyq3LmDkiTUCfQPuBGn[sVzojQerUqX(u"࠶ቫ"):]))+YoQW601K4fMJcsreDnGVE5wUZIy7+vODxLKW5Ql6r4Fbm8(u"ࠫ฾ีฯࠡษ็ำํ๊ࠠศๆอ๎ࠥ็๊่ษࠣวัําสࠢ࠽ࠤࡡࡴ࡜࡯ࠩჱ")
	for CCsm1xkvzejL0RSQZI9JaWD,BBWS6VTi15YeM2bvJGXtxpslDhg8 in rvdoZOyq3LmDkiTUCfQPuBGn[uuExaKGL7UONtevRd(u"࠷ቬ"):]:
		CCsm1xkvzejL0RSQZI9JaWD = vvmT3DLXkhPBwIaOAo6srZpEnRVJC(CCsm1xkvzejL0RSQZI9JaWD)
		CCsm1xkvzejL0RSQZI9JaWD = CCsm1xkvzejL0RSQZI9JaWD.strip(iFBmE2MUIpSu34wsd7Rf6z).strip(HtK4o2sTPgA78U(u"ࠬࠦ࠮ࠨჲ"))
		UsaTN0fzgjFQqX5Znk3JVI4yv8oHA += CCsm1xkvzejL0RSQZI9JaWD+hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"࠭࠺ࠡࠩჳ")+PSwfZcdRYhpl5Igqz8xOEk67+str(BBWS6VTi15YeM2bvJGXtxpslDhg8)+YoQW601K4fMJcsreDnGVE5wUZIy7+AbqCJZdWQP9j(u"ࠧࠡࠢࠣࠫჴ")
	a6nyIkEVsvc7ibXSm1feqCUT += aqEsMBckT2bunGHfl48Wip+str(tMa3Gzf0xqu2rH4gPwTFSCDcivOVN)+YoQW601K4fMJcsreDnGVE5wUZIy7+xpT28sXu051(u"ࠨใํำ๏๎็ศฬࠣหูะฺๅฬࠣ࠾ࠥ࠭ჵ")
	a6nyIkEVsvc7ibXSm1feqCUT += OTlVEGYPSxsNaBdXUucqA3+aqEsMBckT2bunGHfl48Wip+str(kU97twfAaGzjYFr0Dnibe5L2s68)+YoQW601K4fMJcsreDnGVE5wUZIy7+tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ฺ่ࠩออสࠡีํีๆืࠠษษํฯํ์ࠠ࠻ࠢࠪჶ")
	a6nyIkEVsvc7ibXSm1feqCUT += OTlVEGYPSxsNaBdXUucqA3+aqEsMBckT2bunGHfl48Wip+str(TfW52JQyVc3ejl8MI)+YoQW601K4fMJcsreDnGVE5wUZIy7+hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠪ฻้ฮวหࠢึ๎ึ็ัࠡษ็ุ้ะ่ะ฻ࠣ࠾ࠥ࠭ჷ")
	a6nyIkEVsvc7ibXSm1feqCUT += OTlVEGYPSxsNaBdXUucqA3+aqEsMBckT2bunGHfl48Wip+str(mARzWphFnQtwDZHNM9)+YoQW601K4fMJcsreDnGVE5wUZIy7+hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠫฯัศ๋ฬࠣฮ฼ฮ๊ใࠢๆ์ิ๐ฺࠠ็สำࠥࡀࠠࠨჸ")
	a6nyIkEVsvc7ibXSm1feqCUT += OTlVEGYPSxsNaBdXUucqA3+aqEsMBckT2bunGHfl48Wip+str(olmrODud3Nj50VFJc2XhRwTgxa1)+YoQW601K4fMJcsreDnGVE5wUZIy7+uuExaKGL7UONtevRd(u"ࠬะหษ์อࠤั๊ฯࠡ็อีํฮ่ๅีࠣ฽๊อฯࠡ࠼ࠣࠫჹ")
	a6nyIkEVsvc7ibXSm1feqCUT += OTlVEGYPSxsNaBdXUucqA3+aqEsMBckT2bunGHfl48Wip+str(len(kQMrDAdLYGybljRqsmJIx5u))+YoQW601K4fMJcsreDnGVE5wUZIy7+hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"࠭ฯ้ๆุࠣ฿๊สࠡใํำ๏๎็ศฬࠣ࠾ࠥ࠭ჺ")
	a6nyIkEVsvc7ibXSm1feqCUT += CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠧ࡝ࡰ࡟ࡲࠬ჻")+URMJYy0oNZOLXW5zxElIsBnFfr7Tb
	ggULVKqsMZbc1ynfBC7(LyNiIHPOwD3hCUYEFM7(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨჼ"),LyNiIHPOwD3hCUYEFM7(u"ࠩ฼ำิࠦวๅลฯ๋ืฯࠠศๆอ๎ࠥอำหะา้ฯࠦ็ัษࠣห้ฮั็ษ่ะࠥ็๊ࠡ࠵ࠣว๏อๅࠡษ็้ฬ฼๊สࠢไ๎ࠥอไฺษ็้้ࠥไ่ࠩჽ"),UsaTN0fzgjFQqX5Znk3JVI4yv8oHA,SaB5hx3PZwXRLtKgrTfQvId(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭ჾ"))
	ggULVKqsMZbc1ynfBC7(tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫჿ"),ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠬ฿ฯะࠢส่ๆ๐ฯ๋๊๊หฯࠦวๅฬํࠤูเไ่ษ๋ࠣีอࠠศๆหี๋อๅอࠢไ๎ࠥ࠹ࠠฤ์ส้ࠥอไๆษู๎ฮࠦแ๋ࠢส่฾อไๆࠢๆ่์࠭ᄀ"),a6nyIkEVsvc7ibXSm1feqCUT,L90uqo28xEKSFUwYTcm51yRWZIkft(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩᄁ"))
	ggULVKqsMZbc1ynfBC7(FRYcH4KL7e9gv5pEB(u"ࠧࡤࡧࡱࡸࡪࡸࠧᄂ"),HtK4o2sTPgA78U(u"ࠨ็๋ห็฿ࠠศึอ฾้ะࠠโ์ࠣ࠷ࠥษ๊ศ็ࠣห้๋วื์ฬࠤๆ๐ࠠศๆ฼ห้๋ࠠไๆ๊ࠫᄃ"),eWfZ8zVxDEnvBpt7ALl3yITuhKa5M,SaB5hx3PZwXRLtKgrTfQvId(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬᄄ"))
	ggULVKqsMZbc1ynfBC7(HtK4o2sTPgA78U(u"ࠪࡰࡪ࡬ࡴࠨᄅ"),MgP8OjoaiWQEVG59(u"ࠫศ฿ไ๊ࠢส่ิ๎ไࠡษ็ฮ๏ࠦแ๋ࠢ࠶ࠤศ๐วๆࠢส่๊อึ๋หࠣหุะฮะ็อࠤฬ๊ศา่ส้ั࠭ᄆ"),ngWSHzwAk1r8oKB,CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࡠ࡮ࡲࡲ࡬࠭ᄇ"))
	return
def ZbaCcAwHmTdDge0LFqknKvWOsJpM():
	aZtYlicqMKUFPkBCX2AONHwJ4 = xpT28sXu051(u"࠭็ัษࠣห้ฮั็ษ่ะࠥ๐ูๆๆࠣหๆ฼ไࠡสสืฯิฯศ็ࠣะ้ีࠠไ๊า๎ࠥ࠮ࡋࡰࡦ࡬ࠤࡘࡱࡩ࡯ࠫࠣห้ึ๊ࠡษึ้์ࡢ࡮ࠨᄈ")+aqEsMBckT2bunGHfl48Wip+HtK4o2sTPgA78U(u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭ᄉ")+YoQW601K4fMJcsreDnGVE5wUZIy7+UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠨ࡞ࡱࡠࡳࡢ࡮๊่้่ࠡ์ࠠหอห๎ฯํࠠษษึฮำีวๆ่ࠢืฯ๎ฯฺࠢ฼้ฬีࠠࡆࡏࡄࡈࠥࡘࡥࡱࡱࡶ࡭ࡹࡵࡲࡺࠢฦ์ࠥะอๆ์็๋๋ࠥๆ࡝ࡰࠪᄊ")+aqEsMBckT2bunGHfl48Wip+GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡲࡦࡲࡲ࠲ࡺࡱ࠮ࡵࡱࠪᄋ")+YoQW601K4fMJcsreDnGVE5wUZIy7+ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠪࡠࡳࡢ࡮࡝ࡰ๋ࠣีํࠠศๆิืฬ๊ษ๊ࠡ฽๎ึํวࠡๅฮ๎ึࠦๅ้ฮ๋ำฮࠦแ๋ࠢๅหห๋ษࠡะา้ฬะࠠศๆหี๋อๅอ๋ࠢห้๋า๋ัࠣว๏฼วࠡ็๋ะํีࠠโ์ࠣๆฬฬๅสࠢฦะํฮษࠡษ็ฬึ์วๆฮࠪᄌ")
	ggULVKqsMZbc1ynfBC7(hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫᄍ"),ZchUJdM93pTA7zG5(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᄎ"),aZtYlicqMKUFPkBCX2AONHwJ4,L90uqo28xEKSFUwYTcm51yRWZIkft(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩᄏ"))
	return
def ttVx0znGRokWf3JHYgasDlF():
	aZtYlicqMKUFPkBCX2AONHwJ4 = tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠧศๆิหอ฽๊็ࠢฦำ๋อ็ࠡใํ๋๊อࠠหูห๎็ࠦใ้ัํࠤ฾๋วะ๋๋ࠢํูࠦษษิอࠥ฿ๆࠡฬฮฬ๏ะࠠไษ่่ࠥอ่ห๊่หฯ๐ใ๋ࠢ็ฬึ์วๆฮࠣ็ํี๊๊่ࠡ฽์ࠦวืษไอࠥ฿ๅศั่้ࠣ็๊ะ์๋๋ฬะࠠศๆ฼ีอ๐ษ๊่ࠡ฽์ࠦวืษไอࠥาไะ่ࠢฮึ๎ศ้ๆึࠤ฾๋วะ๋้ࠢ฾ํࠠศุสๅฮࠦๅิฬ๋ำ฾ูࠦๆษาࠤํ็๊่ࠢฦ๎฻อࠠอ็ํ฽ࠥอูะษาฮ้่ࠥะ์ࠣห้๋ืๅ๊หอู๊ࠥๆๆࠣฬึ์วๆฮࠣ฽๊อฯ๊ࠡๆ่์อࠠหฬ่ࠤฬ๎ส้็สฮ๏้๊ศ๋่ࠢฬࠦสฮฬสะࠥษ๊่๋ࠡ฽๋ࠥๆࠡษ็าอืษࠡใํࠤ่๎ฯ๋ࠢฦ์ࠥอไฯสิอࠥ็๊ࠡฬฮฬ๏ะࠠฤุสๅฬะࠠไ๊า๎ࠬᄐ")+OTlVEGYPSxsNaBdXUucqA3+PSwfZcdRYhpl5Igqz8xOEk67+gZ4LwbKaOm[sVzojQerUqX(u"ࠨࡍࡒࡈࡎࡋࡍࡂࡆࡢࡅࡕࡖࠧᄑ")][FGTfwsjNrB8DvKSZhLIQAb1JnO]+YoQW601K4fMJcsreDnGVE5wUZIy7+IpC4qHXRuyNFjzWv(u"ࠩࠣࠤࠥࠦࠠࠡล๋ࠤࠥࠦࠠࠡࠢࠪᄒ")+PSwfZcdRYhpl5Igqz8xOEk67+gZ4LwbKaOm[hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠪࡏࡔࡊࡉࡆࡏࡄࡈࡤࡇࡐࡑࠩᄓ")][YYJQyRskpX8jv]+YoQW601K4fMJcsreDnGVE5wUZIy7
	aZtYlicqMKUFPkBCX2AONHwJ4 += ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠫࡡࡴ࡜࡯࡞ࡱห้ืวษูࠣวิ์ว่๊ࠢ์ࠥอไิ๊ิืࠥอไั์ࠣ๎าะวอ้้ࠣิ๐ัࠡ็็ๅฬะࠠไ๊า๎๊ࠥสฬสํฮࠥฮั็ษ่ะࠥ฿ๅศัࠣฬฬ๊ืา์ๅอࠥอไหไ็๎ิ๐ษࠡษ็ๆิ๐ๅส࡞ࡱࠫᄔ")+PSwfZcdRYhpl5Igqz8xOEk67+gZ4LwbKaOm[vODxLKW5Ql6r4Fbm8(u"࡙ࠬࡏࡖࡔࡆࡉࡘ࠭ᄕ")][YYJQyRskpX8jv]+YoQW601K4fMJcsreDnGVE5wUZIy7
	aZtYlicqMKUFPkBCX2AONHwJ4 += uuExaKGL7UONtevRd(u"࠭࡜࡯࡞ࡱࡠࡳาๅ๋฻้้ࠣ็วหࠢ฼้ฬีࠠๆ๊ฯ์ิฯࠠโ์ࠣห้๋่ใ฻ࠣวิ์ว่ࠩᄖ")+OTlVEGYPSxsNaBdXUucqA3+PSwfZcdRYhpl5Igqz8xOEk67+gZ4LwbKaOm[tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠧࡔࡑࡘࡖࡈࡋࡓࠨᄗ")][nI2JK1RfsGWNY3OarEeMQZ]+YoQW601K4fMJcsreDnGVE5wUZIy7
	ggULVKqsMZbc1ynfBC7(xpT28sXu051(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨᄘ"),SaB5hx3PZwXRLtKgrTfQvId(u"ࠩส่๊๎วใ฻ࠣห้ืำๆ์ฬࠤ้ฮั็ษ่ะࠥ฿ๅศั่้ࠣ็๊ะ์๋๋ฬะࠠศๆ฼ีอ๐ษࠨᄙ"),aZtYlicqMKUFPkBCX2AONHwJ4,ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭ᄚ"))
	return
def Go1VbKAenJHy5iP8c(r6UyvzPs1ZmGHKCWe):
	WwMgozBIC32n9d0tyfp.executebuiltin(JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠫࡆࡪࡤࡰࡰ࠱ࡓࡵ࡫࡮ࡔࡧࡷࡸ࡮ࡴࡧࡴࠪࠪᄛ")+r6UyvzPs1ZmGHKCWe+uuExaKGL7UONtevRd(u"ࠬ࠯ࠧᄜ"), rGPen6cSMHQkAywh8vqI9JXiD2)
	return
def inc0qJAsOf8dQCHgUG():
	aolOvjwC6d(JZszNnIEMAx28Yao0yqhiXGKOPb(u"࠭ࡳࡵࡱࡳࠫᄝ"))
	WwMgozBIC32n9d0tyfp.executebuiltin(UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠢࡂࡥࡷ࡭ࡻࡧࡴࡦ࡙࡬ࡲࡩࡵࡷࠩࡋࡱࡸࡪࡸࡦࡢࡥࡨࡗࡪࡺࡴࡪࡰࡪࡷ࠮ࠨᄞ"))
	return
def orPqw1N4BxKDCSa7FXIgiW3s2l():
	WwMgozBIC32n9d0tyfp.executebuiltin(TlGXWLYsV1z(u"ࠨࡃࡧࡨࡴࡴ࠮ࡐࡲࡨࡲࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠮ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠯ࠧᄟ"), rGPen6cSMHQkAywh8vqI9JXiD2)
	return
def dY0Bxclpf3k849zCJHvgm1q():
	bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,FRYcH4KL7e9gv5pEB(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬᄠ"),tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ู่๊ࠪอࠡ็ะฮํ๐วหࠢๅหห๋ษࠡ࠰ࠣหีํศࠡว็ํࠥอไใษษ้ฮࠦวๅฬํࠤฯื๊ะ่ࠢืาํว๊ࠡ็หࠥะฯฯๆࠣษ้๐็ศ๋่่ࠢ์ࠠษษึฮำีวๆࠢࠥห้๋ว้ีࠥࠤศ๎ࠠࠣษ็ี๏๋่หࠤࠣห฻เืࠡ฻็ํࠥอไำำࠣะ์ฯࠠศๆํ้๏์ࠠฤ๊ࠣหุะฮะ็ࠣࠦฬ๊ใ๋ส๋ีิࠨ้ࠠษู฾฼ูࠦๅ๋ࠣัึ็ࠠࠣࡅࠥࠤศ๎ฺࠠๆ์ࠤฬ฼ฺุࠢ฼่๎ࠦาาࠢࠥห้่วว็ฬࠦࠥอไั์ࠣๅ๏ࠦฬ่หࠣห้๐ๅ๋่ࠪᄡ"))
	return
def xxvHEQlGXk3AehOKT54SYo():
	bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,ZchUJdM93pTA7zG5(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᄢ"),UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"๊ࠬไห฻ส้้ࠦๅฺࠢส่๊็ึๅหࠣ࠲ࠥอะ่สࠣษ้๏ࠠศๆิหอ฽ࠠศๆำ๎ࠥะั๋ัࠣษ฻อแห้ࠣวํࠦๅิฯ๊ࠤ๊์ࠠࠡไสส๊ฯࠠศๆ่ๅ฻๊ษ๊ࠡ็็๋ࠦไศࠢอ๊็ืฺࠠๆํ๋ࠥ๎ไศࠢอุ฿๊็ࠡ࠰ࠣ์ออำหะาห๊ࠦࠢศๆ่หํูࠢࠡล๋ࠤࠧอไา์่์ฯࠨࠠศุ฽฻ࠥ฿ไ๊ࠢส่ืืࠠอ้ฬࠤฬ๊๊ๆ์้ࠤ࠳่ࠦฤ็สࠤออำหะาห๊ࠦࠢศๆๆ๎อ๎ัะࠤࠣๅฬ฼ฺุࠢ฼่๎ࠦอาใࠣࠦࡈࠨࠠฤ๊ࠣ฽้๏ࠠำำࠣࠦฬ๊โศศ่อࠧࠦวๅาํࠤๆ๐ࠠอ้ฬࠤฬ๊๊ๆ์้ࠤ࠳่ࠦ็ใึࠤฬ๊ใๅษ่ࠤํอไุำํๆฮูࠦ็ัࠣห้ะูศ็็ࠤ๊฿ࠠๆฯอ์๏อสࠡไ๋หห๋ࠠศๆ่ๅ฻๊ษࠨᄣ"))
	return
def ho0c2JuHRidU6C41(D5Ry94hxdML3FtoE28GqV=jXE2YHkswT8y(u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈࠬᄤ"),showDialogs=rGPen6cSMHQkAywh8vqI9JXiD2):
	Pwe2ycZtIx5FOrhuf = WwMgozBIC32n9d0tyfp.executeJSONRPC(YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡓࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡉࡨࡸࡘ࡫ࡴࡵ࡫ࡱ࡫࡛ࡧ࡬ࡶࡧࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡵࡨࡸࡹ࡯࡮ࡨࠤ࠽ࠦࡱࡵ࡯࡬ࡣࡱࡨ࡫࡫ࡥ࡭࠰ࡶ࡯࡮ࡴࠢࡾࡿࠪᄥ"))
	data = bHyN37Y82ZKVLOexBF.loads(Pwe2ycZtIx5FOrhuf)
	Ki3XYMHOZvIWtByA2agT = data[L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠨࡴࡨࡷࡺࡲࡴࠨᄦ")][sVzojQerUqX(u"ࠩࡹࡥࡱࡻࡥࠨᄧ")]
	if iELueYz3J1FmxaW7vc: Ki3XYMHOZvIWtByA2agT = Ki3XYMHOZvIWtByA2agT.encode(df6QpwGxuJVZr)
	if showDialogs:
		U17QqF2gkI46 = A1AXKupEOfz(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ᄨ"),AbqCJZdWQP9j(u"ࠫ์๊ࠠหำํำࠥะฺ๋์ิࠤั๊ฯࠡࠩᄩ")+Ki3XYMHOZvIWtByA2agT+xpT28sXu051(u"ࠬࠦวๅาํࠤู๊สฯั่ࠤฬ๊ย็ࠢไ๎้่ࠥะ์ࠣษ้๏ࠠศๆศูิอัࠡษ็วำ๐ัࠡๆฯ่ิࠦࠧᄪ")+D5Ry94hxdML3FtoE28GqV+sVzojQerUqX(u"࠭ࠠภࠣࠪᄫ"))
		if U17QqF2gkI46!=vODxLKW5Ql6r4Fbm8(u"࠷ቭ"): return BF6QAiLUNHh7rKOugaw
	M5qyIg2dZlm6FxH4tTPV79okNu0bCG,dNSmqzLRnDpMv,DKkWE5zLldjsc6hP39V8Irt7fey = UDbFm3VYA1vzHZ2wxTeNJyWM(D5Ry94hxdML3FtoE28GqV,BF6QAiLUNHh7rKOugaw,BF6QAiLUNHh7rKOugaw)
	if M5qyIg2dZlm6FxH4tTPV79okNu0bCG:
		if showDialogs: bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,PtkEvXAqif14G20QZsaSyT(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᄬ"),uuExaKGL7UONtevRd(u"ࠨฬ่ฮࠥ฿ๅๅ์ฬࠤฯัศ๋ฬࠣห้าไะࠢส่ัี๊ะ๋๋ࠢํࠦฬศ้ีࠤ้๊วิฬัำฬ๋ࠠ࠯ࠢึ์ๆ๊ࠦห็ࠣห้ศๆࠡฬ฽๎๏ืࠠฦ฻าหิอสࠡๅ๋ำ๏ࠦไไ์ࠣ๎ุะูๆๆࠣห้าไะࠢส่ัี๊ะࠢหำ้อࠠๆ่ࠣห้่ฯ๋็ࠪᄭ"))
		umOGqx65jCSBT1 = WwMgozBIC32n9d0tyfp.executeJSONRPC(GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡕࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡗࡪࡺࡓࡦࡶࡷ࡭ࡳ࡭ࡖࡢ࡮ࡸࡩࠧ࠲ࠢࡪࡦࠥ࠾࠶࠲ࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡷࡪࡺࡴࡪࡰࡪࠦ࠿ࠨ࡬ࡰࡱ࡮ࡥࡳࡪࡦࡦࡧ࡯࠲ࡸࡱࡩ࡯ࠤ࠯ࠦࡻࡧ࡬ࡶࡧࠥ࠾ࠧ࠭ᄮ")+D5Ry94hxdML3FtoE28GqV+xpT28sXu051(u"ࠪࠦࢂࢃࠧᄯ"))
		M5qyIg2dZlm6FxH4tTPV79okNu0bCG = rGPen6cSMHQkAywh8vqI9JXiD2 if AbqCJZdWQP9j(u"ࠫࡔࡑࠧᄰ") in umOGqx65jCSBT1 else BF6QAiLUNHh7rKOugaw
		X2cQ5NCPvkMieBW7oASspFjE.sleep(xpT28sXu051(u"࠱ቮ"))
		WwMgozBIC32n9d0tyfp.executebuiltin(hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"࡙ࠬࡥ࡯ࡦࡆࡰ࡮ࡩ࡫ࠩ࠳࠴࠭ࠬᄱ"))
	elif showDialogs: bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,ZchUJdM93pTA7zG5(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᄲ"),jXE2YHkswT8y(u"ࠧๅๆฦืๆࠦแีๆอࠤ฾๋ไ๋หࠣฮะฮ๊ห๋ࠢฮๆ฿๊ๅࠢส่ั๊ฯࠡษ็้฼๊่ษࠩᄳ"))
	return M5qyIg2dZlm6FxH4tTPV79okNu0bCG
def yhTBUcFtLgo():
	url = uuExaKGL7UONtevRd(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡯࡬ࡶࡷࡵࡲࡴ࠰࡮ࡳࡩ࡯࠮ࡵࡸ࠲ࡶࡪࡲࡥࡢࡵࡨࡷ࠴ࡽࡩ࡯ࡦࡲࡻࡸ࠵ࡷࡪࡰ࠹࠸࠴࠭ᄴ")
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠩࡊࡉ࡙࠭ᄵ"),url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,jXE2YHkswT8y(u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗ࠲࡙ࡈࡐ࡙ࡢࡐࡆ࡚ࡅࡔࡖࡢࡏࡔࡊࡉࡠࡘࡈࡖࡘࡏࡏࡏ࠯࠴ࡷࡹ࠭ᄶ"))
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	RQNtP2GFraiVHuJSdswoDZxBvqyf1j = dEyT9xhGjolYzLCH7460w3.findall(y6y5HtgXO4TkUbwVZ(u"ࠫࡹ࡯ࡴ࡭ࡧࡀࠦࡰࡵࡤࡪ࠯ࠫࡠࡩ࠱࡜࠯࡞ࡧ࠯࠲ࡡࡡ࠮ࡼࡄ࠱࡟ࡣࠫࠪ࠯ࠪᄷ"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	RQNtP2GFraiVHuJSdswoDZxBvqyf1j = RQNtP2GFraiVHuJSdswoDZxBvqyf1j[FGTfwsjNrB8DvKSZhLIQAb1JnO].split(y6y5HtgXO4TkUbwVZ(u"ࠬ࠳ࠧᄸ"))[FGTfwsjNrB8DvKSZhLIQAb1JnO]
	u0uS5QUwR9jFgsfl6dGyx2nXEVva = str(ZD1J5rN8u2wzdgqoyULm4)
	ngWSHzwAk1r8oKB = tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"࡛࠭ࡓࡖࡏࡡส฻ฯศำࠣ็ํี๊ࠡษ็วำ๐ัࠡษ็้ฯ๎แาࠢส่ว์่๊ࠠࠣ࠾ࠥࠦࠠࠨᄹ")+aqEsMBckT2bunGHfl48Wip+RQNtP2GFraiVHuJSdswoDZxBvqyf1j+YoQW601K4fMJcsreDnGVE5wUZIy7
	ngWSHzwAk1r8oKB += JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠧ࡝ࡰ࡟ࡲࠬᄺ")+vODxLKW5Ql6r4Fbm8(u"ࠨ࡝ࡕࡘࡑࡣลึัสี้่ࠥะ์ࠣห้ึ๊ࠡษ้ฮࠥะำหะา้์ࠦ็้ࠢ࠽ࠤࠥࠦࠧᄻ")+aqEsMBckT2bunGHfl48Wip+u0uS5QUwR9jFgsfl6dGyx2nXEVva+YoQW601K4fMJcsreDnGVE5wUZIy7
	bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,MgP8OjoaiWQEVG59(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬᄼ"),ngWSHzwAk1r8oKB)
	return
def tkLMTQbNO1D():
	Eiq7gPBGY4Q,D0xzIGq7Z5u3bXipnHrsk9h2W,ooZwrRUshc13uN = BF6QAiLUNHh7rKOugaw,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U
	KejIXJrqOB9DQi0AYn8NUy2EcpG,axpOkZ6BSfCsGE2M4hqtTVLcAQ3uP,wf15smNYJZ6ctMyP3BLSj8QunrU = BF6QAiLUNHh7rKOugaw,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U
	T0nxf19jK45XgUIchJ8M2zpet = [UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨᄽ"),PtkEvXAqif14G20QZsaSyT(u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠭ᄾ"),sVzojQerUqX(u"ࠬࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇࠫᄿ")]
	qQsCzJV2Wgr63in8YF1E0dXf9OSG = Mk1o9HmfhFYupBtdi3(T0nxf19jK45XgUIchJ8M2zpet)
	for M8hQu61Uid in T0nxf19jK45XgUIchJ8M2zpet:
		if M8hQu61Uid not in list(qQsCzJV2Wgr63in8YF1E0dXf9OSG.keys()): continue
		BCG6aEXrN0,M0A7hVgYLTC3DtidwyIQ,B1U7oLRzXtQGjSeYyv,XwLoV0RdYqZ6CFj9sgGuyOciE,B153K72OyIhV,SSPUNGLfTcBH9lZmCKz,Cqk5fbThjz9LAIUPH = qQsCzJV2Wgr63in8YF1E0dXf9OSG[M8hQu61Uid]
		if M8hQu61Uid==sVzojQerUqX(u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫᅀ"):
			KejIXJrqOB9DQi0AYn8NUy2EcpG = BCG6aEXrN0
			axpOkZ6BSfCsGE2M4hqtTVLcAQ3uP = M0A7hVgYLTC3DtidwyIQ+tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠧࠡࠢࠣࠤ࠭ࠦࠧᅁ")+aanoXVLTZqsIwitBdY0kcJS794FDg(SSPUNGLfTcBH9lZmCKz)+vODxLKW5Ql6r4Fbm8(u"ࠨࠢࠬࠫᅂ")
			wf15smNYJZ6ctMyP3BLSj8QunrU = XwLoV0RdYqZ6CFj9sgGuyOciE
		elif M8hQu61Uid==HtK4o2sTPgA78U(u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧࠫᅃ"):
			Eiq7gPBGY4Q = Eiq7gPBGY4Q or BCG6aEXrN0
			D0xzIGq7Z5u3bXipnHrsk9h2W += GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠪࠤࠥ࠲ࠠࠡࠩᅄ")+M0A7hVgYLTC3DtidwyIQ+sVzojQerUqX(u"ࠫࠥࠦࠠࠡࠪࠣࠫᅅ")+aanoXVLTZqsIwitBdY0kcJS794FDg(SSPUNGLfTcBH9lZmCKz)+JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠬࠦࠩࠨᅆ")
			ooZwrRUshc13uN += GGx4qyKP1vUtRghsE2WfaHLMXZ(u"࠭ࠠࠡ࠮ࠣࠤࠬᅇ")+XwLoV0RdYqZ6CFj9sgGuyOciE
		elif M8hQu61Uid==tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭ᅈ"):
			B648BSXx1CmnoYgpOUiKWDZQzNeb = BCG6aEXrN0
			EqCwn2LJibD3ldXUjha5Mmt = M0A7hVgYLTC3DtidwyIQ+y6y5HtgXO4TkUbwVZ(u"ࠨࠢࠣࠤࠥ࠮ࠠࠨᅉ")+aanoXVLTZqsIwitBdY0kcJS794FDg(SSPUNGLfTcBH9lZmCKz)+GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠩࠣ࠭ࠬᅊ")
			RqoSavpgLP = XwLoV0RdYqZ6CFj9sgGuyOciE
	D0xzIGq7Z5u3bXipnHrsk9h2W = D0xzIGq7Z5u3bXipnHrsk9h2W.strip(IpC4qHXRuyNFjzWv(u"ࠪࠤࠥ࠲ࠠࠡࠩᅋ"))
	ooZwrRUshc13uN = ooZwrRUshc13uN.strip(SaB5hx3PZwXRLtKgrTfQvId(u"ࠫࠥࠦࠬࠡࠢࠪᅌ"))
	RPuJUkO5cbLgl2Awj  = UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠬࡡࡒࡕࡎࡠห้หีะษิࠤฬ๊รฯ์ิࠤ้ฮั็ษ่ะࠥ฿ๅศัࠣห้๋ส้ใิࠤฬ๊ย็๊ࠢ์ࠥࡀࠠࠡࠢࠪᅍ")+aqEsMBckT2bunGHfl48Wip+wf15smNYJZ6ctMyP3BLSj8QunrU+YoQW601K4fMJcsreDnGVE5wUZIy7
	RPuJUkO5cbLgl2Awj += OTlVEGYPSxsNaBdXUucqA3+HtK4o2sTPgA78U(u"࡛࠭ࡓࡖࡏࡡฬ๊ลึัสีࠥอไั์ࠣห๋ะࠠหีอาิ๋็ࠡๆหี๋อๅอࠢ฼้ฬี่๊ࠠࠣ࠾ࠥࠦࠠࠨᅎ")+aqEsMBckT2bunGHfl48Wip+axpOkZ6BSfCsGE2M4hqtTVLcAQ3uP+YoQW601K4fMJcsreDnGVE5wUZIy7
	RPuJUkO5cbLgl2Awj += jXE2YHkswT8y(u"ࠧ࡝ࡰ࡟ࡲࠬᅏ")+L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠨ࡝ࡕࡘࡑࡣวๅวุำฬืࠠศๆฦา๏ืࠠๅ็ึฮํีูࠡ฻่หิࠦวๅ็อ์ๆืࠠศๆล๊ࠥํ่ࠡ࠼ࠣࠤࠥ࠭ᅐ")+aqEsMBckT2bunGHfl48Wip+ooZwrRUshc13uN+YoQW601K4fMJcsreDnGVE5wUZIy7
	RPuJUkO5cbLgl2Awj += OTlVEGYPSxsNaBdXUucqA3+zmcGfOdvAjsELeJlP(u"ࠩ࡞ࡖ࡙ࡒ࡝ศๆศูิอัࠡษ็ิ๏ࠦว็ฬࠣฮุะฮะ็๊ࠤ้๋ำห๊า฽ࠥ฿ๅศั๋ࠣํࠦ࠺ࠡࠢࠣࠫᅑ")+aqEsMBckT2bunGHfl48Wip+D0xzIGq7Z5u3bXipnHrsk9h2W+YoQW601K4fMJcsreDnGVE5wUZIy7
	RPuJUkO5cbLgl2Awj += XrTw01KtLzbpoyMf(u"ࠪࡠࡳࡢ࡮ࠨᅒ")+CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠫࡠࡘࡔࡍ࡟ส่ส฻ฯศำࠣห้ษฮ๋ำ่ࠣั๊ฯࠡ็อีํฮ่ๅีࠣ฽๊อฯࠡษ็้ฯ๎แาࠢส่ว์่๊ࠠࠣ࠾ࠥࠦࠠࠨᅓ")+aqEsMBckT2bunGHfl48Wip+RqoSavpgLP+YoQW601K4fMJcsreDnGVE5wUZIy7
	RPuJUkO5cbLgl2Awj += OTlVEGYPSxsNaBdXUucqA3+sVzojQerUqX(u"ࠬࡡࡒࡕࡎࡠห้หีะษิࠤฬ๊ะ๋ࠢส๊ฯࠦสิฬัำ๊ํࠠๅฮ็ำ๋ࠥสา๊ห์ฺู้ࠠ็สำࠥํ่ࠡ࠼ࠣࠤࠥ࠭ᅔ")+aqEsMBckT2bunGHfl48Wip+EqCwn2LJibD3ldXUjha5Mmt+YoQW601K4fMJcsreDnGVE5wUZIy7
	BCG6aEXrN0 = KejIXJrqOB9DQi0AYn8NUy2EcpG or Eiq7gPBGY4Q
	if BCG6aEXrN0:
		header = ZchUJdM93pTA7zG5(u"࠭วๅำฯหฦࠦสฮัํฯࠥหึศใสฮ้่ࠥะ์่ࠣา๊ࠠศๆุ่ฬ้ไࠨᅕ")
		AkLKwEuog3O8JDFlt6nGiN19aec0p = LyNiIHPOwD3hCUYEFM7(u"ࠧศ่อࠤอำวอห่ࠣฯำฯ๋อࠣฬึ์วๆฮࠣ฽๊อฯࠡล๋ࠤฯำฯ๋อุ้ࠣะ่ะ฻ࠣ฽๊อฯࠨᅖ")
	else:
		header = yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠨฯส่๏อࠠๅษࠣ๎ําฯࠡฬะำ๏ัวหࠢ็ฬึ์วๆฮࠣ฽๊อฯࠡล๋ࠤู๊ส้ั฼ࠤ฾๋วะࠩᅗ")
		AkLKwEuog3O8JDFlt6nGiN19aec0p = sVzojQerUqX(u"ࠩส่ึาวยࠢศฬ้อฺࠡษ็้อืๅอࠢ฼๊ࠥอไๆึๆ่ฮࠦวๅฬํࠤฯ๎วอ้ๆࠫᅘ")
	XDowxf3YTQlGnJFgbuqdVIz94 = vODxLKW5Ql6r4Fbm8(u"่่ࠪ๐๋ࠠ฻่่ࠥ฿ๆะๅࠣห้ะอะ์ฮࠤฬ๊สๅไสส๏๊ࠦอสࠣว๋๊ࠦไ๊้ࠤ้ี๊ไࠢไ๎้่ࠥะ์࡟ࡲู๊ส้ั฼ࠤ฾๋วะࠢࡈࡑࡆࡊࠠࡓࡧࡳࡳࡸ࡯ࡴࡰࡴࡼࠫᅙ")
	KKpIvETkbG8weQqnZli6c = RPuJUkO5cbLgl2Awj+IpC4qHXRuyNFjzWv(u"ࠫࡡࡴ࡜࡯ࠩᅚ")+AkLKwEuog3O8JDFlt6nGiN19aec0p+EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠬࡢ࡮࡝ࡰࠪᅛ")+XDowxf3YTQlGnJFgbuqdVIz94
	ggULVKqsMZbc1ynfBC7(tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"࠭ࡲࡪࡩ࡫ࡸࠬᅜ"),header,KKpIvETkbG8weQqnZli6c,UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪᅝ"))
	return BCG6aEXrN0
def p6JieQVcbmWuIxroRA4v3fCdT(M8hQu61Uid,Cqk5fbThjz9LAIUPH,showDialogs):
	M5qyIg2dZlm6FxH4tTPV79okNu0bCG = BF6QAiLUNHh7rKOugaw
	if showDialogs:
		U17QqF2gkI46 = A1AXKupEOfz(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᅞ"),jXE2YHkswT8y(u"ࠩึ์ๆ๊ࠦห็ࠣห้ศๆࠡฮ็ฬࠥอไๆๆไࠤฬ๊ๅื฼๋฻๊ࠥไฦุสๅฮࠦวๅ็ฺ่ํฮษࠡๆๆ๎ࠥ๐สๆࠢอฯอ๐ส่ࠢ฼่๎ࠦใ้ัํࠤ࠳ࠦวๅ็็ๅ่ࠥฯࠡ์ๆ์๋ࠦใษ์ิࠤํ่ฯࠡ์ะฮฬาࠠษ฻ูࠤฬ๊่ใฬࠣ࠲ࠥํไࠡฬิ๎ิࠦสฮ็ํ่ࠥอไๆๆไࠤฬ๊ย็ࠢยࠥࠬᅟ"))
		if U17QqF2gkI46!=YYJQyRskpX8jv: return BF6QAiLUNHh7rKOugaw
	WzLGcTUDZIC2RXAQbahSYmfpH = HHECmRlDkqTty05rGveI7hc436XA(Cqk5fbThjz9LAIUPH,{},showDialogs)
	if WzLGcTUDZIC2RXAQbahSYmfpH:
		zzUAWOMoFYCVh = wkMR5x1gTWEQIc6qHCa.path.join(p2tS61Jv9RBQdgKoZy,M8hQu61Uid)
		TAkeulImazNdJwE9(zzUAWOMoFYCVh,rGPen6cSMHQkAywh8vqI9JXiD2,BF6QAiLUNHh7rKOugaw)
		import zipfile as GKRCoM3lvIjibr6nxusJ8,io as q09oI4ugVNEjnTPid
		ppVhgmwjQGtoEFNd5ZHc9A = q09oI4ugVNEjnTPid.BytesIO(WzLGcTUDZIC2RXAQbahSYmfpH)
		try:
			TLIBQw4rnUE = GKRCoM3lvIjibr6nxusJ8.ZipFile(ppVhgmwjQGtoEFNd5ZHc9A)
			TLIBQw4rnUE.extractall(p2tS61Jv9RBQdgKoZy)
			X2cQ5NCPvkMieBW7oASspFjE.sleep(YYJQyRskpX8jv)
			WwMgozBIC32n9d0tyfp.executebuiltin(GGx4qyKP1vUtRghsE2WfaHLMXZ(u"࡙ࠪࡵࡪࡡࡵࡧࡏࡳࡨࡧ࡬ࡂࡦࡧࡳࡳࡹࠧᅠ"))
			X2cQ5NCPvkMieBW7oASspFjE.sleep(YYJQyRskpX8jv)
			M5qyIg2dZlm6FxH4tTPV79okNu0bCG = ccVI1JSnbDx(M8hQu61Uid)
		except: M5qyIg2dZlm6FxH4tTPV79okNu0bCG = BF6QAiLUNHh7rKOugaw
	if showDialogs:
		if M5qyIg2dZlm6FxH4tTPV79okNu0bCG: bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,sVzojQerUqX(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᅡ"),Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠬะๅࠡส้ะฬำࠠหอห๎ฯࠦวๅวูหๆฯࠠศๆ่฻้๎ศสࠩᅢ"))
		else: bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,FRYcH4KL7e9gv5pEB(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᅣ"),IpC4qHXRuyNFjzWv(u"ࠧๅๆฦืๆࠦแีๆอࠤ฾๋ไ๋หࠣฮะฮ๊หࠢส่ส฼วโหࠣห้๋ืๅ๊หอࠬᅤ"))
	return M5qyIg2dZlm6FxH4tTPV79okNu0bCG
def nv2FxBURGbaTYX(M8hQu61Uid,showDialogs=rGPen6cSMHQkAywh8vqI9JXiD2):
	if showDialogs==iiy37aKq0pCEIOwfcTh61xb4U: showDialogs = rGPen6cSMHQkAywh8vqI9JXiD2
	cRKfmdWpl5hGJk9eLNCEob = wd9kGFayMlcZgEoufxVU([M8hQu61Uid])
	aaqgsZLkyCPxnQ,rP6S9wgnfFY05 = cRKfmdWpl5hGJk9eLNCEob[M8hQu61Uid]
	if rP6S9wgnfFY05:
		M5qyIg2dZlm6FxH4tTPV79okNu0bCG = rGPen6cSMHQkAywh8vqI9JXiD2
		if showDialogs: bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,LyNiIHPOwD3hCUYEFM7(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᅥ"),ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠩไัฺࠦวๅวูหๆฯࠠ࡝ࡰࠣࠫᅦ")+M8hQu61Uid+HtK4o2sTPgA78U(u"ࠪࠤࡡࡴ่ࠠา๊ࠤศ๊ลืษไอࠥ฿ๆะๅ้ࠣํา่ะหࠣ์๊็ูๅหࠣ์ัอ็ำห่้ࠣอำหะาห๊࠭ᅧ"))
	else:
		M5qyIg2dZlm6FxH4tTPV79okNu0bCG = BF6QAiLUNHh7rKOugaw
		U17QqF2gkI46 = A1AXKupEOfz(LyNiIHPOwD3hCUYEFM7(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫᅨ"),iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᅩ"),iiy37aKq0pCEIOwfcTh61xb4U+M8hQu61Uid+LyNiIHPOwD3hCUYEFM7(u"࠭ࠠ࡝ࡰ๋ࠣีํࠠฤๆศฺฬ็ษࠡ฻้ำฺ่๋ࠦำ้ࠣๆ฿ไสࠢฦ์ࠥเ๊า่ࠢ์ั๎ฯสࠢ࠱ࠤ๏าศࠡฬฮฬ๏ะ็ศ๋ࠢฮๆ฿๊ๅ้สࠤ้้๊ࠡ์฼้้ࠦวๅสิ๊ฬ๋ฬࠡ฻้ำ่ࠦศึ๊ิอࠥ฻อ๋ฯฬࠤ࠳ࠦ็ๅࠢอี๏ีࠠหอห๎ฯ่ࠦหใ฼๎้ࠦ็ั้ࠣห้หึศใฬࠤฬ๊ย็ࠢยࠫᅪ"))
		if U17QqF2gkI46==ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"࠲ቯ"):
			WwMgozBIC32n9d0tyfp.executebuiltin(JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠧࡊࡰࡶࡸࡦࡲ࡬ࡂࡦࡧࡳࡳ࠮ࠧᅫ")+M8hQu61Uid+jXE2YHkswT8y(u"ࠨࠫࠪᅬ"))
			X2cQ5NCPvkMieBW7oASspFjE.sleep(TlGXWLYsV1z(u"࠳ተ"))
			WwMgozBIC32n9d0tyfp.executebuiltin(UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠩࡖࡩࡳࡪࡃ࡭࡫ࡦ࡯࠭࠷࠱ࠪࠩᅭ"))
			X2cQ5NCPvkMieBW7oASspFjE.sleep(PtkEvXAqif14G20QZsaSyT(u"࠴ቱ"))
			while WwMgozBIC32n9d0tyfp.getCondVisibility(zmcGfOdvAjsELeJlP(u"࡛ࠪ࡮ࡴࡤࡰࡹ࠱ࡍࡸࡇࡣࡵ࡫ࡹࡩ࠭ࡶࡲࡰࡩࡵࡩࡸࡹࡤࡪࡣ࡯ࡳ࡬࠯ࠧᅮ")): X2cQ5NCPvkMieBW7oASspFjE.sleep(XrTw01KtLzbpoyMf(u"࠵ቲ"))
			M5qyIg2dZlm6FxH4tTPV79okNu0bCG = ccVI1JSnbDx(M8hQu61Uid)
			if showDialogs and M5qyIg2dZlm6FxH4tTPV79okNu0bCG: bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,sVzojQerUqX(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᅯ"),xpT28sXu051(u"ࠬะๅࠡใะูࠥษ่ࠡฬฮฬ๏ะࠠฤ๊ࠣฮๆ฿๊ๅࠢฦ์ࠥะอะ์ฮࠤฬ๊ลืษไอࠥอไๆู็์อฯ้้ࠠํࠤฬ๊ย็ࠢฯห์ุษࠡๆ็หุะฮะษ่ࠫᅰ"))
			elif showDialogs: bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,TlGXWLYsV1z(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᅱ"),tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠧโึ็ࠤๆ๐ࠠหอห๎ฯࠦร้ࠢอๅ฾๐ไࠡล๋ࠤฯำฯ๋อࠣห้หึศใฬࠤฬ๊ๅุๆ๋ฬฮࠦ࠮๊ࠡส่า๊่๊ࠠࠣฮะฮ๊ห้สࠤํะแฺ์็๋ฬࠦๅ็ࠢัหึาࠠศๆหี๋อๅอࠩᅲ"))
	return M5qyIg2dZlm6FxH4tTPV79okNu0bCG
def x8mRHgVtiOylF(showDialogs):
	if not showDialogs: U17QqF2gkI46 = rGPen6cSMHQkAywh8vqI9JXiD2
	else: U17QqF2gkI46 = A1AXKupEOfz(L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨᅳ"),iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,zmcGfOdvAjsELeJlP(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬᅴ"),ZchUJdM93pTA7zG5(u"ࠪฬึ์วๆฮࠣ็ํี๊ࠡ์ๅ์๊ࠦศฺ็็๎ฮࠦสฮัํฯࠥาๅ๋฻ࠣห้หึศใสฮࠥะไใษษ๎ฬࠦใๅࠢ࠵࠸ูࠥวฺหࠣ์้้ๆࠡ็่็๋ࠦลอำสล์อࠠศๆล๊ࠥ࠴่ࠠๆࠣฮึ๐ฯࠡฬะำ๏ัࠠอ็ํ฽ࠥหึศใสฮ้่ࠥะ์ࠣห้ศๆࠡมࠪᅵ"))
	if U17QqF2gkI46==sVzojQerUqX(u"࠶ታ"):
		WwMgozBIC32n9d0tyfp.executebuiltin(hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"࡚ࠫࡶࡤࡢࡶࡨࡅࡩࡪ࡯࡯ࡔࡨࡴࡴࡹࠧᅶ"))
		if showDialogs:
			bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,HtK4o2sTPgA78U(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᅷ"),YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"࠭สๆࠢศีุอไูࠡ็ฬࠥหไ๊ࠢหี๋อๅอࠢๆ์ิ๐ࠠศๆำ๎ࠥ็๊ࠡฮ๊หื้ࠠๅๅํࠤ๏่่ๆࠢหฮาี๊ฬࠢฯ้๏฿ࠠฦุสๅฬะࠠไ๊า๎ࠥ࠴ࠠษ็สࠤๆ๐็ศࠢอัิ๐ห้ࠡำหࠥอไษำ้ห๊า้ࠠฬะำ๏ัࠠๆีอ์ิ฿ฺࠠ็สำࠥ࠴๋ࠠำฯํࠥหูุษฤࠤ่๎ฯ๋ࠢ࠸ࠤิ่ววไࠣวํࠦรไอิࠤ้้๊ࠡ์้๋๏ูࠦๆๆํอࠥอไหฯา๎ะ࠭ᅸ"))
	return
def XyGJzjM74bEVSxHv():
	Bcxq3nkvTU9iM(PdkZHNBlpg2b7DmX6qRiyVa,tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪᅹ"),hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠨࡃࡏࡐࡤࡇࡄࡅࡑࡑࡗࡤ࡞ࡍࡍࠩᅺ"))
	yhTBUcFtLgo()
	BCG6aEXrN0 = tkLMTQbNO1D()
	if BCG6aEXrN0:
		SMxv29nWI0HbkqUEVrgymYO(rGPen6cSMHQkAywh8vqI9JXiD2)
		x8mRHgVtiOylF(rGPen6cSMHQkAywh8vqI9JXiD2)
		SqMHwb6X1Ph8jY7LBNkmtV4F5Jlspy(BF6QAiLUNHh7rKOugaw)
	return
def ccVI1JSnbDx(M8hQu61Uid):
	EA7FzO1kMZGQXDd2giB0cwLom = WwMgozBIC32n9d0tyfp.executeJSONRPC(ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡃࡧࡨࡴࡴࡳ࠯ࡕࡨࡸࡆࡪࡤࡰࡰࡈࡲࡦࡨ࡬ࡦࡦࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡣࡧࡨࡴࡴࡩࡥࠤ࠽ࠦࠬᅻ")+M8hQu61Uid+ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠪࠦ࠱ࠨࡥ࡯ࡣࡥࡰࡪࡪࠢ࠻ࡶࡵࡹࡪࢃࡽࠨᅼ"))
	succeeded = rGPen6cSMHQkAywh8vqI9JXiD2 if ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠫࡔࡑࠧᅽ") in EA7FzO1kMZGQXDd2giB0cwLom else BF6QAiLUNHh7rKOugaw
	return succeeded
def ZbH2QAeCiyT6KpOqWhmNsng4k(M8hQu61Uid):
	EA7FzO1kMZGQXDd2giB0cwLom = WwMgozBIC32n9d0tyfp.executeJSONRPC(YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡆࡪࡤࡰࡰࡶ࠲ࡘ࡫ࡴࡂࡦࡧࡳࡳࡋ࡮ࡢࡤ࡯ࡩࡩࠨࠬࠣ࡫ࡧࠦ࠿࠷ࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡦࡪࡤࡰࡰ࡬ࡨࠧࡀࠢࠨᅾ")+M8hQu61Uid+LyNiIHPOwD3hCUYEFM7(u"࠭ࠢ࠭ࠤࡨࡲࡦࡨ࡬ࡦࡦࠥ࠾࡫ࡧ࡬ࡴࡧࢀࢁࠬᅿ"))
	succeeded = rGPen6cSMHQkAywh8vqI9JXiD2 if hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠧࡐࡍࠪᆀ") in EA7FzO1kMZGQXDd2giB0cwLom else BF6QAiLUNHh7rKOugaw
	return succeeded
def UDbFm3VYA1vzHZ2wxTeNJyWM(M8hQu61Uid,showDialogs,By2H4GiYUCdPLp53W9mKI,qQsCzJV2Wgr63in8YF1E0dXf9OSG=None):
	U17QqF2gkI46,succeeded,dNSmqzLRnDpMv,M0A7hVgYLTC3DtidwyIQ = rGPen6cSMHQkAywh8vqI9JXiD2,BF6QAiLUNHh7rKOugaw,tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨᆁ"),iiy37aKq0pCEIOwfcTh61xb4U
	if not qQsCzJV2Wgr63in8YF1E0dXf9OSG: qQsCzJV2Wgr63in8YF1E0dXf9OSG = Mk1o9HmfhFYupBtdi3([M8hQu61Uid])
	if M8hQu61Uid in list(qQsCzJV2Wgr63in8YF1E0dXf9OSG.keys()):
		BCG6aEXrN0,M0A7hVgYLTC3DtidwyIQ,B1U7oLRzXtQGjSeYyv,XwLoV0RdYqZ6CFj9sgGuyOciE,B153K72OyIhV,SSPUNGLfTcBH9lZmCKz,Cqk5fbThjz9LAIUPH = qQsCzJV2Wgr63in8YF1E0dXf9OSG[M8hQu61Uid]
		if SSPUNGLfTcBH9lZmCKz==y6y5HtgXO4TkUbwVZ(u"ࠩࡪࡳࡴࡪࠧᆂ"):
			succeeded,dNSmqzLRnDpMv = rGPen6cSMHQkAywh8vqI9JXiD2,YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠪࡲࡴࡺࡨࡪࡰࡪࠫᆃ")
			if By2H4GiYUCdPLp53W9mKI and showDialogs:
				U17QqF2gkI46 = A1AXKupEOfz(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,ZchUJdM93pTA7zG5(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᆄ"),xpT28sXu051(u"ࠬา๊ะࠢฯำฬࠦ࠮࠯ࠢๆ์ิ๐๋ࠠีอาิ๋ࠠฤะิࠤส฻ฯศำ้ࠣฯ๎แาࠢไ๎๋่ࠥศไ฼ࠤู๊ส้ั฼ࠤ฾๋วะࠢ็๋ีํࠠศๆศฺฬ็ษ࡝ࡰ࡟ࡲࠬᆅ")+M8hQu61Uid+tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"࠭࡜࡯࡞ࡱ๋้ࠦสา์าࠤส฿วะหࠣฮะฮ๊ห๊ࠢิ์ࠦวๅวูหๆฯࠠๆำฬࠤศิั๊ࠩᆆ"))
				if U17QqF2gkI46:
					succeeded = p6JieQVcbmWuIxroRA4v3fCdT(M8hQu61Uid,Cqk5fbThjz9LAIUPH,BF6QAiLUNHh7rKOugaw)
					if succeeded:
						dNSmqzLRnDpMv = SaB5hx3PZwXRLtKgrTfQvId(u"ࠧࡳࡧ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨࠬᆇ")
						if showDialogs: bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,MgP8OjoaiWQEVG59(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᆈ"),yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠩฯ๎ิࠦฬะษࠣ࠲࠳ࠦวๅวูหๆฯࠠไษ้ฮ๋่ࠥอ๊าอࠥ࠴࠮๊ࠡๅห๊ࠦวๅสิ๊ฬ๋ฬࠡสศ฽ฬีษࠡฬฮฬ๏ะ็ศ࡞ࡱࡠࡳ࠭ᆉ")+M8hQu61Uid)
					else:
						dNSmqzLRnDpMv = YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠪࡪࡦ࡯࡬ࡦࡦࠪᆊ")
						bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᆋ"),L90uqo28xEKSFUwYTcm51yRWZIkft(u"๊ࠬไฤีไࠤ࠳࠴ࠠศๆหี๋อๅอࠢ็้ࠥ๐ำหูํ฽ࠥหูศัฬࠤฯัศ๋ฬ๋ࠣีํࠠศๆศฺฬ็ษ࡝ࡰ࡟ࡲࠬᆌ")+M8hQu61Uid)
		else:
			if showDialogs:
				if SSPUNGLfTcBH9lZmCKz==hhQwbeiNLoqFjX90fB7aG8VAs(u"࠭ࡤࡪࡵࡤࡦࡱ࡫ࡤࠨᆍ"): aZtYlicqMKUFPkBCX2AONHwJ4 = yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠧๆฬ๋ๆๆฯࠧᆎ")
				elif SSPUNGLfTcBH9lZmCKz==EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠨࡱ࡯ࡨࠬᆏ"): aZtYlicqMKUFPkBCX2AONHwJ4 = vODxLKW5Ql6r4Fbm8(u"ࠩๅำ๏๋ษࠨᆐ")
				elif SSPUNGLfTcBH9lZmCKz==TlGXWLYsV1z(u"ࠪࡱ࡮ࡹࡳࡪࡰࡪࠫᆑ"): aZtYlicqMKUFPkBCX2AONHwJ4 = MgP8OjoaiWQEVG59(u"ࠫ฿๐ัࠡ็ฮฬฯฯࠧᆒ")
				U17QqF2gkI46 = A1AXKupEOfz(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,vODxLKW5Ql6r4Fbm8(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᆓ"),hhQwbeiNLoqFjX90fB7aG8VAs(u"࠭็ั้ࠣห้หึศใฬࠤࠬᆔ")+aZtYlicqMKUFPkBCX2AONHwJ4+y6y5HtgXO4TkUbwVZ(u"ࠧࠡ࠰࠱ࠤ์๊ࠠหำํำࠥหีๅษะࠤ์ึ็ࠡษ็ู้้ไสࠢยࠥࡡࡴ࡜࡯ࠩᆕ")+M8hQu61Uid)
			if not U17QqF2gkI46: dNSmqzLRnDpMv = xpT28sXu051(u"ࠨࡥࡤࡲࡨ࡫࡬ࡦࡦࠪᆖ")
			else:
				if SSPUNGLfTcBH9lZmCKz==YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠩࡧ࡭ࡸࡧࡢ࡭ࡧࡧࠫᆗ"):
					succeeded = ccVI1JSnbDx(M8hQu61Uid)
					if succeeded:
						dNSmqzLRnDpMv = UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠪࡩࡳࡧࡢ࡭ࡧࡧࠫᆘ")
						if showDialogs: bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᆙ"),Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠬา๊ะࠢฯำฬࠦ࠮࠯ࠢส่ส฼วโหࠣ็ฬ์สࠡ็อ์็็ษࠡ࠰࠱ࠤํ่วๆࠢส่อืๆศ็ฯࠤอะิ฻์็๋ฬࡢ࡮࡝ࡰࠪᆚ")+M8hQu61Uid)
					elif showDialogs: bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,xpT28sXu051(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᆛ"),UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠧๅๆฦืๆࠦ࠮࠯ࠢส่ส฼วโห้ࠣฯ๎โโหࠣ࠲࠳่ࠦๅ็ࠣ๎ุะื๋฻ࠣห้ฮั็ษ่ะࠥะิ฻์็๋ฬࡢ࡮࡝ࡰࠪᆜ")+M8hQu61Uid)
				elif SSPUNGLfTcBH9lZmCKz in [Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠨࡱ࡯ࡨࠬᆝ"),xpT28sXu051(u"ࠩࡰ࡭ࡸࡹࡩ࡯ࡩࠪᆞ")]:
					succeeded = p6JieQVcbmWuIxroRA4v3fCdT(M8hQu61Uid,Cqk5fbThjz9LAIUPH,BF6QAiLUNHh7rKOugaw)
					if succeeded:
						if SSPUNGLfTcBH9lZmCKz==TlGXWLYsV1z(u"ࠪࡳࡱࡪࠧᆟ"): dNSmqzLRnDpMv = UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠫࡺࡶࡤࡢࡶࡨࡨࠬᆠ")
						elif SSPUNGLfTcBH9lZmCKz==tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠬࡳࡩࡴࡵ࡬ࡲ࡬࠭ᆡ"): dNSmqzLRnDpMv = IpC4qHXRuyNFjzWv(u"࠭ࡩ࡯ࡵࡷࡥࡱࡲࡥࡥࠩᆢ")
						M0A7hVgYLTC3DtidwyIQ = XwLoV0RdYqZ6CFj9sgGuyOciE
						if showDialogs:
							if dNSmqzLRnDpMv==GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠧࡶࡲࡧࡥࡹ࡫ࡤࠨᆣ"): bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,FRYcH4KL7e9gv5pEB(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᆤ"),ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠩฯ๎ิࠦฬะษࠣ࠲࠳ࠦวๅวูหๆฯࠠไษ้ฮ่ࠥฯ๋็ฬࠤ࠳࠴้ࠠษ็ฬึ์วๆฮࠣๆฬ๋ࠠษฬะำ๏ั็ศ࡞ࡱࡠࡳ࠭ᆥ")+M8hQu61Uid)
							elif dNSmqzLRnDpMv==PtkEvXAqif14G20QZsaSyT(u"ࠪ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩ࠭ᆦ"): bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,xpT28sXu051(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᆧ"),tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠬา๊ะࠢฯำฬࠦ࠮࠯ࠢส่ส฼วโห่๊ࠣࠦสไ่้ࠣํา่ะหࠣๅ๏ࠦใ้ัํࠤ࠳࠴้ࠠษ็ฬึ์วๆฮࠣๆฬ๋ࠠษฬฮฬ๏ะ็ศ࡞ࡱࡠࡳ࠭ᆨ")+M8hQu61Uid)
					elif showDialogs: bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,Y41NvKfOroMzGB8sEHy7wbXlc5(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᆩ"),sVzojQerUqX(u"ࠧๅๆฦืๆࠦ࠮࠯ࠢส่อืๆศ็ฯࠤ้๋๋ࠠีอ฻๏฿ࠠหฯา๎ะࠦร้ࠢอฯอ๐ส้ࠡำ๋ࠥอไฦุสๅฮࡢ࡮࡝ࡰࠪᆪ")+M8hQu61Uid)
	elif showDialogs: bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,LyNiIHPOwD3hCUYEFM7(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᆫ"),CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠩ็่ศูแࠡ࠰࠱ࠤ์ึ็ࠡษ็ษ฻อแสࠢ฽๎ึࠦๅ้ฮ๋ำฮࠦแ๋่ࠢืฯ๎ฯฺࠢ฼้ฬีࠠ࠯࠰ࠣ์้ํะศࠢ็หࠥ๐ำหูํ฽ࠥอไษำ้ห๊าࠠฤ่ࠣ๎็๎ๅࠡสอฯอ๐ส้ࠡำ๋ࠥอไฦุสๅฮࠦร้ࠢอัิ๐ห่ษ࡟ࡲࡡࡴࠧᆬ")+M8hQu61Uid)
	return succeeded,dNSmqzLRnDpMv,M0A7hVgYLTC3DtidwyIQ
def C98klhwSjxg4mEdzGrBFn6iMIXW1Hf(M8hQu61Uid,showDialogs,GKcwmdIEjtDJXTZk6Q4HASBozYiO07,WAFDxwezmjPgT2ZEbVCiydM=None,AlI5YdVoWgZyP=None):
	H65HghkeCITxdiamFtPrlyMA = rGPen6cSMHQkAywh8vqI9JXiD2 if WAFDxwezmjPgT2ZEbVCiydM else BF6QAiLUNHh7rKOugaw
	if not H65HghkeCITxdiamFtPrlyMA:
		WAFDxwezmjPgT2ZEbVCiydM = m5mc0l3DPgnSoI.connect(i4MTUvPC0IdYDtZ1gOWz7oQGy)
		WAFDxwezmjPgT2ZEbVCiydM.text_factory = str
		AlI5YdVoWgZyP = WAFDxwezmjPgT2ZEbVCiydM.cursor()
	succeeded,JSUHEjTGa7utxyfMI4b0dXView3 = rGPen6cSMHQkAywh8vqI9JXiD2,BF6QAiLUNHh7rKOugaw
	try:
		iFPa18rIeQghup = ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨࠬᆭ")
		AlI5YdVoWgZyP.execute(Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠫࡘࡋࡌࡆࡅࡗࠤࡴࡸࡩࡨ࡫ࡱࠤࡋࡘࡏࡎࠢ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨࠥ࡝ࡈࡆࡔࡈࠤࡦࡪࡤࡰࡰࡌࡈࠥࡃࠠࠣࠩᆮ")+M8hQu61Uid+EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠬࠨࠠ࠼ࠩᆯ"))
		s9Knvz7Ymhy46BErTSpwlUIR = AlI5YdVoWgZyP.fetchall()
		if s9Knvz7Ymhy46BErTSpwlUIR and iFPa18rIeQghup not in str(s9Knvz7Ymhy46BErTSpwlUIR): AlI5YdVoWgZyP.execute(hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"࠭ࡕࡑࡆࡄࡘࡊࠦࡩ࡯ࡵࡷࡥࡱࡲࡥࡥࠢࡖࡉ࡙ࠦ࡯ࡳ࡫ࡪ࡭ࡳࠦ࠽ࠡࠤࠪᆰ")+iFPa18rIeQghup+ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"࡚ࠧࠣࠢࡌࡊࡘࡅࠡࡣࡧࡨࡴࡴࡉࡅࠢࡀࠤࠧ࠭ᆱ")+M8hQu61Uid+uuExaKGL7UONtevRd(u"ࠨࠤࠣ࠿ࠬᆲ"))
		BxrtF9og7aQqbYMyD4hLfk = AbqCJZdWQP9j(u"ࠩࡥࡰࡦࡩ࡫࡭࡫ࡶࡸࠬᆳ") if iELueYz3J1FmxaW7vc else LyNiIHPOwD3hCUYEFM7(u"ࠪࡹࡵࡪࡡࡵࡧࡢࡶࡺࡲࡥࡴࠩᆴ")
		AlI5YdVoWgZyP.execute(yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠫࡘࡋࡌࡆࡅࡗࠤ࠯ࠦࡆࡓࡑࡐࠤࠬᆵ")+BxrtF9og7aQqbYMyD4hLfk+hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠬࠦࡗࡉࡇࡕࡉࠥࡧࡤࡥࡱࡱࡍࡉࠦ࠽ࠡࠤࠪᆶ")+M8hQu61Uid+XrTw01KtLzbpoyMf(u"࠭ࠢࠡ࠽ࠪᆷ"))
		s9Knvz7Ymhy46BErTSpwlUIR = AlI5YdVoWgZyP.fetchall()
		if s9Knvz7Ymhy46BErTSpwlUIR:
			if showDialogs: U17QqF2gkI46 = A1AXKupEOfz(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,FRYcH4KL7e9gv5pEB(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᆸ"),uuExaKGL7UONtevRd(u"ࠨษ็ฮาี๊ฬࠢส่ศ๎ส้็สฮ๏้๊ࠡๆศฺฬ็ษࠡ࡞ࡱࠤࠬᆹ")+M8hQu61Uid+IpC4qHXRuyNFjzWv(u"ࠩࠣࡠࡳࡢ࡮ࠡࠩᆺ")+PSwfZcdRYhpl5Igqz8xOEk67+Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠪࠤ๊ะ่ใใࠣ์้อ๋ࠠ฻่่ࠥ࠴࠮้ࠡ็ࠤฯื๊ะࠢอๅ฾๐ไ่ࠢส่ว์ࠠภࠣࠤࠤࠬᆻ")+YoQW601K4fMJcsreDnGVE5wUZIy7+sVzojQerUqX(u"ࠫࠥࡢ࡮࡝ࡰࠣฮุะื๋฻ࠣษ๏่วโ้ࠣฬุํ่ๅหࠣ฽๋ีࠠศๆ฼์ิฯࠠฦๆ์ࠤ์ึ็ࠡษ็ุฬฺษࠡษ็้ํา่ะหࠣๅ๏ࠦโศศ่อࠥิฯๆษอࠤอืๆศ็ฯࠤ฾๋วะࠩᆼ"))
			else: U17QqF2gkI46 = YYJQyRskpX8jv
			if U17QqF2gkI46==YYJQyRskpX8jv:
				JSUHEjTGa7utxyfMI4b0dXView3 = rGPen6cSMHQkAywh8vqI9JXiD2
				AlI5YdVoWgZyP.execute(L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࠫᆽ")+BxrtF9og7aQqbYMyD4hLfk+ZchUJdM93pTA7zG5(u"࠭ࠠࡘࡊࡈࡖࡊࠦࡡࡥࡦࡲࡲࡎࡊࠠ࠾ࠢࠥࠫᆾ")+M8hQu61Uid+ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠧࠣࠢ࠾ࠫᆿ"))
		elif GKcwmdIEjtDJXTZk6Q4HASBozYiO07:
			if showDialogs: U17QqF2gkI46 = A1AXKupEOfz(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᇀ"),ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠩส่ฯำฯ๋อࠣห้ษ่ห๊่หฯ๐ใ๋ࠢ็ษ฻อแสࠢ࡟ࡲࠥ࠭ᇁ")+M8hQu61Uid+IpC4qHXRuyNFjzWv(u"ࠪࠤࡡࡴ࡜࡯ࠢࠪᇂ")+PSwfZcdRYhpl5Igqz8xOEk67+hhQwbeiNLoqFjX90fB7aG8VAs(u"๋ࠫࠥแฺๆࠣ์๏฿ๅๅࠢ࠱࠲ࠥํไࠡฬิ๎ิࠦล๋ไสๅ์ࠦวๅฤ้ࠤฤࠧࠡࠡࠩᇃ")+YoQW601K4fMJcsreDnGVE5wUZIy7+zmcGfOdvAjsELeJlP(u"ࠬࠦ࡜࡯࡞ࡱࠤฯูสุ์฼ࠤฯ็ู๋ๆ๊ࠤอู็้ๆฬࠤ฾์ฯࠡษ็฽ํีษࠡว็ํࠥํะ่ࠢสู่อิสࠢส่๊๎ฬ้ัฬࠤๆ๐ࠠใษษ้ฮࠦฮะ็สฮࠥฮั็ษ่ะࠥ฿ๅศัࠪᇄ"))
			else: U17QqF2gkI46 = YYJQyRskpX8jv
			if U17QqF2gkI46==YYJQyRskpX8jv:
				JSUHEjTGa7utxyfMI4b0dXView3 = rGPen6cSMHQkAywh8vqI9JXiD2
				if iELueYz3J1FmxaW7vc: AlI5YdVoWgZyP.execute(yJeq1BjfiO4NFuwIEzxVLK6b9s(u"࠭ࡉࡏࡕࡈࡖ࡙ࠦࡉࡏࡖࡒࠤࠬᇅ")+BxrtF9og7aQqbYMyD4hLfk+sVzojQerUqX(u"ࠧࠡࠪࡤࡨࡩࡵ࡮ࡊࡆࠬࠤ࡛ࡇࡌࡖࡇࡖࠤ࠭ࠨࠧᇆ")+M8hQu61Uid+ZchUJdM93pTA7zG5(u"ࠨࠤࠬࠤࡀ࠭ᇇ"))
				else: AlI5YdVoWgZyP.execute(EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠩࡌࡒࡘࡋࡒࡕࠢࡌࡒ࡙ࡕࠠࠨᇈ")+BxrtF9og7aQqbYMyD4hLfk+ZchUJdM93pTA7zG5(u"ࠪࠤ࠭ࡧࡤࡥࡱࡱࡍࡉ࠲ࡵࡱࡦࡤࡸࡪࡘࡵ࡭ࡧࠬࠤ࡛ࡇࡌࡖࡇࡖࠤ࠭ࠨࠧᇉ")+M8hQu61Uid+HtK4o2sTPgA78U(u"ࠫࠧ࠲࠱ࠪࠢ࠾ࠫᇊ"))
	except: succeeded = BF6QAiLUNHh7rKOugaw
	if showDialogs and JSUHEjTGa7utxyfMI4b0dXView3:
		if succeeded: bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᇋ"),GGx4qyKP1vUtRghsE2WfaHLMXZ(u"࠭ๆอฯอࠤ฾๋ไ๋หࠣษฺ๊วฮࠢอัิ๐หࠡษ็ษ฻อแสࠢ࡟ࡲࡡࡴࠧᇌ")+M8hQu61Uid)
		else: bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᇍ"),FRYcH4KL7e9gv5pEB(u"ࠨใื่ฯูࠦๆๆํอࠥหีๅษะࠤฯำฯ๋อࠣห้หึศใฬࠤࡡࡴ࡜࡯ࠩᇎ")+M8hQu61Uid)
	if not H65HghkeCITxdiamFtPrlyMA:
		WAFDxwezmjPgT2ZEbVCiydM.commit()
		WAFDxwezmjPgT2ZEbVCiydM.close()
		if JSUHEjTGa7utxyfMI4b0dXView3:
			X2cQ5NCPvkMieBW7oASspFjE.sleep(sVzojQerUqX(u"࠷ቴ"))
			WwMgozBIC32n9d0tyfp.executebuiltin(uuExaKGL7UONtevRd(u"ࠩࡘࡴࡩࡧࡴࡦࡎࡲࡧࡦࡲࡁࡥࡦࡲࡲࡸ࠭ᇏ"))
			X2cQ5NCPvkMieBW7oASspFjE.sleep(JZszNnIEMAx28Yao0yqhiXGKOPb(u"࠱ት"))
	return JSUHEjTGa7utxyfMI4b0dXView3
def yyZWqpR2rFDOwjXlxcCU53(T0nxf19jK45XgUIchJ8M2zpet,showDialogs,By2H4GiYUCdPLp53W9mKI,GKcwmdIEjtDJXTZk6Q4HASBozYiO07):
	WAFDxwezmjPgT2ZEbVCiydM = m5mc0l3DPgnSoI.connect(i4MTUvPC0IdYDtZ1gOWz7oQGy)
	WAFDxwezmjPgT2ZEbVCiydM.text_factory = str
	AlI5YdVoWgZyP = WAFDxwezmjPgT2ZEbVCiydM.cursor()
	qQsCzJV2Wgr63in8YF1E0dXf9OSG = Mk1o9HmfhFYupBtdi3(T0nxf19jK45XgUIchJ8M2zpet)
	ddnDrOcMpjbGJ = BF6QAiLUNHh7rKOugaw
	for M8hQu61Uid in T0nxf19jK45XgUIchJ8M2zpet:
		succeeded,dNSmqzLRnDpMv,M0A7hVgYLTC3DtidwyIQ = UDbFm3VYA1vzHZ2wxTeNJyWM(M8hQu61Uid,showDialogs,By2H4GiYUCdPLp53W9mKI,qQsCzJV2Wgr63in8YF1E0dXf9OSG)
		JSUHEjTGa7utxyfMI4b0dXView3 = C98klhwSjxg4mEdzGrBFn6iMIXW1Hf(M8hQu61Uid,showDialogs,GKcwmdIEjtDJXTZk6Q4HASBozYiO07,WAFDxwezmjPgT2ZEbVCiydM,AlI5YdVoWgZyP)
		if JSUHEjTGa7utxyfMI4b0dXView3: ddnDrOcMpjbGJ = rGPen6cSMHQkAywh8vqI9JXiD2
	WAFDxwezmjPgT2ZEbVCiydM.commit()
	WAFDxwezmjPgT2ZEbVCiydM.close()
	if ddnDrOcMpjbGJ:
		X2cQ5NCPvkMieBW7oASspFjE.sleep(tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"࠲ቶ"))
		WwMgozBIC32n9d0tyfp.executebuiltin(JZszNnIEMAx28Yao0yqhiXGKOPb(u"࡙ࠪࡵࡪࡡࡵࡧࡏࡳࡨࡧ࡬ࡂࡦࡧࡳࡳࡹࠧᇐ"))
		X2cQ5NCPvkMieBW7oASspFjE.sleep(y6y5HtgXO4TkUbwVZ(u"࠳ቷ"))
	if showDialogs:
		if len(T0nxf19jK45XgUIchJ8M2zpet)>zmcGfOdvAjsELeJlP(u"࠴ቸ"): bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᇑ"),vODxLKW5Ql6r4Fbm8(u"ࠬะๅࠡส้ะฬำࠠโฯุࠤัฺ๋๊ࠢส่ส฼วโษอࠫᇒ"))
		else: bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,y6y5HtgXO4TkUbwVZ(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᇓ"),ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠧห็ࠣฬ๋าวฮࠢไัฺࠦวๅวูหๆฯ࡜࡯࡞ࡱࠫᇔ")+T0nxf19jK45XgUIchJ8M2zpet[ZchUJdM93pTA7zG5(u"࠴ቹ")])
	return
def SMxv29nWI0HbkqUEVrgymYO(showDialogs):
	ZQuksYeI47cHpf5EnySbP8ax2 = [yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭ᇕ"),CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧࠫᇖ"),sVzojQerUqX(u"ࠪࡷࡨࡸࡩࡱࡶ࠱ࡱࡴࡪࡵ࡭ࡧ࠱ࡶࡪࡹ࡯࡭ࡸࡨࡹࡷࡲࠧᇗ"),Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠫࡸࡩࡲࡪࡲࡷ࠲ࡲࡵࡤࡶ࡮ࡨ࠲ࡾࡺ࠭ࡥ࡮ࡳࠫᇘ")]
	Wfg1xK09shUNLD5rkS = [SaB5hx3PZwXRLtKgrTfQvId(u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪ࠮ࡰࡶ࡫ࡩࡷࡹࠧᇙ"),yJeq1BjfiO4NFuwIEzxVLK6b9s(u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤ࠯ࡩ࡬ࡸࡪ࡫ࠧᇚ"),sVzojQerUqX(u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥ࠰ࡳࡽࡹ࡮࡯࡯ࡣࡱࡽࡼ࡮ࡥࡳࡧࠪᇛ"),MgP8OjoaiWQEVG59(u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦ࠱࡫࡮ࡺࡨࡶࡤࠪᇜ"),xpT28sXu051(u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧ࠲࡬࡯ࡴࡦࡣࠪᇝ"),ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨ࠳ࡩ࡯ࡥࡧࡥࡩࡷ࡭ࠧᇞ")]
	for M8hQu61Uid in Wfg1xK09shUNLD5rkS: ZbH2QAeCiyT6KpOqWhmNsng4k(M8hQu61Uid)
	yyZWqpR2rFDOwjXlxcCU53(ZQuksYeI47cHpf5EnySbP8ax2,showDialogs,BF6QAiLUNHh7rKOugaw,BF6QAiLUNHh7rKOugaw)
	return
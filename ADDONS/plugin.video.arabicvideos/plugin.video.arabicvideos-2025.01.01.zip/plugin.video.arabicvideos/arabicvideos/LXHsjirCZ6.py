# -*- coding: utf-8 -*-
from braVAkwfBN import *
sQU2GnRoMwLK8CBdfzmNr4jXyO = 'AKWAMTUBE'
ooQEi5O6tYsGVF8LU0TC3hgMeflBwH = '_AKT_'
JaQEtCzDXgos1cdZN = gZ4LwbKaOm[sQU2GnRoMwLK8CBdfzmNr4jXyO][0]
a8GCLIuWNkS = ['الرئيسية','يلا شوت']
def sHVM8YchrDjZAJ7(mode,url,text):
	if   mode==850: EA7FzO1kMZGQXDd2giB0cwLom = jihuS9LVAvTrClPapMbUEwfn8XN()
	elif mode==851: EA7FzO1kMZGQXDd2giB0cwLom = AIQeNZP4FMDw9S(url,text)
	elif mode==852: EA7FzO1kMZGQXDd2giB0cwLom = TW6Z0zqaDl(url)
	elif mode==853: EA7FzO1kMZGQXDd2giB0cwLom = tN1Y9wIDQqrE6xMhkl(url)
	elif mode==859: EA7FzO1kMZGQXDd2giB0cwLom = mUhJtHB9nw(text)
	else: EA7FzO1kMZGQXDd2giB0cwLom = False
	return EA7FzO1kMZGQXDd2giB0cwLom
def jihuS9LVAvTrClPapMbUEwfn8XN():
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',JaQEtCzDXgos1cdZN,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'AKWAMTUBE-MENU-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'بحث في الموقع',iiy37aKq0pCEIOwfcTh61xb4U,859,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'_REMEMBERRESULTS_')
	bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"primary-links"(.*?)</u',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?<span>(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title in items:
			if title in a8GCLIuWNkS: continue
			bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,851)
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"list-categories"(.*?)</u',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?>(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title in items:
			if 'http' not in fCXyTlcmF4WuetVork: fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN+'/'+fCXyTlcmF4WuetVork.lstrip('/')
			if title in a8GCLIuWNkS: continue
			bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,851)
	return
def AIQeNZP4FMDw9S(url,type=iiy37aKq0pCEIOwfcTh61xb4U):
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'AKWAMTUBE-TITLES-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"home-content"(.*?)"footer"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		PPH1sQtTkDBbnlYpZfo5 = PPH1sQtTkDBbnlYpZfo5.replace('"overlay"','"duration"><')
		items = dEyT9xhGjolYzLCH7460w3.findall('"thumb".*?data-src="(.*?)".*?"duration">(.*?)<.*?href="(.*?)">(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		u3Rztpl4VHO9GZ7jCBM65kvS = []
		for C0dvhEbPWYlUtimM3x,Zt6GY7K2oFeAd5kTy3nJvDBpQr,fCXyTlcmF4WuetVork,title in items:
			title = title.strip(' ')
			title = JIY6A30UOsQboNVqCn(title)
			zN7sZyFnw5JTE8 = dEyT9xhGjolYzLCH7460w3.findall('(.*?) (الحلقة|حلقة).\d+',title,dEyT9xhGjolYzLCH7460w3.DOTALL)
			if 'episodes' not in type and zN7sZyFnw5JTE8:
				title = '_MOD_' + zN7sZyFnw5JTE8[0][0]
				title = title.replace('اون لاين',iiy37aKq0pCEIOwfcTh61xb4U)
				if title not in u3Rztpl4VHO9GZ7jCBM65kvS:
					bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,853,C0dvhEbPWYlUtimM3x)
					u3Rztpl4VHO9GZ7jCBM65kvS.append(title)
			else: bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,852,C0dvhEbPWYlUtimM3x,Zt6GY7K2oFeAd5kTy3nJvDBpQr)
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('''["']pagination["'](.*?)["']footer["']''',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		type = 'episodes_pages' if 'episodes' in type else 'pages'
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)">(.*?)</a>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title in items:
			title = JIY6A30UOsQboNVqCn(title)
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'صفحة '+title,fCXyTlcmF4WuetVork,851,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,type)
	return
def tN1Y9wIDQqrE6xMhkl(url):
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'AKWAMTUBE-SERIES-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('class="eplist"(.*?)</div>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		f9a8L1lCJvn6pIUuP = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)" title="(.*?)"',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title in f9a8L1lCJvn6pIUuP:
			bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,872)
	else:
		fCXyTlcmF4WuetVork = dEyT9xhGjolYzLCH7460w3.findall('"category".*?href="(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if fCXyTlcmF4WuetVork:
			fCXyTlcmF4WuetVork = YqdaDIig21wBTWJeUHbc(fCXyTlcmF4WuetVork[0])
			AIQeNZP4FMDw9S(fCXyTlcmF4WuetVork,'episodes')
	return
def TW6Z0zqaDl(url):
	ff2PjlcCF5ZWyIUbVguMz = []
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'AKWAMTUBE-PLAY-2nd')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	if 'hash=' in Vxz6OndPIX4g2kaRp7:
		xkQc7HUzeP4F = dEyT9xhGjolYzLCH7460w3.findall('hash=(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		xkQc7HUzeP4F = list(set(xkQc7HUzeP4F))
		for H0BbXRwP5vOqS in xkQc7HUzeP4F:
			kKU0my3NP8sD = []
			ng8RFTvpBOxuMa2ySjYWqVZX = H0BbXRwP5vOqS.split('__')
			for jBaSGYDb0LuQ9dNAOzRpvT4CgHKMW in ng8RFTvpBOxuMa2ySjYWqVZX:
				try:
					jBaSGYDb0LuQ9dNAOzRpvT4CgHKMW = UodGe76Lu2IHTYPxBhjk1RpcaqrM.b64decode(jBaSGYDb0LuQ9dNAOzRpvT4CgHKMW+'=')
					if J1MoiYc7ZwzKS: jBaSGYDb0LuQ9dNAOzRpvT4CgHKMW = jBaSGYDb0LuQ9dNAOzRpvT4CgHKMW.decode(df6QpwGxuJVZr)
					kKU0my3NP8sD.append(jBaSGYDb0LuQ9dNAOzRpvT4CgHKMW)
				except: pass
			P3tys0cXWbiIUKk7HQ6n89V = '>'.join(kKU0my3NP8sD)
			P3tys0cXWbiIUKk7HQ6n89V = P3tys0cXWbiIUKk7HQ6n89V.splitlines()
			for fCXyTlcmF4WuetVork in P3tys0cXWbiIUKk7HQ6n89V:
				if ' => ' in fCXyTlcmF4WuetVork:
					title,fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork.split(' => ')
					fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork+'?named='+title+'__watch'
					ff2PjlcCF5ZWyIUbVguMz.append(fCXyTlcmF4WuetVork)
	elif 'post_id' in Vxz6OndPIX4g2kaRp7:
		VlX2C0mPxeyD8wZYKLuf = dEyT9xhGjolYzLCH7460w3.findall("post_id = '(.*?)'",Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if VlX2C0mPxeyD8wZYKLuf:
			VlX2C0mPxeyD8wZYKLuf = VlX2C0mPxeyD8wZYKLuf[0]
			fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN+'/wp-admin/admin-ajax.php?action=video_info&post_id='+VlX2C0mPxeyD8wZYKLuf
			oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',fCXyTlcmF4WuetVork,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'ALMSTBA-PLAY-2nd')
			Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
			P3tys0cXWbiIUKk7HQ6n89V = dEyT9xhGjolYzLCH7460w3.findall('"name":"(.*?)","src":"(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
			if not P3tys0cXWbiIUKk7HQ6n89V: P3tys0cXWbiIUKk7HQ6n89V = dEyT9xhGjolYzLCH7460w3.findall('"(src)":"(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
			for name,fCXyTlcmF4WuetVork in P3tys0cXWbiIUKk7HQ6n89V:
				fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork.replace('\\/','/')
				fCXyTlcmF4WuetVork = YqdaDIig21wBTWJeUHbc(fCXyTlcmF4WuetVork)
				if name=='src': name = ''
				ff2PjlcCF5ZWyIUbVguMz.append(fCXyTlcmF4WuetVork+'?named='+name+'__watch')
	import lqBJGK8hXO
	lqBJGK8hXO.ZDg1HavwueT85mcAOorC4hnS(ff2PjlcCF5ZWyIUbVguMz,sQU2GnRoMwLK8CBdfzmNr4jXyO,'video',url)
	return
def mUhJtHB9nw(search):
	search,brFQp5vmgJWdZfEkCBOlu9c,showDialogs = XkYnev3ZCA6ahO94(search)
	if search==iiy37aKq0pCEIOwfcTh61xb4U: search = TTBf6S08q1NKXd5v9wa()
	if search==iiy37aKq0pCEIOwfcTh61xb4U: return
	search = search.replace(iFBmE2MUIpSu34wsd7Rf6z,'+')
	url = JaQEtCzDXgos1cdZN+'/?s='+search
	AIQeNZP4FMDw9S(url,'search')
	return
# -*- coding: utf-8 -*-
from braVAkwfBN import *
sQU2GnRoMwLK8CBdfzmNr4jXyO = 'EGYNOW'
ooQEi5O6tYsGVF8LU0TC3hgMeflBwH = '_EGN_'
JaQEtCzDXgos1cdZN = gZ4LwbKaOm[sQU2GnRoMwLK8CBdfzmNr4jXyO][0]
a8GCLIuWNkS = ['عروض مصارعة','الكل','n/A','المزيد','قصة عشق']
def sHVM8YchrDjZAJ7(mode,url,text):
	if   mode==430: EA7FzO1kMZGQXDd2giB0cwLom = jihuS9LVAvTrClPapMbUEwfn8XN()
	elif mode==431: EA7FzO1kMZGQXDd2giB0cwLom = AIQeNZP4FMDw9S(url,text)
	elif mode==432: EA7FzO1kMZGQXDd2giB0cwLom = TW6Z0zqaDl(url)
	elif mode==433: EA7FzO1kMZGQXDd2giB0cwLom = YNcMvoVF5swlDBJI7PL(url)
	elif mode==434: EA7FzO1kMZGQXDd2giB0cwLom = chQHNdWgTSDjti8R9pJUf(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==435: EA7FzO1kMZGQXDd2giB0cwLom = chQHNdWgTSDjti8R9pJUf(url,'SPECIFIED_FILTER___'+text)
	elif mode==436: EA7FzO1kMZGQXDd2giB0cwLom = BaSyudevC40nsQHW5j7JX6RM9(url)
	elif mode==437: EA7FzO1kMZGQXDd2giB0cwLom = ooWayg7xku3KeicwrpBjITmGZ2zqh(url)
	elif mode==439: EA7FzO1kMZGQXDd2giB0cwLom = mUhJtHB9nw(text)
	else: EA7FzO1kMZGQXDd2giB0cwLom = False
	return EA7FzO1kMZGQXDd2giB0cwLom
def jihuS9LVAvTrClPapMbUEwfn8XN():
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',JaQEtCzDXgos1cdZN+'/films',iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'EGYNOW-MENU-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	ffBG4TaQU8lVF26R = dEyT9xhGjolYzLCH7460w3.findall('"canonical" href="(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	ffBG4TaQU8lVF26R = ffBG4TaQU8lVF26R[0].strip('/')
	ffBG4TaQU8lVF26R = F82MvyX4ThI6sbnA3efDoVS(ffBG4TaQU8lVF26R,'url')
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'بحث في الموقع',iiy37aKq0pCEIOwfcTh61xb4U,439,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'_REMEMBERRESULTS_')
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'فلتر محدد',ffBG4TaQU8lVF26R,435)
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'فلتر كامل',ffBG4TaQU8lVF26R,434)
	bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'المضاف حديثا',ffBG4TaQU8lVF26R,431)
	bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'افلام اون لاين',ffBG4TaQU8lVF26R+'/films1',436)
	bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'مسلسلات اون لاين',ffBG4TaQU8lVF26R+'/series-all1',436)
	bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'قائمة تفصيلية',ffBG4TaQU8lVF26R,437)
	bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"SiteNavigation"(.*?)"Search"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
	items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?>(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	for fCXyTlcmF4WuetVork,title in items:
		if title in a8GCLIuWNkS: continue
		if title=='الرئيسية': continue
		if 'اون لاين' in title: continue
		bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,431)
	return
def ooWayg7xku3KeicwrpBjITmGZ2zqh(website=iiy37aKq0pCEIOwfcTh61xb4U):
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',website+'/films',iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'EGYNOW-MENU-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	ffBG4TaQU8lVF26R = dEyT9xhGjolYzLCH7460w3.findall('"canonical" href="(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	ffBG4TaQU8lVF26R = ffBG4TaQU8lVF26R[0].strip('/')
	ffBG4TaQU8lVF26R = F82MvyX4ThI6sbnA3efDoVS(ffBG4TaQU8lVF26R,'url')
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"ListDroped"(.*?)"SearchingMaster"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
	items = dEyT9xhGjolYzLCH7460w3.findall('data-tax="(.*?)" data-term="(.*?)" data-name="(.*?)"',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	for RRIscyLmNH9dq2Dio3TSr,aasX2cby4Vo5rTgB,title in items:
		if title in a8GCLIuWNkS: continue
		fCXyTlcmF4WuetVork = website+'/explore/?'+RRIscyLmNH9dq2Dio3TSr+'='+aasX2cby4Vo5rTgB
		bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,431)
	return
def BaSyudevC40nsQHW5j7JX6RM9(url):
	ffBG4TaQU8lVF26R = F82MvyX4ThI6sbnA3efDoVS(url,'url')
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'EGYNOW-SUBMENU-1st')
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'الجميع',url,431)
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"titleSectionCon"(.*?)</div></div>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
	items = dEyT9xhGjolYzLCH7460w3.findall('data-key="(.*?)".*?<em>(.*?)</em>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	for Ax2k5gsahJCBE30DfntcyXL7P,title in items:
		if title in a8GCLIuWNkS: continue
		eCGwzSrqBmIv = ffBG4TaQU8lVF26R+'/wp-content/themes/EgyNowByElshaikh/Ajaxt/Movies/Keys.php?key='+Ax2k5gsahJCBE30DfntcyXL7P
		bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,eCGwzSrqBmIv,431)
	return
def AIQeNZP4FMDw9S(url,lHDuLVCy8kvqB6Rxh4Gs5K=iiy37aKq0pCEIOwfcTh61xb4U):
	ffBG4TaQU8lVF26R = F82MvyX4ThI6sbnA3efDoVS(url,'url')
	items = []
	if '/Terms.php' in url or '/Get.php' in url or '/Keys.php' in url:
		eCGwzSrqBmIv,EwsmJ67cCYDIlg = sFNjagPK4W(url)
		rzR9SN7ApZuQhTDWEX3V6ga = {'X-Requested-With':'XMLHttpRequest','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'POST',eCGwzSrqBmIv,EwsmJ67cCYDIlg,rzR9SN7ApZuQhTDWEX3V6ga,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'EGYNOW-TITLES-1st')
		Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
		PPH1sQtTkDBbnlYpZfo5 = Vxz6OndPIX4g2kaRp7
	elif lHDuLVCy8kvqB6Rxh4Gs5K=='featured':
		oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'EGYNOW-TITLES-2nd')
		Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"MainSlider"(.*?)"MatchesTable"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('<a href="(.*?)" title="(.*?)".*?image: url\((.*?)\)',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	else:
		oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'EGYNOW-TITLES-2nd')
		Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"BlocksList"(.*?)"Paginate"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if not UUIohmv597bO83YCLgWS: UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"BlocksList"(.*?)"titleSectionCon"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
	if not items: items = dEyT9xhGjolYzLCH7460w3.findall('<a href="(.*?)" title="(.*?)".*?data-image="(.*?)"',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	u3Rztpl4VHO9GZ7jCBM65kvS = []
	mxXKsCgL5OoP1evURZ8SdIfpBrwu = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for fCXyTlcmF4WuetVork,title,C0dvhEbPWYlUtimM3x in items:
		fCXyTlcmF4WuetVork = a9I3YZjc6ySDPE4Kp(fCXyTlcmF4WuetVork).strip('/')
		title = JIY6A30UOsQboNVqCn(title)
		zN7sZyFnw5JTE8 = dEyT9xhGjolYzLCH7460w3.findall('(.*?) الحلقة \d+',title,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if any(aasX2cby4Vo5rTgB in title for aasX2cby4Vo5rTgB in mxXKsCgL5OoP1evURZ8SdIfpBrwu):
			bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,432,C0dvhEbPWYlUtimM3x)
		elif zN7sZyFnw5JTE8 and 'الحلقة' in title:
			title = '_MOD_' + zN7sZyFnw5JTE8[0]
			if title not in u3Rztpl4VHO9GZ7jCBM65kvS:
				bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,433,C0dvhEbPWYlUtimM3x)
				u3Rztpl4VHO9GZ7jCBM65kvS.append(title)
		elif '/movseries/' in fCXyTlcmF4WuetVork:
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,431,C0dvhEbPWYlUtimM3x)
		else: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,433,C0dvhEbPWYlUtimM3x)
	if lHDuLVCy8kvqB6Rxh4Gs5K!='featured':
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"Paginate"(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if UUIohmv597bO83YCLgWS:
			PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
			items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)">(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
			for fCXyTlcmF4WuetVork,title in items:
				if 'http' not in fCXyTlcmF4WuetVork: fCXyTlcmF4WuetVork = ffBG4TaQU8lVF26R+fCXyTlcmF4WuetVork
				fCXyTlcmF4WuetVork = JIY6A30UOsQboNVqCn(fCXyTlcmF4WuetVork)
				title = JIY6A30UOsQboNVqCn(title)
				if title!=iiy37aKq0pCEIOwfcTh61xb4U: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'صفحة '+title,fCXyTlcmF4WuetVork,431)
		SwiW9ygZnaTl53PVbKzRtY = dEyT9xhGjolYzLCH7460w3.findall('showmore" href="(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if SwiW9ygZnaTl53PVbKzRtY:
			fCXyTlcmF4WuetVork = SwiW9ygZnaTl53PVbKzRtY[0]
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'مشاهدة المزيد',fCXyTlcmF4WuetVork,431)
	return
def YNcMvoVF5swlDBJI7PL(url):
	ffBG4TaQU8lVF26R = F82MvyX4ThI6sbnA3efDoVS(url,'url')
	HG5rE20ORdbqUKWewuZCJP4zoXF6g,eTov6CfDcRZVJEAq5BH = [],[]
	if 'Episodes.php' in url:
		eCGwzSrqBmIv,EwsmJ67cCYDIlg = sFNjagPK4W(url)
		rzR9SN7ApZuQhTDWEX3V6ga = {'X-Requested-With':'XMLHttpRequest','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'POST',eCGwzSrqBmIv,EwsmJ67cCYDIlg,rzR9SN7ApZuQhTDWEX3V6ga,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'EGYNOW-EPISODES-1st')
		Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
		eTov6CfDcRZVJEAq5BH = [Vxz6OndPIX4g2kaRp7]
	else:
		oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'EGYNOW-EPISODES-2nd')
		Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
		HG5rE20ORdbqUKWewuZCJP4zoXF6g = dEyT9xhGjolYzLCH7460w3.findall('"SeasonsList"(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		eTov6CfDcRZVJEAq5BH = dEyT9xhGjolYzLCH7460w3.findall('"EpisodesList"(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if HG5rE20ORdbqUKWewuZCJP4zoXF6g:
		C0dvhEbPWYlUtimM3x = dEyT9xhGjolYzLCH7460w3.findall('"og:image" content="(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		C0dvhEbPWYlUtimM3x = C0dvhEbPWYlUtimM3x[0]
		PPH1sQtTkDBbnlYpZfo5 = HG5rE20ORdbqUKWewuZCJP4zoXF6g[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('data-id="(.*?)".*?data-season="(.*?)".*?">(.*?)</a>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for H0BbXRwP5vOqS,KFS2gaqMTLJpr0h,title in items:
			fCXyTlcmF4WuetVork = ffBG4TaQU8lVF26R+'/wp-content/themes/EgyNowByElshaikh/Ajaxt/Single/Episodes.php?'+'season='+KFS2gaqMTLJpr0h+'&post_id='+H0BbXRwP5vOqS
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,433,C0dvhEbPWYlUtimM3x)
	elif eTov6CfDcRZVJEAq5BH:
		C0dvhEbPWYlUtimM3x = WwMgozBIC32n9d0tyfp.getInfoLabel('ListItem.Thumb')
		PPH1sQtTkDBbnlYpZfo5 = eTov6CfDcRZVJEAq5BH[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?</i>(.*?)<em>(.*?)</em>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title,zN7sZyFnw5JTE8 in items:
			title = title+iFBmE2MUIpSu34wsd7Rf6z+zN7sZyFnw5JTE8
			bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,432,C0dvhEbPWYlUtimM3x)
	return
def TW6Z0zqaDl(url):
	eCGwzSrqBmIv = url+'/watch/'
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',eCGwzSrqBmIv,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'EGYNOW-PLAY-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	duef0gb3Mi1AV5WpN8 = []
	ffBG4TaQU8lVF26R = F82MvyX4ThI6sbnA3efDoVS(eCGwzSrqBmIv,'url')
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"container-servers"(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		l6lm7giRe1UzEDIvb5 = dEyT9xhGjolYzLCH7460w3.findall('data-id="(.*?)"',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if l6lm7giRe1UzEDIvb5:
			l6lm7giRe1UzEDIvb5 = l6lm7giRe1UzEDIvb5[0]
			items = dEyT9xhGjolYzLCH7460w3.findall('data-server="(.*?)".*?<span>(.*?)</span>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
			for Zw4M5DUStdE6xp7GI,title in items:
				fCXyTlcmF4WuetVork = ffBG4TaQU8lVF26R+'/wp-content/themes/EgyNowByElshaikh/Ajaxt/Single/Server.php?server='+Zw4M5DUStdE6xp7GI+'&post_id='+l6lm7giRe1UzEDIvb5+'?named='+title+'__watch'
				duef0gb3Mi1AV5WpN8.append(fCXyTlcmF4WuetVork)
	gbHP10xvrEmBAQsTkuwGoyeIz = dEyT9xhGjolYzLCH7460w3.findall('"container-iframe"><iframe src="(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if gbHP10xvrEmBAQsTkuwGoyeIz:
		gbHP10xvrEmBAQsTkuwGoyeIz = gbHP10xvrEmBAQsTkuwGoyeIz[0].replace(OTlVEGYPSxsNaBdXUucqA3,iiy37aKq0pCEIOwfcTh61xb4U)
		title = F82MvyX4ThI6sbnA3efDoVS(gbHP10xvrEmBAQsTkuwGoyeIz,'name')
		fCXyTlcmF4WuetVork = gbHP10xvrEmBAQsTkuwGoyeIz+'?named='+title+'__embed'
		duef0gb3Mi1AV5WpN8.append(fCXyTlcmF4WuetVork)
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"container-download"(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?span>(.*?)<.*?em>(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title,pMAWqrwP80lR in items:
			fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork.replace(OTlVEGYPSxsNaBdXUucqA3,iiy37aKq0pCEIOwfcTh61xb4U)
			if pMAWqrwP80lR!=iiy37aKq0pCEIOwfcTh61xb4U: pMAWqrwP80lR = '____'+pMAWqrwP80lR
			fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork+'?named='+title+'__download'+pMAWqrwP80lR
			duef0gb3Mi1AV5WpN8.append(fCXyTlcmF4WuetVork)
	import lqBJGK8hXO
	lqBJGK8hXO.ZDg1HavwueT85mcAOorC4hnS(duef0gb3Mi1AV5WpN8,sQU2GnRoMwLK8CBdfzmNr4jXyO,'video',url)
	return
def mUhJtHB9nw(search):
	search,brFQp5vmgJWdZfEkCBOlu9c,showDialogs = XkYnev3ZCA6ahO94(search)
	if search==iiy37aKq0pCEIOwfcTh61xb4U: search = TTBf6S08q1NKXd5v9wa()
	if search==iiy37aKq0pCEIOwfcTh61xb4U: return
	search = search.replace(iFBmE2MUIpSu34wsd7Rf6z,'%20')
	url = JaQEtCzDXgos1cdZN+'/?s='+search
	AIQeNZP4FMDw9S(url)
	return
def Dv235GCSiTYasugHxhbPUVjdKkcprN(url):
	url = url.split('/smartemadfilter?')[0]
	ffBG4TaQU8lVF26R = F82MvyX4ThI6sbnA3efDoVS(url,'url')
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(Dxc7GChQwZ4kOlKHSbL06agnB,'GET',ffBG4TaQU8lVF26R,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'EGYNOW-GET_FILTERS_BLOCKS-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('("dropdown-button".*?)"SearchingMaster"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
	n8nFIQBNaXD = dEyT9xhGjolYzLCH7460w3.findall('"dropdown-button".*?<em>(.*?)</em>(.*?data-tax="(.*?)".*?</div>)',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	return n8nFIQBNaXD
def T6TdxbQOnA(PPH1sQtTkDBbnlYpZfo5):
	items = dEyT9xhGjolYzLCH7460w3.findall('data-term="(\d+)" data-name="(.*?)"',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	return items
def FvYaT7p0Wi3unK6(url):
	UM3q9WaVXOP4ZuhCnHB5jyA = url.split('/smartemadfilter?')[0]
	VrnhdEezI7 = F82MvyX4ThI6sbnA3efDoVS(url,'url')
	url = url.replace(UM3q9WaVXOP4ZuhCnHB5jyA,VrnhdEezI7)
	url = url.replace('/smartemadfilter?','/explore/?')
	return url
def qqYDzAbCaOtrUjcgeyHx(vvlVH6JT9YDNPeSaRUkKCAwpr5uq,url):
	bPXk8KHyCUrifag = qJ8NQtuWARGjoZd9swfbH(vvlVH6JT9YDNPeSaRUkKCAwpr5uq,'modified_filters')
	O5Pwg3UFyX0k9E = url+'/smartemadfilter?'+bPXk8KHyCUrifag
	O5Pwg3UFyX0k9E = FvYaT7p0Wi3unK6(O5Pwg3UFyX0k9E)
	return O5Pwg3UFyX0k9E
JYMlXTc9DCZrohd = ['category','country','genre','release-year']
a3aiAqYngfydR1XNJK975wl4jD = ['quality','release-year','genre','category','language','country']
def chQHNdWgTSDjti8R9pJUf(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==iiy37aKq0pCEIOwfcTh61xb4U: Mhd9LWrfiF1EsASl6eP34uTp0qNGom,ovh6cXGg1qd85fn3CSJEisTlI7Yz = iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U
	else: Mhd9LWrfiF1EsASl6eP34uTp0qNGom,ovh6cXGg1qd85fn3CSJEisTlI7Yz = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if JYMlXTc9DCZrohd[0]+'=' not in Mhd9LWrfiF1EsASl6eP34uTp0qNGom: RRIscyLmNH9dq2Dio3TSr = JYMlXTc9DCZrohd[0]
		for iEfNKT3velFyGth80SA4pxbCRrVD in range(len(JYMlXTc9DCZrohd[0:-1])):
			if JYMlXTc9DCZrohd[iEfNKT3velFyGth80SA4pxbCRrVD]+'=' in Mhd9LWrfiF1EsASl6eP34uTp0qNGom: RRIscyLmNH9dq2Dio3TSr = JYMlXTc9DCZrohd[iEfNKT3velFyGth80SA4pxbCRrVD+1]
		HdFJThcNtWe3lb8n4OmaSwQ = Mhd9LWrfiF1EsASl6eP34uTp0qNGom+'&'+RRIscyLmNH9dq2Dio3TSr+'=0'
		vvlVH6JT9YDNPeSaRUkKCAwpr5uq = ovh6cXGg1qd85fn3CSJEisTlI7Yz+'&'+RRIscyLmNH9dq2Dio3TSr+'=0'
		cCZR4YdwUepABD9mQsubT8FgN = HdFJThcNtWe3lb8n4OmaSwQ.strip('&')+'___'+vvlVH6JT9YDNPeSaRUkKCAwpr5uq.strip('&')
		bPXk8KHyCUrifag = qJ8NQtuWARGjoZd9swfbH(ovh6cXGg1qd85fn3CSJEisTlI7Yz,'modified_filters')
		eCGwzSrqBmIv = url+'/smartemadfilter?'+bPXk8KHyCUrifag
	elif type=='ALL_ITEMS_FILTER':
		GMQ6AxE012X9 = qJ8NQtuWARGjoZd9swfbH(Mhd9LWrfiF1EsASl6eP34uTp0qNGom,'modified_values')
		GMQ6AxE012X9 = a9I3YZjc6ySDPE4Kp(GMQ6AxE012X9)
		if ovh6cXGg1qd85fn3CSJEisTlI7Yz!=iiy37aKq0pCEIOwfcTh61xb4U: ovh6cXGg1qd85fn3CSJEisTlI7Yz = qJ8NQtuWARGjoZd9swfbH(ovh6cXGg1qd85fn3CSJEisTlI7Yz,'modified_filters')
		if ovh6cXGg1qd85fn3CSJEisTlI7Yz==iiy37aKq0pCEIOwfcTh61xb4U: eCGwzSrqBmIv = url
		else: eCGwzSrqBmIv = url+'/smartemadfilter?'+ovh6cXGg1qd85fn3CSJEisTlI7Yz
		eCGwzSrqBmIv = FvYaT7p0Wi3unK6(eCGwzSrqBmIv)
		bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'أظهار قائمة الفيديو التي تم اختيارها ',eCGwzSrqBmIv,431)
		bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+' [[   '+GMQ6AxE012X9+'   ]]',eCGwzSrqBmIv,431)
		bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	n8nFIQBNaXD = Dv235GCSiTYasugHxhbPUVjdKkcprN(url)
	dict = {}
	for name,PPH1sQtTkDBbnlYpZfo5,cWhMpFIbQU4D1Bi in n8nFIQBNaXD:
		name = name.replace('--',iiy37aKq0pCEIOwfcTh61xb4U)
		items = T6TdxbQOnA(PPH1sQtTkDBbnlYpZfo5)
		if '=' not in eCGwzSrqBmIv: eCGwzSrqBmIv = url
		if type=='SPECIFIED_FILTER':
			if RRIscyLmNH9dq2Dio3TSr!=cWhMpFIbQU4D1Bi: continue
			elif len(items)<2:
				if cWhMpFIbQU4D1Bi==JYMlXTc9DCZrohd[-1]:
					url = FvYaT7p0Wi3unK6(url)
					AIQeNZP4FMDw9S(url)
				else: chQHNdWgTSDjti8R9pJUf(eCGwzSrqBmIv,'SPECIFIED_FILTER___'+cCZR4YdwUepABD9mQsubT8FgN)
				return
			else:
				eCGwzSrqBmIv = FvYaT7p0Wi3unK6(eCGwzSrqBmIv)
				if cWhMpFIbQU4D1Bi==JYMlXTc9DCZrohd[-1]: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'الجميع ',eCGwzSrqBmIv,431)
				else: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'الجميع ',eCGwzSrqBmIv,435,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,cCZR4YdwUepABD9mQsubT8FgN)
		elif type=='ALL_ITEMS_FILTER':
			HdFJThcNtWe3lb8n4OmaSwQ = Mhd9LWrfiF1EsASl6eP34uTp0qNGom+'&'+cWhMpFIbQU4D1Bi+'=0'
			vvlVH6JT9YDNPeSaRUkKCAwpr5uq = ovh6cXGg1qd85fn3CSJEisTlI7Yz+'&'+cWhMpFIbQU4D1Bi+'=0'
			cCZR4YdwUepABD9mQsubT8FgN = HdFJThcNtWe3lb8n4OmaSwQ+'___'+vvlVH6JT9YDNPeSaRUkKCAwpr5uq
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'الجميع :'+name,eCGwzSrqBmIv,434,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,cCZR4YdwUepABD9mQsubT8FgN)
		dict[cWhMpFIbQU4D1Bi] = {}
		for aasX2cby4Vo5rTgB,KjsA38t0DCSmuLcaE in items:
			if aasX2cby4Vo5rTgB=='196533': KjsA38t0DCSmuLcaE = 'أفلام نيتفلكس'
			elif aasX2cby4Vo5rTgB=='196531': KjsA38t0DCSmuLcaE = 'مسلسلات نيتفلكس'
			if KjsA38t0DCSmuLcaE in a8GCLIuWNkS: continue
			dict[cWhMpFIbQU4D1Bi][aasX2cby4Vo5rTgB] = KjsA38t0DCSmuLcaE
			HdFJThcNtWe3lb8n4OmaSwQ = Mhd9LWrfiF1EsASl6eP34uTp0qNGom+'&'+cWhMpFIbQU4D1Bi+'='+KjsA38t0DCSmuLcaE
			vvlVH6JT9YDNPeSaRUkKCAwpr5uq = ovh6cXGg1qd85fn3CSJEisTlI7Yz+'&'+cWhMpFIbQU4D1Bi+'='+aasX2cby4Vo5rTgB
			kuyfTIwjRrhXUo = HdFJThcNtWe3lb8n4OmaSwQ+'___'+vvlVH6JT9YDNPeSaRUkKCAwpr5uq
			title = KjsA38t0DCSmuLcaE+' :'#+dict[cWhMpFIbQU4D1Bi]['0']
			title = KjsA38t0DCSmuLcaE+' :'+name
			if type=='ALL_ITEMS_FILTER': bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,url,434,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,kuyfTIwjRrhXUo)
			elif type=='SPECIFIED_FILTER' and JYMlXTc9DCZrohd[-2]+'=' in Mhd9LWrfiF1EsASl6eP34uTp0qNGom:
				O5Pwg3UFyX0k9E = qqYDzAbCaOtrUjcgeyHx(vvlVH6JT9YDNPeSaRUkKCAwpr5uq,url)
				bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,O5Pwg3UFyX0k9E,431)
			else: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,url,435,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,kuyfTIwjRrhXUo)
	return
def qJ8NQtuWARGjoZd9swfbH(HSAqBpsb2jRLvk9lx147rzY,mode):
	HSAqBpsb2jRLvk9lx147rzY = HSAqBpsb2jRLvk9lx147rzY.replace('=&','=0&')
	HSAqBpsb2jRLvk9lx147rzY = HSAqBpsb2jRLvk9lx147rzY.strip('&')
	x8UiIH3WCTEpe = {}
	if '=' in HSAqBpsb2jRLvk9lx147rzY:
		items = HSAqBpsb2jRLvk9lx147rzY.split('&')
		for YXD9KNfjCaLwkcrvJxldn7I in items:
			xYkDXe5UjvETygJNLrRQ96mtp8BKGW,aasX2cby4Vo5rTgB = YXD9KNfjCaLwkcrvJxldn7I.split('=')
			x8UiIH3WCTEpe[xYkDXe5UjvETygJNLrRQ96mtp8BKGW] = aasX2cby4Vo5rTgB
	QAvGYocVXgzh9 = iiy37aKq0pCEIOwfcTh61xb4U
	for key in a3aiAqYngfydR1XNJK975wl4jD:
		if key in list(x8UiIH3WCTEpe.keys()): aasX2cby4Vo5rTgB = x8UiIH3WCTEpe[key]
		else: aasX2cby4Vo5rTgB = '0'
		if '%' not in aasX2cby4Vo5rTgB: aasX2cby4Vo5rTgB = YqdaDIig21wBTWJeUHbc(aasX2cby4Vo5rTgB)
		if mode=='modified_values' and aasX2cby4Vo5rTgB!='0': QAvGYocVXgzh9 = QAvGYocVXgzh9+' + '+aasX2cby4Vo5rTgB
		elif mode=='modified_filters' and aasX2cby4Vo5rTgB!='0': QAvGYocVXgzh9 = QAvGYocVXgzh9+'&'+key+'='+aasX2cby4Vo5rTgB
		elif mode=='all_filters': QAvGYocVXgzh9 = QAvGYocVXgzh9+'&'+key+'='+aasX2cby4Vo5rTgB
	QAvGYocVXgzh9 = QAvGYocVXgzh9.strip(' + ')
	QAvGYocVXgzh9 = QAvGYocVXgzh9.strip('&')
	QAvGYocVXgzh9 = QAvGYocVXgzh9.replace('=0','=')
	return QAvGYocVXgzh9
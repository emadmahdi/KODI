# -*- coding: utf-8 -*-
from braVAkwfBN import *
sQU2GnRoMwLK8CBdfzmNr4jXyO = 'CIMACLUP'
ooQEi5O6tYsGVF8LU0TC3hgMeflBwH = '_CMC_'
JaQEtCzDXgos1cdZN = gZ4LwbKaOm[sQU2GnRoMwLK8CBdfzmNr4jXyO][0]
a8GCLIuWNkS = ['موقع نتفليكس']
def sHVM8YchrDjZAJ7(mode,url,text):
	if   mode==490: EA7FzO1kMZGQXDd2giB0cwLom = jihuS9LVAvTrClPapMbUEwfn8XN()
	elif mode==491: EA7FzO1kMZGQXDd2giB0cwLom = AIQeNZP4FMDw9S(url,text)
	elif mode==492: EA7FzO1kMZGQXDd2giB0cwLom = TW6Z0zqaDl(url)
	elif mode==493: EA7FzO1kMZGQXDd2giB0cwLom = YNcMvoVF5swlDBJI7PL(url)
	elif mode==494: EA7FzO1kMZGQXDd2giB0cwLom = BaSyudevC40nsQHW5j7JX6RM9(url)
	elif mode==499: EA7FzO1kMZGQXDd2giB0cwLom = mUhJtHB9nw(text,url)
	else: EA7FzO1kMZGQXDd2giB0cwLom = False
	return EA7FzO1kMZGQXDd2giB0cwLom
def jihuS9LVAvTrClPapMbUEwfn8XN():
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',JaQEtCzDXgos1cdZN,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'CIMACLUP-MENU-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	ffBG4TaQU8lVF26R = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	ffBG4TaQU8lVF26R = ffBG4TaQU8lVF26R[0].strip('/')
	ffBG4TaQU8lVF26R = F82MvyX4ThI6sbnA3efDoVS(ffBG4TaQU8lVF26R,'url')
	eTov6CfDcRZVJEAq5BH = dEyT9xhGjolYzLCH7460w3.findall('"filter AjaxifyFilter"(.*?)</div>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if eTov6CfDcRZVJEAq5BH:
		PPH1sQtTkDBbnlYpZfo5 = eTov6CfDcRZVJEAq5BH[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('data-filter="(.*?)".*?>(.*?)</a>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title in items:
			if title in a8GCLIuWNkS: continue
			fCXyTlcmF4WuetVork = ffBG4TaQU8lVF26R+'/wp-content/themes/old/filter/'+fCXyTlcmF4WuetVork+'.php'
			bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,491)
	bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'أفلام',ffBG4TaQU8lVF26R+'/category/افلام-movies-filme/foreign-hd-افلام-اجنبى-2',494,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'_REMEMBERRESULTS_')
	bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'مسلسلات',ffBG4TaQU8lVF26R+'/category/مسلسلات/مسلسلات-اجنبى',494,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'_REMEMBERRESULTS_')
	bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('class="navigation-menu"(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
	items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?>(.*?)</a>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	for fCXyTlcmF4WuetVork,title in items:
		if fCXyTlcmF4WuetVork=='/': continue
		if 'http' not in fCXyTlcmF4WuetVork: fCXyTlcmF4WuetVork = ffBG4TaQU8lVF26R+fCXyTlcmF4WuetVork
		if title in a8GCLIuWNkS: continue
		bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,491)
	return Vxz6OndPIX4g2kaRp7
def BaSyudevC40nsQHW5j7JX6RM9(url):
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'CIMACLUP-SUBMENU-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	HG5rE20ORdbqUKWewuZCJP4zoXF6g = dEyT9xhGjolYzLCH7460w3.findall('"filter"(.*?)</div>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if HG5rE20ORdbqUKWewuZCJP4zoXF6g:
		PPH1sQtTkDBbnlYpZfo5 = HG5rE20ORdbqUKWewuZCJP4zoXF6g[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?>(.*?)</a>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title in items:
			if title in a8GCLIuWNkS: continue
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,491)
	return
def AIQeNZP4FMDw9S(url,Ax2k5gsahJCBE30DfntcyXL7P=iiy37aKq0pCEIOwfcTh61xb4U):
	items = []
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'CIMACLUP-TITLES-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	PPH1sQtTkDBbnlYpZfo5 = iiy37aKq0pCEIOwfcTh61xb4U
	if '.php' in url: PPH1sQtTkDBbnlYpZfo5 = Vxz6OndPIX4g2kaRp7
	elif '?s=' in url:
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"blocks(.*?)"manifest"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if UUIohmv597bO83YCLgWS:
			PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
			items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?src="(.*?)".*?alt="(.*?)"',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	else:
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"Blocks(.*?)"manifest"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if UUIohmv597bO83YCLgWS:
			PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
	if not PPH1sQtTkDBbnlYpZfo5: return
	u3Rztpl4VHO9GZ7jCBM65kvS = []
	mxXKsCgL5OoP1evURZ8SdIfpBrwu = ['مشاهدة','فيلم','اغنية','أغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for fCXyTlcmF4WuetVork,C0dvhEbPWYlUtimM3x,title in items:
		title = JIY6A30UOsQboNVqCn(title)
		zN7sZyFnw5JTE8 = dEyT9xhGjolYzLCH7460w3.findall('(.*?) حلقة \d+',title,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if not zN7sZyFnw5JTE8: zN7sZyFnw5JTE8 = dEyT9xhGjolYzLCH7460w3.findall('(.*?) الحلقة \d+',title,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if not zN7sZyFnw5JTE8 or any(aasX2cby4Vo5rTgB in title for aasX2cby4Vo5rTgB in mxXKsCgL5OoP1evURZ8SdIfpBrwu):
			bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,492,C0dvhEbPWYlUtimM3x)
		elif zN7sZyFnw5JTE8 and 'حلقة' in title:
			title = '_MOD_' + zN7sZyFnw5JTE8[0]
			if title not in u3Rztpl4VHO9GZ7jCBM65kvS:
				bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,493,C0dvhEbPWYlUtimM3x)
				u3Rztpl4VHO9GZ7jCBM65kvS.append(title)
		else: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,493,C0dvhEbPWYlUtimM3x)
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"pagination"(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('<li><a href="(.*?)".*?>(.*?)</a>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title in items:
			title = JIY6A30UOsQboNVqCn(title)
			title = title.replace('الصفحة ',iiy37aKq0pCEIOwfcTh61xb4U)
			if title!=iiy37aKq0pCEIOwfcTh61xb4U: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'صفحة '+title,fCXyTlcmF4WuetVork,491)
	return
def YNcMvoVF5swlDBJI7PL(url):
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'CIMACLUP-EPISODES-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	eCGwzSrqBmIv = dEyT9xhGjolYzLCH7460w3.findall('"ButtonsBarCo".*?href="(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if eCGwzSrqBmIv:
		eCGwzSrqBmIv = eCGwzSrqBmIv[0]
		oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',eCGwzSrqBmIv,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'CIMACLUP-EPISODES-2nd')
		Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	C0dvhEbPWYlUtimM3x = dEyT9xhGjolYzLCH7460w3.findall('"img-responsive" src="(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if C0dvhEbPWYlUtimM3x: C0dvhEbPWYlUtimM3x = C0dvhEbPWYlUtimM3x[0]
	else: C0dvhEbPWYlUtimM3x = WwMgozBIC32n9d0tyfp.getInfoLabel('ListItem.Thumb')
	HG5rE20ORdbqUKWewuZCJP4zoXF6g = dEyT9xhGjolYzLCH7460w3.findall('"filter"(.*?)</div>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	eTov6CfDcRZVJEAq5BH = dEyT9xhGjolYzLCH7460w3.findall('"Blocks(.*?)class="pagination"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if HG5rE20ORdbqUKWewuZCJP4zoXF6g and '/series/' not in url:
		PPH1sQtTkDBbnlYpZfo5 = HG5rE20ORdbqUKWewuZCJP4zoXF6g[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?>(.*?)</a>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title in items:
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,493,C0dvhEbPWYlUtimM3x)
	elif eTov6CfDcRZVJEAq5BH:
		PPH1sQtTkDBbnlYpZfo5 = eTov6CfDcRZVJEAq5BH[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?image\:url\((.*?)\).*?"boxtitle">(.*?)</div>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if items:
			for fCXyTlcmF4WuetVork,C0dvhEbPWYlUtimM3x,title in items:
				title = title.strip(iFBmE2MUIpSu34wsd7Rf6z)
				bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,492,C0dvhEbPWYlUtimM3x)
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"pagination"(.*?)</div>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if UUIohmv597bO83YCLgWS:
			PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
			items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?>(.*?)</a>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
			for fCXyTlcmF4WuetVork,title in items:
				title = JIY6A30UOsQboNVqCn(title)
				title = title.replace('الصفحة ',iiy37aKq0pCEIOwfcTh61xb4U)
				if title!=iiy37aKq0pCEIOwfcTh61xb4U: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'صفحة '+title,fCXyTlcmF4WuetVork,491)
	return
def TW6Z0zqaDl(url):
	eCGwzSrqBmIv = url.strip('/')+'/?view=1'
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',eCGwzSrqBmIv,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'CIMACLUP-PLAY-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	duef0gb3Mi1AV5WpN8 = []
	ffBG4TaQU8lVF26R = F82MvyX4ThI6sbnA3efDoVS(url,'url')
	l6lm7giRe1UzEDIvb5 = dEyT9xhGjolYzLCH7460w3.findall("data: 'q=(.*?)&",Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	l6lm7giRe1UzEDIvb5 = l6lm7giRe1UzEDIvb5[0]
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"serversList"(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('data-server="(.*?)">(.*?)</li>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for Gmjz63g4fhkU,title in items:
			title = title.strip(iFBmE2MUIpSu34wsd7Rf6z)
			fCXyTlcmF4WuetVork = ffBG4TaQU8lVF26R+'/wp-content/themes/old/servers/server.php?q='+l6lm7giRe1UzEDIvb5+'&i='+Gmjz63g4fhkU+'?named='+title+'__watch'
			duef0gb3Mi1AV5WpN8.append(fCXyTlcmF4WuetVork)
	fCXyTlcmF4WuetVork = dEyT9xhGjolYzLCH7460w3.findall('"embedServer".*?SRC="(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if fCXyTlcmF4WuetVork:
		title = 'مفضل'
		fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork[0]+'?named=__embed__'+title
		duef0gb3Mi1AV5WpN8.append(fCXyTlcmF4WuetVork)
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"downloadsList"(.*?)</div>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('<td>(.*?)</td>.*?href="(.*?)"',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for title,fCXyTlcmF4WuetVork in items:
			title = title.strip(iFBmE2MUIpSu34wsd7Rf6z)
			if 'anavidz' in fCXyTlcmF4WuetVork: Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb = '__خاص'
			else: Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb = iiy37aKq0pCEIOwfcTh61xb4U
			fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork+'?named='+title+'__download'+Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb
			duef0gb3Mi1AV5WpN8.append(fCXyTlcmF4WuetVork)
	import lqBJGK8hXO
	lqBJGK8hXO.ZDg1HavwueT85mcAOorC4hnS(duef0gb3Mi1AV5WpN8,sQU2GnRoMwLK8CBdfzmNr4jXyO,'video',url)
	return
def mUhJtHB9nw(search,ffBG4TaQU8lVF26R=iiy37aKq0pCEIOwfcTh61xb4U):
	if not ffBG4TaQU8lVF26R: ffBG4TaQU8lVF26R = JaQEtCzDXgos1cdZN
	search,brFQp5vmgJWdZfEkCBOlu9c,showDialogs = XkYnev3ZCA6ahO94(search)
	if not search:
		search = TTBf6S08q1NKXd5v9wa()
		if not search: return
	search = search.replace(iFBmE2MUIpSu34wsd7Rf6z,'+')
	url = ffBG4TaQU8lVF26R+'/index.php?s='+search
	AIQeNZP4FMDw9S(url)
	return
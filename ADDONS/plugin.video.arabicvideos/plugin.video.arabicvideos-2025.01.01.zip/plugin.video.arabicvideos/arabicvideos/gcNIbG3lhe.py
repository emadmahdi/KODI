# -*- coding: utf-8 -*-
from braVAkwfBN import *
sQU2GnRoMwLK8CBdfzmNr4jXyO = 'FASELHD2'
headers = {'User-Agent':iiy37aKq0pCEIOwfcTh61xb4U}
ooQEi5O6tYsGVF8LU0TC3hgMeflBwH = '_FH2_'
JaQEtCzDXgos1cdZN = gZ4LwbKaOm[sQU2GnRoMwLK8CBdfzmNr4jXyO][0]
a8GCLIuWNkS = ['wwe']
def sHVM8YchrDjZAJ7(mode,url,text):
	if   mode==590: EA7FzO1kMZGQXDd2giB0cwLom = jihuS9LVAvTrClPapMbUEwfn8XN()
	elif mode==591: EA7FzO1kMZGQXDd2giB0cwLom = AIQeNZP4FMDw9S(url,text)
	elif mode==592: EA7FzO1kMZGQXDd2giB0cwLom = TW6Z0zqaDl(url)
	elif mode==593: EA7FzO1kMZGQXDd2giB0cwLom = jjQL1mhRn3VpBzNcidEaT4yKt9(url,text)
	elif mode==599: EA7FzO1kMZGQXDd2giB0cwLom = mUhJtHB9nw(text)
	else: EA7FzO1kMZGQXDd2giB0cwLom = False
	return EA7FzO1kMZGQXDd2giB0cwLom
def jihuS9LVAvTrClPapMbUEwfn8XN():
	ffBG4TaQU8lVF26R = JaQEtCzDXgos1cdZN
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',ffBG4TaQU8lVF26R,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'FASELHD2-MENU-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'بحث في الموقع',ffBG4TaQU8lVF26R,599,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'_REMEMBERRESULTS_')
	bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'المميزة',ffBG4TaQU8lVF26R,591,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'featured1')
	items = dEyT9xhGjolYzLCH7460w3.findall('<strong>(.*?)</strong>.*?href="(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	for title,fCXyTlcmF4WuetVork in items:
		bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,591,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'details1')
	bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('main-menu"(.*?)header-social',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		ddArMvJQaj3Z71SOigFTRuK = dEyT9xhGjolYzLCH7460w3.findall('<li (.*?)</li>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for mmV5SgG39tduKpl in ddArMvJQaj3Z71SOigFTRuK:
			items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?>(.*?)<',mmV5SgG39tduKpl,dEyT9xhGjolYzLCH7460w3.DOTALL)
			for fCXyTlcmF4WuetVork,title in items:
				if 'http' not in fCXyTlcmF4WuetVork: fCXyTlcmF4WuetVork = ffBG4TaQU8lVF26R+fCXyTlcmF4WuetVork
				bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,591,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'details2')
	return Vxz6OndPIX4g2kaRp7
def AIQeNZP4FMDw9S(url,type=iiy37aKq0pCEIOwfcTh61xb4U):
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'FASELHD2-TITLES-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	ygKNUbcjTR = 0
	eTov6CfDcRZVJEAq5BH = dEyT9xhGjolYzLCH7460w3.findall('"archive-slider(.*?)<h4>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if eTov6CfDcRZVJEAq5BH: U462wftipjCPA1hLuGsKr8koxnd = eTov6CfDcRZVJEAq5BH[0]
	else: U462wftipjCPA1hLuGsKr8koxnd = iiy37aKq0pCEIOwfcTh61xb4U
	if type=='featured1':
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"slider-carousel"(.*?)</container>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall(' src="(.*?)".*?"slider-title">(.*?)<.*?<a href="(.*?)"',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		dqYh4p9eBu0Riw2TSVA,v1JrBsOo8Qyzk,P3tys0cXWbiIUKk7HQ6n89V = zip(*items)
		items = zip(P3tys0cXWbiIUKk7HQ6n89V,dqYh4p9eBu0Riw2TSVA,v1JrBsOo8Qyzk)
	elif type=='featured2':
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?image:url\((.*?)\).*?<h3.*?>(.*?)</h3>',U462wftipjCPA1hLuGsKr8koxnd,dEyT9xhGjolYzLCH7460w3.DOTALL)
	elif type=='filters':
		UUIohmv597bO83YCLgWS = [Vxz6OndPIX4g2kaRp7.replace('\\/','/').replace('\\"','"')]
	elif type=='details2' and 'href' in U462wftipjCPA1hLuGsKr8koxnd:
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('<h4>(.*?)</h4>(.*?)</container>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'مميزة',url,591,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'featured2')
		title = UUIohmv597bO83YCLgWS[0][0]
		bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,url,591,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'details3')
		return
	else:
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('<h4>(.*?)</h4>(.*?)</container>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		title,PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?image:url\((.*?)\).*?<h3.*?>(.*?)</h3>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	mxXKsCgL5OoP1evURZ8SdIfpBrwu = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية','حلقة']
	u3Rztpl4VHO9GZ7jCBM65kvS = []
	for fCXyTlcmF4WuetVork,C0dvhEbPWYlUtimM3x,title in items:
		if any(aasX2cby4Vo5rTgB in title.lower() for aasX2cby4Vo5rTgB in a8GCLIuWNkS): continue
		title = title.strip(iFBmE2MUIpSu34wsd7Rf6z)
		title = JIY6A30UOsQboNVqCn(title)
		zN7sZyFnw5JTE8 = dEyT9xhGjolYzLCH7460w3.findall('(.*?) (الحلقة|حلقة).\d+',title,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if '/movseries/' in fCXyTlcmF4WuetVork:
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,591,C0dvhEbPWYlUtimM3x)
		elif zN7sZyFnw5JTE8 and type==iiy37aKq0pCEIOwfcTh61xb4U:
			title = '_MOD_'+zN7sZyFnw5JTE8[0][0]
			if title not in u3Rztpl4VHO9GZ7jCBM65kvS:
				bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,593,C0dvhEbPWYlUtimM3x)
				u3Rztpl4VHO9GZ7jCBM65kvS.append(title)
		elif any(aasX2cby4Vo5rTgB in title for aasX2cby4Vo5rTgB in mxXKsCgL5OoP1evURZ8SdIfpBrwu):
			bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,592,C0dvhEbPWYlUtimM3x)
		else: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,593,C0dvhEbPWYlUtimM3x)
	if type=='filters':
		FSU4DQVwsGvuCKae8Ph3q6ZYx = dEyT9xhGjolYzLCH7460w3.findall('"more_button_page":(.*?),',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if FSU4DQVwsGvuCKae8Ph3q6ZYx:
			count = FSU4DQVwsGvuCKae8Ph3q6ZYx[0]
			fCXyTlcmF4WuetVork = url+'/offset/'+count
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'صفحة أخرى',fCXyTlcmF4WuetVork,591,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'filters')
	elif 'details' in type:
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('class="pagination(.*?)</div>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if UUIohmv597bO83YCLgWS:
			PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
			items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)">(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
			for fCXyTlcmF4WuetVork,title in items:
				title = 'صفحة '+JIY6A30UOsQboNVqCn(title)
				bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,591,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'details4')
	return
def jjQL1mhRn3VpBzNcidEaT4yKt9(url,type=iiy37aKq0pCEIOwfcTh61xb4U):
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'FASELHD2-SEASONS_EPISODES-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	zfbAhCqkmOoZWyGpT3KUIF9anBN = False
	if not type:
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('<seasons(.*?)</seasons>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if UUIohmv597bO83YCLgWS:
			PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
			items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?image:url\((.*?)\).*?<h3>(.*?)</h3>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
			if len(items)>1:
				ffBG4TaQU8lVF26R = F82MvyX4ThI6sbnA3efDoVS(url,'url')
				zfbAhCqkmOoZWyGpT3KUIF9anBN = True
				for fCXyTlcmF4WuetVork,C0dvhEbPWYlUtimM3x,title in items:
					title = JIY6A30UOsQboNVqCn(title)
					bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,593,C0dvhEbPWYlUtimM3x,iiy37aKq0pCEIOwfcTh61xb4U,'episodes')
	if type=='episodes' or not zfbAhCqkmOoZWyGpT3KUIF9anBN:
		L95mrowGgdsD = dEyT9xhGjolYzLCH7460w3.findall('<bkز*?image:url\((.*?)\)"></bk>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if L95mrowGgdsD: C0dvhEbPWYlUtimM3x = L95mrowGgdsD[0]
		else: C0dvhEbPWYlUtimM3x = iiy37aKq0pCEIOwfcTh61xb4U
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('<all-episodes(.*?)</all-episodes>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if UUIohmv597bO83YCLgWS:
			PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
			items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?>(.*?)</a>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
			for fCXyTlcmF4WuetVork,title in items:
				title = title.strip(iFBmE2MUIpSu34wsd7Rf6z)
				title = JIY6A30UOsQboNVqCn(title)
				bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,592,C0dvhEbPWYlUtimM3x)
	return
def TW6Z0zqaDl(url):
	ff2PjlcCF5ZWyIUbVguMz,g6gl2Fz4bsh1dkW5CDtBAVJNynR,adfKwimHOzu7n469yXt = [],[],[]
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(r3rnfZ7cdxzNFebIRaLSG6B,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'FASELHD2-PLAY-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	zXyCncmMHTfIGBlwV3i9R = dEyT9xhGjolYzLCH7460w3.findall('العمر :.*?<strong">(.*?)</strong>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if zXyCncmMHTfIGBlwV3i9R and IUF8hYKEGLmHDtXbuWNvnJ(sQU2GnRoMwLK8CBdfzmNr4jXyO,url,zXyCncmMHTfIGBlwV3i9R): return
	fCXyTlcmF4WuetVork = dEyT9xhGjolYzLCH7460w3.findall('<iframe src="(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if fCXyTlcmF4WuetVork:
		fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork[0]
		ff2PjlcCF5ZWyIUbVguMz.append(fCXyTlcmF4WuetVork+'?named=__embed')
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('<slice-title(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('data-url="(.*?)".*?</i>(.*?)</li>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,name in items:
			name = name.strip(iFBmE2MUIpSu34wsd7Rf6z)
			ff2PjlcCF5ZWyIUbVguMz.append(fCXyTlcmF4WuetVork+'?named='+name+'__watch')
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('<downloads(.*?)</downloads>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?</div>(.*?)</div>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,name in items:
			ff2PjlcCF5ZWyIUbVguMz.append(fCXyTlcmF4WuetVork+'?named='+name+'__download')
	for pntgBel9CduE6Gryki3wO in ff2PjlcCF5ZWyIUbVguMz:
		fCXyTlcmF4WuetVork,name = pntgBel9CduE6Gryki3wO.split('?named')
		if fCXyTlcmF4WuetVork not in g6gl2Fz4bsh1dkW5CDtBAVJNynR:
			g6gl2Fz4bsh1dkW5CDtBAVJNynR.append(fCXyTlcmF4WuetVork)
			adfKwimHOzu7n469yXt.append(pntgBel9CduE6Gryki3wO)
	import lqBJGK8hXO
	lqBJGK8hXO.ZDg1HavwueT85mcAOorC4hnS(adfKwimHOzu7n469yXt,sQU2GnRoMwLK8CBdfzmNr4jXyO,'video',url)
	return
def mUhJtHB9nw(search):
	search,brFQp5vmgJWdZfEkCBOlu9c,showDialogs = XkYnev3ZCA6ahO94(search)
	if search==iiy37aKq0pCEIOwfcTh61xb4U: search = TTBf6S08q1NKXd5v9wa()
	if search==iiy37aKq0pCEIOwfcTh61xb4U: return
	search = search.replace(iFBmE2MUIpSu34wsd7Rf6z,'+')
	ffBG4TaQU8lVF26R = JaQEtCzDXgos1cdZN
	url = ffBG4TaQU8lVF26R+'/?s='+search
	AIQeNZP4FMDw9S(url,'details5')
	return
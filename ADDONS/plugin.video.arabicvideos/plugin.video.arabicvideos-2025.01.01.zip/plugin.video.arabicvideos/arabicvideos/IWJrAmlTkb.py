# -*- coding: utf-8 -*-
from braVAkwfBN import *
sQU2GnRoMwLK8CBdfzmNr4jXyO = 'CIMACLUBWORK'
ooQEi5O6tYsGVF8LU0TC3hgMeflBwH = '_CCW_'
JaQEtCzDXgos1cdZN = gZ4LwbKaOm[sQU2GnRoMwLK8CBdfzmNr4jXyO][0]
a8GCLIuWNkS = ['الصفحة الرئيسية','Sign in','تسجيل','عروض مصارعة']
headers = {'Referer':JaQEtCzDXgos1cdZN}
def sHVM8YchrDjZAJ7(mode,url,text):
	if   mode==630: EA7FzO1kMZGQXDd2giB0cwLom = jihuS9LVAvTrClPapMbUEwfn8XN()
	elif mode==631: EA7FzO1kMZGQXDd2giB0cwLom = AIQeNZP4FMDw9S(url,text)
	elif mode==632: EA7FzO1kMZGQXDd2giB0cwLom = TW6Z0zqaDl(url)
	elif mode==633: EA7FzO1kMZGQXDd2giB0cwLom = LEc19rxAg0P4ZXmSaCNid(url,text)
	elif mode==634: EA7FzO1kMZGQXDd2giB0cwLom = BaSyudevC40nsQHW5j7JX6RM9(url)
	elif mode==639: EA7FzO1kMZGQXDd2giB0cwLom = mUhJtHB9nw(text)
	else: EA7FzO1kMZGQXDd2giB0cwLom = False
	return EA7FzO1kMZGQXDd2giB0cwLom
def jihuS9LVAvTrClPapMbUEwfn8XN():
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',JaQEtCzDXgos1cdZN+'/index.php',iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'CIMACLUBWORK-MENU-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'بحث في الموقع',iiy37aKq0pCEIOwfcTh61xb4U,639,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'_REMEMBERRESULTS_')
	bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'المميزة',JaQEtCzDXgos1cdZN+'/index.php',631,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'featured')
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"navslide-wrap"(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
	items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?</i>(.*?)</a>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	for fCXyTlcmF4WuetVork,title in items:
		if title in a8GCLIuWNkS: continue
		if title=='أحدث الحلقات': mode,lHDuLVCy8kvqB6Rxh4Gs5K = 631,'new_episodes'
		else: mode,lHDuLVCy8kvqB6Rxh4Gs5K = 634,iiy37aKq0pCEIOwfcTh61xb4U
		bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,mode,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,lHDuLVCy8kvqB6Rxh4Gs5K)
	bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('/category.php">(.*?)"navslide-divider"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall("'dropdown-menu'(.*?)</ul>",Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	for U462wftipjCPA1hLuGsKr8koxnd in UUIohmv597bO83YCLgWS: PPH1sQtTkDBbnlYpZfo5 = PPH1sQtTkDBbnlYpZfo5.replace(U462wftipjCPA1hLuGsKr8koxnd,iiy37aKq0pCEIOwfcTh61xb4U)
	items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?>(.*?)</a>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	for fCXyTlcmF4WuetVork,title in items:
		if title in a8GCLIuWNkS: continue
		bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,634)
	return
def BaSyudevC40nsQHW5j7JX6RM9(url):
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'CIMACLUBWORK-SUBMENU-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	HG5rE20ORdbqUKWewuZCJP4zoXF6g = dEyT9xhGjolYzLCH7460w3.findall('"caret"(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if HG5rE20ORdbqUKWewuZCJP4zoXF6g:
		PPH1sQtTkDBbnlYpZfo5 = HG5rE20ORdbqUKWewuZCJP4zoXF6g[0]
		PPH1sQtTkDBbnlYpZfo5 = PPH1sQtTkDBbnlYpZfo5.replace('"presentation"','</ul>')
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if not UUIohmv597bO83YCLgWS: UUIohmv597bO83YCLgWS = [(iiy37aKq0pCEIOwfcTh61xb4U,PPH1sQtTkDBbnlYpZfo5)]
		bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' فرز أو فلتر أو ترتيب '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
		for MF3KpchD8xSdtL0VXTAB96w,PPH1sQtTkDBbnlYpZfo5 in UUIohmv597bO83YCLgWS:
			items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?>(.*?)</a>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
			if MF3KpchD8xSdtL0VXTAB96w: MF3KpchD8xSdtL0VXTAB96w = MF3KpchD8xSdtL0VXTAB96w+': '
			for fCXyTlcmF4WuetVork,title in items:
				title = MF3KpchD8xSdtL0VXTAB96w+title
				bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,631)
	eTov6CfDcRZVJEAq5BH = dEyT9xhGjolYzLCH7460w3.findall('"pm-category-subcats"(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if eTov6CfDcRZVJEAq5BH:
		PPH1sQtTkDBbnlYpZfo5 = eTov6CfDcRZVJEAq5BH[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)">(.*?)</a>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if len(items)<30:
			bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
			for fCXyTlcmF4WuetVork,title in items:
				bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,631)
	if not HG5rE20ORdbqUKWewuZCJP4zoXF6g and not eTov6CfDcRZVJEAq5BH: AIQeNZP4FMDw9S(url)
	return
def AIQeNZP4FMDw9S(url,lHDuLVCy8kvqB6Rxh4Gs5K=iiy37aKq0pCEIOwfcTh61xb4U):
	if lHDuLVCy8kvqB6Rxh4Gs5K=='ajax-search':
		url,search = url.split('?',1)
		data = 'queryString='+search
		headers = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'POST',url,data,headers,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'CIMACLUBWORK-TITLES-1st')
	else:
		oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'CIMACLUBWORK-TITLES-2nd')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	PPH1sQtTkDBbnlYpZfo5,items = iiy37aKq0pCEIOwfcTh61xb4U,[]
	ffBG4TaQU8lVF26R = F82MvyX4ThI6sbnA3efDoVS(url,'url')
	if lHDuLVCy8kvqB6Rxh4Gs5K=='ajax-search':
		PPH1sQtTkDBbnlYpZfo5 = Vxz6OndPIX4g2kaRp7
		lFmsiNI2UDoJBdVCQtqx4WPXb7 = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)">(.*?)</a>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title in lFmsiNI2UDoJBdVCQtqx4WPXb7: items.append((fCXyTlcmF4WuetVork,title,iiy37aKq0pCEIOwfcTh61xb4U))
	elif lHDuLVCy8kvqB6Rxh4Gs5K=='featured':
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"pm-carousel_featured"(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if UUIohmv597bO83YCLgWS:
			PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
			items = dEyT9xhGjolYzLCH7460w3.findall('''"postBlock".*?href="(.*?)" title="(.*?)".*?image:url\('(.*?)'\)''',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	elif lHDuLVCy8kvqB6Rxh4Gs5K=='new_episodes':
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"row pm-ul-browse-videos(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if UUIohmv597bO83YCLgWS: PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
	elif lHDuLVCy8kvqB6Rxh4Gs5K=='new_movies':
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"row pm-ul-browse-videos(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if len(UUIohmv597bO83YCLgWS)>1: PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[1]
	elif lHDuLVCy8kvqB6Rxh4Gs5K=='featured_series':
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"home-series-list"(.*?)</div>[\t|\n]*</div>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if UUIohmv597bO83YCLgWS: PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		lFmsiNI2UDoJBdVCQtqx4WPXb7 = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)">(.*?)</a>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title in lFmsiNI2UDoJBdVCQtqx4WPXb7: items.append((fCXyTlcmF4WuetVork,title,iiy37aKq0pCEIOwfcTh61xb4U))
	else:
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"row pm-ul-browse-videos(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if UUIohmv597bO83YCLgWS: PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
	if PPH1sQtTkDBbnlYpZfo5 and not items: items = dEyT9xhGjolYzLCH7460w3.findall('"thumbnail".*?<a href="(.*?)" title="(.*?)".*?src="(.*?)"',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if not items: return
	u3Rztpl4VHO9GZ7jCBM65kvS = []
	mxXKsCgL5OoP1evURZ8SdIfpBrwu = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for fCXyTlcmF4WuetVork,title,C0dvhEbPWYlUtimM3x in items:
		title = title.replace(' سيما كلوب',iiy37aKq0pCEIOwfcTh61xb4U)
		title = title.replace(' اون لاين',iiy37aKq0pCEIOwfcTh61xb4U)
		zN7sZyFnw5JTE8 = dEyT9xhGjolYzLCH7460w3.findall('(.*?) (الحلقة|حلقة).\d+',title,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if 'WWE' in title: continue
		elif any(aasX2cby4Vo5rTgB in title for aasX2cby4Vo5rTgB in mxXKsCgL5OoP1evURZ8SdIfpBrwu):
			bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,632,C0dvhEbPWYlUtimM3x)
		elif lHDuLVCy8kvqB6Rxh4Gs5K=='new_episodes':
			bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,632,C0dvhEbPWYlUtimM3x)
		elif zN7sZyFnw5JTE8:
			title = '_MOD_' + zN7sZyFnw5JTE8[0][0]
			if title not in u3Rztpl4VHO9GZ7jCBM65kvS:
				bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,633,C0dvhEbPWYlUtimM3x)
				u3Rztpl4VHO9GZ7jCBM65kvS.append(title)
		else: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,633,C0dvhEbPWYlUtimM3x)
	if 1:
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"pagination(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if UUIohmv597bO83YCLgWS:
			PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
			items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?>(.*?)</a>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
			for fCXyTlcmF4WuetVork,title in items:
				if fCXyTlcmF4WuetVork=='#': continue
				fCXyTlcmF4WuetVork = ffBG4TaQU8lVF26R+'/'+fCXyTlcmF4WuetVork.strip('/')
				title = JIY6A30UOsQboNVqCn(title)
				bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'صفحة '+title,fCXyTlcmF4WuetVork,631)
	return
def LEc19rxAg0P4ZXmSaCNid(url,kbTg05YG6clitmjwoDx3VZQuq):
	ffBG4TaQU8lVF26R = F82MvyX4ThI6sbnA3efDoVS(url,'url')
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'CIMACLUBWORK-EPISODES-2nd')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	L95mrowGgdsD = dEyT9xhGjolYzLCH7460w3.findall('"series-header".*?src="(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if L95mrowGgdsD: C0dvhEbPWYlUtimM3x = L95mrowGgdsD[0]
	else: C0dvhEbPWYlUtimM3x = iiy37aKq0pCEIOwfcTh61xb4U
	items = []
	MSkCvHyJmlVYuZQGzpDNr6o1 = False
	HG5rE20ORdbqUKWewuZCJP4zoXF6g = dEyT9xhGjolYzLCH7460w3.findall('"SeasonsBox"(.*?)"SeasonsEpisodesMain',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if HG5rE20ORdbqUKWewuZCJP4zoXF6g and not kbTg05YG6clitmjwoDx3VZQuq:
		PPH1sQtTkDBbnlYpZfo5 = HG5rE20ORdbqUKWewuZCJP4zoXF6g[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('''onclick="openCity\(event,.'(.*?)'\)">(.*?)</button>''',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for kbTg05YG6clitmjwoDx3VZQuq,title in items:
			kbTg05YG6clitmjwoDx3VZQuq = kbTg05YG6clitmjwoDx3VZQuq.strip('#')
			if len(items)>1: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,url,633,C0dvhEbPWYlUtimM3x,iiy37aKq0pCEIOwfcTh61xb4U,kbTg05YG6clitmjwoDx3VZQuq)
			else: MSkCvHyJmlVYuZQGzpDNr6o1 = True
	else: MSkCvHyJmlVYuZQGzpDNr6o1 = True
	eTov6CfDcRZVJEAq5BH = dEyT9xhGjolYzLCH7460w3.findall('id="'+kbTg05YG6clitmjwoDx3VZQuq+'"(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if eTov6CfDcRZVJEAq5BH and MSkCvHyJmlVYuZQGzpDNr6o1:
		PPH1sQtTkDBbnlYpZfo5 = eTov6CfDcRZVJEAq5BH[0]
		lFmsiNI2UDoJBdVCQtqx4WPXb7 = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?>(.*?)</a>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		items = []
		for fCXyTlcmF4WuetVork,title in lFmsiNI2UDoJBdVCQtqx4WPXb7: items.append((fCXyTlcmF4WuetVork,title,C0dvhEbPWYlUtimM3x))
		if not items: items = dEyT9xhGjolYzLCH7460w3.findall('"thumbnail".*?href="(.*?)" title="(.*?)".*?src="(.*?)"',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title,C0dvhEbPWYlUtimM3x in items:
			fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork.strip('/')
			title = title.replace('</em><span>',iFBmE2MUIpSu34wsd7Rf6z).strip(iFBmE2MUIpSu34wsd7Rf6z)
			bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,632,C0dvhEbPWYlUtimM3x)
	return
def TW6Z0zqaDl(url):
	duef0gb3Mi1AV5WpN8,R62ZFAHJCl0YeQWEvMhprDi7mPVg3,ff2PjlcCF5ZWyIUbVguMz = [],[],[]
	eCGwzSrqBmIv = url.replace('/watch.php','/play.php')
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',eCGwzSrqBmIv,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'CIMACLUBWORK-PLAY-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('id="player"(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		P3tys0cXWbiIUKk7HQ6n89V = dEyT9xhGjolYzLCH7460w3.findall("src='(.*?)'.*?<strong>(.*?)</strong>",PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title in P3tys0cXWbiIUKk7HQ6n89V:
			if fCXyTlcmF4WuetVork not in duef0gb3Mi1AV5WpN8:
				R62ZFAHJCl0YeQWEvMhprDi7mPVg3.append('?named='+title+'__watch')
				duef0gb3Mi1AV5WpN8.append(fCXyTlcmF4WuetVork)
	eCGwzSrqBmIv = url.replace('/watch.php','/downloads.php')
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',eCGwzSrqBmIv,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'CIMACLUBWORK-PLAY-2nd')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('id="pm-download"(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		P3tys0cXWbiIUKk7HQ6n89V = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?<strong>(.*?)</strong>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title in P3tys0cXWbiIUKk7HQ6n89V:
			if fCXyTlcmF4WuetVork not in duef0gb3Mi1AV5WpN8:
				R62ZFAHJCl0YeQWEvMhprDi7mPVg3.append('?named='+title+'__download')
				duef0gb3Mi1AV5WpN8.append(fCXyTlcmF4WuetVork)
	c1CH6qPe8oZX3irhEgAzuxm5 = zip(duef0gb3Mi1AV5WpN8,R62ZFAHJCl0YeQWEvMhprDi7mPVg3)
	for fCXyTlcmF4WuetVork,name in c1CH6qPe8oZX3irhEgAzuxm5: ff2PjlcCF5ZWyIUbVguMz.append(fCXyTlcmF4WuetVork+name)
	import lqBJGK8hXO
	lqBJGK8hXO.ZDg1HavwueT85mcAOorC4hnS(ff2PjlcCF5ZWyIUbVguMz,sQU2GnRoMwLK8CBdfzmNr4jXyO,'video',url)
	return
def mUhJtHB9nw(search):
	search,brFQp5vmgJWdZfEkCBOlu9c,showDialogs = XkYnev3ZCA6ahO94(search)
	if search==iiy37aKq0pCEIOwfcTh61xb4U: search = TTBf6S08q1NKXd5v9wa()
	if search==iiy37aKq0pCEIOwfcTh61xb4U: return
	search = search.replace(iFBmE2MUIpSu34wsd7Rf6z,'+')
	url = JaQEtCzDXgos1cdZN+'/search.php?keywords='+search
	AIQeNZP4FMDw9S(url,'search')
	return
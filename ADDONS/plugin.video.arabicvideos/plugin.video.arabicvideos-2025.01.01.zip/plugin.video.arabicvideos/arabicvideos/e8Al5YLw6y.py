# -*- coding: utf-8 -*-
from braVAkwfBN import *
sQU2GnRoMwLK8CBdfzmNr4jXyO = 'IFILM'
ooQEi5O6tYsGVF8LU0TC3hgMeflBwH = '_IFL_'
JaQEtCzDXgos1cdZN = gZ4LwbKaOm[sQU2GnRoMwLK8CBdfzmNr4jXyO][0]
QSaKzorWqRMY8JkTtNdG1exb = gZ4LwbKaOm[sQU2GnRoMwLK8CBdfzmNr4jXyO][1]
H6RzwPS2yjtZavnqQYbC9 = gZ4LwbKaOm[sQU2GnRoMwLK8CBdfzmNr4jXyO][2]
HdsUA2jGVWbo87RTICg0 = gZ4LwbKaOm[sQU2GnRoMwLK8CBdfzmNr4jXyO][3]
def sHVM8YchrDjZAJ7(mode,url,zLEP9N4BOsVrXa,text):
	if   mode==20: EA7FzO1kMZGQXDd2giB0cwLom = N26AuCOJv0kdSlG9rMUjK4h5tgQXx()
	elif mode==21: EA7FzO1kMZGQXDd2giB0cwLom = jihuS9LVAvTrClPapMbUEwfn8XN(url)
	elif mode==22: EA7FzO1kMZGQXDd2giB0cwLom = AIQeNZP4FMDw9S(url,zLEP9N4BOsVrXa)
	elif mode==23: EA7FzO1kMZGQXDd2giB0cwLom = YNcMvoVF5swlDBJI7PL(url,zLEP9N4BOsVrXa)
	elif mode==24: EA7FzO1kMZGQXDd2giB0cwLom = TW6Z0zqaDl(url,text)
	elif mode==25: EA7FzO1kMZGQXDd2giB0cwLom = tKbskSTu1Z4N2YCXMpn9(url)
	elif mode==27: EA7FzO1kMZGQXDd2giB0cwLom = FaD6NxfSIbzZimr9d4wOjQMkYhn5(url)
	elif mode==28: EA7FzO1kMZGQXDd2giB0cwLom = V4HcIe63TrFDEPv()
	elif mode==29: EA7FzO1kMZGQXDd2giB0cwLom = mUhJtHB9nw(text)
	else: EA7FzO1kMZGQXDd2giB0cwLom = False
	return EA7FzO1kMZGQXDd2giB0cwLom
def N26AuCOJv0kdSlG9rMUjK4h5tgQXx():
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'عربي',JaQEtCzDXgos1cdZN,21,iiy37aKq0pCEIOwfcTh61xb4U,'101')
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'English',QSaKzorWqRMY8JkTtNdG1exb,21,iiy37aKq0pCEIOwfcTh61xb4U,'101')
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'فارسى',H6RzwPS2yjtZavnqQYbC9,21,iiy37aKq0pCEIOwfcTh61xb4U,'101')
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'فارسى 2',HdsUA2jGVWbo87RTICg0,21,iiy37aKq0pCEIOwfcTh61xb4U,'101')
	return
def V4HcIe63TrFDEPv():
	bP6z3OSLp7va('live',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'عربي',JaQEtCzDXgos1cdZN,27)
	bP6z3OSLp7va('live',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'English',QSaKzorWqRMY8JkTtNdG1exb,27)
	bP6z3OSLp7va('live',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'فارسى',H6RzwPS2yjtZavnqQYbC9,27)
	bP6z3OSLp7va('live',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'فارسى 2',HdsUA2jGVWbo87RTICg0,27)
	return
def jihuS9LVAvTrClPapMbUEwfn8XN(NNTsOeQWh7kJrBKqGbYSXyFz0RI):
	sQU2GnRoMwLK8CBdfzmNr4jXyO = NNTsOeQWh7kJrBKqGbYSXyFz0RI
	if NNTsOeQWh7kJrBKqGbYSXyFz0RI=='IFILM-ARABIC': NNTsOeQWh7kJrBKqGbYSXyFz0RI = JaQEtCzDXgos1cdZN
	elif NNTsOeQWh7kJrBKqGbYSXyFz0RI=='IFILM-ENGLISH': NNTsOeQWh7kJrBKqGbYSXyFz0RI = QSaKzorWqRMY8JkTtNdG1exb
	else: sQU2GnRoMwLK8CBdfzmNr4jXyO = iiy37aKq0pCEIOwfcTh61xb4U
	aN8jtOe3hcFP6fwRYnbg = yC1lTFBOjLzHma7JWiv2wESRfAp6Qe(NNTsOeQWh7kJrBKqGbYSXyFz0RI)
	if aN8jtOe3hcFP6fwRYnbg=='ar' or sQU2GnRoMwLK8CBdfzmNr4jXyO=='IFILM-ARABIC':
		z9qNQGLovgOKkDaZjxFpyTIf3 = 'بحث في الموقع'
		IrXjyqcp13l = 'مسلسلات - حالية'
		ccgt6lhpXynUR79P5ev = 'مسلسلات - أحدث'
		s7efbn0qHXB2 = 'مسلسلات - أبجدي'
		S8Z2QYh1lrHpoR = 'بث حي آي فيلم'
		ee7HxIQwiKRs4 = 'أفلام'
		ubeyDsHYKnAvUkC70orIS1j = 'موسيقى'
		w8WCZlEp57FBDQAd34Ny = 'برامج'
	elif aN8jtOe3hcFP6fwRYnbg=='en' or sQU2GnRoMwLK8CBdfzmNr4jXyO=='IFILM-ENGLISH':
		z9qNQGLovgOKkDaZjxFpyTIf3 = 'Search in site'
		IrXjyqcp13l = 'Series - Current'
		ccgt6lhpXynUR79P5ev = 'Series - Latest'
		s7efbn0qHXB2 = 'Series - Alphabet'
		S8Z2QYh1lrHpoR = 'Live iFilm channel'
		ee7HxIQwiKRs4 = 'Movies'
		ubeyDsHYKnAvUkC70orIS1j = 'Music'
		w8WCZlEp57FBDQAd34Ny = 'Shows'
	elif aN8jtOe3hcFP6fwRYnbg in ['fa','fa2']:
		z9qNQGLovgOKkDaZjxFpyTIf3 = 'جستجو در سایت'
		IrXjyqcp13l = 'سريال - جاری'
		ccgt6lhpXynUR79P5ev = 'سريال - آخرین'
		s7efbn0qHXB2 = 'سريال - الفبا'
		S8Z2QYh1lrHpoR = 'پخش زنده اي فيلم'
		ee7HxIQwiKRs4 = 'فيلم'
		ubeyDsHYKnAvUkC70orIS1j = 'موسيقى'
		w8WCZlEp57FBDQAd34Ny = 'برنامه ها'
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+z9qNQGLovgOKkDaZjxFpyTIf3,NNTsOeQWh7kJrBKqGbYSXyFz0RI,29,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'_REMEMBERRESULTS_')
	bP6z3OSLp7va('live',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+S8Z2QYh1lrHpoR,NNTsOeQWh7kJrBKqGbYSXyFz0RI,27)
	bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	mmV5SgG39tduKpl = ['Series','Program','Music']
	Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(Dxc7GChQwZ4kOlKHSbL06agnB,NNTsOeQWh7kJrBKqGbYSXyFz0RI+'/home',iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'IFILM-MENU-1st')
	UUIohmv597bO83YCLgWS=dEyT9xhGjolYzLCH7460w3.findall('button-menu(.*?)/Contact',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)">(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title in items:
			if any(aasX2cby4Vo5rTgB in fCXyTlcmF4WuetVork for aasX2cby4Vo5rTgB in mmV5SgG39tduKpl):
				url = NNTsOeQWh7kJrBKqGbYSXyFz0RI+fCXyTlcmF4WuetVork
				if 'Series' in fCXyTlcmF4WuetVork:
					bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+IrXjyqcp13l,url,22,iiy37aKq0pCEIOwfcTh61xb4U,'100')
					bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+ccgt6lhpXynUR79P5ev,url,22,iiy37aKq0pCEIOwfcTh61xb4U,'101')
					bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+s7efbn0qHXB2,url,22,iiy37aKq0pCEIOwfcTh61xb4U,'201')
				elif 'Film' in fCXyTlcmF4WuetVork: bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+ee7HxIQwiKRs4,url,22,iiy37aKq0pCEIOwfcTh61xb4U,'100')
				elif 'Music' in fCXyTlcmF4WuetVork: bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+ubeyDsHYKnAvUkC70orIS1j,url,25,iiy37aKq0pCEIOwfcTh61xb4U,'101')
				elif 'Program' in fCXyTlcmF4WuetVork: bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+w8WCZlEp57FBDQAd34Ny,url,22,iiy37aKq0pCEIOwfcTh61xb4U,'101')
	return Vxz6OndPIX4g2kaRp7
def tKbskSTu1Z4N2YCXMpn9(url):
	NNTsOeQWh7kJrBKqGbYSXyFz0RI = kiCsMQD3ucU8PVEIrBf5OxztdjFnh(url)
	Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(Dxc7GChQwZ4kOlKHSbL06agnB,url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'IFILM-MUSIC_MENU-1st')
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('Music-tools-header(.*?)Music-body',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
	title = dEyT9xhGjolYzLCH7460w3.findall('<p>(.*?)</p>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)[0]
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,url,22,iiy37aKq0pCEIOwfcTh61xb4U,'101')
	items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)">(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	for fCXyTlcmF4WuetVork,title in items:
		fCXyTlcmF4WuetVork = NNTsOeQWh7kJrBKqGbYSXyFz0RI + fCXyTlcmF4WuetVork
		bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,23,iiy37aKq0pCEIOwfcTh61xb4U,'101')
	return
def AIQeNZP4FMDw9S(url,zLEP9N4BOsVrXa):
	NNTsOeQWh7kJrBKqGbYSXyFz0RI = kiCsMQD3ucU8PVEIrBf5OxztdjFnh(url)
	aN8jtOe3hcFP6fwRYnbg = yC1lTFBOjLzHma7JWiv2wESRfAp6Qe(url)
	type = url.split('/')[-1]
	OOMnkNfup298Ys46elFdQaPA7G = str(int(zLEP9N4BOsVrXa)//100)
	zLEP9N4BOsVrXa = str(int(zLEP9N4BOsVrXa)%100)
	if type=='Series' and zLEP9N4BOsVrXa=='0':
		Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(PNjZMS7nxa9clHusz1,url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'IFILM-TITLES-1st')
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('serial-body(.*?)class="row',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?src=(.*?)>.*?h3>(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,C0dvhEbPWYlUtimM3x,title in items:
			title = vvmT3DLXkhPBwIaOAo6srZpEnRVJC(title)
			title = JIY6A30UOsQboNVqCn(title)
			fCXyTlcmF4WuetVork = NNTsOeQWh7kJrBKqGbYSXyFz0RI + fCXyTlcmF4WuetVork
			C0dvhEbPWYlUtimM3x = NNTsOeQWh7kJrBKqGbYSXyFz0RI + YqdaDIig21wBTWJeUHbc(C0dvhEbPWYlUtimM3x)
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,23,C0dvhEbPWYlUtimM3x,OOMnkNfup298Ys46elFdQaPA7G+'01')
	pWvsR8C2N61E9QtKOc5bZ3DIXm=0
	if type=='Series': RRIscyLmNH9dq2Dio3TSr='3'
	if type=='Film': RRIscyLmNH9dq2Dio3TSr='5'
	if type=='Program': RRIscyLmNH9dq2Dio3TSr='7'
	if type in ['Series','Program','Film'] and zLEP9N4BOsVrXa!='0':
		eCGwzSrqBmIv = NNTsOeQWh7kJrBKqGbYSXyFz0RI+'/Home/PageingItem?category='+RRIscyLmNH9dq2Dio3TSr+'&page='+zLEP9N4BOsVrXa+'&size=30&orderby='+OOMnkNfup298Ys46elFdQaPA7G
		Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(PNjZMS7nxa9clHusz1,eCGwzSrqBmIv,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'IFILM-TITLES-2nd')
		items = dEyT9xhGjolYzLCH7460w3.findall('"Id":(.*?),"Title":(.*?),.+?"ImageAddress_S":"(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for id,title,C0dvhEbPWYlUtimM3x in items:
			title = vvmT3DLXkhPBwIaOAo6srZpEnRVJC(title)
			title = title.replace('\\',iiy37aKq0pCEIOwfcTh61xb4U)
			title = title.replace('"',iiy37aKq0pCEIOwfcTh61xb4U)
			pWvsR8C2N61E9QtKOc5bZ3DIXm += 1
			fCXyTlcmF4WuetVork = NNTsOeQWh7kJrBKqGbYSXyFz0RI + '/' + type + '/Content/' + id
			C0dvhEbPWYlUtimM3x = NNTsOeQWh7kJrBKqGbYSXyFz0RI + YqdaDIig21wBTWJeUHbc(C0dvhEbPWYlUtimM3x)
			if type=='Film': bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,24,C0dvhEbPWYlUtimM3x,OOMnkNfup298Ys46elFdQaPA7G+'01')
			else: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,23,C0dvhEbPWYlUtimM3x,OOMnkNfup298Ys46elFdQaPA7G+'01')
	if type=='Music':
		Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(PNjZMS7nxa9clHusz1,NNTsOeQWh7kJrBKqGbYSXyFz0RI+'/Music/Index?page='+zLEP9N4BOsVrXa,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'IFILM-TITLES-3rd')
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('pagination-demo(.*?)pagination-demo',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?src="(.*?)".*?<h3>(.*?)</h3>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,C0dvhEbPWYlUtimM3x,title in items:
			pWvsR8C2N61E9QtKOc5bZ3DIXm += 1
			C0dvhEbPWYlUtimM3x = NNTsOeQWh7kJrBKqGbYSXyFz0RI + C0dvhEbPWYlUtimM3x
			fCXyTlcmF4WuetVork = NNTsOeQWh7kJrBKqGbYSXyFz0RI + fCXyTlcmF4WuetVork
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,23,C0dvhEbPWYlUtimM3x,'101')
	if pWvsR8C2N61E9QtKOc5bZ3DIXm>20:
		title='صفحة '
		if aN8jtOe3hcFP6fwRYnbg=='en': title = 'Page '
		if aN8jtOe3hcFP6fwRYnbg=='fa': title = 'صفحه '
		if aN8jtOe3hcFP6fwRYnbg=='fa2': title = 'صفحه '
		for Mx2ndrD8PNq1KA in range(1,11) :
			if not zLEP9N4BOsVrXa==str(Mx2ndrD8PNq1KA):
				EIP63h2p79Z8KacsVr = '0'+str(Mx2ndrD8PNq1KA)
				bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title+str(Mx2ndrD8PNq1KA),url,22,iiy37aKq0pCEIOwfcTh61xb4U,OOMnkNfup298Ys46elFdQaPA7G+EIP63h2p79Z8KacsVr[-2:])
	return
def YNcMvoVF5swlDBJI7PL(url,zLEP9N4BOsVrXa):
	if not zLEP9N4BOsVrXa: zLEP9N4BOsVrXa = 0
	NNTsOeQWh7kJrBKqGbYSXyFz0RI = kiCsMQD3ucU8PVEIrBf5OxztdjFnh(url)
	KKxw6aJkTAFdDOeh3r = kiCsMQD3ucU8PVEIrBf5OxztdjFnh(url)
	aN8jtOe3hcFP6fwRYnbg = yC1lTFBOjLzHma7JWiv2wESRfAp6Qe(url)
	ng8RFTvpBOxuMa2ySjYWqVZX = url.split('/')
	id,type = ng8RFTvpBOxuMa2ySjYWqVZX[-1],ng8RFTvpBOxuMa2ySjYWqVZX[3]
	OOMnkNfup298Ys46elFdQaPA7G = str(int(zLEP9N4BOsVrXa)//100)
	zLEP9N4BOsVrXa = str(int(zLEP9N4BOsVrXa)%100)
	pWvsR8C2N61E9QtKOc5bZ3DIXm = 0
	if type=='Series':
		Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(PNjZMS7nxa9clHusz1,url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'IFILM-EPISODES-1st')
		items = dEyT9xhGjolYzLCH7460w3.findall('Comment_panel_Item.*?p>(.*?)<i.+?var inter_ = (.*?);.*?src="(.*?)\'.*?data-url="(.*?)\'',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		title = ' - الحلقة '
		if aN8jtOe3hcFP6fwRYnbg=='en': title = ' - Episode '
		if aN8jtOe3hcFP6fwRYnbg=='fa': title = ' - قسمت '
		if aN8jtOe3hcFP6fwRYnbg=='fa2': title = ' - قسمت '
		if aN8jtOe3hcFP6fwRYnbg=='fa': O1UscIWyzJ6gQE0CTxZR8 = iiy37aKq0pCEIOwfcTh61xb4U
		else: O1UscIWyzJ6gQE0CTxZR8 = aN8jtOe3hcFP6fwRYnbg
		QOZNRi90LX1nWes = dEyT9xhGjolYzLCH7460w3.findall('data-video="(.*?)(\'.*?\'_)(.*?)">',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for name,count,C0dvhEbPWYlUtimM3x,fCXyTlcmF4WuetVork in items:
			for zN7sZyFnw5JTE8 in range(int(count),0,-1):
				fSbszgRrGpJ61En7CPNXIoVm = C0dvhEbPWYlUtimM3x + O1UscIWyzJ6gQE0CTxZR8 + id + '/' + str(zN7sZyFnw5JTE8) + '.png'
				IrXjyqcp13l = name + title + str(zN7sZyFnw5JTE8)
				IrXjyqcp13l = JIY6A30UOsQboNVqCn(IrXjyqcp13l)
				bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+IrXjyqcp13l,url,24,fSbszgRrGpJ61En7CPNXIoVm,iiy37aKq0pCEIOwfcTh61xb4U,str(zN7sZyFnw5JTE8))
	elif type=='Program':
		eCGwzSrqBmIv = NNTsOeQWh7kJrBKqGbYSXyFz0RI+'/Home/PageingAttachmentItem?id='+str(id)+'&page='+zLEP9N4BOsVrXa+'&size=30&orderby=1'
		Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(PNjZMS7nxa9clHusz1,eCGwzSrqBmIv,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'IFILM-EPISODES-2nd')
		items = dEyT9xhGjolYzLCH7460w3.findall('Episode":(.*?),.*?ImageAddress_S":"(.*?)".*?VideoAddress":"(.*?)".*?Discription":"(.*?)".*?Caption":"(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		title = ' - الحلقة '
		if aN8jtOe3hcFP6fwRYnbg=='en': title = ' - Episode '
		if aN8jtOe3hcFP6fwRYnbg=='fa': title = ' - قسمت '
		if aN8jtOe3hcFP6fwRYnbg=='fa2': title = ' - قسمت '
		for zN7sZyFnw5JTE8,C0dvhEbPWYlUtimM3x,fCXyTlcmF4WuetVork,mb10NVJTa6HcEYx4AkRLPwosMSgB2W,name in items:
			pWvsR8C2N61E9QtKOc5bZ3DIXm += 1
			fSbszgRrGpJ61En7CPNXIoVm = KKxw6aJkTAFdDOeh3r + YqdaDIig21wBTWJeUHbc(C0dvhEbPWYlUtimM3x)
			name = vvmT3DLXkhPBwIaOAo6srZpEnRVJC(name)
			IrXjyqcp13l = name + title + str(zN7sZyFnw5JTE8)
			bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+IrXjyqcp13l,eCGwzSrqBmIv,24,fSbszgRrGpJ61En7CPNXIoVm,iiy37aKq0pCEIOwfcTh61xb4U,str(pWvsR8C2N61E9QtKOc5bZ3DIXm))
	elif type=='Music':
		if 'Content' in url and 'category' not in url:
			eCGwzSrqBmIv = NNTsOeQWh7kJrBKqGbYSXyFz0RI+'/Music/GetTracksBy?id='+str(id)+'&page='+zLEP9N4BOsVrXa+'&size=30&type=0'
			Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(PNjZMS7nxa9clHusz1,eCGwzSrqBmIv,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'IFILM-EPISODES-3rd')
			items = dEyT9xhGjolYzLCH7460w3.findall('ImageAddress_S":"(.*?)".*?VoiceAddress":"(.*?)".*?Caption":"(.*?)","Title":"(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
			for C0dvhEbPWYlUtimM3x,fCXyTlcmF4WuetVork,name,title in items:
				pWvsR8C2N61E9QtKOc5bZ3DIXm += 1
				fSbszgRrGpJ61En7CPNXIoVm = KKxw6aJkTAFdDOeh3r + YqdaDIig21wBTWJeUHbc(C0dvhEbPWYlUtimM3x)
				IrXjyqcp13l = name + ' - ' + title
				IrXjyqcp13l = IrXjyqcp13l.strip(iFBmE2MUIpSu34wsd7Rf6z)
				IrXjyqcp13l = vvmT3DLXkhPBwIaOAo6srZpEnRVJC(IrXjyqcp13l)
				bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+IrXjyqcp13l,eCGwzSrqBmIv,24,fSbszgRrGpJ61En7CPNXIoVm,iiy37aKq0pCEIOwfcTh61xb4U,str(pWvsR8C2N61E9QtKOc5bZ3DIXm))
		elif 'Clips' in url:
			eCGwzSrqBmIv = NNTsOeQWh7kJrBKqGbYSXyFz0RI+'/Music/GetTracksBy?id=0&page='+zLEP9N4BOsVrXa+'&size=30&type=15'
			Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(PNjZMS7nxa9clHusz1,eCGwzSrqBmIv,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'IFILM-EPISODES-4th')
			items = dEyT9xhGjolYzLCH7460w3.findall('ImageAddress_S":"(.*?)".*?Caption":"(.*?)".*?VideoAddress":"(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
			for C0dvhEbPWYlUtimM3x,title,fCXyTlcmF4WuetVork in items:
				pWvsR8C2N61E9QtKOc5bZ3DIXm += 1
				fSbszgRrGpJ61En7CPNXIoVm = KKxw6aJkTAFdDOeh3r + YqdaDIig21wBTWJeUHbc(C0dvhEbPWYlUtimM3x)
				IrXjyqcp13l = title.strip(iFBmE2MUIpSu34wsd7Rf6z)
				IrXjyqcp13l = vvmT3DLXkhPBwIaOAo6srZpEnRVJC(IrXjyqcp13l)
				bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+IrXjyqcp13l,eCGwzSrqBmIv,24,fSbszgRrGpJ61En7CPNXIoVm,iiy37aKq0pCEIOwfcTh61xb4U,str(pWvsR8C2N61E9QtKOc5bZ3DIXm))
		elif 'category' in url:
			if 'category=6' in url:
				eCGwzSrqBmIv = NNTsOeQWh7kJrBKqGbYSXyFz0RI+'/Music/GetTracksBy?id=0&page='+zLEP9N4BOsVrXa+'&size=30&type=6'
				Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(PNjZMS7nxa9clHusz1,eCGwzSrqBmIv,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'IFILM-EPISODES-5th')
			elif 'category=4' in url:
				eCGwzSrqBmIv = NNTsOeQWh7kJrBKqGbYSXyFz0RI+'/Music/GetTracksBy?id=0&page='+zLEP9N4BOsVrXa+'&size=30&type=4'
				Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(PNjZMS7nxa9clHusz1,eCGwzSrqBmIv,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'IFILM-EPISODES-6th')
			items = dEyT9xhGjolYzLCH7460w3.findall('ImageAddress_S":"(.*?)".*?VoiceAddress":"(.*?)".*?Caption":"(.*?)","Title":"(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
			for C0dvhEbPWYlUtimM3x,fCXyTlcmF4WuetVork,name,title in items:
				pWvsR8C2N61E9QtKOc5bZ3DIXm += 1
				fSbszgRrGpJ61En7CPNXIoVm = KKxw6aJkTAFdDOeh3r + YqdaDIig21wBTWJeUHbc(C0dvhEbPWYlUtimM3x)
				IrXjyqcp13l = name + ' - ' + title
				IrXjyqcp13l = IrXjyqcp13l.strip(iFBmE2MUIpSu34wsd7Rf6z)
				IrXjyqcp13l = vvmT3DLXkhPBwIaOAo6srZpEnRVJC(IrXjyqcp13l)
				bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+IrXjyqcp13l,eCGwzSrqBmIv,24,fSbszgRrGpJ61En7CPNXIoVm,iiy37aKq0pCEIOwfcTh61xb4U,str(pWvsR8C2N61E9QtKOc5bZ3DIXm))
	if type=='Music' or type=='Program':
		if pWvsR8C2N61E9QtKOc5bZ3DIXm>25:
			title='صفحة '
			if aN8jtOe3hcFP6fwRYnbg=='en': title = ' Page '
			if aN8jtOe3hcFP6fwRYnbg=='fa': title = ' صفحه '
			if aN8jtOe3hcFP6fwRYnbg=='fa2': title = ' صفحه '
			for Mx2ndrD8PNq1KA in range(1,11):
				if not zLEP9N4BOsVrXa==str(Mx2ndrD8PNq1KA):
					EIP63h2p79Z8KacsVr = '0'+str(Mx2ndrD8PNq1KA)
					bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title+str(Mx2ndrD8PNq1KA),url,23,iiy37aKq0pCEIOwfcTh61xb4U,OOMnkNfup298Ys46elFdQaPA7G+EIP63h2p79Z8KacsVr[-2:])
	return
def TW6Z0zqaDl(url,zN7sZyFnw5JTE8):
	KKxw6aJkTAFdDOeh3r = kiCsMQD3ucU8PVEIrBf5OxztdjFnh(url)
	A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = [],[]
	Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(PNjZMS7nxa9clHusz1,url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'IFILM-PLAY-1st')
	items = dEyT9xhGjolYzLCH7460w3.findall('data-video="(.*?)(\'.*?\'_)(.*?)">',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if items:
		aN8jtOe3hcFP6fwRYnbg = yC1lTFBOjLzHma7JWiv2wESRfAp6Qe(url)
		ng8RFTvpBOxuMa2ySjYWqVZX = url.split('/')
		id,type = ng8RFTvpBOxuMa2ySjYWqVZX[-1],ng8RFTvpBOxuMa2ySjYWqVZX[3]
		fCXyTlcmF4WuetVork = items[0][0]+aN8jtOe3hcFP6fwRYnbg+id+'/,'+zN7sZyFnw5JTE8+','+zN7sZyFnw5JTE8+'_'+items[0][2]
		A7Ap2wdlxM.append('m3u8')
		duef0gb3Mi1AV5WpN8.append(fCXyTlcmF4WuetVork)
	items = dEyT9xhGjolYzLCH7460w3.findall('data-url="(http.*?)(\'.*?\')(\..*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if items:
		aN8jtOe3hcFP6fwRYnbg = yC1lTFBOjLzHma7JWiv2wESRfAp6Qe(url)
		ng8RFTvpBOxuMa2ySjYWqVZX = url.split('/')
		id,type = ng8RFTvpBOxuMa2ySjYWqVZX[-1],ng8RFTvpBOxuMa2ySjYWqVZX[3]
		fCXyTlcmF4WuetVork = items[0][0]+aN8jtOe3hcFP6fwRYnbg+id+'/'+zN7sZyFnw5JTE8+items[0][2]
		A7Ap2wdlxM.append('mp4 url')
		duef0gb3Mi1AV5WpN8.append(fCXyTlcmF4WuetVork)
	items = dEyT9xhGjolYzLCH7460w3.findall('source src="(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	for fCXyTlcmF4WuetVork in items:
		fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork.replace('//','/')
		A7Ap2wdlxM.append('mp4 src')
		duef0gb3Mi1AV5WpN8.append(fCXyTlcmF4WuetVork)
	items = dEyT9xhGjolYzLCH7460w3.findall('VideoAddress":"(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if items:
		fCXyTlcmF4WuetVork = items[int(zN7sZyFnw5JTE8)-1]
		fCXyTlcmF4WuetVork = KKxw6aJkTAFdDOeh3r+YqdaDIig21wBTWJeUHbc(fCXyTlcmF4WuetVork)
		A7Ap2wdlxM.append('mp4 address')
		duef0gb3Mi1AV5WpN8.append(fCXyTlcmF4WuetVork)
	items = dEyT9xhGjolYzLCH7460w3.findall('VoiceAddress":"(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if items:
		fCXyTlcmF4WuetVork = items[int(zN7sZyFnw5JTE8)-1]
		fCXyTlcmF4WuetVork = KKxw6aJkTAFdDOeh3r+YqdaDIig21wBTWJeUHbc(fCXyTlcmF4WuetVork)
		A7Ap2wdlxM.append('mp3 address')
		duef0gb3Mi1AV5WpN8.append(fCXyTlcmF4WuetVork)
	if len(duef0gb3Mi1AV5WpN8)==1: fCXyTlcmF4WuetVork = duef0gb3Mi1AV5WpN8[0]
	else:
		mmfrx2S5XqknFTDeRhj49LuYv1wW0 = ccv1mVPUsnr('اختر الفيديو المناسب:', A7Ap2wdlxM)
		if mmfrx2S5XqknFTDeRhj49LuYv1wW0 == -1 : return
		fCXyTlcmF4WuetVork = duef0gb3Mi1AV5WpN8[mmfrx2S5XqknFTDeRhj49LuYv1wW0]
	PsD3IgluKFyvzMLoRT9j5hq2(fCXyTlcmF4WuetVork,sQU2GnRoMwLK8CBdfzmNr4jXyO,'video')
	return
def kiCsMQD3ucU8PVEIrBf5OxztdjFnh(url):
	if JaQEtCzDXgos1cdZN in url: ekEOd3mqAThaBDUoIrntuGRjYW = JaQEtCzDXgos1cdZN
	elif QSaKzorWqRMY8JkTtNdG1exb in url: ekEOd3mqAThaBDUoIrntuGRjYW = QSaKzorWqRMY8JkTtNdG1exb
	elif H6RzwPS2yjtZavnqQYbC9 in url: ekEOd3mqAThaBDUoIrntuGRjYW = H6RzwPS2yjtZavnqQYbC9
	elif HdsUA2jGVWbo87RTICg0 in url: ekEOd3mqAThaBDUoIrntuGRjYW = HdsUA2jGVWbo87RTICg0
	else: ekEOd3mqAThaBDUoIrntuGRjYW = iiy37aKq0pCEIOwfcTh61xb4U
	return ekEOd3mqAThaBDUoIrntuGRjYW
def yC1lTFBOjLzHma7JWiv2wESRfAp6Qe(url):
	if   JaQEtCzDXgos1cdZN in url: aN8jtOe3hcFP6fwRYnbg = 'ar'
	elif QSaKzorWqRMY8JkTtNdG1exb in url: aN8jtOe3hcFP6fwRYnbg = 'en'
	elif H6RzwPS2yjtZavnqQYbC9 in url: aN8jtOe3hcFP6fwRYnbg = 'fa'
	elif HdsUA2jGVWbo87RTICg0 in url: aN8jtOe3hcFP6fwRYnbg = 'fa2'
	else: aN8jtOe3hcFP6fwRYnbg = iiy37aKq0pCEIOwfcTh61xb4U
	return aN8jtOe3hcFP6fwRYnbg
def FaD6NxfSIbzZimr9d4wOjQMkYhn5(url):
	aN8jtOe3hcFP6fwRYnbg = yC1lTFBOjLzHma7JWiv2wESRfAp6Qe(url)
	eCGwzSrqBmIv = url + '/Home/Live'
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(Dxc7GChQwZ4kOlKHSbL06agnB,'GET',eCGwzSrqBmIv,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'IFILM-LIVE-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	items = dEyT9xhGjolYzLCH7460w3.findall('source src="(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	O5Pwg3UFyX0k9E = items[0]
	PsD3IgluKFyvzMLoRT9j5hq2(O5Pwg3UFyX0k9E,sQU2GnRoMwLK8CBdfzmNr4jXyO,'live')
	return
def mUhJtHB9nw(search):
	search,brFQp5vmgJWdZfEkCBOlu9c,showDialogs = XkYnev3ZCA6ahO94(search)
	if not search:
		search = TTBf6S08q1NKXd5v9wa()
		if not search: return
	VVOtdjT9AF4Wk3GECqHL = search.replace(iFBmE2MUIpSu34wsd7Rf6z,'+')
	if showDialogs:
		W846ki2vgVlPKmc9GLjTdHtSx1QhuF = [ JaQEtCzDXgos1cdZN , QSaKzorWqRMY8JkTtNdG1exb , H6RzwPS2yjtZavnqQYbC9 , HdsUA2jGVWbo87RTICg0 ]
		R62ZFAHJCl0YeQWEvMhprDi7mPVg3 = [ 'عربي' , 'English' , 'فارسى' , 'فارسى 2' ]
		mmfrx2S5XqknFTDeRhj49LuYv1wW0 = ccv1mVPUsnr('اختر اللغة المناسبة:', R62ZFAHJCl0YeQWEvMhprDi7mPVg3)
		if mmfrx2S5XqknFTDeRhj49LuYv1wW0 == -1 : return
		website = W846ki2vgVlPKmc9GLjTdHtSx1QhuF[mmfrx2S5XqknFTDeRhj49LuYv1wW0]
	else:
		if '_IFILM-ARABIC_' in brFQp5vmgJWdZfEkCBOlu9c: website = JaQEtCzDXgos1cdZN
		elif '_IFILM-ENGLISH_' in brFQp5vmgJWdZfEkCBOlu9c: website = QSaKzorWqRMY8JkTtNdG1exb
		else: website = iiy37aKq0pCEIOwfcTh61xb4U
	if not website: return
	aN8jtOe3hcFP6fwRYnbg = yC1lTFBOjLzHma7JWiv2wESRfAp6Qe(website)
	eCGwzSrqBmIv = website + "/Home/Search?searchstring=" + VVOtdjT9AF4Wk3GECqHL
	Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(PNjZMS7nxa9clHusz1,eCGwzSrqBmIv,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'IFILM-SEARCH-1st')
	items = dEyT9xhGjolYzLCH7460w3.findall('"ImageAddress_S":"(.*?)".*?"CategoryId":(.*?),"Id":(.*?),"Title":"(.*?)",',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if items:
		for C0dvhEbPWYlUtimM3x,RRIscyLmNH9dq2Dio3TSr,id,title in items:
			if RRIscyLmNH9dq2Dio3TSr in ['3','7']:
				title = title.replace('\\',iiy37aKq0pCEIOwfcTh61xb4U)
				title = title.replace('"',iiy37aKq0pCEIOwfcTh61xb4U)
				if RRIscyLmNH9dq2Dio3TSr=='3':
					type = 'Series'
					if aN8jtOe3hcFP6fwRYnbg=='ar': name = 'مسلسل : '
					elif aN8jtOe3hcFP6fwRYnbg=='en': name = 'Series : '
					elif aN8jtOe3hcFP6fwRYnbg=='fa': name = 'سريال ها : '
					elif aN8jtOe3hcFP6fwRYnbg=='fa2': name = 'سريال ها : '
				elif RRIscyLmNH9dq2Dio3TSr=='5':
					type = 'Film'
					if aN8jtOe3hcFP6fwRYnbg=='ar': name = 'فيلم : '
					elif aN8jtOe3hcFP6fwRYnbg=='en': name = 'Movie : '
					elif aN8jtOe3hcFP6fwRYnbg=='fa': name = 'فيلم : '
					elif aN8jtOe3hcFP6fwRYnbg=='fa2': name = 'فلم ها : '
				elif RRIscyLmNH9dq2Dio3TSr=='7':
					type = 'Program'
					if aN8jtOe3hcFP6fwRYnbg=='ar': name = 'برنامج : '
					elif aN8jtOe3hcFP6fwRYnbg=='en': name = 'Program : '
					elif aN8jtOe3hcFP6fwRYnbg=='fa': name = 'برنامه ها : '
					elif aN8jtOe3hcFP6fwRYnbg=='fa2': name = 'برنامه ها : '
				title = name + title
				fCXyTlcmF4WuetVork = website + '/' + type + '/Content/' + id
				C0dvhEbPWYlUtimM3x = YqdaDIig21wBTWJeUHbc(C0dvhEbPWYlUtimM3x)
				C0dvhEbPWYlUtimM3x = website+C0dvhEbPWYlUtimM3x
				bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,23,C0dvhEbPWYlUtimM3x,'101')
	return
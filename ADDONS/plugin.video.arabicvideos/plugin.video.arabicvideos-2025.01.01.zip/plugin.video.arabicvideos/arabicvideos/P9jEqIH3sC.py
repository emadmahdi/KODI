# -*- coding: utf-8 -*-
from braVAkwfBN import *
sQU2GnRoMwLK8CBdfzmNr4jXyO = 'ALMSTBA'
ooQEi5O6tYsGVF8LU0TC3hgMeflBwH = '_MST_'
JaQEtCzDXgos1cdZN = gZ4LwbKaOm[sQU2GnRoMwLK8CBdfzmNr4jXyO][0]
a8GCLIuWNkS = ['الرئيسية','يلا شوت']
def sHVM8YchrDjZAJ7(mode,url,text):
	if   mode==860: EA7FzO1kMZGQXDd2giB0cwLom = jihuS9LVAvTrClPapMbUEwfn8XN()
	elif mode==861: EA7FzO1kMZGQXDd2giB0cwLom = AIQeNZP4FMDw9S(url,text)
	elif mode==862: EA7FzO1kMZGQXDd2giB0cwLom = TW6Z0zqaDl(url)
	elif mode==863: EA7FzO1kMZGQXDd2giB0cwLom = LEc19rxAg0P4ZXmSaCNid(url,text)
	elif mode==869: EA7FzO1kMZGQXDd2giB0cwLom = mUhJtHB9nw(text)
	else: EA7FzO1kMZGQXDd2giB0cwLom = False
	return EA7FzO1kMZGQXDd2giB0cwLom
def jihuS9LVAvTrClPapMbUEwfn8XN():
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',JaQEtCzDXgos1cdZN,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'ALMSTBA-MENU-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'بحث في الموقع',iiy37aKq0pCEIOwfcTh61xb4U,869,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'_REMEMBERRESULTS_')
	bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"primary-links"(.*?)</u',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?<span>(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title in items:
			if title in a8GCLIuWNkS: continue
			bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,861)
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"list-categories"(.*?)<script',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?>(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title in items:
			if 'http' not in fCXyTlcmF4WuetVork: fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN+'/'+fCXyTlcmF4WuetVork.lstrip('/')
			if title in a8GCLIuWNkS: continue
			bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,861)
	return
def AIQeNZP4FMDw9S(url,uuX8TYmVoFRlvpQ7LZ=iiy37aKq0pCEIOwfcTh61xb4U):
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'ALMSTBA-TITLES-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"home-content"(.*?)"footer"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		PPH1sQtTkDBbnlYpZfo5 = PPH1sQtTkDBbnlYpZfo5.replace('"overlay"','"duration"><')
		items = dEyT9xhGjolYzLCH7460w3.findall('"thumb".*?data-src="(.*?)".*?"duration">(.*?)<.*?href="(.*?)">(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		u3Rztpl4VHO9GZ7jCBM65kvS = []
		for C0dvhEbPWYlUtimM3x,Zt6GY7K2oFeAd5kTy3nJvDBpQr,fCXyTlcmF4WuetVork,title in items:
			title = title.strip(' ')
			title = JIY6A30UOsQboNVqCn(title)
			zN7sZyFnw5JTE8 = dEyT9xhGjolYzLCH7460w3.findall('(.*?) (الحلقة|حلقة).\d+',title,dEyT9xhGjolYzLCH7460w3.DOTALL)
			if 'episodes' not in uuX8TYmVoFRlvpQ7LZ and zN7sZyFnw5JTE8:
				title = '_MOD_' + zN7sZyFnw5JTE8[0][0]
				title = title.replace('اون لاين',iiy37aKq0pCEIOwfcTh61xb4U)
				if title not in u3Rztpl4VHO9GZ7jCBM65kvS:
					bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,863,C0dvhEbPWYlUtimM3x)
					u3Rztpl4VHO9GZ7jCBM65kvS.append(title)
			else: bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,862,C0dvhEbPWYlUtimM3x,Zt6GY7K2oFeAd5kTy3nJvDBpQr)
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('''["']pagination["'](.*?)["']footer["']''',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		uuX8TYmVoFRlvpQ7LZ = 'episodes_pages' if 'episodes' in uuX8TYmVoFRlvpQ7LZ else 'pages'
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)">(.*?)</a>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title in items:
			title = JIY6A30UOsQboNVqCn(title)
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'صفحة '+title,fCXyTlcmF4WuetVork,861,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,uuX8TYmVoFRlvpQ7LZ)
	else:
		fFcGDq7jWaPbBw9hnltUoTMiOKzpk = dEyT9xhGjolYzLCH7460w3.findall('class="pagination__next.*?href="(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if fFcGDq7jWaPbBw9hnltUoTMiOKzpk:
			fCXyTlcmF4WuetVork = fFcGDq7jWaPbBw9hnltUoTMiOKzpk[0]
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'صفحة لاحقة',fCXyTlcmF4WuetVork,861,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,uuX8TYmVoFRlvpQ7LZ)
	return
def LEc19rxAg0P4ZXmSaCNid(url,kbTg05YG6clitmjwoDx3VZQuq):
	ffBG4TaQU8lVF26R = F82MvyX4ThI6sbnA3efDoVS(url,'url')
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'ALMSTBA-EPISODES_SEASONS-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	HG5rE20ORdbqUKWewuZCJP4zoXF6g = dEyT9xhGjolYzLCH7460w3.findall('"episodes-container"(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	L95mrowGgdsD = dEyT9xhGjolYzLCH7460w3.findall('"thumbnailUrl":"(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	C0dvhEbPWYlUtimM3x = L95mrowGgdsD[0] if L95mrowGgdsD else iiy37aKq0pCEIOwfcTh61xb4U
	C0dvhEbPWYlUtimM3x = C0dvhEbPWYlUtimM3x.replace('\/','/')
	C0dvhEbPWYlUtimM3x += '|Referer='+JaQEtCzDXgos1cdZN
	items = []
	MSkCvHyJmlVYuZQGzpDNr6o1 = False
	if HG5rE20ORdbqUKWewuZCJP4zoXF6g and not kbTg05YG6clitmjwoDx3VZQuq:
		PPH1sQtTkDBbnlYpZfo5 = HG5rE20ORdbqUKWewuZCJP4zoXF6g[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('data-tab="(.*?)".*?>(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for kbTg05YG6clitmjwoDx3VZQuq,title in items:
			kbTg05YG6clitmjwoDx3VZQuq = kbTg05YG6clitmjwoDx3VZQuq.strip('#')
			if len(items)>1: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,url,863,C0dvhEbPWYlUtimM3x,iiy37aKq0pCEIOwfcTh61xb4U,kbTg05YG6clitmjwoDx3VZQuq)
			else: MSkCvHyJmlVYuZQGzpDNr6o1 = True
	else: MSkCvHyJmlVYuZQGzpDNr6o1 = True
	if MSkCvHyJmlVYuZQGzpDNr6o1 or not kbTg05YG6clitmjwoDx3VZQuq:
		if not kbTg05YG6clitmjwoDx3VZQuq: eTov6CfDcRZVJEAq5BH = dEyT9xhGjolYzLCH7460w3.findall('"tab-content.*?id="(.*?)</div>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		else: eTov6CfDcRZVJEAq5BH = dEyT9xhGjolYzLCH7460w3.findall('"tab-content.*?id="'+kbTg05YG6clitmjwoDx3VZQuq+'"(.*?)</div>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if eTov6CfDcRZVJEAq5BH:
			PPH1sQtTkDBbnlYpZfo5 = eTov6CfDcRZVJEAq5BH[0]
			items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)" title="(.*?)"',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
			for fCXyTlcmF4WuetVork,title in items:
				if 'http' not in fCXyTlcmF4WuetVork: fCXyTlcmF4WuetVork = ffBG4TaQU8lVF26R+'/'+fCXyTlcmF4WuetVork.strip('./')
				title = title.replace('</em><span>',iFBmE2MUIpSu34wsd7Rf6z)
				bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,862,C0dvhEbPWYlUtimM3x)
	return
def TW6Z0zqaDl(url):
	ff2PjlcCF5ZWyIUbVguMz,fwDKASjdbmGvouLTFke = [],[]
	eCGwzSrqBmIv = url.strip('/')+'/?do=watch'
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',eCGwzSrqBmIv,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'ALMSTBA-PLAY-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	fCXyTlcmF4WuetVork = dEyT9xhGjolYzLCH7460w3.findall('iframe src="(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if fCXyTlcmF4WuetVork:
		fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork[0]
		fwDKASjdbmGvouLTFke.append(fCXyTlcmF4WuetVork)
		oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',fCXyTlcmF4WuetVork,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'ALMSTBA-PLAY-2nd')
		z0spMAOfJElv6L1K9ae = oCJ8TdG2LwSIVcbaUnhB.content
		hx0dU3Ki7AyEfkSZY6TmN2BwtX = dEyT9xhGjolYzLCH7460w3.findall('iframe src="(.*?)"',z0spMAOfJElv6L1K9ae,dEyT9xhGjolYzLCH7460w3.DOTALL)
		hx0dU3Ki7AyEfkSZY6TmN2BwtX = hx0dU3Ki7AyEfkSZY6TmN2BwtX[0] if hx0dU3Ki7AyEfkSZY6TmN2BwtX else fCXyTlcmF4WuetVork
		if hx0dU3Ki7AyEfkSZY6TmN2BwtX not in fwDKASjdbmGvouLTFke:
			fwDKASjdbmGvouLTFke.append(hx0dU3Ki7AyEfkSZY6TmN2BwtX)
			Zw4M5DUStdE6xp7GI = F82MvyX4ThI6sbnA3efDoVS(hx0dU3Ki7AyEfkSZY6TmN2BwtX,'name')
			hx0dU3Ki7AyEfkSZY6TmN2BwtX = hx0dU3Ki7AyEfkSZY6TmN2BwtX+'?named='+Zw4M5DUStdE6xp7GI+'__embed'
			ff2PjlcCF5ZWyIUbVguMz.append(hx0dU3Ki7AyEfkSZY6TmN2BwtX)
	headers = {'Referer':url}
	l6lm7giRe1UzEDIvb5 = dEyT9xhGjolYzLCH7460w3.findall('post_id:(\d+)',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	R5Oy7SrvE3o = JaQEtCzDXgos1cdZN+'/wp-admin/admin-ajax.php?action=video_info&post_id='+l6lm7giRe1UzEDIvb5[0]
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',R5Oy7SrvE3o,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'ALMSTBA-PLAY-3rd')
	z0spMAOfJElv6L1K9ae = oCJ8TdG2LwSIVcbaUnhB.content
	fCXyTlcmF4WuetVork = dEyT9xhGjolYzLCH7460w3.findall('"src":"(.*?)"',z0spMAOfJElv6L1K9ae,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if fCXyTlcmF4WuetVork:
		fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork[0]
		fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork.replace('\/','/')
		if fCXyTlcmF4WuetVork not in fwDKASjdbmGvouLTFke:
			fwDKASjdbmGvouLTFke.append(fCXyTlcmF4WuetVork)
			Zw4M5DUStdE6xp7GI = F82MvyX4ThI6sbnA3efDoVS(fCXyTlcmF4WuetVork,'name')
			fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork+'?named='+Zw4M5DUStdE6xp7GI+'__watch'
			ff2PjlcCF5ZWyIUbVguMz.append(fCXyTlcmF4WuetVork)
	fCXyTlcmF4WuetVork = dEyT9xhGjolYzLCH7460w3.findall('"Download" target="_blank" href="(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if fCXyTlcmF4WuetVork:
		fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork[0]
		if fCXyTlcmF4WuetVork not in fwDKASjdbmGvouLTFke:
			fwDKASjdbmGvouLTFke.append(fCXyTlcmF4WuetVork)
			Zw4M5DUStdE6xp7GI = F82MvyX4ThI6sbnA3efDoVS(fCXyTlcmF4WuetVork,'name')
			fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork+'?named='+Zw4M5DUStdE6xp7GI+'__download'
			ff2PjlcCF5ZWyIUbVguMz.append(fCXyTlcmF4WuetVork)
	import lqBJGK8hXO
	lqBJGK8hXO.ZDg1HavwueT85mcAOorC4hnS(ff2PjlcCF5ZWyIUbVguMz,sQU2GnRoMwLK8CBdfzmNr4jXyO,'video',url)
	return
def mUhJtHB9nw(search):
	search,brFQp5vmgJWdZfEkCBOlu9c,showDialogs = XkYnev3ZCA6ahO94(search)
	if search==iiy37aKq0pCEIOwfcTh61xb4U: search = TTBf6S08q1NKXd5v9wa()
	if search==iiy37aKq0pCEIOwfcTh61xb4U: return
	search = search.replace(iFBmE2MUIpSu34wsd7Rf6z,'+')
	url = JaQEtCzDXgos1cdZN+'/?s='+search
	AIQeNZP4FMDw9S(url,'search')
	return
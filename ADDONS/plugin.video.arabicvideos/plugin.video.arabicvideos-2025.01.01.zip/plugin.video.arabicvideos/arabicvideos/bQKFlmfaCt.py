# -*- coding: utf-8 -*-
from braVAkwfBN import *
sQU2GnRoMwLK8CBdfzmNr4jXyO = 'CIMAWBAS'
ooQEi5O6tYsGVF8LU0TC3hgMeflBwH = '_CWB_'
JaQEtCzDXgos1cdZN = gZ4LwbKaOm[sQU2GnRoMwLK8CBdfzmNr4jXyO][0]
a8GCLIuWNkS = ['الصفحة الرئيسية','Sign in','تسجيل','افلام للكبار فقط']
headers = {'Referer':JaQEtCzDXgos1cdZN}
def sHVM8YchrDjZAJ7(mode,url,text):
	if   mode==980: EA7FzO1kMZGQXDd2giB0cwLom = jihuS9LVAvTrClPapMbUEwfn8XN()
	elif mode==981: EA7FzO1kMZGQXDd2giB0cwLom = AIQeNZP4FMDw9S(url,text)
	elif mode==982: EA7FzO1kMZGQXDd2giB0cwLom = TW6Z0zqaDl(url)
	elif mode==983: EA7FzO1kMZGQXDd2giB0cwLom = LEc19rxAg0P4ZXmSaCNid(url,text)
	elif mode==984: EA7FzO1kMZGQXDd2giB0cwLom = BaSyudevC40nsQHW5j7JX6RM9(url)
	elif mode==989: EA7FzO1kMZGQXDd2giB0cwLom = mUhJtHB9nw(text)
	else: EA7FzO1kMZGQXDd2giB0cwLom = False
	return EA7FzO1kMZGQXDd2giB0cwLom
def jihuS9LVAvTrClPapMbUEwfn8XN():
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',JaQEtCzDXgos1cdZN,headers,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'CIMAWBAS-MENU-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'بحث في الموقع',iiy37aKq0pCEIOwfcTh61xb4U,989,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'_REMEMBERRESULTS_')
	bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('''["']navslide-wrap["'](.*?)</ul>''',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?</i>(.*?)</a>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title in items:
			if title in a8GCLIuWNkS: continue
			bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,984)
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('/category.php">(.*?)"navslide-divider"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('''["']dropdown-menu["'](.*?)</ul>''',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	for U462wftipjCPA1hLuGsKr8koxnd in UUIohmv597bO83YCLgWS: PPH1sQtTkDBbnlYpZfo5 = PPH1sQtTkDBbnlYpZfo5.replace(U462wftipjCPA1hLuGsKr8koxnd,iiy37aKq0pCEIOwfcTh61xb4U)
	items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?>(.*?)</a>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	for fCXyTlcmF4WuetVork,title in items:
		if not title: continue
		if title in a8GCLIuWNkS: continue
		if title=='جديد الأفلام': title = 'المضاف حديثا'
		bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,984)
	return
def BaSyudevC40nsQHW5j7JX6RM9(url):
	oBCcmrv9tzPEOa5ILk7j,lFmsiNI2UDoJBdVCQtqx4WPXb7 = [],[]
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'CIMAWBAS-SUBMENU-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	HG5rE20ORdbqUKWewuZCJP4zoXF6g = dEyT9xhGjolYzLCH7460w3.findall('"caret"(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if HG5rE20ORdbqUKWewuZCJP4zoXF6g and '.php' in str(HG5rE20ORdbqUKWewuZCJP4zoXF6g):
		PPH1sQtTkDBbnlYpZfo5 = HG5rE20ORdbqUKWewuZCJP4zoXF6g[0]
		PPH1sQtTkDBbnlYpZfo5 = PPH1sQtTkDBbnlYpZfo5.replace('"presentation"','</ul>')
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if not UUIohmv597bO83YCLgWS: UUIohmv597bO83YCLgWS = [(iiy37aKq0pCEIOwfcTh61xb4U,PPH1sQtTkDBbnlYpZfo5)]
		for MF3KpchD8xSdtL0VXTAB96w,PPH1sQtTkDBbnlYpZfo5 in UUIohmv597bO83YCLgWS:
			oBCcmrv9tzPEOa5ILk7j = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?>(.*?)</a>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
			if MF3KpchD8xSdtL0VXTAB96w: MF3KpchD8xSdtL0VXTAB96w = MF3KpchD8xSdtL0VXTAB96w+': '
			for fCXyTlcmF4WuetVork,title in oBCcmrv9tzPEOa5ILk7j:
				title = MF3KpchD8xSdtL0VXTAB96w+title
				bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,981)
	eTov6CfDcRZVJEAq5BH = dEyT9xhGjolYzLCH7460w3.findall('"pm-category-subcats"(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if eTov6CfDcRZVJEAq5BH:
		PPH1sQtTkDBbnlYpZfo5 = eTov6CfDcRZVJEAq5BH[0]
		lFmsiNI2UDoJBdVCQtqx4WPXb7 = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)">(.*?)</a>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if 1 or len(lFmsiNI2UDoJBdVCQtqx4WPXb7)<30:
			if oBCcmrv9tzPEOa5ILk7j: bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
			for fCXyTlcmF4WuetVork,title in lFmsiNI2UDoJBdVCQtqx4WPXb7:
				if title in a8GCLIuWNkS: continue
				bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,981)
	if not HG5rE20ORdbqUKWewuZCJP4zoXF6g and not eTov6CfDcRZVJEAq5BH: AIQeNZP4FMDw9S(url)
	return
def AIQeNZP4FMDw9S(url,lHDuLVCy8kvqB6Rxh4Gs5K=iiy37aKq0pCEIOwfcTh61xb4U):
	ffBG4TaQU8lVF26R = F82MvyX4ThI6sbnA3efDoVS(url,'url')
	global headers
	headers['Referer'] = ffBG4TaQU8lVF26R
	if lHDuLVCy8kvqB6Rxh4Gs5K=='ajax-search':
		url,search = url.split('?',1)
		data = 'queryString='+search
		rzR9SN7ApZuQhTDWEX3V6ga = headers.copy()
		rzR9SN7ApZuQhTDWEX3V6ga['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8'
		oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'POST',url,data,rzR9SN7ApZuQhTDWEX3V6ga,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'CIMAWBAS-TITLES-1st')
	else:
		oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'CIMAWBAS-TITLES-2nd')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	PPH1sQtTkDBbnlYpZfo5,items = iiy37aKq0pCEIOwfcTh61xb4U,[]
	if lHDuLVCy8kvqB6Rxh4Gs5K=='ajax-search':
		PPH1sQtTkDBbnlYpZfo5 = Vxz6OndPIX4g2kaRp7
		lFmsiNI2UDoJBdVCQtqx4WPXb7 = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)">(.*?)</a>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title in lFmsiNI2UDoJBdVCQtqx4WPXb7: items.append((iiy37aKq0pCEIOwfcTh61xb4U,fCXyTlcmF4WuetVork,title))
	elif lHDuLVCy8kvqB6Rxh4Gs5K=='featured':
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"pm-carousel_featured"(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if UUIohmv597bO83YCLgWS: PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
	elif lHDuLVCy8kvqB6Rxh4Gs5K=='new_episodes':
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"row pm-ul-browse-videos(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if UUIohmv597bO83YCLgWS: PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
	elif lHDuLVCy8kvqB6Rxh4Gs5K=='new_movies':
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"row pm-ul-browse-videos(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if len(UUIohmv597bO83YCLgWS)>1: PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[1]
	elif lHDuLVCy8kvqB6Rxh4Gs5K=='featured_series':
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"home-series-list"(.*?)</div>[\t|\n]*</div>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if UUIohmv597bO83YCLgWS: PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
	else:
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"pm-grid"(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if UUIohmv597bO83YCLgWS: PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
	if PPH1sQtTkDBbnlYpZfo5 and not items: items = dEyT9xhGjolYzLCH7460w3.findall('"thumbnail".*?<a href="(.*?)" title="(.*?)".*?data-echo="(.*?)"',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if not items: return
	u3Rztpl4VHO9GZ7jCBM65kvS = []
	mxXKsCgL5OoP1evURZ8SdIfpBrwu = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for fCXyTlcmF4WuetVork,title,C0dvhEbPWYlUtimM3x in items:
		C0dvhEbPWYlUtimM3x += '|Referer='+ffBG4TaQU8lVF26R
		if 'http' not in fCXyTlcmF4WuetVork: fCXyTlcmF4WuetVork = ffBG4TaQU8lVF26R+'/'+fCXyTlcmF4WuetVork.strip('/')
		title = JIY6A30UOsQboNVqCn(title)
		zN7sZyFnw5JTE8 = dEyT9xhGjolYzLCH7460w3.findall('(.*?) (الحلقة|حلقة).\d+',title,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if any(aasX2cby4Vo5rTgB in title for aasX2cby4Vo5rTgB in mxXKsCgL5OoP1evURZ8SdIfpBrwu):
			bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,982,C0dvhEbPWYlUtimM3x)
		elif lHDuLVCy8kvqB6Rxh4Gs5K=='new_episodes':
			bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,982,C0dvhEbPWYlUtimM3x)
		elif zN7sZyFnw5JTE8:
			title = '_MOD_' + zN7sZyFnw5JTE8[0][0]
			if title not in u3Rztpl4VHO9GZ7jCBM65kvS:
				bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,983,C0dvhEbPWYlUtimM3x)
				u3Rztpl4VHO9GZ7jCBM65kvS.append(title)
		else: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,983,C0dvhEbPWYlUtimM3x)
	if 1:
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"pagination(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if UUIohmv597bO83YCLgWS:
			PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
			items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?>(.*?)</a>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
			for fCXyTlcmF4WuetVork,title in items:
				if fCXyTlcmF4WuetVork=='#': continue
				if 'http' not in fCXyTlcmF4WuetVork: fCXyTlcmF4WuetVork = ffBG4TaQU8lVF26R+'/'+fCXyTlcmF4WuetVork.strip('/')
				title = JIY6A30UOsQboNVqCn(title)
				bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'صفحة '+title,fCXyTlcmF4WuetVork,981)
	return
def LEc19rxAg0P4ZXmSaCNid(url,kbTg05YG6clitmjwoDx3VZQuq):
	ffBG4TaQU8lVF26R = F82MvyX4ThI6sbnA3efDoVS(url,'url')
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'CIMAWBAS-EPISODES-2nd')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	HG5rE20ORdbqUKWewuZCJP4zoXF6g = dEyT9xhGjolYzLCH7460w3.findall('"SeasonsBox"(.*?)"SeasonsEpisodesMain',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	L95mrowGgdsD = dEyT9xhGjolYzLCH7460w3.findall('preview_image_url: "(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	C0dvhEbPWYlUtimM3x = L95mrowGgdsD[0] if L95mrowGgdsD else iiy37aKq0pCEIOwfcTh61xb4U
	C0dvhEbPWYlUtimM3x += '|Referer='+ffBG4TaQU8lVF26R
	items = []
	MSkCvHyJmlVYuZQGzpDNr6o1 = False
	if HG5rE20ORdbqUKWewuZCJP4zoXF6g and not kbTg05YG6clitmjwoDx3VZQuq:
		PPH1sQtTkDBbnlYpZfo5 = HG5rE20ORdbqUKWewuZCJP4zoXF6g[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('''onclick=".*?openCity\(event, '(.*?)'\)".*?>(.*?)</button>''',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for kbTg05YG6clitmjwoDx3VZQuq,title in items:
			kbTg05YG6clitmjwoDx3VZQuq = kbTg05YG6clitmjwoDx3VZQuq.strip('#')
			if len(items)>1: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,url,983,C0dvhEbPWYlUtimM3x,iiy37aKq0pCEIOwfcTh61xb4U,kbTg05YG6clitmjwoDx3VZQuq)
			else: MSkCvHyJmlVYuZQGzpDNr6o1 = True
	else: MSkCvHyJmlVYuZQGzpDNr6o1 = True
	eTov6CfDcRZVJEAq5BH = []
	if kbTg05YG6clitmjwoDx3VZQuq: eTov6CfDcRZVJEAq5BH = dEyT9xhGjolYzLCH7460w3.findall('id="'+kbTg05YG6clitmjwoDx3VZQuq+'"(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if not eTov6CfDcRZVJEAq5BH:
		eTov6CfDcRZVJEAq5BH = dEyT9xhGjolYzLCH7460w3.findall('"AiredEPS"(.*?)</div>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if eTov6CfDcRZVJEAq5BH:
			PPH1sQtTkDBbnlYpZfo5 = eTov6CfDcRZVJEAq5BH[0]
			items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?">(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
			for fCXyTlcmF4WuetVork,title in items:
				if 'http' not in fCXyTlcmF4WuetVork: fCXyTlcmF4WuetVork = ffBG4TaQU8lVF26R+'/'+fCXyTlcmF4WuetVork.strip('/')
				title = title.replace('</em><span>',iFBmE2MUIpSu34wsd7Rf6z)
				bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,982,C0dvhEbPWYlUtimM3x)
	elif eTov6CfDcRZVJEAq5BH and MSkCvHyJmlVYuZQGzpDNr6o1:
		PPH1sQtTkDBbnlYpZfo5 = eTov6CfDcRZVJEAq5BH[0]
		lFmsiNI2UDoJBdVCQtqx4WPXb7 = dEyT9xhGjolYzLCH7460w3.findall('''title=['"](.*?)['"].*?href=["'](.*?)["'].*?''',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if lFmsiNI2UDoJBdVCQtqx4WPXb7:
			zw7N4lrtECp82,RQrACJj4nth87 = zip(*lFmsiNI2UDoJBdVCQtqx4WPXb7)
			VF1BSGJLUvl0mog3brie8YT5 = [C0dvhEbPWYlUtimM3x]*len(lFmsiNI2UDoJBdVCQtqx4WPXb7)
			items = zip(RQrACJj4nth87,zw7N4lrtECp82,VF1BSGJLUvl0mog3brie8YT5)
		if not items: items = dEyT9xhGjolYzLCH7460w3.findall('"thumbnail".*?href="(.*?)" title="(.*?)".*?src="(.*?)"',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title,C0dvhEbPWYlUtimM3x in items:
			C0dvhEbPWYlUtimM3x += '|Referer='+ffBG4TaQU8lVF26R
			if 'http' not in fCXyTlcmF4WuetVork: fCXyTlcmF4WuetVork = ffBG4TaQU8lVF26R+'/'+fCXyTlcmF4WuetVork.strip('/')
			title = title.replace('</em><span>',iFBmE2MUIpSu34wsd7Rf6z)
			bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,982,C0dvhEbPWYlUtimM3x)
	return
def TW6Z0zqaDl(url):
	ff2PjlcCF5ZWyIUbVguMz,fwDKASjdbmGvouLTFke = [],[]
	Vxz6OndPIX4g2kaRp7 = ''
	if 'post=' in Vxz6OndPIX4g2kaRp7:
		fCXyTlcmF4WuetVork = dEyT9xhGjolYzLCH7460w3.findall('id="player".*?href="(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork[0]
		H0BbXRwP5vOqS = fCXyTlcmF4WuetVork.split('post=')[1]
		H0BbXRwP5vOqS = UodGe76Lu2IHTYPxBhjk1RpcaqrM.b64decode(H0BbXRwP5vOqS)
		if J1MoiYc7ZwzKS: H0BbXRwP5vOqS = H0BbXRwP5vOqS.decode(df6QpwGxuJVZr)
		H0BbXRwP5vOqS = DeIL3qoa2UBtYPb('dict',H0BbXRwP5vOqS)
		P3tys0cXWbiIUKk7HQ6n89V = H0BbXRwP5vOqS['servers']
		v1JrBsOo8Qyzk = list(P3tys0cXWbiIUKk7HQ6n89V.keys())
		P3tys0cXWbiIUKk7HQ6n89V = list(P3tys0cXWbiIUKk7HQ6n89V.values())
		c1CH6qPe8oZX3irhEgAzuxm5 = zip(v1JrBsOo8Qyzk,P3tys0cXWbiIUKk7HQ6n89V)
		for title,fCXyTlcmF4WuetVork in c1CH6qPe8oZX3irhEgAzuxm5:
			fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork+'?named='+title+'__watch'
			ff2PjlcCF5ZWyIUbVguMz.append(fCXyTlcmF4WuetVork)
	else:
		eCGwzSrqBmIv = url.replace('watch.php','see.php')
		oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',eCGwzSrqBmIv,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'CIMAWBAS-PLAY2-1st')
		Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
		fCXyTlcmF4WuetVork = dEyT9xhGjolYzLCH7460w3.findall('"embedURL" href="(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if 0 and fCXyTlcmF4WuetVork:
			fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork[0]
			if fCXyTlcmF4WuetVork not in fwDKASjdbmGvouLTFke:
				fwDKASjdbmGvouLTFke.append(fCXyTlcmF4WuetVork)
				Zw4M5DUStdE6xp7GI = F82MvyX4ThI6sbnA3efDoVS(fCXyTlcmF4WuetVork,'name')
				fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork+'?named='+Zw4M5DUStdE6xp7GI+'__embed'
				ff2PjlcCF5ZWyIUbVguMz.append(fCXyTlcmF4WuetVork)
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('list_server(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if UUIohmv597bO83YCLgWS:
			PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
			items = dEyT9xhGjolYzLCH7460w3.findall("<iframe src='(.*?)'.*?<strong>(.*?)<",PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
			for fCXyTlcmF4WuetVork,title in items:
				if fCXyTlcmF4WuetVork in fwDKASjdbmGvouLTFke: continue
				fwDKASjdbmGvouLTFke.append(fCXyTlcmF4WuetVork)
				Zw4M5DUStdE6xp7GI = F82MvyX4ThI6sbnA3efDoVS(fCXyTlcmF4WuetVork,'name')
				fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork+'?named='+Zw4M5DUStdE6xp7GI+'__watch'
				ff2PjlcCF5ZWyIUbVguMz.append(fCXyTlcmF4WuetVork)
		eCGwzSrqBmIv = url.replace('watch.php','downloads.php')
		oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',eCGwzSrqBmIv,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,False,'CIMAWBAS-PLAY-2nd')
		Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"pm-download"(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for PPH1sQtTkDBbnlYpZfo5 in UUIohmv597bO83YCLgWS:
			items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?<strong>(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
			if not items: items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?<span>(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
			for fCXyTlcmF4WuetVork,title in items:
				if fCXyTlcmF4WuetVork in fwDKASjdbmGvouLTFke: continue
				fwDKASjdbmGvouLTFke.append(fCXyTlcmF4WuetVork)
				Zw4M5DUStdE6xp7GI = F82MvyX4ThI6sbnA3efDoVS(fCXyTlcmF4WuetVork,'name')
				fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork+'?named='+Zw4M5DUStdE6xp7GI+'__download'
				ff2PjlcCF5ZWyIUbVguMz.append(fCXyTlcmF4WuetVork)
	import lqBJGK8hXO
	lqBJGK8hXO.ZDg1HavwueT85mcAOorC4hnS(ff2PjlcCF5ZWyIUbVguMz,sQU2GnRoMwLK8CBdfzmNr4jXyO,'video',url)
	return
def mUhJtHB9nw(search):
	search,brFQp5vmgJWdZfEkCBOlu9c,showDialogs = XkYnev3ZCA6ahO94(search)
	if search==iiy37aKq0pCEIOwfcTh61xb4U: search = TTBf6S08q1NKXd5v9wa()
	if search==iiy37aKq0pCEIOwfcTh61xb4U: return
	search = search.replace(iFBmE2MUIpSu34wsd7Rf6z,'+')
	url = JaQEtCzDXgos1cdZN+'/search.php?keywords='+search
	AIQeNZP4FMDw9S(url,'search')
	return
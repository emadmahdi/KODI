# -*- coding: utf-8 -*-
from braVAkwfBN import *
sQU2GnRoMwLK8CBdfzmNr4jXyO = 'ARABICTOONS'
ooQEi5O6tYsGVF8LU0TC3hgMeflBwH = '_ART_'
JaQEtCzDXgos1cdZN = gZ4LwbKaOm[sQU2GnRoMwLK8CBdfzmNr4jXyO][0]
def sHVM8YchrDjZAJ7(mode,url,text):
	if   mode==730: EA7FzO1kMZGQXDd2giB0cwLom = jihuS9LVAvTrClPapMbUEwfn8XN()
	elif mode==731: EA7FzO1kMZGQXDd2giB0cwLom = AIQeNZP4FMDw9S(url,text)
	elif mode==732: EA7FzO1kMZGQXDd2giB0cwLom = TW6Z0zqaDl(url)
	elif mode==733: EA7FzO1kMZGQXDd2giB0cwLom = YNcMvoVF5swlDBJI7PL(url)
	elif mode==734: EA7FzO1kMZGQXDd2giB0cwLom = MeGviE6magR13IDFKLHSn0B(url)
	elif mode==735: EA7FzO1kMZGQXDd2giB0cwLom = FiSrIRZHp584gBk(url)
	elif mode==739: EA7FzO1kMZGQXDd2giB0cwLom = mUhJtHB9nw(text)
	else: EA7FzO1kMZGQXDd2giB0cwLom = False
	return EA7FzO1kMZGQXDd2giB0cwLom
def jihuS9LVAvTrClPapMbUEwfn8XN():
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'بحث في الموقع',iiy37aKq0pCEIOwfcTh61xb4U,739,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'_REMEMBERRESULTS_')
	bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'افلام',JaQEtCzDXgos1cdZN+'/movies.php',731)
	bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'مسلسلات',JaQEtCzDXgos1cdZN+'/cartoon.php',734)
	bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'مسلسلات مميزة',JaQEtCzDXgos1cdZN+'/top.php',735)
	bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'أحدث الأفلام المضافة',JaQEtCzDXgos1cdZN,731,'','','LATEST_MOVIES')
	bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'أحدث المسلسلات المضافة',JaQEtCzDXgos1cdZN,731,'','','LATEST_SERIES')
	return
def MeGviE6magR13IDFKLHSn0B(url):
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'الكل',url,731)
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'ARABICTOONS-SERIES_SUBMENU-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('label="navigation"(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall("href='(.*?)'>(.*?)</a>",PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title in items:
			fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN+'/'+fCXyTlcmF4WuetVork
			title = 'حرف '+title
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,731)
	return
def FiSrIRZHp584gBk(url):
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'ARABICTOONS-SERIES_FEATURED-2nd')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('class="slider"(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('title="(.*?)" href="(.*?)".*?src="(.*?)"',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for title,fCXyTlcmF4WuetVork,C0dvhEbPWYlUtimM3x in items:
			fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN+'/'+fCXyTlcmF4WuetVork
			C0dvhEbPWYlUtimM3x = JaQEtCzDXgos1cdZN+'/'+C0dvhEbPWYlUtimM3x
			title = title.strip(iFBmE2MUIpSu34wsd7Rf6z)
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,733,C0dvhEbPWYlUtimM3x)
	return
def AIQeNZP4FMDw9S(url,lHDuLVCy8kvqB6Rxh4Gs5K):
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'ARABICTOONS-TITLES-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall("class='moviesBlocks(.*?)list-group",Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if lHDuLVCy8kvqB6Rxh4Gs5K=='LATEST_SERIES': PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[1]
	else: PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
	items = dEyT9xhGjolYzLCH7460w3.findall('class="movie".*?href="(.*?)".*?src="(.*?)".*?<b>(.*?)</b>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	for fCXyTlcmF4WuetVork,C0dvhEbPWYlUtimM3x,title in items:
		fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN+'/'+fCXyTlcmF4WuetVork
		C0dvhEbPWYlUtimM3x = JaQEtCzDXgos1cdZN+'/'+C0dvhEbPWYlUtimM3x
		title = title.strip(iFBmE2MUIpSu34wsd7Rf6z)
		if 'movies.php' in url or lHDuLVCy8kvqB6Rxh4Gs5K=='LATEST_MOVIES':
			bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,732,C0dvhEbPWYlUtimM3x)
		else: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,733,C0dvhEbPWYlUtimM3x)
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"pagination(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[-1]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?>(.*?)</a>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title in items:
			fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN+'/'+fCXyTlcmF4WuetVork
			title = title.strip(iFBmE2MUIpSu34wsd7Rf6z)
			title = JIY6A30UOsQboNVqCn(title)
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'صفحة '+title,fCXyTlcmF4WuetVork,731)
	return
def YNcMvoVF5swlDBJI7PL(url):
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'ARABICTOONS-EPISODES-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall("class='moviesBlocks(.*?)script",Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('class="movie".*?title="(.*?)".*?href="(.*?)".*?src="(.*?)".*?<b>(.*?)</b>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for title,fCXyTlcmF4WuetVork,C0dvhEbPWYlUtimM3x,xjcbhOeEASYd1 in items:
			fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN+'/'+fCXyTlcmF4WuetVork
			C0dvhEbPWYlUtimM3x = JaQEtCzDXgos1cdZN+'/'+C0dvhEbPWYlUtimM3x
			title = title.strip(iFBmE2MUIpSu34wsd7Rf6z)
			title = title+iFBmE2MUIpSu34wsd7Rf6z+xjcbhOeEASYd1.strip(iFBmE2MUIpSu34wsd7Rf6z)
			bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,732,C0dvhEbPWYlUtimM3x)
	return
def TW6Z0zqaDl(url):
	ff2PjlcCF5ZWyIUbVguMz = []
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'ARABICTOONS-PLAY-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	P3tys0cXWbiIUKk7HQ6n89V = dEyT9xhGjolYzLCH7460w3.findall('source src="(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if P3tys0cXWbiIUKk7HQ6n89V:
		fCXyTlcmF4WuetVork = P3tys0cXWbiIUKk7HQ6n89V[0]
		if 'Referer=' not in fCXyTlcmF4WuetVork: fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork+'|Referer=https://www.arabic-toons.com'
		ff2PjlcCF5ZWyIUbVguMz.append(fCXyTlcmF4WuetVork+'?named=__embed')
	import lqBJGK8hXO
	lqBJGK8hXO.ZDg1HavwueT85mcAOorC4hnS(ff2PjlcCF5ZWyIUbVguMz,sQU2GnRoMwLK8CBdfzmNr4jXyO,'video',url)
	return
def mUhJtHB9nw(search):
	search,brFQp5vmgJWdZfEkCBOlu9c,showDialogs = XkYnev3ZCA6ahO94(search)
	if search==iiy37aKq0pCEIOwfcTh61xb4U: search = TTBf6S08q1NKXd5v9wa()
	if search==iiy37aKq0pCEIOwfcTh61xb4U: return
	search = search.replace(iFBmE2MUIpSu34wsd7Rf6z,'%20')
	duef0gb3Mi1AV5WpN8 = [iiy37aKq0pCEIOwfcTh61xb4U,'m']
	R62ZFAHJCl0YeQWEvMhprDi7mPVg3 = ['مسلسلات','افلام']
	if showDialogs:
		mmfrx2S5XqknFTDeRhj49LuYv1wW0 = ccv1mVPUsnr('اختر النوع المطلوب:', R62ZFAHJCl0YeQWEvMhprDi7mPVg3)
		if mmfrx2S5XqknFTDeRhj49LuYv1wW0==-1: return
	else: mmfrx2S5XqknFTDeRhj49LuYv1wW0 = 0
	type = duef0gb3Mi1AV5WpN8[mmfrx2S5XqknFTDeRhj49LuYv1wW0]
	url = JaQEtCzDXgos1cdZN+'/livesearch.php?'+type+'&q='+search
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'ARABICTOONS-SEARCH-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)">(.*?)<',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	for fCXyTlcmF4WuetVork,title in items:
		fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN+'/'+fCXyTlcmF4WuetVork
		title = title.strip(iFBmE2MUIpSu34wsd7Rf6z)
		if type=='m': bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,732)
		else: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,733)
	return
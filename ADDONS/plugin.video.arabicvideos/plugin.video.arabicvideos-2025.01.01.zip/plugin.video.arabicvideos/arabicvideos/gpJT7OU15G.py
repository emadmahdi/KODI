# -*- coding: utf-8 -*-
from braVAkwfBN import *
sQU2GnRoMwLK8CBdfzmNr4jXyO = 'EGYBEST1'
ooQEi5O6tYsGVF8LU0TC3hgMeflBwH = '_EB1_'
JaQEtCzDXgos1cdZN = gZ4LwbKaOm[sQU2GnRoMwLK8CBdfzmNr4jXyO][0]
a8GCLIuWNkS = ['مكتبتي','ايجي بست']
def sHVM8YchrDjZAJ7(mode,url,zLEP9N4BOsVrXa,text):
	if   mode==770: EA7FzO1kMZGQXDd2giB0cwLom = jihuS9LVAvTrClPapMbUEwfn8XN()
	elif mode==771: EA7FzO1kMZGQXDd2giB0cwLom = AIQeNZP4FMDw9S(url,zLEP9N4BOsVrXa)
	elif mode==772: EA7FzO1kMZGQXDd2giB0cwLom = BaSyudevC40nsQHW5j7JX6RM9(url)
	elif mode==773: EA7FzO1kMZGQXDd2giB0cwLom = TW6Z0zqaDl(url)
	elif mode==774: EA7FzO1kMZGQXDd2giB0cwLom = chQHNdWgTSDjti8R9pJUf(url,'FULL_FILTER___'+text)
	elif mode==775: EA7FzO1kMZGQXDd2giB0cwLom = chQHNdWgTSDjti8R9pJUf(url,'DEFINED_FILTER___'+text)
	elif mode==776: EA7FzO1kMZGQXDd2giB0cwLom = jjQL1mhRn3VpBzNcidEaT4yKt9(url,zLEP9N4BOsVrXa)
	elif mode==779: EA7FzO1kMZGQXDd2giB0cwLom = mUhJtHB9nw(text,url)
	else: EA7FzO1kMZGQXDd2giB0cwLom = False
	return EA7FzO1kMZGQXDd2giB0cwLom
def jihuS9LVAvTrClPapMbUEwfn8XN():
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'بحث في الموقع',iiy37aKq0pCEIOwfcTh61xb4U,779,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'_REMEMBERRESULTS_')
	bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(Dxc7GChQwZ4kOlKHSbL06agnB,'GET',JaQEtCzDXgos1cdZN,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'EGYBEST1-MENU-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('nav-list(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?<span>(.*?)</span>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title in items:
			title = title.strip(iFBmE2MUIpSu34wsd7Rf6z)
			if any(aasX2cby4Vo5rTgB in title for aasX2cby4Vo5rTgB in a8GCLIuWNkS): continue
			bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,771)
		bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('main-article(.*?)social-box',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('main-title.*?">(.*?)<.*?href="(.*?)"',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for title,fCXyTlcmF4WuetVork in items:
			title = title.strip(iFBmE2MUIpSu34wsd7Rf6z)
			bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,771,iiy37aKq0pCEIOwfcTh61xb4U,'mainmenu')
		bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('main-menu(.*?)</div></div>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)">(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title in items:
			title = title.strip(iFBmE2MUIpSu34wsd7Rf6z)
			bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,771)
	return Vxz6OndPIX4g2kaRp7
def jjQL1mhRn3VpBzNcidEaT4yKt9(url,type=iiy37aKq0pCEIOwfcTh61xb4U):
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'EGYBEST1-SEASONS_EPISODES-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('main-article".*?">(.*?)<(.*?)article',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		zfbAhCqkmOoZWyGpT3KUIF9anBN,f9a8L1lCJvn6pIUuP,items = iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,[]
		for name,PPH1sQtTkDBbnlYpZfo5 in UUIohmv597bO83YCLgWS:
			if 'حلقات' in name: f9a8L1lCJvn6pIUuP = PPH1sQtTkDBbnlYpZfo5
			if 'مواسم' in name: zfbAhCqkmOoZWyGpT3KUIF9anBN = PPH1sQtTkDBbnlYpZfo5
		if zfbAhCqkmOoZWyGpT3KUIF9anBN and not type:
			items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?data-src="(.*?)".*?"title">(.*?)<',zfbAhCqkmOoZWyGpT3KUIF9anBN,dEyT9xhGjolYzLCH7460w3.DOTALL)
			if len(items)>1:
				for fCXyTlcmF4WuetVork,C0dvhEbPWYlUtimM3x,title in items:
					bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,776,C0dvhEbPWYlUtimM3x,'season')
		if f9a8L1lCJvn6pIUuP and len(items)<2:
			items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?data-src="(.*?)".*?title="(.*?)"',f9a8L1lCJvn6pIUuP,dEyT9xhGjolYzLCH7460w3.DOTALL)
			if items:
				for fCXyTlcmF4WuetVork,C0dvhEbPWYlUtimM3x,title in items:
					bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,773,C0dvhEbPWYlUtimM3x)
			else:
				items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)">(.*?)<',f9a8L1lCJvn6pIUuP,dEyT9xhGjolYzLCH7460w3.DOTALL)
				for fCXyTlcmF4WuetVork,title in items:
					bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,773)
	return
def AIQeNZP4FMDw9S(url,type=iiy37aKq0pCEIOwfcTh61xb4U):
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'EGYBEST1-TITLES-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	items,ZZ9OJHhGUaIASWPD5eTBFwmRvo3Y7,HSAqBpsb2jRLvk9lx147rzY = [],False,False
	if not type:
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('main-content(.*?)</div>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if UUIohmv597bO83YCLgWS:
			PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
			items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?</i>(.*?)</a>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
			for fCXyTlcmF4WuetVork,title in items:
				title = title.strip(iFBmE2MUIpSu34wsd7Rf6z)
				bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,771,iiy37aKq0pCEIOwfcTh61xb4U,'submenu')
				ZZ9OJHhGUaIASWPD5eTBFwmRvo3Y7 = True
	if not type and 'p=' not in url:
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('searchform(.*?)</form>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if UUIohmv597bO83YCLgWS:
			if ZZ9OJHhGUaIASWPD5eTBFwmRvo3Y7: bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'فلتر محدد',url,775,iiy37aKq0pCEIOwfcTh61xb4U,'filter')
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'فلتر كامل',url,774,iiy37aKq0pCEIOwfcTh61xb4U,'filter')
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'بحث',url,779)
			bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
			HSAqBpsb2jRLvk9lx147rzY = True
	if not ZZ9OJHhGUaIASWPD5eTBFwmRvo3Y7:
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('blocks(.*?)article',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if UUIohmv597bO83YCLgWS:
			PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
			items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?src="(.*?)".*?class="title">(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
			for fCXyTlcmF4WuetVork,C0dvhEbPWYlUtimM3x,title in items:
				C0dvhEbPWYlUtimM3x = C0dvhEbPWYlUtimM3x.strip(OTlVEGYPSxsNaBdXUucqA3)
				fCXyTlcmF4WuetVork = a9I3YZjc6ySDPE4Kp(fCXyTlcmF4WuetVork)
				if '/serie/' in fCXyTlcmF4WuetVork: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,776,C0dvhEbPWYlUtimM3x,'season')
				else: bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,773,C0dvhEbPWYlUtimM3x)
			zLEP9N4BOsVrXa = '1'
			if 'p=' in url: url,zLEP9N4BOsVrXa = url.split('p=',1)
			FZ0zy7Cgeo1UjkR = '&' if '?' in url else '?'
			url = url+FZ0zy7Cgeo1UjkR
			url = url.replace('?&','?')
			if len(items)==40:
				url = url+'p='+str(int(zLEP9N4BOsVrXa)+1)
				bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'الصفحة التالية',url,771)
			elif zLEP9N4BOsVrXa!='1':
				url = url+'p='+str(int(zLEP9N4BOsVrXa)-1)
				bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'الصفحة السابقة',url,771)
	return
def TW6Z0zqaDl(url):
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(hI7SkXd94fFzAHNZCQoMqEutbnWP,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'EGYBEST1-PLAY-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	UAhMnV3r89cWy7X1D05GBCwTqOP4p = dEyT9xhGjolYzLCH7460w3.findall('<label>التصنيف</label>.*?">(.*?)<',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UAhMnV3r89cWy7X1D05GBCwTqOP4p and IUF8hYKEGLmHDtXbuWNvnJ(sQU2GnRoMwLK8CBdfzmNr4jXyO,url,UAhMnV3r89cWy7X1D05GBCwTqOP4p): return
	WK130YrED8vNhiHntepuXR,ff2PjlcCF5ZWyIUbVguMz,a8jRBLmeA2ti6 = [],[],[]
	fCXyTlcmF4WuetVork = dEyT9xhGjolYzLCH7460w3.findall('download-section.*?action="(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if fCXyTlcmF4WuetVork:
		fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork[0]
		if fCXyTlcmF4WuetVork not in a8jRBLmeA2ti6:
			a8jRBLmeA2ti6.append(fCXyTlcmF4WuetVork)
			ff2PjlcCF5ZWyIUbVguMz.append(fCXyTlcmF4WuetVork+'?named=__embed______'+YqdaDIig21wBTWJeUHbc(url))
	ddfSDGyqEc = dEyT9xhGjolYzLCH7460w3.findall('WatchServers(.*?)</div>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	for PPH1sQtTkDBbnlYpZfo5 in ddfSDGyqEc:
		P3tys0cXWbiIUKk7HQ6n89V = dEyT9xhGjolYzLCH7460w3.findall("url='(.*?)'.*?>(.*?)<",PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,Zw4M5DUStdE6xp7GI in P3tys0cXWbiIUKk7HQ6n89V:
			if fCXyTlcmF4WuetVork not in a8jRBLmeA2ti6:
				a8jRBLmeA2ti6.append(fCXyTlcmF4WuetVork)
				ff2PjlcCF5ZWyIUbVguMz.append(fCXyTlcmF4WuetVork+'?named='+Zw4M5DUStdE6xp7GI+'__both______'+YqdaDIig21wBTWJeUHbc(url))
	import lqBJGK8hXO
	lqBJGK8hXO.ZDg1HavwueT85mcAOorC4hnS(ff2PjlcCF5ZWyIUbVguMz,sQU2GnRoMwLK8CBdfzmNr4jXyO,'video',url)
	return
def mUhJtHB9nw(search,url=iiy37aKq0pCEIOwfcTh61xb4U):
	search,brFQp5vmgJWdZfEkCBOlu9c,showDialogs = XkYnev3ZCA6ahO94(search)
	if not search: search = TTBf6S08q1NKXd5v9wa()
	if not search: return
	VVOtdjT9AF4Wk3GECqHL = search.replace(iFBmE2MUIpSu34wsd7Rf6z,'%20')
	if not url: url = JaQEtCzDXgos1cdZN+'/search?query='+VVOtdjT9AF4Wk3GECqHL
	else: url = url+'?title='+VVOtdjT9AF4Wk3GECqHL+'&genre=&year=&lang='
	AIQeNZP4FMDw9S(url,'search')
	return
def Dv235GCSiTYasugHxhbPUVjdKkcprN(url):
	url = url.split('/smartemadfilter?')[0]
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(Dxc7GChQwZ4kOlKHSbL06agnB,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'EGYBEST1-GET_FILTERS_BLOCKS-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	n8nFIQBNaXD = []
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('form-row(.*?)</form>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		n8nFIQBNaXD = dEyT9xhGjolYzLCH7460w3.findall('select name="(.*?)".*?value>(.*?)<(.*?)</select',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		t4tvDjdhuyfVo,EaJdizIBhr3XnWGHsYxvO0S2oVyKwj,ddfSDGyqEc = zip(*n8nFIQBNaXD)
		n8nFIQBNaXD = zip(EaJdizIBhr3XnWGHsYxvO0S2oVyKwj,t4tvDjdhuyfVo,ddfSDGyqEc)
	return n8nFIQBNaXD
def T6TdxbQOnA(PPH1sQtTkDBbnlYpZfo5):
	items = dEyT9xhGjolYzLCH7460w3.findall('value="(.*?)">(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	return items
def GyQ7pvCNeFHiPs0U3Dqf(url):
	url = url.replace('/smartemadfilter?','?title=&')
	return url
PlFdUZ6T2ceunDCGBhiqXyrWwONYx = ['year','lang','genre']
ooTiu86KvMCYBceUV2J9rzLP1qE = ['year','lang','genre']
def chQHNdWgTSDjti8R9pJUf(url,filter):
	url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==iiy37aKq0pCEIOwfcTh61xb4U: Mhd9LWrfiF1EsASl6eP34uTp0qNGom,ovh6cXGg1qd85fn3CSJEisTlI7Yz = iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U
	else: Mhd9LWrfiF1EsASl6eP34uTp0qNGom,ovh6cXGg1qd85fn3CSJEisTlI7Yz = filter.split('___')
	if type=='DEFINED_FILTER':
		if ooTiu86KvMCYBceUV2J9rzLP1qE[0]+'=' not in Mhd9LWrfiF1EsASl6eP34uTp0qNGom: RRIscyLmNH9dq2Dio3TSr = ooTiu86KvMCYBceUV2J9rzLP1qE[0]
		for iEfNKT3velFyGth80SA4pxbCRrVD in range(len(ooTiu86KvMCYBceUV2J9rzLP1qE[0:-1])):
			if ooTiu86KvMCYBceUV2J9rzLP1qE[iEfNKT3velFyGth80SA4pxbCRrVD]+'=' in Mhd9LWrfiF1EsASl6eP34uTp0qNGom: RRIscyLmNH9dq2Dio3TSr = ooTiu86KvMCYBceUV2J9rzLP1qE[iEfNKT3velFyGth80SA4pxbCRrVD+1]
		HdFJThcNtWe3lb8n4OmaSwQ = Mhd9LWrfiF1EsASl6eP34uTp0qNGom+'&'+RRIscyLmNH9dq2Dio3TSr+'=0'
		vvlVH6JT9YDNPeSaRUkKCAwpr5uq = ovh6cXGg1qd85fn3CSJEisTlI7Yz+'&'+RRIscyLmNH9dq2Dio3TSr+'=0'
		cCZR4YdwUepABD9mQsubT8FgN = HdFJThcNtWe3lb8n4OmaSwQ.strip('&')+'___'+vvlVH6JT9YDNPeSaRUkKCAwpr5uq.strip('&')
		bPXk8KHyCUrifag = qJ8NQtuWARGjoZd9swfbH(ovh6cXGg1qd85fn3CSJEisTlI7Yz,'all')
		eCGwzSrqBmIv = url+'/smartemadfilter?'+bPXk8KHyCUrifag
	elif type=='FULL_FILTER':
		GMQ6AxE012X9 = qJ8NQtuWARGjoZd9swfbH(Mhd9LWrfiF1EsASl6eP34uTp0qNGom,'modified_values')
		GMQ6AxE012X9 = a9I3YZjc6ySDPE4Kp(GMQ6AxE012X9)
		if ovh6cXGg1qd85fn3CSJEisTlI7Yz: ovh6cXGg1qd85fn3CSJEisTlI7Yz = qJ8NQtuWARGjoZd9swfbH(ovh6cXGg1qd85fn3CSJEisTlI7Yz,'all')
		if not ovh6cXGg1qd85fn3CSJEisTlI7Yz: eCGwzSrqBmIv = url
		else: eCGwzSrqBmIv = url+'/smartemadfilter?'+ovh6cXGg1qd85fn3CSJEisTlI7Yz
		O5Pwg3UFyX0k9E = GyQ7pvCNeFHiPs0U3Dqf(eCGwzSrqBmIv)
		bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'أظهار قائمة الفيديو التي تم اختيارها ',O5Pwg3UFyX0k9E,771,iiy37aKq0pCEIOwfcTh61xb4U,'filter')
		bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+' [[   '+GMQ6AxE012X9+'   ]]',O5Pwg3UFyX0k9E,771,iiy37aKq0pCEIOwfcTh61xb4U,'filter')
		bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	n8nFIQBNaXD = Dv235GCSiTYasugHxhbPUVjdKkcprN(url)
	dict = {}
	for name,cWhMpFIbQU4D1Bi,PPH1sQtTkDBbnlYpZfo5 in n8nFIQBNaXD:
		name = name.replace('كل ',iiy37aKq0pCEIOwfcTh61xb4U)
		items = T6TdxbQOnA(PPH1sQtTkDBbnlYpZfo5)
		if '=' not in eCGwzSrqBmIv: eCGwzSrqBmIv = url
		if type=='DEFINED_FILTER':
			if RRIscyLmNH9dq2Dio3TSr!=cWhMpFIbQU4D1Bi: continue
			elif len(items)<2:
				if cWhMpFIbQU4D1Bi==ooTiu86KvMCYBceUV2J9rzLP1qE[-1]:
					O5Pwg3UFyX0k9E = GyQ7pvCNeFHiPs0U3Dqf(eCGwzSrqBmIv)
					AIQeNZP4FMDw9S(O5Pwg3UFyX0k9E)
				else: chQHNdWgTSDjti8R9pJUf(eCGwzSrqBmIv,'DEFINED_FILTER___'+cCZR4YdwUepABD9mQsubT8FgN)
				return
			else:
				if cWhMpFIbQU4D1Bi==ooTiu86KvMCYBceUV2J9rzLP1qE[-1]:
					O5Pwg3UFyX0k9E = GyQ7pvCNeFHiPs0U3Dqf(eCGwzSrqBmIv)
					bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'الجميع ',O5Pwg3UFyX0k9E,771,iiy37aKq0pCEIOwfcTh61xb4U,'filter')
				else: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'الجميع ',eCGwzSrqBmIv,775,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,cCZR4YdwUepABD9mQsubT8FgN)
		elif type=='FULL_FILTER':
			HdFJThcNtWe3lb8n4OmaSwQ = Mhd9LWrfiF1EsASl6eP34uTp0qNGom+'&'+cWhMpFIbQU4D1Bi+'=0'
			vvlVH6JT9YDNPeSaRUkKCAwpr5uq = ovh6cXGg1qd85fn3CSJEisTlI7Yz+'&'+cWhMpFIbQU4D1Bi+'=0'
			cCZR4YdwUepABD9mQsubT8FgN = HdFJThcNtWe3lb8n4OmaSwQ+'___'+vvlVH6JT9YDNPeSaRUkKCAwpr5uq
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'الجميع :'+name,eCGwzSrqBmIv,774,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,cCZR4YdwUepABD9mQsubT8FgN)
		dict[cWhMpFIbQU4D1Bi] = {}
		for aasX2cby4Vo5rTgB,KjsA38t0DCSmuLcaE in items:
			if not aasX2cby4Vo5rTgB: continue
			if KjsA38t0DCSmuLcaE in a8GCLIuWNkS: continue
			dict[cWhMpFIbQU4D1Bi][aasX2cby4Vo5rTgB] = KjsA38t0DCSmuLcaE
			HdFJThcNtWe3lb8n4OmaSwQ = Mhd9LWrfiF1EsASl6eP34uTp0qNGom+'&'+cWhMpFIbQU4D1Bi+'='+KjsA38t0DCSmuLcaE
			vvlVH6JT9YDNPeSaRUkKCAwpr5uq = ovh6cXGg1qd85fn3CSJEisTlI7Yz+'&'+cWhMpFIbQU4D1Bi+'='+aasX2cby4Vo5rTgB
			kuyfTIwjRrhXUo = HdFJThcNtWe3lb8n4OmaSwQ+'___'+vvlVH6JT9YDNPeSaRUkKCAwpr5uq
			title = KjsA38t0DCSmuLcaE+' :'#+dict[cWhMpFIbQU4D1Bi]['0']
			title = KjsA38t0DCSmuLcaE+' :'+name
			if type=='FULL_FILTER': bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,url,774,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,kuyfTIwjRrhXUo)
			elif type=='DEFINED_FILTER' and ooTiu86KvMCYBceUV2J9rzLP1qE[-2]+'=' in Mhd9LWrfiF1EsASl6eP34uTp0qNGom:
				bPXk8KHyCUrifag = qJ8NQtuWARGjoZd9swfbH(vvlVH6JT9YDNPeSaRUkKCAwpr5uq,'modified_filters')
				eCGwzSrqBmIv = url+'/smartemadfilter?'+bPXk8KHyCUrifag
				O5Pwg3UFyX0k9E = GyQ7pvCNeFHiPs0U3Dqf(eCGwzSrqBmIv)
				bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,O5Pwg3UFyX0k9E,771,iiy37aKq0pCEIOwfcTh61xb4U,'filter')
			elif type=='DEFINED_FILTER': bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,url,775,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,kuyfTIwjRrhXUo)
	return
def qJ8NQtuWARGjoZd9swfbH(HSAqBpsb2jRLvk9lx147rzY,mode):
	HSAqBpsb2jRLvk9lx147rzY = HSAqBpsb2jRLvk9lx147rzY.replace('=&','=0&')
	HSAqBpsb2jRLvk9lx147rzY = HSAqBpsb2jRLvk9lx147rzY.strip('&')
	x8UiIH3WCTEpe = {}
	if '=' in HSAqBpsb2jRLvk9lx147rzY:
		items = HSAqBpsb2jRLvk9lx147rzY.split('&')
		for YXD9KNfjCaLwkcrvJxldn7I in items:
			xYkDXe5UjvETygJNLrRQ96mtp8BKGW,aasX2cby4Vo5rTgB = YXD9KNfjCaLwkcrvJxldn7I.split('=')
			x8UiIH3WCTEpe[xYkDXe5UjvETygJNLrRQ96mtp8BKGW] = aasX2cby4Vo5rTgB
	QAvGYocVXgzh9 = iiy37aKq0pCEIOwfcTh61xb4U
	for key in PlFdUZ6T2ceunDCGBhiqXyrWwONYx:
		if key in list(x8UiIH3WCTEpe.keys()): aasX2cby4Vo5rTgB = x8UiIH3WCTEpe[key]
		else: aasX2cby4Vo5rTgB = '0'
		if '%' not in aasX2cby4Vo5rTgB: aasX2cby4Vo5rTgB = YqdaDIig21wBTWJeUHbc(aasX2cby4Vo5rTgB)
		if mode=='modified_values' and aasX2cby4Vo5rTgB!='0': QAvGYocVXgzh9 = QAvGYocVXgzh9+' + '+aasX2cby4Vo5rTgB
		elif mode=='modified_filters' and aasX2cby4Vo5rTgB!='0': QAvGYocVXgzh9 = QAvGYocVXgzh9+'&'+key+'='+aasX2cby4Vo5rTgB
		elif mode=='all': QAvGYocVXgzh9 = QAvGYocVXgzh9+'&'+key+'='+aasX2cby4Vo5rTgB
	QAvGYocVXgzh9 = QAvGYocVXgzh9.strip(' + ')
	QAvGYocVXgzh9 = QAvGYocVXgzh9.strip('&')
	QAvGYocVXgzh9 = QAvGYocVXgzh9.replace('=0','=')
	return QAvGYocVXgzh9
# -*- coding: utf-8 -*-
import sys as ytv0YaxDcRINurplWKg587Pwqz
LS5n9Ib81cvhApByQJa6GX4HTf = ytv0YaxDcRINurplWKg587Pwqz.version_info [0] == 2
FVDxSCW5MgK = 2048
o2SVZsYjxd4MPfLCRzv1Ime9XD6rhW = 7
def EnKbMAYoFJ (kc93hiPDm4MqAOaL):
	global BCEn6px5l4
	qR9DalTWtCBVeyYwiQg = ord (kc93hiPDm4MqAOaL [-1])
	SSe8FNopD7MI1EixsPTgl4v3YmfB6 = kc93hiPDm4MqAOaL [:-1]
	T2g7SpExkOcr8NUtfYyMB1d4usRw = qR9DalTWtCBVeyYwiQg % len (SSe8FNopD7MI1EixsPTgl4v3YmfB6)
	fxd3B46829KvYlTG17kUyLNJIbWDp0 = SSe8FNopD7MI1EixsPTgl4v3YmfB6 [:T2g7SpExkOcr8NUtfYyMB1d4usRw] + SSe8FNopD7MI1EixsPTgl4v3YmfB6 [T2g7SpExkOcr8NUtfYyMB1d4usRw:]
	if LS5n9Ib81cvhApByQJa6GX4HTf:
		nXV2GRHyP8dpugjML5sTE4OKN = unicode () .join ([unichr (ord (XXYULyZe1FgwdTVnSx2kHfDAsMClJ9) - FVDxSCW5MgK - (GPf6BlpctR + qR9DalTWtCBVeyYwiQg) % o2SVZsYjxd4MPfLCRzv1Ime9XD6rhW) for GPf6BlpctR, XXYULyZe1FgwdTVnSx2kHfDAsMClJ9 in enumerate (fxd3B46829KvYlTG17kUyLNJIbWDp0)])
	else:
		nXV2GRHyP8dpugjML5sTE4OKN = str () .join ([chr (ord (XXYULyZe1FgwdTVnSx2kHfDAsMClJ9) - FVDxSCW5MgK - (GPf6BlpctR + qR9DalTWtCBVeyYwiQg) % o2SVZsYjxd4MPfLCRzv1Ime9XD6rhW) for GPf6BlpctR, XXYULyZe1FgwdTVnSx2kHfDAsMClJ9 in enumerate (fxd3B46829KvYlTG17kUyLNJIbWDp0)])
	return eval (nXV2GRHyP8dpugjML5sTE4OKN)
hhqd6cnfNJiAaLKTPbst5RpMmZF2G,LyNiIHPOwD3hCUYEFM7,vODxLKW5Ql6r4Fbm8=EnKbMAYoFJ,EnKbMAYoFJ,EnKbMAYoFJ
xpT28sXu051,GGx4qyKP1vUtRghsE2WfaHLMXZ,PtkEvXAqif14G20QZsaSyT=vODxLKW5Ql6r4Fbm8,LyNiIHPOwD3hCUYEFM7,hhqd6cnfNJiAaLKTPbst5RpMmZF2G
SaB5hx3PZwXRLtKgrTfQvId,YzX407G1m8ER9OBpkeuqPIf6Ajrh5,EMO8gy4LrsNTh0knZwpSeU75APW=PtkEvXAqif14G20QZsaSyT,GGx4qyKP1vUtRghsE2WfaHLMXZ,xpT28sXu051
yJeq1BjfiO4NFuwIEzxVLK6b9s,ZchUJdM93pTA7zG5,CCUzMTgQjrHntoiGf16LXW5P8EdVu=EMO8gy4LrsNTh0knZwpSeU75APW,YzX407G1m8ER9OBpkeuqPIf6Ajrh5,SaB5hx3PZwXRLtKgrTfQvId
JZszNnIEMAx28Yao0yqhiXGKOPb,XrTw01KtLzbpoyMf,uuExaKGL7UONtevRd=CCUzMTgQjrHntoiGf16LXW5P8EdVu,ZchUJdM93pTA7zG5,yJeq1BjfiO4NFuwIEzxVLK6b9s
y6y5HtgXO4TkUbwVZ,sVzojQerUqX,tKNPiXfQ7HoAqndw3z9IL4E6VrGv1=uuExaKGL7UONtevRd,XrTw01KtLzbpoyMf,JZszNnIEMAx28Yao0yqhiXGKOPb
AbqCJZdWQP9j,Y41NvKfOroMzGB8sEHy7wbXlc5,hhQwbeiNLoqFjX90fB7aG8VAs=tKNPiXfQ7HoAqndw3z9IL4E6VrGv1,sVzojQerUqX,y6y5HtgXO4TkUbwVZ
IpC4qHXRuyNFjzWv,ppxP0Cg6N3JVELzjGKmkZ2qIlu,L90uqo28xEKSFUwYTcm51yRWZIkft=hhQwbeiNLoqFjX90fB7aG8VAs,Y41NvKfOroMzGB8sEHy7wbXlc5,AbqCJZdWQP9j
FRYcH4KL7e9gv5pEB,tELM0b9FzxuRI4J1CYcie7ZXsHBar,TlGXWLYsV1z=L90uqo28xEKSFUwYTcm51yRWZIkft,ppxP0Cg6N3JVELzjGKmkZ2qIlu,IpC4qHXRuyNFjzWv
ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n,HtK4o2sTPgA78U,zmcGfOdvAjsELeJlP=TlGXWLYsV1z,tELM0b9FzxuRI4J1CYcie7ZXsHBar,FRYcH4KL7e9gv5pEB
UO04GcM7oFd3kJbtKQZHRgI2jeyzCh,MgP8OjoaiWQEVG59,jXE2YHkswT8y=zmcGfOdvAjsELeJlP,HtK4o2sTPgA78U,ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n
from braVAkwfBN import *
sQU2GnRoMwLK8CBdfzmNr4jXyO = YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠫࡈࡒࡅࡂࡐࡈࡖࠬࠀ")
ooQEi5O6tYsGVF8LU0TC3hgMeflBwH = vODxLKW5Ql6r4Fbm8(u"ࠬࡥࡃࡍࡐࡢࠫࠁ")
fP2WMcxU86QG5dCYawVZLn = wkMR5x1gTWEQIc6qHCa.path.join(p2tS61Jv9RBQdgKoZy,sVzojQerUqX(u"࠭ࡴࡦ࡯ࡳࠫࠂ"))
rGU5tFSowIPg4qy = wkMR5x1gTWEQIc6qHCa.path.join(p2tS61Jv9RBQdgKoZy,ZchUJdM93pTA7zG5(u"ࠧࡱࡣࡦ࡯ࡦ࡭ࡥࡴࠩࠃ"))
mhj5soJl0bi62TXEWcr = wkMR5x1gTWEQIc6qHCa.path.join(Hyw4UJ6ephu,AbqCJZdWQP9j(u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪࠄ"),xpT28sXu051(u"ࠩࡗ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡸ࠭ࠅ"))
zbtkf4hOWMyXr = Z5ng8awdRcW39U0kvbGm
tCOTD2GEqJNynx = tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠪ࠳ࡩࡧࡴࡢ࠱ࡶࡽࡸࡺࡥ࡮࠱ࡸࡷࡦ࡭ࡥࡴࡶࡤࡸࡸ࠭ࠆ")
i3SzxVmp2nfR9hBs7ON0ZrWTGLJXgy = vODxLKW5Ql6r4Fbm8(u"ࠫ࠴ࡪࡡࡵࡣ࠲ࡷࡾࡹࡴࡦ࡯࠲ࡨࡷࡵࡰࡣࡱࡻࠫࠇ")
YDzfVdQnPUqLE0rF4NhCt = MgP8OjoaiWQEVG59(u"ࠬ࠵ࡤࡢࡶࡤ࠳ࡹࡵ࡭ࡣࡵࡷࡳࡳ࡫ࡳࠨࠈ")
s0DIfkpFYRPLolenHm4JMUvBGy = uuExaKGL7UONtevRd(u"࠭࠯ࡥࡣࡷࡥ࠴ࡲ࡯ࡨࡩࡨࡶࠬࠉ")
C5J8bQzF9BsXlWa4n = XrTw01KtLzbpoyMf(u"ࠧ࠰ࡦࡤࡸࡦ࠵࡬ࡰࡩࠪࠊ")
vWh0CHJ5Po = uuExaKGL7UONtevRd(u"ࠨ࠱ࡧࡥࡹࡧ࠯ࡢࡰࡵࠫࠋ")
def sHVM8YchrDjZAJ7(Cpf9s3c0Zngj7XE):
	if   Cpf9s3c0Zngj7XE==EMO8gy4LrsNTh0knZwpSeU75APW(u"࠼࠺࠰ࡸ"): EA7FzO1kMZGQXDd2giB0cwLom = wlyZqVhEndAT4rxNjJk1UpsO()
	elif Cpf9s3c0Zngj7XE==yJeq1BjfiO4NFuwIEzxVLK6b9s(u"࠽࠴࠲ࡹ"): EA7FzO1kMZGQXDd2giB0cwLom = TAkeulImazNdJwE9(fP2WMcxU86QG5dCYawVZLn,rGPen6cSMHQkAywh8vqI9JXiD2,rGPen6cSMHQkAywh8vqI9JXiD2)
	elif Cpf9s3c0Zngj7XE==yJeq1BjfiO4NFuwIEzxVLK6b9s(u"࠷࠵࠴ࡺ"): EA7FzO1kMZGQXDd2giB0cwLom = TAkeulImazNdJwE9(rGU5tFSowIPg4qy,rGPen6cSMHQkAywh8vqI9JXiD2,rGPen6cSMHQkAywh8vqI9JXiD2)
	elif Cpf9s3c0Zngj7XE==hhQwbeiNLoqFjX90fB7aG8VAs(u"࠸࠶࠶ࡻ"): EA7FzO1kMZGQXDd2giB0cwLom = TAkeulImazNdJwE9(mhj5soJl0bi62TXEWcr,BF6QAiLUNHh7rKOugaw,rGPen6cSMHQkAywh8vqI9JXiD2)
	elif Cpf9s3c0Zngj7XE==ZchUJdM93pTA7zG5(u"࠹࠷࠸ࡼ"): EA7FzO1kMZGQXDd2giB0cwLom = K45GEw7LsyrRUbaHYn9c(zbtkf4hOWMyXr,rGPen6cSMHQkAywh8vqI9JXiD2)
	elif Cpf9s3c0Zngj7XE==TlGXWLYsV1z(u"࠺࠸࠺ࡽ"): EA7FzO1kMZGQXDd2giB0cwLom = ZLODSnClHQe4o3vEbkBamxATij(rGPen6cSMHQkAywh8vqI9JXiD2)
	elif Cpf9s3c0Zngj7XE==y6y5HtgXO4TkUbwVZ(u"࠻࠺࠶ࡾ"): EA7FzO1kMZGQXDd2giB0cwLom = bZksFW4gtKiQEXIwC6zjnH1qJYLfur()
	elif Cpf9s3c0Zngj7XE==ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"࠼࠻࠱ࡿ"): EA7FzO1kMZGQXDd2giB0cwLom = TAkeulImazNdJwE9(tCOTD2GEqJNynx,BF6QAiLUNHh7rKOugaw,rGPen6cSMHQkAywh8vqI9JXiD2)
	elif Cpf9s3c0Zngj7XE==tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"࠽࠵࠳ࢀ"): EA7FzO1kMZGQXDd2giB0cwLom = TAkeulImazNdJwE9(i3SzxVmp2nfR9hBs7ON0ZrWTGLJXgy,BF6QAiLUNHh7rKOugaw,rGPen6cSMHQkAywh8vqI9JXiD2)
	elif Cpf9s3c0Zngj7XE==SaB5hx3PZwXRLtKgrTfQvId(u"࠷࠶࠵ࢁ"): EA7FzO1kMZGQXDd2giB0cwLom = TAkeulImazNdJwE9(YDzfVdQnPUqLE0rF4NhCt,BF6QAiLUNHh7rKOugaw,rGPen6cSMHQkAywh8vqI9JXiD2)
	elif Cpf9s3c0Zngj7XE==uuExaKGL7UONtevRd(u"࠸࠷࠷ࢂ"): EA7FzO1kMZGQXDd2giB0cwLom = TAkeulImazNdJwE9(s0DIfkpFYRPLolenHm4JMUvBGy,BF6QAiLUNHh7rKOugaw,rGPen6cSMHQkAywh8vqI9JXiD2)
	elif Cpf9s3c0Zngj7XE==tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"࠹࠸࠹ࢃ"): EA7FzO1kMZGQXDd2giB0cwLom = TAkeulImazNdJwE9(C5J8bQzF9BsXlWa4n,BF6QAiLUNHh7rKOugaw,rGPen6cSMHQkAywh8vqI9JXiD2)
	elif Cpf9s3c0Zngj7XE==zmcGfOdvAjsELeJlP(u"࠺࠹࠻ࢄ"): EA7FzO1kMZGQXDd2giB0cwLom = TAkeulImazNdJwE9(vWh0CHJ5Po,BF6QAiLUNHh7rKOugaw,rGPen6cSMHQkAywh8vqI9JXiD2)
	elif Cpf9s3c0Zngj7XE==UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"࠻࠺࠽ࢅ"): EA7FzO1kMZGQXDd2giB0cwLom = F9FEzVAfSh(rGPen6cSMHQkAywh8vqI9JXiD2)
	elif Cpf9s3c0Zngj7XE==TlGXWLYsV1z(u"࠼࠻࠸ࢆ"): EA7FzO1kMZGQXDd2giB0cwLom = S7XLNBwMeC()
	else: EA7FzO1kMZGQXDd2giB0cwLom = BF6QAiLUNHh7rKOugaw
	return EA7FzO1kMZGQXDd2giB0cwLom
def wlyZqVhEndAT4rxNjJk1UpsO():
	Qoqu9UxivsIMWzrH4cKD1YtEj3gl,GMKDTSAOotn = LrGaYW8iA4(fP2WMcxU86QG5dCYawVZLn)
	IUS6hd0wNnu,F0y3qCcUePuQiGDm = LrGaYW8iA4(rGU5tFSowIPg4qy)
	MuFpcrInEwP,UU1TipWomO8FMx9qblDy4wNSIg = LrGaYW8iA4(mhj5soJl0bi62TXEWcr)
	uW7XyiB5DVoQSa14TcPpJqhxg0nA,nweK9NrtqF4ckoIO0V7 = MZ0QpfA1jaJgoWO2IndU(zbtkf4hOWMyXr)
	uW7XyiB5DVoQSa14TcPpJqhxg0nA -= XrTw01KtLzbpoyMf(u"࠹࠶࠹࠸࠷ࢇ")
	nweK9NrtqF4ckoIO0V7 -= zmcGfOdvAjsELeJlP(u"࠱࢈")
	RPuJUkO5cbLgl2Awj = HtK4o2sTPgA78U(u"ࠩࠣࠬࠬࠌ")+slfhz6b12HOMSL4aXoC(Qoqu9UxivsIMWzrH4cKD1YtEj3gl)+zmcGfOdvAjsELeJlP(u"ࠪࠤ࠲ࠦࠧࠍ")+str(GMKDTSAOotn)+SaB5hx3PZwXRLtKgrTfQvId(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬࠎ")
	AkLKwEuog3O8JDFlt6nGiN19aec0p = CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠬࠦࠨࠨࠏ")+slfhz6b12HOMSL4aXoC(IUS6hd0wNnu)+FRYcH4KL7e9gv5pEB(u"࠭ࠠ࠮ࠢࠪࠐ")+str(F0y3qCcUePuQiGDm)+AbqCJZdWQP9j(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨࠑ")
	XDowxf3YTQlGnJFgbuqdVIz94 = SaB5hx3PZwXRLtKgrTfQvId(u"ࠨࠢࠫࠫࠒ")+slfhz6b12HOMSL4aXoC(MuFpcrInEwP)+hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠩࠣ࠱ࠥ࠭ࠓ")+str(UU1TipWomO8FMx9qblDy4wNSIg)+FRYcH4KL7e9gv5pEB(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࠔ")
	KKpIvETkbG8weQqnZli6c = yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠫࠥ࠮ࠧࠕ")+slfhz6b12HOMSL4aXoC(uW7XyiB5DVoQSa14TcPpJqhxg0nA)+EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠬ࠯ࠧࠖ")
	Sa5KHnedsPDEYAFlJZtVR4MyUIOLC = Qoqu9UxivsIMWzrH4cKD1YtEj3gl+IUS6hd0wNnu+MuFpcrInEwP+uW7XyiB5DVoQSa14TcPpJqhxg0nA
	vfqn7zT9oweJ = GMKDTSAOotn+F0y3qCcUePuQiGDm+UU1TipWomO8FMx9qblDy4wNSIg+nweK9NrtqF4ckoIO0V7
	U94JwhRgpXCOe5 = ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"࠭ࠠࠩࠩࠗ")+slfhz6b12HOMSL4aXoC(Sa5KHnedsPDEYAFlJZtVR4MyUIOLC)+UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠧࠡ࠯ࠣࠫ࠘")+str(vfqn7zT9oweJ)+L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩ࠙")
	bP6z3OSLp7va(Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠩ࡯࡭ࡳࡱࠧࠚ"),ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ุ้ࠪำࠠศๆฯ้๏฿ࠧࠛ")+U94JwhRgpXCOe5,iiy37aKq0pCEIOwfcTh61xb4U,Y41NvKfOroMzGB8sEHy7wbXlc5(u"࠸࠶࠸ࢉ"))
	bP6z3OSLp7va(AbqCJZdWQP9j(u"ࠫࡱ࡯࡮࡬ࠩࠜ"),PSwfZcdRYhpl5Igqz8xOEk67+Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠬࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫࠝ")+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,Y41NvKfOroMzGB8sEHy7wbXlc5(u"࠻࠼࠽࠾ࢊ"))
	bP6z3OSLp7va(GGx4qyKP1vUtRghsE2WfaHLMXZ(u"࠭࡬ࡪࡰ࡮ࠫࠞ"),ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+MgP8OjoaiWQEVG59(u"ࠧๆีะࠤฬ๊ๅๅใสฮࠥอไๆฦๅฮฮ࠭ࠟ")+RPuJUkO5cbLgl2Awj,iiy37aKq0pCEIOwfcTh61xb4U,JZszNnIEMAx28Yao0yqhiXGKOPb(u"࠺࠸࠶ࢋ"))
	bP6z3OSLp7va(tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠨ࡮࡬ࡲࡰ࠭ࠠ"),ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+sVzojQerUqX(u"่ࠩืาࠦวๅ็็ๅฬะࠠศๆฺ่฿๎ืสࠩࠡ")+AkLKwEuog3O8JDFlt6nGiN19aec0p,iiy37aKq0pCEIOwfcTh61xb4U,JZszNnIEMAx28Yao0yqhiXGKOPb(u"࠻࠹࠸ࢌ"))
	bP6z3OSLp7va(sVzojQerUqX(u"ࠪࡰ࡮ࡴ࡫ࠨࠢ"),ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+Y41NvKfOroMzGB8sEHy7wbXlc5(u"ู๊ࠫอࠡษ็ูํืࠠศๆๅำ๏๋ษࠨࠣ")+XDowxf3YTQlGnJFgbuqdVIz94,iiy37aKq0pCEIOwfcTh61xb4U,vODxLKW5Ql6r4Fbm8(u"࠼࠺࠳ࢍ"))
	bP6z3OSLp7va(y6y5HtgXO4TkUbwVZ(u"ࠬࡲࡩ࡯࡭ࠪࠤ"),ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"࠭สโำํ฾๋ࠥไโุࠢ์ึࠦวๅวูหๆอสࠨࠥ")+KKpIvETkbG8weQqnZli6c,iiy37aKq0pCEIOwfcTh61xb4U,GGx4qyKP1vUtRghsE2WfaHLMXZ(u"࠽࠴࠵ࢎ"))
	OXsckY7RzjCag9A.setSetting(XrTw01KtLzbpoyMf(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡶࡪ࡬ࡲࡦࡵ࡫ࠫࠦ"),iiy37aKq0pCEIOwfcTh61xb4U)
	return
def bZksFW4gtKiQEXIwC6zjnH1qJYLfur():
	FNdolhtxP1u0X9JV = rGPen6cSMHQkAywh8vqI9JXiD2 if tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠨ࠱ࠪࠧ") in Hyw4UJ6ephu else BF6QAiLUNHh7rKOugaw
	if not FNdolhtxP1u0X9JV:
		bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬࠨ"),vODxLKW5Ql6r4Fbm8(u"ࠪ฽๊๊๊สࠢอ๊฽๐แࠡษ็ะ์อาࠡ็อ์ๆืษࠡใๅ฻๊ࠥรอ้ีอࠥ๐่็ๅึࠤ࠳࠴้ࠠฮ๊หื้ࠠๅ์ึࠤ๊์ࠠ็๊฼ࠤ๏๎ๆไีࠪࠩ"))
		return
	zCXZNsp6PT8Mhxnr5v0G71KaBdFR = OXsckY7RzjCag9A.getSetting(sVzojQerUqX(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡳࡧࡩࡶࡪࡹࡨࠨࠪ"))
	if not zCXZNsp6PT8Mhxnr5v0G71KaBdFR: S7XLNBwMeC()
	Qoqu9UxivsIMWzrH4cKD1YtEj3gl,GMKDTSAOotn = LrGaYW8iA4(tCOTD2GEqJNynx)
	IUS6hd0wNnu,F0y3qCcUePuQiGDm = LrGaYW8iA4(i3SzxVmp2nfR9hBs7ON0ZrWTGLJXgy)
	MuFpcrInEwP,UU1TipWomO8FMx9qblDy4wNSIg = LrGaYW8iA4(YDzfVdQnPUqLE0rF4NhCt)
	uW7XyiB5DVoQSa14TcPpJqhxg0nA,nweK9NrtqF4ckoIO0V7 = LrGaYW8iA4(s0DIfkpFYRPLolenHm4JMUvBGy)
	M5MnNI4x8ohU3HPJq0Xd2i6ZsAyVe7,aZLh6HdBYK5JyT8ARigVC = LrGaYW8iA4(C5J8bQzF9BsXlWa4n)
	TF7CWxSl6nAwvN,ETog2HlaqN5YcMyu = LrGaYW8iA4(vWh0CHJ5Po)
	RPuJUkO5cbLgl2Awj = vODxLKW5Ql6r4Fbm8(u"ࠬࠦࠨࠨࠫ")+slfhz6b12HOMSL4aXoC(Qoqu9UxivsIMWzrH4cKD1YtEj3gl)+hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"࠭ࠠ࠮ࠢࠪࠬ")+str(GMKDTSAOotn)+CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨ࠭")
	AkLKwEuog3O8JDFlt6nGiN19aec0p = IpC4qHXRuyNFjzWv(u"ࠨࠢࠫࠫ࠮")+slfhz6b12HOMSL4aXoC(IUS6hd0wNnu)+LyNiIHPOwD3hCUYEFM7(u"ࠩࠣ࠱ࠥ࠭࠯")+str(F0y3qCcUePuQiGDm)+uuExaKGL7UONtevRd(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫ࠰")
	XDowxf3YTQlGnJFgbuqdVIz94 = ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠫࠥ࠮ࠧ࠱")+slfhz6b12HOMSL4aXoC(MuFpcrInEwP)+SaB5hx3PZwXRLtKgrTfQvId(u"ࠬࠦ࠭ࠡࠩ࠲")+str(UU1TipWomO8FMx9qblDy4wNSIg)+tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧ࠳")
	KKpIvETkbG8weQqnZli6c = hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠧࠡࠪࠪ࠴")+slfhz6b12HOMSL4aXoC(uW7XyiB5DVoQSa14TcPpJqhxg0nA)+UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠨࠢ࠰ࠤࠬ࠵")+str(nweK9NrtqF4ckoIO0V7)+hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠩࠣࡪ࡮ࡲࡥࡴࠫࠪ࠶")
	RnBKyj0spEkPHS = xpT28sXu051(u"ࠪࠤ࠭࠭࠷")+slfhz6b12HOMSL4aXoC(M5MnNI4x8ohU3HPJq0Xd2i6ZsAyVe7)+tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠫࠥ࠳ࠠࠨ࠸")+str(aZLh6HdBYK5JyT8ARigVC)+yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠬࠦࡦࡪ࡮ࡨࡷ࠮࠭࠹")
	dLkuwbCB7tavMe5T18xrV = sVzojQerUqX(u"࠭ࠠࠩࠩ࠺")+slfhz6b12HOMSL4aXoC(TF7CWxSl6nAwvN)+ZchUJdM93pTA7zG5(u"ࠧࠡ࠯ࠣࠫ࠻")+str(ETog2HlaqN5YcMyu)+zmcGfOdvAjsELeJlP(u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩ࠼")
	Sa5KHnedsPDEYAFlJZtVR4MyUIOLC = Qoqu9UxivsIMWzrH4cKD1YtEj3gl+IUS6hd0wNnu+MuFpcrInEwP+uW7XyiB5DVoQSa14TcPpJqhxg0nA+M5MnNI4x8ohU3HPJq0Xd2i6ZsAyVe7+TF7CWxSl6nAwvN
	vfqn7zT9oweJ = GMKDTSAOotn+F0y3qCcUePuQiGDm+UU1TipWomO8FMx9qblDy4wNSIg+nweK9NrtqF4ckoIO0V7+aZLh6HdBYK5JyT8ARigVC+ETog2HlaqN5YcMyu
	U94JwhRgpXCOe5 = tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠩࠣࠬࠬ࠽")+slfhz6b12HOMSL4aXoC(Sa5KHnedsPDEYAFlJZtVR4MyUIOLC)+HtK4o2sTPgA78U(u"ࠪࠤ࠲ࠦࠧ࠾")+str(vfqn7zT9oweJ)+sVzojQerUqX(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬ࠿")
	bP6z3OSLp7va(AbqCJZdWQP9j(u"ࠬࡲࡩ࡯࡭ࠪࡀ"),ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+LyNiIHPOwD3hCUYEFM7(u"࠭ลฺูสลࠥืฮึหࠣๆึอมส๋ࠢ็ฯอศสࠩࡁ"),iiy37aKq0pCEIOwfcTh61xb4U,EMO8gy4LrsNTh0knZwpSeU75APW(u"࠷࠶࠺࢏"))
	bP6z3OSLp7va(FRYcH4KL7e9gv5pEB(u"ࠧ࡭࡫ࡱ࡯ࠬࡂ"),ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+uuExaKGL7UONtevRd(u"ࠨ็ึัࠥอไอ็ํ฽ࠬࡃ")+U94JwhRgpXCOe5,iiy37aKq0pCEIOwfcTh61xb4U,GGx4qyKP1vUtRghsE2WfaHLMXZ(u"࠸࠷࠺࢐"))
	bP6z3OSLp7va(xpT28sXu051(u"ࠩ࡯࡭ࡳࡱࠧࡄ"),PSwfZcdRYhpl5Igqz8xOEk67+LyNiIHPOwD3hCUYEFM7(u"ࠪࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡࠩࡅ")+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"࠻࠼࠽࠾࢑"))
	bP6z3OSLp7va(FRYcH4KL7e9gv5pEB(u"ࠫࡱ࡯࡮࡬ࠩࡆ"),ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+yJeq1BjfiO4NFuwIEzxVLK6b9s(u"๋ࠬำฮ่่ࠢๆอสࠡࡷࡶࡥ࡬࡫ࡳࡵࡣࡷࡷࠬࡇ")+RPuJUkO5cbLgl2Awj,iiy37aKq0pCEIOwfcTh61xb4U,IpC4qHXRuyNFjzWv(u"࠺࠹࠶࢒"))
	bP6z3OSLp7va(YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"࠭࡬ࡪࡰ࡮ࠫࡈ"),ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠧๆีะࠤ๊๊แศฬࠣࡨࡷࡵࡰࡣࡱࡻࠫࡉ")+AkLKwEuog3O8JDFlt6nGiN19aec0p,iiy37aKq0pCEIOwfcTh61xb4U,GGx4qyKP1vUtRghsE2WfaHLMXZ(u"࠻࠺࠸࢓"))
	bP6z3OSLp7va(YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠨ࡮࡬ࡲࡰ࠭ࡊ"),ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"่ࠩืาࠦๅๅใสฮࠥࡺ࡯࡮ࡤࡶࡸࡴࡴࡥࡴࠩࡋ")+XDowxf3YTQlGnJFgbuqdVIz94,iiy37aKq0pCEIOwfcTh61xb4U,PtkEvXAqif14G20QZsaSyT(u"࠼࠻࠳࢔"))
	bP6z3OSLp7va(EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠪࡰ࡮ࡴ࡫ࠨࡌ"),ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+MgP8OjoaiWQEVG59(u"ู๊ࠫอࠡ็็ๅฬะࠠ࡭ࡱࡪ࡫ࡪࡸࠧࡍ")+KKpIvETkbG8weQqnZli6c,iiy37aKq0pCEIOwfcTh61xb4U,xpT28sXu051(u"࠽࠵࠵࢕"))
	bP6z3OSLp7va(L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠬࡲࡩ࡯࡭ࠪࡎ"),ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+EMO8gy4LrsNTh0knZwpSeU75APW(u"࠭ๅิฯ้้ࠣ็วหࠢ࡯ࡳ࡬࠭ࡏ")+RnBKyj0spEkPHS,iiy37aKq0pCEIOwfcTh61xb4U,y6y5HtgXO4TkUbwVZ(u"࠷࠶࠷࢖"))
	bP6z3OSLp7va(AbqCJZdWQP9j(u"ࠧ࡭࡫ࡱ࡯ࠬࡐ"),ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠨ็ึั๋ࠥไโษอࠤࡦࡴࡲࠨࡑ")+dLkuwbCB7tavMe5T18xrV,iiy37aKq0pCEIOwfcTh61xb4U,LyNiIHPOwD3hCUYEFM7(u"࠸࠷࠹ࢗ"))
	OXsckY7RzjCag9A.setSetting(FRYcH4KL7e9gv5pEB(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡸࡥࡧࡴࡨࡷ࡭࠭ࡒ"),iiy37aKq0pCEIOwfcTh61xb4U)
	return
def S7XLNBwMeC():
	U17QqF2gkI46 = A1AXKupEOfz(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ࡓ"),yJeq1BjfiO4NFuwIEzxVLK6b9s(u"้้๊ࠫࠡ์฼้้ࠦวๅฬ้฼๏็ฺ่ࠠา็ࠥ࠴࠮ࠡสิ๊ฬ๋ฬࠡ฻่หิࠦศฮษฯอࠥหไ๊ࠢศ฽฼อมࠡำัูฮࠦวๅไิหฦฯ้ࠠษ็็ฯอศสࠢ็่๊๊แศฬࠣ์ฬ๊ๅอๆาหฯࠦวๅฬํࠤุ๎แࠡ์่ืาํวࠡษ็ฬึ์วๆฮࠣ࠲࠳ࠦ็ๅࠢอี๏ีࠠฦ฻ฺหฦࠦ็ั้ࠣห้ืฮึหࠣห้ศๆࠡมࠤࠫࡔ"))
	if U17QqF2gkI46==-EMO8gy4LrsNTh0knZwpSeU75APW(u"࠳࢘"): return
	if U17QqF2gkI46:
		import subprocess as AfJFuoBEkn8h0iGbZ1sQ7MKl
		try:
			AfJFuoBEkn8h0iGbZ1sQ7MKl.Popen(ZchUJdM93pTA7zG5(u"ࠬࡹࡵࠨࡕ"))
			ArlGzEh9s7KYLxqvmT4JfuDg = rGPen6cSMHQkAywh8vqI9JXiD2
		except: ArlGzEh9s7KYLxqvmT4JfuDg = BF6QAiLUNHh7rKOugaw
		if ArlGzEh9s7KYLxqvmT4JfuDg:
			nzp1lEZrucdwjOCtDMbHIAK2xYSoLT = tCOTD2GEqJNynx+iFBmE2MUIpSu34wsd7Rf6z+i3SzxVmp2nfR9hBs7ON0ZrWTGLJXgy+iFBmE2MUIpSu34wsd7Rf6z+YDzfVdQnPUqLE0rF4NhCt+iFBmE2MUIpSu34wsd7Rf6z+s0DIfkpFYRPLolenHm4JMUvBGy+iFBmE2MUIpSu34wsd7Rf6z+C5J8bQzF9BsXlWa4n+iFBmE2MUIpSu34wsd7Rf6z+vWh0CHJ5Po
			y5064y8gp1X7 = AfJFuoBEkn8h0iGbZ1sQ7MKl.Popen(Y41NvKfOroMzGB8sEHy7wbXlc5(u"࠭ࡳࡶࠢ࠰ࡧࠥࠨࡣࡩ࡯ࡲࡨࠥ࠳ࡒࠡ࠲࠺࠻࠼ࠦࠧࡖ")+nzp1lEZrucdwjOCtDMbHIAK2xYSoLT+IpC4qHXRuyNFjzWv(u"ࠧࠣࠩࡗ"),shell=rGPen6cSMHQkAywh8vqI9JXiD2,stdin=AfJFuoBEkn8h0iGbZ1sQ7MKl.PIPE,stdout=AfJFuoBEkn8h0iGbZ1sQ7MKl.PIPE,stderr=AfJFuoBEkn8h0iGbZ1sQ7MKl.PIPE)
			bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫࡘ"),AbqCJZdWQP9j(u"้ࠩะาะฺࠠ็็๎ฮࠦลฺูสลࠥอไาะุอ࡙ࠬ"))
			SqMHwb6X1Ph8jY7LBNkmtV4F5Jlspy(BF6QAiLUNHh7rKOugaw)
		else: bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,MgP8OjoaiWQEVG59(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࡚࠭"),y6y5HtgXO4TkUbwVZ(u"ࠫ฾๋ไ๋หࠣษ฾฽วยࠢิาฺฯࠠศๆๅีฬวษ๊ࠡส่่ะวษหࠣฮาะวอࠢหี๋อๅอࠢࠣࡶࡴࡵࡴࠡࠢฦ์ࠥࠦࡳࡶࡲࡨࡶࡺࡹࡥࡳࠢࠣวํࠦࠠࡴࡷࠣࠤํา็ศิๆࠤ้อ๋๊ࠠฯำࠥ็๊่๊ࠢิฬࠦวๅสิ๊ฬ๋ฬࠡ࠰࠱ࠤศ๎ࠠไ๊า๎ࠥเ๊าࠢๅหิืฺࠠๆ์ࠤฬูสฯัส้ࠥํะศࠢส่อืๆศ็ฯ࡛ࠫ"))
	return
def slfhz6b12HOMSL4aXoC(Sa5KHnedsPDEYAFlJZtVR4MyUIOLC):
	for noUVir5wOMbjdfKH1RCxIYhSPAqTWu in [ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠬࡈࠧ࡜"),UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"࠭ࡋࡃࠩ࡝"),ZchUJdM93pTA7zG5(u"ࠧࡎࡄࠪ࡞"),hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠨࡉࡅࠫ࡟"),uuExaKGL7UONtevRd(u"ࠩࡗࡆࠬࡠ")]:
		if Sa5KHnedsPDEYAFlJZtVR4MyUIOLC<Y41NvKfOroMzGB8sEHy7wbXlc5(u"࠴࠴࠷࠺࢙"): break
		else: Sa5KHnedsPDEYAFlJZtVR4MyUIOLC /= jXE2YHkswT8y(u"࠵࠵࠸࠴࠯࠲࢚")
	U94JwhRgpXCOe5 = Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠥࠩ࠸࠴࠱ࡧࠢࠨࡷࠧࡡ")%(Sa5KHnedsPDEYAFlJZtVR4MyUIOLC,noUVir5wOMbjdfKH1RCxIYhSPAqTWu)
	return U94JwhRgpXCOe5
def LrGaYW8iA4(g3iACn6KjfQo9maRMS=IpC4qHXRuyNFjzWv(u"ࠫ࠳࠭ࡢ")):
	global bb2Y9wKa3T1NEyifWg0o4eLmQ,c23rFPJHZ0TopsNxYWSv
	bb2Y9wKa3T1NEyifWg0o4eLmQ,c23rFPJHZ0TopsNxYWSv = HtK4o2sTPgA78U(u"࠵࢛"),HtK4o2sTPgA78U(u"࠵࢛")
	def tdfRjcT19570ub(g3iACn6KjfQo9maRMS):
		global bb2Y9wKa3T1NEyifWg0o4eLmQ,c23rFPJHZ0TopsNxYWSv
		if wkMR5x1gTWEQIc6qHCa.path.exists(g3iACn6KjfQo9maRMS):
			if JZszNnIEMAx28Yao0yqhiXGKOPb(u"࠶࢜") and uuExaKGL7UONtevRd(u"ࠬࡹࡣࡢࡰࡧ࡭ࡷ࠭ࡣ") in dir(wkMR5x1gTWEQIc6qHCa):
				for daEbwZTAtY in wkMR5x1gTWEQIc6qHCa.scandir(g3iACn6KjfQo9maRMS):
					if daEbwZTAtY.is_dir(follow_symlinks=BF6QAiLUNHh7rKOugaw):
						tdfRjcT19570ub(daEbwZTAtY.path)
					elif daEbwZTAtY.is_file(follow_symlinks=BF6QAiLUNHh7rKOugaw):
						bb2Y9wKa3T1NEyifWg0o4eLmQ += daEbwZTAtY.stat().st_size
						c23rFPJHZ0TopsNxYWSv += ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"࠱࢝")
			else:
				for daEbwZTAtY in wkMR5x1gTWEQIc6qHCa.listdir(g3iACn6KjfQo9maRMS):
					b62Op4ACWa1DufrTU5dL7hz = wkMR5x1gTWEQIc6qHCa.path.abspath(wkMR5x1gTWEQIc6qHCa.path.join(g3iACn6KjfQo9maRMS,daEbwZTAtY))
					if wkMR5x1gTWEQIc6qHCa.path.isdir(b62Op4ACWa1DufrTU5dL7hz):
						tdfRjcT19570ub(b62Op4ACWa1DufrTU5dL7hz)
					elif wkMR5x1gTWEQIc6qHCa.path.isfile(b62Op4ACWa1DufrTU5dL7hz):
						Sa5KHnedsPDEYAFlJZtVR4MyUIOLC,vfqn7zT9oweJ = MZ0QpfA1jaJgoWO2IndU(b62Op4ACWa1DufrTU5dL7hz)
						bb2Y9wKa3T1NEyifWg0o4eLmQ += Sa5KHnedsPDEYAFlJZtVR4MyUIOLC
						c23rFPJHZ0TopsNxYWSv += vfqn7zT9oweJ
		return
	try: tdfRjcT19570ub(g3iACn6KjfQo9maRMS)
	except: pass
	return bb2Y9wKa3T1NEyifWg0o4eLmQ,c23rFPJHZ0TopsNxYWSv
def ZLODSnClHQe4o3vEbkBamxATij(showDialogs):
	if showDialogs:
		U17QqF2gkI46 = A1AXKupEOfz(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩࡤ"),PSwfZcdRYhpl5Igqz8xOEk67+LyNiIHPOwD3hCUYEFM7(u"่ࠧๆࠣฮึ๐ฯࠡ็ึัࠬࡥ")+OTlVEGYPSxsNaBdXUucqA3+hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠨ็ฯ่ิࠦวๅ็็ๅฬะࠠศๆ่ศ็ะษࠡ࠰࠱ࠤํ๋ฬๅัࠣห้๋ไโษอࠤฬ๊ๅื฼๋฻ฮࠦ࠮࠯๋้ࠢั๊ฯࠡษ็ูํืࠠศๆๅำ๏๋ษࠡ࠰࠱ࠤํะแา์฽ࠤ๊๊แࠡื๋ีࠥอไฦุสๅฬะࠧࡦ")+OTlVEGYPSxsNaBdXUucqA3+HtK4o2sTPgA78U(u"ࠩยࠥࠦ࠭ࡧ")+YoQW601K4fMJcsreDnGVE5wUZIy7)
		if U17QqF2gkI46!=yJeq1BjfiO4NFuwIEzxVLK6b9s(u"࠲࢞"): return
	TAkeulImazNdJwE9(fP2WMcxU86QG5dCYawVZLn,rGPen6cSMHQkAywh8vqI9JXiD2,BF6QAiLUNHh7rKOugaw)
	TAkeulImazNdJwE9(rGU5tFSowIPg4qy,rGPen6cSMHQkAywh8vqI9JXiD2,BF6QAiLUNHh7rKOugaw)
	TAkeulImazNdJwE9(mhj5soJl0bi62TXEWcr,BF6QAiLUNHh7rKOugaw,BF6QAiLUNHh7rKOugaw)
	K45GEw7LsyrRUbaHYn9c(zbtkf4hOWMyXr,BF6QAiLUNHh7rKOugaw)
	if showDialogs:
		bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ࡨ"),vODxLKW5Ql6r4Fbm8(u"ࠫฯ๋ࠠศๆ่ืาࠦศ็ฮสัࠬࡩ"))
		SqMHwb6X1Ph8jY7LBNkmtV4F5Jlspy(BF6QAiLUNHh7rKOugaw)
	return
def F9FEzVAfSh(showDialogs):
	if showDialogs:
		U17QqF2gkI46 = A1AXKupEOfz(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,LyNiIHPOwD3hCUYEFM7(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨࡪ"),PSwfZcdRYhpl5Igqz8xOEk67+zmcGfOdvAjsELeJlP(u"࠭็ๅࠢอี๏ีࠠๆีะࠤ๊๊แศฬࠪ࡫")+OTlVEGYPSxsNaBdXUucqA3+ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠧࡶࡵࡤ࡫ࡪࡹࡴࡢࡶࡶࠤ࠳࠴ࠠࡥࡴࡲࡴࡧࡵࡸࠡ࠰࠱ࠤࡹࡵ࡭ࡣࡵࡷࡳࡳ࡫ࡳࠡ࠰࠱ࠤࡱࡵࡧࡨࡧࡵࠤ࠳࠴ࠠ࡭ࡱࡪࠤ࠳࠴ࠠࡢࡰࡵࠫ࡬")+OTlVEGYPSxsNaBdXUucqA3+AbqCJZdWQP9j(u"ࠨࡁࠤࠥࠬ࡭")+YoQW601K4fMJcsreDnGVE5wUZIy7)
		if U17QqF2gkI46!=L90uqo28xEKSFUwYTcm51yRWZIkft(u"࠳࢟"): return
	TAkeulImazNdJwE9(tCOTD2GEqJNynx,BF6QAiLUNHh7rKOugaw,BF6QAiLUNHh7rKOugaw)
	TAkeulImazNdJwE9(i3SzxVmp2nfR9hBs7ON0ZrWTGLJXgy,BF6QAiLUNHh7rKOugaw,BF6QAiLUNHh7rKOugaw)
	TAkeulImazNdJwE9(YDzfVdQnPUqLE0rF4NhCt,BF6QAiLUNHh7rKOugaw,BF6QAiLUNHh7rKOugaw)
	TAkeulImazNdJwE9(s0DIfkpFYRPLolenHm4JMUvBGy,BF6QAiLUNHh7rKOugaw,BF6QAiLUNHh7rKOugaw)
	TAkeulImazNdJwE9(C5J8bQzF9BsXlWa4n,BF6QAiLUNHh7rKOugaw,BF6QAiLUNHh7rKOugaw)
	TAkeulImazNdJwE9(vWh0CHJ5Po,BF6QAiLUNHh7rKOugaw,BF6QAiLUNHh7rKOugaw)
	if showDialogs:
		bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ࡮"),tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠪฮ๊ࠦวๅ็ึัࠥฮๆอษะࠫ࡯"))
		SqMHwb6X1Ph8jY7LBNkmtV4F5Jlspy(BF6QAiLUNHh7rKOugaw)
	return
def K45GEw7LsyrRUbaHYn9c(qfznVTCRpxSDM85QGBHoU,showDialogs):
	if showDialogs:
		U17QqF2gkI46 = A1AXKupEOfz(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧࡰ"),PSwfZcdRYhpl5Igqz8xOEk67+LyNiIHPOwD3hCUYEFM7(u"ࠬํไࠡฬิ๎ิࠦๅิฯ้ࠣาะ่๋ษอࠤ๊๊แࠡื๋ีࠥอไอๆาࠤฤࠧࠡࠨࡱ")+YoQW601K4fMJcsreDnGVE5wUZIy7)
		if U17QqF2gkI46!=TlGXWLYsV1z(u"࠴ࢠ"): return
	FZ0zy7Cgeo1UjkR = m5mc0l3DPgnSoI.connect(qfznVTCRpxSDM85QGBHoU)
	FZ0zy7Cgeo1UjkR.text_factory = str
	AlI5YdVoWgZyP = FZ0zy7Cgeo1UjkR.cursor()
	AlI5YdVoWgZyP.execute(SaB5hx3PZwXRLtKgrTfQvId(u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࡵࡧࡴࡩ࠽ࠪࡲ"))
	AlI5YdVoWgZyP.execute(JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥࡹࡩࡻࡧࡶ࠿ࠬࡳ"))
	AlI5YdVoWgZyP.execute(LyNiIHPOwD3hCUYEFM7(u"ࠨࡆࡈࡐࡊ࡚ࡅࠡࡈࡕࡓࡒࠦࡴࡦࡺࡷࡹࡷ࡫࠻ࠨࡴ"))
	FZ0zy7Cgeo1UjkR.commit()
	AlI5YdVoWgZyP.execute(jXE2YHkswT8y(u"࡙ࠩࡅࡈ࡛ࡕࡎ࠽ࠪࡵ"))
	FZ0zy7Cgeo1UjkR.close()
	if showDialogs:
		bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ࡶ"),hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠫฯ๋ࠠศๆ่ืาࠦศ็ฮสัࠬࡷ"))
		SqMHwb6X1Ph8jY7LBNkmtV4F5Jlspy(BF6QAiLUNHh7rKOugaw)
	return
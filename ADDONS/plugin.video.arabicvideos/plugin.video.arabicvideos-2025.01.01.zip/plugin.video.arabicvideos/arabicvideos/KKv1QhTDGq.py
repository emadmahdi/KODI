# -*- coding: utf-8 -*-
import sys as ytv0YaxDcRINurplWKg587Pwqz
LS5n9Ib81cvhApByQJa6GX4HTf = ytv0YaxDcRINurplWKg587Pwqz.version_info [0] == 2
FVDxSCW5MgK = 2048
o2SVZsYjxd4MPfLCRzv1Ime9XD6rhW = 7
def EnKbMAYoFJ (kc93hiPDm4MqAOaL):
	global BCEn6px5l4
	qR9DalTWtCBVeyYwiQg = ord (kc93hiPDm4MqAOaL [-1])
	SSe8FNopD7MI1EixsPTgl4v3YmfB6 = kc93hiPDm4MqAOaL [:-1]
	T2g7SpExkOcr8NUtfYyMB1d4usRw = qR9DalTWtCBVeyYwiQg % len (SSe8FNopD7MI1EixsPTgl4v3YmfB6)
	fxd3B46829KvYlTG17kUyLNJIbWDp0 = SSe8FNopD7MI1EixsPTgl4v3YmfB6 [:T2g7SpExkOcr8NUtfYyMB1d4usRw] + SSe8FNopD7MI1EixsPTgl4v3YmfB6 [T2g7SpExkOcr8NUtfYyMB1d4usRw:]
	if LS5n9Ib81cvhApByQJa6GX4HTf:
		nXV2GRHyP8dpugjML5sTE4OKN = unicode () .join ([unichr (ord (XXYULyZe1FgwdTVnSx2kHfDAsMClJ9) - FVDxSCW5MgK - (GPf6BlpctR + qR9DalTWtCBVeyYwiQg) % o2SVZsYjxd4MPfLCRzv1Ime9XD6rhW) for GPf6BlpctR, XXYULyZe1FgwdTVnSx2kHfDAsMClJ9 in enumerate (fxd3B46829KvYlTG17kUyLNJIbWDp0)])
	else:
		nXV2GRHyP8dpugjML5sTE4OKN = str () .join ([chr (ord (XXYULyZe1FgwdTVnSx2kHfDAsMClJ9) - FVDxSCW5MgK - (GPf6BlpctR + qR9DalTWtCBVeyYwiQg) % o2SVZsYjxd4MPfLCRzv1Ime9XD6rhW) for GPf6BlpctR, XXYULyZe1FgwdTVnSx2kHfDAsMClJ9 in enumerate (fxd3B46829KvYlTG17kUyLNJIbWDp0)])
	return eval (nXV2GRHyP8dpugjML5sTE4OKN)
hhqd6cnfNJiAaLKTPbst5RpMmZF2G,LyNiIHPOwD3hCUYEFM7,vODxLKW5Ql6r4Fbm8=EnKbMAYoFJ,EnKbMAYoFJ,EnKbMAYoFJ
xpT28sXu051,GGx4qyKP1vUtRghsE2WfaHLMXZ,PtkEvXAqif14G20QZsaSyT=vODxLKW5Ql6r4Fbm8,LyNiIHPOwD3hCUYEFM7,hhqd6cnfNJiAaLKTPbst5RpMmZF2G
SaB5hx3PZwXRLtKgrTfQvId,YzX407G1m8ER9OBpkeuqPIf6Ajrh5,EMO8gy4LrsNTh0knZwpSeU75APW=PtkEvXAqif14G20QZsaSyT,GGx4qyKP1vUtRghsE2WfaHLMXZ,xpT28sXu051
yJeq1BjfiO4NFuwIEzxVLK6b9s,ZchUJdM93pTA7zG5,CCUzMTgQjrHntoiGf16LXW5P8EdVu=EMO8gy4LrsNTh0knZwpSeU75APW,YzX407G1m8ER9OBpkeuqPIf6Ajrh5,SaB5hx3PZwXRLtKgrTfQvId
JZszNnIEMAx28Yao0yqhiXGKOPb,XrTw01KtLzbpoyMf,uuExaKGL7UONtevRd=CCUzMTgQjrHntoiGf16LXW5P8EdVu,ZchUJdM93pTA7zG5,yJeq1BjfiO4NFuwIEzxVLK6b9s
y6y5HtgXO4TkUbwVZ,sVzojQerUqX,tKNPiXfQ7HoAqndw3z9IL4E6VrGv1=uuExaKGL7UONtevRd,XrTw01KtLzbpoyMf,JZszNnIEMAx28Yao0yqhiXGKOPb
AbqCJZdWQP9j,Y41NvKfOroMzGB8sEHy7wbXlc5,hhQwbeiNLoqFjX90fB7aG8VAs=tKNPiXfQ7HoAqndw3z9IL4E6VrGv1,sVzojQerUqX,y6y5HtgXO4TkUbwVZ
IpC4qHXRuyNFjzWv,ppxP0Cg6N3JVELzjGKmkZ2qIlu,L90uqo28xEKSFUwYTcm51yRWZIkft=hhQwbeiNLoqFjX90fB7aG8VAs,Y41NvKfOroMzGB8sEHy7wbXlc5,AbqCJZdWQP9j
FRYcH4KL7e9gv5pEB,tELM0b9FzxuRI4J1CYcie7ZXsHBar,TlGXWLYsV1z=L90uqo28xEKSFUwYTcm51yRWZIkft,ppxP0Cg6N3JVELzjGKmkZ2qIlu,IpC4qHXRuyNFjzWv
ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n,HtK4o2sTPgA78U,zmcGfOdvAjsELeJlP=TlGXWLYsV1z,tELM0b9FzxuRI4J1CYcie7ZXsHBar,FRYcH4KL7e9gv5pEB
UO04GcM7oFd3kJbtKQZHRgI2jeyzCh,MgP8OjoaiWQEVG59,jXE2YHkswT8y=zmcGfOdvAjsELeJlP,HtK4o2sTPgA78U,ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n
import xbmc as WwMgozBIC32n9d0tyfp,re as dEyT9xhGjolYzLCH7460w3,sys as ytv0YaxDcRINurplWKg587Pwqz,xbmcaddon as DnzmO5hVTuNriyELed,random as ufTX72hK8Q63jSsJiqDm5,os as wkMR5x1gTWEQIc6qHCa,xbmcvfs as FCzlJghHX2nPG3BRNc0SoetQdqW,time as X2cQ5NCPvkMieBW7oASspFjE,pickle as OZEQnsofuYvj,zlib as MZHConzbXxjIDNLV,xbmcgui as OOYtyXB3o8K,xbmcplugin as dsBkaDQ16gtSnbrUXvl,sqlite3 as m5mc0l3DPgnSoI,traceback as xiFBCH5hcJks,threading as EEehSFDLdpKBR3W1ga9PxrV,hashlib as WWbKa0cgvFOURDoHIEV3uhipsJ96,json as bHyN37Y82ZKVLOexBF
import IiCsQD91HF
sQU2GnRoMwLK8CBdfzmNr4jXyO = AbqCJZdWQP9j(u"ࠬࡒࡉࡃࡕࡒࡒࡊ࠭य़")
TPFpytsjLd57U = [IpC4qHXRuyNFjzWv(u"࠭࠹࠺࠻࠼࠱࠾࠿࠹࠺࠯࠼࠽࠾࠿࠭࠺࠻࠼࠽࠲࠶࠰࠱࠲ࠪॠ"),vODxLKW5Ql6r4Fbm8(u"ࠧ࠺࠻࠻࠼࠲࠽࠷࠷࠸࠰࠹࠺࠺࠴࠮࠵࠶࠶࠷࠳࠲࠱࠺࠹ࠫॡ")]
eeA3KYiN75JumQrEIdZw4XVp = []
KBCco4GTRUp1a = {}
iiy37aKq0pCEIOwfcTh61xb4U = PtkEvXAqif14G20QZsaSyT(u"ࠨࠩॢ")
iFBmE2MUIpSu34wsd7Rf6z = ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠩࠣࠫॣ")
Wc5GekRC0HQLz7 = iFBmE2MUIpSu34wsd7Rf6z*zmcGfOdvAjsELeJlP(u"࠳଩")
jHLaUg49SXC6JyTM = iFBmE2MUIpSu34wsd7Rf6z*JZszNnIEMAx28Yao0yqhiXGKOPb(u"࠵ପ")
hnVQObwUcR207fC = iFBmE2MUIpSu34wsd7Rf6z*UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"࠷ଫ")
rGPen6cSMHQkAywh8vqI9JXiD2 = CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"࡙ࡸࡵࡦ୺")
BF6QAiLUNHh7rKOugaw = Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࡌࡡ࡭ࡵࡨ୻")
FGTfwsjNrB8DvKSZhLIQAb1JnO = L90uqo28xEKSFUwYTcm51yRWZIkft(u"࠴ବ")
YYJQyRskpX8jv = HtK4o2sTPgA78U(u"࠶ଭ")
nI2JK1RfsGWNY3OarEeMQZ = AbqCJZdWQP9j(u"࠸ମ")
iiCWLaJREureAlOkv = YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"࠳ଯ")
pZWli1xqfVtvzuSU6ImNw53gBFsh = yJeq1BjfiO4NFuwIEzxVLK6b9s(u"࠵ର")
PSwfZcdRYhpl5Igqz8xOEk67 = EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡃ࠷࠵ࡊࡢ࠭।")
aqEsMBckT2bunGHfl48Wip = ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ॥")
MJSF94CaiBj2 = hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆ࠴࠵ࡈ࠸࠸࠹࡝ࠨ०")
dis4E096qw = hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇ࠳ࡉ࠹࠶ࡌࡆ࡞ࠩ१")
YoQW601K4fMJcsreDnGVE5wUZIy7 = PtkEvXAqif14G20QZsaSyT(u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ२")
df6QpwGxuJVZr = JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠨࡷࡷࡪ࠽࠭३")
q1rohYuwnfpVZUa98L2CtQzmAcB = tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ४")
P3sqIW4T8rYpjNxOXhcBk2GD = yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠪࡒࡔ࡚ࡉࡄࡇࡢࡐࡎࡔࡅࡔࠩ५")
ggQb54INJ8on0M = ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠫࡊࡘࡒࡐࡔࠪ६")
uiza5vIyTWtUeB8sXwAVYMFpgjrk = ZchUJdM93pTA7zG5(u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪ७")
OTlVEGYPSxsNaBdXUucqA3 = Y41NvKfOroMzGB8sEHy7wbXlc5(u"࠭࡜࡯ࠩ८")
Mge0HhFk9Ic6sm5VR = YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠧ࡝ࡴࠪ९")
V5f96hvSkeUwCxZrE4dlzpy = DnzmO5hVTuNriyELed.Addon().getAddonInfo(L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠨࡲࡤࡸ࡭࠭॰"))
XTi72SOMHRZUzfV49y3jGtB = wkMR5x1gTWEQIc6qHCa.path.join(V5f96hvSkeUwCxZrE4dlzpy,JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠩࡳࡥࡨࡱࡡࡨࡧࡶࠫॱ"))
ytv0YaxDcRINurplWKg587Pwqz.path.append(XTi72SOMHRZUzfV49y3jGtB)
MDPFS9ovE8daQwhKrI = WwMgozBIC32n9d0tyfp.getInfoLabel(TlGXWLYsV1z(u"ࠥࡗࡾࡹࡴࡦ࡯࠱ࡆࡺ࡯࡬ࡥࡘࡨࡶࡸ࡯࡯࡯ࠤॲ"))
ZD1J5rN8u2wzdgqoyULm4 = dEyT9xhGjolYzLCH7460w3.findall(hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠫ࠭ࡢࡤ࡝ࡦ࡟࠲ࡡࡪࠩࠨॳ"),MDPFS9ovE8daQwhKrI,dEyT9xhGjolYzLCH7460w3.DOTALL)
ZD1J5rN8u2wzdgqoyULm4 = float(ZD1J5rN8u2wzdgqoyULm4[FGTfwsjNrB8DvKSZhLIQAb1JnO])
eVvIKwBWTu1JphDX5OMjCx = WwMgozBIC32n9d0tyfp.Player
wiNkogLdpnA = OOYtyXB3o8K.WindowXMLDialog
iELueYz3J1FmxaW7vc = ZD1J5rN8u2wzdgqoyULm4<IpC4qHXRuyNFjzWv(u"࠳࠼଱")
J1MoiYc7ZwzKS = ZD1J5rN8u2wzdgqoyULm4>JZszNnIEMAx28Yao0yqhiXGKOPb(u"࠴࠼࠳࠿࠹ଲ")
if J1MoiYc7ZwzKS:
	DAV0Wk6lMH9tZ2 = WwMgozBIC32n9d0tyfp.LOGINFO
	Ds9inqGKb5frAd2CzmWke61aMQ,DApVioTIRMGX = TlGXWLYsV1z(u"ࡺ࠭࡜ࡶ࠴࠳࠶ࡦ࠭ॴ"),YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࡻࠧ࡝ࡷ࠵࠴࠷ࡨࠧॵ")
	bWB3qZjA1dDiM7N8huXUFHK = FCzlJghHX2nPG3BRNc0SoetQdqW.translatePath(hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲ࡸࡪࡳࡰࠨॶ"))
	from urllib.parse import unquote as _MgHfeC5Juko
else:
	DAV0Wk6lMH9tZ2 = WwMgozBIC32n9d0tyfp.LOGNOTICE
	Ds9inqGKb5frAd2CzmWke61aMQ,DApVioTIRMGX = UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࡶࠩ࡟ࡹ࠷࠶࠲ࡢࠩॷ").encode(df6QpwGxuJVZr),jXE2YHkswT8y(u"ࡷࠪࡠࡺ࠸࠰࠳ࡤࠪॸ").encode(df6QpwGxuJVZr)
	bWB3qZjA1dDiM7N8huXUFHK = WwMgozBIC32n9d0tyfp.translatePath(SaB5hx3PZwXRLtKgrTfQvId(u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡴࡦ࡯ࡳࠫॹ"))
	from urllib import unquote as _MgHfeC5Juko
E4QD2hgVZlT0pU1d39CwFyxb8fOrvA = AbqCJZdWQP9j(u"࠺࠵ଳ")
o5oKZNPi9CeVSI3DzBUEa8tGcAkvH = AbqCJZdWQP9j(u"࠻࠶଴")*E4QD2hgVZlT0pU1d39CwFyxb8fOrvA
v62Tn4AXCdINlFGDW0 = SaB5hx3PZwXRLtKgrTfQvId(u"࠸࠴ଵ")*o5oKZNPi9CeVSI3DzBUEa8tGcAkvH
TO1VRMCYG7dDWSU2qQf6EhIm = tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"࠳࠱ଶ")*v62Tn4AXCdINlFGDW0
hI7SkXd94fFzAHNZCQoMqEutbnWP = FGTfwsjNrB8DvKSZhLIQAb1JnO
Qfob9ThC6ryqKkYZ = YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"࠴࠲ଷ")*E4QD2hgVZlT0pU1d39CwFyxb8fOrvA
r3rnfZ7cdxzNFebIRaLSG6B = nI2JK1RfsGWNY3OarEeMQZ*o5oKZNPi9CeVSI3DzBUEa8tGcAkvH
PNjZMS7nxa9clHusz1 = YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"࠳࠹ସ")*o5oKZNPi9CeVSI3DzBUEa8tGcAkvH
Dxc7GChQwZ4kOlKHSbL06agnB = iiCWLaJREureAlOkv*v62Tn4AXCdINlFGDW0
ea84RQXsdLY9GIVjSzb = JZszNnIEMAx28Yao0yqhiXGKOPb(u"࠶࠴ହ")*v62Tn4AXCdINlFGDW0
VaeMF1mIjQ5iLtfGcB = JZszNnIEMAx28Yao0yqhiXGKOPb(u"࠵࠷଺")*TO1VRMCYG7dDWSU2qQf6EhIm
FvL8I2f4EX = o5oKZNPi9CeVSI3DzBUEa8tGcAkvH
M8hQu61Uid = ytv0YaxDcRINurplWKg587Pwqz.argv[FGTfwsjNrB8DvKSZhLIQAb1JnO].split(zmcGfOdvAjsELeJlP(u"ࠫ࠴࠭ॺ"))[nI2JK1RfsGWNY3OarEeMQZ]
Lwz8pPM60OCIBK7 = int(ytv0YaxDcRINurplWKg587Pwqz.argv[YYJQyRskpX8jv])
CzWIqm1YAcEa9gTSZ30fk27 = ytv0YaxDcRINurplWKg587Pwqz.argv[nI2JK1RfsGWNY3OarEeMQZ]
OvERI7a2pgV5GCmfoXDxk = M8hQu61Uid.split(sVzojQerUqX(u"ࠬ࠴ࠧॻ"))[nI2JK1RfsGWNY3OarEeMQZ]
DdAjF5pBNL9IqPgkz0xhcQEfU = WwMgozBIC32n9d0tyfp.getInfoLabel(ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"࠭ࡓࡺࡵࡷࡩࡲ࠴ࡁࡥࡦࡲࡲ࡛࡫ࡲࡴ࡫ࡲࡲ࠭࠭ॼ")+M8hQu61Uid+y6y5HtgXO4TkUbwVZ(u"ࠧࠪࠩॽ"))
StqmrCIJX4T623w5j9NEonxfQ = wkMR5x1gTWEQIc6qHCa.path.join(bWB3qZjA1dDiM7N8huXUFHK,M8hQu61Uid)
PdkZHNBlpg2b7DmX6qRiyVa = wkMR5x1gTWEQIc6qHCa.path.join(StqmrCIJX4T623w5j9NEonxfQ,y6y5HtgXO4TkUbwVZ(u"ࠨ࡯ࡤ࡭ࡳࡪࡡࡵࡣ࠱ࡨࡧ࠭ॾ"))
NWDbjPABRxu = wkMR5x1gTWEQIc6qHCa.path.join(StqmrCIJX4T623w5j9NEonxfQ,L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠩ࡯ࡥࡸࡺࡶࡪࡦࡨࡳࡸ࠴ࡤࡢࡶࠪॿ"))
pwXCQWuGUMka2hFN = int(X2cQ5NCPvkMieBW7oASspFjE.time())
OXsckY7RzjCag9A = DnzmO5hVTuNriyELed.Addon(id=M8hQu61Uid)
nR6F28iELvzNG = OXsckY7RzjCag9A.getSetting(IpC4qHXRuyNFjzWv(u"ࠪࡥࡻ࠴ࡶࡦࡴࡶ࡭ࡴࡴࠧঀ"))
UYetvipxsyObLZaMw3WVdAgCFEh = BF6QAiLUNHh7rKOugaw if nR6F28iELvzNG==DdAjF5pBNL9IqPgkz0xhcQEfU else rGPen6cSMHQkAywh8vqI9JXiD2
fpQHPAZvKw94 = BF6QAiLUNHh7rKOugaw
def sFNjagPK4W(smglbwR7x2oM,AAbf0g1sJ4crMQYiKmTypFltvkUVD=EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠫࡄ࠭ঁ")):
	if FRYcH4KL7e9gv5pEB(u"ࠬࡃࠧং") in smglbwR7x2oM:
		if AAbf0g1sJ4crMQYiKmTypFltvkUVD in smglbwR7x2oM: eCGwzSrqBmIv,T0MSCRIytzF8mpJa6P5wrb7uYHf = smglbwR7x2oM.split(AAbf0g1sJ4crMQYiKmTypFltvkUVD,ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"࠶଻"))
		else: eCGwzSrqBmIv,T0MSCRIytzF8mpJa6P5wrb7uYHf = iiy37aKq0pCEIOwfcTh61xb4U,smglbwR7x2oM
		T0MSCRIytzF8mpJa6P5wrb7uYHf = T0MSCRIytzF8mpJa6P5wrb7uYHf.split(xpT28sXu051(u"࠭ࠦࠨঃ"))
		EwsmJ67cCYDIlg = {}
		for oh2XtOL6Kya7we5B9UIMGYN in T0MSCRIytzF8mpJa6P5wrb7uYHf:
			Onuh30WYrigx,NHgSFB4E0lmtyDdswYiIUeCqp5J = oh2XtOL6Kya7we5B9UIMGYN.split(uuExaKGL7UONtevRd(u"ࠧ࠾ࠩ঄"),y6y5HtgXO4TkUbwVZ(u"࠷଼"))
			EwsmJ67cCYDIlg[Onuh30WYrigx] = NHgSFB4E0lmtyDdswYiIUeCqp5J
	else: eCGwzSrqBmIv,EwsmJ67cCYDIlg = smglbwR7x2oM,{}
	return eCGwzSrqBmIv,EwsmJ67cCYDIlg
def UrB3iTzS1sFnX(Toe5N9znWjQHmP4whguld):
	SR2mA4sfOwzrleFpLcKa0i6Pbj,ekEOd3mqAThaBDUoIrntuGRjYW,jhZNR7xbKiU8EDcI6 = iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U
	Toe5N9znWjQHmP4whguld = Toe5N9znWjQHmP4whguld.replace(Ds9inqGKb5frAd2CzmWke61aMQ,iiy37aKq0pCEIOwfcTh61xb4U).replace(DApVioTIRMGX,iiy37aKq0pCEIOwfcTh61xb4U)
	ZEdj50uOAeXUWGCk = dEyT9xhGjolYzLCH7460w3.findall(ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠨࠪ࠱࠭ࡡࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇ࠲࠻ࡇ࠶ࡌ࡜࡞ࠪ࡟ࡻࡡࡽ࡜ࡸࠫࠣ࠯ࡡࡡ࡜࠰ࡅࡒࡐࡔࡘ࡜࡞ࠪ࠱࠮ࡄ࠯ࠤࠨঅ"),Toe5N9znWjQHmP4whguld,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if ZEdj50uOAeXUWGCk: SR2mA4sfOwzrleFpLcKa0i6Pbj,ekEOd3mqAThaBDUoIrntuGRjYW,Toe5N9znWjQHmP4whguld = ZEdj50uOAeXUWGCk[FGTfwsjNrB8DvKSZhLIQAb1JnO]
	if SR2mA4sfOwzrleFpLcKa0i6Pbj not in [iFBmE2MUIpSu34wsd7Rf6z,YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠩ࠯ࠫআ"),iiy37aKq0pCEIOwfcTh61xb4U]: jhZNR7xbKiU8EDcI6 = ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠪࡣࡒࡕࡄࡠࠩই")
	if ekEOd3mqAThaBDUoIrntuGRjYW: ekEOd3mqAThaBDUoIrntuGRjYW = L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠫࡤ࠭ঈ")+ekEOd3mqAThaBDUoIrntuGRjYW+yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠬࡥࠧউ")
	Toe5N9znWjQHmP4whguld = ekEOd3mqAThaBDUoIrntuGRjYW+jhZNR7xbKiU8EDcI6+Toe5N9znWjQHmP4whguld
	return Toe5N9znWjQHmP4whguld
def a9I3YZjc6ySDPE4Kp(smglbwR7x2oM):
	return _MgHfeC5Juko(smglbwR7x2oM)
def Q4APpMirastonc6Wh1v2XOH3K(e82rZNpUJBjRLckEmhH3):
	h8S1uPUbfD = {ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"࠭ࡴࡺࡲࡨࠫঊ"):iiy37aKq0pCEIOwfcTh61xb4U,ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠧ࡮ࡱࡧࡩࠬঋ"):iiy37aKq0pCEIOwfcTh61xb4U,YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠨࡷࡵࡰࠬঌ"):iiy37aKq0pCEIOwfcTh61xb4U,AbqCJZdWQP9j(u"ࠩࡷࡩࡽࡺࠧ঍"):iiy37aKq0pCEIOwfcTh61xb4U,xpT28sXu051(u"ࠪࡴࡦ࡭ࡥࠨ঎"):iiy37aKq0pCEIOwfcTh61xb4U,XrTw01KtLzbpoyMf(u"ࠫࡳࡧ࡭ࡦࠩএ"):iiy37aKq0pCEIOwfcTh61xb4U,L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠬ࡯࡭ࡢࡩࡨࠫঐ"):iiy37aKq0pCEIOwfcTh61xb4U,EMO8gy4LrsNTh0knZwpSeU75APW(u"࠭ࡣࡰࡰࡷࡩࡽࡺࠧ঑"):iiy37aKq0pCEIOwfcTh61xb4U,LyNiIHPOwD3hCUYEFM7(u"ࠧࡪࡰࡩࡳࡩ࡯ࡣࡵࠩ঒"):iiy37aKq0pCEIOwfcTh61xb4U}
	if EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠨࡁࠪও") in e82rZNpUJBjRLckEmhH3: e82rZNpUJBjRLckEmhH3 = e82rZNpUJBjRLckEmhH3.split(xpT28sXu051(u"ࠩࡂࠫঔ"),YYJQyRskpX8jv)[YYJQyRskpX8jv]
	eCGwzSrqBmIv,Old8wqF1xcivQeJZmDPbk3 = sFNjagPK4W(e82rZNpUJBjRLckEmhH3)
	aargs = dict(list(h8S1uPUbfD.items())+list(Old8wqF1xcivQeJZmDPbk3.items()))
	D8DaOljYRmg2x = aargs[yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠪࡱࡴࡪࡥࠨক")]
	A8RCSEltk1g6Wq5KGeIdxnFpUv = a9I3YZjc6ySDPE4Kp(aargs[zmcGfOdvAjsELeJlP(u"ࠫࡺࡸ࡬ࠨখ")])
	bi1RWINt52gz3DsuEqvZ = a9I3YZjc6ySDPE4Kp(aargs[L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠬࡺࡥࡹࡶࠪগ")])
	gkyuWnHmrClwzbjAqMTBREKtaI = a9I3YZjc6ySDPE4Kp(aargs[FRYcH4KL7e9gv5pEB(u"࠭ࡰࡢࡩࡨࠫঘ")])
	IXfvjBK2RAHbMlV36t = a9I3YZjc6ySDPE4Kp(aargs[Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠧࡵࡻࡳࡩࠬঙ")])
	q9FkAs1NQVWaXRl = a9I3YZjc6ySDPE4Kp(aargs[UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠨࡰࡤࡱࡪ࠭চ")])
	ILNJfuaQCG8U1xDW24KB = a9I3YZjc6ySDPE4Kp(aargs[y6y5HtgXO4TkUbwVZ(u"ࠩ࡬ࡱࡦ࡭ࡥࠨছ")])
	kv4lwLRzc0i = aargs[JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠪࡧࡴࡴࡴࡦࡺࡷࠫজ")]
	LaSfOom2Tr4p9tKX = a9I3YZjc6ySDPE4Kp(aargs[xpT28sXu051(u"ࠫ࡮ࡴࡦࡰࡦ࡬ࡧࡹ࠭ঝ")])
	if LaSfOom2Tr4p9tKX: LaSfOom2Tr4p9tKX = eval(LaSfOom2Tr4p9tKX)
	else: LaSfOom2Tr4p9tKX = {}
	if not D8DaOljYRmg2x: IXfvjBK2RAHbMlV36t = y6y5HtgXO4TkUbwVZ(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬঞ") ; D8DaOljYRmg2x = sVzojQerUqX(u"࠭࠲࠷࠲ࠪট")
	return IXfvjBK2RAHbMlV36t,q9FkAs1NQVWaXRl,A8RCSEltk1g6Wq5KGeIdxnFpUv,D8DaOljYRmg2x,ILNJfuaQCG8U1xDW24KB,gkyuWnHmrClwzbjAqMTBREKtaI,bi1RWINt52gz3DsuEqvZ,kv4lwLRzc0i,LaSfOom2Tr4p9tKX
def IIZ4e82HBP0oTmtOgaWY7hsMz(sQU2GnRoMwLK8CBdfzmNr4jXyO):
	KQsCUnqlWe = ytv0YaxDcRINurplWKg587Pwqz._getframe(YYJQyRskpX8jv).f_code.co_name
	if not sQU2GnRoMwLK8CBdfzmNr4jXyO or not KQsCUnqlWe or KQsCUnqlWe==CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠧ࠽࡯ࡲࡨࡺࡲࡥ࠿ࠩঠ"):
		return Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠨ࡝ࠣࠫড")+OvERI7a2pgV5GCmfoXDxk.upper()+tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠩࡢࠫঢ")+DdAjF5pBNL9IqPgkz0xhcQEfU+Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠪࡣࠬণ")+str(ZD1J5rN8u2wzdgqoyULm4)+PtkEvXAqif14G20QZsaSyT(u"ࠫࠥࡣࠧত")
	return TlGXWLYsV1z(u"ࠬ࠴࡜ࡵࠩথ")+KQsCUnqlWe
def WKquk5EaNr4RzVf(Wgwk3JKCIh5mPrnL,NNFlSgsp39MWCGxaXEILe):
	if iELueYz3J1FmxaW7vc: NNFlSgsp39MWCGxaXEILe = NNFlSgsp39MWCGxaXEILe.decode(df6QpwGxuJVZr).encode(df6QpwGxuJVZr)
	dlUB4oK9DaR = DAV0Wk6lMH9tZ2
	Wbe8jlJaNdroOHgpm = [iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U]
	if Wgwk3JKCIh5mPrnL: NNFlSgsp39MWCGxaXEILe = NNFlSgsp39MWCGxaXEILe.replace(aqEsMBckT2bunGHfl48Wip,iiy37aKq0pCEIOwfcTh61xb4U).replace(PSwfZcdRYhpl5Igqz8xOEk67,iiy37aKq0pCEIOwfcTh61xb4U).replace(YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U)
	else: Wgwk3JKCIh5mPrnL = q1rohYuwnfpVZUa98L2CtQzmAcB
	AWXgadk5lcYjnLSqPVw,AAbf0g1sJ4crMQYiKmTypFltvkUVD = tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"࠭࡜ࡵࠩদ"),jHLaUg49SXC6JyTM
	ttuA5VNJz62ZaUiW3XLvdI = UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"࠵࠴ା")*iFBmE2MUIpSu34wsd7Rf6z if J1MoiYc7ZwzKS else AbqCJZdWQP9j(u"࠳࠲ଽ")*iFBmE2MUIpSu34wsd7Rf6z
	jdMOEPQ16gGK5 = pZWli1xqfVtvzuSU6ImNw53gBFsh*AWXgadk5lcYjnLSqPVw
	if NNFlSgsp39MWCGxaXEILe.startswith(Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠧࡐࡒࡈࡒ࡚ࡘࡌࠨধ")): NNFlSgsp39MWCGxaXEILe = uuExaKGL7UONtevRd(u"ࠨ࠰࡟ࡸࠬন")+NNFlSgsp39MWCGxaXEILe
	if ggQb54INJ8on0M in Wgwk3JKCIh5mPrnL: dlUB4oK9DaR = WwMgozBIC32n9d0tyfp.LOGERROR
	if Wgwk3JKCIh5mPrnL in [q1rohYuwnfpVZUa98L2CtQzmAcB,ggQb54INJ8on0M]: Wbe8jlJaNdroOHgpm = [NNFlSgsp39MWCGxaXEILe]
	elif Wgwk3JKCIh5mPrnL==uiza5vIyTWtUeB8sXwAVYMFpgjrk: Wbe8jlJaNdroOHgpm = NNFlSgsp39MWCGxaXEILe.split(AAbf0g1sJ4crMQYiKmTypFltvkUVD)
	elif Wgwk3JKCIh5mPrnL==P3sqIW4T8rYpjNxOXhcBk2GD:
		sVKiT85bQpO2N9HAgZxELrfcB0SeG = NNFlSgsp39MWCGxaXEILe.split(AAbf0g1sJ4crMQYiKmTypFltvkUVD)
		Wbe8jlJaNdroOHgpm = [sVKiT85bQpO2N9HAgZxELrfcB0SeG[FGTfwsjNrB8DvKSZhLIQAb1JnO]]
		for ba3If2JElOq0nNPWBkXC6dH in range(YYJQyRskpX8jv,len(sVKiT85bQpO2N9HAgZxELrfcB0SeG),nI2JK1RfsGWNY3OarEeMQZ):
			try: Qu1kiXlawDdrpFM5Ss4TgWt2xn9b = sVKiT85bQpO2N9HAgZxELrfcB0SeG[ba3If2JElOq0nNPWBkXC6dH]+AAbf0g1sJ4crMQYiKmTypFltvkUVD+sVKiT85bQpO2N9HAgZxELrfcB0SeG[ba3If2JElOq0nNPWBkXC6dH+FRYcH4KL7e9gv5pEB(u"࠳ି")]
			except: Qu1kiXlawDdrpFM5Ss4TgWt2xn9b = sVKiT85bQpO2N9HAgZxELrfcB0SeG[ba3If2JElOq0nNPWBkXC6dH]
			Wbe8jlJaNdroOHgpm.append(Qu1kiXlawDdrpFM5Ss4TgWt2xn9b)
	niJBVIuCAS1p5Obh = Wbe8jlJaNdroOHgpm[FGTfwsjNrB8DvKSZhLIQAb1JnO]
	for KKmXklH2p8CEqGzDFNI3c0 in Wbe8jlJaNdroOHgpm[YYJQyRskpX8jv:]:
		if Wgwk3JKCIh5mPrnL in [uiza5vIyTWtUeB8sXwAVYMFpgjrk,P3sqIW4T8rYpjNxOXhcBk2GD]: jdMOEPQ16gGK5 += AWXgadk5lcYjnLSqPVw
		niJBVIuCAS1p5Obh += Mge0HhFk9Ic6sm5VR+ttuA5VNJz62ZaUiW3XLvdI+jdMOEPQ16gGK5+KKmXklH2p8CEqGzDFNI3c0
	niJBVIuCAS1p5Obh += GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠩࠣࡣࠬ঩")
	if EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠪࠩࠬপ") in niJBVIuCAS1p5Obh: niJBVIuCAS1p5Obh = a9I3YZjc6ySDPE4Kp(niJBVIuCAS1p5Obh)
	WwMgozBIC32n9d0tyfp.log(niJBVIuCAS1p5Obh,level=dlUB4oK9DaR)
	return
def gkdxoKzQVY6C7OGF3JvM9Xq(qfznVTCRpxSDM85QGBHoU):
	try: FZ0zy7Cgeo1UjkR = m5mc0l3DPgnSoI.connect(qfznVTCRpxSDM85QGBHoU,check_same_thread=EMO8gy4LrsNTh0knZwpSeU75APW(u"ࡆࡢ࡮ࡶࡩ୼"))
	except:
		if not wkMR5x1gTWEQIc6qHCa.path.exists(StqmrCIJX4T623w5j9NEonxfQ):
			wkMR5x1gTWEQIc6qHCa.makedirs(StqmrCIJX4T623w5j9NEonxfQ)
			FZ0zy7Cgeo1UjkR = m5mc0l3DPgnSoI.connect(qfznVTCRpxSDM85QGBHoU,check_same_thread=hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࡇࡣ࡯ࡷࡪ୽"))
	FZ0zy7Cgeo1UjkR.text_factory = str
	AlI5YdVoWgZyP = FZ0zy7Cgeo1UjkR.cursor()
	AlI5YdVoWgZyP.execute(YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠫࡕࡘࡁࡈࡏࡄࠤࡦࡻࡴࡰ࡯ࡤࡸ࡮ࡩ࡟ࡪࡰࡧࡩࡽࡃ࡮ࡰ࠽ࠪফ"))
	AlI5YdVoWgZyP.execute(sVzojQerUqX(u"ࠬࡖࡒࡂࡉࡐࡅࠥ࡯ࡧ࡯ࡱࡵࡩࡤࡩࡨࡦࡥ࡮ࡣࡨࡵ࡮ࡴࡶࡵࡥ࡮ࡴࡴࡴ࠿ࡼࡩࡸࡁࠧব"))
	AlI5YdVoWgZyP.execute(FRYcH4KL7e9gv5pEB(u"࠭ࡐࡓࡃࡊࡑࡆࠦࡪࡰࡷࡵࡲࡦࡲ࡟࡮ࡱࡧࡩࡂࡕࡆࡇ࠽ࠪভ"))
	AlI5YdVoWgZyP.execute(hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠧࡑࡔࡄࡋࡒࡇࠠࡴࡻࡱࡧ࡭ࡸ࡯࡯ࡱࡸࡷࡂࡕࡆࡇ࠽ࠪম"))
	tqC0PngwO4pA = RNS4lsuKk6Wa5MdA7jUIBixb9(qfznVTCRpxSDM85QGBHoU,FZ0zy7Cgeo1UjkR,AlI5YdVoWgZyP,BF6QAiLUNHh7rKOugaw,MgP8OjoaiWQEVG59(u"ࠨࡄࡈࡋࡎࡔࠠࡊࡏࡐࡉࡉࡏࡁࡕࡇࠣࡘࡗࡇࡎࡔࡃࡆࡘࡎࡕࡎࠡ࠽ࠪয"))
	if tqC0PngwO4pA: FZ0zy7Cgeo1UjkR.commit()
	else:
		qAXLJHy4FBEhc5aem7wPul()
	return FZ0zy7Cgeo1UjkR,AlI5YdVoWgZyP
def RNS4lsuKk6Wa5MdA7jUIBixb9(qfznVTCRpxSDM85QGBHoU,FZ0zy7Cgeo1UjkR,AlI5YdVoWgZyP,rrUusNJTRId2zSPmV7xMlB9k5oGfw,yemFD6dIqGtpQXf05URHMSgPuWAj,S0vfcpWLtDi8YZ7E4z=()):
	try:
		if rrUusNJTRId2zSPmV7xMlB9k5oGfw: AlI5YdVoWgZyP.executemany(yemFD6dIqGtpQXf05URHMSgPuWAj,S0vfcpWLtDi8YZ7E4z)
		else: AlI5YdVoWgZyP.execute(yemFD6dIqGtpQXf05URHMSgPuWAj,S0vfcpWLtDi8YZ7E4z)
		FZ0zy7Cgeo1UjkR.commit()
		tqC0PngwO4pA = rGPen6cSMHQkAywh8vqI9JXiD2
	except:
		tqC0PngwO4pA,timeout = BF6QAiLUNHh7rKOugaw,LyNiIHPOwD3hCUYEFM7(u"࠴࠴ୀ")
		zw7N4lrtECp82 = X2cQ5NCPvkMieBW7oASspFjE.time()
		while X2cQ5NCPvkMieBW7oASspFjE.time()-zw7N4lrtECp82<timeout and not tqC0PngwO4pA:
			try:
				if rrUusNJTRId2zSPmV7xMlB9k5oGfw: AlI5YdVoWgZyP.executemany(yemFD6dIqGtpQXf05URHMSgPuWAj,S0vfcpWLtDi8YZ7E4z)
				else: AlI5YdVoWgZyP.execute(yemFD6dIqGtpQXf05URHMSgPuWAj,S0vfcpWLtDi8YZ7E4z)
				FZ0zy7Cgeo1UjkR.commit()
				tqC0PngwO4pA = rGPen6cSMHQkAywh8vqI9JXiD2
			except: X2cQ5NCPvkMieBW7oASspFjE.sleep(L90uqo28xEKSFUwYTcm51yRWZIkft(u"࠴࠳࠻ୁ"))
		if not tqC0PngwO4pA:
			WKquk5EaNr4RzVf(uiza5vIyTWtUeB8sXwAVYMFpgjrk,HtK4o2sTPgA78U(u"ࠩ࠱ࡠࡹ࡛࡮ࡢࡤ࡯ࡩࠥࡺ࡯ࠡࡹࡵ࡭ࡹ࡫ࠠࡵࡱࠣࡸ࡭࡫ࠠࡥࡣࡷࡥࡧࡧࡳࡦࠢࡩ࡭ࡱ࡫ࠠࠡࠢࠪর")+qfznVTCRpxSDM85QGBHoU+CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠪࠤࠥࠦࡆࡢ࡫࡯ࡩࡩࠦࡷࡩࡧࡱࠤࡪࡾࡥࡤࡷࡷ࡭ࡳ࡭ࠠࡵࡪ࡬ࡷࠥࡹࡴࡢࡶࡨࡱࡪࡴࡴࠡࠢࠣࠫ঱")+yemFD6dIqGtpQXf05URHMSgPuWAj+OTlVEGYPSxsNaBdXUucqA3)
			import braVAkwfBN
			braVAkwfBN.YYkhEn5xTXLUevzCVNB16mR(SaB5hx3PZwXRLtKgrTfQvId(u"ࠫๆฺไࠡใํࠤ็อูะหࠣห้ฮ๊ศ่สฮࠬল"),yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠬࡌࡡࡪ࡮ࡸࡶࡪ࠭঳"))
	return tqC0PngwO4pA
def QKzCiBOWZus1nSv(qfznVTCRpxSDM85QGBHoU,hhMxKFyp3IBbVLvfi9,WSpGLu84ycrNdBYQezqmk3,WO6BLfauTJKvVpitDY=None):
	oRzlSfeE6DY0mFy37NCVxAJW1BwZtM = c9ho5RAHxMTPyqOd(hhMxKFyp3IBbVLvfi9)
	xZ9qAk7pF3XCKDsOh0SN = OXsckY7RzjCag9A.getSetting(jXE2YHkswT8y(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰࡫ࡸࡹࡶࡣࡢࡥ࡫ࡩࠬ঴"))
	if WSpGLu84ycrNdBYQezqmk3 not in [ZchUJdM93pTA7zG5(u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪ঵"),UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠨࡉࡏࡓࡇࡇࡌࡔࡇࡄࡖࡈࡎ࡟ࡔࡒࡏࡍ࡙࡚ࡅࡅࡡࡄࡐࡑ࠭শ"),hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠩࡊࡐࡔࡈࡁࡍࡕࡈࡅࡗࡉࡈࡠࡕࡓࡐࡎ࡚ࡔࡆࡆࡢࡋࡔࡕࡇࡍࡇࠪষ")] and qfznVTCRpxSDM85QGBHoU==PdkZHNBlpg2b7DmX6qRiyVa and WO6BLfauTJKvVpitDY!=MgP8OjoaiWQEVG59(u"ࠪࡑࡊ࡙ࡓࡂࡉࡈࡗࠬস"):
		if xZ9qAk7pF3XCKDsOh0SN==TlGXWLYsV1z(u"ࠫࡘ࡚ࡏࡑࠩহ"): return oRzlSfeE6DY0mFy37NCVxAJW1BwZtM
		zCXZNsp6PT8Mhxnr5v0G71KaBdFR = OXsckY7RzjCag9A.getSetting(YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡴࡨࡪࡷ࡫ࡳࡩࠩ঺"))
		if zCXZNsp6PT8Mhxnr5v0G71KaBdFR==CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"࠭ࡒࡆࡈࡕࡉࡘࡎ࡟ࡄࡃࡆࡌࡊ࠭঻"):
			Bcxq3nkvTU9iM(qfznVTCRpxSDM85QGBHoU,WSpGLu84ycrNdBYQezqmk3,WO6BLfauTJKvVpitDY)
			return oRzlSfeE6DY0mFy37NCVxAJW1BwZtM
	ZBHsiW4h1jRIV = FGTfwsjNrB8DvKSZhLIQAb1JnO
	if xZ9qAk7pF3XCKDsOh0SN==AbqCJZdWQP9j(u"ࠧࡍࡋࡐࡍ࡙ࡋࡄࠨ়"): ZBHsiW4h1jRIV = FvL8I2f4EX
	FZ0zy7Cgeo1UjkR,AlI5YdVoWgZyP = gkdxoKzQVY6C7OGF3JvM9Xq(qfznVTCRpxSDM85QGBHoU)
	MMpeAXKHLFyOsbhPGt0g = AlI5YdVoWgZyP.execute(hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠨࡕࡈࡐࡊࡉࡔࠡࡰࡤࡱࡪࠦࡆࡓࡑࡐࠤࡸࡷ࡬ࡪࡶࡨࡣࡲࡧࡳࡵࡧࡵࠤ࡜ࡎࡅࡓࡇࠣࡸࡾࡶࡥ࠾ࠤࡷࡥࡧࡲࡥࠣࠢࡄࡒࡉࠦ࡮ࡢ࡯ࡨࡁࠧ࠭ঽ")+WSpGLu84ycrNdBYQezqmk3+Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠩࠥࠤࡀ࠭া")).fetchall()
	if MMpeAXKHLFyOsbhPGt0g:
		if ZBHsiW4h1jRIV: RNS4lsuKk6Wa5MdA7jUIBixb9(qfznVTCRpxSDM85QGBHoU,FZ0zy7Cgeo1UjkR,AlI5YdVoWgZyP,BF6QAiLUNHh7rKOugaw,XrTw01KtLzbpoyMf(u"ࠪࡈࡊࡒࡅࡕࡇࠣࡊࡗࡕࡍࠡࠤࠪি")+WSpGLu84ycrNdBYQezqmk3+ZchUJdM93pTA7zG5(u"ࠫࠧࠦࡗࡉࡇࡕࡉࠥ࡫ࡸࡱ࡫ࡵࡽࡃ࠭ী")+str(pwXCQWuGUMka2hFN+ZBHsiW4h1jRIV)+IpC4qHXRuyNFjzWv(u"ࠬࠦ࠻ࠨু"))
		RNS4lsuKk6Wa5MdA7jUIBixb9(qfznVTCRpxSDM85QGBHoU,FZ0zy7Cgeo1UjkR,AlI5YdVoWgZyP,BF6QAiLUNHh7rKOugaw,hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࠧ࠭ূ")+WSpGLu84ycrNdBYQezqmk3+CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"࡚ࠧࠣࠢࡌࡊࡘࡅࠡࡧࡻࡴ࡮ࡸࡹ࠽ࠩৃ")+str(pwXCQWuGUMka2hFN)+HtK4o2sTPgA78U(u"ࠨࠢ࠾ࠫৄ"))
		if WO6BLfauTJKvVpitDY:
			RR5JyxbWSOi21Vst4 = (str(WO6BLfauTJKvVpitDY),)
			AlI5YdVoWgZyP.execute(TlGXWLYsV1z(u"ࠩࡖࡉࡑࡋࡃࡕࠢࡧࡥࡹࡧࠠࡇࡔࡒࡑࠥࠨࠧ৅")+WSpGLu84ycrNdBYQezqmk3+yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠪࠦࠥ࡝ࡈࡆࡔࡈࠤࡨࡵ࡬ࡶ࡯ࡱࠤࡂࠦ࠿ࠡ࠽ࠪ৆"),RR5JyxbWSOi21Vst4)
			s9Knvz7Ymhy46BErTSpwlUIR = AlI5YdVoWgZyP.fetchall()
			if s9Knvz7Ymhy46BErTSpwlUIR:
				try:
					XiWJ2PTqvds4pBNebVrt98x = MZHConzbXxjIDNLV.decompress(s9Knvz7Ymhy46BErTSpwlUIR[FGTfwsjNrB8DvKSZhLIQAb1JnO][FGTfwsjNrB8DvKSZhLIQAb1JnO])
					oRzlSfeE6DY0mFy37NCVxAJW1BwZtM = OZEQnsofuYvj.loads(XiWJ2PTqvds4pBNebVrt98x)
				except: pass
		else:
			AlI5YdVoWgZyP.execute(Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠫࡘࡋࡌࡆࡅࡗࠤࡨࡵ࡬ࡶ࡯ࡱ࠰ࡩࡧࡴࡢࠢࡉࡖࡔࡓࠠࠣࠩে")+WSpGLu84ycrNdBYQezqmk3+AbqCJZdWQP9j(u"ࠬࠨࠠ࠼ࠩৈ"))
			s9Knvz7Ymhy46BErTSpwlUIR = AlI5YdVoWgZyP.fetchall()
			if s9Knvz7Ymhy46BErTSpwlUIR:
				oRzlSfeE6DY0mFy37NCVxAJW1BwZtM,aQ2LMHcIvyqURJTdlspD6 = {},[]
				for nWuNMeQ4FjPLXsGz,EwsmJ67cCYDIlg in s9Knvz7Ymhy46BErTSpwlUIR:
					AkLKwEuog3O8JDFlt6nGiN19aec0p = MZHConzbXxjIDNLV.decompress(EwsmJ67cCYDIlg)
					EwsmJ67cCYDIlg = OZEQnsofuYvj.loads(AkLKwEuog3O8JDFlt6nGiN19aec0p)
					oRzlSfeE6DY0mFy37NCVxAJW1BwZtM[nWuNMeQ4FjPLXsGz] = EwsmJ67cCYDIlg
					aQ2LMHcIvyqURJTdlspD6.append(nWuNMeQ4FjPLXsGz)
				if aQ2LMHcIvyqURJTdlspD6:
					oRzlSfeE6DY0mFy37NCVxAJW1BwZtM[tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"࠭࡟ࡠࡕࡈࡕ࡚ࡋࡎࡄࡇࡇࡣࡈࡕࡌࡖࡏࡑࡗࡤࡥࠧ৉")] = aQ2LMHcIvyqURJTdlspD6
					if hhMxKFyp3IBbVLvfi9==FRYcH4KL7e9gv5pEB(u"ࠧ࡭࡫ࡶࡸࠬ৊"): oRzlSfeE6DY0mFy37NCVxAJW1BwZtM = aQ2LMHcIvyqURJTdlspD6
	FZ0zy7Cgeo1UjkR.close()
	return oRzlSfeE6DY0mFy37NCVxAJW1BwZtM
def YMQXP2BGeK86CEb(qfznVTCRpxSDM85QGBHoU,WSpGLu84ycrNdBYQezqmk3,WO6BLfauTJKvVpitDY,oRzlSfeE6DY0mFy37NCVxAJW1BwZtM,BUNRYozbWHwpEqr89fQL3hs,nTN8scdD9i6aERUKFBXo=BF6QAiLUNHh7rKOugaw):
	xZ9qAk7pF3XCKDsOh0SN = OXsckY7RzjCag9A.getSetting(YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲࡭ࡺࡴࡱࡥࡤࡧ࡭࡫ࠧো"))
	if xZ9qAk7pF3XCKDsOh0SN==ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠩࡏࡍࡒࡏࡔࡆࡆࠪৌ") and BUNRYozbWHwpEqr89fQL3hs>FvL8I2f4EX: BUNRYozbWHwpEqr89fQL3hs = FvL8I2f4EX
	if nTN8scdD9i6aERUKFBXo:
		QhNGvIF4YS2a5gxLAcy1k6VW3w,ETsFOuqxalPA8WbRILYmrdt2UVZ5Gp = [],[]
		for o6oXFxmE1bQC in range(len(WO6BLfauTJKvVpitDY)):
			XiWJ2PTqvds4pBNebVrt98x = OZEQnsofuYvj.dumps(oRzlSfeE6DY0mFy37NCVxAJW1BwZtM[o6oXFxmE1bQC])
			L86OhqWmZn0ok9jTzu4PIaSHl = MZHConzbXxjIDNLV.compress(XiWJ2PTqvds4pBNebVrt98x)
			QhNGvIF4YS2a5gxLAcy1k6VW3w.append((WO6BLfauTJKvVpitDY[o6oXFxmE1bQC],))
			ETsFOuqxalPA8WbRILYmrdt2UVZ5Gp.append((BUNRYozbWHwpEqr89fQL3hs+pwXCQWuGUMka2hFN,str(WO6BLfauTJKvVpitDY[o6oXFxmE1bQC]),L86OhqWmZn0ok9jTzu4PIaSHl))
	else:
		XiWJ2PTqvds4pBNebVrt98x = OZEQnsofuYvj.dumps(oRzlSfeE6DY0mFy37NCVxAJW1BwZtM)
		uoa3GNT7wrAci = MZHConzbXxjIDNLV.compress(XiWJ2PTqvds4pBNebVrt98x)
	FZ0zy7Cgeo1UjkR,AlI5YdVoWgZyP = gkdxoKzQVY6C7OGF3JvM9Xq(qfznVTCRpxSDM85QGBHoU)
	RNS4lsuKk6Wa5MdA7jUIBixb9(qfznVTCRpxSDM85QGBHoU,FZ0zy7Cgeo1UjkR,AlI5YdVoWgZyP,BF6QAiLUNHh7rKOugaw,FRYcH4KL7e9gv5pEB(u"ࠪࡇࡗࡋࡁࡕࡇࠣࡘࡆࡈࡌࡆࠢࡌࡊࠥࡔࡏࡕࠢࡈ࡜ࡎ࡙ࡔࡔ্ࠢࠥࠫ")+WSpGLu84ycrNdBYQezqmk3+JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠫࠧࠦࠨࡦࡺࡳ࡭ࡷࡿࠬࡤࡱ࡯ࡹࡲࡴࠬࡥࡣࡷࡥ࠮ࠦ࠻ࠨৎ"))
	if nTN8scdD9i6aERUKFBXo:
		RNS4lsuKk6Wa5MdA7jUIBixb9(qfznVTCRpxSDM85QGBHoU,FZ0zy7Cgeo1UjkR,AlI5YdVoWgZyP,rGPen6cSMHQkAywh8vqI9JXiD2,AbqCJZdWQP9j(u"ࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࠦࠬ৏")+WSpGLu84ycrNdBYQezqmk3+TlGXWLYsV1z(u"࡙࠭ࠢࠡࡋࡉࡗࡋࠠࡤࡱ࡯ࡹࡲࡴࠠ࠾ࠢࡂࠤࡀ࠭৐"),QhNGvIF4YS2a5gxLAcy1k6VW3w)
		RNS4lsuKk6Wa5MdA7jUIBixb9(qfznVTCRpxSDM85QGBHoU,FZ0zy7Cgeo1UjkR,AlI5YdVoWgZyP,rGPen6cSMHQkAywh8vqI9JXiD2,CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠧࡊࡐࡖࡉࡗ࡚ࠠࡊࡐࡗࡓࠥࠨࠧ৑")+WSpGLu84ycrNdBYQezqmk3+AbqCJZdWQP9j(u"ࠨࠤ࡚ࠣࡆࡒࡕࡆࡕࠣࠬࡄ࠲࠿࠭ࡁࠬࠤࡀ࠭৒"),ETsFOuqxalPA8WbRILYmrdt2UVZ5Gp)
	else:
		if BUNRYozbWHwpEqr89fQL3hs:
			RR5JyxbWSOi21Vst4 = (str(WO6BLfauTJKvVpitDY),)
			RNS4lsuKk6Wa5MdA7jUIBixb9(qfznVTCRpxSDM85QGBHoU,FZ0zy7Cgeo1UjkR,AlI5YdVoWgZyP,BF6QAiLUNHh7rKOugaw,zmcGfOdvAjsELeJlP(u"ࠩࡇࡉࡑࡋࡔࡆࠢࡉࡖࡔࡓࠠࠣࠩ৓")+WSpGLu84ycrNdBYQezqmk3+CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠪࠦࠥ࡝ࡈࡆࡔࡈࠤࡨࡵ࡬ࡶ࡯ࡱࠤࡂࠦ࠿ࠡ࠽ࠪ৔"),RR5JyxbWSOi21Vst4)
			RR5JyxbWSOi21Vst4 = (BUNRYozbWHwpEqr89fQL3hs+pwXCQWuGUMka2hFN,str(WO6BLfauTJKvVpitDY),uoa3GNT7wrAci)
			RNS4lsuKk6Wa5MdA7jUIBixb9(qfznVTCRpxSDM85QGBHoU,FZ0zy7Cgeo1UjkR,AlI5YdVoWgZyP,BF6QAiLUNHh7rKOugaw,SaB5hx3PZwXRLtKgrTfQvId(u"ࠫࡎࡔࡓࡆࡔࡗࠤࡎࡔࡔࡐࠢࠥࠫ৕")+WSpGLu84ycrNdBYQezqmk3+HtK4o2sTPgA78U(u"ࠬࠨࠠࡗࡃࡏ࡙ࡊ࡙ࠠࠩࡁ࠯ࡃ࠱ࡅࠩࠡ࠽ࠪ৖"),RR5JyxbWSOi21Vst4)
		else:
			RR5JyxbWSOi21Vst4 = (uoa3GNT7wrAci,str(WO6BLfauTJKvVpitDY))
			RNS4lsuKk6Wa5MdA7jUIBixb9(qfznVTCRpxSDM85QGBHoU,FZ0zy7Cgeo1UjkR,AlI5YdVoWgZyP,BF6QAiLUNHh7rKOugaw,EMO8gy4LrsNTh0knZwpSeU75APW(u"࠭ࡕࡑࡆࡄࡘࡊࠦࠢࠨৗ")+WSpGLu84ycrNdBYQezqmk3+UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠧࠣࠢࡖࡉ࡙ࠦࡤࡢࡶࡤࠤࡂࠦ࠿࡙ࠡࡋࡉࡗࡋࠠࡤࡱ࡯ࡹࡲࡴࠠ࠾ࠢࡂࠤࡀ࠭৘"),RR5JyxbWSOi21Vst4)
	FZ0zy7Cgeo1UjkR.close()
	return
def Bcxq3nkvTU9iM(qfznVTCRpxSDM85QGBHoU,WSpGLu84ycrNdBYQezqmk3,WO6BLfauTJKvVpitDY=None):
	FZ0zy7Cgeo1UjkR,AlI5YdVoWgZyP = gkdxoKzQVY6C7OGF3JvM9Xq(qfznVTCRpxSDM85QGBHoU)
	if WO6BLfauTJKvVpitDY==None: RNS4lsuKk6Wa5MdA7jUIBixb9(qfznVTCRpxSDM85QGBHoU,FZ0zy7Cgeo1UjkR,AlI5YdVoWgZyP,BF6QAiLUNHh7rKOugaw,vODxLKW5Ql6r4Fbm8(u"ࠨࡆࡕࡓࡕࠦࡔࡂࡄࡏࡉࠥࡏࡆࠡࡇ࡛ࡍࡘ࡚ࡓࠡࠤࠪ৙")+WSpGLu84ycrNdBYQezqmk3+GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠩࠥࠤࡀ࠭৚"))
	else:
		MMpeAXKHLFyOsbhPGt0g = AlI5YdVoWgZyP.execute(sVzojQerUqX(u"ࠪࡗࡊࡒࡅࡄࡖࠣࡲࡦࡳࡥࠡࡈࡕࡓࡒࠦࡳࡲ࡮࡬ࡸࡪࡥ࡭ࡢࡵࡷࡩࡷࠦࡗࡉࡇࡕࡉࠥࡺࡹࡱࡧࡀࠦࡹࡧࡢ࡭ࡧࠥࠤࡆࡔࡄࠡࡰࡤࡱࡪࡃࠢࠨ৛")+WSpGLu84ycrNdBYQezqmk3+SaB5hx3PZwXRLtKgrTfQvId(u"ࠫࠧࠦ࠻ࠨড়")).fetchall()
		if MMpeAXKHLFyOsbhPGt0g:
			RR5JyxbWSOi21Vst4 = (str(WO6BLfauTJKvVpitDY),)
			if vODxLKW5Ql6r4Fbm8(u"ࠬࠫࠧঢ়") in WO6BLfauTJKvVpitDY: RNS4lsuKk6Wa5MdA7jUIBixb9(qfznVTCRpxSDM85QGBHoU,FZ0zy7Cgeo1UjkR,AlI5YdVoWgZyP,BF6QAiLUNHh7rKOugaw,UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࠧ࠭৞")+WSpGLu84ycrNdBYQezqmk3+HtK4o2sTPgA78U(u"࡚ࠧࠣࠢࡌࡊࡘࡅࠡࡥࡲࡰࡺࡳ࡮ࠡ࡮࡬࡯ࡪࠦ࠿ࠡ࠽ࠪয়"),RR5JyxbWSOi21Vst4)
			else: RNS4lsuKk6Wa5MdA7jUIBixb9(qfznVTCRpxSDM85QGBHoU,FZ0zy7Cgeo1UjkR,AlI5YdVoWgZyP,BF6QAiLUNHh7rKOugaw,IpC4qHXRuyNFjzWv(u"ࠨࡆࡈࡐࡊ࡚ࡅࠡࡈࡕࡓࡒࠦࠢࠨৠ")+WSpGLu84ycrNdBYQezqmk3+EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠩࠥࠤ࡜ࡎࡅࡓࡇࠣࡧࡴࡲࡵ࡮ࡰࠣࡁࠥࡅࠠ࠼ࠩৡ"),RR5JyxbWSOi21Vst4)
	FZ0zy7Cgeo1UjkR.close()
	return
class BhSZ2uyPL0JnmsqowANj(): pass
class AutiwYdmGMSgL3lXTD(BhSZ2uyPL0JnmsqowANj):
	def __init__(k8BA0layVWnJ4De36HNSd2):
		k8BA0layVWnJ4De36HNSd2.url = iiy37aKq0pCEIOwfcTh61xb4U
		k8BA0layVWnJ4De36HNSd2.code = -FRYcH4KL7e9gv5pEB(u"࠾࠿ୂ")
		k8BA0layVWnJ4De36HNSd2.reason = iiy37aKq0pCEIOwfcTh61xb4U
		k8BA0layVWnJ4De36HNSd2.content = iiy37aKq0pCEIOwfcTh61xb4U
		k8BA0layVWnJ4De36HNSd2.headers = {}
		k8BA0layVWnJ4De36HNSd2.cookies = {}
		k8BA0layVWnJ4De36HNSd2.succeeded = BF6QAiLUNHh7rKOugaw
def c9ho5RAHxMTPyqOd(EGJVsZy38Xx):
	if EGJVsZy38Xx==MgP8OjoaiWQEVG59(u"ࠪࡨ࡮ࡩࡴࠨৢ"): oRzlSfeE6DY0mFy37NCVxAJW1BwZtM = {}
	elif EGJVsZy38Xx==jXE2YHkswT8y(u"ࠫࡱ࡯ࡳࡵࠩৣ"): oRzlSfeE6DY0mFy37NCVxAJW1BwZtM = []
	elif EGJVsZy38Xx==uuExaKGL7UONtevRd(u"ࠬࡺࡵࡱ࡮ࡨࠫ৤"): oRzlSfeE6DY0mFy37NCVxAJW1BwZtM = ()
	elif EGJVsZy38Xx==PtkEvXAqif14G20QZsaSyT(u"࠭ࡳࡵࡴࠪ৥"): oRzlSfeE6DY0mFy37NCVxAJW1BwZtM = iiy37aKq0pCEIOwfcTh61xb4U
	elif EGJVsZy38Xx==ZchUJdM93pTA7zG5(u"ࠧࡪࡰࡷࠫ০"): oRzlSfeE6DY0mFy37NCVxAJW1BwZtM = FGTfwsjNrB8DvKSZhLIQAb1JnO
	elif EGJVsZy38Xx==sVzojQerUqX(u"ࠨࡴࡨࡷࡵࡵ࡮ࡴࡧࠪ১"): oRzlSfeE6DY0mFy37NCVxAJW1BwZtM = AutiwYdmGMSgL3lXTD()
	elif not EGJVsZy38Xx: oRzlSfeE6DY0mFy37NCVxAJW1BwZtM = None
	else: oRzlSfeE6DY0mFy37NCVxAJW1BwZtM = None
	return oRzlSfeE6DY0mFy37NCVxAJW1BwZtM
def EETfYmdIcBQsXGiLzpODJxr35e(dxv3KocV5rOSmITLatDR):
	IIynmkO7rpajiYdtF1N6uDBE3hWL92 = OXsckY7RzjCag9A.getSetting(TlGXWLYsV1z(u"ࠩࡤࡺ࠳ࡶࡲࡪࡸࡶ࠵ࠬ২"))
	C3ts4rlVjfcygPEiW6Ywb5KAh7pDO = iw3BpJl1Y9tbg8XMR4VeoS6kEUhf.splitlines()
	TU5J0BgnW2xrAPdLjoe4KymzqwYN6 = FGTfwsjNrB8DvKSZhLIQAb1JnO
	o2oZMyNALwBYQCXj4z38sTDg = len(dxv3KocV5rOSmITLatDR)
	lAro7n9bksuiTdUp6qXP0hgDz = [BF6QAiLUNHh7rKOugaw]*o2oZMyNALwBYQCXj4z38sTDg
	for JFWNBnjX0vGl98DoEpS7cRbIdsxymk in [pwXCQWuGUMka2hFN,pwXCQWuGUMka2hFN-r3rnfZ7cdxzNFebIRaLSG6B]:
		f3fx5DtdcGiJFTsVz8OAun4 = str(JFWNBnjX0vGl98DoEpS7cRbIdsxymk*sVzojQerUqX(u"࠱࠱࠲࠳࠴࠵࠴࠰ୄ")/tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"࠺࠳࠳࠲࠳࠴ୃ"))[FGTfwsjNrB8DvKSZhLIQAb1JnO:ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"࠵୅")]
		if f3fx5DtdcGiJFTsVz8OAun4!=TU5J0BgnW2xrAPdLjoe4KymzqwYN6:
			for ba3If2JElOq0nNPWBkXC6dH in range(o2oZMyNALwBYQCXj4z38sTDg):
				if not lAro7n9bksuiTdUp6qXP0hgDz[ba3If2JElOq0nNPWBkXC6dH]:
					zxhLWvnMpYmajICB = BF6QAiLUNHh7rKOugaw
					for E5VIAxUbJYuwmyNOHjhte16KMsFfS in C3ts4rlVjfcygPEiW6Ywb5KAh7pDO:
						uI6OjE2bfsWli78VxzDT9dNR4m = AbqCJZdWQP9j(u"ࠪ࡜࠶࠿ࠧ৩")+dxv3KocV5rOSmITLatDR[ba3If2JElOq0nNPWBkXC6dH]+MgP8OjoaiWQEVG59(u"ࠫ࠶࠾࠽ࠨ৪")+E5VIAxUbJYuwmyNOHjhte16KMsFfS[-ZchUJdM93pTA7zG5(u"࠴࠷୆"):]+DdAjF5pBNL9IqPgkz0xhcQEfU+f3fx5DtdcGiJFTsVz8OAun4
						uI6OjE2bfsWli78VxzDT9dNR4m = WWbKa0cgvFOURDoHIEV3uhipsJ96.md5(uI6OjE2bfsWli78VxzDT9dNR4m.encode(df6QpwGxuJVZr)).hexdigest()[:HtK4o2sTPgA78U(u"࠶࠶େ")]
						if uI6OjE2bfsWli78VxzDT9dNR4m in IIynmkO7rpajiYdtF1N6uDBE3hWL92:
							zxhLWvnMpYmajICB = rGPen6cSMHQkAywh8vqI9JXiD2
							break
					lAro7n9bksuiTdUp6qXP0hgDz[ba3If2JElOq0nNPWBkXC6dH] = zxhLWvnMpYmajICB
		TU5J0BgnW2xrAPdLjoe4KymzqwYN6 = f3fx5DtdcGiJFTsVz8OAun4
	return lAro7n9bksuiTdUp6qXP0hgDz
class AopjiwhR30bv8Pax4EJKclDLTIm1M(eVvIKwBWTu1JphDX5OMjCx):
	def __init__(k8BA0layVWnJ4De36HNSd2): pass
	def e20faZPhsVjXmGK9DOzrkUicgQl(k8BA0layVWnJ4De36HNSd2,ZjgeiO5lGA4DQRuJEM):
		k8BA0layVWnJ4De36HNSd2.F580IoCg1UKz = jXE2YHkswT8y(u"ࠬࡨ࡬ࡰࡥ࡮ࡩࡩ࠭৫") if IiCsQD91HF.bbrnyC5Bz9Vqgc0fFYuZ6QNEMvXK7 else iiy37aKq0pCEIOwfcTh61xb4U
		k8BA0layVWnJ4De36HNSd2.ZjgeiO5lGA4DQRuJEM = ZjgeiO5lGA4DQRuJEM
		if not IiCsQD91HF.ic2FB5X43kWzyTKtNE:
			import braVAkwfBN
			braVAkwfBN.fNqmjxDcp1Q8tPsHiKhIg20au4FzAS(Qfob9ThC6ryqKkYZ)
	def onPlayBackStopped(k8BA0layVWnJ4De36HNSd2): k8BA0layVWnJ4De36HNSd2.F580IoCg1UKz = CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭৬")
	def onPlayBackError(k8BA0layVWnJ4De36HNSd2): k8BA0layVWnJ4De36HNSd2.F580IoCg1UKz = hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠧࡧࡣ࡬ࡰࡪࡪࠧ৭")
	def onPlayBackEnded(k8BA0layVWnJ4De36HNSd2): k8BA0layVWnJ4De36HNSd2.F580IoCg1UKz = uuExaKGL7UONtevRd(u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨ৮")
	def onPlayBackStarted(k8BA0layVWnJ4De36HNSd2):
		k8BA0layVWnJ4De36HNSd2.F580IoCg1UKz = JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠩࡶࡸࡦࡸࡴࡦࡦࠪ৯")
		SfH8aUN2lnOyFXG1MiLj = EEehSFDLdpKBR3W1ga9PxrV.Thread(target=k8BA0layVWnJ4De36HNSd2.XoLa5Bm1Kx0T9qIrS,args=())
		SfH8aUN2lnOyFXG1MiLj.start()
	def onAVStarted(k8BA0layVWnJ4De36HNSd2):
		if IiCsQD91HF.ic2FB5X43kWzyTKtNE: k8BA0layVWnJ4De36HNSd2.F580IoCg1UKz = hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠪࡴࡱࡧࡹࡪࡰࡪࠫৰ")
		else: k8BA0layVWnJ4De36HNSd2.F580IoCg1UKz = L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠫࡹ࡫ࡳࡵ࡫ࡱ࡫ࠬৱ")
	def XoLa5Bm1Kx0T9qIrS(k8BA0layVWnJ4De36HNSd2):
		aolOvjwC6d(HtK4o2sTPgA78U(u"ࠬࡹࡴࡰࡲࠪ৲"))
		dNREKhDVMlFgrizCyvPtXm = FGTfwsjNrB8DvKSZhLIQAb1JnO
		while not eval(FRYcH4KL7e9gv5pEB(u"࠭ࡸࡣ࡯ࡦ࠲ࡕࡲࡡࡺࡧࡵࠬ࠮࠴ࡩࡴࡒ࡯ࡥࡾ࡯࡮ࡨࠪࠬࠫ৳"),{tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠧࡹࡤࡰࡧࠬ৴"):WwMgozBIC32n9d0tyfp}) and k8BA0layVWnJ4De36HNSd2.F580IoCg1UKz==TlGXWLYsV1z(u"ࠨࡵࡷࡥࡷࡺࡥࡥࠩ৵"):
			WwMgozBIC32n9d0tyfp.sleep(zmcGfOdvAjsELeJlP(u"࠵࠵࠶࠰ୈ"))
			dNREKhDVMlFgrizCyvPtXm += YYJQyRskpX8jv
			if dNREKhDVMlFgrizCyvPtXm>TlGXWLYsV1z(u"࠻࠶୉"): return
		if IiCsQD91HF.bbrnyC5Bz9Vqgc0fFYuZ6QNEMvXK7: k8BA0layVWnJ4De36HNSd2.F580IoCg1UKz = sVzojQerUqX(u"ࠩࡥࡰࡴࡩ࡫ࡦࡦࠪ৶")
		elif IiCsQD91HF.ic2FB5X43kWzyTKtNE: k8BA0layVWnJ4De36HNSd2.F580IoCg1UKz = jXE2YHkswT8y(u"ࠪࡴࡱࡧࡹࡪࡰࡪࠫ৷")
		elif IiCsQD91HF.e8cB3UpjldxMI:
			import braVAkwfBN
			k8BA0layVWnJ4De36HNSd2.F580IoCg1UKz = yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠫࡹ࡫ࡳࡵ࡫ࡱ࡫ࠬ৸")
			KLUY2gxEHy8 = EEehSFDLdpKBR3W1ga9PxrV.Thread(target=braVAkwfBN.YmERob4iJnGaBC3HylOV9PKu1I,args=(k8BA0layVWnJ4De36HNSd2.ZjgeiO5lGA4DQRuJEM,))
			KLUY2gxEHy8.start()
			ccBdIeF6QS8pG7fPoUqHZ = EEehSFDLdpKBR3W1ga9PxrV.Thread(target=braVAkwfBN.SmXxLw7l2gIUR9zF83hTNdpMaA6i,args=())
			ccBdIeF6QS8pG7fPoUqHZ.start()
		else: k8BA0layVWnJ4De36HNSd2.F580IoCg1UKz = sVzojQerUqX(u"ࠬࡨ࡬ࡰࡥ࡮ࡩࡩ࠭৹")
def FW1E8exYu7Q5yod():
	tG31nDuf9YMI0PHZm2Ox,GwlOZp1TRYqI = iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U
	vvjg8aws3ldME7Uzfq = WwMgozBIC32n9d0tyfp.getInfoLabel(GGx4qyKP1vUtRghsE2WfaHLMXZ(u"࠭ࡓࡺࡵࡷࡩࡲ࠴ࡆࡳ࡫ࡨࡲࡩࡲࡹࡏࡣࡰࡩࠬ৺"))
	try:
		KKJLY3BhaoV7rGZW1sDNy9i6eEPH = open(GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠧ࠰ࡲࡵࡳࡨ࠵ࡣࡱࡷ࡬ࡲ࡫ࡵࠧ৻"),ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠨࡴࡥࠫৼ")).read()
		if J1MoiYc7ZwzKS: KKJLY3BhaoV7rGZW1sDNy9i6eEPH = KKJLY3BhaoV7rGZW1sDNy9i6eEPH.decode(df6QpwGxuJVZr)
		QXrZMKaOVupb1qLwPyGojlxCB85it4 = dEyT9xhGjolYzLCH7460w3.findall(xpT28sXu051(u"ࠩࡖࡩࡷ࡯ࡡ࡭࠰࠭ࡃ࠿ࠦࠨ࠯ࠬࡂ࠭ࠩ࠭৽"),KKJLY3BhaoV7rGZW1sDNy9i6eEPH,dEyT9xhGjolYzLCH7460w3.IGNORECASE)
		if QXrZMKaOVupb1qLwPyGojlxCB85it4: tG31nDuf9YMI0PHZm2Ox = QXrZMKaOVupb1qLwPyGojlxCB85it4[FGTfwsjNrB8DvKSZhLIQAb1JnO]
	except: pass
	try:
		import subprocess as AfJFuoBEkn8h0iGbZ1sQ7MKl
		qng0R2QYioPpLydJV5GNKj7vur = AfJFuoBEkn8h0iGbZ1sQ7MKl.Popen(XrTw01KtLzbpoyMf(u"ࠪࡷࡹࡧࡴࠡ࠯ࡦࠤ࡙ࠧࠦࠥࠢࠥࠤ࠴ࡹࡴࡰࡴࡤ࡫ࡪ࠵ࡥ࡮ࡷ࡯ࡥࡹ࡫ࡤ࠰࠲ࠣ࠿ࠥࡹࡴࡢࡶࠣ࠱ࡨ࡚ࠦࠢࠡࠧࠤࠧࠦ࠯ࡷࡣࡵ࠳ࡱࡵࡧࠨ৾"),shell=rGPen6cSMHQkAywh8vqI9JXiD2,stdin=AfJFuoBEkn8h0iGbZ1sQ7MKl.PIPE,stdout=AfJFuoBEkn8h0iGbZ1sQ7MKl.PIPE,stderr=AfJFuoBEkn8h0iGbZ1sQ7MKl.PIPE)
		RoB3TH5E2eZKPViaULQmcgk = qng0R2QYioPpLydJV5GNKj7vur.stdout.read()
		if RoB3TH5E2eZKPViaULQmcgk:
			if J1MoiYc7ZwzKS:
				RoB3TH5E2eZKPViaULQmcgk = RoB3TH5E2eZKPViaULQmcgk.decode(df6QpwGxuJVZr,y6y5HtgXO4TkUbwVZ(u"ࠫ࡮࡭࡮ࡰࡴࡨࠫ৿"))
			q6ouZvPtVUHjhfa5zcxXA32108lweK = dEyT9xhGjolYzLCH7460w3.findall(Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠬࠦࠨ࡝ࡦࡾ࠵࠵ࢃࠩࠡࠩ਀"),RoB3TH5E2eZKPViaULQmcgk,dEyT9xhGjolYzLCH7460w3.IGNORECASE)
			if q6ouZvPtVUHjhfa5zcxXA32108lweK: GwlOZp1TRYqI = min(q6ouZvPtVUHjhfa5zcxXA32108lweK)
	except: pass
	return vvjg8aws3ldME7Uzfq,tG31nDuf9YMI0PHZm2Ox,GwlOZp1TRYqI
def GmTZdMqCPhJs3pUcgS4tBOki(lf8S7dFRxyhQK=rGPen6cSMHQkAywh8vqI9JXiD2,iiKw16BHkPTU=uuExaKGL7UONtevRd(u"࠹࠲୊")):
	g5J70TGfUXS3as6V = rGPen6cSMHQkAywh8vqI9JXiD2
	if lf8S7dFRxyhQK:
		xlQ7C3mqvojrBA = QKzCiBOWZus1nSv(PdkZHNBlpg2b7DmX6qRiyVa,LyNiIHPOwD3hCUYEFM7(u"࠭࡬ࡪࡵࡷࠫਁ"),uuExaKGL7UONtevRd(u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪਂ"),HtK4o2sTPgA78U(u"ࠨࡕࡌࡘࡊ࡙࡟ࡄࡊࡈࡇࡐ࠭ਃ"))
		if xlQ7C3mqvojrBA:
			C3ts4rlVjfcygPEiW6Ywb5KAh7pDO,Ua4j1snIzVxKhcd6QrHyv,CMFshWbt92OPBUV,VYzlCXFoEJfIKQkb = xlQ7C3mqvojrBA
			g5J70TGfUXS3as6V = QKzCiBOWZus1nSv(PdkZHNBlpg2b7DmX6qRiyVa,jXE2YHkswT8y(u"ࠩ࡯࡭ࡸࡺࠧ਄"),HtK4o2sTPgA78U(u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭ਅ"),HtK4o2sTPgA78U(u"ࠫࡘࡏࡔࡆࡕࡢ࡚ࡊࡘࡉࡇ࡛ࠪਆ"))
			if g5J70TGfUXS3as6V: vvjg8aws3ldME7Uzfq,tG31nDuf9YMI0PHZm2Ox,GwlOZp1TRYqI = g5J70TGfUXS3as6V
			else: vvjg8aws3ldME7Uzfq,tG31nDuf9YMI0PHZm2Ox,GwlOZp1TRYqI = FW1E8exYu7Q5yod()
			if (Ua4j1snIzVxKhcd6QrHyv,CMFshWbt92OPBUV,VYzlCXFoEJfIKQkb)==(vvjg8aws3ldME7Uzfq,tG31nDuf9YMI0PHZm2Ox,GwlOZp1TRYqI): return OTlVEGYPSxsNaBdXUucqA3.join(C3ts4rlVjfcygPEiW6Ywb5KAh7pDO)
	if g5J70TGfUXS3as6V: vvjg8aws3ldME7Uzfq,tG31nDuf9YMI0PHZm2Ox,GwlOZp1TRYqI = FW1E8exYu7Q5yod()
	global g3vPMjAlz0iVROScQd,llf0QUZqLYi6zG4Xb8E
	g3vPMjAlz0iVROScQd,llf0QUZqLYi6zG4Xb8E,tiC178JnEsySa5zufVdMmLHUOKGAw = iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U
	iiKw16BHkPTU = iiKw16BHkPTU//nI2JK1RfsGWNY3OarEeMQZ
	EEehSFDLdpKBR3W1ga9PxrV.Thread(target=VKWBvmHGTdAr2R).start()
	EEehSFDLdpKBR3W1ga9PxrV.Thread(target=AXRzStGfJw9OWQvMPcN8Cd).start()
	for o6oXFxmE1bQC in range(YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"࠱࠱ୋ")):
		X2cQ5NCPvkMieBW7oASspFjE.sleep(y6y5HtgXO4TkUbwVZ(u"࠱࠰࠸ୌ"))
		if not tiC178JnEsySa5zufVdMmLHUOKGAw:
			try:
				oTYGVEQgk3M = WwMgozBIC32n9d0tyfp.getInfoLabel(tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠬࡔࡥࡵࡹࡲࡶࡰ࠴ࡍࡢࡥࡄࡨࡩࡸࡥࡴࡵࠪਇ"))
				if oTYGVEQgk3M.count(EMO8gy4LrsNTh0knZwpSeU75APW(u"࠭࠺ࠨਈ"))==UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"࠸୎") and oTYGVEQgk3M.count(MgP8OjoaiWQEVG59(u"ࠧ࠱ࠩਉ"))<hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"࠻୍"):
					oTYGVEQgk3M = oTYGVEQgk3M.lower().replace(hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠨ࠼ࠪਊ"),iiy37aKq0pCEIOwfcTh61xb4U)
					tiC178JnEsySa5zufVdMmLHUOKGAw = str(int(oTYGVEQgk3M,yJeq1BjfiO4NFuwIEzxVLK6b9s(u"࠵࠻୏")))
			except: pass
		if g3vPMjAlz0iVROScQd and llf0QUZqLYi6zG4Xb8E and tiC178JnEsySa5zufVdMmLHUOKGAw: break
	J1Ob4LwfEUzKvNixlkVs9pauYMqF7 = [llf0QUZqLYi6zG4Xb8E,g3vPMjAlz0iVROScQd,tiC178JnEsySa5zufVdMmLHUOKGAw,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,uuExaKGL7UONtevRd(u"ࠩ࠳࠴࠶࠷࠲࠳࠵࠶࠸࠹࠻࠵࠷࠸࠺࠻ࠬ਋")]
	if tG31nDuf9YMI0PHZm2Ox or GwlOZp1TRYqI:
		JkKlsxBamZp = [(pZWli1xqfVtvzuSU6ImNw53gBFsh,tG31nDuf9YMI0PHZm2Ox),(IpC4qHXRuyNFjzWv(u"࠺୐"),GwlOZp1TRYqI)]
		for Onuh30WYrigx,NHgSFB4E0lmtyDdswYiIUeCqp5J in JkKlsxBamZp:
			NHgSFB4E0lmtyDdswYiIUeCqp5J = NHgSFB4E0lmtyDdswYiIUeCqp5J.strip(tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠪ࠴ࠬ਌"))
			if NHgSFB4E0lmtyDdswYiIUeCqp5J:
				if J1MoiYc7ZwzKS: NHgSFB4E0lmtyDdswYiIUeCqp5J = NHgSFB4E0lmtyDdswYiIUeCqp5J.encode(df6QpwGxuJVZr)
				NHgSFB4E0lmtyDdswYiIUeCqp5J = str(int(WWbKa0cgvFOURDoHIEV3uhipsJ96.md5(NHgSFB4E0lmtyDdswYiIUeCqp5J).hexdigest(),ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"࠹࠶୑")))
				AAhj7icVWZey = [int(NHgSFB4E0lmtyDdswYiIUeCqp5J[EH73GpPYOsZMgXDU:EH73GpPYOsZMgXDU+MgP8OjoaiWQEVG59(u"࠲࠷୓")]) for EH73GpPYOsZMgXDU in range(len(NHgSFB4E0lmtyDdswYiIUeCqp5J)) if EH73GpPYOsZMgXDU%MgP8OjoaiWQEVG59(u"࠲࠷୓")==yJeq1BjfiO4NFuwIEzxVLK6b9s(u"࠰୒")]
				J1Ob4LwfEUzKvNixlkVs9pauYMqF7[Onuh30WYrigx-YYJQyRskpX8jv] = str(sum(AAhj7icVWZey))
	C3ts4rlVjfcygPEiW6Ywb5KAh7pDO,MA1YVnsx74Lj = [],BF6QAiLUNHh7rKOugaw
	for OJLonGRMcSiAy4sVHv2BwN3tfxaP9e,AAhj7icVWZey in enumerate(J1Ob4LwfEUzKvNixlkVs9pauYMqF7):
		if not AAhj7icVWZey: continue
		if MA1YVnsx74Lj and AAhj7icVWZey==J1Ob4LwfEUzKvNixlkVs9pauYMqF7[-YYJQyRskpX8jv]: continue
		MA1YVnsx74Lj = rGPen6cSMHQkAywh8vqI9JXiD2
		AAhj7icVWZey = GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠫ࠵࠭਍")*iiKw16BHkPTU+AAhj7icVWZey
		AAhj7icVWZey = AAhj7icVWZey[-iiKw16BHkPTU:]
		Ky8kTBNSe6uX,HSj4YG0lzrXIU7 = iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U
		eLCEXaVvjwolcy82kJuMtiS = str(int(tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠬ࠿ࠧ਎")*(iiKw16BHkPTU+YYJQyRskpX8jv))-int(AAhj7icVWZey))[-iiKw16BHkPTU:]
		for ba3If2JElOq0nNPWBkXC6dH in list(range(FGTfwsjNrB8DvKSZhLIQAb1JnO,iiKw16BHkPTU,pZWli1xqfVtvzuSU6ImNw53gBFsh)):
			Ky8kTBNSe6uX += eLCEXaVvjwolcy82kJuMtiS[ba3If2JElOq0nNPWBkXC6dH:ba3If2JElOq0nNPWBkXC6dH+pZWli1xqfVtvzuSU6ImNw53gBFsh]+LyNiIHPOwD3hCUYEFM7(u"࠭࠭ࠨਏ")
			HSj4YG0lzrXIU7 += str(sum(map(int,AAhj7icVWZey[ba3If2JElOq0nNPWBkXC6dH:ba3If2JElOq0nNPWBkXC6dH+pZWli1xqfVtvzuSU6ImNw53gBFsh]))%CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"࠳࠳୔"))
		E5VIAxUbJYuwmyNOHjhte16KMsFfS = str(OJLonGRMcSiAy4sVHv2BwN3tfxaP9e)+Ky8kTBNSe6uX+HSj4YG0lzrXIU7
		C3ts4rlVjfcygPEiW6Ywb5KAh7pDO.append(E5VIAxUbJYuwmyNOHjhte16KMsFfS)
	qAsLUlPiOIpjt0,qRbalkUDdxcvSeOgw = [],[]
	for user in C3ts4rlVjfcygPEiW6Ywb5KAh7pDO:
		count = str(str(C3ts4rlVjfcygPEiW6Ywb5KAh7pDO).count(user[GGx4qyKP1vUtRghsE2WfaHLMXZ(u"࠴୕"):]))
		qAsLUlPiOIpjt0.append(count+user)
	qAsLUlPiOIpjt0 = sorted(qAsLUlPiOIpjt0,reverse=MgP8OjoaiWQEVG59(u"ࡖࡵࡹࡪ୾"),key=lambda key: key[FRYcH4KL7e9gv5pEB(u"࠴ୖ")])
	for user in qAsLUlPiOIpjt0: qRbalkUDdxcvSeOgw.append(user[EMO8gy4LrsNTh0knZwpSeU75APW(u"࠶ୗ"):])
	YMQXP2BGeK86CEb(PdkZHNBlpg2b7DmX6qRiyVa,TlGXWLYsV1z(u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪਐ"),UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠨࡕࡌࡘࡊ࡙࡟ࡗࡇࡕࡍࡋ࡟ࠧ਑"),[vvjg8aws3ldME7Uzfq,tG31nDuf9YMI0PHZm2Ox,GwlOZp1TRYqI],PNjZMS7nxa9clHusz1)
	YMQXP2BGeK86CEb(PdkZHNBlpg2b7DmX6qRiyVa,EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬ਒"),y6y5HtgXO4TkUbwVZ(u"ࠪࡗࡎ࡚ࡅࡔࡡࡆࡌࡊࡉࡋࠨਓ"),[qRbalkUDdxcvSeOgw,vvjg8aws3ldME7Uzfq,tG31nDuf9YMI0PHZm2Ox,GwlOZp1TRYqI],Dxc7GChQwZ4kOlKHSbL06agnB)
	for user in TPFpytsjLd57U:
		if user in qRbalkUDdxcvSeOgw: qRbalkUDdxcvSeOgw.remove(user)
	return OTlVEGYPSxsNaBdXUucqA3.join(qRbalkUDdxcvSeOgw)
def VKWBvmHGTdAr2R():
	global g3vPMjAlz0iVROScQd
	import getmac82 as dCkGXYZsVrz
	try:
		uHbPOMy2rEZeVd1lJ8Yi0Bk = dCkGXYZsVrz.get_mac_address()
		if uHbPOMy2rEZeVd1lJ8Yi0Bk.count(HtK4o2sTPgA78U(u"ࠫ࠿࠭ਔ"))==PtkEvXAqif14G20QZsaSyT(u"࠵୙") and uHbPOMy2rEZeVd1lJ8Yi0Bk.count(FRYcH4KL7e9gv5pEB(u"ࠬ࠶ࠧਕ"))<uuExaKGL7UONtevRd(u"࠿୘"):
			uHbPOMy2rEZeVd1lJ8Yi0Bk = uHbPOMy2rEZeVd1lJ8Yi0Bk.lower().replace(hhQwbeiNLoqFjX90fB7aG8VAs(u"࠭࠺ࠨਖ"),iiy37aKq0pCEIOwfcTh61xb4U)
			g3vPMjAlz0iVROScQd = str(int(uHbPOMy2rEZeVd1lJ8Yi0Bk,FRYcH4KL7e9gv5pEB(u"࠲࠸୚")))
	except: pass
	return
def AXRzStGfJw9OWQvMPcN8Cd():
	global llf0QUZqLYi6zG4Xb8E
	import getmac94 as isceBA1M57gFTYmD8Q2HpEOjnUP
	try:
		k0clKj8gsJpXT9trI5V6PYmE1U7zb = isceBA1M57gFTYmD8Q2HpEOjnUP.get_mac_address()
		if k0clKj8gsJpXT9trI5V6PYmE1U7zb.count(SaB5hx3PZwXRLtKgrTfQvId(u"ࠧ࠻ࠩਗ"))==JZszNnIEMAx28Yao0yqhiXGKOPb(u"࠸ଡ଼") and k0clKj8gsJpXT9trI5V6PYmE1U7zb.count(L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠨ࠲ࠪਘ"))<ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"࠻୛"):
			k0clKj8gsJpXT9trI5V6PYmE1U7zb = k0clKj8gsJpXT9trI5V6PYmE1U7zb.lower().replace(xpT28sXu051(u"ࠩ࠽ࠫਙ"),iiy37aKq0pCEIOwfcTh61xb4U)
			llf0QUZqLYi6zG4Xb8E = str(int(k0clKj8gsJpXT9trI5V6PYmE1U7zb,AbqCJZdWQP9j(u"࠵࠻ଢ଼")))
	except: pass
	return
def ri8uRdOU0kNfq4(EGJVsZy38Xx,smglbwR7x2oM,oRzlSfeE6DY0mFy37NCVxAJW1BwZtM,CZGXVf91e3KTpSDqyP6x8otlhLBam2,VamqUtbfFn6MANy,bDlzGospmi69Oy1NILPaHMWK8Z3FSw):
	rzR9SN7ApZuQhTDWEX3V6ga = str(CZGXVf91e3KTpSDqyP6x8otlhLBam2)[FGTfwsjNrB8DvKSZhLIQAb1JnO:zmcGfOdvAjsELeJlP(u"࠷࠻࠰୞")].replace(OTlVEGYPSxsNaBdXUucqA3,UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠪࡠࡡࡴࠧਚ")).replace(Mge0HhFk9Ic6sm5VR,hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠫࡡࡢࡲࠨਛ")).replace(hnVQObwUcR207fC,iFBmE2MUIpSu34wsd7Rf6z).replace(jHLaUg49SXC6JyTM,iFBmE2MUIpSu34wsd7Rf6z)
	if len(str(CZGXVf91e3KTpSDqyP6x8otlhLBam2))>ZchUJdM93pTA7zG5(u"࠸࠵࠱ୟ"): rzR9SN7ApZuQhTDWEX3V6ga = rzR9SN7ApZuQhTDWEX3V6ga+TlGXWLYsV1z(u"ࠬࠦ࠮࠯࠰ࠪਜ")
	EwsmJ67cCYDIlg = str(oRzlSfeE6DY0mFy37NCVxAJW1BwZtM)[FGTfwsjNrB8DvKSZhLIQAb1JnO:yJeq1BjfiO4NFuwIEzxVLK6b9s(u"࠲࠶࠲ୠ")].replace(OTlVEGYPSxsNaBdXUucqA3,AbqCJZdWQP9j(u"࠭࡜࡝ࡰࠪਝ")).replace(Mge0HhFk9Ic6sm5VR,GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠧ࡝࡞ࡵࠫਞ")).replace(hnVQObwUcR207fC,iFBmE2MUIpSu34wsd7Rf6z).replace(jHLaUg49SXC6JyTM,iFBmE2MUIpSu34wsd7Rf6z)
	if len(str(oRzlSfeE6DY0mFy37NCVxAJW1BwZtM))>hhQwbeiNLoqFjX90fB7aG8VAs(u"࠳࠷࠳ୡ"): EwsmJ67cCYDIlg = EwsmJ67cCYDIlg+ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠨࠢ࠱࠲࠳࠭ਟ")
	WKquk5EaNr4RzVf(q1rohYuwnfpVZUa98L2CtQzmAcB,ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠩࡒࡔࡊࡔࡕࡓࡎࡢࠫਠ")+EGJVsZy38Xx+tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠪࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭ਡ")+smglbwR7x2oM+AbqCJZdWQP9j(u"ࠫࠥࡣࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭ਢ")+VamqUtbfFn6MANy+ZchUJdM93pTA7zG5(u"ࠬࠦ࡝ࠡࠢࠣࡑࡪࡺࡨࡰࡦ࠽ࠤࡠࠦࠧਣ")+bDlzGospmi69Oy1NILPaHMWK8Z3FSw+ZchUJdM93pTA7zG5(u"࠭ࠠ࡞ࠢࠣࠤࡍ࡫ࡡࡥࡧࡵࡷ࠿࡛ࠦࠡࠩਤ")+str(rzR9SN7ApZuQhTDWEX3V6ga)+xpT28sXu051(u"ࠧࠡ࡟ࠣࠤࠥࡊࡡࡵࡣ࠽ࠤࡠࠦࠧਥ")+EwsmJ67cCYDIlg+uuExaKGL7UONtevRd(u"ࠨࠢࡠࠫਦ"))
	return
def gOjQKfpoJqdCBWl7(bDlzGospmi69Oy1NILPaHMWK8Z3FSw,smglbwR7x2oM,oRzlSfeE6DY0mFy37NCVxAJW1BwZtM=iiy37aKq0pCEIOwfcTh61xb4U,CZGXVf91e3KTpSDqyP6x8otlhLBam2=iiy37aKq0pCEIOwfcTh61xb4U,VamqUtbfFn6MANy=iiy37aKq0pCEIOwfcTh61xb4U):
	ri8uRdOU0kNfq4(EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠩࡘࡖࡑࡒࡉࡃ࡞ࡷࡠࡹࡕࡐࡆࡐࡢ࡙ࡗࡒࠧਧ"),smglbwR7x2oM,oRzlSfeE6DY0mFy37NCVxAJW1BwZtM,CZGXVf91e3KTpSDqyP6x8otlhLBam2,VamqUtbfFn6MANy,bDlzGospmi69Oy1NILPaHMWK8Z3FSw)
	if J1MoiYc7ZwzKS: import urllib.request as rjZ2mqJXAuQ
	else: import urllib2 as rjZ2mqJXAuQ
	if not CZGXVf91e3KTpSDqyP6x8otlhLBam2: CZGXVf91e3KTpSDqyP6x8otlhLBam2 = {TlGXWLYsV1z(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧਨ"):iiy37aKq0pCEIOwfcTh61xb4U}
	if not oRzlSfeE6DY0mFy37NCVxAJW1BwZtM: oRzlSfeE6DY0mFy37NCVxAJW1BwZtM = {}
	if bDlzGospmi69Oy1NILPaHMWK8Z3FSw==FRYcH4KL7e9gv5pEB(u"ࠫࡌࡋࡔࠨ਩"):
		smglbwR7x2oM = smglbwR7x2oM+tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠬࡅࠧਪ")+zzUnMebTFdNgB8hOwJmKxVj(oRzlSfeE6DY0mFy37NCVxAJW1BwZtM)
		oRzlSfeE6DY0mFy37NCVxAJW1BwZtM = None
	elif bDlzGospmi69Oy1NILPaHMWK8Z3FSw==AbqCJZdWQP9j(u"࠭ࡐࡐࡕࡗࠫਫ") and hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠧ࡫ࡵࡲࡲࠬਬ") in str(CZGXVf91e3KTpSDqyP6x8otlhLBam2):
		oRzlSfeE6DY0mFy37NCVxAJW1BwZtM = bHyN37Y82ZKVLOexBF.dumps(oRzlSfeE6DY0mFy37NCVxAJW1BwZtM)
		oRzlSfeE6DY0mFy37NCVxAJW1BwZtM = str(oRzlSfeE6DY0mFy37NCVxAJW1BwZtM).encode(df6QpwGxuJVZr)
	elif bDlzGospmi69Oy1NILPaHMWK8Z3FSw==vODxLKW5Ql6r4Fbm8(u"ࠨࡒࡒࡗ࡙࠭ਭ"):
		oRzlSfeE6DY0mFy37NCVxAJW1BwZtM = zzUnMebTFdNgB8hOwJmKxVj(oRzlSfeE6DY0mFy37NCVxAJW1BwZtM)
		oRzlSfeE6DY0mFy37NCVxAJW1BwZtM = oRzlSfeE6DY0mFy37NCVxAJW1BwZtM.encode(df6QpwGxuJVZr)
	try:
		wQmV7shBLPe6alkUqp = rjZ2mqJXAuQ.Request(smglbwR7x2oM,headers=CZGXVf91e3KTpSDqyP6x8otlhLBam2,data=oRzlSfeE6DY0mFy37NCVxAJW1BwZtM)
		VVznOTKE7NDIe0HGkg = rjZ2mqJXAuQ.urlopen(wQmV7shBLPe6alkUqp)
		HGQ5Ty9mlSLwed = VVznOTKE7NDIe0HGkg.read()
		RRLYX967TCPfySDoeF8pV3gANMGWuQ,LXSBswmknoDzdT1hQqlUie = ZchUJdM93pTA7zG5(u"࠴࠳࠴ୢ"),FRYcH4KL7e9gv5pEB(u"ࠩࡒࡏࠬਮ")
	except:
		HGQ5Ty9mlSLwed = iiy37aKq0pCEIOwfcTh61xb4U
		RRLYX967TCPfySDoeF8pV3gANMGWuQ,LXSBswmknoDzdT1hQqlUie = -YYJQyRskpX8jv,YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"࡙ࠪࡳࡱ࡮ࡰࡹࡱࠤࡊࡸࡲࡰࡴࠪਯ")
	WKquk5EaNr4RzVf(q1rohYuwnfpVZUa98L2CtQzmAcB,L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠫࡔࡖࡅࡏࡗࡕࡐࡤ࡛ࡒࡍࡎࡌࡆࡡࡺ࡜ࡵࡔࡈࡗࡕࡕࡎࡔࡇࠣࠤࡈࡵࡤࡦ࠼ࠣ࡟ࠥ࠭ਰ")+str(RRLYX967TCPfySDoeF8pV3gANMGWuQ)+zmcGfOdvAjsELeJlP(u"ࠬࠦ࡝ࠡࠢࠣࡖࡪࡧࡳࡰࡰ࠽ࠤࡠࠦࠧ਱")+LXSBswmknoDzdT1hQqlUie+sVzojQerUqX(u"࠭ࠠ࡞ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨਲ")+VamqUtbfFn6MANy+HtK4o2sTPgA78U(u"ࠧࠡ࡟ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭ਲ਼")+smglbwR7x2oM+EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠨࠢࡠࠫ਴"))
	if HGQ5Ty9mlSLwed and J1MoiYc7ZwzKS: HGQ5Ty9mlSLwed = HGQ5Ty9mlSLwed.decode(df6QpwGxuJVZr)
	return HGQ5Ty9mlSLwed
def xaP4EqIfl6ShL5B8(Scs9OlEC1XKfuQFvMHJDwPL58G):
	wtg34PqX7F = {
		L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠤࡸࡷࡪࡸ࡟ࡪࡦࠥਵ"):WQgeBZ8k7RsuIPdD,
		HtK4o2sTPgA78U(u"ࠥࡳࡸࡥࡶࡦࡴࡶ࡭ࡴࡴࠢਸ਼"):str(ZD1J5rN8u2wzdgqoyULm4),
		JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠦࡦࡶࡰࡠࡸࡨࡶࡸ࡯࡯࡯ࠤ਷"):DdAjF5pBNL9IqPgkz0xhcQEfU,
		GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠧࡪࡥࡷ࡫ࡦࡩࡤ࡬ࡡ࡮࡫࡯ࡽࠧਸ"):DdAjF5pBNL9IqPgkz0xhcQEfU,
		FRYcH4KL7e9gv5pEB(u"ࠨࡰ࡭ࡣࡷࡪࡴࡸ࡭ࠣਹ"): DdAjF5pBNL9IqPgkz0xhcQEfU,
		SaB5hx3PZwXRLtKgrTfQvId(u"ࠢࡤࡣࡵࡶ࡮࡫ࡲࠣ਺"):TlGXWLYsV1z(u"ࠣࡃࡕࡅࡇࡏࡃࡠࡘࡌࡈࡊࡕࡓࠣ਻"),
		yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠤ࡬ࡴ਼ࠧ"): GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠥࠨࡷ࡫࡭ࡰࡶࡨࠦ਽"),
		zmcGfOdvAjsELeJlP(u"ࠦࠩࡹ࡫ࡪࡲࡢࡹࡸ࡫ࡲࡠࡲࡵࡳࡵ࡫ࡲࡵ࡫ࡨࡷࡤࡹࡹ࡯ࡥࠥਾ"):BF6QAiLUNHh7rKOugaw
	}
	Bn9Ck36Yw0c8fKJV47SsPFlvaLi5 = []
	for nYj9DlqLkQsmS8xthp in Scs9OlEC1XKfuQFvMHJDwPL58G:
		QihHpX3jKr = wtg34PqX7F.copy()
		QihHpX3jKr[Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠬ࡫ࡶࡦࡰࡷࡣࡹࡿࡰࡦࠩਿ")] = nYj9DlqLkQsmS8xthp
		QihHpX3jKr[hhQwbeiNLoqFjX90fB7aG8VAs(u"࠭ࡥࡷࡧࡱࡸࡤࡶࡲࡰࡲࡨࡶࡹ࡯ࡥࡴࠩੀ")] = {CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠢࡆࡸࡨࡲࡹࡥࡎࡢ࡯ࡨࠦੁ"):nYj9DlqLkQsmS8xthp}
		QihHpX3jKr[jXE2YHkswT8y(u"ࠨࡷࡶࡩࡷࡥࡰࡳࡱࡳࡩࡷࡺࡩࡦࡵࠪੂ")] = {FRYcH4KL7e9gv5pEB(u"ࠤࡘࡷࡪࡸ࡟ࡆࡸࡨࡲࡹࡥࡎࡢ࡯ࡨࠦ੃"):nYj9DlqLkQsmS8xthp}
		Bn9Ck36Yw0c8fKJV47SsPFlvaLi5.append(QihHpX3jKr)
	F2Qx01DIvWKogHpYMbsGcr = str(ufTX72hK8Q63jSsJiqDm5.randrange(PtkEvXAqif14G20QZsaSyT(u"࠴࠵࠶࠷࠱࠲࠳࠴࠵࠶࠷࠱ୣ"),ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"࠽࠾࠿࠹࠺࠻࠼࠽࠾࠿࠹࠺୤")))
	oRzlSfeE6DY0mFy37NCVxAJW1BwZtM = {
		hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠥࡥࡵ࡯࡟࡬ࡧࡼࠦ੄"):hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠫ࠷࠻࠴ࡥࡦ࠶ࡥ࠹࠶࠹ࡥ࠺ࡥ࠺࠽࠷ࡤ࠵ࡧ࠴࠵࠼࡫ࡥ࠸࠺ࡦࡩࡧ࡬࠲࠺ࠩ੅"),
		vODxLKW5Ql6r4Fbm8(u"ࠧ࡯࡮ࡴࡧࡵࡸࡤ࡯ࡤࠣ੆"):F2Qx01DIvWKogHpYMbsGcr,
		YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠨࡥࡷࡧࡱࡸࡸࠨੇ"): Bn9Ck36Yw0c8fKJV47SsPFlvaLi5
	}
	CZGXVf91e3KTpSDqyP6x8otlhLBam2 = {sVzojQerUqX(u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭ੈ"):GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡪࡴࡱࡱࠫ੉")}
	smglbwR7x2oM = Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡵ࡯࠲࠯ࡣࡰࡴࡱ࡯ࡴࡶࡦࡨ࠲ࡨࡵ࡭࠰࠴࠲࡬ࡹࡺࡰࡢࡲ࡬ࠫ੊")
	HGQ5Ty9mlSLwed = gOjQKfpoJqdCBWl7(tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠪࡔࡔ࡙ࡔࠨੋ"),smglbwR7x2oM,oRzlSfeE6DY0mFy37NCVxAJW1BwZtM,CZGXVf91e3KTpSDqyP6x8otlhLBam2,XrTw01KtLzbpoyMf(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲࡙ࡅࡏࡆࡢࡅࡓࡇࡌ࡚ࡖࡌࡇࡘࡥࡅࡗࡇࡑࡘࡘ࠳࠱ࡴࡶࠪੌ"))
	return HGQ5Ty9mlSLwed
def DeIL3qoa2UBtYPb(hhMxKFyp3IBbVLvfi9,XiWJ2PTqvds4pBNebVrt98x):
	XiWJ2PTqvds4pBNebVrt98x = XiWJ2PTqvds4pBNebVrt98x.replace(tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠬࡴࡵ࡭࡮੍ࠪ"),AbqCJZdWQP9j(u"࠭ࡎࡰࡰࡨࠫ੎"))
	XiWJ2PTqvds4pBNebVrt98x = XiWJ2PTqvds4pBNebVrt98x.replace(IpC4qHXRuyNFjzWv(u"ࠧࡵࡴࡸࡩࠬ੏"),tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠨࡖࡵࡹࡪ࠭੐"))
	XiWJ2PTqvds4pBNebVrt98x = XiWJ2PTqvds4pBNebVrt98x.replace(sVzojQerUqX(u"ࠩࡩࡥࡱࡹࡥࠨੑ"),IpC4qHXRuyNFjzWv(u"ࠪࡊࡦࡲࡳࡦࠩ੒"))
	XiWJ2PTqvds4pBNebVrt98x = XiWJ2PTqvds4pBNebVrt98x.replace(AbqCJZdWQP9j(u"ࠫࡡ࠵ࠧ੓"),EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠬ࠵ࠧ੔"))
	try: AkLKwEuog3O8JDFlt6nGiN19aec0p = eval(XiWJ2PTqvds4pBNebVrt98x)
	except: AkLKwEuog3O8JDFlt6nGiN19aec0p = c9ho5RAHxMTPyqOd(hhMxKFyp3IBbVLvfi9)
	return AkLKwEuog3O8JDFlt6nGiN19aec0p
def vtTse5pbrQCKAWjdyJYiPzuOEwxlh():
	EGJVsZy38Xx,Toe5N9znWjQHmP4whguld,smglbwR7x2oM,y3qATZDQOch6db5WjnmrguflU,L95mrowGgdsD,zLEP9N4BOsVrXa,XiWJ2PTqvds4pBNebVrt98x,EALyNnv1Db4cUd8sQoZX2pmBVt7kM,XC10geOnQtwrs = Q4APpMirastonc6Wh1v2XOH3K(CzWIqm1YAcEa9gTSZ30fk27)
	ZEdj50uOAeXUWGCk = dEyT9xhGjolYzLCH7460w3.findall(UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"࠭࡜ࡥ࡞ࡧ࠾ࡡࡪ࡜ࡥࠢ࡟࡟࠴ࡉࡏࡍࡑࡕࡠࡢ࠭੕"),Toe5N9znWjQHmP4whguld,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if ZEdj50uOAeXUWGCk: Toe5N9znWjQHmP4whguld = Toe5N9znWjQHmP4whguld.split(ZEdj50uOAeXUWGCk[FGTfwsjNrB8DvKSZhLIQAb1JnO],sVzojQerUqX(u"࠶୥"))[YYJQyRskpX8jv]
	twMTcyzmOH61 = X2cQ5NCPvkMieBW7oASspFjE.strftime(sVzojQerUqX(u"ࠧࡠࠧࡰ࠲ࠪࡪ࡟ࠦࡊ࠽ࠩࡒࡥࠧ੖"),X2cQ5NCPvkMieBW7oASspFjE.localtime(pwXCQWuGUMka2hFN))
	Toe5N9znWjQHmP4whguld = Toe5N9znWjQHmP4whguld+twMTcyzmOH61
	QL43gdorzFVS9DkUfbvB1X = EGJVsZy38Xx,Toe5N9znWjQHmP4whguld,smglbwR7x2oM,y3qATZDQOch6db5WjnmrguflU,L95mrowGgdsD,zLEP9N4BOsVrXa,XiWJ2PTqvds4pBNebVrt98x,EALyNnv1Db4cUd8sQoZX2pmBVt7kM,XC10geOnQtwrs
	if wkMR5x1gTWEQIc6qHCa.path.exists(NWDbjPABRxu):
		dQ960sl5X13MFwW24jEtCBR = open(NWDbjPABRxu,tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠨࡴࡥࠫ੗")).read()
		if J1MoiYc7ZwzKS: dQ960sl5X13MFwW24jEtCBR = dQ960sl5X13MFwW24jEtCBR.decode(df6QpwGxuJVZr)
		dQ960sl5X13MFwW24jEtCBR = DeIL3qoa2UBtYPb(ZchUJdM93pTA7zG5(u"ࠩࡧ࡭ࡨࡺࠧ੘"),dQ960sl5X13MFwW24jEtCBR)
	else: dQ960sl5X13MFwW24jEtCBR = {}
	kvysZqlKXSPC = {}
	for SDC0jEVPRr6qHYQp7dM in list(dQ960sl5X13MFwW24jEtCBR.keys()):
		if SDC0jEVPRr6qHYQp7dM!=EGJVsZy38Xx: kvysZqlKXSPC[SDC0jEVPRr6qHYQp7dM] = dQ960sl5X13MFwW24jEtCBR[SDC0jEVPRr6qHYQp7dM]
		else:
			if Toe5N9znWjQHmP4whguld and Toe5N9znWjQHmP4whguld!=y6y5HtgXO4TkUbwVZ(u"ࠪ࠲࠳࠭ਖ਼"):
				O4P6kKtv0uXL = dQ960sl5X13MFwW24jEtCBR[SDC0jEVPRr6qHYQp7dM]
				if QL43gdorzFVS9DkUfbvB1X in O4P6kKtv0uXL:
					bsqXJ3iaf2dop5 = O4P6kKtv0uXL.index(QL43gdorzFVS9DkUfbvB1X)
					del O4P6kKtv0uXL[bsqXJ3iaf2dop5]
				nFrfKgIy7dlN2HDCOR5AQJiL9X4pT = [QL43gdorzFVS9DkUfbvB1X]+O4P6kKtv0uXL
				nFrfKgIy7dlN2HDCOR5AQJiL9X4pT = nFrfKgIy7dlN2HDCOR5AQJiL9X4pT[:ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"࠻࠰୦")]
				kvysZqlKXSPC[SDC0jEVPRr6qHYQp7dM] = nFrfKgIy7dlN2HDCOR5AQJiL9X4pT
			else: kvysZqlKXSPC[SDC0jEVPRr6qHYQp7dM] = dQ960sl5X13MFwW24jEtCBR[SDC0jEVPRr6qHYQp7dM]
	if EGJVsZy38Xx not in list(kvysZqlKXSPC.keys()): kvysZqlKXSPC[EGJVsZy38Xx] = [QL43gdorzFVS9DkUfbvB1X]
	kvysZqlKXSPC = str(kvysZqlKXSPC)
	if J1MoiYc7ZwzKS: kvysZqlKXSPC = kvysZqlKXSPC.encode(df6QpwGxuJVZr)
	open(NWDbjPABRxu,yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠫࡼࡨࠧਗ਼")).write(kvysZqlKXSPC)
	return
def zzUnMebTFdNgB8hOwJmKxVj(oRzlSfeE6DY0mFy37NCVxAJW1BwZtM):
	if J1MoiYc7ZwzKS: import urllib.parse as IdFBfnjs3uYDwKqbkvXtPG
	else: import urllib as IdFBfnjs3uYDwKqbkvXtPG
	U4izZHjRFhpsD = IdFBfnjs3uYDwKqbkvXtPG.urlencode(oRzlSfeE6DY0mFy37NCVxAJW1BwZtM)
	return U4izZHjRFhpsD
def PsD3IgluKFyvzMLoRT9j5hq2(O5Pwg3UFyX0k9E,KKxw6aJkTAFdDOeh3r=iiy37aKq0pCEIOwfcTh61xb4U,IXfvjBK2RAHbMlV36t=iiy37aKq0pCEIOwfcTh61xb4U):
	tNGEy8DzoQ9 = KKxw6aJkTAFdDOeh3r not in [AbqCJZdWQP9j(u"ࠬࡓ࠳ࡖࠩਜ਼"),uuExaKGL7UONtevRd(u"࠭ࡉࡑࡖ࡙ࠫੜ")]
	if not IXfvjBK2RAHbMlV36t: IXfvjBK2RAHbMlV36t = zmcGfOdvAjsELeJlP(u"ࠧࡷ࡫ࡧࡩࡴ࠭੝")
	y2boSPsYmFjZBJzWpMEica6HRD,QFHvuhgCAncSj3LX,nJbTDhsOq0fZNBwVR7etWG35 = zmcGfOdvAjsELeJlP(u"ࠨࡥࡤࡲࡨ࡫࡬ࡦࡦࠪਫ਼"),iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U
	if len(O5Pwg3UFyX0k9E)==iiCWLaJREureAlOkv:
		smglbwR7x2oM,SBK4b87qLWRuCpJ,nJbTDhsOq0fZNBwVR7etWG35 = O5Pwg3UFyX0k9E
		if SBK4b87qLWRuCpJ: QFHvuhgCAncSj3LX = UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠩࠣࠤ࡙ࠥࡵࡣࡶ࡬ࡸࡱ࡫࠺ࠡ࡝ࠣࠫ੟")+SBK4b87qLWRuCpJ+FRYcH4KL7e9gv5pEB(u"ࠪࠤࡢ࠭੠")
	else: smglbwR7x2oM,SBK4b87qLWRuCpJ,nJbTDhsOq0fZNBwVR7etWG35 = O5Pwg3UFyX0k9E,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U
	smglbwR7x2oM = smglbwR7x2oM.replace(PtkEvXAqif14G20QZsaSyT(u"ࠫࠪ࠸࠰ࠨ੡"),iFBmE2MUIpSu34wsd7Rf6z)
	asP7tCIR3S4wQ2ncHG0ZOVbNgWfhe6 = dVeG46wAnrtlpkbNPsvJ9(smglbwR7x2oM)
	if KKxw6aJkTAFdDOeh3r not in [UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠬࡊࡏࡘࡐࡏࡓࡆࡊࠧ੢"),y6y5HtgXO4TkUbwVZ(u"࠭ࡉࡑࡖ࡙ࠫ੣")]:
		if KKxw6aJkTAFdDOeh3r!=Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠧࡅࡑ࡚ࡒࡑࡕࡁࡅࠩ੤"): smglbwR7x2oM = smglbwR7x2oM.replace(iFBmE2MUIpSu34wsd7Rf6z,FRYcH4KL7e9gv5pEB(u"ࠨࠧ࠵࠴ࠬ੥"))
		WKquk5EaNr4RzVf(q1rohYuwnfpVZUa98L2CtQzmAcB,IIZ4e82HBP0oTmtOgaWY7hsMz(sQU2GnRoMwLK8CBdfzmNr4jXyO)+tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠩࠣࠤࠥࡖࡲࡦࡲࡤࡶ࡮ࡴࡧࠡࡶࡲࠤࡵࡲࡡࡺ࠱ࡧࡳࡼࡴ࡬ࡰࡣࡧࠤࡻ࡯ࡤࡦࡱࠣࠤࠥ࡜ࡩࡥࡧࡲ࠾ࠥࡡࠠࠨ੦")+smglbwR7x2oM+JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠪࠤࡢ࠭੧")+QFHvuhgCAncSj3LX)
		if asP7tCIR3S4wQ2ncHG0ZOVbNgWfhe6==MgP8OjoaiWQEVG59(u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪ੨") and KKxw6aJkTAFdDOeh3r not in [y6y5HtgXO4TkUbwVZ(u"ࠬࡏࡐࡕࡘࠪ੩"),LyNiIHPOwD3hCUYEFM7(u"࡙࠭ࡐࡗࡗ࡙ࡇࡋࠧ੪")]:
			import braVAkwfBN
			A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = braVAkwfBN.VKTp8gacXPG9Zr4H3NQCM0O(KKxw6aJkTAFdDOeh3r,smglbwR7x2oM)
			MH9dDWw6lxUpqcAYzFhveGZoKVQ = len(duef0gb3Mi1AV5WpN8)
			if MH9dDWw6lxUpqcAYzFhveGZoKVQ>YYJQyRskpX8jv:
				mmfrx2S5XqknFTDeRhj49LuYv1wW0 = braVAkwfBN.ccv1mVPUsnr(AbqCJZdWQP9j(u"ࠧศะอีࠥอไๆๆไࠤฬ๊ๅ็ษึฬ࠿ࠦࠨࠨ੫")+str(MH9dDWw6lxUpqcAYzFhveGZoKVQ)+TlGXWLYsV1z(u"ࠨ่่ࠢๆ࠯ࠧ੬"), A7Ap2wdlxM)
				if mmfrx2S5XqknFTDeRhj49LuYv1wW0==-YYJQyRskpX8jv:
					braVAkwfBN.YYkhEn5xTXLUevzCVNB16mR(PtkEvXAqif14G20QZsaSyT(u"ࠩศ่฿อมࠡ฻่่๏ฯࠠหึ฽๎้ࠦวๅใํำ๏๎ࠧ੭"),ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠪࡇࡦࡴࡣࡦ࡮ࠪ੮"))
					return y2boSPsYmFjZBJzWpMEica6HRD
			else: mmfrx2S5XqknFTDeRhj49LuYv1wW0 = FGTfwsjNrB8DvKSZhLIQAb1JnO
			smglbwR7x2oM = duef0gb3Mi1AV5WpN8[mmfrx2S5XqknFTDeRhj49LuYv1wW0]
			if A7Ap2wdlxM[FGTfwsjNrB8DvKSZhLIQAb1JnO]!=YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠫ࠲࠷ࠧ੯"):
				WKquk5EaNr4RzVf(q1rohYuwnfpVZUa98L2CtQzmAcB,IIZ4e82HBP0oTmtOgaWY7hsMz(sQU2GnRoMwLK8CBdfzmNr4jXyO)+jXE2YHkswT8y(u"ࠬࠦࠠࠡࡘ࡬ࡨࡪࡵࠠࡔࡧ࡯ࡩࡨࡺࡥࡥࠢࠣࠤࡘ࡫࡬ࡦࡥࡷ࡭ࡴࡴ࠺ࠡ࡝ࠣࠫੰ")+A7Ap2wdlxM[mmfrx2S5XqknFTDeRhj49LuYv1wW0]+JZszNnIEMAx28Yao0yqhiXGKOPb(u"࠭ࠠ࡞ࠢࠣࠤ࡛࡯ࡤࡦࡱ࠽ࠤࡠࠦࠧੱ")+smglbwR7x2oM+hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠧࠡ࡟ࠪੲ"))
		if sVzojQerUqX(u"ࠨ࠱࡬ࡪ࡮ࡲ࡭࠰ࠩੳ") in smglbwR7x2oM: smglbwR7x2oM = smglbwR7x2oM+ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠩࡿ࡙ࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺ࠽ࠧࠩੴ")
		elif uuExaKGL7UONtevRd(u"ࠪ࡬ࡹࡺࡰࠨੵ") in smglbwR7x2oM.lower() and ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠫ࠴ࡪࡡࡴࡪ࠲ࠫ੶") not in smglbwR7x2oM and IpC4qHXRuyNFjzWv(u"ࠬࡿ࡯ࡶࡶࡸࡦࡪ࠴࡭ࡱࡦࠪ੷") not in smglbwR7x2oM:
			smglbwR7x2oM = smglbwR7x2oM+YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"࠭ࡼࠨ੸") if ZchUJdM93pTA7zG5(u"ࠧࡽࠩ੹") not in smglbwR7x2oM else smglbwR7x2oM+JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠨࠨࠪ੺")
			if TlGXWLYsV1z(u"ࠩࡹࡩࡷ࡯ࡦࡺࡲࡨࡩࡷࡃࠧ੻") not in smglbwR7x2oM and L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࠬ੼") in smglbwR7x2oM.lower(): smglbwR7x2oM += ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠫࡻ࡫ࡲࡪࡨࡼࡴࡪ࡫ࡲ࠾ࡨࡤࡰࡸ࡫ࠦࠨ੽")
			if jXE2YHkswT8y(u"ࠬࡻࡳࡦࡴ࠰ࡥ࡬࡫࡮ࡵ࠿ࠪ੾") not in smglbwR7x2oM.lower() and KKxw6aJkTAFdDOeh3r not in [AbqCJZdWQP9j(u"࠭ࡉࡑࡖ࡙ࠫ੿"),zmcGfOdvAjsELeJlP(u"ࠧࡎ࠵ࡘࠫ઀")]: smglbwR7x2oM += hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࡂࠬࠧઁ")
			if hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠩࡵࡩ࡫࡫ࡲࡦࡴࡀࠫં") not in smglbwR7x2oM.lower(): smglbwR7x2oM += IpC4qHXRuyNFjzWv(u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࡁ࡭ࡺࡴࡱࠨࠪઃ")
	WKquk5EaNr4RzVf(P3sqIW4T8rYpjNxOXhcBk2GD,IIZ4e82HBP0oTmtOgaWY7hsMz(sQU2GnRoMwLK8CBdfzmNr4jXyO)+HtK4o2sTPgA78U(u"ࠫࠥࠦࠠࡈࡱࡷࠤ࡫࡯࡮ࡢ࡮ࠣࡹࡷࡲ࡙ࠠࠡࠢ࡭ࡩ࡫࡯࠻ࠢ࡞ࠤࠬ઄")+smglbwR7x2oM+TlGXWLYsV1z(u"ࠬࠦ࡝ࠨઅ"))
	yQ6W3ZTpwqd42gv1RCij8oSGlA0U = OOYtyXB3o8K.ListItem()
	IXfvjBK2RAHbMlV36t,q9FkAs1NQVWaXRl,A8RCSEltk1g6Wq5KGeIdxnFpUv,D8DaOljYRmg2x,ILNJfuaQCG8U1xDW24KB,gkyuWnHmrClwzbjAqMTBREKtaI,bi1RWINt52gz3DsuEqvZ,kv4lwLRzc0i,LaSfOom2Tr4p9tKX = Q4APpMirastonc6Wh1v2XOH3K(CzWIqm1YAcEa9gTSZ30fk27)
	if KKxw6aJkTAFdDOeh3r not in [SaB5hx3PZwXRLtKgrTfQvId(u"࠭ࡄࡐ࡙ࡑࡐࡔࡇࡄࠨઆ"),ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠧࡊࡒࡗ࡚ࠬઇ")]:
		if iELueYz3J1FmxaW7vc: FEB32G9Y01SLylcIAa = ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲࡧࡤࡥࡱࡱࠫઈ")
		else: FEB32G9Y01SLylcIAa = XrTw01KtLzbpoyMf(u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳࠧઉ")
		yQ6W3ZTpwqd42gv1RCij8oSGlA0U.setProperty(FEB32G9Y01SLylcIAa, iiy37aKq0pCEIOwfcTh61xb4U)
		yQ6W3ZTpwqd42gv1RCij8oSGlA0U.setMimeType(tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠪࡱ࡮ࡳࡥ࠰ࡺ࠰ࡸࡾࡶࡥࠨઊ"))
		if ZD1J5rN8u2wzdgqoyULm4<hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"࠲࠱୧"): yQ6W3ZTpwqd42gv1RCij8oSGlA0U.setInfo(GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠫࡻ࡯ࡤࡦࡱࠪઋ"),{AbqCJZdWQP9j(u"ࠬࡳࡥࡥ࡫ࡤࡸࡾࡶࡥࠨઌ"):zmcGfOdvAjsELeJlP(u"࠭࡭ࡰࡸ࡬ࡩࠬઍ")})
		else:
			KKVisLJjtYqomrSROe5HkNG = yQ6W3ZTpwqd42gv1RCij8oSGlA0U.getVideoInfoTag()
			KKVisLJjtYqomrSROe5HkNG.setMediaType(MgP8OjoaiWQEVG59(u"ࠧ࡮ࡱࡹ࡭ࡪ࠭઎"))
		yQ6W3ZTpwqd42gv1RCij8oSGlA0U.setArt({PtkEvXAqif14G20QZsaSyT(u"ࠨࡶ࡫ࡹࡲࡨࠧએ"):ILNJfuaQCG8U1xDW24KB,SaB5hx3PZwXRLtKgrTfQvId(u"ࠩࡳࡳࡸࡺࡥࡳࠩઐ"):ILNJfuaQCG8U1xDW24KB,vODxLKW5Ql6r4Fbm8(u"ࠪࡦࡦࡴ࡮ࡦࡴࠪઑ"):ILNJfuaQCG8U1xDW24KB,PtkEvXAqif14G20QZsaSyT(u"ࠫ࡫ࡧ࡮ࡢࡴࡷࠫ઒"):ILNJfuaQCG8U1xDW24KB,y6y5HtgXO4TkUbwVZ(u"ࠬࡩ࡬ࡦࡣࡵࡥࡷࡺࠧઓ"):ILNJfuaQCG8U1xDW24KB,CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"࠭ࡣ࡭ࡧࡤࡶࡱࡵࡧࡰࠩઔ"):ILNJfuaQCG8U1xDW24KB,AbqCJZdWQP9j(u"ࠧ࡭ࡣࡱࡨࡸࡩࡡࡱࡧࠪક"):ILNJfuaQCG8U1xDW24KB,L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠨ࡫ࡦࡳࡳ࠭ખ"):ILNJfuaQCG8U1xDW24KB})
		if asP7tCIR3S4wQ2ncHG0ZOVbNgWfhe6 in [AbqCJZdWQP9j(u"ࠩ࠱ࡱࡵࡪࠧગ"),LyNiIHPOwD3hCUYEFM7(u"ࠪ࠲ࡲ࠹ࡵ࠹ࠩઘ")]: yQ6W3ZTpwqd42gv1RCij8oSGlA0U.setContentLookup(rGPen6cSMHQkAywh8vqI9JXiD2)
		else: yQ6W3ZTpwqd42gv1RCij8oSGlA0U.setContentLookup(BF6QAiLUNHh7rKOugaw)
		from lpTiXPCdwE import nv2FxBURGbaTYX
		if ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠫࡷࡺ࡭ࡱࠩઙ") in smglbwR7x2oM:
			nv2FxBURGbaTYX(vODxLKW5Ql6r4Fbm8(u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡶࡹࡳࡰࠨચ"),BF6QAiLUNHh7rKOugaw)
		elif asP7tCIR3S4wQ2ncHG0ZOVbNgWfhe6==Y41NvKfOroMzGB8sEHy7wbXlc5(u"࠭࠮࡮ࡲࡧࠫછ") or zmcGfOdvAjsELeJlP(u"ࠧ࠰ࡦࡤࡷ࡭࠵ࠧજ") in smglbwR7x2oM:
			nv2FxBURGbaTYX(CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡡࡥࡣࡳࡸ࡮ࡼࡥࠨઝ"),BF6QAiLUNHh7rKOugaw)
			yQ6W3ZTpwqd42gv1RCij8oSGlA0U.setProperty(FEB32G9Y01SLylcIAa,y6y5HtgXO4TkUbwVZ(u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡢࡦࡤࡴࡹ࡯ࡶࡦࠩઞ"))
			yQ6W3ZTpwqd42gv1RCij8oSGlA0U.setProperty(HtK4o2sTPgA78U(u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡣࡧࡥࡵࡺࡩࡷࡧ࠱ࡱࡦࡴࡩࡧࡧࡶࡸࡤࡺࡹࡱࡧࠪટ"),y6y5HtgXO4TkUbwVZ(u"ࠫࡲࡶࡤࠨઠ"))
		if SBK4b87qLWRuCpJ:
			yQ6W3ZTpwqd42gv1RCij8oSGlA0U.setSubtitles([SBK4b87qLWRuCpJ])
	if IXfvjBK2RAHbMlV36t==xpT28sXu051(u"ࠬࡼࡩࡥࡧࡲࠫડ") and KKxw6aJkTAFdDOeh3r==UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"࠭ࡄࡐ࡙ࡑࡐࡔࡇࡄࠨઢ"):
		y2boSPsYmFjZBJzWpMEica6HRD = zmcGfOdvAjsELeJlP(u"ࠧࡱ࡮ࡤࡽࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧણ")
		KKxw6aJkTAFdDOeh3r = MgP8OjoaiWQEVG59(u"ࠨࡒࡏࡅ࡞ࡥࡄࡍࡡࡉࡍࡑࡋࡓࠨત")
	elif IXfvjBK2RAHbMlV36t==YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠩࡹ࡭ࡩ࡫࡯ࠨથ") and kv4lwLRzc0i.startswith(zmcGfOdvAjsELeJlP(u"ࠪ࠺ࠬદ")):
		y2boSPsYmFjZBJzWpMEica6HRD = tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࡯࡮ࡨࠩધ")
		KKxw6aJkTAFdDOeh3r = KKxw6aJkTAFdDOeh3r+IpC4qHXRuyNFjzWv(u"ࠬࡥࡄࡍࠩન")
	if y2boSPsYmFjZBJzWpMEica6HRD!=XrTw01KtLzbpoyMf(u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤࡪࡰࡪࠫ઩"): vtTse5pbrQCKAWjdyJYiPzuOEwxlh()
	QYrGfZTEpo98D.e20faZPhsVjXmGK9DOzrkUicgQl(KKxw6aJkTAFdDOeh3r)
	if QYrGfZTEpo98D.F580IoCg1UKz: return L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠧࡣ࡮ࡲࡧࡰ࡫ࡤࠨપ")
	if IXfvjBK2RAHbMlV36t==ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠨࡸ࡬ࡨࡪࡵࠧફ") and not kv4lwLRzc0i.startswith(hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠩ࠹ࠫબ")):
		yQ6W3ZTpwqd42gv1RCij8oSGlA0U.setPath(smglbwR7x2oM)
		WKquk5EaNr4RzVf(q1rohYuwnfpVZUa98L2CtQzmAcB,IIZ4e82HBP0oTmtOgaWY7hsMz(sQU2GnRoMwLK8CBdfzmNr4jXyO)+L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠪࠤࠥࠦࡖࡪࡦࡨࡳࠥࡶ࡬ࡢࡻࠣࡹࡸ࡯࡮ࡨࠢࡶࡩࡹࡘࡥࡴࡱ࡯ࡺࡪࡪࡕࡳ࡮ࠫ࠭ࠥࠦࠠࡗ࡫ࡧࡩࡴࡀࠠ࡜ࠢࠪભ")+smglbwR7x2oM+HtK4o2sTPgA78U(u"ࠫࠥࡣࠧમ"))
		dsBkaDQ16gtSnbrUXvl.setResolvedUrl(Lwz8pPM60OCIBK7,rGPen6cSMHQkAywh8vqI9JXiD2,yQ6W3ZTpwqd42gv1RCij8oSGlA0U)
	elif IXfvjBK2RAHbMlV36t==jXE2YHkswT8y(u"ࠬࡲࡩࡷࡧࠪય"):
		WKquk5EaNr4RzVf(q1rohYuwnfpVZUa98L2CtQzmAcB,IIZ4e82HBP0oTmtOgaWY7hsMz(sQU2GnRoMwLK8CBdfzmNr4jXyO)+yJeq1BjfiO4NFuwIEzxVLK6b9s(u"࠭ࠠࠡࠢࡏ࡭ࡻ࡫ࠠࡱ࡮ࡤࡽࠥࡻࡳࡪࡰࡪࠤࡵࡲࡡࡺࠪࠬࠤࠥࠦࡖࡪࡦࡨࡳ࠿࡛ࠦࠡࠩર")+smglbwR7x2oM+uuExaKGL7UONtevRd(u"ࠧࠡ࡟ࠪ઱"))
		QYrGfZTEpo98D.play(smglbwR7x2oM,yQ6W3ZTpwqd42gv1RCij8oSGlA0U)
	M5qyIg2dZlm6FxH4tTPV79okNu0bCG = BF6QAiLUNHh7rKOugaw
	if y2boSPsYmFjZBJzWpMEica6HRD==tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦ࡬ࡲ࡬࠭લ"):
		from KKZupF6iA4 import Ily7S5uCTQRbk82
		M5qyIg2dZlm6FxH4tTPV79okNu0bCG = Ily7S5uCTQRbk82(smglbwR7x2oM,asP7tCIR3S4wQ2ncHG0ZOVbNgWfhe6,KKxw6aJkTAFdDOeh3r)
		if M5qyIg2dZlm6FxH4tTPV79okNu0bCG: vtTse5pbrQCKAWjdyJYiPzuOEwxlh()
	else:
		ff23ICqELcvWaZYm4suDzHnU,y2boSPsYmFjZBJzWpMEica6HRD,EEvMV7mB98sQhYqK1IuONneC,LgVvH7SCXT,UxfBR8gdinNIV6LA2v57OXrDp = FGTfwsjNrB8DvKSZhLIQAb1JnO,ZchUJdM93pTA7zG5(u"ࠩࡷࡶ࡮࡫ࡤࠨળ"),BF6QAiLUNHh7rKOugaw,zmcGfOdvAjsELeJlP(u"࠳࠳࠴࠵୩"),GGx4qyKP1vUtRghsE2WfaHLMXZ(u"࠵࠷࠳࠴࠵୨")
		if tNGEy8DzoQ9: import braVAkwfBN
		while ff23ICqELcvWaZYm4suDzHnU<UxfBR8gdinNIV6LA2v57OXrDp:
			WwMgozBIC32n9d0tyfp.sleep(LgVvH7SCXT)
			ff23ICqELcvWaZYm4suDzHnU += LgVvH7SCXT
			if QYrGfZTEpo98D.F580IoCg1UKz==EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠪࡷࡹࡧࡲࡵࡧࡧࠫ઴") and not EEvMV7mB98sQhYqK1IuONneC:
				if tNGEy8DzoQ9: braVAkwfBN.YYkhEn5xTXLUevzCVNB16mR(SaB5hx3PZwXRLtKgrTfQvId(u"๋ࠫาอหࠢ฼้้๐ษࠡวํะฬีࠠศๆไ๎ิ๐่ࠨવ"),tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"࡙ࠬࡵࡤࡥࡨࡷࡸ࠭શ"),X2cQ5NCPvkMieBW7oASspFjE=SaB5hx3PZwXRLtKgrTfQvId(u"࠺࠹࠵୪"))
				WKquk5EaNr4RzVf(P3sqIW4T8rYpjNxOXhcBk2GD,IIZ4e82HBP0oTmtOgaWY7hsMz(sQU2GnRoMwLK8CBdfzmNr4jXyO)+XrTw01KtLzbpoyMf(u"࠭ࠠࠡࠢࡖࡹࡨࡩࡥࡴࡵ࠽ࠤࠥ࡜ࡩࡥࡧࡲࠤࡸࡺࡡࡳࡶࡨࡨࠥࠦࠠࡗ࡫ࡧࡩࡴࡀࠠ࡜ࠢࠪષ")+smglbwR7x2oM+jXE2YHkswT8y(u"ࠧࠡ࡟ࠪસ")+QFHvuhgCAncSj3LX)
				EEvMV7mB98sQhYqK1IuONneC = rGPen6cSMHQkAywh8vqI9JXiD2
			elif QYrGfZTEpo98D.F580IoCg1UKz in [YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠨࡲ࡯ࡥࡾ࡯࡮ࡨࠩહ"),sVzojQerUqX(u"ࠩࡷࡩࡸࡺࡩ࡯ࡩࠪ઺")]:
				WKquk5EaNr4RzVf(P3sqIW4T8rYpjNxOXhcBk2GD,IIZ4e82HBP0oTmtOgaWY7hsMz(sQU2GnRoMwLK8CBdfzmNr4jXyO)+xpT28sXu051(u"ࠪࠤࠥࠦࡓࡶࡥࡦࡩࡸࡹ࠺࡙ࠡࠢ࡭ࡩ࡫࡯ࠡࡲ࡯ࡥࡾ࡯࡮ࡨࠢࠣࠤ࡛࡯ࡤࡦࡱ࠽ࠤࡠࠦࠧ઻")+smglbwR7x2oM+MgP8OjoaiWQEVG59(u"ࠫࠥࡣ઼ࠧ")+QFHvuhgCAncSj3LX)
				break
			elif QYrGfZTEpo98D.F580IoCg1UKz==ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬઽ"):
				WKquk5EaNr4RzVf(uiza5vIyTWtUeB8sXwAVYMFpgjrk,IIZ4e82HBP0oTmtOgaWY7hsMz(sQU2GnRoMwLK8CBdfzmNr4jXyO)+ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"࠭ࠠࠡࠢࡉࡥ࡮ࡲࡥࡥࠢࡳࡰࡦࡿࡩ࡯ࡩࠣࡺ࡮ࡪࡥࡰࠢࠣࠤ࡛࡯ࡤࡦࡱ࠽ࠤࡠࠦࠧા")+smglbwR7x2oM+L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠧࠡ࡟ࠪિ")+QFHvuhgCAncSj3LX)
				if tNGEy8DzoQ9: braVAkwfBN.YYkhEn5xTXLUevzCVNB16mR(y6y5HtgXO4TkUbwVZ(u"ࠨใื่ฯูࠦๆๆํอࠥะิ฻์็ࠤฬ๊แ๋ัํ์ࠬી"),jXE2YHkswT8y(u"ࠩࡉࡥ࡮ࡲࡵࡳࡧࠪુ"),X2cQ5NCPvkMieBW7oASspFjE=tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"࠻࠺࠶୫"))
				break
			elif QYrGfZTEpo98D.F580IoCg1UKz==XrTw01KtLzbpoyMf(u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠫૂ"):
				WKquk5EaNr4RzVf(ggQb54INJ8on0M,IIZ4e82HBP0oTmtOgaWY7hsMz(sQU2GnRoMwLK8CBdfzmNr4jXyO)+XrTw01KtLzbpoyMf(u"ࠫࠥࠦࠠࡅࡧࡹ࡭ࡨ࡫ࠠࡪࡵࠣࡦࡱࡵࡣ࡬ࡧࡧࠤࠥࠦࡖࡪࡦࡨࡳ࠿࡛ࠦࠡࠩૃ")+smglbwR7x2oM+jXE2YHkswT8y(u"ࠬࠦ࡝ࠨૄ"))
				break
		else: y2boSPsYmFjZBJzWpMEica6HRD = hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"࠭ࡴࡪ࡯ࡨࡳࡺࡺࠧૅ")
	if y2boSPsYmFjZBJzWpMEica6HRD in [hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠧࡱ࡮ࡤࡽࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ૆")] or QYrGfZTEpo98D.F580IoCg1UKz in [ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠨࡲ࡯ࡥࡾ࡯࡮ࡨࠩે"),PtkEvXAqif14G20QZsaSyT(u"ࠩࡷࡩࡸࡺࡩ࡯ࡩࠪૈ")] or M5qyIg2dZlm6FxH4tTPV79okNu0bCG: gE8olLZnXGx0NFrpQ4qvzhya67Djd(KKxw6aJkTAFdDOeh3r)
	else: exec(uuExaKGL7UONtevRd(u"ࠪ࡭ࡲࡶ࡯ࡳࡶࠣࡼࡧࡳࡣ࠼ࡺࡥࡱࡨ࠴ࡐ࡭ࡣࡼࡩࡷ࠮ࠩ࠯ࡵࡷࡳࡵ࠮ࠩࠨૉ"))
	DjbW4KkVIudBte0iZzQaSAC1vgyo = WwMgozBIC32n9d0tyfp.Player().isPlaying()
	if not DjbW4KkVIudBte0iZzQaSAC1vgyo and y2boSPsYmFjZBJzWpMEica6HRD not in [hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࡯࡮ࡨࠩ૊")]:
		msg = sVzojQerUqX(u"࡚ࠬࡩ࡮ࡧࡲࡹࡹ࠭ો") if y2boSPsYmFjZBJzWpMEica6HRD==hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"࠭ࡴࡪ࡯ࡨࡳࡺࡺࠧૌ") else HtK4o2sTPgA78U(u"ࠧࡖࡰ࡮ࡲࡴࡽ࡮ࠨ્")
		if tNGEy8DzoQ9: braVAkwfBN.YYkhEn5xTXLUevzCVNB16mR(YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠨใื่ฯูࠦๆๆํอࠥะิ฻์็ࠤฬ๊แ๋ัํ์ࠬ૎"),msg,X2cQ5NCPvkMieBW7oASspFjE=SaB5hx3PZwXRLtKgrTfQvId(u"࠼࠻࠰୬"))
		WKquk5EaNr4RzVf(uiza5vIyTWtUeB8sXwAVYMFpgjrk,IIZ4e82HBP0oTmtOgaWY7hsMz(sQU2GnRoMwLK8CBdfzmNr4jXyO)+CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠩࠣࠤࠥ࠭૏")+msg+TlGXWLYsV1z(u"ࠪ࠾ࠥࠦࡕ࡯࡭ࡱࡳࡼࡴࠠࡱࡴࡲࡦࡱ࡫࡭࡚ࠡࠢࠣ࡮ࡪࡥࡰ࠼ࠣ࡟ࠥ࠭ૐ")+smglbwR7x2oM+yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠫࠥࡣࠧ૑")+QFHvuhgCAncSj3LX)
	return QYrGfZTEpo98D.F580IoCg1UKz
def dVeG46wAnrtlpkbNPsvJ9(smglbwR7x2oM):
	if UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠬࡅࠧ૒") in smglbwR7x2oM: smglbwR7x2oM = smglbwR7x2oM.split(hhQwbeiNLoqFjX90fB7aG8VAs(u"࠭࠿ࠨ૓"))[FGTfwsjNrB8DvKSZhLIQAb1JnO]
	if y6y5HtgXO4TkUbwVZ(u"ࠧࡽࠩ૔") in smglbwR7x2oM: smglbwR7x2oM = smglbwR7x2oM.split(Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠨࡾࠪ૕"))[FGTfwsjNrB8DvKSZhLIQAb1JnO]
	path = L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠩ࠲ࠫ૖").join(smglbwR7x2oM.split(sVzojQerUqX(u"ࠪ࠳ࠬ૗"))[UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"࠹୭"):]) if L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠫ࠿࠵࠯ࠨ૘") in smglbwR7x2oM else smglbwR7x2oM
	AAxlhaUdNRX2CFZkTuj = dEyT9xhGjolYzLCH7460w3.findall(sVzojQerUqX(u"ࠬࡢ࠮ࠩ࡝ࡤ࠱ࡿ࠶࠭࠺࡟ࡾ࠶࠱࠺ࡽࠪࠩ૙"),path,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if AAxlhaUdNRX2CFZkTuj:
		AAxlhaUdNRX2CFZkTuj = AAxlhaUdNRX2CFZkTuj[-YYJQyRskpX8jv]
		QEiIn6q23j1HMxVs = [FRYcH4KL7e9gv5pEB(u"࠭࡭࠴ࡷ࠻ࠫ૚"),L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠧ࡮ࡲ࠷ࠫ૛"),ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠨ࡯ࡳࡨࠬ૜"),hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠩࡺࡩࡧࡳࠧ૝"),tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠪࡥࡻ࡯ࠧ૞"),vODxLKW5Ql6r4Fbm8(u"ࠫࡦࡧࡣࠨ૟"),LyNiIHPOwD3hCUYEFM7(u"ࠬࡳ࠳ࡶࠩૠ"),ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"࠭࡭࡬ࡸࠪૡ"),IpC4qHXRuyNFjzWv(u"ࠧࡧ࡮ࡹࠫૢ"),tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠨ࡯ࡳ࠷ࠬૣ"),zmcGfOdvAjsELeJlP(u"ࠩࡷࡷࠬ૤")]
		if AAxlhaUdNRX2CFZkTuj in QEiIn6q23j1HMxVs: return ZchUJdM93pTA7zG5(u"ࠪ࠲ࠬ૥")+AAxlhaUdNRX2CFZkTuj
	return iiy37aKq0pCEIOwfcTh61xb4U
def gE8olLZnXGx0NFrpQ4qvzhya67Djd(QihHpX3jKr):
	if not IiCsQD91HF.ic2FB5X43kWzyTKtNE: QihHpX3jKr += zmcGfOdvAjsELeJlP(u"ࠫࡤ࡚ࡓࠨ૦")
	RR80SbLUCimJrMV.append(QihHpX3jKr)
	return
def qAXLJHy4FBEhc5aem7wPul(ntPBiF2IqpgCvsEc6h1wOmXKoaNr=BF6QAiLUNHh7rKOugaw):
	TGxWVt7w8K(ntPBiF2IqpgCvsEc6h1wOmXKoaNr,ZchUJdM93pTA7zG5(u"ࠬࡥ࡟ࡠࡈࡒࡖࡈࡋ࡟ࡆ࡚ࡌࡘࡤࡥ࡟ࠨ૧"))
	ytv0YaxDcRINurplWKg587Pwqz.exit()
def TGxWVt7w8K(ntPBiF2IqpgCvsEc6h1wOmXKoaNr,UIxuCn8wAWpgz5j9EdqFvreH):
	if UIxuCn8wAWpgz5j9EdqFvreH:
		if YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"࠭࡟ࡠࡡࡉࡓࡗࡉࡅࡠࡇ࡛ࡍ࡙ࡥ࡟ࡠࠩ૨") in UIxuCn8wAWpgz5j9EdqFvreH: WKquk5EaNr4RzVf(iiy37aKq0pCEIOwfcTh61xb4U,YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠧࡠࡡࡢࡊࡔࡘࡃࡆࡡࡈ࡜ࡎ࡚࡟ࡠࡡࠪ૩"))
		else:
			TUAvjq9C0NHBiWnM6mEgIr4Sct8x = OXsckY7RzjCag9A.getSetting(sVzojQerUqX(u"ࠨࡣࡹ࠲ࡱࡧ࡮ࡨࡷࡤ࡫ࡪ࠴ࡴࡳࡣࡱࡷࡱࡧࡴࡦࠩ૪"))
			OXsckY7RzjCag9A.setSetting(Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠩࡤࡺ࠳ࡲࡡ࡯ࡩࡸࡥ࡬࡫࠮ࡵࡴࡤࡲࡸࡲࡡࡵࡧࠪ૫"),iiy37aKq0pCEIOwfcTh61xb4U)
			import braVAkwfBN
			braVAkwfBN.STuF19IbYQR3gz(UIxuCn8wAWpgz5j9EdqFvreH)
			OXsckY7RzjCag9A.setSetting(xpT28sXu051(u"ࠪࡥࡻ࠴࡬ࡢࡰࡪࡹࡦ࡭ࡥ࠯ࡶࡵࡥࡳࡹ࡬ࡢࡶࡨࠫ૬"),TUAvjq9C0NHBiWnM6mEgIr4Sct8x)
	aolOvjwC6d(L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠫࡸࡺ࡯ࡱࠩ૭"))
	zCXZNsp6PT8Mhxnr5v0G71KaBdFR = OXsckY7RzjCag9A.getSetting(ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡴࡨࡪࡷ࡫ࡳࡩࠩ૮"))
	if zCXZNsp6PT8Mhxnr5v0G71KaBdFR==zmcGfOdvAjsELeJlP(u"࠭ࡒࡆࡓࡘࡉࡘ࡚࡟ࡓࡇࡉࡖࡊ࡙ࡈࡠࡅࡄࡇࡍࡋࠧ૯"): OXsckY7RzjCag9A.setSetting(UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡶࡪ࡬ࡲࡦࡵ࡫ࠫ૰"),LyNiIHPOwD3hCUYEFM7(u"ࠨࡔࡈࡊࡗࡋࡓࡉࡡࡆࡅࡈࡎࡅࠨ૱"))
	elif zCXZNsp6PT8Mhxnr5v0G71KaBdFR==uuExaKGL7UONtevRd(u"ࠩࡕࡉࡋࡘࡅࡔࡊࡢࡇࡆࡉࡈࡆࠩ૲"): OXsckY7RzjCag9A.setSetting(XrTw01KtLzbpoyMf(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡲࡦࡨࡵࡩࡸ࡮ࠧ૳"),iiy37aKq0pCEIOwfcTh61xb4U)
	if OXsckY7RzjCag9A.getSetting(ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡵࡨࡨࡳࡹࠧ૴")) not in [LyNiIHPOwD3hCUYEFM7(u"ࠬࡇࡕࡕࡑࠪ૵"),XrTw01KtLzbpoyMf(u"࠭ࡓࡕࡑࡓࠫ૶"),PtkEvXAqif14G20QZsaSyT(u"ࠧࡂࡕࡎࠫ૷")]: OXsckY7RzjCag9A.setSetting(sVzojQerUqX(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡺࡹࡥࡥࡰࡶࠫ૸"),uuExaKGL7UONtevRd(u"ࠩࡄࡗࡐ࠭ૹ"))
	if OXsckY7RzjCag9A.getSetting(ZchUJdM93pTA7zG5(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡵࡴࡧࡳࡶࡴࡾࡹࠨૺ")) not in [zmcGfOdvAjsELeJlP(u"ࠫࡆ࡛ࡔࡐࠩૻ"),EMO8gy4LrsNTh0knZwpSeU75APW(u"࡙ࠬࡔࡐࡒࠪૼ"),YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"࠭ࡁࡔࡍࠪ૽")]: OXsckY7RzjCag9A.setSetting(xpT28sXu051(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡹࡸ࡫ࡰࡳࡱࡻࡽࠬ૾"),JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠨࡃࡖࡏࠬ૿"))
	EXSMU1qhPLlWp985KJfsFQRC = OXsckY7RzjCag9A.getSetting(XrTw01KtLzbpoyMf(u"ࠩࡤࡺ࠳ࡳࡹࡴ࡭࡬ࡲ࠳ࡼࡩࡦࡹࡰࡳࡩ࡫ࠧ଀"))
	Pwe2ycZtIx5FOrhuf = WwMgozBIC32n9d0tyfp.executeJSONRPC(LyNiIHPOwD3hCUYEFM7(u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡖࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡌ࡫ࡴࡔࡧࡷࡸ࡮ࡴࡧࡗࡣ࡯ࡹࡪࠨࠬࠣ࡫ࡧࠦ࠿࠷ࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡸ࡫ࡴࡵ࡫ࡱ࡫ࠧࡀࠢ࡭ࡱࡲ࡯ࡦࡴࡤࡧࡧࡨࡰ࠳ࡹ࡫ࡪࡰࠥࢁࢂ࠭ଁ"))
	if tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪଂ") in str(Pwe2ycZtIx5FOrhuf) and EXSMU1qhPLlWp985KJfsFQRC in [ZchUJdM93pTA7zG5(u"ࠬࡋࡍࡂࡆࠣࡐ࡮ࡹࡴࠨଃ"),ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"࠭ࡅࡎࡃࡇࠤࡌࡧ࡬࡭ࡧࡵࡽࠬ଄")]:
		X2cQ5NCPvkMieBW7oASspFjE.sleep(GGx4qyKP1vUtRghsE2WfaHLMXZ(u"࠰࠯࠳࠳࠴୮"))
		WwMgozBIC32n9d0tyfp.executebuiltin(hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡗࡪࡺࡖࡪࡧࡺࡑࡴࡪࡥࠩ࠲ࠬࠫଅ"))
	if FGTfwsjNrB8DvKSZhLIQAb1JnO and Lwz8pPM60OCIBK7>-YYJQyRskpX8jv:
		dsBkaDQ16gtSnbrUXvl.setResolvedUrl(Lwz8pPM60OCIBK7,BF6QAiLUNHh7rKOugaw,OOYtyXB3o8K.ListItem())
		M5qyIg2dZlm6FxH4tTPV79okNu0bCG,BBhSoAIskTHPN1MnWLGjUawZy,z1F5cTMvEk2Ngd70QRy3mqp = BF6QAiLUNHh7rKOugaw,BF6QAiLUNHh7rKOugaw,BF6QAiLUNHh7rKOugaw
		dsBkaDQ16gtSnbrUXvl.endOfDirectory(Lwz8pPM60OCIBK7,M5qyIg2dZlm6FxH4tTPV79okNu0bCG,BBhSoAIskTHPN1MnWLGjUawZy,z1F5cTMvEk2Ngd70QRy3mqp)
	if RR80SbLUCimJrMV:
		KLUY2gxEHy8 = EEehSFDLdpKBR3W1ga9PxrV.Thread(target=xaP4EqIfl6ShL5B8,args=(RR80SbLUCimJrMV,))
		KLUY2gxEHy8.start()
	UUsRCncKxB41EMOXhH8vyGd36 = pNO0reZBaLzh1Y9GMinuPHASg()
	if UUsRCncKxB41EMOXhH8vyGd36 and not IiCsQD91HF.resolveonly:
		IiCsQD91HF.resolveonly = rGPen6cSMHQkAywh8vqI9JXiD2
		DjbW4KkVIudBte0iZzQaSAC1vgyo = WwMgozBIC32n9d0tyfp.Player().isPlaying()
		if not DjbW4KkVIudBte0iZzQaSAC1vgyo: tqC0PngwO4pA = WwMgozBIC32n9d0tyfp.executeJSONRPC(JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡑ࡮ࡤࡽࡱ࡯ࡳࡵ࠰ࡆࡰࡪࡧࡲࠣ࠮ࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡪࡦࠥ࠾࠶ࢃࡽࠨଆ"))
		else:
			ZCOnBzyQ7oi = EDvgbUoNP3CTX86OS7uHIxy()
			if ZCOnBzyQ7oi:
				import braVAkwfBN
				for ba3If2JElOq0nNPWBkXC6dH in range(TlGXWLYsV1z(u"࠲୰"),tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"࠲࠴࠳୯"),PtkEvXAqif14G20QZsaSyT(u"࠶ୱ")):
					X2cQ5NCPvkMieBW7oASspFjE.sleep(FRYcH4KL7e9gv5pEB(u"࠷୲"))
					DjbW4KkVIudBte0iZzQaSAC1vgyo = WwMgozBIC32n9d0tyfp.Player().isPlaying()
					if not DjbW4KkVIudBte0iZzQaSAC1vgyo:
						braVAkwfBN.YYkhEn5xTXLUevzCVNB16mR(y6y5HtgXO4TkUbwVZ(u"ࠩส่ๆ๐ฯ๋๊ࠣห้๊วฮไࠪଇ"),vODxLKW5Ql6r4Fbm8(u"ࠪษ้เวยࠢไัฺࠦวๅีํีๆืวหࠩଈ"),X2cQ5NCPvkMieBW7oASspFjE=uuExaKGL7UONtevRd(u"࠶࠶࠰࠱୳"))
						break
				else:
					EGJVsZy38Xx,Toe5N9znWjQHmP4whguld,smglbwR7x2oM,y3qATZDQOch6db5WjnmrguflU,L95mrowGgdsD,zLEP9N4BOsVrXa,XiWJ2PTqvds4pBNebVrt98x,EALyNnv1Db4cUd8sQoZX2pmBVt7kM,XC10geOnQtwrs = Q4APpMirastonc6Wh1v2XOH3K(ZCOnBzyQ7oi)
					if not any(aasX2cby4Vo5rTgB in Toe5N9znWjQHmP4whguld for aasX2cby4Vo5rTgB in braVAkwfBN.NOT_TO_TEST_ALL_SERVERS):
						braVAkwfBN.YYkhEn5xTXLUevzCVNB16mR(XrTw01KtLzbpoyMf(u"ࠫฬ๊แ๋ัํ์ࠥอไๅษะๆࠬଉ"),yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠬ็อึࠢฯ้๏฿ࠠศๆึ๎ึ็ัศฬࠪଊ"),X2cQ5NCPvkMieBW7oASspFjE=ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"࠷࠰࠱࠲୴"))
						X2cQ5NCPvkMieBW7oASspFjE.sleep(FRYcH4KL7e9gv5pEB(u"࠲୵"))
						if iELueYz3J1FmxaW7vc:
							smglbwR7x2oM = smglbwR7x2oM.encode(df6QpwGxuJVZr)
						braVAkwfBN.qI2s0ZN7uj(BF6QAiLUNHh7rKOugaw,BF6QAiLUNHh7rKOugaw,BF6QAiLUNHh7rKOugaw)
						EA7FzO1kMZGQXDd2giB0cwLom = braVAkwfBN.wA8ZcpVskTjEf5GdULPi4(EGJVsZy38Xx,Toe5N9znWjQHmP4whguld,smglbwR7x2oM,y3qATZDQOch6db5WjnmrguflU,L95mrowGgdsD,zLEP9N4BOsVrXa,XiWJ2PTqvds4pBNebVrt98x,EALyNnv1Db4cUd8sQoZX2pmBVt7kM,XC10geOnQtwrs)
						braVAkwfBN.qI2s0ZN7uj(rGPen6cSMHQkAywh8vqI9JXiD2,rGPen6cSMHQkAywh8vqI9JXiD2,BF6QAiLUNHh7rKOugaw)
						braVAkwfBN.YYkhEn5xTXLUevzCVNB16mR(PtkEvXAqif14G20QZsaSyT(u"࠭วๅใํำ๏๎ࠠศๆ็หา่ࠧଋ"),uuExaKGL7UONtevRd(u"ࠧศ่อ๋๎ࠦแฮืࠣหู้๊าใิหฯ࠭ଌ"),X2cQ5NCPvkMieBW7oASspFjE=yJeq1BjfiO4NFuwIEzxVLK6b9s(u"࠲࠲࠳࠴୶"))
						ntPBiF2IqpgCvsEc6h1wOmXKoaNr = BF6QAiLUNHh7rKOugaw
	LsjrhQpZKcn41EyDwlFBm0IYtX = OXsckY7RzjCag9A.getSetting(hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡧ࡯ࡴࡳࡣࡷࡩࠬ଍"))
	if ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠩ࠰ࠫ଎") in LsjrhQpZKcn41EyDwlFBm0IYtX:
		LsjrhQpZKcn41EyDwlFBm0IYtX = LsjrhQpZKcn41EyDwlFBm0IYtX.replace(y6y5HtgXO4TkUbwVZ(u"ࠪ࠱ࠬଏ"),iiy37aKq0pCEIOwfcTh61xb4U)
		OXsckY7RzjCag9A.setSetting(CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡣ࡫ࡷࡶࡦࡺࡥࠨଐ"),LsjrhQpZKcn41EyDwlFBm0IYtX)
	if ntPBiF2IqpgCvsEc6h1wOmXKoaNr: WwMgozBIC32n9d0tyfp.executebuiltin(hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠩ଑"))
	return
def EDvgbUoNP3CTX86OS7uHIxy():
	WqViQN4wA19 = WwMgozBIC32n9d0tyfp.executeJSONRPC(hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡖ࡬ࡢࡻ࡯࡭ࡸࡺ࠮ࡈࡧࡷࡍࡹ࡫࡭ࡴࠤ࠯ࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡱ࡮ࡤࡽࡱ࡯ࡳࡵ࡫ࡧࠦ࠿࠷ࠬࠣࡲࡵࡳࡵ࡫ࡲࡵ࡫ࡨࡷࠧࡀ࡛ࠣࡶ࡬ࡸࡱ࡫ࠢ࠭ࠤࡩ࡭ࡱ࡫ࠢ࠭ࠤࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࠧࡣࡽ࠭ࠤ࡬ࡨࠧࡀ࠱ࡾࠩ଒"))
	EA7FzO1kMZGQXDd2giB0cwLom = bHyN37Y82ZKVLOexBF.loads(WqViQN4wA19)[ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠧࡳࡧࡶࡹࡱࡺࠧଓ")]
	ZCOnBzyQ7oi = iiy37aKq0pCEIOwfcTh61xb4U
	try: items = EA7FzO1kMZGQXDd2giB0cwLom[zmcGfOdvAjsELeJlP(u"ࠨ࡫ࡷࡩࡲࡹࠧଔ")]
	except: return iiy37aKq0pCEIOwfcTh61xb4U
	if items:
		for rxbivCFQ9aAnpckTUXYh65dH4,file in enumerate(items):
			path = file[L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠩࡩ࡭ࡱ࡫ࠧକ")]
			if M8hQu61Uid not in path: continue
			path = path.split(M8hQu61Uid)[YYJQyRskpX8jv][YYJQyRskpX8jv:]
			if path==CzWIqm1YAcEa9gTSZ30fk27: break
		count = EA7FzO1kMZGQXDd2giB0cwLom[MgP8OjoaiWQEVG59(u"ࠪࡰ࡮ࡳࡩࡵࡵࠪଖ")][AbqCJZdWQP9j(u"ࠫࡹࡵࡴࡢ࡮ࠪଗ")]
		if rxbivCFQ9aAnpckTUXYh65dH4+YYJQyRskpX8jv<count: ZCOnBzyQ7oi = items[rxbivCFQ9aAnpckTUXYh65dH4+YYJQyRskpX8jv][Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠬ࡬ࡩ࡭ࡧࠪଘ")]
	return ZCOnBzyQ7oi
def pNO0reZBaLzh1Y9GMinuPHASg():
	tqC0PngwO4pA = WwMgozBIC32n9d0tyfp.executeJSONRPC(EMO8gy4LrsNTh0knZwpSeU75APW(u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠣࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡓࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡉࡨࡸࡘ࡫ࡴࡵ࡫ࡱ࡫࡛ࡧ࡬ࡶࡧࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡵࡨࡸࡹ࡯࡮ࡨࠤ࠽ࠦࡻ࡯ࡤࡦࡱࡳࡰࡦࡿࡥࡳ࠰ࡤࡹࡹࡵࡰ࡭ࡣࡼࡲࡪࡾࡴࡪࡶࡨࡱࠧࢃࡽࠨଙ"))
	g3xZ09E8heVCD5Hfonsi = BF6QAiLUNHh7rKOugaw if FRYcH4KL7e9gv5pEB(u"ࠧ࡜࡟ࠪଚ") in str(tqC0PngwO4pA) else rGPen6cSMHQkAywh8vqI9JXiD2
	return g3xZ09E8heVCD5Hfonsi
def aolOvjwC6d(KDgEoe0O4PHNkMnVWB8Uu):
	global fpQHPAZvKw94
	if fpQHPAZvKw94:
		if KDgEoe0O4PHNkMnVWB8Uu==TlGXWLYsV1z(u"ࠨࡵࡷࡳࡵ࠭ଛ"):
			tFPGhK6bYwBEOoHDL = L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠩࡥࡹࡸࡿࡤࡪࡣ࡯ࡳ࡬ࡴ࡯ࡤࡣࡱࡧࡪࡲࠧଜ") if ZD1J5rN8u2wzdgqoyULm4>L90uqo28xEKSFUwYTcm51yRWZIkft(u"࠳࠺࠲࠾࠿୷") else vODxLKW5Ql6r4Fbm8(u"ࠪࡦࡺࡹࡹࡥ࡫ࡤࡰࡴ࡭ࠧଝ")
			WwMgozBIC32n9d0tyfp.executebuiltin(JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠫࡉ࡯ࡡ࡭ࡱࡪ࠲ࡈࡲ࡯ࡴࡧࠫࠫଞ")+tFPGhK6bYwBEOoHDL+uuExaKGL7UONtevRd(u"ࠬ࠯ࠧଟ"))
			fpQHPAZvKw94 = BF6QAiLUNHh7rKOugaw
	else:
		if KDgEoe0O4PHNkMnVWB8Uu==IpC4qHXRuyNFjzWv(u"࠭ࡳࡵࡣࡵࡸࠬଠ"):
			tFPGhK6bYwBEOoHDL = FRYcH4KL7e9gv5pEB(u"ࠧࡣࡷࡶࡽࡩ࡯ࡡ࡭ࡱࡪࡲࡴࡩࡡ࡯ࡥࡨࡰࠬଡ") if ZD1J5rN8u2wzdgqoyULm4>y6y5HtgXO4TkUbwVZ(u"࠴࠻࠳࠿࠹୸") else sVzojQerUqX(u"ࠨࡤࡸࡷࡾࡪࡩࡢ࡮ࡲ࡫ࠬଢ")
			WwMgozBIC32n9d0tyfp.executebuiltin(vODxLKW5Ql6r4Fbm8(u"ࠩࡄࡧࡹ࡯ࡶࡢࡶࡨ࡛࡮ࡴࡤࡰࡹࠫࠫଣ")+tFPGhK6bYwBEOoHDL+sVzojQerUqX(u"ࠪ࠭ࠬତ"))
			fpQHPAZvKw94 = rGPen6cSMHQkAywh8vqI9JXiD2
	return
DD4mdiAJMayx7,iBg4yDO2EGZ = None,None
RR80SbLUCimJrMV = []
iw3BpJl1Y9tbg8XMR4VeoS6kEUhf = GmTZdMqCPhJs3pUcgS4tBOki()
WQgeBZ8k7RsuIPdD = iw3BpJl1Y9tbg8XMR4VeoS6kEUhf.splitlines()[FGTfwsjNrB8DvKSZhLIQAb1JnO][-EMO8gy4LrsNTh0knZwpSeU75APW(u"࠶࠹୹"):]
IiCsQD91HF.bbrnyC5Bz9Vqgc0fFYuZ6QNEMvXK7,IiCsQD91HF.ic2FB5X43kWzyTKtNE,IiCsQD91HF.e8cB3UpjldxMI,IiCsQD91HF.i95KXZx1GISPt = EETfYmdIcBQsXGiLzpODJxr35e([yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠫࡈ࡚ࡅ࠺ࡆࡖ࠵࠾࡜ࡕ࠱ࡘࡖ࡜ࠬଥ"),XrTw01KtLzbpoyMf(u"ࠬ࡝ࡓࡖࡔࡉࡘ࠶࠿ࡑࡕࡇࡉ࡞࡝࠭ଦ"),YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"࠭ࡂࡕࡇࡻࡔ࡛࠷࠹ࡖࡔ࡙ࡒ࡚࡙ࡕ࠶ࡊ࡛ࠫଧ"),Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠧࡐࡖ࠴࠽ࡏ࡛࠰ࡹࡄࡗ࡙ࡱࡊࡘࠨନ")])
m0T9yjFUQoSXhCGJrxMzep5134 = iiy37aKq0pCEIOwfcTh61xb4U
IiCsQD91HF.resolveonly = BF6QAiLUNHh7rKOugaw
QYrGfZTEpo98D = AopjiwhR30bv8Pax4EJKclDLTIm1M()
IiCsQD91HF.showDialogs = rGPen6cSMHQkAywh8vqI9JXiD2
# -*- coding: utf-8 -*-
from braVAkwfBN import *
sQU2GnRoMwLK8CBdfzmNr4jXyO = 'EGYBEST3'
ooQEi5O6tYsGVF8LU0TC3hgMeflBwH = '_EB3_'
JaQEtCzDXgos1cdZN = gZ4LwbKaOm[sQU2GnRoMwLK8CBdfzmNr4jXyO][0]
a8GCLIuWNkS = ['المصارعة الحرة','ايجي بست','التصميم الجديد','عروض المصارعة','مكتبتي','ايجي بست الجديد','ايجي بست البديل','egybest','موقع ايجي بست','موقع نتفليكس']
def sHVM8YchrDjZAJ7(mode,url,zLEP9N4BOsVrXa,text):
	if   mode==790: EA7FzO1kMZGQXDd2giB0cwLom = jihuS9LVAvTrClPapMbUEwfn8XN()
	elif mode==791: EA7FzO1kMZGQXDd2giB0cwLom = AIQeNZP4FMDw9S(url,zLEP9N4BOsVrXa)
	elif mode==792: EA7FzO1kMZGQXDd2giB0cwLom = BaSyudevC40nsQHW5j7JX6RM9(url)
	elif mode==793: EA7FzO1kMZGQXDd2giB0cwLom = TW6Z0zqaDl(url)
	elif mode==796: EA7FzO1kMZGQXDd2giB0cwLom = jjQL1mhRn3VpBzNcidEaT4yKt9(url,zLEP9N4BOsVrXa)
	elif mode==799: EA7FzO1kMZGQXDd2giB0cwLom = mUhJtHB9nw(text)
	else: EA7FzO1kMZGQXDd2giB0cwLom = False
	return EA7FzO1kMZGQXDd2giB0cwLom
def jihuS9LVAvTrClPapMbUEwfn8XN():
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(Dxc7GChQwZ4kOlKHSbL06agnB,'GET',JaQEtCzDXgos1cdZN,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'EGYBEST3-MENU-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('list-pages(.*?)fa-folder',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?<span>(.*?)</span>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title in items:
			title = title.strip(iFBmE2MUIpSu34wsd7Rf6z)
			if any(aasX2cby4Vo5rTgB in title for aasX2cby4Vo5rTgB in a8GCLIuWNkS): continue
			if 'http' not in fCXyTlcmF4WuetVork: fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN+fCXyTlcmF4WuetVork
			bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,791)
		bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('main-article(.*?)social-box',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('main-title.*?">(.*?)<.*?href="(.*?)"',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for title,fCXyTlcmF4WuetVork in items:
			title = title.strip(iFBmE2MUIpSu34wsd7Rf6z)
			if any(aasX2cby4Vo5rTgB in title for aasX2cby4Vo5rTgB in a8GCLIuWNkS): continue
			if 'http' not in fCXyTlcmF4WuetVork: fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN+fCXyTlcmF4WuetVork
			bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,791,iiy37aKq0pCEIOwfcTh61xb4U,'mainmenu')
		bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('main-menu(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)">(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title in items:
			title = title.strip(iFBmE2MUIpSu34wsd7Rf6z)
			if any(aasX2cby4Vo5rTgB in title for aasX2cby4Vo5rTgB in a8GCLIuWNkS): continue
			if 'http' not in fCXyTlcmF4WuetVork: fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN+fCXyTlcmF4WuetVork
			bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,791)
	return Vxz6OndPIX4g2kaRp7
def jjQL1mhRn3VpBzNcidEaT4yKt9(url,type=iiy37aKq0pCEIOwfcTh61xb4U):
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'EGYBEST3-SEASONS_EPISODES-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('main-article".*?">(.*?)<(.*?)article',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		zfbAhCqkmOoZWyGpT3KUIF9anBN,f9a8L1lCJvn6pIUuP,items = iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,[]
		for name,PPH1sQtTkDBbnlYpZfo5 in UUIohmv597bO83YCLgWS:
			if 'حلقات' in name: f9a8L1lCJvn6pIUuP = PPH1sQtTkDBbnlYpZfo5
			if 'مواسم' in name: zfbAhCqkmOoZWyGpT3KUIF9anBN = PPH1sQtTkDBbnlYpZfo5
		if zfbAhCqkmOoZWyGpT3KUIF9anBN and not type:
			items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?data-src="(.*?)".*?"title">(.*?)<',zfbAhCqkmOoZWyGpT3KUIF9anBN,dEyT9xhGjolYzLCH7460w3.DOTALL)
			if len(items)>1:
				for fCXyTlcmF4WuetVork,C0dvhEbPWYlUtimM3x,title in items:
					bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,796,C0dvhEbPWYlUtimM3x,'season')
		if f9a8L1lCJvn6pIUuP and len(items)<2:
			items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?data-src="(.*?)".*?class="title">(.*?)<',f9a8L1lCJvn6pIUuP,dEyT9xhGjolYzLCH7460w3.DOTALL)
			if items:
				for fCXyTlcmF4WuetVork,C0dvhEbPWYlUtimM3x,title in items:
					bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,793,C0dvhEbPWYlUtimM3x)
			else:
				items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)">(.*?)<',f9a8L1lCJvn6pIUuP,dEyT9xhGjolYzLCH7460w3.DOTALL)
				for fCXyTlcmF4WuetVork,title in items:
					bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,793)
	return
def AIQeNZP4FMDw9S(url,type=iiy37aKq0pCEIOwfcTh61xb4U):
	LsjrhQpZKcn41EyDwlFBm0IYtX,start,uuX8TYmVoFRlvpQ7LZ,select,JJm06MvE1cZrojkPALugt8YXO9 = 0,0,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U
	if 'pagination' in type:
		iajEot7NHe,data = sFNjagPK4W(url)
		LsjrhQpZKcn41EyDwlFBm0IYtX = int(data['limit'])
		start = int(data['start'])
		uuX8TYmVoFRlvpQ7LZ = data['type']
		select = data['select']
		EwsmJ67cCYDIlg = 'limit='+str(LsjrhQpZKcn41EyDwlFBm0IYtX)+'&start='+str(start)+'&type='+uuX8TYmVoFRlvpQ7LZ+'&select='+select
		rzR9SN7ApZuQhTDWEX3V6ga = {'Content-Type':'application/x-www-form-urlencoded'}
		oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'POST',iajEot7NHe,EwsmJ67cCYDIlg,rzR9SN7ApZuQhTDWEX3V6ga,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'EGYBEST3-TITLES-1st')
		Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
		z0spMAOfJElv6L1K9ae = 'blocks'+Vxz6OndPIX4g2kaRp7+'article'
	else:
		oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'EGYBEST3-TITLES-2nd')
		Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
		z0spMAOfJElv6L1K9ae = Vxz6OndPIX4g2kaRp7
		code = dEyT9xhGjolYzLCH7460w3.findall("<script>(var.*?=.*?;var.*?=.*?;var.*?=.*?;var.*?=.*?;var.*?=.*?);</script>",Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if code:
			code = code[0].replace('var',iiy37aKq0pCEIOwfcTh61xb4U).replace(iFBmE2MUIpSu34wsd7Rf6z,iiy37aKq0pCEIOwfcTh61xb4U).replace("'",iiy37aKq0pCEIOwfcTh61xb4U).replace(';','&')
			qBIUYtOjTAx0,data = sFNjagPK4W('?'+code)
			LsjrhQpZKcn41EyDwlFBm0IYtX = int(data['limit'])
			start = int(data['start'])
			uuX8TYmVoFRlvpQ7LZ = data['type']
			select = data['select']
			JJm06MvE1cZrojkPALugt8YXO9 = data['ajaxurl']
			EwsmJ67cCYDIlg = 'limit='+str(LsjrhQpZKcn41EyDwlFBm0IYtX)+'&start='+str(start)+'&type='+uuX8TYmVoFRlvpQ7LZ+'&select='+select
			iajEot7NHe = JaQEtCzDXgos1cdZN+JJm06MvE1cZrojkPALugt8YXO9
			rzR9SN7ApZuQhTDWEX3V6ga = {'Content-Type':'application/x-www-form-urlencoded'}
			oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'POST',iajEot7NHe,EwsmJ67cCYDIlg,rzR9SN7ApZuQhTDWEX3V6ga,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'EGYBEST3-TITLES-3rd')
			z0spMAOfJElv6L1K9ae = oCJ8TdG2LwSIVcbaUnhB.content
			z0spMAOfJElv6L1K9ae = 'blocks'+z0spMAOfJElv6L1K9ae+'article'
	items,ZZ9OJHhGUaIASWPD5eTBFwmRvo3Y7,HSAqBpsb2jRLvk9lx147rzY = [],False,False
	if not type:
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('main-content(.*?)</div>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if UUIohmv597bO83YCLgWS:
			PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
			items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?</i>(.*?)</a>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
			for fCXyTlcmF4WuetVork,title in items:
				title = title.strip(iFBmE2MUIpSu34wsd7Rf6z)
				bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,791,iiy37aKq0pCEIOwfcTh61xb4U,'submenu')
				ZZ9OJHhGUaIASWPD5eTBFwmRvo3Y7 = True
	if not type:
		HSAqBpsb2jRLvk9lx147rzY = pumnMZXzQg1EkAP(Vxz6OndPIX4g2kaRp7)
	if not ZZ9OJHhGUaIASWPD5eTBFwmRvo3Y7 and not HSAqBpsb2jRLvk9lx147rzY:
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('blocks(.*?)article',z0spMAOfJElv6L1K9ae,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if UUIohmv597bO83YCLgWS:
			PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
			items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?src="(.*?)".*?class="title">(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
			for fCXyTlcmF4WuetVork,C0dvhEbPWYlUtimM3x,title in items:
				C0dvhEbPWYlUtimM3x = C0dvhEbPWYlUtimM3x.strip(OTlVEGYPSxsNaBdXUucqA3)
				fCXyTlcmF4WuetVork = a9I3YZjc6ySDPE4Kp(fCXyTlcmF4WuetVork)
				if '/selary/' in fCXyTlcmF4WuetVork: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,791,C0dvhEbPWYlUtimM3x)
				elif 'مسلسل' in fCXyTlcmF4WuetVork and 'حلقة' not in fCXyTlcmF4WuetVork: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,796,C0dvhEbPWYlUtimM3x)
				elif 'موسم' in fCXyTlcmF4WuetVork and 'حلقة' not in fCXyTlcmF4WuetVork: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,796,C0dvhEbPWYlUtimM3x)
				else: bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,793,C0dvhEbPWYlUtimM3x)
		o2oZMyNALwBYQCXj4z38sTDg = 12
		data = dEyT9xhGjolYzLCH7460w3.findall('class="(load-more.*?)<',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if len(items)==o2oZMyNALwBYQCXj4z38sTDg and (data or 'pagination' in type):
			EwsmJ67cCYDIlg = 'limit='+str(o2oZMyNALwBYQCXj4z38sTDg)+'&start='+str(start+o2oZMyNALwBYQCXj4z38sTDg)+'&type='+uuX8TYmVoFRlvpQ7LZ+'&select='+select
			eCGwzSrqBmIv = iajEot7NHe+'?next=page&'+EwsmJ67cCYDIlg
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'المزيد',eCGwzSrqBmIv,791,iiy37aKq0pCEIOwfcTh61xb4U,'pagination_'+type)
	return
def pumnMZXzQg1EkAP(Vxz6OndPIX4g2kaRp7):
	HSAqBpsb2jRLvk9lx147rzY = False
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('main-article(.*?)article',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		ddfSDGyqEc = dEyT9xhGjolYzLCH7460w3.findall('data-tax="(.*?)".*?<span>(.*?)<(.*?)</ul>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if ddfSDGyqEc: bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
		for RRIscyLmNH9dq2Dio3TSr,name,PPH1sQtTkDBbnlYpZfo5 in ddfSDGyqEc:
			name = name.strip(iFBmE2MUIpSu34wsd7Rf6z)
			items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)">(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
			for fCXyTlcmF4WuetVork,aasX2cby4Vo5rTgB in items:
				title = name+':  '+aasX2cby4Vo5rTgB
				bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,791,iiy37aKq0pCEIOwfcTh61xb4U,'filter')
				HSAqBpsb2jRLvk9lx147rzY = True
	return HSAqBpsb2jRLvk9lx147rzY
def TW6Z0zqaDl(url):
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(hI7SkXd94fFzAHNZCQoMqEutbnWP,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'EGYBEST3-PLAY-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	ff2PjlcCF5ZWyIUbVguMz,a8jRBLmeA2ti6 = [],[]
	items = dEyT9xhGjolYzLCH7460w3.findall('server-item.*?data-code="(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	for Z70iYh6wclNrmVsdE in items:
		tdI7MClmaAP = UodGe76Lu2IHTYPxBhjk1RpcaqrM.b64decode(Z70iYh6wclNrmVsdE)
		if J1MoiYc7ZwzKS: tdI7MClmaAP = tdI7MClmaAP.decode(df6QpwGxuJVZr)
		fCXyTlcmF4WuetVork = dEyT9xhGjolYzLCH7460w3.findall('src="(.*?)"',tdI7MClmaAP,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if fCXyTlcmF4WuetVork:
			fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork[0]
			if fCXyTlcmF4WuetVork not in a8jRBLmeA2ti6:
				a8jRBLmeA2ti6.append(fCXyTlcmF4WuetVork)
				Zw4M5DUStdE6xp7GI = F82MvyX4ThI6sbnA3efDoVS(fCXyTlcmF4WuetVork,'name')
				ff2PjlcCF5ZWyIUbVguMz.append(fCXyTlcmF4WuetVork+'?named='+Zw4M5DUStdE6xp7GI+'__watch')
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('class="downloads(.*?)</section>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('"tr flex-start".*?<div>[ a-zA-Z]*(\d{3,4})[ a-zA-Z]*</div>.*?href="(.*?)"',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for pMAWqrwP80lR,fCXyTlcmF4WuetVork in items:
			if fCXyTlcmF4WuetVork not in a8jRBLmeA2ti6:
				if '/?url=' in fCXyTlcmF4WuetVork: fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork.split('/?url=')[1]
				a8jRBLmeA2ti6.append(fCXyTlcmF4WuetVork)
				Zw4M5DUStdE6xp7GI = F82MvyX4ThI6sbnA3efDoVS(fCXyTlcmF4WuetVork,'name')
				ff2PjlcCF5ZWyIUbVguMz.append(fCXyTlcmF4WuetVork+'?named='+Zw4M5DUStdE6xp7GI+'__download____'+pMAWqrwP80lR)
	import lqBJGK8hXO
	lqBJGK8hXO.ZDg1HavwueT85mcAOorC4hnS(ff2PjlcCF5ZWyIUbVguMz,sQU2GnRoMwLK8CBdfzmNr4jXyO,'video',url)
	return
def mUhJtHB9nw(text):
	return
# -*- coding: utf-8 -*-
import sys as ytv0YaxDcRINurplWKg587Pwqz
LS5n9Ib81cvhApByQJa6GX4HTf = ytv0YaxDcRINurplWKg587Pwqz.version_info [0] == 2
FVDxSCW5MgK = 2048
o2SVZsYjxd4MPfLCRzv1Ime9XD6rhW = 7
def EnKbMAYoFJ (kc93hiPDm4MqAOaL):
	global BCEn6px5l4
	qR9DalTWtCBVeyYwiQg = ord (kc93hiPDm4MqAOaL [-1])
	SSe8FNopD7MI1EixsPTgl4v3YmfB6 = kc93hiPDm4MqAOaL [:-1]
	T2g7SpExkOcr8NUtfYyMB1d4usRw = qR9DalTWtCBVeyYwiQg % len (SSe8FNopD7MI1EixsPTgl4v3YmfB6)
	fxd3B46829KvYlTG17kUyLNJIbWDp0 = SSe8FNopD7MI1EixsPTgl4v3YmfB6 [:T2g7SpExkOcr8NUtfYyMB1d4usRw] + SSe8FNopD7MI1EixsPTgl4v3YmfB6 [T2g7SpExkOcr8NUtfYyMB1d4usRw:]
	if LS5n9Ib81cvhApByQJa6GX4HTf:
		nXV2GRHyP8dpugjML5sTE4OKN = unicode () .join ([unichr (ord (XXYULyZe1FgwdTVnSx2kHfDAsMClJ9) - FVDxSCW5MgK - (GPf6BlpctR + qR9DalTWtCBVeyYwiQg) % o2SVZsYjxd4MPfLCRzv1Ime9XD6rhW) for GPf6BlpctR, XXYULyZe1FgwdTVnSx2kHfDAsMClJ9 in enumerate (fxd3B46829KvYlTG17kUyLNJIbWDp0)])
	else:
		nXV2GRHyP8dpugjML5sTE4OKN = str () .join ([chr (ord (XXYULyZe1FgwdTVnSx2kHfDAsMClJ9) - FVDxSCW5MgK - (GPf6BlpctR + qR9DalTWtCBVeyYwiQg) % o2SVZsYjxd4MPfLCRzv1Ime9XD6rhW) for GPf6BlpctR, XXYULyZe1FgwdTVnSx2kHfDAsMClJ9 in enumerate (fxd3B46829KvYlTG17kUyLNJIbWDp0)])
	return eval (nXV2GRHyP8dpugjML5sTE4OKN)
hhqd6cnfNJiAaLKTPbst5RpMmZF2G,LyNiIHPOwD3hCUYEFM7,vODxLKW5Ql6r4Fbm8=EnKbMAYoFJ,EnKbMAYoFJ,EnKbMAYoFJ
xpT28sXu051,GGx4qyKP1vUtRghsE2WfaHLMXZ,PtkEvXAqif14G20QZsaSyT=vODxLKW5Ql6r4Fbm8,LyNiIHPOwD3hCUYEFM7,hhqd6cnfNJiAaLKTPbst5RpMmZF2G
SaB5hx3PZwXRLtKgrTfQvId,YzX407G1m8ER9OBpkeuqPIf6Ajrh5,EMO8gy4LrsNTh0knZwpSeU75APW=PtkEvXAqif14G20QZsaSyT,GGx4qyKP1vUtRghsE2WfaHLMXZ,xpT28sXu051
yJeq1BjfiO4NFuwIEzxVLK6b9s,ZchUJdM93pTA7zG5,CCUzMTgQjrHntoiGf16LXW5P8EdVu=EMO8gy4LrsNTh0knZwpSeU75APW,YzX407G1m8ER9OBpkeuqPIf6Ajrh5,SaB5hx3PZwXRLtKgrTfQvId
JZszNnIEMAx28Yao0yqhiXGKOPb,XrTw01KtLzbpoyMf,uuExaKGL7UONtevRd=CCUzMTgQjrHntoiGf16LXW5P8EdVu,ZchUJdM93pTA7zG5,yJeq1BjfiO4NFuwIEzxVLK6b9s
y6y5HtgXO4TkUbwVZ,sVzojQerUqX,tKNPiXfQ7HoAqndw3z9IL4E6VrGv1=uuExaKGL7UONtevRd,XrTw01KtLzbpoyMf,JZszNnIEMAx28Yao0yqhiXGKOPb
AbqCJZdWQP9j,Y41NvKfOroMzGB8sEHy7wbXlc5,hhQwbeiNLoqFjX90fB7aG8VAs=tKNPiXfQ7HoAqndw3z9IL4E6VrGv1,sVzojQerUqX,y6y5HtgXO4TkUbwVZ
IpC4qHXRuyNFjzWv,ppxP0Cg6N3JVELzjGKmkZ2qIlu,L90uqo28xEKSFUwYTcm51yRWZIkft=hhQwbeiNLoqFjX90fB7aG8VAs,Y41NvKfOroMzGB8sEHy7wbXlc5,AbqCJZdWQP9j
FRYcH4KL7e9gv5pEB,tELM0b9FzxuRI4J1CYcie7ZXsHBar,TlGXWLYsV1z=L90uqo28xEKSFUwYTcm51yRWZIkft,ppxP0Cg6N3JVELzjGKmkZ2qIlu,IpC4qHXRuyNFjzWv
ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n,HtK4o2sTPgA78U,zmcGfOdvAjsELeJlP=TlGXWLYsV1z,tELM0b9FzxuRI4J1CYcie7ZXsHBar,FRYcH4KL7e9gv5pEB
UO04GcM7oFd3kJbtKQZHRgI2jeyzCh,MgP8OjoaiWQEVG59,jXE2YHkswT8y=zmcGfOdvAjsELeJlP,HtK4o2sTPgA78U,ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n
from KKv1QhTDGq import *
sQU2GnRoMwLK8CBdfzmNr4jXyO = sVzojQerUqX(u"ࠨࡋࡑࡍ࡙࠭ኄ")
xGpqNiKTnMeHCw2X5zIbSQ = tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠩࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠩኅ")
EGJVsZy38Xx,Toe5N9znWjQHmP4whguld,smglbwR7x2oM,y3qATZDQOch6db5WjnmrguflU,L95mrowGgdsD,zLEP9N4BOsVrXa,XiWJ2PTqvds4pBNebVrt98x,EALyNnv1Db4cUd8sQoZX2pmBVt7kM,XC10geOnQtwrs = Q4APpMirastonc6Wh1v2XOH3K(CzWIqm1YAcEa9gTSZ30fk27)
lBz8JnYhCN3RU = int(y3qATZDQOch6db5WjnmrguflU)
e7wFcO9GDXRq = WwMgozBIC32n9d0tyfp.getInfoLabel(ZchUJdM93pTA7zG5(u"ࠪࡐ࡮ࡹࡴࡊࡶࡨࡱ࠳ࡒࡡࡣࡧ࡯ࠫኆ"))
e7wFcO9GDXRq = e7wFcO9GDXRq.replace(Ds9inqGKb5frAd2CzmWke61aMQ,iiy37aKq0pCEIOwfcTh61xb4U).replace(DApVioTIRMGX,iiy37aKq0pCEIOwfcTh61xb4U)
if lBz8JnYhCN3RU==y6y5HtgXO4TkUbwVZ(u"࠸࠶࠱ኬ"): iM2UNQ69X3kC = sVzojQerUqX(u"ࠫࠥࠦࠠࡗࡧࡵࡷ࡮ࡵ࡮࠻ࠢ࡞ࠤࠬኇ")+DdAjF5pBNL9IqPgkz0xhcQEfU+tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠬࠦ࡝ࠡࠢࠣࡏࡴࡪࡩ࠻ࠢ࡞ࠤࠬኈ")+MDPFS9ovE8daQwhKrI+FRYcH4KL7e9gv5pEB(u"࠭ࠠ࡞ࠩ኉")
else:
	fmxYuJUhKZMRtcA9epjD = a9I3YZjc6ySDPE4Kp(CzWIqm1YAcEa9gTSZ30fk27).replace(PSwfZcdRYhpl5Igqz8xOEk67,iiy37aKq0pCEIOwfcTh61xb4U).replace(aqEsMBckT2bunGHfl48Wip,iiy37aKq0pCEIOwfcTh61xb4U)
	fmxYuJUhKZMRtcA9epjD = fmxYuJUhKZMRtcA9epjD.replace(YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U).strip(iFBmE2MUIpSu34wsd7Rf6z)
	fmxYuJUhKZMRtcA9epjD = fmxYuJUhKZMRtcA9epjD.replace(hnVQObwUcR207fC,iFBmE2MUIpSu34wsd7Rf6z).replace(jHLaUg49SXC6JyTM,iFBmE2MUIpSu34wsd7Rf6z).replace(Wc5GekRC0HQLz7,iFBmE2MUIpSu34wsd7Rf6z)
	iM2UNQ69X3kC = ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠧࠡࠢࠣࡐࡦࡨࡥ࡭࠼ࠣ࡟ࠥ࠭ኊ")+e7wFcO9GDXRq+CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠨࠢࡠࠤࠥࠦࡍࡰࡦࡨ࠾ࠥࡡࠠࠨኋ")+y3qATZDQOch6db5WjnmrguflU+vODxLKW5Ql6r4Fbm8(u"ࠩࠣࡡࠥࠦࠠࡑࡣࡷ࡬࠿࡛ࠦࠡࠩኌ")+fmxYuJUhKZMRtcA9epjD+ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠪࠤࡢ࠭ኍ")
WKquk5EaNr4RzVf(q1rohYuwnfpVZUa98L2CtQzmAcB,xGpqNiKTnMeHCw2X5zIbSQ+OTlVEGYPSxsNaBdXUucqA3+IIZ4e82HBP0oTmtOgaWY7hsMz(sQU2GnRoMwLK8CBdfzmNr4jXyO)+iM2UNQ69X3kC)
if SaB5hx3PZwXRLtKgrTfQvId(u"ࠫࡤ࠭኎") in EALyNnv1Db4cUd8sQoZX2pmBVt7kM: XZt0CwHxU2jne8oEdrQh5MLT,HhVucpbsy12qgXY = EALyNnv1Db4cUd8sQoZX2pmBVt7kM.split(XrTw01KtLzbpoyMf(u"ࠬࡥࠧ኏"),UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"࠱ክ"))
else: XZt0CwHxU2jne8oEdrQh5MLT,HhVucpbsy12qgXY = EALyNnv1Db4cUd8sQoZX2pmBVt7kM,iiy37aKq0pCEIOwfcTh61xb4U
ef74aPgdcbQFAnGok9thpBwY8m06,UIxuCn8wAWpgz5j9EdqFvreH = BF6QAiLUNHh7rKOugaw,iiy37aKq0pCEIOwfcTh61xb4U
if XZt0CwHxU2jne8oEdrQh5MLT in [yJeq1BjfiO4NFuwIEzxVLK6b9s(u"࠭࠱ࠨነ"),hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠧ࠳ࠩኑ"),ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠨ࠵ࠪኒ"),FRYcH4KL7e9gv5pEB(u"ࠩ࠷ࠫና"),IpC4qHXRuyNFjzWv(u"ࠪ࠹ࠬኔ"),zmcGfOdvAjsELeJlP(u"ࠫ࠶࠷ࠧን"),JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠬ࠷࠲ࠨኖ"),JZszNnIEMAx28Yao0yqhiXGKOPb(u"࠭࠱࠴ࠩኗ")] and (AbqCJZdWQP9j(u"ࠧࡂࡆࡇࠫኘ") in HhVucpbsy12qgXY or UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠨࡔࡈࡑࡔ࡜ࡅࠨኙ") in HhVucpbsy12qgXY or GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠩࡘࡔࠬኚ") in HhVucpbsy12qgXY or HtK4o2sTPgA78U(u"ࠪࡈࡔ࡝ࡎࠨኛ") in HhVucpbsy12qgXY):
	from LTAR3BSjNg import niuvdONsTa8A6BPE2wht
	niuvdONsTa8A6BPE2wht(EALyNnv1Db4cUd8sQoZX2pmBVt7kM,XZt0CwHxU2jne8oEdrQh5MLT,HhVucpbsy12qgXY)
	OXsckY7RzjCag9A.setSetting(FRYcH4KL7e9gv5pEB(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡳࡧࡩࡶࡪࡹࡨࠨኜ"),CzWIqm1YAcEa9gTSZ30fk27)
	ef74aPgdcbQFAnGok9thpBwY8m06 = rGPen6cSMHQkAywh8vqI9JXiD2
elif not UYetvipxsyObLZaMw3WVdAgCFEh and lBz8JnYhCN3RU in [SaB5hx3PZwXRLtKgrTfQvId(u"࠳࠵࠸ኮ"),vODxLKW5Ql6r4Fbm8(u"࠹࠴࠹ኯ")]:
	skyPuAlLvecbtRZfB0pzIGd34n7xX9 = str(XC10geOnQtwrs[MgP8OjoaiWQEVG59(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬኝ")])
	sQU2GnRoMwLK8CBdfzmNr4jXyO = SaB5hx3PZwXRLtKgrTfQvId(u"࠭ࡉࡑࡖ࡙ࠫኞ") if lBz8JnYhCN3RU==yJeq1BjfiO4NFuwIEzxVLK6b9s(u"࠵࠷࠺ኰ") else AbqCJZdWQP9j(u"ࠧࡎ࠵ࡘࠫኟ")
	OPHpJi08uoEIrgekzhNv26MlDWBmV9 = sQU2GnRoMwLK8CBdfzmNr4jXyO.lower()
	QlAC9VBYGRckULquednZ0XvOxF4f5M = OXsckY7RzjCag9A.getSetting(JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠨࡣࡹ࠲ࠬአ")+OPHpJi08uoEIrgekzhNv26MlDWBmV9+ZchUJdM93pTA7zG5(u"ࠩ࠱ࡹࡸ࡫ࡲࡢࡩࡨࡲࡹࡥࠧኡ")+skyPuAlLvecbtRZfB0pzIGd34n7xX9)
	aOtvl3xUCgoDIQN0HEVGYf = OXsckY7RzjCag9A.getSetting(tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠪࡥࡻ࠴ࠧኢ")+OPHpJi08uoEIrgekzhNv26MlDWBmV9+JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠫ࠳ࡸࡥࡧࡧࡵࡩࡷࡥࠧኣ")+skyPuAlLvecbtRZfB0pzIGd34n7xX9)
	if QlAC9VBYGRckULquednZ0XvOxF4f5M or aOtvl3xUCgoDIQN0HEVGYf:
		smglbwR7x2oM += PtkEvXAqif14G20QZsaSyT(u"ࠬࢂࠧኤ")
		if QlAC9VBYGRckULquednZ0XvOxF4f5M: smglbwR7x2oM += ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"࠭ࠦࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࡁࠬእ")+QlAC9VBYGRckULquednZ0XvOxF4f5M
		if aOtvl3xUCgoDIQN0HEVGYf: smglbwR7x2oM += YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠧࠧࡔࡨࡪࡪࡸࡥࡳ࠿ࠪኦ")+aOtvl3xUCgoDIQN0HEVGYf
		smglbwR7x2oM = smglbwR7x2oM.replace(HtK4o2sTPgA78U(u"ࠨࡾࠩࠫኧ"),jXE2YHkswT8y(u"ࠩࡿࠫከ"))
	bLNT8mixnpYaZzgf6HR9vMqQj3l = OXsckY7RzjCag9A.getSetting(uuExaKGL7UONtevRd(u"ࠪࡥࡻ࠴ࠧኩ")+OPHpJi08uoEIrgekzhNv26MlDWBmV9+GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠫ࠳ࡹࡥࡳࡸࡨࡶࡤ࠭ኪ")+skyPuAlLvecbtRZfB0pzIGd34n7xX9)
	if bLNT8mixnpYaZzgf6HR9vMqQj3l:
		ioKFMfVvw9dJPR0xGYbZTQlE = dEyT9xhGjolYzLCH7460w3.findall(UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠬࡀ࠯࠰ࠪ࠱࠮ࡄ࠯࠯ࠨካ"),smglbwR7x2oM,dEyT9xhGjolYzLCH7460w3.DOTALL)
		smglbwR7x2oM = smglbwR7x2oM.replace(ioKFMfVvw9dJPR0xGYbZTQlE[FGTfwsjNrB8DvKSZhLIQAb1JnO],bLNT8mixnpYaZzgf6HR9vMqQj3l)
	PsD3IgluKFyvzMLoRT9j5hq2(smglbwR7x2oM,sQU2GnRoMwLK8CBdfzmNr4jXyO,EGJVsZy38Xx)
else:
	import braVAkwfBN
	try: braVAkwfBN.Iey5DnObB6p7ZlJ29jVCvfshzx(EGJVsZy38Xx,Toe5N9znWjQHmP4whguld,smglbwR7x2oM,y3qATZDQOch6db5WjnmrguflU,L95mrowGgdsD,zLEP9N4BOsVrXa,XiWJ2PTqvds4pBNebVrt98x,EALyNnv1Db4cUd8sQoZX2pmBVt7kM,XC10geOnQtwrs,lBz8JnYhCN3RU,XZt0CwHxU2jne8oEdrQh5MLT,HhVucpbsy12qgXY,e7wFcO9GDXRq)
	except Exception as yy2jWo16LdtRQeMXHZpPJO: UIxuCn8wAWpgz5j9EdqFvreH = xiFBCH5hcJks.format_exc()
	ef74aPgdcbQFAnGok9thpBwY8m06 = braVAkwfBN.ef74aPgdcbQFAnGok9thpBwY8m06
TGxWVt7w8K(ef74aPgdcbQFAnGok9thpBwY8m06,UIxuCn8wAWpgz5j9EdqFvreH)
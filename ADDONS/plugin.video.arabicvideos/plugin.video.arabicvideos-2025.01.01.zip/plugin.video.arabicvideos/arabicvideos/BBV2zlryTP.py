# -*- coding: utf-8 -*-
from braVAkwfBN import *
sQU2GnRoMwLK8CBdfzmNr4jXyO = 'GOOGLESEARCH'
ooQEi5O6tYsGVF8LU0TC3hgMeflBwH = '_GOS_'
def sHVM8YchrDjZAJ7(Cpf9s3c0Zngj7XE,kMqh74TPvpSDar59xQUjAyVlHes,U94JwhRgpXCOe5):
	if   Cpf9s3c0Zngj7XE==1010: EA7FzO1kMZGQXDd2giB0cwLom = jihuS9LVAvTrClPapMbUEwfn8XN()
	elif Cpf9s3c0Zngj7XE==1011: EA7FzO1kMZGQXDd2giB0cwLom = oj5OAeuY64(U94JwhRgpXCOe5)
	elif Cpf9s3c0Zngj7XE==1012: EA7FzO1kMZGQXDd2giB0cwLom = XLbzJ21aBFGNdTCt8PwmyeKqEfjM(kMqh74TPvpSDar59xQUjAyVlHes,U94JwhRgpXCOe5)
	elif Cpf9s3c0Zngj7XE==1013: EA7FzO1kMZGQXDd2giB0cwLom = JFOEeDi3whsykPNYWzv()
	elif Cpf9s3c0Zngj7XE==1014: EA7FzO1kMZGQXDd2giB0cwLom = fR0tQGgL3X5qyTus1VeM(kMqh74TPvpSDar59xQUjAyVlHes,U94JwhRgpXCOe5)
	elif Cpf9s3c0Zngj7XE==1015: EA7FzO1kMZGQXDd2giB0cwLom = vA1hfjk3SRI5UNsx9oyJlgGPzbHM2(U94JwhRgpXCOe5)
	elif Cpf9s3c0Zngj7XE==1016: EA7FzO1kMZGQXDd2giB0cwLom = GFcetxYqKHPXN(U94JwhRgpXCOe5)
	elif Cpf9s3c0Zngj7XE==1018: EA7FzO1kMZGQXDd2giB0cwLom = mUhJtHB9nw(U94JwhRgpXCOe5,-ea84RQXsdLY9GIVjSzb)
	elif Cpf9s3c0Zngj7XE==1019: EA7FzO1kMZGQXDd2giB0cwLom = mUhJtHB9nw(U94JwhRgpXCOe5)
	else: EA7FzO1kMZGQXDd2giB0cwLom = False
	return EA7FzO1kMZGQXDd2giB0cwLom
def jihuS9LVAvTrClPapMbUEwfn8XN():
	bP6z3OSLp7va('folder','بحث جوجل جديد',iiy37aKq0pCEIOwfcTh61xb4U,1019,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'_REMEMBERRESULTS_')
	bP6z3OSLp7va('link','كيف يعمل بحث جوجل','',1013)
	bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+'==== كلمات البحث المخزنة ===='+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	AGD5vOKL04tkUrn7aHYfbugsmje2ql = QKzCiBOWZus1nSv(PdkZHNBlpg2b7DmX6qRiyVa,'dict','GLOBALSEARCH_SPLITTED_GOOGLE')
	if AGD5vOKL04tkUrn7aHYfbugsmje2ql:
		AGD5vOKL04tkUrn7aHYfbugsmje2ql = AGD5vOKL04tkUrn7aHYfbugsmje2ql['__SEQUENCED_COLUMNS__']
		for XoJdWFj2HL14SIhExcU in reversed(AGD5vOKL04tkUrn7aHYfbugsmje2ql):
			bP6z3OSLp7va('folder',XoJdWFj2HL14SIhExcU,iiy37aKq0pCEIOwfcTh61xb4U,1019,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,XoJdWFj2HL14SIhExcU)
	return
def mUhJtHB9nw(search,t7zuPMcO8bWUA3ej6DEJ2d4m=ea84RQXsdLY9GIVjSzb):
	search,FG615TlEM78tKb,showDialogs = XkYnev3ZCA6ahO94(search)
	if search==iiy37aKq0pCEIOwfcTh61xb4U: search = TTBf6S08q1NKXd5v9wa()
	if search==iiy37aKq0pCEIOwfcTh61xb4U: return
	aKQTNif8Yw4s = search.replace(ooQEi5O6tYsGVF8LU0TC3hgMeflBwH,iiy37aKq0pCEIOwfcTh61xb4U).lower()
	piln0LAjYq4t,GnOQ0VNH3Dsj1LSx6gWXc4ZI = [],[]
	if t7zuPMcO8bWUA3ej6DEJ2d4m>0: GnOQ0VNH3Dsj1LSx6gWXc4ZI = QKzCiBOWZus1nSv(PdkZHNBlpg2b7DmX6qRiyVa,'list','GOOGLESEARCH_RESULTS',aKQTNif8Yw4s)
	if GnOQ0VNH3Dsj1LSx6gWXc4ZI: piln0LAjYq4t,CqBxQIlscUGrpN38YZkPOu = GnOQ0VNH3Dsj1LSx6gWXc4ZI
	if not GnOQ0VNH3Dsj1LSx6gWXc4ZI or t7zuPMcO8bWUA3ej6DEJ2d4m<0:
		lsSm9JC0bgw4u52WHGinQNM1TeIDv = uu6ypOsHewvYmkz8nafb35Eir(aKQTNif8Yw4s,t7zuPMcO8bWUA3ej6DEJ2d4m)
		piln0LAjYq4t,CqBxQIlscUGrpN38YZkPOu = [],[]
		for YXD9KNfjCaLwkcrvJxldn7I in lsSm9JC0bgw4u52WHGinQNM1TeIDv:
			name,fCXyTlcmF4WuetVork,title,text,pJQbGCZfoX4MkKTDY,ekEOd3mqAThaBDUoIrntuGRjYW = YXD9KNfjCaLwkcrvJxldn7I
			if name==ekEOd3mqAThaBDUoIrntuGRjYW: CqBxQIlscUGrpN38YZkPOu.append(YXD9KNfjCaLwkcrvJxldn7I)
			else: piln0LAjYq4t.append(YXD9KNfjCaLwkcrvJxldn7I)
		import TsIdr4GvYk
		if t7zuPMcO8bWUA3ej6DEJ2d4m>=0: TsIdr4GvYk.RJOu38mxiIjWA4qcP0EG6lUnabT(aKQTNif8Yw4s,'_GOOGLE',True)
		piln0LAjYq4t = sorted(piln0LAjYq4t,reverse=BF6QAiLUNHh7rKOugaw,key=lambda key: key[FGTfwsjNrB8DvKSZhLIQAb1JnO])
		CqBxQIlscUGrpN38YZkPOu = sorted(CqBxQIlscUGrpN38YZkPOu,reverse=BF6QAiLUNHh7rKOugaw,key=lambda key: key[FGTfwsjNrB8DvKSZhLIQAb1JnO])
		YMQXP2BGeK86CEb(PdkZHNBlpg2b7DmX6qRiyVa,'GOOGLESEARCH_RESULTS',aKQTNif8Yw4s,[piln0LAjYq4t,CqBxQIlscUGrpN38YZkPOu],ea84RQXsdLY9GIVjSzb)
		if t7zuPMcO8bWUA3ej6DEJ2d4m<0:
			Bcxq3nkvTU9iM(PdkZHNBlpg2b7DmX6qRiyVa,'GLOBALSEARCH_DETAILED_GOOGLE',aKQTNif8Yw4s)
			TsIdr4GvYk.RJOu38mxiIjWA4qcP0EG6lUnabT(aKQTNif8Yw4s,'_GOOGLE',False)
			Bcxq3nkvTU9iM(PdkZHNBlpg2b7DmX6qRiyVa,'GLOBALSEARCH_DIVIDED_GOOGLE',"%, '"+aKQTNif8Yw4s+"')")
			if piln0LAjYq4t: bb5kRv7jh3LaEVJtIfg('','','رسالة من المبرمج','تم عمل بحث جوجل جديد وتم إيجاد\n\n'+str(len(piln0LAjYq4t))+'  موقع')
			else: piln0LAjYq4t,CqBxQIlscUGrpN38YZkPOu = ThbHWkr0igqFLja2IdYBP6voS3uZV5(aKQTNif8Yw4s,BF6QAiLUNHh7rKOugaw)
	bP6z3OSLp7va('link','بحث جماعي لمواقع جوجل','search_sites_google',1012,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,aKQTNif8Yw4s)
	bP6z3OSLp7va('folder','بحث منفرد لمواقع جوجل',iiy37aKq0pCEIOwfcTh61xb4U,1011,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,aKQTNif8Yw4s)
	bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+'===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	bP6z3OSLp7va('folder','نتائج البحث مفصلة - '+aKQTNif8Yw4s,'opened_sites_google',1012,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,aKQTNif8Yw4s)
	bP6z3OSLp7va('folder','نتائج البحث مقسمة - '+aKQTNif8Yw4s,'listed_sites_google',1012,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,aKQTNif8Yw4s)
	bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+'===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	bP6z3OSLp7va('folder','مواقع جوجل ('+str(len(piln0LAjYq4t))+') - '+aKQTNif8Yw4s,'',1016,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,aKQTNif8Yw4s)
	bP6z3OSLp7va('link','إعادة بحث جوجل - '+aKQTNif8Yw4s,'',1018,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,aKQTNif8Yw4s)
	return
def GFcetxYqKHPXN(aKQTNif8Yw4s):
	piln0LAjYq4t,CqBxQIlscUGrpN38YZkPOu = ThbHWkr0igqFLja2IdYBP6voS3uZV5(aKQTNif8Yw4s)
	if not piln0LAjYq4t and not CqBxQIlscUGrpN38YZkPOu: return
	J8ELVFfk3W7GKsPir4dxtegTqRCy = {}
	for name,fCXyTlcmF4WuetVork,title,text,pJQbGCZfoX4MkKTDY,ekEOd3mqAThaBDUoIrntuGRjYW in piln0LAjYq4t: J8ELVFfk3W7GKsPir4dxtegTqRCy[ekEOd3mqAThaBDUoIrntuGRjYW] = name,fCXyTlcmF4WuetVork,title,text,pJQbGCZfoX4MkKTDY,ekEOd3mqAThaBDUoIrntuGRjYW
	ttFYERwUizgPyOIq91d4WN = list(J8ELVFfk3W7GKsPir4dxtegTqRCy.keys())
	import TsIdr4GvYk
	Hlk8VWd5mBwhL6uxE = TsIdr4GvYk.t624ZFj0bLTEvG1uImXpr7M83oJq(ttFYERwUizgPyOIq91d4WN)
	for ekEOd3mqAThaBDUoIrntuGRjYW in Hlk8VWd5mBwhL6uxE:
		if 'tuple' in str(type(ekEOd3mqAThaBDUoIrntuGRjYW)):
			g6ghGH4aBEYkTl3vbJZ.append(ekEOd3mqAThaBDUoIrntuGRjYW)
			continue
		name,fCXyTlcmF4WuetVork,title,text,pJQbGCZfoX4MkKTDY,ekEOd3mqAThaBDUoIrntuGRjYW = J8ELVFfk3W7GKsPir4dxtegTqRCy[ekEOd3mqAThaBDUoIrntuGRjYW]
		ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,lEgmdMxnfsXj,ZebIE2aQgrGn = GGkFKuWvn5q1wVmldgXz(ekEOd3mqAThaBDUoIrntuGRjYW)
		bP6z3OSLp7va('folder',ZebIE2aQgrGn+name,fCXyTlcmF4WuetVork,1014,pJQbGCZfoX4MkKTDY,'',ekEOd3mqAThaBDUoIrntuGRjYW)
	bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+'===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+'مواقع بجوجل غير موجودة بالبرنامج'+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,1015)
	CqBxQIlscUGrpN38YZkPOu = sorted(CqBxQIlscUGrpN38YZkPOu,reverse=BF6QAiLUNHh7rKOugaw,key=lambda key: key[FGTfwsjNrB8DvKSZhLIQAb1JnO])
	for name,fCXyTlcmF4WuetVork,title,text,pJQbGCZfoX4MkKTDY,ekEOd3mqAThaBDUoIrntuGRjYW in CqBxQIlscUGrpN38YZkPOu:
		bP6z3OSLp7va('link','_GOS_'+PSwfZcdRYhpl5Igqz8xOEk67+name+iFBmE2MUIpSu34wsd7Rf6z+YoQW601K4fMJcsreDnGVE5wUZIy7,fCXyTlcmF4WuetVork,1015,pJQbGCZfoX4MkKTDY,'',ekEOd3mqAThaBDUoIrntuGRjYW)
	return
def ThbHWkr0igqFLja2IdYBP6voS3uZV5(aKQTNif8Yw4s,f1uyjEq9hPiACzL5XsK=rGPen6cSMHQkAywh8vqI9JXiD2):
	piln0LAjYq4t,CqBxQIlscUGrpN38YZkPOu = [],[]
	if f1uyjEq9hPiACzL5XsK:
		GnOQ0VNH3Dsj1LSx6gWXc4ZI = QKzCiBOWZus1nSv(PdkZHNBlpg2b7DmX6qRiyVa,'list','GOOGLESEARCH_RESULTS',aKQTNif8Yw4s)
		if GnOQ0VNH3Dsj1LSx6gWXc4ZI: piln0LAjYq4t,CqBxQIlscUGrpN38YZkPOu = GnOQ0VNH3Dsj1LSx6gWXc4ZI
	if not piln0LAjYq4t and not CqBxQIlscUGrpN38YZkPOu: bb5kRv7jh3LaEVJtIfg('','','رسالة من المبرمج','للأسف جوجل لم يجد مواقع فيها طلبك')
	return piln0LAjYq4t,CqBxQIlscUGrpN38YZkPOu
def XLbzJ21aBFGNdTCt8PwmyeKqEfjM(Vl07OYWcxeMQwgpFAbJnLhRuBf2d6K,aKQTNif8Yw4s):
	piln0LAjYq4t,CqBxQIlscUGrpN38YZkPOu = ThbHWkr0igqFLja2IdYBP6voS3uZV5(aKQTNif8Yw4s)
	if not piln0LAjYq4t and not CqBxQIlscUGrpN38YZkPOu: return
	Zox3q2HilOXJbzBWFw1Y,zqRJEL043jOFocWd7 = [],{}
	for name,fCXyTlcmF4WuetVork,title,text,pJQbGCZfoX4MkKTDY,ekEOd3mqAThaBDUoIrntuGRjYW in piln0LAjYq4t:
		Zox3q2HilOXJbzBWFw1Y.append(ekEOd3mqAThaBDUoIrntuGRjYW)
		zqRJEL043jOFocWd7[ekEOd3mqAThaBDUoIrntuGRjYW] = KhDs4UNAY2Qp9oX(title)
	import TsIdr4GvYk
	TsIdr4GvYk.lHMrpxQJBIz3kwjsvOKd1P(aKQTNif8Yw4s,Vl07OYWcxeMQwgpFAbJnLhRuBf2d6K,iiy37aKq0pCEIOwfcTh61xb4U,Zox3q2HilOXJbzBWFw1Y,zqRJEL043jOFocWd7)
	return
def oj5OAeuY64(aKQTNif8Yw4s):
	piln0LAjYq4t,CqBxQIlscUGrpN38YZkPOu = ThbHWkr0igqFLja2IdYBP6voS3uZV5(aKQTNif8Yw4s)
	if not piln0LAjYq4t and not CqBxQIlscUGrpN38YZkPOu: return
	J8ELVFfk3W7GKsPir4dxtegTqRCy = {}
	for name,fCXyTlcmF4WuetVork,title,text,pJQbGCZfoX4MkKTDY,ekEOd3mqAThaBDUoIrntuGRjYW in piln0LAjYq4t:
		J8ELVFfk3W7GKsPir4dxtegTqRCy[ekEOd3mqAThaBDUoIrntuGRjYW] = name,fCXyTlcmF4WuetVork,title,text,pJQbGCZfoX4MkKTDY,ekEOd3mqAThaBDUoIrntuGRjYW
	ttFYERwUizgPyOIq91d4WN = list(J8ELVFfk3W7GKsPir4dxtegTqRCy.keys())
	import TsIdr4GvYk
	Hlk8VWd5mBwhL6uxE = TsIdr4GvYk.t624ZFj0bLTEvG1uImXpr7M83oJq(ttFYERwUizgPyOIq91d4WN)
	for ekEOd3mqAThaBDUoIrntuGRjYW in Hlk8VWd5mBwhL6uxE:
		if 'tuple' in str(type(ekEOd3mqAThaBDUoIrntuGRjYW)):
			g6ghGH4aBEYkTl3vbJZ.append(ekEOd3mqAThaBDUoIrntuGRjYW)
			continue
		name,fCXyTlcmF4WuetVork,title,text,pJQbGCZfoX4MkKTDY,ekEOd3mqAThaBDUoIrntuGRjYW = J8ELVFfk3W7GKsPir4dxtegTqRCy[ekEOd3mqAThaBDUoIrntuGRjYW]
		ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,lEgmdMxnfsXj,ZebIE2aQgrGn = GGkFKuWvn5q1wVmldgXz(ekEOd3mqAThaBDUoIrntuGRjYW)
		title = KhDs4UNAY2Qp9oX(title)
		name = name+' - '+aKQTNif8Yw4s
		bP6z3OSLp7va('folder',ZebIE2aQgrGn+name,ekEOd3mqAThaBDUoIrntuGRjYW,548,pJQbGCZfoX4MkKTDY,'',title)
	return
def KhDs4UNAY2Qp9oX(title):
	zN7sZyFnw5JTE8 = dEyT9xhGjolYzLCH7460w3.findall('(.*?) (الحلقة|حلقة)',title,dEyT9xhGjolYzLCH7460w3.DOTALL)
	Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb = zN7sZyFnw5JTE8[0][0] if zN7sZyFnw5JTE8 else title
	Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb = Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb.replace('مشاهدة اونلاين، فيديو، الإعلان، صور - السينما.كوم','').replace('- ‎عرب سيد - Arabseed','')
	Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb = Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb.replace('- وى سيما wecima ماى سيما mycima - وي سيما','').replace('- فيديو Dailymotion','')
	Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb = Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb.replace('الموسم','').replace('الموقع','').replace('- شوف نت','').replace('موسم','').replace('HD','')
	Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb = Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb.replace('مشاهدة','').replace('نتائج البحث:','').replace('اونلاين','').replace('- سيما فور بي','')
	Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb = Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb.replace('موقع','').replace('| اكوام','').replace('','').replace('','').replace('','').replace('','')
	Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb = Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb.strip(' ').replace('    ',' ').replace('   ',' ').replace('  ',' ').replace('  ',' ')
	return Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb
def uu6ypOsHewvYmkz8nafb35Eir(search,t7zuPMcO8bWUA3ej6DEJ2d4m):
	search = search.replace(iFBmE2MUIpSu34wsd7Rf6z,'%20')
	url = 'https://www.google.com/search?hl=en&filter=1&imgSize=small&safe=active&num=100&start=0&q='+search
	headers = {'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36 Edg/128.0.0.0'}
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(t7zuPMcO8bWUA3ej6DEJ2d4m,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'GOOGLESEARCH-SEARCH-1st')
	L0Lm9asVYKQuzwHl,l3AHh7iV8PZqCpbocM = [],[]
	if not oCJ8TdG2LwSIVcbaUnhB.succeeded: return L0Lm9asVYKQuzwHl
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	ftgwel75KLyXDJGk = wkMR5x1gTWEQIc6qHCa.path.join(yBIA5N98RmP7pdzeS3s0gOH,'googlesearch')
	if not wkMR5x1gTWEQIc6qHCa.path.exists(ftgwel75KLyXDJGk):
		try: wkMR5x1gTWEQIc6qHCa.makedirs(ftgwel75KLyXDJGk)
		except: pass
	ddfSDGyqEc = dEyT9xhGjolYzLCH7460w3.findall('(\[null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,".*?\]\])',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	for PPH1sQtTkDBbnlYpZfo5 in ddfSDGyqEc:
		PPH1sQtTkDBbnlYpZfo5 = DeIL3qoa2UBtYPb('list',PPH1sQtTkDBbnlYpZfo5)
		if len(PPH1sQtTkDBbnlYpZfo5)>17:
			fCXyTlcmF4WuetVork = PPH1sQtTkDBbnlYpZfo5[17]
			title,text,name,L95mrowGgdsD = PPH1sQtTkDBbnlYpZfo5[31][0:4]
			name = name.strip(' ')
			if not name: name = F82MvyX4ThI6sbnA3efDoVS(fCXyTlcmF4WuetVork,'name')
			name = VzC7H3ty4U8GkD(name)
			if 'http://' in L95mrowGgdsD or 'https://' in L95mrowGgdsD: pJQbGCZfoX4MkKTDY = L95mrowGgdsD
			elif 'data:image/' in L95mrowGgdsD and ';base64,' in L95mrowGgdsD:
				Lg73ITo5kymi4d0rsPXDUM = dEyT9xhGjolYzLCH7460w3.findall('data:image/(\w+);base64,',L95mrowGgdsD)
				Lg73ITo5kymi4d0rsPXDUM = Lg73ITo5kymi4d0rsPXDUM[0]
				pJQbGCZfoX4MkKTDY = wkMR5x1gTWEQIc6qHCa.path.join(ftgwel75KLyXDJGk,name+'.'+Lg73ITo5kymi4d0rsPXDUM)
				if not wkMR5x1gTWEQIc6qHCa.path.exists(pJQbGCZfoX4MkKTDY):
					L95mrowGgdsD = L95mrowGgdsD.replace('\\u003d','=')
					L95mrowGgdsD = L95mrowGgdsD.replace('data:image/'+Lg73ITo5kymi4d0rsPXDUM+';base64,','')
					r8xkpveQBL4UlfItAY0Mu2iFHzg = UodGe76Lu2IHTYPxBhjk1RpcaqrM.b64decode(L95mrowGgdsD)
					open(pJQbGCZfoX4MkKTDY,'wb').write(r8xkpveQBL4UlfItAY0Mu2iFHzg)
			else: pJQbGCZfoX4MkKTDY = ''
			ekEOd3mqAThaBDUoIrntuGRjYW = EnWA8vNCx30V7(name,fCXyTlcmF4WuetVork)
			if ekEOd3mqAThaBDUoIrntuGRjYW not in l3AHh7iV8PZqCpbocM:
				l3AHh7iV8PZqCpbocM.append(ekEOd3mqAThaBDUoIrntuGRjYW)
				name = aanoXVLTZqsIwitBdY0kcJS794FDg(ekEOd3mqAThaBDUoIrntuGRjYW)
				L0Lm9asVYKQuzwHl.append([name,fCXyTlcmF4WuetVork,title,text,pJQbGCZfoX4MkKTDY,ekEOd3mqAThaBDUoIrntuGRjYW])
	return L0Lm9asVYKQuzwHl
def fR0tQGgL3X5qyTus1VeM(fCXyTlcmF4WuetVork,ekEOd3mqAThaBDUoIrntuGRjYW):
	ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,lEgmdMxnfsXj,ZebIE2aQgrGn = GGkFKuWvn5q1wVmldgXz(ekEOd3mqAThaBDUoIrntuGRjYW)
	if ZebIE2aQgrGn: ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI()
	else: vA1hfjk3SRI5UNsx9oyJlgGPzbHM2()
	return
def JFOEeDi3whsykPNYWzv():
	bb5kRv7jh3LaEVJtIfg('','','رسالة من المبرمج','هذا البحث يستخدم ذكاء وشمولية وسرعة محرك بحث جوجل .. ونتائج هذا البحث هي أسماء مواقع الإنترنت التي موجودة في هذا البرنامج والتي فيها الفيديوهات المطلوبة\n\nهذا البحث يحتاج كلمات بحث عادية جدا بدون أي مراعاة لدقة الكلمات أو تفاصيل الفيديوهات أو حتى إملاء الكلمات\n\nهذا البحث يستطيع أيضا أن يفحص محتويات المواقع التي وجدها جوجل إذا كانت هذه المواقع موجودة بهذا البرنامج')
	return
def vA1hfjk3SRI5UNsx9oyJlgGPzbHM2(ekEOd3mqAThaBDUoIrntuGRjYW=''):
	bb5kRv7jh3LaEVJtIfg('','',ekEOd3mqAThaBDUoIrntuGRjYW,'هذا الموقع غير موجود في البرنامج .. أو أسم الموقع مختلف وغير مطابق للاسم المستخدم في البرنامج')
	return
def EnWA8vNCx30V7(name,fCXyTlcmF4WuetVork):
	dIcFoMvKzGhJ9BVTnaQ2Ng = {
	 'فشار فيديو مشاهدة افلام ومسلسلات اون لاين'	:'FUSHARVIDEO'
	,'وى سيما wecima ماى سيما mycima'			:'WECIMA1'
	,'شبكتي تي في - SHABAKATY TV'				:'SHABAKATY'
	,'اكوام  شبكة اكوام AKWAM'					:'AKWAM'
	,'سيما كلوب  CIMACLUB'						:'CIMACLUB'
	,'سيما فري CIMAFREE':'CIMAFREE'
	,'هلا سيما'			:'HALACIMA'
	,'لاروزا'			:'LAROZA'
	,'برستيج'			:'BRSTEJ'
	,'كرمالك TV'		:'KIRMALK'
	,'سيما فور بي'		:'CIMA4P'
	,'اهواك تي في'		:'AHWAK'
	,'CIMA CLUB'		:'CIMACLUB'
	,'اكوام'			:'AKWAM'
	,'وي سيما'			:'WECIMA1'
	,'سيما ناو'			:'CIMANOW'
	,'سيما لايت'			:'CIMALIGHT'
	,'عرب سيد'			:'ARABSEED'
	,'فيديو ياقوت'		:'YAQOT'
	,'المصطبة TV'		:'ALMSTBA'
	,'دراما كافيه'		:'DRAMACAFE'
	,'سيما 400'			:'CIMA400'
	,'فيديو تكات'		:'TIKAAT'
	,'السينما.كوم'		:'ELCINEMA'
	,'فوستا'			:'FOSTA'
	,'سيما عبدو'		:'CIMAABDO'
	,'فاصل إعلاني'		:'FASELHD1'
	,'مسلسلات تايم'		:'SERIESTIME'
	,'برس3تيج'		:''
	,'برس3تيج'		:''
	,'برس3تيج'		:''
	,'برس3تيج'		:''
	,'برس3تيج'		:''
	,'برس3تيج'		:''
	,'برس3تيج'		:''
	,'برس3تيج'		:''
	}
	ccgt6lhpXynUR79P5ev = name.lower()
	umOGqx65jCSBT1 = ''
	for key in list(dIcFoMvKzGhJ9BVTnaQ2Ng.keys()):
		if key.lower() in ccgt6lhpXynUR79P5ev: umOGqx65jCSBT1 = dIcFoMvKzGhJ9BVTnaQ2Ng[key]
	if not umOGqx65jCSBT1:
		hx0dU3Ki7AyEfkSZY6TmN2BwtX = F82MvyX4ThI6sbnA3efDoVS(fCXyTlcmF4WuetVork,'url')
		for ekEOd3mqAThaBDUoIrntuGRjYW in list(gZ4LwbKaOm.keys()):
			q9gapTFDB8jn = F82MvyX4ThI6sbnA3efDoVS(gZ4LwbKaOm[ekEOd3mqAThaBDUoIrntuGRjYW][0],'url')
			if hx0dU3Ki7AyEfkSZY6TmN2BwtX==q9gapTFDB8jn: umOGqx65jCSBT1 = ekEOd3mqAThaBDUoIrntuGRjYW
	if not umOGqx65jCSBT1:
		ccgt6lhpXynUR79P5ev = F82MvyX4ThI6sbnA3efDoVS(fCXyTlcmF4WuetVork,'name')
		for ekEOd3mqAThaBDUoIrntuGRjYW in list(gZ4LwbKaOm.keys()):
			s7efbn0qHXB2 = F82MvyX4ThI6sbnA3efDoVS(gZ4LwbKaOm[ekEOd3mqAThaBDUoIrntuGRjYW][0],'name')
			if ccgt6lhpXynUR79P5ev==s7efbn0qHXB2: umOGqx65jCSBT1 = ekEOd3mqAThaBDUoIrntuGRjYW
	if not umOGqx65jCSBT1: umOGqx65jCSBT1 = name
	umOGqx65jCSBT1 = umOGqx65jCSBT1.upper()
	return umOGqx65jCSBT1
# -*- coding: utf-8 -*-
from braVAkwfBN import *
headers = { 'User-Agent' : iiy37aKq0pCEIOwfcTh61xb4U }
sQU2GnRoMwLK8CBdfzmNr4jXyO = 'AKOAM'
ooQEi5O6tYsGVF8LU0TC3hgMeflBwH = '_AKO_'
JaQEtCzDXgos1cdZN = gZ4LwbKaOm[sQU2GnRoMwLK8CBdfzmNr4jXyO][0]
dd5JFRgHtZpGKaUme9rAxBNX = ['فيلم','كليب','العرض الاسبوعي','مسرحية','مسرحيه','اغنية','اعلان','لقاء']
def sHVM8YchrDjZAJ7(mode,url,text):
	if   mode==70: EA7FzO1kMZGQXDd2giB0cwLom = jihuS9LVAvTrClPapMbUEwfn8XN()
	elif mode==71: EA7FzO1kMZGQXDd2giB0cwLom = hemvDOJkEw2FdCSgnL1VaR(url)
	elif mode==72: EA7FzO1kMZGQXDd2giB0cwLom = AIQeNZP4FMDw9S(url,text)
	elif mode==73: EA7FzO1kMZGQXDd2giB0cwLom = rrtwCXgcfINuH9vkYa5y1OBspl3o(url)
	elif mode==74: EA7FzO1kMZGQXDd2giB0cwLom = TW6Z0zqaDl(url)
	elif mode==79: EA7FzO1kMZGQXDd2giB0cwLom = mUhJtHB9nw(text)
	else: EA7FzO1kMZGQXDd2giB0cwLom = False
	return EA7FzO1kMZGQXDd2giB0cwLom
def jihuS9LVAvTrClPapMbUEwfn8XN():
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'بحث في الموقع',iiy37aKq0pCEIOwfcTh61xb4U,79,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'_REMEMBERRESULTS_')
	bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'سلسلة افلام',iiy37aKq0pCEIOwfcTh61xb4U,79,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'سلسلة افلام')
	bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'سلاسل منوعة',iiy37aKq0pCEIOwfcTh61xb4U,79,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'سلسلة')
	bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	a8GCLIuWNkS = ['الكتب و الابحاث','الكورسات التعليمية','الألعاب','البرامج','الاجهزة اللوحية','الصور و الخلفيات','المصارعة الحرة']
	Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(Dxc7GChQwZ4kOlKHSbL06agnB,JaQEtCzDXgos1cdZN,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,'AKOAM-MENU-1st')
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('class="partions"(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)">(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title in items:
			if title not in a8GCLIuWNkS:
				bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,71)
	return Vxz6OndPIX4g2kaRp7
def hemvDOJkEw2FdCSgnL1VaR(url):
	Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(Dxc7GChQwZ4kOlKHSbL06agnB,url,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,'AKOAM-CATEGORIES-1st')
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('sect_parts(.*?)</div>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?>(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title in items:
			title = title.strip(iFBmE2MUIpSu34wsd7Rf6z)
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,72)
		bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'جميع الفروع',url,72)
	else: AIQeNZP4FMDw9S(url,iiy37aKq0pCEIOwfcTh61xb4U)
	return
def AIQeNZP4FMDw9S(url,type):
	Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(PNjZMS7nxa9clHusz1,url,iiy37aKq0pCEIOwfcTh61xb4U,headers,True,'AKOAM-TITLES-1st')
	items = []
	if type=='featured':
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('section_title featured_title(.*?)subjects-crousel',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)"><div class="subject_box.*?src="(.*?)".*?<h3.*?>(.*?)</h3>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	elif type=='search':
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('akoam_result(.*?)<script',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?background-image: url\((.*?)\).*?<h1>(.*?)</h1>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	elif type=='more':
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('section_title more_title(.*?)footer_bottom_services',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	else:
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('navigation(.*?)<script',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if not items and UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('div class="subject_box.*?href="(.*?)".*?src="(.*?)".*?<h3.*?>(.*?)</h3>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	for fCXyTlcmF4WuetVork,C0dvhEbPWYlUtimM3x,title in items:
		if 'توضيح هام' in title: continue
		title = title.replace(OTlVEGYPSxsNaBdXUucqA3,iiy37aKq0pCEIOwfcTh61xb4U).strip(iFBmE2MUIpSu34wsd7Rf6z)
		title = JIY6A30UOsQboNVqCn(title)
		if any(aasX2cby4Vo5rTgB in title for aasX2cby4Vo5rTgB in dd5JFRgHtZpGKaUme9rAxBNX): bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,73,C0dvhEbPWYlUtimM3x)
		else: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,73,C0dvhEbPWYlUtimM3x)
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('class="pagination"(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall("</li><li >.*?href='(.*?)'>(.*?)<",PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title in items:
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'صفحة '+title,fCXyTlcmF4WuetVork,72,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,type)
	return
def yUY7uKnZaBMXSEObIg3FN9w0(url):
	Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(Dxc7GChQwZ4kOlKHSbL06agnB,url,iiy37aKq0pCEIOwfcTh61xb4U,headers,True,'AKOAM-SECTIONS-2nd')
	eCGwzSrqBmIv = dEyT9xhGjolYzLCH7460w3.findall('"href","(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	eCGwzSrqBmIv = eCGwzSrqBmIv[1]
	return eCGwzSrqBmIv
def rrtwCXgcfINuH9vkYa5y1OBspl3o(url):
	Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(PNjZMS7nxa9clHusz1,url,iiy37aKq0pCEIOwfcTh61xb4U,headers,True,'AKOAM-SECTIONS-1st')
	TTrphz1BIeOocHDmCERZ = dEyT9xhGjolYzLCH7460w3.findall('"(https*://akwam.net/\w+.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	B9epUjo8dR0Wfm6wi = dEyT9xhGjolYzLCH7460w3.findall('"(https*://underurl.com/\w+.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if TTrphz1BIeOocHDmCERZ or B9epUjo8dR0Wfm6wi:
		if TTrphz1BIeOocHDmCERZ: O5Pwg3UFyX0k9E = TTrphz1BIeOocHDmCERZ[0]
		elif B9epUjo8dR0Wfm6wi: O5Pwg3UFyX0k9E = yUY7uKnZaBMXSEObIg3FN9w0(B9epUjo8dR0Wfm6wi[0])
		O5Pwg3UFyX0k9E = a9I3YZjc6ySDPE4Kp(O5Pwg3UFyX0k9E)
		import oIeuaPmibU
		if '/series/' in O5Pwg3UFyX0k9E or '/shows/' in O5Pwg3UFyX0k9E: oIeuaPmibU.YNcMvoVF5swlDBJI7PL(O5Pwg3UFyX0k9E)
		else: oIeuaPmibU.TW6Z0zqaDl(O5Pwg3UFyX0k9E)
		return
	UAhMnV3r89cWy7X1D05GBCwTqOP4p = dEyT9xhGjolYzLCH7460w3.findall('محتوى الفيلم.*?>.*?(\w*?)\W*?<',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UAhMnV3r89cWy7X1D05GBCwTqOP4p and IUF8hYKEGLmHDtXbuWNvnJ(sQU2GnRoMwLK8CBdfzmNr4jXyO,url,UAhMnV3r89cWy7X1D05GBCwTqOP4p): return
	items = dEyT9xhGjolYzLCH7460w3.findall('<br />\n<a href="(.*?)".*?<span style="color:.*?">(.*?)</span>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	for fCXyTlcmF4WuetVork,title in items:
		title = JIY6A30UOsQboNVqCn(title)
		bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,73)
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('class="sub_title".*?<h1.*?>(.*?)</h1>.*?class="main_img".*?src="(.*?)".*?ad-300-250(.*?)ako-feedback',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if not UUIohmv597bO83YCLgWS:
		YYkhEn5xTXLUevzCVNB16mR('خطأ خارجي','لا يوجد ملف فيديو')
		return
	name,C0dvhEbPWYlUtimM3x,PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
	name = name.strip(iFBmE2MUIpSu34wsd7Rf6z)
	if 'sub_epsiode_title' in PPH1sQtTkDBbnlYpZfo5:
		items = dEyT9xhGjolYzLCH7460w3.findall('sub_epsiode_title">(.*?)</h2>.*?sub_file_title.*?>(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	else:
		NOYmEgMxGRca1PHTD = dEyT9xhGjolYzLCH7460w3.findall('sub_file_title\'>(.*?) - <i>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		items = []
		for filename in NOYmEgMxGRca1PHTD:
			items.append( ('رابط التشغيل',filename) )
	if not items: items = [ ('رابط التشغيل',iiy37aKq0pCEIOwfcTh61xb4U) ]
	count = 0
	A7Ap2wdlxM,pfa0P8yik67tBLU9rKCwmu4MO1IZFq = [],[]
	size = len(items)
	for title,filename in items:
		d2xq6KCoULIiPWOyFwp0t = iiy37aKq0pCEIOwfcTh61xb4U
		if ' - ' in filename: filename = filename.split(' - ')[0]
		else: filename = 'dummy.zip'
		if '.' in filename: d2xq6KCoULIiPWOyFwp0t = filename.split('.')[-1]
		title = title.replace(OTlVEGYPSxsNaBdXUucqA3,iiy37aKq0pCEIOwfcTh61xb4U).strip(iFBmE2MUIpSu34wsd7Rf6z)
		A7Ap2wdlxM.append(title)
		pfa0P8yik67tBLU9rKCwmu4MO1IZFq.append(count)
		count += 1
	if size>0:
		if any(aasX2cby4Vo5rTgB in name for aasX2cby4Vo5rTgB in dd5JFRgHtZpGKaUme9rAxBNX):
			if size==1:
				mmfrx2S5XqknFTDeRhj49LuYv1wW0 = 0
			else:
				mmfrx2S5XqknFTDeRhj49LuYv1wW0 = ccv1mVPUsnr('اختر الفيديو المناسب:', A7Ap2wdlxM)
				if mmfrx2S5XqknFTDeRhj49LuYv1wW0 == -1: return
			TW6Z0zqaDl(url+'?section='+str(1+pfa0P8yik67tBLU9rKCwmu4MO1IZFq[size-mmfrx2S5XqknFTDeRhj49LuYv1wW0-1]))
		else:
			for iEfNKT3velFyGth80SA4pxbCRrVD in reversed(range(size)):
				title = name + ' - ' + A7Ap2wdlxM[iEfNKT3velFyGth80SA4pxbCRrVD]
				title = title.replace(OTlVEGYPSxsNaBdXUucqA3,iiy37aKq0pCEIOwfcTh61xb4U).strip(iFBmE2MUIpSu34wsd7Rf6z)
				fCXyTlcmF4WuetVork = url + '?section='+str(size-iEfNKT3velFyGth80SA4pxbCRrVD)
				bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,74,C0dvhEbPWYlUtimM3x)
	else:
		bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'الرابط ليس فيديو',iiy37aKq0pCEIOwfcTh61xb4U,9999,C0dvhEbPWYlUtimM3x)
	return
def TW6Z0zqaDl(url):
	eCGwzSrqBmIv,zN7sZyFnw5JTE8 = url.split('?section=')
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',eCGwzSrqBmIv,iiy37aKq0pCEIOwfcTh61xb4U,headers,True,iiy37aKq0pCEIOwfcTh61xb4U,'AKOAM-PLAY_AKOAM-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('ad-300-250.*?ad-300-250(.*?)ako-feedback',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	I9AEfHClMt48yWB2U5vDNoa0 = UUIohmv597bO83YCLgWS[0].replace("'direct_link_box",'"direct_link_box epsoide_box')
	I9AEfHClMt48yWB2U5vDNoa0 = I9AEfHClMt48yWB2U5vDNoa0 + 'direct_link_box'
	ddfSDGyqEc = dEyT9xhGjolYzLCH7460w3.findall('epsoide_box(.*?)direct_link_box',I9AEfHClMt48yWB2U5vDNoa0,dEyT9xhGjolYzLCH7460w3.DOTALL)
	zN7sZyFnw5JTE8 = len(ddfSDGyqEc)-int(zN7sZyFnw5JTE8)
	PPH1sQtTkDBbnlYpZfo5 = ddfSDGyqEc[zN7sZyFnw5JTE8]
	ff2PjlcCF5ZWyIUbVguMz = []
	OrmgHsQ81yDJtohduT05bpIaK = {'1423075862':'dailymotion','1477487601':'estream','1505328404':'streamango',
		'1423080015':'flashx','1458117295':'openload','1423079306':'vimple','1430052371':'ok.ru',
		'1477488213':'thevid','1558278006':'uqload','1477487990':'vidtodo'}
	items = dEyT9xhGjolYzLCH7460w3.findall("class='download_btn.*?href='(.*?)'",PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	for fCXyTlcmF4WuetVork in items:
		ff2PjlcCF5ZWyIUbVguMz.append(fCXyTlcmF4WuetVork+'?named=________akoam')
	items = dEyT9xhGjolYzLCH7460w3.findall('background-image: url\((.*?)\).*?href=\'(.*?)\'',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	for nD3FCVjZLhdo,fCXyTlcmF4WuetVork in items:
		nD3FCVjZLhdo = nD3FCVjZLhdo.split('/')[-1]
		nD3FCVjZLhdo = nD3FCVjZLhdo.split('.')[0]
		if nD3FCVjZLhdo in OrmgHsQ81yDJtohduT05bpIaK:
			ff2PjlcCF5ZWyIUbVguMz.append(fCXyTlcmF4WuetVork+'?named='+OrmgHsQ81yDJtohduT05bpIaK[nD3FCVjZLhdo]+'________akoam')
		else: ff2PjlcCF5ZWyIUbVguMz.append(fCXyTlcmF4WuetVork+'?named='+nD3FCVjZLhdo+'________akoam')
	if not ff2PjlcCF5ZWyIUbVguMz:
		message = dEyT9xhGjolYzLCH7460w3.findall('sub-no-file.*?\n(.*?)\n',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if message: bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'رسالة من الموقع الاصلي',message[0])
	else:
		import lqBJGK8hXO
		lqBJGK8hXO.ZDg1HavwueT85mcAOorC4hnS(ff2PjlcCF5ZWyIUbVguMz,sQU2GnRoMwLK8CBdfzmNr4jXyO,'video',url)
	return
def mUhJtHB9nw(search):
	search,brFQp5vmgJWdZfEkCBOlu9c,showDialogs = XkYnev3ZCA6ahO94(search)
	if search==iiy37aKq0pCEIOwfcTh61xb4U: search = TTBf6S08q1NKXd5v9wa()
	if search==iiy37aKq0pCEIOwfcTh61xb4U: return
	VVOtdjT9AF4Wk3GECqHL = search.replace(iFBmE2MUIpSu34wsd7Rf6z,'%20')
	url = JaQEtCzDXgos1cdZN + '/search/'+VVOtdjT9AF4Wk3GECqHL
	EA7FzO1kMZGQXDd2giB0cwLom = AIQeNZP4FMDw9S(url,'search')
	return
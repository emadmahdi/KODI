# -*- coding: utf-8 -*-
import sys as ytv0YaxDcRINurplWKg587Pwqz
LS5n9Ib81cvhApByQJa6GX4HTf = ytv0YaxDcRINurplWKg587Pwqz.version_info [0] == 2
FVDxSCW5MgK = 2048
o2SVZsYjxd4MPfLCRzv1Ime9XD6rhW = 7
def EnKbMAYoFJ (kc93hiPDm4MqAOaL):
	global BCEn6px5l4
	qR9DalTWtCBVeyYwiQg = ord (kc93hiPDm4MqAOaL [-1])
	SSe8FNopD7MI1EixsPTgl4v3YmfB6 = kc93hiPDm4MqAOaL [:-1]
	T2g7SpExkOcr8NUtfYyMB1d4usRw = qR9DalTWtCBVeyYwiQg % len (SSe8FNopD7MI1EixsPTgl4v3YmfB6)
	fxd3B46829KvYlTG17kUyLNJIbWDp0 = SSe8FNopD7MI1EixsPTgl4v3YmfB6 [:T2g7SpExkOcr8NUtfYyMB1d4usRw] + SSe8FNopD7MI1EixsPTgl4v3YmfB6 [T2g7SpExkOcr8NUtfYyMB1d4usRw:]
	if LS5n9Ib81cvhApByQJa6GX4HTf:
		nXV2GRHyP8dpugjML5sTE4OKN = unicode () .join ([unichr (ord (XXYULyZe1FgwdTVnSx2kHfDAsMClJ9) - FVDxSCW5MgK - (GPf6BlpctR + qR9DalTWtCBVeyYwiQg) % o2SVZsYjxd4MPfLCRzv1Ime9XD6rhW) for GPf6BlpctR, XXYULyZe1FgwdTVnSx2kHfDAsMClJ9 in enumerate (fxd3B46829KvYlTG17kUyLNJIbWDp0)])
	else:
		nXV2GRHyP8dpugjML5sTE4OKN = str () .join ([chr (ord (XXYULyZe1FgwdTVnSx2kHfDAsMClJ9) - FVDxSCW5MgK - (GPf6BlpctR + qR9DalTWtCBVeyYwiQg) % o2SVZsYjxd4MPfLCRzv1Ime9XD6rhW) for GPf6BlpctR, XXYULyZe1FgwdTVnSx2kHfDAsMClJ9 in enumerate (fxd3B46829KvYlTG17kUyLNJIbWDp0)])
	return eval (nXV2GRHyP8dpugjML5sTE4OKN)
hhqd6cnfNJiAaLKTPbst5RpMmZF2G,LyNiIHPOwD3hCUYEFM7,vODxLKW5Ql6r4Fbm8=EnKbMAYoFJ,EnKbMAYoFJ,EnKbMAYoFJ
xpT28sXu051,GGx4qyKP1vUtRghsE2WfaHLMXZ,PtkEvXAqif14G20QZsaSyT=vODxLKW5Ql6r4Fbm8,LyNiIHPOwD3hCUYEFM7,hhqd6cnfNJiAaLKTPbst5RpMmZF2G
SaB5hx3PZwXRLtKgrTfQvId,YzX407G1m8ER9OBpkeuqPIf6Ajrh5,EMO8gy4LrsNTh0knZwpSeU75APW=PtkEvXAqif14G20QZsaSyT,GGx4qyKP1vUtRghsE2WfaHLMXZ,xpT28sXu051
yJeq1BjfiO4NFuwIEzxVLK6b9s,ZchUJdM93pTA7zG5,CCUzMTgQjrHntoiGf16LXW5P8EdVu=EMO8gy4LrsNTh0knZwpSeU75APW,YzX407G1m8ER9OBpkeuqPIf6Ajrh5,SaB5hx3PZwXRLtKgrTfQvId
JZszNnIEMAx28Yao0yqhiXGKOPb,XrTw01KtLzbpoyMf,uuExaKGL7UONtevRd=CCUzMTgQjrHntoiGf16LXW5P8EdVu,ZchUJdM93pTA7zG5,yJeq1BjfiO4NFuwIEzxVLK6b9s
y6y5HtgXO4TkUbwVZ,sVzojQerUqX,tKNPiXfQ7HoAqndw3z9IL4E6VrGv1=uuExaKGL7UONtevRd,XrTw01KtLzbpoyMf,JZszNnIEMAx28Yao0yqhiXGKOPb
AbqCJZdWQP9j,Y41NvKfOroMzGB8sEHy7wbXlc5,hhQwbeiNLoqFjX90fB7aG8VAs=tKNPiXfQ7HoAqndw3z9IL4E6VrGv1,sVzojQerUqX,y6y5HtgXO4TkUbwVZ
IpC4qHXRuyNFjzWv,ppxP0Cg6N3JVELzjGKmkZ2qIlu,L90uqo28xEKSFUwYTcm51yRWZIkft=hhQwbeiNLoqFjX90fB7aG8VAs,Y41NvKfOroMzGB8sEHy7wbXlc5,AbqCJZdWQP9j
FRYcH4KL7e9gv5pEB,tELM0b9FzxuRI4J1CYcie7ZXsHBar,TlGXWLYsV1z=L90uqo28xEKSFUwYTcm51yRWZIkft,ppxP0Cg6N3JVELzjGKmkZ2qIlu,IpC4qHXRuyNFjzWv
ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n,HtK4o2sTPgA78U,zmcGfOdvAjsELeJlP=TlGXWLYsV1z,tELM0b9FzxuRI4J1CYcie7ZXsHBar,FRYcH4KL7e9gv5pEB
UO04GcM7oFd3kJbtKQZHRgI2jeyzCh,MgP8OjoaiWQEVG59,jXE2YHkswT8y=zmcGfOdvAjsELeJlP,HtK4o2sTPgA78U,ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n
from braVAkwfBN import *
sQU2GnRoMwLK8CBdfzmNr4jXyO = PtkEvXAqif14G20QZsaSyT(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪử")
Kfhm2Mx9LPCGIHTUDZNSFi15B = []
headers = {YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬỮ"):iiy37aKq0pCEIOwfcTh61xb4U}
def ppeGlrhnWwKUDa7Jm(source,EGJVsZy38Xx,url):
	WKquk5EaNr4RzVf(uiza5vIyTWtUeB8sXwAVYMFpgjrk,IIZ4e82HBP0oTmtOgaWY7hsMz(sQU2GnRoMwLK8CBdfzmNr4jXyO)+LyNiIHPOwD3hCUYEFM7(u"ࠩࠣࠤࠥࡌࡡࡪ࡮ࡨࡨࠥ࡬ࡩ࡯ࡦ࡬ࡲ࡬ࠦࡶࡪࡦࡨࡳࠥ࡬ࡩ࡭ࡧࡶࠤࠥࠦࠠࡔ࡫ࡷࡩ࠿࡛ࠦࠡࠩữ")+source+MgP8OjoaiWQEVG59(u"ࠪࠤࡢࠦࠠࠡࠢࡗࡽࡵ࡫࠺ࠡ࡝ࠣࠫỰ")+EGJVsZy38Xx+HtK4o2sTPgA78U(u"ࠫࠥࡣࠧự"))
	YYpDMcwVm2kFGQdbKyHPseiSfa = QKzCiBOWZus1nSv(PdkZHNBlpg2b7DmX6qRiyVa,ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠬࡪࡩࡤࡶࠪỲ"),hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩỳ"),hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠧࡔࡋࡗࡉࡘࡥࡅࡓࡔࡒࡖࡘ࠭Ỵ"))
	twMTcyzmOH61 = X2cQ5NCPvkMieBW7oASspFjE.strftime(ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠨࠧ࡜࠲ࠪࡳ࠮ࠦࡦࠣࠩࡍࡀࠥࡎࠩỵ"),X2cQ5NCPvkMieBW7oASspFjE.gmtime(pwXCQWuGUMka2hFN))
	FHgYoph3Crdti1vBMqTJ82WO = twMTcyzmOH61,url
	key = source+hnVQObwUcR207fC+DdAjF5pBNL9IqPgkz0xhcQEfU+hnVQObwUcR207fC+str(ZD1J5rN8u2wzdgqoyULm4)
	aZtYlicqMKUFPkBCX2AONHwJ4 = iiy37aKq0pCEIOwfcTh61xb4U
	if key not in list(YYpDMcwVm2kFGQdbKyHPseiSfa.keys()): YYpDMcwVm2kFGQdbKyHPseiSfa[key] = [FHgYoph3Crdti1vBMqTJ82WO]
	else:
		if url not in str(YYpDMcwVm2kFGQdbKyHPseiSfa[key]): YYpDMcwVm2kFGQdbKyHPseiSfa[key].append(FHgYoph3Crdti1vBMqTJ82WO)
		else: aZtYlicqMKUFPkBCX2AONHwJ4 = XrTw01KtLzbpoyMf(u"ࠩ࡟ࡲࠥํะศࠢส่ๆ๐ฯ๋๊้ࠣํา่ะࠢไ๎่ࠥวว็ฬࠤฬ๊แ๋ัํ์์อสࠡษ็ฮ๏ࠦไๆࠢอ฽๊๊ࠧỶ")
	g2iSWGcIR9rdQyneOjAHk = FGTfwsjNrB8DvKSZhLIQAb1JnO
	for key in list(YYpDMcwVm2kFGQdbKyHPseiSfa.keys()):
		YYpDMcwVm2kFGQdbKyHPseiSfa[key] = list(set(YYpDMcwVm2kFGQdbKyHPseiSfa[key]))
		g2iSWGcIR9rdQyneOjAHk += len(YYpDMcwVm2kFGQdbKyHPseiSfa[key])
	bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,ZchUJdM93pTA7zG5(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ỷ"),PtkEvXAqif14G20QZsaSyT(u"้๊ࠫริใࠣห้ฮั็ษ่ะ๊ࠥๅࠡ์ฯำ๋ࠥไโษอࠤฬ๊แ๋ัํ์ࠬỸ")+aZtYlicqMKUFPkBCX2AONHwJ4+jXE2YHkswT8y(u"ࠬࡢ࡮࡝ࡰ่้ࠣ฿ไๆࠢส่อืๆศ็ฯࠤ๏่่ๆࠢหะ๊฿ࠠใษษ้ฮࠦศศๆไ๎ิ๐่่ษอࠤฬ๊ส๋ࠢ็้ࠥ๐ฬะࠢ็๋ฬࠦๅๅใสฮࠥ็๊ะ์๋ࠤํู่โࠢํ฽ึ฼ฺࠠๆํ็ࠥอไษำ้ห๊าࠠฤ่ࠣฮึูไ้ࠡำ๋ࠥอไใษษ้ฮࠦลๅ๋ࠣห้๋ศา็ฯࠤ฾์ฯๆษࠣ๎ฺฮอࠡ฻าำ์อࠠ࠶ࠢไ๎ิ๐่่ษอࠫỹ")+UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"࠭࡜࡯࡞ࡱࠫỺ")+Y41NvKfOroMzGB8sEHy7wbXlc5(u"ฺࠧัาࠤฬ๊แ๋ัํ์์อสࠡใํࠤฬ๊โศศ่อࠥอไร่๋ࠣํࠦ࠺ࠡࠢࠪỻ")+str(g2iSWGcIR9rdQyneOjAHk))
	if g2iSWGcIR9rdQyneOjAHk>=LyNiIHPOwD3hCUYEFM7(u"࠸อ"):
		U17QqF2gkI46 = A1AXKupEOfz(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,PtkEvXAqif14G20QZsaSyT(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫỼ"),hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠩส่อืๆศ็ฯࠤัู๋ࠡไสส๊ฯࠠโ์๊หࠥ࠻ࠠโ์า๎ํํวหࠢ็้ࠥ๐ฬะࠢส่อืๆศ็ฯࠤ้ํวࠡ็็ๅฬะࠠโ์า๎ํࠦ࠮࠯ࠢึ์ๆ๊ࠦใ๊่ࠤฬ๊ศา่ส้ัࠦวๅฤ้ࠤอ๋ำฮ๊ࠢิ์ࠦวๅไสส๊ฯࠠ࡝ࡰ࡟ࡲࠥํไࠡฬิ๎ิࠦลาีส่ࠥํะ่ࠢส่็อฦๆหࠣๆอ๊ࠠๆีะ๋ฬࠦลๅ๋ࠣห้๋ศา็ฯࠤ้้๊ࠡ์ๅ์๊ࠦวๅ็หี๊าࠠษใะูࠥํะ่ࠢส่ๆ๐ฯ๋๊๊หฯࠦฟࠢࠣࠪỽ"))
		if U17QqF2gkI46==L90uqo28xEKSFUwYTcm51yRWZIkft(u"࠵ฮ"):
			G8hQ3CqBwpW7EZjzvesHxP = iiy37aKq0pCEIOwfcTh61xb4U
			for key in list(YYpDMcwVm2kFGQdbKyHPseiSfa.keys()):
				G8hQ3CqBwpW7EZjzvesHxP += OTlVEGYPSxsNaBdXUucqA3+key
				F9wjltD1bSYT8qRrGpevfsN = sorted(YYpDMcwVm2kFGQdbKyHPseiSfa[key],reverse=BF6QAiLUNHh7rKOugaw,key=lambda KV2LyniSrI: KV2LyniSrI[FGTfwsjNrB8DvKSZhLIQAb1JnO])
				for twMTcyzmOH61,url in F9wjltD1bSYT8qRrGpevfsN:
					G8hQ3CqBwpW7EZjzvesHxP += OTlVEGYPSxsNaBdXUucqA3+twMTcyzmOH61+hnVQObwUcR207fC+a9I3YZjc6ySDPE4Kp(url)
				G8hQ3CqBwpW7EZjzvesHxP += uuExaKGL7UONtevRd(u"ࠪࡠࡳࡢ࡮ࠨỾ")
			import lpTiXPCdwE
			M5qyIg2dZlm6FxH4tTPV79okNu0bCG = lpTiXPCdwE.EmxZ2PWFGSaYQNkclpnVsR(tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"࡛ࠫ࡯ࡤࡦࡱࡶࠫỿ"),iiy37aKq0pCEIOwfcTh61xb4U,BF6QAiLUNHh7rKOugaw,iiy37aKq0pCEIOwfcTh61xb4U,TlGXWLYsV1z(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡒࡏࡅ࡞ࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩἀ"),iiy37aKq0pCEIOwfcTh61xb4U,G8hQ3CqBwpW7EZjzvesHxP)
			if M5qyIg2dZlm6FxH4tTPV79okNu0bCG: bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,JZszNnIEMAx28Yao0yqhiXGKOPb(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩἁ"),tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠧห็ࠣห้หัิษ็ࠤอ์ฬศฯࠪἂ"))
			else: bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,AbqCJZdWQP9j(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫἃ"),uuExaKGL7UONtevRd(u"ࠩไุ้ะฺࠠ็็๎ฮࠦวๅวิืฬ๊ࠧἄ"))
		if U17QqF2gkI46!=-YYJQyRskpX8jv:
			YYpDMcwVm2kFGQdbKyHPseiSfa = {}
			Bcxq3nkvTU9iM(PdkZHNBlpg2b7DmX6qRiyVa,MgP8OjoaiWQEVG59(u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭ἅ"),ZchUJdM93pTA7zG5(u"ࠫࡘࡏࡔࡆࡕࡢࡉࡗࡘࡏࡓࡕࠪἆ"))
	if YYpDMcwVm2kFGQdbKyHPseiSfa: YMQXP2BGeK86CEb(PdkZHNBlpg2b7DmX6qRiyVa,FRYcH4KL7e9gv5pEB(u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨἇ"),L90uqo28xEKSFUwYTcm51yRWZIkft(u"࠭ࡓࡊࡖࡈࡗࡤࡋࡒࡓࡑࡕࡗࠬἈ"),YYpDMcwVm2kFGQdbKyHPseiSfa,VaeMF1mIjQ5iLtfGcB)
	return
def eYTGRMa9Sow18xr7Xpc0iC(dycQVJHaAt,source):
	adfKwimHOzu7n469yXt,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8,fwDKASjdbmGvouLTFke = [],[],[],[]
	for BFWTwxolSOAP9Uj in dycQVJHaAt[:]:
		UeNwXE5tWKhFTZ7q9k8zu0vxapm14,Tah1vG47QFrxd = BFWTwxolSOAP9Uj,ZchUJdM93pTA7zG5(u"ࠧࠨἉ")
		if tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩἊ") in BFWTwxolSOAP9Uj: UeNwXE5tWKhFTZ7q9k8zu0vxapm14,Tah1vG47QFrxd = BFWTwxolSOAP9Uj.split(sVzojQerUqX(u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪἋ"),YYJQyRskpX8jv)
		if UeNwXE5tWKhFTZ7q9k8zu0vxapm14 in fwDKASjdbmGvouLTFke: continue
		if source==PtkEvXAqif14G20QZsaSyT(u"ࠪࡅࡑࡓࡓࡕࡄࡄࠫἌ"): phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = uuAyGoxEWv7(UeNwXE5tWKhFTZ7q9k8zu0vxapm14)
		elif EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠫࡶࡼࡩࡥࠩἍ") in UeNwXE5tWKhFTZ7q9k8zu0vxapm14: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = uuAyGoxEWv7(UeNwXE5tWKhFTZ7q9k8zu0vxapm14)
		if duef0gb3Mi1AV5WpN8:
			dycQVJHaAt.remove(BFWTwxolSOAP9Uj)
			phDAJlISKQmV9dnB5tRsFTyecGwC3 = dEyT9xhGjolYzLCH7460w3.findall(PtkEvXAqif14G20QZsaSyT(u"ࠬࡴࡡ࡮ࡧࡧࡁ࠳࠰࠿ࡠࡡࠫ࠲࠯ࡅࠩࡠࡡࠪἎ"),BFWTwxolSOAP9Uj+FRYcH4KL7e9gv5pEB(u"࠭࡟ࡠࠩἏ"),dEyT9xhGjolYzLCH7460w3.DOTALL)
			phDAJlISKQmV9dnB5tRsFTyecGwC3 = phDAJlISKQmV9dnB5tRsFTyecGwC3[ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"࠵ฯ")] if phDAJlISKQmV9dnB5tRsFTyecGwC3 else LyNiIHPOwD3hCUYEFM7(u"ࠧࠨἐ")
			for Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb,hx0dU3Ki7AyEfkSZY6TmN2BwtX in zip(A7Ap2wdlxM,duef0gb3Mi1AV5WpN8):
				if hx0dU3Ki7AyEfkSZY6TmN2BwtX in fwDKASjdbmGvouLTFke: continue
				fwDKASjdbmGvouLTFke.append(hx0dU3Ki7AyEfkSZY6TmN2BwtX)
				hx0dU3Ki7AyEfkSZY6TmN2BwtX = hx0dU3Ki7AyEfkSZY6TmN2BwtX+yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩἑ")+Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb+FRYcH4KL7e9gv5pEB(u"ࠩࡢࡣࠬἒ")+phDAJlISKQmV9dnB5tRsFTyecGwC3
				adfKwimHOzu7n469yXt.append(hx0dU3Ki7AyEfkSZY6TmN2BwtX)
	return dycQVJHaAt+adfKwimHOzu7n469yXt
def ZDg1HavwueT85mcAOorC4hnS(ff2PjlcCF5ZWyIUbVguMz,source,EGJVsZy38Xx,url):
	if not ff2PjlcCF5ZWyIUbVguMz:
		ppeGlrhnWwKUDa7Jm(source,EGJVsZy38Xx,url)
		return
	ff2PjlcCF5ZWyIUbVguMz = eYTGRMa9Sow18xr7Xpc0iC(ff2PjlcCF5ZWyIUbVguMz,source)
	ff2PjlcCF5ZWyIUbVguMz = list(set(ff2PjlcCF5ZWyIUbVguMz))
	A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = jSN2OF7lcKViRHxnLGTvf(ff2PjlcCF5ZWyIUbVguMz,source)
	if IiCsQD91HF.resolveonly:
		t15bwsPEJOkD6eUC = clqJiEdkt0GzeHYvOBK34(A7Ap2wdlxM,duef0gb3Mi1AV5WpN8,source,BF6QAiLUNHh7rKOugaw)
		return
	S9nrvDAwHBexGt,phm0nfzAUCXHBjO7lIDSxT3eZJdc,yseMbuKXOnkB96AxFEQzULWR3fGTN,t15bwsPEJOkD6eUC,VquYgABQN9PxMwst2OhJv,YXD9KNfjCaLwkcrvJxldn7I = BF6QAiLUNHh7rKOugaw,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,[],iiy37aKq0pCEIOwfcTh61xb4U,[]
	DDcfJqGEQedK = not any(aasX2cby4Vo5rTgB in source for aasX2cby4Vo5rTgB in llVTWkotwd)
	if DDcfJqGEQedK:
		La5Gh8JZcfv = FGTfwsjNrB8DvKSZhLIQAb1JnO
		lGrSDThdLQ2C0PvBn = QKzCiBOWZus1nSv(PdkZHNBlpg2b7DmX6qRiyVa,ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠪࡰ࡮ࡹࡴࠨἓ"),JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡉࡥࡓࡖࡅࡆࡉࡊࡊࡅࡅࠩἔ"))
		DtQAUl1bovV = QKzCiBOWZus1nSv(PdkZHNBlpg2b7DmX6qRiyVa,ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠬࡲࡩࡴࡶࠪἕ"),MgP8OjoaiWQEVG59(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡄࡠࡈࡄࡍࡑࡋࡄࠨ἖"))
		rxbivCFQ9aAnpckTUXYh65dH4 = FGTfwsjNrB8DvKSZhLIQAb1JnO
		for title,fCXyTlcmF4WuetVork in zip(A7Ap2wdlxM,duef0gb3Mi1AV5WpN8):
			fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork.split(MgP8OjoaiWQEVG59(u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ἗"),YYJQyRskpX8jv)[FGTfwsjNrB8DvKSZhLIQAb1JnO]
			if fCXyTlcmF4WuetVork in lGrSDThdLQ2C0PvBn:
				La5Gh8JZcfv += YYJQyRskpX8jv
				A7Ap2wdlxM[rxbivCFQ9aAnpckTUXYh65dH4] = MJSF94CaiBj2+title+YoQW601K4fMJcsreDnGVE5wUZIy7
			elif fCXyTlcmF4WuetVork in DtQAUl1bovV:
				La5Gh8JZcfv += YYJQyRskpX8jv
				A7Ap2wdlxM[rxbivCFQ9aAnpckTUXYh65dH4] = PSwfZcdRYhpl5Igqz8xOEk67+title+YoQW601K4fMJcsreDnGVE5wUZIy7
			rxbivCFQ9aAnpckTUXYh65dH4 += YYJQyRskpX8jv
		YXD9KNfjCaLwkcrvJxldn7I = [aqEsMBckT2bunGHfl48Wip+SaB5hx3PZwXRLtKgrTfQvId(u"ࠨใะูࠥาๅ๋฻ࠣหู้๊าใิหฯ࠭Ἐ")+YoQW601K4fMJcsreDnGVE5wUZIy7]
	else: VquYgABQN9PxMwst2OhJv = aqEsMBckT2bunGHfl48Wip+Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠩฦาฯืࠠศๆึ๎ึ็ัࠡษ็้๋อำษࠩἙ")+YoQW601K4fMJcsreDnGVE5wUZIy7
	LsjrhQpZKcn41EyDwlFBm0IYtX = OXsckY7RzjCag9A.getSetting(sVzojQerUqX(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡢࡪࡶࡵࡥࡹ࡫ࠧἚ"))
	RRZcwlH5nID49W6FJumjUPq7ipT = uuExaKGL7UONtevRd(u"ࠫ࠲࠭Ἓ") not in LsjrhQpZKcn41EyDwlFBm0IYtX
	while rGPen6cSMHQkAywh8vqI9JXiD2:
		U1iY5TqB9ukgeoVp = rGPen6cSMHQkAywh8vqI9JXiD2
		if DDcfJqGEQedK:
			if RRZcwlH5nID49W6FJumjUPq7ipT and len(A7Ap2wdlxM)==YYJQyRskpX8jv: mmfrx2S5XqknFTDeRhj49LuYv1wW0 = YYJQyRskpX8jv
			else:
				QdalxsyVTm6c = str(A7Ap2wdlxM).count(MJSF94CaiBj2)
				qmLoU32MEG0gQYxVdcTz7S = str(A7Ap2wdlxM).count(PSwfZcdRYhpl5Igqz8xOEk67)
				PPKBFmrkGc7HyTd = len(A7Ap2wdlxM)-QdalxsyVTm6c-qmLoU32MEG0gQYxVdcTz7S
				if iELueYz3J1FmxaW7vc: VquYgABQN9PxMwst2OhJv = PSwfZcdRYhpl5Igqz8xOEk67+tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠬࠦࠠࠡีํสฮࡀࠧἜ")+str(qmLoU32MEG0gQYxVdcTz7S)+YoQW601K4fMJcsreDnGVE5wUZIy7+sVzojQerUqX(u"่࠭ࠠࠡࠢะ์๎ไส࠼ࠪἝ")+str(PPKBFmrkGc7HyTd)+MJSF94CaiBj2+PtkEvXAqif14G20QZsaSyT(u"ࠧอ์าอ࠿࠭἞")+str(QdalxsyVTm6c)+YoQW601K4fMJcsreDnGVE5wUZIy7
				else: VquYgABQN9PxMwst2OhJv = MJSF94CaiBj2+xpT28sXu051(u"ࠨฮํำฮࡀࠧ἟")+str(QdalxsyVTm6c)+YoQW601K4fMJcsreDnGVE5wUZIy7+sVzojQerUqX(u"ࠩࠣࠤ๋ࠥฬ่๊็อ࠿࠭ἠ")+str(PPKBFmrkGc7HyTd)+PSwfZcdRYhpl5Igqz8xOEk67+AbqCJZdWQP9j(u"ࠪࠤࠥࠦำ๋ศฬ࠾ࠬἡ")+str(qmLoU32MEG0gQYxVdcTz7S)+YoQW601K4fMJcsreDnGVE5wUZIy7
				mmfrx2S5XqknFTDeRhj49LuYv1wW0 = ccv1mVPUsnr(VquYgABQN9PxMwst2OhJv,YXD9KNfjCaLwkcrvJxldn7I+A7Ap2wdlxM)
			if mmfrx2S5XqknFTDeRhj49LuYv1wW0==FGTfwsjNrB8DvKSZhLIQAb1JnO:
				U1iY5TqB9ukgeoVp = BF6QAiLUNHh7rKOugaw
				start,end = FGTfwsjNrB8DvKSZhLIQAb1JnO,len(A7Ap2wdlxM)-YYJQyRskpX8jv
				t15bwsPEJOkD6eUC = clqJiEdkt0GzeHYvOBK34(A7Ap2wdlxM,duef0gb3Mi1AV5WpN8,source,rGPen6cSMHQkAywh8vqI9JXiD2)
				yseMbuKXOnkB96AxFEQzULWR3fGTN = IpC4qHXRuyNFjzWv(u"ࠫࡷ࡫ࡳࡰ࡮ࡹࡩࡩࡥࡡ࡭࡮ࠪἢ") if t15bwsPEJOkD6eUC else jXE2YHkswT8y(u"ࠬࡴ࡯ࡵࡡࡵࡩࡸࡵ࡬ࡷࡣࡥࡰࡪ࠭ἣ")
			elif mmfrx2S5XqknFTDeRhj49LuYv1wW0>FGTfwsjNrB8DvKSZhLIQAb1JnO: start,end = mmfrx2S5XqknFTDeRhj49LuYv1wW0-YYJQyRskpX8jv,mmfrx2S5XqknFTDeRhj49LuYv1wW0-YYJQyRskpX8jv
		else:
			if RRZcwlH5nID49W6FJumjUPq7ipT and len(A7Ap2wdlxM)==YYJQyRskpX8jv: mmfrx2S5XqknFTDeRhj49LuYv1wW0 = FGTfwsjNrB8DvKSZhLIQAb1JnO
			else: mmfrx2S5XqknFTDeRhj49LuYv1wW0 = ccv1mVPUsnr(VquYgABQN9PxMwst2OhJv,A7Ap2wdlxM)
			start,end = mmfrx2S5XqknFTDeRhj49LuYv1wW0,mmfrx2S5XqknFTDeRhj49LuYv1wW0
		if mmfrx2S5XqknFTDeRhj49LuYv1wW0==-YYJQyRskpX8jv:
			yseMbuKXOnkB96AxFEQzULWR3fGTN = TlGXWLYsV1z(u"࠭ࡣࡢࡰࡦࡩࡱ࡫ࡤࠨἤ")
			break
		if U1iY5TqB9ukgeoVp:
			yseMbuKXOnkB96AxFEQzULWR3fGTN = PtkEvXAqif14G20QZsaSyT(u"ࠧࡳࡧࡶࡳࡱࡼࡥࡥࡡࡲࡲࡪ࠭ἥ")
			t15bwsPEJOkD6eUC = clqJiEdkt0GzeHYvOBK34([A7Ap2wdlxM[start]],[duef0gb3Mi1AV5WpN8[start]],source,rGPen6cSMHQkAywh8vqI9JXiD2)
			title,fCXyTlcmF4WuetVork,phm0nfzAUCXHBjO7lIDSxT3eZJdc,v1JrBsOo8Qyzk,P3tys0cXWbiIUKk7HQ6n89V = t15bwsPEJOkD6eUC[FGTfwsjNrB8DvKSZhLIQAb1JnO]
			y2boSPsYmFjZBJzWpMEica6HRD,FTs8KiI6n0S9EYowBLDNgQu7C5VjU = dbgzVjEGO01wXAuTPI8crCWam3S5B(title,fCXyTlcmF4WuetVork,v1JrBsOo8Qyzk,P3tys0cXWbiIUKk7HQ6n89V,source,EGJVsZy38Xx)
			if y2boSPsYmFjZBJzWpMEica6HRD in [UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦ࡬ࡲ࡬࠭ἦ"),TlGXWLYsV1z(u"ࠩࡳࡰࡦࡿࡩ࡯ࡩࠪἧ"),CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠪࡸࡪࡹࡴࡪࡰࡪࠫἨ")]:
				S9nrvDAwHBexGt = rGPen6cSMHQkAywh8vqI9JXiD2
				break
			else:
				if not phm0nfzAUCXHBjO7lIDSxT3eZJdc: phm0nfzAUCXHBjO7lIDSxT3eZJdc = SaB5hx3PZwXRLtKgrTfQvId(u"࡛ࠫ࡯ࡤࡦࡱࠣࡴࡱࡧࡹࠡࡨࡤ࡭ࡱ࡫ࡤࠨἩ")
				title = PSwfZcdRYhpl5Igqz8xOEk67+title+YoQW601K4fMJcsreDnGVE5wUZIy7
				t15bwsPEJOkD6eUC[FGTfwsjNrB8DvKSZhLIQAb1JnO] = title,fCXyTlcmF4WuetVork,phm0nfzAUCXHBjO7lIDSxT3eZJdc,v1JrBsOo8Qyzk,P3tys0cXWbiIUKk7HQ6n89V
				mbIOiTzgY5 = fCXyTlcmF4WuetVork.split(LyNiIHPOwD3hCUYEFM7(u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭Ἢ"),YYJQyRskpX8jv)[FGTfwsjNrB8DvKSZhLIQAb1JnO]
				Bcxq3nkvTU9iM(PdkZHNBlpg2b7DmX6qRiyVa,GGx4qyKP1vUtRghsE2WfaHLMXZ(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡄࡠࡕࡘࡇࡈࡋࡅࡅࡇࡇࠫἫ"),mbIOiTzgY5)
				YMQXP2BGeK86CEb(PdkZHNBlpg2b7DmX6qRiyVa,JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡅࡡࡉࡅࡎࡒࡅࡅࠩἬ"),mbIOiTzgY5,[phm0nfzAUCXHBjO7lIDSxT3eZJdc,title,fCXyTlcmF4WuetVork],PNjZMS7nxa9clHusz1)
			if phm0nfzAUCXHBjO7lIDSxT3eZJdc==CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠨࡇ࡛ࡍ࡙ࡥࡁࡍࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭Ἥ"): break
			sHPiAac6dgOCYJoXbuhwDGlUFmS = ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠩ࡞ࡐࡊࡌࡔ࡞ࠢࠣࠫἮ")+phm0nfzAUCXHBjO7lIDSxT3eZJdc.replace(OTlVEGYPSxsNaBdXUucqA3,FRYcH4KL7e9gv5pEB(u"ࠪࡠࡳࡡࡌࡆࡈࡗࡡࠥࠦࠧἯ")) if phm0nfzAUCXHBjO7lIDSxT3eZJdc.count(OTlVEGYPSxsNaBdXUucqA3)>HtK4o2sTPgA78U(u"࠹ะ") else OTlVEGYPSxsNaBdXUucqA3+phm0nfzAUCXHBjO7lIDSxT3eZJdc
			if MgP8OjoaiWQEVG59(u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬἰ") not in source: bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨἱ"),yJeq1BjfiO4NFuwIEzxVLK6b9s(u"࠭วๅีํีๆืࠠๅ็ࠣ๎฾๋ไࠡฮิฬู๊ࠥาใิࠤ฿๐ั่ࠩἲ")+OTlVEGYPSxsNaBdXUucqA3+sHPiAac6dgOCYJoXbuhwDGlUFmS,profile=ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠧࡤࡱࡱࡪ࡮ࡸ࡭ࡠ࡯ࡨࡨ࡮ࡻ࡭ࡧࡱࡱࡸࠬἳ"))
			if len(duef0gb3Mi1AV5WpN8)==YYJQyRskpX8jv and phm0nfzAUCXHBjO7lIDSxT3eZJdc: break
		for rxbivCFQ9aAnpckTUXYh65dH4 in range(start,end+YYJQyRskpX8jv):
			y9YluP8fpWOeKsiX4gJVvjqSt60 = FGTfwsjNrB8DvKSZhLIQAb1JnO if U1iY5TqB9ukgeoVp else rxbivCFQ9aAnpckTUXYh65dH4
			title,fCXyTlcmF4WuetVork,phm0nfzAUCXHBjO7lIDSxT3eZJdc,v1JrBsOo8Qyzk,P3tys0cXWbiIUKk7HQ6n89V = t15bwsPEJOkD6eUC[y9YluP8fpWOeKsiX4gJVvjqSt60]
			A7Ap2wdlxM[rxbivCFQ9aAnpckTUXYh65dH4] = A7Ap2wdlxM[rxbivCFQ9aAnpckTUXYh65dH4].replace(PSwfZcdRYhpl5Igqz8xOEk67,iiy37aKq0pCEIOwfcTh61xb4U).replace(MJSF94CaiBj2,iiy37aKq0pCEIOwfcTh61xb4U).replace(YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U)
			if phm0nfzAUCXHBjO7lIDSxT3eZJdc: A7Ap2wdlxM[rxbivCFQ9aAnpckTUXYh65dH4] = PSwfZcdRYhpl5Igqz8xOEk67+A7Ap2wdlxM[rxbivCFQ9aAnpckTUXYh65dH4]+YoQW601K4fMJcsreDnGVE5wUZIy7
			else: A7Ap2wdlxM[rxbivCFQ9aAnpckTUXYh65dH4] = MJSF94CaiBj2+A7Ap2wdlxM[rxbivCFQ9aAnpckTUXYh65dH4]+YoQW601K4fMJcsreDnGVE5wUZIy7
	if yseMbuKXOnkB96AxFEQzULWR3fGTN==L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠨࡰࡲࡸࡤࡸࡥࡴࡱ࡯ࡺࡦࡨ࡬ࡦࠩἴ"): bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,vODxLKW5Ql6r4Fbm8(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬἵ"),tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"่้ࠪษำโࠢ็หࠥ๐่อัࠣื๏ืแาษอࠤั๐ฯสࠢไ๎ࠥํะศࠢส่ๆ๐ฯ๋๊ࠣ࠲࠳ࠦอศ๊็ࠤศ์ࠠหสะฯࠥ฿ๆ้ࠡำหࠥอไโ์า๎ํࠦแ๋่ࠢ์ฬู่ࠡลัี๎ࠦแ๋๊ࠢิฬࠦวๅสิ๊ฬ๋ฬࠨἶ"))
	if not S9nrvDAwHBexGt or yseMbuKXOnkB96AxFEQzULWR3fGTN in [zmcGfOdvAjsELeJlP(u"ࠫࡨࡧ࡮ࡤࡧ࡯ࡩࡩ࠭ἷ"),tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠬࡴ࡯ࡵࡡࡵࡩࡸࡵ࡬ࡷࡣࡥࡰࡪ࠭Ἰ")] or phm0nfzAUCXHBjO7lIDSxT3eZJdc:
		tqC0PngwO4pA = WwMgozBIC32n9d0tyfp.executeJSONRPC(LyNiIHPOwD3hCUYEFM7(u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥ࡭ࡩࠨ࠺࠲࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡖ࡬ࡢࡻ࡯࡭ࡸࡺ࠮ࡄ࡮ࡨࡥࡷࠨࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡵࡲࡡࡺ࡮࡬ࡷࡹ࡯ࡤࠣ࠼࠴ࢁࢂ࠭Ἱ"))
	return
tZwKXhiQu9V2,jzVTwcGFi6v3CMuYyo9RAPr1,cwyepKNO6T7fadQ,aJqDzVrBG3WRbPmSg,R12nle7jSq8fUzMiuc4d,mbAwK8fZJgjLhMQSHGqEcpYsxW = [],[],[],[],[],[]
def clqJiEdkt0GzeHYvOBK34(WK130YrED8vNhiHntepuXR,ff2PjlcCF5ZWyIUbVguMz,source,showDialogs):
	global tZwKXhiQu9V2,jzVTwcGFi6v3CMuYyo9RAPr1,cwyepKNO6T7fadQ,aJqDzVrBG3WRbPmSg,R12nle7jSq8fUzMiuc4d,mbAwK8fZJgjLhMQSHGqEcpYsxW
	EA7FzO1kMZGQXDd2giB0cwLom,bp9xufdZSRHyltK8VAc5ihI7U,new = [],[],[]
	qI2s0ZN7uj(BF6QAiLUNHh7rKOugaw,BF6QAiLUNHh7rKOugaw,BF6QAiLUNHh7rKOugaw)
	count = len(ff2PjlcCF5ZWyIUbVguMz)
	for ba3If2JElOq0nNPWBkXC6dH in range(count):
		tZwKXhiQu9V2.append(None)
		jzVTwcGFi6v3CMuYyo9RAPr1.append(None)
		cwyepKNO6T7fadQ.append(None)
		aJqDzVrBG3WRbPmSg.append(None)
		R12nle7jSq8fUzMiuc4d.append(None)
		mbAwK8fZJgjLhMQSHGqEcpYsxW.append(FGTfwsjNrB8DvKSZhLIQAb1JnO)
		title = WK130YrED8vNhiHntepuXR[ba3If2JElOq0nNPWBkXC6dH]
		fCXyTlcmF4WuetVork = ff2PjlcCF5ZWyIUbVguMz[ba3If2JElOq0nNPWBkXC6dH].strip(iFBmE2MUIpSu34wsd7Rf6z).strip(UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠧࠧࠩἺ")).strip(TlGXWLYsV1z(u"ࠨࡁࠪἻ")).strip(uuExaKGL7UONtevRd(u"ࠩ࠲ࠫἼ"))
		if count>YYJQyRskpX8jv and showDialogs: YYkhEn5xTXLUevzCVNB16mR(tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠪๅา฻ࠠิ์ิๅึࠦัใ็ࠣࠤࠬἽ")+str(ba3If2JElOq0nNPWBkXC6dH+jXE2YHkswT8y(u"࠱ั")),title)
		saYvedRCKO = [AbqCJZdWQP9j(u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬἾ"),FRYcH4KL7e9gv5pEB(u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐࠪἿ"),tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"࠭ࡁࡌ࡙ࡄࡑࠬὀ")]
		if source in saYvedRCKO: tZwKXhiQu9V2[ba3If2JElOq0nNPWBkXC6dH] = IcrOQnU5sd(title,fCXyTlcmF4WuetVork,source,ba3If2JElOq0nNPWBkXC6dH)
		else:
			if EMO8gy4LrsNTh0knZwpSeU75APW(u"࠲า"):
				buHaW1hmOCfeTxiMoJnNFj40y = EEehSFDLdpKBR3W1ga9PxrV.Thread(target=IcrOQnU5sd,args=(title,fCXyTlcmF4WuetVork,source,ba3If2JElOq0nNPWBkXC6dH))
				buHaW1hmOCfeTxiMoJnNFj40y.start()
				bp9xufdZSRHyltK8VAc5ihI7U.append(buHaW1hmOCfeTxiMoJnNFj40y)
				new.append(ba3If2JElOq0nNPWBkXC6dH)
				X2cQ5NCPvkMieBW7oASspFjE.sleep(MgP8OjoaiWQEVG59(u"࠳ำ"))
	timeout = LyNiIHPOwD3hCUYEFM7(u"࠹࠴ิ") if source==L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠧࡂࡍ࡚ࡅࡒ࠭ὁ") else PtkEvXAqif14G20QZsaSyT(u"࠷࠵ี")
	QhNGvIF4YS2a5gxLAcy1k6VW3w = X2cQ5NCPvkMieBW7oASspFjE.time()
	for buHaW1hmOCfeTxiMoJnNFj40y in bp9xufdZSRHyltK8VAc5ihI7U: buHaW1hmOCfeTxiMoJnNFj40y.join(timeout)
	for ba3If2JElOq0nNPWBkXC6dH in range(count):
		title = WK130YrED8vNhiHntepuXR[ba3If2JElOq0nNPWBkXC6dH]
		fCXyTlcmF4WuetVork = ff2PjlcCF5ZWyIUbVguMz[ba3If2JElOq0nNPWBkXC6dH].strip(iFBmE2MUIpSu34wsd7Rf6z).strip(vODxLKW5Ql6r4Fbm8(u"ࠨࠨࠪὂ")).strip(XrTw01KtLzbpoyMf(u"ࠩࡂࠫὃ")).strip(TlGXWLYsV1z(u"ࠪ࠳ࠬὄ"))
		ijMthkoW7n = rGPen6cSMHQkAywh8vqI9JXiD2 if mbAwK8fZJgjLhMQSHGqEcpYsxW[ba3If2JElOq0nNPWBkXC6dH]+YYJQyRskpX8jv>timeout else BF6QAiLUNHh7rKOugaw
		if tZwKXhiQu9V2[ba3If2JElOq0nNPWBkXC6dH] and len(tZwKXhiQu9V2[ba3If2JElOq0nNPWBkXC6dH])==ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"࠸ึ") and (tZwKXhiQu9V2[ba3If2JElOq0nNPWBkXC6dH][FGTfwsjNrB8DvKSZhLIQAb1JnO] or tZwKXhiQu9V2[ba3If2JElOq0nNPWBkXC6dH][nI2JK1RfsGWNY3OarEeMQZ]): sHPiAac6dgOCYJoXbuhwDGlUFmS,Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb,hx0dU3Ki7AyEfkSZY6TmN2BwtX = tZwKXhiQu9V2[ba3If2JElOq0nNPWBkXC6dH]
		elif ijMthkoW7n: sHPiAac6dgOCYJoXbuhwDGlUFmS,Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb,hx0dU3Ki7AyEfkSZY6TmN2BwtX = ZchUJdM93pTA7zG5(u"ࠫࡋࡧࡩ࡭ࡧࡧ࠾ࠥࠦࡔࡪ࡯ࡨࡨࠥࡕࡵࡵࠢࠫࠫὅ")+str(timeout)+UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠬࠦࡳࡦࡥࡲࡲࡩࡹࠩࠨ὆"),[],[]
		else: sHPiAac6dgOCYJoXbuhwDGlUFmS,Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb,hx0dU3Ki7AyEfkSZY6TmN2BwtX = JZszNnIEMAx28Yao0yqhiXGKOPb(u"࠭ࡆࡢ࡫࡯ࡩࡩࡀࠠࠡࡅࡲࡹࡱࡪࠠ࡯ࡱࡷࠤ࡫࡯࡮ࡥࠢࡷ࡬ࡪࠦࡶࡪࡦࡨࡳࠥ࡬ࡩ࡭ࡧࠪ὇"),[],[]
		EA7FzO1kMZGQXDd2giB0cwLom.append([title,fCXyTlcmF4WuetVork,sHPiAac6dgOCYJoXbuhwDGlUFmS,Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb,hx0dU3Ki7AyEfkSZY6TmN2BwtX])
		if ba3If2JElOq0nNPWBkXC6dH in new:
			mbIOiTzgY5 = fCXyTlcmF4WuetVork.split(HtK4o2sTPgA78U(u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨὈ"),YYJQyRskpX8jv)[FGTfwsjNrB8DvKSZhLIQAb1JnO]
			if not sHPiAac6dgOCYJoXbuhwDGlUFmS: YMQXP2BGeK86CEb(PdkZHNBlpg2b7DmX6qRiyVa,LyNiIHPOwD3hCUYEFM7(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡆࡢࡗ࡚ࡉࡃࡆࡇࡇࡉࡉ࠭Ὁ"),mbIOiTzgY5,[sHPiAac6dgOCYJoXbuhwDGlUFmS,Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb,hx0dU3Ki7AyEfkSZY6TmN2BwtX],PNjZMS7nxa9clHusz1)
			else: YMQXP2BGeK86CEb(PdkZHNBlpg2b7DmX6qRiyVa,MgP8OjoaiWQEVG59(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡇࡣࡋࡇࡉࡍࡇࡇࠫὊ"),mbIOiTzgY5,[sHPiAac6dgOCYJoXbuhwDGlUFmS,Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb,hx0dU3Ki7AyEfkSZY6TmN2BwtX],PNjZMS7nxa9clHusz1)
	qI2s0ZN7uj(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U)
	return EA7FzO1kMZGQXDd2giB0cwLom
def IcrOQnU5sd(Zw4M5DUStdE6xp7GI,url,source,aqCScXK4Gg1Dkt5vHL38RJEBUZe):
	global tZwKXhiQu9V2,mbAwK8fZJgjLhMQSHGqEcpYsxW
	mbAwK8fZJgjLhMQSHGqEcpYsxW[aqCScXK4Gg1Dkt5vHL38RJEBUZe] = FGTfwsjNrB8DvKSZhLIQAb1JnO
	QhNGvIF4YS2a5gxLAcy1k6VW3w = X2cQ5NCPvkMieBW7oASspFjE.time()
	WKquk5EaNr4RzVf(P3sqIW4T8rYpjNxOXhcBk2GD,IIZ4e82HBP0oTmtOgaWY7hsMz(sQU2GnRoMwLK8CBdfzmNr4jXyO)+sVzojQerUqX(u"ࠪࠤࠥࠦࡒࡦࡵࡲࡰࡻ࡯࡮ࡨࠢࡶࡸࡦࡸࡴࡦࡦࠣࠤ࡙ࠥࡥ࡭ࡧࡦࡸࡪࡪ࠺ࠡ࡝ࠣࠫὋ")+Zw4M5DUStdE6xp7GI+YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠫࠥࡣࠠࠡࠢࡒࡶ࡮࡭ࡩ࡯ࡣ࡯࠾ࠥࡡࠠࠨὌ")+url+ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠬࠦ࡝ࠨὍ"))
	fCXyTlcmF4WuetVork,mOYVSgRxWbl194UXva60DTqCsLG7 = url,iiy37aKq0pCEIOwfcTh61xb4U
	dcWwXaBn0A = IpC4qHXRuyNFjzWv(u"࠭ࡉࡏࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࠪ὎")
	phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = SxZwT3eW4fslAEFoCup(url,source)
	if phm0nfzAUCXHBjO7lIDSxT3eZJdc==XrTw01KtLzbpoyMf(u"ࠧࡆ࡚ࡌࡘࡤࡇࡌࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ὏"):
		tZwKXhiQu9V2[aqCScXK4Gg1Dkt5vHL38RJEBUZe] = sVzojQerUqX(u"ࠨࡇ࡛ࡍ࡙ࡥࡁࡍࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ὐ"),[],[]
		mbAwK8fZJgjLhMQSHGqEcpYsxW[aqCScXK4Gg1Dkt5vHL38RJEBUZe] = X2cQ5NCPvkMieBW7oASspFjE.time()-QhNGvIF4YS2a5gxLAcy1k6VW3w
		return tZwKXhiQu9V2[aqCScXK4Gg1Dkt5vHL38RJEBUZe]
	elif GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬὑ") in phm0nfzAUCXHBjO7lIDSxT3eZJdc:
		mOYVSgRxWbl194UXva60DTqCsLG7 = sVzojQerUqX(u"ࠪࡠࡳࡘࡥࡴࡱ࡯ࡺࡪࡸࠠ࠲࠼ࠣࠤࡓ࡫ࡥࡥࠢࡈࡼࡹ࡫ࡲ࡯ࡣ࡯ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷ࠭ὒ")
		fCXyTlcmF4WuetVork = xn9QjVJdASLWz1a4fNrYRqgc2o(duef0gb3Mi1AV5WpN8)[FGTfwsjNrB8DvKSZhLIQAb1JnO]
		dcWwXaBn0A,mOYVSgRxWbl194UXva60DTqCsLG7,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = X3fWYLws8lITS0OKmF(mOYVSgRxWbl194UXva60DTqCsLG7,fCXyTlcmF4WuetVork,source,aqCScXK4Gg1Dkt5vHL38RJEBUZe)
		if mOYVSgRxWbl194UXva60DTqCsLG7==UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠫࡊ࡞ࡉࡕࡡࡄࡐࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩὓ"):
			mbAwK8fZJgjLhMQSHGqEcpYsxW[aqCScXK4Gg1Dkt5vHL38RJEBUZe] = X2cQ5NCPvkMieBW7oASspFjE.time()-QhNGvIF4YS2a5gxLAcy1k6VW3w
			return mOYVSgRxWbl194UXva60DTqCsLG7,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8
	elif phm0nfzAUCXHBjO7lIDSxT3eZJdc: mOYVSgRxWbl194UXva60DTqCsLG7 = UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠬࡘࡥࡴࡱ࡯ࡺࡪࡸࠠ࠲࠼ࠣࠤࠬὔ")+phm0nfzAUCXHBjO7lIDSxT3eZJdc.replace(OTlVEGYPSxsNaBdXUucqA3,iiy37aKq0pCEIOwfcTh61xb4U).replace(Mge0HhFk9Ic6sm5VR,iiy37aKq0pCEIOwfcTh61xb4U)[:ZchUJdM93pTA7zG5(u"࠾࠰ื")]
	if duef0gb3Mi1AV5WpN8:
		duef0gb3Mi1AV5WpN8 = xn9QjVJdASLWz1a4fNrYRqgc2o(duef0gb3Mi1AV5WpN8)
		WKquk5EaNr4RzVf(P3sqIW4T8rYpjNxOXhcBk2GD,IIZ4e82HBP0oTmtOgaWY7hsMz(sQU2GnRoMwLK8CBdfzmNr4jXyO)+EMO8gy4LrsNTh0knZwpSeU75APW(u"࠭ࠠࠡࠢࡕࡩࡸࡵ࡬ࡷ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡩࡩ࡫ࡤࠡࠢࠣࡗࡪࡲࡥࡤࡶࡨࡨ࠿࡛ࠦࠡࠩὕ")+Zw4M5DUStdE6xp7GI+vODxLKW5Ql6r4Fbm8(u"ࠧࠡ࡟ࠣࠤࠥࡘࡥࡴࡱ࡯ࡺࡪࡸ࠺ࠡ࡝ࠣࠫὖ")+dcWwXaBn0A+zmcGfOdvAjsELeJlP(u"ࠨࠢࡠࠤࠥࠦࡏࡳ࡫ࡪ࡭ࡳࡧ࡬࠻ࠢ࡞ࠤࠬὗ")+url+JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠩࠣࡡࠥࠦࠠࡍ࡫ࡱ࡯࠿࡛ࠦࠡࠩ὘")+fCXyTlcmF4WuetVork+hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠪࠤࡢࠦࠠࠡࠢࠣࠤ࡛࡯ࡤࡦࡱࡶ࠾ࠥࡡࠠࠨὙ")+str(duef0gb3Mi1AV5WpN8)+yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠫࠥࡣࠧ὚"))
	else: WKquk5EaNr4RzVf(P3sqIW4T8rYpjNxOXhcBk2GD,IIZ4e82HBP0oTmtOgaWY7hsMz(sQU2GnRoMwLK8CBdfzmNr4jXyO)+XrTw01KtLzbpoyMf(u"ࠬࠦࠠࠡࡔࡨࡷࡴࡲࡶࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧࠤࠥࠦࡓࡦ࡮ࡨࡧࡹ࡫ࡤ࠻ࠢ࡞ࠤࠬὛ")+Zw4M5DUStdE6xp7GI+YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"࠭ࠠ࡞ࠢࠣࠤࡔࡸࡩࡨ࡫ࡱࡥࡱࡀࠠ࡜ࠢࠪ὜")+url+SaB5hx3PZwXRLtKgrTfQvId(u"ࠧࠡ࡟ࠣࠤࠥࡒࡩ࡯࡭࠽ࠤࡠࠦࠧὝ")+fCXyTlcmF4WuetVork+FRYcH4KL7e9gv5pEB(u"ࠨࠢࡠࠤࠥࠦࡅࡳࡴࡲࡶࡸࡀࠠ࡜ࠢࠪ὞")+mOYVSgRxWbl194UXva60DTqCsLG7+ZchUJdM93pTA7zG5(u"ࠩࠣࡡࠬὟ"))
	mOYVSgRxWbl194UXva60DTqCsLG7 = a9I3YZjc6ySDPE4Kp(mOYVSgRxWbl194UXva60DTqCsLG7)
	tZwKXhiQu9V2[aqCScXK4Gg1Dkt5vHL38RJEBUZe] = mOYVSgRxWbl194UXva60DTqCsLG7,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8
	mbAwK8fZJgjLhMQSHGqEcpYsxW[aqCScXK4Gg1Dkt5vHL38RJEBUZe] = X2cQ5NCPvkMieBW7oASspFjE.time()-QhNGvIF4YS2a5gxLAcy1k6VW3w
	return mOYVSgRxWbl194UXva60DTqCsLG7,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8
def dbgzVjEGO01wXAuTPI8crCWam3S5B(title,fCXyTlcmF4WuetVork,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8,source,EGJVsZy38Xx=iiy37aKq0pCEIOwfcTh61xb4U):
	if duef0gb3Mi1AV5WpN8:
		if not A7Ap2wdlxM[UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"࠰ุ")]: A7Ap2wdlxM = duef0gb3Mi1AV5WpN8
		LsjrhQpZKcn41EyDwlFBm0IYtX = OXsckY7RzjCag9A.getSetting(ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡢࡪࡶࡵࡥࡹ࡫ࠧὠ"))
		RRZcwlH5nID49W6FJumjUPq7ipT = ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠫ࠲࠭ὡ") not in LsjrhQpZKcn41EyDwlFBm0IYtX
		while rGPen6cSMHQkAywh8vqI9JXiD2:
			if RRZcwlH5nID49W6FJumjUPq7ipT and len(duef0gb3Mi1AV5WpN8)==YYJQyRskpX8jv: mmfrx2S5XqknFTDeRhj49LuYv1wW0 = FGTfwsjNrB8DvKSZhLIQAb1JnO
			else: mmfrx2S5XqknFTDeRhj49LuYv1wW0 = ccv1mVPUsnr(TlGXWLYsV1z(u"ࠬอฮหำࠣห้๋ไโࠢส่๊์วิส࠽ࠫὢ"), A7Ap2wdlxM)
			if mmfrx2S5XqknFTDeRhj49LuYv1wW0==-YYJQyRskpX8jv: umOGqx65jCSBT1 = zmcGfOdvAjsELeJlP(u"࠭ࡣࡢࡰࡦࡩࡱ࡫ࡤࠨὣ")
			else:
				xLhg6bfDsPmNToqURdtA = duef0gb3Mi1AV5WpN8[mmfrx2S5XqknFTDeRhj49LuYv1wW0]
				WKquk5EaNr4RzVf(P3sqIW4T8rYpjNxOXhcBk2GD,IIZ4e82HBP0oTmtOgaWY7hsMz(sQU2GnRoMwLK8CBdfzmNr4jXyO)+PtkEvXAqif14G20QZsaSyT(u"ࠧࠡࠢࠣࡔࡱࡧࡹࡪࡰࡪࠤࡸࡺࡡࡳࡶࡨࡨࠥࠦࠠࡔࡧ࡯ࡩࡨࡺࡥࡥ࠼ࠣ࡟ࠥ࠭ὤ")+title+JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠨࠢࡠࠤࠥࠦࡏࡳ࡫ࡪ࡭ࡳࡧ࡬࠻ࠢ࡞ࠤࠬὥ")+fCXyTlcmF4WuetVork+sVzojQerUqX(u"ࠩࠣࡡࠥࠦࠠࡗ࡫ࡧࡩࡴࡀࠠ࡜ࠢࠪὦ")+str(xLhg6bfDsPmNToqURdtA)+UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠪࠤࡢ࠭ὧ"))
				if ZchUJdM93pTA7zG5(u"ࠫࡲࡵࡳࡩࡣ࡫ࡨࡦ࠴ࠧὨ") in xLhg6bfDsPmNToqURdtA and ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡟ࡰࡴ࡬࡫ࠬὩ") in xLhg6bfDsPmNToqURdtA:
					sHPiAac6dgOCYJoXbuhwDGlUFmS,hTokmyvgtKG,j6P7d92fziHV3s = R4xVvt2TlcrnYW8(xLhg6bfDsPmNToqURdtA)
					if j6P7d92fziHV3s: xLhg6bfDsPmNToqURdtA = j6P7d92fziHV3s[FGTfwsjNrB8DvKSZhLIQAb1JnO]
					else: xLhg6bfDsPmNToqURdtA = iiy37aKq0pCEIOwfcTh61xb4U
				if not xLhg6bfDsPmNToqURdtA: umOGqx65jCSBT1 = uuExaKGL7UONtevRd(u"࠭ࡵ࡯ࡴࡨࡷࡴࡲࡶࡦࡦࠪὪ")
				else: umOGqx65jCSBT1 = PsD3IgluKFyvzMLoRT9j5hq2(xLhg6bfDsPmNToqURdtA,source,EGJVsZy38Xx)
			if umOGqx65jCSBT1 in [CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠧࡱ࡮ࡤࡽ࡮ࡴࡧࠨὫ"),FRYcH4KL7e9gv5pEB(u"ࠨࡶࡨࡷࡹ࡯࡮ࡨࠩὬ"),tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧ࡭ࡳ࡭ࠧὭ"),AbqCJZdWQP9j(u"ࠪࡧࡦࡴࡣࡦ࡮ࡨࡨࠬὮ")] or len(duef0gb3Mi1AV5WpN8)==YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"࠲ู"): break
			elif umOGqx65jCSBT1 in [PtkEvXAqif14G20QZsaSyT(u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫὯ"),CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠬࡺࡩ࡮ࡧࡲࡹࡹ࠭ὰ"),ZchUJdM93pTA7zG5(u"࠭ࡴࡳ࡫ࡨࡨࠬά")]: break
			else: bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,uuExaKGL7UONtevRd(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪὲ"),ZchUJdM93pTA7zG5(u"ࠨษ็้้็ࠠๅ็ࠣ๎฾๋ไࠡฮิฬ๋ࠥไโࠢ฽๎ึํࠧέ"))
	else:
		umOGqx65jCSBT1 = Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠩࡸࡲࡷ࡫ࡳࡰ࡮ࡹࡩࡩ࠭ὴ")
		if dVeG46wAnrtlpkbNPsvJ9(fCXyTlcmF4WuetVork): umOGqx65jCSBT1 = PsD3IgluKFyvzMLoRT9j5hq2(fCXyTlcmF4WuetVork,source,EGJVsZy38Xx)
	return umOGqx65jCSBT1,duef0gb3Mi1AV5WpN8
def f8kXlgjdbBWi2ZNtVHaycxeED1TP(url,source):
	eCGwzSrqBmIv,qq8UKjLDTbHYtaw1WXBmVQ4sGpO0Fu,Zw4M5DUStdE6xp7GI,v1gZtmsfVMqlDzSrPIH7Tn4Rd9AJ,JJwnocyLUxHI2jlKF4Y,EGJVsZy38Xx,d2xq6KCoULIiPWOyFwp0t,pMAWqrwP80lR,aOtvl3xUCgoDIQN0HEVGYf = url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U
	if CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫή") in url:
		eCGwzSrqBmIv,qq8UKjLDTbHYtaw1WXBmVQ4sGpO0Fu = url.split(MgP8OjoaiWQEVG59(u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬὶ"),YYJQyRskpX8jv)
		qq8UKjLDTbHYtaw1WXBmVQ4sGpO0Fu = qq8UKjLDTbHYtaw1WXBmVQ4sGpO0Fu+uuExaKGL7UONtevRd(u"ࠬࡥ࡟ࠨί")+L90uqo28xEKSFUwYTcm51yRWZIkft(u"࠭࡟ࡠࠩὸ")+tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠧࡠࡡࠪό")+HtK4o2sTPgA78U(u"ࠨࡡࡢࠫὺ")+sVzojQerUqX(u"ࠩࡢࡣࠬύ")
		JJwnocyLUxHI2jlKF4Y,EGJVsZy38Xx,d2xq6KCoULIiPWOyFwp0t,pMAWqrwP80lR,aOtvl3xUCgoDIQN0HEVGYf,AWhpYHuQqgEKx, = qq8UKjLDTbHYtaw1WXBmVQ4sGpO0Fu.split(YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠪࡣࡤ࠭ὼ"))[:sVzojQerUqX(u"࠸ฺ")]
	if not pMAWqrwP80lR: pMAWqrwP80lR = FRYcH4KL7e9gv5pEB(u"ࠫ࠵࠭ώ")
	else: pMAWqrwP80lR = pMAWqrwP80lR.replace(XrTw01KtLzbpoyMf(u"ࠬࡶࠧ὾"),iiy37aKq0pCEIOwfcTh61xb4U).replace(iFBmE2MUIpSu34wsd7Rf6z,iiy37aKq0pCEIOwfcTh61xb4U)
	eCGwzSrqBmIv = eCGwzSrqBmIv.strip(CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"࠭࠿ࠨ὿")).strip(HtK4o2sTPgA78U(u"ࠧ࠰ࠩᾀ")).strip(FRYcH4KL7e9gv5pEB(u"ࠨࠨࠪᾁ"))
	Zw4M5DUStdE6xp7GI = F82MvyX4ThI6sbnA3efDoVS(eCGwzSrqBmIv,tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠩ࡫ࡳࡸࡺࠧᾂ"))
	if JJwnocyLUxHI2jlKF4Y: v1gZtmsfVMqlDzSrPIH7Tn4Rd9AJ = JJwnocyLUxHI2jlKF4Y
	else: v1gZtmsfVMqlDzSrPIH7Tn4Rd9AJ = Zw4M5DUStdE6xp7GI
	v1gZtmsfVMqlDzSrPIH7Tn4Rd9AJ = F82MvyX4ThI6sbnA3efDoVS(v1gZtmsfVMqlDzSrPIH7Tn4Rd9AJ,ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠪࡲࡦࡳࡥࠨᾃ"))
	JJwnocyLUxHI2jlKF4Y = JJwnocyLUxHI2jlKF4Y.replace(ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"๊ࠫฮวีำࠪᾄ"),iiy37aKq0pCEIOwfcTh61xb4U).replace(MgP8OjoaiWQEVG59(u"ู๊ࠬาใิࠫᾅ"),iiy37aKq0pCEIOwfcTh61xb4U).replace(hhQwbeiNLoqFjX90fB7aG8VAs(u"࠭วๅࠢࠪᾆ"),iFBmE2MUIpSu34wsd7Rf6z).replace(Wc5GekRC0HQLz7,iFBmE2MUIpSu34wsd7Rf6z)
	qq8UKjLDTbHYtaw1WXBmVQ4sGpO0Fu = qq8UKjLDTbHYtaw1WXBmVQ4sGpO0Fu.replace(ZchUJdM93pTA7zG5(u"ࠧๆสสุึ࠭ᾇ"),iiy37aKq0pCEIOwfcTh61xb4U).replace(tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠨีํีๆืࠧᾈ"),iiy37aKq0pCEIOwfcTh61xb4U).replace(UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠩส่ࠥ࠭ᾉ"),iFBmE2MUIpSu34wsd7Rf6z).replace(Wc5GekRC0HQLz7,iFBmE2MUIpSu34wsd7Rf6z)
	v1gZtmsfVMqlDzSrPIH7Tn4Rd9AJ = v1gZtmsfVMqlDzSrPIH7Tn4Rd9AJ.replace(sVzojQerUqX(u"้ࠪออิาࠩᾊ"),iiy37aKq0pCEIOwfcTh61xb4U).replace(yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ุࠫ๐ัโำࠪᾋ"),iiy37aKq0pCEIOwfcTh61xb4U).replace(ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠬอไࠡࠩᾌ"),iFBmE2MUIpSu34wsd7Rf6z).replace(Wc5GekRC0HQLz7,iFBmE2MUIpSu34wsd7Rf6z)
	return eCGwzSrqBmIv,qq8UKjLDTbHYtaw1WXBmVQ4sGpO0Fu,Zw4M5DUStdE6xp7GI,v1gZtmsfVMqlDzSrPIH7Tn4Rd9AJ,JJwnocyLUxHI2jlKF4Y,EGJVsZy38Xx,d2xq6KCoULIiPWOyFwp0t,pMAWqrwP80lR,aOtvl3xUCgoDIQN0HEVGYf
def idykRD0Z6AFpX7YszJg2El(url,source):
	ffbAi4C8snmpa1dHqD7olykV3,JJwnocyLUxHI2jlKF4Y,h5aq3QTUSLDnB4lXMt1I,ffkrLiTDc0jVegJ,XBn154hLcTrwRMKp8OxVAyt,Tah1vG47QFrxd,dcWwXaBn0A = iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,None,None,None,None,None
	eCGwzSrqBmIv,qq8UKjLDTbHYtaw1WXBmVQ4sGpO0Fu,Zw4M5DUStdE6xp7GI,v1gZtmsfVMqlDzSrPIH7Tn4Rd9AJ,JJwnocyLUxHI2jlKF4Y,EGJVsZy38Xx,d2xq6KCoULIiPWOyFwp0t,pMAWqrwP80lR,aOtvl3xUCgoDIQN0HEVGYf = f8kXlgjdbBWi2ZNtVHaycxeED1TP(url,source)
	if MgP8OjoaiWQEVG59(u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧᾍ") in url:
		if   EGJVsZy38Xx==EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠧࡦ࡯ࡥࡩࡩ࠭ᾎ"): EGJVsZy38Xx = iFBmE2MUIpSu34wsd7Rf6z+MgP8OjoaiWQEVG59(u"ࠨ็ไฺ้࠭ᾏ")
		elif EGJVsZy38Xx==TlGXWLYsV1z(u"ࠩࡺࡥࡹࡩࡨࠨᾐ"): EGJVsZy38Xx = iFBmE2MUIpSu34wsd7Rf6z+yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ฺ๊ࠪࠩว่ัฬࠫᾑ")
		elif EGJVsZy38Xx==tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠫࡧࡵࡴࡩࠩᾒ"): EGJVsZy38Xx = iFBmE2MUIpSu34wsd7Rf6z+MgP8OjoaiWQEVG59(u"ࠬࠫࠥๆึส๋ิฯ้ࠠฬะ้๏๊ࠧᾓ")
		elif EGJVsZy38Xx==L90uqo28xEKSFUwYTcm51yRWZIkft(u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤࠨᾔ"): EGJVsZy38Xx = iFBmE2MUIpSu34wsd7Rf6z+LyNiIHPOwD3hCUYEFM7(u"ࠧࠦࠧࠨฮา๋๊ๅࠩᾕ")
		elif EGJVsZy38Xx==iiy37aKq0pCEIOwfcTh61xb4U: EGJVsZy38Xx = iFBmE2MUIpSu34wsd7Rf6z+FRYcH4KL7e9gv5pEB(u"ࠨࠧࠨࠩࠪ࠭ᾖ")
		if d2xq6KCoULIiPWOyFwp0t!=iiy37aKq0pCEIOwfcTh61xb4U:
			if UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠩࡰࡴ࠹࠭ᾗ") not in d2xq6KCoULIiPWOyFwp0t: d2xq6KCoULIiPWOyFwp0t = tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠪࠩࠬᾘ")+d2xq6KCoULIiPWOyFwp0t
			d2xq6KCoULIiPWOyFwp0t = iFBmE2MUIpSu34wsd7Rf6z+d2xq6KCoULIiPWOyFwp0t
		if pMAWqrwP80lR!=iiy37aKq0pCEIOwfcTh61xb4U:
			pMAWqrwP80lR = yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠫࠪࠫࠥࠦࠧࠨࠩࠪࠫࠧᾙ")+pMAWqrwP80lR
			pMAWqrwP80lR = iFBmE2MUIpSu34wsd7Rf6z+pMAWqrwP80lR[-jXE2YHkswT8y(u"࠼฻"):]
	if   zmcGfOdvAjsELeJlP(u"ࠬࡇࡋࡐࡃࡐࠫᾚ")		in source: Tah1vG47QFrxd	= v1gZtmsfVMqlDzSrPIH7Tn4Rd9AJ
	elif JZszNnIEMAx28Yao0yqhiXGKOPb(u"࠭ࡁࡌ࡙ࡄࡑࠬᾛ")		in source: h5aq3QTUSLDnB4lXMt1I	= uuExaKGL7UONtevRd(u"ࠧࡢ࡭ࡺࡥࡲ࠭ᾜ")
	elif PtkEvXAqif14G20QZsaSyT(u"ࠨ࡭ࡤࡸࡰࡵࡵࡵࡧࠪᾝ")		in Zw4M5DUStdE6xp7GI: h5aq3QTUSLDnB4lXMt1I	= v1gZtmsfVMqlDzSrPIH7Tn4Rd9AJ
	elif FRYcH4KL7e9gv5pEB(u"ࠩࡳ࡬ࡴࡺ࡯ࡴ࠰ࡤࡴࡵ࠴ࡧࠨᾞ")	in Zw4M5DUStdE6xp7GI: h5aq3QTUSLDnB4lXMt1I	= v1gZtmsfVMqlDzSrPIH7Tn4Rd9AJ
	elif jXE2YHkswT8y(u"ࠪࡥࡷࡧࡢࡴࡧࡨࡨࠬᾟ")		in source: h5aq3QTUSLDnB4lXMt1I	= v1gZtmsfVMqlDzSrPIH7Tn4Rd9AJ
	elif CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠫࡦࡲࡡࡳࡣࡥࠫᾠ")		in Zw4M5DUStdE6xp7GI: h5aq3QTUSLDnB4lXMt1I	= v1gZtmsfVMqlDzSrPIH7Tn4Rd9AJ
	elif L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠬ࡬ࡡࡴࡧ࡯ࠫᾡ")		in Zw4M5DUStdE6xp7GI: h5aq3QTUSLDnB4lXMt1I	= v1gZtmsfVMqlDzSrPIH7Tn4Rd9AJ
	elif EMO8gy4LrsNTh0knZwpSeU75APW(u"࠭ࡴ࠸࡯ࡨࡩࡱ࠭ᾢ")		in Zw4M5DUStdE6xp7GI: h5aq3QTUSLDnB4lXMt1I	= v1gZtmsfVMqlDzSrPIH7Tn4Rd9AJ
	elif SaB5hx3PZwXRLtKgrTfQvId(u"ࠧ࡮ࡱࡹࡷ࠹ࡻࠧᾣ")		in JJwnocyLUxHI2jlKF4Y:   h5aq3QTUSLDnB4lXMt1I	= v1gZtmsfVMqlDzSrPIH7Tn4Rd9AJ
	elif sVzojQerUqX(u"ࠨ࡯ࡼࡩ࡬ࡿࡶࡪࡲࠪᾤ")		in JJwnocyLUxHI2jlKF4Y:   h5aq3QTUSLDnB4lXMt1I	= v1gZtmsfVMqlDzSrPIH7Tn4Rd9AJ
	elif L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠩࡩࡥ࡯࡫ࡲࠨᾥ")		in JJwnocyLUxHI2jlKF4Y:   h5aq3QTUSLDnB4lXMt1I	= v1gZtmsfVMqlDzSrPIH7Tn4Rd9AJ
	elif jXE2YHkswT8y(u"ࠪๅัืࠧᾦ")			in JJwnocyLUxHI2jlKF4Y:   h5aq3QTUSLDnB4lXMt1I	= tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠫ࡫ࡧࡪࡦࡴࠪᾧ")
	elif ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠬ็ไิูํ๊ࠬᾨ")		in JJwnocyLUxHI2jlKF4Y:   h5aq3QTUSLDnB4lXMt1I	= ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"࠭ࡰࡢ࡮ࡨࡷࡹ࡯࡮ࡦࠩᾩ")
	elif EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠧࡨࡦࡵ࡭ࡻ࡫ࠧᾪ")		in eCGwzSrqBmIv:   h5aq3QTUSLDnB4lXMt1I	= y6y5HtgXO4TkUbwVZ(u"ࠨࡩࡲࡳ࡬ࡲࡥࠨᾫ")
	elif L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠩࡰࡽࡨ࡯࡭ࡢࠩᾬ")		in JJwnocyLUxHI2jlKF4Y:   h5aq3QTUSLDnB4lXMt1I	= v1gZtmsfVMqlDzSrPIH7Tn4Rd9AJ
	elif xpT28sXu051(u"ࠪࡻࡪࡩࡩ࡮ࡣࠪᾭ")		in JJwnocyLUxHI2jlKF4Y:   h5aq3QTUSLDnB4lXMt1I	= v1gZtmsfVMqlDzSrPIH7Tn4Rd9AJ
	elif vODxLKW5Ql6r4Fbm8(u"ࠫࡨ࡯࡭ࡢࡰࡲࡻࠬᾮ")		in JJwnocyLUxHI2jlKF4Y:   h5aq3QTUSLDnB4lXMt1I	= v1gZtmsfVMqlDzSrPIH7Tn4Rd9AJ
	elif AbqCJZdWQP9j(u"ࠬࡴࡥࡸࡥ࡬ࡱࡦ࠭ᾯ")		in JJwnocyLUxHI2jlKF4Y:   h5aq3QTUSLDnB4lXMt1I	= v1gZtmsfVMqlDzSrPIH7Tn4Rd9AJ
	elif vODxLKW5Ql6r4Fbm8(u"࠭ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱࠫᾰ")	in Zw4M5DUStdE6xp7GI: h5aq3QTUSLDnB4lXMt1I	= v1gZtmsfVMqlDzSrPIH7Tn4Rd9AJ
	elif JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠧࡣࡱ࡮ࡶࡦ࠭ᾱ")		in Zw4M5DUStdE6xp7GI: h5aq3QTUSLDnB4lXMt1I	= v1gZtmsfVMqlDzSrPIH7Tn4Rd9AJ
	elif xpT28sXu051(u"ࠨࡶࡹࡪࡺࡴࠧᾲ")		in Zw4M5DUStdE6xp7GI: h5aq3QTUSLDnB4lXMt1I	= v1gZtmsfVMqlDzSrPIH7Tn4Rd9AJ
	elif ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠩࡷࡺࡰࡹࡡࠨᾳ")		in Zw4M5DUStdE6xp7GI: h5aq3QTUSLDnB4lXMt1I	= v1gZtmsfVMqlDzSrPIH7Tn4Rd9AJ
	elif ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠪࡥࡳࡧࡶࡪࡦࡽࠫᾴ")		in Zw4M5DUStdE6xp7GI: h5aq3QTUSLDnB4lXMt1I	= v1gZtmsfVMqlDzSrPIH7Tn4Rd9AJ
	elif EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠫࡸ࡮࡯ࡰࡨࡳࡶࡴ࠭᾵")		in Zw4M5DUStdE6xp7GI: h5aq3QTUSLDnB4lXMt1I	= v1gZtmsfVMqlDzSrPIH7Tn4Rd9AJ
	elif UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠬࡹࡨࡢࡪ࡬ࡨ࠹ࡻࠧᾶ")		in Zw4M5DUStdE6xp7GI: Tah1vG47QFrxd	= v1gZtmsfVMqlDzSrPIH7Tn4Rd9AJ
	elif SaB5hx3PZwXRLtKgrTfQvId(u"࠭ࡳࡩࡣ࡫ࡩࡩ࠺ࡵࠨᾷ")		in Zw4M5DUStdE6xp7GI: Tah1vG47QFrxd	= v1gZtmsfVMqlDzSrPIH7Tn4Rd9AJ
	elif LyNiIHPOwD3hCUYEFM7(u"ࠧࡤ࡫ࡰࡥ࠹ࡻࠧᾸ")		in Zw4M5DUStdE6xp7GI: Tah1vG47QFrxd	= v1gZtmsfVMqlDzSrPIH7Tn4Rd9AJ
	elif EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠨࡧࡪࡽࡳࡵࡷࠨᾹ")		in Zw4M5DUStdE6xp7GI: Tah1vG47QFrxd	= v1gZtmsfVMqlDzSrPIH7Tn4Rd9AJ
	elif SaB5hx3PZwXRLtKgrTfQvId(u"ࠩ࡫ࡥࡱࡧࡣࡪ࡯ࡤࠫᾺ")		in Zw4M5DUStdE6xp7GI: Tah1vG47QFrxd	= v1gZtmsfVMqlDzSrPIH7Tn4Rd9AJ
	elif jXE2YHkswT8y(u"ࠪࡧ࡮ࡳࡡࡢࡤࡧࡳࠬΆ")		in Zw4M5DUStdE6xp7GI: Tah1vG47QFrxd	= v1gZtmsfVMqlDzSrPIH7Tn4Rd9AJ
	elif FRYcH4KL7e9gv5pEB(u"ࠫࡷ࡫ࡤ࡮ࡱࡧࡼࠬᾼ")	 	in Zw4M5DUStdE6xp7GI: h5aq3QTUSLDnB4lXMt1I	= tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠬࡸࡥࡥ࡯ࡲࡨࡽ࠭᾽")
	elif hhQwbeiNLoqFjX90fB7aG8VAs(u"࠭ࡹࡰࡷࡷࡹࠬι")	 	in Zw4M5DUStdE6xp7GI: h5aq3QTUSLDnB4lXMt1I	= xpT28sXu051(u"ࠧࡺࡱࡸࡸࡺࡨࡥࠨ᾿")
	elif y6y5HtgXO4TkUbwVZ(u"ࠨࡻ࠵ࡹ࠳ࡨࡥࠨ῀")	 	in Zw4M5DUStdE6xp7GI: h5aq3QTUSLDnB4lXMt1I	= yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠩࡼࡳࡺࡺࡵࡣࡧࠪ῁")
	elif tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠪࡩ࡬ࡿ࠭ࡣࡧࡶࡸ࠳ࡴࡥࡵࠩῂ")	in Zw4M5DUStdE6xp7GI: h5aq3QTUSLDnB4lXMt1I	= v1gZtmsfVMqlDzSrPIH7Tn4Rd9AJ
	elif ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠫࡩ࠴ࡥࡨࡻࡥࡩࡸࡺ࠮ࡥࠩῃ")	in Zw4M5DUStdE6xp7GI: h5aq3QTUSLDnB4lXMt1I	= xpT28sXu051(u"ࠬ࡫ࡧࡺࡤࡨࡷࡹࡼࡩࡱࠩῄ")
	elif vODxLKW5Ql6r4Fbm8(u"࠭ࡥࡨࡻ࠱ࡦࡪࡹࡴࠨ῅")		in Zw4M5DUStdE6xp7GI: h5aq3QTUSLDnB4lXMt1I	= UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠧࡦࡩࡼࡦࡪࡹࡴ࠲ࠩῆ")
	elif tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠨࡧࡪࡽࡧ࡫ࡳࡵࠩῇ")		in Zw4M5DUStdE6xp7GI: h5aq3QTUSLDnB4lXMt1I	= y6y5HtgXO4TkUbwVZ(u"ࠩࡨ࡫ࡾࡨࡥࡴࡶ࠶ࠫῈ")
	elif FRYcH4KL7e9gv5pEB(u"ࠪࡱࡴࡹࡨࡢࡪࡧࡥࠬΈ")		in Zw4M5DUStdE6xp7GI: h5aq3QTUSLDnB4lXMt1I	= vODxLKW5Ql6r4Fbm8(u"ࠫࡲࡵࡳࡩࡣ࡫ࡨࡦ࠭Ὴ")
	elif yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠬ࡬ࡡࡤࡷ࡯ࡸࡾࡨ࡯ࡰ࡭ࡶࠫΉ")	in Zw4M5DUStdE6xp7GI: h5aq3QTUSLDnB4lXMt1I	= PtkEvXAqif14G20QZsaSyT(u"࠭ࡦࡢࡥࡸࡰࡹࡿࡢࡰࡱ࡮ࡷࠬῌ")
	elif SaB5hx3PZwXRLtKgrTfQvId(u"ࠧࡪࡰࡩࡰࡦࡳ࠮ࡤࡥࠪ῍")	in Zw4M5DUStdE6xp7GI: h5aq3QTUSLDnB4lXMt1I	= ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠨ࡫ࡱࡪࡱࡧ࡭ࠨ῎")
	elif hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠩࡥࡹࡿࢀࡶࡳ࡮ࠪ῏")		in Zw4M5DUStdE6xp7GI: h5aq3QTUSLDnB4lXMt1I	= HtK4o2sTPgA78U(u"ࠪࡦࡺࢀࡺࡷࡴ࡯ࠫῐ")
	elif vODxLKW5Ql6r4Fbm8(u"ࠫࡦࡸࡡࡣ࡮ࡲࡥࡩࡹࠧῑ")	in Zw4M5DUStdE6xp7GI: ffkrLiTDc0jVegJ	= xpT28sXu051(u"ࠬࡧࡲࡢࡤ࡯ࡳࡦࡪࡳࠨῒ")
	elif ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"࠭ࡡࡳࡥ࡫࡭ࡻ࡫ࠧΐ")		in Zw4M5DUStdE6xp7GI: ffkrLiTDc0jVegJ	= AbqCJZdWQP9j(u"ࠧࡢࡴࡦ࡬࡮ࡼࡥࠨ῔")
	elif LyNiIHPOwD3hCUYEFM7(u"ࠨࡥࡤࡸࡨ࡮࠮ࡪࡵࠪ῕")	 	in Zw4M5DUStdE6xp7GI: ffkrLiTDc0jVegJ	= uuExaKGL7UONtevRd(u"ࠩࡦࡥࡹࡩࡨࠨῖ")
	elif XrTw01KtLzbpoyMf(u"ࠪࡪ࡮ࡲࡥࡳ࡫ࡲࠫῗ")		in Zw4M5DUStdE6xp7GI: ffkrLiTDc0jVegJ	= xpT28sXu051(u"ࠫ࡫࡯࡬ࡦࡴ࡬ࡳࠬῘ")
	elif ZchUJdM93pTA7zG5(u"ࠬࡼࡩࡥࡤࡰࠫῙ")		in Zw4M5DUStdE6xp7GI: ffkrLiTDc0jVegJ	= zmcGfOdvAjsELeJlP(u"࠭ࡶࡪࡦࡥࡱࠬῚ")
	elif zmcGfOdvAjsELeJlP(u"ࠧࡷ࡫ࡧ࡬ࡩ࠭Ί")		in Zw4M5DUStdE6xp7GI: Tah1vG47QFrxd	= v1gZtmsfVMqlDzSrPIH7Tn4Rd9AJ
	elif L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠨ࡯ࡼࡺ࡮ࡪࠧ῜")		in Zw4M5DUStdE6xp7GI: Tah1vG47QFrxd	= v1gZtmsfVMqlDzSrPIH7Tn4Rd9AJ
	elif ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠩࡰࡽࡻ࡯ࡩࡥࠩ῝")		in Zw4M5DUStdE6xp7GI: Tah1vG47QFrxd	= v1gZtmsfVMqlDzSrPIH7Tn4Rd9AJ
	elif Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠪࡺ࡮ࡪࡥࡰࡤ࡬ࡲࠬ῞")		in Zw4M5DUStdE6xp7GI: ffkrLiTDc0jVegJ	= hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠫࡻ࡯ࡤࡦࡱࡥ࡭ࡳ࠭῟")
	elif yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠬ࡭࡯ࡷ࡫ࡧࠫῠ")		in Zw4M5DUStdE6xp7GI: ffkrLiTDc0jVegJ	= PtkEvXAqif14G20QZsaSyT(u"࠭ࡧࡰࡸ࡬ࡨࠬῡ")
	elif zmcGfOdvAjsELeJlP(u"ࠧ࡭࡫࡬ࡺ࡮ࡪࡥࡰࠩῢ") 	in Zw4M5DUStdE6xp7GI: ffkrLiTDc0jVegJ	= ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠨ࡮࡬࡭ࡻ࡯ࡤࡦࡱࠪΰ")
	elif sVzojQerUqX(u"ࠩࡰࡴ࠹ࡻࡰ࡭ࡱࡤࡨࠬῤ")	in Zw4M5DUStdE6xp7GI: ffkrLiTDc0jVegJ	= FRYcH4KL7e9gv5pEB(u"ࠪࡱࡵ࠺ࡵࡱ࡮ࡲࡥࡩ࠭ῥ")
	elif uuExaKGL7UONtevRd(u"ࠫࡵࡻࡢ࡭࡫ࡦࡺ࡮ࡪࡥࡰࠩῦ")	in Zw4M5DUStdE6xp7GI: ffkrLiTDc0jVegJ	= GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠬࡶࡵࡣ࡮࡬ࡧࡻ࡯ࡤࡦࡱࠪῧ")
	elif HtK4o2sTPgA78U(u"࠭ࡲࡢࡲ࡬ࡨࡻ࡯ࡤࡦࡱࠪῨ") 	in Zw4M5DUStdE6xp7GI: ffkrLiTDc0jVegJ	= Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠧࡳࡣࡳ࡭ࡩࡼࡩࡥࡧࡲࠫῩ")
	elif uuExaKGL7UONtevRd(u"ࠨࡶࡲࡴ࠹ࡺ࡯ࡱࠩῪ")		in Zw4M5DUStdE6xp7GI: ffkrLiTDc0jVegJ	= PtkEvXAqif14G20QZsaSyT(u"ࠩࡷࡳࡵ࠺ࡴࡰࡲࠪΎ")
	elif uuExaKGL7UONtevRd(u"ࠪࡹࡵࡶࠧῬ") 			in Zw4M5DUStdE6xp7GI: ffkrLiTDc0jVegJ	= SaB5hx3PZwXRLtKgrTfQvId(u"ࠫࡺࡶࡢࡰ࡯ࠪ῭")
	elif MgP8OjoaiWQEVG59(u"ࠬࡻࡰࡣࠩ΅") 			in Zw4M5DUStdE6xp7GI: ffkrLiTDc0jVegJ	= L90uqo28xEKSFUwYTcm51yRWZIkft(u"࠭ࡵࡱࡤࡲࡱࠬ`")
	elif AbqCJZdWQP9j(u"ࠧࡶࡳ࡯ࡳࡦࡪࠧ῰") 		in Zw4M5DUStdE6xp7GI: ffkrLiTDc0jVegJ	= vODxLKW5Ql6r4Fbm8(u"ࠨࡷࡴࡰࡴࡧࡤࠨ῱")
	elif hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠩࡹ࡯ࠬῲ") 			in Zw4M5DUStdE6xp7GI: ffkrLiTDc0jVegJ	= YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠪࡺࡰ࠭ῳ")
	elif LyNiIHPOwD3hCUYEFM7(u"ࠫࡻࡩࡳࡵࡴࡨࡥࡲ࠭ῴ") 	in Zw4M5DUStdE6xp7GI: ffkrLiTDc0jVegJ	= AbqCJZdWQP9j(u"ࠬࡼࡣࡴࡶࡵࡩࡦࡳࠧ῵")
	elif LyNiIHPOwD3hCUYEFM7(u"࠭ࡶࡪࡦࡥࡳࡧ࠭ῶ")		in Zw4M5DUStdE6xp7GI: ffkrLiTDc0jVegJ	= AbqCJZdWQP9j(u"ࠧࡷ࡫ࡧࡦࡴࡨࠧῷ")
	elif ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠨࡸ࡬ࡨࡴࢀࡡࠨῸ") 		in Zw4M5DUStdE6xp7GI: ffkrLiTDc0jVegJ	= UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠩࡹ࡭ࡩࡵࡺࡢࠩΌ")
	elif vODxLKW5Ql6r4Fbm8(u"ࠪࡻࡦࡺࡣࡩࡸ࡬ࡨࡪࡵࠧῺ") 	in Zw4M5DUStdE6xp7GI: ffkrLiTDc0jVegJ	= ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠫࡼࡧࡴࡤࡪࡹ࡭ࡩ࡫࡯ࠨΏ")
	elif yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠬࡽࡩ࡯ࡶࡹ࠲ࡱ࡯ࡶࡦࠩῼ")	in Zw4M5DUStdE6xp7GI: ffkrLiTDc0jVegJ	= xpT28sXu051(u"࠭ࡷࡪࡰࡷࡺ࠳ࡲࡩࡷࡧࠪ´")
	elif ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠧࡻ࡫ࡳࡴࡾࡹࡨࡢࡴࡨࠫ῾")	in Zw4M5DUStdE6xp7GI: ffkrLiTDc0jVegJ	= IpC4qHXRuyNFjzWv(u"ࠨࡼ࡬ࡴࡵࡿࡳࡩࡣࡵࡩࠬ῿")
	elif y6y5HtgXO4TkUbwVZ(u"ࠫ࡭ࡪ࠭ࡤࡦࡱࠫࠀ")		in Zw4M5DUStdE6xp7GI: ffkrLiTDc0jVegJ	= LyNiIHPOwD3hCUYEFM7(u"ࠬ࡮ࡤ࠮ࡥࡧࡲࠬࠁ")
	if   h5aq3QTUSLDnB4lXMt1I:	ffbAi4C8snmpa1dHqD7olykV3,JJwnocyLUxHI2jlKF4Y = y6y5HtgXO4TkUbwVZ(u"࠭ฮศืࠪࠂ"),h5aq3QTUSLDnB4lXMt1I
	elif Tah1vG47QFrxd:		ffbAi4C8snmpa1dHqD7olykV3,JJwnocyLUxHI2jlKF4Y = y6y5HtgXO4TkUbwVZ(u"ࠧࠦ็ะำิ࠭ࠃ"),Tah1vG47QFrxd
	elif ffkrLiTDc0jVegJ:		ffbAi4C8snmpa1dHqD7olykV3,JJwnocyLUxHI2jlKF4Y = zmcGfOdvAjsELeJlP(u"ࠨࠧࠨ฽ฬ๋ࠠๆ฻ิ์ๆ࠭ࠄ"),ffkrLiTDc0jVegJ
	elif XBn154hLcTrwRMKp8OxVAyt:	ffbAi4C8snmpa1dHqD7olykV3,JJwnocyLUxHI2jlKF4Y = PtkEvXAqif14G20QZsaSyT(u"ࠩࠨࠩࠪ฿วๆࠢัหึา๊ࠨࠅ"),XBn154hLcTrwRMKp8OxVAyt
	elif dcWwXaBn0A:	ffbAi4C8snmpa1dHqD7olykV3,JJwnocyLUxHI2jlKF4Y = ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ฺࠪࠩࠪࠫࠥษ่ࠤำอัอ์ࠪࠆ"),v1gZtmsfVMqlDzSrPIH7Tn4Rd9AJ
	else:			ffbAi4C8snmpa1dHqD7olykV3,JJwnocyLUxHI2jlKF4Y = vODxLKW5Ql6r4Fbm8(u"ࠫࠪࠫࠥࠦࠧ฼ห๊ࠦๅอ้๋่ࠬࠇ"),v1gZtmsfVMqlDzSrPIH7Tn4Rd9AJ
	return ffbAi4C8snmpa1dHqD7olykV3,JJwnocyLUxHI2jlKF4Y,EGJVsZy38Xx,d2xq6KCoULIiPWOyFwp0t,pMAWqrwP80lR
def KuCBN9bgPwIYxne8GvzEV2cq(phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8):
	v1JrBsOo8Qyzk,P3tys0cXWbiIUKk7HQ6n89V = [],[]
	for title,fCXyTlcmF4WuetVork in zip(A7Ap2wdlxM,duef0gb3Mi1AV5WpN8):
		if dVeG46wAnrtlpkbNPsvJ9(fCXyTlcmF4WuetVork):
			v1JrBsOo8Qyzk.append(title)
			P3tys0cXWbiIUKk7HQ6n89V.append(fCXyTlcmF4WuetVork)
	if not P3tys0cXWbiIUKk7HQ6n89V and not phm0nfzAUCXHBjO7lIDSxT3eZJdc: phm0nfzAUCXHBjO7lIDSxT3eZJdc = zmcGfOdvAjsELeJlP(u"ࠬࡌࡡࡪ࡮ࡨࡨࠬࠈ")
	return phm0nfzAUCXHBjO7lIDSxT3eZJdc,v1JrBsOo8Qyzk,P3tys0cXWbiIUKk7HQ6n89V
def SxZwT3eW4fslAEFoCup(url,source):
	eCGwzSrqBmIv,Tah1vG47QFrxd,Zw4M5DUStdE6xp7GI,v1gZtmsfVMqlDzSrPIH7Tn4Rd9AJ,JJwnocyLUxHI2jlKF4Y,EGJVsZy38Xx,d2xq6KCoULIiPWOyFwp0t,pMAWqrwP80lR,aOtvl3xUCgoDIQN0HEVGYf = f8kXlgjdbBWi2ZNtVHaycxeED1TP(url,source)
	if   EMO8gy4LrsNTh0knZwpSeU75APW(u"࠭ࡹࡰࡷࡷࡹࠬࠉ")		in Zw4M5DUStdE6xp7GI: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪࠊ"),[iiy37aKq0pCEIOwfcTh61xb4U],[url]
	elif yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠨࡻ࠵ࡹ࠳ࡨࡥࠨࠋ")		in Zw4M5DUStdE6xp7GI: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = ZchUJdM93pTA7zG5(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬࠌ"),[iiy37aKq0pCEIOwfcTh61xb4U],[url]
	elif CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠪࡵࡻ࡯ࡤࠨࠍ")			in Zw4M5DUStdE6xp7GI: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = uuAyGoxEWv7(eCGwzSrqBmIv)
	elif IpC4qHXRuyNFjzWv(u"ࠫ࡫࡯࡬࡮ࡧࡼࠫࠎ")		in Zw4M5DUStdE6xp7GI: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = uuAyGoxEWv7(eCGwzSrqBmIv)
	elif ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠬࡇࡌࡎࡕࡗࡆࡆ࠭ࠏ")		in source: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = uuAyGoxEWv7(eCGwzSrqBmIv)
	elif UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"࠭ࡁࡌࡑࡄࡑࠬࠐ")		in source: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = vr5aHp1ofi(eCGwzSrqBmIv,JJwnocyLUxHI2jlKF4Y)
	elif vODxLKW5Ql6r4Fbm8(u"ࠧࡂࡍ࡚ࡅࡒ࠭ࠑ")		in source: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = oIeuaPmibU(eCGwzSrqBmIv,EGJVsZy38Xx,pMAWqrwP80lR)
	elif xpT28sXu051(u"ࠨࡈࡄࡗࡊࡒࡈࡅ࠳ࠪࠒ")		in source: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = i1tWTclz6O(eCGwzSrqBmIv)
	elif xpT28sXu051(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪࠓ")		in source: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = TlGXWLYsV1z(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ࠔ"),[iiy37aKq0pCEIOwfcTh61xb4U],[url]
	elif GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠫࡈࡏࡍࡂ࠶ࡘࠫࠕ")		in source: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = WYuiCFZ3mU(eCGwzSrqBmIv)
	elif LyNiIHPOwD3hCUYEFM7(u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡈࠧࠖ")		in source: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = Iwj5CaLmYO(eCGwzSrqBmIv)
	elif hhQwbeiNLoqFjX90fB7aG8VAs(u"࠭ࡁࡓࡃࡅࡗࡊࡋࡄࠨࠗ")		in source: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = sRIEkLr634(eCGwzSrqBmIv)
	elif uuExaKGL7UONtevRd(u"ࠧࡄࡋࡐࡅࡆࡈࡄࡐࠩ࠘")		in source: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = MlFkyhP502(eCGwzSrqBmIv)
	elif zmcGfOdvAjsELeJlP(u"ࠨࡕࡋࡓࡋࡎࡁࠨ࠙")		in source: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = CJPfXMgbsv(eCGwzSrqBmIv)
	elif TlGXWLYsV1z(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠴ࠫࠚ")		in source: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = gpJT7OU15G(eCGwzSrqBmIv,aOtvl3xUCgoDIQN0HEVGYf)
	elif Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠪࡐࡆࡘࡏ࡛ࡃࠪࠛ")		in source: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = WWA4uXG7hb(eCGwzSrqBmIv)
	elif PtkEvXAqif14G20QZsaSyT(u"ࠫࡰࡧࡴ࡬ࡱࡸࡸࡪ࠭ࠜ")		in Zw4M5DUStdE6xp7GI: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = ttolzyQDF7(eCGwzSrqBmIv)
	elif uuExaKGL7UONtevRd(u"ࠬࡧ࡫ࡰࡣࡰ࠲ࡨࡧ࡭ࠨࠝ")	in Zw4M5DUStdE6xp7GI: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = dS3lHm09G4(eCGwzSrqBmIv)
	elif YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"࠭ࡡ࡭ࡣࡵࡥࡧ࠭ࠞ")		in Zw4M5DUStdE6xp7GI: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = Hz8jtLRixdFSy(eCGwzSrqBmIv)
	elif zmcGfOdvAjsELeJlP(u"ࠧࡴࡪࡤ࡬࡮ࡪ࠴ࡶࠩࠟ")		in Zw4M5DUStdE6xp7GI: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = vvcSWtyJxw(eCGwzSrqBmIv)
	elif ZchUJdM93pTA7zG5(u"ࠨࡵ࡫ࡥ࡭࡫ࡤ࠵ࡷࠪࠠ")		in Zw4M5DUStdE6xp7GI: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = vvcSWtyJxw(eCGwzSrqBmIv)
	elif tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠩࡨ࡫ࡾࡴ࡯ࡸࠩࠡ")		in Zw4M5DUStdE6xp7GI: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = pfObhokENe(eCGwzSrqBmIv)
	elif MgP8OjoaiWQEVG59(u"ࠪࡸࡻ࡬ࡵ࡯ࠩࠢ")		in Zw4M5DUStdE6xp7GI: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = V18kA4epvm(eCGwzSrqBmIv)
	elif hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠫࡹࡼ࡫ࡴࡣࠪࠣ")		in Zw4M5DUStdE6xp7GI: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = V18kA4epvm(eCGwzSrqBmIv)
	elif yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠬࡺࡶ࠮ࡨ࠱ࡧࡴࡳࠧࠤ")		in Zw4M5DUStdE6xp7GI: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = V18kA4epvm(eCGwzSrqBmIv)
	elif HtK4o2sTPgA78U(u"࠭ࡨࡢ࡮ࡤࡧ࡮ࡳࡡࠨࠥ")		in Zw4M5DUStdE6xp7GI: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = B0BLI6vrM7(eCGwzSrqBmIv)
	elif hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠧࡴࡪࡲࡳ࡫ࡶࡲࡰࠩࠦ")		in Zw4M5DUStdE6xp7GI: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = NeR5gq8kfL(eCGwzSrqBmIv)
	elif ZchUJdM93pTA7zG5(u"ࠨ࡯ࡼࡩ࡬ࡿࡶࡪࡲࠪࠧ")		in Zw4M5DUStdE6xp7GI: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = BFJ2rvblqP1oSXI0L(eCGwzSrqBmIv)
	elif XrTw01KtLzbpoyMf(u"ࠩࡹࡷ࠹ࡻࠧࠨ")			in Zw4M5DUStdE6xp7GI: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = Qh3dFi9vNj(eCGwzSrqBmIv)
	elif ZchUJdM93pTA7zG5(u"ࠪࡪࡦࡰࡥࡳࠩࠩ")		in Zw4M5DUStdE6xp7GI: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = j9jVLNUiMD(eCGwzSrqBmIv)
	elif YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠫࡨ࡯࡭ࡢࡰࡲࡻࠬࠪ")		in Zw4M5DUStdE6xp7GI: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = nnFQHctSEG(eCGwzSrqBmIv)
	elif ZchUJdM93pTA7zG5(u"ࠬࡴࡥࡸࡥ࡬ࡱࡦ࠭ࠫ")		in Zw4M5DUStdE6xp7GI: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = nnFQHctSEG(eCGwzSrqBmIv)
	elif uuExaKGL7UONtevRd(u"࠭ࡣࡪ࡯ࡤ࠱ࡱ࡯ࡧࡩࡶࠪࠬ")	in Zw4M5DUStdE6xp7GI: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = BDYeH90xTR(eCGwzSrqBmIv)
	elif LyNiIHPOwD3hCUYEFM7(u"ࠧࡤ࡫ࡰࡥࡱ࡯ࡧࡩࡶࠪ࠭")	in Zw4M5DUStdE6xp7GI: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = BDYeH90xTR(eCGwzSrqBmIv)
	elif vODxLKW5Ql6r4Fbm8(u"ࠨ࡯ࡼࡧ࡮ࡳࡡࠨ࠮")		in Zw4M5DUStdE6xp7GI: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = kiFol7tQ5Y(eCGwzSrqBmIv)
	elif SaB5hx3PZwXRLtKgrTfQvId(u"ࠩࡺࡩࡨ࡯࡭ࡢࠩ࠯")		in Zw4M5DUStdE6xp7GI: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = rgoAS9U5fkvaclP2xOL(eCGwzSrqBmIv)
	elif tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠪࡦࡴࡱࡲࡢࠩ࠰")		in Zw4M5DUStdE6xp7GI: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = sZEufTSeXb(eCGwzSrqBmIv)
	elif sVzojQerUqX(u"ࠫࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯ࠩ࠱")	in Zw4M5DUStdE6xp7GI: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = LATecKt1Ra(eCGwzSrqBmIv)
	elif xpT28sXu051(u"ࠬࡧࡲࡣ࡮࡬ࡳࡳࢀࠧ࠲")		in Zw4M5DUStdE6xp7GI: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = nmXJxRS1VU(eCGwzSrqBmIv)
	elif ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"࠭ࡥࡨࡻ࠰ࡦࡪࡹࡴ࠯ࡰࡨࡸࠬ࠳")	in Zw4M5DUStdE6xp7GI: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = PrqXjGnsUS(eCGwzSrqBmIv)
	elif L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠧࡥ࠰ࡨ࡫ࡾࡨࡥࡴࡶ࠱ࡨࠬ࠴")	in Zw4M5DUStdE6xp7GI: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = iiy37aKq0pCEIOwfcTh61xb4U,[iiy37aKq0pCEIOwfcTh61xb4U],[eCGwzSrqBmIv]
	elif XrTw01KtLzbpoyMf(u"ࠨࡧࡪࡽࡧ࡫ࡳࡵࠩ࠵")		in Zw4M5DUStdE6xp7GI: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = eScC4ZYT7g(eCGwzSrqBmIv)
	elif ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠩࡶࡩࡷ࡯ࡥࡴ࠶ࡺࡥࡹࡩࡨࠨ࠶")	in Zw4M5DUStdE6xp7GI: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = zYRenU6D40(eCGwzSrqBmIv)
	elif IpC4qHXRuyNFjzWv(u"ࠪࡹࡵࡨࡡ࡮ࠩ࠷") 		in Zw4M5DUStdE6xp7GI: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = iiy37aKq0pCEIOwfcTh61xb4U,[iiy37aKq0pCEIOwfcTh61xb4U],[eCGwzSrqBmIv]
	else: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = sVzojQerUqX(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ࠸"),[iiy37aKq0pCEIOwfcTh61xb4U],[eCGwzSrqBmIv]
	if phm0nfzAUCXHBjO7lIDSxT3eZJdc not in [zmcGfOdvAjsELeJlP(u"ࠬ࠭࠹"),vODxLKW5Ql6r4Fbm8(u"࠭ࡅ࡙ࡋࡗࡣࡆࡒࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ࠺"),YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ࠻")]: phm0nfzAUCXHBjO7lIDSxT3eZJdc = tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠨࡈࡤ࡭ࡱ࡫ࡤ࠻ࠢࠣࠫ࠼")+phm0nfzAUCXHBjO7lIDSxT3eZJdc
	return phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8
def X3fWYLws8lITS0OKmF(mOYVSgRxWbl194UXva60DTqCsLG7,url,source,aqCScXK4Gg1Dkt5vHL38RJEBUZe):
	global tZwKXhiQu9V2,jzVTwcGFi6v3CMuYyo9RAPr1,cwyepKNO6T7fadQ,aJqDzVrBG3WRbPmSg,R12nle7jSq8fUzMiuc4d
	hGEBZbPToAqx987S0JKiItF = []
	for dcWwXaBn0A in [jzVTwcGFi6v3CMuYyo9RAPr1,cwyepKNO6T7fadQ,aJqDzVrBG3WRbPmSg,R12nle7jSq8fUzMiuc4d]: dcWwXaBn0A[aqCScXK4Gg1Dkt5vHL38RJEBUZe] = xpT28sXu051(u"ࠩࡗ࡭ࡲ࡫࡯ࡶࡶࠪ࠽"),[],[]
	MR8qLo0lX9h4WxZjHQPp2CI63rf,lBFc7h3w6aSW = [LzkNmxOZhK5pFQuPAf7C0B682l,RaXm0HLTSNV5,ddNj8EciKmMCTSoHIkWG,GGbm8zAhH0gcuxEJ3OV],[]
	if PtkEvXAqif14G20QZsaSyT(u"ࠪࡪࡷࡪ࡬ࠨ࠾") in url: MR8qLo0lX9h4WxZjHQPp2CI63rf,lBFc7h3w6aSW = [LzkNmxOZhK5pFQuPAf7C0B682l,RaXm0HLTSNV5,GGbm8zAhH0gcuxEJ3OV],[aJqDzVrBG3WRbPmSg]
	if LyNiIHPOwD3hCUYEFM7(u"ࠫࡾࡵࡵࡵࡷࡥࡩࠬ࠿") in url: MR8qLo0lX9h4WxZjHQPp2CI63rf,lBFc7h3w6aSW = [LzkNmxOZhK5pFQuPAf7C0B682l],[cwyepKNO6T7fadQ,aJqDzVrBG3WRbPmSg,R12nle7jSq8fUzMiuc4d]
	for dcWwXaBn0A in lBFc7h3w6aSW: dcWwXaBn0A[aqCScXK4Gg1Dkt5vHL38RJEBUZe] = LyNiIHPOwD3hCUYEFM7(u"࡙ࠬ࡫ࡪࡲࡳࡩࡩ࠭ࡀ"),[],[]
	for dcWwXaBn0A in MR8qLo0lX9h4WxZjHQPp2CI63rf:
		wDxMFZzR7fGPy = EEehSFDLdpKBR3W1ga9PxrV.Thread(target=dcWwXaBn0A,args=(url,source,aqCScXK4Gg1Dkt5vHL38RJEBUZe))
		hGEBZbPToAqx987S0JKiItF.append(wDxMFZzR7fGPy)
		wDxMFZzR7fGPy.start()
		X2cQ5NCPvkMieBW7oASspFjE.sleep(JZszNnIEMAx28Yao0yqhiXGKOPb(u"࠵฼"))
	IVqvjOfWewrp5NLQa47,SbDm5QMspFXW4B,P8qneipojwIZC7z,TplzLJsydn4Meju512f3FIqP0rtQvk = BF6QAiLUNHh7rKOugaw,BF6QAiLUNHh7rKOugaw,BF6QAiLUNHh7rKOugaw,BF6QAiLUNHh7rKOugaw
	timeout,step = PtkEvXAqif14G20QZsaSyT(u"࠸࠶฽"),nI2JK1RfsGWNY3OarEeMQZ
	for HuCxAcQrZX109MsB6fop in range(timeout//step):
		if not IVqvjOfWewrp5NLQa47 and jzVTwcGFi6v3CMuYyo9RAPr1[aqCScXK4Gg1Dkt5vHL38RJEBUZe][FGTfwsjNrB8DvKSZhLIQAb1JnO]!=zmcGfOdvAjsELeJlP(u"࠭ࡔࡪ࡯ࡨࡳࡺࡺࠧࡁ"): IVqvjOfWewrp5NLQa47 = rGPen6cSMHQkAywh8vqI9JXiD2
		if not SbDm5QMspFXW4B and cwyepKNO6T7fadQ[aqCScXK4Gg1Dkt5vHL38RJEBUZe][FGTfwsjNrB8DvKSZhLIQAb1JnO]!=UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠧࡕ࡫ࡰࡩࡴࡻࡴࠨࡂ"): SbDm5QMspFXW4B = rGPen6cSMHQkAywh8vqI9JXiD2
		if not P8qneipojwIZC7z and aJqDzVrBG3WRbPmSg[aqCScXK4Gg1Dkt5vHL38RJEBUZe][FGTfwsjNrB8DvKSZhLIQAb1JnO]!=hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠨࡖ࡬ࡱࡪࡵࡵࡵࠩࡃ"): P8qneipojwIZC7z = rGPen6cSMHQkAywh8vqI9JXiD2
		if not TplzLJsydn4Meju512f3FIqP0rtQvk and R12nle7jSq8fUzMiuc4d[aqCScXK4Gg1Dkt5vHL38RJEBUZe][FGTfwsjNrB8DvKSZhLIQAb1JnO]!=IpC4qHXRuyNFjzWv(u"ࠩࡗ࡭ࡲ࡫࡯ࡶࡶࠪࡄ"): TplzLJsydn4Meju512f3FIqP0rtQvk = rGPen6cSMHQkAywh8vqI9JXiD2
		if IVqvjOfWewrp5NLQa47 and SbDm5QMspFXW4B and P8qneipojwIZC7z and TplzLJsydn4Meju512f3FIqP0rtQvk: break
		if not jzVTwcGFi6v3CMuYyo9RAPr1[aqCScXK4Gg1Dkt5vHL38RJEBUZe][FGTfwsjNrB8DvKSZhLIQAb1JnO] and jzVTwcGFi6v3CMuYyo9RAPr1[aqCScXK4Gg1Dkt5vHL38RJEBUZe][nI2JK1RfsGWNY3OarEeMQZ]: break
		if not cwyepKNO6T7fadQ[aqCScXK4Gg1Dkt5vHL38RJEBUZe][FGTfwsjNrB8DvKSZhLIQAb1JnO] and cwyepKNO6T7fadQ[aqCScXK4Gg1Dkt5vHL38RJEBUZe][nI2JK1RfsGWNY3OarEeMQZ]: break
		if not aJqDzVrBG3WRbPmSg[aqCScXK4Gg1Dkt5vHL38RJEBUZe][FGTfwsjNrB8DvKSZhLIQAb1JnO] and aJqDzVrBG3WRbPmSg[aqCScXK4Gg1Dkt5vHL38RJEBUZe][nI2JK1RfsGWNY3OarEeMQZ]: break
		if not R12nle7jSq8fUzMiuc4d[aqCScXK4Gg1Dkt5vHL38RJEBUZe][FGTfwsjNrB8DvKSZhLIQAb1JnO] and R12nle7jSq8fUzMiuc4d[aqCScXK4Gg1Dkt5vHL38RJEBUZe][nI2JK1RfsGWNY3OarEeMQZ]: break
		X2cQ5NCPvkMieBW7oASspFjE.sleep(step)
	for wDxMFZzR7fGPy in hGEBZbPToAqx987S0JKiItF: wDxMFZzR7fGPy.join(JZszNnIEMAx28Yao0yqhiXGKOPb(u"࠷฾"))
	jGkVuA5exwsdvRby7 = TlGXWLYsV1z(u"ࠪࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘ࡟࠳ࠩࡅ")
	phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = jzVTwcGFi6v3CMuYyo9RAPr1[aqCScXK4Gg1Dkt5vHL38RJEBUZe]
	duef0gb3Mi1AV5WpN8 = xn9QjVJdASLWz1a4fNrYRqgc2o(duef0gb3Mi1AV5WpN8)
	tZwKXhiQu9V2[aqCScXK4Gg1Dkt5vHL38RJEBUZe] = mOYVSgRxWbl194UXva60DTqCsLG7,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8
	if phm0nfzAUCXHBjO7lIDSxT3eZJdc==LyNiIHPOwD3hCUYEFM7(u"ࠫࡊ࡞ࡉࡕࡡࡄࡐࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩࡆ") or duef0gb3Mi1AV5WpN8: return jGkVuA5exwsdvRby7,phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8
	mOYVSgRxWbl194UXva60DTqCsLG7 += AbqCJZdWQP9j(u"ࠬࡢ࡮ࡓࡧࡶࡳࡱࡼࡥࡳࠢ࠵࠾ࠥࠦࠧࡇ")+phm0nfzAUCXHBjO7lIDSxT3eZJdc.replace(OTlVEGYPSxsNaBdXUucqA3,iiy37aKq0pCEIOwfcTh61xb4U).replace(Mge0HhFk9Ic6sm5VR,iiy37aKq0pCEIOwfcTh61xb4U)[:Y41NvKfOroMzGB8sEHy7wbXlc5(u"࠸࠱฿")]
	jGkVuA5exwsdvRby7 = yJeq1BjfiO4NFuwIEzxVLK6b9s(u"࠭ࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡢ࠷ࠬࡈ")
	phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = cwyepKNO6T7fadQ[aqCScXK4Gg1Dkt5vHL38RJEBUZe]
	duef0gb3Mi1AV5WpN8 = xn9QjVJdASLWz1a4fNrYRqgc2o(duef0gb3Mi1AV5WpN8)
	tZwKXhiQu9V2[aqCScXK4Gg1Dkt5vHL38RJEBUZe] = mOYVSgRxWbl194UXva60DTqCsLG7,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8
	if phm0nfzAUCXHBjO7lIDSxT3eZJdc==FRYcH4KL7e9gv5pEB(u"ࠧࡆ࡚ࡌࡘࡤࡇࡌࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬࡉ") or duef0gb3Mi1AV5WpN8: return jGkVuA5exwsdvRby7,phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8
	mOYVSgRxWbl194UXva60DTqCsLG7 += EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠨ࡞ࡱࡖࡪࡹ࡯࡭ࡸࡨࡶࠥ࠹࠺ࠡࠢࠪࡊ")+phm0nfzAUCXHBjO7lIDSxT3eZJdc.replace(OTlVEGYPSxsNaBdXUucqA3,iiy37aKq0pCEIOwfcTh61xb4U).replace(Mge0HhFk9Ic6sm5VR,iiy37aKq0pCEIOwfcTh61xb4U)[:AbqCJZdWQP9j(u"࠹࠲เ")]
	jGkVuA5exwsdvRby7 = jXE2YHkswT8y(u"ࠩࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗࡥ࠴ࠨࡋ")
	phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = aJqDzVrBG3WRbPmSg[aqCScXK4Gg1Dkt5vHL38RJEBUZe]
	duef0gb3Mi1AV5WpN8 = xn9QjVJdASLWz1a4fNrYRqgc2o(duef0gb3Mi1AV5WpN8)
	tZwKXhiQu9V2[aqCScXK4Gg1Dkt5vHL38RJEBUZe] = mOYVSgRxWbl194UXva60DTqCsLG7,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8
	if phm0nfzAUCXHBjO7lIDSxT3eZJdc==sVzojQerUqX(u"ࠪࡉ࡝ࡏࡔࡠࡃࡏࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨࡌ") or duef0gb3Mi1AV5WpN8: return jGkVuA5exwsdvRby7,phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8
	mOYVSgRxWbl194UXva60DTqCsLG7 += ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠫࡡࡴࡒࡦࡵࡲࡰࡻ࡫ࡲࠡ࠶࠽ࠤࠥ࠭ࡍ")+phm0nfzAUCXHBjO7lIDSxT3eZJdc.replace(OTlVEGYPSxsNaBdXUucqA3,iiy37aKq0pCEIOwfcTh61xb4U).replace(Mge0HhFk9Ic6sm5VR,iiy37aKq0pCEIOwfcTh61xb4U)[:uuExaKGL7UONtevRd(u"࠺࠳แ")]
	jGkVuA5exwsdvRby7 = FRYcH4KL7e9gv5pEB(u"ࠬࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡡ࠸ࠫࡎ")
	phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = R12nle7jSq8fUzMiuc4d[aqCScXK4Gg1Dkt5vHL38RJEBUZe]
	duef0gb3Mi1AV5WpN8 = xn9QjVJdASLWz1a4fNrYRqgc2o(duef0gb3Mi1AV5WpN8)
	tZwKXhiQu9V2[aqCScXK4Gg1Dkt5vHL38RJEBUZe] = mOYVSgRxWbl194UXva60DTqCsLG7,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8
	if phm0nfzAUCXHBjO7lIDSxT3eZJdc==XrTw01KtLzbpoyMf(u"࠭ࡅ࡙ࡋࡗࡣࡆࡒࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫࡏ") or duef0gb3Mi1AV5WpN8: return jGkVuA5exwsdvRby7,phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8
	mOYVSgRxWbl194UXva60DTqCsLG7 += SaB5hx3PZwXRLtKgrTfQvId(u"ࠧ࡝ࡰࡕࡩࡸࡵ࡬ࡷࡧࡵࠤ࠺ࡀࠠࠡࠩࡐ")+phm0nfzAUCXHBjO7lIDSxT3eZJdc.replace(OTlVEGYPSxsNaBdXUucqA3,iiy37aKq0pCEIOwfcTh61xb4U).replace(Mge0HhFk9Ic6sm5VR,iiy37aKq0pCEIOwfcTh61xb4U)[:JZszNnIEMAx28Yao0yqhiXGKOPb(u"࠻࠴โ")]
	tZwKXhiQu9V2[aqCScXK4Gg1Dkt5vHL38RJEBUZe] = mOYVSgRxWbl194UXva60DTqCsLG7,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8
	return jGkVuA5exwsdvRby7,mOYVSgRxWbl194UXva60DTqCsLG7,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8
def LzkNmxOZhK5pFQuPAf7C0B682l(url,source,aqCScXK4Gg1Dkt5vHL38RJEBUZe):
	eCGwzSrqBmIv,Tah1vG47QFrxd,Zw4M5DUStdE6xp7GI,v1gZtmsfVMqlDzSrPIH7Tn4Rd9AJ,JJwnocyLUxHI2jlKF4Y,EGJVsZy38Xx,d2xq6KCoULIiPWOyFwp0t,pMAWqrwP80lR,aOtvl3xUCgoDIQN0HEVGYf = f8kXlgjdbBWi2ZNtVHaycxeED1TP(url,source)
	duef0gb3Mi1AV5WpN8 = []
	if HtK4o2sTPgA78U(u"ࠨࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠭ࡑ")	in Zw4M5DUStdE6xp7GI: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = LATecKt1Ra(url)
	elif IpC4qHXRuyNFjzWv(u"ࠩࡪࡳࡴ࡭࡬ࡦࡷࡶࡩࡷࡩ࡯ࠨࡒ") in Zw4M5DUStdE6xp7GI: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = WjkxfB6anb3TSmEv(url)
	elif yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠪࡽࡴࡻࡴࡶࠩࡓ")		in Zw4M5DUStdE6xp7GI: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = z6LdPkhxOr2V3fQFp7B9(url)
	elif AbqCJZdWQP9j(u"ࠫࡾ࠸ࡵ࠯ࡤࡨࠫࡔ")		in Zw4M5DUStdE6xp7GI: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = z6LdPkhxOr2V3fQFp7B9(url)
	elif EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠬࡶࡨࡰࡶࡲࡷ࠳ࡧࡰࡱ࠰ࡪࠫࡕ")	in url   : phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = c0i9xeIUCVJkFw6L(url)
	elif GGx4qyKP1vUtRghsE2WfaHLMXZ(u"࠭࡭ࡰࡵ࡫ࡥ࡭ࡪࡡࠨࡖ")		in Zw4M5DUStdE6xp7GI: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = R4xVvt2TlcrnYW8(url)
	elif IpC4qHXRuyNFjzWv(u"ࠧࡧࡣࡶࡩࡱ࡮ࡤࠨࡗ")		in url   : phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = i1tWTclz6O(url)
	elif GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠨࡣࡵࡥࡧࡲ࡯ࡢࡦࡶࠫࡘ")	in Zw4M5DUStdE6xp7GI: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = hmQAKxRf074ql9XNz6UpkHsnc(url)
	elif ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠩࡤࡶࡨ࡮ࡩࡷࡧ࡙ࠪ")		in Zw4M5DUStdE6xp7GI: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = dzNDMaOYqjBUZpTCWuecvk8V301o(url)
	elif Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠪࡦࡺࢀࡺࡷࡴ࡯࡚ࠫ")		in Zw4M5DUStdE6xp7GI: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = wYI46DCkqPB9A(url)
	elif ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠫࡪ࠻ࡴࡴࡣࡵ࡛ࠫ")		in Zw4M5DUStdE6xp7GI: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = UUTM5J1g9qbI(url)
	elif tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠬ࡬ࡡࡤࡷ࡯ࡸࡾࡨ࡯ࡰ࡭ࡶࠫ࡜")	in Zw4M5DUStdE6xp7GI: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = elyOETRJDU8afgsdM9uI50iCN6wpm(url)
	elif hhQwbeiNLoqFjX90fB7aG8VAs(u"࠭ࡩ࡯ࡨ࡯ࡥࡲ࠴ࡣࡤࠩ࡝")	in Zw4M5DUStdE6xp7GI: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = elyOETRJDU8afgsdM9uI50iCN6wpm(url)
	elif IpC4qHXRuyNFjzWv(u"ࠧࡶࡲࡥࡥࡲ࠭࡞") 		in Zw4M5DUStdE6xp7GI: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = iiy37aKq0pCEIOwfcTh61xb4U,[iiy37aKq0pCEIOwfcTh61xb4U],[url]
	elif YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠨ࡮࡬࡭ࡻ࡯ࡤࡦࡱࠪ࡟") 	in Zw4M5DUStdE6xp7GI: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = awL8f4UXuTE(url)
	elif y6y5HtgXO4TkUbwVZ(u"ࠩࡰࡴ࠹ࡻࡰ࡭ࡱࡤࡨࠬࡠ")	in Zw4M5DUStdE6xp7GI: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = SD1gIurNBUWjq(url)
	elif PtkEvXAqif14G20QZsaSyT(u"ࠪࡶࡦࡶࡩࡥࡸ࡬ࡨࡪࡵࠧࡡ") 	in Zw4M5DUStdE6xp7GI: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = qqI9tn4BaLAEv(url)
	elif yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠫࡹࡵࡰ࠵ࡶࡲࡴࠬࡢ")		in Zw4M5DUStdE6xp7GI: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = BCpdKNMx4t(url)
	elif ZchUJdM93pTA7zG5(u"ࠬࡻࡰࡣࠩࡣ") 			in Zw4M5DUStdE6xp7GI: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = ZT24V7nCGp(url)
	elif jXE2YHkswT8y(u"࠭ࡵࡱࡲࠪࡤ") 			in Zw4M5DUStdE6xp7GI: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = ZT24V7nCGp(url)
	elif zmcGfOdvAjsELeJlP(u"ࠧࡶࡳ࡯ࡳࡦࡪࠧࡥ") 		in Zw4M5DUStdE6xp7GI: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = UzG0eH6OjQSYr(url)
	elif GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠨࡸ࡮ࠫࡦ")	 		in Zw4M5DUStdE6xp7GI: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = HtF3Z1J56gqD2TdwCo(eCGwzSrqBmIv)
	elif tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠩࡹࡧࡸࡺࡲࡦࡣࡰࠫࡧ") 	in Zw4M5DUStdE6xp7GI: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = JJdsf3YkRMCHx8mu45V(url)
	elif AbqCJZdWQP9j(u"ࠪࡺ࡮ࡪࡢࡰࡤࠪࡨ")		in Zw4M5DUStdE6xp7GI: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = wMmEKTqbuceaAgzjkZGs1l0OYd5PyR(url)
	elif yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠫࡻ࡯ࡤࡰࡼࡤࠫࡩ") 		in Zw4M5DUStdE6xp7GI: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = ISjGlvDeVK1TE6U2bRiZ(url)
	elif LyNiIHPOwD3hCUYEFM7(u"ࠬࡽࡡࡵࡥ࡫ࡺ࡮ࡪࡥࡰࠩࡪ") 	in Zw4M5DUStdE6xp7GI: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = SfL14M8xHB5Fi3ZDE9rV(url)
	elif HtK4o2sTPgA78U(u"࠭ࡷࡪࡰࡷࡺ࠳ࡲࡩࡷࡧࠪ࡫")	in Zw4M5DUStdE6xp7GI: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = g2gYcCOpUuB(url)
	elif EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠧࡻ࡫ࡳࡴࡾࡹࡨࡢࡴࡨࠫ࡬")	in Zw4M5DUStdE6xp7GI: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = ddKeEc2pHv3fhoikzByNOJqAS(url)
	else: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = iiy37aKq0pCEIOwfcTh61xb4U,[],[]
	global jzVTwcGFi6v3CMuYyo9RAPr1
	if phm0nfzAUCXHBjO7lIDSxT3eZJdc not in [YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠨࠩ࡭"),jXE2YHkswT8y(u"ࠩࡈ࡜ࡎ࡚࡟ࡂࡎࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ࡮"),yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭࡯")]: phm0nfzAUCXHBjO7lIDSxT3eZJdc = SaB5hx3PZwXRLtKgrTfQvId(u"ࠫࡋࡧࡩ࡭ࡧࡧ࠾ࠥࠦࠧࡰ")+phm0nfzAUCXHBjO7lIDSxT3eZJdc
	jzVTwcGFi6v3CMuYyo9RAPr1[aqCScXK4Gg1Dkt5vHL38RJEBUZe] = phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8
	return
def RaXm0HLTSNV5(url,source,aqCScXK4Gg1Dkt5vHL38RJEBUZe):
	global cwyepKNO6T7fadQ
	if ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠬࡿ࡯ࡶࡶࡸࡦࡪ࠭ࡱ") in url:
		cwyepKNO6T7fadQ[aqCScXK4Gg1Dkt5vHL38RJEBUZe] = CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"࠭ࡆࡢ࡫࡯ࡩࡩࡀࠠࠡࡕ࡮࡭ࡵࡶࡥࡥࠩࡲ"),[],[]
		return
	phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = iiy37aKq0pCEIOwfcTh61xb4U,[],[]
	if dVeG46wAnrtlpkbNPsvJ9(url):
		phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = iiy37aKq0pCEIOwfcTh61xb4U,[iiy37aKq0pCEIOwfcTh61xb4U],[url]
	if not duef0gb3Mi1AV5WpN8:
		phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = vvsnFTHJdrV9RCOPoe(url)
	if not duef0gb3Mi1AV5WpN8:
		phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = NNZ7ynOVBYwG5(url)
	if not duef0gb3Mi1AV5WpN8:
		if phm0nfzAUCXHBjO7lIDSxT3eZJdc==TlGXWLYsV1z(u"ࠧࡆ࡚ࡌࡘࡤࡇࡌࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬࡳ"): phm0nfzAUCXHBjO7lIDSxT3eZJdc = iiy37aKq0pCEIOwfcTh61xb4U
		cwyepKNO6T7fadQ[aqCScXK4Gg1Dkt5vHL38RJEBUZe] = yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠨࡈࡤ࡭ࡱ࡫ࡤ࠻ࠢࠣࠫࡴ")+phm0nfzAUCXHBjO7lIDSxT3eZJdc,[],[]
		return
	cwyepKNO6T7fadQ[aqCScXK4Gg1Dkt5vHL38RJEBUZe] = phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8
	return
def ddNj8EciKmMCTSoHIkWG(url,source,aqCScXK4Gg1Dkt5vHL38RJEBUZe):
	UIxuCn8wAWpgz5j9EdqFvreH = iiy37aKq0pCEIOwfcTh61xb4U
	EA7FzO1kMZGQXDd2giB0cwLom = BF6QAiLUNHh7rKOugaw
	try:
		import resolveurl as hqw1OrFBjHzZPWefI3vKplA
		EA7FzO1kMZGQXDd2giB0cwLom = hqw1OrFBjHzZPWefI3vKplA.resolve(url)
	except Exception as IIwlEFYZdnU6Seizqv1C3ct: UIxuCn8wAWpgz5j9EdqFvreH = str(IIwlEFYZdnU6Seizqv1C3ct)
	global aJqDzVrBG3WRbPmSg
	if not EA7FzO1kMZGQXDd2giB0cwLom:
		if UIxuCn8wAWpgz5j9EdqFvreH==iiy37aKq0pCEIOwfcTh61xb4U:
			UIxuCn8wAWpgz5j9EdqFvreH = xiFBCH5hcJks.format_exc()
			if UIxuCn8wAWpgz5j9EdqFvreH!=tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠩࡑࡳࡳ࡫ࡔࡺࡲࡨ࠾ࠥࡔ࡯࡯ࡧ࡟ࡲࠬࡵ"): ytv0YaxDcRINurplWKg587Pwqz.stderr.write(UIxuCn8wAWpgz5j9EdqFvreH)
		phm0nfzAUCXHBjO7lIDSxT3eZJdc = UIxuCn8wAWpgz5j9EdqFvreH.splitlines()[-YYJQyRskpX8jv]
		aJqDzVrBG3WRbPmSg[aqCScXK4Gg1Dkt5vHL38RJEBUZe] = jXE2YHkswT8y(u"ࠪࡊࡦ࡯࡬ࡦࡦ࠽ࠤࠥ࠭ࡶ")+phm0nfzAUCXHBjO7lIDSxT3eZJdc,[],[]
		return
	aJqDzVrBG3WRbPmSg[aqCScXK4Gg1Dkt5vHL38RJEBUZe] = iiy37aKq0pCEIOwfcTh61xb4U,[iiy37aKq0pCEIOwfcTh61xb4U],[EA7FzO1kMZGQXDd2giB0cwLom]
	return
def GGbm8zAhH0gcuxEJ3OV(url,source,aqCScXK4Gg1Dkt5vHL38RJEBUZe):
	UIxuCn8wAWpgz5j9EdqFvreH = iiy37aKq0pCEIOwfcTh61xb4U
	EA7FzO1kMZGQXDd2giB0cwLom = BF6QAiLUNHh7rKOugaw
	try:
		import yt_dlp as Zdn0e3WqOJg1Av
		jbuwgL7B3Oc49IV = Zdn0e3WqOJg1Av.YoutubeDL({UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠫࡳࡵ࡟ࡤࡱ࡯ࡳࡷ࠭ࡷ"): rGPen6cSMHQkAywh8vqI9JXiD2})
		EA7FzO1kMZGQXDd2giB0cwLom = jbuwgL7B3Oc49IV.extract_info(url,download=BF6QAiLUNHh7rKOugaw)
	except Exception as IIwlEFYZdnU6Seizqv1C3ct: UIxuCn8wAWpgz5j9EdqFvreH = str(IIwlEFYZdnU6Seizqv1C3ct)
	global R12nle7jSq8fUzMiuc4d
	if not EA7FzO1kMZGQXDd2giB0cwLom or TlGXWLYsV1z(u"ࠬ࡬࡯ࡳ࡯ࡤࡸࡸ࠭ࡸ") not in list(EA7FzO1kMZGQXDd2giB0cwLom.keys()):
		if UIxuCn8wAWpgz5j9EdqFvreH==iiy37aKq0pCEIOwfcTh61xb4U:
			UIxuCn8wAWpgz5j9EdqFvreH = xiFBCH5hcJks.format_exc()
			if UIxuCn8wAWpgz5j9EdqFvreH!=CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"࠭ࡎࡰࡰࡨࡘࡾࡶࡥ࠻ࠢࡑࡳࡳ࡫࡜࡯ࠩࡹ"): ytv0YaxDcRINurplWKg587Pwqz.stderr.write(UIxuCn8wAWpgz5j9EdqFvreH)
		phm0nfzAUCXHBjO7lIDSxT3eZJdc = UIxuCn8wAWpgz5j9EdqFvreH.splitlines()[-YYJQyRskpX8jv]
		R12nle7jSq8fUzMiuc4d[aqCScXK4Gg1Dkt5vHL38RJEBUZe] = CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠧࡇࡣ࡬ࡰࡪࡪ࠺ࠡࠢࠪࡺ")+phm0nfzAUCXHBjO7lIDSxT3eZJdc,[],[]
	else:
		A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = [],[]
		for fCXyTlcmF4WuetVork in EA7FzO1kMZGQXDd2giB0cwLom[vODxLKW5Ql6r4Fbm8(u"ࠨࡨࡲࡶࡲࡧࡴࡴࠩࡻ")]:
			A7Ap2wdlxM.append(fCXyTlcmF4WuetVork[tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠩࡩࡳࡷࡳࡡࡵࠩࡼ")])
			duef0gb3Mi1AV5WpN8.append(fCXyTlcmF4WuetVork[TlGXWLYsV1z(u"ࠪࡹࡷࡲࠧࡽ")])
		R12nle7jSq8fUzMiuc4d[aqCScXK4Gg1Dkt5vHL38RJEBUZe] = iiy37aKq0pCEIOwfcTh61xb4U,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8
	return
def vvsnFTHJdrV9RCOPoe(url):
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(r3rnfZ7cdxzNFebIRaLSG6B,IpC4qHXRuyNFjzWv(u"ࠫࡌࡋࡔࠨࡾ"),url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,BF6QAiLUNHh7rKOugaw,EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡔࡈࡈࡎࡘࡅࡄࡖࡢ࡙ࡗࡒ࠭࠲ࡵࡷࠫࡿ"))
	headers = oCJ8TdG2LwSIVcbaUnhB.headers
	if LyNiIHPOwD3hCUYEFM7(u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨࢀ") in list(headers.keys()):
		fCXyTlcmF4WuetVork = oCJ8TdG2LwSIVcbaUnhB.headers[HtK4o2sTPgA78U(u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩࢁ")]
		if dVeG46wAnrtlpkbNPsvJ9(fCXyTlcmF4WuetVork): return iiy37aKq0pCEIOwfcTh61xb4U,[iiy37aKq0pCEIOwfcTh61xb4U],[fCXyTlcmF4WuetVork]
	return GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠨࡈࡤ࡭ࡱ࡫ࡤ࠻ࠢࠣࠫࢂ"),[],[]
def xn9QjVJdASLWz1a4fNrYRqgc2o(ddysUlpTPGoEQeXhfNjC):
	if UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠩ࡯࡭ࡸࡺࠧࢃ") in str(type(ddysUlpTPGoEQeXhfNjC)):
		P3tys0cXWbiIUKk7HQ6n89V = []
		for fCXyTlcmF4WuetVork in ddysUlpTPGoEQeXhfNjC:
			if hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠪࡷࡹࡸࠧࢄ") in str(type(fCXyTlcmF4WuetVork)): fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork.replace(Mge0HhFk9Ic6sm5VR,iiy37aKq0pCEIOwfcTh61xb4U).replace(OTlVEGYPSxsNaBdXUucqA3,iiy37aKq0pCEIOwfcTh61xb4U).strip(iFBmE2MUIpSu34wsd7Rf6z)
			P3tys0cXWbiIUKk7HQ6n89V.append(fCXyTlcmF4WuetVork)
	else: P3tys0cXWbiIUKk7HQ6n89V = ddysUlpTPGoEQeXhfNjC.replace(Mge0HhFk9Ic6sm5VR,iiy37aKq0pCEIOwfcTh61xb4U).replace(OTlVEGYPSxsNaBdXUucqA3,iiy37aKq0pCEIOwfcTh61xb4U).strip(iFBmE2MUIpSu34wsd7Rf6z)
	return P3tys0cXWbiIUKk7HQ6n89V
def jSN2OF7lcKViRHxnLGTvf(j6P7d92fziHV3s,source):
	data = QKzCiBOWZus1nSv(PdkZHNBlpg2b7DmX6qRiyVa,EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠫࡱ࡯ࡳࡵࠩࢅ"),AbqCJZdWQP9j(u"࡙ࠬࡅࡓࡘࡈࡖࡘ࠭ࢆ"),j6P7d92fziHV3s)
	if data:
		A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = zip(*data)
		A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = list(A7Ap2wdlxM),list(duef0gb3Mi1AV5WpN8)
		return A7Ap2wdlxM,duef0gb3Mi1AV5WpN8
	A7Ap2wdlxM,duef0gb3Mi1AV5WpN8,bHhtkEFl2BO0715pcj3DqT = [],[],[]
	for fCXyTlcmF4WuetVork in j6P7d92fziHV3s:
		if hhQwbeiNLoqFjX90fB7aG8VAs(u"࠭࠯࠰ࠩࢇ") not in fCXyTlcmF4WuetVork: continue
		ffbAi4C8snmpa1dHqD7olykV3,JJwnocyLUxHI2jlKF4Y,EGJVsZy38Xx,d2xq6KCoULIiPWOyFwp0t,pMAWqrwP80lR = idykRD0Z6AFpX7YszJg2El(fCXyTlcmF4WuetVork,source)
		pMAWqrwP80lR = dEyT9xhGjolYzLCH7460w3.findall(zmcGfOdvAjsELeJlP(u"ࠧ࡝ࡦ࠮ࠫ࢈"),pMAWqrwP80lR,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if pMAWqrwP80lR: pMAWqrwP80lR = int(pMAWqrwP80lR[FGTfwsjNrB8DvKSZhLIQAb1JnO])
		else: pMAWqrwP80lR = FGTfwsjNrB8DvKSZhLIQAb1JnO
		Zw4M5DUStdE6xp7GI = F82MvyX4ThI6sbnA3efDoVS(fCXyTlcmF4WuetVork,IpC4qHXRuyNFjzWv(u"ࠨࡰࡤࡱࡪ࠭ࢉ"))
		bHhtkEFl2BO0715pcj3DqT.append([ffbAi4C8snmpa1dHqD7olykV3,JJwnocyLUxHI2jlKF4Y,EGJVsZy38Xx,d2xq6KCoULIiPWOyFwp0t,pMAWqrwP80lR,fCXyTlcmF4WuetVork,Zw4M5DUStdE6xp7GI])
	if bHhtkEFl2BO0715pcj3DqT:
		e46jmo3rxZLscOdq = sorted(bHhtkEFl2BO0715pcj3DqT,reverse=rGPen6cSMHQkAywh8vqI9JXiD2,key=lambda key: (key[pZWli1xqfVtvzuSU6ImNw53gBFsh],key[FGTfwsjNrB8DvKSZhLIQAb1JnO],key[iiCWLaJREureAlOkv],key[nI2JK1RfsGWNY3OarEeMQZ],key[YYJQyRskpX8jv],key[EMO8gy4LrsNTh0knZwpSeU75APW(u"࠹ใ")],key[TlGXWLYsV1z(u"࠻ไ")]))
		fwDKASjdbmGvouLTFke,gbHP10xvrEmBAQsTkuwGoyeIz = [],[]
		for FHgYoph3Crdti1vBMqTJ82WO in e46jmo3rxZLscOdq:
			ffbAi4C8snmpa1dHqD7olykV3,JJwnocyLUxHI2jlKF4Y,EGJVsZy38Xx,d2xq6KCoULIiPWOyFwp0t,pMAWqrwP80lR,fCXyTlcmF4WuetVork,Zw4M5DUStdE6xp7GI = FHgYoph3Crdti1vBMqTJ82WO
			if y6y5HtgXO4TkUbwVZ(u"่ࠩๅ฻๊ࠧࢊ") in EGJVsZy38Xx:
				gbHP10xvrEmBAQsTkuwGoyeIz.append(FHgYoph3Crdti1vBMqTJ82WO)
				continue
			if FHgYoph3Crdti1vBMqTJ82WO not in fwDKASjdbmGvouLTFke: fwDKASjdbmGvouLTFke.append(FHgYoph3Crdti1vBMqTJ82WO)
		fwDKASjdbmGvouLTFke = gbHP10xvrEmBAQsTkuwGoyeIz+fwDKASjdbmGvouLTFke
		rxbivCFQ9aAnpckTUXYh65dH4 = FGTfwsjNrB8DvKSZhLIQAb1JnO
		for ffbAi4C8snmpa1dHqD7olykV3,JJwnocyLUxHI2jlKF4Y,EGJVsZy38Xx,d2xq6KCoULIiPWOyFwp0t,pMAWqrwP80lR,fCXyTlcmF4WuetVork,Zw4M5DUStdE6xp7GI in fwDKASjdbmGvouLTFke:
			pMAWqrwP80lR = str(pMAWqrwP80lR) if pMAWqrwP80lR else iiy37aKq0pCEIOwfcTh61xb4U
			title = SaB5hx3PZwXRLtKgrTfQvId(u"ࠪื๏ืแาࠩࢋ")+iFBmE2MUIpSu34wsd7Rf6z+EGJVsZy38Xx+iFBmE2MUIpSu34wsd7Rf6z+ffbAi4C8snmpa1dHqD7olykV3+iFBmE2MUIpSu34wsd7Rf6z+pMAWqrwP80lR+iFBmE2MUIpSu34wsd7Rf6z+d2xq6KCoULIiPWOyFwp0t+iFBmE2MUIpSu34wsd7Rf6z+JJwnocyLUxHI2jlKF4Y
			if Zw4M5DUStdE6xp7GI.lower() not in title.lower(): title = title+iFBmE2MUIpSu34wsd7Rf6z+Zw4M5DUStdE6xp7GI
			title = title.replace(YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠫࠪ࠭ࢌ"),iiy37aKq0pCEIOwfcTh61xb4U).strip(iFBmE2MUIpSu34wsd7Rf6z).replace(Wc5GekRC0HQLz7,iFBmE2MUIpSu34wsd7Rf6z).replace(Wc5GekRC0HQLz7,iFBmE2MUIpSu34wsd7Rf6z).replace(Wc5GekRC0HQLz7,iFBmE2MUIpSu34wsd7Rf6z)
			rxbivCFQ9aAnpckTUXYh65dH4 += YYJQyRskpX8jv
			title = str(rxbivCFQ9aAnpckTUXYh65dH4)+hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠬ࠴ࠠࠨࢍ")+title
			if fCXyTlcmF4WuetVork not in duef0gb3Mi1AV5WpN8:
				A7Ap2wdlxM.append(title)
				duef0gb3Mi1AV5WpN8.append(fCXyTlcmF4WuetVork)
		if duef0gb3Mi1AV5WpN8:
			data = zip(A7Ap2wdlxM,duef0gb3Mi1AV5WpN8)
			if data: YMQXP2BGeK86CEb(PdkZHNBlpg2b7DmX6qRiyVa,yJeq1BjfiO4NFuwIEzxVLK6b9s(u"࠭ࡓࡆࡔ࡙ࡉࡗ࡙ࠧࢎ"),j6P7d92fziHV3s,data,Dxc7GChQwZ4kOlKHSbL06agnB)
	A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = list(A7Ap2wdlxM),list(duef0gb3Mi1AV5WpN8)
	return A7Ap2wdlxM,duef0gb3Mi1AV5WpN8
def Hz8jtLRixdFSy(url):
	if uuExaKGL7UONtevRd(u"ࠧ࠯࡯࠶ࡹ࠽࠭࢏") in url:
		A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = VKTp8gacXPG9Zr4H3NQCM0O(sQU2GnRoMwLK8CBdfzmNr4jXyO,url)
		if duef0gb3Mi1AV5WpN8: return iiy37aKq0pCEIOwfcTh61xb4U,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8
		return IpC4qHXRuyNFjzWv(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡑ࠸࡛࠸ࠨ࢐"),[],[]
	return jXE2YHkswT8y(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ࢑"),[iiy37aKq0pCEIOwfcTh61xb4U],[url]
def ttolzyQDF7(url):
	ff2PjlcCF5ZWyIUbVguMz,WK130YrED8vNhiHntepuXR = [],[]
	if GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠪ࠳ࡻ࡯ࡤࡦࡱࡶ࠲ࡲࡶ࠴ࡀࡸ࡬ࡨࡂ࠭࢒") in url:
		oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠫࡌࡋࡔࠨ࢓"),url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,BF6QAiLUNHh7rKOugaw,iiy37aKq0pCEIOwfcTh61xb4U,FRYcH4KL7e9gv5pEB(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡍࡄࡘࡐࡕࡕࡕࡇ࠰࠵ࡸࡺࠧ࢔"))
		if SaB5hx3PZwXRLtKgrTfQvId(u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ࢕") in oCJ8TdG2LwSIVcbaUnhB.headers:
			fCXyTlcmF4WuetVork = oCJ8TdG2LwSIVcbaUnhB.headers[xpT28sXu051(u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ࢖")]
			ff2PjlcCF5ZWyIUbVguMz.append(fCXyTlcmF4WuetVork)
			Zw4M5DUStdE6xp7GI = F82MvyX4ThI6sbnA3efDoVS(fCXyTlcmF4WuetVork,JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠨࡰࡤࡱࡪ࠭ࢗ"))
			WK130YrED8vNhiHntepuXR.append(Zw4M5DUStdE6xp7GI)
	elif sVzojQerUqX(u"ࠩ࡮ࡥࡹࡱ࡯ࡶࡶࡨ࠲ࡨࡵ࡭ࠨ࢘") in url:
		oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,SaB5hx3PZwXRLtKgrTfQvId(u"ࠪࡋࡊ࡚࢙ࠧ"),url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,jXE2YHkswT8y(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡌࡃࡗࡏࡔ࡛ࡔࡆ࠯࠵ࡲࡩ࢚࠭"))
		Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
		EmgOrMcPySkh2oFitb4qvNU7nQGD = dEyT9xhGjolYzLCH7460w3.findall(ZchUJdM93pTA7zG5(u"ࠬ࠮ࡥࡷࡣ࡯ࡠ࠭࡬ࡵ࡯ࡥࡷ࡭ࡴࡴ࡜ࠩࡲ࠯ࡥ࠱ࡩࠬ࡬࠮ࡨ࠰ࡩࡢࠩ࠯ࠬࡂࡠ࠮ࡢࠩࠪ࠰࠿࠳ࡸࡩࡲࡪࡲࡷࡂ࢛ࠬ"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if EmgOrMcPySkh2oFitb4qvNU7nQGD:
			EmgOrMcPySkh2oFitb4qvNU7nQGD = EmgOrMcPySkh2oFitb4qvNU7nQGD[FGTfwsjNrB8DvKSZhLIQAb1JnO]
			vvrRwpWAOoSGThIJQVtCd2ZL = D9gvQoIknzpr5chBa6Y2VKHxPq(EmgOrMcPySkh2oFitb4qvNU7nQGD)
			fwNvItaL3xQTbzmYMq = dEyT9xhGjolYzLCH7460w3.findall(MgP8OjoaiWQEVG59(u"࠭ࡳࡰࡷࡵࡧࡪࡹ࠺ࠩ࡞࡞࠲࠯ࡅ࡜࡞ࠫ࠯ࠫ࢜"),vvrRwpWAOoSGThIJQVtCd2ZL,dEyT9xhGjolYzLCH7460w3.DOTALL)
			if fwNvItaL3xQTbzmYMq:
				fwNvItaL3xQTbzmYMq = fwNvItaL3xQTbzmYMq[FGTfwsjNrB8DvKSZhLIQAb1JnO]
				fwNvItaL3xQTbzmYMq = DeIL3qoa2UBtYPb(xpT28sXu051(u"ࠧ࡭࡫ࡶࡸࠬ࢝"),fwNvItaL3xQTbzmYMq)
				for dict in fwNvItaL3xQTbzmYMq:
					fCXyTlcmF4WuetVork = dict[hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠨࡨ࡬ࡰࡪ࠭࢞")]
					pMAWqrwP80lR = dict[vODxLKW5Ql6r4Fbm8(u"ࠩ࡯ࡥࡧ࡫࡬ࠨ࢟")]
					ff2PjlcCF5ZWyIUbVguMz.append(fCXyTlcmF4WuetVork)
					Zw4M5DUStdE6xp7GI = F82MvyX4ThI6sbnA3efDoVS(fCXyTlcmF4WuetVork,FRYcH4KL7e9gv5pEB(u"ࠪࡲࡦࡳࡥࠨࢠ"))
					WK130YrED8vNhiHntepuXR.append(pMAWqrwP80lR+iFBmE2MUIpSu34wsd7Rf6z+Zw4M5DUStdE6xp7GI)
		elif AbqCJZdWQP9j(u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭ࢡ") in oCJ8TdG2LwSIVcbaUnhB.headers:
			fCXyTlcmF4WuetVork = oCJ8TdG2LwSIVcbaUnhB.headers[Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧࢢ")]
			ff2PjlcCF5ZWyIUbVguMz.append(fCXyTlcmF4WuetVork)
			Zw4M5DUStdE6xp7GI = F82MvyX4ThI6sbnA3efDoVS(fCXyTlcmF4WuetVork,HtK4o2sTPgA78U(u"࠭࡮ࡢ࡯ࡨࠫࢣ"))
			WK130YrED8vNhiHntepuXR.append(Zw4M5DUStdE6xp7GI)
		if UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠧࡀࡷࡵࡰࡂ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡰࡩࡱࡷࡳࡸ࠴ࡡࡱࡲ࠱࡫ࡴࡵࠧࢤ") in url:
			fCXyTlcmF4WuetVork = url.split(xpT28sXu051(u"ࠨࡁࡸࡶࡱࡃࠧࢥ"))[YYJQyRskpX8jv]
			fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork.split(y6y5HtgXO4TkUbwVZ(u"ࠩࠩࠫࢦ"))[FGTfwsjNrB8DvKSZhLIQAb1JnO]
			if fCXyTlcmF4WuetVork:
				ff2PjlcCF5ZWyIUbVguMz.append(fCXyTlcmF4WuetVork)
				WK130YrED8vNhiHntepuXR.append(ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠪࡴ࡭ࡵࡴࡰࡵࠣ࡫ࡴࡵࡧ࡭ࡧࠪࢧ"))
	else:
		ff2PjlcCF5ZWyIUbVguMz.append(url)
		Zw4M5DUStdE6xp7GI = F82MvyX4ThI6sbnA3efDoVS(url,FRYcH4KL7e9gv5pEB(u"ࠫࡳࡧ࡭ࡦࠩࢨ"))
		WK130YrED8vNhiHntepuXR.append(Zw4M5DUStdE6xp7GI)
	if not ff2PjlcCF5ZWyIUbVguMz: return tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡌࡃࡗࡏࡔ࡛ࡔࡆࠩࢩ"),[],[]
	elif len(ff2PjlcCF5ZWyIUbVguMz)==YYJQyRskpX8jv: fCXyTlcmF4WuetVork = ff2PjlcCF5ZWyIUbVguMz[FGTfwsjNrB8DvKSZhLIQAb1JnO]
	else:
		mmfrx2S5XqknFTDeRhj49LuYv1wW0 = ccv1mVPUsnr(tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"࠭รฯฬิࠤฬ๊ๅๅใࠣห้๋ๆศีหࠫࢪ"),WK130YrED8vNhiHntepuXR)
		if mmfrx2S5XqknFTDeRhj49LuYv1wW0==-YYJQyRskpX8jv: return vODxLKW5Ql6r4Fbm8(u"ࠧࡆ࡚ࡌࡘࡤࡇࡌࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬࢫ"),[],[]
		fCXyTlcmF4WuetVork = ff2PjlcCF5ZWyIUbVguMz[mmfrx2S5XqknFTDeRhj49LuYv1wW0]
	return GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫࢬ"),[iiy37aKq0pCEIOwfcTh61xb4U],[fCXyTlcmF4WuetVork]
def WjkxfB6anb3TSmEv(url):
	headers = {AbqCJZdWQP9j(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ࢭ"):MgP8OjoaiWQEVG59(u"ࠪࡏࡴࡪࡩ࠰ࠩࢮ")+str(ZD1J5rN8u2wzdgqoyULm4)}
	for o6oXFxmE1bQC in range(JZszNnIEMAx28Yao0yqhiXGKOPb(u"࠻࠰ๅ")):
		X2cQ5NCPvkMieBW7oASspFjE.sleep(yJeq1BjfiO4NFuwIEzxVLK6b9s(u"࠰࠯࠳࠳࠴ๆ"))
		oCJ8TdG2LwSIVcbaUnhB = GJqpByOKiRenb184w0(FRYcH4KL7e9gv5pEB(u"ࠫࡌࡋࡔࠨࢯ"),url,iiy37aKq0pCEIOwfcTh61xb4U,headers,BF6QAiLUNHh7rKOugaw,iiy37aKq0pCEIOwfcTh61xb4U,TlGXWLYsV1z(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡉࡒࡓࡌࡒࡅࡖࡕࡈࡖࡈࡕࡎࡕࡇࡑࡘ࠲࠷ࡳࡵࠩࢰ"))
		if ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨࢱ") in list(oCJ8TdG2LwSIVcbaUnhB.headers.keys()):
			fCXyTlcmF4WuetVork = oCJ8TdG2LwSIVcbaUnhB.headers[yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩࢲ")]
			fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork+PtkEvXAqif14G20QZsaSyT(u"ࠨࡾࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࡃࠧࢳ")+headers[Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ࢴ")]
			return iiy37aKq0pCEIOwfcTh61xb4U,[iiy37aKq0pCEIOwfcTh61xb4U],[fCXyTlcmF4WuetVork]
		if oCJ8TdG2LwSIVcbaUnhB.code!=Y41NvKfOroMzGB8sEHy7wbXlc5(u"࠵࠴࠼็"): break
	return tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡍࡏࡐࡉࡏࡉ࡚࡙ࡅࡓࡅࡒࡒ࡙ࡋࡎࡕࠩࢵ"),[],[]
def c0i9xeIUCVJkFw6L(url):
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠫࡌࡋࡔࠨࢶ"),url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡒࡋࡓ࡙ࡕࡓࡈࡑࡒࡋࡑࡋ࠭࠲ࡵࡷࠫࢷ"))
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	fCXyTlcmF4WuetVork = dEyT9xhGjolYzLCH7460w3.findall(LyNiIHPOwD3hCUYEFM7(u"࠭ࠢࠩࡪࡷࡸࡵࡹ࠺࠰࠱ࡹ࡭ࡩ࡫࡯࠮ࡦࡲࡻࡳࡲ࡯ࡢࡦࡶ࠲࠯ࡅࠩࠣ࠮࠱࠮ࡄ࠲࠮ࠫࡁ࠯ࠬ࠳࠰࠿ࠪ࠮ࠪࢸ"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if fCXyTlcmF4WuetVork:
		fCXyTlcmF4WuetVork,pMAWqrwP80lR = fCXyTlcmF4WuetVork[FGTfwsjNrB8DvKSZhLIQAb1JnO]
		return iiy37aKq0pCEIOwfcTh61xb4U,[pMAWqrwP80lR],[fCXyTlcmF4WuetVork]
	return ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡓࡌࡔ࡚ࡏࡔࡉࡒࡓࡌࡒࡅࠨࢹ"),[],[]
def Yb3dMo1ZF5(url):
	if sVzojQerUqX(u"ࠨ࠱ࡺࡩࡪࡶࡩࡴ࠱ࠪࢺ") in url:
		oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(r3rnfZ7cdxzNFebIRaLSG6B,JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠩࡊࡉ࡙࠭ࢻ"),url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,TlGXWLYsV1z(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡗࡆࡅࡌࡑࡆ࠸࠭࠲ࡵࡷࠫࢼ"))
		Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
		fCXyTlcmF4WuetVork = dEyT9xhGjolYzLCH7460w3.findall(GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡱࡶࡣ࡯࡭ࡹࡿ࠾ࠨࢽ"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if fCXyTlcmF4WuetVork: url = fCXyTlcmF4WuetVork[FGTfwsjNrB8DvKSZhLIQAb1JnO]
		else: return xpT28sXu051(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡘࡇࡆࡍࡒࡇ࠲ࠨࢾ"),[],[]
	return tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩࢿ"),[iiy37aKq0pCEIOwfcTh61xb4U],[url]
def uuAyGoxEWv7(url):
	phm0nfzAUCXHBjO7lIDSxT3eZJdc,WK130YrED8vNhiHntepuXR,ff2PjlcCF5ZWyIUbVguMz = iiy37aKq0pCEIOwfcTh61xb4U,[],[]
	if TlGXWLYsV1z(u"ࠧ࠰ࡦࡲࡻࡳࡲ࡯ࡢࡦ࠲ࠫࣀ") in url:
		oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(r3rnfZ7cdxzNFebIRaLSG6B,EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠨࡉࡈࡘࠬࣁ"),url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,BF6QAiLUNHh7rKOugaw,EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡗࡖࡊࡆ࠰࠵ࡸࡺࠧࣂ"))
		fCXyTlcmF4WuetVork = oCJ8TdG2LwSIVcbaUnhB.url
		if fCXyTlcmF4WuetVork: phm0nfzAUCXHBjO7lIDSxT3eZJdc,WK130YrED8vNhiHntepuXR,ff2PjlcCF5ZWyIUbVguMz = iiy37aKq0pCEIOwfcTh61xb4U,[iiy37aKq0pCEIOwfcTh61xb4U],[fCXyTlcmF4WuetVork]
	elif hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠪࡷࡪࡸࡶ࠾ࠩࣃ") in url:
		oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(r3rnfZ7cdxzNFebIRaLSG6B,CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠫࡌࡋࡔࠨࣄ"),url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,AbqCJZdWQP9j(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡓ࡙ࡍࡉ࠳࠲࡯ࡦࠪࣅ"))
		Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
		fCXyTlcmF4WuetVork = dEyT9xhGjolYzLCH7460w3.findall(ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"࠭࠼ࡪࡨࡵࡥࡲ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬࣆ"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if fCXyTlcmF4WuetVork: url = fCXyTlcmF4WuetVork[FGTfwsjNrB8DvKSZhLIQAb1JnO]
		else:
			fCXyTlcmF4WuetVork = dEyT9xhGjolYzLCH7460w3.findall(Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠢࡂ࡮ࡥࡥࡕࡲࡡࡺࡧࡵࡇࡴࡴࡴࡳࡱ࡯ࡠ࠭࠭ࠨ࠯ࠬࡂ࠭ࠬࠨࣇ"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
			if fCXyTlcmF4WuetVork:
				url = fCXyTlcmF4WuetVork[FGTfwsjNrB8DvKSZhLIQAb1JnO]
				url = UodGe76Lu2IHTYPxBhjk1RpcaqrM.b64decode(url)
				if J1MoiYc7ZwzKS: url = url.decode(df6QpwGxuJVZr)
			else: return SaB5hx3PZwXRLtKgrTfQvId(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡕ࡛ࡏࡄࠨࣈ"),[],[]
		phm0nfzAUCXHBjO7lIDSxT3eZJdc,WK130YrED8vNhiHntepuXR,ff2PjlcCF5ZWyIUbVguMz = FRYcH4KL7e9gv5pEB(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬࣉ"),[iiy37aKq0pCEIOwfcTh61xb4U],[url]
	else:
		oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,ZchUJdM93pTA7zG5(u"ࠪࡋࡊ࡚ࠧ࣊"),url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,y6y5HtgXO4TkUbwVZ(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡒࡘࡌࡈ࠲࠹ࡲࡥࠩ࣋"))
		Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall(EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠬࠨࡡࡱ࡮ࡵ࠱ࡲ࡫࡮ࡶࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭࣌"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if UUIohmv597bO83YCLgWS:
			PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[EMO8gy4LrsNTh0knZwpSeU75APW(u"࠲่")]
			items = dEyT9xhGjolYzLCH7460w3.findall(XrTw01KtLzbpoyMf(u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ࣍"),PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
			for fCXyTlcmF4WuetVork,title in items:
				WK130YrED8vNhiHntepuXR.append(title)
				ff2PjlcCF5ZWyIUbVguMz.append(fCXyTlcmF4WuetVork)
	return phm0nfzAUCXHBjO7lIDSxT3eZJdc,WK130YrED8vNhiHntepuXR,ff2PjlcCF5ZWyIUbVguMz
def i1tWTclz6O(url):
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(r3rnfZ7cdxzNFebIRaLSG6B,LyNiIHPOwD3hCUYEFM7(u"ࠧࡈࡇࡗࠫ࣎"),url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡋࡇࡓࡆࡎࡋࡈ࠶࠳࠱ࡴࡶ࣏ࠪ"))
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	Vxz6OndPIX4g2kaRp7 = zJ1OjtAFPhK85MY2p7ZmVBowxgS(Vxz6OndPIX4g2kaRp7)
	fCXyTlcmF4WuetVork = dEyT9xhGjolYzLCH7460w3.findall(TlGXWLYsV1z(u"ࠩࠥࡪ࡮ࡲࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࣐ࠪ"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if fCXyTlcmF4WuetVork: return iiy37aKq0pCEIOwfcTh61xb4U,[iiy37aKq0pCEIOwfcTh61xb4U],[fCXyTlcmF4WuetVork[FGTfwsjNrB8DvKSZhLIQAb1JnO]]
	return ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡌࡁࡔࡇࡏࡌࡉ࠷࣑ࠧ"),[],[]
def WWA4uXG7hb(url):
	if len(url)>FRYcH4KL7e9gv5pEB(u"࠵࠴࠵้"):
		url = url.strip(TlGXWLYsV1z(u"ࠫ࠴࣒࠭"))+L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠬ࠵࣓ࠧ")
		oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(r3rnfZ7cdxzNFebIRaLSG6B,vODxLKW5Ql6r4Fbm8(u"࠭ࡇࡆࡖࠪࣔ"),url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡐࡆࡘࡏ࡛ࡃ࠰࠵ࡸࡺࠧࣕ"))
		Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
		if FGTfwsjNrB8DvKSZhLIQAb1JnO and PtkEvXAqif14G20QZsaSyT(u"ࠨࡨࡸࡲࡨࡺࡩࡰࡰࠫ࡬࠱ࡻࠬ࡯࠮ࡷ࠰ࡪ࠲ࡲࠪࠩࣖ") in Vxz6OndPIX4g2kaRp7:
			UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall(CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠩࠥࡰࡴࡧࡤࡦࡴࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨࣗ"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
			if UUIohmv597bO83YCLgWS:
				PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[HtK4o2sTPgA78U(u"࠴๊")]
				UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall(CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠪࡀࡸࡩࡲࡪࡲࡷࡂࡻࡧࡲࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡥࡵ࡭ࡵࡺࠧࣘ"),PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
				if UUIohmv597bO83YCLgWS:
					PPH1sQtTkDBbnlYpZfo5 = D5oyMb7NTziWkrqPG(UUIohmv597bO83YCLgWS[IpC4qHXRuyNFjzWv(u"࠵๋")])
		elif len(Vxz6OndPIX4g2kaRp7)<yJeq1BjfiO4NFuwIEzxVLK6b9s(u"࠺࠰࠱์"): fCXyTlcmF4WuetVork = Vxz6OndPIX4g2kaRp7
		else: return tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡌࡂࡔࡒ࡞ࡆ࠭ࣙ"),[],[]
		return tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠬ࠭ࣚ"),[iiy37aKq0pCEIOwfcTh61xb4U],[fCXyTlcmF4WuetVork]
	return ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩࣛ"),[iiy37aKq0pCEIOwfcTh61xb4U],[url]
def CJPfXMgbsv(url):
	if hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠧ࠰ࡦࡲࡻࡳ࠴ࡰࡩࡲࠪࣜ") in url:
		oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(r3rnfZ7cdxzNFebIRaLSG6B,uuExaKGL7UONtevRd(u"ࠨࡉࡈࡘࠬࣝ"),url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡙ࡈࡐࡈࡋࡅ࠲࠷ࡳࡵࠩࣞ"))
		Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
		fCXyTlcmF4WuetVork = dEyT9xhGjolYzLCH7460w3.findall(FRYcH4KL7e9gv5pEB(u"ࠪࡺ࡮ࡪࡥࡰ࠯ࡺࡶࡦࡶࡰࡦࡴ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫࣟ"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		url = fCXyTlcmF4WuetVork[FGTfwsjNrB8DvKSZhLIQAb1JnO]
	return uuExaKGL7UONtevRd(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ࣠"),[iiy37aKq0pCEIOwfcTh61xb4U],[url]
def WYuiCFZ3mU(url):
	if EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠬࡹࡥࡳࡸࡨࡶ࠳ࡶࡨࡱࠩ࣡") in url:
		oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(r3rnfZ7cdxzNFebIRaLSG6B,EMO8gy4LrsNTh0knZwpSeU75APW(u"࠭ࡇࡆࡖࠪ࣢"),url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,jXE2YHkswT8y(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡇࡎࡓࡁ࠵ࡗ࠰࠵ࡸࡺࣣࠧ"))
		Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
		fCXyTlcmF4WuetVork = dEyT9xhGjolYzLCH7460w3.findall(xpT28sXu051(u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࣤ"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork[FGTfwsjNrB8DvKSZhLIQAb1JnO]
		if uuExaKGL7UONtevRd(u"ࠩ࡫ࡸࡹࡶࠧࣥ") in fCXyTlcmF4WuetVork: return YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘࣦ࠭"),[iiy37aKq0pCEIOwfcTh61xb4U],[fCXyTlcmF4WuetVork]
		return zmcGfOdvAjsELeJlP(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡃࡊࡏࡄ࠸࡚࠭ࣧ"),[],[]
	return JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨࣨ"),[iiy37aKq0pCEIOwfcTh61xb4U],[url]
def pfObhokENe(url):
	eCGwzSrqBmIv,EwsmJ67cCYDIlg = sFNjagPK4W(url)
	rzR9SN7ApZuQhTDWEX3V6ga = {IpC4qHXRuyNFjzWv(u"࠭ࡘ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡧࡧ࠱࡜࡯ࡴࡩࣩࠩ"):JZszNnIEMAx28Yao0yqhiXGKOPb(u"࡙ࠧࡏࡏࡌࡹࡺࡰࡓࡧࡴࡹࡪࡹࡴࠨ࣪"),JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ࣫"):zmcGfOdvAjsELeJlP(u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤ࠼ࠢࡦ࡬ࡦࡸࡳࡦࡶࡀ࡙࡙ࡌ࠭࠹ࠩ࣬")}
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,FRYcH4KL7e9gv5pEB(u"ࠪࡔࡔ࡙ࡔࠨ࣭"),eCGwzSrqBmIv,EwsmJ67cCYDIlg,rzR9SN7ApZuQhTDWEX3V6ga,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,y6y5HtgXO4TkUbwVZ(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆࡉ࡜ࡒࡔ࡝࠭࠲ࡵࡷ࣮ࠫ"))
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	fCXyTlcmF4WuetVork = dEyT9xhGjolYzLCH7460w3.findall(hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࣯ࠪ"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if not fCXyTlcmF4WuetVork: return Y41NvKfOroMzGB8sEHy7wbXlc5(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡇࡊ࡝ࡓࡕࡗࠨࣰ"),[],[]
	fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork[FGTfwsjNrB8DvKSZhLIQAb1JnO]
	return ZchUJdM93pTA7zG5(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࣱࠪ"),[iiy37aKq0pCEIOwfcTh61xb4U],[fCXyTlcmF4WuetVork]
def NeR5gq8kfL(url):
	headers = {JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠨ࡚࠰ࡖࡪࡷࡵࡦࡵࡷࡩࡩ࠳ࡗࡪࡶ࡫ࣲࠫ"):hhQwbeiNLoqFjX90fB7aG8VAs(u"࡛ࠩࡑࡑࡎࡴࡵࡲࡕࡩࡶࡻࡥࡴࡶࠪࣳ")}
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,LyNiIHPOwD3hCUYEFM7(u"ࠪࡋࡊ࡚ࠧࣴ"),url,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡔࡊࡒࡓࡋࡖࡒࡐ࠯࠴ࡷࡹ࠭ࣵ"))
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	fCXyTlcmF4WuetVork = dEyT9xhGjolYzLCH7460w3.findall(zmcGfOdvAjsELeJlP(u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࣶࠪ"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL|dEyT9xhGjolYzLCH7460w3.IGNORECASE)
	if not fCXyTlcmF4WuetVork: return AbqCJZdWQP9j(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡕࡋࡓࡔࡌࡐࡓࡑࠪࣷ"),[],[]
	fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork[FGTfwsjNrB8DvKSZhLIQAb1JnO]
	return TlGXWLYsV1z(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪࣸ"),[iiy37aKq0pCEIOwfcTh61xb4U],[fCXyTlcmF4WuetVork]
def B0BLI6vrM7(url):
	eCGwzSrqBmIv,EwsmJ67cCYDIlg = sFNjagPK4W(url)
	rzR9SN7ApZuQhTDWEX3V6ga = {GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࣹࠧ"):TlGXWLYsV1z(u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤ࠼ࠢࡦ࡬ࡦࡸࡳࡦࡶࡀ࡙࡙ࡌ࠭࠹ࣺࠩ")}
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠪࡔࡔ࡙ࡔࠨࣻ"),eCGwzSrqBmIv,EwsmJ67cCYDIlg,rzR9SN7ApZuQhTDWEX3V6ga,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡉࡃࡏࡅࡈࡏࡍࡂ࠯࠴ࡷࡹ࠭ࣼ"))
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	fCXyTlcmF4WuetVork = dEyT9xhGjolYzLCH7460w3.findall(SaB5hx3PZwXRLtKgrTfQvId(u"ࠬ࠭ࠧ࠽࡫ࡩࡶࡦࡳࡥࠡࡵࡵࡧࡂࡡࠢࠨ࡟ࠫ࠲࠯ࡅࠩ࡜ࠤࠪࡡࠬ࠭ࠧࣽ"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL|dEyT9xhGjolYzLCH7460w3.IGNORECASE)
	if not fCXyTlcmF4WuetVork: return ZchUJdM93pTA7zG5(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡊࡄࡐࡆࡉࡉࡎࡃࠪࣾ"),[],[]
	fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork[FGTfwsjNrB8DvKSZhLIQAb1JnO]
	if SaB5hx3PZwXRLtKgrTfQvId(u"ࠧࡩࡶࡷࡴࠬࣿ") not in fCXyTlcmF4WuetVork: fCXyTlcmF4WuetVork = sVzojQerUqX(u"ࠨࡪࡷࡸࡵࡀࠧऀ")+fCXyTlcmF4WuetVork
	return UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬँ"),[iiy37aKq0pCEIOwfcTh61xb4U],[fCXyTlcmF4WuetVork]
def MlFkyhP502(url):
	hx0dU3Ki7AyEfkSZY6TmN2BwtX,WK130YrED8vNhiHntepuXR,ff2PjlcCF5ZWyIUbVguMz = url,[],[]
	if tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠪ࠳ࡦࡰࡡࡹ࠱ࠪं") in url:
		eCGwzSrqBmIv,EwsmJ67cCYDIlg = sFNjagPK4W(url)
		rzR9SN7ApZuQhTDWEX3V6ga = {FRYcH4KL7e9gv5pEB(u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪः"):YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧ࠿ࠥࡩࡨࡢࡴࡶࡩࡹࡃࡕࡕࡈ࠰࠼ࠬऄ")}
		oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,uuExaKGL7UONtevRd(u"࠭ࡐࡐࡕࡗࠫअ"),eCGwzSrqBmIv,EwsmJ67cCYDIlg,rzR9SN7ApZuQhTDWEX3V6ga,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,HtK4o2sTPgA78U(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡇࡎࡓࡁࡂࡄࡇࡓ࠲࠷ࡳࡵࠩआ"))
		Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
		sVKiT85bQpO2N9HAgZxELrfcB0SeG = dEyT9xhGjolYzLCH7460w3.findall(SaB5hx3PZwXRLtKgrTfQvId(u"ࠨࠩࠪࡀ࡮࡬ࡲࡢ࡯ࡨ࠲࠯ࡅࡳࡳࡥࡀ࡟ࠧ࠭࡝ࠩ࠰࠭ࡃ࠮ࡡࠢࠨ࡟ࠪࠫࠬइ"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL|dEyT9xhGjolYzLCH7460w3.IGNORECASE)
		if sVKiT85bQpO2N9HAgZxELrfcB0SeG: hx0dU3Ki7AyEfkSZY6TmN2BwtX = sVKiT85bQpO2N9HAgZxELrfcB0SeG[FGTfwsjNrB8DvKSZhLIQAb1JnO]
	return XrTw01KtLzbpoyMf(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬई"),[iiy37aKq0pCEIOwfcTh61xb4U],[hx0dU3Ki7AyEfkSZY6TmN2BwtX]
def V18kA4epvm(url):
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,xpT28sXu051(u"ࠪࡋࡊ࡚ࠧउ"),url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡕࡘࡉ࡙ࡓ࠳࠱ࡴࡶࠪऊ"))
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	hPIQV0bUN8aDALk3ivt1qy2c9gwjrH = dEyT9xhGjolYzLCH7460w3.findall(LyNiIHPOwD3hCUYEFM7(u"ࠧࡼࡡࡳࠢࡩࡷࡪࡸࡶࠡ࠿࠱࠮ࡄ࠭ࠨ࠯ࠬࡂ࠭ࠬࠨऋ"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL|dEyT9xhGjolYzLCH7460w3.IGNORECASE)
	if hPIQV0bUN8aDALk3ivt1qy2c9gwjrH:
		hPIQV0bUN8aDALk3ivt1qy2c9gwjrH = hPIQV0bUN8aDALk3ivt1qy2c9gwjrH[FGTfwsjNrB8DvKSZhLIQAb1JnO][CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"࠲ํ"):]
		hPIQV0bUN8aDALk3ivt1qy2c9gwjrH = UodGe76Lu2IHTYPxBhjk1RpcaqrM.b64decode(hPIQV0bUN8aDALk3ivt1qy2c9gwjrH)
		if J1MoiYc7ZwzKS: hPIQV0bUN8aDALk3ivt1qy2c9gwjrH = hPIQV0bUN8aDALk3ivt1qy2c9gwjrH.decode(df6QpwGxuJVZr)
		fCXyTlcmF4WuetVork = dEyT9xhGjolYzLCH7460w3.findall(MgP8OjoaiWQEVG59(u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫऌ"),hPIQV0bUN8aDALk3ivt1qy2c9gwjrH,dEyT9xhGjolYzLCH7460w3.DOTALL)
	else: fCXyTlcmF4WuetVork = iiy37aKq0pCEIOwfcTh61xb4U
	if not fCXyTlcmF4WuetVork: return FRYcH4KL7e9gv5pEB(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡗ࡚ࡋ࡛ࡎࠨऍ"),[],[]
	fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork[FGTfwsjNrB8DvKSZhLIQAb1JnO]
	if L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠨࡪࡷࡸࡵ࠭ऎ") not in fCXyTlcmF4WuetVork: fCXyTlcmF4WuetVork = Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠩ࡫ࡸࡹࡶ࠺ࠨए")+fCXyTlcmF4WuetVork
	return LyNiIHPOwD3hCUYEFM7(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ऐ"),[iiy37aKq0pCEIOwfcTh61xb4U],[fCXyTlcmF4WuetVork]
def BFJ2rvblqP1oSXI0L(url):
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(r3rnfZ7cdxzNFebIRaLSG6B,ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠫࡌࡋࡔࠨऑ"),url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡏ࡜ࡉࡌ࡟ࡖࡊࡒ࠰࠵ࡸࡺࠧऒ"))
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	fCXyTlcmF4WuetVork = dEyT9xhGjolYzLCH7460w3.findall(uuExaKGL7UONtevRd(u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡣࡰ࡮࠰ࡷࡲ࠳࠱࠳ࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫओ"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if not fCXyTlcmF4WuetVork: return tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡐ࡝ࡊࡍ࡙ࡗࡋࡓࠫऔ"),[],[]
	fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork[FGTfwsjNrB8DvKSZhLIQAb1JnO]
	return LyNiIHPOwD3hCUYEFM7(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫक"),[iiy37aKq0pCEIOwfcTh61xb4U],[fCXyTlcmF4WuetVork]
def LATecKt1Ra(url):
	id = url.split(JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠩ࠲ࠫख"))[-xpT28sXu051(u"࠲๎")]
	if hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠪ࠳ࡪࡳࡢࡦࡦࠪग") in url: url = url.replace(Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠫ࠴࡫࡭ࡣࡧࡧࠫघ"),iiy37aKq0pCEIOwfcTh61xb4U)
	url = url.replace(ZchUJdM93pTA7zG5(u"ࠬ࠴ࡣࡰ࡯࠲ࠫङ"),L90uqo28xEKSFUwYTcm51yRWZIkft(u"࠭࠮ࡤࡱࡰ࠳ࡵࡲࡡࡺࡧࡵ࠳ࡲ࡫ࡴࡢࡦࡤࡸࡦ࠵ࠧच"))
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(r3rnfZ7cdxzNFebIRaLSG6B,hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠧࡈࡇࡗࠫछ"),url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,y6y5HtgXO4TkUbwVZ(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯࠴ࡷࡹ࠭ज"))
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	phm0nfzAUCXHBjO7lIDSxT3eZJdc = vODxLKW5Ql6r4Fbm8(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏࠩझ")
	IIwlEFYZdnU6Seizqv1C3ct = dEyT9xhGjolYzLCH7460w3.findall(SaB5hx3PZwXRLtKgrTfQvId(u"ࠪࠦࡪࡸࡲࡰࡴࠥ࠲࠯ࡅࠢ࡮ࡧࡶࡷࡦ࡭ࡥࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫञ"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if IIwlEFYZdnU6Seizqv1C3ct: phm0nfzAUCXHBjO7lIDSxT3eZJdc = IIwlEFYZdnU6Seizqv1C3ct[FGTfwsjNrB8DvKSZhLIQAb1JnO]
	url = dEyT9xhGjolYzLCH7460w3.findall(ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠫࡽ࠳࡭ࡱࡧࡪ࡙ࡗࡒࠢ࠭ࠤࡸࡶࡱࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨट"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if not url and phm0nfzAUCXHBjO7lIDSxT3eZJdc:
		return phm0nfzAUCXHBjO7lIDSxT3eZJdc,[],[]
	fCXyTlcmF4WuetVork = url[FGTfwsjNrB8DvKSZhLIQAb1JnO].replace(hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠬࡢ࡜ࠨठ"),iiy37aKq0pCEIOwfcTh61xb4U)
	hTokmyvgtKG,j6P7d92fziHV3s = VKTp8gacXPG9Zr4H3NQCM0O(sQU2GnRoMwLK8CBdfzmNr4jXyO,fCXyTlcmF4WuetVork)
	LsjrhQpZKcn41EyDwlFBm0IYtX = OXsckY7RzjCag9A.getSetting(yJeq1BjfiO4NFuwIEzxVLK6b9s(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡥ࡭ࡹࡸࡡࡵࡧࠪड"))
	if LsjrhQpZKcn41EyDwlFBm0IYtX and FRYcH4KL7e9gv5pEB(u"ࠧ࠮ࠩढ") not in LsjrhQpZKcn41EyDwlFBm0IYtX: title,fCXyTlcmF4WuetVork = hTokmyvgtKG[JZszNnIEMAx28Yao0yqhiXGKOPb(u"࠲๏")],j6P7d92fziHV3s[JZszNnIEMAx28Yao0yqhiXGKOPb(u"࠲๏")]
	else:
		w3Ocz1JhkdGN6MartBi82mHxpsW = dEyT9xhGjolYzLCH7460w3.findall(sVzojQerUqX(u"ࠨࠤࡲࡻࡳ࡫ࡲࠣ࠼࡟ࡿࠧ࡯ࡤࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࠨࡳࡤࡴࡨࡩࡳࡴࡡ࡮ࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠱ࠨࡵࡳ࡮ࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬण"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if w3Ocz1JhkdGN6MartBi82mHxpsW: eebXUiEaHWV4dvxmsonkq,eojfzVLctg6FpJYs,owGhzDaBXx2VgA0M = w3Ocz1JhkdGN6MartBi82mHxpsW[FGTfwsjNrB8DvKSZhLIQAb1JnO]
		else: eebXUiEaHWV4dvxmsonkq,eojfzVLctg6FpJYs,owGhzDaBXx2VgA0M = iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U
		owGhzDaBXx2VgA0M = owGhzDaBXx2VgA0M.replace(Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠩ࡟࠳ࠬत"),GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠪ࠳ࠬथ"))
		eojfzVLctg6FpJYs = vvmT3DLXkhPBwIaOAo6srZpEnRVJC(eojfzVLctg6FpJYs)
		A7Ap2wdlxM = [PSwfZcdRYhpl5Igqz8xOEk67+UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠫࡔ࡝ࡎࡆࡔ࠽ࠤࠥ࠭द")+eojfzVLctg6FpJYs+YoQW601K4fMJcsreDnGVE5wUZIy7]+hTokmyvgtKG
		duef0gb3Mi1AV5WpN8 = [owGhzDaBXx2VgA0M]+j6P7d92fziHV3s
		mmfrx2S5XqknFTDeRhj49LuYv1wW0 = ccv1mVPUsnr(PtkEvXAqif14G20QZsaSyT(u"ࠬอฮหำࠣห้๋ไโࠢส่๊์วิส࠽ࠤ࠭࠭ध")+str(len(duef0gb3Mi1AV5WpN8)-tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"࠴๐"))+tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"࠭ࠠๆๆไ࠭ࠬन"),A7Ap2wdlxM)
		if mmfrx2S5XqknFTDeRhj49LuYv1wW0==-YYJQyRskpX8jv: return ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠧࡆ࡚ࡌࡘࡤࡇࡌࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬऩ"),[],[]
		elif mmfrx2S5XqknFTDeRhj49LuYv1wW0==FGTfwsjNrB8DvKSZhLIQAb1JnO:
			a6zqTCpFUns = ytv0YaxDcRINurplWKg587Pwqz.argv[FGTfwsjNrB8DvKSZhLIQAb1JnO]+XrTw01KtLzbpoyMf(u"ࠨࡁࡷࡽࡵ࡫࠽ࡧࡱ࡯ࡨࡪࡸࠦ࡮ࡱࡧࡩࡂ࠺࠰࠳ࠨࡸࡶࡱࡃࠧप")+owGhzDaBXx2VgA0M+XrTw01KtLzbpoyMf(u"ࠩࠩࡸࡪࡾࡴࡵ࠿ࠪफ")+eojfzVLctg6FpJYs
			WwMgozBIC32n9d0tyfp.executebuiltin(HtK4o2sTPgA78U(u"ࠥࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡕࡱࡦࡤࡸࡪ࠮ࠢब")+a6zqTCpFUns+YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠦ࠮ࠨभ"))
			return MgP8OjoaiWQEVG59(u"ࠬࡋࡘࡊࡖࡢࡅࡑࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪम"),[],[]
		title,fCXyTlcmF4WuetVork = A7Ap2wdlxM[mmfrx2S5XqknFTDeRhj49LuYv1wW0],duef0gb3Mi1AV5WpN8[mmfrx2S5XqknFTDeRhj49LuYv1wW0]
	return iiy37aKq0pCEIOwfcTh61xb4U,[title],[fCXyTlcmF4WuetVork]
def sZEufTSeXb(fCXyTlcmF4WuetVork):
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(r3rnfZ7cdxzNFebIRaLSG6B,jXE2YHkswT8y(u"࠭ࡇࡆࡖࠪय"),fCXyTlcmF4WuetVork,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡆࡔࡑࡒࡂ࠯࠴ࡷࡹ࠭र"))
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	if CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠨ࠰࡭ࡷࡴࡴࠧऱ") in fCXyTlcmF4WuetVork: url = dEyT9xhGjolYzLCH7460w3.findall(uuExaKGL7UONtevRd(u"ࠩࠥࡷࡷࡩࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩल"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	else: url = dEyT9xhGjolYzLCH7460w3.findall(TlGXWLYsV1z(u"ࠪࡷࡴࡻࡲࡤࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨळ"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if not url: return tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡂࡐࡍࡕࡅࠬऴ"),[],[]
	url = url[FGTfwsjNrB8DvKSZhLIQAb1JnO]
	if EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠬ࡮ࡴࡵࡲࠪव") not in url: url = IpC4qHXRuyNFjzWv(u"࠭ࡨࡵࡶࡳ࠾ࠬश")+url
	return iiy37aKq0pCEIOwfcTh61xb4U,[iiy37aKq0pCEIOwfcTh61xb4U],[url]
def R4xVvt2TlcrnYW8(url):
	headers = { Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫष") : iiy37aKq0pCEIOwfcTh61xb4U }
	if XrTw01KtLzbpoyMf(u"ࠨࡱࡳࡁࡩࡵࡷ࡯࡮ࡲࡥࡩࡥ࡯ࡳ࡫ࡪࠫस") in url:
		Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(r3rnfZ7cdxzNFebIRaLSG6B,url,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡓࡏࡔࡊࡄࡌࡉࡇ࠭࠲ࡵࡷࠫह"))
		items = dEyT9xhGjolYzLCH7460w3.findall(tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠪࡨ࡮ࡸࡥࡤࡶࠣࡰ࡮ࡴ࡫࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩऺ"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if items: return iiy37aKq0pCEIOwfcTh61xb4U,[iiy37aKq0pCEIOwfcTh61xb4U],[items[FGTfwsjNrB8DvKSZhLIQAb1JnO]]
		else:
			aZtYlicqMKUFPkBCX2AONHwJ4 = dEyT9xhGjolYzLCH7460w3.findall(MgP8OjoaiWQEVG59(u"ࠫࡨࡲࡡࡴࡵࡀࠦࡪࡸࡲࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩऻ"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
			if aZtYlicqMKUFPkBCX2AONHwJ4:
				bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่์็฿ࠠศๆสู้๐़ࠧ"),aZtYlicqMKUFPkBCX2AONHwJ4[FGTfwsjNrB8DvKSZhLIQAb1JnO])
				return SaB5hx3PZwXRLtKgrTfQvId(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࠧऽ")+aZtYlicqMKUFPkBCX2AONHwJ4[FGTfwsjNrB8DvKSZhLIQAb1JnO],[],[]
	else:
		ccgt6lhpXynUR79P5ev = MgP8OjoaiWQEVG59(u"ࠧ࡮ࡱࡹ࡭ࡿࡲࡡ࡯ࡦࠪा")
		Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(r3rnfZ7cdxzNFebIRaLSG6B,url,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,ZchUJdM93pTA7zG5(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡒࡕࡓࡉࡃࡋࡈࡆ࠳࠲࡯ࡦࠪि"))
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall(sVzojQerUqX(u"ࠩࡉࡳࡷࡳࠠ࡮ࡧࡷ࡬ࡴࡪ࠽ࠣࡒࡒࡗ࡙ࠨࠠࡢࡥࡷ࡭ࡴࡴ࠽࡝ࠩࠫ࠲࠯ࡅࠩ࡝ࠩࠫ࠲࠯ࡅࠩࡥ࡫ࡹࠫी"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if not UUIohmv597bO83YCLgWS: return FRYcH4KL7e9gv5pEB(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡓࡏࡔࡊࡄࡌࡉࡇࠧु"),[],[]
		hx0dU3Ki7AyEfkSZY6TmN2BwtX = UUIohmv597bO83YCLgWS[FGTfwsjNrB8DvKSZhLIQAb1JnO][FGTfwsjNrB8DvKSZhLIQAb1JnO]
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[FGTfwsjNrB8DvKSZhLIQAb1JnO][YYJQyRskpX8jv]
		if LyNiIHPOwD3hCUYEFM7(u"ࠫ࠳ࡸࡡࡳࠩू") in PPH1sQtTkDBbnlYpZfo5 or LyNiIHPOwD3hCUYEFM7(u"ࠬ࠴ࡺࡪࡲࠪृ") in PPH1sQtTkDBbnlYpZfo5: return hhQwbeiNLoqFjX90fB7aG8VAs(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡍࡐࡕࡋࡅࡍࡊࡁࠡࡐࡲࡸࠥࡧࠠࡷ࡫ࡧࡩࡴࠦࡦࡪ࡮ࡨࠫॄ"),[],[]
		items = dEyT9xhGjolYzLCH7460w3.findall(ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠧ࡯ࡣࡰࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡸࡤࡰࡺ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨॅ"),PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		Si4j3bXGLeno0zfxlm9ZOcy = {}
		for JJwnocyLUxHI2jlKF4Y,aasX2cby4Vo5rTgB in items:
			Si4j3bXGLeno0zfxlm9ZOcy[JJwnocyLUxHI2jlKF4Y] = aasX2cby4Vo5rTgB
		data = zzUnMebTFdNgB8hOwJmKxVj(Si4j3bXGLeno0zfxlm9ZOcy)
		Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(r3rnfZ7cdxzNFebIRaLSG6B,hx0dU3Ki7AyEfkSZY6TmN2BwtX,data,headers,iiy37aKq0pCEIOwfcTh61xb4U,uuExaKGL7UONtevRd(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡒࡕࡓࡉࡃࡋࡈࡆ࠳࠳ࡳࡦࠪॆ"))
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall(XrTw01KtLzbpoyMf(u"ࠩࡇࡳࡼࡴ࡬ࡰࡣࡧࠤ࡛࡯ࡤࡦࡱ࠱࠮ࡄ࡭ࡥࡵ࡞ࠫࡠࠬ࠮࠮ࠫࡁࠬࡠࠬ࠴ࠪࡀࡵࡲࡹࡷࡩࡥࡴ࠼ࠫ࠲࠯ࡅࠩࡪ࡯ࡤ࡫ࡪࡀࠧे"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if not UUIohmv597bO83YCLgWS: return ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡓࡏࡔࡊࡄࡌࡉࡇࠧै"),[],[]
		download = UUIohmv597bO83YCLgWS[FGTfwsjNrB8DvKSZhLIQAb1JnO][FGTfwsjNrB8DvKSZhLIQAb1JnO]
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[FGTfwsjNrB8DvKSZhLIQAb1JnO][YYJQyRskpX8jv]
		items = dEyT9xhGjolYzLCH7460w3.findall(tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠫ࡫࡯࡬ࡦ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠫ࠰ࡱࡧࡢࡦ࡮࠽ࠦ࠳࠰࠿ࠣࡾࠬࠫॉ"),PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		Dz1CNgS8XGrx6YWuORlUefQB,A7Ap2wdlxM,x8x42QwarFnvlhNmDXpLiUWtPyRqgj,duef0gb3Mi1AV5WpN8,qqn2LF8jeYrpQUCw7SNvhJ0ODTR1l = [],[],[],[],[]
		for fCXyTlcmF4WuetVork,title in items:
			if uuExaKGL7UONtevRd(u"ࠬ࠴࡭࠴ࡷ࠻ࠫॊ") in fCXyTlcmF4WuetVork:
				Dz1CNgS8XGrx6YWuORlUefQB,x8x42QwarFnvlhNmDXpLiUWtPyRqgj = VKTp8gacXPG9Zr4H3NQCM0O(sQU2GnRoMwLK8CBdfzmNr4jXyO,fCXyTlcmF4WuetVork)
				duef0gb3Mi1AV5WpN8 = duef0gb3Mi1AV5WpN8 + x8x42QwarFnvlhNmDXpLiUWtPyRqgj
				if Dz1CNgS8XGrx6YWuORlUefQB[FGTfwsjNrB8DvKSZhLIQAb1JnO]==tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"࠭࠭࠲ࠩो"): A7Ap2wdlxM.append(YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠧࠡีํีๆืࠠฯษุࠤࠬौ")+LyNiIHPOwD3hCUYEFM7(u"ࠨ࡯࠶ࡹ࠽्ࠦࠧ")+ccgt6lhpXynUR79P5ev)
				else:
					for title in Dz1CNgS8XGrx6YWuORlUefQB:
						A7Ap2wdlxM.append(GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠩࠣื๏ืแาࠢัหฺࠦࠧॎ")+CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠪࡱ࠸ࡻ࠸ࠡࠩॏ")+ccgt6lhpXynUR79P5ev+iFBmE2MUIpSu34wsd7Rf6z+title)
			else:
				title = title.replace(sVzojQerUqX(u"ࠫ࠱ࡲࡡࡣࡧ࡯࠾ࠧ࠭ॐ"),iiy37aKq0pCEIOwfcTh61xb4U)
				title = title.strip(XrTw01KtLzbpoyMf(u"ࠬࠨࠧ॑"))
				title = Y41NvKfOroMzGB8sEHy7wbXlc5(u"࠭ࠠิ์ิๅึࠦࠠฯษุࠤ॒ࠬ")+ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠧࠡ࡯ࡳ࠸ࠥ࠭॓")+ccgt6lhpXynUR79P5ev+iFBmE2MUIpSu34wsd7Rf6z+title
				A7Ap2wdlxM.append(title)
				duef0gb3Mi1AV5WpN8.append(fCXyTlcmF4WuetVork)
		fCXyTlcmF4WuetVork = XrTw01KtLzbpoyMf(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡯ࡲࡷ࡭ࡧࡨࡥࡣ࠱ࡳࡳࡲࡩ࡯ࡧࠪ॔") + download
		Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(r3rnfZ7cdxzNFebIRaLSG6B,fCXyTlcmF4WuetVork,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,PtkEvXAqif14G20QZsaSyT(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡓࡏࡔࡊࡄࡌࡉࡇ࠭࠶ࡶ࡫ࠫॕ"))
		items = dEyT9xhGjolYzLCH7460w3.findall(zmcGfOdvAjsELeJlP(u"ࠥࡨࡴࡽ࡮࡭ࡱࡤࡨࡤࡼࡩࡥࡧࡲࡠ࠭࠭ࠨ࠯ࠬࡂ࠭ࠬ࠲ࠧࠩ࠰࠭ࡃ࠮࠭ࠬࠨࠪ࠱࠮ࡄ࠯ࠧ࠯ࠬࡂࡀࡹࡪ࠾ࠩ࠰࠭ࡃ࠮࠲ࠢॖ"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for id,Cpf9s3c0Zngj7XE,hash,T27hnaIAydbzjRU93v5FBtfPGXQp in items:
			title = vODxLKW5Ql6r4Fbm8(u"ู๊ࠫࠥาใิࠤฯำๅ๋ๆࠣาฬ฻ࠠࠨॗ")+Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠬࠦ࡭ࡱ࠶ࠣࠫक़")+ccgt6lhpXynUR79P5ev+iFBmE2MUIpSu34wsd7Rf6z+T27hnaIAydbzjRU93v5FBtfPGXQp.split(uuExaKGL7UONtevRd(u"࠭ࡸࠨख़"))[YYJQyRskpX8jv]
			fCXyTlcmF4WuetVork = tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡮ࡱࡶ࡬ࡦ࡮ࡤࡢ࠰ࡲࡲࡱ࡯࡮ࡦ࠱ࡧࡰࡄࡵࡰ࠾ࡦࡲࡻࡳࡲ࡯ࡢࡦࡢࡳࡷ࡯ࡧࠧ࡫ࡧࡁࠬग़")+id+FRYcH4KL7e9gv5pEB(u"ࠨࠨࡰࡳࡩ࡫࠽ࠨज़")+Cpf9s3c0Zngj7XE+FRYcH4KL7e9gv5pEB(u"ࠩࠩ࡬ࡦࡹࡨ࠾ࠩड़")+hash
			qqn2LF8jeYrpQUCw7SNvhJ0ODTR1l.append(T27hnaIAydbzjRU93v5FBtfPGXQp)
			A7Ap2wdlxM.append(title)
			duef0gb3Mi1AV5WpN8.append(fCXyTlcmF4WuetVork)
		qqn2LF8jeYrpQUCw7SNvhJ0ODTR1l = set(qqn2LF8jeYrpQUCw7SNvhJ0ODTR1l)
		Jv4BN0UXbFxo1pMj,fKtVWcmL6bisq = [],[]
		for title in A7Ap2wdlxM:
			IUudCk6KnAmtv9ZlHsN1S = dEyT9xhGjolYzLCH7460w3.findall(LyNiIHPOwD3hCUYEFM7(u"ࠥࠤ࠭ࡢࡤࠫࡺࡿࡠࡩ࠰ࠩࠧࠨࠥढ़"),title+MgP8OjoaiWQEVG59(u"ࠫࠫࠬࠧफ़"),dEyT9xhGjolYzLCH7460w3.DOTALL)
			for T27hnaIAydbzjRU93v5FBtfPGXQp in qqn2LF8jeYrpQUCw7SNvhJ0ODTR1l:
				if IUudCk6KnAmtv9ZlHsN1S[FGTfwsjNrB8DvKSZhLIQAb1JnO] in T27hnaIAydbzjRU93v5FBtfPGXQp:
					title = title.replace(IUudCk6KnAmtv9ZlHsN1S[FGTfwsjNrB8DvKSZhLIQAb1JnO],T27hnaIAydbzjRU93v5FBtfPGXQp.split(yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠬࡾࠧय़"))[YYJQyRskpX8jv])
			Jv4BN0UXbFxo1pMj.append(title)
		for iEfNKT3velFyGth80SA4pxbCRrVD in range(len(duef0gb3Mi1AV5WpN8)):
			items = dEyT9xhGjolYzLCH7460w3.findall(tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠨࠦࠧࠪ࠱࠮ࡄ࠯ࠨ࡝ࡦ࠭࠭ࠫࠬࠢॠ"),GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠧࠧࠨࠪॡ")+Jv4BN0UXbFxo1pMj[iEfNKT3velFyGth80SA4pxbCRrVD]+XrTw01KtLzbpoyMf(u"ࠨࠨࠩࠫॢ"),dEyT9xhGjolYzLCH7460w3.DOTALL)
			fKtVWcmL6bisq.append( [Jv4BN0UXbFxo1pMj[iEfNKT3velFyGth80SA4pxbCRrVD],duef0gb3Mi1AV5WpN8[iEfNKT3velFyGth80SA4pxbCRrVD],items[FGTfwsjNrB8DvKSZhLIQAb1JnO][FGTfwsjNrB8DvKSZhLIQAb1JnO],items[FGTfwsjNrB8DvKSZhLIQAb1JnO][YYJQyRskpX8jv]] )
		fKtVWcmL6bisq = sorted(fKtVWcmL6bisq, key=lambda noUVir5wOMbjdfKH1RCxIYhSPAqTWu: noUVir5wOMbjdfKH1RCxIYhSPAqTWu[iiCWLaJREureAlOkv], reverse=rGPen6cSMHQkAywh8vqI9JXiD2)
		fKtVWcmL6bisq = sorted(fKtVWcmL6bisq, key=lambda noUVir5wOMbjdfKH1RCxIYhSPAqTWu: noUVir5wOMbjdfKH1RCxIYhSPAqTWu[nI2JK1RfsGWNY3OarEeMQZ], reverse=BF6QAiLUNHh7rKOugaw)
		A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = [],[]
		for iEfNKT3velFyGth80SA4pxbCRrVD in range(len(fKtVWcmL6bisq)):
			A7Ap2wdlxM.append(fKtVWcmL6bisq[iEfNKT3velFyGth80SA4pxbCRrVD][FGTfwsjNrB8DvKSZhLIQAb1JnO])
			duef0gb3Mi1AV5WpN8.append(fKtVWcmL6bisq[iEfNKT3velFyGth80SA4pxbCRrVD][YYJQyRskpX8jv])
	if len(duef0gb3Mi1AV5WpN8)==FGTfwsjNrB8DvKSZhLIQAb1JnO: return yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡒࡕࡓࡉࡃࡋࡈࡆ࠭ॣ"),[],[]
	return iiy37aKq0pCEIOwfcTh61xb4U,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8
def UUTM5J1g9qbI(url):
	ng8RFTvpBOxuMa2ySjYWqVZX = url.split(GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠪࡃࠬ।"))
	eCGwzSrqBmIv = ng8RFTvpBOxuMa2ySjYWqVZX[FGTfwsjNrB8DvKSZhLIQAb1JnO]
	headers = { JZszNnIEMAx28Yao0yqhiXGKOPb(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ॥") : iiy37aKq0pCEIOwfcTh61xb4U }
	Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(r3rnfZ7cdxzNFebIRaLSG6B,eCGwzSrqBmIv,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡇ࠸ࡘࡘࡇࡒ࠮࠳ࡶࡸࠬ०"))
	items = dEyT9xhGjolYzLCH7460w3.findall(tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"࠭ࡐ࡭ࡧࡤࡷࡪࠦࡷࡢ࡫ࡷ࠲࠯ࡅࡨࡳࡧࡩࡁࡡ࠭ࠨ࠯ࠬࡂ࠭ࡡ࠭ࠧ१"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	url = items[FGTfwsjNrB8DvKSZhLIQAb1JnO]
	return UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ२"),[iiy37aKq0pCEIOwfcTh61xb4U],[url]
def wYI46DCkqPB9A(url):
	A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = [],[]
	headers = { Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ३") : iiy37aKq0pCEIOwfcTh61xb4U }
	Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(Dxc7GChQwZ4kOlKHSbL06agnB,url,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡌࡁࡄࡗࡏࡘ࡞ࡈࡏࡐࡍࡖ࠱࠶ࡹࡴࠨ४"))
	eCGwzSrqBmIv = dEyT9xhGjolYzLCH7460w3.findall(jXE2YHkswT8y(u"ࠪࡶࡪࡪࡩࡳࡧࡦࡸࡤࡻࡲ࡭࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ५"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if eCGwzSrqBmIv: return iiy37aKq0pCEIOwfcTh61xb4U,[iiy37aKq0pCEIOwfcTh61xb4U],[eCGwzSrqBmIv[FGTfwsjNrB8DvKSZhLIQAb1JnO]]
	else: return SaB5hx3PZwXRLtKgrTfQvId(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡂࡖ࡜࡝࡚ࡗࡒࠧ६"),[],[]
def elyOETRJDU8afgsdM9uI50iCN6wpm(url):
	A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = [],[]
	headers = { Y41NvKfOroMzGB8sEHy7wbXlc5(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ७") : iiy37aKq0pCEIOwfcTh61xb4U }
	Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(Dxc7GChQwZ4kOlKHSbL06agnB,url,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,JZszNnIEMAx28Yao0yqhiXGKOPb(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡉࡅࡈ࡛ࡌࡕ࡛ࡅࡓࡔࡑࡓ࠮࠳ࡶࡸࠬ८"))
	eCGwzSrqBmIv = dEyT9xhGjolYzLCH7460w3.findall(TlGXWLYsV1z(u"ࠧࡩࡴࡨࡪࠧ࠲ࠢࠩࡪࡷࡸ࠳࠰࠿ࠪࠤࠪ९"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if eCGwzSrqBmIv: return iiy37aKq0pCEIOwfcTh61xb4U,[iiy37aKq0pCEIOwfcTh61xb4U],[eCGwzSrqBmIv[FGTfwsjNrB8DvKSZhLIQAb1JnO]]
	else: return xpT28sXu051(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡊࡆࡉࡕࡍࡖ࡜ࡆࡔࡕࡋࡔࠩ॰"),[],[]
def j9jVLNUiMD(url):
	A7Ap2wdlxM,duef0gb3Mi1AV5WpN8,errno = [],[],iiy37aKq0pCEIOwfcTh61xb4U
	if EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠩ࠲ࡻࡵ࠳ࡡࡥ࡯࡬ࡲ࠴࠭ॱ") in url:
		eCGwzSrqBmIv,EwsmJ67cCYDIlg = sFNjagPK4W(url)
		rzR9SN7ApZuQhTDWEX3V6ga = {UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩॲ"):yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦ࠾ࠤࡨ࡮ࡡࡳࡵࡨࡸࡂ࡛ࡔࡇ࠯࠻ࠫॳ")}
		oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(r3rnfZ7cdxzNFebIRaLSG6B,SaB5hx3PZwXRLtKgrTfQvId(u"ࠬࡖࡏࡔࡖࠪॴ"),eCGwzSrqBmIv,EwsmJ67cCYDIlg,rzR9SN7ApZuQhTDWEX3V6ga,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡉࡅࡏࡋࡒࡔࡊࡒ࡛࠲࠸࡮ࡥࠩॵ"))
		z0spMAOfJElv6L1K9ae = oCJ8TdG2LwSIVcbaUnhB.content
		if z0spMAOfJElv6L1K9ae.startswith(AbqCJZdWQP9j(u"ࠧࡩࡶࡷࡴࠬॶ")): eCGwzSrqBmIv = z0spMAOfJElv6L1K9ae
		else:
			O5Pwg3UFyX0k9E = dEyT9xhGjolYzLCH7460w3.findall(GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠨࠩࠪࡷࡷࡩ࠽࡜ࠩࠥࡡ࠭࠴ࠪࡀࠫ࡞ࠫࠧࡣࠧࠨࠩॷ"),z0spMAOfJElv6L1K9ae,dEyT9xhGjolYzLCH7460w3.DOTALL)
			if O5Pwg3UFyX0k9E:
				eCGwzSrqBmIv = O5Pwg3UFyX0k9E[FGTfwsjNrB8DvKSZhLIQAb1JnO]
				O5Pwg3UFyX0k9E = dEyT9xhGjolYzLCH7460w3.findall(zmcGfOdvAjsELeJlP(u"ࠩࡶࡳࡺࡸࡣࡦ࠿ࠫ࠲࠯ࡅࠩ࡜ࠨࠧࡡࠬॸ"),eCGwzSrqBmIv,dEyT9xhGjolYzLCH7460w3.DOTALL)
				if O5Pwg3UFyX0k9E:
					eCGwzSrqBmIv = a9I3YZjc6ySDPE4Kp(O5Pwg3UFyX0k9E[FGTfwsjNrB8DvKSZhLIQAb1JnO])
					return iiy37aKq0pCEIOwfcTh61xb4U,[iiy37aKq0pCEIOwfcTh61xb4U],[eCGwzSrqBmIv]
	elif LyNiIHPOwD3hCUYEFM7(u"ࠪ࠳ࡱ࡯࡮࡬ࡵ࠲ࠫॹ") in url:
		oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(r3rnfZ7cdxzNFebIRaLSG6B,xpT28sXu051(u"ࠫࡌࡋࡔࠨॺ"),url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,rGPen6cSMHQkAywh8vqI9JXiD2,iiy37aKq0pCEIOwfcTh61xb4U,TlGXWLYsV1z(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡈࡄࡎࡊࡘࡓࡉࡑ࡚࠱࠶ࡹࡴࠨॻ"))
		z0spMAOfJElv6L1K9ae = oCJ8TdG2LwSIVcbaUnhB.content
		if FRYcH4KL7e9gv5pEB(u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨॼ") in list(oCJ8TdG2LwSIVcbaUnhB.headers.keys()): eCGwzSrqBmIv = oCJ8TdG2LwSIVcbaUnhB.headers[ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩॽ")]
		else: eCGwzSrqBmIv = dEyT9xhGjolYzLCH7460w3.findall(EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠨ࡫ࡧࡁࠧࡲࡩ࡯࡭ࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬॾ"),z0spMAOfJElv6L1K9ae,dEyT9xhGjolYzLCH7460w3.DOTALL)[FGTfwsjNrB8DvKSZhLIQAb1JnO]
	if FRYcH4KL7e9gv5pEB(u"ࠩ࠲ࡺ࠴࠭ॿ") in eCGwzSrqBmIv or GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠪ࠳࡫࠵ࠧঀ") in eCGwzSrqBmIv:
		eCGwzSrqBmIv = eCGwzSrqBmIv.replace(yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠫ࠴࡬࠯ࠨঁ"),hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠬ࠵ࡡࡱ࡫࠲ࡷࡴࡻࡲࡤࡧ࠲ࠫং"))
		eCGwzSrqBmIv = eCGwzSrqBmIv.replace(CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"࠭࠯ࡷ࠱ࠪঃ"),xpT28sXu051(u"ࠧ࠰ࡣࡳ࡭࠴ࡹ࡯ࡶࡴࡦࡩ࠴࠭঄"))
		oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(r3rnfZ7cdxzNFebIRaLSG6B,Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠨࡒࡒࡗ࡙࠭অ"),eCGwzSrqBmIv,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,FRYcH4KL7e9gv5pEB(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡌࡁࡋࡇࡕࡗࡍࡕࡗ࠮࠵ࡵࡨࠬআ"))
		z0spMAOfJElv6L1K9ae = oCJ8TdG2LwSIVcbaUnhB.content
		items = dEyT9xhGjolYzLCH7460w3.findall(PtkEvXAqif14G20QZsaSyT(u"ࠪࠦ࡫࡯࡬ࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠰ࠧࡲࡡࡣࡧ࡯ࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ই"),z0spMAOfJElv6L1K9ae,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if items:
			for fCXyTlcmF4WuetVork,title in items:
				fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork.replace(IpC4qHXRuyNFjzWv(u"ࠫࡡࡢࠧঈ"),iiy37aKq0pCEIOwfcTh61xb4U)
				A7Ap2wdlxM.append(title)
				duef0gb3Mi1AV5WpN8.append(fCXyTlcmF4WuetVork)
		else:
			items = dEyT9xhGjolYzLCH7460w3.findall(ZchUJdM93pTA7zG5(u"ࠬࠨࡦࡪ࡮ࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭উ"),z0spMAOfJElv6L1K9ae,dEyT9xhGjolYzLCH7460w3.DOTALL)
			if items:
				fCXyTlcmF4WuetVork = items[FGTfwsjNrB8DvKSZhLIQAb1JnO]
				fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork.replace(CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"࠭࡜࡝ࠩঊ"),iiy37aKq0pCEIOwfcTh61xb4U)
				A7Ap2wdlxM.append(iiy37aKq0pCEIOwfcTh61xb4U)
				duef0gb3Mi1AV5WpN8.append(fCXyTlcmF4WuetVork)
	else: return ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪঋ"),[iiy37aKq0pCEIOwfcTh61xb4U],[eCGwzSrqBmIv]
	if len(duef0gb3Mi1AV5WpN8)==FGTfwsjNrB8DvKSZhLIQAb1JnO: return xpT28sXu051(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡊࡆࡐࡅࡓࡕࡋࡓ࡜࠭ঌ"),[],[]
	return iiy37aKq0pCEIOwfcTh61xb4U,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8
def Qh3dFi9vNj(url):
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(r3rnfZ7cdxzNFebIRaLSG6B,hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠩࡊࡉ࡙࠭঍"),url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,uuExaKGL7UONtevRd(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡍࡐࡘࡖ࠸࡚࠳࠱ࡴࡶࠪ঎"))
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	A7Ap2wdlxM,duef0gb3Mi1AV5WpN8,errno = [],[],iiy37aKq0pCEIOwfcTh61xb4U
	if hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠫࡵࡲࡡࡺࡧࡵࡣࡪࡳࡢࡦࡦ࠱ࡴ࡭ࡶࠧএ") in url or CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠬ࠵ࡥ࡮ࡤࡨࡨ࠴࠭ঐ") in url:
		if PtkEvXAqif14G20QZsaSyT(u"࠭ࡰ࡭ࡣࡼࡩࡷࡥࡥ࡮ࡤࡨࡨ࠳ࡶࡨࡱࠩ঑") in url:
			eCGwzSrqBmIv = dEyT9xhGjolYzLCH7460w3.findall(IpC4qHXRuyNFjzWv(u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ঒"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
			eCGwzSrqBmIv = eCGwzSrqBmIv[FGTfwsjNrB8DvKSZhLIQAb1JnO]
		else: eCGwzSrqBmIv = url
		if uuExaKGL7UONtevRd(u"ࠨ࡯ࡲࡺࡸ࠺ࡵࠨও") not in eCGwzSrqBmIv: return ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬঔ"),[iiy37aKq0pCEIOwfcTh61xb4U],[eCGwzSrqBmIv]
		oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(r3rnfZ7cdxzNFebIRaLSG6B,TlGXWLYsV1z(u"ࠪࡋࡊ࡚ࠧক"),eCGwzSrqBmIv,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,PtkEvXAqif14G20QZsaSyT(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡎࡑ࡙ࡗ࠹࡛࠭࠳ࡰࡧࠫখ"))
		Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall(ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠬ࡯ࡤ࠾ࠤࡳࡰࡦࡿࡥࡳࠤࠫ࠲࠯ࡅࠩࡷ࡫ࡧࡩࡴࡰࡳࠨগ"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[FGTfwsjNrB8DvKSZhLIQAb1JnO]
		items = dEyT9xhGjolYzLCH7460w3.findall(L90uqo28xEKSFUwYTcm51yRWZIkft(u"࠭࠼ࡴࡱࡸࡶࡨ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࡭ࡣࡥࡩࡱࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧঘ"),PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if items:
			for fCXyTlcmF4WuetVork,e7wFcO9GDXRq in items:
				A7Ap2wdlxM.append(e7wFcO9GDXRq)
				duef0gb3Mi1AV5WpN8.append(fCXyTlcmF4WuetVork)
	elif ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠧ࡮ࡣ࡬ࡲࡤࡶ࡬ࡢࡻࡨࡶ࠳ࡶࡨࡱࠩঙ") in url:
		eCGwzSrqBmIv = dEyT9xhGjolYzLCH7460w3.findall(jXE2YHkswT8y(u"ࠨࡷࡵࡰࡂ࠮࠮ࠫࡁࠬࠦࠬচ"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		eCGwzSrqBmIv = eCGwzSrqBmIv[FGTfwsjNrB8DvKSZhLIQAb1JnO]
		oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(r3rnfZ7cdxzNFebIRaLSG6B,IpC4qHXRuyNFjzWv(u"ࠩࡊࡉ࡙࠭ছ"),eCGwzSrqBmIv,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡍࡐࡘࡖ࠸࡚࠳࠳ࡳࡦࠪজ"))
		Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
		O5Pwg3UFyX0k9E = dEyT9xhGjolYzLCH7460w3.findall(yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠫࠧ࡬ࡩ࡭ࡧࠥ࠾ࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ঝ"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		O5Pwg3UFyX0k9E = O5Pwg3UFyX0k9E[FGTfwsjNrB8DvKSZhLIQAb1JnO]
		A7Ap2wdlxM.append(iiy37aKq0pCEIOwfcTh61xb4U)
		duef0gb3Mi1AV5WpN8.append(O5Pwg3UFyX0k9E)
	elif IpC4qHXRuyNFjzWv(u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡟࡭࡫ࡱ࡯ࠬঞ") in url:
		eCGwzSrqBmIv = dEyT9xhGjolYzLCH7460w3.findall(UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"࠭࠼ࡤࡧࡱࡸࡪࡸ࠾࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩট"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if eCGwzSrqBmIv:
			eCGwzSrqBmIv = eCGwzSrqBmIv[FGTfwsjNrB8DvKSZhLIQAb1JnO]
			return ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪঠ"),[iiy37aKq0pCEIOwfcTh61xb4U],[eCGwzSrqBmIv]
	if len(duef0gb3Mi1AV5WpN8)==FGTfwsjNrB8DvKSZhLIQAb1JnO: return IpC4qHXRuyNFjzWv(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡑࡔ࡜ࡓ࠵ࡗࠪড"),[],[]
	return iiy37aKq0pCEIOwfcTh61xb4U,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8
def Iwj5CaLmYO(url):
	if L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠩࡂ࡫ࡪࡺ࠽ࠨঢ") in url:
		fCXyTlcmF4WuetVork = url.split(YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠪࡃ࡬࡫ࡴ࠾ࠩণ"),YYJQyRskpX8jv)[YYJQyRskpX8jv]
		fCXyTlcmF4WuetVork = UodGe76Lu2IHTYPxBhjk1RpcaqrM.b64decode(fCXyTlcmF4WuetVork)
		if J1MoiYc7ZwzKS: fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork.decode(df6QpwGxuJVZr,CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠫ࡮࡭࡮ࡰࡴࡨࠫত"))
		return tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨথ"),[iiy37aKq0pCEIOwfcTh61xb4U],[fCXyTlcmF4WuetVork]
	website = gZ4LwbKaOm[jXE2YHkswT8y(u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡂࠨদ")][FGTfwsjNrB8DvKSZhLIQAb1JnO]
	headers = {xpT28sXu051(u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨধ"):website}
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(hI7SkXd94fFzAHNZCQoMqEutbnWP,SaB5hx3PZwXRLtKgrTfQvId(u"ࠨࡉࡈࡘࠬন"),url,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,HtK4o2sTPgA78U(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡉࡉࡎࡃࡆࡐ࡚ࡈ࠭࠳ࡰࡧࠫ঩"))
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	Zw4M5DUStdE6xp7GI = F82MvyX4ThI6sbnA3efDoVS(url,zmcGfOdvAjsELeJlP(u"ࠪࡹࡷࡲࠧপ"))
	fCXyTlcmF4WuetVork = dEyT9xhGjolYzLCH7460w3.findall(hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩࡃ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨফ"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if not fCXyTlcmF4WuetVork: fCXyTlcmF4WuetVork = dEyT9xhGjolYzLCH7460w3.findall(uuExaKGL7UONtevRd(u"ࠧࡹ࡯ࡶࡴࡦࡩࡸࡀࠠ࡝࡝ࠪࠬ࠳࠰࠿ࠪࠩࠥব"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if not fCXyTlcmF4WuetVork: fCXyTlcmF4WuetVork = dEyT9xhGjolYzLCH7460w3.findall(AbqCJZdWQP9j(u"ࠨࡦࡪ࡮ࡨ࠾ࠬ࠮࠮ࠫࡁࠬࠫࠧভ"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if fCXyTlcmF4WuetVork:
		fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork[FGTfwsjNrB8DvKSZhLIQAb1JnO]+xpT28sXu051(u"ࠧࡽࡔࡨࡪࡪࡸࡥࡳ࠿ࠪম")+website
		return iiy37aKq0pCEIOwfcTh61xb4U,[iiy37aKq0pCEIOwfcTh61xb4U],[fCXyTlcmF4WuetVork]
	if sVzojQerUqX(u"ࠨࡰࡤࡱࡪࡃ࡙ࠢࡶࡲ࡯ࡪࡴࠢࠨয") in Vxz6OndPIX4g2kaRp7:
		sqZlTP4pxrzY7Gy98MR = dEyT9xhGjolYzLCH7460w3.findall(IpC4qHXRuyNFjzWv(u"ࠩࡱࡥࡲ࡫࠽࡚ࠣࡷࡳࡰ࡫࡮ࠣࠢࡦࡳࡳࡺࡥ࡯ࡶࡀࠦ࠭࠴ࠪࡀࠫࠥࠫর"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if sqZlTP4pxrzY7Gy98MR:
			fCXyTlcmF4WuetVork = sqZlTP4pxrzY7Gy98MR[FGTfwsjNrB8DvKSZhLIQAb1JnO]
			fCXyTlcmF4WuetVork = UodGe76Lu2IHTYPxBhjk1RpcaqrM.b64decode(fCXyTlcmF4WuetVork)
			if J1MoiYc7ZwzKS: fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork.decode(df6QpwGxuJVZr,ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠪ࡭࡬ࡴ࡯ࡳࡧࠪ঱"))
			fCXyTlcmF4WuetVork = dEyT9xhGjolYzLCH7460w3.findall(LyNiIHPOwD3hCUYEFM7(u"ࠫ࡭ࡺࡴࡱ࠰࠭ࡃ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠬࠨল"),fCXyTlcmF4WuetVork,dEyT9xhGjolYzLCH7460w3.DOTALL)
			if fCXyTlcmF4WuetVork:
				fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork[FGTfwsjNrB8DvKSZhLIQAb1JnO]+uuExaKGL7UONtevRd(u"ࠬࢂࡒࡦࡨࡨࡶࡪࡸ࠽ࠨ঳")+website
				return iiy37aKq0pCEIOwfcTh61xb4U,[iiy37aKq0pCEIOwfcTh61xb4U],[fCXyTlcmF4WuetVork]
	return yJeq1BjfiO4NFuwIEzxVLK6b9s(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ঴"),[iiy37aKq0pCEIOwfcTh61xb4U],[url]
def gpJT7OU15G(url,aOtvl3xUCgoDIQN0HEVGYf):
	WK130YrED8vNhiHntepuXR,ff2PjlcCF5ZWyIUbVguMz = [],[]
	if TlGXWLYsV1z(u"ࠧ࠰࠳࠲ࠫ঵") in url:
		fCXyTlcmF4WuetVork = url.replace(ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠨ࠱࠴࠳ࠬশ"),yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠩ࠲࠸࠴࠭ষ"))
		oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(hI7SkXd94fFzAHNZCQoMqEutbnWP,HtK4o2sTPgA78U(u"ࠪࡋࡊ࡚ࠧস"),fCXyTlcmF4WuetVork,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,BF6QAiLUNHh7rKOugaw,iiy37aKq0pCEIOwfcTh61xb4U,CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆࡉ࡜ࡆࡊ࡙ࡔ࠲࠯࠴ࡷࡹ࠭হ"))
		z0spMAOfJElv6L1K9ae = oCJ8TdG2LwSIVcbaUnhB.content
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall(zmcGfOdvAjsELeJlP(u"ࠬࡂࡶࡪࡦࡨࡳ࠭࠴ࠪࡀࠫ࠿࠳ࡻ࡯ࡤࡦࡱࡁࠫ঺"),z0spMAOfJElv6L1K9ae,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if UUIohmv597bO83YCLgWS:
			PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[FGTfwsjNrB8DvKSZhLIQAb1JnO]
			items = dEyT9xhGjolYzLCH7460w3.findall(tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡪࡼࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ঻"),PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
			for fCXyTlcmF4WuetVork,pMAWqrwP80lR in items:
				if fCXyTlcmF4WuetVork not in ff2PjlcCF5ZWyIUbVguMz:
					ff2PjlcCF5ZWyIUbVguMz.append(fCXyTlcmF4WuetVork)
					Zw4M5DUStdE6xp7GI = F82MvyX4ThI6sbnA3efDoVS(fCXyTlcmF4WuetVork,jXE2YHkswT8y(u"ࠧ࡯ࡣࡰࡩ়ࠬ"))
					WK130YrED8vNhiHntepuXR.append(Zw4M5DUStdE6xp7GI+Wc5GekRC0HQLz7+pMAWqrwP80lR)
			return iiy37aKq0pCEIOwfcTh61xb4U,WK130YrED8vNhiHntepuXR,ff2PjlcCF5ZWyIUbVguMz
	elif y6y5HtgXO4TkUbwVZ(u"ࠨ࠱ࡧ࠳ࠬঽ") in url:
		oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(hI7SkXd94fFzAHNZCQoMqEutbnWP,LyNiIHPOwD3hCUYEFM7(u"ࠩࡊࡉ࡙࠭া"),url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,xpT28sXu051(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅࡈ࡛ࡅࡉࡘ࡚࠱࠮࠴ࡱࡨࠬি"))
		z0spMAOfJElv6L1K9ae = oCJ8TdG2LwSIVcbaUnhB.content
		fCXyTlcmF4WuetVork = dEyT9xhGjolYzLCH7460w3.findall(EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠫࡁ࡯ࡦࡳࡣࡰࡩ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬী"),z0spMAOfJElv6L1K9ae,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if fCXyTlcmF4WuetVork:
			fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork[FGTfwsjNrB8DvKSZhLIQAb1JnO].replace(SaB5hx3PZwXRLtKgrTfQvId(u"ࠬ࠵࠱࠰ࠩু"),tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"࠭࠯࠵࠱ࠪূ"))
			oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(hI7SkXd94fFzAHNZCQoMqEutbnWP,uuExaKGL7UONtevRd(u"ࠧࡈࡇࡗࠫৃ"),fCXyTlcmF4WuetVork,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,BF6QAiLUNHh7rKOugaw,iiy37aKq0pCEIOwfcTh61xb4U,xpT28sXu051(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡊࡍ࡙ࡃࡇࡖࡘ࠶࠳࠳ࡳࡦࠪৄ"))
			z0spMAOfJElv6L1K9ae = oCJ8TdG2LwSIVcbaUnhB.content
			fCXyTlcmF4WuetVork = dEyT9xhGjolYzLCH7460w3.findall(y6y5HtgXO4TkUbwVZ(u"ࠩࡦࡰࡦࡹࡳ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ৅"),z0spMAOfJElv6L1K9ae,dEyT9xhGjolYzLCH7460w3.DOTALL)
			if fCXyTlcmF4WuetVork: return uuExaKGL7UONtevRd(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭৆"),[iiy37aKq0pCEIOwfcTh61xb4U],[fCXyTlcmF4WuetVork[FGTfwsjNrB8DvKSZhLIQAb1JnO]]
	elif HtK4o2sTPgA78U(u"ࠫ࠴ࡸ࡯࡭ࡧ࠲ࠫে") in url:
		headers = {CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭ৈ"):aOtvl3xUCgoDIQN0HEVGYf}
		oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(r3rnfZ7cdxzNFebIRaLSG6B,ZchUJdM93pTA7zG5(u"࠭ࡇࡆࡖࠪ৉"),url,iiy37aKq0pCEIOwfcTh61xb4U,headers,BF6QAiLUNHh7rKOugaw,iiy37aKq0pCEIOwfcTh61xb4U,vODxLKW5Ql6r4Fbm8(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡉࡌ࡟ࡂࡆࡕࡗ࠵࠲࠺ࡴࡩࠩ৊"))
		fCXyTlcmF4WuetVork = oCJ8TdG2LwSIVcbaUnhB.headers[XrTw01KtLzbpoyMf(u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪো")]
		oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(r3rnfZ7cdxzNFebIRaLSG6B,ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠩࡊࡉ࡙࠭ৌ"),fCXyTlcmF4WuetVork,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,HtK4o2sTPgA78U(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅࡈ࡛ࡅࡉࡘ࡚࠱࠮࠷ࡷ࡬্ࠬ"))
		Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
		phm0nfzAUCXHBjO7lIDSxT3eZJdc,WK130YrED8vNhiHntepuXR,ff2PjlcCF5ZWyIUbVguMz = XRsU6ModzJhDiF4BpmNafyeVrEH9(fCXyTlcmF4WuetVork,Vxz6OndPIX4g2kaRp7)
		return phm0nfzAUCXHBjO7lIDSxT3eZJdc,WK130YrED8vNhiHntepuXR,ff2PjlcCF5ZWyIUbVguMz
	elif vODxLKW5Ql6r4Fbm8(u"ࠫ࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠯ࠨৎ") in url:
		eCGwzSrqBmIv = url.replace(GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠬ࠵ࡤࡰࡹࡱࡰࡴࡧࡤ࠰ࠩ৏"),JZszNnIEMAx28Yao0yqhiXGKOPb(u"࠭࠯ࡴࡥࡵ࡭ࡵࡺ࠯ࠨ৐"))
		rzR9SN7ApZuQhTDWEX3V6ga = {tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ৑"):aOtvl3xUCgoDIQN0HEVGYf}
		oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(r3rnfZ7cdxzNFebIRaLSG6B,ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠨࡉࡈࡘࠬ৒"),eCGwzSrqBmIv,iiy37aKq0pCEIOwfcTh61xb4U,rzR9SN7ApZuQhTDWEX3V6ga,BF6QAiLUNHh7rKOugaw,iiy37aKq0pCEIOwfcTh61xb4U,zmcGfOdvAjsELeJlP(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡋࡇ࡚ࡄࡈࡗ࡙࠷࠭࠷ࡶ࡫ࠫ৓"))
		Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
		fCXyTlcmF4WuetVork = dEyT9xhGjolYzLCH7460w3.findall(YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠪࡀ࡮࡬ࡲࡢ࡯ࡨ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ৔"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if fCXyTlcmF4WuetVork:
			fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork[FGTfwsjNrB8DvKSZhLIQAb1JnO]
			oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(r3rnfZ7cdxzNFebIRaLSG6B,ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠫࡌࡋࡔࠨ৕"),fCXyTlcmF4WuetVork,iiy37aKq0pCEIOwfcTh61xb4U,rzR9SN7ApZuQhTDWEX3V6ga,BF6QAiLUNHh7rKOugaw,iiy37aKq0pCEIOwfcTh61xb4U,HtK4o2sTPgA78U(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡇࡊ࡝ࡇࡋࡓࡕ࠳࠰࠻ࡹ࡮ࠧ৖"))
			Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
			if YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨৗ") in list(oCJ8TdG2LwSIVcbaUnhB.headers.keys()):
				fCXyTlcmF4WuetVork = oCJ8TdG2LwSIVcbaUnhB.headers[hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ৘")]
				oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(r3rnfZ7cdxzNFebIRaLSG6B,JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠨࡉࡈࡘࠬ৙"),fCXyTlcmF4WuetVork,iiy37aKq0pCEIOwfcTh61xb4U,rzR9SN7ApZuQhTDWEX3V6ga,BF6QAiLUNHh7rKOugaw,iiy37aKq0pCEIOwfcTh61xb4U,ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡋࡇ࡚ࡄࡈࡗ࡙࠷࠭࠹ࡶ࡫ࠫ৚"))
				Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
				phm0nfzAUCXHBjO7lIDSxT3eZJdc,WK130YrED8vNhiHntepuXR,ff2PjlcCF5ZWyIUbVguMz = XRsU6ModzJhDiF4BpmNafyeVrEH9(fCXyTlcmF4WuetVork,Vxz6OndPIX4g2kaRp7)
				if ff2PjlcCF5ZWyIUbVguMz: return phm0nfzAUCXHBjO7lIDSxT3eZJdc,WK130YrED8vNhiHntepuXR,ff2PjlcCF5ZWyIUbVguMz
			elif SaB5hx3PZwXRLtKgrTfQvId(u"ࠪ࠳ࡪࡳࡢࡦࡦ࠱ࡴ࡭ࡶ࠿ࡪࡦࡀࠫ৛") in fCXyTlcmF4WuetVork:
				fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork.replace(TlGXWLYsV1z(u"ࠫ࠴࡫࡭ࡣࡧࡧ࠲ࡵ࡮ࡰࡀ࡫ࡧࡁࠬড়"),LyNiIHPOwD3hCUYEFM7(u"ࠬ࠵ࡪࡸࡲ࡯ࡥࡾ࡫ࡲ࠯ࡲ࡫ࡴࡄ࡯ࡤ࠾ࠩঢ়"))
				return SaB5hx3PZwXRLtKgrTfQvId(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ৞"),[iiy37aKq0pCEIOwfcTh61xb4U],[fCXyTlcmF4WuetVork]
	else: return hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪয়"),[iiy37aKq0pCEIOwfcTh61xb4U],[url]
	return JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡉࡌ࡟ࡂࡆࡕࡗ࠵ࠬৠ"),[],[]
def eScC4ZYT7g(url):
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(hI7SkXd94fFzAHNZCQoMqEutbnWP,SaB5hx3PZwXRLtKgrTfQvId(u"ࠩࡊࡉ࡙࠭ৡ"),url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,uuExaKGL7UONtevRd(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅࡈ࡛ࡅࡉࡘ࡚࠳࠮࠳ࡶࡸࠬৢ"))
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	data = dEyT9xhGjolYzLCH7460w3.findall(zmcGfOdvAjsELeJlP(u"ࠫࠧࡧࡣࡵ࡫ࡲࡲࠧ࠴ࠪࡀࡸࡤࡰࡺ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡺࡦࡲࡵࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡼࡡ࡭ࡷࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬৣ"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if data:
		ycS8Ze4t6zsRoTr,id,QapoXUByKOmJ = data[FGTfwsjNrB8DvKSZhLIQAb1JnO]
		data = MgP8OjoaiWQEVG59(u"ࠬࡵࡰ࠾ࠩ৤")+ycS8Ze4t6zsRoTr+EMO8gy4LrsNTh0knZwpSeU75APW(u"࠭ࠦࡪࡦࡀࠫ৥")+id+vODxLKW5Ql6r4Fbm8(u"ࠧࠧࡨࡱࡥࡲ࡫࠽ࠨ০")+QapoXUByKOmJ
		headers = {zmcGfOdvAjsELeJlP(u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ১"):TlGXWLYsV1z(u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤࠨ২")}
		oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(hI7SkXd94fFzAHNZCQoMqEutbnWP,yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠪࡔࡔ࡙ࡔࠨ৩"),url,data,headers,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆࡉ࡜ࡆࡊ࡙ࡔ࠴࠯࠵ࡲࡩ࠭৪"))
		Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
		fCXyTlcmF4WuetVork = dEyT9xhGjolYzLCH7460w3.findall(PtkEvXAqif14G20QZsaSyT(u"ࠬࠨࡲࡦࡨࡨࡶࡪࡸࠢࠡࡸࡤࡰࡺ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ৫"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if fCXyTlcmF4WuetVork: return hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ৬"),[iiy37aKq0pCEIOwfcTh61xb4U],[fCXyTlcmF4WuetVork[FGTfwsjNrB8DvKSZhLIQAb1JnO]]
	return tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡈࡋ࡞ࡈࡅࡔࡖ࠴ࠫ৭"),[],[]
def PrqXjGnsUS(url):
	headers = {hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠨ࡚࠰ࡖࡪࡷࡵࡦࡵࡷࡩࡩ࠳ࡗࡪࡶ࡫ࠫ৮"):vODxLKW5Ql6r4Fbm8(u"࡛ࠩࡑࡑࡎࡴࡵࡲࡕࡩࡶࡻࡥࡴࡶࠪ৯")}
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(hI7SkXd94fFzAHNZCQoMqEutbnWP,JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠪࡋࡊ࡚ࠧৰ"),url,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆࡉ࡜ࡆࡊ࡙ࡔ࠵࠯࠴ࡷࡹ࠭ৱ"))
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	fCXyTlcmF4WuetVork = dEyT9xhGjolYzLCH7460w3.findall(CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ৲"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if fCXyTlcmF4WuetVork:
		fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork[FGTfwsjNrB8DvKSZhLIQAb1JnO].replace(OTlVEGYPSxsNaBdXUucqA3,iiy37aKq0pCEIOwfcTh61xb4U)
		return JZszNnIEMAx28Yao0yqhiXGKOPb(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ৳"),[iiy37aKq0pCEIOwfcTh61xb4U],[fCXyTlcmF4WuetVork]
	return HtK4o2sTPgA78U(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡈࡋ࡞ࡈࡅࡔࡖ࠴ࠫ৴"),[],[]
def aY5JxSDGNE(url):
	eCGwzSrqBmIv = url.split(FRYcH4KL7e9gv5pEB(u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ৵"),YYJQyRskpX8jv)[FGTfwsjNrB8DvKSZhLIQAb1JnO].strip(PtkEvXAqif14G20QZsaSyT(u"ࠩࡂࠫ৶")).strip(hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠪ࠳ࠬ৷")).strip(EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠫࠫ࠭৸"))
	A7Ap2wdlxM,duef0gb3Mi1AV5WpN8,items,O5Pwg3UFyX0k9E = [],[],[],iiy37aKq0pCEIOwfcTh61xb4U
	headers = { Y41NvKfOroMzGB8sEHy7wbXlc5(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ৹"):hhQwbeiNLoqFjX90fB7aG8VAs(u"࠭ࡍࡰࡼ࡬ࡰࡱࡧ࠯࠶࠰࠳ࠤ࠭࡝ࡩ࡯ࡦࡲࡻࡸࠦࡎࡕࠢ࠴࠴࠳࠶࠻࡙ࠡ࡬ࡲ࠻࠺࠻ࠡࡺ࠹࠸࠮࠭৺") }
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(r3rnfZ7cdxzNFebIRaLSG6B,yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠧࡈࡇࡗࠫ৻"),eCGwzSrqBmIv,iiy37aKq0pCEIOwfcTh61xb4U,headers,rGPen6cSMHQkAywh8vqI9JXiD2,iiy37aKq0pCEIOwfcTh61xb4U,sVzojQerUqX(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡊࡍ࡙ࡃࡇࡖࡘ࠲࠷ࡳࡵࠩৼ"))
	if yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ৽") in list(oCJ8TdG2LwSIVcbaUnhB.headers.keys()): O5Pwg3UFyX0k9E = oCJ8TdG2LwSIVcbaUnhB.headers[SaB5hx3PZwXRLtKgrTfQvId(u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ৾")]
	if hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠫ࡭ࡺࡴࡱࠩ৿") in O5Pwg3UFyX0k9E:
		if XrTw01KtLzbpoyMf(u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭਀") in url: O5Pwg3UFyX0k9E = O5Pwg3UFyX0k9E.replace(sVzojQerUqX(u"࠭࠯ࡧ࠱ࠪਁ"),CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠧ࠰ࡸ࠲ࠫਂ"))
		u7uUZRmeJP92zixvprLVt4S = eCGwzSrqBmIv.split(zmcGfOdvAjsELeJlP(u"ࠨࡁࡓࡌࡕ࡙ࡉࡅ࠿ࠪਃ"))[YYJQyRskpX8jv]
		headers = { JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭਄"):headers[PtkEvXAqif14G20QZsaSyT(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧਅ")] , hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠫࡈࡵ࡯࡬࡫ࡨࠫਆ"):CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠬࡖࡈࡑࡕࡌࡈࡂ࠭ਇ")+u7uUZRmeJP92zixvprLVt4S }
		oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(r3rnfZ7cdxzNFebIRaLSG6B,PtkEvXAqif14G20QZsaSyT(u"࠭ࡇࡆࡖࠪਈ"),O5Pwg3UFyX0k9E,iiy37aKq0pCEIOwfcTh61xb4U,headers,BF6QAiLUNHh7rKOugaw,iiy37aKq0pCEIOwfcTh61xb4U,PtkEvXAqif14G20QZsaSyT(u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠮ࡒࡏࡅ࡞࠳࠳ࡳࡦࠪਉ"))
		Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
		if hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠨ࠱ࡩ࠳ࠬਊ") in O5Pwg3UFyX0k9E: items = dEyT9xhGjolYzLCH7460w3.findall(XrTw01KtLzbpoyMf(u"ࠩ࠿࡬࠷ࡄ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ਋"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		elif tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠪ࠳ࡻ࠵ࠧ਌") in O5Pwg3UFyX0k9E: items = dEyT9xhGjolYzLCH7460w3.findall(LyNiIHPOwD3hCUYEFM7(u"ࠫ࡮ࡪ࠽ࠣࡸ࡬ࡨࡪࡵࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ਍"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if items: return [],[iiy37aKq0pCEIOwfcTh61xb4U],[ items[FGTfwsjNrB8DvKSZhLIQAb1JnO] ]
		elif L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠬࡂࡨ࠲ࡀ࠷࠴࠹ࡂ࠯ࡩ࠳ࡁࠫ਎") in Vxz6OndPIX4g2kaRp7:
			return tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦำ๋ำไีࠥอไโ์า๎ํࠦแ๋้ࠣััฮࠠืัࠣ็ํีู๊๊่ࠡิื็ࠡ็้ࠤฬ๊ล็ฬิ๊ฯࠦวๅะสูฮࠦศไࠩਏ"),[],[]
	else: return vODxLKW5Ql6r4Fbm8(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡈࡋ࡞ࡈࡅࡔࡖࠪਐ"),[],[]
def zYRenU6D40(fCXyTlcmF4WuetVork):
	ng8RFTvpBOxuMa2ySjYWqVZX = dEyT9xhGjolYzLCH7460w3.findall(yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠨࡲࡲࡷࡹ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠦࡴࡧࡵࡺࡪࡸࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠧࠨࠪ਑"),fCXyTlcmF4WuetVork+EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠩࠩࠪࠬ਒"),dEyT9xhGjolYzLCH7460w3.DOTALL|dEyT9xhGjolYzLCH7460w3.IGNORECASE)
	VlX2C0mPxeyD8wZYKLuf,w7dRclJi29IUOqP = ng8RFTvpBOxuMa2ySjYWqVZX[FGTfwsjNrB8DvKSZhLIQAb1JnO]
	url = ZchUJdM93pTA7zG5(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸ࡫ࡲࡪࡧࡶ࠸ࡼࡧࡴࡤࡪ࠱ࡲࡪࡺ࠯ࡢ࡬ࡤࡼࡈ࡫࡮ࡵࡧࡵࡃࡤࡧࡣࡵ࡫ࡲࡲࡂ࡭ࡥࡵࡵࡨࡶࡻ࡫ࡲࠧࡡࡳࡳࡸࡺ࡟ࡪࡦࡀࠫਓ")+VlX2C0mPxeyD8wZYKLuf+zmcGfOdvAjsELeJlP(u"ࠫࠫࡹࡥࡳࡸࡨࡶ࡮ࡪ࠽ࠨਔ")+w7dRclJi29IUOqP
	headers = { xpT28sXu051(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩਕ"):iiy37aKq0pCEIOwfcTh61xb4U , UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"࠭ࡘ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡧࡧ࠱࡜࡯ࡴࡩࠩਖ"):ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"࡙ࠧࡏࡏࡌࡹࡺࡰࡓࡧࡴࡹࡪࡹࡴࠨਗ") }
	eCGwzSrqBmIv = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(r3rnfZ7cdxzNFebIRaLSG6B,url,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡘࡋࡒࡊࡇࡖ࠸࡜ࡇࡔࡄࡊ࠰࠵ࡸࡺࠧਘ"))
	return SaB5hx3PZwXRLtKgrTfQvId(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬਙ"),[iiy37aKq0pCEIOwfcTh61xb4U],[eCGwzSrqBmIv]
def kiFol7tQ5Y(url):
	Zw4M5DUStdE6xp7GI = F82MvyX4ThI6sbnA3efDoVS(url,jXE2YHkswT8y(u"ࠪࡹࡷࡲࠧਚ"))
	rzR9SN7ApZuQhTDWEX3V6ga = {jXE2YHkswT8y(u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬਛ"):Zw4M5DUStdE6xp7GI,UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠬࡇࡣࡤࡧࡳࡸ࠲ࡋ࡮ࡤࡱࡧ࡭ࡳ࡭ࠧਜ"):hhQwbeiNLoqFjX90fB7aG8VAs(u"࠭ࡧࡻ࡫ࡳ࠰ࠥࡪࡥࡧ࡮ࡤࡸࡪ࠭ਝ")}
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(Qfob9ThC6ryqKkYZ,LyNiIHPOwD3hCUYEFM7(u"ࠧࡈࡇࡗࠫਞ"),url,iiy37aKq0pCEIOwfcTh61xb4U,rzR9SN7ApZuQhTDWEX3V6ga,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡒ࡟ࡃࡊࡏࡄ࠱࠶ࡹࡴࠨਟ"))
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall(zmcGfOdvAjsELeJlP(u"ࠩࡳࡰࡦࡿࡥࡳ࠰ࡴࡹࡦࡲࡩࡵࡻࡶࡩࡱ࡫ࡣࡵࡱࡵࠬ࠳࠰࠿ࠪࡨࡲࡶࡲࡧࡴࡴ࠼ࠪਠ"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	eCGwzSrqBmIv = iiy37aKq0pCEIOwfcTh61xb4U
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[FGTfwsjNrB8DvKSZhLIQAb1JnO]
		items = dEyT9xhGjolYzLCH7460w3.findall(L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠪࡪࡴࡸ࡭ࡢࡶ࠽ࠤࡡ࠭ࠨ࡝ࡦ࠱࠮ࡄ࠯࡜ࠨ࠮ࠣࡷࡷࡩ࠺ࠡࠤࠫ࠲࠯ࡅࠩࠣࠩਡ"),PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = [],[]
		for title,fCXyTlcmF4WuetVork in items:
			A7Ap2wdlxM.append(title)
			duef0gb3Mi1AV5WpN8.append(fCXyTlcmF4WuetVork)
		if len(duef0gb3Mi1AV5WpN8)==YYJQyRskpX8jv: eCGwzSrqBmIv = duef0gb3Mi1AV5WpN8[FGTfwsjNrB8DvKSZhLIQAb1JnO]
		elif len(duef0gb3Mi1AV5WpN8)>YYJQyRskpX8jv:
			mmfrx2S5XqknFTDeRhj49LuYv1wW0 = ccv1mVPUsnr(XrTw01KtLzbpoyMf(u"ࠫศิสาࠢส่๊๊แࠡษ็้๋อำษࠩਢ"), A7Ap2wdlxM)
			if mmfrx2S5XqknFTDeRhj49LuYv1wW0==-YYJQyRskpX8jv: return JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠬࡋࡘࡊࡖࡢࡅࡑࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪਣ"),[],[]
			eCGwzSrqBmIv = duef0gb3Mi1AV5WpN8[mmfrx2S5XqknFTDeRhj49LuYv1wW0]
	else:
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall(xpT28sXu051(u"࠭ࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫਤ"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if UUIohmv597bO83YCLgWS: eCGwzSrqBmIv = UUIohmv597bO83YCLgWS[FGTfwsjNrB8DvKSZhLIQAb1JnO]
	if not eCGwzSrqBmIv: return YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡐ࡝ࡈࡏࡍࡂࠩਥ"),[],[]
	return tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫਦ"),[iiy37aKq0pCEIOwfcTh61xb4U],[eCGwzSrqBmIv]
def rgoAS9U5fkvaclP2xOL(url):
	Zw4M5DUStdE6xp7GI = F82MvyX4ThI6sbnA3efDoVS(url,tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠩࡸࡶࡱ࠭ਧ"))
	rzR9SN7ApZuQhTDWEX3V6ga = {GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫਨ"):Zw4M5DUStdE6xp7GI,EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠫࡆࡩࡣࡦࡲࡷ࠱ࡊࡴࡣࡰࡦ࡬ࡲ࡬࠭਩"):XrTw01KtLzbpoyMf(u"ࠬ࡭ࡺࡪࡲ࠯ࠤࡩ࡫ࡦ࡭ࡣࡷࡩࠬਪ")}
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(Qfob9ThC6ryqKkYZ,PtkEvXAqif14G20QZsaSyT(u"࠭ࡇࡆࡖࠪਫ"),url,iiy37aKq0pCEIOwfcTh61xb4U,rzR9SN7ApZuQhTDWEX3V6ga,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡛ࡊࡉࡉࡎࡃ࠰࠵ࡸࡺࠧਬ"))
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall(xpT28sXu051(u"ࠨࡲ࡯ࡥࡾ࡫ࡲ࠯ࡳࡸࡥࡱ࡯ࡴࡺࡵࡨࡰࡪࡩࡴࡰࡴࠫ࠲࠯ࡅࠩࡧࡱࡵࡱࡦࡺࡳ࠻ࠩਭ"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	eCGwzSrqBmIv = iiy37aKq0pCEIOwfcTh61xb4U
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[FGTfwsjNrB8DvKSZhLIQAb1JnO]
		items = dEyT9xhGjolYzLCH7460w3.findall(UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠩࡩࡳࡷࡳࡡࡵ࠼ࠣࡠࠬ࠮࡜ࡥ࠰࠭ࡃ࠮ࡢࠧ࠭ࠢࡶࡶࡨࡀࠠࠣࠪ࠱࠮ࡄ࠯ࠢࠨਮ"),PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = [],[]
		for title,fCXyTlcmF4WuetVork in items:
			A7Ap2wdlxM.append(title)
			duef0gb3Mi1AV5WpN8.append(fCXyTlcmF4WuetVork)
		if len(duef0gb3Mi1AV5WpN8)==YYJQyRskpX8jv: eCGwzSrqBmIv = duef0gb3Mi1AV5WpN8[FGTfwsjNrB8DvKSZhLIQAb1JnO]
		elif len(duef0gb3Mi1AV5WpN8)>YYJQyRskpX8jv:
			mmfrx2S5XqknFTDeRhj49LuYv1wW0 = ccv1mVPUsnr(JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠪวำะัࠡษ็้้็ࠠศๆ่๊ฬูศࠨਯ"), A7Ap2wdlxM)
			if mmfrx2S5XqknFTDeRhj49LuYv1wW0==-YYJQyRskpX8jv: return zmcGfOdvAjsELeJlP(u"ࠫࡊ࡞ࡉࡕࡡࡄࡐࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩਰ"),[],[]
			eCGwzSrqBmIv = duef0gb3Mi1AV5WpN8[mmfrx2S5XqknFTDeRhj49LuYv1wW0]
	if not eCGwzSrqBmIv:
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall(tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠬࡹ࡯ࡶࡴࡦࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ਱"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if UUIohmv597bO83YCLgWS: eCGwzSrqBmIv = UUIohmv597bO83YCLgWS[FGTfwsjNrB8DvKSZhLIQAb1JnO]
	if not eCGwzSrqBmIv: return ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤ࡙ࠡࡈࡇࡎࡓࡁࠨਲ"),[],[]
	return GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪਲ਼"),[iiy37aKq0pCEIOwfcTh61xb4U],[eCGwzSrqBmIv]
def dS3lHm09G4(fCXyTlcmF4WuetVork):
	ng8RFTvpBOxuMa2ySjYWqVZX = dEyT9xhGjolYzLCH7460w3.findall(vODxLKW5Ql6r4Fbm8(u"ࠨࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࡠࡄࡶ࡯ࡴࡶ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠪࡸ࡫ࡲࡷࡧࡵ࡭ࡩࡃࠨ࠯ࠬࡂ࠭ࠫࠬࠧ਴"),fCXyTlcmF4WuetVork+L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠩࠩࠪࠬਵ"),dEyT9xhGjolYzLCH7460w3.DOTALL)
	url,VlX2C0mPxeyD8wZYKLuf,w7dRclJi29IUOqP = ng8RFTvpBOxuMa2ySjYWqVZX[FGTfwsjNrB8DvKSZhLIQAb1JnO]
	data = {JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠪࡴࡴࡹࡴࡠ࡫ࡧࠫਸ਼"):VlX2C0mPxeyD8wZYKLuf,hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠫࡸ࡫ࡲࡷࡧࡵࠫ਷"):w7dRclJi29IUOqP}
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,LyNiIHPOwD3hCUYEFM7(u"ࠬࡖࡏࡔࡖࠪਸ"),url,data,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,HtK4o2sTPgA78U(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡏࡔࡇࡍࡄࡃࡐ࠱࠶ࡹࡴࠨਹ"))
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	eCGwzSrqBmIv = dEyT9xhGjolYzLCH7460w3.findall(Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠧࡪࡨࡵࡥࡲ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ਺"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)[FGTfwsjNrB8DvKSZhLIQAb1JnO]
	return IpC4qHXRuyNFjzWv(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ਻"),[iiy37aKq0pCEIOwfcTh61xb4U],[eCGwzSrqBmIv]
def BDYeH90xTR(url):
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,y6y5HtgXO4TkUbwVZ(u"ࠩࡊࡉ਼࡙࠭"),url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,SaB5hx3PZwXRLtKgrTfQvId(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡃࡊࡏࡄࡐࡎࡍࡈࡕ࠯࠴ࡷࡹ࠭਽"))
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	fCXyTlcmF4WuetVork = dEyT9xhGjolYzLCH7460w3.findall(ZchUJdM93pTA7zG5(u"ࠫࡁ࡯ࡦࡳࡣࡰࡩ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬਾ"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if fCXyTlcmF4WuetVork:
		fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork[FGTfwsjNrB8DvKSZhLIQAb1JnO]
		if fCXyTlcmF4WuetVork: return MgP8OjoaiWQEVG59(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨਿ"),[iiy37aKq0pCEIOwfcTh61xb4U],[fCXyTlcmF4WuetVork]
	return sVzojQerUqX(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡅࡌࡑࡆࡒࡉࡈࡊࡗࠫੀ"),[],[]
def G3hQr8jp5d(url):
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠧࡈࡇࡗࠫੁ"),url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡈࡏࡍࡂࡅࡏ࡙ࡕ࠳࠱ࡴࡶࠪੂ"))
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	fCXyTlcmF4WuetVork = dEyT9xhGjolYzLCH7460w3.findall(FRYcH4KL7e9gv5pEB(u"ࠩ࠿ࡍࡋࡘࡁࡎࡇࠣࡗࡗࡉ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ੃"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)[FGTfwsjNrB8DvKSZhLIQAb1JnO]
	return AbqCJZdWQP9j(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭੄"),[iiy37aKq0pCEIOwfcTh61xb4U],[fCXyTlcmF4WuetVork]
def nnFQHctSEG(url):
	UM3q9WaVXOP4ZuhCnHB5jyA = F82MvyX4ThI6sbnA3efDoVS(url,tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠫࡺࡸ࡬ࠨ੅"))
	if GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠬ࡯࡮ࡥࡧࡻࡁࠬ੆") in url:
		headers = {JZszNnIEMAx28Yao0yqhiXGKOPb(u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧੇ"):UM3q9WaVXOP4ZuhCnHB5jyA}
		oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,LyNiIHPOwD3hCUYEFM7(u"ࠧࡈࡇࡗࠫੈ"),url,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡈࡏࡍࡂࡐࡒ࡛࠲࠷ࡳࡵࠩ੉"))
		Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
		eCGwzSrqBmIv = dEyT9xhGjolYzLCH7460w3.findall(HtK4o2sTPgA78U(u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ੊"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if eCGwzSrqBmIv:
			eCGwzSrqBmIv = eCGwzSrqBmIv[FGTfwsjNrB8DvKSZhLIQAb1JnO]
			if jXE2YHkswT8y(u"ࠪ࡬ࡹࡺࡰࠨੋ") not in eCGwzSrqBmIv: eCGwzSrqBmIv = hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠫ࡭ࡺࡴࡱ࠼ࠪੌ")+eCGwzSrqBmIv
			if YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠬࡩࡩ࡮ࡣࡱࡳࡼ੍࠭") in eCGwzSrqBmIv:
				eCGwzSrqBmIv = eCGwzSrqBmIv.replace(Y41NvKfOroMzGB8sEHy7wbXlc5(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࠨ੎"),GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࠨ੏"))
				oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠨࡉࡈࡘࠬ੐"),eCGwzSrqBmIv,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡉࡉࡎࡃࡑࡓ࡜࠳࠲࡯ࡦࠪੑ"))
				z0spMAOfJElv6L1K9ae = oCJ8TdG2LwSIVcbaUnhB.content
				items = dEyT9xhGjolYzLCH7460w3.findall(L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠪࡷࡴࡻࡲࡤࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷ࡮ࢀࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ੒"),z0spMAOfJElv6L1K9ae,dEyT9xhGjolYzLCH7460w3.DOTALL)
				A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = [],[]
				VrnhdEezI7 = F82MvyX4ThI6sbnA3efDoVS(eCGwzSrqBmIv,TlGXWLYsV1z(u"ࠫࡺࡸ࡬ࠨ੓"))
				for fCXyTlcmF4WuetVork,pMAWqrwP80lR in reversed(items):
					fCXyTlcmF4WuetVork = VrnhdEezI7+fCXyTlcmF4WuetVork+FRYcH4KL7e9gv5pEB(u"ࠬࢂࡒࡦࡨࡨࡶࡪࡸ࠽ࠨ੔")+VrnhdEezI7
					A7Ap2wdlxM.append(pMAWqrwP80lR)
					duef0gb3Mi1AV5WpN8.append(fCXyTlcmF4WuetVork)
				return iiy37aKq0pCEIOwfcTh61xb4U,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8
			else: return Y41NvKfOroMzGB8sEHy7wbXlc5(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ੕"),[iiy37aKq0pCEIOwfcTh61xb4U],[eCGwzSrqBmIv]
	eCGwzSrqBmIv = url+ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠧࡽࡔࡨࡪࡪࡸࡥࡳ࠿ࠪ੖")+UM3q9WaVXOP4ZuhCnHB5jyA
	if uuExaKGL7UONtevRd(u"ࠨࡪࡷࡸࡵ࠭੗") not in eCGwzSrqBmIv: eCGwzSrqBmIv = xpT28sXu051(u"ࠩ࡫ࡸࡹࡶ࠺ࠨ੘")+eCGwzSrqBmIv
	return iiy37aKq0pCEIOwfcTh61xb4U,[iiy37aKq0pCEIOwfcTh61xb4U],[eCGwzSrqBmIv]
def wwOnS4C9YdTsVLRoXqWbk2ZAu3iy7m(fCXyTlcmF4WuetVork):
	UM3q9WaVXOP4ZuhCnHB5jyA = F82MvyX4ThI6sbnA3efDoVS(fCXyTlcmF4WuetVork,TlGXWLYsV1z(u"ࠪࡹࡷࡲࠧਖ਼"))
	if hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠫࡵࡵࡳࡵ࡫ࡧࠫਗ਼") in fCXyTlcmF4WuetVork:
		ng8RFTvpBOxuMa2ySjYWqVZX = dEyT9xhGjolYzLCH7460w3.findall(Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠬ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩ࡝ࡁࡳࡳࡸࡺࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠧࡵࡨࡶࡻ࡫ࡲࡪࡦࡀࠬ࠳࠰࠿ࠪࠨࠩࠫਜ਼"),fCXyTlcmF4WuetVork+vODxLKW5Ql6r4Fbm8(u"࠭ࠦࠧࠩੜ"),dEyT9xhGjolYzLCH7460w3.DOTALL)
		url,VlX2C0mPxeyD8wZYKLuf,w7dRclJi29IUOqP = ng8RFTvpBOxuMa2ySjYWqVZX[FGTfwsjNrB8DvKSZhLIQAb1JnO]
		data = {UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠧࡪࡦࠪ੝"):VlX2C0mPxeyD8wZYKLuf,L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠨࡵࡨࡶࡻ࡫ࡲࠨਫ਼"):w7dRclJi29IUOqP}
		oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠩࡓࡓࡘ࡚ࠧ੟"),url,data,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,zmcGfOdvAjsELeJlP(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡃࡊࡏࡄࡒࡔ࡝࠭࠲ࡵࡷࠫ੠"))
		Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
		eCGwzSrqBmIv = dEyT9xhGjolYzLCH7460w3.findall(MgP8OjoaiWQEVG59(u"ࠫ࡮࡬ࡲࡢ࡯ࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ੡"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)[FGTfwsjNrB8DvKSZhLIQAb1JnO]
		if FRYcH4KL7e9gv5pEB(u"ࠬࡩࡩ࡮ࡣࡱࡳࡼ࠭੢") in eCGwzSrqBmIv:
			headers = {L90uqo28xEKSFUwYTcm51yRWZIkft(u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧ੣"):UM3q9WaVXOP4ZuhCnHB5jyA,HtK4o2sTPgA78U(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ੤"):iiy37aKq0pCEIOwfcTh61xb4U}
			oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠨࡉࡈࡘࠬ੥"),eCGwzSrqBmIv,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡉࡉࡎࡃࡑࡓ࡜࠳࠲࡯ࡦࠪ੦"))
			z0spMAOfJElv6L1K9ae = oCJ8TdG2LwSIVcbaUnhB.content
			items = dEyT9xhGjolYzLCH7460w3.findall(uuExaKGL7UONtevRd(u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷ࡮ࢀࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ੧"),z0spMAOfJElv6L1K9ae,dEyT9xhGjolYzLCH7460w3.DOTALL)
			A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = [],[]
			VrnhdEezI7 = F82MvyX4ThI6sbnA3efDoVS(eCGwzSrqBmIv,ZchUJdM93pTA7zG5(u"ࠫࡺࡸ࡬ࠨ੨"))
			for fCXyTlcmF4WuetVork,pMAWqrwP80lR in reversed(items):
				fCXyTlcmF4WuetVork = VrnhdEezI7+fCXyTlcmF4WuetVork+ZchUJdM93pTA7zG5(u"ࠬࢂࡒࡦࡨࡨࡶࡪࡸ࠽ࠨ੩")+VrnhdEezI7
				A7Ap2wdlxM.append(pMAWqrwP80lR)
				duef0gb3Mi1AV5WpN8.append(fCXyTlcmF4WuetVork)
			return iiy37aKq0pCEIOwfcTh61xb4U,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8
		else: return AbqCJZdWQP9j(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ੪"),[iiy37aKq0pCEIOwfcTh61xb4U],[eCGwzSrqBmIv]
	else:
		fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork+jXE2YHkswT8y(u"ࠧࡽࡔࡨࡪࡪࡸࡥࡳ࠿ࠪ੫")+UM3q9WaVXOP4ZuhCnHB5jyA
		return iiy37aKq0pCEIOwfcTh61xb4U,[iiy37aKq0pCEIOwfcTh61xb4U],[fCXyTlcmF4WuetVork]
def nmXJxRS1VU(fCXyTlcmF4WuetVork):
	if XrTw01KtLzbpoyMf(u"ࠨࡲࡲࡷࡹ࡯ࡤࠨ੬") in fCXyTlcmF4WuetVork:
		ng8RFTvpBOxuMa2ySjYWqVZX = dEyT9xhGjolYzLCH7460w3.findall(ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠩࡳࡳࡸࡺࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠧࡵࡨࡶࡻ࡫ࡲࡪࡦࡀࠬ࠳࠰࠿ࠪࠨࠩࠫ੭"),fCXyTlcmF4WuetVork+SaB5hx3PZwXRLtKgrTfQvId(u"ࠪࠪࠫ࠭੮"),dEyT9xhGjolYzLCH7460w3.DOTALL|dEyT9xhGjolYzLCH7460w3.IGNORECASE)
		VlX2C0mPxeyD8wZYKLuf,w7dRclJi29IUOqP = ng8RFTvpBOxuMa2ySjYWqVZX[FGTfwsjNrB8DvKSZhLIQAb1JnO]
		oGIOdU6Ci18xc3vkBNTm4efRzhLE = F82MvyX4ThI6sbnA3efDoVS(fCXyTlcmF4WuetVork,IpC4qHXRuyNFjzWv(u"ࠫࡺࡸ࡬ࠨ੯"))
		url = oGIOdU6Ci18xc3vkBNTm4efRzhLE+FRYcH4KL7e9gv5pEB(u"ࠬ࠵ࡡ࡫ࡣࡻࡇࡪࡴࡴࡦࡴࡂࡣࡦࡩࡴࡪࡱࡱࡁ࡬࡫ࡴࡴࡧࡵࡺࡪࡸࠦࡠࡲࡲࡷࡹࡥࡩࡥ࠿ࠪੰ")+VlX2C0mPxeyD8wZYKLuf+Y41NvKfOroMzGB8sEHy7wbXlc5(u"࠭ࠦࡴࡧࡵࡺࡪࡸࡩࡥ࠿ࠪੱ")+w7dRclJi29IUOqP
		headers = { CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫੲ"):iiy37aKq0pCEIOwfcTh61xb4U , HtK4o2sTPgA78U(u"ࠨ࡚࠰ࡖࡪࡷࡵࡦࡵࡷࡩࡩ࠳ࡗࡪࡶ࡫ࠫੳ"):PtkEvXAqif14G20QZsaSyT(u"࡛ࠩࡑࡑࡎࡴࡵࡲࡕࡩࡶࡻࡥࡴࡶࠪੴ") }
		eCGwzSrqBmIv = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(r3rnfZ7cdxzNFebIRaLSG6B,url,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,ZchUJdM93pTA7zG5(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡓࡄࡏࡍࡔࡔ࡚࠮࠳ࡶࡸࠬੵ"))
		eCGwzSrqBmIv = eCGwzSrqBmIv.replace(OTlVEGYPSxsNaBdXUucqA3,iiy37aKq0pCEIOwfcTh61xb4U).replace(Mge0HhFk9Ic6sm5VR,iiy37aKq0pCEIOwfcTh61xb4U)
		return EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ੶"),[iiy37aKq0pCEIOwfcTh61xb4U],[eCGwzSrqBmIv]
	elif tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠬ࠵ࡲࡦࡦ࡬ࡶࡪࡩࡴ࠰ࠩ੷") in fCXyTlcmF4WuetVork:
		d95dmOUNYHZsquy = FGTfwsjNrB8DvKSZhLIQAb1JnO
		while uuExaKGL7UONtevRd(u"࠭࠯ࡳࡧࡧ࡭ࡷ࡫ࡣࡵ࠱ࠪ੸") in fCXyTlcmF4WuetVork and d95dmOUNYHZsquy<FRYcH4KL7e9gv5pEB(u"࠹๑"):
			oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(Dxc7GChQwZ4kOlKHSbL06agnB,hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠧࡈࡇࡗࠫ੹"),fCXyTlcmF4WuetVork,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,xpT28sXu051(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡘࡂࡍࡋࡒࡒ࡟࠳࠲࡯ࡦࠪ੺"))
			if jXE2YHkswT8y(u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ੻") in list(oCJ8TdG2LwSIVcbaUnhB.headers.keys()): fCXyTlcmF4WuetVork = oCJ8TdG2LwSIVcbaUnhB.headers[SaB5hx3PZwXRLtKgrTfQvId(u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ੼")]
			d95dmOUNYHZsquy += YYJQyRskpX8jv
		return iiy37aKq0pCEIOwfcTh61xb4U,[iiy37aKq0pCEIOwfcTh61xb4U],[fCXyTlcmF4WuetVork]
	else: return zmcGfOdvAjsELeJlP(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡁࡓࡄࡏࡍࡔࡔ࡚ࠨ੽"),[],[]
def sRIEkLr634(url):
	Zw4M5DUStdE6xp7GI = F82MvyX4ThI6sbnA3efDoVS(url,uuExaKGL7UONtevRd(u"ࠬࡻࡲ࡭ࠩ੾"))
	headers = {FRYcH4KL7e9gv5pEB(u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧ੿"):Zw4M5DUStdE6xp7GI,YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ઀"):FgJLkYac7lQxEbs()}
	if yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠨ࠱ࡨࡱࡧ࡫ࡤ࠮ࠩઁ") in url:
		Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(r3rnfZ7cdxzNFebIRaLSG6B,url,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,XrTw01KtLzbpoyMf(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡒࡂࡄࡖࡉࡊࡊ࠭࠳ࡰࡧࠫં"))
		fCXyTlcmF4WuetVork = dEyT9xhGjolYzLCH7460w3.findall(hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠪࡀࡸࡵࡵࡳࡥࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩઃ"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if fCXyTlcmF4WuetVork:
			fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork[FGTfwsjNrB8DvKSZhLIQAb1JnO].replace(PtkEvXAqif14G20QZsaSyT(u"ࠫ࡭ࡺࡴࡱࡵࠪ઄"),FRYcH4KL7e9gv5pEB(u"ࠬ࡮ࡴࡵࡲࠪઅ"))
			return iiy37aKq0pCEIOwfcTh61xb4U,[iiy37aKq0pCEIOwfcTh61xb4U],[fCXyTlcmF4WuetVork]
	else:
		xMZNnh9PgqGlT17iKIsHUdc0D6o8 = MMCJxEfv0WUek(Dxc7GChQwZ4kOlKHSbL06agnB,vODxLKW5Ql6r4Fbm8(u"࠭ࡇࡆࡖࠪઆ"),url,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡗࡇࡂࡔࡇࡈࡈ࠲࠹ࡲࡥࠩઇ"))
		Vxz6OndPIX4g2kaRp7 = xMZNnh9PgqGlT17iKIsHUdc0D6o8.content
		rzR9SN7ApZuQhTDWEX3V6ga = headers.copy()
		if tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠨࡡ࡯ࡲࡰࡥࠧઈ") in str(xMZNnh9PgqGlT17iKIsHUdc0D6o8.cookies):
			cookies = xMZNnh9PgqGlT17iKIsHUdc0D6o8.cookies
			rzR9SN7ApZuQhTDWEX3V6ga[tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠩࡆࡳࡴࡱࡩࡦࠩઉ")] = a9I3YZjc6ySDPE4Kp(zzUnMebTFdNgB8hOwJmKxVj(cookies))
		fCXyTlcmF4WuetVork = dEyT9xhGjolYzLCH7460w3.findall(uuExaKGL7UONtevRd(u"ࠪࡰ࡮ࡴ࡫࠯ࡪࡵࡩ࡫ࠦ࠽ࠡࠤࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭ࠧ࠭ઊ"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if not fCXyTlcmF4WuetVork: return MgP8OjoaiWQEVG59(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧઋ"),[iiy37aKq0pCEIOwfcTh61xb4U],[url]
		else:
			fCXyTlcmF4WuetVork = a9I3YZjc6ySDPE4Kp(fCXyTlcmF4WuetVork[FGTfwsjNrB8DvKSZhLIQAb1JnO])+MgP8OjoaiWQEVG59(u"ࠬࠬࡤ࠾࠳ࠪઌ")
			xQoYJsjSm0yfdzaOewV7pC = MMCJxEfv0WUek(Dxc7GChQwZ4kOlKHSbL06agnB,EMO8gy4LrsNTh0knZwpSeU75APW(u"࠭ࡇࡆࡖࠪઍ"),fCXyTlcmF4WuetVork,iiy37aKq0pCEIOwfcTh61xb4U,rzR9SN7ApZuQhTDWEX3V6ga,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡗࡇࡂࡔࡇࡈࡈ࠲࠺ࡴࡩࠩ઎"))
			Vxz6OndPIX4g2kaRp7 = xQoYJsjSm0yfdzaOewV7pC.content
			fCXyTlcmF4WuetVork = dEyT9xhGjolYzLCH7460w3.findall(TlGXWLYsV1z(u"ࠨ࡫ࡧࡁࠧࡨࡴ࡯ࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫએ"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
			if fCXyTlcmF4WuetVork:
				fCXyTlcmF4WuetVork = a9I3YZjc6ySDPE4Kp(fCXyTlcmF4WuetVork[FGTfwsjNrB8DvKSZhLIQAb1JnO])
				if FRYcH4KL7e9gv5pEB(u"ࠩࡰࡴ࠹࠭ઐ") in fCXyTlcmF4WuetVork and SaB5hx3PZwXRLtKgrTfQvId(u"ࠪ࠳ࡩ࠵ࠧઑ") in fCXyTlcmF4WuetVork: return iiy37aKq0pCEIOwfcTh61xb4U,[iiy37aKq0pCEIOwfcTh61xb4U],[fCXyTlcmF4WuetVork]
				else: return zmcGfOdvAjsELeJlP(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ઒"),[iiy37aKq0pCEIOwfcTh61xb4U],[fCXyTlcmF4WuetVork]
	return AbqCJZdWQP9j(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡂࡔࡄࡆࡘࡋࡅࡅࠩઓ"),[],[]
def vvcSWtyJxw(fCXyTlcmF4WuetVork):
	if AbqCJZdWQP9j(u"࠭࡟ࡢࡥࡷ࡭ࡴࡴ࠽ࡨࡧࡷࡷࡪࡸࡶࡦࡴࠪઔ") in fCXyTlcmF4WuetVork:
		headers = {xpT28sXu051(u"࡙ࠧ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪࠪક"):hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠨ࡚ࡐࡐࡍࡺࡴࡱࡔࡨࡵࡺ࡫ࡳࡵࠩખ")}
		oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,vODxLKW5Ql6r4Fbm8(u"ࠩࡊࡉ࡙࠭ગ"),fCXyTlcmF4WuetVork,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡓࡉࡃࡋࡍࡉ࠺ࡕ࠮࠳ࡶࡸࠬઘ"))
		url = oCJ8TdG2LwSIVcbaUnhB.content
		if url: return XrTw01KtLzbpoyMf(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧઙ"),[iiy37aKq0pCEIOwfcTh61xb4U],[url]
	else:
		ng8RFTvpBOxuMa2ySjYWqVZX = dEyT9xhGjolYzLCH7460w3.findall(FRYcH4KL7e9gv5pEB(u"ࠬࡶ࡯ࡴࡶ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠪࡸ࡫ࡲࡷࡧࡵ࡭ࡩࡃࠨ࠯ࠬࡂ࠭ࠩ࠭ચ"),fCXyTlcmF4WuetVork,dEyT9xhGjolYzLCH7460w3.DOTALL|dEyT9xhGjolYzLCH7460w3.IGNORECASE)
		if not ng8RFTvpBOxuMa2ySjYWqVZX: ng8RFTvpBOxuMa2ySjYWqVZX = dEyT9xhGjolYzLCH7460w3.findall(ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"࠭࡟ࡱࡱࡶࡸࡤ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠦࡴࡧࡵࡺࡪࡸࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠥࠩછ"),fCXyTlcmF4WuetVork,dEyT9xhGjolYzLCH7460w3.DOTALL|dEyT9xhGjolYzLCH7460w3.IGNORECASE)
		VlX2C0mPxeyD8wZYKLuf,w7dRclJi29IUOqP = ng8RFTvpBOxuMa2ySjYWqVZX[FGTfwsjNrB8DvKSZhLIQAb1JnO]
		Zw4M5DUStdE6xp7GI = F82MvyX4ThI6sbnA3efDoVS(fCXyTlcmF4WuetVork,vODxLKW5Ql6r4Fbm8(u"ࠧࡶࡴ࡯ࠫજ"))
		url = Zw4M5DUStdE6xp7GI+PtkEvXAqif14G20QZsaSyT(u"ࠨ࠱ࡺࡴ࠲ࡩ࡯࡯ࡶࡨࡲࡹ࠵ࡴࡩࡧࡰࡩࡸ࠵ࡴࡩࡧࡰࡩ࠴ࡇࡪࡢࡺࡤࡸ࠴࡙ࡩ࡯ࡩ࡯ࡩ࠴࡙ࡥࡳࡸࡨࡶ࠳ࡶࡨࡱࠩઝ")
		data = {UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠩ࡬ࡨࠬઞ"):VlX2C0mPxeyD8wZYKLuf,zmcGfOdvAjsELeJlP(u"ࠪ࡭ࠬટ"):w7dRclJi29IUOqP}
		headers = {y6y5HtgXO4TkUbwVZ(u"ࠫ࡝࠳ࡒࡦࡳࡸࡩࡸࡺࡥࡥ࠯࡚࡭ࡹ࡮ࠧઠ"):LyNiIHPOwD3hCUYEFM7(u"ࠬ࡞ࡍࡍࡊࡷࡸࡵࡘࡥࡲࡷࡨࡷࡹ࠭ડ"),LyNiIHPOwD3hCUYEFM7(u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧઢ"):fCXyTlcmF4WuetVork}
		oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,sVzojQerUqX(u"ࠧࡑࡑࡖࡘࠬણ"),url,data,headers,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,PtkEvXAqif14G20QZsaSyT(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡘࡎࡁࡉࡋࡇ࠸࡚࠳࠲࡯ࡦࠪત"))
		z0spMAOfJElv6L1K9ae = oCJ8TdG2LwSIVcbaUnhB.content
		eCGwzSrqBmIv = dEyT9xhGjolYzLCH7460w3.findall(CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧથ"),z0spMAOfJElv6L1K9ae,dEyT9xhGjolYzLCH7460w3.DOTALL|dEyT9xhGjolYzLCH7460w3.IGNORECASE)
		if eCGwzSrqBmIv:
			eCGwzSrqBmIv = eCGwzSrqBmIv[FGTfwsjNrB8DvKSZhLIQAb1JnO]
			return tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭દ"),[iiy37aKq0pCEIOwfcTh61xb4U],[eCGwzSrqBmIv]
	return UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡓࡉࡃࡋࡍࡉ࠺ࡕࠨધ"),[],[]
def jRQDTbql6I(oMktqPXryR7v):
	NeLJxDGoFlay2E3 = OXsckY7RzjCag9A.getSetting(xpT28sXu051(u"ࠬࡧࡶ࠯ࡣ࡮ࡻࡦࡳ࠮ࡷࡧࡵ࡭࡫࡯ࡣࡢࡶ࡬ࡳࡳ࠭ન"))
	headers = {xpT28sXu051(u"࠭ࡃࡰࡱ࡮࡭ࡪ࠭઩"):NeLJxDGoFlay2E3} if NeLJxDGoFlay2E3 else iiy37aKq0pCEIOwfcTh61xb4U
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(Dxc7GChQwZ4kOlKHSbL06agnB,AbqCJZdWQP9j(u"ࠧࡈࡇࡗࠫપ"),oMktqPXryR7v,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,MgP8OjoaiWQEVG59(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡇ࡟ࡐࡂࡕࡖࡣࡆࡑࡗࡂࡏࡢࡇࡆࡖࡔࡄࡊࡄ࠱࠶ࡹࡴࠨફ"))
	lRnjFoXHBfO = oCJ8TdG2LwSIVcbaUnhB.content
	IENZqBv29lU3dQfchgHy5LRKATDX8 = str(oCJ8TdG2LwSIVcbaUnhB.headers)
	qouKrBJsMcRDUAf6HZ4e7 = IENZqBv29lU3dQfchgHy5LRKATDX8+lRnjFoXHBfO
	if PtkEvXAqif14G20QZsaSyT(u"ࠩ࠱ࡱࡵ࠺ࠧબ") in qouKrBJsMcRDUAf6HZ4e7: ODImXaV12yknNJH4fp7Y = rGPen6cSMHQkAywh8vqI9JXiD2
	else:
		dtZQc2os1pmxkrDlNvAF7by3ESgzB,XV3cU4Ez5kgM0YtHNedhuRGB879lpT,ACw698eRzxIPkV7pmoX,rDHK8IWCmSlNpEB1a,ODImXaV12yknNJH4fp7Y = iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,BF6QAiLUNHh7rKOugaw
		captcha = dEyT9xhGjolYzLCH7460w3.findall(HtK4o2sTPgA78U(u"ࠪࡴࡦ࡭ࡥ࠮ࡴࡨࡨ࡮ࡸࡥࡤࡶ࠱࠮ࡄࡧࡣࡵ࡫ࡲࡲࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡦࡤࡸࡦ࠳ࡳࡪࡶࡨ࡯ࡪࡿ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨભ"),lRnjFoXHBfO,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if captcha: ACw698eRzxIPkV7pmoX,rDHK8IWCmSlNpEB1a = captcha[FGTfwsjNrB8DvKSZhLIQAb1JnO]
		Ijbrs5fJEyOTWDMKguSRFw97lz = gZ4LwbKaOm[tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠫࡕ࡟ࡔࡉࡑࡑࠫમ")][PtkEvXAqif14G20QZsaSyT(u"࠼๒")]
		if FGTfwsjNrB8DvKSZhLIQAb1JnO:
			data = {JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠬࡻࡳࡦࡴࠪય"):iw3BpJl1Y9tbg8XMR4VeoS6kEUhf,ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"࠭ࡶࡦࡴࡶ࡭ࡴࡴࠧર"):DdAjF5pBNL9IqPgkz0xhcQEfU,vODxLKW5Ql6r4Fbm8(u"ࠧࡶࡴ࡯ࠫ઱"):oMktqPXryR7v,tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠨ࡭ࡨࡽࠬલ"):rDHK8IWCmSlNpEB1a,ZchUJdM93pTA7zG5(u"ࠩ࡬ࡨࠬળ"):iiy37aKq0pCEIOwfcTh61xb4U,EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠪ࡮ࡴࡨࠧ઴"):tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠫ࡬࡫ࡴࡶࡴ࡯ࡷࠬવ")}
			oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(hI7SkXd94fFzAHNZCQoMqEutbnWP,jXE2YHkswT8y(u"ࠬࡖࡏࡔࡖࠪશ"),Ijbrs5fJEyOTWDMKguSRFw97lz,data,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡅ࡝ࡕࡇࡓࡔࡡࡄࡏ࡜ࡇࡍࡠࡅࡄࡔ࡙ࡉࡈࡂ࠯࠵ࡲࡩ࠭ષ"))
			Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
		Vxz6OndPIX4g2kaRp7 = iiy37aKq0pCEIOwfcTh61xb4U
		if Vxz6OndPIX4g2kaRp7.startswith(ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠧࡖࡔࡏࡗࡂ࠭સ")):
			ddysUlpTPGoEQeXhfNjC = DeIL3qoa2UBtYPb(sVzojQerUqX(u"ࠨ࡮࡬ࡷࡹ࠭હ"),Vxz6OndPIX4g2kaRp7.split(y6y5HtgXO4TkUbwVZ(u"ࠩࡘࡖࡑ࡙࠽ࠨ઺"),YYJQyRskpX8jv)[YYJQyRskpX8jv])
			for lHDuLVCy8kvqB6Rxh4Gs5K in ddysUlpTPGoEQeXhfNjC:
				url = lHDuLVCy8kvqB6Rxh4Gs5K[hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠪࡹࡷࡲࠧ઻")]
				xR0giHpZE1TcFjb4GS2d3aOwULzMk = lHDuLVCy8kvqB6Rxh4Gs5K[xpT28sXu051(u"ࠫࡲ࡫ࡴࡩࡱࡧ઼ࠫ")]
				data = lHDuLVCy8kvqB6Rxh4Gs5K[L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠬࡪࡡࡵࡣࠪઽ")]
				headers = lHDuLVCy8kvqB6Rxh4Gs5K[sVzojQerUqX(u"࠭ࡨࡦࡣࡧࡩࡷࡹࠧા")]
				oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(hI7SkXd94fFzAHNZCQoMqEutbnWP,xR0giHpZE1TcFjb4GS2d3aOwULzMk,url,data,headers,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,uuExaKGL7UONtevRd(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡆ࡞ࡖࡁࡔࡕࡢࡅࡐ࡝ࡁࡎࡡࡆࡅࡕ࡚ࡃࡉࡃ࠰࠷ࡷࡪࠧિ"))
				lRnjFoXHBfO = oCJ8TdG2LwSIVcbaUnhB.content
				if vODxLKW5Ql6r4Fbm8(u"ࠨ࠰ࡰࡴ࠹࠭ી") in lRnjFoXHBfO:
					ODImXaV12yknNJH4fp7Y = rGPen6cSMHQkAywh8vqI9JXiD2
					break
				IENZqBv29lU3dQfchgHy5LRKATDX8 = str(oCJ8TdG2LwSIVcbaUnhB.headers)
				qouKrBJsMcRDUAf6HZ4e7 = IENZqBv29lU3dQfchgHy5LRKATDX8+lRnjFoXHBfO
				dtZQc2os1pmxkrDlNvAF7by3ESgzB = dEyT9xhGjolYzLCH7460w3.findall(AbqCJZdWQP9j(u"ࠩࠫࡥࡰࡽࡡ࡮ࡘࡨࡶ࡮࡬ࡩࡤࡣࡷ࡭ࡴࡴ࡜ࡸ࠭ࠬ࠲࠯ࡅࠢࠩࡧࡼࡎ࠳࠰࠿ࠪࠤࠪુ"),qouKrBJsMcRDUAf6HZ4e7,dEyT9xhGjolYzLCH7460w3.DOTALL)
				XV3cU4Ez5kgM0YtHNedhuRGB879lpT = dEyT9xhGjolYzLCH7460w3.findall(EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠪࡶࡪࡩࡡࡱࡶࡦ࡬ࡦ࠳ࡴࡰ࡭ࡨࡲ࠳࠰࠿ࠣࠪ࠳࠷ࡆ࠴ࠪࡀࠫࠥࠫૂ"),qouKrBJsMcRDUAf6HZ4e7,dEyT9xhGjolYzLCH7460w3.DOTALL)
				if XV3cU4Ez5kgM0YtHNedhuRGB879lpT: XV3cU4Ez5kgM0YtHNedhuRGB879lpT = XV3cU4Ez5kgM0YtHNedhuRGB879lpT[FGTfwsjNrB8DvKSZhLIQAb1JnO]
				if dtZQc2os1pmxkrDlNvAF7by3ESgzB or XV3cU4Ez5kgM0YtHNedhuRGB879lpT: break
		if not ODImXaV12yknNJH4fp7Y:
			if not dtZQc2os1pmxkrDlNvAF7by3ESgzB:
				if captcha and not XV3cU4Ez5kgM0YtHNedhuRGB879lpT:
					if YYJQyRskpX8jv: XV3cU4Ez5kgM0YtHNedhuRGB879lpT = xEw7j5Grt1zhZ(rDHK8IWCmSlNpEB1a,hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠫࡦࡸࠧૃ"),oMktqPXryR7v)
					else:
						if not Vxz6OndPIX4g2kaRp7.startswith(HtK4o2sTPgA78U(u"ࠬࡏࡄ࠾ࠩૄ")):
							data = {sVzojQerUqX(u"࠭ࡵࡴࡧࡵࠫૅ"):iw3BpJl1Y9tbg8XMR4VeoS6kEUhf,XrTw01KtLzbpoyMf(u"ࠧࡷࡧࡵࡷ࡮ࡵ࡮ࠨ૆"):DdAjF5pBNL9IqPgkz0xhcQEfU,XrTw01KtLzbpoyMf(u"ࠨࡷࡵࡰࠬે"):oMktqPXryR7v,IpC4qHXRuyNFjzWv(u"ࠩ࡮ࡩࡾ࠭ૈ"):rDHK8IWCmSlNpEB1a,sVzojQerUqX(u"ࠪ࡭ࡩ࠭ૉ"):iiy37aKq0pCEIOwfcTh61xb4U,EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠫ࡯ࡵࡢࠨ૊"):UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠬ࡭ࡥࡵ࡫ࡧࠫો")}
							oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(hI7SkXd94fFzAHNZCQoMqEutbnWP,ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"࠭ࡐࡐࡕࡗࠫૌ"),Ijbrs5fJEyOTWDMKguSRFw97lz,data,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,y6y5HtgXO4TkUbwVZ(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡆ࡞ࡖࡁࡔࡕࡢࡅࡐ࡝ࡁࡎࡡࡆࡅࡕ࡚ࡃࡉࡃ࠰࠸ࡹ࡮્ࠧ"))
							Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
						else: Vxz6OndPIX4g2kaRp7 = ZchUJdM93pTA7zG5(u"ࠨࡋࡇࡁ࠶࠸࠳࠵࠼࠽࠾࠿࡚ࡉࡎࡇࡒ࡙࡙ࡃ࠴࠶ࠩ૎")
						if Vxz6OndPIX4g2kaRp7.startswith(TlGXWLYsV1z(u"ࠩࡌࡈࡂ࠭૏")):
							nn31zlmfXFJA9B8ybhWLIgk2Ne = dEyT9xhGjolYzLCH7460w3.findall(LyNiIHPOwD3hCUYEFM7(u"ࠪࡍࡉࡃࠨ࠯ࠬࡂ࠭࠿ࡀ࠺࠻ࡖࡌࡑࡊࡕࡕࡕ࠿ࠫ࠲࠯ࡅࠩࠥࠩૐ"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
							vvfmPOlod3rVzyFKc812S4NJxYQ7,ff23ICqELcvWaZYm4suDzHnU = nn31zlmfXFJA9B8ybhWLIgk2Ne[FGTfwsjNrB8DvKSZhLIQAb1JnO]
							aZtYlicqMKUFPkBCX2AONHwJ4 = zmcGfOdvAjsELeJlP(u"ࠫ์ึ็ࠡษ็฽๊๊๊สࠢอัฯอฬ๊ࠡๅฮ๋ࠥๆࠡ࠳࠳ࠤส๊้ࠡࠩ૑")+ff23ICqELcvWaZYm4suDzHnU+HtK4o2sTPgA78U(u"ࠬࠦหศ่ํอࠬ૒")
							sspk8CPTnaqeyzALQuD6ExX = BH5w8KScjpRhAkI7PlqDU()
							sspk8CPTnaqeyzALQuD6ExX.create(HtK4o2sTPgA78U(u"࠭ๅฮษ๋่ฮࠦสอษ๋ึࠥ็อึࠢฦ๊ฬࠦร็ีส๊ࠥ๎ไิฬࠣฬึ์วๆฮࠣ็ํ๋ศ๋๊อีࠬ૓"),aZtYlicqMKUFPkBCX2AONHwJ4)
							aHjMv035eKufFkEr = X2cQ5NCPvkMieBW7oASspFjE.time()
							Eeit5k2PbfH0YzILCSN,fHhzAX3bTDZuJd0r18G = FGTfwsjNrB8DvKSZhLIQAb1JnO,FGTfwsjNrB8DvKSZhLIQAb1JnO
							while Eeit5k2PbfH0YzILCSN<int(ff23ICqELcvWaZYm4suDzHnU):
								o8oBqwQFbU2uL3SEGD0lgWO4xRnJYC(sspk8CPTnaqeyzALQuD6ExX,int(Eeit5k2PbfH0YzILCSN/int(ff23ICqELcvWaZYm4suDzHnU)*FRYcH4KL7e9gv5pEB(u"࠷࠰࠱๓")),aZtYlicqMKUFPkBCX2AONHwJ4,iiy37aKq0pCEIOwfcTh61xb4U,ff23ICqELcvWaZYm4suDzHnU+ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠧࠡ࠱ࠣࠫ૔")+str(int(Eeit5k2PbfH0YzILCSN))+XrTw01KtLzbpoyMf(u"ࠨࠢࠣฯฬ์๊สࠩ૕"))
								if Eeit5k2PbfH0YzILCSN>fHhzAX3bTDZuJd0r18G+ZchUJdM93pTA7zG5(u"࠱࠱๔"):
									data = {jXE2YHkswT8y(u"ࠩࡸࡷࡪࡸࠧ૖"):iw3BpJl1Y9tbg8XMR4VeoS6kEUhf,L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫ૗"):DdAjF5pBNL9IqPgkz0xhcQEfU,L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠫࡺࡸ࡬ࠨ૘"):oMktqPXryR7v,tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠬࡱࡥࡺࠩ૙"):rDHK8IWCmSlNpEB1a,LyNiIHPOwD3hCUYEFM7(u"࠭ࡩࡥࠩ૚"):vvfmPOlod3rVzyFKc812S4NJxYQ7,TlGXWLYsV1z(u"ࠧ࡫ࡱࡥࠫ૛"):ZchUJdM93pTA7zG5(u"ࠨࡩࡨࡸࡹࡵ࡫ࡦࡰࠪ૜")}
									oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(hI7SkXd94fFzAHNZCQoMqEutbnWP,tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠩࡓࡓࡘ࡚ࠧ૝"),Ijbrs5fJEyOTWDMKguSRFw97lz,data,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡂ࡚ࡒࡄࡗࡘࡥࡁࡌ࡙ࡄࡑࡤࡉࡁࡑࡖࡆࡌࡆ࠳࠵ࡵࡪࠪ૞"))
									Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
									if Vxz6OndPIX4g2kaRp7.startswith(HtK4o2sTPgA78U(u"࡙ࠫࡕࡋࡆࡐࡀࠫ૟")):
										XV3cU4Ez5kgM0YtHNedhuRGB879lpT = Vxz6OndPIX4g2kaRp7.split(uuExaKGL7UONtevRd(u"࡚ࠬࡏࡌࡇࡑࡁࠬૠ"),EMO8gy4LrsNTh0knZwpSeU75APW(u"࠲๕"))[YYJQyRskpX8jv]
										break
									fHhzAX3bTDZuJd0r18G = Eeit5k2PbfH0YzILCSN
								else: X2cQ5NCPvkMieBW7oASspFjE.sleep(YYJQyRskpX8jv)
								Eeit5k2PbfH0YzILCSN = X2cQ5NCPvkMieBW7oASspFjE.time()-aHjMv035eKufFkEr
							sspk8CPTnaqeyzALQuD6ExX.close()
				if XV3cU4Ez5kgM0YtHNedhuRGB879lpT:
					k2sTUcM9aKjyp5IJOWL6Nt7r1o = oCJ8TdG2LwSIVcbaUnhB.cookies
					qa1uMOdN7cKLvb86QrSyGWpkV4 = dEyT9xhGjolYzLCH7460w3.findall(uuExaKGL7UONtevRd(u"࠭ࡡ࡬ࡹࡤࡱࡤࡹࡥࡴࡵ࡬ࡳࡳࡃࠨ࠯ࠬࡂ࠭ࡀ࠭ૡ"),qouKrBJsMcRDUAf6HZ4e7,dEyT9xhGjolYzLCH7460w3.DOTALL)
					if UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠧࡢ࡭ࡺࡥࡲࡥࡳࡦࡵࡶ࡭ࡴࡴࠧૢ") in list(k2sTUcM9aKjyp5IJOWL6Nt7r1o.keys()): qa1uMOdN7cKLvb86QrSyGWpkV4 = k2sTUcM9aKjyp5IJOWL6Nt7r1o[xpT28sXu051(u"ࠨࡣ࡮ࡻࡦࡳ࡟ࡴࡧࡶࡷ࡮ࡵ࡮ࠨૣ")]
					elif qa1uMOdN7cKLvb86QrSyGWpkV4: qa1uMOdN7cKLvb86QrSyGWpkV4 = qa1uMOdN7cKLvb86QrSyGWpkV4[FGTfwsjNrB8DvKSZhLIQAb1JnO]
					captcha = dEyT9xhGjolYzLCH7460w3.findall(TlGXWLYsV1z(u"ࠩࡳࡥ࡬࡫࠭ࡳࡧࡧ࡭ࡷ࡫ࡣࡵ࠰࠭ࡃࡦࡩࡴࡪࡱࡱࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡥࡣࡷࡥ࠲ࡹࡩࡵࡧ࡮ࡩࡾࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ૤"),lRnjFoXHBfO,dEyT9xhGjolYzLCH7460w3.DOTALL)
					if captcha: ACw698eRzxIPkV7pmoX,rDHK8IWCmSlNpEB1a = captcha[FGTfwsjNrB8DvKSZhLIQAb1JnO]
					if qa1uMOdN7cKLvb86QrSyGWpkV4 and captcha:
						headers = {TlGXWLYsV1z(u"ࠪࡇࡴࡵ࡫ࡪࡧࠪ૥"):GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠫࡦࡱࡷࡢ࡯ࡢࡷࡪࡹࡳࡪࡱࡱࡁࠬ૦")+qa1uMOdN7cKLvb86QrSyGWpkV4,HtK4o2sTPgA78U(u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭૧"):oMktqPXryR7v,FRYcH4KL7e9gv5pEB(u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ૨"):FRYcH4KL7e9gv5pEB(u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩ࠭૩")}
						data = CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠨࡩ࠰ࡶࡪࡩࡡࡱࡶࡦ࡬ࡦ࠳ࡲࡦࡵࡳࡳࡳࡹࡥ࠾ࠩ૪")+XV3cU4Ez5kgM0YtHNedhuRGB879lpT
						oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(Dxc7GChQwZ4kOlKHSbL06agnB,sVzojQerUqX(u"ࠩࡓࡓࡘ࡚ࠧ૫"),ACw698eRzxIPkV7pmoX,data,headers,BF6QAiLUNHh7rKOugaw,iiy37aKq0pCEIOwfcTh61xb4U,HtK4o2sTPgA78U(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡂ࡚ࡒࡄࡗࡘࡥࡁࡌ࡙ࡄࡑࡤࡉࡁࡑࡖࡆࡌࡆ࠳࠶ࡵࡪࠪ૬"))
						lRnjFoXHBfO = oCJ8TdG2LwSIVcbaUnhB.content
						try: cookies = oCJ8TdG2LwSIVcbaUnhB.cookies
						except: cookies = {}
						dtZQc2os1pmxkrDlNvAF7by3ESgzB = dEyT9xhGjolYzLCH7460w3.findall(ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠦࠬ࠮ࡡ࡬ࡹࡤࡱ࡛࡫ࡲࡪࡨ࡬ࡧࡦࡺࡩࡰࡰ࠱࠮ࡄ࠯ࠧ࠻ࠢࠪࠬ࠳࠰࠿ࠪࠩࠥ૭"),str(cookies),dEyT9xhGjolYzLCH7460w3.DOTALL)
			if dtZQc2os1pmxkrDlNvAF7by3ESgzB:
				JJwnocyLUxHI2jlKF4Y,dtZQc2os1pmxkrDlNvAF7by3ESgzB = dtZQc2os1pmxkrDlNvAF7by3ESgzB[FGTfwsjNrB8DvKSZhLIQAb1JnO]
				NeLJxDGoFlay2E3 = JJwnocyLUxHI2jlKF4Y+AbqCJZdWQP9j(u"ࠬࡃࠧ૮")+dtZQc2os1pmxkrDlNvAF7by3ESgzB
				OXsckY7RzjCag9A.setSetting(L90uqo28xEKSFUwYTcm51yRWZIkft(u"࠭ࡡࡷ࠰ࡤ࡯ࡼࡧ࡭࠯ࡸࡨࡶ࡮࡬ࡩࡤࡣࡷ࡭ࡴࡴࠧ૯"),NeLJxDGoFlay2E3)
				bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ૰"),y6y5HtgXO4TkUbwVZ(u"ࠨ่ฯัฯูࠦๆๆํอࠥ็อึࠢฦ๊ฬࠦล็ีส๊ࠥ࠴࠮๊ࠡๅห๊ࠦวๅสิ๊ฬ๋ฬࠡสัึ๋ࠦๆหษษะࠥํะศࠢส่ๆำีࠡๆๆ๎ࠥ๐ำหะา้์อࠠๅษะๆฬࠦ࠮࠯๋่ࠢฬࠦส้ฮาࠤาอฬสࠢ็ษ฾อฯส๊ࠢิฬࠦวๅใะูู๊ࠥะหࠣวูํัࠡ࡞ࡱࡠࡳูࠦๅ็สࠤศ์่ࠠาสࠤฬ๊แฮืࠣืํ็๋ࠠฬๆีึࠦแ๋ࠢะห้ฯࠠห฼ํีࠥืศุࠢส่ัํวำࠢหห้หๆหำ้ฮࠥ࠴࠮ࠡล๋ࠤส฽แศรࠣีฬ๎สาࠢส่ส์สา่อࠤ࠳࠴ࠠฤ๊ࠣๅฺ๊ࠠิๆๆࠤฬ๊ัศ๊อีࠥ࠴࠮ࠡล๋ࠤฬูสฯัส้ࠥ࡜ࡐࡏࠢฦ์ࠥฮั้ๅึ๎ࠬ૱"))
				if hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠩ࠱ࡱࡵ࠺ࠧ૲") not in lRnjFoXHBfO:
					headers = {GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠪࡇࡴࡵ࡫ࡪࡧࠪ૳"):NeLJxDGoFlay2E3}
					oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(Dxc7GChQwZ4kOlKHSbL06agnB,GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠫࡌࡋࡔࠨ૴"),oMktqPXryR7v,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡄ࡜ࡔࡆ࡙ࡓࡠࡃࡎ࡛ࡆࡓ࡟ࡄࡃࡓࡘࡈࡎࡁ࠮࠹ࡷ࡬ࠬ૵"))
					lRnjFoXHBfO = oCJ8TdG2LwSIVcbaUnhB.content
	if not ODImXaV12yknNJH4fp7Y and not NeLJxDGoFlay2E3: bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,ZchUJdM93pTA7zG5(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ૶"),LyNiIHPOwD3hCUYEFM7(u"ࠧโึ็ฮࠥ฿ๅๅ์ฬࠤๆำีࠡล้หࠥษๆิษ้ࠤ࠳࠴ࠠฮษ๋่ࠥหูศัฬࠤฬู๊ๆๆํอ๋ࠥัสࠢฦาึ๏ࠠษษึฮำีวๆ้ࠢๅุࠦวๅใํำ๏๎ࠠฤ๊ࠣๅ๏ี๊้ࠢ฽๎ึํࠠๆ่๊ࠣๆูࠠศๆ่์็฿ࠧ૷"))
	return lRnjFoXHBfO
def oIeuaPmibU(url,EGJVsZy38Xx,pMAWqrwP80lR):
	ff2PjlcCF5ZWyIUbVguMz,WK130YrED8vNhiHntepuXR = [],[]
	oMktqPXryR7v = url
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(Dxc7GChQwZ4kOlKHSbL06agnB,tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠨࡉࡈࡘࠬ૸"),url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡋࡘࡃࡐ࠱࠶ࡹࡴࠨૹ"))
	z0spMAOfJElv6L1K9ae = oCJ8TdG2LwSIVcbaUnhB.content
	rrq0ogTnNjVe = []
	if L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠪ࠳ࡼࡧࡴࡤࡪ࠲ࠫૺ") in z0spMAOfJElv6L1K9ae or hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠫ࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠯ࠨૻ") in z0spMAOfJElv6L1K9ae:
		ddfSDGyqEc = dEyT9xhGjolYzLCH7460w3.findall(ZchUJdM93pTA7zG5(u"ࠬࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࡩࡶࡷࡴ࠳࠰࠿࠽࠱ࡤࡂࠬૼ"),z0spMAOfJElv6L1K9ae,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if ddfSDGyqEc:
			for PPH1sQtTkDBbnlYpZfo5 in ddfSDGyqEc:
				P3tys0cXWbiIUKk7HQ6n89V = dEyT9xhGjolYzLCH7460w3.findall(Y41NvKfOroMzGB8sEHy7wbXlc5(u"࠭ࡨࡳࡧࡩࡁࠧ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡹࡰࡢࡰ࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ૽"),PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
				for fCXyTlcmF4WuetVork,title in P3tys0cXWbiIUKk7HQ6n89V:
					if fCXyTlcmF4WuetVork in ff2PjlcCF5ZWyIUbVguMz: continue
					if CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠧ࠰ࡹࡤࡸࡨ࡮࠯ࠨ૾") not in fCXyTlcmF4WuetVork and tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠨ࠱ࡧࡳࡼࡴ࡬ࡰࡣࡧ࠳ࠬ૿") not in fCXyTlcmF4WuetVork: continue
					if CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠩสࠫ଀") not in title:
						rrq0ogTnNjVe.append((title,fCXyTlcmF4WuetVork))
						continue
					title = title.replace(GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠪࡀ࠴ࡹࡰࡢࡰࡁࠫଁ"),iiy37aKq0pCEIOwfcTh61xb4U).replace(LyNiIHPOwD3hCUYEFM7(u"ࠫࠥ࠳ࠠࠨଂ"),iiy37aKq0pCEIOwfcTh61xb4U).strip(iFBmE2MUIpSu34wsd7Rf6z).replace(Wc5GekRC0HQLz7,iFBmE2MUIpSu34wsd7Rf6z)
					if xpT28sXu051(u"ࠬࡹࡰࡢࡰࠪଃ") in title: continue
					ff2PjlcCF5ZWyIUbVguMz.append(fCXyTlcmF4WuetVork)
					WK130YrED8vNhiHntepuXR.append(title)
			for title,fCXyTlcmF4WuetVork in rrq0ogTnNjVe:
				if fCXyTlcmF4WuetVork not in ff2PjlcCF5ZWyIUbVguMz:
					ff2PjlcCF5ZWyIUbVguMz.append(fCXyTlcmF4WuetVork)
					WK130YrED8vNhiHntepuXR.append(title)
			mmfrx2S5XqknFTDeRhj49LuYv1wW0 = FGTfwsjNrB8DvKSZhLIQAb1JnO
			if len(ff2PjlcCF5ZWyIUbVguMz)>YYJQyRskpX8jv:
				mmfrx2S5XqknFTDeRhj49LuYv1wW0 = ccv1mVPUsnr(zmcGfOdvAjsELeJlP(u"࠭ศฺุ๊หࠥ๐อหษฯࠤ࠻࠶ࠠฬษ้๎ฮ࠭଄"),WK130YrED8vNhiHntepuXR)
				if mmfrx2S5XqknFTDeRhj49LuYv1wW0==-YYJQyRskpX8jv: return Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠧࡆ࡚ࡌࡘࡤࡇࡌࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬଅ"),[],[]
			if ff2PjlcCF5ZWyIUbVguMz and mmfrx2S5XqknFTDeRhj49LuYv1wW0>=FGTfwsjNrB8DvKSZhLIQAb1JnO: oMktqPXryR7v = ff2PjlcCF5ZWyIUbVguMz[mmfrx2S5XqknFTDeRhj49LuYv1wW0]
	lRnjFoXHBfO = jRQDTbql6I(oMktqPXryR7v)
	duef0gb3Mi1AV5WpN8,A7Ap2wdlxM = [],[]
	if EGJVsZy38Xx==EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦࠪଆ"):
		y5W8dLOsB0Eep3xtZ4Jv = dEyT9xhGjolYzLCH7460w3.findall(XrTw01KtLzbpoyMf(u"ࠩࡥࡸࡳ࠳࡬ࡰࡣࡧࡩࡷ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧଇ"),lRnjFoXHBfO,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if y5W8dLOsB0Eep3xtZ4Jv:
			fCXyTlcmF4WuetVork = a9I3YZjc6ySDPE4Kp(y5W8dLOsB0Eep3xtZ4Jv[FGTfwsjNrB8DvKSZhLIQAb1JnO])
			duef0gb3Mi1AV5WpN8.append(fCXyTlcmF4WuetVork)
			A7Ap2wdlxM.append(pMAWqrwP80lR)
	elif EGJVsZy38Xx==JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠪࡻࡦࡺࡣࡩࠩଈ"):
		P3tys0cXWbiIUKk7HQ6n89V = dEyT9xhGjolYzLCH7460w3.findall(Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠫࡁࡹ࡯ࡶࡴࡦࡩ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴ࡫ࡽࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ଉ"),lRnjFoXHBfO,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,size in P3tys0cXWbiIUKk7HQ6n89V:
			if not fCXyTlcmF4WuetVork: continue
			if pMAWqrwP80lR in size:
				A7Ap2wdlxM.append(size)
				duef0gb3Mi1AV5WpN8.append(fCXyTlcmF4WuetVork)
				break
		if not duef0gb3Mi1AV5WpN8:
			for fCXyTlcmF4WuetVork,size in P3tys0cXWbiIUKk7HQ6n89V:
				if not fCXyTlcmF4WuetVork: continue
				A7Ap2wdlxM.append(size)
				duef0gb3Mi1AV5WpN8.append(fCXyTlcmF4WuetVork)
	if not duef0gb3Mi1AV5WpN8: return SaB5hx3PZwXRLtKgrTfQvId(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡂࡍ࡚ࡅࡒ࠭ଊ"),[],[]
	return iiy37aKq0pCEIOwfcTh61xb4U,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8
def vr5aHp1ofi(url,JJwnocyLUxHI2jlKF4Y):
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,Y41NvKfOroMzGB8sEHy7wbXlc5(u"࠭ࡇࡆࡖࠪଋ"),url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,rGPen6cSMHQkAywh8vqI9JXiD2,iiy37aKq0pCEIOwfcTh61xb4U,tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡐࡕࡁࡎ࠯࠴ࡷࡹ࠭ଌ"))
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	cookies = oCJ8TdG2LwSIVcbaUnhB.cookies
	if ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠨࡩࡲࡰ࡮ࡴ࡫ࠨ଍") in list(cookies.keys()):
		NeLJxDGoFlay2E3 = cookies[CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠩࡪࡳࡱ࡯࡮࡬ࠩ଎")]
		NeLJxDGoFlay2E3 = a9I3YZjc6ySDPE4Kp(vvmT3DLXkhPBwIaOAo6srZpEnRVJC(NeLJxDGoFlay2E3))
		items = dEyT9xhGjolYzLCH7460w3.findall(tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠪࡶࡴࡻࡴࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫଏ"),NeLJxDGoFlay2E3,dEyT9xhGjolYzLCH7460w3.DOTALL)
		eCGwzSrqBmIv = items[FGTfwsjNrB8DvKSZhLIQAb1JnO].replace(hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠫࡡ࠵ࠧଐ"),sVzojQerUqX(u"ࠬ࠵ࠧ଑"))
		eCGwzSrqBmIv = vvmT3DLXkhPBwIaOAo6srZpEnRVJC(eCGwzSrqBmIv)
	else: eCGwzSrqBmIv = url
	if IpC4qHXRuyNFjzWv(u"࠭ࡣࡢࡶࡦ࡬࠳࡯ࡳࠨ଒") in eCGwzSrqBmIv:
		qPdRkHWOcV0UXMy1o = eCGwzSrqBmIv.split(Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠧࠦ࠴ࡉࠫଓ"))[-YYJQyRskpX8jv]
		eCGwzSrqBmIv = zmcGfOdvAjsELeJlP(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡥࡤࡸࡨ࡮࠮ࡪࡵ࠲ࠫଔ")+qPdRkHWOcV0UXMy1o
		return ZchUJdM93pTA7zG5(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬକ"),[iiy37aKq0pCEIOwfcTh61xb4U],[eCGwzSrqBmIv]
	else:
		website = gZ4LwbKaOm[UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠪࡅࡐࡕࡁࡎࠩଖ")][FGTfwsjNrB8DvKSZhLIQAb1JnO]
		oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,y6y5HtgXO4TkUbwVZ(u"ࠫࡌࡋࡔࠨଗ"),website,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,rGPen6cSMHQkAywh8vqI9JXiD2,iiy37aKq0pCEIOwfcTh61xb4U,GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡎࡓࡆࡓ࠭࠳ࡰࡧࠫଘ"))
		j6H4f51GCVKeEnMvaWqN = oCJ8TdG2LwSIVcbaUnhB.url
		HSEekrxJ0aOhdL35ItPNRuz = eCGwzSrqBmIv.split(ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"࠭࠯ࠨଙ"))[nI2JK1RfsGWNY3OarEeMQZ]
		VVSh8yuGO5zHwU = j6H4f51GCVKeEnMvaWqN.split(zmcGfOdvAjsELeJlP(u"ࠧ࠰ࠩଚ"))[nI2JK1RfsGWNY3OarEeMQZ]
		O5Pwg3UFyX0k9E = eCGwzSrqBmIv.replace(HSEekrxJ0aOhdL35ItPNRuz,VVSh8yuGO5zHwU)
		headers = { tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬଛ"):iiy37aKq0pCEIOwfcTh61xb4U , y6y5HtgXO4TkUbwVZ(u"࡛ࠩ࠱ࡗ࡫ࡱࡶࡧࡶࡸࡪࡪ࠭ࡘ࡫ࡷ࡬ࠬଜ"):ZchUJdM93pTA7zG5(u"ࠪ࡜ࡒࡒࡈࡵࡶࡳࡖࡪࡷࡵࡦࡵࡷࠫଝ") , ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬଞ"):O5Pwg3UFyX0k9E }
		oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(r3rnfZ7cdxzNFebIRaLSG6B,ZchUJdM93pTA7zG5(u"ࠬࡖࡏࡔࡖࠪଟ"), O5Pwg3UFyX0k9E, iiy37aKq0pCEIOwfcTh61xb4U, headers, BF6QAiLUNHh7rKOugaw,iiy37aKq0pCEIOwfcTh61xb4U,ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡏࡔࡇࡍ࠮࠵ࡵࡨࠬଠ"))
		Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
		items = dEyT9xhGjolYzLCH7460w3.findall(Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠧࡥ࡫ࡵࡩࡨࡺ࡟࡭࡫ࡱ࡯ࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧଡ"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL|dEyT9xhGjolYzLCH7460w3.IGNORECASE)
		if not items:
			items = dEyT9xhGjolYzLCH7460w3.findall(XrTw01KtLzbpoyMf(u"ࠨ࠾࡬ࡪࡷࡧ࡭ࡦ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩଢ"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL|dEyT9xhGjolYzLCH7460w3.IGNORECASE)
			if not items:
				items = dEyT9xhGjolYzLCH7460w3.findall(IpC4qHXRuyNFjzWv(u"ࠩ࠿ࡩࡲࡨࡥࡥ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩଣ"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL|dEyT9xhGjolYzLCH7460w3.IGNORECASE)
		if items:
			fCXyTlcmF4WuetVork = items[FGTfwsjNrB8DvKSZhLIQAb1JnO].replace(XrTw01KtLzbpoyMf(u"ࠪࡠ࠴࠭ତ"),ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠫ࠴࠭ଥ"))
			fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork.rstrip(YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠬ࠵ࠧଦ"))
			if YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"࠭ࡨࡵࡶࡳࠫଧ") not in fCXyTlcmF4WuetVork: fCXyTlcmF4WuetVork = GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠧࡩࡶࡷࡴ࠿࠭ନ") + fCXyTlcmF4WuetVork
			fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork.replace(HtK4o2sTPgA78U(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࠩ଩"),ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࠫପ"))
			if JJwnocyLUxHI2jlKF4Y==iiy37aKq0pCEIOwfcTh61xb4U: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = iiy37aKq0pCEIOwfcTh61xb4U,[iiy37aKq0pCEIOwfcTh61xb4U],[fCXyTlcmF4WuetVork]
			else: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = IpC4qHXRuyNFjzWv(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ଫ"),[iiy37aKq0pCEIOwfcTh61xb4U],[fCXyTlcmF4WuetVork]
		else: phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = TlGXWLYsV1z(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡁࡌࡑࡄࡑࠬବ"),[],[]
		return phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8
def qqI9tn4BaLAEv(url):
	headers = { SaB5hx3PZwXRLtKgrTfQvId(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩଭ") : iiy37aKq0pCEIOwfcTh61xb4U }
	Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(r3rnfZ7cdxzNFebIRaLSG6B,url,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,TlGXWLYsV1z(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡕࡅࡕࡏࡄࡗࡋࡇࡉࡔ࠳࠱ࡴࡶࠪମ"))
	items = dEyT9xhGjolYzLCH7460w3.findall(IpC4qHXRuyNFjzWv(u"ࠧ࠽ࡵࡲࡹࡷࡩࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡮ࡤࡦࡪࡲ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨଯ"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	A7Ap2wdlxM,duef0gb3Mi1AV5WpN8,errno = [],[],iiy37aKq0pCEIOwfcTh61xb4U
	if items:
		for fCXyTlcmF4WuetVork,e7wFcO9GDXRq in items:
			A7Ap2wdlxM.append(e7wFcO9GDXRq)
			duef0gb3Mi1AV5WpN8.append(fCXyTlcmF4WuetVork)
	if len(duef0gb3Mi1AV5WpN8)==FGTfwsjNrB8DvKSZhLIQAb1JnO: return LyNiIHPOwD3hCUYEFM7(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡖࡆࡖࡉࡅࡘࡌࡈࡊࡕࠧର"),[],[]
	return iiy37aKq0pCEIOwfcTh61xb4U,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8
def ke07Gduc9vRJbtQU5(url):
	qCVlj6LiNza2MbZosSecpWQGuJd7 = url.split(tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠩ࠲ࠫ଱"))[JZszNnIEMAx28Yao0yqhiXGKOPb(u"࠵๖")]
	data = tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠪࡳࡵࡃࡤࡰࡹࡱࡰࡴࡧࡤ࠳ࠨ࡬ࡨࡂ࠭ଲ")+qCVlj6LiNza2MbZosSecpWQGuJd7
	headers = {IpC4qHXRuyNFjzWv(u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪଳ"):hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧࠫ଴")}
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(r3rnfZ7cdxzNFebIRaLSG6B,JZszNnIEMAx28Yao0yqhiXGKOPb(u"࠭ࡐࡐࡕࡗࠫଵ"),url,data,headers,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡊࡗࡊࡌ࠮࠳ࡶࡸࠬଶ"))
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	items = dEyT9xhGjolYzLCH7460w3.findall(y6y5HtgXO4TkUbwVZ(u"ࠨࡣࡧࡦࡱࡵࡣ࡬ࡡࡧࡩࡹ࡫ࡣࡵࡧࡧ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬଷ"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if items:
		url = items[FGTfwsjNrB8DvKSZhLIQAb1JnO]
		return iiy37aKq0pCEIOwfcTh61xb4U,[iiy37aKq0pCEIOwfcTh61xb4U],[url]
	return CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡋࡘࡄࡍࠩସ"),[],[]
def HtF3Z1J56gqD2TdwCo(url):
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(r3rnfZ7cdxzNFebIRaLSG6B,SaB5hx3PZwXRLtKgrTfQvId(u"ࠪࡋࡊ࡚ࠧହ"),url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,ZchUJdM93pTA7zG5(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡗࡍ࠰࠵ࡸࡺࠧ଺"))
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	try: Vxz6OndPIX4g2kaRp7 = Vxz6OndPIX4g2kaRp7.decode(ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠬࡻࡴࡧ࠺ࠪ଻"),TlGXWLYsV1z(u"࠭ࡩࡨࡰࡲࡶࡪ଼࠭"))
	except: pass
	items = dEyT9xhGjolYzLCH7460w3.findall(YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠧࡥࡱࡦࡷࡤࡴ࡯ࡠࡲࡵࡩࡻ࡯ࡥࡸࡡࡧࡩࡸࡩࡲࡪࡲࡷ࡭ࡴࡴ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨଽ"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if items:
		url = items[FGTfwsjNrB8DvKSZhLIQAb1JnO]
		return iiy37aKq0pCEIOwfcTh61xb4U,[iiy37aKq0pCEIOwfcTh61xb4U],[url]
	return tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦ࡚ࠣࡐ࠭ା"),[],[]
def UzG0eH6OjQSYr(url):
	headers = {IpC4qHXRuyNFjzWv(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ି"):iiy37aKq0pCEIOwfcTh61xb4U}
	Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(r3rnfZ7cdxzNFebIRaLSG6B,url,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡕࡒࡎࡒࡅࡉ࠳࠱ࡴࡶࠪୀ"))
	items = dEyT9xhGjolYzLCH7460w3.findall(tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠫࡸࡵࡵࡳࡥࡨࡷ࠿ࠦ࡜࡜ࠤࠫ࠲࠯ࡅࠩࠣࠩୁ"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if items:
		url = items[FGTfwsjNrB8DvKSZhLIQAb1JnO]+yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠬࢂࡒࡦࡨࡨࡶࡪࡸ࠽ࠨୂ")+url
		return iiy37aKq0pCEIOwfcTh61xb4U,[iiy37aKq0pCEIOwfcTh61xb4U],[url]
	return AbqCJZdWQP9j(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡗࡔࡐࡔࡇࡄࠨୃ"),[],[]
def JJdsf3YkRMCHx8mu45V(url):
	url = url.strip(JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠧ࠰ࠩୄ"))
	if GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠨ࠱ࡨࡱࡧ࡫ࡤ࠰ࠩ୅") in url: qPdRkHWOcV0UXMy1o = url.split(IpC4qHXRuyNFjzWv(u"ࠩ࠲ࠫ୆"))[pZWli1xqfVtvzuSU6ImNw53gBFsh]
	else: qPdRkHWOcV0UXMy1o = url.split(tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠪ࠳ࠬେ"))[-YYJQyRskpX8jv]
	url = LyNiIHPOwD3hCUYEFM7(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡼࡣࡴࡶࡵࡩࡦࡳ࠮ࡵࡱ࠲ࡴࡱࡧࡹࡦࡴࡂࡪ࡮ࡪ࠽ࠨୈ") + qPdRkHWOcV0UXMy1o
	headers = { UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ୉") : iiy37aKq0pCEIOwfcTh61xb4U }
	Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(r3rnfZ7cdxzNFebIRaLSG6B,url,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡙ࡇࡘ࡚ࡒࡆࡃࡐ࠱࠶ࡹࡴࠨ୊"))
	Vxz6OndPIX4g2kaRp7 = Vxz6OndPIX4g2kaRp7.replace(tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠧ࡝࡞ࠪୋ"),iiy37aKq0pCEIOwfcTh61xb4U)
	items = dEyT9xhGjolYzLCH7460w3.findall(GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠨࡨ࡬ࡰࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨୌ"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if items: return iiy37aKq0pCEIOwfcTh61xb4U,[iiy37aKq0pCEIOwfcTh61xb4U],[ items[FGTfwsjNrB8DvKSZhLIQAb1JnO] ]
	return MgP8OjoaiWQEVG59(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤ࡛ࡉࡓࡕࡔࡈࡅࡒ୍࠭"),[],[]
def ISjGlvDeVK1TE6U2bRiZ(url):
	Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(r3rnfZ7cdxzNFebIRaLSG6B,url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,vODxLKW5Ql6r4Fbm8(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡖࡊࡆࡒ࡞ࡆ࠳࠱ࡴࡶࠪ୎"))
	items = dEyT9xhGjolYzLCH7460w3.findall(uuExaKGL7UONtevRd(u"ࠫࡸࡸࡣ࠻ࠢࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡲࡡࡣࡧ࡯࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠱ࠦࡲࡦࡵ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ୏"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = [],[]
	for fCXyTlcmF4WuetVork,e7wFcO9GDXRq,IUudCk6KnAmtv9ZlHsN1S in items:
		A7Ap2wdlxM.append(e7wFcO9GDXRq+iFBmE2MUIpSu34wsd7Rf6z+IUudCk6KnAmtv9ZlHsN1S)
		duef0gb3Mi1AV5WpN8.append(fCXyTlcmF4WuetVork)
	if len(duef0gb3Mi1AV5WpN8)==FGTfwsjNrB8DvKSZhLIQAb1JnO: return EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡗࡋࡇࡓ࡟ࡇࠧ୐"),[],[]
	return iiy37aKq0pCEIOwfcTh61xb4U,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8
def SfL14M8xHB5Fi3ZDE9rV(url):
	Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(r3rnfZ7cdxzNFebIRaLSG6B,url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,GGx4qyKP1vUtRghsE2WfaHLMXZ(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡚ࡅ࡙ࡉࡈࡗࡋࡇࡉࡔ࠳࠱ࡴࡶࠪ୑"))
	items = dEyT9xhGjolYzLCH7460w3.findall(xpT28sXu051(u"ࠢࡥࡱࡺࡲࡱࡵࡡࡥࡡࡹ࡭ࡩ࡫࡯࡝ࠪࠪࠬ࠳࠰࠿ࠪࠩ࠯ࠫ࠭࠴ࠪࡀࠫࠪ࠰ࠬ࠮࠮ࠫࡁࠬࠫࡡ࠯࡜ࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂ࠳࠰࠿࠽ࡶࡧࡂ࠭࠴ࠪࡀࠫ࠯࠲࠯ࡅ࠼࠰ࡶࡧࡂࠧ୒"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	items = set(items)
	A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = [],[]
	for qPdRkHWOcV0UXMy1o,Cpf9s3c0Zngj7XE,QZsaMFdzSj,e7wFcO9GDXRq,IUudCk6KnAmtv9ZlHsN1S in items:
		url = MgP8OjoaiWQEVG59(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡥࡹࡩࡨࡷ࡫ࡧࡩࡴ࠴ࡵࡴ࠱ࡧࡰࡄࡵࡰ࠾ࡦࡲࡻࡳࡲ࡯ࡢࡦࡢࡳࡷ࡯ࡧࠧ࡫ࡧࡁࠬ୓")+qPdRkHWOcV0UXMy1o+hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠩࠩࡱࡴࡪࡥ࠾ࠩ୔")+Cpf9s3c0Zngj7XE+XrTw01KtLzbpoyMf(u"ࠪࠪ࡭ࡧࡳࡩ࠿ࠪ୕")+QZsaMFdzSj
		Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(r3rnfZ7cdxzNFebIRaLSG6B,url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,y6y5HtgXO4TkUbwVZ(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡘࡃࡗࡇࡍ࡜ࡉࡅࡇࡒ࠱࠷ࡴࡤࠨୖ"))
		items = dEyT9xhGjolYzLCH7460w3.findall(FRYcH4KL7e9gv5pEB(u"ࠬࡪࡩࡳࡧࡦࡸࠥࡲࡩ࡯࡭࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫୗ"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork in items:
			A7Ap2wdlxM.append(e7wFcO9GDXRq+iFBmE2MUIpSu34wsd7Rf6z+IUudCk6KnAmtv9ZlHsN1S)
			duef0gb3Mi1AV5WpN8.append(fCXyTlcmF4WuetVork)
	if len(duef0gb3Mi1AV5WpN8)==FGTfwsjNrB8DvKSZhLIQAb1JnO: return ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤ࡙ࠡࡄࡘࡈࡎࡖࡊࡆࡈࡓࠬ୘"),[],[]
	return iiy37aKq0pCEIOwfcTh61xb4U,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8
def ZT24V7nCGp(url):
	fCXyTlcmF4WuetVork = iiy37aKq0pCEIOwfcTh61xb4U
	if YYJQyRskpX8jv or TlGXWLYsV1z(u"ࠧࡌࡧࡼࡁࠬ୙") not in url:
		eCGwzSrqBmIv = url.replace(LyNiIHPOwD3hCUYEFM7(u"ࠨࡷࡳࡦࡴࡳ࠮࡭࡫ࡹࡩࠬ୚"),hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠩࡸࡴࡵࡵ࡭࠯࡮࡬ࡺࡪ࠭୛"))
		eCGwzSrqBmIv = eCGwzSrqBmIv.split(jXE2YHkswT8y(u"ࠪ࠳ࠬଡ଼"))
		qPdRkHWOcV0UXMy1o = eCGwzSrqBmIv[iiCWLaJREureAlOkv]
		eCGwzSrqBmIv = FRYcH4KL7e9gv5pEB(u"ࠫ࠴࠭ଢ଼").join(eCGwzSrqBmIv[FGTfwsjNrB8DvKSZhLIQAb1JnO:pZWli1xqfVtvzuSU6ImNw53gBFsh])
		Si4j3bXGLeno0zfxlm9ZOcy = {FRYcH4KL7e9gv5pEB(u"ࠬ࡯ࡤࠨ୞"):qPdRkHWOcV0UXMy1o,tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"࠭࡯ࡱࠩୟ"):jXE2YHkswT8y(u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥ࠴ࠪୠ"),UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠨ࡯ࡨࡸ࡭ࡵࡤࡠࡨࡵࡩࡪ࠭ୡ"):L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠩࡉࡶࡪ࡫ࠫࡅࡱࡺࡲࡱࡵࡡࡥ࠭ࠨ࠷ࡊࠫ࠳ࡆࠩୢ")}
		oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(r3rnfZ7cdxzNFebIRaLSG6B,XrTw01KtLzbpoyMf(u"ࠪࡔࡔ࡙ࡔࠨୣ"),eCGwzSrqBmIv,Si4j3bXGLeno0zfxlm9ZOcy,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,xpT28sXu051(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡖࡒࡅࡓࡒ࠳࠱ࡴࡶࠪ୤"))
		if vODxLKW5Ql6r4Fbm8(u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ୥") in list(oCJ8TdG2LwSIVcbaUnhB.headers.keys()): fCXyTlcmF4WuetVork = oCJ8TdG2LwSIVcbaUnhB.headers[EMO8gy4LrsNTh0knZwpSeU75APW(u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ୦")]
		if not fCXyTlcmF4WuetVork and oCJ8TdG2LwSIVcbaUnhB.succeeded:
			Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
			fCXyTlcmF4WuetVork = dEyT9xhGjolYzLCH7460w3.findall(Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠧࡪࡦࡀࠦࡩ࡯ࡲࡦࡥࡷࡣࡱ࡯࡮࡬ࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ୧"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
			if fCXyTlcmF4WuetVork: fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork[FGTfwsjNrB8DvKSZhLIQAb1JnO]
	else:
		oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(r3rnfZ7cdxzNFebIRaLSG6B,UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠨࡉࡈࡘࠬ୨"),url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,IpC4qHXRuyNFjzWv(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡛ࡐࡃࡑࡐ࠱࠷ࡴࡤࠨ୩"))
		if ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠪࡰࡴࡩࡡࡵ࡫ࡲࡲࠬ୪") in list(oCJ8TdG2LwSIVcbaUnhB.headers.keys()): fCXyTlcmF4WuetVork = oCJ8TdG2LwSIVcbaUnhB.headers[MgP8OjoaiWQEVG59(u"ࠫࡱࡵࡣࡢࡶ࡬ࡳࡳ࠭୫")]
	if fCXyTlcmF4WuetVork: return iiy37aKq0pCEIOwfcTh61xb4U,[iiy37aKq0pCEIOwfcTh61xb4U],[fCXyTlcmF4WuetVork]
	return HtK4o2sTPgA78U(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡖࡒࡅࡓࡒ࠭୬"),[],[]
def awL8f4UXuTE(url):
	headers = { ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ୭") : iiy37aKq0pCEIOwfcTh61xb4U }
	Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(r3rnfZ7cdxzNFebIRaLSG6B,url,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,MgP8OjoaiWQEVG59(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡐࡎࡏࡖࡊࡆࡈࡓ࠲࠷ࡳࡵࠩ୮"))
	items = dEyT9xhGjolYzLCH7460w3.findall(L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠨࡵࡲࡹࡷࡩࡥࡴ࠼࠱࠮ࡄࠨࠨ࠯ࠬࡂ࠭ࠧ࠲ࠢࠩ࠰࠭ࡃ࠮ࠨࠧ୯"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = [],[]
	if items:
		A7Ap2wdlxM.append(L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠩࡰࡴ࠹࠭୰"))
		duef0gb3Mi1AV5WpN8.append(items[FGTfwsjNrB8DvKSZhLIQAb1JnO][YYJQyRskpX8jv])
		A7Ap2wdlxM.append(FRYcH4KL7e9gv5pEB(u"ࠪࡱ࠸ࡻ࠸ࠨୱ"))
		duef0gb3Mi1AV5WpN8.append(items[FGTfwsjNrB8DvKSZhLIQAb1JnO][FGTfwsjNrB8DvKSZhLIQAb1JnO])
		return iiy37aKq0pCEIOwfcTh61xb4U,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8
	else: return hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡌࡊࡋ࡙ࡍࡉࡋࡏࠨ୲"),[],[]
def z6LdPkhxOr2V3fQFp7B9(url):
	qPdRkHWOcV0UXMy1o = url.split(sVzojQerUqX(u"ࠬ࠵ࠧ୳"))[-YYJQyRskpX8jv]
	qPdRkHWOcV0UXMy1o = qPdRkHWOcV0UXMy1o.split(AbqCJZdWQP9j(u"࠭ࠦࠨ୴"))[FGTfwsjNrB8DvKSZhLIQAb1JnO]
	qPdRkHWOcV0UXMy1o = qPdRkHWOcV0UXMy1o.replace(tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠧࡸࡣࡷࡧ࡭ࡅࡶ࠾ࠩ୵"),iiy37aKq0pCEIOwfcTh61xb4U)
	eCGwzSrqBmIv = gZ4LwbKaOm[ZchUJdM93pTA7zG5(u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩ୶")][FGTfwsjNrB8DvKSZhLIQAb1JnO]+jXE2YHkswT8y(u"ࠩ࠲ࡻࡦࡺࡣࡩࡁࡹࡁࠬ୷")+qPdRkHWOcV0UXMy1o
	zRiuBNrfpde4ZlUnoEjG37H = PtkEvXAqif14G20QZsaSyT(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡽࡴࡻࡴࡶ࠰ࡥࡩ࠴࠭୸")+qPdRkHWOcV0UXMy1o
	mJXa86O3VqnhoK2ID7CL,k03kbvh7xa8ZmKHwpRrCYXD = iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U
	headers = {AbqCJZdWQP9j(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ୹"):iiy37aKq0pCEIOwfcTh61xb4U}
	if FGTfwsjNrB8DvKSZhLIQAb1JnO:
		Vxz6OndPIX4g2kaRp7 = iiy37aKq0pCEIOwfcTh61xb4U
		for o6oXFxmE1bQC in range(TlGXWLYsV1z(u"࠸๗")):
			oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(hI7SkXd94fFzAHNZCQoMqEutbnWP,EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠬࡍࡅࡕࠩ୺"),eCGwzSrqBmIv,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡜ࡓ࡚࡚ࡕࡃࡇ࠰࠵ࡸࡺࠧ୻"))
			Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
			if y6y5HtgXO4TkUbwVZ(u"ࠧࡪࡶࡤ࡫ࠬ୼") in Vxz6OndPIX4g2kaRp7: break
			X2cQ5NCPvkMieBW7oASspFjE.sleep(nI2JK1RfsGWNY3OarEeMQZ)
		dLVhlByrevFDXbPKgcYmWR = dEyT9xhGjolYzLCH7460w3.findall(yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠨࡸࡤࡶࠥࡿࡴࡊࡰ࡬ࡸ࡮ࡧ࡬ࡑ࡮ࡤࡽࡪࡸࡒࡦࡵࡳࡳࡳࡹࡥࠡ࠿ࠣࠬ࠳࠰࠿ࠪ࠽࠿࠳ࡸࡩࡲࡪࡲࡷࡂࠬ୽"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if dLVhlByrevFDXbPKgcYmWR: dLVhlByrevFDXbPKgcYmWR = dLVhlByrevFDXbPKgcYmWR[FGTfwsjNrB8DvKSZhLIQAb1JnO]
		else: dLVhlByrevFDXbPKgcYmWR = Vxz6OndPIX4g2kaRp7
	else:
		Vxz6OndPIX4g2kaRp7 = iiy37aKq0pCEIOwfcTh61xb4U
		tcv3rnuCFEQmzf6i9XhgUH,rfBAJx30NnHwdekY6icT2MSZULl = iiy37aKq0pCEIOwfcTh61xb4U,{}
		BuxFjX0omMZe7qJDPaVUr,qAawdug1ko6G9zp = iiy37aKq0pCEIOwfcTh61xb4U,{}
		O5Pwg3UFyX0k9E = gZ4LwbKaOm[AbqCJZdWQP9j(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪ୾")][FGTfwsjNrB8DvKSZhLIQAb1JnO]+tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠪ࠳ࡾࡵࡵࡵࡷࡥࡩ࡮࠵ࡶ࠲࠱ࡳࡰࡦࡿࡥࡳࠩ୿")
		headers[JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ஀")] = GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲࡮ࡸࡵ࡮ࠨ஁")
		if YYJQyRskpX8jv:
			V4p9OiNGeDSfyx = FRYcH4KL7e9gv5pEB(u"࠭ࡻࠣࡸ࡬ࡨࡪࡵࡉࡥࠤ࠽ࠤࠧ࠭ஂ")+qPdRkHWOcV0UXMy1o+IpC4qHXRuyNFjzWv(u"ࠧࠣ࠮ࠣࠦࡨࡵ࡮ࡵࡧࡻࡸࠧࡀࠠࡼࠤࡦࡰ࡮࡫࡮ࡵࠤ࠽ࠤࢀࠨࡣ࡭࡫ࡨࡲࡹ࡜ࡥࡳࡵ࡬ࡳࡳࠨ࠺ࠡࠤ࠻࠲࠶࠸࠮࠱ࠤ࠯ࠤࠧࡩ࡬ࡪࡧࡱࡸࡓࡧ࡭ࡦࠤ࠽ࠤࠧࡇࡎࡅࡔࡒࡍࡉࡥࡕࡏࡒࡏ࡙ࡌࡍࡅࡅࠤࢀࢁࢂ࠭ஃ")
			oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(hI7SkXd94fFzAHNZCQoMqEutbnWP,JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠨࡒࡒࡗ࡙࠭஄"),O5Pwg3UFyX0k9E,V4p9OiNGeDSfyx,headers,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,jXE2YHkswT8y(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡟ࡏࡖࡖࡘࡆࡊ࠳࠲࡯ࡦࠪஅ"))
			dLVhlByrevFDXbPKgcYmWR = oCJ8TdG2LwSIVcbaUnhB.content
			if SaB5hx3PZwXRLtKgrTfQvId(u"ࠪࡷࡹࡸࡥࡢ࡯࡬ࡲ࡬ࡊࡡࡵࡣࠪஆ") in dLVhlByrevFDXbPKgcYmWR:
				tcv3rnuCFEQmzf6i9XhgUH = dLVhlByrevFDXbPKgcYmWR.replace(IpC4qHXRuyNFjzWv(u"ࠫࡡࡢࡵ࠱࠲࠵࠺ࠬஇ"),sVzojQerUqX(u"ࠬࠬࠧஈ"))
				rfBAJx30NnHwdekY6icT2MSZULl = DeIL3qoa2UBtYPb(LyNiIHPOwD3hCUYEFM7(u"࠭ࡤࡪࡥࡷࠫஉ"),tcv3rnuCFEQmzf6i9XhgUH)
		if YYJQyRskpX8jv:
			V4p9OiNGeDSfyx = TlGXWLYsV1z(u"ࠧࡼࠤࡹ࡭ࡩ࡫࡯ࡊࡦࠥ࠾ࠥࠨࠧஊ")+qPdRkHWOcV0UXMy1o+Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠨࠤ࠯ࠤࠧࡩ࡯࡯ࡶࡨࡼࡹࠨ࠺ࠡࡽࠥࡧࡱ࡯ࡥ࡯ࡶࠥ࠾ࠥࢁࠢࡤ࡮࡬ࡩࡳࡺࡖࡦࡴࡶ࡭ࡴࡴࠢ࠻ࠢࠥ࠺࠳࠹࠶ࠣ࠮ࠣࠦࡨࡲࡩࡦࡰࡷࡒࡦࡳࡥࠣ࠼ࠣࠦࡎࡕࡓࡠࡗࡑࡔࡑ࡛ࡇࡈࡇࡇࠦࢂࢃࡽࠨ஋")
			oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(hI7SkXd94fFzAHNZCQoMqEutbnWP,L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠩࡓࡓࡘ࡚ࠧ஌"),O5Pwg3UFyX0k9E,V4p9OiNGeDSfyx,headers,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳࡙ࡐࡗࡗ࡙ࡇࡋ࠭࠴ࡴࡧࠫ஍"))
			dLVhlByrevFDXbPKgcYmWR = oCJ8TdG2LwSIVcbaUnhB.content
			if XrTw01KtLzbpoyMf(u"ࠫࡸࡺࡲࡦࡣࡰ࡭ࡳ࡭ࡄࡢࡶࡤࠫஎ") in dLVhlByrevFDXbPKgcYmWR:
				BuxFjX0omMZe7qJDPaVUr = dLVhlByrevFDXbPKgcYmWR.replace(sVzojQerUqX(u"ࠬࡢ࡜ࡶ࠲࠳࠶࠻࠭ஏ"),hhQwbeiNLoqFjX90fB7aG8VAs(u"࠭ࠦࠨஐ"))
				qAawdug1ko6G9zp = DeIL3qoa2UBtYPb(tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠧࡥ࡫ࡦࡸࠬ஑"),BuxFjX0omMZe7qJDPaVUr)
		if YYJQyRskpX8jv and hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠨࡵࡷࡶࡪࡧ࡭ࡪࡰࡪࡈࡦࡺࡡࠨஒ") not in tcv3rnuCFEQmzf6i9XhgUH+BuxFjX0omMZe7qJDPaVUr:
			tcv3rnuCFEQmzf6i9XhgUH,BuxFjX0omMZe7qJDPaVUr = iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U
			rfBAJx30NnHwdekY6icT2MSZULl,qAawdug1ko6G9zp = {},{}
			V4p9OiNGeDSfyx = CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠩࡾࠦࡻ࡯ࡤࡦࡱࡌࡨࠧࡀࠠࠣࠩஓ")+qPdRkHWOcV0UXMy1o+Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠪࠦ࠱ࠦࠢࡤࡱࡱࡸࡪࡾࡴࠣ࠼ࠣࡿࠧࡩ࡬ࡪࡧࡱࡸࠧࡀࠠࡼࠤࡦࡰ࡮࡫࡮ࡵࡘࡨࡶࡸ࡯࡯࡯ࠤ࠽ࠤࠧ࠷࠹࠯࠴࠼࠲࠸࠽ࠢ࠭ࠢࠥࡧࡱ࡯ࡥ࡯ࡶࡑࡥࡲ࡫ࠢ࠻ࠢࠥࡍࡔ࡙ࠢࡾࡿࢀࠫஔ")
			oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(hI7SkXd94fFzAHNZCQoMqEutbnWP,sVzojQerUqX(u"ࠫࡕࡕࡓࡕࠩக"),O5Pwg3UFyX0k9E,V4p9OiNGeDSfyx,headers,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡛ࡒ࡙࡙࡛ࡂࡆ࠯࠷ࡸ࡭࠭஖"))
			dLVhlByrevFDXbPKgcYmWR = oCJ8TdG2LwSIVcbaUnhB.content
			if GGx4qyKP1vUtRghsE2WfaHLMXZ(u"࠭ࡳࡵࡴࡨࡥࡲ࡯࡮ࡨࡆࡤࡸࡦ࠭஗") in dLVhlByrevFDXbPKgcYmWR:
				tcv3rnuCFEQmzf6i9XhgUH = dLVhlByrevFDXbPKgcYmWR.replace(ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠧ࡝࡞ࡸ࠴࠵࠸࠶ࠨ஘"),tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠨࠨࠪங"))
				rfBAJx30NnHwdekY6icT2MSZULl = DeIL3qoa2UBtYPb(ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠩࡧ࡭ࡨࡺࠧச"),tcv3rnuCFEQmzf6i9XhgUH)
	J4GM90dymg5kbTKiYHtrWQ,ce57Mt3EqgVQxIz,tHA3aBQKE109zTN4VPu,t1gk4L5hdYeTmupf2ivaZlWQH = iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,[],[]
	XXF84CezDqm3Ktk1LUApnJ,Y4mNJ5Od7pyuCHVwvQKzZlIhj,MTtNz5B8syfL,q1RcFM2Hwd = iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,[],[]
	try: ce57Mt3EqgVQxIz = rfBAJx30NnHwdekY6icT2MSZULl[HtK4o2sTPgA78U(u"ࠪࡷࡹࡸࡥࡢ࡯࡬ࡲ࡬ࡊࡡࡵࡣࠪ஛")][hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠫ࡭ࡲࡳࡎࡣࡱ࡭࡫࡫ࡳࡵࡗࡵࡰࠬஜ")]
	except: pass
	try: Y4mNJ5Od7pyuCHVwvQKzZlIhj = qAawdug1ko6G9zp[EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠬࡹࡴࡳࡧࡤࡱ࡮ࡴࡧࡅࡣࡷࡥࠬ஝")][IpC4qHXRuyNFjzWv(u"࠭ࡨ࡭ࡵࡐࡥࡳ࡯ࡦࡦࡵࡷ࡙ࡷࡲࠧஞ")]
	except: pass
	try: J4GM90dymg5kbTKiYHtrWQ = rfBAJx30NnHwdekY6icT2MSZULl[uuExaKGL7UONtevRd(u"ࠧࡴࡶࡵࡩࡦࡳࡩ࡯ࡩࡇࡥࡹࡧࠧட")][AbqCJZdWQP9j(u"ࠨࡦࡤࡷ࡭ࡓࡡ࡯࡫ࡩࡩࡸࡺࡕࡳ࡮ࠪ஠")]
	except: pass
	try: XXF84CezDqm3Ktk1LUApnJ = qAawdug1ko6G9zp[TlGXWLYsV1z(u"ࠩࡶࡸࡷ࡫ࡡ࡮࡫ࡱ࡫ࡉࡧࡴࡢࠩ஡")][MgP8OjoaiWQEVG59(u"ࠪࡨࡦࡹࡨࡎࡣࡱ࡭࡫࡫ࡳࡵࡗࡵࡰࠬ஢")]
	except: pass
	try: tHA3aBQKE109zTN4VPu = rfBAJx30NnHwdekY6icT2MSZULl[HtK4o2sTPgA78U(u"ࠫࡸࡺࡲࡦࡣࡰ࡭ࡳ࡭ࡄࡢࡶࡤࠫண")][hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠬ࡬࡯ࡳ࡯ࡤࡸࡸ࠭த")]
	except: pass
	try: MTtNz5B8syfL = qAawdug1ko6G9zp[UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"࠭ࡳࡵࡴࡨࡥࡲ࡯࡮ࡨࡆࡤࡸࡦ࠭஥")][UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠧࡧࡱࡵࡱࡦࡺࡳࠨ஦")]
	except: pass
	try: t1gk4L5hdYeTmupf2ivaZlWQH = rfBAJx30NnHwdekY6icT2MSZULl[ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠨࡵࡷࡶࡪࡧ࡭ࡪࡰࡪࡈࡦࡺࡡࠨ஧")][JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠩࡤࡨࡦࡶࡴࡪࡸࡨࡊࡴࡸ࡭ࡢࡶࡶࠫந")]
	except: pass
	try: q1RcFM2Hwd = qAawdug1ko6G9zp[CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠪࡷࡹࡸࡥࡢ࡯࡬ࡲ࡬ࡊࡡࡵࡣࠪன")][ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠫࡦࡪࡡࡱࡶ࡬ࡺࡪࡌ࡯ࡳ࡯ࡤࡸࡸ࠭ப")]
	except: pass
	A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = [PtkEvXAqif14G20QZsaSyT(u"ࠬฮฯ้่ࠣฮึาๅสࠢํ์ฯ๐่ษࠩ஫")],[iiy37aKq0pCEIOwfcTh61xb4U]
	try:
		NNZ2f6okAiGjgsqlCr = rfBAJx30NnHwdekY6icT2MSZULl[EMO8gy4LrsNTh0knZwpSeU75APW(u"࠭ࡣࡢࡲࡷ࡭ࡴࡴࡳࠨ஬")][ZchUJdM93pTA7zG5(u"ࠧࡱ࡮ࡤࡽࡪࡸࡃࡢࡲࡷ࡭ࡴࡴࡳࡕࡴࡤࡧࡰࡲࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫ஭")][tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠨࡥࡤࡴࡹ࡯࡯࡯ࡖࡵࡥࡨࡱࡳࠨம")]
		for yGYP6vqEeM7UnwS2 in NNZ2f6okAiGjgsqlCr:
			fCXyTlcmF4WuetVork = yGYP6vqEeM7UnwS2[MgP8OjoaiWQEVG59(u"ࠩࡥࡥࡸ࡫ࡕࡳ࡮ࠪய")]
			try: title = yGYP6vqEeM7UnwS2[MgP8OjoaiWQEVG59(u"ࠪࡲࡦࡳࡥࠨர")][xpT28sXu051(u"ࠫࡸ࡯࡭ࡱ࡮ࡨࡘࡪࡾࡴࠨற")]
			except: title = yGYP6vqEeM7UnwS2[sVzojQerUqX(u"ࠬࡴࡡ࡮ࡧࠪல")][ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"࠭ࡲࡶࡰࡶࠫள")][FGTfwsjNrB8DvKSZhLIQAb1JnO][ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠧࡵࡧࡻࡸࡹ࠭ழ")]
			duef0gb3Mi1AV5WpN8.append(fCXyTlcmF4WuetVork)
			A7Ap2wdlxM.append(title)
	except: pass
	try:
		NNZ2f6okAiGjgsqlCr = qAawdug1ko6G9zp[yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠨࡥࡤࡴࡹ࡯࡯࡯ࡵࠪவ")][vODxLKW5Ql6r4Fbm8(u"ࠩࡳࡰࡦࡿࡥࡳࡅࡤࡴࡹ࡯࡯࡯ࡵࡗࡶࡦࡩ࡫࡭࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭ஶ")][uuExaKGL7UONtevRd(u"ࠪࡧࡦࡶࡴࡪࡱࡱࡘࡷࡧࡣ࡬ࡵࠪஷ")]
		for yGYP6vqEeM7UnwS2 in NNZ2f6okAiGjgsqlCr:
			fCXyTlcmF4WuetVork = yGYP6vqEeM7UnwS2[hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠫࡧࡧࡳࡦࡗࡵࡰࠬஸ")]
			try: title = yGYP6vqEeM7UnwS2[tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠬࡴࡡ࡮ࡧࠪஹ")][FRYcH4KL7e9gv5pEB(u"࠭ࡳࡪ࡯ࡳࡰࡪ࡚ࡥࡹࡶࠪ஺")]
			except: title = yGYP6vqEeM7UnwS2[YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠧ࡯ࡣࡰࡩࠬ஻")][L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠨࡴࡸࡲࡸ࠭஼")][FGTfwsjNrB8DvKSZhLIQAb1JnO][YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠩࡷࡩࡽࡺࡴࠨ஽")]
			if fCXyTlcmF4WuetVork not in duef0gb3Mi1AV5WpN8:
				duef0gb3Mi1AV5WpN8.append(fCXyTlcmF4WuetVork)
				A7Ap2wdlxM.append(title)
	except: pass
	if len(A7Ap2wdlxM)>YYJQyRskpX8jv:
		mmfrx2S5XqknFTDeRhj49LuYv1wW0 = ccv1mVPUsnr(tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠪหำะัࠡษ็ฮึาๅสࠢࠫࠫா")+str(len(A7Ap2wdlxM))+zmcGfOdvAjsELeJlP(u"๋ࠫࠥไโࠫࠪி"), A7Ap2wdlxM)
		if mmfrx2S5XqknFTDeRhj49LuYv1wW0==-YYJQyRskpX8jv: return UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠬࡋࡘࡊࡖࡢࡅࡑࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪீ"),[],[]
		elif mmfrx2S5XqknFTDeRhj49LuYv1wW0!=FGTfwsjNrB8DvKSZhLIQAb1JnO:
			fCXyTlcmF4WuetVork = duef0gb3Mi1AV5WpN8[mmfrx2S5XqknFTDeRhj49LuYv1wW0]+HtK4o2sTPgA78U(u"࠭ࠦࠨு")
			UpDMNyv61Yj8oSmczJFe = dEyT9xhGjolYzLCH7460w3.findall(AbqCJZdWQP9j(u"ࠧࠧࠪࡩࡱࡹࡃ࠮ࠫࡁࠬࠪࠬூ"),fCXyTlcmF4WuetVork)
			if UpDMNyv61Yj8oSmczJFe: fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork.replace(UpDMNyv61Yj8oSmczJFe[FGTfwsjNrB8DvKSZhLIQAb1JnO],JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠨࡨࡰࡸࡂࡼࡴࡵࠩ௃"))
			else: fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork+IpC4qHXRuyNFjzWv(u"ࠩࡩࡱࡹࡃࡶࡵࡶࠪ௄")
			mJXa86O3VqnhoK2ID7CL = fCXyTlcmF4WuetVork.strip(jXE2YHkswT8y(u"ࠪࠪࠬ௅"))
	SSAgyW0Qnx6jMvfLU1c,FHo3LOXeNq6CV2JtgkZhE1,NNVezSPHdra18k4KLvnA2YwMhyFR = [],[],[]
	rnCEDXPB47 = [ce57Mt3EqgVQxIz,Y4mNJ5Od7pyuCHVwvQKzZlIhj]
	KwBmHk9YnNRS = [J4GM90dymg5kbTKiYHtrWQ,XXF84CezDqm3Ktk1LUApnJ]
	fwDKASjdbmGvouLTFke,mmeFhtGiDU4 = [],[]
	for TQ5GC0gPwuDm8h in tHA3aBQKE109zTN4VPu+MTtNz5B8syfL:
		if TQ5GC0gPwuDm8h[ZchUJdM93pTA7zG5(u"ࠫ࡮ࡺࡡࡨࠩெ")] not in fwDKASjdbmGvouLTFke:
			fwDKASjdbmGvouLTFke.append(TQ5GC0gPwuDm8h[zmcGfOdvAjsELeJlP(u"ࠬ࡯ࡴࡢࡩࠪே")])
			mmeFhtGiDU4.append(TQ5GC0gPwuDm8h)
	fwDKASjdbmGvouLTFke,nGDiAaz5c19Xgq = [],[]
	for TQ5GC0gPwuDm8h in t1gk4L5hdYeTmupf2ivaZlWQH+q1RcFM2Hwd:
		if TQ5GC0gPwuDm8h[ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"࠭ࡩࡵࡣࡪࠫை")] not in fwDKASjdbmGvouLTFke:
			fwDKASjdbmGvouLTFke.append(TQ5GC0gPwuDm8h[XrTw01KtLzbpoyMf(u"ࠧࡪࡶࡤ࡫ࠬ௉")])
			nGDiAaz5c19Xgq.append(TQ5GC0gPwuDm8h)
	for dict in mmeFhtGiDU4+nGDiAaz5c19Xgq:
		if jXE2YHkswT8y(u"ࠨ࡫ࡷࡥ࡬࠭ொ") in list(dict.keys()): dict[vODxLKW5Ql6r4Fbm8(u"ࠩ࡬ࡸࡦ࡭ࠧோ")] = str(dict[xpT28sXu051(u"ࠪ࡭ࡹࡧࡧࠨௌ")])
		if YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠫ࡫ࡶࡳࠨ்") in list(dict.keys()): dict[HtK4o2sTPgA78U(u"ࠬ࡬ࡰࡴࠩ௎")] = str(dict[SaB5hx3PZwXRLtKgrTfQvId(u"࠭ࡦࡱࡵࠪ௏")])
		if EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠧ࡮࡫ࡰࡩ࡙ࡿࡰࡦࠩௐ") in list(dict.keys()): dict[TlGXWLYsV1z(u"ࠨࡶࡼࡴࡪ࠭௑")] = dict[EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠩࡰ࡭ࡲ࡫ࡔࡺࡲࡨࠫ௒")]
		if LyNiIHPOwD3hCUYEFM7(u"ࠪࡥࡺࡪࡩࡰࡕࡤࡱࡵࡲࡥࡓࡣࡷࡩࠬ௓") in list(dict.keys()): dict[AbqCJZdWQP9j(u"ࠫࡦࡻࡤࡪࡱࡢࡷࡦࡳࡰ࡭ࡧࡢࡶࡦࡺࡥࠨ௔")] = str(dict[GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠬࡧࡵࡥ࡫ࡲࡗࡦࡳࡰ࡭ࡧࡕࡥࡹ࡫ࠧ௕")])
		if y6y5HtgXO4TkUbwVZ(u"࠭ࡡࡶࡦ࡬ࡳࡈ࡮ࡡ࡯ࡰࡨࡰࡸ࠭௖") in list(dict.keys()): dict[xpT28sXu051(u"ࠧࡢࡷࡧ࡭ࡴࡥࡣࡩࡣࡱࡲࡪࡲࡳࠨௗ")] = str(dict[Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠨࡣࡸࡨ࡮ࡵࡃࡩࡣࡱࡲࡪࡲࡳࠨ௘")])
		if yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠩࡺ࡭ࡩࡺࡨࠨ௙") in list(dict.keys()): dict[ZchUJdM93pTA7zG5(u"ࠪࡷ࡮ࢀࡥࠨ௚")] = str(dict[IpC4qHXRuyNFjzWv(u"ࠫࡼ࡯ࡤࡵࡪࠪ௛")])+UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠬࡾࠧ௜")+str(dict[MgP8OjoaiWQEVG59(u"࠭ࡨࡦ࡫ࡪ࡬ࡹ࠭௝")])
		if yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠧࡪࡰ࡬ࡸࡗࡧ࡮ࡨࡧࠪ௞") in list(dict.keys()): dict[hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠨ࡫ࡱ࡭ࡹ࠭௟")] = dict[xpT28sXu051(u"ࠩ࡬ࡲ࡮ࡺࡒࡢࡰࡪࡩࠬ௠")][HtK4o2sTPgA78U(u"ࠪࡷࡹࡧࡲࡵࠩ௡")]+SaB5hx3PZwXRLtKgrTfQvId(u"ࠫ࠲࠭௢")+dict[GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠬ࡯࡮ࡪࡶࡕࡥࡳ࡭ࡥࠨ௣")][SaB5hx3PZwXRLtKgrTfQvId(u"࠭ࡥ࡯ࡦࠪ௤")]
		if uuExaKGL7UONtevRd(u"ࠧࡪࡰࡧࡩࡽࡘࡡ࡯ࡩࡨࠫ௥") in list(dict.keys()): dict[tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠨ࡫ࡱࡨࡪࡾࠧ௦")] = dict[TlGXWLYsV1z(u"ࠩ࡬ࡲࡩ࡫ࡸࡓࡣࡱ࡫ࡪ࠭௧")][zmcGfOdvAjsELeJlP(u"ࠪࡷࡹࡧࡲࡵࠩ௨")]+hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠫ࠲࠭௩")+dict[uuExaKGL7UONtevRd(u"ࠬ࡯࡮ࡥࡧࡻࡖࡦࡴࡧࡦࠩ௪")][PtkEvXAqif14G20QZsaSyT(u"࠭ࡥ࡯ࡦࠪ௫")]
		if AbqCJZdWQP9j(u"ࠧࡢࡸࡨࡶࡦ࡭ࡥࡃ࡫ࡷࡶࡦࡺࡥࠨ௬") in list(dict.keys()): dict[zmcGfOdvAjsELeJlP(u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ௭")] = dict[HtK4o2sTPgA78U(u"ࠩࡤࡺࡪࡸࡡࡨࡧࡅ࡭ࡹࡸࡡࡵࡧࠪ௮")]
		if yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ௯") in list(dict.keys()) and int(dict[hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ௰")])>jXE2YHkswT8y(u"࠵࠶࠷࠲࠳࠴࠶࠷࠸๘"): del dict[hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭௱")]
		if LyNiIHPOwD3hCUYEFM7(u"࠭ࡳࡪࡩࡱࡥࡹࡻࡲࡦࡅ࡬ࡴ࡭࡫ࡲࠨ௲") in list(dict.keys()):
			C3xrhOvKsTl6J1EdAyIB = dict[HtK4o2sTPgA78U(u"ࠧࡴ࡫ࡪࡲࡦࡺࡵࡳࡧࡆ࡭ࡵ࡮ࡥࡳࠩ௳")].split(uuExaKGL7UONtevRd(u"ࠨࠨࠪ௴"))
			for YXD9KNfjCaLwkcrvJxldn7I in C3xrhOvKsTl6J1EdAyIB:
				key,aasX2cby4Vo5rTgB = YXD9KNfjCaLwkcrvJxldn7I.split(XrTw01KtLzbpoyMf(u"ࠩࡀࠫ௵"),FRYcH4KL7e9gv5pEB(u"࠶๙"))
				dict[key] = a9I3YZjc6ySDPE4Kp(aasX2cby4Vo5rTgB)
		if yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠪࡹࡷࡲࠧ௶") in list(dict.keys()): dict[LyNiIHPOwD3hCUYEFM7(u"ࠫࡺࡸ࡬ࠨ௷")] = a9I3YZjc6ySDPE4Kp(dict[hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠬࡻࡲ࡭ࠩ௸")])
		SSAgyW0Qnx6jMvfLU1c.append(dict)
	YMszTC150dPxakqybR8QJnlpohfiNu = iiy37aKq0pCEIOwfcTh61xb4U
	if EMO8gy4LrsNTh0knZwpSeU75APW(u"࠭ࡳࡱ࠿ࡶ࡭࡬࠭௹") in tcv3rnuCFEQmzf6i9XhgUH or AbqCJZdWQP9j(u"ࠧࡴࡲࡀࡷ࡮࡭ࠧ௺") in BuxFjX0omMZe7qJDPaVUr:
		if not Vxz6OndPIX4g2kaRp7:
			oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(hI7SkXd94fFzAHNZCQoMqEutbnWP,vODxLKW5Ql6r4Fbm8(u"ࠨࡉࡈࡘࠬ௻"),eCGwzSrqBmIv,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,PtkEvXAqif14G20QZsaSyT(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡟ࡏࡖࡖࡘࡆࡊ࠳࠵ࡵࡪࠪ௼"))
			Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
		HHUlF9AW1X7a3vxsDpMuoKLtQr = dEyT9xhGjolYzLCH7460w3.findall(xpT28sXu051(u"ࠪࡷࡷࡩ࠽ࠣࠪ࠲ࡷ࠴ࡶ࡬ࡢࡻࡨࡶ࠴ࡢࡷࠫࡁ࠲ࡴࡱࡧࡹࡦࡴࡢ࡭ࡦࡹ࠮ࡷࡨ࡯ࡷࡪࡺ࠯ࡦࡰࡢ࠲࠳࠵ࡢࡢࡵࡨ࠲࡯ࡹࠩࠣࠩ௽"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if HHUlF9AW1X7a3vxsDpMuoKLtQr:
			HHUlF9AW1X7a3vxsDpMuoKLtQr = gZ4LwbKaOm[sVzojQerUqX(u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬ௾")][FGTfwsjNrB8DvKSZhLIQAb1JnO]+HHUlF9AW1X7a3vxsDpMuoKLtQr[FGTfwsjNrB8DvKSZhLIQAb1JnO]
			oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(hI7SkXd94fFzAHNZCQoMqEutbnWP,ZchUJdM93pTA7zG5(u"ࠬࡍࡅࡕࠩ௿"),HHUlF9AW1X7a3vxsDpMuoKLtQr,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,MgP8OjoaiWQEVG59(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡜ࡓ࡚࡚ࡕࡃࡇ࠰࠺ࡹ࡮ࠧఀ"))
			YMszTC150dPxakqybR8QJnlpohfiNu = oCJ8TdG2LwSIVcbaUnhB.content
			import youtube_signature.cipher as llCEgjh1yAtfu,youtube_signature.json_script_engine as nk4ixPe9bms8wMvTCJ3qHNSgWAtG
			C3xrhOvKsTl6J1EdAyIB = YtO47FPE23ghvow1VsjLWJyTCIuaeU.C3xrhOvKsTl6J1EdAyIB.Cipher()
			C3xrhOvKsTl6J1EdAyIB._object_cache = {}
			sxDXVijJFmIUZaS = C3xrhOvKsTl6J1EdAyIB._load_javascript(YMszTC150dPxakqybR8QJnlpohfiNu)
			jsKSvQeZVhEdYI3q0Xlb1uPwkAn = DeIL3qoa2UBtYPb(AbqCJZdWQP9j(u"ࠧࡴࡶࡵࠫఁ"),str(sxDXVijJFmIUZaS))
			Wfaq3jgYenpMl4i = YtO47FPE23ghvow1VsjLWJyTCIuaeU.fITLW3GpVO.JsonScriptEngine(jsKSvQeZVhEdYI3q0Xlb1uPwkAn)
	for dict in SSAgyW0Qnx6jMvfLU1c:
		url = dict[Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠨࡷࡵࡰࠬం")]
		if GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠩࡶ࡭࡬ࡴࡡࡵࡷࡵࡩࡂ࠭ః") in url or url.count(sVzojQerUqX(u"ࠪࡷ࡮࡭࠽ࠨఄ"))>YYJQyRskpX8jv:
			FHo3LOXeNq6CV2JtgkZhE1.append(dict)
		elif YMszTC150dPxakqybR8QJnlpohfiNu and HtK4o2sTPgA78U(u"ࠫࡸ࠭అ") in list(dict.keys()) and jXE2YHkswT8y(u"ࠬࡹࡰࠨఆ") in list(dict.keys()):
			VXZRtuOkr5 = Wfaq3jgYenpMl4i.execute(dict[HtK4o2sTPgA78U(u"࠭ࡳࠨఇ")])
			if VXZRtuOkr5!=dict[sVzojQerUqX(u"ࠧࡴࠩఈ")]:
				dict[sVzojQerUqX(u"ࠨࡷࡵࡰࠬఉ")] = url+SaB5hx3PZwXRLtKgrTfQvId(u"ࠩࠩࠫఊ")+dict[IpC4qHXRuyNFjzWv(u"ࠪࡷࡵ࠭ఋ")]+ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠫࡂ࠭ఌ")+VXZRtuOkr5
				FHo3LOXeNq6CV2JtgkZhE1.append(dict)
	for dict in FHo3LOXeNq6CV2JtgkZhE1:
		d2xq6KCoULIiPWOyFwp0t,Q2ndkD7ajwxAycMSLge,i7RVwF3DB4Y,uuX8TYmVoFRlvpQ7LZ,Q7tkVXZSHiO9E10To45PN,ttKWoIH83b = tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠬࡻ࡮࡬ࡰࡲࡻࡳ࠭఍"),jXE2YHkswT8y(u"࠭ࡵ࡯࡭ࡱࡳࡼࡴࠧఎ"),ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠧࡶࡰ࡮ࡲࡴࡽ࡮ࠨఏ"),tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠨࡗࡱ࡯ࡳࡵࡷ࡯ࠩఐ"),iiy37aKq0pCEIOwfcTh61xb4U,TlGXWLYsV1z(u"ࠩ࠳ࠫ఑")
		try:
			CovEOMedKrj = dict[jXE2YHkswT8y(u"ࠪࡸࡾࡶࡥࠨఒ")]
			CovEOMedKrj = CovEOMedKrj.replace(AbqCJZdWQP9j(u"ࠫ࠰࠭ఓ"),iiy37aKq0pCEIOwfcTh61xb4U)
			items = dEyT9xhGjolYzLCH7460w3.findall(IpC4qHXRuyNFjzWv(u"ࠬ࠮࠮ࠫࡁࠬ࠳࠭࠴ࠪࡀࠫ࠾࠲࠯ࡅࠢࠩ࠰࠭ࡃ࠮ࠨࠧఔ"),CovEOMedKrj,dEyT9xhGjolYzLCH7460w3.DOTALL)
			uuX8TYmVoFRlvpQ7LZ,d2xq6KCoULIiPWOyFwp0t,Q7tkVXZSHiO9E10To45PN = items[FGTfwsjNrB8DvKSZhLIQAb1JnO]
			TT37yC4V52pozHmG0w6OxDq = Q7tkVXZSHiO9E10To45PN.split(y6y5HtgXO4TkUbwVZ(u"࠭ࠬࠨక"))
			Q2ndkD7ajwxAycMSLge = iiy37aKq0pCEIOwfcTh61xb4U
			for YXD9KNfjCaLwkcrvJxldn7I in TT37yC4V52pozHmG0w6OxDq: Q2ndkD7ajwxAycMSLge += YXD9KNfjCaLwkcrvJxldn7I.split(sVzojQerUqX(u"ࠧ࠯ࠩఖ"))[FGTfwsjNrB8DvKSZhLIQAb1JnO]+TlGXWLYsV1z(u"ࠨ࠮ࠪగ")
			Q2ndkD7ajwxAycMSLge = Q2ndkD7ajwxAycMSLge.strip(YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠩ࠯ࠫఘ"))
			if YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫఙ") in list(dict.keys()): ttKWoIH83b = str(int(dict[JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬచ")])//uuExaKGL7UONtevRd(u"࠷࠰࠳࠶๚"))+sVzojQerUqX(u"ࠬࡱࡢࡱࡵࠣࠤࠬఛ")
			else: ttKWoIH83b = iiy37aKq0pCEIOwfcTh61xb4U
			if uuX8TYmVoFRlvpQ7LZ==ZchUJdM93pTA7zG5(u"࠭ࡴࡦࡺࡷࡸࠬజ"): continue
			elif xpT28sXu051(u"ࠧ࠭ࠩఝ") in CovEOMedKrj:
				uuX8TYmVoFRlvpQ7LZ = FRYcH4KL7e9gv5pEB(u"ࠨࡃ࠮࡚ࠬఞ")
				i7RVwF3DB4Y = d2xq6KCoULIiPWOyFwp0t+Wc5GekRC0HQLz7+ttKWoIH83b+dict[IpC4qHXRuyNFjzWv(u"ࠩࡶ࡭ࡿ࡫ࠧట")].split(tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠪࡼࠬఠ"))[YYJQyRskpX8jv]
			elif uuX8TYmVoFRlvpQ7LZ==JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠫࡻ࡯ࡤࡦࡱࠪడ"):
				uuX8TYmVoFRlvpQ7LZ = XrTw01KtLzbpoyMf(u"ࠬ࡜ࡩࡥࡧࡲࠫఢ")
				i7RVwF3DB4Y = ttKWoIH83b+dict[HtK4o2sTPgA78U(u"࠭ࡳࡪࡼࡨࠫణ")].split(L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠧࡹࠩత"))[YYJQyRskpX8jv]+Wc5GekRC0HQLz7+dict[PtkEvXAqif14G20QZsaSyT(u"ࠨࡨࡳࡷࠬథ")]+jXE2YHkswT8y(u"ࠩࡩࡴࡸ࠭ద")+Wc5GekRC0HQLz7+d2xq6KCoULIiPWOyFwp0t
			elif uuX8TYmVoFRlvpQ7LZ==SaB5hx3PZwXRLtKgrTfQvId(u"ࠪࡥࡺࡪࡩࡰࠩధ"):
				uuX8TYmVoFRlvpQ7LZ = ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠫࡆࡻࡤࡪࡱࠪన")
				i7RVwF3DB4Y = ttKWoIH83b+str(int(dict[ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠬࡧࡵࡥ࡫ࡲࡣࡸࡧ࡭ࡱ࡮ࡨࡣࡷࡧࡴࡦࠩ఩")])/UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"࠱࠱࠲࠳๛"))+XrTw01KtLzbpoyMf(u"࠭࡫ࡩࡼࠣࠤࠬప")+dict[hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠧࡢࡷࡧ࡭ࡴࡥࡣࡩࡣࡱࡲࡪࡲࡳࠨఫ")]+hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠨࡥ࡫ࠫబ")+Wc5GekRC0HQLz7+d2xq6KCoULIiPWOyFwp0t
		except:
			UIxuCn8wAWpgz5j9EdqFvreH = xiFBCH5hcJks.format_exc()
			if UIxuCn8wAWpgz5j9EdqFvreH!=vODxLKW5Ql6r4Fbm8(u"ࠩࡑࡳࡳ࡫ࡔࡺࡲࡨ࠾ࠥࡔ࡯࡯ࡧ࡟ࡲࠬభ"): ytv0YaxDcRINurplWKg587Pwqz.stderr.write(UIxuCn8wAWpgz5j9EdqFvreH)
		if GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠪࡨࡺࡸ࠽ࠨమ") in dict[Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠫࡺࡸ࡬ࠨయ")]: Zt6GY7K2oFeAd5kTy3nJvDBpQr = round(tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"࠲࠱࠹๝")+float(dict[CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠬࡻࡲ࡭ࠩర")].split(JZszNnIEMAx28Yao0yqhiXGKOPb(u"࠭ࡤࡶࡴࡀࠫఱ"),PtkEvXAqif14G20QZsaSyT(u"࠲๜"))[YYJQyRskpX8jv].split(SaB5hx3PZwXRLtKgrTfQvId(u"ࠧࠧࠩల"),YYJQyRskpX8jv)[FGTfwsjNrB8DvKSZhLIQAb1JnO]))
		elif TlGXWLYsV1z(u"ࠨࡣࡳࡴࡷࡵࡸࡅࡷࡵࡥࡹ࡯࡯࡯ࡏࡶࠫళ") in list(dict.keys()): Zt6GY7K2oFeAd5kTy3nJvDBpQr = round(XrTw01KtLzbpoyMf(u"࠳࠲࠺๞")+float(dict[XrTw01KtLzbpoyMf(u"ࠩࡤࡴࡵࡸ࡯ࡹࡆࡸࡶࡦࡺࡩࡰࡰࡐࡷࠬఴ")])/MgP8OjoaiWQEVG59(u"࠵࠵࠶࠰๟"))
		else: Zt6GY7K2oFeAd5kTy3nJvDBpQr = xpT28sXu051(u"ࠪ࠴ࠬవ")
		if hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬశ") not in list(dict.keys()): ttKWoIH83b = dict[EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠬࡹࡩࡻࡧࠪష")].split(tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"࠭ࡸࠨస"))[YYJQyRskpX8jv]
		else: ttKWoIH83b = str(int(dict[MgP8OjoaiWQEVG59(u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨహ")])//xpT28sXu051(u"࠶࠶࠲࠵๠"))
		if hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠨ࡫ࡱ࡭ࡹ࠭఺") not in list(dict.keys()): dict[jXE2YHkswT8y(u"ࠩ࡬ࡲ࡮ࡺࠧ఻")] = ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠪ࠴࠲࠶఼ࠧ")
		dict[sVzojQerUqX(u"ࠫࡹ࡯ࡴ࡭ࡧࠪఽ")] = uuX8TYmVoFRlvpQ7LZ+AbqCJZdWQP9j(u"ࠬࡀࠠࠡࠩా")+i7RVwF3DB4Y+hhQwbeiNLoqFjX90fB7aG8VAs(u"࠭ࠠࠡࠪࠪి")+Q2ndkD7ajwxAycMSLge+PtkEvXAqif14G20QZsaSyT(u"ࠧ࠭ࠩీ")+dict[tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠨ࡫ࡷࡥ࡬࠭ు")]+Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠩࠬࠫూ")
		dict[UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠪࡵࡺࡧ࡬ࡪࡶࡼࠫృ")] = i7RVwF3DB4Y.split(Wc5GekRC0HQLz7)[FGTfwsjNrB8DvKSZhLIQAb1JnO].split(GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠫࡰࡨࡰࡴࠩౄ"))[FGTfwsjNrB8DvKSZhLIQAb1JnO]
		dict[tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠬࡺࡹࡱࡧ࠵ࠫ౅")] = uuX8TYmVoFRlvpQ7LZ
		dict[y6y5HtgXO4TkUbwVZ(u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨె")] = d2xq6KCoULIiPWOyFwp0t
		dict[SaB5hx3PZwXRLtKgrTfQvId(u"ࠧࡤࡱࡧࡩࡨࡹࠧే")] = Q7tkVXZSHiO9E10To45PN
		dict[ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠨࡦࡸࡶࡦࡺࡩࡰࡰࠪై")] = Zt6GY7K2oFeAd5kTy3nJvDBpQr
		dict[YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ౉")] = ttKWoIH83b
		NNVezSPHdra18k4KLvnA2YwMhyFR.append(dict)
	eQ9FZswqJkm0gLxYt7NyTI,mweo95CsVi0N2UYSZxXkpdnLROl6,RrTEaFCiI0Q4gMBuw3HP,WF2HQkT78zVtGJoRsZfm3U,ffvh9ctdCnj = [],[],[],[],[]
	CGyRnQH1N7tBp8ciPDdKFxAjvlV,Mna6Gyte01wLp,iFZPlbN1CMgKsGIS4kBY9UrQuxXV6z,aato3BHjVKd6cpwqQmy1rPNu,aGfDxmJtAKdZ = [],[],[],[],[]
	for yXaup4BtEZr7xhP1wekq3U in KwBmHk9YnNRS:
		if not yXaup4BtEZr7xhP1wekq3U: continue
		dict = {}
		dict[SaB5hx3PZwXRLtKgrTfQvId(u"ࠪࡸࡾࡶࡥ࠳ࠩొ")] = CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠫࡆ࠱ࡖࠨో")
		dict[ZchUJdM93pTA7zG5(u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧౌ")] = MgP8OjoaiWQEVG59(u"࠭࡭ࡱࡦ్ࠪ")
		dict[sVzojQerUqX(u"ࠧࡵ࡫ࡷࡰࡪ࠭౎")] = dict[UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠨࡶࡼࡴࡪ࠸ࠧ౏")]+zmcGfOdvAjsELeJlP(u"ࠩ࠽ࠤࠥ࠭౐")+dict[yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠪࡪ࡮ࡲࡥࡵࡻࡳࡩࠬ౑")]+Wc5GekRC0HQLz7+YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠫั๎ฯสࠢำ็๏ฯࠧ౒")
		dict[SaB5hx3PZwXRLtKgrTfQvId(u"ࠬࡻࡲ࡭ࠩ౓")] = yXaup4BtEZr7xhP1wekq3U
		dict[MgP8OjoaiWQEVG59(u"࠭ࡱࡶࡣ࡯࡭ࡹࡿࠧ౔")] = AbqCJZdWQP9j(u"ࠧ࠱ౕࠩ")
		dict[vODxLKW5Ql6r4Fbm8(u"ࠨࡤ࡬ࡸࡷࡧࡴࡦౖࠩ")] = tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠩ࠴࠵࠶࠸࠲࠳࠵࠶࠷ࠬ౗")
		NNVezSPHdra18k4KLvnA2YwMhyFR.append(dict)
	for pYkv4ic7HFGK0jCqUsJ165T in rnCEDXPB47:
		if not pYkv4ic7HFGK0jCqUsJ165T: continue
		Dz1CNgS8XGrx6YWuORlUefQB,x8x42QwarFnvlhNmDXpLiUWtPyRqgj = VKTp8gacXPG9Zr4H3NQCM0O(sQU2GnRoMwLK8CBdfzmNr4jXyO,pYkv4ic7HFGK0jCqUsJ165T)
		tiK1nfoE7A = list(zip(Dz1CNgS8XGrx6YWuORlUefQB,x8x42QwarFnvlhNmDXpLiUWtPyRqgj))
		for title,fCXyTlcmF4WuetVork in tiK1nfoE7A:
			dict = {}
			dict[CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠪࡸࡾࡶࡥ࠳ࠩౘ")] = tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠫࡆ࠱ࡖࠨౙ")
			dict[TlGXWLYsV1z(u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧౚ")] = vODxLKW5Ql6r4Fbm8(u"࠭࡭࠴ࡷ࠻ࠫ౛")
			dict[FRYcH4KL7e9gv5pEB(u"ࠧࡶࡴ࡯ࠫ౜")] = fCXyTlcmF4WuetVork
			if MgP8OjoaiWQEVG59(u"ࠨ࡭ࡥࡴࡸ࠭ౝ") in title: dict[Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ౞")] = title.split(vODxLKW5Ql6r4Fbm8(u"ࠪ࡯ࡧࡶࡳࠨ౟"))[FGTfwsjNrB8DvKSZhLIQAb1JnO].rsplit(Wc5GekRC0HQLz7)[-YYJQyRskpX8jv]
			else: dict[CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬౠ")] = SaB5hx3PZwXRLtKgrTfQvId(u"ࠬ࠷࠰ࠨౡ")
			if title.count(Wc5GekRC0HQLz7)>YYJQyRskpX8jv:
				pMAWqrwP80lR = title.rsplit(Wc5GekRC0HQLz7)[-iiCWLaJREureAlOkv]
				if pMAWqrwP80lR.isdigit(): dict[Y41NvKfOroMzGB8sEHy7wbXlc5(u"࠭ࡱࡶࡣ࡯࡭ࡹࡿࠧౢ")] = pMAWqrwP80lR
				else: dict[L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠧࡲࡷࡤࡰ࡮ࡺࡹࠨౣ")] = sVzojQerUqX(u"ࠨ࠲࠳࠴࠵࠭౤")
			if title==CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠩ࠰࠵ࠬ౥"): dict[hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠪࡸ࡮ࡺ࡬ࡦࠩ౦")] = dict[jXE2YHkswT8y(u"ࠫࡹࡿࡰࡦ࠴ࠪ౧")]+LyNiIHPOwD3hCUYEFM7(u"ࠬࡀࠠࠡࠩ౨")+dict[LyNiIHPOwD3hCUYEFM7(u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨ౩")]+Wc5GekRC0HQLz7+EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠧอ๊าอࠥึใ๋หࠪ౪")
			else: dict[jXE2YHkswT8y(u"ࠨࡶ࡬ࡸࡱ࡫ࠧ౫")] = dict[hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠩࡷࡽࡵ࡫࠲ࠨ౬")]+ZchUJdM93pTA7zG5(u"ࠪ࠾ࠥࠦࠧ౭")+dict[PtkEvXAqif14G20QZsaSyT(u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭౮")]+Wc5GekRC0HQLz7+dict[tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭౯")]+xpT28sXu051(u"࠭࡫ࡣࡲࡶࠤࠥ࠭౰")+dict[ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠧࡲࡷࡤࡰ࡮ࡺࡹࠨ౱")]
			NNVezSPHdra18k4KLvnA2YwMhyFR.append(dict)
	NNVezSPHdra18k4KLvnA2YwMhyFR = sorted(NNVezSPHdra18k4KLvnA2YwMhyFR,reverse=rGPen6cSMHQkAywh8vqI9JXiD2,key=lambda key: int(key[yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ౲")]))
	if not NNVezSPHdra18k4KLvnA2YwMhyFR:
		if not Vxz6OndPIX4g2kaRp7:
			oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(hI7SkXd94fFzAHNZCQoMqEutbnWP,ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠩࡊࡉ࡙࠭౳"),eCGwzSrqBmIv,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,AbqCJZdWQP9j(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳࡙ࡐࡗࡗ࡙ࡇࡋ࠭࠸ࡶ࡫ࠫ౴"))
			Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
		ngZh3MbtFxsQAjGvyUJ67VN = dEyT9xhGjolYzLCH7460w3.findall(FRYcH4KL7e9gv5pEB(u"ࠫࡨࡲࡡࡴࡵࡀࠦࡲ࡫ࡳࡴࡣࡪࡩࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ౵"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		E8ZibMeyGK = dEyT9xhGjolYzLCH7460w3.findall(HtK4o2sTPgA78U(u"ࠬࠨࡰ࡭ࡣࡼࡩࡷࡋࡲࡳࡱࡵࡑࡪࡹࡳࡢࡩࡨࡖࡪࡴࡤࡦࡴࡨࡶࠧࡀ࡜ࡼࠤࡶࡹࡧࡸࡥࡢࡵࡲࡲࠧࡀ࡜ࡼࠤࡵࡹࡳࡹࠢ࠻࡞࡞ࡠࢀࠨࡴࡦࡺࡷࡸࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ౶"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		dANSkE5C2gKL4z7DTmuXBFR = dEyT9xhGjolYzLCH7460w3.findall(hhQwbeiNLoqFjX90fB7aG8VAs(u"࠭ࠢࡱ࡮ࡤࡽࡪࡸࡅࡳࡴࡲࡶࡒ࡫ࡳࡴࡣࡪࡩࡗ࡫࡮ࡥࡧࡵࡩࡷࠨ࠺࡝ࡽࠥࡶࡪࡧࡳࡰࡰࠥ࠾ࢀࠨࡳࡪ࡯ࡳࡰࡪ࡚ࡥࡹࡶࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ౷"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		ngWSHzwAk1r8oKB = dEyT9xhGjolYzLCH7460w3.findall(FRYcH4KL7e9gv5pEB(u"ࠧࠣࡲ࡯ࡥࡾ࡫ࡲࡆࡴࡵࡳࡷࡓࡥࡴࡵࡤ࡫ࡪࡘࡥ࡯ࡦࡨࡶࡪࡸࠢ࠻࡞ࡾࠦࡸࡻࡢࡳࡧࡤࡷࡴࡴࠢ࠻ࡽࠥࡷ࡮ࡳࡰ࡭ࡧࡗࡩࡽࡺࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ౸"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		eWfZ8zVxDEnvBpt7ALl3yITuhKa5M,ndc28qGFgoxVZ1YOeQs4wR,AI80az1VycjT7xRg6wHJ2QnLik3ZOl = iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U
		try: eWfZ8zVxDEnvBpt7ALl3yITuhKa5M = rfBAJx30NnHwdekY6icT2MSZULl[UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠨࡲ࡯ࡥࡾࡧࡢࡪ࡮࡬ࡸࡾ࡙ࡴࡢࡶࡸࡷࠬ౹")][hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠩࡨࡶࡷࡵࡲࡔࡥࡵࡩࡪࡴࠧ౺")][tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠪࡧࡴࡴࡦࡪࡴࡰࡈ࡮ࡧ࡬ࡰࡩࡕࡩࡳࡪࡥࡳࡧࡵࠫ౻")][jXE2YHkswT8y(u"ࠫࡹ࡯ࡴ࡭ࡧࠪ౼")][LyNiIHPOwD3hCUYEFM7(u"ࠬࡸࡵ࡯ࡵࠪ౽")][FGTfwsjNrB8DvKSZhLIQAb1JnO][hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"࠭ࡴࡦࡺࡷࡸࠬ౾")]
		except:
			try: eWfZ8zVxDEnvBpt7ALl3yITuhKa5M = qAawdug1ko6G9zp[HtK4o2sTPgA78U(u"ࠧࡱ࡮ࡤࡽࡦࡨࡩ࡭࡫ࡷࡽࡘࡺࡡࡵࡷࡶࠫ౿")][Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠨࡧࡵࡶࡴࡸࡓࡤࡴࡨࡩࡳ࠭ಀ")][MgP8OjoaiWQEVG59(u"ࠩࡦࡳࡳ࡬ࡩࡳ࡯ࡇ࡭ࡦࡲ࡯ࡨࡔࡨࡲࡩ࡫ࡲࡦࡴࠪಁ")][MgP8OjoaiWQEVG59(u"ࠪࡸ࡮ࡺ࡬ࡦࠩಂ")][MgP8OjoaiWQEVG59(u"ࠫࡷࡻ࡮ࡴࠩಃ")][FGTfwsjNrB8DvKSZhLIQAb1JnO][zmcGfOdvAjsELeJlP(u"ࠬࡺࡥࡹࡶࡷࠫ಄")]
			except: pass
		try: ndc28qGFgoxVZ1YOeQs4wR = rfBAJx30NnHwdekY6icT2MSZULl[IpC4qHXRuyNFjzWv(u"࠭ࡰ࡭ࡣࡼࡥࡧ࡯࡬ࡪࡶࡼࡗࡹࡧࡴࡶࡵࠪಅ")][Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠧࡦࡴࡵࡳࡷ࡙ࡣࡳࡧࡨࡲࠬಆ")][CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠨࡥࡲࡲ࡫࡯ࡲ࡮ࡆ࡬ࡥࡱࡵࡧࡓࡧࡱࡨࡪࡸࡥࡳࠩಇ")][ZchUJdM93pTA7zG5(u"ࠩࡧ࡭ࡦࡲ࡯ࡨࡏࡨࡷࡸࡧࡧࡦࡵࠪಈ")][FGTfwsjNrB8DvKSZhLIQAb1JnO][HtK4o2sTPgA78U(u"ࠪࡶࡺࡴࡳࠨಉ")][FGTfwsjNrB8DvKSZhLIQAb1JnO][GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠫࡹ࡫ࡸࡵࡶࠪಊ")]
		except:
			try: ndc28qGFgoxVZ1YOeQs4wR = qAawdug1ko6G9zp[EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠬࡶ࡬ࡢࡻࡤࡦ࡮ࡲࡩࡵࡻࡖࡸࡦࡺࡵࡴࠩಋ")][MgP8OjoaiWQEVG59(u"࠭ࡥࡳࡴࡲࡶࡘࡩࡲࡦࡧࡱࠫಌ")][MgP8OjoaiWQEVG59(u"ࠧࡤࡱࡱࡪ࡮ࡸ࡭ࡅ࡫ࡤࡰࡴ࡭ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ಍")][uuExaKGL7UONtevRd(u"ࠨࡦ࡬ࡥࡱࡵࡧࡎࡧࡶࡷࡦ࡭ࡥࡴࠩಎ")][FGTfwsjNrB8DvKSZhLIQAb1JnO][ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠩࡵࡹࡳࡹࠧಏ")][FGTfwsjNrB8DvKSZhLIQAb1JnO][sVzojQerUqX(u"ࠪࡸࡪࡾࡴࡵࠩಐ")]
			except: pass
		try: AI80az1VycjT7xRg6wHJ2QnLik3ZOl = rfBAJx30NnHwdekY6icT2MSZULl[CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠫࡵࡲࡡࡺࡣࡥ࡭ࡱ࡯ࡴࡺࡕࡷࡥࡹࡻࡳࠨ಑")][HtK4o2sTPgA78U(u"ࠬࡸࡥࡢࡵࡲࡲࠬಒ")]
		except:
			try: AI80az1VycjT7xRg6wHJ2QnLik3ZOl = qAawdug1ko6G9zp[hhQwbeiNLoqFjX90fB7aG8VAs(u"࠭ࡰ࡭ࡣࡼࡥࡧ࡯࡬ࡪࡶࡼࡗࡹࡧࡴࡶࡵࠪಓ")][ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠧࡳࡧࡤࡷࡴࡴࠧಔ")]
			except: pass
		if ngZh3MbtFxsQAjGvyUJ67VN or E8ZibMeyGK or dANSkE5C2gKL4z7DTmuXBFR or ngWSHzwAk1r8oKB or eWfZ8zVxDEnvBpt7ALl3yITuhKa5M or ndc28qGFgoxVZ1YOeQs4wR or AI80az1VycjT7xRg6wHJ2QnLik3ZOl:
			if   ngZh3MbtFxsQAjGvyUJ67VN: aZtYlicqMKUFPkBCX2AONHwJ4 = ngZh3MbtFxsQAjGvyUJ67VN[FGTfwsjNrB8DvKSZhLIQAb1JnO]
			elif E8ZibMeyGK: aZtYlicqMKUFPkBCX2AONHwJ4 = E8ZibMeyGK[FGTfwsjNrB8DvKSZhLIQAb1JnO]
			elif dANSkE5C2gKL4z7DTmuXBFR: aZtYlicqMKUFPkBCX2AONHwJ4 = dANSkE5C2gKL4z7DTmuXBFR[FGTfwsjNrB8DvKSZhLIQAb1JnO]
			elif ngWSHzwAk1r8oKB: aZtYlicqMKUFPkBCX2AONHwJ4 = ngWSHzwAk1r8oKB[FGTfwsjNrB8DvKSZhLIQAb1JnO]
			elif eWfZ8zVxDEnvBpt7ALl3yITuhKa5M: aZtYlicqMKUFPkBCX2AONHwJ4 = eWfZ8zVxDEnvBpt7ALl3yITuhKa5M
			elif ndc28qGFgoxVZ1YOeQs4wR: aZtYlicqMKUFPkBCX2AONHwJ4 = ndc28qGFgoxVZ1YOeQs4wR
			elif AI80az1VycjT7xRg6wHJ2QnLik3ZOl: aZtYlicqMKUFPkBCX2AONHwJ4 = AI80az1VycjT7xRg6wHJ2QnLik3ZOl
			tWvC5shuf6 = aZtYlicqMKUFPkBCX2AONHwJ4.replace(OTlVEGYPSxsNaBdXUucqA3,iiy37aKq0pCEIOwfcTh61xb4U).strip(iFBmE2MUIpSu34wsd7Rf6z)
			QRnKlxOp6bM2IhVSXz7k4F = PSwfZcdRYhpl5Igqz8xOEk67+XrTw01KtLzbpoyMf(u"ࠨ้ำหࠥอไโ์า๎ํࠦแู๋้้้ࠣไสࠢ࠱࠲ࠥษ่ࠡ฼ํี๋ࠥไศศ่ࠤ้ฮูืࠢสู่๊สฯั่๎๋ࠦ࠮࠯ࠢฦ์ࠥเ๊า่ࠢฮํ็ัࠡษ็ฦ๋ࠦ࠮࠯ࠢฦ์ࠥ๐่ห์๋ฬࠥ๐อหษฯࠤู๐มࠡ็ะำิࠦ࠮࠯ࠢฦ์ࠥ๐่ห์๋ฬࠥเ๊าࠢๅหิืࠠฤ่ࠣ๎ูเไࠡษ็ๅ๏ี๊้ࠢส่ว์ࠧಕ")+YoQW601K4fMJcsreDnGVE5wUZIy7
			bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅ้ไ฼ࠤํอไๆสิ้ั࠭ಖ"),QRnKlxOp6bM2IhVSXz7k4F+vODxLKW5Ql6r4Fbm8(u"ࠪࡠࡳࡢ࡮ࠨಗ")+aqEsMBckT2bunGHfl48Wip+UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠫึูวๅห้๋๊้ࠣࠦฬํ์อ࠭ಘ")+YoQW601K4fMJcsreDnGVE5wUZIy7+OTlVEGYPSxsNaBdXUucqA3+tWvC5shuf6)
			return ZchUJdM93pTA7zG5(u"ࠬࡋࡲࡳࡱࡵࠤࠥࠦࠠ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤ࡞ࡕࡕࡕࡗࡅࡉࠥࡌࡡࡪ࡮ࡨࡨ࠿ࠦࠧಙ")+tWvC5shuf6,[],[]
		else: return vODxLKW5Ql6r4Fbm8(u"࠭ࡅࡳࡴࡲࡶࠥࠦࠠࠡ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥ࡟ࡏࡖࡖࡘࡆࡊࠦࡆࡢ࡫࡯ࡩࡩ࠭ಚ"),[],[]
	tPbj6e8koZEhsAW1 = []
	for dict in NNVezSPHdra18k4KLvnA2YwMhyFR:
		if dict[L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠧࡵࡻࡳࡩ࠷࠭ಛ")]==TlGXWLYsV1z(u"ࠨࡘ࡬ࡨࡪࡵࠧಜ"):
			eQ9FZswqJkm0gLxYt7NyTI.append(dict[L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠩࡷ࡭ࡹࡲࡥࠨಝ")])
			CGyRnQH1N7tBp8ciPDdKFxAjvlV.append(dict)
		elif dict[hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠪࡸࡾࡶࡥ࠳ࠩಞ")]==y6y5HtgXO4TkUbwVZ(u"ࠫࡆࡻࡤࡪࡱࠪಟ"):
			mweo95CsVi0N2UYSZxXkpdnLROl6.append(dict[Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠬࡺࡩࡵ࡮ࡨࠫಠ")])
			Mna6Gyte01wLp.append(dict)
		elif dict[ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨಡ")]==EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠧ࡮ࡲࡧࠫಢ"):
			title = dict[UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠨࡶ࡬ࡸࡱ࡫ࠧಣ")].replace(EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠩࡄ࠯࡛ࡀࠠࠡࠩತ"),iiy37aKq0pCEIOwfcTh61xb4U)
			if uuExaKGL7UONtevRd(u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫಥ") not in list(dict.keys()): ttKWoIH83b = UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠫ࠵࠭ದ")
			else: ttKWoIH83b = dict[vODxLKW5Ql6r4Fbm8(u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭ಧ")]
			tPbj6e8koZEhsAW1.append([dict,{},title,ttKWoIH83b])
		else:
			title = dict[YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"࠭ࡴࡪࡶ࡯ࡩࠬನ")].replace(MgP8OjoaiWQEVG59(u"ࠧࡂ࡙࠭࠾ࠥࠦࠧ಩"),iiy37aKq0pCEIOwfcTh61xb4U)
			if CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩಪ") not in list(dict.keys()): ttKWoIH83b = MgP8OjoaiWQEVG59(u"ࠩ࠳ࠫಫ")
			else: ttKWoIH83b = dict[CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫಬ")]
			tPbj6e8koZEhsAW1.append([dict,{},title,ttKWoIH83b])
			RrTEaFCiI0Q4gMBuw3HP.append(title)
			iFZPlbN1CMgKsGIS4kBY9UrQuxXV6z.append(dict)
		QceVgxwDJbPM2jtkihUzq3nGAmp = rGPen6cSMHQkAywh8vqI9JXiD2
		if GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠫࡨࡵࡤࡦࡥࡶࠫಭ") in list(dict.keys()):
			if SaB5hx3PZwXRLtKgrTfQvId(u"ࠬࡧࡶ࠱ࠩಮ") in dict[hhQwbeiNLoqFjX90fB7aG8VAs(u"࠭ࡣࡰࡦࡨࡧࡸ࠭ಯ")]: QceVgxwDJbPM2jtkihUzq3nGAmp = BF6QAiLUNHh7rKOugaw
			elif ZD1J5rN8u2wzdgqoyULm4<xpT28sXu051(u"࠷࠸๡") and EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠧࡢࡸࡦࠫರ") not in dict[y6y5HtgXO4TkUbwVZ(u"ࠨࡥࡲࡨࡪࡩࡳࠨಱ")] and ZchUJdM93pTA7zG5(u"ࠩࡰࡴ࠹ࡧࠧಲ") not in dict[sVzojQerUqX(u"ࠪࡧࡴࡪࡥࡤࡵࠪಳ")]: QceVgxwDJbPM2jtkihUzq3nGAmp = BF6QAiLUNHh7rKOugaw
		if QceVgxwDJbPM2jtkihUzq3nGAmp and dict[Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠫࡹࡿࡰࡦ࠴ࠪ಴")]==uuExaKGL7UONtevRd(u"ࠬ࡜ࡩࡥࡧࡲࠫವ") and dict[ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"࠭ࡩ࡯࡫ࡷࠫಶ")]!=hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠧ࠱࠯࠳ࠫಷ"):
			ffvh9ctdCnj.append(dict[vODxLKW5Ql6r4Fbm8(u"ࠨࡶ࡬ࡸࡱ࡫ࠧಸ")])
			aGfDxmJtAKdZ.append(dict)
		elif QceVgxwDJbPM2jtkihUzq3nGAmp and dict[L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠩࡷࡽࡵ࡫࠲ࠨಹ")]==IpC4qHXRuyNFjzWv(u"ࠪࡅࡺࡪࡩࡰࠩ಺") and dict[tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠫ࡮ࡴࡩࡵࠩ಻")]!=EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠬ࠶࠭࠱಼ࠩ"):
			WF2HQkT78zVtGJoRsZfm3U.append(dict[UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"࠭ࡴࡪࡶ࡯ࡩࠬಽ")])
			aato3BHjVKd6cpwqQmy1rPNu.append(dict)
	for CwXogH5keEzLdJu3Z in aato3BHjVKd6cpwqQmy1rPNu:
		EblC8sqfYDW0A = CwXogH5keEzLdJu3Z[uuExaKGL7UONtevRd(u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨಾ")]
		for xAlJW8k9avBOgELbmeI in aGfDxmJtAKdZ:
			IU53MF9R1Ytz = xAlJW8k9avBOgELbmeI[YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩಿ")]
			ttKWoIH83b = int(IU53MF9R1Ytz)+int(EblC8sqfYDW0A)
			title = xAlJW8k9avBOgELbmeI[JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠩࡷ࡭ࡹࡲࡥࠨೀ")].replace(jXE2YHkswT8y(u"࡚ࠪ࡮ࡪࡥࡰ࠼ࠣࠤࠬು"),ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠫࡲࡶࡤࠡࠢࠪೂ"))
			title = title.replace(xAlJW8k9avBOgELbmeI[CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧೃ")]+Wc5GekRC0HQLz7,iiy37aKq0pCEIOwfcTh61xb4U)
			title = title.replace(IU53MF9R1Ytz+YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"࠭࡫ࡣࡲࡶࠫೄ"),str(ttKWoIH83b)+uuExaKGL7UONtevRd(u"ࠧ࡬ࡤࡳࡷࠬ೅"))
			title = title+uuExaKGL7UONtevRd(u"ࠨࠪࠪೆ")+CwXogH5keEzLdJu3Z[sVzojQerUqX(u"ࠩࡷ࡭ࡹࡲࡥࠨೇ")].split(HtK4o2sTPgA78U(u"ࠪࠬࠬೈ"),YYJQyRskpX8jv)[YYJQyRskpX8jv]
			tPbj6e8koZEhsAW1.append([xAlJW8k9avBOgELbmeI,CwXogH5keEzLdJu3Z,title,ttKWoIH83b])
	l03w7FeqLvMX1j2YEdgxpo = []
	for stream in tPbj6e8koZEhsAW1:
		xAlJW8k9avBOgELbmeI,CwXogH5keEzLdJu3Z,title,ttKWoIH83b = stream
		qqxvrgsFcEbA8fdOIileQG1 = title[:iiCWLaJREureAlOkv]
		if MgP8OjoaiWQEVG59(u"ࠫี้๊สࠩ೉") in title: qqxvrgsFcEbA8fdOIileQG1 += tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠬ࠱ࠧೊ")
		l03w7FeqLvMX1j2YEdgxpo.append([stream,qqxvrgsFcEbA8fdOIileQG1,int(ttKWoIH83b)])
	kVrsxBp6PEONY4M12boReSgcKJ = BF6QAiLUNHh7rKOugaw
	ZCqfwruncbv3GtaiX1QmDLUE8 = OoC5bEUlDd2shtFzNrvgpyqK(sQU2GnRoMwLK8CBdfzmNr4jXyO,l03w7FeqLvMX1j2YEdgxpo)
	if ZCqfwruncbv3GtaiX1QmDLUE8:
		cBTptUQo8RaDF9A703rGd,q1bvzWuxJeV7PEcfiCYFld,title,ttKWoIH83b = ZCqfwruncbv3GtaiX1QmDLUE8[ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"࠰๢")][ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"࠰๢")]
		k03kbvh7xa8ZmKHwpRrCYXD = cBTptUQo8RaDF9A703rGd[HtK4o2sTPgA78U(u"࠭ࡵࡳ࡮ࠪೋ")]
		if MgP8OjoaiWQEVG59(u"ࠧ࡮ࡲࡧࠫೌ") in title and k03kbvh7xa8ZmKHwpRrCYXD!=yXaup4BtEZr7xhP1wekq3U: kVrsxBp6PEONY4M12boReSgcKJ = rGPen6cSMHQkAywh8vqI9JXiD2
		qfaiL6clG8xXuFPnTJhD9 = title
	else:
		rPblaxQIZ4wR2dg = OoC5bEUlDd2shtFzNrvgpyqK(sQU2GnRoMwLK8CBdfzmNr4jXyO,l03w7FeqLvMX1j2YEdgxpo,sVzojQerUqX(u"࠲࠷࠳࠴๣"))
		rPblaxQIZ4wR2dg,GIDnvKOA2NxaBgWYTb7LdP,GYnj2MKeAZtzxQw = zip(*rPblaxQIZ4wR2dg)
		MUp403Qv7Pyc6NTIg,xMH8OT5fnjFgIakJC6s,ttuA5VNJz62ZaUiW3XLvdI = [],[],FGTfwsjNrB8DvKSZhLIQAb1JnO
		tPbj6e8koZEhsAW1 = sorted(tPbj6e8koZEhsAW1, reverse=rGPen6cSMHQkAywh8vqI9JXiD2, key=lambda key: float(key[iiCWLaJREureAlOkv]))
		eojfzVLctg6FpJYs,myoefkrj1nIXCiUODVAx52,qqflUJ0SuwyYH = iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U
		try: eojfzVLctg6FpJYs = rfBAJx30NnHwdekY6icT2MSZULl[PtkEvXAqif14G20QZsaSyT(u"ࠨࡸ࡬ࡨࡪࡵࡄࡦࡶࡤ࡭ࡱࡹ್ࠧ")][PtkEvXAqif14G20QZsaSyT(u"ࠩࡤࡹࡹ࡮࡯ࡳࠩ೎")]
		except:
			try: eojfzVLctg6FpJYs = qAawdug1ko6G9zp[TlGXWLYsV1z(u"ࠪࡺ࡮ࡪࡥࡰࡆࡨࡸࡦ࡯࡬ࡴࠩ೏")][hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠫࡦࡻࡴࡩࡱࡵࠫ೐")]
			except: pass
		try: myoefkrj1nIXCiUODVAx52 = rfBAJx30NnHwdekY6icT2MSZULl[MgP8OjoaiWQEVG59(u"ࠬࡼࡩࡥࡧࡲࡈࡪࡺࡡࡪ࡮ࡶࠫ೑")][ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"࠭ࡣࡩࡣࡱࡲࡪࡲࡉࡥࠩ೒")]
		except:
			try: myoefkrj1nIXCiUODVAx52 = qAawdug1ko6G9zp[TlGXWLYsV1z(u"ࠧࡷ࡫ࡧࡩࡴࡊࡥࡵࡣ࡬ࡰࡸ࠭೓")][uuExaKGL7UONtevRd(u"ࠨࡥ࡫ࡥࡳࡴࡥ࡭ࡋࡧࠫ೔")]
			except: pass
		if eojfzVLctg6FpJYs and myoefkrj1nIXCiUODVAx52:
			ttuA5VNJz62ZaUiW3XLvdI += YYJQyRskpX8jv
			title = PSwfZcdRYhpl5Igqz8xOEk67+tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠩࡒ࡛ࡓࡋࡒ࠻ࠢࠣࠫೕ")+eojfzVLctg6FpJYs+YoQW601K4fMJcsreDnGVE5wUZIy7
			fCXyTlcmF4WuetVork = gZ4LwbKaOm[HtK4o2sTPgA78U(u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫೖ")][FGTfwsjNrB8DvKSZhLIQAb1JnO]+xpT28sXu051(u"ࠫ࠴ࡩࡨࡢࡰࡱࡩࡱ࠵ࠧ೗")+myoefkrj1nIXCiUODVAx52
			MUp403Qv7Pyc6NTIg.append(title)
			xMH8OT5fnjFgIakJC6s.append(fCXyTlcmF4WuetVork)
			try: qqflUJ0SuwyYH = rfBAJx30NnHwdekY6icT2MSZULl[MgP8OjoaiWQEVG59(u"ࠬࡼࡩࡥࡧࡲࡈࡪࡺࡡࡪ࡮ࡶࠫ೘")][Y41NvKfOroMzGB8sEHy7wbXlc5(u"࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࠩ೙")][EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡶࠫ೚")][-YYJQyRskpX8jv][L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠨࡷࡵࡰࠬ೛")]
			except:
				try: qqflUJ0SuwyYH = qAawdug1ko6G9zp[Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠩࡹ࡭ࡩ࡫࡯ࡅࡧࡷࡥ࡮ࡲࡳࠨ೜")][UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱ࠭ೝ")][ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡳࠨೞ")][-YYJQyRskpX8jv][SaB5hx3PZwXRLtKgrTfQvId(u"ࠬࡻࡲ࡭ࠩ೟")]
				except: pass
		for xAlJW8k9avBOgELbmeI,CwXogH5keEzLdJu3Z,title,ttKWoIH83b in rPblaxQIZ4wR2dg:
			MUp403Qv7Pyc6NTIg.append(title) ; xMH8OT5fnjFgIakJC6s.append(TlGXWLYsV1z(u"࠭ࡨࡪࡩ࡫ࡩࡸࡺࠧೠ"))
		if RrTEaFCiI0Q4gMBuw3HP: MUp403Qv7Pyc6NTIg.append(LyNiIHPOwD3hCUYEFM7(u"ࠧึ๊ิอࠥ๎ี้ฬ้ࠣาีฯสࠩೡ")) ; xMH8OT5fnjFgIakJC6s.append(Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠨ࡯ࡸࡼࡪࡪࠧೢ"))
		if tPbj6e8koZEhsAW1: MUp403Qv7Pyc6NTIg.append(ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ุࠩ์ึฯ้ࠠื๋ฮࠥอไๆฬ๋ๅึ࠭ೣ")) ; xMH8OT5fnjFgIakJC6s.append(CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠪࡥࡱࡲࠧ೤"))
		if ffvh9ctdCnj: MUp403Qv7Pyc6NTIg.append(YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠫฬิสาࠢสฺ่๎ัส๋ࠢห้฻่หࠩ೥")) ; xMH8OT5fnjFgIakJC6s.append(JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠬࡳࡰࡥࠩ೦"))
		if eQ9FZswqJkm0gLxYt7NyTI: MUp403Qv7Pyc6NTIg.append(LyNiIHPOwD3hCUYEFM7(u"࠭ี้ำฬࠤอี่็ุࠢ์ฯ࠭೧")) ; xMH8OT5fnjFgIakJC6s.append(CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠧࡷ࡫ࡧࡩࡴ࠭೨"))
		if mweo95CsVi0N2UYSZxXkpdnLROl6: MUp403Qv7Pyc6NTIg.append(xpT28sXu051(u"ࠨื๋ฮࠥฮฯู้่ࠣํืษࠨ೩")) ; xMH8OT5fnjFgIakJC6s.append(hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠩࡤࡹࡩ࡯࡯ࠨ೪"))
		while rGPen6cSMHQkAywh8vqI9JXiD2:
			mmfrx2S5XqknFTDeRhj49LuYv1wW0 = ccv1mVPUsnr(zRiuBNrfpde4ZlUnoEjG37H, MUp403Qv7Pyc6NTIg)
			if mmfrx2S5XqknFTDeRhj49LuYv1wW0==-YYJQyRskpX8jv: return EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠪࡉ࡝ࡏࡔࡠࡃࡏࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ೫"),[],[]
			elif mmfrx2S5XqknFTDeRhj49LuYv1wW0==FGTfwsjNrB8DvKSZhLIQAb1JnO and eojfzVLctg6FpJYs:
				fCXyTlcmF4WuetVork = xMH8OT5fnjFgIakJC6s[mmfrx2S5XqknFTDeRhj49LuYv1wW0]
				a6zqTCpFUns = ytv0YaxDcRINurplWKg587Pwqz.argv[FGTfwsjNrB8DvKSZhLIQAb1JnO]+Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠫࡄࡺࡹࡱࡧࡀࡪࡴࡲࡤࡦࡴࠩࡱࡴࡪࡥ࠾࠳࠷࠵ࠫࡴࡡ࡮ࡧࡀࠫ೬")+YqdaDIig21wBTWJeUHbc(eojfzVLctg6FpJYs)+yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠬࠬࡵࡳ࡮ࡀࠫ೭")+fCXyTlcmF4WuetVork
				if qqflUJ0SuwyYH: a6zqTCpFUns = a6zqTCpFUns+GGx4qyKP1vUtRghsE2WfaHLMXZ(u"࠭ࠦࡪ࡯ࡤ࡫ࡪࡃࠧ೮")+YqdaDIig21wBTWJeUHbc(qqflUJ0SuwyYH)
				WwMgozBIC32n9d0tyfp.executebuiltin(YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠢࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱࡙ࡵࡪࡡࡵࡧࠫࠦ೯")+a6zqTCpFUns+YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠣࠫࠥ೰"))
				return ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠩࡈ࡜ࡎ࡚࡟ࡂࡎࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧೱ"),[],[]
			RzBbfLYvm4Fgja7GcwCHMnX0K = xMH8OT5fnjFgIakJC6s[mmfrx2S5XqknFTDeRhj49LuYv1wW0]
			qfaiL6clG8xXuFPnTJhD9 = MUp403Qv7Pyc6NTIg[mmfrx2S5XqknFTDeRhj49LuYv1wW0]
			if RzBbfLYvm4Fgja7GcwCHMnX0K==TlGXWLYsV1z(u"ࠪࡨࡦࡹࡨࠨೲ"):
				k03kbvh7xa8ZmKHwpRrCYXD = yXaup4BtEZr7xhP1wekq3U
				break
			elif RzBbfLYvm4Fgja7GcwCHMnX0K in [hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠫࡦࡻࡤࡪࡱࠪೳ"),tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠬࡼࡩࡥࡧࡲࠫ೴"),hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"࠭࡭ࡶࡺࡨࡨࠬ೵")]:
				if RzBbfLYvm4Fgja7GcwCHMnX0K==ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠧ࡮ࡷࡻࡩࡩ࠭೶"): A7Ap2wdlxM,Msp6LFZX1fCue3vAPhVKRjcgYa2D4t = RrTEaFCiI0Q4gMBuw3HP,iFZPlbN1CMgKsGIS4kBY9UrQuxXV6z
				elif RzBbfLYvm4Fgja7GcwCHMnX0K==GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠨࡸ࡬ࡨࡪࡵࠧ೷"): A7Ap2wdlxM,Msp6LFZX1fCue3vAPhVKRjcgYa2D4t = eQ9FZswqJkm0gLxYt7NyTI,CGyRnQH1N7tBp8ciPDdKFxAjvlV
				elif RzBbfLYvm4Fgja7GcwCHMnX0K==uuExaKGL7UONtevRd(u"ࠩࡤࡹࡩ࡯࡯ࠨ೸"): A7Ap2wdlxM,Msp6LFZX1fCue3vAPhVKRjcgYa2D4t = mweo95CsVi0N2UYSZxXkpdnLROl6,Mna6Gyte01wLp
				mmfrx2S5XqknFTDeRhj49LuYv1wW0 = ccv1mVPUsnr(ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠪหำะัࠡษ็้้็ࠠࠩࠩ೹")+str(len(A7Ap2wdlxM))+L90uqo28xEKSFUwYTcm51yRWZIkft(u"๋ࠫࠥไโࠫࠪ೺"), A7Ap2wdlxM)
				if mmfrx2S5XqknFTDeRhj49LuYv1wW0!=-YYJQyRskpX8jv:
					k03kbvh7xa8ZmKHwpRrCYXD = Msp6LFZX1fCue3vAPhVKRjcgYa2D4t[mmfrx2S5XqknFTDeRhj49LuYv1wW0][ZchUJdM93pTA7zG5(u"ࠬࡻࡲ࡭ࠩ೻")]
					qfaiL6clG8xXuFPnTJhD9 = A7Ap2wdlxM[mmfrx2S5XqknFTDeRhj49LuYv1wW0]
					break
			elif RzBbfLYvm4Fgja7GcwCHMnX0K==EMO8gy4LrsNTh0knZwpSeU75APW(u"࠭࡭ࡱࡦࠪ೼"):
				mmfrx2S5XqknFTDeRhj49LuYv1wW0 = ccv1mVPUsnr(PtkEvXAqif14G20QZsaSyT(u"ࠧศะอีࠥา่ะหࠣห้฻่าหࠣࠬࠬ೽")+str(len(ffvh9ctdCnj))+XrTw01KtLzbpoyMf(u"ࠨ่่ࠢๆ࠯ࠧ೾"), ffvh9ctdCnj)
				if mmfrx2S5XqknFTDeRhj49LuYv1wW0!=-YYJQyRskpX8jv:
					qfaiL6clG8xXuFPnTJhD9 = ffvh9ctdCnj[mmfrx2S5XqknFTDeRhj49LuYv1wW0]
					cBTptUQo8RaDF9A703rGd = aGfDxmJtAKdZ[mmfrx2S5XqknFTDeRhj49LuYv1wW0]
					mmfrx2S5XqknFTDeRhj49LuYv1wW0 = ccv1mVPUsnr(zmcGfOdvAjsELeJlP(u"ࠩสาฯืࠠอ๊าอࠥอไึ๊อࠤ࠭࠭೿")+str(len(WF2HQkT78zVtGJoRsZfm3U))+AbqCJZdWQP9j(u"ࠪࠤ๊๊แࠪࠩഀ"), WF2HQkT78zVtGJoRsZfm3U)
					if mmfrx2S5XqknFTDeRhj49LuYv1wW0!=-YYJQyRskpX8jv:
						qfaiL6clG8xXuFPnTJhD9 += tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠫࠥ࠱ࠠࠨഁ")+WF2HQkT78zVtGJoRsZfm3U[mmfrx2S5XqknFTDeRhj49LuYv1wW0]
						q1bvzWuxJeV7PEcfiCYFld = aato3BHjVKd6cpwqQmy1rPNu[mmfrx2S5XqknFTDeRhj49LuYv1wW0]
						kVrsxBp6PEONY4M12boReSgcKJ = rGPen6cSMHQkAywh8vqI9JXiD2
						break
			elif RzBbfLYvm4Fgja7GcwCHMnX0K==hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠬࡧ࡬࡭ࠩം"):
				XSQor0zKs7CtjWuGvxEABm4d9,PNUQ96FmOMDXx,KerBgEC7T5Lm,rvG9HjSKaTz71sZF5ytBDJPCl6gV = list(zip(*tPbj6e8koZEhsAW1))
				mmfrx2S5XqknFTDeRhj49LuYv1wW0 = ccv1mVPUsnr(zmcGfOdvAjsELeJlP(u"࠭วฯฬิࠤฬ๊ๅๅใࠣࠬࠬഃ")+str(len(KerBgEC7T5Lm))+yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠧࠡ็็ๅ࠮࠭ഄ"), KerBgEC7T5Lm)
				if mmfrx2S5XqknFTDeRhj49LuYv1wW0!=-YYJQyRskpX8jv:
					qfaiL6clG8xXuFPnTJhD9 = KerBgEC7T5Lm[mmfrx2S5XqknFTDeRhj49LuYv1wW0]
					cBTptUQo8RaDF9A703rGd = XSQor0zKs7CtjWuGvxEABm4d9[mmfrx2S5XqknFTDeRhj49LuYv1wW0]
					if XrTw01KtLzbpoyMf(u"ࠨ࡯ࡳࡨࠬഅ") in KerBgEC7T5Lm[mmfrx2S5XqknFTDeRhj49LuYv1wW0] and cBTptUQo8RaDF9A703rGd[XrTw01KtLzbpoyMf(u"ࠩࡸࡶࡱ࠭ആ")]!=yXaup4BtEZr7xhP1wekq3U:
						q1bvzWuxJeV7PEcfiCYFld = PNUQ96FmOMDXx[mmfrx2S5XqknFTDeRhj49LuYv1wW0]
						kVrsxBp6PEONY4M12boReSgcKJ = rGPen6cSMHQkAywh8vqI9JXiD2
					else: k03kbvh7xa8ZmKHwpRrCYXD = cBTptUQo8RaDF9A703rGd[XrTw01KtLzbpoyMf(u"ࠪࡹࡷࡲࠧഇ")]
					break
			elif RzBbfLYvm4Fgja7GcwCHMnX0K==ZchUJdM93pTA7zG5(u"ࠫ࡭࡯ࡧࡩࡧࡶࡸࠬഈ"):
				XSQor0zKs7CtjWuGvxEABm4d9,PNUQ96FmOMDXx,KerBgEC7T5Lm,rvG9HjSKaTz71sZF5ytBDJPCl6gV = list(zip(*rPblaxQIZ4wR2dg))
				cBTptUQo8RaDF9A703rGd = XSQor0zKs7CtjWuGvxEABm4d9[mmfrx2S5XqknFTDeRhj49LuYv1wW0-ttuA5VNJz62ZaUiW3XLvdI]
				if XrTw01KtLzbpoyMf(u"ࠬࡳࡰࡥࠩഉ") in KerBgEC7T5Lm[mmfrx2S5XqknFTDeRhj49LuYv1wW0-ttuA5VNJz62ZaUiW3XLvdI] and cBTptUQo8RaDF9A703rGd[uuExaKGL7UONtevRd(u"࠭ࡵࡳ࡮ࠪഊ")]!=yXaup4BtEZr7xhP1wekq3U:
					q1bvzWuxJeV7PEcfiCYFld = PNUQ96FmOMDXx[mmfrx2S5XqknFTDeRhj49LuYv1wW0-ttuA5VNJz62ZaUiW3XLvdI]
					kVrsxBp6PEONY4M12boReSgcKJ = rGPen6cSMHQkAywh8vqI9JXiD2
				else: k03kbvh7xa8ZmKHwpRrCYXD = cBTptUQo8RaDF9A703rGd[zmcGfOdvAjsELeJlP(u"ࠧࡶࡴ࡯ࠫഋ")]
				qfaiL6clG8xXuFPnTJhD9 = KerBgEC7T5Lm[mmfrx2S5XqknFTDeRhj49LuYv1wW0-ttuA5VNJz62ZaUiW3XLvdI]
				break
	if kVrsxBp6PEONY4M12boReSgcKJ:
		K5BXY9oCstGIJ = int(cBTptUQo8RaDF9A703rGd[IpC4qHXRuyNFjzWv(u"ࠨࡦࡸࡶࡦࡺࡩࡰࡰࠪഌ")])
		c2cxsIH1mzpfFa6XhwjUt8CGY5Z = int(q1bvzWuxJeV7PEcfiCYFld[y6y5HtgXO4TkUbwVZ(u"ࠩࡧࡹࡷࡧࡴࡪࡱࡱࠫ഍")])
		Zt6GY7K2oFeAd5kTy3nJvDBpQr = str(max(K5BXY9oCstGIJ,c2cxsIH1mzpfFa6XhwjUt8CGY5Z))
		qbnIXjyd0KraCiE3N = cBTptUQo8RaDF9A703rGd[TlGXWLYsV1z(u"ࠪࡹࡷࡲࠧഎ")].replace(XrTw01KtLzbpoyMf(u"ࠫࠫ࠭ഏ"),HtK4o2sTPgA78U(u"ࠬࠬࡡ࡮ࡲ࠾ࠫഐ"))
		aaNx1vuAHs4FlOCp = q1bvzWuxJeV7PEcfiCYFld[LyNiIHPOwD3hCUYEFM7(u"࠭ࡵࡳ࡮ࠪ഑")].replace(AbqCJZdWQP9j(u"ࠧࠧࠩഒ"),AbqCJZdWQP9j(u"ࠨࠨࡤࡱࡵࡁࠧഓ"))
		mpd = MgP8OjoaiWQEVG59(u"ࠩ࠿ࡑࡕࡊࠠ࡮ࡧࡧ࡭ࡦࡖࡲࡦࡵࡨࡲࡹࡧࡴࡪࡱࡱࡈࡺࡸࡡࡵ࡫ࡲࡲࡂࠨࡐࡕࠩഔ")+Zt6GY7K2oFeAd5kTy3nJvDBpQr+PtkEvXAqif14G20QZsaSyT(u"ࠪࡗࠧࡄ࡜࡯ࠩക")
		mpd += ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠫࡁࡖࡥࡳ࡫ࡲࡨࡃࡢ࡮ࠨഖ")
		mpd += L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠬࡂࡁࡥࡣࡳࡸࡦࡺࡩࡰࡰࡖࡩࡹࠦ࡭ࡪ࡯ࡨࡘࡾࡶࡥ࠾ࠤࡹ࡭ࡩ࡫࡯࠰ࠩഗ")+cBTptUQo8RaDF9A703rGd[uuExaKGL7UONtevRd(u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨഘ")]+zmcGfOdvAjsELeJlP(u"ࠧࠣࠢࡦࡳࡩ࡫ࡣࡴ࠿ࠥࠫങ")+cBTptUQo8RaDF9A703rGd[AbqCJZdWQP9j(u"ࠨࡥࡲࡨࡪࡩࡳࠨച")]+FRYcH4KL7e9gv5pEB(u"ࠩࠥࡂࡡࡴࠧഛ")
		mpd += GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠪࡀࡗ࡫ࡰࡳࡧࡶࡩࡳࡺࡡࡵ࡫ࡲࡲࡃࡢ࡮ࠨജ")
		mpd += FRYcH4KL7e9gv5pEB(u"ࠫࡁࡈࡡࡴࡧࡘࡖࡑࡄࠧഝ")+qbnIXjyd0KraCiE3N+SaB5hx3PZwXRLtKgrTfQvId(u"ࠬࡂ࠯ࡃࡣࡶࡩ࡚ࡘࡌ࠿࡞ࡱࠫഞ")
		mpd += FRYcH4KL7e9gv5pEB(u"࠭࠼ࡔࡧࡪࡱࡪࡴࡴࡃࡣࡶࡩࠥ࡯࡮ࡥࡧࡻࡖࡦࡴࡧࡦ࠿ࠥࠫട")+cBTptUQo8RaDF9A703rGd[zmcGfOdvAjsELeJlP(u"ࠧࡪࡰࡧࡩࡽ࠭ഠ")]+HtK4o2sTPgA78U(u"ࠨࠤࡁࡠࡳ࠭ഡ")
		mpd += EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠩ࠿ࡍࡳ࡯ࡴࡪࡣ࡯࡭ࡿࡧࡴࡪࡱࡱࠤࡷࡧ࡮ࡨࡧࡀࠦࠬഢ")+cBTptUQo8RaDF9A703rGd[ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠪ࡭ࡳ࡯ࡴࠨണ")]+MgP8OjoaiWQEVG59(u"ࠫࠧࠦ࠯࠿࡞ࡱࠫത")
		mpd += FRYcH4KL7e9gv5pEB(u"ࠬࡂ࠯ࡔࡧࡪࡱࡪࡴࡴࡃࡣࡶࡩࡃࡢ࡮ࠨഥ")
		mpd += TlGXWLYsV1z(u"࠭࠼࠰ࡔࡨࡴࡷ࡫ࡳࡦࡰࡷࡥࡹ࡯࡯࡯ࡀ࡟ࡲࠬദ")
		mpd += UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠧ࠽࠱ࡄࡨࡦࡶࡴࡢࡶ࡬ࡳࡳ࡙ࡥࡵࡀ࡟ࡲࠬധ")
		mpd += ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠨ࠾ࡄࡨࡦࡶࡴࡢࡶ࡬ࡳࡳ࡙ࡥࡵࠢࡰ࡭ࡲ࡫ࡔࡺࡲࡨࡁࠧࡧࡵࡥ࡫ࡲ࠳ࠬന")+q1bvzWuxJeV7PEcfiCYFld[YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠫഩ")]+xpT28sXu051(u"ࠪࠦࠥࡩ࡯ࡥࡧࡦࡷࡂࠨࠧപ")+q1bvzWuxJeV7PEcfiCYFld[XrTw01KtLzbpoyMf(u"ࠫࡨࡵࡤࡦࡥࡶࠫഫ")]+ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠬࠨ࠾࡝ࡰࠪബ")
		mpd += hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"࠭࠼ࡓࡧࡳࡶࡪࡹࡥ࡯ࡶࡤࡸ࡮ࡵ࡮࠿࡞ࡱࠫഭ")
		mpd += y6y5HtgXO4TkUbwVZ(u"ࠧ࠽ࡄࡤࡷࡪ࡛ࡒࡍࡀࠪമ")+aaNx1vuAHs4FlOCp+tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠨ࠾࠲ࡆࡦࡹࡥࡖࡔࡏࡂࡡࡴࠧയ")
		mpd += L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠩ࠿ࡗࡪ࡭࡭ࡦࡰࡷࡆࡦࡹࡥࠡ࡫ࡱࡨࡪࡾࡒࡢࡰࡪࡩࡂࠨࠧര")+q1bvzWuxJeV7PEcfiCYFld[SaB5hx3PZwXRLtKgrTfQvId(u"ࠪ࡭ࡳࡪࡥࡹࠩറ")]+ZchUJdM93pTA7zG5(u"ࠫࠧࡄ࡜࡯ࠩല")
		mpd += SaB5hx3PZwXRLtKgrTfQvId(u"ࠬࡂࡉ࡯࡫ࡷ࡭ࡦࡲࡩࡻࡣࡷ࡭ࡴࡴࠠࡳࡣࡱ࡫ࡪࡃࠢࠨള")+q1bvzWuxJeV7PEcfiCYFld[AbqCJZdWQP9j(u"࠭ࡩ࡯࡫ࡷࠫഴ")]+sVzojQerUqX(u"ࠧࠣࠢ࠲ࡂࡡࡴࠧവ")
		mpd += UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠨ࠾࠲ࡗࡪ࡭࡭ࡦࡰࡷࡆࡦࡹࡥ࠿࡞ࡱࠫശ")
		mpd += hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠩ࠿࠳ࡗ࡫ࡰࡳࡧࡶࡩࡳࡺࡡࡵ࡫ࡲࡲࡃࡢ࡮ࠨഷ")
		mpd += y6y5HtgXO4TkUbwVZ(u"ࠪࡀ࠴ࡇࡤࡢࡲࡷࡥࡹ࡯࡯࡯ࡕࡨࡸࡃࡢ࡮ࠨസ")
		mpd += Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠫࡁ࠵ࡐࡦࡴ࡬ࡳࡩࡄ࡜࡯ࠩഹ")
		mpd += hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠬࡂ࠯ࡎࡒࡇࡂࡡࡴࠧഺ")
		if J1MoiYc7ZwzKS:
			import http.server as MgipekNnVmDsIX0x16u5RL
			import http.client as Hc2MJpX6ET3oCPlSfagjtIk
		else:
			import BaseHTTPServer as MgipekNnVmDsIX0x16u5RL
			import httplib as Hc2MJpX6ET3oCPlSfagjtIk
		class K0tax8dOkA5CNTG1D(MgipekNnVmDsIX0x16u5RL.HTTPServer):
			def __init__(duiHLz8j2YhP3VUAapeB1GnmFS,ip=LyNiIHPOwD3hCUYEFM7(u"࠭࡬ࡰࡥࡤࡰ࡭ࡵࡳࡵ഻ࠩ"),port=SaB5hx3PZwXRLtKgrTfQvId(u"࠷࠸࠴࠺࠻๤"),mpd=IpC4qHXRuyNFjzWv(u"ࠧ࠽ࡀ഼ࠪ")):
				duiHLz8j2YhP3VUAapeB1GnmFS.ip = ip
				duiHLz8j2YhP3VUAapeB1GnmFS.port = port
				duiHLz8j2YhP3VUAapeB1GnmFS.mpd = mpd
				MgipekNnVmDsIX0x16u5RL.HTTPServer.__init__(duiHLz8j2YhP3VUAapeB1GnmFS,(duiHLz8j2YhP3VUAapeB1GnmFS.ip,duiHLz8j2YhP3VUAapeB1GnmFS.port),ooeI4XOa5fSJFE9PWw7jd3)
				duiHLz8j2YhP3VUAapeB1GnmFS.mpdurl = JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࠩഽ")+ip+yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠩ࠽ࠫാ")+str(port)+PtkEvXAqif14G20QZsaSyT(u"ࠪ࠳ࡾࡵࡵࡵࡷࡥࡩ࠳ࡳࡰࡥࠩി")
			def start(duiHLz8j2YhP3VUAapeB1GnmFS):
				duiHLz8j2YhP3VUAapeB1GnmFS.threads = tIvpmRVh8Z0lHS9sk4ECg6Ni5PeDWJ(BF6QAiLUNHh7rKOugaw)
				duiHLz8j2YhP3VUAapeB1GnmFS.threads.ztvP0T59IiMp61VJmf7(YYJQyRskpX8jv,duiHLz8j2YhP3VUAapeB1GnmFS.e9KdUL0yQn28qmSxDgP5wf)
			def e9KdUL0yQn28qmSxDgP5wf(duiHLz8j2YhP3VUAapeB1GnmFS):
				duiHLz8j2YhP3VUAapeB1GnmFS.keeprunning = rGPen6cSMHQkAywh8vqI9JXiD2
				while duiHLz8j2YhP3VUAapeB1GnmFS.keeprunning:
					duiHLz8j2YhP3VUAapeB1GnmFS.handle_request()
			def stop(duiHLz8j2YhP3VUAapeB1GnmFS):
				duiHLz8j2YhP3VUAapeB1GnmFS.keeprunning = BF6QAiLUNHh7rKOugaw
				duiHLz8j2YhP3VUAapeB1GnmFS.iG9MjDPA261S()
			def O245mNlyuhYxBWpzQ7f(duiHLz8j2YhP3VUAapeB1GnmFS):
				duiHLz8j2YhP3VUAapeB1GnmFS.stop()
				duiHLz8j2YhP3VUAapeB1GnmFS.lwugO16XR3UKeqpdCsfzijm.close()
				duiHLz8j2YhP3VUAapeB1GnmFS.server_close()
			def xxSs9TkVM0OJ3Umbn(duiHLz8j2YhP3VUAapeB1GnmFS,mpd):
				duiHLz8j2YhP3VUAapeB1GnmFS.mpd = mpd
			def iG9MjDPA261S(duiHLz8j2YhP3VUAapeB1GnmFS):
				FZ0zy7Cgeo1UjkR = Hc2MJpX6ET3oCPlSfagjtIk.HTTPConnection(duiHLz8j2YhP3VUAapeB1GnmFS.ip+ZchUJdM93pTA7zG5(u"ࠫ࠿࠭ീ")+str(duiHLz8j2YhP3VUAapeB1GnmFS.port))
				FZ0zy7Cgeo1UjkR.request(CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠧࡎࡅࡂࡆࠥു"), vODxLKW5Ql6r4Fbm8(u"ࠨ࠯ࠣൂ"))
		class ooeI4XOa5fSJFE9PWw7jd3(MgipekNnVmDsIX0x16u5RL.BaseHTTPRequestHandler):
			def qPaGh8JOitMEXxlm(duiHLz8j2YhP3VUAapeB1GnmFS):
				duiHLz8j2YhP3VUAapeB1GnmFS.send_response(Y41NvKfOroMzGB8sEHy7wbXlc5(u"࠵࠴࠵๥"))
				duiHLz8j2YhP3VUAapeB1GnmFS.send_header(hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡶࡼࡴࡪ࠭ൃ"),JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠨࡶࡨࡼࡹ࠵ࡰ࡭ࡣ࡬ࡲࠬൄ"))
				duiHLz8j2YhP3VUAapeB1GnmFS.end_headers()
				duiHLz8j2YhP3VUAapeB1GnmFS.wfile.write(duiHLz8j2YhP3VUAapeB1GnmFS.Zw4M5DUStdE6xp7GI.mpd.encode(df6QpwGxuJVZr))
				X2cQ5NCPvkMieBW7oASspFjE.sleep(YYJQyRskpX8jv)
				if duiHLz8j2YhP3VUAapeB1GnmFS.path==tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠩ࠲ࡽࡴࡻࡴࡶࡤࡨ࠲ࡲࡶࡤࠨ൅"): duiHLz8j2YhP3VUAapeB1GnmFS.Zw4M5DUStdE6xp7GI.O245mNlyuhYxBWpzQ7f()
				if duiHLz8j2YhP3VUAapeB1GnmFS.path==L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠪ࠳ࡸ࡮ࡵࡵࡦࡲࡻࡳ࠭െ"): duiHLz8j2YhP3VUAapeB1GnmFS.Zw4M5DUStdE6xp7GI.O245mNlyuhYxBWpzQ7f()
			def dnijMlAL89CUkeEgGDxOz(duiHLz8j2YhP3VUAapeB1GnmFS):
				duiHLz8j2YhP3VUAapeB1GnmFS.send_response(LyNiIHPOwD3hCUYEFM7(u"࠶࠵࠶๦"))
				duiHLz8j2YhP3VUAapeB1GnmFS.end_headers()
		nJbTDhsOq0fZNBwVR7etWG35 = K0tax8dOkA5CNTG1D(ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠫ࠶࠸࠷࠯࠲࠱࠴࠳࠷ࠧേ"),HtK4o2sTPgA78U(u"࠺࠻࠰࠶࠷๧"),mpd)
		k03kbvh7xa8ZmKHwpRrCYXD = nJbTDhsOq0fZNBwVR7etWG35.mpdurl
		nJbTDhsOq0fZNBwVR7etWG35.start()
	else: nJbTDhsOq0fZNBwVR7etWG35 = iiy37aKq0pCEIOwfcTh61xb4U
	if J1MoiYc7ZwzKS: csIXNmgAzuByWHLRP812D9JehY5Uqn,O0JzKo5BcmlG2 = iiy37aKq0pCEIOwfcTh61xb4U,ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠬࡢࡴࠨൈ")
	else: csIXNmgAzuByWHLRP812D9JehY5Uqn,O0JzKo5BcmlG2 = y6y5HtgXO4TkUbwVZ(u"࠭࡜ࡵࠩ൉"),iiy37aKq0pCEIOwfcTh61xb4U
	pSQdtRAmKvC = csIXNmgAzuByWHLRP812D9JehY5Uqn+sVzojQerUqX(u"ࠧࡂࡷࡧ࡭ࡴࡀࠠ࡜ࠢࠪൊ")+q1bvzWuxJeV7PEcfiCYFld[HtK4o2sTPgA78U(u"ࠨࡷࡵࡰࠬോ")]+JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠩࠣࡡࡡࡴ࡜ࡵ࡞ࡷࠫൌ")+O0JzKo5BcmlG2+SaB5hx3PZwXRLtKgrTfQvId(u"࡚ࠪ࡮ࡪࡥࡰ࠼ࠣ࡟്ࠥ࠭")+cBTptUQo8RaDF9A703rGd[tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠫࡺࡸ࡬ࠨൎ")]+LyNiIHPOwD3hCUYEFM7(u"ࠬࠦ࡝ࠨ൏") if kVrsxBp6PEONY4M12boReSgcKJ else csIXNmgAzuByWHLRP812D9JehY5Uqn+XrTw01KtLzbpoyMf(u"࠭ࡁࠬࡘ࠽ࠤࡠࠦࠧ൐")+k03kbvh7xa8ZmKHwpRrCYXD+Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠧࠡ࡟ࠪ൑")
	WKquk5EaNr4RzVf(P3sqIW4T8rYpjNxOXhcBk2GD,IIZ4e82HBP0oTmtOgaWY7hsMz(sQU2GnRoMwLK8CBdfzmNr4jXyO)+sVzojQerUqX(u"ࠨ࡞ࡷࡔࡱࡧࡹࡪࡰࡪࠤࡘࡺࡲࡦࡣࡰ࠾ࠥࡡࠠࠨ൒")+qfaiL6clG8xXuFPnTJhD9+yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠩࠣࡡࠥࠦࠠࠨ൓")+pSQdtRAmKvC+hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠪࠫൔ"))
	if not k03kbvh7xa8ZmKHwpRrCYXD: return hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠫࡊࡸࡲࡰࡴࠣࠤࠥࠦ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣ࡝ࡔ࡛ࡔࡖࡄࡈࠤࡋࡧࡩ࡭ࡧࡧࠫൕ"),[],[]
	return iiy37aKq0pCEIOwfcTh61xb4U,[qfaiL6clG8xXuFPnTJhD9],[[k03kbvh7xa8ZmKHwpRrCYXD,mJXa86O3VqnhoK2ID7CL,nJbTDhsOq0fZNBwVR7etWG35]]
def wMmEKTqbuceaAgzjkZGs1l0OYd5PyR(url):
	headers = { Y41NvKfOroMzGB8sEHy7wbXlc5(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩൖ") : iiy37aKq0pCEIOwfcTh61xb4U }
	Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(r3rnfZ7cdxzNFebIRaLSG6B,url,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,Y41NvKfOroMzGB8sEHy7wbXlc5(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡙ࡍࡉࡈࡏࡃ࠯࠴ࡷࡹ࠭ൗ"))
	items = dEyT9xhGjolYzLCH7460w3.findall(tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠧࡧ࡫࡯ࡩ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠮ࠬ࡭ࡣࡥࡩࡱࡀࠢࠩ࠰࠭ࡃ࠮ࠨࡼࠪ࡞ࢀࠫ൘"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	items = set(items)
	items = sorted(items, reverse=rGPen6cSMHQkAywh8vqI9JXiD2, key=lambda key: key[nI2JK1RfsGWNY3OarEeMQZ])
	Dz1CNgS8XGrx6YWuORlUefQB,A7Ap2wdlxM,x8x42QwarFnvlhNmDXpLiUWtPyRqgj,duef0gb3Mi1AV5WpN8 = [],[],[],[]
	if not items: return hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦ࡚ࠣࡎࡊࡂࡐࡄࠪ൙"),[],[]
	for fCXyTlcmF4WuetVork,qBIUYtOjTAx0,e7wFcO9GDXRq in items:
		fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork.replace(Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠩ࡫ࡸࡹࡶࡳ࠻ࠩ൚"),hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠪ࡬ࡹࡺࡰ࠻ࠩ൛"))
		if YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪ൜") in fCXyTlcmF4WuetVork:
			Dz1CNgS8XGrx6YWuORlUefQB,x8x42QwarFnvlhNmDXpLiUWtPyRqgj = VKTp8gacXPG9Zr4H3NQCM0O(sQU2GnRoMwLK8CBdfzmNr4jXyO,fCXyTlcmF4WuetVork)
			duef0gb3Mi1AV5WpN8 = duef0gb3Mi1AV5WpN8 + x8x42QwarFnvlhNmDXpLiUWtPyRqgj
			if Dz1CNgS8XGrx6YWuORlUefQB[FGTfwsjNrB8DvKSZhLIQAb1JnO]==uuExaKGL7UONtevRd(u"ࠬ࠳࠱ࠨ൝"): A7Ap2wdlxM.append(GGx4qyKP1vUtRghsE2WfaHLMXZ(u"࠭ำ๋ำไีࠥิวึࠩ൞")+yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠧࠡࠢࠣࡱ࠸ࡻ࠸ࠨൟ"))
			else:
				for title in Dz1CNgS8XGrx6YWuORlUefQB:
					A7Ap2wdlxM.append(GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠨีํีๆืࠠฯษุࠫൠ")+jHLaUg49SXC6JyTM+title)
		else:
			title = ZchUJdM93pTA7zG5(u"ࠩึ๎ึ็ัࠡะสูࠬൡ")+xpT28sXu051(u"ࠪࠤࠥࠦ࡭ࡱ࠶ࠣࠤࠥ࠭ൢ")+e7wFcO9GDXRq
			duef0gb3Mi1AV5WpN8.append(fCXyTlcmF4WuetVork)
			A7Ap2wdlxM.append(title)
	return iiy37aKq0pCEIOwfcTh61xb4U,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8
def XRsU6ModzJhDiF4BpmNafyeVrEH9(url,Vxz6OndPIX4g2kaRp7):
	WK130YrED8vNhiHntepuXR,ff2PjlcCF5ZWyIUbVguMz,mNDoK3O1lVp7XuTZ,adfKwimHOzu7n469yXt,P3tys0cXWbiIUKk7HQ6n89V = [],[],[],[],[]
	if Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠫࡸࡺࡲࠨൣ") not in str(type(Vxz6OndPIX4g2kaRp7)): Vxz6OndPIX4g2kaRp7 = Vxz6OndPIX4g2kaRp7.decode(df6QpwGxuJVZr,ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠬ࡯ࡧ࡯ࡱࡵࡩࠬ൤"))
	fCXyTlcmF4WuetVork = dEyT9xhGjolYzLCH7460w3.findall(CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"࠭࠼ࡷ࡫ࡧࡩࡴࠦࡰࡳࡧ࡯ࡳࡦࡪ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ൥"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if fCXyTlcmF4WuetVork and not dVeG46wAnrtlpkbNPsvJ9(fCXyTlcmF4WuetVork[FGTfwsjNrB8DvKSZhLIQAb1JnO]): fCXyTlcmF4WuetVork = []
	if not fCXyTlcmF4WuetVork: fCXyTlcmF4WuetVork = dEyT9xhGjolYzLCH7460w3.findall(PtkEvXAqif14G20QZsaSyT(u"ࠧ࠽ࡵࡲࡹࡷࡩࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭൦"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if fCXyTlcmF4WuetVork and not dVeG46wAnrtlpkbNPsvJ9(fCXyTlcmF4WuetVork[FGTfwsjNrB8DvKSZhLIQAb1JnO]): fCXyTlcmF4WuetVork = []
	if not fCXyTlcmF4WuetVork: fCXyTlcmF4WuetVork = dEyT9xhGjolYzLCH7460w3.findall(uuExaKGL7UONtevRd(u"ࠨࡦ࡬ࡶࡪࡩࡴࡠ࡮࡬ࡲࡰ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ൧"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if fCXyTlcmF4WuetVork and not dVeG46wAnrtlpkbNPsvJ9(fCXyTlcmF4WuetVork[FGTfwsjNrB8DvKSZhLIQAb1JnO]): fCXyTlcmF4WuetVork = []
	if fCXyTlcmF4WuetVork:
		fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork[FGTfwsjNrB8DvKSZhLIQAb1JnO]
		title = fCXyTlcmF4WuetVork.rsplit(yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠩ࠱ࠫ൨"),tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"࠷๨"))[YYJQyRskpX8jv]
		WK130YrED8vNhiHntepuXR.append(title)
		ff2PjlcCF5ZWyIUbVguMz.append(fCXyTlcmF4WuetVork)
	else:
		ddfSDGyqEc = dEyT9xhGjolYzLCH7460w3.findall(UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠪࡷࡴࡻࡲࡤࡧࡶ࠾ࠥ࠰ࠨ࡝࡝࠱࠮ࡄࡢ࡝ࠪࠩ൩"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if not ddfSDGyqEc: ddfSDGyqEc = dEyT9xhGjolYzLCH7460w3.findall(jXE2YHkswT8y(u"ࠫࡻࡧࡲࠡࡵࡲࡹࡷࡩࡥࡴࠢࡀࠤ࠭ࡢࡻ࠯ࠬࡂࡠࢂ࠯ࠧ൪"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if not ddfSDGyqEc: ddfSDGyqEc = dEyT9xhGjolYzLCH7460w3.findall(Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠬࡼࡡࡳࠢ࡭ࡻࠥࡃࠠࠩ࡞ࡾ࠲࠯ࡅ࡜ࡾࠫࠪ൫"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if not ddfSDGyqEc: ddfSDGyqEc = dEyT9xhGjolYzLCH7460w3.findall(yJeq1BjfiO4NFuwIEzxVLK6b9s(u"࠭ࡶࡢࡴࠣࡴࡱࡧࡹࡦࡴࠣࡁࠥ࠴ࠪࡀ࡞ࠫࠬࡡࢁ࠮ࠫࡁ࡟ࢁ࠮ࡢࠩࠨ൬"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if ddfSDGyqEc:
			ddfSDGyqEc = ddfSDGyqEc[FGTfwsjNrB8DvKSZhLIQAb1JnO]
			ddfSDGyqEc = dEyT9xhGjolYzLCH7460w3.sub(JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࡲࠨࠪ࡞ࡠࢀࡢࠬ࡞࡝࡟ࡸࡡࡹ࡜࡯࡞ࡵࡡ࠯࠯ࠨ࡝ࡹ࠮࡟ࡡࡺ࡜ࡴ࡟࠭࠭࠿࠭൭"),IpC4qHXRuyNFjzWv(u"ࡳࠩ࡟࠵ࠧࡢ࠲ࠣ࠼ࠪ൮"),ddfSDGyqEc)
			ddfSDGyqEc = DeIL3qoa2UBtYPb(FRYcH4KL7e9gv5pEB(u"ࠩࡧ࡭ࡨࡺࠧ൯"),ddfSDGyqEc)
			if isinstance(ddfSDGyqEc,dict): ddfSDGyqEc = [ddfSDGyqEc]
			for PPH1sQtTkDBbnlYpZfo5 in ddfSDGyqEc:
				Ru7borMB4VyLeJUaItgFW2vX6mZjS,fCXyTlcmF4WuetVork = iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U
				if isinstance(PPH1sQtTkDBbnlYpZfo5,dict):
					keys = list(PPH1sQtTkDBbnlYpZfo5.keys())
					if   CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠪࡸࡾࡶࡥࠨ൰") in keys: Ru7borMB4VyLeJUaItgFW2vX6mZjS = str(PPH1sQtTkDBbnlYpZfo5[XrTw01KtLzbpoyMf(u"ࠫࡹࡿࡰࡦࠩ൱")])
					if   hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠬ࡬ࡩ࡭ࡧࠪ൲") in keys: fCXyTlcmF4WuetVork = PPH1sQtTkDBbnlYpZfo5[ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"࠭ࡦࡪ࡮ࡨࠫ൳")]
					elif IpC4qHXRuyNFjzWv(u"ࠧࡩ࡮ࡶࠫ൴") in keys: fCXyTlcmF4WuetVork = PPH1sQtTkDBbnlYpZfo5[ZchUJdM93pTA7zG5(u"ࠨࡪ࡯ࡷࠬ൵")]
					elif CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠩࡶࡶࡨ࠭൶") in keys: fCXyTlcmF4WuetVork = PPH1sQtTkDBbnlYpZfo5[SaB5hx3PZwXRLtKgrTfQvId(u"ࠪࡷࡷࡩࠧ൷")]
					if   FRYcH4KL7e9gv5pEB(u"ࠫࡱࡧࡢࡦ࡮ࠪ൸") in keys: title = str(PPH1sQtTkDBbnlYpZfo5[AbqCJZdWQP9j(u"ࠬࡲࡡࡣࡧ࡯ࠫ൹")])
					elif y6y5HtgXO4TkUbwVZ(u"࠭ࡶࡪࡦࡨࡳࡤ࡮ࡥࡪࡩ࡫ࡸࠬൺ") in keys: title = str(PPH1sQtTkDBbnlYpZfo5[zmcGfOdvAjsELeJlP(u"ࠧࡷ࡫ࡧࡩࡴࡥࡨࡦ࡫ࡪ࡬ࡹ࠭ൻ")])
					elif SaB5hx3PZwXRLtKgrTfQvId(u"ࠨ࠰ࠪർ") in fCXyTlcmF4WuetVork: title = fCXyTlcmF4WuetVork.rsplit(uuExaKGL7UONtevRd(u"ࠩ࠱ࠫൽ"),uuExaKGL7UONtevRd(u"࠱๩"))[YYJQyRskpX8jv]
					else: title = fCXyTlcmF4WuetVork
				elif isinstance(PPH1sQtTkDBbnlYpZfo5,str):
					fCXyTlcmF4WuetVork = PPH1sQtTkDBbnlYpZfo5
					title = fCXyTlcmF4WuetVork.rsplit(CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠪ࠲ࠬൾ"),vODxLKW5Ql6r4Fbm8(u"࠲๪"))[YYJQyRskpX8jv]
				if YYJQyRskpX8jv:
					WK130YrED8vNhiHntepuXR.append(title+Wc5GekRC0HQLz7+Ru7borMB4VyLeJUaItgFW2vX6mZjS)
					ff2PjlcCF5ZWyIUbVguMz.append(fCXyTlcmF4WuetVork)
	for fCXyTlcmF4WuetVork,title in zip(ff2PjlcCF5ZWyIUbVguMz,WK130YrED8vNhiHntepuXR):
		fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork.replace(GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠫࡡࡢ࠯ࠨൿ"),TlGXWLYsV1z(u"ࠬ࠵ࠧ඀"))
		Zw4M5DUStdE6xp7GI = F82MvyX4ThI6sbnA3efDoVS(url,MgP8OjoaiWQEVG59(u"࠭ࡵࡳ࡮ࠪඁ"))
		QlAC9VBYGRckULquednZ0XvOxF4f5M = FgJLkYac7lQxEbs()
		if TlGXWLYsV1z(u"ࠧࡩࡶࡷࡴࠬං") not in fCXyTlcmF4WuetVork: fCXyTlcmF4WuetVork = Zw4M5DUStdE6xp7GI+fCXyTlcmF4WuetVork
		if YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧඃ") in fCXyTlcmF4WuetVork:
			headers = {TlGXWLYsV1z(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭඄"):QlAC9VBYGRckULquednZ0XvOxF4f5M,YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫඅ"):Zw4M5DUStdE6xp7GI}
			RRu9kGQnfCNeFq7orbBgtY,H9OUb5LQM2io = VKTp8gacXPG9Zr4H3NQCM0O(sQU2GnRoMwLK8CBdfzmNr4jXyO,fCXyTlcmF4WuetVork,headers)
			adfKwimHOzu7n469yXt += H9OUb5LQM2io
			mNDoK3O1lVp7XuTZ += RRu9kGQnfCNeFq7orbBgtY
		else:
			fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork+hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠫࢁ࡛ࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ࠿ࠪආ")+QlAC9VBYGRckULquednZ0XvOxF4f5M+JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠬࠬࡒࡦࡨࡨࡶࡪࡸ࠽ࠨඇ")+Zw4M5DUStdE6xp7GI
			adfKwimHOzu7n469yXt.append(fCXyTlcmF4WuetVork)
			mNDoK3O1lVp7XuTZ.append(title)
	phm0nfzAUCXHBjO7lIDSxT3eZJdc,WK130YrED8vNhiHntepuXR,ff2PjlcCF5ZWyIUbVguMz = iiy37aKq0pCEIOwfcTh61xb4U,[],[]
	if adfKwimHOzu7n469yXt: phm0nfzAUCXHBjO7lIDSxT3eZJdc,WK130YrED8vNhiHntepuXR,ff2PjlcCF5ZWyIUbVguMz = iiy37aKq0pCEIOwfcTh61xb4U,mNDoK3O1lVp7XuTZ,adfKwimHOzu7n469yXt
	else:
		if FRYcH4KL7e9gv5pEB(u"࠭࠼ࠨඈ") not in Vxz6OndPIX4g2kaRp7 and len(Vxz6OndPIX4g2kaRp7)<hhQwbeiNLoqFjX90fB7aG8VAs(u"࠳࠳࠴๫") and Vxz6OndPIX4g2kaRp7: phm0nfzAUCXHBjO7lIDSxT3eZJdc = Vxz6OndPIX4g2kaRp7
		else:
			msg = dEyT9xhGjolYzLCH7460w3.findall(FRYcH4KL7e9gv5pEB(u"ࠧ࠽ࡦ࡬ࡺࠥࡹࡴࡺ࡮ࡨࡁࠧ࠴ࠪࡀࠤࡁࠬࡋ࡯࡬ࡦ࠰࠭ࡃ࠮ࡂࠧඉ"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
			if not msg: msg = dEyT9xhGjolYzLCH7460w3.findall(ZchUJdM93pTA7zG5(u"ࠨ࠾ࡧ࡭ࡻࠦࡣ࡭ࡣࡶࡷࡂࠨࡶࡱࡡࡹ࡭ࡩ࡫࡯ࡠࡵࡷࡹࡧࡥࡴࡹࡶࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫඊ"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
			if not msg: msg = dEyT9xhGjolYzLCH7460w3.findall(CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠩ࠿࡬࠷ࡄࠨࡔࡱࡵࡶࡾ࠴ࠪࡀࠫ࠿ࠫඋ"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
			if msg: phm0nfzAUCXHBjO7lIDSxT3eZJdc = msg[FGTfwsjNrB8DvKSZhLIQAb1JnO]
	return phm0nfzAUCXHBjO7lIDSxT3eZJdc,WK130YrED8vNhiHntepuXR,ff2PjlcCF5ZWyIUbVguMz
def YYdkJQyqIGzHV5ibO6(o4z2xMs1LBVXiGA,url):
	global Zr0sVtjhCOQ14Bulc
	url = url.strip(Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠪ࠳ࠬඌ"))
	vvrRwpWAOoSGThIJQVtCd2ZL,Si4j3bXGLeno0zfxlm9ZOcy = iiy37aKq0pCEIOwfcTh61xb4U,{}
	headers = {sVzojQerUqX(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨඍ"):FgJLkYac7lQxEbs()}
	headers[SaB5hx3PZwXRLtKgrTfQvId(u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭ඎ")] = F82MvyX4ThI6sbnA3efDoVS(url,tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"࠭ࡵࡳ࡮ࠪඏ"))
	headers[jXE2YHkswT8y(u"ࠧࡂࡥࡦࡩࡵࡺ࠭ࡍࡣࡱ࡫ࡺࡧࡧࡦࠩඐ")] = LyNiIHPOwD3hCUYEFM7(u"ࠨࡧࡱ࠱࡚࡙ࠬࡦࡰ࠾ࡵࡂ࠶࠮࠺ࠩඑ")
	headers[sVzojQerUqX(u"ࠩࡖࡩࡨ࠳ࡆࡦࡶࡦ࡬࠲ࡊࡥࡴࡶࠪඒ")] = hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠪ࡭࡫ࡸࡡ࡮ࡧࠪඓ")
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(r3rnfZ7cdxzNFebIRaLSG6B,ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠫࡌࡋࡔࠨඔ"),url,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,BF6QAiLUNHh7rKOugaw,y6y5HtgXO4TkUbwVZ(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡚ࡖࡌࡆࡘࡉࡏࡉ࠰࠵ࡸࡺࠧඕ"))
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	Xt6zjLgwabZP8JV = oCJ8TdG2LwSIVcbaUnhB.code
	if not isinstance(Vxz6OndPIX4g2kaRp7,str): Vxz6OndPIX4g2kaRp7 = Vxz6OndPIX4g2kaRp7.decode(df6QpwGxuJVZr,xpT28sXu051(u"࠭ࡩࡨࡰࡲࡶࡪ࠭ඖ"))
	if tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠧࡧࡷࡱࡧࡹ࡯࡯࡯ࠪࡳ࠰ࡦ࠲ࡣ࠭࡭࠯ࡩ࠱࠭඗") in Vxz6OndPIX4g2kaRp7:
		EmgOrMcPySkh2oFitb4qvNU7nQGD = dEyT9xhGjolYzLCH7460w3.findall(tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠨࠪࡨࡺࡦࡲ࡜ࠩࡨࡸࡲࡨࡺࡩࡰࡰ࡟ࠬࡵ࠲ࡡ࠭ࡥ࠯࡯࠱࡫ࠬ࡜ࡦࡵࡡ࠳࠰࠿ࠪ࠾࠲ࡷࡨࡸࡩࡱࡶࡁࠫ඘"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if EmgOrMcPySkh2oFitb4qvNU7nQGD:
			try: vvrRwpWAOoSGThIJQVtCd2ZL = D9gvQoIknzpr5chBa6Y2VKHxPq(EmgOrMcPySkh2oFitb4qvNU7nQGD[FGTfwsjNrB8DvKSZhLIQAb1JnO])
			except: vvrRwpWAOoSGThIJQVtCd2ZL = iiy37aKq0pCEIOwfcTh61xb4U
	if LyNiIHPOwD3hCUYEFM7(u"ࠩࡩࡹࡳࡩࡴࡪࡱࡱࠬ࡭࠲ࡵ࠭ࡰ࠯ࡸ࠱࡫ࠬࡳࠫࠪ඙") in Vxz6OndPIX4g2kaRp7:
		EmgOrMcPySkh2oFitb4qvNU7nQGD = dEyT9xhGjolYzLCH7460w3.findall(yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠪࠬࡪࡼࡡ࡭࡞ࠫࡪࡺࡴࡣࡵ࡫ࡲࡲࡡ࠮ࡨ࠭ࡷ࠯ࡲ࠱ࡺࠬࡦ࠮ࡵ࠲࠯ࡅࠩ࠽࠱ࡶࡧࡷ࡯ࡰࡵࡀࠪක"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if EmgOrMcPySkh2oFitb4qvNU7nQGD:
			try: vvrRwpWAOoSGThIJQVtCd2ZL = D5oyMb7NTziWkrqPG(EmgOrMcPySkh2oFitb4qvNU7nQGD[FGTfwsjNrB8DvKSZhLIQAb1JnO])
			except: vvrRwpWAOoSGThIJQVtCd2ZL = iiy37aKq0pCEIOwfcTh61xb4U
	z0spMAOfJElv6L1K9ae = Vxz6OndPIX4g2kaRp7+vvrRwpWAOoSGThIJQVtCd2ZL
	if jXE2YHkswT8y(u"ࠫࠧ࡯ࡤ࠳ࠤࠪඛ") in z0spMAOfJElv6L1K9ae or AbqCJZdWQP9j(u"ࠬࠨࡩࡥࠤࠪග") in z0spMAOfJElv6L1K9ae:
		UbQKWZn7z2TMcRwg61YDAdeH8SO = url.split(sVzojQerUqX(u"࠭࠯ࠨඝ"))[iiCWLaJREureAlOkv].replace(sVzojQerUqX(u"ࠧࡦ࡯ࡥࡩࡩ࠳ࠧඞ"),iiy37aKq0pCEIOwfcTh61xb4U).replace(CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠨ࠰࡫ࡸࡲࡲࠧඟ"),iiy37aKq0pCEIOwfcTh61xb4U)
		if hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠩࠥ࡭ࡩ࠸ࠢࠨච") in z0spMAOfJElv6L1K9ae: Si4j3bXGLeno0zfxlm9ZOcy = {ZchUJdM93pTA7zG5(u"ࠪ࡭ࡩ࠸ࠧඡ"):UbQKWZn7z2TMcRwg61YDAdeH8SO,y6y5HtgXO4TkUbwVZ(u"ࠫࡴࡶࠧජ"):xpT28sXu051(u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠲ࠨඣ")}
		elif EMO8gy4LrsNTh0knZwpSeU75APW(u"࠭ࠢࡪࡦࠥࠫඤ") in z0spMAOfJElv6L1K9ae: Si4j3bXGLeno0zfxlm9ZOcy = {AbqCJZdWQP9j(u"ࠧࡪࡦࠪඥ"):UbQKWZn7z2TMcRwg61YDAdeH8SO,XrTw01KtLzbpoyMf(u"ࠨࡱࡳࠫඦ"):XrTw01KtLzbpoyMf(u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧ࠶ࠬට")}
		rzR9SN7ApZuQhTDWEX3V6ga = headers.copy()
		rzR9SN7ApZuQhTDWEX3V6ga[MgP8OjoaiWQEVG59(u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩඨ")] = ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦࠪඩ")
		xQoYJsjSm0yfdzaOewV7pC = MMCJxEfv0WUek(r3rnfZ7cdxzNFebIRaLSG6B,AbqCJZdWQP9j(u"ࠬࡖࡏࡔࡖࠪඪ"),url,Si4j3bXGLeno0zfxlm9ZOcy,rzR9SN7ApZuQhTDWEX3V6ga,iiy37aKq0pCEIOwfcTh61xb4U,BF6QAiLUNHh7rKOugaw,MgP8OjoaiWQEVG59(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡛ࡗࡍࡇࡒࡊࡐࡊ࠱࠷ࡴࡤࠨණ"))
		z0spMAOfJElv6L1K9ae = xQoYJsjSm0yfdzaOewV7pC.content
	n946ncom3kWEIAwsFZQdp1hru7TL,G9RbxhB3qTdLf0etKswN,Ze6bCjpyP35IzasOgKu0v = XRsU6ModzJhDiF4BpmNafyeVrEH9(url,z0spMAOfJElv6L1K9ae)
	Zr0sVtjhCOQ14Bulc[o4z2xMs1LBVXiGA] = n946ncom3kWEIAwsFZQdp1hru7TL,G9RbxhB3qTdLf0etKswN,Ze6bCjpyP35IzasOgKu0v,Xt6zjLgwabZP8JV
	return
Zr0sVtjhCOQ14Bulc,KKtT1dxf6VScGFJes5 = {},FGTfwsjNrB8DvKSZhLIQAb1JnO
def NNZ7ynOVBYwG5(url):
	global Zr0sVtjhCOQ14Bulc,KKtT1dxf6VScGFJes5
	P3tys0cXWbiIUKk7HQ6n89V,threads = [],[]
	KKtT1dxf6VScGFJes5 += FRYcH4KL7e9gv5pEB(u"࠴࠴࠵๬")
	M7ZNPwfom2FnUD = KKtT1dxf6VScGFJes5
	P3tys0cXWbiIUKk7HQ6n89V.append([YYJQyRskpX8jv,url])
	Zr0sVtjhCOQ14Bulc[M7ZNPwfom2FnUD+YYJQyRskpX8jv] = [None,None,None,None]
	lAoVPRXtnkHqbw21i0IaQCT = EEehSFDLdpKBR3W1ga9PxrV.Thread(target=YYdkJQyqIGzHV5ibO6,args=(M7ZNPwfom2FnUD+YYJQyRskpX8jv,url))
	lAoVPRXtnkHqbw21i0IaQCT.start()
	lAoVPRXtnkHqbw21i0IaQCT.join(EMO8gy4LrsNTh0knZwpSeU75APW(u"࠵࠵๭"))
	if not Zr0sVtjhCOQ14Bulc[M7ZNPwfom2FnUD+ZchUJdM93pTA7zG5(u"࠶๮")][nI2JK1RfsGWNY3OarEeMQZ]:
		eCGwzSrqBmIv = url.replace(CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠧ࠰ࡧࡰࡦࡪࡪ࠭ࠨඬ"),yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠨ࠱ࠪත"))
		ng8RFTvpBOxuMa2ySjYWqVZX = dEyT9xhGjolYzLCH7460w3.findall(IpC4qHXRuyNFjzWv(u"ࠩࡡࠬ࠳࠰࠿࠻࠱࠲࠲࠯ࡅࠩ࠰ࠪ࠱࠮ࡄ࠯࠯ࠩ࠰࠭ࡃ࠮ࠪࠧථ"),eCGwzSrqBmIv+ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠪ࠳ࠬද"),dEyT9xhGjolYzLCH7460w3.DOTALL)
		start,EEoS5fyCeAN,end = ng8RFTvpBOxuMa2ySjYWqVZX[FGTfwsjNrB8DvKSZhLIQAb1JnO]
		end = end.strip(GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠫ࠴࠭ධ"))
		OQolPCwGSpA = len(EEoS5fyCeAN)<pZWli1xqfVtvzuSU6ImNw53gBFsh or EEoS5fyCeAN in [CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠬ࡬ࡩ࡭ࡧࠪන"),yJeq1BjfiO4NFuwIEzxVLK6b9s(u"࠭ࡶࡪࡦࡨࡳࠬ඲"),ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠧࡷ࡫ࡧࡩࡴ࡫࡭ࡣࡧࡧࠫඳ"),ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠨࡣ࡭ࡥࡽ࠭ප"),FRYcH4KL7e9gv5pEB(u"ࠩ࡬ࡪࡷࡧ࡭ࡦࠩඵ"),CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠪࡱ࡮ࡸࡲࡰࡴࠪබ")]
		if not OQolPCwGSpA: P3tys0cXWbiIUKk7HQ6n89V.append([nI2JK1RfsGWNY3OarEeMQZ,start+IpC4qHXRuyNFjzWv(u"ࠫ࠴࡫࡭ࡣࡧࡧ࠱ࠬභ")+EEoS5fyCeAN+ZchUJdM93pTA7zG5(u"ࠬ࠵ࠧම")+end])
		if end: P3tys0cXWbiIUKk7HQ6n89V.append([iiCWLaJREureAlOkv,start+yJeq1BjfiO4NFuwIEzxVLK6b9s(u"࠭࠯ࠨඹ")+EEoS5fyCeAN+LyNiIHPOwD3hCUYEFM7(u"ࠧ࠰ࡧࡰࡦࡪࡪ࠭ࠨය")+end])
		if vODxLKW5Ql6r4Fbm8(u"ࠨ࠰࡫ࡸࡲࡲࠧර") in EEoS5fyCeAN:
			FnEkxHscC4XhIW3i9T1Vqv8ewMLOoj = EEoS5fyCeAN.replace(IpC4qHXRuyNFjzWv(u"ࠩ࠱࡬ࡹࡳ࡬ࠨ඼"),iiy37aKq0pCEIOwfcTh61xb4U)
			P3tys0cXWbiIUKk7HQ6n89V.append([pZWli1xqfVtvzuSU6ImNw53gBFsh,start+LyNiIHPOwD3hCUYEFM7(u"ࠪ࠳ࠬල")+FnEkxHscC4XhIW3i9T1Vqv8ewMLOoj+CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠫ࠴࠭඾")+end])
			P3tys0cXWbiIUKk7HQ6n89V.append([hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"࠻๯"),start+TlGXWLYsV1z(u"ࠬ࠵ࡥ࡮ࡤࡨࡨ࠲࠭඿")+FnEkxHscC4XhIW3i9T1Vqv8ewMLOoj+zmcGfOdvAjsELeJlP(u"࠭࠯ࠨව")+end])
			if end: P3tys0cXWbiIUKk7HQ6n89V.append([JZszNnIEMAx28Yao0yqhiXGKOPb(u"࠶๰"),start+FRYcH4KL7e9gv5pEB(u"ࠧ࠰ࠩශ")+FnEkxHscC4XhIW3i9T1Vqv8ewMLOoj+yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠨ࠱ࡨࡱࡧ࡫ࡤ࠮ࠩෂ")+end])
		elif JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠩ࠱࡬ࡹࡳ࡬ࠨස") in end:
			QBwNV8c2i1LranKRH = end.replace(yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠪ࠲࡭ࡺ࡭࡭ࠩහ"),iiy37aKq0pCEIOwfcTh61xb4U)
			P3tys0cXWbiIUKk7HQ6n89V.append([SaB5hx3PZwXRLtKgrTfQvId(u"࠸๱"),start+yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠫ࠴࠭ළ")+EEoS5fyCeAN+FRYcH4KL7e9gv5pEB(u"ࠬ࠵ࠧෆ")+QBwNV8c2i1LranKRH])
			if not OQolPCwGSpA: P3tys0cXWbiIUKk7HQ6n89V.append([y6y5HtgXO4TkUbwVZ(u"࠺๲"),start+PtkEvXAqif14G20QZsaSyT(u"࠭࠯ࡦ࡯ࡥࡩࡩ࠳ࠧ෇")+EEoS5fyCeAN+PtkEvXAqif14G20QZsaSyT(u"ࠧ࠰ࠩ෈")+QBwNV8c2i1LranKRH])
			P3tys0cXWbiIUKk7HQ6n89V.append([L90uqo28xEKSFUwYTcm51yRWZIkft(u"࠼๳"),start+HtK4o2sTPgA78U(u"ࠨ࠱ࠪ෉")+EEoS5fyCeAN+tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠩ࠲ࡩࡲࡨࡥࡥ࠯්ࠪ")+QBwNV8c2i1LranKRH])
		else:
			if not OQolPCwGSpA: P3tys0cXWbiIUKk7HQ6n89V.append([SaB5hx3PZwXRLtKgrTfQvId(u"࠵࠵๴"),start+ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠪ࠳ࠬ෋")+EEoS5fyCeAN+PtkEvXAqif14G20QZsaSyT(u"ࠫ࠳࡮ࡴ࡮࡮ࠪ෌")])
			if not OQolPCwGSpA: P3tys0cXWbiIUKk7HQ6n89V.append([PtkEvXAqif14G20QZsaSyT(u"࠶࠷๵"),start+uuExaKGL7UONtevRd(u"ࠬ࠵ࡥ࡮ࡤࡨࡨ࠲࠭෍")+EEoS5fyCeAN+SaB5hx3PZwXRLtKgrTfQvId(u"࠭࠮ࡩࡶࡰࡰࠬ෎")])
			if end: P3tys0cXWbiIUKk7HQ6n89V.append([sVzojQerUqX(u"࠷࠲๶"),start+JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠧ࠰ࠩා")+EEoS5fyCeAN+LyNiIHPOwD3hCUYEFM7(u"ࠨ࠱ࠪැ")+end+PtkEvXAqif14G20QZsaSyT(u"ࠩ࠱࡬ࡹࡳ࡬ࠨෑ")])
			if end: P3tys0cXWbiIUKk7HQ6n89V.append([FRYcH4KL7e9gv5pEB(u"࠱࠴๷"),start+sVzojQerUqX(u"ࠪ࠳ࠬි")+EEoS5fyCeAN+uuExaKGL7UONtevRd(u"ࠫ࠴࡫࡭ࡣࡧࡧ࠱ࠬී")+end+EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠬ࠴ࡨࡵ࡯࡯ࠫු")])
		if OQolPCwGSpA and end:
			end = end.replace(hhQwbeiNLoqFjX90fB7aG8VAs(u"࠭࠯ࡦ࡯ࡥࡩࡩ࠳ࠧ෕"),sVzojQerUqX(u"ࠧ࠰ࠩූ"))
			P3tys0cXWbiIUKk7HQ6n89V.append([SaB5hx3PZwXRLtKgrTfQvId(u"࠲࠶๸"),start+vODxLKW5Ql6r4Fbm8(u"ࠨ࠱ࠪ෗")+end])
			P3tys0cXWbiIUKk7HQ6n89V.append([tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"࠳࠸๹"),start+GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠩ࠲ࡩࡲࡨࡥࡥ࠯ࠪෘ")+end])
			if LyNiIHPOwD3hCUYEFM7(u"ࠪ࠲࡭ࡺ࡭࡭ࠩෙ") in end:
				QBwNV8c2i1LranKRH = end.replace(tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠫ࠳࡮ࡴ࡮࡮ࠪේ"),iiy37aKq0pCEIOwfcTh61xb4U)
				P3tys0cXWbiIUKk7HQ6n89V.append([zmcGfOdvAjsELeJlP(u"࠴࠺๺"),start+YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠬ࠵ࠧෛ")+QBwNV8c2i1LranKRH])
				P3tys0cXWbiIUKk7HQ6n89V.append([GGx4qyKP1vUtRghsE2WfaHLMXZ(u"࠵࠼๻"),start+XrTw01KtLzbpoyMf(u"࠭࠯ࡦ࡯ࡥࡩࡩ࠳ࠧො")+QBwNV8c2i1LranKRH])
			else:
				P3tys0cXWbiIUKk7HQ6n89V.append([GGx4qyKP1vUtRghsE2WfaHLMXZ(u"࠶࠾๼"),start+vODxLKW5Ql6r4Fbm8(u"ࠧ࠰ࠩෝ")+end+PtkEvXAqif14G20QZsaSyT(u"ࠨ࠰࡫ࡸࡲࡲࠧෞ")])
				P3tys0cXWbiIUKk7HQ6n89V.append([GGx4qyKP1vUtRghsE2WfaHLMXZ(u"࠷࠹๽"),start+ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠩ࠲ࡩࡲࡨࡥࡥ࠯ࠪෟ")+end+ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠪ࠲࡭ࡺ࡭࡭ࠩ෠")])
		QcMTXIqdavNoYA1 = []
		for qCVlj6LiNza2MbZosSecpWQGuJd7,fCXyTlcmF4WuetVork in P3tys0cXWbiIUKk7HQ6n89V[YYJQyRskpX8jv:]:
			Zr0sVtjhCOQ14Bulc[M7ZNPwfom2FnUD+qCVlj6LiNza2MbZosSecpWQGuJd7] = [None,None,None,None]
			Sd6C38mfOrvZaoYVsqMygNIb5 = EEehSFDLdpKBR3W1ga9PxrV.Thread(target=YYdkJQyqIGzHV5ibO6,args=(M7ZNPwfom2FnUD+qCVlj6LiNza2MbZosSecpWQGuJd7,fCXyTlcmF4WuetVork))
			Sd6C38mfOrvZaoYVsqMygNIb5.start()
			QcMTXIqdavNoYA1.append(Sd6C38mfOrvZaoYVsqMygNIb5)
			X2cQ5NCPvkMieBW7oASspFjE.sleep(AbqCJZdWQP9j(u"࠰࠯࠹࠸๾"))
		for Sd6C38mfOrvZaoYVsqMygNIb5 in QcMTXIqdavNoYA1: Sd6C38mfOrvZaoYVsqMygNIb5.join(ZchUJdM93pTA7zG5(u"࠲࠲๿"))
	phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = iiy37aKq0pCEIOwfcTh61xb4U,[],[]
	zNcwdnO39lA = []
	for qCVlj6LiNza2MbZosSecpWQGuJd7,fCXyTlcmF4WuetVork in P3tys0cXWbiIUKk7HQ6n89V:
		QMVAFJYmri9fKkS7jnZc301O,D5DRIKPCSj23ribBfd9,CCglWLRTsNIF23r5OAwcHxfBubiEd,rjcEAOCTGa1 = Zr0sVtjhCOQ14Bulc[M7ZNPwfom2FnUD+qCVlj6LiNza2MbZosSecpWQGuJd7]
		if not duef0gb3Mi1AV5WpN8 and CCglWLRTsNIF23r5OAwcHxfBubiEd: A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = D5DRIKPCSj23ribBfd9,CCglWLRTsNIF23r5OAwcHxfBubiEd
		if not phm0nfzAUCXHBjO7lIDSxT3eZJdc and QMVAFJYmri9fKkS7jnZc301O: phm0nfzAUCXHBjO7lIDSxT3eZJdc = QMVAFJYmri9fKkS7jnZc301O
		if rjcEAOCTGa1: zNcwdnO39lA.append(rjcEAOCTGa1)
	zNcwdnO39lA = list(set(zNcwdnO39lA))
	if not phm0nfzAUCXHBjO7lIDSxT3eZJdc and len(zNcwdnO39lA)==y6y5HtgXO4TkUbwVZ(u"࠳຀"):
		Xt6zjLgwabZP8JV = zNcwdnO39lA[FGTfwsjNrB8DvKSZhLIQAb1JnO]
		if Xt6zjLgwabZP8JV!=L90uqo28xEKSFUwYTcm51yRWZIkft(u"࠵࠴࠵ກ"):
			if Xt6zjLgwabZP8JV<FGTfwsjNrB8DvKSZhLIQAb1JnO: phm0nfzAUCXHBjO7lIDSxT3eZJdc = FRYcH4KL7e9gv5pEB(u"࡛ࠫ࡯ࡤࡦࡱࠣࡴࡦ࡭ࡥ࠰ࡵࡨࡶࡻ࡫ࡲࠡ࡫ࡶࠤࡳࡵࡴࠡࡣࡦࡧࡪࡹࡳࡪࡤ࡯ࡩࠬ෡")
			else:
				phm0nfzAUCXHBjO7lIDSxT3eZJdc = Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠬࡎࡔࡕࡒࠣࡉࡷࡸ࡯ࡳ࠼ࠣࠫ෢")+str(Xt6zjLgwabZP8JV)
				if J1MoiYc7ZwzKS: import http.client as Hc2MJpX6ET3oCPlSfagjtIk
				else: import httplib as Hc2MJpX6ET3oCPlSfagjtIk
				try: phm0nfzAUCXHBjO7lIDSxT3eZJdc += MgP8OjoaiWQEVG59(u"࠭ࠠࠩࠢࠪ෣")+Hc2MJpX6ET3oCPlSfagjtIk.responses[Xt6zjLgwabZP8JV]+tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠧࠡࠫࠪ෤")
				except: pass
	X2cQ5NCPvkMieBW7oASspFjE.sleep(YYJQyRskpX8jv)
	return phm0nfzAUCXHBjO7lIDSxT3eZJdc,A7Ap2wdlxM,duef0gb3Mi1AV5WpN8
class j1XEMZtxbu6K87wUvlHYh9I4F(OOYtyXB3o8K.WindowDialog):
	def __init__(duiHLz8j2YhP3VUAapeB1GnmFS, *args, **gSN8JnLj3FUOohl):
		AAVG6359korcgfBx4OYR1v = wkMR5x1gTWEQIc6qHCa.path.join(V5f96hvSkeUwCxZrE4dlzpy, uuExaKGL7UONtevRd(u"ࠨࡴࡨࡷࡴࡻࡲࡤࡧࡶࠫ෥"), sVzojQerUqX(u"ࠩࡵࡩࡨࡧࡰࡵࡥ࡫ࡥ࠷࠭෦"), LyNiIHPOwD3hCUYEFM7(u"ࠪࡨ࡮ࡧ࡬ࡰࡩࡥ࡫࠳ࡶ࡮ࡨࠩ෧"))
		pbY9RA53j8H0eUEyXr = wkMR5x1gTWEQIc6qHCa.path.join(V5f96hvSkeUwCxZrE4dlzpy, tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠫࡷ࡫ࡳࡰࡷࡵࡧࡪࡹࠧ෨"), PtkEvXAqif14G20QZsaSyT(u"ࠬࡸࡥࡤࡣࡳࡸࡨ࡮ࡡ࠳ࠩ෩"), hhQwbeiNLoqFjX90fB7aG8VAs(u"࠭ࡳࡦ࡮ࡨࡧࡹ࡫ࡤ࠯ࡲࡱ࡫ࠬ෪"))
		p24PyufhCieHa9 = wkMR5x1gTWEQIc6qHCa.path.join(V5f96hvSkeUwCxZrE4dlzpy, PtkEvXAqif14G20QZsaSyT(u"ࠧࡳࡧࡶࡳࡺࡸࡣࡦࡵࠪ෫"), UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠨࡴࡨࡧࡦࡶࡴࡤࡪࡤ࠶ࠬ෬"), TlGXWLYsV1z(u"ࠩࡥࡹࡹࡺ࡯࡯ࡨࡲ࠲ࡵࡴࡧࠨ෭"))
		Q836vWcNKbiXjl7tqHxwamyuUFOC = wkMR5x1gTWEQIc6qHCa.path.join(V5f96hvSkeUwCxZrE4dlzpy, PtkEvXAqif14G20QZsaSyT(u"ࠪࡶࡪࡹ࡯ࡶࡴࡦࡩࡸ࠭෮"), ZchUJdM93pTA7zG5(u"ࠫࡷ࡫ࡣࡢࡲࡷࡧ࡭ࡧ࠲ࠨ෯"), TlGXWLYsV1z(u"ࠬࡨࡵࡵࡶࡲࡲࡳ࡬࠮ࡱࡰࡪࠫ෰"))
		TTeRD6hstz = wkMR5x1gTWEQIc6qHCa.path.join(V5f96hvSkeUwCxZrE4dlzpy, UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"࠭ࡲࡦࡵࡲࡹࡷࡩࡥࡴࠩ෱"), hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠧࡳࡧࡦࡥࡵࡺࡣࡩࡣ࠵ࠫෲ"), hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠨࡤࡸࡸࡹࡵ࡮ࡣࡩ࠱ࡴࡳ࡭ࠧෳ"))
		duiHLz8j2YhP3VUAapeB1GnmFS.cancelled = BF6QAiLUNHh7rKOugaw
		duiHLz8j2YhP3VUAapeB1GnmFS.chk = [FGTfwsjNrB8DvKSZhLIQAb1JnO] * tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"࠽ຂ")
		duiHLz8j2YhP3VUAapeB1GnmFS.chkbutton = [FGTfwsjNrB8DvKSZhLIQAb1JnO] * sVzojQerUqX(u"࠾຃")
		duiHLz8j2YhP3VUAapeB1GnmFS.chkstate = [BF6QAiLUNHh7rKOugaw] * xpT28sXu051(u"࠿ຄ")
		GGTEviMIfk, HDTPaC97FygBXiJAQIwr13lU5k0K68, eepuqiHmwIEdLo8anUGPTzWOQg, sNymFlYwfHt8eMrTSq2oaWJQnAEz = jXE2YHkswT8y(u"࠲࠶࠲຅"), FGTfwsjNrB8DvKSZhLIQAb1JnO, uuExaKGL7UONtevRd(u"࠸࠲࠳ຆ"), UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"࠹࠹࠴ງ")
		rO8Fp4y1KLTzEga = GGTEviMIfk+eepuqiHmwIEdLo8anUGPTzWOQg//nI2JK1RfsGWNY3OarEeMQZ
		iq9xJlwbvn5UTWFX, ii40FGAaNlP18ICcSq5WMd, b5bY9hpUrakgxMms4J, qMDLG5sBZoAQmwdP8HCf96i = sVzojQerUqX(u"࠷࠺࠻ຉ"), FRYcH4KL7e9gv5pEB(u"࠴࠶࠵ຈ"), LyNiIHPOwD3hCUYEFM7(u"࠺࠶࠰ຊ"), LyNiIHPOwD3hCUYEFM7(u"࠺࠶࠰ຊ")
		Rog52fm1nVkMYyxehu0BFz = iq9xJlwbvn5UTWFX+b5bY9hpUrakgxMms4J//nI2JK1RfsGWNY3OarEeMQZ
		ddZ4W3bYwp2vm6Be, csSnjyOMG8, tP7c54VRQkuHT, RCcG1U9aTP6nYZiVx = FRYcH4KL7e9gv5pEB(u"࠱࠱࠲ຌ"), HtK4o2sTPgA78U(u"࠷࠷࠸ຍ"), GGx4qyKP1vUtRghsE2WfaHLMXZ(u"࠷࠵࠱຋"), uuExaKGL7UONtevRd(u"࠷࠳ຎ")
		KJBiAFQamXOs8l1Vr3gv9oMIWhdP = rO8Fp4y1KLTzEga-tP7c54VRQkuHT-ddZ4W3bYwp2vm6Be//nI2JK1RfsGWNY3OarEeMQZ
		SEq0ifeW2uQLPJ6MCXZjly = rO8Fp4y1KLTzEga+ddZ4W3bYwp2vm6Be//nI2JK1RfsGWNY3OarEeMQZ
		xXlaYqmOh5dtW9Q6cn3LUM, ec4qN0nUsKYHvMi9tjgJfV, neLDU2YaP3fJ, JgP9a6py3OmD = hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"࠶࠹࠺ຏ"), Y41NvKfOroMzGB8sEHy7wbXlc5(u"࠷࠵ຐ"), yJeq1BjfiO4NFuwIEzxVLK6b9s(u"࠻࠰࠱ຒ"), MgP8OjoaiWQEVG59(u"࠺࠶ຑ")
		RR93MvugFULICHQSnZyo, D93DWKh56HgGwUJXYneRau, d8Ib4Ap16esnRVgZfKtDQM, hhR3zMuktK2omLbIlyVxcZ09nXgQ7G = ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"࠳࠶࠷ຓ"), SaB5hx3PZwXRLtKgrTfQvId(u"࠺࠴ຖ"), uuExaKGL7UONtevRd(u"࠷࠳࠴ຕ"), SaB5hx3PZwXRLtKgrTfQvId(u"࠶࠲ດ")
		MEnH5Deskm = ZchUJdM93pTA7zG5(u"࠴࠳࠿ທ")
		GGTEviMIfk, HDTPaC97FygBXiJAQIwr13lU5k0K68, eepuqiHmwIEdLo8anUGPTzWOQg, sNymFlYwfHt8eMrTSq2oaWJQnAEz = int(GGTEviMIfk*MEnH5Deskm), int(HDTPaC97FygBXiJAQIwr13lU5k0K68*MEnH5Deskm), int(eepuqiHmwIEdLo8anUGPTzWOQg*MEnH5Deskm), int(sNymFlYwfHt8eMrTSq2oaWJQnAEz*MEnH5Deskm)
		iq9xJlwbvn5UTWFX, ii40FGAaNlP18ICcSq5WMd, b5bY9hpUrakgxMms4J, qMDLG5sBZoAQmwdP8HCf96i = int(iq9xJlwbvn5UTWFX*MEnH5Deskm), int(ii40FGAaNlP18ICcSq5WMd*MEnH5Deskm), int(b5bY9hpUrakgxMms4J*MEnH5Deskm), int(qMDLG5sBZoAQmwdP8HCf96i*MEnH5Deskm)
		KJBiAFQamXOs8l1Vr3gv9oMIWhdP, b37aVjvsNOtY, CZwAhm37p2, J3e10YK8ftjmqEduHsROGSF6 = int(KJBiAFQamXOs8l1Vr3gv9oMIWhdP*MEnH5Deskm), int(csSnjyOMG8*MEnH5Deskm), int(tP7c54VRQkuHT*MEnH5Deskm), int(RCcG1U9aTP6nYZiVx*MEnH5Deskm)
		SEq0ifeW2uQLPJ6MCXZjly, k24kR3AZJDrWOTfycI78wFpHaU, UgyCqWcojtxh, FH5tIlWz7Q2yuXDTMChK3ZfA = int(SEq0ifeW2uQLPJ6MCXZjly*MEnH5Deskm), int(csSnjyOMG8*MEnH5Deskm), int(tP7c54VRQkuHT*MEnH5Deskm), int(RCcG1U9aTP6nYZiVx*MEnH5Deskm)
		xXlaYqmOh5dtW9Q6cn3LUM, ec4qN0nUsKYHvMi9tjgJfV, neLDU2YaP3fJ, JgP9a6py3OmD = int(xXlaYqmOh5dtW9Q6cn3LUM*MEnH5Deskm), int(ec4qN0nUsKYHvMi9tjgJfV*MEnH5Deskm), int(neLDU2YaP3fJ*MEnH5Deskm), int(JgP9a6py3OmD*MEnH5Deskm)
		RR93MvugFULICHQSnZyo, D93DWKh56HgGwUJXYneRau, d8Ib4Ap16esnRVgZfKtDQM, hhR3zMuktK2omLbIlyVxcZ09nXgQ7G = int(RR93MvugFULICHQSnZyo*MEnH5Deskm), int(D93DWKh56HgGwUJXYneRau*MEnH5Deskm), int(d8Ib4Ap16esnRVgZfKtDQM*MEnH5Deskm), int(hhR3zMuktK2omLbIlyVxcZ09nXgQ7G*MEnH5Deskm)
		lyuMe0toO1d8LacIJ6QkBh7Ww9 = OOYtyXB3o8K.ControlImage(GGTEviMIfk, HDTPaC97FygBXiJAQIwr13lU5k0K68, eepuqiHmwIEdLo8anUGPTzWOQg, sNymFlYwfHt8eMrTSq2oaWJQnAEz, AAVG6359korcgfBx4OYR1v)
		duiHLz8j2YhP3VUAapeB1GnmFS.addControl(lyuMe0toO1d8LacIJ6QkBh7Ww9)
		duiHLz8j2YhP3VUAapeB1GnmFS.iteration = gSN8JnLj3FUOohl.get(UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠩ࡬ࡸࡪࡸࡡࡵ࡫ࡲࡲࠬ෴"))
		J8lUKvY0ekBgif2 = aqEsMBckT2bunGHfl48Wip+UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠪๅา฻ࠠฤ่สࠤส์ำศ่ࠣ์ู้สࠡำ๋ฬํะࠠࠡࠢࠣࠤࠥࠦࠠࠡࠩ෵")+y6y5HtgXO4TkUbwVZ(u"ࠫฬ๊ๅฮษ๋่ฮࠦัใ็ࠣࠤࠬ෶")+str(duiHLz8j2YhP3VUAapeB1GnmFS.iteration)+YoQW601K4fMJcsreDnGVE5wUZIy7
		duiHLz8j2YhP3VUAapeB1GnmFS.strActionInfo = OOYtyXB3o8K.ControlLabel(xXlaYqmOh5dtW9Q6cn3LUM, ec4qN0nUsKYHvMi9tjgJfV, neLDU2YaP3fJ, JgP9a6py3OmD, J8lUKvY0ekBgif2, EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠬ࡬࡯࡯ࡶ࠴࠷ࠬ෷"))
		duiHLz8j2YhP3VUAapeB1GnmFS.addControl(duiHLz8j2YhP3VUAapeB1GnmFS.strActionInfo)
		C0dvhEbPWYlUtimM3x = OOYtyXB3o8K.ControlImage(iq9xJlwbvn5UTWFX, ii40FGAaNlP18ICcSq5WMd, b5bY9hpUrakgxMms4J, qMDLG5sBZoAQmwdP8HCf96i, gSN8JnLj3FUOohl.get(TlGXWLYsV1z(u"࠭ࡣࡢࡲࡷࡧ࡭ࡧࠧ෸")))
		duiHLz8j2YhP3VUAapeB1GnmFS.addControl(C0dvhEbPWYlUtimM3x)
		os5SkBwazpZg8eOGij0WDfEUnCrN = aqEsMBckT2bunGHfl48Wip+gSN8JnLj3FUOohl.get(SaB5hx3PZwXRLtKgrTfQvId(u"ࠧ࡮ࡵࡪࠫ෹"))+YoQW601K4fMJcsreDnGVE5wUZIy7
		duiHLz8j2YhP3VUAapeB1GnmFS.strActionInfo = OOYtyXB3o8K.ControlLabel(RR93MvugFULICHQSnZyo, D93DWKh56HgGwUJXYneRau, d8Ib4Ap16esnRVgZfKtDQM, hhR3zMuktK2omLbIlyVxcZ09nXgQ7G, os5SkBwazpZg8eOGij0WDfEUnCrN, FRYcH4KL7e9gv5pEB(u"ࠨࡨࡲࡲࡹ࠷࠳ࠨ෺"))
		duiHLz8j2YhP3VUAapeB1GnmFS.addControl(duiHLz8j2YhP3VUAapeB1GnmFS.strActionInfo)
		text = aqEsMBckT2bunGHfl48Wip+ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠩัีําࠧ෻")+YoQW601K4fMJcsreDnGVE5wUZIy7
		duiHLz8j2YhP3VUAapeB1GnmFS.cancelbutton = OOYtyXB3o8K.ControlButton(KJBiAFQamXOs8l1Vr3gv9oMIWhdP, b37aVjvsNOtY, CZwAhm37p2, J3e10YK8ftjmqEduHsROGSF6, text, focusTexture=TTeRD6hstz, noFocusTexture=p24PyufhCieHa9, alignment=hhQwbeiNLoqFjX90fB7aG8VAs(u"࠷ຘ"))
		text = aqEsMBckT2bunGHfl48Wip+CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠪหุะๅาษิࠫ෼")+YoQW601K4fMJcsreDnGVE5wUZIy7
		duiHLz8j2YhP3VUAapeB1GnmFS.okbutton = OOYtyXB3o8K.ControlButton(SEq0ifeW2uQLPJ6MCXZjly, k24kR3AZJDrWOTfycI78wFpHaU, UgyCqWcojtxh, FH5tIlWz7Q2yuXDTMChK3ZfA, text, focusTexture=TTeRD6hstz, noFocusTexture=p24PyufhCieHa9, alignment=uuExaKGL7UONtevRd(u"࠸ນ"))
		duiHLz8j2YhP3VUAapeB1GnmFS.addControl(duiHLz8j2YhP3VUAapeB1GnmFS.okbutton)
		duiHLz8j2YhP3VUAapeB1GnmFS.addControl(duiHLz8j2YhP3VUAapeB1GnmFS.cancelbutton)
		JAOcDnfp8itCe0FSM, afy20XUoB81W7cQGNn4VZht = qMDLG5sBZoAQmwdP8HCf96i//iiCWLaJREureAlOkv, b5bY9hpUrakgxMms4J//iiCWLaJREureAlOkv
		for iEfNKT3velFyGth80SA4pxbCRrVD in range(MgP8OjoaiWQEVG59(u"࠹ບ")):
			Nd0eZ4SYP5UaDjcIwkMqBz1fy7s = iEfNKT3velFyGth80SA4pxbCRrVD // iiCWLaJREureAlOkv
			jjlbmtUEQpeVrxg17aRCDOZufNH = iEfNKT3velFyGth80SA4pxbCRrVD % iiCWLaJREureAlOkv
			zn9hp3IRcN = iq9xJlwbvn5UTWFX + (afy20XUoB81W7cQGNn4VZht * jjlbmtUEQpeVrxg17aRCDOZufNH)
			HnvsJWPSGl3fXbcuL2U = ii40FGAaNlP18ICcSq5WMd + (JAOcDnfp8itCe0FSM * Nd0eZ4SYP5UaDjcIwkMqBz1fy7s)
			duiHLz8j2YhP3VUAapeB1GnmFS.chk[iEfNKT3velFyGth80SA4pxbCRrVD] = OOYtyXB3o8K.ControlImage(zn9hp3IRcN, HnvsJWPSGl3fXbcuL2U, afy20XUoB81W7cQGNn4VZht, JAOcDnfp8itCe0FSM, pbY9RA53j8H0eUEyXr)
			duiHLz8j2YhP3VUAapeB1GnmFS.addControl(duiHLz8j2YhP3VUAapeB1GnmFS.chk[iEfNKT3velFyGth80SA4pxbCRrVD])
			duiHLz8j2YhP3VUAapeB1GnmFS.chk[iEfNKT3velFyGth80SA4pxbCRrVD].setVisible(BF6QAiLUNHh7rKOugaw)
			duiHLz8j2YhP3VUAapeB1GnmFS.chkbutton[iEfNKT3velFyGth80SA4pxbCRrVD] = OOYtyXB3o8K.ControlButton(zn9hp3IRcN, HnvsJWPSGl3fXbcuL2U, afy20XUoB81W7cQGNn4VZht, JAOcDnfp8itCe0FSM, str(iEfNKT3velFyGth80SA4pxbCRrVD + YYJQyRskpX8jv), font=hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠫ࡫ࡵ࡮ࡵ࠳࠶ࠫ෽"), focusTexture=p24PyufhCieHa9, noFocusTexture=Q836vWcNKbiXjl7tqHxwamyuUFOC)
			duiHLz8j2YhP3VUAapeB1GnmFS.addControl(duiHLz8j2YhP3VUAapeB1GnmFS.chkbutton[iEfNKT3velFyGth80SA4pxbCRrVD])
		for iEfNKT3velFyGth80SA4pxbCRrVD in range(jXE2YHkswT8y(u"࠺ປ")):
			YCatD4MLd5Bm = (iEfNKT3velFyGth80SA4pxbCRrVD // iiCWLaJREureAlOkv) * iiCWLaJREureAlOkv
			c1cu7VoXEJqtObdzkxSi = YCatD4MLd5Bm + (iEfNKT3velFyGth80SA4pxbCRrVD + YYJQyRskpX8jv) % iiCWLaJREureAlOkv
			Rjh4NnXsoTCrI7QB9ex = YCatD4MLd5Bm + (iEfNKT3velFyGth80SA4pxbCRrVD - YYJQyRskpX8jv) % iiCWLaJREureAlOkv
			BSwTmpQxHKL9 = (iEfNKT3velFyGth80SA4pxbCRrVD - iiCWLaJREureAlOkv) % AbqCJZdWQP9j(u"࠻ຜ")
			Z5GuqgtApEL7Ny = (iEfNKT3velFyGth80SA4pxbCRrVD + iiCWLaJREureAlOkv) % XrTw01KtLzbpoyMf(u"࠼ຝ")
			duiHLz8j2YhP3VUAapeB1GnmFS.chkbutton[iEfNKT3velFyGth80SA4pxbCRrVD].controlRight(duiHLz8j2YhP3VUAapeB1GnmFS.chkbutton[c1cu7VoXEJqtObdzkxSi])
			duiHLz8j2YhP3VUAapeB1GnmFS.chkbutton[iEfNKT3velFyGth80SA4pxbCRrVD].controlLeft(duiHLz8j2YhP3VUAapeB1GnmFS.chkbutton[Rjh4NnXsoTCrI7QB9ex])
			if iEfNKT3velFyGth80SA4pxbCRrVD <= nI2JK1RfsGWNY3OarEeMQZ:
				duiHLz8j2YhP3VUAapeB1GnmFS.chkbutton[iEfNKT3velFyGth80SA4pxbCRrVD].controlUp(duiHLz8j2YhP3VUAapeB1GnmFS.okbutton)
			else:
				duiHLz8j2YhP3VUAapeB1GnmFS.chkbutton[iEfNKT3velFyGth80SA4pxbCRrVD].controlUp(duiHLz8j2YhP3VUAapeB1GnmFS.chkbutton[BSwTmpQxHKL9])
			if iEfNKT3velFyGth80SA4pxbCRrVD >= LyNiIHPOwD3hCUYEFM7(u"࠺ພ"):
				duiHLz8j2YhP3VUAapeB1GnmFS.chkbutton[iEfNKT3velFyGth80SA4pxbCRrVD].controlDown(duiHLz8j2YhP3VUAapeB1GnmFS.okbutton)
			else:
				duiHLz8j2YhP3VUAapeB1GnmFS.chkbutton[iEfNKT3velFyGth80SA4pxbCRrVD].controlDown(duiHLz8j2YhP3VUAapeB1GnmFS.chkbutton[Z5GuqgtApEL7Ny])
		duiHLz8j2YhP3VUAapeB1GnmFS.okbutton.controlLeft(duiHLz8j2YhP3VUAapeB1GnmFS.cancelbutton)
		duiHLz8j2YhP3VUAapeB1GnmFS.okbutton.controlRight(duiHLz8j2YhP3VUAapeB1GnmFS.cancelbutton)
		duiHLz8j2YhP3VUAapeB1GnmFS.cancelbutton.controlLeft(duiHLz8j2YhP3VUAapeB1GnmFS.okbutton)
		duiHLz8j2YhP3VUAapeB1GnmFS.cancelbutton.controlRight(duiHLz8j2YhP3VUAapeB1GnmFS.okbutton)
		duiHLz8j2YhP3VUAapeB1GnmFS.okbutton.controlDown(duiHLz8j2YhP3VUAapeB1GnmFS.chkbutton[nI2JK1RfsGWNY3OarEeMQZ])
		duiHLz8j2YhP3VUAapeB1GnmFS.okbutton.controlUp(duiHLz8j2YhP3VUAapeB1GnmFS.chkbutton[ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"࠽ຟ")])
		duiHLz8j2YhP3VUAapeB1GnmFS.cancelbutton.controlDown(duiHLz8j2YhP3VUAapeB1GnmFS.chkbutton[FGTfwsjNrB8DvKSZhLIQAb1JnO])
		duiHLz8j2YhP3VUAapeB1GnmFS.cancelbutton.controlUp(duiHLz8j2YhP3VUAapeB1GnmFS.chkbutton[IpC4qHXRuyNFjzWv(u"࠼ຠ")])
		duiHLz8j2YhP3VUAapeB1GnmFS.setFocus(duiHLz8j2YhP3VUAapeB1GnmFS.okbutton)
	def get(duiHLz8j2YhP3VUAapeB1GnmFS):
		duiHLz8j2YhP3VUAapeB1GnmFS.doModal()
		duiHLz8j2YhP3VUAapeB1GnmFS.close()
		if not duiHLz8j2YhP3VUAapeB1GnmFS.cancelled:
			return [iEfNKT3velFyGth80SA4pxbCRrVD for iEfNKT3velFyGth80SA4pxbCRrVD in range(FRYcH4KL7e9gv5pEB(u"࠹ມ")) if duiHLz8j2YhP3VUAapeB1GnmFS.chkstate[iEfNKT3velFyGth80SA4pxbCRrVD]]
	def onControl(duiHLz8j2YhP3VUAapeB1GnmFS, dgzDAZYCJNXPMQyE9vhS1teiB0):
		if dgzDAZYCJNXPMQyE9vhS1teiB0.getId() == duiHLz8j2YhP3VUAapeB1GnmFS.okbutton.getId() and any(duiHLz8j2YhP3VUAapeB1GnmFS.chkstate):
			duiHLz8j2YhP3VUAapeB1GnmFS.close()
		elif dgzDAZYCJNXPMQyE9vhS1teiB0.getId() == duiHLz8j2YhP3VUAapeB1GnmFS.cancelbutton.getId():
			duiHLz8j2YhP3VUAapeB1GnmFS.cancelled = rGPen6cSMHQkAywh8vqI9JXiD2
			duiHLz8j2YhP3VUAapeB1GnmFS.close()
		else:
			e7wFcO9GDXRq = dgzDAZYCJNXPMQyE9vhS1teiB0.getLabel()
			if e7wFcO9GDXRq.isnumeric():
				index = int(e7wFcO9GDXRq) - YYJQyRskpX8jv
				duiHLz8j2YhP3VUAapeB1GnmFS.chkstate[index] = not duiHLz8j2YhP3VUAapeB1GnmFS.chkstate[index]
				duiHLz8j2YhP3VUAapeB1GnmFS.chk[index].setVisible(duiHLz8j2YhP3VUAapeB1GnmFS.chkstate[index])
	def onAction(duiHLz8j2YhP3VUAapeB1GnmFS, nYj9DlqLkQsmS8xthp):
		if nYj9DlqLkQsmS8xthp == AbqCJZdWQP9j(u"࠲࠲ຢ"):
			duiHLz8j2YhP3VUAapeB1GnmFS.cancelled = rGPen6cSMHQkAywh8vqI9JXiD2
			duiHLz8j2YhP3VUAapeB1GnmFS.close()
def xEw7j5Grt1zhZ(key,aN8jtOe3hcFP6fwRYnbg,url):
	headers = {vODxLKW5Ql6r4Fbm8(u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭෾"):url,Y41NvKfOroMzGB8sEHy7wbXlc5(u"࠭ࡁࡤࡥࡨࡴࡹ࠳ࡌࡢࡰࡪࡹࡦ࡭ࡥࠨ෿"):aN8jtOe3hcFP6fwRYnbg}
	fBXqcPChEDutyIelrRH9a8Q6UT4G = IpC4qHXRuyNFjzWv(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲࡬ࡵ࡯ࡨ࡮ࡨ࠲ࡨࡵ࡭࠰ࡴࡨࡧࡦࡶࡴࡤࡪࡤ࠳ࡦࡶࡩ࠰ࡨࡤࡰࡱࡨࡡࡤ࡭ࡂ࡯ࡂ࠭฀")+key
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(Dxc7GChQwZ4kOlKHSbL06agnB,LyNiIHPOwD3hCUYEFM7(u"ࠨࡉࡈࡘࠬก"),fBXqcPChEDutyIelrRH9a8Q6UT4G,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,xpT28sXu051(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡍࡅࡕࡡࡕࡉࡈࡇࡐࡕࡅࡋࡅ࠷ࡥࡔࡐࡍࡈࡒ࠲࠷ࡳࡵࠩข"))
	XV3cU4Ez5kgM0YtHNedhuRGB879lpT,iteration = iiy37aKq0pCEIOwfcTh61xb4U,FGTfwsjNrB8DvKSZhLIQAb1JnO
	while rGPen6cSMHQkAywh8vqI9JXiD2:
		Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
		Si4j3bXGLeno0zfxlm9ZOcy = dEyT9xhGjolYzLCH7460w3.findall(TlGXWLYsV1z(u"ࠪࠦ࠭࠵ࡲࡦࡥࡤࡴࡹࡩࡨࡢ࠱ࡤࡴ࡮࠸࠯ࡱࡣࡼࡰࡴࡧࡤ࡜ࡠࠥࡡ࠰࠯ࠧฃ"), Vxz6OndPIX4g2kaRp7)
		iteration += YYJQyRskpX8jv
		message = dEyT9xhGjolYzLCH7460w3.findall(EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠫࡁࡲࡡࡣࡧ࡯࡟ࡣࡄ࡝ࠬࡥ࡯ࡥࡸࡹ࠽ࠣࡨࡥࡧ࠲࡯࡭ࡢࡩࡨࡷࡪࡲࡥࡤࡶ࠰ࡱࡪࡹࡳࡢࡩࡨ࠱ࡹ࡫ࡸࡵࠤ࡞ࡢࡃࡣࠪ࠿ࠪ࠱࠮ࡄ࠯࠼࠰࡮ࡤࡦࡪࡲ࠾ࠨค"), Vxz6OndPIX4g2kaRp7)
		if not message: message = dEyT9xhGjolYzLCH7460w3.findall(IpC4qHXRuyNFjzWv(u"ࠬࡂࡤࡪࡸ࡞ࡢࡃࡣࠫࡤ࡮ࡤࡷࡸࡃࠢࡧࡤࡦ࠱࡮ࡳࡡࡨࡧࡶࡩࡱ࡫ࡣࡵ࠯ࡰࡩࡸࡹࡡࡨࡧ࠰ࡩࡷࡸ࡯ࡳࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨฅ"), Vxz6OndPIX4g2kaRp7)
		if not message:
			XV3cU4Ez5kgM0YtHNedhuRGB879lpT = dEyT9xhGjolYzLCH7460w3.findall(XrTw01KtLzbpoyMf(u"࠭ࡲࡦࡣࡧࡳࡳࡲࡹ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨฆ"), Vxz6OndPIX4g2kaRp7)[FGTfwsjNrB8DvKSZhLIQAb1JnO]
			break
		else:
			message = message[FGTfwsjNrB8DvKSZhLIQAb1JnO]
			Si4j3bXGLeno0zfxlm9ZOcy = Si4j3bXGLeno0zfxlm9ZOcy[FGTfwsjNrB8DvKSZhLIQAb1JnO]
		bvLVTy8I7SMa = dEyT9xhGjolYzLCH7460w3.findall(L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࡲࠨࡰࡤࡱࡪࡃࠢࡤࠤ࡟ࡷ࠰ࡼࡡ࡭ࡷࡨࡁࠧ࠮࡛࡟ࠤࡠ࠯࠮࠭ง"), Vxz6OndPIX4g2kaRp7)[FGTfwsjNrB8DvKSZhLIQAb1JnO]
		qVSmdAQ4kwgx = ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡧࡰࡱࡪࡰࡪ࠴ࡣࡰ࡯ࠨࡷࠬจ") % (Si4j3bXGLeno0zfxlm9ZOcy.replace(XrTw01KtLzbpoyMf(u"ࠩࠩࡥࡲࡶ࠻ࠨฉ"), tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠪࠪࠬช")))
		message = dEyT9xhGjolYzLCH7460w3.sub(xpT28sXu051(u"ࠫࡁ࠵࠿ࠩࡦ࡬ࡺࢁࡹࡴࡳࡱࡱ࡫࠮ࡡ࡞࠿࡟࠭ࡂࠬซ"), iiy37aKq0pCEIOwfcTh61xb4U, message)
		y4NfcvDRewGV = j1XEMZtxbu6K87wUvlHYh9I4F(captcha=qVSmdAQ4kwgx, msg=message, iteration=iteration)
		F7AuSCnJPh = y4NfcvDRewGV.get()
		if not F7AuSCnJPh: break
		data = {L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠬࡩࠧฌ"): bvLVTy8I7SMa, sVzojQerUqX(u"࠭ࡲࡦࡵࡳࡳࡳࡹࡥࠨญ"): F7AuSCnJPh}
		oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(Dxc7GChQwZ4kOlKHSbL06agnB,HtK4o2sTPgA78U(u"ࠧࡑࡑࡖࡘࠬฎ"),fBXqcPChEDutyIelrRH9a8Q6UT4G,data,headers,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,vODxLKW5Ql6r4Fbm8(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡌࡋࡔࡠࡔࡈࡇࡆࡖࡔࡄࡊࡄ࠶ࡤ࡚ࡏࡌࡇࡑ࠱࠷ࡴࡤࠨฏ"))
	return XV3cU4Ez5kgM0YtHNedhuRGB879lpT
def hmQAKxRf074ql9XNz6UpkHsnc(url):
	Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(r3rnfZ7cdxzNFebIRaLSG6B,url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,AbqCJZdWQP9j(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡒࡂࡄࡏࡓࡆࡊࡓ࠮࠳ࡶࡸࠬฐ"))
	items = dEyT9xhGjolYzLCH7460w3.findall(CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠪࡧࡴࡲ࡯ࡳ࠿ࠥࡶࡪࡪࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨฑ"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if items: return iiy37aKq0pCEIOwfcTh61xb4U,[iiy37aKq0pCEIOwfcTh61xb4U],[ items[FGTfwsjNrB8DvKSZhLIQAb1JnO] ]
	else: return TlGXWLYsV1z(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡁࡓࡃࡅࡐࡔࡇࡄࡔࠩฒ"),[],[]
def BCpdKNMx4t(url):
	return iiy37aKq0pCEIOwfcTh61xb4U,[iiy37aKq0pCEIOwfcTh61xb4U],[url]
def ddKeEc2pHv3fhoikzByNOJqAS(url):
	Zw4M5DUStdE6xp7GI = url.split(TlGXWLYsV1z(u"ࠬ࠵ࠧณ"))
	tI3Zos4xGuS60BDPACanJTE = zmcGfOdvAjsELeJlP(u"࠭࠯ࠨด").join(Zw4M5DUStdE6xp7GI[FGTfwsjNrB8DvKSZhLIQAb1JnO:iiCWLaJREureAlOkv])
	Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(r3rnfZ7cdxzNFebIRaLSG6B,url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡞ࡎࡖࡐ࡚ࡕࡋࡅࡗࡋ࠭࠲ࡵࡷࠫต"))
	items = dEyT9xhGjolYzLCH7460w3.findall(uuExaKGL7UONtevRd(u"ࠨࡦ࡯ࡦࡺࡺࡴࡰࡰ࡟ࠫࡡ࠯࠮ࡩࡴࡨࡪࠥࡃࠠࠣࠪ࠱࠮ࡄ࠯ࠢࠡ࡞࠮ࠤࡡ࠮ࠨ࠯ࠬࡂ࠭ࠥࡢࠥࠡࠪ࠱࠮ࡄ࠯ࠠ࡝࠭ࠣࠬ࠳࠰࠿ࠪࠢ࡟ࠩࠥ࠮࠮ࠫࡁࠬࡠ࠮ࠦ࡜ࠬࠢࠥࠬ࠳࠰࠿ࠪࠤࠪถ"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if items:
		NZpmhLBscQeR,yaABUVqiE3nk8se,xspSwKH1XmgLhv,DGtQhbE3BHS0CW1U6o5MROKYj4u,MMRyrqL5oJ7ECj0viQm,wre8BapWUA7OPQhG6XxmfFo = items[FGTfwsjNrB8DvKSZhLIQAb1JnO]
		xYkDXe5UjvETygJNLrRQ96mtp8BKGW = int(yaABUVqiE3nk8se) % int(xspSwKH1XmgLhv) + int(DGtQhbE3BHS0CW1U6o5MROKYj4u) % int(MMRyrqL5oJ7ECj0viQm)
		url = tI3Zos4xGuS60BDPACanJTE + NZpmhLBscQeR + str(xYkDXe5UjvETygJNLrRQ96mtp8BKGW) + wre8BapWUA7OPQhG6XxmfFo
		return iiy37aKq0pCEIOwfcTh61xb4U,[iiy37aKq0pCEIOwfcTh61xb4U],[url]
	else: return ZchUJdM93pTA7zG5(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤ࡟ࡏࡐࡑ࡛ࡖࡌࡆࡘࡅࠨท"),[],[]
def SD1gIurNBUWjq(url):
	id = url.split(uuExaKGL7UONtevRd(u"ࠪ࠳ࠬธ"))[-YYJQyRskpX8jv]
	headers = { Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪน") : vODxLKW5Ql6r4Fbm8(u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧࠫบ") }
	Si4j3bXGLeno0zfxlm9ZOcy = { FRYcH4KL7e9gv5pEB(u"ࠨࡩࡥࠤป"):id , AbqCJZdWQP9j(u"ࠢࡰࡲࠥผ"):Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠣࡦࡲࡻࡳࡲ࡯ࡢࡦ࠵ࠦฝ") }
	lHDuLVCy8kvqB6Rxh4Gs5K = MMCJxEfv0WUek(r3rnfZ7cdxzNFebIRaLSG6B,ZchUJdM93pTA7zG5(u"ࠩࡓࡓࡘ࡚ࠧพ"), url, Si4j3bXGLeno0zfxlm9ZOcy, headers, iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡍࡑ࠶ࡘࡔࡑࡕࡁࡅ࠯࠴ࡷࡹ࠭ฟ"))
	if tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭ภ") in list(lHDuLVCy8kvqB6Rxh4Gs5K.headers.keys()): fCXyTlcmF4WuetVork = lHDuLVCy8kvqB6Rxh4Gs5K.headers[uuExaKGL7UONtevRd(u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧม")]
	else: fCXyTlcmF4WuetVork = url
	if fCXyTlcmF4WuetVork: return iiy37aKq0pCEIOwfcTh61xb4U,[iiy37aKq0pCEIOwfcTh61xb4U],[fCXyTlcmF4WuetVork]
	else: return TlGXWLYsV1z(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡏࡓ࠸࡚ࡖࡌࡐࡃࡇࠫย"),[],[]
def g2gYcCOpUuB(url):
	Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(r3rnfZ7cdxzNFebIRaLSG6B,url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,AbqCJZdWQP9j(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡛ࡎࡔࡔࡗࡎࡌ࡚ࡊ࠳࠱ࡴࡶࠪร"))
	items = dEyT9xhGjolYzLCH7460w3.findall(EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠨ࡯ࡳ࠸࠿ࠦ࡜࡜࡞ࠪࠬ࠳࠰࠿ࠪ࡞ࠪࠫฤ"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if items: return iiy37aKq0pCEIOwfcTh61xb4U,[iiy37aKq0pCEIOwfcTh61xb4U],[ items[FGTfwsjNrB8DvKSZhLIQAb1JnO] ]
	else: return tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤ࡜ࡏࡎࡕࡘࡏࡍ࡛ࡋࠧล"),[],[]
def dzNDMaOYqjBUZpTCWuecvk8V301o(url):
	Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(r3rnfZ7cdxzNFebIRaLSG6B,url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡓࡅࡋࡍ࡛ࡋ࠭࠲ࡵࡷࠫฦ"))
	items = dEyT9xhGjolYzLCH7460w3.findall(hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠫࡸࡵࡵࡳࡥࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩว"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if items:
		url = url = CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡࡳࡥ࡫࡭ࡻ࡫࠮ࡰࡴࡪࠫศ") + items[FGTfwsjNrB8DvKSZhLIQAb1JnO]
		return iiy37aKq0pCEIOwfcTh61xb4U,[iiy37aKq0pCEIOwfcTh61xb4U],[ url ]
	else: return uuExaKGL7UONtevRd(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡃࡕࡇࡍࡏࡖࡆࠩษ"),[],[]
def QKIEOYzfbPJoDGV(url):
	Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(r3rnfZ7cdxzNFebIRaLSG6B,url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡉࡘ࡚ࡒࡆࡃࡐ࠱࠶ࡹࡴࠨส"))
	items = dEyT9xhGjolYzLCH7460w3.findall(MgP8OjoaiWQEVG59(u"ࠨࡸ࡬ࡨࡪࡵࠠࡱࡴࡨࡰࡴࡧࡤ࠯ࠬࡂࡷࡷࡩ࠽࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨห"),Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if items: return iiy37aKq0pCEIOwfcTh61xb4U,[iiy37aKq0pCEIOwfcTh61xb4U],[ items[FGTfwsjNrB8DvKSZhLIQAb1JnO] ]
	else: return jXE2YHkswT8y(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡊ࡙ࡔࡓࡇࡄࡑࠬฬ"),[],[]
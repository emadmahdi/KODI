# -*- coding: utf-8 -*-
from braVAkwfBN import *
sQU2GnRoMwLK8CBdfzmNr4jXyO = 'SHAHID4U'
ooQEi5O6tYsGVF8LU0TC3hgMeflBwH = '_SH4_'
JaQEtCzDXgos1cdZN = gZ4LwbKaOm[sQU2GnRoMwLK8CBdfzmNr4jXyO][0]
headers = {'User-Agent':FgJLkYac7lQxEbs(True)}
a8GCLIuWNkS = ['عروض مصارعة','الكل','افلام','javascript','مصارعة حرة']
def sHVM8YchrDjZAJ7(mode,url,text):
	if   mode==110: EA7FzO1kMZGQXDd2giB0cwLom = jihuS9LVAvTrClPapMbUEwfn8XN()
	elif mode==111: EA7FzO1kMZGQXDd2giB0cwLom = AIQeNZP4FMDw9S(url,text)
	elif mode==112: EA7FzO1kMZGQXDd2giB0cwLom = TW6Z0zqaDl(url)
	elif mode==113: EA7FzO1kMZGQXDd2giB0cwLom = YNcMvoVF5swlDBJI7PL(url,True)
	elif mode==114: EA7FzO1kMZGQXDd2giB0cwLom = chQHNdWgTSDjti8R9pJUf(url,'FULL_FILTER___'+text)
	elif mode==115: EA7FzO1kMZGQXDd2giB0cwLom = chQHNdWgTSDjti8R9pJUf(url,'DEFINED_FILTER___'+text)
	elif mode==116: EA7FzO1kMZGQXDd2giB0cwLom = YNcMvoVF5swlDBJI7PL(url,False)
	elif mode==119: EA7FzO1kMZGQXDd2giB0cwLom = mUhJtHB9nw(text)
	else: EA7FzO1kMZGQXDd2giB0cwLom = False
	return EA7FzO1kMZGQXDd2giB0cwLom
def jihuS9LVAvTrClPapMbUEwfn8XN():
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',JaQEtCzDXgos1cdZN,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'SHAHID4U-MENU-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	ffBG4TaQU8lVF26R = F82MvyX4ThI6sbnA3efDoVS(oCJ8TdG2LwSIVcbaUnhB.url,'url')
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'بحث في الموقع',iiy37aKq0pCEIOwfcTh61xb4U,119,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'_REMEMBERRESULTS_')
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'فلتر محدد',ffBG4TaQU8lVF26R,115)
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'فلتر كامل',ffBG4TaQU8lVF26R,114)
	bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'المميزة',ffBG4TaQU8lVF26R,111,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'featured')
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('simple-filter(.*?)adv-filter',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if not UUIohmv597bO83YCLgWS:
		bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'موقع شاهد فوريو','البرنامج لم يستطيع إيجاد عنوان الموقع أو تصميم الموقع تغير')
		return
	else:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('location = \'(.*?)\'.*?src="(.*?)".*?<h3>(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for filter,C0dvhEbPWYlUtimM3x,title in items:
			url = ffBG4TaQU8lVF26R+filter
			bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,url,111,C0dvhEbPWYlUtimM3x,iiy37aKq0pCEIOwfcTh61xb4U,filter)
		bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('class="dropdown"(.*?)<script>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?>(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title in items:
			title = title.replace(OTlVEGYPSxsNaBdXUucqA3,iiy37aKq0pCEIOwfcTh61xb4U).replace(Mge0HhFk9Ic6sm5VR,iiy37aKq0pCEIOwfcTh61xb4U).strip(iFBmE2MUIpSu34wsd7Rf6z)
			if title in a8GCLIuWNkS: continue
			if 'http' not in fCXyTlcmF4WuetVork: fCXyTlcmF4WuetVork = ffBG4TaQU8lVF26R+fCXyTlcmF4WuetVork
			if 'netflix' in fCXyTlcmF4WuetVork: title = 'نيتفلكس'
			bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,111)
	return Vxz6OndPIX4g2kaRp7
def AIQeNZP4FMDw9S(url,Ax2k5gsahJCBE30DfntcyXL7P=iiy37aKq0pCEIOwfcTh61xb4U,oCJ8TdG2LwSIVcbaUnhB=iiy37aKq0pCEIOwfcTh61xb4U):
	if not oCJ8TdG2LwSIVcbaUnhB: oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'SHAHID4U-TITLES-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	UUIohmv597bO83YCLgWS,items,u3Rztpl4VHO9GZ7jCBM65kvS = [],[],[]
	if Ax2k5gsahJCBE30DfntcyXL7P=='featured': UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('glide__slides(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	else: UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('shows-container(.*?)pagination',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if not UUIohmv597bO83YCLgWS: return
	PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
	if not items: items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?url\((.*?)\).*?"title">(.*?)</h4>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	mxXKsCgL5OoP1evURZ8SdIfpBrwu = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for fCXyTlcmF4WuetVork,C0dvhEbPWYlUtimM3x,title in items:
		if 'WWE' in title: continue
		if 'javascript' in fCXyTlcmF4WuetVork: continue
		fCXyTlcmF4WuetVork = a9I3YZjc6ySDPE4Kp(fCXyTlcmF4WuetVork).strip('/')
		title = JIY6A30UOsQboNVqCn(title)
		title = title.strip(iFBmE2MUIpSu34wsd7Rf6z)
		zN7sZyFnw5JTE8 = dEyT9xhGjolYzLCH7460w3.findall('(.*?) الحلقة \d+',title,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if '/film/' in fCXyTlcmF4WuetVork or 'فيلم' in fCXyTlcmF4WuetVork or any(aasX2cby4Vo5rTgB in title for aasX2cby4Vo5rTgB in mxXKsCgL5OoP1evURZ8SdIfpBrwu):
			bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,112,C0dvhEbPWYlUtimM3x)
		elif zN7sZyFnw5JTE8 and 'الحلقة' in title and '/list' not in url:
			title = '_MOD_' + zN7sZyFnw5JTE8[0]
			if title not in u3Rztpl4VHO9GZ7jCBM65kvS:
				bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,113,C0dvhEbPWYlUtimM3x)
				u3Rztpl4VHO9GZ7jCBM65kvS.append(title)
		elif '/actor/' in fCXyTlcmF4WuetVork:
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,111,C0dvhEbPWYlUtimM3x)
		elif '/series/' in fCXyTlcmF4WuetVork and '/list' not in url:
			fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork+'/list'
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,111,C0dvhEbPWYlUtimM3x)
		elif '/list' in url and 'حلقة' in title:
			bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,112,C0dvhEbPWYlUtimM3x)
		else: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,113,C0dvhEbPWYlUtimM3x)
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"pagination"(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		if Ax2k5gsahJCBE30DfntcyXL7P!='search': items = dEyT9xhGjolYzLCH7460w3.findall('(updateQuery).*?>(.+?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		else: items = dEyT9xhGjolYzLCH7460w3.findall('<li>.*?href="(.*?)">(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if 'page=' in url: url = url.split('page=',1)[0][:-1]
		for fCXyTlcmF4WuetVork,title in items:
			title = title.replace(OTlVEGYPSxsNaBdXUucqA3,iiy37aKq0pCEIOwfcTh61xb4U).replace(Mge0HhFk9Ic6sm5VR,iiy37aKq0pCEIOwfcTh61xb4U)
			title = title.strip(iFBmE2MUIpSu34wsd7Rf6z)
			if Ax2k5gsahJCBE30DfntcyXL7P!='search':
				if '?' in url: fCXyTlcmF4WuetVork = url+'&page='+title
				else: fCXyTlcmF4WuetVork = url+'?page='+title
			title = JIY6A30UOsQboNVqCn(title)
			if title: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'صفحة '+title,fCXyTlcmF4WuetVork,111,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,Ax2k5gsahJCBE30DfntcyXL7P)
	return
def YNcMvoVF5swlDBJI7PL(url,JJsuRbhko2VP9FdEMgnpr80D5l):
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'SHAHID4U-EPISODES-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('items d-flex(.*?)</div>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if len(UUIohmv597bO83YCLgWS)>1:
		if '/season/' in UUIohmv597bO83YCLgWS[0]: zfbAhCqkmOoZWyGpT3KUIF9anBN,f9a8L1lCJvn6pIUuP = UUIohmv597bO83YCLgWS[0],UUIohmv597bO83YCLgWS[1]
		else: zfbAhCqkmOoZWyGpT3KUIF9anBN,f9a8L1lCJvn6pIUuP = UUIohmv597bO83YCLgWS[1],UUIohmv597bO83YCLgWS[0]
	else: zfbAhCqkmOoZWyGpT3KUIF9anBN,f9a8L1lCJvn6pIUuP = UUIohmv597bO83YCLgWS[0],UUIohmv597bO83YCLgWS[0]
	for o6oXFxmE1bQC in range(2):
		if JJsuRbhko2VP9FdEMgnpr80D5l: mode,type,PPH1sQtTkDBbnlYpZfo5 = 116,'folder',zfbAhCqkmOoZWyGpT3KUIF9anBN
		else: mode,type,PPH1sQtTkDBbnlYpZfo5 = 112,'video',f9a8L1lCJvn6pIUuP
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?span.*?">(.*?)<.*?span.*?">(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if JJsuRbhko2VP9FdEMgnpr80D5l and len(items)<2:
			JJsuRbhko2VP9FdEMgnpr80D5l = False
			continue
		for fCXyTlcmF4WuetVork,YhB0TkycFJxX2V3PDHW6NiA,Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb in items:
			title = YhB0TkycFJxX2V3PDHW6NiA+iFBmE2MUIpSu34wsd7Rf6z+Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb
			bP6z3OSLp7va(type,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,mode)
		break
	if not items and '/episodes' in Vxz6OndPIX4g2kaRp7:
		zelNBksaDSFU1AQLh8Yy4ZHjG = dEyT9xhGjolYzLCH7460w3.findall('class="breadcrumb"(.*?)</div>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if zelNBksaDSFU1AQLh8Yy4ZHjG:
			PPH1sQtTkDBbnlYpZfo5 = zelNBksaDSFU1AQLh8Yy4ZHjG[0]
			P3tys0cXWbiIUKk7HQ6n89V = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)"',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
			if len(P3tys0cXWbiIUKk7HQ6n89V)>2:
				fCXyTlcmF4WuetVork = P3tys0cXWbiIUKk7HQ6n89V[2]+'list'
				AIQeNZP4FMDw9S(fCXyTlcmF4WuetVork)
	return
def TW6Z0zqaDl(url):
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(Dxc7GChQwZ4kOlKHSbL06agnB,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'SHAHID4U-PLAY-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('class="actions(.*?)</div>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if not UUIohmv597bO83YCLgWS: return
	PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
	P3tys0cXWbiIUKk7HQ6n89V = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)"',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	tFsBjIpgCO7TYqMHWuZ5oy0xQ = '/watch/' in PPH1sQtTkDBbnlYpZfo5
	download = '/download/' in PPH1sQtTkDBbnlYpZfo5
	if   tFsBjIpgCO7TYqMHWuZ5oy0xQ and not download: jdlmn8yMsSOH5C0a,xC97aIWYXhLGH = P3tys0cXWbiIUKk7HQ6n89V[0],iiy37aKq0pCEIOwfcTh61xb4U
	elif not tFsBjIpgCO7TYqMHWuZ5oy0xQ and download: jdlmn8yMsSOH5C0a,xC97aIWYXhLGH = iiy37aKq0pCEIOwfcTh61xb4U,P3tys0cXWbiIUKk7HQ6n89V[0]
	elif tFsBjIpgCO7TYqMHWuZ5oy0xQ and download: jdlmn8yMsSOH5C0a,xC97aIWYXhLGH = P3tys0cXWbiIUKk7HQ6n89V[0],P3tys0cXWbiIUKk7HQ6n89V[1]
	else: jdlmn8yMsSOH5C0a,xC97aIWYXhLGH = iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U
	duef0gb3Mi1AV5WpN8 = []
	if tFsBjIpgCO7TYqMHWuZ5oy0xQ:
		oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(Dxc7GChQwZ4kOlKHSbL06agnB,'GET',jdlmn8yMsSOH5C0a,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'SHAHID4U-PLAY-2nd')
		z0spMAOfJElv6L1K9ae = oCJ8TdG2LwSIVcbaUnhB.content
		eTov6CfDcRZVJEAq5BH = dEyT9xhGjolYzLCH7460w3.findall('let servers(.*?)player',z0spMAOfJElv6L1K9ae,dEyT9xhGjolYzLCH7460w3.DOTALL|dEyT9xhGjolYzLCH7460w3.IGNORECASE)
		if eTov6CfDcRZVJEAq5BH:
			U462wftipjCPA1hLuGsKr8koxnd = eTov6CfDcRZVJEAq5BH[0]
			lFmsiNI2UDoJBdVCQtqx4WPXb7 = dEyT9xhGjolYzLCH7460w3.findall('"name":"(.*?)".*?"url":"(.*?)"',U462wftipjCPA1hLuGsKr8koxnd,dEyT9xhGjolYzLCH7460w3.DOTALL)
			for title,fCXyTlcmF4WuetVork in lFmsiNI2UDoJBdVCQtqx4WPXb7:
				fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork.replace('\\/','/')
				fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork+'?named='+title+'__watch'
				duef0gb3Mi1AV5WpN8.append(fCXyTlcmF4WuetVork)
	if download:
		oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(Dxc7GChQwZ4kOlKHSbL06agnB,'GET',xC97aIWYXhLGH,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'SHAHID4U-PLAY-3rd')
		z0spMAOfJElv6L1K9ae = oCJ8TdG2LwSIVcbaUnhB.content
		eTov6CfDcRZVJEAq5BH = dEyT9xhGjolYzLCH7460w3.findall('"servers"(.*?)info-container',z0spMAOfJElv6L1K9ae,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if eTov6CfDcRZVJEAq5BH:
			U462wftipjCPA1hLuGsKr8koxnd = eTov6CfDcRZVJEAq5BH[0]
			lFmsiNI2UDoJBdVCQtqx4WPXb7 = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?<span>(.*?)<.*?</i>.*?<span>(.*?)<',U462wftipjCPA1hLuGsKr8koxnd,dEyT9xhGjolYzLCH7460w3.DOTALL)
			for fCXyTlcmF4WuetVork,title,pMAWqrwP80lR in lFmsiNI2UDoJBdVCQtqx4WPXb7:
				fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork+'?named='+title+'__download'+'____'+pMAWqrwP80lR
				duef0gb3Mi1AV5WpN8.append(fCXyTlcmF4WuetVork)
	import lqBJGK8hXO
	lqBJGK8hXO.ZDg1HavwueT85mcAOorC4hnS(duef0gb3Mi1AV5WpN8,sQU2GnRoMwLK8CBdfzmNr4jXyO,'video',url)
	return
def mUhJtHB9nw(search):
	search,brFQp5vmgJWdZfEkCBOlu9c,showDialogs = XkYnev3ZCA6ahO94(search)
	if not search:
		search = TTBf6S08q1NKXd5v9wa()
		if not search: return
	search = search.replace(iFBmE2MUIpSu34wsd7Rf6z,'+')
	url = JaQEtCzDXgos1cdZN+'/search?s='+search
	AIQeNZP4FMDw9S(url,'search')
	return
def Dv235GCSiTYasugHxhbPUVjdKkcprN(url):
	url = url.split('/smartemadfilter?')[0]
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(Dxc7GChQwZ4kOlKHSbL06agnB,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'SHAHID4U-GET_FILTERS_BLOCKS-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	n8nFIQBNaXD = []
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('adv-filter(.*?)shows-container',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		n8nFIQBNaXD = dEyT9xhGjolYzLCH7460w3.findall('''updateQuery\('(.*?)'.*?value.*?>(.*?)<(.*?)</select''',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		t4tvDjdhuyfVo,EaJdizIBhr3XnWGHsYxvO0S2oVyKwj,ddfSDGyqEc = zip(*n8nFIQBNaXD)
		n8nFIQBNaXD = zip(EaJdizIBhr3XnWGHsYxvO0S2oVyKwj,t4tvDjdhuyfVo,ddfSDGyqEc)
	return n8nFIQBNaXD
def T6TdxbQOnA(PPH1sQtTkDBbnlYpZfo5):
	items = dEyT9xhGjolYzLCH7460w3.findall('value="(.*?)".*?>\s*(.*?)\s*<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	return items
def GyQ7pvCNeFHiPs0U3Dqf(url):
	if '/smartemadfilter?' not in url: url = url+'/smartemadfilter?'
	UM3q9WaVXOP4ZuhCnHB5jyA = url.split('/smartemadfilter?')[0]
	VrnhdEezI7 = F82MvyX4ThI6sbnA3efDoVS(url,'url')
	url = url.replace(UM3q9WaVXOP4ZuhCnHB5jyA,VrnhdEezI7)
	url = url.replace('/smartemadfilter?','/?')
	return url
PlFdUZ6T2ceunDCGBhiqXyrWwONYx = ['quality','year','genre','category']
ooTiu86KvMCYBceUV2J9rzLP1qE = ['category','genre','year']
def chQHNdWgTSDjti8R9pJUf(url,filter):
	url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==iiy37aKq0pCEIOwfcTh61xb4U: Mhd9LWrfiF1EsASl6eP34uTp0qNGom,ovh6cXGg1qd85fn3CSJEisTlI7Yz = iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U
	else: Mhd9LWrfiF1EsASl6eP34uTp0qNGom,ovh6cXGg1qd85fn3CSJEisTlI7Yz = filter.split('___')
	if type=='DEFINED_FILTER':
		if ooTiu86KvMCYBceUV2J9rzLP1qE[0]+'=' not in Mhd9LWrfiF1EsASl6eP34uTp0qNGom: RRIscyLmNH9dq2Dio3TSr = ooTiu86KvMCYBceUV2J9rzLP1qE[0]
		for iEfNKT3velFyGth80SA4pxbCRrVD in range(len(ooTiu86KvMCYBceUV2J9rzLP1qE[0:-1])):
			if ooTiu86KvMCYBceUV2J9rzLP1qE[iEfNKT3velFyGth80SA4pxbCRrVD]+'=' in Mhd9LWrfiF1EsASl6eP34uTp0qNGom: RRIscyLmNH9dq2Dio3TSr = ooTiu86KvMCYBceUV2J9rzLP1qE[iEfNKT3velFyGth80SA4pxbCRrVD+1]
		HdFJThcNtWe3lb8n4OmaSwQ = Mhd9LWrfiF1EsASl6eP34uTp0qNGom+'&'+RRIscyLmNH9dq2Dio3TSr+'=0'
		vvlVH6JT9YDNPeSaRUkKCAwpr5uq = ovh6cXGg1qd85fn3CSJEisTlI7Yz+'&'+RRIscyLmNH9dq2Dio3TSr+'=0'
		cCZR4YdwUepABD9mQsubT8FgN = HdFJThcNtWe3lb8n4OmaSwQ.strip('&')+'___'+vvlVH6JT9YDNPeSaRUkKCAwpr5uq.strip('&')
		bPXk8KHyCUrifag = qJ8NQtuWARGjoZd9swfbH(ovh6cXGg1qd85fn3CSJEisTlI7Yz,'modified_filters')
		eCGwzSrqBmIv = url+'/smartemadfilter?'+bPXk8KHyCUrifag
	elif type=='FULL_FILTER':
		GMQ6AxE012X9 = qJ8NQtuWARGjoZd9swfbH(Mhd9LWrfiF1EsASl6eP34uTp0qNGom,'modified_values')
		GMQ6AxE012X9 = a9I3YZjc6ySDPE4Kp(GMQ6AxE012X9)
		if ovh6cXGg1qd85fn3CSJEisTlI7Yz!=iiy37aKq0pCEIOwfcTh61xb4U: ovh6cXGg1qd85fn3CSJEisTlI7Yz = qJ8NQtuWARGjoZd9swfbH(ovh6cXGg1qd85fn3CSJEisTlI7Yz,'modified_filters')
		if ovh6cXGg1qd85fn3CSJEisTlI7Yz==iiy37aKq0pCEIOwfcTh61xb4U: eCGwzSrqBmIv = url
		else: eCGwzSrqBmIv = url+'/smartemadfilter?'+ovh6cXGg1qd85fn3CSJEisTlI7Yz
		O5Pwg3UFyX0k9E = GyQ7pvCNeFHiPs0U3Dqf(eCGwzSrqBmIv)
		bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'أظهار قائمة الفيديو التي تم اختيارها ',O5Pwg3UFyX0k9E,111)
		bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+' [[   '+GMQ6AxE012X9+'   ]]',O5Pwg3UFyX0k9E,111)
		bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	n8nFIQBNaXD = Dv235GCSiTYasugHxhbPUVjdKkcprN(url)
	dict = {}
	for name,cWhMpFIbQU4D1Bi,PPH1sQtTkDBbnlYpZfo5 in n8nFIQBNaXD:
		name = name.replace('كل ',iiy37aKq0pCEIOwfcTh61xb4U)
		items = T6TdxbQOnA(PPH1sQtTkDBbnlYpZfo5)
		if '=' not in eCGwzSrqBmIv: eCGwzSrqBmIv = url
		if type=='DEFINED_FILTER':
			if RRIscyLmNH9dq2Dio3TSr!=cWhMpFIbQU4D1Bi: continue
			elif len(items)<2:
				if cWhMpFIbQU4D1Bi==ooTiu86KvMCYBceUV2J9rzLP1qE[-1]:
					O5Pwg3UFyX0k9E = GyQ7pvCNeFHiPs0U3Dqf(eCGwzSrqBmIv)
					AIQeNZP4FMDw9S(O5Pwg3UFyX0k9E)
				else: chQHNdWgTSDjti8R9pJUf(eCGwzSrqBmIv,'DEFINED_FILTER___'+cCZR4YdwUepABD9mQsubT8FgN)
				return
			else:
				if cWhMpFIbQU4D1Bi==ooTiu86KvMCYBceUV2J9rzLP1qE[-1]:
					O5Pwg3UFyX0k9E = GyQ7pvCNeFHiPs0U3Dqf(eCGwzSrqBmIv)
					bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'الجميع',O5Pwg3UFyX0k9E,111)
				else: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'الجميع',eCGwzSrqBmIv,115,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,cCZR4YdwUepABD9mQsubT8FgN)
		elif type=='FULL_FILTER':
			HdFJThcNtWe3lb8n4OmaSwQ = Mhd9LWrfiF1EsASl6eP34uTp0qNGom+'&'+cWhMpFIbQU4D1Bi+'=0'
			vvlVH6JT9YDNPeSaRUkKCAwpr5uq = ovh6cXGg1qd85fn3CSJEisTlI7Yz+'&'+cWhMpFIbQU4D1Bi+'=0'
			cCZR4YdwUepABD9mQsubT8FgN = HdFJThcNtWe3lb8n4OmaSwQ+'___'+vvlVH6JT9YDNPeSaRUkKCAwpr5uq
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'الجميع :'+name,eCGwzSrqBmIv,114,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,cCZR4YdwUepABD9mQsubT8FgN)
		dict[cWhMpFIbQU4D1Bi] = {}
		for aasX2cby4Vo5rTgB,KjsA38t0DCSmuLcaE in items:
			if aasX2cby4Vo5rTgB=='196533': KjsA38t0DCSmuLcaE = 'أفلام نيتفلكس'
			elif aasX2cby4Vo5rTgB=='196531': KjsA38t0DCSmuLcaE = 'مسلسلات نيتفلكس'
			if KjsA38t0DCSmuLcaE in a8GCLIuWNkS: continue
			dict[cWhMpFIbQU4D1Bi][aasX2cby4Vo5rTgB] = KjsA38t0DCSmuLcaE
			HdFJThcNtWe3lb8n4OmaSwQ = Mhd9LWrfiF1EsASl6eP34uTp0qNGom+'&'+cWhMpFIbQU4D1Bi+'='+KjsA38t0DCSmuLcaE
			vvlVH6JT9YDNPeSaRUkKCAwpr5uq = ovh6cXGg1qd85fn3CSJEisTlI7Yz+'&'+cWhMpFIbQU4D1Bi+'='+aasX2cby4Vo5rTgB
			kuyfTIwjRrhXUo = HdFJThcNtWe3lb8n4OmaSwQ+'___'+vvlVH6JT9YDNPeSaRUkKCAwpr5uq
			title = KjsA38t0DCSmuLcaE+' :'#+dict[cWhMpFIbQU4D1Bi]['0']
			title = KjsA38t0DCSmuLcaE+' :'+name
			if type=='FULL_FILTER': bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,url,114,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,kuyfTIwjRrhXUo)
			elif type=='DEFINED_FILTER' and ooTiu86KvMCYBceUV2J9rzLP1qE[-2]+'=' in Mhd9LWrfiF1EsASl6eP34uTp0qNGom:
				bPXk8KHyCUrifag = qJ8NQtuWARGjoZd9swfbH(vvlVH6JT9YDNPeSaRUkKCAwpr5uq,'modified_filters')
				eCGwzSrqBmIv = url+'/smartemadfilter?'+bPXk8KHyCUrifag
				O5Pwg3UFyX0k9E = GyQ7pvCNeFHiPs0U3Dqf(eCGwzSrqBmIv)
				bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,O5Pwg3UFyX0k9E,111)
			else: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,url,115,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,kuyfTIwjRrhXUo)
	return
def qJ8NQtuWARGjoZd9swfbH(HSAqBpsb2jRLvk9lx147rzY,mode):
	HSAqBpsb2jRLvk9lx147rzY = HSAqBpsb2jRLvk9lx147rzY.replace('=&','=0&')
	HSAqBpsb2jRLvk9lx147rzY = HSAqBpsb2jRLvk9lx147rzY.strip('&')
	x8UiIH3WCTEpe = {}
	if '=' in HSAqBpsb2jRLvk9lx147rzY:
		items = HSAqBpsb2jRLvk9lx147rzY.split('&')
		for YXD9KNfjCaLwkcrvJxldn7I in items:
			xYkDXe5UjvETygJNLrRQ96mtp8BKGW,aasX2cby4Vo5rTgB = YXD9KNfjCaLwkcrvJxldn7I.split('=')
			x8UiIH3WCTEpe[xYkDXe5UjvETygJNLrRQ96mtp8BKGW] = aasX2cby4Vo5rTgB
	QAvGYocVXgzh9 = iiy37aKq0pCEIOwfcTh61xb4U
	for key in PlFdUZ6T2ceunDCGBhiqXyrWwONYx:
		if key in list(x8UiIH3WCTEpe.keys()): aasX2cby4Vo5rTgB = x8UiIH3WCTEpe[key]
		else: aasX2cby4Vo5rTgB = '0'
		if '%' not in aasX2cby4Vo5rTgB: aasX2cby4Vo5rTgB = YqdaDIig21wBTWJeUHbc(aasX2cby4Vo5rTgB)
		if mode=='modified_values' and aasX2cby4Vo5rTgB!='0': QAvGYocVXgzh9 = QAvGYocVXgzh9+' + '+aasX2cby4Vo5rTgB
		elif mode=='modified_filters' and aasX2cby4Vo5rTgB!='0': QAvGYocVXgzh9 = QAvGYocVXgzh9+'&'+key+'='+aasX2cby4Vo5rTgB
		elif mode=='all': QAvGYocVXgzh9 = QAvGYocVXgzh9+'&'+key+'='+aasX2cby4Vo5rTgB
	QAvGYocVXgzh9 = QAvGYocVXgzh9.strip(' + ')
	QAvGYocVXgzh9 = QAvGYocVXgzh9.strip('&')
	QAvGYocVXgzh9 = QAvGYocVXgzh9.replace('=0','=')
	return QAvGYocVXgzh9
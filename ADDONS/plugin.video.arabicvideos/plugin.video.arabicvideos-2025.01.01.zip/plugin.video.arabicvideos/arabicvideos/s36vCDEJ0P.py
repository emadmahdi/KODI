# -*- coding: utf-8 -*-
from braVAkwfBN import *
sQU2GnRoMwLK8CBdfzmNr4jXyO = 'EGYBESTVIP'
ooQEi5O6tYsGVF8LU0TC3hgMeflBwH = '_EGV_'
JaQEtCzDXgos1cdZN = gZ4LwbKaOm[sQU2GnRoMwLK8CBdfzmNr4jXyO][0]
def sHVM8YchrDjZAJ7(mode,url,zLEP9N4BOsVrXa,text):
	if   mode==220: EA7FzO1kMZGQXDd2giB0cwLom = jihuS9LVAvTrClPapMbUEwfn8XN()
	elif mode==221: EA7FzO1kMZGQXDd2giB0cwLom = AIQeNZP4FMDw9S(url,zLEP9N4BOsVrXa)
	elif mode==222: EA7FzO1kMZGQXDd2giB0cwLom = BaSyudevC40nsQHW5j7JX6RM9(url)
	elif mode==223: EA7FzO1kMZGQXDd2giB0cwLom = TW6Z0zqaDl(url)
	elif mode==224: EA7FzO1kMZGQXDd2giB0cwLom = chQHNdWgTSDjti8R9pJUf(url)
	elif mode==229: EA7FzO1kMZGQXDd2giB0cwLom = mUhJtHB9nw(text)
	else: EA7FzO1kMZGQXDd2giB0cwLom = False
	return EA7FzO1kMZGQXDd2giB0cwLom
def jihuS9LVAvTrClPapMbUEwfn8XN():
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'بحث في الموقع',iiy37aKq0pCEIOwfcTh61xb4U,229,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'_REMEMBERRESULTS_')
	bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(Dxc7GChQwZ4kOlKHSbL06agnB,'GET',JaQEtCzDXgos1cdZN,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'EGYBEST-MENU-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('class="i i-home"(.*?)</div>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)"(.*?)</a>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title in items:
			if '</i>' in title: title = title.split('</i>')[1]
			bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,222)
		bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('class="ba(.*?)<script',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('pda bdb"><strong>(.*?)<.*?href="(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for title,fCXyTlcmF4WuetVork in items:
			bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,221)
		bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?>(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title in items:
			if 'html' not in fCXyTlcmF4WuetVork: continue
			if not fCXyTlcmF4WuetVork.endswith('/'): bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,221)
	return Vxz6OndPIX4g2kaRp7
def BaSyudevC40nsQHW5j7JX6RM9(url):
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(Dxc7GChQwZ4kOlKHSbL06agnB,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'EGYBESTVIP-SUBMENU-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('class="rs_scroll"(.*?)</div>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
	items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?</i>(.*?)</a>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	for fCXyTlcmF4WuetVork,title in items:
		bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,224)
	return
def chQHNdWgTSDjti8R9pJUf(url):
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'الجميع',url,221)
	Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(Dxc7GChQwZ4kOlKHSbL06agnB,url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'EGYBESTVIP-FILTERS_MENU-1st')
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('class="sub_nav(.*?)id="movies',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".+?>(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title in items:
			if fCXyTlcmF4WuetVork=='#': name = title
			else:
				title = title + '  :  ' + 'فلتر ' + name
				bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,221)
	else: AIQeNZP4FMDw9S(url)
	return
def AIQeNZP4FMDw9S(url,zLEP9N4BOsVrXa='1'):
	if zLEP9N4BOsVrXa==iiy37aKq0pCEIOwfcTh61xb4U: zLEP9N4BOsVrXa = '1'
	if '/search' in url or '?' in url: eCGwzSrqBmIv = url + '&'
	else: eCGwzSrqBmIv = url + '?'
	eCGwzSrqBmIv = eCGwzSrqBmIv + 'page=' + zLEP9N4BOsVrXa
	Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(PNjZMS7nxa9clHusz1,eCGwzSrqBmIv,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'EGYBESTVIP-TITLES-1st')
	if '/season' in url:
		UUIohmv597bO83YCLgWS=dEyT9xhGjolYzLCH7460w3.findall('class="pda"(.*?)div',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[-1]
	elif '/series/' in url:
		UUIohmv597bO83YCLgWS=dEyT9xhGjolYzLCH7460w3.findall('class="owl-carousel owl-carousel(.*?)div',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
	else:
		UUIohmv597bO83YCLgWS=dEyT9xhGjolYzLCH7460w3.findall('id="movies(.*?)</div>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[-1]
	items = dEyT9xhGjolYzLCH7460w3.findall('<a href="(.*?)".*?src="(.*?)".*?title">(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	for fCXyTlcmF4WuetVork,C0dvhEbPWYlUtimM3x,title in items:
		title = JIY6A30UOsQboNVqCn(title)
		if '/movie/' in fCXyTlcmF4WuetVork or '/episode' in fCXyTlcmF4WuetVork:
			bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork.rstrip('/'),223,C0dvhEbPWYlUtimM3x)
		else:
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,221,C0dvhEbPWYlUtimM3x)
	if len(items)>=16:
		Je8pqw4PvVmo = ['/movies','/tv','/search','/trending']
		zLEP9N4BOsVrXa = int(zLEP9N4BOsVrXa)
		if any(aasX2cby4Vo5rTgB in url for aasX2cby4Vo5rTgB in Je8pqw4PvVmo):
			for ErNHgXYKc4Tnme9J in range(0,1000,100):
				if int(zLEP9N4BOsVrXa/100)*100==ErNHgXYKc4Tnme9J:
					for iEfNKT3velFyGth80SA4pxbCRrVD in range(ErNHgXYKc4Tnme9J,ErNHgXYKc4Tnme9J+100,10):
						if int(zLEP9N4BOsVrXa/10)*10==iEfNKT3velFyGth80SA4pxbCRrVD:
							for J9Cut4yfxIQR2zA1hZnjEH in range(iEfNKT3velFyGth80SA4pxbCRrVD,iEfNKT3velFyGth80SA4pxbCRrVD+10,1):
								if not zLEP9N4BOsVrXa==J9Cut4yfxIQR2zA1hZnjEH and J9Cut4yfxIQR2zA1hZnjEH!=0:
									bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'صفحة '+str(J9Cut4yfxIQR2zA1hZnjEH),url,221,iiy37aKq0pCEIOwfcTh61xb4U,str(J9Cut4yfxIQR2zA1hZnjEH))
						elif iEfNKT3velFyGth80SA4pxbCRrVD!=0: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'صفحة '+str(iEfNKT3velFyGth80SA4pxbCRrVD),url,221,iiy37aKq0pCEIOwfcTh61xb4U,str(iEfNKT3velFyGth80SA4pxbCRrVD))
						else: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'صفحة '+str(1),url,221,iiy37aKq0pCEIOwfcTh61xb4U,str(1))
				elif ErNHgXYKc4Tnme9J!=0: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'صفحة '+str(ErNHgXYKc4Tnme9J),url,221,iiy37aKq0pCEIOwfcTh61xb4U,str(ErNHgXYKc4Tnme9J))
				else: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'صفحة '+str(1),url,221)
	return
def TW6Z0zqaDl(url):
	A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = [],[]
	Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(Dxc7GChQwZ4kOlKHSbL06agnB,url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'EGYBESTVIP-PLAY-1st')
	UAhMnV3r89cWy7X1D05GBCwTqOP4p = dEyT9xhGjolYzLCH7460w3.findall('<td>التصنيف</td>.*?">(.*?)<',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UAhMnV3r89cWy7X1D05GBCwTqOP4p and IUF8hYKEGLmHDtXbuWNvnJ(sQU2GnRoMwLK8CBdfzmNr4jXyO,url,UAhMnV3r89cWy7X1D05GBCwTqOP4p): return
	F5HaRJTqK7Situg2jpkOc,mnRxoUeDcA6HVZKizvwBu3LO8FS9PN = iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U
	MN5xDE2kFvtreUPCZjKqX,AQdhtvcGTFXWwuOKNYSy = Vxz6OndPIX4g2kaRp7,Vxz6OndPIX4g2kaRp7
	SkoOWKE3dc6lUuAZG94reRbCajV2wt = dEyT9xhGjolYzLCH7460w3.findall('show_dl api" href="(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if SkoOWKE3dc6lUuAZG94reRbCajV2wt:
		for fCXyTlcmF4WuetVork in SkoOWKE3dc6lUuAZG94reRbCajV2wt:
			if '/watch/' in fCXyTlcmF4WuetVork: F5HaRJTqK7Situg2jpkOc = fCXyTlcmF4WuetVork
			elif '/download/' in fCXyTlcmF4WuetVork: mnRxoUeDcA6HVZKizvwBu3LO8FS9PN = fCXyTlcmF4WuetVork
		if F5HaRJTqK7Situg2jpkOc!=iiy37aKq0pCEIOwfcTh61xb4U: MN5xDE2kFvtreUPCZjKqX = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(Dxc7GChQwZ4kOlKHSbL06agnB,F5HaRJTqK7Situg2jpkOc,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'EGYBESTVIP-PLAY-2nd')
		if mnRxoUeDcA6HVZKizvwBu3LO8FS9PN!=iiy37aKq0pCEIOwfcTh61xb4U: AQdhtvcGTFXWwuOKNYSy = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(Dxc7GChQwZ4kOlKHSbL06agnB,mnRxoUeDcA6HVZKizvwBu3LO8FS9PN,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'EGYBESTVIP-PLAY-3rd')
	AjYnX2cBSE = dEyT9xhGjolYzLCH7460w3.findall('id="video".*?data-src="(.*?)"',MN5xDE2kFvtreUPCZjKqX,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if AjYnX2cBSE:
		eCGwzSrqBmIv = AjYnX2cBSE[0]
		if eCGwzSrqBmIv!=iiy37aKq0pCEIOwfcTh61xb4U and 'uploaded.egybest.download' in eCGwzSrqBmIv and '/?id=_' not in eCGwzSrqBmIv:
			z0spMAOfJElv6L1K9ae = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(Dxc7GChQwZ4kOlKHSbL06agnB,eCGwzSrqBmIv,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'EGYBESTVIP-PLAY-4th')
			hhfk7ByLsN8QmKpGCj0RSqEDxP2Orc = dEyT9xhGjolYzLCH7460w3.findall('source src="(.*?)" title="(.*?)"',z0spMAOfJElv6L1K9ae,dEyT9xhGjolYzLCH7460w3.DOTALL)
			if hhfk7ByLsN8QmKpGCj0RSqEDxP2Orc:
				for fCXyTlcmF4WuetVork,pMAWqrwP80lR in hhfk7ByLsN8QmKpGCj0RSqEDxP2Orc:
					duef0gb3Mi1AV5WpN8.append(fCXyTlcmF4WuetVork+'?named=ed.egybest.do__watch__mp4__'+pMAWqrwP80lR)
			else:
				Zw4M5DUStdE6xp7GI = eCGwzSrqBmIv.split('/')[2]
				duef0gb3Mi1AV5WpN8.append(eCGwzSrqBmIv+'?named='+Zw4M5DUStdE6xp7GI+'__watch')
		elif eCGwzSrqBmIv!=iiy37aKq0pCEIOwfcTh61xb4U:
			Zw4M5DUStdE6xp7GI = eCGwzSrqBmIv.split('/')[2]
			duef0gb3Mi1AV5WpN8.append(eCGwzSrqBmIv+'?named='+Zw4M5DUStdE6xp7GI+'__watch')
	yd12GtsPnAB3W0w6 = dEyT9xhGjolYzLCH7460w3.findall('<table class="dls_table(.*?)</table>',AQdhtvcGTFXWwuOKNYSy,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if yd12GtsPnAB3W0w6:
		yd12GtsPnAB3W0w6 = yd12GtsPnAB3W0w6[0]
		ynxeAlJGKjP8R61M = dEyT9xhGjolYzLCH7460w3.findall('<td>.*?<td>(.*?)<.*?href="(.*?)"',yd12GtsPnAB3W0w6,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if ynxeAlJGKjP8R61M:
			for pMAWqrwP80lR,fCXyTlcmF4WuetVork in ynxeAlJGKjP8R61M:
				if 'myegyvip' not in fCXyTlcmF4WuetVork: continue
				if fCXyTlcmF4WuetVork.count('/')>=2:
					Zw4M5DUStdE6xp7GI = fCXyTlcmF4WuetVork.split('/')[2]
					duef0gb3Mi1AV5WpN8.append(fCXyTlcmF4WuetVork+'?named='+Zw4M5DUStdE6xp7GI+'__download__mp4__'+pMAWqrwP80lR)
	nFrfKgIy7dlN2HDCOR5AQJiL9X4pT = []
	for fCXyTlcmF4WuetVork in duef0gb3Mi1AV5WpN8:
		nFrfKgIy7dlN2HDCOR5AQJiL9X4pT.append(fCXyTlcmF4WuetVork)
	import lqBJGK8hXO
	lqBJGK8hXO.ZDg1HavwueT85mcAOorC4hnS(nFrfKgIy7dlN2HDCOR5AQJiL9X4pT,sQU2GnRoMwLK8CBdfzmNr4jXyO,'video',url)
	return
def mUhJtHB9nw(search):
	search,brFQp5vmgJWdZfEkCBOlu9c,showDialogs = XkYnev3ZCA6ahO94(search)
	if search==iiy37aKq0pCEIOwfcTh61xb4U: search = TTBf6S08q1NKXd5v9wa()
	if search==iiy37aKq0pCEIOwfcTh61xb4U: return
	VVOtdjT9AF4Wk3GECqHL = search.replace(iFBmE2MUIpSu34wsd7Rf6z,'+')
	Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(r3rnfZ7cdxzNFebIRaLSG6B,JaQEtCzDXgos1cdZN,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'EGYBESTVIP-SEARCH-1st')
	XV3cU4Ez5kgM0YtHNedhuRGB879lpT = dEyT9xhGjolYzLCH7460w3.findall('name="_token" value="(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if XV3cU4Ez5kgM0YtHNedhuRGB879lpT:
		url = JaQEtCzDXgos1cdZN+'/search?_token='+XV3cU4Ez5kgM0YtHNedhuRGB879lpT[0]+'&q='+VVOtdjT9AF4Wk3GECqHL
		AIQeNZP4FMDw9S(url)
	return
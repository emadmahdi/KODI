# -*- coding: utf-8 -*-
from braVAkwfBN import *
sQU2GnRoMwLK8CBdfzmNr4jXyO = 'YOUTUBE'
ooQEi5O6tYsGVF8LU0TC3hgMeflBwH = '_YUT_'
JaQEtCzDXgos1cdZN = gZ4LwbKaOm[sQU2GnRoMwLK8CBdfzmNr4jXyO][0]
jEw7nlMP2z0r = 0
def sHVM8YchrDjZAJ7(mode,url,text,type,zLEP9N4BOsVrXa,name,L95mrowGgdsD):
	if	 mode==140: EA7FzO1kMZGQXDd2giB0cwLom = jihuS9LVAvTrClPapMbUEwfn8XN()
	elif mode==141: EA7FzO1kMZGQXDd2giB0cwLom = yE9TsawrV56diYh1DMKvNkXpHAIo(url,name,L95mrowGgdsD)
	elif mode==143: EA7FzO1kMZGQXDd2giB0cwLom = TW6Z0zqaDl(url,type)
	elif mode==144: EA7FzO1kMZGQXDd2giB0cwLom = AIQeNZP4FMDw9S(url,zLEP9N4BOsVrXa,text)
	elif mode==145: EA7FzO1kMZGQXDd2giB0cwLom = M9Mbdz04yi2N(url,zLEP9N4BOsVrXa)
	elif mode==147: EA7FzO1kMZGQXDd2giB0cwLom = hW2PIzO05DaxKLRn()
	elif mode==148: EA7FzO1kMZGQXDd2giB0cwLom = tPVxb8XEIiJgkhZ1l()
	elif mode==149: EA7FzO1kMZGQXDd2giB0cwLom = mUhJtHB9nw(text)
	else: EA7FzO1kMZGQXDd2giB0cwLom = False
	return EA7FzO1kMZGQXDd2giB0cwLom
def jihuS9LVAvTrClPapMbUEwfn8XN():
	if 0:
		bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'قائمة 1',JaQEtCzDXgos1cdZN+'/playlist?list=PLDJPKWWTSFaaGNjpDcPUsWZJVePmAYk_E&pp=iAQB',144)
		bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'قائمة 2',JaQEtCzDXgos1cdZN+'/playlist?list=PLAj5Gs8FH8ZnUbF0RV-7G3BoqIyZA4uSA',144)
		bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'شخص',JaQEtCzDXgos1cdZN+'/user/TCNofficial',144)
		bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'موقع',JaQEtCzDXgos1cdZN+'/channel/UCq59aGNsq9bbhwVTq1Utvgw',144)
		bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'حساب',JaQEtCzDXgos1cdZN+'/@TheSocialCTV',144)
		bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'العاب',JaQEtCzDXgos1cdZN+'/gaming',144)
		bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'افلام',JaQEtCzDXgos1cdZN+'/feed/storefront',144)
		bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'مختارات',JaQEtCzDXgos1cdZN+'/feed/guide_builder',144)
		bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'قصيرة',JaQEtCzDXgos1cdZN+'/shorts',144,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'_REMEMBERRESULTS_')
		bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'تصفح',JaQEtCzDXgos1cdZN+'/youtubei/v1/guide?key=',144)
		bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'رئيسية',JaQEtCzDXgos1cdZN+iiy37aKq0pCEIOwfcTh61xb4U,144)
		bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'رائج',JaQEtCzDXgos1cdZN+'/feed/trending?bp=',144)
		bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'بحث في الموقع',iiy37aKq0pCEIOwfcTh61xb4U,149,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'_REMEMBERRESULTS_')
	bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'الرائجة',JaQEtCzDXgos1cdZN+'/feed/trending',144)
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'التصفح',JaQEtCzDXgos1cdZN+'/youtubei/v1/guide?key=',144)
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'القصيرة',JaQEtCzDXgos1cdZN+'/shorts',144,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'_REMEMBERRESULTS_')
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'مختارات يوتيوب',JaQEtCzDXgos1cdZN+'/feed/guide_builder',144)
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'مختارات البرنامج',iiy37aKq0pCEIOwfcTh61xb4U,290)
	bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'بحث: قنوات عربية',iiy37aKq0pCEIOwfcTh61xb4U,147)
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'بحث: قنوات أجنبية',iiy37aKq0pCEIOwfcTh61xb4U,148)
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'بحث: افلام عربية',JaQEtCzDXgos1cdZN+'/results?search_query=فيلم',144)
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'بحث: افلام اجنبية',JaQEtCzDXgos1cdZN+'/results?search_query=movie',144)
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'بحث: مسرحيات عربية',JaQEtCzDXgos1cdZN+'/results?search_query=مسرحية',144)
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'بحث: مسلسلات عربية',JaQEtCzDXgos1cdZN+'/results?search_query=مسلسل&sp=EgIQAw==',144)
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'بحث: مسلسلات اجنبية',JaQEtCzDXgos1cdZN+'/results?search_query=series&sp=EgIQAw==',144)
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'بحث: مسلسلات كارتون',JaQEtCzDXgos1cdZN+'/results?search_query=كارتون&sp=EgIQAw==',144)
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'بحث: خطبة المرجعية',JaQEtCzDXgos1cdZN+'/results?search_query=قناة+كربلاء+الفضائية+خطبة+الجمعة&sp=CAISAhAB',144)
	return
def yE9TsawrV56diYh1DMKvNkXpHAIo(url,name,L95mrowGgdsD):
	name = UrB3iTzS1sFnX(name)
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'CHNL:  '+name,url,144,L95mrowGgdsD)
	return
def hW2PIzO05DaxKLRn():
	AIQeNZP4FMDw9S(JaQEtCzDXgos1cdZN+'/results?search_query=قناة+بث&sp=EgJAAQ==')
	return
def tPVxb8XEIiJgkhZ1l():
	AIQeNZP4FMDw9S(JaQEtCzDXgos1cdZN+'/results?search_query=tv&sp=EgJAAQ==')
	return
def TW6Z0zqaDl(url,type):
	url = url.split('&',1)[0]
	import lqBJGK8hXO
	lqBJGK8hXO.ZDg1HavwueT85mcAOorC4hnS([url],sQU2GnRoMwLK8CBdfzmNr4jXyO,type,url)
	return
def JozMevlXRFGhbQu3HasWnAZ2(sqzYKBjtT21GCfI5rOkhNLQ8Jv,url,bsqXJ3iaf2dop5):
	level,zYP6nLBOkx0KWE1MeVX3,jOuAatGEMb9Yc,QDwx9jgPkBZMU5b8OWzoLEIcHfqhe = bsqXJ3iaf2dop5.split('::')
	X37n8hjQLpHTGMC,FVavAeJklBt3HrRqzhndW7cI4U = [],[]
	if '/youtubei/v1/browse' in url: X37n8hjQLpHTGMC.append("yccc['onResponseReceivedActions']")
	if '/youtubei/v1/search' in url: X37n8hjQLpHTGMC.append("yccc['onResponseReceivedCommands']")
	X37n8hjQLpHTGMC.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs'][0]['tabRenderer']['content']['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['playlistVideoListRenderer']['contents']")
	if level=='1': X37n8hjQLpHTGMC.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs'][0]['tabRenderer']['content']['richGridRenderer']['header']['feedFilterChipBarRenderer']['contents']")
	X37n8hjQLpHTGMC.append("yccc['contents']['twoColumnWatchNextResults']['playlist']['playlist']['contents']")
	X37n8hjQLpHTGMC.append("yccc['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['contents']")
	X37n8hjQLpHTGMC.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs']")
	X37n8hjQLpHTGMC.append("yccc['entries']")
	X37n8hjQLpHTGMC.append("yccc['items'][3]['guideSectionRenderer']['items']")
	ooP2xU40ZcFv,TLMIRmzrAGYUiVS47vaZB,EyhFAmlxnWjH9O = s34hMqLSzDWt1IZkoC6ja7pVH(sqzYKBjtT21GCfI5rOkhNLQ8Jv,iiy37aKq0pCEIOwfcTh61xb4U,X37n8hjQLpHTGMC)
	if level=='1' and ooP2xU40ZcFv:
		if len(TLMIRmzrAGYUiVS47vaZB)>1 and 'search_query' not in url:
			for CuMtvmpi3YGXVnq1 in range(len(TLMIRmzrAGYUiVS47vaZB)):
				zYP6nLBOkx0KWE1MeVX3 = str(CuMtvmpi3YGXVnq1)
				X37n8hjQLpHTGMC = []
				X37n8hjQLpHTGMC.append("yddd["+zYP6nLBOkx0KWE1MeVX3+"]['reloadContinuationItemsCommand']['continuationItems']")
				X37n8hjQLpHTGMC.append("yddd["+zYP6nLBOkx0KWE1MeVX3+"]['command']")
				X37n8hjQLpHTGMC.append("yddd["+zYP6nLBOkx0KWE1MeVX3+"]")
				M5qyIg2dZlm6FxH4tTPV79okNu0bCG,YXD9KNfjCaLwkcrvJxldn7I,MGUpOVcyHm3P9xC8ij76QlfY = s34hMqLSzDWt1IZkoC6ja7pVH(TLMIRmzrAGYUiVS47vaZB,iiy37aKq0pCEIOwfcTh61xb4U,X37n8hjQLpHTGMC)
				if M5qyIg2dZlm6FxH4tTPV79okNu0bCG: FVavAeJklBt3HrRqzhndW7cI4U.append([YXD9KNfjCaLwkcrvJxldn7I,url,'2::'+zYP6nLBOkx0KWE1MeVX3+'::0::0'])
			X37n8hjQLpHTGMC.append("yccc['continuationEndpoint']")
			M5qyIg2dZlm6FxH4tTPV79okNu0bCG,YXD9KNfjCaLwkcrvJxldn7I,MGUpOVcyHm3P9xC8ij76QlfY = s34hMqLSzDWt1IZkoC6ja7pVH(sqzYKBjtT21GCfI5rOkhNLQ8Jv,iiy37aKq0pCEIOwfcTh61xb4U,X37n8hjQLpHTGMC)
			if M5qyIg2dZlm6FxH4tTPV79okNu0bCG and FVavAeJklBt3HrRqzhndW7cI4U and 'continuationCommand' in list(YXD9KNfjCaLwkcrvJxldn7I.keys()):
				fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN+'/my_main_page_shorts_link'
				FVavAeJklBt3HrRqzhndW7cI4U.append([YXD9KNfjCaLwkcrvJxldn7I,fCXyTlcmF4WuetVork,'1::0::0::0'])
	return TLMIRmzrAGYUiVS47vaZB,ooP2xU40ZcFv,FVavAeJklBt3HrRqzhndW7cI4U,EyhFAmlxnWjH9O
def tw5SsEDHMbOGT4jK2V6Ba(sqzYKBjtT21GCfI5rOkhNLQ8Jv,TLMIRmzrAGYUiVS47vaZB,url,bsqXJ3iaf2dop5):
	level,zYP6nLBOkx0KWE1MeVX3,jOuAatGEMb9Yc,QDwx9jgPkBZMU5b8OWzoLEIcHfqhe = bsqXJ3iaf2dop5.split('::')
	X37n8hjQLpHTGMC,aabWZs3RnXoUmIjvp90zlNd2L1E = [],[]
	X37n8hjQLpHTGMC.append("yddd[0]['itemSectionRenderer']['contents']")
	X37n8hjQLpHTGMC.append("yddd["+zYP6nLBOkx0KWE1MeVX3+"]['reloadContinuationItemsCommand']['continuationItems']")
	X37n8hjQLpHTGMC.append("yddd[1]['reloadContinuationItemsCommand']['continuationItems']")
	if '/youtubei/v1/browse' in url: X37n8hjQLpHTGMC.append("yddd[0]['appendContinuationItemsAction']['continuationItems']")
	elif '/youtubei/v1/search' in url: X37n8hjQLpHTGMC.append("yddd[0]['appendContinuationItemsAction']['continuationItems'][0]['itemSectionRenderer']['contents']")
	X37n8hjQLpHTGMC.append("yddd["+zYP6nLBOkx0KWE1MeVX3+"]['tabRenderer']['content']['sectionListRenderer']['contents']")
	if '/videos' in url or ('/shorts' in url and '/shorts/' not in url):
		X37n8hjQLpHTGMC.append("yddd["+zYP6nLBOkx0KWE1MeVX3+"]['tabRenderer']['content']['richGridRenderer']['header']['feedFilterChipBarRenderer']['contents']")
	X37n8hjQLpHTGMC.append("yddd["+zYP6nLBOkx0KWE1MeVX3+"]['tabRenderer']['content']['richGridRenderer']['contents']")
	X37n8hjQLpHTGMC.append("yddd["+zYP6nLBOkx0KWE1MeVX3+"]['expandableTabRenderer']['content']['sectionListRenderer']['contents']")
	X37n8hjQLpHTGMC.append("yddd["+zYP6nLBOkx0KWE1MeVX3+"]['richSectionRenderer']['content']['richShelfRenderer']['contents']")
	X37n8hjQLpHTGMC.append("yddd["+zYP6nLBOkx0KWE1MeVX3+"]")
	w1Mh3mrN9dfGHl,ifSwc45mDMLgGpFEQ69NnT,D5QAR2zvebu3rqt9Vy = s34hMqLSzDWt1IZkoC6ja7pVH(TLMIRmzrAGYUiVS47vaZB,iiy37aKq0pCEIOwfcTh61xb4U,X37n8hjQLpHTGMC)
	if level=='2' and w1Mh3mrN9dfGHl:
		if len(ifSwc45mDMLgGpFEQ69NnT)>1:
			for CuMtvmpi3YGXVnq1 in range(len(ifSwc45mDMLgGpFEQ69NnT)):
				jOuAatGEMb9Yc = str(CuMtvmpi3YGXVnq1)
				X37n8hjQLpHTGMC = []
				X37n8hjQLpHTGMC.append("yeee["+jOuAatGEMb9Yc+"]['richSectionRenderer']['content']")
				X37n8hjQLpHTGMC.append("yeee["+jOuAatGEMb9Yc+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['header']")
				X37n8hjQLpHTGMC.append("yeee["+jOuAatGEMb9Yc+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
				X37n8hjQLpHTGMC.append("yeee["+jOuAatGEMb9Yc+"]['itemSectionRenderer']['contents'][0]")
				X37n8hjQLpHTGMC.append("yeee["+jOuAatGEMb9Yc+"]['richItemRenderer']['content']")
				X37n8hjQLpHTGMC.append("yeee["+jOuAatGEMb9Yc+"]")
				M5qyIg2dZlm6FxH4tTPV79okNu0bCG,YXD9KNfjCaLwkcrvJxldn7I,MGUpOVcyHm3P9xC8ij76QlfY = s34hMqLSzDWt1IZkoC6ja7pVH(ifSwc45mDMLgGpFEQ69NnT,iiy37aKq0pCEIOwfcTh61xb4U,X37n8hjQLpHTGMC)
				if M5qyIg2dZlm6FxH4tTPV79okNu0bCG: aabWZs3RnXoUmIjvp90zlNd2L1E.append([YXD9KNfjCaLwkcrvJxldn7I,url,'3::'+zYP6nLBOkx0KWE1MeVX3+'::'+jOuAatGEMb9Yc+'::0'])
			X37n8hjQLpHTGMC.append("yddd[0]['appendContinuationItemsAction']['continuationItems'][1]")
			X37n8hjQLpHTGMC.append("yddd[1]")
			M5qyIg2dZlm6FxH4tTPV79okNu0bCG,YXD9KNfjCaLwkcrvJxldn7I,MGUpOVcyHm3P9xC8ij76QlfY = s34hMqLSzDWt1IZkoC6ja7pVH(TLMIRmzrAGYUiVS47vaZB,iiy37aKq0pCEIOwfcTh61xb4U,X37n8hjQLpHTGMC)
			if M5qyIg2dZlm6FxH4tTPV79okNu0bCG and aabWZs3RnXoUmIjvp90zlNd2L1E and 'continuationItemRenderer' in list(YXD9KNfjCaLwkcrvJxldn7I.keys()):
				aabWZs3RnXoUmIjvp90zlNd2L1E.append([YXD9KNfjCaLwkcrvJxldn7I,url,'3::0::0::0'])
	return ifSwc45mDMLgGpFEQ69NnT,w1Mh3mrN9dfGHl,aabWZs3RnXoUmIjvp90zlNd2L1E,D5QAR2zvebu3rqt9Vy
def pA6NgVkEKRs2ClPohf(sqzYKBjtT21GCfI5rOkhNLQ8Jv,ifSwc45mDMLgGpFEQ69NnT,url,bsqXJ3iaf2dop5):
	level,zYP6nLBOkx0KWE1MeVX3,jOuAatGEMb9Yc,QDwx9jgPkBZMU5b8OWzoLEIcHfqhe = bsqXJ3iaf2dop5.split('::')
	X37n8hjQLpHTGMC,MGRTKSlgt1dnhrP4Y = [],[]
	X37n8hjQLpHTGMC.append("yeee["+jOuAatGEMb9Yc+"]['shelfRenderer']['content']['verticalListRenderer']['items']")
	X37n8hjQLpHTGMC.append("yeee["+jOuAatGEMb9Yc+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalMovieListRenderer']['items']")
	X37n8hjQLpHTGMC.append("yeee["+jOuAatGEMb9Yc+"]['itemSectionRenderer']['contents'][0]['reelShelfRenderer']['items']")
	X37n8hjQLpHTGMC.append("yeee["+jOuAatGEMb9Yc+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	X37n8hjQLpHTGMC.append("yeee["+jOuAatGEMb9Yc+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalListRenderer']['items']")
	X37n8hjQLpHTGMC.append("yeee["+jOuAatGEMb9Yc+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['expandedShelfContentsRenderer']['items']")
	X37n8hjQLpHTGMC.append("yeee["+jOuAatGEMb9Yc+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
	X37n8hjQLpHTGMC.append("yeee["+jOuAatGEMb9Yc+"]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	X37n8hjQLpHTGMC.append("yeee[0]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	X37n8hjQLpHTGMC.append("yeee[0]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	X37n8hjQLpHTGMC.append("yeee[0]['itemSectionRenderer']['contents'][0]['playlistVideoListRenderer']['contents']")
	X37n8hjQLpHTGMC.append("yeee["+jOuAatGEMb9Yc+"]['reelShelfRenderer']['items']")
	X37n8hjQLpHTGMC.append("yeee["+jOuAatGEMb9Yc+"]['richSectionRenderer']['content']['richShelfRenderer']['contents']")
	X37n8hjQLpHTGMC.append("yeee")
	xxAgL1HRKWqkrJeiVNMo4DyQltZ,BfuqC2LxznrRNmaUv7OW,yy2z7QZ0TuvRiA = s34hMqLSzDWt1IZkoC6ja7pVH(ifSwc45mDMLgGpFEQ69NnT,iiy37aKq0pCEIOwfcTh61xb4U,X37n8hjQLpHTGMC)
	if level=='3' and xxAgL1HRKWqkrJeiVNMo4DyQltZ:
		if len(BfuqC2LxznrRNmaUv7OW)>0:
			for CuMtvmpi3YGXVnq1 in range(len(BfuqC2LxznrRNmaUv7OW)):
				QDwx9jgPkBZMU5b8OWzoLEIcHfqhe = str(CuMtvmpi3YGXVnq1)
				X37n8hjQLpHTGMC = []
				X37n8hjQLpHTGMC.append("yfff["+QDwx9jgPkBZMU5b8OWzoLEIcHfqhe+"]['richItemRenderer']['content']")
				X37n8hjQLpHTGMC.append("yfff["+QDwx9jgPkBZMU5b8OWzoLEIcHfqhe+"]['gameCardRenderer']['game']")
				X37n8hjQLpHTGMC.append("yfff["+QDwx9jgPkBZMU5b8OWzoLEIcHfqhe+"]['itemSectionRenderer']['contents'][0]")
				X37n8hjQLpHTGMC.append("yfff["+QDwx9jgPkBZMU5b8OWzoLEIcHfqhe+"]")
				X37n8hjQLpHTGMC.append("yfff")
				M5qyIg2dZlm6FxH4tTPV79okNu0bCG,YXD9KNfjCaLwkcrvJxldn7I,MGUpOVcyHm3P9xC8ij76QlfY = s34hMqLSzDWt1IZkoC6ja7pVH(BfuqC2LxznrRNmaUv7OW,iiy37aKq0pCEIOwfcTh61xb4U,X37n8hjQLpHTGMC)
				if M5qyIg2dZlm6FxH4tTPV79okNu0bCG: MGRTKSlgt1dnhrP4Y.append([YXD9KNfjCaLwkcrvJxldn7I,url,'4::'+zYP6nLBOkx0KWE1MeVX3+'::'+jOuAatGEMb9Yc+'::'+QDwx9jgPkBZMU5b8OWzoLEIcHfqhe])
	return BfuqC2LxznrRNmaUv7OW,xxAgL1HRKWqkrJeiVNMo4DyQltZ,MGRTKSlgt1dnhrP4Y,yy2z7QZ0TuvRiA
def s34hMqLSzDWt1IZkoC6ja7pVH(NZpmhLBscQeR,yaABUVqiE3nk8se,tSrRbVYjKCp):
	sqzYKBjtT21GCfI5rOkhNLQ8Jv,yaABUVqiE3nk8se = NZpmhLBscQeR,yaABUVqiE3nk8se
	TLMIRmzrAGYUiVS47vaZB,yaABUVqiE3nk8se = NZpmhLBscQeR,yaABUVqiE3nk8se
	ifSwc45mDMLgGpFEQ69NnT,yaABUVqiE3nk8se = NZpmhLBscQeR,yaABUVqiE3nk8se
	BfuqC2LxznrRNmaUv7OW,yaABUVqiE3nk8se = NZpmhLBscQeR,yaABUVqiE3nk8se
	YXD9KNfjCaLwkcrvJxldn7I,r5VGw2CN93SfUgyd1uD7HKT = NZpmhLBscQeR,yaABUVqiE3nk8se
	count = len(tSrRbVYjKCp)
	for o6oXFxmE1bQC in range(count):
		try:
			fxKoP70b3JYhDCgsVOIe1HdLMu2v = eval(tSrRbVYjKCp[o6oXFxmE1bQC])
			return True,fxKoP70b3JYhDCgsVOIe1HdLMu2v,o6oXFxmE1bQC+1
		except: pass
	return False,iiy37aKq0pCEIOwfcTh61xb4U,0
def AIQeNZP4FMDw9S(url,bsqXJ3iaf2dop5=iiy37aKq0pCEIOwfcTh61xb4U,data=iiy37aKq0pCEIOwfcTh61xb4U):
	FVavAeJklBt3HrRqzhndW7cI4U,aabWZs3RnXoUmIjvp90zlNd2L1E,MGRTKSlgt1dnhrP4Y = [],[],[]
	if '::' not in bsqXJ3iaf2dop5: bsqXJ3iaf2dop5 = '1::0::0::0'
	level,zYP6nLBOkx0KWE1MeVX3,jOuAatGEMb9Yc,QDwx9jgPkBZMU5b8OWzoLEIcHfqhe = bsqXJ3iaf2dop5.split('::')
	if level=='4': level,zYP6nLBOkx0KWE1MeVX3,jOuAatGEMb9Yc,QDwx9jgPkBZMU5b8OWzoLEIcHfqhe = '1',zYP6nLBOkx0KWE1MeVX3,jOuAatGEMb9Yc,QDwx9jgPkBZMU5b8OWzoLEIcHfqhe
	data = data.replace('_REMEMBERRESULTS_',iiy37aKq0pCEIOwfcTh61xb4U)
	Vxz6OndPIX4g2kaRp7,sqzYKBjtT21GCfI5rOkhNLQ8Jv,EwsmJ67cCYDIlg = DZIvxozB7Y5K4qCe(url,data)
	bsqXJ3iaf2dop5 = level+'::'+zYP6nLBOkx0KWE1MeVX3+'::'+jOuAatGEMb9Yc+'::'+QDwx9jgPkBZMU5b8OWzoLEIcHfqhe
	if level in ['1','2','3']:
		TLMIRmzrAGYUiVS47vaZB,ooP2xU40ZcFv,FVavAeJklBt3HrRqzhndW7cI4U,EyhFAmlxnWjH9O = JozMevlXRFGhbQu3HasWnAZ2(sqzYKBjtT21GCfI5rOkhNLQ8Jv,url,bsqXJ3iaf2dop5)
		if not ooP2xU40ZcFv: return
		GMKDTSAOotn = len(FVavAeJklBt3HrRqzhndW7cI4U)
		if GMKDTSAOotn<2:
			if level=='1': level = '2'
			FVavAeJklBt3HrRqzhndW7cI4U = []
	bsqXJ3iaf2dop5 = level+'::'+zYP6nLBOkx0KWE1MeVX3+'::'+jOuAatGEMb9Yc+'::'+QDwx9jgPkBZMU5b8OWzoLEIcHfqhe
	if level in ['2','3']:
		ifSwc45mDMLgGpFEQ69NnT,w1Mh3mrN9dfGHl,aabWZs3RnXoUmIjvp90zlNd2L1E,D5QAR2zvebu3rqt9Vy = tw5SsEDHMbOGT4jK2V6Ba(sqzYKBjtT21GCfI5rOkhNLQ8Jv,TLMIRmzrAGYUiVS47vaZB,url,bsqXJ3iaf2dop5)
		if not w1Mh3mrN9dfGHl: return
		F0y3qCcUePuQiGDm = len(aabWZs3RnXoUmIjvp90zlNd2L1E)
		if F0y3qCcUePuQiGDm<2:
			if level=='2': level = '3'
			aabWZs3RnXoUmIjvp90zlNd2L1E = []
	bsqXJ3iaf2dop5 = level+'::'+zYP6nLBOkx0KWE1MeVX3+'::'+jOuAatGEMb9Yc+'::'+QDwx9jgPkBZMU5b8OWzoLEIcHfqhe
	if level in ['3']:
		BfuqC2LxznrRNmaUv7OW,xxAgL1HRKWqkrJeiVNMo4DyQltZ,MGRTKSlgt1dnhrP4Y,yy2z7QZ0TuvRiA = pA6NgVkEKRs2ClPohf(sqzYKBjtT21GCfI5rOkhNLQ8Jv,ifSwc45mDMLgGpFEQ69NnT,url,bsqXJ3iaf2dop5)
		if not xxAgL1HRKWqkrJeiVNMo4DyQltZ: return
		UU1TipWomO8FMx9qblDy4wNSIg = len(MGRTKSlgt1dnhrP4Y)
	for YXD9KNfjCaLwkcrvJxldn7I,url,bsqXJ3iaf2dop5 in FVavAeJklBt3HrRqzhndW7cI4U+aabWZs3RnXoUmIjvp90zlNd2L1E+MGRTKSlgt1dnhrP4Y:
		zxhLWvnMpYmajICB = xVkiyDWZwT7rctYLd3I(YXD9KNfjCaLwkcrvJxldn7I,url,bsqXJ3iaf2dop5)
	return
def xVkiyDWZwT7rctYLd3I(YXD9KNfjCaLwkcrvJxldn7I,url=iiy37aKq0pCEIOwfcTh61xb4U,bsqXJ3iaf2dop5=iiy37aKq0pCEIOwfcTh61xb4U):
	if '::' in bsqXJ3iaf2dop5: level,zYP6nLBOkx0KWE1MeVX3,jOuAatGEMb9Yc,QDwx9jgPkBZMU5b8OWzoLEIcHfqhe = bsqXJ3iaf2dop5.split('::')
	else: level,zYP6nLBOkx0KWE1MeVX3,jOuAatGEMb9Yc,QDwx9jgPkBZMU5b8OWzoLEIcHfqhe = '1','0','0','0'
	M5qyIg2dZlm6FxH4tTPV79okNu0bCG,title,fCXyTlcmF4WuetVork,C0dvhEbPWYlUtimM3x,count,Zt6GY7K2oFeAd5kTy3nJvDBpQr,Vx2Xgfpt4zJdZwrcLkHG,o8yIKr4ZnUmSzO9VtRDCQ,MvqlsCXhuxHm = QCbZHSBe0uw(YXD9KNfjCaLwkcrvJxldn7I)
	fnhjSYyKULecpm7OAT3sPv9lBQ = '/videos?' in fCXyTlcmF4WuetVork or '/streams?' in fCXyTlcmF4WuetVork or '/playlists?' in fCXyTlcmF4WuetVork
	SKeWGI7OUtjY0 = '/channels?' in fCXyTlcmF4WuetVork or '/shorts?' in fCXyTlcmF4WuetVork
	if fnhjSYyKULecpm7OAT3sPv9lBQ or SKeWGI7OUtjY0: fCXyTlcmF4WuetVork = url
	fnhjSYyKULecpm7OAT3sPv9lBQ = 'watch?v=' not in fCXyTlcmF4WuetVork and '/playlist?list=' not in fCXyTlcmF4WuetVork
	SKeWGI7OUtjY0 = '/gaming' not in fCXyTlcmF4WuetVork  and '/feed/storefront' not in fCXyTlcmF4WuetVork
	if bsqXJ3iaf2dop5[0:5]=='3::0::' and fnhjSYyKULecpm7OAT3sPv9lBQ and SKeWGI7OUtjY0: fCXyTlcmF4WuetVork = url
	if '/youtubei/v1/guide?key=' in url or '/gaming' in fCXyTlcmF4WuetVork:
		level,zYP6nLBOkx0KWE1MeVX3,jOuAatGEMb9Yc,QDwx9jgPkBZMU5b8OWzoLEIcHfqhe = '1','0','0','0'
		bsqXJ3iaf2dop5 = iiy37aKq0pCEIOwfcTh61xb4U
	EwsmJ67cCYDIlg = iiy37aKq0pCEIOwfcTh61xb4U
	if '/youtubei/v1/browse' in fCXyTlcmF4WuetVork or '/youtubei/v1/search' in fCXyTlcmF4WuetVork or '/my_main_page_shorts_link' in url:
		data = OXsckY7RzjCag9A.getSetting('av.youtube.data')
		if data.count(':::')==4:
			bbg7i0DFEuTYX8avk,key,mOKb2wxjl47Daq16,nDtmdZ0A7vjiKLPCfl4N,XV3cU4Ez5kgM0YtHNedhuRGB879lpT = data.split(':::')
			EwsmJ67cCYDIlg = bbg7i0DFEuTYX8avk+':::'+key+':::'+mOKb2wxjl47Daq16+':::'+nDtmdZ0A7vjiKLPCfl4N+':::'+MvqlsCXhuxHm
			if '/my_main_page_shorts_link' in url and not fCXyTlcmF4WuetVork: fCXyTlcmF4WuetVork = url
			else: fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork+'?key='+key
	if not title:
		global jEw7nlMP2z0r
		jEw7nlMP2z0r += 1
		title = 'فيديوهات '+str(jEw7nlMP2z0r)
		bsqXJ3iaf2dop5 = '3'+'::'+zYP6nLBOkx0KWE1MeVX3+'::'+jOuAatGEMb9Yc+'::'+QDwx9jgPkBZMU5b8OWzoLEIcHfqhe
	if not M5qyIg2dZlm6FxH4tTPV79okNu0bCG: return False
	elif 'searchPyvRenderer' in str(YXD9KNfjCaLwkcrvJxldn7I): return False
	elif '/about' in fCXyTlcmF4WuetVork: return False
	elif '/community' in fCXyTlcmF4WuetVork: return False
	elif 'continuationItemRenderer' in list(YXD9KNfjCaLwkcrvJxldn7I.keys()) or 'continuationCommand' in list(YXD9KNfjCaLwkcrvJxldn7I.keys()):
		if int(level)>1: level = str(int(level)-1)
		bsqXJ3iaf2dop5 = level+'::'+zYP6nLBOkx0KWE1MeVX3+'::'+jOuAatGEMb9Yc+'::'+QDwx9jgPkBZMU5b8OWzoLEIcHfqhe
		bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+':: '+'صفحة أخرى',fCXyTlcmF4WuetVork,144,C0dvhEbPWYlUtimM3x,bsqXJ3iaf2dop5,EwsmJ67cCYDIlg)
	elif '/search' in fCXyTlcmF4WuetVork:
		title = ':: '+title
		bsqXJ3iaf2dop5 = '3'+'::'+zYP6nLBOkx0KWE1MeVX3+'::'+jOuAatGEMb9Yc+'::'+QDwx9jgPkBZMU5b8OWzoLEIcHfqhe
		url = url.replace('/search',iiy37aKq0pCEIOwfcTh61xb4U)
		bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,url,145,iiy37aKq0pCEIOwfcTh61xb4U,bsqXJ3iaf2dop5,'_REMEMBERRESULTS_')
	elif 'search_query' in url and not fCXyTlcmF4WuetVork:
		bsqXJ3iaf2dop5 = '3'+'::'+zYP6nLBOkx0KWE1MeVX3+'::'+jOuAatGEMb9Yc+'::'+QDwx9jgPkBZMU5b8OWzoLEIcHfqhe
		title = ':: '+title
		bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,url,144,C0dvhEbPWYlUtimM3x,bsqXJ3iaf2dop5,EwsmJ67cCYDIlg)
	elif '/browse' in fCXyTlcmF4WuetVork and url==JaQEtCzDXgos1cdZN:
		title = ':: '+title
		bsqXJ3iaf2dop5 = '2::0::0::0'
		bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,144,C0dvhEbPWYlUtimM3x,bsqXJ3iaf2dop5,EwsmJ67cCYDIlg)
	elif not fCXyTlcmF4WuetVork and 'horizontalMovieListRenderer' in str(YXD9KNfjCaLwkcrvJxldn7I):
		title = ':: '+title
		bsqXJ3iaf2dop5 = '3::0::0::0'
		bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,url,144,C0dvhEbPWYlUtimM3x,bsqXJ3iaf2dop5)
	elif 'messageRenderer' in str(YXD9KNfjCaLwkcrvJxldn7I):
		bP6z3OSLp7va('link',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	elif Vx2Xgfpt4zJdZwrcLkHG:
		bP6z3OSLp7va('live',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+Vx2Xgfpt4zJdZwrcLkHG+title,fCXyTlcmF4WuetVork,143,C0dvhEbPWYlUtimM3x)
	elif '/playlist?list=' in fCXyTlcmF4WuetVork:
		fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork.replace('&playnext=1',iiy37aKq0pCEIOwfcTh61xb4U)
		bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'LIST'+count+':  '+title,fCXyTlcmF4WuetVork,144,C0dvhEbPWYlUtimM3x,bsqXJ3iaf2dop5)
	elif '/shorts/' in fCXyTlcmF4WuetVork:
		fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork.split('&list=',1)[0]
		bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,143,C0dvhEbPWYlUtimM3x,Zt6GY7K2oFeAd5kTy3nJvDBpQr)
	elif '/watch?v=' in fCXyTlcmF4WuetVork:
		if '&list=' in fCXyTlcmF4WuetVork and count:
			Q8iGErW2LKzf9I04Ng7yOVow6qA = fCXyTlcmF4WuetVork.split('&list=',1)[1]
			fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN+'/playlist?list='+Q8iGErW2LKzf9I04Ng7yOVow6qA
			bsqXJ3iaf2dop5 = '1::0::0::0'
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'LIST'+count+':  '+title,fCXyTlcmF4WuetVork,144,C0dvhEbPWYlUtimM3x,bsqXJ3iaf2dop5)
		else:
			fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork.split('&list=',1)[0]
			bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,143,C0dvhEbPWYlUtimM3x,Zt6GY7K2oFeAd5kTy3nJvDBpQr)
	elif '/channel/' in fCXyTlcmF4WuetVork or '/c/' in fCXyTlcmF4WuetVork or ('/@' in fCXyTlcmF4WuetVork and fCXyTlcmF4WuetVork.count('/')==3):
		if iELueYz3J1FmxaW7vc:
			title = title.decode(df6QpwGxuJVZr).encode('raw_unicode_escape')
			title = vvmT3DLXkhPBwIaOAo6srZpEnRVJC(title)
		bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'CHNL'+count+':  '+title,fCXyTlcmF4WuetVork,144,C0dvhEbPWYlUtimM3x,bsqXJ3iaf2dop5)
	elif '/user/' in fCXyTlcmF4WuetVork:
		bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'USER'+count+':  '+title,fCXyTlcmF4WuetVork,144,C0dvhEbPWYlUtimM3x,bsqXJ3iaf2dop5)
	else:
		if not fCXyTlcmF4WuetVork: fCXyTlcmF4WuetVork = url
		title = ':: '+title
		bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,144,C0dvhEbPWYlUtimM3x,bsqXJ3iaf2dop5,EwsmJ67cCYDIlg)
	return True
def QCbZHSBe0uw(YXD9KNfjCaLwkcrvJxldn7I):
	M5qyIg2dZlm6FxH4tTPV79okNu0bCG,title,fCXyTlcmF4WuetVork,C0dvhEbPWYlUtimM3x,count,Zt6GY7K2oFeAd5kTy3nJvDBpQr,Vx2Xgfpt4zJdZwrcLkHG,o8yIKr4ZnUmSzO9VtRDCQ,XV3cU4Ez5kgM0YtHNedhuRGB879lpT = False,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U
	if not isinstance(YXD9KNfjCaLwkcrvJxldn7I,dict): return M5qyIg2dZlm6FxH4tTPV79okNu0bCG,title,fCXyTlcmF4WuetVork,C0dvhEbPWYlUtimM3x,count,Zt6GY7K2oFeAd5kTy3nJvDBpQr,Vx2Xgfpt4zJdZwrcLkHG,o8yIKr4ZnUmSzO9VtRDCQ,XV3cU4Ez5kgM0YtHNedhuRGB879lpT
	for VVIQUfMXBwOenTlyvgDWKH0FZE in list(YXD9KNfjCaLwkcrvJxldn7I.keys()):
		r5VGw2CN93SfUgyd1uD7HKT = YXD9KNfjCaLwkcrvJxldn7I[VVIQUfMXBwOenTlyvgDWKH0FZE]
		if isinstance(r5VGw2CN93SfUgyd1uD7HKT,dict): break
	X37n8hjQLpHTGMC = []
	X37n8hjQLpHTGMC.append("yrender['header']['playlistHeaderRenderer']['title']['simpleText']")
	X37n8hjQLpHTGMC.append("yrender['header']['richListHeaderRenderer']['title']['simpleText']")
	X37n8hjQLpHTGMC.append("yrender['header']['richListHeaderRenderer']['title']")
	X37n8hjQLpHTGMC.append("yrender['headline']['simpleText']")
	X37n8hjQLpHTGMC.append("yrender['unplayableText']['simpleText']")
	X37n8hjQLpHTGMC.append("yrender['formattedTitle']['simpleText']")
	X37n8hjQLpHTGMC.append("yrender['title']['simpleText']")
	X37n8hjQLpHTGMC.append("yrender['title']['runs'][0]['text']")
	X37n8hjQLpHTGMC.append("yrender['text']['simpleText']")
	X37n8hjQLpHTGMC.append("yrender['text']['runs'][0]['text']")
	X37n8hjQLpHTGMC.append("yrender['title']['content']")
	X37n8hjQLpHTGMC.append("yrender['title']")
	X37n8hjQLpHTGMC.append("item['title']")
	X37n8hjQLpHTGMC.append("item['reelWatchEndpoint']['videoId']")
	M5qyIg2dZlm6FxH4tTPV79okNu0bCG,title,MGUpOVcyHm3P9xC8ij76QlfY = s34hMqLSzDWt1IZkoC6ja7pVH(YXD9KNfjCaLwkcrvJxldn7I,r5VGw2CN93SfUgyd1uD7HKT,X37n8hjQLpHTGMC)
	X37n8hjQLpHTGMC = []
	X37n8hjQLpHTGMC.append("yrender['title']['runs'][0]['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	X37n8hjQLpHTGMC.append("yrender['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	X37n8hjQLpHTGMC.append("yrender['continuationEndpoint']['commandMetadata']['webCommandMetadata']['apiUrl']")
	X37n8hjQLpHTGMC.append("yrender['navigationEndpoint']['commandMetadata']['webCommandMetadata']['apiUrl']")
	X37n8hjQLpHTGMC.append("yrender['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	X37n8hjQLpHTGMC.append("item['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	X37n8hjQLpHTGMC.append("item['commandMetadata']['webCommandMetadata']['url']")
	M5qyIg2dZlm6FxH4tTPV79okNu0bCG,fCXyTlcmF4WuetVork,MGUpOVcyHm3P9xC8ij76QlfY = s34hMqLSzDWt1IZkoC6ja7pVH(YXD9KNfjCaLwkcrvJxldn7I,r5VGw2CN93SfUgyd1uD7HKT,X37n8hjQLpHTGMC)
	X37n8hjQLpHTGMC = []
	X37n8hjQLpHTGMC.append("yrender['thumbnail']['thumbnails'][0]['url']")
	X37n8hjQLpHTGMC.append("yrender['thumbnails'][0]['thumbnails'][0]['url']")
	X37n8hjQLpHTGMC.append("item['reelWatchEndpoint']['thumbnail']['thumbnails'][0]['url']")
	M5qyIg2dZlm6FxH4tTPV79okNu0bCG,C0dvhEbPWYlUtimM3x,MGUpOVcyHm3P9xC8ij76QlfY = s34hMqLSzDWt1IZkoC6ja7pVH(YXD9KNfjCaLwkcrvJxldn7I,r5VGw2CN93SfUgyd1uD7HKT,X37n8hjQLpHTGMC)
	X37n8hjQLpHTGMC = []
	X37n8hjQLpHTGMC.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayBottomPanelRenderer']['text']['runs'][0]['text']")
	X37n8hjQLpHTGMC.append("yrender['videoCountShortText']['simpleText']")
	X37n8hjQLpHTGMC.append("yrender['videoCountText']['runs'][0]['text']")
	X37n8hjQLpHTGMC.append("yrender['videoCount']")
	M5qyIg2dZlm6FxH4tTPV79okNu0bCG,count,MGUpOVcyHm3P9xC8ij76QlfY = s34hMqLSzDWt1IZkoC6ja7pVH(YXD9KNfjCaLwkcrvJxldn7I,r5VGw2CN93SfUgyd1uD7HKT,X37n8hjQLpHTGMC)
	X37n8hjQLpHTGMC = []
	X37n8hjQLpHTGMC.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['runs'][0]['text']")
	X37n8hjQLpHTGMC.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['simpleText']")
	X37n8hjQLpHTGMC.append("yrender['lengthText']['simpleText']")
	X37n8hjQLpHTGMC.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['icon']['iconType']")
	X37n8hjQLpHTGMC.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['style']")
	M5qyIg2dZlm6FxH4tTPV79okNu0bCG,Zt6GY7K2oFeAd5kTy3nJvDBpQr,MGUpOVcyHm3P9xC8ij76QlfY = s34hMqLSzDWt1IZkoC6ja7pVH(YXD9KNfjCaLwkcrvJxldn7I,r5VGw2CN93SfUgyd1uD7HKT,X37n8hjQLpHTGMC)
	X37n8hjQLpHTGMC = []
	X37n8hjQLpHTGMC.append("yrender['navigationEndpoint']['continuationCommand']['token']")
	X37n8hjQLpHTGMC.append("yrender['continuationEndpoint']['continuationCommand']['token']")
	M5qyIg2dZlm6FxH4tTPV79okNu0bCG,XV3cU4Ez5kgM0YtHNedhuRGB879lpT,MGUpOVcyHm3P9xC8ij76QlfY = s34hMqLSzDWt1IZkoC6ja7pVH(YXD9KNfjCaLwkcrvJxldn7I,r5VGw2CN93SfUgyd1uD7HKT,X37n8hjQLpHTGMC)
	if 'LIVE' in Zt6GY7K2oFeAd5kTy3nJvDBpQr: Zt6GY7K2oFeAd5kTy3nJvDBpQr,Vx2Xgfpt4zJdZwrcLkHG = iiy37aKq0pCEIOwfcTh61xb4U,'LIVE:  '
	if 'مباشر' in Zt6GY7K2oFeAd5kTy3nJvDBpQr: Zt6GY7K2oFeAd5kTy3nJvDBpQr,Vx2Xgfpt4zJdZwrcLkHG = iiy37aKq0pCEIOwfcTh61xb4U,'LIVE:  '
	if 'badges' in list(r5VGw2CN93SfUgyd1uD7HKT.keys()):
		YTcW0nrZo51XDesAk3MSq2Gh = str(r5VGw2CN93SfUgyd1uD7HKT['badges'])
		if 'Free with Ads' in YTcW0nrZo51XDesAk3MSq2Gh: o8yIKr4ZnUmSzO9VtRDCQ = '$:  '
		if 'LIVE' in YTcW0nrZo51XDesAk3MSq2Gh: Vx2Xgfpt4zJdZwrcLkHG = 'LIVE:  '
		if 'Buy' in YTcW0nrZo51XDesAk3MSq2Gh or 'Rent' in YTcW0nrZo51XDesAk3MSq2Gh: o8yIKr4ZnUmSzO9VtRDCQ = '$$:  '
		if Q5V784gMylUrz3T2ZhAYFKLnE(u'مباشر') in YTcW0nrZo51XDesAk3MSq2Gh: Vx2Xgfpt4zJdZwrcLkHG = 'LIVE:  '
		if Q5V784gMylUrz3T2ZhAYFKLnE(u'شراء') in YTcW0nrZo51XDesAk3MSq2Gh: o8yIKr4ZnUmSzO9VtRDCQ = '$$:  '
		if Q5V784gMylUrz3T2ZhAYFKLnE(u'استئجار') in YTcW0nrZo51XDesAk3MSq2Gh: o8yIKr4ZnUmSzO9VtRDCQ = '$$:  '
		if Q5V784gMylUrz3T2ZhAYFKLnE(u'إعلانات') in YTcW0nrZo51XDesAk3MSq2Gh: o8yIKr4ZnUmSzO9VtRDCQ = '$:  '
	fCXyTlcmF4WuetVork = vvmT3DLXkhPBwIaOAo6srZpEnRVJC(fCXyTlcmF4WuetVork)
	if fCXyTlcmF4WuetVork and 'http' not in fCXyTlcmF4WuetVork: fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN+fCXyTlcmF4WuetVork
	C0dvhEbPWYlUtimM3x = C0dvhEbPWYlUtimM3x.split('?')[0]
	if  C0dvhEbPWYlUtimM3x and 'http' not in C0dvhEbPWYlUtimM3x: C0dvhEbPWYlUtimM3x = 'https:'+C0dvhEbPWYlUtimM3x
	title = vvmT3DLXkhPBwIaOAo6srZpEnRVJC(title)
	if o8yIKr4ZnUmSzO9VtRDCQ: title = o8yIKr4ZnUmSzO9VtRDCQ+title
	Zt6GY7K2oFeAd5kTy3nJvDBpQr = Zt6GY7K2oFeAd5kTy3nJvDBpQr.replace(',',iiy37aKq0pCEIOwfcTh61xb4U)
	count = count.replace(',',iiy37aKq0pCEIOwfcTh61xb4U)
	count = dEyT9xhGjolYzLCH7460w3.findall('\d+',count)
	if count: count = count[0]
	else: count = iiy37aKq0pCEIOwfcTh61xb4U
	return True,title,fCXyTlcmF4WuetVork,C0dvhEbPWYlUtimM3x,count,Zt6GY7K2oFeAd5kTy3nJvDBpQr,Vx2Xgfpt4zJdZwrcLkHG,o8yIKr4ZnUmSzO9VtRDCQ,XV3cU4Ez5kgM0YtHNedhuRGB879lpT
def DZIvxozB7Y5K4qCe(url,data=iiy37aKq0pCEIOwfcTh61xb4U,lHDuLVCy8kvqB6Rxh4Gs5K=iiy37aKq0pCEIOwfcTh61xb4U):
	if lHDuLVCy8kvqB6Rxh4Gs5K==iiy37aKq0pCEIOwfcTh61xb4U: lHDuLVCy8kvqB6Rxh4Gs5K = 'ytInitialData'
	QlAC9VBYGRckULquednZ0XvOxF4f5M = FgJLkYac7lQxEbs()
	rzR9SN7ApZuQhTDWEX3V6ga = {'User-Agent':QlAC9VBYGRckULquednZ0XvOxF4f5M,'Cookie':'PREF=hl=ar'}
	global OXsckY7RzjCag9A
	if not data: data = OXsckY7RzjCag9A.getSetting('av.youtube.data')
	if data.count(':::')==4: bbg7i0DFEuTYX8avk,key,mOKb2wxjl47Daq16,nDtmdZ0A7vjiKLPCfl4N,XV3cU4Ez5kgM0YtHNedhuRGB879lpT = data.split(':::')
	else: bbg7i0DFEuTYX8avk,key,mOKb2wxjl47Daq16,nDtmdZ0A7vjiKLPCfl4N,XV3cU4Ez5kgM0YtHNedhuRGB879lpT = iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U
	EwsmJ67cCYDIlg = {"context":{"client":{"hl":"ar","clientName":"WEB","clientVersion":mOKb2wxjl47Daq16}}}
	if url==JaQEtCzDXgos1cdZN+'/shorts' or '/my_main_page_shorts_link' in url:
		url = JaQEtCzDXgos1cdZN+'/youtubei/v1/reel/reel_watch_sequence'+'?key='+key
		EwsmJ67cCYDIlg['sequenceParams'] = bbg7i0DFEuTYX8avk
		EwsmJ67cCYDIlg = str(EwsmJ67cCYDIlg)
		oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(r3rnfZ7cdxzNFebIRaLSG6B,'POST',url,EwsmJ67cCYDIlg,rzR9SN7ApZuQhTDWEX3V6ga,True,True,'YOUTUBE-GET_PAGE_DATA-1st')
	elif '/guide?key=' in url:
		url = JaQEtCzDXgos1cdZN+'/youtubei/v1/guide?key='+key
		EwsmJ67cCYDIlg = str(EwsmJ67cCYDIlg)
		oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(r3rnfZ7cdxzNFebIRaLSG6B,'POST',url,EwsmJ67cCYDIlg,rzR9SN7ApZuQhTDWEX3V6ga,True,True,'YOUTUBE-GET_PAGE_DATA-3rd')
	elif 'key=' in url and bbg7i0DFEuTYX8avk:
		EwsmJ67cCYDIlg['continuation'] = XV3cU4Ez5kgM0YtHNedhuRGB879lpT
		EwsmJ67cCYDIlg['context']['client']['visitorData'] = bbg7i0DFEuTYX8avk
		EwsmJ67cCYDIlg = str(EwsmJ67cCYDIlg)
		oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(r3rnfZ7cdxzNFebIRaLSG6B,'POST',url,EwsmJ67cCYDIlg,rzR9SN7ApZuQhTDWEX3V6ga,True,True,'YOUTUBE-GET_PAGE_DATA-4th')
	elif 'ctoken=' in url and nDtmdZ0A7vjiKLPCfl4N:
		rzR9SN7ApZuQhTDWEX3V6ga.update({'X-YouTube-Client-Name':'1','X-YouTube-Client-Version':mOKb2wxjl47Daq16})
		rzR9SN7ApZuQhTDWEX3V6ga.update({'Cookie':'VISITOR_INFO1_LIVE='+nDtmdZ0A7vjiKLPCfl4N})
		oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(r3rnfZ7cdxzNFebIRaLSG6B,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,rzR9SN7ApZuQhTDWEX3V6ga,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'YOUTUBE-GET_PAGE_DATA-5th')
	else:
		oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(r3rnfZ7cdxzNFebIRaLSG6B,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,rzR9SN7ApZuQhTDWEX3V6ga,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'YOUTUBE-GET_PAGE_DATA-6th')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	ZEdj50uOAeXUWGCk = dEyT9xhGjolYzLCH7460w3.findall('"innertubeApiKey".*?"(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL|dEyT9xhGjolYzLCH7460w3.I)
	if ZEdj50uOAeXUWGCk: key = ZEdj50uOAeXUWGCk[0]
	ZEdj50uOAeXUWGCk = dEyT9xhGjolYzLCH7460w3.findall('"cver".*?"value".*?"(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL|dEyT9xhGjolYzLCH7460w3.I)
	if ZEdj50uOAeXUWGCk: mOKb2wxjl47Daq16 = ZEdj50uOAeXUWGCk[0]
	ZEdj50uOAeXUWGCk = dEyT9xhGjolYzLCH7460w3.findall('"visitorData".*?"(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL|dEyT9xhGjolYzLCH7460w3.I)
	if ZEdj50uOAeXUWGCk: bbg7i0DFEuTYX8avk = ZEdj50uOAeXUWGCk[0]
	cookies = oCJ8TdG2LwSIVcbaUnhB.cookies
	if 'VISITOR_INFO1_LIVE' in list(cookies.keys()): nDtmdZ0A7vjiKLPCfl4N = cookies['VISITOR_INFO1_LIVE']
	V4p9OiNGeDSfyx = bbg7i0DFEuTYX8avk+':::'+key+':::'+mOKb2wxjl47Daq16+':::'+nDtmdZ0A7vjiKLPCfl4N+':::'+XV3cU4Ez5kgM0YtHNedhuRGB879lpT
	if lHDuLVCy8kvqB6Rxh4Gs5K=='ytInitialData' and 'ytInitialData' in Vxz6OndPIX4g2kaRp7:
		wqCpiLVsbohUHcB5 = dEyT9xhGjolYzLCH7460w3.findall('window\["ytInitialData"\] = ({.*?});',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if not wqCpiLVsbohUHcB5: wqCpiLVsbohUHcB5 = dEyT9xhGjolYzLCH7460w3.findall('var ytInitialData = ({.*?});',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		k9voalDfZ4SRIwWy2X = DeIL3qoa2UBtYPb('str',wqCpiLVsbohUHcB5[0])
	elif lHDuLVCy8kvqB6Rxh4Gs5K=='ytInitialGuideData' and 'ytInitialGuideData' in Vxz6OndPIX4g2kaRp7:
		wqCpiLVsbohUHcB5 = dEyT9xhGjolYzLCH7460w3.findall('var ytInitialGuideData = ({.*?});',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		k9voalDfZ4SRIwWy2X = DeIL3qoa2UBtYPb('str',wqCpiLVsbohUHcB5[0])
	elif '</script>' not in Vxz6OndPIX4g2kaRp7: k9voalDfZ4SRIwWy2X = DeIL3qoa2UBtYPb('str',Vxz6OndPIX4g2kaRp7)
	else: k9voalDfZ4SRIwWy2X = iiy37aKq0pCEIOwfcTh61xb4U
	if 0:
		sqzYKBjtT21GCfI5rOkhNLQ8Jv = str(k9voalDfZ4SRIwWy2X)
		if J1MoiYc7ZwzKS: sqzYKBjtT21GCfI5rOkhNLQ8Jv = sqzYKBjtT21GCfI5rOkhNLQ8Jv.encode(df6QpwGxuJVZr)
		open('S:\\0000emad.dat','wb').write(sqzYKBjtT21GCfI5rOkhNLQ8Jv)
	OXsckY7RzjCag9A.setSetting('av.youtube.data',V4p9OiNGeDSfyx)
	return Vxz6OndPIX4g2kaRp7,k9voalDfZ4SRIwWy2X,V4p9OiNGeDSfyx
def M9Mbdz04yi2N(url,bsqXJ3iaf2dop5):
	search = TTBf6S08q1NKXd5v9wa()
	if not search: return
	search = search.replace(iFBmE2MUIpSu34wsd7Rf6z,'+')
	eCGwzSrqBmIv = url+'/search?query='+search
	AIQeNZP4FMDw9S(eCGwzSrqBmIv,bsqXJ3iaf2dop5)
	return
def mUhJtHB9nw(search):
	search,brFQp5vmgJWdZfEkCBOlu9c,showDialogs = XkYnev3ZCA6ahO94(search)
	if not search:
		search = TTBf6S08q1NKXd5v9wa()
		if not search: return
	search = search.replace(iFBmE2MUIpSu34wsd7Rf6z,'+')
	eCGwzSrqBmIv = JaQEtCzDXgos1cdZN+'/results?search_query='+search
	if not showDialogs:
		if '_YOUTUBE-VIDEOS_' in brFQp5vmgJWdZfEkCBOlu9c: vvulfzObNTJCntcrHwjX8 = '&sp=EgIQAQ%253D%253D'
		elif '_YOUTUBE-PLAYLISTS_' in brFQp5vmgJWdZfEkCBOlu9c: vvulfzObNTJCntcrHwjX8 = '&sp=EgIQAw%253D%253D'
		elif '_YOUTUBE-CHANNELS_' in brFQp5vmgJWdZfEkCBOlu9c: vvulfzObNTJCntcrHwjX8 = '&sp=EgIQAg%253D%253D'
		else: vvulfzObNTJCntcrHwjX8 = iiy37aKq0pCEIOwfcTh61xb4U
		O5Pwg3UFyX0k9E = eCGwzSrqBmIv+vvulfzObNTJCntcrHwjX8
	else:
		YvLw3z52aFGZ1uSdMs4qXhRUylOxi,pEUuPmWL6gnZNxM7Y2Sd,Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb = [],[],iiy37aKq0pCEIOwfcTh61xb4U
		tlHG9ICsVrwd37aik8zB0WOm = ['فيديوهات مرتبة بالصلة','فيديوهات مرتبة بالتاريخ','فيديوهات مرتبة بعدد المشاهدات','فيديوهات مرتبة بالتقييم','(جيد للمسلسلات) قوائم تشغيل','قنوات','بث حي']
		qq7hWnTeQGvwzKr5NloaZ46VUys2 = ['&sp=CAASAhAB','&sp=CAISAhAB','&sp=CAMSAhAB','&sp=CAESAhAB','&sp=EgIQAw==','&sp=EgIQAg==','&sp=EgJAAQ==']
		SulLHWk7CTxQcZ = ccv1mVPUsnr('اختر البحث المناسب',tlHG9ICsVrwd37aik8zB0WOm)
		if SulLHWk7CTxQcZ == -1: return
		Fv8SPb2eClOa5wkL3rVN4XmAUj67I1 = qq7hWnTeQGvwzKr5NloaZ46VUys2[SulLHWk7CTxQcZ]
		Vxz6OndPIX4g2kaRp7,ZqBwlJjmTE5Oba9XfvNAn,data = DZIvxozB7Y5K4qCe(eCGwzSrqBmIv+Fv8SPb2eClOa5wkL3rVN4XmAUj67I1)
		if ZqBwlJjmTE5Oba9XfvNAn:
			try:
				cmtDvXxpZyuI8KW = ZqBwlJjmTE5Oba9XfvNAn['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['subMenu']['searchSubMenuRenderer']['groups']
				for PfvcRwdJ0ugmMCysVeU3LbhGr8SY in range(len(cmtDvXxpZyuI8KW)):
					group = cmtDvXxpZyuI8KW[PfvcRwdJ0ugmMCysVeU3LbhGr8SY]['searchFilterGroupRenderer']['filters']
					for VVyh7A1Pb2Zi8a6HJOvCGepBr54nx in range(len(group)):
						r5VGw2CN93SfUgyd1uD7HKT = group[VVyh7A1Pb2Zi8a6HJOvCGepBr54nx]['searchFilterRenderer']
						if 'navigationEndpoint' in list(r5VGw2CN93SfUgyd1uD7HKT.keys()):
							fCXyTlcmF4WuetVork = r5VGw2CN93SfUgyd1uD7HKT['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']
							fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork.replace('\u0026','&')
							title = r5VGw2CN93SfUgyd1uD7HKT['tooltip']
							title = title.replace('البحث عن ',iiy37aKq0pCEIOwfcTh61xb4U)
							if 'إزالة الفلتر' in title: continue
							if 'قائمة تشغيل' in title:
								title = 'جيد للمسلسلات '+title
								Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb = title
								hx0dU3Ki7AyEfkSZY6TmN2BwtX = fCXyTlcmF4WuetVork
							if 'ترتيب حسب' in title: continue
							title = title.replace('Search for ',iiy37aKq0pCEIOwfcTh61xb4U)
							if 'Remove' in title: continue
							if 'Playlist' in title:
								title = 'جيد للمسلسلات '+title
								Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb = title
								hx0dU3Ki7AyEfkSZY6TmN2BwtX = fCXyTlcmF4WuetVork
							if 'Sort by' in title: continue
							YvLw3z52aFGZ1uSdMs4qXhRUylOxi.append(vvmT3DLXkhPBwIaOAo6srZpEnRVJC(title))
							pEUuPmWL6gnZNxM7Y2Sd.append(fCXyTlcmF4WuetVork)
			except: pass
		if not Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb: uKqxQPJLXm2h8 = iiy37aKq0pCEIOwfcTh61xb4U
		else:
			YvLw3z52aFGZ1uSdMs4qXhRUylOxi = ['بدون فلتر',Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb]+YvLw3z52aFGZ1uSdMs4qXhRUylOxi
			pEUuPmWL6gnZNxM7Y2Sd = [iiy37aKq0pCEIOwfcTh61xb4U,hx0dU3Ki7AyEfkSZY6TmN2BwtX]+pEUuPmWL6gnZNxM7Y2Sd
			avoqxTLgyzHKsQdI = ccv1mVPUsnr('موقع يوتيوب - اختر الفلتر',YvLw3z52aFGZ1uSdMs4qXhRUylOxi)
			if avoqxTLgyzHKsQdI == -1: return
			uKqxQPJLXm2h8 = pEUuPmWL6gnZNxM7Y2Sd[avoqxTLgyzHKsQdI]
		if uKqxQPJLXm2h8: O5Pwg3UFyX0k9E = JaQEtCzDXgos1cdZN+uKqxQPJLXm2h8
		elif Fv8SPb2eClOa5wkL3rVN4XmAUj67I1: O5Pwg3UFyX0k9E = eCGwzSrqBmIv+Fv8SPb2eClOa5wkL3rVN4XmAUj67I1
		else: O5Pwg3UFyX0k9E = eCGwzSrqBmIv
	AIQeNZP4FMDw9S(O5Pwg3UFyX0k9E)
	return
# -*- coding: utf-8 -*-
from braVAkwfBN import *
sQU2GnRoMwLK8CBdfzmNr4jXyO = 'LIVETV'
JaQEtCzDXgos1cdZN = gZ4LwbKaOm['PYTHON'][0]
def sHVM8YchrDjZAJ7(mode,url):
	if   mode==100: EA7FzO1kMZGQXDd2giB0cwLom = jihuS9LVAvTrClPapMbUEwfn8XN()
	elif mode==101: EA7FzO1kMZGQXDd2giB0cwLom = rmEH1eAYBg8xPK('0',True)
	elif mode==102: EA7FzO1kMZGQXDd2giB0cwLom = rmEH1eAYBg8xPK('1',True)
	elif mode==103: EA7FzO1kMZGQXDd2giB0cwLom = rmEH1eAYBg8xPK('2',True)
	elif mode==104: EA7FzO1kMZGQXDd2giB0cwLom = rmEH1eAYBg8xPK('3',True)
	elif mode==105: EA7FzO1kMZGQXDd2giB0cwLom = TW6Z0zqaDl(url)
	elif mode==106: EA7FzO1kMZGQXDd2giB0cwLom = rmEH1eAYBg8xPK('4',True)
	else: EA7FzO1kMZGQXDd2giB0cwLom = False
	return EA7FzO1kMZGQXDd2giB0cwLom
def jihuS9LVAvTrClPapMbUEwfn8XN():
	bP6z3OSLp7va('folder','_M3U_'+'قوائم فيديوهات M3U',iiy37aKq0pCEIOwfcTh61xb4U,762)
	bP6z3OSLp7va('folder','_IPT_'+'قوائم فيديوهات IPTV',iiy37aKq0pCEIOwfcTh61xb4U,761)
	bP6z3OSLp7va('folder','_TV0_'+'قنوات من مواقعها الأصلية',iiy37aKq0pCEIOwfcTh61xb4U,101)
	bP6z3OSLp7va('folder','_TV4_'+'قنوات مختارة من يوتيوب',iiy37aKq0pCEIOwfcTh61xb4U,106)
	bP6z3OSLp7va('folder','_YUT_'+'قنوات عربية من يوتيوب',iiy37aKq0pCEIOwfcTh61xb4U,147)
	bP6z3OSLp7va('folder','_YUT_'+'قنوات أجنبية من يوتيوب',iiy37aKq0pCEIOwfcTh61xb4U,148)
	bP6z3OSLp7va('folder','_IFL_'+'  قناة آي فيلم من موقعهم  ',iiy37aKq0pCEIOwfcTh61xb4U,28)
	bP6z3OSLp7va('live','_MRF_'+'قناة المعارف من موقعهم',iiy37aKq0pCEIOwfcTh61xb4U,41)
	bP6z3OSLp7va('live','_PNT_'+'قناة هلا من موقع بانيت',iiy37aKq0pCEIOwfcTh61xb4U,38)
	bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	bP6z3OSLp7va('folder','_TV1_'+'قنوات تلفزيونية عامة',iiy37aKq0pCEIOwfcTh61xb4U,102)
	bP6z3OSLp7va('folder','_TV2_'+'قنوات تلفزيونية خاصة',iiy37aKq0pCEIOwfcTh61xb4U,103)
	bP6z3OSLp7va('folder','_TV3_'+'قنوات تلفزيونية للفحص',iiy37aKq0pCEIOwfcTh61xb4U,104)
	return
def rmEH1eAYBg8xPK(mmV5SgG39tduKpl,showDialogs=True):
	ooQEi5O6tYsGVF8LU0TC3hgMeflBwH = '_TV'+mmV5SgG39tduKpl+'_'
	Si4j3bXGLeno0zfxlm9ZOcy = {'id':iiy37aKq0pCEIOwfcTh61xb4U,'user':iw3BpJl1Y9tbg8XMR4VeoS6kEUhf,'function':'list','menu':mmV5SgG39tduKpl}
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(r3rnfZ7cdxzNFebIRaLSG6B,'POST',JaQEtCzDXgos1cdZN,Si4j3bXGLeno0zfxlm9ZOcy,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'LIVETV-ITEMS-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	items = dEyT9xhGjolYzLCH7460w3.findall('([^;\r\n]+?);;(.*?);;(.*?);;(.*?);;(.*?);;',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if items:
		for iEfNKT3velFyGth80SA4pxbCRrVD in range(len(items)):
			name = items[iEfNKT3velFyGth80SA4pxbCRrVD][3]
			start = name[0:2]
			start = start.replace('al','Al')
			start = start.replace('El','Al')
			start = start.replace('AL','Al')
			start = start.replace('EL','Al')
			name = start+name[2:]
			start = name[0:3]
			start = start.replace('Al-','Al')
			start = start.replace('Al ','Al')
			name = start+name[3:]
			items[iEfNKT3velFyGth80SA4pxbCRrVD] = items[iEfNKT3velFyGth80SA4pxbCRrVD][0],items[iEfNKT3velFyGth80SA4pxbCRrVD][1],items[iEfNKT3velFyGth80SA4pxbCRrVD][2],name,items[iEfNKT3velFyGth80SA4pxbCRrVD][4]
		items = set(items)
		items = sorted(items, reverse=False, key=lambda key: key[0].lower())
		items = sorted(items, reverse=False, key=lambda key: key[3].lower())
		for VamqUtbfFn6MANy,Zw4M5DUStdE6xp7GI,qCVlj6LiNza2MbZosSecpWQGuJd7,name,C0dvhEbPWYlUtimM3x in items:
			if '#' in VamqUtbfFn6MANy: continue
			if VamqUtbfFn6MANy!='URL': name = name+PSwfZcdRYhpl5Igqz8xOEk67+jHLaUg49SXC6JyTM+VamqUtbfFn6MANy+YoQW601K4fMJcsreDnGVE5wUZIy7
			url = VamqUtbfFn6MANy+';;'+Zw4M5DUStdE6xp7GI+';;'+qCVlj6LiNza2MbZosSecpWQGuJd7+';;'+mmV5SgG39tduKpl
			bP6z3OSLp7va('live',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+iiy37aKq0pCEIOwfcTh61xb4U+name,url,105,C0dvhEbPWYlUtimM3x)
	else:
		if showDialogs: bP6z3OSLp7va('link',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'هذه الخدمة مخصصة للمبرمج فقط',iiy37aKq0pCEIOwfcTh61xb4U,9999)
	return
def TW6Z0zqaDl(id):
	VamqUtbfFn6MANy,Zw4M5DUStdE6xp7GI,qCVlj6LiNza2MbZosSecpWQGuJd7,mmV5SgG39tduKpl = id.split(';;')
	url = iiy37aKq0pCEIOwfcTh61xb4U
	if VamqUtbfFn6MANy=='URL': url = qCVlj6LiNza2MbZosSecpWQGuJd7
	elif VamqUtbfFn6MANy=='YOUTUBE':
		url = gZ4LwbKaOm['YOUTUBE'][0]+'/watch?v='+qCVlj6LiNza2MbZosSecpWQGuJd7
		import lqBJGK8hXO
		lqBJGK8hXO.ZDg1HavwueT85mcAOorC4hnS([url],sQU2GnRoMwLK8CBdfzmNr4jXyO,'live',url)
		return
	elif VamqUtbfFn6MANy=='GA':
		Si4j3bXGLeno0zfxlm9ZOcy = { 'id' : iiy37aKq0pCEIOwfcTh61xb4U, 'user' : iw3BpJl1Y9tbg8XMR4VeoS6kEUhf , 'function' : 'playGA1' , 'menu' : iiy37aKq0pCEIOwfcTh61xb4U }
		oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(r3rnfZ7cdxzNFebIRaLSG6B,'GET',JaQEtCzDXgos1cdZN,Si4j3bXGLeno0zfxlm9ZOcy,iiy37aKq0pCEIOwfcTh61xb4U,False,iiy37aKq0pCEIOwfcTh61xb4U,'LIVETV-PLAY-1st')
		if not oCJ8TdG2LwSIVcbaUnhB.succeeded:
			bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
		cookies = oCJ8TdG2LwSIVcbaUnhB.cookies
		qa1uMOdN7cKLvb86QrSyGWpkV4 = cookies['ASP.NET_SessionId']
		url = oCJ8TdG2LwSIVcbaUnhB.headers['Location']
		Si4j3bXGLeno0zfxlm9ZOcy = { 'id' : qCVlj6LiNza2MbZosSecpWQGuJd7 , 'user' : iw3BpJl1Y9tbg8XMR4VeoS6kEUhf , 'function' : 'playGA2' , 'menu' : iiy37aKq0pCEIOwfcTh61xb4U }
		headers = { 'Cookie' : 'ASP.NET_SessionId='+qa1uMOdN7cKLvb86QrSyGWpkV4 }
		oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(r3rnfZ7cdxzNFebIRaLSG6B,'GET',JaQEtCzDXgos1cdZN,Si4j3bXGLeno0zfxlm9ZOcy,headers,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'LIVETV-PLAY-2nd')
		if not oCJ8TdG2LwSIVcbaUnhB.succeeded:
			bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
		url = dEyT9xhGjolYzLCH7460w3.findall('resp":"(http.*?m3u8)(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		fCXyTlcmF4WuetVork = url[0][0]
		BehavuIfZnQ9xW6CXVgH = url[0][1]
		V0XRK8jgYmGqdQevuW4z1Z9A7ba6 = 'http://38.'+Zw4M5DUStdE6xp7GI+'777/'+qCVlj6LiNza2MbZosSecpWQGuJd7+'_HD.m3u8'+BehavuIfZnQ9xW6CXVgH
		W0qFJtThfvsmDxGupeYIOPNi3bV = V0XRK8jgYmGqdQevuW4z1Z9A7ba6.replace('36:7','40:7').replace('_HD.m3u8','.m3u8')
		fiRxb4SgFc = V0XRK8jgYmGqdQevuW4z1Z9A7ba6.replace('36:7','42:7').replace('_HD.m3u8','.m3u8')
		A7Ap2wdlxM = ['HD','SD1','SD2']
		duef0gb3Mi1AV5WpN8 = [V0XRK8jgYmGqdQevuW4z1Z9A7ba6,W0qFJtThfvsmDxGupeYIOPNi3bV,fiRxb4SgFc]
		mmfrx2S5XqknFTDeRhj49LuYv1wW0 = 0
		if mmfrx2S5XqknFTDeRhj49LuYv1wW0 == -1: return
		else: url = duef0gb3Mi1AV5WpN8[mmfrx2S5XqknFTDeRhj49LuYv1wW0]
	elif VamqUtbfFn6MANy=='NT':
		headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
		Si4j3bXGLeno0zfxlm9ZOcy = { 'id' : qCVlj6LiNza2MbZosSecpWQGuJd7 , 'user' : iw3BpJl1Y9tbg8XMR4VeoS6kEUhf , 'function' : 'playNT' , 'menu' : mmV5SgG39tduKpl }
		oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(r3rnfZ7cdxzNFebIRaLSG6B,'POST', JaQEtCzDXgos1cdZN, Si4j3bXGLeno0zfxlm9ZOcy, headers, False,iiy37aKq0pCEIOwfcTh61xb4U,'LIVETV-PLAY-3rd')
		if not oCJ8TdG2LwSIVcbaUnhB.succeeded:
			bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
		url = oCJ8TdG2LwSIVcbaUnhB.headers['Location']
		url = url.replace('%20',iFBmE2MUIpSu34wsd7Rf6z)
		url = url.replace('%3D','=')
		if 'Learn' in qCVlj6LiNza2MbZosSecpWQGuJd7:
			url = url.replace('NTNNile',iiy37aKq0pCEIOwfcTh61xb4U)
			url = url.replace('learning1','Learning')
	elif VamqUtbfFn6MANy=='PL':
		Si4j3bXGLeno0zfxlm9ZOcy = { 'id' : qCVlj6LiNza2MbZosSecpWQGuJd7 , 'user' : iw3BpJl1Y9tbg8XMR4VeoS6kEUhf , 'function' : 'playPL' , 'menu' : mmV5SgG39tduKpl }
		oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(r3rnfZ7cdxzNFebIRaLSG6B,'POST', JaQEtCzDXgos1cdZN, Si4j3bXGLeno0zfxlm9ZOcy, iiy37aKq0pCEIOwfcTh61xb4U,False,iiy37aKq0pCEIOwfcTh61xb4U,'LIVETV-PLAY-4th')
		if not oCJ8TdG2LwSIVcbaUnhB.succeeded:
			bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
		url = oCJ8TdG2LwSIVcbaUnhB.headers['Location']
		headers = {'Referer':oCJ8TdG2LwSIVcbaUnhB.headers['Referer']}
		oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(hI7SkXd94fFzAHNZCQoMqEutbnWP,'POST',url, iiy37aKq0pCEIOwfcTh61xb4U,headers , iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'LIVETV-PLAY-5th')
		if not oCJ8TdG2LwSIVcbaUnhB.succeeded:
			bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
		items = dEyT9xhGjolYzLCH7460w3.findall('source src="(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		url = items[0]
	elif VamqUtbfFn6MANy in ['TA','FM','YU','WS1','WS2','RL1','RL2']:
		if VamqUtbfFn6MANy=='TA': qCVlj6LiNza2MbZosSecpWQGuJd7 = id
		headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
		Si4j3bXGLeno0zfxlm9ZOcy = { 'id' : qCVlj6LiNza2MbZosSecpWQGuJd7 , 'user' : iw3BpJl1Y9tbg8XMR4VeoS6kEUhf , 'function' : 'play'+VamqUtbfFn6MANy , 'menu' : mmV5SgG39tduKpl }
		oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(r3rnfZ7cdxzNFebIRaLSG6B,'POST',JaQEtCzDXgos1cdZN,Si4j3bXGLeno0zfxlm9ZOcy,headers,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'LIVETV-PLAY-6th')
		if not oCJ8TdG2LwSIVcbaUnhB.succeeded:
			bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
		url = oCJ8TdG2LwSIVcbaUnhB.headers['Location']
		if VamqUtbfFn6MANy=='FM':
			oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(hI7SkXd94fFzAHNZCQoMqEutbnWP,'GET', url, iiy37aKq0pCEIOwfcTh61xb4U, iiy37aKq0pCEIOwfcTh61xb4U, False,iiy37aKq0pCEIOwfcTh61xb4U,'LIVETV-PLAY-7th')
			url = oCJ8TdG2LwSIVcbaUnhB.headers['Location']
			url = url.replace('https','http')
	PsD3IgluKFyvzMLoRT9j5hq2(url,sQU2GnRoMwLK8CBdfzmNr4jXyO,'live')
	return
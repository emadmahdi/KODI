# -*- coding: utf-8 -*-
from braVAkwfBN import *
sQU2GnRoMwLK8CBdfzmNr4jXyO = 'KARBALATV'
ooQEi5O6tYsGVF8LU0TC3hgMeflBwH = '_KRB_'
JaQEtCzDXgos1cdZN = gZ4LwbKaOm[sQU2GnRoMwLK8CBdfzmNr4jXyO][0]
headers = {'User-Agent':iiy37aKq0pCEIOwfcTh61xb4U}
def sHVM8YchrDjZAJ7(mode,url,text):
	if   mode==320: EA7FzO1kMZGQXDd2giB0cwLom = jihuS9LVAvTrClPapMbUEwfn8XN()
	elif mode==321: EA7FzO1kMZGQXDd2giB0cwLom = AIQeNZP4FMDw9S(url)
	elif mode==322: EA7FzO1kMZGQXDd2giB0cwLom = TW6Z0zqaDl(url)
	elif mode==329: EA7FzO1kMZGQXDd2giB0cwLom = mUhJtHB9nw(text)
	else: EA7FzO1kMZGQXDd2giB0cwLom = False
	return EA7FzO1kMZGQXDd2giB0cwLom
def jihuS9LVAvTrClPapMbUEwfn8XN():
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'بحث في الموقع',iiy37aKq0pCEIOwfcTh61xb4U,329,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'_REMEMBERRESULTS_')
	bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(Dxc7GChQwZ4kOlKHSbL06agnB,'GET',JaQEtCzDXgos1cdZN+'/video.php',iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'KARBALATV-MENU-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('class="icono-plus"(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
	items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)">(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	for fCXyTlcmF4WuetVork,title in items:
		if title=='المكتبة المرئية': continue
		fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN+fCXyTlcmF4WuetVork
		bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,321)
	return Vxz6OndPIX4g2kaRp7
def AIQeNZP4FMDw9S(url):
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'KARBALATV-TITLES-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('class="container"(.*?)class="footer',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
	items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?url\((.*?)\).*?pd5">(.*?)<.*?<h3.*?">(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if not items: items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?src="(.*?)".*?alt="(.*?)".*?<p.*?>(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	for fCXyTlcmF4WuetVork,C0dvhEbPWYlUtimM3x,count,title in items:
		count = count.replace('عدد ',iiy37aKq0pCEIOwfcTh61xb4U).replace(iFBmE2MUIpSu34wsd7Rf6z,iiy37aKq0pCEIOwfcTh61xb4U)
		fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork.replace('/',iiy37aKq0pCEIOwfcTh61xb4U)
		C0dvhEbPWYlUtimM3x = C0dvhEbPWYlUtimM3x.replace("'",iiy37aKq0pCEIOwfcTh61xb4U)
		if '.php' not in fCXyTlcmF4WuetVork: fCXyTlcmF4WuetVork = 'video.php'+fCXyTlcmF4WuetVork
		fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN+'/'+fCXyTlcmF4WuetVork
		C0dvhEbPWYlUtimM3x = JaQEtCzDXgos1cdZN+C0dvhEbPWYlUtimM3x
		title = title.strip(iFBmE2MUIpSu34wsd7Rf6z)
		title = title+' ('+count+')'
		if 'video.php' in fCXyTlcmF4WuetVork: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,321,C0dvhEbPWYlUtimM3x)
		elif 'watch.php' in fCXyTlcmF4WuetVork: bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,322,C0dvhEbPWYlUtimM3x)
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('class="pagination(.*?)class="footer',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)">(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title in items:
			fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN+'/video.php'+fCXyTlcmF4WuetVork
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'صفحة '+title,fCXyTlcmF4WuetVork,321)
	return
def TW6Z0zqaDl(url):
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(r3rnfZ7cdxzNFebIRaLSG6B,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'KARBALATV-PLAY-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	fCXyTlcmF4WuetVork = dEyT9xhGjolYzLCH7460w3.findall('<video.*?src="(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN+fCXyTlcmF4WuetVork[0]
	PsD3IgluKFyvzMLoRT9j5hq2(fCXyTlcmF4WuetVork,sQU2GnRoMwLK8CBdfzmNr4jXyO,'video')
	return
def mUhJtHB9nw(search):
	search,brFQp5vmgJWdZfEkCBOlu9c,showDialogs = XkYnev3ZCA6ahO94(search)
	if search==iiy37aKq0pCEIOwfcTh61xb4U: search = TTBf6S08q1NKXd5v9wa()
	if search==iiy37aKq0pCEIOwfcTh61xb4U: return
	search = search.replace(iFBmE2MUIpSu34wsd7Rf6z,'+')
	url = JaQEtCzDXgos1cdZN+'/search.php?q='+search
	AIQeNZP4FMDw9S(url)
	return
# -*- coding: utf-8 -*-
from braVAkwfBN import *
sQU2GnRoMwLK8CBdfzmNr4jXyO = 'SHOOFMAX'
ooQEi5O6tYsGVF8LU0TC3hgMeflBwH = '_SHM_'
JaQEtCzDXgos1cdZN = gZ4LwbKaOm[sQU2GnRoMwLK8CBdfzmNr4jXyO][0]
QSaKzorWqRMY8JkTtNdG1exb = gZ4LwbKaOm[sQU2GnRoMwLK8CBdfzmNr4jXyO][1]
H6RzwPS2yjtZavnqQYbC9 = gZ4LwbKaOm[sQU2GnRoMwLK8CBdfzmNr4jXyO][2]
def sHVM8YchrDjZAJ7(mode,url,text):
	if   mode==50: EA7FzO1kMZGQXDd2giB0cwLom = jihuS9LVAvTrClPapMbUEwfn8XN()
	elif mode==51: EA7FzO1kMZGQXDd2giB0cwLom = AIQeNZP4FMDw9S(url)
	elif mode==52: EA7FzO1kMZGQXDd2giB0cwLom = YNcMvoVF5swlDBJI7PL(url)
	elif mode==53: EA7FzO1kMZGQXDd2giB0cwLom = TW6Z0zqaDl(url)
	elif mode==55: EA7FzO1kMZGQXDd2giB0cwLom = u5xroRO7levpsT20jKBqLy()
	elif mode==56: EA7FzO1kMZGQXDd2giB0cwLom = WpM6fdRGFT2H()
	elif mode==57: EA7FzO1kMZGQXDd2giB0cwLom = pumnMZXzQg1EkAP(url,1)
	elif mode==58: EA7FzO1kMZGQXDd2giB0cwLom = pumnMZXzQg1EkAP(url,2)
	elif mode==59: EA7FzO1kMZGQXDd2giB0cwLom = mUhJtHB9nw(text)
	else: EA7FzO1kMZGQXDd2giB0cwLom = False
	return EA7FzO1kMZGQXDd2giB0cwLom
def jihuS9LVAvTrClPapMbUEwfn8XN():
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'بحث في الموقع',iiy37aKq0pCEIOwfcTh61xb4U,59,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'_REMEMBERRESULTS_')
	bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'المسلسلات',iiy37aKq0pCEIOwfcTh61xb4U,56)
	bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'الافلام',iiy37aKq0pCEIOwfcTh61xb4U,55)
	return iiy37aKq0pCEIOwfcTh61xb4U
def u5xroRO7levpsT20jKBqLy():
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'أفلام مرتبة بسنة الإنتاج',JaQEtCzDXgos1cdZN+'/movie/1/yop',57)
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'أفلام مرتبة بالأفضل تقييم',JaQEtCzDXgos1cdZN+'/movie/1/review',57)
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'أفلام مرتبة بالأكثر مشاهدة',JaQEtCzDXgos1cdZN+'/movie/1/views',57)
	return
def WpM6fdRGFT2H():
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'مسلسلات مرتبة بسنة الإنتاج',JaQEtCzDXgos1cdZN+'/series/1/yop',57)
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'مسلسلات مرتبة بالأفضل تقييم',JaQEtCzDXgos1cdZN+'/series/1/review',57)
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'مسلسلات مرتبة بالأكثر مشاهدة',JaQEtCzDXgos1cdZN+'/series/1/views',57)
	return
def AIQeNZP4FMDw9S(url):
	if '?' in url:
		ng8RFTvpBOxuMa2ySjYWqVZX = url.split('?')
		url = ng8RFTvpBOxuMa2ySjYWqVZX[0]
		filter = '?' + YqdaDIig21wBTWJeUHbc(ng8RFTvpBOxuMa2ySjYWqVZX[1],'=&:/%')
	else: filter = iiy37aKq0pCEIOwfcTh61xb4U
	type,zLEP9N4BOsVrXa,sort = url.split('/')[-3:]
	if sort in ['yop','review','views']:
		if type=='movie': phDAJlISKQmV9dnB5tRsFTyecGwC3='فيلم'
		elif type=='series': phDAJlISKQmV9dnB5tRsFTyecGwC3='مسلسل'
		url = JaQEtCzDXgos1cdZN + '/genre/filter/' + YqdaDIig21wBTWJeUHbc(phDAJlISKQmV9dnB5tRsFTyecGwC3) + '/' + zLEP9N4BOsVrXa + '/' + sort + filter
		Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(PNjZMS7nxa9clHusz1,url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'SHOOFMAX-TITLES-1st')
		items = dEyT9xhGjolYzLCH7460w3.findall('"pid":(.*?),.*?"ptitle":"(.*?)".+?"pepisodes":(.*?),"presbase":"(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		pWvsR8C2N61E9QtKOc5bZ3DIXm=0
		for id,title,qem6IPOy3pCZ7FjcXU1MbYRQS9H,C0dvhEbPWYlUtimM3x in items:
			pWvsR8C2N61E9QtKOc5bZ3DIXm += 1
			C0dvhEbPWYlUtimM3x = H6RzwPS2yjtZavnqQYbC9 + '/v2/img/program/main/' + C0dvhEbPWYlUtimM3x + '-2.jpg'
			fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN + '/program/' + id
			if type=='movie': bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,53,C0dvhEbPWYlUtimM3x)
			if type=='series': bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'مسلسل '+title,fCXyTlcmF4WuetVork+'?ep='+qem6IPOy3pCZ7FjcXU1MbYRQS9H+'='+title+'='+C0dvhEbPWYlUtimM3x,52,C0dvhEbPWYlUtimM3x)
	else:
		if type=='movie': phDAJlISKQmV9dnB5tRsFTyecGwC3='movies'
		elif type=='series': phDAJlISKQmV9dnB5tRsFTyecGwC3='series'
		url = QSaKzorWqRMY8JkTtNdG1exb + '/json/selected/' + sort + '-' + phDAJlISKQmV9dnB5tRsFTyecGwC3 + '-WW.json'
		Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(PNjZMS7nxa9clHusz1,url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'SHOOFMAX-TITLES-2nd')
		items = dEyT9xhGjolYzLCH7460w3.findall('"ref":(.*?),"ep":(.*?),"base":"(.*?)","title":"(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		pWvsR8C2N61E9QtKOc5bZ3DIXm=0
		for id,qem6IPOy3pCZ7FjcXU1MbYRQS9H,C0dvhEbPWYlUtimM3x,title in items:
			pWvsR8C2N61E9QtKOc5bZ3DIXm += 1
			C0dvhEbPWYlUtimM3x = QSaKzorWqRMY8JkTtNdG1exb + '/img/program/' + C0dvhEbPWYlUtimM3x + '-2.jpg'
			fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN + '/program/' + id
			if type=='movie': bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,53,C0dvhEbPWYlUtimM3x)
			elif type=='series': bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'مسلسل '+title,fCXyTlcmF4WuetVork+'?ep='+qem6IPOy3pCZ7FjcXU1MbYRQS9H+'='+title+'='+C0dvhEbPWYlUtimM3x,52,C0dvhEbPWYlUtimM3x)
	title='صفحة '
	if pWvsR8C2N61E9QtKOc5bZ3DIXm==16:
		for Mx2ndrD8PNq1KA in range(1,13) :
			if not zLEP9N4BOsVrXa==str(Mx2ndrD8PNq1KA):
				url = JaQEtCzDXgos1cdZN+'/genre/filter/'+type+'/'+str(Mx2ndrD8PNq1KA)+'/'+sort+filter
				bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title+str(Mx2ndrD8PNq1KA),url,51)
	return
def YNcMvoVF5swlDBJI7PL(url):
	ng8RFTvpBOxuMa2ySjYWqVZX = url.split('=')
	qem6IPOy3pCZ7FjcXU1MbYRQS9H = int(ng8RFTvpBOxuMa2ySjYWqVZX[1])
	name = a9I3YZjc6ySDPE4Kp(ng8RFTvpBOxuMa2ySjYWqVZX[2])
	name = name.replace('_MOD_مسلسل ',iiy37aKq0pCEIOwfcTh61xb4U)
	C0dvhEbPWYlUtimM3x = ng8RFTvpBOxuMa2ySjYWqVZX[3]
	url = url.split('?')[0]
	if qem6IPOy3pCZ7FjcXU1MbYRQS9H==0:
		Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(PNjZMS7nxa9clHusz1,url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'SHOOFMAX-EPISODES-1st')
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('<select(.*?)</select>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('option value="(.*?)"',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		qem6IPOy3pCZ7FjcXU1MbYRQS9H = int(items[-1])
	for zN7sZyFnw5JTE8 in range(qem6IPOy3pCZ7FjcXU1MbYRQS9H,0,-1):
		fCXyTlcmF4WuetVork = url + '?ep=' + str(zN7sZyFnw5JTE8)
		title = '_MOD_مسلسل '+name+' - الحلقة '+str(zN7sZyFnw5JTE8)
		bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,53,C0dvhEbPWYlUtimM3x)
	return
def TW6Z0zqaDl(url):
	Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(Dxc7GChQwZ4kOlKHSbL06agnB,url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'SHOOFMAX-PLAY-1st')
	yockNWtY7uTLP9daC2GZ1 = dEyT9xhGjolYzLCH7460w3.findall('متوفر على شوف ماكس بعد.*?moment\("(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if yockNWtY7uTLP9daC2GZ1:
		X2cQ5NCPvkMieBW7oASspFjE = yockNWtY7uTLP9daC2GZ1[1].replace('T',hnVQObwUcR207fC)
		bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'رسالة من الموقع الأصلي','هذا الفيديو سيكون متوفر على شوف ماكس بعد هذا الوقت'+OTlVEGYPSxsNaBdXUucqA3+X2cQ5NCPvkMieBW7oASspFjE)
		return
	aiYoTNQkgBWn6zw0KGV9e,uuU4h6kZCBgFL = [],[]
	KgcPHtBFi0LV = dEyT9xhGjolYzLCH7460w3.findall('var origin_link = "(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)[0]
	hY5lXdn06jTyqZPLUt8EzrsQaGH = dEyT9xhGjolYzLCH7460w3.findall('var backup_origin_link = "(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)[0]
	P3tys0cXWbiIUKk7HQ6n89V = dEyT9xhGjolYzLCH7460w3.findall('hls: (.*?)_link\+"(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	for Zw4M5DUStdE6xp7GI,fCXyTlcmF4WuetVork in P3tys0cXWbiIUKk7HQ6n89V:
		if 'backup' in Zw4M5DUStdE6xp7GI:
			Zw4M5DUStdE6xp7GI = 'backup server'
			url = hY5lXdn06jTyqZPLUt8EzrsQaGH + fCXyTlcmF4WuetVork
		else:
			Zw4M5DUStdE6xp7GI = 'main server'
			url = KgcPHtBFi0LV + fCXyTlcmF4WuetVork
		if '.m3u8' in url:
			aiYoTNQkgBWn6zw0KGV9e.append(url)
			uuU4h6kZCBgFL.append('m3u8  '+Zw4M5DUStdE6xp7GI)
	P3tys0cXWbiIUKk7HQ6n89V = dEyT9xhGjolYzLCH7460w3.findall('mp4:.*?_link.*?\t(.*?)_link\+"(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	P3tys0cXWbiIUKk7HQ6n89V += dEyT9xhGjolYzLCH7460w3.findall('mp4:.*?\t(.*?)_link\+"(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	for Zw4M5DUStdE6xp7GI,fCXyTlcmF4WuetVork in P3tys0cXWbiIUKk7HQ6n89V:
		filename = fCXyTlcmF4WuetVork.split('/')[-1]
		filename = filename.replace('fallback',iiy37aKq0pCEIOwfcTh61xb4U)
		filename = filename.replace('.mp4',iiy37aKq0pCEIOwfcTh61xb4U)
		filename = filename.replace('-',iiy37aKq0pCEIOwfcTh61xb4U)
		if 'backup' in Zw4M5DUStdE6xp7GI:
			Zw4M5DUStdE6xp7GI = 'backup server'
			url = hY5lXdn06jTyqZPLUt8EzrsQaGH + fCXyTlcmF4WuetVork
		else:
			Zw4M5DUStdE6xp7GI = 'main server'
			url = KgcPHtBFi0LV + fCXyTlcmF4WuetVork
		aiYoTNQkgBWn6zw0KGV9e.append(url)
		uuU4h6kZCBgFL.append('mp4  '+Zw4M5DUStdE6xp7GI+Wc5GekRC0HQLz7+filename)
	mmfrx2S5XqknFTDeRhj49LuYv1wW0 = ccv1mVPUsnr('Select Video Quality:', uuU4h6kZCBgFL)
	if mmfrx2S5XqknFTDeRhj49LuYv1wW0 == -1 : return
	url = aiYoTNQkgBWn6zw0KGV9e[mmfrx2S5XqknFTDeRhj49LuYv1wW0]
	PsD3IgluKFyvzMLoRT9j5hq2(url,sQU2GnRoMwLK8CBdfzmNr4jXyO,'video')
	return
def pumnMZXzQg1EkAP(url,type):
	if 'series' in url: eCGwzSrqBmIv = JaQEtCzDXgos1cdZN + '/genre/مسلسل'
	else: eCGwzSrqBmIv = JaQEtCzDXgos1cdZN + '/genre/فيلم'
	eCGwzSrqBmIv = YqdaDIig21wBTWJeUHbc(eCGwzSrqBmIv)
	Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(Dxc7GChQwZ4kOlKHSbL06agnB,eCGwzSrqBmIv,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'SHOOFMAX-FILTERS-1st')
	if type==1: UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('subgenre(.*?)div',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	elif type==2: UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('country(.*?)div',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
	items = dEyT9xhGjolYzLCH7460w3.findall('option value="(.*?)">(.*?)</option',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if type==1:
		for AAZDqkb6nTJMp9P47ed0hwi5ySGs,title in items:
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,url+'?subgenre='+AAZDqkb6nTJMp9P47ed0hwi5ySGs,58)
	elif type==2:
		url,AAZDqkb6nTJMp9P47ed0hwi5ySGs = url.split('?')
		for CCsm1xkvzejL0RSQZI9JaWD,title in items:
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,url+'?country='+CCsm1xkvzejL0RSQZI9JaWD+'&'+AAZDqkb6nTJMp9P47ed0hwi5ySGs,51)
	return
def mUhJtHB9nw(search):
	search,brFQp5vmgJWdZfEkCBOlu9c,showDialogs = XkYnev3ZCA6ahO94(search)
	if not search: search = TTBf6S08q1NKXd5v9wa()
	if not search: return
	VVOtdjT9AF4Wk3GECqHL = search.replace(iFBmE2MUIpSu34wsd7Rf6z,'%20')
	url = JaQEtCzDXgos1cdZN+'/search?q='+VVOtdjT9AF4Wk3GECqHL
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,True,iiy37aKq0pCEIOwfcTh61xb4U,'SHOOFMAX-SEARCH-2nd')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('general-body(.*?)search-bottom-padding',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
	items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?background-image: url\((.*?)\).*?<span>(.*?)</span>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if items:
		for fCXyTlcmF4WuetVork,C0dvhEbPWYlUtimM3x,title in items:
			url = JaQEtCzDXgos1cdZN + fCXyTlcmF4WuetVork
			if '/program/' in url:
				if '?ep=' in url:
					title = '_MOD_مسلسل '+title
					url = url.replace('?ep=1','?ep=0')
					url = url+'='+YqdaDIig21wBTWJeUHbc(title)+'='+C0dvhEbPWYlUtimM3x
					bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,url,52,C0dvhEbPWYlUtimM3x)
				else:
					title = '_MOD_فيلم '+title
					bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,url,53,C0dvhEbPWYlUtimM3x)
	return
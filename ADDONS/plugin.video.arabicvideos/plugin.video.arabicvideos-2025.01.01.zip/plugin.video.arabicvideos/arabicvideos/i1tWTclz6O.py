# -*- coding: utf-8 -*-
from braVAkwfBN import *
sQU2GnRoMwLK8CBdfzmNr4jXyO = 'FASELHD1'
headers = {'User-Agent':iiy37aKq0pCEIOwfcTh61xb4U}
ooQEi5O6tYsGVF8LU0TC3hgMeflBwH = '_FH1_'
JaQEtCzDXgos1cdZN = gZ4LwbKaOm[sQU2GnRoMwLK8CBdfzmNr4jXyO][0]
a8GCLIuWNkS = ['جوائز الأوسكار','المراجعات','wwe']
def sHVM8YchrDjZAJ7(mode,url,text):
	if   mode==570: EA7FzO1kMZGQXDd2giB0cwLom = jihuS9LVAvTrClPapMbUEwfn8XN()
	elif mode==571: EA7FzO1kMZGQXDd2giB0cwLom = AIQeNZP4FMDw9S(url,text)
	elif mode==572: EA7FzO1kMZGQXDd2giB0cwLom = TW6Z0zqaDl(url)
	elif mode==573: EA7FzO1kMZGQXDd2giB0cwLom = jjQL1mhRn3VpBzNcidEaT4yKt9(url,text)
	elif mode==576: EA7FzO1kMZGQXDd2giB0cwLom = tUYsO8JiWnloFIZ29Evyw6GKXq()
	elif mode==579: EA7FzO1kMZGQXDd2giB0cwLom = mUhJtHB9nw(text)
	else: EA7FzO1kMZGQXDd2giB0cwLom = False
	return EA7FzO1kMZGQXDd2giB0cwLom
def jihuS9LVAvTrClPapMbUEwfn8XN():
	bP6z3OSLp7va('link',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'لماذا الموقع بطيء',iiy37aKq0pCEIOwfcTh61xb4U,576)
	ffBG4TaQU8lVF26R,url = JaQEtCzDXgos1cdZN,JaQEtCzDXgos1cdZN
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'FASELHD1-MENU-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'بحث في الموقع',ffBG4TaQU8lVF26R,579,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'_REMEMBERRESULTS_')
	bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'المميزة',ffBG4TaQU8lVF26R,571,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'featured1')
	items = dEyT9xhGjolYzLCH7460w3.findall('class="h3">(.*?)<.*?href="(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	for title,fCXyTlcmF4WuetVork in items:
		bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,571,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'details1')
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"menu-primary"(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		ddArMvJQaj3Z71SOigFTRuK = dEyT9xhGjolYzLCH7460w3.findall('<li (.*?)</li>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		nx9kySHIKbzOJAtam0Bc1LV = [iiy37aKq0pCEIOwfcTh61xb4U,'أفلام: ','مسلسلات: ','برامج: ','آسيوي: ','أنمي: ']
		o6oXFxmE1bQC = 0
		for mmV5SgG39tduKpl in ddArMvJQaj3Z71SOigFTRuK:
			if o6oXFxmE1bQC>0: bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
			items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?>(.*?)<',mmV5SgG39tduKpl,dEyT9xhGjolYzLCH7460w3.DOTALL)
			for fCXyTlcmF4WuetVork,title in items:
				if fCXyTlcmF4WuetVork=='#': continue
				if 'http' not in fCXyTlcmF4WuetVork: fCXyTlcmF4WuetVork = ffBG4TaQU8lVF26R+fCXyTlcmF4WuetVork
				if title==iiy37aKq0pCEIOwfcTh61xb4U: continue
				if any(aasX2cby4Vo5rTgB in title.lower() for aasX2cby4Vo5rTgB in a8GCLIuWNkS): continue
				title = nx9kySHIKbzOJAtam0Bc1LV[o6oXFxmE1bQC]+title
				bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,571,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'details2')
			o6oXFxmE1bQC += 1
	return
def tUYsO8JiWnloFIZ29Evyw6GKXq():
	bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'رسالة من المبرمج','موقع فاصل الأول بطيء من المصدر .. بسبب قيام أصحاب الموقع بإضافة فحص وتحقق أمني ضد هجوم البرامج وهجوم القراصنة على صفحات الموقع .. والوقت الضائع يذهب في محاولة تجاوز هذا الفحص واثبات أن هذا البرنامج هو مجرد متصفح للمواقع ولا يقوم بالهجوم على المواقع')
	return
def AIQeNZP4FMDw9S(url,type=iiy37aKq0pCEIOwfcTh61xb4U):
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'FASELHD1-TITLES-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	eTov6CfDcRZVJEAq5BH = dEyT9xhGjolYzLCH7460w3.findall('class="h4">(.*?)</div>(.*?)"container"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if not eTov6CfDcRZVJEAq5BH: return
	if type=='filters':
		UUIohmv597bO83YCLgWS = [Vxz6OndPIX4g2kaRp7.replace('\\/','/').replace('\\"','"')]
	elif type=='featured1':
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"homeSlide"(.*?)"container"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall(' src="(.*?)".*? href="(.*?)">(.*?)</a>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		dqYh4p9eBu0Riw2TSVA,P3tys0cXWbiIUKk7HQ6n89V,v1JrBsOo8Qyzk = zip(*items)
		items = zip(P3tys0cXWbiIUKk7HQ6n89V,dqYh4p9eBu0Riw2TSVA,v1JrBsOo8Qyzk)
	elif type=='featured2':
		title,PPH1sQtTkDBbnlYpZfo5 = eTov6CfDcRZVJEAq5BH[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*? data-src="(.*?)".*? alt="(.*?)"',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	elif type=='details2' and len(eTov6CfDcRZVJEAq5BH)>1:
		title = eTov6CfDcRZVJEAq5BH[0][0]
		bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,url,571,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'featured2')
		title = eTov6CfDcRZVJEAq5BH[1][0]
		bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,url,571,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'details3')
		return
	else:
		title,PPH1sQtTkDBbnlYpZfo5 = eTov6CfDcRZVJEAq5BH[-1]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*? data-src="(.*?)".*?"h1">(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	u3Rztpl4VHO9GZ7jCBM65kvS = []
	for fCXyTlcmF4WuetVork,C0dvhEbPWYlUtimM3x,title in items:
		if any(aasX2cby4Vo5rTgB in title.lower() for aasX2cby4Vo5rTgB in a8GCLIuWNkS): continue
		C0dvhEbPWYlUtimM3x = vvmT3DLXkhPBwIaOAo6srZpEnRVJC(C0dvhEbPWYlUtimM3x)
		C0dvhEbPWYlUtimM3x = C0dvhEbPWYlUtimM3x.split('?resize=')[0]
		title = JIY6A30UOsQboNVqCn(title)
		zN7sZyFnw5JTE8 = dEyT9xhGjolYzLCH7460w3.findall('(.*?) (الحلقة|حلقة).\d+',title,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if '/collections/' in fCXyTlcmF4WuetVork:
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,571,C0dvhEbPWYlUtimM3x)
		elif zN7sZyFnw5JTE8 and type==iiy37aKq0pCEIOwfcTh61xb4U:
			title = '_MOD_'+zN7sZyFnw5JTE8[0][0]
			title = title.strip(' –')
			if title not in u3Rztpl4VHO9GZ7jCBM65kvS:
				bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,573,C0dvhEbPWYlUtimM3x)
				u3Rztpl4VHO9GZ7jCBM65kvS.append(title)
		elif 'episodes/' in fCXyTlcmF4WuetVork or 'movies/' in fCXyTlcmF4WuetVork or 'hindi/' in fCXyTlcmF4WuetVork:
			bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,572,C0dvhEbPWYlUtimM3x)
		else: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,573,C0dvhEbPWYlUtimM3x)
	if type=='filters':
		FSU4DQVwsGvuCKae8Ph3q6ZYx = dEyT9xhGjolYzLCH7460w3.findall('"more_button_page":(.*?),',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if FSU4DQVwsGvuCKae8Ph3q6ZYx:
			count = FSU4DQVwsGvuCKae8Ph3q6ZYx[0]
			fCXyTlcmF4WuetVork = url+'/offset/'+count
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'صفحة أخرى',fCXyTlcmF4WuetVork,571,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'filters')
	elif 'details' in type:
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall("class='pagination(.*?)</div>",Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if UUIohmv597bO83YCLgWS:
			PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
			items = dEyT9xhGjolYzLCH7460w3.findall("href='(.*?)'.*?>(.*?)<",PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
			for fCXyTlcmF4WuetVork,title in items:
				title = 'صفحة '+JIY6A30UOsQboNVqCn(title)
				bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,571,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'details4')
	return
def jjQL1mhRn3VpBzNcidEaT4yKt9(url,type=iiy37aKq0pCEIOwfcTh61xb4U):
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'FASELHD1-SEASONS_EPISODES-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	zfbAhCqkmOoZWyGpT3KUIF9anBN = False
	if not type:
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"seasonList"(.*?)"container"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if UUIohmv597bO83YCLgWS:
			PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
			items = dEyT9xhGjolYzLCH7460w3.findall('href = \'(.*?)\'.*? data-src="(.*?)".*?alt="(.*?)".*?"title">(.*?)</div>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
			if len(items)>1:
				ffBG4TaQU8lVF26R = F82MvyX4ThI6sbnA3efDoVS(url,'url')
				zfbAhCqkmOoZWyGpT3KUIF9anBN = True
				for fCXyTlcmF4WuetVork,C0dvhEbPWYlUtimM3x,name,title in items:
					name = JIY6A30UOsQboNVqCn(name)
					if 'http' not in fCXyTlcmF4WuetVork: fCXyTlcmF4WuetVork = ffBG4TaQU8lVF26R+fCXyTlcmF4WuetVork
					title = name+' - '+title
					bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,573,C0dvhEbPWYlUtimM3x,iiy37aKq0pCEIOwfcTh61xb4U,'episodes')
	if type=='episodes' or not zfbAhCqkmOoZWyGpT3KUIF9anBN:
		L95mrowGgdsD = dEyT9xhGjolYzLCH7460w3.findall('"posterImg".*?src="(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if L95mrowGgdsD: C0dvhEbPWYlUtimM3x = L95mrowGgdsD[0]
		else: C0dvhEbPWYlUtimM3x = iiy37aKq0pCEIOwfcTh61xb4U
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"epAll"(.*?)</div>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if UUIohmv597bO83YCLgWS:
			PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
			items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?>(.*?)</a>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
			for fCXyTlcmF4WuetVork,title in items:
				title = title.strip(iFBmE2MUIpSu34wsd7Rf6z)
				title = JIY6A30UOsQboNVqCn(title)
				bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,572,C0dvhEbPWYlUtimM3x)
	return
def TW6Z0zqaDl(url):
	ff2PjlcCF5ZWyIUbVguMz,g6gl2Fz4bsh1dkW5CDtBAVJNynR,adfKwimHOzu7n469yXt = [],[],[]
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(r3rnfZ7cdxzNFebIRaLSG6B,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'FASELHD1-PLAY-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	zXyCncmMHTfIGBlwV3i9R = dEyT9xhGjolYzLCH7460w3.findall('مستوى المشاهدة.*?">(.*?)</span>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if zXyCncmMHTfIGBlwV3i9R:
		UAhMnV3r89cWy7X1D05GBCwTqOP4p = dEyT9xhGjolYzLCH7460w3.findall('"tag">(.*?)</a>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if UAhMnV3r89cWy7X1D05GBCwTqOP4p and IUF8hYKEGLmHDtXbuWNvnJ(sQU2GnRoMwLK8CBdfzmNr4jXyO,url,UAhMnV3r89cWy7X1D05GBCwTqOP4p): return
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"videoRow"(.*?)</div>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('src="(.*?)"',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork in items:
			fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork.split('&img=')[0]
			ff2PjlcCF5ZWyIUbVguMz.append(fCXyTlcmF4WuetVork+'?named=__embed')
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('class="streamHeader(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall("href = '(.*?)'.*?</i>(.*?)</a>",PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,name in items:
			fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork.split('&img=')[0]
			name = name.strip(iFBmE2MUIpSu34wsd7Rf6z)
			ff2PjlcCF5ZWyIUbVguMz.append(fCXyTlcmF4WuetVork+'?named='+name+'__watch')
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('class="downloadLinks(.*?)blackwindow',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?</span>(.*?)</a>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,name in items:
			fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork.split('&img=')[0]
			ff2PjlcCF5ZWyIUbVguMz.append(fCXyTlcmF4WuetVork+'?named='+name+'__download')
	for pntgBel9CduE6Gryki3wO in ff2PjlcCF5ZWyIUbVguMz:
		fCXyTlcmF4WuetVork,name = pntgBel9CduE6Gryki3wO.split('?named')
		if fCXyTlcmF4WuetVork not in g6gl2Fz4bsh1dkW5CDtBAVJNynR:
			g6gl2Fz4bsh1dkW5CDtBAVJNynR.append(fCXyTlcmF4WuetVork)
			adfKwimHOzu7n469yXt.append(pntgBel9CduE6Gryki3wO)
	import lqBJGK8hXO
	lqBJGK8hXO.ZDg1HavwueT85mcAOorC4hnS(adfKwimHOzu7n469yXt,sQU2GnRoMwLK8CBdfzmNr4jXyO,'video',url)
	return
def mUhJtHB9nw(search):
	search,brFQp5vmgJWdZfEkCBOlu9c,showDialogs = XkYnev3ZCA6ahO94(search)
	if search==iiy37aKq0pCEIOwfcTh61xb4U: search = TTBf6S08q1NKXd5v9wa()
	if search==iiy37aKq0pCEIOwfcTh61xb4U: return
	search = search.replace(iFBmE2MUIpSu34wsd7Rf6z,'+')
	eCGwzSrqBmIv = JaQEtCzDXgos1cdZN+'/?s='+search
	AIQeNZP4FMDw9S(eCGwzSrqBmIv,'details5')
	return
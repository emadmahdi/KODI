# -*- coding: utf-8 -*-
import sys as ytv0YaxDcRINurplWKg587Pwqz
LS5n9Ib81cvhApByQJa6GX4HTf = ytv0YaxDcRINurplWKg587Pwqz.version_info [0] == 2
FVDxSCW5MgK = 2048
o2SVZsYjxd4MPfLCRzv1Ime9XD6rhW = 7
def EnKbMAYoFJ (kc93hiPDm4MqAOaL):
	global BCEn6px5l4
	qR9DalTWtCBVeyYwiQg = ord (kc93hiPDm4MqAOaL [-1])
	SSe8FNopD7MI1EixsPTgl4v3YmfB6 = kc93hiPDm4MqAOaL [:-1]
	T2g7SpExkOcr8NUtfYyMB1d4usRw = qR9DalTWtCBVeyYwiQg % len (SSe8FNopD7MI1EixsPTgl4v3YmfB6)
	fxd3B46829KvYlTG17kUyLNJIbWDp0 = SSe8FNopD7MI1EixsPTgl4v3YmfB6 [:T2g7SpExkOcr8NUtfYyMB1d4usRw] + SSe8FNopD7MI1EixsPTgl4v3YmfB6 [T2g7SpExkOcr8NUtfYyMB1d4usRw:]
	if LS5n9Ib81cvhApByQJa6GX4HTf:
		nXV2GRHyP8dpugjML5sTE4OKN = unicode () .join ([unichr (ord (XXYULyZe1FgwdTVnSx2kHfDAsMClJ9) - FVDxSCW5MgK - (GPf6BlpctR + qR9DalTWtCBVeyYwiQg) % o2SVZsYjxd4MPfLCRzv1Ime9XD6rhW) for GPf6BlpctR, XXYULyZe1FgwdTVnSx2kHfDAsMClJ9 in enumerate (fxd3B46829KvYlTG17kUyLNJIbWDp0)])
	else:
		nXV2GRHyP8dpugjML5sTE4OKN = str () .join ([chr (ord (XXYULyZe1FgwdTVnSx2kHfDAsMClJ9) - FVDxSCW5MgK - (GPf6BlpctR + qR9DalTWtCBVeyYwiQg) % o2SVZsYjxd4MPfLCRzv1Ime9XD6rhW) for GPf6BlpctR, XXYULyZe1FgwdTVnSx2kHfDAsMClJ9 in enumerate (fxd3B46829KvYlTG17kUyLNJIbWDp0)])
	return eval (nXV2GRHyP8dpugjML5sTE4OKN)
hhqd6cnfNJiAaLKTPbst5RpMmZF2G,LyNiIHPOwD3hCUYEFM7,vODxLKW5Ql6r4Fbm8=EnKbMAYoFJ,EnKbMAYoFJ,EnKbMAYoFJ
xpT28sXu051,GGx4qyKP1vUtRghsE2WfaHLMXZ,PtkEvXAqif14G20QZsaSyT=vODxLKW5Ql6r4Fbm8,LyNiIHPOwD3hCUYEFM7,hhqd6cnfNJiAaLKTPbst5RpMmZF2G
SaB5hx3PZwXRLtKgrTfQvId,YzX407G1m8ER9OBpkeuqPIf6Ajrh5,EMO8gy4LrsNTh0knZwpSeU75APW=PtkEvXAqif14G20QZsaSyT,GGx4qyKP1vUtRghsE2WfaHLMXZ,xpT28sXu051
yJeq1BjfiO4NFuwIEzxVLK6b9s,ZchUJdM93pTA7zG5,CCUzMTgQjrHntoiGf16LXW5P8EdVu=EMO8gy4LrsNTh0knZwpSeU75APW,YzX407G1m8ER9OBpkeuqPIf6Ajrh5,SaB5hx3PZwXRLtKgrTfQvId
JZszNnIEMAx28Yao0yqhiXGKOPb,XrTw01KtLzbpoyMf,uuExaKGL7UONtevRd=CCUzMTgQjrHntoiGf16LXW5P8EdVu,ZchUJdM93pTA7zG5,yJeq1BjfiO4NFuwIEzxVLK6b9s
y6y5HtgXO4TkUbwVZ,sVzojQerUqX,tKNPiXfQ7HoAqndw3z9IL4E6VrGv1=uuExaKGL7UONtevRd,XrTw01KtLzbpoyMf,JZszNnIEMAx28Yao0yqhiXGKOPb
AbqCJZdWQP9j,Y41NvKfOroMzGB8sEHy7wbXlc5,hhQwbeiNLoqFjX90fB7aG8VAs=tKNPiXfQ7HoAqndw3z9IL4E6VrGv1,sVzojQerUqX,y6y5HtgXO4TkUbwVZ
IpC4qHXRuyNFjzWv,ppxP0Cg6N3JVELzjGKmkZ2qIlu,L90uqo28xEKSFUwYTcm51yRWZIkft=hhQwbeiNLoqFjX90fB7aG8VAs,Y41NvKfOroMzGB8sEHy7wbXlc5,AbqCJZdWQP9j
FRYcH4KL7e9gv5pEB,tELM0b9FzxuRI4J1CYcie7ZXsHBar,TlGXWLYsV1z=L90uqo28xEKSFUwYTcm51yRWZIkft,ppxP0Cg6N3JVELzjGKmkZ2qIlu,IpC4qHXRuyNFjzWv
ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n,HtK4o2sTPgA78U,zmcGfOdvAjsELeJlP=TlGXWLYsV1z,tELM0b9FzxuRI4J1CYcie7ZXsHBar,FRYcH4KL7e9gv5pEB
UO04GcM7oFd3kJbtKQZHRgI2jeyzCh,MgP8OjoaiWQEVG59,jXE2YHkswT8y=zmcGfOdvAjsELeJlP,HtK4o2sTPgA78U,ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n
from braVAkwfBN import *
sQU2GnRoMwLK8CBdfzmNr4jXyO = vODxLKW5Ql6r4Fbm8(u"ࠫࡉࡕࡗࡏࡎࡒࡅࡉ࠭ࢡ")
def sHVM8YchrDjZAJ7(Cpf9s3c0Zngj7XE,kMqh74TPvpSDar59xQUjAyVlHes):
	if   Cpf9s3c0Zngj7XE==JZszNnIEMAx28Yao0yqhiXGKOPb(u"࠹࠳࠱श"): EA7FzO1kMZGQXDd2giB0cwLom = G1DUurE4zdN3FYfgoIQpCK9XLk()
	elif Cpf9s3c0Zngj7XE==XrTw01KtLzbpoyMf(u"࠳࠴࠳ष"): EA7FzO1kMZGQXDd2giB0cwLom = TW6Z0zqaDl(kMqh74TPvpSDar59xQUjAyVlHes)
	elif Cpf9s3c0Zngj7XE==UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"࠴࠵࠵स"): EA7FzO1kMZGQXDd2giB0cwLom = SpixCmzW39oKMOtv84D()
	elif Cpf9s3c0Zngj7XE==PtkEvXAqif14G20QZsaSyT(u"࠵࠶࠷ह"): EA7FzO1kMZGQXDd2giB0cwLom = WesntaZOT0vAxdhGw()
	else: EA7FzO1kMZGQXDd2giB0cwLom = BF6QAiLUNHh7rKOugaw
	return EA7FzO1kMZGQXDd2giB0cwLom
def TW6Z0zqaDl(kMqh74TPvpSDar59xQUjAyVlHes):
	PsD3IgluKFyvzMLoRT9j5hq2(kMqh74TPvpSDar59xQUjAyVlHes,sQU2GnRoMwLK8CBdfzmNr4jXyO,UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠬࡼࡩࡥࡧࡲࠫࢢ"))
	return
def WesntaZOT0vAxdhGw():
	aZtYlicqMKUFPkBCX2AONHwJ4 = PtkEvXAqif14G20QZsaSyT(u"࠭รั้หࠤส๊้ࠡำสฬ฼ࠦวๅใํำ๏๎ࠠฤ๊ࠣห้฻่หࠢไ๎ࠥอไๆ๊ๅ฽ࠥอไๆู็์อࠦหๆࠢฦฺ฿฽ฺࠠๆ์ࠤืืࠠศๆๅหห๋ษࠡษ็๎๊๐ๆࠡอ่ࠤศิสศำࠣࠦฯำๅ๋ๆ้้ࠣ็วหࠢไ๎ิ๐่ࠣࠢฮ้ࠥอฮหษิࠤิ่ษࠡษ็ูํืษ๊ࠡสาฯอั่๋ࠡ฽๋ࠥไโࠢสฺ่๎ัส๋ࠢฬ฾ี็ศࠢึ์ๆ๊ࠦษัฦࠤฬ๊สฮ็ํ่ࠬࢣ")
	bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,HtK4o2sTPgA78U(u"ุࠧำํๆฮࠦสฮ็ํ่ࠥอไๆๆไหฯ࠭ࢤ"),aZtYlicqMKUFPkBCX2AONHwJ4)
	return
def G1DUurE4zdN3FYfgoIQpCK9XLk():
	bP6z3OSLp7va(uuExaKGL7UONtevRd(u"ࠨ࡮࡬ࡲࡰ࠭ࢥ"),PSwfZcdRYhpl5Igqz8xOEk67+EMO8gy4LrsNTh0knZwpSeU75APW(u"ฺࠩี๏่ษࠡฬะ้๏๊ࠠๆๆไหฯࠦวๅใํำ๏๎ࠧࢦ")+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"࠶࠷࠸ऺ"))
	bP6z3OSLp7va(uuExaKGL7UONtevRd(u"ࠪࡰ࡮ࡴ࡫ࠨࢧ"),PSwfZcdRYhpl5Igqz8xOEk67+sVzojQerUqX(u"ࠫฯเ๊๋ำ้่ࠣอๆࠡฬะ้๏๊ࠠศๆไ๎ิ๐่่ษอࠫࢨ")+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"࠷࠸࠸ऻ"))
	bP6z3OSLp7va(PtkEvXAqif14G20QZsaSyT(u"ࠬࡲࡩ࡯࡭ࠪࢩ"),PSwfZcdRYhpl5Igqz8xOEk67+tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"࠭ࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࠬࢪ")+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,sVzojQerUqX(u"࠾࠿࠹࠺़"))
	UxLks45wtR2pnIbmYVSNCM6 = AWl1Phi9dmraZGF()
	auwBLqWNdymHJ = wkMR5x1gTWEQIc6qHCa.stat(UxLks45wtR2pnIbmYVSNCM6).st_mtime
	frKzDoxVINlL397S = []
	if J1MoiYc7ZwzKS: KxWv5mgHBjo = wkMR5x1gTWEQIc6qHCa.listdir(UxLks45wtR2pnIbmYVSNCM6.encode(df6QpwGxuJVZr))
	else: KxWv5mgHBjo = wkMR5x1gTWEQIc6qHCa.listdir(UxLks45wtR2pnIbmYVSNCM6.decode(df6QpwGxuJVZr))
	for NTxA09tqrhpXbSfvCk5K in KxWv5mgHBjo:
		if J1MoiYc7ZwzKS: NTxA09tqrhpXbSfvCk5K = NTxA09tqrhpXbSfvCk5K.decode(df6QpwGxuJVZr)
		if not NTxA09tqrhpXbSfvCk5K.startswith(YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠧࡧ࡫࡯ࡩࡤ࠭ࢫ")): continue
		vv64odD3iYF = wkMR5x1gTWEQIc6qHCa.path.join(UxLks45wtR2pnIbmYVSNCM6,NTxA09tqrhpXbSfvCk5K)
		auwBLqWNdymHJ = wkMR5x1gTWEQIc6qHCa.path.getmtime(vv64odD3iYF)
		frKzDoxVINlL397S.append([NTxA09tqrhpXbSfvCk5K,auwBLqWNdymHJ])
	frKzDoxVINlL397S = sorted(frKzDoxVINlL397S,reverse=rGPen6cSMHQkAywh8vqI9JXiD2,key=lambda key: key[YYJQyRskpX8jv])
	for NTxA09tqrhpXbSfvCk5K,auwBLqWNdymHJ in frKzDoxVINlL397S:
		if iELueYz3J1FmxaW7vc:
			try: NTxA09tqrhpXbSfvCk5K = NTxA09tqrhpXbSfvCk5K.decode(df6QpwGxuJVZr)
			except: pass
			NTxA09tqrhpXbSfvCk5K = NTxA09tqrhpXbSfvCk5K.encode(df6QpwGxuJVZr)
		vv64odD3iYF = wkMR5x1gTWEQIc6qHCa.path.join(UxLks45wtR2pnIbmYVSNCM6,NTxA09tqrhpXbSfvCk5K)
		bP6z3OSLp7va(sVzojQerUqX(u"ࠨࡸ࡬ࡨࡪࡵࠧࢬ"),NTxA09tqrhpXbSfvCk5K,vv64odD3iYF,ZchUJdM93pTA7zG5(u"࠹࠳࠲ऽ"))
	return
def AWl1Phi9dmraZGF():
	UxLks45wtR2pnIbmYVSNCM6 = OXsckY7RzjCag9A.getSetting(EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠩࡤࡺ࠳ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠮ࡱࡣࡷ࡬ࠬࢭ"))
	if UxLks45wtR2pnIbmYVSNCM6: return UxLks45wtR2pnIbmYVSNCM6
	OXsckY7RzjCag9A.setSetting(GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠪࡥࡻ࠴ࡤࡰࡹࡱࡰࡴࡧࡤ࠯ࡲࡤࡸ࡭࠭ࢮ"),StqmrCIJX4T623w5j9NEonxfQ)
	return StqmrCIJX4T623w5j9NEonxfQ
def SpixCmzW39oKMOtv84D():
	UxLks45wtR2pnIbmYVSNCM6 = AWl1Phi9dmraZGF()
	ttzBY9jmXZNVeATrphCqvLo8Ma = A1AXKupEOfz(JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫࢯ"),iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,FRYcH4KL7e9gv5pEB(u"๋ࠬใศ่ࠣฮำุ๊็่่ࠢๆอสࠡษ็ฮา๋๊ๅࠩࢰ"),aqEsMBckT2bunGHfl48Wip+UxLks45wtR2pnIbmYVSNCM6+YoQW601K4fMJcsreDnGVE5wUZIy7+MgP8OjoaiWQEVG59(u"࠭࡜࡯࡞ࡱ๋ีอ่๊้่ࠠࠣอๆࠡฬัึ๏์ࠠๆๆไหฯࠦวๅใํำ๏๎ࠠศๆอ๎ࠥะอๆๆ๊หࠥอๆหࠢหหุะฮะษ่ࠤ์ึวࠡษ็ฬึ์วๆฮࠣ࠲ࠥํไࠡฬิ๎ิࠦส฻์ํีࠥอไๆๅส๊ࠥลࠧࢱ"))
	if ttzBY9jmXZNVeATrphCqvLo8Ma==ZchUJdM93pTA7zG5(u"࠱ा"):
		SSfQJNLw6iWKkD0hz8Amv4dlXF7Z = IXo1OsZjYzcJvpgUFedfi(JZszNnIEMAx28Yao0yqhiXGKOPb(u"࠴ि"),hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠧๆๅส๊ࠥะอๆ์็ࠤ๊๊แศฬࠣห้็๊ะ์๋ࠫࢲ"),JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠨ࡮ࡲࡧࡦࡲࠧࢳ"),iiy37aKq0pCEIOwfcTh61xb4U,BF6QAiLUNHh7rKOugaw,rGPen6cSMHQkAywh8vqI9JXiD2,UxLks45wtR2pnIbmYVSNCM6)
		U17QqF2gkI46 = A1AXKupEOfz(PtkEvXAqif14G20QZsaSyT(u"ࠩࡦࡩࡳࡺࡥࡳࠩࢴ"),iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,hhQwbeiNLoqFjX90fB7aG8VAs(u"้่ࠪอๆࠡฬัึ๏์ࠠๆๆไหฯࠦวๅฬะ้๏๊ࠧࢵ"),aqEsMBckT2bunGHfl48Wip+UxLks45wtR2pnIbmYVSNCM6+YoQW601K4fMJcsreDnGVE5wUZIy7+ZchUJdM93pTA7zG5(u"ࠫࡡࡴ࡜࡯้ำหࠥํ่ࠡษ็้่อๆࠡษ็ะิ๐ฯࠡๆอาื๐ๆࠡ็็ๅฬะࠠศๆไ๎ิ๐่ࠡษ็ฮ๏ࠦสฮ็็๋ฬࠦว็ฬࠣฬฬูสฯัส้ࠥํะศࠢส่อืๆศ็ฯࠤ࠳ࠦ็ๅࠢอี๏ีࠠศีอาิอๅ่ࠢหำ้อࠠๆ่ࠣห้๋ใศ่ࠣห้่ฯ๋็ࠣรࠬࢶ"))
		if U17QqF2gkI46==UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"࠳ी"):
			OXsckY7RzjCag9A.setSetting(JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠬࡧࡶ࠯ࡦࡲࡻࡳࡲ࡯ࡢࡦ࠱ࡴࡦࡺࡨࠨࢷ"),SSfQJNLw6iWKkD0hz8Amv4dlXF7Z)
			bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,HtK4o2sTPgA78U(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩࢸ"),UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠧห็ࠣฮ฿๐๊า่ࠢ็ฬ์ࠠหะี๎๋ࠦวๅ็็ๅฬะࠠศๆ่ั๊๊ษࠨࢹ"))
	return
def Ily7S5uCTQRbk82(kMqh74TPvpSDar59xQUjAyVlHes,asP7tCIR3S4wQ2ncHG0ZOVbNgWfhe6=iiy37aKq0pCEIOwfcTh61xb4U,website=iiy37aKq0pCEIOwfcTh61xb4U):
	WKquk5EaNr4RzVf(q1rohYuwnfpVZUa98L2CtQzmAcB,IIZ4e82HBP0oTmtOgaWY7hsMz(sQU2GnRoMwLK8CBdfzmNr4jXyO)+xpT28sXu051(u"ࠨࠢࠣࠤࡕࡸࡥࡱࡣࡵ࡭ࡳ࡭ࠠࡵࡱࠣࡨࡴࡽ࡮࡭ࡱࡤࡨࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨࢺ")+kMqh74TPvpSDar59xQUjAyVlHes+ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠩࠣࡡࠬࢻ"))
	if not asP7tCIR3S4wQ2ncHG0ZOVbNgWfhe6: asP7tCIR3S4wQ2ncHG0ZOVbNgWfhe6 = dVeG46wAnrtlpkbNPsvJ9(kMqh74TPvpSDar59xQUjAyVlHes)
	UxLks45wtR2pnIbmYVSNCM6 = AWl1Phi9dmraZGF()
	SWDcPHa03GEyls9UnN = mkT7KMxSV1PvEr5(BF6QAiLUNHh7rKOugaw)
	NTxA09tqrhpXbSfvCk5K = SWDcPHa03GEyls9UnN.replace(iFBmE2MUIpSu34wsd7Rf6z,HtK4o2sTPgA78U(u"ࠪࡣࠬࢼ"))
	NTxA09tqrhpXbSfvCk5K = VzC7H3ty4U8GkD(NTxA09tqrhpXbSfvCk5K)
	NTxA09tqrhpXbSfvCk5K = jXE2YHkswT8y(u"ࠫ࡫࡯࡬ࡦࡡࠪࢽ")+str(int(pwXCQWuGUMka2hFN))[-AbqCJZdWQP9j(u"࠷ु"):]+JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠬࡥࠧࢾ")+NTxA09tqrhpXbSfvCk5K+asP7tCIR3S4wQ2ncHG0ZOVbNgWfhe6
	BDg73oUhNMcT6sCO51K = wkMR5x1gTWEQIc6qHCa.path.join(UxLks45wtR2pnIbmYVSNCM6,NTxA09tqrhpXbSfvCk5K)
	qNojFLzuAkDZHEy1d4scer = {}
	qNojFLzuAkDZHEy1d4scer[yJeq1BjfiO4NFuwIEzxVLK6b9s(u"࠭ࡁࡤࡥࡨࡴࡹ࠳ࡅ࡯ࡥࡲࡨ࡮ࡴࡧࠨࢿ")] = iiy37aKq0pCEIOwfcTh61xb4U
	qNojFLzuAkDZHEy1d4scer[ZchUJdM93pTA7zG5(u"ࠧࡂࡥࡦࡩࡵࡺࠧࣀ")] = IpC4qHXRuyNFjzWv(u"ࠨࠬ࠲࠮ࠬࣁ")
	kMqh74TPvpSDar59xQUjAyVlHes = kMqh74TPvpSDar59xQUjAyVlHes.replace(JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠩࡹࡩࡷ࡯ࡦࡺࡲࡨࡩࡷࡃࡦࡢ࡮ࡶࡩࠬࣂ"),iiy37aKq0pCEIOwfcTh61xb4U)
	if ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺ࠽ࠨࣃ") in kMqh74TPvpSDar59xQUjAyVlHes:
		eCGwzSrqBmIv,QlAC9VBYGRckULquednZ0XvOxF4f5M = kMqh74TPvpSDar59xQUjAyVlHes.rsplit(ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴ࠾ࠩࣄ"),Y41NvKfOroMzGB8sEHy7wbXlc5(u"࠵ू"))
		QlAC9VBYGRckULquednZ0XvOxF4f5M = QlAC9VBYGRckULquednZ0XvOxF4f5M.replace(y6y5HtgXO4TkUbwVZ(u"ࠬࢂࠧࣅ"),iiy37aKq0pCEIOwfcTh61xb4U).replace(GGx4qyKP1vUtRghsE2WfaHLMXZ(u"࠭ࠦࠨࣆ"),iiy37aKq0pCEIOwfcTh61xb4U)
	else: eCGwzSrqBmIv,QlAC9VBYGRckULquednZ0XvOxF4f5M = kMqh74TPvpSDar59xQUjAyVlHes,None
	if not QlAC9VBYGRckULquednZ0XvOxF4f5M: QlAC9VBYGRckULquednZ0XvOxF4f5M = FgJLkYac7lQxEbs()
	if QlAC9VBYGRckULquednZ0XvOxF4f5M: qNojFLzuAkDZHEy1d4scer[Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫࣇ")] = QlAC9VBYGRckULquednZ0XvOxF4f5M
	if ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠨࡔࡨࡪࡪࡸࡥࡳ࠿ࠪࣈ") in eCGwzSrqBmIv: eCGwzSrqBmIv,aOtvl3xUCgoDIQN0HEVGYf = eCGwzSrqBmIv.rsplit(tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࡀࠫࣉ"),MgP8OjoaiWQEVG59(u"࠶ृ"))
	else: eCGwzSrqBmIv,aOtvl3xUCgoDIQN0HEVGYf = eCGwzSrqBmIv,iiy37aKq0pCEIOwfcTh61xb4U
	eCGwzSrqBmIv = eCGwzSrqBmIv.strip(GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠪࢀࠬ࣊")).strip(ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠫࠫ࠭࣋")).strip(FRYcH4KL7e9gv5pEB(u"ࠬࢂࠧ࣌")).strip(hhQwbeiNLoqFjX90fB7aG8VAs(u"࠭ࠦࠨ࣍"))
	aOtvl3xUCgoDIQN0HEVGYf = aOtvl3xUCgoDIQN0HEVGYf.replace(FRYcH4KL7e9gv5pEB(u"ࠧࡽࠩ࣎"),iiy37aKq0pCEIOwfcTh61xb4U).replace(vODxLKW5Ql6r4Fbm8(u"ࠨࠨ࣏ࠪ"),iiy37aKq0pCEIOwfcTh61xb4U)
	if aOtvl3xUCgoDIQN0HEVGYf:	qNojFLzuAkDZHEy1d4scer[EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴ࣐ࠪ")] = aOtvl3xUCgoDIQN0HEVGYf
	WKquk5EaNr4RzVf(q1rohYuwnfpVZUa98L2CtQzmAcB,IIZ4e82HBP0oTmtOgaWY7hsMz(sQU2GnRoMwLK8CBdfzmNr4jXyO)+TlGXWLYsV1z(u"ࠪࠤࠥࠦࡄࡰࡹࡱࡰࡴࡧࡤࡪࡰࡪࠤࡻ࡯ࡤࡦࡱࠣࡪ࡮ࡲࡥ࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝࣑ࠣࠫ")+eCGwzSrqBmIv+sVzojQerUqX(u"ࠫࠥࡣࠠࠡࠢࡋࡩࡦࡪࡥࡳࡵ࠽ࠤࡠ࣒ࠦࠧ")+str(qNojFLzuAkDZHEy1d4scer)+hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠬࠦ࡝ࠡࠢࠣࡊ࡮ࡲࡥ࠻ࠢ࡞ࠤ࣓ࠬ")+BDg73oUhNMcT6sCO51K+hhQwbeiNLoqFjX90fB7aG8VAs(u"࠭ࠠ࡞ࠩࣔ"))
	NQfBRbkJp193wuqET0A2 = jXE2YHkswT8y(u"࠷࠰࠳࠶ॄ")*jXE2YHkswT8y(u"࠷࠰࠳࠶ॄ")
	acmDvpIW6M1R = JZszNnIEMAx28Yao0yqhiXGKOPb(u"࠰ॅ")
	try:
		FwqIQhdn3u5Nf9O1aZXMoYlR =	WwMgozBIC32n9d0tyfp.getInfoLabel(YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠧࡔࡻࡶࡸࡪࡳ࠮ࡇࡴࡨࡩࡘࡶࡡࡤࡧࠪࣕ"))
		FwqIQhdn3u5Nf9O1aZXMoYlR = dEyT9xhGjolYzLCH7460w3.findall(MgP8OjoaiWQEVG59(u"ࠨ࡞ࡧ࠯ࠬࣖ"),FwqIQhdn3u5Nf9O1aZXMoYlR)
		acmDvpIW6M1R = int(FwqIQhdn3u5Nf9O1aZXMoYlR[FGTfwsjNrB8DvKSZhLIQAb1JnO])
	except: pass
	if not acmDvpIW6M1R:
		try:
			LLuPFgb5x37pU62rBHTG4MyY = wkMR5x1gTWEQIc6qHCa.statvfs(UxLks45wtR2pnIbmYVSNCM6)
			acmDvpIW6M1R = LLuPFgb5x37pU62rBHTG4MyY.f_frsize*LLuPFgb5x37pU62rBHTG4MyY.f_bavail//NQfBRbkJp193wuqET0A2
		except: pass
	if not acmDvpIW6M1R:
		try:
			LLuPFgb5x37pU62rBHTG4MyY = wkMR5x1gTWEQIc6qHCa.fstatvfs(UxLks45wtR2pnIbmYVSNCM6)
			acmDvpIW6M1R = LLuPFgb5x37pU62rBHTG4MyY.f_frsize*LLuPFgb5x37pU62rBHTG4MyY.f_bavail//NQfBRbkJp193wuqET0A2
		except: pass
	if not acmDvpIW6M1R:
		try:
			import shutil as S6pUxKcTIPD75OsJM9BemQ
			g2iSWGcIR9rdQyneOjAHk,a91ysWKEUuBA2xDplnwjvbT,Yu0AJGsIvP = S6pUxKcTIPD75OsJM9BemQ.disk_usage(UxLks45wtR2pnIbmYVSNCM6)
			acmDvpIW6M1R = Yu0AJGsIvP//NQfBRbkJp193wuqET0A2
		except: pass
	if not acmDvpIW6M1R:
		ggULVKqsMZbc1ynfBC7(tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠩࡵ࡭࡬࡮ࡴࠨࣗ"),CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ุ้ࠪออสࠢส่ฯิา๋่้ࠣัํ่ๅหࠪࣘ"),jXE2YHkswT8y(u"้๊ࠫริใࠣห้ฮั็ษ่ะࠥเ๊าࠢๅหิืࠠฤ่ࠣ๎าีฯࠡ็ๅำฬืࠠๆีสัฮࠦวๅฬัึ๏์ࠠศๆไหึเษࠡใํࠤัํวำๅࠣ์฾๊๊่ࠢไห๋ࠦสฮ็ํ่ࠥอไโ์า๎ํํวหࠢ็๊ࠥ๐ูๆๆࠣ฽๋ีใࠡว็ํࠥษๆࠡ์ๅ์๊ࠦๅษำ่ะ๏ࠦศา่ส้ัࠦใ้ัํࠤอำไ้ࠡำ๋ࠥอไๆึๆ่ฮࠦไศ่ࠣฮา๋๊ๅࠢส่ๆ๐ฯ๋๊๊หฯࠦโะࠢํือฮࠠศ็อ่ฬวࠠอ้สึ่ࠦศศๆ่่ๆอส๊๊ࠡิฬࠦแ๋้ࠣา฼๎ัสࠢ฼่๎ูࠦๆๆࠣะ์อาไࠢหูํืษࠡืะ๎าฯ้ࠠๆ๊ิฬࠦวๅีหฬ่ࠥวๆࠢส่๊ฮัๆฮ้ࠣษ่สศࠢห้๋฿ࠠศๆหี๋อๅอ่๊ࠢࠥะอๆ์็ࠤฬ๊แ๋ัํ์์อสࠨࣙ"),xpT28sXu051(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨࣚ"))
		WKquk5EaNr4RzVf(uiza5vIyTWtUeB8sXwAVYMFpgjrk,IIZ4e82HBP0oTmtOgaWY7hsMz(sQU2GnRoMwLK8CBdfzmNr4jXyO)+uuExaKGL7UONtevRd(u"࠭ࠠࠡࠢࡘࡲࡦࡨ࡬ࡦࠢࡷࡳࠥࡪࡥࡵࡧࡵࡱ࡮ࡴࡥࠡࡶ࡫ࡩࠥࡪࡩࡴ࡭ࠣࡪࡷ࡫ࡥࠡࡵࡳࡥࡨ࡫ࠧࣛ"))
		return BF6QAiLUNHh7rKOugaw
	if asP7tCIR3S4wQ2ncHG0ZOVbNgWfhe6==JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠧ࠯࡯࠶ࡹ࠽࠭ࣜ"):
		A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = VKTp8gacXPG9Zr4H3NQCM0O(sQU2GnRoMwLK8CBdfzmNr4jXyO,eCGwzSrqBmIv,qNojFLzuAkDZHEy1d4scer)
		if len(A7Ap2wdlxM)==jXE2YHkswT8y(u"࠱ॆ"):
			YYkhEn5xTXLUevzCVNB16mR(tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠨใื่ࠥ็๊ࠡวํะฬีࠠๆๆไࠤฬ๊สฮ็ํ่ࠬࣝ"),iiy37aKq0pCEIOwfcTh61xb4U)
			return BF6QAiLUNHh7rKOugaw
		elif len(A7Ap2wdlxM)==ZchUJdM93pTA7zG5(u"࠳े"): mmfrx2S5XqknFTDeRhj49LuYv1wW0 = CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"࠳ै")
		elif len(A7Ap2wdlxM)>GGx4qyKP1vUtRghsE2WfaHLMXZ(u"࠵ॉ"):
			mmfrx2S5XqknFTDeRhj49LuYv1wW0 = ccv1mVPUsnr(SaB5hx3PZwXRLtKgrTfQvId(u"ࠩสาฯืࠠศๆ่่ๆࠦวๅ็้หุฮࠧࣞ"), A7Ap2wdlxM)
			if mmfrx2S5XqknFTDeRhj49LuYv1wW0 == -UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"࠶ॊ") :
				YYkhEn5xTXLUevzCVNB16mR(tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠪฮ๊ࠦลๅ฼สลࠥอไหฯ่๎้࠭ࣟ"),iiy37aKq0pCEIOwfcTh61xb4U)
				return BF6QAiLUNHh7rKOugaw
		eCGwzSrqBmIv = duef0gb3Mi1AV5WpN8[mmfrx2S5XqknFTDeRhj49LuYv1wW0]
	OOoGJEcyReUAID7ZXCPKxL5 = HtK4o2sTPgA78U(u"࠶ो")
	import requests as Z4rotfjRx7A8U9Jgy0IaL1KnbTuB5
	if asP7tCIR3S4wQ2ncHG0ZOVbNgWfhe6==jXE2YHkswT8y(u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪ࣠"):
		BDg73oUhNMcT6sCO51K = BDg73oUhNMcT6sCO51K.rsplit(tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠬ࠴࡭࠴ࡷ࠻ࠫ࣡"))[FGTfwsjNrB8DvKSZhLIQAb1JnO]+EMO8gy4LrsNTh0knZwpSeU75APW(u"࠭࠮࡮ࡲ࠷ࠫ࣢")
		oikBndh2USEOV = MMCJxEfv0WUek(r3rnfZ7cdxzNFebIRaLSG6B,MgP8OjoaiWQEVG59(u"ࠧࡈࡇࡗࣣࠫ"),eCGwzSrqBmIv,iiy37aKq0pCEIOwfcTh61xb4U,qNojFLzuAkDZHEy1d4scer,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,jXE2YHkswT8y(u"ࠨࡆࡒ࡛ࡓࡒࡏࡂࡆ࠰ࡈࡔ࡝ࡎࡍࡑࡄࡈࡤ࡜ࡉࡅࡇࡒ࠱࠶ࡹࡴࠨࣤ"))
		eA07OE5JZFHbyk = oikBndh2USEOV.content
		P3tys0cXWbiIUKk7HQ6n89V = dEyT9xhGjolYzLCH7460w3.findall(EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠩࠦࡉ࡝࡚ࡉࡏࡈ࠽࠲࠯ࡅ࡛࡝ࡰ࡟ࡶࡢ࠮࠮ࠫࡁࠬ࡟ࡡࡴ࡜ࡳ࡟ࠪࣥ"),eA07OE5JZFHbyk+YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠪࡠࡳࡢࡲࠨࣦ"),dEyT9xhGjolYzLCH7460w3.DOTALL)
		if not P3tys0cXWbiIUKk7HQ6n89V:
			WKquk5EaNr4RzVf(uiza5vIyTWtUeB8sXwAVYMFpgjrk,IIZ4e82HBP0oTmtOgaWY7hsMz(sQU2GnRoMwLK8CBdfzmNr4jXyO)+TlGXWLYsV1z(u"ࠫࠥࠦࠠࡕࡪࡨࠤࡲ࠹ࡵ࠹ࠢࡩ࡭ࡱ࡫ࠠࡥ࡫ࡧࠤࡳࡵࡴࠡࡪࡤࡺࡪࠦࡴࡩࡧࠣࡶࡪࡷࡵࡪࡴࡨࡨࠥࡲࡩ࡯࡭ࡶࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧࣧ")+eCGwzSrqBmIv+ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠬࠦ࡝ࠨࣨ"))
			return BF6QAiLUNHh7rKOugaw
		fCXyTlcmF4WuetVork = P3tys0cXWbiIUKk7HQ6n89V[FGTfwsjNrB8DvKSZhLIQAb1JnO]
		if not fCXyTlcmF4WuetVork.startswith(hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"࠭ࡨࡵࡶࡳࣩࠫ")):
			if fCXyTlcmF4WuetVork.startswith(LyNiIHPOwD3hCUYEFM7(u"ࠧ࠰࠱ࠪ࣪")): fCXyTlcmF4WuetVork = eCGwzSrqBmIv.split(XrTw01KtLzbpoyMf(u"ࠨ࠼ࠪ࣫"),XrTw01KtLzbpoyMf(u"࠱ौ"))[FGTfwsjNrB8DvKSZhLIQAb1JnO]+LyNiIHPOwD3hCUYEFM7(u"ࠩ࠽ࠫ࣬")+fCXyTlcmF4WuetVork
			elif fCXyTlcmF4WuetVork.startswith(xpT28sXu051(u"ࠪ࠳࣭ࠬ")): fCXyTlcmF4WuetVork = F82MvyX4ThI6sbnA3efDoVS(eCGwzSrqBmIv,IpC4qHXRuyNFjzWv(u"ࠫࡺࡸ࡬ࠨ࣮"))+fCXyTlcmF4WuetVork
			else: fCXyTlcmF4WuetVork = eCGwzSrqBmIv.rsplit(hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠬ࠵࣯ࠧ"),tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"࠲्"))[FGTfwsjNrB8DvKSZhLIQAb1JnO]+uuExaKGL7UONtevRd(u"࠭࠯ࠨࣰ")+fCXyTlcmF4WuetVork
		oikBndh2USEOV = Z4rotfjRx7A8U9Jgy0IaL1KnbTuB5.request(sVzojQerUqX(u"ࠧࡈࡇࡗࣱࠫ"),fCXyTlcmF4WuetVork,headers=qNojFLzuAkDZHEy1d4scer,verify=BF6QAiLUNHh7rKOugaw)
		tSzKahr3HiOIZl0cxBX61ym79u4fD = oikBndh2USEOV.content
		Vd8seyTlfYpA1rq5McE7 = len(tSzKahr3HiOIZl0cxBX61ym79u4fD)
		m4rYSE1fQO = len(P3tys0cXWbiIUKk7HQ6n89V)
		OOoGJEcyReUAID7ZXCPKxL5 = Vd8seyTlfYpA1rq5McE7*m4rYSE1fQO
	else:
		Vd8seyTlfYpA1rq5McE7 = hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"࠳ॎ")*NQfBRbkJp193wuqET0A2
		oikBndh2USEOV = Z4rotfjRx7A8U9Jgy0IaL1KnbTuB5.request(CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠨࡉࡈࡘࣲࠬ"),eCGwzSrqBmIv,headers=qNojFLzuAkDZHEy1d4scer,verify=BF6QAiLUNHh7rKOugaw,stream=rGPen6cSMHQkAywh8vqI9JXiD2)
		if yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡐࡪࡴࡧࡵࡪࠪࣳ") in oikBndh2USEOV.headers: OOoGJEcyReUAID7ZXCPKxL5 = int(oikBndh2USEOV.headers[MgP8OjoaiWQEVG59(u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱ࡑ࡫࡮ࡨࡶ࡫ࠫࣴ")])
		m4rYSE1fQO = int(OOoGJEcyReUAID7ZXCPKxL5//Vd8seyTlfYpA1rq5McE7)
	g9knySsRtf6IXmjaVvUrE8i = int(OOoGJEcyReUAID7ZXCPKxL5//NQfBRbkJp193wuqET0A2)+yJeq1BjfiO4NFuwIEzxVLK6b9s(u"࠴ॏ")
	if OOoGJEcyReUAID7ZXCPKxL5<zmcGfOdvAjsELeJlP(u"࠶࠶࠶࠰࠱ॐ"):
		WKquk5EaNr4RzVf(uiza5vIyTWtUeB8sXwAVYMFpgjrk,IIZ4e82HBP0oTmtOgaWY7hsMz(sQU2GnRoMwLK8CBdfzmNr4jXyO)+vODxLKW5Ql6r4Fbm8(u"ࠫࠥࠦࠠࡗ࡫ࡧࡩࡴࠦࡦࡪ࡮ࡨࠤ࡮ࡹࠠࡵࡱࡲࠤࡸࡳࡡ࡭࡮ࠣࡳࡷࠦࡩࡵࠢ࡬ࡷࠥࡳ࠳ࡶ࠺ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭ࣵ")+eCGwzSrqBmIv+MgP8OjoaiWQEVG59(u"ࠬࠦ࡝࡚ࠡࠢࠣ࡮ࡪࡥࡰࠢࡩ࡭ࡱ࡫ࠠࡴ࡫ࡽࡩ࠿࡛ࣶࠦࠡࠩ")+str(g9knySsRtf6IXmjaVvUrE8i)+HtK4o2sTPgA78U(u"࠭ࠠࡎࡄࠣࡡࠥࠦࠠࡂࡸࡤ࡭ࡱࡧࡢ࡭ࡧࠣࡷ࡮ࢀࡥ࠻ࠢ࡞ࠤࠬࣷ")+str(acmDvpIW6M1R)+uuExaKGL7UONtevRd(u"ࠧࠡࡏࡅࠤࡢࠦࠠࠡࡈ࡬ࡰࡪࡀࠠ࡜ࠢࠪࣸ")+BDg73oUhNMcT6sCO51K+zmcGfOdvAjsELeJlP(u"ࠨࠢࡠࣹࠫ"))
		bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,xpT28sXu051(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࣺࠬ"),PtkEvXAqif14G20QZsaSyT(u"ࠪๅู๊ࠠโ์้ࠣ฾ืแสࠢะะ๊ࠦๅๅใࠣห้็๊ะ์๋ࠤศ๎ࠠศๆ่่ๆࠦี฻์ิࠤัีว๊ࠡ็๋ีอࠠๅษࠣ๎๊้ๆࠡๆ็ฬึ์วๆฮࠣฮา๋๊ๅ๊ࠢิฬࠦวๅ็็ๅࠬࣻ"))
		return BF6QAiLUNHh7rKOugaw
	AohmrtTGnINWxElO = ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"࠹࠶࠰॑")
	UUosbQZMgRS = acmDvpIW6M1R-g9knySsRtf6IXmjaVvUrE8i
	if UUosbQZMgRS<AohmrtTGnINWxElO:
		WKquk5EaNr4RzVf(uiza5vIyTWtUeB8sXwAVYMFpgjrk,IIZ4e82HBP0oTmtOgaWY7hsMz(sQU2GnRoMwLK8CBdfzmNr4jXyO)+tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠫࠥࠦࠠࡏࡱࡷࠤࡪࡴ࡯ࡶࡩ࡫ࠤࡩ࡯ࡳ࡬ࠢࡶࡴࡦࡩࡥࠡࡶࡲࠤࡩࡵࡷ࡯࡮ࡲࡥࡩࠦࡴࡩࡧࠣࡺ࡮ࡪࡥࡰࠢࡩ࡭ࡱ࡫ࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪࣼ")+eCGwzSrqBmIv+uuExaKGL7UONtevRd(u"ࠬࠦ࡝࡚ࠡࠢࠣ࡮ࡪࡥࡰࠢࡩ࡭ࡱ࡫ࠠࡴ࡫ࡽࡩ࠿࡛ࠦࠡࠩࣽ")+str(g9knySsRtf6IXmjaVvUrE8i)+IpC4qHXRuyNFjzWv(u"࠭ࠠࡎࡄࠣࡡࠥࠦࠠࡂࡸࡤ࡭ࡱࡧࡢ࡭ࡧࠣࡷ࡮ࢀࡥ࠻ࠢ࡞ࠤࠬࣾ")+str(acmDvpIW6M1R)+PtkEvXAqif14G20QZsaSyT(u"ࠧࠡࡏࡅࠤ࠲ࠦࠧࣿ")+str(AohmrtTGnINWxElO)+PtkEvXAqif14G20QZsaSyT(u"ࠨࠢࡐࡆࠥࡣࠠࠡࠢࡉ࡭ࡱ࡫࠺ࠡ࡝ࠣࠫऀ")+BDg73oUhNMcT6sCO51K+PtkEvXAqif14G20QZsaSyT(u"ࠩࠣࡡࠬँ"))
		bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"่ࠪฬ๊้ࠦฮาࠤู๊วฮหࠣ็ฬ็๊สࠢ็่ฯำๅ๋ๆࠪं"),UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠫฬ๊ๅๅใࠣห้๋ืๅ๊หࠤฯำๅ๋ๆ๊ࠤาาๅ่ࠢࠪः")+str(g9knySsRtf6IXmjaVvUrE8i)+Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠬࠦๅ๋฼สฬฬ๐ส๊ࠡฯ๋ฬุใࠡใํ๋๋ࠥำศฯฬࠤๆอั฻หࠣࠫऄ")+str(acmDvpIW6M1R)+sVzojQerUqX(u"࠭ࠠๆ์฽หออ๊ห๋่้๋ࠢอศใ฻อࠥ฿ไ๊ࠢ฼้้ࠦฬ่ษี็ࠥฮฯู้่้ࠣอใๅࠢํะอࠦลษไสลࠥ࠭अ")+str(AohmrtTGnINWxElO)+PtkEvXAqif14G20QZsaSyT(u"ࠧࠡ็ํ฾ฬฮว๋ฬࠣๅฬืฺสࠢาหห๋ว๊๊ࠡิฬࠦๅฺ่ส๋ࠥษๆࠡฮ๊หื้ࠠๅษࠣฮําฯࠡใํ๋๋ࠥำศฯฬࠤ่อแ๋ห่ࠣฯำๅ๋ๆ้้ࠣ็ࠠศๆไ๎ิ๐่ࠡษ็้฼๊่ษࠩआ"))
		return BF6QAiLUNHh7rKOugaw
	U17QqF2gkI46 = A1AXKupEOfz(SaB5hx3PZwXRLtKgrTfQvId(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨइ"),iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,SaB5hx3PZwXRLtKgrTfQvId(u"๊่ࠩࠥะั๋ัࠣฮา๋๊ๅࠢส่๊๊แࠡมࠪई"),tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠪห้๋ไโࠢส่๊฽ไ้สࠣัั๋็ࠡฬๅี๏ฮวࠡࠩउ")+str(g9knySsRtf6IXmjaVvUrE8i)+FRYcH4KL7e9gv5pEB(u"๋๊ࠫࠥ฻ษหห๏ะ้ࠠฮ๊หื้ࠠโ์๊ࠤู๊วฮหࠣๅฬืฺสࠢอๆึ๐ศศࠢࠪऊ")+str(acmDvpIW6M1R)+CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠬࠦๅ๋฼สฬฬ๐ส๊๊ࠡิฬࠦวๅ็็ๅ่ࠥฯࠡ์ะฮฬาࠠษ฻ูࠤฬ๊่ใฬ่้ࠣะอๆ์็ࠤ๊์ࠠศๆศ๊ฯืๆหࠢศ่๎ࠦฬ่ษี็ࠥ࠴่ࠠๆࠣห๋ะࠠๆฬฦ็ิ่ࠦหำํำࠥอไศีอ้ึอัࠡสอั๊๐ไࠡ็็ๅࠥอไโ์า๎ํࠦฟࠨऋ"))
	if U17QqF2gkI46!=SaB5hx3PZwXRLtKgrTfQvId(u"࠷॒"):
		bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,GGx4qyKP1vUtRghsE2WfaHLMXZ(u"࠭สๆࠢศ่฿อมࠡ฻่่๏ฯࠠหฯ่๎้ࠦๅๅใࠣห้็๊ะ์๋ࠫऌ"))
		WKquk5EaNr4RzVf(q1rohYuwnfpVZUa98L2CtQzmAcB,IIZ4e82HBP0oTmtOgaWY7hsMz(sQU2GnRoMwLK8CBdfzmNr4jXyO)+GGx4qyKP1vUtRghsE2WfaHLMXZ(u"࡙ࠧࠡࠢࠣࡸ࡫ࡲࠡࡥࡤࡲࡨ࡫࡬ࡦࡦࠣࡸ࡭࡫ࠠࡥࡱࡺࡲࡱࡵࡡࡥࠢࡲࡪࠥࡺࡨࡦࠢࡹ࡭ࡩ࡫࡯ࠡࡨ࡬ࡰࡪࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩऍ")+eCGwzSrqBmIv+LyNiIHPOwD3hCUYEFM7(u"ࠨࠢࡠࠤࠥࠦࡆࡪ࡮ࡨ࠾ࠥࡡࠠࠨऎ")+BDg73oUhNMcT6sCO51K+hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠩࠣࡡࠬए"))
		return BF6QAiLUNHh7rKOugaw
	WKquk5EaNr4RzVf(q1rohYuwnfpVZUa98L2CtQzmAcB,IIZ4e82HBP0oTmtOgaWY7hsMz(sQU2GnRoMwLK8CBdfzmNr4jXyO)+tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠪࠤࠥࠦࡄࡰࡹࡱࡰࡴࡧࡤࠡࡵࡷࡥࡷࡺࡥࡥࠢࡶࡹࡨࡩࡥࡴࡵࡩࡹࡱࡲࡹࠨऐ"))
	sspk8CPTnaqeyzALQuD6ExX = BH5w8KScjpRhAkI7PlqDU()
	sspk8CPTnaqeyzALQuD6ExX.create(BDg73oUhNMcT6sCO51K,uuExaKGL7UONtevRd(u"ࠫฬ๊ำุำࠣๅํ่่๊้่ࠠࠣอๆࠡฬัึ๏์ࠠๆๆไࠤฬ๊แ๋ัํ์ࠬऑ"))
	VCi9ed3oSGMDmRw2IQKyvUck8hTXZ = rGPen6cSMHQkAywh8vqI9JXiD2
	QhNGvIF4YS2a5gxLAcy1k6VW3w = X2cQ5NCPvkMieBW7oASspFjE.time()
	if not IiCsQD91HF.ic2FB5X43kWzyTKtNE:
		bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,AbqCJZdWQP9j(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨऒ"),UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"࠭ศิสหࠤ฾ีๅࠡษ็ฮอืูࠡฬ่ࠤสฺ๊ศรࠣฮา๋๊ๅ่่ࠢๆࠦวๅใํำ๏๎ࠧओ"))
		return BF6QAiLUNHh7rKOugaw
	if J1MoiYc7ZwzKS: m8dTraOy5MxvW9gJBhAPRQDbswSFoc = open(BDg73oUhNMcT6sCO51K,ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠧࡸࡤࠪऔ"))
	else: m8dTraOy5MxvW9gJBhAPRQDbswSFoc = open(BDg73oUhNMcT6sCO51K.decode(df6QpwGxuJVZr),tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠨࡹࡥࠫक"))
	if asP7tCIR3S4wQ2ncHG0ZOVbNgWfhe6==GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨख"):
		for o6oXFxmE1bQC in range(y6y5HtgXO4TkUbwVZ(u"࠱॓"),m4rYSE1fQO+y6y5HtgXO4TkUbwVZ(u"࠱॓")):
			fCXyTlcmF4WuetVork = P3tys0cXWbiIUKk7HQ6n89V[o6oXFxmE1bQC-UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"࠲॔")]
			if not fCXyTlcmF4WuetVork.startswith(CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠪ࡬ࡹࡺࡰࠨग")):
				if fCXyTlcmF4WuetVork.startswith(jXE2YHkswT8y(u"ࠫ࠴࠵ࠧघ")): fCXyTlcmF4WuetVork = eCGwzSrqBmIv.split(ZchUJdM93pTA7zG5(u"ࠬࡀࠧङ"),jXE2YHkswT8y(u"࠳ॕ"))[FGTfwsjNrB8DvKSZhLIQAb1JnO]+jXE2YHkswT8y(u"࠭࠺ࠨच")+fCXyTlcmF4WuetVork
				elif fCXyTlcmF4WuetVork.startswith(CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠧ࠰ࠩछ")): fCXyTlcmF4WuetVork = F82MvyX4ThI6sbnA3efDoVS(eCGwzSrqBmIv,ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠨࡷࡵࡰࠬज"))+fCXyTlcmF4WuetVork
				else: fCXyTlcmF4WuetVork = eCGwzSrqBmIv.rsplit(jXE2YHkswT8y(u"ࠩ࠲ࠫझ"),FRYcH4KL7e9gv5pEB(u"࠴ॖ"))[FGTfwsjNrB8DvKSZhLIQAb1JnO]+ZchUJdM93pTA7zG5(u"ࠪ࠳ࠬञ")+fCXyTlcmF4WuetVork
			oikBndh2USEOV = Z4rotfjRx7A8U9Jgy0IaL1KnbTuB5.request(AbqCJZdWQP9j(u"ࠫࡌࡋࡔࠨट"),fCXyTlcmF4WuetVork,headers=qNojFLzuAkDZHEy1d4scer,verify=BF6QAiLUNHh7rKOugaw)
			tSzKahr3HiOIZl0cxBX61ym79u4fD = oikBndh2USEOV.content
			oikBndh2USEOV.close()
			m8dTraOy5MxvW9gJBhAPRQDbswSFoc.write(tSzKahr3HiOIZl0cxBX61ym79u4fD)
			mi4AfdRzjbaogrM25v1nkGFwNS6tBD = X2cQ5NCPvkMieBW7oASspFjE.time()
			kOiNeGID79CudjolPA = mi4AfdRzjbaogrM25v1nkGFwNS6tBD-QhNGvIF4YS2a5gxLAcy1k6VW3w
			D0iWGkLV9p = kOiNeGID79CudjolPA//o6oXFxmE1bQC
			Iusw9AOf3z1MB4g7UycEt8Y2RGeJ = D0iWGkLV9p*(m4rYSE1fQO+GGx4qyKP1vUtRghsE2WfaHLMXZ(u"࠵ॗ"))
			zmnuHLi0KP7q9rBTypGvS = Iusw9AOf3z1MB4g7UycEt8Y2RGeJ-kOiNeGID79CudjolPA
			o8oBqwQFbU2uL3SEGD0lgWO4xRnJYC(sspk8CPTnaqeyzALQuD6ExX,int(ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"࠷࠰࠱ख़")*o6oXFxmE1bQC//(m4rYSE1fQO+sVzojQerUqX(u"࠶क़"))),tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠬอไิูิࠤๆ๎โ้๋ࠡࠤ๊้ว็ࠢอาื๐ๆࠡ็็ๅࠥอไโ์า๎ํ࠭ठ"),L90uqo28xEKSFUwYTcm51yRWZIkft(u"࠭ฬๅส้้ࠣ็ࠠศๆไ๎ิ๐่࠻࠯ࠣห้าายࠢิๆ๊࠭ड"),str(o6oXFxmE1bQC*Vd8seyTlfYpA1rq5McE7//NQfBRbkJp193wuqET0A2)+PtkEvXAqif14G20QZsaSyT(u"ࠧ࠰ࠩढ")+str(g9knySsRtf6IXmjaVvUrE8i)+HtK4o2sTPgA78U(u"ࠨࠢࡐࡆ๊ࠥࠦࠠࠡๅฮ๋ࠥสษไํ࠾ࠥ࠭ण")+X2cQ5NCPvkMieBW7oASspFjE.strftime(jXE2YHkswT8y(u"ࠤࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠦत"),X2cQ5NCPvkMieBW7oASspFjE.gmtime(zmnuHLi0KP7q9rBTypGvS))+uuExaKGL7UONtevRd(u"ࠪࠤๅ࠭थ"))
			if sspk8CPTnaqeyzALQuD6ExX.iscanceled():
				VCi9ed3oSGMDmRw2IQKyvUck8hTXZ = BF6QAiLUNHh7rKOugaw
				break
	else:
		o6oXFxmE1bQC = jXE2YHkswT8y(u"࠰ग़")
		for tSzKahr3HiOIZl0cxBX61ym79u4fD in oikBndh2USEOV.iter_content(chunk_size=Vd8seyTlfYpA1rq5McE7):
			m8dTraOy5MxvW9gJBhAPRQDbswSFoc.write(tSzKahr3HiOIZl0cxBX61ym79u4fD)
			o6oXFxmE1bQC = o6oXFxmE1bQC+XrTw01KtLzbpoyMf(u"࠲ज़")
			mi4AfdRzjbaogrM25v1nkGFwNS6tBD = X2cQ5NCPvkMieBW7oASspFjE.time()
			kOiNeGID79CudjolPA = mi4AfdRzjbaogrM25v1nkGFwNS6tBD-QhNGvIF4YS2a5gxLAcy1k6VW3w
			D0iWGkLV9p = kOiNeGID79CudjolPA/o6oXFxmE1bQC
			Iusw9AOf3z1MB4g7UycEt8Y2RGeJ = D0iWGkLV9p*(m4rYSE1fQO+YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"࠳ड़"))
			zmnuHLi0KP7q9rBTypGvS = Iusw9AOf3z1MB4g7UycEt8Y2RGeJ-kOiNeGID79CudjolPA
			o8oBqwQFbU2uL3SEGD0lgWO4xRnJYC(sspk8CPTnaqeyzALQuD6ExX,int(jXE2YHkswT8y(u"࠵࠵࠶फ़")*o6oXFxmE1bQC/(m4rYSE1fQO+EMO8gy4LrsNTh0knZwpSeU75APW(u"࠴ढ़"))),XrTw01KtLzbpoyMf(u"ࠫฬ๊ำุำࠣๅํ่่๊้่ࠠࠣอๆࠡฬัึ๏์ࠠๆๆไࠤฬ๊แ๋ัํ์ࠬद"),XrTw01KtLzbpoyMf(u"ࠬาไษ่่ࠢๆࠦวๅใํำ๏๎࠺࠮ࠢส่ัุมࠡำๅ้ࠬध"),str(o6oXFxmE1bQC*Vd8seyTlfYpA1rq5McE7//NQfBRbkJp193wuqET0A2)+UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"࠭࠯ࠨन")+str(g9knySsRtf6IXmjaVvUrE8i)+tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠧࠡࡏࡅࠤ้ࠥࠦࠠไอࠤ๊ะศใ์࠽ࠤࠬऩ")+X2cQ5NCPvkMieBW7oASspFjE.strftime(xpT28sXu051(u"ࠣࠧࡋ࠾ࠪࡓ࠺ࠦࡕࠥप"),X2cQ5NCPvkMieBW7oASspFjE.gmtime(zmnuHLi0KP7q9rBTypGvS))+hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠩࠣไࠬफ"))
			if sspk8CPTnaqeyzALQuD6ExX.iscanceled():
				VCi9ed3oSGMDmRw2IQKyvUck8hTXZ = BF6QAiLUNHh7rKOugaw
				break
		oikBndh2USEOV.close()
	m8dTraOy5MxvW9gJBhAPRQDbswSFoc.close()
	sspk8CPTnaqeyzALQuD6ExX.close()
	if not VCi9ed3oSGMDmRw2IQKyvUck8hTXZ:
		WKquk5EaNr4RzVf(q1rohYuwnfpVZUa98L2CtQzmAcB,IIZ4e82HBP0oTmtOgaWY7hsMz(sQU2GnRoMwLK8CBdfzmNr4jXyO)+ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠪࠤࠥࠦࡕࡴࡧࡵࠤࡨࡧ࡮ࡤࡧ࡯ࡩࡩ࠵ࡩ࡯ࡶࡨࡶࡷࡻࡰࡵࡧࡧࠤࡹ࡮ࡥࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࠣࡴࡷࡵࡣࡦࡵࡶࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧब")+eCGwzSrqBmIv+ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠫࠥࡣࠠࠡࠢࡉ࡭ࡱ࡫࠺ࠡ࡝ࠣࠫभ")+BDg73oUhNMcT6sCO51K+L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠬࠦ࡝ࠨम"))
		bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩय"),ZchUJdM93pTA7zG5(u"ࠧษฯึฬࠥ฽ไษๅࠣฮ๊ࠦลๅ฼สลࠥ฿ๅๅ์ฬࠤฯำๅ๋ๆ้้ࠣ็ࠠศๆไ๎ิ๐่ࠨर"))
		return rGPen6cSMHQkAywh8vqI9JXiD2
	WKquk5EaNr4RzVf(q1rohYuwnfpVZUa98L2CtQzmAcB,IIZ4e82HBP0oTmtOgaWY7hsMz(sQU2GnRoMwLK8CBdfzmNr4jXyO)+tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠨࠢࠣࠤ࡛࡯ࡤࡦࡱࠣࡪ࡮ࡲࡥࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࡨࡨࠥࡹࡵࡤࡥࡨࡷࡸ࡬ࡵ࡭࡮ࡼࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧऱ")+eCGwzSrqBmIv+IpC4qHXRuyNFjzWv(u"ࠩࠣࡡࠥࠦࠠࡇ࡫࡯ࡩ࠿࡛ࠦࠡࠩल")+BDg73oUhNMcT6sCO51K+SaB5hx3PZwXRLtKgrTfQvId(u"ࠪࠤࡢ࠭ळ"))
	bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧऴ"),MgP8OjoaiWQEVG59(u"ࠬะๅࠡฬะ้๏๊ࠠๆๆไࠤฬ๊แ๋ัํ์ࠥฮๆอษะࠫव"))
	return rGPen6cSMHQkAywh8vqI9JXiD2
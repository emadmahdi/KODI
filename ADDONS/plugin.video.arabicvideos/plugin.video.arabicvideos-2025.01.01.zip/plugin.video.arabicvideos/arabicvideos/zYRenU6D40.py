# -*- coding: utf-8 -*-
from braVAkwfBN import *
sQU2GnRoMwLK8CBdfzmNr4jXyO = 'SERIES4WATCH'
headers = { 'User-Agent' : iiy37aKq0pCEIOwfcTh61xb4U }
ooQEi5O6tYsGVF8LU0TC3hgMeflBwH = '_SFW_'
JaQEtCzDXgos1cdZN = gZ4LwbKaOm[sQU2GnRoMwLK8CBdfzmNr4jXyO][0]
def sHVM8YchrDjZAJ7(mode,url,text):
	if   mode==210: EA7FzO1kMZGQXDd2giB0cwLom = jihuS9LVAvTrClPapMbUEwfn8XN()
	elif mode==211: EA7FzO1kMZGQXDd2giB0cwLom = AIQeNZP4FMDw9S(url)
	elif mode==212: EA7FzO1kMZGQXDd2giB0cwLom = TW6Z0zqaDl(url)
	elif mode==213: EA7FzO1kMZGQXDd2giB0cwLom = YNcMvoVF5swlDBJI7PL(url)
	elif mode==214: EA7FzO1kMZGQXDd2giB0cwLom = Oq7dXfWn6YwkPDK(url)
	elif mode==215: EA7FzO1kMZGQXDd2giB0cwLom = A0oYjNZw34rlbstL2uKO(url)
	elif mode==218: EA7FzO1kMZGQXDd2giB0cwLom = YQKHRwPDsohO()
	elif mode==219: EA7FzO1kMZGQXDd2giB0cwLom = mUhJtHB9nw(text)
	else: EA7FzO1kMZGQXDd2giB0cwLom = False
	return EA7FzO1kMZGQXDd2giB0cwLom
def YQKHRwPDsohO():
	message = 'هذا الموقع تغير بالكامل ... وبحاجة الى اعادة برمجة من الصفر ... والمبرمج حاليا مشغول ويعاني من وعكة صحية ... ولهذا سوف يبقى الموقع مغلق الى ما شاء الله'
	bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'رسالة من المبرمج','الموقع تغير بالكامل',message)
	return
def jihuS9LVAvTrClPapMbUEwfn8XN():
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'بحث في الموقع',iiy37aKq0pCEIOwfcTh61xb4U,219,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'_REMEMBERRESULTS_')
	url = JaQEtCzDXgos1cdZN+'/getpostsPin?type=one&data=pin&limit=25'
	bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'المميزة',url,211)
	Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(Dxc7GChQwZ4kOlKHSbL06agnB,JaQEtCzDXgos1cdZN,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,'SERIES4WATCH-MENU-1st')
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('FiltersButtons(.*?)</div>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
	items = dEyT9xhGjolYzLCH7460w3.findall('data-get="(.*?)".*?</i>(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	for fCXyTlcmF4WuetVork,title in items:
		url = JaQEtCzDXgos1cdZN+'/getposts?type=one&data='+fCXyTlcmF4WuetVork
		bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,url,211)
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('navigation-menu(.*?)</div>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
	items = dEyT9xhGjolYzLCH7460w3.findall('href="(http.*?)">(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	a8GCLIuWNkS = ['مسلسلات انمي','الرئيسية']
	for fCXyTlcmF4WuetVork,title in items:
		title = title.strip(iFBmE2MUIpSu34wsd7Rf6z)
		if not any(aasX2cby4Vo5rTgB in title for aasX2cby4Vo5rTgB in a8GCLIuWNkS):
			bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,211)
	return Vxz6OndPIX4g2kaRp7
def AIQeNZP4FMDw9S(url):
	Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(PNjZMS7nxa9clHusz1,url,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,'SERIES4WATCH-TITLES-1st')
	if 'getposts' in url or '/search?s=' in url: PPH1sQtTkDBbnlYpZfo5 = Vxz6OndPIX4g2kaRp7
	else:
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('MediaGrid"(.*?)class="pagination"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if UUIohmv597bO83YCLgWS: PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		else: return
	items = dEyT9xhGjolYzLCH7460w3.findall('src="(.*?)".*?href="(.*?)".*?<h3>(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	u3Rztpl4VHO9GZ7jCBM65kvS = []
	QIEZDm5syS6Lvulf0 = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for C0dvhEbPWYlUtimM3x,fCXyTlcmF4WuetVork,title in items:
		if '/series/' in fCXyTlcmF4WuetVork: continue
		fCXyTlcmF4WuetVork = a9I3YZjc6ySDPE4Kp(fCXyTlcmF4WuetVork).strip('/')
		title = JIY6A30UOsQboNVqCn(title)
		title = title.strip(iFBmE2MUIpSu34wsd7Rf6z)
		if '/film/' in fCXyTlcmF4WuetVork or any(aasX2cby4Vo5rTgB in title for aasX2cby4Vo5rTgB in QIEZDm5syS6Lvulf0):
			bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,212,C0dvhEbPWYlUtimM3x)
		elif '/episode/' in fCXyTlcmF4WuetVork and 'الحلقة' in title:
			zN7sZyFnw5JTE8 = dEyT9xhGjolYzLCH7460w3.findall('(.*?) الحلقة \d+',title,dEyT9xhGjolYzLCH7460w3.DOTALL)
			if zN7sZyFnw5JTE8:
				title = '_MOD_' + zN7sZyFnw5JTE8[0]
				if title not in u3Rztpl4VHO9GZ7jCBM65kvS:
					bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,213,C0dvhEbPWYlUtimM3x)
					u3Rztpl4VHO9GZ7jCBM65kvS.append(title)
		else: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,213,C0dvhEbPWYlUtimM3x)
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('class="pagination(.*?)</div>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('<a href=["\'](http.*?)["\'].*?>(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title in items:
			fCXyTlcmF4WuetVork = JIY6A30UOsQboNVqCn(fCXyTlcmF4WuetVork)
			title = JIY6A30UOsQboNVqCn(title)
			title = title.replace('الصفحة ',iiy37aKq0pCEIOwfcTh61xb4U)
			if title!=iiy37aKq0pCEIOwfcTh61xb4U: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'صفحة '+title,fCXyTlcmF4WuetVork,211)
	return
def YNcMvoVF5swlDBJI7PL(url):
	KEAY7S3Up1f0HFjkVcLxP5se9D,items,v7CQL4K56PzGRO = -1,[],[]
	Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(PNjZMS7nxa9clHusz1,url,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,'SERIES4WATCH-EPISODES-1st')
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('ti-list-numbered(.*?)</div>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		ddfSDGyqEc = iiy37aKq0pCEIOwfcTh61xb4U.join(UUIohmv597bO83YCLgWS)
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)"',ddfSDGyqEc,dEyT9xhGjolYzLCH7460w3.DOTALL)
	items.append(url)
	items = set(items)
	for fCXyTlcmF4WuetVork in items:
		fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork.strip('/')
		title = '_MOD_' + fCXyTlcmF4WuetVork.split('/')[-1].replace('-',iFBmE2MUIpSu34wsd7Rf6z)
		MGUpOVcyHm3P9xC8ij76QlfY = dEyT9xhGjolYzLCH7460w3.findall('الحلقة-(\d+)',fCXyTlcmF4WuetVork.split('/')[-1],dEyT9xhGjolYzLCH7460w3.DOTALL)
		if MGUpOVcyHm3P9xC8ij76QlfY: MGUpOVcyHm3P9xC8ij76QlfY = MGUpOVcyHm3P9xC8ij76QlfY[0]
		else: MGUpOVcyHm3P9xC8ij76QlfY = '0'
		v7CQL4K56PzGRO.append([fCXyTlcmF4WuetVork,title,MGUpOVcyHm3P9xC8ij76QlfY])
	items = sorted(v7CQL4K56PzGRO, reverse=False, key=lambda key: int(key[2]))
	CuW69BJrQeUk8AMsPm = str(items).count('/season/')
	KEAY7S3Up1f0HFjkVcLxP5se9D = str(items).count('/episode/')
	if CuW69BJrQeUk8AMsPm>1 and KEAY7S3Up1f0HFjkVcLxP5se9D>0 and '/season/' not in url:
		for fCXyTlcmF4WuetVork,title,MGUpOVcyHm3P9xC8ij76QlfY in items:
			if '/season/' in fCXyTlcmF4WuetVork: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,213)
	else:
		for fCXyTlcmF4WuetVork,title,MGUpOVcyHm3P9xC8ij76QlfY in items:
			if '/season/' not in fCXyTlcmF4WuetVork: bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,212)
	return
def TW6Z0zqaDl(url):
	duef0gb3Mi1AV5WpN8 = []
	ng8RFTvpBOxuMa2ySjYWqVZX = url.split('/')
	Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(Dxc7GChQwZ4kOlKHSbL06agnB,url,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,'SERIES4WATCH-PLAY-1st')
	if '/watch/' in Vxz6OndPIX4g2kaRp7:
		eCGwzSrqBmIv = url.replace(ng8RFTvpBOxuMa2ySjYWqVZX[3],'watch')
		z0spMAOfJElv6L1K9ae = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(Dxc7GChQwZ4kOlKHSbL06agnB,eCGwzSrqBmIv,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,'SERIES4WATCH-PLAY-2nd')
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('class="servers-list(.*?)</div>',z0spMAOfJElv6L1K9ae,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if UUIohmv597bO83YCLgWS:
			PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
			items = dEyT9xhGjolYzLCH7460w3.findall('data-embedd="(.*?)".*?server_image">\n(.*?)\n',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
			if items:
				id = dEyT9xhGjolYzLCH7460w3.findall('post_id=(.*?)"',z0spMAOfJElv6L1K9ae,dEyT9xhGjolYzLCH7460w3.DOTALL)
				if id:
					qCVlj6LiNza2MbZosSecpWQGuJd7 = id[0]
					for fCXyTlcmF4WuetVork,title in items:
						fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN+'/?postid='+qCVlj6LiNza2MbZosSecpWQGuJd7+'&serverid='+fCXyTlcmF4WuetVork+'?named='+title+'__watch'
						duef0gb3Mi1AV5WpN8.append(fCXyTlcmF4WuetVork)
			else:
				items = dEyT9xhGjolYzLCH7460w3.findall('data-embedd=".*?(http.*?)("|&quot;)',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
				for fCXyTlcmF4WuetVork,qBIUYtOjTAx0 in items:
					duef0gb3Mi1AV5WpN8.append(fCXyTlcmF4WuetVork)
	if '/download/' in Vxz6OndPIX4g2kaRp7:
		eCGwzSrqBmIv = url.replace(ng8RFTvpBOxuMa2ySjYWqVZX[3],'download')
		z0spMAOfJElv6L1K9ae = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(Dxc7GChQwZ4kOlKHSbL06agnB,eCGwzSrqBmIv,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,'SERIES4WATCH-PLAY-3rd')
		id = dEyT9xhGjolYzLCH7460w3.findall('postId:"(.*?)"',z0spMAOfJElv6L1K9ae,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if id:
			qCVlj6LiNza2MbZosSecpWQGuJd7 = id[0]
			rzR9SN7ApZuQhTDWEX3V6ga = { 'User-Agent':iiy37aKq0pCEIOwfcTh61xb4U , 'X-Requested-With':'XMLHttpRequest' }
			eCGwzSrqBmIv = JaQEtCzDXgos1cdZN + '/ajaxCenter?_action=getdownloadlinks&postId='+qCVlj6LiNza2MbZosSecpWQGuJd7
			z0spMAOfJElv6L1K9ae = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(Dxc7GChQwZ4kOlKHSbL06agnB,eCGwzSrqBmIv,iiy37aKq0pCEIOwfcTh61xb4U,rzR9SN7ApZuQhTDWEX3V6ga,iiy37aKq0pCEIOwfcTh61xb4U,'SERIES4WATCH-PLAY-4th')
			UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('<h3.*?(\d+)(.*?)</div>',z0spMAOfJElv6L1K9ae,dEyT9xhGjolYzLCH7460w3.DOTALL)
			if UUIohmv597bO83YCLgWS:
				for T27hnaIAydbzjRU93v5FBtfPGXQp,PPH1sQtTkDBbnlYpZfo5 in UUIohmv597bO83YCLgWS:
					items = dEyT9xhGjolYzLCH7460w3.findall('<td>(.*?)<.*?href="(.*?)"',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
					for name,fCXyTlcmF4WuetVork in items:
						duef0gb3Mi1AV5WpN8.append(fCXyTlcmF4WuetVork+'?named='+name+'__download'+'____'+T27hnaIAydbzjRU93v5FBtfPGXQp)
			else:
				UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('<h6(.*?)</table>',z0spMAOfJElv6L1K9ae,dEyT9xhGjolYzLCH7460w3.DOTALL)
				if not UUIohmv597bO83YCLgWS: UUIohmv597bO83YCLgWS = [z0spMAOfJElv6L1K9ae]
				for PPH1sQtTkDBbnlYpZfo5 in UUIohmv597bO83YCLgWS:
					name = iiy37aKq0pCEIOwfcTh61xb4U
					items = dEyT9xhGjolYzLCH7460w3.findall('href="(http.*?)"',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
					for fCXyTlcmF4WuetVork in items:
						Zw4M5DUStdE6xp7GI = '&&' + fCXyTlcmF4WuetVork.split('/')[2].lower() + '&&'
						Zw4M5DUStdE6xp7GI = Zw4M5DUStdE6xp7GI.replace('.com&&',iiy37aKq0pCEIOwfcTh61xb4U).replace('.co&&',iiy37aKq0pCEIOwfcTh61xb4U)
						Zw4M5DUStdE6xp7GI = Zw4M5DUStdE6xp7GI.replace('.net&&',iiy37aKq0pCEIOwfcTh61xb4U).replace('.org&&',iiy37aKq0pCEIOwfcTh61xb4U)
						Zw4M5DUStdE6xp7GI = Zw4M5DUStdE6xp7GI.replace('.live&&',iiy37aKq0pCEIOwfcTh61xb4U).replace('.online&&',iiy37aKq0pCEIOwfcTh61xb4U)
						Zw4M5DUStdE6xp7GI = Zw4M5DUStdE6xp7GI.replace('&&hd.',iiy37aKq0pCEIOwfcTh61xb4U).replace('&&www.',iiy37aKq0pCEIOwfcTh61xb4U)
						Zw4M5DUStdE6xp7GI = Zw4M5DUStdE6xp7GI.replace('&&',iiy37aKq0pCEIOwfcTh61xb4U)
						fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork + '?named=' + name + Zw4M5DUStdE6xp7GI + '__download'
						duef0gb3Mi1AV5WpN8.append(fCXyTlcmF4WuetVork)
	import lqBJGK8hXO
	lqBJGK8hXO.ZDg1HavwueT85mcAOorC4hnS(duef0gb3Mi1AV5WpN8,sQU2GnRoMwLK8CBdfzmNr4jXyO,'video',url)
	return
def mUhJtHB9nw(search):
	search,brFQp5vmgJWdZfEkCBOlu9c,showDialogs = XkYnev3ZCA6ahO94(search)
	if search==iiy37aKq0pCEIOwfcTh61xb4U: search = TTBf6S08q1NKXd5v9wa()
	if search==iiy37aKq0pCEIOwfcTh61xb4U: return
	search = search.replace(iFBmE2MUIpSu34wsd7Rf6z,'+')
	url = JaQEtCzDXgos1cdZN + '/search?s='+search
	AIQeNZP4FMDw9S(url)
	return
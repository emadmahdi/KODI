# -*- coding: utf-8 -*-
from braVAkwfBN import *
x25j0zbNOqAe4BgIoQtcd = 'IPTV'
gp5OsEbPCX0MGZw1tTf63zcySKLH = '_IPT_'
NeizUlRJp5bQAuKhsaYv0P4gDI = [
		 'IGNORED'
		,'LIVE_UNKNOWN_GROUPED','LIVE_UNKNOWN_GROUPED_SORTED'
		,'VOD_UNKNOWN_GROUPED','VOD_UNKNOWN_GROUPED_SORTED'
		,'LIVE_ARCHIVED_GROUPED_SORTED','LIVE_EPG_GROUPED_SORTED','LIVE_TIMESHIFT_GROUPED_SORTED'
		,'LIVE_GROUPED','LIVE_GROUPED_SORTED'
		,'LIVE_ORIGINAL_GROUPED','LIVE_FROM_GROUP_SORTED','LIVE_FROM_NAME_SORTED'
		,'VOD_MOVIES_GROUPED','VOD_MOVIES_GROUPED_SORTED'
		,'VOD_SERIES_GROUPED','VOD_SERIES_GROUPED_SORTED'
		,'VOD_ORIGINAL_GROUPED','VOD_FROM_GROUP_SORTED','VOD_FROM_NAME_SORTED'
		]
def aSZHGchAUqxirb2ztEK5wWo(Cpf9s3c0Zngj7XE,kMqh74TPvpSDar59xQUjAyVlHes,U94JwhRgpXCOe5,synCYOiMR789twmfr,F50ngOyjSvAcVRtdafJsiBkP9Yx,BSmlfc08nJ):
	global gp5OsEbPCX0MGZw1tTf63zcySKLH
	try:
		QZEi0WbICGAXPzH876 = str(BSmlfc08nJ['folder'])
		gp5OsEbPCX0MGZw1tTf63zcySKLH = '_IP'+QZEi0WbICGAXPzH876+'_'
	except: QZEi0WbICGAXPzH876 = iiy37aKq0pCEIOwfcTh61xb4U
	if   Cpf9s3c0Zngj7XE==230: LcMSkexq718nIEaCGRgP = RlU7zJX98EacB1eH()
	elif Cpf9s3c0Zngj7XE==231: LcMSkexq718nIEaCGRgP = ppWGUxyoz1(QZEi0WbICGAXPzH876)
	elif Cpf9s3c0Zngj7XE==232: LcMSkexq718nIEaCGRgP = qMwhogZNPrE98AkLx6Ht7jJS(QZEi0WbICGAXPzH876)
	elif Cpf9s3c0Zngj7XE==233: LcMSkexq718nIEaCGRgP = CFhvzLMJ5KiywpIfANxqgHGrloT(QZEi0WbICGAXPzH876,kMqh74TPvpSDar59xQUjAyVlHes,U94JwhRgpXCOe5,F50ngOyjSvAcVRtdafJsiBkP9Yx)
	elif Cpf9s3c0Zngj7XE==234: LcMSkexq718nIEaCGRgP = rmEH1eAYBg8xPK(QZEi0WbICGAXPzH876,kMqh74TPvpSDar59xQUjAyVlHes,U94JwhRgpXCOe5,F50ngOyjSvAcVRtdafJsiBkP9Yx)
	elif Cpf9s3c0Zngj7XE==235: LcMSkexq718nIEaCGRgP = TW6Z0zqaDl(QZEi0WbICGAXPzH876,kMqh74TPvpSDar59xQUjAyVlHes,synCYOiMR789twmfr)
	elif Cpf9s3c0Zngj7XE==236: LcMSkexq718nIEaCGRgP = m9sD2UNo3OnFbawyfcKrB(QZEi0WbICGAXPzH876,True)
	elif Cpf9s3c0Zngj7XE==237: LcMSkexq718nIEaCGRgP = DDGYfd2miAauNzOVsUxEJb1ecyRXQ5(QZEi0WbICGAXPzH876,True)
	elif Cpf9s3c0Zngj7XE==238: LcMSkexq718nIEaCGRgP = JqbugthmPrAUHYdMZR0BvoSxnkN(QZEi0WbICGAXPzH876,kMqh74TPvpSDar59xQUjAyVlHes,U94JwhRgpXCOe5)
	elif Cpf9s3c0Zngj7XE==239: LcMSkexq718nIEaCGRgP = g5h4NU9EkHwnQqrAamMi7JOZDeX(U94JwhRgpXCOe5,QZEi0WbICGAXPzH876,kMqh74TPvpSDar59xQUjAyVlHes,F50ngOyjSvAcVRtdafJsiBkP9Yx)
	elif Cpf9s3c0Zngj7XE==280: LcMSkexq718nIEaCGRgP = JJUoTEDm2h3eQijgavIZHd1GL(QZEi0WbICGAXPzH876,True)
	elif Cpf9s3c0Zngj7XE==281: LcMSkexq718nIEaCGRgP = ryboCGwJIskXZvPAT(QZEi0WbICGAXPzH876)
	elif Cpf9s3c0Zngj7XE==282: LcMSkexq718nIEaCGRgP = mCQOIgALuKGocwN7Dytbf8UEpJj(QZEi0WbICGAXPzH876)
	elif Cpf9s3c0Zngj7XE==283: LcMSkexq718nIEaCGRgP = U2K6rlmJpMOosQ(QZEi0WbICGAXPzH876)
	elif Cpf9s3c0Zngj7XE==285: LcMSkexq718nIEaCGRgP = j83AQoWvke(QZEi0WbICGAXPzH876,kMqh74TPvpSDar59xQUjAyVlHes,U94JwhRgpXCOe5)
	elif Cpf9s3c0Zngj7XE==286: LcMSkexq718nIEaCGRgP = Y6RaGO02TLsKC(QZEi0WbICGAXPzH876)
	elif Cpf9s3c0Zngj7XE==289: LcMSkexq718nIEaCGRgP = bytEjneopA(U94JwhRgpXCOe5,QZEi0WbICGAXPzH876,kMqh74TPvpSDar59xQUjAyVlHes,F50ngOyjSvAcVRtdafJsiBkP9Yx)
	else: LcMSkexq718nIEaCGRgP = False
	return LcMSkexq718nIEaCGRgP
def RlU7zJX98EacB1eH():
	for QZEi0WbICGAXPzH876 in range(1,IDxpbtWgzXHs3u08Q7nR6YerO+1):
		gp5OsEbPCX0MGZw1tTf63zcySKLH = '_IP'+str(QZEi0WbICGAXPzH876)+'_'
		bP6z3OSLp7va('folder',gp5OsEbPCX0MGZw1tTf63zcySKLH+'قائمة مجلد '+T7Rtxv5SnE1O94dLBcVNKHDZbJQe[QZEi0WbICGAXPzH876],iiy37aKq0pCEIOwfcTh61xb4U,280,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,{'folder':QZEi0WbICGAXPzH876})
	return
def JJUoTEDm2h3eQijgavIZHd1GL(QZEi0WbICGAXPzH876=iiy37aKq0pCEIOwfcTh61xb4U,YaxK9usyg6VfMPIEhq7ctzBmOi8We1=iiy37aKq0pCEIOwfcTh61xb4U):
	if QZEi0WbICGAXPzH876:
		HHDzyhR1LQAw = {'folder':QZEi0WbICGAXPzH876}
		uVs5SRi1t3wcDYXUAadJLpCG = iiy37aKq0pCEIOwfcTh61xb4U
	else:
		HHDzyhR1LQAw = iiy37aKq0pCEIOwfcTh61xb4U
		uVs5SRi1t3wcDYXUAadJLpCG = iiy37aKq0pCEIOwfcTh61xb4U
	iVhz17ERCqYMTdB2 = whH63ZkMf7j5gsY(QZEi0WbICGAXPzH876,YaxK9usyg6VfMPIEhq7ctzBmOi8We1)
	if not iVhz17ERCqYMTdB2:
		bP6z3OSLp7va('link',gp5OsEbPCX0MGZw1tTf63zcySKLH+aqEsMBckT2bunGHfl48Wip+' إضافة أو تغيير اشتراك'+uVs5SRi1t3wcDYXUAadJLpCG+' '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,231,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,HHDzyhR1LQAw)
		bP6z3OSLp7va('link',gp5OsEbPCX0MGZw1tTf63zcySKLH+aqEsMBckT2bunGHfl48Wip+' جلب ملفات'+uVs5SRi1t3wcDYXUAadJLpCG+' '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,232,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,HHDzyhR1LQAw)
		bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	else:
		bP6z3OSLp7va('folder',gp5OsEbPCX0MGZw1tTf63zcySKLH+'بحث في الملفات'+uVs5SRi1t3wcDYXUAadJLpCG,iiy37aKq0pCEIOwfcTh61xb4U,289,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'_REMEMBERRESULTS_',iiy37aKq0pCEIOwfcTh61xb4U,HHDzyhR1LQAw)
		bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
		bP6z3OSLp7va('folder',gp5OsEbPCX0MGZw1tTf63zcySKLH+'قنوات بدون جلب ملفات','XTREAM_LIVE_GROUPS',285,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,HHDzyhR1LQAw)
		bP6z3OSLp7va('folder',gp5OsEbPCX0MGZw1tTf63zcySKLH+'قنوات مصنفة مرتبة'+uVs5SRi1t3wcDYXUAadJLpCG,'LIVE_GROUPED_SORTED',233,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,HHDzyhR1LQAw)
		bP6z3OSLp7va('folder',gp5OsEbPCX0MGZw1tTf63zcySKLH+'قنوات مصنفة من القسم'+uVs5SRi1t3wcDYXUAadJLpCG,'LIVE_FROM_GROUP_SORTED',233,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,HHDzyhR1LQAw)
		bP6z3OSLp7va('folder',gp5OsEbPCX0MGZw1tTf63zcySKLH+'قنوات مصنفة من الاسم'+uVs5SRi1t3wcDYXUAadJLpCG,'LIVE_FROM_NAME_SORTED',233,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,HHDzyhR1LQAw)
		bP6z3OSLp7va('folder',gp5OsEbPCX0MGZw1tTf63zcySKLH+'قنوات مصنفة بلا ترتيب'+uVs5SRi1t3wcDYXUAadJLpCG,'LIVE_GROUPED',233,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,HHDzyhR1LQAw)
		bP6z3OSLp7va('folder',gp5OsEbPCX0MGZw1tTf63zcySKLH+'قنوات بلا ترتيب'+uVs5SRi1t3wcDYXUAadJLpCG,'LIVE_ORIGINAL_GROUPED',233,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,HHDzyhR1LQAw)
		bP6z3OSLp7va('folder',gp5OsEbPCX0MGZw1tTf63zcySKLH+'قنوات مجهولة مرتبة'+uVs5SRi1t3wcDYXUAadJLpCG,'LIVE_UNKNOWN_GROUPED_SORTED',233,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,HHDzyhR1LQAw)
		bP6z3OSLp7va('folder',gp5OsEbPCX0MGZw1tTf63zcySKLH+'قنوات مجهولة بلا ترتيب'+uVs5SRi1t3wcDYXUAadJLpCG,'LIVE_UNKNOWN_GROUPED',233,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,HHDzyhR1LQAw)
		bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
		bP6z3OSLp7va('folder',gp5OsEbPCX0MGZw1tTf63zcySKLH+'أفلام بدون جلب ملفات','XTREAM_VOD_GROUPS',285,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,HHDzyhR1LQAw)
		bP6z3OSLp7va('folder',gp5OsEbPCX0MGZw1tTf63zcySKLH+'أفلام مصنفة بلا ترتيب'+uVs5SRi1t3wcDYXUAadJLpCG,'VOD_MOVIES_GROUPED',233,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,HHDzyhR1LQAw)
		bP6z3OSLp7va('folder',gp5OsEbPCX0MGZw1tTf63zcySKLH+'أفلام مصنفة مرتبة'+uVs5SRi1t3wcDYXUAadJLpCG,'VOD_MOVIES_GROUPED_SORTED',233,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,HHDzyhR1LQAw)
		bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
		bP6z3OSLp7va('folder',gp5OsEbPCX0MGZw1tTf63zcySKLH+'مسلسلات بدون جلب ملفات','XTREAM_SERIES_GROUPS',285,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,HHDzyhR1LQAw)
		bP6z3OSLp7va('folder',gp5OsEbPCX0MGZw1tTf63zcySKLH+'مسلسلات مصنفة بلا ترتيب'+uVs5SRi1t3wcDYXUAadJLpCG,'VOD_SERIES_GROUPED',233,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,HHDzyhR1LQAw)
		bP6z3OSLp7va('folder',gp5OsEbPCX0MGZw1tTf63zcySKLH+'مسلسلات مصنفة مرتبة'+uVs5SRi1t3wcDYXUAadJLpCG,'VOD_SERIES_GROUPED_SORTED',233,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,HHDzyhR1LQAw)
		bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
		bP6z3OSLp7va('folder',gp5OsEbPCX0MGZw1tTf63zcySKLH+'فيديوهات بلا ترتيب'+uVs5SRi1t3wcDYXUAadJLpCG,'VOD_ORIGINAL_GROUPED',233,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,HHDzyhR1LQAw)
		bP6z3OSLp7va('folder',gp5OsEbPCX0MGZw1tTf63zcySKLH+'فيديوهات مصنفة من القسم'+uVs5SRi1t3wcDYXUAadJLpCG,'VOD_FROM_GROUP_SORTED',233,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,HHDzyhR1LQAw)
		bP6z3OSLp7va('folder',gp5OsEbPCX0MGZw1tTf63zcySKLH+'فيديوهات مصنفة من الاسم'+uVs5SRi1t3wcDYXUAadJLpCG,'VOD_FROM_NAME_SORTED',233,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,HHDzyhR1LQAw)
		bP6z3OSLp7va('folder',gp5OsEbPCX0MGZw1tTf63zcySKLH+'فيديوهات مجهولة بلا ترتيب'+uVs5SRi1t3wcDYXUAadJLpCG,'VOD_UNKNOWN_GROUPED',233,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,HHDzyhR1LQAw)
		bP6z3OSLp7va('folder',gp5OsEbPCX0MGZw1tTf63zcySKLH+'فيديوهات مجهولة مرتبة'+uVs5SRi1t3wcDYXUAadJLpCG,'VOD_UNKNOWN_GROUPED_SORTED',233,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,HHDzyhR1LQAw)
		bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
		bP6z3OSLp7va('folder',gp5OsEbPCX0MGZw1tTf63zcySKLH+'برامج القنوات (جدول فقط)'+uVs5SRi1t3wcDYXUAadJLpCG,'LIVE_EPG_GROUPED_SORTED',233,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,HHDzyhR1LQAw)
		bP6z3OSLp7va('folder',gp5OsEbPCX0MGZw1tTf63zcySKLH+'أرشيف القنوات للأيام الماضية'+uVs5SRi1t3wcDYXUAadJLpCG,'LIVE_TIMESHIFT_GROUPED_SORTED',233,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,HHDzyhR1LQAw)
		bP6z3OSLp7va('folder',gp5OsEbPCX0MGZw1tTf63zcySKLH+'أرشيف برامج القنوات للأيام الماضية'+uVs5SRi1t3wcDYXUAadJLpCG,'LIVE_ARCHIVED_GROUPED_SORTED',233,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,HHDzyhR1LQAw)
		bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	bP6z3OSLp7va('link',gp5OsEbPCX0MGZw1tTf63zcySKLH+'إضافة أو تغيير اشتراك'+uVs5SRi1t3wcDYXUAadJLpCG,iiy37aKq0pCEIOwfcTh61xb4U,231,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,HHDzyhR1LQAw)
	bP6z3OSLp7va('link',gp5OsEbPCX0MGZw1tTf63zcySKLH+'جلب ملفات'+uVs5SRi1t3wcDYXUAadJLpCG,iiy37aKq0pCEIOwfcTh61xb4U,232,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,HHDzyhR1LQAw)
	bP6z3OSLp7va('link',gp5OsEbPCX0MGZw1tTf63zcySKLH+'مسح ملفات'+uVs5SRi1t3wcDYXUAadJLpCG,iiy37aKq0pCEIOwfcTh61xb4U,237,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,HHDzyhR1LQAw)
	bP6z3OSLp7va('link',gp5OsEbPCX0MGZw1tTf63zcySKLH+'فحص اشتراك'+uVs5SRi1t3wcDYXUAadJLpCG,iiy37aKq0pCEIOwfcTh61xb4U,236,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,HHDzyhR1LQAw)
	bP6z3OSLp7va('link',gp5OsEbPCX0MGZw1tTf63zcySKLH+'عدد فيديوهات'+uVs5SRi1t3wcDYXUAadJLpCG,iiy37aKq0pCEIOwfcTh61xb4U,281,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,HHDzyhR1LQAw)
	bP6z3OSLp7va('link',gp5OsEbPCX0MGZw1tTf63zcySKLH+'Referer تغيير'+uVs5SRi1t3wcDYXUAadJLpCG,iiy37aKq0pCEIOwfcTh61xb4U,286,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,HHDzyhR1LQAw)
	bP6z3OSLp7va('link',gp5OsEbPCX0MGZw1tTf63zcySKLH+'User-Agent تغيير'+uVs5SRi1t3wcDYXUAadJLpCG,iiy37aKq0pCEIOwfcTh61xb4U,283,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,HHDzyhR1LQAw)
	bP6z3OSLp7va('link',gp5OsEbPCX0MGZw1tTf63zcySKLH+'استخدم السيرفر الأسرع'+uVs5SRi1t3wcDYXUAadJLpCG,iiy37aKq0pCEIOwfcTh61xb4U,282,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,HHDzyhR1LQAw)
	return
def m9sD2UNo3OnFbawyfcKrB(QZEi0WbICGAXPzH876,YaxK9usyg6VfMPIEhq7ctzBmOi8We1=True):
	ZnmVbxX1PT,dd9ngbVhDcJ5UGo3z = False,iiy37aKq0pCEIOwfcTh61xb4U
	PPvU1cC2HdhzS9KDQNgkRMrsmltwAG,mmkYeCUcryn2qxtEol7Q3 = iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U
	PufdHwFN0Qi5onleA1KZ,LjmRTZl5J3sfp4xywD6NkWIovgh,uOhjCkDo8b,M5FR8xYbQJCgD0Ewf,VgRjTyW5vFOdfExzMnPQSKUXZ1 = UrQ2K7hVyA(QZEi0WbICGAXPzH876)
	if M5FR8xYbQJCgD0Ewf==iiy37aKq0pCEIOwfcTh61xb4U: return False,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U
	qNojFLzuAkDZHEy1d4scer = IIao4mWn2BRMk(QZEi0WbICGAXPzH876)
	if PufdHwFN0Qi5onleA1KZ:
		oikBndh2USEOV = MMCJxEfv0WUek(hI7SkXd94fFzAHNZCQoMqEutbnWP,'GET',PufdHwFN0Qi5onleA1KZ,iiy37aKq0pCEIOwfcTh61xb4U,qNojFLzuAkDZHEy1d4scer,False,iiy37aKq0pCEIOwfcTh61xb4U,'IPTV-CHECK_ACCOUNT-1st')
		JiUpSTZWMhHP = oikBndh2USEOV.content
		if oikBndh2USEOV.succeeded:
			XTvOfZdIQYn4u1wjU,oKk8vWhzwj0tsfI6M,n41PMBRl5VeDAufd8TrzikIXp,hADa8zylGs,lN8oYaustCmGxVBZQP3K0bL7cDkT = 0,0,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U
			try:
				TQ5GC0gPwuDm8h = DeIL3qoa2UBtYPb('dict',JiUpSTZWMhHP)
				dd9ngbVhDcJ5UGo3z = TQ5GC0gPwuDm8h['user_info']['status']
				ZnmVbxX1PT = True
				n41PMBRl5VeDAufd8TrzikIXp = TQ5GC0gPwuDm8h['server_info']['time_now']
			except: pass
			if n41PMBRl5VeDAufd8TrzikIXp:
				try:
					xB5fN1tES7aHAYk9XWd6bie0CD = X2cQ5NCPvkMieBW7oASspFjE.strptime(n41PMBRl5VeDAufd8TrzikIXp,'%Y.%m.%d %H:%M:%S')
					XTvOfZdIQYn4u1wjU = int(X2cQ5NCPvkMieBW7oASspFjE.mktime(xB5fN1tES7aHAYk9XWd6bie0CD))
					oKk8vWhzwj0tsfI6M = int(pwXCQWuGUMka2hFN-XTvOfZdIQYn4u1wjU)
					oKk8vWhzwj0tsfI6M = int((oKk8vWhzwj0tsfI6M+900)/1800)*1800
				except: pass
				try:
					xB5fN1tES7aHAYk9XWd6bie0CD = X2cQ5NCPvkMieBW7oASspFjE.localtime(int(TQ5GC0gPwuDm8h['user_info']['created_at']))
					hADa8zylGs = X2cQ5NCPvkMieBW7oASspFjE.strftime('%Y.%m.%d %H:%M:%S',xB5fN1tES7aHAYk9XWd6bie0CD)
				except: pass
				try:
					xB5fN1tES7aHAYk9XWd6bie0CD = X2cQ5NCPvkMieBW7oASspFjE.localtime(int(TQ5GC0gPwuDm8h['user_info']['exp_date']))
					lN8oYaustCmGxVBZQP3K0bL7cDkT = X2cQ5NCPvkMieBW7oASspFjE.strftime('%Y.%m.%d %H:%M:%S',xB5fN1tES7aHAYk9XWd6bie0CD)
				except: pass
			OXsckY7RzjCag9A.setSetting('av.iptv.timestamp_'+QZEi0WbICGAXPzH876,str(pwXCQWuGUMka2hFN))
			OXsckY7RzjCag9A.setSetting('av.iptv.timediff_'+QZEi0WbICGAXPzH876,str(oKk8vWhzwj0tsfI6M))
			try:
				DFnCOZK7P3XV8bgldGIehWAS62 = '"server_info":'+JiUpSTZWMhHP.split('"server_info":')[1]
				DFnCOZK7P3XV8bgldGIehWAS62 = DFnCOZK7P3XV8bgldGIehWAS62.replace(':',': ').replace(',',', ').replace('}}','}')
				SL9mEwtFA7oYD4 = dEyT9xhGjolYzLCH7460w3.findall('"url": "(.*?)", "port": "(.*?)"',DFnCOZK7P3XV8bgldGIehWAS62,dEyT9xhGjolYzLCH7460w3.DOTALL)
				PPvU1cC2HdhzS9KDQNgkRMrsmltwAG,mmkYeCUcryn2qxtEol7Q3 = SL9mEwtFA7oYD4[0]
			except: ZnmVbxX1PT = False
			if ZnmVbxX1PT and YaxK9usyg6VfMPIEhq7ctzBmOi8We1:
				max = TQ5GC0gPwuDm8h['user_info']['max_connections']
				WVewCBp58S = TQ5GC0gPwuDm8h['user_info']['active_cons']
				AtNix6r38b1TjGdyWZcPnI = TQ5GC0gPwuDm8h['user_info']['is_trial']
				QB2MShj9g5Dv4eaxAX8 = PufdHwFN0Qi5onleA1KZ.split('?',1)
				aZtYlicqMKUFPkBCX2AONHwJ4 = 'URL:  '+PSwfZcdRYhpl5Igqz8xOEk67+PufdHwFN0Qi5onleA1KZ+YoQW601K4fMJcsreDnGVE5wUZIy7
				aZtYlicqMKUFPkBCX2AONHwJ4 += '\n\nStatus:  '+PSwfZcdRYhpl5Igqz8xOEk67+dd9ngbVhDcJ5UGo3z+YoQW601K4fMJcsreDnGVE5wUZIy7
				aZtYlicqMKUFPkBCX2AONHwJ4 += '\nTrial:    '+PSwfZcdRYhpl5Igqz8xOEk67+str(AtNix6r38b1TjGdyWZcPnI=='1')+YoQW601K4fMJcsreDnGVE5wUZIy7
				aZtYlicqMKUFPkBCX2AONHwJ4 += '\nCreated  At:  '+PSwfZcdRYhpl5Igqz8xOEk67+hADa8zylGs+YoQW601K4fMJcsreDnGVE5wUZIy7
				aZtYlicqMKUFPkBCX2AONHwJ4 += '\nExpiry Date:  '+PSwfZcdRYhpl5Igqz8xOEk67+lN8oYaustCmGxVBZQP3K0bL7cDkT+YoQW601K4fMJcsreDnGVE5wUZIy7
				aZtYlicqMKUFPkBCX2AONHwJ4 += '\nConnections   ( Active / Maximum ) :  '+PSwfZcdRYhpl5Igqz8xOEk67+WVewCBp58S+' / '+max+YoQW601K4fMJcsreDnGVE5wUZIy7
				aZtYlicqMKUFPkBCX2AONHwJ4 += '\nAllowed Outputs:   '+PSwfZcdRYhpl5Igqz8xOEk67+" , ".join(TQ5GC0gPwuDm8h['user_info']['allowed_output_formats'])+YoQW601K4fMJcsreDnGVE5wUZIy7
				aZtYlicqMKUFPkBCX2AONHwJ4 += '\n\n'+DFnCOZK7P3XV8bgldGIehWAS62
				if dd9ngbVhDcJ5UGo3z=='Active': BBWHv8OyN6VudhF('الاشتراك يعمل بدون مشاكل',aZtYlicqMKUFPkBCX2AONHwJ4)
				else: BBWHv8OyN6VudhF('يبدو أن هناك مشكلة في الاشتراك',aZtYlicqMKUFPkBCX2AONHwJ4)
	if PufdHwFN0Qi5onleA1KZ and ZnmVbxX1PT and dd9ngbVhDcJ5UGo3z=='Active':
		WKquk5EaNr4RzVf(q1rohYuwnfpVZUa98L2CtQzmAcB,'.\tChecking IPTV URL   [ IPTV account is OK ]   [ '+PufdHwFN0Qi5onleA1KZ+' ]')
		VsfSE7hTyxPUko = True
	else:
		WKquk5EaNr4RzVf(uiza5vIyTWtUeB8sXwAVYMFpgjrk,'Checking IPTV URL   [ Does not work ]   [ '+PufdHwFN0Qi5onleA1KZ+' ]')
		if YaxK9usyg6VfMPIEhq7ctzBmOi8We1: bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'فحص اشتراك ـIPTV','رابط اشتراك ـIPTV الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـIPTV وقم بإضافة رابط ـIPTV جديد أو قم بإصلاح الرابط القديم')
		VsfSE7hTyxPUko = False
	return VsfSE7hTyxPUko,PPvU1cC2HdhzS9KDQNgkRMrsmltwAG,mmkYeCUcryn2qxtEol7Q3
def rmEH1eAYBg8xPK(QZEi0WbICGAXPzH876,ERdVgaeYJtcbmM5AFkZNn,mF8LjNVMIzeJX,JJXDWPbmBGEFRoOejr8Z7cyU5wgk3,YaxK9usyg6VfMPIEhq7ctzBmOi8We1=True):
	if not JJXDWPbmBGEFRoOejr8Z7cyU5wgk3: JJXDWPbmBGEFRoOejr8Z7cyU5wgk3 = '1'
	if not whH63ZkMf7j5gsY(QZEi0WbICGAXPzH876,YaxK9usyg6VfMPIEhq7ctzBmOi8We1): return
	zzPO3oKR8eVEcI4ruS5wGhyQ = m8tbAHrJLowOSax2NdZK(QZEi0WbICGAXPzH876,ERdVgaeYJtcbmM5AFkZNn)
	z0OXopbnK2E = QKzCiBOWZus1nSv(zzPO3oKR8eVEcI4ruS5wGhyQ,'list',ERdVgaeYJtcbmM5AFkZNn,mF8LjNVMIzeJX)
	ww9ibQEkrTvXoStlBRjGVLaeupqdc = int(JJXDWPbmBGEFRoOejr8Z7cyU5wgk3)*100
	HxOrYzlCXasuSdjBb = ww9ibQEkrTvXoStlBRjGVLaeupqdc-100
	for YGNomIp2tDSR6ncf,svZJBpqOEQNyRPaDMUh870bCtdnT1,kMqh74TPvpSDar59xQUjAyVlHes,RtWKTkahzD0EuPVLpr in z0OXopbnK2E[HxOrYzlCXasuSdjBb:ww9ibQEkrTvXoStlBRjGVLaeupqdc]:
		WQdwGJk9mlHMzYyPovcrV8f = ('GROUPED' in ERdVgaeYJtcbmM5AFkZNn or ERdVgaeYJtcbmM5AFkZNn=='ALL')
		AFt0cr7izCOEubR2 = ('GROUPED' not in ERdVgaeYJtcbmM5AFkZNn and ERdVgaeYJtcbmM5AFkZNn!='ALL')
		if WQdwGJk9mlHMzYyPovcrV8f or AFt0cr7izCOEubR2:
			if   'ARCHIVED'  in ERdVgaeYJtcbmM5AFkZNn: g6ghGH4aBEYkTl3vbJZ.append(['folder',gp5OsEbPCX0MGZw1tTf63zcySKLH+svZJBpqOEQNyRPaDMUh870bCtdnT1,kMqh74TPvpSDar59xQUjAyVlHes,238,RtWKTkahzD0EuPVLpr,iiy37aKq0pCEIOwfcTh61xb4U,'ARCHIVED',iiy37aKq0pCEIOwfcTh61xb4U,{'folder':QZEi0WbICGAXPzH876}])
			elif 'EPG' 		 in ERdVgaeYJtcbmM5AFkZNn: g6ghGH4aBEYkTl3vbJZ.append(['folder',gp5OsEbPCX0MGZw1tTf63zcySKLH+svZJBpqOEQNyRPaDMUh870bCtdnT1,kMqh74TPvpSDar59xQUjAyVlHes,238,RtWKTkahzD0EuPVLpr,iiy37aKq0pCEIOwfcTh61xb4U,'FULL_EPG',iiy37aKq0pCEIOwfcTh61xb4U,{'folder':QZEi0WbICGAXPzH876}])
			elif 'TIMESHIFT' in ERdVgaeYJtcbmM5AFkZNn: g6ghGH4aBEYkTl3vbJZ.append(['folder',gp5OsEbPCX0MGZw1tTf63zcySKLH+svZJBpqOEQNyRPaDMUh870bCtdnT1,kMqh74TPvpSDar59xQUjAyVlHes,238,RtWKTkahzD0EuPVLpr,iiy37aKq0pCEIOwfcTh61xb4U,'TIMESHIFT',iiy37aKq0pCEIOwfcTh61xb4U,{'folder':QZEi0WbICGAXPzH876}])
			elif 'LIVE' 	 in ERdVgaeYJtcbmM5AFkZNn: g6ghGH4aBEYkTl3vbJZ.append(['live',gp5OsEbPCX0MGZw1tTf63zcySKLH+svZJBpqOEQNyRPaDMUh870bCtdnT1,kMqh74TPvpSDar59xQUjAyVlHes,235,RtWKTkahzD0EuPVLpr,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,YGNomIp2tDSR6ncf,{'folder':QZEi0WbICGAXPzH876}])
			else: g6ghGH4aBEYkTl3vbJZ.append(['video',gp5OsEbPCX0MGZw1tTf63zcySKLH+svZJBpqOEQNyRPaDMUh870bCtdnT1,kMqh74TPvpSDar59xQUjAyVlHes,235,RtWKTkahzD0EuPVLpr,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,{'folder':QZEi0WbICGAXPzH876}])
	wBxmDdbuSL7gfNCpU9W8MkJ0 = len(z0OXopbnK2E)
	vsOn7KRH1Vz6PLjWhdtIXw25YFNqu(QZEi0WbICGAXPzH876,JJXDWPbmBGEFRoOejr8Z7cyU5wgk3,ERdVgaeYJtcbmM5AFkZNn,234,wBxmDdbuSL7gfNCpU9W8MkJ0,mF8LjNVMIzeJX)
	return
def QRFra1ps34IA(qqVYUsTKn9Nl82B5FWvmCD1P6gRp):
	bP6z3OSLp7va('link',qqVYUsTKn9Nl82B5FWvmCD1P6gRp+'هذه القائمة إما فارغة أو غير موجودة',iiy37aKq0pCEIOwfcTh61xb4U,9999)
	bP6z3OSLp7va('link',qqVYUsTKn9Nl82B5FWvmCD1P6gRp+'أو الخدمة غير موجودة في اشتراكك',iiy37aKq0pCEIOwfcTh61xb4U,9999)
	bP6z3OSLp7va('link',qqVYUsTKn9Nl82B5FWvmCD1P6gRp+'أو رابط IPTVـ الذي أنت أضفته غير صحيح',iiy37aKq0pCEIOwfcTh61xb4U,9999)
	return
def CFhvzLMJ5KiywpIfANxqgHGrloT(QZEi0WbICGAXPzH876,ERdVgaeYJtcbmM5AFkZNn,mF8LjNVMIzeJX,JJXDWPbmBGEFRoOejr8Z7cyU5wgk3,RUb8iEeK3vV=iiy37aKq0pCEIOwfcTh61xb4U,YaxK9usyg6VfMPIEhq7ctzBmOi8We1=True):
	if not JJXDWPbmBGEFRoOejr8Z7cyU5wgk3: JJXDWPbmBGEFRoOejr8Z7cyU5wgk3 = '1'
	qqVYUsTKn9Nl82B5FWvmCD1P6gRp = gp5OsEbPCX0MGZw1tTf63zcySKLH
	if not whH63ZkMf7j5gsY(QZEi0WbICGAXPzH876,YaxK9usyg6VfMPIEhq7ctzBmOi8We1): return False
	if '__SERIES__' in mF8LjNVMIzeJX: NxDXakM2K7udOQtbhz34v,LGiK5gV9ZQD7qc0l4WBvS2yeoEh = mF8LjNVMIzeJX.split('__SERIES__')
	else: NxDXakM2K7udOQtbhz34v,LGiK5gV9ZQD7qc0l4WBvS2yeoEh = mF8LjNVMIzeJX,iiy37aKq0pCEIOwfcTh61xb4U
	zzPO3oKR8eVEcI4ruS5wGhyQ = m8tbAHrJLowOSax2NdZK(QZEi0WbICGAXPzH876,ERdVgaeYJtcbmM5AFkZNn)
	kkErtBo7c9uesx = QKzCiBOWZus1nSv(zzPO3oKR8eVEcI4ruS5wGhyQ,'list',ERdVgaeYJtcbmM5AFkZNn,'__GROUPS__')
	if not kkErtBo7c9uesx: return False
	RDuIoOWBMvNekcj1q7r5s = []
	for DYxVAZjPCvdMScFfHLJ,RtWKTkahzD0EuPVLpr in kkErtBo7c9uesx:
		if RUb8iEeK3vV:
			if '__SERIES__' in DYxVAZjPCvdMScFfHLJ: qqVYUsTKn9Nl82B5FWvmCD1P6gRp = 'SERIES'
			elif '!!__UNKNOWN__!!' in DYxVAZjPCvdMScFfHLJ: qqVYUsTKn9Nl82B5FWvmCD1P6gRp = 'UNKNOWN'
			elif 'LIVE' in ERdVgaeYJtcbmM5AFkZNn: qqVYUsTKn9Nl82B5FWvmCD1P6gRp = 'LIVE'
			else: qqVYUsTKn9Nl82B5FWvmCD1P6gRp = 'VIDEOS'
			qqVYUsTKn9Nl82B5FWvmCD1P6gRp = ','+PSwfZcdRYhpl5Igqz8xOEk67+qqVYUsTKn9Nl82B5FWvmCD1P6gRp+': '+YoQW601K4fMJcsreDnGVE5wUZIy7
		if '__SERIES__' in DYxVAZjPCvdMScFfHLJ: igKC8YD5kacwNp,nFCOyXNUJwW13PstvxdR = DYxVAZjPCvdMScFfHLJ.split('__SERIES__')
		else: igKC8YD5kacwNp,nFCOyXNUJwW13PstvxdR = DYxVAZjPCvdMScFfHLJ,iiy37aKq0pCEIOwfcTh61xb4U
		if not mF8LjNVMIzeJX:
			if igKC8YD5kacwNp in RDuIoOWBMvNekcj1q7r5s: continue
			RDuIoOWBMvNekcj1q7r5s.append(igKC8YD5kacwNp)
			if 'RANDOM' in RUb8iEeK3vV: bP6z3OSLp7va('folder',qqVYUsTKn9Nl82B5FWvmCD1P6gRp+igKC8YD5kacwNp,ERdVgaeYJtcbmM5AFkZNn,167,iiy37aKq0pCEIOwfcTh61xb4U,'1',DYxVAZjPCvdMScFfHLJ,iiy37aKq0pCEIOwfcTh61xb4U,{'folder':QZEi0WbICGAXPzH876})
			elif '__SERIES__' in DYxVAZjPCvdMScFfHLJ: bP6z3OSLp7va('folder',qqVYUsTKn9Nl82B5FWvmCD1P6gRp+igKC8YD5kacwNp,ERdVgaeYJtcbmM5AFkZNn,233,iiy37aKq0pCEIOwfcTh61xb4U,'1',DYxVAZjPCvdMScFfHLJ,iiy37aKq0pCEIOwfcTh61xb4U,{'folder':QZEi0WbICGAXPzH876})
			else: bP6z3OSLp7va('folder',qqVYUsTKn9Nl82B5FWvmCD1P6gRp+igKC8YD5kacwNp,ERdVgaeYJtcbmM5AFkZNn,234,iiy37aKq0pCEIOwfcTh61xb4U,'1',DYxVAZjPCvdMScFfHLJ,iiy37aKq0pCEIOwfcTh61xb4U,{'folder':QZEi0WbICGAXPzH876})
		elif '__SERIES__' in DYxVAZjPCvdMScFfHLJ and igKC8YD5kacwNp==NxDXakM2K7udOQtbhz34v:
			if nFCOyXNUJwW13PstvxdR in RDuIoOWBMvNekcj1q7r5s: continue
			RDuIoOWBMvNekcj1q7r5s.append(nFCOyXNUJwW13PstvxdR)
			if 'RANDOM' in RUb8iEeK3vV: bP6z3OSLp7va('folder',qqVYUsTKn9Nl82B5FWvmCD1P6gRp+nFCOyXNUJwW13PstvxdR,ERdVgaeYJtcbmM5AFkZNn,167,iiy37aKq0pCEIOwfcTh61xb4U,'1',DYxVAZjPCvdMScFfHLJ,iiy37aKq0pCEIOwfcTh61xb4U,{'folder':QZEi0WbICGAXPzH876})
			else: bP6z3OSLp7va('folder',qqVYUsTKn9Nl82B5FWvmCD1P6gRp+nFCOyXNUJwW13PstvxdR,ERdVgaeYJtcbmM5AFkZNn,234,RtWKTkahzD0EuPVLpr,'1',DYxVAZjPCvdMScFfHLJ,iiy37aKq0pCEIOwfcTh61xb4U,{'folder':QZEi0WbICGAXPzH876})
	g6ghGH4aBEYkTl3vbJZ[:] = sorted(g6ghGH4aBEYkTl3vbJZ,reverse=False,key=lambda cg8pNq2WQ6wszyjtC01JD: cg8pNq2WQ6wszyjtC01JD[1].lower())
	if not RUb8iEeK3vV:
		ww9ibQEkrTvXoStlBRjGVLaeupqdc = int(JJXDWPbmBGEFRoOejr8Z7cyU5wgk3)*100
		HxOrYzlCXasuSdjBb = ww9ibQEkrTvXoStlBRjGVLaeupqdc-100
		wBxmDdbuSL7gfNCpU9W8MkJ0 = len(g6ghGH4aBEYkTl3vbJZ)
		g6ghGH4aBEYkTl3vbJZ[:] = g6ghGH4aBEYkTl3vbJZ[HxOrYzlCXasuSdjBb:ww9ibQEkrTvXoStlBRjGVLaeupqdc]
		vsOn7KRH1Vz6PLjWhdtIXw25YFNqu(QZEi0WbICGAXPzH876,JJXDWPbmBGEFRoOejr8Z7cyU5wgk3,ERdVgaeYJtcbmM5AFkZNn,233,wBxmDdbuSL7gfNCpU9W8MkJ0,mF8LjNVMIzeJX)
	return True
def JqbugthmPrAUHYdMZR0BvoSxnkN(QZEi0WbICGAXPzH876,kMqh74TPvpSDar59xQUjAyVlHes,WjlPK6RQCHuF):
	if not whH63ZkMf7j5gsY(QZEi0WbICGAXPzH876,True): return
	qNojFLzuAkDZHEy1d4scer = IIao4mWn2BRMk(QZEi0WbICGAXPzH876)
	XTvOfZdIQYn4u1wjU = OXsckY7RzjCag9A.getSetting('av.iptv.timestamp_'+QZEi0WbICGAXPzH876)
	if not XTvOfZdIQYn4u1wjU or pwXCQWuGUMka2hFN-int(XTvOfZdIQYn4u1wjU)>24*o5oKZNPi9CeVSI3DzBUEa8tGcAkvH:
		VsfSE7hTyxPUko,PPvU1cC2HdhzS9KDQNgkRMrsmltwAG,mmkYeCUcryn2qxtEol7Q3 = m9sD2UNo3OnFbawyfcKrB(QZEi0WbICGAXPzH876,False)
		if not VsfSE7hTyxPUko: return
	oKk8vWhzwj0tsfI6M = int(OXsckY7RzjCag9A.getSetting('av.iptv.timediff_'+QZEi0WbICGAXPzH876))
	uOhjCkDo8b = OXsckY7RzjCag9A.getSetting('av.iptv.server_'+QZEi0WbICGAXPzH876)
	M5FR8xYbQJCgD0Ewf = OXsckY7RzjCag9A.getSetting('av.iptv.username_'+QZEi0WbICGAXPzH876)
	VgRjTyW5vFOdfExzMnPQSKUXZ1 = OXsckY7RzjCag9A.getSetting('av.iptv.password_'+QZEi0WbICGAXPzH876)
	cX6E3LmeiGS79KW4b2oHgUksx0 = kMqh74TPvpSDar59xQUjAyVlHes.split('/')
	mLxTf08aVo9KcA = cX6E3LmeiGS79KW4b2oHgUksx0[-1].replace('.ts',iiy37aKq0pCEIOwfcTh61xb4U).replace('.m3u8',iiy37aKq0pCEIOwfcTh61xb4U)
	if WjlPK6RQCHuF=='SHORT_EPG': yvC7gotmhKRT0sIcUL = 'get_short_epg'
	else: yvC7gotmhKRT0sIcUL = 'get_simple_data_table'
	PufdHwFN0Qi5onleA1KZ,LjmRTZl5J3sfp4xywD6NkWIovgh,uOhjCkDo8b,M5FR8xYbQJCgD0Ewf,VgRjTyW5vFOdfExzMnPQSKUXZ1 = UrQ2K7hVyA(QZEi0WbICGAXPzH876)
	if not M5FR8xYbQJCgD0Ewf: return
	hZ1GNrgPp7TLv02UeiI93MSx6B = PufdHwFN0Qi5onleA1KZ+'&action='+yvC7gotmhKRT0sIcUL+'&stream_id='+mLxTf08aVo9KcA
	JiUpSTZWMhHP = KK0E3DkqdLCJ76Y8Zv4VSOmc(hI7SkXd94fFzAHNZCQoMqEutbnWP,hZ1GNrgPp7TLv02UeiI93MSx6B,iiy37aKq0pCEIOwfcTh61xb4U,qNojFLzuAkDZHEy1d4scer,iiy37aKq0pCEIOwfcTh61xb4U,'IPTV-EPG_ITEMS-2nd')
	LdOj7XnmiPp6zBus81ZkvG3eA2 = DeIL3qoa2UBtYPb('dict',JiUpSTZWMhHP)
	wXKedvQOW0jgGmHMS7aPJbI = LdOj7XnmiPp6zBus81ZkvG3eA2['epg_listings']
	TlK8sfJUjw35F2X = []
	if WjlPK6RQCHuF in ['ARCHIVED','TIMESHIFT']:
		for TQ5GC0gPwuDm8h in wXKedvQOW0jgGmHMS7aPJbI:
			if TQ5GC0gPwuDm8h['has_archive']==1:
				TlK8sfJUjw35F2X.append(TQ5GC0gPwuDm8h)
				if WjlPK6RQCHuF in ['TIMESHIFT']: break
		if not TlK8sfJUjw35F2X: return
		bP6z3OSLp7va('link',gp5OsEbPCX0MGZw1tTf63zcySKLH+PSwfZcdRYhpl5Igqz8xOEk67+'الملفات الأولي بهذه القائمة قد لا تعمل'+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
		if WjlPK6RQCHuF in ['TIMESHIFT']:
			cpFXw9lhePvE7OmxRr = 2
			ii7qEBIKu2ovdL50R1HW = cpFXw9lhePvE7OmxRr*o5oKZNPi9CeVSI3DzBUEa8tGcAkvH
			TlK8sfJUjw35F2X = []
			ZyaOkAQJwM0nt = int(int(TQ5GC0gPwuDm8h['start_timestamp'])/ii7qEBIKu2ovdL50R1HW)*ii7qEBIKu2ovdL50R1HW
			UDSZzJWs369TpGyK1t = pwXCQWuGUMka2hFN+ii7qEBIKu2ovdL50R1HW
			QuIs9AtXOY78kJH1UNwoBKWh3zrlg = int((UDSZzJWs369TpGyK1t-ZyaOkAQJwM0nt)/o5oKZNPi9CeVSI3DzBUEa8tGcAkvH)
			for vfqn7zT9oweJ in range(QuIs9AtXOY78kJH1UNwoBKWh3zrlg):
				if vfqn7zT9oweJ>=6:
					if vfqn7zT9oweJ%cpFXw9lhePvE7OmxRr!=0: continue
					wkYquGBgtfiTI5Ph1UEZc4oJ08Q = ii7qEBIKu2ovdL50R1HW
				else: wkYquGBgtfiTI5Ph1UEZc4oJ08Q = ii7qEBIKu2ovdL50R1HW//2
				KKiYDXeAz7FGZCVT0bd29mo = ZyaOkAQJwM0nt+vfqn7zT9oweJ*o5oKZNPi9CeVSI3DzBUEa8tGcAkvH
				TQ5GC0gPwuDm8h = {}
				TQ5GC0gPwuDm8h['title'] = iiy37aKq0pCEIOwfcTh61xb4U
				xB5fN1tES7aHAYk9XWd6bie0CD = X2cQ5NCPvkMieBW7oASspFjE.localtime(KKiYDXeAz7FGZCVT0bd29mo-oKk8vWhzwj0tsfI6M-o5oKZNPi9CeVSI3DzBUEa8tGcAkvH)
				TQ5GC0gPwuDm8h['start'] = X2cQ5NCPvkMieBW7oASspFjE.strftime('%Y.%m.%d %H:%M:%S',xB5fN1tES7aHAYk9XWd6bie0CD)
				TQ5GC0gPwuDm8h['start_timestamp'] = str(KKiYDXeAz7FGZCVT0bd29mo)
				TQ5GC0gPwuDm8h['stop_timestamp'] = str(KKiYDXeAz7FGZCVT0bd29mo+wkYquGBgtfiTI5Ph1UEZc4oJ08Q)
				TlK8sfJUjw35F2X.append(TQ5GC0gPwuDm8h)
	elif WjlPK6RQCHuF in ['SHORT_EPG','FULL_EPG']: TlK8sfJUjw35F2X = wXKedvQOW0jgGmHMS7aPJbI
	if WjlPK6RQCHuF=='FULL_EPG' and len(TlK8sfJUjw35F2X)>0:
		bP6z3OSLp7va('link',gp5OsEbPCX0MGZw1tTf63zcySKLH+PSwfZcdRYhpl5Igqz8xOEk67+'هذه قائمة برامج القنوات (جدول فقط)ـ'+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	BiWjl0qXIT8fn1AkEU = []
	RtWKTkahzD0EuPVLpr = WwMgozBIC32n9d0tyfp.getInfoLabel('ListItem.Icon')
	for TQ5GC0gPwuDm8h in TlK8sfJUjw35F2X:
		svZJBpqOEQNyRPaDMUh870bCtdnT1 = UodGe76Lu2IHTYPxBhjk1RpcaqrM.b64decode(TQ5GC0gPwuDm8h['title'])
		if J1MoiYc7ZwzKS: svZJBpqOEQNyRPaDMUh870bCtdnT1 = svZJBpqOEQNyRPaDMUh870bCtdnT1.decode(df6QpwGxuJVZr)
		KKiYDXeAz7FGZCVT0bd29mo = int(TQ5GC0gPwuDm8h['start_timestamp'])
		zDJNuya1WcSLsPpK = int(TQ5GC0gPwuDm8h['stop_timestamp'])
		o1wRizjaAD0Vf58J7gLXYdINenbrU = str(int((zDJNuya1WcSLsPpK-KKiYDXeAz7FGZCVT0bd29mo+59)/60))
		xx7kitBno6rscHKLaCFWb = TQ5GC0gPwuDm8h['start'].replace(iFBmE2MUIpSu34wsd7Rf6z,':')
		xB5fN1tES7aHAYk9XWd6bie0CD = X2cQ5NCPvkMieBW7oASspFjE.localtime(KKiYDXeAz7FGZCVT0bd29mo-o5oKZNPi9CeVSI3DzBUEa8tGcAkvH)
		s8BNckqrg6SCPhFi74YmKxGnjzI = X2cQ5NCPvkMieBW7oASspFjE.strftime('%H:%M',xB5fN1tES7aHAYk9XWd6bie0CD)
		HfLGTFQn06U7mV = X2cQ5NCPvkMieBW7oASspFjE.strftime('%a',xB5fN1tES7aHAYk9XWd6bie0CD)
		if WjlPK6RQCHuF=='SHORT_EPG': svZJBpqOEQNyRPaDMUh870bCtdnT1 = aqEsMBckT2bunGHfl48Wip+s8BNckqrg6SCPhFi74YmKxGnjzI+' ـ '+svZJBpqOEQNyRPaDMUh870bCtdnT1+YoQW601K4fMJcsreDnGVE5wUZIy7
		elif WjlPK6RQCHuF=='TIMESHIFT': svZJBpqOEQNyRPaDMUh870bCtdnT1 = HfLGTFQn06U7mV+iFBmE2MUIpSu34wsd7Rf6z+s8BNckqrg6SCPhFi74YmKxGnjzI+' ('+o1wRizjaAD0Vf58J7gLXYdINenbrU+'min)'
		else: svZJBpqOEQNyRPaDMUh870bCtdnT1 = HfLGTFQn06U7mV+iFBmE2MUIpSu34wsd7Rf6z+s8BNckqrg6SCPhFi74YmKxGnjzI+' ('+o1wRizjaAD0Vf58J7gLXYdINenbrU+'min)   '+svZJBpqOEQNyRPaDMUh870bCtdnT1+' ـ'
		if WjlPK6RQCHuF in ['ARCHIVED','FULL_EPG','TIMESHIFT']:
			LnaD9UyYH7qkPwQShgrW2CFef = uOhjCkDo8b+'/timeshift/'+M5FR8xYbQJCgD0Ewf+'/'+VgRjTyW5vFOdfExzMnPQSKUXZ1+'/'+o1wRizjaAD0Vf58J7gLXYdINenbrU+'/'+xx7kitBno6rscHKLaCFWb+'/'+mLxTf08aVo9KcA+'.m3u8'
			if WjlPK6RQCHuF=='FULL_EPG': bP6z3OSLp7va('link',gp5OsEbPCX0MGZw1tTf63zcySKLH+svZJBpqOEQNyRPaDMUh870bCtdnT1,LnaD9UyYH7qkPwQShgrW2CFef,9999,RtWKTkahzD0EuPVLpr,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,{'folder':QZEi0WbICGAXPzH876})
			else: bP6z3OSLp7va('video',gp5OsEbPCX0MGZw1tTf63zcySKLH+svZJBpqOEQNyRPaDMUh870bCtdnT1,LnaD9UyYH7qkPwQShgrW2CFef,235,RtWKTkahzD0EuPVLpr,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,{'folder':QZEi0WbICGAXPzH876})
		BiWjl0qXIT8fn1AkEU.append(svZJBpqOEQNyRPaDMUh870bCtdnT1)
	if WjlPK6RQCHuF=='SHORT_EPG' and BiWjl0qXIT8fn1AkEU: ndcIwKfF3MWHgyetL5YzJr8jlN6D = NW92cI5MjezZVnTGmq(BiWjl0qXIT8fn1AkEU)
	return BiWjl0qXIT8fn1AkEU
def mCQOIgALuKGocwN7Dytbf8UEpJj(QZEi0WbICGAXPzH876):
	if not whH63ZkMf7j5gsY(QZEi0WbICGAXPzH876,True): return
	uOhjCkDo8b,NYMF2Vn9grPwDmUv1G,Ct3rSkiXM5YQquAPsp8gcDU17 = iiy37aKq0pCEIOwfcTh61xb4U,0,0
	VsfSE7hTyxPUko,PPvU1cC2HdhzS9KDQNgkRMrsmltwAG,mmkYeCUcryn2qxtEol7Q3 = m9sD2UNo3OnFbawyfcKrB(QZEi0WbICGAXPzH876,False)
	if VsfSE7hTyxPUko:
		MKhspwl0ZJ5bjUaiuTk = MtOTE0iscPV7d4bR9K512Zp(PPvU1cC2HdhzS9KDQNgkRMrsmltwAG)
		NYMF2Vn9grPwDmUv1G = iqEgBpYWHmh8uXFzOwMG(MKhspwl0ZJ5bjUaiuTk[0],int(mmkYeCUcryn2qxtEol7Q3))
		zzPO3oKR8eVEcI4ruS5wGhyQ = m8tbAHrJLowOSax2NdZK(QZEi0WbICGAXPzH876,'LIVE_GROUPED')
		iqvYpcmt6Ejy5JUbMONRgFze = QKzCiBOWZus1nSv(zzPO3oKR8eVEcI4ruS5wGhyQ,'list','LIVE_GROUPED')
		z0OXopbnK2E = QKzCiBOWZus1nSv(zzPO3oKR8eVEcI4ruS5wGhyQ,'list','LIVE_GROUPED',iqvYpcmt6Ejy5JUbMONRgFze[1])
		kMqh74TPvpSDar59xQUjAyVlHes = z0OXopbnK2E[0][2]
		qOJe0yIdHjXmlMFr1Lv2SRDfEBbho = dEyT9xhGjolYzLCH7460w3.findall('://(.*?)/',kMqh74TPvpSDar59xQUjAyVlHes,dEyT9xhGjolYzLCH7460w3.DOTALL)
		qOJe0yIdHjXmlMFr1Lv2SRDfEBbho = qOJe0yIdHjXmlMFr1Lv2SRDfEBbho[0]
		if ':' in qOJe0yIdHjXmlMFr1Lv2SRDfEBbho: t1W4pjlLbMD3RgrPNJBkeUfOSZuyx,TSGMnN9aC015lIrXxvD4QfLApHYdFb = qOJe0yIdHjXmlMFr1Lv2SRDfEBbho.split(':')
		else: t1W4pjlLbMD3RgrPNJBkeUfOSZuyx,TSGMnN9aC015lIrXxvD4QfLApHYdFb = qOJe0yIdHjXmlMFr1Lv2SRDfEBbho,'80'
		TT3SE0Mc6bFWhq2IA5jRV = MtOTE0iscPV7d4bR9K512Zp(t1W4pjlLbMD3RgrPNJBkeUfOSZuyx)
		Ct3rSkiXM5YQquAPsp8gcDU17 = iqEgBpYWHmh8uXFzOwMG(TT3SE0Mc6bFWhq2IA5jRV[0],int(TSGMnN9aC015lIrXxvD4QfLApHYdFb))
	if NYMF2Vn9grPwDmUv1G and Ct3rSkiXM5YQquAPsp8gcDU17:
		aZtYlicqMKUFPkBCX2AONHwJ4 = 'هل تريد استخدام السيرفر الأصلي أم السيرفر الأسرع ؟!!'
		aZtYlicqMKUFPkBCX2AONHwJ4 += '\n\n'+'وقت ضائع في السيرفر الأصلي'+OTlVEGYPSxsNaBdXUucqA3+str(int(Ct3rSkiXM5YQquAPsp8gcDU17*1000))+' ملي ثانية'
		aZtYlicqMKUFPkBCX2AONHwJ4 += '\n\n'+'وقت ضائع في السيرفر البديل'+OTlVEGYPSxsNaBdXUucqA3+str(int(NYMF2Vn9grPwDmUv1G*1000))+' ملي ثانية'
		ylRmrkV2fv4nGLC = A1AXKupEOfz('center','السيرفر الأصلي','السيرفر الأسرع','رسالة من المبرمج',aZtYlicqMKUFPkBCX2AONHwJ4)
		if ylRmrkV2fv4nGLC==1 and NYMF2Vn9grPwDmUv1G<Ct3rSkiXM5YQquAPsp8gcDU17: uOhjCkDo8b = PPvU1cC2HdhzS9KDQNgkRMrsmltwAG+':'+mmkYeCUcryn2qxtEol7Q3
	else: bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'رسالة من المبرمج','البرنامج لم يجد السيرفر البديل')
	OXsckY7RzjCag9A.setSetting('av.iptv.server_'+QZEi0WbICGAXPzH876,uOhjCkDo8b)
	return
def TW6Z0zqaDl(QZEi0WbICGAXPzH876,kMqh74TPvpSDar59xQUjAyVlHes,synCYOiMR789twmfr):
	b1aZrdVE0UN8h4KGMqXDAtxu9 = OXsckY7RzjCag9A.getSetting('av.iptv.useragent_'+QZEi0WbICGAXPzH876)
	XNpSgHj5iceQ3v7TD9Ww = OXsckY7RzjCag9A.getSetting('av.iptv.referer_'+QZEi0WbICGAXPzH876)
	if b1aZrdVE0UN8h4KGMqXDAtxu9 or XNpSgHj5iceQ3v7TD9Ww:
		kMqh74TPvpSDar59xQUjAyVlHes += '|'
		if b1aZrdVE0UN8h4KGMqXDAtxu9: kMqh74TPvpSDar59xQUjAyVlHes += '&User-Agent='+b1aZrdVE0UN8h4KGMqXDAtxu9
		if XNpSgHj5iceQ3v7TD9Ww: kMqh74TPvpSDar59xQUjAyVlHes += '&Referer='+XNpSgHj5iceQ3v7TD9Ww
		kMqh74TPvpSDar59xQUjAyVlHes = kMqh74TPvpSDar59xQUjAyVlHes.replace('|&','|')
	xAUEpXNmjVodtsucLySbeY0q = OXsckY7RzjCag9A.getSetting('av.iptv.server_'+QZEi0WbICGAXPzH876)
	if xAUEpXNmjVodtsucLySbeY0q:
		rq6l0GB7IKRymNEAJnDhTY = dEyT9xhGjolYzLCH7460w3.findall('://(.*?)/',kMqh74TPvpSDar59xQUjAyVlHes,dEyT9xhGjolYzLCH7460w3.DOTALL)
		kMqh74TPvpSDar59xQUjAyVlHes = kMqh74TPvpSDar59xQUjAyVlHes.replace(rq6l0GB7IKRymNEAJnDhTY[0],xAUEpXNmjVodtsucLySbeY0q)
	PsD3IgluKFyvzMLoRT9j5hq2(kMqh74TPvpSDar59xQUjAyVlHes,x25j0zbNOqAe4BgIoQtcd,synCYOiMR789twmfr)
	return
def U2K6rlmJpMOosQ(QZEi0WbICGAXPzH876):
	bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'رسالة من المبرمج','تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـIPTV أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـIPTV تحتاج ـUser-Agent خاص')
	b1aZrdVE0UN8h4KGMqXDAtxu9 = OXsckY7RzjCag9A.getSetting('av.iptv.useragent_'+QZEi0WbICGAXPzH876)
	cPoYMehxUObK67yG = A1AXKupEOfz('center','استخدام الأصلي','تعديل القديم',b1aZrdVE0UN8h4KGMqXDAtxu9,'هذا هو ـUser-Agent المستخدم حاليا مع ـIPTV الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـIPTV ؟!')
	if cPoYMehxUObK67yG==1: b1aZrdVE0UN8h4KGMqXDAtxu9 = TTBf6S08q1NKXd5v9wa('أكتب ـIPTV User-Agent جديد',b1aZrdVE0UN8h4KGMqXDAtxu9,True)
	else: b1aZrdVE0UN8h4KGMqXDAtxu9 = 'Unknown'
	if b1aZrdVE0UN8h4KGMqXDAtxu9==iFBmE2MUIpSu34wsd7Rf6z:
		bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'رسالة من المبرمج','غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	cPoYMehxUObK67yG = A1AXKupEOfz('center',iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,b1aZrdVE0UN8h4KGMqXDAtxu9,'هل تريد استخدام هذا ـUser-Agent بدلا من  القديم ؟')
	if cPoYMehxUObK67yG!=1:
		bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'رسالة من المبرمج','تم الإلغاء')
		return
	OXsckY7RzjCag9A.setSetting('av.iptv.useragent_'+QZEi0WbICGAXPzH876,b1aZrdVE0UN8h4KGMqXDAtxu9)
	OlDUo31STWKuLHXcFG(QZEi0WbICGAXPzH876)
	return
def Y6RaGO02TLsKC(QZEi0WbICGAXPzH876):
	bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'رسالة من المبرمج','تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـIPTV أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـIPTV تحتاج ـReferer خاص')
	XNpSgHj5iceQ3v7TD9Ww = OXsckY7RzjCag9A.getSetting('av.iptv.referer_'+QZEi0WbICGAXPzH876)
	cPoYMehxUObK67yG = A1AXKupEOfz('center','استخدام الأصلي','تعديل القديم',XNpSgHj5iceQ3v7TD9Ww,'هذا هو ـReferer المستخدم حاليا مع ـIPTV الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـIPTV ؟!')
	if cPoYMehxUObK67yG==1: XNpSgHj5iceQ3v7TD9Ww = TTBf6S08q1NKXd5v9wa('أكتب ـIPTV Referer جديد',XNpSgHj5iceQ3v7TD9Ww,True)
	else: XNpSgHj5iceQ3v7TD9Ww = iiy37aKq0pCEIOwfcTh61xb4U
	if XNpSgHj5iceQ3v7TD9Ww==iFBmE2MUIpSu34wsd7Rf6z:
		bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'رسالة من المبرمج','غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	cPoYMehxUObK67yG = A1AXKupEOfz('center',iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,XNpSgHj5iceQ3v7TD9Ww,'هل تريد استخدام هذا ـReferer بدلا من  القديم ؟')
	if cPoYMehxUObK67yG!=1:
		bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'رسالة من المبرمج','تم الإلغاء')
		return
	OXsckY7RzjCag9A.setSetting('av.iptv.referer_'+QZEi0WbICGAXPzH876,XNpSgHj5iceQ3v7TD9Ww)
	OlDUo31STWKuLHXcFG(QZEi0WbICGAXPzH876)
	return
def UrQ2K7hVyA(QZEi0WbICGAXPzH876,ttHWamZ2GT956sYDpePCiQoMybU=iiy37aKq0pCEIOwfcTh61xb4U):
	if not ttHWamZ2GT956sYDpePCiQoMybU: ttHWamZ2GT956sYDpePCiQoMybU = OXsckY7RzjCag9A.getSetting('av.iptv.url_'+QZEi0WbICGAXPzH876)
	uOhjCkDo8b = F82MvyX4ThI6sbnA3efDoVS(ttHWamZ2GT956sYDpePCiQoMybU,'url')
	M5FR8xYbQJCgD0Ewf = dEyT9xhGjolYzLCH7460w3.findall('username=(.*?)&',ttHWamZ2GT956sYDpePCiQoMybU+'&',dEyT9xhGjolYzLCH7460w3.DOTALL)
	VgRjTyW5vFOdfExzMnPQSKUXZ1 = dEyT9xhGjolYzLCH7460w3.findall('password=(.*?)&',ttHWamZ2GT956sYDpePCiQoMybU+'&',dEyT9xhGjolYzLCH7460w3.DOTALL)
	if not M5FR8xYbQJCgD0Ewf or not VgRjTyW5vFOdfExzMnPQSKUXZ1:
		bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'فحص اشتراك ـIPTV','رابط اشتراك ـIPTV الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـIPTV وقم بإضافة رابط ـIPTV جديد أو قم بإصلاح الرابط القديم')
		return iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U
	M5FR8xYbQJCgD0Ewf = M5FR8xYbQJCgD0Ewf[0]
	VgRjTyW5vFOdfExzMnPQSKUXZ1 = VgRjTyW5vFOdfExzMnPQSKUXZ1[0]
	PufdHwFN0Qi5onleA1KZ = uOhjCkDo8b+'/player_api.php?username='+M5FR8xYbQJCgD0Ewf+'&password='+VgRjTyW5vFOdfExzMnPQSKUXZ1
	LjmRTZl5J3sfp4xywD6NkWIovgh = uOhjCkDo8b+'/get.php?username='+M5FR8xYbQJCgD0Ewf+'&password='+VgRjTyW5vFOdfExzMnPQSKUXZ1+'&type=m3u_plus'
	return PufdHwFN0Qi5onleA1KZ,LjmRTZl5J3sfp4xywD6NkWIovgh,uOhjCkDo8b,M5FR8xYbQJCgD0Ewf,VgRjTyW5vFOdfExzMnPQSKUXZ1
def PBElratnDIs8NQRu69jJUbZLMgXG(QZEi0WbICGAXPzH876,uCoB9dYem2SZf7KTqpENyL1jQIsUWO=iiy37aKq0pCEIOwfcTh61xb4U):
	woXtcOCiSEJkj4Y8uvgK2s0f = uCoB9dYem2SZf7KTqpENyL1jQIsUWO.replace('/','_').replace(':','_').replace('.','_')
	woXtcOCiSEJkj4Y8uvgK2s0f = woXtcOCiSEJkj4Y8uvgK2s0f.replace('?','_').replace('=','_').replace('&','_')
	woXtcOCiSEJkj4Y8uvgK2s0f = wkMR5x1gTWEQIc6qHCa.path.join(StqmrCIJX4T623w5j9NEonxfQ,woXtcOCiSEJkj4Y8uvgK2s0f).strip('.m3u')+'.m3u'
	return woXtcOCiSEJkj4Y8uvgK2s0f
def ppWGUxyoz1(QZEi0WbICGAXPzH876):
	RtM8jaClfbNXHQdPKog7ZrD = OXsckY7RzjCag9A.getSetting('av.iptv.url_'+QZEi0WbICGAXPzH876)
	M0OcgV2aoY = True
	if RtM8jaClfbNXHQdPKog7ZrD:
		cPoYMehxUObK67yG = Ny92sqomMkizpgKV1('center','كتابة جديد','تعديل القديم','مسح القديم','الرابط الحالي هو:',PSwfZcdRYhpl5Igqz8xOEk67+RtM8jaClfbNXHQdPKog7ZrD+YoQW601K4fMJcsreDnGVE5wUZIy7+'\n\n هذا هو رابط ـIPTV المسجل في البرنامج ... هل تريد تعديله أم تريد كتابة رابط جديد ؟!')
		if cPoYMehxUObK67yG==-1: return
		elif cPoYMehxUObK67yG==0: RtM8jaClfbNXHQdPKog7ZrD = iiy37aKq0pCEIOwfcTh61xb4U
		elif cPoYMehxUObK67yG==2:
			cPoYMehxUObK67yG = A1AXKupEOfz('center',iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'رسالة من المبرمج','هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if cPoYMehxUObK67yG in [-1,0]: return
			bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'رسالة من المبرمج','تم مسح الرابط')
			M0OcgV2aoY = False
			DDIVhbjqvdpGL94xJlBS2tzNY5XeyM = iiy37aKq0pCEIOwfcTh61xb4U
	if M0OcgV2aoY:
		DDIVhbjqvdpGL94xJlBS2tzNY5XeyM = TTBf6S08q1NKXd5v9wa('اكتب رابط ـIPTV كاملا',RtM8jaClfbNXHQdPKog7ZrD)
		DDIVhbjqvdpGL94xJlBS2tzNY5XeyM = DDIVhbjqvdpGL94xJlBS2tzNY5XeyM.strip(iFBmE2MUIpSu34wsd7Rf6z)
		if not DDIVhbjqvdpGL94xJlBS2tzNY5XeyM:
			cPoYMehxUObK67yG = A1AXKupEOfz('center',iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'رسالة من المبرمج','لقد قمت بإدخال رابط فارغ .. هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if cPoYMehxUObK67yG in [-1,0]: return
			bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'رسالة من المبرمج','تم مسح الرابط')
	else:
		PufdHwFN0Qi5onleA1KZ,LjmRTZl5J3sfp4xywD6NkWIovgh,uOhjCkDo8b,M5FR8xYbQJCgD0Ewf,VgRjTyW5vFOdfExzMnPQSKUXZ1 = UrQ2K7hVyA(QZEi0WbICGAXPzH876,DDIVhbjqvdpGL94xJlBS2tzNY5XeyM)
		if not M5FR8xYbQJCgD0Ewf: return
		aZtYlicqMKUFPkBCX2AONHwJ4 = 'هذه المعلومات تم أخذها من رابط ـIPTV الذي انت كتبته . هل تريد استخدامها ؟!\n'
		aZtYlicqMKUFPkBCX2AONHwJ4 += OTlVEGYPSxsNaBdXUucqA3+aqEsMBckT2bunGHfl48Wip+uOhjCkDo8b+YoQW601K4fMJcsreDnGVE5wUZIy7+'عنوان السيرفر: '
		aZtYlicqMKUFPkBCX2AONHwJ4 += OTlVEGYPSxsNaBdXUucqA3+aqEsMBckT2bunGHfl48Wip+M5FR8xYbQJCgD0Ewf+YoQW601K4fMJcsreDnGVE5wUZIy7+'اسم المستخدم: '
		aZtYlicqMKUFPkBCX2AONHwJ4 += OTlVEGYPSxsNaBdXUucqA3+aqEsMBckT2bunGHfl48Wip+SzTrdCv6hYHAFt43mBlWOq++'كلمة السر: '
		cPoYMehxUObK67yG = A1AXKupEOfz('right',iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'الرابط الجديد هو:',PSwfZcdRYhpl5Igqz8xOEk67+DDIVhbjqvdpGL94xJlBS2tzNY5XeyM+YoQW601K4fMJcsreDnGVE5wUZIy7+'\n\n'+aZtYlicqMKUFPkBCX2AONHwJ4)
		if cPoYMehxUObK67yG!=1:
			bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'رسالة من المبرمج','تم الإلغاء')
			return
	OXsckY7RzjCag9A.setSetting('av.iptv.url_'+QZEi0WbICGAXPzH876,DDIVhbjqvdpGL94xJlBS2tzNY5XeyM)
	OXsckY7RzjCag9A.setSetting('av.iptv.timestamp_'+QZEi0WbICGAXPzH876,iiy37aKq0pCEIOwfcTh61xb4U)
	OXsckY7RzjCag9A.setSetting('av.iptv.timediff_'+QZEi0WbICGAXPzH876,iiy37aKq0pCEIOwfcTh61xb4U)
	b1aZrdVE0UN8h4KGMqXDAtxu9 = OXsckY7RzjCag9A.getSetting('av.iptv.useragent_'+QZEi0WbICGAXPzH876)
	if not b1aZrdVE0UN8h4KGMqXDAtxu9: OXsckY7RzjCag9A.setSetting('av.iptv.useragent_'+QZEi0WbICGAXPzH876,'Unknown')
	Io3FXx580SZtgPDUaE7lAd = A1AXKupEOfz('center',iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,DDIVhbjqvdpGL94xJlBS2tzNY5XeyM+'\n\nتم تغير رابط اشتراك ـIPTV إلى هذا الرابط الجديد ... هل تريد فحص هذا الرابط الآن ؟')
	if Io3FXx580SZtgPDUaE7lAd==1: VsfSE7hTyxPUko,PPvU1cC2HdhzS9KDQNgkRMrsmltwAG,mmkYeCUcryn2qxtEol7Q3 = m9sD2UNo3OnFbawyfcKrB(QZEi0WbICGAXPzH876,True)
	OlDUo31STWKuLHXcFG(QZEi0WbICGAXPzH876)
	return
def dDnThYVjEtzGkyW9K4eF6Hc(UCOyxvPEBiwmbkLdzfDjIM4rp,BwiFNxkrhgdA5m9qMKL3e2YoHafQ,iXfqR3NxVnwd5t8AjTmgL,rx0ViTX1zNycaPFqk2,Ih0XRyCBN6lKs,jpouXixl9Oqzvg2V3k8ZayRJNsnI,LjmRTZl5J3sfp4xywD6NkWIovgh):
	z0OXopbnK2E,mYCHMpaP2ObUxLFqV = [],[]
	yMnZepV78lP9hgRt = ['.avi','.mp4','.mkv','.mp3','.webm','.aac']
	for ALqPlOD34cfHQWk7ae0URbZotXNTFs in UCOyxvPEBiwmbkLdzfDjIM4rp:
		if jpouXixl9Oqzvg2V3k8ZayRJNsnI%473==0:
			o8oBqwQFbU2uL3SEGD0lgWO4xRnJYC(rx0ViTX1zNycaPFqk2,40+int(10*jpouXixl9Oqzvg2V3k8ZayRJNsnI/Ih0XRyCBN6lKs),'قراءة الفيديوهات','الفيديو رقم:-',str(jpouXixl9Oqzvg2V3k8ZayRJNsnI)+' / '+str(Ih0XRyCBN6lKs))
			if rx0ViTX1zNycaPFqk2.iscanceled():
				rx0ViTX1zNycaPFqk2.close()
				return None,None,None
		kMqh74TPvpSDar59xQUjAyVlHes = dEyT9xhGjolYzLCH7460w3.findall('^(.*?)\n+((http|https|rtmp).*?)$',ALqPlOD34cfHQWk7ae0URbZotXNTFs,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if kMqh74TPvpSDar59xQUjAyVlHes:
			ALqPlOD34cfHQWk7ae0URbZotXNTFs,kMqh74TPvpSDar59xQUjAyVlHes,HrzYa61RN5hAVS9BtnJ3mDy = kMqh74TPvpSDar59xQUjAyVlHes[0]
			kMqh74TPvpSDar59xQUjAyVlHes = kMqh74TPvpSDar59xQUjAyVlHes.replace(OTlVEGYPSxsNaBdXUucqA3,iiy37aKq0pCEIOwfcTh61xb4U)
			ALqPlOD34cfHQWk7ae0URbZotXNTFs = ALqPlOD34cfHQWk7ae0URbZotXNTFs.replace(OTlVEGYPSxsNaBdXUucqA3,iiy37aKq0pCEIOwfcTh61xb4U)
		else:
			mYCHMpaP2ObUxLFqV.append({'line':ALqPlOD34cfHQWk7ae0URbZotXNTFs})
			continue
		pjsubrfqUP9zw1la,YGNomIp2tDSR6ncf,DYxVAZjPCvdMScFfHLJ,svZJBpqOEQNyRPaDMUh870bCtdnT1,synCYOiMR789twmfr,MMyUn38BRTQeitDaXF = {},iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,False
		try:
			ALqPlOD34cfHQWk7ae0URbZotXNTFs,svZJBpqOEQNyRPaDMUh870bCtdnT1 = ALqPlOD34cfHQWk7ae0URbZotXNTFs.rsplit('",',1)
			ALqPlOD34cfHQWk7ae0URbZotXNTFs = ALqPlOD34cfHQWk7ae0URbZotXNTFs+'"'
		except:
			try: ALqPlOD34cfHQWk7ae0URbZotXNTFs,svZJBpqOEQNyRPaDMUh870bCtdnT1 = ALqPlOD34cfHQWk7ae0URbZotXNTFs.rsplit('1,',1)
			except: svZJBpqOEQNyRPaDMUh870bCtdnT1 = iiy37aKq0pCEIOwfcTh61xb4U
		pjsubrfqUP9zw1la['url'] = kMqh74TPvpSDar59xQUjAyVlHes
		AvZyDi2ap0cBxMNwdLh5GY6V = dEyT9xhGjolYzLCH7460w3.findall(' (.*?)="(.*?)"',ALqPlOD34cfHQWk7ae0URbZotXNTFs,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for cg8pNq2WQ6wszyjtC01JD,RoUcHZgQ3BkiYdCKFSu4TsfpW in AvZyDi2ap0cBxMNwdLh5GY6V:
			cg8pNq2WQ6wszyjtC01JD = cg8pNq2WQ6wszyjtC01JD.replace('"',iiy37aKq0pCEIOwfcTh61xb4U).strip(iFBmE2MUIpSu34wsd7Rf6z)
			pjsubrfqUP9zw1la[cg8pNq2WQ6wszyjtC01JD] = RoUcHZgQ3BkiYdCKFSu4TsfpW.strip(iFBmE2MUIpSu34wsd7Rf6z)
		glGxBsSfejhiZqyaI5FXADVHYc8 = list(pjsubrfqUP9zw1la.keys())
		if not svZJBpqOEQNyRPaDMUh870bCtdnT1:
			if 'name' in glGxBsSfejhiZqyaI5FXADVHYc8 and pjsubrfqUP9zw1la['name']: svZJBpqOEQNyRPaDMUh870bCtdnT1 = pjsubrfqUP9zw1la['name']
		pjsubrfqUP9zw1la['title'] = svZJBpqOEQNyRPaDMUh870bCtdnT1.strip(iFBmE2MUIpSu34wsd7Rf6z).replace(Wc5GekRC0HQLz7,iFBmE2MUIpSu34wsd7Rf6z).replace(Wc5GekRC0HQLz7,iFBmE2MUIpSu34wsd7Rf6z)
		if 'logo' in glGxBsSfejhiZqyaI5FXADVHYc8:
			pjsubrfqUP9zw1la['img'] = pjsubrfqUP9zw1la['logo']
			del pjsubrfqUP9zw1la['logo']
		else: pjsubrfqUP9zw1la['img'] = iiy37aKq0pCEIOwfcTh61xb4U
		if 'group' in glGxBsSfejhiZqyaI5FXADVHYc8 and pjsubrfqUP9zw1la['group']: DYxVAZjPCvdMScFfHLJ = pjsubrfqUP9zw1la['group']
		if any(aasX2cby4Vo5rTgB in kMqh74TPvpSDar59xQUjAyVlHes.lower() for aasX2cby4Vo5rTgB in yMnZepV78lP9hgRt):
			MMyUn38BRTQeitDaXF = True if 'm3u' not in kMqh74TPvpSDar59xQUjAyVlHes else False
		if MMyUn38BRTQeitDaXF or '__SERIES__' in DYxVAZjPCvdMScFfHLJ or '__MOVIES__' in DYxVAZjPCvdMScFfHLJ:
			synCYOiMR789twmfr = 'VOD'
			if '__SERIES__' in DYxVAZjPCvdMScFfHLJ: synCYOiMR789twmfr = synCYOiMR789twmfr+'_SERIES'
			elif '__MOVIES__' in DYxVAZjPCvdMScFfHLJ: synCYOiMR789twmfr = synCYOiMR789twmfr+'_MOVIES'
			else: synCYOiMR789twmfr = synCYOiMR789twmfr+'_UNKNOWN'
			DYxVAZjPCvdMScFfHLJ = DYxVAZjPCvdMScFfHLJ.replace('__SERIES__',iiy37aKq0pCEIOwfcTh61xb4U).replace('__MOVIES__',iiy37aKq0pCEIOwfcTh61xb4U)
		else:
			synCYOiMR789twmfr = 'LIVE'
			if svZJBpqOEQNyRPaDMUh870bCtdnT1 in BwiFNxkrhgdA5m9qMKL3e2YoHafQ: YGNomIp2tDSR6ncf = YGNomIp2tDSR6ncf+'_EPG'
			if svZJBpqOEQNyRPaDMUh870bCtdnT1 in iXfqR3NxVnwd5t8AjTmgL: YGNomIp2tDSR6ncf = YGNomIp2tDSR6ncf+'_ARCHIVED'
			if not DYxVAZjPCvdMScFfHLJ: synCYOiMR789twmfr = synCYOiMR789twmfr+'_UNKNOWN'
			else: synCYOiMR789twmfr = synCYOiMR789twmfr+YGNomIp2tDSR6ncf
		DYxVAZjPCvdMScFfHLJ = DYxVAZjPCvdMScFfHLJ.strip(iFBmE2MUIpSu34wsd7Rf6z).replace(Wc5GekRC0HQLz7,iFBmE2MUIpSu34wsd7Rf6z).replace(Wc5GekRC0HQLz7,iFBmE2MUIpSu34wsd7Rf6z)
		if 'LIVE_UNKNOWN' in synCYOiMR789twmfr: DYxVAZjPCvdMScFfHLJ = '!!__UNKNOWN_LIVE__!!'
		elif 'VOD_UNKNOWN' in synCYOiMR789twmfr: DYxVAZjPCvdMScFfHLJ = '!!__UNKNOWN_VOD__!!'
		elif 'VOD_SERIES' in synCYOiMR789twmfr:
			QN3uWtS6DXV8TFBbfLa = dEyT9xhGjolYzLCH7460w3.findall('(.*?) [Ss]\d+ +[Ee]\d+',pjsubrfqUP9zw1la['title'],dEyT9xhGjolYzLCH7460w3.DOTALL)
			if QN3uWtS6DXV8TFBbfLa: QN3uWtS6DXV8TFBbfLa = QN3uWtS6DXV8TFBbfLa[0]
			else: QN3uWtS6DXV8TFBbfLa = '!!__UNKNOWN_SERIES__!!'
			DYxVAZjPCvdMScFfHLJ = DYxVAZjPCvdMScFfHLJ+'__SERIES__'+QN3uWtS6DXV8TFBbfLa
		if 'id' in glGxBsSfejhiZqyaI5FXADVHYc8: del pjsubrfqUP9zw1la['id']
		if 'ID' in glGxBsSfejhiZqyaI5FXADVHYc8: del pjsubrfqUP9zw1la['ID']
		if 'name' in glGxBsSfejhiZqyaI5FXADVHYc8: del pjsubrfqUP9zw1la['name']
		svZJBpqOEQNyRPaDMUh870bCtdnT1 = pjsubrfqUP9zw1la['title']
		svZJBpqOEQNyRPaDMUh870bCtdnT1 = vvmT3DLXkhPBwIaOAo6srZpEnRVJC(svZJBpqOEQNyRPaDMUh870bCtdnT1)
		svZJBpqOEQNyRPaDMUh870bCtdnT1 = wI5A6gTQLjNvlcDhY4(svZJBpqOEQNyRPaDMUh870bCtdnT1)
		El9XMQkH23wubW8rBhRaJf1Ttc6GS,DYxVAZjPCvdMScFfHLJ = Obxnt9XrKEAIF04hCa5P(DYxVAZjPCvdMScFfHLJ)
		nTGiW3pkS4oF7,svZJBpqOEQNyRPaDMUh870bCtdnT1 = Obxnt9XrKEAIF04hCa5P(svZJBpqOEQNyRPaDMUh870bCtdnT1)
		pjsubrfqUP9zw1la['type'] = synCYOiMR789twmfr
		pjsubrfqUP9zw1la['context'] = YGNomIp2tDSR6ncf
		pjsubrfqUP9zw1la['group'] = DYxVAZjPCvdMScFfHLJ.upper()
		pjsubrfqUP9zw1la['title'] = svZJBpqOEQNyRPaDMUh870bCtdnT1.upper()
		pjsubrfqUP9zw1la['country'] = nTGiW3pkS4oF7.upper()
		pjsubrfqUP9zw1la['language'] = El9XMQkH23wubW8rBhRaJf1Ttc6GS.upper()
		z0OXopbnK2E.append(pjsubrfqUP9zw1la)
		jpouXixl9Oqzvg2V3k8ZayRJNsnI += 1
	return z0OXopbnK2E,jpouXixl9Oqzvg2V3k8ZayRJNsnI,mYCHMpaP2ObUxLFqV
def wI5A6gTQLjNvlcDhY4(svZJBpqOEQNyRPaDMUh870bCtdnT1):
	svZJBpqOEQNyRPaDMUh870bCtdnT1 = svZJBpqOEQNyRPaDMUh870bCtdnT1.replace(Wc5GekRC0HQLz7,iFBmE2MUIpSu34wsd7Rf6z).replace(Wc5GekRC0HQLz7,iFBmE2MUIpSu34wsd7Rf6z).replace(Wc5GekRC0HQLz7,iFBmE2MUIpSu34wsd7Rf6z)
	svZJBpqOEQNyRPaDMUh870bCtdnT1 = svZJBpqOEQNyRPaDMUh870bCtdnT1.replace('||','|').replace('___',':').replace('--','-')
	svZJBpqOEQNyRPaDMUh870bCtdnT1 = svZJBpqOEQNyRPaDMUh870bCtdnT1.replace('[[','[').replace(']]',']')
	svZJBpqOEQNyRPaDMUh870bCtdnT1 = svZJBpqOEQNyRPaDMUh870bCtdnT1.replace('((','(').replace('))',')')
	svZJBpqOEQNyRPaDMUh870bCtdnT1 = svZJBpqOEQNyRPaDMUh870bCtdnT1.replace('<<','<').replace('>>','>')
	svZJBpqOEQNyRPaDMUh870bCtdnT1 = svZJBpqOEQNyRPaDMUh870bCtdnT1.strip(iFBmE2MUIpSu34wsd7Rf6z)
	return svZJBpqOEQNyRPaDMUh870bCtdnT1
def kk0qTDL5x1P(oV028NSLx3AsZwjRruE1QG,rx0ViTX1zNycaPFqk2):
	LcoaMs1I8mgvx7qzSh = {}
	for SSvi7eIpcULPzgRMOaH9t1fTG5mu6K in NeizUlRJp5bQAuKhsaYv0P4gDI: LcoaMs1I8mgvx7qzSh[SSvi7eIpcULPzgRMOaH9t1fTG5mu6K] = []
	Ih0XRyCBN6lKs = len(oV028NSLx3AsZwjRruE1QG)
	uq50OaP7nV4mfoGg21sMFAptl = str(Ih0XRyCBN6lKs)
	jpouXixl9Oqzvg2V3k8ZayRJNsnI = 0
	mYCHMpaP2ObUxLFqV = []
	for pjsubrfqUP9zw1la in oV028NSLx3AsZwjRruE1QG:
		if jpouXixl9Oqzvg2V3k8ZayRJNsnI%873==0:
			o8oBqwQFbU2uL3SEGD0lgWO4xRnJYC(rx0ViTX1zNycaPFqk2,50+int(5*jpouXixl9Oqzvg2V3k8ZayRJNsnI/Ih0XRyCBN6lKs),'تصنيف الفيديوهات الغير مرتبة','الفيديو رقم:-',str(jpouXixl9Oqzvg2V3k8ZayRJNsnI)+' / '+uq50OaP7nV4mfoGg21sMFAptl)
			if rx0ViTX1zNycaPFqk2.iscanceled():
				rx0ViTX1zNycaPFqk2.close()
				return None,None
		DYxVAZjPCvdMScFfHLJ,YGNomIp2tDSR6ncf,svZJBpqOEQNyRPaDMUh870bCtdnT1,kMqh74TPvpSDar59xQUjAyVlHes,RtWKTkahzD0EuPVLpr = pjsubrfqUP9zw1la['group'],pjsubrfqUP9zw1la['context'],pjsubrfqUP9zw1la['title'],pjsubrfqUP9zw1la['url'],pjsubrfqUP9zw1la['img']
		nTGiW3pkS4oF7,El9XMQkH23wubW8rBhRaJf1Ttc6GS,SSvi7eIpcULPzgRMOaH9t1fTG5mu6K = pjsubrfqUP9zw1la['country'],pjsubrfqUP9zw1la['language'],pjsubrfqUP9zw1la['type']
		FDNwkgjHcC3A8zbVX2xlYUtZ6sTS = (DYxVAZjPCvdMScFfHLJ,YGNomIp2tDSR6ncf,svZJBpqOEQNyRPaDMUh870bCtdnT1,kMqh74TPvpSDar59xQUjAyVlHes,RtWKTkahzD0EuPVLpr)
		cWfY0x6XsVg3 = False
		if 'LIVE' in SSvi7eIpcULPzgRMOaH9t1fTG5mu6K:
			if 'UNKNOWN' in SSvi7eIpcULPzgRMOaH9t1fTG5mu6K: LcoaMs1I8mgvx7qzSh['LIVE_UNKNOWN_GROUPED'].append(FDNwkgjHcC3A8zbVX2xlYUtZ6sTS)
			elif 'LIVE' in SSvi7eIpcULPzgRMOaH9t1fTG5mu6K: LcoaMs1I8mgvx7qzSh['LIVE_GROUPED'].append(FDNwkgjHcC3A8zbVX2xlYUtZ6sTS)
			else: cWfY0x6XsVg3 = True
			LcoaMs1I8mgvx7qzSh['LIVE_ORIGINAL_GROUPED'].append(FDNwkgjHcC3A8zbVX2xlYUtZ6sTS)
		elif 'VOD' in SSvi7eIpcULPzgRMOaH9t1fTG5mu6K:
			if 'UNKNOWN' in SSvi7eIpcULPzgRMOaH9t1fTG5mu6K: LcoaMs1I8mgvx7qzSh['VOD_UNKNOWN_GROUPED'].append(FDNwkgjHcC3A8zbVX2xlYUtZ6sTS)
			elif 'MOVIES' in SSvi7eIpcULPzgRMOaH9t1fTG5mu6K: LcoaMs1I8mgvx7qzSh['VOD_MOVIES_GROUPED'].append(FDNwkgjHcC3A8zbVX2xlYUtZ6sTS)
			elif 'SERIES' in SSvi7eIpcULPzgRMOaH9t1fTG5mu6K: LcoaMs1I8mgvx7qzSh['VOD_SERIES_GROUPED'].append(FDNwkgjHcC3A8zbVX2xlYUtZ6sTS)
			else: cWfY0x6XsVg3 = True
			LcoaMs1I8mgvx7qzSh['VOD_ORIGINAL_GROUPED'].append(FDNwkgjHcC3A8zbVX2xlYUtZ6sTS)
		else: cWfY0x6XsVg3 = True
		if cWfY0x6XsVg3: mYCHMpaP2ObUxLFqV.append(pjsubrfqUP9zw1la)
		jpouXixl9Oqzvg2V3k8ZayRJNsnI += 1
	t3QsKd5a6D1xiXnFferLHBo = sorted(oV028NSLx3AsZwjRruE1QG,reverse=False,key=lambda cg8pNq2WQ6wszyjtC01JD: cg8pNq2WQ6wszyjtC01JD['title'].lower())
	del oV028NSLx3AsZwjRruE1QG
	uq50OaP7nV4mfoGg21sMFAptl = str(Ih0XRyCBN6lKs)
	jpouXixl9Oqzvg2V3k8ZayRJNsnI = 0
	for pjsubrfqUP9zw1la in t3QsKd5a6D1xiXnFferLHBo:
		jpouXixl9Oqzvg2V3k8ZayRJNsnI += 1
		if jpouXixl9Oqzvg2V3k8ZayRJNsnI%873==0:
			o8oBqwQFbU2uL3SEGD0lgWO4xRnJYC(rx0ViTX1zNycaPFqk2,55+int(5*jpouXixl9Oqzvg2V3k8ZayRJNsnI/Ih0XRyCBN6lKs),'تصنيف الفيديوهات المرتبة','الفيديو رقم:-',str(jpouXixl9Oqzvg2V3k8ZayRJNsnI)+' / '+uq50OaP7nV4mfoGg21sMFAptl)
			if rx0ViTX1zNycaPFqk2.iscanceled():
				rx0ViTX1zNycaPFqk2.close()
				return None,None
		SSvi7eIpcULPzgRMOaH9t1fTG5mu6K = pjsubrfqUP9zw1la['type']
		DYxVAZjPCvdMScFfHLJ,YGNomIp2tDSR6ncf,svZJBpqOEQNyRPaDMUh870bCtdnT1,kMqh74TPvpSDar59xQUjAyVlHes,RtWKTkahzD0EuPVLpr = pjsubrfqUP9zw1la['group'],pjsubrfqUP9zw1la['context'],pjsubrfqUP9zw1la['title'],pjsubrfqUP9zw1la['url'],pjsubrfqUP9zw1la['img']
		nTGiW3pkS4oF7,El9XMQkH23wubW8rBhRaJf1Ttc6GS = pjsubrfqUP9zw1la['country'],pjsubrfqUP9zw1la['language']
		J0t4efIOc7DjG2B61Ss8Ag = (DYxVAZjPCvdMScFfHLJ,YGNomIp2tDSR6ncf+'_TIMESHIFT',svZJBpqOEQNyRPaDMUh870bCtdnT1,kMqh74TPvpSDar59xQUjAyVlHes,RtWKTkahzD0EuPVLpr)
		FDNwkgjHcC3A8zbVX2xlYUtZ6sTS = (DYxVAZjPCvdMScFfHLJ,YGNomIp2tDSR6ncf,svZJBpqOEQNyRPaDMUh870bCtdnT1,kMqh74TPvpSDar59xQUjAyVlHes,RtWKTkahzD0EuPVLpr)
		MaWBQucY3h0HJTv8nmSCN4so6ZjpR = (nTGiW3pkS4oF7,YGNomIp2tDSR6ncf,svZJBpqOEQNyRPaDMUh870bCtdnT1,kMqh74TPvpSDar59xQUjAyVlHes,RtWKTkahzD0EuPVLpr)
		nVdGXsWH1LCOJIw8Qetmap = (El9XMQkH23wubW8rBhRaJf1Ttc6GS,YGNomIp2tDSR6ncf,svZJBpqOEQNyRPaDMUh870bCtdnT1,kMqh74TPvpSDar59xQUjAyVlHes,RtWKTkahzD0EuPVLpr)
		if 'LIVE' in SSvi7eIpcULPzgRMOaH9t1fTG5mu6K:
			if 'UNKNOWN' in SSvi7eIpcULPzgRMOaH9t1fTG5mu6K: LcoaMs1I8mgvx7qzSh['LIVE_UNKNOWN_GROUPED_SORTED'].append(FDNwkgjHcC3A8zbVX2xlYUtZ6sTS)
			else: LcoaMs1I8mgvx7qzSh['LIVE_GROUPED_SORTED'].append(FDNwkgjHcC3A8zbVX2xlYUtZ6sTS)
			if 'EPG'		in SSvi7eIpcULPzgRMOaH9t1fTG5mu6K: LcoaMs1I8mgvx7qzSh['LIVE_EPG_GROUPED_SORTED'].append(FDNwkgjHcC3A8zbVX2xlYUtZ6sTS)
			if 'ARCHIVED'	in SSvi7eIpcULPzgRMOaH9t1fTG5mu6K: LcoaMs1I8mgvx7qzSh['LIVE_ARCHIVED_GROUPED_SORTED'].append(FDNwkgjHcC3A8zbVX2xlYUtZ6sTS)
			if 'ARCHIVED'	in SSvi7eIpcULPzgRMOaH9t1fTG5mu6K: LcoaMs1I8mgvx7qzSh['LIVE_TIMESHIFT_GROUPED_SORTED'].append(J0t4efIOc7DjG2B61Ss8Ag)
			LcoaMs1I8mgvx7qzSh['LIVE_FROM_NAME_SORTED'].append(MaWBQucY3h0HJTv8nmSCN4so6ZjpR)
			LcoaMs1I8mgvx7qzSh['LIVE_FROM_GROUP_SORTED'].append(nVdGXsWH1LCOJIw8Qetmap)
		elif 'VOD' in SSvi7eIpcULPzgRMOaH9t1fTG5mu6K:
			if   'UNKNOWN'	in SSvi7eIpcULPzgRMOaH9t1fTG5mu6K: LcoaMs1I8mgvx7qzSh['VOD_UNKNOWN_GROUPED_SORTED'].append(FDNwkgjHcC3A8zbVX2xlYUtZ6sTS)
			elif 'MOVIES'	in SSvi7eIpcULPzgRMOaH9t1fTG5mu6K: LcoaMs1I8mgvx7qzSh['VOD_MOVIES_GROUPED_SORTED'].append(FDNwkgjHcC3A8zbVX2xlYUtZ6sTS)
			elif 'SERIES'	in SSvi7eIpcULPzgRMOaH9t1fTG5mu6K: LcoaMs1I8mgvx7qzSh['VOD_SERIES_GROUPED_SORTED'].append(FDNwkgjHcC3A8zbVX2xlYUtZ6sTS)
			LcoaMs1I8mgvx7qzSh['VOD_FROM_NAME_SORTED'].append(MaWBQucY3h0HJTv8nmSCN4so6ZjpR)
			LcoaMs1I8mgvx7qzSh['VOD_FROM_GROUP_SORTED'].append(nVdGXsWH1LCOJIw8Qetmap)
	return LcoaMs1I8mgvx7qzSh,mYCHMpaP2ObUxLFqV
def Obxnt9XrKEAIF04hCa5P(svZJBpqOEQNyRPaDMUh870bCtdnT1):
	if len(svZJBpqOEQNyRPaDMUh870bCtdnT1)<3: return svZJBpqOEQNyRPaDMUh870bCtdnT1,svZJBpqOEQNyRPaDMUh870bCtdnT1
	qFDW3lkLsoApuBV1M,okr6qGW49yUF0NhBg1JlwM = iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U
	BW94zas1KtO27LRgbCP = svZJBpqOEQNyRPaDMUh870bCtdnT1
	u6rmUyz3EGxJM7SO = svZJBpqOEQNyRPaDMUh870bCtdnT1[:1]
	bO36ItodLFBjnliP5VrQys = svZJBpqOEQNyRPaDMUh870bCtdnT1[1:]
	if   u6rmUyz3EGxJM7SO=='(': okr6qGW49yUF0NhBg1JlwM = ')'
	elif u6rmUyz3EGxJM7SO=='[': okr6qGW49yUF0NhBg1JlwM = ']'
	elif u6rmUyz3EGxJM7SO=='<': okr6qGW49yUF0NhBg1JlwM = '>'
	elif u6rmUyz3EGxJM7SO=='|': okr6qGW49yUF0NhBg1JlwM = '|'
	if okr6qGW49yUF0NhBg1JlwM and (okr6qGW49yUF0NhBg1JlwM in bO36ItodLFBjnliP5VrQys):
		D3JYyt2MFXEwAuVLskc4C,xQguitdWbhCUIznm785LD = bO36ItodLFBjnliP5VrQys.split(okr6qGW49yUF0NhBg1JlwM,1)
		qFDW3lkLsoApuBV1M = D3JYyt2MFXEwAuVLskc4C
		BW94zas1KtO27LRgbCP = u6rmUyz3EGxJM7SO+D3JYyt2MFXEwAuVLskc4C+okr6qGW49yUF0NhBg1JlwM+iFBmE2MUIpSu34wsd7Rf6z+xQguitdWbhCUIznm785LD
	elif svZJBpqOEQNyRPaDMUh870bCtdnT1.count('|')>=2:
		D3JYyt2MFXEwAuVLskc4C,xQguitdWbhCUIznm785LD = svZJBpqOEQNyRPaDMUh870bCtdnT1.split('|',1)
		qFDW3lkLsoApuBV1M = D3JYyt2MFXEwAuVLskc4C
		BW94zas1KtO27LRgbCP = D3JYyt2MFXEwAuVLskc4C+' |'+xQguitdWbhCUIznm785LD
	else:
		okr6qGW49yUF0NhBg1JlwM = dEyT9xhGjolYzLCH7460w3.findall('^\w{2}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',svZJBpqOEQNyRPaDMUh870bCtdnT1,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if not okr6qGW49yUF0NhBg1JlwM: okr6qGW49yUF0NhBg1JlwM = dEyT9xhGjolYzLCH7460w3.findall('^\w{3}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',svZJBpqOEQNyRPaDMUh870bCtdnT1,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if not okr6qGW49yUF0NhBg1JlwM: okr6qGW49yUF0NhBg1JlwM = dEyT9xhGjolYzLCH7460w3.findall('^\w{4}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',svZJBpqOEQNyRPaDMUh870bCtdnT1,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if okr6qGW49yUF0NhBg1JlwM:
			D3JYyt2MFXEwAuVLskc4C,xQguitdWbhCUIznm785LD = svZJBpqOEQNyRPaDMUh870bCtdnT1.split(okr6qGW49yUF0NhBg1JlwM[0],1)
			qFDW3lkLsoApuBV1M = D3JYyt2MFXEwAuVLskc4C
			BW94zas1KtO27LRgbCP = D3JYyt2MFXEwAuVLskc4C+iFBmE2MUIpSu34wsd7Rf6z+okr6qGW49yUF0NhBg1JlwM[0]+iFBmE2MUIpSu34wsd7Rf6z+xQguitdWbhCUIznm785LD
	BW94zas1KtO27LRgbCP = BW94zas1KtO27LRgbCP.replace(jHLaUg49SXC6JyTM,iFBmE2MUIpSu34wsd7Rf6z).replace(Wc5GekRC0HQLz7,iFBmE2MUIpSu34wsd7Rf6z)
	qFDW3lkLsoApuBV1M = qFDW3lkLsoApuBV1M.replace(Wc5GekRC0HQLz7,iFBmE2MUIpSu34wsd7Rf6z)
	if not qFDW3lkLsoApuBV1M: qFDW3lkLsoApuBV1M = '!!__UNKNOWN__!!'
	qFDW3lkLsoApuBV1M = qFDW3lkLsoApuBV1M.strip(iFBmE2MUIpSu34wsd7Rf6z)
	BW94zas1KtO27LRgbCP = BW94zas1KtO27LRgbCP.strip(iFBmE2MUIpSu34wsd7Rf6z)
	return qFDW3lkLsoApuBV1M,BW94zas1KtO27LRgbCP
def IIao4mWn2BRMk(QZEi0WbICGAXPzH876):
	qNojFLzuAkDZHEy1d4scer = {}
	b1aZrdVE0UN8h4KGMqXDAtxu9 = OXsckY7RzjCag9A.getSetting('av.iptv.useragent_'+QZEi0WbICGAXPzH876)
	if b1aZrdVE0UN8h4KGMqXDAtxu9: qNojFLzuAkDZHEy1d4scer['User-Agent'] = b1aZrdVE0UN8h4KGMqXDAtxu9
	XNpSgHj5iceQ3v7TD9Ww = OXsckY7RzjCag9A.getSetting('av.iptv.referer_'+QZEi0WbICGAXPzH876)
	if XNpSgHj5iceQ3v7TD9Ww: qNojFLzuAkDZHEy1d4scer['Referer'] = XNpSgHj5iceQ3v7TD9Ww
	return qNojFLzuAkDZHEy1d4scer
def qMwhogZNPrE98AkLx6Ht7jJS(QZEi0WbICGAXPzH876):
	global rx0ViTX1zNycaPFqk2,LcoaMs1I8mgvx7qzSh,VV7IB0jaMcSxQH8lLETURoFK5AP,lBvniw69puMcWhR7gFHL1AXTPst0,YaFdrXAnsmVlfZjgW159KCozNDxe,iqvYpcmt6Ejy5JUbMONRgFze,OBkqRVJCGZsTKAd35SHWxvn,JAhFBXIlNZ6TtbpgnGqwdiyQkK,STAiGI40jtl29LmoPCEp3aXhguD
	PufdHwFN0Qi5onleA1KZ,LjmRTZl5J3sfp4xywD6NkWIovgh,uOhjCkDo8b,M5FR8xYbQJCgD0Ewf,VgRjTyW5vFOdfExzMnPQSKUXZ1 = UrQ2K7hVyA(QZEi0WbICGAXPzH876)
	if not M5FR8xYbQJCgD0Ewf: return
	qNojFLzuAkDZHEy1d4scer = IIao4mWn2BRMk(QZEi0WbICGAXPzH876)
	ylRmrkV2fv4nGLC = A1AXKupEOfz('center',iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'رسالة من المبرمج','جلب ملفات ـIPTV جديدة قد تحتاج عدة دقائق . هل تريد أن تجلب الملفات الآن ؟')
	if ylRmrkV2fv4nGLC!=1: return
	woXtcOCiSEJkj4Y8uvgK2s0f = mzo15abwgdesuvn4CEGjSiNpDYVk.replace('___','_'+QZEi0WbICGAXPzH876)
	if 1:
		VsfSE7hTyxPUko,PPvU1cC2HdhzS9KDQNgkRMrsmltwAG,mmkYeCUcryn2qxtEol7Q3 = m9sD2UNo3OnFbawyfcKrB(QZEi0WbICGAXPzH876,False)
		if not VsfSE7hTyxPUko:
			bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'رسالة من المبرمج','فشل بسحب ملفات ـIPTV . أحتمال رابط ـIPTV غير صحيح أو قديم أو لا يعمل .. علما أن هذه الخدمة تحتاج اشتراك مدفوع وصحيح ويجب أن تضيف رابط الاشتراك بنفسك للبرنامج باستخدام قائمة ـIPTV الموجودة بهذا البرنامج')
			if not LjmRTZl5J3sfp4xywD6NkWIovgh: WKquk5EaNr4RzVf(uiza5vIyTWtUeB8sXwAVYMFpgjrk,IIZ4e82HBP0oTmtOgaWY7hsMz(x25j0zbNOqAe4BgIoQtcd)+'   No IPTV URL found to download IPTV files')
			else: WKquk5EaNr4RzVf(uiza5vIyTWtUeB8sXwAVYMFpgjrk,IIZ4e82HBP0oTmtOgaWY7hsMz(x25j0zbNOqAe4BgIoQtcd)+'   Failed to download IPTV files')
			return
		RgAdhIQClnijBmu54UG2sP3S1N = HHECmRlDkqTty05rGveI7hc436XA(LjmRTZl5J3sfp4xywD6NkWIovgh,qNojFLzuAkDZHEy1d4scer,True)
		if not RgAdhIQClnijBmu54UG2sP3S1N: return
		open(woXtcOCiSEJkj4Y8uvgK2s0f,'wb').write(RgAdhIQClnijBmu54UG2sP3S1N)
	else: RgAdhIQClnijBmu54UG2sP3S1N = open(woXtcOCiSEJkj4Y8uvgK2s0f,'rb').read()
	if J1MoiYc7ZwzKS and RgAdhIQClnijBmu54UG2sP3S1N: RgAdhIQClnijBmu54UG2sP3S1N = RgAdhIQClnijBmu54UG2sP3S1N.decode(df6QpwGxuJVZr)
	rx0ViTX1zNycaPFqk2 = BH5w8KScjpRhAkI7PlqDU()
	rx0ViTX1zNycaPFqk2.create('جلب ملفات ـIPTV جديدة',iiy37aKq0pCEIOwfcTh61xb4U)
	o8oBqwQFbU2uL3SEGD0lgWO4xRnJYC(rx0ViTX1zNycaPFqk2,15,'تنظيف الملف الرئيسي',iiy37aKq0pCEIOwfcTh61xb4U)
	RgAdhIQClnijBmu54UG2sP3S1N = RgAdhIQClnijBmu54UG2sP3S1N.replace('"tvg-','" tvg-')
	RgAdhIQClnijBmu54UG2sP3S1N = RgAdhIQClnijBmu54UG2sP3S1N.replace('َ',iiy37aKq0pCEIOwfcTh61xb4U).replace('ً',iiy37aKq0pCEIOwfcTh61xb4U).replace('ُ',iiy37aKq0pCEIOwfcTh61xb4U).replace('ٌ',iiy37aKq0pCEIOwfcTh61xb4U)
	RgAdhIQClnijBmu54UG2sP3S1N = RgAdhIQClnijBmu54UG2sP3S1N.replace('ّ',iiy37aKq0pCEIOwfcTh61xb4U).replace('ِ',iiy37aKq0pCEIOwfcTh61xb4U).replace('ٍ',iiy37aKq0pCEIOwfcTh61xb4U).replace('ْ',iiy37aKq0pCEIOwfcTh61xb4U)
	RgAdhIQClnijBmu54UG2sP3S1N = RgAdhIQClnijBmu54UG2sP3S1N.replace('group-title=','group=').replace('tvg-',iiy37aKq0pCEIOwfcTh61xb4U)
	iXfqR3NxVnwd5t8AjTmgL,BwiFNxkrhgdA5m9qMKL3e2YoHafQ = [],[]
	o8oBqwQFbU2uL3SEGD0lgWO4xRnJYC(rx0ViTX1zNycaPFqk2,20,'جلب الملفات الثانوية','الملف رقم:-','1 / 3')
	if rx0ViTX1zNycaPFqk2.iscanceled():
		rx0ViTX1zNycaPFqk2.close()
		return
	kMqh74TPvpSDar59xQUjAyVlHes = PufdHwFN0Qi5onleA1KZ+'&action=get_series_categories'
	oikBndh2USEOV = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',kMqh74TPvpSDar59xQUjAyVlHes,iiy37aKq0pCEIOwfcTh61xb4U,qNojFLzuAkDZHEy1d4scer,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'IPTV-CREATE_STREAMS-1st')
	JiUpSTZWMhHP = oikBndh2USEOV.content
	JiUpSTZWMhHP = vvmT3DLXkhPBwIaOAo6srZpEnRVJC(JiUpSTZWMhHP)
	gxeZmynrQV4R58p2 = dEyT9xhGjolYzLCH7460w3.findall('category_name":"(.*?)"',JiUpSTZWMhHP,dEyT9xhGjolYzLCH7460w3.DOTALL)
	del JiUpSTZWMhHP
	for DYxVAZjPCvdMScFfHLJ in gxeZmynrQV4R58p2:
		DYxVAZjPCvdMScFfHLJ = DYxVAZjPCvdMScFfHLJ.replace('\/','/')
		if iELueYz3J1FmxaW7vc: DYxVAZjPCvdMScFfHLJ = DYxVAZjPCvdMScFfHLJ.decode(df6QpwGxuJVZr).encode(df6QpwGxuJVZr)
		RgAdhIQClnijBmu54UG2sP3S1N = RgAdhIQClnijBmu54UG2sP3S1N.replace('group="'+DYxVAZjPCvdMScFfHLJ+'"','group="__SERIES__'+DYxVAZjPCvdMScFfHLJ+'"')
	del gxeZmynrQV4R58p2
	o8oBqwQFbU2uL3SEGD0lgWO4xRnJYC(rx0ViTX1zNycaPFqk2,25,'جلب الملفات الثانوية','الملف رقم:-','2 / 3')
	if rx0ViTX1zNycaPFqk2.iscanceled():
		rx0ViTX1zNycaPFqk2.close()
		return
	kMqh74TPvpSDar59xQUjAyVlHes = PufdHwFN0Qi5onleA1KZ+'&action=get_vod_categories'
	oikBndh2USEOV = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',kMqh74TPvpSDar59xQUjAyVlHes,iiy37aKq0pCEIOwfcTh61xb4U,qNojFLzuAkDZHEy1d4scer,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'IPTV-CREATE_STREAMS-2nd')
	JiUpSTZWMhHP = oikBndh2USEOV.content
	JiUpSTZWMhHP = vvmT3DLXkhPBwIaOAo6srZpEnRVJC(JiUpSTZWMhHP)
	mjBiOdbQf6F8y1Ku = dEyT9xhGjolYzLCH7460w3.findall('category_name":"(.*?)"',JiUpSTZWMhHP,dEyT9xhGjolYzLCH7460w3.DOTALL)
	del JiUpSTZWMhHP
	for DYxVAZjPCvdMScFfHLJ in mjBiOdbQf6F8y1Ku:
		DYxVAZjPCvdMScFfHLJ = DYxVAZjPCvdMScFfHLJ.replace('\/','/')
		if iELueYz3J1FmxaW7vc: DYxVAZjPCvdMScFfHLJ = DYxVAZjPCvdMScFfHLJ.decode(df6QpwGxuJVZr).encode(df6QpwGxuJVZr)
		RgAdhIQClnijBmu54UG2sP3S1N = RgAdhIQClnijBmu54UG2sP3S1N.replace('group="'+DYxVAZjPCvdMScFfHLJ+'"','group="__MOVIES__'+DYxVAZjPCvdMScFfHLJ+'"')
	del mjBiOdbQf6F8y1Ku
	o8oBqwQFbU2uL3SEGD0lgWO4xRnJYC(rx0ViTX1zNycaPFqk2,30,'جلب الملفات الثانوية','الملف رقم:-','3 / 3')
	if rx0ViTX1zNycaPFqk2.iscanceled():
		rx0ViTX1zNycaPFqk2.close()
		return
	kMqh74TPvpSDar59xQUjAyVlHes = PufdHwFN0Qi5onleA1KZ+'&action=get_live_streams'
	oikBndh2USEOV = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',kMqh74TPvpSDar59xQUjAyVlHes,iiy37aKq0pCEIOwfcTh61xb4U,qNojFLzuAkDZHEy1d4scer,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'IPTV-CREATE_STREAMS-3rd')
	JiUpSTZWMhHP = oikBndh2USEOV.content
	JiUpSTZWMhHP = vvmT3DLXkhPBwIaOAo6srZpEnRVJC(JiUpSTZWMhHP)
	NRjiuq0kGbef = dEyT9xhGjolYzLCH7460w3.findall('"name":"(.*?)".*?"tv_archive":(.*?),',JiUpSTZWMhHP,dEyT9xhGjolYzLCH7460w3.DOTALL)
	for JJwnocyLUxHI2jlKF4Y,E1XSIpgezf0Z in NRjiuq0kGbef:
		if E1XSIpgezf0Z=='1': iXfqR3NxVnwd5t8AjTmgL.append(JJwnocyLUxHI2jlKF4Y)
	del NRjiuq0kGbef
	M4O8sdbCzBQIlHkAfeD = dEyT9xhGjolYzLCH7460w3.findall('"name":"(.*?)".*?"epg_channel_id":(.*?),',JiUpSTZWMhHP,dEyT9xhGjolYzLCH7460w3.DOTALL)
	del JiUpSTZWMhHP
	for JJwnocyLUxHI2jlKF4Y,xjA6JhvQWPpm7HL5bnS190wqes in M4O8sdbCzBQIlHkAfeD:
		if xjA6JhvQWPpm7HL5bnS190wqes!='null': BwiFNxkrhgdA5m9qMKL3e2YoHafQ.append(JJwnocyLUxHI2jlKF4Y)
	del M4O8sdbCzBQIlHkAfeD
	RgAdhIQClnijBmu54UG2sP3S1N = RgAdhIQClnijBmu54UG2sP3S1N.replace(Mge0HhFk9Ic6sm5VR,OTlVEGYPSxsNaBdXUucqA3)
	UCOyxvPEBiwmbkLdzfDjIM4rp = dEyT9xhGjolYzLCH7460w3.findall('NF:(.+?)'+'#'+'EXTI',RgAdhIQClnijBmu54UG2sP3S1N+'\n+'+'#'+'EXTINF:',dEyT9xhGjolYzLCH7460w3.DOTALL)
	if not UCOyxvPEBiwmbkLdzfDjIM4rp:
		WKquk5EaNr4RzVf(uiza5vIyTWtUeB8sXwAVYMFpgjrk,IIZ4e82HBP0oTmtOgaWY7hsMz(x25j0zbNOqAe4BgIoQtcd)+'   Folder:'+QZEi0WbICGAXPzH876+'   No video links found in IPTV file')
		bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'رسالة من المبرمج','رابط ـIPTV الذي أنت أضفته لا توجد فيه فيديوهات .. احتمال رابط ـIPTV غير صحيح'+OTlVEGYPSxsNaBdXUucqA3+aqEsMBckT2bunGHfl48Wip+'مجلد رقم '+QZEi0WbICGAXPzH876)
		rx0ViTX1zNycaPFqk2.close()
		return
	se1mo6SHYbw2U83KkiCIPzdW = []
	for ALqPlOD34cfHQWk7ae0URbZotXNTFs in UCOyxvPEBiwmbkLdzfDjIM4rp:
		i7ivzogwbtl568TBLPyIM = ALqPlOD34cfHQWk7ae0URbZotXNTFs.lower()
		if 'adult' in i7ivzogwbtl568TBLPyIM: continue
		if 'xxx' in i7ivzogwbtl568TBLPyIM: continue
		se1mo6SHYbw2U83KkiCIPzdW.append(ALqPlOD34cfHQWk7ae0URbZotXNTFs)
	UCOyxvPEBiwmbkLdzfDjIM4rp = se1mo6SHYbw2U83KkiCIPzdW
	del se1mo6SHYbw2U83KkiCIPzdW
	bguC9ey5DoNicFWrlvKT48qm = 1024*1024
	tt3QwjiROkC = 1+len(RgAdhIQClnijBmu54UG2sP3S1N)//bguC9ey5DoNicFWrlvKT48qm//10
	del RgAdhIQClnijBmu54UG2sP3S1N
	KX9oJzlHUN5bWx0RM1pYCT = len(UCOyxvPEBiwmbkLdzfDjIM4rp)
	BAqxQc24TYEpsM6h = QavKJFzZAO3(UCOyxvPEBiwmbkLdzfDjIM4rp,tt3QwjiROkC)
	del UCOyxvPEBiwmbkLdzfDjIM4rp
	for mi7Q1WRhZUJF3GOczo in range(tt3QwjiROkC):
		o8oBqwQFbU2uL3SEGD0lgWO4xRnJYC(rx0ViTX1zNycaPFqk2,35+int(5*mi7Q1WRhZUJF3GOczo/tt3QwjiROkC),'تقطيع الملف الرئيسي','الجزء رقم:-',str(mi7Q1WRhZUJF3GOczo+1)+' / '+str(tt3QwjiROkC))
		if rx0ViTX1zNycaPFqk2.iscanceled():
			rx0ViTX1zNycaPFqk2.close()
			return
		Rs7Y23ION8VzXQrPFG = str(BAqxQc24TYEpsM6h[mi7Q1WRhZUJF3GOczo])
		if J1MoiYc7ZwzKS: Rs7Y23ION8VzXQrPFG = Rs7Y23ION8VzXQrPFG.encode(df6QpwGxuJVZr)
		open(woXtcOCiSEJkj4Y8uvgK2s0f+'.00'+str(mi7Q1WRhZUJF3GOczo),'wb').write(Rs7Y23ION8VzXQrPFG)
	del BAqxQc24TYEpsM6h,Rs7Y23ION8VzXQrPFG
	hhdXuQ4l8tKvNaoqm5DnVAisFZP,oV028NSLx3AsZwjRruE1QG,jpouXixl9Oqzvg2V3k8ZayRJNsnI = [],[],0
	for mi7Q1WRhZUJF3GOczo in range(tt3QwjiROkC):
		if rx0ViTX1zNycaPFqk2.iscanceled():
			rx0ViTX1zNycaPFqk2.close()
			return
		Rs7Y23ION8VzXQrPFG = open(woXtcOCiSEJkj4Y8uvgK2s0f+'.00'+str(mi7Q1WRhZUJF3GOczo),'rb').read()
		X2cQ5NCPvkMieBW7oASspFjE.sleep(1)
		try: wkMR5x1gTWEQIc6qHCa.remove(woXtcOCiSEJkj4Y8uvgK2s0f+'.00'+str(mi7Q1WRhZUJF3GOczo))
		except: pass
		if J1MoiYc7ZwzKS: Rs7Y23ION8VzXQrPFG = Rs7Y23ION8VzXQrPFG.decode(df6QpwGxuJVZr)
		YzFK4GlsROEJw0mPIiqyL3og1Q = DeIL3qoa2UBtYPb('list',Rs7Y23ION8VzXQrPFG)
		del Rs7Y23ION8VzXQrPFG
		z0OXopbnK2E,jpouXixl9Oqzvg2V3k8ZayRJNsnI,mYCHMpaP2ObUxLFqV = dDnThYVjEtzGkyW9K4eF6Hc(YzFK4GlsROEJw0mPIiqyL3og1Q,BwiFNxkrhgdA5m9qMKL3e2YoHafQ,iXfqR3NxVnwd5t8AjTmgL,rx0ViTX1zNycaPFqk2,KX9oJzlHUN5bWx0RM1pYCT,jpouXixl9Oqzvg2V3k8ZayRJNsnI,LjmRTZl5J3sfp4xywD6NkWIovgh)
		if rx0ViTX1zNycaPFqk2.iscanceled():
			rx0ViTX1zNycaPFqk2.close()
			return
		if not z0OXopbnK2E:
			rx0ViTX1zNycaPFqk2.close()
			return
		oV028NSLx3AsZwjRruE1QG += z0OXopbnK2E
		hhdXuQ4l8tKvNaoqm5DnVAisFZP += mYCHMpaP2ObUxLFqV
	del YzFK4GlsROEJw0mPIiqyL3og1Q,z0OXopbnK2E
	LcoaMs1I8mgvx7qzSh,mYCHMpaP2ObUxLFqV = kk0qTDL5x1P(oV028NSLx3AsZwjRruE1QG,rx0ViTX1zNycaPFqk2)
	if rx0ViTX1zNycaPFqk2.iscanceled():
		rx0ViTX1zNycaPFqk2.close()
		return
	hhdXuQ4l8tKvNaoqm5DnVAisFZP += mYCHMpaP2ObUxLFqV
	del oV028NSLx3AsZwjRruE1QG,mYCHMpaP2ObUxLFqV
	lBvniw69puMcWhR7gFHL1AXTPst0,YaFdrXAnsmVlfZjgW159KCozNDxe,iqvYpcmt6Ejy5JUbMONRgFze,OBkqRVJCGZsTKAd35SHWxvn,JAhFBXIlNZ6TtbpgnGqwdiyQkK = {},{},{},0,0
	bIFd019KOg5 = list(LcoaMs1I8mgvx7qzSh.keys())
	STAiGI40jtl29LmoPCEp3aXhguD = len(bIFd019KOg5)*3
	if 1:
		cL5pBywjAPY40 = {}
		for ERdVgaeYJtcbmM5AFkZNn in bIFd019KOg5:
			cL5pBywjAPY40[ERdVgaeYJtcbmM5AFkZNn] = EEehSFDLdpKBR3W1ga9PxrV.Thread(target=eS7CFoPqL1ak4UwQTgmyx,args=(ERdVgaeYJtcbmM5AFkZNn,))
			cL5pBywjAPY40[ERdVgaeYJtcbmM5AFkZNn].start()
		for ERdVgaeYJtcbmM5AFkZNn in bIFd019KOg5:
			cL5pBywjAPY40[ERdVgaeYJtcbmM5AFkZNn].join()
		if rx0ViTX1zNycaPFqk2.iscanceled():
			rx0ViTX1zNycaPFqk2.close()
			return
	else:
		for ERdVgaeYJtcbmM5AFkZNn in bIFd019KOg5:
			eS7CFoPqL1ak4UwQTgmyx(ERdVgaeYJtcbmM5AFkZNn)
			if rx0ViTX1zNycaPFqk2.iscanceled():
				rx0ViTX1zNycaPFqk2.close()
				return
	DDGYfd2miAauNzOVsUxEJb1ecyRXQ5(QZEi0WbICGAXPzH876,False)
	bIFd019KOg5 = list(lBvniw69puMcWhR7gFHL1AXTPst0.keys())
	VV7IB0jaMcSxQH8lLETURoFK5AP = 0
	if 1:
		cL5pBywjAPY40 = {}
		for ERdVgaeYJtcbmM5AFkZNn in bIFd019KOg5:
			cL5pBywjAPY40[ERdVgaeYJtcbmM5AFkZNn] = EEehSFDLdpKBR3W1ga9PxrV.Thread(target=rTnMfHIG0WASwmheDFYq3uP,args=(QZEi0WbICGAXPzH876,ERdVgaeYJtcbmM5AFkZNn))
			cL5pBywjAPY40[ERdVgaeYJtcbmM5AFkZNn].start()
		for ERdVgaeYJtcbmM5AFkZNn in bIFd019KOg5:
			cL5pBywjAPY40[ERdVgaeYJtcbmM5AFkZNn].join()
		if rx0ViTX1zNycaPFqk2.iscanceled():
			rx0ViTX1zNycaPFqk2.close()
			return
	else:
		for ERdVgaeYJtcbmM5AFkZNn in bIFd019KOg5:
			rTnMfHIG0WASwmheDFYq3uP(QZEi0WbICGAXPzH876,ERdVgaeYJtcbmM5AFkZNn)
			if rx0ViTX1zNycaPFqk2.iscanceled():
				rx0ViTX1zNycaPFqk2.close()
				return
	mi7Q1WRhZUJF3GOczo = 0
	KV7ANvXGq5I2nok4fjxOWP0pb = len(hhdXuQ4l8tKvNaoqm5DnVAisFZP)
	zzPO3oKR8eVEcI4ruS5wGhyQ = m8tbAHrJLowOSax2NdZK(QZEi0WbICGAXPzH876,'IGNORED')
	for hBvdJ8YGzPoxFtT3H27m in hhdXuQ4l8tKvNaoqm5DnVAisFZP:
		if mi7Q1WRhZUJF3GOczo%27==0:
			o8oBqwQFbU2uL3SEGD0lgWO4xRnJYC(rx0ViTX1zNycaPFqk2,95+int(5*mi7Q1WRhZUJF3GOczo//KV7ANvXGq5I2nok4fjxOWP0pb),'تخزين المهملة','الفيديو رقم:-',str(mi7Q1WRhZUJF3GOczo)+' / '+str(KV7ANvXGq5I2nok4fjxOWP0pb))
			if rx0ViTX1zNycaPFqk2.iscanceled():
				rx0ViTX1zNycaPFqk2.close()
				return
		YMQXP2BGeK86CEb(zzPO3oKR8eVEcI4ruS5wGhyQ,'IGNORED',str(hBvdJ8YGzPoxFtT3H27m),iiy37aKq0pCEIOwfcTh61xb4U,VaeMF1mIjQ5iLtfGcB)
		mi7Q1WRhZUJF3GOczo += 1
	YMQXP2BGeK86CEb(zzPO3oKR8eVEcI4ruS5wGhyQ,'IGNORED','__COUNT__',str(KV7ANvXGq5I2nok4fjxOWP0pb),VaeMF1mIjQ5iLtfGcB)
	YMQXP2BGeK86CEb(zzPO3oKR8eVEcI4ruS5wGhyQ,'DUMMY','__DUMMY__','1',VaeMF1mIjQ5iLtfGcB)
	rx0ViTX1zNycaPFqk2.close()
	X2cQ5NCPvkMieBW7oASspFjE.sleep(1)
	DyUsrLbpIkgYCEhdz1xnlN = ryboCGwJIskXZvPAT(QZEi0WbICGAXPzH876,False)
	bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'رسالة من المبرمج',aqEsMBckT2bunGHfl48Wip+'تم جلب ملفات ـIPTV جديدة'+YoQW601K4fMJcsreDnGVE5wUZIy7+'\n\n'+DyUsrLbpIkgYCEhdz1xnlN)
	OlDUo31STWKuLHXcFG(QZEi0WbICGAXPzH876)
	pzdyLtNP8rYDiUacIf(False)
	SqMHwb6X1Ph8jY7LBNkmtV4F5Jlspy(False)
	return
def eS7CFoPqL1ak4UwQTgmyx(ERdVgaeYJtcbmM5AFkZNn):
	global rx0ViTX1zNycaPFqk2,LcoaMs1I8mgvx7qzSh,VV7IB0jaMcSxQH8lLETURoFK5AP,lBvniw69puMcWhR7gFHL1AXTPst0,YaFdrXAnsmVlfZjgW159KCozNDxe,iqvYpcmt6Ejy5JUbMONRgFze,OBkqRVJCGZsTKAd35SHWxvn,JAhFBXIlNZ6TtbpgnGqwdiyQkK,STAiGI40jtl29LmoPCEp3aXhguD
	lBvniw69puMcWhR7gFHL1AXTPst0[ERdVgaeYJtcbmM5AFkZNn] = {}
	K13Kv6aespzGVc29ICuSWjNnFgbtJ,LQP5tqjOoVm = {},[]
	IKvMJbk5sanBgTfm93Owc40Y = len(LcoaMs1I8mgvx7qzSh[ERdVgaeYJtcbmM5AFkZNn])
	lBvniw69puMcWhR7gFHL1AXTPst0[ERdVgaeYJtcbmM5AFkZNn]['__COUNT__'] = IKvMJbk5sanBgTfm93Owc40Y
	if IKvMJbk5sanBgTfm93Owc40Y>0:
		znMeZYPjqOAxKFVRE9hDt7bH,TmolgM4knPiH,LITtgcPwHoau5qz3eD,pBdGlkMYc2hEmsiu5,brzF6JqeN0cf48PGlK = zip(*LcoaMs1I8mgvx7qzSh[ERdVgaeYJtcbmM5AFkZNn])
		del TmolgM4knPiH,LITtgcPwHoau5qz3eD,pBdGlkMYc2hEmsiu5
		Y1fFoeExk02b = list(set(znMeZYPjqOAxKFVRE9hDt7bH))
		for DYxVAZjPCvdMScFfHLJ in Y1fFoeExk02b:
			K13Kv6aespzGVc29ICuSWjNnFgbtJ[DYxVAZjPCvdMScFfHLJ] = iiy37aKq0pCEIOwfcTh61xb4U
			lBvniw69puMcWhR7gFHL1AXTPst0[ERdVgaeYJtcbmM5AFkZNn][DYxVAZjPCvdMScFfHLJ] = []
		o8oBqwQFbU2uL3SEGD0lgWO4xRnJYC(rx0ViTX1zNycaPFqk2,60+int(15*JAhFBXIlNZ6TtbpgnGqwdiyQkK//STAiGI40jtl29LmoPCEp3aXhguD),'تصنيع القوائم','الجزء رقم:-',str(JAhFBXIlNZ6TtbpgnGqwdiyQkK)+' / '+str(STAiGI40jtl29LmoPCEp3aXhguD))
		if rx0ViTX1zNycaPFqk2.iscanceled(): return
		JAhFBXIlNZ6TtbpgnGqwdiyQkK += 1
		l2XxknqAdRJV3HzeFr0mU = len(Y1fFoeExk02b)
		del Y1fFoeExk02b
		LQP5tqjOoVm = list(set(zip(znMeZYPjqOAxKFVRE9hDt7bH,brzF6JqeN0cf48PGlK)))
		del znMeZYPjqOAxKFVRE9hDt7bH,brzF6JqeN0cf48PGlK
		for DYxVAZjPCvdMScFfHLJ,GmrA8hvBgN4bDdEWXS9nVMtU in LQP5tqjOoVm:
			if not K13Kv6aespzGVc29ICuSWjNnFgbtJ[DYxVAZjPCvdMScFfHLJ] and GmrA8hvBgN4bDdEWXS9nVMtU: K13Kv6aespzGVc29ICuSWjNnFgbtJ[DYxVAZjPCvdMScFfHLJ] = GmrA8hvBgN4bDdEWXS9nVMtU
		o8oBqwQFbU2uL3SEGD0lgWO4xRnJYC(rx0ViTX1zNycaPFqk2,60+int(15*JAhFBXIlNZ6TtbpgnGqwdiyQkK//STAiGI40jtl29LmoPCEp3aXhguD),'تصنيع القوائم','الجزء رقم:-',str(JAhFBXIlNZ6TtbpgnGqwdiyQkK)+' / '+str(STAiGI40jtl29LmoPCEp3aXhguD))
		if rx0ViTX1zNycaPFqk2.iscanceled(): return
		JAhFBXIlNZ6TtbpgnGqwdiyQkK += 1
		eeIfOPvd6DK0mMupBQXn1 = list(K13Kv6aespzGVc29ICuSWjNnFgbtJ.keys())
		RFvEGJxb80Iozw7lf5pk3CWBe = list(K13Kv6aespzGVc29ICuSWjNnFgbtJ.values())
		del K13Kv6aespzGVc29ICuSWjNnFgbtJ
		LQP5tqjOoVm = list(zip(eeIfOPvd6DK0mMupBQXn1,RFvEGJxb80Iozw7lf5pk3CWBe))
		del eeIfOPvd6DK0mMupBQXn1,RFvEGJxb80Iozw7lf5pk3CWBe
		LQP5tqjOoVm = sorted(LQP5tqjOoVm)
	else: JAhFBXIlNZ6TtbpgnGqwdiyQkK += 2
	lBvniw69puMcWhR7gFHL1AXTPst0[ERdVgaeYJtcbmM5AFkZNn]['__GROUPS__'] = LQP5tqjOoVm
	del LQP5tqjOoVm
	for DYxVAZjPCvdMScFfHLJ,YGNomIp2tDSR6ncf,svZJBpqOEQNyRPaDMUh870bCtdnT1,kMqh74TPvpSDar59xQUjAyVlHes,RtWKTkahzD0EuPVLpr in LcoaMs1I8mgvx7qzSh[ERdVgaeYJtcbmM5AFkZNn]:
		lBvniw69puMcWhR7gFHL1AXTPst0[ERdVgaeYJtcbmM5AFkZNn][DYxVAZjPCvdMScFfHLJ].append((YGNomIp2tDSR6ncf,svZJBpqOEQNyRPaDMUh870bCtdnT1,kMqh74TPvpSDar59xQUjAyVlHes,RtWKTkahzD0EuPVLpr))
	o8oBqwQFbU2uL3SEGD0lgWO4xRnJYC(rx0ViTX1zNycaPFqk2,60+int(15*JAhFBXIlNZ6TtbpgnGqwdiyQkK//STAiGI40jtl29LmoPCEp3aXhguD),'تصنيع القوائم','الجزء رقم:-',str(JAhFBXIlNZ6TtbpgnGqwdiyQkK)+' / '+str(STAiGI40jtl29LmoPCEp3aXhguD))
	if rx0ViTX1zNycaPFqk2.iscanceled(): return
	JAhFBXIlNZ6TtbpgnGqwdiyQkK += 1
	del LcoaMs1I8mgvx7qzSh[ERdVgaeYJtcbmM5AFkZNn]
	iqvYpcmt6Ejy5JUbMONRgFze[ERdVgaeYJtcbmM5AFkZNn] = list(lBvniw69puMcWhR7gFHL1AXTPst0[ERdVgaeYJtcbmM5AFkZNn].keys())
	YaFdrXAnsmVlfZjgW159KCozNDxe[ERdVgaeYJtcbmM5AFkZNn] = len(iqvYpcmt6Ejy5JUbMONRgFze[ERdVgaeYJtcbmM5AFkZNn])
	OBkqRVJCGZsTKAd35SHWxvn += YaFdrXAnsmVlfZjgW159KCozNDxe[ERdVgaeYJtcbmM5AFkZNn]
	return
def rTnMfHIG0WASwmheDFYq3uP(QZEi0WbICGAXPzH876,ERdVgaeYJtcbmM5AFkZNn):
	global rx0ViTX1zNycaPFqk2,LcoaMs1I8mgvx7qzSh,VV7IB0jaMcSxQH8lLETURoFK5AP,lBvniw69puMcWhR7gFHL1AXTPst0,YaFdrXAnsmVlfZjgW159KCozNDxe,iqvYpcmt6Ejy5JUbMONRgFze,OBkqRVJCGZsTKAd35SHWxvn,JAhFBXIlNZ6TtbpgnGqwdiyQkK,STAiGI40jtl29LmoPCEp3aXhguD
	zzPO3oKR8eVEcI4ruS5wGhyQ = m8tbAHrJLowOSax2NdZK(QZEi0WbICGAXPzH876,ERdVgaeYJtcbmM5AFkZNn)
	for jpouXixl9Oqzvg2V3k8ZayRJNsnI in range(1+YaFdrXAnsmVlfZjgW159KCozNDxe[ERdVgaeYJtcbmM5AFkZNn]//273):
		xMzXUOLWuB95EckSHlwo = []
		iy5da03KPvzHr = iqvYpcmt6Ejy5JUbMONRgFze[ERdVgaeYJtcbmM5AFkZNn][0:273]
		for DYxVAZjPCvdMScFfHLJ in iy5da03KPvzHr:
			xMzXUOLWuB95EckSHlwo.append(lBvniw69puMcWhR7gFHL1AXTPst0[ERdVgaeYJtcbmM5AFkZNn][DYxVAZjPCvdMScFfHLJ])
		YMQXP2BGeK86CEb(zzPO3oKR8eVEcI4ruS5wGhyQ,ERdVgaeYJtcbmM5AFkZNn,iy5da03KPvzHr,xMzXUOLWuB95EckSHlwo,VaeMF1mIjQ5iLtfGcB,True)
		VV7IB0jaMcSxQH8lLETURoFK5AP += len(iy5da03KPvzHr)
		o8oBqwQFbU2uL3SEGD0lgWO4xRnJYC(rx0ViTX1zNycaPFqk2,75+int(20*VV7IB0jaMcSxQH8lLETURoFK5AP//OBkqRVJCGZsTKAd35SHWxvn),'تخزين القوائم','القائمة رقم:-',str(VV7IB0jaMcSxQH8lLETURoFK5AP)+' / '+str(OBkqRVJCGZsTKAd35SHWxvn))
		if rx0ViTX1zNycaPFqk2.iscanceled(): return
		del iqvYpcmt6Ejy5JUbMONRgFze[ERdVgaeYJtcbmM5AFkZNn][0:273]
	del lBvniw69puMcWhR7gFHL1AXTPst0[ERdVgaeYJtcbmM5AFkZNn],iqvYpcmt6Ejy5JUbMONRgFze[ERdVgaeYJtcbmM5AFkZNn],YaFdrXAnsmVlfZjgW159KCozNDxe[ERdVgaeYJtcbmM5AFkZNn]
	return
def ryboCGwJIskXZvPAT(QZEi0WbICGAXPzH876,YaxK9usyg6VfMPIEhq7ctzBmOi8We1=True):
	if not whH63ZkMf7j5gsY(QZEi0WbICGAXPzH876,YaxK9usyg6VfMPIEhq7ctzBmOi8We1): return
	t3t1BDpqugGSW65aR = 'رسالة من المبرمج'
	aj83kIZu7BGfiRS = m8tbAHrJLowOSax2NdZK(QZEi0WbICGAXPzH876,'LIVE_ORIGINAL_GROUPED')
	A6J7GNwdF95Uezgvq0sDThkx4KIp8 = m8tbAHrJLowOSax2NdZK(QZEi0WbICGAXPzH876,'VOD_ORIGINAL_GROUPED')
	KV7ANvXGq5I2nok4fjxOWP0pb = QKzCiBOWZus1nSv(aj83kIZu7BGfiRS,'int','IGNORED','__COUNT__')
	ggKmSdvhouMjDW2JTEl6cObfweYPZi = QKzCiBOWZus1nSv(aj83kIZu7BGfiRS,'int','LIVE_ORIGINAL_GROUPED','__COUNT__')
	tVp5FzUvKh = QKzCiBOWZus1nSv(A6J7GNwdF95Uezgvq0sDThkx4KIp8,'int','VOD_ORIGINAL_GROUPED','__COUNT__')
	QNVJcXbk1TKauvADH = QKzCiBOWZus1nSv(aj83kIZu7BGfiRS,'int','LIVE_GROUPED','__COUNT__')
	RJETt7knjdZ0I3efv1FDblzswrYuiS = QKzCiBOWZus1nSv(aj83kIZu7BGfiRS,'int','LIVE_UNKNOWN_GROUPED','__COUNT__')
	cWTlRzC5QX6xet70k = QKzCiBOWZus1nSv(aj83kIZu7BGfiRS,'int','VOD_MOVIES_GROUPED','__COUNT__')
	tD2MXpsaBcWmjnv8uRzy = QKzCiBOWZus1nSv(A6J7GNwdF95Uezgvq0sDThkx4KIp8,'int','VOD_SERIES_GROUPED','__COUNT__')
	hhkYGrKw31IAlTq2odfZF = QKzCiBOWZus1nSv(aj83kIZu7BGfiRS,'int','VOD_UNKNOWN_GROUPED','__COUNT__')
	iqvYpcmt6Ejy5JUbMONRgFze = QKzCiBOWZus1nSv(A6J7GNwdF95Uezgvq0sDThkx4KIp8,'list','VOD_SERIES_GROUPED','__GROUPS__')
	CyEGXJiVbLmPd = []
	for DYxVAZjPCvdMScFfHLJ,RtWKTkahzD0EuPVLpr in iqvYpcmt6Ejy5JUbMONRgFze:
		u6z5yGYRDfQH7WpUZvia = DYxVAZjPCvdMScFfHLJ.split('__SERIES__')[1]
		CyEGXJiVbLmPd.append(u6z5yGYRDfQH7WpUZvia)
	PZTpcrkDKHt0R62AoU3aixegvQLy = len(CyEGXJiVbLmPd)
	wBxmDdbuSL7gfNCpU9W8MkJ0 = int(cWTlRzC5QX6xet70k)+int(tD2MXpsaBcWmjnv8uRzy)+int(hhkYGrKw31IAlTq2odfZF)+int(RJETt7knjdZ0I3efv1FDblzswrYuiS)+int(QNVJcXbk1TKauvADH)
	DyUsrLbpIkgYCEhdz1xnlN = iiy37aKq0pCEIOwfcTh61xb4U
	DyUsrLbpIkgYCEhdz1xnlN += 'قنوات: '+str(QNVJcXbk1TKauvADH)
	DyUsrLbpIkgYCEhdz1xnlN += '   .   أفلام: '+str(cWTlRzC5QX6xet70k)
	DyUsrLbpIkgYCEhdz1xnlN += '\nمسلسلات: '+str(PZTpcrkDKHt0R62AoU3aixegvQLy)
	DyUsrLbpIkgYCEhdz1xnlN += '   .   حلقات: '+str(tD2MXpsaBcWmjnv8uRzy)
	DyUsrLbpIkgYCEhdz1xnlN += '\nقنوات مجهولة: '+str(RJETt7knjdZ0I3efv1FDblzswrYuiS)
	DyUsrLbpIkgYCEhdz1xnlN += '   .   فيدوهات مجهولة: '+str(hhkYGrKw31IAlTq2odfZF)
	DyUsrLbpIkgYCEhdz1xnlN += '\nمجموع القنوات: '+str(ggKmSdvhouMjDW2JTEl6cObfweYPZi)
	DyUsrLbpIkgYCEhdz1xnlN += '   .   مجموع الفيديوهات: '+str(tVp5FzUvKh)
	DyUsrLbpIkgYCEhdz1xnlN += '\n\nمجموع المضافة: '+str(wBxmDdbuSL7gfNCpU9W8MkJ0)
	DyUsrLbpIkgYCEhdz1xnlN += '   .   مجموع المهملة: '+str(KV7ANvXGq5I2nok4fjxOWP0pb)
	if YaxK9usyg6VfMPIEhq7ctzBmOi8We1: bb5kRv7jh3LaEVJtIfg('center',iiy37aKq0pCEIOwfcTh61xb4U,t3t1BDpqugGSW65aR,DyUsrLbpIkgYCEhdz1xnlN)
	BfkGdSbZWPrn = DyUsrLbpIkgYCEhdz1xnlN.replace('\n\n',OTlVEGYPSxsNaBdXUucqA3)
	WKquk5EaNr4RzVf(q1rohYuwnfpVZUa98L2CtQzmAcB,'.\tCounts of IPTV videos   Folder: '+QZEi0WbICGAXPzH876+OTlVEGYPSxsNaBdXUucqA3+BfkGdSbZWPrn)
	return DyUsrLbpIkgYCEhdz1xnlN
def DDGYfd2miAauNzOVsUxEJb1ecyRXQ5(QZEi0WbICGAXPzH876,YaxK9usyg6VfMPIEhq7ctzBmOi8We1=True):
	if YaxK9usyg6VfMPIEhq7ctzBmOi8We1:
		ylRmrkV2fv4nGLC = A1AXKupEOfz('center',iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'مسح ملفات ـIPTV','تستطيع في أي وقت الدخول إلى قائمة ـIPTV وجلب ملفات ـIPTV جديدة .. هل تريد الآن مسح الملفات القديمة المخزنة في البرنامج ؟!')
		if ylRmrkV2fv4nGLC!=1: return
		m8dTraOy5MxvW9gJBhAPRQDbswSFoc = mzo15abwgdesuvn4CEGjSiNpDYVk.replace('___','_'+QZEi0WbICGAXPzH876)
		try: wkMR5x1gTWEQIc6qHCa.remove(m8dTraOy5MxvW9gJBhAPRQDbswSFoc)
		except: pass
	m8dTraOy5MxvW9gJBhAPRQDbswSFoc = cIFB9Ey2RMC8dveLi.replace('___','_'+QZEi0WbICGAXPzH876)
	try: wkMR5x1gTWEQIc6qHCa.remove(m8dTraOy5MxvW9gJBhAPRQDbswSFoc)
	except: pass
	m8dTraOy5MxvW9gJBhAPRQDbswSFoc = nodBvzbNipsO3JfK48HVxauREWhGFZ.replace('___','_'+QZEi0WbICGAXPzH876)
	try: wkMR5x1gTWEQIc6qHCa.remove(m8dTraOy5MxvW9gJBhAPRQDbswSFoc)
	except: pass
	Bcxq3nkvTU9iM(PdkZHNBlpg2b7DmX6qRiyVa,'SECTIONS_IPTV','SECTIONS_IPTV_'+QZEi0WbICGAXPzH876)
	Bcxq3nkvTU9iM(PdkZHNBlpg2b7DmX6qRiyVa,'SECTIONS_IPTV','SECTIONS_IPTV_ALL')
	pzdyLtNP8rYDiUacIf(False)
	OlDUo31STWKuLHXcFG(QZEi0WbICGAXPzH876)
	if YaxK9usyg6VfMPIEhq7ctzBmOi8We1:
		bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'رسالة من المبرمج','تم مسح جميع ملفات ـIPTV')
		SqMHwb6X1Ph8jY7LBNkmtV4F5Jlspy(False)
	return
def whH63ZkMf7j5gsY(QZEi0WbICGAXPzH876=iiy37aKq0pCEIOwfcTh61xb4U,YaxK9usyg6VfMPIEhq7ctzBmOi8We1=True):
	if QZEi0WbICGAXPzH876:
		zzPO3oKR8eVEcI4ruS5wGhyQ = m8tbAHrJLowOSax2NdZK(str(QZEi0WbICGAXPzH876),'DUMMY')
		HrzYa61RN5hAVS9BtnJ3mDy = QKzCiBOWZus1nSv(zzPO3oKR8eVEcI4ruS5wGhyQ,'str','DUMMY','__DUMMY__')
		if HrzYa61RN5hAVS9BtnJ3mDy: return True
	else:
		QZEi0WbICGAXPzH876 = '1'
		for uVs5SRi1t3wcDYXUAadJLpCG in range(1,IDxpbtWgzXHs3u08Q7nR6YerO+1):
			zzPO3oKR8eVEcI4ruS5wGhyQ = m8tbAHrJLowOSax2NdZK(str(uVs5SRi1t3wcDYXUAadJLpCG),'DUMMY')
			HrzYa61RN5hAVS9BtnJ3mDy = QKzCiBOWZus1nSv(zzPO3oKR8eVEcI4ruS5wGhyQ,'str','DUMMY','__DUMMY__')
			if HrzYa61RN5hAVS9BtnJ3mDy: return True
	if YaxK9usyg6VfMPIEhq7ctzBmOi8We1:
		bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'رسالة من المبرمج','هذا الجزء من البرنامج يحتاج اشتراك IPTV مدفوع من شركة IPTV .. ونوع الرابط المطلوب هو  m3u .. وهذا مثال لتوضيح شكل الرابط المطلوب في هذا البرنامج  '+PSwfZcdRYhpl5Igqz8xOEk67+' \n\nhttp://xyz.xyz/get.php?username=xyz&password=xyz&type=m3u_plus '+YoQW601K4fMJcsreDnGVE5wUZIy7)
		t3t1BDpqugGSW65aR = 'إضافة وتغيير رابط '+T7Rtxv5SnE1O94dLBcVNKHDZbJQe[1]+' (مجلد '+T7Rtxv5SnE1O94dLBcVNKHDZbJQe[int(QZEi0WbICGAXPzH876)]+')'
		ylRmrkV2fv4nGLC = A1AXKupEOfz(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,t3t1BDpqugGSW65aR,'لإضافة رابط IPTV .. أولا أفتح قائمة IPTV .. وثانيا أنقر على إضافة رابط أو اشتراك ـIPTV .. وثالثا أنقر على جلب ملفات ـIPTV \n\n هل تريد إضافة أو تغيير رابط IPTV الآن ؟!')
		if ylRmrkV2fv4nGLC==1: ppWGUxyoz1(QZEi0WbICGAXPzH876)
	return False
def g5h4NU9EkHwnQqrAamMi7JOZDeX(QULsNtf9ZRAoWj6gSiKVMyH,QZEi0WbICGAXPzH876=iiy37aKq0pCEIOwfcTh61xb4U,ERdVgaeYJtcbmM5AFkZNn=iiy37aKq0pCEIOwfcTh61xb4U,JJXDWPbmBGEFRoOejr8Z7cyU5wgk3=iiy37aKq0pCEIOwfcTh61xb4U):
	if not JJXDWPbmBGEFRoOejr8Z7cyU5wgk3: JJXDWPbmBGEFRoOejr8Z7cyU5wgk3 = '1'
	XoJdWFj2HL14SIhExcU,FG615TlEM78tKb,YaxK9usyg6VfMPIEhq7ctzBmOi8We1 = XkYnev3ZCA6ahO94(QULsNtf9ZRAoWj6gSiKVMyH)
	if not whH63ZkMf7j5gsY(QZEi0WbICGAXPzH876,YaxK9usyg6VfMPIEhq7ctzBmOi8We1): return
	if not XoJdWFj2HL14SIhExcU:
		XoJdWFj2HL14SIhExcU = TTBf6S08q1NKXd5v9wa()
		if not XoJdWFj2HL14SIhExcU: return
	T1QjvXZmseLqfkaC = [iiy37aKq0pCEIOwfcTh61xb4U,'LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not ERdVgaeYJtcbmM5AFkZNn:
		if not YaxK9usyg6VfMPIEhq7ctzBmOi8We1:
			if   '_IPTV-LIVE_' in FG615TlEM78tKb: ERdVgaeYJtcbmM5AFkZNn = T1QjvXZmseLqfkaC[1]
			elif '_IPTV-MOVIES' in FG615TlEM78tKb: ERdVgaeYJtcbmM5AFkZNn = T1QjvXZmseLqfkaC[2]
			elif '_IPTV-SERIES' in FG615TlEM78tKb: ERdVgaeYJtcbmM5AFkZNn = T1QjvXZmseLqfkaC[3]
			else: ERdVgaeYJtcbmM5AFkZNn = T1QjvXZmseLqfkaC[0]
		else:
			igtx4rUHdYIq8E2ojcv = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			RzBbfLYvm4Fgja7GcwCHMnX0K = ccv1mVPUsnr('أختر البحث المناسب', igtx4rUHdYIq8E2ojcv)
			if RzBbfLYvm4Fgja7GcwCHMnX0K==-1: return
			ERdVgaeYJtcbmM5AFkZNn = T1QjvXZmseLqfkaC[RzBbfLYvm4Fgja7GcwCHMnX0K]
	XoJdWFj2HL14SIhExcU = XoJdWFj2HL14SIhExcU+'_NODIALOGS_'
	if QZEi0WbICGAXPzH876: bytEjneopA(XoJdWFj2HL14SIhExcU,QZEi0WbICGAXPzH876,ERdVgaeYJtcbmM5AFkZNn,JJXDWPbmBGEFRoOejr8Z7cyU5wgk3)
	else:
		for QZEi0WbICGAXPzH876 in range(1,IDxpbtWgzXHs3u08Q7nR6YerO+1):
			bytEjneopA(XoJdWFj2HL14SIhExcU,str(QZEi0WbICGAXPzH876),ERdVgaeYJtcbmM5AFkZNn,JJXDWPbmBGEFRoOejr8Z7cyU5wgk3)
		g6ghGH4aBEYkTl3vbJZ[:] = sorted(g6ghGH4aBEYkTl3vbJZ,reverse=False,key=lambda cg8pNq2WQ6wszyjtC01JD: cg8pNq2WQ6wszyjtC01JD[1].lower())
	return
def bytEjneopA(QULsNtf9ZRAoWj6gSiKVMyH,QZEi0WbICGAXPzH876,ERdVgaeYJtcbmM5AFkZNn=iiy37aKq0pCEIOwfcTh61xb4U,JJXDWPbmBGEFRoOejr8Z7cyU5wgk3=iiy37aKq0pCEIOwfcTh61xb4U):
	if not JJXDWPbmBGEFRoOejr8Z7cyU5wgk3: JJXDWPbmBGEFRoOejr8Z7cyU5wgk3 = '1'
	XoJdWFj2HL14SIhExcU,FG615TlEM78tKb,YaxK9usyg6VfMPIEhq7ctzBmOi8We1 = XkYnev3ZCA6ahO94(QULsNtf9ZRAoWj6gSiKVMyH)
	if not QZEi0WbICGAXPzH876: return
	if not whH63ZkMf7j5gsY(QZEi0WbICGAXPzH876,YaxK9usyg6VfMPIEhq7ctzBmOi8We1): return
	if not XoJdWFj2HL14SIhExcU:
		XoJdWFj2HL14SIhExcU = TTBf6S08q1NKXd5v9wa()
		if not XoJdWFj2HL14SIhExcU: return
	T1QjvXZmseLqfkaC = [iiy37aKq0pCEIOwfcTh61xb4U,'LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not ERdVgaeYJtcbmM5AFkZNn:
		if not YaxK9usyg6VfMPIEhq7ctzBmOi8We1:
			if   '_IPTV-LIVE_' in FG615TlEM78tKb: ERdVgaeYJtcbmM5AFkZNn = T1QjvXZmseLqfkaC[1]
			elif '_IPTV-MOVIES' in FG615TlEM78tKb: ERdVgaeYJtcbmM5AFkZNn = T1QjvXZmseLqfkaC[2]
			elif '_IPTV-SERIES' in FG615TlEM78tKb: ERdVgaeYJtcbmM5AFkZNn = T1QjvXZmseLqfkaC[3]
			else: ERdVgaeYJtcbmM5AFkZNn = T1QjvXZmseLqfkaC[0]
		else:
			igtx4rUHdYIq8E2ojcv = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			RzBbfLYvm4Fgja7GcwCHMnX0K = ccv1mVPUsnr('أختر البحث المناسب', igtx4rUHdYIq8E2ojcv)
			if RzBbfLYvm4Fgja7GcwCHMnX0K==-1: return
			ERdVgaeYJtcbmM5AFkZNn = T1QjvXZmseLqfkaC[RzBbfLYvm4Fgja7GcwCHMnX0K]
	sJZv9hlqfMYEe3RwGVAUp = XoJdWFj2HL14SIhExcU.lower()
	zzPO3oKR8eVEcI4ruS5wGhyQ = m8tbAHrJLowOSax2NdZK(QZEi0WbICGAXPzH876,'SEARCH')
	LcMSkexq718nIEaCGRgP = QKzCiBOWZus1nSv(zzPO3oKR8eVEcI4ruS5wGhyQ,'list','SEARCH',(ERdVgaeYJtcbmM5AFkZNn,sJZv9hlqfMYEe3RwGVAUp))
	if not LcMSkexq718nIEaCGRgP:
		dPqhbVXiSLnypAM2cxkIC,oCOyp14aTcAseFVQ05KDBrf6 = [],[]
		if not ERdVgaeYJtcbmM5AFkZNn: wDitFoerQzMYaU6ZknPV9bH = [1,2,3,4,5]
		else: wDitFoerQzMYaU6ZknPV9bH = [T1QjvXZmseLqfkaC.index(ERdVgaeYJtcbmM5AFkZNn)]
		for mi7Q1WRhZUJF3GOczo in wDitFoerQzMYaU6ZknPV9bH:
			zzPO3oKR8eVEcI4ruS5wGhyQ = m8tbAHrJLowOSax2NdZK(QZEi0WbICGAXPzH876,T1QjvXZmseLqfkaC[mi7Q1WRhZUJF3GOczo])
			if mi7Q1WRhZUJF3GOczo!=3:
				z0OXopbnK2E = QKzCiBOWZus1nSv(zzPO3oKR8eVEcI4ruS5wGhyQ,'dict',T1QjvXZmseLqfkaC[mi7Q1WRhZUJF3GOczo])
				del z0OXopbnK2E['__COUNT__']
				del z0OXopbnK2E['__GROUPS__']
				del z0OXopbnK2E['__SEQUENCED_COLUMNS__']
				iqvYpcmt6Ejy5JUbMONRgFze = list(z0OXopbnK2E.keys())
				for DYxVAZjPCvdMScFfHLJ in iqvYpcmt6Ejy5JUbMONRgFze:
					for YGNomIp2tDSR6ncf,svZJBpqOEQNyRPaDMUh870bCtdnT1,kMqh74TPvpSDar59xQUjAyVlHes,RtWKTkahzD0EuPVLpr in z0OXopbnK2E[DYxVAZjPCvdMScFfHLJ]:
						if sJZv9hlqfMYEe3RwGVAUp in svZJBpqOEQNyRPaDMUh870bCtdnT1.lower(): oCOyp14aTcAseFVQ05KDBrf6.append((svZJBpqOEQNyRPaDMUh870bCtdnT1,kMqh74TPvpSDar59xQUjAyVlHes,RtWKTkahzD0EuPVLpr))
					del z0OXopbnK2E[DYxVAZjPCvdMScFfHLJ]
				del z0OXopbnK2E
			else: iqvYpcmt6Ejy5JUbMONRgFze = QKzCiBOWZus1nSv(zzPO3oKR8eVEcI4ruS5wGhyQ,'list',T1QjvXZmseLqfkaC[mi7Q1WRhZUJF3GOczo],'__GROUPS__')
			for DYxVAZjPCvdMScFfHLJ in iqvYpcmt6Ejy5JUbMONRgFze:
				try: DYxVAZjPCvdMScFfHLJ,RtWKTkahzD0EuPVLpr = DYxVAZjPCvdMScFfHLJ
				except: RtWKTkahzD0EuPVLpr = iiy37aKq0pCEIOwfcTh61xb4U
				if sJZv9hlqfMYEe3RwGVAUp in DYxVAZjPCvdMScFfHLJ.lower():
					if mi7Q1WRhZUJF3GOczo!=3: EHuBjy5M7aVZq8p0F6LGvYe4k = DYxVAZjPCvdMScFfHLJ
					else:
						igKC8YD5kacwNp,nFCOyXNUJwW13PstvxdR = DYxVAZjPCvdMScFfHLJ.split('__SERIES__')
						if sJZv9hlqfMYEe3RwGVAUp in igKC8YD5kacwNp.lower(): EHuBjy5M7aVZq8p0F6LGvYe4k = igKC8YD5kacwNp
						else: EHuBjy5M7aVZq8p0F6LGvYe4k = nFCOyXNUJwW13PstvxdR
					dPqhbVXiSLnypAM2cxkIC.append((DYxVAZjPCvdMScFfHLJ,EHuBjy5M7aVZq8p0F6LGvYe4k,T1QjvXZmseLqfkaC[mi7Q1WRhZUJF3GOczo],RtWKTkahzD0EuPVLpr))
			del iqvYpcmt6Ejy5JUbMONRgFze
		dPqhbVXiSLnypAM2cxkIC = set(dPqhbVXiSLnypAM2cxkIC)
		oCOyp14aTcAseFVQ05KDBrf6 = set(oCOyp14aTcAseFVQ05KDBrf6)
		dPqhbVXiSLnypAM2cxkIC = sorted(dPqhbVXiSLnypAM2cxkIC,reverse=False,key=lambda cg8pNq2WQ6wszyjtC01JD: cg8pNq2WQ6wszyjtC01JD[1])
		oCOyp14aTcAseFVQ05KDBrf6 = sorted(oCOyp14aTcAseFVQ05KDBrf6,reverse=False,key=lambda cg8pNq2WQ6wszyjtC01JD: cg8pNq2WQ6wszyjtC01JD[0])
		YMQXP2BGeK86CEb(zzPO3oKR8eVEcI4ruS5wGhyQ,'SEARCH',(ERdVgaeYJtcbmM5AFkZNn,sJZv9hlqfMYEe3RwGVAUp),(dPqhbVXiSLnypAM2cxkIC,oCOyp14aTcAseFVQ05KDBrf6),VaeMF1mIjQ5iLtfGcB)
	else: dPqhbVXiSLnypAM2cxkIC,oCOyp14aTcAseFVQ05KDBrf6 = LcMSkexq718nIEaCGRgP
	iqvYpcmt6Ejy5JUbMONRgFze = len(dPqhbVXiSLnypAM2cxkIC)
	rF46vNQ9nCf1BSzu = len(oCOyp14aTcAseFVQ05KDBrf6)
	F50ngOyjSvAcVRtdafJsiBkP9Yx = int(JJXDWPbmBGEFRoOejr8Z7cyU5wgk3)
	MMTLjYgxkuJUXCd5Hpnz2I = max(0,(F50ngOyjSvAcVRtdafJsiBkP9Yx-1)*100)
	LM9ElGwSHRWaYcjIhe = max(0,F50ngOyjSvAcVRtdafJsiBkP9Yx*100)
	JJgecifAuPQRmxZ = max(0,MMTLjYgxkuJUXCd5Hpnz2I-iqvYpcmt6Ejy5JUbMONRgFze)
	JHBdmh40wAM3RTVbze1j = max(0,LM9ElGwSHRWaYcjIhe-iqvYpcmt6Ejy5JUbMONRgFze)
	for DYxVAZjPCvdMScFfHLJ,EHuBjy5M7aVZq8p0F6LGvYe4k,Cm58rhtHuPDLAGK4xaQEUNs,RtWKTkahzD0EuPVLpr in dPqhbVXiSLnypAM2cxkIC[MMTLjYgxkuJUXCd5Hpnz2I:LM9ElGwSHRWaYcjIhe]:
		bP6z3OSLp7va('folder',gp5OsEbPCX0MGZw1tTf63zcySKLH+EHuBjy5M7aVZq8p0F6LGvYe4k,Cm58rhtHuPDLAGK4xaQEUNs,234,RtWKTkahzD0EuPVLpr,'1',DYxVAZjPCvdMScFfHLJ,iiy37aKq0pCEIOwfcTh61xb4U,{'folder':QZEi0WbICGAXPzH876})
	del dPqhbVXiSLnypAM2cxkIC
	for svZJBpqOEQNyRPaDMUh870bCtdnT1,kMqh74TPvpSDar59xQUjAyVlHes,RtWKTkahzD0EuPVLpr in oCOyp14aTcAseFVQ05KDBrf6[JJgecifAuPQRmxZ:JHBdmh40wAM3RTVbze1j]:
		gIEcyLuJokq5seOKa6vtMnWl = dVeG46wAnrtlpkbNPsvJ9(kMqh74TPvpSDar59xQUjAyVlHes)
		synCYOiMR789twmfr = 'live'
		if '.mkv' in gIEcyLuJokq5seOKa6vtMnWl or 'VOD' in ERdVgaeYJtcbmM5AFkZNn: synCYOiMR789twmfr = 'video'
		bP6z3OSLp7va(synCYOiMR789twmfr,gp5OsEbPCX0MGZw1tTf63zcySKLH+svZJBpqOEQNyRPaDMUh870bCtdnT1,kMqh74TPvpSDar59xQUjAyVlHes,235,RtWKTkahzD0EuPVLpr,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,{'folder':QZEi0WbICGAXPzH876})
	del oCOyp14aTcAseFVQ05KDBrf6
	vsOn7KRH1Vz6PLjWhdtIXw25YFNqu(QZEi0WbICGAXPzH876,JJXDWPbmBGEFRoOejr8Z7cyU5wgk3,ERdVgaeYJtcbmM5AFkZNn,239,iqvYpcmt6Ejy5JUbMONRgFze+rF46vNQ9nCf1BSzu,XoJdWFj2HL14SIhExcU+'_NODIALOGS_')
	return
def vsOn7KRH1Vz6PLjWhdtIXw25YFNqu(QZEi0WbICGAXPzH876,JJXDWPbmBGEFRoOejr8Z7cyU5wgk3,ERdVgaeYJtcbmM5AFkZNn,Cpf9s3c0Zngj7XE,wBxmDdbuSL7gfNCpU9W8MkJ0,U94JwhRgpXCOe5):
	if JJXDWPbmBGEFRoOejr8Z7cyU5wgk3!='1': bP6z3OSLp7va('folder',gp5OsEbPCX0MGZw1tTf63zcySKLH+'صفحة '+str(1),ERdVgaeYJtcbmM5AFkZNn,Cpf9s3c0Zngj7XE,iiy37aKq0pCEIOwfcTh61xb4U,str(1),U94JwhRgpXCOe5,iiy37aKq0pCEIOwfcTh61xb4U,{'folder':QZEi0WbICGAXPzH876})
	if not wBxmDdbuSL7gfNCpU9W8MkJ0: wBxmDdbuSL7gfNCpU9W8MkJ0 = 0
	PMTLiwqC9SBy4hD7Hjp3Q1JfX = int(wBxmDdbuSL7gfNCpU9W8MkJ0/100)+1
	for F50ngOyjSvAcVRtdafJsiBkP9Yx in range(2,PMTLiwqC9SBy4hD7Hjp3Q1JfX):
		WQdwGJk9mlHMzYyPovcrV8f = (F50ngOyjSvAcVRtdafJsiBkP9Yx%10==0 or int(JJXDWPbmBGEFRoOejr8Z7cyU5wgk3)-4<F50ngOyjSvAcVRtdafJsiBkP9Yx<int(JJXDWPbmBGEFRoOejr8Z7cyU5wgk3)+4)
		AFt0cr7izCOEubR2 = (WQdwGJk9mlHMzYyPovcrV8f and int(JJXDWPbmBGEFRoOejr8Z7cyU5wgk3)-40<F50ngOyjSvAcVRtdafJsiBkP9Yx<int(JJXDWPbmBGEFRoOejr8Z7cyU5wgk3)+40)
		if str(F50ngOyjSvAcVRtdafJsiBkP9Yx)!=JJXDWPbmBGEFRoOejr8Z7cyU5wgk3 and (F50ngOyjSvAcVRtdafJsiBkP9Yx%100==0 or AFt0cr7izCOEubR2):
			bP6z3OSLp7va('folder',gp5OsEbPCX0MGZw1tTf63zcySKLH+'صفحة '+str(F50ngOyjSvAcVRtdafJsiBkP9Yx),ERdVgaeYJtcbmM5AFkZNn,Cpf9s3c0Zngj7XE,iiy37aKq0pCEIOwfcTh61xb4U,str(F50ngOyjSvAcVRtdafJsiBkP9Yx),U94JwhRgpXCOe5,iiy37aKq0pCEIOwfcTh61xb4U,{'folder':QZEi0WbICGAXPzH876})
	if str(PMTLiwqC9SBy4hD7Hjp3Q1JfX)!=JJXDWPbmBGEFRoOejr8Z7cyU5wgk3: bP6z3OSLp7va('folder',gp5OsEbPCX0MGZw1tTf63zcySKLH+'أخر صفحة '+str(PMTLiwqC9SBy4hD7Hjp3Q1JfX),ERdVgaeYJtcbmM5AFkZNn,Cpf9s3c0Zngj7XE,iiy37aKq0pCEIOwfcTh61xb4U,str(PMTLiwqC9SBy4hD7Hjp3Q1JfX),U94JwhRgpXCOe5,iiy37aKq0pCEIOwfcTh61xb4U,{'folder':QZEi0WbICGAXPzH876})
	return
def m8tbAHrJLowOSax2NdZK(QZEi0WbICGAXPzH876,ERdVgaeYJtcbmM5AFkZNn):
	if 'SERIES' in ERdVgaeYJtcbmM5AFkZNn or 'VOD_ORIGINAL' in ERdVgaeYJtcbmM5AFkZNn: zzPO3oKR8eVEcI4ruS5wGhyQ = nodBvzbNipsO3JfK48HVxauREWhGFZ
	else: zzPO3oKR8eVEcI4ruS5wGhyQ = cIFB9Ey2RMC8dveLi
	zzPO3oKR8eVEcI4ruS5wGhyQ = zzPO3oKR8eVEcI4ruS5wGhyQ.replace('___','_'+QZEi0WbICGAXPzH876)
	return zzPO3oKR8eVEcI4ruS5wGhyQ
def j83AQoWvke(QZEi0WbICGAXPzH876,ERdVgaeYJtcbmM5AFkZNn,mF8LjNVMIzeJX):
	PufdHwFN0Qi5onleA1KZ,LjmRTZl5J3sfp4xywD6NkWIovgh,uOhjCkDo8b,M5FR8xYbQJCgD0Ewf,VgRjTyW5vFOdfExzMnPQSKUXZ1 = UrQ2K7hVyA(QZEi0WbICGAXPzH876)
	if not M5FR8xYbQJCgD0Ewf: return
	qNojFLzuAkDZHEy1d4scer = IIao4mWn2BRMk(QZEi0WbICGAXPzH876)
	if   ERdVgaeYJtcbmM5AFkZNn=='XTREAM_LIVE_GROUPS': kMqh74TPvpSDar59xQUjAyVlHes = PufdHwFN0Qi5onleA1KZ+'&action=get_live_categories'
	elif ERdVgaeYJtcbmM5AFkZNn=='XTREAM_VOD_GROUPS': kMqh74TPvpSDar59xQUjAyVlHes = PufdHwFN0Qi5onleA1KZ+'&action=get_vod_categories'
	elif ERdVgaeYJtcbmM5AFkZNn=='XTREAM_SERIES_GROUPS': kMqh74TPvpSDar59xQUjAyVlHes = PufdHwFN0Qi5onleA1KZ+'&action=get_series_categories'
	elif ERdVgaeYJtcbmM5AFkZNn=='XTREAM_LIVE_ITEMS': kMqh74TPvpSDar59xQUjAyVlHes = PufdHwFN0Qi5onleA1KZ+'&action=get_live_streams&category_id='+mF8LjNVMIzeJX
	elif ERdVgaeYJtcbmM5AFkZNn=='XTREAM_VOD_ITEMS': kMqh74TPvpSDar59xQUjAyVlHes = PufdHwFN0Qi5onleA1KZ+'&action=get_vod_streams&category_id='+mF8LjNVMIzeJX
	elif ERdVgaeYJtcbmM5AFkZNn=='XTREAM_SERIES_ITEMS': kMqh74TPvpSDar59xQUjAyVlHes = PufdHwFN0Qi5onleA1KZ+'&action=get_series&category_id='+mF8LjNVMIzeJX
	elif ERdVgaeYJtcbmM5AFkZNn=='XTREAM_EPISODES': kMqh74TPvpSDar59xQUjAyVlHes = PufdHwFN0Qi5onleA1KZ+'&action=get_series_info&series_id='+mF8LjNVMIzeJX
	else: return
	oikBndh2USEOV = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',kMqh74TPvpSDar59xQUjAyVlHes,iiy37aKq0pCEIOwfcTh61xb4U,qNojFLzuAkDZHEy1d4scer,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'IPTV-XTREAM_MENUS-1st')
	JiUpSTZWMhHP = oikBndh2USEOV.content
	if iELueYz3J1FmxaW7vc: JiUpSTZWMhHP = JiUpSTZWMhHP.decode(df6QpwGxuJVZr).encode(df6QpwGxuJVZr)
	ym8UFT2LIpf75Jjs4OurZD1 = DeIL3qoa2UBtYPb('list',JiUpSTZWMhHP)
	if 'GROUPS' in ERdVgaeYJtcbmM5AFkZNn:
		ERdVgaeYJtcbmM5AFkZNn = ERdVgaeYJtcbmM5AFkZNn.replace('_GROUPS','_ITEMS')
		ym8UFT2LIpf75Jjs4OurZD1 = sorted(ym8UFT2LIpf75Jjs4OurZD1,reverse=False,key=lambda cg8pNq2WQ6wszyjtC01JD: cg8pNq2WQ6wszyjtC01JD['category_name'].lower())
		for DYxVAZjPCvdMScFfHLJ in ym8UFT2LIpf75Jjs4OurZD1:
			qPdRkHWOcV0UXMy1o = DYxVAZjPCvdMScFfHLJ['category_id']
			svZJBpqOEQNyRPaDMUh870bCtdnT1 = DYxVAZjPCvdMScFfHLJ['category_name']
			bP6z3OSLp7va('folder',gp5OsEbPCX0MGZw1tTf63zcySKLH+svZJBpqOEQNyRPaDMUh870bCtdnT1,ERdVgaeYJtcbmM5AFkZNn,285,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,str(qPdRkHWOcV0UXMy1o),iiy37aKq0pCEIOwfcTh61xb4U,{'folder':QZEi0WbICGAXPzH876})
	elif ERdVgaeYJtcbmM5AFkZNn=='XTREAM_SERIES_ITEMS':
		ym8UFT2LIpf75Jjs4OurZD1 = sorted(ym8UFT2LIpf75Jjs4OurZD1,reverse=False,key=lambda cg8pNq2WQ6wszyjtC01JD: cg8pNq2WQ6wszyjtC01JD['name'].lower())
		for ZpQbdcjYiRXf01nNI5u in ym8UFT2LIpf75Jjs4OurZD1:
			svZJBpqOEQNyRPaDMUh870bCtdnT1 = ZpQbdcjYiRXf01nNI5u['name']
			GmrA8hvBgN4bDdEWXS9nVMtU = ZpQbdcjYiRXf01nNI5u['cover']
			qPdRkHWOcV0UXMy1o = ZpQbdcjYiRXf01nNI5u['series_id']
			bP6z3OSLp7va('folder',gp5OsEbPCX0MGZw1tTf63zcySKLH+svZJBpqOEQNyRPaDMUh870bCtdnT1,'XTREAM_EPISODES',285,GmrA8hvBgN4bDdEWXS9nVMtU,iiy37aKq0pCEIOwfcTh61xb4U,str(qPdRkHWOcV0UXMy1o),iiy37aKq0pCEIOwfcTh61xb4U,{'folder':QZEi0WbICGAXPzH876})
	elif ERdVgaeYJtcbmM5AFkZNn=='XTREAM_EPISODES':
		GmrA8hvBgN4bDdEWXS9nVMtU = ym8UFT2LIpf75Jjs4OurZD1['info']['cover']
		JJwnocyLUxHI2jlKF4Y = ym8UFT2LIpf75Jjs4OurZD1['info']['name']
		KgUmdbEIZLuV9 = ym8UFT2LIpf75Jjs4OurZD1['episodes']
		for Vj8g5RLoGrqpU1imdwAIytZnzY in KgUmdbEIZLuV9:
			gB8qDOu4PFsYho5bfIQGW6H = KgUmdbEIZLuV9[Vj8g5RLoGrqpU1imdwAIytZnzY]
			for FomAZ78Vb2z9 in gB8qDOu4PFsYho5bfIQGW6H:
				svZJBpqOEQNyRPaDMUh870bCtdnT1 = FomAZ78Vb2z9['title']
				UpcLBl7ijrfhVy = dEyT9xhGjolYzLCH7460w3.findall('\d+.(S\d+E\d+)',svZJBpqOEQNyRPaDMUh870bCtdnT1,dEyT9xhGjolYzLCH7460w3.DOTALL)
				if UpcLBl7ijrfhVy: svZJBpqOEQNyRPaDMUh870bCtdnT1 = JJwnocyLUxHI2jlKF4Y+iFBmE2MUIpSu34wsd7Rf6z+UpcLBl7ijrfhVy[0]
				qPdRkHWOcV0UXMy1o = FomAZ78Vb2z9['id']
				mjIGpRcEexQntB = FomAZ78Vb2z9['container_extension']
				kMqh74TPvpSDar59xQUjAyVlHes = PufdHwFN0Qi5onleA1KZ.split('/player_api.php')[0]+'/series/'+M5FR8xYbQJCgD0Ewf+'/'+VgRjTyW5vFOdfExzMnPQSKUXZ1+'/'+str(qPdRkHWOcV0UXMy1o)+'.'+mjIGpRcEexQntB
				bP6z3OSLp7va('video',gp5OsEbPCX0MGZw1tTf63zcySKLH+svZJBpqOEQNyRPaDMUh870bCtdnT1,kMqh74TPvpSDar59xQUjAyVlHes,235,GmrA8hvBgN4bDdEWXS9nVMtU,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,{'folder':QZEi0WbICGAXPzH876})
	elif 'ITEMS' in ERdVgaeYJtcbmM5AFkZNn:
		synCYOiMR789twmfr = 'live' if 'LIVE' in ERdVgaeYJtcbmM5AFkZNn else 'video'
		ym8UFT2LIpf75Jjs4OurZD1 = sorted(ym8UFT2LIpf75Jjs4OurZD1,reverse=False,key=lambda cg8pNq2WQ6wszyjtC01JD: cg8pNq2WQ6wszyjtC01JD['name'].lower())
		for DDfL4FHNXKljE5pcInSwxA08i27ub in ym8UFT2LIpf75Jjs4OurZD1:
			svZJBpqOEQNyRPaDMUh870bCtdnT1 = DDfL4FHNXKljE5pcInSwxA08i27ub['name']
			GmrA8hvBgN4bDdEWXS9nVMtU = DDfL4FHNXKljE5pcInSwxA08i27ub['stream_icon']
			qPdRkHWOcV0UXMy1o = DDfL4FHNXKljE5pcInSwxA08i27ub['stream_id']
			try:
				mjIGpRcEexQntB = DDfL4FHNXKljE5pcInSwxA08i27ub['container_extension']
				if mjIGpRcEexQntB: mjIGpRcEexQntB = '.'+mjIGpRcEexQntB
			except: mjIGpRcEexQntB = iiy37aKq0pCEIOwfcTh61xb4U
			if DDfL4FHNXKljE5pcInSwxA08i27ub['stream_type']=='live': SSvi7eIpcULPzgRMOaH9t1fTG5mu6K,Acp9I3kLo5eRXGUqmMwgbrvfBSax4 = iiy37aKq0pCEIOwfcTh61xb4U,'live'
			elif DDfL4FHNXKljE5pcInSwxA08i27ub['stream_type']=='movie': SSvi7eIpcULPzgRMOaH9t1fTG5mu6K,Acp9I3kLo5eRXGUqmMwgbrvfBSax4 = 'movie/','video'
			kMqh74TPvpSDar59xQUjAyVlHes = PufdHwFN0Qi5onleA1KZ.split('/player_api.php')[0]+'/'+SSvi7eIpcULPzgRMOaH9t1fTG5mu6K+M5FR8xYbQJCgD0Ewf+'/'+VgRjTyW5vFOdfExzMnPQSKUXZ1+'/'+str(qPdRkHWOcV0UXMy1o)+mjIGpRcEexQntB
			bP6z3OSLp7va(synCYOiMR789twmfr,gp5OsEbPCX0MGZw1tTf63zcySKLH+svZJBpqOEQNyRPaDMUh870bCtdnT1,kMqh74TPvpSDar59xQUjAyVlHes,235,GmrA8hvBgN4bDdEWXS9nVMtU,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,{'folder':QZEi0WbICGAXPzH876})
	return
def OlDUo31STWKuLHXcFG(QZEi0WbICGAXPzH876):
	XzhOTQymRcVY = OXsckY7RzjCag9A.getSetting('av.language.provider')
	pARIeP8YUMbf6nz5t7o0Wx = OXsckY7RzjCag9A.getSetting('av.language.code')
	Bcxq3nkvTU9iM(PdkZHNBlpg2b7DmX6qRiyVa,'MENUS_CACHE_'+XzhOTQymRcVY+'_'+pARIeP8YUMbf6nz5t7o0Wx,'%_IP'+QZEi0WbICGAXPzH876+'_%')
	return
# -*- coding: utf-8 -*-
from braVAkwfBN import *
headers = { 'User-Agent' : iiy37aKq0pCEIOwfcTh61xb4U }
sQU2GnRoMwLK8CBdfzmNr4jXyO = 'AKWAM'
ooQEi5O6tYsGVF8LU0TC3hgMeflBwH = '_AKW_'
JaQEtCzDXgos1cdZN = gZ4LwbKaOm[sQU2GnRoMwLK8CBdfzmNr4jXyO][0]
IITeNr0JPKniOzBDLvlAs2xVpR3u8 = iiy37aKq0pCEIOwfcTh61xb4U
a8GCLIuWNkS = ['ألعاب','المصارعة الحرة','القران الكريم','الكتب و الابحاث','الصور و الخلفيات','المسلسلات الاذاعية']
def sHVM8YchrDjZAJ7(mode,url,text):
	if   mode==240: EA7FzO1kMZGQXDd2giB0cwLom = jihuS9LVAvTrClPapMbUEwfn8XN()
	elif mode==241: EA7FzO1kMZGQXDd2giB0cwLom = AIQeNZP4FMDw9S(url,text)
	elif mode==242: EA7FzO1kMZGQXDd2giB0cwLom = YNcMvoVF5swlDBJI7PL(url)
	elif mode==243: EA7FzO1kMZGQXDd2giB0cwLom = TW6Z0zqaDl(url)
	elif mode==244: EA7FzO1kMZGQXDd2giB0cwLom = chQHNdWgTSDjti8R9pJUf(url,'FILTERS___'+text)
	elif mode==245: EA7FzO1kMZGQXDd2giB0cwLom = chQHNdWgTSDjti8R9pJUf(url,'CATEGORIES___'+text)
	elif mode==246: EA7FzO1kMZGQXDd2giB0cwLom = t6tlwLNPW7qkI4geboF2mYd(url)
	elif mode==247: EA7FzO1kMZGQXDd2giB0cwLom = jHi7sKno9cG(url)
	elif mode==248: EA7FzO1kMZGQXDd2giB0cwLom = bNjA7nXgEPoIKHi5hTpsFaL41UJ()
	elif mode==249: EA7FzO1kMZGQXDd2giB0cwLom = mUhJtHB9nw(text)
	else: EA7FzO1kMZGQXDd2giB0cwLom = False
	return EA7FzO1kMZGQXDd2giB0cwLom
def bNjA7nXgEPoIKHi5hTpsFaL41UJ():
	bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'رسالة من المبرمج','هذا الموقع "أكوام الجديد" في بعض الأحيان فيه نوع من الحجب ضد البرامج . وهذا يسبب مشكلة في تشغيل الفيديوهات . هذه المشكلة سببها من الموقع الأصلي وهي تظهر وتختفي بصورة عشوائية')
	return
def jihuS9LVAvTrClPapMbUEwfn8XN():
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',JaQEtCzDXgos1cdZN,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'AKWAM-MENU-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	idAHcpmFODTY3y4GPu9v = dEyT9xhGjolYzLCH7460w3.findall('home-site-btn-container.*?href="(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if idAHcpmFODTY3y4GPu9v: idAHcpmFODTY3y4GPu9v = idAHcpmFODTY3y4GPu9v[0]
	else: idAHcpmFODTY3y4GPu9v = JaQEtCzDXgos1cdZN
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',idAHcpmFODTY3y4GPu9v,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'AKWAM-MENU-2nd')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'بحث في الموقع',iiy37aKq0pCEIOwfcTh61xb4U,249,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'_REMEMBERRESULTS_')
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'فلتر محدد',JaQEtCzDXgos1cdZN,246)
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'فلتر كامل',JaQEtCzDXgos1cdZN,247)
	bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'المميزة',idAHcpmFODTY3y4GPu9v,241,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'featured')
	recent = dEyT9xhGjolYzLCH7460w3.findall('recently-container.*?href="(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	fCXyTlcmF4WuetVork = recent[0]
	bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'أضيف حديثا',fCXyTlcmF4WuetVork,241)
	bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('mb-4 d-flex align-items-center.*?href="(.*?)".*?class="header-link text-white">(.*?)<.*?class="menu"(.*?)</div>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	for fCXyTlcmF4WuetVork,name,PPH1sQtTkDBbnlYpZfo5 in UUIohmv597bO83YCLgWS:
		if name in a8GCLIuWNkS: continue
		bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+name,fCXyTlcmF4WuetVork,241)
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)">(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title in items:
			if title in a8GCLIuWNkS: continue
			title = name+iFBmE2MUIpSu34wsd7Rf6z+title
			bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,241)
	return
def t6tlwLNPW7qkI4geboF2mYd(website=iiy37aKq0pCEIOwfcTh61xb4U):
	Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(Dxc7GChQwZ4kOlKHSbL06agnB,JaQEtCzDXgos1cdZN,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,'AKWAM-MENU-1st')
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('class="menu(.*?)<nav',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?text">(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title in items:
			if title not in a8GCLIuWNkS:
				title = title+' مصنفة'
				bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,245)
		if website==iiy37aKq0pCEIOwfcTh61xb4U: bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	return Vxz6OndPIX4g2kaRp7
def jHi7sKno9cG(website=iiy37aKq0pCEIOwfcTh61xb4U):
	Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(Dxc7GChQwZ4kOlKHSbL06agnB,JaQEtCzDXgos1cdZN,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,'AKWAM-MENU-1st')
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('class="menu(.*?)<nav',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?text">(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title in items:
			if title not in a8GCLIuWNkS:
				title = title+' مفلترة'
				bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,244)
		if website==iiy37aKq0pCEIOwfcTh61xb4U: bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	return Vxz6OndPIX4g2kaRp7
def AIQeNZP4FMDw9S(url,type=iiy37aKq0pCEIOwfcTh61xb4U):
	Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(PNjZMS7nxa9clHusz1,url,iiy37aKq0pCEIOwfcTh61xb4U,headers,True,'AKWAM-TITLES-1st')
	if type=='featured': UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('swiper-container(.*?)swiper-button-prev',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	else: UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('class="widget"(.*?)main-footer',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('data-src="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if not items:
			items = dEyT9xhGjolYzLCH7460w3.findall('src="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for C0dvhEbPWYlUtimM3x,fCXyTlcmF4WuetVork,title in items:
			if '/series/' in fCXyTlcmF4WuetVork or '/shows/' in fCXyTlcmF4WuetVork:
				bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,242,C0dvhEbPWYlUtimM3x)
			elif '/movies/' in fCXyTlcmF4WuetVork:
				bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,243,C0dvhEbPWYlUtimM3x)
			elif '/games/' not in fCXyTlcmF4WuetVork:
				bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,243,C0dvhEbPWYlUtimM3x)
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('pagination(.*?)</div>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?>(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title in items:
			if title=='&lsaquo;': title = 'سابقة'
			if title=='&rsaquo;': title = 'لاحقة'
			fCXyTlcmF4WuetVork = JIY6A30UOsQboNVqCn(fCXyTlcmF4WuetVork)
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'صفحة '+title,fCXyTlcmF4WuetVork,241)
	return
def mUhJtHB9nw(search):
	search,brFQp5vmgJWdZfEkCBOlu9c,showDialogs = XkYnev3ZCA6ahO94(search)
	if search==iiy37aKq0pCEIOwfcTh61xb4U: search = TTBf6S08q1NKXd5v9wa()
	if search==iiy37aKq0pCEIOwfcTh61xb4U: return
	VVOtdjT9AF4Wk3GECqHL = search.replace(iFBmE2MUIpSu34wsd7Rf6z,'%20')
	url = JaQEtCzDXgos1cdZN + '/search?q='+VVOtdjT9AF4Wk3GECqHL
	EA7FzO1kMZGQXDd2giB0cwLom = AIQeNZP4FMDw9S(url)
	return
def YNcMvoVF5swlDBJI7PL(url):
	Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(PNjZMS7nxa9clHusz1,url,iiy37aKq0pCEIOwfcTh61xb4U,headers,True,'AKWAM-EPISODES-1st')
	if '-episodes">' not in Vxz6OndPIX4g2kaRp7:
		C0dvhEbPWYlUtimM3x = WwMgozBIC32n9d0tyfp.getInfoLabel('ListItem.Icon')
		bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'رابط التشغيل',url,243,C0dvhEbPWYlUtimM3x)
	else:
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('-episodes">(.*?)<div class="widget-4',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		f9a8L1lCJvn6pIUuP = dEyT9xhGjolYzLCH7460w3.findall('href="(http.*?)".*?>(.*?)<.*?src="(.*?)"',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title,C0dvhEbPWYlUtimM3x in f9a8L1lCJvn6pIUuP:
			title = title.replace(Wc5GekRC0HQLz7,iFBmE2MUIpSu34wsd7Rf6z)
			if 'الحلقات' in title or 'مواسم اخرى' in title: continue
			if '/series/' in fCXyTlcmF4WuetVork: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,242,C0dvhEbPWYlUtimM3x)
			else: bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,243,C0dvhEbPWYlUtimM3x)
	return
def TW6Z0zqaDl(url):
	Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(Dxc7GChQwZ4kOlKHSbL06agnB,url,iiy37aKq0pCEIOwfcTh61xb4U,headers,True,'AKWAM-PLAY-1st')
	UAhMnV3r89cWy7X1D05GBCwTqOP4p = dEyT9xhGjolYzLCH7460w3.findall('badge-danger.*?>(.*?)<',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UAhMnV3r89cWy7X1D05GBCwTqOP4p and IUF8hYKEGLmHDtXbuWNvnJ(sQU2GnRoMwLK8CBdfzmNr4jXyO,url,UAhMnV3r89cWy7X1D05GBCwTqOP4p): return
	dKpIoliRENVFxS3HtM4wLr = dEyT9xhGjolYzLCH7460w3.findall('li><a href="#(.*?)".*?>(.*?)<',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	duef0gb3Mi1AV5WpN8,A7Ap2wdlxM,ddfSDGyqEc,iH1pleUAXmaCrIgLFD92 = [],[],[],[]
	if dKpIoliRENVFxS3HtM4wLr:
		d2xq6KCoULIiPWOyFwp0t = 'mp4'
		for RGTPvFZrfSEt,pMAWqrwP80lR in dKpIoliRENVFxS3HtM4wLr:
			UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('tab-content quality" id="'+RGTPvFZrfSEt+'".*?</div>.\s*</div>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
			PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
			ddfSDGyqEc.append(PPH1sQtTkDBbnlYpZfo5)
			iH1pleUAXmaCrIgLFD92.append(pMAWqrwP80lR)
	else:
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('class="qualities(.*?)<h3.*?>(.*?)<',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if not UUIohmv597bO83YCLgWS:
			bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'رسالة من المبرمج','لا يوجد ملف فيديو في هذا الرابط')
			return
		else:
			PPH1sQtTkDBbnlYpZfo5,filename = UUIohmv597bO83YCLgWS[0]
			SQBWX4lui2Uf7 = ['zip','rar','txt','pdf','htm','tar','iso','html']
			d2xq6KCoULIiPWOyFwp0t = filename.rsplit('.',1)[1].strip(iFBmE2MUIpSu34wsd7Rf6z)
			if d2xq6KCoULIiPWOyFwp0t in SQBWX4lui2Uf7:
				bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'رسالة من المبرمج','الملف ليس فيديو ولا صوت')
				return
		ddfSDGyqEc.append(PPH1sQtTkDBbnlYpZfo5)
		iH1pleUAXmaCrIgLFD92.append(iiy37aKq0pCEIOwfcTh61xb4U)
	for iEfNKT3velFyGth80SA4pxbCRrVD in range(len(ddfSDGyqEc)):
		P3tys0cXWbiIUKk7HQ6n89V = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?icon-(.*?)"',ddfSDGyqEc[iEfNKT3velFyGth80SA4pxbCRrVD],dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,f32iyhptDd8mvMqWJoQYwEgTIGZbV in P3tys0cXWbiIUKk7HQ6n89V:
			if 'torrent' in f32iyhptDd8mvMqWJoQYwEgTIGZbV: continue
			elif 'download' in f32iyhptDd8mvMqWJoQYwEgTIGZbV: type = 'download'
			elif 'play' in f32iyhptDd8mvMqWJoQYwEgTIGZbV: type = 'watch'
			else: type = 'unknown'
			fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork+'?named=__'+type+'____'+iH1pleUAXmaCrIgLFD92[iEfNKT3velFyGth80SA4pxbCRrVD]+'__akwam'
			duef0gb3Mi1AV5WpN8.append(fCXyTlcmF4WuetVork)
	import lqBJGK8hXO
	lqBJGK8hXO.ZDg1HavwueT85mcAOorC4hnS(duef0gb3Mi1AV5WpN8,sQU2GnRoMwLK8CBdfzmNr4jXyO,'video',url)
	return
def chQHNdWgTSDjti8R9pJUf(url,filter):
	JYMlXTc9DCZrohd = ['section','category','year','rating']
	if '?' in url: url = url.split('?')[0]
	type,filter = filter.split('___',1)
	if filter==iiy37aKq0pCEIOwfcTh61xb4U: Mhd9LWrfiF1EsASl6eP34uTp0qNGom,ovh6cXGg1qd85fn3CSJEisTlI7Yz = iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U
	else: Mhd9LWrfiF1EsASl6eP34uTp0qNGom,ovh6cXGg1qd85fn3CSJEisTlI7Yz = filter.split('___')
	if type=='CATEGORIES':
		if JYMlXTc9DCZrohd[0]+'=' not in Mhd9LWrfiF1EsASl6eP34uTp0qNGom: RRIscyLmNH9dq2Dio3TSr = JYMlXTc9DCZrohd[0]
		for iEfNKT3velFyGth80SA4pxbCRrVD in range(len(JYMlXTc9DCZrohd[0:-1])):
			if JYMlXTc9DCZrohd[iEfNKT3velFyGth80SA4pxbCRrVD]+'=' in Mhd9LWrfiF1EsASl6eP34uTp0qNGom: RRIscyLmNH9dq2Dio3TSr = JYMlXTc9DCZrohd[iEfNKT3velFyGth80SA4pxbCRrVD+1]
		HdFJThcNtWe3lb8n4OmaSwQ = Mhd9LWrfiF1EsASl6eP34uTp0qNGom+'&'+RRIscyLmNH9dq2Dio3TSr+'=0'
		vvlVH6JT9YDNPeSaRUkKCAwpr5uq = ovh6cXGg1qd85fn3CSJEisTlI7Yz+'&'+RRIscyLmNH9dq2Dio3TSr+'=0'
		cCZR4YdwUepABD9mQsubT8FgN = HdFJThcNtWe3lb8n4OmaSwQ.strip('&')+'___'+vvlVH6JT9YDNPeSaRUkKCAwpr5uq.strip('&')
		bPXk8KHyCUrifag = qJ8NQtuWARGjoZd9swfbH(ovh6cXGg1qd85fn3CSJEisTlI7Yz,'all')
		eCGwzSrqBmIv = url+'?'+bPXk8KHyCUrifag
	elif type=='FILTERS':
		GMQ6AxE012X9 = qJ8NQtuWARGjoZd9swfbH(Mhd9LWrfiF1EsASl6eP34uTp0qNGom,'modified_values')
		GMQ6AxE012X9 = a9I3YZjc6ySDPE4Kp(GMQ6AxE012X9)
		if ovh6cXGg1qd85fn3CSJEisTlI7Yz!=iiy37aKq0pCEIOwfcTh61xb4U: ovh6cXGg1qd85fn3CSJEisTlI7Yz = qJ8NQtuWARGjoZd9swfbH(ovh6cXGg1qd85fn3CSJEisTlI7Yz,'all')
		if ovh6cXGg1qd85fn3CSJEisTlI7Yz==iiy37aKq0pCEIOwfcTh61xb4U: eCGwzSrqBmIv = url
		else: eCGwzSrqBmIv = url+'?'+ovh6cXGg1qd85fn3CSJEisTlI7Yz
		bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'أظهار قائمة الفيديو التي تم اختيارها',eCGwzSrqBmIv,241,iiy37aKq0pCEIOwfcTh61xb4U,'1')
		bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+' [[   '+GMQ6AxE012X9+'   ]]',eCGwzSrqBmIv,241,iiy37aKq0pCEIOwfcTh61xb4U,'1')
		bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(Dxc7GChQwZ4kOlKHSbL06agnB,url,iiy37aKq0pCEIOwfcTh61xb4U,headers,True,'AKWAM-FILTERS_MENU-1st')
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('<form id(.*?)</form>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
	n8nFIQBNaXD = dEyT9xhGjolYzLCH7460w3.findall('<select.*?name="(.*?)".*?">(.*?)<(.*?)</select>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	dict = {}
	for cWhMpFIbQU4D1Bi,name,PPH1sQtTkDBbnlYpZfo5 in n8nFIQBNaXD:
		items = dEyT9xhGjolYzLCH7460w3.findall('<option(.*?)>(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if '=' not in eCGwzSrqBmIv: eCGwzSrqBmIv = url
		if type=='CATEGORIES':
			if RRIscyLmNH9dq2Dio3TSr!=cWhMpFIbQU4D1Bi: continue
			elif len(items)<=1:
				if cWhMpFIbQU4D1Bi==JYMlXTc9DCZrohd[-1]: AIQeNZP4FMDw9S(eCGwzSrqBmIv)
				else: chQHNdWgTSDjti8R9pJUf(eCGwzSrqBmIv,'CATEGORIES___'+cCZR4YdwUepABD9mQsubT8FgN)
				return
			else:
				if cWhMpFIbQU4D1Bi==JYMlXTc9DCZrohd[-1]: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'الجميع',eCGwzSrqBmIv,241,iiy37aKq0pCEIOwfcTh61xb4U,'1')
				else: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'الجميع',eCGwzSrqBmIv,245,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,cCZR4YdwUepABD9mQsubT8FgN)
		elif type=='FILTERS':
			HdFJThcNtWe3lb8n4OmaSwQ = Mhd9LWrfiF1EsASl6eP34uTp0qNGom+'&'+cWhMpFIbQU4D1Bi+'=0'
			vvlVH6JT9YDNPeSaRUkKCAwpr5uq = ovh6cXGg1qd85fn3CSJEisTlI7Yz+'&'+cWhMpFIbQU4D1Bi+'=0'
			cCZR4YdwUepABD9mQsubT8FgN = HdFJThcNtWe3lb8n4OmaSwQ+'___'+vvlVH6JT9YDNPeSaRUkKCAwpr5uq
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'الجميع : '+name,eCGwzSrqBmIv,244,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,cCZR4YdwUepABD9mQsubT8FgN)
		dict[cWhMpFIbQU4D1Bi] = {}
		for aasX2cby4Vo5rTgB,KjsA38t0DCSmuLcaE in items:
			if KjsA38t0DCSmuLcaE in a8GCLIuWNkS: continue
			if 'value' not in aasX2cby4Vo5rTgB: aasX2cby4Vo5rTgB = KjsA38t0DCSmuLcaE
			else: aasX2cby4Vo5rTgB = dEyT9xhGjolYzLCH7460w3.findall('"(.*?)"',aasX2cby4Vo5rTgB,dEyT9xhGjolYzLCH7460w3.DOTALL)[0]
			dict[cWhMpFIbQU4D1Bi][aasX2cby4Vo5rTgB] = KjsA38t0DCSmuLcaE
			HdFJThcNtWe3lb8n4OmaSwQ = Mhd9LWrfiF1EsASl6eP34uTp0qNGom+'&'+cWhMpFIbQU4D1Bi+'='+KjsA38t0DCSmuLcaE
			vvlVH6JT9YDNPeSaRUkKCAwpr5uq = ovh6cXGg1qd85fn3CSJEisTlI7Yz+'&'+cWhMpFIbQU4D1Bi+'='+aasX2cby4Vo5rTgB
			kuyfTIwjRrhXUo = HdFJThcNtWe3lb8n4OmaSwQ+'___'+vvlVH6JT9YDNPeSaRUkKCAwpr5uq
			title = KjsA38t0DCSmuLcaE+' : '#+dict[cWhMpFIbQU4D1Bi]['0']
			title = KjsA38t0DCSmuLcaE+' : '+name
			if type=='FILTERS': bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,url,244,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,kuyfTIwjRrhXUo)
			elif type=='CATEGORIES' and JYMlXTc9DCZrohd[-2]+'=' in Mhd9LWrfiF1EsASl6eP34uTp0qNGom:
				bPXk8KHyCUrifag = qJ8NQtuWARGjoZd9swfbH(vvlVH6JT9YDNPeSaRUkKCAwpr5uq,'all')
				O5Pwg3UFyX0k9E = url+'?'+bPXk8KHyCUrifag
				bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,O5Pwg3UFyX0k9E,241,iiy37aKq0pCEIOwfcTh61xb4U,'1')
			else: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,url,245,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,kuyfTIwjRrhXUo)
	return
def qJ8NQtuWARGjoZd9swfbH(HSAqBpsb2jRLvk9lx147rzY,mode):
	HSAqBpsb2jRLvk9lx147rzY = HSAqBpsb2jRLvk9lx147rzY.strip('&')
	x8UiIH3WCTEpe = {}
	if '=' in HSAqBpsb2jRLvk9lx147rzY:
		items = HSAqBpsb2jRLvk9lx147rzY.split('&')
		for YXD9KNfjCaLwkcrvJxldn7I in items:
			xYkDXe5UjvETygJNLrRQ96mtp8BKGW,aasX2cby4Vo5rTgB = YXD9KNfjCaLwkcrvJxldn7I.split('=')
			x8UiIH3WCTEpe[xYkDXe5UjvETygJNLrRQ96mtp8BKGW] = aasX2cby4Vo5rTgB
	QAvGYocVXgzh9 = iiy37aKq0pCEIOwfcTh61xb4U
	a3aiAqYngfydR1XNJK975wl4jD = ['section','category','rating','year','language','formats','quality']
	for key in a3aiAqYngfydR1XNJK975wl4jD:
		if key in list(x8UiIH3WCTEpe.keys()): aasX2cby4Vo5rTgB = x8UiIH3WCTEpe[key]
		else: aasX2cby4Vo5rTgB = '0'
		if mode=='modified_values' and aasX2cby4Vo5rTgB!='0': QAvGYocVXgzh9 = QAvGYocVXgzh9+' + '+aasX2cby4Vo5rTgB
		elif mode=='modified_filters' and aasX2cby4Vo5rTgB!='0': QAvGYocVXgzh9 = QAvGYocVXgzh9+'&'+key+'='+aasX2cby4Vo5rTgB
		elif mode=='all': QAvGYocVXgzh9 = QAvGYocVXgzh9+'&'+key+'='+aasX2cby4Vo5rTgB
	QAvGYocVXgzh9 = QAvGYocVXgzh9.strip(' + ')
	QAvGYocVXgzh9 = QAvGYocVXgzh9.strip('&')
	return QAvGYocVXgzh9
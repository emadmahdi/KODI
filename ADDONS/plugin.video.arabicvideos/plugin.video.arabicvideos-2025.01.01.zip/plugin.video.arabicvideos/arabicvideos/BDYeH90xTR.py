# -*- coding: utf-8 -*-
from braVAkwfBN import *
sQU2GnRoMwLK8CBdfzmNr4jXyO = 'CIMALIGHT'
ooQEi5O6tYsGVF8LU0TC3hgMeflBwH = '_CML_'
JaQEtCzDXgos1cdZN = gZ4LwbKaOm[sQU2GnRoMwLK8CBdfzmNr4jXyO][0]
a8GCLIuWNkS = ['قنوات فضائية']
def sHVM8YchrDjZAJ7(mode,url,text):
	if   mode==470: EA7FzO1kMZGQXDd2giB0cwLom = jihuS9LVAvTrClPapMbUEwfn8XN()
	elif mode==471: EA7FzO1kMZGQXDd2giB0cwLom = AIQeNZP4FMDw9S(url,text)
	elif mode==472: EA7FzO1kMZGQXDd2giB0cwLom = TW6Z0zqaDl(url)
	elif mode==473: EA7FzO1kMZGQXDd2giB0cwLom = LEc19rxAg0P4ZXmSaCNid(url,text)
	elif mode==474: EA7FzO1kMZGQXDd2giB0cwLom = BaSyudevC40nsQHW5j7JX6RM9(url)
	elif mode==479: EA7FzO1kMZGQXDd2giB0cwLom = mUhJtHB9nw(text)
	else: EA7FzO1kMZGQXDd2giB0cwLom = False
	return EA7FzO1kMZGQXDd2giB0cwLom
def jihuS9LVAvTrClPapMbUEwfn8XN():
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',JaQEtCzDXgos1cdZN,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'CIMALIGHT-MENU-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	ffBG4TaQU8lVF26R = dEyT9xhGjolYzLCH7460w3.findall('"url": "(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	ffBG4TaQU8lVF26R = ffBG4TaQU8lVF26R[0].strip('/')
	ffBG4TaQU8lVF26R = F82MvyX4ThI6sbnA3efDoVS(ffBG4TaQU8lVF26R,'url')
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'بحث في الموقع',iiy37aKq0pCEIOwfcTh61xb4U,479,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'_REMEMBERRESULTS_')
	bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"content"(.*?)</div>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
	items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?</i>(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	for fCXyTlcmF4WuetVork,title in items:
		title = title.replace(Wc5GekRC0HQLz7,iiy37aKq0pCEIOwfcTh61xb4U).strip(iFBmE2MUIpSu34wsd7Rf6z)
		fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork.replace('cat=online-movies1','cat=online-movies')
		bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,474)
	bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('/category.php">(.*?)"navslide-divider"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall("'dropdown-menu'(.*?)</ul>",Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?>(.*?)</a>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	for fCXyTlcmF4WuetVork,title in items:
		if title in a8GCLIuWNkS: continue
		if 'مسلسل ' in title: continue
		if 'برنامج ' in title: continue
		if 'للكبار' in title: continue
		bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,474)
	return
def BaSyudevC40nsQHW5j7JX6RM9(url):
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'CIMALIGHT-TITLES-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	if 'topvideos.php' in url: UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"caret"(.*?)id="pm-grid"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	else: UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"caret"(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?>(.*?)</a>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title in items:
			if 'topvideos.php' in fCXyTlcmF4WuetVork:
				if 'topvideos.php?c=english-movies' in fCXyTlcmF4WuetVork: continue
				if 'topvideos.php?c=online-movies1' in fCXyTlcmF4WuetVork: continue
				if 'topvideos.php?c=misc' in fCXyTlcmF4WuetVork: continue
				if 'topvideos.php?c=tv-channel' in fCXyTlcmF4WuetVork: continue
				if 'منذ البداية' in title and 'do=rating' not in fCXyTlcmF4WuetVork: continue
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,471)
	else: AIQeNZP4FMDw9S(url)
	return
def AIQeNZP4FMDw9S(url,lHDuLVCy8kvqB6Rxh4Gs5K=iiy37aKq0pCEIOwfcTh61xb4U):
	ffBG4TaQU8lVF26R = F82MvyX4ThI6sbnA3efDoVS(url,'url')
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'CIMALIGHT-TITLES-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	items = []
	if lHDuLVCy8kvqB6Rxh4Gs5K=='featured_movies':
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"container-fluid"(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?"title">(.*?)</div>.*?image:url\(\'(.*?)\'\)',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		P3tys0cXWbiIUKk7HQ6n89V,v1JrBsOo8Qyzk,XPo6ai5L94BEDOhgGu1tN7 = zip(*items)
		items = zip(XPo6ai5L94BEDOhgGu1tN7,P3tys0cXWbiIUKk7HQ6n89V,v1JrBsOo8Qyzk)
	elif lHDuLVCy8kvqB6Rxh4Gs5K=='featured_series':
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('المسلسلات المميزة(.*?)<style>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?title="(.*?)".*?image:url\(\'(.*?)\'\)',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		P3tys0cXWbiIUKk7HQ6n89V,v1JrBsOo8Qyzk,XPo6ai5L94BEDOhgGu1tN7 = zip(*items)
		items = zip(XPo6ai5L94BEDOhgGu1tN7,P3tys0cXWbiIUKk7HQ6n89V,v1JrBsOo8Qyzk)
	else:
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('(data-echo=".*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if not UUIohmv597bO83YCLgWS: UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"BlocksList"(.*?)"titleSectionCon"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if not UUIohmv597bO83YCLgWS: UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('id="pm-grid"(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if not UUIohmv597bO83YCLgWS: UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('id="pm-related"(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if not UUIohmv597bO83YCLgWS: UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('pm-ul-browse-videos(.*?)clearfix',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if not UUIohmv597bO83YCLgWS: return
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
	if not items: items = dEyT9xhGjolYzLCH7460w3.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if not items: items = dEyT9xhGjolYzLCH7460w3.findall('src="(.*?)".*?href="(.*?)".*?>(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	u3Rztpl4VHO9GZ7jCBM65kvS = []
	mxXKsCgL5OoP1evURZ8SdIfpBrwu = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for C0dvhEbPWYlUtimM3x,fCXyTlcmF4WuetVork,title in items:
		fCXyTlcmF4WuetVork = a9I3YZjc6ySDPE4Kp(fCXyTlcmF4WuetVork).strip('/')
		title = title.replace('ماي سيما',iiy37aKq0pCEIOwfcTh61xb4U).replace('مشاهدة',iiy37aKq0pCEIOwfcTh61xb4U).strip(iFBmE2MUIpSu34wsd7Rf6z).replace(Wc5GekRC0HQLz7,iFBmE2MUIpSu34wsd7Rf6z)
		if 'http' not in fCXyTlcmF4WuetVork: fCXyTlcmF4WuetVork = ffBG4TaQU8lVF26R+'/'+fCXyTlcmF4WuetVork.strip('/')
		if 'http' not in C0dvhEbPWYlUtimM3x: C0dvhEbPWYlUtimM3x = ffBG4TaQU8lVF26R+'/'+C0dvhEbPWYlUtimM3x.strip('/')
		zN7sZyFnw5JTE8 = dEyT9xhGjolYzLCH7460w3.findall('(.*?) (الحلقة|حلقة) \d+',title,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if any(aasX2cby4Vo5rTgB in title for aasX2cby4Vo5rTgB in mxXKsCgL5OoP1evURZ8SdIfpBrwu):
			title = '_MOD_'+title
			bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,472,C0dvhEbPWYlUtimM3x)
		elif zN7sZyFnw5JTE8 and 'حلقة' in title:
			title = '_MOD_'+zN7sZyFnw5JTE8[0][0]
			if title not in u3Rztpl4VHO9GZ7jCBM65kvS:
				bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,473,C0dvhEbPWYlUtimM3x)
				u3Rztpl4VHO9GZ7jCBM65kvS.append(title)
		elif '/movseries/' in fCXyTlcmF4WuetVork:
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,471,C0dvhEbPWYlUtimM3x)
		else: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,473,C0dvhEbPWYlUtimM3x)
	if lHDuLVCy8kvqB6Rxh4Gs5K not in ['featured_movies','featured_series']:
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"pagination(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if UUIohmv597bO83YCLgWS:
			PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
			items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?>(.*?)</a>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
			for fCXyTlcmF4WuetVork,title in items:
				if fCXyTlcmF4WuetVork=='#': continue
				fCXyTlcmF4WuetVork = ffBG4TaQU8lVF26R+'/'+fCXyTlcmF4WuetVork.strip('/')
				title = JIY6A30UOsQboNVqCn(title)
				bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'صفحة '+title,fCXyTlcmF4WuetVork,471)
		SwiW9ygZnaTl53PVbKzRtY = dEyT9xhGjolYzLCH7460w3.findall('showmore" href="(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if SwiW9ygZnaTl53PVbKzRtY:
			fCXyTlcmF4WuetVork = SwiW9ygZnaTl53PVbKzRtY[0]
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'مشاهدة المزيد',fCXyTlcmF4WuetVork,471)
	return
def LEc19rxAg0P4ZXmSaCNid(url,kbTg05YG6clitmjwoDx3VZQuq):
	ffBG4TaQU8lVF26R = F82MvyX4ThI6sbnA3efDoVS(url,'url')
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'CIMALIGHT-EPISODES-2nd')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	HG5rE20ORdbqUKWewuZCJP4zoXF6g = dEyT9xhGjolYzLCH7460w3.findall('"SeasonsBox"(.*?)</div>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	items = []
	if HG5rE20ORdbqUKWewuZCJP4zoXF6g and not kbTg05YG6clitmjwoDx3VZQuq:
		C0dvhEbPWYlUtimM3x = dEyT9xhGjolYzLCH7460w3.findall('"series-header".*?src="(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		C0dvhEbPWYlUtimM3x = C0dvhEbPWYlUtimM3x[0] if C0dvhEbPWYlUtimM3x else iiy37aKq0pCEIOwfcTh61xb4U
		PPH1sQtTkDBbnlYpZfo5 = HG5rE20ORdbqUKWewuZCJP4zoXF6g[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('openCity\(event\, \'(.*?)\'\)".*?>(.*?)</button>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if len(items)==1: kbTg05YG6clitmjwoDx3VZQuq = items[0][0]
		elif len(items)>1:
			for kbTg05YG6clitmjwoDx3VZQuq,title in items: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,url,473,C0dvhEbPWYlUtimM3x,iiy37aKq0pCEIOwfcTh61xb4U,kbTg05YG6clitmjwoDx3VZQuq)
	eTov6CfDcRZVJEAq5BH = dEyT9xhGjolYzLCH7460w3.findall('id="'+kbTg05YG6clitmjwoDx3VZQuq+'"(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if eTov6CfDcRZVJEAq5BH and len(items)<2:
		C0dvhEbPWYlUtimM3x = dEyT9xhGjolYzLCH7460w3.findall('"series-header".*?src="(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		C0dvhEbPWYlUtimM3x = C0dvhEbPWYlUtimM3x[0] if C0dvhEbPWYlUtimM3x else iiy37aKq0pCEIOwfcTh61xb4U
		PPH1sQtTkDBbnlYpZfo5 = eTov6CfDcRZVJEAq5BH[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?title="(.*?)"',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if items:
			for fCXyTlcmF4WuetVork,title in items:
				title = title.replace('ماي سيما',iiy37aKq0pCEIOwfcTh61xb4U).replace('مسلسل',iiy37aKq0pCEIOwfcTh61xb4U).strip(iFBmE2MUIpSu34wsd7Rf6z)
				if 'http' not in fCXyTlcmF4WuetVork: fCXyTlcmF4WuetVork = ffBG4TaQU8lVF26R+'/'+fCXyTlcmF4WuetVork.strip('/')
				bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,472,C0dvhEbPWYlUtimM3x)
		else:
			items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?title="(.*?)".*?image:url\((.*?)\)',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
			for fCXyTlcmF4WuetVork,title,C0dvhEbPWYlUtimM3x in items:
				if 'http' not in fCXyTlcmF4WuetVork: fCXyTlcmF4WuetVork = ffBG4TaQU8lVF26R+'/'+fCXyTlcmF4WuetVork.strip('/')
				bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,472,C0dvhEbPWYlUtimM3x)
	if 'id="pm-related"' in Vxz6OndPIX4g2kaRp7:
		if items: bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
		bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'مواضيع ذات صلة',url,471)
	return
def TW6Z0zqaDl(url):
	duef0gb3Mi1AV5WpN8 = []
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'CIMALIGHT-PLAY-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('<div itemprop="description">(.*?)href=',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		UAhMnV3r89cWy7X1D05GBCwTqOP4p = dEyT9xhGjolYzLCH7460w3.findall('<p>(.*?)</p>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if UAhMnV3r89cWy7X1D05GBCwTqOP4p and IUF8hYKEGLmHDtXbuWNvnJ(sQU2GnRoMwLK8CBdfzmNr4jXyO,url,UAhMnV3r89cWy7X1D05GBCwTqOP4p,True): return
	eCGwzSrqBmIv = url.replace('/watch.php','/play.php')
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',eCGwzSrqBmIv,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'CIMALIGHT-PLAY-2nd')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	mLjB9PlUwZWyuSt3hGqITHk = []
	fCXyTlcmF4WuetVork = dEyT9xhGjolYzLCH7460w3.findall('"embedURL" href="(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if fCXyTlcmF4WuetVork:
		fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork[0]
		if fCXyTlcmF4WuetVork and fCXyTlcmF4WuetVork not in mLjB9PlUwZWyuSt3hGqITHk:
			mLjB9PlUwZWyuSt3hGqITHk.append(fCXyTlcmF4WuetVork)
			fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork+'?named=__embed'
			if 'http' not in fCXyTlcmF4WuetVork: fCXyTlcmF4WuetVork = 'http:'+fCXyTlcmF4WuetVork
			duef0gb3Mi1AV5WpN8.append(fCXyTlcmF4WuetVork)
	items = dEyT9xhGjolYzLCH7460w3.findall("<iframe src='(.*?)'.*?<strong>(.*?)</strong>",Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	for fCXyTlcmF4WuetVork,title in items:
		if fCXyTlcmF4WuetVork not in mLjB9PlUwZWyuSt3hGqITHk:
			mLjB9PlUwZWyuSt3hGqITHk.append(fCXyTlcmF4WuetVork)
			fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork+'?named='+title+'__watch'
			if 'http' not in fCXyTlcmF4WuetVork: fCXyTlcmF4WuetVork = 'http:'+fCXyTlcmF4WuetVork
			duef0gb3Mi1AV5WpN8.append(fCXyTlcmF4WuetVork)
	eCGwzSrqBmIv = url.replace('/watch.php','/downloads.php')
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',eCGwzSrqBmIv,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'CIMALIGHT-PLAY-3rd')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"downloadlist"(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?<strong>(.*?)</strong>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title in items:
			if fCXyTlcmF4WuetVork not in mLjB9PlUwZWyuSt3hGqITHk:
				mLjB9PlUwZWyuSt3hGqITHk.append(fCXyTlcmF4WuetVork)
				fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork+'?named='+title+'__download'
				if 'http' not in fCXyTlcmF4WuetVork: fCXyTlcmF4WuetVork = 'http:'+fCXyTlcmF4WuetVork
				duef0gb3Mi1AV5WpN8.append(fCXyTlcmF4WuetVork)
	import lqBJGK8hXO
	lqBJGK8hXO.ZDg1HavwueT85mcAOorC4hnS(duef0gb3Mi1AV5WpN8,sQU2GnRoMwLK8CBdfzmNr4jXyO,'video',url)
	return
def mUhJtHB9nw(search):
	search,brFQp5vmgJWdZfEkCBOlu9c,showDialogs = XkYnev3ZCA6ahO94(search)
	if search==iiy37aKq0pCEIOwfcTh61xb4U: search = TTBf6S08q1NKXd5v9wa()
	if search==iiy37aKq0pCEIOwfcTh61xb4U: return
	search = search.replace(iFBmE2MUIpSu34wsd7Rf6z,'+')
	Zw4M5DUStdE6xp7GI = F82MvyX4ThI6sbnA3efDoVS(JaQEtCzDXgos1cdZN,'url')
	url = Zw4M5DUStdE6xp7GI+'/search.php?keywords='+search
	AIQeNZP4FMDw9S(url,'search')
	return
﻿# -*- coding: utf-8 -*-
from braVAkwfBN import *
def sHVM8YchrDjZAJ7(Cpf9s3c0Zngj7XE,BWY3GL2Z7uFcjmVHxbQqIn):
	if BWY3GL2Z7uFcjmVHxbQqIn==iiy37aKq0pCEIOwfcTh61xb4U: return
	if Cpf9s3c0Zngj7XE==1:
		hhXo0bDTcWEa8N1fB6Vl = OOYtyXB3o8K.getCurrentWindowDialogId()
		ji4voyIO8bYap = OOYtyXB3o8K.Window(hhXo0bDTcWEa8N1fB6Vl)
		BWY3GL2Z7uFcjmVHxbQqIn = gcN78Bi6TD1QZsyR(BWY3GL2Z7uFcjmVHxbQqIn)
		ji4voyIO8bYap.getControl(311).setLabel(BWY3GL2Z7uFcjmVHxbQqIn)
	if Cpf9s3c0Zngj7XE==0:
		EGJVsZy38Xx='X'
		if J1MoiYc7ZwzKS: reWJAdwsQoRVIUXPYfuyBb5LtKvpT = isinstance(BWY3GL2Z7uFcjmVHxbQqIn,str)
		else: reWJAdwsQoRVIUXPYfuyBb5LtKvpT = isinstance(BWY3GL2Z7uFcjmVHxbQqIn,unicode)
		if reWJAdwsQoRVIUXPYfuyBb5LtKvpT==True: EGJVsZy38Xx='U'
		V62JaEUzMDLWfHGBhCqxekOn0PR4Ad=str(type(BWY3GL2Z7uFcjmVHxbQqIn))+iFBmE2MUIpSu34wsd7Rf6z+BWY3GL2Z7uFcjmVHxbQqIn+iFBmE2MUIpSu34wsd7Rf6z+EGJVsZy38Xx+iFBmE2MUIpSu34wsd7Rf6z
		for iEfNKT3velFyGth80SA4pxbCRrVD in range(0,len(BWY3GL2Z7uFcjmVHxbQqIn),1):
			V62JaEUzMDLWfHGBhCqxekOn0PR4Ad += hex(ord(BWY3GL2Z7uFcjmVHxbQqIn[iEfNKT3velFyGth80SA4pxbCRrVD])).replace('0x',iiy37aKq0pCEIOwfcTh61xb4U)+iFBmE2MUIpSu34wsd7Rf6z
		BWY3GL2Z7uFcjmVHxbQqIn = gcN78Bi6TD1QZsyR(BWY3GL2Z7uFcjmVHxbQqIn)
		EGJVsZy38Xx='X'
		if J1MoiYc7ZwzKS: reWJAdwsQoRVIUXPYfuyBb5LtKvpT = isinstance(BWY3GL2Z7uFcjmVHxbQqIn, str)
		else: reWJAdwsQoRVIUXPYfuyBb5LtKvpT = isinstance(BWY3GL2Z7uFcjmVHxbQqIn, unicode)
		if reWJAdwsQoRVIUXPYfuyBb5LtKvpT==True: EGJVsZy38Xx='U'
		HLVOyAR4W1v8KicFBgEXPJS=str(type(BWY3GL2Z7uFcjmVHxbQqIn))+iFBmE2MUIpSu34wsd7Rf6z+BWY3GL2Z7uFcjmVHxbQqIn+iFBmE2MUIpSu34wsd7Rf6z+EGJVsZy38Xx+iFBmE2MUIpSu34wsd7Rf6z
		for iEfNKT3velFyGth80SA4pxbCRrVD in range(0,len(BWY3GL2Z7uFcjmVHxbQqIn),1):
			HLVOyAR4W1v8KicFBgEXPJS += hex(ord(BWY3GL2Z7uFcjmVHxbQqIn[iEfNKT3velFyGth80SA4pxbCRrVD])).replace('0x',iiy37aKq0pCEIOwfcTh61xb4U)+iFBmE2MUIpSu34wsd7Rf6z
	return
# -*- coding: utf-8 -*-
from braVAkwfBN import *
sQU2GnRoMwLK8CBdfzmNr4jXyO = 'SHIAVOICE'
ooQEi5O6tYsGVF8LU0TC3hgMeflBwH = '_SHV_'
JaQEtCzDXgos1cdZN = gZ4LwbKaOm[sQU2GnRoMwLK8CBdfzmNr4jXyO][0]
headers = {'User-Agent':None}
def sHVM8YchrDjZAJ7(mode,url,text):
	if   mode==310: EA7FzO1kMZGQXDd2giB0cwLom = jihuS9LVAvTrClPapMbUEwfn8XN()
	elif mode==311: EA7FzO1kMZGQXDd2giB0cwLom = AIQeNZP4FMDw9S(url)
	elif mode==312: EA7FzO1kMZGQXDd2giB0cwLom = TW6Z0zqaDl(url)
	elif mode==313: EA7FzO1kMZGQXDd2giB0cwLom = jglQyAnbzxrPY8BCd(url)
	elif mode==314: EA7FzO1kMZGQXDd2giB0cwLom = GGbxVPw0MrO(text)
	elif mode==319: EA7FzO1kMZGQXDd2giB0cwLom = mUhJtHB9nw(text)
	else: EA7FzO1kMZGQXDd2giB0cwLom = False
	return EA7FzO1kMZGQXDd2giB0cwLom
def jihuS9LVAvTrClPapMbUEwfn8XN():
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'بحث في الموقع',iiy37aKq0pCEIOwfcTh61xb4U,319,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'_REMEMBERRESULTS_')
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(Dxc7GChQwZ4kOlKHSbL06agnB,'GET',JaQEtCzDXgos1cdZN,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'SHIAVOICE-MENU-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('id="menulinks"(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
	bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	items = dEyT9xhGjolYzLCH7460w3.findall('<h5>(.*?)</h5>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL|dEyT9xhGjolYzLCH7460w3.IGNORECASE)
	for rxbivCFQ9aAnpckTUXYh65dH4 in range(len(items)):
		title = items[rxbivCFQ9aAnpckTUXYh65dH4].strip(iFBmE2MUIpSu34wsd7Rf6z)
		bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,JaQEtCzDXgos1cdZN,314,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,str(rxbivCFQ9aAnpckTUXYh65dH4+1))
	bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'مقاطع شهر',JaQEtCzDXgos1cdZN,314,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'0')
	bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?<B>(.*?)</B>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	for fCXyTlcmF4WuetVork,title in items:
		fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN+'/'+fCXyTlcmF4WuetVork
		bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,311)
	return Vxz6OndPIX4g2kaRp7
def GGbxVPw0MrO(rxbivCFQ9aAnpckTUXYh65dH4):
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(r3rnfZ7cdxzNFebIRaLSG6B,'GET',JaQEtCzDXgos1cdZN,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'SHIAVOICE-LATEST-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	if rxbivCFQ9aAnpckTUXYh65dH4=='0':
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('class="tab-content"(.*?)</table>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?title="(.*?)".*?</i>(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,name,title in items:
			fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN+'/'+fCXyTlcmF4WuetVork
			title = title.strip(iFBmE2MUIpSu34wsd7Rf6z)
			name = name.strip(iFBmE2MUIpSu34wsd7Rf6z)
			title = title+' ('+name+')'
			bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,312)
	elif rxbivCFQ9aAnpckTUXYh65dH4 in ['1','2','3']:
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('(<h5>.*?)<div class="col-lg',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		tuli6dAe02jGIyxHv9 = int(rxbivCFQ9aAnpckTUXYh65dH4)-1
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[tuli6dAe02jGIyxHv9]
		if rxbivCFQ9aAnpckTUXYh65dH4=='1': items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?src="(.*?)".*?<strong>(.*?)<.*?</i>(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		else: items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?src="(.*?)".*?<strong>(.*?)<.*?href=".*?">(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,C0dvhEbPWYlUtimM3x,title,name in items:
			C0dvhEbPWYlUtimM3x = JaQEtCzDXgos1cdZN+'/'+C0dvhEbPWYlUtimM3x
			fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN+'/'+fCXyTlcmF4WuetVork
			title = title.strip(iFBmE2MUIpSu34wsd7Rf6z)
			name = name.strip(iFBmE2MUIpSu34wsd7Rf6z)
			title = title+' ('+name+')'
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,311,C0dvhEbPWYlUtimM3x)
	elif rxbivCFQ9aAnpckTUXYh65dH4 in ['4','5','6']:
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('(<h5>.*?)</table>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		rxbivCFQ9aAnpckTUXYh65dH4 = int(rxbivCFQ9aAnpckTUXYh65dH4)-4
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[rxbivCFQ9aAnpckTUXYh65dH4]
		items = dEyT9xhGjolYzLCH7460w3.findall('src="(.*?)".*?href="(.*?)".*?title="(.*?)".*?<strong.*?>(.*?)</strong>.*?-cell">(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for C0dvhEbPWYlUtimM3x,fCXyTlcmF4WuetVork,IrXjyqcp13l,title,ccgt6lhpXynUR79P5ev in items:
			C0dvhEbPWYlUtimM3x = JaQEtCzDXgos1cdZN+'/'+C0dvhEbPWYlUtimM3x
			fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN+'/'+fCXyTlcmF4WuetVork
			title = title.strip(iFBmE2MUIpSu34wsd7Rf6z)
			IrXjyqcp13l = IrXjyqcp13l.strip(iFBmE2MUIpSu34wsd7Rf6z)
			ccgt6lhpXynUR79P5ev = ccgt6lhpXynUR79P5ev.strip(iFBmE2MUIpSu34wsd7Rf6z)
			if IrXjyqcp13l: name = IrXjyqcp13l
			else: name = ccgt6lhpXynUR79P5ev
			title = title+' ('+name+')'
			bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,312,C0dvhEbPWYlUtimM3x)
	return
def AIQeNZP4FMDw9S(url):
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'SHIAVOICE-TITLES-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('ibox-heading"(.*?)class="float-right',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
	if 'catsum-mobile' in PPH1sQtTkDBbnlYpZfo5:
		items = dEyT9xhGjolYzLCH7460w3.findall('src="(.*?)".*?href="(.*?)".*?<strong>(.*?)</strong>.*?catsum-mobile">(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if items:
			for C0dvhEbPWYlUtimM3x,fCXyTlcmF4WuetVork,title,count in items:
				C0dvhEbPWYlUtimM3x = JaQEtCzDXgos1cdZN+'/'+C0dvhEbPWYlUtimM3x
				fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN+'/'+fCXyTlcmF4WuetVork
				count = count.replace(' الصوتية: ',':')
				title = title.strip(iFBmE2MUIpSu34wsd7Rf6z)
				title = title+' ('+count+')'
				bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,311,C0dvhEbPWYlUtimM3x)
	else:
		items = dEyT9xhGjolYzLCH7460w3.findall('" href="(.*?)".*?</i>(.*?)</a>.*?">(.*?)<.*?<span.*?<span.*?<span.*?">(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title,lKzSv4ebVBFLIhuasjPARDnMm5J,Zt6GY7K2oFeAd5kTy3nJvDBpQr in items:
			if title==iiy37aKq0pCEIOwfcTh61xb4U or lKzSv4ebVBFLIhuasjPARDnMm5J==iiy37aKq0pCEIOwfcTh61xb4U: continue
			fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN+'/'+fCXyTlcmF4WuetVork
			title = title+' ('+Zt6GY7K2oFeAd5kTy3nJvDBpQr+')'
			bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,312)
	if not items: YNcMvoVF5swlDBJI7PL(Vxz6OndPIX4g2kaRp7)
	return
def YNcMvoVF5swlDBJI7PL(Vxz6OndPIX4g2kaRp7):
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('class="ibox-content"(.*?)class="pagination',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
	items = dEyT9xhGjolYzLCH7460w3.findall('href="(http.*?)".*?</i>(.*?)<.*?cell">(.*?)<.*?cell">(.*?)<.*?cell">(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	for fCXyTlcmF4WuetVork,title,name,count,Zt6GY7K2oFeAd5kTy3nJvDBpQr in items:
		fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN+'/'+fCXyTlcmF4WuetVork
		title = title.strip(iFBmE2MUIpSu34wsd7Rf6z)
		name = name.strip(iFBmE2MUIpSu34wsd7Rf6z)
		title = title+' ('+name+')'
		bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,312,iiy37aKq0pCEIOwfcTh61xb4U,Zt6GY7K2oFeAd5kTy3nJvDBpQr)
	return
def jglQyAnbzxrPY8BCd(url):
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'SHIAVOICE-SEARCH_ITEMS-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('class="ibox-content p-1"(.*?)class="ibox-content"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if not UUIohmv597bO83YCLgWS:
		AIQeNZP4FMDw9S(url)
		return
	PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
	items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?<strong>(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	for fCXyTlcmF4WuetVork,title in items:
		fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN+'/'+fCXyTlcmF4WuetVork
		title = title.strip(iFBmE2MUIpSu34wsd7Rf6z)
		if '/play-' in fCXyTlcmF4WuetVork: bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,312)
		else: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,311)
	return
def TW6Z0zqaDl(url):
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(r3rnfZ7cdxzNFebIRaLSG6B,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'SHIAVOICE-PLAY-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	fCXyTlcmF4WuetVork = dEyT9xhGjolYzLCH7460w3.findall('<audio.*?src="(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if not fCXyTlcmF4WuetVork: fCXyTlcmF4WuetVork = dEyT9xhGjolYzLCH7460w3.findall('<video.*?src="(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN+fCXyTlcmF4WuetVork[0]
	PsD3IgluKFyvzMLoRT9j5hq2(fCXyTlcmF4WuetVork,sQU2GnRoMwLK8CBdfzmNr4jXyO,'video')
	return
def mUhJtHB9nw(search):
	search,brFQp5vmgJWdZfEkCBOlu9c,showDialogs = XkYnev3ZCA6ahO94(search)
	if search==iiy37aKq0pCEIOwfcTh61xb4U: search = TTBf6S08q1NKXd5v9wa()
	if search==iiy37aKq0pCEIOwfcTh61xb4U: return
	search = search.replace(iFBmE2MUIpSu34wsd7Rf6z,'+')
	IQ35uE2iHqtyCdTakzVAs = ['&t=a','&t=c','&t=s']
	if showDialogs:
		TTEJmYNfFscxaqR0U9V4KDPoy = ['قارئ','إصدار / مجلد','مقطع الصوتي']
		mmfrx2S5XqknFTDeRhj49LuYv1wW0 = ccv1mVPUsnr('موقع صوت الشيعة - أختر البحث', TTEJmYNfFscxaqR0U9V4KDPoy)
		if mmfrx2S5XqknFTDeRhj49LuYv1wW0 == -1: return
	elif '_SHIAVOICE-PERSONS_' in brFQp5vmgJWdZfEkCBOlu9c: mmfrx2S5XqknFTDeRhj49LuYv1wW0 = 0
	elif '_SHIAVOICE-ALBUMS_' in brFQp5vmgJWdZfEkCBOlu9c: mmfrx2S5XqknFTDeRhj49LuYv1wW0 = 1
	elif '_SHIAVOICE-AUDIOS_' in brFQp5vmgJWdZfEkCBOlu9c: mmfrx2S5XqknFTDeRhj49LuYv1wW0 = 2
	else: return
	type = IQ35uE2iHqtyCdTakzVAs[mmfrx2S5XqknFTDeRhj49LuYv1wW0]
	url = JaQEtCzDXgos1cdZN+'/search.php?q='+search+type
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'SHIAVOICE-SEARCH-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('class="ibox-content"(.*?)class="ibox-content"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		if mmfrx2S5XqknFTDeRhj49LuYv1wW0 in [0,1]:
			items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?src="(.*?)".*?href=".*?">(.*?)<.*?">(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
			for fCXyTlcmF4WuetVork,C0dvhEbPWYlUtimM3x,title,name in items:
				title = title.strip(iFBmE2MUIpSu34wsd7Rf6z)
				name = name.strip(iFBmE2MUIpSu34wsd7Rf6z)
				title = title+' ('+name+')'
				bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,313,C0dvhEbPWYlUtimM3x)
		elif mmfrx2S5XqknFTDeRhj49LuYv1wW0==2:
			items = dEyT9xhGjolYzLCH7460w3.findall('href="(http.*?)".*?</i>(.*?)</a></td><td>(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
			for fCXyTlcmF4WuetVork,title,name in items:
				title = title.strip(iFBmE2MUIpSu34wsd7Rf6z)
				name = name.strip(iFBmE2MUIpSu34wsd7Rf6z)
				title = title+' ('+name+')'
				bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,312)
	return
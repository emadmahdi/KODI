# -*- coding: utf-8 -*-
import sys as ytv0YaxDcRINurplWKg587Pwqz
LS5n9Ib81cvhApByQJa6GX4HTf = ytv0YaxDcRINurplWKg587Pwqz.version_info [0] == 2
FVDxSCW5MgK = 2048
o2SVZsYjxd4MPfLCRzv1Ime9XD6rhW = 7
def EnKbMAYoFJ (kc93hiPDm4MqAOaL):
	global BCEn6px5l4
	qR9DalTWtCBVeyYwiQg = ord (kc93hiPDm4MqAOaL [-1])
	SSe8FNopD7MI1EixsPTgl4v3YmfB6 = kc93hiPDm4MqAOaL [:-1]
	T2g7SpExkOcr8NUtfYyMB1d4usRw = qR9DalTWtCBVeyYwiQg % len (SSe8FNopD7MI1EixsPTgl4v3YmfB6)
	fxd3B46829KvYlTG17kUyLNJIbWDp0 = SSe8FNopD7MI1EixsPTgl4v3YmfB6 [:T2g7SpExkOcr8NUtfYyMB1d4usRw] + SSe8FNopD7MI1EixsPTgl4v3YmfB6 [T2g7SpExkOcr8NUtfYyMB1d4usRw:]
	if LS5n9Ib81cvhApByQJa6GX4HTf:
		nXV2GRHyP8dpugjML5sTE4OKN = unicode () .join ([unichr (ord (XXYULyZe1FgwdTVnSx2kHfDAsMClJ9) - FVDxSCW5MgK - (GPf6BlpctR + qR9DalTWtCBVeyYwiQg) % o2SVZsYjxd4MPfLCRzv1Ime9XD6rhW) for GPf6BlpctR, XXYULyZe1FgwdTVnSx2kHfDAsMClJ9 in enumerate (fxd3B46829KvYlTG17kUyLNJIbWDp0)])
	else:
		nXV2GRHyP8dpugjML5sTE4OKN = str () .join ([chr (ord (XXYULyZe1FgwdTVnSx2kHfDAsMClJ9) - FVDxSCW5MgK - (GPf6BlpctR + qR9DalTWtCBVeyYwiQg) % o2SVZsYjxd4MPfLCRzv1Ime9XD6rhW) for GPf6BlpctR, XXYULyZe1FgwdTVnSx2kHfDAsMClJ9 in enumerate (fxd3B46829KvYlTG17kUyLNJIbWDp0)])
	return eval (nXV2GRHyP8dpugjML5sTE4OKN)
hhqd6cnfNJiAaLKTPbst5RpMmZF2G,LyNiIHPOwD3hCUYEFM7,vODxLKW5Ql6r4Fbm8=EnKbMAYoFJ,EnKbMAYoFJ,EnKbMAYoFJ
xpT28sXu051,GGx4qyKP1vUtRghsE2WfaHLMXZ,PtkEvXAqif14G20QZsaSyT=vODxLKW5Ql6r4Fbm8,LyNiIHPOwD3hCUYEFM7,hhqd6cnfNJiAaLKTPbst5RpMmZF2G
SaB5hx3PZwXRLtKgrTfQvId,YzX407G1m8ER9OBpkeuqPIf6Ajrh5,EMO8gy4LrsNTh0knZwpSeU75APW=PtkEvXAqif14G20QZsaSyT,GGx4qyKP1vUtRghsE2WfaHLMXZ,xpT28sXu051
yJeq1BjfiO4NFuwIEzxVLK6b9s,ZchUJdM93pTA7zG5,CCUzMTgQjrHntoiGf16LXW5P8EdVu=EMO8gy4LrsNTh0knZwpSeU75APW,YzX407G1m8ER9OBpkeuqPIf6Ajrh5,SaB5hx3PZwXRLtKgrTfQvId
JZszNnIEMAx28Yao0yqhiXGKOPb,XrTw01KtLzbpoyMf,uuExaKGL7UONtevRd=CCUzMTgQjrHntoiGf16LXW5P8EdVu,ZchUJdM93pTA7zG5,yJeq1BjfiO4NFuwIEzxVLK6b9s
y6y5HtgXO4TkUbwVZ,sVzojQerUqX,tKNPiXfQ7HoAqndw3z9IL4E6VrGv1=uuExaKGL7UONtevRd,XrTw01KtLzbpoyMf,JZszNnIEMAx28Yao0yqhiXGKOPb
AbqCJZdWQP9j,Y41NvKfOroMzGB8sEHy7wbXlc5,hhQwbeiNLoqFjX90fB7aG8VAs=tKNPiXfQ7HoAqndw3z9IL4E6VrGv1,sVzojQerUqX,y6y5HtgXO4TkUbwVZ
IpC4qHXRuyNFjzWv,ppxP0Cg6N3JVELzjGKmkZ2qIlu,L90uqo28xEKSFUwYTcm51yRWZIkft=hhQwbeiNLoqFjX90fB7aG8VAs,Y41NvKfOroMzGB8sEHy7wbXlc5,AbqCJZdWQP9j
FRYcH4KL7e9gv5pEB,tELM0b9FzxuRI4J1CYcie7ZXsHBar,TlGXWLYsV1z=L90uqo28xEKSFUwYTcm51yRWZIkft,ppxP0Cg6N3JVELzjGKmkZ2qIlu,IpC4qHXRuyNFjzWv
ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n,HtK4o2sTPgA78U,zmcGfOdvAjsELeJlP=TlGXWLYsV1z,tELM0b9FzxuRI4J1CYcie7ZXsHBar,FRYcH4KL7e9gv5pEB
UO04GcM7oFd3kJbtKQZHRgI2jeyzCh,MgP8OjoaiWQEVG59,jXE2YHkswT8y=zmcGfOdvAjsELeJlP,HtK4o2sTPgA78U,ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n
from KKv1QhTDGq import *
import base64 as UodGe76Lu2IHTYPxBhjk1RpcaqrM
sQU2GnRoMwLK8CBdfzmNr4jXyO = tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠪࡐࡎࡈࡓࡕ࡙ࡒࠫ୿")
g6ghGH4aBEYkTl3vbJZ,DLTuRI6kd1K75q,EeCo9tOcL2dIZu75g = [],{},{}
rbKI7RAUc9SCoTagkXFJyiePNfx6,jZPNfVdJqoQx4,O8ObqHAIx6sgnaNC7dLDXcVt9GZh2B = iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U
ef74aPgdcbQFAnGok9thpBwY8m06 = BF6QAiLUNHh7rKOugaw
EXDGSeAzlq7myvNjJxd4B = {}
if J1MoiYc7ZwzKS:
	K1KA8whDjRrQI3OBgMzbLo9 = FCzlJghHX2nPG3BRNc0SoetQdqW.translatePath(JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯ࡹࡤࡰࡧࠬ஀"))
	Hyw4UJ6ephu = FCzlJghHX2nPG3BRNc0SoetQdqW.translatePath(LyNiIHPOwD3hCUYEFM7(u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰ࡪࡲࡱࡪ࠭஁"))
	ffMPJBwaht5 = FCzlJghHX2nPG3BRNc0SoetQdqW.translatePath(IpC4qHXRuyNFjzWv(u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱࡯ࡳ࡬ࡶࡡࡵࡪࠪஂ"))
	i4MTUvPC0IdYDtZ1gOWz7oQGy = wkMR5x1gTWEQIc6qHCa.path.join(Hyw4UJ6ephu,PtkEvXAqif14G20QZsaSyT(u"ࠧࡶࡵࡨࡶࡩࡧࡴࡢࠩஃ"),SaB5hx3PZwXRLtKgrTfQvId(u"ࠨࡆࡤࡸࡦࡨࡡࡴࡧࠪ஄"),JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠩࡄࡨࡩࡵ࡮ࡴ࠵࠶࠲ࡩࡨࠧஅ"))
	mnKDoEOqYJLtX1rfFCz0sdRQ = wkMR5x1gTWEQIc6qHCa.path.join(Hyw4UJ6ephu,uuExaKGL7UONtevRd(u"ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬஆ"),yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠫࡉࡧࡴࡢࡤࡤࡷࡪ࠭இ"),ZchUJdM93pTA7zG5(u"ࠬ࡜ࡩࡦࡹࡐࡳࡩ࡫ࡳ࠷࠰ࡧࡦࠬஈ"))
	Z5ng8awdRcW39U0kvbGm = wkMR5x1gTWEQIc6qHCa.path.join(Hyw4UJ6ephu,jXE2YHkswT8y(u"࠭ࡵࡴࡧࡵࡨࡦࡺࡡࠨஉ"),JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠧࡅࡣࡷࡥࡧࡧࡳࡦࠩஊ"),FRYcH4KL7e9gv5pEB(u"ࠨࡖࡨࡼࡹࡻࡲࡦࡵ࠴࠷࠳ࡪࡢࠨ஋"))
	IrGVXjLSAaDgOm4lE80Q = yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࡷࠪࡠࡺ࠶࠲ࡥ࠳ࠪ஌")
	from urllib.parse import quote as _9hcm7SBKxOpwtMzXv0W
else:
	K1KA8whDjRrQI3OBgMzbLo9 = WwMgozBIC32n9d0tyfp.translatePath(hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡸࡣ࡯ࡦࠫ஍"))
	Hyw4UJ6ephu = WwMgozBIC32n9d0tyfp.translatePath(tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯ࡩࡱࡰࡩࠬஎ"))
	ffMPJBwaht5 = WwMgozBIC32n9d0tyfp.translatePath(SaB5hx3PZwXRLtKgrTfQvId(u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰࡮ࡲ࡫ࡵࡧࡴࡩࠩஏ"))
	i4MTUvPC0IdYDtZ1gOWz7oQGy = wkMR5x1gTWEQIc6qHCa.path.join(Hyw4UJ6ephu,EMO8gy4LrsNTh0knZwpSeU75APW(u"࠭ࡵࡴࡧࡵࡨࡦࡺࡡࠨஐ"),ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠧࡅࡣࡷࡥࡧࡧࡳࡦࠩ஑"),zmcGfOdvAjsELeJlP(u"ࠨࡃࡧࡨࡴࡴࡳ࠳࠹࠱ࡨࡧ࠭ஒ"))
	mnKDoEOqYJLtX1rfFCz0sdRQ = wkMR5x1gTWEQIc6qHCa.path.join(Hyw4UJ6ephu,IpC4qHXRuyNFjzWv(u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫஓ"),ZchUJdM93pTA7zG5(u"ࠪࡈࡦࡺࡡࡣࡣࡶࡩࠬஔ"),y6y5HtgXO4TkUbwVZ(u"࡛ࠫ࡯ࡥࡸࡏࡲࡨࡪࡹ࠶࠯ࡦࡥࠫக"))
	Z5ng8awdRcW39U0kvbGm = wkMR5x1gTWEQIc6qHCa.path.join(Hyw4UJ6ephu,Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧ஖"),L90uqo28xEKSFUwYTcm51yRWZIkft(u"࠭ࡄࡢࡶࡤࡦࡦࡹࡥࠨ஗"),sVzojQerUqX(u"ࠧࡕࡧࡻࡸࡺࡸࡥࡴ࠳࠶࠲ࡩࡨࠧ஘"))
	IrGVXjLSAaDgOm4lE80Q = Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࡶࠩ࡟ࡹ࠵࠸ࡤ࠲ࠩங").encode(df6QpwGxuJVZr)
	from urllib import quote as _9hcm7SBKxOpwtMzXv0W
Ct1U8Ao9wucR = wkMR5x1gTWEQIc6qHCa.path.join(ffMPJBwaht5,FRYcH4KL7e9gv5pEB(u"ࠩ࡮ࡳࡩ࡯࠮࡭ࡱࡪࠫச"))
fftaeIcglCErxBsY3ORFh = wkMR5x1gTWEQIc6qHCa.path.join(ffMPJBwaht5,MgP8OjoaiWQEVG59(u"ࠪ࡯ࡴࡪࡩ࠯ࡱ࡯ࡨ࠳ࡲ࡯ࡨࠩ஛"))
cIFB9Ey2RMC8dveLi = wkMR5x1gTWEQIc6qHCa.path.join(StqmrCIJX4T623w5j9NEonxfQ,tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠫ࡮ࡶࡴࡷ࠳ࡧࡥࡹࡧ࡟ࡠࡡ࠱ࡨࡧ࠭ஜ"))
nodBvzbNipsO3JfK48HVxauREWhGFZ = wkMR5x1gTWEQIc6qHCa.path.join(StqmrCIJX4T623w5j9NEonxfQ,Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠬ࡯ࡰࡵࡸ࠵ࡨࡦࡺࡡࡠࡡࡢ࠲ࡩࡨࠧ஝"))
XRfL4NKwpE3q0dbkGUDVJCa96ohtr = wkMR5x1gTWEQIc6qHCa.path.join(StqmrCIJX4T623w5j9NEonxfQ,LyNiIHPOwD3hCUYEFM7(u"࠭࡭࠴ࡷࡧࡥࡹࡧ࡟ࡠࡡ࠱ࡨࡧ࠭ஞ"))
v05aOkM7NXBHuT3UpAdiPq4 = wkMR5x1gTWEQIc6qHCa.path.join(StqmrCIJX4T623w5j9NEonxfQ,ZchUJdM93pTA7zG5(u"ࠧࡧࡣࡹࡳࡺࡸࡩࡵࡧࡶ࠲ࡩࡧࡴࠨட"))
mzo15abwgdesuvn4CEGjSiNpDYVk = wkMR5x1gTWEQIc6qHCa.path.join(StqmrCIJX4T623w5j9NEonxfQ,xpT28sXu051(u"ࠨ࡫ࡳࡸࡻ࡬ࡩ࡭ࡧࡢࡣࡤ࠴ࡤࡢࡶࠪ஠"))
qNZoztHEJb5YcgmsiBnO = wkMR5x1gTWEQIc6qHCa.path.join(StqmrCIJX4T623w5j9NEonxfQ,IpC4qHXRuyNFjzWv(u"ࠩࡰ࠷ࡺ࡬ࡩ࡭ࡧࡢࡣࡤ࠴ࡤࡢࡶࠪ஡"))
yBIA5N98RmP7pdzeS3s0gOH = wkMR5x1gTWEQIc6qHCa.path.join(StqmrCIJX4T623w5j9NEonxfQ,EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠪ࡭ࡲࡧࡧࡦࡵࠪ஢"))
e98JbQcKOVoL1diakqYzCv3MDR = wkMR5x1gTWEQIc6qHCa.path.join(yBIA5N98RmP7pdzeS3s0gOH,IpC4qHXRuyNFjzWv(u"ࠫࡩ࡯ࡡ࡭ࡱࡪࡷࠬண"))
z6kbVo0FJ8lHmdGS = wkMR5x1gTWEQIc6qHCa.path.join(yBIA5N98RmP7pdzeS3s0gOH,HtK4o2sTPgA78U(u"ࠬࡴ࡯ࡵ࡫ࡩ࡭ࡨࡧࡴࡪࡱࡱࡷࠬத"))
PuhkKlL5mRz = wkMR5x1gTWEQIc6qHCa.path.join(e98JbQcKOVoL1diakqYzCv3MDR,TlGXWLYsV1z(u"࠭ࡤࡪࡣ࡯ࡳ࡬ࡥ࠰࠱࠲࠳ࡣ࠳ࡶ࡮ࡨࠩ஥"))
V5f96hvSkeUwCxZrE4dlzpy = DnzmO5hVTuNriyELed.Addon().getAddonInfo(xpT28sXu051(u"ࠧࡱࡣࡷ࡬ࠬ஦"))
tM4HZFfyPg5ICrAvE = wkMR5x1gTWEQIc6qHCa.path.join(V5f96hvSkeUwCxZrE4dlzpy,FRYcH4KL7e9gv5pEB(u"ࠨ࡫ࡦࡳࡳ࠴ࡰ࡯ࡩࠪ஧"))
spCNX6kIrUqYV0JyL9i4Kol = wkMR5x1gTWEQIc6qHCa.path.join(V5f96hvSkeUwCxZrE4dlzpy,HtK4o2sTPgA78U(u"ࠩࡷ࡬ࡺࡳࡢ࠯ࡲࡱ࡫ࠬந"))
ofV9Z80GDXWbmOkSlz4Ccjvt = wkMR5x1gTWEQIc6qHCa.path.join(V5f96hvSkeUwCxZrE4dlzpy,tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠪࡪࡦࡴࡡࡳࡶ࠱ࡴࡳ࡭ࠧன"))
ddrDEicMVvQnbRoA0sNS61GxXCH93 = wkMR5x1gTWEQIc6qHCa.path.join(V5f96hvSkeUwCxZrE4dlzpy,YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠫࡧࡧ࡮࡯ࡧࡵ࠲ࡵࡴࡧࠨப"))
aPVfGTBZqm78CnFIHcv = wkMR5x1gTWEQIc6qHCa.path.join(V5f96hvSkeUwCxZrE4dlzpy,tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠬࡲࡡ࡯ࡦࡶࡧࡦࡶࡥ࠯ࡲࡱ࡫ࠬ஫"))
kUMf0S4nLF = wkMR5x1gTWEQIc6qHCa.path.join(V5f96hvSkeUwCxZrE4dlzpy,ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"࠭ࡰࡰࡵࡷࡩࡷ࠴ࡰ࡯ࡩࠪ஬"))
a4hp5zLeVsqkdvG39wxcP61 = wkMR5x1gTWEQIc6qHCa.path.join(V5f96hvSkeUwCxZrE4dlzpy,tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠧࡤ࡮ࡨࡥࡷࡲ࡯ࡨࡱ࠱ࡴࡳ࡭ࠧ஭"))
nUGdrSF5q2BwAjLv6iNt10z = wkMR5x1gTWEQIc6qHCa.path.join(V5f96hvSkeUwCxZrE4dlzpy,tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠨࡥ࡯ࡩࡦࡸࡡࡳࡶ࠱ࡴࡳ࡭ࠧம"))
NVyzGu2hnfiB61rP = wkMR5x1gTWEQIc6qHCa.path.join(V5f96hvSkeUwCxZrE4dlzpy,hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠩࡰࡩࡳࡻ࡟ࡳࡧࡧࡣ࠷࠶࠰ࡹ࠴࠸࠴࠳ࡶ࡮ࡨࠩய"))
viMfkPrbW6X = wkMR5x1gTWEQIc6qHCa.path.join(V5f96hvSkeUwCxZrE4dlzpy,AbqCJZdWQP9j(u"ࠪࡧ࡭ࡧ࡮ࡨࡧ࡯ࡳ࡬࠴ࡴࡹࡶࠪர"))
p2tS61Jv9RBQdgKoZy = wkMR5x1gTWEQIc6qHCa.path.join(Hyw4UJ6ephu,LyNiIHPOwD3hCUYEFM7(u"ࠫࡦࡪࡤࡰࡰࡶࠫற"))
yO6VIi1bo5 = wkMR5x1gTWEQIc6qHCa.path.join(Hyw4UJ6ephu,FRYcH4KL7e9gv5pEB(u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧல"),ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"࠭ࡡࡥࡦࡲࡲࡤࡪࡡࡵࡣࠪள"),M8hQu61Uid,IpC4qHXRuyNFjzWv(u"ࠧࡴࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡻࡱࡱ࠭ழ"))
mwo4Z2LyxS3BeC5fbntE = wkMR5x1gTWEQIc6qHCa.path.join(K1KA8whDjRrQI3OBgMzbLo9,L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠨ࡯ࡨࡨ࡮ࡧࠧவ"),tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠩࡉࡳࡳࡺࡳࠨஶ"),L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠪࡥࡷ࡯ࡡ࡭࠰ࡷࡸ࡫࠭ஷ"))
IDxpbtWgzXHs3u08Q7nR6YerO = zmcGfOdvAjsELeJlP(u"࠹Ꮒ")
T7Rtxv5SnE1O94dLBcVNKHDZbJQe = [SaB5hx3PZwXRLtKgrTfQvId(u"ฺࠫ็ัࠨஸ"),ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠬษ่ๅࠩஹ"),XrTw01KtLzbpoyMf(u"࠭หศ่ํࠫ஺"),hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠧฬษ็ฯࠬ஻"),y6y5HtgXO4TkUbwVZ(u"ࠨำสฬ฾࠭஼"),Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠩัหู๊ࠧ஽"),CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠪืฬีำࠨா"),sVzojQerUqX(u"ุࠫอศฺࠩி"),tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠬัวๆ่ࠪீ"),hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"࠭สศี฼ࠫு"),tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ฺࠧษืีࠬூ")]
xxkwlavUo3gJfB = PtkEvXAqif14G20QZsaSyT(u"ࠨ⸽ࠣ⼡ࠥ⸰ࠠ⸼ࠩ௃")
y9gSjTop7DedV0fF8c1v = [CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠩࡅࡓࡐࡘࡁࠨ௄"),Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠪࡔࡆࡔࡅࡕࠩ௅"),IpC4qHXRuyNFjzWv(u"ࠫࡆࡘࡁࡃࡋࡆࡘࡔࡕࡎࡔࠩெ"),SaB5hx3PZwXRLtKgrTfQvId(u"ࠬࡑࡁࡓࡄࡄࡐࡆ࡚ࡖࠨே"),GGx4qyKP1vUtRghsE2WfaHLMXZ(u"࠭ࡉࡇࡋࡏࡑࠬை"),sVzojQerUqX(u"ࠧࡊࡈࡌࡐࡒ࠳ࡁࡓࡃࡅࡍࡈ࠭௉"),jXE2YHkswT8y(u"ࠨࡋࡉࡍࡑࡓ࠭ࡆࡐࡊࡐࡎ࡙ࡈࠨொ")]
y9gSjTop7DedV0fF8c1v += [zmcGfOdvAjsELeJlP(u"ࠩ࡜ࡘࡇࡥࡃࡉࡃࡑࡒࡊࡒࡓࠨோ"),LyNiIHPOwD3hCUYEFM7(u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠶ࠬௌ"),hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠫࡆࡑࡏࡂࡏ்ࠪ"),Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠬࡇࡋࡘࡃࡐࠫ௎"),FRYcH4KL7e9gv5pEB(u"࠭ࡁࡍࡏࡄࡅࡗࡋࡆࠨ௏"),LyNiIHPOwD3hCUYEFM7(u"ࠧࡔࡊࡒࡓࡋࡓࡁ࡙ࠩௐ")]
r7IetLGg5o = [TlGXWLYsV1z(u"ࠨࡎࡄࡖࡔࡠࡁࠨ௑"),YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠩࡉࡅࡏࡋࡒࡔࡊࡒ࡛ࠬ௒"),HtK4o2sTPgA78U(u"ࠪࡘ࡛ࡌࡕࡏࠩ௓"),MgP8OjoaiWQEVG59(u"ࠫࡑࡕࡄ࡚ࡐࡈࡘࠬ௔"),L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠬࡉࡉࡎࡃࡑࡓ࡜࠭௕"),MgP8OjoaiWQEVG59(u"࠭ࡓࡉࡃࡋࡍࡉࡔࡅࡘࡕࠪ௖"),jXE2YHkswT8y(u"ࠧࡂࡔࡄࡆࡘࡋࡅࡅࠩௗ")]
r7IetLGg5o += [uuExaKGL7UONtevRd(u"ࠨࡅࡌࡑࡆࡉࡌࡖࡄࠪ௘"),UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘࠫ௙"),uuExaKGL7UONtevRd(u"ࠪࡗࡍࡕࡆࡉࡃࠪ௚"),hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠫ࡜ࡋࡃࡊࡏࡄ࠵ࠬ௛"),LyNiIHPOwD3hCUYEFM7(u"ࠬ࡝ࡅࡄࡋࡐࡅ࠷࠭௜")]
hN2KoH3RPWb = [GGx4qyKP1vUtRghsE2WfaHLMXZ(u"࠭ࡔࡊࡍࡄࡅ࡙࠭௝"),sVzojQerUqX(u"ࠧࡂ࡛ࡏࡓࡑ࠭௞"),JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠨࡈࡒࡗ࡙ࡇࠧ௟"),xpT28sXu051(u"ࠩࡉࡅࡇࡘࡁࡌࡃࠪ௠"),jXE2YHkswT8y(u"ࠪ࡝ࡆࡗࡏࡕࠩ௡"),MgP8OjoaiWQEVG59(u"ࠫࡘࡎࡁࡃࡃࡎࡅ࡙࡟ࠧ௢"),EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠬ࡜ࡁࡓࡄࡒࡒࠬ௣"),GGx4qyKP1vUtRghsE2WfaHLMXZ(u"࠭ࡂࡓࡕࡗࡉࡏ࠭௤")]
hN2KoH3RPWb += [L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠧࡌࡋࡕࡑࡆࡒࡋࠨ௥"),sVzojQerUqX(u"ࠨࡃࡑࡍࡒࡋ࡚ࡊࡆࠪ௦"),YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠩࡉࡅࡗࡋࡓࡌࡑࠪ௧"),xpT28sXu051(u"ࠪࡌࡆࡒࡁࡄࡋࡐࡅࠬ௨"),GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠫࡆࡒࡍࡔࡖࡅࡅࠬ௩"),MgP8OjoaiWQEVG59(u"࡙ࠬࡈࡐࡑࡉࡒࡊ࡚ࠧ௪"),hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"࠭ࡄࡓࡃࡐࡅࡘ࠽ࠧ௫")]
hN2KoH3RPWb += [yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠧࡄࡋࡐࡅࡋࡘࡅࡆࠩ௬"),y6y5HtgXO4TkUbwVZ(u"ࠨࡅࡌࡑࡆࡌࡁࡏࡕࠪ௭"),vODxLKW5Ql6r4Fbm8(u"ࠩࡈࡐࡎࡌࡖࡊࡆࡈࡓࠬ௮"),sVzojQerUqX(u"ࠪࡊ࡚ࡔࡏࡏࡖ࡙ࠫ௯"),sVzojQerUqX(u"ࠫࡈࡏࡍࡂࡎࡌࡋࡍ࡚ࠧ௰"),UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠬࡉࡉࡎࡃ࠷࠴࠵࠭௱"),tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"࠭ࡃࡊࡏࡄࡅࡇࡊࡏࠨ௲")]
hN2KoH3RPWb += [YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠧࡂࡍ࡚ࡅࡒ࡚ࡕࡃࡇࠪ௳"),tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠨࡏࡄࡗࡆ࡜ࡉࡅࡇࡒࠫ௴"),IpC4qHXRuyNFjzWv(u"ࠩࡇࡖࡆࡓࡁࡄࡃࡉࡉࠬ௵"),xpT28sXu051(u"ࠪࡊ࡚࡙ࡈࡂࡔࡗ࡚ࠬ௶"),PtkEvXAqif14G20QZsaSyT(u"ࠫࡈࡏࡍࡂ࡙ࡅࡅࡘ࠭௷"),xpT28sXu051(u"ࠬࡇࡈࡘࡃࡎࠫ௸"),LyNiIHPOwD3hCUYEFM7(u"࠭ࡖࡊࡆࡈࡓࡓ࡙ࡁࡆࡏࠪ௹")]
hN2KoH3RPWb += [YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠧࡌࡃࡗࡏࡔ࡚ࡔࡗࠩ௺"),L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠨࡕࡈࡖࡎࡋࡓࡕࡋࡐࡉࠬ௻"),CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠩࡉ࡙ࡘࡎࡁࡓࡘࡌࡈࡊࡕࠧ௼"),EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠪࡇࡎࡓࡁ࠵ࡒࠪ௽"),uuExaKGL7UONtevRd(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠶࠭௾"),EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠸ࠧ௿"),ZchUJdM93pTA7zG5(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠴ࠨఀ")]
QAXtCkG3TjP8RYBx7eFLgOq2 = [ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨఁ"),vODxLKW5Ql6r4Fbm8(u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯࡙ࡍࡉࡋࡏࡔࠩం"),jXE2YHkswT8y(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡔࡑࡇ࡙ࡍࡋࡖࡘࡘ࠭ః"),zmcGfOdvAjsELeJlP(u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱ࡈࡎࡁࡏࡐࡈࡐࡘ࠭ఄ")]
QAXtCkG3TjP8RYBx7eFLgOq2 += [zmcGfOdvAjsELeJlP(u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏࠩఅ"),AbqCJZdWQP9j(u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰࡚ࡎࡊࡅࡐࡕࠪఆ"),CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱ࡕࡒࡁ࡚ࡎࡌࡗ࡙࡙ࠧఇ"),TlGXWLYsV1z(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲ࡉࡈࡂࡐࡑࡉࡑ࡙ࠧఈ"),XrTw01KtLzbpoyMf(u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡌࡊࡘࡈࡗࠬఉ"),IpC4qHXRuyNFjzWv(u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡉࡃࡖࡌ࡙ࡇࡇࡔࠩఊ")]
QAXtCkG3TjP8RYBx7eFLgOq2 += [XrTw01KtLzbpoyMf(u"ࠪࡍࡕ࡚ࡖࠨఋ"),hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠫࡎࡖࡔࡗ࠯ࡏࡍ࡛ࡋࠧఌ"),PtkEvXAqif14G20QZsaSyT(u"ࠬࡏࡐࡕࡘ࠰ࡑࡔ࡜ࡉࡆࡕࠪ఍"),MgP8OjoaiWQEVG59(u"࠭ࡉࡑࡖ࡙࠱ࡘࡋࡒࡊࡇࡖࠫఎ")]
QAXtCkG3TjP8RYBx7eFLgOq2 += [L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠧࡎ࠵ࡘࠫఏ"),FRYcH4KL7e9gv5pEB(u"ࠨࡏ࠶࡙࠲ࡒࡉࡗࡇࠪఐ"),PtkEvXAqif14G20QZsaSyT(u"ࠩࡐ࠷࡚࠳ࡍࡐࡘࡌࡉࡘ࠭఑"),uuExaKGL7UONtevRd(u"ࠪࡑ࠸࡛࠭ࡔࡇࡕࡍࡊ࡙ࠧఒ")]
KBCco4GTRUp1a = [MgP8OjoaiWQEVG59(u"ࠫࡋ࡛ࡓࡉࡃࡕࡘ࡛࠭ఓ"),GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠬࡊࡒࡂࡏࡄࡇࡆࡌࡅࠨఔ"),jXE2YHkswT8y(u"࠭ࡃࡊࡏࡄ࠸࠵࠶ࠧక"),SaB5hx3PZwXRLtKgrTfQvId(u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠵ࠩఖ"),sVzojQerUqX(u"ࠨࡎࡄࡖࡔࡠࡁࠨగ")]
VWNd7mbavTp8ucM9 = [LyNiIHPOwD3hCUYEFM7(u"ࠩ࡜ࡘࡇࡥࡃࡉࡃࡑࡒࡊࡒࡓࠨఘ")]
rYCyXNbRlKxnT5w  = [FRYcH4KL7e9gv5pEB(u"ࠪࡅࡐ࡝ࡁࡎࠩఙ"),UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠫࡆࡘࡁࡃࡕࡈࡉࡉ࠭చ"),XrTw01KtLzbpoyMf(u"ࠬࡈࡏࡌࡔࡄࠫఛ"),tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"࠭ࡁࡌࡑࡄࡑࠬజ"),IpC4qHXRuyNFjzWv(u"ࠧࡄࡋࡐࡅࡈࡒࡕࡃࠩఝ"),zmcGfOdvAjsELeJlP(u"ࠨࡈࡄࡆࡗࡇࡋࡂࠩఞ"),UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠩࡉࡅࡘࡋࡌࡉࡆ࠵ࠫట"),XrTw01KtLzbpoyMf(u"ࠪࡇࡎࡓࡁࡇࡔࡈࡉࠬఠ"),YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠫࡈࡏࡍࡂ࠶ࡓࠫడ")]
rYCyXNbRlKxnT5w += [zmcGfOdvAjsELeJlP(u"ࠬࡉࡉࡎࡃࡉࡅࡓ࡙ࠧఢ"),L90uqo28xEKSFUwYTcm51yRWZIkft(u"࠭ࡃࡊࡏࡄࡐࡎࡍࡈࡕࠩణ"),UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠧࡄࡋࡐࡅࡓࡕࡗࠨత"),CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠨ࡙ࡈࡇࡎࡓࡁ࠲ࠩథ"),ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"࡚ࠩࡉࡈࡏࡍࡂ࠴ࠪద"),hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠪࡗࡍࡇࡈࡊࡆࡑࡉ࡜࡙ࠧధ"),zmcGfOdvAjsELeJlP(u"ࠫࡋࡕࡓࡕࡃࠪన"),PtkEvXAqif14G20QZsaSyT(u"ࠬࡇࡈࡘࡃࡎࠫ఩"),EMO8gy4LrsNTh0knZwpSeU75APW(u"࠭ࡓࡉࡑࡒࡊࡓࡋࡔࠨప")]
rYCyXNbRlKxnT5w += [L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠧࡔࡇࡕࡍࡊ࡙ࡔࡊࡏࡈࠫఫ"),TlGXWLYsV1z(u"ࠨࡈࡄࡎࡊࡘࡓࡉࡑ࡚ࠫబ"),FRYcH4KL7e9gv5pEB(u"ࠩࡎࡅࡗࡈࡁࡍࡃࡗ࡚ࠬభ"),ZchUJdM93pTA7zG5(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠵ࠬమ"),hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠷࠭య"),AbqCJZdWQP9j(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠺ࠧర"),vODxLKW5Ql6r4Fbm8(u"࠭ࡈࡂࡎࡄࡇࡎࡓࡁࠨఱ"),hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠧࡂࡍ࡚ࡅࡒ࡚ࡕࡃࡇࠪల")]
rYCyXNbRlKxnT5w += [y6y5HtgXO4TkUbwVZ(u"ࠨࡎࡒࡈ࡞ࡔࡅࡕࠩళ"),UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘࠫఴ"),EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠪࡗࡍࡕࡏࡇࡏࡄ࡜ࠬవ"),FRYcH4KL7e9gv5pEB(u"࡙ࠫ࡜ࡆࡖࡐࠪశ"),tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠬࡉࡉࡎࡃࡄࡆࡉࡕࠧష"),sVzojQerUqX(u"࠭ࡓࡉࡑࡉࡌࡆ࠭స"),JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠧࡗࡃࡕࡆࡔࡔࠧహ"),PtkEvXAqif14G20QZsaSyT(u"ࠨࡃࡏࡑࡘ࡚ࡂࡂࠩ఺"),UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠩࡉࡅࡗࡋࡓࡌࡑࠪ఻")]
rYCyXNbRlKxnT5w += [ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠪࡆࡗ࡙ࡔࡆࡌ఼ࠪ"),hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠫ࡞ࡇࡑࡐࡖࠪఽ"),GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠬࡊࡒࡂࡏࡄࡗ࠼࠭ా"),PtkEvXAqif14G20QZsaSyT(u"࠭ࡃࡊࡏࡄ࠸࠵࠶ࠧి"),ZchUJdM93pTA7zG5(u"ࠧࡂࡔࡄࡆࡎࡉࡔࡐࡑࡑࡗࠬీ"),vODxLKW5Ql6r4Fbm8(u"ࠨࡃࡏࡑࡆࡇࡒࡆࡈࠪు"),IpC4qHXRuyNFjzWv(u"ࠩࡎࡅ࡙ࡑࡏࡕࡖ࡙ࠫూ"),GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠪࡐࡆࡘࡏ࡛ࡃࠪృ"),yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠫࡈࡏࡍࡂ࡙ࡅࡅࡘ࠭ౄ")]
rYCyXNbRlKxnT5w += [LyNiIHPOwD3hCUYEFM7(u"ࠬࡌࡕࡔࡊࡄࡖ࡛ࡏࡄࡆࡑࠪ౅"),UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"࠭ࡆࡖࡕࡋࡅࡗ࡚ࡖࠨె"),tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠧࡌࡋࡕࡑࡆࡒࡋࠨే"),sVzojQerUqX(u"ࠨࡆࡕࡅࡒࡇࡃࡂࡈࡈࠫై"),IpC4qHXRuyNFjzWv(u"ࠩࡗࡍࡐࡇࡁࡕࠩ౉"),uuExaKGL7UONtevRd(u"ࠪࡗࡍࡇࡂࡂࡍࡄࡘ࡞࠭ొ"),TlGXWLYsV1z(u"ࠫࡆࡔࡉࡎࡇ࡝ࡍࡉ࠭ో")]
EvdXOkT37uMNc06FHKnSowAxei9  = [GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰࡚ࡎࡊࡅࡐࡕࠪౌ"),ZchUJdM93pTA7zG5(u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱ࡕࡒࡁ࡚ࡎࡌࡗ్࡙࡙ࠧ"),SaB5hx3PZwXRLtKgrTfQvId(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲ࡉࡈࡂࡐࡑࡉࡑ࡙ࠧ౎"),EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡌࡊࡘࡈࡗࠬ౏"),hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡉࡃࡖࡌ࡙ࡇࡇࡔࠩ౐")]
EvdXOkT37uMNc06FHKnSowAxei9 += [y6y5HtgXO4TkUbwVZ(u"ࠪࡍࡋࡏࡌࡎ࠯ࡄࡖࡆࡈࡉࡄࠩ౑"),tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠫࡎࡌࡉࡍࡏ࠰ࡉࡓࡍࡌࡊࡕࡋࠫ౒")]
EvdXOkT37uMNc06FHKnSowAxei9 += [TlGXWLYsV1z(u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡖࡊࡆࡈࡓࡘ࠭౓"),y6y5HtgXO4TkUbwVZ(u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡑࡎࡄ࡝ࡑࡏࡓࡕࡕࠪ౔"),vODxLKW5Ql6r4Fbm8(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡅࡋࡅࡓࡔࡅࡍࡕౕࠪ")]
EvdXOkT37uMNc06FHKnSowAxei9 += [jXE2YHkswT8y(u"ࠨࡋࡓࡘ࡛࠳ࡌࡊࡘࡈౖࠫ"),jXE2YHkswT8y(u"ࠩࡌࡔ࡙࡜࠭ࡎࡑ࡙ࡍࡊ࡙ࠧ౗"),JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠪࡍࡕ࡚ࡖ࠮ࡕࡈࡖࡎࡋࡓࠨౘ")]
EvdXOkT37uMNc06FHKnSowAxei9 += [ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠫࡒ࠹ࡕ࠮ࡎࡌ࡚ࡊ࠭ౙ"),EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠬࡓ࠳ࡖ࠯ࡐࡓ࡛ࡏࡅࡔࠩౚ"),yJeq1BjfiO4NFuwIEzxVLK6b9s(u"࠭ࡍ࠴ࡗ࠰ࡗࡊࡘࡉࡆࡕࠪ౛")]
VL0vzXn6HucPhMWOwtRjsT = [hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠧࡎ࠵ࡘࠫ౜"),HtK4o2sTPgA78U(u"ࠨࡋࡓࡘ࡛࠭ౝ"),vODxLKW5Ql6r4Fbm8(u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔࠧ౞"),TlGXWLYsV1z(u"ࠪࡍࡋࡏࡌࡎࠩ౟"),LyNiIHPOwD3hCUYEFM7(u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬౠ")]
sdf5uU2hLnzVjQxcBJtGgP4EXyvOA = rYCyXNbRlKxnT5w+VL0vzXn6HucPhMWOwtRjsT
uXtbUqcMdTFICQjGY7a63em = rYCyXNbRlKxnT5w+EvdXOkT37uMNc06FHKnSowAxei9
bhCnG4zQdj = uXtbUqcMdTFICQjGY7a63em+VWNd7mbavTp8ucM9
j5q8z4HT3cfhvK = [YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠬࡖࡒࡊࡘࡄࡘࡊ࠭ౡ")]+y9gSjTop7DedV0fF8c1v+[vODxLKW5Ql6r4Fbm8(u"࠭ࡍࡊ࡚ࡈࡈࠬౢ")]+r7IetLGg5o+[LyNiIHPOwD3hCUYEFM7(u"ࠧࡑࡗࡅࡐࡎࡉࠧౣ")]+hN2KoH3RPWb+[xpT28sXu051(u"ࠨࡒࡕࡍ࡛ࡇࡔࡆࠩ౤")]+QAXtCkG3TjP8RYBx7eFLgOq2
llVTWkotwd = [MgP8OjoaiWQEVG59(u"ࠩࡄࡏࡔࡇࡍࠨ౥"),AbqCJZdWQP9j(u"ࠪࡅࡐ࡝ࡁࡎࠩ౦"),xpT28sXu051(u"ࠫࡎࡌࡉࡍࡏࠪ౧"),CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠬࡑࡁࡓࡄࡄࡐࡆ࡚ࡖࠨ౨"),L90uqo28xEKSFUwYTcm51yRWZIkft(u"࠭ࡁࡍࡏࡄࡅࡗࡋࡆࠨ౩"),HtK4o2sTPgA78U(u"ࠧࡔࡊࡒࡓࡋࡓࡁ࡙ࠩ౪"),PtkEvXAqif14G20QZsaSyT(u"ࠨࡕࡋࡍࡆ࡜ࡏࡊࡅࡈࠫ౫"),TlGXWLYsV1z(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪ౬"),L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎࠨ౭"),HtK4o2sTPgA78U(u"ࠫࡒ࠹ࡕࠨ౮"),AbqCJZdWQP9j(u"ࠬࡏࡐࡕࡘࠪ౯"),EMO8gy4LrsNTh0knZwpSeU75APW(u"࠭ࡂࡐࡍࡕࡅࠬ౰"),MgP8OjoaiWQEVG59(u"ࠧࡆࡎࡆࡍࡓࡋࡍࡂࠩ౱"),TlGXWLYsV1z(u"ࠨࡃࡕࡅࡇࡏࡃࡕࡑࡒࡒࡘ࠭౲")]
NOT_TO_TEST_ALL_SERVERS = [ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠩࡢࡅࡐࡕ࡟ࠨ౳"),sVzojQerUqX(u"ࠪࡣࡆࡑࡗࡠࠩ౴"),FRYcH4KL7e9gv5pEB(u"ࠫࡤࡏࡆࡍࡡࠪ౵"),FRYcH4KL7e9gv5pEB(u"ࠬࡥࡋࡓࡄࡢࠫ౶"),JZszNnIEMAx28Yao0yqhiXGKOPb(u"࠭࡟ࡎࡔࡉࡣࠬ౷"),PtkEvXAqif14G20QZsaSyT(u"ࠧࡠࡕࡋࡑࡤ࠭౸"),y6y5HtgXO4TkUbwVZ(u"ࠨࡡࡖࡌ࡛ࡥࠧ౹"),ZchUJdM93pTA7zG5(u"ࠩࡢ࡝࡚࡚࡟ࠨ౺"),GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠪࡣࡉࡒࡍࡠࠩ౻"),zmcGfOdvAjsELeJlP(u"ࠫࡤࡓࡕࠨ౼"),hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠬࡥࡉࡑࠩ౽"),PtkEvXAqif14G20QZsaSyT(u"࠭࡟ࡃࡍࡕࡣࠬ౾"),sVzojQerUqX(u"ࠧࡠࡇࡏࡇࡤ࠭౿"),EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠨࡡࡄࡖ࡙ࡥࠧಀ")]
N9mPkX14E8VyHDSF = [yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠩࡐࡉࡓ࡛࡟ࡓࡇ࡙ࡉࡗ࡙ࡅࡅࡡࡓࡉࡗࡓࠧಁ"),FRYcH4KL7e9gv5pEB(u"ࠪࡑࡊࡔࡕࡠࡃࡖࡇࡊࡔࡄࡆࡆࡢࡔࡊࡘࡍࠨಂ"),EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠫࡒࡋࡎࡖࡡࡇࡉࡘࡉࡅࡏࡆࡈࡈࡤࡖࡅࡓࡏࠪಃ"),CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠬࡓࡅࡏࡗࡢࡖࡆࡔࡄࡐࡏࡌ࡞ࡊࡊ࡟ࡑࡇࡕࡑࠬ಄"),GGx4qyKP1vUtRghsE2WfaHLMXZ(u"࠭ࡍࡆࡐࡘࡣࡗࡋࡖࡆࡔࡖࡉࡉࡥࡔࡆࡏࡓࠫಅ"),y6y5HtgXO4TkUbwVZ(u"ࠧࡎࡇࡑ࡙ࡤࡇࡓࡄࡇࡑࡈࡊࡊ࡟ࡕࡇࡐࡔࠬಆ"),xpT28sXu051(u"ࠨࡏࡈࡒ࡚ࡥࡄࡆࡕࡆࡉࡓࡊࡅࡅࡡࡗࡉࡒࡖࠧಇ"),xpT28sXu051(u"ࠩࡐࡉࡓ࡛࡟ࡓࡃࡑࡈࡔࡓࡉ࡛ࡇࡇࡣ࡙ࡋࡍࡑࠩಈ")]
ITjWNo35aOkfebDQnA = [
						 jXE2YHkswT8y(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡘࡔࡊࡄࡖࡎࡔࡇ࠮࠳ࡶࡸࠬಉ")
						,GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࡙࠭ࡕࡋࡅࡗࡏࡎࡈ࠯࠵ࡲࡩ࠭ಊ")
						,FRYcH4KL7e9gv5pEB(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡏࡘࡐ࡙ࡏ࡟࡙ࡕࡋࡅࡗࡏࡎࡈ࠯࠴ࡷࡹ࠭ಋ")
						]
LJCPyc4vO8t3d = [
						 XrTw01KtLzbpoyMf(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡔࡇࡑࡈࡤࡇࡎࡂࡎ࡜ࡘࡎࡉࡓࡠࡇ࡙ࡉࡓ࡚ࡓ࠮࠳ࡶࡸࠬಌ")
						,PtkEvXAqif14G20QZsaSyT(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡇ࡛ࡘࡗࡇࡃࡕࡡࡐ࠷࡚࠾࠭࠲ࡵࡷࠫ಍")
						,JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡕࡅࡓࡊࡏࡎࡡࡘࡗࡊࡘࡁࡈࡇࡑࡘ࠲࠷ࡳࡵࠩಎ")
						,FRYcH4KL7e9gv5pEB(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡊ࡚࡟ࡑࡔࡒ࡜ࡎࡋࡓࡠࡎࡌࡗ࡙࠳࠱ࡴࡶࠪಏ")
						,EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠪࡍࡕ࡚ࡖ࠮ࡅࡋࡉࡈࡑ࡟ࡂࡅࡆࡓ࡚ࡔࡔ࠮࠳ࡶࡸࠬಐ")
						,L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡅࡐࡎࡒࡇࡆ࡚ࡉࡐࡐ࠰࠵ࡸࡺࠧ಑")
						,tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡐࡑࡊࡐࡊࡥࡎࡆ࡙ࡢࡌࡔ࡙ࡔࡏࡃࡐࡉ࠲࠷ࡳࡵࠩಒ")
						,Y41NvKfOroMzGB8sEHy7wbXlc5(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡑࡒࡋࡑࡋ࡟ࡏࡇ࡚ࡣࡍࡕࡓࡕࡐࡄࡑࡊ࠳࠳ࡳࡦࠪಓ")
						,tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡔࡈࡅࡉࡥࡁࡍࡎࡢࡅࡉࡊࡏࡏࡕࡢ࡜ࡒࡒ࠭࠲ࡵࡷࠫಔ")
						,JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡌࡕࡏࡈࡎࡈ࡙ࡘࡋࡒࡄࡑࡑࡘࡊࡔࡔ࠮࠳ࡶࡸࠬಕ")
						,uuExaKGL7UONtevRd(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡈ࡙ࡑࡃࡖࡗࡤࡇࡋࡘࡃࡐࡣࡈࡇࡐࡕࡅࡋࡅ࠲࠹ࡲࡥࠩಖ")
						,jXE2YHkswT8y(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡂ࡚ࡒࡄࡗࡘࡥࡁࡌ࡙ࡄࡑࡤࡉࡁࡑࡖࡆࡌࡆ࠳࠵ࡵࡪࠪಗ")
						,zmcGfOdvAjsELeJlP(u"ࠫࡊࡒࡃࡊࡐࡈࡑࡆ࠳ࡓࡆࡃࡕࡇࡍ࠳࠱ࡴࡶࠪಘ")
						,JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡚ࡖࡌࡆࡘࡉࡏࡉ࠰࠵ࡸࡺࠧಙ")
						,y6y5HtgXO4TkUbwVZ(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡛ࡗࡍࡇࡒࡊࡐࡊ࠱࠷ࡴࡤࠨಚ")
						]
E1BmkjY4ruH0SzlcoTdCPbD3vQ = LJCPyc4vO8t3d+[
				 L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡒࡕࡓ࡝࡟࡟ࡕࡇࡖࡘ࠲࠷ࡳࡵࠩಛ")
				,MgP8OjoaiWQEVG59(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢࡌ࡙࡚ࡐࡔࡒࡕࡓ࡝ࡏࡅࡔ࠯࠴ࡷࡹ࠭ಜ")
				,EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡓࡕࡋࡎࡖࡔࡏࡣ࡜ࡋࡂࡑࡔࡒ࡜ࡎࡋࡓ࠮࠳ࡶࡸࠬಝ")
				,HtK4o2sTPgA78U(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤ࡝ࡅࡃࡒࡕࡓ࡝ࡏࡅࡔ࠯࠵ࡲࡩ࠭ಞ")
				,JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡕࡐࡆࡐࡘࡖࡑࡥࡗࡆࡄࡓࡖࡔ࡞࡙ࡕࡑ࠰࠵ࡸࡺࠧಟ")
				,tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡘࡇࡅࡔࡗࡕࡘ࡚ࡖࡒ࠱࠷ࡴࡤࠨಠ")
				,ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠࡍࡓࡖࡔ࡞࡙ࡄࡑࡐ࠱࠶ࡹࡴࠨಡ")
				,FRYcH4KL7e9gv5pEB(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡑࡓࡉࡓ࡛ࡒࡍࡡࡎࡔࡗࡕࡘ࡚ࡅࡒࡑ࠲࠸࡮ࡥࠩಢ")
				,CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢࡏࡕࡘࡏ࡙࡛ࡆࡓࡒ࠳࠳ࡳࡦࠪಣ")
				,ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡇࡍࡋࡃࡌࡡࡋࡘ࡙ࡖࡓࡠࡒࡕࡓ࡝ࡏࡅࡔ࠯࠴ࡷࡹ࠭ತ")
				,y6y5HtgXO4TkUbwVZ(u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗ࠲ࡎࡔࡕࡒࡖࡣ࡙ࡋࡓࡕ࠯࠴ࡷࡹ࠭ಥ")
				,HtK4o2sTPgA78U(u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠳ࡔࡆࡕࡗࡣࡆࡒࡌࡠ࡙ࡈࡆࡘࡏࡔࡆࡕ࠰࠵ࡸࡺࠧದ")
				,LyNiIHPOwD3hCUYEFM7(u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙࠭ࡕࡇࡖࡘࡤࡇࡌࡍࡡ࡚ࡉࡇ࡙ࡉࡕࡇࡖ࠱࠷ࡴࡤࠨಧ")
				,hhQwbeiNLoqFjX90fB7aG8VAs(u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓ࠮ࡗࡖࡅࡌࡋ࡟ࡓࡇࡓࡓࡗ࡚࠭࠲ࡵࡷࠫನ")
				,hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡉࡒࡓࡌࡒࡅࡠࡖࡕࡅࡓ࡙ࡌࡂࡖࡈ࠱࠶ࡹࡴࠨ಩")
				,UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡕࡉ࡛ࡋࡒࡔࡑࡢࡘࡗࡇࡎࡔࡎࡄࡘࡊ࠳࠱ࡴࡶࠪಪ")
				]
cl6fApKxQTzywM27g = [YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠩ࠻࠲࠽࠴࠸࠯࠺ࠪಫ"),ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠪ࠵࠳࠷࠮࠲࠰࠴ࠫಬ"),TlGXWLYsV1z(u"ࠫ࠶࠴࠰࠯࠲࠱࠵ࠬಭ"),IpC4qHXRuyNFjzWv(u"ࠬ࠾࠮࠹࠰࠷࠲࠹࠭ಮ"),jXE2YHkswT8y(u"࠭࠲࠱࠺࠱࠺࠼࠴࠲࠳࠴࠱࠶࠷࠸ࠧಯ"),tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠧ࠳࠲࠻࠲࠻࠽࠮࠳࠴࠳࠲࠷࠸࠰ࠨರ")]
gZ4LwbKaOm = {
			 hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠨࡃࡋ࡛ࡆࡑࠧಱ")		:[HtK4o2sTPgA78U(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡸ࠴ࡡࡩࡹࡤ࡯ࡹࡼ࠮࡯ࡧࡷࠫಲ")]
			,tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠪࡅࡐࡕࡁࡎࠩಳ")		:[JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧ࡫࠯ࡵࡹ࠳ࡴࡲࡤࠨ಴")]
			,xpT28sXu051(u"ࠬࡇࡋࡘࡃࡐࠫವ")		:[yJeq1BjfiO4NFuwIEzxVLK6b9s(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢ࡭࠱ࡷࡻ࠭ಶ")]
			,XrTw01KtLzbpoyMf(u"ࠧࡂࡍ࡚ࡅࡒ࡚ࡕࡃࡇࠪಷ")	:[IpC4qHXRuyNFjzWv(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡬࠲ࡦࡱࡷࡢ࡯࠱ࡸࡺࡨࡥࠨಸ")]
			,ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠩࡄࡐࡒࡇࡁࡓࡇࡉࠫಹ")		:[PtkEvXAqif14G20QZsaSyT(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡲ࡭ࡢࡣࡵࡩ࡫࠴ࡣࡩࠩ಺")]
			,XrTw01KtLzbpoyMf(u"ࠫࡆࡒࡍࡔࡖࡅࡅࠬ಻")		:[EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡶࡰࡦ࠱ࡥࡱࡳࡳࡵࡤࡤ࠲ࡹࡼ಼ࠧ")]
			,LyNiIHPOwD3hCUYEFM7(u"࠭ࡁࡏࡋࡐࡉ࡟ࡏࡄࠨಽ")		:[yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡱ࡭ࡲ࡫ࡺࡪࡦ࠱ࡷ࡭ࡵࡷࠨಾ")]
			,jXE2YHkswT8y(u"ࠨࡃࡕࡅࡇࡏࡃࡕࡑࡒࡒࡘ࠭ಿ")	:[zmcGfOdvAjsELeJlP(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡡࡳࡣࡥ࡭ࡨ࠳ࡴࡰࡱࡱࡷ࠳ࡩ࡯࡮ࠩೀ")]
			,hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠪࡅࡗࡇࡂࡔࡇࡈࡈࠬು")		:[LyNiIHPOwD3hCUYEFM7(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡲࡢࡤࡶࡩࡪࡪ࠮࡯ࡧࡷࠫೂ")]
			,PtkEvXAqif14G20QZsaSyT(u"ࠬࡇ࡙ࡍࡑࡏࠫೃ")		:[xpT28sXu051(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡧ࠱ࡥࡾࡲ࡯࡭࠰ࡱࡩࡹ࠭ೄ")]
			,TlGXWLYsV1z(u"ࠧࡃࡑࡎࡖࡆ࠭೅")		:[JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡵ࡫ࡳࡴ࡬ࡶࡰࡦ࠱ࡧࡴࡳࠧೆ")]
			,CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠩࡅࡖࡘ࡚ࡅࡋࠩೇ")		:[uuExaKGL7UONtevRd(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡧࡸࡳࡵࡧ࡭࠲ࡨࡵ࡭ࠨೈ")]
			,ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠫࡈࡏࡍࡂ࠶࠳࠴ࠬ೉")		:[SaB5hx3PZwXRLtKgrTfQvId(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡣࡪ࡯ࡤ࠸࠵࠶࠮ࡤࡱࡰࠫೊ")]
			,L90uqo28xEKSFUwYTcm51yRWZIkft(u"࠭ࡃࡊࡏࡄ࠸ࡕ࠭ೋ")		:[GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡥ࡬ࡱࡦ࠺ࡰ࠯ࡥࡲࡱࠬೌ")]
			,sVzojQerUqX(u"ࠨࡅࡌࡑࡆ࠺ࡕࠨ್")		:[yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࠵ࡨ࡯࡭ࡢ࠶ࡸ࠲ࡨࡵ࡭ࠨ೎")]
			,CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠪࡇࡎࡓࡁࡂࡄࡇࡓࠬ೏")		:[vODxLKW5Ql6r4Fbm8(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡩࡩ࡮ࡣ࠶ࡦࡩࡵ࠮ࡤࡱࡰࠫ೐")]
			,PtkEvXAqif14G20QZsaSyT(u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡈࠧ೑")		:[LyNiIHPOwD3hCUYEFM7(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡤ࡫ࡰࡥࡨࡲࡵࡣ࠰ࡺࡥࡹࡩࡨࠨ೒")]
			,hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠧࡄࡋࡐࡅࡈࡒࡕࡃ࡙ࡒࡖࡐ࠭೓")	:[JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡷࡺࡻ࠴ࡣࡪ࡯ࡤࡧࡱࡻࡢ࠯ࡵ࡫ࡳࡵ࠭೔")]
			,tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠩࡆࡍࡒࡇࡆࡂࡐࡖࠫೕ")		:[ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡥ࡬ࡱࡦ࡬ࡡ࡯ࡵ࠱ࡧࡴࡳࠧೖ")]
			,ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠫࡈࡏࡍࡂࡈࡕࡉࡊ࠭೗")		:[ZchUJdM93pTA7zG5(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡣࡪ࡯ࡤࡪࡷ࡫ࡥ࠯ࡸ࡬ࡴࠬ೘")]
			,Y41NvKfOroMzGB8sEHy7wbXlc5(u"࠭ࡃࡊࡏࡄࡐࡎࡍࡈࡕࠩ೙")	:[ZchUJdM93pTA7zG5(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹ࠵࠻࠳ࡳࡹ࠮ࡥ࡬ࡱࡦ࠴࡮ࡦࡶ࠲ࡱࡾࡩ࠱ࠨ೚")]
			,hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠨࡅࡌࡑࡆࡔࡏࡘࠩ೛")		:[Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡧ࡮ࡳࡡ࡯ࡱࡺ࠲ࡨࡩࠧ೜")]
			,zmcGfOdvAjsELeJlP(u"ࠪࡇࡎࡓࡁࡘࡄࡄࡗࠬೝ")		:[XrTw01KtLzbpoyMf(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡩࡩ࡮ࡣࡺࡦࡦࡹ࠮࡮ࡻࡦ࡭ࡲࡧ࠮ࡤࡥࠪೞ")]
			,GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐࠪ೟")	:[y6y5HtgXO4TkUbwVZ(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲ࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯࠰ࡦࡳࡲ࠭ೠ"),hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡩࡵࡥࡵ࡮ࡱ࡭࠰ࡤࡴ࡮࠴ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱ࠲ࡨࡵ࡭ࠨೡ")]
			,YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠨࡆࡕࡅࡒࡇࡃࡂࡈࡈࠫೢ")	:[HtK4o2sTPgA78U(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻ࠷࠻࠮ࡥࡴࡤࡱࡦࡩࡡࡧࡧ࠰ࡸࡻ࠴ࡣࡰ࡯ࠪೣ")]
			,jXE2YHkswT8y(u"ࠪࡈࡗࡇࡍࡂࡕ࠺ࠫ೤")		:[HtK4o2sTPgA78U(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡪࡲࡢ࡯ࡤࡷ࠼࠴࡮ࡦࡶࠪ೥")]
			,Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠷ࠧ೦")		:[zmcGfOdvAjsELeJlP(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦࡩࡼࡦࡪࡹࡴ࠯ࡨࡸࡲࠬ೧")]
			,ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠳ࠩ೨")		:[yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨ࡫ࡾࡨࡥࡴࡶ࠱ࡻࡪࡨࡣࡢ࡯ࠪ೩")]
			,SaB5hx3PZwXRLtKgrTfQvId(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠶ࠫ೪")		:[y6y5HtgXO4TkUbwVZ(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡮࡫ࡧࡺࡤࡨࡷࡹ࠴ࡢࡪࡦࠪ೫")]
			,MgP8OjoaiWQEVG59(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠹࠭೬")		:[Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥࡨࡻ࠰ࡦࡪࡹࡴ࠯ࡰࡨࡸࠬ೭")]
			,CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"࠭ࡅࡈ࡛ࡇࡉࡆࡊࠧ೮")		:[L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡪࡽࡩ࡫ࡡࡥ࠰࡯࡭ࡻ࡫ࠧ೯")]
			,vODxLKW5Ql6r4Fbm8(u"ࠨࡇࡏࡇࡎࡔࡅࡎࡃࠪ೰")		:[hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩࡱࡩࡩ࡯ࡧࡰࡥ࠳ࡩ࡯࡮ࠩೱ")]
			,uuExaKGL7UONtevRd(u"ࠪࡉࡑࡏࡆࡗࡋࡇࡉࡔ࠭ೲ")	:[uuExaKGL7UONtevRd(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹࡨࡢࡪ࡬ࡨ࠳࡫࡬ࡪࡨ࠱ࡲࡪࡽࡳࠨೳ")]
			,tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠬࡌࡁࡃࡔࡄࡏࡆ࠭೴")		:[LyNiIHPOwD3hCUYEFM7(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡧࡣࡥࡶࡰࡧ࠮ࡤࡱࡰࠫ೵")]
			,jXE2YHkswT8y(u"ࠧࡇࡃࡍࡉࡗ࡙ࡈࡐ࡙ࠪ೶")	:[AbqCJZdWQP9j(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡩࡥ࡯࡫ࡲ࠯ࡵ࡫ࡳࡼ࠭೷")]
			,ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠩࡉࡅࡗࡋࡓࡌࡑࠪ೸")		:[vODxLKW5Ql6r4Fbm8(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡻ࡯ࡰ࠯ࡨࡤࡶࡪࡹ࡫ࡰ࠰ࡱࡩࡹ࠭೹")]
			,xpT28sXu051(u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠷࠭೺")		:[GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡࡴ࡮ࡤ࠲࡫ࡧࡳࡦ࡮࡫ࡨ࠳ࡩ࡬ࡰࡷࡧࠫ೻")]
			,XrTw01KtLzbpoyMf(u"࠭ࡆࡐࡕࡗࡅࠬ೼")		:[TlGXWLYsV1z(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺ࡮࠳࡬࡯ࡴࡶࡤ࠱ࡹࡼ࠮࡯ࡧࡷࠫ೽")]
			,IpC4qHXRuyNFjzWv(u"ࠨࡈࡘࡒࡔࡔࡔࡗࠩ೾")		:[SaB5hx3PZwXRLtKgrTfQvId(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡫࠳ࡧ࡬࡮ࡧࡶ࡬ࡰࡧࡨ࠯ࡰࡨࡸࠬ೿")]
			,ZchUJdM93pTA7zG5(u"ࠪࡊ࡚࡙ࡈࡂࡔࡗ࡚ࠬഀ")		:[Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡨ࠮ࡧࡷࡶ࡬ࡦࡸ࠭ࡵࡸ࠱ࡧࡴࡳࠧഁ")]
			,uuExaKGL7UONtevRd(u"ࠬࡌࡕࡔࡊࡄࡖ࡛ࡏࡄࡆࡑࠪം")	:[SaB5hx3PZwXRLtKgrTfQvId(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴ࠰ࡩࡹࡸ࡮ࡡࡳ࠰ࡹ࡭ࡩ࡫࡯ࠨഃ")]
			,SaB5hx3PZwXRLtKgrTfQvId(u"ࠧࡉࡃࡏࡅࡈࡏࡍࡂࠩഄ")		:[ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡫ࡥࡱࡧࡣࡪ࡯ࡤ࠲ࡲ࡫ࡤࡪࡣࠪഅ")]
			,GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠩࡌࡊࡎࡒࡍࠨആ")		:[tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡸ࠮ࡪࡨ࡬ࡰࡲࡺࡶ࠯࡫ࡵࠫഇ"),CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫࡮࠯࡫ࡩ࡭ࡱࡳࡴࡷ࠰࡬ࡶࠬഈ"),ZchUJdM93pTA7zG5(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡦࡢ࠰࡬ࡪ࡮ࡲ࡭ࡵࡸ࠱࡭ࡷ࠭ഉ"),vODxLKW5Ql6r4Fbm8(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡧࡣ࠵࠲࡮࡬ࡩ࡭࡯ࡷࡺ࠳࡯ࡲࠨഊ"),YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠺࠵࠱࠵࠾࠶࠮࠳࠶࠱࠵࠷࠸ࠧഋ")]
			,EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠨࡍࡄࡖࡇࡇࡌࡂࡖ࡙ࠫഌ")	:[uuExaKGL7UONtevRd(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡦࡸࡢࡢ࡮ࡤ࠱ࡹࡼ࠮ࡪࡳࠪ഍")]
			,IpC4qHXRuyNFjzWv(u"ࠪࡏࡆ࡚ࡋࡐࡖࡗ࡚ࠬഎ")		:[Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱࡩࡵ࡭ࡲࡸ࠳ࡩࡡ࡮ࠩഏ")]
			,YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠬࡑࡉࡓࡏࡄࡐࡐ࠭ഐ")		:[MgP8OjoaiWQEVG59(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡷ࠱࡯࡮ࡸ࡭ࡢ࡮࡮࠲ࡨࡵ࡭ࠨ഑")]
			,FRYcH4KL7e9gv5pEB(u"ࠧࡌࡑࡇࡍࡊࡓࡁࡅࡡࡄࡔࡕ࠭ഒ")	:[ZchUJdM93pTA7zG5(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡷ࡭ࡳࡿ࠮ࡤࡥ࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨࠬഓ"),ZchUJdM93pTA7zG5(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳ࠳࠲࠴࠼࠳࡬ࡷࡴ࠰ࡶࡸࡴࡸࡥࠨഔ")]
			,IpC4qHXRuyNFjzWv(u"ࠪࡐࡆࡘࡏ࡛ࡃࠪക")		:[zmcGfOdvAjsELeJlP(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡲࡡࡳࡱࡽࡥ࠳࡯࡮࡬ࠩഖ")]
			,sVzojQerUqX(u"ࠬࡒࡏࡅ࡛ࡑࡉ࡙࠭ഗ")		:[ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡭ࡱࡧࡽࡳ࡫ࡴ࠯࡮࡬ࡲࡰ࠭ഘ")]
			,zmcGfOdvAjsELeJlP(u"ࠧࡎࡃࡖࡅ࡛ࡏࡄࡆࡑࠪങ")	:[tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨࡲ࠳ࡳࡡࡴࡣ࠱ࡲࡪࡽࡳࠨച")]
			,SaB5hx3PZwXRLtKgrTfQvId(u"ࠩࡓࡅࡓࡋࡔࠨഛ")		:[xpT28sXu051(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡻࡼࡽ࠮ࡱࡣࡱࡩࡹ࠴ࡣࡰ࠰࡬ࡰࠬജ")]
			,UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠫࡗࡋࡌࡆࡃࡖࡉࡘ࠭ഝ")		:[XrTw01KtLzbpoyMf(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡵࡸࡶ࡬࡫࠮ࡴࡪ࠲࡯ࡴࡪࡩ࠰ࡧࡰࡥࡩࡥࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷ࠴ࡵ࡬ࡥ࠱࡬ࡲࡩ࡫ࡸ࠯ࡪࡷࡱࡱ࠭ഞ")]
			,ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"࠭ࡓࡆࡔࡌࡉࡘ࡚ࡉࡎࡇࠪട")	:[MgP8OjoaiWQEVG59(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡤࡤ࠲ࡸ࡫ࡲࡪࡧࡶࡸ࡮ࡳࡥ࠯ࡥࡤࡱࠬഠ")]
			,HtK4o2sTPgA78U(u"ࠨࡕࡋࡅࡇࡇࡋࡂࡖ࡜ࠫഡ")	:[JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡧ࡮ࡳࡡࡩࡦ࠱ࡺ࡮ࡶࠧഢ")]
			,tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙ࠬണ")		:[zmcGfOdvAjsELeJlP(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹࡨࡪ࡫ࡧ࠸ࡺ࠴ࡣࡰ࡯ࠪത")]
			,GGx4qyKP1vUtRghsE2WfaHLMXZ(u"࡙ࠬࡈࡂࡊࡌࡈࡓࡋࡗࡔࠩഥ")	:[zmcGfOdvAjsELeJlP(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦ࠰ࡶ࡬࠹ࡻ࠮࡯ࡧࡺࡷࠬദ")]
			,ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠧࡔࡊࡒࡊࡍࡇࠧധ")		:[JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡶ࡬ࡴ࡬ࡨࡢ࠰ࡷࡺࠬന")]
			,jXE2YHkswT8y(u"ࠩࡖࡌࡔࡕࡆࡎࡃ࡛ࠫഩ")		:[LyNiIHPOwD3hCUYEFM7(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸ࡮࡯ࡰࡨࡰࡥࡽ࠴ࡣࡰ࡯ࠪപ"),HtK4o2sTPgA78U(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹࡴࡢࡶ࡬ࡧ࠳ࡹࡨࡰࡱࡩࡱࡦࡾ࠮ࡤࡱࡰࠫഫ"),ZchUJdM93pTA7zG5(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡩࡱࡲࡪࡲࡧࡸ࠯ࡣࡽࡹࡷ࡫ࡥࡥࡩࡨ࠲ࡳ࡫ࡴࠨബ")]
			,EMO8gy4LrsNTh0knZwpSeU75APW(u"࠭ࡓࡉࡑࡒࡊࡓࡋࡔࠨഭ")		:[hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡶ࠲ࡦࡱࡷࡢ࡯࠱ࡸࡺࡨࡥࠨമ")]
			,LyNiIHPOwD3hCUYEFM7(u"ࠨࡖࡌࡏࡆࡇࡔࠨയ")		:[XrTw01KtLzbpoyMf(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡸ࡮ࡱࡡࡢࡶ࠱ࡲࡪࡺࠧര")]
			,YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠪࡘ࡛ࡌࡕࡏࠩറ")		:[tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹ࠮ࡵࡸࡩࡹࡳ࠴࡭ࡦࠩല")]
			,ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠬ࡜ࡁࡓࡄࡒࡒࠬള")		:[yJeq1BjfiO4NFuwIEzxVLK6b9s(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡮࠰ࡹࡥࡷࡨ࡯࡯࠰ࡦࡥࡲ࠭ഴ")]
			,tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠧࡗࡋࡇࡉࡔࡔࡓࡂࡇࡐࠫവ")	:[SaB5hx3PZwXRLtKgrTfQvId(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡹ࡭ࡩ࡫࡯࠯ࡰࡶࡥࡪࡳ࠮࡯ࡧࡷࠫശ")]
			,MgP8OjoaiWQEVG59(u"࡚ࠩࡉࡈࡏࡍࡂ࠳ࠪഷ")		:[Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼ࡫ࡣࡪ࡯ࡤ࠲ࡸ࡮࡯ࡸࠩസ")]
			,XrTw01KtLzbpoyMf(u"ࠫ࡜ࡋࡃࡊࡏࡄ࠶ࠬഹ")		:[vODxLKW5Ql6r4Fbm8(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡦࡥ࡬ࡱࡦ࠴ࡣ࡭࡫ࡦ࡯ࠬഺ")]
			,y6y5HtgXO4TkUbwVZ(u"࡙࠭ࡂࡓࡒࡘ഻ࠬ")		:[MgP8OjoaiWQEVG59(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡻ࠱ࡽࡦࡷ࡯ࡵ࠰ࡷࡺ഼ࠬ")]
			,LyNiIHPOwD3hCUYEFM7(u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩഽ")		:[hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡥࡲࡱࠬാ")]
			,tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠪ࡝࡙ࡈ࡟ࡄࡊࡄࡒࡓࡋࡌࡔࠩി")	:[PtkEvXAqif14G20QZsaSyT(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡧࡴࡳࠧീ")]
			,PtkEvXAqif14G20QZsaSyT(u"ࠬࡏࡐࡕࡘࠪു")			:[ZchUJdM93pTA7zG5(u"࠭ࠧൂ")]
			,PtkEvXAqif14G20QZsaSyT(u"ࠧࡎ࠵ࡘࠫൃ")			:[UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠨࠩൄ")]
			,ZchUJdM93pTA7zG5(u"ࠩࡕࡉࡕࡕࡓࠨ൅")		:[FRYcH4KL7e9gv5pEB(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴࡮ࡦࡶ࡯࡭࡫ࡿ࠮ࡢࡲࡳ࠳ࡐࡕࡄࡊࡔࡈࡔࡔ࠵ࡁࡅࡆࡒࡒࡘ࠵ࡡࡥࡦࡲࡲࡸ࠴ࡸ࡮࡮ࠪെ"),Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮࡯ࡧࡷࡰ࡮࡬ࡹ࠯ࡣࡳࡴ࠴ࡑࡏࡅࡋࡕࡉࡕࡕ࠯ࡂࡆࡇࡓࡓ࡙࠱࠹࠱ࡤࡨࡩࡵ࡮ࡴ࠳࠻࠲ࡽࡳ࡬ࠨേ"),GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡰࡨࡸࡱ࡯ࡦࡺ࠰ࡤࡴࡵ࠵ࡋࡐࡆࡌࡖࡊࡖࡏ࠰ࡃࡇࡈࡔࡔࡓ࠲࠻࠲ࡥࡩࡪ࡯࡯ࡵ࠴࠽࠳ࡾ࡭࡭ࠩൈ")]
			,uuExaKGL7UONtevRd(u"࠭ࡒࡆࡒࡒࡗࡤࡈࡋࡑ࠳ࠪ൉")	:[IpC4qHXRuyNFjzWv(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡩ࡬ࡸ࡭ࡻࡢ࠯ࡥࡲࡱ࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠰ࡍࡒࡈࡎ࠵ࡲࡢࡹ࠲ࡶࡪ࡬ࡳ࠰ࡪࡨࡥࡩࡹ࠯࡮ࡣࡶࡸࡪࡸ࠯ࡂࡆࡇࡓࡓ࡙࠯ࡢࡦࡧࡳࡳࡹ࠮ࡹ࡯࡯ࠫൊ"),JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡪ࡭ࡹ࡮ࡵࡣ࠰ࡦࡳࡲ࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠱ࡎࡓࡉࡏ࠯ࡳࡣࡺ࠳ࡷ࡫ࡦࡴ࠱࡫ࡩࡦࡪࡳ࠰࡯ࡤࡷࡹ࡫ࡲ࠰ࡃࡇࡈࡔࡔࡓ࠲࠺࠲ࡥࡩࡪ࡯࡯ࡵ࠴࠼࠳ࡾ࡭࡭ࠩോ"),AbqCJZdWQP9j(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡫࡮ࡺࡨࡶࡤ࠱ࡧࡴࡳ࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠲ࡏࡔࡊࡉ࠰ࡴࡤࡻ࠴ࡸࡥࡧࡵ࠲࡬ࡪࡧࡤࡴ࠱ࡰࡥࡸࡺࡥࡳ࠱ࡄࡈࡉࡕࡎࡔ࠳࠼࠳ࡦࡪࡤࡰࡰࡶ࠵࠾࠴ࡸ࡮࡮ࠪൌ")]
			,JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠪࡖࡊࡖࡏࡔࡡࡅࡏࡕ࠸്ࠧ")	:[HtK4o2sTPgA78U(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡴࡨࡴࡴ࠴ࡵ࡬࠰ࡷࡳ࠴ࡇࡄࡅࡑࡑࡗ࠴ࡧࡤࡥࡱࡱࡷ࠳ࡾ࡭࡭ࠩൎ"),jXE2YHkswT8y(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡵࡩࡵࡵ࠮ࡶ࡭࠱ࡸࡴ࠵ࡁࡅࡆࡒࡒࡘ࠷࠸࠰ࡣࡧࡨࡴࡴࡳ࠲࠺࠱ࡼࡲࡲࠧ൏"),y6y5HtgXO4TkUbwVZ(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡶࡪࡶ࡯࠯ࡷ࡮࠲ࡹࡵ࠯ࡂࡆࡇࡓࡓ࡙࠱࠺࠱ࡤࡨࡩࡵ࡮ࡴ࠳࠼࠲ࡽࡳ࡬ࠨ൐")]
			,vODxLKW5Ql6r4Fbm8(u"ࠧࡓࡇࡓࡓࡘࡥࡂࡌࡒ࠶ࠫ൑")	:[JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮ࡸࡥࡱࡱ࠱ࡱࡴࡵ࡯࠯ࡥࡲࡱ࠴ࡇࡄࡅࡑࡑࡗ࠴ࡧࡤࡥࡱࡱࡷ࠳ࡾ࡭࡭ࠩ൒"),y6y5HtgXO4TkUbwVZ(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡲࡦࡲࡲ࠲ࡲࡵ࡯ࡰ࠰ࡦࡳࡲ࠵ࡁࡅࡆࡒࡒࡘ࠷࠸࠰ࡣࡧࡨࡴࡴࡳ࠲࠺࠱ࡼࡲࡲࠧ൓"),IpC4qHXRuyNFjzWv(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡳࡧࡳࡳ࠳ࡳ࡯ࡰࡱ࠱ࡧࡴࡳ࠯ࡂࡆࡇࡓࡓ࡙࠱࠺࠱ࡤࡨࡩࡵ࡮ࡴ࠳࠼࠲ࡽࡳ࡬ࠨൔ")]
			,jXE2YHkswT8y(u"ࠫࡘࡕࡕࡓࡅࡈࡗࠬൕ")		:[TlGXWLYsV1z(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠰ࡳࡽࡹ࡮࡯࡯ࡣࡱࡽࡼ࡮ࡥࡳࡧ࠱ࡧࡴࡳ࠯࡬ࡱࡧ࡭ࠬൖ"),GGx4qyKP1vUtRghsE2WfaHLMXZ(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡵࡸࡶ࡬࡫࠮ࡴࡪࠪൗ"),XrTw01KtLzbpoyMf(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡲࡪࡺ࡬ࡪࡨࡼ࠲ࡦࡶࡰ࠰ࡍࡒࡈࡎࡘࡅࡑࡑࠪ൘")]
			}
if YYJQyRskpX8jv:
	gZ4LwbKaOm[JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠨࡒ࡜ࡘࡍࡕࡎࠨ൙")] = [PtkEvXAqif14G20QZsaSyT(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡼࡥࡳࡥࡨࡰ࠳ࡧࡰࡱ࠱࡯࡭ࡸࡺࡰ࡭ࡣࡼࠫ൚"),hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲ࡹࡸࡧࡧࡦࡴࡨࡴࡴࡸࡴࠨ൛"),Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡷࡧࡵࡧࡪࡲ࠮ࡢࡲࡳ࠳ࡸ࡫࡮ࡥࡧࡰࡥ࡮ࡲࠧ൜"),sVzojQerUqX(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡸࡨࡶࡨ࡫࡬࠯ࡣࡳࡴ࠴࡭ࡥࡵ࡯ࡨࡷࡸࡧࡧࡦࡵࠪ൝"),XrTw01KtLzbpoyMf(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵ࡧࡦࡶ࡬ࡷࡱࡧ࡭ࡪࡥࠪ൞"),Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡺࡪࡸࡣࡦ࡮࠱ࡥࡵࡶ࠯ࡨࡧࡷࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ࠭ൟ"),sVzojQerUqX(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡻ࡫ࡲࡤࡧ࡯࠲ࡦࡶࡰ࠰ࡩࡨࡸࡰࡴ࡯ࡸࡰࡨࡶࡷࡵࡲࡴࠩൠ"),hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡼࡥࡳࡥࡨࡰ࠳ࡧࡰࡱ࠱ࡦࡥࡵࡺࡣࡩࡣࠪൡ"),UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲ࡸࡪࡹࡴࡪࡰࡪࠫൢ"),uuExaKGL7UONtevRd(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡷࡧࡵࡧࡪࡲ࠮ࡢࡲࡳ࠳࡬࡫ࡴࡦࡺࡷࡶࡦࡶࡹࡵࡪࡲࡲࡨࡵࡤࡦࠩൣ")]
	gZ4LwbKaOm[yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠬࡖ࡙ࡕࡊࡒࡒࡤࡈࡋࡑ࠳ࠪ൤")] = [y6y5HtgXO4TkUbwVZ(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠱ࡴࡾࡺࡨࡰࡰࡤࡲࡾࡽࡨࡦࡴࡨ࠲ࡨࡵ࡭࠰࡮࡬ࡷࡹࡶ࡬ࡢࡻࠪ൥"),y6y5HtgXO4TkUbwVZ(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠲ࡵࡿࡴࡩࡱࡱࡥࡳࡿࡷࡩࡧࡵࡩ࠳ࡩ࡯࡮࠱ࡸࡷࡦ࡭ࡥࡳࡧࡳࡳࡷࡺࠧ൦"),L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠳ࡶࡹࡵࡪࡲࡲࡦࡴࡹࡸࡪࡨࡶࡪ࠴ࡣࡰ࡯࠲ࡷࡪࡴࡤࡦ࡯ࡤ࡭ࡱ࠭൧"),YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠴ࡰࡺࡶ࡫ࡳࡳࡧ࡮ࡺࡹ࡫ࡩࡷ࡫࠮ࡤࡱࡰ࠳࡬࡫ࡴ࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩ൨"),HtK4o2sTPgA78U(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠮ࡱࡻࡷ࡬ࡴࡴࡡ࡯ࡻࡺ࡬ࡪࡸࡥ࠯ࡥࡲࡱ࠴࡭ࡥࡵ࡫ࡶࡰࡦࡳࡩࡤࠩ൩"),uuExaKGL7UONtevRd(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠯ࡲࡼࡸ࡭ࡵ࡮ࡢࡰࡼࡻ࡭࡫ࡲࡦ࠰ࡦࡳࡲ࠵ࡧࡦࡶࡴࡹࡪࡹࡴࡪࡱࡱࡷࠬ൪"),y6y5HtgXO4TkUbwVZ(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠰ࡳࡽࡹ࡮࡯࡯ࡣࡱࡽࡼ࡮ࡥࡳࡧ࠱ࡧࡴࡳ࠯ࡨࡧࡷ࡯ࡳࡵࡷ࡯ࡧࡵࡶࡴࡸࡳࠨ൫"),FRYcH4KL7e9gv5pEB(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠱ࡴࡾࡺࡨࡰࡰࡤࡲࡾࡽࡨࡦࡴࡨ࠲ࡨࡵ࡭࠰ࡥࡤࡴࡹࡩࡨࡢࠩ൬"),HtK4o2sTPgA78U(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠲ࡵࡿࡴࡩࡱࡱࡥࡳࡿࡷࡩࡧࡵࡩ࠳ࡩ࡯࡮࠱ࡷࡩࡸࡺࡩ࡯ࡩࠪ൭"),uuExaKGL7UONtevRd(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠳ࡶࡹࡵࡪࡲࡲࡦࡴࡹࡸࡪࡨࡶࡪ࠴ࡣࡰ࡯࠲࡫ࡪࡺࡥࡹࡶࡵࡥࡵࡿࡴࡩࡱࡱࡧࡴࡪࡥࠨ൮")]
	gZ4LwbKaOm[TlGXWLYsV1z(u"ࠩࡓ࡝࡙ࡎࡏࡏࡡࡅࡏࡕ࠸ࠧ൯")] = [EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡻ࡫࠯ࡶࡲ࠳ࡱ࡯ࡳࡵࡲ࡯ࡥࡾ࠭൰"),FRYcH4KL7e9gv5pEB(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡵ࡬࠰ࡷࡳ࠴ࡻࡳࡢࡩࡨࡶࡪࡶ࡯ࡳࡶࠪ൱"),TlGXWLYsV1z(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡶ࡭࠱ࡸࡴ࠵ࡳࡦࡰࡧࡩࡲࡧࡩ࡭ࠩ൲"),SaB5hx3PZwXRLtKgrTfQvId(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡷ࡮࠲ࡹࡵ࠯ࡨࡧࡷࡱࡪࡹࡳࡢࡩࡨࡷࠬ൳"),vODxLKW5Ql6r4Fbm8(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡸ࡯࠳ࡺ࡯࠰ࡩࡨࡸ࡮ࡹ࡬ࡢ࡯࡬ࡧࠬ൴"),GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡹࡰ࠴ࡴࡰ࠱ࡪࡩࡹࡷࡵࡦࡵࡷ࡭ࡴࡴࡳࠨ൵"),sVzojQerUqX(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡺࡱ࠮ࡵࡱ࠲࡫ࡪࡺ࡫࡯ࡱࡺࡲࡪࡸࡲࡰࡴࡶࠫ൶"),hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡻ࡫࠯ࡶࡲ࠳ࡨࡧࡰࡵࡥ࡫ࡥࠬ൷"),CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡵ࡬࠰ࡷࡳ࠴ࡺࡥࡴࡶ࡬ࡲ࡬࠭൸"),CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡶ࡭࠱ࡸࡴ࠵ࡧࡦࡶࡨࡼࡹࡸࡡࡱࡻࡷ࡬ࡴࡴࡣࡰࡦࡨࠫ൹")]
	gZ4LwbKaOm[ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"࠭ࡐ࡚ࡖࡋࡓࡓࡥࡂࡌࡒ࠶ࠫൺ")] = [HtK4o2sTPgA78U(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡰࡳࡴࡵ࠮ࡤࡱࡰ࠳ࡱ࡯ࡳࡵࡲ࡯ࡥࡾ࠭ൻ"),jXE2YHkswT8y(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡱࡴࡵ࡯࠯ࡥࡲࡱ࠴ࡻࡳࡢࡩࡨࡶࡪࡶ࡯ࡳࡶࠪർ"),jXE2YHkswT8y(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡲࡵ࡯ࡰ࠰ࡦࡳࡲ࠵ࡳࡦࡰࡧࡩࡲࡧࡩ࡭ࠩൽ"),GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡳ࡯ࡰࡱ࠱ࡧࡴࡳ࠯ࡨࡧࡷࡱࡪࡹࡳࡢࡩࡨࡷࠬൾ"),uuExaKGL7UONtevRd(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴࡭ࡰࡱࡲ࠲ࡨࡵ࡭࠰ࡩࡨࡸ࡮ࡹ࡬ࡢ࡯࡬ࡧࠬൿ"),ZchUJdM93pTA7zG5(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮࡮ࡱࡲࡳ࠳ࡩ࡯࡮࠱ࡪࡩࡹࡷࡵࡦࡵࡷ࡭ࡴࡴࡳࠨ඀"),YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯࡯ࡲࡳࡴ࠴ࡣࡰ࡯࠲࡫ࡪࡺ࡫࡯ࡱࡺࡲࡪࡸࡲࡰࡴࡶࠫඁ"),LyNiIHPOwD3hCUYEFM7(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡰࡳࡴࡵ࠮ࡤࡱࡰ࠳ࡨࡧࡰࡵࡥ࡫ࡥࠬං"),EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡱࡴࡵ࡯࠯ࡥࡲࡱ࠴ࡺࡥࡴࡶ࡬ࡲ࡬࠭ඃ"),ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡲࡵ࡯ࡰ࠰ࡦࡳࡲ࠵ࡧࡦࡶࡨࡼࡹࡸࡡࡱࡻࡷ࡬ࡴࡴࡣࡰࡦࡨࠫ඄")]
else:
	gZ4LwbKaOm[GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠪࡔ࡞࡚ࡈࡐࡐࠪඅ")] = [YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡲࡩࡴࡶࡳࡰࡦࡿࠧආ"),vODxLKW5Ql6r4Fbm8(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡵࡴࡣࡪࡩࡷ࡫ࡰࡰࡴࡷࠫඇ"),ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡴࡧࡱࡨࡪࡳࡡࡪ࡮ࠪඈ"),JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸࡲ࡫ࡳࡴࡣࡪࡩࡸ࠭ඉ"),sVzojQerUqX(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹ࡯ࡳ࡭ࡣࡰ࡭ࡨ࠭ඊ"),HtK4o2sTPgA78U(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺࡱࡶࡧࡶࡸ࡮ࡵ࡮ࡴࠩඋ"),CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴ࡬ࡰࡲࡻࡳ࡫ࡲࡳࡱࡵࡷࠬඌ"),zmcGfOdvAjsELeJlP(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡩࡡࡱࡶࡦ࡬ࡦ࠭ඍ"),yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡴࡦࡵࡷ࡭ࡳ࡭ࠧඎ"),ZchUJdM93pTA7zG5(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷࡩࡽࡺࡲࡢࡲࡼࡸ࡭ࡵ࡮ࡤࡱࡧࡩࠬඏ")]
	gZ4LwbKaOm[y6y5HtgXO4TkUbwVZ(u"ࠧࡑ࡛ࡗࡌࡔࡔ࡟ࡃࡍࡓ࠵ࠬඐ")] = [GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱࡯࡭ࡸࡺࡰ࡭ࡣࡼࠫඑ"),zmcGfOdvAjsELeJlP(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡹࡸࡧࡧࡦࡴࡨࡴࡴࡸࡴࠨඒ"),PtkEvXAqif14G20QZsaSyT(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡸ࡫࡮ࡥࡧࡰࡥ࡮ࡲࠧඓ"),PtkEvXAqif14G20QZsaSyT(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵ࡯ࡨࡷࡸࡧࡧࡦࡵࠪඔ"),IpC4qHXRuyNFjzWv(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶ࡬ࡷࡱࡧ࡭ࡪࡥࠪඕ"),HtK4o2sTPgA78U(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ࠭ඖ"),vODxLKW5Ql6r4Fbm8(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸࡰࡴ࡯ࡸࡰࡨࡶࡷࡵࡲࡴࠩ඗"),CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡦࡥࡵࡺࡣࡩࡣࠪ඘"),jXE2YHkswT8y(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡸࡪࡹࡴࡪࡰࡪࠫ඙"),tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴࡦࡺࡷࡶࡦࡶࡹࡵࡪࡲࡲࡨࡵࡤࡦࠩක")]
	gZ4LwbKaOm[GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠫࡕ࡟ࡔࡉࡑࡑࡣࡇࡑࡐ࠳ࠩඛ")] = [xpT28sXu051(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵࡬ࡪࡵࡷࡴࡱࡧࡹࠨග"),y6y5HtgXO4TkUbwVZ(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡶࡵࡤ࡫ࡪࡸࡥࡱࡱࡵࡸࠬඝ"),GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡵࡨࡲࡩ࡫࡭ࡢ࡫࡯ࠫඞ"),sVzojQerUqX(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹࡳࡥࡴࡵࡤ࡫ࡪࡹࠧඟ"),LyNiIHPOwD3hCUYEFM7(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺࡩࡴ࡮ࡤࡱ࡮ࡩࠧච"),hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴࡲࡷࡨࡷࡹ࡯࡯࡯ࡵࠪඡ"),MgP8OjoaiWQEVG59(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵ࡭ࡱࡳࡼࡴࡥࡳࡴࡲࡶࡸ࠭ජ"),FRYcH4KL7e9gv5pEB(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡣࡢࡲࡷࡧ࡭ࡧࠧඣ"),sVzojQerUqX(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡵࡧࡶࡸ࡮ࡴࡧࠨඤ"),YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸࡪࡾࡴࡳࡣࡳࡽࡹ࡮࡯࡯ࡥࡲࡨࡪ࠭ඥ")]
	gZ4LwbKaOm[MgP8OjoaiWQEVG59(u"ࠨࡒ࡜ࡘࡍࡕࡎࡠࡄࡎࡔ࠸࠭ඦ")] = [XrTw01KtLzbpoyMf(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡰ࡮ࡹࡴࡱ࡮ࡤࡽࠬට"),ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡺࡹࡡࡨࡧࡵࡩࡵࡵࡲࡵࠩඨ"),tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡹࡥ࡯ࡦࡨࡱࡦ࡯࡬ࠨඩ"),xpT28sXu051(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶࡰࡩࡸࡹࡡࡨࡧࡶࠫඪ"),UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷ࡭ࡸࡲࡡ࡮࡫ࡦࠫණ"),XrTw01KtLzbpoyMf(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸࡶࡻࡥࡴࡶ࡬ࡳࡳࡹࠧඬ"),uuExaKGL7UONtevRd(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹࡱ࡮ࡰࡹࡱࡩࡷࡸ࡯ࡳࡵࠪත"),JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡧࡦࡶࡴࡤࡪࡤࠫථ"),SaB5hx3PZwXRLtKgrTfQvId(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡹ࡫ࡳࡵ࡫ࡱ࡫ࠬද"),CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵࡧࡻࡸࡷࡧࡰࡺࡶ࡫ࡳࡳࡩ࡯ࡥࡧࠪධ")]
bjiw4aZJOKMtpkrAFWug0vx3LNd2Ec = [EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠬࡒࡉࡔࡖࡓࡐࡆ࡟ࠧන"),HtK4o2sTPgA78U(u"࠭ࡒࡆࡒࡒࡖ࡙࡙ࠧ඲"),LyNiIHPOwD3hCUYEFM7(u"ࠧࡆࡏࡄࡍࡑ࡙ࠧඳ"),hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠨࡏࡈࡗࡘࡇࡇࡆࡕࠪප"),CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠩࡌࡗࡑࡇࡍࡊࡅࡖࠫඵ"),GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠪࡕ࡚ࡋࡓࡕࡋࡒࡒࡘ࠭බ"),L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠫࡐࡔࡏࡘࡐࡈࡖࡗࡕࡒࡔࠩභ"),jXE2YHkswT8y(u"ࠬࡉࡁࡑࡖࡆࡌࡆ࠭ම"),UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"࠭ࡔࡆࡕࡗࡍࡓࡍࠧඹ"),ZchUJdM93pTA7zG5(u"ࠧࡆ࡚ࡗࡖࡆࡖ࡙ࡕࡊࡒࡒࡈࡕࡄࡆࠩය")]
gsteZDpHaMmyQkBwC = [UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠨࡃࡇࡈࡔࡔࡓࠨර"),PtkEvXAqif14G20QZsaSyT(u"ࠩࡄࡈࡉࡕࡎࡔ࠳࠻ࠫ඼"),ZchUJdM93pTA7zG5(u"ࠪࡅࡉࡊࡏࡏࡕ࠴࠽ࠬල")]
class YhUSm4KqOHBXnC9LdJsPg8(wiNkogLdpnA):
	def __init__(k8BA0layVWnJ4De36HNSd2,*aargs,**kkwargs):
		k8BA0layVWnJ4De36HNSd2.choiceID = -YYJQyRskpX8jv
	def onClick(k8BA0layVWnJ4De36HNSd2,pKN02F4EBk):
		if pKN02F4EBk>=uuExaKGL7UONtevRd(u"࠾࠶࠱࠱Ꮓ"): k8BA0layVWnJ4De36HNSd2.choiceID = pKN02F4EBk-uuExaKGL7UONtevRd(u"࠾࠶࠱࠱Ꮓ")
		k8BA0layVWnJ4De36HNSd2.fwzulK4roX3tcZ7J2Fxbh()
	def jz3MNyZsDYvpkVufaJdI2bS6CUw(k8BA0layVWnJ4De36HNSd2,*aargs):
		k8BA0layVWnJ4De36HNSd2.button0,k8BA0layVWnJ4De36HNSd2.button1,k8BA0layVWnJ4De36HNSd2.button2 = aargs[FGTfwsjNrB8DvKSZhLIQAb1JnO],aargs[YYJQyRskpX8jv],aargs[nI2JK1RfsGWNY3OarEeMQZ]
		k8BA0layVWnJ4De36HNSd2.header,k8BA0layVWnJ4De36HNSd2.text = aargs[iiCWLaJREureAlOkv],aargs[pZWli1xqfVtvzuSU6ImNw53gBFsh]
		k8BA0layVWnJ4De36HNSd2.profile,k8BA0layVWnJ4De36HNSd2.direction = aargs[XrTw01KtLzbpoyMf(u"࠻Ꮔ")],aargs[JZszNnIEMAx28Yao0yqhiXGKOPb(u"࠶Ꮕ")]
		k8BA0layVWnJ4De36HNSd2.buttonstimeout,k8BA0layVWnJ4De36HNSd2.closetimeout = aargs[CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"࠹Ꮗ")],aargs[GGx4qyKP1vUtRghsE2WfaHLMXZ(u"࠹Ꮖ")]
		if k8BA0layVWnJ4De36HNSd2.buttonstimeout>FGTfwsjNrB8DvKSZhLIQAb1JnO or k8BA0layVWnJ4De36HNSd2.closetimeout>hhQwbeiNLoqFjX90fB7aG8VAs(u"࠳Ꮘ"): k8BA0layVWnJ4De36HNSd2.enable_progressbar = rGPen6cSMHQkAywh8vqI9JXiD2
		else: k8BA0layVWnJ4De36HNSd2.enable_progressbar = BF6QAiLUNHh7rKOugaw
		k8BA0layVWnJ4De36HNSd2.image_filename = PuhkKlL5mRz.replace(HtK4o2sTPgA78U(u"ࠫࡤ࠶࠰࠱࠲ࡢࠫ඾"),EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠬࡥࠧ඿")+str(X2cQ5NCPvkMieBW7oASspFjE.time())+xpT28sXu051(u"࠭࡟ࠨව"))
		k8BA0layVWnJ4De36HNSd2.image_filename = k8BA0layVWnJ4De36HNSd2.image_filename.replace(FRYcH4KL7e9gv5pEB(u"ࠧ࡝࡞ࠪශ"),yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠨ࡞࡟ࡠࡡ࠭ෂ")).replace(tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠩ࠲࠳ࠬස"),hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠪ࠳࠴࠵࠯ࠨහ"))
		k8BA0layVWnJ4De36HNSd2.image_height = XV4nFRGIpg971ukM(k8BA0layVWnJ4De36HNSd2.button0,k8BA0layVWnJ4De36HNSd2.button1,k8BA0layVWnJ4De36HNSd2.button2,k8BA0layVWnJ4De36HNSd2.header,k8BA0layVWnJ4De36HNSd2.text,k8BA0layVWnJ4De36HNSd2.profile,k8BA0layVWnJ4De36HNSd2.direction,k8BA0layVWnJ4De36HNSd2.enable_progressbar,k8BA0layVWnJ4De36HNSd2.image_filename)
		k8BA0layVWnJ4De36HNSd2.show()
		k8BA0layVWnJ4De36HNSd2.getControl(YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"࠽࠵࠻࠰Ꮙ")).setImage(k8BA0layVWnJ4De36HNSd2.image_filename)
		k8BA0layVWnJ4De36HNSd2.getControl(AbqCJZdWQP9j(u"࠾࠶࠵࠱Ꮚ")).setHeight(k8BA0layVWnJ4De36HNSd2.image_height)
		if not k8BA0layVWnJ4De36HNSd2.button1 and k8BA0layVWnJ4De36HNSd2.button0 and k8BA0layVWnJ4De36HNSd2.button2: k8BA0layVWnJ4De36HNSd2.getControl(tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"࠹࠱࠳࠵Ꮜ")).setPosition(-hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"࠳࠴࠳Ꮝ"),MgP8OjoaiWQEVG59(u"࠶Ꮛ"))
		return k8BA0layVWnJ4De36HNSd2.image_filename,k8BA0layVWnJ4De36HNSd2.image_height
	def ReC12DmhyZbP7Nd4XnJl(k8BA0layVWnJ4De36HNSd2):
		if k8BA0layVWnJ4De36HNSd2.buttonstimeout:
			k8BA0layVWnJ4De36HNSd2.th1 = EEehSFDLdpKBR3W1ga9PxrV.Thread(target=k8BA0layVWnJ4De36HNSd2.GNO2sTfRuJ5BYEqDbxiFIAPHeaZ,args=())
			k8BA0layVWnJ4De36HNSd2.th1.start()
		else: k8BA0layVWnJ4De36HNSd2.lBE6XhR8CYsfj()
	def GNO2sTfRuJ5BYEqDbxiFIAPHeaZ(k8BA0layVWnJ4De36HNSd2):
		k8BA0layVWnJ4De36HNSd2.getControl(ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"࠻࠳࠶࠵Ꮞ")).setEnabled(rGPen6cSMHQkAywh8vqI9JXiD2)
		for o6oXFxmE1bQC in range(YYJQyRskpX8jv,k8BA0layVWnJ4De36HNSd2.buttonstimeout+YYJQyRskpX8jv):
			X2cQ5NCPvkMieBW7oASspFjE.sleep(YYJQyRskpX8jv)
			CYlOp1huALMwdfomHj0P9ys8K = int(CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"࠴࠴࠵Ꮟ")*o6oXFxmE1bQC/k8BA0layVWnJ4De36HNSd2.buttonstimeout)
			k8BA0layVWnJ4De36HNSd2.jHm7JdWbY9FNAiMEncokuBG8(CYlOp1huALMwdfomHj0P9ys8K)
			if k8BA0layVWnJ4De36HNSd2.choiceID>CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"࠴Ꮠ"): break
		k8BA0layVWnJ4De36HNSd2.lBE6XhR8CYsfj()
	def laqQ5XZrjJhxM1EUbWB(k8BA0layVWnJ4De36HNSd2):
		if k8BA0layVWnJ4De36HNSd2.closetimeout:
			k8BA0layVWnJ4De36HNSd2.th2 = EEehSFDLdpKBR3W1ga9PxrV.Thread(target=k8BA0layVWnJ4De36HNSd2.VN7ORtfEbPG5j1BkpcMiSm,args=())
			k8BA0layVWnJ4De36HNSd2.th2.start()
		else: k8BA0layVWnJ4De36HNSd2.lBE6XhR8CYsfj()
	def VN7ORtfEbPG5j1BkpcMiSm(k8BA0layVWnJ4De36HNSd2):
		k8BA0layVWnJ4De36HNSd2.getControl(y6y5HtgXO4TkUbwVZ(u"࠾࠶࠲࠱Ꮡ")).setEnabled(rGPen6cSMHQkAywh8vqI9JXiD2)
		X2cQ5NCPvkMieBW7oASspFjE.sleep(k8BA0layVWnJ4De36HNSd2.buttonstimeout)
		for o6oXFxmE1bQC in range(k8BA0layVWnJ4De36HNSd2.closetimeout-YYJQyRskpX8jv,-YYJQyRskpX8jv,-YYJQyRskpX8jv):
			X2cQ5NCPvkMieBW7oASspFjE.sleep(YYJQyRskpX8jv)
			CYlOp1huALMwdfomHj0P9ys8K = int(GGx4qyKP1vUtRghsE2WfaHLMXZ(u"࠷࠰࠱Ꮢ")*o6oXFxmE1bQC/k8BA0layVWnJ4De36HNSd2.closetimeout)
			k8BA0layVWnJ4De36HNSd2.jHm7JdWbY9FNAiMEncokuBG8(CYlOp1huALMwdfomHj0P9ys8K)
			if k8BA0layVWnJ4De36HNSd2.choiceID>FGTfwsjNrB8DvKSZhLIQAb1JnO: break
		if k8BA0layVWnJ4De36HNSd2.closetimeout>FGTfwsjNrB8DvKSZhLIQAb1JnO: k8BA0layVWnJ4De36HNSd2.choiceID = EMO8gy4LrsNTh0knZwpSeU75APW(u"࠱࠱Ꮣ")
		k8BA0layVWnJ4De36HNSd2.fwzulK4roX3tcZ7J2Fxbh()
	def jHm7JdWbY9FNAiMEncokuBG8(k8BA0layVWnJ4De36HNSd2,CYlOp1huALMwdfomHj0P9ys8K):
		k8BA0layVWnJ4De36HNSd2.precent = CYlOp1huALMwdfomHj0P9ys8K
		k8BA0layVWnJ4De36HNSd2.getControl(CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"࠺࠲࠵࠴Ꮤ")).setPercent(k8BA0layVWnJ4De36HNSd2.precent)
	def lBE6XhR8CYsfj(k8BA0layVWnJ4De36HNSd2):
		if k8BA0layVWnJ4De36HNSd2.button0: k8BA0layVWnJ4De36HNSd2.getControl(ZchUJdM93pTA7zG5(u"࠻࠳࠵࠵Ꮥ")).setEnabled(rGPen6cSMHQkAywh8vqI9JXiD2)
		if k8BA0layVWnJ4De36HNSd2.button1: k8BA0layVWnJ4De36HNSd2.getControl(xpT28sXu051(u"࠼࠴࠶࠷Ꮦ")).setEnabled(rGPen6cSMHQkAywh8vqI9JXiD2)
		if k8BA0layVWnJ4De36HNSd2.button2: k8BA0layVWnJ4De36HNSd2.getControl(YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"࠽࠵࠷࠲Ꮧ")).setEnabled(rGPen6cSMHQkAywh8vqI9JXiD2)
	def fwzulK4roX3tcZ7J2Fxbh(k8BA0layVWnJ4De36HNSd2):
		k8BA0layVWnJ4De36HNSd2.close()
		try: wkMR5x1gTWEQIc6qHCa.remove(k8BA0layVWnJ4De36HNSd2.image_filename)
		except: pass
class tIvpmRVh8Z0lHS9sk4ECg6Ni5PeDWJ():
	def __init__(k8BA0layVWnJ4De36HNSd2,showDialogs=BF6QAiLUNHh7rKOugaw,logErrors=rGPen6cSMHQkAywh8vqI9JXiD2):
		k8BA0layVWnJ4De36HNSd2.showDialogs = showDialogs
		k8BA0layVWnJ4De36HNSd2.logErrors = logErrors
		k8BA0layVWnJ4De36HNSd2.finishedLIST,k8BA0layVWnJ4De36HNSd2.failedLIST = [],[]
		k8BA0layVWnJ4De36HNSd2.statusDICT,k8BA0layVWnJ4De36HNSd2.resultsDICT = {},{}
		k8BA0layVWnJ4De36HNSd2.processesLIST = []
		k8BA0layVWnJ4De36HNSd2.starttimeDICT,k8BA0layVWnJ4De36HNSd2.finishtimeDICT,k8BA0layVWnJ4De36HNSd2.elpasedtimeDICT = {},{},{}
	def xrm0JkzUa3IQfKZ(k8BA0layVWnJ4De36HNSd2,Tj2xuNbqyrLMeoaYJB7Sh3IiU,M4hIvdynPzxGj1WFBfA5p,*aargs):
		Tj2xuNbqyrLMeoaYJB7Sh3IiU = str(Tj2xuNbqyrLMeoaYJB7Sh3IiU)
		k8BA0layVWnJ4De36HNSd2.statusDICT[Tj2xuNbqyrLMeoaYJB7Sh3IiU] = HtK4o2sTPgA78U(u"ࠫࡷࡻ࡮࡯࡫ࡱ࡫ࠬළ")
		if k8BA0layVWnJ4De36HNSd2.showDialogs: YYkhEn5xTXLUevzCVNB16mR(iiy37aKq0pCEIOwfcTh61xb4U,Tj2xuNbqyrLMeoaYJB7Sh3IiU)
		sj246WXRZ1QPchEB7l8V = EEehSFDLdpKBR3W1ga9PxrV.Thread(target=k8BA0layVWnJ4De36HNSd2.LHQxKTz4uJDOZ1hdlBF9U0,args=(Tj2xuNbqyrLMeoaYJB7Sh3IiU,M4hIvdynPzxGj1WFBfA5p,aargs))
		k8BA0layVWnJ4De36HNSd2.processesLIST.append(sj246WXRZ1QPchEB7l8V)
		return sj246WXRZ1QPchEB7l8V
	def ztvP0T59IiMp61VJmf7(k8BA0layVWnJ4De36HNSd2,Tj2xuNbqyrLMeoaYJB7Sh3IiU,M4hIvdynPzxGj1WFBfA5p,*aargs):
		sj246WXRZ1QPchEB7l8V = k8BA0layVWnJ4De36HNSd2.xrm0JkzUa3IQfKZ(Tj2xuNbqyrLMeoaYJB7Sh3IiU,M4hIvdynPzxGj1WFBfA5p,*aargs)
		sj246WXRZ1QPchEB7l8V.start()
	def LHQxKTz4uJDOZ1hdlBF9U0(k8BA0layVWnJ4De36HNSd2,Tj2xuNbqyrLMeoaYJB7Sh3IiU,M4hIvdynPzxGj1WFBfA5p,aargs):
		Tj2xuNbqyrLMeoaYJB7Sh3IiU = str(Tj2xuNbqyrLMeoaYJB7Sh3IiU)
		k8BA0layVWnJ4De36HNSd2.starttimeDICT[Tj2xuNbqyrLMeoaYJB7Sh3IiU] = X2cQ5NCPvkMieBW7oASspFjE.time()
		try:
			k8BA0layVWnJ4De36HNSd2.resultsDICT[Tj2xuNbqyrLMeoaYJB7Sh3IiU] = M4hIvdynPzxGj1WFBfA5p(*aargs)
			if ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠬࡕࡐࡆࡐࡘࡖࡑ࠭ෆ") in str(M4hIvdynPzxGj1WFBfA5p) and not k8BA0layVWnJ4De36HNSd2.resultsDICT[Tj2xuNbqyrLMeoaYJB7Sh3IiU].succeeded: KEPGn8jNAtmDB2yS0kZiX4MCw()
			k8BA0layVWnJ4De36HNSd2.finishedLIST.append(Tj2xuNbqyrLMeoaYJB7Sh3IiU)
			k8BA0layVWnJ4De36HNSd2.statusDICT[Tj2xuNbqyrLMeoaYJB7Sh3IiU] = ZchUJdM93pTA7zG5(u"࠭ࡦࡪࡰ࡬ࡷ࡭࡫ࡤࠨ෇")
		except Exception as GklR5ZezV83FJXKnCr6AaT:
			if k8BA0layVWnJ4De36HNSd2.logErrors:
				UIxuCn8wAWpgz5j9EdqFvreH = xiFBCH5hcJks.format_exc()
				if UIxuCn8wAWpgz5j9EdqFvreH!=ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠧࡏࡱࡱࡩ࡙ࡿࡰࡦ࠼ࠣࡒࡴࡴࡥ࡝ࡰࠪ෈"): ytv0YaxDcRINurplWKg587Pwqz.stderr.write(UIxuCn8wAWpgz5j9EdqFvreH)
			k8BA0layVWnJ4De36HNSd2.failedLIST.append(Tj2xuNbqyrLMeoaYJB7Sh3IiU)
			k8BA0layVWnJ4De36HNSd2.statusDICT[Tj2xuNbqyrLMeoaYJB7Sh3IiU] = tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨ෉")
		k8BA0layVWnJ4De36HNSd2.finishtimeDICT[Tj2xuNbqyrLMeoaYJB7Sh3IiU] = X2cQ5NCPvkMieBW7oASspFjE.time()
		k8BA0layVWnJ4De36HNSd2.elpasedtimeDICT[Tj2xuNbqyrLMeoaYJB7Sh3IiU] = k8BA0layVWnJ4De36HNSd2.finishtimeDICT[Tj2xuNbqyrLMeoaYJB7Sh3IiU] - k8BA0layVWnJ4De36HNSd2.starttimeDICT[Tj2xuNbqyrLMeoaYJB7Sh3IiU]
	def vP7SpKieY3rsuJ02X(k8BA0layVWnJ4De36HNSd2):
		for qng0R2QYioPpLydJV5GNKj7vur in k8BA0layVWnJ4De36HNSd2.processesLIST:
			qng0R2QYioPpLydJV5GNKj7vur.start()
	def h9hJBOE2PyG6M8U0AVQIlkLqvpi(k8BA0layVWnJ4De36HNSd2):
		while AbqCJZdWQP9j(u"ࠩࡵࡹࡳࡴࡩ࡯ࡩ්ࠪ") in list(k8BA0layVWnJ4De36HNSd2.statusDICT.values()): X2cQ5NCPvkMieBW7oASspFjE.sleep(jXE2YHkswT8y(u"࠶Ꮨ"))
def IkwAF5TXvNLOsU9iQmcVKESdu():
	if not UYetvipxsyObLZaMw3WVdAgCFEh: return hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠪࡒࡔࡥࡕࡑࡆࡄࡘࡊ࠭෋")
	tG9iKqnZEs1CgWRpa6z = YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠫࡋ࡛ࡌࡍࡡࡘࡔࡉࡇࡔࡆࠩ෌")
	R42CVaGOcYqD1dznwoQeAFligfXJ0 = [Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠬ࠾࠮࠶࠰࠳ࠫ෍"),MgP8OjoaiWQEVG59(u"࠭࠲࠱࠴࠴࠲࠶࠶࠮࠲࠻ࠪ෎"),UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠧ࠳࠲࠵࠵࠳࠷࠱࠯࠴࠷ࡥࠬා"),FRYcH4KL7e9gv5pEB(u"ࠨ࠴࠳࠶࠶࠴࠱࠳࠰࠶࠴ࠬැ"),UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠩ࠵࠴࠷࠸࠮࠱࠴࠱࠴࠷࠭ෑ"),GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠪ࠶࠵࠸࠲࠯࠳࠳࠲࠷࠸ࠧි"),y6y5HtgXO4TkUbwVZ(u"ࠫ࠷࠶࠲࠴࠰࠳࠷࠳࠶࠶ࠨී"),y6y5HtgXO4TkUbwVZ(u"ࠬ࠸࠰࠳࠵࠱࠴࠺࠴࠱࠷ࠩු"),YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"࠭࠲࠱࠴࠶࠲࠵࠼࠮࠱࠸ࠪ෕"),EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠧ࠳࠲࠵࠷࠳࠷࠰࠯࠴࠻ࠫූ"),ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠨ࠴࠳࠶࠹࠴࠰࠲࠰࠴࠸ࠬ෗"),hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠩ࠵࠴࠷࠺࠮࠱࠹࠱࠶࠵࠭ෘ")]
	WWNoQrEbLahnCxRfSj5GZmPM7HXu = R42CVaGOcYqD1dznwoQeAFligfXJ0[-YYJQyRskpX8jv]
	OYCQpVgr0S2wuc3 = o0e6QJ2iBPmfR1pLAMEqz8l(WWNoQrEbLahnCxRfSj5GZmPM7HXu)
	vt2pPxEiYd40DKmu1BRXbOUoaJreQ = o0e6QJ2iBPmfR1pLAMEqz8l(DdAjF5pBNL9IqPgkz0xhcQEfU)
	if vt2pPxEiYd40DKmu1BRXbOUoaJreQ>OYCQpVgr0S2wuc3:
		tG9iKqnZEs1CgWRpa6z = ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠪࡗࡎࡓࡐࡍࡇࡢ࡙ࡕࡊࡁࡕࡇࠪෙ")
	return tG9iKqnZEs1CgWRpa6z
def Hm64zKwvF2toSZVG8dprJDkXCTncf():
	for j4ZIlrBtDAXGEWmLu2VQSs8e5wy7,pLCYwde0WgycRiMu1Xm82Pro7jTx,frKzDoxVINlL397S in wkMR5x1gTWEQIc6qHCa.walk(yBIA5N98RmP7pdzeS3s0gOH,topdown=BF6QAiLUNHh7rKOugaw):
		if len(frKzDoxVINlL397S)>YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"࠻࠰࠱Ꮩ"): TAkeulImazNdJwE9(j4ZIlrBtDAXGEWmLu2VQSs8e5wy7,BF6QAiLUNHh7rKOugaw,BF6QAiLUNHh7rKOugaw)
	return
def kqAyL0F4bUcl1svBPn(iQ2tN1nLmJH7GCchv4u0VoSKlb):
	if LyNiIHPOwD3hCUYEFM7(u"ࠫࡊ࡞ࡔࡓࡃࡓ࡝࡙ࡎࡏࡏࡅࡒࡈࡊ࠭ේ") in str(RR80SbLUCimJrMV): return
	ENsZOjlzJvcgAXDo963LrP = iiy37aKq0pCEIOwfcTh61xb4U
	if iQ2tN1nLmJH7GCchv4u0VoSKlb: ENsZOjlzJvcgAXDo963LrP = QKzCiBOWZus1nSv(PdkZHNBlpg2b7DmX6qRiyVa,hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠬࡹࡴࡳࠩෛ"),ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩො"),ZchUJdM93pTA7zG5(u"ࠧࡆ࡚ࡗࡖࡆࡖ࡙ࡕࡊࡒࡒࡈࡕࡄࡆࠩෝ"))
	global gZ4LwbKaOm,eeA3KYiN75JumQrEIdZw4XVp,KBCco4GTRUp1a,TPFpytsjLd57U
	if not ENsZOjlzJvcgAXDo963LrP:
		smglbwR7x2oM = gZ4LwbKaOm[ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠨࡒ࡜ࡘࡍࡕࡎࠨෞ")][JZszNnIEMAx28Yao0yqhiXGKOPb(u"࠹Ꮪ")]
		nT4CcjPoyq1NWYeDSrgkJxB0F2tHp = {Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠩࡸࡷࡪࡸࠧෟ"):iw3BpJl1Y9tbg8XMR4VeoS6kEUhf,IpC4qHXRuyNFjzWv(u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫ෠"):DdAjF5pBNL9IqPgkz0xhcQEfU}
		VVznOTKE7NDIe0HGkg = MMCJxEfv0WUek(hI7SkXd94fFzAHNZCQoMqEutbnWP,hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠫࡕࡕࡓࡕࠩ෡"),smglbwR7x2oM,nT4CcjPoyq1NWYeDSrgkJxB0F2tHp,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡅ࡙ࡖࡕࡅࡤࡖ࡙ࡕࡊࡒࡒࡤࡉࡏࡅࡇ࠰࠵ࡸࡺࠧ෢"))
		if VVznOTKE7NDIe0HGkg.succeeded:
			ENsZOjlzJvcgAXDo963LrP = VVznOTKE7NDIe0HGkg.content
			YMQXP2BGeK86CEb(PdkZHNBlpg2b7DmX6qRiyVa,EMO8gy4LrsNTh0knZwpSeU75APW(u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩ෣"),SaB5hx3PZwXRLtKgrTfQvId(u"ࠧࡆ࡚ࡗࡖࡆࡖ࡙ࡕࡊࡒࡒࡈࡕࡄࡆࠩ෤"),ENsZOjlzJvcgAXDo963LrP,VaeMF1mIjQ5iLtfGcB)
	if ENsZOjlzJvcgAXDo963LrP:
		global NEW_SITESURLS,NEW_BADSCRAPERS,NEW_BADWEBSITES,l4LkuxdgVajRcfS2HB73zQPiD
		global j5q8z4HT3cfhvK,uXtbUqcMdTFICQjGY7a63em,bhCnG4zQdj
		NEW_SITESURLS,l4LkuxdgVajRcfS2HB73zQPiD,NEW_BADSCRAPERS,NEW_BADWEBSITES = {},[],[],{}
		exec(ENsZOjlzJvcgAXDo963LrP,globals(),locals())
		gZ4LwbKaOm.update(NEW_SITESURLS)
		eeA3KYiN75JumQrEIdZw4XVp = list(set(eeA3KYiN75JumQrEIdZw4XVp+NEW_BADSCRAPERS))
		TPFpytsjLd57U = list(set(TPFpytsjLd57U+l4LkuxdgVajRcfS2HB73zQPiD))
		if DdAjF5pBNL9IqPgkz0xhcQEfU in list(NEW_BADWEBSITES.keys()): KBCco4GTRUp1a += NEW_BADWEBSITES[DdAjF5pBNL9IqPgkz0xhcQEfU]
		for ekEOd3mqAThaBDUoIrntuGRjYW in KBCco4GTRUp1a:
			if ekEOd3mqAThaBDUoIrntuGRjYW in j5q8z4HT3cfhvK: j5q8z4HT3cfhvK.remove(ekEOd3mqAThaBDUoIrntuGRjYW)
			if ekEOd3mqAThaBDUoIrntuGRjYW in uXtbUqcMdTFICQjGY7a63em: uXtbUqcMdTFICQjGY7a63em.remove(ekEOd3mqAThaBDUoIrntuGRjYW)
			if ekEOd3mqAThaBDUoIrntuGRjYW in bhCnG4zQdj: bhCnG4zQdj.remove(ekEOd3mqAThaBDUoIrntuGRjYW)
	return
def YHtkW17DjvoCaMs():
	try: wkMR5x1gTWEQIc6qHCa.makedirs(StqmrCIJX4T623w5j9NEonxfQ)
	except: pass
	eX2iI1vRsQUGJOnwq6 = IkwAF5TXvNLOsU9iQmcVKESdu()
	if eX2iI1vRsQUGJOnwq6==xpT28sXu051(u"ࠨࡕࡌࡑࡕࡒࡅࡠࡗࡓࡈࡆ࡚ࡅࠨ෥"): WKquk5EaNr4RzVf(q1rohYuwnfpVZUa98L2CtQzmAcB,yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠩ࠱ࡠࡹࡇࡲࡢࡤ࡬ࡧ࡛࡯ࡤࡦࡱࡶࠤ࡚ࡶࡤࡢࡶࡨࠤ࡙ࡿࡰࡦ࠼ࠣࠤࡘࡏࡍࡑࡎࡈࠤ࡚ࡖࡄࡂࡖࡈࠤࠥࠦࡐࡢࡶ࡫࠾ࠥࡡࠠࠨ෦")+CzWIqm1YAcEa9gTSZ30fk27+jXE2YHkswT8y(u"ࠪࠤࡢ࠭෧"))
	else: WKquk5EaNr4RzVf(q1rohYuwnfpVZUa98L2CtQzmAcB,L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠫ࠳ࡢࡴࡂࡴࡤࡦ࡮ࡩࡖࡪࡦࡨࡳࡸࠦࡕࡱࡦࡤࡸࡪࠦࡔࡺࡲࡨ࠾ࠥࠦࡆࡖࡎࡏࠤ࡚ࡖࡄࡂࡖࡈࠤࠥࠦࡐࡢࡶ࡫࠾ࠥࡡࠠࠨ෨")+CzWIqm1YAcEa9gTSZ30fk27+PtkEvXAqif14G20QZsaSyT(u"ࠬࠦ࡝ࠨ෩"))
	bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,y6y5HtgXO4TkUbwVZ(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ෪"),UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠧห็ࠣฮาี๊ฬࠢส่อืๆศ็ฯࠤๆ๐ࠠอ้สึ่ࡢ࡮ฦๆ์ࠤฬ๊ลึัสีࠥืโๆ࠼࡟ࡲࡡࡴࠧ෫")+DdAjF5pBNL9IqPgkz0xhcQEfU)
	bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ෬"),ZchUJdM93pTA7zG5(u"ࠩอ้ࠥะหษ์อࠤศ๎ࠠหฯา๎ะࠦวๅวุำฬืࠠศๆฯำ๏ีࠠๅสิ๊ฬ๋ฬࠡษ็ๅ๏ี๊้้สฮࠥอไฺำห๎ฮࠦ࠮ࠡล๋ࠤฯ๋ࠠๆีะࠤ่อิࠡษ็ฬึ์วๆฮࠣࡠࡳࡢ࡮ࠡีํๆํ๋ࠠศๆล๊ࠥอไษำ้ห๊าࠠษส฼ฺࠥอไโฯู๋ฬะࠠๅุ่หู๋ࠦๆๆࠣห้ฮั็ษ่ะࠥฮี้ำฬࠤฺำ๊ฮหࠣ์๊ะใศ็็อࠬ෭"))
	Bcxq3nkvTU9iM(PdkZHNBlpg2b7DmX6qRiyVa,y6y5HtgXO4TkUbwVZ(u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭෮"),MgP8OjoaiWQEVG59(u"ࠫࡖ࡛ࡅࡔࡖࡌࡓࡓ࡙ࠧ෯"))
	Bcxq3nkvTU9iM(PdkZHNBlpg2b7DmX6qRiyVa,EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࠨ෰"),zmcGfOdvAjsELeJlP(u"࠭ࡁࡍࡎࡢࡅࡉࡊࡏࡏࡕࡢ࡜ࡒࡒࠧ෱"))
	Bcxq3nkvTU9iM(PdkZHNBlpg2b7DmX6qRiyVa,ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪෲ"),tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠨࡈࡒࡖ࡜ࡇࡒࡅࡕࠪෳ"))
	Bcxq3nkvTU9iM(PdkZHNBlpg2b7DmX6qRiyVa,GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬ෴"),tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠪࡗࡎ࡚ࡅࡔࡡࡑࡅࡒࡋࡓࠨ෵"))
	Bcxq3nkvTU9iM(PdkZHNBlpg2b7DmX6qRiyVa,xpT28sXu051(u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧ෶"),vODxLKW5Ql6r4Fbm8(u"࡙ࠬࡉࡕࡇࡖࡣࡈࡎࡅࡄࡍࠪ෷"))
	Bcxq3nkvTU9iM(PdkZHNBlpg2b7DmX6qRiyVa,L90uqo28xEKSFUwYTcm51yRWZIkft(u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩ෸"),XrTw01KtLzbpoyMf(u"ࠧࡔࡋࡗࡉࡘࡥࡖࡆࡔࡌࡊ࡞࠭෹"))
	OXsckY7RzjCag9A.setSetting(XrTw01KtLzbpoyMf(u"ࠨࡣࡹ࠲࡭ࡵࡳࡵ࠰ࡩࡳࡸࡺࡡࠨ෺"),iiy37aKq0pCEIOwfcTh61xb4U)
	OXsckY7RzjCag9A.setSetting(ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠩࡤࡺ࠳࡮࡯ࡴࡶ࠱ࡪࡦࡨࡲࡢ࡭ࡤࠫ෻"),iiy37aKq0pCEIOwfcTh61xb4U)
	OXsckY7RzjCag9A.setSetting(UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠪࡥࡻ࠴ࡨࡰࡵࡷ࠲ࡸ࡮ࡡࡩ࡫ࡧ࠸ࡺ࠭෼"),iiy37aKq0pCEIOwfcTh61xb4U)
	OXsckY7RzjCag9A.setSetting(HtK4o2sTPgA78U(u"ࠫࡦࡼ࠮ࡩࡱࡶࡸ࠳࡬ࡡࡴࡧ࡯࡬ࡩ࠷ࠧ෽"),iiy37aKq0pCEIOwfcTh61xb4U)
	OXsckY7RzjCag9A.setSetting(jXE2YHkswT8y(u"ࠬࡧࡶ࠯ࡲࡵ࡭ࡻࡹ࠱ࠨ෾"),iiy37aKq0pCEIOwfcTh61xb4U)
	OXsckY7RzjCag9A.setSetting(ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"࠭ࡡࡷ࠰ࡳࡩࡷ࡯࡯ࡥ࠰࡬ࡲ࡫ࡵࡳࠨ෿"),iiy37aKq0pCEIOwfcTh61xb4U)
	OXsckY7RzjCag9A.setSetting(XrTw01KtLzbpoyMf(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴ࡳࡩࡱࡵࡸࠬ฀"),iiy37aKq0pCEIOwfcTh61xb4U)
	OXsckY7RzjCag9A.setSetting(LyNiIHPOwD3hCUYEFM7(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮ࡳࡧࡪࡹࡱࡧࡲࠨก"),iiy37aKq0pCEIOwfcTh61xb4U)
	OXsckY7RzjCag9A.setSetting(LyNiIHPOwD3hCUYEFM7(u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯࡮ࡲࡲ࡬࠭ข"),iiy37aKq0pCEIOwfcTh61xb4U)
	OXsckY7RzjCag9A.setSetting(JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰ࡰࡩࡸࡹࡡࡨࡧࡶࠫฃ"),iiy37aKq0pCEIOwfcTh61xb4U)
	OXsckY7RzjCag9A.setSetting(MgP8OjoaiWQEVG59(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ࠭ค"),iiy37aKq0pCEIOwfcTh61xb4U)
	Bcxq3nkvTU9iM(PdkZHNBlpg2b7DmX6qRiyVa,Y41NvKfOroMzGB8sEHy7wbXlc5(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡔࡋࡗࡉࡘ࠭ฅ"))
	Bcxq3nkvTU9iM(PdkZHNBlpg2b7DmX6qRiyVa,XrTw01KtLzbpoyMf(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡋࡓࡘ࡛࠭ฆ"))
	Bcxq3nkvTU9iM(PdkZHNBlpg2b7DmX6qRiyVa,yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡐ࠷࡚࠭ง"))
	Bcxq3nkvTU9iM(PdkZHNBlpg2b7DmX6qRiyVa,HtK4o2sTPgA78U(u"ࠨࡕࡆࡖࡆࡖࡅࡓࡕࡢࡗ࡙ࡇࡔࡖࡕࠪจ"))
	pzdyLtNP8rYDiUacIf(BF6QAiLUNHh7rKOugaw)
	fNqmjxDcp1Q8tPsHiKhIg20au4FzAS(hI7SkXd94fFzAHNZCQoMqEutbnWP)
	import lpTiXPCdwE
	lpTiXPCdwE.SMxv29nWI0HbkqUEVrgymYO(rGPen6cSMHQkAywh8vqI9JXiD2)
	if eX2iI1vRsQUGJOnwq6==PtkEvXAqif14G20QZsaSyT(u"ࠩࡖࡍࡒࡖࡌࡆࡡࡘࡔࡉࡇࡔࡆࠩฉ"):
		FkOnysh4X7mNU9(rGPen6cSMHQkAywh8vqI9JXiD2,[PdkZHNBlpg2b7DmX6qRiyVa])
	else:
		FkOnysh4X7mNU9(BF6QAiLUNHh7rKOugaw,[])
		lpTiXPCdwE.ttVx0znGRokWf3JHYgasDlF()
		lpTiXPCdwE.nv2FxBURGbaTYX(yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡣࡧࡥࡵࡺࡩࡷࡧࠪช"),BF6QAiLUNHh7rKOugaw)
		lpTiXPCdwE.nv2FxBURGbaTYX(hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡵࡸࡲࡶࠧซ"),BF6QAiLUNHh7rKOugaw)
		try:
			e3ZFcLf5iyXp8IBC = wkMR5x1gTWEQIc6qHCa.path.join(Hyw4UJ6ephu,HtK4o2sTPgA78U(u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧฌ"),CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"࠭ࡡࡥࡦࡲࡲࡤࡪࡡࡵࡣࠪญ"),tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠧࡴࡥࡵ࡭ࡵࡺ࠮࡮ࡱࡧࡹࡱ࡫࠮ࡳࡧࡶࡳࡱࡼࡥࡶࡴ࡯ࠫฎ"),Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠨࡵࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡼࡲࡲࠧฏ"))
			yW6DShkLQZUJ2Iniu8rV7 = DnzmO5hVTuNriyELed.Addon(id=Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠩࡶࡧࡷ࡯ࡰࡵ࠰ࡰࡳࡩࡻ࡬ࡦ࠰ࡵࡩࡸࡵ࡬ࡷࡧࡸࡶࡱ࠭ฐ"))
			yW6DShkLQZUJ2Iniu8rV7.setSetting(SaB5hx3PZwXRLtKgrTfQvId(u"ࠪࡥࡻ࠴ࡡࡶࡶࡲࡣࡵ࡯ࡣ࡬ࠩฑ"),AbqCJZdWQP9j(u"ࠫࡋࡧ࡬ࡴࡧࠪฒ"))
		except: pass
		try:
			e3ZFcLf5iyXp8IBC = wkMR5x1gTWEQIc6qHCa.path.join(Hyw4UJ6ephu,PtkEvXAqif14G20QZsaSyT(u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧณ"),L90uqo28xEKSFUwYTcm51yRWZIkft(u"࠭ࡡࡥࡦࡲࡲࡤࡪࡡࡵࡣࠪด"),xpT28sXu051(u"ࠧࡴࡥࡵ࡭ࡵࡺ࠮࡮ࡱࡧࡹࡱ࡫࠮ࡺࡶ࠰ࡨࡱࡶࠧต"),ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠨࡵࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡼࡲࡲࠧถ"))
			yW6DShkLQZUJ2Iniu8rV7 = DnzmO5hVTuNriyELed.Addon(id=ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠩࡶࡧࡷ࡯ࡰࡵ࠰ࡰࡳࡩࡻ࡬ࡦ࠰ࡼࡸ࠲ࡪ࡬ࡱࠩท"))
			yW6DShkLQZUJ2Iniu8rV7.setSetting(hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠪࡥࡻ࠴ࡶࡪࡦࡨࡳࡤࡷࡵࡢ࡮࡬ࡸࡾ࠭ธ"),FRYcH4KL7e9gv5pEB(u"ࠫ࠸࠭น"))
		except: pass
		try:
			e3ZFcLf5iyXp8IBC = wkMR5x1gTWEQIc6qHCa.path.join(Hyw4UJ6ephu,MgP8OjoaiWQEVG59(u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧบ"),vODxLKW5Ql6r4Fbm8(u"࠭ࡡࡥࡦࡲࡲࡤࡪࡡࡵࡣࠪป"),xpT28sXu051(u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡧࡤࡢࡲࡷ࡭ࡻ࡫ࠧผ"),tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠨࡵࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡼࡲࡲࠧฝ"))
			yW6DShkLQZUJ2Iniu8rV7 = DnzmO5hVTuNriyELed.Addon(id=sVzojQerUqX(u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡢࡦࡤࡴࡹ࡯ࡶࡦࠩพ"))
			yW6DShkLQZUJ2Iniu8rV7.setSetting(IpC4qHXRuyNFjzWv(u"ࠪࡥࡻ࠴ࡓࡕࡔࡈࡅࡒ࡙ࡅࡍࡇࡆࡘࡎࡕࡎࠨฟ"),TlGXWLYsV1z(u"ࠫ࠷࠭ภ"))
		except: pass
	oRzlSfeE6DY0mFy37NCVxAJW1BwZtM = vvqB64XWVrb1kKJmC0xyNHiF7fOL(NWDbjPABRxu)
	oRzlSfeE6DY0mFy37NCVxAJW1BwZtM = vvqB64XWVrb1kKJmC0xyNHiF7fOL(v05aOkM7NXBHuT3UpAdiPq4)
	lpTiXPCdwE.gv0QrBSsWVdLY5TnNRwDy4kjeb(BF6QAiLUNHh7rKOugaw)
	OXsckY7RzjCag9A.setSetting(IpC4qHXRuyNFjzWv(u"ࠬࡧࡶ࠯ࡸࡨࡶࡸ࡯࡯࡯ࠩม"),DdAjF5pBNL9IqPgkz0xhcQEfU)
	SqMHwb6X1Ph8jY7LBNkmtV4F5Jlspy(BF6QAiLUNHh7rKOugaw)
	return
def n9nIi1N7A6y8H4Tr():
	rrCcRTZDnwSWgHl1XYUi = X3IPqeaH8zOYn(OXsckY7RzjCag9A.getSetting(CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡹࡨࡰࡴࡷࠫย")))
	rrCcRTZDnwSWgHl1XYUi = FGTfwsjNrB8DvKSZhLIQAb1JnO if not rrCcRTZDnwSWgHl1XYUi else int(rrCcRTZDnwSWgHl1XYUi)
	if not rrCcRTZDnwSWgHl1XYUi or not FGTfwsjNrB8DvKSZhLIQAb1JnO<=pwXCQWuGUMka2hFN-rrCcRTZDnwSWgHl1XYUi<=r3rnfZ7cdxzNFebIRaLSG6B:
		OXsckY7RzjCag9A.setSetting(AbqCJZdWQP9j(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴ࡳࡩࡱࡵࡸࠬร"),kTJISUV1CbZQ2gndAuMwBP7(pwXCQWuGUMka2hFN))
		fNqmjxDcp1Q8tPsHiKhIg20au4FzAS(hI7SkXd94fFzAHNZCQoMqEutbnWP)
		VHagxEK7LJ1AY398 = X3IPqeaH8zOYn(OXsckY7RzjCag9A.getSetting(SaB5hx3PZwXRLtKgrTfQvId(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮ࡳࡧࡪࡹࡱࡧࡲࠨฤ")))
		VHagxEK7LJ1AY398 = FGTfwsjNrB8DvKSZhLIQAb1JnO if not VHagxEK7LJ1AY398 else int(VHagxEK7LJ1AY398)
		if not VHagxEK7LJ1AY398 or not FGTfwsjNrB8DvKSZhLIQAb1JnO<=pwXCQWuGUMka2hFN-VHagxEK7LJ1AY398<=PNjZMS7nxa9clHusz1:
			OXsckY7RzjCag9A.setSetting(FRYcH4KL7e9gv5pEB(u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯ࡴࡨ࡫ࡺࡲࡡࡳࠩล"),kTJISUV1CbZQ2gndAuMwBP7(pwXCQWuGUMka2hFN))
			kqAyL0F4bUcl1svBPn(BF6QAiLUNHh7rKOugaw)
		tvkEqNn3dHwzWC5Q4T = X3IPqeaH8zOYn(OXsckY7RzjCag9A.getSetting(PtkEvXAqif14G20QZsaSyT(u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰࡯ࡳࡳ࡭ࠧฦ")))
		tvkEqNn3dHwzWC5Q4T = FGTfwsjNrB8DvKSZhLIQAb1JnO if not tvkEqNn3dHwzWC5Q4T else int(tvkEqNn3dHwzWC5Q4T)
		if not tvkEqNn3dHwzWC5Q4T or not FGTfwsjNrB8DvKSZhLIQAb1JnO<=pwXCQWuGUMka2hFN-tvkEqNn3dHwzWC5Q4T<=Dxc7GChQwZ4kOlKHSbL06agnB:
			OXsckY7RzjCag9A.setSetting(UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡰࡴࡴࡧࠨว"),kTJISUV1CbZQ2gndAuMwBP7(pwXCQWuGUMka2hFN))
			sj246WXRZ1QPchEB7l8V = EEehSFDLdpKBR3W1ga9PxrV.Thread(target=Hm64zKwvF2toSZVG8dprJDkXCTncf)
			sj246WXRZ1QPchEB7l8V.start()
	pcrJfP6IBdbYXjLFkwaRW = X3IPqeaH8zOYn(OXsckY7RzjCag9A.getSetting(uuExaKGL7UONtevRd(u"ࠬࡧࡶ࠯ࡲࡨࡶ࡮ࡵࡤ࠯࡫ࡱࡪࡴࡹࠧศ")))
	pcrJfP6IBdbYXjLFkwaRW = FGTfwsjNrB8DvKSZhLIQAb1JnO if not pcrJfP6IBdbYXjLFkwaRW else int(pcrJfP6IBdbYXjLFkwaRW)
	poP8CUsvAg4MZcnyBw = X3IPqeaH8zOYn(OXsckY7RzjCag9A.getSetting(tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡷࡵࡦࡵࡷ࡭ࡴࡴࡳࠨษ")))
	poP8CUsvAg4MZcnyBw = FGTfwsjNrB8DvKSZhLIQAb1JnO if not poP8CUsvAg4MZcnyBw else int(poP8CUsvAg4MZcnyBw)
	if not pcrJfP6IBdbYXjLFkwaRW or not poP8CUsvAg4MZcnyBw or not FGTfwsjNrB8DvKSZhLIQAb1JnO<=pwXCQWuGUMka2hFN-poP8CUsvAg4MZcnyBw<=pcrJfP6IBdbYXjLFkwaRW: iaVgBNnCSw()
	return
def iaVgBNnCSw():
	E7mudpjWDlFM14YVfT = YYJQyRskpX8jv
	tH1vsQrg5oawfKbe8mJcYWjTDl = BF6QAiLUNHh7rKOugaw if IiCsQD91HF.i95KXZx1GISPt else rGPen6cSMHQkAywh8vqI9JXiD2
	if tH1vsQrg5oawfKbe8mJcYWjTDl:
		ddxk8CzNrlhiJtSeTDLVEa0c = QeY9sWZqAhDomcd3rMIp(rGPen6cSMHQkAywh8vqI9JXiD2)
		if len(ddxk8CzNrlhiJtSeTDLVEa0c)>YYJQyRskpX8jv:
			WKquk5EaNr4RzVf(q1rohYuwnfpVZUa98L2CtQzmAcB,ZchUJdM93pTA7zG5(u"ࠧ࠯࡞ࡷࡗ࡭ࡵࡷࡪࡰࡪࠤࡖࡻࡥࡴࡶ࡬ࡳࡳࠦࠠࠡࡒࡤࡸ࡭ࡀࠠ࡜ࠢࠪส")+CzWIqm1YAcEa9gTSZ30fk27+LyNiIHPOwD3hCUYEFM7(u"ࠨࠢࡠࠫห"))
			Tj2xuNbqyrLMeoaYJB7Sh3IiU,BBWS6VTi15YeM2bvJGXtxpslDhg8,bl81eAwQG63tZjRhSzX0dCIv,OC9lxzDodrFpvn8X6kMebAfE1tKS,GNzbpq6tvX1kZjgixEmSn,LXSBswmknoDzdT1hQqlUie = ddxk8CzNrlhiJtSeTDLVEa0c[FGTfwsjNrB8DvKSZhLIQAb1JnO]
			aRmuUoYczdTE4hbLO0JMqty,aS4kgtYoWwlFLs1m9 = OC9lxzDodrFpvn8X6kMebAfE1tKS.split(yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠩ࡟ࡲࡀࡁࠧฬ"))
			del ddxk8CzNrlhiJtSeTDLVEa0c[FGTfwsjNrB8DvKSZhLIQAb1JnO]
			Tdap18kQc4gZBM79Xv = ufTX72hK8Q63jSsJiqDm5.sample(ddxk8CzNrlhiJtSeTDLVEa0c,YYJQyRskpX8jv)
			Tj2xuNbqyrLMeoaYJB7Sh3IiU,BBWS6VTi15YeM2bvJGXtxpslDhg8,bl81eAwQG63tZjRhSzX0dCIv,OC9lxzDodrFpvn8X6kMebAfE1tKS,GNzbpq6tvX1kZjgixEmSn,LXSBswmknoDzdT1hQqlUie = Tdap18kQc4gZBM79Xv[FGTfwsjNrB8DvKSZhLIQAb1JnO]
			bl81eAwQG63tZjRhSzX0dCIv = XrTw01KtLzbpoyMf(u"ࠪ࡟ࡗ࡚ࡌ࡞ࠩอ")+aqEsMBckT2bunGHfl48Wip+CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠫࠥࡀࠠࠨฮ")+Tj2xuNbqyrLMeoaYJB7Sh3IiU+YoQW601K4fMJcsreDnGVE5wUZIy7+bl81eAwQG63tZjRhSzX0dCIv
			GNzbpq6tvX1kZjgixEmSn = zmcGfOdvAjsELeJlP(u"ࠬหัิษ็ࠤึูวๅห่้๋ࠣศา็ฯࠫฯ")
			xxkwlavUo3gJfB = L90uqo28xEKSFUwYTcm51yRWZIkft(u"࠭วๅฬหี฾อสࠨะ")
			button0,button1 = OC9lxzDodrFpvn8X6kMebAfE1tKS,GNzbpq6tvX1kZjgixEmSn
			dKpIoliRENVFxS3HtM4wLr = [button0,button1,xxkwlavUo3gJfB]
			UUiKRFs5yuPMwZpjQlV = YYJQyRskpX8jv if IiCsQD91HF.ic2FB5X43kWzyTKtNE else y6y5HtgXO4TkUbwVZ(u"࠲࠲Ꮫ")
			kCWluLqaQTjbyoOZt0 = -L90uqo28xEKSFUwYTcm51yRWZIkft(u"࠻Ꮬ")
			while kCWluLqaQTjbyoOZt0<FGTfwsjNrB8DvKSZhLIQAb1JnO:
				HECsI7DGuRr6cKFkeagv1QntWNwSj9 = ufTX72hK8Q63jSsJiqDm5.sample(dKpIoliRENVFxS3HtM4wLr,iiCWLaJREureAlOkv)
				kCWluLqaQTjbyoOZt0 = Ny92sqomMkizpgKV1(iiy37aKq0pCEIOwfcTh61xb4U,HECsI7DGuRr6cKFkeagv1QntWNwSj9[FGTfwsjNrB8DvKSZhLIQAb1JnO],HECsI7DGuRr6cKFkeagv1QntWNwSj9[YYJQyRskpX8jv],HECsI7DGuRr6cKFkeagv1QntWNwSj9[nI2JK1RfsGWNY3OarEeMQZ],aRmuUoYczdTE4hbLO0JMqty,bl81eAwQG63tZjRhSzX0dCIv,CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠧࡤࡱࡱࡪ࡮ࡸ࡭ࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩั"),UUiKRFs5yuPMwZpjQlV,hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"࠹࠴Ꮭ"))
				if kCWluLqaQTjbyoOZt0==tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"࠵࠵Ꮮ"): break
				import lpTiXPCdwE
				if kCWluLqaQTjbyoOZt0>=FGTfwsjNrB8DvKSZhLIQAb1JnO and HECsI7DGuRr6cKFkeagv1QntWNwSj9[kCWluLqaQTjbyoOZt0]==dKpIoliRENVFxS3HtM4wLr[YYJQyRskpX8jv]:
					lpTiXPCdwE.fmS1GJHNpqKyxE7u5bA()
					if kCWluLqaQTjbyoOZt0>=FGTfwsjNrB8DvKSZhLIQAb1JnO: kCWluLqaQTjbyoOZt0 = -tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"࠾Ꮯ")
				elif kCWluLqaQTjbyoOZt0>=FGTfwsjNrB8DvKSZhLIQAb1JnO and HECsI7DGuRr6cKFkeagv1QntWNwSj9[kCWluLqaQTjbyoOZt0]==dKpIoliRENVFxS3HtM4wLr[nI2JK1RfsGWNY3OarEeMQZ]:
					lpTiXPCdwE.yyWPISuOFtKBUXq8GQDwkCjf5xos(BF6QAiLUNHh7rKOugaw)
				if kCWluLqaQTjbyoOZt0==-YYJQyRskpX8jv: bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫา"),aqEsMBckT2bunGHfl48Wip+UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠩัีําࠠฯูฦࠫำ")+YoQW601K4fMJcsreDnGVE5wUZIy7+ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠪࡠࡳࠦไๅะิ์ัࠦวๅืะ๎าࠦรฯฬิࠤํออะ่๊ࠢࠥอไฤฮ๋ฬฮࠦวๅ็อ์ๆืษࠨิ"))
			E7mudpjWDlFM14YVfT = YYJQyRskpX8jv
		else: E7mudpjWDlFM14YVfT = FGTfwsjNrB8DvKSZhLIQAb1JnO
	OXsckY7RzjCag9A.setSetting(hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ࠭ี"),kTJISUV1CbZQ2gndAuMwBP7(pwXCQWuGUMka2hFN))
	YMQXP2BGeK86CEb(PdkZHNBlpg2b7DmX6qRiyVa,ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨึ"),CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"࠭ࡓࡊࡖࡈࡗࡤࡔࡁࡎࡇࡖࠫื"),E7mudpjWDlFM14YVfT,VaeMF1mIjQ5iLtfGcB)
	return
def ulJmMYhHLa9pVT(EGJVsZy38Xx,Toe5N9znWjQHmP4whguld,smglbwR7x2oM,y3qATZDQOch6db5WjnmrguflU,L95mrowGgdsD,zLEP9N4BOsVrXa,XiWJ2PTqvds4pBNebVrt98x,EALyNnv1Db4cUd8sQoZX2pmBVt7kM,XC10geOnQtwrs,lBz8JnYhCN3RU,e7wFcO9GDXRq,M5qyIg2dZlm6FxH4tTPV79okNu0bCG,BBhSoAIskTHPN1MnWLGjUawZy,z1F5cTMvEk2Ngd70QRy3mqp):
	B9HnYsiS4Dgq3tVTwOKcoACaELrufU = int(lBz8JnYhCN3RU%CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"࠷࠰Ꮰ"))
	xl0I9SsgtGu5E = int(lBz8JnYhCN3RU/MgP8OjoaiWQEVG59(u"࠱࠱Ꮱ"))
	bdYnOoSxlsAwpZWDt01F7qT = EGJVsZy38Xx,Toe5N9znWjQHmP4whguld,smglbwR7x2oM,y3qATZDQOch6db5WjnmrguflU,L95mrowGgdsD,zLEP9N4BOsVrXa,XiWJ2PTqvds4pBNebVrt98x,iiy37aKq0pCEIOwfcTh61xb4U,XC10geOnQtwrs
	FZl8t1uPx3yszXYoe5CJ9GnfQ6TvB = OXsckY7RzjCag9A.getSetting(sVzojQerUqX(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡱࡪࡴࡵࡴࡥࡤࡧ࡭࡫ุࠧ"))
	if not FZl8t1uPx3yszXYoe5CJ9GnfQ6TvB: OXsckY7RzjCag9A.setSetting(y6y5HtgXO4TkUbwVZ(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡲ࡫࡮ࡶࡵࡦࡥࡨ࡮ࡥࠨู"),CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠩࡄ࡙࡙ࡕฺࠧ"))
	zCXZNsp6PT8Mhxnr5v0G71KaBdFR = OXsckY7RzjCag9A.getSetting(AbqCJZdWQP9j(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡲࡦࡨࡵࡩࡸ࡮ࠧ฻"))
	SWDcPHa03GEyls9UnN = UrB3iTzS1sFnX(e7wFcO9GDXRq)
	gpb9GmYhwH3s7i4e = [FGTfwsjNrB8DvKSZhLIQAb1JnO,uuExaKGL7UONtevRd(u"࠳࠸Ꮳ"),y6y5HtgXO4TkUbwVZ(u"࠴࠻Ꮴ"),TlGXWLYsV1z(u"࠵࠾Ꮵ"),jXE2YHkswT8y(u"࠳࠸Ꮲ"),tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"࠳࠵Ꮸ"),xpT28sXu051(u"࠺࠶Ꮶ"),ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"࠻࠳Ꮷ")]
	kKVGn6ATW7EDe1Z8Pf9oX4 = xl0I9SsgtGu5E not in gpb9GmYhwH3s7i4e
	FCWQrhNy45IxcX86YgKHSzER0biM7 = xl0I9SsgtGu5E in [zmcGfOdvAjsELeJlP(u"࠶࠸Ꮼ"),LyNiIHPOwD3hCUYEFM7(u"࠳࠺Ꮹ"),xpT28sXu051(u"࠺࠵Ꮻ"),FRYcH4KL7e9gv5pEB(u"࠹࠵Ꮺ")]
	R7MgKh5fraJnF = lBz8JnYhCN3RU in [FRYcH4KL7e9gv5pEB(u"࠸࠶࠶Ꮾ"),ZchUJdM93pTA7zG5(u"࠷࠽࠰Ꮽ")]
	iT7tp5u8HUbW = (kKVGn6ATW7EDe1Z8Pf9oX4 or FCWQrhNy45IxcX86YgKHSzER0biM7) and not R7MgKh5fraJnF
	krPfEgXiN37THhqyMURne1A4pO = (zCXZNsp6PT8Mhxnr5v0G71KaBdFR or not EALyNnv1Db4cUd8sQoZX2pmBVt7kM) and zCXZNsp6PT8Mhxnr5v0G71KaBdFR not in [XrTw01KtLzbpoyMf(u"ࠫࡗࡋࡆࡓࡇࡖࡌࡤࡉࡁࡄࡊࡈࠫ฼")]+N9mPkX14E8VyHDSF
	RRey1Ogjqxz0LIW4VBt3o8Fc9EdkN = IpC4qHXRuyNFjzWv(u"ࠬࡺࡹࡱࡧࡀࠫ฽") in zCXZNsp6PT8Mhxnr5v0G71KaBdFR
	crqKbo8YuV = lBz8JnYhCN3RU in [GGx4qyKP1vUtRghsE2WfaHLMXZ(u"࠴࠺࠶ᏹ"),y6y5HtgXO4TkUbwVZ(u"࠵࠻࠸ᏺ"),CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"࠶࠼࠳ᏻ"),UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"࠷࠶࠵Ᏽ"),AbqCJZdWQP9j(u"࠱࠷࠷᏶"),HtK4o2sTPgA78U(u"࠲࠸࠹᏷"),sVzojQerUqX(u"࠳࠹࠻ᏸ"),vODxLKW5Ql6r4Fbm8(u"࠶࠼࠸Ᏼ"),hhQwbeiNLoqFjX90fB7aG8VAs(u"࠹࠹࠵Ᏹ"),AbqCJZdWQP9j(u"࠷࠷࠴Ꮿ"),YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"࠸࠸࠶Ᏸ"),jXE2YHkswT8y(u"࠺࠺࠹Ᏺ"),zmcGfOdvAjsELeJlP(u"࠻࠻࠻Ᏻ")]
	mUhJtHB9nw = B9HnYsiS4Dgq3tVTwOKcoACaELrufU==uuExaKGL7UONtevRd(u"࠿ᏼ") or lBz8JnYhCN3RU in [GGx4qyKP1vUtRghsE2WfaHLMXZ(u"࠲࠶࠸᏾"),L90uqo28xEKSFUwYTcm51yRWZIkft(u"࠸࠵࠻᐀"),ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"࠷࠵࠷᏿"),jXE2YHkswT8y(u"࠴࠶ᏽ")]
	tcxdziHvKXUMyq1O93L5NJf4ngA = not crqKbo8YuV
	cc08YHrXvoRg7Ls = not mUhJtHB9nw
	usRUxYCj1DLc9lrBOSWQVZH8yaN = SWDcPHa03GEyls9UnN in [iiy37aKq0pCEIOwfcTh61xb4U,tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"࠭࠮࠯ࠩ฾")]
	zHcn2Xy9BQ = usRUxYCj1DLc9lrBOSWQVZH8yaN or tcxdziHvKXUMyq1O93L5NJf4ngA
	vBxTOP7ygnAHpZ5X26iM8 = usRUxYCj1DLc9lrBOSWQVZH8yaN or cc08YHrXvoRg7Ls or RRey1Ogjqxz0LIW4VBt3o8Fc9EdkN
	e6QmX9b4BGIUTvDqkLxtCrJl5Wy = lBz8JnYhCN3RU not in [GGx4qyKP1vUtRghsE2WfaHLMXZ(u"࠳࠸࠳ᐅ"),y6y5HtgXO4TkUbwVZ(u"࠶࠻࠷ᐁ"),jXE2YHkswT8y(u"࠴࠹࠹ᐆ"),ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"࠸࠷࠱ᐃ"),GGx4qyKP1vUtRghsE2WfaHLMXZ(u"࠸࠹࠰ᐂ"),tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"࠵࠵࠲ᐄ"),JZszNnIEMAx28Yao0yqhiXGKOPb(u"࠴࠴࠶࠶ᐇ")]
	if FZl8t1uPx3yszXYoe5CJ9GnfQ6TvB==tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠧࡔࡖࡒࡔࠬ฿"): ViOyZLPINwKaS5sepdnm = mUhJtHB9nw or crqKbo8YuV
	else: ViOyZLPINwKaS5sepdnm = rGPen6cSMHQkAywh8vqI9JXiD2
	aaDP65Q3EtXM = xl0I9SsgtGu5E in [HtK4o2sTPgA78U(u"࠼࠺ᐉ"),xpT28sXu051(u"࠻࠺ᐈ")]
	Jtn5a8CfBgejQ = lBz8JnYhCN3RU in [hhQwbeiNLoqFjX90fB7aG8VAs(u"࠸࠸࠱ᐊ"),ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"࠷࠳࠲ᐋ")]
	FL3WEQIfoin12U4lRrvcY = not aaDP65Q3EtXM and not Jtn5a8CfBgejQ
	kV3wtLvpdrXo6eK1QBUMPAjG8az7g = zHcn2Xy9BQ and vBxTOP7ygnAHpZ5X26iM8 and e6QmX9b4BGIUTvDqkLxtCrJl5Wy and ViOyZLPINwKaS5sepdnm and FL3WEQIfoin12U4lRrvcY
	xxpIcGeHUdWt1Ey5n = e6QmX9b4BGIUTvDqkLxtCrJl5Wy and ViOyZLPINwKaS5sepdnm and FL3WEQIfoin12U4lRrvcY
	UdjTRFouqJDNZW3XHsKP271E = xxpIcGeHUdWt1Ey5n
	XMFrUlHy0oQgIqLWJY195K3 = OXsckY7RzjCag9A.getSetting(ZchUJdM93pTA7zG5(u"ࠨࡣࡹ࠲ࡱࡧ࡮ࡨࡷࡤ࡫ࡪ࠴ࡰࡳࡱࡹ࡭ࡩ࡫ࡲࠨเ"))
	kqwteuoVZK25MsrFzLf6dY9 = OXsckY7RzjCag9A.getSetting(ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠩࡤࡺ࠳ࡲࡡ࡯ࡩࡸࡥ࡬࡫࠮ࡤࡱࡧࡩࠬแ"))
	PPdh6zxpSVAfNOFHJ7oGR10U = BF6QAiLUNHh7rKOugaw
	if krPfEgXiN37THhqyMURne1A4pO and kV3wtLvpdrXo6eK1QBUMPAjG8az7g:
		dVNATb2KFHDevMlJ5YOZG = QKzCiBOWZus1nSv(PdkZHNBlpg2b7DmX6qRiyVa,tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠪࡰ࡮ࡹࡴࠨโ"),CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠫࡒࡋࡎࡖࡕࡢࡇࡆࡉࡈࡆࡡࠪใ")+XMFrUlHy0oQgIqLWJY195K3+MgP8OjoaiWQEVG59(u"ࠬࡥࠧไ")+kqwteuoVZK25MsrFzLf6dY9,bdYnOoSxlsAwpZWDt01F7qT)
		if dVNATb2KFHDevMlJ5YOZG:
			WKquk5EaNr4RzVf(iiy37aKq0pCEIOwfcTh61xb4U,ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"࠭࠮࡝ࡶࡐࡉࡓ࡛ࡓࡠࡅࡄࡇࡍࡋ࡟ࠨๅ")+XMFrUlHy0oQgIqLWJY195K3+vODxLKW5Ql6r4Fbm8(u"ࠧࡠࠩๆ")+kqwteuoVZK25MsrFzLf6dY9+PtkEvXAqif14G20QZsaSyT(u"ࠨࠢࠣࠤࡑࡵࡡࡥ࡫ࡱ࡫ࠥࡳࡥ࡯ࡷࠣࡪࡷࡵ࡭ࠡࡥࡤࡧ࡭࡫ࠧ็"))
			if RRey1Ogjqxz0LIW4VBt3o8Fc9EdkN:
				IlRjEdf194H8wbCQZnVWgpezsc5aFP = []
				from TTOWYe76MF import rrAFBXq5Q2Gpnw
				from LTAR3BSjNg import IkV3q9Q2jBYuhKTtzW01dFoCxL,ZurfTHXFnmM3t7CSogYJxjBhA
				eI4l89fGtbK2ma6FNyCjkDJsnui = rrAFBXq5Q2Gpnw
				KK0unX9R58QLYz = IkV3q9Q2jBYuhKTtzW01dFoCxL()
				q9BepQos0XWYZHycgv348 = zCXZNsp6PT8Mhxnr5v0G71KaBdFR
				iBHbcdw4WLg3P0pT,h9EUcuxpm5BXQ,DjAoaVRzItq2bY,jlwvAic5HfGK1qCMQrIZ9pOu,zobcsYWChpP52eA8mL9KuO,GGO6zoTBJ2kNLD1j,WBqACFE5HvOgl0JIXRycxPUe2niVL,gZmQICDWzMYXT5FiASf,ttleD5rRC32PkxmHzKVhWv1TO4Y0qw = Q4APpMirastonc6Wh1v2XOH3K(q9BepQos0XWYZHycgv348)
				t4gBWCPLOrUf = iBHbcdw4WLg3P0pT,h9EUcuxpm5BXQ,DjAoaVRzItq2bY,jlwvAic5HfGK1qCMQrIZ9pOu,zobcsYWChpP52eA8mL9KuO,GGO6zoTBJ2kNLD1j,WBqACFE5HvOgl0JIXRycxPUe2niVL,iiy37aKq0pCEIOwfcTh61xb4U,ttleD5rRC32PkxmHzKVhWv1TO4Y0qw
				for OOAIaEkhsVfBYld in dVNATb2KFHDevMlJ5YOZG:
					kkPC2aLxOsA1lMHD0Voip = OOAIaEkhsVfBYld[AbqCJZdWQP9j(u"ࠩࡰࡩࡳࡻࡉࡵࡧࡰ่ࠫ")]
					if kkPC2aLxOsA1lMHD0Voip==t4gBWCPLOrUf or OOAIaEkhsVfBYld[xpT28sXu051(u"ࠪࡱࡴࡪࡥࠨ้")] in [jXE2YHkswT8y(u"࠴࠹࠹ᐍ"),yJeq1BjfiO4NFuwIEzxVLK6b9s(u"࠳࠹࠳ᐌ")]:
						OOAIaEkhsVfBYld = mOlYsSNcyniA9(kkPC2aLxOsA1lMHD0Voip,eI4l89fGtbK2ma6FNyCjkDJsnui,KK0unX9R58QLYz)
						if OOAIaEkhsVfBYld[CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠫ࡫ࡧࡶࡰࡴ࡬ࡸࡪࡹ๊ࠧ")]:
							hhd9vRNGw4UnH2tXOB76MikT = ZurfTHXFnmM3t7CSogYJxjBhA(KK0unX9R58QLYz,kkPC2aLxOsA1lMHD0Voip,OOAIaEkhsVfBYld[tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠬࡴࡥࡸࡲࡤࡸ࡭๋࠭")])
							OOAIaEkhsVfBYld[ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"࠭ࡣࡰࡰࡷࡩࡽࡺ࡟࡮ࡧࡱࡹࠬ์")] = hhd9vRNGw4UnH2tXOB76MikT+OOAIaEkhsVfBYld[hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠧࡤࡱࡱࡸࡪࡾࡴࡠ࡯ࡨࡲࡺ࠭ํ")]
					IlRjEdf194H8wbCQZnVWgpezsc5aFP.append(OOAIaEkhsVfBYld)
				OXsckY7RzjCag9A.setSetting(AbqCJZdWQP9j(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡷ࡫ࡦࡳࡧࡶ࡬ࠬ๎"),iiy37aKq0pCEIOwfcTh61xb4U)
				if EGJVsZy38Xx==CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠩࡩࡳࡱࡪࡥࡳࠩ๏"): YMQXP2BGeK86CEb(PdkZHNBlpg2b7DmX6qRiyVa,UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠪࡑࡊࡔࡕࡔࡡࡆࡅࡈࡎࡅࡠࠩ๐")+XMFrUlHy0oQgIqLWJY195K3+SaB5hx3PZwXRLtKgrTfQvId(u"ࠫࡤ࠭๑")+kqwteuoVZK25MsrFzLf6dY9,bdYnOoSxlsAwpZWDt01F7qT,IlRjEdf194H8wbCQZnVWgpezsc5aFP,PNjZMS7nxa9clHusz1)
			else: IlRjEdf194H8wbCQZnVWgpezsc5aFP = dVNATb2KFHDevMlJ5YOZG
			if EGJVsZy38Xx==xpT28sXu051(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ๒") and SWDcPHa03GEyls9UnN!=hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"࠭࠮࠯ࠩ๓") and iT7tp5u8HUbW: vtTse5pbrQCKAWjdyJYiPzuOEwxlh()
			PPdh6zxpSVAfNOFHJ7oGR10U = wZM73KAr9H4aV(bdYnOoSxlsAwpZWDt01F7qT,IlRjEdf194H8wbCQZnVWgpezsc5aFP,M5qyIg2dZlm6FxH4tTPV79okNu0bCG,BBhSoAIskTHPN1MnWLGjUawZy,z1F5cTMvEk2Ngd70QRy3mqp)
	elif EGJVsZy38Xx==Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ๔") and zCXZNsp6PT8Mhxnr5v0G71KaBdFR not in [YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠨࡔࡈࡊࡗࡋࡓࡉࡡࡆࡅࡈࡎࡅࠨ๕")]+N9mPkX14E8VyHDSF and xxpIcGeHUdWt1Ey5n:
		Bcxq3nkvTU9iM(PdkZHNBlpg2b7DmX6qRiyVa,tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠩࡐࡉࡓ࡛ࡓࡠࡅࡄࡇࡍࡋ࡟ࠨ๖")+XMFrUlHy0oQgIqLWJY195K3+PtkEvXAqif14G20QZsaSyT(u"ࠪࡣࠬ๗")+kqwteuoVZK25MsrFzLf6dY9,bdYnOoSxlsAwpZWDt01F7qT)
	return PPdh6zxpSVAfNOFHJ7oGR10U,zCXZNsp6PT8Mhxnr5v0G71KaBdFR,bdYnOoSxlsAwpZWDt01F7qT,SWDcPHa03GEyls9UnN,iT7tp5u8HUbW,UdjTRFouqJDNZW3XHsKP271E,XMFrUlHy0oQgIqLWJY195K3,kqwteuoVZK25MsrFzLf6dY9
def cPTjCDRhnzUyt(EGJVsZy38Xx,Toe5N9znWjQHmP4whguld,smglbwR7x2oM,y3qATZDQOch6db5WjnmrguflU,L95mrowGgdsD,zLEP9N4BOsVrXa,XiWJ2PTqvds4pBNebVrt98x,EALyNnv1Db4cUd8sQoZX2pmBVt7kM,XC10geOnQtwrs,lBz8JnYhCN3RU,XZt0CwHxU2jne8oEdrQh5MLT,HhVucpbsy12qgXY):
	if XZt0CwHxU2jne8oEdrQh5MLT in [jXE2YHkswT8y(u"ࠫ࠶࠭๘"),ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠬ࠸ࠧ๙"),tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"࠭࠳ࠨ๚"),sVzojQerUqX(u"ࠧ࠵ࠩ๛"),zmcGfOdvAjsELeJlP(u"ࠨ࠷ࠪ๜"),CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠩ࠴࠵ࠬ๝"),tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠪ࠵࠷࠭๞"),SaB5hx3PZwXRLtKgrTfQvId(u"ࠫ࠶࠹ࠧ๟")] and HhVucpbsy12qgXY:
		import LTAR3BSjNg
		LTAR3BSjNg.niuvdONsTa8A6BPE2wht(EALyNnv1Db4cUd8sQoZX2pmBVt7kM,XZt0CwHxU2jne8oEdrQh5MLT,HhVucpbsy12qgXY)
		SqMHwb6X1Ph8jY7LBNkmtV4F5Jlspy(BF6QAiLUNHh7rKOugaw,CzWIqm1YAcEa9gTSZ30fk27)
	elif XZt0CwHxU2jne8oEdrQh5MLT==SaB5hx3PZwXRLtKgrTfQvId(u"ࠬ࠼ࠧ๠"):
		import braVAkwfBN
		if HhVucpbsy12qgXY==GGx4qyKP1vUtRghsE2WfaHLMXZ(u"࠭ࡄࡐ࡙ࡑࡐࡔࡇࡄࠨ๡"): braVAkwfBN.YYkhEn5xTXLUevzCVNB16mR(LyNiIHPOwD3hCUYEFM7(u"๋ࠧำฯํࠥอไศ่อ฼ฬืࠧ๢"),L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠨฮสี๏ࠦแฮื้้ࠣ็ࠠศๆอั๊๐ไࠨ๣"),X2cQ5NCPvkMieBW7oASspFjE=ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"࠵࠴࠵࠶ᐎ"))
		elif HhVucpbsy12qgXY==ZchUJdM93pTA7zG5(u"ࠩࡇࡉࡑࡋࡔࡆࠩ๤"): KCPY4RcQjwErGfkn8I(kMqh74TPvpSDar59xQUjAyVlHes,BF6QAiLUNHh7rKOugaw)
		EA7FzO1kMZGQXDd2giB0cwLom = braVAkwfBN.wA8ZcpVskTjEf5GdULPi4(EGJVsZy38Xx,Toe5N9znWjQHmP4whguld,smglbwR7x2oM,lBz8JnYhCN3RU,L95mrowGgdsD,zLEP9N4BOsVrXa,XiWJ2PTqvds4pBNebVrt98x,EALyNnv1Db4cUd8sQoZX2pmBVt7kM,XC10geOnQtwrs)
		if HhVucpbsy12qgXY==GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠪࡈࡔ࡝ࡎࡍࡑࡄࡈࠬ๥"): KEPGn8jNAtmDB2yS0kZiX4MCw()
	elif EALyNnv1Db4cUd8sQoZX2pmBVt7kM==TlGXWLYsV1z(u"ࠫ࠼࠭๦"):
		import TsIdr4GvYk
		TsIdr4GvYk.NjAfaewzlX(TlGXWLYsV1z(u"ࠬࡥࡁࡍࡎࠪ๧"))
		SqMHwb6X1Ph8jY7LBNkmtV4F5Jlspy(BF6QAiLUNHh7rKOugaw)
	elif EALyNnv1Db4cUd8sQoZX2pmBVt7kM==xpT28sXu051(u"࠭࠸ࠨ๨"): WwMgozBIC32n9d0tyfp.executebuiltin(L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱࡙ࡵࡪࡡࡵࡧࠫࡴࡱࡻࡧࡪࡰ࠽࠳࠴࠭๩")+M8hQu61Uid+ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠨࡁࡰࡳࡩ࡫࠽ࠨ๪")+str(y3qATZDQOch6db5WjnmrguflU)+hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠩࠩࡸࡾࡶࡥ࠾ࡨࡲࡰࡩ࡫ࡲࠪࠩ๫"))
	elif EALyNnv1Db4cUd8sQoZX2pmBVt7kM==HtK4o2sTPgA78U(u"ࠪ࠽ࠬ๬"):
		SqMHwb6X1Ph8jY7LBNkmtV4F5Jlspy(rGPen6cSMHQkAywh8vqI9JXiD2)
	elif EALyNnv1Db4cUd8sQoZX2pmBVt7kM==TlGXWLYsV1z(u"ࠫ࠶࠶ࠧ๭"):
		import TsIdr4GvYk
		TsIdr4GvYk.NjAfaewzlX(hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠬࡥࡇࡐࡑࡊࡐࡊ࠭๮"))
		SqMHwb6X1Ph8jY7LBNkmtV4F5Jlspy(BF6QAiLUNHh7rKOugaw)
	elif EALyNnv1Db4cUd8sQoZX2pmBVt7kM==hhQwbeiNLoqFjX90fB7aG8VAs(u"࠭࠱࠵ࠩ๯"): SqMHwb6X1Ph8jY7LBNkmtV4F5Jlspy(rGPen6cSMHQkAywh8vqI9JXiD2,YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠧࡎࡇࡑ࡙ࡤࡘࡅࡗࡇࡕࡗࡊࡊ࡟ࡕࡇࡐࡔࠬ๰"))
	elif EALyNnv1Db4cUd8sQoZX2pmBVt7kM==hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠨ࠳࠸ࠫ๱"): SqMHwb6X1Ph8jY7LBNkmtV4F5Jlspy(rGPen6cSMHQkAywh8vqI9JXiD2,TlGXWLYsV1z(u"ࠩࡐࡉࡓ࡛࡟ࡂࡕࡆࡉࡓࡊࡅࡅࡡࡗࡉࡒࡖࠧ๲"))
	elif EALyNnv1Db4cUd8sQoZX2pmBVt7kM==SaB5hx3PZwXRLtKgrTfQvId(u"ࠪ࠵࠻࠭๳"): SqMHwb6X1Ph8jY7LBNkmtV4F5Jlspy(rGPen6cSMHQkAywh8vqI9JXiD2,vODxLKW5Ql6r4Fbm8(u"ࠫࡒࡋࡎࡖࡡࡇࡉࡘࡉࡅࡏࡆࡈࡈࡤ࡚ࡅࡎࡒࠪ๴"))
	elif EALyNnv1Db4cUd8sQoZX2pmBVt7kM==ZchUJdM93pTA7zG5(u"ࠬ࠷࠷ࠨ๵"): SqMHwb6X1Ph8jY7LBNkmtV4F5Jlspy(rGPen6cSMHQkAywh8vqI9JXiD2,UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"࠭ࡍࡆࡐࡘࡣࡗࡇࡎࡅࡑࡐࡍ࡟ࡋࡄࡠࡖࡈࡑࡕ࠭๶"))
	elif EALyNnv1Db4cUd8sQoZX2pmBVt7kM==PtkEvXAqif14G20QZsaSyT(u"ࠧ࠲࠺ࠪ๷"):
		ttKWoIH83b = OXsckY7RzjCag9A.getSetting(LyNiIHPOwD3hCUYEFM7(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡧ࡯ࡴࡳࡣࡷࡩࠬ๸"))
		if ttKWoIH83b: OXsckY7RzjCag9A.setSetting(EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡨࡩࡵࡴࡤࡸࡪ࠭๹"),sVzojQerUqX(u"ࠪ࠱ࠬ๺")+ttKWoIH83b)
	if EALyNnv1Db4cUd8sQoZX2pmBVt7kM in [tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠫ࠾࠭๻"),xpT28sXu051(u"ࠬ࠷࠴ࠨ๼"),ZchUJdM93pTA7zG5(u"࠭࠱࠶ࠩ๽"),CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠧ࠲࠸ࠪ๾"),y6y5HtgXO4TkUbwVZ(u"ࠨ࠳࠺ࠫ๿")]: KEPGn8jNAtmDB2yS0kZiX4MCw()
	return
def Iey5DnObB6p7ZlJ29jVCvfshzx(EGJVsZy38Xx,Toe5N9znWjQHmP4whguld,smglbwR7x2oM,y3qATZDQOch6db5WjnmrguflU,L95mrowGgdsD,zLEP9N4BOsVrXa,XiWJ2PTqvds4pBNebVrt98x,EALyNnv1Db4cUd8sQoZX2pmBVt7kM,XC10geOnQtwrs,lBz8JnYhCN3RU,XZt0CwHxU2jne8oEdrQh5MLT,HhVucpbsy12qgXY,e7wFcO9GDXRq):
	if UYetvipxsyObLZaMw3WVdAgCFEh: YHtkW17DjvoCaMs()
	if EALyNnv1Db4cUd8sQoZX2pmBVt7kM: cPTjCDRhnzUyt(EGJVsZy38Xx,Toe5N9znWjQHmP4whguld,smglbwR7x2oM,y3qATZDQOch6db5WjnmrguflU,L95mrowGgdsD,zLEP9N4BOsVrXa,XiWJ2PTqvds4pBNebVrt98x,EALyNnv1Db4cUd8sQoZX2pmBVt7kM,XC10geOnQtwrs,lBz8JnYhCN3RU,XZt0CwHxU2jne8oEdrQh5MLT,HhVucpbsy12qgXY)
	n9nIi1N7A6y8H4Tr()
	kqAyL0F4bUcl1svBPn(rGPen6cSMHQkAywh8vqI9JXiD2)
	M5qyIg2dZlm6FxH4tTPV79okNu0bCG,BBhSoAIskTHPN1MnWLGjUawZy,z1F5cTMvEk2Ngd70QRy3mqp = rGPen6cSMHQkAywh8vqI9JXiD2,BF6QAiLUNHh7rKOugaw,BF6QAiLUNHh7rKOugaw
	xOc5TlqDBghQiG2UA = ulJmMYhHLa9pVT(EGJVsZy38Xx,Toe5N9znWjQHmP4whguld,smglbwR7x2oM,y3qATZDQOch6db5WjnmrguflU,L95mrowGgdsD,zLEP9N4BOsVrXa,XiWJ2PTqvds4pBNebVrt98x,EALyNnv1Db4cUd8sQoZX2pmBVt7kM,XC10geOnQtwrs,lBz8JnYhCN3RU,e7wFcO9GDXRq,M5qyIg2dZlm6FxH4tTPV79okNu0bCG,BBhSoAIskTHPN1MnWLGjUawZy,z1F5cTMvEk2Ngd70QRy3mqp)
	PPdh6zxpSVAfNOFHJ7oGR10U,zCXZNsp6PT8Mhxnr5v0G71KaBdFR,bdYnOoSxlsAwpZWDt01F7qT,SWDcPHa03GEyls9UnN,iT7tp5u8HUbW,UdjTRFouqJDNZW3XHsKP271E,XMFrUlHy0oQgIqLWJY195K3,kqwteuoVZK25MsrFzLf6dY9 = xOc5TlqDBghQiG2UA
	if PPdh6zxpSVAfNOFHJ7oGR10U: return
	if zCXZNsp6PT8Mhxnr5v0G71KaBdFR==HtK4o2sTPgA78U(u"ࠩࡕࡉࡋࡘࡅࡔࡊࡢࡇࡆࡉࡈࡆࠩ຀"): fNqmjxDcp1Q8tPsHiKhIg20au4FzAS(hI7SkXd94fFzAHNZCQoMqEutbnWP)
	aolOvjwC6d(jXE2YHkswT8y(u"ࠪࡷࡹࡧࡲࡵࠩກ"))
	if OXsckY7RzjCag9A.getSetting(FRYcH4KL7e9gv5pEB(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡩࡶࡷࡴࡨࡧࡣࡩࡧࠪຂ")) not in [tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠬࡇࡕࡕࡑࠪ຃"),Y41NvKfOroMzGB8sEHy7wbXlc5(u"࠭ࡓࡕࡑࡓࠫຄ"),AbqCJZdWQP9j(u"ࠧࡍࡋࡐࡍ࡙ࡋࡄࠨ຅")]:
		OXsckY7RzjCag9A.setSetting(SaB5hx3PZwXRLtKgrTfQvId(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲࡭ࡺࡴࡱࡥࡤࡧ࡭࡫ࠧຆ"),tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠩࡄ࡙࡙ࡕࠧງ"))
	if not OXsckY7RzjCag9A.getSetting(JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡤ࡯ࡵࠪຈ")): OXsckY7RzjCag9A.setSetting(vODxLKW5Ql6r4Fbm8(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡥࡰࡶࠫຉ"),cl6fApKxQTzywM27g[FGTfwsjNrB8DvKSZhLIQAb1JnO])
	EA7FzO1kMZGQXDd2giB0cwLom = wA8ZcpVskTjEf5GdULPi4(EGJVsZy38Xx,Toe5N9znWjQHmP4whguld,smglbwR7x2oM,y3qATZDQOch6db5WjnmrguflU,L95mrowGgdsD,zLEP9N4BOsVrXa,XiWJ2PTqvds4pBNebVrt98x,EALyNnv1Db4cUd8sQoZX2pmBVt7kM,XC10geOnQtwrs)
	if LyNiIHPOwD3hCUYEFM7(u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧຊ") in XiWJ2PTqvds4pBNebVrt98x: BBhSoAIskTHPN1MnWLGjUawZy = rGPen6cSMHQkAywh8vqI9JXiD2
	if EGJVsZy38Xx==y6y5HtgXO4TkUbwVZ(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭຋"):
		if SWDcPHa03GEyls9UnN!=sVzojQerUqX(u"ࠧ࠯࠰ࠪຌ") and iT7tp5u8HUbW: vtTse5pbrQCKAWjdyJYiPzuOEwxlh()
		if Lwz8pPM60OCIBK7>-YYJQyRskpX8jv:
			mwZI85odUY = [FGTfwsjNrB8DvKSZhLIQAb1JnO,vODxLKW5Ql6r4Fbm8(u"࠶࠻ᐐ"),JZszNnIEMAx28Yao0yqhiXGKOPb(u"࠷࠷ᐑ"),UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"࠱࠺ᐒ"),ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"࠶࠻ᐏ"),hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"࠶࠸ᐕ"),IpC4qHXRuyNFjzWv(u"࠶࠲ᐓ"),FRYcH4KL7e9gv5pEB(u"࠷࠶ᐔ")]
			if (QKzCiBOWZus1nSv(PdkZHNBlpg2b7DmX6qRiyVa,HtK4o2sTPgA78U(u"ࠨ࡫ࡱࡸࠬຍ"),UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬຎ"),IpC4qHXRuyNFjzWv(u"ࠪࡗࡎ࡚ࡅࡔࡡࡑࡅࡒࡋࡓࠨຏ")) or lBz8JnYhCN3RU not in mwZI85odUY) and not IiCsQD91HF.bbrnyC5Bz9Vqgc0fFYuZ6QNEMvXK7:
				from TTOWYe76MF import rrAFBXq5Q2Gpnw
				dVNATb2KFHDevMlJ5YOZG = qa6vEkbJj4AhKTPlBY8(rrAFBXq5Q2Gpnw)
				PPdh6zxpSVAfNOFHJ7oGR10U = wZM73KAr9H4aV(bdYnOoSxlsAwpZWDt01F7qT,dVNATb2KFHDevMlJ5YOZG,M5qyIg2dZlm6FxH4tTPV79okNu0bCG,BBhSoAIskTHPN1MnWLGjUawZy,z1F5cTMvEk2Ngd70QRy3mqp)
				if dVNATb2KFHDevMlJ5YOZG and UdjTRFouqJDNZW3XHsKP271E:
					YMQXP2BGeK86CEb(PdkZHNBlpg2b7DmX6qRiyVa,YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠫࡒࡋࡎࡖࡕࡢࡇࡆࡉࡈࡆࡡࠪຐ")+XMFrUlHy0oQgIqLWJY195K3+CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠬࡥࠧຑ")+kqwteuoVZK25MsrFzLf6dY9,bdYnOoSxlsAwpZWDt01F7qT,dVNATb2KFHDevMlJ5YOZG,PNjZMS7nxa9clHusz1)
			else:
				dsBkaDQ16gtSnbrUXvl.addDirectoryItem(Lwz8pPM60OCIBK7,ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠩຒ")+M8hQu61Uid+JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠧ࠰ࡁࡷࡽࡵ࡫࠽࡭࡫ࡱ࡯ࠫࡳ࡯ࡥࡧࡀ࠹࠵࠶ࠧຓ"),OOYtyXB3o8K.ListItem(zmcGfOdvAjsELeJlP(u"ࠨๆา๎่ࠦๅีๅ็อ๋ࠥๆࠡฮ๊หื้ࠧດ")))
				dsBkaDQ16gtSnbrUXvl.addDirectoryItem(Lwz8pPM60OCIBK7,ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠬຕ")+M8hQu61Uid+tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠪ࠳ࡄࡺࡹࡱࡧࡀࡰ࡮ࡴ࡫ࠧ࡯ࡲࡨࡪࡃ࠵࠱࠲ࠪຖ"),OOYtyXB3o8K.ListItem(tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠫศ็สฮࠢ็ฮ็ืรࠡษ็ฮๆอี๋ๆࠪທ")))
			dsBkaDQ16gtSnbrUXvl.endOfDirectory(Lwz8pPM60OCIBK7,M5qyIg2dZlm6FxH4tTPV79okNu0bCG,BBhSoAIskTHPN1MnWLGjUawZy,z1F5cTMvEk2Ngd70QRy3mqp)
	return
def fNqmjxDcp1Q8tPsHiKhIg20au4FzAS(W608CZLsD4ecpzUOKYT5SQVjRfMyIA):
	if GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠬࡓࡅࡔࡕࡄࡋࡊ࡙ࠧຘ") in str(RR80SbLUCimJrMV): return
	aR1xW0Dsnlbumi5A = BF6QAiLUNHh7rKOugaw if W608CZLsD4ecpzUOKYT5SQVjRfMyIA else rGPen6cSMHQkAywh8vqI9JXiD2
	if not aR1xW0Dsnlbumi5A:
		po7456sPxUuka = X3IPqeaH8zOYn(OXsckY7RzjCag9A.getSetting(ZchUJdM93pTA7zG5(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡳࡥࡴࡵࡤ࡫ࡪࡹࠧນ")))
		po7456sPxUuka = FGTfwsjNrB8DvKSZhLIQAb1JnO if not po7456sPxUuka else int(po7456sPxUuka)
		if not po7456sPxUuka or not FGTfwsjNrB8DvKSZhLIQAb1JnO<=pwXCQWuGUMka2hFN-po7456sPxUuka<=W608CZLsD4ecpzUOKYT5SQVjRfMyIA: aR1xW0Dsnlbumi5A = rGPen6cSMHQkAywh8vqI9JXiD2
	if not aR1xW0Dsnlbumi5A:
		XrPHQb9URNVlqME7jKBWxT4 = OXsckY7RzjCag9A.getSetting(XrTw01KtLzbpoyMf(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡱࡪࡹࡳࡢࡩࡨࡷࠬບ"))
		if XrPHQb9URNVlqME7jKBWxT4 in [iiy37aKq0pCEIOwfcTh61xb4U,GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠨࡑࡏࡈࡤ࡚ࡏࡠࡇࡕࡖࡔࡘࠧປ"),CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠩࡑࡉ࡜ࡥࡔࡐࡡࡈࡖࡗࡕࡒࠨຜ")]: aR1xW0Dsnlbumi5A = rGPen6cSMHQkAywh8vqI9JXiD2
	if not aR1xW0Dsnlbumi5A:
		IeMmj7wqPN8 = OXsckY7RzjCag9A.getSetting(XrTw01KtLzbpoyMf(u"ࠪࡥࡻ࠴ࡰࡳ࡫ࡹࡷ࠶࠭ຝ"))
		FZ0zy7Cgeo1UjkR,AlI5YdVoWgZyP = gkdxoKzQVY6C7OGF3JvM9Xq(PdkZHNBlpg2b7DmX6qRiyVa)
		AlI5YdVoWgZyP.execute(HtK4o2sTPgA78U(u"ࠫࡕࡘࡁࡈࡏࡄࠤࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡡ࡬ࡨࡀ࠭ພ"))
		d18pEhPG35UZxSyW2kcqgKTR = str(AlI5YdVoWgZyP.fetchall()[EMO8gy4LrsNTh0knZwpSeU75APW(u"࠴ᐖ")][EMO8gy4LrsNTh0knZwpSeU75APW(u"࠴ᐖ")])
		FZ0zy7Cgeo1UjkR.close()
		StbuiQDrJk = WWbKa0cgvFOURDoHIEV3uhipsJ96.md5(IpC4qHXRuyNFjzWv(u"࠺ᐗ")*IeMmj7wqPN8.encode(df6QpwGxuJVZr)).hexdigest()
		StbuiQDrJk = WWbKa0cgvFOURDoHIEV3uhipsJ96.md5(yJeq1BjfiO4NFuwIEzxVLK6b9s(u"࠷࠴ᐘ")*StbuiQDrJk.encode(df6QpwGxuJVZr)).hexdigest()
		StbuiQDrJk = WWbKa0cgvFOURDoHIEV3uhipsJ96.md5(YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"࠱࠺ᐙ")*StbuiQDrJk.encode(df6QpwGxuJVZr)).hexdigest()
		StbuiQDrJk = str(int(StbuiQDrJk[YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"࠵ᐛ"):hhQwbeiNLoqFjX90fB7aG8VAs(u"࠴࠶ᐜ")],FRYcH4KL7e9gv5pEB(u"࠵࠻ᐝ")))[:L90uqo28xEKSFUwYTcm51yRWZIkft(u"࠺ᐚ")]
		if StbuiQDrJk!=d18pEhPG35UZxSyW2kcqgKTR: aR1xW0Dsnlbumi5A = rGPen6cSMHQkAywh8vqI9JXiD2
	if aR1xW0Dsnlbumi5A: QJpT1XnkNomcWeiB8M7(BF6QAiLUNHh7rKOugaw)
	return
def wA8ZcpVskTjEf5GdULPi4(EGJVsZy38Xx,Toe5N9znWjQHmP4whguld,smglbwR7x2oM,y3qATZDQOch6db5WjnmrguflU,L95mrowGgdsD,zLEP9N4BOsVrXa,XiWJ2PTqvds4pBNebVrt98x,EALyNnv1Db4cUd8sQoZX2pmBVt7kM,XC10geOnQtwrs):
	lBz8JnYhCN3RU = int(y3qATZDQOch6db5WjnmrguflU)
	xl0I9SsgtGu5E = int(lBz8JnYhCN3RU//hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"࠶࠶ᐞ"))
	if   xl0I9SsgtGu5E==FGTfwsjNrB8DvKSZhLIQAb1JnO:  from lpTiXPCdwE 		import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==YYJQyRskpX8jv:  from Ibg5KoZMAz 		import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==nI2JK1RfsGWNY3OarEeMQZ:  from e8Al5YLw6y 		import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,zLEP9N4BOsVrXa,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==iiCWLaJREureAlOkv:  from MMz7bIHjBQ 		import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,zLEP9N4BOsVrXa,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==pZWli1xqfVtvzuSU6ImNw53gBFsh:  from xfhMZiYNPV 		import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x,zLEP9N4BOsVrXa)
	elif xl0I9SsgtGu5E==L90uqo28xEKSFUwYTcm51yRWZIkft(u"࠻ᐟ"):  from BHSfLIuQ1j 		import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==vODxLKW5Ql6r4Fbm8(u"࠶ᐠ"):  from glAOIw1BXa 		import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==SaB5hx3PZwXRLtKgrTfQvId(u"࠸ᐡ"):  from vr5aHp1ofi 			import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==xpT28sXu051(u"࠺ᐢ"):  from B0BLI6vrM7 		import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==MgP8OjoaiWQEVG59(u"࠼ᐣ"):  from MMEJAz3Onk		import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"࠵࠵ᐤ"): from XgsrtIMz4H 		import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM)
	elif xl0I9SsgtGu5E==EMO8gy4LrsNTh0knZwpSeU75APW(u"࠶࠷ᐥ"): from vvcSWtyJxw 		import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==xpT28sXu051(u"࠷࠲ᐦ"): from aY5JxSDGNE 		import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,zLEP9N4BOsVrXa,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==sVzojQerUqX(u"࠱࠴ᐧ"): from AIu94zF6tx		import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,zLEP9N4BOsVrXa,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==FRYcH4KL7e9gv5pEB(u"࠲࠶ᐨ"): from QGlgpcTFhx 		import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x,EGJVsZy38Xx,zLEP9N4BOsVrXa,Toe5N9znWjQHmP4whguld,L95mrowGgdsD)
	elif xl0I9SsgtGu5E==CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"࠳࠸ᐩ"): from lpTiXPCdwE 		import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==Y41NvKfOroMzGB8sEHy7wbXlc5(u"࠴࠺ᐪ"): from crqKbo8YuV		import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x,zLEP9N4BOsVrXa,XC10geOnQtwrs)
	elif xl0I9SsgtGu5E==EMO8gy4LrsNTh0knZwpSeU75APW(u"࠵࠼ᐫ"): from lpTiXPCdwE 		import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==vODxLKW5Ql6r4Fbm8(u"࠶࠾ᐬ"): from Pa0Od3Vrio		import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==sVzojQerUqX(u"࠷࠹ᐭ"): from lpTiXPCdwE 		import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==MgP8OjoaiWQEVG59(u"࠲࠱ᐮ"): from nmXJxRS1VU		import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==yJeq1BjfiO4NFuwIEzxVLK6b9s(u"࠳࠳ᐯ"): from zYRenU6D40	import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==sVzojQerUqX(u"࠴࠵ᐰ"): from s36vCDEJ0P		import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,zLEP9N4BOsVrXa,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==PtkEvXAqif14G20QZsaSyT(u"࠵࠷ᐱ"): from uUbDljY0SN			import aSZHGchAUqxirb2ztEK5wWo; EA7FzO1kMZGQXDd2giB0cwLom = aSZHGchAUqxirb2ztEK5wWo(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x,EGJVsZy38Xx,zLEP9N4BOsVrXa,XC10geOnQtwrs)
	elif xl0I9SsgtGu5E==ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"࠶࠹ᐲ"): from oIeuaPmibU 			import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==y6y5HtgXO4TkUbwVZ(u"࠷࠻ᐳ"): from sRIEkLr634 		import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==AbqCJZdWQP9j(u"࠸࠶ᐴ"): from TTOWYe76MF 			import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"࠲࠸ᐵ"): from LTAR3BSjNg		import aSZHGchAUqxirb2ztEK5wWo; EA7FzO1kMZGQXDd2giB0cwLom = aSZHGchAUqxirb2ztEK5wWo(lBz8JnYhCN3RU,EALyNnv1Db4cUd8sQoZX2pmBVt7kM)
	elif xl0I9SsgtGu5E==FRYcH4KL7e9gv5pEB(u"࠳࠺ᐶ"): from uUbDljY0SN			import aSZHGchAUqxirb2ztEK5wWo; EA7FzO1kMZGQXDd2giB0cwLom = aSZHGchAUqxirb2ztEK5wWo(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x,EGJVsZy38Xx,zLEP9N4BOsVrXa,XC10geOnQtwrs)
	elif xl0I9SsgtGu5E==sVzojQerUqX(u"࠴࠼ᐷ"): from etmINUEDQr	import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,zLEP9N4BOsVrXa,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==HtK4o2sTPgA78U(u"࠶࠴ᐸ"): from nnFQHctSEG		import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==L90uqo28xEKSFUwYTcm51yRWZIkft(u"࠷࠶ᐹ"): from nnOsIgCyuK		import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==jXE2YHkswT8y(u"࠸࠸ᐺ"): from FiWJ1oQ39C		import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==GGx4qyKP1vUtRghsE2WfaHLMXZ(u"࠹࠳ᐻ"): from KKZupF6iA4		import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM)
	elif xl0I9SsgtGu5E==sVzojQerUqX(u"࠳࠵ᐼ"): from lpTiXPCdwE 		import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==JZszNnIEMAx28Yao0yqhiXGKOPb(u"࠴࠷ᐽ"): from dS3lHm09G4		import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"࠵࠹ᐾ"): from kiFol7tQ5Y			import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==GGx4qyKP1vUtRghsE2WfaHLMXZ(u"࠶࠻ᐿ"): from sZEufTSeXb			import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"࠷࠽ᑀ"): from Qh3dFi9vNj 		import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==vODxLKW5Ql6r4Fbm8(u"࠸࠿ᑁ"): from j9jVLNUiMD		import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"࠺࠰ᑂ"): from LATecKt1Ra	import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x,EGJVsZy38Xx,zLEP9N4BOsVrXa)
	elif xl0I9SsgtGu5E==HtK4o2sTPgA78U(u"࠴࠲ᑃ"): from LATecKt1Ra	import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x,EGJVsZy38Xx,zLEP9N4BOsVrXa)
	elif xl0I9SsgtGu5E==L90uqo28xEKSFUwYTcm51yRWZIkft(u"࠵࠴ᑄ"): from WYuiCFZ3mU			import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==sVzojQerUqX(u"࠶࠶ᑅ"): from pfObhokENe			import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==HtK4o2sTPgA78U(u"࠷࠸ᑆ"): from nBh0GXEfrJ		import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"࠸࠺ᑇ"): from lmcNbDZW4x		import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"࠹࠼ᑈ"): from V18kA4epvm			import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==xpT28sXu051(u"࠺࠷ᑉ"): from BDYeH90xTR		import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==SaB5hx3PZwXRLtKgrTfQvId(u"࠴࠹ᑊ"): from NeR5gq8kfL		import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==MgP8OjoaiWQEVG59(u"࠵࠻ᑋ"): from G3hQr8jp5d		import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==XrTw01KtLzbpoyMf(u"࠷࠳ᑌ"): from lpTiXPCdwE 		import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==SaB5hx3PZwXRLtKgrTfQvId(u"࠸࠵ᑍ"): from QQYEGou3rO 		import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"࠹࠷ᑎ"): from QQYEGou3rO 		import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==yJeq1BjfiO4NFuwIEzxVLK6b9s(u"࠺࠹ᑏ"): from TTOWYe76MF 			import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==y6y5HtgXO4TkUbwVZ(u"࠻࠴ᑐ"): from TsIdr4GvYk	import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x,zLEP9N4BOsVrXa)
	elif xl0I9SsgtGu5E==vODxLKW5Ql6r4Fbm8(u"࠵࠶ᑑ"): from MlFkyhP502 		import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==AbqCJZdWQP9j(u"࠶࠸ᑒ"): from ZwBdxCKtac		import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==vODxLKW5Ql6r4Fbm8(u"࠷࠺ᑓ"): from i1tWTclz6O		import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==AbqCJZdWQP9j(u"࠸࠼ᑔ"): from lBf6NGa9QS		import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==XrTw01KtLzbpoyMf(u"࠹࠾ᑕ"): from gcNIbG3lhe		import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==yJeq1BjfiO4NFuwIEzxVLK6b9s(u"࠻࠶ᑖ"): from i6FvBKHolR			import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==LyNiIHPOwD3hCUYEFM7(u"࠼࠱ᑗ"): from xkPupjMbOt			import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"࠶࠳ᑘ"): from vjJHClWtZz		import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==L90uqo28xEKSFUwYTcm51yRWZIkft(u"࠷࠵ᑙ"): from IWJrAmlTkb	import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==JZszNnIEMAx28Yao0yqhiXGKOPb(u"࠸࠷ᑚ"): from CJPfXMgbsv			import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"࠹࠹ᑛ"): from c9SbFCj6mZ			import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==TlGXWLYsV1z(u"࠺࠻ᑜ"): from d1HyMeiw3x			import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==vODxLKW5Ql6r4Fbm8(u"࠻࠽ᑝ"): from ttolzyQDF7		import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==TlGXWLYsV1z(u"࠼࠸ᑞ"): from ZYNsy6CK4u		import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"࠶࠺ᑟ"): from GG36Ij5SxU		import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==TlGXWLYsV1z(u"࠸࠲ᑠ"): from WWA4uXG7hb			import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"࠹࠴ᑡ"): from FwKQq7S2Ce			import aSZHGchAUqxirb2ztEK5wWo; EA7FzO1kMZGQXDd2giB0cwLom = aSZHGchAUqxirb2ztEK5wWo(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x,EGJVsZy38Xx,zLEP9N4BOsVrXa,XC10geOnQtwrs)
	elif xl0I9SsgtGu5E==ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"࠺࠶ᑢ"): from FwKQq7S2Ce			import aSZHGchAUqxirb2ztEK5wWo; EA7FzO1kMZGQXDd2giB0cwLom = aSZHGchAUqxirb2ztEK5wWo(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x,EGJVsZy38Xx,zLEP9N4BOsVrXa,XC10geOnQtwrs)
	elif xl0I9SsgtGu5E==LyNiIHPOwD3hCUYEFM7(u"࠻࠸ᑣ"): from wXO1vzDjd6	import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==JZszNnIEMAx28Yao0yqhiXGKOPb(u"࠼࠺ᑤ"): from gUIPklvSzK		import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU)
	elif xl0I9SsgtGu5E==FRYcH4KL7e9gv5pEB(u"࠽࠵ᑥ"): from gUIPklvSzK		import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU)
	elif xl0I9SsgtGu5E==HtK4o2sTPgA78U(u"࠷࠷ᑦ"): from crqKbo8YuV		import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x,zLEP9N4BOsVrXa,XC10geOnQtwrs)
	elif xl0I9SsgtGu5E==PtkEvXAqif14G20QZsaSyT(u"࠸࠹ᑧ"): from gpJT7OU15G 		import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,zLEP9N4BOsVrXa,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==EMO8gy4LrsNTh0knZwpSeU75APW(u"࠹࠻ᑨ"): from ibaL4O16jq 		import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,zLEP9N4BOsVrXa,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==JZszNnIEMAx28Yao0yqhiXGKOPb(u"࠺࠽ᑩ"): from eScC4ZYT7g 		import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,zLEP9N4BOsVrXa,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==L90uqo28xEKSFUwYTcm51yRWZIkft(u"࠼࠵ᑪ"): from PrqXjGnsUS 		import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,zLEP9N4BOsVrXa,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==FRYcH4KL7e9gv5pEB(u"࠽࠷ᑫ"): from Q5ZGqRs2PD 		import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==sVzojQerUqX(u"࠾࠲ᑬ"): from Iwj5CaLmYO		import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,zLEP9N4BOsVrXa,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"࠸࠴ᑭ"): from UUycmu7XjD		import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==SaB5hx3PZwXRLtKgrTfQvId(u"࠹࠶ᑮ"): from YgcvUa8k0q		import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==MgP8OjoaiWQEVG59(u"࠺࠸ᑯ"): from LXHsjirCZ6		import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==GGx4qyKP1vUtRghsE2WfaHLMXZ(u"࠻࠺ᑰ"): from P9jEqIH3sC		import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==uuExaKGL7UONtevRd(u"࠼࠼ᑱ"): from z0WKEVAsdr			import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"࠽࠾ᑲ"): from PPb6MJwGTd			import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==AbqCJZdWQP9j(u"࠾࠹ᑳ"): from E2QSq0Vila		import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==JZszNnIEMAx28Yao0yqhiXGKOPb(u"࠹࠱ᑴ"): from t1y7wWPiYU	import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==y6y5HtgXO4TkUbwVZ(u"࠺࠳ᑵ"): from paQ0bIuUzL		import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==yJeq1BjfiO4NFuwIEzxVLK6b9s(u"࠻࠵ᑶ"): from ZDOsRb7T8t		import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"࠼࠷ᑷ"): from z1zYM6yWUf		import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"࠽࠹ᑸ"): from gyVpCIimfU			import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==zmcGfOdvAjsELeJlP(u"࠾࠻ᑹ"): from PB1lXgx3tI			import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==yJeq1BjfiO4NFuwIEzxVLK6b9s(u"࠿࠶ᑺ"): from P7siNyYAtg		import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==TlGXWLYsV1z(u"࠹࠸ᑻ"): from ssRAGfmY8E		import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==vODxLKW5Ql6r4Fbm8(u"࠺࠺ᑼ"): from bQKFlmfaCt		import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"࠻࠼ᑽ"): from xXsrnOe40o		import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==IpC4qHXRuyNFjzWv(u"࠴࠴࠵ᑾ"): from Yb3dMo1ZF5		import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==yJeq1BjfiO4NFuwIEzxVLK6b9s(u"࠵࠵࠷ᑿ"): from BBV2zlryTP	import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==ZchUJdM93pTA7zG5(u"࠶࠶࠲ᒀ"): from lpTiXPCdwE 		import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"࠷࠰࠴ᒁ"): from fflA4BGKvW	import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==GGx4qyKP1vUtRghsE2WfaHLMXZ(u"࠱࠱࠶ᒂ"): from ZEJASPVH72		import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==HtK4o2sTPgA78U(u"࠲࠲࠸ᒃ"): from ZdY3Dn5pLk			import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==LyNiIHPOwD3hCUYEFM7(u"࠳࠳࠺ᒄ"): from p4p1fGStCP		import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x)
	elif xl0I9SsgtGu5E==sVzojQerUqX(u"࠴࠴࠼ᒅ"): from xGr1HzD4fV		import sHVM8YchrDjZAJ7	; EA7FzO1kMZGQXDd2giB0cwLom = sHVM8YchrDjZAJ7(lBz8JnYhCN3RU,smglbwR7x2oM,XiWJ2PTqvds4pBNebVrt98x)
	else: EA7FzO1kMZGQXDd2giB0cwLom = None
	return EA7FzO1kMZGQXDd2giB0cwLom
def owBxZQnetHJ0rTyIP3ivq(RRLYX967TCPfySDoeF8pV3gANMGWuQ,LXSBswmknoDzdT1hQqlUie,VamqUtbfFn6MANy,showDialogs):
	ekEOd3mqAThaBDUoIrntuGRjYW = VamqUtbfFn6MANy.split(GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠬ࠳ࠧຟ"),YYJQyRskpX8jv)[FGTfwsjNrB8DvKSZhLIQAb1JnO] if YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"࠭࠭ࠨຠ") in VamqUtbfFn6MANy else VamqUtbfFn6MANy
	if not showDialogs or VamqUtbfFn6MANy in LJCPyc4vO8t3d: return BF6QAiLUNHh7rKOugaw
	TUAvjq9C0NHBiWnM6mEgIr4Sct8x = OXsckY7RzjCag9A.getSetting(PtkEvXAqif14G20QZsaSyT(u"ࠧࡢࡸ࠱ࡰࡦࡴࡧࡶࡣࡪࡩ࠳ࡺࡲࡢࡰࡶࡰࡦࡺࡥࠨມ"))
	OXsckY7RzjCag9A.setSetting(GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠨࡣࡹ࠲ࡱࡧ࡮ࡨࡷࡤ࡫ࡪ࠴ࡴࡳࡣࡱࡷࡱࡧࡴࡦࠩຢ"),iiy37aKq0pCEIOwfcTh61xb4U)
	cu39CLRQqa21XP5GMIyiE68WTzgp = RRLYX967TCPfySDoeF8pV3gANMGWuQ in [hhQwbeiNLoqFjX90fB7aG8VAs(u"࠷ᒉ"),uuExaKGL7UONtevRd(u"࠶࠷࠰࠱࠳ᒇ"),EMO8gy4LrsNTh0knZwpSeU75APW(u"࠵࠶࠶࠰࠳ᒆ"),HtK4o2sTPgA78U(u"࠷࠰࠱࠷࠷ᒈ")]
	wnB8p6riCJoQ9laf34mvRUYS = LXSBswmknoDzdT1hQqlUie.lower()
	xxaDUTZKIt5cq7SRJo = RRLYX967TCPfySDoeF8pV3gANMGWuQ in [FGTfwsjNrB8DvKSZhLIQAb1JnO,yJeq1BjfiO4NFuwIEzxVLK6b9s(u"࠴࠴࠹ᒌ"),XrTw01KtLzbpoyMf(u"࠲࠲࠳࠺࠶ᒊ"),AbqCJZdWQP9j(u"࠳࠴࠵ᒋ")]
	a9hBYcdTX4bIPqJvne2jm = YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠩࡥࡰࡴࡩ࡫ࡦࡦࠣࡦࡾࠦࡣ࡭ࡱࡸࡨ࡫ࡲࡡࡳࡧࠪຣ") in wnB8p6riCJoQ9laf34mvRUYS
	tpr0cm4NjB1os = zmcGfOdvAjsELeJlP(u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠤࡧࡿࠠ࠶ࠢࡶࡩࡨࡵ࡮ࡥࡵࠣࡦࡷࡵࡷࡴࡧࡵࠤࡨ࡮ࡥࡤ࡭ࠪ຤") in wnB8p6riCJoQ9laf34mvRUYS
	oj1lFrTx2KNm5guADRzW9SeLZ8c7dP = tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠫࡧࡲ࡯ࡤ࡭ࡨࡨࠥࡨࡹࠡࡴࡨࡧࡦࡶࡴࡤࡪࡤࠫລ") in wnB8p6riCJoQ9laf34mvRUYS
	QuqzJVsn8hr = y6y5HtgXO4TkUbwVZ(u"ࠬࡨ࡬ࡰࡥ࡮ࡩࡩࠦࡢࡺࠢࡦࡰࡴࡻࡤࡧ࡮ࡤࡶࡪࠦࡳࡦࡥࡸࡶ࡮ࡺࡹࠡࡥ࡫ࡩࡨࡱࠧ຦") in wnB8p6riCJoQ9laf34mvRUYS
	ULsxfNwT4Akv3cSE8gmrXB6 = OXsckY7RzjCag9A.getSetting(JZszNnIEMAx28Yao0yqhiXGKOPb(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡸࡷࡪࡶࡲࡰࡺࡼࠫວ"))
	SZNw0txeoyrsjiAUn = OXsckY7RzjCag9A.getSetting(ZchUJdM93pTA7zG5(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡹࡸ࡫ࡤ࡯ࡵࠪຨ"))
	B7HdVcr4OGF = yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠨใื่ࠥ็๊ࠡีะฬࠥอไึใะอ๋ࠥๆࠡษ็ษ๋ะั็ฬࠪຩ")
	ccXsbUGk8rZnVqjLI = IpC4qHXRuyNFjzWv(u"ࠩࡈࡶࡷࡵࡲࠡࠩສ")+str(RRLYX967TCPfySDoeF8pV3gANMGWuQ)+YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠪ࠾ࠥ࠭ຫ")+LXSBswmknoDzdT1hQqlUie
	ccXsbUGk8rZnVqjLI = a9I3YZjc6ySDPE4Kp(ccXsbUGk8rZnVqjLI)
	if xxaDUTZKIt5cq7SRJo or a9hBYcdTX4bIPqJvne2jm or tpr0cm4NjB1os or oj1lFrTx2KNm5guADRzW9SeLZ8c7dP or QuqzJVsn8hr: B7HdVcr4OGF += sVzojQerUqX(u"ࠫࠥ࠴ࠠศๆ่์็฿ࠠโ์๊ࠤาาศุࠡาࠤ่๎ฯู๋่ࠢิื็ࠡษ็ษ๋ะั็ฬࠣห้ิวึࠢห็ࠥษ่ࠡสส่๊๎โฺ࡞ࡱࠫຬ")
	if cu39CLRQqa21XP5GMIyiE68WTzgp: B7HdVcr4OGF += UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠬࠦ࠮ࠡๆา๎่ࠦฮุลࠣࡈࡓ้࡙ࠠ็฼๊ฬํࠠห฻ำีࠥะัอ็ฬࠤฬูๅࠡษ็้ํู่ࠡว็ํࠥืโๆ้࡟ࡲࠬອ")
	ccXsbUGk8rZnVqjLI = OTlVEGYPSxsNaBdXUucqA3+PSwfZcdRYhpl5Igqz8xOEk67+ccXsbUGk8rZnVqjLI+YoQW601K4fMJcsreDnGVE5wUZIy7
	if ULsxfNwT4Akv3cSE8gmrXB6==ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"࠭ࡁࡔࡍࠪຮ") or SZNw0txeoyrsjiAUn==xpT28sXu051(u"ࠧࡂࡕࡎࠫຯ"):
		B7HdVcr4OGF += OTlVEGYPSxsNaBdXUucqA3+aqEsMBckT2bunGHfl48Wip+ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠨ้็ࠤฯื๊ะࠢฦ๊ࠥ๐อศ๊็ࠤฬ๊ศา่ส้ัࠦลึๆสัࠥอไๆึๆ่ฮࠦ࠮࠯ࠢฦ้ࠥะั๋ัࠣษึูวๅࠢิืฬ๊ษࠡล๋ࠤำ฽รࠡว็ํࠥอไๆสิ้ัࠦฟࠢࠣࠪະ")+YoQW601K4fMJcsreDnGVE5wUZIy7
	gI80r9PwlyQ3HOkFjRYWG = BF6QAiLUNHh7rKOugaw
	if ULsxfNwT4Akv3cSE8gmrXB6==ZchUJdM93pTA7zG5(u"ࠩࡄࡗࡐ࠭ັ") or SZNw0txeoyrsjiAUn==XrTw01KtLzbpoyMf(u"ࠪࡅࡘࡑࠧາ"):
		kCWluLqaQTjbyoOZt0 = Ny92sqomMkizpgKV1(Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫຳ"),xpT28sXu051(u"ࠬิั้ฮࠪິ"),hhQwbeiNLoqFjX90fB7aG8VAs(u"࠭ลาีส่๊ࠥไๆสิ้ั࠭ີ"),GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠧหื็๎าࠦวๅ็ื็้ฯࠧຶ"),ekEOd3mqAThaBDUoIrntuGRjYW+jHLaUg49SXC6JyTM+aanoXVLTZqsIwitBdY0kcJS794FDg(ekEOd3mqAThaBDUoIrntuGRjYW),B7HdVcr4OGF+OTlVEGYPSxsNaBdXUucqA3+ccXsbUGk8rZnVqjLI)
		if kCWluLqaQTjbyoOZt0==YYJQyRskpX8jv:
			from lpTiXPCdwE import fmS1GJHNpqKyxE7u5bA
			fmS1GJHNpqKyxE7u5bA()
		elif kCWluLqaQTjbyoOZt0==nI2JK1RfsGWNY3OarEeMQZ: gI80r9PwlyQ3HOkFjRYWG = rGPen6cSMHQkAywh8vqI9JXiD2
	else: bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,ekEOd3mqAThaBDUoIrntuGRjYW+jHLaUg49SXC6JyTM+aanoXVLTZqsIwitBdY0kcJS794FDg(ekEOd3mqAThaBDUoIrntuGRjYW),B7HdVcr4OGF,ccXsbUGk8rZnVqjLI)
	OXsckY7RzjCag9A.setSetting(XrTw01KtLzbpoyMf(u"ࠨࡣࡹ࠲ࡱࡧ࡮ࡨࡷࡤ࡫ࡪ࠴ࡴࡳࡣࡱࡷࡱࡧࡴࡦࠩື"),TUAvjq9C0NHBiWnM6mEgIr4Sct8x)
	return gI80r9PwlyQ3HOkFjRYWG
def FkOnysh4X7mNU9(MI4PnAc5isXpWyJN=BF6QAiLUNHh7rKOugaw,iqXFfwSJzxg=[]):
	oJdt5fAXVw = [NWDbjPABRxu,v05aOkM7NXBHuT3UpAdiPq4]+iqXFfwSJzxg
	for VBb0cK9HdXsp5ouJ17vhewL6GRztn in wkMR5x1gTWEQIc6qHCa.listdir(StqmrCIJX4T623w5j9NEonxfQ):
		if MI4PnAc5isXpWyJN and (VBb0cK9HdXsp5ouJ17vhewL6GRztn.startswith(XrTw01KtLzbpoyMf(u"ࠩ࡬ࡴࡹࡼຸࠧ")) or VBb0cK9HdXsp5ouJ17vhewL6GRztn.startswith(SaB5hx3PZwXRLtKgrTfQvId(u"ࠪࡱ࠸ࡻູࠧ"))): continue
		if VBb0cK9HdXsp5ouJ17vhewL6GRztn.startswith(y6y5HtgXO4TkUbwVZ(u"ࠫ࡫࡯࡬ࡦࡡ຺ࠪ")): continue
		x32ZVgJ6vM0hCHyuKb7tsNT5mOA = wkMR5x1gTWEQIc6qHCa.path.join(StqmrCIJX4T623w5j9NEonxfQ,VBb0cK9HdXsp5ouJ17vhewL6GRztn)
		if x32ZVgJ6vM0hCHyuKb7tsNT5mOA in oJdt5fAXVw: continue
		try: wkMR5x1gTWEQIc6qHCa.remove(x32ZVgJ6vM0hCHyuKb7tsNT5mOA)
		except: pass
	if yBIA5N98RmP7pdzeS3s0gOH not in oJdt5fAXVw: TAkeulImazNdJwE9(yBIA5N98RmP7pdzeS3s0gOH,rGPen6cSMHQkAywh8vqI9JXiD2,BF6QAiLUNHh7rKOugaw)
	X2cQ5NCPvkMieBW7oASspFjE.sleep(y6y5HtgXO4TkUbwVZ(u"࠵ᒍ"))
	return
def KKEptMxecIgmVCqu2vrXQWn37PbyL(F9FTDvowPy,bDlzGospmi69Oy1NILPaHMWK8Z3FSw,smglbwR7x2oM,oRzlSfeE6DY0mFy37NCVxAJW1BwZtM,CZGXVf91e3KTpSDqyP6x8otlhLBam2,Kh6Op2cwaB9,showDialogs,VamqUtbfFn6MANy,D8o76IEfjVOLz=rGPen6cSMHQkAywh8vqI9JXiD2,N9Bvn0opEfM=rGPen6cSMHQkAywh8vqI9JXiD2):
	smglbwR7x2oM = smglbwR7x2oM+uuExaKGL7UONtevRd(u"ࠬࢂࡼࡎࡻࡓࡶࡴࡾࡹࡖࡴ࡯ࡁࠬົ")+F9FTDvowPy
	VVznOTKE7NDIe0HGkg = MMCJxEfv0WUek(Dxc7GChQwZ4kOlKHSbL06agnB,bDlzGospmi69Oy1NILPaHMWK8Z3FSw,smglbwR7x2oM,oRzlSfeE6DY0mFy37NCVxAJW1BwZtM,CZGXVf91e3KTpSDqyP6x8otlhLBam2,Kh6Op2cwaB9,showDialogs,VamqUtbfFn6MANy,D8o76IEfjVOLz,N9Bvn0opEfM)
	if smglbwR7x2oM in VVznOTKE7NDIe0HGkg.content: VVznOTKE7NDIe0HGkg.succeeded = BF6QAiLUNHh7rKOugaw
	if not VVznOTKE7NDIe0HGkg.succeeded:
		KEPGn8jNAtmDB2yS0kZiX4MCw()
	return VVznOTKE7NDIe0HGkg
def nxD0wE4yCtO(smglbwR7x2oM):
	VVznOTKE7NDIe0HGkg = MMCJxEfv0WUek(r3rnfZ7cdxzNFebIRaLSG6B,ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"࠭ࡇࡆࡖࠪຼ"),smglbwR7x2oM,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,rGPen6cSMHQkAywh8vqI9JXiD2,iiy37aKq0pCEIOwfcTh61xb4U,L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡉࡈࡘࡤࡖࡒࡐ࡚ࡌࡉࡘࡥࡌࡊࡕࡗ࠱࠶ࡹࡴࠨຽ"),rGPen6cSMHQkAywh8vqI9JXiD2,BF6QAiLUNHh7rKOugaw)
	XRMoPpHl3csdVfhxEAtQk = []
	if VVznOTKE7NDIe0HGkg.succeeded:
		HGQ5Ty9mlSLwed = VVznOTKE7NDIe0HGkg.content
		Ge1J70pO8yrU3cY = dEyT9xhGjolYzLCH7460w3.findall(sVzojQerUqX(u"ࠨࠢࠫ࠲࠯ࡅࠩࠡ࡞ࡧࡿ࠶࠲࠳ࡾ࡯ࡶࠫ຾"),HGQ5Ty9mlSLwed)
		if Ge1J70pO8yrU3cY: HGQ5Ty9mlSLwed = OTlVEGYPSxsNaBdXUucqA3.join(Ge1J70pO8yrU3cY)
		bH3CNaFWIPl7EDjR8gJis6mz = HGQ5Ty9mlSLwed.replace(Mge0HhFk9Ic6sm5VR,iiy37aKq0pCEIOwfcTh61xb4U).strip(OTlVEGYPSxsNaBdXUucqA3).split(OTlVEGYPSxsNaBdXUucqA3)
		XRMoPpHl3csdVfhxEAtQk = []
		for F9FTDvowPy in bH3CNaFWIPl7EDjR8gJis6mz:
			if F9FTDvowPy.count(uuExaKGL7UONtevRd(u"ࠩ࠱ࠫ຿"))==iiCWLaJREureAlOkv: XRMoPpHl3csdVfhxEAtQk.append(F9FTDvowPy)
	return XRMoPpHl3csdVfhxEAtQk
def llbsRvomZYPUBW4c0A6(*aargs):
	LKp6UAF7uRaqwDsT4f8v = ZchUJdM93pTA7zG5(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡶࡩ࠯ࡲࡵࡳࡽࡿࡳࡤࡴࡤࡴࡪ࠴ࡣࡰ࡯࠲ࡺ࠷࠵࠿ࡳࡧࡴࡹࡪࡹࡴ࠾ࡦ࡬ࡷࡵࡲࡡࡺࡲࡵࡳࡽ࡯ࡥࡴࠨࡳࡶࡴࡾࡹࡵࡻࡳࡩࡂ࡮ࡴࡵࡲࠩࡸ࡮ࡳࡥࡰࡷࡷࡁ࠶࠶࠰࠱࠲ࠩࡷࡸࡲ࠽ࡺࡧࡶࠪࡱ࡯࡭ࡪࡶࡀ࠵࠵ࠬࡣࡰࡷࡱࡸࡷࡿ࠽ࡏࡎ࠯ࡆࡊ࠲ࡄࡆ࠮ࡉࡖ࠱ࡍࡂ࠭ࡖࡕࠫເ")
	ANXbLVa1g3m = tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡸࡡࡸ࠰ࡪ࡭ࡹ࡮ࡵࡣࡷࡶࡩࡷࡩ࡯࡯ࡶࡨࡲࡹ࠴ࡣࡰ࡯࠲ࡶࡴࡵࡳࡵࡧࡵ࡯࡮ࡪ࠯ࡰࡲࡨࡲࡵࡸ࡯ࡹࡻ࡯࡭ࡸࡺ࠯࡮ࡣ࡬ࡲ࠴ࡎࡔࡕࡒࡖ࠲ࡹࡾࡴࠨແ")
	N8Ns3dQilezWTPYvXjhVKqLUGBpJZ = nxD0wE4yCtO(ANXbLVa1g3m)
	XRMoPpHl3csdVfhxEAtQk = nxD0wE4yCtO(LKp6UAF7uRaqwDsT4f8v)
	IsZxzugVh8eByN7TnPtlr = N8Ns3dQilezWTPYvXjhVKqLUGBpJZ+XRMoPpHl3csdVfhxEAtQk
	WKquk5EaNr4RzVf(P3sqIW4T8rYpjNxOXhcBk2GD,IIZ4e82HBP0oTmtOgaWY7hsMz(sQU2GnRoMwLK8CBdfzmNr4jXyO)+AbqCJZdWQP9j(u"ࠬࠦࠠࠡࡉࡲࡸࠥࡶࡲࡰࡺ࡬ࡩࡸࠦ࡬ࡪࡵࡷࠤࠥࠦ࠱ࡴࡶ࠮࠶ࡳࡪ࠺ࠡ࡝ࠣࠫໂ")+str(len(N8Ns3dQilezWTPYvXjhVKqLUGBpJZ))+hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"࠭ࠫࠨໃ")+str(len(XRMoPpHl3csdVfhxEAtQk))+YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠧࠡ࡟ࠪໄ"))
	F9FTDvowPy = OXsckY7RzjCag9A.getSetting(HtK4o2sTPgA78U(u"ࠨࡣࡹ࠲ࡵࡸ࡯ࡹࡻ࠱ࡰࡦࡹࡴࠨ໅"))
	VVznOTKE7NDIe0HGkg = AutiwYdmGMSgL3lXTD()
	OXsckY7RzjCag9A.setSetting(MgP8OjoaiWQEVG59(u"ࠩࡤࡺ࠳ࡶࡲࡰࡺࡼ࠲ࡱࡧࡳࡵࠩໆ"),iiy37aKq0pCEIOwfcTh61xb4U)
	if F9FTDvowPy or IsZxzugVh8eByN7TnPtlr:
		Tj2xuNbqyrLMeoaYJB7Sh3IiU,ff23ICqELcvWaZYm4suDzHnU = FGTfwsjNrB8DvKSZhLIQAb1JnO,tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"࠶࠶ᒎ")
		nFI1s6tOU7fz5KLyCNZcgHxklqSB9 = len(IsZxzugVh8eByN7TnPtlr)
		PIDg6GtzlySrm2YNEXZoKpMiwcCe = ff23ICqELcvWaZYm4suDzHnU
		if nFI1s6tOU7fz5KLyCNZcgHxklqSB9>PIDg6GtzlySrm2YNEXZoKpMiwcCe: GbKY71HVizjWC26J04sUuSZ5g = PIDg6GtzlySrm2YNEXZoKpMiwcCe
		else: GbKY71HVizjWC26J04sUuSZ5g = nFI1s6tOU7fz5KLyCNZcgHxklqSB9
		PjUAksOnVi = ufTX72hK8Q63jSsJiqDm5.sample(IsZxzugVh8eByN7TnPtlr,GbKY71HVizjWC26J04sUuSZ5g)
		if F9FTDvowPy: PjUAksOnVi = [F9FTDvowPy]+PjUAksOnVi
		I0Me3tryoXzNTZFa4PvDcxUH5B296 = tIvpmRVh8Z0lHS9sk4ECg6Ni5PeDWJ(BF6QAiLUNHh7rKOugaw,BF6QAiLUNHh7rKOugaw)
		QhNGvIF4YS2a5gxLAcy1k6VW3w = X2cQ5NCPvkMieBW7oASspFjE.time()
		while X2cQ5NCPvkMieBW7oASspFjE.time()-QhNGvIF4YS2a5gxLAcy1k6VW3w<=ff23ICqELcvWaZYm4suDzHnU and not I0Me3tryoXzNTZFa4PvDcxUH5B296.finishedLIST:
			if Tj2xuNbqyrLMeoaYJB7Sh3IiU<GbKY71HVizjWC26J04sUuSZ5g:
				F9FTDvowPy = PjUAksOnVi[Tj2xuNbqyrLMeoaYJB7Sh3IiU]
				I0Me3tryoXzNTZFa4PvDcxUH5B296.ztvP0T59IiMp61VJmf7(Tj2xuNbqyrLMeoaYJB7Sh3IiU,KKEptMxecIgmVCqu2vrXQWn37PbyL,F9FTDvowPy,*aargs)
			X2cQ5NCPvkMieBW7oASspFjE.sleep(SaB5hx3PZwXRLtKgrTfQvId(u"࠶࠮࠸࠷ᒏ"))
			Tj2xuNbqyrLMeoaYJB7Sh3IiU += YYJQyRskpX8jv
			WKquk5EaNr4RzVf(q1rohYuwnfpVZUa98L2CtQzmAcB,IIZ4e82HBP0oTmtOgaWY7hsMz(sQU2GnRoMwLK8CBdfzmNr4jXyO)+CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠪࠤࠥࠦࡔࡳࡻ࡬ࡲ࡬ࡀࠠࠡࠢࡓࡶࡴࡾࡹ࠻ࠢ࡞ࠤࠬ໇")+F9FTDvowPy+SaB5hx3PZwXRLtKgrTfQvId(u"ࠫࠥࡣ່ࠧ"))
		finishedLIST = I0Me3tryoXzNTZFa4PvDcxUH5B296.finishedLIST
		if finishedLIST:
			resultsDICT = I0Me3tryoXzNTZFa4PvDcxUH5B296.resultsDICT
			l0AiJYdSpHs = finishedLIST[FGTfwsjNrB8DvKSZhLIQAb1JnO]
			VVznOTKE7NDIe0HGkg = resultsDICT[l0AiJYdSpHs]
			F9FTDvowPy = PjUAksOnVi[int(l0AiJYdSpHs)]
			OXsckY7RzjCag9A.setSetting(JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠬࡧࡶ࠯ࡲࡵࡳࡽࡿ࠮࡭ࡣࡶࡸ້ࠬ"),F9FTDvowPy)
			if l0AiJYdSpHs!=FGTfwsjNrB8DvKSZhLIQAb1JnO: WKquk5EaNr4RzVf(P3sqIW4T8rYpjNxOXhcBk2GD,IIZ4e82HBP0oTmtOgaWY7hsMz(sQU2GnRoMwLK8CBdfzmNr4jXyO)+AbqCJZdWQP9j(u"࠭ࠠࠡࠢࡖࡹࡨࡩࡥࡴࡵ࠽ࠤࠥࠦࡐࡳࡱࡻࡽ࠿໊࡛ࠦࠡࠩ")+F9FTDvowPy+XrTw01KtLzbpoyMf(u"ࠧࠡ࡟໋ࠪ"))
			else: WKquk5EaNr4RzVf(P3sqIW4T8rYpjNxOXhcBk2GD,IIZ4e82HBP0oTmtOgaWY7hsMz(sQU2GnRoMwLK8CBdfzmNr4jXyO)+hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠨࠢࠣࠤࡘࡻࡣࡤࡧࡶࡷ࠿ࠦࠠࠡࡕࡤࡺࡪࡪࠠࡱࡴࡲࡼࡾࡀࠠ࡜ࠢࠪ໌")+F9FTDvowPy+xpT28sXu051(u"ࠩࠣࡡࠬໍ"))
	return VVznOTKE7NDIe0HGkg
def GGxpi7C41NyAqFgkYUVM2u(VT9g2Ghpvoden3HX0YiELNWSlyI,u9XCDzyOjNi):
	G9lJnIb1tRHfYxvj6rQePWpD = VT9g2Ghpvoden3HX0YiELNWSlyI.create_connection
	def v6mCwr7KM5Lzbx1leP0sk4RgN9ODXp(bUEYThLjvHftoAN7e,*aargs,**kkwargs):
		eNyxJLBPSwhQs,iCJN5klxdc = bUEYThLjvHftoAN7e
		ip = MtOTE0iscPV7d4bR9K512Zp(eNyxJLBPSwhQs,u9XCDzyOjNi)
		if ip: eNyxJLBPSwhQs = ip[FGTfwsjNrB8DvKSZhLIQAb1JnO]
		else:
			if u9XCDzyOjNi in cl6fApKxQTzywM27g: cl6fApKxQTzywM27g.remove(u9XCDzyOjNi)
			if cl6fApKxQTzywM27g:
				H91eQlNLStdWFfPTJxXkYVAG2z = cl6fApKxQTzywM27g[FGTfwsjNrB8DvKSZhLIQAb1JnO]
				ip = MtOTE0iscPV7d4bR9K512Zp(eNyxJLBPSwhQs,H91eQlNLStdWFfPTJxXkYVAG2z)
				if ip: eNyxJLBPSwhQs = ip[FGTfwsjNrB8DvKSZhLIQAb1JnO]
		bUEYThLjvHftoAN7e = (eNyxJLBPSwhQs,iCJN5klxdc)
		return G9lJnIb1tRHfYxvj6rQePWpD(bUEYThLjvHftoAN7e,*aargs,**kkwargs)
	VT9g2Ghpvoden3HX0YiELNWSlyI.create_connection = v6mCwr7KM5Lzbx1leP0sk4RgN9ODXp
	return G9lJnIb1tRHfYxvj6rQePWpD
def VC8whLNfAD5s9dOP(smglbwR7x2oM):
	ggBNXx8o2QqjKDtAZ6svFbfkYnW79,rTjkY6B2nqA4RMOXe = smglbwR7x2oM.split(ZchUJdM93pTA7zG5(u"ࠪ࠳ࠬ໎"))[nI2JK1RfsGWNY3OarEeMQZ],yJeq1BjfiO4NFuwIEzxVLK6b9s(u"࠸࠱ᒐ")
	if SaB5hx3PZwXRLtKgrTfQvId(u"ࠫ࠿࠭໏") in ggBNXx8o2QqjKDtAZ6svFbfkYnW79: ggBNXx8o2QqjKDtAZ6svFbfkYnW79,rTjkY6B2nqA4RMOXe = ggBNXx8o2QqjKDtAZ6svFbfkYnW79.split(TlGXWLYsV1z(u"ࠬࡀࠧ໐"))
	nSIfMdQoVGuy08UEkwme = vODxLKW5Ql6r4Fbm8(u"࠭࠯ࠨ໑")+zmcGfOdvAjsELeJlP(u"ࠧ࠰ࠩ໒").join(smglbwR7x2oM.split(ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠨ࠱ࠪ໓"))[HtK4o2sTPgA78U(u"࠴ᒑ"):])
	lHDuLVCy8kvqB6Rxh4Gs5K = XrTw01KtLzbpoyMf(u"ࠩࡊࡉ࡙ࠦࠧ໔")+nSIfMdQoVGuy08UEkwme+TlGXWLYsV1z(u"ࠪࠤࡍ࡚ࡔࡑ࠱࠴࠲࠶ࡢࡲ࡝ࡰࠪ໕")
	lHDuLVCy8kvqB6Rxh4Gs5K += GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠫࡍࡵࡳࡵ࠼ࠣࠫ໖")+ggBNXx8o2QqjKDtAZ6svFbfkYnW79+GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠬࡢࡲ࡝ࡰࠪ໗")
	lHDuLVCy8kvqB6Rxh4Gs5K += GGx4qyKP1vUtRghsE2WfaHLMXZ(u"࠭࡜ࡳ࡞ࡱࠫ໘")
	from socket import socket as lwugO16XR3UKeqpdCsfzijm,AF_INET as rmlR3OKoLGeNs,SOCK_STREAM as g5gE4wnyMf0q9dVxjTRCSciWYo
	try:
		OOwxq8BEJHisPDKZfSL3cFAY = lwugO16XR3UKeqpdCsfzijm(rmlR3OKoLGeNs,g5gE4wnyMf0q9dVxjTRCSciWYo)
		OOwxq8BEJHisPDKZfSL3cFAY.connect((ggBNXx8o2QqjKDtAZ6svFbfkYnW79,rTjkY6B2nqA4RMOXe))
		OOwxq8BEJHisPDKZfSL3cFAY.send(lHDuLVCy8kvqB6Rxh4Gs5K.encode(df6QpwGxuJVZr))
		C1it6wN48k2rhbxLQRuYOcIX = OOwxq8BEJHisPDKZfSL3cFAY.recv(LyNiIHPOwD3hCUYEFM7(u"࠷࠴࠾࠼ᒓ")*xpT28sXu051(u"࠳࠳࠶࠹ᒒ"))
		HGQ5Ty9mlSLwed = repr(C1it6wN48k2rhbxLQRuYOcIX)
	except: HGQ5Ty9mlSLwed = iiy37aKq0pCEIOwfcTh61xb4U
	return HGQ5Ty9mlSLwed
def F82MvyX4ThI6sbnA3efDoVS(Zd7faKVcIU3O1HrRPwJX5QL4,EGJVsZy38Xx):
	if xpT28sXu051(u"ࠧ࠯ࠩ໙") not in Zd7faKVcIU3O1HrRPwJX5QL4: return Zd7faKVcIU3O1HrRPwJX5QL4
	Zd7faKVcIU3O1HrRPwJX5QL4 = Zd7faKVcIU3O1HrRPwJX5QL4+xpT28sXu051(u"ࠨ࠱ࠪ໚")
	VJdaM0jmI129qNTHQOf7r8eKCPGD,NvH5x2G6rbidCn01UwTq9OEFRzo3 = Zd7faKVcIU3O1HrRPwJX5QL4.split(YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠩ࠱ࠫ໛"),Y41NvKfOroMzGB8sEHy7wbXlc5(u"࠵ᒔ"))
	NfPyExc0UOseKJ64,uu2aDehGsWqQHkjPg74Uwp = NvH5x2G6rbidCn01UwTq9OEFRzo3.split(zmcGfOdvAjsELeJlP(u"ࠪ࠳ࠬໜ"),PtkEvXAqif14G20QZsaSyT(u"࠶ᒕ"))
	zJuTb9aZGc2iLe = VJdaM0jmI129qNTHQOf7r8eKCPGD+L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠫ࠳࠭ໝ")+NfPyExc0UOseKJ64
	if EGJVsZy38Xx in [uuExaKGL7UONtevRd(u"ࠬ࡮࡯ࡴࡶࠪໞ"),JZszNnIEMAx28Yao0yqhiXGKOPb(u"࠭࡮ࡢ࡯ࡨࠫໟ")] and SaB5hx3PZwXRLtKgrTfQvId(u"ࠧ࠰ࠩ໠") in zJuTb9aZGc2iLe: zJuTb9aZGc2iLe = zJuTb9aZGc2iLe.rsplit(XrTw01KtLzbpoyMf(u"ࠨ࠱ࠪ໡"),yJeq1BjfiO4NFuwIEzxVLK6b9s(u"࠷ᒖ"))[YYJQyRskpX8jv]
	if EGJVsZy38Xx==XrTw01KtLzbpoyMf(u"ࠩࡱࡥࡲ࡫ࠧ໢") and HtK4o2sTPgA78U(u"ࠪ࠲ࠬ໣") in zJuTb9aZGc2iLe:
		lXJS4K2yGEmINYuQxODvf = zJuTb9aZGc2iLe.split(HtK4o2sTPgA78U(u"ࠫ࠳࠭໤"))
		iiKw16BHkPTU = len(lXJS4K2yGEmINYuQxODvf)
		if hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠬࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰࠪ໥") in zJuTb9aZGc2iLe: lXJS4K2yGEmINYuQxODvf = XrTw01KtLzbpoyMf(u"࠭ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱࠫ໦")
		elif iiKw16BHkPTU<=nI2JK1RfsGWNY3OarEeMQZ: lXJS4K2yGEmINYuQxODvf = lXJS4K2yGEmINYuQxODvf[FGTfwsjNrB8DvKSZhLIQAb1JnO]
		elif iiKw16BHkPTU>=iiCWLaJREureAlOkv: lXJS4K2yGEmINYuQxODvf = lXJS4K2yGEmINYuQxODvf[YYJQyRskpX8jv]
		if len(lXJS4K2yGEmINYuQxODvf)>YYJQyRskpX8jv: zJuTb9aZGc2iLe = lXJS4K2yGEmINYuQxODvf
	return zJuTb9aZGc2iLe
def Q5V784gMylUrz3T2ZhAYFKLnE(JQAEg12W8Y5vTodiPBXnIc0qUMeGp9):
	L4ndFe5QrZ8Jw2UjcEKM = repr(JQAEg12W8Y5vTodiPBXnIc0qUMeGp9.encode(df6QpwGxuJVZr)).replace(Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠢࠨࠤ໧"),iiy37aKq0pCEIOwfcTh61xb4U)
	return L4ndFe5QrZ8Jw2UjcEKM
def gcN78Bi6TD1QZsyR(uuqUHMeswmptg):
	dUkz7vcJB5XE = iiy37aKq0pCEIOwfcTh61xb4U
	if iELueYz3J1FmxaW7vc: uuqUHMeswmptg = uuqUHMeswmptg.decode(df6QpwGxuJVZr)
	from unicodedata import decomposition as gp6bWnoXtrHawFMuE0PYZvkQ8JD
	for YlAfNn9Sw1matco47CUBQ0 in uuqUHMeswmptg:
		if   YlAfNn9Sw1matco47CUBQ0==Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࡶࠩลࠫ໨"): PoIvkErUYAfF4dae3Tm7hMCpqR8 = y6y5HtgXO4TkUbwVZ(u"ࠩ࡟ࡠࡺ࠶࠶࠳࠴ࠪ໩")
		elif YlAfNn9Sw1matco47CUBQ0==EMO8gy4LrsNTh0knZwpSeU75APW(u"ࡸࠫศ࠭໪"): PoIvkErUYAfF4dae3Tm7hMCpqR8 = ZchUJdM93pTA7zG5(u"ࠫࡡࡢࡵ࠱࠸࠵࠷ࠬ໫")
		elif YlAfNn9Sw1matco47CUBQ0==ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࡺ࠭ฤࠨ໬"): PoIvkErUYAfF4dae3Tm7hMCpqR8 = MgP8OjoaiWQEVG59(u"࠭࡜࡝ࡷ࠳࠺࠷࠺ࠧ໭")
		elif YlAfNn9Sw1matco47CUBQ0==SaB5hx3PZwXRLtKgrTfQvId(u"ࡵࠨวࠪ໮"): PoIvkErUYAfF4dae3Tm7hMCpqR8 = L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠨ࡞࡟ࡹ࠵࠼࠲࠶ࠩ໯")
		elif YlAfNn9Sw1matco47CUBQ0==y6y5HtgXO4TkUbwVZ(u"ࡷࠪสࠬ໰"): PoIvkErUYAfF4dae3Tm7hMCpqR8 = IpC4qHXRuyNFjzWv(u"ࠪࡠࡡࡻ࠰࠷࠴࠹ࠫ໱")
		else:
			iA8eyD76OqU = gp6bWnoXtrHawFMuE0PYZvkQ8JD(YlAfNn9Sw1matco47CUBQ0)
			if iFBmE2MUIpSu34wsd7Rf6z in iA8eyD76OqU: PoIvkErUYAfF4dae3Tm7hMCpqR8 = y6y5HtgXO4TkUbwVZ(u"ࠫࡡࡢࡵࠨ໲")+iA8eyD76OqU.split(iFBmE2MUIpSu34wsd7Rf6z,YYJQyRskpX8jv)[YYJQyRskpX8jv]
			else:
				PoIvkErUYAfF4dae3Tm7hMCpqR8 = ZchUJdM93pTA7zG5(u"ࠬ࠶࠰࠱࠲ࠪ໳")+hex(ord(YlAfNn9Sw1matco47CUBQ0)).replace(JZszNnIEMAx28Yao0yqhiXGKOPb(u"࠭࠰ࡹࠩ໴"),iiy37aKq0pCEIOwfcTh61xb4U)
				PoIvkErUYAfF4dae3Tm7hMCpqR8 = ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠧ࡝࡞ࡸࠫ໵")+PoIvkErUYAfF4dae3Tm7hMCpqR8[-pZWli1xqfVtvzuSU6ImNw53gBFsh:]
		dUkz7vcJB5XE += PoIvkErUYAfF4dae3Tm7hMCpqR8
	dUkz7vcJB5XE = dUkz7vcJB5XE.replace(PtkEvXAqif14G20QZsaSyT(u"ࠨ࡞࡟ࡹ࠵࠼ࡃࡄࠩ໶"),ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠩ࡟ࡠࡺ࠶࠶࠵࠻ࠪ໷"))
	if iELueYz3J1FmxaW7vc: dUkz7vcJB5XE = dUkz7vcJB5XE.decode(AbqCJZdWQP9j(u"ࠪࡹࡳ࡯ࡣࡰࡦࡨࡣࡪࡹࡣࡢࡲࡨࠫ໸")).encode(df6QpwGxuJVZr)
	else: dUkz7vcJB5XE = dUkz7vcJB5XE.encode(df6QpwGxuJVZr).decode(ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠫࡺࡴࡩࡤࡱࡧࡩࡤ࡫ࡳࡤࡣࡳࡩࠬ໹"))
	return dUkz7vcJB5XE
def TTBf6S08q1NKXd5v9wa(header=zmcGfOdvAjsELeJlP(u"๊่ࠬฮหࠣห้๋แศฬํัࠬ໺"),lPY52bDgMAst4=iiy37aKq0pCEIOwfcTh61xb4U,lSAjwVdGHKvbgWcRIUEOn=BF6QAiLUNHh7rKOugaw,source=iiy37aKq0pCEIOwfcTh61xb4U):
	XiWJ2PTqvds4pBNebVrt98x = fK1BA8dxgVnZQGk6SzqX(header,lPY52bDgMAst4,type=OOYtyXB3o8K.INPUT_ALPHANUM)
	XiWJ2PTqvds4pBNebVrt98x = XiWJ2PTqvds4pBNebVrt98x.strip(iFBmE2MUIpSu34wsd7Rf6z).replace(hnVQObwUcR207fC,iFBmE2MUIpSu34wsd7Rf6z).replace(jHLaUg49SXC6JyTM,iFBmE2MUIpSu34wsd7Rf6z).replace(Wc5GekRC0HQLz7,iFBmE2MUIpSu34wsd7Rf6z)
	if not XiWJ2PTqvds4pBNebVrt98x and not lSAjwVdGHKvbgWcRIUEOn:
		WKquk5EaNr4RzVf(q1rohYuwnfpVZUa98L2CtQzmAcB,vODxLKW5Ql6r4Fbm8(u"࠭࠮࡝ࡶࡎࡩࡾࡨ࡯ࡢࡴࡧࠤࡪࡴࡴࡳࡻࠣࡧࡦࡴࡣࡦ࡮ࡨࡨ࠿ࠦࠠࠡࠤࠪ໻")+XiWJ2PTqvds4pBNebVrt98x+SaB5hx3PZwXRLtKgrTfQvId(u"ࠧࠣࠩ໼"))
		bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,AbqCJZdWQP9j(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ໽"),PtkEvXAqif14G20QZsaSyT(u"ࠩอ้ࠥหไ฻ษฤࠤฬ๊ละะส่ࠬ໾"))
		return iiy37aKq0pCEIOwfcTh61xb4U
	if XiWJ2PTqvds4pBNebVrt98x not in [iiy37aKq0pCEIOwfcTh61xb4U,iFBmE2MUIpSu34wsd7Rf6z]:
		XiWJ2PTqvds4pBNebVrt98x = XiWJ2PTqvds4pBNebVrt98x.strip(iFBmE2MUIpSu34wsd7Rf6z)
		XiWJ2PTqvds4pBNebVrt98x = gcN78Bi6TD1QZsyR(XiWJ2PTqvds4pBNebVrt98x)
	if source!=XrTw01KtLzbpoyMf(u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗࠬ໿") and IUF8hYKEGLmHDtXbuWNvnJ(JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠫࡐࡋ࡙ࡃࡑࡄࡖࡉ࠭ༀ"),iiy37aKq0pCEIOwfcTh61xb4U,[XiWJ2PTqvds4pBNebVrt98x],BF6QAiLUNHh7rKOugaw):
		WKquk5EaNr4RzVf(q1rohYuwnfpVZUa98L2CtQzmAcB,uuExaKGL7UONtevRd(u"ࠬ࠴࡜ࡵࡍࡨࡽࡧࡵࡡࡳࡦࠣࡩࡳࡺࡲࡺࠢࡥࡰࡴࡩ࡫ࡦࡦ࠽ࠤࠥࠦࠢࠨ༁")+XiWJ2PTqvds4pBNebVrt98x+MgP8OjoaiWQEVG59(u"࠭ࠢࠨ༂"))
		bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,XrTw01KtLzbpoyMf(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ༃"),SaB5hx3PZwXRLtKgrTfQvId(u"ࠨษ้ฮ้ࠥสษฬࠣ็้๋ษࠡล๋ࠤึ่ๅࠡๆ๊ࠤ฾๊วใหࠣฬศ็ไศ็่้้ࠣศศำࠣๅ็฽ࠠ࠯࠰ࠣ์์ึวࠡษ็ฬึ์วๆฮ่ࠣฬ๊ࠦิ็ะࠤออำหะาห๊ࠦ็ไาสࠤ่๊ๅศฬࠪ༄"))
		return iiy37aKq0pCEIOwfcTh61xb4U
	WKquk5EaNr4RzVf(q1rohYuwnfpVZUa98L2CtQzmAcB,HtK4o2sTPgA78U(u"ࠩ࠱ࡠࡹࡑࡥࡺࡤࡲࡥࡷࡪࠠࡦࡰࡷࡶࡾࠦࡡ࡭࡮ࡲࡻࡪࡪ࠺ࠡࠢࠣࠦࠬ༅")+XiWJ2PTqvds4pBNebVrt98x+xpT28sXu051(u"ࠪࠦࠬ༆"))
	return XiWJ2PTqvds4pBNebVrt98x
def VKTp8gacXPG9Zr4H3NQCM0O(sQU2GnRoMwLK8CBdfzmNr4jXyO,eCGwzSrqBmIv,rzR9SN7ApZuQhTDWEX3V6ga={}):
	smglbwR7x2oM,Aq65G83nIv,GmTJlQcwnYNbOWB2xXt,L4yYqE38juA2wQbs = eCGwzSrqBmIv,{},{},iiy37aKq0pCEIOwfcTh61xb4U
	if SaB5hx3PZwXRLtKgrTfQvId(u"ࠫࢁ࠭༇") in eCGwzSrqBmIv: smglbwR7x2oM,Aq65G83nIv = sFNjagPK4W(eCGwzSrqBmIv,MgP8OjoaiWQEVG59(u"ࠬࢂࠧ༈"))
	CRYAzJ5EftxV7dvWKrPbiO = list(set(list(rzR9SN7ApZuQhTDWEX3V6ga.keys())+list(Aq65G83nIv.keys())))
	for Onuh30WYrigx in CRYAzJ5EftxV7dvWKrPbiO:
		if Onuh30WYrigx in list(Aq65G83nIv.keys()): GmTJlQcwnYNbOWB2xXt[Onuh30WYrigx] = Aq65G83nIv[Onuh30WYrigx]
		else: GmTJlQcwnYNbOWB2xXt[Onuh30WYrigx] = rzR9SN7ApZuQhTDWEX3V6ga[Onuh30WYrigx]
	if JZszNnIEMAx28Yao0yqhiXGKOPb(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ༉") not in CRYAzJ5EftxV7dvWKrPbiO: GmTJlQcwnYNbOWB2xXt[YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ༊")] = FgJLkYac7lQxEbs()
	if JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ་") not in CRYAzJ5EftxV7dvWKrPbiO: GmTJlQcwnYNbOWB2xXt[zmcGfOdvAjsELeJlP(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ༌")] = F82MvyX4ThI6sbnA3efDoVS(smglbwR7x2oM,CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠪࡹࡷࡲࠧ།"))
	if ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠫࡆࡩࡣࡦࡲࡷ࠱ࡑࡧ࡮ࡨࡷࡤ࡫ࡪ࠭༎") not in CRYAzJ5EftxV7dvWKrPbiO: GmTJlQcwnYNbOWB2xXt[zmcGfOdvAjsELeJlP(u"ࠬࡇࡣࡤࡧࡳࡸ࠲ࡒࡡ࡯ࡩࡸࡥ࡬࡫ࠧ༏")] = L90uqo28xEKSFUwYTcm51yRWZIkft(u"࠭ࡥ࡯࠯ࡘࡗ࠱࡫࡮࠼ࡳࡀ࠴࠳࠿ࠧ༐")
	for Onuh30WYrigx in list(GmTJlQcwnYNbOWB2xXt.keys()): L4yYqE38juA2wQbs += xpT28sXu051(u"ࠧࠧࠩ༑")+Onuh30WYrigx+L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠨ࠿ࠪ༒")+GmTJlQcwnYNbOWB2xXt[Onuh30WYrigx]
	if L4yYqE38juA2wQbs: L4yYqE38juA2wQbs = TlGXWLYsV1z(u"ࠩࡿࠫ༓")+L4yYqE38juA2wQbs[YYJQyRskpX8jv:]
	VVznOTKE7NDIe0HGkg = MMCJxEfv0WUek(Qfob9ThC6ryqKkYZ,MgP8OjoaiWQEVG59(u"ࠪࡋࡊ࡚ࠧ༔"),smglbwR7x2oM,iiy37aKq0pCEIOwfcTh61xb4U,GmTJlQcwnYNbOWB2xXt,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡋࡘࡕࡔࡄࡇ࡙ࡥࡍ࠴ࡗ࠻࠱࠶ࡹࡴࠨ༕"),BF6QAiLUNHh7rKOugaw,BF6QAiLUNHh7rKOugaw)
	HGQ5Ty9mlSLwed = VVznOTKE7NDIe0HGkg.content
	if ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"࡙ࠬࡔࡓࡇࡄࡑ࠲ࡏࡎࡇࠩ༖") not in HGQ5Ty9mlSLwed: return [YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"࠭࠭࠲ࠩ༗")],[smglbwR7x2oM+L4yYqE38juA2wQbs]
	if CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠧࡕ࡛ࡓࡉࡂࡇࡕࡅࡋࡒ༘ࠫ") in HGQ5Ty9mlSLwed: return [y6y5HtgXO4TkUbwVZ(u"ࠨ࠯࠴༙ࠫ")],[smglbwR7x2oM+L4yYqE38juA2wQbs]
	if L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠩࡗ࡝ࡕࡋ࠽ࡗࡋࡇࡉࡔ࠭༚") in HGQ5Ty9mlSLwed: return [jXE2YHkswT8y(u"ࠪ࠱࠶࠭༛")],[smglbwR7x2oM+L4yYqE38juA2wQbs]
	A7Ap2wdlxM,duef0gb3Mi1AV5WpN8,y9yfq4kQba3wTz,WUKAbPMfkIzeXsVSi = [],[],[],[]
	Wbe8jlJaNdroOHgpm = dEyT9xhGjolYzLCH7460w3.findall(ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠫࠨࡋࡘࡕ࠯࡛࠱ࡘ࡚ࡒࡆࡃࡐ࠱ࡎࡔࡆ࠻ࠪ࠱࠮ࡄ࠯࡛࡝ࡴ࡟ࡲࡢ࠱ࠨ࠯ࠬࡂ࠭ࡠࡢࡲ࡝ࡰࡠ࠯ࠬ༜"),HGQ5Ty9mlSLwed+OTlVEGYPSxsNaBdXUucqA3,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if not Wbe8jlJaNdroOHgpm: return [yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠬ࠳࠱ࠨ༝")],[smglbwR7x2oM+L4yYqE38juA2wQbs]
	for KKmXklH2p8CEqGzDFNI3c0,Zd7faKVcIU3O1HrRPwJX5QL4 in Wbe8jlJaNdroOHgpm:
		FaL0bpiDM6Ad,ttKWoIH83b,pMAWqrwP80lR = {},-YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"࠱ᒗ"),-YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"࠱ᒗ")
		g7ULx8u6tDi0neVQhofdX = iiy37aKq0pCEIOwfcTh61xb4U
		QQlIRbV9urgv1tWkn8 = KKmXklH2p8CEqGzDFNI3c0.split(GGx4qyKP1vUtRghsE2WfaHLMXZ(u"࠭ࠬࠨ༞"))
		for YVKo4mpBq9vEeUfM7JR8ujSP in QQlIRbV9urgv1tWkn8:
			if sVzojQerUqX(u"ࠧ࠾ࠩ༟") in YVKo4mpBq9vEeUfM7JR8ujSP:
				Onuh30WYrigx,NHgSFB4E0lmtyDdswYiIUeCqp5J = YVKo4mpBq9vEeUfM7JR8ujSP.split(yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠨ࠿ࠪ༠"),hhQwbeiNLoqFjX90fB7aG8VAs(u"࠲ᒘ"))
				FaL0bpiDM6Ad[Onuh30WYrigx.lower()] = NHgSFB4E0lmtyDdswYiIUeCqp5J
		if IpC4qHXRuyNFjzWv(u"ࠩࡤࡺࡪࡸࡡࡨࡧ࠰ࡦࡦࡴࡤࡸ࡫ࡧࡸ࡭࠭༡") in KKmXklH2p8CEqGzDFNI3c0.lower():
			ttKWoIH83b = int(FaL0bpiDM6Ad[jXE2YHkswT8y(u"ࠪࡥࡻ࡫ࡲࡢࡩࡨ࠱ࡧࡧ࡮ࡥࡹ࡬ࡨࡹ࡮ࠧ༢")])//y6y5HtgXO4TkUbwVZ(u"࠳࠳࠶࠹ᒙ")
			g7ULx8u6tDi0neVQhofdX += str(ttKWoIH83b)+ZchUJdM93pTA7zG5(u"ࠫࡰࡨࡰࡴࠢࠣࠫ༣")
		elif vODxLKW5Ql6r4Fbm8(u"ࠬࡨࡡ࡯ࡦࡺ࡭ࡩࡺࡨࠨ༤") in KKmXklH2p8CEqGzDFNI3c0.lower():
			ttKWoIH83b = int(FaL0bpiDM6Ad[AbqCJZdWQP9j(u"࠭ࡢࡢࡰࡧࡻ࡮ࡪࡴࡩࠩ༥")])//XrTw01KtLzbpoyMf(u"࠴࠴࠷࠺ᒚ")
			g7ULx8u6tDi0neVQhofdX += str(ttKWoIH83b)+CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠧ࡬ࡤࡳࡷࠥࠦࠧ༦")
		if PtkEvXAqif14G20QZsaSyT(u"ࠨࡴࡨࡷࡴࡲࡵࡵ࡫ࡲࡲࠬ༧") in KKmXklH2p8CEqGzDFNI3c0.lower():
			pMAWqrwP80lR = int(FaL0bpiDM6Ad[L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠩࡵࡩࡸࡵ࡬ࡶࡶ࡬ࡳࡳ࠭༨")].split(tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠪࡼࠬ༩"))[YYJQyRskpX8jv])
			g7ULx8u6tDi0neVQhofdX += str(pMAWqrwP80lR)+Wc5GekRC0HQLz7
		g7ULx8u6tDi0neVQhofdX = g7ULx8u6tDi0neVQhofdX.strip(Wc5GekRC0HQLz7)
		if not g7ULx8u6tDi0neVQhofdX: g7ULx8u6tDi0neVQhofdX = UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"࡚ࠫࡴ࡫࡯ࡱࡺࡲࠬ༪")
		if not Zd7faKVcIU3O1HrRPwJX5QL4.startswith(JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠬ࡮ࡴࡵࡲࠪ༫")):
			if Zd7faKVcIU3O1HrRPwJX5QL4.startswith(HtK4o2sTPgA78U(u"࠭࠯࠰ࠩ༬")): Zd7faKVcIU3O1HrRPwJX5QL4 = smglbwR7x2oM.split(uuExaKGL7UONtevRd(u"ࠧ࠻ࠩ༭"),YYJQyRskpX8jv)[FGTfwsjNrB8DvKSZhLIQAb1JnO]+JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠨ࠼ࠪ༮")+Zd7faKVcIU3O1HrRPwJX5QL4
			elif Zd7faKVcIU3O1HrRPwJX5QL4.startswith(IpC4qHXRuyNFjzWv(u"ࠩ࠲ࠫ༯")): Zd7faKVcIU3O1HrRPwJX5QL4 = F82MvyX4ThI6sbnA3efDoVS(smglbwR7x2oM,SaB5hx3PZwXRLtKgrTfQvId(u"ࠪࡹࡷࡲࠧ༰"))+Zd7faKVcIU3O1HrRPwJX5QL4
			else: Zd7faKVcIU3O1HrRPwJX5QL4 = smglbwR7x2oM.rsplit(ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠫ࠴࠭༱"),YYJQyRskpX8jv)[FGTfwsjNrB8DvKSZhLIQAb1JnO]+UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠬ࠵ࠧ༲")+Zd7faKVcIU3O1HrRPwJX5QL4
		if yJeq1BjfiO4NFuwIEzxVLK6b9s(u"࠭ࡰࡳࡱࡪࡶࡪࡹࡳࡪࡸࡨ࠱ࡺࡸࡩࠨ༳") in list(FaL0bpiDM6Ad.keys()):
			hx0dU3Ki7AyEfkSZY6TmN2BwtX = FaL0bpiDM6Ad[TlGXWLYsV1z(u"ࠧࡱࡴࡲ࡫ࡷ࡫ࡳࡴ࡫ࡹࡩ࠲ࡻࡲࡪࠩ༴")]
			hx0dU3Ki7AyEfkSZY6TmN2BwtX = hx0dU3Ki7AyEfkSZY6TmN2BwtX.replace(HtK4o2sTPgA78U(u"ࠨࠤ༵ࠪ"),iiy37aKq0pCEIOwfcTh61xb4U).replace(IpC4qHXRuyNFjzWv(u"ࠤࠪࠦ༶"),iiy37aKq0pCEIOwfcTh61xb4U).split(tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"༷ࠪࠧࠬ"),YYJQyRskpX8jv)[FGTfwsjNrB8DvKSZhLIQAb1JnO]
			asP7tCIR3S4wQ2ncHG0ZOVbNgWfhe6 = dVeG46wAnrtlpkbNPsvJ9(hx0dU3Ki7AyEfkSZY6TmN2BwtX)
			if asP7tCIR3S4wQ2ncHG0ZOVbNgWfhe6: Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb = g7ULx8u6tDi0neVQhofdX+Wc5GekRC0HQLz7+asP7tCIR3S4wQ2ncHG0ZOVbNgWfhe6
			else: Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb = g7ULx8u6tDi0neVQhofdX
			Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb = Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb+FRYcH4KL7e9gv5pEB(u"ࠫࠥࠦࡐࡳࡱࡪࡶࡪࡹࡳࡪࡸࡨࠫ༸")
			Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb = Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb+Wc5GekRC0HQLz7+F82MvyX4ThI6sbnA3efDoVS(hx0dU3Ki7AyEfkSZY6TmN2BwtX,L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠬࡴࡡ࡮ࡧ༹ࠪ"))
			A7Ap2wdlxM.append(Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb)
			duef0gb3Mi1AV5WpN8.append(hx0dU3Ki7AyEfkSZY6TmN2BwtX)
			y9yfq4kQba3wTz.append(pMAWqrwP80lR)
			WUKAbPMfkIzeXsVSi.append(ttKWoIH83b)
		Zd7faKVcIU3O1HrRPwJX5QL4 = Zd7faKVcIU3O1HrRPwJX5QL4.split(ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"࠭ࠣࠨ༺"),YYJQyRskpX8jv)[FGTfwsjNrB8DvKSZhLIQAb1JnO]
		asP7tCIR3S4wQ2ncHG0ZOVbNgWfhe6 = dVeG46wAnrtlpkbNPsvJ9(Zd7faKVcIU3O1HrRPwJX5QL4)
		if asP7tCIR3S4wQ2ncHG0ZOVbNgWfhe6: g7ULx8u6tDi0neVQhofdX = g7ULx8u6tDi0neVQhofdX+Wc5GekRC0HQLz7+asP7tCIR3S4wQ2ncHG0ZOVbNgWfhe6
		g7ULx8u6tDi0neVQhofdX = g7ULx8u6tDi0neVQhofdX+Wc5GekRC0HQLz7+F82MvyX4ThI6sbnA3efDoVS(Zd7faKVcIU3O1HrRPwJX5QL4,FRYcH4KL7e9gv5pEB(u"ࠧ࡯ࡣࡰࡩࠬ༻"))
		A7Ap2wdlxM.append(g7ULx8u6tDi0neVQhofdX)
		duef0gb3Mi1AV5WpN8.append(Zd7faKVcIU3O1HrRPwJX5QL4)
		y9yfq4kQba3wTz.append(pMAWqrwP80lR)
		WUKAbPMfkIzeXsVSi.append(ttKWoIH83b)
	c1CH6qPe8oZX3irhEgAzuxm5 = list(zip(A7Ap2wdlxM,duef0gb3Mi1AV5WpN8,y9yfq4kQba3wTz,WUKAbPMfkIzeXsVSi))
	c1CH6qPe8oZX3irhEgAzuxm5 = sorted(c1CH6qPe8oZX3irhEgAzuxm5, reverse=rGPen6cSMHQkAywh8vqI9JXiD2, key=lambda key: key[iiCWLaJREureAlOkv])
	A7Ap2wdlxM,duef0gb3Mi1AV5WpN8,y9yfq4kQba3wTz,WUKAbPMfkIzeXsVSi = list(zip(*c1CH6qPe8oZX3irhEgAzuxm5))
	A7Ap2wdlxM,duef0gb3Mi1AV5WpN8 = list(A7Ap2wdlxM),list(duef0gb3Mi1AV5WpN8)
	j6P7d92fziHV3s = []
	for Zd7faKVcIU3O1HrRPwJX5QL4 in duef0gb3Mi1AV5WpN8: j6P7d92fziHV3s.append(Zd7faKVcIU3O1HrRPwJX5QL4+L4yYqE38juA2wQbs)
	l03w7FeqLvMX1j2YEdgxpo = list(zip(j6P7d92fziHV3s,[sVzojQerUqX(u"ࠨࡦࡸࡱࡲࡿࠧ༼")]*len(j6P7d92fziHV3s),WUKAbPMfkIzeXsVSi))
	lNxUgMyAej6r7XfWGHCKb = OoC5bEUlDd2shtFzNrvgpyqK(sQU2GnRoMwLK8CBdfzmNr4jXyO,l03w7FeqLvMX1j2YEdgxpo)
	if lNxUgMyAej6r7XfWGHCKb:
		fCXyTlcmF4WuetVork,qBIUYtOjTAx0,ttKWoIH83b = lNxUgMyAej6r7XfWGHCKb[AbqCJZdWQP9j(u"࠴ᒛ")]
		index = j6P7d92fziHV3s.index(fCXyTlcmF4WuetVork)
		title = A7Ap2wdlxM[index]
		A7Ap2wdlxM,j6P7d92fziHV3s = [title],[fCXyTlcmF4WuetVork]
	return A7Ap2wdlxM,j6P7d92fziHV3s
def MtOTE0iscPV7d4bR9K512Zp(eNyxJLBPSwhQs,u9XCDzyOjNi=iiy37aKq0pCEIOwfcTh61xb4U):
	if not u9XCDzyOjNi: u9XCDzyOjNi = cl6fApKxQTzywM27g[FGTfwsjNrB8DvKSZhLIQAb1JnO]
	if eNyxJLBPSwhQs.replace(YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠩ࠱ࠫ༽"),iiy37aKq0pCEIOwfcTh61xb4U).isdigit(): return [eNyxJLBPSwhQs]
	from struct import pack as AARYiMGHkm8bnfrdXKah,unpack_from as iGug26MAqznOWj3YTDItRkFV7X
	from socket import socket as lwugO16XR3UKeqpdCsfzijm,AF_INET as rmlR3OKoLGeNs,SOCK_DGRAM as LlDsug24apI0
	try:
		Wxbwu9qRoU4 = AARYiMGHkm8bnfrdXKah(yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠥࡂࡍࠨ༾"), Y41NvKfOroMzGB8sEHy7wbXlc5(u"࠶࠸࠰࠵࠻ᒜ"))
		Wxbwu9qRoU4 += AARYiMGHkm8bnfrdXKah(UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠦࡃࡎࠢ༿"), TlGXWLYsV1z(u"࠸࠵࠷ᒝ"))
		Wxbwu9qRoU4 += AARYiMGHkm8bnfrdXKah(zmcGfOdvAjsELeJlP(u"ࠧࡄࡈࠣཀ"), YYJQyRskpX8jv)
		Wxbwu9qRoU4 += AARYiMGHkm8bnfrdXKah(TlGXWLYsV1z(u"ࠨ࠾ࡉࠤཁ"), FGTfwsjNrB8DvKSZhLIQAb1JnO)
		Wxbwu9qRoU4 += AARYiMGHkm8bnfrdXKah(tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠢ࠿ࡊࠥག"), FGTfwsjNrB8DvKSZhLIQAb1JnO)
		Wxbwu9qRoU4 += AARYiMGHkm8bnfrdXKah(UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠣࡀࡋࠦགྷ"), FGTfwsjNrB8DvKSZhLIQAb1JnO)
		if J1MoiYc7ZwzKS: cvOpK4NDUIjBnJW1s78y2xGElrwz = eNyxJLBPSwhQs.split(PtkEvXAqif14G20QZsaSyT(u"ࠩ࠱ࠫང"))
		else: cvOpK4NDUIjBnJW1s78y2xGElrwz = eNyxJLBPSwhQs.decode(df6QpwGxuJVZr).split(hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠪ࠲ࠬཅ"))
		for z7UI4JxHqlNr5ianR3Lsj1 in cvOpK4NDUIjBnJW1s78y2xGElrwz:
			kaUh70Yf1EeC5nBix6FAgmoGd = z7UI4JxHqlNr5ianR3Lsj1.encode(df6QpwGxuJVZr)
			Wxbwu9qRoU4 += AARYiMGHkm8bnfrdXKah(uuExaKGL7UONtevRd(u"ࠦࡇࠨཆ"), len(z7UI4JxHqlNr5ianR3Lsj1))
			for QQ6XvbaN1I0Wq in z7UI4JxHqlNr5ianR3Lsj1:
				Wxbwu9qRoU4 += AARYiMGHkm8bnfrdXKah(yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠧࡩࠢཇ"), QQ6XvbaN1I0Wq.encode(df6QpwGxuJVZr))
		Wxbwu9qRoU4 += AARYiMGHkm8bnfrdXKah(PtkEvXAqif14G20QZsaSyT(u"ࠨࡂࠣ཈"), FGTfwsjNrB8DvKSZhLIQAb1JnO)
		Wxbwu9qRoU4 += AARYiMGHkm8bnfrdXKah(YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠢ࠿ࡊࠥཉ"), YYJQyRskpX8jv)
		Wxbwu9qRoU4 += AARYiMGHkm8bnfrdXKah(ZchUJdM93pTA7zG5(u"ࠣࡀࡋࠦཊ"), YYJQyRskpX8jv)
		SSQAGTODfU5Csjkue4HYxqntXv = lwugO16XR3UKeqpdCsfzijm(rmlR3OKoLGeNs,LlDsug24apI0)
		SSQAGTODfU5Csjkue4HYxqntXv.sendto(bytes(Wxbwu9qRoU4), (u9XCDzyOjNi, L90uqo28xEKSFUwYTcm51yRWZIkft(u"࠵࠴ᒞ")))
		SSQAGTODfU5Csjkue4HYxqntXv.settimeout(JZszNnIEMAx28Yao0yqhiXGKOPb(u"࠷ᒟ"))
		oRzlSfeE6DY0mFy37NCVxAJW1BwZtM, WIFe9dt42KCD = SSQAGTODfU5Csjkue4HYxqntXv.recvfrom(y6y5HtgXO4TkUbwVZ(u"࠳࠳࠶࠹ᒠ"))
		SSQAGTODfU5Csjkue4HYxqntXv.close()
		MpbsIjaG95DEP2763oQtJner = iGug26MAqznOWj3YTDItRkFV7X(EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠤࡁࡌࡍࡎࡈࡉࡊࠥཋ"), oRzlSfeE6DY0mFy37NCVxAJW1BwZtM, FGTfwsjNrB8DvKSZhLIQAb1JnO)
		suJX1GzYHML6O = MpbsIjaG95DEP2763oQtJner[iiCWLaJREureAlOkv]
		XYaF1D9yAorWH7fEzCZMNJ = len(eNyxJLBPSwhQs)+Y41NvKfOroMzGB8sEHy7wbXlc5(u"࠴࠼ᒡ")
		OC9lxzDodrFpvn8X6kMebAfE1tKS = []
		for _XagYZeN8DGCwn53PdMqoK in range(suJX1GzYHML6O):
			kkEJ6MbvZTgcunOSXhK = XYaF1D9yAorWH7fEzCZMNJ
			mGfXZQo9DjgREis3KOU = YYJQyRskpX8jv
			IX0oJxugZdLO5 = BF6QAiLUNHh7rKOugaw
			while rGPen6cSMHQkAywh8vqI9JXiD2:
				QQ6XvbaN1I0Wq = iGug26MAqznOWj3YTDItRkFV7X(MgP8OjoaiWQEVG59(u"ࠥࡂࡇࠨཌ"), oRzlSfeE6DY0mFy37NCVxAJW1BwZtM, kkEJ6MbvZTgcunOSXhK)[FGTfwsjNrB8DvKSZhLIQAb1JnO]
				if QQ6XvbaN1I0Wq == FGTfwsjNrB8DvKSZhLIQAb1JnO:
					kkEJ6MbvZTgcunOSXhK += YYJQyRskpX8jv
					break
				if QQ6XvbaN1I0Wq >= GGx4qyKP1vUtRghsE2WfaHLMXZ(u"࠵࠾࠸ᒢ"):
					EDZQ2sAjUBG = iGug26MAqznOWj3YTDItRkFV7X(PtkEvXAqif14G20QZsaSyT(u"ࠦࡃࡈࠢཌྷ"), oRzlSfeE6DY0mFy37NCVxAJW1BwZtM, kkEJ6MbvZTgcunOSXhK + YYJQyRskpX8jv)[FGTfwsjNrB8DvKSZhLIQAb1JnO]
					kkEJ6MbvZTgcunOSXhK = ((QQ6XvbaN1I0Wq << zmcGfOdvAjsELeJlP(u"࠽ᒣ")) + EDZQ2sAjUBG - 0xc000) - YYJQyRskpX8jv
					IX0oJxugZdLO5 = rGPen6cSMHQkAywh8vqI9JXiD2
				kkEJ6MbvZTgcunOSXhK += YYJQyRskpX8jv
				if IX0oJxugZdLO5 == BF6QAiLUNHh7rKOugaw: mGfXZQo9DjgREis3KOU += YYJQyRskpX8jv
			if IX0oJxugZdLO5 == rGPen6cSMHQkAywh8vqI9JXiD2: mGfXZQo9DjgREis3KOU += YYJQyRskpX8jv
			XYaF1D9yAorWH7fEzCZMNJ = XYaF1D9yAorWH7fEzCZMNJ + mGfXZQo9DjgREis3KOU
			dZNLYQt9ryPHRhKIlubSioFx = iGug26MAqznOWj3YTDItRkFV7X(IpC4qHXRuyNFjzWv(u"ࠧࡄࡈࡉࡋࡋࠦཎ"), oRzlSfeE6DY0mFy37NCVxAJW1BwZtM, XYaF1D9yAorWH7fEzCZMNJ)
			XYaF1D9yAorWH7fEzCZMNJ = XYaF1D9yAorWH7fEzCZMNJ + IpC4qHXRuyNFjzWv(u"࠷࠰ᒤ")
			IIxHKrgkF53GRM0by2 = dZNLYQt9ryPHRhKIlubSioFx[FGTfwsjNrB8DvKSZhLIQAb1JnO]
			v9QjM4qYtT2 = dZNLYQt9ryPHRhKIlubSioFx[iiCWLaJREureAlOkv]
			if IIxHKrgkF53GRM0by2 == YYJQyRskpX8jv:
				KLmzoI3iyMCJHvASlbh6e = iGug26MAqznOWj3YTDItRkFV7X(ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠨ࠾ࠣཏ")+y6y5HtgXO4TkUbwVZ(u"ࠢࡃࠤཐ")*v9QjM4qYtT2, oRzlSfeE6DY0mFy37NCVxAJW1BwZtM, XYaF1D9yAorWH7fEzCZMNJ)
				ip = iiy37aKq0pCEIOwfcTh61xb4U
				for QQ6XvbaN1I0Wq in KLmzoI3iyMCJHvASlbh6e: ip += str(QQ6XvbaN1I0Wq) + xpT28sXu051(u"ࠨ࠰ࠪད")
				ip = ip[FGTfwsjNrB8DvKSZhLIQAb1JnO:-YYJQyRskpX8jv]
				OC9lxzDodrFpvn8X6kMebAfE1tKS.append(ip)
			if IIxHKrgkF53GRM0by2 in [YYJQyRskpX8jv,nI2JK1RfsGWNY3OarEeMQZ,tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"࠷ᒧ"),PtkEvXAqif14G20QZsaSyT(u"࠹ᒨ"),y6y5HtgXO4TkUbwVZ(u"࠲࠷ᒦ"),CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"࠲࠹ᒥ")]: XYaF1D9yAorWH7fEzCZMNJ = XYaF1D9yAorWH7fEzCZMNJ + v9QjM4qYtT2
	except: OC9lxzDodrFpvn8X6kMebAfE1tKS = []
	if not OC9lxzDodrFpvn8X6kMebAfE1tKS: WKquk5EaNr4RzVf(uiza5vIyTWtUeB8sXwAVYMFpgjrk,IIZ4e82HBP0oTmtOgaWY7hsMz(sQU2GnRoMwLK8CBdfzmNr4jXyO)+SaB5hx3PZwXRLtKgrTfQvId(u"ࠩࠣࠤࠥࡊࡎࡔࡡࡕࡉࡘࡕࡌࡗࡇࡕࠤ࡫ࡧࡩ࡭ࡧࡧࠤࠥࠦࡈࡰࡵࡷ࠾ࠥࡡࠠࠨདྷ")+eNyxJLBPSwhQs+XrTw01KtLzbpoyMf(u"ࠪࠤࡢ࠭ན"))
	return OC9lxzDodrFpvn8X6kMebAfE1tKS
def IUF8hYKEGLmHDtXbuWNvnJ(sQU2GnRoMwLK8CBdfzmNr4jXyO,smglbwR7x2oM,UAhMnV3r89cWy7X1D05GBCwTqOP4p,showDialogs=rGPen6cSMHQkAywh8vqI9JXiD2):
	if UAhMnV3r89cWy7X1D05GBCwTqOP4p:
		kkfGtmUDJbER = [EMO8gy4LrsNTh0knZwpSeU75APW(u"่ࠫฮวาࠩཔ"),IpC4qHXRuyNFjzWv(u"ࠬฮวๅ฼ࠪཕ"),L90uqo28xEKSFUwYTcm51yRWZIkft(u"࠭ࡡࡥࡷ࡯ࡸࠬབ"),CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠧࡹࡺࠪབྷ"),L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠨࡵࡨࡼࠬམ")]
		if sQU2GnRoMwLK8CBdfzmNr4jXyO!=TlGXWLYsV1z(u"ࠩࡅࡓࡐࡘࡁࠨཙ"):
			kkfGtmUDJbER += [PtkEvXAqif14G20QZsaSyT(u"ࠪࡶ࠿࠭ཚ"),uuExaKGL7UONtevRd(u"ࠫࡷ࠳ࠧཛ"),vODxLKW5Ql6r4Fbm8(u"ࠬ࠳࡭ࡢࠩཛྷ")]
			kkfGtmUDJbER += [yJeq1BjfiO4NFuwIEzxVLK6b9s(u"࠭࠺ࡳࠩཝ"),ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠧ࠮ࡴࠪཞ"),hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠨ࡯ࡤ࠱ࠬཟ")]
		for ZfxFOL740wnKEgyiItPACU9rdvQ in UAhMnV3r89cWy7X1D05GBCwTqOP4p:
			if ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠩࡪࡩࡹ࠴ࡰࡩࡲࡂࠫའ") in ZfxFOL740wnKEgyiItPACU9rdvQ: continue
			if sVzojQerUqX(u"ࠪั้่ษࠨཡ") in ZfxFOL740wnKEgyiItPACU9rdvQ: continue
			ZfxFOL740wnKEgyiItPACU9rdvQ = ZfxFOL740wnKEgyiItPACU9rdvQ.lower()
			if iELueYz3J1FmxaW7vc: ZfxFOL740wnKEgyiItPACU9rdvQ = ZfxFOL740wnKEgyiItPACU9rdvQ.decode(df6QpwGxuJVZr).encode(df6QpwGxuJVZr)
			ZfxFOL740wnKEgyiItPACU9rdvQ = ZfxFOL740wnKEgyiItPACU9rdvQ.replace(EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠫ࠿࠭ར"),iiy37aKq0pCEIOwfcTh61xb4U)
			GnbfL3j82s1BYumi4 = dEyT9xhGjolYzLCH7460w3.findall(vODxLKW5Ql6r4Fbm8(u"ࠬ࠮࠱࡜࠷࠰࠽ࡢ࠱ࡼ࠳࡝࠳࠱࠸ࡣࠫࠪࠩལ"),ZfxFOL740wnKEgyiItPACU9rdvQ,dEyT9xhGjolYzLCH7460w3.DOTALL)
			soFYcEpNGtQ0bq5e3mPCSa = BF6QAiLUNHh7rKOugaw
			for yjIhk7ZPfr2Ks3ACi in GnbfL3j82s1BYumi4:
				if len(yjIhk7ZPfr2Ks3ACi)==nI2JK1RfsGWNY3OarEeMQZ:
					soFYcEpNGtQ0bq5e3mPCSa = rGPen6cSMHQkAywh8vqI9JXiD2
					break
			if ZchUJdM93pTA7zG5(u"࠭࡮ࡰࡶࠣࡶࡦࡺࡥࡥࠩཤ") in ZfxFOL740wnKEgyiItPACU9rdvQ: continue
			elif tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠧࡶࡰࡵࡥࡹ࡫ࡤࠨཥ") in ZfxFOL740wnKEgyiItPACU9rdvQ: continue
			elif hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠨ฼ํี๋ࠥี็ใࠪས") in ZfxFOL740wnKEgyiItPACU9rdvQ: continue
			elif EETfYmdIcBQsXGiLzpODJxr35e([YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠩࡅࡘࡊࡾࡐࡗ࠳࠼ࡗࡗ࡜ࡎࡖࡗ࡯࡚ࡉ࡜ࡅࡗࡇ࡛ࠫཧ")])[FGTfwsjNrB8DvKSZhLIQAb1JnO]: continue
			elif ZfxFOL740wnKEgyiItPACU9rdvQ in [FRYcH4KL7e9gv5pEB(u"ࠪࡶࠬཨ")] or soFYcEpNGtQ0bq5e3mPCSa or any(aasX2cby4Vo5rTgB in ZfxFOL740wnKEgyiItPACU9rdvQ for aasX2cby4Vo5rTgB in kkfGtmUDJbER):
				WKquk5EaNr4RzVf(uiza5vIyTWtUeB8sXwAVYMFpgjrk,IIZ4e82HBP0oTmtOgaWY7hsMz(sQU2GnRoMwLK8CBdfzmNr4jXyO)+AbqCJZdWQP9j(u"ࠫࠥࠦࠠࡃ࡮ࡲࡧࡰ࡫ࡤࠡࡣࡧࡹࡱࡺࡳࠡࡸ࡬ࡨࡪࡵࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪཀྵ")+smglbwR7x2oM+tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠬࠦ࡝ࠨཪ"))
				if showDialogs: YYkhEn5xTXLUevzCVNB16mR(Y41NvKfOroMzGB8sEHy7wbXlc5(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩཫ"),LyNiIHPOwD3hCUYEFM7(u"ࠧศๆไ๎ิ๐่ࠡๆ็็ออัࠡใๅ฻ࠥ๎ร็ษ้๋ࠣ฿ส่ࠩཬ"))
				return rGPen6cSMHQkAywh8vqI9JXiD2
	return BF6QAiLUNHh7rKOugaw
def bb5kRv7jh3LaEVJtIfg(*aargs,**kkwargs):
	if aargs:
		direction = aargs[FGTfwsjNrB8DvKSZhLIQAb1JnO]
		RGTPvFZrfSEt = aargs[YYJQyRskpX8jv]
		if not direction: direction = tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ཭")
		if not RGTPvFZrfSEt: RGTPvFZrfSEt = FRYcH4KL7e9gv5pEB(u"ࠩสืฯ๋ัศำࠪ཮")
		hTidLWj4qr39P2HoY0x5KSZ = aargs[nI2JK1RfsGWNY3OarEeMQZ]
		XiWJ2PTqvds4pBNebVrt98x = OTlVEGYPSxsNaBdXUucqA3.join(aargs[Y41NvKfOroMzGB8sEHy7wbXlc5(u"࠷ᒩ"):])
	else: direction,RGTPvFZrfSEt,hTidLWj4qr39P2HoY0x5KSZ,XiWJ2PTqvds4pBNebVrt98x = iiy37aKq0pCEIOwfcTh61xb4U,vODxLKW5Ql6r4Fbm8(u"ࠪࡓࡐ࠭཯"),iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U
	Ny92sqomMkizpgKV1(direction,iiy37aKq0pCEIOwfcTh61xb4U,RGTPvFZrfSEt,iiy37aKq0pCEIOwfcTh61xb4U,hTidLWj4qr39P2HoY0x5KSZ,XiWJ2PTqvds4pBNebVrt98x,**kkwargs)
	return
def A1AXKupEOfz(*aargs,**kkwargs):
	direction = aargs[FGTfwsjNrB8DvKSZhLIQAb1JnO]
	ACaYrb6t9INljq54wiDnLhOk = aargs[YYJQyRskpX8jv]
	xCoLaNji4WK = aargs[nI2JK1RfsGWNY3OarEeMQZ]
	if xCoLaNji4WK or ACaYrb6t9INljq54wiDnLhOk: q0BwohGJY2xapybT = rGPen6cSMHQkAywh8vqI9JXiD2
	else: q0BwohGJY2xapybT = BF6QAiLUNHh7rKOugaw
	hTidLWj4qr39P2HoY0x5KSZ = aargs[iiCWLaJREureAlOkv]
	XiWJ2PTqvds4pBNebVrt98x = aargs[pZWli1xqfVtvzuSU6ImNw53gBFsh]
	if not direction: direction = sVzojQerUqX(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ཰")
	if not ACaYrb6t9INljq54wiDnLhOk: ACaYrb6t9INljq54wiDnLhOk = hhQwbeiNLoqFjX90fB7aG8VAs(u"้ࠬไศࠢࠣࡒࡴཱ࠭")
	if not xCoLaNji4WK: xCoLaNji4WK = yJeq1BjfiO4NFuwIEzxVLK6b9s(u"࠭ๆฺ็ࠣࠤ࡞࡫ࡳࠨི")
	if len(aargs)>=XrTw01KtLzbpoyMf(u"࠼ᒫ"): XiWJ2PTqvds4pBNebVrt98x += OTlVEGYPSxsNaBdXUucqA3+aargs[LyNiIHPOwD3hCUYEFM7(u"࠺ᒪ")]
	if len(aargs)>=SaB5hx3PZwXRLtKgrTfQvId(u"࠷ᒬ"): XiWJ2PTqvds4pBNebVrt98x += OTlVEGYPSxsNaBdXUucqA3+aargs[vODxLKW5Ql6r4Fbm8(u"࠷ᒭ")]
	kCWluLqaQTjbyoOZt0 = Ny92sqomMkizpgKV1(direction,ACaYrb6t9INljq54wiDnLhOk,iiy37aKq0pCEIOwfcTh61xb4U,xCoLaNji4WK,hTidLWj4qr39P2HoY0x5KSZ,XiWJ2PTqvds4pBNebVrt98x,**kkwargs)
	if kCWluLqaQTjbyoOZt0==-jXE2YHkswT8y(u"࠳ᒮ") and q0BwohGJY2xapybT: kCWluLqaQTjbyoOZt0 = -YYJQyRskpX8jv
	elif kCWluLqaQTjbyoOZt0==-YYJQyRskpX8jv and not q0BwohGJY2xapybT: kCWluLqaQTjbyoOZt0 = BF6QAiLUNHh7rKOugaw
	elif kCWluLqaQTjbyoOZt0==FGTfwsjNrB8DvKSZhLIQAb1JnO: kCWluLqaQTjbyoOZt0 = BF6QAiLUNHh7rKOugaw
	elif kCWluLqaQTjbyoOZt0==nI2JK1RfsGWNY3OarEeMQZ: kCWluLqaQTjbyoOZt0 = rGPen6cSMHQkAywh8vqI9JXiD2
	return kCWluLqaQTjbyoOZt0
def ccv1mVPUsnr(*aargs,**kkwargs):
	return OOYtyXB3o8K.Dialog().select(*aargs,**kkwargs)
def YYkhEn5xTXLUevzCVNB16mR(*aargs,**kkwargs):
	hTidLWj4qr39P2HoY0x5KSZ = aargs[FGTfwsjNrB8DvKSZhLIQAb1JnO]
	XiWJ2PTqvds4pBNebVrt98x = aargs[YYJQyRskpX8jv]
	DU3YSnf2sIl = kkwargs[uuExaKGL7UONtevRd(u"ࠧࡵ࡫ࡰࡩཱིࠬ")] if SaB5hx3PZwXRLtKgrTfQvId(u"ࠨࡶ࡬ࡱࡪུ࠭") in list(kkwargs.keys()) else GGx4qyKP1vUtRghsE2WfaHLMXZ(u"࠴࠴࠵࠶ᒯ")
	Z9K2hJBQTmz30D6wFvRod4GPEx = aargs[nI2JK1RfsGWNY3OarEeMQZ] if len(aargs)>nI2JK1RfsGWNY3OarEeMQZ and jXE2YHkswT8y(u"ࠩࡷ࡭ࡲ࡫ཱུࠧ") not in aargs[nI2JK1RfsGWNY3OarEeMQZ] else zmcGfOdvAjsELeJlP(u"ࠪࡲࡴࡺࡩࡧ࡫ࡦࡥࡹ࡯࡯࡯ࡡࡵࡩ࡬ࡻ࡬ࡢࡴࠪྲྀ")
	sj246WXRZ1QPchEB7l8V = EEehSFDLdpKBR3W1ga9PxrV.Thread(target=PJ1SRAZsCHB,args=(hTidLWj4qr39P2HoY0x5KSZ,XiWJ2PTqvds4pBNebVrt98x,Z9K2hJBQTmz30D6wFvRod4GPEx,DU3YSnf2sIl))
	sj246WXRZ1QPchEB7l8V.start()
	return
def PJ1SRAZsCHB(hTidLWj4qr39P2HoY0x5KSZ,XiWJ2PTqvds4pBNebVrt98x,Z9K2hJBQTmz30D6wFvRod4GPEx,DU3YSnf2sIl):
	DTXrIOaoHUh7KPQBduS3JW6Gt40 = Z9K2hJBQTmz30D6wFvRod4GPEx.replace(sVzojQerUqX(u"ࠫࡳࡵࡴࡪࡨ࡬ࡧࡦࡺࡩࡰࡰࡢࠫཷ"),iiy37aKq0pCEIOwfcTh61xb4U)
	name = mkT7KMxSV1PvEr5(rGPen6cSMHQkAywh8vqI9JXiD2,DTXrIOaoHUh7KPQBduS3JW6Gt40+sVzojQerUqX(u"ࠬࠦ࠭ࠡࠩླྀ")+hTidLWj4qr39P2HoY0x5KSZ+ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"࠭ࠠ࠮ࠢࠪཹ")+XiWJ2PTqvds4pBNebVrt98x)
	name = VzC7H3ty4U8GkD(name)
	image_filename = wkMR5x1gTWEQIc6qHCa.path.join(z6kbVo0FJ8lHmdGS,name+LyNiIHPOwD3hCUYEFM7(u"ࠧ࠯ࡲࡱ࡫ེࠬ"))
	if wkMR5x1gTWEQIc6qHCa.path.exists(image_filename):
		if Z9K2hJBQTmz30D6wFvRod4GPEx==L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠨࡰࡲࡸ࡮࡬ࡩࡤࡣࡷ࡭ࡴࡴ࡟ࡳࡧࡪࡹࡱࡧࡲࠨཻ"): image_height = tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"࠵࠶࠽ᒰ")
		elif Z9K2hJBQTmz30D6wFvRod4GPEx==jXE2YHkswT8y(u"ࠩࡱࡳࡹ࡯ࡦࡪࡥࡤࡸ࡮ࡵ࡮ࡠࡣࡸࡸࡴོ࠭"): image_height = TlGXWLYsV1z(u"࠷࠷࠰ᒱ")
	else: image_height = XV4nFRGIpg971ukM(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,hTidLWj4qr39P2HoY0x5KSZ,XiWJ2PTqvds4pBNebVrt98x,Z9K2hJBQTmz30D6wFvRod4GPEx,yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠪࡰࡪ࡬ࡴࠨཽ"),BF6QAiLUNHh7rKOugaw,image_filename)
	tFPGhK6bYwBEOoHDL = wiNkogLdpnA(CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠫࡉ࡯ࡡ࡭ࡱࡪࡒࡴࡺࡩࡧ࡫ࡦࡥࡹ࡯࡯࡯ࡋࡰࡥ࡬࡫࠮ࡹ࡯࡯ࠫཾ"),V5f96hvSkeUwCxZrE4dlzpy,HtK4o2sTPgA78U(u"ࠬࡊࡥࡧࡣࡸࡰࡹ࠭ཿ"),FRYcH4KL7e9gv5pEB(u"࠭࠷࠳࠲ࡳྀࠫ"))
	tFPGhK6bYwBEOoHDL.show()
	if Z9K2hJBQTmz30D6wFvRod4GPEx==hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠧ࡯ࡱࡷ࡭࡫࡯ࡣࡢࡶ࡬ࡳࡳࡥࡡࡶࡶࡲཱྀࠫ"):
		tFPGhK6bYwBEOoHDL.getControl(HtK4o2sTPgA78U(u"࠹࠱࠶࠳ᒳ")).setHeight(CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"࠸࠱࠶ᒲ"))
		tFPGhK6bYwBEOoHDL.getControl(CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"࠼࠴࠹࠶ᒶ")).setPosition(PtkEvXAqif14G20QZsaSyT(u"࠶࠷ᒴ"),-zmcGfOdvAjsELeJlP(u"࠺࠳ᒵ"))
		tFPGhK6bYwBEOoHDL.getControl(zmcGfOdvAjsELeJlP(u"࠽࠵࠻࠰ᒷ")).setPosition(ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"࠶࠸࠰ᒸ"),-tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"࠼࠰ᒹ"))
		tFPGhK6bYwBEOoHDL.getControl(FRYcH4KL7e9gv5pEB(u"࠶࠳࠴ᒼ")).setPosition(ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"࠹࠱ᒺ"),-LyNiIHPOwD3hCUYEFM7(u"࠴࠷ᒻ"))
	tFPGhK6bYwBEOoHDL.getControl(hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"࠷࠴࠶ᒽ")).setVisible(BF6QAiLUNHh7rKOugaw)
	tFPGhK6bYwBEOoHDL.getControl(HtK4o2sTPgA78U(u"࠸࠵࠸ᒾ")).setVisible(BF6QAiLUNHh7rKOugaw)
	tFPGhK6bYwBEOoHDL.getControl(HtK4o2sTPgA78U(u"࠾࠶࠵࠱ᒿ")).setImage(image_filename)
	tFPGhK6bYwBEOoHDL.getControl(hhQwbeiNLoqFjX90fB7aG8VAs(u"࠿࠰࠶࠲ᓀ")).setHeight(image_height)
	X2cQ5NCPvkMieBW7oASspFjE.sleep(DU3YSnf2sIl//LyNiIHPOwD3hCUYEFM7(u"࠱࠱࠲࠳࠲࠵ᓁ"))
	return
def BBWHv8OyN6VudhF(*aargs,**kkwargs):
	hTidLWj4qr39P2HoY0x5KSZ,XiWJ2PTqvds4pBNebVrt98x,profile,direction = iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,vODxLKW5Ql6r4Fbm8(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࡣࡱࡵ࡮ࡨࠩྂ"),UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠩ࡯ࡩ࡫ࡺࠧྃ")
	if len(aargs)>=YYJQyRskpX8jv: hTidLWj4qr39P2HoY0x5KSZ = aargs[FGTfwsjNrB8DvKSZhLIQAb1JnO]
	if len(aargs)>=nI2JK1RfsGWNY3OarEeMQZ: XiWJ2PTqvds4pBNebVrt98x = aargs[YYJQyRskpX8jv]
	if len(aargs)>=iiCWLaJREureAlOkv: profile = aargs[nI2JK1RfsGWNY3OarEeMQZ]
	if len(aargs)>=pZWli1xqfVtvzuSU6ImNw53gBFsh: direction = aargs[iiCWLaJREureAlOkv]
	return ggULVKqsMZbc1ynfBC7(direction,hTidLWj4qr39P2HoY0x5KSZ,XiWJ2PTqvds4pBNebVrt98x,profile)
def NW92cI5MjezZVnTGmq(*aargs,**kkwargs):
	return OOYtyXB3o8K.Dialog().contextmenu(*aargs,**kkwargs)
def IXo1OsZjYzcJvpgUFedfi(*aargs,**kkwargs):
	return OOYtyXB3o8K.Dialog().browseSingle(*aargs,**kkwargs)
def fK1BA8dxgVnZQGk6SzqX(*aargs,**kkwargs):
	return OOYtyXB3o8K.Dialog().input(*aargs,**kkwargs)
def BH5w8KScjpRhAkI7PlqDU(*aargs,**kkwargs):
	return OOYtyXB3o8K.DialogProgress(*aargs,**kkwargs)
def Ny92sqomMkizpgKV1(direction,button0=iiy37aKq0pCEIOwfcTh61xb4U,button1=iiy37aKq0pCEIOwfcTh61xb4U,button2=iiy37aKq0pCEIOwfcTh61xb4U,hTidLWj4qr39P2HoY0x5KSZ=iiy37aKq0pCEIOwfcTh61xb4U,XiWJ2PTqvds4pBNebVrt98x=iiy37aKq0pCEIOwfcTh61xb4U,profile=GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠪࡧࡴࡴࡦࡪࡴࡰࡣࡧ࡯ࡧࡧࡱࡱࡸ྄ࠬ"),YPNGc0i1yD8aIKdgLekRn=FGTfwsjNrB8DvKSZhLIQAb1JnO,SSePGd9xzTigQaRIB2MFJ1CUVyhqWs=FGTfwsjNrB8DvKSZhLIQAb1JnO):
	if not direction: direction = FRYcH4KL7e9gv5pEB(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ྅")
	tFPGhK6bYwBEOoHDL = YhUSm4KqOHBXnC9LdJsPg8(vODxLKW5Ql6r4Fbm8(u"ࠬࡊࡩࡢ࡮ࡲ࡫ࡈࡵ࡮ࡧ࡫ࡵࡱ࡙࡮ࡲࡦࡧࡅࡹࡹࡺ࡯࡯ࡵ࠱ࡼࡲࡲࠧ྆"),V5f96hvSkeUwCxZrE4dlzpy,GGx4qyKP1vUtRghsE2WfaHLMXZ(u"࠭ࡄࡦࡨࡤࡹࡱࡺࠧ྇"),tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠧ࠸࠴࠳ࡴࠬྈ"))
	tFPGhK6bYwBEOoHDL.jz3MNyZsDYvpkVufaJdI2bS6CUw(button0,button1,button2,hTidLWj4qr39P2HoY0x5KSZ,XiWJ2PTqvds4pBNebVrt98x,profile,direction,YPNGc0i1yD8aIKdgLekRn,SSePGd9xzTigQaRIB2MFJ1CUVyhqWs)
	if YPNGc0i1yD8aIKdgLekRn>FGTfwsjNrB8DvKSZhLIQAb1JnO: tFPGhK6bYwBEOoHDL.ReC12DmhyZbP7Nd4XnJl()
	if SSePGd9xzTigQaRIB2MFJ1CUVyhqWs>FGTfwsjNrB8DvKSZhLIQAb1JnO: tFPGhK6bYwBEOoHDL.laqQ5XZrjJhxM1EUbWB()
	if YPNGc0i1yD8aIKdgLekRn==FGTfwsjNrB8DvKSZhLIQAb1JnO and SSePGd9xzTigQaRIB2MFJ1CUVyhqWs==FGTfwsjNrB8DvKSZhLIQAb1JnO: tFPGhK6bYwBEOoHDL.lBE6XhR8CYsfj()
	tFPGhK6bYwBEOoHDL.doModal()
	kCWluLqaQTjbyoOZt0 = tFPGhK6bYwBEOoHDL.choiceID
	return kCWluLqaQTjbyoOZt0
def ggULVKqsMZbc1ynfBC7(direction,hTidLWj4qr39P2HoY0x5KSZ,XiWJ2PTqvds4pBNebVrt98x,profile=jXE2YHkswT8y(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࡣࡱࡵ࡮ࡨࠩྉ")):
	if not direction: direction = EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠩ࡯ࡩ࡫ࡺࠧྊ")
	tFPGhK6bYwBEOoHDL = wiNkogLdpnA(ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠪࡈ࡮ࡧ࡬ࡰࡩࡗࡩࡽࡺࡖࡪࡧࡺࡩࡷࡌࡵ࡭࡮ࡖࡧࡷ࡫ࡥ࡯࠰ࡻࡱࡱ࠭ྋ"),V5f96hvSkeUwCxZrE4dlzpy,MgP8OjoaiWQEVG59(u"ࠫࡉ࡫ࡦࡢࡷ࡯ࡸࠬྌ"),y6y5HtgXO4TkUbwVZ(u"ࠬ࠽࠲࠱ࡲࠪྍ"))
	image_filename = PuhkKlL5mRz.replace(ZchUJdM93pTA7zG5(u"࠭࡟࠱࠲࠳࠴ࡤ࠭ྎ"),FRYcH4KL7e9gv5pEB(u"ࠧࡠࠩྏ")+str(X2cQ5NCPvkMieBW7oASspFjE.time())+TlGXWLYsV1z(u"ࠨࡡࠪྐ"))
	image_filename = image_filename.replace(tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠩ࡟ࡠࠬྑ"),hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠪࡠࡡࡢ࡜ࠨྒ")).replace(IpC4qHXRuyNFjzWv(u"ࠫ࠴࠵ࠧྒྷ"),sVzojQerUqX(u"ࠬ࠵࠯࠰࠱ࠪྔ"))
	image_height = XV4nFRGIpg971ukM(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,hTidLWj4qr39P2HoY0x5KSZ,XiWJ2PTqvds4pBNebVrt98x,profile,direction,BF6QAiLUNHh7rKOugaw,image_filename)
	tFPGhK6bYwBEOoHDL.show()
	tFPGhK6bYwBEOoHDL.getControl(EMO8gy4LrsNTh0knZwpSeU75APW(u"࠺࠲࠸࠴ᓂ")).setHeight(image_height)
	tFPGhK6bYwBEOoHDL.getControl(UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"࠻࠳࠹࠵ᓃ")).setImage(image_filename)
	rG7qcgNWkxbzPwp6iLS9 = tFPGhK6bYwBEOoHDL.doModal()
	try: wkMR5x1gTWEQIc6qHCa.remove(image_filename)
	except: pass
	return rG7qcgNWkxbzPwp6iLS9
def FgJLkYac7lQxEbs(Qc3s1JuTz7M80CntlDo=rGPen6cSMHQkAywh8vqI9JXiD2):
	if Qc3s1JuTz7M80CntlDo:
		QlAC9VBYGRckULquednZ0XvOxF4f5M = QKzCiBOWZus1nSv(PdkZHNBlpg2b7DmX6qRiyVa,YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"࠭ࡳࡵࡴࠪྕ"),EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪྖ"),ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠨࡗࡖࡉࡗࡇࡇࡆࡐࡗࠫྗ"))
		if QlAC9VBYGRckULquednZ0XvOxF4f5M: return QlAC9VBYGRckULquednZ0XvOxF4f5M
	XiWJ2PTqvds4pBNebVrt98x = iiy37aKq0pCEIOwfcTh61xb4U
	if FGTfwsjNrB8DvKSZhLIQAb1JnO and VVznOTKE7NDIe0HGkg.succeeded:
		HGQ5Ty9mlSLwed = VVznOTKE7NDIe0HGkg.content
		MH9dDWw6lxUpqcAYzFhveGZoKVQ = HGQ5Ty9mlSLwed.count(zmcGfOdvAjsELeJlP(u"ࠩࡐࡳࡿ࡯࡬࡭ࡣࠪ྘"))
		if MH9dDWw6lxUpqcAYzFhveGZoKVQ>tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"࠻࠴ᓄ"):
			XiWJ2PTqvds4pBNebVrt98x = dEyT9xhGjolYzLCH7460w3.findall(hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠪ࡫ࡪࡺ࠭ࡵࡪࡨ࠱ࡱ࡯ࡳࡵ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬྙ"),HGQ5Ty9mlSLwed,dEyT9xhGjolYzLCH7460w3.DOTALL)
			XiWJ2PTqvds4pBNebVrt98x = XiWJ2PTqvds4pBNebVrt98x[FGTfwsjNrB8DvKSZhLIQAb1JnO]
	if not XiWJ2PTqvds4pBNebVrt98x:
		V5ZbiSY0FTKphMRUD38qnevjwEsHdO = wkMR5x1gTWEQIc6qHCa.path.join(V5f96hvSkeUwCxZrE4dlzpy,yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠫࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪྚ"),uuExaKGL7UONtevRd(u"ࠬࡻࡳࡦࡴࡤ࡫ࡪࡴࡴࡴ࠰ࡷࡼࡹ࠭ྛ"))
		XiWJ2PTqvds4pBNebVrt98x = open(V5ZbiSY0FTKphMRUD38qnevjwEsHdO,zmcGfOdvAjsELeJlP(u"࠭ࡲࡣࠩྜ")).read()
		if J1MoiYc7ZwzKS: XiWJ2PTqvds4pBNebVrt98x = XiWJ2PTqvds4pBNebVrt98x.decode(df6QpwGxuJVZr)
		XiWJ2PTqvds4pBNebVrt98x = XiWJ2PTqvds4pBNebVrt98x.replace(Mge0HhFk9Ic6sm5VR,iiy37aKq0pCEIOwfcTh61xb4U)
	XXFU6JAtEPgrTxS2Kk = dEyT9xhGjolYzLCH7460w3.findall(SaB5hx3PZwXRLtKgrTfQvId(u"ࠧࠩࡏࡲࡾ࡮ࡲ࡬ࡢ࠰࠭ࡃ࠮ࡢ࡮ࠨྜྷ"),XiWJ2PTqvds4pBNebVrt98x,dEyT9xhGjolYzLCH7460w3.DOTALL)
	n2HJetVgZrzTokE9DuFm8G1sh = []
	for KKmXklH2p8CEqGzDFNI3c0 in XXFU6JAtEPgrTxS2Kk:
		Ini9XSyWe2PZDj = KKmXklH2p8CEqGzDFNI3c0.lower()
		if IpC4qHXRuyNFjzWv(u"ࠨࡣࡱࡨࡷࡵࡩࡥࠩྞ") in Ini9XSyWe2PZDj: continue
		if hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠩࡸࡦࡺࡴࡴࡶࠩྟ") in Ini9XSyWe2PZDj: continue
		if YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠪ࡭ࡵ࡮࡯࡯ࡧࠪྠ") in Ini9XSyWe2PZDj: continue
		if yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠫࡨࡸ࡯ࡴࠩྡ") in Ini9XSyWe2PZDj: continue
		n2HJetVgZrzTokE9DuFm8G1sh.append(KKmXklH2p8CEqGzDFNI3c0)
	QlAC9VBYGRckULquednZ0XvOxF4f5M = ufTX72hK8Q63jSsJiqDm5.sample(n2HJetVgZrzTokE9DuFm8G1sh,YYJQyRskpX8jv)
	QlAC9VBYGRckULquednZ0XvOxF4f5M = QlAC9VBYGRckULquednZ0XvOxF4f5M[FGTfwsjNrB8DvKSZhLIQAb1JnO]
	YMQXP2BGeK86CEb(PdkZHNBlpg2b7DmX6qRiyVa,y6y5HtgXO4TkUbwVZ(u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࠨྡྷ"),XrTw01KtLzbpoyMf(u"࠭ࡕࡔࡇࡕࡅࡌࡋࡎࡕࠩྣ"),QlAC9VBYGRckULquednZ0XvOxF4f5M,PNjZMS7nxa9clHusz1)
	return QlAC9VBYGRckULquednZ0XvOxF4f5M
def STuF19IbYQR3gz(UIxuCn8wAWpgz5j9EdqFvreH=iiy37aKq0pCEIOwfcTh61xb4U):
	showDialogs = rGPen6cSMHQkAywh8vqI9JXiD2 if O8ObqHAIx6sgnaNC7dLDXcVt9GZh2B==iiy37aKq0pCEIOwfcTh61xb4U else O8ObqHAIx6sgnaNC7dLDXcVt9GZh2B
	if not showDialogs: return
	if not UIxuCn8wAWpgz5j9EdqFvreH: UIxuCn8wAWpgz5j9EdqFvreH = xiFBCH5hcJks.format_exc()
	if IpC4qHXRuyNFjzWv(u"ࠧࡔࡻࡶࡸࡪࡳࡅࡹ࡫ࡷࠫྤ") in UIxuCn8wAWpgz5j9EdqFvreH or PtkEvXAqif14G20QZsaSyT(u"ࠨࡡࡢࡣࡋࡕࡒࡄࡇࡢࡉ࡝ࡏࡔࡠࡡࡢࠫྥ") in UIxuCn8wAWpgz5j9EdqFvreH: return
	if UIxuCn8wAWpgz5j9EdqFvreH!=yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠩࡑࡳࡳ࡫ࡔࡺࡲࡨ࠾ࠥࡔ࡯࡯ࡧ࡟ࡲࠬྦ"): ytv0YaxDcRINurplWKg587Pwqz.stderr.write(UIxuCn8wAWpgz5j9EdqFvreH)
	Wbe8jlJaNdroOHgpm = UIxuCn8wAWpgz5j9EdqFvreH.splitlines()
	yy2jWo16LdtRQeMXHZpPJO = Wbe8jlJaNdroOHgpm[-TlGXWLYsV1z(u"࠵ᓅ")]
	KHBoxPqOzGMslbDt8kS1dwE = open(Ct1U8Ao9wucR,PtkEvXAqif14G20QZsaSyT(u"ࠪࡶࡧ࠭ྦྷ")).read()
	if J1MoiYc7ZwzKS: KHBoxPqOzGMslbDt8kS1dwE = KHBoxPqOzGMslbDt8kS1dwE.decode(df6QpwGxuJVZr)
	KHBoxPqOzGMslbDt8kS1dwE = KHBoxPqOzGMslbDt8kS1dwE[-JZszNnIEMAx28Yao0yqhiXGKOPb(u"࠽࠶࠰࠱ᓆ"):]
	AAbf0g1sJ4crMQYiKmTypFltvkUVD = JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠫࡂ࠭ྨ")*TlGXWLYsV1z(u"࠷࠰࠱ᓇ")
	if AAbf0g1sJ4crMQYiKmTypFltvkUVD in KHBoxPqOzGMslbDt8kS1dwE: KHBoxPqOzGMslbDt8kS1dwE = KHBoxPqOzGMslbDt8kS1dwE.rsplit(AAbf0g1sJ4crMQYiKmTypFltvkUVD,YYJQyRskpX8jv)[YYJQyRskpX8jv]
	if yy2jWo16LdtRQeMXHZpPJO in KHBoxPqOzGMslbDt8kS1dwE: KHBoxPqOzGMslbDt8kS1dwE = KHBoxPqOzGMslbDt8kS1dwE.rsplit(yy2jWo16LdtRQeMXHZpPJO,YYJQyRskpX8jv)[FGTfwsjNrB8DvKSZhLIQAb1JnO]
	fwNvItaL3xQTbzmYMq = dEyT9xhGjolYzLCH7460w3.findall(JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠬ࠮ࡓࡰࡷࡵࡧࡪࢂࡍࡰࡦࡨ࠭࠿ࠦ࡜࡜ࠢࠫ࠲࠯ࡅࠩࠡ࡞ࡠࠫྩ"),KHBoxPqOzGMslbDt8kS1dwE,dEyT9xhGjolYzLCH7460w3.DOTALL)
	for TOICVh7Fgd2WurvDNASZt,VamqUtbfFn6MANy in reversed(fwNvItaL3xQTbzmYMq):
		if VamqUtbfFn6MANy: break
	else: VamqUtbfFn6MANy = MgP8OjoaiWQEVG59(u"࠭ࡎࡐࡖࠣࡗࡕࡋࡃࡊࡈࡌࡉࡉ࠭ྪ")
	BdluXk6trpsO2bF841jZLgH7nG9c,KKmXklH2p8CEqGzDFNI3c0,M4hIvdynPzxGj1WFBfA5p = iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U
	B2gaHFz3k4mystuCxNwKlr6AZ = L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠧ࡜ࡔࡗࡐࡢ࠭ྫ")+aqEsMBckT2bunGHfl48Wip+YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠨษ็า฼ษ࠺ࠡࠢࠪྫྷ")+YoQW601K4fMJcsreDnGVE5wUZIy7+yy2jWo16LdtRQeMXHZpPJO
	AWhpYHuQqgEKx = hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠩ࡞ࡖ࡙ࡒ࡝ࠨྭ")+aqEsMBckT2bunGHfl48Wip+tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠪห้๋ีะำ࠽ࠤࠥ࠭ྮ")+YoQW601K4fMJcsreDnGVE5wUZIy7+VamqUtbfFn6MANy
	for qW41vJC0kn8plSLy in reversed(Wbe8jlJaNdroOHgpm):
		if yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠫࡋ࡯࡬ࡦࠢࠥࠫྯ") in qW41vJC0kn8plSLy and EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠬࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫྰ") in qW41vJC0kn8plSLy: break
	qW41vJC0kn8plSLy = dEyT9xhGjolYzLCH7460w3.findall(zmcGfOdvAjsELeJlP(u"࠭ࡆࡪ࡮ࡨࠤࠧ࠮࠮ࠫࡁࠬࠦࡡ࠲ࠠ࡭࡫ࡱࡩࠥ࠮࠮ࠫࡁࠬࡠ࠱ࠦࡩ࡯ࠢࠫ࠲࠯ࡅࠩࠥࠩྱ"),qW41vJC0kn8plSLy,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if qW41vJC0kn8plSLy:
		BdluXk6trpsO2bF841jZLgH7nG9c,KKmXklH2p8CEqGzDFNI3c0,M4hIvdynPzxGj1WFBfA5p = qW41vJC0kn8plSLy[FGTfwsjNrB8DvKSZhLIQAb1JnO]
		if y6y5HtgXO4TkUbwVZ(u"ࠧ࠰ࠩྲ") in BdluXk6trpsO2bF841jZLgH7nG9c: BdluXk6trpsO2bF841jZLgH7nG9c = BdluXk6trpsO2bF841jZLgH7nG9c.rsplit(ZchUJdM93pTA7zG5(u"ࠨ࠱ࠪླ"),YYJQyRskpX8jv)[YYJQyRskpX8jv]
		else: BdluXk6trpsO2bF841jZLgH7nG9c = BdluXk6trpsO2bF841jZLgH7nG9c.rsplit(tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠩ࡟ࡠࠬྴ"),YYJQyRskpX8jv)[YYJQyRskpX8jv]
		ZNJkQtmDEMr80AHRFG = xpT28sXu051(u"ࠪ࡟ࡗ࡚ࡌ࡞ࠩྵ")+aqEsMBckT2bunGHfl48Wip+PtkEvXAqif14G20QZsaSyT(u"ࠫฬ๊ๅๅใ࠽ࠤࠥ࠭ྶ")+YoQW601K4fMJcsreDnGVE5wUZIy7+BdluXk6trpsO2bF841jZLgH7nG9c
		bqPSCmMWRh83n2TZVe = zmcGfOdvAjsELeJlP(u"ࠬࡡࡒࡕࡎࡠࠫྷ")+aqEsMBckT2bunGHfl48Wip+TlGXWLYsV1z(u"࠭วๅีฺี࠿ࠦࠠࠨྸ")+YoQW601K4fMJcsreDnGVE5wUZIy7+KKmXklH2p8CEqGzDFNI3c0
		UUCdmqb8ZsyIjKS = GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠧ࡜ࡔࡗࡐࡢ࠭ྐྵ")+aqEsMBckT2bunGHfl48Wip+tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠨษ็้่อๆ࠻ࠢࠣࠫྺ")+YoQW601K4fMJcsreDnGVE5wUZIy7+M4hIvdynPzxGj1WFBfA5p
		OVe6XKnFIua3C4Y5HlDPo2x1pqkbG = ZNJkQtmDEMr80AHRFG+OTlVEGYPSxsNaBdXUucqA3+bqPSCmMWRh83n2TZVe+OTlVEGYPSxsNaBdXUucqA3+UUCdmqb8ZsyIjKS+OTlVEGYPSxsNaBdXUucqA3+AWhpYHuQqgEKx+OTlVEGYPSxsNaBdXUucqA3+B2gaHFz3k4mystuCxNwKlr6AZ
		W4W0dvFVeoH = bqPSCmMWRh83n2TZVe+OTlVEGYPSxsNaBdXUucqA3+AWhpYHuQqgEKx+OTlVEGYPSxsNaBdXUucqA3+B2gaHFz3k4mystuCxNwKlr6AZ+OTlVEGYPSxsNaBdXUucqA3+ZNJkQtmDEMr80AHRFG+OTlVEGYPSxsNaBdXUucqA3+UUCdmqb8ZsyIjKS
		noMZGxPfsWlAF8Km1gHhqkCtQi73 = bqPSCmMWRh83n2TZVe+OTlVEGYPSxsNaBdXUucqA3+B2gaHFz3k4mystuCxNwKlr6AZ+OTlVEGYPSxsNaBdXUucqA3+ZNJkQtmDEMr80AHRFG+OTlVEGYPSxsNaBdXUucqA3+UUCdmqb8ZsyIjKS
	else:
		ZNJkQtmDEMr80AHRFG,bqPSCmMWRh83n2TZVe,UUCdmqb8ZsyIjKS = iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U
		OVe6XKnFIua3C4Y5HlDPo2x1pqkbG = AWhpYHuQqgEKx+xpT28sXu051(u"ࠩ࡟ࡲࡡࡴࠧྻ")+B2gaHFz3k4mystuCxNwKlr6AZ
		W4W0dvFVeoH = AWhpYHuQqgEKx+EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠪࡠࡳࡢ࡮ࠨྼ")+B2gaHFz3k4mystuCxNwKlr6AZ
		noMZGxPfsWlAF8Km1gHhqkCtQi73 = B2gaHFz3k4mystuCxNwKlr6AZ
	q09muWHtpcYS8a7Rr3Jk4LO = yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠫาีหࠡะฺวࠥเ๊า่ࠢๆฺ๎ฯࠨ྽")+OTlVEGYPSxsNaBdXUucqA3
	UW6ARl3NEkVG9OLqjge5 = MW8GynzAVHXRphaZ0BeEI()
	rvdeMZlwXqD2IRWj5Ack7BfEm89 = []
	EA7FzO1kMZGQXDd2giB0cwLom = UW6ARl3NEkVG9OLqjge5[YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪ྾")]
	vt2pPxEiYd40DKmu1BRXbOUoaJreQ = o0e6QJ2iBPmfR1pLAMEqz8l(DdAjF5pBNL9IqPgkz0xhcQEfU)
	if AbqCJZdWQP9j(u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫ྿") in list(UW6ARl3NEkVG9OLqjge5.keys()):
		for nR6F28iELvzNG,fqHB10Qnk87Ag6F9C,P4Lz56oAda9 in EA7FzO1kMZGQXDd2giB0cwLom:
			rvdeMZlwXqD2IRWj5Ack7BfEm89 = max(rvdeMZlwXqD2IRWj5Ack7BfEm89,fqHB10Qnk87Ag6F9C)
		if vt2pPxEiYd40DKmu1BRXbOUoaJreQ<rvdeMZlwXqD2IRWj5Ack7BfEm89:
			hTidLWj4qr39P2HoY0x5KSZ = GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠧใ็ࠣฬฯำฯ๋อࠣห้ฮั็ษ่ะ่ࠥศๅࠢศีุอไࠡษ็วำ฽วยࠢ็่๊ฮัๆฮࠪ࿀")
			kCWluLqaQTjbyoOZt0 = Ny92sqomMkizpgKV1(jXE2YHkswT8y(u"ࠨࡴ࡬࡫࡭ࡺࠧ࿁"),CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠩศีุอไࠡว็ํࠥอไๆสิ้ั࠭࿂"),L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠪฮาี๊ฬࠩ࿃"),LyNiIHPOwD3hCUYEFM7(u"ࠫำื่อࠩ࿄"),q09muWHtpcYS8a7Rr3Jk4LO+hTidLWj4qr39P2HoY0x5KSZ,OVe6XKnFIua3C4Y5HlDPo2x1pqkbG)
			if kCWluLqaQTjbyoOZt0==YYJQyRskpX8jv:
				import lpTiXPCdwE
				lpTiXPCdwE.SMxv29nWI0HbkqUEVrgymYO(rGPen6cSMHQkAywh8vqI9JXiD2)
				KEPGn8jNAtmDB2yS0kZiX4MCw()
			elif kCWluLqaQTjbyoOZt0==nI2JK1RfsGWNY3OarEeMQZ: KEPGn8jNAtmDB2yS0kZiX4MCw()
	z0e2XBbpWTCMfu4cv = QKzCiBOWZus1nSv(PdkZHNBlpg2b7DmX6qRiyVa,yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠬࡲࡩࡴࡶࠪ࿅"),vODxLKW5Ql6r4Fbm8(u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎ࿆ࠩ"),jXE2YHkswT8y(u"ࠧࡂࡎࡏࡣࡘࡋࡎࡕࡡࡈࡖࡗࡕࡒࡔࠩ࿇"))
	if not z0e2XBbpWTCMfu4cv: z0e2XBbpWTCMfu4cv = []
	W4W0dvFVeoH = W4W0dvFVeoH.replace(OTlVEGYPSxsNaBdXUucqA3,tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠨ࡞࡟ࡲࠬ࿈")).replace(tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠩ࡞ࡖ࡙ࡒ࡝ࠨ࿉"),iiy37aKq0pCEIOwfcTh61xb4U).replace(aqEsMBckT2bunGHfl48Wip,iiy37aKq0pCEIOwfcTh61xb4U).replace(YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U)
	noMZGxPfsWlAF8Km1gHhqkCtQi73 = noMZGxPfsWlAF8Km1gHhqkCtQi73.replace(OTlVEGYPSxsNaBdXUucqA3,tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠪࡠࡡࡴࠧ࿊")).replace(HtK4o2sTPgA78U(u"ࠫࡠࡘࡔࡍ࡟ࠪ࿋"),iiy37aKq0pCEIOwfcTh61xb4U).replace(aqEsMBckT2bunGHfl48Wip,iiy37aKq0pCEIOwfcTh61xb4U).replace(YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U)
	yCbO9Xnp2Z = DdAjF5pBNL9IqPgkz0xhcQEfU+IpC4qHXRuyNFjzWv(u"ࠬࡀ࠺ࠨ࿌")+noMZGxPfsWlAF8Km1gHhqkCtQi73
	if yCbO9Xnp2Z in z0e2XBbpWTCMfu4cv:
		hTidLWj4qr39P2HoY0x5KSZ = SaB5hx3PZwXRLtKgrTfQvId(u"࠭ไใัࠣๆ๊ะࠠศ่อࠤุอศใษࠣฬสืำศๆ๋ࠣีอࠠศๆั฻ศࠦลๅ๋ࠣห้๋ศา็ฯࠫ࿍")
		bb5kRv7jh3LaEVJtIfg(AbqCJZdWQP9j(u"ࠧࡳ࡫ࡪ࡬ࡹ࠭࿎"),iiy37aKq0pCEIOwfcTh61xb4U,q09muWHtpcYS8a7Rr3Jk4LO+hTidLWj4qr39P2HoY0x5KSZ,OVe6XKnFIua3C4Y5HlDPo2x1pqkbG)
		return
	BNA6KfzInoaEOvPerdCL = str(ZD1J5rN8u2wzdgqoyULm4).split(uuExaKGL7UONtevRd(u"ࠨ࠰ࠪ࿏"))[FGTfwsjNrB8DvKSZhLIQAb1JnO]
	smglbwR7x2oM = gZ4LwbKaOm[yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠩࡓ࡝࡙ࡎࡏࡏࠩ࿐")][CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"࠶ᓈ")]
	VVznOTKE7NDIe0HGkg = MMCJxEfv0WUek(r3rnfZ7cdxzNFebIRaLSG6B,tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠪࡔࡔ࡙ࡔࠨ࿑"),smglbwR7x2oM,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,sVzojQerUqX(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲࡙ࡈࡐ࡙ࡢࡉ࡝ࡏࡔࡠࡇࡕࡖࡔࡘࡓ࠮࠳ࡶࡸࠬ࿒"),BF6QAiLUNHh7rKOugaw,BF6QAiLUNHh7rKOugaw)
	HGQ5Ty9mlSLwed = VVznOTKE7NDIe0HGkg.content
	PW7ZOUYl2o0EmBKrGJgRQNf1D = dEyT9xhGjolYzLCH7460w3.findall(UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"࡙ࠬࡔࡂࡔࡗ࠾࠿࡙ࡔࡂࡔࡗ࡟ࡡࡸ࡜࡯࡟࠮࠾࠿࠮࠮ࠫࡁࠬ࡟ࡡࡸ࡜࡯࡟࠮࠾࠿࠮࠮ࠫࡁࠬ࡟ࡡࡸ࡜࡯࡟࠮࠾࠿࠮࠮ࠫࡁࠬ࡟ࡡࡸ࡜࡯࡟࠮࠾࠿࠮࠮ࠫࡁࠬ࡟ࡡࡸ࡜࡯࡟࠮ࡉࡓࡊ࠺࠻ࡇࡑࡈࠬ࿓"),HGQ5Ty9mlSLwed,dEyT9xhGjolYzLCH7460w3.DOTALL)
	for Yedj5S6ghRQKJ2nl,Eeg6SmkHcC9Rjp7i4V,NN0FjBH4WlPzUQCeAs,Lj5uUzr1gk7b0RW in PW7ZOUYl2o0EmBKrGJgRQNf1D:
		Yedj5S6ghRQKJ2nl = Yedj5S6ghRQKJ2nl.split(yJeq1BjfiO4NFuwIEzxVLK6b9s(u"࠭ࠫࠨ࿔"))
		NN0FjBH4WlPzUQCeAs = NN0FjBH4WlPzUQCeAs.split(L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠧࠬࠩ࿕"))
		Lj5uUzr1gk7b0RW = Lj5uUzr1gk7b0RW.split(MgP8OjoaiWQEVG59(u"ࠨ࠭ࠪ࿖"))
		if KKmXklH2p8CEqGzDFNI3c0 in Yedj5S6ghRQKJ2nl and yy2jWo16LdtRQeMXHZpPJO==Eeg6SmkHcC9Rjp7i4V and DdAjF5pBNL9IqPgkz0xhcQEfU in NN0FjBH4WlPzUQCeAs and BNA6KfzInoaEOvPerdCL in Lj5uUzr1gk7b0RW:
			hTidLWj4qr39P2HoY0x5KSZ = FRYcH4KL7e9gv5pEB(u"๊ࠩิฬࠦวๅะฺวู๋ࠥา๊ไࠤํฺู๊ษ็ะࠥฮวๅวุำฬืࠠศๆๅหิ๋ࠧ࿗")
			U17QqF2gkI46 = A1AXKupEOfz(L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠪࡶ࡮࡭ࡨࡵࠩ࿘"),jXE2YHkswT8y(u"ࠫำื่อࠩ࿙"),sVzojQerUqX(u"ࠬหัิษ็ࠤส๊้ࠡษ็้อืๅอࠩ࿚"),q09muWHtpcYS8a7Rr3Jk4LO+hTidLWj4qr39P2HoY0x5KSZ,OVe6XKnFIua3C4Y5HlDPo2x1pqkbG)
			if U17QqF2gkI46==YYJQyRskpX8jv: bb5kRv7jh3LaEVJtIfg(tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"࠭ࡣࡦࡰࡷࡩࡷ࠭࿛"),iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,hTidLWj4qr39P2HoY0x5KSZ)
			return
	hTidLWj4qr39P2HoY0x5KSZ = yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠧศๆิะฬวࠠฦำึห้ࠦ็ัษࠣห้ิืฤࠢศ่๎ࠦวๅ็หี๊าࠧ࿜")
	Mj31nS0Be7h2g = Ny92sqomMkizpgKV1(SaB5hx3PZwXRLtKgrTfQvId(u"ࠨࡴ࡬࡫࡭ࡺࠧ࿝"),JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠩศีุอไࠡว็ํࠥอไๆสิ้ั࠭࿞"),JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠪฮาี๊ฬࠢฯึห๐ࠧ࿟"),Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠫฯำฯ๋อࠣห้ฮั็ษ่ะࠬ࿠"),q09muWHtpcYS8a7Rr3Jk4LO+hTidLWj4qr39P2HoY0x5KSZ,OVe6XKnFIua3C4Y5HlDPo2x1pqkbG)
	if Mj31nS0Be7h2g==YYJQyRskpX8jv:
		kqAyL0F4bUcl1svBPn(BF6QAiLUNHh7rKOugaw)
		YYkhEn5xTXLUevzCVNB16mR(PtkEvXAqif14G20QZsaSyT(u"ࠬ์ฬฮฬࠣ฽๊๊๊สࠢส่ฯำฯ๋อࠣห้าาว์ࠪ࿡"),TlGXWLYsV1z(u"࠭ํࡔࡷࡦࡧࡪࡹࡳࠨ࿢"),X2cQ5NCPvkMieBW7oASspFjE=XrTw01KtLzbpoyMf(u"࠸࠷࠳ᓉ"))
		KEPGn8jNAtmDB2yS0kZiX4MCw()
	elif Mj31nS0Be7h2g==nI2JK1RfsGWNY3OarEeMQZ:
		import lpTiXPCdwE
		lpTiXPCdwE.SMxv29nWI0HbkqUEVrgymYO(rGPen6cSMHQkAywh8vqI9JXiD2)
		KEPGn8jNAtmDB2yS0kZiX4MCw()
	U17QqF2gkI46 = A1AXKupEOfz(LyNiIHPOwD3hCUYEFM7(u"ࠧࡤࡧࡱࡸࡪࡸࠧ࿣"),iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,y6y5HtgXO4TkUbwVZ(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ࿤"),GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠩึ์ๆ๊ࠦห็ࠣษึูวๅࠢึะ้ࠦวๅลั฻ฬว้ࠠษ็หุะฮะษ่ࠤส๊้ࠡษ็้อืๅอࠢ็็๏ฺ๊ࠦำไࠤฬ๊ๅษำ่ะࠥษ๊็๋้ࠢฯ๏้ࠠๅํๅࠥ๎ไๆษำหࠥำีๅฬ๋ࠣีํࠠศๆุ่่๊ษࠡๆฦ๊ࠥอไๆสิ้ัࠦไศࠢํ฽้๋ࠠศๆ฽๎อ่ࠦๅษࠣ๎ุะื๋฻ࠣหฺ๊วฮุ่่๊ࠢษ๊๊ࠡ์๊ࠥวࠡ์฼ีๆࠦใ๋ใࠣ฼์ืส๊ࠡ็้ฬึวฺ๊ࠡีฯ่ࠦๆฬ์ࠤ฽ํัห๊ࠢิ์ࠦวๅ็ื็้ฯࠠ࠯๊่ࠢࠥะั๋ัࠣวึูวๅࠢสุ่าไࠡมࠪ࿥"))
	if U17QqF2gkI46==YYJQyRskpX8jv: fcBu5mjy96oVdizMUI = jXE2YHkswT8y(u"ࠪࡣࡕࡘࡏࡃࡎࡈࡑࡤ࠭࿦")
	else:
		bb5kRv7jh3LaEVJtIfg(xpT28sXu051(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ࿧"),iiy37aKq0pCEIOwfcTh61xb4U,hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ࿨"),aqEsMBckT2bunGHfl48Wip+ZchUJdM93pTA7zG5(u"࠭สๆࠢศ่฿อมࠡวิืฬ๊ࠠศๆั฻ศ࠭࿩")+YoQW601K4fMJcsreDnGVE5wUZIy7+vODxLKW5Ql6r4Fbm8(u"ࠧ࡝ࡰ็ว๋ࠦวๅ็หี๊าࠠๅษࠣ๎฾๊ๅࠡษ็฾๏ฮ้ࠠๆสࠤ๏ูสุ์฼ࠤส฻ไศฯࠣห้ิืฤࠢหำํ์ࠠิฮ็ࠤฬ๊รฯูสลࠥอไั์้่ࠣะ่ษࠢไ๎์ࠦฬๆ์฼ࠤฯ็วึ์็ࠤ์ึวࠡษ็า฼ษ้ࠠ฼ํี์ࠦๅ็ࠢส่ศิืศรࠪ࿪"))
		return
	NNFlSgsp39MWCGxaXEILe = W4W0dvFVeoH
	import lpTiXPCdwE
	M5qyIg2dZlm6FxH4tTPV79okNu0bCG = lpTiXPCdwE.EmxZ2PWFGSaYQNkclpnVsR(y6y5HtgXO4TkUbwVZ(u"ࠨࡇࡵࡶࡴࡸࡳࠨ࿫"),NNFlSgsp39MWCGxaXEILe,rGPen6cSMHQkAywh8vqI9JXiD2,iiy37aKq0pCEIOwfcTh61xb4U,ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠩࡈࡑࡆࡏࡌ࠮ࡈࡕࡓࡒ࠳ࡓࡉࡑ࡚ࡣࡊ࡞ࡉࡕࡡࡈࡖࡗࡕࡒࡔࠩ࿬"),fcBu5mjy96oVdizMUI)
	if M5qyIg2dZlm6FxH4tTPV79okNu0bCG and fcBu5mjy96oVdizMUI:
		z0e2XBbpWTCMfu4cv.append(yCbO9Xnp2Z)
		YMQXP2BGeK86CEb(PdkZHNBlpg2b7DmX6qRiyVa,jXE2YHkswT8y(u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭࿭"),hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠫࡆࡒࡌࡠࡕࡈࡒ࡙ࡥࡅࡓࡔࡒࡖࡘ࠭࿮"),z0e2XBbpWTCMfu4cv,VaeMF1mIjQ5iLtfGcB)
	return
def f9nhoOBItUCu0YeQ7T(oRzlSfeE6DY0mFy37NCVxAJW1BwZtM,filename=None):
	if J1MoiYc7ZwzKS: oRzlSfeE6DY0mFy37NCVxAJW1BwZtM = oRzlSfeE6DY0mFy37NCVxAJW1BwZtM.encode(df6QpwGxuJVZr)
	if not filename: VBb0cK9HdXsp5ouJ17vhewL6GRztn = SaB5hx3PZwXRLtKgrTfQvId(u"ࠬࡹ࠺࡝࡞࠳࠴࠵࠶ࡥ࡮ࡣࡧࡣࠬ࿯")+str(X2cQ5NCPvkMieBW7oASspFjE.time())+SaB5hx3PZwXRLtKgrTfQvId(u"࠭࠮ࡥࡣࡷࠫ࿰")
	else: VBb0cK9HdXsp5ouJ17vhewL6GRztn = IpC4qHXRuyNFjzWv(u"ࠧࡴ࠼࡟ࡠ࠵࠶࠰࠱ࡧࡰࡥࡩࡥࠧ࿱")+filename+yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠨ࠰ࡧࡥࡹ࠭࿲")
	open(VBb0cK9HdXsp5ouJ17vhewL6GRztn,hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠩࡺࡦࠬ࿳")).write(oRzlSfeE6DY0mFy37NCVxAJW1BwZtM)
	return
def QeY9sWZqAhDomcd3rMIp(iQ2tN1nLmJH7GCchv4u0VoSKlb):
	if iQ2tN1nLmJH7GCchv4u0VoSKlb:
		ddxk8CzNrlhiJtSeTDLVEa0c = QKzCiBOWZus1nSv(PdkZHNBlpg2b7DmX6qRiyVa,TlGXWLYsV1z(u"ࠪࡰ࡮ࡹࡴࠨ࿴"),jXE2YHkswT8y(u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧ࿵"),y6y5HtgXO4TkUbwVZ(u"ࠬࡗࡕࡆࡕࡗࡍࡔࡔࡓࠨ࿶"))
		if ddxk8CzNrlhiJtSeTDLVEa0c: return ddxk8CzNrlhiJtSeTDLVEa0c
	smglbwR7x2oM = gZ4LwbKaOm[ZchUJdM93pTA7zG5(u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭࿷")][sVzojQerUqX(u"࠷ᓊ")]
	BBWS6VTi15YeM2bvJGXtxpslDhg8 = GmTZdMqCPhJs3pUcgS4tBOki(BF6QAiLUNHh7rKOugaw) if not iQ2tN1nLmJH7GCchv4u0VoSKlb else iw3BpJl1Y9tbg8XMR4VeoS6kEUhf
	A35buNj8r7ydgkYsOQvW0 = hz5lWCRmTwgFV48NSMBPY9AKf()
	CCsm1xkvzejL0RSQZI9JaWD = A35buNj8r7ydgkYsOQvW0.split(XrTw01KtLzbpoyMf(u"ࠧ࠭ࠩ࿸"))[nI2JK1RfsGWNY3OarEeMQZ]
	WtfFabx8qHizMG5LlX60YkBZ = wkMR5x1gTWEQIc6qHCa.path.join(V5f96hvSkeUwCxZrE4dlzpy,jXE2YHkswT8y(u"ࠨࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧ࿹"))
	KyD5k2s1SoFv47RI8GlHmXBq = UELnHN0VWlGoZKa8Mu4riQTkgSC2()
	nT4CcjPoyq1NWYeDSrgkJxB0F2tHp = {hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠩࡸࡷࡪࡸࠧ࿺"):BBWS6VTi15YeM2bvJGXtxpslDhg8,vODxLKW5Ql6r4Fbm8(u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫ࿻"):DdAjF5pBNL9IqPgkz0xhcQEfU,MgP8OjoaiWQEVG59(u"ࠫࡨࡵࡵ࡯ࡶࡵࡽࠬ࿼"):CCsm1xkvzejL0RSQZI9JaWD,xpT28sXu051(u"ࠬ࡯ࡤࡴࠩ࿽"):kTJISUV1CbZQ2gndAuMwBP7(KyD5k2s1SoFv47RI8GlHmXBq)}
	VVznOTKE7NDIe0HGkg = MMCJxEfv0WUek(hI7SkXd94fFzAHNZCQoMqEutbnWP,tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"࠭ࡐࡐࡕࡗࠫ࿾"),smglbwR7x2oM,nT4CcjPoyq1NWYeDSrgkJxB0F2tHp,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡉࡈࡘࡤࡗࡕࡆࡕࡗࡍࡔࡔࡓ࠮࠳ࡶࡸࠬ࿿"))
	ddxk8CzNrlhiJtSeTDLVEa0c = []
	if VVznOTKE7NDIe0HGkg.succeeded:
		HGQ5Ty9mlSLwed = VVznOTKE7NDIe0HGkg.content
		ddxk8CzNrlhiJtSeTDLVEa0c = HGQ5Ty9mlSLwed.replace(XrTw01KtLzbpoyMf(u"ࠨ࡞࡟ࡶࠬက"),OTlVEGYPSxsNaBdXUucqA3).replace(AbqCJZdWQP9j(u"ࠩ࡟ࡠࡳ࠭ခ"),OTlVEGYPSxsNaBdXUucqA3).replace(GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠪࡠࡷࡢ࡮ࠨဂ"),OTlVEGYPSxsNaBdXUucqA3).replace(Mge0HhFk9Ic6sm5VR,OTlVEGYPSxsNaBdXUucqA3)
		ddxk8CzNrlhiJtSeTDLVEa0c = dEyT9xhGjolYzLCH7460w3.findall(CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠫࡘ࡚ࡁࡓࡖ࠽࠾ࡘ࡚ࡁࡓࡖ࠽࠾࠭ࡢࡤࠬࠫ࠽࠾࠭࠴ࠪࡀࠫ࡟ࡲ࠿ࡀࠨ࠯ࠬࡂ࠭ࡡࡴ࠺࠻ࠪ࠱࠮ࡄ࠯࡜࡯࠼࠽ࠬ࠳࠰࠿ࠪ࡞ࡱ࠾࠿࠮࠮ࠫࡁࠬࡠࡳࡋࡎࡅ࠼࠽ࡉࡓࡊࠧဃ"),ddxk8CzNrlhiJtSeTDLVEa0c,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if ddxk8CzNrlhiJtSeTDLVEa0c:
			ddxk8CzNrlhiJtSeTDLVEa0c = sorted(ddxk8CzNrlhiJtSeTDLVEa0c,reverse=BF6QAiLUNHh7rKOugaw,key=lambda key: int(key[FGTfwsjNrB8DvKSZhLIQAb1JnO]))
			Tj2xuNbqyrLMeoaYJB7Sh3IiU,BBWS6VTi15YeM2bvJGXtxpslDhg8,bl81eAwQG63tZjRhSzX0dCIv,OC9lxzDodrFpvn8X6kMebAfE1tKS,GNzbpq6tvX1kZjgixEmSn,LXSBswmknoDzdT1hQqlUie = ddxk8CzNrlhiJtSeTDLVEa0c[FGTfwsjNrB8DvKSZhLIQAb1JnO]
			AEJlh3LQpHiGv07UKZF8Dge2XqBI = LXSBswmknoDzdT1hQqlUie if EETfYmdIcBQsXGiLzpODJxr35e([CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠬࡓࡔ࠱࠷ࡋ࡜࠵ࡲࡔࡕࡇࡉࡒࡘ࡛ࡎࡧࡗࡈ࡚ࡘ࡙ࡕ࠺ࡇ࡛ࠫင")])[FGTfwsjNrB8DvKSZhLIQAb1JnO] else bl81eAwQG63tZjRhSzX0dCIv
			OXsckY7RzjCag9A.setSetting(AbqCJZdWQP9j(u"࠭ࡡࡷ࠰ࡳࡩࡷ࡯࡯ࡥ࠰࡬ࡲ࡫ࡵࡳࠨစ"),AEJlh3LQpHiGv07UKZF8Dge2XqBI)
			YMQXP2BGeK86CEb(PdkZHNBlpg2b7DmX6qRiyVa,jXE2YHkswT8y(u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪဆ"),Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠨࡓࡘࡉࡘ࡚ࡉࡐࡐࡖࠫဇ"),ddxk8CzNrlhiJtSeTDLVEa0c,PNjZMS7nxa9clHusz1)
			OXsckY7RzjCag9A.setSetting(L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯ࡳࡸࡩࡸࡺࡩࡰࡰࡶࠫဈ"),kTJISUV1CbZQ2gndAuMwBP7(pwXCQWuGUMka2hFN))
	return ddxk8CzNrlhiJtSeTDLVEa0c
def QavKJFzZAO3(QQlIRbV9urgv1tWkn8,xAlUSbZaKEI=FGTfwsjNrB8DvKSZhLIQAb1JnO,mNV4bv9cgFL=FGTfwsjNrB8DvKSZhLIQAb1JnO):
	if xAlUSbZaKEI and not mNV4bv9cgFL: mNV4bv9cgFL = len(QQlIRbV9urgv1tWkn8)//xAlUSbZaKEI
	gp3OJEb8QheaBYNw7I0vKPx9cXkDSU,o6oXFxmE1bQC,O1tzxUQDMC7fVdjb8BRck = [],-YYJQyRskpX8jv,FGTfwsjNrB8DvKSZhLIQAb1JnO
	for YVKo4mpBq9vEeUfM7JR8ujSP in QQlIRbV9urgv1tWkn8:
		if O1tzxUQDMC7fVdjb8BRck%mNV4bv9cgFL==FGTfwsjNrB8DvKSZhLIQAb1JnO:
			o6oXFxmE1bQC += YYJQyRskpX8jv
			gp3OJEb8QheaBYNw7I0vKPx9cXkDSU.append([])
		gp3OJEb8QheaBYNw7I0vKPx9cXkDSU[o6oXFxmE1bQC].append(YVKo4mpBq9vEeUfM7JR8ujSP)
		O1tzxUQDMC7fVdjb8BRck += YYJQyRskpX8jv
	return gp3OJEb8QheaBYNw7I0vKPx9cXkDSU
def mkjVeYaE3sdbHUCXBKzG9ZO8oPv(VBb0cK9HdXsp5ouJ17vhewL6GRztn,oRzlSfeE6DY0mFy37NCVxAJW1BwZtM):
	lGvCUxi8ZRowBHJDf = wkMR5x1gTWEQIc6qHCa.path.join(StqmrCIJX4T623w5j9NEonxfQ,VBb0cK9HdXsp5ouJ17vhewL6GRztn)
	if YYJQyRskpX8jv or uuExaKGL7UONtevRd(u"ࠪࡍࡕ࡚ࡖࡠࠩဉ") not in VBb0cK9HdXsp5ouJ17vhewL6GRztn or UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠫࡒ࠹ࡕࡠࠩည") not in VBb0cK9HdXsp5ouJ17vhewL6GRztn: XiWJ2PTqvds4pBNebVrt98x = str(oRzlSfeE6DY0mFy37NCVxAJW1BwZtM)
	else:
		gp3OJEb8QheaBYNw7I0vKPx9cXkDSU = QavKJFzZAO3(oRzlSfeE6DY0mFy37NCVxAJW1BwZtM,FRYcH4KL7e9gv5pEB(u"࠻ᓋ"))
		XiWJ2PTqvds4pBNebVrt98x = iiy37aKq0pCEIOwfcTh61xb4U
		for DvjA02fiCYq in gp3OJEb8QheaBYNw7I0vKPx9cXkDSU:
			XiWJ2PTqvds4pBNebVrt98x += str(DvjA02fiCYq)+ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠬࡢ࡮࡝ࡰࡀࡁࡂࡃ࡜࡯࡞ࡱࠫဋ")
		XiWJ2PTqvds4pBNebVrt98x = XiWJ2PTqvds4pBNebVrt98x.strip(L90uqo28xEKSFUwYTcm51yRWZIkft(u"࠭࡜࡯࡞ࡱࡁࡂࡃ࠽࡝ࡰ࡟ࡲࠬဌ"))
	uoa3GNT7wrAci = MZHConzbXxjIDNLV.compress(XiWJ2PTqvds4pBNebVrt98x)
	open(lGvCUxi8ZRowBHJDf,TlGXWLYsV1z(u"ࠧࡸࡤࠪဍ")).write(uoa3GNT7wrAci)
	return
def Loy9U7meKlGw5JpbS(hhMxKFyp3IBbVLvfi9,VBb0cK9HdXsp5ouJ17vhewL6GRztn):
	if hhMxKFyp3IBbVLvfi9==XrTw01KtLzbpoyMf(u"ࠨࡦ࡬ࡧࡹ࠭ဎ"): oRzlSfeE6DY0mFy37NCVxAJW1BwZtM = {}
	elif hhMxKFyp3IBbVLvfi9==L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠩ࡯࡭ࡸࡺࠧဏ"): oRzlSfeE6DY0mFy37NCVxAJW1BwZtM = []
	elif hhMxKFyp3IBbVLvfi9==PtkEvXAqif14G20QZsaSyT(u"ࠪࡷࡹࡸࠧတ"): oRzlSfeE6DY0mFy37NCVxAJW1BwZtM = iiy37aKq0pCEIOwfcTh61xb4U
	elif hhMxKFyp3IBbVLvfi9==tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠫ࡮ࡴࡴࠨထ"): oRzlSfeE6DY0mFy37NCVxAJW1BwZtM = FGTfwsjNrB8DvKSZhLIQAb1JnO
	else: oRzlSfeE6DY0mFy37NCVxAJW1BwZtM = None
	lGvCUxi8ZRowBHJDf = wkMR5x1gTWEQIc6qHCa.path.join(StqmrCIJX4T623w5j9NEonxfQ,VBb0cK9HdXsp5ouJ17vhewL6GRztn)
	uoa3GNT7wrAci = open(lGvCUxi8ZRowBHJDf,SaB5hx3PZwXRLtKgrTfQvId(u"ࠬࡸࡢࠨဒ")).read()
	XiWJ2PTqvds4pBNebVrt98x = MZHConzbXxjIDNLV.decompress(uoa3GNT7wrAci)
	if sVzojQerUqX(u"࠭࡜࡯࡞ࡱࡁࡂࡃ࠽࡝ࡰ࡟ࡲࠬဓ") not in XiWJ2PTqvds4pBNebVrt98x: oRzlSfeE6DY0mFy37NCVxAJW1BwZtM = eval(XiWJ2PTqvds4pBNebVrt98x)
	else:
		gp3OJEb8QheaBYNw7I0vKPx9cXkDSU = XiWJ2PTqvds4pBNebVrt98x.split(IpC4qHXRuyNFjzWv(u"ࠧ࡝ࡰ࡟ࡲࡂࡃ࠽࠾࡞ࡱࡠࡳ࠭န"))
		del XiWJ2PTqvds4pBNebVrt98x
		oRzlSfeE6DY0mFy37NCVxAJW1BwZtM = []
		CCGgIlis9pjc5oLkh6MA7mYUtqQ0 = tIvpmRVh8Z0lHS9sk4ECg6Ni5PeDWJ()
		Tj2xuNbqyrLMeoaYJB7Sh3IiU = FGTfwsjNrB8DvKSZhLIQAb1JnO
		for DvjA02fiCYq in gp3OJEb8QheaBYNw7I0vKPx9cXkDSU:
			CCGgIlis9pjc5oLkh6MA7mYUtqQ0.xrm0JkzUa3IQfKZ(str(Tj2xuNbqyrLMeoaYJB7Sh3IiU),eval,DvjA02fiCYq)
			Tj2xuNbqyrLMeoaYJB7Sh3IiU += YYJQyRskpX8jv
		del gp3OJEb8QheaBYNw7I0vKPx9cXkDSU
		CCGgIlis9pjc5oLkh6MA7mYUtqQ0.vP7SpKieY3rsuJ02X()
		CCGgIlis9pjc5oLkh6MA7mYUtqQ0.h9hJBOE2PyG6M8U0AVQIlkLqvpi()
		OOUe9mGQYo81 = list(CCGgIlis9pjc5oLkh6MA7mYUtqQ0.resultsDICT.keys())
		VgDKYvqrUfQShRjTu25skJw = sorted(OOUe9mGQYo81,reverse=BF6QAiLUNHh7rKOugaw,key=lambda key: int(key))
		for Tj2xuNbqyrLMeoaYJB7Sh3IiU in VgDKYvqrUfQShRjTu25skJw:
			oRzlSfeE6DY0mFy37NCVxAJW1BwZtM += CCGgIlis9pjc5oLkh6MA7mYUtqQ0.resultsDICT[Tj2xuNbqyrLMeoaYJB7Sh3IiU]
	return oRzlSfeE6DY0mFy37NCVxAJW1BwZtM
def T45yMNop1tga2KAZO6FG0URLPYXb(M8hQu61Uid):
	pp259Gc4RHvXwhQdi = wkMR5x1gTWEQIc6qHCa.path.join(Hyw4UJ6ephu,TlGXWLYsV1z(u"ࠨࡣࡧࡨࡴࡴࡳࠨပ"),M8hQu61Uid,ZchUJdM93pTA7zG5(u"ࠩࡤࡨࡩࡵ࡮࠯ࡺࡰࡰࠬဖ"))
	try: VdBIMzWtwsSK30qbLDXruxGNkP = open(pp259Gc4RHvXwhQdi,ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠪࡶࡧ࠭ဗ")).read()
	except:
		D6PN12Ma0EY7qXAKh4f = wkMR5x1gTWEQIc6qHCa.path.join(K1KA8whDjRrQI3OBgMzbLo9,CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠫࡦࡪࡤࡰࡰࡶࠫဘ"),M8hQu61Uid,vODxLKW5Ql6r4Fbm8(u"ࠬࡧࡤࡥࡱࡱ࠲ࡽࡳ࡬ࠨမ"))
		try: VdBIMzWtwsSK30qbLDXruxGNkP = open(D6PN12Ma0EY7qXAKh4f,ZchUJdM93pTA7zG5(u"࠭ࡲࡣࠩယ")).read()
		except: return iiy37aKq0pCEIOwfcTh61xb4U,[]
	if J1MoiYc7ZwzKS: VdBIMzWtwsSK30qbLDXruxGNkP = VdBIMzWtwsSK30qbLDXruxGNkP.decode(df6QpwGxuJVZr)
	HXRtwCZadsgTAB2uISoQW13MYP = dEyT9xhGjolYzLCH7460w3.findall(tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠧࡪࡦࡀ࠲࠯ࡅࡶࡦࡴࡶ࡭ࡴࡴ࠽࡜࡞ࠥࡠࠬࡣࠨ࠯ࠬࡂ࠭ࡠࡢࠢ࡝ࠩࡠࠫရ"),VdBIMzWtwsSK30qbLDXruxGNkP,dEyT9xhGjolYzLCH7460w3.DOTALL|dEyT9xhGjolYzLCH7460w3.IGNORECASE)
	if not HXRtwCZadsgTAB2uISoQW13MYP: return iiy37aKq0pCEIOwfcTh61xb4U,[]
	q4Bk3sES9TP7Ld8fDVU,aaAJdWzjTy9RsLYUKNh4 = HXRtwCZadsgTAB2uISoQW13MYP[FGTfwsjNrB8DvKSZhLIQAb1JnO],o0e6QJ2iBPmfR1pLAMEqz8l(HXRtwCZadsgTAB2uISoQW13MYP[FGTfwsjNrB8DvKSZhLIQAb1JnO])
	return q4Bk3sES9TP7Ld8fDVU,aaAJdWzjTy9RsLYUKNh4
def MW8GynzAVHXRphaZ0BeEI():
	e2MA1mhKP4JZdyrWSwHxYX = QKzCiBOWZus1nSv(PdkZHNBlpg2b7DmX6qRiyVa,JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠨࡦ࡬ࡧࡹ࠭လ"),SaB5hx3PZwXRLtKgrTfQvId(u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬဝ"),uuExaKGL7UONtevRd(u"ࠪࡅࡑࡒ࡟ࡂࡆࡇࡓࡓ࡙࡟࡙ࡏࡏࠫသ"))
	if e2MA1mhKP4JZdyrWSwHxYX: return e2MA1mhKP4JZdyrWSwHxYX
	UW6ARl3NEkVG9OLqjge5,e2MA1mhKP4JZdyrWSwHxYX = {},{}
	fwNvItaL3xQTbzmYMq = [gZ4LwbKaOm[GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠫࡗࡋࡐࡐࡕࠪဟ")][FGTfwsjNrB8DvKSZhLIQAb1JnO]]
	if ZD1J5rN8u2wzdgqoyULm4>hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"࠵࠼࠴࠹࠺ᓌ"): fwNvItaL3xQTbzmYMq.append(gZ4LwbKaOm[CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠬࡘࡅࡑࡑࡖࠫဠ")][YYJQyRskpX8jv])
	if J1MoiYc7ZwzKS: fwNvItaL3xQTbzmYMq.append(gZ4LwbKaOm[L90uqo28xEKSFUwYTcm51yRWZIkft(u"࠭ࡒࡆࡒࡒࡗࠬအ")][nI2JK1RfsGWNY3OarEeMQZ])
	for rKkHdYQaRvNOPSB73pWMZ in fwNvItaL3xQTbzmYMq:
		VVznOTKE7NDIe0HGkg = MMCJxEfv0WUek(hI7SkXd94fFzAHNZCQoMqEutbnWP,ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠧࡈࡇࡗࠫဢ"),rKkHdYQaRvNOPSB73pWMZ,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,ZchUJdM93pTA7zG5(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡕࡉࡆࡊ࡟ࡂࡎࡏࡣࡆࡊࡄࡐࡐࡖࡣ࡝ࡓࡌ࠮࠳ࡶࡸࠬဣ"))
		if VVznOTKE7NDIe0HGkg.succeeded:
			HGQ5Ty9mlSLwed = VVznOTKE7NDIe0HGkg.content
			K8zyt0aCc5SbWn9EuHhDs6qld7F = rKkHdYQaRvNOPSB73pWMZ.rsplit(vODxLKW5Ql6r4Fbm8(u"ࠩ࠲ࠫဤ"),XrTw01KtLzbpoyMf(u"࠶ᓍ"))[FGTfwsjNrB8DvKSZhLIQAb1JnO]
			VvOuHkK2oF95QzGJ = dEyT9xhGjolYzLCH7460w3.findall(L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠪ࡭ࡩࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡹࡩࡷࡹࡩࡰࡰࡀࠦ࠭࠴ࠪࡀࠫࠥࠫဥ"),HGQ5Ty9mlSLwed,dEyT9xhGjolYzLCH7460w3.DOTALL|dEyT9xhGjolYzLCH7460w3.IGNORECASE)
			for M8hQu61Uid,vL1e7UYNRHlZES in VvOuHkK2oF95QzGJ:
				xCRySI9jcqTVDdvWb8M = K8zyt0aCc5SbWn9EuHhDs6qld7F+hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠫ࠴࠭ဦ")+M8hQu61Uid+MgP8OjoaiWQEVG59(u"ࠬ࠵ࠧဧ")+M8hQu61Uid+ZchUJdM93pTA7zG5(u"࠭࠭ࠨဨ")+vL1e7UYNRHlZES+TlGXWLYsV1z(u"ࠧ࠯ࡼ࡬ࡴࠬဩ")
				if M8hQu61Uid not in list(UW6ARl3NEkVG9OLqjge5.keys()):
					UW6ARl3NEkVG9OLqjge5[M8hQu61Uid] = []
					e2MA1mhKP4JZdyrWSwHxYX[M8hQu61Uid] = []
				aGTI45QL3E2yBZkH9UwCrRvV = o0e6QJ2iBPmfR1pLAMEqz8l(vL1e7UYNRHlZES)
				UW6ARl3NEkVG9OLqjge5[M8hQu61Uid].append((vL1e7UYNRHlZES,aGTI45QL3E2yBZkH9UwCrRvV,xCRySI9jcqTVDdvWb8M))
	for M8hQu61Uid in list(UW6ARl3NEkVG9OLqjge5.keys()):
		e2MA1mhKP4JZdyrWSwHxYX[M8hQu61Uid] = sorted(UW6ARl3NEkVG9OLqjge5[M8hQu61Uid],reverse=rGPen6cSMHQkAywh8vqI9JXiD2,key=lambda key: key[YYJQyRskpX8jv])
	YMQXP2BGeK86CEb(PdkZHNBlpg2b7DmX6qRiyVa,Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫဪ"),CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠩࡄࡐࡑࡥࡁࡅࡆࡒࡒࡘࡥࡘࡎࡎࠪါ"),e2MA1mhKP4JZdyrWSwHxYX,PNjZMS7nxa9clHusz1)
	return e2MA1mhKP4JZdyrWSwHxYX
def o0e6QJ2iBPmfR1pLAMEqz8l(vL1e7UYNRHlZES):
	aGTI45QL3E2yBZkH9UwCrRvV = []
	nx9kySHIKbzOJAtam0Bc1LV = vL1e7UYNRHlZES.split(CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠪ࠲ࠬာ"))
	for jT015I89yKiM3Xzl in nx9kySHIKbzOJAtam0Bc1LV:
		kaUh70Yf1EeC5nBix6FAgmoGd = dEyT9xhGjolYzLCH7460w3.findall(ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠫࡡࡪࠫࡽ࡝࡟࠯ࡡ࠳ࡡ࠮ࡼࡄ࠱࡟ࡣࠫࠨိ"),jT015I89yKiM3Xzl,dEyT9xhGjolYzLCH7460w3.DOTALL)
		kKU0my3NP8sD = []
		for z7UI4JxHqlNr5ianR3Lsj1 in kaUh70Yf1EeC5nBix6FAgmoGd:
			if z7UI4JxHqlNr5ianR3Lsj1.isdigit(): z7UI4JxHqlNr5ianR3Lsj1 = int(z7UI4JxHqlNr5ianR3Lsj1)
			kKU0my3NP8sD.append(z7UI4JxHqlNr5ianR3Lsj1)
		aGTI45QL3E2yBZkH9UwCrRvV.append(kKU0my3NP8sD)
	return aGTI45QL3E2yBZkH9UwCrRvV
def fFxkWTej6g7tYQ2Jq4Za(aGTI45QL3E2yBZkH9UwCrRvV):
	vL1e7UYNRHlZES = iiy37aKq0pCEIOwfcTh61xb4U
	for jT015I89yKiM3Xzl in aGTI45QL3E2yBZkH9UwCrRvV:
		for z7UI4JxHqlNr5ianR3Lsj1 in jT015I89yKiM3Xzl: vL1e7UYNRHlZES += str(z7UI4JxHqlNr5ianR3Lsj1)
		vL1e7UYNRHlZES += vODxLKW5Ql6r4Fbm8(u"ࠬ࠴ࠧီ")
	vL1e7UYNRHlZES = vL1e7UYNRHlZES.strip(zmcGfOdvAjsELeJlP(u"࠭࠮ࠨု"))
	return vL1e7UYNRHlZES
def Mk1o9HmfhFYupBtdi3(T0nxf19jK45XgUIchJ8M2zpet):
	qQsCzJV2Wgr63in8YF1E0dXf9OSG = {}
	UW6ARl3NEkVG9OLqjge5 = MW8GynzAVHXRphaZ0BeEI()
	cRKfmdWpl5hGJk9eLNCEob = wd9kGFayMlcZgEoufxVU(T0nxf19jK45XgUIchJ8M2zpet)
	for M8hQu61Uid in T0nxf19jK45XgUIchJ8M2zpet:
		if M8hQu61Uid not in list(UW6ARl3NEkVG9OLqjge5.keys()): continue
		e2MA1mhKP4JZdyrWSwHxYX = UW6ARl3NEkVG9OLqjge5[M8hQu61Uid]
		XwLoV0RdYqZ6CFj9sgGuyOciE,B153K72OyIhV,Cqk5fbThjz9LAIUPH = e2MA1mhKP4JZdyrWSwHxYX[FGTfwsjNrB8DvKSZhLIQAb1JnO]
		M0A7hVgYLTC3DtidwyIQ,B1U7oLRzXtQGjSeYyv = T45yMNop1tga2KAZO6FG0URLPYXb(M8hQu61Uid)
		aaqgsZLkyCPxnQ,rP6S9wgnfFY05 = cRKfmdWpl5hGJk9eLNCEob[M8hQu61Uid]
		hh6Dzpvg1UYnWTxV = B153K72OyIhV>B1U7oLRzXtQGjSeYyv and aaqgsZLkyCPxnQ
		BCG6aEXrN0 = rGPen6cSMHQkAywh8vqI9JXiD2
		if not aaqgsZLkyCPxnQ: aX5FsDV4LZCr6obP8g7zepn2kuMm = zmcGfOdvAjsELeJlP(u"ࠧ࡮࡫ࡶࡷ࡮ࡴࡧࠨူ")
		elif not rP6S9wgnfFY05: aX5FsDV4LZCr6obP8g7zepn2kuMm = uuExaKGL7UONtevRd(u"ࠨࡦ࡬ࡷࡦࡨ࡬ࡦࡦࠪေ")
		elif hh6Dzpvg1UYnWTxV: aX5FsDV4LZCr6obP8g7zepn2kuMm = yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠩࡲࡰࡩ࠭ဲ")
		else:
			aX5FsDV4LZCr6obP8g7zepn2kuMm = PtkEvXAqif14G20QZsaSyT(u"ࠪ࡫ࡴࡵࡤࠨဳ")
			BCG6aEXrN0 = BF6QAiLUNHh7rKOugaw
		qQsCzJV2Wgr63in8YF1E0dXf9OSG[M8hQu61Uid] = BCG6aEXrN0,M0A7hVgYLTC3DtidwyIQ,B1U7oLRzXtQGjSeYyv,XwLoV0RdYqZ6CFj9sgGuyOciE,B153K72OyIhV,aX5FsDV4LZCr6obP8g7zepn2kuMm,Cqk5fbThjz9LAIUPH
	return qQsCzJV2Wgr63in8YF1E0dXf9OSG
def o8oBqwQFbU2uL3SEGD0lgWO4xRnJYC(sspk8CPTnaqeyzALQuD6ExX,lWiKqyJ9swGIcdErB8pP,DqciZw8UkSbdNYLA7xEIR36mTJG=iiy37aKq0pCEIOwfcTh61xb4U,bqPSCmMWRh83n2TZVe=iiy37aKq0pCEIOwfcTh61xb4U,Yedj5S6ghRQKJ2nl=iiy37aKq0pCEIOwfcTh61xb4U):
	if iELueYz3J1FmxaW7vc: sspk8CPTnaqeyzALQuD6ExX.update(lWiKqyJ9swGIcdErB8pP,DqciZw8UkSbdNYLA7xEIR36mTJG,bqPSCmMWRh83n2TZVe,Yedj5S6ghRQKJ2nl)
	else: sspk8CPTnaqeyzALQuD6ExX.update(lWiKqyJ9swGIcdErB8pP,DqciZw8UkSbdNYLA7xEIR36mTJG+OTlVEGYPSxsNaBdXUucqA3+bqPSCmMWRh83n2TZVe+OTlVEGYPSxsNaBdXUucqA3+Yedj5S6ghRQKJ2nl)
	return
def D9gvQoIknzpr5chBa6Y2VKHxPq(EmgOrMcPySkh2oFitb4qvNU7nQGD):
	def RqfVSiLWZ7n1p4GJKI6(H5l2Bw6y7WqeCaPs,g9k3MPLDoW4E8pRTFw,CpqsbGdFE108RDPujk7lO6=L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠦ࠵࠷࠲࠴࠶࠸࠺࠼࠾࠹ࡢࡤࡦࡨࡪ࡬ࡧࡩ࡫࡭࡯ࡱࡳ࡮ࡰࡲࡴࡶࡸࡺࡵࡷࡹࡻࡽࡿࡇࡂࡄࡆࡈࡊࡌࡎࡉࡋࡍࡏࡑࡓࡕࡐࡒࡔࡖࡘ࡚࡜ࡗ࡙࡛࡝ࠦဴ")):
		return ((H5l2Bw6y7WqeCaPs == FGTfwsjNrB8DvKSZhLIQAb1JnO) and CpqsbGdFE108RDPujk7lO6[FGTfwsjNrB8DvKSZhLIQAb1JnO]) or (RqfVSiLWZ7n1p4GJKI6(H5l2Bw6y7WqeCaPs // g9k3MPLDoW4E8pRTFw, g9k3MPLDoW4E8pRTFw, CpqsbGdFE108RDPujk7lO6).lstrip(CpqsbGdFE108RDPujk7lO6[FGTfwsjNrB8DvKSZhLIQAb1JnO]) + CpqsbGdFE108RDPujk7lO6[H5l2Bw6y7WqeCaPs % g9k3MPLDoW4E8pRTFw])
	def tp6P01uKQAvl74bqYsVf(SSzAxMcIq7i5tbZUvY2OVyfR, DToJiUqZ8rBGbhfISdxue2kv, ZqBwlJjmTE5Oba9XfvNAn, Naex4Y1fFLvocdbuD6C2ZwmpXl0By8, WdsFGJj2plQtVuok6D=None, cmtDvXxpZyuI8KW=None, Y5YCE2teLPfAUb4HJmlrQasvzOj=None):
		while (ZqBwlJjmTE5Oba9XfvNAn):
			ZqBwlJjmTE5Oba9XfvNAn-=yJeq1BjfiO4NFuwIEzxVLK6b9s(u"࠷ᓎ")
			if (Naex4Y1fFLvocdbuD6C2ZwmpXl0By8[ZqBwlJjmTE5Oba9XfvNAn]): SSzAxMcIq7i5tbZUvY2OVyfR = dEyT9xhGjolYzLCH7460w3.sub(IpC4qHXRuyNFjzWv(u"ࠧࡢ࡜ࡣࠤဵ") + RqfVSiLWZ7n1p4GJKI6(ZqBwlJjmTE5Oba9XfvNAn, DToJiUqZ8rBGbhfISdxue2kv) + zmcGfOdvAjsELeJlP(u"ࠨ࡜࡝ࡤࠥံ"),  Naex4Y1fFLvocdbuD6C2ZwmpXl0By8[ZqBwlJjmTE5Oba9XfvNAn], SSzAxMcIq7i5tbZUvY2OVyfR)
		return SSzAxMcIq7i5tbZUvY2OVyfR
	EmgOrMcPySkh2oFitb4qvNU7nQGD = EmgOrMcPySkh2oFitb4qvNU7nQGD.split(jXE2YHkswT8y(u"ࠧࡾ့ࠪࠪ"))[YYJQyRskpX8jv]
	EmgOrMcPySkh2oFitb4qvNU7nQGD = EmgOrMcPySkh2oFitb4qvNU7nQGD.rsplit(FRYcH4KL7e9gv5pEB(u"ࠨࡵࡳࡰ࡮ࡺࠧး"))[FGTfwsjNrB8DvKSZhLIQAb1JnO]+TlGXWLYsV1z(u"ࠤࡶࡴࡱ࡯ࡴࠩࠩࡿࠫ࠮࠯္ࠢ")
	vvrRwpWAOoSGThIJQVtCd2ZL = eval(y6y5HtgXO4TkUbwVZ(u"ࠪࡹࡳࡶࡡࡤ࡭်ࠫࠫ")+EmgOrMcPySkh2oFitb4qvNU7nQGD,{GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠫࡧࡧࡳࡦࡐࠪျ"):RqfVSiLWZ7n1p4GJKI6,JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠬࡻ࡮ࡱࡣࡦ࡯ࠬြ"):tp6P01uKQAvl74bqYsVf})
	return vvrRwpWAOoSGThIJQVtCd2ZL
def D5oyMb7NTziWkrqPG(code):
	_H5irvIeDVWjXYdmEGozBbl0kAs=yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠨ࠰࠲࠴࠶࠸࠺࠼࠷࠹࠻ࡤࡦࡨࡪࡥࡧࡩ࡫࡭࡯ࡱ࡬࡮ࡰࡲࡴࡶࡸࡳࡵࡷࡹࡻࡽࡿࡺࡂࡄࡆࡈࡊࡌࡇࡉࡋࡍࡏࡑࡓࡎࡐࡒࡔࡖࡘ࡚ࡕࡗ࡙࡛࡝࡟࠱࠯ࠣွ")
	def PpNOuXFnWKyT4lwSba6s5g(cmtDvXxpZyuI8KW,WdsFGJj2plQtVuok6D,iwhf3cba2RA8SCTxnsHoN):
		BBoGymq7iejkWpOK6hrRgwUMSdH = list(_H5irvIeDVWjXYdmEGozBbl0kAs)
		pq9s6L8C3vDowIBbkcYKnlJ = BBoGymq7iejkWpOK6hrRgwUMSdH[zmcGfOdvAjsELeJlP(u"࠰ᓏ"):WdsFGJj2plQtVuok6D]
		iEfNKT3velFyGth80SA4pxbCRrVD = BBoGymq7iejkWpOK6hrRgwUMSdH[MgP8OjoaiWQEVG59(u"࠱ᓐ"):iwhf3cba2RA8SCTxnsHoN]
		cmtDvXxpZyuI8KW = list(cmtDvXxpZyuI8KW)[::-Y41NvKfOroMzGB8sEHy7wbXlc5(u"࠳ᓑ")]
		J9Cut4yfxIQR2zA1hZnjEH = FRYcH4KL7e9gv5pEB(u"࠳ᓒ")
		for ZqBwlJjmTE5Oba9XfvNAn,g9k3MPLDoW4E8pRTFw in enumerate(cmtDvXxpZyuI8KW):
			if g9k3MPLDoW4E8pRTFw in pq9s6L8C3vDowIBbkcYKnlJ: J9Cut4yfxIQR2zA1hZnjEH = J9Cut4yfxIQR2zA1hZnjEH + pq9s6L8C3vDowIBbkcYKnlJ.index(g9k3MPLDoW4E8pRTFw)*WdsFGJj2plQtVuok6D**ZqBwlJjmTE5Oba9XfvNAn
		Naex4Y1fFLvocdbuD6C2ZwmpXl0By8 = tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠢࠣှ")
		while J9Cut4yfxIQR2zA1hZnjEH > tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"࠴ᓓ"):
			Naex4Y1fFLvocdbuD6C2ZwmpXl0By8 = iEfNKT3velFyGth80SA4pxbCRrVD[J9Cut4yfxIQR2zA1hZnjEH%iwhf3cba2RA8SCTxnsHoN] + Naex4Y1fFLvocdbuD6C2ZwmpXl0By8
			J9Cut4yfxIQR2zA1hZnjEH = (J9Cut4yfxIQR2zA1hZnjEH - (J9Cut4yfxIQR2zA1hZnjEH%iwhf3cba2RA8SCTxnsHoN))//iwhf3cba2RA8SCTxnsHoN
		return int(Naex4Y1fFLvocdbuD6C2ZwmpXl0By8) or uuExaKGL7UONtevRd(u"࠵ᓔ")
	def CWDOpvN1XtU(pq9s6L8C3vDowIBbkcYKnlJ,u,ErNHgXYKc4Tnme9J,Fy4Nsgnz26f,WdsFGJj2plQtVuok6D,Y5YCE2teLPfAUb4HJmlrQasvzOj):
		Y5YCE2teLPfAUb4HJmlrQasvzOj = L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠣࠤဿ");
		iEfNKT3velFyGth80SA4pxbCRrVD = SaB5hx3PZwXRLtKgrTfQvId(u"࠶ᓕ")
		while iEfNKT3velFyGth80SA4pxbCRrVD < len(pq9s6L8C3vDowIBbkcYKnlJ):
			J9Cut4yfxIQR2zA1hZnjEH = JZszNnIEMAx28Yao0yqhiXGKOPb(u"࠰ᓖ")
			IOEo8DNdbSTm0QhZAWv = SaB5hx3PZwXRLtKgrTfQvId(u"ࠤࠥ၀")
			while pq9s6L8C3vDowIBbkcYKnlJ[iEfNKT3velFyGth80SA4pxbCRrVD] is not ErNHgXYKc4Tnme9J[WdsFGJj2plQtVuok6D]:
				IOEo8DNdbSTm0QhZAWv = TlGXWLYsV1z(u"ࠪࠫ၁").join([IOEo8DNdbSTm0QhZAWv,pq9s6L8C3vDowIBbkcYKnlJ[iEfNKT3velFyGth80SA4pxbCRrVD]])
				iEfNKT3velFyGth80SA4pxbCRrVD = iEfNKT3velFyGth80SA4pxbCRrVD + hhQwbeiNLoqFjX90fB7aG8VAs(u"࠲ᓗ")
			while J9Cut4yfxIQR2zA1hZnjEH < len(ErNHgXYKc4Tnme9J):
				IOEo8DNdbSTm0QhZAWv = IOEo8DNdbSTm0QhZAWv.replace(ErNHgXYKc4Tnme9J[J9Cut4yfxIQR2zA1hZnjEH],str(J9Cut4yfxIQR2zA1hZnjEH))
				J9Cut4yfxIQR2zA1hZnjEH = J9Cut4yfxIQR2zA1hZnjEH + SaB5hx3PZwXRLtKgrTfQvId(u"࠳ᓘ")
			Y5YCE2teLPfAUb4HJmlrQasvzOj = AbqCJZdWQP9j(u"ࠫࠬ၂").join([Y5YCE2teLPfAUb4HJmlrQasvzOj,tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠬ࠭၃").join(map(chr, [PpNOuXFnWKyT4lwSba6s5g(IOEo8DNdbSTm0QhZAWv,WdsFGJj2plQtVuok6D,uuExaKGL7UONtevRd(u"࠴࠴ᓙ")) - Fy4Nsgnz26f]))])
			iEfNKT3velFyGth80SA4pxbCRrVD = iEfNKT3velFyGth80SA4pxbCRrVD + uuExaKGL7UONtevRd(u"࠵ᓚ")
		return Y5YCE2teLPfAUb4HJmlrQasvzOj
	code = code.replace(ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"࠭࡜࡯ࠩ၄"),SaB5hx3PZwXRLtKgrTfQvId(u"ࠧࠨ၅")).replace(hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠨ࡞ࡵࠫ၆"),xpT28sXu051(u"ࠩࠪ၇"))
	t8Kxcy1k64r9vPn7LTOWdofle = dEyT9xhGjolYzLCH7460w3.findall(tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠪࡠࢂࡢࠨࠣࠪ࡟ࡻ࠰࠯ࠢ࠭ࠪ࡟ࡨ࠰࠯ࠬࠣࠪ࡟ࡻ࠰࠯ࠢ࠭ࠪ࡟ࡨ࠰࠯ࠬࠩ࡞ࡧ࠯࠮࠲ࠨ࡝ࡦ࠮࠭ࡡ࠯࡜ࠪࠩ၈"),code,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if t8Kxcy1k64r9vPn7LTOWdofle:
		t8Kxcy1k64r9vPn7LTOWdofle = list(t8Kxcy1k64r9vPn7LTOWdofle[L90uqo28xEKSFUwYTcm51yRWZIkft(u"࠵ᓛ")])
		for jZn3saQF6WoSIg0wCrdKViBuOe9A,code in enumerate(t8Kxcy1k64r9vPn7LTOWdofle):
			if code.isdigit(): t8Kxcy1k64r9vPn7LTOWdofle[jZn3saQF6WoSIg0wCrdKViBuOe9A] = int(code)
			else: t8Kxcy1k64r9vPn7LTOWdofle[jZn3saQF6WoSIg0wCrdKViBuOe9A] = code.replace(yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠫࡡࠨࠧ၉"),IpC4qHXRuyNFjzWv(u"ࠬ࠭၊"))
		A2r6eqYcJzNPdHwo7jX = CWDOpvN1XtU(*t8Kxcy1k64r9vPn7LTOWdofle)
		return A2r6eqYcJzNPdHwo7jX
	return y6y5HtgXO4TkUbwVZ(u"࠭ࠧ။")
def A1j8EPUMFV546YbThLokNtcuG2Bv(smglbwR7x2oM,nQMYaEvoeNw9gjkZhfWRdATJXlC=iiy37aKq0pCEIOwfcTh61xb4U):
	if nQMYaEvoeNw9gjkZhfWRdATJXlC==LyNiIHPOwD3hCUYEFM7(u"ࠧ࡭ࡱࡺࡩࡷ࠭၌"): smglbwR7x2oM = dEyT9xhGjolYzLCH7460w3.sub(JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࡳࠩࠨ࡟࠵࠳࠹ࡂ࠯࡝ࡡࢀ࠸ࡽࠨ၍"),lambda WR0pt3qnrsMgdeZxGV: WR0pt3qnrsMgdeZxGV.group(FGTfwsjNrB8DvKSZhLIQAb1JnO).lower(),smglbwR7x2oM)
	elif nQMYaEvoeNw9gjkZhfWRdATJXlC==JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠩࡸࡴࡵ࡫ࡲࠨ၎"): smglbwR7x2oM = dEyT9xhGjolYzLCH7460w3.sub(yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࡵࠫࠪࡡ࠰࠮࠻ࡤ࠱ࡿࡣࡻ࠳ࡿࠪ၏"),lambda WR0pt3qnrsMgdeZxGV: WR0pt3qnrsMgdeZxGV.group(FGTfwsjNrB8DvKSZhLIQAb1JnO).upper(),smglbwR7x2oM)
	return smglbwR7x2oM
def wd9kGFayMlcZgEoufxVU(T0nxf19jK45XgUIchJ8M2zpet):
	xTR5pZygcPn20s4B,g3xZ09E8heVCD5Hfonsi = BF6QAiLUNHh7rKOugaw,BF6QAiLUNHh7rKOugaw
	FZ0zy7Cgeo1UjkR = m5mc0l3DPgnSoI.connect(i4MTUvPC0IdYDtZ1gOWz7oQGy)
	FZ0zy7Cgeo1UjkR.text_factory = str
	AlI5YdVoWgZyP = FZ0zy7Cgeo1UjkR.cursor()
	if len(T0nxf19jK45XgUIchJ8M2zpet)==YYJQyRskpX8jv: ZBIC8Wpw0u = SaB5hx3PZwXRLtKgrTfQvId(u"ࠫ࠭ࠨࠧၐ")+T0nxf19jK45XgUIchJ8M2zpet[FGTfwsjNrB8DvKSZhLIQAb1JnO]+ZchUJdM93pTA7zG5(u"ࠬࠨࠩࠨၑ")
	else: ZBIC8Wpw0u = str(tuple(T0nxf19jK45XgUIchJ8M2zpet))
	AlI5YdVoWgZyP.execute(TlGXWLYsV1z(u"࠭ࡓࡆࡎࡈࡇ࡙ࠦࡡࡥࡦࡲࡲࡎࡊࠬࡦࡰࡤࡦࡱ࡫ࡤࠡࡈࡕࡓࡒࠦࡩ࡯ࡵࡷࡥࡱࡲࡥࡥ࡚ࠢࡌࡊࡘࡅࠡࡣࡧࡨࡴࡴࡉࡅࠢࡌࡒࠥ࠭ၒ")+ZBIC8Wpw0u+CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠧࠡ࠽ࠪၓ"))
	s9Knvz7Ymhy46BErTSpwlUIR = AlI5YdVoWgZyP.fetchall()
	cRKfmdWpl5hGJk9eLNCEob = {}
	for M8hQu61Uid in T0nxf19jK45XgUIchJ8M2zpet: cRKfmdWpl5hGJk9eLNCEob[M8hQu61Uid] = (BF6QAiLUNHh7rKOugaw,BF6QAiLUNHh7rKOugaw)
	for M8hQu61Uid,g3xZ09E8heVCD5Hfonsi in s9Knvz7Ymhy46BErTSpwlUIR:
		xTR5pZygcPn20s4B = rGPen6cSMHQkAywh8vqI9JXiD2
		g3xZ09E8heVCD5Hfonsi = g3xZ09E8heVCD5Hfonsi==YYJQyRskpX8jv
		cRKfmdWpl5hGJk9eLNCEob[M8hQu61Uid] = (xTR5pZygcPn20s4B,g3xZ09E8heVCD5Hfonsi)
	FZ0zy7Cgeo1UjkR.close()
	return cRKfmdWpl5hGJk9eLNCEob
def vvqB64XWVrb1kKJmC0xyNHiF7fOL(BdluXk6trpsO2bF841jZLgH7nG9c):
	EA7FzO1kMZGQXDd2giB0cwLom = iiy37aKq0pCEIOwfcTh61xb4U
	if wkMR5x1gTWEQIc6qHCa.path.exists(BdluXk6trpsO2bF841jZLgH7nG9c):
		dQ960sl5X13MFwW24jEtCBR = open(BdluXk6trpsO2bF841jZLgH7nG9c,AbqCJZdWQP9j(u"ࠨࡴࡥࠫၔ")).read()
		if J1MoiYc7ZwzKS: dQ960sl5X13MFwW24jEtCBR = dQ960sl5X13MFwW24jEtCBR.decode(df6QpwGxuJVZr)
		xS62wlohkFG5nZT4DrYJ1XqK7EPiO = DeIL3qoa2UBtYPb(GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠩࡧ࡭ࡨࡺࠧၕ"),dQ960sl5X13MFwW24jEtCBR)
		if xS62wlohkFG5nZT4DrYJ1XqK7EPiO:
			EA7FzO1kMZGQXDd2giB0cwLom = {}
			for Onuh30WYrigx in xS62wlohkFG5nZT4DrYJ1XqK7EPiO.keys():
				EA7FzO1kMZGQXDd2giB0cwLom[Onuh30WYrigx] = []
				for zxQ1mt5odH0MUFRAYSTNJ8Z in xS62wlohkFG5nZT4DrYJ1XqK7EPiO[Onuh30WYrigx]:
					EGJVsZy38Xx,Toe5N9znWjQHmP4whguld,smglbwR7x2oM,y3qATZDQOch6db5WjnmrguflU,L95mrowGgdsD,zLEP9N4BOsVrXa,XiWJ2PTqvds4pBNebVrt98x,EALyNnv1Db4cUd8sQoZX2pmBVt7kM,XC10geOnQtwrs = iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U
					EGJVsZy38Xx = zxQ1mt5odH0MUFRAYSTNJ8Z[FGTfwsjNrB8DvKSZhLIQAb1JnO]
					Toe5N9znWjQHmP4whguld = zxQ1mt5odH0MUFRAYSTNJ8Z[YYJQyRskpX8jv]
					Toe5N9znWjQHmP4whguld = UrB3iTzS1sFnX(Toe5N9znWjQHmP4whguld)
					smglbwR7x2oM = zxQ1mt5odH0MUFRAYSTNJ8Z[nI2JK1RfsGWNY3OarEeMQZ]
					y3qATZDQOch6db5WjnmrguflU = zxQ1mt5odH0MUFRAYSTNJ8Z[iiCWLaJREureAlOkv]
					L95mrowGgdsD = zxQ1mt5odH0MUFRAYSTNJ8Z[pZWli1xqfVtvzuSU6ImNw53gBFsh]
					zLEP9N4BOsVrXa = zxQ1mt5odH0MUFRAYSTNJ8Z[yJeq1BjfiO4NFuwIEzxVLK6b9s(u"࠻ᓜ")]
					if len(zxQ1mt5odH0MUFRAYSTNJ8Z)>tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"࠶ᓝ"): XiWJ2PTqvds4pBNebVrt98x = zxQ1mt5odH0MUFRAYSTNJ8Z[tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"࠶ᓝ")]
					if len(zxQ1mt5odH0MUFRAYSTNJ8Z)>LyNiIHPOwD3hCUYEFM7(u"࠸ᓞ"): EALyNnv1Db4cUd8sQoZX2pmBVt7kM = zxQ1mt5odH0MUFRAYSTNJ8Z[LyNiIHPOwD3hCUYEFM7(u"࠸ᓞ")]
					if len(zxQ1mt5odH0MUFRAYSTNJ8Z)>L90uqo28xEKSFUwYTcm51yRWZIkft(u"࠺ᓟ"): XC10geOnQtwrs = zxQ1mt5odH0MUFRAYSTNJ8Z[L90uqo28xEKSFUwYTcm51yRWZIkft(u"࠺ᓟ")]
					if BdluXk6trpsO2bF841jZLgH7nG9c==v05aOkM7NXBHuT3UpAdiPq4: UUNtGepmfJ6nd7A1rLPcBbE = EGJVsZy38Xx,Toe5N9znWjQHmP4whguld,smglbwR7x2oM,y3qATZDQOch6db5WjnmrguflU,L95mrowGgdsD,zLEP9N4BOsVrXa,XiWJ2PTqvds4pBNebVrt98x,iiy37aKq0pCEIOwfcTh61xb4U,XC10geOnQtwrs
					else: UUNtGepmfJ6nd7A1rLPcBbE = EGJVsZy38Xx,Toe5N9znWjQHmP4whguld,smglbwR7x2oM,y3qATZDQOch6db5WjnmrguflU,L95mrowGgdsD,zLEP9N4BOsVrXa,XiWJ2PTqvds4pBNebVrt98x,EALyNnv1Db4cUd8sQoZX2pmBVt7kM,XC10geOnQtwrs
					EA7FzO1kMZGQXDd2giB0cwLom[Onuh30WYrigx].append(UUNtGepmfJ6nd7A1rLPcBbE)
		kvysZqlKXSPC = str(EA7FzO1kMZGQXDd2giB0cwLom)
		if J1MoiYc7ZwzKS: kvysZqlKXSPC = kvysZqlKXSPC.encode(df6QpwGxuJVZr)
		open(BdluXk6trpsO2bF841jZLgH7nG9c,tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠪࡻࡧ࠭ၖ")).write(kvysZqlKXSPC)
	return EA7FzO1kMZGQXDd2giB0cwLom
def GGkFKuWvn5q1wVmldgXz(ekEOd3mqAThaBDUoIrntuGRjYW):
	p5tuac8hGPKI6MO37v9EoRFXi = ekEOd3mqAThaBDUoIrntuGRjYW.split(FRYcH4KL7e9gv5pEB(u"ࠫ࠲࠭ၗ"),YYJQyRskpX8jv)[FGTfwsjNrB8DvKSZhLIQAb1JnO]
	ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,lEgmdMxnfsXj,ZebIE2aQgrGn = iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U
	if   p5tuac8hGPKI6MO37v9EoRFXi==YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠬࡇࡈࡘࡃࡎࠫၘ")		:	from xkPupjMbOt			import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==EMO8gy4LrsNTh0knZwpSeU75APW(u"࠭ࡁࡌࡑࡄࡑࠬၙ")		:	from vr5aHp1ofi			import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==xpT28sXu051(u"ࠧࡂࡍࡒࡅࡒࡉࡁࡎࠩၚ")	:	from dS3lHm09G4		import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠨࡃࡎ࡛ࡆࡓࠧၛ")		:	from oIeuaPmibU			import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==TlGXWLYsV1z(u"ࠩࡄࡏ࡜ࡇࡍࡕࡗࡅࡉࠬၜ")	:	from LXHsjirCZ6		import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==y6y5HtgXO4TkUbwVZ(u"ࠪࡅࡑࡇࡒࡂࡄࠪၝ")	:	from Ibg5KoZMAz			import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠫࡆࡒࡆࡂࡖࡌࡑࡎ࠭ၞ")	:	from glAOIw1BXa		import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==MgP8OjoaiWQEVG59(u"ࠬࡇࡌࡌࡃ࡚ࡘࡍࡇࡒࠨၟ")	: 	from AIu94zF6tx		import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==FRYcH4KL7e9gv5pEB(u"࠭ࡁࡍࡏࡄࡅࡗࡋࡆࠨၠ")	:	from xfhMZiYNPV		import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==jXE2YHkswT8y(u"ࠧࡂࡎࡐࡗ࡙ࡈࡁࠨၡ")	:	from P9jEqIH3sC		import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==FRYcH4KL7e9gv5pEB(u"ࠨࡃࡑࡍࡒࡋ࡚ࡊࡆࠪၢ")	:	from ssRAGfmY8E		import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠩࡄࡖࡆࡈࡉࡄࡖࡒࡓࡓ࡙ࠧၣ"):	from wXO1vzDjd6	import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==PtkEvXAqif14G20QZsaSyT(u"ࠪࡅࡗࡇࡂࡔࡇࡈࡈࠬၤ")	:	from sRIEkLr634		import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠫࡆ࡟ࡌࡐࡎࠪၥ")		:	from ZdY3Dn5pLk			import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠬࡈࡏࡌࡔࡄࠫၦ")		:	from sZEufTSeXb			import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==y6y5HtgXO4TkUbwVZ(u"࠭ࡂࡓࡕࡗࡉࡏ࠭ၧ")	:	from c9SbFCj6mZ			import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==vODxLKW5Ql6r4Fbm8(u"ࠧࡄࡋࡐࡅ࠹࠶࠰ࠨၨ")	:	from GG36Ij5SxU		import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠨࡅࡌࡑࡆ࠺ࡐࠨၩ")	:	from PPb6MJwGTd			import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==sVzojQerUqX(u"ࠩࡆࡍࡒࡇ࠴ࡖࠩၪ")	:	from WYuiCFZ3mU			import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠪࡇࡎࡓࡁࡂࡄࡇࡓࠬၫ")	:	from MlFkyhP502		import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==jXE2YHkswT8y(u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࠭ၬ")	:	from Iwj5CaLmYO		import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡈࡗࡐࡔࡎࠫၭ"):	from IWJrAmlTkb	import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==L90uqo28xEKSFUwYTcm51yRWZIkft(u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡐࠨၮ")	:	from G3hQr8jp5d		import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠧࡄࡋࡐࡅࡋࡇࡎࡔࠩၯ")	:	from MMEJAz3Onk		import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠨࡅࡌࡑࡆࡌࡒࡆࡇࠪၰ")	:	from UUycmu7XjD		import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==sVzojQerUqX(u"ࠩࡆࡍࡒࡇࡌࡊࡉࡋࡘࠬၱ")	:	from BDYeH90xTR		import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==HtK4o2sTPgA78U(u"ࠪࡇࡎࡓࡁࡏࡑ࡚ࠫၲ")	:	from nnFQHctSEG		import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠫࡈࡏࡍࡂ࡙ࡅࡅࡘ࠭ၳ")	:	from bQKFlmfaCt		import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==jXE2YHkswT8y(u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐࠪၴ"):	from LATecKt1Ra	import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"࠭ࡄࡓࡃࡐࡅࡈࡇࡆࡆࠩၵ")	:	from z1zYM6yWUf		import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==uuExaKGL7UONtevRd(u"ࠧࡅࡔࡄࡑࡆ࡙࠷ࠨၶ")	:	from ZYNsy6CK4u		import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕࠩၷ")	:	from aY5JxSDGNE		import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==HtK4o2sTPgA78U(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠴ࠫၸ")	:	from gpJT7OU15G		import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==XrTw01KtLzbpoyMf(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠶ࠬၹ")	:	from ibaL4O16jq		import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==LyNiIHPOwD3hCUYEFM7(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠸࠭ၺ")	:	from eScC4ZYT7g		import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==PtkEvXAqif14G20QZsaSyT(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠺ࠧၻ")	:	from PrqXjGnsUS		import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==FRYcH4KL7e9gv5pEB(u"࠭ࡅࡈ࡛ࡇࡉࡆࡊࠧၼ")	:	from nBh0GXEfrJ		import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==LyNiIHPOwD3hCUYEFM7(u"ࠧࡆࡉ࡜ࡒࡔ࡝ࠧၽ")	:	from pfObhokENe			import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠨࡇࡏࡇࡎࡔࡅࡎࡃࠪၾ")	:	from QQYEGou3rO		import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠩࡈࡐࡎࡌࡖࡊࡆࡈࡓࠬၿ")	:	from p4p1fGStCP		import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠪࡊࡆࡈࡒࡂࡍࡄࠫႀ")	:	from vjJHClWtZz		import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠫࡋࡇࡊࡆࡔࡖࡌࡔ࡝ࠧႁ")	:	from j9jVLNUiMD		import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠬࡌࡁࡓࡇࡖࡏࡔ࠭ႂ")	:	from xXsrnOe40o		import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==AbqCJZdWQP9j(u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠱ࠨႃ")	:	from i1tWTclz6O		import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠧࡇࡃࡖࡉࡑࡎࡄ࠳ࠩႄ")	:	from gcNIbG3lhe		import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==IpC4qHXRuyNFjzWv(u"ࠨࡈࡒࡗ࡙ࡇࠧႅ")		:	from i6FvBKHolR			import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==LyNiIHPOwD3hCUYEFM7(u"ࠩࡉ࡙ࡓࡕࡎࡕࡘࠪႆ")	:	from xGr1HzD4fV		import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==FRYcH4KL7e9gv5pEB(u"ࠪࡊ࡚࡙ࡈࡂࡔࡗ࡚ࠬႇ")	:	from paQ0bIuUzL		import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==y6y5HtgXO4TkUbwVZ(u"ࠫࡋ࡛ࡓࡉࡃࡕ࡚ࡎࡊࡅࡐࠩႈ"):	from t1y7wWPiYU	import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==SaB5hx3PZwXRLtKgrTfQvId(u"ࠬࡍࡏࡐࡉࡏࡉࡘࡋࡁࡓࡅࡋࠫႉ"):	from BBV2zlryTP	import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==XrTw01KtLzbpoyMf(u"࠭ࡈࡂࡎࡄࡇࡎࡓࡁࠨႊ")	:	from B0BLI6vrM7		import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==zmcGfOdvAjsELeJlP(u"ࠧࡊࡈࡌࡐࡒ࠭ႋ")		:	from e8Al5YLw6y			import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠨࡋࡓࡘ࡛࠭ႌ")		:	from uUbDljY0SN			import JJUoTEDm2h3eQijgavIZHd1GL as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,g5h4NU9EkHwnQqrAamMi7JOZDeX as lEgmdMxnfsXj,gp5OsEbPCX0MGZw1tTf63zcySKLH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠩࡎࡅࡗࡈࡁࡍࡃࡗ࡚ႍࠬ")	:	from FiWJ1oQ39C		import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠪࡏࡆ࡚ࡋࡐࡖࡗ࡚ࠬႎ")	:	from Q5ZGqRs2PD		import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==vODxLKW5Ql6r4Fbm8(u"ࠫࡐࡇࡔࡌࡑࡘࡘࡊ࠭ႏ")	:	from ttolzyQDF7		import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==xpT28sXu051(u"ࠬࡑࡉࡓࡏࡄࡐࡐ࠭႐")	:	from ZDOsRb7T8t		import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"࠭ࡌࡂࡔࡒ࡞ࡆ࠭႑")	:	from WWA4uXG7hb			import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠧࡍࡑࡇ࡝ࡓࡋࡔࠨ႒")	:	from lmcNbDZW4x		import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠨࡏ࠶࡙ࠬ႓")		:	from FwKQq7S2Ce			import JJUoTEDm2h3eQijgavIZHd1GL as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,g5h4NU9EkHwnQqrAamMi7JOZDeX as lEgmdMxnfsXj,gp5OsEbPCX0MGZw1tTf63zcySKLH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠩࡐࡅࡘࡇࡖࡊࡆࡈࡓࠬ႔")	:	from ZEJASPVH72		import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==uuExaKGL7UONtevRd(u"ࠪࡑࡔ࡜ࡓ࠵ࡗࠪ႕")	:	from Qh3dFi9vNj			import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠫࡒ࡟ࡃࡊࡏࡄࠫ႖")	:	from kiFol7tQ5Y			import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠬࡖࡁࡏࡇࡗࠫ႗")		:	from MMz7bIHjBQ			import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==vODxLKW5Ql6r4Fbm8(u"࠭ࡑࡇࡋࡏࡑࠬ႘")		:	from PB1lXgx3tI			import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠧࡔࡇࡕࡍࡊ࡙ࡔࡊࡏࡈࠫ႙"):	from E2QSq0Vila		import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠨࡕࡋࡅࡇࡇࡋࡂࡖ࡜ࠫႚ")	:	from P7siNyYAtg		import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==zmcGfOdvAjsELeJlP(u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘࠫႛ")	:	from vvcSWtyJxw		import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠪࡗࡍࡇࡈࡊࡆࡑࡉ࡜࡙ࠧႜ"):	from lBf6NGa9QS		import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==PtkEvXAqif14G20QZsaSyT(u"ࠫࡘࡎࡉࡂࡘࡒࡍࡈࡋࠧႝ")	:	from nnOsIgCyuK		import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==jXE2YHkswT8y(u"࡙ࠬࡈࡐࡈࡋࡅࠬ႞")	:	from CJPfXMgbsv			import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"࠭ࡓࡉࡑࡒࡊࡒࡇࡘࠨ႟")	:	from BHSfLIuQ1j		import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠧࡔࡊࡒࡓࡋࡔࡅࡕࠩႠ")	:	from YgcvUa8k0q		import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==MgP8OjoaiWQEVG59(u"ࠨࡕࡋࡓࡔࡌࡐࡓࡑࠪႡ")	:	from NeR5gq8kfL		import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠩࡗࡍࡐࡇࡁࡕࠩႢ")	:	from gyVpCIimfU			import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==LyNiIHPOwD3hCUYEFM7(u"ࠪࡘ࡛ࡌࡕࡏࠩႣ")		:	from V18kA4epvm			import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==JZszNnIEMAx28Yao0yqhiXGKOPb(u"࡛ࠫࡇࡒࡃࡑࡑࠫႤ")	:	from z0WKEVAsdr			import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠬ࡜ࡉࡅࡇࡒࡒࡘࡇࡅࡎࠩႥ"):	from fflA4BGKvW		import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==MgP8OjoaiWQEVG59(u"࠭ࡗࡆࡅࡌࡑࡆ࠷ࠧႦ")	:	from ZwBdxCKtac		import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠧࡘࡇࡆࡍࡒࡇ࠲ࠨႧ")	:	from Yb3dMo1ZF5		import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠨ࡛ࡄࡕࡔ࡚ࠧႨ")		:	from d1HyMeiw3x			import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪႩ")	:	from QGlgpcTFhx		import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	elif p5tuac8hGPKI6MO37v9EoRFXi==vODxLKW5Ql6r4Fbm8(u"ࠪ࡝࡙ࡈ࡟ࡄࡊࡄࡒࡓࡋࡌࡔࠩႪ"):	from etmINUEDQr	import jihuS9LVAvTrClPapMbUEwfn8XN as ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,mUhJtHB9nw as lEgmdMxnfsXj,ooQEi5O6tYsGVF8LU0TC3hgMeflBwH as ZebIE2aQgrGn
	return ED1rSYJ2MVO3hZLFtH5gW9A6iCxuI,lEgmdMxnfsXj,ZebIE2aQgrGn
def HHECmRlDkqTty05rGveI7hc436XA(PPlg6LFy3CTc,CZGXVf91e3KTpSDqyP6x8otlhLBam2,showDialogs):
	WKquk5EaNr4RzVf(q1rohYuwnfpVZUa98L2CtQzmAcB,PtkEvXAqif14G20QZsaSyT(u"ࠫ࠳ࡢࡴࡅࡱࡺࡲࡱࡵࡡࡥ࡫ࡱ࡫࠿࡛ࠦࠡࠩႫ")+PPlg6LFy3CTc+sVzojQerUqX(u"ࠬࠦ࡝ࠡࠢࠣࡌࡪࡧࡤࡦࡴࡶ࠾ࠥࡡࠠࠨႬ")+str(CZGXVf91e3KTpSDqyP6x8otlhLBam2)+PtkEvXAqif14G20QZsaSyT(u"࠭ࠠ࡞ࠩႭ"))
	sspk8CPTnaqeyzALQuD6ExX = BH5w8KScjpRhAkI7PlqDU()
	sspk8CPTnaqeyzALQuD6ExX.create(ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪႮ"),GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠨ์ฯี๏ࠦวๅฤ้ࠤๆำีࠡษ็้้็ࠠศๆ่฻้๎ศࠡฬะ้๏๊็๊ࠡห฽ิํวࠡี๋ๅࠥะศะลࠣ฽๊๊๊สࠢฯ่อࠦวๅ็็ๅ๋ࠥๆࠡษ็ษ๋ะั็ฬࠪႯ"))
	NQfBRbkJp193wuqET0A2 = XrTw01KtLzbpoyMf(u"࠴࠴࠷࠺ᓠ")*XrTw01KtLzbpoyMf(u"࠴࠴࠷࠺ᓠ")
	baWvVJBhSye6g7X540jA9URQpoNF = PtkEvXAqif14G20QZsaSyT(u"࠵ᓡ")*NQfBRbkJp193wuqET0A2
	import requests as Z4rotfjRx7A8U9Jgy0IaL1KnbTuB5
	VVznOTKE7NDIe0HGkg = Z4rotfjRx7A8U9Jgy0IaL1KnbTuB5.get(PPlg6LFy3CTc,stream=rGPen6cSMHQkAywh8vqI9JXiD2,headers=CZGXVf91e3KTpSDqyP6x8otlhLBam2)
	aLFxpAjb8PVZDIHESTnhsvyXOtY7f = VVznOTKE7NDIe0HGkg.headers
	VVznOTKE7NDIe0HGkg.close()
	HCipGJ1cv89rgTjUFNt7Bh0XmqlA = bytes()
	if not aLFxpAjb8PVZDIHESTnhsvyXOtY7f:
		if showDialogs: bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬႰ"),vODxLKW5Ql6r4Fbm8(u"ࠪห้ฮั็ษ่ะ๊ࠥๅࠡ์อ้่์ࠠๆ่ࠣฮา๋๊ๅࠢส่๊๊แࠡษ็้฼๊่ษ๋ࠢหู้ศษࠢๅำࠥ๐ใ้่ࠣ฽๋ีใࠡ็ื็้ฯࠠโ์ࠣห้หๆหำ้ฮࠥอไฯษุࠤอ้ࠠ࠯ࠢฯีอࠦสฮ็ํ่ࠥอไๆๆไࠤ๊ืษࠡลัี๎࠭Ⴑ"))
		sspk8CPTnaqeyzALQuD6ExX.close()
	else:
		if PtkEvXAqif14G20QZsaSyT(u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲ࡒࡥ࡯ࡩࡷ࡬ࠬႲ") not in list(aLFxpAjb8PVZDIHESTnhsvyXOtY7f.keys()): loycO3NJfAZkdTFh8eg = FGTfwsjNrB8DvKSZhLIQAb1JnO
		else: loycO3NJfAZkdTFh8eg = int(aLFxpAjb8PVZDIHESTnhsvyXOtY7f[HtK4o2sTPgA78U(u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡌࡦࡰࡪࡸ࡭࠭Ⴓ")])
		g9knySsRtf6IXmjaVvUrE8i = str(int(CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"࠷࠰࠱࠲ᓣ")*loycO3NJfAZkdTFh8eg/NQfBRbkJp193wuqET0A2)/PtkEvXAqif14G20QZsaSyT(u"࠶࠶࠰࠱࠰࠳ᓢ"))
		m4rYSE1fQO = int(loycO3NJfAZkdTFh8eg/baWvVJBhSye6g7X540jA9URQpoNF)+YYJQyRskpX8jv
		if y6y5HtgXO4TkUbwVZ(u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡓࡣࡱ࡫ࡪ࠭Ⴔ") in list(aLFxpAjb8PVZDIHESTnhsvyXOtY7f.keys()) and loycO3NJfAZkdTFh8eg>NQfBRbkJp193wuqET0A2:
			U27OgbYw3J9hH = rGPen6cSMHQkAywh8vqI9JXiD2
			XXBazOjST1Csl0mZ5QM = []
			yV2W83ipeaDIwus5j = YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"࠱࠱ᓤ")
			XXBazOjST1Csl0mZ5QM.append(str(FGTfwsjNrB8DvKSZhLIQAb1JnO*loycO3NJfAZkdTFh8eg//yV2W83ipeaDIwus5j)+tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠧ࠮ࠩႵ")+str(YYJQyRskpX8jv*loycO3NJfAZkdTFh8eg//yV2W83ipeaDIwus5j-YYJQyRskpX8jv))
			XXBazOjST1Csl0mZ5QM.append(str(YYJQyRskpX8jv*loycO3NJfAZkdTFh8eg//yV2W83ipeaDIwus5j)+yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠨ࠯ࠪႶ")+str(nI2JK1RfsGWNY3OarEeMQZ*loycO3NJfAZkdTFh8eg//yV2W83ipeaDIwus5j-YYJQyRskpX8jv))
			XXBazOjST1Csl0mZ5QM.append(str(nI2JK1RfsGWNY3OarEeMQZ*loycO3NJfAZkdTFh8eg//yV2W83ipeaDIwus5j)+y6y5HtgXO4TkUbwVZ(u"ࠩ࠰ࠫႷ")+str(iiCWLaJREureAlOkv*loycO3NJfAZkdTFh8eg//yV2W83ipeaDIwus5j-YYJQyRskpX8jv))
			XXBazOjST1Csl0mZ5QM.append(str(iiCWLaJREureAlOkv*loycO3NJfAZkdTFh8eg//yV2W83ipeaDIwus5j)+ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠪ࠱ࠬႸ")+str(pZWli1xqfVtvzuSU6ImNw53gBFsh*loycO3NJfAZkdTFh8eg//yV2W83ipeaDIwus5j-YYJQyRskpX8jv))
			XXBazOjST1Csl0mZ5QM.append(str(pZWli1xqfVtvzuSU6ImNw53gBFsh*loycO3NJfAZkdTFh8eg//yV2W83ipeaDIwus5j)+EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠫ࠲࠭Ⴙ")+str(IpC4qHXRuyNFjzWv(u"࠶ᓥ")*loycO3NJfAZkdTFh8eg//yV2W83ipeaDIwus5j-YYJQyRskpX8jv))
			XXBazOjST1Csl0mZ5QM.append(str(LyNiIHPOwD3hCUYEFM7(u"࠷ᓦ")*loycO3NJfAZkdTFh8eg//yV2W83ipeaDIwus5j)+AbqCJZdWQP9j(u"ࠬ࠳ࠧႺ")+str(GGx4qyKP1vUtRghsE2WfaHLMXZ(u"࠹ᓧ")*loycO3NJfAZkdTFh8eg//yV2W83ipeaDIwus5j-YYJQyRskpX8jv))
			XXBazOjST1Csl0mZ5QM.append(str(vODxLKW5Ql6r4Fbm8(u"࠻ᓩ")*loycO3NJfAZkdTFh8eg//yV2W83ipeaDIwus5j)+yJeq1BjfiO4NFuwIEzxVLK6b9s(u"࠭࠭ࠨႻ")+str(xpT28sXu051(u"࠻ᓨ")*loycO3NJfAZkdTFh8eg//yV2W83ipeaDIwus5j-YYJQyRskpX8jv))
			XXBazOjST1Csl0mZ5QM.append(str(vODxLKW5Ql6r4Fbm8(u"࠷ᓫ")*loycO3NJfAZkdTFh8eg//yV2W83ipeaDIwus5j)+uuExaKGL7UONtevRd(u"ࠧ࠮ࠩႼ")+str(vODxLKW5Ql6r4Fbm8(u"࠾ᓪ")*loycO3NJfAZkdTFh8eg//yV2W83ipeaDIwus5j-YYJQyRskpX8jv))
			XXBazOjST1Csl0mZ5QM.append(str(hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"࠺ᓭ")*loycO3NJfAZkdTFh8eg//yV2W83ipeaDIwus5j)+YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠨ࠯ࠪႽ")+str(IpC4qHXRuyNFjzWv(u"࠺ᓬ")*loycO3NJfAZkdTFh8eg//yV2W83ipeaDIwus5j-YYJQyRskpX8jv))
			XXBazOjST1Csl0mZ5QM.append(str(xpT28sXu051(u"࠼ᓮ")*loycO3NJfAZkdTFh8eg//yV2W83ipeaDIwus5j)+ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠩ࠰ࠫႾ"))
			yl90vjNQLnHo = float(m4rYSE1fQO)/yV2W83ipeaDIwus5j
			kkOrMevb1tUgWfQS8 = yl90vjNQLnHo/int(YYJQyRskpX8jv+yl90vjNQLnHo)
		else:
			U27OgbYw3J9hH = BF6QAiLUNHh7rKOugaw
			yV2W83ipeaDIwus5j = YYJQyRskpX8jv
			kkOrMevb1tUgWfQS8 = YYJQyRskpX8jv
		WKquk5EaNr4RzVf(q1rohYuwnfpVZUa98L2CtQzmAcB,zmcGfOdvAjsELeJlP(u"ࠪ࠲ࡡࡺࡄࡰࡹࡱࡰࡴࡧࡤࠡࡷࡶ࡭ࡳ࡭ࠠࡳࡣࡱ࡫ࡪࡹ࠺ࠡ࡝ࠣࠫႿ")+str(U27OgbYw3J9hH)+tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠫࠥࡣࠠࠡࠢࡇࡳࡼࡴ࡬ࡰࡣࡧࠤࡸ࡯ࡺࡦ࠼ࠣ࡟ࠥ࠭Ⴠ")+str(loycO3NJfAZkdTFh8eg)+tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠬࠦ࡝ࠨჁ"))
		o6oXFxmE1bQC,DSyCklR0ug6Y = FGTfwsjNrB8DvKSZhLIQAb1JnO,FGTfwsjNrB8DvKSZhLIQAb1JnO
		for O1tzxUQDMC7fVdjb8BRck in range(yV2W83ipeaDIwus5j):
			rzR9SN7ApZuQhTDWEX3V6ga = CZGXVf91e3KTpSDqyP6x8otlhLBam2.copy()
			if U27OgbYw3J9hH: rzR9SN7ApZuQhTDWEX3V6ga[L90uqo28xEKSFUwYTcm51yRWZIkft(u"࠭ࡒࡢࡰࡪࡩࠬჂ")] = sVzojQerUqX(u"ࠧࡣࡻࡷࡩࡸࡃࠧჃ")+XXBazOjST1Csl0mZ5QM[O1tzxUQDMC7fVdjb8BRck]
			VVznOTKE7NDIe0HGkg = Z4rotfjRx7A8U9Jgy0IaL1KnbTuB5.get(PPlg6LFy3CTc,stream=rGPen6cSMHQkAywh8vqI9JXiD2,headers=rzR9SN7ApZuQhTDWEX3V6ga,timeout=GGx4qyKP1vUtRghsE2WfaHLMXZ(u"࠷࠵࠶ᓯ"))
			for kcPEupqNFbLaiDhwn3e2rZ4g6xv in VVznOTKE7NDIe0HGkg.iter_content(chunk_size=baWvVJBhSye6g7X540jA9URQpoNF):
				if sspk8CPTnaqeyzALQuD6ExX.iscanceled():
					WKquk5EaNr4RzVf(q1rohYuwnfpVZUa98L2CtQzmAcB,ZchUJdM93pTA7zG5(u"ࠨ࠰࡟ࡸࡉࡵࡷ࡯࡮ࡲࡥࡩࠦࡃࡢࡰࡦࡩࡱ࡫ࡤࠨჄ"))
					break
				o6oXFxmE1bQC += kkOrMevb1tUgWfQS8
				HCipGJ1cv89rgTjUFNt7Bh0XmqlA += kcPEupqNFbLaiDhwn3e2rZ4g6xv
				if not DSyCklR0ug6Y: DSyCklR0ug6Y = len(kcPEupqNFbLaiDhwn3e2rZ4g6xv)
				if loycO3NJfAZkdTFh8eg: o8oBqwQFbU2uL3SEGD0lgWO4xRnJYC(sspk8CPTnaqeyzALQuD6ExX,uuExaKGL7UONtevRd(u"࠶࠶࠰ᓰ")*o6oXFxmE1bQC//m4rYSE1fQO,L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠩฯ่อࠦวๅ็็ๅ࠿࠳ࠠศๆฯึฦࠦัใ็ࠪჅ"),str(L90uqo28xEKSFUwYTcm51yRWZIkft(u"࠷࠰࠱࠰࠳ᓱ")*DSyCklR0ug6Y*o6oXFxmE1bQC//baWvVJBhSye6g7X540jA9URQpoNF//L90uqo28xEKSFUwYTcm51yRWZIkft(u"࠷࠰࠱࠰࠳ᓱ"))+SaB5hx3PZwXRLtKgrTfQvId(u"ࠪࠤ࠴ࠦࠧ჆")+g9knySsRtf6IXmjaVvUrE8i+HtK4o2sTPgA78U(u"ࠫࠥࡓࡂࠨჇ"))
				else: o8oBqwQFbU2uL3SEGD0lgWO4xRnJYC(sspk8CPTnaqeyzALQuD6ExX,DSyCklR0ug6Y*o6oXFxmE1bQC//baWvVJBhSye6g7X540jA9URQpoNF,xpT28sXu051(u"ࠬาไษࠢส่๊๊แ࠻࠯ࠪ჈"),str(ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"࠱࠱࠲࠱࠴ᓲ")*DSyCklR0ug6Y*o6oXFxmE1bQC//baWvVJBhSye6g7X540jA9URQpoNF//ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"࠱࠱࠲࠱࠴ᓲ"))+ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"࠭ࠠࡎࡄࠪ჉"))
			VVznOTKE7NDIe0HGkg.close()
		sspk8CPTnaqeyzALQuD6ExX.close()
		if len(HCipGJ1cv89rgTjUFNt7Bh0XmqlA)<loycO3NJfAZkdTFh8eg and loycO3NJfAZkdTFh8eg>FGTfwsjNrB8DvKSZhLIQAb1JnO:
			WKquk5EaNr4RzVf(q1rohYuwnfpVZUa98L2CtQzmAcB,EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠧ࠯࡞ࡷࡈࡴࡽ࡮࡭ࡱࡤࡨࠥ࡬ࡡࡪ࡮ࡨࡨࠥࡵࡲࠡࡥࡤࡲࡨ࡫࡬ࡦࡦࠣࡥࡹࡀࠠ࡜ࠢࠪ჊")+str(len(HCipGJ1cv89rgTjUFNt7Bh0XmqlA)//NQfBRbkJp193wuqET0A2)+tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠨࠢࡐࡆࠥࡣࠠࠡࠢࡉࡶࡴࡳࠠࡵࡱࡷࡥࡱࠦ࡯ࡧ࠼ࠣ࡟ࠥ࠭჋")+g9knySsRtf6IXmjaVvUrE8i+zmcGfOdvAjsELeJlP(u"ࠩࠣࡑࡇࠦ࡝ࠨ჌"))
			kCWluLqaQTjbyoOZt0 = Ny92sqomMkizpgKV1(iiy37aKq0pCEIOwfcTh61xb4U,JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠪษ้เวย๋ࠢาึ๎ฬࠨჍ"),PtkEvXAqif14G20QZsaSyT(u"ࠫฬูสฯัส้ࠥอไๆๆไࠤฬ๊ๆศไุࠫ჎"),CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠬหูศัฬࠤั๊ศࠡษ็้้็ࠧ჏"),hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩა"),PtkEvXAqif14G20QZsaSyT(u"ࠧโึ็ࠤๆ๐ࠠอๆหࠤฬ๊ๅๅใࠣࡠࡳࠦไๅลึๅࠥำฯฬࠢั฻ศࠦแ๋ࠢอั๊๐ไࠡษ็้้็ࠠ࡝ࡰࠣฮ๊ࠦฬๅสࠣࠫბ")+str(len(HCipGJ1cv89rgTjUFNt7Bh0XmqlA)//NQfBRbkJp193wuqET0A2)+hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠨ่ࠢ๎฿อศศ์อࠤ๊์ࠠๆฮ่์฾ࠦࠧგ")+g9knySsRtf6IXmjaVvUrE8i+XrTw01KtLzbpoyMf(u"้ࠩࠣ๏เวษษํฮࠥࡢ࡮ࠡฮิฬࠥาไษࠢส่๊๊แࠡ็ิอࠥษฮา๋ࠣࡠࡳࠦ็ๅࠢอี๏ีࠠศีอาิอๅࠡษ็้้็ࠠศๆ้ห็฻ࠠภࠣࠤࠫდ"))
			if kCWluLqaQTjbyoOZt0==nI2JK1RfsGWNY3OarEeMQZ: HCipGJ1cv89rgTjUFNt7Bh0XmqlA = HHECmRlDkqTty05rGveI7hc436XA(PPlg6LFy3CTc,CZGXVf91e3KTpSDqyP6x8otlhLBam2,showDialogs)
			elif kCWluLqaQTjbyoOZt0==YYJQyRskpX8jv: WKquk5EaNr4RzVf(q1rohYuwnfpVZUa98L2CtQzmAcB,hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠪ࠲ࡡࡺࡎࡰࡶࠣࡧࡴࡳࡰ࡭ࡧࡷࡩࡩࠦࡤࡰࡹࡱࡰࡴࡧࡤࡦࡦࠣࡪ࡮ࡲࡥࠡ࡫ࡶࠤࡦࡩࡣࡦࡲࡷࡩࡩࠦࡡ࡯ࡦࠣࡻ࡮ࡲ࡬ࠡࡤࡨࠤࡺࡹࡥࡥࠩე"))
			else: return iiy37aKq0pCEIOwfcTh61xb4U
			if not HCipGJ1cv89rgTjUFNt7Bh0XmqlA: return iiy37aKq0pCEIOwfcTh61xb4U
		else: WKquk5EaNr4RzVf(q1rohYuwnfpVZUa98L2CtQzmAcB,GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠫ࠳ࡢࡴࡅࡱࡺࡲࡱࡵࡡࡥࠢࡖࡹࡨࡩࡥࡦࡦࡨࡨ࠳ࠦࠠࠡࡈ࡬ࡰࡪࠦࡓࡪࡼࡨ࠾ࠥࡡࠠࠨვ")+g9knySsRtf6IXmjaVvUrE8i+TlGXWLYsV1z(u"ࠬࠦࡍࡃࠢࡠࠫზ"))
	return HCipGJ1cv89rgTjUFNt7Bh0XmqlA
def KgNBVtp8GhyPH9Zdvk3bU5Q7EM0z(sQU2GnRoMwLK8CBdfzmNr4jXyO):
	return VVznOTKE7NDIe0HGkg
def hz5lWCRmTwgFV48NSMBPY9AKf(ip=iiy37aKq0pCEIOwfcTh61xb4U):
	global m0T9yjFUQoSXhCGJrxMzep5134
	if m0T9yjFUQoSXhCGJrxMzep5134: return m0T9yjFUQoSXhCGJrxMzep5134
	rVR3khmj0Hs8SNXfqD6y2gidM,CCsm1xkvzejL0RSQZI9JaWD,B203kfQiJdKMt,rt45xp7XA6g8J0ESTcVODqi,Y30Yx9HqWQDd,R4dnewACfcWsVjJZbXhyHk8BIi = iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U
	smglbwR7x2oM = JZszNnIEMAx28Yao0yqhiXGKOPb(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡩࡱࡹ࡫ࡳ࠳࡯ࡳ࠰ࠩთ")+ip+SaB5hx3PZwXRLtKgrTfQvId(u"ࠧࡀࡱࡸࡸࡵࡻࡴ࠾࡬ࡶࡳࡳࠬࡦࡪࡧ࡯ࡨࡸࡃࡩࡱ࠮ࡦࡳࡳࡺࡩ࡯ࡧࡱࡸ࠱ࡩ࡯ࡶࡰࡷࡶࡾ࠲ࡣࡰࡷࡱࡸࡷࡿ࡟ࡤࡱࡧࡩ࠱ࡸࡥࡨ࡫ࡲࡲ࠱ࡩࡩࡵࡻ࠯ࡸ࡮ࡳࡥࡻࡱࡱࡩࠬი")
	CZGXVf91e3KTpSDqyP6x8otlhLBam2 = {uuExaKGL7UONtevRd(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬკ"):iiy37aKq0pCEIOwfcTh61xb4U}
	VVznOTKE7NDIe0HGkg = MMCJxEfv0WUek(r3rnfZ7cdxzNFebIRaLSG6B,TlGXWLYsV1z(u"ࠩࡊࡉ࡙࠭ლ"),smglbwR7x2oM,iiy37aKq0pCEIOwfcTh61xb4U,CZGXVf91e3KTpSDqyP6x8otlhLBam2,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,FRYcH4KL7e9gv5pEB(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡋࡏࡍࡑࡆࡅ࡙ࡏࡏࡏ࠯࠴ࡷࡹ࠭მ"))
	if not VVznOTKE7NDIe0HGkg.succeeded:
		smglbwR7x2oM = ZchUJdM93pTA7zG5(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࡮ࡶ࠭ࡢࡲ࡬࠲ࡨࡵ࡭࠰࡬ࡶࡳࡳ࠵ࠧნ")+ip+LyNiIHPOwD3hCUYEFM7(u"ࠬࡅࡦࡪࡧ࡯ࡨࡸࡃࡱࡶࡧࡵࡽ࠱ࡩ࡯࡯ࡶ࡬ࡲࡪࡴࡴ࠭ࡥࡲࡹࡳࡺࡲࡺ࠮ࡦࡳࡺࡴࡴࡳࡻࡆࡳࡩ࡫ࠬࡳࡧࡪ࡭ࡴࡴࡎࡢ࡯ࡨ࠰ࡨ࡯ࡴࡺ࠮ࡲࡪ࡫ࡹࡥࡵࠩო")
		VVznOTKE7NDIe0HGkg = MMCJxEfv0WUek(r3rnfZ7cdxzNFebIRaLSG6B,ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"࠭ࡇࡆࡖࠪპ"),smglbwR7x2oM,iiy37aKq0pCEIOwfcTh61xb4U,CZGXVf91e3KTpSDqyP6x8otlhLBam2,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,uuExaKGL7UONtevRd(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡉࡈࡓࡑࡕࡃࡂࡖࡌࡓࡓ࠳࠲࡯ࡦࠪჟ"))
	if VVznOTKE7NDIe0HGkg.succeeded:
		Vxz6OndPIX4g2kaRp7 = VVznOTKE7NDIe0HGkg.content
		wrPltUmQ1Cbz97So = bHyN37Y82ZKVLOexBF.loads(Vxz6OndPIX4g2kaRp7)
		qaSoAhlUc3QJmjYGr = list(wrPltUmQ1Cbz97So.keys())
		if tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠨ࡫ࡳࠫრ") in qaSoAhlUc3QJmjYGr: ip = wrPltUmQ1Cbz97So[EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠩ࡬ࡴࠬს")]
		if PtkEvXAqif14G20QZsaSyT(u"ࠪࡧࡴࡴࡴࡪࡰࡨࡲࡹ࠭ტ") in qaSoAhlUc3QJmjYGr: rVR3khmj0Hs8SNXfqD6y2gidM = wrPltUmQ1Cbz97So[HtK4o2sTPgA78U(u"ࠫࡨࡵ࡮ࡵ࡫ࡱࡩࡳࡺࠧუ")]
		if TlGXWLYsV1z(u"ࠬࡩ࡯ࡶࡰࡷࡶࡾ࠭ფ") in qaSoAhlUc3QJmjYGr: CCsm1xkvzejL0RSQZI9JaWD = wrPltUmQ1Cbz97So[SaB5hx3PZwXRLtKgrTfQvId(u"࠭ࡣࡰࡷࡱࡸࡷࡿࠧქ")]
		if vODxLKW5Ql6r4Fbm8(u"ࠧࡤࡱࡸࡲࡹࡸࡹࡠࡥࡲࡨࡪ࠭ღ") in qaSoAhlUc3QJmjYGr: B203kfQiJdKMt = wrPltUmQ1Cbz97So[yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠨࡥࡲࡹࡳࡺࡲࡺࡡࡦࡳࡩ࡫ࠧყ")]
		if JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠩࡵࡩ࡬࡯࡯࡯ࠩშ") in qaSoAhlUc3QJmjYGr: rt45xp7XA6g8J0ESTcVODqi = wrPltUmQ1Cbz97So[tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠪࡶࡪ࡭ࡩࡰࡰࠪჩ")]
		if XrTw01KtLzbpoyMf(u"ࠫࡨ࡯ࡴࡺࠩც") in qaSoAhlUc3QJmjYGr: Y30Yx9HqWQDd = wrPltUmQ1Cbz97So[SaB5hx3PZwXRLtKgrTfQvId(u"ࠬࡩࡩࡵࡻࠪძ")]
		if MgP8OjoaiWQEVG59(u"࠭ࡱࡶࡧࡵࡽࠬწ") in qaSoAhlUc3QJmjYGr: ip = wrPltUmQ1Cbz97So[hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠧࡲࡷࡨࡶࡾ࠭ჭ")]
		if ZchUJdM93pTA7zG5(u"ࠨࡥࡲࡹࡳࡺࡲࡺࡅࡲࡨࡪ࠭ხ") in qaSoAhlUc3QJmjYGr: B203kfQiJdKMt = wrPltUmQ1Cbz97So[IpC4qHXRuyNFjzWv(u"ࠩࡦࡳࡺࡴࡴࡳࡻࡆࡳࡩ࡫ࠧჯ")]
		if LyNiIHPOwD3hCUYEFM7(u"ࠪࡶࡪ࡭ࡩࡰࡰࡑࡥࡲ࡫ࠧჰ") in qaSoAhlUc3QJmjYGr: rt45xp7XA6g8J0ESTcVODqi = wrPltUmQ1Cbz97So[y6y5HtgXO4TkUbwVZ(u"ࠫࡷ࡫ࡧࡪࡱࡱࡒࡦࡳࡥࠨჱ")]
		if UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠬࡺࡩ࡮ࡧࡽࡳࡳ࡫ࠧჲ") in qaSoAhlUc3QJmjYGr:
			R4dnewACfcWsVjJZbXhyHk8BIi = wrPltUmQ1Cbz97So[TlGXWLYsV1z(u"࠭ࡴࡪ࡯ࡨࡾࡴࡴࡥࠨჳ")][LyNiIHPOwD3hCUYEFM7(u"ࠧࡶࡶࡦࠫჴ")]
			if R4dnewACfcWsVjJZbXhyHk8BIi[FGTfwsjNrB8DvKSZhLIQAb1JnO] not in [CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠨ࠯ࠪჵ"),y6y5HtgXO4TkUbwVZ(u"ࠩ࠮ࠫჶ")]: R4dnewACfcWsVjJZbXhyHk8BIi = zmcGfOdvAjsELeJlP(u"ࠪ࠯ࠬჷ")+R4dnewACfcWsVjJZbXhyHk8BIi
		if jXE2YHkswT8y(u"ࠫࡴ࡬ࡦࡴࡧࡷࠫჸ") in qaSoAhlUc3QJmjYGr:
			R4dnewACfcWsVjJZbXhyHk8BIi = wrPltUmQ1Cbz97So[sVzojQerUqX(u"ࠬࡵࡦࡧࡵࡨࡸࠬჹ")]
			if R4dnewACfcWsVjJZbXhyHk8BIi>=ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"࠱ᓳ"): R4dnewACfcWsVjJZbXhyHk8BIi = uuExaKGL7UONtevRd(u"࠭ࠫࠨჺ")+X2cQ5NCPvkMieBW7oASspFjE.strftime(EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠢࠦࡊ࠽ࠩࡒࠨ჻"),X2cQ5NCPvkMieBW7oASspFjE.gmtime(R4dnewACfcWsVjJZbXhyHk8BIi))
			else: R4dnewACfcWsVjJZbXhyHk8BIi = ZchUJdM93pTA7zG5(u"ࠨ࠯ࠪჼ")+X2cQ5NCPvkMieBW7oASspFjE.strftime(JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠤࠨࡌ࠿ࠫࡍࠣჽ"),X2cQ5NCPvkMieBW7oASspFjE.gmtime(-R4dnewACfcWsVjJZbXhyHk8BIi))
	m0T9yjFUQoSXhCGJrxMzep5134 = ip+XrTw01KtLzbpoyMf(u"ࠪ࠰ࠬჾ")+rVR3khmj0Hs8SNXfqD6y2gidM+hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠫ࠱࠭ჿ")+CCsm1xkvzejL0RSQZI9JaWD+jXE2YHkswT8y(u"ࠬ࠲ࠧᄀ")+rt45xp7XA6g8J0ESTcVODqi+PtkEvXAqif14G20QZsaSyT(u"࠭ࠬࠨᄁ")+Y30Yx9HqWQDd+uuExaKGL7UONtevRd(u"ࠧ࠭ࠩᄂ")+R4dnewACfcWsVjJZbXhyHk8BIi
	m0T9yjFUQoSXhCGJrxMzep5134 = m0T9yjFUQoSXhCGJrxMzep5134.encode(df6QpwGxuJVZr)
	if J1MoiYc7ZwzKS: m0T9yjFUQoSXhCGJrxMzep5134 = m0T9yjFUQoSXhCGJrxMzep5134.decode(IpC4qHXRuyNFjzWv(u"ࠨࡷࡱ࡭ࡨࡵࡤࡦࡡࡨࡷࡨࡧࡰࡦࠩᄃ"))
	m0T9yjFUQoSXhCGJrxMzep5134 = vvmT3DLXkhPBwIaOAo6srZpEnRVJC(m0T9yjFUQoSXhCGJrxMzep5134)
	return m0T9yjFUQoSXhCGJrxMzep5134
def XkYnev3ZCA6ahO94(OG3ZdWVcw4j6Nn5kzgASyUuJhpTEb):
	tSWCxLZequIpNQvKD,showDialogs = iiy37aKq0pCEIOwfcTh61xb4U,rGPen6cSMHQkAywh8vqI9JXiD2
	if OG3ZdWVcw4j6Nn5kzgASyUuJhpTEb.count(yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠩࡢࠫᄄ"))>=nI2JK1RfsGWNY3OarEeMQZ:
		OG3ZdWVcw4j6Nn5kzgASyUuJhpTEb,tSWCxLZequIpNQvKD = OG3ZdWVcw4j6Nn5kzgASyUuJhpTEb.split(XrTw01KtLzbpoyMf(u"ࠪࡣࠬᄅ"),YYJQyRskpX8jv)
		tSWCxLZequIpNQvKD = zmcGfOdvAjsELeJlP(u"ࠫࡤ࠭ᄆ")+tSWCxLZequIpNQvKD
		if XrTw01KtLzbpoyMf(u"ࠬࡥࡎࡐࡆࡌࡅࡑࡕࡇࡔࡡࠪᄇ") in tSWCxLZequIpNQvKD: showDialogs = BF6QAiLUNHh7rKOugaw
		else: showDialogs = rGPen6cSMHQkAywh8vqI9JXiD2
	return OG3ZdWVcw4j6Nn5kzgASyUuJhpTEb,tSWCxLZequIpNQvKD,showDialogs
def UELnHN0VWlGoZKa8Mu4riQTkgSC2():
	WtfFabx8qHizMG5LlX60YkBZ = wkMR5x1gTWEQIc6qHCa.path.join(V5f96hvSkeUwCxZrE4dlzpy,uuExaKGL7UONtevRd(u"࠭ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬᄈ"))
	KyD5k2s1SoFv47RI8GlHmXBq = FGTfwsjNrB8DvKSZhLIQAb1JnO
	if wkMR5x1gTWEQIc6qHCa.path.exists(WtfFabx8qHizMG5LlX60YkBZ):
		for VBb0cK9HdXsp5ouJ17vhewL6GRztn in wkMR5x1gTWEQIc6qHCa.listdir(WtfFabx8qHizMG5LlX60YkBZ):
			if ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠧ࠯ࡲࡼࡳࠬᄉ") in VBb0cK9HdXsp5ouJ17vhewL6GRztn: continue
			if SaB5hx3PZwXRLtKgrTfQvId(u"ࠨࡡࡢࡴࡾࡩࡡࡤࡪࡨࡣࡤ࠭ᄊ") in VBb0cK9HdXsp5ouJ17vhewL6GRztn: continue
			b62Op4ACWa1DufrTU5dL7hz = wkMR5x1gTWEQIc6qHCa.path.join(WtfFabx8qHizMG5LlX60YkBZ,VBb0cK9HdXsp5ouJ17vhewL6GRztn)
			OtJ0V3QBE8zWxSskHMDXj,MH9dDWw6lxUpqcAYzFhveGZoKVQ = MZ0QpfA1jaJgoWO2IndU(b62Op4ACWa1DufrTU5dL7hz)
			KyD5k2s1SoFv47RI8GlHmXBq += OtJ0V3QBE8zWxSskHMDXj
	return KyD5k2s1SoFv47RI8GlHmXBq
def QJpT1XnkNomcWeiB8M7(showDialogs):
	XXH5nP4frIvhztdjBDCYk = OXsckY7RzjCag9A.getSetting(ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡳࡥࡴࡵࡤ࡫ࡪࡹࠧᄋ"))
	KmdOyv8IVUgwYGXuBafql41 = QKzCiBOWZus1nSv(PdkZHNBlpg2b7DmX6qRiyVa,ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠪࡷࡹࡸࠧᄌ"),EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧᄍ"),sVzojQerUqX(u"ࠬࡓࡅࡔࡕࡄࡋࡊ࡙ࠧᄎ"))
	hxvBs6gRt7eGDLHSyEZ4Qnqc1N2,CwaSuJVMpRnx = XXH5nP4frIvhztdjBDCYk,KmdOyv8IVUgwYGXuBafql41
	mgBeTA4XrZ1ChfcyaYK,lAro7n9bksuiTdUp6qXP0hgDz = iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U
	if y6y5HtgXO4TkUbwVZ(u"࠭ࡍࡆࡕࡖࡅࡌࡋࡓࠨᄏ") not in str(RR80SbLUCimJrMV):
		smglbwR7x2oM = gZ4LwbKaOm[YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠧࡑ࡛ࡗࡌࡔࡔࠧᄐ")][iiCWLaJREureAlOkv]
		A35buNj8r7ydgkYsOQvW0 = hz5lWCRmTwgFV48NSMBPY9AKf()
		CCsm1xkvzejL0RSQZI9JaWD = A35buNj8r7ydgkYsOQvW0.split(hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠨ࠮ࠪᄑ"))[nI2JK1RfsGWNY3OarEeMQZ]
		KyD5k2s1SoFv47RI8GlHmXBq = UELnHN0VWlGoZKa8Mu4riQTkgSC2()
		nT4CcjPoyq1NWYeDSrgkJxB0F2tHp = {UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠩࡸࡷࡪࡸࠧᄒ"):iw3BpJl1Y9tbg8XMR4VeoS6kEUhf,EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫᄓ"):DdAjF5pBNL9IqPgkz0xhcQEfU,tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠫࡨࡵࡵ࡯ࡶࡵࡽࠬᄔ"):CCsm1xkvzejL0RSQZI9JaWD,PtkEvXAqif14G20QZsaSyT(u"ࠬ࡯ࡤࡴࠩᄕ"):kTJISUV1CbZQ2gndAuMwBP7(KyD5k2s1SoFv47RI8GlHmXBq)}
		VVznOTKE7NDIe0HGkg = MMCJxEfv0WUek(hI7SkXd94fFzAHNZCQoMqEutbnWP,Y41NvKfOroMzGB8sEHy7wbXlc5(u"࠭ࡐࡐࡕࡗࠫᄖ"),smglbwR7x2oM,nT4CcjPoyq1NWYeDSrgkJxB0F2tHp,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,y6y5HtgXO4TkUbwVZ(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡉࡈࡘࡤࡓࡅࡔࡕࡄࡋࡊ࡙࠭࠲ࡵࡷࠫᄗ"))
		if not VVznOTKE7NDIe0HGkg.succeeded:
			if XXH5nP4frIvhztdjBDCYk in [iiy37aKq0pCEIOwfcTh61xb4U,L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠨࡐࡈ࡛ࠬᄘ")]: hxvBs6gRt7eGDLHSyEZ4Qnqc1N2 = AbqCJZdWQP9j(u"ࠩࡑࡉ࡜ࡥࡔࡐࡡࡈࡖࡗࡕࡒࠨᄙ")
			elif XXH5nP4frIvhztdjBDCYk==YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠪࡓࡑࡊࠧᄚ"): hxvBs6gRt7eGDLHSyEZ4Qnqc1N2 = uuExaKGL7UONtevRd(u"ࠫࡔࡒࡄࡠࡖࡒࡣࡊࡘࡒࡐࡔࠪᄛ")
		else:
			WtCPcwBJ1KayVqb = VVznOTKE7NDIe0HGkg.content
			WtCPcwBJ1KayVqb = DeIL3qoa2UBtYPb(hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠬࡲࡩࡴࡶࠪᄜ"),WtCPcwBJ1KayVqb)
			WtCPcwBJ1KayVqb = sorted(WtCPcwBJ1KayVqb,reverse=rGPen6cSMHQkAywh8vqI9JXiD2,key=lambda key: int(key[FGTfwsjNrB8DvKSZhLIQAb1JnO]))
			lAro7n9bksuiTdUp6qXP0hgDz,CwaSuJVMpRnx = iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U
			for gYWOKvJ5Us7AjLPw6DbeErx,i0dJnpDS5ZF9rO8E74kH,NNFlSgsp39MWCGxaXEILe in WtCPcwBJ1KayVqb:
				if gYWOKvJ5Us7AjLPw6DbeErx==IpC4qHXRuyNFjzWv(u"࠭࠰ࠨᄝ"):
					lAro7n9bksuiTdUp6qXP0hgDz += NNFlSgsp39MWCGxaXEILe+sVzojQerUqX(u"ࠧ࠻࠼ࠪᄞ")
					continue
				if CwaSuJVMpRnx: CwaSuJVMpRnx += OTlVEGYPSxsNaBdXUucqA3+PSwfZcdRYhpl5Igqz8xOEk67+tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠨࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦࠧᄟ")+YoQW601K4fMJcsreDnGVE5wUZIy7+yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠩ࡟ࡲࡡࡴࠧᄠ")
				EwS2qdRczpOWbJAnTPf97ta = NNFlSgsp39MWCGxaXEILe.split(OTlVEGYPSxsNaBdXUucqA3)[FGTfwsjNrB8DvKSZhLIQAb1JnO]
				h5aq3QTUSLDnB4lXMt1I = GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠪีุอไสࠢัหฺฯࠠๅๅࠣๅ็฽ࠧᄡ") if i0dJnpDS5ZF9rO8E74kH else iiy37aKq0pCEIOwfcTh61xb4U
				CwaSuJVMpRnx += NNFlSgsp39MWCGxaXEILe.replace(EwS2qdRczpOWbJAnTPf97ta,aqEsMBckT2bunGHfl48Wip+EwS2qdRczpOWbJAnTPf97ta+h5aq3QTUSLDnB4lXMt1I+YoQW601K4fMJcsreDnGVE5wUZIy7)+OTlVEGYPSxsNaBdXUucqA3
			CwaSuJVMpRnx = OTlVEGYPSxsNaBdXUucqA3+CwaSuJVMpRnx+UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠫࡡࡴ࡜࡯ࠩᄢ")
			lAro7n9bksuiTdUp6qXP0hgDz = lAro7n9bksuiTdUp6qXP0hgDz.strip(sVzojQerUqX(u"ࠬࡀ࠺ࠨᄣ"))
			mgBeTA4XrZ1ChfcyaYK = OXsckY7RzjCag9A.getSetting(MgP8OjoaiWQEVG59(u"࠭ࡡࡷ࠰ࡳࡶ࡮ࡼࡳ࠲ࠩᄤ"))
			if CwaSuJVMpRnx==KmdOyv8IVUgwYGXuBafql41 and XXH5nP4frIvhztdjBDCYk in [uuExaKGL7UONtevRd(u"ࠧࡐࡎࡇࠫᄥ"),uuExaKGL7UONtevRd(u"ࠨࡑࡏࡈࡤ࡚ࡏࡠࡇࡕࡖࡔࡘࠧᄦ")]: hxvBs6gRt7eGDLHSyEZ4Qnqc1N2 = tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠩࡒࡐࡉ࠭ᄧ")
			else: hxvBs6gRt7eGDLHSyEZ4Qnqc1N2 = IpC4qHXRuyNFjzWv(u"ࠪࡒࡊ࡝ࠧᄨ")
			YMQXP2BGeK86CEb(PdkZHNBlpg2b7DmX6qRiyVa,YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧᄩ"),xpT28sXu051(u"ࠬࡓࡅࡔࡕࡄࡋࡊ࡙ࠧᄪ"),CwaSuJVMpRnx,VaeMF1mIjQ5iLtfGcB)
			OXsckY7RzjCag9A.setSetting(FRYcH4KL7e9gv5pEB(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡳࡥࡴࡵࡤ࡫ࡪࡹࠧᄫ"),kTJISUV1CbZQ2gndAuMwBP7(pwXCQWuGUMka2hFN))
			OXsckY7RzjCag9A.setSetting(HtK4o2sTPgA78U(u"ࠧࡢࡸ࠱ࡴࡷ࡯ࡶࡴ࠳ࠪᄬ"),lAro7n9bksuiTdUp6qXP0hgDz)
			StbuiQDrJk = WWbKa0cgvFOURDoHIEV3uhipsJ96.md5(UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"࠷ᓴ")*lAro7n9bksuiTdUp6qXP0hgDz.encode(df6QpwGxuJVZr)).hexdigest()
			StbuiQDrJk = WWbKa0cgvFOURDoHIEV3uhipsJ96.md5(MgP8OjoaiWQEVG59(u"࠴࠸ᓵ")*StbuiQDrJk.encode(df6QpwGxuJVZr)).hexdigest()
			StbuiQDrJk = WWbKa0cgvFOURDoHIEV3uhipsJ96.md5(PtkEvXAqif14G20QZsaSyT(u"࠵࠾ᓶ")*StbuiQDrJk.encode(df6QpwGxuJVZr)).hexdigest()
			FZ0zy7Cgeo1UjkR,AlI5YdVoWgZyP = gkdxoKzQVY6C7OGF3JvM9Xq(PdkZHNBlpg2b7DmX6qRiyVa)
			d18pEhPG35UZxSyW2kcqgKTR = AlI5YdVoWgZyP.execute(JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠨࡒࡕࡅࡌࡓࡁࠡࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳࡥࡩࡥ࠿ࠪᄭ")+str(int(StbuiQDrJk[YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"࠹ᓸ"):CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"࠱࠳ᓹ")],GGx4qyKP1vUtRghsE2WfaHLMXZ(u"࠲࠸ᓺ")))[:hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"࠾ᓷ")]+y6y5HtgXO4TkUbwVZ(u"ࠩ࠾ࠫᄮ"))
			FZ0zy7Cgeo1UjkR.close()
		rSoU6Xgplcb3fJ1q4hzvATiVQekt = rGPen6cSMHQkAywh8vqI9JXiD2 if lAro7n9bksuiTdUp6qXP0hgDz!=mgBeTA4XrZ1ChfcyaYK else BF6QAiLUNHh7rKOugaw
		if rSoU6Xgplcb3fJ1q4hzvATiVQekt:
			JM9BOLa5Uhu4s = IiCsQD91HF.ic2FB5X43kWzyTKtNE
			IiCsQD91HF.bbrnyC5Bz9Vqgc0fFYuZ6QNEMvXK7,IiCsQD91HF.ic2FB5X43kWzyTKtNE,IiCsQD91HF.e8cB3UpjldxMI,IiCsQD91HF.i95KXZx1GISPt = EETfYmdIcBQsXGiLzpODJxr35e([jXE2YHkswT8y(u"ࠪࡇ࡙ࡋ࠹ࡅࡕ࠴࠽࡛࡛࠰ࡗࡕ࡛ࠫᄯ"),ZchUJdM93pTA7zG5(u"ࠫ࡜࡙ࡕࡓࡈࡗ࠵࠾ࡗࡔࡆࡈ࡝࡜ࠬᄰ"),sVzojQerUqX(u"ࠬࡈࡔࡆࡺࡓ࡚࠶࠿ࡕࡓࡘࡑ࡙ࡘ࡛࠵ࡉ࡚ࠪᄱ"),L90uqo28xEKSFUwYTcm51yRWZIkft(u"࠭ࡏࡕ࠳࠼ࡎ࡚࠶ࡸࡃࡖࡘࡰࡉ࡞ࠧᄲ")])
			tvsD8pWQyH0bk = IiCsQD91HF.ic2FB5X43kWzyTKtNE
			if not JM9BOLa5Uhu4s and tvsD8pWQyH0bk and XrTw01KtLzbpoyMf(u"ࠧࡎࡇࡖࡗࡆࡍࡅࡔࡡࡗࡗࠬᄳ") in RR80SbLUCimJrMV:
				RR80SbLUCimJrMV.remove(ZchUJdM93pTA7zG5(u"ࠨࡏࡈࡗࡘࡇࡇࡆࡕࡢࡘࡘ࠭ᄴ"))
				RR80SbLUCimJrMV.append(UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠩࡐࡉࡘ࡙ࡁࡈࡇࡖࠫᄵ"))
			elif JM9BOLa5Uhu4s and not tvsD8pWQyH0bk and CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠪࡑࡊ࡙ࡓࡂࡉࡈࡗࠬᄶ") in RR80SbLUCimJrMV:
				RR80SbLUCimJrMV.remove(XrTw01KtLzbpoyMf(u"ࠫࡒࡋࡓࡔࡃࡊࡉࡘ࠭ᄷ"))
				RR80SbLUCimJrMV.append(SaB5hx3PZwXRLtKgrTfQvId(u"ࠬࡓࡅࡔࡕࡄࡋࡊ࡙࡟ࡕࡕࠪᄸ"))
			SqMHwb6X1Ph8jY7LBNkmtV4F5Jlspy(BF6QAiLUNHh7rKOugaw)
	if showDialogs:
		if hxvBs6gRt7eGDLHSyEZ4Qnqc1N2 in [ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"࠭ࡏࡍࡆࡢࡘࡔࡥࡅࡓࡔࡒࡖࠬᄹ"),hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠧࡏࡇ࡚ࡣ࡙ࡕ࡟ࡆࡔࡕࡓࡗ࠭ᄺ")]:
			bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,HtK4o2sTPgA78U(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᄻ"),AbqCJZdWQP9j(u"๊๊ࠩฬ้ࠠๆึๆ่ฮࠦแ๋ࠢฯ๋ฬุใ๊๊ࠡ๎๊๊ࠥิฬ้๋ࠣࠦวๅสิ๊ฬ๋ฬࠡ࠰࠱ࠤ์ึ็ࠡษ็ู้้ไสࠢๅำࠥ๐ใ้่ࠣือฮ็ศࠢส่ส์สา่อࠤฬ๊ฮศืࠣฬ่ࠦร้ࠢส่ึอ่หำࠣห้ิวึࠢห็ࠥษ่ࠡ็ื็้ฯࠠโ์ࠣห้ษำๅษๆࠤ฾์ฯไࠩᄼ"))
		else:
			ggULVKqsMZbc1ynfBC7(SaB5hx3PZwXRLtKgrTfQvId(u"ࠪࡶ࡮࡭ࡨࡵࠩᄽ"),CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠫึูววๆ้๋ࠣࠦวๅ็หี๊าࠠฦๆ์ࠤู๊สฯั่๎ࠥอไษำ้ห๊าࠧᄾ"),CwaSuJVMpRnx,vODxLKW5Ql6r4Fbm8(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࡠ࡮ࡲࡲ࡬࠭ᄿ"))
			hxvBs6gRt7eGDLHSyEZ4Qnqc1N2 = JZszNnIEMAx28Yao0yqhiXGKOPb(u"࠭ࡏࡍࡆࠪᅀ")
	if hxvBs6gRt7eGDLHSyEZ4Qnqc1N2!=XXH5nP4frIvhztdjBDCYk:
		OXsckY7RzjCag9A.setSetting(TlGXWLYsV1z(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡱࡪࡹࡳࡢࡩࡨࡷࠬᅁ"),hxvBs6gRt7eGDLHSyEZ4Qnqc1N2)
		SqMHwb6X1Ph8jY7LBNkmtV4F5Jlspy(BF6QAiLUNHh7rKOugaw)
	return
def iqEgBpYWHmh8uXFzOwMG(eNyxJLBPSwhQs,iCJN5klxdc):
	from socket import socket as lwugO16XR3UKeqpdCsfzijm,AF_INET as rmlR3OKoLGeNs,SOCK_STREAM as g5gE4wnyMf0q9dVxjTRCSciWYo
	SSQAGTODfU5Csjkue4HYxqntXv = lwugO16XR3UKeqpdCsfzijm(rmlR3OKoLGeNs,g5gE4wnyMf0q9dVxjTRCSciWYo)
	SSQAGTODfU5Csjkue4HYxqntXv.settimeout(YYJQyRskpX8jv)
	zxhLWvnMpYmajICB,kmuzfxD58vnHBJK4 = rGPen6cSMHQkAywh8vqI9JXiD2,FGTfwsjNrB8DvKSZhLIQAb1JnO
	QhNGvIF4YS2a5gxLAcy1k6VW3w = X2cQ5NCPvkMieBW7oASspFjE.time()
	try: SSQAGTODfU5Csjkue4HYxqntXv.connect((eNyxJLBPSwhQs,iCJN5klxdc))
	except: zxhLWvnMpYmajICB = BF6QAiLUNHh7rKOugaw
	mi4AfdRzjbaogrM25v1nkGFwNS6tBD = X2cQ5NCPvkMieBW7oASspFjE.time()
	if zxhLWvnMpYmajICB: kmuzfxD58vnHBJK4 = mi4AfdRzjbaogrM25v1nkGFwNS6tBD-QhNGvIF4YS2a5gxLAcy1k6VW3w
	return kmuzfxD58vnHBJK4
def pzdyLtNP8rYDiUacIf(showDialogs):
	if showDialogs:
		U17QqF2gkI46 = A1AXKupEOfz(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,zmcGfOdvAjsELeJlP(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᅂ"),ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠩึ์ๆ๊ࠦใ๊่ࠤฬ๊ศา่ส้ัࠦวๅฤ้ࠤอหีๅษะࠤํะๆู์ไࠤัฺ๋๊ࠢๅ์ฬ฿ฯࠡษ็ฬ๏อๆศฬࠣ์ฬ๊ใศึࠣห้๋ำหะา้ฮࠦแ๋ࠢส่อืๆศ็ฯࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡฬื฾๏ฺ๊ࠠ็็๎ฮࠦวๅฬ้฼๏็ࠠศๆล๊ࠥลࠡࠨᅃ"))
	else: U17QqF2gkI46 = rGPen6cSMHQkAywh8vqI9JXiD2
	if U17QqF2gkI46==YYJQyRskpX8jv:
		for VBb0cK9HdXsp5ouJ17vhewL6GRztn in wkMR5x1gTWEQIc6qHCa.listdir(StqmrCIJX4T623w5j9NEonxfQ):
			if VBb0cK9HdXsp5ouJ17vhewL6GRztn.endswith(TlGXWLYsV1z(u"ࠪ࠲ࡩࡨࠧᅄ")) and JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠫࡩࡧࡴࡢࠩᅅ") in VBb0cK9HdXsp5ouJ17vhewL6GRztn:
				qfznVTCRpxSDM85QGBHoU = wkMR5x1gTWEQIc6qHCa.path.join(StqmrCIJX4T623w5j9NEonxfQ,VBb0cK9HdXsp5ouJ17vhewL6GRztn)
				FZ0zy7Cgeo1UjkR,AlI5YdVoWgZyP = gkdxoKzQVY6C7OGF3JvM9Xq(qfznVTCRpxSDM85QGBHoU)
				AlI5YdVoWgZyP.execute(vODxLKW5Ql6r4Fbm8(u"ࠬࡖࡒࡂࡉࡐࡅࠥ࡬࡯ࡳࡧ࡬࡫ࡳࡥ࡫ࡦࡻࡶࡁࡳࡵ࠻ࠨᅆ"))
				AlI5YdVoWgZyP.execute(CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"࠭ࡐࡓࡃࡊࡑࡆࠦࡴࡦ࡯ࡳࡣࡸࡺ࡯ࡳࡧࡀࡑࡊࡓࡏࡓ࡛࠾ࠫᅇ"))
				AlI5YdVoWgZyP.execute(EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠧࡑࡔࡄࡋࡒࡇࠠࡪࡰࡷࡩ࡬ࡸࡩࡵࡻࡢࡧ࡭࡫ࡣ࡬࠽ࠪᅈ"))
				AlI5YdVoWgZyP.execute(hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠨࡒࡕࡅࡌࡓࡁࠡࡱࡳࡸ࡮ࡳࡩࡻࡧ࠾ࠫᅉ"))
				AlI5YdVoWgZyP.execute(hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"࡙ࠩࡅࡈ࡛ࡕࡎ࠽ࠪᅊ"))
				FZ0zy7Cgeo1UjkR.commit()
				FZ0zy7Cgeo1UjkR.close()
		if showDialogs: bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,xpT28sXu051(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ᅋ"),vODxLKW5Ql6r4Fbm8(u"ࠫฯ๋สࠡส้ะฬำฺࠠ็็๎ฮࠦลึๆสัࠥ๎ส็ฺํๅࠥาๅ๋฻ࠣๆํอูะࠢส่อ๐ว็ษอࠤํอไไษืࠤฬ๊ๅิฬัำ๊ฯࠠโ์ࠣห้ฮั็ษ่ะࠬᅌ"))
	return
def qI2s0ZN7uj(lYbnmpxai7v8Id03PyNSW,evY8TlC76uIEGWkpc,showDialogs):
	if lYbnmpxai7v8Id03PyNSW!=None:
		global rbKI7RAUc9SCoTagkXFJyiePNfx6
		rbKI7RAUc9SCoTagkXFJyiePNfx6 = lYbnmpxai7v8Id03PyNSW
	if evY8TlC76uIEGWkpc!=None:
		global jZPNfVdJqoQx4
		jZPNfVdJqoQx4 = evY8TlC76uIEGWkpc
	if showDialogs!=None:
		global O8ObqHAIx6sgnaNC7dLDXcVt9GZh2B
		O8ObqHAIx6sgnaNC7dLDXcVt9GZh2B = showDialogs
	return
def CuwjkBr8l10vb(bDlzGospmi69Oy1NILPaHMWK8Z3FSw,smglbwR7x2oM,data,headers,allow_redirects,showDialogs,VamqUtbfFn6MANy,D8o76IEfjVOLz,N9Bvn0opEfM):
	if showDialogs==iiy37aKq0pCEIOwfcTh61xb4U: bHZ5D6c9pRGfx = rGPen6cSMHQkAywh8vqI9JXiD2 if O8ObqHAIx6sgnaNC7dLDXcVt9GZh2B==iiy37aKq0pCEIOwfcTh61xb4U else O8ObqHAIx6sgnaNC7dLDXcVt9GZh2B
	else: bHZ5D6c9pRGfx = rGPen6cSMHQkAywh8vqI9JXiD2 if showDialogs else BF6QAiLUNHh7rKOugaw
	if N9Bvn0opEfM==iiy37aKq0pCEIOwfcTh61xb4U: WZJQ4PfXSw6yx7I = rGPen6cSMHQkAywh8vqI9JXiD2 if jZPNfVdJqoQx4==iiy37aKq0pCEIOwfcTh61xb4U else jZPNfVdJqoQx4
	else: WZJQ4PfXSw6yx7I = rGPen6cSMHQkAywh8vqI9JXiD2 if N9Bvn0opEfM else BF6QAiLUNHh7rKOugaw
	if D8o76IEfjVOLz==iiy37aKq0pCEIOwfcTh61xb4U: T2tbsJZ8eQnPIwUjMcLxgvrHpYOyR7 = rGPen6cSMHQkAywh8vqI9JXiD2 if rbKI7RAUc9SCoTagkXFJyiePNfx6==iiy37aKq0pCEIOwfcTh61xb4U else rbKI7RAUc9SCoTagkXFJyiePNfx6
	else: T2tbsJZ8eQnPIwUjMcLxgvrHpYOyR7 = rGPen6cSMHQkAywh8vqI9JXiD2 if D8o76IEfjVOLz else BF6QAiLUNHh7rKOugaw
	if allow_redirects==iiy37aKq0pCEIOwfcTh61xb4U: mC1Iuc3BdXv6ZPMeG2aQxDlV = rGPen6cSMHQkAywh8vqI9JXiD2
	else: mC1Iuc3BdXv6ZPMeG2aQxDlV = rGPen6cSMHQkAywh8vqI9JXiD2 if allow_redirects else BF6QAiLUNHh7rKOugaw
	rzR9SN7ApZuQhTDWEX3V6ga = {} if headers==iiy37aKq0pCEIOwfcTh61xb4U else headers
	EwsmJ67cCYDIlg = {} if data==iiy37aKq0pCEIOwfcTh61xb4U else data
	if VamqUtbfFn6MANy==TlGXWLYsV1z(u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙࠭ࡊࡐࡖࡘࡆࡒࡌࡠࡑࡏࡈࡤࡘࡅࡍࡇࡄࡗࡊ࠳࠱ࡴࡶࠪᅍ"): rzR9SN7ApZuQhTDWEX3V6ga = {}
	else:
		bqI8FwRJxPYm27sClVDZ = list(rzR9SN7ApZuQhTDWEX3V6ga.keys())
		if y6y5HtgXO4TkUbwVZ(u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧᅎ") not in bqI8FwRJxPYm27sClVDZ: rzR9SN7ApZuQhTDWEX3V6ga[UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨᅏ")] = FRYcH4KL7e9gv5pEB(u"ࠨࡪࡷࡸࡵ࠭ᅐ")
		if SaB5hx3PZwXRLtKgrTfQvId(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ᅑ") not in bqI8FwRJxPYm27sClVDZ: rzR9SN7ApZuQhTDWEX3V6ga[tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧᅒ")] = FgJLkYac7lQxEbs(rGPen6cSMHQkAywh8vqI9JXiD2)
	return bDlzGospmi69Oy1NILPaHMWK8Z3FSw,smglbwR7x2oM,EwsmJ67cCYDIlg,rzR9SN7ApZuQhTDWEX3V6ga,mC1Iuc3BdXv6ZPMeG2aQxDlV,bHZ5D6c9pRGfx,VamqUtbfFn6MANy,T2tbsJZ8eQnPIwUjMcLxgvrHpYOyR7,WZJQ4PfXSw6yx7I
def GJqpByOKiRenb184w0(bDlzGospmi69Oy1NILPaHMWK8Z3FSw,smglbwR7x2oM,oRzlSfeE6DY0mFy37NCVxAJW1BwZtM,CZGXVf91e3KTpSDqyP6x8otlhLBam2,Kh6Op2cwaB9,showDialogs,VamqUtbfFn6MANy,D8o76IEfjVOLz=iiy37aKq0pCEIOwfcTh61xb4U,N9Bvn0opEfM=iiy37aKq0pCEIOwfcTh61xb4U):
	BehavuIfZnQ9xW6CXVgH = CuwjkBr8l10vb(bDlzGospmi69Oy1NILPaHMWK8Z3FSw,smglbwR7x2oM,oRzlSfeE6DY0mFy37NCVxAJW1BwZtM,CZGXVf91e3KTpSDqyP6x8otlhLBam2,Kh6Op2cwaB9,showDialogs,VamqUtbfFn6MANy,D8o76IEfjVOLz,N9Bvn0opEfM)
	bDlzGospmi69Oy1NILPaHMWK8Z3FSw,smglbwR7x2oM,EwsmJ67cCYDIlg,rzR9SN7ApZuQhTDWEX3V6ga,mC1Iuc3BdXv6ZPMeG2aQxDlV,bHZ5D6c9pRGfx,VamqUtbfFn6MANy,T2tbsJZ8eQnPIwUjMcLxgvrHpYOyR7,WZJQ4PfXSw6yx7I = BehavuIfZnQ9xW6CXVgH
	eCGwzSrqBmIv,TeLlsNSmcf7FvU3byDkzWAItq5da4R,uuHt2FaeJLp8,KvXWMwZf438UyOnFBlqPDsiIm1c0L = T2TI6RohemNWG4(smglbwR7x2oM)
	u9XCDzyOjNi = OXsckY7RzjCag9A.getSetting(HtK4o2sTPgA78U(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡥࡰࡶࠫᅓ"))
	SZNw0txeoyrsjiAUn = OXsckY7RzjCag9A.getSetting(MgP8OjoaiWQEVG59(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡷࡶࡩࡩࡴࡳࠨᅔ"))
	ULsxfNwT4Akv3cSE8gmrXB6 = OXsckY7RzjCag9A.getSetting(GGx4qyKP1vUtRghsE2WfaHLMXZ(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡸࡷࡪࡶࡲࡰࡺࡼࠫᅕ"))
	YiRtHb1SsT = [zmcGfOdvAjsELeJlP(u"ࠧࡴࡥࡵࡥࡵ࡫࡯ࡱࡵࠪᅖ"),MgP8OjoaiWQEVG59(u"ࠨࡵࡦࡶࡦࡶࡥࡳࡣࡳ࡭ࠬᅗ"),tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠩࡶࡧࡷࡧࡰࡪࡰࡪࡥࡳࡺࠧᅘ"),FRYcH4KL7e9gv5pEB(u"ࠪࡷࡨࡸࡡࡱ࡫ࡱ࡫ࡷࡵࡢࡰࡶࠪᅙ"),XrTw01KtLzbpoyMf(u"ࠫࡸࡩࡲࡢࡲࡨࡹࡵ࠭ᅚ"),MgP8OjoaiWQEVG59(u"ࠬࡹࡣࡳࡣࡳࡩ࠳ࡪ࡯ࠨᅛ")]
	amFCNfE3e9j = rGPen6cSMHQkAywh8vqI9JXiD2 if any(aasX2cby4Vo5rTgB in smglbwR7x2oM for aasX2cby4Vo5rTgB in YiRtHb1SsT) else BF6QAiLUNHh7rKOugaw
	if ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"࠭ࠦࡶࡴ࡯ࡁࠬᅜ") in eCGwzSrqBmIv and amFCNfE3e9j: pFDkX1be0ahQtgB5K9o8u2IlRjsJL = eCGwzSrqBmIv.rsplit(yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠧࠧࡷࡵࡰࡂ࠭ᅝ"),GGx4qyKP1vUtRghsE2WfaHLMXZ(u"࠳ᓻ"))[YYJQyRskpX8jv]
	else: pFDkX1be0ahQtgB5K9o8u2IlRjsJL = iiy37aKq0pCEIOwfcTh61xb4U
	qq1akwOhbSK7DxH8ejyCUQ = gZ4LwbKaOm[zmcGfOdvAjsELeJlP(u"ࠨࡒ࡜ࡘࡍࡕࡎࠨᅞ")]
	mm3f1ysFBLekStg4J = eCGwzSrqBmIv in qq1akwOhbSK7DxH8ejyCUQ or pFDkX1be0ahQtgB5K9o8u2IlRjsJL in qq1akwOhbSK7DxH8ejyCUQ
	nIHeh8abAStMF = gZ4LwbKaOm[sVzojQerUqX(u"ࠩࡕࡉࡕࡕࡓࠨᅟ")]
	Wtn4aBMjciVGd8oIK2 = eCGwzSrqBmIv in nIHeh8abAStMF or pFDkX1be0ahQtgB5K9o8u2IlRjsJL in nIHeh8abAStMF
	t4gzUilp0mGHjPrvQSAfB3aDI = mm3f1ysFBLekStg4J or Wtn4aBMjciVGd8oIK2
	dkWYFLy4E2xJGS6g = BF6QAiLUNHh7rKOugaw
	kPIjYiFwQcg8nbBHsy5zKdxpS = rGPen6cSMHQkAywh8vqI9JXiD2
	OYQEkcp7MSKiqPareb01wIR = TeLlsNSmcf7FvU3byDkzWAItq5da4R==None and uuHt2FaeJLp8==None and not amFCNfE3e9j
	if OYQEkcp7MSKiqPareb01wIR and t4gzUilp0mGHjPrvQSAfB3aDI:
		if mm3f1ysFBLekStg4J:
			H9Mjxsn70GR1EFTmeY2NubtkJW = qq1akwOhbSK7DxH8ejyCUQ.index(eCGwzSrqBmIv)
			xU0CngZJ5MPO8kBh7Yu2l3SrQsIDt = gZ4LwbKaOm[jXE2YHkswT8y(u"ࠪࡔ࡞࡚ࡈࡐࡐࡢࡆࡐࡖ࠱ࠨᅠ")][H9Mjxsn70GR1EFTmeY2NubtkJW]
			I27ogq5n0fudMYjED = gZ4LwbKaOm[UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠫࡕ࡟ࡔࡉࡑࡑࡣࡇࡑࡐ࠳ࠩᅡ")][H9Mjxsn70GR1EFTmeY2NubtkJW]
			vlDF0ck58Cmz3jqOy2UhZMBPt6deQ = gZ4LwbKaOm[TlGXWLYsV1z(u"ࠬࡖ࡙ࡕࡊࡒࡒࡤࡈࡋࡑ࠵ࠪᅢ")][H9Mjxsn70GR1EFTmeY2NubtkJW]
			nYj9DlqLkQsmS8xthp = bjiw4aZJOKMtpkrAFWug0vx3LNd2Ec[H9Mjxsn70GR1EFTmeY2NubtkJW]
			if nYj9DlqLkQsmS8xthp==sVzojQerUqX(u"࠭ࡌࡊࡕࡗࡔࡑࡇ࡙ࠨᅣ"): T2tbsJZ8eQnPIwUjMcLxgvrHpYOyR7,WZJQ4PfXSw6yx7I,kPIjYiFwQcg8nbBHsy5zKdxpS = BF6QAiLUNHh7rKOugaw,BF6QAiLUNHh7rKOugaw,BF6QAiLUNHh7rKOugaw
			elif nYj9DlqLkQsmS8xthp==XrTw01KtLzbpoyMf(u"ࠧࡄࡃࡓࡘࡈࡎࡁࠨᅤ"): dkWYFLy4E2xJGS6g = rGPen6cSMHQkAywh8vqI9JXiD2
		elif Wtn4aBMjciVGd8oIK2:
			H9Mjxsn70GR1EFTmeY2NubtkJW = nIHeh8abAStMF.index(eCGwzSrqBmIv)
			xU0CngZJ5MPO8kBh7Yu2l3SrQsIDt = gZ4LwbKaOm[L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠨࡔࡈࡔࡔ࡙࡟ࡃࡍࡓ࠵ࠬᅥ")][H9Mjxsn70GR1EFTmeY2NubtkJW]
			I27ogq5n0fudMYjED = gZ4LwbKaOm[XrTw01KtLzbpoyMf(u"ࠩࡕࡉࡕࡕࡓࡠࡄࡎࡔ࠷࠭ᅦ")][H9Mjxsn70GR1EFTmeY2NubtkJW]
			vlDF0ck58Cmz3jqOy2UhZMBPt6deQ = gZ4LwbKaOm[AbqCJZdWQP9j(u"ࠪࡖࡊࡖࡏࡔࡡࡅࡏࡕ࠹ࠧᅧ")][H9Mjxsn70GR1EFTmeY2NubtkJW]
			nYj9DlqLkQsmS8xthp = gsteZDpHaMmyQkBwC[H9Mjxsn70GR1EFTmeY2NubtkJW]
	if uuHt2FaeJLp8==iiy37aKq0pCEIOwfcTh61xb4U: uuHt2FaeJLp8 = u9XCDzyOjNi
	elif uuHt2FaeJLp8==None and SZNw0txeoyrsjiAUn in [tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠫࡆ࡛ࡔࡐࠩᅨ"),AbqCJZdWQP9j(u"ࠬࡇࡃࡄࡇࡓࡘࡊࡊࠧᅩ")] and T2tbsJZ8eQnPIwUjMcLxgvrHpYOyR7: uuHt2FaeJLp8 = u9XCDzyOjNi
	if mm3f1ysFBLekStg4J or Wtn4aBMjciVGd8oIK2: ff23ICqELcvWaZYm4suDzHnU = Y41NvKfOroMzGB8sEHy7wbXlc5(u"࠴࠹ᓼ")
	elif amFCNfE3e9j: ff23ICqELcvWaZYm4suDzHnU = SaB5hx3PZwXRLtKgrTfQvId(u"࠺࠵ᓽ")
	elif VamqUtbfFn6MANy in LJCPyc4vO8t3d: ff23ICqELcvWaZYm4suDzHnU = CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"࠶࠶ᓾ")
	elif VamqUtbfFn6MANy==ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡓࡇ࡙ࡉࡗ࡙ࡏࡠࡖࡕࡅࡓ࡙ࡌࡂࡖࡈ࠱࠶ࡹࡴࠨᅪ"): ff23ICqELcvWaZYm4suDzHnU = TlGXWLYsV1z(u"࠸࠰ᓿ")
	elif VamqUtbfFn6MANy==uuExaKGL7UONtevRd(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡉࡒࡓࡌࡒࡅࡠࡖࡕࡅࡓ࡙ࡌࡂࡖࡈ࠱࠶ࡹࡴࠨᅫ"): ff23ICqELcvWaZYm4suDzHnU = PtkEvXAqif14G20QZsaSyT(u"࠲࠱ᔀ")
	elif PtkEvXAqif14G20QZsaSyT(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡑࡗࡂࡏࠪᅬ") in VamqUtbfFn6MANy: ff23ICqELcvWaZYm4suDzHnU = PtkEvXAqif14G20QZsaSyT(u"࠸࠲ᔁ")
	elif TlGXWLYsV1z(u"ࠩࡖࡌࡔࡌࡈࡂࠩᅭ") in VamqUtbfFn6MANy: ff23ICqELcvWaZYm4suDzHnU = YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"࠹࠸ᔂ")
	elif MgP8OjoaiWQEVG59(u"ࠪࡇࡎࡓࡁ࠵ࡗࠪᅮ") in VamqUtbfFn6MANy: ff23ICqELcvWaZYm4suDzHnU = SaB5hx3PZwXRLtKgrTfQvId(u"࠵࠹ᔃ")
	elif sVzojQerUqX(u"ࠫࡆࡎࡗࡂࡍࠪᅯ") in VamqUtbfFn6MANy: ff23ICqELcvWaZYm4suDzHnU = ZchUJdM93pTA7zG5(u"࠶࠵ᔄ")
	elif xpT28sXu051(u"ࠬࡉࡉࡎࡃࡏࡍࡌࡎࡔࠨᅰ") in VamqUtbfFn6MANy: ff23ICqELcvWaZYm4suDzHnU = ZchUJdM93pTA7zG5(u"࠷࠶ᔅ")
	elif uuExaKGL7UONtevRd(u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡂࡘࡑࡕࡏࠬᅱ") in VamqUtbfFn6MANy: ff23ICqELcvWaZYm4suDzHnU = uuExaKGL7UONtevRd(u"࠹࠰ᔆ")
	elif GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠧࡂࡍࡒࡅࡒ࠭ᅲ") in VamqUtbfFn6MANy: ff23ICqELcvWaZYm4suDzHnU = AbqCJZdWQP9j(u"࠲࠶ᔇ")
	elif zmcGfOdvAjsELeJlP(u"ࠨࡃࡎ࡛ࡆࡓࠧᅳ") in VamqUtbfFn6MANy: ff23ICqELcvWaZYm4suDzHnU = LyNiIHPOwD3hCUYEFM7(u"࠴࠲ᔈ")
	elif tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠩࡉࡅࡘࡋࡌࡉࡆ࠴ࠫᅴ") in VamqUtbfFn6MANy: ff23ICqELcvWaZYm4suDzHnU = zmcGfOdvAjsELeJlP(u"࠴࠳ᔉ")
	elif zmcGfOdvAjsELeJlP(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠷ࠬᅵ") in VamqUtbfFn6MANy: ff23ICqELcvWaZYm4suDzHnU = JZszNnIEMAx28Yao0yqhiXGKOPb(u"࠹࠴ᔊ")
	elif CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠫࡍࡇࡌࡂࡅࡌࡑࡆ࠭ᅶ") in VamqUtbfFn6MANy: ff23ICqELcvWaZYm4suDzHnU = YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"࠸࠵ᔋ")
	else: ff23ICqELcvWaZYm4suDzHnU = TlGXWLYsV1z(u"࠶࠻ᔌ")
	AgTcqs5L3vH2oNVjx = (TeLlsNSmcf7FvU3byDkzWAItq5da4R!=None)
	YPATFajmlo629dOpCiLUzfZGE38Ms = (uuHt2FaeJLp8!=None and SZNw0txeoyrsjiAUn!=JZszNnIEMAx28Yao0yqhiXGKOPb(u"࡙ࠬࡔࡐࡒࠪᅷ"))
	if AgTcqs5L3vH2oNVjx and not amFCNfE3e9j: YYkhEn5xTXLUevzCVNB16mR(MgP8OjoaiWQEVG59(u"࠭สโ฻ํ่ࠥฮั้ๅึ๎ࠥืโๆࠩᅸ"),TeLlsNSmcf7FvU3byDkzWAItq5da4R)
	elif YPATFajmlo629dOpCiLUzfZGE38Ms: YYkhEn5xTXLUevzCVNB16mR(ZchUJdM93pTA7zG5(u"ࠧหใ฼๎้ࠦࡄࡏࡕࠣี็๋ࠧᅹ"),uuHt2FaeJLp8)
	if AgTcqs5L3vH2oNVjx:
		bH3CNaFWIPl7EDjR8gJis6mz = {IpC4qHXRuyNFjzWv(u"ࠣࡪࡷࡸࡵࠨᅺ"):TeLlsNSmcf7FvU3byDkzWAItq5da4R,L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠤ࡫ࡸࡹࡶࡳࠣᅻ"):TeLlsNSmcf7FvU3byDkzWAItq5da4R}
		YYsiRbxEn63AoX = TeLlsNSmcf7FvU3byDkzWAItq5da4R
	else: bH3CNaFWIPl7EDjR8gJis6mz,YYsiRbxEn63AoX = {},iiy37aKq0pCEIOwfcTh61xb4U
	if YPATFajmlo629dOpCiLUzfZGE38Ms:
		import urllib3.util.connection as VT9g2Ghpvoden3HX0YiELNWSlyI
		G9lJnIb1tRHfYxvj6rQePWpD = GGxpi7C41NyAqFgkYUVM2u(VT9g2Ghpvoden3HX0YiELNWSlyI,u9XCDzyOjNi)
	JDQe5TjZA3yi7tzR6Fs0wK,AWhpYHuQqgEKx,tBmM8w7Lqsg9QRVUcOoxbFA1,EYHJXVLGgMSvzCwK,FtTIKrkPBQ7Riwu3hd6,verify = mC1Iuc3BdXv6ZPMeG2aQxDlV,VamqUtbfFn6MANy,bDlzGospmi69Oy1NILPaHMWK8Z3FSw,BF6QAiLUNHh7rKOugaw,BF6QAiLUNHh7rKOugaw,KvXWMwZf438UyOnFBlqPDsiIm1c0L
	if dkWYFLy4E2xJGS6g: FtTIKrkPBQ7Riwu3hd6 = rGPen6cSMHQkAywh8vqI9JXiD2
	if t4gzUilp0mGHjPrvQSAfB3aDI or mC1Iuc3BdXv6ZPMeG2aQxDlV: JDQe5TjZA3yi7tzR6Fs0wK = BF6QAiLUNHh7rKOugaw
	if mm3f1ysFBLekStg4J: tBmM8w7Lqsg9QRVUcOoxbFA1 = MgP8OjoaiWQEVG59(u"ࠪࡔࡔ࡙ࡔࠨᅼ")
	RRLYX967TCPfySDoeF8pV3gANMGWuQ,LXSBswmknoDzdT1hQqlUie = -YYJQyRskpX8jv,SaB5hx3PZwXRLtKgrTfQvId(u"࡚ࠫࡴ࡫࡯ࡱࡺࡲࠥࡋࡲࡳࡱࡵࠫᅽ")
	pWXYBzIa8n7iVxRAmsUfL9cj = BF6QAiLUNHh7rKOugaw
	global EXDGSeAzlq7myvNjJxd4B
	if not EXDGSeAzlq7myvNjJxd4B: EXDGSeAzlq7myvNjJxd4B = QKzCiBOWZus1nSv(PdkZHNBlpg2b7DmX6qRiyVa,ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠬࡪࡩࡤࡶࠪᅾ"),YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩᅿ"),ZchUJdM93pTA7zG5(u"ࠧࡇࡑࡕ࡛ࡆࡘࡄࡔࠩᆀ"))
	lgoZk7dnCDH0IFqiKWVc2e8fR = []
	while eCGwzSrqBmIv not in lgoZk7dnCDH0IFqiKWVc2e8fR and eCGwzSrqBmIv in list(EXDGSeAzlq7myvNjJxd4B.keys()):
		lgoZk7dnCDH0IFqiKWVc2e8fR.append(eCGwzSrqBmIv)
		eCGwzSrqBmIv = EXDGSeAzlq7myvNjJxd4B[eCGwzSrqBmIv]
	import requests as Z4rotfjRx7A8U9Jgy0IaL1KnbTuB5
	for o6oXFxmE1bQC in range(hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"࠿ᔍ")):
		BHNqKd2AXQ6 = rGPen6cSMHQkAywh8vqI9JXiD2
		M5qyIg2dZlm6FxH4tTPV79okNu0bCG = BF6QAiLUNHh7rKOugaw
		try:
			if o6oXFxmE1bQC: AWhpYHuQqgEKx = ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗ࠲࠷ࡳࡵࠩᆁ")
			if amFCNfE3e9j or not AgTcqs5L3vH2oNVjx: ri8uRdOU0kNfq4(sVzojQerUqX(u"ࠩࡕࡉࡖ࡛ࡅࡔࡖࡖࡠࡹࡕࡐࡆࡐࡢ࡙ࡗࡒࠧᆂ"),eCGwzSrqBmIv,EwsmJ67cCYDIlg,rzR9SN7ApZuQhTDWEX3V6ga,AWhpYHuQqgEKx,tBmM8w7Lqsg9QRVUcOoxbFA1)
			try: VVznOTKE7NDIe0HGkg.close()
			except: pass
			O5Pwg3UFyX0k9E = eCGwzSrqBmIv
			VVznOTKE7NDIe0HGkg = Z4rotfjRx7A8U9Jgy0IaL1KnbTuB5.request(tBmM8w7Lqsg9QRVUcOoxbFA1,eCGwzSrqBmIv,data=EwsmJ67cCYDIlg,headers=rzR9SN7ApZuQhTDWEX3V6ga,verify=verify,allow_redirects=JDQe5TjZA3yi7tzR6Fs0wK,timeout=ff23ICqELcvWaZYm4suDzHnU,proxies=bH3CNaFWIPl7EDjR8gJis6mz)
			if IpC4qHXRuyNFjzWv(u"࠳࠱࠲ᔎ")<=VVznOTKE7NDIe0HGkg.status_code<=xpT28sXu051(u"࠴࠻࠼ᔏ"):
				if not EYHJXVLGgMSvzCwK:
					jnblaI3BhGwTevi97NgY = list(VVznOTKE7NDIe0HGkg.headers.keys())
					if xpT28sXu051(u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬᆃ") in jnblaI3BhGwTevi97NgY: eCGwzSrqBmIv = VVznOTKE7NDIe0HGkg.headers[uuExaKGL7UONtevRd(u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭ᆄ")]
					elif xpT28sXu051(u"ࠬࡲ࡯ࡤࡣࡷ࡭ࡴࡴࠧᆅ") in jnblaI3BhGwTevi97NgY: eCGwzSrqBmIv = VVznOTKE7NDIe0HGkg.headers[zmcGfOdvAjsELeJlP(u"࠭࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠨᆆ")]
					else: EYHJXVLGgMSvzCwK = rGPen6cSMHQkAywh8vqI9JXiD2
					if not EYHJXVLGgMSvzCwK: eCGwzSrqBmIv = eCGwzSrqBmIv.encode(hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠧ࡭ࡣࡷ࡭ࡳ࠳࠱ࠨᆇ"),XrTw01KtLzbpoyMf(u"ࠨ࡫ࡪࡲࡴࡸࡥࠨᆈ")).decode(df6QpwGxuJVZr,GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠩ࡬࡫ࡳࡵࡲࡦࠩᆉ"))
					if t4gzUilp0mGHjPrvQSAfB3aDI and VVznOTKE7NDIe0HGkg.status_code==CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"࠵࠳࠻ᔐ"):
						JDQe5TjZA3yi7tzR6Fs0wK = mC1Iuc3BdXv6ZPMeG2aQxDlV
						tBmM8w7Lqsg9QRVUcOoxbFA1 = bDlzGospmi69Oy1NILPaHMWK8Z3FSw
						EYHJXVLGgMSvzCwK = rGPen6cSMHQkAywh8vqI9JXiD2
						CiWJTYvyfpLrt
				if not EYHJXVLGgMSvzCwK or mC1Iuc3BdXv6ZPMeG2aQxDlV:
					if CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠪ࡬ࡹࡺࡰࠨᆊ") not in eCGwzSrqBmIv:
						zJuTb9aZGc2iLe = F82MvyX4ThI6sbnA3efDoVS(O5Pwg3UFyX0k9E,tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠫࡺࡸ࡬ࠨᆋ"))
						eCGwzSrqBmIv = zJuTb9aZGc2iLe+uuExaKGL7UONtevRd(u"ࠬ࠵ࠧᆌ")+eCGwzSrqBmIv.lstrip(JZszNnIEMAx28Yao0yqhiXGKOPb(u"࠭࠯ࠨᆍ"))
				if eCGwzSrqBmIv!=O5Pwg3UFyX0k9E:
					EXDGSeAzlq7myvNjJxd4B[O5Pwg3UFyX0k9E] = eCGwzSrqBmIv
					pWXYBzIa8n7iVxRAmsUfL9cj = rGPen6cSMHQkAywh8vqI9JXiD2
				if not EYHJXVLGgMSvzCwK and mC1Iuc3BdXv6ZPMeG2aQxDlV and not dVeG46wAnrtlpkbNPsvJ9(eCGwzSrqBmIv): CiWJTYvyfpLrt
			elif vODxLKW5Ql6r4Fbm8(u"࠹࠺࠶ᔒ")<=VVznOTKE7NDIe0HGkg.status_code<=yJeq1BjfiO4NFuwIEzxVLK6b9s(u"࠸࠽࠾ᔑ"):
				VVznOTKE7NDIe0HGkg.reason = VVznOTKE7NDIe0HGkg.content
				FtTIKrkPBQ7Riwu3hd6 = rGPen6cSMHQkAywh8vqI9JXiD2
			O5Pwg3UFyX0k9E = VVznOTKE7NDIe0HGkg.url
			RRLYX967TCPfySDoeF8pV3gANMGWuQ = VVznOTKE7NDIe0HGkg.status_code
			LXSBswmknoDzdT1hQqlUie = VVznOTKE7NDIe0HGkg.reason
			VVznOTKE7NDIe0HGkg.raise_for_status()
			M5qyIg2dZlm6FxH4tTPV79okNu0bCG = rGPen6cSMHQkAywh8vqI9JXiD2
		except Z4rotfjRx7A8U9Jgy0IaL1KnbTuB5.exceptions.HTTPError as GklR5ZezV83FJXKnCr6AaT:
			pass
		except Z4rotfjRx7A8U9Jgy0IaL1KnbTuB5.exceptions.Timeout as GklR5ZezV83FJXKnCr6AaT:
			if iELueYz3J1FmxaW7vc: LXSBswmknoDzdT1hQqlUie = str(GklR5ZezV83FJXKnCr6AaT.message).split(ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠧ࠻ࠢࠪᆎ"))[YYJQyRskpX8jv]
			else: LXSBswmknoDzdT1hQqlUie = str(GklR5ZezV83FJXKnCr6AaT).split(hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠨ࠼ࠣࠫᆏ"))[YYJQyRskpX8jv]
		except Z4rotfjRx7A8U9Jgy0IaL1KnbTuB5.exceptions.ConnectionError as GklR5ZezV83FJXKnCr6AaT:
			try: yy2jWo16LdtRQeMXHZpPJO = GklR5ZezV83FJXKnCr6AaT.message[FGTfwsjNrB8DvKSZhLIQAb1JnO]
			except: yy2jWo16LdtRQeMXHZpPJO = str(GklR5ZezV83FJXKnCr6AaT)
			pdu3QP6nANWe40JTcDrZ = dEyT9xhGjolYzLCH7460w3.findall(ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠤ࡟࡟ࡊࡸࡲ࡯ࡱࠣࠬࡡࡪࠫࠪ࡞ࡠࠤ࠭࠴ࠪࡀࠫࠪࠦᆐ"),yy2jWo16LdtRQeMXHZpPJO)
			if not pdu3QP6nANWe40JTcDrZ: pdu3QP6nANWe40JTcDrZ = dEyT9xhGjolYzLCH7460w3.findall(Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠥ࠰ࠥ࡫ࡲࡳࡱࡵࡠ࠭࠮࡜ࡥ࠭ࠬ࠰ࠥ࠭ࠨ࠯ࠬࡂ࠭ࠬࠨᆑ"),yy2jWo16LdtRQeMXHZpPJO)
			if not pdu3QP6nANWe40JTcDrZ:
				KAH6RrqgftTN4ZnlzQUv = dEyT9xhGjolYzLCH7460w3.findall(L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠦ࠿ࠦࠨ࠯ࠬࡂ࠭࠿࠴ࠪࡀࠪ࡟ࡨ࠰࠯࠺ࠣᆒ"),yy2jWo16LdtRQeMXHZpPJO)
				if KAH6RrqgftTN4ZnlzQUv: pdu3QP6nANWe40JTcDrZ = [KAH6RrqgftTN4ZnlzQUv[FGTfwsjNrB8DvKSZhLIQAb1JnO][YYJQyRskpX8jv],KAH6RrqgftTN4ZnlzQUv[FGTfwsjNrB8DvKSZhLIQAb1JnO][FGTfwsjNrB8DvKSZhLIQAb1JnO]]
			if not pdu3QP6nANWe40JTcDrZ: pdu3QP6nANWe40JTcDrZ = dEyT9xhGjolYzLCH7460w3.findall(GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠧࡀࠨ࡝ࡦ࠮࠭࠿ࠦࠨ࠯ࠬࡂ࠭ࠬࠨᆓ"),yy2jWo16LdtRQeMXHZpPJO)
			if not pdu3QP6nANWe40JTcDrZ: pdu3QP6nANWe40JTcDrZ = dEyT9xhGjolYzLCH7460w3.findall(SaB5hx3PZwXRLtKgrTfQvId(u"ࠨࠠࠩ࡞ࡧ࠯࠮ࡣࠠࠩ࠰࠭ࡃ࠮࠭ࠢᆔ"),yy2jWo16LdtRQeMXHZpPJO)
			try: RRLYX967TCPfySDoeF8pV3gANMGWuQ,LXSBswmknoDzdT1hQqlUie = pdu3QP6nANWe40JTcDrZ[FGTfwsjNrB8DvKSZhLIQAb1JnO]
			except: RRLYX967TCPfySDoeF8pV3gANMGWuQ,LXSBswmknoDzdT1hQqlUie = -sVzojQerUqX(u"࠷ᔓ"),yy2jWo16LdtRQeMXHZpPJO
		except Z4rotfjRx7A8U9Jgy0IaL1KnbTuB5.exceptions.RequestException as GklR5ZezV83FJXKnCr6AaT:
			if iELueYz3J1FmxaW7vc: LXSBswmknoDzdT1hQqlUie = GklR5ZezV83FJXKnCr6AaT.message
			else: LXSBswmknoDzdT1hQqlUie = str(GklR5ZezV83FJXKnCr6AaT)
		except:
			BHNqKd2AXQ6 = BF6QAiLUNHh7rKOugaw
			try: RRLYX967TCPfySDoeF8pV3gANMGWuQ = VVznOTKE7NDIe0HGkg.status_code
			except: pass
			try: LXSBswmknoDzdT1hQqlUie = VVznOTKE7NDIe0HGkg.reason
			except: pass
		LXSBswmknoDzdT1hQqlUie = str(LXSBswmknoDzdT1hQqlUie)
		WKquk5EaNr4RzVf(q1rohYuwnfpVZUa98L2CtQzmAcB,hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠧࡐࡒࡈࡒ࡚ࡘࡌࡠࡔࡈࡕ࡚ࡋࡓࡕࡕ࡟ࡸࡗࡋࡓࡑࡑࡑࡗࡊࠦࠠࡄࡱࡧࡩ࠿࡛ࠦࠡࠩᆕ")+str(RRLYX967TCPfySDoeF8pV3gANMGWuQ)+EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠨࠢࡠࠤࠥࠦࡒࡦࡣࡶࡳࡳࡀࠠ࡜ࠢࠪᆖ")+LXSBswmknoDzdT1hQqlUie+hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠩࠣࡡࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫᆗ")+VamqUtbfFn6MANy+ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩᆘ")+smglbwR7x2oM+xpT28sXu051(u"ࠫࠥࡣࠧᆙ"))
		if OYQEkcp7MSKiqPareb01wIR and t4gzUilp0mGHjPrvQSAfB3aDI and BHNqKd2AXQ6 and not FtTIKrkPBQ7Riwu3hd6 and RRLYX967TCPfySDoeF8pV3gANMGWuQ!=IpC4qHXRuyNFjzWv(u"࠸࠰࠱ᔔ"):
			if eCGwzSrqBmIv not in [xU0CngZJ5MPO8kBh7Yu2l3SrQsIDt,I27ogq5n0fudMYjED,vlDF0ck58Cmz3jqOy2UhZMBPt6deQ]: eCGwzSrqBmIv,FtTIKrkPBQ7Riwu3hd6 = xU0CngZJ5MPO8kBh7Yu2l3SrQsIDt,BF6QAiLUNHh7rKOugaw
			elif eCGwzSrqBmIv==xU0CngZJ5MPO8kBh7Yu2l3SrQsIDt: eCGwzSrqBmIv,FtTIKrkPBQ7Riwu3hd6 = I27ogq5n0fudMYjED,BF6QAiLUNHh7rKOugaw
			elif eCGwzSrqBmIv==I27ogq5n0fudMYjED: eCGwzSrqBmIv,FtTIKrkPBQ7Riwu3hd6 = vlDF0ck58Cmz3jqOy2UhZMBPt6deQ,rGPen6cSMHQkAywh8vqI9JXiD2
			continue
		if BHNqKd2AXQ6: break
	if not M5qyIg2dZlm6FxH4tTPV79okNu0bCG and lgoZk7dnCDH0IFqiKWVc2e8fR:
		for url in lgoZk7dnCDH0IFqiKWVc2e8fR:
			if url in list(EXDGSeAzlq7myvNjJxd4B.keys()):
				del EXDGSeAzlq7myvNjJxd4B[url]
				pWXYBzIa8n7iVxRAmsUfL9cj = rGPen6cSMHQkAywh8vqI9JXiD2
	if pWXYBzIa8n7iVxRAmsUfL9cj:
		YMQXP2BGeK86CEb(PdkZHNBlpg2b7DmX6qRiyVa,hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࠨᆚ"),uuExaKGL7UONtevRd(u"࠭ࡆࡐࡔ࡚ࡅࡗࡊࡓࠨᆛ"),EXDGSeAzlq7myvNjJxd4B,Dxc7GChQwZ4kOlKHSbL06agnB)
		EXDGSeAzlq7myvNjJxd4B = {}
	if uuHt2FaeJLp8!=None and SZNw0txeoyrsjiAUn!=ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠧࡔࡖࡒࡔࠬᆜ"): VT9g2Ghpvoden3HX0YiELNWSlyI.create_connection = G9lJnIb1tRHfYxvj6rQePWpD
	if SZNw0txeoyrsjiAUn==y6y5HtgXO4TkUbwVZ(u"ࠨࡃࡏ࡛ࡆ࡟ࡓࠨᆝ") and T2tbsJZ8eQnPIwUjMcLxgvrHpYOyR7: uuHt2FaeJLp8 = None
	if not M5qyIg2dZlm6FxH4tTPV79okNu0bCG and TeLlsNSmcf7FvU3byDkzWAItq5da4R==None and VamqUtbfFn6MANy not in LJCPyc4vO8t3d:
		UIxuCn8wAWpgz5j9EdqFvreH = xiFBCH5hcJks.format_exc()
		if UIxuCn8wAWpgz5j9EdqFvreH!=YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠩࡑࡳࡳ࡫ࡔࡺࡲࡨ࠾ࠥࡔ࡯࡯ࡧ࡟ࡲࠬᆞ"): ytv0YaxDcRINurplWKg587Pwqz.stderr.write(UIxuCn8wAWpgz5j9EdqFvreH)
	xQoYJsjSm0yfdzaOewV7pC = AutiwYdmGMSgL3lXTD()
	if amFCNfE3e9j: O5Pwg3UFyX0k9E = pFDkX1be0ahQtgB5K9o8u2IlRjsJL
	if not O5Pwg3UFyX0k9E: O5Pwg3UFyX0k9E = eCGwzSrqBmIv
	xQoYJsjSm0yfdzaOewV7pC.url = O5Pwg3UFyX0k9E
	xQoYJsjSm0yfdzaOewV7pC.scrape = amFCNfE3e9j
	try: LLRi7nOAEbmvlrWzYVo9XJuaecsjQ = VVznOTKE7NDIe0HGkg.content
	except: LLRi7nOAEbmvlrWzYVo9XJuaecsjQ = iiy37aKq0pCEIOwfcTh61xb4U
	try: GmTJlQcwnYNbOWB2xXt = VVznOTKE7NDIe0HGkg.headers
	except: GmTJlQcwnYNbOWB2xXt = {}
	try: chQ0uPj2xwkmMAG9ByvYerNFC = VVznOTKE7NDIe0HGkg.cookies.get_dict()
	except: chQ0uPj2xwkmMAG9ByvYerNFC = {}
	try: VVznOTKE7NDIe0HGkg.close()
	except: pass
	if J1MoiYc7ZwzKS:
		try: LLRi7nOAEbmvlrWzYVo9XJuaecsjQ = LLRi7nOAEbmvlrWzYVo9XJuaecsjQ.decode(df6QpwGxuJVZr)
		except: pass
	RRLYX967TCPfySDoeF8pV3gANMGWuQ = int(RRLYX967TCPfySDoeF8pV3gANMGWuQ)
	xQoYJsjSm0yfdzaOewV7pC.code = RRLYX967TCPfySDoeF8pV3gANMGWuQ
	xQoYJsjSm0yfdzaOewV7pC.reason = LXSBswmknoDzdT1hQqlUie
	xQoYJsjSm0yfdzaOewV7pC.content = LLRi7nOAEbmvlrWzYVo9XJuaecsjQ
	xQoYJsjSm0yfdzaOewV7pC.headers = GmTJlQcwnYNbOWB2xXt
	xQoYJsjSm0yfdzaOewV7pC.cookies = chQ0uPj2xwkmMAG9ByvYerNFC
	xQoYJsjSm0yfdzaOewV7pC.succeeded = M5qyIg2dZlm6FxH4tTPV79okNu0bCG
	xQoYJsjSm0yfdzaOewV7pC.scrapernumber = iiy37aKq0pCEIOwfcTh61xb4U
	xQoYJsjSm0yfdzaOewV7pC.scraperserver = iiy37aKq0pCEIOwfcTh61xb4U
	xQoYJsjSm0yfdzaOewV7pC.scraperurl = iiy37aKq0pCEIOwfcTh61xb4U
	if iELueYz3J1FmxaW7vc or isinstance(xQoYJsjSm0yfdzaOewV7pC.content,str): XxYo5dZHznvV0u7ycQS = xQoYJsjSm0yfdzaOewV7pC.content.lower()
	else: XxYo5dZHznvV0u7ycQS = iiy37aKq0pCEIOwfcTh61xb4U
	fnhjSYyKULecpm7OAT3sPv9lBQ = (sVzojQerUqX(u"ࠪࡧࡱࡵࡵࡥࡨ࡯ࡥࡷ࡫ࠧᆟ") in XxYo5dZHznvV0u7ycQS or y6y5HtgXO4TkUbwVZ(u"ࠫ࡬ࡵ࡯ࡨ࡮ࡨࠫᆠ") in XxYo5dZHznvV0u7ycQS) and XxYo5dZHznvV0u7ycQS.count(FRYcH4KL7e9gv5pEB(u"ࠬࡸࡥࡤࡣࡳࡸࡨ࡮ࡡࠨᆡ"))>JZszNnIEMAx28Yao0yqhiXGKOPb(u"࠲ᔕ") and EMO8gy4LrsNTh0knZwpSeU75APW(u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠱ࠨᆢ") not in VamqUtbfFn6MANy and hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠧࡳࡧࡦࡥࡵࡺࡣࡩࡣ࠰ࡸࡴࡱࡥ࡯ࠩᆣ") not in XxYo5dZHznvV0u7ycQS and not amFCNfE3e9j
	if RRLYX967TCPfySDoeF8pV3gANMGWuQ==SaB5hx3PZwXRLtKgrTfQvId(u"࠳࠲࠳ᔖ") and fnhjSYyKULecpm7OAT3sPv9lBQ: xQoYJsjSm0yfdzaOewV7pC.succeeded = BF6QAiLUNHh7rKOugaw
	if xQoYJsjSm0yfdzaOewV7pC.succeeded and OYQEkcp7MSKiqPareb01wIR and t4gzUilp0mGHjPrvQSAfB3aDI:
		QihHpX3jKr = XrTw01KtLzbpoyMf(u"ࠨࡅࡄࡔ࡙ࡉࡈࡂࠩᆤ")+EwsmJ67cCYDIlg[TlGXWLYsV1z(u"ࠩ࡭ࡳࡧ࠭ᆥ")].upper().replace(hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠪࡋࡊ࡚ࠧᆦ"),iiy37aKq0pCEIOwfcTh61xb4U) if dkWYFLy4E2xJGS6g else nYj9DlqLkQsmS8xthp
		gE8olLZnXGx0NFrpQ4qvzhya67Djd(QihHpX3jKr)
	if not xQoYJsjSm0yfdzaOewV7pC.succeeded and OYQEkcp7MSKiqPareb01wIR:
		SKeWGI7OUtjY0 = (JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠫࡨࡲ࡯ࡶࡦࡩࡰࡦࡸࡥࠨᆧ") in XxYo5dZHznvV0u7ycQS and L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠬࡸࡡࡺࠢ࡬ࡨ࠿ࠦࠧᆨ") in XxYo5dZHznvV0u7ycQS)
		InX8l1gdKwU5aeiyW0mp = (PtkEvXAqif14G20QZsaSyT(u"࠭࠵ࠡࡵࡨࡧࠬᆩ") in XxYo5dZHznvV0u7ycQS and hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࠨᆪ") in XxYo5dZHznvV0u7ycQS)
		scI1mbRj60 = (RRLYX967TCPfySDoeF8pV3gANMGWuQ in [SaB5hx3PZwXRLtKgrTfQvId(u"࠶࠳࠷ᔗ")] and UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠨࡧࡵࡶࡴࡸࠠࡤࡱࡧࡩ࠿ࠦ࠱࠱࠴࠳ࠫᆫ") in XxYo5dZHznvV0u7ycQS)
		iWeSfQFsJNp7BOmu8ydMKrovaA = (XrTw01KtLzbpoyMf(u"ࠩࡢࡧ࡫ࡥࡣࡩ࡮ࡢࠫᆬ") in XxYo5dZHznvV0u7ycQS and tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠪࡧ࡭ࡧ࡬࡭ࡧࡱ࡫ࡪ࠳ࠧᆭ") in XxYo5dZHznvV0u7ycQS)
		if   fnhjSYyKULecpm7OAT3sPv9lBQ: LXSBswmknoDzdT1hQqlUie = GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠫࡇࡲ࡯ࡤ࡭ࡨࡨࠥࡨࡹࠡࡴࡨࡧࡦࡶࡴࡤࡪࡤࠫᆮ")
		elif SKeWGI7OUtjY0: LXSBswmknoDzdT1hQqlUie = CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠬࡈ࡬ࡰࡥ࡮ࡩࡩࠦࡢࡺࠢࡦࡰࡴࡻࡤࡧ࡮ࡤࡶࡪ࠭ᆯ")
		elif InX8l1gdKwU5aeiyW0mp: LXSBswmknoDzdT1hQqlUie = Y41NvKfOroMzGB8sEHy7wbXlc5(u"࠭ࡂ࡭ࡱࡦ࡯ࡪࡪࠠࡣࡻࠣ࠹ࠥࡹࡥࡤࡱࡱࡨࡸࠦࡢࡳࡱࡺࡷࡪࡸࠠࡤࡪࡨࡧࡰ࠭ᆰ")
		elif scI1mbRj60: LXSBswmknoDzdT1hQqlUie = AbqCJZdWQP9j(u"ࠧࡃ࡮ࡲࡧࡰ࡫ࡤࠡࡤࡼࠤࡨࡲ࡯ࡶࡦࡩࡰࡦࡸࡥࠡࡣࡦࡧࡪࡹࡳࠡࡦࡨࡲ࡮࡫ࡤࠨᆱ")
		elif iWeSfQFsJNp7BOmu8ydMKrovaA: LXSBswmknoDzdT1hQqlUie = tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠨࡄ࡯ࡳࡨࡱࡥࡥࠢࡥࡽࠥࡩ࡬ࡰࡷࡧࡪࡱࡧࡲࡦࠢࡶࡩࡨࡻࡲࡪࡶࡼࠤࡨ࡮ࡥࡤ࡭ࠪᆲ")
		else: LXSBswmknoDzdT1hQqlUie = str(LXSBswmknoDzdT1hQqlUie)
		if VamqUtbfFn6MANy in ITjWNo35aOkfebDQnA: pass
		elif VamqUtbfFn6MANy in LJCPyc4vO8t3d:
			WKquk5EaNr4RzVf(uiza5vIyTWtUeB8sXwAVYMFpgjrk,IIZ4e82HBP0oTmtOgaWY7hsMz(sQU2GnRoMwLK8CBdfzmNr4jXyO)+CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠩࠣࠤࡉ࡯ࡲࡦࡥࡷࠤࡨࡵ࡮࡯ࡧࡦࡸ࡮ࡵ࡮ࠡࡨࡤ࡭ࡱ࡫ࡤࠡࠢࠣࡇࡴࡪࡥ࠻ࠢ࡞ࠤࠬᆳ")+str(RRLYX967TCPfySDoeF8pV3gANMGWuQ)+TlGXWLYsV1z(u"ࠪࠤࡢࠦࠠࠡࡔࡨࡥࡸࡵ࡮࠻ࠢ࡞ࠤࠬᆴ")+LXSBswmknoDzdT1hQqlUie+hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠫࠥࡣࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭ᆵ")+VamqUtbfFn6MANy+y6y5HtgXO4TkUbwVZ(u"ࠬࠦ࡝࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫᆶ")+eCGwzSrqBmIv+tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"࠭ࠠ࡞ࠩᆷ"))
		else: WKquk5EaNr4RzVf(uiza5vIyTWtUeB8sXwAVYMFpgjrk,IIZ4e82HBP0oTmtOgaWY7hsMz(sQU2GnRoMwLK8CBdfzmNr4jXyO)+zmcGfOdvAjsELeJlP(u"ࠧࠡࠢࠣࡈ࡮ࡸࡥࡤࡶࠣࡧࡴࡴ࡮ࡦࡥࡷ࡭ࡴࡴࠠࡧࡣ࡬ࡰࡪࡪࠠࠡࠢࡆࡳࡩ࡫࠺ࠡ࡝ࠣࠫᆸ")+str(RRLYX967TCPfySDoeF8pV3gANMGWuQ)+SaB5hx3PZwXRLtKgrTfQvId(u"ࠨࠢࡠࠤࠥࠦࡒࡦࡣࡶࡳࡳࡀࠠ࡜ࠢࠪᆹ")+LXSBswmknoDzdT1hQqlUie+XrTw01KtLzbpoyMf(u"ࠩࠣࡡࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫᆺ")+VamqUtbfFn6MANy+UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩᆻ")+eCGwzSrqBmIv+LyNiIHPOwD3hCUYEFM7(u"ࠫࠥࡣࠧᆼ"))
		Gef0NYO5SRdpyQ4qkILX = pFDkX1be0ahQtgB5K9o8u2IlRjsJL if amFCNfE3e9j else a9I3YZjc6ySDPE4Kp(eCGwzSrqBmIv)
		if iELueYz3J1FmxaW7vc and isinstance(Gef0NYO5SRdpyQ4qkILX,unicode): Gef0NYO5SRdpyQ4qkILX = Gef0NYO5SRdpyQ4qkILX.encode(df6QpwGxuJVZr)
		if t4gzUilp0mGHjPrvQSAfB3aDI: Gef0NYO5SRdpyQ4qkILX = Gef0NYO5SRdpyQ4qkILX.split(xpT28sXu051(u"ࠬ࠵ࠧᆽ"))[-YYJQyRskpX8jv]
		C5wtEx8dgMaWF2yNXBhvsYzleOPQVL = str(LXSBswmknoDzdT1hQqlUie)+PtkEvXAqif14G20QZsaSyT(u"࠭࡜࡯ࠪࠣࠫᆾ")+Gef0NYO5SRdpyQ4qkILX+L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠧࠡࠫࠪᆿ")
		if RRLYX967TCPfySDoeF8pV3gANMGWuQ in [-YYJQyRskpX8jv,-nI2JK1RfsGWNY3OarEeMQZ] or fnhjSYyKULecpm7OAT3sPv9lBQ or SKeWGI7OUtjY0 or InX8l1gdKwU5aeiyW0mp or scI1mbRj60 or iWeSfQFsJNp7BOmu8ydMKrovaA:
			xQoYJsjSm0yfdzaOewV7pC.code = -iiCWLaJREureAlOkv
			xQoYJsjSm0yfdzaOewV7pC.reason = LXSBswmknoDzdT1hQqlUie
			if WZJQ4PfXSw6yx7I:
				lloDvathpIVNs = FTLpOjS0Ew1YaRy3Q9(bDlzGospmi69Oy1NILPaHMWK8Z3FSw,eCGwzSrqBmIv,EwsmJ67cCYDIlg,rzR9SN7ApZuQhTDWEX3V6ga,mC1Iuc3BdXv6ZPMeG2aQxDlV,bHZ5D6c9pRGfx,VamqUtbfFn6MANy,RRLYX967TCPfySDoeF8pV3gANMGWuQ,LXSBswmknoDzdT1hQqlUie)
				if lloDvathpIVNs.succeeded: return lloDvathpIVNs
		U17QqF2gkI46 = rGPen6cSMHQkAywh8vqI9JXiD2
		if (SZNw0txeoyrsjiAUn==hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠨࡃࡖࡏࠬᇀ") or ULsxfNwT4Akv3cSE8gmrXB6==Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠩࡄࡗࡐ࠭ᇁ")) and (T2tbsJZ8eQnPIwUjMcLxgvrHpYOyR7 or WZJQ4PfXSw6yx7I):
			U17QqF2gkI46 = owBxZQnetHJ0rTyIP3ivq(RRLYX967TCPfySDoeF8pV3gANMGWuQ,C5wtEx8dgMaWF2yNXBhvsYzleOPQVL,VamqUtbfFn6MANy,bHZ5D6c9pRGfx)
			if U17QqF2gkI46 and SZNw0txeoyrsjiAUn==CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠪࡅࡘࡑࠧᇂ"): SZNw0txeoyrsjiAUn = XrTw01KtLzbpoyMf(u"ࠫࡆࡉࡃࡆࡒࡗࡉࡉ࠭ᇃ")
			else: SZNw0txeoyrsjiAUn = LyNiIHPOwD3hCUYEFM7(u"ࠬࡘࡅࡋࡇࡆࡘࡊࡊࠧᇄ")
			if U17QqF2gkI46 and ULsxfNwT4Akv3cSE8gmrXB6==y6y5HtgXO4TkUbwVZ(u"࠭ࡁࡔࡍࠪᇅ"): ULsxfNwT4Akv3cSE8gmrXB6 = yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠧࡂࡅࡆࡉࡕ࡚ࡅࡅࠩᇆ")
			else: ULsxfNwT4Akv3cSE8gmrXB6 = xpT28sXu051(u"ࠨࡔࡈࡎࡊࡉࡔࡆࡆࠪᇇ")
			OXsckY7RzjCag9A.setSetting(FRYcH4KL7e9gv5pEB(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡦࡱࡷࠬᇈ"),SZNw0txeoyrsjiAUn)
			OXsckY7RzjCag9A.setSetting(ZchUJdM93pTA7zG5(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡵࡴࡧࡳࡶࡴࡾࡹࠨᇉ"),ULsxfNwT4Akv3cSE8gmrXB6)
		if U17QqF2gkI46:
			if RRLYX967TCPfySDoeF8pV3gANMGWuQ==vODxLKW5Ql6r4Fbm8(u"࠻ᔘ") and y6y5HtgXO4TkUbwVZ(u"ࠫ࡭ࡺࡴࡱࡵࠪᇊ") in eCGwzSrqBmIv and kPIjYiFwQcg8nbBHsy5zKdxpS:
				if bHZ5D6c9pRGfx: YYkhEn5xTXLUevzCVNB16mR(CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠬะแฺ์็ࠤๆำีࠡึ๊หิฯࠠศๆอุๆ๐ัࠡࡕࡖࡐࠬᇋ"),CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"࠭ไฦื็หาࠦๅีๅ็อࠥอไฦ่อี๋๐สࠨᇌ"),X2cQ5NCPvkMieBW7oASspFjE=uuExaKGL7UONtevRd(u"࠶࠵࠶࠰ᔙ"))
				O5Pwg3UFyX0k9E = eCGwzSrqBmIv+hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠧࡽࡾࡑࡳ࡛࡫ࡲࡪࡨࡼࡗࡘࡒࠧᇍ")
				LohAQRbz2WGpwNmPHJrdcv984S = GJqpByOKiRenb184w0(bDlzGospmi69Oy1NILPaHMWK8Z3FSw,O5Pwg3UFyX0k9E,oRzlSfeE6DY0mFy37NCVxAJW1BwZtM,CZGXVf91e3KTpSDqyP6x8otlhLBam2,Kh6Op2cwaB9,bHZ5D6c9pRGfx,tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗ࠲࠸࡮ࡥࠩᇎ"))
				if LohAQRbz2WGpwNmPHJrdcv984S.succeeded:
					xQoYJsjSm0yfdzaOewV7pC = LohAQRbz2WGpwNmPHJrdcv984S
					WKquk5EaNr4RzVf(P3sqIW4T8rYpjNxOXhcBk2GD,IIZ4e82HBP0oTmtOgaWY7hsMz(sQU2GnRoMwLK8CBdfzmNr4jXyO)+PtkEvXAqif14G20QZsaSyT(u"ࠩࠣࠤ࡙ࠥࡵࡤࡥࡨࡩࡩ࡫ࡤࠡࡷࡶ࡭ࡳ࡭ࠠࡔࡕࡏ࠾ࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫᇏ")+VamqUtbfFn6MANy+L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩᇐ")+smglbwR7x2oM+hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠫࠥࡣࠧᇑ"))
					if bHZ5D6c9pRGfx: YYkhEn5xTXLUevzCVNB16mR(SaB5hx3PZwXRLtKgrTfQvId(u"ࠬ์ฬศฯࠣฬฬูสฯัส้࡙ࠥࡓࡍࠩᇒ"),LyNiIHPOwD3hCUYEFM7(u"࠭ไฦื็หาࠦๅีๅ็อࠥอไฦ่อี๋๐สࠨᇓ"),X2cQ5NCPvkMieBW7oASspFjE=FRYcH4KL7e9gv5pEB(u"࠷࠶࠰࠱ᔚ"))
				else:
					WKquk5EaNr4RzVf(uiza5vIyTWtUeB8sXwAVYMFpgjrk,IIZ4e82HBP0oTmtOgaWY7hsMz(sQU2GnRoMwLK8CBdfzmNr4jXyO)+tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠧࠡࠢࠣࡊࡦ࡯࡬ࡦࡦࠣࡹࡸ࡯࡮ࡨࠢࡖࡗࡑࡀࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭ᇔ")+VamqUtbfFn6MANy+hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧᇕ")+smglbwR7x2oM+IpC4qHXRuyNFjzWv(u"ࠩࠣࡡࠬᇖ"))
					if bHZ5D6c9pRGfx: YYkhEn5xTXLUevzCVNB16mR(hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠪๅู๊ࠠษษึฮำีวๆࠢࡖࡗࡑ࠭ᇗ"),YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"้ࠫหีๅษะࠤฺ๊ใๅหࠣห้หๆหำ้๎ฯ࠭ᇘ"),X2cQ5NCPvkMieBW7oASspFjE=SaB5hx3PZwXRLtKgrTfQvId(u"࠸࠰࠱࠲ᔛ"))
			if not xQoYJsjSm0yfdzaOewV7pC.succeeded and ULsxfNwT4Akv3cSE8gmrXB6 in [IpC4qHXRuyNFjzWv(u"ࠬࡇࡕࡕࡑࠪᇙ"),UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"࠭ࡁࡄࡅࡈࡔ࡙ࡋࡄࠨᇚ")] and WZJQ4PfXSw6yx7I:
				if bHZ5D6c9pRGfx: YYkhEn5xTXLUevzCVNB16mR(ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠧหใ฼๎้ࠦำ๋ำไีฬะࠠษำ๋็ุ๐ࠧᇛ"),FRYcH4KL7e9gv5pEB(u"ࠨๆศู้ออࠡ็ื็้ฯࠠศๆศ๊ฯืๆ๋ฬࠪᇜ"),X2cQ5NCPvkMieBW7oASspFjE=LyNiIHPOwD3hCUYEFM7(u"࠲࠱࠲࠳ᔜ"))
				LohAQRbz2WGpwNmPHJrdcv984S = llbsRvomZYPUBW4c0A6(bDlzGospmi69Oy1NILPaHMWK8Z3FSw,eCGwzSrqBmIv,oRzlSfeE6DY0mFy37NCVxAJW1BwZtM,CZGXVf91e3KTpSDqyP6x8otlhLBam2,Kh6Op2cwaB9,bHZ5D6c9pRGfx,VamqUtbfFn6MANy)
				if LohAQRbz2WGpwNmPHJrdcv984S.succeeded:
					xQoYJsjSm0yfdzaOewV7pC = LohAQRbz2WGpwNmPHJrdcv984S
					WKquk5EaNr4RzVf(P3sqIW4T8rYpjNxOXhcBk2GD,IIZ4e82HBP0oTmtOgaWY7hsMz(sQU2GnRoMwLK8CBdfzmNr4jXyO)+zmcGfOdvAjsELeJlP(u"ࠩࠣࠤࠥࡖࡲࡰࡺ࡬ࡩࡸࠦࡳࡶࡥࡦࡩࡪࡪࡥࡥ࠼ࠣࠤ࡙ࠥ࡯ࡶࡴࡦࡩ࠿࡛ࠦࠡࠩᇝ")+VamqUtbfFn6MANy+zmcGfOdvAjsELeJlP(u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩᇞ")+smglbwR7x2oM+xpT28sXu051(u"ࠫࠥࡣࠧᇟ"))
					if bHZ5D6c9pRGfx: YYkhEn5xTXLUevzCVNB16mR(uuExaKGL7UONtevRd(u"ࠬ์ฬศฯࠣื๏ืแาษอࠤอื่ไีํࠫᇠ"),uuExaKGL7UONtevRd(u"࠭ไฦื็หาࠦๅีๅ็อࠥอไฦ่อี๋๐สࠨᇡ"),X2cQ5NCPvkMieBW7oASspFjE=MgP8OjoaiWQEVG59(u"࠳࠲࠳࠴ᔝ"))
				else:
					WKquk5EaNr4RzVf(uiza5vIyTWtUeB8sXwAVYMFpgjrk,IIZ4e82HBP0oTmtOgaWY7hsMz(sQU2GnRoMwLK8CBdfzmNr4jXyO)+xpT28sXu051(u"ࠧࠡࠢࠣࡔࡷࡵࡸࡪࡧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠾ࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫᇢ")+VamqUtbfFn6MANy+SaB5hx3PZwXRLtKgrTfQvId(u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧᇣ")+smglbwR7x2oM+sVzojQerUqX(u"ࠩࠣࡡࠬᇤ"))
					if bHZ5D6c9pRGfx: YYkhEn5xTXLUevzCVNB16mR(y6y5HtgXO4TkUbwVZ(u"ࠪๅู๊ࠠิ์ิๅึอสࠡสิ์ู่๊ࠨᇥ"),vODxLKW5Ql6r4Fbm8(u"้ࠫหีๅษะࠤฺ๊ใๅหࠣห้หๆหำ้๎ฯ࠭ᇦ"),X2cQ5NCPvkMieBW7oASspFjE=MgP8OjoaiWQEVG59(u"࠴࠳࠴࠵ᔞ"))
			if not xQoYJsjSm0yfdzaOewV7pC.succeeded and SZNw0txeoyrsjiAUn in [y6y5HtgXO4TkUbwVZ(u"ࠬࡇࡕࡕࡑࠪᇧ"),ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"࠭ࡁࡄࡅࡈࡔ࡙ࡋࡄࠨᇨ")] and T2tbsJZ8eQnPIwUjMcLxgvrHpYOyR7:
				if bHZ5D6c9pRGfx: YYkhEn5xTXLUevzCVNB16mR(ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠧหใ฼๎้ࠦำ๋ำไีࠥࡊࡎࡔࠩᇩ"),EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠨๆศู้ออࠡ็ื็้ฯࠠศๆศ๊ฯืๆ๋ฬࠪᇪ"),X2cQ5NCPvkMieBW7oASspFjE=ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"࠵࠴࠵࠶ᔟ"))
				O5Pwg3UFyX0k9E = eCGwzSrqBmIv+GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠩࡿࢀࡒࡿࡄࡏࡕࡘࡶࡱࡃࠧᇫ")
				LohAQRbz2WGpwNmPHJrdcv984S = GJqpByOKiRenb184w0(bDlzGospmi69Oy1NILPaHMWK8Z3FSw,O5Pwg3UFyX0k9E,oRzlSfeE6DY0mFy37NCVxAJW1BwZtM,CZGXVf91e3KTpSDqyP6x8otlhLBam2,Kh6Op2cwaB9,bHZ5D6c9pRGfx,tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤࡘࡅࡒࡗࡈࡗ࡙࡙࠭࠵ࡶ࡫ࠫᇬ"))
				if LohAQRbz2WGpwNmPHJrdcv984S.succeeded:
					xQoYJsjSm0yfdzaOewV7pC = LohAQRbz2WGpwNmPHJrdcv984S
					WKquk5EaNr4RzVf(P3sqIW4T8rYpjNxOXhcBk2GD,IIZ4e82HBP0oTmtOgaWY7hsMz(sQU2GnRoMwLK8CBdfzmNr4jXyO)+YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠫࠥࠦࠠࡅࡐࡖࠤࡸࡻࡣࡤࡧࡨࡨࡪࡪ࠺ࠡࠢࠣࡈࡓ࡙࠺ࠡ࡝ࠣࠫᇭ")+u9XCDzyOjNi+HtK4o2sTPgA78U(u"ࠬࠦ࡝ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧᇮ")+VamqUtbfFn6MANy+PtkEvXAqif14G20QZsaSyT(u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬᇯ")+smglbwR7x2oM+L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠧࠡ࡟ࠪᇰ"))
					if bHZ5D6c9pRGfx: YYkhEn5xTXLUevzCVNB16mR(GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠨ่ฯหาࠦำ๋ำไีࠥࡊࡎࡔࠩᇱ"),CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠩ็ษฺ๊วฮุ่่๊ࠢษࠡษ็ษ๋ะั็์อࠫᇲ"),X2cQ5NCPvkMieBW7oASspFjE=CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"࠶࠵࠶࠰ᔠ"))
				else:
					WKquk5EaNr4RzVf(uiza5vIyTWtUeB8sXwAVYMFpgjrk,IIZ4e82HBP0oTmtOgaWY7hsMz(sQU2GnRoMwLK8CBdfzmNr4jXyO)+uuExaKGL7UONtevRd(u"ࠪࠤࠥࠦࡄࡏࡕࠣࡪࡦ࡯࡬ࡦࡦ࠽ࠤࠥࠦࡄࡏࡕ࠽ࠤࡠࠦࠧᇳ")+u9XCDzyOjNi+LyNiIHPOwD3hCUYEFM7(u"ࠫࠥࡣࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭ᇴ")+VamqUtbfFn6MANy+tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠬࠦ࡝࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫᇵ")+smglbwR7x2oM+YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"࠭ࠠ࡞ࠩᇶ"))
					if bHZ5D6c9pRGfx: YYkhEn5xTXLUevzCVNB16mR(CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠧโึ็ࠤุ๐ัโำࠣࡈࡓ࡙ࠧᇷ"),PtkEvXAqif14G20QZsaSyT(u"ࠨๆศู้ออࠡ็ื็้ฯࠠศๆศ๊ฯืๆ๋ฬࠪᇸ"),X2cQ5NCPvkMieBW7oASspFjE=tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"࠷࠶࠰࠱ᔡ"))
		if ULsxfNwT4Akv3cSE8gmrXB6==zmcGfOdvAjsELeJlP(u"ࠩࡕࡉࡏࡋࡃࡕࡇࡇࠫᇹ") or SZNw0txeoyrsjiAUn==XrTw01KtLzbpoyMf(u"ࠪࡖࡊࡐࡅࡄࡖࡈࡈࠬᇺ"): bHZ5D6c9pRGfx = BF6QAiLUNHh7rKOugaw
		if not xQoYJsjSm0yfdzaOewV7pC.succeeded:
			if bHZ5D6c9pRGfx: gI80r9PwlyQ3HOkFjRYWG = owBxZQnetHJ0rTyIP3ivq(RRLYX967TCPfySDoeF8pV3gANMGWuQ,C5wtEx8dgMaWF2yNXBhvsYzleOPQVL,VamqUtbfFn6MANy,bHZ5D6c9pRGfx)
			if RRLYX967TCPfySDoeF8pV3gANMGWuQ!=EMO8gy4LrsNTh0knZwpSeU75APW(u"࠸࠰࠱ᔢ") and VamqUtbfFn6MANy not in E1BmkjY4ruH0SzlcoTdCPbD3vQ and GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࠨᇻ") not in VamqUtbfFn6MANy: qAXLJHy4FBEhc5aem7wPul()
	if OXsckY7RzjCag9A.getSetting(SaB5hx3PZwXRLtKgrTfQvId(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡷࡶࡩࡩࡴࡳࠨᇼ")) not in [PtkEvXAqif14G20QZsaSyT(u"࠭ࡁࡖࡖࡒࠫᇽ"),GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠧࡔࡖࡒࡔࠬᇾ"),EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠨࡃࡖࡏࠬᇿ")]: OXsckY7RzjCag9A.setSetting(ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡦࡱࡷࠬሀ"),hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠪࡅࡘࡑࠧሁ"))
	if OXsckY7RzjCag9A.getSetting(Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡵࡨࡴࡷࡵࡸࡺࠩሂ")) not in [xpT28sXu051(u"ࠬࡇࡕࡕࡑࠪሃ"),FRYcH4KL7e9gv5pEB(u"࠭ࡓࡕࡑࡓࠫሄ"),tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠧࡂࡕࡎࠫህ")]: OXsckY7RzjCag9A.setSetting(Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡺࡹࡥࡱࡴࡲࡼࡾ࠭ሆ"),HtK4o2sTPgA78U(u"ࠩࡄࡗࡐ࠭ሇ"))
	return xQoYJsjSm0yfdzaOewV7pC
def mtMp5GAHcQsBNLJovRg1r3KVdqjn(website,HHm6yoEO7v4GBWqpcrQgJUiaw,HHA39MlzJfWajViorZ=None):
	XqOGU7za2rTn0HF1b9cl6P = ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"࠱࠱ᔣ")
	BzLH9g4xyvbi5nSt7wl31PGf8EFM = [ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"࠲ᔤ"),ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"࠲ᔤ"),ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"࠲ᔤ"),L90uqo28xEKSFUwYTcm51yRWZIkft(u"࠳࠳ᔥ"),L90uqo28xEKSFUwYTcm51yRWZIkft(u"࠸ᔦ"),L90uqo28xEKSFUwYTcm51yRWZIkft(u"࠳࠳ᔥ"),ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"࠲ᔤ"),ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"࠲ᔤ"),ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"࠲ᔤ"),L90uqo28xEKSFUwYTcm51yRWZIkft(u"࠸ᔦ")]
	XYt1D3zsTlcHxG9R = eeA3KYiN75JumQrEIdZw4XVp
	ymHol4ki5d7NxJpF2bTrQRK = []
	S693LIndobOuFkrgCZGeYqD47xKz = [y6y5HtgXO4TkUbwVZ(u"࠴ᔧ")]*XqOGU7za2rTn0HF1b9cl6P
	ttswzc21T0PV7C8LH9RMKb = QKzCiBOWZus1nSv(PdkZHNBlpg2b7DmX6qRiyVa,hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠪࡨ࡮ࡩࡴࠨለ"),hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠫࡘࡉࡒࡂࡒࡈࡖࡘࡥࡓࡕࡃࡗ࡙ࡘ࠭ሉ"))
	for mulJoyxhNV8 in list(ttswzc21T0PV7C8LH9RMKb.keys()):
		if website not in mulJoyxhNV8: continue
		ekEOd3mqAThaBDUoIrntuGRjYW,DOVnwCNdGiBFP7MZ = mulJoyxhNV8.split(yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠬࡥ࡟ࠨሊ"))
		S693LIndobOuFkrgCZGeYqD47xKz[int(DOVnwCNdGiBFP7MZ)] = ttswzc21T0PV7C8LH9RMKb[mulJoyxhNV8]
	for ba3If2JElOq0nNPWBkXC6dH in range(XqOGU7za2rTn0HF1b9cl6P):
		if ba3If2JElOq0nNPWBkXC6dH in XYt1D3zsTlcHxG9R+HHm6yoEO7v4GBWqpcrQgJUiaw: continue
		if ba3If2JElOq0nNPWBkXC6dH==HHA39MlzJfWajViorZ: S693LIndobOuFkrgCZGeYqD47xKz[ba3If2JElOq0nNPWBkXC6dH] = S693LIndobOuFkrgCZGeYqD47xKz[ba3If2JElOq0nNPWBkXC6dH]+hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"࠶ᔨ")
		if S693LIndobOuFkrgCZGeYqD47xKz[ba3If2JElOq0nNPWBkXC6dH]<ZchUJdM93pTA7zG5(u"࠹ᔩ"): ymHol4ki5d7NxJpF2bTrQRK += [ba3If2JElOq0nNPWBkXC6dH]*BzLH9g4xyvbi5nSt7wl31PGf8EFM[ba3If2JElOq0nNPWBkXC6dH]
	if not ymHol4ki5d7NxJpF2bTrQRK:
		for ba3If2JElOq0nNPWBkXC6dH in range(XqOGU7za2rTn0HF1b9cl6P):
			S693LIndobOuFkrgCZGeYqD47xKz[ba3If2JElOq0nNPWBkXC6dH] = hhQwbeiNLoqFjX90fB7aG8VAs(u"࠰ᔪ")
			if ba3If2JElOq0nNPWBkXC6dH in XYt1D3zsTlcHxG9R+HHm6yoEO7v4GBWqpcrQgJUiaw: continue
			ymHol4ki5d7NxJpF2bTrQRK += [ba3If2JElOq0nNPWBkXC6dH]*BzLH9g4xyvbi5nSt7wl31PGf8EFM[ba3If2JElOq0nNPWBkXC6dH]
	for ba3If2JElOq0nNPWBkXC6dH in XYt1D3zsTlcHxG9R: S693LIndobOuFkrgCZGeYqD47xKz[ba3If2JElOq0nNPWBkXC6dH] = UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"࠺࠻࠼࠽ᔫ")
	hKeJEaMuUCd5LlAgvGb = []
	for ba3If2JElOq0nNPWBkXC6dH in range(XqOGU7za2rTn0HF1b9cl6P): hKeJEaMuUCd5LlAgvGb.append(website+SaB5hx3PZwXRLtKgrTfQvId(u"࠭࡟ࡠࠩላ")+str(ba3If2JElOq0nNPWBkXC6dH))
	YMQXP2BGeK86CEb(PdkZHNBlpg2b7DmX6qRiyVa,tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠧࡔࡅࡕࡅࡕࡋࡒࡔࡡࡖࡘࡆ࡚ࡕࡔࠩሌ"),hKeJEaMuUCd5LlAgvGb,S693LIndobOuFkrgCZGeYqD47xKz,v62Tn4AXCdINlFGDW0*ZchUJdM93pTA7zG5(u"࠷ᔬ"),rGPen6cSMHQkAywh8vqI9JXiD2)
	return ymHol4ki5d7NxJpF2bTrQRK
def FTLpOjS0Ew1YaRy3Q9(bDlzGospmi69Oy1NILPaHMWK8Z3FSw,eCGwzSrqBmIv,EwsmJ67cCYDIlg,rzR9SN7ApZuQhTDWEX3V6ga,mC1Iuc3BdXv6ZPMeG2aQxDlV,bHZ5D6c9pRGfx,VamqUtbfFn6MANy,RRLYX967TCPfySDoeF8pV3gANMGWuQ,LXSBswmknoDzdT1hQqlUie,HHm6yoEO7v4GBWqpcrQgJUiaw=[]):
	YYkhEn5xTXLUevzCVNB16mR(EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠨสาวฯูࠦๆๆํอࠥะฬศ๊ีࠤฬ๊ออสࠪል"),iiy37aKq0pCEIOwfcTh61xb4U,X2cQ5NCPvkMieBW7oASspFjE=tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"࠺࠹࠵ᔭ"))
	WKquk5EaNr4RzVf(P3sqIW4T8rYpjNxOXhcBk2GD,IIZ4e82HBP0oTmtOgaWY7hsMz(sQU2GnRoMwLK8CBdfzmNr4jXyO)+zmcGfOdvAjsELeJlP(u"ࠩࠣࠤ࡚ࠥࡲࡺ࡫ࡱ࡫ࠥࡨࡹࡱࡣࡶࡷࠥࡨ࡬ࡰࡥ࡮࡭ࡳ࡭ࠠࠡࠢࡆࡳࡩ࡫࠺ࠡ࡝ࠣࠫሎ")+str(RRLYX967TCPfySDoeF8pV3gANMGWuQ)+PtkEvXAqif14G20QZsaSyT(u"ࠪࠤࡢࠦࠠࡓࡧࡤࡷࡴࡴ࠺ࠡ࡝ࠣࠫሏ")+LXSBswmknoDzdT1hQqlUie+IpC4qHXRuyNFjzWv(u"ࠫࠥࡣࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭ሐ")+VamqUtbfFn6MANy+ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠬࠦ࡝ࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪሑ")+eCGwzSrqBmIv+ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"࠭ࠠ࡞ࠩሒ"))
	website = VamqUtbfFn6MANy.split(PtkEvXAqif14G20QZsaSyT(u"ࠧ࠮ࠩሓ"))[FGTfwsjNrB8DvKSZhLIQAb1JnO]
	YiRtHb1SsT = mtMp5GAHcQsBNLJovRg1r3KVdqjn(website,HHm6yoEO7v4GBWqpcrQgJUiaw)
	sVKiT85bQpO2N9HAgZxELrfcB0SeG = []
	if website==GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠨࡈࡄࡗࡊࡒࡈࡅ࠳ࠪሔ"):
		if FGTfwsjNrB8DvKSZhLIQAb1JnO in YiRtHb1SsT: sVKiT85bQpO2N9HAgZxELrfcB0SeG += [FGTfwsjNrB8DvKSZhLIQAb1JnO]
		if YYJQyRskpX8jv in YiRtHb1SsT: sVKiT85bQpO2N9HAgZxELrfcB0SeG += [YYJQyRskpX8jv]
		if nI2JK1RfsGWNY3OarEeMQZ in YiRtHb1SsT: sVKiT85bQpO2N9HAgZxELrfcB0SeG += [nI2JK1RfsGWNY3OarEeMQZ]
		if iiCWLaJREureAlOkv in YiRtHb1SsT: sVKiT85bQpO2N9HAgZxELrfcB0SeG += [iiCWLaJREureAlOkv]*ZchUJdM93pTA7zG5(u"࠵࠵ᔮ")
		if pZWli1xqfVtvzuSU6ImNw53gBFsh in YiRtHb1SsT: sVKiT85bQpO2N9HAgZxELrfcB0SeG += [pZWli1xqfVtvzuSU6ImNw53gBFsh]*YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"࠺ᔯ")
		if hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"࠵ᔱ") in YiRtHb1SsT: sVKiT85bQpO2N9HAgZxELrfcB0SeG += [hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"࠵ᔱ")]*HtK4o2sTPgA78U(u"࠷࠰ᔰ")
		if IpC4qHXRuyNFjzWv(u"࠷ᔲ") in YiRtHb1SsT: sVKiT85bQpO2N9HAgZxELrfcB0SeG += [IpC4qHXRuyNFjzWv(u"࠷ᔲ")]
		if jXE2YHkswT8y(u"࠹ᔳ") in YiRtHb1SsT: sVKiT85bQpO2N9HAgZxELrfcB0SeG += [jXE2YHkswT8y(u"࠹ᔳ")]
	elif website==FRYcH4KL7e9gv5pEB(u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘࠫሕ"):
		if iiCWLaJREureAlOkv in YiRtHb1SsT: sVKiT85bQpO2N9HAgZxELrfcB0SeG += [iiCWLaJREureAlOkv]*sVzojQerUqX(u"࠴࠴ᔴ")
	elif website==Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠪࡇࡎࡓࡁࡘࡄࡄࡗࠬሖ"):
		if YYJQyRskpX8jv in YiRtHb1SsT: sVKiT85bQpO2N9HAgZxELrfcB0SeG += [YYJQyRskpX8jv]
		if pZWli1xqfVtvzuSU6ImNw53gBFsh in YiRtHb1SsT: sVKiT85bQpO2N9HAgZxELrfcB0SeG += [pZWli1xqfVtvzuSU6ImNw53gBFsh]*HtK4o2sTPgA78U(u"࠹ᔵ")
		if YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"࠻ᔷ") in YiRtHb1SsT: sVKiT85bQpO2N9HAgZxELrfcB0SeG += [YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"࠻ᔷ")]*tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"࠶࠶ᔶ")
		if LyNiIHPOwD3hCUYEFM7(u"࠶ᔸ") in YiRtHb1SsT: sVKiT85bQpO2N9HAgZxELrfcB0SeG += [LyNiIHPOwD3hCUYEFM7(u"࠶ᔸ")]
		if CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"࠸ᔹ") in YiRtHb1SsT: sVKiT85bQpO2N9HAgZxELrfcB0SeG += [CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"࠸ᔹ")]
	elif website==y6y5HtgXO4TkUbwVZ(u"ࠫࡈࡏࡍࡂࡎࡌࡋࡍ࡚ࠧሗ"):
		if pZWli1xqfVtvzuSU6ImNw53gBFsh in YiRtHb1SsT: sVKiT85bQpO2N9HAgZxELrfcB0SeG += [pZWli1xqfVtvzuSU6ImNw53gBFsh]*vODxLKW5Ql6r4Fbm8(u"࠷ᔺ")
		if GGx4qyKP1vUtRghsE2WfaHLMXZ(u"࠹ᔼ") in YiRtHb1SsT: sVKiT85bQpO2N9HAgZxELrfcB0SeG += [GGx4qyKP1vUtRghsE2WfaHLMXZ(u"࠹ᔼ")]*XrTw01KtLzbpoyMf(u"࠴࠴ᔻ")
	elif website==tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠬ࡝ࡅࡄࡋࡐࡅ࠶࠭መ"):
		if MgP8OjoaiWQEVG59(u"࠾ᔽ") in YiRtHb1SsT: sVKiT85bQpO2N9HAgZxELrfcB0SeG += [MgP8OjoaiWQEVG59(u"࠾ᔽ")]*GGx4qyKP1vUtRghsE2WfaHLMXZ(u"࠻ᔾ")
	if sVKiT85bQpO2N9HAgZxELrfcB0SeG: YiRtHb1SsT = sVKiT85bQpO2N9HAgZxELrfcB0SeG
	if YiRtHb1SsT:
		KB5xuz42bO96 = ufTX72hK8Q63jSsJiqDm5.sample(YiRtHb1SsT,YYJQyRskpX8jv)[FGTfwsjNrB8DvKSZhLIQAb1JnO]
	else: KB5xuz42bO96 = -YYJQyRskpX8jv
	update = rGPen6cSMHQkAywh8vqI9JXiD2
	if KB5xuz42bO96==FGTfwsjNrB8DvKSZhLIQAb1JnO:
		scraperserver = SaB5hx3PZwXRLtKgrTfQvId(u"࠭ࡳࡤࡴࡤࡴࡪࡵࡰࡴ࠳ࠪሙ")
		frAqnQyu0HbkmCXVlISLFT3Kv = tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡴࡥࡵࡥࡵ࡫࡯ࡱࡵ࠱࡯ࡪ࡫ࡰࡠࡪࡨࡥࡩ࡫ࡲࡴ࠿ࡗࡶࡺ࡫࠮ࡤࡱࡸࡲࡹࡸࡹ࠾࡫࡯࠾࠶࠻࠰ࡥ࠴࠵ࡪ࠶࠳ࡣ࠶࠺ࡤ࠱࠹࠶࠲࠲࠯ࡤࡥ࠽࠺࠭ࡦ࠻࠵࠷ࡨࡧࡦ࠹࠷࠻࠷࠹ࡆࡰࡳࡱࡻࡽ࠳ࡹࡣࡳࡣࡳࡩࡴࡶࡳ࠯࡫ࡲ࠾࠺࠹࠵࠴ࠩሚ")
		x93j25L6Agtsyfkh7 = eCGwzSrqBmIv+LyNiIHPOwD3hCUYEFM7(u"ࠨࡾࡿࡑࡾࡖࡲࡰࡺࡼ࡙ࡷࡲ࠽ࠨማ")+frAqnQyu0HbkmCXVlISLFT3Kv+y6y5HtgXO4TkUbwVZ(u"ࠩࡿࢀࡓࡵࡖࡦࡴ࡬ࡪࡾ࡙ࡓࡍࠩሜ")
		lloDvathpIVNs = GJqpByOKiRenb184w0(bDlzGospmi69Oy1NILPaHMWK8Z3FSw,x93j25L6Agtsyfkh7,EwsmJ67cCYDIlg,rzR9SN7ApZuQhTDWEX3V6ga,mC1Iuc3BdXv6ZPMeG2aQxDlV,bHZ5D6c9pRGfx,VamqUtbfFn6MANy,BF6QAiLUNHh7rKOugaw,BF6QAiLUNHh7rKOugaw)
	elif KB5xuz42bO96==YYJQyRskpX8jv:
		scraperserver = UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠪࡷࡨࡸࡡࡱࡧࡲࡴࡸ࠸ࠧም")
		frAqnQyu0HbkmCXVlISLFT3Kv = XrTw01KtLzbpoyMf(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡸࡩࡲࡢࡲࡨࡳࡵࡹ࠮࡬ࡧࡨࡴࡤ࡮ࡥࡢࡦࡨࡶࡸࡃࡔࡳࡷࡨ࠲ࡨࡵࡵ࡯ࡶࡵࡽࡂ࡯࡬࠻࠵࠼࠽࠶࡫࠹ࡤ࠷࠰࠻ࡪ࡫࠳࠮࠶ࡨࡩ࠷࠳࠸࠵ࡥ࠳࠱࡫ࡪ࠷࠺࠴ࡥࡥࡩࡪ࠳ࡥ࠷ࡃࡴࡷࡵࡸࡺ࠰ࡶࡧࡷࡧࡰࡦࡱࡳࡷ࠳࡯࡯࠻࠷࠶࠹࠸࠭ሞ")
		x93j25L6Agtsyfkh7 = eCGwzSrqBmIv+FRYcH4KL7e9gv5pEB(u"ࠬࢂࡼࡎࡻࡓࡶࡴࡾࡹࡖࡴ࡯ࡁࠬሟ")+frAqnQyu0HbkmCXVlISLFT3Kv+MgP8OjoaiWQEVG59(u"࠭ࡼࡽࡐࡲ࡚ࡪࡸࡩࡧࡻࡖࡗࡑ࠭ሠ")
		lloDvathpIVNs = GJqpByOKiRenb184w0(bDlzGospmi69Oy1NILPaHMWK8Z3FSw,x93j25L6Agtsyfkh7,EwsmJ67cCYDIlg,rzR9SN7ApZuQhTDWEX3V6ga,mC1Iuc3BdXv6ZPMeG2aQxDlV,bHZ5D6c9pRGfx,VamqUtbfFn6MANy,BF6QAiLUNHh7rKOugaw,BF6QAiLUNHh7rKOugaw)
	elif KB5xuz42bO96==nI2JK1RfsGWNY3OarEeMQZ:
		scraperserver = JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠧࡴࡥࡵࡥࡵ࡫ࡲࡢࡲ࡬ࠫሡ")
		frAqnQyu0HbkmCXVlISLFT3Kv = CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡵࡦࡶࡦࡶࡥࡳࡣࡳ࡭࠳ࡱࡥࡦࡲࡢ࡬ࡪࡧࡤࡦࡴࡶࡁ࡙ࡸࡵࡦ࠰ࡦࡳࡺࡴࡴࡳࡻࡢࡧࡴࡪࡥ࠾࡫࡯࠾࠼࠼ࡢ࠵ࡨࡦ࠷࠹࡬ࡣࡥ࠳࠼ࡨ࠾ࡩ࠵࠶ࡣ࠴࠹࡫࠹࠶࠱࠶ࡦࡨ࠾࠷࠴ࡤࡂࡳࡶࡴࡾࡹ࠮ࡵࡨࡶࡻ࡫ࡲ࠯ࡵࡦࡶࡦࡶࡥࡳࡣࡳ࡭࠳ࡩ࡯࡮࠼࠻࠴࠵࠷ࠧሢ")
		x93j25L6Agtsyfkh7 = eCGwzSrqBmIv+hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠩࡿࢀࡒࡿࡐࡳࡱࡻࡽ࡚ࡸ࡬࠾ࠩሣ")+frAqnQyu0HbkmCXVlISLFT3Kv+sVzojQerUqX(u"ࠪࢀࢁࡔ࡯ࡗࡧࡵ࡭࡫ࡿࡓࡔࡎࠪሤ")
		lloDvathpIVNs = GJqpByOKiRenb184w0(bDlzGospmi69Oy1NILPaHMWK8Z3FSw,x93j25L6Agtsyfkh7,EwsmJ67cCYDIlg,rzR9SN7ApZuQhTDWEX3V6ga,mC1Iuc3BdXv6ZPMeG2aQxDlV,bHZ5D6c9pRGfx,VamqUtbfFn6MANy,BF6QAiLUNHh7rKOugaw,BF6QAiLUNHh7rKOugaw)
	elif KB5xuz42bO96==iiCWLaJREureAlOkv:
		scraperserver = EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠫࡸࡩࡲࡢࡲࡨࡹࡵ࠭ሥ")
		O5Pwg3UFyX0k9E = eCGwzSrqBmIv.replace(hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࠧሦ"),LyNiIHPOwD3hCUYEFM7(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࠧሧ"))
		x93j25L6Agtsyfkh7 = ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡢࡲ࡬࠲ࡸࡩࡲࡢࡲࡨࡹࡵ࠴ࡣࡰ࡯࠲ࡃࡦࡶࡩࡠ࡭ࡨࡽࡂ࠷ࡖࡏࡵࡐࡸࡑ࠷࡯ࡃࡔ࡛࡯ࡘࡔࡃࡣࡅࡐࡎ࠶ࡑࡘ࡚ࡌ࡭࡮࠵ࡪࡪ࡛ࡹࠩ࡯ࡪ࡫ࡰࡠࡪࡨࡥࡩ࡫ࡲࡴ࠿ࡉࡥࡱࡹࡥࠧࡥࡲࡹࡳࡺࡲࡺࡡࡦࡳࡩ࡫࠽ࡪ࡮ࠩࡹࡷࡲ࠽ࠨረ")+YqdaDIig21wBTWJeUHbc(O5Pwg3UFyX0k9E)
		lloDvathpIVNs = GJqpByOKiRenb184w0(ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠨࡉࡈࡘࠬሩ"),x93j25L6Agtsyfkh7,EwsmJ67cCYDIlg,rzR9SN7ApZuQhTDWEX3V6ga,mC1Iuc3BdXv6ZPMeG2aQxDlV,bHZ5D6c9pRGfx,VamqUtbfFn6MANy,BF6QAiLUNHh7rKOugaw,BF6QAiLUNHh7rKOugaw)
	elif KB5xuz42bO96==pZWli1xqfVtvzuSU6ImNw53gBFsh:
		scraperserver = hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠩࡶࡧࡷࡧࡰࡪࡰࡪࡶࡴࡨ࡯ࡵࠩሪ")
		x93j25L6Agtsyfkh7 = ZchUJdM93pTA7zG5(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡥࡵ࡯࠮ࡴࡥࡵࡥࡵ࡯࡮ࡨࡴࡲࡦࡴࡺ࠮ࡤࡱࡰ࠳ࡄࡺ࡯࡬ࡧࡱࡁࡦ࠺ࡦ࠸ࡨࡥ࠵࠹࠳࠲ࡥࡧࡩ࠱࠹࠶࠷࠲࠯࠻࠺࠹ࡨ࠭࠳࠴ࡨ࠷࠷࠼࠴ࡥ࠶ࡧࡨࡨࠬࡰࡳࡱࡻࡽࡈࡵࡵ࡯ࡶࡵࡽࡂࡏࡌࠧࡷࡵࡰࡂ࠭ራ")+YqdaDIig21wBTWJeUHbc(eCGwzSrqBmIv)
		lloDvathpIVNs = GJqpByOKiRenb184w0(GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠫࡌࡋࡔࠨሬ"),x93j25L6Agtsyfkh7,EwsmJ67cCYDIlg,rzR9SN7ApZuQhTDWEX3V6ga,mC1Iuc3BdXv6ZPMeG2aQxDlV,bHZ5D6c9pRGfx,VamqUtbfFn6MANy,BF6QAiLUNHh7rKOugaw,BF6QAiLUNHh7rKOugaw)
		try:
			lloDvathpIVNs.content = DeIL3qoa2UBtYPb(HtK4o2sTPgA78U(u"ࠬࡪࡩࡤࡶࠪር"),lloDvathpIVNs.content)
			lloDvathpIVNs.content = lloDvathpIVNs.content[hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"࠭ࡲࡦࡵࡸࡰࡹ࠭ሮ")]
		except: pass
	elif KB5xuz42bO96==hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"࠵ᔿ"):
		scraperserver = AbqCJZdWQP9j(u"ࠧࡴࡥࡵࡥࡵ࡯࡮ࡨࡣࡱࡸ࠶࠭ሯ")
		frAqnQyu0HbkmCXVlISLFT3Kv = GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡵࡦࡶࡦࡶࡩ࡯ࡩࡤࡲࡹࠬࡰࡳࡱࡻࡽࡤࡩ࡯ࡶࡰࡷࡶࡾࡃࡉࡍࠨࡥࡶࡴࡽࡳࡦࡴࡀࡊࡦࡲࡳࡦࠨࡩࡳࡷࡽࡡࡳࡦࡢ࡬ࡪࡧࡤࡦࡴࡶࡁ࡙ࡸࡵࡦ࠼࠵ࡦ࠸࠺࠰ࡢ࠸࠻࠽࠵ࡧ࠵࠵࠲࠴ࡨࡧࡩ࠳࠸࠴ࡦ࠵࠶࠺࠵ࡥ࠻࠹࠶ࡪ࠾ࡀࡱࡴࡲࡼࡾ࠴ࡳࡤࡴࡤࡴ࡮ࡴࡧࡢࡰࡷ࠲ࡨࡵ࡭࠻࠺࠳࠼࠵࠭ሰ")
		x93j25L6Agtsyfkh7 = eCGwzSrqBmIv+vODxLKW5Ql6r4Fbm8(u"ࠩࡿࢀࡒࡿࡐࡳࡱࡻࡽ࡚ࡸ࡬࠾ࠩሱ")+frAqnQyu0HbkmCXVlISLFT3Kv+HtK4o2sTPgA78U(u"ࠪࢀࢁࡔ࡯ࡗࡧࡵ࡭࡫ࡿࡓࡔࡎࠪሲ")
		lloDvathpIVNs = GJqpByOKiRenb184w0(bDlzGospmi69Oy1NILPaHMWK8Z3FSw,x93j25L6Agtsyfkh7,EwsmJ67cCYDIlg,rzR9SN7ApZuQhTDWEX3V6ga,mC1Iuc3BdXv6ZPMeG2aQxDlV,bHZ5D6c9pRGfx,VamqUtbfFn6MANy,BF6QAiLUNHh7rKOugaw,BF6QAiLUNHh7rKOugaw)
	elif KB5xuz42bO96==EMO8gy4LrsNTh0knZwpSeU75APW(u"࠷ᕀ"):
		scraperserver = ZchUJdM93pTA7zG5(u"ࠫࡸࡩࡲࡢࡲࡨ࠲ࡩࡵ࠱ࠨሳ")
		frAqnQyu0HbkmCXVlISLFT3Kv = TlGXWLYsV1z(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡩࡣ࠳࠸࠶ࡥࡧ࠷ࡥ࠶࠲࠷࠸ࡩ࠸ࡣࡢ࠷ࡧ࠹ࡩ࠹ࡦ࠺ࡧ࠶ࡧ࠸࠾࠶ࡦࡥࡤ࠵࠶࠶࠸࠴࠺࠼ࡥ࠼࠹࠺ࡤࡷࡶࡸࡴࡳࡈࡦࡣࡧࡩࡷࡹ࠽ࡕࡴࡸࡩࠫ࡭ࡥࡰࡅࡲࡨࡪࡃࡩ࡭ࡂࡳࡶࡴࡾࡹ࠯ࡵࡦࡶࡦࡶࡥ࠯ࡦࡲ࠾࠽࠶࠸࠱ࠩሴ")
		x93j25L6Agtsyfkh7 = eCGwzSrqBmIv+XrTw01KtLzbpoyMf(u"࠭ࡼࡽࡏࡼࡔࡷࡵࡸࡺࡗࡵࡰࡂ࠭ስ")+frAqnQyu0HbkmCXVlISLFT3Kv+xpT28sXu051(u"ࠧࡽࡾࡑࡳ࡛࡫ࡲࡪࡨࡼࡗࡘࡒࠧሶ")
		lloDvathpIVNs = GJqpByOKiRenb184w0(bDlzGospmi69Oy1NILPaHMWK8Z3FSw,x93j25L6Agtsyfkh7,EwsmJ67cCYDIlg,rzR9SN7ApZuQhTDWEX3V6ga,mC1Iuc3BdXv6ZPMeG2aQxDlV,bHZ5D6c9pRGfx,VamqUtbfFn6MANy,BF6QAiLUNHh7rKOugaw,BF6QAiLUNHh7rKOugaw)
	elif KB5xuz42bO96==hhQwbeiNLoqFjX90fB7aG8VAs(u"࠹ᕁ"):
		scraperserver = yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠨࡵࡦࡶࡦࡶࡥ࠯ࡦࡲ࠶ࠬሷ")
		frAqnQyu0HbkmCXVlISLFT3Kv = CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴ࡧ࠸ࡪ࠳ࡢࡧ࠴࠼࠺ࡪࡦ࠵ࡤࡩ࠺ࡦ࡬࠵࠴࠵ࡦ࠻࠵࠺࠰ࡣ࠵࠷࠻ࡨ࠿ࡥ࠺࠻ࡥࡩ࠹࠼࠶ࡢࡧ࠼࠾ࡨࡻࡳࡵࡱࡰࡌࡪࡧࡤࡦࡴࡶࡁ࡙ࡸࡵࡦࠨࡪࡩࡴࡉ࡯ࡥࡧࡀ࡭ࡱࡆࡰࡳࡱࡻࡽ࠳ࡹࡣࡳࡣࡳࡩ࠳ࡪ࡯࠻࠺࠳࠼࠵࠭ሸ")
		x93j25L6Agtsyfkh7 = eCGwzSrqBmIv+IpC4qHXRuyNFjzWv(u"ࠪࢀࢁࡓࡹࡑࡴࡲࡼࡾ࡛ࡲ࡭࠿ࠪሹ")+frAqnQyu0HbkmCXVlISLFT3Kv+xpT28sXu051(u"ࠫࢁࢂࡎࡰࡘࡨࡶ࡮࡬ࡹࡔࡕࡏࠫሺ")
		lloDvathpIVNs = GJqpByOKiRenb184w0(bDlzGospmi69Oy1NILPaHMWK8Z3FSw,x93j25L6Agtsyfkh7,EwsmJ67cCYDIlg,rzR9SN7ApZuQhTDWEX3V6ga,mC1Iuc3BdXv6ZPMeG2aQxDlV,bHZ5D6c9pRGfx,VamqUtbfFn6MANy,BF6QAiLUNHh7rKOugaw,BF6QAiLUNHh7rKOugaw)
	elif KB5xuz42bO96==hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"࠻ᕂ"):
		scraperserver = ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠬࡹࡣࡳࡣࡳࡩࡴࡶࡳ࠴ࠩሻ")
		x93j25L6Agtsyfkh7 = zmcGfOdvAjsELeJlP(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡱࡴࡲࡼࡾ࠴ࡳࡤࡴࡤࡴࡪࡵࡰࡴ࠰࡬ࡳ࠴ࡼ࠱࠰ࡁࡤࡴ࡮ࡥ࡫ࡦࡻࡀ࠷࠾࠿࠱ࡦ࠻ࡦ࠹࠲࠽ࡥࡦ࠵࠰࠸ࡪ࡫࠲࠮࠺࠷ࡧ࠵࠳ࡦࡥ࠹࠼࠶ࡧࡧࡤࡥ࠵ࡧ࠹ࠫࡩ࡯ࡶࡰࡷࡶࡾࡃࡩ࡭ࠨࡸࡶࡱࡃࠧሼ")+YqdaDIig21wBTWJeUHbc(eCGwzSrqBmIv)
		lloDvathpIVNs = GJqpByOKiRenb184w0(vODxLKW5Ql6r4Fbm8(u"ࠧࡈࡇࡗࠫሽ"),x93j25L6Agtsyfkh7,EwsmJ67cCYDIlg,rzR9SN7ApZuQhTDWEX3V6ga,mC1Iuc3BdXv6ZPMeG2aQxDlV,bHZ5D6c9pRGfx,VamqUtbfFn6MANy,BF6QAiLUNHh7rKOugaw,BF6QAiLUNHh7rKOugaw)
	elif KB5xuz42bO96==ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"࠽ᕃ"):
		scraperserver = tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠨࡵࡦࡶࡦࡶࡩ࡯ࡩࡤࡲࡹ࠸ࠧሾ")
		frAqnQyu0HbkmCXVlISLFT3Kv = FRYcH4KL7e9gv5pEB(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡶࡧࡷࡧࡰࡪࡰࡪࡥࡳࡺࠦࡱࡴࡲࡼࡾࡥࡣࡰࡷࡱࡸࡷࡿ࠽ࡂࡇࠩࡶࡪࡺࡵࡳࡰࡢࡴࡦ࡭ࡥࡠࡵࡲࡹࡷࡩࡥ࠾ࡶࡵࡹࡪࠬࡦࡰࡴࡺࡥࡷࡪ࡟ࡩࡧࡤࡨࡪࡸࡳ࠾ࡶࡵࡹࡪࡀ࠲ࡣ࠵࠷࠴ࡦ࠼࠸࠺࠲ࡤ࠹࠹࠶࠱ࡥࡤࡦ࠷࠼࠸ࡣ࠲࠳࠷࠹ࡩ࠿࠶࠳ࡧ࠻ࡄࡵࡸ࡯ࡹࡻ࠱ࡷࡨࡸࡡࡱ࡫ࡱ࡫ࡦࡴࡴ࠯ࡥࡲࡱ࠿࠾࠰࠹࠲ࠪሿ")
		x93j25L6Agtsyfkh7 = eCGwzSrqBmIv+FRYcH4KL7e9gv5pEB(u"ࠪࢀࢁࡓࡹࡑࡴࡲࡼࡾ࡛ࡲ࡭࠿ࠪቀ")+frAqnQyu0HbkmCXVlISLFT3Kv+yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠫࢁࢂࡎࡰࡘࡨࡶ࡮࡬ࡹࡔࡕࡏࠫቁ")
		lloDvathpIVNs = GJqpByOKiRenb184w0(bDlzGospmi69Oy1NILPaHMWK8Z3FSw,x93j25L6Agtsyfkh7,EwsmJ67cCYDIlg,rzR9SN7ApZuQhTDWEX3V6ga,mC1Iuc3BdXv6ZPMeG2aQxDlV,bHZ5D6c9pRGfx,VamqUtbfFn6MANy,BF6QAiLUNHh7rKOugaw,BF6QAiLUNHh7rKOugaw)
	else:
		scraperserver,x93j25L6Agtsyfkh7 = iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U
		lloDvathpIVNs = AutiwYdmGMSgL3lXTD()
		update = BF6QAiLUNHh7rKOugaw
	if update and not lloDvathpIVNs.succeeded:
		mtMp5GAHcQsBNLJovRg1r3KVdqjn(website,[],KB5xuz42bO96)
		if len(list(set(YiRtHb1SsT)))>YYJQyRskpX8jv:
			U17QqF2gkI46 = A1AXKupEOfz(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨቂ"),vODxLKW5Ql6r4Fbm8(u"࠭ไๅลึๅู๊ࠥาใิࠤ๊฿วๅฮฬࠤฬ๊ออสࠣี็๋ࠠࠨቃ")+str(KB5xuz42bO96)+UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠧࠡใื่ࠥ็๊ࠡ฻่่๏ฯࠠหฮส์ืࠦวๅฯฯฬࠥ࠴࠮้ࠡ็ࠤฯื๊ะ่ࠢัฬ๎ไสࠢอะฬ๎าࠡษ็ััฮࠠๆำฬࠤศิั๊ࠢหหุะฮะษ่ࠤุ๐ัโำ้ࠣำะไโࠢยࠥࠬቄ"))
			if U17QqF2gkI46==YYJQyRskpX8jv:
				HHm6yoEO7v4GBWqpcrQgJUiaw.append(KB5xuz42bO96)
				lloDvathpIVNs = FTLpOjS0Ew1YaRy3Q9(bDlzGospmi69Oy1NILPaHMWK8Z3FSw,eCGwzSrqBmIv,EwsmJ67cCYDIlg,rzR9SN7ApZuQhTDWEX3V6ga,mC1Iuc3BdXv6ZPMeG2aQxDlV,bHZ5D6c9pRGfx,VamqUtbfFn6MANy,RRLYX967TCPfySDoeF8pV3gANMGWuQ,LXSBswmknoDzdT1hQqlUie,HHm6yoEO7v4GBWqpcrQgJUiaw)
				return lloDvathpIVNs
	lloDvathpIVNs.scrapernumber = str(KB5xuz42bO96)
	lloDvathpIVNs.scraperserver = scraperserver
	lloDvathpIVNs.scraperurl = x93j25L6Agtsyfkh7
	AZFMvK0BrDLOt9pUXHST = L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠨีํีๆืࠠาไ่ࠤࠬቅ")+lloDvathpIVNs.scrapernumber
	if lloDvathpIVNs.succeeded:
		WKquk5EaNr4RzVf(P3sqIW4T8rYpjNxOXhcBk2GD,IIZ4e82HBP0oTmtOgaWY7hsMz(sQU2GnRoMwLK8CBdfzmNr4jXyO)+PtkEvXAqif14G20QZsaSyT(u"ࠩࠣࠤ࡙ࠥࡵࡤࡥࡨࡩࡩ࡫ࡤࠡࡤࡼࡴࡦࡹࡳࠡࡤ࡯ࡳࡨࡱࡩ࡯ࡩࠣࠤ࡙ࠥࡥࡳࡸࡨࡶ࠿࡛ࠦࠡࠩቆ")+scraperserver+L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠪࠤࡢࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬቇ")+VamqUtbfFn6MANy+uuExaKGL7UONtevRd(u"ࠫࠥࡣࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪቈ")+eCGwzSrqBmIv+yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠬࠦ࡝ࠨ቉"))
		YYkhEn5xTXLUevzCVNB16mR(yJeq1BjfiO4NFuwIEzxVLK6b9s(u"࠭ๆอฯอࠤ฾๋ไ๋หࠣฮัอ่ำࠢส่าาศࠨቊ"),AZFMvK0BrDLOt9pUXHST,X2cQ5NCPvkMieBW7oASspFjE=xpT28sXu051(u"࠼࠻࠰ᕄ"))
	else:
		WKquk5EaNr4RzVf(uiza5vIyTWtUeB8sXwAVYMFpgjrk,IIZ4e82HBP0oTmtOgaWY7hsMz(sQU2GnRoMwLK8CBdfzmNr4jXyO)+MgP8OjoaiWQEVG59(u"ࠧࠡࠢࠣࡊࡦ࡯࡬ࡦࡦࠣࡦࡾࡶࡡࡴࡵࠣࡦࡱࡵࡣ࡬࡫ࡱ࡫ࠥࠦࠠࡔࡧࡵࡺࡪࡸ࠺ࠡ࡝ࠣࠫቋ")+scraperserver+SaB5hx3PZwXRLtKgrTfQvId(u"ࠨࠢࡠࠤࠥࠦࡃࡰࡦࡨ࠾ࠥࡡࠠࠨቌ")+str(lloDvathpIVNs.code)+ZchUJdM93pTA7zG5(u"ࠩࠣࡡࠥࠦࠠࡓࡧࡤࡷࡴࡴ࠺ࠡ࡝ࠣࠫቍ")+lloDvathpIVNs.reason+XrTw01KtLzbpoyMf(u"ࠪࠤࡢࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬ቎")+VamqUtbfFn6MANy+sVzojQerUqX(u"ࠫࠥࡣࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ቏")+eCGwzSrqBmIv+LyNiIHPOwD3hCUYEFM7(u"ࠬࠦ࡝ࠨቐ"))
		YYkhEn5xTXLUevzCVNB16mR(y6y5HtgXO4TkUbwVZ(u"࠭แีๆอࠤ฾๋ไ๋หࠣฮัอ่ำࠢส่าาศࠨቑ"),AZFMvK0BrDLOt9pUXHST,X2cQ5NCPvkMieBW7oASspFjE=yJeq1BjfiO4NFuwIEzxVLK6b9s(u"࠽࠵࠱ᕅ"))
	return lloDvathpIVNs
def MMCJxEfv0WUek(xZ9qAk7pF3XCKDsOh0SN,bDlzGospmi69Oy1NILPaHMWK8Z3FSw,smglbwR7x2oM,oRzlSfeE6DY0mFy37NCVxAJW1BwZtM,CZGXVf91e3KTpSDqyP6x8otlhLBam2,Kh6Op2cwaB9,showDialogs,VamqUtbfFn6MANy,D8o76IEfjVOLz=iiy37aKq0pCEIOwfcTh61xb4U,N9Bvn0opEfM=iiy37aKq0pCEIOwfcTh61xb4U):
	eCGwzSrqBmIv,TeLlsNSmcf7FvU3byDkzWAItq5da4R,uuHt2FaeJLp8,KvXWMwZf438UyOnFBlqPDsiIm1c0L = T2TI6RohemNWG4(smglbwR7x2oM)
	try: tsY75poQq6HO0B9jz3uJZE = CZGXVf91e3KTpSDqyP6x8otlhLBam2.copy()
	except: tsY75poQq6HO0B9jz3uJZE = CZGXVf91e3KTpSDqyP6x8otlhLBam2
	YVKo4mpBq9vEeUfM7JR8ujSP = bDlzGospmi69Oy1NILPaHMWK8Z3FSw,eCGwzSrqBmIv,oRzlSfeE6DY0mFy37NCVxAJW1BwZtM,tsY75poQq6HO0B9jz3uJZE,Kh6Op2cwaB9
	if xZ9qAk7pF3XCKDsOh0SN<hhQwbeiNLoqFjX90fB7aG8VAs(u"࠰ᕆ"):
		Bcxq3nkvTU9iM(PdkZHNBlpg2b7DmX6qRiyVa,uuExaKGL7UONtevRd(u"ࠧࡐࡒࡈࡒ࡚ࡘࡌࡠࡔࡈࡕ࡚ࡋࡓࡕࡕࠪቒ"),YVKo4mpBq9vEeUfM7JR8ujSP)
		xZ9qAk7pF3XCKDsOh0SN = -xZ9qAk7pF3XCKDsOh0SN
	if xZ9qAk7pF3XCKDsOh0SN>xpT28sXu051(u"࠱ᕇ"):
		VVznOTKE7NDIe0HGkg = QKzCiBOWZus1nSv(PdkZHNBlpg2b7DmX6qRiyVa,CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠨࡴࡨࡷࡵࡵ࡮ࡴࡧࠪቓ"),ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠩࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗࠬቔ"),YVKo4mpBq9vEeUfM7JR8ujSP)
		if VVznOTKE7NDIe0HGkg.succeeded:
			ri8uRdOU0kNfq4(hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠪࡖࡊࡗࡕࡆࡕࡗࡗࠥࠦࡒࡆࡃࡇࡣࡈࡇࡃࡉࡇࠪቕ"),eCGwzSrqBmIv,oRzlSfeE6DY0mFy37NCVxAJW1BwZtM,CZGXVf91e3KTpSDqyP6x8otlhLBam2,VamqUtbfFn6MANy,bDlzGospmi69Oy1NILPaHMWK8Z3FSw)
			return VVznOTKE7NDIe0HGkg
	VVznOTKE7NDIe0HGkg = GJqpByOKiRenb184w0(bDlzGospmi69Oy1NILPaHMWK8Z3FSw,smglbwR7x2oM,oRzlSfeE6DY0mFy37NCVxAJW1BwZtM,CZGXVf91e3KTpSDqyP6x8otlhLBam2,Kh6Op2cwaB9,showDialogs,VamqUtbfFn6MANy,D8o76IEfjVOLz,N9Bvn0opEfM)
	if VVznOTKE7NDIe0HGkg.succeeded:
		if sVzojQerUqX(u"ࠫࡈࡏࡍࡂࡐࡒ࡛ࠬቖ") in VamqUtbfFn6MANy: VVznOTKE7NDIe0HGkg.content = zJ1OjtAFPhK85MY2p7ZmVBowxgS(VVznOTKE7NDIe0HGkg.content)
		if VVznOTKE7NDIe0HGkg.scrape: xZ9qAk7pF3XCKDsOh0SN = Dxc7GChQwZ4kOlKHSbL06agnB
		if xZ9qAk7pF3XCKDsOh0SN and VVznOTKE7NDIe0HGkg.content: YMQXP2BGeK86CEb(PdkZHNBlpg2b7DmX6qRiyVa,FRYcH4KL7e9gv5pEB(u"ࠬࡕࡐࡆࡐࡘࡖࡑࡥࡒࡆࡓࡘࡉࡘ࡚ࡓࠨ቗"),YVKo4mpBq9vEeUfM7JR8ujSP,VVznOTKE7NDIe0HGkg,xZ9qAk7pF3XCKDsOh0SN)
	return VVznOTKE7NDIe0HGkg
def uDgpjAaKoJTUGY1PlyLqtROrwBQ6(xZ9qAk7pF3XCKDsOh0SN,smglbwR7x2oM,oRzlSfeE6DY0mFy37NCVxAJW1BwZtM,CZGXVf91e3KTpSDqyP6x8otlhLBam2,showDialogs,VamqUtbfFn6MANy):
	if not oRzlSfeE6DY0mFy37NCVxAJW1BwZtM or isinstance(oRzlSfeE6DY0mFy37NCVxAJW1BwZtM,dict): bDlzGospmi69Oy1NILPaHMWK8Z3FSw = ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"࠭ࡇࡆࡖࠪቘ")
	else:
		bDlzGospmi69Oy1NILPaHMWK8Z3FSw = MgP8OjoaiWQEVG59(u"ࠧࡑࡑࡖࡘࠬ቙")
		oRzlSfeE6DY0mFy37NCVxAJW1BwZtM = a9I3YZjc6ySDPE4Kp(oRzlSfeE6DY0mFy37NCVxAJW1BwZtM)
		YtfKlA145HJup9zOy,oRzlSfeE6DY0mFy37NCVxAJW1BwZtM = sFNjagPK4W(oRzlSfeE6DY0mFy37NCVxAJW1BwZtM)
	VVznOTKE7NDIe0HGkg = MMCJxEfv0WUek(xZ9qAk7pF3XCKDsOh0SN,bDlzGospmi69Oy1NILPaHMWK8Z3FSw,smglbwR7x2oM,oRzlSfeE6DY0mFy37NCVxAJW1BwZtM,CZGXVf91e3KTpSDqyP6x8otlhLBam2,rGPen6cSMHQkAywh8vqI9JXiD2,showDialogs,VamqUtbfFn6MANy)
	HGQ5Ty9mlSLwed = VVznOTKE7NDIe0HGkg.content
	HGQ5Ty9mlSLwed = str(HGQ5Ty9mlSLwed)
	return HGQ5Ty9mlSLwed
def T2TI6RohemNWG4(smglbwR7x2oM):
	o2tSGV89DbAI7zaE = smglbwR7x2oM.split(ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠨࡾࡿࠫቚ"))
	eCGwzSrqBmIv,TeLlsNSmcf7FvU3byDkzWAItq5da4R,uuHt2FaeJLp8,KvXWMwZf438UyOnFBlqPDsiIm1c0L = o2tSGV89DbAI7zaE[FGTfwsjNrB8DvKSZhLIQAb1JnO],None,None,rGPen6cSMHQkAywh8vqI9JXiD2
	for YVKo4mpBq9vEeUfM7JR8ujSP in o2tSGV89DbAI7zaE:
		if xpT28sXu051(u"ࠩࡐࡽࡕࡸ࡯ࡹࡻࡘࡶࡱࡃࠧቛ") in YVKo4mpBq9vEeUfM7JR8ujSP: TeLlsNSmcf7FvU3byDkzWAItq5da4R = YVKo4mpBq9vEeUfM7JR8ujSP[zmcGfOdvAjsELeJlP(u"࠳࠴ᕈ"):]
		elif XrTw01KtLzbpoyMf(u"ࠪࡑࡾࡊࡎࡔࡗࡵࡰࡂ࠭ቜ") in YVKo4mpBq9vEeUfM7JR8ujSP: uuHt2FaeJLp8 = YVKo4mpBq9vEeUfM7JR8ujSP[PtkEvXAqif14G20QZsaSyT(u"࠼ᕉ"):]
		elif jXE2YHkswT8y(u"ࠫࡓࡵࡖࡦࡴ࡬ࡪࡾ࡙ࡓࡍࠩቝ") in YVKo4mpBq9vEeUfM7JR8ujSP: KvXWMwZf438UyOnFBlqPDsiIm1c0L = BF6QAiLUNHh7rKOugaw
	return eCGwzSrqBmIv,TeLlsNSmcf7FvU3byDkzWAItq5da4R,uuHt2FaeJLp8,KvXWMwZf438UyOnFBlqPDsiIm1c0L
def KhobVXm6PsUkD5v(xZ9qAk7pF3XCKDsOh0SN,bDlzGospmi69Oy1NILPaHMWK8Z3FSw,smglbwR7x2oM,imr6ckqDveLz7tCJXlY,JXFUYbDPuwk4HSoc7TA,CyidFPfE2tXD3cI,CZGXVf91e3KTpSDqyP6x8otlhLBam2=iiy37aKq0pCEIOwfcTh61xb4U):
	KeRtIq9jdHD0AbPO5 = F82MvyX4ThI6sbnA3efDoVS(smglbwR7x2oM,xpT28sXu051(u"ࠬࡻࡲ࡭ࠩ቞"))
	WQ91kEDxupH0y6RBzt4MPh = OXsckY7RzjCag9A.getSetting(FRYcH4KL7e9gv5pEB(u"࠭ࡡࡷ࠰࡫ࡳࡸࡺ࠮ࠨ቟")+imr6ckqDveLz7tCJXlY)
	if KeRtIq9jdHD0AbPO5==WQ91kEDxupH0y6RBzt4MPh: OXsckY7RzjCag9A.setSetting(LyNiIHPOwD3hCUYEFM7(u"ࠧࡢࡸ࠱࡬ࡴࡹࡴ࠯ࠩበ")+imr6ckqDveLz7tCJXlY,iiy37aKq0pCEIOwfcTh61xb4U)
	if WQ91kEDxupH0y6RBzt4MPh: O5Pwg3UFyX0k9E = smglbwR7x2oM.replace(KeRtIq9jdHD0AbPO5,WQ91kEDxupH0y6RBzt4MPh)
	else:
		O5Pwg3UFyX0k9E = smglbwR7x2oM
		WQ91kEDxupH0y6RBzt4MPh = KeRtIq9jdHD0AbPO5
	LohAQRbz2WGpwNmPHJrdcv984S = MMCJxEfv0WUek(xZ9qAk7pF3XCKDsOh0SN,bDlzGospmi69Oy1NILPaHMWK8Z3FSw,O5Pwg3UFyX0k9E,iiy37aKq0pCEIOwfcTh61xb4U,CZGXVf91e3KTpSDqyP6x8otlhLBam2,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡓࡔࡍࡌࡆࡡࡑࡉ࡜ࡥࡈࡐࡕࡗࡒࡆࡓࡅ࠮࠳ࡶࡸࠬቡ"))
	HGQ5Ty9mlSLwed = LohAQRbz2WGpwNmPHJrdcv984S.content
	if J1MoiYc7ZwzKS:
		try: HGQ5Ty9mlSLwed = HGQ5Ty9mlSLwed.decode(df6QpwGxuJVZr,sVzojQerUqX(u"ࠩ࡬࡫ࡳࡵࡲࡦࠩቢ"))
		except: pass
	if not LohAQRbz2WGpwNmPHJrdcv984S.succeeded or CyidFPfE2tXD3cI not in HGQ5Ty9mlSLwed:
		JXFUYbDPuwk4HSoc7TA = JXFUYbDPuwk4HSoc7TA.replace(iFBmE2MUIpSu34wsd7Rf6z,Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠪ࠯ࠬባ"))
		eCGwzSrqBmIv = hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡪࡳࡴ࡭࡬ࡦ࠰ࡦࡳࡲ࠵ࡳࡦࡣࡵࡧ࡭ࡅࡱ࠾ࠩቤ")+JXFUYbDPuwk4HSoc7TA
		rzR9SN7ApZuQhTDWEX3V6ga = {SaB5hx3PZwXRLtKgrTfQvId(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩብ"):iiy37aKq0pCEIOwfcTh61xb4U}
		xQoYJsjSm0yfdzaOewV7pC = MMCJxEfv0WUek(xZ9qAk7pF3XCKDsOh0SN,bDlzGospmi69Oy1NILPaHMWK8Z3FSw,eCGwzSrqBmIv,iiy37aKq0pCEIOwfcTh61xb4U,rzR9SN7ApZuQhTDWEX3V6ga,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡑࡒࡋࡑࡋ࡟ࡏࡇ࡚ࡣࡍࡕࡓࡕࡐࡄࡑࡊ࠳࠲࡯ࡦࠪቦ"))
		if xQoYJsjSm0yfdzaOewV7pC.succeeded:
			HGQ5Ty9mlSLwed = xQoYJsjSm0yfdzaOewV7pC.content
			if J1MoiYc7ZwzKS:
				try: HGQ5Ty9mlSLwed = HGQ5Ty9mlSLwed.decode(df6QpwGxuJVZr,hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠧࡪࡩࡱࡳࡷ࡫ࠧቧ"))
				except: pass
			P3tys0cXWbiIUKk7HQ6n89V = dEyT9xhGjolYzLCH7460w3.findall(tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥ࠳ࡡࡽࠪ࡝ࡁ࠱࠮ࡄ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩࠣࠩቨ"),HGQ5Ty9mlSLwed,dEyT9xhGjolYzLCH7460w3.DOTALL)
			eWaxGPIEvylQdrnpV = [WQ91kEDxupH0y6RBzt4MPh]
			SAEivhV5syQgRIl6GjL = [ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠩࡤࡴࡰ࠭ቩ"),tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠪ࡫ࡴࡵࡧ࡭ࡧࠪቪ"),L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠫࡹࡽࡩࡵࡶࡨࡶࠬቫ"),sVzojQerUqX(u"ࠬࡿ࡯ࡶࡶࡸࡦࡪ࠭ቬ"),uuExaKGL7UONtevRd(u"࠭ࡦࡢࡥࡨࡦࡴࡵ࡫ࠨቭ"),AbqCJZdWQP9j(u"ࠧࡱࡪࡳࠫቮ"),HtK4o2sTPgA78U(u"ࠨࡣࡷࡰࡦࡷࠧቯ"),TlGXWLYsV1z(u"ࠩࡶ࡭ࡹ࡫ࡩ࡯ࡦ࡬ࡧࡪࡹࠧተ"),LyNiIHPOwD3hCUYEFM7(u"ࠪࡷࡺࡸ࠮࡭ࡻࠪቱ"),yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠫࡧࡲ࡯ࡨࡵࡳࡳࡹ࠭ቲ"),MgP8OjoaiWQEVG59(u"ࠬ࡯࡮ࡧࡱࡵࡱࡪࡸࠧታ"),vODxLKW5Ql6r4Fbm8(u"࠭ࡳࡪࡶࡨࡰ࡮ࡱࡥࠨቴ"),CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠧࡪࡰࡶࡸࡦ࡭ࡲࡢ࡯ࠪት"),jXE2YHkswT8y(u"ࠨࡵࡱࡥࡵࡩࡨࡢࡶࠪቶ"),HtK4o2sTPgA78U(u"ࠩ࡫ࡸࡹࡶ࠭ࡦࡳࡸ࡭ࡻ࠭ቷ"),jXE2YHkswT8y(u"ࠪࡪࡦࡹࡥ࡭ࡲ࡯ࡹࡸ࠭ቸ")]
			for Zd7faKVcIU3O1HrRPwJX5QL4 in P3tys0cXWbiIUKk7HQ6n89V:
				if any(aasX2cby4Vo5rTgB in Zd7faKVcIU3O1HrRPwJX5QL4 for aasX2cby4Vo5rTgB in SAEivhV5syQgRIl6GjL): continue
				WQ91kEDxupH0y6RBzt4MPh = F82MvyX4ThI6sbnA3efDoVS(Zd7faKVcIU3O1HrRPwJX5QL4,ZchUJdM93pTA7zG5(u"ࠫࡺࡸ࡬ࠨቹ"))
				if WQ91kEDxupH0y6RBzt4MPh in eWaxGPIEvylQdrnpV: continue
				if len(eWaxGPIEvylQdrnpV)==yJeq1BjfiO4NFuwIEzxVLK6b9s(u"࠽ᕊ"):
					WKquk5EaNr4RzVf(uiza5vIyTWtUeB8sXwAVYMFpgjrk,IIZ4e82HBP0oTmtOgaWY7hsMz(sQU2GnRoMwLK8CBdfzmNr4jXyO)+Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠬࠦࠠࠡࡉࡲࡳ࡬ࡲࡥࠡࡦ࡬ࡨࠥࡴ࡯ࡵࠢࡩ࡭ࡳࡪࠠࡢࠢࡱࡩࡼࠦࡨࡰࡵࡷࡲࡦࡳࡥࠡࠢࠣࡗ࡮ࡺࡥ࠻ࠢ࡞ࠤࠬቺ")+imr6ckqDveLz7tCJXlY+PtkEvXAqif14G20QZsaSyT(u"࠭ࠠ࡞ࠢࠣࡓࡱࡪ࠺ࠡ࡝ࠣࠫቻ")+KeRtIq9jdHD0AbPO5+TlGXWLYsV1z(u"ࠧࠡ࡟ࠪቼ"))
					OXsckY7RzjCag9A.setSetting(JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠨࡣࡹ࠲࡭ࡵࡳࡵ࠰ࠪች")+imr6ckqDveLz7tCJXlY,iiy37aKq0pCEIOwfcTh61xb4U)
					break
				eWaxGPIEvylQdrnpV.append(WQ91kEDxupH0y6RBzt4MPh)
				O5Pwg3UFyX0k9E = smglbwR7x2oM.replace(KeRtIq9jdHD0AbPO5,WQ91kEDxupH0y6RBzt4MPh)
				LohAQRbz2WGpwNmPHJrdcv984S = MMCJxEfv0WUek(xZ9qAk7pF3XCKDsOh0SN,bDlzGospmi69Oy1NILPaHMWK8Z3FSw,O5Pwg3UFyX0k9E,iiy37aKq0pCEIOwfcTh61xb4U,CZGXVf91e3KTpSDqyP6x8otlhLBam2,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,HtK4o2sTPgA78U(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡔࡕࡇࡍࡇࡢࡒࡊ࡝࡟ࡉࡑࡖࡘࡓࡇࡍࡆ࠯࠶ࡶࡩ࠭ቾ"))
				HGQ5Ty9mlSLwed = LohAQRbz2WGpwNmPHJrdcv984S.content
				if LohAQRbz2WGpwNmPHJrdcv984S.succeeded and CyidFPfE2tXD3cI in HGQ5Ty9mlSLwed:
					WKquk5EaNr4RzVf(P3sqIW4T8rYpjNxOXhcBk2GD,IIZ4e82HBP0oTmtOgaWY7hsMz(sQU2GnRoMwLK8CBdfzmNr4jXyO)+HtK4o2sTPgA78U(u"ࠪࠤࠥࠦࡇࡰࡱࡪࡰࡪࠦࡦࡰࡷࡱࡨࠥࡧࠠ࡯ࡧࡺࠤ࡭ࡵࡳࡵࡰࡤࡱࡪࠦࠠࠡࡕ࡬ࡸࡪࡀࠠ࡜ࠢࠪቿ")+imr6ckqDveLz7tCJXlY+sVzojQerUqX(u"ࠫࠥࡣࠠࠡࠢࡑࡩࡼࡀࠠ࡜ࠢࠪኀ")+WQ91kEDxupH0y6RBzt4MPh+jXE2YHkswT8y(u"ࠬࠦ࡝ࠡࠢࡒࡰࡩࡀࠠ࡜ࠢࠪኁ")+KeRtIq9jdHD0AbPO5+yJeq1BjfiO4NFuwIEzxVLK6b9s(u"࠭ࠠ࡞ࠩኂ"))
					OXsckY7RzjCag9A.setSetting(UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠧࡢࡸ࠱࡬ࡴࡹࡴ࠯ࠩኃ")+imr6ckqDveLz7tCJXlY,WQ91kEDxupH0y6RBzt4MPh)
					break
	return WQ91kEDxupH0y6RBzt4MPh,O5Pwg3UFyX0k9E,LohAQRbz2WGpwNmPHJrdcv984S
def aanoXVLTZqsIwitBdY0kcJS794FDg(XiWJ2PTqvds4pBNebVrt98x):
	I6ZPeV1pv4O0Utwn = {
	 vODxLKW5Ql6r4Fbm8(u"ࠨࡣ࡫ࡻࡦࡱࠧኄ")				:CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"่ࠩ์็฿ࠠฤ้๋ห่ࠦส๋ใํࠫኅ")
	,SaB5hx3PZwXRLtKgrTfQvId(u"ࠪࡥࡰࡵࡡ࡮ࠩኆ")				:TlGXWLYsV1z(u"๊ࠫ๎โฺࠢฦ็ํอๅࠡษ็ๆิ๐ๅࠨኇ")
	,Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠬࡧ࡫ࡰࡣࡰࡧࡦࡳࠧኈ")				:L90uqo28xEKSFUwYTcm51yRWZIkft(u"࠭ๅ้ไ฼ࠤศ้่ศ็ࠣ็ฬ๋ࠧ኉")
	,hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠧࡢ࡭ࡺࡥࡲ࠭ኊ")				:MgP8OjoaiWQEVG59(u"ࠨ็๋ๆ฾ࠦรไ๊ส้ࠥอไอัํำࠬኋ")
	,UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠩࡤ࡯ࡼࡧ࡭ࡵࡷࡥࡩࠬኌ")			:JZszNnIEMAx28Yao0yqhiXGKOPb(u"้ࠪํู่ࠡษๆ์ฬ๋ࠠห์๋ฬࠬኍ")
	,PtkEvXAqif14G20QZsaSyT(u"ࠫࡦࡲࡡࡳࡣࡥࠫ኎")				:tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"๋่ࠬใ฻ࠣ็้ࠦวๅ฻ิฬࠬ኏")
	,tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"࠭ࡡ࡭ࡨࡤࡸ࡮ࡳࡩࠨነ")				:tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠧๆ๊ๅ฽ࠥอไๆ่หีࠥอไโษฺ้๏࠭ኑ")
	,MgP8OjoaiWQEVG59(u"ࠨࡣ࡯࡯ࡦࡽࡴࡩࡣࡵࠫኒ")			:ZchUJdM93pTA7zG5(u"่ࠩ์็฿ࠠใ่สอࠥอไไ๊ฮีࠬና")
	,CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠪࡥࡱࡳࡡࡢࡴࡨࡪࠬኔ")				:vODxLKW5Ql6r4Fbm8(u"๊ࠫ๎โฺࠢๅ๊ฬฯࠠศๆ่฽ฬืแࠨን")
	,ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠬࡧ࡬࡮ࡵࡷࡦࡦ࠭ኖ")				:MgP8OjoaiWQEVG59(u"࠭ๅ้ไ฼ࠤฬ๊ๅึูหอࠬኗ")
	,zmcGfOdvAjsELeJlP(u"ࠧࡢࡰ࡬ࡱࡪࢀࡩࡥࠩኘ")				:FRYcH4KL7e9gv5pEB(u"ࠨ็๋ๆ฾ࠦว็็ํࠤืีࠧኙ")
	,hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠩࡤࡶࡦࡨࡩࡤࡶࡲࡳࡳࡹࠧኚ")			:tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"้ࠪํู่ࠡฬ๋๊ืูࠦาสํอࠬኛ")
	,vODxLKW5Ql6r4Fbm8(u"ࠫࡦࡸࡡࡣࡵࡨࡩࡩ࠭ኜ")				:uuExaKGL7UONtevRd(u"๋่ࠬใ฻ࠣ฽ึฮࠠิ์ํำࠬኝ")
	,GGx4qyKP1vUtRghsE2WfaHLMXZ(u"࠭ࡡࡳࡤ࡯࡭ࡴࡴࡺࠨኞ")				:SaB5hx3PZwXRLtKgrTfQvId(u"ࠧๆ๊ๅ฽ࠥ฿ัษࠢ็๎ํ์าࠨኟ")
	,AbqCJZdWQP9j(u"ࠨࡣࡼࡰࡴࡲࠧአ")				:FRYcH4KL7e9gv5pEB(u"่ࠩ์็฿ࠠฤ์็์้࠭ኡ")
	,zmcGfOdvAjsELeJlP(u"ࠪࡦࡴࡱࡲࡢࠩኢ")				:CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"๊ࠫ๎โฺࠢห็ึอࠧኣ")
	,Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠬࡨࡲࡴࡶࡨ࡮ࠬኤ")				:yJeq1BjfiO4NFuwIEzxVLK6b9s(u"࠭ๅ้ไ฼ࠤอืำห์ฯࠫእ")
	,HtK4o2sTPgA78U(u"ࠧࡤ࡫ࡰࡥ࠹࠶࠰ࠨኦ")				:ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠨ็๋ๆ฾ࠦำ๋็สࠤ࠹࠶࠰ࠨኧ")
	,AbqCJZdWQP9j(u"ࠩࡦ࡭ࡲࡧ࠴ࡱࠩከ")				:MgP8OjoaiWQEVG59(u"้ࠪํู่ࠡีํ้ฬࠦแ้ำࠣฬ๏࠭ኩ")
	,MgP8OjoaiWQEVG59(u"ࠫࡨ࡯࡭ࡢ࠶ࡸࠫኪ")				:sVzojQerUqX(u"๋่ࠬใ฻ࠣื๏๋วࠡใ๋ี๏๎ࠧካ")
	,xpT28sXu051(u"࠭ࡣࡪ࡯ࡤࡥࡧࡪ࡯ࠨኬ")				:UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠧๆ๊ๅ฽ู๊ࠥๆษࠣ฽อี่ࠨክ")
	,EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠨࡥ࡬ࡱࡦࡩ࡬ࡶࡤࠪኮ")				:PtkEvXAqif14G20QZsaSyT(u"่ࠩ์็฿ࠠิ์่ห้ࠥไ้สࠪኯ")
	,GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠪࡧ࡮ࡳࡡࡤ࡮ࡸࡦࡼࡵࡲ࡬ࠩኰ")			:LyNiIHPOwD3hCUYEFM7(u"๊ࠫ๎โฺࠢึ๎๊อࠠไๆ๋ฬࠥ฿ๅๅࠩ኱")
	,jXE2YHkswT8y(u"ࠬࡩࡩ࡮ࡣࡦࡰࡺࡶࠧኲ")				:ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"࠭ๅ้ไ฼ࠤุ๐ๅศࠢๆ่ํฮࠧኳ")
	,HtK4o2sTPgA78U(u"ࠧࡤ࡫ࡰࡥ࡫ࡧ࡮ࡴࠩኴ")				:EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠨ็๋ๆ฾ࠦำ๋็สࠤๆอๆำࠩኵ")
	,AbqCJZdWQP9j(u"ࠩࡦ࡭ࡲࡧࡦࡳࡧࡨࠫ኶")				:PtkEvXAqif14G20QZsaSyT(u"้ࠪํู่ࠡีํ้ฬࠦแา์ࠪ኷")
	,jXE2YHkswT8y(u"ࠫࡨ࡯࡭ࡢ࡮࡬࡫࡭ࡺࠧኸ")			:ZchUJdM93pTA7zG5(u"๋่ࠬใ฻ࠣื๏๋วࠡๆส๎ฯ࠭ኹ")
	,hhQwbeiNLoqFjX90fB7aG8VAs(u"࠭ࡣࡪ࡯ࡤࡲࡴࡽࠧኺ")				:PtkEvXAqif14G20QZsaSyT(u"ࠧๆ๊ๅ฽ู๊ࠥๆษ๊ࠣฬ๎ࠧኻ")
	,sVzojQerUqX(u"ࠨࡥ࡬ࡱࡦࡽࡢࡢࡵࠪኼ")				:JZszNnIEMAx28Yao0yqhiXGKOPb(u"่ࠩ์็฿ࠠิ์่หࠥ๎ศิࠩኽ")
	,uuExaKGL7UONtevRd(u"ࠪࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮ࠨኾ")			:uuExaKGL7UONtevRd(u"๊ࠫ๎โฺࠢาห๏๊๊ࠡ็ุ๋๋࠭኿")
	,SaB5hx3PZwXRLtKgrTfQvId(u"ࠬࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰ࠰ࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬዀ")	:ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"࠭ๅ้ไ฼ࠤิอ๊ๅ์้ࠣํฺๆࠡ็ึฮำีๅ๋่ࠪ዁")
	,CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠧࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲ࠲࡮ࡡࡴࡪࡷࡥ࡬ࡹࠧዂ")	:CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠨ็๋ๆ฾ࠦฯศ์็๎๋่ࠥี่๋ࠣฬฺสศๅࠪዃ")
	,YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠩࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴ࠭࡭࡫ࡹࡩࡸ࠭ዄ")	:uuExaKGL7UONtevRd(u"้ࠪํู่ࠡัส๎้๐ࠠๆ๊ื๊๋ࠥศศึิࠫዅ")
	,yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠫࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯࠯ࡳࡰࡦࡿ࡬ࡪࡵࡷࡷࠬ዆"):PtkEvXAqif14G20QZsaSyT(u"๋่ࠬใ฻ࠣำฬ๐ไ๋่ࠢ์ู์ࠠใ๊สส๊࠭዇")
	,tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"࠭ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱ࠱ࡹࡵࡰࡪࡥࡶࠫወ")	:jXE2YHkswT8y(u"ࠧๆ๊ๅ฽ࠥีว๋ๆํࠤ๊๎ิ็่ࠢ์ฬ฼ฺ๊ࠩዉ")
	,hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠨࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠳ࡶࡪࡦࡨࡳࡸ࠭ዊ")	:hhQwbeiNLoqFjX90fB7aG8VAs(u"่ࠩ์็฿ࠠะษํ่๏ࠦๅ้ึ้ࠤๆ๐ฯ๋๊๊หฯ࠭ዋ")
	,vODxLKW5Ql6r4Fbm8(u"ࠪࡨ࡮ࡹࡡࡣ࡮ࡨࡨࠬዌ")				:SaB5hx3PZwXRLtKgrTfQvId(u"๊ࠫะ่ใใࠪው")
	,L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠬࡪࡲࡢ࡯ࡤࡧࡦ࡬ࡥࠨዎ")			:zmcGfOdvAjsELeJlP(u"࠭ๅ้ไ฼ࠤิืวๆษࠣ็ฬ็๊่ࠩዏ")
	,y6y5HtgXO4TkUbwVZ(u"ࠧࡥࡴࡤࡱࡦࡹ࠷ࠨዐ")				:L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠨ็๋ๆ฾ࠦฯาษ่หࠥ฻อࠨዑ")
	,yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠩࡨ࡫ࡾࡨࡥࡴࡶࠪዒ")				:ZchUJdM93pTA7zG5(u"้ࠪํู่ࠡษํะ๏ࠦศ๋ีอࠫዓ")
	,LyNiIHPOwD3hCUYEFM7(u"ࠫࡪ࡭ࡹࡣࡧࡶࡸ࠶࠭ዔ")				:tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"๋่ࠬใ฻ࠣห๏า๊ࠡสํืฯࠦ࠱ࠨዕ")
	,tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"࠭ࡥࡨࡻࡥࡩࡸࡺ࠲ࠨዖ")				:hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠧๆ๊ๅ฽ࠥอ๊อ์ࠣฬ๏ูสࠡ࠴ࠪ዗")
	,YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠨࡧࡪࡽࡧ࡫ࡳࡵ࠵ࠪዘ")				:EMO8gy4LrsNTh0knZwpSeU75APW(u"่ࠩ์็฿ࠠศ์ฯ๎ࠥฮ๊ิฬࠣ࠷ࠬዙ")
	,YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠪࡩ࡬ࡿࡢࡦࡵࡷ࠸ࠬዚ")				:FRYcH4KL7e9gv5pEB(u"๊ࠫ๎โฺࠢส๎ั๐ࠠษ์ึฮࠥ࠺ࠧዛ")
	,y6y5HtgXO4TkUbwVZ(u"ࠬ࡫ࡧࡺࡤࡨࡷࡹࡼࡩࡱࠩዜ")			:xpT28sXu051(u"࠭ๅ้ไ฼ࠤฬ๐ฬ๋ࠢห๎ุะࠠࡷ࡫ࡳࠫዝ")
	,GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠧࡦࡩࡼࡨࡪࡧࡤࠨዞ")				:L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠨ็๋ๆ฾ࠦล๋ฮํࠤิ๐ฯࠨዟ")
	,ZchUJdM93pTA7zG5(u"ࠩࡨ࡫ࡾࡴ࡯ࡸࠩዠ")				:vODxLKW5Ql6r4Fbm8(u"้ࠪํู่ࠡวํะ๏ࠦๆศ๊ࠪዡ")
	,UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠫࡪࡲࡣࡪࡰࡨࡱࡦ࠭ዢ")				:jXE2YHkswT8y(u"๋่ࠬใ฻้ࠣํฺู่หࠣหู้๊็็สࠫዣ")
	,jXE2YHkswT8y(u"࠭ࡥ࡭࡫ࡩࡺ࡮ࡪࡥࡰࠩዤ")			:CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠧๆ๊ๅ฽ࠥษไ๋ใࠣๅ๏ี๊้ࠩዥ")
	,HtK4o2sTPgA78U(u"ࠨࡨࡤࡦࡷࡧ࡫ࡢࠩዦ")				:SaB5hx3PZwXRLtKgrTfQvId(u"่ࠩ์็฿ࠠโสิ็ฮ࠭ዧ")
	,hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠪࡪࡦ࡯࡬ࡦࡦࠪየ")				:ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠫๆฺไࠨዩ")
	,tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠬ࡬ࡡ࡫ࡧࡵࡷ࡭ࡵࡷࠨዪ")			:PtkEvXAqif14G20QZsaSyT(u"࠭ๅ้ไ฼ࠤๆาัࠡึ๋ࠫያ")
	,y6y5HtgXO4TkUbwVZ(u"ࠧࡧࡣࡵࡩࡸࡱ࡯ࠨዬ")				:XrTw01KtLzbpoyMf(u"ࠨ็๋ๆ฾ࠦแศำึ็ํ࠭ይ")
	,JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠩࡩࡥࡸ࡫࡬ࡩࡦ࠴ࠫዮ")				:ZchUJdM93pTA7zG5(u"้ࠪํู่ࠡใสู้ࠦวๅล๋่ࠬዯ")
	,AbqCJZdWQP9j(u"ࠫ࡫ࡧࡳࡦ࡮࡫ࡨ࠷࠭ደ")				:AbqCJZdWQP9j(u"๋่ࠬใ฻ࠣๅฬ฻ไࠡษ็ฯฬ์๊ࠨዱ")
	,GGx4qyKP1vUtRghsE2WfaHLMXZ(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ዲ")				:MgP8OjoaiWQEVG59(u"ࠧๆฮ็ำࠬዳ")
	,XrTw01KtLzbpoyMf(u"ࠨࡨࡲࡷࡹࡧࠧዴ")				:TlGXWLYsV1z(u"่ࠩ์็฿ࠠโ๊ึฮฬ࠭ድ")
	,Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠪࡪࡺࡴ࡯࡯ࡶࡹࠫዶ")				:L90uqo28xEKSFUwYTcm51yRWZIkft(u"๊ࠫ๎โฺࠢไ๊ํ์ࠠห์ไ๎ࠬዷ")
	,hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠬ࡬ࡵࡴࡪࡤࡶࡹࡼࠧዸ")				:EMO8gy4LrsNTh0knZwpSeU75APW(u"࠭ๅ้ไ฼ࠤๆ๎ิศำࠣฮ๏็๊ࠨዹ")
	,xpT28sXu051(u"ࠧࡧࡷࡶ࡬ࡦࡸࡶࡪࡦࡨࡳࠬዺ")			:vODxLKW5Ql6r4Fbm8(u"ࠨ็๋ๆ฾ࠦแ้ึสีࠥ็๊ะ์๋ࠫዻ")
	,HtK4o2sTPgA78U(u"ࠩࡪࡳࡴࡪࠧዼ")					:GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠪะ๏ีࠧዽ")
	,UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠫ࡭ࡧ࡬ࡢࡥ࡬ࡱࡦ࠭ዾ")				:MgP8OjoaiWQEVG59(u"๋่ࠬใ฻๋้ࠣอࠠิ์่หࠬዿ")
	,PtkEvXAqif14G20QZsaSyT(u"࠭ࡨࡦ࡮ࡤࡰࠬጀ")				:hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠧๆ๊ๅ฽ࠥํไศๆࠣ๎ํะ๊้สࠪጁ")
	,SaB5hx3PZwXRLtKgrTfQvId(u"ࠨ࡫ࡩ࡭ࡱࡳࠧጂ")				:EMO8gy4LrsNTh0knZwpSeU75APW(u"่ࠩ์็฿ࠠใ่สอࠥศ๊ࠡใํ่๊࠭ጃ")
	,uuExaKGL7UONtevRd(u"ࠪ࡭࡫࡯࡬࡮࠯ࡤࡶࡦࡨࡩࡤࠩጄ")			:MgP8OjoaiWQEVG59(u"๊ࠫ๎โฺࠢๅ๊ฬฯࠠร์ࠣๅ๏๊ๅࠡ฻ิฬ๏࠭ጅ")
	,HtK4o2sTPgA78U(u"ࠬ࡯ࡦࡪ࡮ࡰ࠱ࡪࡴࡧ࡭࡫ࡶ࡬ࠬጆ")		:ZchUJdM93pTA7zG5(u"࠭ๅ้ไ฼ࠤ็์วสࠢล๎ࠥ็๊ๅ็ࠣห๋าไ๋ิํࠫጇ")
	,YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠧࡪࡲࡷࡺࠬገ")					:PtkEvXAqif14G20QZsaSyT(u"ࠨࡋࡓࡘ࡛࠭ጉ")
	,Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠩ࡬ࡴࡹࡼ࠭࡭࡫ࡹࡩࠬጊ")			:Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠪࡍࡕ࡚ࡖࠡไ้์ฬะࠧጋ")
	,Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠫ࡮ࡶࡴࡷ࠯ࡰࡳࡻ࡯ࡥࡴࠩጌ")			:CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠬࡏࡐࡕࡘࠣวๆ๊วๆࠩግ")
	,ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"࠭ࡩࡱࡶࡹ࠱ࡸ࡫ࡲࡪࡧࡶࠫጎ")			:FRYcH4KL7e9gv5pEB(u"ࠧࡊࡒࡗ๋࡚ࠥำๅี็หฯ࠭ጏ")
	,vODxLKW5Ql6r4Fbm8(u"ࠨ࡭ࡤࡶࡧࡧ࡬ࡢࡶࡹࠫጐ")			:FRYcH4KL7e9gv5pEB(u"่ࠩ์็฿ࠠใ่สอ้ࠥัษๆสลࠬ጑")
	,UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠪ࡯ࡦࡺ࡫ࡰࡶࡷࡺࠬጒ")				:IpC4qHXRuyNFjzWv(u"๊ࠫ๎โฺࠢๆฮ่๎สࠡฬํๅ๏࠭ጓ")
	,ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠬࡱࡡࡵ࡭ࡲࡹࡹ࡫ࠧጔ")				:L90uqo28xEKSFUwYTcm51yRWZIkft(u"࠭ๅ้ไ฼ࠤ่ะใ้ฬࠪጕ")
	,SaB5hx3PZwXRLtKgrTfQvId(u"ࠧ࡬࡫ࡵࡱࡦࡲ࡫ࠨ጖")				:MgP8OjoaiWQEVG59(u"ࠨ็๋ๆ฾ࠦใา็ส่่࠭጗")
	,MgP8OjoaiWQEVG59(u"ࠩ࡯ࡥࡷࡵࡺࡢࠩጘ")				:tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"้ࠪํู่ࠡๆสีํุวࠨጙ")
	,CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠫࡱ࡯ࡢࡳࡣࡵࡽࠬጚ")				:hhQwbeiNLoqFjX90fB7aG8VAs(u"๋ࠬไโࠩጛ")
	,UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"࠭࡬ࡪࡸࡨࠫጜ")					:zmcGfOdvAjsELeJlP(u"ࠧใ่สอࠬጝ")
	,ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠨ࡮࡬ࡺࡪࡺࡶࠨጞ")				:MgP8OjoaiWQEVG59(u"่่ࠩๆ࠭ጟ")
	,ZchUJdM93pTA7zG5(u"ࠪࡰࡴࡪࡹ࡯ࡧࡷࠫጠ")				:y6y5HtgXO4TkUbwVZ(u"๊ࠫ๎โฺࠢ็์ิ๐ࠠ็ฬࠪጡ")
	,ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠬࡳ࠳ࡶࠩጢ")					:xpT28sXu051(u"࠭ࡍ࠴ࡗࠪጣ")
	,GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠧ࡮࠵ࡸ࠱ࡱ࡯ࡶࡦࠩጤ")				:ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠨࡏ࠶่࡙ࠥๆ้ษอࠫጥ")
	,HtK4o2sTPgA78U(u"ࠩࡰ࠷ࡺ࠳࡭ࡰࡸ࡬ࡩࡸ࠭ጦ")			:hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠪࡑ࠸࡛ࠠฤใ็ห๊࠭ጧ")
	,vODxLKW5Ql6r4Fbm8(u"ࠫࡲ࠹ࡵ࠮ࡵࡨࡶ࡮࡫ࡳࠨጨ")			:JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠬࡓ࠳ࡖ่ࠢืู้ไศฬࠪጩ")
	,jXE2YHkswT8y(u"࠭࡭ࡢࡵࡤࡺ࡮ࡪࡥࡰࠩጪ")			:uuExaKGL7UONtevRd(u"ࠧๆ๊ๅ฽๋ࠥวิษࠣๅ๏ี๊้ࠩጫ")
	,ZchUJdM93pTA7zG5(u"ࠨ࡯࡬ࡷࡸ࡯࡮ࡨࠩጬ")				:xpT28sXu051(u"่ࠩๅ็๎ฯࠨጭ")
	,tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠪࡱࡴࡼࡳ࠵ࡷࠪጮ")				:UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"๊ࠫ๎โฺ่ࠢ์ๆุࠠโ๊ิ๎ํ࠭ጯ")
	,jXE2YHkswT8y(u"ࠬࡳࡹࡤ࡫ࡰࡥࠬጰ")				:XrTw01KtLzbpoyMf(u"࠭ๅ้ไ฼ࠤ๊อ๊ࠡีํ้ฬ࠭ጱ")
	,yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠧࡰ࡮ࡧࠫጲ")					:zmcGfOdvAjsELeJlP(u"ࠨไา๎๊࠭ጳ")
	,tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠩࡳࡥࡳ࡫ࡴࠨጴ")				:FRYcH4KL7e9gv5pEB(u"้ࠪํู่ࠡสส๊๏ะࠧጵ")
	,tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠫࡵࡧ࡮ࡦࡶ࠰ࡱࡴࡼࡩࡦࡵࠪጶ")			:hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"๋่ࠬใ฻ࠣฬฬ์๊หࠢสๅ้อๅࠨጷ")
	,L90uqo28xEKSFUwYTcm51yRWZIkft(u"࠭ࡰࡢࡰࡨࡸ࠲ࡹࡥࡳ࡫ࡨࡷࠬጸ")			:PtkEvXAqif14G20QZsaSyT(u"ࠧๆ๊ๅ฽ࠥฮว็์อࠤู๊ไิๆสฮࠬጹ")
	,EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠨࡳࡩ࡭ࡱࡳࠧጺ")				:PtkEvXAqif14G20QZsaSyT(u"่ࠩ์็฿ࠠไ์๋ࠤๆ๐ไๆࠩጻ")
	,HtK4o2sTPgA78U(u"ࠪࡷࡪࡸࡩࡦࡵࡷ࡭ࡲ࡫ࠧጼ")			:ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"๊ࠫ๎โฺࠢึ๎ึ๐ำࠡฬส๎๊࠭ጽ")
	,GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠬࡹࡨࡢࡤࡤ࡯ࡦࡺࡹࠨጾ")			:FRYcH4KL7e9gv5pEB(u"࠭ๅ้ไ฼ࠤูฮให์ࠪጿ")
	,hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠧࡴࡪࡤ࡬࡮ࡪ࠴ࡶࠩፀ")				:ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠨ็๋ๆ฾ࠦิศ้าࠤๆ๎ั๋๊ࠪፁ")
	,AbqCJZdWQP9j(u"ࠩࡶ࡬ࡦ࡮ࡩࡥࡰࡨࡻࡸ࠭ፂ")			:xpT28sXu051(u"้ࠪํู่ࠡึส๋ิࠦๆ๋๊ีࠫፃ")
	,YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠫࡸ࡮ࡩࡢࡸࡲ࡭ࡨ࡫ࠧፄ")			:ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"๋่ࠬใ฻ูࠣํะࠠศๆื๎฾ฯࠧፅ")
	,sVzojQerUqX(u"࠭ࡳࡩ࡫ࡤࡺࡴ࡯ࡣࡦ࠯ࡤࡰࡧࡻ࡭ࡴࠩፆ")		:zmcGfOdvAjsELeJlP(u"ࠧๆ๊ๅ฽ࠥ฻่หࠢสู่๐ูสࠢส่อ๎ๅࠨፇ")
	,UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠨࡵ࡫࡭ࡦࡼ࡯ࡪࡥࡨ࠱ࡦࡻࡤࡪࡱࡶࠫፈ")		:ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"่ࠩ์็฿ࠠึ๊อࠤฬ๊ิ๋฻ฬࠤฺ๎ส๋ษอࠫፉ")
	,PtkEvXAqif14G20QZsaSyT(u"ࠪࡷ࡭࡯ࡡࡷࡱ࡬ࡧࡪ࠳ࡰࡦࡴࡶࡳࡳࡹࠧፊ")	:yJeq1BjfiO4NFuwIEzxVLK6b9s(u"๊ࠫ๎โฺุࠢ์ฯࠦวๅึํ฽ฮࠦโศำษࠫፋ")
	,sVzojQerUqX(u"ࠬࡹࡨࡰࡨ࡫ࡥࠬፌ")				:IpC4qHXRuyNFjzWv(u"࠭ๅ้ไ฼ࠤู๎แ่ษࠣฮ๏็๊ࠨፍ")
	,LyNiIHPOwD3hCUYEFM7(u"ࠧࡴࡪࡲࡳ࡫ࡳࡡࡹࠩፎ")				:IpC4qHXRuyNFjzWv(u"ࠨ็๋ๆ฾ࠦิ้ใ้ࠣฬ้ำࠨፏ")
	,HtK4o2sTPgA78U(u"ࠩࡶ࡬ࡴࡵࡦ࡯ࡧࡷࠫፐ")				:Y41NvKfOroMzGB8sEHy7wbXlc5(u"้ࠪํู่ࠡึ๋ๅࠥ์สࠨፑ")
	,EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠫࡸ࡮࡯ࡰࡨࡳࡶࡴ࠭ፒ")				:MgP8OjoaiWQEVG59(u"๋่ࠬใ฻ุࠣํ็ࠠษำ๋ࠫፓ")
	,SaB5hx3PZwXRLtKgrTfQvId(u"࠭ࡴࡪ࡭ࡤࡥࡹ࠭ፔ")				:UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠧๆ๊ๅ฽ࠥะใศฬࠪፕ")
	,CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠨࡶࡹࡪࡺࡴࠧፖ")				:MgP8OjoaiWQEVG59(u"่ࠩ์็฿ࠠห์ไ๎ࠥ็ว็ࠩፗ")
	,EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠪࡺࡦࡸࡢࡰࡰࠪፘ")				:YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"๊ࠫ๎โฺࠢไหึฮ่็ࠩፙ")
	,AbqCJZdWQP9j(u"ࠬࡼࡩࡥࡧࡲࠫፚ")				:uuExaKGL7UONtevRd(u"࠭แ๋ัํ์ࠬ፛")
	,L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠧࡷ࡫ࡧࡩࡴࡴࡳࡢࡧࡰࠫ፜")			:HtK4o2sTPgA78U(u"ࠨ็๋ๆ฾ࠦแ๋ัํ์ࠥ์ำศศ่ࠫ፝")
	,L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠩࡺࡩࡨ࡯࡭ࡢ࠳ࠪ፞")				:tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"้ࠪํู่๊ࠡํࠤุ๐ๅศࠢ࠴ࠫ፟")
	,CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠫࡼ࡫ࡣࡪ࡯ࡤ࠶ࠬ፠")				:FRYcH4KL7e9gv5pEB(u"๋่ࠬใ฻ࠣ์๏ࠦำ๋็สࠤ࠷࠭፡")
	,TlGXWLYsV1z(u"࠭ࡹࡢࡳࡲࡸࠬ።")				:IpC4qHXRuyNFjzWv(u"ࠧๆ๊ๅ฽ࠥ๐วใ๊อࠫ፣")
	,ZchUJdM93pTA7zG5(u"ࠨࡻࡲࡹࡹࡻࡢࡦࠩ፤")				:uuExaKGL7UONtevRd(u"่ࠩ์็฿๋๊ࠠอ๎ํฮࠧ፥")
	,GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠪࡽࡴࡻࡴࡶࡤࡨ࠱ࡨ࡮ࡡ࡯ࡰࡨࡰࡸ࠭፦")		:AbqCJZdWQP9j(u"๊ࠫ๎โฺࠢํ์ฯ๐่ษࠢๅ๊ํอสࠨ፧")
	,y6y5HtgXO4TkUbwVZ(u"ࠬࡿ࡯ࡶࡶࡸࡦࡪ࠳ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡴࠩ፨")	:Y41NvKfOroMzGB8sEHy7wbXlc5(u"࠭ๅ้ไ฼ࠤ๏๎ส๋๊หࠤ็๎วว็ࠪ፩")
	,Y41NvKfOroMzGB8sEHy7wbXlc5(u"ࠧࡺࡱࡸࡸࡺࡨࡥ࠮ࡸ࡬ࡨࡪࡵࡳࠨ፪")		:EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠨ็๋ๆ฾๊้ࠦฬํ์อࠦแ๋ัํ์์อสࠨ፫")
	,jXE2YHkswT8y(u"ࠩࡼࡸࡧࡥࡣࡩࡣࡱࡲࡪࡲࡳࠨ፬")			:MgP8OjoaiWQEVG59(u"้ࠪํอโฺ่๊ࠢࠥ๐่ห์๋ฬࠬ፭")
	}
	aknGye5UoSKFd4D39ziBOlsWj1C6v2 = XiWJ2PTqvds4pBNebVrt98x.lower()
	for key in list(I6ZPeV1pv4O0Utwn.keys()):
		AobrXV6t8fLnCRZI1d4BzDqUN09wO = key.lower()
		if aknGye5UoSKFd4D39ziBOlsWj1C6v2==AobrXV6t8fLnCRZI1d4BzDqUN09wO:
			XiWJ2PTqvds4pBNebVrt98x = I6ZPeV1pv4O0Utwn[key]
			break
	return XiWJ2PTqvds4pBNebVrt98x
def KEPGn8jNAtmDB2yS0kZiX4MCw():
	tqC0PngwO4pA = WwMgozBIC32n9d0tyfp.executeJSONRPC(SaB5hx3PZwXRLtKgrTfQvId(u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠣ࡫ࡧࠦ࠿࠷ࠬࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡔࡱࡧࡹ࡭࡫ࡶࡸ࠳ࡉ࡬ࡦࡣࡵࠦ࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡳࡰࡦࡿ࡬ࡪࡵࡷ࡭ࡩࠨ࠺࠲ࡿࢀࠫ፮"))
	raise ValueError(CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"ࠬࡥ࡟ࡠࡈࡒࡖࡈࡋ࡟ࡆ࡚ࡌࡘࡤࡥ࡟ࠨ፯"))
def SqMHwb6X1Ph8jY7LBNkmtV4F5Jlspy(S6EvTRBc7k2mbxQ1OjpUqDf,UUy21VnCQhZpbco76SJ=iiy37aKq0pCEIOwfcTh61xb4U):
	global ef74aPgdcbQFAnGok9thpBwY8m06
	ef74aPgdcbQFAnGok9thpBwY8m06 = rGPen6cSMHQkAywh8vqI9JXiD2
	if not UUy21VnCQhZpbco76SJ and S6EvTRBc7k2mbxQ1OjpUqDf: UUy21VnCQhZpbco76SJ = XrTw01KtLzbpoyMf(u"࠭ࡒࡆࡓࡘࡉࡘ࡚࡟ࡓࡇࡉࡖࡊ࡙ࡈࡠࡅࡄࡇࡍࡋࠧ፰")
	OXsckY7RzjCag9A.setSetting(UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡶࡪ࡬ࡲࡦࡵ࡫ࠫ፱"),UUy21VnCQhZpbco76SJ)
	return
def YqdaDIig21wBTWJeUHbc(smglbwR7x2oM,jscBpTJGqS4wr=AbqCJZdWQP9j(u"ࠨ࠼࠲ࠫ፲")):
	return _9hcm7SBKxOpwtMzXv0W(smglbwR7x2oM,jscBpTJGqS4wr)
def bbFB9IqCjgwnHslZLk4Dp87Yr(xjcbhOeEASYd1):
	if xjcbhOeEASYd1 in [iiy37aKq0pCEIOwfcTh61xb4U,yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠩ࠳ࠫ፳"),FGTfwsjNrB8DvKSZhLIQAb1JnO]: return iiy37aKq0pCEIOwfcTh61xb4U
	xjcbhOeEASYd1 = int(xjcbhOeEASYd1)
	PhnyaHoYN248wUVvzJeMguDlAKdGx5 = xjcbhOeEASYd1^Dxc7GChQwZ4kOlKHSbL06agnB
	EEwBQqcxsKlnSVfOMa3ZpjudX6i = xjcbhOeEASYd1^PNjZMS7nxa9clHusz1
	vvxLKEVDWg4Sy6B8wdlFr7i = xjcbhOeEASYd1^r3rnfZ7cdxzNFebIRaLSG6B
	rG7qcgNWkxbzPwp6iLS9 = str(PhnyaHoYN248wUVvzJeMguDlAKdGx5)+str(EEwBQqcxsKlnSVfOMa3ZpjudX6i)+str(vvxLKEVDWg4Sy6B8wdlFr7i)
	return rG7qcgNWkxbzPwp6iLS9
def qrlgOVWEySGpCMnJw8QX(xjcbhOeEASYd1):
	if xjcbhOeEASYd1 in [iiy37aKq0pCEIOwfcTh61xb4U,uuExaKGL7UONtevRd(u"ࠪ࠴ࠬ፴"),FGTfwsjNrB8DvKSZhLIQAb1JnO]: return iiy37aKq0pCEIOwfcTh61xb4U
	xjcbhOeEASYd1 = str(xjcbhOeEASYd1)
	rG7qcgNWkxbzPwp6iLS9 = iiy37aKq0pCEIOwfcTh61xb4U
	if len(xjcbhOeEASYd1)==vODxLKW5Ql6r4Fbm8(u"࠶࠻ᕋ"):
		PhnyaHoYN248wUVvzJeMguDlAKdGx5,EEwBQqcxsKlnSVfOMa3ZpjudX6i,vvxLKEVDWg4Sy6B8wdlFr7i = xjcbhOeEASYd1[FGTfwsjNrB8DvKSZhLIQAb1JnO:pZWli1xqfVtvzuSU6ImNw53gBFsh],xjcbhOeEASYd1[pZWli1xqfVtvzuSU6ImNw53gBFsh:hhQwbeiNLoqFjX90fB7aG8VAs(u"࠿ᕌ")],xjcbhOeEASYd1[hhQwbeiNLoqFjX90fB7aG8VAs(u"࠿ᕌ"):]
		PhnyaHoYN248wUVvzJeMguDlAKdGx5 = int(PhnyaHoYN248wUVvzJeMguDlAKdGx5)^r3rnfZ7cdxzNFebIRaLSG6B
		EEwBQqcxsKlnSVfOMa3ZpjudX6i = int(EEwBQqcxsKlnSVfOMa3ZpjudX6i)^PNjZMS7nxa9clHusz1
		vvxLKEVDWg4Sy6B8wdlFr7i = int(vvxLKEVDWg4Sy6B8wdlFr7i)^Dxc7GChQwZ4kOlKHSbL06agnB
		if PhnyaHoYN248wUVvzJeMguDlAKdGx5==EEwBQqcxsKlnSVfOMa3ZpjudX6i==vvxLKEVDWg4Sy6B8wdlFr7i: rG7qcgNWkxbzPwp6iLS9 = str(PhnyaHoYN248wUVvzJeMguDlAKdGx5*zmcGfOdvAjsELeJlP(u"࠶࠱ᕍ"))
	return rG7qcgNWkxbzPwp6iLS9
def kTJISUV1CbZQ2gndAuMwBP7(xjcbhOeEASYd1,JgQrtN9mElhPBo3ZsF2XUkMbHvWjK=YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠫ࠻࠹࠸࠵࠳࠻࠶࠸࠭፵")):
	if xjcbhOeEASYd1==iiy37aKq0pCEIOwfcTh61xb4U: return iiy37aKq0pCEIOwfcTh61xb4U
	xjcbhOeEASYd1 = int(xjcbhOeEASYd1)+int(JgQrtN9mElhPBo3ZsF2XUkMbHvWjK)
	PhnyaHoYN248wUVvzJeMguDlAKdGx5 = xjcbhOeEASYd1^Dxc7GChQwZ4kOlKHSbL06agnB
	EEwBQqcxsKlnSVfOMa3ZpjudX6i = xjcbhOeEASYd1^PNjZMS7nxa9clHusz1
	vvxLKEVDWg4Sy6B8wdlFr7i = xjcbhOeEASYd1^r3rnfZ7cdxzNFebIRaLSG6B
	rG7qcgNWkxbzPwp6iLS9 = str(PhnyaHoYN248wUVvzJeMguDlAKdGx5)+str(EEwBQqcxsKlnSVfOMa3ZpjudX6i)+str(vvxLKEVDWg4Sy6B8wdlFr7i)
	return rG7qcgNWkxbzPwp6iLS9
def X3IPqeaH8zOYn(xjcbhOeEASYd1,JgQrtN9mElhPBo3ZsF2XUkMbHvWjK=jXE2YHkswT8y(u"ࠬ࠼࠳࠹࠶࠴࠼࠷࠹ࠧ፶")):
	if xjcbhOeEASYd1==iiy37aKq0pCEIOwfcTh61xb4U: return iiy37aKq0pCEIOwfcTh61xb4U
	xjcbhOeEASYd1 = str(xjcbhOeEASYd1)
	iiKw16BHkPTU = int(len(xjcbhOeEASYd1)/iiCWLaJREureAlOkv)
	PhnyaHoYN248wUVvzJeMguDlAKdGx5 = int(xjcbhOeEASYd1[FGTfwsjNrB8DvKSZhLIQAb1JnO:iiKw16BHkPTU])^Dxc7GChQwZ4kOlKHSbL06agnB
	EEwBQqcxsKlnSVfOMa3ZpjudX6i = int(xjcbhOeEASYd1[iiKw16BHkPTU:nI2JK1RfsGWNY3OarEeMQZ*iiKw16BHkPTU])^PNjZMS7nxa9clHusz1
	vvxLKEVDWg4Sy6B8wdlFr7i = int(xjcbhOeEASYd1[nI2JK1RfsGWNY3OarEeMQZ*iiKw16BHkPTU:iiCWLaJREureAlOkv*iiKw16BHkPTU])^r3rnfZ7cdxzNFebIRaLSG6B
	rG7qcgNWkxbzPwp6iLS9 = iiy37aKq0pCEIOwfcTh61xb4U
	if PhnyaHoYN248wUVvzJeMguDlAKdGx5==EEwBQqcxsKlnSVfOMa3ZpjudX6i==vvxLKEVDWg4Sy6B8wdlFr7i: rG7qcgNWkxbzPwp6iLS9 = str(int(PhnyaHoYN248wUVvzJeMguDlAKdGx5)-int(JgQrtN9mElhPBo3ZsF2XUkMbHvWjK))
	return rG7qcgNWkxbzPwp6iLS9
def YmERob4iJnGaBC3HylOV9PKu1I(ZjgeiO5lGA4DQRuJEM):
	GGful29tv0EjXdVaWmgwzH8QMSh = gZ4LwbKaOm[vODxLKW5Ql6r4Fbm8(u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭፷")][CCUzMTgQjrHntoiGf16LXW5P8EdVu(u"࠹ᕎ")]
	KOWmMZPVpzoaN93ghT5ibx1Hfq = wkMR5x1gTWEQIc6qHCa.path.join(V5f96hvSkeUwCxZrE4dlzpy,XrTw01KtLzbpoyMf(u"ࠧࡳࡧࡶࡳࡺࡸࡣࡦࡵࠪ፸"),UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠨࡵ࡮࡭ࡳࡹࠧ፹"),tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠩࡇࡩ࡫ࡧࡵ࡭ࡶࠪ፺"),hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠪ࠻࠷࠶ࡰࠨ፻"),sVzojQerUqX(u"ࠫࡉ࡯ࡡ࡭ࡱࡪࡇࡴࡴࡦࡪࡴࡰࡘ࡭ࡸࡥࡦࡄࡸࡸࡹࡵ࡮ࡴ࠰ࡻࡱࡱ࠭፼"))
	NuEVpKLjPYq7mbASMw,klHivPBzpwJT5sXf = MZ0QpfA1jaJgoWO2IndU(KOWmMZPVpzoaN93ghT5ibx1Hfq)
	NuEVpKLjPYq7mbASMw = kTJISUV1CbZQ2gndAuMwBP7(NuEVpKLjPYq7mbASMw,FRYcH4KL7e9gv5pEB(u"ࠬ࠷࠲࠲࠺࠶࠵࠽࠻࠳ࠨ፽"))
	HDp6E7Chf9LTYZMs1qKzbSPa3FUm = {ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"࠭ࡩࡥࡵࠪ፾"):HtK4o2sTPgA78U(u"ࠧࡅࡋࡄࡐࡔࡍࠧ፿"),SaB5hx3PZwXRLtKgrTfQvId(u"ࠨࡷࡶࡶࠬᎀ"):iw3BpJl1Y9tbg8XMR4VeoS6kEUhf,AbqCJZdWQP9j(u"ࠩࡹࡩࡷ࠭ᎁ"):DdAjF5pBNL9IqPgkz0xhcQEfU,ZchUJdM93pTA7zG5(u"ࠪࡷࡨࡸࠧᎂ"):ZjgeiO5lGA4DQRuJEM,tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠫࡸ࡯ࡺࠨᎃ"):NuEVpKLjPYq7mbASMw}
	pZk9CmnsujW7AKE5VP1R = {PtkEvXAqif14G20QZsaSyT(u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫᎄ"):SaB5hx3PZwXRLtKgrTfQvId(u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࠬᎅ")}
	mVl7kPK4H2egMsuBpZiy = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,jXE2YHkswT8y(u"ࠧࡑࡑࡖࡘࠬᎆ"),GGful29tv0EjXdVaWmgwzH8QMSh,HDp6E7Chf9LTYZMs1qKzbSPa3FUm,pZk9CmnsujW7AKE5VP1R,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,sVzojQerUqX(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡖࡌࡔ࡝࡟ࡑࡎࡄ࡝ࡤࡊࡉࡂࡎࡒࡋ࠲࠷ࡳࡵࠩᎇ"))
	cq0kN2XGrKxevU = mVl7kPK4H2egMsuBpZiy.content
	try:
		if not cq0kN2XGrKxevU: lq1nObGTKWz
		deXo6AyfiEa = DeIL3qoa2UBtYPb(L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠩࡧ࡭ࡨࡺࠧᎈ"),cq0kN2XGrKxevU)
		X12FU8Luoy0HlxiNQBbS67ThGPtsk = deXo6AyfiEa[vODxLKW5Ql6r4Fbm8(u"ࠪࡱࡸ࡭ࠧᎉ")]
		Q4xlDPkda603ZsV7IgmNfLbSuY2er8 = deXo6AyfiEa[MgP8OjoaiWQEVG59(u"ࠫࡸ࡫ࡣࠨᎊ")]
		mK1NdTDWbtnaLFJHeXP6p2wv = deXo6AyfiEa[hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"ࠬࡹࡴࡱࠩᎋ")]
		Q4xlDPkda603ZsV7IgmNfLbSuY2er8 = int(X3IPqeaH8zOYn(Q4xlDPkda603ZsV7IgmNfLbSuY2er8,y6y5HtgXO4TkUbwVZ(u"࠭࠱࠳࠳࠻࠷࠶࠾࠵࠴ࠩᎌ")))
		mK1NdTDWbtnaLFJHeXP6p2wv = int(X3IPqeaH8zOYn(mK1NdTDWbtnaLFJHeXP6p2wv,FRYcH4KL7e9gv5pEB(u"ࠧ࠲࠴࠴࠼࠸࠷࠸࠶࠵ࠪᎍ")))
		for TAs9qNFJ1hx78K in range(Q4xlDPkda603ZsV7IgmNfLbSuY2er8,FGTfwsjNrB8DvKSZhLIQAb1JnO,-mK1NdTDWbtnaLFJHeXP6p2wv):
			if not eval(L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠨࡺࡥࡱࡨ࠴ࡐ࡭ࡣࡼࡩࡷ࠮ࠩ࠯࡫ࡶࡔࡱࡧࡹࡪࡰࡪࠬ࠮࠭ᎎ"),{ewqNSF2CyG5xsmh6v1AuKOaYfHrL7n(u"ࠩࡻࡦࡲࡩࠧᎏ"):WwMgozBIC32n9d0tyfp}): lq1nObGTKWz
			YYkhEn5xTXLUevzCVNB16mR(yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠪฬฬ่๊ࠡๆ็ฮัืศส๋ࠢห้็อึࠩ᎐"),str(TAs9qNFJ1hx78K)+PtkEvXAqif14G20QZsaSyT(u"ࠫࠥࠦหศ่ํอࠬ᎑"),X2cQ5NCPvkMieBW7oASspFjE=hhQwbeiNLoqFjX90fB7aG8VAs(u"࠵࠳࠴ᕏ")*mK1NdTDWbtnaLFJHeXP6p2wv)
			WwMgozBIC32n9d0tyfp.sleep(SaB5hx3PZwXRLtKgrTfQvId(u"࠴࠴࠵࠶ᕐ")*mK1NdTDWbtnaLFJHeXP6p2wv)
		if eval(MgP8OjoaiWQEVG59(u"ࠬࡾࡢ࡮ࡥ࠱ࡔࡱࡧࡹࡦࡴࠫ࠭࠳࡯ࡳࡑ࡮ࡤࡽ࡮ࡴࡧࠩࠫࠪ᎒"),{hhqd6cnfNJiAaLKTPbst5RpMmZF2G(u"࠭ࡸࡣ࡯ࡦࠫ᎓"):WwMgozBIC32n9d0tyfp}):
			X12FU8Luoy0HlxiNQBbS67ThGPtsk = X12FU8Luoy0HlxiNQBbS67ThGPtsk.replace(OTlVEGYPSxsNaBdXUucqA3,MgP8OjoaiWQEVG59(u"ࠧ࡝࡞ࡱࠫ᎔")).replace(Mge0HhFk9Ic6sm5VR,EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠨ࡞࡟ࡶࠬ᎕"))
			bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,sVzojQerUqX(u"ࠩัีําࠧ᎖"),TlGXWLYsV1z(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭᎗"),X12FU8Luoy0HlxiNQBbS67ThGPtsk)
		lq1nObGTKWz
	except: exec(XrTw01KtLzbpoyMf(u"ࠫࡽࡨ࡭ࡤ࠰ࡓࡰࡦࡿࡥࡳࠪࠬ࠲ࡸࡺ࡯ࡱࠪࠬࠫ᎘"),{LyNiIHPOwD3hCUYEFM7(u"ࠬࡾࡢ࡮ࡥࠪ᎙"):WwMgozBIC32n9d0tyfp})
	return
def SmXxLw7l2gIUR9zF83hTNdpMaA6i():
	exec(PtkEvXAqif14G20QZsaSyT(u"࠭ࠧࠨࠏࠍࡸࡷࡿ࠺ࠎࠌࠌࡻ࡮ࡴࡤࡰࡹ࠴࠶࠸ࠦ࠽ࠡࡺࡥࡱࡨ࡭ࡵࡪ࠰࡚࡭ࡳࡪ࡯ࡸࠪ࠴࠴࠵࠸࠵ࠪࠏࠍࠍࡼ࡮ࡩ࡭ࡧࠣࡘࡷࡻࡥ࠻ࠏࠍࠍࠎࡾࡢ࡮ࡥ࠱ࡷࡱ࡫ࡥࡱࠪ࠴࠴࠵࠶ࠩࠎࠌࠌࠍࡹࡸࡹ࠻ࠢࡺ࡭ࡳࡪ࡯ࡸ࠳࠵࠷࠳࡭ࡥࡵࡈࡲࡧࡺࡹࠨ࠲࠲࠳࠶࠺࠯ࠍࠋࠋࠌࡩࡽࡩࡥࡱࡶ࠽ࠤࡧࡸࡥࡢ࡭ࠐࠎࠎࢀࡣࡳࡧࡤࡸࡪࡥࡥࡳࡱࡵࡶࠒࠐࡥࡹࡥࡨࡴࡹࡀࠠࡹࡤࡰࡧ࠳ࡖ࡬ࡢࡻࡨࡶ࠭࠯࠮ࡴࡶࡲࡴ࠭࠯ࠍࠋࠩࠪࠫ᎚"),{JZszNnIEMAx28Yao0yqhiXGKOPb(u"ࠧࡹࡤࡰࡧ࡬ࡻࡩࠨ᎛"):OOYtyXB3o8K,IpC4qHXRuyNFjzWv(u"ࠨࡺࡥࡱࡨ࠭᎜"):WwMgozBIC32n9d0tyfp})
	return
def MZ0QpfA1jaJgoWO2IndU(BdluXk6trpsO2bF841jZLgH7nG9c):
	OtJ0V3QBE8zWxSskHMDXj,MH9dDWw6lxUpqcAYzFhveGZoKVQ = FGTfwsjNrB8DvKSZhLIQAb1JnO,FGTfwsjNrB8DvKSZhLIQAb1JnO
	if wkMR5x1gTWEQIc6qHCa.path.exists(BdluXk6trpsO2bF841jZLgH7nG9c):
		try: OtJ0V3QBE8zWxSskHMDXj = wkMR5x1gTWEQIc6qHCa.path.getsize(BdluXk6trpsO2bF841jZLgH7nG9c)
		except: pass
		if not OtJ0V3QBE8zWxSskHMDXj:
			try: OtJ0V3QBE8zWxSskHMDXj = wkMR5x1gTWEQIc6qHCa.stat(BdluXk6trpsO2bF841jZLgH7nG9c).st_size
			except: pass
		if not OtJ0V3QBE8zWxSskHMDXj:
			try:
				from pathlib import Path as PydoQMAUW3GKhuFXZSVc
				OtJ0V3QBE8zWxSskHMDXj = PydoQMAUW3GKhuFXZSVc(BdluXk6trpsO2bF841jZLgH7nG9c).stat().st_size
			except: pass
		if OtJ0V3QBE8zWxSskHMDXj: MH9dDWw6lxUpqcAYzFhveGZoKVQ = YYJQyRskpX8jv
	return OtJ0V3QBE8zWxSskHMDXj,MH9dDWw6lxUpqcAYzFhveGZoKVQ
def KCPY4RcQjwErGfkn8I(jhIpk9ANqbiv3zHeQgwPMSR1sJ,showDialogs):
	if showDialogs:
		U17QqF2gkI46 = A1AXKupEOfz(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,ZchUJdM93pTA7zG5(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ᎝"),jhIpk9ANqbiv3zHeQgwPMSR1sJ+AbqCJZdWQP9j(u"ࠪࡠࡳࡢ࡮ࠨ᎞")+PSwfZcdRYhpl5Igqz8xOEk67+xpT28sXu051(u"ࠫ์๊ࠠหำํำ๋ࠥำฮ๊ࠢิฬࠦวๅ็็ๅࠥลࠡࠨ᎟")+YoQW601K4fMJcsreDnGVE5wUZIy7)
		if U17QqF2gkI46!=jXE2YHkswT8y(u"࠵ᕑ"): return
	Y0yxuvUe5JF9S2NI = BF6QAiLUNHh7rKOugaw
	if wkMR5x1gTWEQIc6qHCa.path.exists(jhIpk9ANqbiv3zHeQgwPMSR1sJ):
		try: wkMR5x1gTWEQIc6qHCa.remove(jhIpk9ANqbiv3zHeQgwPMSR1sJ.decode(df6QpwGxuJVZr))
		except:
			try: wkMR5x1gTWEQIc6qHCa.remove(yyhsK830cXz)
			except Exception as w6KJIEZVobfX0g:
				if showDialogs: bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᎠ"),str(w6KJIEZVobfX0g))
				Y0yxuvUe5JF9S2NI = rGPen6cSMHQkAywh8vqI9JXiD2
	if showDialogs:
		if Y0yxuvUe5JF9S2NI: bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,jXE2YHkswT8y(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᎡ"),YzX407G1m8ER9OBpkeuqPIf6Ajrh5(u"ࠧโึ็ฮࠥ฿ๅๅ์ฬࠤู๊อࠡษ็้้็ࠧᎢ"))
		else:
			bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,EMO8gy4LrsNTh0knZwpSeU75APW(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᎣ"),tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠩอ้ࠥอไๆีะࠤอ์ฬศฯࠪᎤ"))
			SqMHwb6X1Ph8jY7LBNkmtV4F5Jlspy(BF6QAiLUNHh7rKOugaw)
	return
def TAkeulImazNdJwE9(ciZJzmbXEe31429s5LWuIoDRN8t,H7Ir0YbBGPVusz,showDialogs):
	if showDialogs:
		U17QqF2gkI46 = A1AXKupEOfz(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,tKNPiXfQ7HoAqndw3z9IL4E6VrGv1(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭Ꭵ"),ciZJzmbXEe31429s5LWuIoDRN8t+L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠫࡡࡴ࡜࡯ࠩᎦ")+PSwfZcdRYhpl5Igqz8xOEk67+XrTw01KtLzbpoyMf(u"ࠬํไࠡฬิ๎ิࠦๅิฯ๋ࠣีอࠠศๆ่ะ้ีࠠภࠣࠪᎧ")+YoQW601K4fMJcsreDnGVE5wUZIy7)
		if U17QqF2gkI46!=YYJQyRskpX8jv: return
	yy2jWo16LdtRQeMXHZpPJO = BF6QAiLUNHh7rKOugaw
	if wkMR5x1gTWEQIc6qHCa.path.exists(ciZJzmbXEe31429s5LWuIoDRN8t):
		for j4ZIlrBtDAXGEWmLu2VQSs8e5wy7,pLCYwde0WgycRiMu1Xm82Pro7jTx,frKzDoxVINlL397S in wkMR5x1gTWEQIc6qHCa.walk(ciZJzmbXEe31429s5LWuIoDRN8t,topdown=BF6QAiLUNHh7rKOugaw):
			for BdluXk6trpsO2bF841jZLgH7nG9c in frKzDoxVINlL397S:
				lGvCUxi8ZRowBHJDf = wkMR5x1gTWEQIc6qHCa.path.join(j4ZIlrBtDAXGEWmLu2VQSs8e5wy7,BdluXk6trpsO2bF841jZLgH7nG9c)
				try: wkMR5x1gTWEQIc6qHCa.remove(lGvCUxi8ZRowBHJDf)
				except Exception as GklR5ZezV83FJXKnCr6AaT:
					if showDialogs and not yy2jWo16LdtRQeMXHZpPJO: bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᎨ"),str(GklR5ZezV83FJXKnCr6AaT))
					yy2jWo16LdtRQeMXHZpPJO = rGPen6cSMHQkAywh8vqI9JXiD2
			if H7Ir0YbBGPVusz:
				for dir in pLCYwde0WgycRiMu1Xm82Pro7jTx:
					zzUAWOMoFYCVh = wkMR5x1gTWEQIc6qHCa.path.join(j4ZIlrBtDAXGEWmLu2VQSs8e5wy7,dir)
					try: wkMR5x1gTWEQIc6qHCa.rmdir(zzUAWOMoFYCVh)
					except: pass
		if H7Ir0YbBGPVusz:
			try: wkMR5x1gTWEQIc6qHCa.rmdir(j4ZIlrBtDAXGEWmLu2VQSs8e5wy7)
			except: pass
	if showDialogs and not yy2jWo16LdtRQeMXHZpPJO:
		bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᎩ"),AbqCJZdWQP9j(u"ࠨฬ่ࠤฬ๊ๅิฯࠣฬ๋าวฮࠩᎪ"))
		SqMHwb6X1Ph8jY7LBNkmtV4F5Jlspy(BF6QAiLUNHh7rKOugaw)
	return
def paTWAORBQdvnfDjmyMxShugelKzZ8(xZ9qAk7pF3XCKDsOh0SN,bDlzGospmi69Oy1NILPaHMWK8Z3FSw,smglbwR7x2oM,oRzlSfeE6DY0mFy37NCVxAJW1BwZtM,CZGXVf91e3KTpSDqyP6x8otlhLBam2,VamqUtbfFn6MANy):
	eCGwzSrqBmIv,TeLlsNSmcf7FvU3byDkzWAItq5da4R,uuHt2FaeJLp8,KvXWMwZf438UyOnFBlqPDsiIm1c0L = T2TI6RohemNWG4(smglbwR7x2oM)
	YVKo4mpBq9vEeUfM7JR8ujSP = bDlzGospmi69Oy1NILPaHMWK8Z3FSw,eCGwzSrqBmIv,oRzlSfeE6DY0mFy37NCVxAJW1BwZtM,CZGXVf91e3KTpSDqyP6x8otlhLBam2
	if xZ9qAk7pF3XCKDsOh0SN<xpT28sXu051(u"࠵ᕒ"):
		Bcxq3nkvTU9iM(PdkZHNBlpg2b7DmX6qRiyVa,ppxP0Cg6N3JVELzjGKmkZ2qIlu(u"ࠩࡒࡔࡊࡔࡕࡓࡎࡢ࡙ࡗࡒࡌࡊࡄࠪᎫ"),YVKo4mpBq9vEeUfM7JR8ujSP)
		xZ9qAk7pF3XCKDsOh0SN = -xZ9qAk7pF3XCKDsOh0SN
	if xZ9qAk7pF3XCKDsOh0SN>tELM0b9FzxuRI4J1CYcie7ZXsHBar(u"࠶ᕓ"):
		HGQ5Ty9mlSLwed = QKzCiBOWZus1nSv(PdkZHNBlpg2b7DmX6qRiyVa,jXE2YHkswT8y(u"ࠪࡷࡹࡸࠧᎬ"),UO04GcM7oFd3kJbtKQZHRgI2jeyzCh(u"ࠫࡔࡖࡅࡏࡗࡕࡐࡤ࡛ࡒࡍࡎࡌࡆࠬᎭ"),YVKo4mpBq9vEeUfM7JR8ujSP)
		if HGQ5Ty9mlSLwed:
			ri8uRdOU0kNfq4(uuExaKGL7UONtevRd(u"࡛ࠬࡒࡍࡎࡌࡆࠥࠦࡒࡆࡃࡇࡣࡈࡇࡃࡉࡇࠪᎮ"),smglbwR7x2oM,oRzlSfeE6DY0mFy37NCVxAJW1BwZtM,CZGXVf91e3KTpSDqyP6x8otlhLBam2,VamqUtbfFn6MANy,bDlzGospmi69Oy1NILPaHMWK8Z3FSw)
			return HGQ5Ty9mlSLwed
	HGQ5Ty9mlSLwed = gOjQKfpoJqdCBWl7(bDlzGospmi69Oy1NILPaHMWK8Z3FSw,smglbwR7x2oM,oRzlSfeE6DY0mFy37NCVxAJW1BwZtM,CZGXVf91e3KTpSDqyP6x8otlhLBam2,VamqUtbfFn6MANy)
	if HGQ5Ty9mlSLwed and xZ9qAk7pF3XCKDsOh0SN: YMQXP2BGeK86CEb(PdkZHNBlpg2b7DmX6qRiyVa,PtkEvXAqif14G20QZsaSyT(u"࠭ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡖࡔࡏࡐࡎࡈࠧᎯ"),YVKo4mpBq9vEeUfM7JR8ujSP,HGQ5Ty9mlSLwed,xZ9qAk7pF3XCKDsOh0SN)
	return HGQ5Ty9mlSLwed
def OoC5bEUlDd2shtFzNrvgpyqK(sQU2GnRoMwLK8CBdfzmNr4jXyO,tPbj6e8koZEhsAW1,izS9mNLIvM2X8Zu1x=FGTfwsjNrB8DvKSZhLIQAb1JnO):
	AEpfR0yb3oY2mD4tnz = OXsckY7RzjCag9A.getSetting(uuExaKGL7UONtevRd(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡦ࡮ࡺࡲࡢࡶࡨࠫᎰ"))
	if AEpfR0yb3oY2mD4tnz and ZchUJdM93pTA7zG5(u"ࠨ࠯ࠪᎱ") not in AEpfR0yb3oY2mD4tnz: LsjrhQpZKcn41EyDwlFBm0IYtX,fKk2x9XpEiv = int(AEpfR0yb3oY2mD4tnz),rGPen6cSMHQkAywh8vqI9JXiD2
	elif izS9mNLIvM2X8Zu1x: LsjrhQpZKcn41EyDwlFBm0IYtX,fKk2x9XpEiv = izS9mNLIvM2X8Zu1x,BF6QAiLUNHh7rKOugaw
	else: return []
	rPblaxQIZ4wR2dg,KYtpWiCxyjT74GoI6f0cVRHadX = [],iiy37aKq0pCEIOwfcTh61xb4U
	T2T6uBlQmJ,tjhskEJAfwugvr8x7e6LYB,U1qWPyXudBb6SmoaNkVEch9j,WyF3RV4JHubEnogSBjh = iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,FGTfwsjNrB8DvKSZhLIQAb1JnO,FGTfwsjNrB8DvKSZhLIQAb1JnO
	tPbj6e8koZEhsAW1 = sorted(tPbj6e8koZEhsAW1,reverse=rGPen6cSMHQkAywh8vqI9JXiD2,key=lambda key: (key[YYJQyRskpX8jv],key[nI2JK1RfsGWNY3OarEeMQZ]))
	for stream,qqxvrgsFcEbA8fdOIileQG1,ttKWoIH83b in tPbj6e8koZEhsAW1+[[iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,FGTfwsjNrB8DvKSZhLIQAb1JnO]]:
		if qqxvrgsFcEbA8fdOIileQG1==KYtpWiCxyjT74GoI6f0cVRHadX:
			if ttKWoIH83b>LsjrhQpZKcn41EyDwlFBm0IYtX: tjhskEJAfwugvr8x7e6LYB,WyF3RV4JHubEnogSBjh = stream,ttKWoIH83b
			elif not T2T6uBlQmJ: T2T6uBlQmJ,U1qWPyXudBb6SmoaNkVEch9j = stream,ttKWoIH83b
		else:
			if tjhskEJAfwugvr8x7e6LYB or T2T6uBlQmJ:
				if T2T6uBlQmJ: rPblaxQIZ4wR2dg.append([T2T6uBlQmJ,KYtpWiCxyjT74GoI6f0cVRHadX,U1qWPyXudBb6SmoaNkVEch9j])
				elif tjhskEJAfwugvr8x7e6LYB: rPblaxQIZ4wR2dg.append([tjhskEJAfwugvr8x7e6LYB,KYtpWiCxyjT74GoI6f0cVRHadX,WyF3RV4JHubEnogSBjh])
			if ttKWoIH83b>LsjrhQpZKcn41EyDwlFBm0IYtX:
				tjhskEJAfwugvr8x7e6LYB,WyF3RV4JHubEnogSBjh = stream,ttKWoIH83b
				T2T6uBlQmJ,U1qWPyXudBb6SmoaNkVEch9j = iiy37aKq0pCEIOwfcTh61xb4U,FGTfwsjNrB8DvKSZhLIQAb1JnO
			else:
				tjhskEJAfwugvr8x7e6LYB,WyF3RV4JHubEnogSBjh = iiy37aKq0pCEIOwfcTh61xb4U,FGTfwsjNrB8DvKSZhLIQAb1JnO
				T2T6uBlQmJ,U1qWPyXudBb6SmoaNkVEch9j = stream,ttKWoIH83b
		KYtpWiCxyjT74GoI6f0cVRHadX = qqxvrgsFcEbA8fdOIileQG1
	if fKk2x9XpEiv:
		s5mYgweJjIvq,GIDnvKOA2NxaBgWYTb7LdP,GYnj2MKeAZtzxQw = zip(*rPblaxQIZ4wR2dg)
		OlypcYoGxzJ7UQXLWn6TmP = [AbqCJZdWQP9j(u"ࠩࡰࡴ࠹࠭Ꮂ"),hhQwbeiNLoqFjX90fB7aG8VAs(u"ࠪࡱࡵࡪࠧᎳ"),L90uqo28xEKSFUwYTcm51yRWZIkft(u"ࠫࡹࡹࠧᎴ"),GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠬࡳ࠳ࡶࠩᎵ")]
		for qqxvrgsFcEbA8fdOIileQG1 in OlypcYoGxzJ7UQXLWn6TmP:
			if qqxvrgsFcEbA8fdOIileQG1 in GIDnvKOA2NxaBgWYTb7LdP:
				index = GIDnvKOA2NxaBgWYTb7LdP.index(qqxvrgsFcEbA8fdOIileQG1)
				rPblaxQIZ4wR2dg = [[s5mYgweJjIvq[index],GIDnvKOA2NxaBgWYTb7LdP[index],GYnj2MKeAZtzxQw[index]]]
				break
	return rPblaxQIZ4wR2dg
def t624ZFj0bLTEvG1uImXpr7M83oJq(ttFYERwUizgPyOIq91d4WN):
	Hlk8VWd5mBwhL6uxE,iVH9Ytw8FknvR6WIupe = [],None
	for ekEOd3mqAThaBDUoIrntuGRjYW in j5q8z4HT3cfhvK:
		if ekEOd3mqAThaBDUoIrntuGRjYW==XrTw01KtLzbpoyMf(u"࠭ࡐࡓࡋ࡙ࡅ࡙ࡋࠧᎶ"): iVH9Ytw8FknvR6WIupe = (SaB5hx3PZwXRLtKgrTfQvId(u"ࠧ࡭࡫ࡱ࡯ࠬᎷ"),PSwfZcdRYhpl5Igqz8xOEk67+y6y5HtgXO4TkUbwVZ(u"ࠨ็๋ห็฿ࠠิ์ิๅึอสࠡะสูฮࠦ࠭ࠡไ็๎้ฯࠠศๆุ่ฬ้ไࠨᎸ")+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,uuExaKGL7UONtevRd(u"࠱࠶࠹ᕔ"),iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U)
		elif ekEOd3mqAThaBDUoIrntuGRjYW==LyNiIHPOwD3hCUYEFM7(u"ࠩࡐࡍ࡝ࡋࡄࠨᎹ"): iVH9Ytw8FknvR6WIupe = (sVzojQerUqX(u"ࠪࡰ࡮ࡴ࡫ࠨᎺ"),PSwfZcdRYhpl5Igqz8xOEk67+EMO8gy4LrsNTh0knZwpSeU75APW(u"๊ࠫ๎วใ฻ࠣื๏ืแาษอࠤำอีส๋ࠢ฽ฬ๋ษࠡ࠯ࠣ็ะ๐ัสࠢสฺ่๊วไๆࠪᎻ")+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,IpC4qHXRuyNFjzWv(u"࠲࠷࠺ᕕ"),iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U)
		elif ekEOd3mqAThaBDUoIrntuGRjYW==SaB5hx3PZwXRLtKgrTfQvId(u"ࠬࡖࡕࡃࡎࡌࡇࠬᎼ"): iVH9Ytw8FknvR6WIupe = (SaB5hx3PZwXRLtKgrTfQvId(u"࠭࡬ࡪࡰ࡮ࠫᎽ"),PSwfZcdRYhpl5Igqz8xOEk67+IpC4qHXRuyNFjzWv(u"ࠧๆ๊สๆ฾ࠦำ๋ำไีฬะฺࠠษ่อࠥ࠳ࠠไอํีฮࠦวๅ็ืห่๊ࠧᎾ")+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,L90uqo28xEKSFUwYTcm51yRWZIkft(u"࠳࠸࠻ᕖ"),iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U)
		if ekEOd3mqAThaBDUoIrntuGRjYW not in ttFYERwUizgPyOIq91d4WN: continue
		if iVH9Ytw8FknvR6WIupe:
			Hlk8VWd5mBwhL6uxE.append(iVH9Ytw8FknvR6WIupe)
			iVH9Ytw8FknvR6WIupe = None
		if ekEOd3mqAThaBDUoIrntuGRjYW not in [XrTw01KtLzbpoyMf(u"ࠨࡒࡕࡍ࡛ࡇࡔࡆࠩᎿ"),yJeq1BjfiO4NFuwIEzxVLK6b9s(u"ࠩࡐࡍ࡝ࡋࡄࠨᏀ"),GGx4qyKP1vUtRghsE2WfaHLMXZ(u"ࠪࡔ࡚ࡈࡌࡊࡅࠪᏁ")]: Hlk8VWd5mBwhL6uxE.append(ekEOd3mqAThaBDUoIrntuGRjYW)
	return Hlk8VWd5mBwhL6uxE
from zZbgNTSl4t import *
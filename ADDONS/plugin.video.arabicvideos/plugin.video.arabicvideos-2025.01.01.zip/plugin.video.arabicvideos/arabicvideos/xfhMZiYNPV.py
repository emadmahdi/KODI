﻿# -*- coding: utf-8 -*-
from braVAkwfBN import *
sQU2GnRoMwLK8CBdfzmNr4jXyO = 'ALMAAREF'
headers = {'User-Agent':iiy37aKq0pCEIOwfcTh61xb4U}
ooQEi5O6tYsGVF8LU0TC3hgMeflBwH = '_MRF_'
JaQEtCzDXgos1cdZN = gZ4LwbKaOm[sQU2GnRoMwLK8CBdfzmNr4jXyO][0]
a8GCLIuWNkS = ['التواصل الاجتماعي','صور التواصل الاجتماعي','أرشيف جميع البرامج']
def sHVM8YchrDjZAJ7(mode,url,text,zLEP9N4BOsVrXa):
	if   mode==40: EA7FzO1kMZGQXDd2giB0cwLom = jihuS9LVAvTrClPapMbUEwfn8XN()
	elif mode==41: EA7FzO1kMZGQXDd2giB0cwLom = FaD6NxfSIbzZimr9d4wOjQMkYhn5()
	elif mode==42: EA7FzO1kMZGQXDd2giB0cwLom = seZUPoWJ9vMT2uQ5yBD(text,zLEP9N4BOsVrXa)
	elif mode==43: EA7FzO1kMZGQXDd2giB0cwLom = TW6Z0zqaDl(url)
	elif mode==44: EA7FzO1kMZGQXDd2giB0cwLom = AIQeNZP4FMDw9S(text,zLEP9N4BOsVrXa)
	elif mode==49: EA7FzO1kMZGQXDd2giB0cwLom = mUhJtHB9nw(text)
	else: EA7FzO1kMZGQXDd2giB0cwLom = False
	return EA7FzO1kMZGQXDd2giB0cwLom
def jihuS9LVAvTrClPapMbUEwfn8XN():
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'بحث في الموقع',iiy37aKq0pCEIOwfcTh61xb4U,49)
	bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	bP6z3OSLp7va('live',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'البث الحي لقناة المعارف',iiy37aKq0pCEIOwfcTh61xb4U,41)
	seZUPoWJ9vMT2uQ5yBD(iiy37aKq0pCEIOwfcTh61xb4U,'1')
	return
def HPAleXOtGUV(brFQp5vmgJWdZfEkCBOlu9c,VV2XK5wtblY4DvxhP0UWm):
	search,sort,vke8SjzmdDPgLcZ5hWrYtMHxqn,RRIscyLmNH9dq2Dio3TSr,kcRbxYPw4DNuTAJ53B91zZnhUSjo = iiy37aKq0pCEIOwfcTh61xb4U,[],[],[],[]
	qBIUYtOjTAx0,lKoZnJ74TMLG852SEbVqt = sFNjagPK4W(brFQp5vmgJWdZfEkCBOlu9c)
	for KjsA38t0DCSmuLcaE in list(lKoZnJ74TMLG852SEbVqt.keys()):
		aasX2cby4Vo5rTgB = lKoZnJ74TMLG852SEbVqt[KjsA38t0DCSmuLcaE]
		if not aasX2cby4Vo5rTgB: continue
		if   KjsA38t0DCSmuLcaE=='sort': sort = [aasX2cby4Vo5rTgB]
		elif KjsA38t0DCSmuLcaE=='series': vke8SjzmdDPgLcZ5hWrYtMHxqn = [aasX2cby4Vo5rTgB]
		elif KjsA38t0DCSmuLcaE=='search': search = aasX2cby4Vo5rTgB
		elif KjsA38t0DCSmuLcaE=='category': RRIscyLmNH9dq2Dio3TSr = [aasX2cby4Vo5rTgB]
		elif KjsA38t0DCSmuLcaE=='specialist': kcRbxYPw4DNuTAJ53B91zZnhUSjo = [aasX2cby4Vo5rTgB]
	Si4j3bXGLeno0zfxlm9ZOcy = {"action":"facetwp_refresh","data":{"facets":{"search":search,"video_categories":RRIscyLmNH9dq2Dio3TSr,"specialist":kcRbxYPw4DNuTAJ53B91zZnhUSjo,"series":vke8SjzmdDPgLcZ5hWrYtMHxqn,"number":[],"sort_video":sort,"count":[],"pagination":[]},"frozen_facets":{},"template":"video_desktop_posts","extras":{"sort":"default"},"soft_refresh":0,"is_bfcache":1,"first_load":0,"paged":int(VV2XK5wtblY4DvxhP0UWm)}}
	Si4j3bXGLeno0zfxlm9ZOcy = bHyN37Y82ZKVLOexBF.dumps(Si4j3bXGLeno0zfxlm9ZOcy)
	fCXyTlcmF4WuetVork = 'https://almaaref.ch/wp-json/facetwp/v1/refresh'
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'POST',fCXyTlcmF4WuetVork,Si4j3bXGLeno0zfxlm9ZOcy,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'ALMAAREF-REQUEST_DATA_PAGE-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	data = DeIL3qoa2UBtYPb('dict',Vxz6OndPIX4g2kaRp7)
	return data
def seZUPoWJ9vMT2uQ5yBD(brFQp5vmgJWdZfEkCBOlu9c,level):
	ddfSDGyqEc = HPAleXOtGUV(brFQp5vmgJWdZfEkCBOlu9c,'1')
	PPH1sQtTkDBbnlYpZfo5 = ddfSDGyqEc['facets']
	if level=='1':
		PPH1sQtTkDBbnlYpZfo5 = PPH1sQtTkDBbnlYpZfo5['video_categories']
		items = dEyT9xhGjolYzLCH7460w3.findall('<div(.*?)/div>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for YXD9KNfjCaLwkcrvJxldn7I in items:
			ZEdj50uOAeXUWGCk = dEyT9xhGjolYzLCH7460w3.findall('data-value=\\"(.*?)\\".*?display-value\\">(.*?)<',YXD9KNfjCaLwkcrvJxldn7I+'<',dEyT9xhGjolYzLCH7460w3.DOTALL)
			if not ZEdj50uOAeXUWGCk: ZEdj50uOAeXUWGCk = dEyT9xhGjolYzLCH7460w3.findall('data-value=\\"(.*?)\\">(.*?)<',YXD9KNfjCaLwkcrvJxldn7I+'<',dEyT9xhGjolYzLCH7460w3.DOTALL)
			RRIscyLmNH9dq2Dio3TSr,title = ZEdj50uOAeXUWGCk[0]
			if iELueYz3J1FmxaW7vc: title = vvmT3DLXkhPBwIaOAo6srZpEnRVJC(title)
			if not brFQp5vmgJWdZfEkCBOlu9c: bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,iiy37aKq0pCEIOwfcTh61xb4U,42,iiy37aKq0pCEIOwfcTh61xb4U,'2','?category='+RRIscyLmNH9dq2Dio3TSr)
			else: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,iiy37aKq0pCEIOwfcTh61xb4U,42,iiy37aKq0pCEIOwfcTh61xb4U,'2',brFQp5vmgJWdZfEkCBOlu9c+'&category='+RRIscyLmNH9dq2Dio3TSr)
	if level=='2':
		PPH1sQtTkDBbnlYpZfo5 = PPH1sQtTkDBbnlYpZfo5['specialist']
		items = dEyT9xhGjolYzLCH7460w3.findall('value="(.*?)".*?>(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for kcRbxYPw4DNuTAJ53B91zZnhUSjo,title in items:
			if iELueYz3J1FmxaW7vc: title = vvmT3DLXkhPBwIaOAo6srZpEnRVJC(title)
			if not kcRbxYPw4DNuTAJ53B91zZnhUSjo: title = title = 'الجميع'
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,iiy37aKq0pCEIOwfcTh61xb4U,42,iiy37aKq0pCEIOwfcTh61xb4U,'3',brFQp5vmgJWdZfEkCBOlu9c+'&specialist='+kcRbxYPw4DNuTAJ53B91zZnhUSjo)
	elif level=='3':
		PPH1sQtTkDBbnlYpZfo5 = PPH1sQtTkDBbnlYpZfo5['series']
		items = dEyT9xhGjolYzLCH7460w3.findall('value="(.*?)".*?>(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for vke8SjzmdDPgLcZ5hWrYtMHxqn,title in items:
			if iELueYz3J1FmxaW7vc: title = vvmT3DLXkhPBwIaOAo6srZpEnRVJC(title)
			if not vke8SjzmdDPgLcZ5hWrYtMHxqn: title = title = 'الجميع'
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,iiy37aKq0pCEIOwfcTh61xb4U,42,iiy37aKq0pCEIOwfcTh61xb4U,'4',brFQp5vmgJWdZfEkCBOlu9c+'&series='+vke8SjzmdDPgLcZ5hWrYtMHxqn)
	elif level=='4':
		PPH1sQtTkDBbnlYpZfo5 = PPH1sQtTkDBbnlYpZfo5['sort_video']
		items = dEyT9xhGjolYzLCH7460w3.findall('value="(.*?)".*?>(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for sort,title in items:
			if not sort: continue
			if iELueYz3J1FmxaW7vc: title = vvmT3DLXkhPBwIaOAo6srZpEnRVJC(title)
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,iiy37aKq0pCEIOwfcTh61xb4U,44,iiy37aKq0pCEIOwfcTh61xb4U,'1',brFQp5vmgJWdZfEkCBOlu9c+'&sort='+sort)
	return
def AIQeNZP4FMDw9S(brFQp5vmgJWdZfEkCBOlu9c,VV2XK5wtblY4DvxhP0UWm):
	ddfSDGyqEc = HPAleXOtGUV(brFQp5vmgJWdZfEkCBOlu9c,VV2XK5wtblY4DvxhP0UWm)
	PPH1sQtTkDBbnlYpZfo5 = ddfSDGyqEc['template']
	items = dEyT9xhGjolYzLCH7460w3.findall('src="(.*?)".*?href="(.*?)">(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	for C0dvhEbPWYlUtimM3x,fCXyTlcmF4WuetVork,title in items:
		if iELueYz3J1FmxaW7vc: title = vvmT3DLXkhPBwIaOAo6srZpEnRVJC(title)
		bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,43,C0dvhEbPWYlUtimM3x)
	PPH1sQtTkDBbnlYpZfo5 = ddfSDGyqEc['facets']['pagination']
	items = dEyT9xhGjolYzLCH7460w3.findall('data-page="(.*?)">(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	for zLEP9N4BOsVrXa,title in items:
		if VV2XK5wtblY4DvxhP0UWm==zLEP9N4BOsVrXa: continue
		if iELueYz3J1FmxaW7vc: title = vvmT3DLXkhPBwIaOAo6srZpEnRVJC(title)
		bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'صفحة '+title,iiy37aKq0pCEIOwfcTh61xb4U,44,iiy37aKq0pCEIOwfcTh61xb4U,zLEP9N4BOsVrXa,brFQp5vmgJWdZfEkCBOlu9c)
	return
def TW6Z0zqaDl(url):
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'ALMAAREF-PLAY-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	fCXyTlcmF4WuetVork = dEyT9xhGjolYzLCH7460w3.findall('<video src="(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if not fCXyTlcmF4WuetVork: fCXyTlcmF4WuetVork = dEyT9xhGjolYzLCH7460w3.findall('youtube_url.*?(http.*?)&',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	ff2PjlcCF5ZWyIUbVguMz = []
	if fCXyTlcmF4WuetVork:
		fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork[0].replace('\/','/')
		ff2PjlcCF5ZWyIUbVguMz.append(fCXyTlcmF4WuetVork)
	import lqBJGK8hXO
	lqBJGK8hXO.ZDg1HavwueT85mcAOorC4hnS(ff2PjlcCF5ZWyIUbVguMz,sQU2GnRoMwLK8CBdfzmNr4jXyO,'video',url)
	return
def FaD6NxfSIbzZimr9d4wOjQMkYhn5():
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(Dxc7GChQwZ4kOlKHSbL06agnB,'GET',JaQEtCzDXgos1cdZN+'/بث-مباشر',iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'ALMAAREF-LIVE-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	url = dEyT9xhGjolYzLCH7460w3.findall('"svpPlayer".*?(http.*?)&',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	url = url[0].replace('\\',iiy37aKq0pCEIOwfcTh61xb4U)
	PsD3IgluKFyvzMLoRT9j5hq2(url,sQU2GnRoMwLK8CBdfzmNr4jXyO,'live')
	return
def mUhJtHB9nw(search):
	search,brFQp5vmgJWdZfEkCBOlu9c,showDialogs = XkYnev3ZCA6ahO94(search)
	TKwbMB0A9gQlZ = False
	if search==iiy37aKq0pCEIOwfcTh61xb4U:
		search = TTBf6S08q1NKXd5v9wa()
		TKwbMB0A9gQlZ = True
	if search==iiy37aKq0pCEIOwfcTh61xb4U: return
	if not TKwbMB0A9gQlZ: AIQeNZP4FMDw9S('?search='+search,'1')
	else: seZUPoWJ9vMT2uQ5yBD('?search='+search,'1')
	return
# -*- coding: utf-8 -*-
from braVAkwfBN import *
sQU2GnRoMwLK8CBdfzmNr4jXyO = 'CIMA4U'
headers = {'User-Agent':iiy37aKq0pCEIOwfcTh61xb4U}
ooQEi5O6tYsGVF8LU0TC3hgMeflBwH = '_C4U_'
JaQEtCzDXgos1cdZN = gZ4LwbKaOm[sQU2GnRoMwLK8CBdfzmNr4jXyO][0]
a8GCLIuWNkS = ['مصارعة حرة','اخري','اخرى','الرئيسية','بدون إختيار','افلام','مسلسلات']
def sHVM8YchrDjZAJ7(mode,url,text):
	if   mode==420: EA7FzO1kMZGQXDd2giB0cwLom = jihuS9LVAvTrClPapMbUEwfn8XN()
	elif mode==421: EA7FzO1kMZGQXDd2giB0cwLom = AIQeNZP4FMDw9S(url,text)
	elif mode==422: EA7FzO1kMZGQXDd2giB0cwLom = Sm6cFjKyW8XTszNxi(url)
	elif mode==423: EA7FzO1kMZGQXDd2giB0cwLom = YNcMvoVF5swlDBJI7PL(url)
	elif mode==424: EA7FzO1kMZGQXDd2giB0cwLom = chQHNdWgTSDjti8R9pJUf(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==425: EA7FzO1kMZGQXDd2giB0cwLom = chQHNdWgTSDjti8R9pJUf(url,'SPECIFIED_FILTER___'+text)
	elif mode==426: EA7FzO1kMZGQXDd2giB0cwLom = TW6Z0zqaDl(url)
	elif mode==427: EA7FzO1kMZGQXDd2giB0cwLom = ooWayg7xku3KeicwrpBjITmGZ2zqh(url)
	elif mode==429: EA7FzO1kMZGQXDd2giB0cwLom = mUhJtHB9nw(text)
	else: EA7FzO1kMZGQXDd2giB0cwLom = False
	return EA7FzO1kMZGQXDd2giB0cwLom
def jihuS9LVAvTrClPapMbUEwfn8XN():
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',JaQEtCzDXgos1cdZN,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'CIMA4U-MENU-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	ffBG4TaQU8lVF26R = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	ffBG4TaQU8lVF26R = ffBG4TaQU8lVF26R[0].strip('/')
	ffBG4TaQU8lVF26R = F82MvyX4ThI6sbnA3efDoVS(ffBG4TaQU8lVF26R,'url')
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'بحث في الموقع',iiy37aKq0pCEIOwfcTh61xb4U,429,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'_REMEMBERRESULTS_')
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'فلتر محدد',ffBG4TaQU8lVF26R,425)
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'فلتر كامل',ffBG4TaQU8lVF26R,424)
	bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'الرئيسية',ffBG4TaQU8lVF26R,421)
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('NavigationMenu(.*?)</div>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
	items = dEyT9xhGjolYzLCH7460w3.findall('href="*(.*?)"*>(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	for fCXyTlcmF4WuetVork,title in items:
		if title in a8GCLIuWNkS: continue
		if '/actors' in fCXyTlcmF4WuetVork: title = 'أفلام النجوم'
		elif '/netflix' in fCXyTlcmF4WuetVork: title = 'أفلام ومسلسلات نيتفلكس'
		bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,421)
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'قائمة تفصيلية',ffBG4TaQU8lVF26R,427)
	return
def ooWayg7xku3KeicwrpBjITmGZ2zqh(website=iiy37aKq0pCEIOwfcTh61xb4U):
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',JaQEtCzDXgos1cdZN,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'CIMA4U-MENU-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('FilteringTitle(.*?)PageTitle',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
	items = dEyT9xhGjolYzLCH7460w3.findall('data-tax="*(.*?)"* data-id="*(.*?)[">]*<a href="*(.*?)[">]+.*?</div>(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	for RRIscyLmNH9dq2Dio3TSr,id,fCXyTlcmF4WuetVork,title in items:
		if title in a8GCLIuWNkS: continue
		if 'netflix-movies' in fCXyTlcmF4WuetVork: title = 'أفلام نيتفلكس'
		elif 'series-netflix' in fCXyTlcmF4WuetVork: title = 'مسلسلات نيتفلكس'
		bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,421,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,RRIscyLmNH9dq2Dio3TSr+'|'+id)
	return
def AIQeNZP4FMDw9S(url,Ax2k5gsahJCBE30DfntcyXL7P=iiy37aKq0pCEIOwfcTh61xb4U):
	if '/HomepageLoader/' in url: url = url.strip('/')+'/mpaa/family/'
	items = []
	ffBG4TaQU8lVF26R = F82MvyX4ThI6sbnA3efDoVS(url,'url')
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'CIMA4U-TITLES-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	if not Ax2k5gsahJCBE30DfntcyXL7P or '|' in Ax2k5gsahJCBE30DfntcyXL7P:
		if '|' not in Ax2k5gsahJCBE30DfntcyXL7P: TWKjq0cJ6nEIiO2l = iiy37aKq0pCEIOwfcTh61xb4U
		else: TWKjq0cJ6nEIiO2l = '/archive/'+Ax2k5gsahJCBE30DfntcyXL7P
		AAbf0g1sJ4crMQYiKmTypFltvkUVD = False
		if 'PinSlider' in Vxz6OndPIX4g2kaRp7:
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'المميزة',url,421,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'featured')
			AAbf0g1sJ4crMQYiKmTypFltvkUVD = True
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('PageTitle(.*?)PageContent',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if UUIohmv597bO83YCLgWS:
			U462wftipjCPA1hLuGsKr8koxnd = UUIohmv597bO83YCLgWS[0]
			lFmsiNI2UDoJBdVCQtqx4WPXb7 = dEyT9xhGjolYzLCH7460w3.findall('data-tab="(.*?)".*?<span>(.*?)<',U462wftipjCPA1hLuGsKr8koxnd,dEyT9xhGjolYzLCH7460w3.DOTALL)
			for u7woJ4Kj0Yb1gEZTzXh3Hr8Gt,Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb in lFmsiNI2UDoJBdVCQtqx4WPXb7:
				hx0dU3Ki7AyEfkSZY6TmN2BwtX = ffBG4TaQU8lVF26R+'/ajaxcenter/action/HomepageLoader/tab/'+u7woJ4Kj0Yb1gEZTzXh3Hr8Gt+TWKjq0cJ6nEIiO2l+'/'
				bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb,hx0dU3Ki7AyEfkSZY6TmN2BwtX,421)
				AAbf0g1sJ4crMQYiKmTypFltvkUVD = True
		if AAbf0g1sJ4crMQYiKmTypFltvkUVD: bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	if Ax2k5gsahJCBE30DfntcyXL7P=='featured':
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('PinSlider(.*?)MultiFilter',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if not UUIohmv597bO83YCLgWS: UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('PinSlider(.*?)PageTitle',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if UUIohmv597bO83YCLgWS: PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		else: PPH1sQtTkDBbnlYpZfo5 = iiy37aKq0pCEIOwfcTh61xb4U
	elif '/HomepageLoader/' in url or '/searchcenter/' in url:
		PPH1sQtTkDBbnlYpZfo5 = Vxz6OndPIX4g2kaRp7
	elif '/filter/' in url:
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('PageContent(.*?)class="*pagination"*',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
	elif '/actors' in url:
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('PageContent(.*?)class="*pagination"*',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="*(.*?)[">]+.*?image:url\((.*?)\).*?ActorName">(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	else:
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('Cima4uBlocks(.*?)</li></ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if UUIohmv597bO83YCLgWS: PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		else: PPH1sQtTkDBbnlYpZfo5 = iiy37aKq0pCEIOwfcTh61xb4U
	if not items: items = dEyT9xhGjolYzLCH7460w3.findall('class="*MovieBlock"*.*?href="*(.*?)[">]+.*?image:url\((.*?)\).*?image.*?BoxTitleInfo.*?</div></div>(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if not items: items = dEyT9xhGjolYzLCH7460w3.findall('class="MovieBlock".*?href="(.*?)".*?data-image="(.*?)".*?alt="(.*?)"',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	u3Rztpl4VHO9GZ7jCBM65kvS = []
	for fCXyTlcmF4WuetVork,C0dvhEbPWYlUtimM3x,title in items:
		if not title: continue
		if '?news=' in fCXyTlcmF4WuetVork: continue
		title = title.replace('مشاهدة ',iiy37aKq0pCEIOwfcTh61xb4U)
		title = JIY6A30UOsQboNVqCn(title)
		zN7sZyFnw5JTE8 = dEyT9xhGjolYzLCH7460w3.findall('(.*?) حلقة \d+',title,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if zN7sZyFnw5JTE8 and 'حلقة' in title:
			title = '_MOD_' + zN7sZyFnw5JTE8[0]
			if title not in u3Rztpl4VHO9GZ7jCBM65kvS:
				bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,422,C0dvhEbPWYlUtimM3x)
				u3Rztpl4VHO9GZ7jCBM65kvS.append(title)
		elif '/actor/' in fCXyTlcmF4WuetVork: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,421,C0dvhEbPWYlUtimM3x)
		else: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,422,C0dvhEbPWYlUtimM3x)
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('pagination(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS and Ax2k5gsahJCBE30DfntcyXL7P!='featured':
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href=[\'\"](.*?)[\'\"]>(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title in items:
			title = JIY6A30UOsQboNVqCn(title)
			title = title.replace('الصفحة ',iiy37aKq0pCEIOwfcTh61xb4U)
			if title!=iiy37aKq0pCEIOwfcTh61xb4U: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'صفحة '+title,fCXyTlcmF4WuetVork,421)
	SwiW9ygZnaTl53PVbKzRtY = dEyT9xhGjolYzLCH7460w3.findall('</li><a href="(.*?)".*?>(.*?)<',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if SwiW9ygZnaTl53PVbKzRtY:
		fCXyTlcmF4WuetVork,title = SwiW9ygZnaTl53PVbKzRtY[0]
		bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,421)
	return
def Sm6cFjKyW8XTszNxi(url):
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'CIMA4U-SEASONS-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('class="WatchNow".*?href="(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		url = UUIohmv597bO83YCLgWS[0]
		oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'CIMA4U-SEASONS-2nd')
		Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('SeasonsSections(.*?)</div></div></div>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if '/tag/' in url or '/actor' in url:
		AIQeNZP4FMDw9S(url)
	elif UUIohmv597bO83YCLgWS:
		C0dvhEbPWYlUtimM3x = WwMgozBIC32n9d0tyfp.getInfoLabel('ListItem.Thumb')
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall("href='(.*?)'>(.*?)<",PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		NWa4Zez3Dp0hnmQ9BVP = ['مسلسل','موسم','برنامج','حلقة']
		for fCXyTlcmF4WuetVork,title in items:
			if any(aasX2cby4Vo5rTgB in title for aasX2cby4Vo5rTgB in NWa4Zez3Dp0hnmQ9BVP):
				bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,423,C0dvhEbPWYlUtimM3x)
			else: bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,426,C0dvhEbPWYlUtimM3x)
	else: YNcMvoVF5swlDBJI7PL(url)
	return
def YNcMvoVF5swlDBJI7PL(url):
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'CIMA4U-EPISODES-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	C0dvhEbPWYlUtimM3x = dEyT9xhGjolYzLCH7460w3.findall('"background-image:url\((.*?)\)',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if C0dvhEbPWYlUtimM3x: C0dvhEbPWYlUtimM3x = C0dvhEbPWYlUtimM3x[0]
	else: C0dvhEbPWYlUtimM3x = iiy37aKq0pCEIOwfcTh61xb4U
	zelNBksaDSFU1AQLh8Yy4ZHjG = dEyT9xhGjolYzLCH7460w3.findall('EpisodesSection(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if zelNBksaDSFU1AQLh8Yy4ZHjG:
		PPH1sQtTkDBbnlYpZfo5 = zelNBksaDSFU1AQLh8Yy4ZHjG[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)"><em>(.*?)<.*?<span>(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title,zN7sZyFnw5JTE8 in items:
			title = title+iFBmE2MUIpSu34wsd7Rf6z+zN7sZyFnw5JTE8
			bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,426,C0dvhEbPWYlUtimM3x)
	else: bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'رابط التشغيل',url,426,C0dvhEbPWYlUtimM3x)
	return
def TW6Z0zqaDl(url):
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'CIMA4U-PLAY-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	NgK4TeLbdYv6mQWyXjFIxkflOSq = oCJ8TdG2LwSIVcbaUnhB.url
	if iELueYz3J1FmxaW7vc: NgK4TeLbdYv6mQWyXjFIxkflOSq = NgK4TeLbdYv6mQWyXjFIxkflOSq.encode(df6QpwGxuJVZr)
	ffBG4TaQU8lVF26R = F82MvyX4ThI6sbnA3efDoVS(NgK4TeLbdYv6mQWyXjFIxkflOSq,'url')
	duef0gb3Mi1AV5WpN8 = []
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('WatchSection(.*?)</div></div>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('data-link="(.*?)".*? />(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for w7dRclJi29IUOqP,title in items:
			title = title.strip(iFBmE2MUIpSu34wsd7Rf6z)
			if 'myvid' in title.lower(): title = 'خاص '+title
			fCXyTlcmF4WuetVork = ffBG4TaQU8lVF26R+'/structure/server.php?id='+w7dRclJi29IUOqP+'?named='+title+'__watch'
			fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork.replace(Mge0HhFk9Ic6sm5VR,iiy37aKq0pCEIOwfcTh61xb4U)
			duef0gb3Mi1AV5WpN8.append(fCXyTlcmF4WuetVork)
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('DownloadServers(.*?)</div></div>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*? />(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title in items:
			title = title.strip(iFBmE2MUIpSu34wsd7Rf6z)
			if 'myvid' in title.lower(): Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb = '__خاص'
			else: Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb = iiy37aKq0pCEIOwfcTh61xb4U
			fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork+'?named='+title+'__download'+Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb
			fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork.replace(Mge0HhFk9Ic6sm5VR,iiy37aKq0pCEIOwfcTh61xb4U)
			duef0gb3Mi1AV5WpN8.append(fCXyTlcmF4WuetVork)
	import lqBJGK8hXO
	lqBJGK8hXO.ZDg1HavwueT85mcAOorC4hnS(duef0gb3Mi1AV5WpN8,sQU2GnRoMwLK8CBdfzmNr4jXyO,'video',url)
	return
def mUhJtHB9nw(search):
	search,brFQp5vmgJWdZfEkCBOlu9c,showDialogs = XkYnev3ZCA6ahO94(search)
	if search==iiy37aKq0pCEIOwfcTh61xb4U: search = TTBf6S08q1NKXd5v9wa()
	if search==iiy37aKq0pCEIOwfcTh61xb4U: return
	search = search.replace(iFBmE2MUIpSu34wsd7Rf6z,'+')
	url = JaQEtCzDXgos1cdZN+'/Search?q='+search
	AIQeNZP4FMDw9S(url,'search')
	return
def Dv235GCSiTYasugHxhbPUVjdKkcprN(url):
	if 'smartemadfilter' not in url: url = F82MvyX4ThI6sbnA3efDoVS(url,'url')
	else: url = url.split('/smartemadfilter?')[0]
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'CIMA4U-GET_FILTERS_BLOCKS-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('MultiFilter(.*?)PageTitle',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
	n8nFIQBNaXD = dEyT9xhGjolYzLCH7460w3.findall('Hoverable.*?<span>(.*?)</span>.*?"all".*?(data-tax="(.*?)".*?)</ul>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	return n8nFIQBNaXD
def T6TdxbQOnA(PPH1sQtTkDBbnlYpZfo5):
	items = dEyT9xhGjolYzLCH7460w3.findall('data-id="(.*?)".*?</div>(.*?)</a>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	return items
def FvYaT7p0Wi3unK6(url):
	UM3q9WaVXOP4ZuhCnHB5jyA = url.split('/smartemadfilter?')[0]
	VrnhdEezI7 = F82MvyX4ThI6sbnA3efDoVS(url,'url')
	url = url.replace(UM3q9WaVXOP4ZuhCnHB5jyA,VrnhdEezI7)
	url = url.replace('/smartemadfilter?','/ajaxcenter/action/HomepageLoader/')
	url = url.replace('=','/').replace('&','/')
	url = url+'/'
	return url
JYMlXTc9DCZrohd = ['category','types','release-year']
a3aiAqYngfydR1XNJK975wl4jD = ['Quality','release-year','types','category']
def chQHNdWgTSDjti8R9pJUf(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==iiy37aKq0pCEIOwfcTh61xb4U: Mhd9LWrfiF1EsASl6eP34uTp0qNGom,ovh6cXGg1qd85fn3CSJEisTlI7Yz = iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U
	else: Mhd9LWrfiF1EsASl6eP34uTp0qNGom,ovh6cXGg1qd85fn3CSJEisTlI7Yz = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if '/category/' in url:
			global JYMlXTc9DCZrohd
			JYMlXTc9DCZrohd = JYMlXTc9DCZrohd[1:]
		if JYMlXTc9DCZrohd[0]+'=' not in Mhd9LWrfiF1EsASl6eP34uTp0qNGom: RRIscyLmNH9dq2Dio3TSr = JYMlXTc9DCZrohd[0]
		for iEfNKT3velFyGth80SA4pxbCRrVD in range(len(JYMlXTc9DCZrohd[0:-1])):
			if JYMlXTc9DCZrohd[iEfNKT3velFyGth80SA4pxbCRrVD]+'=' in Mhd9LWrfiF1EsASl6eP34uTp0qNGom: RRIscyLmNH9dq2Dio3TSr = JYMlXTc9DCZrohd[iEfNKT3velFyGth80SA4pxbCRrVD+1]
		HdFJThcNtWe3lb8n4OmaSwQ = Mhd9LWrfiF1EsASl6eP34uTp0qNGom+'&'+RRIscyLmNH9dq2Dio3TSr+'=0'
		vvlVH6JT9YDNPeSaRUkKCAwpr5uq = ovh6cXGg1qd85fn3CSJEisTlI7Yz+'&'+RRIscyLmNH9dq2Dio3TSr+'=0'
		cCZR4YdwUepABD9mQsubT8FgN = HdFJThcNtWe3lb8n4OmaSwQ.strip('&')+'___'+vvlVH6JT9YDNPeSaRUkKCAwpr5uq.strip('&')
		bPXk8KHyCUrifag = qJ8NQtuWARGjoZd9swfbH(ovh6cXGg1qd85fn3CSJEisTlI7Yz,'modified_filters')
		eCGwzSrqBmIv = url+'/smartemadfilter?'+bPXk8KHyCUrifag
	elif type=='ALL_ITEMS_FILTER':
		GMQ6AxE012X9 = qJ8NQtuWARGjoZd9swfbH(Mhd9LWrfiF1EsASl6eP34uTp0qNGom,'modified_values')
		GMQ6AxE012X9 = a9I3YZjc6ySDPE4Kp(GMQ6AxE012X9)
		if ovh6cXGg1qd85fn3CSJEisTlI7Yz!=iiy37aKq0pCEIOwfcTh61xb4U: ovh6cXGg1qd85fn3CSJEisTlI7Yz = qJ8NQtuWARGjoZd9swfbH(ovh6cXGg1qd85fn3CSJEisTlI7Yz,'modified_filters')
		if ovh6cXGg1qd85fn3CSJEisTlI7Yz==iiy37aKq0pCEIOwfcTh61xb4U: eCGwzSrqBmIv = url
		else: eCGwzSrqBmIv = url+'/smartemadfilter?'+ovh6cXGg1qd85fn3CSJEisTlI7Yz
		eCGwzSrqBmIv = FvYaT7p0Wi3unK6(eCGwzSrqBmIv)
		bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'أظهار قائمة الفيديو التي تم اختيارها ',eCGwzSrqBmIv,421,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'filter')
		bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+' [[   '+GMQ6AxE012X9+'   ]]',eCGwzSrqBmIv,421,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'filter')
		bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	n8nFIQBNaXD = Dv235GCSiTYasugHxhbPUVjdKkcprN(url)
	dict = {}
	for name,PPH1sQtTkDBbnlYpZfo5,cWhMpFIbQU4D1Bi in n8nFIQBNaXD:
		if '/category/' in url and cWhMpFIbQU4D1Bi=='category': continue
		name = name.replace('--',iiy37aKq0pCEIOwfcTh61xb4U)
		items = T6TdxbQOnA(PPH1sQtTkDBbnlYpZfo5)
		if '=' not in eCGwzSrqBmIv: eCGwzSrqBmIv = url
		if type=='SPECIFIED_FILTER':
			if RRIscyLmNH9dq2Dio3TSr!=cWhMpFIbQU4D1Bi: continue
			elif len(items)<2:
				if cWhMpFIbQU4D1Bi==JYMlXTc9DCZrohd[-1]:
					url = FvYaT7p0Wi3unK6(url)
					AIQeNZP4FMDw9S(url)
				else: chQHNdWgTSDjti8R9pJUf(eCGwzSrqBmIv,'SPECIFIED_FILTER___'+cCZR4YdwUepABD9mQsubT8FgN)
				return
			else:
				eCGwzSrqBmIv = FvYaT7p0Wi3unK6(eCGwzSrqBmIv)
				if cWhMpFIbQU4D1Bi==JYMlXTc9DCZrohd[-1]: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'الجميع',eCGwzSrqBmIv,421,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'filter')
				else: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'الجميع',eCGwzSrqBmIv,425,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,cCZR4YdwUepABD9mQsubT8FgN)
		elif type=='ALL_ITEMS_FILTER':
			HdFJThcNtWe3lb8n4OmaSwQ = Mhd9LWrfiF1EsASl6eP34uTp0qNGom+'&'+cWhMpFIbQU4D1Bi+'=0'
			vvlVH6JT9YDNPeSaRUkKCAwpr5uq = ovh6cXGg1qd85fn3CSJEisTlI7Yz+'&'+cWhMpFIbQU4D1Bi+'=0'
			cCZR4YdwUepABD9mQsubT8FgN = HdFJThcNtWe3lb8n4OmaSwQ+'___'+vvlVH6JT9YDNPeSaRUkKCAwpr5uq
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'الجميع :'+name,eCGwzSrqBmIv,424,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,cCZR4YdwUepABD9mQsubT8FgN)
		dict[cWhMpFIbQU4D1Bi] = {}
		for aasX2cby4Vo5rTgB,KjsA38t0DCSmuLcaE in items:
			if aasX2cby4Vo5rTgB=='196533': KjsA38t0DCSmuLcaE = 'أفلام نيتفلكس'
			elif aasX2cby4Vo5rTgB=='196531': KjsA38t0DCSmuLcaE = 'مسلسلات نيتفلكس'
			if KjsA38t0DCSmuLcaE in a8GCLIuWNkS: continue
			dict[cWhMpFIbQU4D1Bi][aasX2cby4Vo5rTgB] = KjsA38t0DCSmuLcaE
			HdFJThcNtWe3lb8n4OmaSwQ = Mhd9LWrfiF1EsASl6eP34uTp0qNGom+'&'+cWhMpFIbQU4D1Bi+'='+KjsA38t0DCSmuLcaE
			vvlVH6JT9YDNPeSaRUkKCAwpr5uq = ovh6cXGg1qd85fn3CSJEisTlI7Yz+'&'+cWhMpFIbQU4D1Bi+'='+aasX2cby4Vo5rTgB
			kuyfTIwjRrhXUo = HdFJThcNtWe3lb8n4OmaSwQ+'___'+vvlVH6JT9YDNPeSaRUkKCAwpr5uq
			title = KjsA38t0DCSmuLcaE+' :'#+dict[cWhMpFIbQU4D1Bi]['0']
			title = KjsA38t0DCSmuLcaE+' :'+name
			if type=='ALL_ITEMS_FILTER': bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,url,424,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,kuyfTIwjRrhXUo)
			elif type=='SPECIFIED_FILTER' and JYMlXTc9DCZrohd[-2]+'=' in Mhd9LWrfiF1EsASl6eP34uTp0qNGom:
				bPXk8KHyCUrifag = qJ8NQtuWARGjoZd9swfbH(vvlVH6JT9YDNPeSaRUkKCAwpr5uq,'modified_filters')
				O5Pwg3UFyX0k9E = url+'/smartemadfilter?'+bPXk8KHyCUrifag
				O5Pwg3UFyX0k9E = FvYaT7p0Wi3unK6(O5Pwg3UFyX0k9E)
				bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,O5Pwg3UFyX0k9E,421,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'filter')
			else: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,url,425,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,kuyfTIwjRrhXUo)
	return
def qJ8NQtuWARGjoZd9swfbH(HSAqBpsb2jRLvk9lx147rzY,mode):
	HSAqBpsb2jRLvk9lx147rzY = HSAqBpsb2jRLvk9lx147rzY.replace('=&','=0&')
	HSAqBpsb2jRLvk9lx147rzY = HSAqBpsb2jRLvk9lx147rzY.strip('&')
	x8UiIH3WCTEpe = {}
	if '=' in HSAqBpsb2jRLvk9lx147rzY:
		items = HSAqBpsb2jRLvk9lx147rzY.split('&')
		for YXD9KNfjCaLwkcrvJxldn7I in items:
			xYkDXe5UjvETygJNLrRQ96mtp8BKGW,aasX2cby4Vo5rTgB = YXD9KNfjCaLwkcrvJxldn7I.split('=')
			x8UiIH3WCTEpe[xYkDXe5UjvETygJNLrRQ96mtp8BKGW] = aasX2cby4Vo5rTgB
	QAvGYocVXgzh9 = iiy37aKq0pCEIOwfcTh61xb4U
	for key in a3aiAqYngfydR1XNJK975wl4jD:
		if key in list(x8UiIH3WCTEpe.keys()): aasX2cby4Vo5rTgB = x8UiIH3WCTEpe[key]
		else: aasX2cby4Vo5rTgB = '0'
		if '%' not in aasX2cby4Vo5rTgB: aasX2cby4Vo5rTgB = YqdaDIig21wBTWJeUHbc(aasX2cby4Vo5rTgB)
		if mode=='modified_values' and aasX2cby4Vo5rTgB!='0': QAvGYocVXgzh9 = QAvGYocVXgzh9+' + '+aasX2cby4Vo5rTgB
		elif mode=='modified_filters' and aasX2cby4Vo5rTgB!='0': QAvGYocVXgzh9 = QAvGYocVXgzh9+'&'+key+'='+aasX2cby4Vo5rTgB
		elif mode=='all': QAvGYocVXgzh9 = QAvGYocVXgzh9+'&'+key+'='+aasX2cby4Vo5rTgB
	QAvGYocVXgzh9 = QAvGYocVXgzh9.strip(' + ')
	QAvGYocVXgzh9 = QAvGYocVXgzh9.strip('&')
	QAvGYocVXgzh9 = QAvGYocVXgzh9.replace('=0','=')
	return QAvGYocVXgzh9
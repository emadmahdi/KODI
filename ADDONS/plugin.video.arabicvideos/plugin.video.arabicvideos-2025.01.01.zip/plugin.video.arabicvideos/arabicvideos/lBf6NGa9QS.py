# -*- coding: utf-8 -*-
from braVAkwfBN import *
sQU2GnRoMwLK8CBdfzmNr4jXyO = 'SHAHIDNEWS'
ooQEi5O6tYsGVF8LU0TC3hgMeflBwH = '_SHN_'
JaQEtCzDXgos1cdZN = gZ4LwbKaOm[sQU2GnRoMwLK8CBdfzmNr4jXyO][0]
a8GCLIuWNkS = ['قنوات فضائية','فارسكو','Show more']
def sHVM8YchrDjZAJ7(mode,url,text):
	if   mode==580: EA7FzO1kMZGQXDd2giB0cwLom = jihuS9LVAvTrClPapMbUEwfn8XN()
	elif mode==581: EA7FzO1kMZGQXDd2giB0cwLom = AIQeNZP4FMDw9S(url,text)
	elif mode==582: EA7FzO1kMZGQXDd2giB0cwLom = TW6Z0zqaDl(url)
	elif mode==583: EA7FzO1kMZGQXDd2giB0cwLom = YNcMvoVF5swlDBJI7PL(url,text)
	elif mode==584: EA7FzO1kMZGQXDd2giB0cwLom = BaSyudevC40nsQHW5j7JX6RM9(url)
	elif mode==589: EA7FzO1kMZGQXDd2giB0cwLom = mUhJtHB9nw(text)
	else: EA7FzO1kMZGQXDd2giB0cwLom = False
	return EA7FzO1kMZGQXDd2giB0cwLom
def jihuS9LVAvTrClPapMbUEwfn8XN():
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',JaQEtCzDXgos1cdZN,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'SHAHIDNEWS-MENU-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'بحث في الموقع',iiy37aKq0pCEIOwfcTh61xb4U,589,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'_REMEMBERRESULTS_')
	bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('/category.php">(.*?)"navslide-divider"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall("'dropdown-menu'(.*?)</ul>",Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	for U462wftipjCPA1hLuGsKr8koxnd in UUIohmv597bO83YCLgWS: PPH1sQtTkDBbnlYpZfo5 = PPH1sQtTkDBbnlYpZfo5.replace(U462wftipjCPA1hLuGsKr8koxnd,iiy37aKq0pCEIOwfcTh61xb4U)
	items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?>(.*?)</a>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	for fCXyTlcmF4WuetVork,title in items:
		if title in a8GCLIuWNkS: continue
		bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,584)
	return
def BaSyudevC40nsQHW5j7JX6RM9(url):
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'SHAHIDNEWS-SUBMENU-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	HG5rE20ORdbqUKWewuZCJP4zoXF6g = dEyT9xhGjolYzLCH7460w3.findall('"caret"(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if HG5rE20ORdbqUKWewuZCJP4zoXF6g:
		PPH1sQtTkDBbnlYpZfo5 = HG5rE20ORdbqUKWewuZCJP4zoXF6g[0]
		PPH1sQtTkDBbnlYpZfo5 = PPH1sQtTkDBbnlYpZfo5.replace('"presentation"','</ul>')
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if not UUIohmv597bO83YCLgWS: UUIohmv597bO83YCLgWS = [(iiy37aKq0pCEIOwfcTh61xb4U,PPH1sQtTkDBbnlYpZfo5)]
		bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' فرز أو فلتر أو ترتيب '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
		for MF3KpchD8xSdtL0VXTAB96w,PPH1sQtTkDBbnlYpZfo5 in UUIohmv597bO83YCLgWS:
			items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?>(.*?)</a>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
			if MF3KpchD8xSdtL0VXTAB96w: MF3KpchD8xSdtL0VXTAB96w = MF3KpchD8xSdtL0VXTAB96w+': '
			for fCXyTlcmF4WuetVork,title in items:
				title = MF3KpchD8xSdtL0VXTAB96w+title
				bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,581)
	eTov6CfDcRZVJEAq5BH = dEyT9xhGjolYzLCH7460w3.findall('"pm-category-subcats"(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if eTov6CfDcRZVJEAq5BH:
		PPH1sQtTkDBbnlYpZfo5 = eTov6CfDcRZVJEAq5BH[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)">(.*?)</a>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if len(items)<30:
			bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
			for fCXyTlcmF4WuetVork,title in items:
				bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,581)
	if not HG5rE20ORdbqUKWewuZCJP4zoXF6g and not eTov6CfDcRZVJEAq5BH: AIQeNZP4FMDw9S(url)
	return
def AIQeNZP4FMDw9S(url,lHDuLVCy8kvqB6Rxh4Gs5K=iiy37aKq0pCEIOwfcTh61xb4U):
	ffBG4TaQU8lVF26R = F82MvyX4ThI6sbnA3efDoVS(url,'url')
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'SHAHIDNEWS-TITLES-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	items = []
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('(data-echo=".*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if not UUIohmv597bO83YCLgWS: UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"BlocksList"(.*?)"titleSectionCon"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if not UUIohmv597bO83YCLgWS: UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('id="pm-grid"(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if not UUIohmv597bO83YCLgWS: UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('id="pm-related"(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if not UUIohmv597bO83YCLgWS: return
	PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
	if not items: items = dEyT9xhGjolYzLCH7460w3.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if not items: items = dEyT9xhGjolYzLCH7460w3.findall('src="(.*?)".*?href="(.*?)".*?>(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	u3Rztpl4VHO9GZ7jCBM65kvS = []
	mxXKsCgL5OoP1evURZ8SdIfpBrwu = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for C0dvhEbPWYlUtimM3x,fCXyTlcmF4WuetVork,title in items:
		fCXyTlcmF4WuetVork = a9I3YZjc6ySDPE4Kp(fCXyTlcmF4WuetVork).strip('/')
		if 'http' not in fCXyTlcmF4WuetVork: fCXyTlcmF4WuetVork = ffBG4TaQU8lVF26R+'/'+fCXyTlcmF4WuetVork.strip('/')
		if 'http' not in C0dvhEbPWYlUtimM3x: C0dvhEbPWYlUtimM3x = ffBG4TaQU8lVF26R+'/'+C0dvhEbPWYlUtimM3x.strip('/')
		zN7sZyFnw5JTE8 = dEyT9xhGjolYzLCH7460w3.findall('(.*?) الحلقة \d+',title,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if any(aasX2cby4Vo5rTgB in title for aasX2cby4Vo5rTgB in mxXKsCgL5OoP1evURZ8SdIfpBrwu):
			bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,582,C0dvhEbPWYlUtimM3x)
		elif zN7sZyFnw5JTE8 and 'الحلقة' in title:
			title = '_MOD_' + zN7sZyFnw5JTE8[0]
			if title not in u3Rztpl4VHO9GZ7jCBM65kvS:
				bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,583,C0dvhEbPWYlUtimM3x)
				u3Rztpl4VHO9GZ7jCBM65kvS.append(title)
		elif '/movseries/' in fCXyTlcmF4WuetVork:
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,581,C0dvhEbPWYlUtimM3x)
		else: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,583,C0dvhEbPWYlUtimM3x)
	if lHDuLVCy8kvqB6Rxh4Gs5K not in ['featured_movies','featured_series']:
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('"pagination(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if UUIohmv597bO83YCLgWS:
			PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
			items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?>(.*?)</a>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
			for fCXyTlcmF4WuetVork,title in items:
				if fCXyTlcmF4WuetVork=='#': continue
				fCXyTlcmF4WuetVork = ffBG4TaQU8lVF26R+'/'+fCXyTlcmF4WuetVork.strip('/')
				title = JIY6A30UOsQboNVqCn(title)
				bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'صفحة '+title,fCXyTlcmF4WuetVork,581)
		SwiW9ygZnaTl53PVbKzRtY = dEyT9xhGjolYzLCH7460w3.findall('showmore" href="(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if SwiW9ygZnaTl53PVbKzRtY:
			fCXyTlcmF4WuetVork = SwiW9ygZnaTl53PVbKzRtY[0]
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'مشاهدة المزيد',fCXyTlcmF4WuetVork,581)
	return
def YNcMvoVF5swlDBJI7PL(url,kbTg05YG6clitmjwoDx3VZQuq):
	ffBG4TaQU8lVF26R = F82MvyX4ThI6sbnA3efDoVS(url,'url')
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'SHAHIDNEWS-EPISODES-2nd')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	HG5rE20ORdbqUKWewuZCJP4zoXF6g = dEyT9xhGjolYzLCH7460w3.findall('nav-seasons"(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	items = []
	MSkCvHyJmlVYuZQGzpDNr6o1 = False
	if HG5rE20ORdbqUKWewuZCJP4zoXF6g and not kbTg05YG6clitmjwoDx3VZQuq:
		PPH1sQtTkDBbnlYpZfo5 = HG5rE20ORdbqUKWewuZCJP4zoXF6g[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)">(.*?)</a>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for kbTg05YG6clitmjwoDx3VZQuq,title in items:
			kbTg05YG6clitmjwoDx3VZQuq = kbTg05YG6clitmjwoDx3VZQuq.strip('#')
			if len(items)>1: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,url,583,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,kbTg05YG6clitmjwoDx3VZQuq)
			else: MSkCvHyJmlVYuZQGzpDNr6o1 = True
	else: MSkCvHyJmlVYuZQGzpDNr6o1 = True
	eTov6CfDcRZVJEAq5BH = dEyT9xhGjolYzLCH7460w3.findall('id="'+kbTg05YG6clitmjwoDx3VZQuq+'"(.*?)</div>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if eTov6CfDcRZVJEAq5BH and MSkCvHyJmlVYuZQGzpDNr6o1:
		PPH1sQtTkDBbnlYpZfo5 = eTov6CfDcRZVJEAq5BH[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?">(.*?)</a>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if items:
			for fCXyTlcmF4WuetVork,title in items:
				fCXyTlcmF4WuetVork = ffBG4TaQU8lVF26R+'/'+fCXyTlcmF4WuetVork.strip('/')
				bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,582)
		else:
			items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?title="(.*?)".*?image:url\((.*?)\)',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
			for fCXyTlcmF4WuetVork,title,C0dvhEbPWYlUtimM3x in items:
				if 'http' not in fCXyTlcmF4WuetVork: fCXyTlcmF4WuetVork = ffBG4TaQU8lVF26R+'/'+fCXyTlcmF4WuetVork.strip('/')
				bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,582)
	return
def TW6Z0zqaDl(url):
	ffBG4TaQU8lVF26R = F82MvyX4ThI6sbnA3efDoVS(url,'url')
	duef0gb3Mi1AV5WpN8 = []
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'SHAHIDNEWS-PLAY-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	fCXyTlcmF4WuetVork = dEyT9xhGjolYzLCH7460w3.findall('"Playerholder".*?href="(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork[0]
	if fCXyTlcmF4WuetVork and 'http' not in fCXyTlcmF4WuetVork: fCXyTlcmF4WuetVork = 'http:'+fCXyTlcmF4WuetVork
	hash = fCXyTlcmF4WuetVork.split('hash=')[1]
	ng8RFTvpBOxuMa2ySjYWqVZX = hash.split('__')
	kKU0my3NP8sD = []
	for jBaSGYDb0LuQ9dNAOzRpvT4CgHKMW in ng8RFTvpBOxuMa2ySjYWqVZX:
		try:
			jBaSGYDb0LuQ9dNAOzRpvT4CgHKMW = UodGe76Lu2IHTYPxBhjk1RpcaqrM.b64decode(jBaSGYDb0LuQ9dNAOzRpvT4CgHKMW+'=')
			if J1MoiYc7ZwzKS: jBaSGYDb0LuQ9dNAOzRpvT4CgHKMW = jBaSGYDb0LuQ9dNAOzRpvT4CgHKMW.decode(df6QpwGxuJVZr)
			kKU0my3NP8sD.append(jBaSGYDb0LuQ9dNAOzRpvT4CgHKMW)
		except: pass
	P3tys0cXWbiIUKk7HQ6n89V = '>'.join(kKU0my3NP8sD)
	P3tys0cXWbiIUKk7HQ6n89V = P3tys0cXWbiIUKk7HQ6n89V.splitlines()
	if 'farsol' not in str(P3tys0cXWbiIUKk7HQ6n89V):
		for fCXyTlcmF4WuetVork in P3tys0cXWbiIUKk7HQ6n89V:
			if ' => ' in fCXyTlcmF4WuetVork:
				title,fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork.split(' => ')
				fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork+'?named='+title+'__watch'
				duef0gb3Mi1AV5WpN8.append(fCXyTlcmF4WuetVork)
		import lqBJGK8hXO
		lqBJGK8hXO.ZDg1HavwueT85mcAOorC4hnS(duef0gb3Mi1AV5WpN8,sQU2GnRoMwLK8CBdfzmNr4jXyO,'video',url)
	else:
		title,fCXyTlcmF4WuetVork = P3tys0cXWbiIUKk7HQ6n89V[0].split(' => ')
		bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'رسالة من المبرمج','هذا الفيديو غير متوفر الآن'+OTlVEGYPSxsNaBdXUucqA3+'يرجى المحاولة لاحقا'+'\n\n'+title)
	return
def mUhJtHB9nw(search):
	search,brFQp5vmgJWdZfEkCBOlu9c,showDialogs = XkYnev3ZCA6ahO94(search)
	if search==iiy37aKq0pCEIOwfcTh61xb4U: search = TTBf6S08q1NKXd5v9wa()
	if search==iiy37aKq0pCEIOwfcTh61xb4U: return
	search = search.replace(iFBmE2MUIpSu34wsd7Rf6z,'+')
	url = JaQEtCzDXgos1cdZN+'/search.php?keywords='+search
	AIQeNZP4FMDw9S(url)
	return
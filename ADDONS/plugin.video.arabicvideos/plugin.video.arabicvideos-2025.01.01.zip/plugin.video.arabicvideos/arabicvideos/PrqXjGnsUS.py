# -*- coding: utf-8 -*-
from braVAkwfBN import *
sQU2GnRoMwLK8CBdfzmNr4jXyO = 'EGYBEST4'
ooQEi5O6tYsGVF8LU0TC3hgMeflBwH = '_EB4_'
JaQEtCzDXgos1cdZN = gZ4LwbKaOm[sQU2GnRoMwLK8CBdfzmNr4jXyO][0]
a8GCLIuWNkS = ['ايجي بست','اتصل بنا','ايجي بست الاصلي','ايجي بست الجديد','ايجي بست البديل','egybest','موقع ايجي بست']
def sHVM8YchrDjZAJ7(mode,url,zLEP9N4BOsVrXa,text):
	if   mode==800: EA7FzO1kMZGQXDd2giB0cwLom = jihuS9LVAvTrClPapMbUEwfn8XN()
	elif mode==801: EA7FzO1kMZGQXDd2giB0cwLom = AIQeNZP4FMDw9S(url,zLEP9N4BOsVrXa)
	elif mode==802: EA7FzO1kMZGQXDd2giB0cwLom = BaSyudevC40nsQHW5j7JX6RM9(url)
	elif mode==803: EA7FzO1kMZGQXDd2giB0cwLom = TW6Z0zqaDl(url)
	elif mode==804: EA7FzO1kMZGQXDd2giB0cwLom = pumnMZXzQg1EkAP(url)
	elif mode==806: EA7FzO1kMZGQXDd2giB0cwLom = jjQL1mhRn3VpBzNcidEaT4yKt9(url,zLEP9N4BOsVrXa)
	elif mode==809: EA7FzO1kMZGQXDd2giB0cwLom = mUhJtHB9nw(text)
	else: EA7FzO1kMZGQXDd2giB0cwLom = False
	return EA7FzO1kMZGQXDd2giB0cwLom
def jihuS9LVAvTrClPapMbUEwfn8XN():
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'بحث في الموقع',iiy37aKq0pCEIOwfcTh61xb4U,809,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'_REMEMBERRESULTS_')
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'فلتر',JaQEtCzDXgos1cdZN+'/trending',804,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'_REMEMBERRESULTS_')
	bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(Dxc7GChQwZ4kOlKHSbL06agnB,'GET',JaQEtCzDXgos1cdZN,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'EGYBEST4-MENU-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('nav-categories(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)">(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title in items:
			title = title.strip(iFBmE2MUIpSu34wsd7Rf6z)
			if any(aasX2cby4Vo5rTgB in title for aasX2cby4Vo5rTgB in a8GCLIuWNkS): continue
			if 'http' not in fCXyTlcmF4WuetVork: fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN+fCXyTlcmF4WuetVork
			bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,801)
		bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('mainContent(.*?)<footer>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('mainTitle.*?href="(.*?)".*?title="(.*?)"',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title in items:
			title = title.strip(iFBmE2MUIpSu34wsd7Rf6z)
			if any(aasX2cby4Vo5rTgB in title for aasX2cby4Vo5rTgB in a8GCLIuWNkS): continue
			if 'http' not in fCXyTlcmF4WuetVork: fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN+fCXyTlcmF4WuetVork
			bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,801,iiy37aKq0pCEIOwfcTh61xb4U,'mainmenu')
		bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('main-menu(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)">(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title in items:
			title = title.strip(iFBmE2MUIpSu34wsd7Rf6z)
			if any(aasX2cby4Vo5rTgB in title for aasX2cby4Vo5rTgB in a8GCLIuWNkS): continue
			if 'http' not in fCXyTlcmF4WuetVork: fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN+fCXyTlcmF4WuetVork
			bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,801)
	return Vxz6OndPIX4g2kaRp7
def jjQL1mhRn3VpBzNcidEaT4yKt9(url,type=iiy37aKq0pCEIOwfcTh61xb4U):
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'EGYBEST4-SEASONS_EPISODES-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('mainTitle.*?>(.*?)<(.*?)pageContent',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		zfbAhCqkmOoZWyGpT3KUIF9anBN,f9a8L1lCJvn6pIUuP,items = iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,[]
		for name,PPH1sQtTkDBbnlYpZfo5 in UUIohmv597bO83YCLgWS:
			if 'حلقات' in name: f9a8L1lCJvn6pIUuP = PPH1sQtTkDBbnlYpZfo5
			if 'مواسم' in name: zfbAhCqkmOoZWyGpT3KUIF9anBN = PPH1sQtTkDBbnlYpZfo5
		if zfbAhCqkmOoZWyGpT3KUIF9anBN and not type:
			items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?img="(.*?)".*?"title">(.*?)<',zfbAhCqkmOoZWyGpT3KUIF9anBN,dEyT9xhGjolYzLCH7460w3.DOTALL)
			if len(items)>1:
				for fCXyTlcmF4WuetVork,C0dvhEbPWYlUtimM3x,title in items:
					bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,806,C0dvhEbPWYlUtimM3x,'season')
		if f9a8L1lCJvn6pIUuP and len(items)<2:
			items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?img="(.*?)".*?"title">(.*?)<',f9a8L1lCJvn6pIUuP,dEyT9xhGjolYzLCH7460w3.DOTALL)
			if items:
				for fCXyTlcmF4WuetVork,C0dvhEbPWYlUtimM3x,title in items:
					bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,803,C0dvhEbPWYlUtimM3x)
			else:
				items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)">(.*?)<',f9a8L1lCJvn6pIUuP,dEyT9xhGjolYzLCH7460w3.DOTALL)
				for fCXyTlcmF4WuetVork,title in items:
					bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,803)
	return
def AIQeNZP4FMDw9S(url,type=iiy37aKq0pCEIOwfcTh61xb4U):
	LsjrhQpZKcn41EyDwlFBm0IYtX,start,uuX8TYmVoFRlvpQ7LZ,select,JJm06MvE1cZrojkPALugt8YXO9 = 0,0,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U
	if 'pagination' in type:
		iajEot7NHe,EwsmJ67cCYDIlg = url.split('?next=page&')
		rzR9SN7ApZuQhTDWEX3V6ga = {'Content-Type':'application/x-www-form-urlencoded'}
		oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'POST',iajEot7NHe,EwsmJ67cCYDIlg,rzR9SN7ApZuQhTDWEX3V6ga,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'EGYBEST4-TITLES-1st')
		Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
		z0spMAOfJElv6L1K9ae = 'secContent'+Vxz6OndPIX4g2kaRp7+'<footer>'
	else:
		oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'EGYBEST4-TITLES-2nd')
		Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
		z0spMAOfJElv6L1K9ae = Vxz6OndPIX4g2kaRp7
	items,ZZ9OJHhGUaIASWPD5eTBFwmRvo3Y7,HSAqBpsb2jRLvk9lx147rzY = [],False,False
	if not type and '/collections' not in url:
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('mainContent(.*?)</div>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if UUIohmv597bO83YCLgWS:
			PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
			items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?</i>(.*?)</a>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
			for fCXyTlcmF4WuetVork,title in items:
				title = title.strip(iFBmE2MUIpSu34wsd7Rf6z)
				bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,801,iiy37aKq0pCEIOwfcTh61xb4U,'submenu')
				ZZ9OJHhGUaIASWPD5eTBFwmRvo3Y7 = True
	if not ZZ9OJHhGUaIASWPD5eTBFwmRvo3Y7:
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('secContent(.*?)mainContent',z0spMAOfJElv6L1K9ae,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if UUIohmv597bO83YCLgWS:
			PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
			items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?img="(.*?)".*?"title">(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
			for fCXyTlcmF4WuetVork,C0dvhEbPWYlUtimM3x,title in items:
				fCXyTlcmF4WuetVork = a9I3YZjc6ySDPE4Kp(fCXyTlcmF4WuetVork)
				C0dvhEbPWYlUtimM3x = C0dvhEbPWYlUtimM3x.strip(OTlVEGYPSxsNaBdXUucqA3)
				title = JIY6A30UOsQboNVqCn(title)
				if '/series/' in fCXyTlcmF4WuetVork and type=='season': bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,806,C0dvhEbPWYlUtimM3x,'season')
				elif '/series/' in fCXyTlcmF4WuetVork: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,806,C0dvhEbPWYlUtimM3x)
				elif '/seasons/' in fCXyTlcmF4WuetVork: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,801,C0dvhEbPWYlUtimM3x,'season')
				elif '/collections' in url: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,801,C0dvhEbPWYlUtimM3x,'collections')
				else: bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,803,C0dvhEbPWYlUtimM3x)
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('loadMoreParams = (.*?);',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if UUIohmv597bO83YCLgWS:
			PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
			BehavuIfZnQ9xW6CXVgH = DeIL3qoa2UBtYPb('dict',PPH1sQtTkDBbnlYpZfo5)
			JJm06MvE1cZrojkPALugt8YXO9 = BehavuIfZnQ9xW6CXVgH['ajaxurl']
			FSU4DQVwsGvuCKae8Ph3q6ZYx = int(BehavuIfZnQ9xW6CXVgH['current_page'])+1
			q0qa1mIGyk = int(BehavuIfZnQ9xW6CXVgH['max_page'])
			U2U8JTIZwb7NOmf = BehavuIfZnQ9xW6CXVgH['posts'].replace('False','false').replace('True','true').replace('None','null')
			if FSU4DQVwsGvuCKae8Ph3q6ZYx<q0qa1mIGyk:
				EwsmJ67cCYDIlg = 'action=loadmore&query='+YqdaDIig21wBTWJeUHbc(U2U8JTIZwb7NOmf,iiy37aKq0pCEIOwfcTh61xb4U)+'&page='+str(FSU4DQVwsGvuCKae8Ph3q6ZYx)
				eCGwzSrqBmIv = JJm06MvE1cZrojkPALugt8YXO9+'?next=page&'+EwsmJ67cCYDIlg
				bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'جلب المزيد',eCGwzSrqBmIv,801,iiy37aKq0pCEIOwfcTh61xb4U,'pagination_'+type)
		elif '?next=page&' in url:
			EwsmJ67cCYDIlg,IIMp8kDh0zEeZJfyrtHBbRvjS = EwsmJ67cCYDIlg.rsplit('=',1)
			IIMp8kDh0zEeZJfyrtHBbRvjS = int(IIMp8kDh0zEeZJfyrtHBbRvjS)+1
			eCGwzSrqBmIv = iajEot7NHe+'?next=page&'+EwsmJ67cCYDIlg+'='+str(IIMp8kDh0zEeZJfyrtHBbRvjS)
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'جلب المزيد',eCGwzSrqBmIv,801,iiy37aKq0pCEIOwfcTh61xb4U,'pagination_'+type)
	return
def pumnMZXzQg1EkAP(url):
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'EGYBEST4-FILTERS-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('sub_nav(.*?)secContent ',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		ddfSDGyqEc = dEyT9xhGjolYzLCH7460w3.findall('"current_opt">(.*?)<(.*?)</div>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for name,PPH1sQtTkDBbnlYpZfo5 in ddfSDGyqEc:
			if 'التصنيف' in name: continue
			name = name.strip(iFBmE2MUIpSu34wsd7Rf6z)
			items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)">(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
			for fCXyTlcmF4WuetVork,aasX2cby4Vo5rTgB in items:
				title = name+':  '+aasX2cby4Vo5rTgB
				bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,801,iiy37aKq0pCEIOwfcTh61xb4U,'filter')
	return
def TW6Z0zqaDl(url):
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(hI7SkXd94fFzAHNZCQoMqEutbnWP,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'EGYBEST4-PLAY-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	UAhMnV3r89cWy7X1D05GBCwTqOP4p = dEyT9xhGjolYzLCH7460w3.findall('<td>التصنيف</td>.*?">(.*?)<',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UAhMnV3r89cWy7X1D05GBCwTqOP4p and IUF8hYKEGLmHDtXbuWNvnJ(sQU2GnRoMwLK8CBdfzmNr4jXyO,url,UAhMnV3r89cWy7X1D05GBCwTqOP4p): return
	ff2PjlcCF5ZWyIUbVguMz,a8jRBLmeA2ti6 = [],[]
	fCXyTlcmF4WuetVork = dEyT9xhGjolYzLCH7460w3.findall('postEmbed.*?src="(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if fCXyTlcmF4WuetVork:
		fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork[0].replace(OTlVEGYPSxsNaBdXUucqA3,iiy37aKq0pCEIOwfcTh61xb4U)
		a8jRBLmeA2ti6.append(fCXyTlcmF4WuetVork)
		Zw4M5DUStdE6xp7GI = F82MvyX4ThI6sbnA3efDoVS(fCXyTlcmF4WuetVork,'name')
		ff2PjlcCF5ZWyIUbVguMz.append(fCXyTlcmF4WuetVork+'?named='+Zw4M5DUStdE6xp7GI+'__embed')
	w8R1Vzb9kBd = dEyT9xhGjolYzLCH7460w3.findall('vo_theme_dir.*?"(.*?)".*?"(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if w8R1Vzb9kBd:
		JJm06MvE1cZrojkPALugt8YXO9,VlX2C0mPxeyD8wZYKLuf = w8R1Vzb9kBd[0]
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('postPlayer(.*?)</ul>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if UUIohmv597bO83YCLgWS:
			PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
			s5mYgweJjIvq = dEyT9xhGjolYzLCH7460w3.findall('<li.*?id\,(.*?)\);">(.*?)</li>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
			for wB890jKFSDV1,name in s5mYgweJjIvq:
				fCXyTlcmF4WuetVork = JJm06MvE1cZrojkPALugt8YXO9+'/temp/ajax/iframe.php?id='+VlX2C0mPxeyD8wZYKLuf+'&video='+wB890jKFSDV1
				ff2PjlcCF5ZWyIUbVguMz.append(fCXyTlcmF4WuetVork+'?named='+name+'__watch')
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('pageContentDown(.*?)</table>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('<tr>.*?<td>[ a-zA-Z]*(\d{3,4})[ a-zA-Z]*</td>.*?href="(.*?)"',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for pMAWqrwP80lR,fCXyTlcmF4WuetVork in items:
			if fCXyTlcmF4WuetVork not in a8jRBLmeA2ti6:
				if '/?url=' in fCXyTlcmF4WuetVork: fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork.split('/?url=')[1]
				a8jRBLmeA2ti6.append(fCXyTlcmF4WuetVork)
				Zw4M5DUStdE6xp7GI = F82MvyX4ThI6sbnA3efDoVS(fCXyTlcmF4WuetVork,'name')
				ff2PjlcCF5ZWyIUbVguMz.append(fCXyTlcmF4WuetVork+'?named='+Zw4M5DUStdE6xp7GI+'__download____'+pMAWqrwP80lR)
	import lqBJGK8hXO
	lqBJGK8hXO.ZDg1HavwueT85mcAOorC4hnS(ff2PjlcCF5ZWyIUbVguMz,sQU2GnRoMwLK8CBdfzmNr4jXyO,'video',url)
	return
def mUhJtHB9nw(search):
	search,brFQp5vmgJWdZfEkCBOlu9c,showDialogs = XkYnev3ZCA6ahO94(search)
	if not search: search = TTBf6S08q1NKXd5v9wa()
	if not search: return
	VVOtdjT9AF4Wk3GECqHL = search.replace(iFBmE2MUIpSu34wsd7Rf6z,'+')
	url = JaQEtCzDXgos1cdZN+'/?s='+VVOtdjT9AF4Wk3GECqHL
	AIQeNZP4FMDw9S(url,'search')
	return
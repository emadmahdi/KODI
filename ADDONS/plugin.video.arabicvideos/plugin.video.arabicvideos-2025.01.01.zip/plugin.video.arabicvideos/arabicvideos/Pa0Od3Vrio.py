# -*- coding: utf-8 -*-
from braVAkwfBN import *
sQU2GnRoMwLK8CBdfzmNr4jXyO = 'MOVIZLAND'
headers = { 'User-Agent' : iiy37aKq0pCEIOwfcTh61xb4U }
ooQEi5O6tYsGVF8LU0TC3hgMeflBwH = '_MVZ_'
JaQEtCzDXgos1cdZN = gZ4LwbKaOm[sQU2GnRoMwLK8CBdfzmNr4jXyO][0]
QSaKzorWqRMY8JkTtNdG1exb = gZ4LwbKaOm[sQU2GnRoMwLK8CBdfzmNr4jXyO][1]
def sHVM8YchrDjZAJ7(mode,url,text):
	if   mode==180: EA7FzO1kMZGQXDd2giB0cwLom = jihuS9LVAvTrClPapMbUEwfn8XN()
	elif mode==181: EA7FzO1kMZGQXDd2giB0cwLom = AIQeNZP4FMDw9S(url,text)
	elif mode==182: EA7FzO1kMZGQXDd2giB0cwLom = TW6Z0zqaDl(url)
	elif mode==183: EA7FzO1kMZGQXDd2giB0cwLom = YNcMvoVF5swlDBJI7PL(url)
	elif mode==188: EA7FzO1kMZGQXDd2giB0cwLom = YQKHRwPDsohO()
	elif mode==189: EA7FzO1kMZGQXDd2giB0cwLom = mUhJtHB9nw(text)
	else: EA7FzO1kMZGQXDd2giB0cwLom = False
	return EA7FzO1kMZGQXDd2giB0cwLom
def YQKHRwPDsohO():
	message = 'هذا الموقع تغير بالكامل ... وبحاجة الى اعادة برمجة من الصفر ... والمبرمج حاليا مشغول ويعاني من وعكة صحية ... ولهذا سوف يبقى الموقع مغلق الى ما شاء الله'
	bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'رسالة من المبرمج',message)
	return
def jihuS9LVAvTrClPapMbUEwfn8XN():
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'بحث في الموقع',iiy37aKq0pCEIOwfcTh61xb4U,189,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'_REMEMBERRESULTS_')
	bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'بوكس اوفيس موفيز لاند',JaQEtCzDXgos1cdZN,181,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'box-office')
	bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'أحدث الافلام',JaQEtCzDXgos1cdZN,181,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'latest-movies')
	bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'تليفزيون موفيز لاند',JaQEtCzDXgos1cdZN,181,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'tv')
	bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'الاكثر مشاهدة',JaQEtCzDXgos1cdZN,181,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'top-views')
	bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'أقوى الافلام الحالية',JaQEtCzDXgos1cdZN,181,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'top-movies')
	Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(Dxc7GChQwZ4kOlKHSbL06agnB,JaQEtCzDXgos1cdZN,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,'MOVIZLAND-MENU-1st')
	items = dEyT9xhGjolYzLCH7460w3.findall('<h2><a href="(.*?)".*?">(.*?)<',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	for fCXyTlcmF4WuetVork,title in items:
		bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,181)
	return Vxz6OndPIX4g2kaRp7
def AIQeNZP4FMDw9S(url,type=iiy37aKq0pCEIOwfcTh61xb4U):
	Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(PNjZMS7nxa9clHusz1,url,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,'MOVIZLAND-ITEMS-1st')
	if type=='latest-movies': PPH1sQtTkDBbnlYpZfo5 = dEyT9xhGjolYzLCH7460w3.findall('class="titleSection">أحدث الأفلام</h1>(.*?)<h1',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)[0]
	elif type=='box-office': PPH1sQtTkDBbnlYpZfo5 = dEyT9xhGjolYzLCH7460w3.findall('class="titleSection">بوكس اوفيس موفيز لاند</h1>(.*?)<h1',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)[0]
	elif type=='top-movies': PPH1sQtTkDBbnlYpZfo5 = dEyT9xhGjolYzLCH7460w3.findall('btn-2-overlay(.*?)<style>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)[0]
	elif type=='top-views': PPH1sQtTkDBbnlYpZfo5 = dEyT9xhGjolYzLCH7460w3.findall('btn-1 btn-absoly(.*?)btn-2 btn-absoly',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)[0]
	elif type=='tv': PPH1sQtTkDBbnlYpZfo5 = dEyT9xhGjolYzLCH7460w3.findall('class="titleSection">تليفزيون موفيز لاند</h1>(.*?)class="paging"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)[0]
	else: PPH1sQtTkDBbnlYpZfo5 = Vxz6OndPIX4g2kaRp7
	if type in ['top-views','top-movies']:
		items = dEyT9xhGjolYzLCH7460w3.findall('style="background-image:url\(\'(.*?)\'.*?href="(.*?)".*?href="(.*?)".*?bottom-title.*?>(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	else: items = dEyT9xhGjolYzLCH7460w3.findall('height="3[0-9]+" src="(.*?)".*?bottom-title.*?href=.*?>(.*?)<.*?href="(.*?)".*?href="(.*?)"',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	u3Rztpl4VHO9GZ7jCBM65kvS = []
	QIEZDm5syS6Lvulf0 = ['فيلم','الحلقة','الحلقه','عرض','Raw','SmackDown','اعلان','اجزاء']
	for C0dvhEbPWYlUtimM3x,NZpmhLBscQeR,yaABUVqiE3nk8se,xspSwKH1XmgLhv in items:
		if type in ['top-views','top-movies']:
			C0dvhEbPWYlUtimM3x,fCXyTlcmF4WuetVork,hx0dU3Ki7AyEfkSZY6TmN2BwtX,title = C0dvhEbPWYlUtimM3x,NZpmhLBscQeR,yaABUVqiE3nk8se,xspSwKH1XmgLhv
		else: C0dvhEbPWYlUtimM3x,title,fCXyTlcmF4WuetVork,hx0dU3Ki7AyEfkSZY6TmN2BwtX = C0dvhEbPWYlUtimM3x,NZpmhLBscQeR,yaABUVqiE3nk8se,xspSwKH1XmgLhv
		fCXyTlcmF4WuetVork = a9I3YZjc6ySDPE4Kp(fCXyTlcmF4WuetVork)
		fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork.replace('?view=true',iiy37aKq0pCEIOwfcTh61xb4U)
		title = JIY6A30UOsQboNVqCn(title)
		if 'بجودة ' in title or 'بجوده ' in title:
			title = '_MOD_' + title.replace('بجودة ',iiy37aKq0pCEIOwfcTh61xb4U).replace('بجوده ',iiy37aKq0pCEIOwfcTh61xb4U)
		title = title.strip(iFBmE2MUIpSu34wsd7Rf6z)
		if 'الحلقة' in title or 'الحلقه' in title:
			zN7sZyFnw5JTE8 = dEyT9xhGjolYzLCH7460w3.findall('(.*?) (الحلقة|الحلقه) \d+',title,dEyT9xhGjolYzLCH7460w3.DOTALL)
			if zN7sZyFnw5JTE8:
				title = '_MOD_' + zN7sZyFnw5JTE8[0][0]
				if title not in u3Rztpl4VHO9GZ7jCBM65kvS:
					bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,183,C0dvhEbPWYlUtimM3x)
					u3Rztpl4VHO9GZ7jCBM65kvS.append(title)
		elif any(aasX2cby4Vo5rTgB in title for aasX2cby4Vo5rTgB in QIEZDm5syS6Lvulf0):
			fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork + '?servers=' + hx0dU3Ki7AyEfkSZY6TmN2BwtX
			bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,182,C0dvhEbPWYlUtimM3x)
		else:
			fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork + '?servers=' + hx0dU3Ki7AyEfkSZY6TmN2BwtX
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,183,C0dvhEbPWYlUtimM3x)
	if type==iiy37aKq0pCEIOwfcTh61xb4U:
		items = dEyT9xhGjolYzLCH7460w3.findall('\n<li><a href="(.*?)".*?>(.*?)<',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title in items:
			title = JIY6A30UOsQboNVqCn(title)
			title = title.replace('الصفحة ',iiy37aKq0pCEIOwfcTh61xb4U)
			if title!=iiy37aKq0pCEIOwfcTh61xb4U:
				bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'صفحة '+title,fCXyTlcmF4WuetVork,181)
	return
def YNcMvoVF5swlDBJI7PL(url):
	eCGwzSrqBmIv = url.split('?servers=')[0]
	Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(PNjZMS7nxa9clHusz1,eCGwzSrqBmIv,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,'MOVIZLAND-EPISODES-1st')
	PPH1sQtTkDBbnlYpZfo5 = dEyT9xhGjolYzLCH7460w3.findall('<title>(.*?)</title>.*?height="([0-9]+)" src="(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	title,qBIUYtOjTAx0,C0dvhEbPWYlUtimM3x = PPH1sQtTkDBbnlYpZfo5[0]
	name = dEyT9xhGjolYzLCH7460w3.findall('(.*?) (الحلقة|الحلقه) [0-9]+',title,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if name: name = '_MOD_' + name[0][0]
	else: name = title
	items = []
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('class="episodesNumbers"(.*?)</div>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)"',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork in items:
			fCXyTlcmF4WuetVork = a9I3YZjc6ySDPE4Kp(fCXyTlcmF4WuetVork)
			title = dEyT9xhGjolYzLCH7460w3.findall('(الحلقة|الحلقه)-([0-9]+)',fCXyTlcmF4WuetVork.split('/')[-2],dEyT9xhGjolYzLCH7460w3.DOTALL)
			if not title: title = dEyT9xhGjolYzLCH7460w3.findall('()-([0-9]+)',fCXyTlcmF4WuetVork.split('/')[-2],dEyT9xhGjolYzLCH7460w3.DOTALL)
			if title: title = iFBmE2MUIpSu34wsd7Rf6z + title[0][1]
			else: title = iiy37aKq0pCEIOwfcTh61xb4U
			title = name + ' - ' + 'الحلقة' + title
			title = JIY6A30UOsQboNVqCn(title)
			bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,182,C0dvhEbPWYlUtimM3x)
	if not items:
		title = JIY6A30UOsQboNVqCn(title)
		if 'بجودة ' in title or 'بجوده ' in title:
			title = '_MOD_' + title.replace('بجودة ',iiy37aKq0pCEIOwfcTh61xb4U).replace('بجوده ',iiy37aKq0pCEIOwfcTh61xb4U)
		bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,url,182,C0dvhEbPWYlUtimM3x)
	return
def TW6Z0zqaDl(url):
	ddysUlpTPGoEQeXhfNjC = url.split('?servers=')
	eCGwzSrqBmIv = ddysUlpTPGoEQeXhfNjC[0]
	del ddysUlpTPGoEQeXhfNjC[0]
	Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(Dxc7GChQwZ4kOlKHSbL06agnB,eCGwzSrqBmIv,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,'MOVIZLAND-PLAY-1st')
	fCXyTlcmF4WuetVork = dEyT9xhGjolYzLCH7460w3.findall('font-size: 25px;" href="(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)[0]
	if fCXyTlcmF4WuetVork not in ddysUlpTPGoEQeXhfNjC: ddysUlpTPGoEQeXhfNjC.append(fCXyTlcmF4WuetVork)
	duef0gb3Mi1AV5WpN8 = []
	for fCXyTlcmF4WuetVork in ddysUlpTPGoEQeXhfNjC:
		if '://moshahda.' in fCXyTlcmF4WuetVork:
			H3Y2FzSkmch5x = fCXyTlcmF4WuetVork
			duef0gb3Mi1AV5WpN8.append(H3Y2FzSkmch5x+'?named=Main')
	for fCXyTlcmF4WuetVork in ddysUlpTPGoEQeXhfNjC:
		if '://vb.movizland.' in fCXyTlcmF4WuetVork:
			Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(Dxc7GChQwZ4kOlKHSbL06agnB,fCXyTlcmF4WuetVork,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,'MOVIZLAND-PLAY-2nd')
			Vxz6OndPIX4g2kaRp7 = Vxz6OndPIX4g2kaRp7.decode('windows-1256').encode(df6QpwGxuJVZr)
			Vxz6OndPIX4g2kaRp7 = Vxz6OndPIX4g2kaRp7.replace('src="http://up.movizland.com/uploads/13721411411.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"')
			Vxz6OndPIX4g2kaRp7 = Vxz6OndPIX4g2kaRp7.replace('src="http://up.movizland.online/uploads/13721411411.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"')
			Vxz6OndPIX4g2kaRp7 = Vxz6OndPIX4g2kaRp7.replace('</a></div><br /><div align="center">','src="/uploads/13721411411.png"')
			Vxz6OndPIX4g2kaRp7 = Vxz6OndPIX4g2kaRp7.replace('class="tborder" align="center"','src="/uploads/13721411411.png"')
			UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('(src="/uploads/13721411411.png".*?href="http://moshahda\..*?/\w+.html".*?src="/uploads/13721411411.png")',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
			if UUIohmv597bO83YCLgWS:
				hTokmyvgtKG,j6P7d92fziHV3s = [],[]
				if len(UUIohmv597bO83YCLgWS)==1:
					title = iiy37aKq0pCEIOwfcTh61xb4U
					PPH1sQtTkDBbnlYpZfo5 = Vxz6OndPIX4g2kaRp7
				else:
					for PPH1sQtTkDBbnlYpZfo5 in UUIohmv597bO83YCLgWS:
						U462wftipjCPA1hLuGsKr8koxnd = dEyT9xhGjolYzLCH7460w3.findall('src="/uploads/13721411411.png".*?http://up.movizland.(online|com)/uploads/.*?\*\*\*\*\*\*\*+(.*?src="/uploads/13721411411.png")',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
						if U462wftipjCPA1hLuGsKr8koxnd: PPH1sQtTkDBbnlYpZfo5 = 'src="/uploads/13721411411.png"  \n  ' + U462wftipjCPA1hLuGsKr8koxnd[0][1]
						U462wftipjCPA1hLuGsKr8koxnd = dEyT9xhGjolYzLCH7460w3.findall('src="/uploads/13721411411.png".*?<hr size="1" style="color:'+'#'+'333; background-color:'+'#'+'333" />(.*?href="http://moshahda\..*?/\w+.html".*?src="/uploads/13721411411.png")',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
						if U462wftipjCPA1hLuGsKr8koxnd: PPH1sQtTkDBbnlYpZfo5 = 'src="/uploads/13721411411.png"  \n  ' + U462wftipjCPA1hLuGsKr8koxnd[0]
						U462wftipjCPA1hLuGsKr8koxnd = dEyT9xhGjolYzLCH7460w3.findall('(src="/uploads/13721411411.png".*?href="http://moshahda\..*?/\w+.html".*?)<hr size="1" style="color:'+'#'+'333; background-color:'+'#'+'333" />.*?src="/uploads/13721411411.png"',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
						if U462wftipjCPA1hLuGsKr8koxnd: PPH1sQtTkDBbnlYpZfo5 = U462wftipjCPA1hLuGsKr8koxnd[0] + '  \n  src="/uploads/13721411411.png"'
						RdJ27OKIWSsLiCB56zTtZ = dEyT9xhGjolYzLCH7460w3.findall('<(.*?)http://up.movizland.(online|com)/uploads/',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
						title = dEyT9xhGjolYzLCH7460w3.findall('> *([^<>]+) *<',RdJ27OKIWSsLiCB56zTtZ[0][0],dEyT9xhGjolYzLCH7460w3.DOTALL)
						title = iFBmE2MUIpSu34wsd7Rf6z.join(title)
						title = title.strip(iFBmE2MUIpSu34wsd7Rf6z)
						title = title.replace(Wc5GekRC0HQLz7,iFBmE2MUIpSu34wsd7Rf6z).replace(Wc5GekRC0HQLz7,iFBmE2MUIpSu34wsd7Rf6z).replace(Wc5GekRC0HQLz7,iFBmE2MUIpSu34wsd7Rf6z).replace(Wc5GekRC0HQLz7,iFBmE2MUIpSu34wsd7Rf6z).replace(Wc5GekRC0HQLz7,iFBmE2MUIpSu34wsd7Rf6z)
						hTokmyvgtKG.append(title)
					mmfrx2S5XqknFTDeRhj49LuYv1wW0 = ccv1mVPUsnr('أختر الفيديو المطلوب:', hTokmyvgtKG)
					if mmfrx2S5XqknFTDeRhj49LuYv1wW0 == -1 : return
					title = hTokmyvgtKG[mmfrx2S5XqknFTDeRhj49LuYv1wW0]
					PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[mmfrx2S5XqknFTDeRhj49LuYv1wW0]
				fCXyTlcmF4WuetVork = dEyT9xhGjolYzLCH7460w3.findall('href="(http://moshahda\..*?/\w+.html)"',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
				tluWDqj4UpkI9scxS21m = fCXyTlcmF4WuetVork[0]
				duef0gb3Mi1AV5WpN8.append(tluWDqj4UpkI9scxS21m+'?named=Forum')
				PPH1sQtTkDBbnlYpZfo5 = PPH1sQtTkDBbnlYpZfo5.replace('ـ',iiy37aKq0pCEIOwfcTh61xb4U)
				PPH1sQtTkDBbnlYpZfo5 = PPH1sQtTkDBbnlYpZfo5.replace('src="http://up.movizland.online/uploads/1517412175296.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="both"  \n  ')
				PPH1sQtTkDBbnlYpZfo5 = PPH1sQtTkDBbnlYpZfo5.replace('src="http://up.movizland.com/uploads/1517412175296.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="both"  \n  ')
				PPH1sQtTkDBbnlYpZfo5 = PPH1sQtTkDBbnlYpZfo5.replace('سيرفرات التحميل','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="download"  \n  ')
				PPH1sQtTkDBbnlYpZfo5 = PPH1sQtTkDBbnlYpZfo5.replace('روابط التحميل','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="download"  \n  ')
				PPH1sQtTkDBbnlYpZfo5 = PPH1sQtTkDBbnlYpZfo5.replace('سيرفرات المشاهد','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="watch"  \n  ')
				PPH1sQtTkDBbnlYpZfo5 = PPH1sQtTkDBbnlYpZfo5.replace('روابط المشاهد','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="watch"  \n  ')
				WMwY2q79eydZ0g = dEyT9xhGjolYzLCH7460w3.findall('(src="/uploads/13721411411.png".*?href="http://e5tsar.com/\d+".*?src="/uploads/13721411411.png")',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
				for Sfh4YtZQxHbONg9JjDc in WMwY2q79eydZ0g:
					type = dEyT9xhGjolYzLCH7460w3.findall(' typetype="(.*?)" ',Sfh4YtZQxHbONg9JjDc)
					if type:
						if type[0]!='both': type = '__'+type[0]
						else: type = iiy37aKq0pCEIOwfcTh61xb4U
					items = dEyT9xhGjolYzLCH7460w3.findall('(?<!http://e5tsar.com/)(\w+[ \w]*</font>.*?|\w+[ \w]*<br />.*?)href="(http://e5tsar.com/.*?)"',Sfh4YtZQxHbONg9JjDc,dEyT9xhGjolYzLCH7460w3.DOTALL)
					for WL6F3KrIO8GmeP9,fCXyTlcmF4WuetVork in items:
						title = dEyT9xhGjolYzLCH7460w3.findall('(\w+[ \w]*)<',WL6F3KrIO8GmeP9)
						title = title[-1]
						fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork + '?named=' + title + type
						duef0gb3Mi1AV5WpN8.append(fCXyTlcmF4WuetVork)
	O5Pwg3UFyX0k9E = eCGwzSrqBmIv.replace(JaQEtCzDXgos1cdZN,QSaKzorWqRMY8JkTtNdG1exb)
	Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(Dxc7GChQwZ4kOlKHSbL06agnB,O5Pwg3UFyX0k9E,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,'MOVIZLAND-PLAY-3rd')
	items = dEyT9xhGjolYzLCH7460w3.findall('" href="(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if items:
		zdQJlZjOv7LiVw34eGW = items[-1]
		duef0gb3Mi1AV5WpN8.append(zdQJlZjOv7LiVw34eGW+'?named=Mobile')
	import lqBJGK8hXO
	lqBJGK8hXO.ZDg1HavwueT85mcAOorC4hnS(duef0gb3Mi1AV5WpN8,sQU2GnRoMwLK8CBdfzmNr4jXyO,'video',url)
	return
def mUhJtHB9nw(search):
	search,brFQp5vmgJWdZfEkCBOlu9c,showDialogs = XkYnev3ZCA6ahO94(search)
	if search==iiy37aKq0pCEIOwfcTh61xb4U: search = TTBf6S08q1NKXd5v9wa()
	if search==iiy37aKq0pCEIOwfcTh61xb4U: return
	search = search.replace(iFBmE2MUIpSu34wsd7Rf6z,'+')
	Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(PNjZMS7nxa9clHusz1,JaQEtCzDXgos1cdZN,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,'MOVIZLAND-SEARCH-1st')
	items = dEyT9xhGjolYzLCH7460w3.findall('<option value="(.*?)">(.*?)</option>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	qjSbmiVELDwOgxNXtI57JQn4o = [ iiy37aKq0pCEIOwfcTh61xb4U ]
	j3b52FqCSkuRHGMcYe9s1BA = [ 'الكل وبدون فلتر' ]
	for RRIscyLmNH9dq2Dio3TSr,title in items:
		qjSbmiVELDwOgxNXtI57JQn4o.append(RRIscyLmNH9dq2Dio3TSr)
		j3b52FqCSkuRHGMcYe9s1BA.append(title)
	if RRIscyLmNH9dq2Dio3TSr:
		mmfrx2S5XqknFTDeRhj49LuYv1wW0 = ccv1mVPUsnr('اختر الفلتر المناسب:', j3b52FqCSkuRHGMcYe9s1BA)
		if mmfrx2S5XqknFTDeRhj49LuYv1wW0 == -1 : return
		RRIscyLmNH9dq2Dio3TSr = qjSbmiVELDwOgxNXtI57JQn4o[mmfrx2S5XqknFTDeRhj49LuYv1wW0]
	else: RRIscyLmNH9dq2Dio3TSr = iiy37aKq0pCEIOwfcTh61xb4U
	url = JaQEtCzDXgos1cdZN + '/?s='+search+'&mcat='+RRIscyLmNH9dq2Dio3TSr
	AIQeNZP4FMDw9S(url)
	return
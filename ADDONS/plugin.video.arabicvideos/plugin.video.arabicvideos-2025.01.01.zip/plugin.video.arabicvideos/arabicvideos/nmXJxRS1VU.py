# -*- coding: utf-8 -*-
from braVAkwfBN import *
sQU2GnRoMwLK8CBdfzmNr4jXyO = 'ARBLIONZ'
headers = { 'User-Agent' : iiy37aKq0pCEIOwfcTh61xb4U }
ooQEi5O6tYsGVF8LU0TC3hgMeflBwH = '_ARL_'
JaQEtCzDXgos1cdZN = gZ4LwbKaOm[sQU2GnRoMwLK8CBdfzmNr4jXyO][0]
a8GCLIuWNkS = ['عروض المصارعة','الكل','الرئيسية','العاب','برامج كمبيوتر','موبايل و جوال','القسم الاسلامي']
def sHVM8YchrDjZAJ7(mode,url,text):
	if   mode==200: EA7FzO1kMZGQXDd2giB0cwLom = jihuS9LVAvTrClPapMbUEwfn8XN()
	elif mode==201: EA7FzO1kMZGQXDd2giB0cwLom = AIQeNZP4FMDw9S(url)
	elif mode==202: EA7FzO1kMZGQXDd2giB0cwLom = TW6Z0zqaDl(url)
	elif mode==203: EA7FzO1kMZGQXDd2giB0cwLom = YNcMvoVF5swlDBJI7PL(url)
	elif mode==204: EA7FzO1kMZGQXDd2giB0cwLom = chQHNdWgTSDjti8R9pJUf(url,'FILTERS___'+text)
	elif mode==205: EA7FzO1kMZGQXDd2giB0cwLom = chQHNdWgTSDjti8R9pJUf(url,'CATEGORIES___'+text)
	elif mode==209: EA7FzO1kMZGQXDd2giB0cwLom = mUhJtHB9nw(text)
	else: EA7FzO1kMZGQXDd2giB0cwLom = False
	return EA7FzO1kMZGQXDd2giB0cwLom
def jihuS9LVAvTrClPapMbUEwfn8XN():
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'بحث في الموقع',iiy37aKq0pCEIOwfcTh61xb4U,209,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'_REMEMBERRESULTS_')
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'فلتر محدد',JaQEtCzDXgos1cdZN,205)
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'فلتر كامل',JaQEtCzDXgos1cdZN,204)
	bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'مميزة',JaQEtCzDXgos1cdZN+'??trending',201)
	bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'أفلام مميزة',JaQEtCzDXgos1cdZN+'??trending_movies',201)
	bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'مسلسلات مميزة',JaQEtCzDXgos1cdZN+'??trending_series',201)
	bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'الصفحة الرئيسية',JaQEtCzDXgos1cdZN+'??mainpage',201)
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(Dxc7GChQwZ4kOlKHSbL06agnB,'GET',JaQEtCzDXgos1cdZN,iiy37aKq0pCEIOwfcTh61xb4U,headers,True,iiy37aKq0pCEIOwfcTh61xb4U,'ARBLIONZ-MENU-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('categories-tabs(.*?)MainRow',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('data-get="(.*?)".*?<h3>(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for filter,title in items:
			fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN+'/ajax/home/more?filter='+filter
			bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,201)
		bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('navigation-menu(.*?)</div>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
	items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?>(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	for fCXyTlcmF4WuetVork,title in items:
		if 'http' not in fCXyTlcmF4WuetVork: fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN+fCXyTlcmF4WuetVork
		title = title.strip(iFBmE2MUIpSu34wsd7Rf6z)
		if not any(aasX2cby4Vo5rTgB in title for aasX2cby4Vo5rTgB in a8GCLIuWNkS):
			bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,201)
	return Vxz6OndPIX4g2kaRp7
def AIQeNZP4FMDw9S(url):
	if '??' in url: url,type = url.split('??')
	else: type = iiy37aKq0pCEIOwfcTh61xb4U
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,headers,True,iiy37aKq0pCEIOwfcTh61xb4U,'ARBLIONZ-TITLES-2nd')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content.encode(df6QpwGxuJVZr)
	if 'getposts' in url: UUIohmv597bO83YCLgWS = [Vxz6OndPIX4g2kaRp7]
	elif type=='trending':
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('MasterSlider(.*?)</div>\n *</div>\n *</div>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	elif type=='trending_movies':
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('Slider_1(.*?)</div>.</div>.</div>.</div>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	elif type=='trending_series':
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('Slider_2(.*?)</div>.</div>.</div>.</div>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	elif type=='111mainpage':
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('class="container page-content"(.*?)class="tabs"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	else:
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('page-content(.*?)main-footer',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if not UUIohmv597bO83YCLgWS: return
	PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
	QIEZDm5syS6Lvulf0 = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	items = dEyT9xhGjolYzLCH7460w3.findall('content-box".*?src="(.*?)".*?href="(.*?)".*?<h3>(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if not items:
		items = dEyT9xhGjolYzLCH7460w3.findall('SliderItem".*?href="(.*?)".*?image: url\((.*?)\).*?<h2>(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		P3tys0cXWbiIUKk7HQ6n89V,dqYh4p9eBu0Riw2TSVA,v1JrBsOo8Qyzk = zip(*items)
		items = zip(dqYh4p9eBu0Riw2TSVA,P3tys0cXWbiIUKk7HQ6n89V,v1JrBsOo8Qyzk)
	u3Rztpl4VHO9GZ7jCBM65kvS = []
	for C0dvhEbPWYlUtimM3x,fCXyTlcmF4WuetVork,title in items:
		if '/series/' in fCXyTlcmF4WuetVork: continue
		fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork.strip('/')
		title = JIY6A30UOsQboNVqCn(title)
		title = title.strip(iFBmE2MUIpSu34wsd7Rf6z)
		if '/film/' in fCXyTlcmF4WuetVork or any(aasX2cby4Vo5rTgB in title for aasX2cby4Vo5rTgB in QIEZDm5syS6Lvulf0):
			bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,202,C0dvhEbPWYlUtimM3x)
		elif '/episode/' in fCXyTlcmF4WuetVork and 'الحلقة' in title:
			zN7sZyFnw5JTE8 = dEyT9xhGjolYzLCH7460w3.findall('(.*?) الحلقة \d+',title,dEyT9xhGjolYzLCH7460w3.DOTALL)
			if zN7sZyFnw5JTE8:
				title = '_MOD_' + zN7sZyFnw5JTE8[0]
				if title not in u3Rztpl4VHO9GZ7jCBM65kvS:
					bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,203,C0dvhEbPWYlUtimM3x)
					u3Rztpl4VHO9GZ7jCBM65kvS.append(title)
		elif '/pack/' in fCXyTlcmF4WuetVork:
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork+'/films',201,C0dvhEbPWYlUtimM3x)
		else: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,203,C0dvhEbPWYlUtimM3x)
	if type in [iiy37aKq0pCEIOwfcTh61xb4U,'mainpage']:
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('class="pagination(.*?)</div>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if UUIohmv597bO83YCLgWS:
			PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
			items = dEyT9xhGjolYzLCH7460w3.findall('href=["\'](http.*?)["\'].*?>(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
			for fCXyTlcmF4WuetVork,title in items:
				fCXyTlcmF4WuetVork = JIY6A30UOsQboNVqCn(fCXyTlcmF4WuetVork)
				title = JIY6A30UOsQboNVqCn(title)
				title = title.replace('الصفحة ',iiy37aKq0pCEIOwfcTh61xb4U)
				if 'search?s=' in url:
					v6woyFrmcbAu3KLHUDpW5tfh = fCXyTlcmF4WuetVork.split('page=')[1]
					OzJT43HeqwMFZ = url.split('page=')[1]
					fCXyTlcmF4WuetVork = url.replace('page='+OzJT43HeqwMFZ,'page='+v6woyFrmcbAu3KLHUDpW5tfh)
				if title!=iiy37aKq0pCEIOwfcTh61xb4U: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'صفحة '+title,fCXyTlcmF4WuetVork,201)
	return
def YNcMvoVF5swlDBJI7PL(url):
	KEAY7S3Up1f0HFjkVcLxP5se9D,items,v7CQL4K56PzGRO = -1,[],[]
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(PNjZMS7nxa9clHusz1,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,headers,True,iiy37aKq0pCEIOwfcTh61xb4U,'ARBLIONZ-EPISODES-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content.encode(df6QpwGxuJVZr)
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('ti-list-numbered(.*?)</div>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		v7CQL4K56PzGRO = []
		ddfSDGyqEc = iiy37aKq0pCEIOwfcTh61xb4U.join(UUIohmv597bO83YCLgWS)
		items = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)"',ddfSDGyqEc,dEyT9xhGjolYzLCH7460w3.DOTALL)
	items.append(url)
	items = set(items)
	for fCXyTlcmF4WuetVork in items:
		fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork.strip('/')
		title = '_MOD_' + fCXyTlcmF4WuetVork.split('/')[-1].replace('-',iFBmE2MUIpSu34wsd7Rf6z)
		MGUpOVcyHm3P9xC8ij76QlfY = dEyT9xhGjolYzLCH7460w3.findall('الحلقة-(\d+)',fCXyTlcmF4WuetVork.split('/')[-1],dEyT9xhGjolYzLCH7460w3.DOTALL)
		if MGUpOVcyHm3P9xC8ij76QlfY: MGUpOVcyHm3P9xC8ij76QlfY = MGUpOVcyHm3P9xC8ij76QlfY[0]
		else: MGUpOVcyHm3P9xC8ij76QlfY = '0'
		v7CQL4K56PzGRO.append([fCXyTlcmF4WuetVork,title,MGUpOVcyHm3P9xC8ij76QlfY])
	items = sorted(v7CQL4K56PzGRO, reverse=False, key=lambda key: int(key[2]))
	CuW69BJrQeUk8AMsPm = str(items).count('/season/')
	KEAY7S3Up1f0HFjkVcLxP5se9D = str(items).count('/episode/')
	if CuW69BJrQeUk8AMsPm>1 and KEAY7S3Up1f0HFjkVcLxP5se9D>0 and '/season/' not in url:
		for fCXyTlcmF4WuetVork,title,MGUpOVcyHm3P9xC8ij76QlfY in items:
			if '/season/' in fCXyTlcmF4WuetVork:
				bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,203)
	else:
		for fCXyTlcmF4WuetVork,title,MGUpOVcyHm3P9xC8ij76QlfY in items:
			if '/season/' not in fCXyTlcmF4WuetVork:
				title = a9I3YZjc6ySDPE4Kp(title)
				bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,202)
	return
def TW6Z0zqaDl(url):
	duef0gb3Mi1AV5WpN8 = []
	ng8RFTvpBOxuMa2ySjYWqVZX = url.split('/')
	WbXtgYqELOUSNZd15epAFchMHJCVso = JaQEtCzDXgos1cdZN
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(Dxc7GChQwZ4kOlKHSbL06agnB,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,headers,True,True,'ARBLIONZ-PLAY-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content.encode(df6QpwGxuJVZr)
	id = dEyT9xhGjolYzLCH7460w3.findall('postId:"(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if not id: id = dEyT9xhGjolYzLCH7460w3.findall('post_id=(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if not id: id = dEyT9xhGjolYzLCH7460w3.findall('post-id="(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if id: id = id[0]
	if '/watch/' in Vxz6OndPIX4g2kaRp7:
		eCGwzSrqBmIv = url.replace(ng8RFTvpBOxuMa2ySjYWqVZX[3],'watch')
		oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(Dxc7GChQwZ4kOlKHSbL06agnB,'GET',eCGwzSrqBmIv,iiy37aKq0pCEIOwfcTh61xb4U,headers,True,True,'ARBLIONZ-PLAY-2nd')
		z0spMAOfJElv6L1K9ae = oCJ8TdG2LwSIVcbaUnhB.content.encode(df6QpwGxuJVZr)
		oBCcmrv9tzPEOa5ILk7j = dEyT9xhGjolYzLCH7460w3.findall('data-embedd="(.*?)".*?alt="(.*?)"',z0spMAOfJElv6L1K9ae,dEyT9xhGjolYzLCH7460w3.DOTALL)
		lFmsiNI2UDoJBdVCQtqx4WPXb7 = dEyT9xhGjolYzLCH7460w3.findall('data-embedd=".*?(http.*?)("|&quot;)',z0spMAOfJElv6L1K9ae,dEyT9xhGjolYzLCH7460w3.DOTALL)
		bq17234fkwjKzc5U69QZ = dEyT9xhGjolYzLCH7460w3.findall('src=&quot;(.*?)&quot;.*?>(.*?)<',z0spMAOfJElv6L1K9ae,dEyT9xhGjolYzLCH7460w3.DOTALL|dEyT9xhGjolYzLCH7460w3.IGNORECASE)
		kD1Vylqvauw07EG9RnAbx4drY8 = dEyT9xhGjolYzLCH7460w3.findall('data-embedd="(.*?)">\n*.*?server_image">\n(.*?)\n',z0spMAOfJElv6L1K9ae)
		poZItberOCBND072KXSHif = dEyT9xhGjolYzLCH7460w3.findall('src=&quot;(.*?)&quot;.*?alt="(.*?)"',z0spMAOfJElv6L1K9ae,dEyT9xhGjolYzLCH7460w3.DOTALL|dEyT9xhGjolYzLCH7460w3.IGNORECASE)
		rxs2EZXfFA0VyanRhwS = dEyT9xhGjolYzLCH7460w3.findall('server="(.*?)".*?<span>(.*?)<',z0spMAOfJElv6L1K9ae,dEyT9xhGjolYzLCH7460w3.DOTALL|dEyT9xhGjolYzLCH7460w3.IGNORECASE)
		items = oBCcmrv9tzPEOa5ILk7j+lFmsiNI2UDoJBdVCQtqx4WPXb7+bq17234fkwjKzc5U69QZ+kD1Vylqvauw07EG9RnAbx4drY8+poZItberOCBND072KXSHif+rxs2EZXfFA0VyanRhwS
		if not items:
			items = dEyT9xhGjolYzLCH7460w3.findall('<span>(.*?)</span>.*?src="(.*?)"',z0spMAOfJElv6L1K9ae,dEyT9xhGjolYzLCH7460w3.DOTALL|dEyT9xhGjolYzLCH7460w3.IGNORECASE)
			items = [(g9k3MPLDoW4E8pRTFw,DToJiUqZ8rBGbhfISdxue2kv) for DToJiUqZ8rBGbhfISdxue2kv,g9k3MPLDoW4E8pRTFw in items]
		for Zw4M5DUStdE6xp7GI,title in items:
			if '.png' in Zw4M5DUStdE6xp7GI: continue
			if '.jpg' in Zw4M5DUStdE6xp7GI: continue
			if '&quot;' in Zw4M5DUStdE6xp7GI: continue
			pMAWqrwP80lR = dEyT9xhGjolYzLCH7460w3.findall('\d\d\d+',title,dEyT9xhGjolYzLCH7460w3.DOTALL)
			if pMAWqrwP80lR:
				pMAWqrwP80lR = pMAWqrwP80lR[0]
				if pMAWqrwP80lR in title: title = title.replace(pMAWqrwP80lR+'p',iiy37aKq0pCEIOwfcTh61xb4U).replace(pMAWqrwP80lR,iiy37aKq0pCEIOwfcTh61xb4U).strip(iFBmE2MUIpSu34wsd7Rf6z)
				pMAWqrwP80lR = '____'+pMAWqrwP80lR
			else: pMAWqrwP80lR = iiy37aKq0pCEIOwfcTh61xb4U
			if Zw4M5DUStdE6xp7GI.isdigit():
				fCXyTlcmF4WuetVork = WbXtgYqELOUSNZd15epAFchMHJCVso+'/?postid='+id+'&serverid='+Zw4M5DUStdE6xp7GI+'?named='+title+'__watch'+pMAWqrwP80lR
			else:
				if 'http' not in Zw4M5DUStdE6xp7GI: Zw4M5DUStdE6xp7GI = 'http:'+Zw4M5DUStdE6xp7GI
				pMAWqrwP80lR = dEyT9xhGjolYzLCH7460w3.findall('\d\d\d+',title,dEyT9xhGjolYzLCH7460w3.DOTALL)
				if pMAWqrwP80lR: pMAWqrwP80lR = '____'+pMAWqrwP80lR[0]
				else: pMAWqrwP80lR = iiy37aKq0pCEIOwfcTh61xb4U
				fCXyTlcmF4WuetVork = Zw4M5DUStdE6xp7GI+'?named=__watch'+pMAWqrwP80lR
			duef0gb3Mi1AV5WpN8.append(fCXyTlcmF4WuetVork)
	if 'DownloadNow' in Vxz6OndPIX4g2kaRp7:
		rzR9SN7ApZuQhTDWEX3V6ga = { 'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8' }
		eCGwzSrqBmIv = url+'/download'
		oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(Dxc7GChQwZ4kOlKHSbL06agnB,'GET',eCGwzSrqBmIv,iiy37aKq0pCEIOwfcTh61xb4U,rzR9SN7ApZuQhTDWEX3V6ga,True,iiy37aKq0pCEIOwfcTh61xb4U,'ARBLIONZ-PLAY-3rd')
		z0spMAOfJElv6L1K9ae = oCJ8TdG2LwSIVcbaUnhB.content.encode(df6QpwGxuJVZr)
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('<ul class="download-items(.*?)</ul>',z0spMAOfJElv6L1K9ae,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for PPH1sQtTkDBbnlYpZfo5 in UUIohmv597bO83YCLgWS:
			items = dEyT9xhGjolYzLCH7460w3.findall('href="(http.*?)".*?<span>(.*?)<.*?<p>(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
			for fCXyTlcmF4WuetVork,name,pMAWqrwP80lR in items:
				fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork+'?named='+name+'__download'+'____'+pMAWqrwP80lR
				duef0gb3Mi1AV5WpN8.append(fCXyTlcmF4WuetVork)
	elif '/download/' in Vxz6OndPIX4g2kaRp7:
		rzR9SN7ApZuQhTDWEX3V6ga = { 'User-Agent':iiy37aKq0pCEIOwfcTh61xb4U , 'X-Requested-With':'XMLHttpRequest' }
		eCGwzSrqBmIv = WbXtgYqELOUSNZd15epAFchMHJCVso + '/ajaxCenter?_action=getdownloadlinks&postId='+id
		oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(Dxc7GChQwZ4kOlKHSbL06agnB,'GET',eCGwzSrqBmIv,iiy37aKq0pCEIOwfcTh61xb4U,rzR9SN7ApZuQhTDWEX3V6ga,True,True,'ARBLIONZ-PLAY-4th')
		z0spMAOfJElv6L1K9ae = oCJ8TdG2LwSIVcbaUnhB.content.encode(df6QpwGxuJVZr)
		if 'download-btns' in z0spMAOfJElv6L1K9ae:
			bq17234fkwjKzc5U69QZ = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)"',z0spMAOfJElv6L1K9ae,dEyT9xhGjolYzLCH7460w3.DOTALL)
			for O5Pwg3UFyX0k9E in bq17234fkwjKzc5U69QZ:
				if '/page/' not in O5Pwg3UFyX0k9E and 'http' in O5Pwg3UFyX0k9E:
					O5Pwg3UFyX0k9E = O5Pwg3UFyX0k9E+'?named=__download'
					duef0gb3Mi1AV5WpN8.append(O5Pwg3UFyX0k9E)
				elif '/page/' in O5Pwg3UFyX0k9E:
					pMAWqrwP80lR = iiy37aKq0pCEIOwfcTh61xb4U
					oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(Dxc7GChQwZ4kOlKHSbL06agnB,'GET',O5Pwg3UFyX0k9E,iiy37aKq0pCEIOwfcTh61xb4U,headers,True,True,'ARBLIONZ-PLAY-5th')
					Yd98FrzLeoGQ2yTHEwKsPJp4mq = oCJ8TdG2LwSIVcbaUnhB.content.encode(df6QpwGxuJVZr)
					ddfSDGyqEc = dEyT9xhGjolYzLCH7460w3.findall('(<strong>.*?)-----',Yd98FrzLeoGQ2yTHEwKsPJp4mq,dEyT9xhGjolYzLCH7460w3.DOTALL)
					for uiLfpEmokbNWMj1BS0X8l in ddfSDGyqEc:
						u2Q1XmGjHqS7w4n5RrTUo = iiy37aKq0pCEIOwfcTh61xb4U
						kD1Vylqvauw07EG9RnAbx4drY8 = dEyT9xhGjolYzLCH7460w3.findall('<strong>(.*?)</strong>',uiLfpEmokbNWMj1BS0X8l,dEyT9xhGjolYzLCH7460w3.DOTALL)
						for cv7SbQ0osM3 in kD1Vylqvauw07EG9RnAbx4drY8:
							YXD9KNfjCaLwkcrvJxldn7I = dEyT9xhGjolYzLCH7460w3.findall('\d\d\d+',cv7SbQ0osM3,dEyT9xhGjolYzLCH7460w3.DOTALL)
							if YXD9KNfjCaLwkcrvJxldn7I:
								pMAWqrwP80lR = '____'+YXD9KNfjCaLwkcrvJxldn7I[0]
								break
						for cv7SbQ0osM3 in reversed(kD1Vylqvauw07EG9RnAbx4drY8):
							YXD9KNfjCaLwkcrvJxldn7I = dEyT9xhGjolYzLCH7460w3.findall('\w\w+',cv7SbQ0osM3,dEyT9xhGjolYzLCH7460w3.DOTALL)
							if YXD9KNfjCaLwkcrvJxldn7I:
								u2Q1XmGjHqS7w4n5RrTUo = YXD9KNfjCaLwkcrvJxldn7I[0]
								break
						poZItberOCBND072KXSHif = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)"',uiLfpEmokbNWMj1BS0X8l,dEyT9xhGjolYzLCH7460w3.DOTALL)
						for NV2kZSnlr4GUu50Ovhd3Xq in poZItberOCBND072KXSHif:
							NV2kZSnlr4GUu50Ovhd3Xq = NV2kZSnlr4GUu50Ovhd3Xq+'?named='+u2Q1XmGjHqS7w4n5RrTUo+'__download'+pMAWqrwP80lR
							duef0gb3Mi1AV5WpN8.append(NV2kZSnlr4GUu50Ovhd3Xq)
		elif 'slow-motion' in z0spMAOfJElv6L1K9ae:
			z0spMAOfJElv6L1K9ae = z0spMAOfJElv6L1K9ae.replace('<h6 ','==END== ==START==')+'==END=='
			z0spMAOfJElv6L1K9ae = z0spMAOfJElv6L1K9ae.replace('<h3 ','==END== ==START==')+'==END=='
			pYbZzJjUDBeEy = dEyT9xhGjolYzLCH7460w3.findall('==START==(.*?)==END==',z0spMAOfJElv6L1K9ae,dEyT9xhGjolYzLCH7460w3.DOTALL)
			if pYbZzJjUDBeEy:
				for uiLfpEmokbNWMj1BS0X8l in pYbZzJjUDBeEy:
					if 'href=' not in uiLfpEmokbNWMj1BS0X8l: continue
					Xc1k6xgo2yqZm = iiy37aKq0pCEIOwfcTh61xb4U
					kD1Vylqvauw07EG9RnAbx4drY8 = dEyT9xhGjolYzLCH7460w3.findall('slow-motion">(.*?)<',uiLfpEmokbNWMj1BS0X8l,dEyT9xhGjolYzLCH7460w3.DOTALL)
					for cv7SbQ0osM3 in kD1Vylqvauw07EG9RnAbx4drY8:
						YXD9KNfjCaLwkcrvJxldn7I = dEyT9xhGjolYzLCH7460w3.findall('\d\d\d+',cv7SbQ0osM3,dEyT9xhGjolYzLCH7460w3.DOTALL)
						if YXD9KNfjCaLwkcrvJxldn7I:
							Xc1k6xgo2yqZm = '____'+YXD9KNfjCaLwkcrvJxldn7I[0]
							break
					kD1Vylqvauw07EG9RnAbx4drY8 = dEyT9xhGjolYzLCH7460w3.findall('<td>(.*?)</td>.*?href="(http.*?)"',uiLfpEmokbNWMj1BS0X8l,dEyT9xhGjolYzLCH7460w3.DOTALL)
					if kD1Vylqvauw07EG9RnAbx4drY8:
						for u2Q1XmGjHqS7w4n5RrTUo,CCglWLRTsNIF23r5OAwcHxfBubiEd in kD1Vylqvauw07EG9RnAbx4drY8:
							CCglWLRTsNIF23r5OAwcHxfBubiEd = CCglWLRTsNIF23r5OAwcHxfBubiEd+'?named='+u2Q1XmGjHqS7w4n5RrTUo+'__download'+Xc1k6xgo2yqZm
							duef0gb3Mi1AV5WpN8.append(CCglWLRTsNIF23r5OAwcHxfBubiEd)
					else:
						kD1Vylqvauw07EG9RnAbx4drY8 = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?http.*?)".*?name">(.*?)<',uiLfpEmokbNWMj1BS0X8l,dEyT9xhGjolYzLCH7460w3.DOTALL)
						for CCglWLRTsNIF23r5OAwcHxfBubiEd,u2Q1XmGjHqS7w4n5RrTUo in kD1Vylqvauw07EG9RnAbx4drY8:
							CCglWLRTsNIF23r5OAwcHxfBubiEd = CCglWLRTsNIF23r5OAwcHxfBubiEd.strip(iFBmE2MUIpSu34wsd7Rf6z)+'?named='+u2Q1XmGjHqS7w4n5RrTUo+'__download'+Xc1k6xgo2yqZm
							duef0gb3Mi1AV5WpN8.append(CCglWLRTsNIF23r5OAwcHxfBubiEd)
			else:
				kD1Vylqvauw07EG9RnAbx4drY8 = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)".*?>(\w+)<',z0spMAOfJElv6L1K9ae,dEyT9xhGjolYzLCH7460w3.DOTALL)
				for CCglWLRTsNIF23r5OAwcHxfBubiEd,u2Q1XmGjHqS7w4n5RrTUo in kD1Vylqvauw07EG9RnAbx4drY8:
					CCglWLRTsNIF23r5OAwcHxfBubiEd = CCglWLRTsNIF23r5OAwcHxfBubiEd.strip(iFBmE2MUIpSu34wsd7Rf6z)+'?named='+u2Q1XmGjHqS7w4n5RrTUo+'__download'
					duef0gb3Mi1AV5WpN8.append(CCglWLRTsNIF23r5OAwcHxfBubiEd)
	import lqBJGK8hXO
	lqBJGK8hXO.ZDg1HavwueT85mcAOorC4hnS(duef0gb3Mi1AV5WpN8,sQU2GnRoMwLK8CBdfzmNr4jXyO,'video',url)
	return
def mUhJtHB9nw(search):
	search,brFQp5vmgJWdZfEkCBOlu9c,showDialogs = XkYnev3ZCA6ahO94(search)
	if search==iiy37aKq0pCEIOwfcTh61xb4U: search = TTBf6S08q1NKXd5v9wa()
	if search==iiy37aKq0pCEIOwfcTh61xb4U: return
	search = search.replace(iFBmE2MUIpSu34wsd7Rf6z,'+')
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(Dxc7GChQwZ4kOlKHSbL06agnB,'GET',JaQEtCzDXgos1cdZN+'/alz',iiy37aKq0pCEIOwfcTh61xb4U,headers,True,iiy37aKq0pCEIOwfcTh61xb4U,'ARBLIONZ-SEARCH-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content.encode(df6QpwGxuJVZr)
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('chevron-select(.*?)</div>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if showDialogs and UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('value="(.*?)".*?>(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		qjSbmiVELDwOgxNXtI57JQn4o,j3b52FqCSkuRHGMcYe9s1BA = [],[]
		for RRIscyLmNH9dq2Dio3TSr,title in items:
			qjSbmiVELDwOgxNXtI57JQn4o.append(RRIscyLmNH9dq2Dio3TSr)
			j3b52FqCSkuRHGMcYe9s1BA.append(title)
		mmfrx2S5XqknFTDeRhj49LuYv1wW0 = ccv1mVPUsnr('اختر الفلتر المناسب:', j3b52FqCSkuRHGMcYe9s1BA)
		if mmfrx2S5XqknFTDeRhj49LuYv1wW0 == -1 : return
		RRIscyLmNH9dq2Dio3TSr = qjSbmiVELDwOgxNXtI57JQn4o[mmfrx2S5XqknFTDeRhj49LuYv1wW0]
	else: RRIscyLmNH9dq2Dio3TSr = iiy37aKq0pCEIOwfcTh61xb4U
	url = JaQEtCzDXgos1cdZN + '/search?s='+search+'&category='+RRIscyLmNH9dq2Dio3TSr+'&page=1'
	AIQeNZP4FMDw9S(url)
	return
def chQHNdWgTSDjti8R9pJUf(url,filter):
	JYMlXTc9DCZrohd = ['category','release-year','genre','Quality']
	if '?' in url: url = url.split('/getposts?')[0]
	type,filter = filter.split('___',1)
	if filter==iiy37aKq0pCEIOwfcTh61xb4U: Mhd9LWrfiF1EsASl6eP34uTp0qNGom,ovh6cXGg1qd85fn3CSJEisTlI7Yz = iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U
	else: Mhd9LWrfiF1EsASl6eP34uTp0qNGom,ovh6cXGg1qd85fn3CSJEisTlI7Yz = filter.split('___')
	if type=='CATEGORIES':
		if JYMlXTc9DCZrohd[0]+'=' not in Mhd9LWrfiF1EsASl6eP34uTp0qNGom: RRIscyLmNH9dq2Dio3TSr = JYMlXTc9DCZrohd[0]
		for iEfNKT3velFyGth80SA4pxbCRrVD in range(len(JYMlXTc9DCZrohd[0:-1])):
			if JYMlXTc9DCZrohd[iEfNKT3velFyGth80SA4pxbCRrVD]+'=' in Mhd9LWrfiF1EsASl6eP34uTp0qNGom: RRIscyLmNH9dq2Dio3TSr = JYMlXTc9DCZrohd[iEfNKT3velFyGth80SA4pxbCRrVD+1]
		HdFJThcNtWe3lb8n4OmaSwQ = Mhd9LWrfiF1EsASl6eP34uTp0qNGom+'&'+RRIscyLmNH9dq2Dio3TSr+'=0'
		vvlVH6JT9YDNPeSaRUkKCAwpr5uq = ovh6cXGg1qd85fn3CSJEisTlI7Yz+'&'+RRIscyLmNH9dq2Dio3TSr+'=0'
		cCZR4YdwUepABD9mQsubT8FgN = HdFJThcNtWe3lb8n4OmaSwQ.strip('&')+'___'+vvlVH6JT9YDNPeSaRUkKCAwpr5uq.strip('&')
		bPXk8KHyCUrifag = qJ8NQtuWARGjoZd9swfbH(ovh6cXGg1qd85fn3CSJEisTlI7Yz,'modified_filters')
		eCGwzSrqBmIv = url+'/getposts?'+bPXk8KHyCUrifag
	elif type=='FILTERS':
		GMQ6AxE012X9 = qJ8NQtuWARGjoZd9swfbH(Mhd9LWrfiF1EsASl6eP34uTp0qNGom,'modified_values')
		GMQ6AxE012X9 = a9I3YZjc6ySDPE4Kp(GMQ6AxE012X9)
		if ovh6cXGg1qd85fn3CSJEisTlI7Yz!=iiy37aKq0pCEIOwfcTh61xb4U: ovh6cXGg1qd85fn3CSJEisTlI7Yz = qJ8NQtuWARGjoZd9swfbH(ovh6cXGg1qd85fn3CSJEisTlI7Yz,'modified_filters')
		if ovh6cXGg1qd85fn3CSJEisTlI7Yz==iiy37aKq0pCEIOwfcTh61xb4U: eCGwzSrqBmIv = url
		else: eCGwzSrqBmIv = url+'/getposts?'+ovh6cXGg1qd85fn3CSJEisTlI7Yz
		bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'أظهار قائمة الفيديو التي تم اختيارها ',eCGwzSrqBmIv,201)
		bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+' [[   '+GMQ6AxE012X9+'   ]]',eCGwzSrqBmIv,201)
		bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(Dxc7GChQwZ4kOlKHSbL06agnB,url+'/alz',iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,'ARBLIONZ-FILTERS_MENU-1st')
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('AjaxFilteringData(.*?)FilterWord',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
	n8nFIQBNaXD = dEyT9xhGjolYzLCH7460w3.findall('</i>(.*?)<.*?data-forTax="(.*?)"(.*?)<h2',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	dict = {}
	for name,cWhMpFIbQU4D1Bi,PPH1sQtTkDBbnlYpZfo5 in n8nFIQBNaXD:
		name = name.replace('اختيار ',iiy37aKq0pCEIOwfcTh61xb4U)
		name = name.replace('سنة الإنتاج','السنة')
		items = dEyT9xhGjolYzLCH7460w3.findall('value="(.*?)".*?</div>(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if '=' not in eCGwzSrqBmIv: eCGwzSrqBmIv = url
		if type=='CATEGORIES':
			if RRIscyLmNH9dq2Dio3TSr!=cWhMpFIbQU4D1Bi: continue
			elif len(items)<=1:
				if cWhMpFIbQU4D1Bi==JYMlXTc9DCZrohd[-1]: AIQeNZP4FMDw9S(eCGwzSrqBmIv)
				else: chQHNdWgTSDjti8R9pJUf(eCGwzSrqBmIv,'CATEGORIES___'+cCZR4YdwUepABD9mQsubT8FgN)
				return
			else:
				if cWhMpFIbQU4D1Bi==JYMlXTc9DCZrohd[-1]: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'الجميع ',eCGwzSrqBmIv,201)
				else: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'الجميع ',eCGwzSrqBmIv,205,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,cCZR4YdwUepABD9mQsubT8FgN)
		elif type=='FILTERS':
			HdFJThcNtWe3lb8n4OmaSwQ = Mhd9LWrfiF1EsASl6eP34uTp0qNGom+'&'+cWhMpFIbQU4D1Bi+'=0'
			vvlVH6JT9YDNPeSaRUkKCAwpr5uq = ovh6cXGg1qd85fn3CSJEisTlI7Yz+'&'+cWhMpFIbQU4D1Bi+'=0'
			cCZR4YdwUepABD9mQsubT8FgN = HdFJThcNtWe3lb8n4OmaSwQ+'___'+vvlVH6JT9YDNPeSaRUkKCAwpr5uq
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'الجميع :'+name,eCGwzSrqBmIv,204,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,cCZR4YdwUepABD9mQsubT8FgN)
		dict[cWhMpFIbQU4D1Bi] = {}
		for aasX2cby4Vo5rTgB,KjsA38t0DCSmuLcaE in items:
			KjsA38t0DCSmuLcaE = KjsA38t0DCSmuLcaE.replace(OTlVEGYPSxsNaBdXUucqA3,iiy37aKq0pCEIOwfcTh61xb4U)
			if KjsA38t0DCSmuLcaE in a8GCLIuWNkS: continue
			dict[cWhMpFIbQU4D1Bi][aasX2cby4Vo5rTgB] = KjsA38t0DCSmuLcaE
			HdFJThcNtWe3lb8n4OmaSwQ = Mhd9LWrfiF1EsASl6eP34uTp0qNGom+'&'+cWhMpFIbQU4D1Bi+'='+KjsA38t0DCSmuLcaE
			vvlVH6JT9YDNPeSaRUkKCAwpr5uq = ovh6cXGg1qd85fn3CSJEisTlI7Yz+'&'+cWhMpFIbQU4D1Bi+'='+aasX2cby4Vo5rTgB
			kuyfTIwjRrhXUo = HdFJThcNtWe3lb8n4OmaSwQ+'___'+vvlVH6JT9YDNPeSaRUkKCAwpr5uq
			title = KjsA38t0DCSmuLcaE+' :'#+dict[cWhMpFIbQU4D1Bi]['0']
			title = KjsA38t0DCSmuLcaE+' :'+name
			if type=='FILTERS': bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,url,204,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,kuyfTIwjRrhXUo)
			elif type=='CATEGORIES' and JYMlXTc9DCZrohd[-2]+'=' in Mhd9LWrfiF1EsASl6eP34uTp0qNGom:
				bPXk8KHyCUrifag = qJ8NQtuWARGjoZd9swfbH(vvlVH6JT9YDNPeSaRUkKCAwpr5uq,'modified_filters')
				O5Pwg3UFyX0k9E = url+'/getposts?'+bPXk8KHyCUrifag
				bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,O5Pwg3UFyX0k9E,201)
			else: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,url,205,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,kuyfTIwjRrhXUo)
	return
def qJ8NQtuWARGjoZd9swfbH(HSAqBpsb2jRLvk9lx147rzY,mode):
	HSAqBpsb2jRLvk9lx147rzY = HSAqBpsb2jRLvk9lx147rzY.replace('=&','=0&')
	HSAqBpsb2jRLvk9lx147rzY = HSAqBpsb2jRLvk9lx147rzY.strip('&')
	x8UiIH3WCTEpe = {}
	if '=' in HSAqBpsb2jRLvk9lx147rzY:
		items = HSAqBpsb2jRLvk9lx147rzY.split('&')
		for YXD9KNfjCaLwkcrvJxldn7I in items:
			xYkDXe5UjvETygJNLrRQ96mtp8BKGW,aasX2cby4Vo5rTgB = YXD9KNfjCaLwkcrvJxldn7I.split('=')
			x8UiIH3WCTEpe[xYkDXe5UjvETygJNLrRQ96mtp8BKGW] = aasX2cby4Vo5rTgB
	QAvGYocVXgzh9 = iiy37aKq0pCEIOwfcTh61xb4U
	a3aiAqYngfydR1XNJK975wl4jD = ['category','release-year','genre','Quality']
	for key in a3aiAqYngfydR1XNJK975wl4jD:
		if key in list(x8UiIH3WCTEpe.keys()): aasX2cby4Vo5rTgB = x8UiIH3WCTEpe[key]
		else: aasX2cby4Vo5rTgB = '0'
		if '%' not in aasX2cby4Vo5rTgB: aasX2cby4Vo5rTgB = YqdaDIig21wBTWJeUHbc(aasX2cby4Vo5rTgB)
		if mode=='modified_values' and aasX2cby4Vo5rTgB!='0': QAvGYocVXgzh9 = QAvGYocVXgzh9+' + '+aasX2cby4Vo5rTgB
		elif mode=='modified_filters' and aasX2cby4Vo5rTgB!='0': QAvGYocVXgzh9 = QAvGYocVXgzh9+'&'+key+'='+aasX2cby4Vo5rTgB
		elif mode=='all': QAvGYocVXgzh9 = QAvGYocVXgzh9+'&'+key+'='+aasX2cby4Vo5rTgB
	QAvGYocVXgzh9 = QAvGYocVXgzh9.strip(' + ')
	QAvGYocVXgzh9 = QAvGYocVXgzh9.strip('&')
	QAvGYocVXgzh9 = QAvGYocVXgzh9.replace('=0','=')
	QAvGYocVXgzh9 = QAvGYocVXgzh9.replace('Quality','quality')
	return QAvGYocVXgzh9
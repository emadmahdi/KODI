# -*- coding: utf-8 -*-
from braVAkwfBN import *
import bs4 as WWF5a03Bix
sQU2GnRoMwLK8CBdfzmNr4jXyO = 'ELCINEMA'
ooQEi5O6tYsGVF8LU0TC3hgMeflBwH = '_ELC_'
JaQEtCzDXgos1cdZN = gZ4LwbKaOm[sQU2GnRoMwLK8CBdfzmNr4jXyO][0]
headers = {'Referer':JaQEtCzDXgos1cdZN}
a8GCLIuWNkS = []
def sHVM8YchrDjZAJ7(mode,url,text):
	if   mode==510: EA7FzO1kMZGQXDd2giB0cwLom = jihuS9LVAvTrClPapMbUEwfn8XN()
	elif mode==511: EA7FzO1kMZGQXDd2giB0cwLom = PP9Ykb4S8tawCoFUqsx5ZErW(url)
	elif mode==512: EA7FzO1kMZGQXDd2giB0cwLom = lsJa5qRHhMm(url)
	elif mode==513: EA7FzO1kMZGQXDd2giB0cwLom = YaBRnDbiflFygpMZAKSEd69GU8rc(url)
	elif mode==514: EA7FzO1kMZGQXDd2giB0cwLom = uxp3cAOydm(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==515: EA7FzO1kMZGQXDd2giB0cwLom = uxp3cAOydm(url,'SPECIFIED_FILTER___'+text)
	elif mode==516: EA7FzO1kMZGQXDd2giB0cwLom = YCjpOT5W0NLrb(text)
	elif mode==517: EA7FzO1kMZGQXDd2giB0cwLom = deDEXniSx8qkV3KwITU1j2(url)
	elif mode==518: EA7FzO1kMZGQXDd2giB0cwLom = CKkqRTePDY0QNcpyJbZoHX14Wr(url)
	elif mode==519: EA7FzO1kMZGQXDd2giB0cwLom = mUhJtHB9nw(text)
	elif mode==520: EA7FzO1kMZGQXDd2giB0cwLom = zDZyTCFV0dYI7tovHSGL63(url)
	elif mode==521: EA7FzO1kMZGQXDd2giB0cwLom = bkMl8QWoFGpJ6K2acPZs0IdvB(url)
	elif mode==522: EA7FzO1kMZGQXDd2giB0cwLom = TW6Z0zqaDl(url)
	elif mode==523: EA7FzO1kMZGQXDd2giB0cwLom = dAwIKnu97TYWFEX(text)
	elif mode==524: EA7FzO1kMZGQXDd2giB0cwLom = jkSTPUasFpyYDNmiqAudOGrMx()
	elif mode==525: EA7FzO1kMZGQXDd2giB0cwLom = ERYtyqu6zHDLhTV0PMjJ()
	elif mode==526: EA7FzO1kMZGQXDd2giB0cwLom = hloEZXzDy4SbUTGKkYr7PnM9()
	elif mode==527: EA7FzO1kMZGQXDd2giB0cwLom = Hkg6iQ9rlnmcy8DESNjzPZI0qeO()
	else: EA7FzO1kMZGQXDd2giB0cwLom = False
	return EA7FzO1kMZGQXDd2giB0cwLom
def jihuS9LVAvTrClPapMbUEwfn8XN():
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'بحث بموسوعة السينما',iiy37aKq0pCEIOwfcTh61xb4U,519)
	bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'موسوعة الأعمال',iiy37aKq0pCEIOwfcTh61xb4U,525)
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'موسوعة الأشخاص',iiy37aKq0pCEIOwfcTh61xb4U,526)
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'موسوعة المصنفات',iiy37aKq0pCEIOwfcTh61xb4U,527)
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'موسوعة المنوعات',iiy37aKq0pCEIOwfcTh61xb4U,524)
	return
def jkSTPUasFpyYDNmiqAudOGrMx():
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+' فيديوهات - خاصة',JaQEtCzDXgos1cdZN+'/video',520)
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'فيديوهات - أحدث',JaQEtCzDXgos1cdZN+'/video/latest',521)
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'فيديوهات - أقدم',JaQEtCzDXgos1cdZN+'/video/oldest',521)
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'فيديوهات - أكثر مشاهدة',JaQEtCzDXgos1cdZN+'/video/views',521)
	return
def ERYtyqu6zHDLhTV0PMjJ():
	MJhpYKrX2QVDoU7 = JaQEtCzDXgos1cdZN+'/lineup?utf8=%E2%9C%93'
	KuY4C0ZliOHbcAI7EPJS = MJhpYKrX2QVDoU7+'&type=2&category=1&foreign=false&tag='
	B7LngRsWzJhUp8raf = MJhpYKrX2QVDoU7+'&type=2&category=3&foreign=false&tag='
	qqn9ydpMJCWL = MJhpYKrX2QVDoU7+'&type=2&category=1&foreign=true&tag='
	svKPHwcyaGu9 = MJhpYKrX2QVDoU7+'&type=2&category=3&foreign=true&tag='
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'مصنفات أفلام عربي',KuY4C0ZliOHbcAI7EPJS,511)
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'مصنفات مسلسلات عربي',B7LngRsWzJhUp8raf,511)
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'مصنفات أفلام اجنبي',qqn9ydpMJCWL,511)
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'مصنفات مسلسلات اجنبي',svKPHwcyaGu9,511)
	bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'فهرس أعمال أبجدي',JaQEtCzDXgos1cdZN+'/index/work/alphabet',517)
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'فهرس  بلد الإنتاج',JaQEtCzDXgos1cdZN+'/index/work/country',517)
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'فهرس اللغة',JaQEtCzDXgos1cdZN+'/index/work/language',517)
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'فهرس مصنفات العمل',JaQEtCzDXgos1cdZN+'/index/work/genre',517)
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'فهرس سنة الإصدار',JaQEtCzDXgos1cdZN+'/index/work/release_year',517)
	bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'مواسم - فلتر محدد',JaQEtCzDXgos1cdZN+'/seasonals',515)
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'مواسم - فلتر كامل',JaQEtCzDXgos1cdZN+'/seasonals',514)
	bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'مصنفات - فلتر محدد',JaQEtCzDXgos1cdZN+'/lineup',515)
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'مصنفات - فلتر كامل',JaQEtCzDXgos1cdZN+'/lineup',514)
	return
def Hkg6iQ9rlnmcy8DESNjzPZI0qeO():
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(Dxc7GChQwZ4kOlKHSbL06agnB,'GET',JaQEtCzDXgos1cdZN+'/lineup',iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'ELCINEMA-MENU-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	DynmguA8OZ5Iq7t4QdNUcPG9 = WWF5a03Bix.BeautifulSoup(Vxz6OndPIX4g2kaRp7,'html.parser',multi_valued_attributes=None)
	PPH1sQtTkDBbnlYpZfo5 = DynmguA8OZ5Iq7t4QdNUcPG9.find('select',attrs={'name':'tag'})
	brFQp5vmgJWdZfEkCBOlu9c = PPH1sQtTkDBbnlYpZfo5.find_all('option')
	for KjsA38t0DCSmuLcaE in brFQp5vmgJWdZfEkCBOlu9c:
		aasX2cby4Vo5rTgB = KjsA38t0DCSmuLcaE.get('value')
		if not aasX2cby4Vo5rTgB: continue
		title = KjsA38t0DCSmuLcaE.text
		if iELueYz3J1FmxaW7vc:
			title = title.encode(df6QpwGxuJVZr)
			aasX2cby4Vo5rTgB = aasX2cby4Vo5rTgB.encode(df6QpwGxuJVZr)
		fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN+'/lineup?utf8=%E2%9C%93&type=&category=&foreign=&tag='+aasX2cby4Vo5rTgB
		title = title.replace('قائمة ',iiy37aKq0pCEIOwfcTh61xb4U)
		bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,511)
	return
def hloEZXzDy4SbUTGKkYr7PnM9():
	MJhpYKrX2QVDoU7 = JaQEtCzDXgos1cdZN+'/lineup?utf8=%E2%9C%93'
	BFWTwxolSOAP9Uj = MJhpYKrX2QVDoU7+'&type=1&category=&foreign=&tag='
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'مصنفات أشخاص',BFWTwxolSOAP9Uj,511)
	bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'فهرس أشخاص أبجدي',JaQEtCzDXgos1cdZN+'/index/person/alphabet',517)
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'فهرس موطن',JaQEtCzDXgos1cdZN+'/index/person/nationality',517)
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'فهرس  تاريخ الميلاد',JaQEtCzDXgos1cdZN+'/index/person/birth_year',517)
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'فهرس  تاريخ الوفاة',JaQEtCzDXgos1cdZN+'/index/person/death_year',517)
	bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'مصنفات - فلتر محدد',JaQEtCzDXgos1cdZN+'/lineup',515)
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'مصنفات - فلتر كامل',JaQEtCzDXgos1cdZN+'/lineup',514)
	return
def PP9Ykb4S8tawCoFUqsx5ZErW(url):
	if '/seasonals' in url: bsqXJ3iaf2dop5 = 0
	elif '/lineup' in url: bsqXJ3iaf2dop5 = 1
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(Dxc7GChQwZ4kOlKHSbL06agnB,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'ELCINEMA-LISTS-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	DynmguA8OZ5Iq7t4QdNUcPG9 = WWF5a03Bix.BeautifulSoup(Vxz6OndPIX4g2kaRp7,'html.parser',multi_valued_attributes=None)
	ddfSDGyqEc = DynmguA8OZ5Iq7t4QdNUcPG9.find_all(class_='jumbo-theater clearfix')
	for PPH1sQtTkDBbnlYpZfo5 in ddfSDGyqEc:
		title = PPH1sQtTkDBbnlYpZfo5.find_all('a')[bsqXJ3iaf2dop5].text
		fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN+PPH1sQtTkDBbnlYpZfo5.find_all('a')[bsqXJ3iaf2dop5].get('href')
		if iELueYz3J1FmxaW7vc:
			title = title.encode(df6QpwGxuJVZr)
			fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork.encode(df6QpwGxuJVZr)
		if not ddfSDGyqEc:
			lsJa5qRHhMm(fCXyTlcmF4WuetVork)
			return
		else:
			title = title.replace('قائمة ',iiy37aKq0pCEIOwfcTh61xb4U)
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,512)
	vsOn7KRH1Vz6PLjWhdtIXw25YFNqu(DynmguA8OZ5Iq7t4QdNUcPG9,511)
	return
def vsOn7KRH1Vz6PLjWhdtIXw25YFNqu(DynmguA8OZ5Iq7t4QdNUcPG9,mode):
	PPH1sQtTkDBbnlYpZfo5 = DynmguA8OZ5Iq7t4QdNUcPG9.find(class_='pagination')
	if PPH1sQtTkDBbnlYpZfo5:
		JD0cNSKG5YLTEhzfls = PPH1sQtTkDBbnlYpZfo5.find_all('a')
		vl4Ea3syRpCm = PPH1sQtTkDBbnlYpZfo5.find_all('li')
		Zjr8akbwo5pSMDOu10Py2i3 = list(zip(JD0cNSKG5YLTEhzfls,vl4Ea3syRpCm))
		o6oXFxmE1bQC = -1
		o2oZMyNALwBYQCXj4z38sTDg = len(Zjr8akbwo5pSMDOu10Py2i3)
		for IIMp8kDh0zEeZJfyrtHBbRvjS,RBzo90L3gjMXfAZIVlChs1cKndywJ in Zjr8akbwo5pSMDOu10Py2i3:
			o6oXFxmE1bQC += 1
			RBzo90L3gjMXfAZIVlChs1cKndywJ = RBzo90L3gjMXfAZIVlChs1cKndywJ['class']
			if 'unavailable' in RBzo90L3gjMXfAZIVlChs1cKndywJ or 'current' in RBzo90L3gjMXfAZIVlChs1cKndywJ: continue
			ccgt6lhpXynUR79P5ev = IIMp8kDh0zEeZJfyrtHBbRvjS.text
			hx0dU3Ki7AyEfkSZY6TmN2BwtX = JaQEtCzDXgos1cdZN+IIMp8kDh0zEeZJfyrtHBbRvjS.get('href')
			if iELueYz3J1FmxaW7vc:
				ccgt6lhpXynUR79P5ev = ccgt6lhpXynUR79P5ev.encode(df6QpwGxuJVZr)
				hx0dU3Ki7AyEfkSZY6TmN2BwtX = hx0dU3Ki7AyEfkSZY6TmN2BwtX.encode(df6QpwGxuJVZr)
			if   o6oXFxmE1bQC==0: ccgt6lhpXynUR79P5ev = 'أولى'
			elif o6oXFxmE1bQC==1: ccgt6lhpXynUR79P5ev = 'سابقة'
			elif o6oXFxmE1bQC==o2oZMyNALwBYQCXj4z38sTDg-2: ccgt6lhpXynUR79P5ev = 'لاحقة'
			elif o6oXFxmE1bQC==o2oZMyNALwBYQCXj4z38sTDg-1: ccgt6lhpXynUR79P5ev = 'أخيرة'
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'صفحة '+ccgt6lhpXynUR79P5ev,hx0dU3Ki7AyEfkSZY6TmN2BwtX,mode)
	return
def lsJa5qRHhMm(url):
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(Dxc7GChQwZ4kOlKHSbL06agnB,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'ELCINEMA-TITLES1-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	DynmguA8OZ5Iq7t4QdNUcPG9 = WWF5a03Bix.BeautifulSoup(Vxz6OndPIX4g2kaRp7,'html.parser',multi_valued_attributes=None)
	ddfSDGyqEc = DynmguA8OZ5Iq7t4QdNUcPG9.find_all(class_='row')
	items,wijqr6NndVsJmg = [],True
	for PPH1sQtTkDBbnlYpZfo5 in ddfSDGyqEc:
		if not PPH1sQtTkDBbnlYpZfo5.find(class_='thumbnail-wrapper'): continue
		if wijqr6NndVsJmg: wijqr6NndVsJmg = False ; continue
		ZZQjAFwf7shpESz4KGTt02kUL = []
		WWGKfHF9YeahR3TEcXzvxo4 = PPH1sQtTkDBbnlYpZfo5.find_all(class_=['censorship red','censorship purple'])
		for NSvLHdwUxG in WWGKfHF9YeahR3TEcXzvxo4:
			ZfxFOL740wnKEgyiItPACU9rdvQ = NSvLHdwUxG.find_all('li')[1].text
			if iELueYz3J1FmxaW7vc:
				ZfxFOL740wnKEgyiItPACU9rdvQ = ZfxFOL740wnKEgyiItPACU9rdvQ.encode(df6QpwGxuJVZr)
			ZZQjAFwf7shpESz4KGTt02kUL.append(ZfxFOL740wnKEgyiItPACU9rdvQ)
		if not IUF8hYKEGLmHDtXbuWNvnJ(sQU2GnRoMwLK8CBdfzmNr4jXyO,iiy37aKq0pCEIOwfcTh61xb4U,ZZQjAFwf7shpESz4KGTt02kUL,False):
			L95mrowGgdsD = PPH1sQtTkDBbnlYpZfo5.find('img').get('data-src')
			title = PPH1sQtTkDBbnlYpZfo5.find('h3')
			name = title.find('a').text
			fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN+title.find('a').get('href')
			m2yjoOTWPI4Anx63M81 = PPH1sQtTkDBbnlYpZfo5.find(class_='no-margin')
			lUQ0XZxkcfLHpbVmEtJ3DR = PPH1sQtTkDBbnlYpZfo5.find(class_='legend')
			if m2yjoOTWPI4Anx63M81: m2yjoOTWPI4Anx63M81 = m2yjoOTWPI4Anx63M81.text
			if lUQ0XZxkcfLHpbVmEtJ3DR: lUQ0XZxkcfLHpbVmEtJ3DR = lUQ0XZxkcfLHpbVmEtJ3DR.text
			if iELueYz3J1FmxaW7vc:
				L95mrowGgdsD = L95mrowGgdsD.encode(df6QpwGxuJVZr)
				name = name.encode(df6QpwGxuJVZr)
				fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork.encode(df6QpwGxuJVZr)
				if m2yjoOTWPI4Anx63M81: m2yjoOTWPI4Anx63M81 = m2yjoOTWPI4Anx63M81.encode(df6QpwGxuJVZr)
			XC10geOnQtwrs = {}
			if lUQ0XZxkcfLHpbVmEtJ3DR: XC10geOnQtwrs['stars'] = lUQ0XZxkcfLHpbVmEtJ3DR
			if m2yjoOTWPI4Anx63M81:
				m2yjoOTWPI4Anx63M81 = m2yjoOTWPI4Anx63M81.replace(OTlVEGYPSxsNaBdXUucqA3,' .. ')
				XC10geOnQtwrs['plot'] = m2yjoOTWPI4Anx63M81.replace('...اقرأ المزيد',iiy37aKq0pCEIOwfcTh61xb4U)
			if '/work/' in fCXyTlcmF4WuetVork:
				bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+name,fCXyTlcmF4WuetVork,516,L95mrowGgdsD,iiy37aKq0pCEIOwfcTh61xb4U,name,iiy37aKq0pCEIOwfcTh61xb4U,XC10geOnQtwrs)
			elif '/person/' in fCXyTlcmF4WuetVork: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+name,fCXyTlcmF4WuetVork,513,L95mrowGgdsD,iiy37aKq0pCEIOwfcTh61xb4U,name,iiy37aKq0pCEIOwfcTh61xb4U,XC10geOnQtwrs)
	vsOn7KRH1Vz6PLjWhdtIXw25YFNqu(DynmguA8OZ5Iq7t4QdNUcPG9,512)
	return
def YaBRnDbiflFygpMZAKSEd69GU8rc(url):
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(Dxc7GChQwZ4kOlKHSbL06agnB,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'ELCINEMA-TITLES2-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	DynmguA8OZ5Iq7t4QdNUcPG9 = WWF5a03Bix.BeautifulSoup(Vxz6OndPIX4g2kaRp7,'html.parser',multi_valued_attributes=None)
	ddfSDGyqEc = DynmguA8OZ5Iq7t4QdNUcPG9.find_all('li')
	EaJdizIBhr3XnWGHsYxvO0S2oVyKwj,items = [],[]
	for PPH1sQtTkDBbnlYpZfo5 in ddfSDGyqEc:
		if not PPH1sQtTkDBbnlYpZfo5.find(class_='thumbnail-wrapper'): continue
		if not PPH1sQtTkDBbnlYpZfo5.find(class_=['unstyled','unstyled text-center']): continue
		if PPH1sQtTkDBbnlYpZfo5.find(class_='hide'): continue
		title = PPH1sQtTkDBbnlYpZfo5.find(class_=['unstyled','unstyled text-center'])
		name = title.find('a').text
		if name in EaJdizIBhr3XnWGHsYxvO0S2oVyKwj: continue
		EaJdizIBhr3XnWGHsYxvO0S2oVyKwj.append(name)
		fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN+title.find('a').get('href')
		if '/search/work/' in url: L95mrowGgdsD = PPH1sQtTkDBbnlYpZfo5.find('img').get('src')
		elif '/search/person/' in url: L95mrowGgdsD = PPH1sQtTkDBbnlYpZfo5.find('img').get('data-src')
		elif '/search/video/' in url: L95mrowGgdsD = PPH1sQtTkDBbnlYpZfo5.find('img').get('data-src')
		else: L95mrowGgdsD = PPH1sQtTkDBbnlYpZfo5.find('img').get('src')
		if iELueYz3J1FmxaW7vc:
			name = name.encode(df6QpwGxuJVZr)
			fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork.encode(df6QpwGxuJVZr)
			L95mrowGgdsD = L95mrowGgdsD.encode(df6QpwGxuJVZr)
		name = name.strip(iFBmE2MUIpSu34wsd7Rf6z)
		items.append((name,fCXyTlcmF4WuetVork,L95mrowGgdsD))
	if '/search/person/' in url: items = sorted(items,reverse=False,key=lambda key: key[0])
	for name,fCXyTlcmF4WuetVork,L95mrowGgdsD in items:
		if '/search/video/' in url: bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+name,fCXyTlcmF4WuetVork,522,L95mrowGgdsD)
		elif '/search/person/' in url: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+name,fCXyTlcmF4WuetVork,513,L95mrowGgdsD,iiy37aKq0pCEIOwfcTh61xb4U,name)
		else: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+name,fCXyTlcmF4WuetVork,516,L95mrowGgdsD,iiy37aKq0pCEIOwfcTh61xb4U,name)
	return
def YCjpOT5W0NLrb(text):
	text = text.replace('الإعلان',iiy37aKq0pCEIOwfcTh61xb4U).replace('لفيلم',iiy37aKq0pCEIOwfcTh61xb4U).replace('الرسمي',iiy37aKq0pCEIOwfcTh61xb4U)
	text = text.replace('إعلان',iiy37aKq0pCEIOwfcTh61xb4U).replace('فيلم',iiy37aKq0pCEIOwfcTh61xb4U).replace('البرومو',iiy37aKq0pCEIOwfcTh61xb4U)
	text = text.replace('التشويقي',iiy37aKq0pCEIOwfcTh61xb4U).replace('لمسلسل',iiy37aKq0pCEIOwfcTh61xb4U).replace('مسلسل',iiy37aKq0pCEIOwfcTh61xb4U)
	text = text.replace(':',iiy37aKq0pCEIOwfcTh61xb4U).replace(')',iiy37aKq0pCEIOwfcTh61xb4U).replace('(',iiy37aKq0pCEIOwfcTh61xb4U).replace(',',iiy37aKq0pCEIOwfcTh61xb4U)
	text = text.replace('_',iiy37aKq0pCEIOwfcTh61xb4U).replace(';',iiy37aKq0pCEIOwfcTh61xb4U).replace('-',iiy37aKq0pCEIOwfcTh61xb4U).replace('.',iiy37aKq0pCEIOwfcTh61xb4U)
	text = text.replace('\'',iiy37aKq0pCEIOwfcTh61xb4U).replace('\"',iiy37aKq0pCEIOwfcTh61xb4U)
	text = text.replace(hnVQObwUcR207fC,iFBmE2MUIpSu34wsd7Rf6z).replace(jHLaUg49SXC6JyTM,iFBmE2MUIpSu34wsd7Rf6z).replace(Wc5GekRC0HQLz7,iFBmE2MUIpSu34wsd7Rf6z)
	text = text.strip(iFBmE2MUIpSu34wsd7Rf6z)
	Wt7mIDpHKX1B3LYRgn9z0Ck48clre = text.count(iFBmE2MUIpSu34wsd7Rf6z)+1
	if Wt7mIDpHKX1B3LYRgn9z0Ck48clre==1:
		dAwIKnu97TYWFEX(text)
		return
	bP6z3OSLp7va('link',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+PSwfZcdRYhpl5Igqz8xOEk67+'==== كلمات للبحث ===='+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	i3JxObLETK4ClV = text.split(iFBmE2MUIpSu34wsd7Rf6z)
	weXdGyFAsCT0Rl8qZ = pow(2,Wt7mIDpHKX1B3LYRgn9z0Ck48clre)
	Qa9vDLUuOEX15P0 = []
	def nnheY9ivXMNk2WqFj(DToJiUqZ8rBGbhfISdxue2kv,g9k3MPLDoW4E8pRTFw):
		if DToJiUqZ8rBGbhfISdxue2kv=='1': return g9k3MPLDoW4E8pRTFw
		return iiy37aKq0pCEIOwfcTh61xb4U
	for o6oXFxmE1bQC in range(weXdGyFAsCT0Rl8qZ,0,-1):
		gIbSRkNaoY31uZW6Ozm2HQqj0dyUCA = list(Wt7mIDpHKX1B3LYRgn9z0Ck48clre*'0'+bin(o6oXFxmE1bQC)[2:])[-Wt7mIDpHKX1B3LYRgn9z0Ck48clre:]
		gIbSRkNaoY31uZW6Ozm2HQqj0dyUCA = reversed(gIbSRkNaoY31uZW6Ozm2HQqj0dyUCA)
		umOGqx65jCSBT1 = map(nnheY9ivXMNk2WqFj,gIbSRkNaoY31uZW6Ozm2HQqj0dyUCA,i3JxObLETK4ClV)
		title = iFBmE2MUIpSu34wsd7Rf6z.join(filter(None,umOGqx65jCSBT1))
		if iELueYz3J1FmxaW7vc: Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb = title.decode(df6QpwGxuJVZr)
		else: Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb = title
		if len(Zr6d2J3ETaGCk9LcKwsi4qB1Hv8mb)>2 and title not in Qa9vDLUuOEX15P0:
			Qa9vDLUuOEX15P0.append(title)
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,iiy37aKq0pCEIOwfcTh61xb4U,523,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,title)
	return
def dAwIKnu97TYWFEX(aKQTNif8Yw4s):
	if iELueYz3J1FmxaW7vc:
		aKQTNif8Yw4s = aKQTNif8Yw4s.decode(df6QpwGxuJVZr)
		import arabic_reshaper as XXsEboRCB9Ijetzl,bidi.algorithm as k9WamxRu6M4K0qeEXY
		aKQTNif8Yw4s = XXsEboRCB9Ijetzl.ArabicReshaper().reshape(aKQTNif8Yw4s)
		aKQTNif8Yw4s = k9WamxRu6M4K0qeEXY.get_display(aKQTNif8Yw4s)
	import TsIdr4GvYk
	aKQTNif8Yw4s = TTBf6S08q1NKXd5v9wa(lPY52bDgMAst4=aKQTNif8Yw4s)
	TsIdr4GvYk.mUhJtHB9nw(aKQTNif8Yw4s)
	return
def deDEXniSx8qkV3KwITU1j2(url):
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(Dxc7GChQwZ4kOlKHSbL06agnB,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'ELCINEMA-INDEXES_LISTS-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	DynmguA8OZ5Iq7t4QdNUcPG9 = WWF5a03Bix.BeautifulSoup(Vxz6OndPIX4g2kaRp7,'html.parser',multi_valued_attributes=None)
	PPH1sQtTkDBbnlYpZfo5 = DynmguA8OZ5Iq7t4QdNUcPG9.find(class_='list-separator list-title')
	v1JrBsOo8Qyzk = PPH1sQtTkDBbnlYpZfo5.find_all('a')
	items = []
	for title in v1JrBsOo8Qyzk:
		name = title.text
		fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN+title.get('href')
		if iELueYz3J1FmxaW7vc:
			name = name.encode(df6QpwGxuJVZr)
			fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork.encode(df6QpwGxuJVZr)
		if '#' not in fCXyTlcmF4WuetVork: items.append((name,fCXyTlcmF4WuetVork))
	items = sorted(items,reverse=False,key=lambda key: key[0])
	for YXD9KNfjCaLwkcrvJxldn7I in items:
		name,fCXyTlcmF4WuetVork = YXD9KNfjCaLwkcrvJxldn7I
		bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+name,fCXyTlcmF4WuetVork,518)
	return
def CKkqRTePDY0QNcpyJbZoHX14Wr(url):
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(Dxc7GChQwZ4kOlKHSbL06agnB,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'ELCINEMA-INDEXES_TITLES-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	DynmguA8OZ5Iq7t4QdNUcPG9 = WWF5a03Bix.BeautifulSoup(Vxz6OndPIX4g2kaRp7,'html.parser',multi_valued_attributes=None)
	ddfSDGyqEc = DynmguA8OZ5Iq7t4QdNUcPG9.find(class_='expand').find_all('tr')
	for PPH1sQtTkDBbnlYpZfo5 in ddfSDGyqEc:
		f2aGQX9bZ5cMhKoApjYeV1 = PPH1sQtTkDBbnlYpZfo5.find_all('a')
		if not f2aGQX9bZ5cMhKoApjYeV1: continue
		L95mrowGgdsD = PPH1sQtTkDBbnlYpZfo5.find('img').get('data-src')
		name = f2aGQX9bZ5cMhKoApjYeV1[1].text
		fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN+f2aGQX9bZ5cMhKoApjYeV1[1].get('href')
		lUQ0XZxkcfLHpbVmEtJ3DR = PPH1sQtTkDBbnlYpZfo5.find(class_='legend')
		if lUQ0XZxkcfLHpbVmEtJ3DR: lUQ0XZxkcfLHpbVmEtJ3DR = lUQ0XZxkcfLHpbVmEtJ3DR.text
		if iELueYz3J1FmxaW7vc:
			name = name.encode(df6QpwGxuJVZr)
			fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork.encode(df6QpwGxuJVZr)
			L95mrowGgdsD = L95mrowGgdsD.encode(df6QpwGxuJVZr)
		XC10geOnQtwrs = {}
		if lUQ0XZxkcfLHpbVmEtJ3DR: XC10geOnQtwrs['stars'] = lUQ0XZxkcfLHpbVmEtJ3DR
		if '/work/' in fCXyTlcmF4WuetVork:
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+name,fCXyTlcmF4WuetVork,516,L95mrowGgdsD,iiy37aKq0pCEIOwfcTh61xb4U,name,iiy37aKq0pCEIOwfcTh61xb4U,XC10geOnQtwrs)
		elif '/person/' in fCXyTlcmF4WuetVork: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+name,fCXyTlcmF4WuetVork,513,L95mrowGgdsD,iiy37aKq0pCEIOwfcTh61xb4U,name,iiy37aKq0pCEIOwfcTh61xb4U,XC10geOnQtwrs)
	vsOn7KRH1Vz6PLjWhdtIXw25YFNqu(DynmguA8OZ5Iq7t4QdNUcPG9,518)
	return
def zDZyTCFV0dYI7tovHSGL63(url):
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(Dxc7GChQwZ4kOlKHSbL06agnB,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'ELCINEMA-VIDEOS_LISTS-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	DynmguA8OZ5Iq7t4QdNUcPG9 = WWF5a03Bix.BeautifulSoup(Vxz6OndPIX4g2kaRp7,'html.parser',multi_valued_attributes=None)
	v1JrBsOo8Qyzk = DynmguA8OZ5Iq7t4QdNUcPG9.find_all(class_='section-title inline')
	P3tys0cXWbiIUKk7HQ6n89V = DynmguA8OZ5Iq7t4QdNUcPG9.find_all(class_='button green small right')
	items = zip(v1JrBsOo8Qyzk,P3tys0cXWbiIUKk7HQ6n89V)
	for title,fCXyTlcmF4WuetVork in items:
		title = title.text
		fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN+fCXyTlcmF4WuetVork.get('href')
		if iELueYz3J1FmxaW7vc:
			title = title.encode(df6QpwGxuJVZr)
			fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork.encode(df6QpwGxuJVZr)
		title = title.replace(hnVQObwUcR207fC,iFBmE2MUIpSu34wsd7Rf6z).replace(jHLaUg49SXC6JyTM,iFBmE2MUIpSu34wsd7Rf6z).replace(Wc5GekRC0HQLz7,iFBmE2MUIpSu34wsd7Rf6z)
		bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,521)
	return
def bkMl8QWoFGpJ6K2acPZs0IdvB(url):
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(Dxc7GChQwZ4kOlKHSbL06agnB,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'ELCINEMA-VIDEOS_TITLES-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	DynmguA8OZ5Iq7t4QdNUcPG9 = WWF5a03Bix.BeautifulSoup(Vxz6OndPIX4g2kaRp7,'html.parser',multi_valued_attributes=None)
	ZsC1oeUhpJ7dtD4aKgm0 = DynmguA8OZ5Iq7t4QdNUcPG9.find(class_='large-block-grid-4 medium-block-grid-4 small-block-grid-2')
	ddfSDGyqEc = ZsC1oeUhpJ7dtD4aKgm0.find_all('li')
	for PPH1sQtTkDBbnlYpZfo5 in ddfSDGyqEc:
		title = PPH1sQtTkDBbnlYpZfo5.find(class_='title').text
		fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN+PPH1sQtTkDBbnlYpZfo5.find('a').get('href')
		L95mrowGgdsD = PPH1sQtTkDBbnlYpZfo5.find('img').get('data-src')
		Zt6GY7K2oFeAd5kTy3nJvDBpQr = PPH1sQtTkDBbnlYpZfo5.find(class_='duration').text
		if iELueYz3J1FmxaW7vc:
			title = title.encode(df6QpwGxuJVZr)
			fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork.encode(df6QpwGxuJVZr)
			L95mrowGgdsD = L95mrowGgdsD.encode(df6QpwGxuJVZr)
			Zt6GY7K2oFeAd5kTy3nJvDBpQr = Zt6GY7K2oFeAd5kTy3nJvDBpQr.encode(df6QpwGxuJVZr)
		Zt6GY7K2oFeAd5kTy3nJvDBpQr = Zt6GY7K2oFeAd5kTy3nJvDBpQr.replace(OTlVEGYPSxsNaBdXUucqA3,iiy37aKq0pCEIOwfcTh61xb4U).strip(iFBmE2MUIpSu34wsd7Rf6z)
		bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,522,L95mrowGgdsD,Zt6GY7K2oFeAd5kTy3nJvDBpQr)
	vsOn7KRH1Vz6PLjWhdtIXw25YFNqu(DynmguA8OZ5Iq7t4QdNUcPG9,521)
	return
def TW6Z0zqaDl(url):
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(Dxc7GChQwZ4kOlKHSbL06agnB,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'ELCINEMA-PLAY-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	DynmguA8OZ5Iq7t4QdNUcPG9 = WWF5a03Bix.BeautifulSoup(Vxz6OndPIX4g2kaRp7,'html.parser',multi_valued_attributes=None)
	fCXyTlcmF4WuetVork = DynmguA8OZ5Iq7t4QdNUcPG9.find(class_='flex-video').find('iframe').get('src')
	if iELueYz3J1FmxaW7vc: fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork.encode(df6QpwGxuJVZr)
	import lqBJGK8hXO
	lqBJGK8hXO.ZDg1HavwueT85mcAOorC4hnS([fCXyTlcmF4WuetVork],sQU2GnRoMwLK8CBdfzmNr4jXyO,'video',url)
	return
def mUhJtHB9nw(search):
	search,brFQp5vmgJWdZfEkCBOlu9c,showDialogs = XkYnev3ZCA6ahO94(search)
	if search==iiy37aKq0pCEIOwfcTh61xb4U: search = TTBf6S08q1NKXd5v9wa()
	if search==iiy37aKq0pCEIOwfcTh61xb4U: return
	search = search.replace(iFBmE2MUIpSu34wsd7Rf6z,'%20')
	url = JaQEtCzDXgos1cdZN+'/search/?q='+search
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(Dxc7GChQwZ4kOlKHSbL06agnB,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'ELCINEMA-SEARCH-1st')
	if not oCJ8TdG2LwSIVcbaUnhB.succeeded:
		BFWTwxolSOAP9Uj = JaQEtCzDXgos1cdZN+'/search_entity/?q='+search+'&entity=work'
		hx0dU3Ki7AyEfkSZY6TmN2BwtX = JaQEtCzDXgos1cdZN+'/search_entity/?q='+search+'&entity=person'
		q9gapTFDB8jn = JaQEtCzDXgos1cdZN+'/search_entity/?q='+search+'&entity=video'
		bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'بحث عن أعمال',BFWTwxolSOAP9Uj,513,iiy37aKq0pCEIOwfcTh61xb4U,search)
		bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'بحث عن أشخاص',hx0dU3Ki7AyEfkSZY6TmN2BwtX,513,iiy37aKq0pCEIOwfcTh61xb4U,search)
		bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'بحث عن فيديوهات',q9gapTFDB8jn,513,iiy37aKq0pCEIOwfcTh61xb4U,search)
		return
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	DynmguA8OZ5Iq7t4QdNUcPG9 = WWF5a03Bix.BeautifulSoup(Vxz6OndPIX4g2kaRp7,'html.parser',multi_valued_attributes=None)
	ddfSDGyqEc = DynmguA8OZ5Iq7t4QdNUcPG9.find_all(class_='section-title left')
	for PPH1sQtTkDBbnlYpZfo5 in ddfSDGyqEc:
		title = PPH1sQtTkDBbnlYpZfo5.text
		if iELueYz3J1FmxaW7vc:
			title = title.encode(df6QpwGxuJVZr)
		title = title.split('(',1)[0].strip(iFBmE2MUIpSu34wsd7Rf6z)
		if   'أعمال' in title: fCXyTlcmF4WuetVork = url.replace('/search/','/search/work/')
		elif 'أشخاص' in title: fCXyTlcmF4WuetVork = url.replace('/search/','/search/person/')
		elif 'فيديوهات' in title: fCXyTlcmF4WuetVork = url.replace('/search/','/search/video/')
		else: continue
		bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,513)
	return
def uxp3cAOydm(url,text):
	global JYMlXTc9DCZrohd,a3aiAqYngfydR1XNJK975wl4jD
	if '/seasonals' in url:
		JYMlXTc9DCZrohd = ['seasonal','year','category']
		a3aiAqYngfydR1XNJK975wl4jD = ['seasonal','year','category']
	elif '/lineup' in url:
		JYMlXTc9DCZrohd = ['category','foreign','type']
		a3aiAqYngfydR1XNJK975wl4jD = ['category','foreign','type']
	chQHNdWgTSDjti8R9pJUf(url,text)
	return
def Dv235GCSiTYasugHxhbPUVjdKkcprN(url):
	url = url.split('/smartemadfilter?')[0]
	oCJ8TdG2LwSIVcbaUnhB = MMCJxEfv0WUek(Dxc7GChQwZ4kOlKHSbL06agnB,'GET',url,iiy37aKq0pCEIOwfcTh61xb4U,headers,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'ELCINEMA-GET_FILTERS_BLOCKS-1st')
	Vxz6OndPIX4g2kaRp7 = oCJ8TdG2LwSIVcbaUnhB.content
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('form action="/(.*?)</form>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
	n8nFIQBNaXD = dEyT9xhGjolYzLCH7460w3.findall('<select name="(.*?)" id="(.*?)".*?>(.*?)</div>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	return n8nFIQBNaXD
def T6TdxbQOnA(PPH1sQtTkDBbnlYpZfo5):
	items = dEyT9xhGjolYzLCH7460w3.findall('<option value="(.*?)">(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	return items
def FvYaT7p0Wi3unK6(url):
	UM3q9WaVXOP4ZuhCnHB5jyA = url.split('/smartemadfilter?')[0]
	VrnhdEezI7 = F82MvyX4ThI6sbnA3efDoVS(url,'url')
	url = url.replace('/smartemadfilter?','/?utf8=%E2%9C%93&')
	return url
def TTj6uWAhy0(vvlVH6JT9YDNPeSaRUkKCAwpr5uq,url):
	bPXk8KHyCUrifag = qJ8NQtuWARGjoZd9swfbH(vvlVH6JT9YDNPeSaRUkKCAwpr5uq,'all_filters')
	O5Pwg3UFyX0k9E = url+'/smartemadfilter?'+bPXk8KHyCUrifag
	O5Pwg3UFyX0k9E = FvYaT7p0Wi3unK6(O5Pwg3UFyX0k9E)
	return O5Pwg3UFyX0k9E
def chQHNdWgTSDjti8R9pJUf(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==iiy37aKq0pCEIOwfcTh61xb4U: Mhd9LWrfiF1EsASl6eP34uTp0qNGom,ovh6cXGg1qd85fn3CSJEisTlI7Yz = iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U
	else: Mhd9LWrfiF1EsASl6eP34uTp0qNGom,ovh6cXGg1qd85fn3CSJEisTlI7Yz = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if JYMlXTc9DCZrohd[0]+'=' not in Mhd9LWrfiF1EsASl6eP34uTp0qNGom: RRIscyLmNH9dq2Dio3TSr = JYMlXTc9DCZrohd[0]
		for iEfNKT3velFyGth80SA4pxbCRrVD in range(len(JYMlXTc9DCZrohd[0:-1])):
			if JYMlXTc9DCZrohd[iEfNKT3velFyGth80SA4pxbCRrVD]+'=' in Mhd9LWrfiF1EsASl6eP34uTp0qNGom: RRIscyLmNH9dq2Dio3TSr = JYMlXTc9DCZrohd[iEfNKT3velFyGth80SA4pxbCRrVD+1]
		HdFJThcNtWe3lb8n4OmaSwQ = Mhd9LWrfiF1EsASl6eP34uTp0qNGom+'&'+RRIscyLmNH9dq2Dio3TSr+'=0'
		vvlVH6JT9YDNPeSaRUkKCAwpr5uq = ovh6cXGg1qd85fn3CSJEisTlI7Yz+'&'+RRIscyLmNH9dq2Dio3TSr+'=0'
		cCZR4YdwUepABD9mQsubT8FgN = HdFJThcNtWe3lb8n4OmaSwQ.strip('&')+'___'+vvlVH6JT9YDNPeSaRUkKCAwpr5uq.strip('&')
		bPXk8KHyCUrifag = qJ8NQtuWARGjoZd9swfbH(ovh6cXGg1qd85fn3CSJEisTlI7Yz,'modified_filters')
		eCGwzSrqBmIv = url+'/smartemadfilter?'+bPXk8KHyCUrifag
	elif type=='ALL_ITEMS_FILTER':
		GMQ6AxE012X9 = qJ8NQtuWARGjoZd9swfbH(Mhd9LWrfiF1EsASl6eP34uTp0qNGom,'modified_values')
		GMQ6AxE012X9 = a9I3YZjc6ySDPE4Kp(GMQ6AxE012X9)
		if ovh6cXGg1qd85fn3CSJEisTlI7Yz!=iiy37aKq0pCEIOwfcTh61xb4U: ovh6cXGg1qd85fn3CSJEisTlI7Yz = qJ8NQtuWARGjoZd9swfbH(ovh6cXGg1qd85fn3CSJEisTlI7Yz,'modified_filters')
		if ovh6cXGg1qd85fn3CSJEisTlI7Yz==iiy37aKq0pCEIOwfcTh61xb4U: eCGwzSrqBmIv = url
		else: eCGwzSrqBmIv = url+'/smartemadfilter?'+ovh6cXGg1qd85fn3CSJEisTlI7Yz
		eCGwzSrqBmIv = FvYaT7p0Wi3unK6(eCGwzSrqBmIv)
		bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'أظهار قائمة الفيديو التي تم اختيارها ',eCGwzSrqBmIv,511)
		bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+' [[   '+GMQ6AxE012X9+'   ]]',eCGwzSrqBmIv,511)
		bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	n8nFIQBNaXD = Dv235GCSiTYasugHxhbPUVjdKkcprN(url)
	dict = {}
	for name,cWhMpFIbQU4D1Bi,PPH1sQtTkDBbnlYpZfo5 in n8nFIQBNaXD:
		name = name.replace('--',iiy37aKq0pCEIOwfcTh61xb4U)
		items = T6TdxbQOnA(PPH1sQtTkDBbnlYpZfo5)
		if '=' not in eCGwzSrqBmIv: eCGwzSrqBmIv = url
		if type=='SPECIFIED_FILTER':
			if cWhMpFIbQU4D1Bi not in JYMlXTc9DCZrohd: continue
			if RRIscyLmNH9dq2Dio3TSr!=cWhMpFIbQU4D1Bi: continue
			elif len(items)<2:
				if cWhMpFIbQU4D1Bi==JYMlXTc9DCZrohd[-1]:
					url = FvYaT7p0Wi3unK6(url)
					lsJa5qRHhMm(url)
				else: chQHNdWgTSDjti8R9pJUf(eCGwzSrqBmIv,'SPECIFIED_FILTER___'+cCZR4YdwUepABD9mQsubT8FgN)
				return
			else:
				eCGwzSrqBmIv = FvYaT7p0Wi3unK6(eCGwzSrqBmIv)
				if cWhMpFIbQU4D1Bi==JYMlXTc9DCZrohd[-1]: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'الجميع',eCGwzSrqBmIv,511)
				else: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'الجميع',eCGwzSrqBmIv,515,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,cCZR4YdwUepABD9mQsubT8FgN)
		elif type=='ALL_ITEMS_FILTER':
			if cWhMpFIbQU4D1Bi not in a3aiAqYngfydR1XNJK975wl4jD: continue
			HdFJThcNtWe3lb8n4OmaSwQ = Mhd9LWrfiF1EsASl6eP34uTp0qNGom+'&'+cWhMpFIbQU4D1Bi+'=0'
			vvlVH6JT9YDNPeSaRUkKCAwpr5uq = ovh6cXGg1qd85fn3CSJEisTlI7Yz+'&'+cWhMpFIbQU4D1Bi+'=0'
			cCZR4YdwUepABD9mQsubT8FgN = HdFJThcNtWe3lb8n4OmaSwQ+'___'+vvlVH6JT9YDNPeSaRUkKCAwpr5uq
			if   name=='type': name = 'النوع'
			elif name=='category': name = 'العمل'
			elif name=='foreign': name = 'اللغة'
			elif name=='year': name = 'السنة'
			elif name=='seasonal': name = 'الموسم'
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'الجميع: '+name,eCGwzSrqBmIv,514,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,cCZR4YdwUepABD9mQsubT8FgN)
		dict[cWhMpFIbQU4D1Bi] = {}
		for aasX2cby4Vo5rTgB,KjsA38t0DCSmuLcaE in items:
			if KjsA38t0DCSmuLcaE in a8GCLIuWNkS: continue
			if 'مصنفات أخرى' in KjsA38t0DCSmuLcaE: continue
			if 'الكل' in KjsA38t0DCSmuLcaE: continue
			if 'اللغة' in KjsA38t0DCSmuLcaE: continue
			KjsA38t0DCSmuLcaE = KjsA38t0DCSmuLcaE.replace('قائمة ',iiy37aKq0pCEIOwfcTh61xb4U)
			if   name=='type': name = 'النوع'
			elif name=='category': name = 'العمل'
			elif name=='foreign': name = 'اللغة'
			elif name=='year': name = 'السنة'
			elif name=='seasonal': name = 'الموسم'
			dict[cWhMpFIbQU4D1Bi][aasX2cby4Vo5rTgB] = KjsA38t0DCSmuLcaE
			HdFJThcNtWe3lb8n4OmaSwQ = Mhd9LWrfiF1EsASl6eP34uTp0qNGom+'&'+cWhMpFIbQU4D1Bi+'='+KjsA38t0DCSmuLcaE
			vvlVH6JT9YDNPeSaRUkKCAwpr5uq = ovh6cXGg1qd85fn3CSJEisTlI7Yz+'&'+cWhMpFIbQU4D1Bi+'='+aasX2cby4Vo5rTgB
			kuyfTIwjRrhXUo = HdFJThcNtWe3lb8n4OmaSwQ+'___'+vvlVH6JT9YDNPeSaRUkKCAwpr5uq
			if name: title = KjsA38t0DCSmuLcaE+' :'+name
			else: title = KjsA38t0DCSmuLcaE
			if type=='ALL_ITEMS_FILTER': bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,url,514,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,kuyfTIwjRrhXUo)
			elif type=='SPECIFIED_FILTER' and JYMlXTc9DCZrohd[-2]+'=' in Mhd9LWrfiF1EsASl6eP34uTp0qNGom:
				O5Pwg3UFyX0k9E = TTj6uWAhy0(vvlVH6JT9YDNPeSaRUkKCAwpr5uq,url)
				bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,O5Pwg3UFyX0k9E,511)
			else: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,url,515,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,kuyfTIwjRrhXUo)
	return
def qJ8NQtuWARGjoZd9swfbH(HSAqBpsb2jRLvk9lx147rzY,mode):
	HSAqBpsb2jRLvk9lx147rzY = HSAqBpsb2jRLvk9lx147rzY.replace('=&','=0&')
	HSAqBpsb2jRLvk9lx147rzY = HSAqBpsb2jRLvk9lx147rzY.strip('&')
	x8UiIH3WCTEpe = {}
	if '=' in HSAqBpsb2jRLvk9lx147rzY:
		items = HSAqBpsb2jRLvk9lx147rzY.split('&')
		for YXD9KNfjCaLwkcrvJxldn7I in items:
			xYkDXe5UjvETygJNLrRQ96mtp8BKGW,aasX2cby4Vo5rTgB = YXD9KNfjCaLwkcrvJxldn7I.split('=')
			x8UiIH3WCTEpe[xYkDXe5UjvETygJNLrRQ96mtp8BKGW] = aasX2cby4Vo5rTgB
	QAvGYocVXgzh9 = iiy37aKq0pCEIOwfcTh61xb4U
	for key in a3aiAqYngfydR1XNJK975wl4jD:
		if key in list(x8UiIH3WCTEpe.keys()): aasX2cby4Vo5rTgB = x8UiIH3WCTEpe[key]
		else: aasX2cby4Vo5rTgB = '0'
		if '%' not in aasX2cby4Vo5rTgB: aasX2cby4Vo5rTgB = YqdaDIig21wBTWJeUHbc(aasX2cby4Vo5rTgB)
		if mode=='modified_values' and aasX2cby4Vo5rTgB!='0': QAvGYocVXgzh9 = QAvGYocVXgzh9+' + '+aasX2cby4Vo5rTgB
		elif mode=='modified_filters' and aasX2cby4Vo5rTgB!='0': QAvGYocVXgzh9 = QAvGYocVXgzh9+'&'+key+'='+aasX2cby4Vo5rTgB
		elif mode=='all_filters': QAvGYocVXgzh9 = QAvGYocVXgzh9+'&'+key+'='+aasX2cby4Vo5rTgB
	QAvGYocVXgzh9 = QAvGYocVXgzh9.strip(' + ')
	QAvGYocVXgzh9 = QAvGYocVXgzh9.strip('&')
	QAvGYocVXgzh9 = QAvGYocVXgzh9.replace('=0','=')
	return QAvGYocVXgzh9
JYMlXTc9DCZrohd = []
a3aiAqYngfydR1XNJK975wl4jD = []
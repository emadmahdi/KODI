# -*- coding: utf-8 -*-
from braVAkwfBN import *
sQU2GnRoMwLK8CBdfzmNr4jXyO = 'ALKAWTHAR'
ooQEi5O6tYsGVF8LU0TC3hgMeflBwH = '_KWT_'
JaQEtCzDXgos1cdZN = gZ4LwbKaOm[sQU2GnRoMwLK8CBdfzmNr4jXyO][0]
def sHVM8YchrDjZAJ7(mode,url,zLEP9N4BOsVrXa,text):
	if   mode==130: EA7FzO1kMZGQXDd2giB0cwLom = jihuS9LVAvTrClPapMbUEwfn8XN()
	elif mode==131: EA7FzO1kMZGQXDd2giB0cwLom = AIQeNZP4FMDw9S(url)
	elif mode==132: EA7FzO1kMZGQXDd2giB0cwLom = hemvDOJkEw2FdCSgnL1VaR(url)
	elif mode==133: EA7FzO1kMZGQXDd2giB0cwLom = YNcMvoVF5swlDBJI7PL(url,zLEP9N4BOsVrXa)
	elif mode==134: EA7FzO1kMZGQXDd2giB0cwLom = TW6Z0zqaDl(url)
	elif mode==135: EA7FzO1kMZGQXDd2giB0cwLom = FaD6NxfSIbzZimr9d4wOjQMkYhn5()
	elif mode==139: EA7FzO1kMZGQXDd2giB0cwLom = mUhJtHB9nw(text,url)
	else: EA7FzO1kMZGQXDd2giB0cwLom = False
	return EA7FzO1kMZGQXDd2giB0cwLom
def jihuS9LVAvTrClPapMbUEwfn8XN():
	bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'بحث في الموقع',iiy37aKq0pCEIOwfcTh61xb4U,139,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'_REMEMBERRESULTS_')
	bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(PNjZMS7nxa9clHusz1,JaQEtCzDXgos1cdZN,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,True,'ALKAWTHAR-MENU-1st')
	UUIohmv597bO83YCLgWS=dEyT9xhGjolYzLCH7460w3.findall('dropdown-menu(.*?)dropdown-toggle',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[1]
	items=dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)">(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	for fCXyTlcmF4WuetVork,title in items:
		if '/conductor' in fCXyTlcmF4WuetVork: continue
		title = title.strip(iFBmE2MUIpSu34wsd7Rf6z)
		url = JaQEtCzDXgos1cdZN+fCXyTlcmF4WuetVork
		if '/category/' in url: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,url,132)
		else: bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,url,131)
	bP6z3OSLp7va('link',PSwfZcdRYhpl5Igqz8xOEk67+' ===== ===== ===== '+YoQW601K4fMJcsreDnGVE5wUZIy7,iiy37aKq0pCEIOwfcTh61xb4U,9999)
	bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'المسلسلات',JaQEtCzDXgos1cdZN+'/category/543',132,iiy37aKq0pCEIOwfcTh61xb4U,'1')
	bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'الأفلام',JaQEtCzDXgos1cdZN+'/category/628',132,iiy37aKq0pCEIOwfcTh61xb4U,'1')
	bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'برامج الصغار والشباب',JaQEtCzDXgos1cdZN+'/category/517',132,iiy37aKq0pCEIOwfcTh61xb4U,'1')
	bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'ابرز البرامج',JaQEtCzDXgos1cdZN+'/category/1763',132,iiy37aKq0pCEIOwfcTh61xb4U,'1')
	bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'المحاضرات',JaQEtCzDXgos1cdZN+'/category/943',132,iiy37aKq0pCEIOwfcTh61xb4U,'1')
	bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'عاشوراء',JaQEtCzDXgos1cdZN+'/category/1353',132,iiy37aKq0pCEIOwfcTh61xb4U,'1')
	bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'البرامج الاجتماعية',JaQEtCzDXgos1cdZN+'/category/501',132,iiy37aKq0pCEIOwfcTh61xb4U,'1')
	bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'البرامج الدينية',JaQEtCzDXgos1cdZN+'/category/509',132,iiy37aKq0pCEIOwfcTh61xb4U,'1')
	bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'البرامج الوثائقية',JaQEtCzDXgos1cdZN+'/category/553',132,iiy37aKq0pCEIOwfcTh61xb4U,'1')
	bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'البرامج السياسية',JaQEtCzDXgos1cdZN+'/category/545',132,iiy37aKq0pCEIOwfcTh61xb4U,'1')
	bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'كتب',JaQEtCzDXgos1cdZN+'/category/291',132,iiy37aKq0pCEIOwfcTh61xb4U,'1')
	bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'تعلم الفارسية',JaQEtCzDXgos1cdZN+'/category/88',132,iiy37aKq0pCEIOwfcTh61xb4U,'1')
	bP6z3OSLp7va('folder',sQU2GnRoMwLK8CBdfzmNr4jXyO+'_SCRIPT_'+ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'أرشيف البرامج',JaQEtCzDXgos1cdZN+'/category/1279',132,iiy37aKq0pCEIOwfcTh61xb4U,'1')
	return
def AIQeNZP4FMDw9S(url):
	AKsQiuk1hJ = ['/religious','/social','/political','/films','/series']
	Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(PNjZMS7nxa9clHusz1,url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,True,'ALKAWTHAR-TITLES-1st')
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('titlebar(.*?)titlebar',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
	if any(aasX2cby4Vo5rTgB in url for aasX2cby4Vo5rTgB in AKsQiuk1hJ):
		items = dEyT9xhGjolYzLCH7460w3.findall("src='(.*?)'.*?href='(.*?)'.*?>(.*?)<",PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for C0dvhEbPWYlUtimM3x,fCXyTlcmF4WuetVork,title in items:
			title = title.strip(iFBmE2MUIpSu34wsd7Rf6z)
			fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN + fCXyTlcmF4WuetVork
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,133,C0dvhEbPWYlUtimM3x,'1')
	elif '/docs' in url:
		items = dEyT9xhGjolYzLCH7460w3.findall("src='(.*?)'.*?<h2>(.*?)</h2>.*?href='(.*?)'",PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for C0dvhEbPWYlUtimM3x,title,fCXyTlcmF4WuetVork in items:
			title = title.strip(iFBmE2MUIpSu34wsd7Rf6z)
			fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN + fCXyTlcmF4WuetVork
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,133,C0dvhEbPWYlUtimM3x,'1')
	return
def hemvDOJkEw2FdCSgnL1VaR(url):
	RRIscyLmNH9dq2Dio3TSr = url.split('/')[-1]
	Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(Dxc7GChQwZ4kOlKHSbL06agnB,url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,True,'ALKAWTHAR-CATEGORIES-1st')
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('parentcat(.*?)</div>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if not UUIohmv597bO83YCLgWS:
		YNcMvoVF5swlDBJI7PL(url,'1')
		return
	PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
	items = dEyT9xhGjolYzLCH7460w3.findall("href='(.*?)'.*?>(.*?)<",PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
	for fCXyTlcmF4WuetVork,title in items:
		title = title.strip(iFBmE2MUIpSu34wsd7Rf6z)
		fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN + fCXyTlcmF4WuetVork
		bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,132,iiy37aKq0pCEIOwfcTh61xb4U,'1')
	return
def YNcMvoVF5swlDBJI7PL(url,zLEP9N4BOsVrXa):
	Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(PNjZMS7nxa9clHusz1,url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,True,'ALKAWTHAR-EPISODES-1st')
	items = dEyT9xhGjolYzLCH7460w3.findall('totalpagecount=[\'"](.*?)[\'"]',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if not items:
		url = dEyT9xhGjolYzLCH7460w3.findall('class="news-detail-body".*?href="(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		url = url[0]
		title = '_MOD_' + 'ملف التشغيل'
		if url: bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,url,134)
		else: bb5kRv7jh3LaEVJtIfg(iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,'رسالة من المبرمج','لا يوجد حاليا ملفات فيديو في هذا الفرع')
		return
	awnhWTdMEfypRiqZNzLKCO1UX7gADv = int(items[0])
	name = dEyT9xhGjolYzLCH7460w3.findall('main-title.*?</a> >(.*?)<',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if name: name = name[0].strip(iFBmE2MUIpSu34wsd7Rf6z)
	else: name = WwMgozBIC32n9d0tyfp.getInfoLabel('ListItem.Label')
	if '/category/' in url or 'search?q=' in url:
		RRIscyLmNH9dq2Dio3TSr = url.split('/')[-1]
		if zLEP9N4BOsVrXa==iiy37aKq0pCEIOwfcTh61xb4U: eCGwzSrqBmIv = url
		else: eCGwzSrqBmIv = JaQEtCzDXgos1cdZN + '/category/' + RRIscyLmNH9dq2Dio3TSr + '/' + zLEP9N4BOsVrXa
		z0spMAOfJElv6L1K9ae = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(PNjZMS7nxa9clHusz1,eCGwzSrqBmIv,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,True,'ALKAWTHAR-EPISODES-2nd')
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('currentpagenumber(.*?)pagination',z0spMAOfJElv6L1K9ae,dEyT9xhGjolYzLCH7460w3.DOTALL)
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		items = dEyT9xhGjolYzLCH7460w3.findall('src="(.*?)".*?full(.*?)>.*?href="(.*?)".*?>(.*?)<',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for C0dvhEbPWYlUtimM3x,type,fCXyTlcmF4WuetVork,title in items:
			if 'video' not in type: continue
			if 'مسلسل' in title and 'حلقة' not in title: continue
			title = title.replace('\r\n',iiy37aKq0pCEIOwfcTh61xb4U)
			title = title.strip(iFBmE2MUIpSu34wsd7Rf6z)
			if 'مسلسل' in name and 'حلقة' in title and 'مسلسل' not in title:
				title = '_MOD_' + name + ' - ' + title
			fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN + fCXyTlcmF4WuetVork
			if RRIscyLmNH9dq2Dio3TSr=='628': bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,133,C0dvhEbPWYlUtimM3x,'1')
			else: bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,134,C0dvhEbPWYlUtimM3x)
	elif '/episode/' in url:
		UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('playlist(.*?)col-md-12',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if UUIohmv597bO83YCLgWS:
			PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
			items = dEyT9xhGjolYzLCH7460w3.findall("video-track-text.*?loadVideo\('(.*?)','(.*?)'.*?>(.*?)<",PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
			for fCXyTlcmF4WuetVork,C0dvhEbPWYlUtimM3x,title in items:
				title = title.strip(iFBmE2MUIpSu34wsd7Rf6z)
				bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,fCXyTlcmF4WuetVork,134,C0dvhEbPWYlUtimM3x)
		elif '/category/628' in Vxz6OndPIX4g2kaRp7:
				title = '_MOD_' + 'ملف التشغيل'
				bP6z3OSLp7va('video',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+title,url,134)
		else:
			items = dEyT9xhGjolYzLCH7460w3.findall('id="Categories.*?href=\'(.*?)\'',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
			RRIscyLmNH9dq2Dio3TSr = items[0].split('/')[-1]
			url = JaQEtCzDXgos1cdZN + '/category/' + RRIscyLmNH9dq2Dio3TSr
			hemvDOJkEw2FdCSgnL1VaR(url)
			return
	UUIohmv597bO83YCLgWS = dEyT9xhGjolYzLCH7460w3.findall('pagination(.*?)</div>',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	if UUIohmv597bO83YCLgWS:
		PPH1sQtTkDBbnlYpZfo5 = UUIohmv597bO83YCLgWS[0]
		JD0cNSKG5YLTEhzfls = dEyT9xhGjolYzLCH7460w3.findall('href="(.*?)">(.*?)</a>',PPH1sQtTkDBbnlYpZfo5,dEyT9xhGjolYzLCH7460w3.DOTALL)
		for fCXyTlcmF4WuetVork,title in JD0cNSKG5YLTEhzfls:
			fCXyTlcmF4WuetVork = JaQEtCzDXgos1cdZN+fCXyTlcmF4WuetVork
			fCXyTlcmF4WuetVork = fCXyTlcmF4WuetVork.replace('&amp;','&')
			bP6z3OSLp7va('folder',ooQEi5O6tYsGVF8LU0TC3hgMeflBwH+'صفحة '+title,fCXyTlcmF4WuetVork,133)
	return
def TW6Z0zqaDl(url):
	if '/news/' in url or '/episode/' in url:
		Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(Dxc7GChQwZ4kOlKHSbL06agnB,url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,True,'ALKAWTHAR-PLAY-1st')
		items = dEyT9xhGjolYzLCH7460w3.findall("mobilevideopath.*?value='(.*?)'",Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
		if items: url = items[0]
	PsD3IgluKFyvzMLoRT9j5hq2(url,sQU2GnRoMwLK8CBdfzmNr4jXyO,'video')
	return
def FaD6NxfSIbzZimr9d4wOjQMkYhn5():
	url = JaQEtCzDXgos1cdZN+'/live'
	Vxz6OndPIX4g2kaRp7 = uDgpjAaKoJTUGY1PlyLqtROrwBQ6(Dxc7GChQwZ4kOlKHSbL06agnB,url,iiy37aKq0pCEIOwfcTh61xb4U,iiy37aKq0pCEIOwfcTh61xb4U,True,'ALKAWTHAR-LIVE-1st')
	eCGwzSrqBmIv = dEyT9xhGjolYzLCH7460w3.findall('live-container.*?src="(.*?)"',Vxz6OndPIX4g2kaRp7,dEyT9xhGjolYzLCH7460w3.DOTALL)
	eCGwzSrqBmIv = eCGwzSrqBmIv[0]
	rzR9SN7ApZuQhTDWEX3V6ga = {'Referer':JaQEtCzDXgos1cdZN}
	xQoYJsjSm0yfdzaOewV7pC = MMCJxEfv0WUek(hI7SkXd94fFzAHNZCQoMqEutbnWP,'GET',eCGwzSrqBmIv,iiy37aKq0pCEIOwfcTh61xb4U,rzR9SN7ApZuQhTDWEX3V6ga,iiy37aKq0pCEIOwfcTh61xb4U,True,'ALKAWTHAR-LIVE-2nd')
	z0spMAOfJElv6L1K9ae = xQoYJsjSm0yfdzaOewV7pC.content
	XV3cU4Ez5kgM0YtHNedhuRGB879lpT = dEyT9xhGjolYzLCH7460w3.findall('csrf-token" content="(.*?)"',z0spMAOfJElv6L1K9ae,dEyT9xhGjolYzLCH7460w3.DOTALL)
	XV3cU4Ez5kgM0YtHNedhuRGB879lpT = XV3cU4Ez5kgM0YtHNedhuRGB879lpT[0]
	B8yOzwPuZeV3RtN0Q4ksn1TdJGc = F82MvyX4ThI6sbnA3efDoVS(eCGwzSrqBmIv,'url')
	O5Pwg3UFyX0k9E = dEyT9xhGjolYzLCH7460w3.findall("playUrl = '(.*?)'",z0spMAOfJElv6L1K9ae,dEyT9xhGjolYzLCH7460w3.DOTALL)
	O5Pwg3UFyX0k9E = B8yOzwPuZeV3RtN0Q4ksn1TdJGc+O5Pwg3UFyX0k9E[0]
	GmTJlQcwnYNbOWB2xXt = {'X-CSRF-TOKEN':XV3cU4Ez5kgM0YtHNedhuRGB879lpT}
	LohAQRbz2WGpwNmPHJrdcv984S = MMCJxEfv0WUek(hI7SkXd94fFzAHNZCQoMqEutbnWP,'POST',O5Pwg3UFyX0k9E,iiy37aKq0pCEIOwfcTh61xb4U,GmTJlQcwnYNbOWB2xXt,False,True,'ALKAWTHAR-LIVE-3rd')
	h9NLHzug623eR = LohAQRbz2WGpwNmPHJrdcv984S.content
	x93j25L6Agtsyfkh7 = dEyT9xhGjolYzLCH7460w3.findall('"(.*?)"',h9NLHzug623eR,dEyT9xhGjolYzLCH7460w3.DOTALL)
	x93j25L6Agtsyfkh7 = x93j25L6Agtsyfkh7[0].replace('\/','/')
	PsD3IgluKFyvzMLoRT9j5hq2(x93j25L6Agtsyfkh7,sQU2GnRoMwLK8CBdfzmNr4jXyO,'live')
	return
def mUhJtHB9nw(search,url=iiy37aKq0pCEIOwfcTh61xb4U):
	search,brFQp5vmgJWdZfEkCBOlu9c,showDialogs = XkYnev3ZCA6ahO94(search)
	if url==iiy37aKq0pCEIOwfcTh61xb4U:
		if search==iiy37aKq0pCEIOwfcTh61xb4U: search = TTBf6S08q1NKXd5v9wa()
		if search==iiy37aKq0pCEIOwfcTh61xb4U: return
		search = YqdaDIig21wBTWJeUHbc(search)
		url = JaQEtCzDXgos1cdZN+'/search?q='+search
		YNcMvoVF5swlDBJI7PL(url,iiy37aKq0pCEIOwfcTh61xb4U)
		return
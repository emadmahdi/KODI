# -*- coding: utf-8 -*-
import sys as pVy8J6XAkqmrvzRe7
M7Cn9c4LzxK8P1O5ikuU = pVy8J6XAkqmrvzRe7.version_info [0] == 2
p3YSoFNiEJmC9x1tUsjX = 2048
uezlMO8x1BJ4PwIY = 7
def EgfwLDcJihvey15uMZCFX (cdeEUYPWMnmJl4iq0RBopyva2SHZX):
	global WkIOeL4KciV
	u8ucs5wX9Y3oVklahTBv6Der4jbWi = ord (cdeEUYPWMnmJl4iq0RBopyva2SHZX [-1])
	vY8n9BXu6oCpckKbWzDq1 = cdeEUYPWMnmJl4iq0RBopyva2SHZX [:-1]
	Pmf137OtuF9voYN = u8ucs5wX9Y3oVklahTBv6Der4jbWi % len (vY8n9BXu6oCpckKbWzDq1)
	Nzkhp109SGsREKaVoXqQ4D = vY8n9BXu6oCpckKbWzDq1 [:Pmf137OtuF9voYN] + vY8n9BXu6oCpckKbWzDq1 [Pmf137OtuF9voYN:]
	if M7Cn9c4LzxK8P1O5ikuU:
		A1KkDCqzTQjMEu75Z2Leb4aH8 = unicode () .join ([unichr (ord (Jfc2YHFLutsC8GSg9eqdDno6yAkT4) - p3YSoFNiEJmC9x1tUsjX - (KOHs9o8x4YTwFgmqvQuj + u8ucs5wX9Y3oVklahTBv6Der4jbWi) % uezlMO8x1BJ4PwIY) for KOHs9o8x4YTwFgmqvQuj, Jfc2YHFLutsC8GSg9eqdDno6yAkT4 in enumerate (Nzkhp109SGsREKaVoXqQ4D)])
	else:
		A1KkDCqzTQjMEu75Z2Leb4aH8 = str () .join ([chr (ord (Jfc2YHFLutsC8GSg9eqdDno6yAkT4) - p3YSoFNiEJmC9x1tUsjX - (KOHs9o8x4YTwFgmqvQuj + u8ucs5wX9Y3oVklahTBv6Der4jbWi) % uezlMO8x1BJ4PwIY) for KOHs9o8x4YTwFgmqvQuj, Jfc2YHFLutsC8GSg9eqdDno6yAkT4 in enumerate (Nzkhp109SGsREKaVoXqQ4D)])
	return eval (A1KkDCqzTQjMEu75Z2Leb4aH8)
Yzbm7Ac4eMKHP1IN,N2XRVI1Hvrxkqsf,TxODKvyAwqVmChU7uorLpb=EgfwLDcJihvey15uMZCFX,EgfwLDcJihvey15uMZCFX,EgfwLDcJihvey15uMZCFX
QLx6cm8dzDCTZu,D4jmQZsoUPaiNw0qIgvyc25f,O9CJ8IX2A0lETWjitaR4zDdecpF=TxODKvyAwqVmChU7uorLpb,N2XRVI1Hvrxkqsf,Yzbm7Ac4eMKHP1IN
R74r6CnPX2Z,ppjqJgVNFk6X1CKn9y2OId7iEauQ,FB0Cu4XTDcfej=O9CJ8IX2A0lETWjitaR4zDdecpF,D4jmQZsoUPaiNw0qIgvyc25f,QLx6cm8dzDCTZu
ZW18wiTteB,mgor3Abi2usncVGhZL1Tj4l,kpxe489EMs62QPWcfh=FB0Cu4XTDcfej,ppjqJgVNFk6X1CKn9y2OId7iEauQ,R74r6CnPX2Z
BRQKJfySTC6iAVLG3OmZg,DDr5LXIpStcnBh9PbuZeCsgzQyG,Is7DRMACaum=kpxe489EMs62QPWcfh,mgor3Abi2usncVGhZL1Tj4l,ZW18wiTteB
QAfCnxOo24YtPgsa0m,yMtnXxSiTUzGWsdj,Sn3ayo5TFewbZ0irDxlKXq=Is7DRMACaum,DDr5LXIpStcnBh9PbuZeCsgzQyG,BRQKJfySTC6iAVLG3OmZg
eUxsukE2tw8ZJpP,deK3Yn6i1HRsrcw4EZD0LP,iHld5wa1jvpz4MGoXYxUcfRF3=Sn3ayo5TFewbZ0irDxlKXq,yMtnXxSiTUzGWsdj,QAfCnxOo24YtPgsa0m
AT4PsXD6Ixjpaekwz9F,wxD5lWH8qrampQBPogLbNe6nA,FG4WcEa5QSU3vLmyC6jM8VqsOedH=iHld5wa1jvpz4MGoXYxUcfRF3,deK3Yn6i1HRsrcw4EZD0LP,eUxsukE2tw8ZJpP
NybQeHvRAqcYmhDIfaiFZXojGC,xoJviS1Me3,ffmzRlOHcBPQA69=FG4WcEa5QSU3vLmyC6jM8VqsOedH,wxD5lWH8qrampQBPogLbNe6nA,AT4PsXD6Ixjpaekwz9F
ewJh3POUpynEdfzoc7MAT,uerm1H6NcpkDCt7z,HmRBJqA8UWO=ffmzRlOHcBPQA69,xoJviS1Me3,NybQeHvRAqcYmhDIfaiFZXojGC
iZq9QbCeJIlgO8W3kd5,PvOcZ491qRi0I,yyaY8SpZq4WFmPuEd2sk0T=HmRBJqA8UWO,uerm1H6NcpkDCt7z,ewJh3POUpynEdfzoc7MAT
import xbmc as BeLDhTt1GQ,xbmcgui as nCHrJksfEtu8Zhe10M,sys as pVy8J6XAkqmrvzRe7,os as bSRUZEN7dHJia2LBG6ejvTCg0zcs,requests as zzYxuOi0BtXdMP72kFsGfJ,re as CJV0WXMAywKY5x2c6qbSf,xbmcvfs as m2ZubSXxTeGpiC6,base64 as YX8rhpG6jO4z97I3APqe210sMKcimt,time as ZsKpyUT9rfLm4EW
aJNqSlf6rx9yguWK7IF = QAfCnxOo24YtPgsa0m(u"ࠫࠬࠀ")
def zJryU4fnuW8L90IFGNT1a5qvtjCY(request):
	krtTu4IaAfBiSnChOY3 = PvOcZ491qRi0I(u"ࠬࡨࡵࡴࡻࡧ࡭ࡦࡲ࡯ࡨࡰࡲࡧࡦࡴࡣࡦ࡮ࠪࠁ")
	if request==AT4PsXD6Ixjpaekwz9F(u"࠭ࡳࡵࡣࡵࡸࠬࠂ"): BeLDhTt1GQ.executebuiltin(iZq9QbCeJIlgO8W3kd5(u"ࠧࡂࡥࡷ࡭ࡻࡧࡴࡦ࡙࡬ࡲࡩࡵࡷࠩࠩࠃ")+krtTu4IaAfBiSnChOY3+Yzbm7Ac4eMKHP1IN(u"ࠨࠫࠪࠄ"))
	elif request==D4jmQZsoUPaiNw0qIgvyc25f(u"ࠩࡶࡸࡴࡶࠧࠅ"): BeLDhTt1GQ.executebuiltin(AT4PsXD6Ixjpaekwz9F(u"ࠪࡈ࡮ࡧ࡬ࡰࡩ࠱ࡇࡱࡵࡳࡦࠪࠪࠆ")+krtTu4IaAfBiSnChOY3+yMtnXxSiTUzGWsdj(u"ࠫ࠮࠭ࠇ"))
	return
def LXwpPu652WKdR8(akTfGdVMPmlCExOWRiL8unJrpIv,GiLnpK3osa5QVkdqY8ROC9U,mZd5WDLgA3sHQvCOF9KM1xaBoGlteU,KgjbOSi5YxdNfQXhrWvoU3,text):
	if not GiLnpK3osa5QVkdqY8ROC9U: GiLnpK3osa5QVkdqY8ROC9U = uerm1H6NcpkDCt7z(u"้ࠬไศࠩࠈ")
	if not mZd5WDLgA3sHQvCOF9KM1xaBoGlteU: mZd5WDLgA3sHQvCOF9KM1xaBoGlteU = ffmzRlOHcBPQA69(u"࠭ๆฺ็ࠪࠉ")
	if not KgjbOSi5YxdNfQXhrWvoU3: KgjbOSi5YxdNfQXhrWvoU3 = mgor3Abi2usncVGhZL1Tj4l(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪࠊ")
	if L4wJHOS27TXd1: qqWFcNPf5yHxGUudj8JDrMLabARpw = nCHrJksfEtu8Zhe10M.Dialog().yesno(KgjbOSi5YxdNfQXhrWvoU3,text,aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,GiLnpK3osa5QVkdqY8ROC9U,mZd5WDLgA3sHQvCOF9KM1xaBoGlteU)
	else: qqWFcNPf5yHxGUudj8JDrMLabARpw = nCHrJksfEtu8Zhe10M.Dialog().yesno(KgjbOSi5YxdNfQXhrWvoU3,text,GiLnpK3osa5QVkdqY8ROC9U,mZd5WDLgA3sHQvCOF9KM1xaBoGlteU)
	return qqWFcNPf5yHxGUudj8JDrMLabARpw
def rrlmsg7HkZTpK(akTfGdVMPmlCExOWRiL8unJrpIv,xicFAG3Mv0lh1JrOe,KgjbOSi5YxdNfQXhrWvoU3,text):
	if not KgjbOSi5YxdNfQXhrWvoU3: KgjbOSi5YxdNfQXhrWvoU3 = wxD5lWH8qrampQBPogLbNe6nA(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫࠋ")
	return nCHrJksfEtu8Zhe10M.Dialog().ok(KgjbOSi5YxdNfQXhrWvoU3,text)
def LIhWQ93vfyxZV6G8M4r1RwC(KgjbOSi5YxdNfQXhrWvoU3=xoJviS1Me3(u"ࠩ็์าฯࠠศๆ่ๅฬะ๊ฮࠩࠌ"),SgDR6PQY38waBFZVW7ALEnoJue=aJNqSlf6rx9yguWK7IF):
	tMWNBiksAdyhJDV7O2Fcrl4QwUXpYL = nCHrJksfEtu8Zhe10M.Dialog().input(KgjbOSi5YxdNfQXhrWvoU3,SgDR6PQY38waBFZVW7ALEnoJue,type=nCHrJksfEtu8Zhe10M.INPUT_ALPHANUM)
	tMWNBiksAdyhJDV7O2Fcrl4QwUXpYL = tMWNBiksAdyhJDV7O2Fcrl4QwUXpYL.strip(NybQeHvRAqcYmhDIfaiFZXojGC(u"ࠪࠤࠬࠍ")).replace(AT4PsXD6Ixjpaekwz9F(u"ࠫࠥࠦࠠࠡࠩࠎ"),ppjqJgVNFk6X1CKn9y2OId7iEauQ(u"ࠬࠦࠧࠏ")).replace(N2XRVI1Hvrxkqsf(u"࠭ࠠࠡࠢࠪࠐ"),yMtnXxSiTUzGWsdj(u"ࠧࠡࠩࠑ")).replace(iZq9QbCeJIlgO8W3kd5(u"ࠨࠢࠣࠫࠒ"),Yzbm7Ac4eMKHP1IN(u"ࠩࠣࠫࠓ"))
	return tMWNBiksAdyhJDV7O2Fcrl4QwUXpYL
def OJeBTQhj4m(Q9QLeWU8OAGfnFavRCr):
	qqWFcNPf5yHxGUudj8JDrMLabARpw = LXwpPu652WKdR8(aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,N2XRVI1Hvrxkqsf(u"ࠪๆอ๊ࠠฦำึห้ࠦำอๆࠣห้ษฮุษฤࠤ๏าศࠡล้ࠤฯฺฺๅࠢหี๋อๅอࠢ฼้ฬี้ࠠฬ้ฮ฽ืࠠฮฬ์ࠤฯ฾็าࠢ็็ࠥอไๆึส็้่ࠦศๆฦา฼อมࠡ࠰࠱ࠤ฾์ฯ่ษࠣื๏่่ๆࠢๆ์ิ๐ࠠษฬึะ๏๊่ࠠา๊ࠤฬ๊ๅีษๆ่ࠥ๎วๅลั฻ฬวࠠโ์ࠣืั๊ࠠศๆฦา฼อมࠡ࠰࠱ࠤํฮูะ้สࠤ็๋ࠠษวิืฬ๊ࠠิฮ็ࠤฬ๊รฯูสล๊ࠥไๆสิ้ัࠦ࠮࠯๊่ࠢࠥะั๋ัࠣห้ศๆࠡวิืฬ๊ࠠิฮ็ࠤฬ๊รฯูสลࠥหไ๊ࠢส่๊ฮัๆฮࠣรࠦ࠭ࠔ"))
	if qqWFcNPf5yHxGUudj8JDrMLabARpw!=ppjqJgVNFk6X1CKn9y2OId7iEauQ(u"࠱ࢫ"): return
	if not bSRUZEN7dHJia2LBG6ejvTCg0zcs.path.exists(Q9QLeWU8OAGfnFavRCr):
		rrlmsg7HkZTpK(aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,ewJh3POUpynEdfzoc7MAT(u"้๊ࠫริใࠣ࠲࠳ࠦำอๆࠣห้ษฮุษฤࠤ฿๐ัࠡ็๋ะํีࠠฤู๊้๊่ࠣฮࠩࠕ"))
		return
	message = LIhWQ93vfyxZV6G8M4r1RwC(NybQeHvRAqcYmhDIfaiFZXojGC(u"ࠬษใหสࠣีุอไหๅࠣห้ะ๊ࠡฬิ๎ิࠦลาีส่์อࠠๆ฻ࠣืั๊ࠠศๆฦา฼อมࠨࠖ"))
	GY4biQXN6udqPJHzKV = BeLDhTt1GQ.getInfoLabel(HmRBJqA8UWO(u"࠭ࡓࡺࡵࡷࡩࡲ࠴ࡁࡥࡦࡲࡲ࡛࡫ࡲࡴ࡫ࡲࡲ࠭࠭ࠗ")+qJAcO6K9Z5mutLgNakdREQHnS2p3b+HmRBJqA8UWO(u"ࠧࠪࠩ࠘"))
	file = open(Q9QLeWU8OAGfnFavRCr,yMtnXxSiTUzGWsdj(u"ࠨࡴࡥࠫ࠙"))
	ObXGELvMAksI8xP6yYC = bSRUZEN7dHJia2LBG6ejvTCg0zcs.path.getsize(Q9QLeWU8OAGfnFavRCr)
	if ObXGELvMAksI8xP6yYC>iHld5wa1jvpz4MGoXYxUcfRF3(u"࠴࠲࠴࠴࠵࠶ࢬ"): file.seek(-iHld5wa1jvpz4MGoXYxUcfRF3(u"࠴࠲࠴࠴࠵࠶ࢬ"),bSRUZEN7dHJia2LBG6ejvTCg0zcs.SEEK_END)
	data = file.read()
	file.close()
	data = data.decode(deK3Yn6i1HRsrcw4EZD0LP(u"ࠩࡸࡸ࡫࠾ࠧࠚ"))
	cnvDIzCXUOkNubxP = CJV0WXMAywKY5x2c6qbSf.findall(TxODKvyAwqVmChU7uorLpb(u"ࠥࠫࡺࡹࡥࡳࡡ࡬ࡨࠬࡀࠠࠨࠪ࠱࠮ࡄ࠯ࠧࠣࠛ"),data,CJV0WXMAywKY5x2c6qbSf.DOTALL)
	if not cnvDIzCXUOkNubxP: cnvDIzCXUOkNubxP = CJV0WXMAywKY5x2c6qbSf.findall(ewJh3POUpynEdfzoc7MAT(u"ࠦࠬࡻࡳࡦࡴࠪ࠾ࠥ࠭ࠨ࠯ࠬࡂ࠭ࠬࠨࠜ"),data,CJV0WXMAywKY5x2c6qbSf.DOTALL)
	if not cnvDIzCXUOkNubxP: cnvDIzCXUOkNubxP = CJV0WXMAywKY5x2c6qbSf.findall(R74r6CnPX2Z(u"ࠬࡢࡤࡼ࠶ࢀ࠱ࡡࡪࡻ࠵ࡿ࠰ࡠࡩࢁ࠴ࡾ࠯࡟ࡨࢀ࠺ࡽ࠮࡞ࡧࡿ࠹ࢃࠧࠝ"),data,CJV0WXMAywKY5x2c6qbSf.DOTALL)
	cnvDIzCXUOkNubxP = cnvDIzCXUOkNubxP[iZq9QbCeJIlgO8W3kd5(u"࠲ࢭ")] if cnvDIzCXUOkNubxP else deK3Yn6i1HRsrcw4EZD0LP(u"࠭࠰࠱࠲࠳ࠫࠞ")
	cnvDIzCXUOkNubxP = cnvDIzCXUOkNubxP.split(Yzbm7Ac4eMKHP1IN(u"ࠧ࡝ࡰࠪࠟ"),Yzbm7Ac4eMKHP1IN(u"࠴ࢮ"))[FG4WcEa5QSU3vLmyC6jM8VqsOedH(u"࠴ࢯ")]
	if L4wJHOS27TXd1: cnvDIzCXUOkNubxP = cnvDIzCXUOkNubxP.encode(NybQeHvRAqcYmhDIfaiFZXojGC(u"ࠨࡷࡷࡪ࠽࠭ࠠ"))
	NAoHD9JvtT50sM64ERLQI = mgor3Abi2usncVGhZL1Tj4l(u"ࠩࡄ࡚࠿ࠦࠧࠡ")+cnvDIzCXUOkNubxP+uerm1H6NcpkDCt7z(u"ࠪ࠱ࡊࡳࡥࡳࡩࡨࡲࡨࡿࠧࠢ")
	message += iHld5wa1jvpz4MGoXYxUcfRF3(u"ࠫࡡࡴ࡜࡯࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࡞ࡱࡉࡲࡧࡩ࡭ࠢࡖࡩࡳࡪࡥࡳ࠼ࠣࠫࠣ")+cnvDIzCXUOkNubxP+FG4WcEa5QSU3vLmyC6jM8VqsOedH(u"ࠬࠦ࠺ࠨࠤ")+D4jmQZsoUPaiNw0qIgvyc25f(u"࠭࡜࡯ࠩࠥ")+ZW18wiTteB(u"ࠧࡂࡦࡧࡳࡳࠦࡖࡦࡴࡶ࡭ࡴࡴ࠺ࠡࠩࠦ")+GY4biQXN6udqPJHzKV+deK3Yn6i1HRsrcw4EZD0LP(u"ࠨࠢ࠽ࡠࡳ࠭ࠧ")
	data = data.encode(O9CJ8IX2A0lETWjitaR4zDdecpF(u"ࠩࡸࡸ࡫࠾ࠧࠨ"))
	GgP7hbQ9jYOvTWI3tV6r = YX8rhpG6jO4z97I3APqe210sMKcimt.b64encode(data)
	NN568KqEpUrDeFYJbsdXk = {PvOcZ491qRi0I(u"ࠪࡷࡺࡨࡪࡦࡥࡷࠫࠩ"):NAoHD9JvtT50sM64ERLQI,TxODKvyAwqVmChU7uorLpb(u"ࠫࡲ࡫ࡳࡴࡣࡪࡩࠬࠪ"):message,QLx6cm8dzDCTZu(u"ࠬࡲ࡯ࡨࡨ࡬ࡰࡪ࠭ࠫ"):GgP7hbQ9jYOvTWI3tV6r}
	cvMk1HGFA50sWVILYdnf = mgor3Abi2usncVGhZL1Tj4l(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵ࡳࡦࡰࡧࡩࡲࡧࡩ࡭ࠩࠬ")
	ccbsrz39MEaAk4S2veFPJoXOtl7Z = zzYxuOi0BtXdMP72kFsGfJ.request(HmRBJqA8UWO(u"ࠧࡑࡑࡖࡘࠬ࠭"),cvMk1HGFA50sWVILYdnf,data=NN568KqEpUrDeFYJbsdXk)
	if ccbsrz39MEaAk4S2veFPJoXOtl7Z.status_code==ewJh3POUpynEdfzoc7MAT(u"࠷࠶࠰ࢰ"): rrlmsg7HkZTpK(aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,R74r6CnPX2Z(u"ࠨฮํำࠥ࠴࠮่ࠡฯัฯูࠦๆๆํอࠥหัิษ็ࠤุาไࠡษ็วำ฽วยࠩ࠮"))
	else: rrlmsg7HkZTpK(aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,ewJh3POUpynEdfzoc7MAT(u"ࠩ็่ศูแࠡ࠰࠱ࠤๆฺไหࠢ฼้้๐ษࠡวิืฬ๊ࠠิฮ็ࠤฬ๊รฯูสลࠬ࠯"))
	return
def Z8a1Xv6NxHGWIh():
	qqWFcNPf5yHxGUudj8JDrMLabARpw = LXwpPu652WKdR8(aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,TxODKvyAwqVmChU7uorLpb(u"้้ࠪ็ࠠฦ฻าหิอสࠡษ็ฬึ์วๆฮࠣ๎าะ่๋ࠢ฼่๎ࠦๅฺๆ๋้ฬะࠠหะุࠤฯำฯ๋อࠣห้ฮั็ษ่ะࠥ๎ส็ฺํ้ࠥ฿ๅๅࠢส่อืๆศ็ฯࠤ࠳࠴ฺ่ࠠาࠤู๊อ้ࠡำหࠥอไๆๆไࠤุ๐โ้็ࠣห้ฮั็ษ่ะࠥฮฮๅไ้้ࠣ็ࠠอัํำࠥ็วา฼ࠣ࠲࠳ࠦ็ๅࠢอี๏ีࠠศๆล๊๋ࠥำฮ่่ࠢๆࠦลฺัสำฬะࠠศๆหี๋อๅอࠢยࠥࠬ࠰"))
	if qqWFcNPf5yHxGUudj8JDrMLabARpw!=xoJviS1Me3(u"࠷ࢱ"): return
	emCV95HEQh = te3SO8kRYUVipbW51H7a(Np6QT8rzHJ73ESoxt2IFX5BlsAKg,ZW18wiTteB(u"ࡌࡡ࡭ࡵࡨࣆ"))
	if emCV95HEQh: rrlmsg7HkZTpK(aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,wxD5lWH8qrampQBPogLbNe6nA(u"ࠫั๐ฯࠡ࠰࠱ࠤ๋าอหࠢ฼้้๐ษࠡ็ึั๋ࠥไโࠢศ฽ิอฯศฬࠣฬึ์วๆฮࠣ฽๊อฯࠡๆ็ๅ๏ี๊้้สฮࠥอไฺำห๎ฮ࠭࠱"))
	else: rrlmsg7HkZTpK(aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,N2XRVI1Hvrxkqsf(u"๊ࠬไฤีไࠤ࠳࠴ࠠโึ็ฮࠥ฿ๅๅ์ฬࠤู๊อࠡ็็ๅࠥหูะษาหฯࠦศา่ส้ัูࠦๆษาࠤ้๊แ๋ัํ์์อสࠡษ็฽ึฮ๊สࠩ࠲"))
	return
def x1Qf93owGnVTFvL():
	qqWFcNPf5yHxGUudj8JDrMLabARpw = LXwpPu652WKdR8(aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,N2XRVI1Hvrxkqsf(u"࠭ๅอๆาࠤ่อิࠡษ็ฬึ์วๆฮࠣ๎าะ่๋ࠢ฼่๎ࠦๅๅใสฮࠥะฮึࠢอ๊฽๐ๅࠡ฻่่ࠥอไษำ้ห๊าࠠๆอ็ࠤ๊๊แศฬࠣห้๋แืๆฬࠤํ๋ไโษอࠤࡎࡖࡔࡗ๋ࠢࠤࡒ࠹ࡕุ๊ࠡ์ึࠦวๅไ๋หห๋ࠠ࠯࠰ࠣ฽๋ีࠠๆีะࠤ์ึวࠡษ็้ั๊ฯࠡีํๆํ๋ࠠศๆหี๋อๅอࠢหา้่ࠠๆฮ็ำࠥาฯ๋ัࠣๅฬืฺࠡ࠰࠱ࠤ์๊ࠠหำํำࠥอไรุ่้ࠣำࠠๆฮ็ำ้ࠥวีࠢส่อืๆศ็ฯࠤฤࠧࠧ࠳"))
	if qqWFcNPf5yHxGUudj8JDrMLabARpw!=kpxe489EMs62QPWcfh(u"࠱ࢲ"): return
	emCV95HEQh = n9AlW7Kt4Bb2i(St0CsQUm8xzlj6ZY,wxD5lWH8qrampQBPogLbNe6nA(u"ࡕࡴࡸࡩࣈ"),wxD5lWH8qrampQBPogLbNe6nA(u"ࡕࡴࡸࡩࣈ"),QLx6cm8dzDCTZu(u"ࡆࡢ࡮ࡶࡩࣇ"))
	if emCV95HEQh: rrlmsg7HkZTpK(aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,QLx6cm8dzDCTZu(u"ࠧอ์าࠤ࠳࠴ࠠ็ฮะฮࠥ฿ๅๅ์ฬࠤู๊อࠡ็ฯ่ิࠦใศึࠣห้ฮั็ษ่ะࠬ࠴"))
	else: rrlmsg7HkZTpK(aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,QLx6cm8dzDCTZu(u"ࠨๆ็วุ็ࠠ࠯࠰ࠣๅู๊สࠡ฻่่๏ฯࠠๆีะࠤ๊าไะࠢๆหูࠦวๅสิ๊ฬ๋ฬࠨ࠵"))
	return
def te3SO8kRYUVipbW51H7a(Uf1BX4hApbsMxL3iu6,YeqJH6PfTOkw2jAL0ZRXcbSo):
	emCV95HEQh = Sn3ayo5TFewbZ0irDxlKXq(u"ࡖࡵࡹࡪࣉ")
	if YeqJH6PfTOkw2jAL0ZRXcbSo:
		qqWFcNPf5yHxGUudj8JDrMLabARpw = LXwpPu652WKdR8(aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,yyaY8SpZq4WFmPuEd2sk0T(u"่่ࠩๆࠦลฺัสำฬะࠠศๆหี๋อๅอࠢํัฯ๎๊ࠡ฻็ํู๋ࠥๅ๊่หฯࠦสฯืࠣฮาี๊ฬࠢส่อืๆศ็ฯࠤํะๆู์่ࠤ฾๋ไࠡษ็ฬึ์วๆฮࠣ࠲࠳ูࠦ็ัุ้ࠣำ่ࠠาสࠤฬ๊ๅๅใࠣื๏่่ๆࠢส่อืๆศ็ฯࠤอิไใ่่ࠢๆࠦฬะ์าࠤๆอั฻ࠢ࠱࠲ࠥํไࠡฬิ๎ิࠦวๅฤ้ࠤู๊อࠡ็็ๅࠥหูะษาหฯࠦวๅสิ๊ฬ๋ฬࠡมࠤࠫ࠶"))
		if qqWFcNPf5yHxGUudj8JDrMLabARpw!=iZq9QbCeJIlgO8W3kd5(u"࠲ࢳ"): return
	if bSRUZEN7dHJia2LBG6ejvTCg0zcs.path.exists(Uf1BX4hApbsMxL3iu6):
		try: bSRUZEN7dHJia2LBG6ejvTCg0zcs.remove(Uf1BX4hApbsMxL3iu6)
		except Exception as lBmkMZDoWN2ycOqEjVLx:
			emCV95HEQh = ffmzRlOHcBPQA69(u"ࡉࡥࡱࡹࡥ࣊")
			if YeqJH6PfTOkw2jAL0ZRXcbSo: rrlmsg7HkZTpK(aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,str(lBmkMZDoWN2ycOqEjVLx))
	if YeqJH6PfTOkw2jAL0ZRXcbSo:
		if emCV95HEQh: rrlmsg7HkZTpK(aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,deK3Yn6i1HRsrcw4EZD0LP(u"ࠪะ๏ีࠠ࠯࠰๊ࠣัำสࠡ฻่่๏ฯࠠศๆ่ืา࠭࠷"))
		else: rrlmsg7HkZTpK(aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,uerm1H6NcpkDCt7z(u"้๊ࠫริใࠣ࠲࠳ࠦแีๆอࠤ฾๋ไ๋หࠣห้๋ำฮࠩ࠸"))
	return emCV95HEQh
def n9AlW7Kt4Bb2i(pWSjoMYZXdULutkc,LoN1FUkcWYjgpR7JMfXa4rn2qC0,iHQmacSO0rFZUGlM4,YeqJH6PfTOkw2jAL0ZRXcbSo):
	emCV95HEQh = xoJviS1Me3(u"ࡘࡷࡻࡥ࣋")
	if YeqJH6PfTOkw2jAL0ZRXcbSo:
		qqWFcNPf5yHxGUudj8JDrMLabARpw = LXwpPu652WKdR8(aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,pWSjoMYZXdULutkc+ZW18wiTteB(u"ࠬࡢ࡮࡝ࡰ๊่ࠥะั๋ัุ้ࠣำ่ࠠาสࠤฬ๊ๅอๆาࠤฤࠧࠧ࠹"))
		if qqWFcNPf5yHxGUudj8JDrMLabARpw!=O9CJ8IX2A0lETWjitaR4zDdecpF(u"࠳ࢴ"): return
	if bSRUZEN7dHJia2LBG6ejvTCg0zcs.path.exists(pWSjoMYZXdULutkc):
		for kc8yuYRSbx6rL4h3iCenZqG0dMXF,EOSN42xs8zQZpWRed6h,IpGHJ5yRxNXPew9nShg40O2drs in bSRUZEN7dHJia2LBG6ejvTCg0zcs.walk(pWSjoMYZXdULutkc,topdown=Is7DRMACaum(u"ࡋࡧ࡬ࡴࡧ࣌")):
			for zQI1mytluM3fPqxUgV9bejNnO in IpGHJ5yRxNXPew9nShg40O2drs:
				vCO37XBmhV1qG2KYjtaLQ = bSRUZEN7dHJia2LBG6ejvTCg0zcs.path.join(kc8yuYRSbx6rL4h3iCenZqG0dMXF,zQI1mytluM3fPqxUgV9bejNnO)
				try: bSRUZEN7dHJia2LBG6ejvTCg0zcs.remove(vCO37XBmhV1qG2KYjtaLQ)
				except Exception as lBmkMZDoWN2ycOqEjVLx:
					emCV95HEQh = iHld5wa1jvpz4MGoXYxUcfRF3(u"ࡌࡡ࡭ࡵࡨ࣍")
					if YeqJH6PfTOkw2jAL0ZRXcbSo: rrlmsg7HkZTpK(aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,str(lBmkMZDoWN2ycOqEjVLx))
			if LoN1FUkcWYjgpR7JMfXa4rn2qC0:
				for A5RITBUCj208uemGtlSV in EOSN42xs8zQZpWRed6h:
					fN1J74aXQRZjt2puYHq3vB = bSRUZEN7dHJia2LBG6ejvTCg0zcs.path.join(kc8yuYRSbx6rL4h3iCenZqG0dMXF,A5RITBUCj208uemGtlSV)
					try: bSRUZEN7dHJia2LBG6ejvTCg0zcs.rmdir(fN1J74aXQRZjt2puYHq3vB)
					except: pass
		if iHQmacSO0rFZUGlM4:
			try: bSRUZEN7dHJia2LBG6ejvTCg0zcs.rmdir(kc8yuYRSbx6rL4h3iCenZqG0dMXF)
			except: pass
	if YeqJH6PfTOkw2jAL0ZRXcbSo:
		if emCV95HEQh: rrlmsg7HkZTpK(aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,yyaY8SpZq4WFmPuEd2sk0T(u"࠭ฬ๋ัࠣ࠲࠳ࠦๆอฯอࠤ฾๋ไ๋หࠣห้๋ำฮࠩ࠺"))
		else: rrlmsg7HkZTpK(aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,kpxe489EMs62QPWcfh(u"ࠧๅๆฦืๆࠦ࠮࠯ࠢไุ้ะฺࠠ็็๎ฮࠦวๅ็ึัࠬ࠻"))
	return emCV95HEQh
def Dp0s9PTHrhSzI3A():
	qqWFcNPf5yHxGUudj8JDrMLabARpw = LXwpPu652WKdR8(aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,QAfCnxOo24YtPgsa0m(u"ࠨ็ฯ่ิࠦี้ำࠣ็ฯอศสࠢส่็๎วว็ࠣ࠲࠳ࠦ็ัษࠣห้๋ฬๅัࠣๅ๏ํࠠษ฻ูࠤ็๎วว็ࠣห้ฮั็ษ่ะ๋ࠥฮำ่ฬࠤอฺใๅุࠢ์ึࠦศะๆสࠤ๊์ࠠศๆๆฮฬฮษࠡ࠰࠱ࠤ฾์ฯࠡ็ึัࠥอไๆฮ็ำู๊ࠥใ๊่ࠤฬ๊ศา่ส้ัࠦศฯๆๅࠤ๊าไะࠢฯำ๏ี้ࠠ์หำศࠦๅาหࠣวำื้ࠡส่่หํࠠษษ็ูํืฺ่ࠠาࠤๆะอࠡษ็ๆํอฦๆࠢ࠱࠲ࠥํไࠡฬิ๎ิࠦวๅฤ้ࠤู๊อࠡ็ฯ่ิࠦี้ำࠣ็ฯอศสࠢๅ์ฬฬๅࠡษ็ฬึ์วๆฮࠣรࠦ࠭࠼"))
	if qqWFcNPf5yHxGUudj8JDrMLabARpw!=wxD5lWH8qrampQBPogLbNe6nA(u"࠴ࢵ"): return
	emCV95HEQh = n9AlW7Kt4Bb2i(Zdl82RVWFU93SJIt0Nq6PCDOeT,ewJh3POUpynEdfzoc7MAT(u"ࡕࡴࡸࡩ࣏"),R74r6CnPX2Z(u"ࡆࡢ࡮ࡶࡩ࣎"),ewJh3POUpynEdfzoc7MAT(u"ࡕࡴࡸࡩ࣏"))
	if emCV95HEQh: rrlmsg7HkZTpK(aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,yMtnXxSiTUzGWsdj(u"ࠩฯ๎ิࠦ࠮࠯้ࠢะาะฺࠠ็็๎ฮࠦๅิฯ้ࠣั๊ฯࠡื๋ี้ࠥสศสฬࠤฬ๊โ้ษษ้ࠬ࠽"))
	else: rrlmsg7HkZTpK(aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,Is7DRMACaum(u"่้ࠪษำโࠢ࠱࠲ࠥ็ิๅฬࠣ฽๊๊๊ส่ࠢืาࠦๅอๆาࠤฺ๎ัࠡๅอหอฯࠠศๆๅ์ฬฬๅࠨ࠾"))
	return
def GrguZjlFeqQhWOzC():
	cvMk1HGFA50sWVILYdnf = eUxsukE2tw8ZJpP(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡴࡷࡵ࡫ࡪ࠴ࡳࡩ࠱࡮ࡳࡩ࡯࠯ࡦ࡯ࡤࡨࡤࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶ࠳ࡴࡲࡤ࠰࡫ࡱࡨࡪࡾ࠮ࡩࡶࡰࡰࠬ࠿")
	ccbsrz39MEaAk4S2veFPJoXOtl7Z = zzYxuOi0BtXdMP72kFsGfJ.request(xoJviS1Me3(u"ࠬࡍࡅࡕࠩࡀ"),cvMk1HGFA50sWVILYdnf)
	hLJgMC5qrB1OjiQ76Re = ccbsrz39MEaAk4S2veFPJoXOtl7Z.content
	hLJgMC5qrB1OjiQ76Re = hLJgMC5qrB1OjiQ76Re.decode(FG4WcEa5QSU3vLmyC6jM8VqsOedH(u"࠭ࡵࡵࡨ࠻ࠫࡁ"))
	IpGHJ5yRxNXPew9nShg40O2drs = CJV0WXMAywKY5x2c6qbSf.findall(D4jmQZsoUPaiNw0qIgvyc25f(u"ࠧࡩࡴࡨࡪࡂࠨࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࠮࠮ࠫࡁࠬ࠲ࡿ࡯ࡰࠣࠩࡂ"),hLJgMC5qrB1OjiQ76Re,CJV0WXMAywKY5x2c6qbSf.DOTALL)
	IpGHJ5yRxNXPew9nShg40O2drs = sorted(IpGHJ5yRxNXPew9nShg40O2drs,reverse=D4jmQZsoUPaiNw0qIgvyc25f(u"ࡖࡵࡹࡪ࣐"))
	QfIvHnPxDy1FlGqR = nCHrJksfEtu8Zhe10M.Dialog().select(DDr5LXIpStcnBh9PbuZeCsgzQyG(u"ࠨษัฮึࠦวๅวุำฬืࠠศๆำ๎ࠥะั๋ัࠣฮะฮ๊ห้ࠪࡃ"),IpGHJ5yRxNXPew9nShg40O2drs)
	if QfIvHnPxDy1FlGqR==-kpxe489EMs62QPWcfh(u"࠵ࢶ"): return
	filename = IpGHJ5yRxNXPew9nShg40O2drs[QfIvHnPxDy1FlGqR]
	if L4wJHOS27TXd1: filename = filename.encode(ffmzRlOHcBPQA69(u"ࠩࡸࡸ࡫࠾ࠧࡄ"))
	zz6IXuohjAkZy = cvMk1HGFA50sWVILYdnf.rsplit(NybQeHvRAqcYmhDIfaiFZXojGC(u"ࠪ࠳ࠬࡅ"),yyaY8SpZq4WFmPuEd2sk0T(u"࠶ࢷ"))[AT4PsXD6Ixjpaekwz9F(u"࠶ࢸ")]+kpxe489EMs62QPWcfh(u"ࠫ࠴࠭ࡆ")+NybQeHvRAqcYmhDIfaiFZXojGC(u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࠬࡇ")+filename+iHld5wa1jvpz4MGoXYxUcfRF3(u"࠭࠮ࡻ࡫ࡳࠫࡈ")
	emCV95HEQh = R74r6CnPX2Z(u"ࡉࡥࡱࡹࡥ࣑")
	ccbsrz39MEaAk4S2veFPJoXOtl7Z = zzYxuOi0BtXdMP72kFsGfJ.request(wxD5lWH8qrampQBPogLbNe6nA(u"ࠧࡈࡇࡗࠫࡉ"),zz6IXuohjAkZy)
	if ccbsrz39MEaAk4S2veFPJoXOtl7Z.status_code==yyaY8SpZq4WFmPuEd2sk0T(u"࠲࠱࠲ࢹ"):
		ZmBxJY0hbrevqjzIKG = ccbsrz39MEaAk4S2veFPJoXOtl7Z.content
		import zipfile as h7hBRozqc4Hb1DK,io as NN0DSwfhRvEJ8glPzZ
		VznFK8tTcM5yqkYUS9ilQ6JxwpZN = NN0DSwfhRvEJ8glPzZ.BytesIO(ZmBxJY0hbrevqjzIKG)
		n9AlW7Kt4Bb2i(e1hxXgFQr73o,R74r6CnPX2Z(u"࡙ࡸࡵࡦ࣓"),R74r6CnPX2Z(u"࡙ࡸࡵࡦ࣓"),kpxe489EMs62QPWcfh(u"ࡊࡦࡲࡳࡦ࣒"))
		lQMUYcsgr8PhziJ0TwvqnK1NIZVm = h7hBRozqc4Hb1DK.ZipFile(VznFK8tTcM5yqkYUS9ilQ6JxwpZN)
		lQMUYcsgr8PhziJ0TwvqnK1NIZVm.extractall(OQF4vD1l85gmaKdzrBZch0)
		ZsKpyUT9rfLm4EW.sleep(PvOcZ491qRi0I(u"࠲ࢺ"))
		BeLDhTt1GQ.executebuiltin(Sn3ayo5TFewbZ0irDxlKXq(u"ࠨࡗࡳࡨࡦࡺࡥࡍࡱࡦࡥࡱࡇࡤࡥࡱࡱࡷࠬࡊ"))
		ZsKpyUT9rfLm4EW.sleep(HmRBJqA8UWO(u"࠳ࢻ"))
		ddNVaO6n3lS2UirsMHoTm7v = BeLDhTt1GQ.executeJSONRPC(FG4WcEa5QSU3vLmyC6jM8VqsOedH(u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡃࡧࡨࡴࡴࡳ࠯ࡕࡨࡸࡆࡪࡤࡰࡰࡈࡲࡦࡨ࡬ࡦࡦࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡣࡧࡨࡴࡴࡩࡥࠤ࠽ࠦࠬࡋ")+qJAcO6K9Z5mutLgNakdREQHnS2p3b+ewJh3POUpynEdfzoc7MAT(u"ࠪࠦ࠱ࠨࡥ࡯ࡣࡥࡰࡪࡪࠢ࠻ࡶࡵࡹࡪࢃࡽࠨࡌ"))
		if DDr5LXIpStcnBh9PbuZeCsgzQyG(u"ࠫࡔࡑࠧࡍ") in ddNVaO6n3lS2UirsMHoTm7v: emCV95HEQh = O9CJ8IX2A0lETWjitaR4zDdecpF(u"࡚ࡲࡶࡧࣔ")
	if emCV95HEQh:
		rrlmsg7HkZTpK(aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,yMtnXxSiTUzGWsdj(u"ࠬา๊ะࠢ࠱࠲ࠥ์ฬฮฬࠣ฽๊๊๊สࠢอฯอ๐สࠡษ็ษฺีวาࠢส่็ี๊ๆࠢ࡟ࡲࡡࡴࠠࠨࡎ")+filename)
		msg = ffmzRlOHcBPQA69(u"࠭อห๋ࠣ๎อ่้ࠡษ็ษฺีวาࠢส่็ี๊ๆࠢไ๎ࠥา็ศิๆࠤํ๊วࠡ์อ้ࠥะอะ์ฮ๋ࠥษ่ห๊่หฯ๐ใ๋ษࠣ࠲࠳๊ࠦอสࠣว๋ࠦสใ๊่ࠤอห๊ใษไࠤฬ๊สฮัํฯࠥอไฤ๊อ์๊อส๋ๅํࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡษ็ฦ๋ࠦล๋ไสๅࠥอไหฯา๎ะࠦวๅล๋ฮํ๋วห์ๆ๎๊ࠥไษำ้ห๊าࠠภࠣࠪࡏ")
		eeo4p8iVvG(msg)
	else: rrlmsg7HkZTpK(aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,Is7DRMACaum(u"ࠧๅๆฦืๆࠦ࠮࠯ࠢไุ้ะฺࠠ็็๎ฮࠦสฬสํฮࠥอไฦืาหึࠦวๅไา๎๊ࠦ࡜࡯࡞ࡱࠤࠬࡐ")+filename)
	return
def eeo4p8iVvG(msg=QLx6cm8dzDCTZu(u"ࠨ้็ࠤฯื๊ะࠢอุ฿๐ไࠡล๋ࠤส๐โศใࠣห้ะอะ์ฮࠤฬ๊ร้ฬ๋้ฬะ๊ไ์่้ࠣฮั็ษ่ะࠥลࠡࠨࡑ")):
	qqWFcNPf5yHxGUudj8JDrMLabARpw = LXwpPu652WKdR8(aJNqSlf6rx9yguWK7IF,D4jmQZsoUPaiNw0qIgvyc25f(u"ࠩศ๎็อแࠡษ็ฮาี๊ฬࠩࡒ"),eUxsukE2tw8ZJpP(u"ࠪฮาี๊ฬࠢฦ์ฯ๎ๅศฬํ็๏࠭ࡓ"),aJNqSlf6rx9yguWK7IF,msg)
	if qqWFcNPf5yHxGUudj8JDrMLabARpw==-yMtnXxSiTUzGWsdj(u"࠴ࢼ"): return
	eT0CvQB9JZlaNwpM3Y = ffmzRlOHcBPQA69(u"ࠫࡪࡴࡡࡣ࡮ࡨࠫࡔ") if qqWFcNPf5yHxGUudj8JDrMLabARpw else iZq9QbCeJIlgO8W3kd5(u"ࠬࡪࡩࡴࡣࡥࡰࡪ࠭ࡕ")
	emCV95HEQh = ewJh3POUpynEdfzoc7MAT(u"ࡆࡢ࡮ࡶࡩࣕ")
	aYvcPxdWGuMR15Tg967 = Yzbm7Ac4eMKHP1IN(u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤࠨࡖ")
	txp62n9K3aEol0gUeTy = kpxe489EMs62QPWcfh(u"ࠧࡣ࡮ࡤࡧࡰࡲࡩࡴࡶࠪࡗ") if L4wJHOS27TXd1 else TxODKvyAwqVmChU7uorLpb(u"ࠨࡷࡳࡨࡦࡺࡥࡠࡴࡸࡰࡪࡹࠧࡘ")
	try:
		import sqlite3 as djbxOaITlRYyNCAirm6WvJHs83Kfo
		l5NfbV3iwtHZqTKQX4L0kpB = djbxOaITlRYyNCAirm6WvJHs83Kfo.connect(WF6cE9LvdyQDqiP53J)
		l5NfbV3iwtHZqTKQX4L0kpB.text_factory = str
		YY7QjaAeB4UNOqsTzF = l5NfbV3iwtHZqTKQX4L0kpB.cursor()
		YY7QjaAeB4UNOqsTzF.execute(ffmzRlOHcBPQA69(u"ࠩࡖࡉࡑࡋࡃࡕࠢࡲࡶ࡮࡭ࡩ࡯ࠢࡉࡖࡔࡓࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࡛ࠣࡍࡋࡒࡆࠢࡤࡨࡩࡵ࡮ࡊࡆࠣࡁࠥࠨ࡙ࠧ")+qJAcO6K9Z5mutLgNakdREQHnS2p3b+FG4WcEa5QSU3vLmyC6jM8VqsOedH(u"ࠪࠦࠥࡁ࡚ࠧ"))
		zTCIDjV8BXY9Lo = YY7QjaAeB4UNOqsTzF.fetchall()
		if zTCIDjV8BXY9Lo and aYvcPxdWGuMR15Tg967 not in str(zTCIDjV8BXY9Lo): YY7QjaAeB4UNOqsTzF.execute(NybQeHvRAqcYmhDIfaiFZXojGC(u"࡚ࠫࡖࡄࡂࡖࡈࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪࠠࡔࡇࡗࠤࡴࡸࡩࡨ࡫ࡱࠤࡂࠦࠢࠨ࡛")+aYvcPxdWGuMR15Tg967+NybQeHvRAqcYmhDIfaiFZXojGC(u"ࠬࠨࠠࡘࡊࡈࡖࡊࠦࡡࡥࡦࡲࡲࡎࡊࠠ࠾ࠢࠥࠫ࡜")+qJAcO6K9Z5mutLgNakdREQHnS2p3b+ZW18wiTteB(u"࠭ࠢࠡ࠽ࠪ࡝"))
		YY7QjaAeB4UNOqsTzF.execute(yyaY8SpZq4WFmPuEd2sk0T(u"ࠧࡔࡇࡏࡉࡈ࡚ࠠࠫࠢࡉࡖࡔࡓࠠࠨ࡞")+txp62n9K3aEol0gUeTy+HmRBJqA8UWO(u"ࠨ࡚ࠢࡌࡊࡘࡅࠡࡣࡧࡨࡴࡴࡉࡅࠢࡀࠤࠧ࠭࡟")+qJAcO6K9Z5mutLgNakdREQHnS2p3b+yMtnXxSiTUzGWsdj(u"ࠩࠥࠤࡀ࠭ࡠ"))
		zTCIDjV8BXY9Lo = YY7QjaAeB4UNOqsTzF.fetchall()
		jC7XPfq5sSGe0c1gNtLyMIpA9b3Wo = yyaY8SpZq4WFmPuEd2sk0T(u"ࡈࡤࡰࡸ࡫ࣗ") if zTCIDjV8BXY9Lo else ppjqJgVNFk6X1CKn9y2OId7iEauQ(u"ࡕࡴࡸࡩࣖ")
		if not jC7XPfq5sSGe0c1gNtLyMIpA9b3Wo and DDr5LXIpStcnBh9PbuZeCsgzQyG(u"ࠪࡩࡳࡧࡢ࡭ࡧࠪࡡ") in eT0CvQB9JZlaNwpM3Y: YY7QjaAeB4UNOqsTzF.execute(R74r6CnPX2Z(u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࠪࡢ")+txp62n9K3aEol0gUeTy+ewJh3POUpynEdfzoc7MAT(u"ࠬࠦࡗࡉࡇࡕࡉࠥࡧࡤࡥࡱࡱࡍࡉࠦ࠽ࠡࠤࠪࡣ")+qJAcO6K9Z5mutLgNakdREQHnS2p3b+ppjqJgVNFk6X1CKn9y2OId7iEauQ(u"࠭ࠢࠡ࠽ࠪࡤ"))
		elif jC7XPfq5sSGe0c1gNtLyMIpA9b3Wo and xoJviS1Me3(u"ࠧࡥ࡫ࡶࡥࡧࡲࡥࠨࡥ") in eT0CvQB9JZlaNwpM3Y:
			if L4wJHOS27TXd1: YY7QjaAeB4UNOqsTzF.execute(iHld5wa1jvpz4MGoXYxUcfRF3(u"ࠨࡋࡑࡗࡊࡘࡔࠡࡋࡑࡘࡔࠦࠧࡦ")+txp62n9K3aEol0gUeTy+uerm1H6NcpkDCt7z(u"ࠩࠣࠬࡦࡪࡤࡰࡰࡌࡈ࠮ࠦࡖࡂࡎࡘࡉࡘࠦࠨࠣࠩࡧ")+qJAcO6K9Z5mutLgNakdREQHnS2p3b+D4jmQZsoUPaiNw0qIgvyc25f(u"ࠪࠦ࠮ࠦ࠻ࠨࡨ"))
			else: YY7QjaAeB4UNOqsTzF.execute(NybQeHvRAqcYmhDIfaiFZXojGC(u"ࠫࡎࡔࡓࡆࡔࡗࠤࡎࡔࡔࡐࠢࠪࡩ")+txp62n9K3aEol0gUeTy+Is7DRMACaum(u"ࠬࠦࠨࡢࡦࡧࡳࡳࡏࡄ࠭ࡷࡳࡨࡦࡺࡥࡓࡷ࡯ࡩ࠮ࠦࡖࡂࡎࡘࡉࡘࠦࠨࠣࠩࡪ")+qJAcO6K9Z5mutLgNakdREQHnS2p3b+deK3Yn6i1HRsrcw4EZD0LP(u"࠭ࠢ࠭࠳ࠬࠤࡀ࠭࡫"))
		l5NfbV3iwtHZqTKQX4L0kpB.commit()
		l5NfbV3iwtHZqTKQX4L0kpB.close()
		emCV95HEQh = eUxsukE2tw8ZJpP(u"ࡗࡶࡺ࡫ࣘ")
	except: pass
	if emCV95HEQh:
		ZsKpyUT9rfLm4EW.sleep(FG4WcEa5QSU3vLmyC6jM8VqsOedH(u"࠵ࢽ"))
		BeLDhTt1GQ.executebuiltin(NybQeHvRAqcYmhDIfaiFZXojGC(u"ࠧࡖࡲࡧࡥࡹ࡫ࡌࡰࡥࡤࡰࡆࡪࡤࡰࡰࡶࠫ࡬"))
		ZsKpyUT9rfLm4EW.sleep(HmRBJqA8UWO(u"࠶ࢾ"))
		rrlmsg7HkZTpK(aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,D4jmQZsoUPaiNw0qIgvyc25f(u"ࠨฮํำࠥ࠴࠮่ࠡฯัฯࠦวๅ฻่่๏ฯࠧ࡭"))
	else: rrlmsg7HkZTpK(aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,xoJviS1Me3(u"ࠩ็่ศูแࠡ࠰࠱ࠤๆฺไหࠢส่฾๋ไ๋หࠪ࡮"))
	return
def sx8VQb9awzXP62tW5LHmG3R():
	qqWFcNPf5yHxGUudj8JDrMLabARpw = LXwpPu652WKdR8(aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,uerm1H6NcpkDCt7z(u"ࠪ฽๊๊๊สࠢอ๊฽๐แࠡๅ๋ำ๏ࠦสห็ࠣฬู๊อࠡษ็้้็วหࠢส่็ี๊ๆหࠣห้๋ฤใฬฬࠤฬ๊ส๋่ࠢฮัู๋สࠢไ๎๋ࠥฬๅัสฮࠥ๎ๅๅใสฮ้่ࠥะ์ࠣ࠲࠳ࠦ็ๅࠢอี๏ีࠠห่฻๎ๆࠦใ้ัํࠤฬ๊ย็ࠢยࠥࠬ࡯"))
	if qqWFcNPf5yHxGUudj8JDrMLabARpw!=O9CJ8IX2A0lETWjitaR4zDdecpF(u"࠷ࢿ"): return
	l5ygJF2AjNaqv79XdQ03YmDuc = n9AlW7Kt4Bb2i(ttNRDoYJbUkVT67,kpxe489EMs62QPWcfh(u"࡙ࡸࡵࡦࣚ"),xoJviS1Me3(u"ࡊࡦࡲࡳࡦࣙ"),xoJviS1Me3(u"ࡊࡦࡲࡳࡦࣙ"))
	EETU9MNvnjhOzRG46JDLq5rs7leatm = n9AlW7Kt4Bb2i(j3pKdqPvN0BRO,kpxe489EMs62QPWcfh(u"ࡔࡳࡷࡨࣜ"),iZq9QbCeJIlgO8W3kd5(u"ࡌࡡ࡭ࡵࡨࣛ"),iZq9QbCeJIlgO8W3kd5(u"ࡌࡡ࡭ࡵࡨࣛ"))
	eJ1aLYPUvbu = n9AlW7Kt4Bb2i(Fk8DzCm16QfaEIZo574V,Yzbm7Ac4eMKHP1IN(u"ࡖࡵࡹࡪࣞ"),uerm1H6NcpkDCt7z(u"ࡇࡣ࡯ࡷࡪࣝ"),uerm1H6NcpkDCt7z(u"ࡇࡣ࡯ࡷࡪࣝ"))
	W9dDROThgk = rrxAPqlpbmZ9c2LBiYhIC(uerm1H6NcpkDCt7z(u"ࡗࡶࡺ࡫ࣟ"))
	kjzHBhaP05xt9dIo3 = dLwMnKEYJhAiTvSPFBsom6Zp0()
	emCV95HEQh = all([l5ygJF2AjNaqv79XdQ03YmDuc,EETU9MNvnjhOzRG46JDLq5rs7leatm,eJ1aLYPUvbu,W9dDROThgk,kjzHBhaP05xt9dIo3])
	if emCV95HEQh: rrlmsg7HkZTpK(aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,AT4PsXD6Ixjpaekwz9F(u"ࠫั๐ฯࠡ࠰࠱ࠤ๋าอหࠢ฼้้๐ษࠡฬ้฼๏็ࠠไ๊า๎ࠬࡰ"))
	else: rrlmsg7HkZTpK(aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,QLx6cm8dzDCTZu(u"๊ࠬไฤีไࠤ࠳࠴ࠠโึ็ฮࠥ฿ๅๅ์ฬࠤฯ์ุ๋ใࠣ็ํี๊ࠨࡱ"))
	return
def UiEJPXAyhYZO56mDp8b9tk():
	qqWFcNPf5yHxGUudj8JDrMLabARpw = LXwpPu652WKdR8(aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,BRQKJfySTC6iAVLG3OmZg(u"ู࠭ๆๆํอࠥะๆู์ไࠤฬ๊ฬ่ษีࠤฯะๅࠡส่ืาࠦวๅ็็ๅฬะࠠศๆๅำ๏๋ษࠡษ็้ษ่สสࠢส่ฯ๐ࠠๆฬฯ้฾ฯࠠโ์๊ࠣ฽อๅࠡฬื฾๏๊ࠠศๆฯ๋ฬุࠠ࠯࠰๋้ࠣࠦสา์าࠤฯ์ุ๋ใࠣห้า็ศิࠣห้ศๆࠡมࠤࠫࡲ"))
	if qqWFcNPf5yHxGUudj8JDrMLabARpw!=ZW18wiTteB(u"࠱ࣀ"): return
	GG2TUF4vBKCkE5DSx7rYoZ = deK3Yn6i1HRsrcw4EZD0LP(u"ࠧ࠰ࡦࡤࡸࡦ࠵ࡳࡺࡵࡷࡩࡲ࠵ࡵࡴࡣࡪࡩࡸࡺࡡࡵࡵࠪࡳ")
	wgtoNTkB9xSWes6iYd = BRQKJfySTC6iAVLG3OmZg(u"ࠨ࠱ࡧࡥࡹࡧ࠯ࡴࡻࡶࡸࡪࡳ࠯ࡥࡴࡲࡴࡧࡵࡸࠨࡴ")
	GqKaVYPfSA2xwW9EJ6 = R74r6CnPX2Z(u"ࠩ࠲ࡨࡦࡺࡡ࠰ࡶࡲࡱࡧࡹࡴࡰࡰࡨࡷࠬࡵ")
	iKdVMyneUBIYzP457T2xb = FB0Cu4XTDcfej(u"ࠪ࠳ࡩࡧࡴࡢ࠱࡯ࡳ࡬࡭ࡥࡳࠩࡶ")
	xe2HM9VE8KyDgnBSolCd = R74r6CnPX2Z(u"ࠫ࠴ࡪࡡࡵࡣ࠲ࡰࡴ࡭ࠧࡷ")
	Fg1flivyz5AXCS9 = TxODKvyAwqVmChU7uorLpb(u"ࠬ࠵ࡤࡢࡶࡤ࠳ࡦࡴࡲࠨࡸ")
	l5ygJF2AjNaqv79XdQ03YmDuc = n9AlW7Kt4Bb2i(GG2TUF4vBKCkE5DSx7rYoZ,uerm1H6NcpkDCt7z(u"࡙ࡸࡵࡦ࣡"),deK3Yn6i1HRsrcw4EZD0LP(u"ࡊࡦࡲࡳࡦ࣠"),deK3Yn6i1HRsrcw4EZD0LP(u"ࡊࡦࡲࡳࡦ࣠"))
	EETU9MNvnjhOzRG46JDLq5rs7leatm = n9AlW7Kt4Bb2i(wgtoNTkB9xSWes6iYd,mgor3Abi2usncVGhZL1Tj4l(u"ࡔࡳࡷࡨࣣ"),eUxsukE2tw8ZJpP(u"ࡌࡡ࡭ࡵࡨ࣢"),eUxsukE2tw8ZJpP(u"ࡌࡡ࡭ࡵࡨ࣢"))
	eJ1aLYPUvbu = n9AlW7Kt4Bb2i(GqKaVYPfSA2xwW9EJ6,ffmzRlOHcBPQA69(u"ࡖࡵࡹࡪࣥ"),yyaY8SpZq4WFmPuEd2sk0T(u"ࡇࡣ࡯ࡷࡪࣤ"),yyaY8SpZq4WFmPuEd2sk0T(u"ࡇࡣ࡯ࡷࡪࣤ"))
	W9dDROThgk = n9AlW7Kt4Bb2i(iKdVMyneUBIYzP457T2xb,R74r6CnPX2Z(u"ࡘࡷࡻࡥࣧ"),FG4WcEa5QSU3vLmyC6jM8VqsOedH(u"ࡉࡥࡱࡹࡥࣦ"),FG4WcEa5QSU3vLmyC6jM8VqsOedH(u"ࡉࡥࡱࡹࡥࣦ"))
	kjzHBhaP05xt9dIo3 = n9AlW7Kt4Bb2i(xe2HM9VE8KyDgnBSolCd,iHld5wa1jvpz4MGoXYxUcfRF3(u"࡚ࡲࡶࡧࣩ"),QAfCnxOo24YtPgsa0m(u"ࡋࡧ࡬ࡴࡧࣨ"),QAfCnxOo24YtPgsa0m(u"ࡋࡧ࡬ࡴࡧࣨ"))
	DirRCtIPbBZcQh5LpNv8UexS6XwJG9 = n9AlW7Kt4Bb2i(Fg1flivyz5AXCS9,N2XRVI1Hvrxkqsf(u"ࡕࡴࡸࡩ࣫"),ZW18wiTteB(u"ࡆࡢ࡮ࡶࡩ࣪"),ZW18wiTteB(u"ࡆࡢ࡮ࡶࡩ࣪"))
	emCV95HEQh = all([l5ygJF2AjNaqv79XdQ03YmDuc,EETU9MNvnjhOzRG46JDLq5rs7leatm,eJ1aLYPUvbu,W9dDROThgk,kjzHBhaP05xt9dIo3,DirRCtIPbBZcQh5LpNv8UexS6XwJG9])
	if emCV95HEQh: rrlmsg7HkZTpK(aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,uerm1H6NcpkDCt7z(u"࠭ฬ๋ัࠣ࠲࠳ࠦๆอฯอࠤ฾๋ไ๋หࠣฮ๋฾๊โࠢส่ัํวำࠩࡹ"))
	else: rrlmsg7HkZTpK(aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,O9CJ8IX2A0lETWjitaR4zDdecpF(u"ࠧๅๆฦืๆࠦ࠮࠯ࠢไุ้ะฺࠠ็็๎ฮࠦส็ฺํๅࠥอไอ้สึࠬࡺ"))
	return
def rrxAPqlpbmZ9c2LBiYhIC(YeqJH6PfTOkw2jAL0ZRXcbSo):
	emCV95HEQh = NybQeHvRAqcYmhDIfaiFZXojGC(u"ࡖࡵࡹࡪ࣬")
	if YeqJH6PfTOkw2jAL0ZRXcbSo:
		qqWFcNPf5yHxGUudj8JDrMLabARpw = LXwpPu652WKdR8(aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,mgor3Abi2usncVGhZL1Tj4l(u"ࠨ้็ࠤฯื๊ะ่ࠢืาࠦๅฮฬ๋๎ฬะࠠๆๆไࠤฺ๎ัࠡษ็ะ้ีࠠภࠣࠤࠫࡻ"))
		if qqWFcNPf5yHxGUudj8JDrMLabARpw!=D4jmQZsoUPaiNw0qIgvyc25f(u"࠲ࣁ"): return
	try:
		import sqlite3 as djbxOaITlRYyNCAirm6WvJHs83Kfo
		oomEUWp0bd2BvSwi4OT = djbxOaITlRYyNCAirm6WvJHs83Kfo.connect(p0PKJqMbDVe3QRw49E7khACs8Or6)
		oomEUWp0bd2BvSwi4OT.text_factory = str
		YY7QjaAeB4UNOqsTzF = oomEUWp0bd2BvSwi4OT.cursor()
		YY7QjaAeB4UNOqsTzF.execute(iHld5wa1jvpz4MGoXYxUcfRF3(u"ࠩࡇࡉࡑࡋࡔࡆࠢࡉࡖࡔࡓࠠࡱࡣࡷ࡬ࡀ࠭ࡼ"))
		YY7QjaAeB4UNOqsTzF.execute(iHld5wa1jvpz4MGoXYxUcfRF3(u"ࠪࡈࡊࡒࡅࡕࡇࠣࡊࡗࡕࡍࠡࡵ࡬ࡾࡪࡹ࠻ࠨࡽ"))
		YY7QjaAeB4UNOqsTzF.execute(PvOcZ491qRi0I(u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࡷࡩࡽࡺࡵࡳࡧ࠾ࠫࡾ"))
		oomEUWp0bd2BvSwi4OT.commit()
		YY7QjaAeB4UNOqsTzF.execute(QLx6cm8dzDCTZu(u"ࠬ࡜ࡁࡄࡗࡘࡑࡀ࠭ࡿ"))
		oomEUWp0bd2BvSwi4OT.close()
	except: emCV95HEQh = O9CJ8IX2A0lETWjitaR4zDdecpF(u"ࡉࡥࡱࡹࡥ࣭")
	if YeqJH6PfTOkw2jAL0ZRXcbSo and emCV95HEQh: rrlmsg7HkZTpK(aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,Sn3ayo5TFewbZ0irDxlKXq(u"࠭สๆࠢสู่๊อࠡส้ะฬำࠧࢀ"))
	return emCV95HEQh
def dLwMnKEYJhAiTvSPFBsom6Zp0():
	emCV95HEQh = AT4PsXD6Ixjpaekwz9F(u"ࡘࡷࡻࡥ࣮")
	for file in bSRUZEN7dHJia2LBG6ejvTCg0zcs.listdir(hK9XGCvs7lS5OYEM80d6jk23U):
		if yMtnXxSiTUzGWsdj(u"ࠧ࡬ࡱࡧ࡭ࡤࡹࡴࡢࡥ࡮ࡸࡷࡧࡣࡦࠩࢁ") not in file or wxD5lWH8qrampQBPogLbNe6nA(u"ࠨ࡭ࡲࡨ࡮ࡥࡣࡳࡣࡶ࡬ࡱࡵࡧࠨࢂ") not in file: continue
		vCO37XBmhV1qG2KYjtaLQ = bSRUZEN7dHJia2LBG6ejvTCg0zcs.path.join(hK9XGCvs7lS5OYEM80d6jk23U,file)
		try:
			bSRUZEN7dHJia2LBG6ejvTCg0zcs.remove(vCO37XBmhV1qG2KYjtaLQ)
		except Exception as lBmkMZDoWN2ycOqEjVLx:
			emCV95HEQh = TxODKvyAwqVmChU7uorLpb(u"ࡋࡧ࡬ࡴࡧ࣯")
			if YeqJH6PfTOkw2jAL0ZRXcbSo and emCV95HEQh: rrlmsg7HkZTpK(aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,aJNqSlf6rx9yguWK7IF,str(lBmkMZDoWN2ycOqEjVLx))
	return emCV95HEQh
zJryU4fnuW8L90IFGNT1a5qvtjCY(AT4PsXD6Ixjpaekwz9F(u"ࠩࡶࡸࡦࡸࡴࠨࢃ"))
kLZP0WI6VS3q1FHM = pVy8J6XAkqmrvzRe7.argv[N2XRVI1Hvrxkqsf(u"࠳ࣂ")]
qJAcO6K9Z5mutLgNakdREQHnS2p3b = uerm1H6NcpkDCt7z(u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨࢄ")
tJSCeoANcLBK3bY1Ri7wMfdVIvZE = BeLDhTt1GQ.getInfoLabel(yyaY8SpZq4WFmPuEd2sk0T(u"ࠦࡘࡿࡳࡵࡧࡰ࠲ࡇࡻࡩ࡭ࡦ࡙ࡩࡷࡹࡩࡰࡰࠥࢅ"))
QPyZXwNMv6 = CJV0WXMAywKY5x2c6qbSf.findall(AT4PsXD6Ixjpaekwz9F(u"ࠬ࠮࡜ࡥ࡞ࡧࡠ࠳ࡢࡤࠪࠩࢆ"),tJSCeoANcLBK3bY1Ri7wMfdVIvZE,CJV0WXMAywKY5x2c6qbSf.DOTALL)
QPyZXwNMv6 = float(QPyZXwNMv6[N2XRVI1Hvrxkqsf(u"࠳ࣃ")])
L4wJHOS27TXd1 = QPyZXwNMv6<Is7DRMACaum(u"࠵࠾ࣄ")
QdOI8gDt61wUm0vEGWV = QPyZXwNMv6>iHld5wa1jvpz4MGoXYxUcfRF3(u"࠶࠾࠮࠺࠻ࣅ")
if QdOI8gDt61wUm0vEGWV:
	hK9XGCvs7lS5OYEM80d6jk23U = m2ZubSXxTeGpiC6.translatePath(D4jmQZsoUPaiNw0qIgvyc25f(u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱࡯ࡳ࡬ࡶࡡࡵࡪࠪࢇ"))
	x5xG8C34dRVLkK = m2ZubSXxTeGpiC6.translatePath(NybQeHvRAqcYmhDIfaiFZXojGC(u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲࡬ࡴࡳࡥࠨ࢈"))
	nm7P5W2dpRXg = m2ZubSXxTeGpiC6.translatePath(D4jmQZsoUPaiNw0qIgvyc25f(u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳ࡹ࡫࡭ࡱࠩࢉ"))
	WF6cE9LvdyQDqiP53J = bSRUZEN7dHJia2LBG6ejvTCg0zcs.path.join(x5xG8C34dRVLkK,Yzbm7Ac4eMKHP1IN(u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫࢊ"),wxD5lWH8qrampQBPogLbNe6nA(u"ࠪࡈࡦࡺࡡࡣࡣࡶࡩࠬࢋ"),R74r6CnPX2Z(u"ࠫࡆࡪࡤࡰࡰࡶ࠷࠸࠴ࡤࡣࠩࢌ"))
else:
	hK9XGCvs7lS5OYEM80d6jk23U = BeLDhTt1GQ.translatePath(ewJh3POUpynEdfzoc7MAT(u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰࡮ࡲ࡫ࡵࡧࡴࡩࠩࢍ"))
	x5xG8C34dRVLkK = BeLDhTt1GQ.translatePath(yyaY8SpZq4WFmPuEd2sk0T(u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱࡫ࡳࡲ࡫ࠧࢎ"))
	nm7P5W2dpRXg = BeLDhTt1GQ.translatePath(O9CJ8IX2A0lETWjitaR4zDdecpF(u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲ࡸࡪࡳࡰࠨ࢏"))
	WF6cE9LvdyQDqiP53J = bSRUZEN7dHJia2LBG6ejvTCg0zcs.path.join(x5xG8C34dRVLkK,HmRBJqA8UWO(u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪ࢐"),Yzbm7Ac4eMKHP1IN(u"ࠩࡇࡥࡹࡧࡢࡢࡵࡨࠫ࢑"),eUxsukE2tw8ZJpP(u"ࠪࡅࡩࡪ࡯࡯ࡵ࠵࠻࠳ࡪࡢࠨ࢒"))
tPIfTmJH5vwL4Eu9hqdY = bSRUZEN7dHJia2LBG6ejvTCg0zcs.path.join(x5xG8C34dRVLkK,QAfCnxOo24YtPgsa0m(u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭࢓"),N2XRVI1Hvrxkqsf(u"ࠬࡧࡤࡥࡱࡱࡣࡩࡧࡴࡢࠩ࢔"),qJAcO6K9Z5mutLgNakdREQHnS2p3b)
Np6QT8rzHJ73ESoxt2IFX5BlsAKg = bSRUZEN7dHJia2LBG6ejvTCg0zcs.path.join(tPIfTmJH5vwL4Eu9hqdY,iHld5wa1jvpz4MGoXYxUcfRF3(u"࠭ࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡺࡰࡰࠬ࢕"))
St0CsQUm8xzlj6ZY = bSRUZEN7dHJia2LBG6ejvTCg0zcs.path.join(nm7P5W2dpRXg,qJAcO6K9Z5mutLgNakdREQHnS2p3b)
Fk8DzCm16QfaEIZo574V = bSRUZEN7dHJia2LBG6ejvTCg0zcs.path.join(x5xG8C34dRVLkK,QLx6cm8dzDCTZu(u"ࠧࡶࡵࡨࡶࡩࡧࡴࡢࠩ࢖"),FG4WcEa5QSU3vLmyC6jM8VqsOedH(u"ࠨࡖ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡷࠬࢗ"))
OQF4vD1l85gmaKdzrBZch0 = bSRUZEN7dHJia2LBG6ejvTCg0zcs.path.join(x5xG8C34dRVLkK,uerm1H6NcpkDCt7z(u"ࠩࡤࡨࡩࡵ࡮ࡴࠩ࢘"))
e1hxXgFQr73o = bSRUZEN7dHJia2LBG6ejvTCg0zcs.path.join(OQF4vD1l85gmaKdzrBZch0,qJAcO6K9Z5mutLgNakdREQHnS2p3b)
ttNRDoYJbUkVT67 = bSRUZEN7dHJia2LBG6ejvTCg0zcs.path.join(OQF4vD1l85gmaKdzrBZch0,QLx6cm8dzDCTZu(u"ࠪࡸࡪࡳࡰࠨ࢙"))
j3pKdqPvN0BRO = bSRUZEN7dHJia2LBG6ejvTCg0zcs.path.join(OQF4vD1l85gmaKdzrBZch0,N2XRVI1Hvrxkqsf(u"ࠫࡵࡧࡣ࡬ࡣࡪࡩࡸ࢚࠭"))
p0PKJqMbDVe3QRw49E7khACs8Or6 = bSRUZEN7dHJia2LBG6ejvTCg0zcs.path.join(x5xG8C34dRVLkK,yyaY8SpZq4WFmPuEd2sk0T(u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧ࢛ࠧ"),wxD5lWH8qrampQBPogLbNe6nA(u"࠭ࡄࡢࡶࡤࡦࡦࡹࡥࠨ࢜"),Is7DRMACaum(u"ࠧࡕࡧࡻࡸࡺࡸࡥࡴ࠳࠶࠲ࡩࡨࠧ࢝"))
Zdl82RVWFU93SJIt0Nq6PCDOeT = bSRUZEN7dHJia2LBG6ejvTCg0zcs.path.join(St0CsQUm8xzlj6ZY,eUxsukE2tw8ZJpP(u"ࠨ࡫ࡰࡥ࡬࡫ࡳࠨ࢞"))
QAtxNyH2Lb6jWRlpXJUfZqV51knc = bSRUZEN7dHJia2LBG6ejvTCg0zcs.path.join(hK9XGCvs7lS5OYEM80d6jk23U,Yzbm7Ac4eMKHP1IN(u"ࠩ࡮ࡳࡩ࡯࠮࡭ࡱࡪࠫ࢟"))
iZo9LrezCmNlIxj3p2KtnAOYFUbH48 = bSRUZEN7dHJia2LBG6ejvTCg0zcs.path.join(hK9XGCvs7lS5OYEM80d6jk23U,Yzbm7Ac4eMKHP1IN(u"ࠪ࡯ࡴࡪࡩ࠯ࡱ࡯ࡨ࠳ࡲ࡯ࡨࠩࢠ"))
if   kLZP0WI6VS3q1FHM==HmRBJqA8UWO(u"ࠫࡸ࡫࡮ࡥࡡ࡯ࡳ࡬࡬ࡩ࡭ࡧࠪࢡ")		: OJeBTQhj4m(QAtxNyH2Lb6jWRlpXJUfZqV51knc)
elif kLZP0WI6VS3q1FHM==ewJh3POUpynEdfzoc7MAT(u"ࠬࡹࡥ࡯ࡦࡢࡳࡱࡪ࡟࡭ࡱࡪࡪ࡮ࡲࡥࠨࢢ")	: OJeBTQhj4m(iZo9LrezCmNlIxj3p2KtnAOYFUbH48)
elif kLZP0WI6VS3q1FHM==Is7DRMACaum(u"࠭ࡤࡦ࡮ࡨࡸࡪࡥࡳࡦࡶࡷ࡭ࡳ࡭ࡳࠨࢣ")		: Z8a1Xv6NxHGWIh()
elif kLZP0WI6VS3q1FHM==NybQeHvRAqcYmhDIfaiFZXojGC(u"ࠧࡥࡧ࡯ࡩࡹ࡫࡟ࡤࡣࡦ࡬ࡪ࠭ࢤ")		: x1Qf93owGnVTFvL()
elif kLZP0WI6VS3q1FHM==QLx6cm8dzDCTZu(u"ࠨࡥ࡯ࡩࡦࡴ࡟࡬ࡱࡧ࡭ࠬࢥ")			: sx8VQb9awzXP62tW5LHmG3R()
elif kLZP0WI6VS3q1FHM==FG4WcEa5QSU3vLmyC6jM8VqsOedH(u"ࠩࡦࡰࡪࡧ࡮ࡠࡦࡨࡺ࡮ࡩࡥࡠࡱࡶࠫࢦ")		: UiEJPXAyhYZO56mDp8b9tk()
elif kLZP0WI6VS3q1FHM==yMtnXxSiTUzGWsdj(u"ࠪ࡭ࡳࡹࡴࡢ࡮࡯ࡣࡴࡲࡤࡠࡸࡨࡶࡸ࡯࡯࡯ࠩࢧ")	: GrguZjlFeqQhWOzC()
elif kLZP0WI6VS3q1FHM==HmRBJqA8UWO(u"ࠫࡲࡵࡤࡪࡨࡼࡣࡦࡻࡴࡰࡷࡳࡨࡦࡺࡥࠨࢨ")	: eeo4p8iVvG()
elif kLZP0WI6VS3q1FHM==QLx6cm8dzDCTZu(u"ࠬࡪࡥ࡭ࡧࡷࡩࡤࡳࡥ࡯ࡷࡶࡣ࡮ࡳࡡࡨࡧࡶࠫࢩ")	: Dp0s9PTHrhSzI3A()
zJryU4fnuW8L90IFGNT1a5qvtjCY(ewJh3POUpynEdfzoc7MAT(u"࠭ࡳࡵࡱࡳࠫࢪ"))
# -*- coding: utf-8 -*-
import sys as TPW58slaVE9OrYQXZnGo2yAfFzpBxc
tbYWAoeMyHTsgFG5x6huz1 = TPW58slaVE9OrYQXZnGo2yAfFzpBxc.version_info [0] == 2
CUJSAbZztE8vYdGByLH0KcnWqe = 2048
R0QCXnpyL1DJwBH67FW = 7
def kSod2AxqugH0 (LURfCucn30xKsMdTiG):
	global ghCyPxkWILcXrGjVut6MQo59fsv
	MfIpC9TDz7Qa5g2vVqPtXh4 = ord (LURfCucn30xKsMdTiG [-1])
	nndScZEtapB74 = LURfCucn30xKsMdTiG [:-1]
	LRbqugZJAa3192OCewWGHvEcP = MfIpC9TDz7Qa5g2vVqPtXh4 % len (nndScZEtapB74)
	qLc7RGgDQE = nndScZEtapB74 [:LRbqugZJAa3192OCewWGHvEcP] + nndScZEtapB74 [LRbqugZJAa3192OCewWGHvEcP:]
	if tbYWAoeMyHTsgFG5x6huz1:
		XUczap3yA0QqFRC82OH6E5mL = unicode () .join ([unichr (ord (ah5u39EBY81MlrwA0cmoz4ngb7TLed) - CUJSAbZztE8vYdGByLH0KcnWqe - (YMjpxPr8WsJ1Bg6Xd + MfIpC9TDz7Qa5g2vVqPtXh4) % R0QCXnpyL1DJwBH67FW) for YMjpxPr8WsJ1Bg6Xd, ah5u39EBY81MlrwA0cmoz4ngb7TLed in enumerate (qLc7RGgDQE)])
	else:
		XUczap3yA0QqFRC82OH6E5mL = str () .join ([chr (ord (ah5u39EBY81MlrwA0cmoz4ngb7TLed) - CUJSAbZztE8vYdGByLH0KcnWqe - (YMjpxPr8WsJ1Bg6Xd + MfIpC9TDz7Qa5g2vVqPtXh4) % R0QCXnpyL1DJwBH67FW) for YMjpxPr8WsJ1Bg6Xd, ah5u39EBY81MlrwA0cmoz4ngb7TLed in enumerate (qLc7RGgDQE)])
	return eval (XUczap3yA0QqFRC82OH6E5mL)
jL1E5AKfwBDv6xmeQtUXcJ3d,JJA7fypmZFVlazvNI,dBi72erQEtKDOwjNFaoAgSP=kSod2AxqugH0,kSod2AxqugH0,kSod2AxqugH0
CDwSWB4v39N7,k4IUieraScH9DV1N7pJgQosYAx5l,Tcf5Ppn9UajDbzyM=dBi72erQEtKDOwjNFaoAgSP,JJA7fypmZFVlazvNI,jL1E5AKfwBDv6xmeQtUXcJ3d
X2crmy67eZpkGTRd,HDpmv4UXzlf72SK9,C3ZK1pu4rfmj8TsWUtBaM=Tcf5Ppn9UajDbzyM,k4IUieraScH9DV1N7pJgQosYAx5l,CDwSWB4v39N7
mg3CbXMA2ouZzQDhRqB,OBsrtQo2pPlgURCxJYbj9iXMD,ssnfOzb16wVog9GKdqcXR3JC7ktSPA=C3ZK1pu4rfmj8TsWUtBaM,HDpmv4UXzlf72SK9,X2crmy67eZpkGTRd
ShnRVsifKtc60zqQ,KKi79PFqsYB0dWSRgaJ3DyE,OzU6t0qcH7MQabeBYK8vgoG=ssnfOzb16wVog9GKdqcXR3JC7ktSPA,OBsrtQo2pPlgURCxJYbj9iXMD,mg3CbXMA2ouZzQDhRqB
mgLADoQ1pbtY,U0VwOviFaYPz2QGs45mJhMXf7Zk,pCTzbw4GyVJHjkcIMQ=OzU6t0qcH7MQabeBYK8vgoG,KKi79PFqsYB0dWSRgaJ3DyE,ShnRVsifKtc60zqQ
owbMhINBQsmx70guApW,SODvU3Ibq5VzC,PPAUFrY8cduRT=pCTzbw4GyVJHjkcIMQ,U0VwOviFaYPz2QGs45mJhMXf7Zk,mgLADoQ1pbtY
knTyjJ0sGIzuwbxRae,nz8x32hX0qcjUPFZk5RdJsiwED,A0aqj9uclgOtByJ6F4bz=PPAUFrY8cduRT,SODvU3Ibq5VzC,owbMhINBQsmx70guApW
YJxaX0MQOHb8oyCBFdnIAe,n6sfYuHBlVdzgmvpXwR3irON0KIj8,LHX65I9nkx0PstgcVY24uSi=A0aqj9uclgOtByJ6F4bz,nz8x32hX0qcjUPFZk5RdJsiwED,knTyjJ0sGIzuwbxRae
EAVanJj1ers2GQud,ELfMeDTIFhJt685K,EF2tvxZHz5n4UruPhaViXKycI6SQR=LHX65I9nkx0PstgcVY24uSi,n6sfYuHBlVdzgmvpXwR3irON0KIj8,YJxaX0MQOHb8oyCBFdnIAe
KhUG1NV9bln5zXjptqFW6dgo,cWbkR6iUZsnJQj14,maUl7SPesynF1j=EF2tvxZHz5n4UruPhaViXKycI6SQR,ELfMeDTIFhJt685K,EAVanJj1ers2GQud
from ii8pncyETm import *
SITESURLS = {
			 OzU6t0qcH7MQabeBYK8vgoG(u"ࠪࡅࡍ࡝ࡁࡌࠩඓ")		:[mg3CbXMA2ouZzQDhRqB(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡳ࠯ࡣ࡫ࡻࡦࡱࡴࡷ࠰ࡱࡩࡹ࠭ඔ")]
			,OzU6t0qcH7MQabeBYK8vgoG(u"ࠬࡇࡋࡐࡃࡐࠫඕ")		:[HDpmv4UXzlf72SK9(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢ࡭࠱ࡷࡻ࠵࡯࡭ࡦࠪඖ")]
			,maUl7SPesynF1j(u"ࠧࡂࡍ࡚ࡅࡒ࠭඗")		:[YJxaX0MQOHb8oyCBFdnIAe(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤ࡯࠳ࡹࡶࠨ඘")]
			,YJxaX0MQOHb8oyCBFdnIAe(u"ࠩࡄࡏ࡜ࡇࡍࡕࡗࡅࡉࠬ඙")	:[knTyjJ0sGIzuwbxRae(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡹ࠮ࡢ࡭ࡺࡥࡲ࠴ࡴࡶࡤࡨࠫක")]
			,jL1E5AKfwBDv6xmeQtUXcJ3d(u"ࠫࡆࡒࡍࡂࡃࡕࡉࡋ࠭ඛ")		:[YJxaX0MQOHb8oyCBFdnIAe(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡ࡭࡯ࡤࡥࡷ࡫ࡦ࠯ࡥ࡫ࠫග")]
			,ShnRVsifKtc60zqQ(u"࠭ࡁࡍࡏࡖࡘࡇࡇࠧඝ")		:[maUl7SPesynF1j(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡧ࡬࡮ࡵࡷࡦࡦ࠴ࡴࡷࠩඞ")]
			,EAVanJj1ers2GQud(u"ࠨࡃࡑࡍࡒࡋ࡚ࡊࡆࠪඟ")		:[C3ZK1pu4rfmj8TsWUtBaM(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡳ࡯࡭ࡦࡼ࡬ࡨ࠳ࡹࡨࡰࡹࠪච")]
			,C3ZK1pu4rfmj8TsWUtBaM(u"ࠪࡅࡗࡇࡂࡊࡅࡗࡓࡔࡔࡓࠨඡ")	:[X2crmy67eZpkGTRd(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡣࡵࡥࡧ࡯ࡣ࠮ࡶࡲࡳࡳࡹ࠮ࡤࡱࡰࠫජ")]
			,U0VwOviFaYPz2QGs45mJhMXf7Zk(u"ࠬࡇࡒࡂࡄࡖࡉࡊࡊࠧඣ")		:[CDwSWB4v39N7(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡴࡤࡦࡸ࡫ࡥࡥ࠰ࡱࡩࡹ࠭ඤ")]
			,cWbkR6iUZsnJQj14(u"ࠧࡂ࡛ࡏࡓࡑ࠭ඥ")		:[dBi72erQEtKDOwjNFaoAgSP(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡩ࠳ࡧࡹ࡭ࡱ࡯࠲ࡳ࡫ࡴࠨඦ")]
			,mgLADoQ1pbtY(u"ࠩࡅࡓࡐࡘࡁࠨට")		:[maUl7SPesynF1j(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸ࡮ࡡࡩ࡫ࡧࡰ࡮ࡼࡥ࠯ࡥࡲࠫඨ")]
			,mgLADoQ1pbtY(u"ࠫࡇࡘࡓࡕࡇࡍࠫඩ")		:[OzU6t0qcH7MQabeBYK8vgoG(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡢࡳࡵࡷ࡭࡯࠴ࡣࡢ࡯ࠪඪ")]
			,KhUG1NV9bln5zXjptqFW6dgo(u"࠭ࡃࡊࡏࡄ࠸࠵࠶ࠧණ")		:[mgLADoQ1pbtY(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡥ࡬ࡱࡦ࠺࠰࠱࠰ࡦࡳࡲ࠭ඬ")]
			,nz8x32hX0qcjUPFZk5RdJsiwED(u"ࠨࡅࡌࡑࡆ࠺ࡐࠨත")		:[jL1E5AKfwBDv6xmeQtUXcJ3d(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻ࠳ࡩࡩ࡮ࡣ࠷ࡴ࠳ࡩ࡯࡮ࠩථ")]
			,KhUG1NV9bln5zXjptqFW6dgo(u"ࠪࡇࡎࡓࡁ࠵ࡗࠪද")		:[Tcf5Ppn9UajDbzyM(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࠷ࡣࡪ࡯ࡤ࠸ࡺ࠴ࡣࡰ࡯ࠪධ")]
			,pCTzbw4GyVJHjkcIMQ(u"ࠬࡉࡉࡎࡃࡄࡆࡉࡕࠧන")		:[LHX65I9nkx0PstgcVY24uSi(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡤ࡯࠱ࡧ࡮ࡳࡡ࠴ࡤࡧࡳ࠳ࡩ࡯࡮ࠩ඲")]
			,KKi79PFqsYB0dWSRgaJ3DyE(u"ࠧࡄࡋࡐࡅࡈࡒࡕࡃࠩඳ")		:[EF2tvxZHz5n4UruPhaViXKycI6SQR(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡦ࡭࡮ࡳࡡࡤ࡮ࡸࡦ࠳ࡩ࡬ࡶࡤࠪප")]
			,HDpmv4UXzlf72SK9(u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅ࡛ࡔࡘࡋࠨඵ")	:[ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡹࡼࡶ࠯ࡥ࡬ࡱࡦࡩ࡬ࡶࡤ࠱ࡷ࡭ࡵࡰࠨබ")]
			,owbMhINBQsmx70guApW(u"ࠫࡈࡏࡍࡂࡈࡄࡒࡘ࠭භ")		:[CDwSWB4v39N7(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡧ࡮ࡳࡡࡧࡣࡱࡷ࠳ࡩ࡯ࠨම")]
			,Tcf5Ppn9UajDbzyM(u"࠭ࡃࡊࡏࡄࡊࡗࡋࡅࠨඹ")		:[ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡥ࡬ࡱࡦ࡬ࡲࡦ࠰ࡷࡳࡩࡧࡹࠨය")]
			,mgLADoQ1pbtY(u"ࠨࡅࡌࡑࡆࡒࡉࡈࡊࡗࠫර")	:[knTyjJ0sGIzuwbxRae(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡱࡾ࠳ࡣࡪ࡯ࡤ࠲ࡳ࡫ࡴࠨ඼")]
			,n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"ࠪࡇࡎࡓࡁࡏࡑ࡚ࠫල")		:[PPAUFrY8cduRT(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡩࡩ࡮ࡣࡱࡳࡼ࠴ࡣࡤࠩ඾")]
			,ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"ࠬࡉࡉࡎࡃ࡚ࡆࡆ࡙ࠧ඿")		:[A0aqj9uclgOtByJ6F4bz(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡮ࡻࡦ࡭ࡲࡧ࠮ࡤࡥࠪව")]
			,knTyjJ0sGIzuwbxRae(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒࠬශ")	:[jL1E5AKfwBDv6xmeQtUXcJ3d(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱ࠲ࡨࡵ࡭ࠨෂ"),pCTzbw4GyVJHjkcIMQ(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡫ࡷࡧࡰࡩࡳ࡯࠲ࡦࡶࡩ࠯ࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠴ࡣࡰ࡯ࠪස"),A0aqj9uclgOtByJ6F4bz(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸ࡫ࡡࡳࡥ࡫࠲ࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯࠰ࡦࡳࡲ࠭හ")]
			,KhUG1NV9bln5zXjptqFW6dgo(u"ࠫࡉࡘࡁࡎࡃࡆࡅࡋࡋࠧළ")	:[KKi79PFqsYB0dWSRgaJ3DyE(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷ࠳࠷࠱ࡨࡷࡧ࡭ࡢࡥࡤࡪࡪ࠳ࡴࡷ࠰ࡦࡳࡲ࠭ෆ")]
			,maUl7SPesynF1j(u"࠭ࡄࡓࡃࡐࡅࡘ࠽ࠧ෇")		:[EF2tvxZHz5n4UruPhaViXKycI6SQR(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡦࡵࡥࡲࡧࡳ࠸࠰ࡱࡩࡹ࠭෈")]
			,X2crmy67eZpkGTRd(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠳ࠪ෉")		:[pCTzbw4GyVJHjkcIMQ(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩ࡬ࡿࡢࡦࡵࡷ࠲࡫ࡻ࡮ࠨ්")]
			,A0aqj9uclgOtByJ6F4bz(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠶ࠬ෋")		:[KhUG1NV9bln5zXjptqFW6dgo(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫ࡧࡺࡤࡨࡷࡹ࠴࡮ࡦࡹࡶࠫ෌")]
			,mgLADoQ1pbtY(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠹ࠧ෍")		:[SODvU3Ibq5VzC(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡪࡧࡪࡽࡧ࡫ࡳࡵ࠰ࡥ࡭ࡩ࠭෎")]
			,U0VwOviFaYPz2QGs45mJhMXf7Zk(u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠵ࠩා")		:[C3ZK1pu4rfmj8TsWUtBaM(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨ࡫ࡾ࠳ࡢࡦࡵࡷ࠲ࡳ࡫ࡴࠨැ")]
			,owbMhINBQsmx70guApW(u"ࠩࡈࡋ࡞ࡊࡅࡂࡆࠪෑ")		:[dBi72erQEtKDOwjNFaoAgSP(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪ࡭ࡹࡥࡧࡤࡨ࠳ࡲࡩࡷࡧࠪි")]
			,pCTzbw4GyVJHjkcIMQ(u"ࠫࡊࡒࡃࡊࡐࡈࡑࡆ࠭ී")		:[X2crmy67eZpkGTRd(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥ࡭ࡥ࡬ࡲࡪࡳࡡ࠯ࡥࡲࡱࠬු")]
			,HDpmv4UXzlf72SK9(u"࠭ࡅࡍࡋࡉ࡚ࡎࡊࡅࡐࠩ෕")	:[ShnRVsifKtc60zqQ(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡵ࡫ࡥ࡭࡯ࡤ࠯ࡧ࡯࡭࡫࠴࡮ࡦࡹࡶࠫූ")]
			,JJA7fypmZFVlazvNI(u"ࠨࡈࡄࡆࡗࡇࡋࡂࠩ෗")		:[A0aqj9uclgOtByJ6F4bz(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡪࡦࡨࡲ࡬ࡣ࠱ࡧࡴࡳࠧෘ")]
			,HDpmv4UXzlf72SK9(u"ࠪࡊࡆࡐࡅࡓࡕࡋࡓ࡜࠭ෙ")	:[mgLADoQ1pbtY(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡬ࡡ࡫ࡧࡵ࠲ࡸ࡮࡯ࡸࠩේ")]
			,EF2tvxZHz5n4UruPhaViXKycI6SQR(u"ࠬࡌࡁࡓࡇࡖࡏࡔ࠭ෛ")		:[mg3CbXMA2ouZzQDhRqB(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡷ࡫ࡳ࠲࡫ࡧࡲࡦࡵ࡮ࡳ࠳ࡴࡥࡵࠩො")]
			,OBsrtQo2pPlgURCxJYbj9iXMD(u"ࠧࡇࡃࡖࡉࡑࡎࡄ࠳ࠩෝ")		:[LHX65I9nkx0PstgcVY24uSi(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡷࡱࡧ࠮ࡧࡣࡶࡩࡱ࡮ࡤ࠯ࡥ࡯ࡳࡺࡪࠧෞ")]
			,OBsrtQo2pPlgURCxJYbj9iXMD(u"ࠩࡉࡓࡘ࡚ࡁࠨෟ")		:[HDpmv4UXzlf72SK9(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡫ࡵࡳࡵࡣ࠰ࡸࡻ࠴ࡷࡦࡤࡶ࡭ࡹ࡫ࠧ෠")]
			,k4IUieraScH9DV1N7pJgQosYAx5l(u"ࠫࡋ࡛ࡎࡐࡐࡗ࡚ࠬ෡")		:[owbMhINBQsmx70guApW(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡧ࠯ࡣ࡯ࡱࡪࡹࡨ࡬ࡣ࡫࠲ࡳ࡫ࡴࠨ෢")]
			,mg3CbXMA2ouZzQDhRqB(u"࠭ࡆࡖࡕࡋࡅࡗ࡚ࡖࠨ෣")		:[KKi79PFqsYB0dWSRgaJ3DyE(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡤ࠱ࡪࡺࡹࡨࡢࡴ࠰ࡸࡻ࠴ࡣࡰ࡯ࠪ෤")]
			,ShnRVsifKtc60zqQ(u"ࠨࡈࡘࡗࡍࡇࡒࡗࡋࡇࡉࡔ࠭෥")	:[KKi79PFqsYB0dWSRgaJ3DyE(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡷ࠳࡬ࡵࡴࡪࡤࡶ࠳ࡼࡩࡥࡧࡲࠫ෦")]
			,A0aqj9uclgOtByJ6F4bz(u"ࠪࡌࡆࡒࡁࡄࡋࡐࡅࠬ෧")		:[mg3CbXMA2ouZzQDhRqB(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡮ࡡ࡭ࡣࡦ࡭ࡲࡧ࠮࡮ࡧࡧ࡭ࡦ࠭෨")]
			,SODvU3Ibq5VzC(u"ࠬࡏࡆࡊࡎࡐࠫ෩")		:[mgLADoQ1pbtY(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡴ࠱࡭࡫࡯࡬࡮ࡶࡹ࠲࡮ࡸࠧ෪"),dBi72erQEtKDOwjNFaoAgSP(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡱ࠲࡮࡬ࡩ࡭࡯ࡷࡺ࠳࡯ࡲࠨ෫"),OBsrtQo2pPlgURCxJYbj9iXMD(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡩࡥ࠳࡯ࡦࡪ࡮ࡰࡸࡻ࠴ࡩࡳࠩ෬"),pCTzbw4GyVJHjkcIMQ(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡪࡦ࠸࠮ࡪࡨ࡬ࡰࡲࡺࡶ࠯࡫ࡵࠫ෭"),C3ZK1pu4rfmj8TsWUtBaM(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠽࠸࠴࠱࠺࠲࠱࠶࠹࠴࠱࠳࠴ࠪ෮")]
			,YJxaX0MQOHb8oyCBFdnIAe(u"ࠫࡐࡇࡒࡃࡃࡏࡅ࡙࡜ࠧ෯")	:[Tcf5Ppn9UajDbzyM(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡢࡴࡥࡥࡱࡧ࠭ࡵࡸ࠱࡭ࡶ࠭෰")]
			,ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"࠭ࡋࡂࡖࡎࡓ࡙࡚ࡖࠨ෱")		:[ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭࡬ࡸࡰࡵࡴ࠯ࡥࡤࡱࠬෲ")]
			,dBi72erQEtKDOwjNFaoAgSP(u"ࠨࡍࡌࡖࡒࡇࡌࡌࠩෳ")		:[owbMhINBQsmx70guApW(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯࡮ࡸ࡭ࡢ࡮࡮࠲ࡴࡸࡧࠨ෴")]
			,ELfMeDTIFhJt685K(u"ࠪࡐࡆࡘࡏ࡛ࡃࠪ෵")		:[k4IUieraScH9DV1N7pJgQosYAx5l(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡲࡡࡳࡱࡽࡥ࠳࡯࡮࡬ࠩ෶")]
			,Tcf5Ppn9UajDbzyM(u"ࠬࡒࡏࡅ࡛ࡑࡉ࡙࠭෷")		:[JJA7fypmZFVlazvNI(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡭ࡱࡧࡽࡳ࡫ࡴ࠯ࡶࡲࡴࠬ෸")]
			,HDpmv4UXzlf72SK9(u"ࠧࡎࡃࡖࡅ࡛ࡏࡄࡆࡑࠪ෹")	:[PPAUFrY8cduRT(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨࡲ࠳ࡳࡡࡴࡣ࠱ࡲࡪࡽࡳࠨ෺")]
			,X2crmy67eZpkGTRd(u"ࠩࡓࡅࡓࡋࡔࠨ෻")		:[ELfMeDTIFhJt685K(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡻࡼࡽ࠮ࡱࡣࡱࡩࡹ࠴ࡣࡰ࠰࡬ࡰࠬ෼")]
			,C3ZK1pu4rfmj8TsWUtBaM(u"ࠫࡗࡋࡌࡆࡃࡖࡉࡘ࠭෽")		:[knTyjJ0sGIzuwbxRae(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡵࡸࡶ࡬࡫࠮ࡴࡪ࠲࡯ࡴࡪࡩ࠰ࡧࡰࡥࡩࡥࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷ࠴ࡵ࡬ࡥ࠱࡬ࡲࡩ࡫ࡸ࠯ࡪࡷࡱࡱ࠭෾")]
			,U0VwOviFaYPz2QGs45mJhMXf7Zk(u"࠭ࡓࡆࡔࡌࡉࡘ࡚ࡉࡎࡇࠪ෿")	:[CDwSWB4v39N7(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡤࡤ࠲ࡸ࡫ࡲࡪࡧࡶࡸ࡮ࡳࡥ࠯ࡥࡤࡱࠬ฀")]
			,owbMhINBQsmx70guApW(u"ࠨࡕࡋࡅࡍࡏࡄ࠵ࡗࠪก")		:[mgLADoQ1pbtY(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡷ࡭ࡧࡨࡩ࡫ࡨࡨ࠹ࡻ࠮࡯ࡧࡷࠫข")]
			,mg3CbXMA2ouZzQDhRqB(u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙࠷࠭ฃ")	:[U0VwOviFaYPz2QGs45mJhMXf7Zk(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹࡨࡢࡪ࡬ࡨ࠹ࡻ࠮ࡧࡱࡵࡹࡲ࠭ค")]
			,LHX65I9nkx0PstgcVY24uSi(u"࡙ࠬࡈࡂࡊࡌࡈࡓࡋࡗࡔࠩฅ")	:[KKi79PFqsYB0dWSRgaJ3DyE(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡳࡦ࠱ࡷ࡭࠺ࡵ࠯ࡰࡨࡻࡸ࠭ฆ")]
			,X2crmy67eZpkGTRd(u"ࠧࡔࡊࡒࡊࡍࡇࠧง")		:[SODvU3Ibq5VzC(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡶ࡬ࡴ࡬ࡨࡢ࠰ࡷࡺࠬจ")]
			,LHX65I9nkx0PstgcVY24uSi(u"ࠩࡖࡌࡔࡕࡆࡎࡃ࡛ࠫฉ")		:[maUl7SPesynF1j(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸ࡮࡯ࡰࡨࡰࡥࡽ࠴ࡣࡰ࡯ࠪช"),mg3CbXMA2ouZzQDhRqB(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹࡴࡢࡶ࡬ࡧ࠳ࡹࡨࡰࡱࡩࡱࡦࡾ࠮ࡤࡱࡰࠫซ"),ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡩࡱࡲࡪࡲࡧࡸ࠯ࡣࡽࡹࡷ࡫ࡥࡥࡩࡨ࠲ࡳ࡫ࡴࠨฌ")]
			,cWbkR6iUZsnJQj14(u"࠭ࡓࡉࡑࡒࡊࡓࡋࡔࠨญ")		:[X2crmy67eZpkGTRd(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡶ࠲ࡸ࡮࡯ࡰࡨࡱࡩࡹ࠴࡯࡯࡮࡬ࡲࡪ࠭ฎ")]
			,X2crmy67eZpkGTRd(u"ࠨࡖࡌࡏࡆࡇࡔࠨฏ")		:[mgLADoQ1pbtY(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡸ࡮ࡱࡡࡢࡶ࠱ࡲࡪࡺࠧฐ")]
			,owbMhINBQsmx70guApW(u"ࠪࡘ࡛ࡌࡕࡏࠩฑ")		:[C3ZK1pu4rfmj8TsWUtBaM(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹ࠮ࡵࡸࡩࡹࡳ࠴࡭ࡦࠩฒ")]
			,mg3CbXMA2ouZzQDhRqB(u"ࠬ࡜ࡁࡓࡄࡒࡒࠬณ")		:[EF2tvxZHz5n4UruPhaViXKycI6SQR(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡮࠰ࡹࡥࡷࡨ࡯࡯࠰ࡦࡥࡲ࠭ด")]
			,U0VwOviFaYPz2QGs45mJhMXf7Zk(u"ࠧࡗࡋࡇࡉࡔࡔࡓࡂࡇࡐࠫต")	:[knTyjJ0sGIzuwbxRae(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡹ࡭ࡩ࡫࡯࠯ࡰࡶࡥࡪࡳ࠮࡯ࡧࡷࠫถ")]
			,n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"࡚ࠩࡉࡈࡏࡍࡂ࠳ࠪท")		:[mgLADoQ1pbtY(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼ࡫ࡣࡪ࡯ࡤ࠲ࡩ࡯ࡲࡦࡥࡷࠫธ")]
			,X2crmy67eZpkGTRd(u"ࠫ࡜ࡋࡃࡊࡏࡄ࠶ࠬน")		:[k4IUieraScH9DV1N7pJgQosYAx5l(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡦࡥ࡬ࡱࡦ࠴ࡡࡤࠩบ")]
			,ShnRVsifKtc60zqQ(u"࡙࠭ࡂࡓࡒࡘࠬป")		:[dBi72erQEtKDOwjNFaoAgSP(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡻ࠱ࡽࡦࡷ࡯ࡵ࠰ࡷࡺࠬผ")]
			,n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩฝ")		:[CDwSWB4v39N7(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡥࡲࡱࠬพ")]
			,mg3CbXMA2ouZzQDhRqB(u"ࠪ࡝࡙ࡈ࡟ࡄࡊࡄࡒࡓࡋࡌࡔࠩฟ")	:[owbMhINBQsmx70guApW(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡧࡴࡳࠧภ")]
			,mgLADoQ1pbtY(u"ࠬࡏࡐࡕࡘࠪม")			:[HQmDERMFjx]
			,A0aqj9uclgOtByJ6F4bz(u"࠭ࡍ࠴ࡗࠪย")			:[HQmDERMFjx]
			,nz8x32hX0qcjUPFZk5RdJsiwED(u"ࠧࡓࡇࡓࡓࡘ࠭ร")		:[nz8x32hX0qcjUPFZk5RdJsiwED(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡳ࡫ࡴ࡭࡫ࡩࡽ࠳ࡧࡰࡱ࠱ࡎࡓࡉࡏࡒࡆࡒࡒ࠳ࡆࡊࡄࡐࡐࡖ࠳ࡦࡪࡤࡰࡰࡶ࠲ࡽࡳ࡬ࠨฤ"),YJxaX0MQOHb8oyCBFdnIAe(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡴࡥࡵ࡮࡬ࡪࡾ࠴ࡡࡱࡲ࠲ࡏࡔࡊࡉࡓࡇࡓࡓ࠴ࡇࡄࡅࡑࡑࡗ࠶࠾࠯ࡢࡦࡧࡳࡳࡹ࠱࠹࠰ࡻࡱࡱ࠭ล"),OzU6t0qcH7MQabeBYK8vgoG(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴࡮ࡦࡶ࡯࡭࡫ࡿ࠮ࡢࡲࡳ࠳ࡐࡕࡄࡊࡔࡈࡔࡔ࠵ࡁࡅࡆࡒࡒࡘ࠷࠹࠰ࡣࡧࡨࡴࡴࡳ࠲࠻࠱ࡼࡲࡲࠧฦ")]
			,JJA7fypmZFVlazvNI(u"ࠫࡗࡋࡐࡐࡕࡢࡆࡐࡖ࠱ࠨว")	:[cWbkR6iUZsnJQj14(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡧࡪࡶ࡫ࡹࡧ࠴ࡣࡰ࡯࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠵ࡋࡐࡆࡌ࠳ࡷࡧࡷ࠰ࡴࡨࡪࡸ࠵ࡨࡦࡣࡧࡷ࠴ࡳࡡࡴࡶࡨࡶ࠴ࡇࡄࡅࡑࡑࡗ࠴ࡧࡤࡥࡱࡱࡷ࠳ࡾ࡭࡭ࠩศ"),CDwSWB4v39N7(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡨ࡫ࡷ࡬ࡺࡨ࠮ࡤࡱࡰ࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠯ࡌࡑࡇࡍ࠴ࡸࡡࡸ࠱ࡵࡩ࡫ࡹ࠯ࡩࡧࡤࡨࡸ࠵࡭ࡢࡵࡷࡩࡷ࠵ࡁࡅࡆࡒࡒࡘ࠷࠸࠰ࡣࡧࡨࡴࡴࡳ࠲࠺࠱ࡼࡲࡲࠧษ"),EF2tvxZHz5n4UruPhaViXKycI6SQR(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡩ࡬ࡸ࡭ࡻࡢ࠯ࡥࡲࡱ࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠰ࡍࡒࡈࡎ࠵ࡲࡢࡹ࠲ࡶࡪ࡬ࡳ࠰ࡪࡨࡥࡩࡹ࠯࡮ࡣࡶࡸࡪࡸ࠯ࡂࡆࡇࡓࡓ࡙࠱࠺࠱ࡤࡨࡩࡵ࡮ࡴ࠳࠼࠲ࡽࡳ࡬ࠨส")]
			,OzU6t0qcH7MQabeBYK8vgoG(u"ࠨࡔࡈࡔࡔ࡙࡟ࡃࡍࡓ࠶ࠬห")	:[LHX65I9nkx0PstgcVY24uSi(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡲࡦࡲࡲ࠲ࡺࡱ࠮ࡵࡱ࠲ࡅࡉࡊࡏࡏࡕ࠲ࡥࡩࡪ࡯࡯ࡵ࠱ࡼࡲࡲࠧฬ"),EAVanJj1ers2GQud(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡳࡧࡳࡳ࠳ࡻ࡫࠯ࡶࡲ࠳ࡆࡊࡄࡐࡐࡖ࠵࠽࠵ࡡࡥࡦࡲࡲࡸ࠷࠸࠯ࡺࡰࡰࠬอ"),cWbkR6iUZsnJQj14(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡴࡨࡴࡴ࠴ࡵ࡬࠰ࡷࡳ࠴ࡇࡄࡅࡑࡑࡗ࠶࠿࠯ࡢࡦࡧࡳࡳࡹ࠱࠺࠰ࡻࡱࡱ࠭ฮ")]
			,n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"ࠬࡘࡅࡑࡑࡖࡣࡇࡑࡐ࠴ࠩฯ")	:[HDpmv4UXzlf72SK9(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡶࡪࡶ࡯࠯࡯ࡲࡳࡴ࠴ࡣࡰ࡯࠲ࡅࡉࡊࡏࡏࡕ࠲ࡥࡩࡪ࡯࡯ࡵ࠱ࡼࡲࡲࠧะ"),SODvU3Ibq5VzC(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡷ࡫ࡰࡰ࠰ࡰࡳࡴࡵ࠮ࡤࡱࡰ࠳ࡆࡊࡄࡐࡐࡖ࠵࠽࠵ࡡࡥࡦࡲࡲࡸ࠷࠸࠯ࡺࡰࡰࠬั"),JJA7fypmZFVlazvNI(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮ࡸࡥࡱࡱ࠱ࡱࡴࡵ࡯࠯ࡥࡲࡱ࠴ࡇࡄࡅࡑࡑࡗ࠶࠿࠯ࡢࡦࡧࡳࡳࡹ࠱࠺࠰ࡻࡱࡱ࠭า")]
			,mg3CbXMA2ouZzQDhRqB(u"ࠩࡎࡓࡉࡏ࡟ࡔࡑࡘࡖࡈࡋࡓࠨำ")	:[ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡹࡵࡳࡩࡨ࠲ࡸ࡮࠯࡬ࡱࡧ࡭ࠬิ"),mgLADoQ1pbtY(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲࡯ࡴࡪࡩࠨี"),n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠯ࡲࡼࡸ࡭ࡵ࡮ࡢࡰࡼࡻ࡭࡫ࡲࡦ࠰ࡦࡳࡲ࠵࡫ࡰࡦ࡬ࠫึ")]
			,HDpmv4UXzlf72SK9(u"࠭ࡆࡊࡎࡈࡗࡤ࡙ࡏࡖࡔࡆࡉࡘ࠭ื"):[SODvU3Ibq5VzC(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡱࡩࡹࡲࡩࡧࡻ࠱ࡥࡵࡶุࠧ")]
			,mg3CbXMA2ouZzQDhRqB(u"ࠨࡍࡒࡈࡎࡋࡍࡂࡆࡢࡅࡕࡖูࠧ")	:[EAVanJj1ers2GQud(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡷ࡭ࡳࡿ࠮ࡤࡥ࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨฺࠬ"),dBi72erQEtKDOwjNFaoAgSP(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴ࠴࠳࠵࠽࠴ࡦࡸࡵ࠱ࡷࡹࡵࡲࡦࠩ฻")]
			}
if CH7RKuDVzN9f06q8MtXPhlvIxakEWg:
	SITESURLS[LHX65I9nkx0PstgcVY24uSi(u"ࠫࡕ࡟ࡔࡉࡑࡑࠫ฼")]      = [EAVanJj1ers2GQud(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡸࡨࡶࡨ࡫࡬࠯ࡣࡳࡴ࠴ࡲࡩࡴࡶࡳࡰࡦࡿࠧ฽"),SODvU3Ibq5VzC(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵ࡵࡴࡣࡪࡩࡷ࡫ࡰࡰࡴࡷࠫ฾"),ShnRVsifKtc60zqQ(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡺࡪࡸࡣࡦ࡮࠱ࡥࡵࡶ࠯ࡴࡧࡱࡨࡪࡳࡡࡪ࡮ࠪ฿"),X2crmy67eZpkGTRd(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡻ࡫ࡲࡤࡧ࡯࠲ࡦࡶࡰ࠰ࡩࡨࡸࡲ࡫ࡳࡴࡣࡪࡩࡸ࠭เ"),k4IUieraScH9DV1N7pJgQosYAx5l(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡼࡥࡳࡥࡨࡰ࠳ࡧࡰࡱ࠱ࡪࡩࡹ࡯ࡳ࡭ࡣࡰ࡭ࡨ࠭แ"),LHX65I9nkx0PstgcVY24uSi(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲࡫ࡪࡺࡱࡶࡧࡶࡸ࡮ࡵ࡮ࡴࠩโ"),CDwSWB4v39N7(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡷࡧࡵࡧࡪࡲ࠮ࡢࡲࡳ࠳࡬࡫ࡴ࡬ࡰࡲࡻࡳ࡫ࡲࡳࡱࡵࡷࠬใ"),U0VwOviFaYPz2QGs45mJhMXf7Zk(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡸࡨࡶࡨ࡫࡬࠯ࡣࡳࡴ࠴ࡩࡡࡱࡶࡦ࡬ࡦ࠭ไ"),OBsrtQo2pPlgURCxJYbj9iXMD(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵ࡴࡦࡵࡷ࡭ࡳ࡭ࠧๅ"),LHX65I9nkx0PstgcVY24uSi(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡺࡪࡸࡣࡦ࡮࠱ࡥࡵࡶ࠯ࡨࡧࡷࡩࡽࡺࡲࡢࡲࡼࡸ࡭ࡵ࡮ࡤࡱࡧࡩࠬๆ"),KhUG1NV9bln5zXjptqFW6dgo(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡻ࡫ࡲࡤࡧ࡯࠲ࡦࡶࡰ࠰ࡧࡻࡩࡨࡻࡴࡦ࡬ࡶࠫ็"),SODvU3Ibq5VzC(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡼࡥࡳࡥࡨࡰ࠳ࡧࡰࡱ࠱ࡺࡩࡧࡩࡡࡤࡪࡨ่ࠫ")]
	SITESURLS[ELfMeDTIFhJt685K(u"ࠪࡔ࡞࡚ࡈࡐࡐࡢࡆࡐࡖ࠱ࠨ้")] = [maUl7SPesynF1j(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠯ࡲࡼࡸ࡭ࡵ࡮ࡢࡰࡼࡻ࡭࡫ࡲࡦ࠰ࡦࡳࡲ࠵࡬ࡪࡵࡷࡴࡱࡧࡹࠨ๊"),knTyjJ0sGIzuwbxRae(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠰ࡳࡽࡹ࡮࡯࡯ࡣࡱࡽࡼ࡮ࡥࡳࡧ࠱ࡧࡴࡳ࠯ࡶࡵࡤ࡫ࡪࡸࡥࡱࡱࡵࡸ๋ࠬ"),EAVanJj1ers2GQud(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠱ࡴࡾࡺࡨࡰࡰࡤࡲࡾࡽࡨࡦࡴࡨ࠲ࡨࡵ࡭࠰ࡵࡨࡲࡩ࡫࡭ࡢ࡫࡯ࠫ์"),PPAUFrY8cduRT(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠲ࡵࡿࡴࡩࡱࡱࡥࡳࡿࡷࡩࡧࡵࡩ࠳ࡩ࡯࡮࠱ࡪࡩࡹࡳࡥࡴࡵࡤ࡫ࡪࡹࠧํ"),PPAUFrY8cduRT(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠳ࡶࡹࡵࡪࡲࡲࡦࡴࡹࡸࡪࡨࡶࡪ࠴ࡣࡰ࡯࠲࡫ࡪࡺࡩࡴ࡮ࡤࡱ࡮ࡩࠧ๎"),ELfMeDTIFhJt685K(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠴ࡰࡺࡶ࡫ࡳࡳࡧ࡮ࡺࡹ࡫ࡩࡷ࡫࠮ࡤࡱࡰ࠳࡬࡫ࡴࡲࡷࡨࡷࡹ࡯࡯࡯ࡵࠪ๏"),ELfMeDTIFhJt685K(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠮ࡱࡻࡷ࡬ࡴࡴࡡ࡯ࡻࡺ࡬ࡪࡸࡥ࠯ࡥࡲࡱ࠴࡭ࡥࡵ࡭ࡱࡳࡼࡴࡥࡳࡴࡲࡶࡸ࠭๐"),OzU6t0qcH7MQabeBYK8vgoG(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠯ࡲࡼࡸ࡭ࡵ࡮ࡢࡰࡼࡻ࡭࡫ࡲࡦ࠰ࡦࡳࡲ࠵ࡣࡢࡲࡷࡧ࡭ࡧࠧ๑"),ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠰ࡳࡽࡹ࡮࡯࡯ࡣࡱࡽࡼ࡮ࡥࡳࡧ࠱ࡧࡴࡳ࠯ࡵࡧࡶࡸ࡮ࡴࡧࠨ๒"),CDwSWB4v39N7(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠱ࡴࡾࡺࡨࡰࡰࡤࡲࡾࡽࡨࡦࡴࡨ࠲ࡨࡵ࡭࠰ࡩࡨࡸࡪࡾࡴࡳࡣࡳࡽࡹ࡮࡯࡯ࡥࡲࡨࡪ࠭๓"),mgLADoQ1pbtY(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠲ࡵࡿࡴࡩࡱࡱࡥࡳࡿࡷࡩࡧࡵࡩ࠳ࡩ࡯࡮࠱ࡨࡼࡪࡩࡵࡵࡧ࡭ࡷࠬ๔"),dBi72erQEtKDOwjNFaoAgSP(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠳ࡶࡹࡵࡪࡲࡲࡦࡴࡹࡸࡪࡨࡶࡪ࠴ࡣࡰ࡯࠲ࡻࡪࡨࡣࡢࡥ࡫ࡩࠬ๕")]
	SITESURLS[HDpmv4UXzlf72SK9(u"ࠩࡓ࡝࡙ࡎࡏࡏࡡࡅࡏࡕ࠸ࠧ๖")] = [PPAUFrY8cduRT(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡷࡪࡸࡶࡦࡴ࠴࠲ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡦࡳࡧࡨࡨࡩࡴࡳ࠯ࡱࡵ࡫࠴ࡲࡩࡴࡶࡳࡰࡦࡿࠧ๗"),owbMhINBQsmx70guApW(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡸ࡫ࡲࡷࡧࡵ࠵࠳ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡧࡴࡨࡩࡩࡪ࡮ࡴ࠰ࡲࡶ࡬࠵ࡵࡴࡣࡪࡩࡷ࡫ࡰࡰࡴࡷࠫ๘"),PPAUFrY8cduRT(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡹࡥࡳࡸࡨࡶ࠶࠴࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡨࡵࡩࡪࡪࡤ࡯ࡵ࠱ࡳࡷ࡭࠯ࡴࡧࡱࡨࡪࡳࡡࡪ࡮ࠪ๙"),maUl7SPesynF1j(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡳࡦࡴࡹࡩࡷ࠷࠮࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡩࡶࡪ࡫ࡤࡥࡰࡶ࠲ࡴࡸࡧ࠰ࡩࡨࡸࡲ࡫ࡳࡴࡣࡪࡩࡸ࠭๚"),nz8x32hX0qcjUPFZk5RdJsiwED(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡴࡧࡵࡺࡪࡸ࠱࠯࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡪࡷ࡫ࡥࡥࡦࡱࡷ࠳ࡵࡲࡨ࠱ࡪࡩࡹ࡯ࡳ࡭ࡣࡰ࡭ࡨ࠭๛"),ShnRVsifKtc60zqQ(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡵࡨࡶࡻ࡫ࡲ࠲࠰࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲࡫ࡸࡥࡦࡦࡧࡲࡸ࠴࡯ࡳࡩ࠲࡫ࡪࡺࡱࡶࡧࡶࡸ࡮ࡵ࡮ࡴࠩ๜"),C3ZK1pu4rfmj8TsWUtBaM(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡶࡩࡷࡼࡥࡳ࠳࠱࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳࡬ࡲࡦࡧࡧࡨࡳࡹ࠮ࡰࡴࡪ࠳࡬࡫ࡴ࡬ࡰࡲࡻࡳ࡫ࡲࡳࡱࡵࡷࠬ๝"),mg3CbXMA2ouZzQDhRqB(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡷࡪࡸࡶࡦࡴ࠴࠲ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡦࡳࡧࡨࡨࡩࡴࡳ࠯ࡱࡵ࡫࠴ࡩࡡࡱࡶࡦ࡬ࡦ࠭๞"),U0VwOviFaYPz2QGs45mJhMXf7Zk(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡸ࡫ࡲࡷࡧࡵ࠵࠳ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡧࡴࡨࡩࡩࡪ࡮ࡴ࠰ࡲࡶ࡬࠵ࡴࡦࡵࡷ࡭ࡳ࡭ࠧ๟"),HDpmv4UXzlf72SK9(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡹࡥࡳࡸࡨࡶ࠶࠴࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡨࡵࡩࡪࡪࡤ࡯ࡵ࠱ࡳࡷ࡭࠯ࡨࡧࡷࡩࡽࡺࡲࡢࡲࡼࡸ࡭ࡵ࡮ࡤࡱࡧࡩࠬ๠"),JJA7fypmZFVlazvNI(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡳࡦࡴࡹࡩࡷ࠷࠮࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡩࡶࡪ࡫ࡤࡥࡰࡶ࠲ࡴࡸࡧ࠰ࡧࡻࡩࡨࡻࡴࡦ࡬ࡶࠫ๡"),owbMhINBQsmx70guApW(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡴࡧࡵࡺࡪࡸ࠱࠯࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡪࡷ࡫ࡥࡥࡦࡱࡷ࠳ࡵࡲࡨ࠱ࡺࡩࡧࡩࡡࡤࡪࡨࠫ๢")]
	SITESURLS[pCTzbw4GyVJHjkcIMQ(u"ࠨࡒ࡜ࡘࡍࡕࡎࡠࡄࡎࡔ࠸࠭๣")] = [EAVanJj1ers2GQud(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡺࡱ࠮ࡵࡱ࠲ࡰ࡮ࡹࡴࡱ࡮ࡤࡽࠬ๤"),owbMhINBQsmx70guApW(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡻ࡫࠯ࡶࡲ࠳ࡺࡹࡡࡨࡧࡵࡩࡵࡵࡲࡵࠩ๥"),jL1E5AKfwBDv6xmeQtUXcJ3d(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡵ࡬࠰ࡷࡳ࠴ࡹࡥ࡯ࡦࡨࡱࡦ࡯࡬ࠨ๦"),EF2tvxZHz5n4UruPhaViXKycI6SQR(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡶ࡭࠱ࡸࡴ࠵ࡧࡦࡶࡰࡩࡸࡹࡡࡨࡧࡶࠫ๧"),OzU6t0qcH7MQabeBYK8vgoG(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡷ࡮࠲ࡹࡵ࠯ࡨࡧࡷ࡭ࡸࡲࡡ࡮࡫ࡦࠫ๨"),A0aqj9uclgOtByJ6F4bz(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡸ࡯࠳ࡺ࡯࠰ࡩࡨࡸࡶࡻࡥࡴࡶ࡬ࡳࡳࡹࠧ๩"),mgLADoQ1pbtY(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡹࡰ࠴ࡴࡰ࠱ࡪࡩࡹࡱ࡮ࡰࡹࡱࡩࡷࡸ࡯ࡳࡵࠪ๪"),maUl7SPesynF1j(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡺࡱ࠮ࡵࡱ࠲ࡧࡦࡶࡴࡤࡪࡤࠫ๫"),HDpmv4UXzlf72SK9(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡻ࡫࠯ࡶࡲ࠳ࡹ࡫ࡳࡵ࡫ࡱ࡫ࠬ๬"),Tcf5Ppn9UajDbzyM(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡵ࡬࠰ࡷࡳ࠴࡭ࡥࡵࡧࡻࡸࡷࡧࡰࡺࡶ࡫ࡳࡳࡩ࡯ࡥࡧࠪ๭"),LHX65I9nkx0PstgcVY24uSi(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡶ࡭࠱ࡸࡴ࠵ࡥࡹࡧࡦࡹࡹ࡫ࡪࡴࠩ๮"),C3ZK1pu4rfmj8TsWUtBaM(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡷ࡮࠲ࡹࡵ࠯ࡸࡧࡥࡧࡦࡩࡨࡦࠩ๯")]
else:
	SITESURLS[k4IUieraScH9DV1N7pJgQosYAx5l(u"ࠧࡑ࡛ࡗࡌࡔࡔࠧ๰")]      = [ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱࡯࡭ࡸࡺࡰ࡭ࡣࡼࠫ๱"),KhUG1NV9bln5zXjptqFW6dgo(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡹࡸࡧࡧࡦࡴࡨࡴࡴࡸࡴࠨ๲"),OBsrtQo2pPlgURCxJYbj9iXMD(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡸ࡫࡮ࡥࡧࡰࡥ࡮ࡲࠧ๳"),KhUG1NV9bln5zXjptqFW6dgo(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵ࡯ࡨࡷࡸࡧࡧࡦࡵࠪ๴"),JJA7fypmZFVlazvNI(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶ࡬ࡷࡱࡧ࡭ࡪࡥࠪ๵"),EF2tvxZHz5n4UruPhaViXKycI6SQR(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ࠭๶"),X2crmy67eZpkGTRd(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸࡰࡴ࡯ࡸࡰࡨࡶࡷࡵࡲࡴࠩ๷"),dBi72erQEtKDOwjNFaoAgSP(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡦࡥࡵࡺࡣࡩࡣࠪ๸"),YJxaX0MQOHb8oyCBFdnIAe(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡸࡪࡹࡴࡪࡰࡪࠫ๹"),CDwSWB4v39N7(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴࡦࡺࡷࡶࡦࡶࡹࡵࡪࡲࡲࡨࡵࡤࡦࠩ๺"),knTyjJ0sGIzuwbxRae(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡫ࡸࡦࡥࡸࡸࡪࡰࡳࠨ๻"),C3ZK1pu4rfmj8TsWUtBaM(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡷࡦࡤࡦࡥࡨ࡮ࡥࠨ๼")]
	SITESURLS[U0VwOviFaYPz2QGs45mJhMXf7Zk(u"࠭ࡐ࡚ࡖࡋࡓࡓࡥࡂࡌࡒ࠴ࠫ๽")] = [pCTzbw4GyVJHjkcIMQ(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰࡮࡬ࡷࡹࡶ࡬ࡢࡻࠪ๾"),ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡸࡷࡦ࡭ࡥࡳࡧࡳࡳࡷࡺࠧ๿"),A0aqj9uclgOtByJ6F4bz(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡷࡪࡴࡤࡦ࡯ࡤ࡭ࡱ࠭຀"),OzU6t0qcH7MQabeBYK8vgoG(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴ࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩກ"),YJxaX0MQOHb8oyCBFdnIAe(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵ࡫ࡶࡰࡦࡳࡩࡤࠩຂ"),dBi72erQEtKDOwjNFaoAgSP(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶࡴࡹࡪࡹࡴࡪࡱࡱࡷࠬ຃"),EAVanJj1ers2GQud(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷ࡯ࡳࡵࡷ࡯ࡧࡵࡶࡴࡸࡳࠨຄ"),knTyjJ0sGIzuwbxRae(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡥࡤࡴࡹࡩࡨࡢࠩ຅"),PPAUFrY8cduRT(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡷࡩࡸࡺࡩ࡯ࡩࠪຆ"),CDwSWB4v39N7(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺࡥࡹࡶࡵࡥࡵࡿࡴࡩࡱࡱࡧࡴࡪࡥࠨງ"),dBi72erQEtKDOwjNFaoAgSP(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡪࡾࡥࡤࡷࡷࡩ࡯ࡹࠧຈ"),knTyjJ0sGIzuwbxRae(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡽࡥࡣࡥࡤࡧ࡭࡫ࠧຉ")]
	SITESURLS[owbMhINBQsmx70guApW(u"ࠬࡖ࡙ࡕࡊࡒࡒࡤࡈࡋࡑ࠴ࠪຊ")] = [k4IUieraScH9DV1N7pJgQosYAx5l(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯࡭࡫ࡶࡸࡵࡲࡡࡺࠩ຋"),EAVanJj1ers2GQud(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡷࡶࡥ࡬࡫ࡲࡦࡲࡲࡶࡹ࠭ຌ"),PPAUFrY8cduRT(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡶࡩࡳࡪࡥ࡮ࡣ࡬ࡰࠬຍ"),C3ZK1pu4rfmj8TsWUtBaM(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺ࡭ࡦࡵࡶࡥ࡬࡫ࡳࠨຎ"),knTyjJ0sGIzuwbxRae(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴࡪࡵ࡯ࡥࡲ࡯ࡣࠨຏ"),jL1E5AKfwBDv6xmeQtUXcJ3d(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵࡳࡸࡩࡸࡺࡩࡰࡰࡶࠫຐ"),YJxaX0MQOHb8oyCBFdnIAe(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶ࡮ࡲࡴࡽ࡮ࡦࡴࡵࡳࡷࡹࠧຑ"),k4IUieraScH9DV1N7pJgQosYAx5l(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡤࡣࡳࡸࡨ࡮ࡡࠨຒ"),pCTzbw4GyVJHjkcIMQ(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡶࡨࡷࡹ࡯࡮ࡨࠩຓ"),nz8x32hX0qcjUPFZk5RdJsiwED(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹ࡫ࡸࡵࡴࡤࡴࡾࡺࡨࡰࡰࡦࡳࡩ࡫ࠧດ"),cWbkR6iUZsnJQj14(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡩࡽ࡫ࡣࡶࡶࡨ࡮ࡸ࠭ຕ"),dBi72erQEtKDOwjNFaoAgSP(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡼ࡫ࡢࡤࡣࡦ࡬ࡪ࠭ຖ")]
	SITESURLS[OzU6t0qcH7MQabeBYK8vgoG(u"ࠫࡕ࡟ࡔࡉࡑࡑࡣࡇࡑࡐ࠴ࠩທ")] = [mgLADoQ1pbtY(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵࡬ࡪࡵࡷࡴࡱࡧࡹࠨຘ"),ShnRVsifKtc60zqQ(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡶࡵࡤ࡫ࡪࡸࡥࡱࡱࡵࡸࠬນ"),nz8x32hX0qcjUPFZk5RdJsiwED(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡵࡨࡲࡩ࡫࡭ࡢ࡫࡯ࠫບ"),ShnRVsifKtc60zqQ(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹࡳࡥࡴࡵࡤ࡫ࡪࡹࠧປ"),knTyjJ0sGIzuwbxRae(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺࡩࡴ࡮ࡤࡱ࡮ࡩࠧຜ"),HDpmv4UXzlf72SK9(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴࡲࡷࡨࡷࡹ࡯࡯࡯ࡵࠪຝ"),A0aqj9uclgOtByJ6F4bz(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵ࡭ࡱࡳࡼࡴࡥࡳࡴࡲࡶࡸ࠭ພ"),PPAUFrY8cduRT(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡣࡢࡲࡷࡧ࡭ࡧࠧຟ"),pCTzbw4GyVJHjkcIMQ(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡵࡧࡶࡸ࡮ࡴࡧࠨຠ"),A0aqj9uclgOtByJ6F4bz(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸࡪࡾࡴࡳࡣࡳࡽࡹ࡮࡯࡯ࡥࡲࡨࡪ࠭ມ"),X2crmy67eZpkGTRd(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡨࡼࡪࡩࡵࡵࡧ࡭ࡷࠬຢ"),maUl7SPesynF1j(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡻࡪࡨࡣࡢࡥ࡫ࡩࠬຣ")]
api_python_actions = [dBi72erQEtKDOwjNFaoAgSP(u"ࠪࡐࡎ࡙ࡔࡑࡎࡄ࡝ࠬ຤"),nz8x32hX0qcjUPFZk5RdJsiwED(u"ࠫࡗࡋࡐࡐࡔࡗࡗࠬລ"),EAVanJj1ers2GQud(u"ࠬࡋࡍࡂࡋࡏࡗࠬ຦"),mg3CbXMA2ouZzQDhRqB(u"࠭ࡍࡆࡕࡖࡅࡌࡋࡓࠨວ"),mgLADoQ1pbtY(u"ࠧࡊࡕࡏࡅࡒࡏࡃࡔࠩຨ"),nz8x32hX0qcjUPFZk5RdJsiwED(u"ࠨࡓࡘࡉࡘ࡚ࡉࡐࡐࡖࠫຩ"),cWbkR6iUZsnJQj14(u"ࠩࡎࡒࡔ࡝ࡎࡆࡔࡕࡓࡗ࡙ࠧສ"),JJA7fypmZFVlazvNI(u"ࠪࡇࡆࡖࡔࡄࡊࡄࠫຫ"),n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"࡙ࠫࡋࡓࡕࡋࡑࡋࠬຬ"),LHX65I9nkx0PstgcVY24uSi(u"ࠬࡋࡘࡕࡔࡄࡔ࡞࡚ࡈࡐࡐࡆࡓࡉࡋࠧອ"),dBi72erQEtKDOwjNFaoAgSP(u"࠭ࡅ࡙ࡇࡆ࡙࡙ࡋࡊࡔࠩຮ"),n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"ࠧࡘࡇࡅࡇࡆࡉࡈࡆࠩຯ")]
api_repos_actions = [OBsrtQo2pPlgURCxJYbj9iXMD(u"ࠨࡃࡇࡈࡔࡔࡓࠨະ"),jL1E5AKfwBDv6xmeQtUXcJ3d(u"ࠩࡄࡈࡉࡕࡎࡔ࠳࠻ࠫັ"),k4IUieraScH9DV1N7pJgQosYAx5l(u"ࠪࡅࡉࡊࡏࡏࡕ࠴࠽ࠬາ")]
non_videos_actions = [LHX65I9nkx0PstgcVY24uSi(u"ࠫࡆࡒࡌࠨຳ"),CDwSWB4v39N7(u"ࠬࡖ࡙ࡕࡊࡒࡒࠬິ"),mg3CbXMA2ouZzQDhRqB(u"࠭ࡉࡏࡕࡗࡅࡑࡒࠧີ"),k4IUieraScH9DV1N7pJgQosYAx5l(u"ࠧࡎࡇࡗࡖࡔࡖࡏࡍࡋࡖࠫຶ"),dBi72erQEtKDOwjNFaoAgSP(u"ࠨࡔࡈࡔࡔ࡙ࠧື"),ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"ࠩࡇࡓࡓࡇࡔࡊࡑࡑࡗຸࠬ"),A0aqj9uclgOtByJ6F4bz(u"ࠪࡇࡆࡖࡔࡄࡊࡄࡍࡉູ࠭"),nz8x32hX0qcjUPFZk5RdJsiwED(u"ࠫࡈࡇࡐࡕࡅࡋࡅ࡙ࡕࡋࡆࡐ຺ࠪ"),HDpmv4UXzlf72SK9(u"ࠬࡉࡁࡑࡖࡆࡌࡆࡍࡅࡕࡋࡇࠫົ"),maUl7SPesynF1j(u"࠭ࡓࡊࡖࡈࡗ࡚ࡘࡌࡔࠩຼ")]+api_python_actions+api_repos_actions
UIW5gSJKhQVyPdNGMamD3nLl = mic3MEN709xOkrjD5ZvbGIlX6
sfR3pZ7rhTlc = gyd2rf0UR5
gYWMTQAJqayd9VOPKNf7c6pbtej4w5 = mic3MEN709xOkrjD5ZvbGIlX6
rE7CO4gbqvZWSU3L = mic3MEN709xOkrjD5ZvbGIlX6
avprivsnorestrict = mic3MEN709xOkrjD5ZvbGIlX6
avprivslongperiod = mic3MEN709xOkrjD5ZvbGIlX6
resolveonly = mic3MEN709xOkrjD5ZvbGIlX6
JotSelVcQp7bNqgKxvOZ46fThWA8 = mic3MEN709xOkrjD5ZvbGIlX6
ALLOW_DNS_FIX = BFavj14P9QklUhIz67CLNmwDEMsrbp
ALLOW_PROXY_FIX = BFavj14P9QklUhIz67CLNmwDEMsrbp
ALLOW_SHOWDIALOGS_FIX = BFavj14P9QklUhIz67CLNmwDEMsrbp
menuItemsLIST = []
SEND_THESE_EVENTS = []
SAVED_FORWARDS = {}
menuItemsDICT = {}
BADSCRAPERS = []
WEBCACHEDATA = {}
BADWEBSITES = [A0aqj9uclgOtByJ6F4bz(u"ࠧࡇࡗࡖࡌࡆࡘࡔࡗࠩຽ"),mg3CbXMA2ouZzQDhRqB(u"ࠨࡆࡕࡅࡒࡇࡃࡂࡈࡈࠫ຾"),mgLADoQ1pbtY(u"ࠩࡆࡍࡒࡇ࠴࠱࠲ࠪ຿"),pCTzbw4GyVJHjkcIMQ(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠸ࠬເ"),mgLADoQ1pbtY(u"ࠫࡑࡇࡒࡐ࡜ࡄࠫແ"),mgLADoQ1pbtY(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠷ࠧໂ"),Tcf5Ppn9UajDbzyM(u"࡙࠭ࡂࡓࡒࡘࠬໃ"),k4IUieraScH9DV1N7pJgQosYAx5l(u"ࠧࡗࡃࡕࡆࡔࡔࠧໄ"),owbMhINBQsmx70guApW(u"ࠨࡊࡄࡐࡆࡉࡉࡎࡃࠪ໅"),PPAUFrY8cduRT(u"ࠩࡓࡅࡓࡋࡔࠨໆ"),dBi72erQEtKDOwjNFaoAgSP(u"ࠪࡗࡍࡇࡂࡂࡍࡄࡘ࡞࠭໇")]
BADWEBSITES += [OzU6t0qcH7MQabeBYK8vgoG(u"ࠫࡋࡇࡂࡓࡃࡎࡅ່ࠬ"),OBsrtQo2pPlgURCxJYbj9iXMD(u"ࠬࡋࡌࡊࡈ࡙ࡍࡉࡋࡏࠨ້"),ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"࠭ࡃࡊࡏࡄࡒࡔ࡝໊ࠧ"),A0aqj9uclgOtByJ6F4bz(u"ࠧࡕࡘࡉ࡙ࡓ໋࠭"),LHX65I9nkx0PstgcVY24uSi(u"ࠨࡈࡘࡒࡔࡔࡔࡗࠩ໌")]
BADCOMMONIDS = [HDpmv4UXzlf72SK9(u"ࠩ࠼࠽࠾࠿࠭࠺࠻࠼࠽࠲࠿࠹࠺࠻࠰࠽࠾࠿࠹࠮࠲࠳࠴࠵࠭ໍ"),HDpmv4UXzlf72SK9(u"ࠪ࠽࠾࠾࠸࠮࠹࠺࠺࠻࠳࠵࠶࠶࠷࠱࠸࠹࠲࠳࠯࠵࠴࠽࠼ࠧ໎")]
GEOLOCATION_DATA = HQmDERMFjx
AV_CLIENT_IDS = HQmDERMFjx
DNS_SERVERS = [SODvU3Ibq5VzC(u"ࠫ࠶࠴࠱࠯࠳࠱࠵ࠬ໏"),ELfMeDTIFhJt685K(u"ࠬ࠾࠮࠹࠰࠻࠲࠽࠭໐"),HDpmv4UXzlf72SK9(u"࠭࠱࠯࠲࠱࠴࠳࠷ࠧ໑"),OzU6t0qcH7MQabeBYK8vgoG(u"ࠧ࠹࠰࠻࠲࠹࠴࠴ࠨ໒"),X2crmy67eZpkGTRd(u"ࠨ࠴࠳࠼࠳࠼࠷࠯࠴࠵࠶࠳࠸࠲࠳ࠩ໓"),EF2tvxZHz5n4UruPhaViXKycI6SQR(u"ࠩ࠵࠴࠽࠴࠶࠸࠰࠵࠶࠵࠴࠲࠳࠲ࠪ໔")]
busydialog_active = mic3MEN709xOkrjD5ZvbGIlX6
dns_succeeded_urls = []
scrapers_succeeded = mic3MEN709xOkrjD5ZvbGIlX6
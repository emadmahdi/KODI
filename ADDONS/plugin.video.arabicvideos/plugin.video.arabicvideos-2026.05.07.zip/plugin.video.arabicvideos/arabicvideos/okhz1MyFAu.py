# -*- coding: utf-8 -*-
from FF68kA5BUy import *
HDLtdMAy7wPkl8aKC3O2 = 'EGYNOW'
EEJvXQzSZNt = '_EGN_'
e2VR8nohduY = Jzthpc2nj5.SITESURLS[HDLtdMAy7wPkl8aKC3O2][0]
FwhZ0nXtpoHTMarf = ['عروض مصارعة','الكل','n/A','المزيد','قصة عشق']
def kk6X5LxpsND(mode,url,text):
	if   mode==430: zLZUkrP7ac5 = afkxo7FyZWB4O6K1eXrs5I()
	elif mode==431: zLZUkrP7ac5 = c8wfGju4CWZm(url,text)
	elif mode==432: zLZUkrP7ac5 = f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url)
	elif mode==433: zLZUkrP7ac5 = XONC9osGSP4fW5HVrhM(url)
	elif mode==434: zLZUkrP7ac5 = ooxUXkcTj5PF4ad2SwYy(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==435: zLZUkrP7ac5 = ooxUXkcTj5PF4ad2SwYy(url,'SPECIFIED_FILTER___'+text)
	elif mode==436: zLZUkrP7ac5 = REWBU20fyqaLprY(url)
	elif mode==437: zLZUkrP7ac5 = cc8Imp2jUeEJBit1ZVCzk(url)
	elif mode==439: zLZUkrP7ac5 = hm4kawIPKp3oMrC75dJZA9HS2(text)
	else: zLZUkrP7ac5 = False
	return zLZUkrP7ac5
def afkxo7FyZWB4O6K1eXrs5I():
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',e2VR8nohduY+'/films',HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'EGYNOW-MENU-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	EFDgdaV4WT6U2yotAPX1B = DyVGS3dX0ZxR.findall('"canonical" href="(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	EFDgdaV4WT6U2yotAPX1B = EFDgdaV4WT6U2yotAPX1B[0].strip(xufJqQcGnhboiVy2wd)
	EFDgdaV4WT6U2yotAPX1B = DpClq35GVjh(EFDgdaV4WT6U2yotAPX1B,'url')
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'بحث في الموقع',HQmDERMFjx,439,HQmDERMFjx,HQmDERMFjx,'_REMEMBERRESULTS_')
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'فلتر محدد',EFDgdaV4WT6U2yotAPX1B,435)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'فلتر كامل',EFDgdaV4WT6U2yotAPX1B,434)
	CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+'المضاف حديثا',EFDgdaV4WT6U2yotAPX1B,431)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+'افلام اون لاين',EFDgdaV4WT6U2yotAPX1B+'/films1',436)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+'مسلسلات اون لاين',EFDgdaV4WT6U2yotAPX1B+'/series-all1',436)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+'قائمة تفصيلية',EFDgdaV4WT6U2yotAPX1B,437)
	CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"SiteNavigation"(.*?)"Search"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	items = DyVGS3dX0ZxR.findall('href="(.*?)".*?>(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	for vn1grP3y4It9GmVuBbLJfz2A,title in items:
		if title in FwhZ0nXtpoHTMarf: continue
		if title=='الرئيسية': continue
		if 'اون لاين' in title: continue
		CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,431)
	return
def cc8Imp2jUeEJBit1ZVCzk(website=HQmDERMFjx):
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',website+'/films',HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'EGYNOW-MENU-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	EFDgdaV4WT6U2yotAPX1B = DyVGS3dX0ZxR.findall('"canonical" href="(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	EFDgdaV4WT6U2yotAPX1B = EFDgdaV4WT6U2yotAPX1B[0].strip(xufJqQcGnhboiVy2wd)
	EFDgdaV4WT6U2yotAPX1B = DpClq35GVjh(EFDgdaV4WT6U2yotAPX1B,'url')
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"ListDroped"(.*?)"SearchingMaster"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	items = DyVGS3dX0ZxR.findall('data-tax="(.*?)" data-term="(.*?)" data-name="(.*?)"',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	for WF2vkePC5gbXAGUarcqlpmB3Q,value,title in items:
		if title in FwhZ0nXtpoHTMarf: continue
		vn1grP3y4It9GmVuBbLJfz2A = website+'/explore/?'+WF2vkePC5gbXAGUarcqlpmB3Q+'='+value
		CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,431)
	return
def REWBU20fyqaLprY(url):
	EFDgdaV4WT6U2yotAPX1B = DpClq35GVjh(url,'url')
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'EGYNOW-SUBMENU-1st')
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'الجميع',url,431)
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"titleSectionCon"(.*?)</div></div>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	items = DyVGS3dX0ZxR.findall('data-key="(.*?)".*?<em>(.*?)</em>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	for KPloNJnsZ2kpHhum1,title in items:
		if title in FwhZ0nXtpoHTMarf: continue
		SSHjMN4uegZfb2 = EFDgdaV4WT6U2yotAPX1B+'/wp-content/themes/EgyNowByElshaikh/Ajaxt/Movies/Keys.php?key='+KPloNJnsZ2kpHhum1
		CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,SSHjMN4uegZfb2,431)
	return
def c8wfGju4CWZm(url,S46ZVrhN1gWY0Iiaj=HQmDERMFjx):
	EFDgdaV4WT6U2yotAPX1B = DpClq35GVjh(url,'url')
	items = []
	if '/Terms.php' in url or '/Get.php' in url or '/Keys.php' in url:
		SSHjMN4uegZfb2,Vi9fwvbSBCI0K6hgXA8EpFrT = Oy2YNHPzuJl(url)
		nJayb3s5zlOgQh9BwiCdEDq = {'X-Requested-With':'XMLHttpRequest','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'POST',SSHjMN4uegZfb2,Vi9fwvbSBCI0K6hgXA8EpFrT,nJayb3s5zlOgQh9BwiCdEDq,HQmDERMFjx,HQmDERMFjx,'EGYNOW-TITLES-1st')
		CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
		MJ2gSPyTl9hzoi1 = CzNPJydxQLfw27tv4ZF8KORAbX5
	elif S46ZVrhN1gWY0Iiaj=='featured':
		vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'EGYNOW-TITLES-2nd')
		CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"MainSlider"(.*?)"MatchesTable"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('<a href="([^"]*)" title="([^"]*)".*?image: url\((.*?)\)',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	else:
		vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'EGYNOW-TITLES-2nd')
		CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"BlocksList"(.*?)"Paginate"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if not Ut7reR0XioMjOdYWZKsLIuc3TQJmC1: Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"BlocksList"(.*?)"titleSectionCon"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	if not items: items = DyVGS3dX0ZxR.findall('<a href="([^"]*)" title="([^"]*)".*?data-image="(.*?)"',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	ORMkTYjJ1p7 = []
	smLQwgO0BynVCcl3fYJ = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for vn1grP3y4It9GmVuBbLJfz2A,title,uIGD4vZcP61QNmw78LXqoEpH in items:
		vn1grP3y4It9GmVuBbLJfz2A = xx9LK4VzpF6IHXSEyhmrQwbg25P0(vn1grP3y4It9GmVuBbLJfz2A).strip(xufJqQcGnhboiVy2wd)
		title = SVsiEWeRf6oIynqQx8pCrM4Tk(title)
		yTz8SOkAhu24j6apo9BmZHvwWsX = DyVGS3dX0ZxR.findall('(.*?) الحلقة \d+',title,DyVGS3dX0ZxR.DOTALL)
		if any(value in title for value in smLQwgO0BynVCcl3fYJ):
			CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,432,uIGD4vZcP61QNmw78LXqoEpH)
		elif yTz8SOkAhu24j6apo9BmZHvwWsX and 'الحلقة' in title:
			title = '_MOD_' + yTz8SOkAhu24j6apo9BmZHvwWsX[0]
			if title not in ORMkTYjJ1p7:
				CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,433,uIGD4vZcP61QNmw78LXqoEpH)
				ORMkTYjJ1p7.append(title)
		elif '/movseries/' in vn1grP3y4It9GmVuBbLJfz2A:
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,431,uIGD4vZcP61QNmw78LXqoEpH)
		else: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,433,uIGD4vZcP61QNmw78LXqoEpH)
	if S46ZVrhN1gWY0Iiaj!='featured':
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"Paginate"(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
			MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
			items = DyVGS3dX0ZxR.findall('href="(.*?)">(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
			for vn1grP3y4It9GmVuBbLJfz2A,title in items:
				if 'http' not in vn1grP3y4It9GmVuBbLJfz2A: vn1grP3y4It9GmVuBbLJfz2A = EFDgdaV4WT6U2yotAPX1B+vn1grP3y4It9GmVuBbLJfz2A
				vn1grP3y4It9GmVuBbLJfz2A = SVsiEWeRf6oIynqQx8pCrM4Tk(vn1grP3y4It9GmVuBbLJfz2A)
				title = SVsiEWeRf6oIynqQx8pCrM4Tk(title)
				if title!=HQmDERMFjx: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'صفحة '+title,vn1grP3y4It9GmVuBbLJfz2A,431)
		cRGB60IvVUsywkjqu = DyVGS3dX0ZxR.findall('showmore" href="(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if cRGB60IvVUsywkjqu:
			vn1grP3y4It9GmVuBbLJfz2A = cRGB60IvVUsywkjqu[0]
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'مشاهدة المزيد',vn1grP3y4It9GmVuBbLJfz2A,431)
	return
def XONC9osGSP4fW5HVrhM(url):
	EFDgdaV4WT6U2yotAPX1B = DpClq35GVjh(url,'url')
	cOUkMZagDQftHLBoCivP,vuylTosVej845YfDNK = [],[]
	if 'Episodes.php' in url:
		SSHjMN4uegZfb2,Vi9fwvbSBCI0K6hgXA8EpFrT = Oy2YNHPzuJl(url)
		nJayb3s5zlOgQh9BwiCdEDq = {'X-Requested-With':'XMLHttpRequest','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'POST',SSHjMN4uegZfb2,Vi9fwvbSBCI0K6hgXA8EpFrT,nJayb3s5zlOgQh9BwiCdEDq,HQmDERMFjx,HQmDERMFjx,'EGYNOW-EPISODES-1st')
		CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
		vuylTosVej845YfDNK = [CzNPJydxQLfw27tv4ZF8KORAbX5]
	else:
		vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'EGYNOW-EPISODES-2nd')
		CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
		cOUkMZagDQftHLBoCivP = DyVGS3dX0ZxR.findall('"SeasonsList"(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		vuylTosVej845YfDNK = DyVGS3dX0ZxR.findall('"EpisodesList"(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if cOUkMZagDQftHLBoCivP:
		uIGD4vZcP61QNmw78LXqoEpH = DyVGS3dX0ZxR.findall('"og:image" content="(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		uIGD4vZcP61QNmw78LXqoEpH = uIGD4vZcP61QNmw78LXqoEpH[0]
		MJ2gSPyTl9hzoi1 = cOUkMZagDQftHLBoCivP[0]
		items = DyVGS3dX0ZxR.findall('data-id="(.*?)".*?data-season="(.*?)".*?">(.*?)</a>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for mmQfkxEvd9GnXU0ZCNOriYyJql1aF,wwcrU5N6dLvRSKxsO,title in items:
			vn1grP3y4It9GmVuBbLJfz2A = EFDgdaV4WT6U2yotAPX1B+'/wp-content/themes/EgyNowByElshaikh/Ajaxt/Single/Episodes.php?'+'season='+wwcrU5N6dLvRSKxsO+'&post_id='+mmQfkxEvd9GnXU0ZCNOriYyJql1aF
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,433,uIGD4vZcP61QNmw78LXqoEpH)
	elif vuylTosVej845YfDNK:
		uIGD4vZcP61QNmw78LXqoEpH = FpGenVlw4Tzxi2WY3JuXcb.getInfoLabel('ListItem.Thumb')
		MJ2gSPyTl9hzoi1 = vuylTosVej845YfDNK[0]
		items = DyVGS3dX0ZxR.findall('href="(.*?)".*?</i>(.*?)<em>(.*?)</em>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,title,yTz8SOkAhu24j6apo9BmZHvwWsX in items:
			title = title+oQpxmKiRPlHeGsLXNrJF78O+yTz8SOkAhu24j6apo9BmZHvwWsX
			CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,432,uIGD4vZcP61QNmw78LXqoEpH)
	return
def f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url):
	SSHjMN4uegZfb2 = url+'/watch/'
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',SSHjMN4uegZfb2,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'EGYNOW-PLAY-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	Na8vklCpUGYIzP0bjutWOT = []
	EFDgdaV4WT6U2yotAPX1B = DpClq35GVjh(SSHjMN4uegZfb2,'url')
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"container-servers"(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		EcqoRFnue9Cw1aX5WNtVO2QMJh = DyVGS3dX0ZxR.findall('data-id="(.*?)"',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		if EcqoRFnue9Cw1aX5WNtVO2QMJh:
			EcqoRFnue9Cw1aX5WNtVO2QMJh = EcqoRFnue9Cw1aX5WNtVO2QMJh[0]
			items = DyVGS3dX0ZxR.findall('data-server="(.*?)".*?<span>(.*?)</span>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
			for pYVvlGR1ES0gdtzayiDqb9w,title in items:
				vn1grP3y4It9GmVuBbLJfz2A = EFDgdaV4WT6U2yotAPX1B+'/wp-content/themes/EgyNowByElshaikh/Ajaxt/Single/Server.php?server='+pYVvlGR1ES0gdtzayiDqb9w+'&post_id='+EcqoRFnue9Cw1aX5WNtVO2QMJh+'?named='+title+'__watch'
				Na8vklCpUGYIzP0bjutWOT.append(vn1grP3y4It9GmVuBbLJfz2A)
	nnBOHYGLpS4g8KfxhX17D = DyVGS3dX0ZxR.findall('"container-iframe"><iframe src="(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if nnBOHYGLpS4g8KfxhX17D:
		nnBOHYGLpS4g8KfxhX17D = nnBOHYGLpS4g8KfxhX17D[0].replace(ti3SbXNV0aJ7n5Grc4OQY8Ll1s9,HQmDERMFjx)
		title = DpClq35GVjh(nnBOHYGLpS4g8KfxhX17D,'name')
		vn1grP3y4It9GmVuBbLJfz2A = nnBOHYGLpS4g8KfxhX17D+'?named='+title+'__embed'
		Na8vklCpUGYIzP0bjutWOT.append(vn1grP3y4It9GmVuBbLJfz2A)
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"container-download"(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('href="(.*?)".*?span>(.*?)<.*?em>(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,title,RRpfksr1PbZagwCIOJXYNHTo in items:
			vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A.replace(ti3SbXNV0aJ7n5Grc4OQY8Ll1s9,HQmDERMFjx)
			if RRpfksr1PbZagwCIOJXYNHTo!=HQmDERMFjx: RRpfksr1PbZagwCIOJXYNHTo = '____'+RRpfksr1PbZagwCIOJXYNHTo
			vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A+'?named='+title+'__download'+RRpfksr1PbZagwCIOJXYNHTo
			Na8vklCpUGYIzP0bjutWOT.append(vn1grP3y4It9GmVuBbLJfz2A)
	import NsD5AomUqH
	NsD5AomUqH.NZcWGBmgFEen5hvJjUSIzOCVk7(Na8vklCpUGYIzP0bjutWOT,HDLtdMAy7wPkl8aKC3O2,'video',url)
	return
def hm4kawIPKp3oMrC75dJZA9HS2(search):
	search,GXVabd4sc2u3zp0JI,showDialogs = x0pzMENwy84tBcZvXr(search)
	if search==HQmDERMFjx: search = q156m84QoYrn()
	if search==HQmDERMFjx: return
	search = search.replace(oQpxmKiRPlHeGsLXNrJF78O,'%20')
	url = e2VR8nohduY+'/?s='+search
	c8wfGju4CWZm(url)
	return
def Fhzowv4lbkLBY(url):
	url = url.split('/smartemadfilter?')[0]
	EFDgdaV4WT6U2yotAPX1B = DpClq35GVjh(url,'url')
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(H5x4Z2qPwR8vXM,'GET',EFDgdaV4WT6U2yotAPX1B,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'EGYNOW-GET_FILTERS_BLOCKS-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('("dropdown-button".*?)"SearchingMaster"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	jnPZuGqg9F5viBUp = DyVGS3dX0ZxR.findall('"dropdown-button".*?<em>(.*?)</em>(.*?data-tax="(.*?)".*?</div>)',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	return jnPZuGqg9F5viBUp
def jfcC3ErztgW9dw(MJ2gSPyTl9hzoi1):
	items = DyVGS3dX0ZxR.findall('data-term="(\d+)" data-name="(.*?)"',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	return items
def IeFlCiJPASD4r2Y6NUbX0k7hVRxBa(url):
	Fewh9HDYiA7jJWS5c6dgr = url.split('/smartemadfilter?')[0]
	EdxGKyuW1mvZSBDf0o947h8Rik = DpClq35GVjh(url,'url')
	url = url.replace(Fewh9HDYiA7jJWS5c6dgr,EdxGKyuW1mvZSBDf0o947h8Rik)
	url = url.replace('/smartemadfilter?','/explore/?')
	return url
def Zt6UWwu84zY0(RRDtwVh6LbFiEycHNQkId5Cefmq,url):
	J4asIxU7Zyq5PiN2rKEctegFV = jlZtWwMfosJFIKenicqU1(RRDtwVh6LbFiEycHNQkId5Cefmq,'modified_filters')
	jDcWv7MAkEV = url+'/smartemadfilter?'+J4asIxU7Zyq5PiN2rKEctegFV
	jDcWv7MAkEV = IeFlCiJPASD4r2Y6NUbX0k7hVRxBa(jDcWv7MAkEV)
	return jDcWv7MAkEV
rrdHuNZaRCOviqPmS4szhD0VcEjM3 = ['category','country','genre','release-year']
xSMWIOb5tFvh = ['quality','release-year','genre','category','language','country']
def ooxUXkcTj5PF4ad2SwYy(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==HQmDERMFjx: eA0pnTuMvxrdmoRC9zPBh,mwhEr8eXxD21MAKfHUSlB = HQmDERMFjx,HQmDERMFjx
	else: eA0pnTuMvxrdmoRC9zPBh,mwhEr8eXxD21MAKfHUSlB = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if rrdHuNZaRCOviqPmS4szhD0VcEjM3[0]+'=' not in eA0pnTuMvxrdmoRC9zPBh: WF2vkePC5gbXAGUarcqlpmB3Q = rrdHuNZaRCOviqPmS4szhD0VcEjM3[0]
		for yuYts1RONXgp in range(len(rrdHuNZaRCOviqPmS4szhD0VcEjM3[0:-1])):
			if rrdHuNZaRCOviqPmS4szhD0VcEjM3[yuYts1RONXgp]+'=' in eA0pnTuMvxrdmoRC9zPBh: WF2vkePC5gbXAGUarcqlpmB3Q = rrdHuNZaRCOviqPmS4szhD0VcEjM3[yuYts1RONXgp+1]
		Cm5jWJgr28TlUnoZYHAxdPI3OB = eA0pnTuMvxrdmoRC9zPBh+'&'+WF2vkePC5gbXAGUarcqlpmB3Q+'=0'
		RRDtwVh6LbFiEycHNQkId5Cefmq = mwhEr8eXxD21MAKfHUSlB+'&'+WF2vkePC5gbXAGUarcqlpmB3Q+'=0'
		GSPtdslyxQURmB5obg69VJMY1jE = Cm5jWJgr28TlUnoZYHAxdPI3OB.strip('&')+'___'+RRDtwVh6LbFiEycHNQkId5Cefmq.strip('&')
		J4asIxU7Zyq5PiN2rKEctegFV = jlZtWwMfosJFIKenicqU1(mwhEr8eXxD21MAKfHUSlB,'modified_filters')
		SSHjMN4uegZfb2 = url+'/smartemadfilter?'+J4asIxU7Zyq5PiN2rKEctegFV
	elif type=='ALL_ITEMS_FILTER':
		v2s9V6uhIT0aCjkPOl7iUqZxB = jlZtWwMfosJFIKenicqU1(eA0pnTuMvxrdmoRC9zPBh,'modified_values')
		v2s9V6uhIT0aCjkPOl7iUqZxB = xx9LK4VzpF6IHXSEyhmrQwbg25P0(v2s9V6uhIT0aCjkPOl7iUqZxB)
		if mwhEr8eXxD21MAKfHUSlB!=HQmDERMFjx: mwhEr8eXxD21MAKfHUSlB = jlZtWwMfosJFIKenicqU1(mwhEr8eXxD21MAKfHUSlB,'modified_filters')
		if mwhEr8eXxD21MAKfHUSlB==HQmDERMFjx: SSHjMN4uegZfb2 = url
		else: SSHjMN4uegZfb2 = url+'/smartemadfilter?'+mwhEr8eXxD21MAKfHUSlB
		SSHjMN4uegZfb2 = IeFlCiJPASD4r2Y6NUbX0k7hVRxBa(SSHjMN4uegZfb2)
		CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'أظهار قائمة الفيديو التي تم اختيارها ',SSHjMN4uegZfb2,431)
		CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+' [[   '+v2s9V6uhIT0aCjkPOl7iUqZxB+'   ]]',SSHjMN4uegZfb2,431)
		CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	jnPZuGqg9F5viBUp = Fhzowv4lbkLBY(url)
	dict = {}
	for name,MJ2gSPyTl9hzoi1,DcpbqKxWsJRCSVkQyjf1 in jnPZuGqg9F5viBUp:
		name = name.replace('--',HQmDERMFjx)
		items = jfcC3ErztgW9dw(MJ2gSPyTl9hzoi1)
		if '=' not in SSHjMN4uegZfb2: SSHjMN4uegZfb2 = url
		if type=='SPECIFIED_FILTER':
			if WF2vkePC5gbXAGUarcqlpmB3Q!=DcpbqKxWsJRCSVkQyjf1: continue
			elif len(items)<2:
				if DcpbqKxWsJRCSVkQyjf1==rrdHuNZaRCOviqPmS4szhD0VcEjM3[-1]:
					url = IeFlCiJPASD4r2Y6NUbX0k7hVRxBa(url)
					c8wfGju4CWZm(url)
				else: ooxUXkcTj5PF4ad2SwYy(SSHjMN4uegZfb2,'SPECIFIED_FILTER___'+GSPtdslyxQURmB5obg69VJMY1jE)
				return
			else:
				SSHjMN4uegZfb2 = IeFlCiJPASD4r2Y6NUbX0k7hVRxBa(SSHjMN4uegZfb2)
				if DcpbqKxWsJRCSVkQyjf1==rrdHuNZaRCOviqPmS4szhD0VcEjM3[-1]: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'الجميع ',SSHjMN4uegZfb2,431)
				else: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'الجميع ',SSHjMN4uegZfb2,435,HQmDERMFjx,HQmDERMFjx,GSPtdslyxQURmB5obg69VJMY1jE)
		elif type=='ALL_ITEMS_FILTER':
			Cm5jWJgr28TlUnoZYHAxdPI3OB = eA0pnTuMvxrdmoRC9zPBh+'&'+DcpbqKxWsJRCSVkQyjf1+'=0'
			RRDtwVh6LbFiEycHNQkId5Cefmq = mwhEr8eXxD21MAKfHUSlB+'&'+DcpbqKxWsJRCSVkQyjf1+'=0'
			GSPtdslyxQURmB5obg69VJMY1jE = Cm5jWJgr28TlUnoZYHAxdPI3OB+'___'+RRDtwVh6LbFiEycHNQkId5Cefmq
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'الجميع :'+name,SSHjMN4uegZfb2,434,HQmDERMFjx,HQmDERMFjx,GSPtdslyxQURmB5obg69VJMY1jE)
		dict[DcpbqKxWsJRCSVkQyjf1] = {}
		for value,yewoKb5dkfHu1xEZMAsY in items:
			if value=='196533': yewoKb5dkfHu1xEZMAsY = 'أفلام نيتفلكس'
			elif value=='196531': yewoKb5dkfHu1xEZMAsY = 'مسلسلات نيتفلكس'
			if yewoKb5dkfHu1xEZMAsY in FwhZ0nXtpoHTMarf: continue
			dict[DcpbqKxWsJRCSVkQyjf1][value] = yewoKb5dkfHu1xEZMAsY
			Cm5jWJgr28TlUnoZYHAxdPI3OB = eA0pnTuMvxrdmoRC9zPBh+'&'+DcpbqKxWsJRCSVkQyjf1+'='+yewoKb5dkfHu1xEZMAsY
			RRDtwVh6LbFiEycHNQkId5Cefmq = mwhEr8eXxD21MAKfHUSlB+'&'+DcpbqKxWsJRCSVkQyjf1+'='+value
			CEniUGWr4jMy = Cm5jWJgr28TlUnoZYHAxdPI3OB+'___'+RRDtwVh6LbFiEycHNQkId5Cefmq
			title = yewoKb5dkfHu1xEZMAsY+' :'#+dict[DcpbqKxWsJRCSVkQyjf1]['0']
			title = yewoKb5dkfHu1xEZMAsY+' :'+name
			if type=='ALL_ITEMS_FILTER': CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,url,434,HQmDERMFjx,HQmDERMFjx,CEniUGWr4jMy)
			elif type=='SPECIFIED_FILTER' and rrdHuNZaRCOviqPmS4szhD0VcEjM3[-2]+'=' in eA0pnTuMvxrdmoRC9zPBh:
				jDcWv7MAkEV = Zt6UWwu84zY0(RRDtwVh6LbFiEycHNQkId5Cefmq,url)
				CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,jDcWv7MAkEV,431)
			else: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,url,435,HQmDERMFjx,HQmDERMFjx,CEniUGWr4jMy)
	return
def jlZtWwMfosJFIKenicqU1(Eya9L4IY3GxqtNoVWegDcPuOR,mode):
	Eya9L4IY3GxqtNoVWegDcPuOR = Eya9L4IY3GxqtNoVWegDcPuOR.replace('=&','=0&')
	Eya9L4IY3GxqtNoVWegDcPuOR = Eya9L4IY3GxqtNoVWegDcPuOR.strip('&')
	AAwtDoF34Y890RXse = {}
	if '=' in Eya9L4IY3GxqtNoVWegDcPuOR:
		items = Eya9L4IY3GxqtNoVWegDcPuOR.split('&')
		for A07BpVeRJToLb in items:
			airVhHdqCb6Gf49eERSjv1,value = A07BpVeRJToLb.split('=')
			AAwtDoF34Y890RXse[airVhHdqCb6Gf49eERSjv1] = value
	n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6 = HQmDERMFjx
	for key in xSMWIOb5tFvh:
		if key in list(AAwtDoF34Y890RXse.keys()): value = AAwtDoF34Y890RXse[key]
		else: value = '0'
		if '%' not in value: value = VVkOtyQLzxBr(value)
		if mode=='modified_values' and value!='0': n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6 = n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6+' + '+value
		elif mode=='modified_filters' and value!='0': n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6 = n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6+'&'+key+'='+value
		elif mode=='all_filters': n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6 = n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6+'&'+key+'='+value
	n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6 = n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6.strip(' + ')
	n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6 = n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6.strip('&')
	n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6 = n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6.replace('=0','=')
	return n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6
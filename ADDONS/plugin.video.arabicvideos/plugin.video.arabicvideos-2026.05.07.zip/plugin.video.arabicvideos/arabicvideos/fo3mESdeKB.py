# -*- coding: utf-8 -*-
from FF68kA5BUy import *
HDLtdMAy7wPkl8aKC3O2 = 'EGYBEST4'
EEJvXQzSZNt = '_EB4_'
e2VR8nohduY = Jzthpc2nj5.SITESURLS[HDLtdMAy7wPkl8aKC3O2][0]
FwhZ0nXtpoHTMarf = ['ايجي بست','اتصل بنا','ايجي بست الاصلي','ايجي بست الجديد','ايجي بست البديل','egybest','موقع ايجي بست']
def kk6X5LxpsND(mode,url,zmL397efNlks5uTEV,text):
	if   mode==800: zLZUkrP7ac5 = afkxo7FyZWB4O6K1eXrs5I()
	elif mode==801: zLZUkrP7ac5 = c8wfGju4CWZm(url,zmL397efNlks5uTEV)
	elif mode==802: zLZUkrP7ac5 = REWBU20fyqaLprY(url)
	elif mode==803: zLZUkrP7ac5 = f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url)
	elif mode==804: zLZUkrP7ac5 = gjwBnYN0zlFWVtGKfOocDA(url)
	elif mode==806: zLZUkrP7ac5 = OeIkhc6dCf01i2BFSKX5L8E9Nvr(url,zmL397efNlks5uTEV)
	elif mode==809: zLZUkrP7ac5 = hm4kawIPKp3oMrC75dJZA9HS2(text)
	else: zLZUkrP7ac5 = False
	return zLZUkrP7ac5
def afkxo7FyZWB4O6K1eXrs5I():
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'بحث في الموقع',HQmDERMFjx,809,HQmDERMFjx,HQmDERMFjx,'_REMEMBERRESULTS_')
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'فلتر',e2VR8nohduY+'/trending',804,HQmDERMFjx,HQmDERMFjx,'_REMEMBERRESULTS_')
	CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(H5x4Z2qPwR8vXM,'GET',e2VR8nohduY,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'EGYBEST4-MENU-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('nav-categories(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('href="(.*?)">(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,title in items:
			title = title.strip(oQpxmKiRPlHeGsLXNrJF78O)
			if any(value in title for value in FwhZ0nXtpoHTMarf): continue
			if 'http' not in vn1grP3y4It9GmVuBbLJfz2A: vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+vn1grP3y4It9GmVuBbLJfz2A
			CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,801)
		CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('mainContent(.*?)<footer>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('mainTitle.*?href="(.*?)".*?title="(.*?)"',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,title in items:
			title = title.strip(oQpxmKiRPlHeGsLXNrJF78O)
			if any(value in title for value in FwhZ0nXtpoHTMarf): continue
			if 'http' not in vn1grP3y4It9GmVuBbLJfz2A: vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+vn1grP3y4It9GmVuBbLJfz2A
			CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,801,HQmDERMFjx,'mainmenu')
		CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('main-menu(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('href="(.*?)">(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,title in items:
			title = title.strip(oQpxmKiRPlHeGsLXNrJF78O)
			if any(value in title for value in FwhZ0nXtpoHTMarf): continue
			if 'http' not in vn1grP3y4It9GmVuBbLJfz2A: vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+vn1grP3y4It9GmVuBbLJfz2A
			CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,801)
	return CzNPJydxQLfw27tv4ZF8KORAbX5
def OeIkhc6dCf01i2BFSKX5L8E9Nvr(url,type=HQmDERMFjx):
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'EGYBEST4-SEASONS_EPISODES-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('mainTitle.*?>(.*?)<(.*?)pageContent',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		WTgZPcmVih38IjnSJ2U,EX6nDt50Hih9mIxulw7kpMCZfaOsJR,items = HQmDERMFjx,HQmDERMFjx,[]
		for name,MJ2gSPyTl9hzoi1 in Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
			if 'حلقات' in name: EX6nDt50Hih9mIxulw7kpMCZfaOsJR = MJ2gSPyTl9hzoi1
			if 'مواسم' in name: WTgZPcmVih38IjnSJ2U = MJ2gSPyTl9hzoi1
		if WTgZPcmVih38IjnSJ2U and not type:
			items = DyVGS3dX0ZxR.findall('href="(.*?)".*?img="(.*?)".*?"title">(.*?)<',WTgZPcmVih38IjnSJ2U,DyVGS3dX0ZxR.DOTALL)
			if len(items)>1:
				for vn1grP3y4It9GmVuBbLJfz2A,uIGD4vZcP61QNmw78LXqoEpH,title in items:
					CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,806,uIGD4vZcP61QNmw78LXqoEpH,'season')
		if EX6nDt50Hih9mIxulw7kpMCZfaOsJR and len(items)<2:
			items = DyVGS3dX0ZxR.findall('href="(.*?)".*?img="(.*?)".*?"title">(.*?)<',EX6nDt50Hih9mIxulw7kpMCZfaOsJR,DyVGS3dX0ZxR.DOTALL)
			if items:
				for vn1grP3y4It9GmVuBbLJfz2A,uIGD4vZcP61QNmw78LXqoEpH,title in items:
					CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,803,uIGD4vZcP61QNmw78LXqoEpH)
			else:
				items = DyVGS3dX0ZxR.findall('href="(.*?)">(.*?)<',EX6nDt50Hih9mIxulw7kpMCZfaOsJR,DyVGS3dX0ZxR.DOTALL)
				for vn1grP3y4It9GmVuBbLJfz2A,title in items:
					CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,803)
	return
def c8wfGju4CWZm(url,type=HQmDERMFjx):
	MMYecLpZi6wfT9m3ju,start,GQB0WzyICDK7mXxN2Acdi,select,ubgQBzFtaLCkKU42MXZ96mefhjoip = 0,0,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx
	if 'pagination' in type:
		gBhoe9AYT0nbdZDQGmfrL2pW,Vi9fwvbSBCI0K6hgXA8EpFrT = url.split('?next=page&')
		nJayb3s5zlOgQh9BwiCdEDq = {'Content-Type':'application/x-www-form-urlencoded'}
		vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'POST',gBhoe9AYT0nbdZDQGmfrL2pW,Vi9fwvbSBCI0K6hgXA8EpFrT,nJayb3s5zlOgQh9BwiCdEDq,HQmDERMFjx,HQmDERMFjx,'EGYBEST4-TITLES-1st')
		CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
		b3L20nx7qwHKTS6so = 'secContent'+CzNPJydxQLfw27tv4ZF8KORAbX5+'<footer>'
	else:
		vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'EGYBEST4-TITLES-2nd')
		CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
		b3L20nx7qwHKTS6so = CzNPJydxQLfw27tv4ZF8KORAbX5
	items,ooMNC7KvzXqmsT2ke3JL9SIFi,Eya9L4IY3GxqtNoVWegDcPuOR = [],False,False
	if not type and '/collections' not in url:
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('mainContent(.*?)</div>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
			MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
			items = DyVGS3dX0ZxR.findall('href="(.*?)".*?</i>(.*?)</a>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
			for vn1grP3y4It9GmVuBbLJfz2A,title in items:
				title = title.strip(oQpxmKiRPlHeGsLXNrJF78O)
				CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,801,HQmDERMFjx,'submenu')
				ooMNC7KvzXqmsT2ke3JL9SIFi = True
	if not ooMNC7KvzXqmsT2ke3JL9SIFi:
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('secContent(.*?)mainContent',b3L20nx7qwHKTS6so,DyVGS3dX0ZxR.DOTALL)
		if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
			MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
			items = DyVGS3dX0ZxR.findall('href="(.*?)".*?img="(.*?)".*?"title">(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
			for vn1grP3y4It9GmVuBbLJfz2A,uIGD4vZcP61QNmw78LXqoEpH,title in items:
				vn1grP3y4It9GmVuBbLJfz2A = xx9LK4VzpF6IHXSEyhmrQwbg25P0(vn1grP3y4It9GmVuBbLJfz2A)
				uIGD4vZcP61QNmw78LXqoEpH = uIGD4vZcP61QNmw78LXqoEpH.strip(ti3SbXNV0aJ7n5Grc4OQY8Ll1s9)
				title = SVsiEWeRf6oIynqQx8pCrM4Tk(title)
				if '/series/' in vn1grP3y4It9GmVuBbLJfz2A and type=='season': CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,806,uIGD4vZcP61QNmw78LXqoEpH,'season')
				elif '/series/' in vn1grP3y4It9GmVuBbLJfz2A: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,806,uIGD4vZcP61QNmw78LXqoEpH)
				elif '/seasons/' in vn1grP3y4It9GmVuBbLJfz2A: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,801,uIGD4vZcP61QNmw78LXqoEpH,'season')
				elif '/collections' in url: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,801,uIGD4vZcP61QNmw78LXqoEpH,'collections')
				else: CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,803,uIGD4vZcP61QNmw78LXqoEpH)
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('loadMoreParams = (.*?);',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
			MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
			lew3BALR7s = aknZqSJyUrFgc9VhH2Psot6e7b8('dict',MJ2gSPyTl9hzoi1)
			ubgQBzFtaLCkKU42MXZ96mefhjoip = lew3BALR7s['ajaxurl']
			lELPWeA4rpO = int(lew3BALR7s['current_page'])+1
			XYDWJGieT82hsM0Lk1R6KIzVon4yCw = int(lew3BALR7s['max_page'])
			z27ntf6qvuCkBQbyPX = lew3BALR7s['posts'].replace('False','false').replace('True','true').replace('None','null')
			if lELPWeA4rpO<XYDWJGieT82hsM0Lk1R6KIzVon4yCw:
				Vi9fwvbSBCI0K6hgXA8EpFrT = 'action=loadmore&query='+VVkOtyQLzxBr(z27ntf6qvuCkBQbyPX,HQmDERMFjx)+'&page='+str(lELPWeA4rpO)
				SSHjMN4uegZfb2 = ubgQBzFtaLCkKU42MXZ96mefhjoip+'?next=page&'+Vi9fwvbSBCI0K6hgXA8EpFrT
				CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'جلب المزيد',SSHjMN4uegZfb2,801,HQmDERMFjx,'pagination_'+type)
		elif '?next=page&' in url:
			Vi9fwvbSBCI0K6hgXA8EpFrT,sibPMcaz4K = Vi9fwvbSBCI0K6hgXA8EpFrT.rsplit('=',1)
			sibPMcaz4K = int(sibPMcaz4K)+1
			SSHjMN4uegZfb2 = gBhoe9AYT0nbdZDQGmfrL2pW+'?next=page&'+Vi9fwvbSBCI0K6hgXA8EpFrT+'='+str(sibPMcaz4K)
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'جلب المزيد',SSHjMN4uegZfb2,801,HQmDERMFjx,'pagination_'+type)
	return
def gjwBnYN0zlFWVtGKfOocDA(url):
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'EGYBEST4-FILTERS-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('sub_nav(.*?)secContent ',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		bUzHWnGg5t1 = DyVGS3dX0ZxR.findall('"current_opt">(.*?)<(.*?)</div>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for name,MJ2gSPyTl9hzoi1 in bUzHWnGg5t1:
			if 'التصنيف' in name: continue
			name = name.strip(oQpxmKiRPlHeGsLXNrJF78O)
			items = DyVGS3dX0ZxR.findall('href="(.*?)">(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
			for vn1grP3y4It9GmVuBbLJfz2A,value in items:
				title = name+':  '+value
				CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,801,HQmDERMFjx,'filter')
	return
def f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url):
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(rwjfOIqQU3ANa0JlWXvCDbFk,'GET',url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'EGYBEST4-PLAY-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	WWbJG6CrUL4tIRsjpNV = DyVGS3dX0ZxR.findall('<td>التصنيف</td>.*?">(.*?)<',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if WWbJG6CrUL4tIRsjpNV and UzSYuZp3Pnhf1W4wyx7Fc0JX6jNb(HDLtdMAy7wPkl8aKC3O2,url,WWbJG6CrUL4tIRsjpNV): return
	KWnAuJIFyESQHjP3X5xzMqUbR6L,QYDSpJHjizlW = [],[]
	vn1grP3y4It9GmVuBbLJfz2A = DyVGS3dX0ZxR.findall('postEmbed.*?src="(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if vn1grP3y4It9GmVuBbLJfz2A:
		vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A[0].replace(ti3SbXNV0aJ7n5Grc4OQY8Ll1s9,HQmDERMFjx)
		QYDSpJHjizlW.append(vn1grP3y4It9GmVuBbLJfz2A)
		pYVvlGR1ES0gdtzayiDqb9w = DpClq35GVjh(vn1grP3y4It9GmVuBbLJfz2A,'name')
		KWnAuJIFyESQHjP3X5xzMqUbR6L.append(vn1grP3y4It9GmVuBbLJfz2A+'?named='+pYVvlGR1ES0gdtzayiDqb9w+'__embed')
	zXfGONZiq5AnVSoeCMKHT = DyVGS3dX0ZxR.findall('vo_theme_dir.*?"(.*?)".*?"(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if zXfGONZiq5AnVSoeCMKHT:
		ubgQBzFtaLCkKU42MXZ96mefhjoip,oogPV1HKSJbGBql46sD25 = zXfGONZiq5AnVSoeCMKHT[0]
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('postPlayer(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
			MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
			KLWzgyDPt5FoUan1 = DyVGS3dX0ZxR.findall('<li.*?id\,(.*?)\);">(.*?)</li>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
			for m5moEy7MBXfRZq2HOQwxNU9WgIeJ,name in KLWzgyDPt5FoUan1:
				vn1grP3y4It9GmVuBbLJfz2A = ubgQBzFtaLCkKU42MXZ96mefhjoip+'/temp/ajax/iframe.php?id='+oogPV1HKSJbGBql46sD25+'&video='+m5moEy7MBXfRZq2HOQwxNU9WgIeJ
				KWnAuJIFyESQHjP3X5xzMqUbR6L.append(vn1grP3y4It9GmVuBbLJfz2A+'?named='+name+'__watch')
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('pageContentDown(.*?)</table>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('<tr>.*?<td>[ a-zA-Z]*(\d{3,4})[ a-zA-Z]*</td>.*?href="(.*?)"',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for RRpfksr1PbZagwCIOJXYNHTo,vn1grP3y4It9GmVuBbLJfz2A in items:
			if vn1grP3y4It9GmVuBbLJfz2A not in QYDSpJHjizlW:
				if '/?url=' in vn1grP3y4It9GmVuBbLJfz2A: vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A.split('/?url=')[1]
				QYDSpJHjizlW.append(vn1grP3y4It9GmVuBbLJfz2A)
				pYVvlGR1ES0gdtzayiDqb9w = DpClq35GVjh(vn1grP3y4It9GmVuBbLJfz2A,'name')
				KWnAuJIFyESQHjP3X5xzMqUbR6L.append(vn1grP3y4It9GmVuBbLJfz2A+'?named='+pYVvlGR1ES0gdtzayiDqb9w+'__download____'+RRpfksr1PbZagwCIOJXYNHTo)
	import NsD5AomUqH
	NsD5AomUqH.NZcWGBmgFEen5hvJjUSIzOCVk7(KWnAuJIFyESQHjP3X5xzMqUbR6L,HDLtdMAy7wPkl8aKC3O2,'video',url)
	return
def hm4kawIPKp3oMrC75dJZA9HS2(search):
	search,GXVabd4sc2u3zp0JI,showDialogs = x0pzMENwy84tBcZvXr(search)
	if not search: search = q156m84QoYrn()
	if not search: return
	q5qfEX4yA6lDop1 = search.replace(oQpxmKiRPlHeGsLXNrJF78O,'+')
	url = e2VR8nohduY+'/?s='+q5qfEX4yA6lDop1
	c8wfGju4CWZm(url,'search')
	return
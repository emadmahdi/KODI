# -*- coding: utf-8 -*-
import sys as TPW58slaVE9OrYQXZnGo2yAfFzpBxc
tbYWAoeMyHTsgFG5x6huz1 = TPW58slaVE9OrYQXZnGo2yAfFzpBxc.version_info [0] == 2
CUJSAbZztE8vYdGByLH0KcnWqe = 2048
R0QCXnpyL1DJwBH67FW = 7
def kSod2AxqugH0 (LURfCucn30xKsMdTiG):
	global ghCyPxkWILcXrGjVut6MQo59fsv
	MfIpC9TDz7Qa5g2vVqPtXh4 = ord (LURfCucn30xKsMdTiG [-1])
	nndScZEtapB74 = LURfCucn30xKsMdTiG [:-1]
	LRbqugZJAa3192OCewWGHvEcP = MfIpC9TDz7Qa5g2vVqPtXh4 % len (nndScZEtapB74)
	qLc7RGgDQE = nndScZEtapB74 [:LRbqugZJAa3192OCewWGHvEcP] + nndScZEtapB74 [LRbqugZJAa3192OCewWGHvEcP:]
	if tbYWAoeMyHTsgFG5x6huz1:
		XUczap3yA0QqFRC82OH6E5mL = unicode () .join ([unichr (ord (ah5u39EBY81MlrwA0cmoz4ngb7TLed) - CUJSAbZztE8vYdGByLH0KcnWqe - (YMjpxPr8WsJ1Bg6Xd + MfIpC9TDz7Qa5g2vVqPtXh4) % R0QCXnpyL1DJwBH67FW) for YMjpxPr8WsJ1Bg6Xd, ah5u39EBY81MlrwA0cmoz4ngb7TLed in enumerate (qLc7RGgDQE)])
	else:
		XUczap3yA0QqFRC82OH6E5mL = str () .join ([chr (ord (ah5u39EBY81MlrwA0cmoz4ngb7TLed) - CUJSAbZztE8vYdGByLH0KcnWqe - (YMjpxPr8WsJ1Bg6Xd + MfIpC9TDz7Qa5g2vVqPtXh4) % R0QCXnpyL1DJwBH67FW) for YMjpxPr8WsJ1Bg6Xd, ah5u39EBY81MlrwA0cmoz4ngb7TLed in enumerate (qLc7RGgDQE)])
	return eval (XUczap3yA0QqFRC82OH6E5mL)
jL1E5AKfwBDv6xmeQtUXcJ3d,JJA7fypmZFVlazvNI,dBi72erQEtKDOwjNFaoAgSP=kSod2AxqugH0,kSod2AxqugH0,kSod2AxqugH0
CDwSWB4v39N7,k4IUieraScH9DV1N7pJgQosYAx5l,Tcf5Ppn9UajDbzyM=dBi72erQEtKDOwjNFaoAgSP,JJA7fypmZFVlazvNI,jL1E5AKfwBDv6xmeQtUXcJ3d
X2crmy67eZpkGTRd,HDpmv4UXzlf72SK9,C3ZK1pu4rfmj8TsWUtBaM=Tcf5Ppn9UajDbzyM,k4IUieraScH9DV1N7pJgQosYAx5l,CDwSWB4v39N7
mg3CbXMA2ouZzQDhRqB,OBsrtQo2pPlgURCxJYbj9iXMD,ssnfOzb16wVog9GKdqcXR3JC7ktSPA=C3ZK1pu4rfmj8TsWUtBaM,HDpmv4UXzlf72SK9,X2crmy67eZpkGTRd
ShnRVsifKtc60zqQ,KKi79PFqsYB0dWSRgaJ3DyE,OzU6t0qcH7MQabeBYK8vgoG=ssnfOzb16wVog9GKdqcXR3JC7ktSPA,OBsrtQo2pPlgURCxJYbj9iXMD,mg3CbXMA2ouZzQDhRqB
mgLADoQ1pbtY,U0VwOviFaYPz2QGs45mJhMXf7Zk,pCTzbw4GyVJHjkcIMQ=OzU6t0qcH7MQabeBYK8vgoG,KKi79PFqsYB0dWSRgaJ3DyE,ShnRVsifKtc60zqQ
owbMhINBQsmx70guApW,SODvU3Ibq5VzC,PPAUFrY8cduRT=pCTzbw4GyVJHjkcIMQ,U0VwOviFaYPz2QGs45mJhMXf7Zk,mgLADoQ1pbtY
knTyjJ0sGIzuwbxRae,nz8x32hX0qcjUPFZk5RdJsiwED,A0aqj9uclgOtByJ6F4bz=PPAUFrY8cduRT,SODvU3Ibq5VzC,owbMhINBQsmx70guApW
YJxaX0MQOHb8oyCBFdnIAe,n6sfYuHBlVdzgmvpXwR3irON0KIj8,LHX65I9nkx0PstgcVY24uSi=A0aqj9uclgOtByJ6F4bz,nz8x32hX0qcjUPFZk5RdJsiwED,knTyjJ0sGIzuwbxRae
EAVanJj1ers2GQud,ELfMeDTIFhJt685K,EF2tvxZHz5n4UruPhaViXKycI6SQR=LHX65I9nkx0PstgcVY24uSi,n6sfYuHBlVdzgmvpXwR3irON0KIj8,YJxaX0MQOHb8oyCBFdnIAe
KhUG1NV9bln5zXjptqFW6dgo,cWbkR6iUZsnJQj14,maUl7SPesynF1j=EF2tvxZHz5n4UruPhaViXKycI6SQR,ELfMeDTIFhJt685K,EAVanJj1ers2GQud
o4bNzIQGYj8En = LHX65I9nkx0PstgcVY24uSi(u"࠱ୌ")
CH7RKuDVzN9f06q8MtXPhlvIxakEWg = KKi79PFqsYB0dWSRgaJ3DyE(u"࠳୍")
FFHRwuxQmbh8BaTqyX3 = CH7RKuDVzN9f06q8MtXPhlvIxakEWg+CH7RKuDVzN9f06q8MtXPhlvIxakEWg
UUR70c8L9yTp3A2ajlmJqkQz = FFHRwuxQmbh8BaTqyX3+CH7RKuDVzN9f06q8MtXPhlvIxakEWg
ihRKM0HpwdVstIF2ZjuTeCmXG = UUR70c8L9yTp3A2ajlmJqkQz+CH7RKuDVzN9f06q8MtXPhlvIxakEWg
MVXFsAiZbSvHTtq8he5GwLaOxzW = ihRKM0HpwdVstIF2ZjuTeCmXG+CH7RKuDVzN9f06q8MtXPhlvIxakEWg
HQmDERMFjx = ELfMeDTIFhJt685K(u"ࠨࠩऎ")
oQpxmKiRPlHeGsLXNrJF78O = k4IUieraScH9DV1N7pJgQosYAx5l(u"ࠩࠣࠫए")
MSnXBQNUg1jF3W2fRlE9OLaCT8ds4 = oQpxmKiRPlHeGsLXNrJF78O*FFHRwuxQmbh8BaTqyX3
xoZHpTRUzS9 = oQpxmKiRPlHeGsLXNrJF78O*UUR70c8L9yTp3A2ajlmJqkQz
pVzyOequnZtI = oQpxmKiRPlHeGsLXNrJF78O*ihRKM0HpwdVstIF2ZjuTeCmXG
xufJqQcGnhboiVy2wd = Tcf5Ppn9UajDbzyM(u"ࠪ࠳ࠬऐ")
mKqAOsD5p0C = mgLADoQ1pbtY(u"ࠫ࠴࠵ࠧऑ")
BFavj14P9QklUhIz67CLNmwDEMsrbp = None
gyd2rf0UR5 = nz8x32hX0qcjUPFZk5RdJsiwED(u"࡚ࡲࡶࡧ௝")
mic3MEN709xOkrjD5ZvbGIlX6 = JJA7fypmZFVlazvNI(u"ࡆࡢ࡮ࡶࡩ௞")
Jb3SYEV8keXWQpNjArgR1wKhl = KKi79PFqsYB0dWSRgaJ3DyE(u"ࠬࡺࡲࡶࡧࠪऒ")
xjD4NgpEkFCrnw8S = dBi72erQEtKDOwjNFaoAgSP(u"࠭ࡦࡢ࡮ࡶࡩࠬओ")
xWfmqtAck6vZbDhoda73GNrOHnKpjF = ELfMeDTIFhJt685K(u"ࠧࡪࡩࡱࡳࡷ࡫ࠧऔ")
SLgzAKNoYhFUR = PPAUFrY8cduRT(u"ࠨࡦࡨࡪࡦࡻ࡬ࡵࠩक")
ao3Q5jP8H0sMxK2iUYwZGE = OBsrtQo2pPlgURCxJYbj9iXMD(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡂ࠶࠴ࡉࡡࠬख")
s7d549VgeP = OzU6t0qcH7MQabeBYK8vgoG(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭ग")
ocup7CLi9Wk5lsZrEhQUIOPt8 = n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌ࠳࠴ࡇ࠷࠷࠸ࡣࠧघ")
P79wIuazCDjv2Biemdb1 = nz8x32hX0qcjUPFZk5RdJsiwED(u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆ࠲ࡈ࠸࠵ࡋࡌ࡝ࠨङ")
zfEterTlgs = JJA7fypmZFVlazvNI(u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋࡌࡆ࡞ࠩच")
cjqzOQ5GXD4kR = JJA7fypmZFVlazvNI(u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩछ")
Zex6D4tJE52r = cWbkR6iUZsnJQj14(u"ࠨࡷࡷࡪ࠽࠭ज")
gV7JxnFQu2svRAPZ = ELfMeDTIFhJt685K(u"ࠩ࡯ࡥࡹ࡯࡮࠮࠳ࠪझ")
yNqJ4UpZ0wngGi1hHeuEMK = CDwSWB4v39N7(u"ࠪࡻ࡮ࡴࡤࡰࡹࡶ࠱࠶࠸࠵࠷ࠩञ")
RRWFdpe04EK1Qn = mgLADoQ1pbtY(u"ࠫࡓࡕࡔࡊࡅࡈࠫट")
UHLAD1JfFIK = cWbkR6iUZsnJQj14(u"ࠬࡋࡒࡓࡑࡕࠫठ")
nAWvufqmpe8V = pCTzbw4GyVJHjkcIMQ(u"࠭ࡎࡐࡖࡌࡇࡊࡥࡌࡊࡐࡈࡗࠬड")
GmyBXr3kYHdlvJ = YJxaX0MQOHb8oyCBFdnIAe(u"ࠧࡆࡔࡕࡓࡗࡥࡌࡊࡐࡈࡗࠬढ")
ti3SbXNV0aJ7n5Grc4OQY8Ll1s9 = knTyjJ0sGIzuwbxRae(u"ࠨ࡞ࡱࠫण")
GsgOT5Vp6UzIy87bh4vQBWdNjAX3c1 = CDwSWB4v39N7(u"ࠩ࡟ࡶࠬत")
OO2BXYhI8UPNq6L = n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭थ")
ccLjeuqU72xNHrGwZ0iPnSM = EAVanJj1ers2GQud(u"࠴୎")
Cmi6t9yruWT4Vz80MbOAKlUh = KhUG1NV9bln5zXjptqFW6dgo(u"࠴࠳࠻୏")
I29LXeoYKpyQduD = nz8x32hX0qcjUPFZk5RdJsiwED(u"࠶࠻୐")
SiOUmVIXaHKEPzF5b = EAVanJj1ers2GQud(u"࠹࠰୑")
aIi7Fv5Mtp9YS4 = ShnRVsifKtc60zqQ(u"࠱࠱୒")
QQuYFfqZAnN = jL1E5AKfwBDv6xmeQtUXcJ3d(u"࠲࠴࠳୓")
zPFfNr1WcoIhMA0DHG = maUl7SPesynF1j(u"࠶࠸୔")
L3C1YrQDi840ShlOJcNGe = MVXFsAiZbSvHTtq8he5GwLaOxzW
g8zRsf2yJHwZeVCWEIYLT = dBi72erQEtKDOwjNFaoAgSP(u"࠹࠴୕")
F2FDLsV4dMtl = EAVanJj1ers2GQud(u"࠺࠵ୖ")*g8zRsf2yJHwZeVCWEIYLT
VRwXUbD43mEnekudL = A0aqj9uclgOtByJ6F4bz(u"࠷࠺ୗ")*F2FDLsV4dMtl
MhcH3Nu8KYZnexfUSvR74jsTqV = PPAUFrY8cduRT(u"࠹࠰୘")*VRwXUbD43mEnekudL
rwjfOIqQU3ANa0JlWXvCDbFk = o4bNzIQGYj8En
SwvFqCI7sc6bTAoeZY = KKi79PFqsYB0dWSRgaJ3DyE(u"࠳࠱୙")*g8zRsf2yJHwZeVCWEIYLT
LLwINhcX2RHSWqpmEnz = FFHRwuxQmbh8BaTqyX3*F2FDLsV4dMtl
j9uzmBeEyK8 = U0VwOviFaYPz2QGs45mJhMXf7Zk(u"࠲࠸୚")*F2FDLsV4dMtl
H5x4Z2qPwR8vXM = UUR70c8L9yTp3A2ajlmJqkQz*VRwXUbD43mEnekudL
ppxzXEh5md4Dwota3gBQFc = dBi72erQEtKDOwjNFaoAgSP(u"࠵࠳୛")*VRwXUbD43mEnekudL
h8CF5iEB9RXNf0G = OzU6t0qcH7MQabeBYK8vgoG(u"࠴࠶ଡ଼")*MhcH3Nu8KYZnexfUSvR74jsTqV
DAev91QlUOxzLSBaof = F2FDLsV4dMtl
ccoph2TqA8fJG4KO6YRwm = [EAVanJj1ers2GQud(u"ฺࠫ็ัࠨद"),maUl7SPesynF1j(u"ࠬษ่ๅࠩध"),k4IUieraScH9DV1N7pJgQosYAx5l(u"࠭หศ่ํࠫन"),k4IUieraScH9DV1N7pJgQosYAx5l(u"ࠧฬษ็ฯࠬऩ"),SODvU3Ibq5VzC(u"ࠨำสฬ฾࠭प"),pCTzbw4GyVJHjkcIMQ(u"ࠩัหู๊ࠧफ"),YJxaX0MQOHb8oyCBFdnIAe(u"ࠪืฬีำࠨब"),ELfMeDTIFhJt685K(u"ุࠫอศฺࠩभ"),YJxaX0MQOHb8oyCBFdnIAe(u"ࠬัวๆ่ࠪम"),n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"࠭สศี฼ࠫय"),KKi79PFqsYB0dWSRgaJ3DyE(u"ฺࠧษืีࠬर")]
wkS3xPoD4j7CqImBzFrhRglbTfNpOE = [
						 YJxaX0MQOHb8oyCBFdnIAe(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡖࡉࡓࡊ࡟ࡂࡐࡄࡐ࡞࡚ࡉࡄࡕࡢࡉ࡛ࡋࡎࡕࡕ࠰࠵ࡸࡺࠧऱ")
						,cWbkR6iUZsnJQj14(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡉ࡝࡚ࡒࡂࡅࡗࡣࡒ࠹ࡕ࠹࠯࠴ࡷࡹ࠭ल")
						,mgLADoQ1pbtY(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡗࡇࡎࡅࡑࡐࡣ࡚࡙ࡅࡓࡃࡊࡉࡓ࡚࠭࠲ࡵࡷࠫळ")
						,SODvU3Ibq5VzC(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡅࡕࡡࡓࡖࡔ࡞ࡉࡆࡕࡢࡐࡎ࡙ࡔ࠮࠳ࡶࡸࠬऴ")
						,ELfMeDTIFhJt685K(u"ࠬࡏࡐࡕࡘ࠰ࡇࡍࡋࡃࡌࡡࡄࡇࡈࡕࡕࡏࡖ࠰࠵ࡸࡺࠧव")
						,maUl7SPesynF1j(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡇࡒࡐࡔࡉࡁࡕࡋࡒࡒ࠲࠷ࡳࡵࠩश")
						,OzU6t0qcH7MQabeBYK8vgoG(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡉࡒࡓࡌࡒࡅࡠࡐࡈ࡛ࡤࡎࡏࡔࡖࡑࡅࡒࡋ࠭࠲ࡵࡷࠫष")
						,C3ZK1pu4rfmj8TsWUtBaM(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡓࡔࡍࡌࡆࡡࡑࡉ࡜ࡥࡈࡐࡕࡗࡒࡆࡓࡅ࠮࠵ࡵࡨࠬस")
						,YJxaX0MQOHb8oyCBFdnIAe(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡖࡊࡇࡄࡠࡃࡏࡐࡤࡇࡄࡅࡑࡑࡗࡤ࡞ࡍࡍ࠯࠴ࡷࡹ࠭ह")
						,pCTzbw4GyVJHjkcIMQ(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡇࡐࡑࡊࡐࡊ࡛ࡓࡆࡔࡆࡓࡓ࡚ࡅࡏࡖ࠰࠵ࡸࡺࠧऺ")
						,CDwSWB4v39N7(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡃ࡛ࡓࡅࡘ࡙࡟ࡂࡍ࡚ࡅࡒࡥࡃࡂࡒࡗࡇࡍࡇ࠭࠴ࡴࡧࠫऻ")
						,mg3CbXMA2ouZzQDhRqB(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡄ࡜ࡔࡆ࡙ࡓࡠࡃࡎ࡛ࡆࡓ࡟ࡄࡃࡓࡘࡈࡎࡁ࠮࠷ࡷ࡬़ࠬ")
						,knTyjJ0sGIzuwbxRae(u"࠭ࡅࡍࡅࡌࡒࡊࡓࡁ࠮ࡕࡈࡅࡗࡉࡈ࠮࠳ࡶࡸࠬऽ")
						,YJxaX0MQOHb8oyCBFdnIAe(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡜ࡘࡎࡁࡓࡋࡑࡋ࠲࠷ࡳࡵࠩा")
						,ELfMeDTIFhJt685K(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡝࡙ࡈࡂࡔࡌࡒࡌ࠳࠲࡯ࡦࠪि")
						]
ikHMyLSuZBDXbaIVQr7Uh6n = wkS3xPoD4j7CqImBzFrhRglbTfNpOE+[
				 CDwSWB4v39N7(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡔࡗࡕࡘ࡚ࡡࡗࡉࡘ࡚࠭࠲ࡵࡷࠫी")
				,nz8x32hX0qcjUPFZk5RdJsiwED(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤࡎࡔࡕࡒࡖࡔࡗࡕࡘࡊࡇࡖ࠱࠶ࡹࡴࠨु")
				,KKi79PFqsYB0dWSRgaJ3DyE(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡕࡐࡆࡐࡘࡖࡑࡥࡗࡆࡄࡓࡖࡔ࡞ࡉࡆࡕ࠰࠵ࡸࡺࠧू")
				,EF2tvxZHz5n4UruPhaViXKycI6SQR(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡘࡇࡅࡔࡗࡕࡘࡊࡇࡖ࠱࠷ࡴࡤࠨृ")
				,owbMhINBQsmx70guApW(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠ࡙ࡈࡆࡕࡘࡏ࡙࡛ࡗࡓ࠲࠷ࡳࡵࠩॄ")
				,Tcf5Ppn9UajDbzyM(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡑࡓࡉࡓ࡛ࡒࡍࡡ࡚ࡉࡇࡖࡒࡐ࡚࡜ࡘࡔ࠳࠲࡯ࡦࠪॅ")
				,Tcf5Ppn9UajDbzyM(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢࡏࡕࡘࡏ࡙࡛ࡆࡓࡒ࠳࠱ࡴࡶࠪॆ")
				,LHX65I9nkx0PstgcVY24uSi(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡓࡕࡋࡎࡖࡔࡏࡣࡐࡖࡒࡐ࡚࡜ࡇࡔࡓ࠭࠳ࡰࡧࠫे")
				,CDwSWB4v39N7(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤࡑࡐࡓࡑ࡛࡝ࡈࡕࡍ࠮࠵ࡵࡨࠬै")
				,SODvU3Ibq5VzC(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡉࡈࡆࡅࡎࡣࡍ࡚ࡔࡑࡕࡢࡔࡗࡕࡘࡊࡇࡖ࠱࠶ࡹࡴࠨॉ")
				,ELfMeDTIFhJt685K(u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙࠭ࡉࡖࡗࡔࡘࡥࡔࡆࡕࡗ࠱࠶ࡹࡴࠨॊ")
				,OzU6t0qcH7MQabeBYK8vgoG(u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓ࠮ࡖࡈࡗ࡙ࡥࡁࡍࡎࡢ࡛ࡊࡈࡓࡊࡖࡈࡗ࠲࠷ࡳࡵࠩो")
				,C3ZK1pu4rfmj8TsWUtBaM(u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࡗࡉࡘ࡚࡟ࡂࡎࡏࡣ࡜ࡋࡂࡔࡋࡗࡉࡘ࠳࠲࡯ࡦࠪौ")
				,ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕ࠰࡙ࡘࡇࡇࡆࡡࡕࡉࡕࡕࡒࡕ࠯࠴ࡷࡹ्࠭")
				,CDwSWB4v39N7(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡔࡕࡇࡍࡇࡢࡘࡗࡇࡎࡔࡎࡄࡘࡊ࠳࠱ࡴࡶࠪॎ")
				,U0VwOviFaYPz2QGs45mJhMXf7Zk(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡗࡋࡖࡆࡔࡖࡓࡤ࡚ࡒࡂࡐࡖࡐࡆ࡚ࡅ࠮࠳ࡶࡸࠬॏ")
				]
llkLy5IdnoqME = [
						 A0aqj9uclgOtByJ6F4bz(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࡙࠭ࡕࡋࡅࡗࡏࡎࡈ࠯࠴ࡷࡹ࠭ॐ")
						,SODvU3Ibq5VzC(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡚ࡖࡌࡆࡘࡉࡏࡉ࠰࠶ࡳࡪࠧ॑")
						,ELfMeDTIFhJt685K(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡐ࡙ࡑ࡚ࡉࡠ࡚ࡖࡌࡆࡘࡉࡏࡉ࠰࠵ࡸࡺ॒ࠧ")
						]
SYGOE6WVFNdKf = [dBi72erQEtKDOwjNFaoAgSP(u"ࠧࡃࡑࡎࡖࡆ࠭॓"),SODvU3Ibq5VzC(u"ࠨࡒࡄࡒࡊ࡚ࠧ॔"),PPAUFrY8cduRT(u"ࠩࡄࡖࡆࡈࡉࡄࡖࡒࡓࡓ࡙ࠧॕ"),mg3CbXMA2ouZzQDhRqB(u"ࠪࡏࡆࡘࡂࡂࡎࡄࡘ࡛࠭ॖ"),mg3CbXMA2ouZzQDhRqB(u"ࠫࡎࡌࡉࡍࡏࠪॗ"),EAVanJj1ers2GQud(u"ࠬࡏࡆࡊࡎࡐ࠱ࡆࡘࡁࡃࡋࡆࠫक़"),cWbkR6iUZsnJQj14(u"࠭ࡉࡇࡋࡏࡑ࠲ࡋࡎࡈࡎࡌࡗࡍ࠭ख़")]
SYGOE6WVFNdKf += [A0aqj9uclgOtByJ6F4bz(u"࡚ࠧࡖࡅࡣࡈࡎࡁࡏࡐࡈࡐࡘ࠭ग़"),A0aqj9uclgOtByJ6F4bz(u"ࠨࡃࡎࡓࡆࡓࠧज़"),mgLADoQ1pbtY(u"ࠩࡄࡏ࡜ࡇࡍࠨड़"),knTyjJ0sGIzuwbxRae(u"ࠪࡅࡑࡓࡁࡂࡔࡈࡊࠬढ़"),C3ZK1pu4rfmj8TsWUtBaM(u"ࠫࡘࡎࡏࡐࡈࡐࡅ࡝࠭फ़")]
IZA0MjTY5GSP8CHBOpQKm3 = [dBi72erQEtKDOwjNFaoAgSP(u"ࠬࡒࡁࡓࡑ࡝ࡅࠬय़"),ELfMeDTIFhJt685K(u"࠭ࡆࡂࡌࡈࡖࡘࡎࡏࡘࠩॠ"),knTyjJ0sGIzuwbxRae(u"ࠧࡕࡘࡉ࡙ࡓ࠭ॡ"),X2crmy67eZpkGTRd(u"ࠨࡎࡒࡈ࡞ࡔࡅࡕࠩॢ"),HDpmv4UXzlf72SK9(u"ࠩࡆࡍࡒࡇࡎࡐ࡙ࠪॣ"),JJA7fypmZFVlazvNI(u"ࠪࡗࡍࡇࡈࡊࡆࡑࡉ࡜࡙ࠧ।"),ELfMeDTIFhJt685K(u"ࠫࡆࡘࡁࡃࡕࡈࡉࡉ࠭॥")]
IZA0MjTY5GSP8CHBOpQKm3 += [EAVanJj1ers2GQud(u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡈࠧ०"),EAVanJj1ers2GQud(u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕࠨ१"),CDwSWB4v39N7(u"ࠧࡔࡊࡒࡊࡍࡇࠧ२"),maUl7SPesynF1j(u"ࠨ࡙ࡈࡇࡎࡓࡁ࠲ࠩ३"),A0aqj9uclgOtByJ6F4bz(u"࡚ࠩࡉࡈࡏࡍࡂ࠴ࠪ४")]
jGIE13SrW89cQsBx4aDYl = [OBsrtQo2pPlgURCxJYbj9iXMD(u"ࠪࡘࡎࡑࡁࡂࡖࠪ५"),maUl7SPesynF1j(u"ࠫࡆ࡟ࡌࡐࡎࠪ६"),cWbkR6iUZsnJQj14(u"ࠬࡌࡏࡔࡖࡄࠫ७"),knTyjJ0sGIzuwbxRae(u"࠭ࡆࡂࡄࡕࡅࡐࡇࠧ८"),HDpmv4UXzlf72SK9(u"࡚ࠧࡃࡔࡓ࡙࠭९"),cWbkR6iUZsnJQj14(u"ࠨࡕࡋࡅࡇࡇࡋࡂࡖ࡜ࠫ॰"),cWbkR6iUZsnJQj14(u"࡙ࠩࡅࡗࡈࡏࡏࠩॱ"),PPAUFrY8cduRT(u"ࠪࡆࡗ࡙ࡔࡆࡌࠪॲ")]
jGIE13SrW89cQsBx4aDYl += [pCTzbw4GyVJHjkcIMQ(u"ࠫࡐࡏࡒࡎࡃࡏࡏࠬॳ"),EF2tvxZHz5n4UruPhaViXKycI6SQR(u"ࠬࡇࡎࡊࡏࡈ࡞ࡎࡊࠧॴ"),YJxaX0MQOHb8oyCBFdnIAe(u"࠭ࡆࡂࡔࡈࡗࡐࡕࠧॵ"),Tcf5Ppn9UajDbzyM(u"ࠧࡉࡃࡏࡅࡈࡏࡍࡂࠩॶ"),nz8x32hX0qcjUPFZk5RdJsiwED(u"ࠨࡃࡏࡑࡘ࡚ࡂࡂࠩॷ"),PPAUFrY8cduRT(u"ࠩࡖࡌࡔࡕࡆࡏࡇࡗࠫॸ"),mgLADoQ1pbtY(u"ࠪࡈࡗࡇࡍࡂࡕ࠺ࠫॹ")]
jGIE13SrW89cQsBx4aDYl += [ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"ࠫࡈࡏࡍࡂࡈࡕࡉࡊ࠭ॺ"),X2crmy67eZpkGTRd(u"ࠬࡉࡉࡎࡃࡉࡅࡓ࡙ࠧॻ"),ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"࠭ࡅࡍࡋࡉ࡚ࡎࡊࡅࡐࠩॼ"),EF2tvxZHz5n4UruPhaViXKycI6SQR(u"ࠧࡇࡗࡑࡓࡓ࡚ࡖࠨॽ"),ShnRVsifKtc60zqQ(u"ࠨࡅࡌࡑࡆࡒࡉࡈࡊࡗࠫॾ"),ShnRVsifKtc60zqQ(u"ࠩࡆࡍࡒࡇ࠴࠱࠲ࠪॿ"),knTyjJ0sGIzuwbxRae(u"ࠪࡇࡎࡓࡁࡂࡄࡇࡓࠬঀ")]
jGIE13SrW89cQsBx4aDYl += [EF2tvxZHz5n4UruPhaViXKycI6SQR(u"ࠫࡆࡑࡗࡂࡏࡗ࡙ࡇࡋࠧঁ"),YJxaX0MQOHb8oyCBFdnIAe(u"ࠬࡓࡁࡔࡃ࡙ࡍࡉࡋࡏࠨং"),U0VwOviFaYPz2QGs45mJhMXf7Zk(u"࠭ࡄࡓࡃࡐࡅࡈࡇࡆࡆࠩঃ"),YJxaX0MQOHb8oyCBFdnIAe(u"ࠧࡇࡗࡖࡌࡆࡘࡔࡗࠩ঄"),CDwSWB4v39N7(u"ࠨࡅࡌࡑࡆ࡝ࡂࡂࡕࠪঅ"),A0aqj9uclgOtByJ6F4bz(u"ࠩࡄࡌ࡜ࡇࡋࠨআ"),dBi72erQEtKDOwjNFaoAgSP(u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠶ࠬই"),YJxaX0MQOHb8oyCBFdnIAe(u"࡛ࠫࡏࡄࡆࡑࡑࡗࡆࡋࡍࠨঈ")]
jGIE13SrW89cQsBx4aDYl += [knTyjJ0sGIzuwbxRae(u"ࠬࡑࡁࡕࡍࡒࡘ࡙࡜ࠧউ"),mg3CbXMA2ouZzQDhRqB(u"࠭ࡓࡆࡔࡌࡉࡘ࡚ࡉࡎࡇࠪঊ"),n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"ࠧࡇࡗࡖࡌࡆࡘࡖࡊࡆࡈࡓࠬঋ"),ELfMeDTIFhJt685K(u"ࠨࡅࡌࡑࡆ࠺ࡐࠨঌ"),knTyjJ0sGIzuwbxRae(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠴ࠫ঍"),PPAUFrY8cduRT(u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙࠷࠭঎"),cWbkR6iUZsnJQj14(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠷࠭এ"),maUl7SPesynF1j(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠺ࠧঐ")]
alEVIeCPBxosqg3n2SdjyWUb8 = [n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"࡙࠭ࡐࡗࡗ࡙ࡇࡋࠧ঑"),JJA7fypmZFVlazvNI(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡘࡌࡈࡊࡕࡓࠨ঒"),mg3CbXMA2ouZzQDhRqB(u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡓࡐࡆ࡟ࡌࡊࡕࡗࡗࠬও"),owbMhINBQsmx70guApW(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡇࡍࡇࡎࡏࡇࡏࡗࠬঔ")]
alEVIeCPBxosqg3n2SdjyWUb8 += [HDpmv4UXzlf72SK9(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎࠨক"),Tcf5Ppn9UajDbzyM(u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯࡙ࡍࡉࡋࡏࡔࠩখ"),OBsrtQo2pPlgURCxJYbj9iXMD(u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰ࡔࡑࡇ࡙ࡍࡋࡖࡘࡘ࠭গ"),KKi79PFqsYB0dWSRgaJ3DyE(u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱ࡈࡎࡁࡏࡐࡈࡐࡘ࠭ঘ"),CDwSWB4v39N7(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲ࡒࡉࡗࡇࡖࠫঙ"),nz8x32hX0qcjUPFZk5RdJsiwED(u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡈࡂࡕࡋࡘࡆࡍࡓࠨচ")]
A3IWNgF0q7wp = [knTyjJ0sGIzuwbxRae(u"ࠩࡓࡖࡎ࡜ࡁࡕࡇࠪছ")]+SYGOE6WVFNdKf+[ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"ࠪࡑࡎ࡞ࡅࡅࠩজ")]+IZA0MjTY5GSP8CHBOpQKm3+[pCTzbw4GyVJHjkcIMQ(u"ࠫࡕ࡛ࡂࡍࡋࡆࠫঝ")]+jGIE13SrW89cQsBx4aDYl+[pCTzbw4GyVJHjkcIMQ(u"ࠬࡖࡒࡊࡘࡄࡘࡊ࠭ঞ")]+alEVIeCPBxosqg3n2SdjyWUb8
nMZ1ARzHE34QGFukObX = [KKi79PFqsYB0dWSRgaJ3DyE(u"࡙࠭ࡕࡄࡢࡇࡍࡇࡎࡏࡇࡏࡗࠬট")]
wJFsv9KC6N = [mg3CbXMA2ouZzQDhRqB(u"ࠧࡑࡔࡌ࡚ࡆ࡚ࡅࠨঠ"),maUl7SPesynF1j(u"ࠨࡏࡌ࡜ࡊࡊࠧড"),YJxaX0MQOHb8oyCBFdnIAe(u"ࠩࡓ࡙ࡇࡒࡉࡄࠩঢ")]
VBcCjEPRTWb = [SODvU3Ibq5VzC(u"ࠪࡑ࠸࡛ࠧণ"),SODvU3Ibq5VzC(u"ࠫࡎࡖࡔࡗࠩত"),KhUG1NV9bln5zXjptqFW6dgo(u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐࠪথ"),maUl7SPesynF1j(u"࠭ࡉࡇࡋࡏࡑࠬদ"),knTyjJ0sGIzuwbxRae(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨধ")]
w8LU7jJRPFAnplBeNy9IQVD0Oqg5d  = [k4IUieraScH9DV1N7pJgQosYAx5l(u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡖࡊࡆࡈࡓࡘ࠭ন"),C3ZK1pu4rfmj8TsWUtBaM(u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡑࡎࡄ࡝ࡑࡏࡓࡕࡕࠪ঩"),ELfMeDTIFhJt685K(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡅࡋࡅࡓࡔࡅࡍࡕࠪপ"),mgLADoQ1pbtY(u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯ࡏࡍ࡛ࡋࡓࠨফ"),cWbkR6iUZsnJQj14(u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰ࡌࡆ࡙ࡈࡕࡃࡊࡗࠬব")]
w8LU7jJRPFAnplBeNy9IQVD0Oqg5d += [knTyjJ0sGIzuwbxRae(u"࠭ࡉࡇࡋࡏࡑ࠲ࡇࡒࡂࡄࡌࡇࠬভ"),ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"ࠧࡊࡈࡌࡐࡒ࠳ࡅࡏࡉࡏࡍࡘࡎࠧম")]
w8LU7jJRPFAnplBeNy9IQVD0Oqg5d += [nz8x32hX0qcjUPFZk5RdJsiwED(u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯࡙ࡍࡉࡋࡏࡔࠩয"),n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡔࡑࡇ࡙ࡍࡋࡖࡘࡘ࠭র"),pCTzbw4GyVJHjkcIMQ(u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱ࡈࡎࡁࡏࡐࡈࡐࡘ࠭঱")]
w8LU7jJRPFAnplBeNy9IQVD0Oqg5d += [HDpmv4UXzlf72SK9(u"ࠫࡎࡖࡔࡗ࠯ࡏࡍ࡛ࡋࠧল"),ShnRVsifKtc60zqQ(u"ࠬࡏࡐࡕࡘ࠰ࡑࡔ࡜ࡉࡆࡕࠪ঳"),OzU6t0qcH7MQabeBYK8vgoG(u"࠭ࡉࡑࡖ࡙࠱ࡘࡋࡒࡊࡇࡖࠫ঴")]
w8LU7jJRPFAnplBeNy9IQVD0Oqg5d += [cWbkR6iUZsnJQj14(u"ࠧࡎ࠵ࡘ࠱ࡑࡏࡖࡆࠩ঵"),OzU6t0qcH7MQabeBYK8vgoG(u"ࠨࡏ࠶࡙࠲ࡓࡏࡗࡋࡈࡗࠬশ"),k4IUieraScH9DV1N7pJgQosYAx5l(u"ࠩࡐ࠷࡚࠳ࡓࡆࡔࡌࡉࡘ࠭ষ")]
o7HNMv1XxyUncsOqg56BtSARG9bpzr = list(filter(lambda tfDSQhVJorIjuY3L0s1NMynTGcqzd: tfDSQhVJorIjuY3L0s1NMynTGcqzd not in w8LU7jJRPFAnplBeNy9IQVD0Oqg5d+nMZ1ARzHE34QGFukObX+wJFsv9KC6N+VBcCjEPRTWb,A3IWNgF0q7wp))
FWwniG0Em8kBIT3QV6tKfpa4 = o7HNMv1XxyUncsOqg56BtSARG9bpzr+VBcCjEPRTWb
bychWmvV7a = o7HNMv1XxyUncsOqg56BtSARG9bpzr+w8LU7jJRPFAnplBeNy9IQVD0Oqg5d
HCGlQVYcUfeuShJXAjv02n9KNEO = bychWmvV7a+nMZ1ARzHE34QGFukObX
Lly9tr1nv2IA4 = FWwniG0Em8kBIT3QV6tKfpa4+nMZ1ARzHE34QGFukObX
QEz4FHoqIrGm9x2vVgJU = [dBi72erQEtKDOwjNFaoAgSP(u"ࠪࡅࡐࡕࡁࡎࠩস"),SODvU3Ibq5VzC(u"ࠫࡆࡑࡗࡂࡏࠪহ"),CDwSWB4v39N7(u"ࠬࡏࡆࡊࡎࡐࠫ঺"),ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"࠭ࡋࡂࡔࡅࡅࡑࡇࡔࡗࠩ঻"),mg3CbXMA2ouZzQDhRqB(u"ࠧࡂࡎࡐࡅࡆࡘࡅࡇ়ࠩ"),ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"ࠨࡕࡋࡓࡔࡌࡍࡂ࡚ࠪঽ"),YJxaX0MQOHb8oyCBFdnIAe(u"ࠩࡖࡌࡎࡇࡖࡐࡋࡆࡉࠬা"),U0VwOviFaYPz2QGs45mJhMXf7Zk(u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫি"),OBsrtQo2pPlgURCxJYbj9iXMD(u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏࠩী"),SODvU3Ibq5VzC(u"ࠬࡓ࠳ࡖࠩু"),nz8x32hX0qcjUPFZk5RdJsiwED(u"࠭ࡉࡑࡖ࡙ࠫূ"),KhUG1NV9bln5zXjptqFW6dgo(u"ࠧࡃࡑࡎࡖࡆ࠭ৃ"),ELfMeDTIFhJt685K(u"ࠨࡇࡏࡇࡎࡔࡅࡎࡃࠪৄ"),KKi79PFqsYB0dWSRgaJ3DyE(u"ࠩࡄࡖࡆࡈࡉࡄࡖࡒࡓࡓ࡙ࠧ৅")]
NOT_TO_TEST_ALL_SERVERS = [OzU6t0qcH7MQabeBYK8vgoG(u"ࠪࡣࡆࡑࡏࡠࠩ৆"),HDpmv4UXzlf72SK9(u"ࠫࡤࡇࡋࡘࡡࠪে"),n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"ࠬࡥࡉࡇࡎࡢࠫৈ"),EF2tvxZHz5n4UruPhaViXKycI6SQR(u"࠭࡟ࡌࡔࡅࡣࠬ৉"),k4IUieraScH9DV1N7pJgQosYAx5l(u"ࠧࡠࡏࡕࡊࡤ࠭৊"),HDpmv4UXzlf72SK9(u"ࠨࡡࡖࡌࡒࡥࠧো"),ELfMeDTIFhJt685K(u"ࠩࡢࡗࡍ࡜࡟ࠨৌ"),nz8x32hX0qcjUPFZk5RdJsiwED(u"ࠪࡣ࡞࡛ࡔࡠ্ࠩ"),A0aqj9uclgOtByJ6F4bz(u"ࠫࡤࡊࡌࡎࡡࠪৎ"),KhUG1NV9bln5zXjptqFW6dgo(u"ࠬࡥࡍࡖࠩ৏"),SODvU3Ibq5VzC(u"࠭࡟ࡊࡒࠪ৐"),KKi79PFqsYB0dWSRgaJ3DyE(u"ࠧࡠࡄࡎࡖࡤ࠭৑"),OBsrtQo2pPlgURCxJYbj9iXMD(u"ࠨࡡࡈࡐࡈࡥࠧ৒"),OBsrtQo2pPlgURCxJYbj9iXMD(u"ࠩࡢࡅࡗ࡚࡟ࠨ৓")]
VsPYkDF9muSrMQfKW0XI6t = [ShnRVsifKtc60zqQ(u"ࠪࡑࡊࡔࡕࡠࡔࡈ࡚ࡊࡘࡓࡆࡆࡢࡔࡊࡘࡍࠨ৔"),HDpmv4UXzlf72SK9(u"ࠫࡒࡋࡎࡖࡡࡄࡗࡈࡋࡎࡅࡇࡇࡣࡕࡋࡒࡎࠩ৕"),mg3CbXMA2ouZzQDhRqB(u"ࠬࡓࡅࡏࡗࡢࡈࡊ࡙ࡃࡆࡐࡇࡉࡉࡥࡐࡆࡔࡐࠫ৖"),ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"࠭ࡍࡆࡐࡘࡣࡗࡇࡎࡅࡑࡐࡍ࡟ࡋࡄࡠࡒࡈࡖࡒ࠭ৗ"),JJA7fypmZFVlazvNI(u"ࠧࡎࡇࡑ࡙ࡤࡘࡅࡗࡇࡕࡗࡊࡊ࡟ࡕࡇࡐࡔࠬ৘"),YJxaX0MQOHb8oyCBFdnIAe(u"ࠨࡏࡈࡒ࡚ࡥࡁࡔࡅࡈࡒࡉࡋࡄࡠࡖࡈࡑࡕ࠭৙"),CDwSWB4v39N7(u"ࠩࡐࡉࡓ࡛࡟ࡅࡇࡖࡇࡊࡔࡄࡆࡆࡢࡘࡊࡓࡐࠨ৚"),LHX65I9nkx0PstgcVY24uSi(u"ࠪࡑࡊࡔࡕࡠࡔࡄࡒࡉࡕࡍࡊ࡜ࡈࡈࡤ࡚ࡅࡎࡒࠪ৛")]
X7XP2SYvJM8bUpOG1m40Z = [o4bNzIQGYj8En,ELfMeDTIFhJt685K(u"࠵࠺࠶ଢ଼"),pCTzbw4GyVJHjkcIMQ(u"࠶࠼࠰୬"),U0VwOviFaYPz2QGs45mJhMXf7Zk(u"࠲࠹࠳୯"),OzU6t0qcH7MQabeBYK8vgoG(u"࠵࠾࠶୤"),owbMhINBQsmx70guApW(u"࠲࠷࠲୧"),owbMhINBQsmx70guApW(u"࠶࠽࠶୫"),KhUG1NV9bln5zXjptqFW6dgo(u"࠸࠹࠰୥"),mgLADoQ1pbtY(u"࠴࠶࠳୨"),EAVanJj1ers2GQud(u"࠹࠷࠰୞"),knTyjJ0sGIzuwbxRae(u"࠵࠱࠲୮"),cWbkR6iUZsnJQj14(u"࠸࠶࠵ୣ"),dBi72erQEtKDOwjNFaoAgSP(u"࠸࠷࠵୪"),OzU6t0qcH7MQabeBYK8vgoG(u"࠻࠴࠱୦"),ELfMeDTIFhJt685K(u"࠽࠶࠱୭"),OBsrtQo2pPlgURCxJYbj9iXMD(u"࠳࠳࠵࠵ୢ"),ELfMeDTIFhJt685K(u"࠺࠻࠼࠴ୡ"),ELfMeDTIFhJt685K(u"࠷࠰࠳࠲ୟ"),U0VwOviFaYPz2QGs45mJhMXf7Zk(u"࠱࠱࠺࠳ୠ"),U0VwOviFaYPz2QGs45mJhMXf7Zk(u"࠳࠴࠴࠵୩")]
oLnpshIVAX7adGtv = [ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"ࠫ࠷࠻࠴ࡥࡦ࠶ࡥ࠹࠶࠹ࡥ࠺ࡥ࠺࠽࠷ࡤ࠵ࡧ࠴࠵࠼࡫ࡥ࠸࠺ࡦࡩࡧ࡬࠲࠺ࠩড়"),pCTzbw4GyVJHjkcIMQ(u"ࠬ࠷࠵࠱ࡦ࠵࠶࡫࠷࠭ࡤ࠷࠻ࡥ࠲࠺࠰࠳࠳࠰ࡥࡦ࠾࠴࠮ࡧ࠼࠶࠸ࡩࡡࡧ࠺࠸࠼࠸࠺ࠧঢ়"),Tcf5Ppn9UajDbzyM(u"࠭࠳࠺࠻࠴ࡩ࠾ࡩ࠵࠮࠹ࡨࡩ࠸࠳࠴ࡦࡧ࠵࠱࠽࠺ࡣ࠱࠯ࡩࡨ࠼࠿࠲ࡣࡣࡧࡨ࠸ࡪ࠵ࠨ৞"),Tcf5Ppn9UajDbzyM(u"ࠧ࠸࠸ࡥ࠸࡫ࡩ࠳࠵ࡨࡦࡨ࠶࠿ࡤ࠺ࡥ࠸࠹ࡦ࠷࠵ࡧ࠵࠹࠴࠹ࡩࡤ࠺࠳࠷ࡧࠬয়"),A0aqj9uclgOtByJ6F4bz(u"ࠨ࠳࡙ࡒࡸࡓࡴࡍ࠳ࡲࡆࡗ࡞࡫ࡔࡐࡆࡦࡈࡓࡊ࠲ࡍ࡛࡝ࡏࡰࡪ࠱ࡦ࡭࡞ࡼ࠭ৠ"),KKi79PFqsYB0dWSRgaJ3DyE(u"ࠩࡤ࠸࡫࠽ࡦࡣ࠳࠷࠱࠷ࡪࡥࡧ࠯࠷࠴࠼࠷࠭࠹࠸࠷ࡦ࠲࠸࠲ࡦ࠵࠵࠺࠹ࡪ࠴ࡥࡦࡦࠫৡ"),maUl7SPesynF1j(u"ࠪ࠶ࡧ࠹࠴࠱ࡣ࠹࠼࠾࠶ࡡ࠶࠶࠳࠵ࡩࡨࡣ࠴࠹࠵ࡧ࠶࠷࠴࠶ࡦ࠼࠺࠷࡫࠸ࠨৢ"),owbMhINBQsmx70guApW(u"ࠫࡨࡩ࠲࠷࠵ࡤࡦ࠶࡫࠵࠱࠶࠷ࡨ࠷ࡩࡡ࠶ࡦ࠸ࡨ࠸࡬࠹ࡦ࠵ࡦ࠷࠽࠼ࡥࡤࡣ࠴࠵࠵࠾࠳࠹࠻ࡤ࠻࠸࠭ৣ"),maUl7SPesynF1j(u"ࠬ࠷ࡣ࠴ࡦ࠶ࡥࡪ࠷࠸࠶ࡦࡩ࠸ࡧ࡬࠶ࡢࡨ࠸࠷࠸ࡩ࠷࠱࠶࠳ࡦ࠸࠺࠷ࡤ࠻ࡨ࠽࠾ࡨࡥ࠵࠸࠹ࡥࡪ࠿ࠧ৤"),A0aqj9uclgOtByJ6F4bz(u"࠭࠴࠵ࡨ࠷࠴࠽ࡪ࠴ࡢ࠴ࡰࡷ࡭࠷ࡢ࠴ࡤࡧ࠸࠾ࡧ࠶࠵࠺࠴࠻࡫࠻ࡰ࠲࠲࠴࠴࠸࡬ࡪࡴࡰ࠷ࡥ࠹࠷࠷ࡧࡥ࠸࠷࠵࠺࠲ࠨ৥"),A0aqj9uclgOtByJ6F4bz(u"ࠧࡣࡤ࠸࠷࠽࠷࠸࠱࠯࠸ࡨ࠶ࡧ࠭࠵ࡥ࠵࠺࠲ࡧࡢ࠷ࡤ࠰࠵࠻ࡨࡢ࠳࠶ࡥ࠺࠾ࡩ࠸ࡢ࠯࠳࠴࠲࠷ࡶ࠶࠻ࡤ࡬࠷࠻ࡱ࠲ࡣ࠹࠴ࠬ০"),A0aqj9uclgOtByJ6F4bz(u"ࠨࡨ࠼ࡪ࠽࠷࠷࠸࠶࠰ࡥࡧ࠿࠸࠮࠶࠴ࡨ࠷࠳࠸࠸࠲ࡧ࠱࠻࠸࠵ࡣ࠺࠷࠺࠺࠸࠵࠴࠳࠰࠴࠵࠳࠱࡮࡫ࡦ࠸ࡩ࡫࡬࡭ࡩࡦࡦࡷ࠭১")]
EER7BgNGhMk43SQYvZUaxc8629I5 = [C3ZK1pu4rfmj8TsWUtBaM(u"ࠩࡶࡧࡷࡧࡰࡦࡱࡳࡷࠬ২"),pCTzbw4GyVJHjkcIMQ(u"ࠪࡷࡨࡸࡡࡱࡧࡵࡥࡵ࡯ࠧ৩"),mg3CbXMA2ouZzQDhRqB(u"ࠫࡸࡩࡲࡢࡲ࡬ࡲ࡬ࡧ࡮ࡵࠩ৪"),X2crmy67eZpkGTRd(u"ࠬࡹࡣࡳࡣࡳ࡭ࡳ࡭ࡲࡰࡤࡲࡸࠬ৫"),A0aqj9uclgOtByJ6F4bz(u"࠭ࡳࡤࡴࡤࡴࡪࡻࡰࠨ৬"),ShnRVsifKtc60zqQ(u"ࠧࡴࡥࡵࡥࡵ࡫࠮ࡥࡱࠪ৭"),cWbkR6iUZsnJQj14(u"ࠨࡴࡤࡴ࡮ࡪࡡࡱ࡫࠱ࡧࡴࡳࠧ৮"),HDpmv4UXzlf72SK9(u"ࠩࡵࡩࡵࡲࡩࡵ࠰ࡧࡩࡻ࠭৯"),HDpmv4UXzlf72SK9(u"ࠪ࠵࠷࠽࠮࠱࠰࠳࠲࠶࠭ৰ"),A0aqj9uclgOtByJ6F4bz(u"ࠫࡸ࡫ࡲࡷࡧࡵ࠶࠳ࡱ࡯ࡥ࡫ࡨࡱࡦࡪࠧৱ")]
Ld4mEbhPnze21y = {
	 mg3CbXMA2ouZzQDhRqB(u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙࡟࠱ࠩ৲")	: o4bNzIQGYj8En
	,ELfMeDTIFhJt685K(u"࠭ࡁࡍࡃࡕࡅࡇ࠭৳")		: LHX65I9nkx0PstgcVY24uSi(u"࠳࠳୰")
	,ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"ࠧࡊࡈࡌࡐࡒ࠭৴")		: nz8x32hX0qcjUPFZk5RdJsiwED(u"࠵࠴ୱ")
	,JJA7fypmZFVlazvNI(u"ࠨࡒࡄࡒࡊ࡚ࠧ৵")		: CDwSWB4v39N7(u"࠷࠵୲")
	,KhUG1NV9bln5zXjptqFW6dgo(u"ࠩࡄࡐࡒࡇࡁࡓࡇࡉࠫ৶")		: dBi72erQEtKDOwjNFaoAgSP(u"࠹࠶୳")
	,pCTzbw4GyVJHjkcIMQ(u"ࠪࡗࡍࡕࡏࡇࡏࡄ࡜ࠬ৷")		: OBsrtQo2pPlgURCxJYbj9iXMD(u"࠻࠰୴")
	,cWbkR6iUZsnJQj14(u"ࠫࡆࡒࡆࡂࡖࡌࡑࡎ࠭৸")		: Tcf5Ppn9UajDbzyM(u"࠶࠱୵")
	,YJxaX0MQOHb8oyCBFdnIAe(u"ࠬࡇࡋࡐࡃࡐࠫ৹")		: ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"࠸࠲୶")
	,n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"࠭ࡈࡂࡎࡄࡇࡎࡓࡁࠨ৺")		: LHX65I9nkx0PstgcVY24uSi(u"࠺࠳୷")
	,knTyjJ0sGIzuwbxRae(u"ࠧࡄࡋࡐࡅࡋࡇࡎࡔࠩ৻")		: CDwSWB4v39N7(u"࠼࠴୸")
	,OzU6t0qcH7MQabeBYK8vgoG(u"ࠨࡎࡌ࡚ࡊ࡚ࡖࠨৼ")		: SODvU3Ibq5VzC(u"࠵࠵࠶୹")
	,mgLADoQ1pbtY(u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘࠫ৽")		: OBsrtQo2pPlgURCxJYbj9iXMD(u"࠶࠷࠰୺")
	,Tcf5Ppn9UajDbzyM(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗࠫ৾")		: A0aqj9uclgOtByJ6F4bz(u"࠷࠲࠱୻")
	,JJA7fypmZFVlazvNI(u"ࠫࡆࡒࡋࡂ࡙ࡗࡌࡆࡘࠧ৿")	: mgLADoQ1pbtY(u"࠱࠴࠲୼")
	,U0VwOviFaYPz2QGs45mJhMXf7Zk(u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭਀")		: KKi79PFqsYB0dWSRgaJ3DyE(u"࠲࠶࠳୽")
	,KhUG1NV9bln5zXjptqFW6dgo(u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓࡠ࠳ࠪਁ")	: cWbkR6iUZsnJQj14(u"࠳࠸࠴୾")
	,C3ZK1pu4rfmj8TsWUtBaM(u"ࠧࡓࡃࡑࡈࡔࡓࡓࡠ࠲ࠪਂ")	: ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"࠴࠺࠵୿")
	,mg3CbXMA2ouZzQDhRqB(u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕࡢ࠶ࠬਃ")	: ELfMeDTIFhJt685K(u"࠵࠼࠶஀")
	,ShnRVsifKtc60zqQ(u"ࠩࡐࡓ࡛ࡏ࡚ࡍࡃࡑࡈࠬ਄")	: cWbkR6iUZsnJQj14(u"࠶࠾࠰஁")
	,maUl7SPesynF1j(u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗࡤ࠹ࠧਅ")	: CDwSWB4v39N7(u"࠷࠹࠱ஂ")
	,LHX65I9nkx0PstgcVY24uSi(u"ࠫࡆࡘࡂࡍࡋࡒࡒ࡟࠭ਆ")		: k4IUieraScH9DV1N7pJgQosYAx5l(u"࠲࠱࠲ஃ")
	,Tcf5Ppn9UajDbzyM(u"࡙ࠬࡅࡓࡋࡈࡗ࠹࡝ࡁࡕࡅࡋࠫਇ")	: ShnRVsifKtc60zqQ(u"࠳࠳࠳஄")
	,LHX65I9nkx0PstgcVY24uSi(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚ࡖࡊࡒࠪਈ")	: EF2tvxZHz5n4UruPhaViXKycI6SQR(u"࠴࠵࠴அ")
	,maUl7SPesynF1j(u"ࠧࡊࡒࡗ࡚ࡤ࠶ࠧਉ")		: Tcf5Ppn9UajDbzyM(u"࠵࠷࠵ஆ")
	,ShnRVsifKtc60zqQ(u"ࠨࡃࡎ࡛ࡆࡓࠧਊ")		: CDwSWB4v39N7(u"࠶࠹࠶இ")
	,jL1E5AKfwBDv6xmeQtUXcJ3d(u"ࠩࡄࡖࡆࡈࡓࡆࡇࡇࠫ਋")		: owbMhINBQsmx70guApW(u"࠷࠻࠰ஈ")
	,C3ZK1pu4rfmj8TsWUtBaM(u"ࠪࡑࡊࡔࡕࡔࡡ࠳ࠫ਌")		: mgLADoQ1pbtY(u"࠸࠶࠱உ")
	,owbMhINBQsmx70guApW(u"ࠫࡋࡇࡖࡐࡔࡌࡘࡊ࡙ࠧ਍")	: Tcf5Ppn9UajDbzyM(u"࠲࠸࠲ஊ")
	,jL1E5AKfwBDv6xmeQtUXcJ3d(u"ࠬࡏࡐࡕࡘࡢ࠵ࠬ਎")		: Tcf5Ppn9UajDbzyM(u"࠳࠺࠳஋")
	,PPAUFrY8cduRT(u"࡙࠭ࡕࡄࡢࡇࡍࡇࡎࡏࡇࡏࡗࠬਏ")	: owbMhINBQsmx70guApW(u"࠴࠼࠴஌")
	,OzU6t0qcH7MQabeBYK8vgoG(u"ࠧࡄࡋࡐࡅࡓࡕࡗࠨਐ")		: U0VwOviFaYPz2QGs45mJhMXf7Zk(u"࠶࠴࠵஍")
	,k4IUieraScH9DV1N7pJgQosYAx5l(u"ࠨࡕࡋࡍࡆ࡜ࡏࡊࡅࡈࠫ਑")	: dBi72erQEtKDOwjNFaoAgSP(u"࠷࠶࠶எ")
	,PPAUFrY8cduRT(u"ࠩࡎࡅࡗࡈࡁࡍࡃࡗ࡚ࠬ਒")	: mg3CbXMA2ouZzQDhRqB(u"࠸࠸࠰ஏ")
	,YJxaX0MQOHb8oyCBFdnIAe(u"ࠪࡈࡔ࡝ࡎࡍࡑࡄࡈࠬਓ")		: k4IUieraScH9DV1N7pJgQosYAx5l(u"࠹࠳࠱ஐ")
	,YJxaX0MQOHb8oyCBFdnIAe(u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘࡥ࠴ࠨਔ")	: PPAUFrY8cduRT(u"࠳࠵࠲஑")
	,nz8x32hX0qcjUPFZk5RdJsiwED(u"ࠬࡇࡋࡐࡃࡐࡇࡆࡓࠧਕ")		: C3ZK1pu4rfmj8TsWUtBaM(u"࠴࠷࠳ஒ")
	,X2crmy67eZpkGTRd(u"࠭ࡍ࡚ࡅࡌࡑࡆ࠭ਖ")		: CDwSWB4v39N7(u"࠵࠹࠴ஓ")
	,HDpmv4UXzlf72SK9(u"ࠧࡃࡑࡎࡖࡆ࠭ਗ")		: A0aqj9uclgOtByJ6F4bz(u"࠶࠻࠵ஔ")
	,JJA7fypmZFVlazvNI(u"ࠨࡏࡒ࡚ࡘ࠺ࡕࠨਘ")		: C3ZK1pu4rfmj8TsWUtBaM(u"࠷࠽࠶க")
	,cWbkR6iUZsnJQj14(u"ࠩࡉࡅࡏࡋࡒࡔࡊࡒ࡛ࠬਙ")	: HDpmv4UXzlf72SK9(u"࠸࠿࠰஖")
	,HDpmv4UXzlf72SK9(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎࡠ࠲ࠪਚ"): KKi79PFqsYB0dWSRgaJ3DyE(u"࠺࠰࠱஗")
	,PPAUFrY8cduRT(u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏࡡ࠴ࠫਛ"): cWbkR6iUZsnJQj14(u"࠴࠲࠲஘")
	,mg3CbXMA2ouZzQDhRqB(u"ࠬࡉࡉࡎࡃ࠷࡙ࠬਜ")		: EAVanJj1ers2GQud(u"࠵࠴࠳ங")
	,SODvU3Ibq5VzC(u"࠭ࡅࡈ࡛ࡑࡓ࡜࠭ਝ")		: X2crmy67eZpkGTRd(u"࠶࠶࠴ச")
	,pCTzbw4GyVJHjkcIMQ(u"ࠧࡆࡉ࡜ࡈࡊࡇࡄࠨਞ")		: Tcf5Ppn9UajDbzyM(u"࠷࠸࠵஛")
	,HDpmv4UXzlf72SK9(u"ࠨࡎࡒࡈ࡞ࡔࡅࡕࠩਟ")		: EF2tvxZHz5n4UruPhaViXKycI6SQR(u"࠸࠺࠶ஜ")
	,owbMhINBQsmx70guApW(u"ࠩࡗ࡚ࡋ࡛ࡎࠨਠ")		: k4IUieraScH9DV1N7pJgQosYAx5l(u"࠹࠼࠰஝")
	,mg3CbXMA2ouZzQDhRqB(u"ࠪࡇࡎࡓࡁࡍࡋࡊࡌ࡙࠭ਡ")	: Tcf5Ppn9UajDbzyM(u"࠺࠷࠱ஞ")
	,C3ZK1pu4rfmj8TsWUtBaM(u"ࠫࡘࡎࡏࡐࡈࡓࡖࡔ࠭ਢ")		: JJA7fypmZFVlazvNI(u"࠴࠹࠲ட")
	,YJxaX0MQOHb8oyCBFdnIAe(u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡖࠧਣ")		: JJA7fypmZFVlazvNI(u"࠵࠻࠳஠")
	,OzU6t0qcH7MQabeBYK8vgoG(u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓࡠ࠷ࠪਤ")	: HDpmv4UXzlf72SK9(u"࠷࠳࠴஡")
	,JJA7fypmZFVlazvNI(u"ࠧࡆࡎࡆࡍࡓࡋࡍࡂࡡ࠳ࠫਥ")	: ShnRVsifKtc60zqQ(u"࠸࠵࠵஢")
	,owbMhINBQsmx70guApW(u"ࠨࡇࡏࡇࡎࡔࡅࡎࡃࡢ࠵ࠬਦ")	: X2crmy67eZpkGTRd(u"࠹࠷࠶ண")
	,JJA7fypmZFVlazvNI(u"ࠩࡐࡉࡓ࡛ࡓࡠ࠳ࠪਧ")		: EF2tvxZHz5n4UruPhaViXKycI6SQR(u"࠺࠹࠰த")
	,JJA7fypmZFVlazvNI(u"ࠪࡋࡑࡕࡂࡂࡎࡖࡉࡆࡘࡃࡉࠩਨ")	: cWbkR6iUZsnJQj14(u"࠻࠴࠱஥")
	,Tcf5Ppn9UajDbzyM(u"ࠫࡈࡏࡍࡂࡃࡅࡈࡔ࠭਩")		: ShnRVsifKtc60zqQ(u"࠵࠶࠲஦")
	,YJxaX0MQOHb8oyCBFdnIAe(u"ࠬ࡝ࡅࡄࡋࡐࡅ࠶࠭ਪ")		: OzU6t0qcH7MQabeBYK8vgoG(u"࠶࠸࠳஧")
	,X2crmy67eZpkGTRd(u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠱ࠨਫ")		: PPAUFrY8cduRT(u"࠷࠺࠴ந")
	,owbMhINBQsmx70guApW(u"ࠧࡔࡊࡄࡌࡎࡊࡎࡆ࡙ࡖࠫਬ")	: A0aqj9uclgOtByJ6F4bz(u"࠸࠼࠵ன")
	,C3ZK1pu4rfmj8TsWUtBaM(u"ࠨࡈࡄࡗࡊࡒࡈࡅ࠴ࠪਭ")		: U0VwOviFaYPz2QGs45mJhMXf7Zk(u"࠹࠾࠶ப")
	,ShnRVsifKtc60zqQ(u"ࠩࡉࡓࡘ࡚ࡁࠨਮ")		: SODvU3Ibq5VzC(u"࠻࠶࠰஫")
	,PPAUFrY8cduRT(u"ࠪࡅࡍ࡝ࡁࡌࠩਯ")		: OBsrtQo2pPlgURCxJYbj9iXMD(u"࠼࠱࠱஬")
	,n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"ࠫࡋࡇࡂࡓࡃࡎࡅࠬਰ")		: EAVanJj1ers2GQud(u"࠶࠳࠲஭")
	,CDwSWB4v39N7(u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡈࡗࡐࡔࡎࠫ਱")	: nz8x32hX0qcjUPFZk5RdJsiwED(u"࠷࠵࠳ம")
	,k4IUieraScH9DV1N7pJgQosYAx5l(u"࠭ࡓࡉࡑࡉࡌࡆ࠭ਲ")		: OBsrtQo2pPlgURCxJYbj9iXMD(u"࠸࠷࠴ய")
	,nz8x32hX0qcjUPFZk5RdJsiwED(u"ࠧࡃࡔࡖࡘࡊࡐࠧਲ਼")		: Tcf5Ppn9UajDbzyM(u"࠹࠹࠵ர")
	,mgLADoQ1pbtY(u"ࠨ࡛ࡄࡕࡔ࡚ࠧ਴")		: YJxaX0MQOHb8oyCBFdnIAe(u"࠺࠻࠶ற")
	,CDwSWB4v39N7(u"ࠩࡎࡅ࡙ࡑࡏࡖࡖࡈࠫਵ")		: JJA7fypmZFVlazvNI(u"࠻࠽࠰ல")
	,C3ZK1pu4rfmj8TsWUtBaM(u"ࠪࡈࡗࡇࡍࡂࡕ࠺ࠫਸ਼")		: mg3CbXMA2ouZzQDhRqB(u"࠼࠸࠱ள")
	,cWbkR6iUZsnJQj14(u"ࠫࡈࡏࡍࡂ࠶࠳࠴ࠬ਷")		: LHX65I9nkx0PstgcVY24uSi(u"࠶࠺࠲ழ")
	,ShnRVsifKtc60zqQ(u"ࠬࡒࡁࡓࡑ࡝ࡅࠬਸ")		: cWbkR6iUZsnJQj14(u"࠸࠲࠳வ")
	,ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"࠭ࡍ࠴ࡗࡢ࠴ࠬਹ")		: SODvU3Ibq5VzC(u"࠹࠴࠴ஶ")
	,A0aqj9uclgOtByJ6F4bz(u"ࠧࡎ࠵ࡘࡣ࠶࠭਺")		: YJxaX0MQOHb8oyCBFdnIAe(u"࠺࠶࠵ஷ")
	,pCTzbw4GyVJHjkcIMQ(u"ࠨࡃࡕࡅࡇࡏࡃࡕࡑࡒࡒࡘ࠭਻")	: mgLADoQ1pbtY(u"࠻࠸࠶ஸ")
	,owbMhINBQsmx70guApW(u"ࠩࡆࡐࡊࡇࡎࡆࡔࡢ࠴਼ࠬ")	: mgLADoQ1pbtY(u"࠼࠺࠰ஹ")
	,owbMhINBQsmx70guApW(u"ࠪࡇࡑࡋࡁࡏࡇࡕࡣ࠶࠭਽")	: n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"࠽࠵࠱஺")
	,JJA7fypmZFVlazvNI(u"ࠫࡗࡇࡎࡅࡑࡐࡗࡤ࠷ࠧਾ")	: C3ZK1pu4rfmj8TsWUtBaM(u"࠷࠷࠲஻")
	,mg3CbXMA2ouZzQDhRqB(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠷ࠧਿ")		: EAVanJj1ers2GQud(u"࠸࠹࠳஼")
	,maUl7SPesynF1j(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠲ࠨੀ")		: Tcf5Ppn9UajDbzyM(u"࠹࠻࠴஽")
	,jL1E5AKfwBDv6xmeQtUXcJ3d(u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠴ࠩੁ")		: cWbkR6iUZsnJQj14(u"࠺࠽࠵ா")
	,pCTzbw4GyVJHjkcIMQ(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠶ࠪੂ")		: OzU6t0qcH7MQabeBYK8vgoG(u"࠼࠵࠶ி")
	,YJxaX0MQOHb8oyCBFdnIAe(u"ࠩࡎࡅ࡙ࡑࡏࡕࡖ࡙ࠫ੃")		: HDpmv4UXzlf72SK9(u"࠽࠷࠰ீ")
	,JJA7fypmZFVlazvNI(u"ࠪࡇࡎࡓࡁࡄࡎࡘࡆࠬ੄")		: EAVanJj1ers2GQud(u"࠾࠲࠱ு")
	,ELfMeDTIFhJt685K(u"ࠫࡈࡏࡍࡂࡈࡕࡉࡊ࠭੅")		: mg3CbXMA2ouZzQDhRqB(u"࠸࠴࠲ூ")
	,dBi72erQEtKDOwjNFaoAgSP(u"࡙ࠬࡈࡐࡑࡉࡒࡊ࡚ࠧ੆")		: SODvU3Ibq5VzC(u"࠹࠶࠳௃")
	,OzU6t0qcH7MQabeBYK8vgoG(u"࠭ࡁࡌ࡙ࡄࡑ࡙࡛ࡂࡆࠩੇ")	: dBi72erQEtKDOwjNFaoAgSP(u"࠺࠸࠴௄")
	,LHX65I9nkx0PstgcVY24uSi(u"ࠧࡂࡎࡐࡗ࡙ࡈࡁࠨੈ")		: SODvU3Ibq5VzC(u"࠻࠺࠵௅")
	,mgLADoQ1pbtY(u"ࠨࡘࡄࡖࡇࡕࡎࠨ੉")		: KhUG1NV9bln5zXjptqFW6dgo(u"࠼࠼࠶ெ")
	,jL1E5AKfwBDv6xmeQtUXcJ3d(u"ࠩࡆࡍࡒࡇ࠴ࡑࠩ੊")		: maUl7SPesynF1j(u"࠽࠾࠰ே")
	,knTyjJ0sGIzuwbxRae(u"ࠪࡗࡊࡘࡉࡆࡕࡗࡍࡒࡋࠧੋ")	: EF2tvxZHz5n4UruPhaViXKycI6SQR(u"࠾࠹࠱ை")
	,X2crmy67eZpkGTRd(u"ࠫࡋ࡛ࡓࡉࡃࡕ࡚ࡎࡊࡅࡐࠩੌ")	: OBsrtQo2pPlgURCxJYbj9iXMD(u"࠹࠱࠲௉")
	,n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"ࠬࡌࡕࡔࡊࡄࡖ࡙࡜੍ࠧ")		: ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"࠺࠳࠳ொ")
	,nz8x32hX0qcjUPFZk5RdJsiwED(u"࠭ࡋࡊࡔࡐࡅࡑࡑࠧ੎")		: nz8x32hX0qcjUPFZk5RdJsiwED(u"࠻࠵࠴ோ")
	,pCTzbw4GyVJHjkcIMQ(u"ࠧࡅࡔࡄࡑࡆࡉࡁࡇࡇࠪ੏")	: mgLADoQ1pbtY(u"࠼࠷࠵ௌ")
	,OBsrtQo2pPlgURCxJYbj9iXMD(u"ࠨࡖࡌࡏࡆࡇࡔࠨ੐")		: knTyjJ0sGIzuwbxRae(u"࠽࠹࠶்")
	,mgLADoQ1pbtY(u"ࠩࡔࡊࡎࡒࡍࠨੑ")		: nz8x32hX0qcjUPFZk5RdJsiwED(u"࠾࠻࠰௎")
	,LHX65I9nkx0PstgcVY24uSi(u"ࠪࡗࡍࡇࡂࡂࡍࡄࡘ࡞࠭੒")	: KKi79PFqsYB0dWSRgaJ3DyE(u"࠿࠶࠱௏")
	,maUl7SPesynF1j(u"ࠫࡆࡔࡉࡎࡇ࡝ࡍࡉ࠭੓")		: SODvU3Ibq5VzC(u"࠹࠸࠲ௐ")
	,C3ZK1pu4rfmj8TsWUtBaM(u"ࠬࡉࡉࡎࡃ࡚ࡆࡆ࡙ࠧ੔")		: OzU6t0qcH7MQabeBYK8vgoG(u"࠺࠺࠳௑")
	,pCTzbw4GyVJHjkcIMQ(u"࠭ࡆࡂࡔࡈࡗࡐࡕࠧ੕")		: n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"࠻࠼࠴௒")
	,pCTzbw4GyVJHjkcIMQ(u"ࠧࡘࡇࡆࡍࡒࡇ࠲ࠨ੖")		: KhUG1NV9bln5zXjptqFW6dgo(u"࠴࠴࠵࠶௓")
	,SODvU3Ibq5VzC(u"ࠨࡉࡒࡓࡌࡒࡅࡔࡇࡄࡖࡈࡎࠧ੗")	: mg3CbXMA2ouZzQDhRqB(u"࠵࠵࠷࠰௔")
	,ELfMeDTIFhJt685K(u"ࠩࡖࡉࡗ࡜ࡉࡄࡇࡖࡣ࠻࠭੘")	: pCTzbw4GyVJHjkcIMQ(u"࠶࠶࠲࠱௕")
	,HDpmv4UXzlf72SK9(u"࡚ࠪࡎࡊࡅࡐࡐࡖࡅࡊࡓࠧਖ਼")	: pCTzbw4GyVJHjkcIMQ(u"࠷࠰࠴࠲௖")
	,JJA7fypmZFVlazvNI(u"ࠫࡒࡇࡓࡂࡘࡌࡈࡊࡕࠧਗ਼")	: LHX65I9nkx0PstgcVY24uSi(u"࠱࠱࠶࠳ௗ")
	,U0VwOviFaYPz2QGs45mJhMXf7Zk(u"ࠬࡇ࡙ࡍࡑࡏࠫਜ਼")		: C3ZK1pu4rfmj8TsWUtBaM(u"࠲࠲࠸࠴௘")
	,LHX65I9nkx0PstgcVY24uSi(u"࠭ࡅࡍࡋࡉ࡚ࡎࡊࡅࡐࠩੜ")	: k4IUieraScH9DV1N7pJgQosYAx5l(u"࠳࠳࠺࠵௙")
	,HDpmv4UXzlf72SK9(u"ࠧࡇࡗࡑࡓࡓ࡚ࡖࠨ੝")		: pCTzbw4GyVJHjkcIMQ(u"࠴࠴࠼࠶௚")
	,ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"ࠨࡅࡏࡉࡆࡔࡅࡓࡡ࠵ࠫਫ਼")	: OBsrtQo2pPlgURCxJYbj9iXMD(u"࠵࠵࠾࠰௛")
	,ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘ࠶ࠬ੟")	: EF2tvxZHz5n4UruPhaViXKycI6SQR(u"࠶࠶࠹࠱௜")
}
o0pkONJQSbMDECiaBfdrRPn = {
	EAVanJj1ers2GQud(u"ࠪࡥ࡭ࡽࡡ࡬ࠩ੠")				:EF2tvxZHz5n4UruPhaViXKycI6SQR(u"๊ࠫ๎โฺࠢฦ๋ํอใࠡฬํๅ๏࠭੡")
	,n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"ࠬࡧ࡫ࡰࡣࡰࠫ੢")				:KKi79PFqsYB0dWSRgaJ3DyE(u"࠭ๅ้ไ฼ࠤศ้่ศ็ࠣห้่ฯ๋็ࠪ੣")
	,JJA7fypmZFVlazvNI(u"ࠧࡢ࡭ࡲࡥࡲࡩࡡ࡮ࠩ੤")				:OzU6t0qcH7MQabeBYK8vgoG(u"ࠨ็๋ๆ฾ࠦรไ๊ส้้ࠥวๆࠩ੥")
	,pCTzbw4GyVJHjkcIMQ(u"ࠩࡤ࡯ࡼࡧ࡭ࠨ੦")				:SODvU3Ibq5VzC(u"้ࠪํู่ࠡลๆ์ฬ๋ࠠศๆฯำ๏ีࠧ੧")
	,mgLADoQ1pbtY(u"ࠫࡦࡱࡷࡢ࡯ࡷࡹࡧ࡫ࠧ੨")			:PPAUFrY8cduRT(u"๋่ࠬใ฻ࠣห่๎วๆࠢอ๎ํฮࠧ੩")
	,k4IUieraScH9DV1N7pJgQosYAx5l(u"࠭ࡡ࡭ࡣࡵࡥࡧ࠭੪")				:X2crmy67eZpkGTRd(u"ࠧๆ๊ๅ฽้ࠥไࠡษ็฽ึฮࠧ੫")
	,KKi79PFqsYB0dWSRgaJ3DyE(u"ࠨࡣ࡯ࡪࡦࡺࡩ࡮࡫ࠪ੬")				:KKi79PFqsYB0dWSRgaJ3DyE(u"่ࠩ์็฿ࠠศๆ่๊อืࠠศๆไห฼๋๊ࠨ੭")
	,KKi79PFqsYB0dWSRgaJ3DyE(u"ࠪࡥࡱࡱࡡࡸࡶ࡫ࡥࡷ࠭੮")			:mg3CbXMA2ouZzQDhRqB(u"๊ࠫ๎โฺࠢๅ๊ฬฯࠠศๆๆ์ะืࠧ੯")
	,maUl7SPesynF1j(u"ࠬࡧ࡬࡮ࡣࡤࡶࡪ࡬ࠧੰ")				:PPAUFrY8cduRT(u"࠭ๅ้ไ฼ࠤ็์วสࠢส่๊฿วาใࠪੱ")
	,dBi72erQEtKDOwjNFaoAgSP(u"ࠧࡢ࡮ࡰࡷࡹࡨࡡࠨੲ")				:mg3CbXMA2ouZzQDhRqB(u"ࠨ็๋ๆ฾ࠦวๅ็ุ฻อฯࠧੳ")
	,OBsrtQo2pPlgURCxJYbj9iXMD(u"ࠩࡤࡲ࡮ࡳࡥࡻ࡫ࡧࠫੴ")				:YJxaX0MQOHb8oyCBFdnIAe(u"้ࠪํู่ࠡษ้้๏ࠦาะࠩੵ")
	,EF2tvxZHz5n4UruPhaViXKycI6SQR(u"ࠫࡦࡸࡡࡣ࡫ࡦࡸࡴࡵ࡮ࡴࠩ੶")			:YJxaX0MQOHb8oyCBFdnIAe(u"๋่ࠬใ฻ࠣวึอศ๋ๅࠣฮํ์าࠨ੷")
	,Tcf5Ppn9UajDbzyM(u"࠭ࡡࡳࡣࡥࡷࡪ࡫ࡤࠨ੸")				:X2crmy67eZpkGTRd(u"ࠧๆ๊ๅ฽ࠥ฿ัษࠢึ๎๏ีࠧ੹")
	,mg3CbXMA2ouZzQDhRqB(u"ࠨࡣࡵࡦࡱ࡯࡯࡯ࡼࠪ੺")				:JJA7fypmZFVlazvNI(u"่ࠩ์็฿ฺࠠำหࠤ้๐่็ิࠪ੻")
	,maUl7SPesynF1j(u"ࠪࡥࡾࡲ࡯࡭ࠩ੼")				:C3ZK1pu4rfmj8TsWUtBaM(u"๊ࠫ๎โฺࠢฦ๎้๎ไࠨ੽")
	,X2crmy67eZpkGTRd(u"ࠬࡨ࡯࡬ࡴࡤࠫ੾")				:U0VwOviFaYPz2QGs45mJhMXf7Zk(u"࠭ๅ้ไ฼ࠤอ้ัศࠩ੿")
	,Tcf5Ppn9UajDbzyM(u"ࠧࡣࡴࡶࡸࡪࡰࠧ઀")				:X2crmy67eZpkGTRd(u"ࠨ็๋ๆ฾ࠦศาีอ๎ั࠭ઁ")
	,k4IUieraScH9DV1N7pJgQosYAx5l(u"ࠩࡦ࡭ࡲࡧ࠴࠱࠲ࠪં")				:KhUG1NV9bln5zXjptqFW6dgo(u"้ࠪํู่ࠡีํ้ฬࠦ࠴࠱࠲ࠪઃ")
	,nz8x32hX0qcjUPFZk5RdJsiwED(u"ࠫࡨ࡯࡭ࡢ࠶ࡳࠫ઄")				:n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"๋่ࠬใ฻ࠣื๏๋วࠡใ๋ีࠥฮ๊ࠨઅ")
	,Tcf5Ppn9UajDbzyM(u"࠭ࡣࡪ࡯ࡤ࠸ࡺ࠭આ")				:ELfMeDTIFhJt685K(u"ࠧๆ๊ๅ฽ู๊ࠥๆษࠣๅํื๊้ࠩઇ")
	,EF2tvxZHz5n4UruPhaViXKycI6SQR(u"ࠨࡥ࡬ࡱࡦࡧࡢࡥࡱࠪઈ")				:KhUG1NV9bln5zXjptqFW6dgo(u"่ࠩ์็฿ࠠิ์่หࠥ฿ศะ๊ࠪઉ")
	,A0aqj9uclgOtByJ6F4bz(u"ࠪࡧ࡮ࡳࡡࡤ࡮ࡸࡦࠬઊ")				:mgLADoQ1pbtY(u"๊ࠫ๎โฺࠢึ๎๊อࠠไๆ๋ฬࠬઋ")
	,OBsrtQo2pPlgURCxJYbj9iXMD(u"ࠬࡩࡩ࡮ࡣࡦࡰࡺࡨࡷࡰࡴ࡮ࠫઌ")			:OzU6t0qcH7MQabeBYK8vgoG(u"࠭ๅ้ไ฼ࠤุ๐ๅศࠢๆ่ํฮฺࠠ็็ࠫઍ")
	,A0aqj9uclgOtByJ6F4bz(u"ࠧࡤ࡫ࡰࡥࡨࡲࡵࡱࠩ઎")				:CDwSWB4v39N7(u"ࠨ็๋ๆ฾ࠦำ๋็สࠤ่๊่ษࠩએ")
	,dBi72erQEtKDOwjNFaoAgSP(u"ࠩࡦ࡭ࡲࡧࡦࡢࡰࡶࠫઐ")				:C3ZK1pu4rfmj8TsWUtBaM(u"้ࠪํู่ࠡีํ้ฬࠦแศ่ีࠫઑ")
	,X2crmy67eZpkGTRd(u"ࠫࡨ࡯࡭ࡢࡨࡵࡩࡪ࠭઒")				:maUl7SPesynF1j(u"๋่ࠬใ฻ࠣื๏๋วࠡใิ๎ࠬઓ")
	,ELfMeDTIFhJt685K(u"࠭ࡣࡪ࡯ࡤࡰ࡮࡭ࡨࡵࠩઔ")			:OBsrtQo2pPlgURCxJYbj9iXMD(u"ࠧๆ๊ๅ฽ู๊ࠥๆษ่ࠣฬ๐สࠨક")
	,KhUG1NV9bln5zXjptqFW6dgo(u"ࠨࡥ࡬ࡱࡦࡴ࡯ࡸࠩખ")				:JJA7fypmZFVlazvNI(u"่ࠩ์็฿ࠠิ์่หࠥ์ว้ࠩગ")
	,mg3CbXMA2ouZzQDhRqB(u"ࠪࡧ࡮ࡳࡡࡸࡤࡤࡷࠬઘ")				:nz8x32hX0qcjUPFZk5RdJsiwED(u"๊ࠫ๎โฺࠢึ๎๊อ้ࠠสึࠫઙ")
	,k4IUieraScH9DV1N7pJgQosYAx5l(u"ࠬࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰࠪચ")			:EAVanJj1ers2GQud(u"࠭ๅ้ไ฼ࠤิอ๊ๅ์้ࠣํฺๆࠨછ")
	,U0VwOviFaYPz2QGs45mJhMXf7Zk(u"ࠧࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲ࠲ࡩࡨࡢࡰࡱࡩࡱࡹࠧજ")	:n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"ࠨ็๋ๆ฾ࠦฯศ์็๎๋่ࠥีุ่้ࠣะฮะ็ํ๊ࠬઝ")
	,ELfMeDTIFhJt685K(u"ࠩࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴ࠭ࡩࡣࡶ࡬ࡹࡧࡧࡴࠩઞ")	:YJxaX0MQOHb8oyCBFdnIAe(u"้ࠪํู่ࠡัส๎้๐ࠠๆ๊ื๊ࠥํวีฬส็ࠬટ")
	,A0aqj9uclgOtByJ6F4bz(u"ࠫࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯࠯࡯࡭ࡻ࡫ࡳࠨઠ")	:PPAUFrY8cduRT(u"๋่ࠬใ฻ࠣำฬ๐ไ๋่ࠢ์ู์ࠠๆสสุึ࠭ડ")
	,OBsrtQo2pPlgURCxJYbj9iXMD(u"࠭ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱ࠱ࡵࡲࡡࡺ࡮࡬ࡷࡹࡹࠧઢ"):X2crmy67eZpkGTRd(u"ࠧๆ๊ๅ฽ࠥีว๋ๆํࠤ๊๎ิ็ࠢๅ์ฬฬๅࠨણ")
	,cWbkR6iUZsnJQj14(u"ࠨࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠳ࡴࡰࡲ࡬ࡧࡸ࠭ત")	:ELfMeDTIFhJt685K(u"่ࠩ์็฿ࠠะษํ่๏ࠦๅ้ึ้ࠤ๊๎วื์฼ࠫથ")
	,maUl7SPesynF1j(u"ࠪࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮࠮ࡸ࡬ࡨࡪࡵࡳࠨદ")	:ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"๊ࠫ๎โฺࠢาห๏๊๊ࠡ็ุ๋๋ࠦแ๋ัํ์์อสࠨધ")
	,pCTzbw4GyVJHjkcIMQ(u"ࠬࡪࡩࡴࡣࡥࡰࡪࡪࠧન")				:OzU6t0qcH7MQabeBYK8vgoG(u"࠭ๅห๊ๅๅࠬ઩")
	,knTyjJ0sGIzuwbxRae(u"ࠧࡥࡴࡤࡱࡦࡩࡡࡧࡧࠪપ")			:mg3CbXMA2ouZzQDhRqB(u"ࠨ็๋ๆ฾ࠦฯาษ่ห้ࠥวโ์๊ࠫફ")
	,ELfMeDTIFhJt685K(u"ࠩࡧࡶࡦࡳࡡࡴ࠹ࠪબ")				:SODvU3Ibq5VzC(u"้ࠪํู่ࠡัิห๊อࠠึฯࠪભ")
	,mgLADoQ1pbtY(u"ࠫࡪ࡭ࡹࡣࡧࡶࡸࠬમ")				:SODvU3Ibq5VzC(u"๋่ࠬใ฻ࠣห๏า๊ࠡสํืฯ࠭ય")
	,SODvU3Ibq5VzC(u"࠭ࡥࡨࡻࡥࡩࡸࡺ࠱ࠨર")				:owbMhINBQsmx70guApW(u"ࠧๆ๊ๅ฽ࠥอ๊อ์ࠣฬ๏ูสࠡ࠳ࠪ઱")
	,KhUG1NV9bln5zXjptqFW6dgo(u"ࠨࡧࡪࡽࡧ࡫ࡳࡵ࠴ࠪલ")				:knTyjJ0sGIzuwbxRae(u"่ࠩ์็฿ࠠศ์ฯ๎ࠥฮ๊ิฬࠣ࠶ࠬળ")
	,ELfMeDTIFhJt685K(u"ࠪࡩ࡬ࡿࡢࡦࡵࡷ࠷ࠬ઴")				:CDwSWB4v39N7(u"๊ࠫ๎โฺࠢส๎ั๐ࠠษ์ึฮࠥ࠹ࠧવ")
	,knTyjJ0sGIzuwbxRae(u"ࠬ࡫ࡧࡺࡤࡨࡷࡹ࠺ࠧશ")				:ELfMeDTIFhJt685K(u"࠭ๅ้ไ฼ࠤฬ๐ฬ๋ࠢห๎ุะࠠ࠵ࠩષ")
	,LHX65I9nkx0PstgcVY24uSi(u"ࠧࡦࡩࡼࡦࡪࡹࡴࡷ࡫ࡳࠫસ")			:KKi79PFqsYB0dWSRgaJ3DyE(u"ࠨ็๋ๆ฾ࠦว๋ฮํࠤอ๐ำหࠢࡹ࡭ࡵ࠭હ")
	,owbMhINBQsmx70guApW(u"ࠩࡨ࡫ࡾࡪࡥࡢࡦࠪ઺")				:JJA7fypmZFVlazvNI(u"้ࠪํู่ࠡวํะ๏ࠦฯ๋ัࠪ઻")
	,mg3CbXMA2ouZzQDhRqB(u"ࠫࡪ࡭ࡹ࡯ࡱࡺ઼ࠫ")				:LHX65I9nkx0PstgcVY24uSi(u"๋่ࠬใ฻ࠣษ๏า๊่ࠡส์ࠬઽ")
	,C3ZK1pu4rfmj8TsWUtBaM(u"࠭ࡥ࡭ࡥ࡬ࡲࡪࡳࡡࠨા")				:mgLADoQ1pbtY(u"ࠧๆ๊ๅ฽๋่ࠥิ๊฼อࠥอไิ์้้ฬ࠭િ")
	,OBsrtQo2pPlgURCxJYbj9iXMD(u"ࠨࡧ࡯࡭࡫ࡼࡩࡥࡧࡲࠫી")			:U0VwOviFaYPz2QGs45mJhMXf7Zk(u"่ࠩ์็฿ࠠฤๆํๅࠥ็๊ะ์๋ࠫુ")
	,A0aqj9uclgOtByJ6F4bz(u"ࠪࡪࡦࡨࡲࡢ࡭ࡤࠫૂ")				:mgLADoQ1pbtY(u"๊ࠫ๎โฺࠢไฬึ้ษࠨૃ")
	,maUl7SPesynF1j(u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬૄ")				:ELfMeDTIFhJt685K(u"࠭แีๆࠪૅ")
	,owbMhINBQsmx70guApW(u"ࠧࡧࡣ࡭ࡩࡷࡹࡨࡰࡹࠪ૆")			:k4IUieraScH9DV1N7pJgQosYAx5l(u"ࠨ็๋ๆ฾ࠦแอำุࠣํ࠭ે")
	,nz8x32hX0qcjUPFZk5RdJsiwED(u"ࠩࡩࡥࡷ࡫ࡳ࡬ࡱࠪૈ")				:dBi72erQEtKDOwjNFaoAgSP(u"้ࠪํู่ࠡใสีุ้่ࠨૉ")
	,EF2tvxZHz5n4UruPhaViXKycI6SQR(u"ࠫ࡫ࡧࡳࡦ࡮࡫ࡨ࠶࠭૊")				:KKi79PFqsYB0dWSRgaJ3DyE(u"๋่ࠬใ฻ࠣๅฬ฻ไࠡษ็วํ๊ࠧો")
	,LHX65I9nkx0PstgcVY24uSi(u"࠭ࡦࡢࡵࡨࡰ࡭ࡪ࠲ࠨૌ")				:EF2tvxZHz5n4UruPhaViXKycI6SQR(u"ࠧๆ๊ๅ฽ࠥ็วึๆࠣห้ัว็์્ࠪ")
	,Tcf5Ppn9UajDbzyM(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ૎")				:n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"่ࠩะ้ีࠧ૏")
	,X2crmy67eZpkGTRd(u"ࠪࡪࡴࡹࡴࡢࠩૐ")				:jL1E5AKfwBDv6xmeQtUXcJ3d(u"๊ࠫ๎โฺࠢไ์ุะวࠨ૑")
	,HDpmv4UXzlf72SK9(u"ࠬ࡬ࡵ࡯ࡱࡱࡸࡻ࠭૒")				:n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"࠭ๅ้ไ฼ࠤๆ์่็ࠢอ๎ๆ๐ࠧ૓")
	,PPAUFrY8cduRT(u"ࠧࡧࡷࡶ࡬ࡦࡸࡴࡷࠩ૔")				:HDpmv4UXzlf72SK9(u"ࠨ็๋ๆ฾ࠦแ้ึสีࠥะ๊โ์ࠪ૕")
	,mg3CbXMA2ouZzQDhRqB(u"ࠩࡩࡹࡸ࡮ࡡࡳࡸ࡬ࡨࡪࡵࠧ૖")			:A0aqj9uclgOtByJ6F4bz(u"้ࠪํู่ࠡใุ๋ฬืࠠโ์า๎ํ࠭૗")
	,CDwSWB4v39N7(u"ࠫ࡬ࡵ࡯ࡥࠩ૘")					:ShnRVsifKtc60zqQ(u"ࠬา๊ะࠩ૙")
	,EAVanJj1ers2GQud(u"࠭ࡨࡢ࡮ࡤࡧ࡮ࡳࡡࠨ૚")				:ShnRVsifKtc60zqQ(u"ࠧๆ๊ๅ฽ࠥํไศࠢึ๎๊อࠧ૛")
	,A0aqj9uclgOtByJ6F4bz(u"ࠨࡪࡨࡰࡦࡲࠧ૜")				:mgLADoQ1pbtY(u"่ࠩ์็฿่ࠠๆส่ࠥ๐่ห์๋ฬࠬ૝")
	,OzU6t0qcH7MQabeBYK8vgoG(u"ࠪ࡭࡫࡯࡬࡮ࠩ૞")				:mgLADoQ1pbtY(u"๊ࠫ๎โฺࠢๅ๊ฬฯࠠร์ࠣๅ๏๊ๅࠨ૟")
	,C3ZK1pu4rfmj8TsWUtBaM(u"ࠬ࡯ࡦࡪ࡮ࡰ࠱ࡦࡸࡡࡣ࡫ࡦࠫૠ")			:HDpmv4UXzlf72SK9(u"࠭ๅ้ไ฼ࠤ็์วสࠢล๎ࠥ็๊ๅ็ࠣ฽ึฮ๊ࠨૡ")
	,owbMhINBQsmx70guApW(u"ࠧࡪࡨ࡬ࡰࡲ࠳ࡥ࡯ࡩ࡯࡭ࡸ࡮ࠧૢ")		:C3ZK1pu4rfmj8TsWUtBaM(u"ࠨ็๋ๆ฾ࠦโ็ษฬࠤว๐ࠠโ์็้ࠥอๆอๆํึ๏࠭ૣ")
	,JJA7fypmZFVlazvNI(u"ࠩ࡬ࡴࡹࡼࠧ૤")					:CDwSWB4v39N7(u"ࠪࡍࡕ࡚ࡖࠨ૥")
	,cWbkR6iUZsnJQj14(u"ࠫ࡮ࡶࡴࡷ࠯࡯࡭ࡻ࡫ࠧ૦")			:LHX65I9nkx0PstgcVY24uSi(u"ࠬࡏࡐࡕࡘࠣๆ๋๎วหࠩ૧")
	,EAVanJj1ers2GQud(u"࠭ࡩࡱࡶࡹ࠱ࡲࡵࡶࡪࡧࡶࠫ૨")			:A0aqj9uclgOtByJ6F4bz(u"ࠧࡊࡒࡗ࡚ࠥษแๅษ่ࠫ૩")
	,KKi79PFqsYB0dWSRgaJ3DyE(u"ࠨ࡫ࡳࡸࡻ࠳ࡳࡦࡴ࡬ࡩࡸ࠭૪")			:PPAUFrY8cduRT(u"ࠩࡌࡔ࡙࡜ࠠๆี็ื้อสࠨ૫")
	,YJxaX0MQOHb8oyCBFdnIAe(u"ࠪ࡯ࡦࡸࡢࡢ࡮ࡤࡸࡻ࠭૬")			:U0VwOviFaYPz2QGs45mJhMXf7Zk(u"๊ࠫ๎โฺࠢๅ๊ฬฯࠠไำห่ฬวࠧ૭")
	,ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"ࠬࡱࡡࡵ࡭ࡲࡸࡹࡼࠧ૮")				:ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"࠭ๅ้ไ฼ࠤ่ะใ้ฬࠣฮ๏็๊ࠨ૯")
	,ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"ࠧ࡬ࡣࡷ࡯ࡴࡻࡴࡦࠩ૰")				:mgLADoQ1pbtY(u"ࠨ็๋ๆ฾ࠦใหๅ๋ฮࠬ૱")
	,YJxaX0MQOHb8oyCBFdnIAe(u"ࠩ࡮࡭ࡷࡳࡡ࡭࡭ࠪ૲")				:LHX65I9nkx0PstgcVY24uSi(u"้ࠪํู่ࠡๅิ้ฬ๊ใࠨ૳")
	,owbMhINBQsmx70guApW(u"ࠫࡱࡧࡲࡰࡼࡤࠫ૴")				:JJA7fypmZFVlazvNI(u"๋่ࠬใ฻่ࠣฬื่ำษࠪ૵")
	,U0VwOviFaYPz2QGs45mJhMXf7Zk(u"࠭࡬ࡪࡤࡵࡥࡷࡿࠧ૶")				:U0VwOviFaYPz2QGs45mJhMXf7Zk(u"ࠧๆๆไࠫ૷")
	,dBi72erQEtKDOwjNFaoAgSP(u"ࠨ࡮࡬ࡺࡪ࠭૸")					:knTyjJ0sGIzuwbxRae(u"ࠩๅ๊ฬฯࠧૹ")
	,ELfMeDTIFhJt685K(u"ࠪࡰ࡮ࡼࡥࡵࡸࠪૺ")				:C3ZK1pu4rfmj8TsWUtBaM(u"๊๊ࠫแࠨૻ")
	,YJxaX0MQOHb8oyCBFdnIAe(u"ࠬࡲ࡯ࡥࡻࡱࡩࡹ࠭ૼ")				:k4IUieraScH9DV1N7pJgQosYAx5l(u"࠭ๅ้ไ฼ࠤ้๎ฯ๋้ࠢฮࠬ૽")
	,YJxaX0MQOHb8oyCBFdnIAe(u"ࠧ࡮࠵ࡸࠫ૾")					:SODvU3Ibq5VzC(u"ࠨࡏ࠶࡙ࠬ૿")
	,PPAUFrY8cduRT(u"ࠩࡰ࠷ࡺ࠳࡬ࡪࡸࡨࠫ଀")				:mgLADoQ1pbtY(u"ࠪࡑ࠸࡛ࠠใ่๋หฯ࠭ଁ")
	,CDwSWB4v39N7(u"ࠫࡲ࠹ࡵ࠮࡯ࡲࡺ࡮࡫ࡳࠨଂ")			:CDwSWB4v39N7(u"ࠬࡓ࠳ࡖࠢฦๅ้อๅࠨଃ")
	,ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"࠭࡭࠴ࡷ࠰ࡷࡪࡸࡩࡦࡵࠪ଄")			:ShnRVsifKtc60zqQ(u"ࠧࡎ࠵ࡘࠤู๊ไิๆสฮࠬଅ")
	,LHX65I9nkx0PstgcVY24uSi(u"ࠨ࡯ࡤࡷࡦࡼࡩࡥࡧࡲࠫଆ")			:EF2tvxZHz5n4UruPhaViXKycI6SQR(u"่ࠩ์็฿ࠠๆษึหࠥ็๊ะ์๋ࠫଇ")
	,ShnRVsifKtc60zqQ(u"ࠪࡱ࡮ࡹࡳࡪࡰࡪࠫଈ")				:mg3CbXMA2ouZzQDhRqB(u"๊ࠫ็โ้ัࠪଉ")
	,X2crmy67eZpkGTRd(u"ࠬࡳ࡯ࡷࡵ࠷ࡹࠬଊ")				:owbMhINBQsmx70guApW(u"࠭ๅ้ไ฼ࠤ๊๎แำࠢไ์ึ๐่ࠨଋ")
	,k4IUieraScH9DV1N7pJgQosYAx5l(u"ࠧ࡮ࡻࡦ࡭ࡲࡧࠧଌ")				:owbMhINBQsmx70guApW(u"ࠨ็๋ๆ฾ࠦๅศ์ࠣื๏๋วࠨ଍")
	,cWbkR6iUZsnJQj14(u"ࠩࡲࡰࡩ࠭଎")					:cWbkR6iUZsnJQj14(u"ࠪๆิ๐ๅࠨଏ")
	,n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"ࠫࡵࡧ࡮ࡦࡶࠪଐ")				:OBsrtQo2pPlgURCxJYbj9iXMD(u"๋่ࠬใ฻ࠣฬฬ์๊หࠩ଑")
	,C3ZK1pu4rfmj8TsWUtBaM(u"࠭ࡰࡢࡰࡨࡸ࠲ࡳ࡯ࡷ࡫ࡨࡷࠬ଒")			:A0aqj9uclgOtByJ6F4bz(u"ࠧๆ๊ๅ฽ࠥฮว็์อࠤฬ็ไศ็ࠪଓ")
	,LHX65I9nkx0PstgcVY24uSi(u"ࠨࡲࡤࡲࡪࡺ࠭ࡴࡧࡵ࡭ࡪࡹࠧଔ")			:Tcf5Ppn9UajDbzyM(u"่ࠩ์็฿ࠠษษ้๎ฯࠦๅิๆึ่ฬะࠧକ")
	,jL1E5AKfwBDv6xmeQtUXcJ3d(u"ࠪࡵ࡫࡯࡬࡮ࠩଖ")				:PPAUFrY8cduRT(u"๊ࠫ๎โฺࠢๆ๎ํࠦแ๋ๆ่ࠫଗ")
	,OzU6t0qcH7MQabeBYK8vgoG(u"ࠬࡹࡥࡳ࡫ࡨࡷࡹ࡯࡭ࡦࠩଘ")			:A0aqj9uclgOtByJ6F4bz(u"࠭ๅ้ไ฼ࠤุ๐ั๋ีࠣฮฬ๐ๅࠨଙ")
	,LHX65I9nkx0PstgcVY24uSi(u"ࠧࡴࡪࡤࡦࡦࡱࡡࡵࡻࠪଚ")			:ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"ࠨ็๋ๆ฾ࠦิษๅอ๎ࠬଛ")
	,CDwSWB4v39N7(u"ࠩࡶ࡬ࡦ࡮ࡩࡥ࠶ࡸࠫଜ")				:dBi72erQEtKDOwjNFaoAgSP(u"้ࠪํู่ࠡึส๋ิࠦแ้ำํ์ࠬଝ")
	,k4IUieraScH9DV1N7pJgQosYAx5l(u"ࠫࡸ࡮ࡡࡩ࡫ࡧ࠸ࡺ࠸ࠧଞ")			:mgLADoQ1pbtY(u"๋่ࠬใ฻ุࠣฬํฯࠡใ๋ี๏๎ࠠ࠳ࠩଟ")
	,KKi79PFqsYB0dWSRgaJ3DyE(u"࠭ࡳࡩࡣ࡫࡭ࡩࡴࡥࡸࡵࠪଠ")			:ELfMeDTIFhJt685K(u"ࠧๆ๊ๅ฽ฺࠥว่ั๊ࠣ๏๎าࠨଡ")
	,pCTzbw4GyVJHjkcIMQ(u"ࠨࡵ࡫࡭ࡦࡼ࡯ࡪࡥࡨࠫଢ")			:k4IUieraScH9DV1N7pJgQosYAx5l(u"่ࠩ์็฿ࠠึ๊อࠤฬ๊ิ๋฻ฬࠫଣ")
	,Tcf5Ppn9UajDbzyM(u"ࠪࡷ࡭࡯ࡡࡷࡱ࡬ࡧࡪ࠳ࡡ࡭ࡤࡸࡱࡸ࠭ତ")		:CDwSWB4v39N7(u"๊ࠫ๎โฺุࠢ์ฯࠦวๅึํ฽ฮࠦวๅส๋้ࠬଥ")
	,owbMhINBQsmx70guApW(u"ࠬࡹࡨࡪࡣࡹࡳ࡮ࡩࡥ࠮ࡣࡸࡨ࡮ࡵࡳࠨଦ")		:X2crmy67eZpkGTRd(u"࠭ๅ้ไ฼ࠤฺ๎สࠡษ็ุ๏฿ษࠡื๋ฮ๏อสࠨଧ")
	,KhUG1NV9bln5zXjptqFW6dgo(u"ࠧࡴࡪ࡬ࡥࡻࡵࡩࡤࡧ࠰ࡴࡪࡸࡳࡰࡰࡶࠫନ")	:OzU6t0qcH7MQabeBYK8vgoG(u"ࠨ็๋ๆ฾ࠦี้ฬࠣหฺฺ้๊หࠣๆฬืฦࠨ଩")
	,k4IUieraScH9DV1N7pJgQosYAx5l(u"ࠩࡶ࡬ࡴ࡬ࡨࡢࠩପ")				:CDwSWB4v39N7(u"้ࠪํู่ࠡึ๋ๅ์อࠠห์ไ๎ࠬଫ")
	,ELfMeDTIFhJt685K(u"ࠫࡸ࡮࡯ࡰࡨࡰࡥࡽ࠭ବ")				:EF2tvxZHz5n4UruPhaViXKycI6SQR(u"๋่ࠬใ฻ุࠣํ็ࠠๆษๆืࠬଭ")
	,k4IUieraScH9DV1N7pJgQosYAx5l(u"࠭ࡳࡩࡱࡲࡪࡳ࡫ࡴࠨମ")				:PPAUFrY8cduRT(u"ࠧๆ๊ๅ฽ฺ่ࠥโ้ࠢฮࠬଯ")
	,mgLADoQ1pbtY(u"ࠨࡵ࡫ࡳࡴ࡬ࡰࡳࡱࠪର")				:EF2tvxZHz5n4UruPhaViXKycI6SQR(u"่ࠩ์็฿ࠠี๊ไࠤอื่ࠨ଱")
	,X2crmy67eZpkGTRd(u"ࠪࡸ࡮ࡱࡡࡢࡶࠪଲ")				:owbMhINBQsmx70guApW(u"๊ࠫ๎โฺࠢอ็ฬะࠧଳ")
	,cWbkR6iUZsnJQj14(u"ࠬࡺࡶࡧࡷࡱࠫ଴")				:Tcf5Ppn9UajDbzyM(u"࠭ๅ้ไ฼ࠤฯ๐แ๋ࠢไห๋࠭ଵ")
	,JJA7fypmZFVlazvNI(u"ࠧࡷࡣࡵࡦࡴࡴࠧଶ")				:dBi72erQEtKDOwjNFaoAgSP(u"ࠨ็๋ๆ฾ࠦแศำห์๋࠭ଷ")
	,mg3CbXMA2ouZzQDhRqB(u"ࠩࡹ࡭ࡩ࡫࡯ࠨସ")				:mg3CbXMA2ouZzQDhRqB(u"ࠪๅ๏ี๊้ࠩହ")
	,mgLADoQ1pbtY(u"ࠫࡻ࡯ࡤࡦࡱࡱࡷࡦ࡫࡭ࠨ଺")			:mgLADoQ1pbtY(u"๋่ࠬใ฻ࠣๅ๏ี๊้้ࠢืฬฬๅࠨ଻")
	,SODvU3Ibq5VzC(u"࠭ࡷࡦࡥ࡬ࡱࡦ࠷଼ࠧ")				:JJA7fypmZFVlazvNI(u"ࠧๆ๊ๅ฽ࠥ๎๊ࠡีํ้ฬࠦ࠱ࠨଽ")
	,ShnRVsifKtc60zqQ(u"ࠨࡹࡨࡧ࡮ࡳࡡ࠳ࠩା")				:ELfMeDTIFhJt685K(u"่ࠩ์็฿้ࠠ์ࠣื๏๋วࠡ࠴ࠪି")
	,jL1E5AKfwBDv6xmeQtUXcJ3d(u"ࠪࡽࡦࡷ࡯ࡵࠩୀ")				:A0aqj9uclgOtByJ6F4bz(u"๊ࠫ๎โฺࠢํห็๎สࠨୁ")
	,SODvU3Ibq5VzC(u"ࠬࡿ࡯ࡶࡶࡸࡦࡪ࠭ୂ")				:ShnRVsifKtc60zqQ(u"࠭ๅ้ไ฼ࠤ๏๎ส๋๊หࠫୃ")
	,A0aqj9uclgOtByJ6F4bz(u"ࠧࡺࡱࡸࡸࡺࡨࡥ࠮ࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠪୄ")		:ELfMeDTIFhJt685K(u"ࠨ็๋ๆ฾๊้ࠦฬํ์อࠦโ็๊สฮࠬ୅")
	,LHX65I9nkx0PstgcVY24uSi(u"ࠩࡼࡳࡺࡺࡵࡣࡧ࠰ࡴࡱࡧࡹ࡭࡫ࡶࡸࡸ࠭୆")	:EAVanJj1ers2GQud(u"้ࠪํู่ࠡ์๋ฮ๏๎ศࠡไ๋หห๋ࠧେ")
	,knTyjJ0sGIzuwbxRae(u"ࠫࡾࡵࡵࡵࡷࡥࡩ࠲ࡼࡩࡥࡧࡲࡷࠬୈ")		:KKi79PFqsYB0dWSRgaJ3DyE(u"๋่ࠬใ฻ࠣ๎ํะ๊้สࠣๅ๏ี๊้้สฮࠬ୉")
	,dBi72erQEtKDOwjNFaoAgSP(u"࠭ࡹࡵࡤࡢࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬ୊")			:JJA7fypmZFVlazvNI(u"ࠧๆ๊สๆ฾ࠦๅ็ࠢํ์ฯ๐่ษࠩୋ")
}
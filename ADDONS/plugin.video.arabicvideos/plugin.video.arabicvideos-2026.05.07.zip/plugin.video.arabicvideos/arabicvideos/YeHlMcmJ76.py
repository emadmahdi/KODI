# -*- coding: utf-8 -*-
from FF68kA5BUy import *
HDLtdMAy7wPkl8aKC3O2 = 'FAJERSHOW'
EEJvXQzSZNt = '_FJS_'
e2VR8nohduY = Jzthpc2nj5.SITESURLS[HDLtdMAy7wPkl8aKC3O2][0]
FwhZ0nXtpoHTMarf = ['التصنيفات','انشاء حساب','طلبات الزوّار']
def kk6X5LxpsND(mode,url,text):
	if   mode==390: zLZUkrP7ac5 = afkxo7FyZWB4O6K1eXrs5I()
	elif mode==391: zLZUkrP7ac5 = c8wfGju4CWZm(url,text)
	elif mode==392: zLZUkrP7ac5 = f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url)
	elif mode==393: zLZUkrP7ac5 = XONC9osGSP4fW5HVrhM(url)
	elif mode==399: zLZUkrP7ac5 = hm4kawIPKp3oMrC75dJZA9HS2(text)
	else: zLZUkrP7ac5 = False
	return zLZUkrP7ac5
def afkxo7FyZWB4O6K1eXrs5I():
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'بحث في الموقع',HQmDERMFjx,399,HQmDERMFjx,HQmDERMFjx,'_REMEMBERRESULTS_')
	CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(H5x4Z2qPwR8vXM,'GET',e2VR8nohduY,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'FAJERSHOW-MENU-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	items = DyVGS3dX0ZxR.findall('<header>.*?<h2>(.*?)<',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	for AeXOdC4y3QVZgjMDn8 in range(len(items)):
		title = items[AeXOdC4y3QVZgjMDn8]
		CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+title,e2VR8nohduY,391,HQmDERMFjx,HQmDERMFjx,'latest'+str(AeXOdC4y3QVZgjMDn8))
	MJ2gSPyTl9hzoi1 = HQmDERMFjx
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('class="menu"(.*?)id="contenedor"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1: MJ2gSPyTl9hzoi1 += Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"header-container"(.*?)</div>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1: MJ2gSPyTl9hzoi1 += Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	items = DyVGS3dX0ZxR.findall('href="([^"]*)">(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	B1eTDbEXUfs8lqtywGoFC3jRc29 = True
	for vn1grP3y4It9GmVuBbLJfz2A,title in items:
		title = SVsiEWeRf6oIynqQx8pCrM4Tk(title)
		if title not in FwhZ0nXtpoHTMarf:
			CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,391)
	return CzNPJydxQLfw27tv4ZF8KORAbX5
def c8wfGju4CWZm(url,S46ZVrhN1gWY0Iiaj):
	MJ2gSPyTl9hzoi1,items = [],[]
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'FAJERSHOW-TITLES-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	if S46ZVrhN1gWY0Iiaj=='search':
		MJ2gSPyTl9hzoi1 = CzNPJydxQLfw27tv4ZF8KORAbX5
		items = DyVGS3dX0ZxR.findall('href="(.*?)".*?src="(.*?)".*?<h4>(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	elif S46ZVrhN1gWY0Iiaj in ['featured_movies','featured_tvshows']:
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('class="content"(.*?)id="archive-content"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1: MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	elif S46ZVrhN1gWY0Iiaj=='top_imdb_movies':
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall("class='top-imdb-list tleft(.*?)class='top-imdb-list tright",CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
			MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
			items = DyVGS3dX0ZxR.findall("src='(.*?)'.*?href='(.*?)'>(.*?)<",MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	elif S46ZVrhN1gWY0Iiaj=='top_imdb_series':
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall("class='top-imdb-list tright(.*?)footer",CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
			MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
			items = DyVGS3dX0ZxR.findall("src='(.*?)'.*?href='(.*?)'>(.*?)<",MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	elif S46ZVrhN1gWY0Iiaj=='sider':
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('class="widget(.*?)class="widget',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		WW81LekVcBdaPuURvJItHsSglFoM = DyVGS3dX0ZxR.findall('href="(.*?)".*?src="(.*?)".*?<h3>(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		Na8vklCpUGYIzP0bjutWOT,eXfxRim3IPS4h60sVTqKWOU1FaurAo,gBzGTxKMSVWFLPvfAI0UZ98D5 = zip(*WW81LekVcBdaPuURvJItHsSglFoM)
		items = zip(eXfxRim3IPS4h60sVTqKWOU1FaurAo,Na8vklCpUGYIzP0bjutWOT,gBzGTxKMSVWFLPvfAI0UZ98D5)
	elif S46ZVrhN1gWY0Iiaj=='randoms':
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('id="slider-movies-tvshows"(.*?)<header>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	elif 'latest' in S46ZVrhN1gWY0Iiaj:
		AeXOdC4y3QVZgjMDn8 = int(S46ZVrhN1gWY0Iiaj[-1:])
		CzNPJydxQLfw27tv4ZF8KORAbX5 = CzNPJydxQLfw27tv4ZF8KORAbX5.replace('<header>','<end><start>')
		CzNPJydxQLfw27tv4ZF8KORAbX5 = CzNPJydxQLfw27tv4ZF8KORAbX5.replace('</div></div></div>','</div></div></div><end>')
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('<start>(.*?)<end>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[AeXOdC4y3QVZgjMDn8]
		if AeXOdC4y3QVZgjMDn8==6:
			WW81LekVcBdaPuURvJItHsSglFoM = DyVGS3dX0ZxR.findall('src="(.*?)" alt="(.*?)".*?href="(.*?)"',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
			eXfxRim3IPS4h60sVTqKWOU1FaurAo,gBzGTxKMSVWFLPvfAI0UZ98D5,Na8vklCpUGYIzP0bjutWOT = zip(*WW81LekVcBdaPuURvJItHsSglFoM)
			items = zip(eXfxRim3IPS4h60sVTqKWOU1FaurAo,Na8vklCpUGYIzP0bjutWOT,gBzGTxKMSVWFLPvfAI0UZ98D5)
	else:
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"archive-grid"(.*?)</main>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
			MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	if not items: items = DyVGS3dX0ZxR.findall('href="(.*?)".*?src="(.*?)".*?<h3>(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	ORMkTYjJ1p7 = []
	for vn1grP3y4It9GmVuBbLJfz2A,uIGD4vZcP61QNmw78LXqoEpH,title in items:
		if 'src=' in title: continue
		if 'serie' in title:
			title = DyVGS3dX0ZxR.findall('^(.*?)<.*?serie">(.*?)<',title,DyVGS3dX0ZxR.DOTALL)
			title = title[0][1]
			if title in ORMkTYjJ1p7: continue
			ORMkTYjJ1p7.append(title)
			title = '_MOD_'+title
		eyLMq9Enup0jiJT42RDWafg = DyVGS3dX0ZxR.findall('^(.*?)<',title,DyVGS3dX0ZxR.DOTALL)
		if eyLMq9Enup0jiJT42RDWafg: title = eyLMq9Enup0jiJT42RDWafg[0]
		title = SVsiEWeRf6oIynqQx8pCrM4Tk(title)
		if '/tvshows/' in vn1grP3y4It9GmVuBbLJfz2A: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,393,uIGD4vZcP61QNmw78LXqoEpH)
		elif '/episodes/' in vn1grP3y4It9GmVuBbLJfz2A: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,393,uIGD4vZcP61QNmw78LXqoEpH)
		elif '/seasons/' in vn1grP3y4It9GmVuBbLJfz2A: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,393,uIGD4vZcP61QNmw78LXqoEpH)
		elif '/collection/' in vn1grP3y4It9GmVuBbLJfz2A: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,391,uIGD4vZcP61QNmw78LXqoEpH)
		else: CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,392,uIGD4vZcP61QNmw78LXqoEpH)
	if S46ZVrhN1gWY0Iiaj not in ['featured_movies','featured_tvshows']:
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"archive-pagination"(.*?)</div>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
			MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
			items = DyVGS3dX0ZxR.findall('href="([^"]*)">(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
			for vn1grP3y4It9GmVuBbLJfz2A,title in items:
				CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'صفحة '+title,vn1grP3y4It9GmVuBbLJfz2A,391,HQmDERMFjx,HQmDERMFjx,S46ZVrhN1gWY0Iiaj)
	return
def XONC9osGSP4fW5HVrhM(url):
	pYVvlGR1ES0gdtzayiDqb9w = DpClq35GVjh(url,'url')
	url = url.replace(pYVvlGR1ES0gdtzayiDqb9w,e2VR8nohduY)
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'FAJERSHOW-EPISODES-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	WWbJG6CrUL4tIRsjpNV = DyVGS3dX0ZxR.findall('class="C rated".*?>(.*?)<',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if WWbJG6CrUL4tIRsjpNV and UzSYuZp3Pnhf1W4wyx7Fc0JX6jNb(HDLtdMAy7wPkl8aKC3O2,url,WWbJG6CrUL4tIRsjpNV): return
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"season-episodes"(.*?)</section>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('href="([^"]*)".*?src="([^"]*)".*?<h4>(.*?)</h4>''',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,uIGD4vZcP61QNmw78LXqoEpH,title in items:
			CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,392,uIGD4vZcP61QNmw78LXqoEpH)
	return
def f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url):
	url = url.replace('//show.alfajertv.com/','//fajer.show/')
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'FAJERSHOW-PLAY-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	if HH6mxXjgcrEN1aenMFWQkS:
		try: CzNPJydxQLfw27tv4ZF8KORAbX5 = CzNPJydxQLfw27tv4ZF8KORAbX5.decode(Zex6D4tJE52r,'ignore')
		except: pass
	WWbJG6CrUL4tIRsjpNV = DyVGS3dX0ZxR.findall('class="C rated".*?>(.*?)<',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if WWbJG6CrUL4tIRsjpNV and UzSYuZp3Pnhf1W4wyx7Fc0JX6jNb(HDLtdMAy7wPkl8aKC3O2,url,WWbJG6CrUL4tIRsjpNV): return
	Na8vklCpUGYIzP0bjutWOT = []
	mmQfkxEvd9GnXU0ZCNOriYyJql1aF = DyVGS3dX0ZxR.findall("postId = (\d+);var postType = '(\a+)';",CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if mmQfkxEvd9GnXU0ZCNOriYyJql1aF: EcqoRFnue9Cw1aX5WNtVO2QMJh,zrUchADfptGno9ea7vx2Z0PCEX5uW = mmQfkxEvd9GnXU0ZCNOriYyJql1aF[0]
	else: EcqoRFnue9Cw1aX5WNtVO2QMJh,zrUchADfptGno9ea7vx2Z0PCEX5uW = HQmDERMFjx,HQmDERMFjx
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"servers-list"(.*?)</div>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('data-server="(.*?)".*?"server-name">(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for IIVYu2pF76Si1rvPHGfx,title in items:
			vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+'/wp-admin/admin-ajax.php?action=doo_player_ajax&post='+EcqoRFnue9Cw1aX5WNtVO2QMJh+'&nume='+IIVYu2pF76Si1rvPHGfx+'&type='+zrUchADfptGno9ea7vx2Z0PCEX5uW
			vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A+'?named='+title+'__watch'
			Na8vklCpUGYIzP0bjutWOT.append(vn1grP3y4It9GmVuBbLJfz2A)
	if 0 and Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('''img src=["'](.*?)["'].*?href=["'](.*?)["'].*?["']quality["']>(.*?)<.*?<td>(.*?)<''',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for uIGD4vZcP61QNmw78LXqoEpH,vn1grP3y4It9GmVuBbLJfz2A,RRpfksr1PbZagwCIOJXYNHTo,ooJVyEN7CjtcOgGSeaRA in items:
			if '=' in uIGD4vZcP61QNmw78LXqoEpH:
				sshx8PBFN57JSEj6 = uIGD4vZcP61QNmw78LXqoEpH.split('=')[1]
				title = DpClq35GVjh(sshx8PBFN57JSEj6,'host')
			else: title = HQmDERMFjx
			title = ooJVyEN7CjtcOgGSeaRA+oQpxmKiRPlHeGsLXNrJF78O+title
			vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A+'?named='+title+'__download____'+RRpfksr1PbZagwCIOJXYNHTo
			Na8vklCpUGYIzP0bjutWOT.append(vn1grP3y4It9GmVuBbLJfz2A)
	import NsD5AomUqH
	NsD5AomUqH.NZcWGBmgFEen5hvJjUSIzOCVk7(Na8vklCpUGYIzP0bjutWOT,HDLtdMAy7wPkl8aKC3O2,'video',url)
	return
def hm4kawIPKp3oMrC75dJZA9HS2(search):
	search,GXVabd4sc2u3zp0JI,showDialogs = x0pzMENwy84tBcZvXr(search)
	if search==HQmDERMFjx: search = q156m84QoYrn()
	if search==HQmDERMFjx: return
	search = search.replace(oQpxmKiRPlHeGsLXNrJF78O,'+')
	url = e2VR8nohduY+'/wp-admin/admin-ajax.php?action=fshow_live_search&s='+search
	c8wfGju4CWZm(url,'search')
	return
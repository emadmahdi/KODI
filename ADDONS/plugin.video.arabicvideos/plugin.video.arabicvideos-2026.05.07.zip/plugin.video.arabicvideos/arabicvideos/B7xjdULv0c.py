# -*- coding: utf-8 -*-
from FF68kA5BUy import *
headers = { 'User-Agent' : HQmDERMFjx }
HDLtdMAy7wPkl8aKC3O2 = 'AKOAM'
EEJvXQzSZNt = '_AKO_'
e2VR8nohduY = Jzthpc2nj5.SITESURLS[HDLtdMAy7wPkl8aKC3O2][0]
llpDRN0MA3 = ['فيلم','كليب','العرض الاسبوعي','مسرحية','مسرحيه','اغنية','اعلان','لقاء']
def kk6X5LxpsND(mode,url,text):
	if   mode==70: zLZUkrP7ac5 = afkxo7FyZWB4O6K1eXrs5I()
	elif mode==71: zLZUkrP7ac5 = ZFEjC6KpI78XPWd9TueM(url)
	elif mode==72: zLZUkrP7ac5 = c8wfGju4CWZm(url,text)
	elif mode==73: zLZUkrP7ac5 = t7zaRoqBHrsW69dOPN24EDngl(url)
	elif mode==74: zLZUkrP7ac5 = f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url)
	elif mode==79: zLZUkrP7ac5 = hm4kawIPKp3oMrC75dJZA9HS2(text)
	else: zLZUkrP7ac5 = False
	return zLZUkrP7ac5
def afkxo7FyZWB4O6K1eXrs5I():
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'بحث في الموقع',HQmDERMFjx,79,HQmDERMFjx,HQmDERMFjx,'_REMEMBERRESULTS_')
	CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+'سلسلة افلام',HQmDERMFjx,79,HQmDERMFjx,HQmDERMFjx,'سلسلة افلام')
	CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+'سلاسل منوعة',HQmDERMFjx,79,HQmDERMFjx,HQmDERMFjx,'سلسلة')
	CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	FwhZ0nXtpoHTMarf = ['الكتب و الابحاث','الكورسات التعليمية','الألعاب','البرامج','الاجهزة اللوحية','الصور و الخلفيات','المصارعة الحرة']
	CzNPJydxQLfw27tv4ZF8KORAbX5 = D0GFPwY8ecAVI(H5x4Z2qPwR8vXM,e2VR8nohduY,HQmDERMFjx,headers,HQmDERMFjx,'AKOAM-MENU-1st')
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('class="partions"(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('href="(.*?)">(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,title in items:
			if title not in FwhZ0nXtpoHTMarf:
				CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,71)
	return CzNPJydxQLfw27tv4ZF8KORAbX5
def ZFEjC6KpI78XPWd9TueM(url):
	CzNPJydxQLfw27tv4ZF8KORAbX5 = D0GFPwY8ecAVI(H5x4Z2qPwR8vXM,url,HQmDERMFjx,headers,HQmDERMFjx,'AKOAM-CATEGORIES-1st')
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('sect_parts(.*?)</div>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('href="(.*?)".*?>(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,title in items:
			title = title.strip(oQpxmKiRPlHeGsLXNrJF78O)
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,72)
		CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'جميع الفروع',url,72)
	else: c8wfGju4CWZm(url,HQmDERMFjx)
	return
def c8wfGju4CWZm(url,type):
	CzNPJydxQLfw27tv4ZF8KORAbX5 = D0GFPwY8ecAVI(j9uzmBeEyK8,url,HQmDERMFjx,headers,True,'AKOAM-TITLES-1st')
	items = []
	if type=='featured':
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('section_title featured_title(.*?)subjects-crousel',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('href="(.*?)"><div class="subject_box.*?src="(.*?)".*?<h3.*?>(.*?)</h3>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	elif type=='search':
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('akoam_result(.*?)<script',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('href="(.*?)".*?background-image: url\((.*?)\).*?<h1>(.*?)</h1>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	elif type=='more':
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('section_title more_title(.*?)footer_bottom_services',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	else:
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('navigation(.*?)<script',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if not items and Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('div class="subject_box.*?href="(.*?)".*?src="(.*?)".*?<h3.*?>(.*?)</h3>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	for vn1grP3y4It9GmVuBbLJfz2A,uIGD4vZcP61QNmw78LXqoEpH,title in items:
		if 'توضيح هام' in title: continue
		title = title.replace(ti3SbXNV0aJ7n5Grc4OQY8Ll1s9,HQmDERMFjx).strip(oQpxmKiRPlHeGsLXNrJF78O)
		title = SVsiEWeRf6oIynqQx8pCrM4Tk(title)
		if any(value in title for value in llpDRN0MA3): CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,73,uIGD4vZcP61QNmw78LXqoEpH)
		else: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,73,uIGD4vZcP61QNmw78LXqoEpH)
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('class="pagination"(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall("</li><li >.*?href='(.*?)'>(.*?)<",MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,title in items:
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'صفحة '+title,vn1grP3y4It9GmVuBbLJfz2A,72,HQmDERMFjx,HQmDERMFjx,type)
	return
def s40tVpaT27b9wfFgIOLodWx5XK(url):
	CzNPJydxQLfw27tv4ZF8KORAbX5 = D0GFPwY8ecAVI(H5x4Z2qPwR8vXM,url,HQmDERMFjx,headers,True,'AKOAM-SECTIONS-2nd')
	SSHjMN4uegZfb2 = DyVGS3dX0ZxR.findall('"href","(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	SSHjMN4uegZfb2 = SSHjMN4uegZfb2[1]
	return SSHjMN4uegZfb2
def t7zaRoqBHrsW69dOPN24EDngl(url):
	CzNPJydxQLfw27tv4ZF8KORAbX5 = D0GFPwY8ecAVI(j9uzmBeEyK8,url,HQmDERMFjx,headers,True,'AKOAM-SECTIONS-1st')
	tdHxImub3FGoAWa0OP76J = DyVGS3dX0ZxR.findall('"(https*://akwam.net/\w+.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	n0nITc7BziX = DyVGS3dX0ZxR.findall('"(https*://underurl.com/\w+.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if tdHxImub3FGoAWa0OP76J or n0nITc7BziX:
		if tdHxImub3FGoAWa0OP76J: jDcWv7MAkEV = tdHxImub3FGoAWa0OP76J[0]
		elif n0nITc7BziX: jDcWv7MAkEV = s40tVpaT27b9wfFgIOLodWx5XK(n0nITc7BziX[0])
		jDcWv7MAkEV = xx9LK4VzpF6IHXSEyhmrQwbg25P0(jDcWv7MAkEV)
		import JHnEqYP1Bs
		if '/series/' in jDcWv7MAkEV or '/shows/' in jDcWv7MAkEV: JHnEqYP1Bs.XONC9osGSP4fW5HVrhM(jDcWv7MAkEV)
		else: JHnEqYP1Bs.f0vdEa8oPRTYSesnmNuklQx7I2zXbq(jDcWv7MAkEV)
		return
	WWbJG6CrUL4tIRsjpNV = DyVGS3dX0ZxR.findall('محتوى الفيلم.*?>.*?(\w*?)\W*?<',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if WWbJG6CrUL4tIRsjpNV and UzSYuZp3Pnhf1W4wyx7Fc0JX6jNb(HDLtdMAy7wPkl8aKC3O2,url,WWbJG6CrUL4tIRsjpNV): return
	items = DyVGS3dX0ZxR.findall('<br />\n<a href="(.*?)".*?<span style="color:.*?">(.*?)</span>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	for vn1grP3y4It9GmVuBbLJfz2A,title in items:
		title = SVsiEWeRf6oIynqQx8pCrM4Tk(title)
		CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,73)
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('class="sub_title".*?<h1.*?>(.*?)</h1>.*?class="main_img".*?src="(.*?)".*?ad-300-250(.*?)ako-feedback',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if not Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		x8a2FGB1jAef94byI('خطأ خارجي','لا يوجد ملف فيديو')
		return
	name,uIGD4vZcP61QNmw78LXqoEpH,MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	name = name.strip(oQpxmKiRPlHeGsLXNrJF78O)
	if 'sub_epsiode_title' in MJ2gSPyTl9hzoi1:
		items = DyVGS3dX0ZxR.findall('sub_epsiode_title">(.*?)</h2>.*?sub_file_title.*?>(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	else:
		dkcOfMal6huwU7jPN = DyVGS3dX0ZxR.findall('sub_file_title\'>(.*?) - <i>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		items = []
		for filename in dkcOfMal6huwU7jPN:
			items.append( ('رابط التشغيل',filename) )
	if not items: items = [ ('رابط التشغيل',HQmDERMFjx) ]
	count = 0
	gBzGTxKMSVWFLPvfAI0UZ98D5,mq3konvsTRM = [],[]
	size = len(items)
	for title,filename in items:
		mwbkTcCzlA2fNFB = HQmDERMFjx
		if ' - ' in filename: filename = filename.split(' - ')[0]
		else: filename = 'dummy.zip'
		if '.' in filename: mwbkTcCzlA2fNFB = filename.split('.')[-1]
		title = title.replace(ti3SbXNV0aJ7n5Grc4OQY8Ll1s9,HQmDERMFjx).strip(oQpxmKiRPlHeGsLXNrJF78O)
		gBzGTxKMSVWFLPvfAI0UZ98D5.append(title)
		mq3konvsTRM.append(count)
		count += 1
	if size>0:
		if any(value in name for value in llpDRN0MA3):
			if size==1:
				lwT9cdaH5AxMU8IpZif20jPX = 0
			else:
				lwT9cdaH5AxMU8IpZif20jPX = GGiSlWbqKDr5Ovkh2L7sHNTxz('اختر الفيديو المناسب:', gBzGTxKMSVWFLPvfAI0UZ98D5)
				if lwT9cdaH5AxMU8IpZif20jPX == -1: return
			f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url+'?section='+str(1+mq3konvsTRM[size-lwT9cdaH5AxMU8IpZif20jPX-1]))
		else:
			for yuYts1RONXgp in reversed(range(size)):
				title = name + ' - ' + gBzGTxKMSVWFLPvfAI0UZ98D5[yuYts1RONXgp]
				title = title.replace(ti3SbXNV0aJ7n5Grc4OQY8Ll1s9,HQmDERMFjx).strip(oQpxmKiRPlHeGsLXNrJF78O)
				vn1grP3y4It9GmVuBbLJfz2A = url + '?section='+str(size-yuYts1RONXgp)
				CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,74,uIGD4vZcP61QNmw78LXqoEpH)
	else:
		CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+'الرابط ليس فيديو',HQmDERMFjx,9999,uIGD4vZcP61QNmw78LXqoEpH)
	return
def f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url):
	SSHjMN4uegZfb2,yTz8SOkAhu24j6apo9BmZHvwWsX = url.split('?section=')
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',SSHjMN4uegZfb2,HQmDERMFjx,headers,True,HQmDERMFjx,'AKOAM-PLAY_AKOAM-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('ad-300-250.*?ad-300-250(.*?)ako-feedback',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	yPVGFNSOr8anHBXeY1oJRk6MCdKDm = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0].replace("'direct_link_box",'"direct_link_box epsoide_box')
	yPVGFNSOr8anHBXeY1oJRk6MCdKDm = yPVGFNSOr8anHBXeY1oJRk6MCdKDm + 'direct_link_box'
	bUzHWnGg5t1 = DyVGS3dX0ZxR.findall('epsoide_box(.*?)direct_link_box',yPVGFNSOr8anHBXeY1oJRk6MCdKDm,DyVGS3dX0ZxR.DOTALL)
	yTz8SOkAhu24j6apo9BmZHvwWsX = len(bUzHWnGg5t1)-int(yTz8SOkAhu24j6apo9BmZHvwWsX)
	MJ2gSPyTl9hzoi1 = bUzHWnGg5t1[yTz8SOkAhu24j6apo9BmZHvwWsX]
	KWnAuJIFyESQHjP3X5xzMqUbR6L = []
	vWHsUkb0BhiJdZ2F3Y = {'1423075862':'dailymotion','1477487601':'estream','1505328404':'streamango',
		'1423080015':'flashx','1458117295':'openload','1423079306':'vimple','1430052371':'ok.ru',
		'1477488213':'thevid','1558278006':'uqload','1477487990':'vidtodo'}
	items = DyVGS3dX0ZxR.findall("class='download_btn.*?href='(.*?)'",MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	for vn1grP3y4It9GmVuBbLJfz2A in items:
		KWnAuJIFyESQHjP3X5xzMqUbR6L.append(vn1grP3y4It9GmVuBbLJfz2A+'?named=________akoam')
	items = DyVGS3dX0ZxR.findall('background-image: url\((.*?)\).*?href=\'(.*?)\'',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	for C4V7rtvjEQSh2l6uPDz1i8Y,vn1grP3y4It9GmVuBbLJfz2A in items:
		C4V7rtvjEQSh2l6uPDz1i8Y = C4V7rtvjEQSh2l6uPDz1i8Y.split(xufJqQcGnhboiVy2wd)[-1]
		C4V7rtvjEQSh2l6uPDz1i8Y = C4V7rtvjEQSh2l6uPDz1i8Y.split('.')[0]
		if C4V7rtvjEQSh2l6uPDz1i8Y in vWHsUkb0BhiJdZ2F3Y:
			KWnAuJIFyESQHjP3X5xzMqUbR6L.append(vn1grP3y4It9GmVuBbLJfz2A+'?named='+vWHsUkb0BhiJdZ2F3Y[C4V7rtvjEQSh2l6uPDz1i8Y]+'________akoam')
		else: KWnAuJIFyESQHjP3X5xzMqUbR6L.append(vn1grP3y4It9GmVuBbLJfz2A+'?named='+C4V7rtvjEQSh2l6uPDz1i8Y+'________akoam')
	if not KWnAuJIFyESQHjP3X5xzMqUbR6L:
		message = DyVGS3dX0ZxR.findall('sub-no-file.*?\n(.*?)\n',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		if message: u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,'رسالة من الموقع الاصلي',message[0])
	else:
		import NsD5AomUqH
		NsD5AomUqH.NZcWGBmgFEen5hvJjUSIzOCVk7(KWnAuJIFyESQHjP3X5xzMqUbR6L,HDLtdMAy7wPkl8aKC3O2,'video',url)
	return
def hm4kawIPKp3oMrC75dJZA9HS2(search):
	search,GXVabd4sc2u3zp0JI,showDialogs = x0pzMENwy84tBcZvXr(search)
	if search==HQmDERMFjx: search = q156m84QoYrn()
	if search==HQmDERMFjx: return
	q5qfEX4yA6lDop1 = search.replace(oQpxmKiRPlHeGsLXNrJF78O,'%20')
	url = e2VR8nohduY + '/search/'+q5qfEX4yA6lDop1
	zLZUkrP7ac5 = c8wfGju4CWZm(url,'search')
	return
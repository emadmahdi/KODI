# -*- coding: utf-8 -*-
from FF68kA5BUy import *
HDLtdMAy7wPkl8aKC3O2 = 'BRSTEJ'
EEJvXQzSZNt = '_BRS_'
e2VR8nohduY = Jzthpc2nj5.SITESURLS[HDLtdMAy7wPkl8aKC3O2][0]
FwhZ0nXtpoHTMarf = ['Sign in','الاقسام','عرض المزيد','download']
def kk6X5LxpsND(mode,url,text):
	if   mode==650: zLZUkrP7ac5 = afkxo7FyZWB4O6K1eXrs5I()
	elif mode==651: zLZUkrP7ac5 = c8wfGju4CWZm(url,text)
	elif mode==652: zLZUkrP7ac5 = f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url)
	elif mode==653: zLZUkrP7ac5 = QQp8orwMlAa1(url,text)
	elif mode==654: zLZUkrP7ac5 = REWBU20fyqaLprY(url)
	elif mode==659: zLZUkrP7ac5 = hm4kawIPKp3oMrC75dJZA9HS2(text)
	else: zLZUkrP7ac5 = False
	return zLZUkrP7ac5
def afkxo7FyZWB4O6K1eXrs5I():
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',e2VR8nohduY,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'BRSTEJ-MENU-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'بحث في الموقع',HQmDERMFjx,659,HQmDERMFjx,HQmDERMFjx,'_REMEMBERRESULTS_')
	CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	items = DyVGS3dX0ZxR.findall('<h2>(.*?)</h2>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	for DvGaoUZE5S4wxfHc910sz,title in enumerate(items):
		CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+title,e2VR8nohduY,651,HQmDERMFjx,HQmDERMFjx,str(DvGaoUZE5S4wxfHc910sz))
	CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"menu-section-list"(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	items = DyVGS3dX0ZxR.findall('href="(.*?)">(.*?)</',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	for vn1grP3y4It9GmVuBbLJfz2A,title in items:
		if title in FwhZ0nXtpoHTMarf: continue
		if 'لاحقا' in title or 'مثال' in title: continue
		title = title.replace('<b>',HQmDERMFjx).strip(oQpxmKiRPlHeGsLXNrJF78O)
		CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,651)
	return
def REWBU20fyqaLprY(url):
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'BRSTEJ-SUBMENU-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	cOUkMZagDQftHLBoCivP = DyVGS3dX0ZxR.findall('"caret"(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if cOUkMZagDQftHLBoCivP:
		MJ2gSPyTl9hzoi1 = cOUkMZagDQftHLBoCivP[0]
		MJ2gSPyTl9hzoi1 = MJ2gSPyTl9hzoi1.replace('"presentation"','</ul>')
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		if not Ut7reR0XioMjOdYWZKsLIuc3TQJmC1: Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = [(HQmDERMFjx,MJ2gSPyTl9hzoi1)]
		CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' فرز أو فلتر أو ترتيب '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
		for XwidGQz8WkV1CorLYJ4Z9aqO0g,MJ2gSPyTl9hzoi1 in Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
			items = DyVGS3dX0ZxR.findall('href="(.*?)".*?>(.*?)</a>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
			if XwidGQz8WkV1CorLYJ4Z9aqO0g: XwidGQz8WkV1CorLYJ4Z9aqO0g = XwidGQz8WkV1CorLYJ4Z9aqO0g+': '
			for vn1grP3y4It9GmVuBbLJfz2A,title in items:
				title = XwidGQz8WkV1CorLYJ4Z9aqO0g+title
				CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,651)
	vuylTosVej845YfDNK = DyVGS3dX0ZxR.findall('"pm-category-subcats"(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if vuylTosVej845YfDNK:
		MJ2gSPyTl9hzoi1 = vuylTosVej845YfDNK[0]
		items = DyVGS3dX0ZxR.findall('href="(.*?)">(.*?)</a>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		if len(items)<30:
			CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
			for vn1grP3y4It9GmVuBbLJfz2A,title in items:
				CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,651)
	if not cOUkMZagDQftHLBoCivP and not vuylTosVej845YfDNK: c8wfGju4CWZm(url)
	return
def c8wfGju4CWZm(url,S46ZVrhN1gWY0Iiaj=HQmDERMFjx):
	if S46ZVrhN1gWY0Iiaj=='ajax-search':
		url,search = url.split('?',1)
		data = 'queryString='+search
		headers = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'POST',url,data,headers,HQmDERMFjx,HQmDERMFjx,'BRSTEJ-TITLES-1st')
	else:
		vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'BRSTEJ-TITLES-2nd')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	MJ2gSPyTl9hzoi1,items = HQmDERMFjx,[]
	EFDgdaV4WT6U2yotAPX1B = DpClq35GVjh(url,'url')
	if S46ZVrhN1gWY0Iiaj=='ajax-search':
		MJ2gSPyTl9hzoi1 = CzNPJydxQLfw27tv4ZF8KORAbX5
		bbiKcPz2RQOUwS = DyVGS3dX0ZxR.findall('href="(.*?)">(.*?)</a>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,title in bbiKcPz2RQOUwS: items.append((HQmDERMFjx,vn1grP3y4It9GmVuBbLJfz2A,title))
	elif S46ZVrhN1gWY0Iiaj=='featured':
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"pm-video-watch-featured"(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1: MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	elif S46ZVrhN1gWY0Iiaj=='new_episodes':
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"row pm-ul-browse-videos(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1: MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	elif S46ZVrhN1gWY0Iiaj=='new_movies':
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"row pm-ul-browse-videos(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if len(Ut7reR0XioMjOdYWZKsLIuc3TQJmC1)>1: MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[1]
	elif S46ZVrhN1gWY0Iiaj=='featured_series':
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"ba mgb table full"(.*?)"clearfix"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1: MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		bbiKcPz2RQOUwS = DyVGS3dX0ZxR.findall('href="([^"]*)" title="([^"]*)"',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,title in bbiKcPz2RQOUwS: items.append((HQmDERMFjx,vn1grP3y4It9GmVuBbLJfz2A,title))
	elif S46ZVrhN1gWY0Iiaj.isdigit():
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('<h2>(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[int(S46ZVrhN1gWY0Iiaj)]
	else:
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"home-container"(.*?)"footer"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1: MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	if MJ2gSPyTl9hzoi1 and not items: items = DyVGS3dX0ZxR.findall('class="thumb".*?href="(.*?)".*?alt="(.*?)".*?data-src="(.*?)"',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	if not items: return
	ORMkTYjJ1p7 = []
	smLQwgO0BynVCcl3fYJ = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for vn1grP3y4It9GmVuBbLJfz2A,title,uIGD4vZcP61QNmw78LXqoEpH in items:
		title = title.strip(oQpxmKiRPlHeGsLXNrJF78O)
		yTz8SOkAhu24j6apo9BmZHvwWsX = DyVGS3dX0ZxR.findall('(.*?) (الحلقة|حلقة).\d+',title,DyVGS3dX0ZxR.DOTALL)
		if any(value in title for value in smLQwgO0BynVCcl3fYJ):
			CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,652,uIGD4vZcP61QNmw78LXqoEpH)
		elif S46ZVrhN1gWY0Iiaj=='new_episodes':
			CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,652,uIGD4vZcP61QNmw78LXqoEpH)
		elif yTz8SOkAhu24j6apo9BmZHvwWsX:
			title = '_MOD_' + yTz8SOkAhu24j6apo9BmZHvwWsX[0][0]
			if title not in ORMkTYjJ1p7:
				CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,653,uIGD4vZcP61QNmw78LXqoEpH)
				ORMkTYjJ1p7.append(title)
		else: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,653,uIGD4vZcP61QNmw78LXqoEpH)
	if 1:
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall("class='pages'(.*?)</div>",CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
			MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
			items = DyVGS3dX0ZxR.findall('href="(.*?)".*?>(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
			for vn1grP3y4It9GmVuBbLJfz2A,title in items:
				vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A.strip(xufJqQcGnhboiVy2wd)
				title = SVsiEWeRf6oIynqQx8pCrM4Tk(title)
				CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'صفحة '+title,vn1grP3y4It9GmVuBbLJfz2A,651)
	return
def QQp8orwMlAa1(url,Y2OHMQ7a5tFfS1n):
	EFDgdaV4WT6U2yotAPX1B = DpClq35GVjh(url,'url')
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'BRSTEJ-EPISODES-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	kALyrFT6KPNGI7Oiup82Qb4JCq0td = DyVGS3dX0ZxR.findall('og:image" content="(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	uIGD4vZcP61QNmw78LXqoEpH = kALyrFT6KPNGI7Oiup82Qb4JCq0td[0] if kALyrFT6KPNGI7Oiup82Qb4JCq0td else HQmDERMFjx
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"EpisodesList"(.*?)</div>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	P6w71TBXELt4e,QKzekJCOfdjLGr9ApnSwZW4iPmBo = HQmDERMFjx,HQmDERMFjx
	if len(Ut7reR0XioMjOdYWZKsLIuc3TQJmC1)==2: P6w71TBXELt4e,QKzekJCOfdjLGr9ApnSwZW4iPmBo = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1
	elif len(Ut7reR0XioMjOdYWZKsLIuc3TQJmC1)==1: QKzekJCOfdjLGr9ApnSwZW4iPmBo = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[o4bNzIQGYj8En]
	items = []
	VyueNkv1smz4MSdtWAiHapBTI8g = False
	if P6w71TBXELt4e and not Y2OHMQ7a5tFfS1n:
		items = DyVGS3dX0ZxR.findall('href="(.*?)".*?>(.*?)<',P6w71TBXELt4e,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,title in items:
			if len(items)>1: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,653,uIGD4vZcP61QNmw78LXqoEpH,HQmDERMFjx,Y2OHMQ7a5tFfS1n)
			else: VyueNkv1smz4MSdtWAiHapBTI8g = True
	else: VyueNkv1smz4MSdtWAiHapBTI8g = True
	if QKzekJCOfdjLGr9ApnSwZW4iPmBo:
		items = DyVGS3dX0ZxR.findall('href="(.*?)".*?>(.*?)<',QKzekJCOfdjLGr9ApnSwZW4iPmBo,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,title in items:
			title = title.strip()
			vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A.strip(xufJqQcGnhboiVy2wd)
			CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,652,uIGD4vZcP61QNmw78LXqoEpH)
	return
def f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url):
	KWnAuJIFyESQHjP3X5xzMqUbR6L = []
	SSHjMN4uegZfb2 = url+'/play'
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',SSHjMN4uegZfb2,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'BRSTEJ-PLAY-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('<iframe id="main-iframe"(.*?)</iframe>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		vn1grP3y4It9GmVuBbLJfz2A = DyVGS3dX0ZxR.findall('src="(.*?)"',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		if vn1grP3y4It9GmVuBbLJfz2A:
			vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A[0]
			KWnAuJIFyESQHjP3X5xzMqUbR6L.append(vn1grP3y4It9GmVuBbLJfz2A+'?named=__embed')
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('class="vp-sources(.*?)</div>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		jzTLleJs8x9Hb1 = DyVGS3dX0ZxR.findall('data-url="(.*?)">(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,title in jzTLleJs8x9Hb1:
			if vn1grP3y4It9GmVuBbLJfz2A not in KWnAuJIFyESQHjP3X5xzMqUbR6L: KWnAuJIFyESQHjP3X5xzMqUbR6L.append(vn1grP3y4It9GmVuBbLJfz2A+'?named='+title.strip()+'__watch')
	otP07csEQAmMKal = DyVGS3dX0ZxR.findall('class="Download".*?href="(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if otP07csEQAmMKal:
		SSHjMN4uegZfb2 = otP07csEQAmMKal[0]
		vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',SSHjMN4uegZfb2,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'BRSTEJ-PLAY-2nd')
		CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('class="download-grid"(.*?)</div>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
			MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
			jzTLleJs8x9Hb1 = DyVGS3dX0ZxR.findall('href="(.*?)">(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
			for vn1grP3y4It9GmVuBbLJfz2A,title in jzTLleJs8x9Hb1:
				if vn1grP3y4It9GmVuBbLJfz2A not in KWnAuJIFyESQHjP3X5xzMqUbR6L: KWnAuJIFyESQHjP3X5xzMqUbR6L.append(vn1grP3y4It9GmVuBbLJfz2A+'?named='+title.strip()+'__download')
	import NsD5AomUqH
	NsD5AomUqH.NZcWGBmgFEen5hvJjUSIzOCVk7(KWnAuJIFyESQHjP3X5xzMqUbR6L,HDLtdMAy7wPkl8aKC3O2,'video',url)
	return
def hm4kawIPKp3oMrC75dJZA9HS2(search):
	search,GXVabd4sc2u3zp0JI,showDialogs = x0pzMENwy84tBcZvXr(search)
	if search==HQmDERMFjx: search = q156m84QoYrn()
	if search==HQmDERMFjx: return
	search = search.replace(oQpxmKiRPlHeGsLXNrJF78O,'+')
	url = e2VR8nohduY+'/?s='+search
	c8wfGju4CWZm(url,'search')
	return
# -*- coding: utf-8 -*-
from FF68kA5BUy import *
HDLtdMAy7wPkl8aKC3O2 = 'SHOOFMAX'
EEJvXQzSZNt = '_SHM_'
e2VR8nohduY = Jzthpc2nj5.SITESURLS[HDLtdMAy7wPkl8aKC3O2][0]
waE5LXVN0BOiQjCUur3oTt6eYSIHJK = Jzthpc2nj5.SITESURLS[HDLtdMAy7wPkl8aKC3O2][1]
IsK7MxWgSEa9JkHQntoh = Jzthpc2nj5.SITESURLS[HDLtdMAy7wPkl8aKC3O2][2]
def kk6X5LxpsND(mode,url,text):
	if   mode==50: zLZUkrP7ac5 = afkxo7FyZWB4O6K1eXrs5I()
	elif mode==51: zLZUkrP7ac5 = c8wfGju4CWZm(url)
	elif mode==52: zLZUkrP7ac5 = XONC9osGSP4fW5HVrhM(url)
	elif mode==53: zLZUkrP7ac5 = f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url)
	elif mode==55: zLZUkrP7ac5 = AghHXzM3xnlGT4kSp()
	elif mode==56: zLZUkrP7ac5 = ddieFtxcQGbmPzCJuNjMoLB52UgTY()
	elif mode==57: zLZUkrP7ac5 = gjwBnYN0zlFWVtGKfOocDA(url,1)
	elif mode==58: zLZUkrP7ac5 = gjwBnYN0zlFWVtGKfOocDA(url,2)
	elif mode==59: zLZUkrP7ac5 = hm4kawIPKp3oMrC75dJZA9HS2(text)
	else: zLZUkrP7ac5 = False
	return zLZUkrP7ac5
def afkxo7FyZWB4O6K1eXrs5I():
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'بحث في الموقع',HQmDERMFjx,59,HQmDERMFjx,HQmDERMFjx,'_REMEMBERRESULTS_')
	CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+'المسلسلات',HQmDERMFjx,56)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+'الافلام',HQmDERMFjx,55)
	return HQmDERMFjx
def AghHXzM3xnlGT4kSp():
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'أفلام مرتبة بسنة الإنتاج',e2VR8nohduY+'/movie/1/yop',57)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'أفلام مرتبة بالأفضل تقييم',e2VR8nohduY+'/movie/1/review',57)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'أفلام مرتبة بالأكثر مشاهدة',e2VR8nohduY+'/movie/1/views',57)
	return
def ddieFtxcQGbmPzCJuNjMoLB52UgTY():
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'مسلسلات مرتبة بسنة الإنتاج',e2VR8nohduY+'/series/1/yop',57)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'مسلسلات مرتبة بالأفضل تقييم',e2VR8nohduY+'/series/1/review',57)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'مسلسلات مرتبة بالأكثر مشاهدة',e2VR8nohduY+'/series/1/views',57)
	return
def c8wfGju4CWZm(url):
	if '?' in url:
		DDAoB3rdfJTXuE2RQwK8 = url.split('?')
		url = DDAoB3rdfJTXuE2RQwK8[0]
		filter = '?' + VVkOtyQLzxBr(DDAoB3rdfJTXuE2RQwK8[1],'=&:/%')
	else: filter = HQmDERMFjx
	type,zmL397efNlks5uTEV,sort = url.split(xufJqQcGnhboiVy2wd)[-3:]
	if sort in ['yop','review','views']:
		if type=='movie': Wzvw6c4Yu2='فيلم'
		elif type=='series': Wzvw6c4Yu2='مسلسل'
		url = e2VR8nohduY + '/genre/filter/' + VVkOtyQLzxBr(Wzvw6c4Yu2) + xufJqQcGnhboiVy2wd + zmL397efNlks5uTEV + xufJqQcGnhboiVy2wd + sort + filter
		CzNPJydxQLfw27tv4ZF8KORAbX5 = D0GFPwY8ecAVI(j9uzmBeEyK8,url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'SHOOFMAX-TITLES-1st')
		items = DyVGS3dX0ZxR.findall('"pid":(.*?),.*?"ptitle":"(.*?)".+?"pepisodes":(.*?),"presbase":"(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		qRF8YQeUsyC=0
		for id,title,VgzivmYSo0UZjyXx4FDI53TOPL,uIGD4vZcP61QNmw78LXqoEpH in items:
			qRF8YQeUsyC += 1
			uIGD4vZcP61QNmw78LXqoEpH = IsK7MxWgSEa9JkHQntoh + '/v2/img/program/main/' + uIGD4vZcP61QNmw78LXqoEpH + '-2.jpg'
			vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY + '/program/' + id
			if type=='movie': CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,53,uIGD4vZcP61QNmw78LXqoEpH)
			if type=='series': CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'مسلسل '+title,vn1grP3y4It9GmVuBbLJfz2A+'?ep='+VgzivmYSo0UZjyXx4FDI53TOPL+'='+title+'='+uIGD4vZcP61QNmw78LXqoEpH,52,uIGD4vZcP61QNmw78LXqoEpH)
	else:
		if type=='movie': Wzvw6c4Yu2='movies'
		elif type=='series': Wzvw6c4Yu2='series'
		url = waE5LXVN0BOiQjCUur3oTt6eYSIHJK + '/json/selected/' + sort + '-' + Wzvw6c4Yu2 + '-WW.json'
		CzNPJydxQLfw27tv4ZF8KORAbX5 = D0GFPwY8ecAVI(j9uzmBeEyK8,url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'SHOOFMAX-TITLES-2nd')
		items = DyVGS3dX0ZxR.findall('"ref":(.*?),"ep":(.*?),"base":"(.*?)","title":"(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		qRF8YQeUsyC=0
		for id,VgzivmYSo0UZjyXx4FDI53TOPL,uIGD4vZcP61QNmw78LXqoEpH,title in items:
			qRF8YQeUsyC += 1
			uIGD4vZcP61QNmw78LXqoEpH = waE5LXVN0BOiQjCUur3oTt6eYSIHJK + '/img/program/' + uIGD4vZcP61QNmw78LXqoEpH + '-2.jpg'
			vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY + '/program/' + id
			if type=='movie': CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,53,uIGD4vZcP61QNmw78LXqoEpH)
			elif type=='series': CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'مسلسل '+title,vn1grP3y4It9GmVuBbLJfz2A+'?ep='+VgzivmYSo0UZjyXx4FDI53TOPL+'='+title+'='+uIGD4vZcP61QNmw78LXqoEpH,52,uIGD4vZcP61QNmw78LXqoEpH)
	title='صفحة '
	if qRF8YQeUsyC==16:
		for TTDKxdHL6XzbY2agoPNQBqeyZc in range(1,13) :
			if not zmL397efNlks5uTEV==str(TTDKxdHL6XzbY2agoPNQBqeyZc):
				url = e2VR8nohduY+'/genre/filter/'+type+xufJqQcGnhboiVy2wd+str(TTDKxdHL6XzbY2agoPNQBqeyZc)+xufJqQcGnhboiVy2wd+sort+filter
				CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title+str(TTDKxdHL6XzbY2agoPNQBqeyZc),url,51)
	return
def XONC9osGSP4fW5HVrhM(url):
	DDAoB3rdfJTXuE2RQwK8 = url.split('=')
	VgzivmYSo0UZjyXx4FDI53TOPL = int(DDAoB3rdfJTXuE2RQwK8[1])
	name = xx9LK4VzpF6IHXSEyhmrQwbg25P0(DDAoB3rdfJTXuE2RQwK8[2])
	name = name.replace('_MOD_مسلسل ',HQmDERMFjx)
	uIGD4vZcP61QNmw78LXqoEpH = DDAoB3rdfJTXuE2RQwK8[3]
	url = url.split('?')[0]
	if VgzivmYSo0UZjyXx4FDI53TOPL==0:
		CzNPJydxQLfw27tv4ZF8KORAbX5 = D0GFPwY8ecAVI(j9uzmBeEyK8,url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'SHOOFMAX-EPISODES-1st')
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('<select(.*?)</select>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('option value="(.*?)"',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		VgzivmYSo0UZjyXx4FDI53TOPL = int(items[-1])
	for yTz8SOkAhu24j6apo9BmZHvwWsX in range(VgzivmYSo0UZjyXx4FDI53TOPL,0,-1):
		vn1grP3y4It9GmVuBbLJfz2A = url + '?ep=' + str(yTz8SOkAhu24j6apo9BmZHvwWsX)
		title = '_MOD_مسلسل '+name+' - الحلقة '+str(yTz8SOkAhu24j6apo9BmZHvwWsX)
		CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,53,uIGD4vZcP61QNmw78LXqoEpH)
	return
def f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url):
	CzNPJydxQLfw27tv4ZF8KORAbX5 = D0GFPwY8ecAVI(H5x4Z2qPwR8vXM,url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'SHOOFMAX-PLAY-1st')
	z1k0LgQdtPZEOhprHGR7X = DyVGS3dX0ZxR.findall('متوفر على شوف ماكس بعد.*?moment\("(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if z1k0LgQdtPZEOhprHGR7X:
		jHWkt18govGwY7iUbduAfxCyRc = z1k0LgQdtPZEOhprHGR7X[1].replace('T',pVzyOequnZtI)
		u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,'رسالة من الموقع الأصلي','هذا الفيديو سيكون متوفر على شوف ماكس بعد هذا الوقت'+ti3SbXNV0aJ7n5Grc4OQY8Ll1s9+jHWkt18govGwY7iUbduAfxCyRc)
		return
	WLtrSNwfMckB,GZy7JNMpTA8i6gfQlso1uK2WR = [],[]
	bx2kSj1cP80uatJTRfHK7s = DyVGS3dX0ZxR.findall('var origin_link = "(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)[0]
	hKNt1QGVqsxgp76JXDoZkjEa = DyVGS3dX0ZxR.findall('var backup_origin_link = "(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)[0]
	jzTLleJs8x9Hb1 = DyVGS3dX0ZxR.findall('hls: (.*?)_link\+"(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	for pYVvlGR1ES0gdtzayiDqb9w,vn1grP3y4It9GmVuBbLJfz2A in jzTLleJs8x9Hb1:
		if 'backup' in pYVvlGR1ES0gdtzayiDqb9w:
			pYVvlGR1ES0gdtzayiDqb9w = 'backup server'
			url = hKNt1QGVqsxgp76JXDoZkjEa + vn1grP3y4It9GmVuBbLJfz2A
		else:
			pYVvlGR1ES0gdtzayiDqb9w = 'main server'
			url = bx2kSj1cP80uatJTRfHK7s + vn1grP3y4It9GmVuBbLJfz2A
		if '.m3u8' in url:
			WLtrSNwfMckB.append(url)
			GZy7JNMpTA8i6gfQlso1uK2WR.append('m3u8  '+pYVvlGR1ES0gdtzayiDqb9w)
	jzTLleJs8x9Hb1 = DyVGS3dX0ZxR.findall('mp4:.*?_link.*?\t(.*?)_link\+"(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	jzTLleJs8x9Hb1 += DyVGS3dX0ZxR.findall('mp4:.*?\t(.*?)_link\+"(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	for pYVvlGR1ES0gdtzayiDqb9w,vn1grP3y4It9GmVuBbLJfz2A in jzTLleJs8x9Hb1:
		filename = vn1grP3y4It9GmVuBbLJfz2A.split(xufJqQcGnhboiVy2wd)[-1]
		filename = filename.replace('fallback',HQmDERMFjx)
		filename = filename.replace('.mp4',HQmDERMFjx)
		filename = filename.replace('-',HQmDERMFjx)
		if 'backup' in pYVvlGR1ES0gdtzayiDqb9w:
			pYVvlGR1ES0gdtzayiDqb9w = 'backup server'
			url = hKNt1QGVqsxgp76JXDoZkjEa + vn1grP3y4It9GmVuBbLJfz2A
		else:
			pYVvlGR1ES0gdtzayiDqb9w = 'main server'
			url = bx2kSj1cP80uatJTRfHK7s + vn1grP3y4It9GmVuBbLJfz2A
		WLtrSNwfMckB.append(url)
		GZy7JNMpTA8i6gfQlso1uK2WR.append('mp4  '+pYVvlGR1ES0gdtzayiDqb9w+MSnXBQNUg1jF3W2fRlE9OLaCT8ds4+filename)
	lwT9cdaH5AxMU8IpZif20jPX = GGiSlWbqKDr5Ovkh2L7sHNTxz('Select Video Quality:', GZy7JNMpTA8i6gfQlso1uK2WR)
	if lwT9cdaH5AxMU8IpZif20jPX == -1 : return
	url = WLtrSNwfMckB[lwT9cdaH5AxMU8IpZif20jPX]
	uZVS3DcJbEULoxpve9IOTgmW6(url,HDLtdMAy7wPkl8aKC3O2,'video')
	return
def gjwBnYN0zlFWVtGKfOocDA(url,type):
	if 'series' in url: SSHjMN4uegZfb2 = e2VR8nohduY + '/genre/مسلسل'
	else: SSHjMN4uegZfb2 = e2VR8nohduY + '/genre/فيلم'
	SSHjMN4uegZfb2 = VVkOtyQLzxBr(SSHjMN4uegZfb2)
	CzNPJydxQLfw27tv4ZF8KORAbX5 = D0GFPwY8ecAVI(H5x4Z2qPwR8vXM,SSHjMN4uegZfb2,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'SHOOFMAX-FILTERS-1st')
	if type==1: Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('subgenre(.*?)div',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	elif type==2: Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('country(.*?)div',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	items = DyVGS3dX0ZxR.findall('option value="(.*?)">(.*?)</option',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	if type==1:
		for LLMAbQWvhiDuGIOqwXcPY,title in items:
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,url+'?subgenre='+LLMAbQWvhiDuGIOqwXcPY,58)
	elif type==2:
		url,LLMAbQWvhiDuGIOqwXcPY = url.split('?')
		for lmsiLduHeBFVJcSjvzXp6,title in items:
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,url+'?country='+lmsiLduHeBFVJcSjvzXp6+'&'+LLMAbQWvhiDuGIOqwXcPY,51)
	return
def hm4kawIPKp3oMrC75dJZA9HS2(search):
	search,GXVabd4sc2u3zp0JI,showDialogs = x0pzMENwy84tBcZvXr(search)
	if not search: search = q156m84QoYrn()
	if not search: return
	q5qfEX4yA6lDop1 = search.replace(oQpxmKiRPlHeGsLXNrJF78O,'%20')
	url = e2VR8nohduY+'/search?q='+q5qfEX4yA6lDop1
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,HQmDERMFjx,True,HQmDERMFjx,'SHOOFMAX-SEARCH-2nd')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('general-body(.*?)search-bottom-padding',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	items = DyVGS3dX0ZxR.findall('href="(.*?)".*?background-image: url\((.*?)\).*?<span>(.*?)</span>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	if items:
		for vn1grP3y4It9GmVuBbLJfz2A,uIGD4vZcP61QNmw78LXqoEpH,title in items:
			url = e2VR8nohduY + vn1grP3y4It9GmVuBbLJfz2A
			if '/program/' in url:
				if '?ep=' in url:
					title = '_MOD_مسلسل '+title
					url = url.replace('?ep=1','?ep=0')
					url = url+'='+VVkOtyQLzxBr(title)+'='+uIGD4vZcP61QNmw78LXqoEpH
					CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,url,52,uIGD4vZcP61QNmw78LXqoEpH)
				else:
					title = '_MOD_فيلم '+title
					CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,url,53,uIGD4vZcP61QNmw78LXqoEpH)
	return
# -*- coding: utf-8 -*-
from FF68kA5BUy import *
HDLtdMAy7wPkl8aKC3O2 = 'CIMAABDO'
EEJvXQzSZNt = '_ABD_'
e2VR8nohduY = Jzthpc2nj5.SITESURLS[HDLtdMAy7wPkl8aKC3O2][0]
FwhZ0nXtpoHTMarf = ['الرئيسية','افلام للكبار فقط +18']
def kk6X5LxpsND(mode,url,text):
	if   mode==550: zLZUkrP7ac5 = afkxo7FyZWB4O6K1eXrs5I()
	elif mode==551: zLZUkrP7ac5 = c8wfGju4CWZm(url,text)
	elif mode==552: zLZUkrP7ac5 = f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url)
	elif mode==553: zLZUkrP7ac5 = XONC9osGSP4fW5HVrhM(url)
	elif mode==559: zLZUkrP7ac5 = hm4kawIPKp3oMrC75dJZA9HS2(text)
	else: zLZUkrP7ac5 = False
	return zLZUkrP7ac5
def afkxo7FyZWB4O6K1eXrs5I():
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',e2VR8nohduY+'/home',HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'CIMAABDO-MENU-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	EFDgdaV4WT6U2yotAPX1B = DpClq35GVjh(e2VR8nohduY,'url')
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'بحث في الموقع',HQmDERMFjx,559,HQmDERMFjx,HQmDERMFjx,'_REMEMBERRESULTS_')
	CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'اخترنا لك',EFDgdaV4WT6U2yotAPX1B+'/home',551,HQmDERMFjx,HQmDERMFjx,'featured')
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('main-content(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	items = DyVGS3dX0ZxR.findall('data-name="(.*?)".*?</i>(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	for KPloNJnsZ2kpHhum1,title in items:
		vn1grP3y4It9GmVuBbLJfz2A = EFDgdaV4WT6U2yotAPX1B+'/ajax/getItem?item='+KPloNJnsZ2kpHhum1+'&Ajax=1'
		CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,551)
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"nav-main"(.*?)</nav>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	items = DyVGS3dX0ZxR.findall('href="(.*?)">(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	for vn1grP3y4It9GmVuBbLJfz2A,title in items:
		if vn1grP3y4It9GmVuBbLJfz2A=='#': continue
		if title in FwhZ0nXtpoHTMarf: continue
		if 'مسلسل ' in title: continue
		if 'أحدث' in title: CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,551)
	CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	for vn1grP3y4It9GmVuBbLJfz2A,title in items:
		if vn1grP3y4It9GmVuBbLJfz2A=='#': continue
		if title in FwhZ0nXtpoHTMarf: continue
		if 'مسلسل ' in title: continue
		if 'أحدث' not in title: CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,551)
	return
def c8wfGju4CWZm(url,KPloNJnsZ2kpHhum1=HQmDERMFjx):
	items = []
	if '/ajax/getItem' in url or '/ajax/loadMore' in url:
		SSHjMN4uegZfb2,Vi9fwvbSBCI0K6hgXA8EpFrT = Oy2YNHPzuJl(url)
		nJayb3s5zlOgQh9BwiCdEDq = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'POST',SSHjMN4uegZfb2,Vi9fwvbSBCI0K6hgXA8EpFrT,nJayb3s5zlOgQh9BwiCdEDq,HQmDERMFjx,HQmDERMFjx,'CIMAABDO-TITLES-1st')
		CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = [CzNPJydxQLfw27tv4ZF8KORAbX5]
	else:
		vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'CIMAABDO-TITLES-2nd')
		CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
		if KPloNJnsZ2kpHhum1=='featured':
			Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"container"(.*?)"container"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
			MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
			items = DyVGS3dX0ZxR.findall('href="([^"]*)" title="([^"]*)".*?src="(.*?)"',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		elif '"section-post mb-10"' in CzNPJydxQLfw27tv4ZF8KORAbX5:
			Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"section-post mb-10"(.*?)"container"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		else:
			Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('<article(.*?)"pagination"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if not Ut7reR0XioMjOdYWZKsLIuc3TQJmC1: return
	MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	if not items:
		items = DyVGS3dX0ZxR.findall('href="([^"]*)" title="([^"]*)".*?data-original="(.*?)"',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		if not items: items = DyVGS3dX0ZxR.findall('href="([^"]*)" title="([^"]*)".*?src="(.*?)"',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	ORMkTYjJ1p7 = []
	smLQwgO0BynVCcl3fYJ = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for vn1grP3y4It9GmVuBbLJfz2A,title,uIGD4vZcP61QNmw78LXqoEpH in items:
		vn1grP3y4It9GmVuBbLJfz2A = xx9LK4VzpF6IHXSEyhmrQwbg25P0(vn1grP3y4It9GmVuBbLJfz2A).strip(xufJqQcGnhboiVy2wd)
		yTz8SOkAhu24j6apo9BmZHvwWsX = DyVGS3dX0ZxR.findall('(.*?) الحلقة \d+',title,DyVGS3dX0ZxR.DOTALL)
		if 'سلاسل' not in url and any(value in title for value in smLQwgO0BynVCcl3fYJ):
			CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,552,uIGD4vZcP61QNmw78LXqoEpH)
		elif yTz8SOkAhu24j6apo9BmZHvwWsX and 'الحلقة' in title:
			title = '_MOD_' + yTz8SOkAhu24j6apo9BmZHvwWsX[0]
			if title not in ORMkTYjJ1p7:
				CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,553,uIGD4vZcP61QNmw78LXqoEpH)
				ORMkTYjJ1p7.append(title)
		elif '/movies/' in vn1grP3y4It9GmVuBbLJfz2A:
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,551,uIGD4vZcP61QNmw78LXqoEpH)
		else: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,553,uIGD4vZcP61QNmw78LXqoEpH)
	if KPloNJnsZ2kpHhum1==HQmDERMFjx:
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"pagination"(.*?)<footer',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
			MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
			items = DyVGS3dX0ZxR.findall('href="(.*?)".*?>(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
			for vn1grP3y4It9GmVuBbLJfz2A,title in items:
				if vn1grP3y4It9GmVuBbLJfz2A=="": continue
				if title!=HQmDERMFjx: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'صفحة '+title,vn1grP3y4It9GmVuBbLJfz2A,551)
	if '/ajax/getItem' in url or '/ajax/loadMore' in url:
		if '/ajax/getItem' in url:
			url = url.replace('/ajax/getItem','/ajax/loadMore')+'&offset=20'
		elif '/ajax/loadMore' in url:
			url,offset = url.split('&offset=')
			offset = int(offset)+20
			url = url+'&offset='+str(offset)
		CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'هناك المزيد',url,551)
	return
def XONC9osGSP4fW5HVrhM(url):
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'CIMAABDO-EPISODES-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	cOUkMZagDQftHLBoCivP = DyVGS3dX0ZxR.findall('"getSeasonsBySeries(.*?)"container"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	vuylTosVej845YfDNK = DyVGS3dX0ZxR.findall('"list-episodes"(.*?)"container"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if cOUkMZagDQftHLBoCivP and '/series/' not in url:
		MJ2gSPyTl9hzoi1 = cOUkMZagDQftHLBoCivP[0]
		items = DyVGS3dX0ZxR.findall('href="([^"]*)" title="([^"]*)".*?src="(.*?)"',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,title,uIGD4vZcP61QNmw78LXqoEpH in items:
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,553,uIGD4vZcP61QNmw78LXqoEpH)
	elif vuylTosVej845YfDNK:
		uIGD4vZcP61QNmw78LXqoEpH = DyVGS3dX0ZxR.findall('"image" src="(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		uIGD4vZcP61QNmw78LXqoEpH = uIGD4vZcP61QNmw78LXqoEpH[0]
		MJ2gSPyTl9hzoi1 = vuylTosVej845YfDNK[0]
		items = DyVGS3dX0ZxR.findall('href="([^"]*)" title="([^"]*)"',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,title in items:
			CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,552,uIGD4vZcP61QNmw78LXqoEpH)
	return
def f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url):
	jDcWv7MAkEV = url.replace('/movies/','/watch_movies/')
	jDcWv7MAkEV = jDcWv7MAkEV.replace('/episodes/','/watch_episodes/')
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',jDcWv7MAkEV,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'CIMAABDO-PLAY-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	EFDgdaV4WT6U2yotAPX1B = DpClq35GVjh(jDcWv7MAkEV,'url')
	KWnAuJIFyESQHjP3X5xzMqUbR6L = []
	vn1grP3y4It9GmVuBbLJfz2A = DyVGS3dX0ZxR.findall('''<iframe.*?src=["'](.*?)["']''',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if vn1grP3y4It9GmVuBbLJfz2A:
		vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A[0]
		pYVvlGR1ES0gdtzayiDqb9w = DpClq35GVjh(vn1grP3y4It9GmVuBbLJfz2A,'url')
		KWnAuJIFyESQHjP3X5xzMqUbR6L.append(vn1grP3y4It9GmVuBbLJfz2A+'?named='+pYVvlGR1ES0gdtzayiDqb9w+'__embed')
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"servers"(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		oogPV1HKSJbGBql46sD25 = DyVGS3dX0ZxR.findall('postID = "(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		oogPV1HKSJbGBql46sD25 = oogPV1HKSJbGBql46sD25[0]
		items = DyVGS3dX0ZxR.findall("getPlayer\('(.*?)'.*?</i>(.*?)</a>",MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		if items:
			for pYVvlGR1ES0gdtzayiDqb9w,title in items:
				title = title.replace(ti3SbXNV0aJ7n5Grc4OQY8Ll1s9,HQmDERMFjx).strip(oQpxmKiRPlHeGsLXNrJF78O)
				vn1grP3y4It9GmVuBbLJfz2A = EFDgdaV4WT6U2yotAPX1B+'/ajax/getPlayer?server='+pYVvlGR1ES0gdtzayiDqb9w+'&postID='+oogPV1HKSJbGBql46sD25+'&Ajax=1'
				vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A+'?named='+title+'__watch'
				KWnAuJIFyESQHjP3X5xzMqUbR6L.append(vn1grP3y4It9GmVuBbLJfz2A)
		else:
			items = DyVGS3dX0ZxR.findall("getPlayerByName\('(.*?)','(.*?)'.*?\"server\">(.*?)</a>",MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
			if items:
				pYVvlGR1ES0gdtzayiDqb9w,G4GpeBPsnO6rZ20mqcESx,title = items[0]
				vn1grP3y4It9GmVuBbLJfz2A = EFDgdaV4WT6U2yotAPX1B+'/ajax/getPlayerByName?server='+pYVvlGR1ES0gdtzayiDqb9w+'&multipleServers='+G4GpeBPsnO6rZ20mqcESx+'&postID='+oogPV1HKSJbGBql46sD25+'&Ajax=1'
				SSHjMN4uegZfb2,Vi9fwvbSBCI0K6hgXA8EpFrT = Oy2YNHPzuJl(vn1grP3y4It9GmVuBbLJfz2A)
				nJayb3s5zlOgQh9BwiCdEDq = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
				vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'POST',SSHjMN4uegZfb2,Vi9fwvbSBCI0K6hgXA8EpFrT,nJayb3s5zlOgQh9BwiCdEDq,HQmDERMFjx,HQmDERMFjx,'CIMAABDO-PLAY-2nd')
				CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
				DFd4RwK2A70cBpeMLlhOu = DyVGS3dX0ZxR.findall('''<iframe src=["'](.*?)["']''',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL|DyVGS3dX0ZxR.IGNORECASE)
				cjfepMobZyFTuwq7WS1EV945L3g = DFd4RwK2A70cBpeMLlhOu[0] if DFd4RwK2A70cBpeMLlhOu else HQmDERMFjx
				if '/iframe/' in cjfepMobZyFTuwq7WS1EV945L3g:
					vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',cjfepMobZyFTuwq7WS1EV945L3g,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'CIMAABDO-PLAY-3rd')
					CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
					hhXsBtDO5AQg7TIG13Ea4MRl6poP = DyVGS3dX0ZxR.findall('version&quot;:&quot;(.*?)&',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
					hhXsBtDO5AQg7TIG13Ea4MRl6poP = hhXsBtDO5AQg7TIG13Ea4MRl6poP[0]
					nJayb3s5zlOgQh9BwiCdEDq = {}
					nJayb3s5zlOgQh9BwiCdEDq['X-Inertia-Partial-Component'] = 'files/mirror/video'
					nJayb3s5zlOgQh9BwiCdEDq['X-Inertia'] = 'true'
					nJayb3s5zlOgQh9BwiCdEDq['X-Inertia-Partial-Data'] = 'streams'
					nJayb3s5zlOgQh9BwiCdEDq['X-Inertia-Version'] = hhXsBtDO5AQg7TIG13Ea4MRl6poP
					vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',cjfepMobZyFTuwq7WS1EV945L3g,HQmDERMFjx,nJayb3s5zlOgQh9BwiCdEDq,HQmDERMFjx,HQmDERMFjx,'CIMAABDO-PLAY-4th')
					CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
					Zq9X0DeCY3k2MinvxSfE8J = aknZqSJyUrFgc9VhH2Psot6e7b8('dict',CzNPJydxQLfw27tv4ZF8KORAbX5)
					groups = Zq9X0DeCY3k2MinvxSfE8J['props']['streams']['data']
					for group in groups:
						RRpfksr1PbZagwCIOJXYNHTo = group['label'].replace(' (source)',HQmDERMFjx)
						JgchXk1oaiA = group['mirrors']
						for UtHvoEe9WjNJQXn4Sc in JgchXk1oaiA:
							pYVvlGR1ES0gdtzayiDqb9w = UtHvoEe9WjNJQXn4Sc['driver']
							vn1grP3y4It9GmVuBbLJfz2A = 'http:'+UtHvoEe9WjNJQXn4Sc['link']+'?named='+pYVvlGR1ES0gdtzayiDqb9w+'__watch____'+RRpfksr1PbZagwCIOJXYNHTo
							KWnAuJIFyESQHjP3X5xzMqUbR6L.append(vn1grP3y4It9GmVuBbLJfz2A)
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"downs"(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('href="([^"]*)" title="([^"]*)"',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,name in items:
			vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A+'?named='+name+'__download'
			if 'http' not in vn1grP3y4It9GmVuBbLJfz2A: vn1grP3y4It9GmVuBbLJfz2A = 'http:'+vn1grP3y4It9GmVuBbLJfz2A
			KWnAuJIFyESQHjP3X5xzMqUbR6L.append(vn1grP3y4It9GmVuBbLJfz2A)
	import NsD5AomUqH
	NsD5AomUqH.NZcWGBmgFEen5hvJjUSIzOCVk7(KWnAuJIFyESQHjP3X5xzMqUbR6L,HDLtdMAy7wPkl8aKC3O2,'video',url)
	return
def hm4kawIPKp3oMrC75dJZA9HS2(search):
	search,GXVabd4sc2u3zp0JI,showDialogs = x0pzMENwy84tBcZvXr(search)
	if search==HQmDERMFjx: search = q156m84QoYrn()
	if search==HQmDERMFjx: return
	search = search.replace(oQpxmKiRPlHeGsLXNrJF78O,'-')
	url = e2VR8nohduY+'/search/'+search+'.html'
	c8wfGju4CWZm(url)
	return
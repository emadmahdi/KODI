# -*- coding: utf-8 -*-
from FF68kA5BUy import *
HDLtdMAy7wPkl8aKC3O2 = 'SHIAVOICE'
EEJvXQzSZNt = '_SHV_'
e2VR8nohduY = Jzthpc2nj5.SITESURLS[HDLtdMAy7wPkl8aKC3O2][0]
headers = {'User-Agent':None}
def kk6X5LxpsND(mode,url,text):
	if   mode==310: zLZUkrP7ac5 = afkxo7FyZWB4O6K1eXrs5I()
	elif mode==311: zLZUkrP7ac5 = c8wfGju4CWZm(url)
	elif mode==312: zLZUkrP7ac5 = f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url)
	elif mode==313: zLZUkrP7ac5 = Uv1FZQ39qOmN4uI2fhGKeR5cJxSW(url)
	elif mode==314: zLZUkrP7ac5 = dnBbVP3FSUHM6eAow8GDkiZEjWlpm(text)
	elif mode==319: zLZUkrP7ac5 = hm4kawIPKp3oMrC75dJZA9HS2(text)
	else: zLZUkrP7ac5 = False
	return zLZUkrP7ac5
def afkxo7FyZWB4O6K1eXrs5I():
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'بحث في الموقع',HQmDERMFjx,319,HQmDERMFjx,HQmDERMFjx,'_REMEMBERRESULTS_')
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(H5x4Z2qPwR8vXM,'GET',e2VR8nohduY,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'SHIAVOICE-MENU-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('id="menulinks"(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	items = DyVGS3dX0ZxR.findall('<h5>(.*?)</h5>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL|DyVGS3dX0ZxR.IGNORECASE)
	for AeXOdC4y3QVZgjMDn8 in range(len(items)):
		title = items[AeXOdC4y3QVZgjMDn8].strip(oQpxmKiRPlHeGsLXNrJF78O)
		CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+title,e2VR8nohduY,314,HQmDERMFjx,HQmDERMFjx,str(AeXOdC4y3QVZgjMDn8+1))
	CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+'مقاطع شهر',e2VR8nohduY,314,HQmDERMFjx,HQmDERMFjx,'0')
	CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	items = DyVGS3dX0ZxR.findall('href="(.*?)".*?<B>(.*?)</B>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	for vn1grP3y4It9GmVuBbLJfz2A,title in items:
		vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+xufJqQcGnhboiVy2wd+vn1grP3y4It9GmVuBbLJfz2A
		CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,311)
	return CzNPJydxQLfw27tv4ZF8KORAbX5
def dnBbVP3FSUHM6eAow8GDkiZEjWlpm(AeXOdC4y3QVZgjMDn8):
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(LLwINhcX2RHSWqpmEnz,'GET',e2VR8nohduY,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'SHIAVOICE-LATEST-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	if AeXOdC4y3QVZgjMDn8=='0':
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('class="tab-content"(.*?)</table>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('href="(.*?)".*?title="(.*?)".*?</i>(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,name,title in items:
			vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+xufJqQcGnhboiVy2wd+vn1grP3y4It9GmVuBbLJfz2A
			title = title.strip(oQpxmKiRPlHeGsLXNrJF78O)
			name = name.strip(oQpxmKiRPlHeGsLXNrJF78O)
			title = title+' ('+name+')'
			CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,312)
	elif AeXOdC4y3QVZgjMDn8 in ['1','2','3']:
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('(<h5>.*?)<div class="col-lg',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		NvLGKpr3Vmfc895jt1RA = int(AeXOdC4y3QVZgjMDn8)-1
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[NvLGKpr3Vmfc895jt1RA]
		if AeXOdC4y3QVZgjMDn8=='1': items = DyVGS3dX0ZxR.findall('href="(.*?)".*?src="(.*?)".*?<strong>(.*?)<.*?</i>(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		else: items = DyVGS3dX0ZxR.findall('href="(.*?)".*?src="(.*?)".*?<strong>(.*?)<.*?href=".*?">(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,uIGD4vZcP61QNmw78LXqoEpH,title,name in items:
			uIGD4vZcP61QNmw78LXqoEpH = e2VR8nohduY+xufJqQcGnhboiVy2wd+uIGD4vZcP61QNmw78LXqoEpH
			vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+xufJqQcGnhboiVy2wd+vn1grP3y4It9GmVuBbLJfz2A
			title = title.strip(oQpxmKiRPlHeGsLXNrJF78O)
			name = name.strip(oQpxmKiRPlHeGsLXNrJF78O)
			title = title+' ('+name+')'
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,311,uIGD4vZcP61QNmw78LXqoEpH)
	elif AeXOdC4y3QVZgjMDn8 in ['4','5','6']:
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('(<h5>.*?)</table>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		AeXOdC4y3QVZgjMDn8 = int(AeXOdC4y3QVZgjMDn8)-4
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[AeXOdC4y3QVZgjMDn8]
		items = DyVGS3dX0ZxR.findall('src="(.*?)".*?href="(.*?)".*?title="(.*?)".*?<strong.*?>(.*?)</strong>.*?-cell">(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for uIGD4vZcP61QNmw78LXqoEpH,vn1grP3y4It9GmVuBbLJfz2A,SLTf7GeYAM,title,hQGaZWkesbXDYn7Altz2oudM in items:
			uIGD4vZcP61QNmw78LXqoEpH = e2VR8nohduY+xufJqQcGnhboiVy2wd+uIGD4vZcP61QNmw78LXqoEpH
			vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+xufJqQcGnhboiVy2wd+vn1grP3y4It9GmVuBbLJfz2A
			title = title.strip(oQpxmKiRPlHeGsLXNrJF78O)
			SLTf7GeYAM = SLTf7GeYAM.strip(oQpxmKiRPlHeGsLXNrJF78O)
			hQGaZWkesbXDYn7Altz2oudM = hQGaZWkesbXDYn7Altz2oudM.strip(oQpxmKiRPlHeGsLXNrJF78O)
			if SLTf7GeYAM: name = SLTf7GeYAM
			else: name = hQGaZWkesbXDYn7Altz2oudM
			title = title+' ('+name+')'
			CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,312,uIGD4vZcP61QNmw78LXqoEpH)
	return
def c8wfGju4CWZm(url):
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'SHIAVOICE-TITLES-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('ibox-heading"(.*?)class="float-right',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	if 'catsum-mobile' in MJ2gSPyTl9hzoi1:
		items = DyVGS3dX0ZxR.findall('src="(.*?)".*?href="(.*?)".*?<strong>(.*?)</strong>.*?catsum-mobile">(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		if items:
			for uIGD4vZcP61QNmw78LXqoEpH,vn1grP3y4It9GmVuBbLJfz2A,title,count in items:
				uIGD4vZcP61QNmw78LXqoEpH = e2VR8nohduY+xufJqQcGnhboiVy2wd+uIGD4vZcP61QNmw78LXqoEpH
				vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+xufJqQcGnhboiVy2wd+vn1grP3y4It9GmVuBbLJfz2A
				count = count.replace(' الصوتية: ',':')
				title = title.strip(oQpxmKiRPlHeGsLXNrJF78O)
				title = title+' ('+count+')'
				CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,311,uIGD4vZcP61QNmw78LXqoEpH)
	else:
		items = DyVGS3dX0ZxR.findall('" href="(.*?)".*?</i>(.*?)</a>.*?">(.*?)<.*?<span.*?<span.*?<span.*?">(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,title,S2ELRsipwZP,OMDCpSL7ZB in items:
			if title==HQmDERMFjx or S2ELRsipwZP==HQmDERMFjx: continue
			vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+xufJqQcGnhboiVy2wd+vn1grP3y4It9GmVuBbLJfz2A
			title = title+' ('+OMDCpSL7ZB+')'
			CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,312)
	if not items: XONC9osGSP4fW5HVrhM(CzNPJydxQLfw27tv4ZF8KORAbX5)
	return
def XONC9osGSP4fW5HVrhM(CzNPJydxQLfw27tv4ZF8KORAbX5):
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('class="ibox-content"(.*?)class="pagination',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	items = DyVGS3dX0ZxR.findall('href="(http.*?)".*?</i>(.*?)<.*?cell">(.*?)<.*?cell">(.*?)<.*?cell">(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	for vn1grP3y4It9GmVuBbLJfz2A,title,name,count,OMDCpSL7ZB in items:
		vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+xufJqQcGnhboiVy2wd+vn1grP3y4It9GmVuBbLJfz2A
		title = title.strip(oQpxmKiRPlHeGsLXNrJF78O)
		name = name.strip(oQpxmKiRPlHeGsLXNrJF78O)
		title = title+' ('+name+')'
		CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,312,HQmDERMFjx,OMDCpSL7ZB)
	return
def Uv1FZQ39qOmN4uI2fhGKeR5cJxSW(url):
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'SHIAVOICE-SEARCH_ITEMS-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('class="ibox-content p-1"(.*?)class="ibox-content"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if not Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		c8wfGju4CWZm(url)
		return
	MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	items = DyVGS3dX0ZxR.findall('href="(.*?)".*?<strong>(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	for vn1grP3y4It9GmVuBbLJfz2A,title in items:
		vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+xufJqQcGnhboiVy2wd+vn1grP3y4It9GmVuBbLJfz2A
		title = title.strip(oQpxmKiRPlHeGsLXNrJF78O)
		if '/play-' in vn1grP3y4It9GmVuBbLJfz2A: CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,312)
		else: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,311)
	return
def f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url):
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(LLwINhcX2RHSWqpmEnz,'GET',url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'SHIAVOICE-PLAY-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	vn1grP3y4It9GmVuBbLJfz2A = DyVGS3dX0ZxR.findall('<audio.*?src="(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if not vn1grP3y4It9GmVuBbLJfz2A: vn1grP3y4It9GmVuBbLJfz2A = DyVGS3dX0ZxR.findall('<video.*?src="(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+vn1grP3y4It9GmVuBbLJfz2A[0]
	uZVS3DcJbEULoxpve9IOTgmW6(vn1grP3y4It9GmVuBbLJfz2A,HDLtdMAy7wPkl8aKC3O2,'video')
	return
def hm4kawIPKp3oMrC75dJZA9HS2(search):
	search,GXVabd4sc2u3zp0JI,showDialogs = x0pzMENwy84tBcZvXr(search)
	if search==HQmDERMFjx: search = q156m84QoYrn()
	if search==HQmDERMFjx: return
	search = search.replace(oQpxmKiRPlHeGsLXNrJF78O,'+')
	yIinvk2lh6atzNOuRGgSJHfL9Zej = ['&t=a','&t=c','&t=s']
	if showDialogs:
		wpgbJf8BOK46AXzUD9QT5n2Pht = ['قارئ','إصدار / مجلد','مقطع الصوتي']
		lwT9cdaH5AxMU8IpZif20jPX = GGiSlWbqKDr5Ovkh2L7sHNTxz('موقع صوت الشيعة - أختر البحث', wpgbJf8BOK46AXzUD9QT5n2Pht)
		if lwT9cdaH5AxMU8IpZif20jPX == -1: return
	elif '_SHIAVOICE-PERSONS_' in GXVabd4sc2u3zp0JI: lwT9cdaH5AxMU8IpZif20jPX = 0
	elif '_SHIAVOICE-ALBUMS_' in GXVabd4sc2u3zp0JI: lwT9cdaH5AxMU8IpZif20jPX = 1
	elif '_SHIAVOICE-AUDIOS_' in GXVabd4sc2u3zp0JI: lwT9cdaH5AxMU8IpZif20jPX = 2
	else: return
	type = yIinvk2lh6atzNOuRGgSJHfL9Zej[lwT9cdaH5AxMU8IpZif20jPX]
	url = e2VR8nohduY+'/search.php?q='+search+type
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'SHIAVOICE-SEARCH-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('class="ibox-content"(.*?)class="ibox-content"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		if lwT9cdaH5AxMU8IpZif20jPX in [0,1]:
			items = DyVGS3dX0ZxR.findall('href="(.*?)".*?src="(.*?)".*?href=".*?">(.*?)<.*?">(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
			for vn1grP3y4It9GmVuBbLJfz2A,uIGD4vZcP61QNmw78LXqoEpH,title,name in items:
				title = title.strip(oQpxmKiRPlHeGsLXNrJF78O)
				name = name.strip(oQpxmKiRPlHeGsLXNrJF78O)
				title = title+' ('+name+')'
				CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,313,uIGD4vZcP61QNmw78LXqoEpH)
		elif lwT9cdaH5AxMU8IpZif20jPX==2:
			items = DyVGS3dX0ZxR.findall('href="(http.*?)".*?</i>(.*?)</a></td><td>(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
			for vn1grP3y4It9GmVuBbLJfz2A,title,name in items:
				title = title.strip(oQpxmKiRPlHeGsLXNrJF78O)
				name = name.strip(oQpxmKiRPlHeGsLXNrJF78O)
				title = title+' ('+name+')'
				CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,312)
	return
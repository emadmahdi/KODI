# -*- coding: utf-8 -*-
from FF68kA5BUy import *
headers = { 'User-Agent' : HQmDERMFjx }
HDLtdMAy7wPkl8aKC3O2 = 'AKWAM'
EEJvXQzSZNt = '_AKW_'
e2VR8nohduY = Jzthpc2nj5.SITESURLS[HDLtdMAy7wPkl8aKC3O2][0]
hZ8oRPVt25vTsIFwY9 = HQmDERMFjx
FwhZ0nXtpoHTMarf = ['ألعاب','المصارعة الحرة','القران الكريم','الكتب و الابحاث','الصور و الخلفيات','المسلسلات الاذاعية']
def kk6X5LxpsND(mode,url,text):
	if   mode==240: zLZUkrP7ac5 = afkxo7FyZWB4O6K1eXrs5I()
	elif mode==241: zLZUkrP7ac5 = c8wfGju4CWZm(url,text)
	elif mode==242: zLZUkrP7ac5 = XONC9osGSP4fW5HVrhM(url)
	elif mode==243: zLZUkrP7ac5 = f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url)
	elif mode==244: zLZUkrP7ac5 = ooxUXkcTj5PF4ad2SwYy(url,'FILTERS___'+text)
	elif mode==245: zLZUkrP7ac5 = ooxUXkcTj5PF4ad2SwYy(url,'CATEGORIES___'+text)
	elif mode==246: zLZUkrP7ac5 = QdaWhw9DKymJt(url)
	elif mode==247: zLZUkrP7ac5 = ASyvljBT0XKC9RrkW32(url)
	elif mode==248: zLZUkrP7ac5 = GeE5DduNZJcQyT()
	elif mode==249: zLZUkrP7ac5 = hm4kawIPKp3oMrC75dJZA9HS2(text)
	else: zLZUkrP7ac5 = False
	return zLZUkrP7ac5
def GeE5DduNZJcQyT():
	u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,'هذا الموقع "أكوام الجديد" في بعض الأحيان فيه نوع من الحجب ضد البرامج . وهذا يسبب مشكلة في تشغيل الفيديوهات . هذه المشكلة سببها من الموقع الأصلي وهي تظهر وتختفي بصورة عشوائية')
	return
def afkxo7FyZWB4O6K1eXrs5I():
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',e2VR8nohduY,HQmDERMFjx,headers,HQmDERMFjx,HQmDERMFjx,'AKWAM-MENU-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	PPB1JrmtTzjRHn = DyVGS3dX0ZxR.findall('home-site-btn-container.*?href="(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if PPB1JrmtTzjRHn: PPB1JrmtTzjRHn = PPB1JrmtTzjRHn[0]
	else: PPB1JrmtTzjRHn = e2VR8nohduY
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',PPB1JrmtTzjRHn,HQmDERMFjx,headers,HQmDERMFjx,HQmDERMFjx,'AKWAM-MENU-2nd')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'بحث في الموقع',HQmDERMFjx,249,HQmDERMFjx,HQmDERMFjx,'_REMEMBERRESULTS_')
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'فلتر محدد',e2VR8nohduY,246)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'فلتر كامل',e2VR8nohduY,247)
	CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+'المميزة',PPB1JrmtTzjRHn,241,HQmDERMFjx,HQmDERMFjx,'featured')
	tQ4GXJbf8dUFo1v = DyVGS3dX0ZxR.findall('recently-container.*?href="(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	vn1grP3y4It9GmVuBbLJfz2A = tQ4GXJbf8dUFo1v[0]
	CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+'أضيف حديثا',vn1grP3y4It9GmVuBbLJfz2A,241)
	CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('mb-4 d-flex align-items-center.*?href="(.*?)".*?class="header-link text-white">(.*?)<.*?class="menu"(.*?)</div>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	for vn1grP3y4It9GmVuBbLJfz2A,name,MJ2gSPyTl9hzoi1 in Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		if name in FwhZ0nXtpoHTMarf: continue
		CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+name,vn1grP3y4It9GmVuBbLJfz2A,241)
		items = DyVGS3dX0ZxR.findall('href="(.*?)">(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,title in items:
			if title in FwhZ0nXtpoHTMarf: continue
			title = name+oQpxmKiRPlHeGsLXNrJF78O+title
			CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,241)
	return
def QdaWhw9DKymJt(website=HQmDERMFjx):
	CzNPJydxQLfw27tv4ZF8KORAbX5 = D0GFPwY8ecAVI(H5x4Z2qPwR8vXM,e2VR8nohduY,HQmDERMFjx,headers,HQmDERMFjx,'AKWAM-MENU-1st')
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('class="menu(.*?)<nav',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('href="(.*?)".*?text">(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,title in items:
			if title not in FwhZ0nXtpoHTMarf:
				title = title+' مصنفة'
				CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,245)
		if website==HQmDERMFjx: CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	return CzNPJydxQLfw27tv4ZF8KORAbX5
def ASyvljBT0XKC9RrkW32(website=HQmDERMFjx):
	CzNPJydxQLfw27tv4ZF8KORAbX5 = D0GFPwY8ecAVI(H5x4Z2qPwR8vXM,e2VR8nohduY,HQmDERMFjx,headers,HQmDERMFjx,'AKWAM-MENU-1st')
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('class="menu(.*?)<nav',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('href="(.*?)".*?text">(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,title in items:
			if title not in FwhZ0nXtpoHTMarf:
				title = title+' مفلترة'
				CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,244)
		if website==HQmDERMFjx: CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	return CzNPJydxQLfw27tv4ZF8KORAbX5
def c8wfGju4CWZm(url,type=HQmDERMFjx):
	CzNPJydxQLfw27tv4ZF8KORAbX5 = D0GFPwY8ecAVI(j9uzmBeEyK8,url,HQmDERMFjx,headers,True,'AKWAM-TITLES-1st')
	if type=='featured': Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('swiper-container(.*?)swiper-button-prev',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	else: Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('class="widget"(.*?)main-footer',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('data-src="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		if not items:
			items = DyVGS3dX0ZxR.findall('src="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for uIGD4vZcP61QNmw78LXqoEpH,vn1grP3y4It9GmVuBbLJfz2A,title in items:
			if '/series/' in vn1grP3y4It9GmVuBbLJfz2A or '/shows/' in vn1grP3y4It9GmVuBbLJfz2A:
				CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,242,uIGD4vZcP61QNmw78LXqoEpH)
			elif '/movies/' in vn1grP3y4It9GmVuBbLJfz2A:
				CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,243,uIGD4vZcP61QNmw78LXqoEpH)
			elif '/games/' not in vn1grP3y4It9GmVuBbLJfz2A:
				CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,243,uIGD4vZcP61QNmw78LXqoEpH)
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('pagination(.*?)</div>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('href="(.*?)".*?>(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,title in items:
			if title=='&lsaquo;': title = 'سابقة'
			if title=='&rsaquo;': title = 'لاحقة'
			vn1grP3y4It9GmVuBbLJfz2A = SVsiEWeRf6oIynqQx8pCrM4Tk(vn1grP3y4It9GmVuBbLJfz2A)
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'صفحة '+title,vn1grP3y4It9GmVuBbLJfz2A,241)
	return
def hm4kawIPKp3oMrC75dJZA9HS2(search):
	search,GXVabd4sc2u3zp0JI,showDialogs = x0pzMENwy84tBcZvXr(search)
	if search==HQmDERMFjx: search = q156m84QoYrn()
	if search==HQmDERMFjx: return
	q5qfEX4yA6lDop1 = search.replace(oQpxmKiRPlHeGsLXNrJF78O,'%20')
	url = e2VR8nohduY + '/search?q='+q5qfEX4yA6lDop1
	zLZUkrP7ac5 = c8wfGju4CWZm(url)
	return
def XONC9osGSP4fW5HVrhM(url):
	CzNPJydxQLfw27tv4ZF8KORAbX5 = D0GFPwY8ecAVI(j9uzmBeEyK8,url,HQmDERMFjx,headers,True,'AKWAM-EPISODES-1st')
	if '-episodes">' not in CzNPJydxQLfw27tv4ZF8KORAbX5:
		uIGD4vZcP61QNmw78LXqoEpH = FpGenVlw4Tzxi2WY3JuXcb.getInfoLabel('ListItem.Icon')
		CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+'رابط التشغيل',url,243,uIGD4vZcP61QNmw78LXqoEpH)
	else:
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('-episodes">(.*?)<div class="widget-4',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		EX6nDt50Hih9mIxulw7kpMCZfaOsJR = DyVGS3dX0ZxR.findall('href="(http.*?)".*?>(.*?)<.*?src="(.*?)"',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,title,uIGD4vZcP61QNmw78LXqoEpH in EX6nDt50Hih9mIxulw7kpMCZfaOsJR:
			title = title.replace(MSnXBQNUg1jF3W2fRlE9OLaCT8ds4,oQpxmKiRPlHeGsLXNrJF78O)
			if 'الحلقات' in title or 'مواسم اخرى' in title: continue
			if '/series/' in vn1grP3y4It9GmVuBbLJfz2A: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,242,uIGD4vZcP61QNmw78LXqoEpH)
			else: CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,243,uIGD4vZcP61QNmw78LXqoEpH)
	return
def f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url):
	CzNPJydxQLfw27tv4ZF8KORAbX5 = D0GFPwY8ecAVI(H5x4Z2qPwR8vXM,url,HQmDERMFjx,headers,True,'AKWAM-PLAY-1st')
	WWbJG6CrUL4tIRsjpNV = DyVGS3dX0ZxR.findall('badge-danger.*?>(.*?)<',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if WWbJG6CrUL4tIRsjpNV and UzSYuZp3Pnhf1W4wyx7Fc0JX6jNb(HDLtdMAy7wPkl8aKC3O2,url,WWbJG6CrUL4tIRsjpNV): return
	TzX2gBOysajxumI5Z8NvqQ = DyVGS3dX0ZxR.findall('li><a href="#(.*?)".*?>(.*?)<',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	Na8vklCpUGYIzP0bjutWOT,gBzGTxKMSVWFLPvfAI0UZ98D5,bUzHWnGg5t1,JZpDnECqv57j2rM1s0mlFSWLezH3Rh = [],[],[],[]
	if TzX2gBOysajxumI5Z8NvqQ:
		mwbkTcCzlA2fNFB = 'mp4'
		for vldiADoFORGqEVwP,RRpfksr1PbZagwCIOJXYNHTo in TzX2gBOysajxumI5Z8NvqQ:
			Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('tab-content quality" id="'+vldiADoFORGqEVwP+'".*?</div>.\s*</div>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
			MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
			bUzHWnGg5t1.append(MJ2gSPyTl9hzoi1)
			JZpDnECqv57j2rM1s0mlFSWLezH3Rh.append(RRpfksr1PbZagwCIOJXYNHTo)
	else:
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('class="qualities(.*?)<h3.*?>(.*?)<',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if not Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
			u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,'لا يوجد ملف فيديو في هذا الرابط')
			return
		else:
			MJ2gSPyTl9hzoi1,filename = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
			TJeVSOQADMsW = ['zip','rar','txt','pdf','htm','tar','iso','html']
			mwbkTcCzlA2fNFB = filename.rsplit('.',1)[1].strip(oQpxmKiRPlHeGsLXNrJF78O)
			if mwbkTcCzlA2fNFB in TJeVSOQADMsW:
				u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,'الملف ليس فيديو ولا صوت')
				return
		bUzHWnGg5t1.append(MJ2gSPyTl9hzoi1)
		JZpDnECqv57j2rM1s0mlFSWLezH3Rh.append(HQmDERMFjx)
	for yuYts1RONXgp in range(len(bUzHWnGg5t1)):
		jzTLleJs8x9Hb1 = DyVGS3dX0ZxR.findall('href="(.*?)".*?icon-(.*?)"',bUzHWnGg5t1[yuYts1RONXgp],DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,Q7kUNJmytAXW in jzTLleJs8x9Hb1:
			if 'torrent' in Q7kUNJmytAXW: continue
			elif 'download' in Q7kUNJmytAXW: type = 'download'
			elif 'play' in Q7kUNJmytAXW: type = 'watch'
			else: type = 'unknown'
			vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A+'?named=__'+type+'____'+JZpDnECqv57j2rM1s0mlFSWLezH3Rh[yuYts1RONXgp]+'__akwam'
			Na8vklCpUGYIzP0bjutWOT.append(vn1grP3y4It9GmVuBbLJfz2A)
	import NsD5AomUqH
	NsD5AomUqH.NZcWGBmgFEen5hvJjUSIzOCVk7(Na8vklCpUGYIzP0bjutWOT,HDLtdMAy7wPkl8aKC3O2,'video',url)
	return
def ooxUXkcTj5PF4ad2SwYy(url,filter):
	rrdHuNZaRCOviqPmS4szhD0VcEjM3 = ['section','category','year','rating']
	if '?' in url: url = url.split('?')[0]
	type,filter = filter.split('___',1)
	if filter==HQmDERMFjx: eA0pnTuMvxrdmoRC9zPBh,mwhEr8eXxD21MAKfHUSlB = HQmDERMFjx,HQmDERMFjx
	else: eA0pnTuMvxrdmoRC9zPBh,mwhEr8eXxD21MAKfHUSlB = filter.split('___')
	if type=='CATEGORIES':
		if rrdHuNZaRCOviqPmS4szhD0VcEjM3[0]+'=' not in eA0pnTuMvxrdmoRC9zPBh: WF2vkePC5gbXAGUarcqlpmB3Q = rrdHuNZaRCOviqPmS4szhD0VcEjM3[0]
		for yuYts1RONXgp in range(len(rrdHuNZaRCOviqPmS4szhD0VcEjM3[0:-1])):
			if rrdHuNZaRCOviqPmS4szhD0VcEjM3[yuYts1RONXgp]+'=' in eA0pnTuMvxrdmoRC9zPBh: WF2vkePC5gbXAGUarcqlpmB3Q = rrdHuNZaRCOviqPmS4szhD0VcEjM3[yuYts1RONXgp+1]
		Cm5jWJgr28TlUnoZYHAxdPI3OB = eA0pnTuMvxrdmoRC9zPBh+'&'+WF2vkePC5gbXAGUarcqlpmB3Q+'=0'
		RRDtwVh6LbFiEycHNQkId5Cefmq = mwhEr8eXxD21MAKfHUSlB+'&'+WF2vkePC5gbXAGUarcqlpmB3Q+'=0'
		GSPtdslyxQURmB5obg69VJMY1jE = Cm5jWJgr28TlUnoZYHAxdPI3OB.strip('&')+'___'+RRDtwVh6LbFiEycHNQkId5Cefmq.strip('&')
		J4asIxU7Zyq5PiN2rKEctegFV = jlZtWwMfosJFIKenicqU1(mwhEr8eXxD21MAKfHUSlB,'all')
		SSHjMN4uegZfb2 = url+'?'+J4asIxU7Zyq5PiN2rKEctegFV
	elif type=='FILTERS':
		v2s9V6uhIT0aCjkPOl7iUqZxB = jlZtWwMfosJFIKenicqU1(eA0pnTuMvxrdmoRC9zPBh,'modified_values')
		v2s9V6uhIT0aCjkPOl7iUqZxB = xx9LK4VzpF6IHXSEyhmrQwbg25P0(v2s9V6uhIT0aCjkPOl7iUqZxB)
		if mwhEr8eXxD21MAKfHUSlB!=HQmDERMFjx: mwhEr8eXxD21MAKfHUSlB = jlZtWwMfosJFIKenicqU1(mwhEr8eXxD21MAKfHUSlB,'all')
		if mwhEr8eXxD21MAKfHUSlB==HQmDERMFjx: SSHjMN4uegZfb2 = url
		else: SSHjMN4uegZfb2 = url+'?'+mwhEr8eXxD21MAKfHUSlB
		CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'أظهار قائمة الفيديو التي تم اختيارها',SSHjMN4uegZfb2,241,HQmDERMFjx,'1')
		CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+' [[   '+v2s9V6uhIT0aCjkPOl7iUqZxB+'   ]]',SSHjMN4uegZfb2,241,HQmDERMFjx,'1')
		CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	CzNPJydxQLfw27tv4ZF8KORAbX5 = D0GFPwY8ecAVI(H5x4Z2qPwR8vXM,url,HQmDERMFjx,headers,True,'AKWAM-FILTERS_MENU-1st')
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('<form id(.*?)</form>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	jnPZuGqg9F5viBUp = DyVGS3dX0ZxR.findall('<select.*?name="(.*?)".*?">(.*?)<(.*?)</select>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	dict = {}
	for DcpbqKxWsJRCSVkQyjf1,name,MJ2gSPyTl9hzoi1 in jnPZuGqg9F5viBUp:
		items = DyVGS3dX0ZxR.findall('<option(.*?)>(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		if '=' not in SSHjMN4uegZfb2: SSHjMN4uegZfb2 = url
		if type=='CATEGORIES':
			if WF2vkePC5gbXAGUarcqlpmB3Q!=DcpbqKxWsJRCSVkQyjf1: continue
			elif len(items)<=1:
				if DcpbqKxWsJRCSVkQyjf1==rrdHuNZaRCOviqPmS4szhD0VcEjM3[-1]: c8wfGju4CWZm(SSHjMN4uegZfb2)
				else: ooxUXkcTj5PF4ad2SwYy(SSHjMN4uegZfb2,'CATEGORIES___'+GSPtdslyxQURmB5obg69VJMY1jE)
				return
			else:
				if DcpbqKxWsJRCSVkQyjf1==rrdHuNZaRCOviqPmS4szhD0VcEjM3[-1]: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'الجميع',SSHjMN4uegZfb2,241,HQmDERMFjx,'1')
				else: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'الجميع',SSHjMN4uegZfb2,245,HQmDERMFjx,HQmDERMFjx,GSPtdslyxQURmB5obg69VJMY1jE)
		elif type=='FILTERS':
			Cm5jWJgr28TlUnoZYHAxdPI3OB = eA0pnTuMvxrdmoRC9zPBh+'&'+DcpbqKxWsJRCSVkQyjf1+'=0'
			RRDtwVh6LbFiEycHNQkId5Cefmq = mwhEr8eXxD21MAKfHUSlB+'&'+DcpbqKxWsJRCSVkQyjf1+'=0'
			GSPtdslyxQURmB5obg69VJMY1jE = Cm5jWJgr28TlUnoZYHAxdPI3OB+'___'+RRDtwVh6LbFiEycHNQkId5Cefmq
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'الجميع : '+name,SSHjMN4uegZfb2,244,HQmDERMFjx,HQmDERMFjx,GSPtdslyxQURmB5obg69VJMY1jE)
		dict[DcpbqKxWsJRCSVkQyjf1] = {}
		for value,yewoKb5dkfHu1xEZMAsY in items:
			if yewoKb5dkfHu1xEZMAsY in FwhZ0nXtpoHTMarf: continue
			if 'value' not in value: value = yewoKb5dkfHu1xEZMAsY
			else: value = DyVGS3dX0ZxR.findall('"(.*?)"',value,DyVGS3dX0ZxR.DOTALL)[0]
			dict[DcpbqKxWsJRCSVkQyjf1][value] = yewoKb5dkfHu1xEZMAsY
			Cm5jWJgr28TlUnoZYHAxdPI3OB = eA0pnTuMvxrdmoRC9zPBh+'&'+DcpbqKxWsJRCSVkQyjf1+'='+yewoKb5dkfHu1xEZMAsY
			RRDtwVh6LbFiEycHNQkId5Cefmq = mwhEr8eXxD21MAKfHUSlB+'&'+DcpbqKxWsJRCSVkQyjf1+'='+value
			CEniUGWr4jMy = Cm5jWJgr28TlUnoZYHAxdPI3OB+'___'+RRDtwVh6LbFiEycHNQkId5Cefmq
			title = yewoKb5dkfHu1xEZMAsY+' : '#+dict[DcpbqKxWsJRCSVkQyjf1]['0']
			title = yewoKb5dkfHu1xEZMAsY+' : '+name
			if type=='FILTERS': CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,url,244,HQmDERMFjx,HQmDERMFjx,CEniUGWr4jMy)
			elif type=='CATEGORIES' and rrdHuNZaRCOviqPmS4szhD0VcEjM3[-2]+'=' in eA0pnTuMvxrdmoRC9zPBh:
				J4asIxU7Zyq5PiN2rKEctegFV = jlZtWwMfosJFIKenicqU1(RRDtwVh6LbFiEycHNQkId5Cefmq,'all')
				jDcWv7MAkEV = url+'?'+J4asIxU7Zyq5PiN2rKEctegFV
				CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,jDcWv7MAkEV,241,HQmDERMFjx,'1')
			else: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,url,245,HQmDERMFjx,HQmDERMFjx,CEniUGWr4jMy)
	return
def jlZtWwMfosJFIKenicqU1(Eya9L4IY3GxqtNoVWegDcPuOR,mode):
	Eya9L4IY3GxqtNoVWegDcPuOR = Eya9L4IY3GxqtNoVWegDcPuOR.strip('&')
	AAwtDoF34Y890RXse = {}
	if '=' in Eya9L4IY3GxqtNoVWegDcPuOR:
		items = Eya9L4IY3GxqtNoVWegDcPuOR.split('&')
		for A07BpVeRJToLb in items:
			airVhHdqCb6Gf49eERSjv1,value = A07BpVeRJToLb.split('=')
			AAwtDoF34Y890RXse[airVhHdqCb6Gf49eERSjv1] = value
	n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6 = HQmDERMFjx
	xSMWIOb5tFvh = ['section','category','rating','year','language','formats','quality']
	for key in xSMWIOb5tFvh:
		if key in list(AAwtDoF34Y890RXse.keys()): value = AAwtDoF34Y890RXse[key]
		else: value = '0'
		if mode=='modified_values' and value!='0': n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6 = n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6+' + '+value
		elif mode=='modified_filters' and value!='0': n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6 = n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6+'&'+key+'='+value
		elif mode=='all': n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6 = n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6+'&'+key+'='+value
	n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6 = n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6.strip(' + ')
	n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6 = n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6.strip('&')
	return n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6
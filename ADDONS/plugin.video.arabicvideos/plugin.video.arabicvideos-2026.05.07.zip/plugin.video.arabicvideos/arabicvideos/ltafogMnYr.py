# -*- coding: utf-8 -*-
from FF68kA5BUy import *
HDLtdMAy7wPkl8aKC3O2 = 'GOOGLESEARCH'
EEJvXQzSZNt = '_GOS_'
def kk6X5LxpsND(lXBL3WrM2JFYm,GUiCEYZjm5,NN9niuC7RoqmhkL2):
	if   lXBL3WrM2JFYm==1010: zLZUkrP7ac5 = afkxo7FyZWB4O6K1eXrs5I()
	elif lXBL3WrM2JFYm==1011: zLZUkrP7ac5 = ijgrlWA2zMnUF0OIqyR3hw9HCo(NN9niuC7RoqmhkL2)
	elif lXBL3WrM2JFYm==1012: zLZUkrP7ac5 = FF6D9PBliVYqNRrmyZsG7Icj3bO(GUiCEYZjm5,NN9niuC7RoqmhkL2)
	elif lXBL3WrM2JFYm==1013: zLZUkrP7ac5 = XX1eyLnvftQ8d0aNwHkcsCJGP4x()
	elif lXBL3WrM2JFYm==1014: zLZUkrP7ac5 = qtfivVPYTdG2DnbNs5kr8g(GUiCEYZjm5,NN9niuC7RoqmhkL2)
	elif lXBL3WrM2JFYm==1015: zLZUkrP7ac5 = TFdprGImDkjNloZS(NN9niuC7RoqmhkL2)
	elif lXBL3WrM2JFYm==1016: zLZUkrP7ac5 = k2MQNnETahsWyf6H0RgAl(NN9niuC7RoqmhkL2)
	elif lXBL3WrM2JFYm==1018: zLZUkrP7ac5 = VSiEfjRp7ColGaKH4P(NN9niuC7RoqmhkL2)
	elif lXBL3WrM2JFYm==1019: zLZUkrP7ac5 = hm4kawIPKp3oMrC75dJZA9HS2(NN9niuC7RoqmhkL2,False)
	else: zLZUkrP7ac5 = False
	return zLZUkrP7ac5
def afkxo7FyZWB4O6K1eXrs5I():
	CfgK4s13Q0hZcHyleT2bVJO9('folder','بحث جوجل جديد',HQmDERMFjx,1019)
	CfgK4s13Q0hZcHyleT2bVJO9('link','كيف يعمل بحث جوجل','',1013)
	CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+'==== كلمات البحث المخزنة ===='+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	AADoyWB6xKYzICleVNvjU8 = FcSRPu295Ot1Jv0Bip3IDom(rDy4FoKpEOsXfT8WZjli,'dict','GLOBALSEARCH_SPLITTED_GOOGLE')
	if AADoyWB6xKYzICleVNvjU8:
		AADoyWB6xKYzICleVNvjU8 = AADoyWB6xKYzICleVNvjU8['__SEQUENCED_COLUMNS__']
		for f5IwhEVtJQG9pODZAU2RnCx7cd80u in reversed(AADoyWB6xKYzICleVNvjU8):
			CfgK4s13Q0hZcHyleT2bVJO9('folder',f5IwhEVtJQG9pODZAU2RnCx7cd80u,HQmDERMFjx,1019,HQmDERMFjx,HQmDERMFjx,f5IwhEVtJQG9pODZAU2RnCx7cd80u)
	return
def VSiEfjRp7ColGaKH4P(search):
	hm4kawIPKp3oMrC75dJZA9HS2(search,True)
	dXUwsnOGKBF57cNaok(mic3MEN709xOkrjD5ZvbGIlX6)
	return
def hm4kawIPKp3oMrC75dJZA9HS2(search,DezlU9wvHymEs0J7AgFNVidM43=False):
	if search==HQmDERMFjx: search = q156m84QoYrn()
	if search==HQmDERMFjx: return
	JNFUAM0L4BQ = search.replace(EEJvXQzSZNt,HQmDERMFjx).lower()
	YpHtyiRc4mdXA56fBnTUDoblFM,m0kqeEO5VtBrozH7,FFPURkqHxVKXpfMeumAiz53ntCrs2T = [],[],[]
	if not DezlU9wvHymEs0J7AgFNVidM43:
		YpHtyiRc4mdXA56fBnTUDoblFM = FcSRPu295Ot1Jv0Bip3IDom(rDy4FoKpEOsXfT8WZjli,'list','GOOGLESEARCH_RESULTS',JNFUAM0L4BQ)
		if YpHtyiRc4mdXA56fBnTUDoblFM: m0kqeEO5VtBrozH7,FFPURkqHxVKXpfMeumAiz53ntCrs2T = YpHtyiRc4mdXA56fBnTUDoblFM
	if DezlU9wvHymEs0J7AgFNVidM43 or not YpHtyiRc4mdXA56fBnTUDoblFM:
		import JEgr7monxk
		JEgr7monxk.zBneiOxaNmXVcW2s1MDjItAqk(JNFUAM0L4BQ,'_GOOGLE',True)
		iCtR4Aewhqybp3QIduao5 = dl8guebaZ9cMBXkwN3Uq7VoLStEO(JNFUAM0L4BQ)
		for A07BpVeRJToLb in iCtR4Aewhqybp3QIduao5:
			name,vn1grP3y4It9GmVuBbLJfz2A,title,text,ban6QpBXi7GK9c42FEemYVyU3qhPg,ZvCajmoUedFL = A07BpVeRJToLb
			if ZvCajmoUedFL in A3IWNgF0q7wp: m0kqeEO5VtBrozH7.append(A07BpVeRJToLb)
			else: FFPURkqHxVKXpfMeumAiz53ntCrs2T.append(A07BpVeRJToLb)
		m0kqeEO5VtBrozH7 = sorted(m0kqeEO5VtBrozH7,reverse=mic3MEN709xOkrjD5ZvbGIlX6,key=lambda key: key[o4bNzIQGYj8En])
		FFPURkqHxVKXpfMeumAiz53ntCrs2T = sorted(FFPURkqHxVKXpfMeumAiz53ntCrs2T,reverse=mic3MEN709xOkrjD5ZvbGIlX6,key=lambda key: key[o4bNzIQGYj8En])
		HqD3sxo0fJX(rDy4FoKpEOsXfT8WZjli,'GOOGLESEARCH_RESULTS',JNFUAM0L4BQ,[m0kqeEO5VtBrozH7,FFPURkqHxVKXpfMeumAiz53ntCrs2T],ppxzXEh5md4Dwota3gBQFc)
		X8X1TJW3AmVdy0ZrFvqjDba7Bg2(rDy4FoKpEOsXfT8WZjli,'GLOBALSEARCH_DETAILED_GOOGLE',JNFUAM0L4BQ)
		JEgr7monxk.zBneiOxaNmXVcW2s1MDjItAqk(JNFUAM0L4BQ,'_GOOGLE',False)
		X8X1TJW3AmVdy0ZrFvqjDba7Bg2(rDy4FoKpEOsXfT8WZjli,'GLOBALSEARCH_DIVIDED_GOOGLE',"%, '"+JNFUAM0L4BQ+"')")
		if m0kqeEO5VtBrozH7: u0W7PAndK1IXU8rxz2jQaM('','',OO2BXYhI8UPNq6L,'تم عمل بحث جوجل جديد وتم إيجاد\n\n'+str(len(m0kqeEO5VtBrozH7))+'  مواقع')
		else: m0kqeEO5VtBrozH7,FFPURkqHxVKXpfMeumAiz53ntCrs2T = UU4ASlpQGjBZu6hLq(JNFUAM0L4BQ,mic3MEN709xOkrjD5ZvbGIlX6)
	CfgK4s13Q0hZcHyleT2bVJO9('link','بحث جماعي لمواقع جوجل','search_sites_google',1012,HQmDERMFjx,HQmDERMFjx,JNFUAM0L4BQ)
	CfgK4s13Q0hZcHyleT2bVJO9('folder','بحث منفرد لمواقع جوجل',HQmDERMFjx,1011,HQmDERMFjx,HQmDERMFjx,JNFUAM0L4BQ)
	CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+'===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	CfgK4s13Q0hZcHyleT2bVJO9('folder','نتائج البحث مفصلة - '+JNFUAM0L4BQ,'opened_sites_google',1012,HQmDERMFjx,HQmDERMFjx,JNFUAM0L4BQ)
	CfgK4s13Q0hZcHyleT2bVJO9('folder','نتائج البحث مقسمة - '+JNFUAM0L4BQ,'listed_sites_google',1012,HQmDERMFjx,HQmDERMFjx,JNFUAM0L4BQ)
	CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+'===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	CfgK4s13Q0hZcHyleT2bVJO9('folder','مواقع جوجل ('+str(len(m0kqeEO5VtBrozH7))+') - '+JNFUAM0L4BQ,'',1016,HQmDERMFjx,HQmDERMFjx,JNFUAM0L4BQ)
	CfgK4s13Q0hZcHyleT2bVJO9('link','إعادة بحث جوجل - '+JNFUAM0L4BQ,'',1018,HQmDERMFjx,HQmDERMFjx,search)
	return
def k2MQNnETahsWyf6H0RgAl(JNFUAM0L4BQ):
	m0kqeEO5VtBrozH7,FFPURkqHxVKXpfMeumAiz53ntCrs2T = UU4ASlpQGjBZu6hLq(JNFUAM0L4BQ)
	if not m0kqeEO5VtBrozH7 and not FFPURkqHxVKXpfMeumAiz53ntCrs2T: return
	Q92QhMOk6tcWmdg3RBL8Yqjx = {}
	for name,vn1grP3y4It9GmVuBbLJfz2A,title,text,ban6QpBXi7GK9c42FEemYVyU3qhPg,ZvCajmoUedFL in m0kqeEO5VtBrozH7: Q92QhMOk6tcWmdg3RBL8Yqjx[ZvCajmoUedFL] = name,vn1grP3y4It9GmVuBbLJfz2A,title,text,ban6QpBXi7GK9c42FEemYVyU3qhPg,ZvCajmoUedFL
	Va0Sd4ATlP1G = list(Q92QhMOk6tcWmdg3RBL8Yqjx.keys())
	import JEgr7monxk
	I3ZSjDFpnQsEGYLykt2a1C = JEgr7monxk.XIZRe7uAVJ(Va0Sd4ATlP1G)
	for ZvCajmoUedFL in I3ZSjDFpnQsEGYLykt2a1C:
		if isinstance(ZvCajmoUedFL,tuple):
			Jzthpc2nj5.menuItemsLIST.append(ZvCajmoUedFL)
			continue
		name,vn1grP3y4It9GmVuBbLJfz2A,title,text,ban6QpBXi7GK9c42FEemYVyU3qhPg,ZvCajmoUedFL = Q92QhMOk6tcWmdg3RBL8Yqjx[ZvCajmoUedFL]
		ddCehb9TygPN5HnMZKBEJA3W42romX,yG0k5pe3mH2,TZRm3tqUKHucWGQ9h08 = h8J6YwoHNtia4LXDVjs0GbW(ZvCajmoUedFL)
		CfgK4s13Q0hZcHyleT2bVJO9('folder',TZRm3tqUKHucWGQ9h08+name,vn1grP3y4It9GmVuBbLJfz2A,1014,ban6QpBXi7GK9c42FEemYVyU3qhPg,'',ZvCajmoUedFL)
	CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+'===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+'مواقع بجوجل غير موجودة بالبرنامج'+cjqzOQ5GXD4kR,HQmDERMFjx,1015)
	FFPURkqHxVKXpfMeumAiz53ntCrs2T = sorted(FFPURkqHxVKXpfMeumAiz53ntCrs2T,reverse=mic3MEN709xOkrjD5ZvbGIlX6,key=lambda key: key[o4bNzIQGYj8En])
	for name,vn1grP3y4It9GmVuBbLJfz2A,title,text,ban6QpBXi7GK9c42FEemYVyU3qhPg,ZvCajmoUedFL in FFPURkqHxVKXpfMeumAiz53ntCrs2T:
		CfgK4s13Q0hZcHyleT2bVJO9('link','_GOS_'+name,vn1grP3y4It9GmVuBbLJfz2A,1015,ban6QpBXi7GK9c42FEemYVyU3qhPg,'',ZvCajmoUedFL)
	return
def UU4ASlpQGjBZu6hLq(JNFUAM0L4BQ,ccrAzjCSphT3=gyd2rf0UR5):
	m0kqeEO5VtBrozH7,FFPURkqHxVKXpfMeumAiz53ntCrs2T = [],[]
	if ccrAzjCSphT3:
		YpHtyiRc4mdXA56fBnTUDoblFM = FcSRPu295Ot1Jv0Bip3IDom(rDy4FoKpEOsXfT8WZjli,'list','GOOGLESEARCH_RESULTS',JNFUAM0L4BQ)
		if YpHtyiRc4mdXA56fBnTUDoblFM: m0kqeEO5VtBrozH7,FFPURkqHxVKXpfMeumAiz53ntCrs2T = YpHtyiRc4mdXA56fBnTUDoblFM
	if not m0kqeEO5VtBrozH7 and not FFPURkqHxVKXpfMeumAiz53ntCrs2T: u0W7PAndK1IXU8rxz2jQaM('','',OO2BXYhI8UPNq6L,'للأسف جوجل لم يجد مواقع فيها طلبك')
	return m0kqeEO5VtBrozH7,FFPURkqHxVKXpfMeumAiz53ntCrs2T
def FF6D9PBliVYqNRrmyZsG7Icj3bO(QG65xDvLnrhmFb9UaRI7,JNFUAM0L4BQ):
	m0kqeEO5VtBrozH7,FFPURkqHxVKXpfMeumAiz53ntCrs2T = UU4ASlpQGjBZu6hLq(JNFUAM0L4BQ)
	if not m0kqeEO5VtBrozH7 and not FFPURkqHxVKXpfMeumAiz53ntCrs2T: return
	GiFRLq61aOJ9,xGNsXRoubSrCHz1 = [],{}
	for name,vn1grP3y4It9GmVuBbLJfz2A,title,text,ban6QpBXi7GK9c42FEemYVyU3qhPg,ZvCajmoUedFL in m0kqeEO5VtBrozH7:
		GiFRLq61aOJ9.append(ZvCajmoUedFL)
		xGNsXRoubSrCHz1[ZvCajmoUedFL] = r2E8sX3Wjc4iYR6qk7oZUndSu0Hfzp(text)
	import JEgr7monxk
	JEgr7monxk.ly3vPB6IbYJfG(JNFUAM0L4BQ,QG65xDvLnrhmFb9UaRI7,HQmDERMFjx,GiFRLq61aOJ9,xGNsXRoubSrCHz1)
	return
def ijgrlWA2zMnUF0OIqyR3hw9HCo(JNFUAM0L4BQ):
	m0kqeEO5VtBrozH7,FFPURkqHxVKXpfMeumAiz53ntCrs2T = UU4ASlpQGjBZu6hLq(JNFUAM0L4BQ)
	if not m0kqeEO5VtBrozH7 and not FFPURkqHxVKXpfMeumAiz53ntCrs2T: return
	Q92QhMOk6tcWmdg3RBL8Yqjx = {}
	for name,vn1grP3y4It9GmVuBbLJfz2A,title,text,ban6QpBXi7GK9c42FEemYVyU3qhPg,ZvCajmoUedFL in m0kqeEO5VtBrozH7:
		Q92QhMOk6tcWmdg3RBL8Yqjx[ZvCajmoUedFL] = name,vn1grP3y4It9GmVuBbLJfz2A,title,text,ban6QpBXi7GK9c42FEemYVyU3qhPg,ZvCajmoUedFL
	Va0Sd4ATlP1G = list(Q92QhMOk6tcWmdg3RBL8Yqjx.keys())
	import JEgr7monxk
	I3ZSjDFpnQsEGYLykt2a1C = JEgr7monxk.XIZRe7uAVJ(Va0Sd4ATlP1G)
	for ZvCajmoUedFL in I3ZSjDFpnQsEGYLykt2a1C:
		if isinstance(ZvCajmoUedFL,tuple):
			Jzthpc2nj5.menuItemsLIST.append(ZvCajmoUedFL)
			continue
		name,vn1grP3y4It9GmVuBbLJfz2A,title,text,ban6QpBXi7GK9c42FEemYVyU3qhPg,ZvCajmoUedFL = Q92QhMOk6tcWmdg3RBL8Yqjx[ZvCajmoUedFL]
		ddCehb9TygPN5HnMZKBEJA3W42romX,yG0k5pe3mH2,TZRm3tqUKHucWGQ9h08 = h8J6YwoHNtia4LXDVjs0GbW(ZvCajmoUedFL)
		text = r2E8sX3Wjc4iYR6qk7oZUndSu0Hfzp(text)
		name = name+' - '+JNFUAM0L4BQ
		CfgK4s13Q0hZcHyleT2bVJO9('folder',TZRm3tqUKHucWGQ9h08+name,ZvCajmoUedFL,548,ban6QpBXi7GK9c42FEemYVyU3qhPg,'',text)
	return
def r2E8sX3Wjc4iYR6qk7oZUndSu0Hfzp(title):
	yTz8SOkAhu24j6apo9BmZHvwWsX = DyVGS3dX0ZxR.findall('(.*?) (الحلقة|حلقة)',title,DyVGS3dX0ZxR.DOTALL)
	eyLMq9Enup0jiJT42RDWafg = yTz8SOkAhu24j6apo9BmZHvwWsX[0][0] if yTz8SOkAhu24j6apo9BmZHvwWsX else title
	eyLMq9Enup0jiJT42RDWafg = eyLMq9Enup0jiJT42RDWafg.replace('مشاهدة اونلاين، فيديو، الإعلان، صور - السينما.كوم','').replace('- ‎عرب سيد - Arabseed','')
	eyLMq9Enup0jiJT42RDWafg = eyLMq9Enup0jiJT42RDWafg.replace('- وى سيما wecima ماى سيما mycima - وي سيما','').replace('- فيديو Dailymotion','')
	eyLMq9Enup0jiJT42RDWafg = eyLMq9Enup0jiJT42RDWafg.replace('الموسم','').replace('الموقع','').replace('- شوف نت','').replace('موسم','').replace('HD','')
	eyLMq9Enup0jiJT42RDWafg = eyLMq9Enup0jiJT42RDWafg.replace('مشاهدة','').replace('نتائج البحث:','').replace('اونلاين','').replace('- سيما فور بي','')
	eyLMq9Enup0jiJT42RDWafg = eyLMq9Enup0jiJT42RDWafg.replace('موقع','').replace('| اكوام','').replace('','').replace('','').replace('','').replace('','')
	eyLMq9Enup0jiJT42RDWafg = eyLMq9Enup0jiJT42RDWafg.strip(' ').replace('    ',' ').replace('   ',' ').replace('  ',' ').replace('  ',' ')
	return eyLMq9Enup0jiJT42RDWafg
def dl8guebaZ9cMBXkwN3Uq7VoLStEO(search):
	search = search.replace(oQpxmKiRPlHeGsLXNrJF78O,'+')
	headers = {'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36 Edg/128.0.0.0'}
	url = 'https://www.google.com/search?hl=en&filter=1&imgSize=small&safe=active&q=-youtube+-instagram+-facebook+-tiktok+-elcinema+'+search
	SSHjMN4uegZfb2 = url+'&start=0&num=100&tbm=vid&udm=7'
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(rwjfOIqQU3ANa0JlWXvCDbFk,'GET',SSHjMN4uegZfb2,HQmDERMFjx,headers,HQmDERMFjx,HQmDERMFjx,'GOOGLESEARCH-SEARCH-1st')
	if not vGXnw9VcUN.succeeded: return []
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	friZl6wo2vTzs = S9Y5kUoRga3EVN.path.join(GnBJi17tQ4ukplr,'googlesearch')
	if not S9Y5kUoRga3EVN.path.exists(friZl6wo2vTzs):
		try: S9Y5kUoRga3EVN.makedirs(friZl6wo2vTzs)
		except: pass
	items = []
	bUzHWnGg5t1 = DyVGS3dX0ZxR.findall('jsname="UWckNb" href="(.*?)".*?<span.*?>(.*?).*?aria-label="(.*?)".*?src="(.*?)".*?class="cuFRh">(.*?)<',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if bUzHWnGg5t1:
		for MJ2gSPyTl9hzoi1 in bUzHWnGg5t1:
			vn1grP3y4It9GmVuBbLJfz2A,title,text,kALyrFT6KPNGI7Oiup82Qb4JCq0td,name = MJ2gSPyTl9hzoi1
			kALyrFT6KPNGI7Oiup82Qb4JCq0td = ''
			items.append([vn1grP3y4It9GmVuBbLJfz2A,title,text,name,kALyrFT6KPNGI7Oiup82Qb4JCq0td])
	else:
		SSHjMN4uegZfb2 = url+'&start=0&num=200'
		vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(rwjfOIqQU3ANa0JlWXvCDbFk,'GET:SCRAPERS',SSHjMN4uegZfb2,HQmDERMFjx,headers,HQmDERMFjx,HQmDERMFjx,'GOOGLESEARCH-SEARCH-2nd')
		if not vGXnw9VcUN.succeeded: return []
		CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
		bUzHWnGg5t1 = DyVGS3dX0ZxR.findall('(\[null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,".*?\]\])',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if not bUzHWnGg5t1: bUzHWnGg5t1 = DyVGS3dX0ZxR.findall('(\[None,None,None,None,None,None,None,None,None,None,None,None,None,None,None,None,None,".*?\]\])',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		for MJ2gSPyTl9hzoi1 in bUzHWnGg5t1:
			MJ2gSPyTl9hzoi1 = aknZqSJyUrFgc9VhH2Psot6e7b8('list',MJ2gSPyTl9hzoi1)
			if len(MJ2gSPyTl9hzoi1)>17:
				vn1grP3y4It9GmVuBbLJfz2A = MJ2gSPyTl9hzoi1[17]
				title,text,name,kALyrFT6KPNGI7Oiup82Qb4JCq0td = MJ2gSPyTl9hzoi1[31][0:4]
				items.append([vn1grP3y4It9GmVuBbLJfz2A,title,text,name,kALyrFT6KPNGI7Oiup82Qb4JCq0td])
	bXZgoU3JCLOxisNMYlQ6zK8Inrk,ceF5tR6GPC4 = [],[]
	for A07BpVeRJToLb in items:
		vn1grP3y4It9GmVuBbLJfz2A,title,text,name,kALyrFT6KPNGI7Oiup82Qb4JCq0td = A07BpVeRJToLb
		name = name.strip(' ')
		if not name: name = DpClq35GVjh(vn1grP3y4It9GmVuBbLJfz2A,'name')
		name = nCu7m5V1eb9Dj8Pyf(name)
		if 'http://' in kALyrFT6KPNGI7Oiup82Qb4JCq0td or 'https://' in kALyrFT6KPNGI7Oiup82Qb4JCq0td: ban6QpBXi7GK9c42FEemYVyU3qhPg = kALyrFT6KPNGI7Oiup82Qb4JCq0td
		elif 'data:image/' in kALyrFT6KPNGI7Oiup82Qb4JCq0td and ';base64,' in kALyrFT6KPNGI7Oiup82Qb4JCq0td:
			EH0xwb9OpFjl2y36IQ7dRVX5nDAP = DyVGS3dX0ZxR.findall('data:image/(\w+);base64,',kALyrFT6KPNGI7Oiup82Qb4JCq0td)
			EH0xwb9OpFjl2y36IQ7dRVX5nDAP = EH0xwb9OpFjl2y36IQ7dRVX5nDAP[0]
			ban6QpBXi7GK9c42FEemYVyU3qhPg = S9Y5kUoRga3EVN.path.join(friZl6wo2vTzs,name+'.'+EH0xwb9OpFjl2y36IQ7dRVX5nDAP)
			if not S9Y5kUoRga3EVN.path.exists(ban6QpBXi7GK9c42FEemYVyU3qhPg):
				kALyrFT6KPNGI7Oiup82Qb4JCq0td = kALyrFT6KPNGI7Oiup82Qb4JCq0td.replace('\\u003d','=')
				kALyrFT6KPNGI7Oiup82Qb4JCq0td = kALyrFT6KPNGI7Oiup82Qb4JCq0td.replace('data:image/'+EH0xwb9OpFjl2y36IQ7dRVX5nDAP+';base64,','')
				EEv2jC04mscR = x4aBluXo02G1eTPr9c.b64decode(kALyrFT6KPNGI7Oiup82Qb4JCq0td)
				open(ban6QpBXi7GK9c42FEemYVyU3qhPg,'wb').write(EEv2jC04mscR)
		else: ban6QpBXi7GK9c42FEemYVyU3qhPg = ''
		ZvCajmoUedFL = hcyfB704J9xVdI5gsWnUSeoAu1i(name,vn1grP3y4It9GmVuBbLJfz2A)
		if ZvCajmoUedFL not in ceF5tR6GPC4:
			ceF5tR6GPC4.append(ZvCajmoUedFL)
			name = oFLajW6gOrufM7I(ZvCajmoUedFL)
			bXZgoU3JCLOxisNMYlQ6zK8Inrk.append([name,vn1grP3y4It9GmVuBbLJfz2A,title,text,ban6QpBXi7GK9c42FEemYVyU3qhPg,ZvCajmoUedFL])
	return bXZgoU3JCLOxisNMYlQ6zK8Inrk
def qtfivVPYTdG2DnbNs5kr8g(vn1grP3y4It9GmVuBbLJfz2A,ZvCajmoUedFL):
	ddCehb9TygPN5HnMZKBEJA3W42romX,yG0k5pe3mH2,TZRm3tqUKHucWGQ9h08 = h8J6YwoHNtia4LXDVjs0GbW(ZvCajmoUedFL)
	if TZRm3tqUKHucWGQ9h08: ddCehb9TygPN5HnMZKBEJA3W42romX()
	else: TFdprGImDkjNloZS()
	return
def XX1eyLnvftQ8d0aNwHkcsCJGP4x():
	u0W7PAndK1IXU8rxz2jQaM('','',OO2BXYhI8UPNq6L,'هذا البحث يستخدم ذكاء وشمولية وسرعة محرك بحث جوجل .. ونتائج هذا البحث هي أسماء مواقع الإنترنت التي موجودة في هذا البرنامج والتي فيها الفيديوهات المطلوبة\n\nهذا البحث يحتاج كلمات بحث عادية جدا بدون أي مراعاة لدقة الكلمات أو تفاصيل الفيديوهات أو حتى إملاء الكلمات\n\nهذا البحث يستطيع أيضا أن يفحص محتويات المواقع التي وجدها جوجل إذا كانت هذه المواقع موجودة بهذا البرنامج')
	return
def TFdprGImDkjNloZS(ZvCajmoUedFL=''):
	u0W7PAndK1IXU8rxz2jQaM('','',ZvCajmoUedFL,'هذا الموقع غير موجود في البرنامج .. أو أسم الموقع مختلف وغير مطابق للاسم المستخدم في البرنامج')
	return
def hcyfB704J9xVdI5gsWnUSeoAu1i(name,vn1grP3y4It9GmVuBbLJfz2A):
	O87OB9HzYebGAMV6XrgU = {
	 'فشار فيديو مشاهدة افلام ومسلسلات اون لاين'	:'FUSHARVIDEO'
	,'وى سيما wecima ماى سيما mycima'			:'WECIMA1'
	,'شبكتي تي في - SHABAKATY TV'				:'SHABAKATY'
	,'اكوام  شبكة اكوام AKWAM'					:'AKWAM'
	,'سيما كلوب  CIMACLUB'						:'CIMACLUB'
	,'سيما فري CIMAFREE':'CIMAFREE'
	,'هلا سيما'			:'HALACIMA'
	,'لاروزا'			:'LAROZA'
	,'برستيج'			:'BRSTEJ'
	,'كرمالك TV'		:'KIRMALK'
	,'سيما فور بي'		:'CIMA4P'
	,'اهواك تي في'		:'AHWAK'
	,'CIMA CLUB'		:'CIMACLUB'
	,'اكوام'			:'AKWAM'
	,'وي سيما'			:'WECIMA1'
	,'سيما ناو'			:'CIMANOW'
	,'سيما لايت'			:'CIMALIGHT'
	,'موقع ماي سيما'	:'CIMALIGHT'
	,'عرب سيد'			:'ARABSEED'
	,'فيديو ياقوت'		:'YAQOT'
	,'المصطبة TV'		:'ALMSTBA'
	,'دراما كافيه'		:'DRAMACAFE'
	,'سيما 400'			:'CIMA400'
	,'فيديو تكات'		:'TIKAAT'
	,'السينما.كوم'		:'ELCINEMA'
	,'فوستا'			:'FOSTA'
	,'سيما عبدو'		:'CIMAABDO'
	,'فاصل إعلاني'		:'FASELHD1'
	,'مسلسلات تايم'		:'SERIESTIME'
	,'شوف نت'			:'SHOOFNET'
	}
	hQGaZWkesbXDYn7Altz2oudM = name.lower()
	Q5h3NlAKkaPpmXtF8uEqV = ''
	for key in list(O87OB9HzYebGAMV6XrgU.keys()):
		if key.lower() in hQGaZWkesbXDYn7Altz2oudM: Q5h3NlAKkaPpmXtF8uEqV = O87OB9HzYebGAMV6XrgU[key]
	if not Q5h3NlAKkaPpmXtF8uEqV:
		cjfepMobZyFTuwq7WS1EV945L3g = DpClq35GVjh(vn1grP3y4It9GmVuBbLJfz2A,'url')
		for ZvCajmoUedFL in list(Jzthpc2nj5.SITESURLS.keys()):
			tkSPaqKuJxBbXMLYiVR3mA = DpClq35GVjh(Jzthpc2nj5.SITESURLS[ZvCajmoUedFL][0],'url')
			if cjfepMobZyFTuwq7WS1EV945L3g==tkSPaqKuJxBbXMLYiVR3mA: Q5h3NlAKkaPpmXtF8uEqV = ZvCajmoUedFL
	if not Q5h3NlAKkaPpmXtF8uEqV:
		hQGaZWkesbXDYn7Altz2oudM = DpClq35GVjh(vn1grP3y4It9GmVuBbLJfz2A,'name')
		for ZvCajmoUedFL in list(Jzthpc2nj5.SITESURLS.keys()):
			ZlyH0jVYBJNe2PIvCzLEK3T = DpClq35GVjh(Jzthpc2nj5.SITESURLS[ZvCajmoUedFL][0],'name')
			if hQGaZWkesbXDYn7Altz2oudM==ZlyH0jVYBJNe2PIvCzLEK3T: Q5h3NlAKkaPpmXtF8uEqV = ZvCajmoUedFL
	if not Q5h3NlAKkaPpmXtF8uEqV: Q5h3NlAKkaPpmXtF8uEqV = name
	Q5h3NlAKkaPpmXtF8uEqV = Q5h3NlAKkaPpmXtF8uEqV.upper()
	return Q5h3NlAKkaPpmXtF8uEqV
# -*- coding: utf-8 -*-
from FF68kA5BUy import *
HDLtdMAy7wPkl8aKC3O2 = 'ALFATIMI'
EEJvXQzSZNt = '_FTM_'
e2VR8nohduY = Jzthpc2nj5.SITESURLS[HDLtdMAy7wPkl8aKC3O2][0]
LNkPwrX0qKegmGlvO3oTi = ['1239','1250','1245','20','1259','218','485','1238','1258','292']
Z6ZenK1bzLlcudiR = ['3030','628']
def kk6X5LxpsND(mode,url,text):
	if   mode==60: zLZUkrP7ac5 = afkxo7FyZWB4O6K1eXrs5I()
	elif mode==61: zLZUkrP7ac5 = c8wfGju4CWZm(url,text)
	elif mode==62: zLZUkrP7ac5 = XONC9osGSP4fW5HVrhM(url)
	elif mode==63: zLZUkrP7ac5 = f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url)
	elif mode==64: zLZUkrP7ac5 = iaD6R29lofANOCurQ3JcWwq(text)
	elif mode==69: zLZUkrP7ac5 = hm4kawIPKp3oMrC75dJZA9HS2(text)
	else: zLZUkrP7ac5 = False
	return zLZUkrP7ac5
def afkxo7FyZWB4O6K1eXrs5I():
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'بحث في الموقع',HQmDERMFjx,69,HQmDERMFjx,HQmDERMFjx,'_REMEMBERRESULTS_')
	CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+'ما يتم مشاهدته الان',e2VR8nohduY,64,HQmDERMFjx,HQmDERMFjx,'recent_viewed_vids')
	CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+'الاكثر مشاهدة',e2VR8nohduY,64,HQmDERMFjx,HQmDERMFjx,'most_viewed_vids')
	CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+'اضيفت مؤخرا',e2VR8nohduY,64,HQmDERMFjx,HQmDERMFjx,'recently_added_vids')
	CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+'فيديو عشوائي',e2VR8nohduY,64,HQmDERMFjx,HQmDERMFjx,'random_vids')
	CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+'افلام ومسلسلات',e2VR8nohduY,61,HQmDERMFjx,HQmDERMFjx,'-1')
	CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+'البرامج الدينية',e2VR8nohduY,61,HQmDERMFjx,HQmDERMFjx,'-2')
	CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+'English Videos',e2VR8nohduY,61,HQmDERMFjx,HQmDERMFjx,'-3')
	return HQmDERMFjx
def c8wfGju4CWZm(url,WF2vkePC5gbXAGUarcqlpmB3Q):
	kpf0W2rZIRHuoNPnjhEDmTG = HQmDERMFjx
	if WF2vkePC5gbXAGUarcqlpmB3Q not in ['-1','-2','-3']: kpf0W2rZIRHuoNPnjhEDmTG = '?cat='+WF2vkePC5gbXAGUarcqlpmB3Q
	SSHjMN4uegZfb2 = e2VR8nohduY+'/menu_level.php'+kpf0W2rZIRHuoNPnjhEDmTG
	CzNPJydxQLfw27tv4ZF8KORAbX5 = D0GFPwY8ecAVI(j9uzmBeEyK8,SSHjMN4uegZfb2,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'ALFATIMI-TITLES-1st')
	items = DyVGS3dX0ZxR.findall('href=\'(.*?)\'.*?>(.*?)<.*?>(.*?)</span>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	D2nFSdxWyw1zt8Z0RAKqb,EyvGPbueNt4YUaT93lhj50R = False,False
	for vn1grP3y4It9GmVuBbLJfz2A,title,count in items:
		title = SVsiEWeRf6oIynqQx8pCrM4Tk(title)
		title = title.strip(oQpxmKiRPlHeGsLXNrJF78O)
		if 'http' not in vn1grP3y4It9GmVuBbLJfz2A: vn1grP3y4It9GmVuBbLJfz2A = 'http:'+vn1grP3y4It9GmVuBbLJfz2A
		kpf0W2rZIRHuoNPnjhEDmTG = DyVGS3dX0ZxR.findall('cat=(.*?)&',vn1grP3y4It9GmVuBbLJfz2A,DyVGS3dX0ZxR.DOTALL)[0]
		if WF2vkePC5gbXAGUarcqlpmB3Q==kpf0W2rZIRHuoNPnjhEDmTG: D2nFSdxWyw1zt8Z0RAKqb = True
		elif D2nFSdxWyw1zt8Z0RAKqb 	or (WF2vkePC5gbXAGUarcqlpmB3Q=='-1' and kpf0W2rZIRHuoNPnjhEDmTG in LNkPwrX0qKegmGlvO3oTi)  						or (WF2vkePC5gbXAGUarcqlpmB3Q=='-2' and kpf0W2rZIRHuoNPnjhEDmTG not in Z6ZenK1bzLlcudiR and kpf0W2rZIRHuoNPnjhEDmTG not in LNkPwrX0qKegmGlvO3oTi)  						or (WF2vkePC5gbXAGUarcqlpmB3Q=='-3' and kpf0W2rZIRHuoNPnjhEDmTG in Z6ZenK1bzLlcudiR):
							if count=='1': CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,63)
							else: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,61,HQmDERMFjx,HQmDERMFjx,kpf0W2rZIRHuoNPnjhEDmTG)
							EyvGPbueNt4YUaT93lhj50R = True
	if not EyvGPbueNt4YUaT93lhj50R: XONC9osGSP4fW5HVrhM(url)
	return
def XONC9osGSP4fW5HVrhM(url):
	CzNPJydxQLfw27tv4ZF8KORAbX5 = D0GFPwY8ecAVI(j9uzmBeEyK8,url,HQmDERMFjx,HQmDERMFjx,True,'ALFATIMI-EPISODES-1st')
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('pagination(.*?)id="footer',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	items = DyVGS3dX0ZxR.findall('grid_view.*?src="(.*?)".*?title="(.*?)".*?<h2.*?href="(.*?)"',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	vn1grP3y4It9GmVuBbLJfz2A = HQmDERMFjx
	for uIGD4vZcP61QNmw78LXqoEpH,title,vn1grP3y4It9GmVuBbLJfz2A in items:
		title = title.replace('Add',HQmDERMFjx).replace('to Quicklist',HQmDERMFjx).strip(oQpxmKiRPlHeGsLXNrJF78O)
		if 'http' not in vn1grP3y4It9GmVuBbLJfz2A: vn1grP3y4It9GmVuBbLJfz2A = 'http:'+vn1grP3y4It9GmVuBbLJfz2A
		CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,63,uIGD4vZcP61QNmw78LXqoEpH)
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1=DyVGS3dX0ZxR.findall('(.*?)div',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	MJ2gSPyTl9hzoi1=Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	MJ2gSPyTl9hzoi1=DyVGS3dX0ZxR.findall('pagination(.*?)</div>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)[0]
	items=DyVGS3dX0ZxR.findall('href="(.*?)".*?>(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	SSHjMN4uegZfb2 = url.split('?')[0]
	for vn1grP3y4It9GmVuBbLJfz2A,sibPMcaz4K in items:
		vn1grP3y4It9GmVuBbLJfz2A = SSHjMN4uegZfb2 + vn1grP3y4It9GmVuBbLJfz2A
		title = SVsiEWeRf6oIynqQx8pCrM4Tk(sibPMcaz4K)
		title = 'صفحة ' + title
		CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,62)
	return vn1grP3y4It9GmVuBbLJfz2A
def f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url):
	if 'videos.php' in url: url = XONC9osGSP4fW5HVrhM(url)
	CzNPJydxQLfw27tv4ZF8KORAbX5 = D0GFPwY8ecAVI(H5x4Z2qPwR8vXM,url,HQmDERMFjx,HQmDERMFjx,True,'ALFATIMI-PLAY-1st')
	items = DyVGS3dX0ZxR.findall('playlistfile:"(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	url = items[0]
	if 'http' not in url: url = 'http:'+url
	uZVS3DcJbEULoxpve9IOTgmW6(url,HDLtdMAy7wPkl8aKC3O2,'video')
	return
def iaD6R29lofANOCurQ3JcWwq(WF2vkePC5gbXAGUarcqlpmB3Q):
	QRw49Dc0SXgn6lzP5jFBe = { 'mode' : WF2vkePC5gbXAGUarcqlpmB3Q }
	url = 'http://alfatimi.tv/ajax.php'
	headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
	data = LGHywlEc41qpeCFiSNX(QRw49Dc0SXgn6lzP5jFBe)
	CzNPJydxQLfw27tv4ZF8KORAbX5 = D0GFPwY8ecAVI(LLwINhcX2RHSWqpmEnz,url,data,headers,True,'ALFATIMI-MOSTS-1st')
	items = DyVGS3dX0ZxR.findall('href="(.*?)".*?title="(.*?)".*?src="(.*?)".*?href',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	for vn1grP3y4It9GmVuBbLJfz2A,title,uIGD4vZcP61QNmw78LXqoEpH in items:
		title = title.strip(oQpxmKiRPlHeGsLXNrJF78O)
		if 'http' not in vn1grP3y4It9GmVuBbLJfz2A: vn1grP3y4It9GmVuBbLJfz2A = 'http:'+vn1grP3y4It9GmVuBbLJfz2A
		CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,63,uIGD4vZcP61QNmw78LXqoEpH)
	return
def hm4kawIPKp3oMrC75dJZA9HS2(search):
	search,GXVabd4sc2u3zp0JI,showDialogs = x0pzMENwy84tBcZvXr(search)
	if search==HQmDERMFjx: search = q156m84QoYrn()
	if search==HQmDERMFjx: return
	q5qfEX4yA6lDop1 = search.replace(oQpxmKiRPlHeGsLXNrJF78O,'+')
	url = e2VR8nohduY + '/search_result.php?query=' + q5qfEX4yA6lDop1
	XONC9osGSP4fW5HVrhM(url)
	return
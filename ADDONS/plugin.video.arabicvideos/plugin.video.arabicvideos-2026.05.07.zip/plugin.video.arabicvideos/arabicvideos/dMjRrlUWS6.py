# -*- coding: utf-8 -*-
from FF68kA5BUy import *
HDLtdMAy7wPkl8aKC3O2 = 'FASELHD2'
headers = {'User-Agent':HQmDERMFjx}
EEJvXQzSZNt = '_FH2_'
e2VR8nohduY = Jzthpc2nj5.SITESURLS[HDLtdMAy7wPkl8aKC3O2][o4bNzIQGYj8En]
FwhZ0nXtpoHTMarf = ['FaselHD']
def kk6X5LxpsND(mode,url,text):
	if   mode==590: zLZUkrP7ac5 = afkxo7FyZWB4O6K1eXrs5I()
	elif mode==591: zLZUkrP7ac5 = c8wfGju4CWZm(url,text)
	elif mode==592: zLZUkrP7ac5 = f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url)
	elif mode==593: zLZUkrP7ac5 = OeIkhc6dCf01i2BFSKX5L8E9Nvr(url,text)
	elif mode==599: zLZUkrP7ac5 = hm4kawIPKp3oMrC75dJZA9HS2(text)
	else: zLZUkrP7ac5 = False
	return zLZUkrP7ac5
def afkxo7FyZWB4O6K1eXrs5I():
	EFDgdaV4WT6U2yotAPX1B = e2VR8nohduY
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',EFDgdaV4WT6U2yotAPX1B,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'FASELHD2-MENU-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'بحث في الموقع',EFDgdaV4WT6U2yotAPX1B,599,HQmDERMFjx,HQmDERMFjx,'_REMEMBERRESULTS_')
	CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	items = DyVGS3dX0ZxR.findall('<h3>(.*?)<.*?href="(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	AeXOdC4y3QVZgjMDn8 = o4bNzIQGYj8En
	for title,vn1grP3y4It9GmVuBbLJfz2A in items:
		vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY
		title = title.strip(oQpxmKiRPlHeGsLXNrJF78O)
		if any(value in title for value in FwhZ0nXtpoHTMarf): continue
		CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,591,HQmDERMFjx,HQmDERMFjx,'featured'+str(AeXOdC4y3QVZgjMDn8))
		AeXOdC4y3QVZgjMDn8 += CH7RKuDVzN9f06q8MtXPhlvIxakEWg
	CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"main-menu"(.*?)</nav>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[o4bNzIQGYj8En]
		ZZOSgyXHzxwsQ7NEe4i = DyVGS3dX0ZxR.findall('<li (.*?)</li>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for t7IyszW0jv in ZZOSgyXHzxwsQ7NEe4i:
			items = DyVGS3dX0ZxR.findall('href="(.*?)".*?>(.*?)<',t7IyszW0jv,DyVGS3dX0ZxR.DOTALL)
			for vn1grP3y4It9GmVuBbLJfz2A,title in items:
				if 'http' not in vn1grP3y4It9GmVuBbLJfz2A: vn1grP3y4It9GmVuBbLJfz2A = EFDgdaV4WT6U2yotAPX1B+vn1grP3y4It9GmVuBbLJfz2A
				CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,591)
	return CzNPJydxQLfw27tv4ZF8KORAbX5
def c8wfGju4CWZm(url,GQB0WzyICDK7mXxN2Acdi=HQmDERMFjx):
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'FASELHD2-TITLES-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	items = []
	if 'featured' in GQB0WzyICDK7mXxN2Acdi:
		AeXOdC4y3QVZgjMDn8 = GQB0WzyICDK7mXxN2Acdi[-CH7RKuDVzN9f06q8MtXPhlvIxakEWg]
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"boxes--holder"(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[int(AeXOdC4y3QVZgjMDn8)]
	elif GQB0WzyICDK7mXxN2Acdi=='filters':
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = [CzNPJydxQLfw27tv4ZF8KORAbX5.replace('\\/',xufJqQcGnhboiVy2wd).replace('\\"','"')]
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[o4bNzIQGYj8En]
	else:
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"boxes--holder"(.*?)"pagination"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[o4bNzIQGYj8En]
	if not items: items = DyVGS3dX0ZxR.findall('href="(.*?)".*?data-image="(.*?)".*?alt="(.*?)"',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	smLQwgO0BynVCcl3fYJ = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية','حلقة']
	ORMkTYjJ1p7 = []
	for vn1grP3y4It9GmVuBbLJfz2A,uIGD4vZcP61QNmw78LXqoEpH,title in items:
		title = title.strip(oQpxmKiRPlHeGsLXNrJF78O)
		try: title = title.encode(gV7JxnFQu2svRAPZ).decode(Zex6D4tJE52r)
		except: pass
		title = SVsiEWeRf6oIynqQx8pCrM4Tk(title)
		if any(value in title.lower() for value in FwhZ0nXtpoHTMarf): continue
		yTz8SOkAhu24j6apo9BmZHvwWsX = DyVGS3dX0ZxR.findall('(.*?) (الحلقة|حلقة).\d+',title,DyVGS3dX0ZxR.DOTALL)
		if '/movseries/' in vn1grP3y4It9GmVuBbLJfz2A: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,591,uIGD4vZcP61QNmw78LXqoEpH)
		elif yTz8SOkAhu24j6apo9BmZHvwWsX:
			title = '_MOD_'+yTz8SOkAhu24j6apo9BmZHvwWsX[0][0]
			if title not in ORMkTYjJ1p7:
				CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,593,uIGD4vZcP61QNmw78LXqoEpH)
				ORMkTYjJ1p7.append(title)
		elif any(value in title for value in smLQwgO0BynVCcl3fYJ): CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,592,uIGD4vZcP61QNmw78LXqoEpH)
		else: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,593,uIGD4vZcP61QNmw78LXqoEpH)
	if GQB0WzyICDK7mXxN2Acdi=='filters':
		lELPWeA4rpO = DyVGS3dX0ZxR.findall('"more_button_page":(.*?),',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		if lELPWeA4rpO:
			count = lELPWeA4rpO[0]
			vn1grP3y4It9GmVuBbLJfz2A = url+'/offset/'+count
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'صفحة أخرى',vn1grP3y4It9GmVuBbLJfz2A,591,HQmDERMFjx,HQmDERMFjx,'filters')
	elif 'featured' not in GQB0WzyICDK7mXxN2Acdi:
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('class="pagination(.*?)</div>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
			MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
			items = DyVGS3dX0ZxR.findall('href="(.*?)">(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
			for vn1grP3y4It9GmVuBbLJfz2A,title in items:
				title = SVsiEWeRf6oIynqQx8pCrM4Tk(title)
				vn1grP3y4It9GmVuBbLJfz2A = SVsiEWeRf6oIynqQx8pCrM4Tk(vn1grP3y4It9GmVuBbLJfz2A)
				if 'http' not in vn1grP3y4It9GmVuBbLJfz2A: vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+vn1grP3y4It9GmVuBbLJfz2A
				CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'صفحة '+title,vn1grP3y4It9GmVuBbLJfz2A,591,HQmDERMFjx,HQmDERMFjx,'details4')
	return
def OeIkhc6dCf01i2BFSKX5L8E9Nvr(url,data=HQmDERMFjx):
	if '/Episodes.php' in url:
		headers = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'POST',url,data,headers,HQmDERMFjx,HQmDERMFjx,'FASELHD2-SEASONS_EPISODES-1st')
		CzNPJydxQLfw27tv4ZF8KORAbX5 = '"EpisodesList"'+vGXnw9VcUN.content+'</div>'
	else:
		vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'FASELHD2-SEASONS_EPISODES-2nd')
		CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	kALyrFT6KPNGI7Oiup82Qb4JCq0td = DyVGS3dX0ZxR.findall('"inner--image"><img src="(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	uIGD4vZcP61QNmw78LXqoEpH = kALyrFT6KPNGI7Oiup82Qb4JCq0td[o4bNzIQGYj8En] if kALyrFT6KPNGI7Oiup82Qb4JCq0td else HQmDERMFjx
	items = []
	if not data:
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"SeasonsList"(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
			MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[o4bNzIQGYj8En]
			items = DyVGS3dX0ZxR.findall('data-id="(.*?)" data-season="(.*?)".*?">(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
			if len(items)>1:
				for EcqoRFnue9Cw1aX5WNtVO2QMJh,Y2OHMQ7a5tFfS1n,title in items:
					vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+'/wp-content/themes/AflamPlus/Inc/Ajax/Single/Episodes.php'
					Vi9fwvbSBCI0K6hgXA8EpFrT = 'season='+Y2OHMQ7a5tFfS1n+'&post_id='+EcqoRFnue9Cw1aX5WNtVO2QMJh
					CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,593,uIGD4vZcP61QNmw78LXqoEpH,HQmDERMFjx,Vi9fwvbSBCI0K6hgXA8EpFrT)
		data = gyd2rf0UR5
	if data and len(items)<FFHRwuxQmbh8BaTqyX3:
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"EpisodesList"(.*?)</div>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
			MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[o4bNzIQGYj8En]
			items = DyVGS3dX0ZxR.findall('href="(.*?)">(.*?)<em>(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
			for vn1grP3y4It9GmVuBbLJfz2A,Uo6C7vBYqD9uOS,eyLMq9Enup0jiJT42RDWafg in items:
				title = Uo6C7vBYqD9uOS+oQpxmKiRPlHeGsLXNrJF78O+eyLMq9Enup0jiJT42RDWafg
				title = title.strip(oQpxmKiRPlHeGsLXNrJF78O)
				CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,592,uIGD4vZcP61QNmw78LXqoEpH)
	return
def f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url):
	url = url.strip(xufJqQcGnhboiVy2wd)+'/watch/'
	KWnAuJIFyESQHjP3X5xzMqUbR6L,oM5QxKTiCrjwszZ0S9dHb1B7p,xqbn6MHwQkWt48lvLUjhZ7TBSri = [],[],[]
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(LLwINhcX2RHSWqpmEnz,'GET',url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'FASELHD2-PLAY-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	OOfClrwaFDnWzms6 = DyVGS3dX0ZxR.findall('العمر :.*?<strong">(.*?)</strong>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if OOfClrwaFDnWzms6 and UzSYuZp3Pnhf1W4wyx7Fc0JX6jNb(HDLtdMAy7wPkl8aKC3O2,url,OOfClrwaFDnWzms6): return
	vn1grP3y4It9GmVuBbLJfz2A = DyVGS3dX0ZxR.findall('<iframe src="(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if vn1grP3y4It9GmVuBbLJfz2A:
		vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A[0]
		KWnAuJIFyESQHjP3X5xzMqUbR6L.append(vn1grP3y4It9GmVuBbLJfz2A+'?named=__embed')
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"main--contents"(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('data-i="(.*?)".*?data-id="(.*?)".*?<span>(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for t0FuXyhb1ZsLM4UfKkHIJP2Orwm,EcqoRFnue9Cw1aX5WNtVO2QMJh,title in items:
			title = title.strip(oQpxmKiRPlHeGsLXNrJF78O)
			vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+'/wp-content/themes/AflamPlus/Inc/Ajax/Single/Server.php?id='+EcqoRFnue9Cw1aX5WNtVO2QMJh+'&i='+t0FuXyhb1ZsLM4UfKkHIJP2Orwm
			KWnAuJIFyESQHjP3X5xzMqUbR6L.append(vn1grP3y4It9GmVuBbLJfz2A+'?named='+title+'__watch')
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"downloads"(.*?)</div>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('href="(.*?)".*?<span>(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,name in items:
			KWnAuJIFyESQHjP3X5xzMqUbR6L.append(vn1grP3y4It9GmVuBbLJfz2A+'?named='+name+'__download')
	for VFyHmsD6IYWXEjOL4KJnkMuZ3avRNC in KWnAuJIFyESQHjP3X5xzMqUbR6L:
		vn1grP3y4It9GmVuBbLJfz2A,name = VFyHmsD6IYWXEjOL4KJnkMuZ3avRNC.split('?named')
		if vn1grP3y4It9GmVuBbLJfz2A not in oM5QxKTiCrjwszZ0S9dHb1B7p:
			oM5QxKTiCrjwszZ0S9dHb1B7p.append(vn1grP3y4It9GmVuBbLJfz2A)
			xqbn6MHwQkWt48lvLUjhZ7TBSri.append(VFyHmsD6IYWXEjOL4KJnkMuZ3avRNC)
	import NsD5AomUqH
	NsD5AomUqH.NZcWGBmgFEen5hvJjUSIzOCVk7(xqbn6MHwQkWt48lvLUjhZ7TBSri,HDLtdMAy7wPkl8aKC3O2,'video',url)
	return
def hm4kawIPKp3oMrC75dJZA9HS2(search):
	search,GXVabd4sc2u3zp0JI,showDialogs = x0pzMENwy84tBcZvXr(search)
	if search==HQmDERMFjx: search = q156m84QoYrn()
	if search==HQmDERMFjx: return
	search = search.replace(oQpxmKiRPlHeGsLXNrJF78O,'+')
	EFDgdaV4WT6U2yotAPX1B = e2VR8nohduY
	url = EFDgdaV4WT6U2yotAPX1B+'/?s='+search
	c8wfGju4CWZm(url,'details5')
	return
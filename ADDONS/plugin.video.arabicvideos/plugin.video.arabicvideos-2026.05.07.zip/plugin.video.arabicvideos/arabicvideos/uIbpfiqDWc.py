# -*- coding: utf-8 -*-
from FF68kA5BUy import *
HDLtdMAy7wPkl8aKC3O2 = 'KATKOUTE'
EEJvXQzSZNt = '_KTK_'
e2VR8nohduY = Jzthpc2nj5.SITESURLS[HDLtdMAy7wPkl8aKC3O2][0]
FwhZ0nXtpoHTMarf = ['الصفحة الرئيسية','Sign in','الأقسام']
def kk6X5LxpsND(mode,url,text):
	if   mode==670: zLZUkrP7ac5 = afkxo7FyZWB4O6K1eXrs5I()
	elif mode==671: zLZUkrP7ac5 = c8wfGju4CWZm(url,text)
	elif mode==672: zLZUkrP7ac5 = f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url)
	elif mode==673: zLZUkrP7ac5 = QQp8orwMlAa1(url,text)
	elif mode==674: zLZUkrP7ac5 = REWBU20fyqaLprY(url)
	elif mode==679: zLZUkrP7ac5 = hm4kawIPKp3oMrC75dJZA9HS2(text)
	else: zLZUkrP7ac5 = False
	return zLZUkrP7ac5
def afkxo7FyZWB4O6K1eXrs5I():
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',e2VR8nohduY,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'KATKOUTE-MENU-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'بحث في الموقع',HQmDERMFjx,679,HQmDERMFjx,HQmDERMFjx,'_REMEMBERRESULTS_')
	CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"navslide-divider"(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('href="(.*?)">(.*?)</a>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,title in items:
			if title in FwhZ0nXtpoHTMarf: continue
			if title=='الأقسام': mode = 675
			else: mode = 674
			CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,mode)
	CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	items = ZFEjC6KpI78XPWd9TueM(e2VR8nohduY+'/watch/browse.html')
	for vn1grP3y4It9GmVuBbLJfz2A,uIGD4vZcP61QNmw78LXqoEpH,title in items:
		CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,674,uIGD4vZcP61QNmw78LXqoEpH)
	return
def ZFEjC6KpI78XPWd9TueM(url):
	CGfLEIZtjWqlz = FcSRPu295Ot1Jv0Bip3IDom(rDy4FoKpEOsXfT8WZjli,'list','KATKOUTE','CATEGORIES')
	if CGfLEIZtjWqlz: return CGfLEIZtjWqlz
	CGfLEIZtjWqlz = []
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(rwjfOIqQU3ANa0JlWXvCDbFk,'GET',url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'KATKOUTE-CATEGORIES-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"category-header"(.*?)<footer>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		CGfLEIZtjWqlz = DyVGS3dX0ZxR.findall('href="(.*?)".*?src="(.*?)" alt="(.*?)"',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		if CGfLEIZtjWqlz: HqD3sxo0fJX(rDy4FoKpEOsXfT8WZjli,'KATKOUTE','CATEGORIES',CGfLEIZtjWqlz,H5x4Z2qPwR8vXM)
	return CGfLEIZtjWqlz
def REWBU20fyqaLprY(url):
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'KATKOUTE-SUBMENU-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	cOUkMZagDQftHLBoCivP = DyVGS3dX0ZxR.findall('"caret"(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if cOUkMZagDQftHLBoCivP:
		MJ2gSPyTl9hzoi1 = cOUkMZagDQftHLBoCivP[0]
		MJ2gSPyTl9hzoi1 = MJ2gSPyTl9hzoi1.replace('"presentation"','</ul>')
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		if not Ut7reR0XioMjOdYWZKsLIuc3TQJmC1: Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = [(HQmDERMFjx,MJ2gSPyTl9hzoi1)]
		CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' فرز أو فلتر أو ترتيب '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
		for XwidGQz8WkV1CorLYJ4Z9aqO0g,MJ2gSPyTl9hzoi1 in Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
			items = DyVGS3dX0ZxR.findall('href="(.*?)".*?>(.*?)</a>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
			if XwidGQz8WkV1CorLYJ4Z9aqO0g: XwidGQz8WkV1CorLYJ4Z9aqO0g = XwidGQz8WkV1CorLYJ4Z9aqO0g+': '
			for vn1grP3y4It9GmVuBbLJfz2A,title in items:
				title = XwidGQz8WkV1CorLYJ4Z9aqO0g+title
				CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,671)
	vuylTosVej845YfDNK = DyVGS3dX0ZxR.findall('"pm-category-subcats"(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if vuylTosVej845YfDNK:
		MJ2gSPyTl9hzoi1 = vuylTosVej845YfDNK[0]
		items = DyVGS3dX0ZxR.findall('href="(.*?)">(.*?)</a>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		if len(items)<30:
			CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
			for vn1grP3y4It9GmVuBbLJfz2A,title in items:
				CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,671)
	if not cOUkMZagDQftHLBoCivP and not vuylTosVej845YfDNK: c8wfGju4CWZm(url)
	return
def c8wfGju4CWZm(url,S46ZVrhN1gWY0Iiaj=HQmDERMFjx):
	if S46ZVrhN1gWY0Iiaj=='ajax-search':
		url,search = url.split('?',1)
		data = 'queryString='+search
		headers = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'POST',url,data,headers,HQmDERMFjx,HQmDERMFjx,'KATKOUTE-TITLES-1st')
	else:
		vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'KATKOUTE-TITLES-2nd')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	MJ2gSPyTl9hzoi1,items = HQmDERMFjx,[]
	EFDgdaV4WT6U2yotAPX1B = DpClq35GVjh(url,'url')
	if S46ZVrhN1gWY0Iiaj=='ajax-search':
		MJ2gSPyTl9hzoi1 = CzNPJydxQLfw27tv4ZF8KORAbX5
		bbiKcPz2RQOUwS = DyVGS3dX0ZxR.findall('href="(.*?)">(.*?)</a>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,title in bbiKcPz2RQOUwS: items.append((HQmDERMFjx,vn1grP3y4It9GmVuBbLJfz2A,title))
	elif S46ZVrhN1gWY0Iiaj=='featured':
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"pm-video-watch-featured"(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1: MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	elif S46ZVrhN1gWY0Iiaj=='new_episodes':
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"row pm-ul-browse-videos(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1: MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	elif S46ZVrhN1gWY0Iiaj=='new_movies':
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"row pm-ul-browse-videos(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if len(Ut7reR0XioMjOdYWZKsLIuc3TQJmC1)>1: MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[1]
	elif S46ZVrhN1gWY0Iiaj=='featured_series':
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"home-series-list"(.*?)</div>[\t|\n]*</div>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1: MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		bbiKcPz2RQOUwS = DyVGS3dX0ZxR.findall('href="(.*?)">(.*?)</a>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,title in bbiKcPz2RQOUwS: items.append((HQmDERMFjx,vn1grP3y4It9GmVuBbLJfz2A,title))
	else:
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('(data-echo=".*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1: MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	if MJ2gSPyTl9hzoi1 and not items: items = DyVGS3dX0ZxR.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	if not items: return
	ORMkTYjJ1p7 = []
	smLQwgO0BynVCcl3fYJ = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية','فلم']
	for uIGD4vZcP61QNmw78LXqoEpH,vn1grP3y4It9GmVuBbLJfz2A,title in items:
		yTz8SOkAhu24j6apo9BmZHvwWsX = DyVGS3dX0ZxR.findall('(.*?) (الحلقة|حلقة).\d+',title,DyVGS3dX0ZxR.DOTALL)
		if any(value in title for value in smLQwgO0BynVCcl3fYJ):
			CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,672,uIGD4vZcP61QNmw78LXqoEpH)
		elif S46ZVrhN1gWY0Iiaj=='new_episodes':
			CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,672,uIGD4vZcP61QNmw78LXqoEpH)
		elif yTz8SOkAhu24j6apo9BmZHvwWsX:
			title = '_MOD_' + yTz8SOkAhu24j6apo9BmZHvwWsX[0][0]
			if title not in ORMkTYjJ1p7:
				CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,673,uIGD4vZcP61QNmw78LXqoEpH)
				ORMkTYjJ1p7.append(title)
		elif '/movseries/' in vn1grP3y4It9GmVuBbLJfz2A:
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,671,uIGD4vZcP61QNmw78LXqoEpH)
		else: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,673,uIGD4vZcP61QNmw78LXqoEpH)
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"pagination(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('href="(.*?)".*?>(.*?)</a>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,title in items:
			if vn1grP3y4It9GmVuBbLJfz2A=='#': continue
			if 'http' not in vn1grP3y4It9GmVuBbLJfz2A:
				SSHjMN4uegZfb2 = url.rsplit(xufJqQcGnhboiVy2wd,1)[0]
				vn1grP3y4It9GmVuBbLJfz2A = SSHjMN4uegZfb2+xufJqQcGnhboiVy2wd+vn1grP3y4It9GmVuBbLJfz2A.strip(xufJqQcGnhboiVy2wd)
			title = SVsiEWeRf6oIynqQx8pCrM4Tk(title)
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'صفحة '+title,vn1grP3y4It9GmVuBbLJfz2A,671,HQmDERMFjx,HQmDERMFjx,S46ZVrhN1gWY0Iiaj)
	return
def QQp8orwMlAa1(url,Y2OHMQ7a5tFfS1n):
	CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+'تشغيل الفيديو',url,672)
	CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	CGfLEIZtjWqlz = ZFEjC6KpI78XPWd9TueM(e2VR8nohduY+'/watch/browse.html')
	TTvs813UZF4clgEhIASG0Mz,aMXWrV75Gu,TphdbuJUkx = zip(*CGfLEIZtjWqlz)
	WYo0JbpwKi7BICdO = []
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'KATKOUTE-EPISODES-2nd')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"row pm-video-heading"(.*?)id="player"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		jzTLleJs8x9Hb1 = DyVGS3dX0ZxR.findall('class="myButton".*?href="(.*?)".*?<b>(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,title in jzTLleJs8x9Hb1:
			if vn1grP3y4It9GmVuBbLJfz2A not in TTvs813UZF4clgEhIASG0Mz:
				A07BpVeRJToLb = (vn1grP3y4It9GmVuBbLJfz2A,title)
				WYo0JbpwKi7BICdO.append(A07BpVeRJToLb)
		if len(WYo0JbpwKi7BICdO)==1:
			vn1grP3y4It9GmVuBbLJfz2A,title = WYo0JbpwKi7BICdO[0]
			c8wfGju4CWZm(vn1grP3y4It9GmVuBbLJfz2A,'new_episodes')
			return
		else:
			for vn1grP3y4It9GmVuBbLJfz2A,title in WYo0JbpwKi7BICdO:
				CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,671,HQmDERMFjx,HQmDERMFjx,'new_episodes')
	if not WYo0JbpwKi7BICdO: c8wfGju4CWZm(url,'new_episodes')
	return
def f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url):
	KWnAuJIFyESQHjP3X5xzMqUbR6L = []
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'KATKOUTE-PLAY-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('sources:(.*?)flashplayer',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		jzTLleJs8x9Hb1 = DyVGS3dX0ZxR.findall('file: "(.*?)".*?label: "(.*?)"',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,RRpfksr1PbZagwCIOJXYNHTo in jzTLleJs8x9Hb1:
			vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A+'?named=__watch__'+RRpfksr1PbZagwCIOJXYNHTo
			KWnAuJIFyESQHjP3X5xzMqUbR6L.append(vn1grP3y4It9GmVuBbLJfz2A)
	jzTLleJs8x9Hb1 = DyVGS3dX0ZxR.findall('"embedded-video".*?src="(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if not jzTLleJs8x9Hb1: jzTLleJs8x9Hb1 = DyVGS3dX0ZxR.findall("file: '(.*?)'",CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if jzTLleJs8x9Hb1:
		vn1grP3y4It9GmVuBbLJfz2A = jzTLleJs8x9Hb1[0]
		if 'http' not in vn1grP3y4It9GmVuBbLJfz2A: vn1grP3y4It9GmVuBbLJfz2A = 'http:'+vn1grP3y4It9GmVuBbLJfz2A
		KWnAuJIFyESQHjP3X5xzMqUbR6L.append(vn1grP3y4It9GmVuBbLJfz2A+'?named=__embed')
	import NsD5AomUqH
	NsD5AomUqH.NZcWGBmgFEen5hvJjUSIzOCVk7(KWnAuJIFyESQHjP3X5xzMqUbR6L,HDLtdMAy7wPkl8aKC3O2,'video',url)
	return
def hm4kawIPKp3oMrC75dJZA9HS2(search):
	search,GXVabd4sc2u3zp0JI,showDialogs = x0pzMENwy84tBcZvXr(search)
	if search==HQmDERMFjx: search = q156m84QoYrn()
	if search==HQmDERMFjx: return
	search = search.replace(oQpxmKiRPlHeGsLXNrJF78O,'+')
	url = e2VR8nohduY+'/watch/search.php?keywords='+search
	c8wfGju4CWZm(url,'search')
	return
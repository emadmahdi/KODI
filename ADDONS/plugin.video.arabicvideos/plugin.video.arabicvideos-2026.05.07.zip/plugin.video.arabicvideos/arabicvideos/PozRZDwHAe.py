﻿# -*- coding: utf-8 -*-
from FF68kA5BUy import *
def kk6X5LxpsND(lXBL3WrM2JFYm,shUt0IuSnTzyR3iobNF):
	if shUt0IuSnTzyR3iobNF==HQmDERMFjx: return
	if lXBL3WrM2JFYm==1:
		T7ktndxrcMCj = P3qhMC0OYJ9UBWEG7ia4fkd.getCurrentWindowDialogId()
		HBrpsCLNuT0XOPGZA6IJSy3ai = P3qhMC0OYJ9UBWEG7ia4fkd.Window(T7ktndxrcMCj)
		shUt0IuSnTzyR3iobNF = hMt6yjiJ2DpwBE(shUt0IuSnTzyR3iobNF)
		HBrpsCLNuT0XOPGZA6IJSy3ai.getControl(311).setLabel(shUt0IuSnTzyR3iobNF)
	if lXBL3WrM2JFYm==0:
		OfjUxo1dAFI8sW3vgCBGKQpln='X'
		if HH6mxXjgcrEN1aenMFWQkS: mmlV6G2N0tLDnwa = isinstance(shUt0IuSnTzyR3iobNF,str)
		else: mmlV6G2N0tLDnwa = isinstance(shUt0IuSnTzyR3iobNF,unicode)
		if mmlV6G2N0tLDnwa==True: OfjUxo1dAFI8sW3vgCBGKQpln='U'
		SRtZpdWVHk6co=str(type(shUt0IuSnTzyR3iobNF))+oQpxmKiRPlHeGsLXNrJF78O+shUt0IuSnTzyR3iobNF+oQpxmKiRPlHeGsLXNrJF78O+OfjUxo1dAFI8sW3vgCBGKQpln+oQpxmKiRPlHeGsLXNrJF78O
		for yuYts1RONXgp in range(0,len(shUt0IuSnTzyR3iobNF),1):
			SRtZpdWVHk6co += hex(ord(shUt0IuSnTzyR3iobNF[yuYts1RONXgp])).replace('0x',HQmDERMFjx)+oQpxmKiRPlHeGsLXNrJF78O
		shUt0IuSnTzyR3iobNF = hMt6yjiJ2DpwBE(shUt0IuSnTzyR3iobNF)
		OfjUxo1dAFI8sW3vgCBGKQpln='X'
		if HH6mxXjgcrEN1aenMFWQkS: mmlV6G2N0tLDnwa = isinstance(shUt0IuSnTzyR3iobNF, str)
		else: mmlV6G2N0tLDnwa = isinstance(shUt0IuSnTzyR3iobNF, unicode)
		if mmlV6G2N0tLDnwa==True: OfjUxo1dAFI8sW3vgCBGKQpln='U'
		QQlcGEhed3xbPnrCXmIFvA=str(type(shUt0IuSnTzyR3iobNF))+oQpxmKiRPlHeGsLXNrJF78O+shUt0IuSnTzyR3iobNF+oQpxmKiRPlHeGsLXNrJF78O+OfjUxo1dAFI8sW3vgCBGKQpln+oQpxmKiRPlHeGsLXNrJF78O
		for yuYts1RONXgp in range(0,len(shUt0IuSnTzyR3iobNF),1):
			QQlcGEhed3xbPnrCXmIFvA += hex(ord(shUt0IuSnTzyR3iobNF[yuYts1RONXgp])).replace('0x',HQmDERMFjx)+oQpxmKiRPlHeGsLXNrJF78O
	return
# -*- coding: utf-8 -*-
import sys as TPW58slaVE9OrYQXZnGo2yAfFzpBxc
tbYWAoeMyHTsgFG5x6huz1 = TPW58slaVE9OrYQXZnGo2yAfFzpBxc.version_info [0] == 2
CUJSAbZztE8vYdGByLH0KcnWqe = 2048
R0QCXnpyL1DJwBH67FW = 7
def kSod2AxqugH0 (LURfCucn30xKsMdTiG):
	global ghCyPxkWILcXrGjVut6MQo59fsv
	MfIpC9TDz7Qa5g2vVqPtXh4 = ord (LURfCucn30xKsMdTiG [-1])
	nndScZEtapB74 = LURfCucn30xKsMdTiG [:-1]
	LRbqugZJAa3192OCewWGHvEcP = MfIpC9TDz7Qa5g2vVqPtXh4 % len (nndScZEtapB74)
	qLc7RGgDQE = nndScZEtapB74 [:LRbqugZJAa3192OCewWGHvEcP] + nndScZEtapB74 [LRbqugZJAa3192OCewWGHvEcP:]
	if tbYWAoeMyHTsgFG5x6huz1:
		XUczap3yA0QqFRC82OH6E5mL = unicode () .join ([unichr (ord (ah5u39EBY81MlrwA0cmoz4ngb7TLed) - CUJSAbZztE8vYdGByLH0KcnWqe - (YMjpxPr8WsJ1Bg6Xd + MfIpC9TDz7Qa5g2vVqPtXh4) % R0QCXnpyL1DJwBH67FW) for YMjpxPr8WsJ1Bg6Xd, ah5u39EBY81MlrwA0cmoz4ngb7TLed in enumerate (qLc7RGgDQE)])
	else:
		XUczap3yA0QqFRC82OH6E5mL = str () .join ([chr (ord (ah5u39EBY81MlrwA0cmoz4ngb7TLed) - CUJSAbZztE8vYdGByLH0KcnWqe - (YMjpxPr8WsJ1Bg6Xd + MfIpC9TDz7Qa5g2vVqPtXh4) % R0QCXnpyL1DJwBH67FW) for YMjpxPr8WsJ1Bg6Xd, ah5u39EBY81MlrwA0cmoz4ngb7TLed in enumerate (qLc7RGgDQE)])
	return eval (XUczap3yA0QqFRC82OH6E5mL)
jL1E5AKfwBDv6xmeQtUXcJ3d,JJA7fypmZFVlazvNI,dBi72erQEtKDOwjNFaoAgSP=kSod2AxqugH0,kSod2AxqugH0,kSod2AxqugH0
CDwSWB4v39N7,k4IUieraScH9DV1N7pJgQosYAx5l,Tcf5Ppn9UajDbzyM=dBi72erQEtKDOwjNFaoAgSP,JJA7fypmZFVlazvNI,jL1E5AKfwBDv6xmeQtUXcJ3d
X2crmy67eZpkGTRd,HDpmv4UXzlf72SK9,C3ZK1pu4rfmj8TsWUtBaM=Tcf5Ppn9UajDbzyM,k4IUieraScH9DV1N7pJgQosYAx5l,CDwSWB4v39N7
mg3CbXMA2ouZzQDhRqB,OBsrtQo2pPlgURCxJYbj9iXMD,ssnfOzb16wVog9GKdqcXR3JC7ktSPA=C3ZK1pu4rfmj8TsWUtBaM,HDpmv4UXzlf72SK9,X2crmy67eZpkGTRd
ShnRVsifKtc60zqQ,KKi79PFqsYB0dWSRgaJ3DyE,OzU6t0qcH7MQabeBYK8vgoG=ssnfOzb16wVog9GKdqcXR3JC7ktSPA,OBsrtQo2pPlgURCxJYbj9iXMD,mg3CbXMA2ouZzQDhRqB
mgLADoQ1pbtY,U0VwOviFaYPz2QGs45mJhMXf7Zk,pCTzbw4GyVJHjkcIMQ=OzU6t0qcH7MQabeBYK8vgoG,KKi79PFqsYB0dWSRgaJ3DyE,ShnRVsifKtc60zqQ
owbMhINBQsmx70guApW,SODvU3Ibq5VzC,PPAUFrY8cduRT=pCTzbw4GyVJHjkcIMQ,U0VwOviFaYPz2QGs45mJhMXf7Zk,mgLADoQ1pbtY
knTyjJ0sGIzuwbxRae,nz8x32hX0qcjUPFZk5RdJsiwED,A0aqj9uclgOtByJ6F4bz=PPAUFrY8cduRT,SODvU3Ibq5VzC,owbMhINBQsmx70guApW
YJxaX0MQOHb8oyCBFdnIAe,n6sfYuHBlVdzgmvpXwR3irON0KIj8,LHX65I9nkx0PstgcVY24uSi=A0aqj9uclgOtByJ6F4bz,nz8x32hX0qcjUPFZk5RdJsiwED,knTyjJ0sGIzuwbxRae
EAVanJj1ers2GQud,ELfMeDTIFhJt685K,EF2tvxZHz5n4UruPhaViXKycI6SQR=LHX65I9nkx0PstgcVY24uSi,n6sfYuHBlVdzgmvpXwR3irON0KIj8,YJxaX0MQOHb8oyCBFdnIAe
KhUG1NV9bln5zXjptqFW6dgo,cWbkR6iUZsnJQj14,maUl7SPesynF1j=EF2tvxZHz5n4UruPhaViXKycI6SQR,ELfMeDTIFhJt685K,EAVanJj1ers2GQud
from RYAntumr2i import *
HDLtdMAy7wPkl8aKC3O2 = CDwSWB4v39N7(u"ࠩࡌࡒࡎ࡚ࠧᐍ")
OfjUxo1dAFI8sW3vgCBGKQpln,iZxORybeI9JdWz12UDo83,QoRGCXVL75edKg8fTvn,xxis9daWFhUtROZ8u,kALyrFT6KPNGI7Oiup82Qb4JCq0td,zmL397efNlks5uTEV,kRpe8NqTm3zH5MGX6,nObHm3uEzJ,GoC84Eq3azJwpSWxkctF1MdTruOIyb = aBgObvuP24e187(yLjouMD5TmVK7bO0de48BPSGh)
AiIrQVMOWUwhRpHfjBnT = int(xxis9daWFhUtROZ8u)
hH0ROgc56krbdaXBEUy4 = FpGenVlw4Tzxi2WY3JuXcb.getInfoLabel(LHX65I9nkx0PstgcVY24uSi(u"ࠪࡐ࡮ࡹࡴࡊࡶࡨࡱ࠳ࡒࡡࡣࡧ࡯ࠫᐎ"))
hH0ROgc56krbdaXBEUy4 = hH0ROgc56krbdaXBEUy4.replace(VVGyhkOBo2P4mDXE5CuJYr1UNZSF,HQmDERMFjx).replace(XDZkwEaf97,HQmDERMFjx)
if AiIrQVMOWUwhRpHfjBnT==KKi79PFqsYB0dWSRgaJ3DyE(u"࠵࠺࠵ᐸ"): OAvmU4h2gGxYapze1sDLPuyEqjS = k4IUieraScH9DV1N7pJgQosYAx5l(u"ࠫࠥࠦࠠࡗࡧࡵࡷ࡮ࡵ࡮࠻ࠢ࡞ࠤࠬᐏ")+sWordmy7qXJvLgOGTl+dBi72erQEtKDOwjNFaoAgSP(u"ࠬࠦ࡝ࠡࠢࠣࡏࡴࡪࡩ࠻ࠢ࡞ࠤࠬᐐ")+yyoUA4lLTYIrtX1EmdVBnjPRZv+HDpmv4UXzlf72SK9(u"࠭ࠠ࡞ࠩᐑ")
else:
	pAR4LUa83r0sKdmcN5CYE = xx9LK4VzpF6IHXSEyhmrQwbg25P0(yLjouMD5TmVK7bO0de48BPSGh).replace(ao3Q5jP8H0sMxK2iUYwZGE,HQmDERMFjx).replace(s7d549VgeP,HQmDERMFjx)
	pAR4LUa83r0sKdmcN5CYE = pAR4LUa83r0sKdmcN5CYE.replace(cjqzOQ5GXD4kR,HQmDERMFjx).strip(oQpxmKiRPlHeGsLXNrJF78O)
	pAR4LUa83r0sKdmcN5CYE = pAR4LUa83r0sKdmcN5CYE.replace(pVzyOequnZtI,oQpxmKiRPlHeGsLXNrJF78O).replace(xoZHpTRUzS9,oQpxmKiRPlHeGsLXNrJF78O).replace(MSnXBQNUg1jF3W2fRlE9OLaCT8ds4,oQpxmKiRPlHeGsLXNrJF78O)
	if A0aqj9uclgOtByJ6F4bz(u"ࠧࠧࡷࡵࡰࡂ࠭ᐒ") in pAR4LUa83r0sKdmcN5CYE:
		pAR4LUa83r0sKdmcN5CYE,VAHJTgDLBIk9lPvt70iZzq2 = pAR4LUa83r0sKdmcN5CYE.rsplit(HDpmv4UXzlf72SK9(u"ࠨࠨࡸࡶࡱࡃࠧᐓ"),U0VwOviFaYPz2QGs45mJhMXf7Zk(u"࠵ᐹ"))
		pAR4LUa83r0sKdmcN5CYE += ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"ࠩࠩࡹࡷࡲ࠽ࠨᐔ")+AcNyrXQp0PFv(VAHJTgDLBIk9lPvt70iZzq2,HDLtdMAy7wPkl8aKC3O2)
	OAvmU4h2gGxYapze1sDLPuyEqjS = A0aqj9uclgOtByJ6F4bz(u"ࠪࠤࠥࠦࡌࡢࡤࡨࡰ࠿࡛ࠦࠡࠩᐕ")+hH0ROgc56krbdaXBEUy4+A0aqj9uclgOtByJ6F4bz(u"ࠫࠥࡣࠠࠡࠢࡐࡳࡩ࡫࠺ࠡ࡝ࠣࠫᐖ")+xxis9daWFhUtROZ8u+OzU6t0qcH7MQabeBYK8vgoG(u"ࠬࠦ࡝ࠡࠢࠣࡔࡦࡺࡨ࠻ࠢ࡞ࠤࠬᐗ")+pAR4LUa83r0sKdmcN5CYE+nz8x32hX0qcjUPFZk5RdJsiwED(u"࠭ࠠ࡞ࠩᐘ")
b7OTyKg6zUR2kfdDSH3AIx = OzU6t0qcH7MQabeBYK8vgoG(u"ࠧ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠧᐙ")
vv8DyVrLOPAXFIMZ9h(RRWFdpe04EK1Qn,b7OTyKg6zUR2kfdDSH3AIx+ti3SbXNV0aJ7n5Grc4OQY8Ll1s9+LLe5QGmjCZigv(HDLtdMAy7wPkl8aKC3O2)+OAvmU4h2gGxYapze1sDLPuyEqjS)
if C3ZK1pu4rfmj8TsWUtBaM(u"ࠨࡡࠪᐚ") in nObHm3uEzJ: M4LROWp8NX7DZx5VvuKiS,X1SKuyMI2WY04JGVafb = nObHm3uEzJ.split(maUl7SPesynF1j(u"ࠩࡢࠫᐛ"),CH7RKuDVzN9f06q8MtXPhlvIxakEWg)
else: M4LROWp8NX7DZx5VvuKiS,X1SKuyMI2WY04JGVafb = nObHm3uEzJ,HQmDERMFjx
N7zAKniRGkIEcQ0YMLHDyUm1ljv = HQmDERMFjx
if M4LROWp8NX7DZx5VvuKiS in [nz8x32hX0qcjUPFZk5RdJsiwED(u"ࠪ࠵ࠬᐜ"),PPAUFrY8cduRT(u"ࠫ࠷࠭ᐝ"),ELfMeDTIFhJt685K(u"ࠬ࠹ࠧᐞ"),dBi72erQEtKDOwjNFaoAgSP(u"࠭࠴ࠨᐟ"),Tcf5Ppn9UajDbzyM(u"ࠧ࠶ࠩᐠ"),KhUG1NV9bln5zXjptqFW6dgo(u"ࠨ࠳࠴ࠫᐡ"),cWbkR6iUZsnJQj14(u"ࠩ࠴࠶ࠬᐢ"),LHX65I9nkx0PstgcVY24uSi(u"ࠪ࠵࠸࠭ᐣ")] and (nz8x32hX0qcjUPFZk5RdJsiwED(u"ࠫࡆࡊࡄࠨᐤ") in X1SKuyMI2WY04JGVafb or KhUG1NV9bln5zXjptqFW6dgo(u"ࠬࡘࡅࡎࡑ࡙ࡉࠬᐥ") in X1SKuyMI2WY04JGVafb or YJxaX0MQOHb8oyCBFdnIAe(u"࠭ࡕࡑࠩᐦ") in X1SKuyMI2WY04JGVafb or owbMhINBQsmx70guApW(u"ࠧࡅࡑ࡚ࡒࠬᐧ") in X1SKuyMI2WY04JGVafb):
	Jzthpc2nj5.JotSelVcQp7bNqgKxvOZ46fThWA8 = gyd2rf0UR5
	Jzthpc2nj5.resolveonly = gyd2rf0UR5
	ii5wgOLeYKFrm9hCAp8fEvD4JZ3t1 = mic3MEN709xOkrjD5ZvbGIlX6
	from rcATPhMH4w import QMkNqYJ7cta0Khv218OAfWVPwdR
	QMkNqYJ7cta0Khv218OAfWVPwdR(nObHm3uEzJ,M4LROWp8NX7DZx5VvuKiS,X1SKuyMI2WY04JGVafb)
	H8jfvMtXa7Neiu.setSetting(ELfMeDTIFhJt685K(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡷ࡫ࡦࡳࡧࡶ࡬ࠬᐨ"),yLjouMD5TmVK7bO0de48BPSGh)
elif not M4LROWp8NX7DZx5VvuKiS and not RA02XBHf6hVdPkMlrDQ and AiIrQVMOWUwhRpHfjBnT in [X2crmy67eZpkGTRd(u"࠷࠹࠵ᐺ"),owbMhINBQsmx70guApW(u"࠽࠱࠶ᐻ")]:
	Jzthpc2nj5.JotSelVcQp7bNqgKxvOZ46fThWA8 = mic3MEN709xOkrjD5ZvbGIlX6
	Jzthpc2nj5.resolveonly = gyd2rf0UR5
	ii5wgOLeYKFrm9hCAp8fEvD4JZ3t1 = gyd2rf0UR5
	fyJ27mwDtuZgzKXG6jbE = str(GoC84Eq3azJwpSWxkctF1MdTruOIyb[jL1E5AKfwBDv6xmeQtUXcJ3d(u"ࠩࡩࡳࡱࡪࡥࡳࠩᐩ")])
	HDLtdMAy7wPkl8aKC3O2 = CDwSWB4v39N7(u"ࠪࡍࡕ࡚ࡖࠨᐪ") if AiIrQVMOWUwhRpHfjBnT==cWbkR6iUZsnJQj14(u"࠲࠴࠷ᐼ") else mgLADoQ1pbtY(u"ࠫࡒ࠹ࡕࠨᐫ")
	SSMFbAXN3xopCDPZ8kauW = HDLtdMAy7wPkl8aKC3O2.lower()
	c0SzxdJ6Mbw9BsLm5O = H8jfvMtXa7Neiu.getSetting(LHX65I9nkx0PstgcVY24uSi(u"ࠬࡧࡶ࠯ࠩᐬ")+SSMFbAXN3xopCDPZ8kauW+KKi79PFqsYB0dWSRgaJ3DyE(u"࠭࠮ࡶࡵࡨࡶࡦ࡭ࡥ࡯ࡶࡢࠫᐭ")+fyJ27mwDtuZgzKXG6jbE)
	dKm1UGJ6eWQ3ita2gYSsf7Np = H8jfvMtXa7Neiu.getSetting(ELfMeDTIFhJt685K(u"ࠧࡢࡸ࠱ࠫᐮ")+SSMFbAXN3xopCDPZ8kauW+Tcf5Ppn9UajDbzyM(u"ࠨ࠰ࡵࡩ࡫࡫ࡲࡦࡴࡢࠫᐯ")+fyJ27mwDtuZgzKXG6jbE)
	if c0SzxdJ6Mbw9BsLm5O or dKm1UGJ6eWQ3ita2gYSsf7Np:
		QoRGCXVL75edKg8fTvn += Tcf5Ppn9UajDbzyM(u"ࠩࡿࠫᐰ")
		if c0SzxdJ6Mbw9BsLm5O: QoRGCXVL75edKg8fTvn += YJxaX0MQOHb8oyCBFdnIAe(u"࡚ࠪࠪࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴ࠾ࠩᐱ")+c0SzxdJ6Mbw9BsLm5O
		if dKm1UGJ6eWQ3ita2gYSsf7Np: QoRGCXVL75edKg8fTvn += U0VwOviFaYPz2QGs45mJhMXf7Zk(u"ࠫࠫࡘࡥࡧࡧࡵࡩࡷࡃࠧᐲ")+dKm1UGJ6eWQ3ita2gYSsf7Np
		QoRGCXVL75edKg8fTvn = QoRGCXVL75edKg8fTvn.replace(Tcf5Ppn9UajDbzyM(u"ࠬࢂࠦࠨᐳ"),jL1E5AKfwBDv6xmeQtUXcJ3d(u"࠭ࡼࠨᐴ"))
	RMHLkWcntSqz9T2UOZpXPJ = H8jfvMtXa7Neiu.getSetting(mg3CbXMA2ouZzQDhRqB(u"ࠧࡢࡸ࠱ࠫᐵ")+SSMFbAXN3xopCDPZ8kauW+dBi72erQEtKDOwjNFaoAgSP(u"ࠨ࠰ࡶࡩࡷࡼࡥࡳࡡࠪᐶ")+fyJ27mwDtuZgzKXG6jbE)
	if RMHLkWcntSqz9T2UOZpXPJ:
		P0ZTgHnf72FaWjAB6IMuJ3ephbzim = DyVGS3dX0ZxR.findall(maUl7SPesynF1j(u"ࠩ࠽࠳࠴࠮࠮ࠫࡁࠬ࠳ࠬᐷ"),QoRGCXVL75edKg8fTvn,DyVGS3dX0ZxR.DOTALL)
		QoRGCXVL75edKg8fTvn = QoRGCXVL75edKg8fTvn.replace(P0ZTgHnf72FaWjAB6IMuJ3ephbzim[o4bNzIQGYj8En],RMHLkWcntSqz9T2UOZpXPJ)
	uZVS3DcJbEULoxpve9IOTgmW6(QoRGCXVL75edKg8fTvn,HDLtdMAy7wPkl8aKC3O2,OfjUxo1dAFI8sW3vgCBGKQpln)
else:
	Jzthpc2nj5.JotSelVcQp7bNqgKxvOZ46fThWA8 = mic3MEN709xOkrjD5ZvbGIlX6
	Jzthpc2nj5.resolveonly = mic3MEN709xOkrjD5ZvbGIlX6
	ii5wgOLeYKFrm9hCAp8fEvD4JZ3t1 = mic3MEN709xOkrjD5ZvbGIlX6
	import FF68kA5BUy
	try: FF68kA5BUy.xYKykP7dbh4o5OS6QXCl(OfjUxo1dAFI8sW3vgCBGKQpln,iZxORybeI9JdWz12UDo83,QoRGCXVL75edKg8fTvn,xxis9daWFhUtROZ8u,kALyrFT6KPNGI7Oiup82Qb4JCq0td,zmL397efNlks5uTEV,kRpe8NqTm3zH5MGX6,nObHm3uEzJ,GoC84Eq3azJwpSWxkctF1MdTruOIyb,AiIrQVMOWUwhRpHfjBnT,M4LROWp8NX7DZx5VvuKiS,X1SKuyMI2WY04JGVafb,hH0ROgc56krbdaXBEUy4)
	except Exception as DD1A7ZuHGQbNvF4U9gMCm6la082yPI: N7zAKniRGkIEcQ0YMLHDyUm1ljv = rHhWGdFfUiJz2sw4MN8aVpe.format_exc()
H5fhTBMIudv4Zy(Jzthpc2nj5.JotSelVcQp7bNqgKxvOZ46fThWA8,N7zAKniRGkIEcQ0YMLHDyUm1ljv,ii5wgOLeYKFrm9hCAp8fEvD4JZ3t1)
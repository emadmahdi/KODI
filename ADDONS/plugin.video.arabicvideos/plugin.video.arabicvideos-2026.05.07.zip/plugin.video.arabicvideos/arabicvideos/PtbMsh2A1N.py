# -*- coding: utf-8 -*-
from FF68kA5BUy import *
HDLtdMAy7wPkl8aKC3O2 = 'SHOOFPRO'
EEJvXQzSZNt = '_SHP_'
e2VR8nohduY = Jzthpc2nj5.SITESURLS[HDLtdMAy7wPkl8aKC3O2][0]
FwhZ0nXtpoHTMarf = ['مصارعة','بث مباشر']
def kk6X5LxpsND(mode,url,text):
	if   mode==480: zLZUkrP7ac5 = afkxo7FyZWB4O6K1eXrs5I()
	elif mode==481: zLZUkrP7ac5 = c8wfGju4CWZm(url,text)
	elif mode==482: zLZUkrP7ac5 = f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url)
	elif mode==483: zLZUkrP7ac5 = XONC9osGSP4fW5HVrhM(url,text)
	elif mode==489: zLZUkrP7ac5 = hm4kawIPKp3oMrC75dJZA9HS2(text,url)
	else: zLZUkrP7ac5 = False
	return zLZUkrP7ac5
def afkxo7FyZWB4O6K1eXrs5I():
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',e2VR8nohduY,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'SHOOFPRO-MENU-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	EFDgdaV4WT6U2yotAPX1B = DyVGS3dX0ZxR.findall('href="(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	EFDgdaV4WT6U2yotAPX1B = EFDgdaV4WT6U2yotAPX1B[0].strip(xufJqQcGnhboiVy2wd)
	EFDgdaV4WT6U2yotAPX1B = DpClq35GVjh(EFDgdaV4WT6U2yotAPX1B,'url')
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'بحث في الموقع',EFDgdaV4WT6U2yotAPX1B,489,HQmDERMFjx,HQmDERMFjx,'_REMEMBERRESULTS_')
	CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+'أحدث المواضيع',EFDgdaV4WT6U2yotAPX1B,481)
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"navigation"(.*?)"myAccount"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	items = DyVGS3dX0ZxR.findall('href="(.*?)".*?</span>(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	for vn1grP3y4It9GmVuBbLJfz2A,title in items:
		if vn1grP3y4It9GmVuBbLJfz2A=='#': continue
		if title in FwhZ0nXtpoHTMarf: continue
		title = SVsiEWeRf6oIynqQx8pCrM4Tk(title)
		CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,481)
	return CzNPJydxQLfw27tv4ZF8KORAbX5
def c8wfGju4CWZm(url,Cfg8ZADBKh5iJuLdm9vN):
	items = []
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'SHOOFPRO-TITLES-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"post(.*?)"footer"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if not Ut7reR0XioMjOdYWZKsLIuc3TQJmC1: return
	MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	items = DyVGS3dX0ZxR.findall('href="([^"]*)" title="([^"]*)".*?image:url\((.*?)\)',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	ORMkTYjJ1p7 = []
	smLQwgO0BynVCcl3fYJ = ['مشاهدة','فيلم','اغنية','أغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	yX0i4pcqKPW1 = xufJqQcGnhboiVy2wd.join(Cfg8ZADBKh5iJuLdm9vN.strip(xufJqQcGnhboiVy2wd).split(xufJqQcGnhboiVy2wd)[4:]).split('-')
	for vn1grP3y4It9GmVuBbLJfz2A,title,uIGD4vZcP61QNmw78LXqoEpH in items:
		title = SVsiEWeRf6oIynqQx8pCrM4Tk(title)
		yTz8SOkAhu24j6apo9BmZHvwWsX = DyVGS3dX0ZxR.findall('(.*?) حلقة \d+',title,DyVGS3dX0ZxR.DOTALL)
		if Cfg8ZADBKh5iJuLdm9vN:
			cjfepMobZyFTuwq7WS1EV945L3g = xufJqQcGnhboiVy2wd.join(vn1grP3y4It9GmVuBbLJfz2A.strip(xufJqQcGnhboiVy2wd).split(xufJqQcGnhboiVy2wd)[4:]).split('-')
			uXv71wlm8bN6i2EGxrsABFMQ = len([tfDSQhVJorIjuY3L0s1NMynTGcqzd for tfDSQhVJorIjuY3L0s1NMynTGcqzd in yX0i4pcqKPW1 if tfDSQhVJorIjuY3L0s1NMynTGcqzd in cjfepMobZyFTuwq7WS1EV945L3g])
			if uXv71wlm8bN6i2EGxrsABFMQ>2 and '/episodes/' in vn1grP3y4It9GmVuBbLJfz2A:
				CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,482,uIGD4vZcP61QNmw78LXqoEpH)
		else:
			if not yTz8SOkAhu24j6apo9BmZHvwWsX: yTz8SOkAhu24j6apo9BmZHvwWsX = DyVGS3dX0ZxR.findall('(.*?) الحلقة \d+',title,DyVGS3dX0ZxR.DOTALL)
			if set(title.split()) & set(smLQwgO0BynVCcl3fYJ) and 'مسلسل' not in title:
				CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,482,uIGD4vZcP61QNmw78LXqoEpH)
			elif yTz8SOkAhu24j6apo9BmZHvwWsX and 'حلقة' in title:
				title = '_MOD_' + yTz8SOkAhu24j6apo9BmZHvwWsX[0]
				if title not in ORMkTYjJ1p7:
					CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,483,uIGD4vZcP61QNmw78LXqoEpH,HQmDERMFjx,url)
					ORMkTYjJ1p7.append(title)
			else: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,483,uIGD4vZcP61QNmw78LXqoEpH,HQmDERMFjx,url)
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall("'pagination'(.*?)</div>",CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall("href='(.*?)'.*?>(.*?)</a>",MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,title in items:
			title = SVsiEWeRf6oIynqQx8pCrM4Tk(title)
			title = title.replace('الصفحة ',HQmDERMFjx)
			if title!=HQmDERMFjx: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'صفحة '+title,vn1grP3y4It9GmVuBbLJfz2A,481,HQmDERMFjx,HQmDERMFjx,Cfg8ZADBKh5iJuLdm9vN)
	return
def XONC9osGSP4fW5HVrhM(url,SSHjMN4uegZfb2):
	headers = {'X-Requested-With':'XMLHttpRequest'}
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,headers,HQmDERMFjx,HQmDERMFjx,'SHOOFPRO-EPISODES-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	EFDgdaV4WT6U2yotAPX1B = DpClq35GVjh(url,'url')
	uIGD4vZcP61QNmw78LXqoEpH = DyVGS3dX0ZxR.findall('"img-responsive" src="(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if uIGD4vZcP61QNmw78LXqoEpH: uIGD4vZcP61QNmw78LXqoEpH = uIGD4vZcP61QNmw78LXqoEpH[0]
	else: uIGD4vZcP61QNmw78LXqoEpH = FpGenVlw4Tzxi2WY3JuXcb.getInfoLabel('ListItem.Thumb')
	jfbzU6BCxkSN = True
	cOUkMZagDQftHLBoCivP = DyVGS3dX0ZxR.findall('"listSeasons(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if cOUkMZagDQftHLBoCivP and '/ajax/seasons' not in url:
		MJ2gSPyTl9hzoi1 = cOUkMZagDQftHLBoCivP[0]
		count = MJ2gSPyTl9hzoi1.count('data-slug=')
		if count==0: count = MJ2gSPyTl9hzoi1.count('data-season=')
		if count>1:
			jfbzU6BCxkSN = False
			if 'data-slug="' in MJ2gSPyTl9hzoi1:
				items = DyVGS3dX0ZxR.findall('data-slug="(.*?)">(.*?)</li>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
				for id,title in items:
					vn1grP3y4It9GmVuBbLJfz2A = EFDgdaV4WT6U2yotAPX1B+'/wp-content/themes/vo2021/temp/ajax/seasons2.php?slug='+id
					CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,483,uIGD4vZcP61QNmw78LXqoEpH)
			else:
				items = DyVGS3dX0ZxR.findall('data-season="(.*?)">(.*?)</li>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
				for id,title in items:
					vn1grP3y4It9GmVuBbLJfz2A = EFDgdaV4WT6U2yotAPX1B+'/wp-content/themes/vo2021/temp/ajax/seasons.php?seriesID='+id
					CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,483,uIGD4vZcP61QNmw78LXqoEpH)
	if jfbzU6BCxkSN:
		MJ2gSPyTl9hzoi1 = HQmDERMFjx
		if '/ajax/seasons' in url: MJ2gSPyTl9hzoi1 = CzNPJydxQLfw27tv4ZF8KORAbX5
		else:
			vuylTosVej845YfDNK = DyVGS3dX0ZxR.findall('"eplist"(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
			if vuylTosVej845YfDNK: MJ2gSPyTl9hzoi1 = vuylTosVej845YfDNK[0]
		items = DyVGS3dX0ZxR.findall('href="([^"]*)" title="([^"]*)"',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		if items:
			for vn1grP3y4It9GmVuBbLJfz2A,title in items:
				title = title.strip(oQpxmKiRPlHeGsLXNrJF78O)
				CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,482,uIGD4vZcP61QNmw78LXqoEpH)
	if not Jzthpc2nj5.menuItemsLIST: c8wfGju4CWZm(SSHjMN4uegZfb2,url)
	return
def f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url):
	SSHjMN4uegZfb2 = url.strip(xufJqQcGnhboiVy2wd)+'/?do=watch'
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',SSHjMN4uegZfb2,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'SHOOFPRO-PLAY-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	Na8vklCpUGYIzP0bjutWOT = []
	EFDgdaV4WT6U2yotAPX1B = DpClq35GVjh(url,'url')
	EcqoRFnue9Cw1aX5WNtVO2QMJh = DyVGS3dX0ZxR.findall('vo_postID = "(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if not EcqoRFnue9Cw1aX5WNtVO2QMJh: EcqoRFnue9Cw1aX5WNtVO2QMJh = DyVGS3dX0ZxR.findall('\(this\.id\,0\,(.*?)\)',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	EcqoRFnue9Cw1aX5WNtVO2QMJh = EcqoRFnue9Cw1aX5WNtVO2QMJh[0]
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"serversList"(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('id="(.*?)".*?">(.*?)</li>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for t0FuXyhb1ZsLM4UfKkHIJP2Orwm,title in items:
			title = title.strip(oQpxmKiRPlHeGsLXNrJF78O)
			vn1grP3y4It9GmVuBbLJfz2A = EFDgdaV4WT6U2yotAPX1B+'/wp-content/themes/vo2021/temp/ajax/iframe2.php?id='+EcqoRFnue9Cw1aX5WNtVO2QMJh+'&video='+t0FuXyhb1ZsLM4UfKkHIJP2Orwm[2:]+'?named='+title+'__watch'
			Na8vklCpUGYIzP0bjutWOT.append(vn1grP3y4It9GmVuBbLJfz2A)
	vn1grP3y4It9GmVuBbLJfz2A = DyVGS3dX0ZxR.findall('"getEmbed".*?src="(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if vn1grP3y4It9GmVuBbLJfz2A:
		title = DpClq35GVjh(vn1grP3y4It9GmVuBbLJfz2A[0],'url')
		vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A[0]+'?named='+title+'__embed'
		Na8vklCpUGYIzP0bjutWOT.append(vn1grP3y4It9GmVuBbLJfz2A)
	SSHjMN4uegZfb2 = url.strip(xufJqQcGnhboiVy2wd)+'/?do=download'
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',SSHjMN4uegZfb2,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'SHOOFPRO-PLAY-2nd')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"table-responsive"(.*?)</table>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('<td>(.*?)</td>.*?href="(.*?)"',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for title,vn1grP3y4It9GmVuBbLJfz2A in items:
			title = title.strip(oQpxmKiRPlHeGsLXNrJF78O)
			if 'anavidz' in vn1grP3y4It9GmVuBbLJfz2A: eyLMq9Enup0jiJT42RDWafg = '__خاص'
			else: eyLMq9Enup0jiJT42RDWafg = HQmDERMFjx
			vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A+'?named='+title+'__download'+eyLMq9Enup0jiJT42RDWafg
			Na8vklCpUGYIzP0bjutWOT.append(vn1grP3y4It9GmVuBbLJfz2A)
	import NsD5AomUqH
	NsD5AomUqH.NZcWGBmgFEen5hvJjUSIzOCVk7(Na8vklCpUGYIzP0bjutWOT,HDLtdMAy7wPkl8aKC3O2,'video',url)
	return
def hm4kawIPKp3oMrC75dJZA9HS2(search,EFDgdaV4WT6U2yotAPX1B=HQmDERMFjx):
	search,GXVabd4sc2u3zp0JI,showDialogs = x0pzMENwy84tBcZvXr(search)
	if search==HQmDERMFjx: search = q156m84QoYrn()
	if search==HQmDERMFjx: return
	search = search.replace(oQpxmKiRPlHeGsLXNrJF78O,'+')
	if EFDgdaV4WT6U2yotAPX1B==HQmDERMFjx: EFDgdaV4WT6U2yotAPX1B = e2VR8nohduY
	url = EFDgdaV4WT6U2yotAPX1B+'/search/'+search+xufJqQcGnhboiVy2wd
	c8wfGju4CWZm(url,HQmDERMFjx)
	return
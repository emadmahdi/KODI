# -*- coding: utf-8 -*-
from FF68kA5BUy import *
HDLtdMAy7wPkl8aKC3O2 = 'YOUTUBE'
EEJvXQzSZNt = '_YUT_'
e2VR8nohduY = Jzthpc2nj5.SITESURLS[HDLtdMAy7wPkl8aKC3O2][0]
KBCjVRUznh0ZNevy4s2 = 0
def kk6X5LxpsND(mode,url,text,type,zmL397efNlks5uTEV,name,kALyrFT6KPNGI7Oiup82Qb4JCq0td):
	if	 mode==140: zLZUkrP7ac5 = afkxo7FyZWB4O6K1eXrs5I()
	elif mode==141: zLZUkrP7ac5 = ddmQSWCePunTh0g3YKVR7E1AGfFLNO(url,name,kALyrFT6KPNGI7Oiup82Qb4JCq0td)
	elif mode==143: zLZUkrP7ac5 = f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url,type)
	elif mode==144: zLZUkrP7ac5 = c8wfGju4CWZm(url,zmL397efNlks5uTEV,text)
	elif mode==145: zLZUkrP7ac5 = JJ0VkCsdI9fZuy23nhMrpHiaqeYU(url,zmL397efNlks5uTEV)
	elif mode==147: zLZUkrP7ac5 = cvdbM0YFPs42xkVESRUHmjhTWGozw6()
	elif mode==148: zLZUkrP7ac5 = QgUXdl8C6TjEIbhSD4GtJiBAR()
	elif mode==149: zLZUkrP7ac5 = hm4kawIPKp3oMrC75dJZA9HS2(text)
	else: zLZUkrP7ac5 = False
	return zLZUkrP7ac5
def afkxo7FyZWB4O6K1eXrs5I():
	if 0:
		CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'قائمة 1',e2VR8nohduY+'/playlist?list=PLDJPKWWTSFaaGNjpDcPUsWZJVePmAYk_E&pp=iAQB',144)
		CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'قائمة 2',e2VR8nohduY+'/playlist?list=PLAj5Gs8FH8ZnUbF0RV-7G3BoqIyZA4uSA',144)
		CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'شخص',e2VR8nohduY+'/user/TCNofficial',144)
		CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'موقع',e2VR8nohduY+'/channel/UCq59aGNsq9bbhwVTq1Utvgw',144)
		CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'حساب',e2VR8nohduY+'/@TheSocialCTV',144)
		CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'العاب',e2VR8nohduY+'/gaming',144)
		CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'افلام',e2VR8nohduY+'/feed/storefront',144)
		CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'مختارات',e2VR8nohduY+'/feed/guide_builder',144)
		CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'قصيرة',e2VR8nohduY+'/shorts',144,HQmDERMFjx,HQmDERMFjx,'_REMEMBERRESULTS_')
		CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'تصفح',e2VR8nohduY+'/youtubei/v1/guide?key=',144)
		CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'رئيسية',e2VR8nohduY+HQmDERMFjx,144)
		CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'رائج',e2VR8nohduY+'/feed/trending?bp=',144)
		CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'بحث في الموقع',HQmDERMFjx,149,HQmDERMFjx,HQmDERMFjx,'_REMEMBERRESULTS_')
	CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'الرائجة',e2VR8nohduY+'/feed/trending',144)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'التصفح',e2VR8nohduY+'/youtubei/v1/guide?key=',144)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'القصيرة',e2VR8nohduY+'/shorts',144,HQmDERMFjx,HQmDERMFjx,'_REMEMBERRESULTS_')
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'مختارات يوتيوب',e2VR8nohduY+'/feed/guide_builder',144)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'مختارات البرنامج',HQmDERMFjx,290)
	CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'بحث: قنوات عربية',HQmDERMFjx,147)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'بحث: قنوات أجنبية',HQmDERMFjx,148)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'بحث: افلام عربية',e2VR8nohduY+'/results?search_query=فيلم',144)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'بحث: افلام اجنبية',e2VR8nohduY+'/results?search_query=movie',144)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'بحث: مسرحيات عربية',e2VR8nohduY+'/results?search_query=مسرحية',144)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'بحث: مسلسلات عربية',e2VR8nohduY+'/results?search_query=مسلسل&sp=EgIQAw==',144)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'بحث: مسلسلات اجنبية',e2VR8nohduY+'/results?search_query=series&sp=EgIQAw==',144)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'بحث: مسلسلات كارتون',e2VR8nohduY+'/results?search_query=كارتون&sp=EgIQAw==',144)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'بحث: خطبة المرجعية',e2VR8nohduY+'/results?search_query=قناة+كربلاء+الفضائية+خطبة+الجمعة&sp=CAISAhAB',144)
	return
def ddmQSWCePunTh0g3YKVR7E1AGfFLNO(url,name,kALyrFT6KPNGI7Oiup82Qb4JCq0td):
	name = AvwfgxLTUERB13jI4FbckPyHu(name)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'CHNL:  '+name,url,144,kALyrFT6KPNGI7Oiup82Qb4JCq0td)
	return
def cvdbM0YFPs42xkVESRUHmjhTWGozw6():
	c8wfGju4CWZm(e2VR8nohduY+'/results?search_query=قناة+بث&sp=EgJAAQ==')
	return
def QgUXdl8C6TjEIbhSD4GtJiBAR():
	c8wfGju4CWZm(e2VR8nohduY+'/results?search_query=tv&sp=EgJAAQ==')
	return
def f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url,type):
	url = url.split('&',1)[0]
	import NsD5AomUqH
	NsD5AomUqH.NZcWGBmgFEen5hvJjUSIzOCVk7([url],HDLtdMAy7wPkl8aKC3O2,type,url)
	return
def b5bFEsBfxO8AiIoSM(Zpy5kOxWRSFXi1gqE,url,bbiEfNgaGDK3tOSoAe0uZy4B):
	level,igSkBl59X2TtNujKca6E3ReLMY,BHimS9I0p2WqUxX6yzVedR8nQPo1,KKBdaScu6lUM2 = bbiEfNgaGDK3tOSoAe0uZy4B.split('::')
	ddq0mue3khpUWsQj1YawZlX,pTN21DIEthc0Wbiolx = [],[]
	if '/youtubei/v1/browse' in url: ddq0mue3khpUWsQj1YawZlX.append("yccc['onResponseReceivedActions']")
	if '/youtubei/v1/search' in url: ddq0mue3khpUWsQj1YawZlX.append("yccc['onResponseReceivedCommands']")
	ddq0mue3khpUWsQj1YawZlX.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs'][0]['tabRenderer']['content']['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['playlistVideoListRenderer']['contents']")
	if level=='1': ddq0mue3khpUWsQj1YawZlX.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs'][0]['tabRenderer']['content']['richGridRenderer']['header']['feedFilterChipBarRenderer']['contents']")
	ddq0mue3khpUWsQj1YawZlX.append("yccc['contents']['twoColumnWatchNextResults']['playlist']['playlist']['contents']")
	ddq0mue3khpUWsQj1YawZlX.append("yccc['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['contents']")
	ddq0mue3khpUWsQj1YawZlX.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs']")
	ddq0mue3khpUWsQj1YawZlX.append("yccc['entries']")
	ddq0mue3khpUWsQj1YawZlX.append("yccc['items'][3]['guideSectionRenderer']['items']")
	vSQmi7q0L9tH6WVM1,q0O6u2SHh8eNdjn9fc,eqbEyncYoTzRD6pXK = PPsDJnQz42(Zpy5kOxWRSFXi1gqE,HQmDERMFjx,ddq0mue3khpUWsQj1YawZlX)
	if level=='1' and vSQmi7q0L9tH6WVM1:
		if len(q0O6u2SHh8eNdjn9fc)>1 and 'search_query' not in url:
			for PnXzwkd2vNcG1iV in range(len(q0O6u2SHh8eNdjn9fc)):
				igSkBl59X2TtNujKca6E3ReLMY = str(PnXzwkd2vNcG1iV)
				ddq0mue3khpUWsQj1YawZlX = []
				ddq0mue3khpUWsQj1YawZlX.append("yddd["+igSkBl59X2TtNujKca6E3ReLMY+"]['reloadContinuationItemsCommand']['continuationItems']")
				ddq0mue3khpUWsQj1YawZlX.append("yddd["+igSkBl59X2TtNujKca6E3ReLMY+"]['command']")
				ddq0mue3khpUWsQj1YawZlX.append("yddd["+igSkBl59X2TtNujKca6E3ReLMY+"]")
				HH2hLvGCD3zfk,A07BpVeRJToLb,mR2QPcrA3wqT5lONxtunW9J0bj8 = PPsDJnQz42(q0O6u2SHh8eNdjn9fc,HQmDERMFjx,ddq0mue3khpUWsQj1YawZlX)
				if HH2hLvGCD3zfk: pTN21DIEthc0Wbiolx.append([A07BpVeRJToLb,url,'2::'+igSkBl59X2TtNujKca6E3ReLMY+'::0::0'])
			ddq0mue3khpUWsQj1YawZlX.append("yccc['continuationEndpoint']")
			HH2hLvGCD3zfk,A07BpVeRJToLb,mR2QPcrA3wqT5lONxtunW9J0bj8 = PPsDJnQz42(Zpy5kOxWRSFXi1gqE,HQmDERMFjx,ddq0mue3khpUWsQj1YawZlX)
			if HH2hLvGCD3zfk and pTN21DIEthc0Wbiolx and 'continuationCommand' in list(A07BpVeRJToLb.keys()):
				vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+'/my_main_page_shorts_link'
				pTN21DIEthc0Wbiolx.append([A07BpVeRJToLb,vn1grP3y4It9GmVuBbLJfz2A,'1::0::0::0'])
	return q0O6u2SHh8eNdjn9fc,vSQmi7q0L9tH6WVM1,pTN21DIEthc0Wbiolx,eqbEyncYoTzRD6pXK
def ZziQSMbmjx7WqRKOUoI5Jw6NnPt4f0(Zpy5kOxWRSFXi1gqE,q0O6u2SHh8eNdjn9fc,url,bbiEfNgaGDK3tOSoAe0uZy4B):
	level,igSkBl59X2TtNujKca6E3ReLMY,BHimS9I0p2WqUxX6yzVedR8nQPo1,KKBdaScu6lUM2 = bbiEfNgaGDK3tOSoAe0uZy4B.split('::')
	ddq0mue3khpUWsQj1YawZlX,qgjzLvA4yUPawpYiOSQF = [],[]
	ddq0mue3khpUWsQj1YawZlX.append("yddd[0]['itemSectionRenderer']['contents']")
	ddq0mue3khpUWsQj1YawZlX.append("yddd["+igSkBl59X2TtNujKca6E3ReLMY+"]['reloadContinuationItemsCommand']['continuationItems']")
	ddq0mue3khpUWsQj1YawZlX.append("yddd[1]['reloadContinuationItemsCommand']['continuationItems']")
	if '/youtubei/v1/browse' in url: ddq0mue3khpUWsQj1YawZlX.append("yddd[0]['appendContinuationItemsAction']['continuationItems']")
	elif '/youtubei/v1/search' in url: ddq0mue3khpUWsQj1YawZlX.append("yddd[0]['appendContinuationItemsAction']['continuationItems'][0]['itemSectionRenderer']['contents']")
	ddq0mue3khpUWsQj1YawZlX.append("yddd["+igSkBl59X2TtNujKca6E3ReLMY+"]['tabRenderer']['content']['sectionListRenderer']['contents']")
	if '/videos' in url or ('/shorts' in url and '/shorts/' not in url):
		ddq0mue3khpUWsQj1YawZlX.append("yddd["+igSkBl59X2TtNujKca6E3ReLMY+"]['tabRenderer']['content']['richGridRenderer']['header']['feedFilterChipBarRenderer']['contents']")
	ddq0mue3khpUWsQj1YawZlX.append("yddd["+igSkBl59X2TtNujKca6E3ReLMY+"]['tabRenderer']['content']['richGridRenderer']['contents']")
	ddq0mue3khpUWsQj1YawZlX.append("yddd["+igSkBl59X2TtNujKca6E3ReLMY+"]['expandableTabRenderer']['content']['sectionListRenderer']['contents']")
	ddq0mue3khpUWsQj1YawZlX.append("yddd["+igSkBl59X2TtNujKca6E3ReLMY+"]['richSectionRenderer']['content']['richShelfRenderer']['contents']")
	ddq0mue3khpUWsQj1YawZlX.append("yddd["+igSkBl59X2TtNujKca6E3ReLMY+"]")
	ySwGE1mjVgZPou3bLvhJ4DnF6flMX,G8l9jgJdVt,HHfbsAOuIv2xpckEgyCSNlZ = PPsDJnQz42(q0O6u2SHh8eNdjn9fc,HQmDERMFjx,ddq0mue3khpUWsQj1YawZlX)
	if level=='2' and ySwGE1mjVgZPou3bLvhJ4DnF6flMX:
		if len(G8l9jgJdVt)>1:
			for PnXzwkd2vNcG1iV in range(len(G8l9jgJdVt)):
				BHimS9I0p2WqUxX6yzVedR8nQPo1 = str(PnXzwkd2vNcG1iV)
				ddq0mue3khpUWsQj1YawZlX = []
				ddq0mue3khpUWsQj1YawZlX.append("yeee["+BHimS9I0p2WqUxX6yzVedR8nQPo1+"]['richSectionRenderer']['content']")
				ddq0mue3khpUWsQj1YawZlX.append("yeee["+BHimS9I0p2WqUxX6yzVedR8nQPo1+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['header']")
				ddq0mue3khpUWsQj1YawZlX.append("yeee["+BHimS9I0p2WqUxX6yzVedR8nQPo1+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
				ddq0mue3khpUWsQj1YawZlX.append("yeee["+BHimS9I0p2WqUxX6yzVedR8nQPo1+"]['itemSectionRenderer']['contents'][0]")
				ddq0mue3khpUWsQj1YawZlX.append("yeee["+BHimS9I0p2WqUxX6yzVedR8nQPo1+"]['richItemRenderer']['content']")
				ddq0mue3khpUWsQj1YawZlX.append("yeee["+BHimS9I0p2WqUxX6yzVedR8nQPo1+"]")
				HH2hLvGCD3zfk,A07BpVeRJToLb,mR2QPcrA3wqT5lONxtunW9J0bj8 = PPsDJnQz42(G8l9jgJdVt,HQmDERMFjx,ddq0mue3khpUWsQj1YawZlX)
				if HH2hLvGCD3zfk: qgjzLvA4yUPawpYiOSQF.append([A07BpVeRJToLb,url,'3::'+igSkBl59X2TtNujKca6E3ReLMY+'::'+BHimS9I0p2WqUxX6yzVedR8nQPo1+'::0'])
			ddq0mue3khpUWsQj1YawZlX.append("yddd[0]['appendContinuationItemsAction']['continuationItems'][1]")
			ddq0mue3khpUWsQj1YawZlX.append("yddd[1]")
			HH2hLvGCD3zfk,A07BpVeRJToLb,mR2QPcrA3wqT5lONxtunW9J0bj8 = PPsDJnQz42(q0O6u2SHh8eNdjn9fc,HQmDERMFjx,ddq0mue3khpUWsQj1YawZlX)
			if HH2hLvGCD3zfk and qgjzLvA4yUPawpYiOSQF and 'continuationItemRenderer' in list(A07BpVeRJToLb.keys()):
				qgjzLvA4yUPawpYiOSQF.append([A07BpVeRJToLb,url,'3::0::0::0'])
	return G8l9jgJdVt,ySwGE1mjVgZPou3bLvhJ4DnF6flMX,qgjzLvA4yUPawpYiOSQF,HHfbsAOuIv2xpckEgyCSNlZ
def JvaMVCkINy9Y1KS5Uox6huQHl7tc(Zpy5kOxWRSFXi1gqE,G8l9jgJdVt,url,bbiEfNgaGDK3tOSoAe0uZy4B):
	level,igSkBl59X2TtNujKca6E3ReLMY,BHimS9I0p2WqUxX6yzVedR8nQPo1,KKBdaScu6lUM2 = bbiEfNgaGDK3tOSoAe0uZy4B.split('::')
	ddq0mue3khpUWsQj1YawZlX,h9uC0EGZdmXsH5 = [],[]
	ddq0mue3khpUWsQj1YawZlX.append("yeee["+BHimS9I0p2WqUxX6yzVedR8nQPo1+"]['shelfRenderer']['content']['verticalListRenderer']['items']")
	ddq0mue3khpUWsQj1YawZlX.append("yeee["+BHimS9I0p2WqUxX6yzVedR8nQPo1+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalMovieListRenderer']['items']")
	ddq0mue3khpUWsQj1YawZlX.append("yeee["+BHimS9I0p2WqUxX6yzVedR8nQPo1+"]['itemSectionRenderer']['contents'][0]['reelShelfRenderer']['items']")
	ddq0mue3khpUWsQj1YawZlX.append("yeee["+BHimS9I0p2WqUxX6yzVedR8nQPo1+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	ddq0mue3khpUWsQj1YawZlX.append("yeee["+BHimS9I0p2WqUxX6yzVedR8nQPo1+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalListRenderer']['items']")
	ddq0mue3khpUWsQj1YawZlX.append("yeee["+BHimS9I0p2WqUxX6yzVedR8nQPo1+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['expandedShelfContentsRenderer']['items']")
	ddq0mue3khpUWsQj1YawZlX.append("yeee["+BHimS9I0p2WqUxX6yzVedR8nQPo1+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
	ddq0mue3khpUWsQj1YawZlX.append("yeee["+BHimS9I0p2WqUxX6yzVedR8nQPo1+"]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	ddq0mue3khpUWsQj1YawZlX.append("yeee[0]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	ddq0mue3khpUWsQj1YawZlX.append("yeee[0]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	ddq0mue3khpUWsQj1YawZlX.append("yeee[0]['itemSectionRenderer']['contents'][0]['playlistVideoListRenderer']['contents']")
	ddq0mue3khpUWsQj1YawZlX.append("yeee["+BHimS9I0p2WqUxX6yzVedR8nQPo1+"]['reelShelfRenderer']['items']")
	ddq0mue3khpUWsQj1YawZlX.append("yeee["+BHimS9I0p2WqUxX6yzVedR8nQPo1+"]['richSectionRenderer']['content']['richShelfRenderer']['contents']")
	ddq0mue3khpUWsQj1YawZlX.append("yeee")
	uQtlVM2Ky3nBrHhpGS5,Ut3FVHZymBM0KAo7jeI2bEv,O8sjHXg5vGnoFR = PPsDJnQz42(G8l9jgJdVt,HQmDERMFjx,ddq0mue3khpUWsQj1YawZlX)
	if level=='3' and uQtlVM2Ky3nBrHhpGS5:
		if len(Ut3FVHZymBM0KAo7jeI2bEv)>0:
			for PnXzwkd2vNcG1iV in range(len(Ut3FVHZymBM0KAo7jeI2bEv)):
				KKBdaScu6lUM2 = str(PnXzwkd2vNcG1iV)
				ddq0mue3khpUWsQj1YawZlX = []
				ddq0mue3khpUWsQj1YawZlX.append("yfff["+KKBdaScu6lUM2+"]['richItemRenderer']['content']")
				ddq0mue3khpUWsQj1YawZlX.append("yfff["+KKBdaScu6lUM2+"]['gameCardRenderer']['game']")
				ddq0mue3khpUWsQj1YawZlX.append("yfff["+KKBdaScu6lUM2+"]['itemSectionRenderer']['contents'][0]")
				ddq0mue3khpUWsQj1YawZlX.append("yfff["+KKBdaScu6lUM2+"]")
				ddq0mue3khpUWsQj1YawZlX.append("yfff")
				HH2hLvGCD3zfk,A07BpVeRJToLb,mR2QPcrA3wqT5lONxtunW9J0bj8 = PPsDJnQz42(Ut3FVHZymBM0KAo7jeI2bEv,HQmDERMFjx,ddq0mue3khpUWsQj1YawZlX)
				if HH2hLvGCD3zfk: h9uC0EGZdmXsH5.append([A07BpVeRJToLb,url,'4::'+igSkBl59X2TtNujKca6E3ReLMY+'::'+BHimS9I0p2WqUxX6yzVedR8nQPo1+'::'+KKBdaScu6lUM2])
	return Ut3FVHZymBM0KAo7jeI2bEv,uQtlVM2Ky3nBrHhpGS5,h9uC0EGZdmXsH5,O8sjHXg5vGnoFR
def PPsDJnQz42(kZIMuFGpqb,RiE7fCIjK2qADY51aJsQOcSmNtVHy,TOPel1H6jcEiVf7upaN4WzYwk):
	Zpy5kOxWRSFXi1gqE,RiE7fCIjK2qADY51aJsQOcSmNtVHy = kZIMuFGpqb,RiE7fCIjK2qADY51aJsQOcSmNtVHy
	q0O6u2SHh8eNdjn9fc,RiE7fCIjK2qADY51aJsQOcSmNtVHy = kZIMuFGpqb,RiE7fCIjK2qADY51aJsQOcSmNtVHy
	G8l9jgJdVt,RiE7fCIjK2qADY51aJsQOcSmNtVHy = kZIMuFGpqb,RiE7fCIjK2qADY51aJsQOcSmNtVHy
	Ut3FVHZymBM0KAo7jeI2bEv,RiE7fCIjK2qADY51aJsQOcSmNtVHy = kZIMuFGpqb,RiE7fCIjK2qADY51aJsQOcSmNtVHy
	A07BpVeRJToLb,i9yPNuwXRo0n1sEe5qp4 = kZIMuFGpqb,RiE7fCIjK2qADY51aJsQOcSmNtVHy
	count = len(TOPel1H6jcEiVf7upaN4WzYwk)
	for DvGaoUZE5S4wxfHc910sz in range(count):
		try:
			r8YAXPztOZ = eval(TOPel1H6jcEiVf7upaN4WzYwk[DvGaoUZE5S4wxfHc910sz])
			return True,r8YAXPztOZ,DvGaoUZE5S4wxfHc910sz+1
		except: pass
	return False,HQmDERMFjx,0
def c8wfGju4CWZm(url,bbiEfNgaGDK3tOSoAe0uZy4B=HQmDERMFjx,data=HQmDERMFjx):
	pTN21DIEthc0Wbiolx,qgjzLvA4yUPawpYiOSQF,h9uC0EGZdmXsH5 = [],[],[]
	if '::' not in bbiEfNgaGDK3tOSoAe0uZy4B: bbiEfNgaGDK3tOSoAe0uZy4B = '1::0::0::0'
	level,igSkBl59X2TtNujKca6E3ReLMY,BHimS9I0p2WqUxX6yzVedR8nQPo1,KKBdaScu6lUM2 = bbiEfNgaGDK3tOSoAe0uZy4B.split('::')
	if level=='4': level,igSkBl59X2TtNujKca6E3ReLMY,BHimS9I0p2WqUxX6yzVedR8nQPo1,KKBdaScu6lUM2 = '1',igSkBl59X2TtNujKca6E3ReLMY,BHimS9I0p2WqUxX6yzVedR8nQPo1,KKBdaScu6lUM2
	data = data.replace('_REMEMBERRESULTS_',HQmDERMFjx)
	CzNPJydxQLfw27tv4ZF8KORAbX5,Zpy5kOxWRSFXi1gqE,Vi9fwvbSBCI0K6hgXA8EpFrT = k1YIj6zhHPW(url,data)
	bbiEfNgaGDK3tOSoAe0uZy4B = level+'::'+igSkBl59X2TtNujKca6E3ReLMY+'::'+BHimS9I0p2WqUxX6yzVedR8nQPo1+'::'+KKBdaScu6lUM2
	if level in ['1','2','3']:
		q0O6u2SHh8eNdjn9fc,vSQmi7q0L9tH6WVM1,pTN21DIEthc0Wbiolx,eqbEyncYoTzRD6pXK = b5bFEsBfxO8AiIoSM(Zpy5kOxWRSFXi1gqE,url,bbiEfNgaGDK3tOSoAe0uZy4B)
		if not vSQmi7q0L9tH6WVM1: return
		a6E8WX2Hn0crdoY4VvfhQP = len(pTN21DIEthc0Wbiolx)
		if a6E8WX2Hn0crdoY4VvfhQP<2:
			if level=='1': level = '2'
			pTN21DIEthc0Wbiolx = []
	bbiEfNgaGDK3tOSoAe0uZy4B = level+'::'+igSkBl59X2TtNujKca6E3ReLMY+'::'+BHimS9I0p2WqUxX6yzVedR8nQPo1+'::'+KKBdaScu6lUM2
	if level in ['2','3']:
		G8l9jgJdVt,ySwGE1mjVgZPou3bLvhJ4DnF6flMX,qgjzLvA4yUPawpYiOSQF,HHfbsAOuIv2xpckEgyCSNlZ = ZziQSMbmjx7WqRKOUoI5Jw6NnPt4f0(Zpy5kOxWRSFXi1gqE,q0O6u2SHh8eNdjn9fc,url,bbiEfNgaGDK3tOSoAe0uZy4B)
		if not ySwGE1mjVgZPou3bLvhJ4DnF6flMX: return
		oDemyqGKAY8InVr4lji = len(qgjzLvA4yUPawpYiOSQF)
		if oDemyqGKAY8InVr4lji<2:
			if level=='2': level = '3'
			qgjzLvA4yUPawpYiOSQF = []
	bbiEfNgaGDK3tOSoAe0uZy4B = level+'::'+igSkBl59X2TtNujKca6E3ReLMY+'::'+BHimS9I0p2WqUxX6yzVedR8nQPo1+'::'+KKBdaScu6lUM2
	if level in ['3']:
		Ut3FVHZymBM0KAo7jeI2bEv,uQtlVM2Ky3nBrHhpGS5,h9uC0EGZdmXsH5,O8sjHXg5vGnoFR = JvaMVCkINy9Y1KS5Uox6huQHl7tc(Zpy5kOxWRSFXi1gqE,G8l9jgJdVt,url,bbiEfNgaGDK3tOSoAe0uZy4B)
		if not uQtlVM2Ky3nBrHhpGS5: return
		BhHXjVQoKGpIzkiRYFdSrtPbm = len(h9uC0EGZdmXsH5)
	for A07BpVeRJToLb,url,bbiEfNgaGDK3tOSoAe0uZy4B in pTN21DIEthc0Wbiolx+qgjzLvA4yUPawpYiOSQF+h9uC0EGZdmXsH5:
		EPJnGfmr9p6wZ5WaL4XtdHjkUi = t3s8U7MWKIuZJHfAQd45wXyB(A07BpVeRJToLb,url,bbiEfNgaGDK3tOSoAe0uZy4B)
	return
def t3s8U7MWKIuZJHfAQd45wXyB(A07BpVeRJToLb,url=HQmDERMFjx,bbiEfNgaGDK3tOSoAe0uZy4B=HQmDERMFjx):
	if '::' in bbiEfNgaGDK3tOSoAe0uZy4B: level,igSkBl59X2TtNujKca6E3ReLMY,BHimS9I0p2WqUxX6yzVedR8nQPo1,KKBdaScu6lUM2 = bbiEfNgaGDK3tOSoAe0uZy4B.split('::')
	else: level,igSkBl59X2TtNujKca6E3ReLMY,BHimS9I0p2WqUxX6yzVedR8nQPo1,KKBdaScu6lUM2 = '1','0','0','0'
	HH2hLvGCD3zfk,title,vn1grP3y4It9GmVuBbLJfz2A,uIGD4vZcP61QNmw78LXqoEpH,count,OMDCpSL7ZB,K6ogPIV5c4eY8,oMNwgEb0JpKWmrdx9zC1faLZI27cFX,dSk54Cpt3ZIbaxNroYG = OOBWoZ0h9tRkwjyYS8xeKqzna(A07BpVeRJToLb)
	BBa7whHUFpPfs6u = '/videos?' in vn1grP3y4It9GmVuBbLJfz2A or '/streams?' in vn1grP3y4It9GmVuBbLJfz2A or '/playlists?' in vn1grP3y4It9GmVuBbLJfz2A
	ulaybBsTmxd = '/channels?' in vn1grP3y4It9GmVuBbLJfz2A or '/shorts?' in vn1grP3y4It9GmVuBbLJfz2A
	if BBa7whHUFpPfs6u or ulaybBsTmxd: vn1grP3y4It9GmVuBbLJfz2A = url
	BBa7whHUFpPfs6u = 'watch?v=' not in vn1grP3y4It9GmVuBbLJfz2A and '/playlist?list=' not in vn1grP3y4It9GmVuBbLJfz2A
	ulaybBsTmxd = '/gaming' not in vn1grP3y4It9GmVuBbLJfz2A  and '/feed/storefront' not in vn1grP3y4It9GmVuBbLJfz2A
	if bbiEfNgaGDK3tOSoAe0uZy4B[0:5]=='3::0::' and BBa7whHUFpPfs6u and ulaybBsTmxd: vn1grP3y4It9GmVuBbLJfz2A = url
	if '/youtubei/v1/guide?key=' in url or '/gaming' in vn1grP3y4It9GmVuBbLJfz2A:
		level,igSkBl59X2TtNujKca6E3ReLMY,BHimS9I0p2WqUxX6yzVedR8nQPo1,KKBdaScu6lUM2 = '1','0','0','0'
		bbiEfNgaGDK3tOSoAe0uZy4B = HQmDERMFjx
	Vi9fwvbSBCI0K6hgXA8EpFrT = HQmDERMFjx
	if '/youtubei/v1/browse' in vn1grP3y4It9GmVuBbLJfz2A or '/youtubei/v1/search' in vn1grP3y4It9GmVuBbLJfz2A or '/my_main_page_shorts_link' in url:
		data = H8jfvMtXa7Neiu.getSetting('av.youtube.data')
		if data.count(':::')==4:
			PgGJQ6Se9yTxzk,key,ttPJjyxTQXnWh6uYpDi,GNXbM0VRxEAdpwaZ81Di,WjA5SoTH673rqsB4lp0FNQyZe = data.split(':::')
			Vi9fwvbSBCI0K6hgXA8EpFrT = PgGJQ6Se9yTxzk+':::'+key+':::'+ttPJjyxTQXnWh6uYpDi+':::'+GNXbM0VRxEAdpwaZ81Di+':::'+dSk54Cpt3ZIbaxNroYG
			if '/my_main_page_shorts_link' in url and not vn1grP3y4It9GmVuBbLJfz2A: vn1grP3y4It9GmVuBbLJfz2A = url
			else: vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A+'?key='+key
	if not title:
		global KBCjVRUznh0ZNevy4s2
		KBCjVRUznh0ZNevy4s2 += 1
		title = 'فيديوهات '+str(KBCjVRUznh0ZNevy4s2)
		bbiEfNgaGDK3tOSoAe0uZy4B = '3'+'::'+igSkBl59X2TtNujKca6E3ReLMY+'::'+BHimS9I0p2WqUxX6yzVedR8nQPo1+'::'+KKBdaScu6lUM2
	if not HH2hLvGCD3zfk: return False
	elif 'searchPyvRenderer' in str(A07BpVeRJToLb): return False
	elif '/about' in vn1grP3y4It9GmVuBbLJfz2A: return False
	elif '/community' in vn1grP3y4It9GmVuBbLJfz2A: return False
	elif 'continuationItemRenderer' in list(A07BpVeRJToLb.keys()) or 'continuationCommand' in list(A07BpVeRJToLb.keys()):
		if int(level)>1: level = str(int(level)-1)
		bbiEfNgaGDK3tOSoAe0uZy4B = level+'::'+igSkBl59X2TtNujKca6E3ReLMY+'::'+BHimS9I0p2WqUxX6yzVedR8nQPo1+'::'+KKBdaScu6lUM2
		CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+':: '+'صفحة أخرى',vn1grP3y4It9GmVuBbLJfz2A,144,uIGD4vZcP61QNmw78LXqoEpH,bbiEfNgaGDK3tOSoAe0uZy4B,Vi9fwvbSBCI0K6hgXA8EpFrT)
	elif '/search' in vn1grP3y4It9GmVuBbLJfz2A:
		title = ':: '+title
		bbiEfNgaGDK3tOSoAe0uZy4B = '3'+'::'+igSkBl59X2TtNujKca6E3ReLMY+'::'+BHimS9I0p2WqUxX6yzVedR8nQPo1+'::'+KKBdaScu6lUM2
		url = url.replace('/search',HQmDERMFjx)
		CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,url,145,HQmDERMFjx,bbiEfNgaGDK3tOSoAe0uZy4B,'_REMEMBERRESULTS_')
	elif 'search_query' in url and not vn1grP3y4It9GmVuBbLJfz2A:
		bbiEfNgaGDK3tOSoAe0uZy4B = '3'+'::'+igSkBl59X2TtNujKca6E3ReLMY+'::'+BHimS9I0p2WqUxX6yzVedR8nQPo1+'::'+KKBdaScu6lUM2
		title = ':: '+title
		CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,url,144,uIGD4vZcP61QNmw78LXqoEpH,bbiEfNgaGDK3tOSoAe0uZy4B,Vi9fwvbSBCI0K6hgXA8EpFrT)
	elif '/browse' in vn1grP3y4It9GmVuBbLJfz2A and url==e2VR8nohduY:
		title = ':: '+title
		bbiEfNgaGDK3tOSoAe0uZy4B = '2::0::0::0'
		CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,144,uIGD4vZcP61QNmw78LXqoEpH,bbiEfNgaGDK3tOSoAe0uZy4B,Vi9fwvbSBCI0K6hgXA8EpFrT)
	elif not vn1grP3y4It9GmVuBbLJfz2A and 'horizontalMovieListRenderer' in str(A07BpVeRJToLb):
		title = ':: '+title
		bbiEfNgaGDK3tOSoAe0uZy4B = '3::0::0::0'
		CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,url,144,uIGD4vZcP61QNmw78LXqoEpH,bbiEfNgaGDK3tOSoAe0uZy4B)
	elif 'messageRenderer' in str(A07BpVeRJToLb):
		CfgK4s13Q0hZcHyleT2bVJO9('link',EEJvXQzSZNt+title,HQmDERMFjx,9999)
	elif K6ogPIV5c4eY8:
		CfgK4s13Q0hZcHyleT2bVJO9('live',EEJvXQzSZNt+K6ogPIV5c4eY8+title,vn1grP3y4It9GmVuBbLJfz2A,143,uIGD4vZcP61QNmw78LXqoEpH)
	elif '/playlist?list=' in vn1grP3y4It9GmVuBbLJfz2A:
		vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A.replace('&playnext=1',HQmDERMFjx)
		CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'LIST'+count+':  '+title,vn1grP3y4It9GmVuBbLJfz2A,144,uIGD4vZcP61QNmw78LXqoEpH,bbiEfNgaGDK3tOSoAe0uZy4B)
	elif '/shorts/' in vn1grP3y4It9GmVuBbLJfz2A:
		vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A.split('&list=',1)[0]
		CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,143,uIGD4vZcP61QNmw78LXqoEpH,OMDCpSL7ZB)
	elif '/watch?v=' in vn1grP3y4It9GmVuBbLJfz2A:
		if '&list=' in vn1grP3y4It9GmVuBbLJfz2A and count:
			xemolQhWXG1PdsNIViHD = vn1grP3y4It9GmVuBbLJfz2A.split('&list=',1)[1]
			vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+'/playlist?list='+xemolQhWXG1PdsNIViHD
			bbiEfNgaGDK3tOSoAe0uZy4B = '1::0::0::0'
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'LIST'+count+':  '+title,vn1grP3y4It9GmVuBbLJfz2A,144,uIGD4vZcP61QNmw78LXqoEpH,bbiEfNgaGDK3tOSoAe0uZy4B)
		else:
			vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A.split('&list=',1)[0]
			CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,143,uIGD4vZcP61QNmw78LXqoEpH,OMDCpSL7ZB)
	elif '/channel/' in vn1grP3y4It9GmVuBbLJfz2A or '/c/' in vn1grP3y4It9GmVuBbLJfz2A or ('/@' in vn1grP3y4It9GmVuBbLJfz2A and vn1grP3y4It9GmVuBbLJfz2A.count(xufJqQcGnhboiVy2wd)==3):
		if C6H1qXua3SMQiIrzxNvJWZE:
			title = title.decode(Zex6D4tJE52r).encode('raw_unicode_escape')
			title = ArwuTXMNsaO9fmjWdI(title)
		CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'CHNL'+count+':  '+title,vn1grP3y4It9GmVuBbLJfz2A,144,uIGD4vZcP61QNmw78LXqoEpH,bbiEfNgaGDK3tOSoAe0uZy4B)
	elif '/user/' in vn1grP3y4It9GmVuBbLJfz2A:
		CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'USER'+count+':  '+title,vn1grP3y4It9GmVuBbLJfz2A,144,uIGD4vZcP61QNmw78LXqoEpH,bbiEfNgaGDK3tOSoAe0uZy4B)
	else:
		if not vn1grP3y4It9GmVuBbLJfz2A: vn1grP3y4It9GmVuBbLJfz2A = url
		title = ':: '+title
		CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,144,uIGD4vZcP61QNmw78LXqoEpH,bbiEfNgaGDK3tOSoAe0uZy4B,Vi9fwvbSBCI0K6hgXA8EpFrT)
	return True
def OOBWoZ0h9tRkwjyYS8xeKqzna(A07BpVeRJToLb):
	HH2hLvGCD3zfk,title,vn1grP3y4It9GmVuBbLJfz2A,uIGD4vZcP61QNmw78LXqoEpH,count,OMDCpSL7ZB,K6ogPIV5c4eY8,oMNwgEb0JpKWmrdx9zC1faLZI27cFX,WjA5SoTH673rqsB4lp0FNQyZe = False,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx
	if not isinstance(A07BpVeRJToLb,dict): return HH2hLvGCD3zfk,title,vn1grP3y4It9GmVuBbLJfz2A,uIGD4vZcP61QNmw78LXqoEpH,count,OMDCpSL7ZB,K6ogPIV5c4eY8,oMNwgEb0JpKWmrdx9zC1faLZI27cFX,WjA5SoTH673rqsB4lp0FNQyZe
	for rykSYMmQ8Uof0JpxbPCKA in list(A07BpVeRJToLb.keys()):
		i9yPNuwXRo0n1sEe5qp4 = A07BpVeRJToLb[rykSYMmQ8Uof0JpxbPCKA]
		if isinstance(i9yPNuwXRo0n1sEe5qp4,dict): break
	ddq0mue3khpUWsQj1YawZlX = []
	ddq0mue3khpUWsQj1YawZlX.append("yrender['header']['playlistHeaderRenderer']['title']['simpleText']")
	ddq0mue3khpUWsQj1YawZlX.append("yrender['header']['richListHeaderRenderer']['title']['simpleText']")
	ddq0mue3khpUWsQj1YawZlX.append("yrender['header']['richListHeaderRenderer']['title']")
	ddq0mue3khpUWsQj1YawZlX.append("yrender['headline']['simpleText']")
	ddq0mue3khpUWsQj1YawZlX.append("yrender['unplayableText']['simpleText']")
	ddq0mue3khpUWsQj1YawZlX.append("yrender['formattedTitle']['simpleText']")
	ddq0mue3khpUWsQj1YawZlX.append("yrender['title']['simpleText']")
	ddq0mue3khpUWsQj1YawZlX.append("yrender['title']['runs'][0]['text']")
	ddq0mue3khpUWsQj1YawZlX.append("yrender['text']['simpleText']")
	ddq0mue3khpUWsQj1YawZlX.append("yrender['text']['runs'][0]['text']")
	ddq0mue3khpUWsQj1YawZlX.append("yrender['title']['content']")
	ddq0mue3khpUWsQj1YawZlX.append("yrender['title']")
	ddq0mue3khpUWsQj1YawZlX.append("item['title']")
	ddq0mue3khpUWsQj1YawZlX.append("item['reelWatchEndpoint']['videoId']")
	HH2hLvGCD3zfk,title,mR2QPcrA3wqT5lONxtunW9J0bj8 = PPsDJnQz42(A07BpVeRJToLb,i9yPNuwXRo0n1sEe5qp4,ddq0mue3khpUWsQj1YawZlX)
	ddq0mue3khpUWsQj1YawZlX = []
	ddq0mue3khpUWsQj1YawZlX.append("yrender['title']['runs'][0]['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	ddq0mue3khpUWsQj1YawZlX.append("yrender['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	ddq0mue3khpUWsQj1YawZlX.append("yrender['continuationEndpoint']['commandMetadata']['webCommandMetadata']['apiUrl']")
	ddq0mue3khpUWsQj1YawZlX.append("yrender['navigationEndpoint']['commandMetadata']['webCommandMetadata']['apiUrl']")
	ddq0mue3khpUWsQj1YawZlX.append("yrender['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	ddq0mue3khpUWsQj1YawZlX.append("item['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	ddq0mue3khpUWsQj1YawZlX.append("item['commandMetadata']['webCommandMetadata']['url']")
	HH2hLvGCD3zfk,vn1grP3y4It9GmVuBbLJfz2A,mR2QPcrA3wqT5lONxtunW9J0bj8 = PPsDJnQz42(A07BpVeRJToLb,i9yPNuwXRo0n1sEe5qp4,ddq0mue3khpUWsQj1YawZlX)
	ddq0mue3khpUWsQj1YawZlX = []
	ddq0mue3khpUWsQj1YawZlX.append("yrender['thumbnail']['thumbnails'][0]['url']")
	ddq0mue3khpUWsQj1YawZlX.append("yrender['thumbnails'][0]['thumbnails'][0]['url']")
	ddq0mue3khpUWsQj1YawZlX.append("item['reelWatchEndpoint']['thumbnail']['thumbnails'][0]['url']")
	HH2hLvGCD3zfk,uIGD4vZcP61QNmw78LXqoEpH,mR2QPcrA3wqT5lONxtunW9J0bj8 = PPsDJnQz42(A07BpVeRJToLb,i9yPNuwXRo0n1sEe5qp4,ddq0mue3khpUWsQj1YawZlX)
	ddq0mue3khpUWsQj1YawZlX = []
	ddq0mue3khpUWsQj1YawZlX.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayBottomPanelRenderer']['text']['runs'][0]['text']")
	ddq0mue3khpUWsQj1YawZlX.append("yrender['videoCountShortText']['simpleText']")
	ddq0mue3khpUWsQj1YawZlX.append("yrender['videoCountText']['runs'][0]['text']")
	ddq0mue3khpUWsQj1YawZlX.append("yrender['videoCount']")
	HH2hLvGCD3zfk,count,mR2QPcrA3wqT5lONxtunW9J0bj8 = PPsDJnQz42(A07BpVeRJToLb,i9yPNuwXRo0n1sEe5qp4,ddq0mue3khpUWsQj1YawZlX)
	ddq0mue3khpUWsQj1YawZlX = []
	ddq0mue3khpUWsQj1YawZlX.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['runs'][0]['text']")
	ddq0mue3khpUWsQj1YawZlX.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['simpleText']")
	ddq0mue3khpUWsQj1YawZlX.append("yrender['lengthText']['simpleText']")
	ddq0mue3khpUWsQj1YawZlX.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['icon']['iconType']")
	ddq0mue3khpUWsQj1YawZlX.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['style']")
	HH2hLvGCD3zfk,OMDCpSL7ZB,mR2QPcrA3wqT5lONxtunW9J0bj8 = PPsDJnQz42(A07BpVeRJToLb,i9yPNuwXRo0n1sEe5qp4,ddq0mue3khpUWsQj1YawZlX)
	ddq0mue3khpUWsQj1YawZlX = []
	ddq0mue3khpUWsQj1YawZlX.append("yrender['navigationEndpoint']['continuationCommand']['token']")
	ddq0mue3khpUWsQj1YawZlX.append("yrender['continuationEndpoint']['continuationCommand']['token']")
	HH2hLvGCD3zfk,WjA5SoTH673rqsB4lp0FNQyZe,mR2QPcrA3wqT5lONxtunW9J0bj8 = PPsDJnQz42(A07BpVeRJToLb,i9yPNuwXRo0n1sEe5qp4,ddq0mue3khpUWsQj1YawZlX)
	if 'LIVE' in OMDCpSL7ZB: OMDCpSL7ZB,K6ogPIV5c4eY8 = HQmDERMFjx,'LIVE:  '
	if 'مباشر' in OMDCpSL7ZB: OMDCpSL7ZB,K6ogPIV5c4eY8 = HQmDERMFjx,'LIVE:  '
	if 'badges' in list(i9yPNuwXRo0n1sEe5qp4.keys()):
		h2hpL7efrDGCQUn = str(i9yPNuwXRo0n1sEe5qp4['badges'])
		if 'Free with Ads' in h2hpL7efrDGCQUn: oMNwgEb0JpKWmrdx9zC1faLZI27cFX = '$:  '
		if 'LIVE' in h2hpL7efrDGCQUn: K6ogPIV5c4eY8 = 'LIVE:  '
		if 'Buy' in h2hpL7efrDGCQUn or 'Rent' in h2hpL7efrDGCQUn: oMNwgEb0JpKWmrdx9zC1faLZI27cFX = '$$:  '
		if DmOqnYKsWSbE1X9VMGQR4gvAUejPf(u'مباشر') in h2hpL7efrDGCQUn: K6ogPIV5c4eY8 = 'LIVE:  '
		if DmOqnYKsWSbE1X9VMGQR4gvAUejPf(u'شراء') in h2hpL7efrDGCQUn: oMNwgEb0JpKWmrdx9zC1faLZI27cFX = '$$:  '
		if DmOqnYKsWSbE1X9VMGQR4gvAUejPf(u'استئجار') in h2hpL7efrDGCQUn: oMNwgEb0JpKWmrdx9zC1faLZI27cFX = '$$:  '
		if DmOqnYKsWSbE1X9VMGQR4gvAUejPf(u'إعلانات') in h2hpL7efrDGCQUn: oMNwgEb0JpKWmrdx9zC1faLZI27cFX = '$:  '
	vn1grP3y4It9GmVuBbLJfz2A = ArwuTXMNsaO9fmjWdI(vn1grP3y4It9GmVuBbLJfz2A)
	if vn1grP3y4It9GmVuBbLJfz2A and 'http' not in vn1grP3y4It9GmVuBbLJfz2A: vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+vn1grP3y4It9GmVuBbLJfz2A
	uIGD4vZcP61QNmw78LXqoEpH = uIGD4vZcP61QNmw78LXqoEpH.split('?')[0]
	if  uIGD4vZcP61QNmw78LXqoEpH and 'http' not in uIGD4vZcP61QNmw78LXqoEpH: uIGD4vZcP61QNmw78LXqoEpH = 'https:'+uIGD4vZcP61QNmw78LXqoEpH
	title = ArwuTXMNsaO9fmjWdI(title)
	if oMNwgEb0JpKWmrdx9zC1faLZI27cFX: title = oMNwgEb0JpKWmrdx9zC1faLZI27cFX+title
	OMDCpSL7ZB = OMDCpSL7ZB.replace(',',HQmDERMFjx)
	count = count.replace(',',HQmDERMFjx)
	count = DyVGS3dX0ZxR.findall('\d+',count)
	if count: count = count[0]
	else: count = HQmDERMFjx
	return True,title,vn1grP3y4It9GmVuBbLJfz2A,uIGD4vZcP61QNmw78LXqoEpH,count,OMDCpSL7ZB,K6ogPIV5c4eY8,oMNwgEb0JpKWmrdx9zC1faLZI27cFX,WjA5SoTH673rqsB4lp0FNQyZe
def k1YIj6zhHPW(url,data=HQmDERMFjx,S46ZVrhN1gWY0Iiaj=HQmDERMFjx):
	if S46ZVrhN1gWY0Iiaj==HQmDERMFjx: S46ZVrhN1gWY0Iiaj = 'ytInitialData'
	c0SzxdJ6Mbw9BsLm5O = xK7D9yiBPEqvhmA8XIoJe()
	nJayb3s5zlOgQh9BwiCdEDq = {'User-Agent':c0SzxdJ6Mbw9BsLm5O,'Cookie':'PREF=hl=ar'}
	global H8jfvMtXa7Neiu
	if not data: data = H8jfvMtXa7Neiu.getSetting('av.youtube.data')
	if data.count(':::')==4: PgGJQ6Se9yTxzk,key,ttPJjyxTQXnWh6uYpDi,GNXbM0VRxEAdpwaZ81Di,WjA5SoTH673rqsB4lp0FNQyZe = data.split(':::')
	else: PgGJQ6Se9yTxzk,key,ttPJjyxTQXnWh6uYpDi,GNXbM0VRxEAdpwaZ81Di,WjA5SoTH673rqsB4lp0FNQyZe = HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx
	Vi9fwvbSBCI0K6hgXA8EpFrT = {"context":{"client":{"hl":"ar","clientName":"WEB","clientVersion":ttPJjyxTQXnWh6uYpDi}}}
	if url==e2VR8nohduY+'/shorts' or '/my_main_page_shorts_link' in url:
		url = e2VR8nohduY+'/youtubei/v1/reel/reel_watch_sequence'+'?key='+key
		Vi9fwvbSBCI0K6hgXA8EpFrT['sequenceParams'] = PgGJQ6Se9yTxzk
		Vi9fwvbSBCI0K6hgXA8EpFrT = str(Vi9fwvbSBCI0K6hgXA8EpFrT)
		vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(LLwINhcX2RHSWqpmEnz,'POST',url,Vi9fwvbSBCI0K6hgXA8EpFrT,nJayb3s5zlOgQh9BwiCdEDq,True,True,'YOUTUBE-GET_PAGE_DATA-1st')
	elif '/guide?key=' in url:
		url = e2VR8nohduY+'/youtubei/v1/guide?key='+key
		Vi9fwvbSBCI0K6hgXA8EpFrT = str(Vi9fwvbSBCI0K6hgXA8EpFrT)
		vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(LLwINhcX2RHSWqpmEnz,'POST',url,Vi9fwvbSBCI0K6hgXA8EpFrT,nJayb3s5zlOgQh9BwiCdEDq,True,True,'YOUTUBE-GET_PAGE_DATA-3rd')
	elif 'key=' in url and PgGJQ6Se9yTxzk:
		Vi9fwvbSBCI0K6hgXA8EpFrT['continuation'] = WjA5SoTH673rqsB4lp0FNQyZe
		Vi9fwvbSBCI0K6hgXA8EpFrT['context']['client']['visitorData'] = PgGJQ6Se9yTxzk
		Vi9fwvbSBCI0K6hgXA8EpFrT = str(Vi9fwvbSBCI0K6hgXA8EpFrT)
		vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(LLwINhcX2RHSWqpmEnz,'POST',url,Vi9fwvbSBCI0K6hgXA8EpFrT,nJayb3s5zlOgQh9BwiCdEDq,True,True,'YOUTUBE-GET_PAGE_DATA-4th')
	elif 'ctoken=' in url and GNXbM0VRxEAdpwaZ81Di:
		nJayb3s5zlOgQh9BwiCdEDq.update({'X-YouTube-Client-Name':'1','X-YouTube-Client-Version':ttPJjyxTQXnWh6uYpDi})
		nJayb3s5zlOgQh9BwiCdEDq.update({'Cookie':'VISITOR_INFO1_LIVE='+GNXbM0VRxEAdpwaZ81Di})
		vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(LLwINhcX2RHSWqpmEnz,'GET',url,HQmDERMFjx,nJayb3s5zlOgQh9BwiCdEDq,HQmDERMFjx,HQmDERMFjx,'YOUTUBE-GET_PAGE_DATA-5th')
	else:
		vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(LLwINhcX2RHSWqpmEnz,'GET',url,HQmDERMFjx,nJayb3s5zlOgQh9BwiCdEDq,HQmDERMFjx,HQmDERMFjx,'YOUTUBE-GET_PAGE_DATA-6th')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	ccmtSYej7D = DyVGS3dX0ZxR.findall('"innertubeApiKey".*?"(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL|DyVGS3dX0ZxR.I)
	if ccmtSYej7D: key = ccmtSYej7D[0]
	ccmtSYej7D = DyVGS3dX0ZxR.findall('"cver".*?"value".*?"(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL|DyVGS3dX0ZxR.I)
	if ccmtSYej7D: ttPJjyxTQXnWh6uYpDi = ccmtSYej7D[0]
	ccmtSYej7D = DyVGS3dX0ZxR.findall('"visitorData".*?"(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL|DyVGS3dX0ZxR.I)
	if ccmtSYej7D: PgGJQ6Se9yTxzk = ccmtSYej7D[0]
	cookies = vGXnw9VcUN.cookies
	if 'VISITOR_INFO1_LIVE' in list(cookies.keys()): GNXbM0VRxEAdpwaZ81Di = cookies['VISITOR_INFO1_LIVE']
	y4MTtLsPzU35SHa = PgGJQ6Se9yTxzk+':::'+key+':::'+ttPJjyxTQXnWh6uYpDi+':::'+GNXbM0VRxEAdpwaZ81Di+':::'+WjA5SoTH673rqsB4lp0FNQyZe
	if S46ZVrhN1gWY0Iiaj=='ytInitialData' and 'ytInitialData' in CzNPJydxQLfw27tv4ZF8KORAbX5:
		mKQ03bfOzYnv27NtRWwuexTori19 = DyVGS3dX0ZxR.findall('window\["ytInitialData"\] = ({.*?});',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if not mKQ03bfOzYnv27NtRWwuexTori19: mKQ03bfOzYnv27NtRWwuexTori19 = DyVGS3dX0ZxR.findall('var ytInitialData = ({.*?});',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		v5vfznkcSilZMVRpEB2mgqu1TCOFY = aknZqSJyUrFgc9VhH2Psot6e7b8('str',mKQ03bfOzYnv27NtRWwuexTori19[0])
	elif S46ZVrhN1gWY0Iiaj=='ytInitialGuideData' and 'ytInitialGuideData' in CzNPJydxQLfw27tv4ZF8KORAbX5:
		mKQ03bfOzYnv27NtRWwuexTori19 = DyVGS3dX0ZxR.findall('var ytInitialGuideData = ({.*?});',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		v5vfznkcSilZMVRpEB2mgqu1TCOFY = aknZqSJyUrFgc9VhH2Psot6e7b8('str',mKQ03bfOzYnv27NtRWwuexTori19[0])
	elif '</script>' not in CzNPJydxQLfw27tv4ZF8KORAbX5: v5vfznkcSilZMVRpEB2mgqu1TCOFY = aknZqSJyUrFgc9VhH2Psot6e7b8('str',CzNPJydxQLfw27tv4ZF8KORAbX5)
	else: v5vfznkcSilZMVRpEB2mgqu1TCOFY = HQmDERMFjx
	if 0:
		Zpy5kOxWRSFXi1gqE = str(v5vfznkcSilZMVRpEB2mgqu1TCOFY)
		if HH6mxXjgcrEN1aenMFWQkS: Zpy5kOxWRSFXi1gqE = Zpy5kOxWRSFXi1gqE.encode(Zex6D4tJE52r)
		open('S:\\0000emad.dat','wb').write(Zpy5kOxWRSFXi1gqE)
	H8jfvMtXa7Neiu.setSetting('av.youtube.data',y4MTtLsPzU35SHa)
	return CzNPJydxQLfw27tv4ZF8KORAbX5,v5vfznkcSilZMVRpEB2mgqu1TCOFY,y4MTtLsPzU35SHa
def JJ0VkCsdI9fZuy23nhMrpHiaqeYU(url,bbiEfNgaGDK3tOSoAe0uZy4B):
	search = q156m84QoYrn()
	if not search: return
	search = search.replace(oQpxmKiRPlHeGsLXNrJF78O,'+')
	SSHjMN4uegZfb2 = url+'/search?query='+search
	c8wfGju4CWZm(SSHjMN4uegZfb2,bbiEfNgaGDK3tOSoAe0uZy4B)
	return
def hm4kawIPKp3oMrC75dJZA9HS2(search):
	search,GXVabd4sc2u3zp0JI,showDialogs = x0pzMENwy84tBcZvXr(search)
	if not search:
		search = q156m84QoYrn()
		if not search: return
	search = search.replace(oQpxmKiRPlHeGsLXNrJF78O,'+')
	SSHjMN4uegZfb2 = e2VR8nohduY+'/results?search_query='+search
	if not showDialogs:
		if '_YOUTUBE-VIDEOS_' in GXVabd4sc2u3zp0JI: SqP2RtfQ9avy48glub0XThBWYe = '&sp=EgIQAQ%253D%253D'
		elif '_YOUTUBE-PLAYLISTS_' in GXVabd4sc2u3zp0JI: SqP2RtfQ9avy48glub0XThBWYe = '&sp=EgIQAw%253D%253D'
		elif '_YOUTUBE-CHANNELS_' in GXVabd4sc2u3zp0JI: SqP2RtfQ9avy48glub0XThBWYe = '&sp=EgIQAg%253D%253D'
		else: SqP2RtfQ9avy48glub0XThBWYe = HQmDERMFjx
		jDcWv7MAkEV = SSHjMN4uegZfb2+SqP2RtfQ9avy48glub0XThBWYe
	else:
		llPL2sNHDIm0QfSxYEZoB1q,DLC9eqWpdTVktgAzS7ZU6Q,eyLMq9Enup0jiJT42RDWafg = [],[],HQmDERMFjx
		qqnbWry51XJxj9LBMI0pTsAOuFPekZ = ['فيديوهات مرتبة بالصلة','فيديوهات مرتبة بالتاريخ','فيديوهات مرتبة بعدد المشاهدات','فيديوهات مرتبة بالتقييم','(جيد للمسلسلات) قوائم تشغيل','قنوات','بث حي']
		Ai1gUfnWBl2FuKL6 = ['&sp=CAASAhAB','&sp=CAISAhAB','&sp=CAMSAhAB','&sp=CAESAhAB','&sp=EgIQAw==','&sp=EgIQAg==','&sp=EgJAAQ==']
		THYfiPJzQF8Sxq = GGiSlWbqKDr5Ovkh2L7sHNTxz('اختر البحث المناسب',qqnbWry51XJxj9LBMI0pTsAOuFPekZ)
		if THYfiPJzQF8Sxq == -1: return
		qqxOwir70S1 = Ai1gUfnWBl2FuKL6[THYfiPJzQF8Sxq]
		CzNPJydxQLfw27tv4ZF8KORAbX5,C56g0LETXba91fKmovGlFs7kctIjA,data = k1YIj6zhHPW(SSHjMN4uegZfb2+qqxOwir70S1)
		if C56g0LETXba91fKmovGlFs7kctIjA:
			try:
				jkEvMTf1KmJRF = C56g0LETXba91fKmovGlFs7kctIjA['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['subMenu']['searchSubMenuRenderer']['groups']
				for QWXTfvEhsarOcyl5ZgVYNMF in range(len(jkEvMTf1KmJRF)):
					group = jkEvMTf1KmJRF[QWXTfvEhsarOcyl5ZgVYNMF]['searchFilterGroupRenderer']['filters']
					for oochiJpHI3FAU20DGMe in range(len(group)):
						i9yPNuwXRo0n1sEe5qp4 = group[oochiJpHI3FAU20DGMe]['searchFilterRenderer']
						if 'navigationEndpoint' in list(i9yPNuwXRo0n1sEe5qp4.keys()):
							vn1grP3y4It9GmVuBbLJfz2A = i9yPNuwXRo0n1sEe5qp4['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']
							vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A.replace('\u0026','&')
							title = i9yPNuwXRo0n1sEe5qp4['tooltip']
							title = title.replace('البحث عن ',HQmDERMFjx)
							if 'إزالة الفلتر' in title: continue
							if 'قائمة تشغيل' in title:
								title = 'جيد للمسلسلات '+title
								eyLMq9Enup0jiJT42RDWafg = title
								cjfepMobZyFTuwq7WS1EV945L3g = vn1grP3y4It9GmVuBbLJfz2A
							if 'ترتيب حسب' in title: continue
							title = title.replace('Search for ',HQmDERMFjx)
							if 'Remove' in title: continue
							if 'Playlist' in title:
								title = 'جيد للمسلسلات '+title
								eyLMq9Enup0jiJT42RDWafg = title
								cjfepMobZyFTuwq7WS1EV945L3g = vn1grP3y4It9GmVuBbLJfz2A
							if 'Sort by' in title: continue
							llPL2sNHDIm0QfSxYEZoB1q.append(ArwuTXMNsaO9fmjWdI(title))
							DLC9eqWpdTVktgAzS7ZU6Q.append(vn1grP3y4It9GmVuBbLJfz2A)
			except: pass
		if not eyLMq9Enup0jiJT42RDWafg: c6FEUb0Rpmxuv5CilrQ4o = HQmDERMFjx
		else:
			llPL2sNHDIm0QfSxYEZoB1q = ['بدون فلتر',eyLMq9Enup0jiJT42RDWafg]+llPL2sNHDIm0QfSxYEZoB1q
			DLC9eqWpdTVktgAzS7ZU6Q = [HQmDERMFjx,cjfepMobZyFTuwq7WS1EV945L3g]+DLC9eqWpdTVktgAzS7ZU6Q
			yIPcqvexOf29VAKl1Gr = GGiSlWbqKDr5Ovkh2L7sHNTxz('موقع يوتيوب - اختر الفلتر',llPL2sNHDIm0QfSxYEZoB1q)
			if yIPcqvexOf29VAKl1Gr == -1: return
			c6FEUb0Rpmxuv5CilrQ4o = DLC9eqWpdTVktgAzS7ZU6Q[yIPcqvexOf29VAKl1Gr]
		if c6FEUb0Rpmxuv5CilrQ4o: jDcWv7MAkEV = e2VR8nohduY+c6FEUb0Rpmxuv5CilrQ4o
		elif qqxOwir70S1: jDcWv7MAkEV = SSHjMN4uegZfb2+qqxOwir70S1
		else: jDcWv7MAkEV = SSHjMN4uegZfb2
	c8wfGju4CWZm(jDcWv7MAkEV)
	return
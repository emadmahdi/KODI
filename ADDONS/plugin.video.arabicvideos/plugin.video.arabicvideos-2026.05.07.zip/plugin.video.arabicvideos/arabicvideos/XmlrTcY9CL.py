# -*- coding: utf-8 -*-
from FF68kA5BUy import *
HDLtdMAy7wPkl8aKC3O2 = 'ALKAWTHAR'
EEJvXQzSZNt = '_KWT_'
e2VR8nohduY = Jzthpc2nj5.SITESURLS[HDLtdMAy7wPkl8aKC3O2][0]
def kk6X5LxpsND(mode,url,zmL397efNlks5uTEV,text):
	if   mode==130: zLZUkrP7ac5 = afkxo7FyZWB4O6K1eXrs5I()
	elif mode==131: zLZUkrP7ac5 = c8wfGju4CWZm(url)
	elif mode==132: zLZUkrP7ac5 = ZFEjC6KpI78XPWd9TueM(url)
	elif mode==133: zLZUkrP7ac5 = XONC9osGSP4fW5HVrhM(url,zmL397efNlks5uTEV)
	elif mode==134: zLZUkrP7ac5 = f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url)
	elif mode==135: zLZUkrP7ac5 = eY4DutR9cHF()
	elif mode==139: zLZUkrP7ac5 = hm4kawIPKp3oMrC75dJZA9HS2(text,url)
	else: zLZUkrP7ac5 = False
	return zLZUkrP7ac5
def afkxo7FyZWB4O6K1eXrs5I():
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'بحث في الموقع',HQmDERMFjx,139,HQmDERMFjx,HQmDERMFjx,'_REMEMBERRESULTS_')
	CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	CzNPJydxQLfw27tv4ZF8KORAbX5 = D0GFPwY8ecAVI(j9uzmBeEyK8,e2VR8nohduY,HQmDERMFjx,HQmDERMFjx,True,'ALKAWTHAR-MENU-1st')
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1=DyVGS3dX0ZxR.findall('dropdown-menu(.*?)dropdown-toggle',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[1]
	items=DyVGS3dX0ZxR.findall('href="(.*?)">(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	for vn1grP3y4It9GmVuBbLJfz2A,title in items:
		if '/conductor' in vn1grP3y4It9GmVuBbLJfz2A: continue
		title = title.strip(oQpxmKiRPlHeGsLXNrJF78O)
		url = e2VR8nohduY+vn1grP3y4It9GmVuBbLJfz2A
		if '/category/' in url: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,url,132)
		else: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,url,131)
	CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+'المسلسلات',e2VR8nohduY+'/category/543',132,HQmDERMFjx,'1')
	CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+'الأفلام',e2VR8nohduY+'/category/628',132,HQmDERMFjx,'1')
	CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+'برامج الصغار والشباب',e2VR8nohduY+'/category/517',132,HQmDERMFjx,'1')
	CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+'ابرز البرامج',e2VR8nohduY+'/category/1763',132,HQmDERMFjx,'1')
	CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+'المحاضرات',e2VR8nohduY+'/category/943',132,HQmDERMFjx,'1')
	CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+'عاشوراء',e2VR8nohduY+'/category/1353',132,HQmDERMFjx,'1')
	CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+'البرامج الاجتماعية',e2VR8nohduY+'/category/501',132,HQmDERMFjx,'1')
	CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+'البرامج الدينية',e2VR8nohduY+'/category/509',132,HQmDERMFjx,'1')
	CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+'البرامج الوثائقية',e2VR8nohduY+'/category/553',132,HQmDERMFjx,'1')
	CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+'البرامج السياسية',e2VR8nohduY+'/category/545',132,HQmDERMFjx,'1')
	CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+'كتب',e2VR8nohduY+'/category/291',132,HQmDERMFjx,'1')
	CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+'تعلم الفارسية',e2VR8nohduY+'/category/88',132,HQmDERMFjx,'1')
	CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+'أرشيف البرامج',e2VR8nohduY+'/category/1279',132,HQmDERMFjx,'1')
	return
def c8wfGju4CWZm(url):
	y9yPjDA2ITf71lxuFNSLgBHmcoR = ['/religious','/social','/political','/films','/series']
	CzNPJydxQLfw27tv4ZF8KORAbX5 = D0GFPwY8ecAVI(j9uzmBeEyK8,url,HQmDERMFjx,HQmDERMFjx,True,'ALKAWTHAR-TITLES-1st')
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('titlebar(.*?)titlebar',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	if any(value in url for value in y9yPjDA2ITf71lxuFNSLgBHmcoR):
		items = DyVGS3dX0ZxR.findall("src='(.*?)'.*?href='(.*?)'.*?>(.*?)<",MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for uIGD4vZcP61QNmw78LXqoEpH,vn1grP3y4It9GmVuBbLJfz2A,title in items:
			title = title.strip(oQpxmKiRPlHeGsLXNrJF78O)
			vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY + vn1grP3y4It9GmVuBbLJfz2A
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,133,uIGD4vZcP61QNmw78LXqoEpH,'1')
	elif '/docs' in url:
		items = DyVGS3dX0ZxR.findall("src='(.*?)'.*?<h2>(.*?)</h2>.*?href='(.*?)'",MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for uIGD4vZcP61QNmw78LXqoEpH,title,vn1grP3y4It9GmVuBbLJfz2A in items:
			title = title.strip(oQpxmKiRPlHeGsLXNrJF78O)
			vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY + vn1grP3y4It9GmVuBbLJfz2A
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,133,uIGD4vZcP61QNmw78LXqoEpH,'1')
	return
def ZFEjC6KpI78XPWd9TueM(url):
	WF2vkePC5gbXAGUarcqlpmB3Q = url.split(xufJqQcGnhboiVy2wd)[-1]
	CzNPJydxQLfw27tv4ZF8KORAbX5 = D0GFPwY8ecAVI(H5x4Z2qPwR8vXM,url,HQmDERMFjx,HQmDERMFjx,True,'ALKAWTHAR-CATEGORIES-1st')
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('parentcat(.*?)</div>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if not Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		XONC9osGSP4fW5HVrhM(url,'1')
		return
	MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	items = DyVGS3dX0ZxR.findall("href='(.*?)'.*?>(.*?)<",MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	for vn1grP3y4It9GmVuBbLJfz2A,title in items:
		title = title.strip(oQpxmKiRPlHeGsLXNrJF78O)
		vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY + vn1grP3y4It9GmVuBbLJfz2A
		CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,132,HQmDERMFjx,'1')
	return
def XONC9osGSP4fW5HVrhM(url,zmL397efNlks5uTEV):
	CzNPJydxQLfw27tv4ZF8KORAbX5 = D0GFPwY8ecAVI(j9uzmBeEyK8,url,HQmDERMFjx,HQmDERMFjx,True,'ALKAWTHAR-EPISODES-1st')
	items = DyVGS3dX0ZxR.findall('totalpagecount=[\'"](.*?)[\'"]',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if not items:
		url = DyVGS3dX0ZxR.findall('class="news-detail-body".*?href="(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		url = url[0]
		title = '_MOD_' + 'ملف التشغيل'
		if url: CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,url,134)
		else: u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,'لا يوجد حاليا ملفات فيديو في هذا الفرع')
		return
	vAXuVHhyFtD95cKawMlokYj = int(items[0])
	name = DyVGS3dX0ZxR.findall('main-title.*?</a> >(.*?)<',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if name: name = name[0].strip(oQpxmKiRPlHeGsLXNrJF78O)
	else: name = FpGenVlw4Tzxi2WY3JuXcb.getInfoLabel('ListItem.Label')
	if '/category/' in url or 'search?q=' in url:
		WF2vkePC5gbXAGUarcqlpmB3Q = url.split(xufJqQcGnhboiVy2wd)[-1]
		if zmL397efNlks5uTEV==HQmDERMFjx: SSHjMN4uegZfb2 = url
		else: SSHjMN4uegZfb2 = e2VR8nohduY + '/category/' + WF2vkePC5gbXAGUarcqlpmB3Q + xufJqQcGnhboiVy2wd + zmL397efNlks5uTEV
		b3L20nx7qwHKTS6so = D0GFPwY8ecAVI(j9uzmBeEyK8,SSHjMN4uegZfb2,HQmDERMFjx,HQmDERMFjx,True,'ALKAWTHAR-EPISODES-2nd')
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('currentpagenumber(.*?)pagination',b3L20nx7qwHKTS6so,DyVGS3dX0ZxR.DOTALL)
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('src="(.*?)".*?full(.*?)>.*?href="(.*?)".*?>(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for uIGD4vZcP61QNmw78LXqoEpH,type,vn1grP3y4It9GmVuBbLJfz2A,title in items:
			if 'video' not in type: continue
			if 'مسلسل' in title and 'حلقة' not in title: continue
			title = title.replace('\r\n',HQmDERMFjx)
			title = title.strip(oQpxmKiRPlHeGsLXNrJF78O)
			if 'مسلسل' in name and 'حلقة' in title and 'مسلسل' not in title:
				title = '_MOD_' + name + ' - ' + title
			vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY + vn1grP3y4It9GmVuBbLJfz2A
			if WF2vkePC5gbXAGUarcqlpmB3Q=='628': CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,133,uIGD4vZcP61QNmw78LXqoEpH,'1')
			else: CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,134,uIGD4vZcP61QNmw78LXqoEpH)
	elif '/episode/' in url:
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('playlist(.*?)col-md-12',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
			MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
			items = DyVGS3dX0ZxR.findall("video-track-text.*?loadVideo\('(.*?)','(.*?)'.*?>(.*?)<",MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
			for vn1grP3y4It9GmVuBbLJfz2A,uIGD4vZcP61QNmw78LXqoEpH,title in items:
				title = title.strip(oQpxmKiRPlHeGsLXNrJF78O)
				CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,134,uIGD4vZcP61QNmw78LXqoEpH)
		elif '/category/628' in CzNPJydxQLfw27tv4ZF8KORAbX5:
				title = '_MOD_' + 'ملف التشغيل'
				CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,url,134)
		else:
			items = DyVGS3dX0ZxR.findall('id="Categories.*?href=\'(.*?)\'',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
			WF2vkePC5gbXAGUarcqlpmB3Q = items[0].split(xufJqQcGnhboiVy2wd)[-1]
			url = e2VR8nohduY + '/category/' + WF2vkePC5gbXAGUarcqlpmB3Q
			ZFEjC6KpI78XPWd9TueM(url)
			return
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('pagination(.*?)</div>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		pHCa6BiYtFR8K7cufxJ4OhLbWSMU = DyVGS3dX0ZxR.findall('href="(.*?)">(.*?)</a>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,title in pHCa6BiYtFR8K7cufxJ4OhLbWSMU:
			vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+vn1grP3y4It9GmVuBbLJfz2A
			vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A.replace('&amp;','&')
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'صفحة '+title,vn1grP3y4It9GmVuBbLJfz2A,133)
	return
def f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url):
	if '/news/' in url or '/episode/' in url:
		CzNPJydxQLfw27tv4ZF8KORAbX5 = D0GFPwY8ecAVI(H5x4Z2qPwR8vXM,url,HQmDERMFjx,HQmDERMFjx,True,'ALKAWTHAR-PLAY-1st')
		items = DyVGS3dX0ZxR.findall("mobilevideopath.*?value='(.*?)'",CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if items: url = items[0]
	uZVS3DcJbEULoxpve9IOTgmW6(url,HDLtdMAy7wPkl8aKC3O2,'video')
	return
def eY4DutR9cHF():
	url = e2VR8nohduY+'/live'
	CzNPJydxQLfw27tv4ZF8KORAbX5 = D0GFPwY8ecAVI(H5x4Z2qPwR8vXM,url,HQmDERMFjx,HQmDERMFjx,True,'ALKAWTHAR-LIVE-1st')
	SSHjMN4uegZfb2 = DyVGS3dX0ZxR.findall('live-container.*?src="(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	SSHjMN4uegZfb2 = SSHjMN4uegZfb2[0]
	nJayb3s5zlOgQh9BwiCdEDq = {'Referer':e2VR8nohduY}
	x4Du7lGWPET6g0H23NAvbopQya = U3GBj7agXTD1Lwze5SvO0H(rwjfOIqQU3ANa0JlWXvCDbFk,'GET',SSHjMN4uegZfb2,HQmDERMFjx,nJayb3s5zlOgQh9BwiCdEDq,HQmDERMFjx,True,'ALKAWTHAR-LIVE-2nd')
	b3L20nx7qwHKTS6so = x4Du7lGWPET6g0H23NAvbopQya.content
	WjA5SoTH673rqsB4lp0FNQyZe = DyVGS3dX0ZxR.findall('csrf-token" content="(.*?)"',b3L20nx7qwHKTS6so,DyVGS3dX0ZxR.DOTALL)
	WjA5SoTH673rqsB4lp0FNQyZe = WjA5SoTH673rqsB4lp0FNQyZe[0]
	vBF1EdeNPr9 = DpClq35GVjh(SSHjMN4uegZfb2,'url')
	jDcWv7MAkEV = DyVGS3dX0ZxR.findall("playUrl = '(.*?)'",b3L20nx7qwHKTS6so,DyVGS3dX0ZxR.DOTALL)
	jDcWv7MAkEV = vBF1EdeNPr9+jDcWv7MAkEV[0]
	sq1bilvkzOhaynJRS = {'X-CSRF-TOKEN':WjA5SoTH673rqsB4lp0FNQyZe}
	eyawEMLBndVH5 = U3GBj7agXTD1Lwze5SvO0H(rwjfOIqQU3ANa0JlWXvCDbFk,'POST',jDcWv7MAkEV,HQmDERMFjx,sq1bilvkzOhaynJRS,False,True,'ALKAWTHAR-LIVE-3rd')
	mv1l3TrKunkdiz8ZVU = eyawEMLBndVH5.content
	fVkhY4eGsLdDb = DyVGS3dX0ZxR.findall('"(.*?)"',mv1l3TrKunkdiz8ZVU,DyVGS3dX0ZxR.DOTALL)
	fVkhY4eGsLdDb = fVkhY4eGsLdDb[0].replace('\/',xufJqQcGnhboiVy2wd)
	uZVS3DcJbEULoxpve9IOTgmW6(fVkhY4eGsLdDb,HDLtdMAy7wPkl8aKC3O2,'live')
	return
def hm4kawIPKp3oMrC75dJZA9HS2(search,url=HQmDERMFjx):
	search,GXVabd4sc2u3zp0JI,showDialogs = x0pzMENwy84tBcZvXr(search)
	if url==HQmDERMFjx:
		if search==HQmDERMFjx: search = q156m84QoYrn()
		if search==HQmDERMFjx: return
		search = VVkOtyQLzxBr(search)
		url = e2VR8nohduY+'/search?q='+search
		XONC9osGSP4fW5HVrhM(url,HQmDERMFjx)
		return
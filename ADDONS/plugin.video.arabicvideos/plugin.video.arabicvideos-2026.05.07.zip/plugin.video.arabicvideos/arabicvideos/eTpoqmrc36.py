# -*- coding: utf-8 -*-
import sys as TPW58slaVE9OrYQXZnGo2yAfFzpBxc
tbYWAoeMyHTsgFG5x6huz1 = TPW58slaVE9OrYQXZnGo2yAfFzpBxc.version_info [0] == 2
CUJSAbZztE8vYdGByLH0KcnWqe = 2048
R0QCXnpyL1DJwBH67FW = 7
def kSod2AxqugH0 (LURfCucn30xKsMdTiG):
	global ghCyPxkWILcXrGjVut6MQo59fsv
	MfIpC9TDz7Qa5g2vVqPtXh4 = ord (LURfCucn30xKsMdTiG [-1])
	nndScZEtapB74 = LURfCucn30xKsMdTiG [:-1]
	LRbqugZJAa3192OCewWGHvEcP = MfIpC9TDz7Qa5g2vVqPtXh4 % len (nndScZEtapB74)
	qLc7RGgDQE = nndScZEtapB74 [:LRbqugZJAa3192OCewWGHvEcP] + nndScZEtapB74 [LRbqugZJAa3192OCewWGHvEcP:]
	if tbYWAoeMyHTsgFG5x6huz1:
		XUczap3yA0QqFRC82OH6E5mL = unicode () .join ([unichr (ord (ah5u39EBY81MlrwA0cmoz4ngb7TLed) - CUJSAbZztE8vYdGByLH0KcnWqe - (YMjpxPr8WsJ1Bg6Xd + MfIpC9TDz7Qa5g2vVqPtXh4) % R0QCXnpyL1DJwBH67FW) for YMjpxPr8WsJ1Bg6Xd, ah5u39EBY81MlrwA0cmoz4ngb7TLed in enumerate (qLc7RGgDQE)])
	else:
		XUczap3yA0QqFRC82OH6E5mL = str () .join ([chr (ord (ah5u39EBY81MlrwA0cmoz4ngb7TLed) - CUJSAbZztE8vYdGByLH0KcnWqe - (YMjpxPr8WsJ1Bg6Xd + MfIpC9TDz7Qa5g2vVqPtXh4) % R0QCXnpyL1DJwBH67FW) for YMjpxPr8WsJ1Bg6Xd, ah5u39EBY81MlrwA0cmoz4ngb7TLed in enumerate (qLc7RGgDQE)])
	return eval (XUczap3yA0QqFRC82OH6E5mL)
jL1E5AKfwBDv6xmeQtUXcJ3d,JJA7fypmZFVlazvNI,dBi72erQEtKDOwjNFaoAgSP=kSod2AxqugH0,kSod2AxqugH0,kSod2AxqugH0
CDwSWB4v39N7,k4IUieraScH9DV1N7pJgQosYAx5l,Tcf5Ppn9UajDbzyM=dBi72erQEtKDOwjNFaoAgSP,JJA7fypmZFVlazvNI,jL1E5AKfwBDv6xmeQtUXcJ3d
X2crmy67eZpkGTRd,HDpmv4UXzlf72SK9,C3ZK1pu4rfmj8TsWUtBaM=Tcf5Ppn9UajDbzyM,k4IUieraScH9DV1N7pJgQosYAx5l,CDwSWB4v39N7
mg3CbXMA2ouZzQDhRqB,OBsrtQo2pPlgURCxJYbj9iXMD,ssnfOzb16wVog9GKdqcXR3JC7ktSPA=C3ZK1pu4rfmj8TsWUtBaM,HDpmv4UXzlf72SK9,X2crmy67eZpkGTRd
ShnRVsifKtc60zqQ,KKi79PFqsYB0dWSRgaJ3DyE,OzU6t0qcH7MQabeBYK8vgoG=ssnfOzb16wVog9GKdqcXR3JC7ktSPA,OBsrtQo2pPlgURCxJYbj9iXMD,mg3CbXMA2ouZzQDhRqB
mgLADoQ1pbtY,U0VwOviFaYPz2QGs45mJhMXf7Zk,pCTzbw4GyVJHjkcIMQ=OzU6t0qcH7MQabeBYK8vgoG,KKi79PFqsYB0dWSRgaJ3DyE,ShnRVsifKtc60zqQ
owbMhINBQsmx70guApW,SODvU3Ibq5VzC,PPAUFrY8cduRT=pCTzbw4GyVJHjkcIMQ,U0VwOviFaYPz2QGs45mJhMXf7Zk,mgLADoQ1pbtY
knTyjJ0sGIzuwbxRae,nz8x32hX0qcjUPFZk5RdJsiwED,A0aqj9uclgOtByJ6F4bz=PPAUFrY8cduRT,SODvU3Ibq5VzC,owbMhINBQsmx70guApW
YJxaX0MQOHb8oyCBFdnIAe,n6sfYuHBlVdzgmvpXwR3irON0KIj8,LHX65I9nkx0PstgcVY24uSi=A0aqj9uclgOtByJ6F4bz,nz8x32hX0qcjUPFZk5RdJsiwED,knTyjJ0sGIzuwbxRae
EAVanJj1ers2GQud,ELfMeDTIFhJt685K,EF2tvxZHz5n4UruPhaViXKycI6SQR=LHX65I9nkx0PstgcVY24uSi,n6sfYuHBlVdzgmvpXwR3irON0KIj8,YJxaX0MQOHb8oyCBFdnIAe
KhUG1NV9bln5zXjptqFW6dgo,cWbkR6iUZsnJQj14,maUl7SPesynF1j=EF2tvxZHz5n4UruPhaViXKycI6SQR,ELfMeDTIFhJt685K,EAVanJj1ers2GQud
from FF68kA5BUy import *
HDLtdMAy7wPkl8aKC3O2 = EAVanJj1ers2GQud(u"ࠫࡈࡒࡅࡂࡐࡈࡖࠬࠀ")
EEJvXQzSZNt = OzU6t0qcH7MQabeBYK8vgoG(u"ࠬࡥࡃࡍࡐࡢࠫࠁ")
oojO6D8vCQSEnJLPUmT = S9Y5kUoRga3EVN.path.join(LLjS8IZtzBGTW,Tcf5Ppn9UajDbzyM(u"࠭ࡴࡦ࡯ࡳࠫࠂ"))
ZJnt2LjW1uEicQYV0Al85 = S9Y5kUoRga3EVN.path.join(LLjS8IZtzBGTW,YJxaX0MQOHb8oyCBFdnIAe(u"ࠧࡱࡣࡦ࡯ࡦ࡭ࡥࡴࠩࠃ"))
z9zBcODbrIhtsGXiWCKmln4TN2 = S9Y5kUoRga3EVN.path.join(vZmS3d7AaDN5JsGqPTgxOpVBFw,KKi79PFqsYB0dWSRgaJ3DyE(u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪࠄ"),X2crmy67eZpkGTRd(u"ࠩࡗ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡸ࠭ࠅ"))
wJW2ZeR7EVaPxr8i4 = U0VwOviFaYPz2QGs45mJhMXf7Zk(u"ࠪ࠳ࡩࡧࡴࡢ࠱ࡶࡽࡸࡺࡥ࡮࠱ࡸࡷࡦ࡭ࡥࡴࡶࡤࡸࡸ࠭ࠆ")
ob1cgWZjzJa = ShnRVsifKtc60zqQ(u"ࠫ࠴ࡪࡡࡵࡣ࠲ࡷࡾࡹࡴࡦ࡯࠲ࡨࡷࡵࡰࡣࡱࡻࠫࠇ")
mmYt16qr8XFD5Sb4RL7K = C3ZK1pu4rfmj8TsWUtBaM(u"ࠬ࠵ࡤࡢࡶࡤ࠳ࡹࡵ࡭ࡣࡵࡷࡳࡳ࡫ࡳࠨࠈ")
iQIyhetTEcZgk3LzudAs5O8U0p4fWD = mgLADoQ1pbtY(u"࠭࠯ࡥࡣࡷࡥ࠴ࡲ࡯ࡨࡩࡨࡶࠬࠉ")
RFEDIj2zMHnud5yGXUt0 = mgLADoQ1pbtY(u"ࠧ࠰ࡦࡤࡸࡦ࠵࡬ࡰࡩࠪࠊ")
hSxaeOj80Hyd = mgLADoQ1pbtY(u"ࠨ࠱ࡧࡥࡹࡧ࠯ࡢࡰࡵࠫࠋ")
D679ta8JYbUNdoRjgPuMWBGCXZn = GnBJi17tQ4ukplr
asvH4NKMARZVkCGge9rXFhBpLtym = cZeYBhl0CKsg1EwxAXnRVf427F
sTyjZSz8oKvLqimP9Ddcxel5hf = ttwXYn5Q8bJ
def kk6X5LxpsND(lXBL3WrM2JFYm):
	if   lXBL3WrM2JFYm==cWbkR6iUZsnJQj14(u"࠸࠶࠳ࣈ"): zLZUkrP7ac5 = GXByaJAOkt7Lje29Zpsh()
	elif lXBL3WrM2JFYm==A0aqj9uclgOtByJ6F4bz(u"࠹࠷࠵ࣉ"): zLZUkrP7ac5 = Nam0DyfXK5(oojO6D8vCQSEnJLPUmT,gyd2rf0UR5,gyd2rf0UR5);CZhBEdmsY4(zLZUkrP7ac5)
	elif lXBL3WrM2JFYm==JJA7fypmZFVlazvNI(u"࠺࠸࠷࣊"): zLZUkrP7ac5 = Nam0DyfXK5(ZJnt2LjW1uEicQYV0Al85,gyd2rf0UR5,gyd2rf0UR5);CZhBEdmsY4(zLZUkrP7ac5)
	elif lXBL3WrM2JFYm==PPAUFrY8cduRT(u"࠻࠹࠹࣋"): zLZUkrP7ac5 = Nam0DyfXK5(z9zBcODbrIhtsGXiWCKmln4TN2,mic3MEN709xOkrjD5ZvbGIlX6,gyd2rf0UR5);CZhBEdmsY4(zLZUkrP7ac5)
	elif lXBL3WrM2JFYm==jL1E5AKfwBDv6xmeQtUXcJ3d(u"࠼࠺࠴࣌"): zLZUkrP7ac5 = p1CDA9m0FZiokLKneX(gyd2rf0UR5);CZhBEdmsY4(zLZUkrP7ac5)
	elif lXBL3WrM2JFYm==knTyjJ0sGIzuwbxRae(u"࠽࠴࠶࣍"): zLZUkrP7ac5 = e6hpcV8Il2AzvYr1agbGwdKB(gyd2rf0UR5);CZhBEdmsY4(zLZUkrP7ac5)
	elif lXBL3WrM2JFYm==C3ZK1pu4rfmj8TsWUtBaM(u"࠷࠵࠸࣎"): zLZUkrP7ac5 = XfMYGQ9DZhWeKCO0bA261r(gyd2rf0UR5);CZhBEdmsY4(zLZUkrP7ac5)
	elif lXBL3WrM2JFYm==U0VwOviFaYPz2QGs45mJhMXf7Zk(u"࠸࠷࠳࣏"): zLZUkrP7ac5 = Vcr4ZbFoaznP3UXm0efEyWRxCdS7()
	elif lXBL3WrM2JFYm==C3ZK1pu4rfmj8TsWUtBaM(u"࠹࠸࠵࣐"): zLZUkrP7ac5 = Nam0DyfXK5(wJW2ZeR7EVaPxr8i4,mic3MEN709xOkrjD5ZvbGIlX6,gyd2rf0UR5);CZhBEdmsY4(zLZUkrP7ac5)
	elif lXBL3WrM2JFYm==n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"࠺࠹࠷࣑"): zLZUkrP7ac5 = Nam0DyfXK5(ob1cgWZjzJa,mic3MEN709xOkrjD5ZvbGIlX6,gyd2rf0UR5);CZhBEdmsY4(zLZUkrP7ac5)
	elif lXBL3WrM2JFYm==LHX65I9nkx0PstgcVY24uSi(u"࠻࠺࠹࣒"): zLZUkrP7ac5 = Nam0DyfXK5(mmYt16qr8XFD5Sb4RL7K,mic3MEN709xOkrjD5ZvbGIlX6,gyd2rf0UR5);CZhBEdmsY4(zLZUkrP7ac5)
	elif lXBL3WrM2JFYm==JJA7fypmZFVlazvNI(u"࠼࠻࠴࣓"): zLZUkrP7ac5 = Nam0DyfXK5(iQIyhetTEcZgk3LzudAs5O8U0p4fWD,mic3MEN709xOkrjD5ZvbGIlX6,gyd2rf0UR5);CZhBEdmsY4(zLZUkrP7ac5)
	elif lXBL3WrM2JFYm==X2crmy67eZpkGTRd(u"࠽࠵࠶ࣔ"): zLZUkrP7ac5 = Nam0DyfXK5(RFEDIj2zMHnud5yGXUt0,mic3MEN709xOkrjD5ZvbGIlX6,gyd2rf0UR5);CZhBEdmsY4(zLZUkrP7ac5)
	elif lXBL3WrM2JFYm==OBsrtQo2pPlgURCxJYbj9iXMD(u"࠷࠶࠸ࣕ"): zLZUkrP7ac5 = Nam0DyfXK5(hSxaeOj80Hyd,mic3MEN709xOkrjD5ZvbGIlX6,gyd2rf0UR5);CZhBEdmsY4(zLZUkrP7ac5)
	elif lXBL3WrM2JFYm==PPAUFrY8cduRT(u"࠸࠷࠺ࣖ"): zLZUkrP7ac5 = QrBDoOAeMHvnRk(gyd2rf0UR5);CZhBEdmsY4(zLZUkrP7ac5)
	elif lXBL3WrM2JFYm==CDwSWB4v39N7(u"࠹࠸࠼ࣗ"): zLZUkrP7ac5 = ExkuhKpBSAJ9gyPbsr();CZhBEdmsY4(zLZUkrP7ac5)
	elif lXBL3WrM2JFYm==OBsrtQo2pPlgURCxJYbj9iXMD(u"࠴࠴࠽࠶ࣘ"): zLZUkrP7ac5 = QQcaqL0dIuiZw3O()
	elif lXBL3WrM2JFYm==HDpmv4UXzlf72SK9(u"࠵࠵࠾࠱ࣙ"): zLZUkrP7ac5 = Ljhuo34nlQtFCR(gyd2rf0UR5);CZhBEdmsY4(zLZUkrP7ac5)
	elif lXBL3WrM2JFYm==A0aqj9uclgOtByJ6F4bz(u"࠶࠶࠸࠳ࣚ"): zLZUkrP7ac5 = gWLXe2BkTmqKcv5dpfhiNnbYj();CZhBEdmsY4(zLZUkrP7ac5)
	elif lXBL3WrM2JFYm==nz8x32hX0qcjUPFZk5RdJsiwED(u"࠷࠰࠹࠵ࣛ"): zLZUkrP7ac5 = hCopWyP6dzJwAQc1gOXxBDi4();CZhBEdmsY4(zLZUkrP7ac5)
	elif lXBL3WrM2JFYm==k4IUieraScH9DV1N7pJgQosYAx5l(u"࠱࠱࠺࠷ࣜ"): zLZUkrP7ac5 = VfayOqQSZ4718nePDBNg5GUu();CZhBEdmsY4(zLZUkrP7ac5)
	elif lXBL3WrM2JFYm==CDwSWB4v39N7(u"࠲࠲࠻࠹ࣝ"): zLZUkrP7ac5 = afkxo7FyZWB4O6K1eXrs5I()
	elif lXBL3WrM2JFYm==HDpmv4UXzlf72SK9(u"࠳࠳࠼࠻ࣞ"): zLZUkrP7ac5 = EECpNbXVhrwdk4YZQelnMJsTtOfi()
	else: zLZUkrP7ac5 = mic3MEN709xOkrjD5ZvbGIlX6
	return zLZUkrP7ac5
def EECpNbXVhrwdk4YZQelnMJsTtOfi():
	PMaTdFmOBHSCWJsRhy = maUl7SPesynF1j(u"࠴࠴࠷࠺ࣟ")*maUl7SPesynF1j(u"࠴࠴࠷࠺ࣟ")
	TPCRAXj1tNUvnSfkzmsihw2Fub3 = NEVGfakZpwsDMA2()//PMaTdFmOBHSCWJsRhy
	kJGvW2BHM5 = TPCRAXj1tNUvnSfkzmsihw2Fub3<A0aqj9uclgOtByJ6F4bz(u"࠹࠵࣠")
	size = ao3Q5jP8H0sMxK2iUYwZGE+mg3CbXMA2ouZzQDhRqB(u"ࠩ็ำ๏้ࠠๆีสัฮࠦแศำ฽อࠥࠦࠧࠌ")+str(TPCRAXj1tNUvnSfkzmsihw2Fub3)+HDpmv4UXzlf72SK9(u"ࠪࠤ๋๊ࠥอษหห๏ะࠧࠍ")+cjqzOQ5GXD4kR
	if kJGvW2BHM5:
		vv8DyVrLOPAXFIMZ9h(GmyBXr3kYHdlvJ,OBsrtQo2pPlgURCxJYbj9iXMD(u"ࠫࡈࡎࡅࡄࡍࡢࡈࡎ࡙ࡋࡠࡕࡓࡅࡈࡋࠠࠡࠢࡖࡘࡔࡘࡁࡈࡇࠣࡍࡘࠦࡆࡖࡎࡏࠤࠥࠦࠧࠎ")+str(TPCRAXj1tNUvnSfkzmsihw2Fub3)+pCTzbw4GyVJHjkcIMQ(u"ࠬࠦࡍࡃࠢࠤࠥࠬࠏ"))
		u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,k4IUieraScH9DV1N7pJgQosYAx5l(u"࠭ๅิษะอࠥอไหะี๎๋ࠦแ๋ࠢฯ๋ฬุใࠡลุฬาะࠠๆ็อ่หฯࠠ࠯࠰ࠣ์์ึวࠡ์ึฬอࠦๅีษๆ่้ࠥห๋ำฬࠤๆ๐ࠠหึ฽๎้ࠦวๅฮ๊หื่ࠦหึ฽๎้ࠦใ้ัํࠤํะิ฻์็ࠤอืๆศ็ฯࠤ฾๋วะࠢ࠱࠲ࠥอๆหࠢหัฬาษࠡว็ํࠥะๆู์ไࠤัํวำๅࠣ์ฯ์ื๋ใࠣ็ํี๊๊ࠡอ๊฽๐แ้ࠡำหࠥอไษำ้ห๊า࡜࡯࡞ࡱࠫࠐ")+size)
	else: u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,LHX65I9nkx0PstgcVY24uSi(u"ࠧๆีสัฮࠦวๅฬัึ๏์ࠠโ์ࠣะ์อาไࠢฯ๎ิฯ࡜࡯࡞ࡱࠫࠑ")+size)
	return kJGvW2BHM5
def CZhBEdmsY4(EPJnGfmr9p6wZ5WaL4XtdHjkUi):
	if EPJnGfmr9p6wZ5WaL4XtdHjkUi: dXUwsnOGKBF57cNaok(gyd2rf0UR5)
	return
def afkxo7FyZWB4O6K1eXrs5I():
	CfgK4s13Q0hZcHyleT2bVJO9(CDwSWB4v39N7(u"ࠨ࡮࡬ࡲࡰ࠭ࠒ"),OzU6t0qcH7MQabeBYK8vgoG(u"ࠩไัฺࠦๅิษะอࠥอไหะี๎๋࠭ࠓ"),HQmDERMFjx,C3ZK1pu4rfmj8TsWUtBaM(u"࠶࠶࠸࠷࣡"))
	CfgK4s13Q0hZcHyleT2bVJO9(n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"ࠪࡪࡴࡲࡤࡦࡴࠪࠔ"),nz8x32hX0qcjUPFZk5RdJsiwED(u"ࠫฯ์ุ๋ใࠣห้า็ศิࠪࠕ"),HQmDERMFjx,pCTzbw4GyVJHjkcIMQ(u"࠽࠵࠱࣢"))
	CfgK4s13Q0hZcHyleT2bVJO9(C3ZK1pu4rfmj8TsWUtBaM(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬࠖ"),PPAUFrY8cduRT(u"࠭สแ่฻๎ๆࠦใแ๊า๎ࠬࠗ"),HQmDERMFjx,owbMhINBQsmx70guApW(u"࠷࠵࠲ࣣ"))
	CfgK4s13Q0hZcHyleT2bVJO9(HDpmv4UXzlf72SK9(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ࠘"),SODvU3Ibq5VzC(u"ࠨฬ้฼๏็ࠠศๆหี๋อๅอࠩ࠙"),HQmDERMFjx,ELfMeDTIFhJt685K(u"࠲࠲࠻࠴ࣤ"))
	return
def QQcaqL0dIuiZw3O():
	t6tJ29yhBeaVsvWlDZdQU1R3fMOu,a6E8WX2Hn0crdoY4VvfhQP = vOtSPQH7TR(D679ta8JYbUNdoRjgPuMWBGCXZn)
	dnu6Gp8Itao5DC7Eiec,oDemyqGKAY8InVr4lji = vOtSPQH7TR(asvH4NKMARZVkCGge9rXFhBpLtym)
	aSN63s7WnvTepMyk8PIQlJVbqcf,BhHXjVQoKGpIzkiRYFdSrtPbm = e6eB5OgKHw4kf1C73IJWNZqAPRbyn(sTyjZSz8oKvLqimP9Ddcxel5hf)
	CBH4DrlhJOkzw95LiTYu1oFVesayfA,kOypuZXLK2MQf6v = t6tJ29yhBeaVsvWlDZdQU1R3fMOu+dnu6Gp8Itao5DC7Eiec+aSN63s7WnvTepMyk8PIQlJVbqcf,a6E8WX2Hn0crdoY4VvfhQP+oDemyqGKAY8InVr4lji+BhHXjVQoKGpIzkiRYFdSrtPbm
	Dl2CStgBcOJWIV = ShnRVsifKtc60zqQ(u"ࠩࠣࠬࠬࠚ")+L0N7IT3P9omAf2C8RjdSlxJv6rqKzU(t6tJ29yhBeaVsvWlDZdQU1R3fMOu)+JJA7fypmZFVlazvNI(u"ࠪࠤ࠲ࠦࠧࠛ")+str(a6E8WX2Hn0crdoY4VvfhQP)+LHX65I9nkx0PstgcVY24uSi(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬࠜ")
	V2BYOtuyW9U = KhUG1NV9bln5zXjptqFW6dgo(u"ࠬࠦࠨࠨࠝ")+L0N7IT3P9omAf2C8RjdSlxJv6rqKzU(dnu6Gp8Itao5DC7Eiec)+OBsrtQo2pPlgURCxJYbj9iXMD(u"࠭ࠠ࠮ࠢࠪࠞ")+str(oDemyqGKAY8InVr4lji)+JJA7fypmZFVlazvNI(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨࠟ")
	CZFXa7H2Vm1R38zWM = ShnRVsifKtc60zqQ(u"ࠨࠢࠫࠫࠠ")+L0N7IT3P9omAf2C8RjdSlxJv6rqKzU(aSN63s7WnvTepMyk8PIQlJVbqcf)+YJxaX0MQOHb8oyCBFdnIAe(u"ࠩࠣ࠱ࠥ࠭ࠡ")+str(BhHXjVQoKGpIzkiRYFdSrtPbm)+YJxaX0MQOHb8oyCBFdnIAe(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࠢ")
	ogPhLb7Q4CtxBzrFZyGKkRJUDIi = KhUG1NV9bln5zXjptqFW6dgo(u"ࠫࠥ࠮ࠧࠣ")+L0N7IT3P9omAf2C8RjdSlxJv6rqKzU(CBH4DrlhJOkzw95LiTYu1oFVesayfA)+mg3CbXMA2ouZzQDhRqB(u"ࠬࠦ࠭ࠡࠩࠤ")+str(kOypuZXLK2MQf6v)+KhUG1NV9bln5zXjptqFW6dgo(u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧࠥ")
	CfgK4s13Q0hZcHyleT2bVJO9(ShnRVsifKtc60zqQ(u"ࠧ࡭࡫ࡱ࡯ࠬࠦ"),EEJvXQzSZNt+SODvU3Ibq5VzC(u"ࠨ็ึัࠥอไอ็ํ฽ࠬࠧ")+ogPhLb7Q4CtxBzrFZyGKkRJUDIi,HQmDERMFjx,k4IUieraScH9DV1N7pJgQosYAx5l(u"࠳࠳࠼࠹ࣥ"))
	CfgK4s13Q0hZcHyleT2bVJO9(C3ZK1pu4rfmj8TsWUtBaM(u"ࠩ࡯࡭ࡳࡱࠧࠨ"),ao3Q5jP8H0sMxK2iUYwZGE+mg3CbXMA2ouZzQDhRqB(u"ࠪࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡࠩࠩ")+cjqzOQ5GXD4kR,HQmDERMFjx,pCTzbw4GyVJHjkcIMQ(u"࠼࠽࠾࠿ࣦ"))
	CfgK4s13Q0hZcHyleT2bVJO9(U0VwOviFaYPz2QGs45mJhMXf7Zk(u"ࠫࡱ࡯࡮࡬ࠩࠪ"),EEJvXQzSZNt+JJA7fypmZFVlazvNI(u"๋ࠬำฮุࠢ์ึࠦวๅๅอหอฯࠧࠫ")+Dl2CStgBcOJWIV,HQmDERMFjx,dBi72erQEtKDOwjNFaoAgSP(u"࠵࠵࠾࠱ࣧ"))
	CfgK4s13Q0hZcHyleT2bVJO9(EF2tvxZHz5n4UruPhaViXKycI6SQR(u"࠭࡬ࡪࡰ࡮ࠫࠬ"),EEJvXQzSZNt+owbMhINBQsmx70guApW(u"ࠧๆีะࠤ่อิࠡษ็ฬึ์วๆฮࠪ࠭")+V2BYOtuyW9U,HQmDERMFjx,mgLADoQ1pbtY(u"࠶࠶࠸࠳ࣨ"))
	CfgK4s13Q0hZcHyleT2bVJO9(LHX65I9nkx0PstgcVY24uSi(u"ࠨ࡮࡬ࡲࡰ࠭࠮"),EEJvXQzSZNt+EAVanJj1ers2GQud(u"่ࠩืาࠦลฺัสำฬะࠠศๆหี๋อๅอࠩ࠯")+CZFXa7H2Vm1R38zWM,HQmDERMFjx,SODvU3Ibq5VzC(u"࠷࠰࠹࠵ࣩ"))
	CfgK4s13Q0hZcHyleT2bVJO9(ELfMeDTIFhJt685K(u"ࠪࡰ࡮ࡴ࡫ࠨ࠰"),EEJvXQzSZNt+CDwSWB4v39N7(u"ࠫฯ฻แ๋ำࠣห้ฮั็ษ่ะࠬ࠱")+ogPhLb7Q4CtxBzrFZyGKkRJUDIi,HQmDERMFjx,JJA7fypmZFVlazvNI(u"࠱࠱࠺࠷࣪"))
	return
def VfayOqQSZ4718nePDBNg5GUu():
	EPJnGfmr9p6wZ5WaL4XtdHjkUi = mic3MEN709xOkrjD5ZvbGIlX6
	N7gs9UBCeDR3 = HUJZy0SrTbBYv1(HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,KKi79PFqsYB0dWSRgaJ3DyE(u"ࠬํไࠡฬิ๎ิࠦแฺๆสࠤู๊อࠡฮ่๎฾ࠦลฺัสำฬะࠠศๆหี๋อๅอࠢ࠱࠲ࠥ๎ๅิฯࠣะ๊๐ูࠡ็็ๅฬะࠠศๆหี๋อๅอࠢส่็ี๊ๆหࠣ࠲࠳ࠦอห๋ࠣ๎฾๎ฯࠡษ็ฬึ์วๆฮࠣษ้๏ࠠฮษ็อࠥอไึใิࠤ࠳࠴๋ࠠ฻้๎ࠥำวๅหࠣ์฻฿๊สูࠢฬ฼ࠦวๅ็ุ๊฾ࠦ࠮࠯ࠢํ฽๋๐ࠠศๆะห้ฯࠠศๆอ๎ࠥ๎ึฺ้สࠤฬ๊ๅษำ่ะ๊ࠥไษำ้ห๊าࠠ࠯࠰๋ࠣีํࠠศๆ฼้้๐ษࠡฬอ้ࠥฮๅิฯ้ࠣั๊ฯࠡๅสุࠥอไษำ้ห๊า้ࠠ็ึั๋ࠥไโࠢศ฽ิอฯศฬࠣห้ฮั็ษ่ะࠥลࠡࠨ࠲"))
	if N7gs9UBCeDR3:
		NNOiKtFjlWzvyeC19Ep = hCopWyP6dzJwAQc1gOXxBDi4()
		oCQ1HRFt4Va5 = Nam0DyfXK5(cZeYBhl0CKsg1EwxAXnRVf427F,gyd2rf0UR5,mic3MEN709xOkrjD5ZvbGIlX6)
		EPJnGfmr9p6wZ5WaL4XtdHjkUi = NNOiKtFjlWzvyeC19Ep and oCQ1HRFt4Va5
		if EPJnGfmr9p6wZ5WaL4XtdHjkUi: u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,ShnRVsifKtc60zqQ(u"࠭ฬ๋ัࠣ࠲࠳ࠦๆอฯอࠤ฾๋ไ๋หุ้ࠣำࠠศๆ่่ๆอสࠡษ็ๆิ๐ๅสࠢ็่อืๆศ็ฯࠤ࠳࠴้ࠠ฻สำࠥอไษำ้ห๊าࠠฦๆ์ࠤํ฼ู๋หࠣห้฻แาࠢ࠱࠲ࠥ๎ึฺ์ฬࠤ฻ฮืࠡษ็ฺ้์ูࠨ࠳"))
		else: u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,PPAUFrY8cduRT(u"ࠧๅๆฦืๆࠦ࠮࠯ࠢไุ้ะฺࠠ็็๎ฮࠦสึใํีࠥอไษำ้ห๊า้ࠠว฼หิะ็ࠡว็ํࠥ๎ึฺ์ฬࠤ฻ฮืࠡษ็ฺ้์ูࠨ࠴"))
	return EPJnGfmr9p6wZ5WaL4XtdHjkUi
def gWLXe2BkTmqKcv5dpfhiNnbYj():
	import gSoJpYTcVy
	gSoJpYTcVy.uELMyWtoGOCRz9A0b6Sam()
	HH2hLvGCD3zfk = mic3MEN709xOkrjD5ZvbGIlX6
	N7gs9UBCeDR3 = HUJZy0SrTbBYv1(U0VwOviFaYPz2QGs45mJhMXf7Zk(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ࠵"),HQmDERMFjx,HQmDERMFjx,LHX65I9nkx0PstgcVY24uSi(u"๊่ࠩࠥะั๋ัุ้ࠣำࠠอ็ํ฽ࠥอไไษืࠤฤ࠭࠶"),owbMhINBQsmx70guApW(u"ࠪห้้วีࠢํืึ฿ฺࠠ็็ࠤฬ๊ศา่ส้ั่ࠦๆีะ๋ࠥ๐ู๋ัࠣืาฮࠠศๆุๅาอสࠡ็้ࠤฬ๊ล็ฬิ๊ฯูࠦ็ัࠣห้ำวอหࠣษ้๐็ศࠢ࠱࠲ࠥ฿ไๆษࠣว๋ࠦวๅ็ึัࠥ๐สๆࠢอ่็อฦ๋ษࠣ฽๋ีࠠศ่อ๋ฬวฺࠠ็ิࠤฬ๊ีโฯสฮࠥ࠴࠮๊ࠡฦ๎฻อࠠศๆ่ืาࠦไศࠢํฺึ่ࠦๆ็ๆ๊ࠥ๐อๅࠢห฽฻ࠦวๅ็ืห่๊ࠧ࠷"))
	if N7gs9UBCeDR3==CH7RKuDVzN9f06q8MtXPhlvIxakEWg:
		HH2hLvGCD3zfk = Nam0DyfXK5(cZeYBhl0CKsg1EwxAXnRVf427F,gyd2rf0UR5,mic3MEN709xOkrjD5ZvbGIlX6)
		if HH2hLvGCD3zfk: u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,C3ZK1pu4rfmj8TsWUtBaM(u"ࠫา๐ฯࠡ࠰࠱ࠤ๋าอหࠢ฼้้๐ษࠡ็ึั๋ࠥฬๅัࠣ็ฬฺࠠศๆหี๋อๅอࠩ࠸"))
		else: u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,knTyjJ0sGIzuwbxRae(u"๊ࠬไฤีไࠤ࠳࠴ࠠโึ็ฮࠥ฿ๅๅ์ฬࠤู๊อࠡ็ฯ่ิࠦใศึࠣห้ฮั็ษ่ะࠬ࠹"))
	return HH2hLvGCD3zfk
def hCopWyP6dzJwAQc1gOXxBDi4():
	HH2hLvGCD3zfk = mic3MEN709xOkrjD5ZvbGIlX6
	N7gs9UBCeDR3 = HUJZy0SrTbBYv1(jL1E5AKfwBDv6xmeQtUXcJ3d(u"࠭ࡣࡦࡰࡷࡩࡷ࠭࠺"),HQmDERMFjx,HQmDERMFjx,ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"ࠧิฦส่ࠬ࠻"),JJA7fypmZFVlazvNI(u"ࠨ้็ࠤศ์สࠡ็อว่ี้ࠠฬิ๎ิࠦๅิฯࠣ์ฯ฻แ๋ำࠣะ๊๐ูࠡว฼ำฬีวหࠢหี๋อๅอࠢ฼้ฬีࠠๅๆไ๎ิ๐่่ษอࠤฬู๊าสํอࠥ࠴ࠠฮ์ฮࠤฯ฿่ะࠢฯ้๏฿ࠠศๆศ฽ิอฯศฬࠣษ้๏ุ้ࠠ฼๎ฮࠦสฬสํฮࠥอไษำ้ห๊าࠠภࠩ࠼"))
	if N7gs9UBCeDR3==CH7RKuDVzN9f06q8MtXPhlvIxakEWg:
		try:
			S9Y5kUoRga3EVN.remove(ttwXYn5Q8bJ)
			HH2hLvGCD3zfk = gyd2rf0UR5
		except: pass
		if HH2hLvGCD3zfk: u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,maUl7SPesynF1j(u"ࠩอ้ࠥฮๆอษะࠤู๊อ๊ࠡอูๆ๐ัࠡ็็ๅࠥหูะษาหฯࠦศา่ส้ัูࠦๆษาࠤ้๊แ๋ัํ์์อสࠡษ็฽ึฮ๊สࠩ࠽"))
		else: u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,A0aqj9uclgOtByJ6F4bz(u"่้ࠪษำโࠢไุ้ะฺࠠ็็๎ฮࠦๅิฯ้้ࠣ็ࠠศๆศ฽ิอฯศฬࠪ࠾"))
	return HH2hLvGCD3zfk
def QQcaqL0dIuiZw3O():
	t6tJ29yhBeaVsvWlDZdQU1R3fMOu,a6E8WX2Hn0crdoY4VvfhQP = vOtSPQH7TR(D679ta8JYbUNdoRjgPuMWBGCXZn)
	dnu6Gp8Itao5DC7Eiec,oDemyqGKAY8InVr4lji = vOtSPQH7TR(asvH4NKMARZVkCGge9rXFhBpLtym)
	aSN63s7WnvTepMyk8PIQlJVbqcf,BhHXjVQoKGpIzkiRYFdSrtPbm = e6eB5OgKHw4kf1C73IJWNZqAPRbyn(sTyjZSz8oKvLqimP9Ddcxel5hf)
	CBH4DrlhJOkzw95LiTYu1oFVesayfA,kOypuZXLK2MQf6v = t6tJ29yhBeaVsvWlDZdQU1R3fMOu+dnu6Gp8Itao5DC7Eiec+aSN63s7WnvTepMyk8PIQlJVbqcf,a6E8WX2Hn0crdoY4VvfhQP+oDemyqGKAY8InVr4lji+BhHXjVQoKGpIzkiRYFdSrtPbm
	Dl2CStgBcOJWIV = KKi79PFqsYB0dWSRgaJ3DyE(u"ࠫࠥ࠮ࠧ࠿")+L0N7IT3P9omAf2C8RjdSlxJv6rqKzU(t6tJ29yhBeaVsvWlDZdQU1R3fMOu)+CDwSWB4v39N7(u"ࠬࠦ࠭ࠡࠩࡀ")+str(a6E8WX2Hn0crdoY4VvfhQP)+LHX65I9nkx0PstgcVY24uSi(u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧࡁ")
	V2BYOtuyW9U = cWbkR6iUZsnJQj14(u"ࠧࠡࠪࠪࡂ")+L0N7IT3P9omAf2C8RjdSlxJv6rqKzU(dnu6Gp8Itao5DC7Eiec)+JJA7fypmZFVlazvNI(u"ࠨࠢ࠰ࠤࠬࡃ")+str(oDemyqGKAY8InVr4lji)+pCTzbw4GyVJHjkcIMQ(u"ࠩࠣࡪ࡮ࡲࡥࡴࠫࠪࡄ")
	CZFXa7H2Vm1R38zWM = SODvU3Ibq5VzC(u"ࠪࠤ࠭࠭ࡅ")+L0N7IT3P9omAf2C8RjdSlxJv6rqKzU(aSN63s7WnvTepMyk8PIQlJVbqcf)+EAVanJj1ers2GQud(u"ࠫࠥ࠳ࠠࠨࡆ")+str(BhHXjVQoKGpIzkiRYFdSrtPbm)+maUl7SPesynF1j(u"ࠬࠦࡦࡪ࡮ࡨࡷ࠮࠭ࡇ")
	ogPhLb7Q4CtxBzrFZyGKkRJUDIi = A0aqj9uclgOtByJ6F4bz(u"࠭ࠠࠩࠩࡈ")+L0N7IT3P9omAf2C8RjdSlxJv6rqKzU(CBH4DrlhJOkzw95LiTYu1oFVesayfA)+KhUG1NV9bln5zXjptqFW6dgo(u"ࠧࠡ࠯ࠣࠫࡉ")+str(kOypuZXLK2MQf6v)+OzU6t0qcH7MQabeBYK8vgoG(u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩࡊ")
	CfgK4s13Q0hZcHyleT2bVJO9(YJxaX0MQOHb8oyCBFdnIAe(u"ࠩ࡯࡭ࡳࡱࠧࡋ"),EEJvXQzSZNt+owbMhINBQsmx70guApW(u"ุ้ࠪำࠠศๆฯ้๏฿ࠧࡌ")+ogPhLb7Q4CtxBzrFZyGKkRJUDIi,HQmDERMFjx,LHX65I9nkx0PstgcVY24uSi(u"࠲࠲࠻࠸࣫"))
	CfgK4s13Q0hZcHyleT2bVJO9(KhUG1NV9bln5zXjptqFW6dgo(u"ࠫࡱ࡯࡮࡬ࠩࡍ"),ao3Q5jP8H0sMxK2iUYwZGE+SODvU3Ibq5VzC(u"ࠬࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫࡎ")+cjqzOQ5GXD4kR,HQmDERMFjx,ShnRVsifKtc60zqQ(u"࠻࠼࠽࠾࣬"))
	CfgK4s13Q0hZcHyleT2bVJO9(owbMhINBQsmx70guApW(u"࠭࡬ࡪࡰ࡮ࠫࡏ"),EEJvXQzSZNt+maUl7SPesynF1j(u"ࠧๆีะࠤฺ๎ัࠡษ็็ฯอศสࠩࡐ")+Dl2CStgBcOJWIV,HQmDERMFjx,OBsrtQo2pPlgURCxJYbj9iXMD(u"࠴࠴࠽࠷࣭"))
	CfgK4s13Q0hZcHyleT2bVJO9(JJA7fypmZFVlazvNI(u"ࠨ࡮࡬ࡲࡰ࠭ࡑ"),EEJvXQzSZNt+SODvU3Ibq5VzC(u"่ࠩืาࠦใศึࠣห้ฮั็ษ่ะࠬࡒ")+V2BYOtuyW9U,HQmDERMFjx,ShnRVsifKtc60zqQ(u"࠵࠵࠾࠲࣮"))
	CfgK4s13Q0hZcHyleT2bVJO9(C3ZK1pu4rfmj8TsWUtBaM(u"ࠪࡰ࡮ࡴ࡫ࠨࡓ"),EEJvXQzSZNt+ShnRVsifKtc60zqQ(u"ู๊ࠫอࠡว฼ำฬีวหࠢส่อืๆศ็ฯࠫࡔ")+CZFXa7H2Vm1R38zWM,HQmDERMFjx,dBi72erQEtKDOwjNFaoAgSP(u"࠶࠶࠸࠴࣯"))
	CfgK4s13Q0hZcHyleT2bVJO9(LHX65I9nkx0PstgcVY24uSi(u"ࠬࡲࡩ࡯࡭ࠪࡕ"),EEJvXQzSZNt+mgLADoQ1pbtY(u"࠭สึใํีࠥอไษำ้ห๊าࠧࡖ")+ogPhLb7Q4CtxBzrFZyGKkRJUDIi,HQmDERMFjx,dBi72erQEtKDOwjNFaoAgSP(u"࠷࠰࠹࠶ࣰ"))
	return
def GXByaJAOkt7Lje29Zpsh():
	t6tJ29yhBeaVsvWlDZdQU1R3fMOu,a6E8WX2Hn0crdoY4VvfhQP = vOtSPQH7TR(oojO6D8vCQSEnJLPUmT)
	dnu6Gp8Itao5DC7Eiec,oDemyqGKAY8InVr4lji = vOtSPQH7TR(ZJnt2LjW1uEicQYV0Al85)
	aSN63s7WnvTepMyk8PIQlJVbqcf,BhHXjVQoKGpIzkiRYFdSrtPbm = vOtSPQH7TR(z9zBcODbrIhtsGXiWCKmln4TN2)
	CBH4DrlhJOkzw95LiTYu1oFVesayfA,kOypuZXLK2MQf6v = e6eB5OgKHw4kf1C73IJWNZqAPRbyn(vvGwhVNk2pEiHmulxbFWc4XeMY)
	CBH4DrlhJOkzw95LiTYu1oFVesayfA -= dBi72erQEtKDOwjNFaoAgSP(u"࠳࠷࠺࠹࠸ࣱ")
	kOypuZXLK2MQf6v -= CH7RKuDVzN9f06q8MtXPhlvIxakEWg
	sqfoI1aVJtUi8RnEedA = str(S9Y5kUoRga3EVN.listdir(Mv2yGnEOJR67h5Wa))
	uuUY56rn1wOZXpEgsLC3G9HS8KicVo = sqfoI1aVJtUi8RnEedA.count(KKi79PFqsYB0dWSRgaJ3DyE(u"ࠧ࡬ࡱࡧ࡭ࡤࡹࡴࡢࡥ࡮ࡸࡷࡧࡣࡦࠩࡗ"))+sqfoI1aVJtUi8RnEedA.count(EF2tvxZHz5n4UruPhaViXKycI6SQR(u"ࠨ࡭ࡲࡨ࡮ࡥࡣࡳࡣࡶ࡬ࡱࡵࡧࠨࡘ"))
	Dl2CStgBcOJWIV = JJA7fypmZFVlazvNI(u"࡙ࠩࠣࠬࠬ")+L0N7IT3P9omAf2C8RjdSlxJv6rqKzU(t6tJ29yhBeaVsvWlDZdQU1R3fMOu)+jL1E5AKfwBDv6xmeQtUXcJ3d(u"ࠪࠤ࠲࡚ࠦࠧ")+str(a6E8WX2Hn0crdoY4VvfhQP)+ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࡛࠭ࠬ")
	V2BYOtuyW9U = knTyjJ0sGIzuwbxRae(u"ࠬࠦࠨࠨ࡜")+L0N7IT3P9omAf2C8RjdSlxJv6rqKzU(dnu6Gp8Itao5DC7Eiec)+KhUG1NV9bln5zXjptqFW6dgo(u"࠭ࠠ࠮ࠢࠪ࡝")+str(oDemyqGKAY8InVr4lji)+KhUG1NV9bln5zXjptqFW6dgo(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨ࡞")
	CZFXa7H2Vm1R38zWM = n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"ࠨࠢࠫࠫ࡟")+L0N7IT3P9omAf2C8RjdSlxJv6rqKzU(aSN63s7WnvTepMyk8PIQlJVbqcf)+cWbkR6iUZsnJQj14(u"ࠩࠣ࠱ࠥ࠭ࡠ")+str(BhHXjVQoKGpIzkiRYFdSrtPbm)+maUl7SPesynF1j(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࡡ")
	ogPhLb7Q4CtxBzrFZyGKkRJUDIi = JJA7fypmZFVlazvNI(u"ࠫࠥ࠮ࠧࡢ")+L0N7IT3P9omAf2C8RjdSlxJv6rqKzU(CBH4DrlhJOkzw95LiTYu1oFVesayfA)+KKi79PFqsYB0dWSRgaJ3DyE(u"ࠬ࠯ࠧࡣ")
	FTsYfR1htBSid5 = OBsrtQo2pPlgURCxJYbj9iXMD(u"࠭ࠠࠩࠩࡤ")+str(uuUY56rn1wOZXpEgsLC3G9HS8KicVo)+OzU6t0qcH7MQabeBYK8vgoG(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨࡥ")
	YDwjEeScqd1o2G6xUaf = t6tJ29yhBeaVsvWlDZdQU1R3fMOu+dnu6Gp8Itao5DC7Eiec+aSN63s7WnvTepMyk8PIQlJVbqcf+CBH4DrlhJOkzw95LiTYu1oFVesayfA
	BB5K8NCkstbxORuAm = a6E8WX2Hn0crdoY4VvfhQP+oDemyqGKAY8InVr4lji+BhHXjVQoKGpIzkiRYFdSrtPbm+kOypuZXLK2MQf6v+uuUY56rn1wOZXpEgsLC3G9HS8KicVo
	NN9niuC7RoqmhkL2 = YJxaX0MQOHb8oyCBFdnIAe(u"ࠨࠢࠫࠫࡦ")+L0N7IT3P9omAf2C8RjdSlxJv6rqKzU(YDwjEeScqd1o2G6xUaf)+knTyjJ0sGIzuwbxRae(u"ࠩࠣ࠱ࠥ࠭ࡧ")+str(BB5K8NCkstbxORuAm)+JJA7fypmZFVlazvNI(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࡨ")
	CfgK4s13Q0hZcHyleT2bVJO9(KKi79PFqsYB0dWSRgaJ3DyE(u"ࠫࡱ࡯࡮࡬ࠩࡩ"),EEJvXQzSZNt+KhUG1NV9bln5zXjptqFW6dgo(u"๋ࠬำฮࠢส่ัฺ๋๊ࠩࡪ")+NN9niuC7RoqmhkL2,HQmDERMFjx,nz8x32hX0qcjUPFZk5RdJsiwED(u"࠸࠶࠸ࣲ"))
	CfgK4s13Q0hZcHyleT2bVJO9(EAVanJj1ers2GQud(u"࠭࡬ࡪࡰ࡮ࠫ࡫"),ao3Q5jP8H0sMxK2iUYwZGE+EF2tvxZHz5n4UruPhaViXKycI6SQR(u"ࠧࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥ࠭࡬")+cjqzOQ5GXD4kR,HQmDERMFjx,KKi79PFqsYB0dWSRgaJ3DyE(u"࠻࠼࠽࠾ࣳ"))
	CfgK4s13Q0hZcHyleT2bVJO9(PPAUFrY8cduRT(u"ࠨ࡮࡬ࡲࡰ࠭࡭"),EEJvXQzSZNt+C3ZK1pu4rfmj8TsWUtBaM(u"่ࠩืาࠦวๅ็็ๅฬะࠠศๆ่ศ็ะษࠨ࡮")+Dl2CStgBcOJWIV,HQmDERMFjx,mg3CbXMA2ouZzQDhRqB(u"࠺࠸࠶ࣴ"))
	CfgK4s13Q0hZcHyleT2bVJO9(k4IUieraScH9DV1N7pJgQosYAx5l(u"ࠪࡰ࡮ࡴ࡫ࠨ࡯"),EEJvXQzSZNt+EAVanJj1ers2GQud(u"ู๊ࠫอࠡษ็้้็วหࠢส่๊฼ฺู้ฬࠫࡰ")+V2BYOtuyW9U,HQmDERMFjx,SODvU3Ibq5VzC(u"࠻࠹࠸ࣵ"))
	CfgK4s13Q0hZcHyleT2bVJO9(OzU6t0qcH7MQabeBYK8vgoG(u"ࠬࡲࡩ࡯࡭ࠪࡱ"),EEJvXQzSZNt+KKi79PFqsYB0dWSRgaJ3DyE(u"࠭ๅิฯࠣห้฻่าࠢส่็ี๊ๆหࠪࡲ")+CZFXa7H2Vm1R38zWM,HQmDERMFjx,EF2tvxZHz5n4UruPhaViXKycI6SQR(u"࠼࠺࠳ࣶ"))
	CfgK4s13Q0hZcHyleT2bVJO9(maUl7SPesynF1j(u"ࠧ࡭࡫ࡱ࡯ࠬࡳ"),EEJvXQzSZNt+OBsrtQo2pPlgURCxJYbj9iXMD(u"ࠨฬไี๏เࠠๆๆไࠤฺ๎ัࠡษ็ษ฻อแศฬࠪࡴ")+ogPhLb7Q4CtxBzrFZyGKkRJUDIi,HQmDERMFjx,PPAUFrY8cduRT(u"࠽࠴࠵ࣷ"))
	CfgK4s13Q0hZcHyleT2bVJO9(YJxaX0MQOHb8oyCBFdnIAe(u"ࠩ࡯࡭ࡳࡱࠧࡵ"),EEJvXQzSZNt+KKi79PFqsYB0dWSRgaJ3DyE(u"ุ้ࠪำࠠๆๆไหฯࠦวๅๅิหูࠦวๅ็วๆฯฯࠧࡶ")+FTsYfR1htBSid5,HQmDERMFjx,maUl7SPesynF1j(u"࠷࠵࠸ࣸ"))
	return
def Vcr4ZbFoaznP3UXm0efEyWRxCdS7():
	Hb4XCUQpIgJDrvAefG12LaZON8 = gyd2rf0UR5 if xufJqQcGnhboiVy2wd in vZmS3d7AaDN5JsGqPTgxOpVBFw else mic3MEN709xOkrjD5ZvbGIlX6
	if not Hb4XCUQpIgJDrvAefG12LaZON8:
		u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,knTyjJ0sGIzuwbxRae(u"ࠫ฾๋ไ๋หࠣฮ๋฾๊โࠢส่ัํวำ่ࠢฮํ็ัสࠢไๆ฼ࠦไฤฮ๊ึฮ๊้่ࠦๆืࠥ࠴࠮ࠡ็ฮ่ࠥษฬ่ิฬࠤศฮไ๊ࠡฦ๊ิื่๋ัࠣ์้๐่็ๅึࠤ࠳࠴้ࠠฮ๊หื้ࠠๅ์ึࠤ๊์่ࠠาสࠤฬ๊ๆ้฻ࠪࡷ"))
		return
	f5wgXJnMDPSpRmzCGF1YZ = H8jfvMtXa7Neiu.getSetting(n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡴࡨࡪࡷ࡫ࡳࡩࠩࡸ"))
	if not f5wgXJnMDPSpRmzCGF1YZ: ExkuhKpBSAJ9gyPbsr()
	t6tJ29yhBeaVsvWlDZdQU1R3fMOu,a6E8WX2Hn0crdoY4VvfhQP = vOtSPQH7TR(wJW2ZeR7EVaPxr8i4)
	dnu6Gp8Itao5DC7Eiec,oDemyqGKAY8InVr4lji = vOtSPQH7TR(ob1cgWZjzJa)
	aSN63s7WnvTepMyk8PIQlJVbqcf,BhHXjVQoKGpIzkiRYFdSrtPbm = vOtSPQH7TR(mmYt16qr8XFD5Sb4RL7K)
	CBH4DrlhJOkzw95LiTYu1oFVesayfA,kOypuZXLK2MQf6v = vOtSPQH7TR(iQIyhetTEcZgk3LzudAs5O8U0p4fWD)
	iYrsQ48P0xn,uuUY56rn1wOZXpEgsLC3G9HS8KicVo = vOtSPQH7TR(RFEDIj2zMHnud5yGXUt0)
	c12KFagrXOZvp4jnlMDLb5JEP,PcspBC2mMkNfJvbIVWX9Gw8u0rey4E = vOtSPQH7TR(hSxaeOj80Hyd)
	Dl2CStgBcOJWIV = U0VwOviFaYPz2QGs45mJhMXf7Zk(u"࠭ࠠࠩࠩࡹ")+L0N7IT3P9omAf2C8RjdSlxJv6rqKzU(t6tJ29yhBeaVsvWlDZdQU1R3fMOu)+maUl7SPesynF1j(u"ࠧࠡ࠯ࠣࠫࡺ")+str(a6E8WX2Hn0crdoY4VvfhQP)+OzU6t0qcH7MQabeBYK8vgoG(u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩࡻ")
	V2BYOtuyW9U = JJA7fypmZFVlazvNI(u"ࠩࠣࠬࠬࡼ")+L0N7IT3P9omAf2C8RjdSlxJv6rqKzU(dnu6Gp8Itao5DC7Eiec)+HDpmv4UXzlf72SK9(u"ࠪࠤ࠲ࠦࠧࡽ")+str(oDemyqGKAY8InVr4lji)+SODvU3Ibq5VzC(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬࡾ")
	CZFXa7H2Vm1R38zWM = jL1E5AKfwBDv6xmeQtUXcJ3d(u"ࠬࠦࠨࠨࡿ")+L0N7IT3P9omAf2C8RjdSlxJv6rqKzU(aSN63s7WnvTepMyk8PIQlJVbqcf)+X2crmy67eZpkGTRd(u"࠭ࠠ࠮ࠢࠪࢀ")+str(BhHXjVQoKGpIzkiRYFdSrtPbm)+Tcf5Ppn9UajDbzyM(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨࢁ")
	ogPhLb7Q4CtxBzrFZyGKkRJUDIi = mgLADoQ1pbtY(u"ࠨࠢࠫࠫࢂ")+L0N7IT3P9omAf2C8RjdSlxJv6rqKzU(CBH4DrlhJOkzw95LiTYu1oFVesayfA)+knTyjJ0sGIzuwbxRae(u"ࠩࠣ࠱ࠥ࠭ࢃ")+str(kOypuZXLK2MQf6v)+pCTzbw4GyVJHjkcIMQ(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࢄ")
	FTsYfR1htBSid5 = A0aqj9uclgOtByJ6F4bz(u"ࠫࠥ࠮ࠧࢅ")+L0N7IT3P9omAf2C8RjdSlxJv6rqKzU(iYrsQ48P0xn)+mgLADoQ1pbtY(u"ࠬࠦ࠭ࠡࠩࢆ")+str(uuUY56rn1wOZXpEgsLC3G9HS8KicVo)+knTyjJ0sGIzuwbxRae(u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧࢇ")
	qcUY8zoFMhirQC = owbMhINBQsmx70guApW(u"ࠧࠡࠪࠪ࢈")+L0N7IT3P9omAf2C8RjdSlxJv6rqKzU(c12KFagrXOZvp4jnlMDLb5JEP)+KhUG1NV9bln5zXjptqFW6dgo(u"ࠨࠢ࠰ࠤࠬࢉ")+str(PcspBC2mMkNfJvbIVWX9Gw8u0rey4E)+ShnRVsifKtc60zqQ(u"ࠩࠣࡪ࡮ࡲࡥࡴࠫࠪࢊ")
	YDwjEeScqd1o2G6xUaf = t6tJ29yhBeaVsvWlDZdQU1R3fMOu+dnu6Gp8Itao5DC7Eiec+aSN63s7WnvTepMyk8PIQlJVbqcf+CBH4DrlhJOkzw95LiTYu1oFVesayfA+iYrsQ48P0xn+c12KFagrXOZvp4jnlMDLb5JEP
	BB5K8NCkstbxORuAm = a6E8WX2Hn0crdoY4VvfhQP+oDemyqGKAY8InVr4lji+BhHXjVQoKGpIzkiRYFdSrtPbm+kOypuZXLK2MQf6v+uuUY56rn1wOZXpEgsLC3G9HS8KicVo+PcspBC2mMkNfJvbIVWX9Gw8u0rey4E
	NN9niuC7RoqmhkL2 = YJxaX0MQOHb8oyCBFdnIAe(u"ࠪࠤ࠭࠭ࢋ")+L0N7IT3P9omAf2C8RjdSlxJv6rqKzU(YDwjEeScqd1o2G6xUaf)+mg3CbXMA2ouZzQDhRqB(u"ࠫࠥ࠳ࠠࠨࢌ")+str(BB5K8NCkstbxORuAm)+owbMhINBQsmx70guApW(u"ࠬࠦࡦࡪ࡮ࡨࡷ࠮࠭ࢍ")
	CfgK4s13Q0hZcHyleT2bVJO9(mg3CbXMA2ouZzQDhRqB(u"࠭࡬ࡪࡰ࡮ࠫࢎ"),EEJvXQzSZNt+n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"ࠧฦ฻ฺหฦࠦัฯืฬࠤ็ืวยหࠣ์่ะวษหࠪ࢏"),HQmDERMFjx,PPAUFrY8cduRT(u"࠸࠷࠻ࣹ"))
	CfgK4s13Q0hZcHyleT2bVJO9(PPAUFrY8cduRT(u"ࠨ࡮࡬ࡲࡰ࠭࢐"),EEJvXQzSZNt+CDwSWB4v39N7(u"่ࠩืาࠦวๅฮ่๎฾࠭࢑")+NN9niuC7RoqmhkL2,HQmDERMFjx,cWbkR6iUZsnJQj14(u"࠹࠸࠻ࣺ"))
	CfgK4s13Q0hZcHyleT2bVJO9(n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"ࠪࡰ࡮ࡴ࡫ࠨ࢒"),ao3Q5jP8H0sMxK2iUYwZGE+HDpmv4UXzlf72SK9(u"ࠫࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࠪ࢓")+cjqzOQ5GXD4kR,HQmDERMFjx,C3ZK1pu4rfmj8TsWUtBaM(u"࠼࠽࠾࠿ࣻ"))
	CfgK4s13Q0hZcHyleT2bVJO9(JJA7fypmZFVlazvNI(u"ࠬࡲࡩ࡯࡭ࠪ࢔"),EEJvXQzSZNt+EAVanJj1ers2GQud(u"࠭ๅิฯ้้ࠣ็วหࠢࡸࡷࡦ࡭ࡥࡴࡶࡤࡸࡸ࠭࢕")+Dl2CStgBcOJWIV,HQmDERMFjx,pCTzbw4GyVJHjkcIMQ(u"࠻࠺࠷ࣼ"))
	CfgK4s13Q0hZcHyleT2bVJO9(ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"ࠧ࡭࡫ࡱ࡯ࠬ࢖"),EEJvXQzSZNt+ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"ࠨ็ึั๋ࠥไโษอࠤࡩࡸ࡯ࡱࡤࡲࡼࠬࢗ")+V2BYOtuyW9U,HQmDERMFjx,k4IUieraScH9DV1N7pJgQosYAx5l(u"࠼࠻࠲ࣽ"))
	CfgK4s13Q0hZcHyleT2bVJO9(X2crmy67eZpkGTRd(u"ࠩ࡯࡭ࡳࡱࠧ࢘"),EEJvXQzSZNt+YJxaX0MQOHb8oyCBFdnIAe(u"ุ้ࠪำࠠๆๆไหฯࠦࡴࡰ࡯ࡥࡷࡹࡵ࡮ࡦࡵ࢙ࠪ")+CZFXa7H2Vm1R38zWM,HQmDERMFjx,n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"࠽࠵࠴ࣾ"))
	CfgK4s13Q0hZcHyleT2bVJO9(KKi79PFqsYB0dWSRgaJ3DyE(u"ࠫࡱ࡯࡮࡬࢚ࠩ"),EEJvXQzSZNt+X2crmy67eZpkGTRd(u"๋ࠬำฮ่่ࠢๆอสࠡ࡮ࡲ࡫࡬࡫ࡲࠨ࢛")+ogPhLb7Q4CtxBzrFZyGKkRJUDIi,HQmDERMFjx,SODvU3Ibq5VzC(u"࠷࠶࠶ࣿ"))
	CfgK4s13Q0hZcHyleT2bVJO9(X2crmy67eZpkGTRd(u"࠭࡬ࡪࡰ࡮ࠫ࢜"),EEJvXQzSZNt+owbMhINBQsmx70guApW(u"ࠧๆีะࠤ๊๊แศฬࠣࡰࡴ࡭ࠧ࢝")+FTsYfR1htBSid5,HQmDERMFjx,EAVanJj1ers2GQud(u"࠸࠷࠸ऀ"))
	CfgK4s13Q0hZcHyleT2bVJO9(Tcf5Ppn9UajDbzyM(u"ࠨ࡮࡬ࡲࡰ࠭࢞"),EEJvXQzSZNt+U0VwOviFaYPz2QGs45mJhMXf7Zk(u"่ࠩืาࠦๅๅใสฮࠥࡧ࡮ࡳࠩ࢟")+qcUY8zoFMhirQC,HQmDERMFjx,n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"࠹࠸࠺ँ"))
	return
def Ljhuo34nlQtFCR(showDialogs):
	if showDialogs: u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,KhUG1NV9bln5zXjptqFW6dgo(u"้ࠪั๊ฯࠡื๋ี้ࠥสศสฬࠤฬ๊โ้ษษ้ࠥ࠴࠮้ࠡำหࠥอไๆฮ็ำࠥ็๊่ࠢห฽฻ࠦโ้ษษ้ࠥอไษำ้ห๊าࠠๆะี๊ฮࠦศีๅ็ࠤฺ๎ัࠡสา่ฬࠦๅ็ࠢส่่ะวษหࠣ࠲࠳ูࠦ็ัุ้ࠣำࠠศๆ่ะ้ีࠠิ์ๅ์๊ࠦวๅสิ๊ฬ๋ฬࠡสั่็ࠦๅอๆาࠤัี๊ะ๋ࠢ๎อีรࠡ็ิอࠥษฮา๋ࠣฬ๊๊ฦ่ࠢหห้฻่าࠢ฼๊ิࠦแหฯࠣห้่่ศศ่ࠫࢠ"))
	muEW2VQDlGr,p7pXl59WRD8keNC = [],o4bNzIQGYj8En
	for rpYAODZRXq3sFBNd,R2d9VbWvJNBo5gpi,r2CoU9Fejs5uGH8S in S9Y5kUoRga3EVN.walk(GnBJi17tQ4ukplr,topdown=mic3MEN709xOkrjD5ZvbGIlX6):
		lQi5GVCEqK2I3T4x = len(r2CoU9Fejs5uGH8S)
		if lQi5GVCEqK2I3T4x>A0aqj9uclgOtByJ6F4bz(u"࠸࠴࠵ं"): muEW2VQDlGr.append(R2d9VbWvJNBo5gpi)
		p7pXl59WRD8keNC += lQi5GVCEqK2I3T4x
	XsQzGhyO0wu7jUnDopeCBR6v2Sf = p7pXl59WRD8keNC>ShnRVsifKtc60zqQ(u"࠹࠵࠶࠰ः")
	if showDialogs:
		count = ao3Q5jP8H0sMxK2iUYwZGE+A0aqj9uclgOtByJ6F4bz(u"้ࠫี๊ไࠢࠣࠫࢡ")+str(p7pXl59WRD8keNC)+pCTzbw4GyVJHjkcIMQ(u"ࠬࠦࠠึ๊ิอࠬࢢ")+cjqzOQ5GXD4kR
		if not muEW2VQDlGr and not XsQzGhyO0wu7jUnDopeCBR6v2Sf: N7gs9UBCeDR3 = HUJZy0SrTbBYv1(HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,k4IUieraScH9DV1N7pJgQosYAx5l(u"࠭ไศࠢํ์ัีฺ่ࠠา็ࠥ฻่าࠢๆฮฬฮษࠡๅฮ๎ึฯࠠ࠯࠰ࠣ์้ํะศࠢ็หࠥะอหษฯࠤศ์ࠠห็ึัࠥ฻่าࠢส่่ะวษหࠣ࠲࠳ࠦ็ๅࠢอี๏ีࠠๆีะࠤฺ๎ัࠡษ็็ฯอศสࠢส่ว์ࠠภࠣࠣࡠࡳࡢ࡮ࠨࢣ")+count)
		else: N7gs9UBCeDR3 = HUJZy0SrTbBYv1(HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,EF2tvxZHz5n4UruPhaViXKycI6SQR(u"ࠧๅัํ็ࠥ฻่าࠢๆฮฬฮษࠡๅฮ๎ึฯࠠ࠯࠰ࠣ์์ึวࠡไาࠤ๏ูศษุ่ࠢฬ้ไࠡใํࠤฯฺฺ๋ๆࠣห้า็ศิࠣ์ฯฺฺ๋ๆࠣฬึ์วๆฮࠣ฽๊อฯࠡ࠰࠱ࠤศ์สࠡสะหัฯࠠฦๆ์ࠤู๊อ้ࠡำ๋ࠥอไึ๊ิࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡ็ึัࠥ฻่าࠢส่่ะวษหࠣห้ศๆࠡมࠤࠤࡡࡴ࡜࡯ࠩࢤ")+count)
	else: N7gs9UBCeDR3 = CH7RKuDVzN9f06q8MtXPhlvIxakEWg
	if N7gs9UBCeDR3==CH7RKuDVzN9f06q8MtXPhlvIxakEWg:
		if XsQzGhyO0wu7jUnDopeCBR6v2Sf: Nam0DyfXK5(rpYAODZRXq3sFBNd,mic3MEN709xOkrjD5ZvbGIlX6,mic3MEN709xOkrjD5ZvbGIlX6)
		elif muEW2VQDlGr:
			for R2d9VbWvJNBo5gpi in muEW2VQDlGr: Nam0DyfXK5(R2d9VbWvJNBo5gpi,mic3MEN709xOkrjD5ZvbGIlX6,mic3MEN709xOkrjD5ZvbGIlX6)
	return
def ExkuhKpBSAJ9gyPbsr():
	EPJnGfmr9p6wZ5WaL4XtdHjkUi = mic3MEN709xOkrjD5ZvbGIlX6
	N7gs9UBCeDR3 = HUJZy0SrTbBYv1(HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,EAVanJj1ers2GQud(u"ࠨๆๆ๎ࠥ๐ูๆๆࠣห้ะๆู์ไࠤ฾์ฯไࠢ࠱࠲ࠥฮั็ษ่ะࠥ฿ๅศัࠣฬาอฬสࠢศ่๎ࠦลฺูสลࠥืฮึหࠣห้่ัศรฬࠤํอไไฬสฬฮࠦไๅ็็ๅฬะ้ࠠษ็้ั๊ฯศฬࠣห้ะ๊ࠡี๋ๅࠥ๐ๅิฯ๊หࠥอไษำ้ห๊าࠠ࠯࠰๋้ࠣࠦสา์าࠤส฿ืศร๋ࠣีํࠠศๆิาฺฯࠠศๆล๊ࠥลࠡࠨࢥ"))
	if N7gs9UBCeDR3==-n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"࠶ऄ"): return
	if N7gs9UBCeDR3:
		import subprocess as uWlqH5fEPsRQ1kMKU
		try:
			uWlqH5fEPsRQ1kMKU.Popen(LHX65I9nkx0PstgcVY24uSi(u"ࠩࡶࡹࠬࢦ"))
			EPJnGfmr9p6wZ5WaL4XtdHjkUi = gyd2rf0UR5
		except: pass
		if EPJnGfmr9p6wZ5WaL4XtdHjkUi:
			dfjxKDMQpNqBmAX7ayi6ThZsL = wJW2ZeR7EVaPxr8i4+oQpxmKiRPlHeGsLXNrJF78O+ob1cgWZjzJa+oQpxmKiRPlHeGsLXNrJF78O+mmYt16qr8XFD5Sb4RL7K+oQpxmKiRPlHeGsLXNrJF78O+iQIyhetTEcZgk3LzudAs5O8U0p4fWD+oQpxmKiRPlHeGsLXNrJF78O+RFEDIj2zMHnud5yGXUt0+oQpxmKiRPlHeGsLXNrJF78O+hSxaeOj80Hyd
			OK87F1JMTaUnkV = uWlqH5fEPsRQ1kMKU.Popen(CDwSWB4v39N7(u"ࠪࡷࡺࠦ࠭ࡤࠢࠥࡧ࡭ࡳ࡯ࡥࠢ࠰ࡖࠥ࠶࠷࠸࠹ࠣࠫࢧ")+dfjxKDMQpNqBmAX7ayi6ThZsL+SODvU3Ibq5VzC(u"ࠫࠧ࠭ࢨ"),shell=gyd2rf0UR5,stdin=uWlqH5fEPsRQ1kMKU.PIPE,stdout=uWlqH5fEPsRQ1kMKU.PIPE,stderr=uWlqH5fEPsRQ1kMKU.PIPE)
			u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,PPAUFrY8cduRT(u"ࠬ์ฬฮฬࠣ฽๊๊๊สࠢศ฽฼อมࠡษ็ีำ฻ษࠨࢩ"))
		else: u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,owbMhINBQsmx70guApW(u"ู࠭ๆๆํอࠥหูุษฤࠤึิีสࠢส่็ืวยหࠣ์ฬ๊ใหษหอࠥะอหษฯࠤอืๆศ็ฯࠤࠥࡸ࡯ࡰࡶࠣࠤศ๎ࠠࠡࡵࡸࡴࡪࡸࡵࡴࡧࡵࠤࠥษ่ࠡࠢࡶࡹ่ࠥࠦอ้สึ่ࠦไศࠢํ์ัีࠠโ์๊ࠤ์ึวࠡษ็ฬึ์วๆฮࠣ࠲࠳ࠦร้ࠢๆ์ิ๐ࠠ฻์ิࠤ็อฯาࠢ฼่๎ࠦวิฬัำฬ๋่ࠠาสࠤฬ๊ศา่ส้ั࠭ࢪ"))
	return EPJnGfmr9p6wZ5WaL4XtdHjkUi
def L0N7IT3P9omAf2C8RjdSlxJv6rqKzU(YDwjEeScqd1o2G6xUaf):
	for tfDSQhVJorIjuY3L0s1NMynTGcqzd in [dBi72erQEtKDOwjNFaoAgSP(u"ࠧࡃࠩࢫ"),YJxaX0MQOHb8oyCBFdnIAe(u"ࠨࡍࡅࠫࢬ"),HDpmv4UXzlf72SK9(u"ࠩࡐࡆࠬࢭ"),ELfMeDTIFhJt685K(u"ࠪࡋࡇ࠭ࢮ"),dBi72erQEtKDOwjNFaoAgSP(u"࡙ࠫࡈࠧࢯ")]:
		if YDwjEeScqd1o2G6xUaf<ELfMeDTIFhJt685K(u"࠷࠰࠳࠶अ"): break
		else: YDwjEeScqd1o2G6xUaf /= PPAUFrY8cduRT(u"࠱࠱࠴࠷࠲࠵आ")
	NN9niuC7RoqmhkL2 = C3ZK1pu4rfmj8TsWUtBaM(u"ࠧࠫ࠳࠯࠳ࡩࠤࠪࡹࠢࢰ")%(YDwjEeScqd1o2G6xUaf,tfDSQhVJorIjuY3L0s1NMynTGcqzd)
	return NN9niuC7RoqmhkL2
def vOtSPQH7TR(Gst4CjUry05mTPwMioVagp=U0VwOviFaYPz2QGs45mJhMXf7Zk(u"࠭࠮ࠨࢱ")):
	global ygS19rWUHKsCbqZcLG8Ei2uxhpX7,Ew4AhejV0Rk8lTWIuJ5cPYdOUMZQg
	ygS19rWUHKsCbqZcLG8Ei2uxhpX7,Ew4AhejV0Rk8lTWIuJ5cPYdOUMZQg = o4bNzIQGYj8En,o4bNzIQGYj8En
	def ILzXb8akciZQ6(Gst4CjUry05mTPwMioVagp):
		global ygS19rWUHKsCbqZcLG8Ei2uxhpX7,Ew4AhejV0Rk8lTWIuJ5cPYdOUMZQg
		if S9Y5kUoRga3EVN.path.exists(Gst4CjUry05mTPwMioVagp):
			if o4bNzIQGYj8En and EF2tvxZHz5n4UruPhaViXKycI6SQR(u"ࠧࡴࡥࡤࡲࡩ࡯ࡲࠨࢲ") in dir(S9Y5kUoRga3EVN):
				for V5Zz7ohcdSG2mFxHwYqW9t1XIK4Njr in S9Y5kUoRga3EVN.scandir(Gst4CjUry05mTPwMioVagp):
					if V5Zz7ohcdSG2mFxHwYqW9t1XIK4Njr.is_dir(follow_symlinks=mic3MEN709xOkrjD5ZvbGIlX6):
						ILzXb8akciZQ6(V5Zz7ohcdSG2mFxHwYqW9t1XIK4Njr.path)
					elif V5Zz7ohcdSG2mFxHwYqW9t1XIK4Njr.is_file(follow_symlinks=mic3MEN709xOkrjD5ZvbGIlX6):
						ygS19rWUHKsCbqZcLG8Ei2uxhpX7 += V5Zz7ohcdSG2mFxHwYqW9t1XIK4Njr.stat().st_size
						Ew4AhejV0Rk8lTWIuJ5cPYdOUMZQg += CH7RKuDVzN9f06q8MtXPhlvIxakEWg
			else:
				for V5Zz7ohcdSG2mFxHwYqW9t1XIK4Njr in S9Y5kUoRga3EVN.listdir(Gst4CjUry05mTPwMioVagp):
					xv7wPnLyOWupNKj8R4asVQGTe0 = S9Y5kUoRga3EVN.path.abspath(S9Y5kUoRga3EVN.path.join(Gst4CjUry05mTPwMioVagp,V5Zz7ohcdSG2mFxHwYqW9t1XIK4Njr))
					if S9Y5kUoRga3EVN.path.isdir(xv7wPnLyOWupNKj8R4asVQGTe0):
						ILzXb8akciZQ6(xv7wPnLyOWupNKj8R4asVQGTe0)
					elif S9Y5kUoRga3EVN.path.isfile(xv7wPnLyOWupNKj8R4asVQGTe0):
						YDwjEeScqd1o2G6xUaf,BB5K8NCkstbxORuAm = e6eB5OgKHw4kf1C73IJWNZqAPRbyn(xv7wPnLyOWupNKj8R4asVQGTe0)
						ygS19rWUHKsCbqZcLG8Ei2uxhpX7 += YDwjEeScqd1o2G6xUaf
						Ew4AhejV0Rk8lTWIuJ5cPYdOUMZQg += BB5K8NCkstbxORuAm
		return
	try: ILzXb8akciZQ6(Gst4CjUry05mTPwMioVagp)
	except: pass
	return ygS19rWUHKsCbqZcLG8Ei2uxhpX7,Ew4AhejV0Rk8lTWIuJ5cPYdOUMZQg
def e6hpcV8Il2AzvYr1agbGwdKB(showDialogs):
	if showDialogs:
		N7gs9UBCeDR3 = HUJZy0SrTbBYv1(HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,ao3Q5jP8H0sMxK2iUYwZGE+n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"ࠨ้็ࠤฯื๊ะ่ࠢืา࠭ࢳ")+ti3SbXNV0aJ7n5Grc4OQY8Ll1s9+C3ZK1pu4rfmj8TsWUtBaM(u"่ࠩะ้ีࠠศๆ่่ๆอสࠡษ็้ษ่สสࠢ࠱࠲ࠥ๎ๅอๆาࠤฬ๊ๅๅใสฮࠥอไๆุ฽์฼ฯࠠ࠯࠰ࠣ์๊าไะࠢสฺ่๎ัࠡษ็ๆิ๐ๅสࠢ࠱࠲ࠥ๎สโำํ฾๋ࠥไโุࠢ์ึࠦวๅวูหๆอสࠡ࠰࠱ࠤํ๋ไโษอࠤฬ๊ใาษืࠫࢴ")+ti3SbXNV0aJ7n5Grc4OQY8Ll1s9+KKi79PFqsYB0dWSRgaJ3DyE(u"ࠪรࠦࠧࠧࢵ")+cjqzOQ5GXD4kR)
		if N7gs9UBCeDR3!=CH7RKuDVzN9f06q8MtXPhlvIxakEWg: return
	vSQmi7q0L9tH6WVM1 = Nam0DyfXK5(oojO6D8vCQSEnJLPUmT,gyd2rf0UR5,mic3MEN709xOkrjD5ZvbGIlX6)
	ySwGE1mjVgZPou3bLvhJ4DnF6flMX = Nam0DyfXK5(ZJnt2LjW1uEicQYV0Al85,gyd2rf0UR5,mic3MEN709xOkrjD5ZvbGIlX6)
	uQtlVM2Ky3nBrHhpGS5 = Nam0DyfXK5(z9zBcODbrIhtsGXiWCKmln4TN2,mic3MEN709xOkrjD5ZvbGIlX6,mic3MEN709xOkrjD5ZvbGIlX6)
	PfrLpBDMc7XlVhd = p1CDA9m0FZiokLKneX(mic3MEN709xOkrjD5ZvbGIlX6)
	pKzHqNTGOtZwcQe27 = XfMYGQ9DZhWeKCO0bA261r(mic3MEN709xOkrjD5ZvbGIlX6)
	succeeded = all([vSQmi7q0L9tH6WVM1,ySwGE1mjVgZPou3bLvhJ4DnF6flMX,uQtlVM2Ky3nBrHhpGS5,PfrLpBDMc7XlVhd,pKzHqNTGOtZwcQe27])
	if showDialogs:
		if succeeded: u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,CDwSWB4v39N7(u"ࠫฯ๋ࠠศๆ่ืาࠦศ็ฮสัࠬࢶ"))
		else: u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"๊ࠬไฤีไࠤๆฺไหࠢ฼้้๐ษࠡษ็ุ้ำࠧࢷ"))
	return succeeded
def QrBDoOAeMHvnRk(showDialogs):
	if showDialogs:
		dfjxKDMQpNqBmAX7ayi6ThZsL = wJW2ZeR7EVaPxr8i4+ti3SbXNV0aJ7n5Grc4OQY8Ll1s9+ob1cgWZjzJa+ti3SbXNV0aJ7n5Grc4OQY8Ll1s9+mmYt16qr8XFD5Sb4RL7K+ti3SbXNV0aJ7n5Grc4OQY8Ll1s9+iQIyhetTEcZgk3LzudAs5O8U0p4fWD+ti3SbXNV0aJ7n5Grc4OQY8Ll1s9+RFEDIj2zMHnud5yGXUt0+ti3SbXNV0aJ7n5Grc4OQY8Ll1s9+hSxaeOj80Hyd
		N7gs9UBCeDR3 = HUJZy0SrTbBYv1(HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,ao3Q5jP8H0sMxK2iUYwZGE+ELfMeDTIFhJt685K(u"࠭็ๅࠢอี๏ีࠠๆีะࠤฬ๊ๅๅใสฮࠥอไๆฦๅฮฮࠦวๅฬํࠤๆ๐่ࠠา๊ࠤฬ๊ๅอๆาหฯࡢ࡮࡝ࡰࠪࢸ")+dfjxKDMQpNqBmAX7ayi6ThZsL+cjqzOQ5GXD4kR)
		if N7gs9UBCeDR3!=CH7RKuDVzN9f06q8MtXPhlvIxakEWg: return
	vSQmi7q0L9tH6WVM1 = Nam0DyfXK5(wJW2ZeR7EVaPxr8i4,mic3MEN709xOkrjD5ZvbGIlX6,mic3MEN709xOkrjD5ZvbGIlX6)
	ySwGE1mjVgZPou3bLvhJ4DnF6flMX = Nam0DyfXK5(ob1cgWZjzJa,mic3MEN709xOkrjD5ZvbGIlX6,mic3MEN709xOkrjD5ZvbGIlX6)
	uQtlVM2Ky3nBrHhpGS5 = Nam0DyfXK5(mmYt16qr8XFD5Sb4RL7K,mic3MEN709xOkrjD5ZvbGIlX6,mic3MEN709xOkrjD5ZvbGIlX6)
	PfrLpBDMc7XlVhd = Nam0DyfXK5(iQIyhetTEcZgk3LzudAs5O8U0p4fWD,mic3MEN709xOkrjD5ZvbGIlX6,mic3MEN709xOkrjD5ZvbGIlX6)
	pKzHqNTGOtZwcQe27 = Nam0DyfXK5(RFEDIj2zMHnud5yGXUt0,mic3MEN709xOkrjD5ZvbGIlX6,mic3MEN709xOkrjD5ZvbGIlX6)
	Zq5b7KdUWHc = Nam0DyfXK5(hSxaeOj80Hyd,mic3MEN709xOkrjD5ZvbGIlX6,mic3MEN709xOkrjD5ZvbGIlX6)
	succeeded = all([vSQmi7q0L9tH6WVM1,ySwGE1mjVgZPou3bLvhJ4DnF6flMX,uQtlVM2Ky3nBrHhpGS5,PfrLpBDMc7XlVhd,pKzHqNTGOtZwcQe27,Zq5b7KdUWHc])
	if showDialogs:
		if succeeded: u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,OzU6t0qcH7MQabeBYK8vgoG(u"ࠧห็ࠣห้๋ำฮࠢห๊ัออࠨࢹ"))
		else: u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,pCTzbw4GyVJHjkcIMQ(u"ࠨๆ็วุ็ࠠโึ็ฮࠥ฿ๅๅ์ฬࠤฬ๊ๅิฯࠪࢺ"))
	return succeeded
def p1CDA9m0FZiokLKneX(showDialogs):
	if showDialogs:
		N7gs9UBCeDR3 = HUJZy0SrTbBYv1(HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,ao3Q5jP8H0sMxK2iUYwZGE+EAVanJj1ers2GQud(u"๊่ࠩࠥะั๋ัุ้ࠣำࠠๆฯอ์๏อสࠡ็็ๅࠥ฻่าࠢส่ั๊ฯࠡมࠤࠥࠬࢻ")+cjqzOQ5GXD4kR)
		if N7gs9UBCeDR3!=YJxaX0MQOHb8oyCBFdnIAe(u"࠲इ"): return jL1E5AKfwBDv6xmeQtUXcJ3d(u"ࡈࡤࡰࡸ࡫ई")
	try:
		succeeded = ShnRVsifKtc60zqQ(u"ࡗࡶࡺ࡫उ")
		k4JH0LWUI8KC7iDRB2xPonhjtqA = TGjo1FbB2IuhVeN985KPDJ7LZaOQ.connect(vvGwhVNk2pEiHmulxbFWc4XeMY)
		k4JH0LWUI8KC7iDRB2xPonhjtqA.text_factory = str
		qK0lfFmPQ8GCS5w3RVXz9ZyHxe = k4JH0LWUI8KC7iDRB2xPonhjtqA.cursor()
		qK0lfFmPQ8GCS5w3RVXz9ZyHxe.execute(YJxaX0MQOHb8oyCBFdnIAe(u"ࠪࡈࡊࡒࡅࡕࡇࠣࡊࡗࡕࡍࠡࡲࡤࡸ࡭ࡁࠧࢼ"))
		qK0lfFmPQ8GCS5w3RVXz9ZyHxe.execute(mgLADoQ1pbtY(u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࡶ࡭ࡿ࡫ࡳ࠼ࠩࢽ"))
		qK0lfFmPQ8GCS5w3RVXz9ZyHxe.execute(mgLADoQ1pbtY(u"ࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࡸࡪࡾࡴࡶࡴࡨ࠿ࠬࢾ"))
		k4JH0LWUI8KC7iDRB2xPonhjtqA.commit()
		qK0lfFmPQ8GCS5w3RVXz9ZyHxe.execute(maUl7SPesynF1j(u"࠭ࡖࡂࡅࡘ࡙ࡒࡁࠧࢿ"))
		k4JH0LWUI8KC7iDRB2xPonhjtqA.close()
	except: succeeded = Tcf5Ppn9UajDbzyM(u"ࡊࡦࡲࡳࡦऊ")
	if showDialogs:
		if succeeded: u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,ELfMeDTIFhJt685K(u"ࠧห็ࠣห้๋ำฮࠢห๊ัออࠨࣀ"))
		else: u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,U0VwOviFaYPz2QGs45mJhMXf7Zk(u"ࠨๆ็วุ็ࠠโึ็ฮࠥ฿ๅๅ์ฬࠤฬ๊ๅิฯࠪࣁ"))
	return succeeded
def XfMYGQ9DZhWeKCO0bA261r(showDialogs):
	if showDialogs:
		N7gs9UBCeDR3 = HUJZy0SrTbBYv1(HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,ShnRVsifKtc60zqQ(u"่่ࠩๆอสࠡษ็็ึอิ้ࠡํࠤ๊๊แศฬࠣ๎ฺ์ู่ษࠣ็ํี๊ࠡ฻้ำ๊อ๋ࠠ฼็ๆࠥ์แิ้ࠣฬฺ๎ัส่ࠢๅฬารสࠢ࠱࠲ࠥํะ่ࠢส่๊๊แศฬࠣ๎าะวอ้สࠤ๊ฮัๆฮํࠤ่๎ฯ๋ࠢะฮ๎ฺ๊ࠦำไ์๋ࠦๅ็้สࠤ่๐แࠡฯาฯฯࠦวๅ็ื็้ฯࠧࣂ")+ti3SbXNV0aJ7n5Grc4OQY8Ll1s9+ti3SbXNV0aJ7n5Grc4OQY8Ll1s9+ao3Q5jP8H0sMxK2iUYwZGE+Tcf5Ppn9UajDbzyM(u"๋้ࠪࠦสา์าࠤู๊อࠡ็็ๅฬะࠠศๆๆีฬฺࠠศๆ่ศ็ะษࠡมࠤࠥࠬࣃ")+cjqzOQ5GXD4kR)
		if N7gs9UBCeDR3!=CH7RKuDVzN9f06q8MtXPhlvIxakEWg: return mg3CbXMA2ouZzQDhRqB(u"ࡋࡧ࡬ࡴࡧऋ")
	succeeded = C3ZK1pu4rfmj8TsWUtBaM(u"࡚ࡲࡶࡧऌ")
	for file in S9Y5kUoRga3EVN.listdir(Mv2yGnEOJR67h5Wa):
		if mg3CbXMA2ouZzQDhRqB(u"ࠫࡰࡵࡤࡪࡡࡶࡸࡦࡩ࡫ࡵࡴࡤࡧࡪ࠭ࣄ") not in file and KKi79PFqsYB0dWSRgaJ3DyE(u"ࠬࡱ࡯ࡥ࡫ࡢࡧࡷࡧࡳࡩ࡮ࡲ࡫ࠬࣅ") not in file: continue
		gs30pVLP5rGm71NviuBK = S9Y5kUoRga3EVN.path.join(Mv2yGnEOJR67h5Wa,file)
		try: S9Y5kUoRga3EVN.remove(gs30pVLP5rGm71NviuBK)
		except Exception as ARl1JsfwPpXQeI:
			succeeded = Tcf5Ppn9UajDbzyM(u"ࡆࡢ࡮ࡶࡩऍ")
			if showDialogs: u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,str(ARl1JsfwPpXQeI))
	if showDialogs:
		if succeeded: u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,nz8x32hX0qcjUPFZk5RdJsiwED(u"࠭สๆࠢสู่๊อࠡส้ะฬำࠧࣆ"))
		else: u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,U0VwOviFaYPz2QGs45mJhMXf7Zk(u"ࠧๅๆฦืๆࠦแีๆอࠤ฾๋ไ๋หࠣห้๋ำฮࠩࣇ"))
	return succeeded
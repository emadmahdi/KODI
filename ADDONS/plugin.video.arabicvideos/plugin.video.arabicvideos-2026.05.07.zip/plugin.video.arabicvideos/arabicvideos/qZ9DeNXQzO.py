# -*- coding: utf-8 -*-
from FF68kA5BUy import *
HDLtdMAy7wPkl8aKC3O2 = 'CIMALIGHT'
EEJvXQzSZNt = '_CML_'
e2VR8nohduY = Jzthpc2nj5.SITESURLS[HDLtdMAy7wPkl8aKC3O2][0]
FwhZ0nXtpoHTMarf = ['قنوات فضائية']
def kk6X5LxpsND(mode,url,text):
	if   mode==470: zLZUkrP7ac5 = afkxo7FyZWB4O6K1eXrs5I()
	elif mode==471: zLZUkrP7ac5 = c8wfGju4CWZm(url,text)
	elif mode==472: zLZUkrP7ac5 = f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url)
	elif mode==473: zLZUkrP7ac5 = QQp8orwMlAa1(url,text)
	elif mode==474: zLZUkrP7ac5 = REWBU20fyqaLprY(url)
	elif mode==479: zLZUkrP7ac5 = hm4kawIPKp3oMrC75dJZA9HS2(text)
	else: zLZUkrP7ac5 = False
	return zLZUkrP7ac5
def afkxo7FyZWB4O6K1eXrs5I():
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',e2VR8nohduY,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'CIMALIGHT-MENU-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'بحث في الموقع',HQmDERMFjx,479,HQmDERMFjx,HQmDERMFjx,'_REMEMBERRESULTS_')
	CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"content"(.*?)</div>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	items = DyVGS3dX0ZxR.findall('href="(.*?)".*?</i>(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	for vn1grP3y4It9GmVuBbLJfz2A,title in items:
		title = title.replace(MSnXBQNUg1jF3W2fRlE9OLaCT8ds4,HQmDERMFjx).strip(oQpxmKiRPlHeGsLXNrJF78O)
		vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A.replace('cat=online-movies1','cat=online-movies')
		CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,474)
	CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('/category.php">(.*?)"navslide-divider"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall("'dropdown-menu'(.*?)</ul>",CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	items = DyVGS3dX0ZxR.findall('href="(.*?)".*?>(.*?)</a>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	for vn1grP3y4It9GmVuBbLJfz2A,title in items:
		if title in FwhZ0nXtpoHTMarf: continue
		if 'مسلسل ' in title: continue
		if 'برنامج ' in title: continue
		if 'للكبار' in title: continue
		CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,474)
	return
def REWBU20fyqaLprY(url):
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'CIMALIGHT-TITLES-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	if 'topvideos.php' in url: Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"caret"(.*?)id="pm-grid"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	else: Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"caret"(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('href="(.*?)".*?>(.*?)</a>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,title in items:
			if 'topvideos.php' in vn1grP3y4It9GmVuBbLJfz2A:
				if 'topvideos.php?c=english-movies' in vn1grP3y4It9GmVuBbLJfz2A: continue
				if 'topvideos.php?c=online-movies1' in vn1grP3y4It9GmVuBbLJfz2A: continue
				if 'topvideos.php?c=misc' in vn1grP3y4It9GmVuBbLJfz2A: continue
				if 'topvideos.php?c=tv-channel' in vn1grP3y4It9GmVuBbLJfz2A: continue
				if 'منذ البداية' in title and 'do=rating' not in vn1grP3y4It9GmVuBbLJfz2A: continue
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,471)
	else: c8wfGju4CWZm(url)
	return
def c8wfGju4CWZm(url,S46ZVrhN1gWY0Iiaj=HQmDERMFjx):
	EFDgdaV4WT6U2yotAPX1B = DpClq35GVjh(url,'url')
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'CIMALIGHT-TITLES-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	items = []
	if S46ZVrhN1gWY0Iiaj=='featured_movies':
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"container-fluid"(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('href="(.*?)".*?"title">(.*?)</div>.*?image:url\(\'(.*?)\'\)',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		jzTLleJs8x9Hb1,qP1wT2MFf0oK9Uv3u87QL,iT75pU3QIh0CWtwVj9Edr = zip(*items)
		items = zip(iT75pU3QIh0CWtwVj9Edr,jzTLleJs8x9Hb1,qP1wT2MFf0oK9Uv3u87QL)
	elif S46ZVrhN1gWY0Iiaj=='featured_series':
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('المسلسلات المميزة(.*?)<style>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('href="(.*?)".*?title="(.*?)".*?image:url\(\'(.*?)\'\)',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		jzTLleJs8x9Hb1,qP1wT2MFf0oK9Uv3u87QL,iT75pU3QIh0CWtwVj9Edr = zip(*items)
		items = zip(iT75pU3QIh0CWtwVj9Edr,jzTLleJs8x9Hb1,qP1wT2MFf0oK9Uv3u87QL)
	else:
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('(data-echo=".*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if not Ut7reR0XioMjOdYWZKsLIuc3TQJmC1: Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"BlocksList"(.*?)"titleSectionCon"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if not Ut7reR0XioMjOdYWZKsLIuc3TQJmC1: Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('id="pm-grid"(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if not Ut7reR0XioMjOdYWZKsLIuc3TQJmC1: Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('id="pm-related"(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if not Ut7reR0XioMjOdYWZKsLIuc3TQJmC1: Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('pm-ul-browse-videos(.*?)clearfix',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if not Ut7reR0XioMjOdYWZKsLIuc3TQJmC1: return
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	if not items: items = DyVGS3dX0ZxR.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	if not items: items = DyVGS3dX0ZxR.findall('src="(.*?)".*?href="(.*?)".*?>(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	ORMkTYjJ1p7 = []
	smLQwgO0BynVCcl3fYJ = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for uIGD4vZcP61QNmw78LXqoEpH,vn1grP3y4It9GmVuBbLJfz2A,title in items:
		vn1grP3y4It9GmVuBbLJfz2A = xx9LK4VzpF6IHXSEyhmrQwbg25P0(vn1grP3y4It9GmVuBbLJfz2A).strip(xufJqQcGnhboiVy2wd)
		title = title.replace('ماي سيما',HQmDERMFjx).replace('مشاهدة',HQmDERMFjx).strip(oQpxmKiRPlHeGsLXNrJF78O).replace(MSnXBQNUg1jF3W2fRlE9OLaCT8ds4,oQpxmKiRPlHeGsLXNrJF78O)
		if 'http' not in vn1grP3y4It9GmVuBbLJfz2A: vn1grP3y4It9GmVuBbLJfz2A = EFDgdaV4WT6U2yotAPX1B+xufJqQcGnhboiVy2wd+vn1grP3y4It9GmVuBbLJfz2A.strip(xufJqQcGnhboiVy2wd)
		if 'http' not in uIGD4vZcP61QNmw78LXqoEpH: uIGD4vZcP61QNmw78LXqoEpH = EFDgdaV4WT6U2yotAPX1B+xufJqQcGnhboiVy2wd+uIGD4vZcP61QNmw78LXqoEpH.strip(xufJqQcGnhboiVy2wd)
		yTz8SOkAhu24j6apo9BmZHvwWsX = DyVGS3dX0ZxR.findall('(.*?) (الحلقة|حلقة) \d+',title,DyVGS3dX0ZxR.DOTALL)
		if any(value in title for value in smLQwgO0BynVCcl3fYJ):
			title = '_MOD_'+title
			CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,472,uIGD4vZcP61QNmw78LXqoEpH)
		elif yTz8SOkAhu24j6apo9BmZHvwWsX and 'حلقة' in title:
			title = '_MOD_'+yTz8SOkAhu24j6apo9BmZHvwWsX[0][0]
			if title not in ORMkTYjJ1p7:
				CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,473,uIGD4vZcP61QNmw78LXqoEpH)
				ORMkTYjJ1p7.append(title)
		elif '/movseries/' in vn1grP3y4It9GmVuBbLJfz2A:
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,471,uIGD4vZcP61QNmw78LXqoEpH)
		else: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,473,uIGD4vZcP61QNmw78LXqoEpH)
	if S46ZVrhN1gWY0Iiaj not in ['featured_movies','featured_series']:
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"pagination(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
			MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
			items = DyVGS3dX0ZxR.findall('href="(.*?)".*?>(.*?)</a>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
			for vn1grP3y4It9GmVuBbLJfz2A,title in items:
				if vn1grP3y4It9GmVuBbLJfz2A=='#': continue
				vn1grP3y4It9GmVuBbLJfz2A = EFDgdaV4WT6U2yotAPX1B+xufJqQcGnhboiVy2wd+vn1grP3y4It9GmVuBbLJfz2A.strip(xufJqQcGnhboiVy2wd)
				title = SVsiEWeRf6oIynqQx8pCrM4Tk(title)
				CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'صفحة '+title,vn1grP3y4It9GmVuBbLJfz2A,471)
		cRGB60IvVUsywkjqu = DyVGS3dX0ZxR.findall('showmore" href="(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if cRGB60IvVUsywkjqu:
			vn1grP3y4It9GmVuBbLJfz2A = cRGB60IvVUsywkjqu[0]
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'مشاهدة المزيد',vn1grP3y4It9GmVuBbLJfz2A,471)
	return
def QQp8orwMlAa1(url,Y2OHMQ7a5tFfS1n):
	EFDgdaV4WT6U2yotAPX1B = DpClq35GVjh(url,'url')
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'CIMALIGHT-EPISODES-2nd')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	cOUkMZagDQftHLBoCivP = DyVGS3dX0ZxR.findall('"SeasonsBox"(.*?)</div>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	items = []
	if cOUkMZagDQftHLBoCivP and not Y2OHMQ7a5tFfS1n:
		uIGD4vZcP61QNmw78LXqoEpH = DyVGS3dX0ZxR.findall('"series-header".*?src="(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		uIGD4vZcP61QNmw78LXqoEpH = uIGD4vZcP61QNmw78LXqoEpH[0] if uIGD4vZcP61QNmw78LXqoEpH else HQmDERMFjx
		MJ2gSPyTl9hzoi1 = cOUkMZagDQftHLBoCivP[0]
		items = DyVGS3dX0ZxR.findall('openCity\(event\, \'(.*?)\'\)".*?>(.*?)</button>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		if len(items)==1: Y2OHMQ7a5tFfS1n = items[0][0]
		elif len(items)>1:
			for Y2OHMQ7a5tFfS1n,title in items: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,url,473,uIGD4vZcP61QNmw78LXqoEpH,HQmDERMFjx,Y2OHMQ7a5tFfS1n)
	vuylTosVej845YfDNK = DyVGS3dX0ZxR.findall('id="'+Y2OHMQ7a5tFfS1n+'"(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if vuylTosVej845YfDNK and len(items)<2:
		uIGD4vZcP61QNmw78LXqoEpH = DyVGS3dX0ZxR.findall('"series-header".*?src="(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		uIGD4vZcP61QNmw78LXqoEpH = uIGD4vZcP61QNmw78LXqoEpH[0] if uIGD4vZcP61QNmw78LXqoEpH else HQmDERMFjx
		MJ2gSPyTl9hzoi1 = vuylTosVej845YfDNK[0]
		items = DyVGS3dX0ZxR.findall('href="(.*?)".*?title="(.*?)"',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		if items:
			for vn1grP3y4It9GmVuBbLJfz2A,title in items:
				title = title.replace('ماي سيما',HQmDERMFjx).replace('مسلسل',HQmDERMFjx).strip(oQpxmKiRPlHeGsLXNrJF78O)
				if 'http' not in vn1grP3y4It9GmVuBbLJfz2A: vn1grP3y4It9GmVuBbLJfz2A = EFDgdaV4WT6U2yotAPX1B+xufJqQcGnhboiVy2wd+vn1grP3y4It9GmVuBbLJfz2A.strip(xufJqQcGnhboiVy2wd)
				CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,472,uIGD4vZcP61QNmw78LXqoEpH)
		else:
			items = DyVGS3dX0ZxR.findall('href="(.*?)".*?title="(.*?)".*?image:url\((.*?)\)',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
			for vn1grP3y4It9GmVuBbLJfz2A,title,uIGD4vZcP61QNmw78LXqoEpH in items:
				if 'http' not in vn1grP3y4It9GmVuBbLJfz2A: vn1grP3y4It9GmVuBbLJfz2A = EFDgdaV4WT6U2yotAPX1B+xufJqQcGnhboiVy2wd+vn1grP3y4It9GmVuBbLJfz2A.strip(xufJqQcGnhboiVy2wd)
				CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,472,uIGD4vZcP61QNmw78LXqoEpH)
	if 'id="pm-related"' in CzNPJydxQLfw27tv4ZF8KORAbX5:
		if items: CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
		CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'مواضيع ذات صلة',url,471)
	return
def f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url):
	Na8vklCpUGYIzP0bjutWOT = []
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'CIMALIGHT-PLAY-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('<div itemprop="description">(.*?)href=',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		WWbJG6CrUL4tIRsjpNV = DyVGS3dX0ZxR.findall('<p>(.*?)</p>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		if WWbJG6CrUL4tIRsjpNV and UzSYuZp3Pnhf1W4wyx7Fc0JX6jNb(HDLtdMAy7wPkl8aKC3O2,url,WWbJG6CrUL4tIRsjpNV,True): return
	SSHjMN4uegZfb2 = url.replace('/watch.php','/play.php')
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',SSHjMN4uegZfb2,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'CIMALIGHT-PLAY-2nd')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	lJQHLk5Sa9w = []
	vn1grP3y4It9GmVuBbLJfz2A = DyVGS3dX0ZxR.findall('"embedded".*?src="(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if vn1grP3y4It9GmVuBbLJfz2A:
		vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A[0]
		if vn1grP3y4It9GmVuBbLJfz2A and vn1grP3y4It9GmVuBbLJfz2A not in lJQHLk5Sa9w:
			lJQHLk5Sa9w.append(vn1grP3y4It9GmVuBbLJfz2A)
			vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A+'?named=__embed'
			if 'http' not in vn1grP3y4It9GmVuBbLJfz2A: vn1grP3y4It9GmVuBbLJfz2A = 'http:'+vn1grP3y4It9GmVuBbLJfz2A
			Na8vklCpUGYIzP0bjutWOT.append(vn1grP3y4It9GmVuBbLJfz2A)
	items = DyVGS3dX0ZxR.findall("iframe src='(.*?)'.*?<strong>(.*?)</strong>",CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	for vn1grP3y4It9GmVuBbLJfz2A,title in items:
		if vn1grP3y4It9GmVuBbLJfz2A not in lJQHLk5Sa9w:
			lJQHLk5Sa9w.append(vn1grP3y4It9GmVuBbLJfz2A)
			vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A+'?named='+title+'__watch'
			if 'http' not in vn1grP3y4It9GmVuBbLJfz2A: vn1grP3y4It9GmVuBbLJfz2A = 'http:'+vn1grP3y4It9GmVuBbLJfz2A
			Na8vklCpUGYIzP0bjutWOT.append(vn1grP3y4It9GmVuBbLJfz2A)
	SSHjMN4uegZfb2 = url.replace('/watch.php','/downloads.php')
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',SSHjMN4uegZfb2,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'CIMALIGHT-PLAY-3rd')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"downloadlist"(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('href="(.*?)".*?<strong>(.*?)</strong>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,title in items:
			if vn1grP3y4It9GmVuBbLJfz2A not in lJQHLk5Sa9w:
				lJQHLk5Sa9w.append(vn1grP3y4It9GmVuBbLJfz2A)
				vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A+'?named='+title+'__download'
				if 'http' not in vn1grP3y4It9GmVuBbLJfz2A: vn1grP3y4It9GmVuBbLJfz2A = 'http:'+vn1grP3y4It9GmVuBbLJfz2A
				Na8vklCpUGYIzP0bjutWOT.append(vn1grP3y4It9GmVuBbLJfz2A)
	import NsD5AomUqH
	NsD5AomUqH.NZcWGBmgFEen5hvJjUSIzOCVk7(Na8vklCpUGYIzP0bjutWOT,HDLtdMAy7wPkl8aKC3O2,'video',url)
	return
def hm4kawIPKp3oMrC75dJZA9HS2(search):
	search,GXVabd4sc2u3zp0JI,showDialogs = x0pzMENwy84tBcZvXr(search)
	if search==HQmDERMFjx: search = q156m84QoYrn()
	if search==HQmDERMFjx: return
	search = search.replace(oQpxmKiRPlHeGsLXNrJF78O,'+')
	pYVvlGR1ES0gdtzayiDqb9w = DpClq35GVjh(e2VR8nohduY,'url')
	url = pYVvlGR1ES0gdtzayiDqb9w+'/search.php?keywords='+search
	c8wfGju4CWZm(url,'search')
	return
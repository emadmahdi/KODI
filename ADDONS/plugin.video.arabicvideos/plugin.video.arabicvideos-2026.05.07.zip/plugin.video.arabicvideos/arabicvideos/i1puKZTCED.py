# -*- coding: utf-8 -*-
from FF68kA5BUy import *
HDLtdMAy7wPkl8aKC3O2 = 'ELIFVIDEO'
EEJvXQzSZNt = '_ELV_'
e2VR8nohduY = Jzthpc2nj5.SITESURLS[HDLtdMAy7wPkl8aKC3O2][0]
FwhZ0nXtpoHTMarf = ['الصفحة الرئيسية','Sign in','تسجيل','افلام للكبار فقط']
headers = ''
def kk6X5LxpsND(mode,url,text):
	if   mode==1060: zLZUkrP7ac5 = afkxo7FyZWB4O6K1eXrs5I()
	elif mode==1061: zLZUkrP7ac5 = c8wfGju4CWZm(url,text)
	elif mode==1062: zLZUkrP7ac5 = f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url)
	elif mode==1063: zLZUkrP7ac5 = QQp8orwMlAa1(url,text)
	elif mode==1064: zLZUkrP7ac5 = REWBU20fyqaLprY(url)
	elif mode==1069: zLZUkrP7ac5 = hm4kawIPKp3oMrC75dJZA9HS2(text)
	else: zLZUkrP7ac5 = False
	return zLZUkrP7ac5
def afkxo7FyZWB4O6K1eXrs5I():
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',e2VR8nohduY,HQmDERMFjx,headers,HQmDERMFjx,HQmDERMFjx,'ELIFVIDEO-MENU-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'بحث في الموقع',HQmDERMFjx,1069,HQmDERMFjx,HQmDERMFjx,'_REMEMBERRESULTS_')
	CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('''["']navslide-wrap["'](.*?)</ul>''',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('href="(.*?)".*?</i>(.*?)</a>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,title in items:
			if title in FwhZ0nXtpoHTMarf: continue
			CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,1064)
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('/category.php">(.*?)"navslide-divider"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('''["']dropdown-menu["'](.*?)</ul>''',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	for ej8EfB1iZ5Gh3X2gxWtSONH in Ut7reR0XioMjOdYWZKsLIuc3TQJmC1: MJ2gSPyTl9hzoi1 = MJ2gSPyTl9hzoi1.replace(ej8EfB1iZ5Gh3X2gxWtSONH,HQmDERMFjx)
	items = DyVGS3dX0ZxR.findall('href="(.*?)".*?>(.*?)</a>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	for vn1grP3y4It9GmVuBbLJfz2A,title in items:
		if not title: continue
		if title in FwhZ0nXtpoHTMarf: continue
		if title=='جديد الأفلام': title = 'المضاف حديثا'
		CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,1064)
	return
def REWBU20fyqaLprY(url):
	fVUt6k9dmSlo58OjK0uGNJMDqTQZHc,bbiKcPz2RQOUwS = [],[]
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,headers,HQmDERMFjx,HQmDERMFjx,'ELIFVIDEO-SUBMENU-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	cOUkMZagDQftHLBoCivP = DyVGS3dX0ZxR.findall('"caret"(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if cOUkMZagDQftHLBoCivP and '.php' in str(cOUkMZagDQftHLBoCivP):
		MJ2gSPyTl9hzoi1 = cOUkMZagDQftHLBoCivP[0]
		MJ2gSPyTl9hzoi1 = MJ2gSPyTl9hzoi1.replace('"presentation"','</ul>')
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		if not Ut7reR0XioMjOdYWZKsLIuc3TQJmC1: Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = [(HQmDERMFjx,MJ2gSPyTl9hzoi1)]
		CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' فرز أو فلتر أو ترتيب '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
		for XwidGQz8WkV1CorLYJ4Z9aqO0g,MJ2gSPyTl9hzoi1 in Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
			fVUt6k9dmSlo58OjK0uGNJMDqTQZHc = DyVGS3dX0ZxR.findall('href="(.*?)".*?>(.*?)</a>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
			if XwidGQz8WkV1CorLYJ4Z9aqO0g: XwidGQz8WkV1CorLYJ4Z9aqO0g = XwidGQz8WkV1CorLYJ4Z9aqO0g+': '
			for vn1grP3y4It9GmVuBbLJfz2A,title in fVUt6k9dmSlo58OjK0uGNJMDqTQZHc:
				title = XwidGQz8WkV1CorLYJ4Z9aqO0g+title
				CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,1061)
	vuylTosVej845YfDNK = DyVGS3dX0ZxR.findall('"pm-category-subcats"(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if vuylTosVej845YfDNK:
		MJ2gSPyTl9hzoi1 = vuylTosVej845YfDNK[0]
		bbiKcPz2RQOUwS = DyVGS3dX0ZxR.findall('href="(.*?)">(.*?)</a>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		if 1 or len(bbiKcPz2RQOUwS)<30:
			if fVUt6k9dmSlo58OjK0uGNJMDqTQZHc: CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
			for vn1grP3y4It9GmVuBbLJfz2A,title in bbiKcPz2RQOUwS:
				if title in FwhZ0nXtpoHTMarf: continue
				CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,1061)
	if not fVUt6k9dmSlo58OjK0uGNJMDqTQZHc and not vuylTosVej845YfDNK: c8wfGju4CWZm(url)
	return
def c8wfGju4CWZm(url,S46ZVrhN1gWY0Iiaj=HQmDERMFjx):
	if S46ZVrhN1gWY0Iiaj=='ajax-search':
		url,search = url.split('?',1)
		data = 'queryString='+search
		nJayb3s5zlOgQh9BwiCdEDq = headers.copy()
		nJayb3s5zlOgQh9BwiCdEDq['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8'
		vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'POST',url,data,nJayb3s5zlOgQh9BwiCdEDq,HQmDERMFjx,HQmDERMFjx,'ELIFVIDEO-TITLES-1st')
	else:
		vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,headers,HQmDERMFjx,HQmDERMFjx,'ELIFVIDEO-TITLES-2nd')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	MJ2gSPyTl9hzoi1,items = HQmDERMFjx,[]
	EFDgdaV4WT6U2yotAPX1B = DpClq35GVjh(url,'url')
	if S46ZVrhN1gWY0Iiaj=='ajax-search':
		MJ2gSPyTl9hzoi1 = CzNPJydxQLfw27tv4ZF8KORAbX5
		bbiKcPz2RQOUwS = DyVGS3dX0ZxR.findall('href="(.*?)">(.*?)</a>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,title in bbiKcPz2RQOUwS: items.append((HQmDERMFjx,vn1grP3y4It9GmVuBbLJfz2A,title))
	elif S46ZVrhN1gWY0Iiaj=='featured':
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"pm-carousel_featured"(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1: MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	elif S46ZVrhN1gWY0Iiaj=='new_episodes':
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"row pm-ul-browse-videos(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1: MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	elif S46ZVrhN1gWY0Iiaj=='new_movies':
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"row pm-ul-browse-videos(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if len(Ut7reR0XioMjOdYWZKsLIuc3TQJmC1)>1: MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[1]
	elif S46ZVrhN1gWY0Iiaj=='featured_series':
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"home-series-list"(.*?)</div>[\t|\n]*</div>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1: MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	else:
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"pm-grid"(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1: MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	if MJ2gSPyTl9hzoi1 and not items: items = DyVGS3dX0ZxR.findall('"thumbnail".*?<a href="([^"]*)" title="([^"]*)".*?src="(.*?)"',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	if not items: return
	ORMkTYjJ1p7 = []
	smLQwgO0BynVCcl3fYJ = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for vn1grP3y4It9GmVuBbLJfz2A,title,uIGD4vZcP61QNmw78LXqoEpH in items:
		uIGD4vZcP61QNmw78LXqoEpH += '|Referer='+e2VR8nohduY
		if 'http' not in vn1grP3y4It9GmVuBbLJfz2A: vn1grP3y4It9GmVuBbLJfz2A = EFDgdaV4WT6U2yotAPX1B+xufJqQcGnhboiVy2wd+vn1grP3y4It9GmVuBbLJfz2A.strip('./')
		title = SVsiEWeRf6oIynqQx8pCrM4Tk(title)
		yTz8SOkAhu24j6apo9BmZHvwWsX = DyVGS3dX0ZxR.findall('(.*?) (الحلقة|حلقة).\d+',title,DyVGS3dX0ZxR.DOTALL)
		if any(value in title for value in smLQwgO0BynVCcl3fYJ):
			CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,1062,uIGD4vZcP61QNmw78LXqoEpH)
		elif S46ZVrhN1gWY0Iiaj=='new_episodes':
			CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,1062,uIGD4vZcP61QNmw78LXqoEpH)
		elif yTz8SOkAhu24j6apo9BmZHvwWsX:
			title = '_MOD_' + yTz8SOkAhu24j6apo9BmZHvwWsX[0][0]
			if title not in ORMkTYjJ1p7:
				CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,1063,uIGD4vZcP61QNmw78LXqoEpH)
				ORMkTYjJ1p7.append(title)
		else: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,1063,uIGD4vZcP61QNmw78LXqoEpH)
	if 1:
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"pagination(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
			MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
			items = DyVGS3dX0ZxR.findall('href="(.*?)".*?>(.*?)</a>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
			for vn1grP3y4It9GmVuBbLJfz2A,title in items:
				if vn1grP3y4It9GmVuBbLJfz2A=='#': continue
				if 'http' not in vn1grP3y4It9GmVuBbLJfz2A: vn1grP3y4It9GmVuBbLJfz2A = EFDgdaV4WT6U2yotAPX1B+xufJqQcGnhboiVy2wd+vn1grP3y4It9GmVuBbLJfz2A.strip('./')
				title = SVsiEWeRf6oIynqQx8pCrM4Tk(title)
				CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'صفحة '+title,vn1grP3y4It9GmVuBbLJfz2A,1061)
	return
def QQp8orwMlAa1(url,Y2OHMQ7a5tFfS1n):
	EFDgdaV4WT6U2yotAPX1B = DpClq35GVjh(url,'url')
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,headers,HQmDERMFjx,HQmDERMFjx,'ELIFVIDEO-EPISODES-2nd')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	cOUkMZagDQftHLBoCivP = DyVGS3dX0ZxR.findall('"SeasonsBox"(.*?)"SeasonsEpisodesMain',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	kALyrFT6KPNGI7Oiup82Qb4JCq0td = DyVGS3dX0ZxR.findall('"image" content="(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	uIGD4vZcP61QNmw78LXqoEpH = kALyrFT6KPNGI7Oiup82Qb4JCq0td[0] if kALyrFT6KPNGI7Oiup82Qb4JCq0td else HQmDERMFjx
	uIGD4vZcP61QNmw78LXqoEpH += '|Referer='+e2VR8nohduY
	items = []
	VyueNkv1smz4MSdtWAiHapBTI8g = False
	if cOUkMZagDQftHLBoCivP and not Y2OHMQ7a5tFfS1n:
		MJ2gSPyTl9hzoi1 = cOUkMZagDQftHLBoCivP[0]
		items = DyVGS3dX0ZxR.findall('''onclick=".*?openCity\(event, '(.*?)'\)".*?>(.*?)</button>''',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for Y2OHMQ7a5tFfS1n,title in items:
			Y2OHMQ7a5tFfS1n = Y2OHMQ7a5tFfS1n.strip('#')
			if len(items)>1: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,url,1063,uIGD4vZcP61QNmw78LXqoEpH,HQmDERMFjx,Y2OHMQ7a5tFfS1n)
			else: VyueNkv1smz4MSdtWAiHapBTI8g = True
	else: VyueNkv1smz4MSdtWAiHapBTI8g = True
	vuylTosVej845YfDNK = DyVGS3dX0ZxR.findall('id="'+Y2OHMQ7a5tFfS1n+'"(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if not vuylTosVej845YfDNK:
		vuylTosVej845YfDNK = DyVGS3dX0ZxR.findall('SeasonsEpisodesMain(.*?)</div>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if vuylTosVej845YfDNK:
			MJ2gSPyTl9hzoi1 = vuylTosVej845YfDNK[0]
			items = DyVGS3dX0ZxR.findall('href="([^"]*)" title="([^"]*)"',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
			for vn1grP3y4It9GmVuBbLJfz2A,title in items:
				if 'http' not in vn1grP3y4It9GmVuBbLJfz2A: vn1grP3y4It9GmVuBbLJfz2A = EFDgdaV4WT6U2yotAPX1B+xufJqQcGnhboiVy2wd+vn1grP3y4It9GmVuBbLJfz2A.strip('./')
				title = title.replace('</em><span>',oQpxmKiRPlHeGsLXNrJF78O)
				CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,1062,uIGD4vZcP61QNmw78LXqoEpH)
	elif vuylTosVej845YfDNK and VyueNkv1smz4MSdtWAiHapBTI8g:
		MJ2gSPyTl9hzoi1 = vuylTosVej845YfDNK[0]
		bbiKcPz2RQOUwS = DyVGS3dX0ZxR.findall('''title=['"](.*?)['"].*?href=["'](.*?)["'].*?''',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		if bbiKcPz2RQOUwS:
			P0YgW6op81QZawuTlfbX4Jxh5yz,shd3aD59KxM1ULIClqTS = zip(*bbiKcPz2RQOUwS)
			V64RDvxzgfbJAGeq0hpFr = [uIGD4vZcP61QNmw78LXqoEpH]*len(bbiKcPz2RQOUwS)
			items = zip(shd3aD59KxM1ULIClqTS,P0YgW6op81QZawuTlfbX4Jxh5yz,V64RDvxzgfbJAGeq0hpFr)
		if not items: items = DyVGS3dX0ZxR.findall('"thumbnail".*?href="([^"]*)" title="([^"]*)".*?src="(.*?)"',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,title,uIGD4vZcP61QNmw78LXqoEpH in items:
			uIGD4vZcP61QNmw78LXqoEpH += '|Referer='+e2VR8nohduY
			if 'http' not in vn1grP3y4It9GmVuBbLJfz2A: vn1grP3y4It9GmVuBbLJfz2A = EFDgdaV4WT6U2yotAPX1B+xufJqQcGnhboiVy2wd+vn1grP3y4It9GmVuBbLJfz2A.strip('./')
			title = title.replace('</em><span>',oQpxmKiRPlHeGsLXNrJF78O)
			CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,1062,uIGD4vZcP61QNmw78LXqoEpH)
	return
def f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url):
	KWnAuJIFyESQHjP3X5xzMqUbR6L = []
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'ELIFVIDEO-PLAY-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	vn1grP3y4It9GmVuBbLJfz2A = DyVGS3dX0ZxR.findall('"xtgo" href="(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if vn1grP3y4It9GmVuBbLJfz2A:
		vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A[0]
		EFDgdaV4WT6U2yotAPX1B = DpClq35GVjh(url,'url')
		headers = {'User-Agent':xK7D9yiBPEqvhmA8XIoJe(),'Referer':EFDgdaV4WT6U2yotAPX1B}
		vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',vn1grP3y4It9GmVuBbLJfz2A,HQmDERMFjx,headers,HQmDERMFjx,HQmDERMFjx,'ELIFVIDEO-PLAY-2nd')
		CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"embeding"(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
			MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
			items = DyVGS3dX0ZxR.findall('embed="(.*?)">(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
			for vn1grP3y4It9GmVuBbLJfz2A,title in items:
				vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A+'?named='+title+'__watch'
				KWnAuJIFyESQHjP3X5xzMqUbR6L.append(vn1grP3y4It9GmVuBbLJfz2A)
	import NsD5AomUqH
	NsD5AomUqH.NZcWGBmgFEen5hvJjUSIzOCVk7(KWnAuJIFyESQHjP3X5xzMqUbR6L,HDLtdMAy7wPkl8aKC3O2,'video',url)
	return
def hm4kawIPKp3oMrC75dJZA9HS2(search):
	search,GXVabd4sc2u3zp0JI,showDialogs = x0pzMENwy84tBcZvXr(search)
	if search==HQmDERMFjx: search = q156m84QoYrn()
	if search==HQmDERMFjx: return
	search = search.replace(oQpxmKiRPlHeGsLXNrJF78O,'+')
	url = e2VR8nohduY+'/search.php?keywords='+search
	c8wfGju4CWZm(url,'search')
	return
# -*- coding: utf-8 -*-
from FF68kA5BUy import *
HDLtdMAy7wPkl8aKC3O2 = 'FASELHD1'
headers = {'User-Agent':HQmDERMFjx}
EEJvXQzSZNt = '_FH1_'
e2VR8nohduY = Jzthpc2nj5.SITESURLS[HDLtdMAy7wPkl8aKC3O2][0]
FwhZ0nXtpoHTMarf = ['جوائز الأوسكار','المراجعات','wwe']
def kk6X5LxpsND(mode,url,text):
	if   mode==570: zLZUkrP7ac5 = afkxo7FyZWB4O6K1eXrs5I()
	elif mode==571: zLZUkrP7ac5 = c8wfGju4CWZm(url,text)
	elif mode==572: zLZUkrP7ac5 = f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url)
	elif mode==573: zLZUkrP7ac5 = OeIkhc6dCf01i2BFSKX5L8E9Nvr(url,text)
	elif mode==576: zLZUkrP7ac5 = lRPnk9MH7S1BJaTeih()
	elif mode==579: zLZUkrP7ac5 = hm4kawIPKp3oMrC75dJZA9HS2(text)
	else: zLZUkrP7ac5 = False
	return zLZUkrP7ac5
def afkxo7FyZWB4O6K1eXrs5I():
	CfgK4s13Q0hZcHyleT2bVJO9('link',EEJvXQzSZNt+'لماذا الموقع بطيء',HQmDERMFjx,576)
	EFDgdaV4WT6U2yotAPX1B,url = e2VR8nohduY,e2VR8nohduY
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'FASELHD1-MENU-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'بحث في الموقع',EFDgdaV4WT6U2yotAPX1B,579,HQmDERMFjx,HQmDERMFjx,'_REMEMBERRESULTS_')
	CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'المميزة',EFDgdaV4WT6U2yotAPX1B,571,HQmDERMFjx,HQmDERMFjx,'featured1')
	items = DyVGS3dX0ZxR.findall('class="h3">(.*?)<.*?href="(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	for title,vn1grP3y4It9GmVuBbLJfz2A in items:
		CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,571,HQmDERMFjx,HQmDERMFjx,'details1')
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"menu-primary"(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		ZZOSgyXHzxwsQ7NEe4i = DyVGS3dX0ZxR.findall('<li (.*?)</li>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		hIq0wEdLbTR3Y12siVg4DaO7znAZ = [HQmDERMFjx,'أفلام: ','مسلسلات: ','برامج: ','آسيوي: ','أنمي: ']
		DvGaoUZE5S4wxfHc910sz = 0
		for t7IyszW0jv in ZZOSgyXHzxwsQ7NEe4i:
			if DvGaoUZE5S4wxfHc910sz>0: CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
			items = DyVGS3dX0ZxR.findall('href="(.*?)".*?>(.*?)<',t7IyszW0jv,DyVGS3dX0ZxR.DOTALL)
			for vn1grP3y4It9GmVuBbLJfz2A,title in items:
				if vn1grP3y4It9GmVuBbLJfz2A=='#': continue
				if 'http' not in vn1grP3y4It9GmVuBbLJfz2A: vn1grP3y4It9GmVuBbLJfz2A = EFDgdaV4WT6U2yotAPX1B+vn1grP3y4It9GmVuBbLJfz2A
				if title==HQmDERMFjx: continue
				if any(value in title.lower() for value in FwhZ0nXtpoHTMarf): continue
				title = hIq0wEdLbTR3Y12siVg4DaO7znAZ[DvGaoUZE5S4wxfHc910sz]+title
				CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,571,HQmDERMFjx,HQmDERMFjx,'details2')
			DvGaoUZE5S4wxfHc910sz += 1
	return
def lRPnk9MH7S1BJaTeih():
	u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,'موقع فاصل الأول بطيء من المصدر .. بسبب قيام أصحاب الموقع بإضافة فحص وتحقق أمني ضد هجوم البرامج وهجوم القراصنة على صفحات الموقع .. والوقت الضائع يذهب في محاولة تجاوز هذا الفحص واثبات أن هذا البرنامج هو مجرد متصفح للمواقع ولا يقوم بالهجوم على المواقع')
	return
def c8wfGju4CWZm(url,type=HQmDERMFjx):
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'FASELHD1-TITLES-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	vuylTosVej845YfDNK = DyVGS3dX0ZxR.findall('class="h4">(.*?)</div>(.*?)"container"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if not vuylTosVej845YfDNK: return
	if type=='filters':
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = [CzNPJydxQLfw27tv4ZF8KORAbX5.replace('\\/',xufJqQcGnhboiVy2wd).replace('\\"','"')]
	elif type=='featured1':
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"homeSlide"(.*?)"container"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall(' src="(.*?)".*? href="(.*?)">(.*?)</a>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		xWR90Dw2kZa4TGz51NQMU3hIv7rXE,jzTLleJs8x9Hb1,qP1wT2MFf0oK9Uv3u87QL = zip(*items)
		items = zip(jzTLleJs8x9Hb1,xWR90Dw2kZa4TGz51NQMU3hIv7rXE,qP1wT2MFf0oK9Uv3u87QL)
	elif type=='featured2':
		title,MJ2gSPyTl9hzoi1 = vuylTosVej845YfDNK[0]
		items = DyVGS3dX0ZxR.findall('href="(.*?)".*? data-src="(.*?)".*? alt="(.*?)"',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	elif type=='details2' and len(vuylTosVej845YfDNK)>1:
		title = vuylTosVej845YfDNK[0][0]
		CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,url,571,HQmDERMFjx,HQmDERMFjx,'featured2')
		title = vuylTosVej845YfDNK[1][0]
		CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,url,571,HQmDERMFjx,HQmDERMFjx,'details3')
		return
	else:
		title,MJ2gSPyTl9hzoi1 = vuylTosVej845YfDNK[-1]
		items = DyVGS3dX0ZxR.findall('href="(.*?)".*? data-src="(.*?)".*?"h1">(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	ORMkTYjJ1p7 = []
	for vn1grP3y4It9GmVuBbLJfz2A,uIGD4vZcP61QNmw78LXqoEpH,title in items:
		if any(value in title.lower() for value in FwhZ0nXtpoHTMarf): continue
		uIGD4vZcP61QNmw78LXqoEpH = ArwuTXMNsaO9fmjWdI(uIGD4vZcP61QNmw78LXqoEpH)
		uIGD4vZcP61QNmw78LXqoEpH = uIGD4vZcP61QNmw78LXqoEpH.split('?resize=')[0]
		title = SVsiEWeRf6oIynqQx8pCrM4Tk(title)
		yTz8SOkAhu24j6apo9BmZHvwWsX = DyVGS3dX0ZxR.findall('(.*?) (الحلقة|حلقة).\d+',title,DyVGS3dX0ZxR.DOTALL)
		if '/collections/' in vn1grP3y4It9GmVuBbLJfz2A:
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,571,uIGD4vZcP61QNmw78LXqoEpH)
		elif yTz8SOkAhu24j6apo9BmZHvwWsX and type==HQmDERMFjx:
			title = '_MOD_'+yTz8SOkAhu24j6apo9BmZHvwWsX[0][0]
			title = title.strip(' –')
			if title not in ORMkTYjJ1p7:
				CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,573,uIGD4vZcP61QNmw78LXqoEpH)
				ORMkTYjJ1p7.append(title)
		elif 'episodes/' in vn1grP3y4It9GmVuBbLJfz2A or 'movies/' in vn1grP3y4It9GmVuBbLJfz2A or 'hindi/' in vn1grP3y4It9GmVuBbLJfz2A:
			CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,572,uIGD4vZcP61QNmw78LXqoEpH)
		else: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,573,uIGD4vZcP61QNmw78LXqoEpH)
	if type=='filters':
		lELPWeA4rpO = DyVGS3dX0ZxR.findall('"more_button_page":(.*?),',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		if lELPWeA4rpO:
			count = lELPWeA4rpO[0]
			vn1grP3y4It9GmVuBbLJfz2A = url+'/offset/'+count
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'صفحة أخرى',vn1grP3y4It9GmVuBbLJfz2A,571,HQmDERMFjx,HQmDERMFjx,'filters')
	elif 'details' in type:
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall("class='pagination(.*?)</div>",CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
			MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
			items = DyVGS3dX0ZxR.findall("href='(.*?)'.*?>(.*?)<",MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
			for vn1grP3y4It9GmVuBbLJfz2A,title in items:
				title = 'صفحة '+SVsiEWeRf6oIynqQx8pCrM4Tk(title)
				CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,571,HQmDERMFjx,HQmDERMFjx,'details4')
	return
def OeIkhc6dCf01i2BFSKX5L8E9Nvr(url,type=HQmDERMFjx):
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'FASELHD1-SEASONS_EPISODES-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	WTgZPcmVih38IjnSJ2U = False
	if not type:
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"seasonList"(.*?)"container"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
			MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
			items = DyVGS3dX0ZxR.findall('href = \'(.*?)\'.*? data-src="(.*?)".*?alt="(.*?)".*?"title">(.*?)</div>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
			if len(items)>1:
				EFDgdaV4WT6U2yotAPX1B = DpClq35GVjh(url,'url')
				WTgZPcmVih38IjnSJ2U = True
				for vn1grP3y4It9GmVuBbLJfz2A,uIGD4vZcP61QNmw78LXqoEpH,name,title in items:
					name = SVsiEWeRf6oIynqQx8pCrM4Tk(name)
					if 'http' not in vn1grP3y4It9GmVuBbLJfz2A: vn1grP3y4It9GmVuBbLJfz2A = EFDgdaV4WT6U2yotAPX1B+vn1grP3y4It9GmVuBbLJfz2A
					title = name+' - '+title
					CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,573,uIGD4vZcP61QNmw78LXqoEpH,HQmDERMFjx,'episodes')
	if type=='episodes' or not WTgZPcmVih38IjnSJ2U:
		kALyrFT6KPNGI7Oiup82Qb4JCq0td = DyVGS3dX0ZxR.findall('"posterImg".*?src="(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if kALyrFT6KPNGI7Oiup82Qb4JCq0td: uIGD4vZcP61QNmw78LXqoEpH = kALyrFT6KPNGI7Oiup82Qb4JCq0td[0]
		else: uIGD4vZcP61QNmw78LXqoEpH = HQmDERMFjx
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"epAll"(.*?)</div>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
			MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
			items = DyVGS3dX0ZxR.findall('href="(.*?)".*?>(.*?)</a>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
			for vn1grP3y4It9GmVuBbLJfz2A,title in items:
				title = title.strip(oQpxmKiRPlHeGsLXNrJF78O)
				title = SVsiEWeRf6oIynqQx8pCrM4Tk(title)
				CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,572,uIGD4vZcP61QNmw78LXqoEpH)
	return
def f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url):
	KWnAuJIFyESQHjP3X5xzMqUbR6L,oM5QxKTiCrjwszZ0S9dHb1B7p,xqbn6MHwQkWt48lvLUjhZ7TBSri = [],[],[]
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(LLwINhcX2RHSWqpmEnz,'GET',url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'FASELHD1-PLAY-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	OOfClrwaFDnWzms6 = DyVGS3dX0ZxR.findall('مستوى المشاهدة.*?">(.*?)</span>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if OOfClrwaFDnWzms6:
		WWbJG6CrUL4tIRsjpNV = DyVGS3dX0ZxR.findall('"tag">(.*?)</a>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if WWbJG6CrUL4tIRsjpNV and UzSYuZp3Pnhf1W4wyx7Fc0JX6jNb(HDLtdMAy7wPkl8aKC3O2,url,WWbJG6CrUL4tIRsjpNV): return
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"videoRow"(.*?)</div>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('src="(.*?)"',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A in items:
			vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A.split('&img=')[0]
			KWnAuJIFyESQHjP3X5xzMqUbR6L.append(vn1grP3y4It9GmVuBbLJfz2A+'?named=__embed')
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('class="streamHeader(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall("href = '(.*?)'.*?</i>(.*?)</a>",MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,name in items:
			vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A.split('&img=')[0]
			name = name.strip(oQpxmKiRPlHeGsLXNrJF78O)
			KWnAuJIFyESQHjP3X5xzMqUbR6L.append(vn1grP3y4It9GmVuBbLJfz2A+'?named='+name+'__watch')
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('class="downloadLinks(.*?)blackwindow',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('href="(.*?)".*?</span>(.*?)</a>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,name in items:
			vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A.split('&img=')[0]
			KWnAuJIFyESQHjP3X5xzMqUbR6L.append(vn1grP3y4It9GmVuBbLJfz2A+'?named='+name+'__download')
	for VFyHmsD6IYWXEjOL4KJnkMuZ3avRNC in KWnAuJIFyESQHjP3X5xzMqUbR6L:
		vn1grP3y4It9GmVuBbLJfz2A,name = VFyHmsD6IYWXEjOL4KJnkMuZ3avRNC.split('?named')
		if vn1grP3y4It9GmVuBbLJfz2A not in oM5QxKTiCrjwszZ0S9dHb1B7p:
			oM5QxKTiCrjwszZ0S9dHb1B7p.append(vn1grP3y4It9GmVuBbLJfz2A)
			xqbn6MHwQkWt48lvLUjhZ7TBSri.append(VFyHmsD6IYWXEjOL4KJnkMuZ3avRNC)
	import NsD5AomUqH
	NsD5AomUqH.NZcWGBmgFEen5hvJjUSIzOCVk7(xqbn6MHwQkWt48lvLUjhZ7TBSri,HDLtdMAy7wPkl8aKC3O2,'video',url)
	return
def hm4kawIPKp3oMrC75dJZA9HS2(search):
	search,GXVabd4sc2u3zp0JI,showDialogs = x0pzMENwy84tBcZvXr(search)
	if search==HQmDERMFjx: search = q156m84QoYrn()
	if search==HQmDERMFjx: return
	search = search.replace(oQpxmKiRPlHeGsLXNrJF78O,'+')
	SSHjMN4uegZfb2 = e2VR8nohduY+'/?s='+search
	c8wfGju4CWZm(SSHjMN4uegZfb2,'details5')
	return
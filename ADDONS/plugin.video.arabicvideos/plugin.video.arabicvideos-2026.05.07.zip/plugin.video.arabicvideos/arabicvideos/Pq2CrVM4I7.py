# -*- coding: utf-8 -*-
from FF68kA5BUy import *
HDLtdMAy7wPkl8aKC3O2 = 'DAILYMOTION'
EEJvXQzSZNt = '_DLM_'
e2VR8nohduY = Jzthpc2nj5.SITESURLS[HDLtdMAy7wPkl8aKC3O2][0]
waE5LXVN0BOiQjCUur3oTt6eYSIHJK = Jzthpc2nj5.SITESURLS[HDLtdMAy7wPkl8aKC3O2][1]
IsK7MxWgSEa9JkHQntoh = Jzthpc2nj5.SITESURLS[HDLtdMAy7wPkl8aKC3O2][2]
def kk6X5LxpsND(mode,url,text,type,zmL397efNlks5uTEV):
	if	 mode==400: zLZUkrP7ac5 = afkxo7FyZWB4O6K1eXrs5I()
	elif mode==401: zLZUkrP7ac5 = x1xsL0QhH3r5oad(url,text)
	elif mode==402: zLZUkrP7ac5 = I2IbUDCvOsSiK8EfYNkm(url,text)
	elif mode==403: zLZUkrP7ac5 = f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url,text)
	elif mode==404: zLZUkrP7ac5 = RT9LcrUXNko7KgbzO08hGFsP(text,zmL397efNlks5uTEV)
	elif mode==405: zLZUkrP7ac5 = XfAL86ZJ3kO2lqwcIutY(text,zmL397efNlks5uTEV)
	elif mode==406: zLZUkrP7ac5 = MDPiql2JxuHTdk(text,zmL397efNlks5uTEV)
	elif mode==407: zLZUkrP7ac5 = Q1blHG862i9tekxUzWdFrBN(url,zmL397efNlks5uTEV)
	elif mode==408: zLZUkrP7ac5 = mQMeF076n2TCOIPJRjyuaKw3xlG(url,zmL397efNlks5uTEV)
	elif mode==409: zLZUkrP7ac5 = hm4kawIPKp3oMrC75dJZA9HS2(text,zmL397efNlks5uTEV)
	elif mode==411: zLZUkrP7ac5 = IXZ4OcxaYgPl(url,text)
	elif mode==414: zLZUkrP7ac5 = ToScuwIyFz3pj(text)
	elif mode==415: zLZUkrP7ac5 = TOwxWMp8FuDReyHrYcVlBKN536n(text,zmL397efNlks5uTEV)
	elif mode==416: zLZUkrP7ac5 = qATVJiEK86L9U(text,zmL397efNlks5uTEV)
	elif mode==417: zLZUkrP7ac5 = tarQvJ0zC16W(url,zmL397efNlks5uTEV)
	else: zLZUkrP7ac5 = False
	return zLZUkrP7ac5
def afkxo7FyZWB4O6K1eXrs5I():
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'الرئيسية',HQmDERMFjx,414)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'بحث في الموقع',HQmDERMFjx,409,HQmDERMFjx,HQmDERMFjx,'_REMEMBERRESULTS_')
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'بحث عن فيديوهات',HQmDERMFjx,409,HQmDERMFjx,'videos?sortBy=','_REMEMBERRESULTS_')
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'بحث عن آخر الفيديوهات',HQmDERMFjx,409,HQmDERMFjx,'videos?sortBy=RECENT','_REMEMBERRESULTS_')
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'بحث عن الفيديوهات الأكثر مشاهدة',HQmDERMFjx,409,HQmDERMFjx,'videos?sortBy=VIEW_COUNT','_REMEMBERRESULTS_')
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'بحث عن قوائم التشغيل',HQmDERMFjx,409,HQmDERMFjx,'playlists','_REMEMBERRESULTS_')
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'بحث عن مستخدم',HQmDERMFjx,409,HQmDERMFjx,'channels','_REMEMBERRESULTS_')
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'بحث عن بث حي',HQmDERMFjx,409,HQmDERMFjx,'lives','_REMEMBERRESULTS_')
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'بحث عن هاشتاك',HQmDERMFjx,409,HQmDERMFjx,'hashtags','_REMEMBERRESULTS_')
	return
def I2IbUDCvOsSiK8EfYNkm(url,vJ9G3ygrubaSjc8):
	if '/dm_' in url:
		vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(LLwINhcX2RHSWqpmEnz,'GET',url,HQmDERMFjx,HQmDERMFjx,False,HQmDERMFjx,'DAILYMOTION-CHANNELS_SUBMENU-1st',False,False)
		headers = vGXnw9VcUN.headers
		if 'Location' in list(headers.keys()): url = e2VR8nohduY+headers['Location']
	vJ9G3ygrubaSjc8 = ao3Q5jP8H0sMxK2iUYwZGE+vJ9G3ygrubaSjc8+cjqzOQ5GXD4kR
	vJ9G3ygrubaSjc8 = Tc7WUd1Hhu9Dlvb4o(vJ9G3ygrubaSjc8)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+':: بث حي',url,411,HQmDERMFjx,HQmDERMFjx,'channel_lives_now')
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+':: آخر الفيديوهات',url+'/videos',408)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+':: الأكثر مشاهدة',url+'/videos?sort=visited',408)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+':: المميزة',url,411,HQmDERMFjx,HQmDERMFjx,'channel_featured_videos')
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+':: قوائم التشغيل',url+'/playlists',407)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+':: قوائم التشغيل أبجدية',url+'/playlists?sort=alphaaz',407)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+':: قنوات ذات صلة',url,411,HQmDERMFjx,HQmDERMFjx,'channel_related_channel')
	return
def Tc7WUd1Hhu9Dlvb4o(title):
	title = title.rstrip('\\').strip(oQpxmKiRPlHeGsLXNrJF78O).replace('\\\\','\\')
	title = ArwuTXMNsaO9fmjWdI(title)
	return title
def f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url,d7SyrAmUloW):
	import NsD5AomUqH
	NsD5AomUqH.NZcWGBmgFEen5hvJjUSIzOCVk7([url],HDLtdMAy7wPkl8aKC3O2,'video',url)
	return
def RT9LcrUXNko7KgbzO08hGFsP(search,zmL397efNlks5uTEV=HQmDERMFjx):
	if zmL397efNlks5uTEV==HQmDERMFjx: zmL397efNlks5uTEV = '1'
	if 'sortBy=' in search: sort = search.split('sortBy=')[1].split('&')[0]
	else: sort = HQmDERMFjx
	search = search.split('/videos')[0]
	S46ZVrhN1gWY0Iiaj = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeVideos":true,"page":mypagenumber,"limit":mypagelimitmysortmethod},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    views {      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment VIDEO_WATCH_LATER_FRAGMENT on Video {  id  isInWatchLater  __typename}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    videos {      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_WATCH_LATER_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	S46ZVrhN1gWY0Iiaj = S46ZVrhN1gWY0Iiaj.replace('mysearchwords',search)
	S46ZVrhN1gWY0Iiaj = S46ZVrhN1gWY0Iiaj.replace('mypagelimit','40')
	S46ZVrhN1gWY0Iiaj = S46ZVrhN1gWY0Iiaj.replace('mypagenumber',zmL397efNlks5uTEV)
	if sort==HQmDERMFjx: S46ZVrhN1gWY0Iiaj = S46ZVrhN1gWY0Iiaj.replace('mysortmethod',HQmDERMFjx)
	else: S46ZVrhN1gWY0Iiaj = S46ZVrhN1gWY0Iiaj.replace('mysortmethod',',"sortByVideos":"'+sort+'"')
	url = e2VR8nohduY+'/search/'+search+'/videos'
	CzNPJydxQLfw27tv4ZF8KORAbX5 = jBxWwr2CZJMIkL0uADOUP8Y6bgzhSp(S46ZVrhN1gWY0Iiaj,search)
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"videos"(.*?)"VideoConnection"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('"node":.*?"xid":"(.*?)",.*?"title":"(.*?)",.*?"name":"(.*?)",.*?"displayName":"(.*?)",.*?"duration":(.*?),".*?thumbnailx240":"(.*?)",',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for id,title,LSq9nwrkO2ThfvC05bPpAHBsN,vJ9G3ygrubaSjc8,OMDCpSL7ZB,uIGD4vZcP61QNmw78LXqoEpH in items:
			uIGD4vZcP61QNmw78LXqoEpH = uIGD4vZcP61QNmw78LXqoEpH.replace('\/',xufJqQcGnhboiVy2wd)
			vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+'/video/'+id
			title = Tc7WUd1Hhu9Dlvb4o(title)
			d7SyrAmUloW = LSq9nwrkO2ThfvC05bPpAHBsN+'::'+vJ9G3ygrubaSjc8
			CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,403,uIGD4vZcP61QNmw78LXqoEpH,OMDCpSL7ZB,d7SyrAmUloW)
		if '"hasNextPage":true' in CzNPJydxQLfw27tv4ZF8KORAbX5:
			zmL397efNlks5uTEV = str(int(zmL397efNlks5uTEV)+1)
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'صفحة '+zmL397efNlks5uTEV,url,404,HQmDERMFjx,zmL397efNlks5uTEV,search)
	return
def XfAL86ZJ3kO2lqwcIutY(search,zmL397efNlks5uTEV=HQmDERMFjx):
	if zmL397efNlks5uTEV==HQmDERMFjx: zmL397efNlks5uTEV = '1'
	S46ZVrhN1gWY0Iiaj = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":true,"shouldIncludeVideos":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    views {      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment VIDEO_WATCH_LATER_FRAGMENT on Video {  id  isInWatchLater  __typename}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    videos {      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_WATCH_LATER_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	S46ZVrhN1gWY0Iiaj = S46ZVrhN1gWY0Iiaj.replace('mysearchwords',search)
	S46ZVrhN1gWY0Iiaj = S46ZVrhN1gWY0Iiaj.replace('mypagelimit','40')
	S46ZVrhN1gWY0Iiaj = S46ZVrhN1gWY0Iiaj.replace('mypagenumber',zmL397efNlks5uTEV)
	url = e2VR8nohduY+'/search/'+search+'/playlists'
	CzNPJydxQLfw27tv4ZF8KORAbX5 = jBxWwr2CZJMIkL0uADOUP8Y6bgzhSp(S46ZVrhN1gWY0Iiaj,search)
	items = DyVGS3dX0ZxR.findall('"node".*?"xid":"(.*?)",.*?"name":"(.*?)",.*?"xid":"(.*?)",.*?"name":"(.*?)",.*?"displayName":"(.*?)",.*?"thumbnailx240":"(.*?)",.*?"total":(.*?),"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	for id,name,rA2QxZ3Lb4olsjHKUDF5Ovupf81,LSq9nwrkO2ThfvC05bPpAHBsN,vJ9G3ygrubaSjc8,uIGD4vZcP61QNmw78LXqoEpH,count in items:
		uIGD4vZcP61QNmw78LXqoEpH = uIGD4vZcP61QNmw78LXqoEpH.replace('\/',xufJqQcGnhboiVy2wd)
		vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+'/playlist/'+id
		title = 'LIST'+count+':  '+name
		title = Tc7WUd1Hhu9Dlvb4o(title)
		d7SyrAmUloW = LSq9nwrkO2ThfvC05bPpAHBsN+'::'+vJ9G3ygrubaSjc8
		CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,401,uIGD4vZcP61QNmw78LXqoEpH,HQmDERMFjx,d7SyrAmUloW)
	if '"hasNextPage":true' in CzNPJydxQLfw27tv4ZF8KORAbX5:
		zmL397efNlks5uTEV = str(int(zmL397efNlks5uTEV)+1)
		CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'صفحة '+zmL397efNlks5uTEV,url,405,HQmDERMFjx,zmL397efNlks5uTEV,search)
	return
def MDPiql2JxuHTdk(search,zmL397efNlks5uTEV=HQmDERMFjx):
	if zmL397efNlks5uTEV==HQmDERMFjx: zmL397efNlks5uTEV = '1'
	S46ZVrhN1gWY0Iiaj = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":true,"shouldIncludePlaylists":false,"shouldIncludeVideos":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    views {      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment VIDEO_WATCH_LATER_FRAGMENT on Video {  id  isInWatchLater  __typename}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    videos {      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_WATCH_LATER_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	S46ZVrhN1gWY0Iiaj = S46ZVrhN1gWY0Iiaj.replace('mysearchwords',search)
	S46ZVrhN1gWY0Iiaj = S46ZVrhN1gWY0Iiaj.replace('mypagelimit','40')
	S46ZVrhN1gWY0Iiaj = S46ZVrhN1gWY0Iiaj.replace('mypagenumber',zmL397efNlks5uTEV)
	url = e2VR8nohduY+'/search/'+search+'/channels'
	CzNPJydxQLfw27tv4ZF8KORAbX5 = jBxWwr2CZJMIkL0uADOUP8Y6bgzhSp(S46ZVrhN1gWY0Iiaj,search)
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"channels"(.*?)"ChannelConnection"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('"node".*?"name":"(.*?)",.*?"displayName":"(.*?)",.*?"thumbnailx240":"(.*?)",',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for id,name,uIGD4vZcP61QNmw78LXqoEpH in items:
			uIGD4vZcP61QNmw78LXqoEpH = uIGD4vZcP61QNmw78LXqoEpH.replace('\/',xufJqQcGnhboiVy2wd)
			vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+xufJqQcGnhboiVy2wd+id
			title = 'USER:  '+name
			title = Tc7WUd1Hhu9Dlvb4o(title)
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,402,uIGD4vZcP61QNmw78LXqoEpH,HQmDERMFjx,name)
		if '"hasNextPage":true' in CzNPJydxQLfw27tv4ZF8KORAbX5:
			zmL397efNlks5uTEV = str(int(zmL397efNlks5uTEV)+1)
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'صفحة '+zmL397efNlks5uTEV,url,406,HQmDERMFjx,zmL397efNlks5uTEV,search)
	return
def ToScuwIyFz3pj(J68g5jbRQo4tCH):
	S46ZVrhN1gWY0Iiaj = '''{"operationName":"HOME_QUERY","variables":{"space":"nextplore"},"query":"fragment TOPIC_BASE_FRAG on Topic {  id  xid  name  thumbnail: coverURL(size: \\"x532\\")  coverURL: coverURL(size: \\"x532\\")  isFollowed  whitelistStatus {    id    isWhitelisted    __typename  }  __typename}query HOME_QUERY($space: String!) {  home: views {    id    neon {      id      sections(space: $space) {        edges {          node {            id            name            title            description            groupingType            type            relatedComponent {              __typename              ... on Collection {                id                xid                __typename              }              ... on Channel {                id                xid                name                displayName                logoURL(size: \\"x60\\")                __typename              }              ... on Topic {                id                __typename                ...TOPIC_BASE_FRAG              }            }            components {              edges {                node {                  __typename                  ... on Video {                    id                    xid                    title                    thumbnailx60: thumbnailURL(size: \\"x60\\")                    thumbnailx120: thumbnailURL(size: \\"x120\\")                    thumbnailx240: thumbnailURL(size: \\"x240\\")                    thumbnailx360: thumbnailURL(size: \\"x360\\")                    thumbnailx480: thumbnailURL(size: \\"x480\\")                    thumbnailx720: thumbnailURL(size: \\"x720\\")                    aspectRatio                    createdAt                    channel {                      id                      xid                      name                      displayName                      logoURLx25: logoURL(size: \\"x25\\")                      accountType                      __typename                    }                    description                    duration                    __typename                  }                  ... on Live {                    id                    xid                    title                    thumbnailx60: thumbnailURL(size: \\"x60\\")                    thumbnailx120: thumbnailURL(size: \\"x120\\")                    thumbnailx240: thumbnailURL(size: \\"x240\\")                    thumbnailx360: thumbnailURL(size: \\"x360\\")                    thumbnailx480: thumbnailURL(size: \\"x480\\")                    thumbnailx720: thumbnailURL(size: \\"x720\\")                    aspectRatio                    createdAt                    channel {                      id                      xid                      name                      displayName                      logoURLx25: logoURL(size: \\"x25\\")                      accountType                      __typename                    }                    startAt                    __typename                  }                }                __typename              }              __typename            }            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	m7yHNwvntVlcioLWEB9ZPISYgR = jBxWwr2CZJMIkL0uADOUP8Y6bgzhSp(S46ZVrhN1gWY0Iiaj)
	if m7yHNwvntVlcioLWEB9ZPISYgR:
		q3LFpN9WXHcr4n = aknZqSJyUrFgc9VhH2Psot6e7b8('dict',m7yHNwvntVlcioLWEB9ZPISYgR)
		NWEAKR6d5iJ8FO0wDeHPMlhpvgT21G = q3LFpN9WXHcr4n['data']['home']['neon']['sections']['edges']
		if not J68g5jbRQo4tCH:
			xLk7CmpVS625WjIoKhtG8zcJyPBAO = []
			for o45IWvdchQ3UiJxmFZbEYfq in NWEAKR6d5iJ8FO0wDeHPMlhpvgT21G:
				e9dRxHLVyn6obQM = o45IWvdchQ3UiJxmFZbEYfq['node']['title']
				if e9dRxHLVyn6obQM not in xLk7CmpVS625WjIoKhtG8zcJyPBAO: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+e9dRxHLVyn6obQM,HQmDERMFjx,414,HQmDERMFjx,HQmDERMFjx,e9dRxHLVyn6obQM)
				xLk7CmpVS625WjIoKhtG8zcJyPBAO.append(e9dRxHLVyn6obQM)
		else:
			for o45IWvdchQ3UiJxmFZbEYfq in NWEAKR6d5iJ8FO0wDeHPMlhpvgT21G:
				e9dRxHLVyn6obQM = o45IWvdchQ3UiJxmFZbEYfq['node']['title']
				if e9dRxHLVyn6obQM==J68g5jbRQo4tCH:
					DM1piZPEuBeLwdyS = o45IWvdchQ3UiJxmFZbEYfq['node']['components']['edges']
					for BwDnou3UN8gf95TdIS7xCY2zEji in DM1piZPEuBeLwdyS:
						OMDCpSL7ZB = str(BwDnou3UN8gf95TdIS7xCY2zEji['node']['duration'])
						title = ArwuTXMNsaO9fmjWdI(BwDnou3UN8gf95TdIS7xCY2zEji['node']['title'])
						title = title.replace('\/',xufJqQcGnhboiVy2wd)
						q05vV2mPaZYfBC3Js = BwDnou3UN8gf95TdIS7xCY2zEji['node']['xid']
						uIGD4vZcP61QNmw78LXqoEpH = BwDnou3UN8gf95TdIS7xCY2zEji['node']['thumbnailx480']
						uIGD4vZcP61QNmw78LXqoEpH = uIGD4vZcP61QNmw78LXqoEpH.replace('\/',xufJqQcGnhboiVy2wd)
						vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+'/video/'+q05vV2mPaZYfBC3Js
						CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,403,uIGD4vZcP61QNmw78LXqoEpH,OMDCpSL7ZB)
	return
def TOwxWMp8FuDReyHrYcVlBKN536n(search,zmL397efNlks5uTEV=HQmDERMFjx):
	if zmL397efNlks5uTEV==HQmDERMFjx: zmL397efNlks5uTEV = '1'
	S46ZVrhN1gWY0Iiaj = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeTopics":false,"shouldIncludeVideos":false,"shouldIncludeLives":true,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    id    views {      id      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  aspectRatio  __typename}fragment VIDEO_FAVORITES_FRAGMENT on Media {  __typename  ... on Video {    id    viewerEngagement {      id      favorited      __typename    }    __typename  }  ... on Live {    id    viewerEngagement {      id      favorited      __typename    }    __typename  }}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}fragment TOPIC_BASE_FRAG on Topic {  id  xid  name  videos(sort: \\"recent\\", first: 5) {    pageInfo {      hasNextPage      nextPage      __typename    }    edges {      node {        id        ...VIDEO_BASE_FRAGMENT        ...VIDEO_FAVORITES_FRAGMENT        __typename      }      __typename    }    __typename  }  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeTopics: Boolean!, $shouldIncludeLives: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(      query: $query      first: $limit      page: $page      sort: $sortByVideos      durationMin: $durationMinVideos      durationMax: $durationMaxVideos      createdAfter: $createdAfterVideos    ) @include(if: $shouldIncludeVideos) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_FAVORITES_FRAGMENT          __typename        }        __typename      }      __typename    }    lives(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeLives) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          xid          title          thumbnail: thumbnailURL(size: \\"x240\\")          thumbnailx60: thumbnailURL(size: \\"x60\\")          thumbnailx120: thumbnailURL(size: \\"x120\\")          thumbnailx240: thumbnailURL(size: \\"x240\\")          thumbnailx720: thumbnailURL(size: \\"x720\\")          audienceCount          aspectRatio          isOnAir          channel {            id            xid            name            displayName            accountType            __typename          }          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    topics(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeTopics) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...TOPIC_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	S46ZVrhN1gWY0Iiaj = S46ZVrhN1gWY0Iiaj.replace('mysearchwords',search)
	S46ZVrhN1gWY0Iiaj = S46ZVrhN1gWY0Iiaj.replace('mypagelimit','40')
	S46ZVrhN1gWY0Iiaj = S46ZVrhN1gWY0Iiaj.replace('mypagenumber',zmL397efNlks5uTEV)
	url = e2VR8nohduY+'/search/'+search+'/lives'
	m7yHNwvntVlcioLWEB9ZPISYgR = jBxWwr2CZJMIkL0uADOUP8Y6bgzhSp(S46ZVrhN1gWY0Iiaj,search)
	if m7yHNwvntVlcioLWEB9ZPISYgR:
		q3LFpN9WXHcr4n = aknZqSJyUrFgc9VhH2Psot6e7b8('dict',m7yHNwvntVlcioLWEB9ZPISYgR)
		try: NWEAKR6d5iJ8FO0wDeHPMlhpvgT21G = q3LFpN9WXHcr4n['data']['search']['lives']['edges']
		except: NWEAKR6d5iJ8FO0wDeHPMlhpvgT21G = []
		for o45IWvdchQ3UiJxmFZbEYfq in NWEAKR6d5iJ8FO0wDeHPMlhpvgT21G:
			name = o45IWvdchQ3UiJxmFZbEYfq['node']['title']
			name = ArwuTXMNsaO9fmjWdI(name)
			q05vV2mPaZYfBC3Js = o45IWvdchQ3UiJxmFZbEYfq['node']['xid']
			vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+'/video/'+q05vV2mPaZYfBC3Js
			CfgK4s13Q0hZcHyleT2bVJO9('live',EEJvXQzSZNt+'LIVE: '+name,vn1grP3y4It9GmVuBbLJfz2A,403)
		if '"hasNextPage":true' in m7yHNwvntVlcioLWEB9ZPISYgR:
			zmL397efNlks5uTEV = str(int(zmL397efNlks5uTEV)+1)
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'صفحة '+zmL397efNlks5uTEV,url,415,HQmDERMFjx,zmL397efNlks5uTEV,search)
	return
def J7jQF0Bm3rxyRvOfGa4l9MVIDLNb(search,zmL397efNlks5uTEV=HQmDERMFjx):
	if zmL397efNlks5uTEV==HQmDERMFjx: zmL397efNlks5uTEV = '1'
	S46ZVrhN1gWY0Iiaj = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeTopics":true,"shouldIncludeVideos":false,"shouldIncludeLives":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    id    views {      id      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  aspectRatio  __typename}fragment VIDEO_FAVORITES_FRAGMENT on Media {  __typename  ... on Video {    id    isInWatchLater    __typename  }  ... on Live {    id    isInWatchLater    __typename  }}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}fragment TOPIC_BASE_FRAG on Topic {  id  xid  name  videos(sort: \\"recent\\", first: 5) {    pageInfo {      hasNextPage      nextPage      __typename    }    edges {      node {        id        ...VIDEO_BASE_FRAGMENT        ...VIDEO_FAVORITES_FRAGMENT        __typename      }      __typename    }    __typename  }  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeTopics: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(      query: $query      first: $limit      page: $page      sort: $sortByVideos      durationMin: $durationMinVideos      durationMax: $durationMaxVideos      createdAfter: $createdAfterVideos    ) @include(if: $shouldIncludeVideos) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_FAVORITES_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    topics(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeTopics) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...TOPIC_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	S46ZVrhN1gWY0Iiaj = S46ZVrhN1gWY0Iiaj.replace('mysearchwords',search)
	S46ZVrhN1gWY0Iiaj = S46ZVrhN1gWY0Iiaj.replace('mypagelimit','40')
	S46ZVrhN1gWY0Iiaj = S46ZVrhN1gWY0Iiaj.replace('mypagenumber',zmL397efNlks5uTEV)
	url = e2VR8nohduY+'/search/'+search+'/topics'
	m7yHNwvntVlcioLWEB9ZPISYgR = jBxWwr2CZJMIkL0uADOUP8Y6bgzhSp(S46ZVrhN1gWY0Iiaj,search)
	if m7yHNwvntVlcioLWEB9ZPISYgR:
		q3LFpN9WXHcr4n = aknZqSJyUrFgc9VhH2Psot6e7b8('dict',m7yHNwvntVlcioLWEB9ZPISYgR)
		try: NWEAKR6d5iJ8FO0wDeHPMlhpvgT21G = q3LFpN9WXHcr4n['data']['search']['topics']['edges']
		except: NWEAKR6d5iJ8FO0wDeHPMlhpvgT21G = []
		for o45IWvdchQ3UiJxmFZbEYfq in NWEAKR6d5iJ8FO0wDeHPMlhpvgT21G:
			name = o45IWvdchQ3UiJxmFZbEYfq['node']['name']
			q05vV2mPaZYfBC3Js = o45IWvdchQ3UiJxmFZbEYfq['node']['xid']
			vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+'/topic/'+q05vV2mPaZYfBC3Js
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'TOPIC: '+name,vn1grP3y4It9GmVuBbLJfz2A,413)
		if '"hasNextPage":true' in m7yHNwvntVlcioLWEB9ZPISYgR:
			zmL397efNlks5uTEV = str(int(zmL397efNlks5uTEV)+1)
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'صفحة '+zmL397efNlks5uTEV,url,412,HQmDERMFjx,zmL397efNlks5uTEV,search)
	return
def pxaz1239dCvSEfn57VTmGuBgWeyX(url,zmL397efNlks5uTEV=HQmDERMFjx):
	if zmL397efNlks5uTEV==HQmDERMFjx: zmL397efNlks5uTEV = '1'
	q05vV2mPaZYfBC3Js = url.split(xufJqQcGnhboiVy2wd)[-1]
	S46ZVrhN1gWY0Iiaj = '''{"operationName":"DISCOVERY_TOPIC_MAIN_QUERY","variables":{"page":mypagenumber,"xid":"mytopicid"},"query":"fragment TOPIC_VIDEO_FRAGMENT on Video {  id  xid  title  duration  isLiked  isInWatchLater  isCreatedForKids  createdAt  isExplicit  videoHeight: height  videoWidth: width  category  channel {    id    xid    name    displayName    logoURLx25: logoURL(size: \\"x25\\")    logoURL(size: \\"x60\\")    accountType    __typename  }  stats {    id    views {      id      total      __typename    }    __typename  }  language {    id    codeAlpha2    __typename  }  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  bestAvailableQuality  aspectRatio  isPublished  __typename}query DISCOVERY_TOPIC_MAIN_QUERY($xid: String!, $page: Int = 1) {  topic(xid: $xid) {    id    xid    name    videos(sort: \\"recent\\", first: 30, page: $page) {      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...TOPIC_VIDEO_FRAGMENT          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	S46ZVrhN1gWY0Iiaj = S46ZVrhN1gWY0Iiaj.replace('mytopicid',q05vV2mPaZYfBC3Js)
	S46ZVrhN1gWY0Iiaj = S46ZVrhN1gWY0Iiaj.replace('mypagenumber',zmL397efNlks5uTEV)
	m7yHNwvntVlcioLWEB9ZPISYgR = jBxWwr2CZJMIkL0uADOUP8Y6bgzhSp(S46ZVrhN1gWY0Iiaj)
	if m7yHNwvntVlcioLWEB9ZPISYgR:
		q3LFpN9WXHcr4n = aknZqSJyUrFgc9VhH2Psot6e7b8('dict',m7yHNwvntVlcioLWEB9ZPISYgR)
		NWEAKR6d5iJ8FO0wDeHPMlhpvgT21G = q3LFpN9WXHcr4n['data']['topic']['videos']['edges']
		for o45IWvdchQ3UiJxmFZbEYfq in NWEAKR6d5iJ8FO0wDeHPMlhpvgT21G:
			OMDCpSL7ZB = str(o45IWvdchQ3UiJxmFZbEYfq['node']['duration'])
			title = ArwuTXMNsaO9fmjWdI(o45IWvdchQ3UiJxmFZbEYfq['node']['title'])
			title = title.replace('\/',xufJqQcGnhboiVy2wd)
			q05vV2mPaZYfBC3Js = o45IWvdchQ3UiJxmFZbEYfq['node']['xid']
			uIGD4vZcP61QNmw78LXqoEpH = o45IWvdchQ3UiJxmFZbEYfq['node']['thumbnailx480']
			uIGD4vZcP61QNmw78LXqoEpH = uIGD4vZcP61QNmw78LXqoEpH.replace('\/',xufJqQcGnhboiVy2wd)
			vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+'/video/'+q05vV2mPaZYfBC3Js
			CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,403,uIGD4vZcP61QNmw78LXqoEpH,OMDCpSL7ZB)
		if '"hasNextPage":true' in m7yHNwvntVlcioLWEB9ZPISYgR:
			zmL397efNlks5uTEV = str(int(zmL397efNlks5uTEV)+1)
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'صفحة '+zmL397efNlks5uTEV,url,413,HQmDERMFjx,zmL397efNlks5uTEV)
	return
def x1xsL0QhH3r5oad(url,d7SyrAmUloW):
	id = url.split(xufJqQcGnhboiVy2wd)[-1]
	LSq9nwrkO2ThfvC05bPpAHBsN,vJ9G3ygrubaSjc8 = d7SyrAmUloW.split('::',1)
	vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+xufJqQcGnhboiVy2wd+LSq9nwrkO2ThfvC05bPpAHBsN
	vJ9G3ygrubaSjc8 = Tc7WUd1Hhu9Dlvb4o(vJ9G3ygrubaSjc8)
	title = ao3Q5jP8H0sMxK2iUYwZGE+'OWNER:  '+vJ9G3ygrubaSjc8+cjqzOQ5GXD4kR
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,402,HQmDERMFjx,HQmDERMFjx,vJ9G3ygrubaSjc8)
	S46ZVrhN1gWY0Iiaj = '''{"operationName":"DISCOVERY_QUEUE_QUERY","variables":{"collectionXid":"myplaylistid","videoXid":"x7s7qbn"},"query":"query DISCOVERY_QUEUE_QUERY($videoXid: String!, $collectionXid: String, $device: String, $videoCountPerSection: Int) {  views {    id    neon {      id      sections(device: $device, space: \\"watching\\", followingChannelXids: [], followingTopicXids: [], watchedVideoXids: [], context: {mediaXid: $videoXid, collectionXid: $collectionXid}, first: 20) {        edges {          node {            id            name            groupingType            relatedComponent {              ... on Channel {                __typename                id                xid                name                displayName                logoURL(size: \\"x60\\")                logoURLx25: logoURL(size: \\"x25\\")              }              ... on Topic {                __typename                id                xid                name                names {                  edges {                    node {                      id                      name                      language {                        id                        codeAlpha2                        __typename                      }                      __typename                    }                    __typename                  }                  __typename                }              }              ... on Collection {                __typename                id                xid                name              }              __typename            }            components(first: $videoCountPerSection) {              metadata {                algorithm {                  name                  version                  uuid                  __typename                }                __typename              }              edges {                node {                  ... on Video {                    __typename                    id                    xid                    title                    duration                    thumbnailx60: thumbnailURL(size: \\"x60\\")                    thumbnailx120: thumbnailURL(size: \\"x120\\")                    thumbnailx240: thumbnailURL(size: \\"x240\\")                    thumbnailx720: thumbnailURL(size: \\"x720\\")                    channel {                      id                      xid                      accountType                      displayName                      logoURLx25: logoURL(size: \\"x25\\")                      logoURL(size: \\"x60\\")                      __typename                    }                  }                  ... on Channel {                    __typename                    id                    xid                    name                    displayName                    accountType                    logoURL(size: \\"x60\\")                  }                  __typename                }                __typename              }              __typename            }            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	S46ZVrhN1gWY0Iiaj = S46ZVrhN1gWY0Iiaj.replace('myplaylistid',id)
	CzNPJydxQLfw27tv4ZF8KORAbX5 = jBxWwr2CZJMIkL0uADOUP8Y6bgzhSp(S46ZVrhN1gWY0Iiaj)
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"collection_videos"(.*?)"SectionEdge"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('"node".*?"xid":"(.*?)",.*?"title":"(.*?)",.*?"duration":(.*?),".*?thumbnailx240":"(.*?)",.*?"xid":"(.*?)",.*?"displayName":"(.*?)",',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for id,title,OMDCpSL7ZB,uIGD4vZcP61QNmw78LXqoEpH,LSq9nwrkO2ThfvC05bPpAHBsN,vJ9G3ygrubaSjc8 in items:
			uIGD4vZcP61QNmw78LXqoEpH = uIGD4vZcP61QNmw78LXqoEpH.replace('\/',xufJqQcGnhboiVy2wd)
			vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+'/video/'+id
			title = Tc7WUd1Hhu9Dlvb4o(title)
			d7SyrAmUloW = LSq9nwrkO2ThfvC05bPpAHBsN+'::'+vJ9G3ygrubaSjc8
			CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,403,uIGD4vZcP61QNmw78LXqoEpH,OMDCpSL7ZB,d7SyrAmUloW)
	return
def mQMeF076n2TCOIPJRjyuaKw3xlG(url,zmL397efNlks5uTEV=HQmDERMFjx):
	if zmL397efNlks5uTEV==HQmDERMFjx: zmL397efNlks5uTEV = '1'
	ZLRQYEUBNPSl3XTxze6Iug = url.split(xufJqQcGnhboiVy2wd)[-2]
	if 'sort=' in url: sort = url.split('sort=')[1].split('&')[0]
	else: sort = 'recent'
	S46ZVrhN1gWY0Iiaj = '''{"operationName":"CHANNEL_VIDEOS_QUERY","variables":{"channel_xid":"mychannelid","sort":"mysortmethod","page":mypagenumber},"query":"fragment CHANNEL_BASE_FRAGMENT on Channel {  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  isFollowed  accountType  __typename}fragment CHANNEL_IMAGES_FRAGMENT on Channel {  id  coverURLx375: coverURL(size: \\"x375\\")  __typename}fragment CHANNEL_UPDATED_FRAGMENT on Channel {  id  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}fragment CHANNEL_COMPLETE_FRAGMENT on Channel {  id  ...CHANNEL_BASE_FRAGMENT  ...CHANNEL_IMAGES_FRAGMENT  ...CHANNEL_UPDATED_FRAGMENT  description  coverURL1024x: coverURL(size: \\"1024x\\")  coverURL1920x: coverURL(size: \\"1920x\\")  externalLinks {    facebookURL    twitterURL    websiteURL    instagramURL    __typename  }  __typename}fragment CHANNEL_FRAGMENT on Channel {  accountType  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  coverURLx375: coverURL(size: \\"x375\\")  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}fragment VIDEO_FRAGMENT on Video {  id  xid  title  viewCount  duration  createdAt  isInWatchLater  channel {    id    ...CHANNEL_FRAGMENT    __typename  }  thumbURLx240: thumbnailURL(size: \\"x240\\")  thumbURLx360: thumbnailURL(size: \\"x360\\")  thumbURLx480: thumbnailURL(size: \\"x480\\")  thumbURLx720: thumbnailURL(size: \\"x720\\")  __typename}query CHANNEL_VIDEOS_QUERY($channel_xid: String!, $sort: String, $page: Int!) {  channel(xid: $channel_xid) {    id    ...CHANNEL_COMPLETE_FRAGMENT    channel_videos_all_videos: videos(sort: $sort, page: $page, first: mypagelimit) {      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...VIDEO_FRAGMENT          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	S46ZVrhN1gWY0Iiaj = S46ZVrhN1gWY0Iiaj.replace('mychannelid',ZLRQYEUBNPSl3XTxze6Iug)
	S46ZVrhN1gWY0Iiaj = S46ZVrhN1gWY0Iiaj.replace('mypagelimit','40')
	S46ZVrhN1gWY0Iiaj = S46ZVrhN1gWY0Iiaj.replace('mypagenumber',zmL397efNlks5uTEV)
	S46ZVrhN1gWY0Iiaj = S46ZVrhN1gWY0Iiaj.replace('mysortmethod',sort)
	CzNPJydxQLfw27tv4ZF8KORAbX5 = jBxWwr2CZJMIkL0uADOUP8Y6bgzhSp(S46ZVrhN1gWY0Iiaj)
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"channel_videos_all_videos"(.*?)"VideoConnection"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('"node".*?"xid":"(.*?)",.*?"title":"(.*?)",.*?"duration":(.*?),".*?name":"(.*?)",.*?"displayName":"(.*?)",.*?"thumbURLx240":"(.*?)",',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for id,title,OMDCpSL7ZB,LSq9nwrkO2ThfvC05bPpAHBsN,vJ9G3ygrubaSjc8,uIGD4vZcP61QNmw78LXqoEpH in items:
			uIGD4vZcP61QNmw78LXqoEpH = uIGD4vZcP61QNmw78LXqoEpH.replace('\/',xufJqQcGnhboiVy2wd)
			vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+'/video/'+id
			title = Tc7WUd1Hhu9Dlvb4o(title)
			d7SyrAmUloW = LSq9nwrkO2ThfvC05bPpAHBsN+'::'+vJ9G3ygrubaSjc8
			CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,403,uIGD4vZcP61QNmw78LXqoEpH,OMDCpSL7ZB,d7SyrAmUloW)
		if '"hasNextPage":true' in CzNPJydxQLfw27tv4ZF8KORAbX5:
			zmL397efNlks5uTEV = str(int(zmL397efNlks5uTEV)+1)
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'صفحة '+zmL397efNlks5uTEV,url,408,HQmDERMFjx,zmL397efNlks5uTEV)
	return
def Q1blHG862i9tekxUzWdFrBN(url,zmL397efNlks5uTEV=HQmDERMFjx):
	if zmL397efNlks5uTEV==HQmDERMFjx: zmL397efNlks5uTEV = '1'
	ZLRQYEUBNPSl3XTxze6Iug = url.split(xufJqQcGnhboiVy2wd)[-2]
	if 'sort=' in url: sort = url.split('sort=')[1].split('&')[0]
	else: sort = 'recent'
	S46ZVrhN1gWY0Iiaj = '''{"operationName":"CHANNEL_COLLECTIONS_QUERY","variables":{"channel_xid":"mychannelid","sort":"mysortmethod","page":mypagenumber},"query":"fragment CHANNEL_BASE_FRAGMENT on Channel {  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  isFollowed  accountType  __typename}fragment CHANNEL_IMAGES_FRAGMENT on Channel {  id  coverURLx375: coverURL(size: \\"x375\\")  __typename}fragment CHANNEL_UPDATED_FRAGMENT on Channel {  id  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}fragment CHANNEL_COMPLETE_FRAGMENT on Channel {  id  ...CHANNEL_BASE_FRAGMENT  ...CHANNEL_IMAGES_FRAGMENT  ...CHANNEL_UPDATED_FRAGMENT  description  coverURL1024x: coverURL(size: \\"1024x\\")  coverURL1920x: coverURL(size: \\"1920x\\")  externalLinks {    facebookURL    twitterURL    websiteURL    instagramURL    __typename  }  __typename}fragment CHANNEL_FRAGMENT on Channel {  accountType  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  coverURLx375: coverURL(size: \\"x375\\")  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}query CHANNEL_COLLECTIONS_QUERY($channel_xid: String!, $sort: String, $page: Int!) {  channel(xid: $channel_xid) {    id    ...CHANNEL_COMPLETE_FRAGMENT    channel_playlist_collections: collections(sort: $sort, page: $page, first: mypagelimit) {      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          xid          updatedAt          name          description          thumbURLx240: thumbnailURL(size: \\"x240\\")          thumbURLx360: thumbnailURL(size: \\"x360\\")          thumbURLx480: thumbnailURL(size: \\"x480\\")          stats {            videos {              total              __typename            }            __typename          }          channel {            id            ...CHANNEL_FRAGMENT            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	S46ZVrhN1gWY0Iiaj = S46ZVrhN1gWY0Iiaj.replace('mychannelid',ZLRQYEUBNPSl3XTxze6Iug)
	S46ZVrhN1gWY0Iiaj = S46ZVrhN1gWY0Iiaj.replace('mypagelimit','40')
	S46ZVrhN1gWY0Iiaj = S46ZVrhN1gWY0Iiaj.replace('mypagenumber',zmL397efNlks5uTEV)
	S46ZVrhN1gWY0Iiaj = S46ZVrhN1gWY0Iiaj.replace('mysortmethod',sort)
	CzNPJydxQLfw27tv4ZF8KORAbX5 = jBxWwr2CZJMIkL0uADOUP8Y6bgzhSp(S46ZVrhN1gWY0Iiaj)
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"channel_playlist_collections"(.*?)"CollectionConnection"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('"node".*?"xid":"(.*?)",.*?"name":"(.*?)",.*?"thumbURLx240":"(.*?)",.*?"total":(.*?),".*?xid":"(.*?)",.*?"name":"(.*?)",.*?"displayName":"(.*?)",',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for id,name,uIGD4vZcP61QNmw78LXqoEpH,count,rA2QxZ3Lb4olsjHKUDF5Ovupf81,LSq9nwrkO2ThfvC05bPpAHBsN,vJ9G3ygrubaSjc8 in items:
			uIGD4vZcP61QNmw78LXqoEpH = uIGD4vZcP61QNmw78LXqoEpH.replace('\/',xufJqQcGnhboiVy2wd)
			vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+'/playlist/'+id
			title = 'LIST'+count+':  '+name
			title = Tc7WUd1Hhu9Dlvb4o(title)
			d7SyrAmUloW = LSq9nwrkO2ThfvC05bPpAHBsN+'::'+vJ9G3ygrubaSjc8
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,401,uIGD4vZcP61QNmw78LXqoEpH,HQmDERMFjx,d7SyrAmUloW)
		if '"hasNextPage":true' in CzNPJydxQLfw27tv4ZF8KORAbX5:
			zmL397efNlks5uTEV = str(int(zmL397efNlks5uTEV)+1)
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'صفحة '+zmL397efNlks5uTEV,url,407,HQmDERMFjx,zmL397efNlks5uTEV)
	return
def IXZ4OcxaYgPl(url,llOWhzQxFuZJtb2pLGRyUfPnIsTD):
	ZLRQYEUBNPSl3XTxze6Iug = url.split(xufJqQcGnhboiVy2wd)[3]
	S46ZVrhN1gWY0Iiaj = '''{"operationName":"CHANNEL_QUERY_DESKTOP","variables":{"channel_name":"mychannelid","relatedChannels":100},"query":"fragment CHANNEL_FRAGMENT on Channel {  accountType  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  coverURLx375: coverURL(size: \\"x375\\")  isFollowed  stats {    id    views {      id      total      __typename    }    followers {      id      total      __typename    }    videos {      id      total      __typename    }    __typename  }  __typename}fragment LIVE_FRAGMENT on Live {  id  xid  title  startAt  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  channel {    id    ...CHANNEL_FRAGMENT    __typename  }  __typename}fragment VIDEO_FRAGMENT on Video {  id  xid  title  viewCount  duration  createdAt  isInWatchLater  channel {    id    ...CHANNEL_FRAGMENT    __typename  }  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment CHANNEL_MAIN_FRAGMENT on Channel {  id  xid  name  displayName  description  accountType  isArtist  logoURL(size: \\"x60\\")  coverURL1024x: coverURL(size: \\"1024x\\")  coverURL1920x: coverURL(size: \\"1920x\\")  isFollowed  tagline  country {    id    codeAlpha2    __typename  }  stats {    id    views {      id      total      __typename    }    followers {      id      total      __typename    }    videos {      id      total      __typename    }    __typename  }  externalLinks {    id    facebookURL    twitterURL    websiteURL    instagramURL    pinterestURL    __typename  }  channel_lives_now: lives(first: 4, isOnAir: true) {    edges {      node {        id        ...LIVE_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_lives_scheduled: lives(first: 4, startIn: 7200) {    edges {      node {        id        ...LIVE_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_featured_videos: videos(first: 4, isFeatured: true) {    edges {      node {        id        ...VIDEO_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_all_videos: videos(first: 4) {    edges {      node {        id        ...VIDEO_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_most_viewed: videos(first: 4, sort: \\"visited\\") {    edges {      node {        id        ...VIDEO_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_collections: collections(first: 4) {    edges {      node {        id        xid        name        description        stats {          id          videos {            id            total            __typename          }          __typename        }        thumbnailx240: thumbnailURL(size: \\"x240\\")        thumbnailx360: thumbnailURL(size: \\"x360\\")        thumbnailx480: thumbnailURL(size: \\"x480\\")        channel {          id          ...CHANNEL_FRAGMENT          __typename        }        __typename      }      __typename    }    __typename  }  channel_related_channel: networkChannels(    hasPublicVideos: true    first: $relatedChannels  ) {    edges {      node {        id        ...CHANNEL_FRAGMENT        __typename      }      __typename    }    __typename  }  __typename}query CHANNEL_QUERY_DESKTOP($channel_name: String!, $relatedChannels: Int) {  channel(name: $channel_name) {    id    ...CHANNEL_MAIN_FRAGMENT    __typename  }}"}'''
	S46ZVrhN1gWY0Iiaj = S46ZVrhN1gWY0Iiaj.replace('mychannelid',ZLRQYEUBNPSl3XTxze6Iug)
	CzNPJydxQLfw27tv4ZF8KORAbX5 = jBxWwr2CZJMIkL0uADOUP8Y6bgzhSp(S46ZVrhN1gWY0Iiaj)
	yFOskEjLN8GZM = IsGwR1YyfQqa4picCZ6m.loads(CzNPJydxQLfw27tv4ZF8KORAbX5)
	try: items = yFOskEjLN8GZM['data']['channel'][llOWhzQxFuZJtb2pLGRyUfPnIsTD]['edges']
	except: items = []
	if not items: CfgK4s13Q0hZcHyleT2bVJO9('link',EEJvXQzSZNt+'لا توجد نتائج',HQmDERMFjx,9999)
	else:
		for A07BpVeRJToLb in items:
			gfqdxCWR3982Soba = A07BpVeRJToLb['node']
			q05vV2mPaZYfBC3Js = gfqdxCWR3982Soba['xid']
			keys = list(gfqdxCWR3982Soba.keys())
			dr74qC9V5zBN3v8pfHbawitS1h = gfqdxCWR3982Soba['__typename'].lower()
			if dr74qC9V5zBN3v8pfHbawitS1h=='channel':
				name = gfqdxCWR3982Soba['name']
				CTRaPtxqkQDvNH7Bn2KErwFjM3 = gfqdxCWR3982Soba['displayName']
				title = 'USER:  '+CTRaPtxqkQDvNH7Bn2KErwFjM3
				uIGD4vZcP61QNmw78LXqoEpH = gfqdxCWR3982Soba['coverURLx375']
			else:
				name = gfqdxCWR3982Soba['channel']['name']
				CTRaPtxqkQDvNH7Bn2KErwFjM3 = gfqdxCWR3982Soba['channel']['displayName']
				title = gfqdxCWR3982Soba['title']
				uIGD4vZcP61QNmw78LXqoEpH = gfqdxCWR3982Soba['thumbnailx360']
				if dr74qC9V5zBN3v8pfHbawitS1h=='live': title = 'LIVE:  '+title
			title = Tc7WUd1Hhu9Dlvb4o(title)
			d7SyrAmUloW = name+'::'+CTRaPtxqkQDvNH7Bn2KErwFjM3
			if C6H1qXua3SMQiIrzxNvJWZE:
				title = title.encode(Zex6D4tJE52r)
				d7SyrAmUloW = d7SyrAmUloW.encode(Zex6D4tJE52r)
			uIGD4vZcP61QNmw78LXqoEpH = uIGD4vZcP61QNmw78LXqoEpH.replace('\/',xufJqQcGnhboiVy2wd)
			if dr74qC9V5zBN3v8pfHbawitS1h=='channel':
				vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+xufJqQcGnhboiVy2wd+q05vV2mPaZYfBC3Js
				CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,402,uIGD4vZcP61QNmw78LXqoEpH,HQmDERMFjx,d7SyrAmUloW)
			else:
				if dr74qC9V5zBN3v8pfHbawitS1h=='video': OMDCpSL7ZB = str(gfqdxCWR3982Soba['duration'])
				else: OMDCpSL7ZB = HQmDERMFjx
				vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+'/video/'+q05vV2mPaZYfBC3Js
				CfgK4s13Q0hZcHyleT2bVJO9(dr74qC9V5zBN3v8pfHbawitS1h,EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,403,uIGD4vZcP61QNmw78LXqoEpH,OMDCpSL7ZB,d7SyrAmUloW)
	return
def qATVJiEK86L9U(search,zmL397efNlks5uTEV=HQmDERMFjx):
	if zmL397efNlks5uTEV==HQmDERMFjx: zmL397efNlks5uTEV = '1'
	S46ZVrhN1gWY0Iiaj = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeHashtags":true,"shouldIncludeVideos":false,"shouldIncludeLives":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  duration  aspectRatio  thumbnail(height: PORTRAIT_240) {    id    url    __typename  }  creator {    id    xid    name    displayName    accountType    avatar(height: SQUARE_60) {      id      url      __typename    }    __typename  }  __typename}fragment CHANNEL_BASE_FRAG on Channel {  id  xid  name  displayName  accountType  isFollowed  avatar(height: SQUARE_120) {    id    url    __typename  }  followerEngagement {    id    followDate    __typename  }  metrics {    id    engagement {      id      followers {        edges {          node {            id            total            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  description  thumbnail(height: PORTRAIT_240) {    id    url    __typename  }  creator {    id    xid    name    displayName    accountType    avatar(height: SQUARE_60) {      id      url      __typename    }    __typename  }  metrics {    id    engagement {      id      videos(filter: {visibility: {eq: PUBLIC}}) {        edges {          node {            id            total            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }  __typename}fragment HASHTAG_BASE_FRAG on Hashtag {  id  xid  name  metrics {    id    engagement {      id      videos {        edges {          node {            id            total            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }  __typename}fragment LIVE_BASE_FRAGMENT on Live {  id  xid  title  audienceCount  aspectRatio  isOnAir  thumbnail(height: PORTRAIT_240) {    id    url    __typename  }  creator {    id    xid    name    displayName    accountType    avatar(height: SQUARE_60) {      id      url      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeHashtags: Boolean!, $shouldIncludeLives: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(      query: $query      first: $limit      page: $page      sort: $sortByVideos      durationMin: $durationMinVideos      durationMax: $durationMaxVideos      createdAfter: $createdAfterVideos    ) @include(if: $shouldIncludeVideos) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          __typename        }        __typename      }      __typename    }    lives(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeLives) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...LIVE_BASE_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    hashtags(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeHashtags) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...HASHTAG_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	S46ZVrhN1gWY0Iiaj = S46ZVrhN1gWY0Iiaj.replace('mysearchwords',search)
	S46ZVrhN1gWY0Iiaj = S46ZVrhN1gWY0Iiaj.replace('mypagelimit','40')
	S46ZVrhN1gWY0Iiaj = S46ZVrhN1gWY0Iiaj.replace('mypagenumber',zmL397efNlks5uTEV)
	url = e2VR8nohduY+'/search/'+search+'/hashtags'
	m7yHNwvntVlcioLWEB9ZPISYgR = jBxWwr2CZJMIkL0uADOUP8Y6bgzhSp(S46ZVrhN1gWY0Iiaj,search)
	if m7yHNwvntVlcioLWEB9ZPISYgR:
		q3LFpN9WXHcr4n = aknZqSJyUrFgc9VhH2Psot6e7b8('dict',m7yHNwvntVlcioLWEB9ZPISYgR)
		try: NWEAKR6d5iJ8FO0wDeHPMlhpvgT21G = q3LFpN9WXHcr4n['data']['search']['hashtags']['edges']
		except: NWEAKR6d5iJ8FO0wDeHPMlhpvgT21G = []
		for o45IWvdchQ3UiJxmFZbEYfq in NWEAKR6d5iJ8FO0wDeHPMlhpvgT21G:
			name = o45IWvdchQ3UiJxmFZbEYfq['node']['name']
			name = ArwuTXMNsaO9fmjWdI(name)
			vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+'/hashtag/'+name[1:]
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'HSHTG: '+name,vn1grP3y4It9GmVuBbLJfz2A,417)
		if '"hasNextPage":true' in m7yHNwvntVlcioLWEB9ZPISYgR:
			zmL397efNlks5uTEV = str(int(zmL397efNlks5uTEV)+1)
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'صفحة '+zmL397efNlks5uTEV,url,416,HQmDERMFjx,zmL397efNlks5uTEV,search)
	return
def tarQvJ0zC16W(url,zmL397efNlks5uTEV=HQmDERMFjx):
	if zmL397efNlks5uTEV==HQmDERMFjx: zmL397efNlks5uTEV = '1'
	name = url.split(xufJqQcGnhboiVy2wd)[-1]
	S46ZVrhN1gWY0Iiaj = '''{"operationName":"HASHTAG_VIDEOS_QUERY","variables":{"hashtag_name":"#myhashtagname","page":mypagenumber},"query":"fragment FRAG_VIDEO_BASE on Video {  id  xid  title  description  thumbnail: thumbnailURL(size: \\"x240\\")  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  bestAvailableQuality  duration  createdAt  viewerEngagement {    id    liked    favorited    __typename  }  isExplicit  canDisplayAds  aspectRatio  stats {    id    views {      id      total      __typename    }    __typename  }  language {    id    codeAlpha2    __typename  }  videoHeight: height  videoWidth: width  __typename}fragment CHANNEL_BASE_FRAG on Channel {  id  xid  name  displayName  description  logoURL(size: \\"x25\\")  logoURLx60: logoURL(size: \\"x60\\")  coverURL(size: \\"x200\\")  coverURLx1024: coverURL(size: \\"1024x\\")  isFollowed  isArtist  accountType  __typename}fragment VIDEO_FRAG on Video {  id  ...FRAG_VIDEO_BASE  channel {    id    ...CHANNEL_BASE_FRAG    __typename  }  __typename}query HASHTAG_VIDEOS_QUERY($hashtag_name: String!, $page: Int!) {  contentFeed(    name: HASHTAG    filter: {name: {eq: $hashtag_name}, post: {eq: VIDEO}}    sort: {create: DESC}    page: $page    first: 30  ) {    totalCount    pageInfo {      hasNextPage      nextPage      __typename    }    edges {      node {        post {          ...VIDEO_FRAG          __typename        }        featured        __typename      }      __typename    }    __typename  }}"}'''
	S46ZVrhN1gWY0Iiaj = S46ZVrhN1gWY0Iiaj.replace('myhashtagname',name)
	S46ZVrhN1gWY0Iiaj = S46ZVrhN1gWY0Iiaj.replace('mypagenumber',zmL397efNlks5uTEV)
	m7yHNwvntVlcioLWEB9ZPISYgR = jBxWwr2CZJMIkL0uADOUP8Y6bgzhSp(S46ZVrhN1gWY0Iiaj)
	if m7yHNwvntVlcioLWEB9ZPISYgR:
		q3LFpN9WXHcr4n = aknZqSJyUrFgc9VhH2Psot6e7b8('dict',m7yHNwvntVlcioLWEB9ZPISYgR)
		NWEAKR6d5iJ8FO0wDeHPMlhpvgT21G = q3LFpN9WXHcr4n['data']['contentFeed']['edges']
		for o45IWvdchQ3UiJxmFZbEYfq in NWEAKR6d5iJ8FO0wDeHPMlhpvgT21G:
			OMDCpSL7ZB = str(o45IWvdchQ3UiJxmFZbEYfq['node']['post']['duration'])
			title = ArwuTXMNsaO9fmjWdI(o45IWvdchQ3UiJxmFZbEYfq['node']['post']['title'])
			title = title.replace('\/',xufJqQcGnhboiVy2wd)
			q05vV2mPaZYfBC3Js = o45IWvdchQ3UiJxmFZbEYfq['node']['post']['xid']
			uIGD4vZcP61QNmw78LXqoEpH = o45IWvdchQ3UiJxmFZbEYfq['node']['post']['thumbnailx480']
			uIGD4vZcP61QNmw78LXqoEpH = uIGD4vZcP61QNmw78LXqoEpH.replace('\/',xufJqQcGnhboiVy2wd)
			vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+'/video/'+q05vV2mPaZYfBC3Js
			CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,403,uIGD4vZcP61QNmw78LXqoEpH,OMDCpSL7ZB)
		if '"hasNextPage":true' in m7yHNwvntVlcioLWEB9ZPISYgR:
			zmL397efNlks5uTEV = str(int(zmL397efNlks5uTEV)+1)
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'صفحة '+zmL397efNlks5uTEV,url,416,HQmDERMFjx,zmL397efNlks5uTEV)
	return
def jBxWwr2CZJMIkL0uADOUP8Y6bgzhSp(S46ZVrhN1gWY0Iiaj,search=HQmDERMFjx):
	if HH6mxXjgcrEN1aenMFWQkS: S46ZVrhN1gWY0Iiaj = S46ZVrhN1gWY0Iiaj.encode(Zex6D4tJE52r)
	a2On46rs0e = zpv4DkMAqYPhXeaGjbUFyV0c1tH()
	headers = {"Authorization":a2On46rs0e,"Origin":e2VR8nohduY}
	if search:
		EFDgdaV4WT6U2yotAPX1B = IsK7MxWgSEa9JkHQntoh
		headers.update({'Content-Type':'application/json','Referer':e2VR8nohduY+xufJqQcGnhboiVy2wd,'X-DM-AppInfo-Id':'com.dailymotion.neon'})
	else:
		EFDgdaV4WT6U2yotAPX1B = waE5LXVN0BOiQjCUur3oTt6eYSIHJK
		headers.update({'Content-Type':'text/plain; charset=utf-8'})
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(LLwINhcX2RHSWqpmEnz,'POST',waE5LXVN0BOiQjCUur3oTt6eYSIHJK,S46ZVrhN1gWY0Iiaj,headers,HQmDERMFjx,HQmDERMFjx,'DAILYMOTION-GET_PAGEDATA-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	return CzNPJydxQLfw27tv4ZF8KORAbX5
def zpv4DkMAqYPhXeaGjbUFyV0c1tH():
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(LLwINhcX2RHSWqpmEnz,'GET',e2VR8nohduY,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'DAILYMOTION-GET_AUTHINTICATION-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	oPaRcp3i7JDQBXML9FgK0IWHf = DyVGS3dX0ZxR.findall('apiClientId.*?return"(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	oPaRcp3i7JDQBXML9FgK0IWHf = oPaRcp3i7JDQBXML9FgK0IWHf[o4bNzIQGYj8En]
	TBGnY3PsIWCJxj4ZVF5p1z0DHhvuNr = DyVGS3dX0ZxR.findall('apiClientSecret.*?return"(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	TBGnY3PsIWCJxj4ZVF5p1z0DHhvuNr = TBGnY3PsIWCJxj4ZVF5p1z0DHhvuNr[o4bNzIQGYj8En]
	c8s3mNi41Ton = 'https://graphql.api.dailymotion.com/oauth/token'
	AqIpU1M2BxEnhG = 'client_credentials'
	data = {'client_id':oPaRcp3i7JDQBXML9FgK0IWHf,'client_secret':TBGnY3PsIWCJxj4ZVF5p1z0DHhvuNr,'grant_type':AqIpU1M2BxEnhG}
	headers = {'Content-Type':'application/x-www-form-urlencoded'}
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(LLwINhcX2RHSWqpmEnz,'POST',c8s3mNi41Ton,data,headers,HQmDERMFjx,HQmDERMFjx,'DAILYMOTION-GET_AUTHINTICATION-2nd')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	Pp1wCyf30vqstdRlKYXIzuJbZB9FL = DyVGS3dX0ZxR.findall('"access_token": *"(.*?)".*?"token_type": *"(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	XgPwa5zhlB6pfKiHEGL7DZAq1S,BW79kN6CHOiaKnFIoR = Pp1wCyf30vqstdRlKYXIzuJbZB9FL[0]
	a2On46rs0e = BW79kN6CHOiaKnFIoR+" "+XgPwa5zhlB6pfKiHEGL7DZAq1S
	return a2On46rs0e
def hm4kawIPKp3oMrC75dJZA9HS2(search,GQB0WzyICDK7mXxN2Acdi=HQmDERMFjx):
	search,GXVabd4sc2u3zp0JI,showDialogs = x0pzMENwy84tBcZvXr(search)
	if not GQB0WzyICDK7mXxN2Acdi and showDialogs:
		Myl4EuqUPGj = ['بحث عن فيديوهات','بحث عن آخر الفيديوهات','بحث عن الفيديوهات الاكثر مشاهدة','(جيد للمسلسلات) بحث عن قوائم تشغيل','بحث عن مستخدم','بحث عن بث حي','بحث عن هاشتاك']
		lwT9cdaH5AxMU8IpZif20jPX = GGiSlWbqKDr5Ovkh2L7sHNTxz('موقع ديلي موشن - اختر البحث',Myl4EuqUPGj)
		if lwT9cdaH5AxMU8IpZif20jPX==-1: return
		elif lwT9cdaH5AxMU8IpZif20jPX==0: GQB0WzyICDK7mXxN2Acdi = 'videos?sortBy='
		elif lwT9cdaH5AxMU8IpZif20jPX==1: GQB0WzyICDK7mXxN2Acdi = 'videos?sortBy=RECENT'
		elif lwT9cdaH5AxMU8IpZif20jPX==2: GQB0WzyICDK7mXxN2Acdi = 'videos?sortBy=VIEW_COUNT'
		elif lwT9cdaH5AxMU8IpZif20jPX==3: GQB0WzyICDK7mXxN2Acdi = 'playlists'
		elif lwT9cdaH5AxMU8IpZif20jPX==4: GQB0WzyICDK7mXxN2Acdi = 'channels'
		elif lwT9cdaH5AxMU8IpZif20jPX==5: GQB0WzyICDK7mXxN2Acdi = 'lives'
		elif lwT9cdaH5AxMU8IpZif20jPX==6: GQB0WzyICDK7mXxN2Acdi = 'hashtags'
	elif '_DAILYMOTION-VIDEOS_' in GXVabd4sc2u3zp0JI: GQB0WzyICDK7mXxN2Acdi = 'videos?sortBy='
	elif '_DAILYMOTION-PLAYLISTS_' in GXVabd4sc2u3zp0JI: GQB0WzyICDK7mXxN2Acdi = 'playlists'
	elif '_DAILYMOTION-CHANNELS_' in GXVabd4sc2u3zp0JI: GQB0WzyICDK7mXxN2Acdi = 'channels'
	elif '_DAILYMOTION-LIVES_' in GXVabd4sc2u3zp0JI: GQB0WzyICDK7mXxN2Acdi = 'lives'
	elif '_DAILYMOTION-HASHTAGS_' in GXVabd4sc2u3zp0JI: GQB0WzyICDK7mXxN2Acdi = 'hashtags'
	elif not GQB0WzyICDK7mXxN2Acdi: GQB0WzyICDK7mXxN2Acdi = 'videos?sortBy='
	if not search:
		search = q156m84QoYrn()
		if not search: return
	if 'videos' in GQB0WzyICDK7mXxN2Acdi: RT9LcrUXNko7KgbzO08hGFsP(search+xufJqQcGnhboiVy2wd+GQB0WzyICDK7mXxN2Acdi)
	elif 'playlists' in GQB0WzyICDK7mXxN2Acdi: XfAL86ZJ3kO2lqwcIutY(search)
	elif 'channels' in GQB0WzyICDK7mXxN2Acdi: MDPiql2JxuHTdk(search)
	elif 'lives' in GQB0WzyICDK7mXxN2Acdi: TOwxWMp8FuDReyHrYcVlBKN536n(search)
	elif 'hashtags' in GQB0WzyICDK7mXxN2Acdi: qATVJiEK86L9U(search)
	return
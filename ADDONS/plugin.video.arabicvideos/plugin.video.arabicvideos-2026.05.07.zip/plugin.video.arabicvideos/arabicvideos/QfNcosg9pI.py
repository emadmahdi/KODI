# -*- coding: utf-8 -*-
import sys as TPW58slaVE9OrYQXZnGo2yAfFzpBxc
tbYWAoeMyHTsgFG5x6huz1 = TPW58slaVE9OrYQXZnGo2yAfFzpBxc.version_info [0] == 2
CUJSAbZztE8vYdGByLH0KcnWqe = 2048
R0QCXnpyL1DJwBH67FW = 7
def kSod2AxqugH0 (LURfCucn30xKsMdTiG):
	global ghCyPxkWILcXrGjVut6MQo59fsv
	MfIpC9TDz7Qa5g2vVqPtXh4 = ord (LURfCucn30xKsMdTiG [-1])
	nndScZEtapB74 = LURfCucn30xKsMdTiG [:-1]
	LRbqugZJAa3192OCewWGHvEcP = MfIpC9TDz7Qa5g2vVqPtXh4 % len (nndScZEtapB74)
	qLc7RGgDQE = nndScZEtapB74 [:LRbqugZJAa3192OCewWGHvEcP] + nndScZEtapB74 [LRbqugZJAa3192OCewWGHvEcP:]
	if tbYWAoeMyHTsgFG5x6huz1:
		XUczap3yA0QqFRC82OH6E5mL = unicode () .join ([unichr (ord (ah5u39EBY81MlrwA0cmoz4ngb7TLed) - CUJSAbZztE8vYdGByLH0KcnWqe - (YMjpxPr8WsJ1Bg6Xd + MfIpC9TDz7Qa5g2vVqPtXh4) % R0QCXnpyL1DJwBH67FW) for YMjpxPr8WsJ1Bg6Xd, ah5u39EBY81MlrwA0cmoz4ngb7TLed in enumerate (qLc7RGgDQE)])
	else:
		XUczap3yA0QqFRC82OH6E5mL = str () .join ([chr (ord (ah5u39EBY81MlrwA0cmoz4ngb7TLed) - CUJSAbZztE8vYdGByLH0KcnWqe - (YMjpxPr8WsJ1Bg6Xd + MfIpC9TDz7Qa5g2vVqPtXh4) % R0QCXnpyL1DJwBH67FW) for YMjpxPr8WsJ1Bg6Xd, ah5u39EBY81MlrwA0cmoz4ngb7TLed in enumerate (qLc7RGgDQE)])
	return eval (XUczap3yA0QqFRC82OH6E5mL)
jL1E5AKfwBDv6xmeQtUXcJ3d,JJA7fypmZFVlazvNI,dBi72erQEtKDOwjNFaoAgSP=kSod2AxqugH0,kSod2AxqugH0,kSod2AxqugH0
CDwSWB4v39N7,k4IUieraScH9DV1N7pJgQosYAx5l,Tcf5Ppn9UajDbzyM=dBi72erQEtKDOwjNFaoAgSP,JJA7fypmZFVlazvNI,jL1E5AKfwBDv6xmeQtUXcJ3d
X2crmy67eZpkGTRd,HDpmv4UXzlf72SK9,C3ZK1pu4rfmj8TsWUtBaM=Tcf5Ppn9UajDbzyM,k4IUieraScH9DV1N7pJgQosYAx5l,CDwSWB4v39N7
mg3CbXMA2ouZzQDhRqB,OBsrtQo2pPlgURCxJYbj9iXMD,ssnfOzb16wVog9GKdqcXR3JC7ktSPA=C3ZK1pu4rfmj8TsWUtBaM,HDpmv4UXzlf72SK9,X2crmy67eZpkGTRd
ShnRVsifKtc60zqQ,KKi79PFqsYB0dWSRgaJ3DyE,OzU6t0qcH7MQabeBYK8vgoG=ssnfOzb16wVog9GKdqcXR3JC7ktSPA,OBsrtQo2pPlgURCxJYbj9iXMD,mg3CbXMA2ouZzQDhRqB
mgLADoQ1pbtY,U0VwOviFaYPz2QGs45mJhMXf7Zk,pCTzbw4GyVJHjkcIMQ=OzU6t0qcH7MQabeBYK8vgoG,KKi79PFqsYB0dWSRgaJ3DyE,ShnRVsifKtc60zqQ
owbMhINBQsmx70guApW,SODvU3Ibq5VzC,PPAUFrY8cduRT=pCTzbw4GyVJHjkcIMQ,U0VwOviFaYPz2QGs45mJhMXf7Zk,mgLADoQ1pbtY
knTyjJ0sGIzuwbxRae,nz8x32hX0qcjUPFZk5RdJsiwED,A0aqj9uclgOtByJ6F4bz=PPAUFrY8cduRT,SODvU3Ibq5VzC,owbMhINBQsmx70guApW
YJxaX0MQOHb8oyCBFdnIAe,n6sfYuHBlVdzgmvpXwR3irON0KIj8,LHX65I9nkx0PstgcVY24uSi=A0aqj9uclgOtByJ6F4bz,nz8x32hX0qcjUPFZk5RdJsiwED,knTyjJ0sGIzuwbxRae
EAVanJj1ers2GQud,ELfMeDTIFhJt685K,EF2tvxZHz5n4UruPhaViXKycI6SQR=LHX65I9nkx0PstgcVY24uSi,n6sfYuHBlVdzgmvpXwR3irON0KIj8,YJxaX0MQOHb8oyCBFdnIAe
KhUG1NV9bln5zXjptqFW6dgo,cWbkR6iUZsnJQj14,maUl7SPesynF1j=EF2tvxZHz5n4UruPhaViXKycI6SQR,ELfMeDTIFhJt685K,EAVanJj1ers2GQud
from RYAntumr2i import *
class ceKymbh352zfoD0LsNFEV68Odj(DDw1qEnuAxL7):
	def __init__(g0hp2XJ5O7N9mtlwWDUiSFkbqV,*aargs,**kkwargs):
		g0hp2XJ5O7N9mtlwWDUiSFkbqV.choiceID = -CH7RKuDVzN9f06q8MtXPhlvIxakEWg
	def onClick(g0hp2XJ5O7N9mtlwWDUiSFkbqV,AArfMecNdJ7KoX):
		if AArfMecNdJ7KoX>=n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"࠹࠱࠳࠳౱"): g0hp2XJ5O7N9mtlwWDUiSFkbqV.choiceID = AArfMecNdJ7KoX-n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"࠹࠱࠳࠳౱")
		g0hp2XJ5O7N9mtlwWDUiSFkbqV.y2OVgDNYT6humdGKI1nPrqiv4Cecf()
	def rwAvtFWdsxc6aqQoUKT(g0hp2XJ5O7N9mtlwWDUiSFkbqV,*aargs):
		g0hp2XJ5O7N9mtlwWDUiSFkbqV.button0,g0hp2XJ5O7N9mtlwWDUiSFkbqV.button1,g0hp2XJ5O7N9mtlwWDUiSFkbqV.button2 = aargs[o4bNzIQGYj8En],aargs[CH7RKuDVzN9f06q8MtXPhlvIxakEWg],aargs[FFHRwuxQmbh8BaTqyX3]
		g0hp2XJ5O7N9mtlwWDUiSFkbqV.header,g0hp2XJ5O7N9mtlwWDUiSFkbqV.text = aargs[UUR70c8L9yTp3A2ajlmJqkQz],aargs[ihRKM0HpwdVstIF2ZjuTeCmXG]
		g0hp2XJ5O7N9mtlwWDUiSFkbqV.profile,g0hp2XJ5O7N9mtlwWDUiSFkbqV.direction = aargs[nz8x32hX0qcjUPFZk5RdJsiwED(u"࠶౲")],aargs[LHX65I9nkx0PstgcVY24uSi(u"࠸౳")]
		g0hp2XJ5O7N9mtlwWDUiSFkbqV.buttonstimeout,g0hp2XJ5O7N9mtlwWDUiSFkbqV.closetimeout = aargs[Tcf5Ppn9UajDbzyM(u"࠻౵")],aargs[pCTzbw4GyVJHjkcIMQ(u"࠻౴")]
		if g0hp2XJ5O7N9mtlwWDUiSFkbqV.buttonstimeout>o4bNzIQGYj8En or g0hp2XJ5O7N9mtlwWDUiSFkbqV.closetimeout>knTyjJ0sGIzuwbxRae(u"࠵౶"): g0hp2XJ5O7N9mtlwWDUiSFkbqV.enable_progressbar = gyd2rf0UR5
		else: g0hp2XJ5O7N9mtlwWDUiSFkbqV.enable_progressbar = mic3MEN709xOkrjD5ZvbGIlX6
		g0hp2XJ5O7N9mtlwWDUiSFkbqV.image_filename = A2G5oMubmJFl.replace(jL1E5AKfwBDv6xmeQtUXcJ3d(u"ࠨࡡ࠳࠴࠵࠶࡟ࠨ௟"),HDpmv4UXzlf72SK9(u"ࠩࡢࠫ௠")+str(jHWkt18govGwY7iUbduAfxCyRc.time())+n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"ࠪࡣࠬ௡"))
		g0hp2XJ5O7N9mtlwWDUiSFkbqV.image_filename = g0hp2XJ5O7N9mtlwWDUiSFkbqV.image_filename.replace(ELfMeDTIFhJt685K(u"ࠫࡡࡢࠧ௢"),nz8x32hX0qcjUPFZk5RdJsiwED(u"ࠬࡢ࡜࡝࡞ࠪ௣")).replace(mKqAOsD5p0C,LHX65I9nkx0PstgcVY24uSi(u"࠭࠯࠰࠱࠲ࠫ௤"))
		g0hp2XJ5O7N9mtlwWDUiSFkbqV.image_height = f3qiwuWEy0NP(g0hp2XJ5O7N9mtlwWDUiSFkbqV.button0,g0hp2XJ5O7N9mtlwWDUiSFkbqV.button1,g0hp2XJ5O7N9mtlwWDUiSFkbqV.button2,g0hp2XJ5O7N9mtlwWDUiSFkbqV.header,g0hp2XJ5O7N9mtlwWDUiSFkbqV.text,g0hp2XJ5O7N9mtlwWDUiSFkbqV.profile,g0hp2XJ5O7N9mtlwWDUiSFkbqV.direction,g0hp2XJ5O7N9mtlwWDUiSFkbqV.enable_progressbar,g0hp2XJ5O7N9mtlwWDUiSFkbqV.image_filename)
		g0hp2XJ5O7N9mtlwWDUiSFkbqV.show()
		g0hp2XJ5O7N9mtlwWDUiSFkbqV.getControl(pCTzbw4GyVJHjkcIMQ(u"࠿࠰࠶࠲౷")).setImage(g0hp2XJ5O7N9mtlwWDUiSFkbqV.image_filename)
		g0hp2XJ5O7N9mtlwWDUiSFkbqV.getControl(LHX65I9nkx0PstgcVY24uSi(u"࠹࠱࠷࠳౸")).setHeight(g0hp2XJ5O7N9mtlwWDUiSFkbqV.image_height)
		if not g0hp2XJ5O7N9mtlwWDUiSFkbqV.button1 and g0hp2XJ5O7N9mtlwWDUiSFkbqV.button0 and g0hp2XJ5O7N9mtlwWDUiSFkbqV.button2: g0hp2XJ5O7N9mtlwWDUiSFkbqV.getControl(PPAUFrY8cduRT(u"࠻࠳࠵࠷౺")).setPosition(-EF2tvxZHz5n4UruPhaViXKycI6SQR(u"࠵࠶࠵౻"),EAVanJj1ers2GQud(u"࠱౹"))
		return g0hp2XJ5O7N9mtlwWDUiSFkbqV.image_filename,g0hp2XJ5O7N9mtlwWDUiSFkbqV.image_height
	def Zng1dSRL3h4NbvQM6AJ(g0hp2XJ5O7N9mtlwWDUiSFkbqV):
		if g0hp2XJ5O7N9mtlwWDUiSFkbqV.buttonstimeout:
			g0hp2XJ5O7N9mtlwWDUiSFkbqV.th1 = Lk21XpCMZto(daemon=gyd2rf0UR5,target=g0hp2XJ5O7N9mtlwWDUiSFkbqV.eeRT4Hf1dyJEIP0svS2tiOxUu)
			g0hp2XJ5O7N9mtlwWDUiSFkbqV.th1.start()
		else: g0hp2XJ5O7N9mtlwWDUiSFkbqV.vtwLCysJXIkHlUpK38u7gRz01O()
	def eeRT4Hf1dyJEIP0svS2tiOxUu(g0hp2XJ5O7N9mtlwWDUiSFkbqV):
		g0hp2XJ5O7N9mtlwWDUiSFkbqV.getControl(dBi72erQEtKDOwjNFaoAgSP(u"࠽࠵࠸࠰౼")).setEnabled(gyd2rf0UR5)
		for DvGaoUZE5S4wxfHc910sz in range(CH7RKuDVzN9f06q8MtXPhlvIxakEWg,g0hp2XJ5O7N9mtlwWDUiSFkbqV.buttonstimeout+CH7RKuDVzN9f06q8MtXPhlvIxakEWg):
			jHWkt18govGwY7iUbduAfxCyRc.sleep(CH7RKuDVzN9f06q8MtXPhlvIxakEWg)
			CRiAHoPrxVf5ITnU70ubYmOeLapgd = int(nz8x32hX0qcjUPFZk5RdJsiwED(u"࠶࠶࠰౽")*DvGaoUZE5S4wxfHc910sz/g0hp2XJ5O7N9mtlwWDUiSFkbqV.buttonstimeout)
			g0hp2XJ5O7N9mtlwWDUiSFkbqV.jjdiuYUc6fzhaP1oG7NJQBS(CRiAHoPrxVf5ITnU70ubYmOeLapgd)
			if g0hp2XJ5O7N9mtlwWDUiSFkbqV.choiceID>jL1E5AKfwBDv6xmeQtUXcJ3d(u"࠶౾"): break
		g0hp2XJ5O7N9mtlwWDUiSFkbqV.vtwLCysJXIkHlUpK38u7gRz01O()
	def nBtdTcUN2lS(g0hp2XJ5O7N9mtlwWDUiSFkbqV):
		if g0hp2XJ5O7N9mtlwWDUiSFkbqV.closetimeout:
			g0hp2XJ5O7N9mtlwWDUiSFkbqV.th2 = Lk21XpCMZto(daemon=gyd2rf0UR5,target=g0hp2XJ5O7N9mtlwWDUiSFkbqV.rDfhFx6lQUnHObpB5ZTSCNz7MXYPWa)
			g0hp2XJ5O7N9mtlwWDUiSFkbqV.th2.start()
		else: g0hp2XJ5O7N9mtlwWDUiSFkbqV.vtwLCysJXIkHlUpK38u7gRz01O()
	def rDfhFx6lQUnHObpB5ZTSCNz7MXYPWa(g0hp2XJ5O7N9mtlwWDUiSFkbqV):
		g0hp2XJ5O7N9mtlwWDUiSFkbqV.getControl(A0aqj9uclgOtByJ6F4bz(u"࠹࠱࠴࠳౿")).setEnabled(gyd2rf0UR5)
		jHWkt18govGwY7iUbduAfxCyRc.sleep(g0hp2XJ5O7N9mtlwWDUiSFkbqV.buttonstimeout)
		for DvGaoUZE5S4wxfHc910sz in range(g0hp2XJ5O7N9mtlwWDUiSFkbqV.closetimeout-CH7RKuDVzN9f06q8MtXPhlvIxakEWg,-CH7RKuDVzN9f06q8MtXPhlvIxakEWg,-CH7RKuDVzN9f06q8MtXPhlvIxakEWg):
			jHWkt18govGwY7iUbduAfxCyRc.sleep(CH7RKuDVzN9f06q8MtXPhlvIxakEWg)
			CRiAHoPrxVf5ITnU70ubYmOeLapgd = int(OzU6t0qcH7MQabeBYK8vgoG(u"࠲࠲࠳ಀ")*DvGaoUZE5S4wxfHc910sz/g0hp2XJ5O7N9mtlwWDUiSFkbqV.closetimeout)
			g0hp2XJ5O7N9mtlwWDUiSFkbqV.jjdiuYUc6fzhaP1oG7NJQBS(CRiAHoPrxVf5ITnU70ubYmOeLapgd)
			if g0hp2XJ5O7N9mtlwWDUiSFkbqV.choiceID>o4bNzIQGYj8En: break
		if g0hp2XJ5O7N9mtlwWDUiSFkbqV.closetimeout>o4bNzIQGYj8En: g0hp2XJ5O7N9mtlwWDUiSFkbqV.choiceID = PPAUFrY8cduRT(u"࠳࠳ಁ")
		g0hp2XJ5O7N9mtlwWDUiSFkbqV.y2OVgDNYT6humdGKI1nPrqiv4Cecf()
	def jjdiuYUc6fzhaP1oG7NJQBS(g0hp2XJ5O7N9mtlwWDUiSFkbqV,CRiAHoPrxVf5ITnU70ubYmOeLapgd):
		g0hp2XJ5O7N9mtlwWDUiSFkbqV.precent = CRiAHoPrxVf5ITnU70ubYmOeLapgd
		g0hp2XJ5O7N9mtlwWDUiSFkbqV.getControl(ELfMeDTIFhJt685K(u"࠼࠴࠷࠶ಂ")).setPercent(g0hp2XJ5O7N9mtlwWDUiSFkbqV.precent)
	def vtwLCysJXIkHlUpK38u7gRz01O(g0hp2XJ5O7N9mtlwWDUiSFkbqV):
		if g0hp2XJ5O7N9mtlwWDUiSFkbqV.button0: g0hp2XJ5O7N9mtlwWDUiSFkbqV.getControl(HDpmv4UXzlf72SK9(u"࠽࠵࠷࠰ಃ")).setEnabled(gyd2rf0UR5)
		if g0hp2XJ5O7N9mtlwWDUiSFkbqV.button1: g0hp2XJ5O7N9mtlwWDUiSFkbqV.getControl(YJxaX0MQOHb8oyCBFdnIAe(u"࠾࠶࠱࠲಄")).setEnabled(gyd2rf0UR5)
		if g0hp2XJ5O7N9mtlwWDUiSFkbqV.button2: g0hp2XJ5O7N9mtlwWDUiSFkbqV.getControl(OzU6t0qcH7MQabeBYK8vgoG(u"࠿࠰࠲࠴ಅ")).setEnabled(gyd2rf0UR5)
	def y2OVgDNYT6humdGKI1nPrqiv4Cecf(g0hp2XJ5O7N9mtlwWDUiSFkbqV):
		g0hp2XJ5O7N9mtlwWDUiSFkbqV.close()
		try: S9Y5kUoRga3EVN.remove(g0hp2XJ5O7N9mtlwWDUiSFkbqV.image_filename)
		except: pass
def u0W7PAndK1IXU8rxz2jQaM(*aargs,**kkwargs):
	if aargs:
		direction = aargs[o4bNzIQGYj8En]
		vldiADoFORGqEVwP = aargs[CH7RKuDVzN9f06q8MtXPhlvIxakEWg]
		if not direction: direction = knTyjJ0sGIzuwbxRae(u"ࠧࡤࡧࡱࡸࡪࡸࠧ௥")
		if not vldiADoFORGqEVwP: vldiADoFORGqEVwP = ShnRVsifKtc60zqQ(u"ࠨษึฮ๊ืวาࠩ௦")
		YIq4xRkJiKh0EGD9eQBnTj1wv = aargs[FFHRwuxQmbh8BaTqyX3]
		kRpe8NqTm3zH5MGX6 = ti3SbXNV0aJ7n5Grc4OQY8Ll1s9.join(aargs[SODvU3Ibq5VzC(u"࠳ಆ"):])
	else: direction,vldiADoFORGqEVwP,YIq4xRkJiKh0EGD9eQBnTj1wv,kRpe8NqTm3zH5MGX6 = HQmDERMFjx,U0VwOviFaYPz2QGs45mJhMXf7Zk(u"ࠩࡒࡏࠬ௧"),HQmDERMFjx,HQmDERMFjx
	uumd4lZkWVE81cI7p0eXgtTQjxhHJ(direction,HQmDERMFjx,vldiADoFORGqEVwP,HQmDERMFjx,YIq4xRkJiKh0EGD9eQBnTj1wv,kRpe8NqTm3zH5MGX6,**kkwargs)
	return
def HUJZy0SrTbBYv1(*aargs,**kkwargs):
	direction = aargs[o4bNzIQGYj8En]
	Q3MoF19A2EzsaVGxHPh8 = aargs[CH7RKuDVzN9f06q8MtXPhlvIxakEWg]
	AMQcSvZDaNGXVeKifLd4thuBOJj = aargs[FFHRwuxQmbh8BaTqyX3]
	if AMQcSvZDaNGXVeKifLd4thuBOJj or Q3MoF19A2EzsaVGxHPh8: obqkRP2zrLCX84aABZYVyjng = gyd2rf0UR5
	else: obqkRP2zrLCX84aABZYVyjng = mic3MEN709xOkrjD5ZvbGIlX6
	YIq4xRkJiKh0EGD9eQBnTj1wv = aargs[UUR70c8L9yTp3A2ajlmJqkQz]
	kRpe8NqTm3zH5MGX6 = aargs[ihRKM0HpwdVstIF2ZjuTeCmXG]
	if not direction: direction = knTyjJ0sGIzuwbxRae(u"ࠪࡧࡪࡴࡴࡦࡴࠪ௨")
	if not Q3MoF19A2EzsaVGxHPh8: Q3MoF19A2EzsaVGxHPh8 = mg3CbXMA2ouZzQDhRqB(u"่๊ࠫวࠡࠢࡑࡳࠬ௩")
	if not AMQcSvZDaNGXVeKifLd4thuBOJj: AMQcSvZDaNGXVeKifLd4thuBOJj = X2crmy67eZpkGTRd(u"ࠬ์ูๆࠢࠣ࡝ࡪࡹࠧ௪")
	if len(aargs)>=ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"࠸ಈ"): kRpe8NqTm3zH5MGX6 += ti3SbXNV0aJ7n5Grc4OQY8Ll1s9+aargs[C3ZK1pu4rfmj8TsWUtBaM(u"࠶ಇ")]
	if len(aargs)>=nz8x32hX0qcjUPFZk5RdJsiwED(u"࠺ಉ"): kRpe8NqTm3zH5MGX6 += ti3SbXNV0aJ7n5Grc4OQY8Ll1s9+aargs[maUl7SPesynF1j(u"࠺ಊ")]
	DuWykph6JM = uumd4lZkWVE81cI7p0eXgtTQjxhHJ(direction,Q3MoF19A2EzsaVGxHPh8,HQmDERMFjx,AMQcSvZDaNGXVeKifLd4thuBOJj,YIq4xRkJiKh0EGD9eQBnTj1wv,kRpe8NqTm3zH5MGX6,**kkwargs)
	if DuWykph6JM==-A0aqj9uclgOtByJ6F4bz(u"࠶ಋ") and obqkRP2zrLCX84aABZYVyjng: DuWykph6JM = -CH7RKuDVzN9f06q8MtXPhlvIxakEWg
	elif DuWykph6JM==-CH7RKuDVzN9f06q8MtXPhlvIxakEWg and not obqkRP2zrLCX84aABZYVyjng: DuWykph6JM = mic3MEN709xOkrjD5ZvbGIlX6
	elif DuWykph6JM==o4bNzIQGYj8En: DuWykph6JM = mic3MEN709xOkrjD5ZvbGIlX6
	elif DuWykph6JM==FFHRwuxQmbh8BaTqyX3: DuWykph6JM = gyd2rf0UR5
	return DuWykph6JM
def GGiSlWbqKDr5Ovkh2L7sHNTxz(*aargs,**kkwargs):
	return P3qhMC0OYJ9UBWEG7ia4fkd.Dialog().select(*aargs,**kkwargs)
def x8a2FGB1jAef94byI(*args,**kwargs):
	YIq4xRkJiKh0EGD9eQBnTj1wv = args[o4bNzIQGYj8En]
	kRpe8NqTm3zH5MGX6 = args[CH7RKuDVzN9f06q8MtXPhlvIxakEWg]
	if len(args) > FFHRwuxQmbh8BaTqyX3 and SODvU3Ibq5VzC(u"࠭ࡴࡪ࡯ࡨࠫ௫") not in str(args[ELfMeDTIFhJt685K(u"࠸ಌ")]):
		FNZkurmfIWv5D7Gxpd0Hc6h21OCq = args[FFHRwuxQmbh8BaTqyX3]
		K7q2AkcuVLNmg = kwargs.get(dBi72erQEtKDOwjNFaoAgSP(u"ࠧࡵ࡫ࡰࡩࠬ௬"), pCTzbw4GyVJHjkcIMQ(u"࠱࠱࠲࠳಍"))
	else:
		FNZkurmfIWv5D7Gxpd0Hc6h21OCq = KKi79PFqsYB0dWSRgaJ3DyE(u"ࠨࡰࡲࡸ࡮࡬ࡩࡤࡣࡷ࡭ࡴࡴ࡟ࡳࡧࡪࡹࡱࡧࡲࠨ௭")
		K7q2AkcuVLNmg = args[FFHRwuxQmbh8BaTqyX3] if len(args) > FFHRwuxQmbh8BaTqyX3 else kwargs.get(JJA7fypmZFVlazvNI(u"ࠩࡷ࡭ࡲ࡫ࠧ௮"), ShnRVsifKtc60zqQ(u"࠲࠲࠳࠴ಎ"))
	dHMzjRrvgZ5AEBobU9F0 = Lk21XpCMZto(daemon=gyd2rf0UR5,target=mg6aoZnshQzHPyRcpKYW0qe3i7O2,args=(YIq4xRkJiKh0EGD9eQBnTj1wv,kRpe8NqTm3zH5MGX6,FNZkurmfIWv5D7Gxpd0Hc6h21OCq,K7q2AkcuVLNmg))
	dHMzjRrvgZ5AEBobU9F0.start()
	return
def mg6aoZnshQzHPyRcpKYW0qe3i7O2(YIq4xRkJiKh0EGD9eQBnTj1wv,kRpe8NqTm3zH5MGX6,FNZkurmfIWv5D7Gxpd0Hc6h21OCq,K7q2AkcuVLNmg):
	R1Rua5VptS = FNZkurmfIWv5D7Gxpd0Hc6h21OCq.replace(ShnRVsifKtc60zqQ(u"ࠪࡲࡴࡺࡩࡧ࡫ࡦࡥࡹ࡯࡯࡯ࡡࠪ௯"),HQmDERMFjx)
	import GU4tA1ermd
	name = GU4tA1ermd.rCt3zFWNQGA1hmbl(gyd2rf0UR5,R1Rua5VptS+mgLADoQ1pbtY(u"ࠫࠥ࠳ࠠࠨ௰")+YIq4xRkJiKh0EGD9eQBnTj1wv+k4IUieraScH9DV1N7pJgQosYAx5l(u"ࠬࠦ࠭ࠡࠩ௱")+kRpe8NqTm3zH5MGX6)
	name = GU4tA1ermd.nCu7m5V1eb9Dj8Pyf(name)
	image_filename = S9Y5kUoRga3EVN.path.join(xpkzGyjrY5OLiVb3Smltqn,name+KhUG1NV9bln5zXjptqFW6dgo(u"࠭࠮ࡱࡰࡪࠫ௲"))
	if S9Y5kUoRga3EVN.path.exists(image_filename):
		if FNZkurmfIWv5D7Gxpd0Hc6h21OCq==dBi72erQEtKDOwjNFaoAgSP(u"ࠧ࡯ࡱࡷ࡭࡫࡯ࡣࡢࡶ࡬ࡳࡳࡥࡲࡦࡩࡸࡰࡦࡸࠧ௳"): image_height = OzU6t0qcH7MQabeBYK8vgoG(u"࠳࠴࠻ಏ")
		elif FNZkurmfIWv5D7Gxpd0Hc6h21OCq==ELfMeDTIFhJt685K(u"ࠨࡰࡲࡸ࡮࡬ࡩࡤࡣࡷ࡭ࡴࡴ࡟ࡢࡷࡷࡳࠬ௴"): image_height = C3ZK1pu4rfmj8TsWUtBaM(u"࠵࠵࠵ಐ")
	else: image_height = f3qiwuWEy0NP(HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,YIq4xRkJiKh0EGD9eQBnTj1wv,kRpe8NqTm3zH5MGX6,FNZkurmfIWv5D7Gxpd0Hc6h21OCq,nz8x32hX0qcjUPFZk5RdJsiwED(u"ࠩ࡯ࡩ࡫ࡺࠧ௵"),mic3MEN709xOkrjD5ZvbGIlX6,image_filename)
	KNDOnCiUYBSw8 = DDw1qEnuAxL7(n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"ࠪࡈ࡮ࡧ࡬ࡰࡩࡑࡳࡹ࡯ࡦࡪࡥࡤࡸ࡮ࡵ࡮ࡊ࡯ࡤ࡫ࡪ࠴ࡸ࡮࡮ࠪ௶"),uulL5Yvt1ENFapdjHfhPs,EAVanJj1ers2GQud(u"ࠫࡉ࡫ࡦࡢࡷ࡯ࡸࠬ௷"),ELfMeDTIFhJt685K(u"ࠬ࠽࠲࠱ࡲࠪ௸"))
	KNDOnCiUYBSw8.show()
	if FNZkurmfIWv5D7Gxpd0Hc6h21OCq==OBsrtQo2pPlgURCxJYbj9iXMD(u"࠭࡮ࡰࡶ࡬ࡪ࡮ࡩࡡࡵ࡫ࡲࡲࡤࡧࡵࡵࡱࠪ௹"):
		KNDOnCiUYBSw8.getControl(PPAUFrY8cduRT(u"࠾࠶࠴࠱ಒ")).setHeight(OzU6t0qcH7MQabeBYK8vgoG(u"࠶࠶࠻಑"))
		KNDOnCiUYBSw8.getControl(U0VwOviFaYPz2QGs45mJhMXf7Zk(u"࠺࠲࠷࠴ಕ")).setPosition(pCTzbw4GyVJHjkcIMQ(u"࠻࠵ಓ"),-A0aqj9uclgOtByJ6F4bz(u"࠸࠱ಔ"))
		KNDOnCiUYBSw8.getControl(LHX65I9nkx0PstgcVY24uSi(u"࠻࠳࠹࠵ಖ")).setPosition(jL1E5AKfwBDv6xmeQtUXcJ3d(u"࠴࠶࠵ಗ"),-ELfMeDTIFhJt685K(u"࠺࠵ಘ"))
		KNDOnCiUYBSw8.getControl(OBsrtQo2pPlgURCxJYbj9iXMD(u"࠴࠱࠲ಛ")).setPosition(C3ZK1pu4rfmj8TsWUtBaM(u"࠾࠶ಙ"),-EF2tvxZHz5n4UruPhaViXKycI6SQR(u"࠹࠵ಚ"))
	KNDOnCiUYBSw8.getControl(PPAUFrY8cduRT(u"࠵࠲࠴ಜ")).setVisible(mic3MEN709xOkrjD5ZvbGIlX6)
	KNDOnCiUYBSw8.getControl(mg3CbXMA2ouZzQDhRqB(u"࠶࠳࠶ಝ")).setVisible(mic3MEN709xOkrjD5ZvbGIlX6)
	KNDOnCiUYBSw8.getControl(U0VwOviFaYPz2QGs45mJhMXf7Zk(u"࠼࠴࠺࠶ಞ")).setImage(image_filename)
	KNDOnCiUYBSw8.getControl(SODvU3Ibq5VzC(u"࠽࠵࠻࠰ಟ")).setHeight(image_height)
	jHWkt18govGwY7iUbduAfxCyRc.sleep(K7q2AkcuVLNmg/HDpmv4UXzlf72SK9(u"࠶࠶࠰࠱࠰࠳ಠ"))
	return
def ivtUDrV92ZjEWdHu(*aargs,**kkwargs):
	YIq4xRkJiKh0EGD9eQBnTj1wv,kRpe8NqTm3zH5MGX6,profile,direction = HQmDERMFjx,HQmDERMFjx,X2crmy67eZpkGTRd(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࡢࡰࡴࡴࡧࠨ௺"),X2crmy67eZpkGTRd(u"ࠨ࡮ࡨࡪࡹ࠭௻")
	if len(aargs)>=CH7RKuDVzN9f06q8MtXPhlvIxakEWg: YIq4xRkJiKh0EGD9eQBnTj1wv = aargs[o4bNzIQGYj8En]
	if len(aargs)>=FFHRwuxQmbh8BaTqyX3: kRpe8NqTm3zH5MGX6 = aargs[CH7RKuDVzN9f06q8MtXPhlvIxakEWg]
	if len(aargs)>=UUR70c8L9yTp3A2ajlmJqkQz: profile = aargs[FFHRwuxQmbh8BaTqyX3]
	if len(aargs)>=ihRKM0HpwdVstIF2ZjuTeCmXG: direction = aargs[UUR70c8L9yTp3A2ajlmJqkQz]
	return LQf1jSRk4tA32a(direction,YIq4xRkJiKh0EGD9eQBnTj1wv,kRpe8NqTm3zH5MGX6,profile)
def lxyYqQiXjM9EwvHFPA6k2zRVSJe(*aargs,**kkwargs):
	return P3qhMC0OYJ9UBWEG7ia4fkd.Dialog().contextmenu(*aargs,**kkwargs)
def Iwa81pXHmnceuGyF9dq(*aargs,**kkwargs):
	return P3qhMC0OYJ9UBWEG7ia4fkd.Dialog().browseSingle(*aargs,**kkwargs)
def gDkQj3u2W7yF9S1fz4PAEBVLICJxpM(*aargs,**kkwargs):
	return P3qhMC0OYJ9UBWEG7ia4fkd.Dialog().input(*aargs,**kkwargs)
def uu2bfv7V3FS(*aargs,**kkwargs):
	return P3qhMC0OYJ9UBWEG7ia4fkd.DialogProgress(*aargs,**kkwargs)
def uumd4lZkWVE81cI7p0eXgtTQjxhHJ(direction,button0=HQmDERMFjx,button1=HQmDERMFjx,button2=HQmDERMFjx,YIq4xRkJiKh0EGD9eQBnTj1wv=HQmDERMFjx,kRpe8NqTm3zH5MGX6=HQmDERMFjx,profile=EAVanJj1ers2GQud(u"ࠩࡦࡳࡳ࡬ࡩࡳ࡯ࡢࡦ࡮࡭ࡦࡰࡰࡷࠫ௼"),gR5ZYb2xLDzhPoIwa1CVUO8jyEQ=o4bNzIQGYj8En,JXwebOxl9s3MmzEKB2j=o4bNzIQGYj8En):
	if not direction: direction = Tcf5Ppn9UajDbzyM(u"ࠪࡧࡪࡴࡴࡦࡴࠪ௽")
	KNDOnCiUYBSw8 = ceKymbh352zfoD0LsNFEV68Odj(U0VwOviFaYPz2QGs45mJhMXf7Zk(u"ࠫࡉ࡯ࡡ࡭ࡱࡪࡇࡴࡴࡦࡪࡴࡰࡘ࡭ࡸࡥࡦࡄࡸࡸࡹࡵ࡮ࡴ࠰ࡻࡱࡱ࠭௾"),uulL5Yvt1ENFapdjHfhPs,cWbkR6iUZsnJQj14(u"ࠬࡊࡥࡧࡣࡸࡰࡹ࠭௿"),X2crmy67eZpkGTRd(u"࠭࠷࠳࠲ࡳࠫఀ"))
	KNDOnCiUYBSw8.rwAvtFWdsxc6aqQoUKT(button0,button1,button2,YIq4xRkJiKh0EGD9eQBnTj1wv,kRpe8NqTm3zH5MGX6,profile,direction,gR5ZYb2xLDzhPoIwa1CVUO8jyEQ,JXwebOxl9s3MmzEKB2j)
	if gR5ZYb2xLDzhPoIwa1CVUO8jyEQ>o4bNzIQGYj8En: KNDOnCiUYBSw8.Zng1dSRL3h4NbvQM6AJ()
	if JXwebOxl9s3MmzEKB2j>o4bNzIQGYj8En: KNDOnCiUYBSw8.nBtdTcUN2lS()
	if gR5ZYb2xLDzhPoIwa1CVUO8jyEQ==o4bNzIQGYj8En and JXwebOxl9s3MmzEKB2j==o4bNzIQGYj8En: KNDOnCiUYBSw8.vtwLCysJXIkHlUpK38u7gRz01O()
	KNDOnCiUYBSw8.doModal()
	DuWykph6JM = KNDOnCiUYBSw8.choiceID
	return DuWykph6JM
def LQf1jSRk4tA32a(direction,YIq4xRkJiKh0EGD9eQBnTj1wv,kRpe8NqTm3zH5MGX6,profile=JJA7fypmZFVlazvNI(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࡢࡰࡴࡴࡧࠨఁ")):
	if not direction: direction = KKi79PFqsYB0dWSRgaJ3DyE(u"ࠨ࡮ࡨࡪࡹ࠭ం")
	KNDOnCiUYBSw8 = DDw1qEnuAxL7(ELfMeDTIFhJt685K(u"ࠩࡇ࡭ࡦࡲ࡯ࡨࡖࡨࡼࡹ࡜ࡩࡦࡹࡨࡶࡋࡻ࡬࡭ࡕࡦࡶࡪ࡫࡮࠯ࡺࡰࡰࠬః"),uulL5Yvt1ENFapdjHfhPs,YJxaX0MQOHb8oyCBFdnIAe(u"ࠪࡈࡪ࡬ࡡࡶ࡮ࡷࠫఄ"),k4IUieraScH9DV1N7pJgQosYAx5l(u"ࠫ࠼࠸࠰ࡱࠩఅ"))
	image_filename = A2G5oMubmJFl.replace(mg3CbXMA2ouZzQDhRqB(u"ࠬࡥ࠰࠱࠲࠳ࡣࠬఆ"),maUl7SPesynF1j(u"࠭࡟ࠨఇ")+str(jHWkt18govGwY7iUbduAfxCyRc.time())+nz8x32hX0qcjUPFZk5RdJsiwED(u"ࠧࡠࠩఈ"))
	image_filename = image_filename.replace(X2crmy67eZpkGTRd(u"ࠨ࡞࡟ࠫఉ"),ELfMeDTIFhJt685K(u"ࠩ࡟ࡠࡡࡢࠧఊ")).replace(mKqAOsD5p0C,mg3CbXMA2ouZzQDhRqB(u"ࠪ࠳࠴࠵࠯ࠨఋ"))
	image_height = f3qiwuWEy0NP(HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,YIq4xRkJiKh0EGD9eQBnTj1wv,kRpe8NqTm3zH5MGX6,profile,direction,mic3MEN709xOkrjD5ZvbGIlX6,image_filename)
	KNDOnCiUYBSw8.show()
	KNDOnCiUYBSw8.getControl(n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"࠿࠰࠶࠲ಡ")).setHeight(image_height)
	KNDOnCiUYBSw8.getControl(knTyjJ0sGIzuwbxRae(u"࠹࠱࠷࠳ಢ")).setImage(image_filename)
	HsP2goBfqCmUJVyti05ZK4WDGOA = KNDOnCiUYBSw8.doModal()
	try: S9Y5kUoRga3EVN.remove(image_filename)
	except: pass
	return HsP2goBfqCmUJVyti05ZK4WDGOA
def f3qiwuWEy0NP(zw6XksRgpJ,FF8oJbhTZqkaVgurDxNSMp3enQytCc,RR8xEPqfLF7CcSDV,m7OyBjWCUFZ4i9ea3EN,NN9niuC7RoqmhkL2,wK7oqpdkfNQxhsJGRySZAcXE9LBWUC,BOG1qPQJv7CnkMiKp9,egmc3uiyjaQL4DF9,Al2Vt3kdnz0YQqfUiaTXFLM):
	fzpCHJw4Oqv082Q7GRP = S9Y5kUoRga3EVN.path.dirname(Al2Vt3kdnz0YQqfUiaTXFLM)
	if not S9Y5kUoRga3EVN.path.exists(fzpCHJw4Oqv082Q7GRP):
		try: S9Y5kUoRga3EVN.makedirs(fzpCHJw4Oqv082Q7GRP)
		except: pass
	DWj3ditMUBSgy2sabFkrpHx1mELYh = VI6wlYJugWSXE(wK7oqpdkfNQxhsJGRySZAcXE9LBWUC)
	zzmaKdis730vkVhB = hhegpYfvGIwi0HNQ8LzXlDWx(DWj3ditMUBSgy2sabFkrpHx1mELYh,zw6XksRgpJ,FF8oJbhTZqkaVgurDxNSMp3enQytCc,RR8xEPqfLF7CcSDV,m7OyBjWCUFZ4i9ea3EN,NN9niuC7RoqmhkL2,wK7oqpdkfNQxhsJGRySZAcXE9LBWUC,BOG1qPQJv7CnkMiKp9,egmc3uiyjaQL4DF9,Al2Vt3kdnz0YQqfUiaTXFLM)
	return zzmaKdis730vkVhB
def VI6wlYJugWSXE(wK7oqpdkfNQxhsJGRySZAcXE9LBWUC):
	G51mfwsYqNgoCzupyX = MVXFsAiZbSvHTtq8he5GwLaOxzW
	Lo7s5uylka = jL1E5AKfwBDv6xmeQtUXcJ3d(u"࠳࠲ಣ")
	vnzJ9I6uA1 = PPAUFrY8cduRT(u"࠴࠳ತ")
	hhA0XZDpdvMS7ru2a8f5YeTjw = o4bNzIQGYj8En
	kkr9VbfxgwCe0ipXOJUW = PPAUFrY8cduRT(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫఌ")
	vyEgbMpCZPFGQcw = o4bNzIQGYj8En
	lEVyfFJ9HgaWKmn2u4rSUCPs = JJA7fypmZFVlazvNI(u"࠴࠽ಥ")
	YY8Ll2OqajSR06p = CDwSWB4v39N7(u"࠷࠵ದ")
	dv3FpaGWXr = HDpmv4UXzlf72SK9(u"࠽ಧ")
	WWkhf4oGy7inSjsuVIA2QdqamUP = gyd2rf0UR5
	eE1p049IQou = pCTzbw4GyVJHjkcIMQ(u"࠹࠷࠶ನ")
	f2NJYsGFtB4R5pqH = mgLADoQ1pbtY(u"࠴࠲࠲಩")
	fXqLTaQUeS1t5kVNGp4B3JRbWMO = cWbkR6iUZsnJQj14(u"࠶࠲ಪ")
	VYhr6wlpXDRgBbji9dnQM71kyAE58 = knTyjJ0sGIzuwbxRae(u"࠴࠻࠴ಫ")
	qQdwHvnTUKb = ELfMeDTIFhJt685K(u"࠵࠼ಬ")
	UUqbt4KPT0dSuCyv7pw5mnFG6Jrecj = MVXFsAiZbSvHTtq8he5GwLaOxzW
	pLUJc9VPorl2 = o4bNzIQGYj8En
	Tfgb7R9FUcoC = ELfMeDTIFhJt685K(u"࠷࠶ಭ")
	byEUIA6VmRGBfd = [Tcf5Ppn9UajDbzyM(u"࠳࠷ರ"),ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"࠸࠸ಮ"),ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"࠸࠸ಯ")]
	from PIL import ImageDraw as IlTdWtz8SvBpfP6ykHN2Kc,ImageFont as qRV9yhfdHczm1jXSweTuinlOG0Jo,Image as gjhR3KTi2cynqBD8w
	if X2crmy67eZpkGTRd(u"ࠬࡴ࡯ࡵ࡫ࡩ࡭ࡨࡧࡴࡪࡱࡱࠫ఍") in wK7oqpdkfNQxhsJGRySZAcXE9LBWUC:
		if wK7oqpdkfNQxhsJGRySZAcXE9LBWUC==X2crmy67eZpkGTRd(u"࠭࡮ࡰࡶ࡬ࡪ࡮ࡩࡡࡵ࡫ࡲࡲࡤࡸࡥࡨࡷ࡯ࡥࡷ࠭ఎ"):
			JJKflmdXCo2UawGrVcHNi6vp = owbMhINBQsmx70guApW(u"࠲࠳࠺ಱ")
			kkr9VbfxgwCe0ipXOJUW = dBi72erQEtKDOwjNFaoAgSP(u"ࠧ࡭ࡧࡩࡸࠬఏ")
			WWkhf4oGy7inSjsuVIA2QdqamUP = mic3MEN709xOkrjD5ZvbGIlX6
		elif wK7oqpdkfNQxhsJGRySZAcXE9LBWUC==JJA7fypmZFVlazvNI(u"ࠨࡰࡲࡸ࡮࡬ࡩࡤࡣࡷ࡭ࡴࡴ࡟ࡢࡷࡷࡳࠬఐ"):
			JJKflmdXCo2UawGrVcHNi6vp = mg3CbXMA2ouZzQDhRqB(u"ࠩࡘࡔࡕࡋࡒࠨ఑")
			kkr9VbfxgwCe0ipXOJUW = k4IUieraScH9DV1N7pJgQosYAx5l(u"ࠪࡶ࡮࡭ࡨࡵࠩఒ")
			hhA0XZDpdvMS7ru2a8f5YeTjw = owbMhINBQsmx70guApW(u"࠳࠳ಲ")
		EoiHNlTu3b4LBfqsn5gpjyW62 = knTyjJ0sGIzuwbxRae(u"࠺࠶࠵ಳ")
		byEUIA6VmRGBfd = [ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"࠷࠸಴"),ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"࠷࠸಴"),ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"࠷࠸಴")]
		vnzJ9I6uA1 = mgLADoQ1pbtY(u"࠷࠶ವ")
		Lo7s5uylka = o4bNzIQGYj8En
		YY8Ll2OqajSR06p = JJA7fypmZFVlazvNI(u"࠸࠰ಶ")
		lEVyfFJ9HgaWKmn2u4rSUCPs = knTyjJ0sGIzuwbxRae(u"࠳࠶ಷ")
	elif wK7oqpdkfNQxhsJGRySZAcXE9LBWUC==PPAUFrY8cduRT(u"ࠫࡲ࡫࡮ࡶࡡ࡬ࡸࡪࡳࠧఓ"):
		byEUIA6VmRGBfd,EoiHNlTu3b4LBfqsn5gpjyW62,JJKflmdXCo2UawGrVcHNi6vp = [OBsrtQo2pPlgURCxJYbj9iXMD(u"࠵࠼಺"),OBsrtQo2pPlgURCxJYbj9iXMD(u"࠵࠼಺"),OBsrtQo2pPlgURCxJYbj9iXMD(u"࠵࠼಺")],U0VwOviFaYPz2QGs45mJhMXf7Zk(u"࠳࠲࠳ಸ"),mgLADoQ1pbtY(u"࠴࠸࠴ಹ")
		vyEgbMpCZPFGQcw,YY8Ll2OqajSR06p,lEVyfFJ9HgaWKmn2u4rSUCPs, = o4bNzIQGYj8En,-C3ZK1pu4rfmj8TsWUtBaM(u"࠵࠷಻"),-n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"࠸࠶಼")
		Lo7s5uylka = o4bNzIQGYj8En
		bIxiluCTELadZg6vNXwYPRoD1jyH = gjhR3KTi2cynqBD8w.open(vCEUortsVAYI5NDuj2y)
		hn1OkzSpaDZIUEiw0CrM69qJt = gjhR3KTi2cynqBD8w.new(Tcf5Ppn9UajDbzyM(u"ࠬࡘࡇࡃࡃࠪఔ"),(EoiHNlTu3b4LBfqsn5gpjyW62,JJKflmdXCo2UawGrVcHNi6vp),(mgLADoQ1pbtY(u"࠸࠵࠶ಽ"),o4bNzIQGYj8En,o4bNzIQGYj8En,mgLADoQ1pbtY(u"࠸࠵࠶ಽ")))
	elif wK7oqpdkfNQxhsJGRySZAcXE9LBWUC==jL1E5AKfwBDv6xmeQtUXcJ3d(u"࠭ࡣࡰࡰࡩ࡭ࡷࡳ࡟ࡴ࡯ࡤࡰࡱ࡬࡯࡯ࡶࠪక"): byEUIA6VmRGBfd,JJKflmdXCo2UawGrVcHNi6vp,EoiHNlTu3b4LBfqsn5gpjyW62 = [Tcf5Ppn9UajDbzyM(u"࠵࠼ು"),ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"࠲࠵ಾ"),HDpmv4UXzlf72SK9(u"࠳࠲ಿ")],YJxaX0MQOHb8oyCBFdnIAe(u"࠹࠵࠶ೂ"),OBsrtQo2pPlgURCxJYbj9iXMD(u"࠻࠳࠴ೀ")
	elif wK7oqpdkfNQxhsJGRySZAcXE9LBWUC==LHX65I9nkx0PstgcVY24uSi(u"ࠧࡤࡱࡱࡪ࡮ࡸ࡭ࡠ࡯ࡨࡨ࡮ࡻ࡭ࡧࡱࡱࡸࠬఖ"): byEUIA6VmRGBfd,JJKflmdXCo2UawGrVcHNi6vp,EoiHNlTu3b4LBfqsn5gpjyW62 = [X2crmy67eZpkGTRd(u"࠹࠲ೄ"),EF2tvxZHz5n4UruPhaViXKycI6SQR(u"࠳࠺ೆ"),X2crmy67eZpkGTRd(u"࠷࠺ೃ")],ShnRVsifKtc60zqQ(u"࠷࠳࠴ೇ"),Tcf5Ppn9UajDbzyM(u"࠹࠱࠲೅")
	elif wK7oqpdkfNQxhsJGRySZAcXE9LBWUC==owbMhINBQsmx70guApW(u"ࠨࡥࡲࡲ࡫࡯ࡲ࡮ࡡࡥ࡭࡬࡬࡯࡯ࡶࠪగ"): byEUIA6VmRGBfd,JJKflmdXCo2UawGrVcHNi6vp,EoiHNlTu3b4LBfqsn5gpjyW62 = [LHX65I9nkx0PstgcVY24uSi(u"࠹࠶ೋ"),pCTzbw4GyVJHjkcIMQ(u"࠶࠶ೈ"),OzU6t0qcH7MQabeBYK8vgoG(u"࠷࠾ೊ")],HDpmv4UXzlf72SK9(u"࠵࠱࠲ೌ"),nz8x32hX0qcjUPFZk5RdJsiwED(u"࠽࠵࠶೉")
	elif wK7oqpdkfNQxhsJGRySZAcXE9LBWUC==EAVanJj1ers2GQud(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬఘ"): JJKflmdXCo2UawGrVcHNi6vp,EoiHNlTu3b4LBfqsn5gpjyW62 = C3ZK1pu4rfmj8TsWUtBaM(u"࠸࠶࠳್"),JJA7fypmZFVlazvNI(u"࠳࠵࠻࠵೎")
	elif wK7oqpdkfNQxhsJGRySZAcXE9LBWUC==mg3CbXMA2ouZzQDhRqB(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹࡥ࡬ࡰࡰࡪࠫఙ"): JJKflmdXCo2UawGrVcHNi6vp,EoiHNlTu3b4LBfqsn5gpjyW62 = knTyjJ0sGIzuwbxRae(u"࡚ࠫࡖࡐࡆࡔࠪచ"),ShnRVsifKtc60zqQ(u"࠴࠶࠼࠶೏")
	elif wK7oqpdkfNQxhsJGRySZAcXE9LBWUC==cWbkR6iUZsnJQj14(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡴ࡯ࡤࡰࡱ࡬࡯࡯ࡶࠪఛ"): byEUIA6VmRGBfd,JJKflmdXCo2UawGrVcHNi6vp,EoiHNlTu3b4LBfqsn5gpjyW62 = [Tcf5Ppn9UajDbzyM(u"࠲࠹೓"),X2crmy67eZpkGTRd(u"࠳࠵೔"),pCTzbw4GyVJHjkcIMQ(u"࠶࠾೑")],maUl7SPesynF1j(u"࠻࠹࠶೐"),KhUG1NV9bln5zXjptqFW6dgo(u"࠷࠲࠸࠲೒")
	elif wK7oqpdkfNQxhsJGRySZAcXE9LBWUC==C3ZK1pu4rfmj8TsWUtBaM(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡵࡰࡥࡱࡲࡦࡰࡰࡷࡣࡱࡵ࡮ࡨࠩజ"): byEUIA6VmRGBfd,JJKflmdXCo2UawGrVcHNi6vp,EoiHNlTu3b4LBfqsn5gpjyW62 = [owbMhINBQsmx70guApW(u"࠶࠽೗"),Tcf5Ppn9UajDbzyM(u"࠷࠹೘"),HDpmv4UXzlf72SK9(u"࠴࠼ೖ")],OzU6t0qcH7MQabeBYK8vgoG(u"ࠧࡖࡒࡓࡉࡗ࠭ఝ"),C3ZK1pu4rfmj8TsWUtBaM(u"࠳࠵࠻࠵ೕ")
	tcanOrJjq5H4,YY4Eypab375QqVATd,PBITziVr9kM2LRXsw8EAFjl1QWpJU = byEUIA6VmRGBfd
	TKpjCGfZquIJ8bo = qRV9yhfdHczm1jXSweTuinlOG0Jo.truetype(E7EPhxf9aOnKDVky68mIgXtYWGo3,size=tcanOrJjq5H4)
	rHYPpafzvCsQTkBejhbgE5mi8 = qRV9yhfdHczm1jXSweTuinlOG0Jo.truetype(E7EPhxf9aOnKDVky68mIgXtYWGo3,size=YY4Eypab375QqVATd)
	uRQJkAhN2CGxifcHtL = qRV9yhfdHczm1jXSweTuinlOG0Jo.truetype(E7EPhxf9aOnKDVky68mIgXtYWGo3,size=PBITziVr9kM2LRXsw8EAFjl1QWpJU)
	NN4Rq3ChWxPKVJ0f2 = EoiHNlTu3b4LBfqsn5gpjyW62-YY8Ll2OqajSR06p*FFHRwuxQmbh8BaTqyX3
	QVyiKDnpTjxL486fYos1JSve2gm = gjhR3KTi2cynqBD8w.new(JJA7fypmZFVlazvNI(u"ࠨࡔࡊࡆࡆ࠭ఞ"),(NN4Rq3ChWxPKVJ0f2,ShnRVsifKtc60zqQ(u"࠷࠰࠱೙")),(C3ZK1pu4rfmj8TsWUtBaM(u"࠲࠶࠷೚"),C3ZK1pu4rfmj8TsWUtBaM(u"࠲࠶࠷೚"),C3ZK1pu4rfmj8TsWUtBaM(u"࠲࠶࠷೚"),o4bNzIQGYj8En))
	gdxh31fPcmC6e2SIbkQ8 = IlTdWtz8SvBpfP6ykHN2Kc.Draw(QVyiKDnpTjxL486fYos1JSve2gm)
	kkNeKZnPQUiXDYodcas,YTc3hiJ8zOB = gdxh31fPcmC6e2SIbkQ8.textsize(mg3CbXMA2ouZzQDhRqB(u"ࠩࡋࡌࡍࠦࡂࡃࡄࠣ࠼࠽࠾ࠠ࠱࠲࠳ࠫట"),font=TKpjCGfZquIJ8bo)
	GpwmxNkcz3ButHsJb1OXvUR,DdaZeBcHzPhbwsi6SAk0CL8G = gdxh31fPcmC6e2SIbkQ8.textsize(n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"ࠪࡌࡍࡎࠠࡃࡄࡅࠤ࠽࠾࠸ࠡ࠲࠳࠴ࠬఠ"),font=rHYPpafzvCsQTkBejhbgE5mi8)
	bbwBWvzMaH = {OBsrtQo2pPlgURCxJYbj9iXMD(u"ࠫࡩ࡫࡬ࡦࡶࡨࡣ࡭ࡧࡲࡢ࡭ࡤࡸࠬడ"):mic3MEN709xOkrjD5ZvbGIlX6,knTyjJ0sGIzuwbxRae(u"ࠬࡹࡵࡱࡲࡲࡶࡹࡥ࡬ࡪࡩࡤࡸࡺࡸࡥࡴࠩఢ"):gyd2rf0UR5,A0aqj9uclgOtByJ6F4bz(u"࠭ࡁࡓࡃࡅࡍࡈࠦࡌࡊࡉࡄࡘ࡚ࡘࡅࠡࡃࡏࡐࡆࡎࠧణ"):mic3MEN709xOkrjD5ZvbGIlX6}
	from arabic_reshaper import ArabicReshaper as b6oEIvAHDZKYwTR
	LNDdcXGHPuxhr5E3SyTAQ = b6oEIvAHDZKYwTR(configuration=bbwBWvzMaH)
	DWj3ditMUBSgy2sabFkrpHx1mELYh = {}
	xpq6Uijh3VC = locals()
	for Rinkx4B0rUOXlpFqQuKPC2oA in xpq6Uijh3VC: DWj3ditMUBSgy2sabFkrpHx1mELYh[Rinkx4B0rUOXlpFqQuKPC2oA] = xpq6Uijh3VC[Rinkx4B0rUOXlpFqQuKPC2oA]
	return DWj3ditMUBSgy2sabFkrpHx1mELYh
def hhegpYfvGIwi0HNQ8LzXlDWx(DWj3ditMUBSgy2sabFkrpHx1mELYh,zw6XksRgpJ,FF8oJbhTZqkaVgurDxNSMp3enQytCc,RR8xEPqfLF7CcSDV,m7OyBjWCUFZ4i9ea3EN,NN9niuC7RoqmhkL2,wK7oqpdkfNQxhsJGRySZAcXE9LBWUC,BOG1qPQJv7CnkMiKp9,egmc3uiyjaQL4DF9,Al2Vt3kdnz0YQqfUiaTXFLM):
	for Rinkx4B0rUOXlpFqQuKPC2oA in DWj3ditMUBSgy2sabFkrpHx1mELYh: globals()[Rinkx4B0rUOXlpFqQuKPC2oA] = DWj3ditMUBSgy2sabFkrpHx1mELYh[Rinkx4B0rUOXlpFqQuKPC2oA]
	global qQdwHvnTUKb,UUqbt4KPT0dSuCyv7pw5mnFG6Jrecj
	if wK7oqpdkfNQxhsJGRySZAcXE9LBWUC!=ShnRVsifKtc60zqQ(u"ࠧ࡮ࡧࡱࡹࡤ࡯ࡴࡦ࡯ࠪత"):
		nmkL1z5EjGaHPp = H8jfvMtXa7Neiu.getSetting(n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"ࠨࡣࡹ࠲ࡱࡧ࡮ࡨࡷࡤ࡫ࡪ࠴ࡴࡳࡣࡱࡷࡱࡧࡴࡦࠩథ"))
		if nmkL1z5EjGaHPp:
			if zw6XksRgpJ==HDpmv4UXzlf72SK9(u"้ࠩ฽๊࡚ࠦࠠࡧࡶࠫద"): zw6XksRgpJ = KKi79PFqsYB0dWSRgaJ3DyE(u"ࠪ࡝ࡪࡹࠧధ")
			elif zw6XksRgpJ==Tcf5Ppn9UajDbzyM(u"่๊ࠫวࠡࠢࡑࡳࠬన"): zw6XksRgpJ = X2crmy67eZpkGTRd(u"ࠬࡔ࡯ࠨ఩")
			if FF8oJbhTZqkaVgurDxNSMp3enQytCc==YJxaX0MQOHb8oyCBFdnIAe(u"࠭ๆฺ็ࠣࠤ࡞࡫ࡳࠨప"): FF8oJbhTZqkaVgurDxNSMp3enQytCc = YJxaX0MQOHb8oyCBFdnIAe(u"࡚ࠧࡧࡶࠫఫ")
			elif FF8oJbhTZqkaVgurDxNSMp3enQytCc==mg3CbXMA2ouZzQDhRqB(u"ࠨๅ็หࠥࠦࡎࡰࠩబ"): FF8oJbhTZqkaVgurDxNSMp3enQytCc = PPAUFrY8cduRT(u"ࠩࡑࡳࠬభ")
			if RR8xEPqfLF7CcSDV==maUl7SPesynF1j(u"๊ࠪ฾๋࡛ࠠࠡࡨࡷࠬమ"): RR8xEPqfLF7CcSDV = owbMhINBQsmx70guApW(u"ࠫ࡞࡫ࡳࠨయ")
			elif RR8xEPqfLF7CcSDV==HDpmv4UXzlf72SK9(u"้ࠬไศࠢࠣࡒࡴ࠭ర"): RR8xEPqfLF7CcSDV = JJA7fypmZFVlazvNI(u"࠭ࡎࡰࠩఱ")
			import GU4tA1ermd
			USFh9yauLTlCXb2nZIw5tqQmO4dH = GU4tA1ermd.lbvnhNqyMV([zw6XksRgpJ,FF8oJbhTZqkaVgurDxNSMp3enQytCc,RR8xEPqfLF7CcSDV,m7OyBjWCUFZ4i9ea3EN,NN9niuC7RoqmhkL2])
			if USFh9yauLTlCXb2nZIw5tqQmO4dH: zw6XksRgpJ,FF8oJbhTZqkaVgurDxNSMp3enQytCc,RR8xEPqfLF7CcSDV,m7OyBjWCUFZ4i9ea3EN,NN9niuC7RoqmhkL2 = USFh9yauLTlCXb2nZIw5tqQmO4dH
	if C6H1qXua3SMQiIrzxNvJWZE:
		NN9niuC7RoqmhkL2 = NN9niuC7RoqmhkL2.decode(Zex6D4tJE52r)
		m7OyBjWCUFZ4i9ea3EN = m7OyBjWCUFZ4i9ea3EN.decode(Zex6D4tJE52r)
		zw6XksRgpJ = zw6XksRgpJ.decode(Zex6D4tJE52r)
		FF8oJbhTZqkaVgurDxNSMp3enQytCc = FF8oJbhTZqkaVgurDxNSMp3enQytCc.decode(Zex6D4tJE52r)
		RR8xEPqfLF7CcSDV = RR8xEPqfLF7CcSDV.decode(Zex6D4tJE52r)
	FJyDAQuLjvE = m7OyBjWCUFZ4i9ea3EN.count(ti3SbXNV0aJ7n5Grc4OQY8Ll1s9)+CH7RKuDVzN9f06q8MtXPhlvIxakEWg
	IHaZnfkPpV7B5gOjK2lcN3D1 = Lo7s5uylka+FJyDAQuLjvE*(YTc3hiJ8zOB+hhA0XZDpdvMS7ru2a8f5YeTjw)-hhA0XZDpdvMS7ru2a8f5YeTjw
	if NN9niuC7RoqmhkL2:
		PEKTdSmY2zX = DdaZeBcHzPhbwsi6SAk0CL8G+dv3FpaGWXr
		mmLuqpwJlGPRsenTYrjHca = LNDdcXGHPuxhr5E3SyTAQ.reshape(NN9niuC7RoqmhkL2)
		if WWkhf4oGy7inSjsuVIA2QdqamUP:
			S6Swsfbtlj4ApkPiQRoeYCLy = J9Jymx4MLXg7kSAnif1jDr(gdxh31fPcmC6e2SIbkQ8,rHYPpafzvCsQTkBejhbgE5mi8,mmLuqpwJlGPRsenTYrjHca,YY4Eypab375QqVATd,NN4Rq3ChWxPKVJ0f2,PEKTdSmY2zX)
			QM1LZKDjbrfe8xpkFo = VV1bFxH5XQhBUldZ2ijc(S6Swsfbtlj4ApkPiQRoeYCLy)
			HiSvDrU5IP = QM1LZKDjbrfe8xpkFo.count(ti3SbXNV0aJ7n5Grc4OQY8Ll1s9)+CH7RKuDVzN9f06q8MtXPhlvIxakEWg
			XNeUStZTxfuD27VAvhmsbGI = lEVyfFJ9HgaWKmn2u4rSUCPs+HiSvDrU5IP*PEKTdSmY2zX-dv3FpaGWXr
		else:
			XNeUStZTxfuD27VAvhmsbGI = lEVyfFJ9HgaWKmn2u4rSUCPs+DdaZeBcHzPhbwsi6SAk0CL8G
			QM1LZKDjbrfe8xpkFo = mmLuqpwJlGPRsenTYrjHca.split(ti3SbXNV0aJ7n5Grc4OQY8Ll1s9)[o4bNzIQGYj8En]
			S6Swsfbtlj4ApkPiQRoeYCLy = mmLuqpwJlGPRsenTYrjHca.split(ti3SbXNV0aJ7n5Grc4OQY8Ll1s9)[o4bNzIQGYj8En]
	else: XNeUStZTxfuD27VAvhmsbGI = lEVyfFJ9HgaWKmn2u4rSUCPs
	jOwTGJksXUbKZB80yfHzM = pLUJc9VPorl2+Tfgb7R9FUcoC
	if egmc3uiyjaQL4DF9:
		ttd5KVl1EJo7PzIus0gi = f2NJYsGFtB4R5pqH-eE1p049IQou
		jOwTGJksXUbKZB80yfHzM += ttd5KVl1EJo7PzIus0gi
	else: ttd5KVl1EJo7PzIus0gi = o4bNzIQGYj8En
	if zw6XksRgpJ or FF8oJbhTZqkaVgurDxNSMp3enQytCc or RR8xEPqfLF7CcSDV: jOwTGJksXUbKZB80yfHzM += fXqLTaQUeS1t5kVNGp4B3JRbWMO
	zzmaKdis730vkVhB = JJKflmdXCo2UawGrVcHNi6vp if JJKflmdXCo2UawGrVcHNi6vp!=knTyjJ0sGIzuwbxRae(u"ࠧࡖࡒࡓࡉࡗ࠭ల") else IHaZnfkPpV7B5gOjK2lcN3D1+XNeUStZTxfuD27VAvhmsbGI+jOwTGJksXUbKZB80yfHzM
	QVyiKDnpTjxL486fYos1JSve2gm = gjhR3KTi2cynqBD8w.new(nz8x32hX0qcjUPFZk5RdJsiwED(u"ࠨࡔࡊࡆࡆ࠭ళ"),(EoiHNlTu3b4LBfqsn5gpjyW62,zzmaKdis730vkVhB),(maUl7SPesynF1j(u"࠳࠷࠸೛"),maUl7SPesynF1j(u"࠳࠷࠸೛"),maUl7SPesynF1j(u"࠳࠷࠸೛"),o4bNzIQGYj8En))
	Ghb7I5S62prJyLu3fgoNCeTA8dXmU = IlTdWtz8SvBpfP6ykHN2Kc.Draw(QVyiKDnpTjxL486fYos1JSve2gm)
	yXOrsuBgplPRZLqTMze = zzmaKdis730vkVhB-IHaZnfkPpV7B5gOjK2lcN3D1-jOwTGJksXUbKZB80yfHzM-lEVyfFJ9HgaWKmn2u4rSUCPs
	if not FF8oJbhTZqkaVgurDxNSMp3enQytCc and zw6XksRgpJ and RR8xEPqfLF7CcSDV:
		qQdwHvnTUKb += YJxaX0MQOHb8oyCBFdnIAe(u"࠳࠳࠹೜")
		UUqbt4KPT0dSuCyv7pw5mnFG6Jrecj -= mg3CbXMA2ouZzQDhRqB(u"࠴࠵࠵ೝ")
	import bidi.algorithm as PkGYL8jmwOEgN3WFQJ271
	if m7OyBjWCUFZ4i9ea3EN:
		foJwT514jAuXbDZYqlkFtSN8I = Lo7s5uylka
		m7OyBjWCUFZ4i9ea3EN = PkGYL8jmwOEgN3WFQJ271.get_display(LNDdcXGHPuxhr5E3SyTAQ.reshape(m7OyBjWCUFZ4i9ea3EN))
		cYvZWInp7liJCRfKXuG = m7OyBjWCUFZ4i9ea3EN.splitlines()
		for Im4LX01gwfluTFQ2cYvrknydpe in cYvZWInp7liJCRfKXuG:
			if Im4LX01gwfluTFQ2cYvrknydpe:
				KKVbqpTgRSYQGBX3hMm,aZzX7J0dH2hxjR5fAybtlKip = Ghb7I5S62prJyLu3fgoNCeTA8dXmU.textsize(Im4LX01gwfluTFQ2cYvrknydpe,font=TKpjCGfZquIJ8bo)
				if kkr9VbfxgwCe0ipXOJUW==X2crmy67eZpkGTRd(u"ࠩࡦࡩࡳࡺࡥࡳࠩఴ"): Jpfb1WhGk5UmtZFV0sDjdi92MynRrT = G51mfwsYqNgoCzupyX+(EoiHNlTu3b4LBfqsn5gpjyW62-KKVbqpTgRSYQGBX3hMm)/FFHRwuxQmbh8BaTqyX3
				elif kkr9VbfxgwCe0ipXOJUW==owbMhINBQsmx70guApW(u"ࠪࡶ࡮࡭ࡨࡵࠩవ"): Jpfb1WhGk5UmtZFV0sDjdi92MynRrT = G51mfwsYqNgoCzupyX+EoiHNlTu3b4LBfqsn5gpjyW62-KKVbqpTgRSYQGBX3hMm-vnzJ9I6uA1
				elif kkr9VbfxgwCe0ipXOJUW==A0aqj9uclgOtByJ6F4bz(u"ࠫࡱ࡫ࡦࡵࠩశ"): Jpfb1WhGk5UmtZFV0sDjdi92MynRrT = G51mfwsYqNgoCzupyX+vnzJ9I6uA1
				Ghb7I5S62prJyLu3fgoNCeTA8dXmU.text((Jpfb1WhGk5UmtZFV0sDjdi92MynRrT,foJwT514jAuXbDZYqlkFtSN8I),Im4LX01gwfluTFQ2cYvrknydpe,font=TKpjCGfZquIJ8bo,fill=ELfMeDTIFhJt685K(u"ࠬࡿࡥ࡭࡮ࡲࡻࠬష"))
			foJwT514jAuXbDZYqlkFtSN8I += tcanOrJjq5H4+hhA0XZDpdvMS7ru2a8f5YeTjw
	if zw6XksRgpJ or FF8oJbhTZqkaVgurDxNSMp3enQytCc or RR8xEPqfLF7CcSDV:
		O5eMwNaKGXuoi9UBvptzDhS3YEPmkc = IHaZnfkPpV7B5gOjK2lcN3D1+yXOrsuBgplPRZLqTMze+lEVyfFJ9HgaWKmn2u4rSUCPs+ttd5KVl1EJo7PzIus0gi+pLUJc9VPorl2
		if zw6XksRgpJ:
			zw6XksRgpJ = PkGYL8jmwOEgN3WFQJ271.get_display(LNDdcXGHPuxhr5E3SyTAQ.reshape(zw6XksRgpJ))
			c8rKXA4ZljM7R1tYq2ST,CYBu6U75QmnNqAIDOv14diJ = Ghb7I5S62prJyLu3fgoNCeTA8dXmU.textsize(zw6XksRgpJ,font=uRQJkAhN2CGxifcHtL)
			Nw1uZcRpfbIqzKVt2rCjAyO4 = qQdwHvnTUKb+o4bNzIQGYj8En*(UUqbt4KPT0dSuCyv7pw5mnFG6Jrecj+VYhr6wlpXDRgBbji9dnQM71kyAE58)+(VYhr6wlpXDRgBbji9dnQM71kyAE58-c8rKXA4ZljM7R1tYq2ST)/FFHRwuxQmbh8BaTqyX3
			Ghb7I5S62prJyLu3fgoNCeTA8dXmU.text((Nw1uZcRpfbIqzKVt2rCjAyO4,O5eMwNaKGXuoi9UBvptzDhS3YEPmkc),zw6XksRgpJ,font=uRQJkAhN2CGxifcHtL,fill=pCTzbw4GyVJHjkcIMQ(u"࠭ࡹࡦ࡮࡯ࡳࡼ࠭స"))
		if FF8oJbhTZqkaVgurDxNSMp3enQytCc:
			FF8oJbhTZqkaVgurDxNSMp3enQytCc = PkGYL8jmwOEgN3WFQJ271.get_display(LNDdcXGHPuxhr5E3SyTAQ.reshape(FF8oJbhTZqkaVgurDxNSMp3enQytCc))
			Jd2XUkzZlyoL3N,MGma4OeX37rE8hu = Ghb7I5S62prJyLu3fgoNCeTA8dXmU.textsize(FF8oJbhTZqkaVgurDxNSMp3enQytCc,font=uRQJkAhN2CGxifcHtL)
			owmjqeKuVpxOc = qQdwHvnTUKb+CH7RKuDVzN9f06q8MtXPhlvIxakEWg*(UUqbt4KPT0dSuCyv7pw5mnFG6Jrecj+VYhr6wlpXDRgBbji9dnQM71kyAE58)+(VYhr6wlpXDRgBbji9dnQM71kyAE58-Jd2XUkzZlyoL3N)/FFHRwuxQmbh8BaTqyX3
			Ghb7I5S62prJyLu3fgoNCeTA8dXmU.text((owmjqeKuVpxOc,O5eMwNaKGXuoi9UBvptzDhS3YEPmkc),FF8oJbhTZqkaVgurDxNSMp3enQytCc,font=uRQJkAhN2CGxifcHtL,fill=pCTzbw4GyVJHjkcIMQ(u"ࠧࡺࡧ࡯ࡰࡴࡽࠧహ"))
		if RR8xEPqfLF7CcSDV:
			RR8xEPqfLF7CcSDV = PkGYL8jmwOEgN3WFQJ271.get_display(LNDdcXGHPuxhr5E3SyTAQ.reshape(RR8xEPqfLF7CcSDV))
			m7rZs5n3BuTUt8ylEqpaFVkjO1,NrbmgWenlfv0wjz5O7YK = Ghb7I5S62prJyLu3fgoNCeTA8dXmU.textsize(RR8xEPqfLF7CcSDV,font=uRQJkAhN2CGxifcHtL)
			p67cnwgkMZOXl3EV = qQdwHvnTUKb+FFHRwuxQmbh8BaTqyX3*(UUqbt4KPT0dSuCyv7pw5mnFG6Jrecj+VYhr6wlpXDRgBbji9dnQM71kyAE58)+(VYhr6wlpXDRgBbji9dnQM71kyAE58-m7rZs5n3BuTUt8ylEqpaFVkjO1)/FFHRwuxQmbh8BaTqyX3
			Ghb7I5S62prJyLu3fgoNCeTA8dXmU.text((p67cnwgkMZOXl3EV,O5eMwNaKGXuoi9UBvptzDhS3YEPmkc),RR8xEPqfLF7CcSDV,font=uRQJkAhN2CGxifcHtL,fill=EF2tvxZHz5n4UruPhaViXKycI6SQR(u"ࠨࡻࡨࡰࡱࡵࡷࠨ఺"))
	if NN9niuC7RoqmhkL2:
		yTNC75P8cwkAM,UoFxCjIkTn0RfvWzQDqe = [],[]
		S6Swsfbtlj4ApkPiQRoeYCLy = IIOqG9NKwES8m0rDMCj(S6Swsfbtlj4ApkPiQRoeYCLy)
		YZyl6TCRUFqDI = S6Swsfbtlj4ApkPiQRoeYCLy.split(OzU6t0qcH7MQabeBYK8vgoG(u"ࠩࡢࡷࡸࡹ࡟ࡠࡰࡨࡻࡱ࡯࡮ࡦࡡࠪ఻"))
		for eODRhKnx6tPcvJ91oX in YZyl6TCRUFqDI:
			nbwYGBruNeJ0tdF9QjiaXpRALZIm = BOG1qPQJv7CnkMiKp9
			if   OBsrtQo2pPlgURCxJYbj9iXMD(u"ࠪࡣࡸࡹࡳࡠࡡ࡯࡭ࡳ࡫࡬ࡦࡨࡷࡣ఼ࠬ") in eODRhKnx6tPcvJ91oX: nbwYGBruNeJ0tdF9QjiaXpRALZIm = ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"ࠫࡱ࡫ࡦࡵࠩఽ")
			elif PPAUFrY8cduRT(u"ࠬࡥࡳࡴࡵࡢࡣࡱ࡯࡮ࡦࡴ࡬࡫࡭ࡺ࡟ࠨా") in eODRhKnx6tPcvJ91oX: nbwYGBruNeJ0tdF9QjiaXpRALZIm = YJxaX0MQOHb8oyCBFdnIAe(u"࠭ࡲࡪࡩ࡫ࡸࠬి")
			elif ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"ࠧࡠࡵࡶࡷࡤࡥ࡬ࡪࡰࡨࡧࡪࡴࡴࡦࡴࡢࠫీ") in eODRhKnx6tPcvJ91oX: nbwYGBruNeJ0tdF9QjiaXpRALZIm = pCTzbw4GyVJHjkcIMQ(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨు")
			cKCMIEG9Dd8UxXJZrTo1fs43h = eODRhKnx6tPcvJ91oX
			LE5bx0iKyFHwDeZp79BQ1csqzOYV = DyVGS3dX0ZxR.findall(dBi72erQEtKDOwjNFaoAgSP(u"ࠩࡢࡷࡸࡹ࡟ࡠ࠰࠭ࡃࡤ࠭ూ"),eODRhKnx6tPcvJ91oX,DyVGS3dX0ZxR.DOTALL)
			for TUuSXK6mhAwy2MaYeP1CZxQf3 in LE5bx0iKyFHwDeZp79BQ1csqzOYV: cKCMIEG9Dd8UxXJZrTo1fs43h = cKCMIEG9Dd8UxXJZrTo1fs43h.replace(TUuSXK6mhAwy2MaYeP1CZxQf3,HQmDERMFjx)
			if cKCMIEG9Dd8UxXJZrTo1fs43h==HQmDERMFjx: KKVbqpTgRSYQGBX3hMm,aZzX7J0dH2hxjR5fAybtlKip = o4bNzIQGYj8En,PEKTdSmY2zX
			else: KKVbqpTgRSYQGBX3hMm,aZzX7J0dH2hxjR5fAybtlKip = Ghb7I5S62prJyLu3fgoNCeTA8dXmU.textsize(cKCMIEG9Dd8UxXJZrTo1fs43h,font=rHYPpafzvCsQTkBejhbgE5mi8)
			if   nbwYGBruNeJ0tdF9QjiaXpRALZIm==mg3CbXMA2ouZzQDhRqB(u"ࠪࡰࡪ࡬ࡴࠨృ"): rkObt69pS3AfIu8sBYwM = vyEgbMpCZPFGQcw+YY8Ll2OqajSR06p
			elif nbwYGBruNeJ0tdF9QjiaXpRALZIm==cWbkR6iUZsnJQj14(u"ࠫࡷ࡯ࡧࡩࡶࠪౄ"): rkObt69pS3AfIu8sBYwM = vyEgbMpCZPFGQcw+YY8Ll2OqajSR06p+NN4Rq3ChWxPKVJ0f2-KKVbqpTgRSYQGBX3hMm
			elif nbwYGBruNeJ0tdF9QjiaXpRALZIm==SODvU3Ibq5VzC(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ౅"): rkObt69pS3AfIu8sBYwM = vyEgbMpCZPFGQcw+YY8Ll2OqajSR06p+(NN4Rq3ChWxPKVJ0f2-KKVbqpTgRSYQGBX3hMm)/FFHRwuxQmbh8BaTqyX3
			if rkObt69pS3AfIu8sBYwM<YY8Ll2OqajSR06p: rkObt69pS3AfIu8sBYwM = vyEgbMpCZPFGQcw+YY8Ll2OqajSR06p
			yTNC75P8cwkAM.append(rkObt69pS3AfIu8sBYwM)
			UoFxCjIkTn0RfvWzQDqe.append(KKVbqpTgRSYQGBX3hMm)
		rkObt69pS3AfIu8sBYwM = yTNC75P8cwkAM[o4bNzIQGYj8En]
		frte6B9ugqFDpbSCW4Kd = S6Swsfbtlj4ApkPiQRoeYCLy.split(U0VwOviFaYPz2QGs45mJhMXf7Zk(u"࠭࡟ࡴࡵࡶࡣࠬె"))
		iiD7XPhBzUZqxoWtvy = (A0aqj9uclgOtByJ6F4bz(u"࠶࠺࠻ೞ"),A0aqj9uclgOtByJ6F4bz(u"࠶࠺࠻ೞ"),A0aqj9uclgOtByJ6F4bz(u"࠶࠺࠻ೞ"),A0aqj9uclgOtByJ6F4bz(u"࠶࠺࠻ೞ"))
		S7S6b5yfZRuNUIx = iiD7XPhBzUZqxoWtvy
		Tjwlohn0rf9kK5Um4vBVQ6GD,D95RxNiCGLYqB7XoQtTpwUy0JgMFOe = o4bNzIQGYj8En,o4bNzIQGYj8En
		RaHVtJKlWmwqz1rYO87gTn5yQ6PsF = mic3MEN709xOkrjD5ZvbGIlX6
		wLXjIxfecuUTp73tZvC2DOPQ = o4bNzIQGYj8En
		dOVrYl4iKqRxsmTzMuZ2 = IHaZnfkPpV7B5gOjK2lcN3D1+lEVyfFJ9HgaWKmn2u4rSUCPs/FFHRwuxQmbh8BaTqyX3
		if XNeUStZTxfuD27VAvhmsbGI<(yXOrsuBgplPRZLqTMze+lEVyfFJ9HgaWKmn2u4rSUCPs):
			fbcNOvlpeAG9 = (yXOrsuBgplPRZLqTMze+lEVyfFJ9HgaWKmn2u4rSUCPs-XNeUStZTxfuD27VAvhmsbGI)/FFHRwuxQmbh8BaTqyX3
			dOVrYl4iKqRxsmTzMuZ2 = IHaZnfkPpV7B5gOjK2lcN3D1+lEVyfFJ9HgaWKmn2u4rSUCPs+fbcNOvlpeAG9-DdaZeBcHzPhbwsi6SAk0CL8G/FFHRwuxQmbh8BaTqyX3
		for Im4LX01gwfluTFQ2cYvrknydpe in frte6B9ugqFDpbSCW4Kd:
			if not Im4LX01gwfluTFQ2cYvrknydpe or (Im4LX01gwfluTFQ2cYvrknydpe and ord(Im4LX01gwfluTFQ2cYvrknydpe[o4bNzIQGYj8En])==U0VwOviFaYPz2QGs45mJhMXf7Zk(u"࠻࠻࠲࠸࠻೟")): continue
			bqLudC4xnvSD9lX3UgQyBFO = Im4LX01gwfluTFQ2cYvrknydpe.split(CDwSWB4v39N7(u"ࠧࡠࡰࡨࡻࡱ࡯࡮ࡦࡡࠪే"),CH7RKuDVzN9f06q8MtXPhlvIxakEWg)
			OWTNMFkneb9SK = Im4LX01gwfluTFQ2cYvrknydpe.split(k4IUieraScH9DV1N7pJgQosYAx5l(u"ࠨࡡࡱࡩࡼࡩ࡯࡭ࡱࡵࠫై"),CH7RKuDVzN9f06q8MtXPhlvIxakEWg)
			eKtL74bcpdI9Y = Im4LX01gwfluTFQ2cYvrknydpe.split(ShnRVsifKtc60zqQ(u"ࠩࡢࡩࡳࡪࡣࡰ࡮ࡲࡶࡤ࠭౉"),CH7RKuDVzN9f06q8MtXPhlvIxakEWg)
			Nng3cpDJmEIKd47LT15xPYQk6bsZ = Im4LX01gwfluTFQ2cYvrknydpe.split(HDpmv4UXzlf72SK9(u"ࠪࡣࡱ࡯࡮ࡦࡴࡷࡰࡤ࠭ొ"),CH7RKuDVzN9f06q8MtXPhlvIxakEWg)
			zzeM7J6vYxqo = Im4LX01gwfluTFQ2cYvrknydpe.split(EF2tvxZHz5n4UruPhaViXKycI6SQR(u"ࠫࡤࡲࡩ࡯ࡧ࡯ࡩ࡫ࡺ࡟ࠨో"),CH7RKuDVzN9f06q8MtXPhlvIxakEWg)
			KKPzN8FlMpHdwnLrAtsY65aXD = Im4LX01gwfluTFQ2cYvrknydpe.split(OBsrtQo2pPlgURCxJYbj9iXMD(u"ࠬࡥ࡬ࡪࡰࡨࡶ࡮࡭ࡨࡵࡡࠪౌ"),CH7RKuDVzN9f06q8MtXPhlvIxakEWg)
			BVp823xhYEzFZrkCu7yw = Im4LX01gwfluTFQ2cYvrknydpe.split(mgLADoQ1pbtY(u"࠭࡟࡭࡫ࡱࡩࡨ࡫࡮ࡵࡧࡵࡣ్ࠬ"),CH7RKuDVzN9f06q8MtXPhlvIxakEWg)
			if len(bqLudC4xnvSD9lX3UgQyBFO)>CH7RKuDVzN9f06q8MtXPhlvIxakEWg:
				wLXjIxfecuUTp73tZvC2DOPQ += CH7RKuDVzN9f06q8MtXPhlvIxakEWg
				Im4LX01gwfluTFQ2cYvrknydpe = bqLudC4xnvSD9lX3UgQyBFO[CH7RKuDVzN9f06q8MtXPhlvIxakEWg]
				Tjwlohn0rf9kK5Um4vBVQ6GD = o4bNzIQGYj8En
				rkObt69pS3AfIu8sBYwM = yTNC75P8cwkAM[wLXjIxfecuUTp73tZvC2DOPQ]
				D95RxNiCGLYqB7XoQtTpwUy0JgMFOe += PEKTdSmY2zX
				RaHVtJKlWmwqz1rYO87gTn5yQ6PsF = mic3MEN709xOkrjD5ZvbGIlX6
			elif len(OWTNMFkneb9SK)>CH7RKuDVzN9f06q8MtXPhlvIxakEWg:
				Im4LX01gwfluTFQ2cYvrknydpe = OWTNMFkneb9SK[CH7RKuDVzN9f06q8MtXPhlvIxakEWg]
				S7S6b5yfZRuNUIx = Im4LX01gwfluTFQ2cYvrknydpe[o4bNzIQGYj8En:SODvU3Ibq5VzC(u"࠾ೠ")]
				S7S6b5yfZRuNUIx = pCTzbw4GyVJHjkcIMQ(u"ࠧࠤࠩ౎")+S7S6b5yfZRuNUIx[FFHRwuxQmbh8BaTqyX3:]
				Im4LX01gwfluTFQ2cYvrknydpe = Im4LX01gwfluTFQ2cYvrknydpe[A0aqj9uclgOtByJ6F4bz(u"࠹ೡ"):]
			elif len(eKtL74bcpdI9Y)>CH7RKuDVzN9f06q8MtXPhlvIxakEWg:
				Im4LX01gwfluTFQ2cYvrknydpe = eKtL74bcpdI9Y[CH7RKuDVzN9f06q8MtXPhlvIxakEWg]
				S7S6b5yfZRuNUIx = iiD7XPhBzUZqxoWtvy
			elif len(Nng3cpDJmEIKd47LT15xPYQk6bsZ)>CH7RKuDVzN9f06q8MtXPhlvIxakEWg:
				Im4LX01gwfluTFQ2cYvrknydpe = Nng3cpDJmEIKd47LT15xPYQk6bsZ[CH7RKuDVzN9f06q8MtXPhlvIxakEWg]
				RaHVtJKlWmwqz1rYO87gTn5yQ6PsF = gyd2rf0UR5
				Tjwlohn0rf9kK5Um4vBVQ6GD = UoFxCjIkTn0RfvWzQDqe[wLXjIxfecuUTp73tZvC2DOPQ]
			elif len(zzeM7J6vYxqo)>C3ZK1pu4rfmj8TsWUtBaM(u"࠲ೢ"): Im4LX01gwfluTFQ2cYvrknydpe = zzeM7J6vYxqo[CH7RKuDVzN9f06q8MtXPhlvIxakEWg]
			elif len(KKPzN8FlMpHdwnLrAtsY65aXD)>EAVanJj1ers2GQud(u"࠳ೣ"): Im4LX01gwfluTFQ2cYvrknydpe = KKPzN8FlMpHdwnLrAtsY65aXD[CH7RKuDVzN9f06q8MtXPhlvIxakEWg]
			elif len(BVp823xhYEzFZrkCu7yw)>LHX65I9nkx0PstgcVY24uSi(u"࠴೤"): Im4LX01gwfluTFQ2cYvrknydpe = BVp823xhYEzFZrkCu7yw[CH7RKuDVzN9f06q8MtXPhlvIxakEWg]
			if Im4LX01gwfluTFQ2cYvrknydpe:
				AAndhWvPIYG9ZDXV5mHb0SryMszx6N = dOVrYl4iKqRxsmTzMuZ2+D95RxNiCGLYqB7XoQtTpwUy0JgMFOe
				Im4LX01gwfluTFQ2cYvrknydpe = PkGYL8jmwOEgN3WFQJ271.get_display(Im4LX01gwfluTFQ2cYvrknydpe)
				KKVbqpTgRSYQGBX3hMm,aZzX7J0dH2hxjR5fAybtlKip = Ghb7I5S62prJyLu3fgoNCeTA8dXmU.textsize(Im4LX01gwfluTFQ2cYvrknydpe,font=rHYPpafzvCsQTkBejhbgE5mi8)
				if RaHVtJKlWmwqz1rYO87gTn5yQ6PsF: Tjwlohn0rf9kK5Um4vBVQ6GD -= KKVbqpTgRSYQGBX3hMm
				uadIJezVUGQRmhKZEjNOsiXFCy9684 = rkObt69pS3AfIu8sBYwM+Tjwlohn0rf9kK5Um4vBVQ6GD
				Ghb7I5S62prJyLu3fgoNCeTA8dXmU.text((uadIJezVUGQRmhKZEjNOsiXFCy9684,AAndhWvPIYG9ZDXV5mHb0SryMszx6N),Im4LX01gwfluTFQ2cYvrknydpe,font=rHYPpafzvCsQTkBejhbgE5mi8,fill=S7S6b5yfZRuNUIx)
				if wK7oqpdkfNQxhsJGRySZAcXE9LBWUC==EAVanJj1ers2GQud(u"ࠨ࡯ࡨࡲࡺࡥࡩࡵࡧࡰࠫ౏"): Ghb7I5S62prJyLu3fgoNCeTA8dXmU.text((uadIJezVUGQRmhKZEjNOsiXFCy9684+CH7RKuDVzN9f06q8MtXPhlvIxakEWg,AAndhWvPIYG9ZDXV5mHb0SryMszx6N+CH7RKuDVzN9f06q8MtXPhlvIxakEWg),Im4LX01gwfluTFQ2cYvrknydpe,font=rHYPpafzvCsQTkBejhbgE5mi8,fill=S7S6b5yfZRuNUIx)
				if not RaHVtJKlWmwqz1rYO87gTn5yQ6PsF: Tjwlohn0rf9kK5Um4vBVQ6GD += KKVbqpTgRSYQGBX3hMm
				if AAndhWvPIYG9ZDXV5mHb0SryMszx6N>yXOrsuBgplPRZLqTMze+PEKTdSmY2zX: break
	if wK7oqpdkfNQxhsJGRySZAcXE9LBWUC==k4IUieraScH9DV1N7pJgQosYAx5l(u"ࠩࡰࡩࡳࡻ࡟ࡪࡶࡨࡱࠬ౐"):
		x3xQTDJ0jthLIC = bIxiluCTELadZg6vNXwYPRoD1jyH.copy()
		jHWkt18govGwY7iUbduAfxCyRc.sleep(EAVanJj1ers2GQud(u"࠴࠳࠶࠵೥"))
		x3xQTDJ0jthLIC.paste(hn1OkzSpaDZIUEiw0CrM69qJt,(o4bNzIQGYj8En,o4bNzIQGYj8En),mask=QVyiKDnpTjxL486fYos1JSve2gm)
	else: x3xQTDJ0jthLIC = QVyiKDnpTjxL486fYos1JSve2gm
	if C6H1qXua3SMQiIrzxNvJWZE: Al2Vt3kdnz0YQqfUiaTXFLM = Al2Vt3kdnz0YQqfUiaTXFLM.decode(Zex6D4tJE52r)
	try: x3xQTDJ0jthLIC.save(Al2Vt3kdnz0YQqfUiaTXFLM)
	except UnicodeError:
		if C6H1qXua3SMQiIrzxNvJWZE:
			Al2Vt3kdnz0YQqfUiaTXFLM = Al2Vt3kdnz0YQqfUiaTXFLM.encode(Zex6D4tJE52r)
			x3xQTDJ0jthLIC.save(Al2Vt3kdnz0YQqfUiaTXFLM)
	return zzmaKdis730vkVhB
def J9Jymx4MLXg7kSAnif1jDr(gdxh31fPcmC6e2SIbkQ8,rHYPpafzvCsQTkBejhbgE5mi8,M0h1XZDG4uqiUYBv,ZA1Nv7s5gbMpD9ua8eX,NN4Rq3ChWxPKVJ0f2,voHyxcqGKbesiN1W4I7DgOLRZwu):
	ccKrnDoXeqvh275Yb,IqPD5v1KdVli,JgqMnTNFlLPAGwV6tx5 = HQmDERMFjx,o4bNzIQGYj8En,jL1E5AKfwBDv6xmeQtUXcJ3d(u"࠶࠻࠰࠱࠲೦")
	M0h1XZDG4uqiUYBv = M0h1XZDG4uqiUYBv.replace(jL1E5AKfwBDv6xmeQtUXcJ3d(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࠫ౑"),CDwSWB4v39N7(u"ࠫࡠࡉࡏࡍࡑࡕ࠾࠿ࡀࠧ౒"))
	iL9azQlAVZf7mUcjxIGKT32q40 = NN4Rq3ChWxPKVJ0f2-ZA1Nv7s5gbMpD9ua8eX*FFHRwuxQmbh8BaTqyX3
	for LohpmrQVwt5y2uR4MON7zBZd in M0h1XZDG4uqiUYBv.splitlines():
		IqPD5v1KdVli += voHyxcqGKbesiN1W4I7DgOLRZwu
		uazAijxloDqy10wL,iMPOycY40XTaRJ1gQjDpf7BECxAU3 = o4bNzIQGYj8En,HQmDERMFjx
		for srhvgaNGwe1OVXEtPpb9Bq06RyZ in LohpmrQVwt5y2uR4MON7zBZd.split(oQpxmKiRPlHeGsLXNrJF78O):
			LmVeoa5Sb3zwQvFXK = VV1bFxH5XQhBUldZ2ijc(oQpxmKiRPlHeGsLXNrJF78O+srhvgaNGwe1OVXEtPpb9Bq06RyZ)
			BgYPqz3DhWM7jmAa6rtSo0T,Nhza27EDYA0bMSL4vr = gdxh31fPcmC6e2SIbkQ8.textsize(LmVeoa5Sb3zwQvFXK,font=rHYPpafzvCsQTkBejhbgE5mi8)
			if uazAijxloDqy10wL+BgYPqz3DhWM7jmAa6rtSo0T<iL9azQlAVZf7mUcjxIGKT32q40:
				if not iMPOycY40XTaRJ1gQjDpf7BECxAU3: iMPOycY40XTaRJ1gQjDpf7BECxAU3 += srhvgaNGwe1OVXEtPpb9Bq06RyZ
				else: iMPOycY40XTaRJ1gQjDpf7BECxAU3 += oQpxmKiRPlHeGsLXNrJF78O+srhvgaNGwe1OVXEtPpb9Bq06RyZ
				uazAijxloDqy10wL += BgYPqz3DhWM7jmAa6rtSo0T
			else:
				if BgYPqz3DhWM7jmAa6rtSo0T<iL9azQlAVZf7mUcjxIGKT32q40:
					iMPOycY40XTaRJ1gQjDpf7BECxAU3 += OBsrtQo2pPlgURCxJYbj9iXMD(u"ࠬࡢ࡮ࠡࠩ౓")+srhvgaNGwe1OVXEtPpb9Bq06RyZ
					IqPD5v1KdVli += voHyxcqGKbesiN1W4I7DgOLRZwu
					uazAijxloDqy10wL = BgYPqz3DhWM7jmAa6rtSo0T
				else:
					while BgYPqz3DhWM7jmAa6rtSo0T>iL9azQlAVZf7mUcjxIGKT32q40:
						for OLRSzDCVZUm in range(CH7RKuDVzN9f06q8MtXPhlvIxakEWg,len(oQpxmKiRPlHeGsLXNrJF78O+srhvgaNGwe1OVXEtPpb9Bq06RyZ),CH7RKuDVzN9f06q8MtXPhlvIxakEWg):
							aFvPrDAK8oMly0I7CSpWN3Xc = oQpxmKiRPlHeGsLXNrJF78O+srhvgaNGwe1OVXEtPpb9Bq06RyZ[:OLRSzDCVZUm]
							lOU5tuRM6iko3dEjIb4mC97 = srhvgaNGwe1OVXEtPpb9Bq06RyZ[OLRSzDCVZUm:]
							L1VKmX9BjIAn2svZ = VV1bFxH5XQhBUldZ2ijc(aFvPrDAK8oMly0I7CSpWN3Xc)
							f7n5t9PJslmGD0ERLeBdYU,dfGmxNwceXDIhQOiW2u6z = gdxh31fPcmC6e2SIbkQ8.textsize(L1VKmX9BjIAn2svZ,font=rHYPpafzvCsQTkBejhbgE5mi8)
							if uazAijxloDqy10wL+f7n5t9PJslmGD0ERLeBdYU>iL9azQlAVZf7mUcjxIGKT32q40:
								MD9yHxZVUsRqKWBNYF8kLXv61 = BgYPqz3DhWM7jmAa6rtSo0T-f7n5t9PJslmGD0ERLeBdYU
								iMPOycY40XTaRJ1gQjDpf7BECxAU3 += aFvPrDAK8oMly0I7CSpWN3Xc+ti3SbXNV0aJ7n5Grc4OQY8Ll1s9
								IqPD5v1KdVli += voHyxcqGKbesiN1W4I7DgOLRZwu
								BgYPqz3DhWM7jmAa6rtSo0T = MD9yHxZVUsRqKWBNYF8kLXv61
								if MD9yHxZVUsRqKWBNYF8kLXv61>iL9azQlAVZf7mUcjxIGKT32q40:
									uazAijxloDqy10wL = o4bNzIQGYj8En
									srhvgaNGwe1OVXEtPpb9Bq06RyZ = lOU5tuRM6iko3dEjIb4mC97
								else:
									uazAijxloDqy10wL = MD9yHxZVUsRqKWBNYF8kLXv61
									iMPOycY40XTaRJ1gQjDpf7BECxAU3 += lOU5tuRM6iko3dEjIb4mC97
								break
				if IqPD5v1KdVli>JgqMnTNFlLPAGwV6tx5: break
		ccKrnDoXeqvh275Yb += ti3SbXNV0aJ7n5Grc4OQY8Ll1s9+iMPOycY40XTaRJ1gQjDpf7BECxAU3
		if IqPD5v1KdVli>JgqMnTNFlLPAGwV6tx5: break
	ccKrnDoXeqvh275Yb = ccKrnDoXeqvh275Yb[CH7RKuDVzN9f06q8MtXPhlvIxakEWg:]
	ccKrnDoXeqvh275Yb = ccKrnDoXeqvh275Yb.replace(EF2tvxZHz5n4UruPhaViXKycI6SQR(u"࡛࠭ࡄࡑࡏࡓࡗࡀ࠺࠻ࠩ౔"),ELfMeDTIFhJt685K(u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࠨౕ"))
	return ccKrnDoXeqvh275Yb
def VV1bFxH5XQhBUldZ2ijc(srhvgaNGwe1OVXEtPpb9Bq06RyZ):
	if ELfMeDTIFhJt685K(u"ࠨ࡝ౖࠪ") in srhvgaNGwe1OVXEtPpb9Bq06RyZ and SODvU3Ibq5VzC(u"ࠩࡠࠫ౗") in srhvgaNGwe1OVXEtPpb9Bq06RyZ:
		LE5bx0iKyFHwDeZp79BQ1csqzOYV = [cjqzOQ5GXD4kR,nz8x32hX0qcjUPFZk5RdJsiwED(u"ࠪ࡟࠴ࡘࡔࡍ࡟ࠪౘ"),SODvU3Ibq5VzC(u"ࠫࡠ࠵ࡌࡆࡈࡗࡡࠬౙ"),YJxaX0MQOHb8oyCBFdnIAe(u"ࠬࡡ࠯ࡓࡋࡊࡌ࡙ࡣࠧౚ"),HDpmv4UXzlf72SK9(u"࡛࠭࠰ࡅࡈࡒ࡙ࡋࡒ࡞ࠩ౛"),mgLADoQ1pbtY(u"ࠧ࡜ࡔࡗࡐࡢ࠭౜"),jL1E5AKfwBDv6xmeQtUXcJ3d(u"ࠨ࡝ࡏࡉࡋ࡚࡝ࠨౝ"),ShnRVsifKtc60zqQ(u"ࠩ࡞ࡖࡎࡍࡈࡕ࡟ࠪ౞"),KhUG1NV9bln5zXjptqFW6dgo(u"ࠪ࡟ࡈࡋࡎࡕࡇࡕࡡࠬ౟")]
		dRIv6lJbqKxhH5EVCumjtn4y = DyVGS3dX0ZxR.findall(maUl7SPesynF1j(u"ࠫࡡࡡࡃࡐࡎࡒࡖࠥ࠴ࠪࡀ࡞ࡠࠫౠ"),srhvgaNGwe1OVXEtPpb9Bq06RyZ,DyVGS3dX0ZxR.DOTALL)
		nGUckuSrF7AQ1 = DyVGS3dX0ZxR.findall(SODvU3Ibq5VzC(u"ࠬࡢ࡛ࡄࡑࡏࡓࡗࡀ࠺࠻࠰࠭ࡃࡡࡣࠧౡ"),srhvgaNGwe1OVXEtPpb9Bq06RyZ,DyVGS3dX0ZxR.DOTALL)
		o4kB0XbGtN2uv6cpzsyCRHjVi9aD = LE5bx0iKyFHwDeZp79BQ1csqzOYV+dRIv6lJbqKxhH5EVCumjtn4y+nGUckuSrF7AQ1
		for TUuSXK6mhAwy2MaYeP1CZxQf3 in o4kB0XbGtN2uv6cpzsyCRHjVi9aD: srhvgaNGwe1OVXEtPpb9Bq06RyZ = srhvgaNGwe1OVXEtPpb9Bq06RyZ.replace(TUuSXK6mhAwy2MaYeP1CZxQf3,HQmDERMFjx)
	return srhvgaNGwe1OVXEtPpb9Bq06RyZ
def IIOqG9NKwES8m0rDMCj(NN9niuC7RoqmhkL2):
	NN9niuC7RoqmhkL2 = NN9niuC7RoqmhkL2.replace(ti3SbXNV0aJ7n5Grc4OQY8Ll1s9,KhUG1NV9bln5zXjptqFW6dgo(u"࠭࡟ࡴࡵࡶࡣࡤࡴࡥࡸ࡮࡬ࡲࡪࡥࠧౢ"))
	NN9niuC7RoqmhkL2 = NN9niuC7RoqmhkL2.replace(CDwSWB4v39N7(u"ࠧ࡜ࡔࡗࡐࡢ࠭ౣ"),LHX65I9nkx0PstgcVY24uSi(u"ࠨࡡࡶࡷࡸࡥ࡟࡭࡫ࡱࡩࡷࡺ࡬ࡠࠩ౤"))
	NN9niuC7RoqmhkL2 = NN9niuC7RoqmhkL2.replace(cWbkR6iUZsnJQj14(u"ࠩ࡞ࡐࡊࡌࡔ࡞ࠩ౥"),KKi79PFqsYB0dWSRgaJ3DyE(u"ࠪࡣࡸࡹࡳࡠࡡ࡯࡭ࡳ࡫࡬ࡦࡨࡷࡣࠬ౦"))
	NN9niuC7RoqmhkL2 = NN9niuC7RoqmhkL2.replace(knTyjJ0sGIzuwbxRae(u"ࠫࡠࡘࡉࡈࡊࡗࡡࠬ౧"),LHX65I9nkx0PstgcVY24uSi(u"ࠬࡥࡳࡴࡵࡢࡣࡱ࡯࡮ࡦࡴ࡬࡫࡭ࡺ࡟ࠨ౨"))
	NN9niuC7RoqmhkL2 = NN9niuC7RoqmhkL2.replace(ELfMeDTIFhJt685K(u"࡛࠭ࡄࡇࡑࡘࡊࡘ࡝ࠨ౩"),pCTzbw4GyVJHjkcIMQ(u"ࠧࡠࡵࡶࡷࡤࡥ࡬ࡪࡰࡨࡧࡪࡴࡴࡦࡴࡢࠫ౪"))
	NN9niuC7RoqmhkL2 = NN9niuC7RoqmhkL2.replace(cjqzOQ5GXD4kR,nz8x32hX0qcjUPFZk5RdJsiwED(u"ࠨࡡࡶࡷࡸࡥ࡟ࡦࡰࡧࡧࡴࡲ࡯ࡳࡡࠪ౫"))
	Gh69UOSawLsgoERjkQz8Y24qI = DyVGS3dX0ZxR.findall(maUl7SPesynF1j(u"ࠩ࡟࡟ࡈࡕࡌࡐࡔࠣࠬ࠳࠰࠿ࠪ࡞ࡠࠫ౬"),NN9niuC7RoqmhkL2,DyVGS3dX0ZxR.DOTALL)
	for NNdOXkixEA8zlV4rK39 in Gh69UOSawLsgoERjkQz8Y24qI: NN9niuC7RoqmhkL2 = NN9niuC7RoqmhkL2.replace(cWbkR6iUZsnJQj14(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࠫ౭")+NNdOXkixEA8zlV4rK39+pCTzbw4GyVJHjkcIMQ(u"ࠫࡢ࠭౮"),KhUG1NV9bln5zXjptqFW6dgo(u"ࠬࡥࡳࡴࡵࡢࡣࡳ࡫ࡷࡤࡱ࡯ࡳࡷ࠭౯")+NNdOXkixEA8zlV4rK39+dBi72erQEtKDOwjNFaoAgSP(u"࠭࡟ࠨ౰"))
	return NN9niuC7RoqmhkL2
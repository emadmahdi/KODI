# -*- coding: utf-8 -*-
from FF68kA5BUy import *
HDLtdMAy7wPkl8aKC3O2 = 'EGYBEST3'
EEJvXQzSZNt = '_EB3_'
e2VR8nohduY = Jzthpc2nj5.SITESURLS[HDLtdMAy7wPkl8aKC3O2][0]
FwhZ0nXtpoHTMarf = ['المصارعة الحرة','ايجي بست','التصميم الجديد','عروض المصارعة','مكتبتي','ايجي بست الجديد','ايجي بست البديل','egybest','موقع ايجي بست','موقع نتفليكس']
def kk6X5LxpsND(mode,url,zmL397efNlks5uTEV,text):
	if   mode==790: zLZUkrP7ac5 = afkxo7FyZWB4O6K1eXrs5I()
	elif mode==791: zLZUkrP7ac5 = c8wfGju4CWZm(url,zmL397efNlks5uTEV)
	elif mode==792: zLZUkrP7ac5 = REWBU20fyqaLprY(url)
	elif mode==793: zLZUkrP7ac5 = f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url)
	elif mode==796: zLZUkrP7ac5 = OeIkhc6dCf01i2BFSKX5L8E9Nvr(url,zmL397efNlks5uTEV)
	elif mode==799: zLZUkrP7ac5 = hm4kawIPKp3oMrC75dJZA9HS2(text)
	else: zLZUkrP7ac5 = False
	return zLZUkrP7ac5
def afkxo7FyZWB4O6K1eXrs5I():
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(H5x4Z2qPwR8vXM,'GET',e2VR8nohduY,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'EGYBEST3-MENU-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('list-pages(.*?)fa-folder',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('href="(.*?)".*?<span>(.*?)</span>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,title in items:
			title = title.strip(oQpxmKiRPlHeGsLXNrJF78O)
			if any(value in title for value in FwhZ0nXtpoHTMarf): continue
			if 'http' not in vn1grP3y4It9GmVuBbLJfz2A: vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+vn1grP3y4It9GmVuBbLJfz2A
			CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,791)
		CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('main-article(.*?)social-box',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('main-title.*?">(.*?)<.*?href="(.*?)"',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for title,vn1grP3y4It9GmVuBbLJfz2A in items:
			title = title.strip(oQpxmKiRPlHeGsLXNrJF78O)
			if any(value in title for value in FwhZ0nXtpoHTMarf): continue
			if 'http' not in vn1grP3y4It9GmVuBbLJfz2A: vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+vn1grP3y4It9GmVuBbLJfz2A
			CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,791,HQmDERMFjx,'mainmenu')
		CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('main-menu(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('href="(.*?)">(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,title in items:
			title = title.strip(oQpxmKiRPlHeGsLXNrJF78O)
			if any(value in title for value in FwhZ0nXtpoHTMarf): continue
			if 'http' not in vn1grP3y4It9GmVuBbLJfz2A: vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+vn1grP3y4It9GmVuBbLJfz2A
			CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,791)
	return CzNPJydxQLfw27tv4ZF8KORAbX5
def OeIkhc6dCf01i2BFSKX5L8E9Nvr(url,type=HQmDERMFjx):
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'EGYBEST3-SEASONS_EPISODES-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('main-article".*?">(.*?)<(.*?)article',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		WTgZPcmVih38IjnSJ2U,EX6nDt50Hih9mIxulw7kpMCZfaOsJR,items = HQmDERMFjx,HQmDERMFjx,[]
		for name,MJ2gSPyTl9hzoi1 in Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
			if 'حلقات' in name: EX6nDt50Hih9mIxulw7kpMCZfaOsJR = MJ2gSPyTl9hzoi1
			if 'مواسم' in name: WTgZPcmVih38IjnSJ2U = MJ2gSPyTl9hzoi1
		if WTgZPcmVih38IjnSJ2U and not type:
			items = DyVGS3dX0ZxR.findall('href="(.*?)".*?data-src="(.*?)".*?"title">(.*?)<',WTgZPcmVih38IjnSJ2U,DyVGS3dX0ZxR.DOTALL)
			if len(items)>1:
				for vn1grP3y4It9GmVuBbLJfz2A,uIGD4vZcP61QNmw78LXqoEpH,title in items:
					CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,796,uIGD4vZcP61QNmw78LXqoEpH,'season')
		if EX6nDt50Hih9mIxulw7kpMCZfaOsJR and len(items)<2:
			items = DyVGS3dX0ZxR.findall('href="(.*?)".*?data-src="(.*?)".*?class="title">(.*?)<',EX6nDt50Hih9mIxulw7kpMCZfaOsJR,DyVGS3dX0ZxR.DOTALL)
			if items:
				for vn1grP3y4It9GmVuBbLJfz2A,uIGD4vZcP61QNmw78LXqoEpH,title in items:
					CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,793,uIGD4vZcP61QNmw78LXqoEpH)
			else:
				items = DyVGS3dX0ZxR.findall('href="(.*?)">(.*?)<',EX6nDt50Hih9mIxulw7kpMCZfaOsJR,DyVGS3dX0ZxR.DOTALL)
				for vn1grP3y4It9GmVuBbLJfz2A,title in items:
					CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,793)
	return
def c8wfGju4CWZm(url,type=HQmDERMFjx):
	MMYecLpZi6wfT9m3ju,start,GQB0WzyICDK7mXxN2Acdi,select,ubgQBzFtaLCkKU42MXZ96mefhjoip = 0,0,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx
	if 'pagination' in type:
		gBhoe9AYT0nbdZDQGmfrL2pW,data = Oy2YNHPzuJl(url)
		MMYecLpZi6wfT9m3ju = int(data['limit'])
		start = int(data['start'])
		GQB0WzyICDK7mXxN2Acdi = data['type']
		select = data['select']
		Vi9fwvbSBCI0K6hgXA8EpFrT = 'limit='+str(MMYecLpZi6wfT9m3ju)+'&start='+str(start)+'&type='+GQB0WzyICDK7mXxN2Acdi+'&select='+select
		nJayb3s5zlOgQh9BwiCdEDq = {'Content-Type':'application/x-www-form-urlencoded'}
		vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'POST',gBhoe9AYT0nbdZDQGmfrL2pW,Vi9fwvbSBCI0K6hgXA8EpFrT,nJayb3s5zlOgQh9BwiCdEDq,HQmDERMFjx,HQmDERMFjx,'EGYBEST3-TITLES-1st')
		CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
		b3L20nx7qwHKTS6so = 'blocks'+CzNPJydxQLfw27tv4ZF8KORAbX5+'article'
	else:
		vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'EGYBEST3-TITLES-2nd')
		CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
		b3L20nx7qwHKTS6so = CzNPJydxQLfw27tv4ZF8KORAbX5
		code = DyVGS3dX0ZxR.findall("<script>(var.*?=.*?;var.*?=.*?;var.*?=.*?;var.*?=.*?;var.*?=.*?);</script>",CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if code:
			code = code[0].replace('var',HQmDERMFjx).replace(oQpxmKiRPlHeGsLXNrJF78O,HQmDERMFjx).replace("'",HQmDERMFjx).replace(';','&')
			RZ9V4eABCTfIO1FUrz2ks5DSwu,data = Oy2YNHPzuJl('?'+code)
			MMYecLpZi6wfT9m3ju = int(data['limit'])
			start = int(data['start'])
			GQB0WzyICDK7mXxN2Acdi = data['type']
			select = data['select']
			ubgQBzFtaLCkKU42MXZ96mefhjoip = data['ajaxurl']
			Vi9fwvbSBCI0K6hgXA8EpFrT = 'limit='+str(MMYecLpZi6wfT9m3ju)+'&start='+str(start)+'&type='+GQB0WzyICDK7mXxN2Acdi+'&select='+select
			gBhoe9AYT0nbdZDQGmfrL2pW = e2VR8nohduY+ubgQBzFtaLCkKU42MXZ96mefhjoip
			nJayb3s5zlOgQh9BwiCdEDq = {'Content-Type':'application/x-www-form-urlencoded'}
			vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'POST',gBhoe9AYT0nbdZDQGmfrL2pW,Vi9fwvbSBCI0K6hgXA8EpFrT,nJayb3s5zlOgQh9BwiCdEDq,HQmDERMFjx,HQmDERMFjx,'EGYBEST3-TITLES-3rd')
			b3L20nx7qwHKTS6so = vGXnw9VcUN.content
			b3L20nx7qwHKTS6so = 'blocks'+b3L20nx7qwHKTS6so+'article'
	items,ooMNC7KvzXqmsT2ke3JL9SIFi,Eya9L4IY3GxqtNoVWegDcPuOR = [],False,False
	if not type:
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('main-content(.*?)</div>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
			MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
			items = DyVGS3dX0ZxR.findall('href="(.*?)".*?</i>(.*?)</a>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
			for vn1grP3y4It9GmVuBbLJfz2A,title in items:
				title = title.strip(oQpxmKiRPlHeGsLXNrJF78O)
				CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,791,HQmDERMFjx,'submenu')
				ooMNC7KvzXqmsT2ke3JL9SIFi = True
	if not type:
		Eya9L4IY3GxqtNoVWegDcPuOR = gjwBnYN0zlFWVtGKfOocDA(CzNPJydxQLfw27tv4ZF8KORAbX5)
	if not ooMNC7KvzXqmsT2ke3JL9SIFi and not Eya9L4IY3GxqtNoVWegDcPuOR:
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('blocks(.*?)article',b3L20nx7qwHKTS6so,DyVGS3dX0ZxR.DOTALL)
		if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
			MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
			items = DyVGS3dX0ZxR.findall('href="(.*?)".*?src="(.*?)".*?class="title">(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
			for vn1grP3y4It9GmVuBbLJfz2A,uIGD4vZcP61QNmw78LXqoEpH,title in items:
				uIGD4vZcP61QNmw78LXqoEpH = uIGD4vZcP61QNmw78LXqoEpH.strip(ti3SbXNV0aJ7n5Grc4OQY8Ll1s9)
				vn1grP3y4It9GmVuBbLJfz2A = xx9LK4VzpF6IHXSEyhmrQwbg25P0(vn1grP3y4It9GmVuBbLJfz2A)
				if '/selary/' in vn1grP3y4It9GmVuBbLJfz2A: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,791,uIGD4vZcP61QNmw78LXqoEpH)
				elif 'مسلسل' in vn1grP3y4It9GmVuBbLJfz2A and 'حلقة' not in vn1grP3y4It9GmVuBbLJfz2A: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,796,uIGD4vZcP61QNmw78LXqoEpH)
				elif 'موسم' in vn1grP3y4It9GmVuBbLJfz2A and 'حلقة' not in vn1grP3y4It9GmVuBbLJfz2A: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,796,uIGD4vZcP61QNmw78LXqoEpH)
				else: CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,793,uIGD4vZcP61QNmw78LXqoEpH)
		NZIBEHr7ecQV6iSTfL4qKFdAUWn3xj = 12
		data = DyVGS3dX0ZxR.findall('class="(load-more.*?)<',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if len(items)==NZIBEHr7ecQV6iSTfL4qKFdAUWn3xj and (data or 'pagination' in type):
			Vi9fwvbSBCI0K6hgXA8EpFrT = 'limit='+str(NZIBEHr7ecQV6iSTfL4qKFdAUWn3xj)+'&start='+str(start+NZIBEHr7ecQV6iSTfL4qKFdAUWn3xj)+'&type='+GQB0WzyICDK7mXxN2Acdi+'&select='+select
			SSHjMN4uegZfb2 = gBhoe9AYT0nbdZDQGmfrL2pW+'?next=page&'+Vi9fwvbSBCI0K6hgXA8EpFrT
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'المزيد',SSHjMN4uegZfb2,791,HQmDERMFjx,'pagination_'+type)
	return
def gjwBnYN0zlFWVtGKfOocDA(CzNPJydxQLfw27tv4ZF8KORAbX5):
	Eya9L4IY3GxqtNoVWegDcPuOR = False
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('main-article(.*?)article',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		bUzHWnGg5t1 = DyVGS3dX0ZxR.findall('data-tax="(.*?)".*?<span>(.*?)<(.*?)</ul>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		if bUzHWnGg5t1: CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
		for WF2vkePC5gbXAGUarcqlpmB3Q,name,MJ2gSPyTl9hzoi1 in bUzHWnGg5t1:
			name = name.strip(oQpxmKiRPlHeGsLXNrJF78O)
			items = DyVGS3dX0ZxR.findall('href="(.*?)">(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
			for vn1grP3y4It9GmVuBbLJfz2A,value in items:
				title = name+':  '+value
				CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,791,HQmDERMFjx,'filter')
				Eya9L4IY3GxqtNoVWegDcPuOR = True
	return Eya9L4IY3GxqtNoVWegDcPuOR
def f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url):
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(rwjfOIqQU3ANa0JlWXvCDbFk,'GET',url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'EGYBEST3-PLAY-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	KWnAuJIFyESQHjP3X5xzMqUbR6L,QYDSpJHjizlW = [],[]
	items = DyVGS3dX0ZxR.findall('server-item.*?data-code="(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	for AGsEP4x3buSz9 in items:
		hTLI50Rg9ApYWyOodZ7v = x4aBluXo02G1eTPr9c.b64decode(AGsEP4x3buSz9)
		if HH6mxXjgcrEN1aenMFWQkS: hTLI50Rg9ApYWyOodZ7v = hTLI50Rg9ApYWyOodZ7v.decode(Zex6D4tJE52r)
		vn1grP3y4It9GmVuBbLJfz2A = DyVGS3dX0ZxR.findall('src="(.*?)"',hTLI50Rg9ApYWyOodZ7v,DyVGS3dX0ZxR.DOTALL)
		if vn1grP3y4It9GmVuBbLJfz2A:
			vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A[0]
			if vn1grP3y4It9GmVuBbLJfz2A not in QYDSpJHjizlW:
				QYDSpJHjizlW.append(vn1grP3y4It9GmVuBbLJfz2A)
				pYVvlGR1ES0gdtzayiDqb9w = DpClq35GVjh(vn1grP3y4It9GmVuBbLJfz2A,'name')
				KWnAuJIFyESQHjP3X5xzMqUbR6L.append(vn1grP3y4It9GmVuBbLJfz2A+'?named='+pYVvlGR1ES0gdtzayiDqb9w+'__watch')
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('class="downloads(.*?)</section>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('"tr flex-start".*?<div>[ a-zA-Z]*(\d{3,4})[ a-zA-Z]*</div>.*?href="(.*?)"',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for RRpfksr1PbZagwCIOJXYNHTo,vn1grP3y4It9GmVuBbLJfz2A in items:
			if vn1grP3y4It9GmVuBbLJfz2A not in QYDSpJHjizlW:
				if '/?url=' in vn1grP3y4It9GmVuBbLJfz2A: vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A.split('/?url=')[1]
				QYDSpJHjizlW.append(vn1grP3y4It9GmVuBbLJfz2A)
				pYVvlGR1ES0gdtzayiDqb9w = DpClq35GVjh(vn1grP3y4It9GmVuBbLJfz2A,'name')
				KWnAuJIFyESQHjP3X5xzMqUbR6L.append(vn1grP3y4It9GmVuBbLJfz2A+'?named='+pYVvlGR1ES0gdtzayiDqb9w+'__download____'+RRpfksr1PbZagwCIOJXYNHTo)
	import NsD5AomUqH
	NsD5AomUqH.NZcWGBmgFEen5hvJjUSIzOCVk7(KWnAuJIFyESQHjP3X5xzMqUbR6L,HDLtdMAy7wPkl8aKC3O2,'video',url)
	return
def hm4kawIPKp3oMrC75dJZA9HS2(text):
	return
# -*- coding: utf-8 -*-
from FF68kA5BUy import *
HDLtdMAy7wPkl8aKC3O2 = 'SHAHID4U2'
EEJvXQzSZNt = '_SH2_'
e2VR8nohduY = Jzthpc2nj5.SITESURLS[HDLtdMAy7wPkl8aKC3O2][0]
headers = {'User-Agent':xK7D9yiBPEqvhmA8XIoJe(True)}
FwhZ0nXtpoHTMarf = []
def kk6X5LxpsND(mode,url,text):
	if   mode==1090: zLZUkrP7ac5 = afkxo7FyZWB4O6K1eXrs5I()
	elif mode==1091: zLZUkrP7ac5 = c8wfGju4CWZm(url,text)
	elif mode==1092: zLZUkrP7ac5 = f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url)
	elif mode==1093: zLZUkrP7ac5 = XONC9osGSP4fW5HVrhM(url,text)
	elif mode==1094: zLZUkrP7ac5 = ooxUXkcTj5PF4ad2SwYy(url,'FULL_FILTER___'+text)
	elif mode==1095: zLZUkrP7ac5 = ooxUXkcTj5PF4ad2SwYy(url,'DEFINED_FILTER___'+text)
	elif mode==1099: zLZUkrP7ac5 = hm4kawIPKp3oMrC75dJZA9HS2(text)
	else: zLZUkrP7ac5 = False
	return zLZUkrP7ac5
def afkxo7FyZWB4O6K1eXrs5I():
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',e2VR8nohduY,HQmDERMFjx,headers,HQmDERMFjx,HQmDERMFjx,'SHAHID4U2-MENU-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	EFDgdaV4WT6U2yotAPX1B = DpClq35GVjh(vGXnw9VcUN.url,'url')
	if C6H1qXua3SMQiIrzxNvJWZE: EFDgdaV4WT6U2yotAPX1B = EFDgdaV4WT6U2yotAPX1B.encode(Zex6D4tJE52r)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'بحث في الموقع',HQmDERMFjx,1099,HQmDERMFjx,HQmDERMFjx,'_REMEMBERRESULTS_')
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'فلتر محدد',EFDgdaV4WT6U2yotAPX1B,1095)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'فلتر كامل',EFDgdaV4WT6U2yotAPX1B,1094)
	CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'المميزة',EFDgdaV4WT6U2yotAPX1B,1091,HQmDERMFjx,HQmDERMFjx,'featured')
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"main-menu"(.*?)</div>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('href="(.*?)".*?>(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,title in items:
			title = title.replace(ti3SbXNV0aJ7n5Grc4OQY8Ll1s9,HQmDERMFjx).replace(GsgOT5Vp6UzIy87bh4vQBWdNjAX3c1,HQmDERMFjx).strip(oQpxmKiRPlHeGsLXNrJF78O)
			if title in FwhZ0nXtpoHTMarf: continue
			if 'http' not in vn1grP3y4It9GmVuBbLJfz2A: vn1grP3y4It9GmVuBbLJfz2A = EFDgdaV4WT6U2yotAPX1B+vn1grP3y4It9GmVuBbLJfz2A
			if 'netflix' in vn1grP3y4It9GmVuBbLJfz2A: title = 'نيتفلكس'
			CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,1091)
	return CzNPJydxQLfw27tv4ZF8KORAbX5
def c8wfGju4CWZm(url,KPloNJnsZ2kpHhum1=HQmDERMFjx,vGXnw9VcUN=HQmDERMFjx):
	if not vGXnw9VcUN: vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,headers,HQmDERMFjx,HQmDERMFjx,'SHAHID4U2-TITLES-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1,items,ORMkTYjJ1p7 = [],[],[]
	if KPloNJnsZ2kpHhum1=='featured': Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"Slides--Main"(.*?)"filterTabs"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	else: Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"BlocksHolder"(.*?)"pagination"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if not Ut7reR0XioMjOdYWZKsLIuc3TQJmC1: return
	MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	items = DyVGS3dX0ZxR.findall('href="(.*?)".*?title="(.*?)".*?data-src="(.*?)"',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	smLQwgO0BynVCcl3fYJ = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for vn1grP3y4It9GmVuBbLJfz2A,title,uIGD4vZcP61QNmw78LXqoEpH in items:
		if 'WWE' in title: continue
		if 'javascript' in vn1grP3y4It9GmVuBbLJfz2A: continue
		if 'http' not in vn1grP3y4It9GmVuBbLJfz2A: vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+vn1grP3y4It9GmVuBbLJfz2A
		title = SVsiEWeRf6oIynqQx8pCrM4Tk(title)
		title = title.strip(oQpxmKiRPlHeGsLXNrJF78O)
		yTz8SOkAhu24j6apo9BmZHvwWsX = DyVGS3dX0ZxR.findall('(.*?) الحلقة \d+',title,DyVGS3dX0ZxR.DOTALL)
		if '/film/' in vn1grP3y4It9GmVuBbLJfz2A or 'فيلم' in vn1grP3y4It9GmVuBbLJfz2A or any(value in title for value in smLQwgO0BynVCcl3fYJ):
			CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,1092,uIGD4vZcP61QNmw78LXqoEpH)
		elif yTz8SOkAhu24j6apo9BmZHvwWsX and 'الحلقة' in title and '/list' not in url:
			title = '_MOD_' + yTz8SOkAhu24j6apo9BmZHvwWsX[0]
			if title not in ORMkTYjJ1p7:
				CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,1093,uIGD4vZcP61QNmw78LXqoEpH)
				ORMkTYjJ1p7.append(title)
		elif '/actor/' in vn1grP3y4It9GmVuBbLJfz2A:
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,1091,uIGD4vZcP61QNmw78LXqoEpH)
		elif '/series/' in vn1grP3y4It9GmVuBbLJfz2A and '/list' not in url:
			vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A+'/list'
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,1091,uIGD4vZcP61QNmw78LXqoEpH)
		elif '/list' in url and 'حلقة' in title:
			CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,1092,uIGD4vZcP61QNmw78LXqoEpH)
		else: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,1093,uIGD4vZcP61QNmw78LXqoEpH)
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"pagination"(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 and not KPloNJnsZ2kpHhum1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('<li>.*?href="(.*?)">(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,title in items:
			title = SVsiEWeRf6oIynqQx8pCrM4Tk(title)
			if title: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'صفحة '+title,vn1grP3y4It9GmVuBbLJfz2A,1091,HQmDERMFjx,HQmDERMFjx,KPloNJnsZ2kpHhum1)
	return
def XONC9osGSP4fW5HVrhM(url,JlVmvgFsdA2rCODPK0WIo):
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,headers,HQmDERMFjx,HQmDERMFjx,'SHAHID4U2-EPISODES-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('class="w-100(.*?)</div>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if not Ut7reR0XioMjOdYWZKsLIuc3TQJmC1: Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('class="EpisodesList"(.*?)</div>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		Zg2cj61zKT0JGeq5US3IVCnYhE = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[o4bNzIQGYj8En]
		xc7wost1eGJHFyf2kYOhX = Zg2cj61zKT0JGeq5US3IVCnYhE.count('/season/')+Zg2cj61zKT0JGeq5US3IVCnYhE.count('/series/')
		bBWjkFQJvqS5201Ouyi9ofMecsUCr4 = Zg2cj61zKT0JGeq5US3IVCnYhE.count('href')-xc7wost1eGJHFyf2kYOhX
		if len(Ut7reR0XioMjOdYWZKsLIuc3TQJmC1)==FFHRwuxQmbh8BaTqyX3:
			WW4miR8cv6AEJQ7IyGes = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[CH7RKuDVzN9f06q8MtXPhlvIxakEWg]
			y0bz7ZCxgFuveKoS = WW4miR8cv6AEJQ7IyGes.count('/season/')+WW4miR8cv6AEJQ7IyGes.count('/series/')
			k2Fh9obfeu5WO8AXmGE1ys = WW4miR8cv6AEJQ7IyGes.count('href=')-y0bz7ZCxgFuveKoS
		else: WW4miR8cv6AEJQ7IyGes,y0bz7ZCxgFuveKoS,k2Fh9obfeu5WO8AXmGE1ys = HQmDERMFjx,o4bNzIQGYj8En,o4bNzIQGYj8En
		MJ2gSPyTl9hzoi1 = HQmDERMFjx
		if not JlVmvgFsdA2rCODPK0WIo:
			if xc7wost1eGJHFyf2kYOhX>CH7RKuDVzN9f06q8MtXPhlvIxakEWg: MJ2gSPyTl9hzoi1 = Zg2cj61zKT0JGeq5US3IVCnYhE
			elif y0bz7ZCxgFuveKoS>CH7RKuDVzN9f06q8MtXPhlvIxakEWg: MJ2gSPyTl9hzoi1 = WW4miR8cv6AEJQ7IyGes
		if not MJ2gSPyTl9hzoi1:
			if bBWjkFQJvqS5201Ouyi9ofMecsUCr4: MJ2gSPyTl9hzoi1 = Zg2cj61zKT0JGeq5US3IVCnYhE
			elif k2Fh9obfeu5WO8AXmGE1ys: MJ2gSPyTl9hzoi1 = WW4miR8cv6AEJQ7IyGes
		items = DyVGS3dX0ZxR.findall('href="(.*?)".*?<span>(.*?)<.*?<em>(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,Uo6C7vBYqD9uOS,eyLMq9Enup0jiJT42RDWafg in items:
			title = Uo6C7vBYqD9uOS+oQpxmKiRPlHeGsLXNrJF78O+eyLMq9Enup0jiJT42RDWafg
			if '/season/' not in vn1grP3y4It9GmVuBbLJfz2A and '/series/' not in vn1grP3y4It9GmVuBbLJfz2A: CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,1092)
			else: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,1093,HQmDERMFjx,HQmDERMFjx,'season')
	return
def f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url):
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(H5x4Z2qPwR8vXM,'GET',url,HQmDERMFjx,headers,HQmDERMFjx,HQmDERMFjx,'SHAHID4U2-PLAY-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	KWnAuJIFyESQHjP3X5xzMqUbR6L,QYDSpJHjizlW = [],[]
	wwmEVad1obxMSBXick2zI8qnRpr = DyVGS3dX0ZxR.findall('class="watch" href="(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	otP07csEQAmMKal = DyVGS3dX0ZxR.findall('class="download" href="(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if wwmEVad1obxMSBXick2zI8qnRpr:
		wwmEVad1obxMSBXick2zI8qnRpr = wwmEVad1obxMSBXick2zI8qnRpr[0].replace(mKqAOsD5p0C,xufJqQcGnhboiVy2wd).replace(':/','://').rstrip(xufJqQcGnhboiVy2wd)+xufJqQcGnhboiVy2wd
		vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(H5x4Z2qPwR8vXM,'GET',wwmEVad1obxMSBXick2zI8qnRpr,HQmDERMFjx,headers,HQmDERMFjx,HQmDERMFjx,'SHAHID4U2-PLAY-2nd')
		CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"watch"(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL|DyVGS3dX0ZxR.IGNORECASE)
		if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
			MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
			items = DyVGS3dX0ZxR.findall('data-watch="(.*?)".*?</i>(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
			for vn1grP3y4It9GmVuBbLJfz2A,title in items:
				if vn1grP3y4It9GmVuBbLJfz2A in QYDSpJHjizlW: continue
				vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A+'?named='+title+'__watch'
				KWnAuJIFyESQHjP3X5xzMqUbR6L.append(vn1grP3y4It9GmVuBbLJfz2A)
				QYDSpJHjizlW.append(vn1grP3y4It9GmVuBbLJfz2A)
	if otP07csEQAmMKal:
		otP07csEQAmMKal = otP07csEQAmMKal[0].replace(mKqAOsD5p0C,xufJqQcGnhboiVy2wd).replace(':/','://').rstrip(xufJqQcGnhboiVy2wd)+xufJqQcGnhboiVy2wd
		vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(H5x4Z2qPwR8vXM,'GET',otP07csEQAmMKal,HQmDERMFjx,headers,HQmDERMFjx,HQmDERMFjx,'SHAHID4U2-PLAY-3rd')
		CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"DownList"(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL|DyVGS3dX0ZxR.IGNORECASE)
		if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
			MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
			items = DyVGS3dX0ZxR.findall('href="(.*?)".*?<quality>(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
			for vn1grP3y4It9GmVuBbLJfz2A,title in items:
				if vn1grP3y4It9GmVuBbLJfz2A in QYDSpJHjizlW: continue
				vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A+'?named='+title+'__download'
				KWnAuJIFyESQHjP3X5xzMqUbR6L.append(vn1grP3y4It9GmVuBbLJfz2A)
				QYDSpJHjizlW.append(vn1grP3y4It9GmVuBbLJfz2A)
	import NsD5AomUqH
	NsD5AomUqH.NZcWGBmgFEen5hvJjUSIzOCVk7(KWnAuJIFyESQHjP3X5xzMqUbR6L,HDLtdMAy7wPkl8aKC3O2,'video',url)
	return
def hm4kawIPKp3oMrC75dJZA9HS2(search):
	search,GXVabd4sc2u3zp0JI,showDialogs = x0pzMENwy84tBcZvXr(search)
	if not search:
		search = q156m84QoYrn()
		if not search: return
	search = search.replace(oQpxmKiRPlHeGsLXNrJF78O,'+')
	url = e2VR8nohduY+'/?s='+search
	c8wfGju4CWZm(url,'search')
	return
def Fhzowv4lbkLBY(url):
	url = url.split('/smartemadfilter?')[0]
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(H5x4Z2qPwR8vXM,'GET',url,HQmDERMFjx,headers,HQmDERMFjx,HQmDERMFjx,'SHAHID4U2-GET_FILTERS_BLOCKS-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	jnPZuGqg9F5viBUp = []
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('adv-filter(.*?)shows-container',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		jnPZuGqg9F5viBUp = DyVGS3dX0ZxR.findall('''updateQuery\('(.*?)'.*?value.*?>(.*?)<(.*?)</select''',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		PPxLnY9KDefQulFd5C8vU,szxwkVQTmqev0jGiK78HJIbN4uDOd,bUzHWnGg5t1 = zip(*jnPZuGqg9F5viBUp)
		jnPZuGqg9F5viBUp = zip(szxwkVQTmqev0jGiK78HJIbN4uDOd,PPxLnY9KDefQulFd5C8vU,bUzHWnGg5t1)
	return jnPZuGqg9F5viBUp
def jfcC3ErztgW9dw(MJ2gSPyTl9hzoi1):
	items = DyVGS3dX0ZxR.findall('value="(.*?)".*?>\s*(.*?)\s*<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	return items
def gghkponM41G6TdLBsrS3(url):
	if '/smartemadfilter?' not in url: url = url+'/smartemadfilter?'
	Fewh9HDYiA7jJWS5c6dgr = url.split('/smartemadfilter?')[0]
	EdxGKyuW1mvZSBDf0o947h8Rik = DpClq35GVjh(url,'url')
	url = url.replace(Fewh9HDYiA7jJWS5c6dgr,EdxGKyuW1mvZSBDf0o947h8Rik)
	url = url.replace('/smartemadfilter?','/?')
	return url
XXC6FzPWVjQnMEldGeTLwpxD = ['quality','year','genre','category']
PydiDZOp6H = ['category','genre','year']
def ooxUXkcTj5PF4ad2SwYy(url,filter):
	url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==HQmDERMFjx: eA0pnTuMvxrdmoRC9zPBh,mwhEr8eXxD21MAKfHUSlB = HQmDERMFjx,HQmDERMFjx
	else: eA0pnTuMvxrdmoRC9zPBh,mwhEr8eXxD21MAKfHUSlB = filter.split('___')
	if type=='DEFINED_FILTER':
		if PydiDZOp6H[0]+'=' not in eA0pnTuMvxrdmoRC9zPBh: WF2vkePC5gbXAGUarcqlpmB3Q = PydiDZOp6H[0]
		for yuYts1RONXgp in range(len(PydiDZOp6H[0:-1])):
			if PydiDZOp6H[yuYts1RONXgp]+'=' in eA0pnTuMvxrdmoRC9zPBh: WF2vkePC5gbXAGUarcqlpmB3Q = PydiDZOp6H[yuYts1RONXgp+1]
		Cm5jWJgr28TlUnoZYHAxdPI3OB = eA0pnTuMvxrdmoRC9zPBh+'&'+WF2vkePC5gbXAGUarcqlpmB3Q+'=0'
		RRDtwVh6LbFiEycHNQkId5Cefmq = mwhEr8eXxD21MAKfHUSlB+'&'+WF2vkePC5gbXAGUarcqlpmB3Q+'=0'
		GSPtdslyxQURmB5obg69VJMY1jE = Cm5jWJgr28TlUnoZYHAxdPI3OB.strip('&')+'___'+RRDtwVh6LbFiEycHNQkId5Cefmq.strip('&')
		J4asIxU7Zyq5PiN2rKEctegFV = jlZtWwMfosJFIKenicqU1(mwhEr8eXxD21MAKfHUSlB,'modified_filters')
		SSHjMN4uegZfb2 = url+'/smartemadfilter?'+J4asIxU7Zyq5PiN2rKEctegFV
	elif type=='FULL_FILTER':
		v2s9V6uhIT0aCjkPOl7iUqZxB = jlZtWwMfosJFIKenicqU1(eA0pnTuMvxrdmoRC9zPBh,'modified_values')
		v2s9V6uhIT0aCjkPOl7iUqZxB = xx9LK4VzpF6IHXSEyhmrQwbg25P0(v2s9V6uhIT0aCjkPOl7iUqZxB)
		if mwhEr8eXxD21MAKfHUSlB!=HQmDERMFjx: mwhEr8eXxD21MAKfHUSlB = jlZtWwMfosJFIKenicqU1(mwhEr8eXxD21MAKfHUSlB,'modified_filters')
		if mwhEr8eXxD21MAKfHUSlB==HQmDERMFjx: SSHjMN4uegZfb2 = url
		else: SSHjMN4uegZfb2 = url+'/smartemadfilter?'+mwhEr8eXxD21MAKfHUSlB
		jDcWv7MAkEV = gghkponM41G6TdLBsrS3(SSHjMN4uegZfb2)
		CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'أظهار قائمة الفيديو التي تم اختيارها ',jDcWv7MAkEV,1091)
		CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+' [[   '+v2s9V6uhIT0aCjkPOl7iUqZxB+'   ]]',jDcWv7MAkEV,1091)
		CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	jnPZuGqg9F5viBUp = Fhzowv4lbkLBY(url)
	dict = {}
	for name,DcpbqKxWsJRCSVkQyjf1,MJ2gSPyTl9hzoi1 in jnPZuGqg9F5viBUp:
		name = name.replace('كل ',HQmDERMFjx)
		items = jfcC3ErztgW9dw(MJ2gSPyTl9hzoi1)
		if '=' not in SSHjMN4uegZfb2: SSHjMN4uegZfb2 = url
		if type=='DEFINED_FILTER':
			if WF2vkePC5gbXAGUarcqlpmB3Q!=DcpbqKxWsJRCSVkQyjf1: continue
			elif len(items)<2:
				if DcpbqKxWsJRCSVkQyjf1==PydiDZOp6H[-1]:
					jDcWv7MAkEV = gghkponM41G6TdLBsrS3(SSHjMN4uegZfb2)
					c8wfGju4CWZm(jDcWv7MAkEV)
				else: ooxUXkcTj5PF4ad2SwYy(SSHjMN4uegZfb2,'DEFINED_FILTER___'+GSPtdslyxQURmB5obg69VJMY1jE)
				return
			else:
				if DcpbqKxWsJRCSVkQyjf1==PydiDZOp6H[-1]:
					jDcWv7MAkEV = gghkponM41G6TdLBsrS3(SSHjMN4uegZfb2)
					CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'الجميع',jDcWv7MAkEV,1091)
				else: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'الجميع',SSHjMN4uegZfb2,1095,HQmDERMFjx,HQmDERMFjx,GSPtdslyxQURmB5obg69VJMY1jE)
		elif type=='FULL_FILTER':
			Cm5jWJgr28TlUnoZYHAxdPI3OB = eA0pnTuMvxrdmoRC9zPBh+'&'+DcpbqKxWsJRCSVkQyjf1+'=0'
			RRDtwVh6LbFiEycHNQkId5Cefmq = mwhEr8eXxD21MAKfHUSlB+'&'+DcpbqKxWsJRCSVkQyjf1+'=0'
			GSPtdslyxQURmB5obg69VJMY1jE = Cm5jWJgr28TlUnoZYHAxdPI3OB+'___'+RRDtwVh6LbFiEycHNQkId5Cefmq
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'الجميع :'+name,SSHjMN4uegZfb2,1094,HQmDERMFjx,HQmDERMFjx,GSPtdslyxQURmB5obg69VJMY1jE)
		dict[DcpbqKxWsJRCSVkQyjf1] = {}
		for value,yewoKb5dkfHu1xEZMAsY in items:
			if value=='196533': yewoKb5dkfHu1xEZMAsY = 'أفلام نيتفلكس'
			elif value=='196531': yewoKb5dkfHu1xEZMAsY = 'مسلسلات نيتفلكس'
			if yewoKb5dkfHu1xEZMAsY in FwhZ0nXtpoHTMarf: continue
			dict[DcpbqKxWsJRCSVkQyjf1][value] = yewoKb5dkfHu1xEZMAsY
			Cm5jWJgr28TlUnoZYHAxdPI3OB = eA0pnTuMvxrdmoRC9zPBh+'&'+DcpbqKxWsJRCSVkQyjf1+'='+yewoKb5dkfHu1xEZMAsY
			RRDtwVh6LbFiEycHNQkId5Cefmq = mwhEr8eXxD21MAKfHUSlB+'&'+DcpbqKxWsJRCSVkQyjf1+'='+value
			CEniUGWr4jMy = Cm5jWJgr28TlUnoZYHAxdPI3OB+'___'+RRDtwVh6LbFiEycHNQkId5Cefmq
			title = yewoKb5dkfHu1xEZMAsY+' :'#+dict[DcpbqKxWsJRCSVkQyjf1]['0']
			title = yewoKb5dkfHu1xEZMAsY+' :'+name
			if type=='FULL_FILTER': CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,url,1094,HQmDERMFjx,HQmDERMFjx,CEniUGWr4jMy)
			elif type=='DEFINED_FILTER' and PydiDZOp6H[-2]+'=' in eA0pnTuMvxrdmoRC9zPBh:
				J4asIxU7Zyq5PiN2rKEctegFV = jlZtWwMfosJFIKenicqU1(RRDtwVh6LbFiEycHNQkId5Cefmq,'modified_filters')
				SSHjMN4uegZfb2 = url+'/smartemadfilter?'+J4asIxU7Zyq5PiN2rKEctegFV
				jDcWv7MAkEV = gghkponM41G6TdLBsrS3(SSHjMN4uegZfb2)
				CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,jDcWv7MAkEV,1091)
			else: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,url,1095,HQmDERMFjx,HQmDERMFjx,CEniUGWr4jMy)
	return
def jlZtWwMfosJFIKenicqU1(Eya9L4IY3GxqtNoVWegDcPuOR,mode):
	Eya9L4IY3GxqtNoVWegDcPuOR = Eya9L4IY3GxqtNoVWegDcPuOR.replace('=&','=0&')
	Eya9L4IY3GxqtNoVWegDcPuOR = Eya9L4IY3GxqtNoVWegDcPuOR.strip('&')
	AAwtDoF34Y890RXse = {}
	if '=' in Eya9L4IY3GxqtNoVWegDcPuOR:
		items = Eya9L4IY3GxqtNoVWegDcPuOR.split('&')
		for A07BpVeRJToLb in items:
			airVhHdqCb6Gf49eERSjv1,value = A07BpVeRJToLb.split('=')
			AAwtDoF34Y890RXse[airVhHdqCb6Gf49eERSjv1] = value
	n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6 = HQmDERMFjx
	for key in XXC6FzPWVjQnMEldGeTLwpxD:
		if key in list(AAwtDoF34Y890RXse.keys()): value = AAwtDoF34Y890RXse[key]
		else: value = '0'
		if '%' not in value: value = VVkOtyQLzxBr(value)
		if mode=='modified_values' and value!='0': n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6 = n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6+' + '+value
		elif mode=='modified_filters' and value!='0': n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6 = n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6+'&'+key+'='+value
		elif mode=='all': n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6 = n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6+'&'+key+'='+value
	n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6 = n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6.strip(' + ')
	n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6 = n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6.strip('&')
	n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6 = n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6.replace('=0','=')
	return n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6
# -*- coding: utf-8 -*-
from FF68kA5BUy import *
HDLtdMAy7wPkl8aKC3O2 = 'BOKRA'
EEJvXQzSZNt = '_BKR_'
e2VR8nohduY = Jzthpc2nj5.SITESURLS[HDLtdMAy7wPkl8aKC3O2][0]
headers = {'User-Agent':HQmDERMFjx}
FwhZ0nXtpoHTMarf = ['افلام للكبار','بكرا TV']
def kk6X5LxpsND(mode,url,text):
	if   mode==370: zLZUkrP7ac5 = afkxo7FyZWB4O6K1eXrs5I()
	elif mode==371: zLZUkrP7ac5 = c8wfGju4CWZm(url,text)
	elif mode==372: zLZUkrP7ac5 = f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url)
	elif mode==374: zLZUkrP7ac5 = eFRlq25sJYPMhv9OoSaLiBw0WA(url)
	elif mode==375: zLZUkrP7ac5 = iE29B4W0VOlwuytoFxT(url)
	elif mode==376: zLZUkrP7ac5 = pNVvfkArnBwqi97hLH16E04JKy(0,url)
	elif mode==377: zLZUkrP7ac5 = pNVvfkArnBwqi97hLH16E04JKy(1,url)
	elif mode==379: zLZUkrP7ac5 = hm4kawIPKp3oMrC75dJZA9HS2(text)
	else: zLZUkrP7ac5 = False
	return zLZUkrP7ac5
def afkxo7FyZWB4O6K1eXrs5I():
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(H5x4Z2qPwR8vXM,'GET',e2VR8nohduY,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'BOKRA-MENU-1st')
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'بحث في الموقع',HQmDERMFjx,379,HQmDERMFjx,HQmDERMFjx,'_REMEMBERRESULTS_')
	CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('right-side(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('href="(.*?)">(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,title in items:
			vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+vn1grP3y4It9GmVuBbLJfz2A
			if not any(value in title for value in FwhZ0nXtpoHTMarf):
				CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,371)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+'المميزة',e2VR8nohduY,375)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+'الأحدث',e2VR8nohduY,376)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+'قائمة الممثلين',e2VR8nohduY,374)
	CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('class="container"(.*?)top-menu',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('href="(.*?)">(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,title in items[7:]:
			title = title.strip(oQpxmKiRPlHeGsLXNrJF78O)
			vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+vn1grP3y4It9GmVuBbLJfz2A
			if not any(value in title for value in FwhZ0nXtpoHTMarf):
				CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,371)
		for vn1grP3y4It9GmVuBbLJfz2A,title in items[0:7]:
			title = title.strip(oQpxmKiRPlHeGsLXNrJF78O)
			vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+vn1grP3y4It9GmVuBbLJfz2A
			if not any(value in title for value in FwhZ0nXtpoHTMarf):
				CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,371)
	return
def eFRlq25sJYPMhv9OoSaLiBw0WA(website=HQmDERMFjx):
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(H5x4Z2qPwR8vXM,'GET',e2VR8nohduY,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'BOKRA-ACTORSMENU-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('class="row cat Tags"(.*?)</div>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('href="([^"]*)" title="([^"]*)"',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,title in items:
			if 'http' in vn1grP3y4It9GmVuBbLJfz2A: continue
			else: vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+vn1grP3y4It9GmVuBbLJfz2A
			if not any(value in title for value in FwhZ0nXtpoHTMarf):
				CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,371)
	return
def iE29B4W0VOlwuytoFxT(website=HQmDERMFjx):
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(LLwINhcX2RHSWqpmEnz,'GET',e2VR8nohduY,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'BOKRA-FEATURED-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"MainContent"(.*?)main-title2',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('href="(/vidpage_.*?)".*? src="(.*?)".*?<h3>(.*?)</h3>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,uIGD4vZcP61QNmw78LXqoEpH,title in items:
			vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+vn1grP3y4It9GmVuBbLJfz2A
			if not any(value in title for value in FwhZ0nXtpoHTMarf):
				uIGD4vZcP61QNmw78LXqoEpH = uIGD4vZcP61QNmw78LXqoEpH.replace('://',':///').replace(mKqAOsD5p0C,xufJqQcGnhboiVy2wd).replace(oQpxmKiRPlHeGsLXNrJF78O,'%20')
				CfgK4s13Q0hZcHyleT2bVJO9('video',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,372,uIGD4vZcP61QNmw78LXqoEpH)
	return
def pNVvfkArnBwqi97hLH16E04JKy(id,website=HQmDERMFjx):
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(LLwINhcX2RHSWqpmEnz,'GET',e2VR8nohduY,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'BOKRA-WATCHINGNOW-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('main-title2(.*?)class="row',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[id]
		items = DyVGS3dX0ZxR.findall('href="(.*?)".*? src="(.*?)".*?<h4>(.*?)</h4>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,uIGD4vZcP61QNmw78LXqoEpH,title in items:
			vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+vn1grP3y4It9GmVuBbLJfz2A
			if not any(value in title for value in FwhZ0nXtpoHTMarf):
				uIGD4vZcP61QNmw78LXqoEpH = uIGD4vZcP61QNmw78LXqoEpH.replace('://',':///').replace(mKqAOsD5p0C,xufJqQcGnhboiVy2wd).replace(oQpxmKiRPlHeGsLXNrJF78O,'%20')
				CfgK4s13Q0hZcHyleT2bVJO9('video',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,372,uIGD4vZcP61QNmw78LXqoEpH)
	return
def c8wfGju4CWZm(url,Wzvw6c4Yu2=HQmDERMFjx):
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'BOKRA-TITLES-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	if 'vidpage_' in url:
		vn1grP3y4It9GmVuBbLJfz2A = DyVGS3dX0ZxR.findall('href="(/Album-.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if vn1grP3y4It9GmVuBbLJfz2A:
			vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+vn1grP3y4It9GmVuBbLJfz2A[0]
			c8wfGju4CWZm(vn1grP3y4It9GmVuBbLJfz2A)
			return
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('class=" subcats"(.*?)class="col-md-3',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Wzvw6c4Yu2==HQmDERMFjx and Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 and Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0].count('href')>1:
		CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'الجميع',url,371,HQmDERMFjx,HQmDERMFjx,'titles')
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('href="([^"]*)" title="([^"]*)"',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,title in items:
			vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+xufJqQcGnhboiVy2wd+vn1grP3y4It9GmVuBbLJfz2A
			title = title.strip(oQpxmKiRPlHeGsLXNrJF78O)
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,371)
	else:
		ORMkTYjJ1p7 = []
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('class="col-md-3(.*?)col-xs-12',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if not Ut7reR0XioMjOdYWZKsLIuc3TQJmC1: Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('class="col-sm-8"(.*?)col-xs-12',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
			MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
			items = DyVGS3dX0ZxR.findall('href="(.*?)".*?src="(.*?)".*?<h4>(.*?)</h4>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
			for vn1grP3y4It9GmVuBbLJfz2A,uIGD4vZcP61QNmw78LXqoEpH,title in items:
				vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+vn1grP3y4It9GmVuBbLJfz2A
				title = title.strip(oQpxmKiRPlHeGsLXNrJF78O)
				uIGD4vZcP61QNmw78LXqoEpH = uIGD4vZcP61QNmw78LXqoEpH.replace('://',':///').replace(mKqAOsD5p0C,xufJqQcGnhboiVy2wd).replace(oQpxmKiRPlHeGsLXNrJF78O,'%20')
				if '/al_' in vn1grP3y4It9GmVuBbLJfz2A:
					CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,371,uIGD4vZcP61QNmw78LXqoEpH)
				elif 'الحلقة' in title and ('/Cat-' in url or '/Search/' in url):
					yTz8SOkAhu24j6apo9BmZHvwWsX = DyVGS3dX0ZxR.findall('(.*?) - +الحلقة +\d+',title,DyVGS3dX0ZxR.DOTALL)
					if yTz8SOkAhu24j6apo9BmZHvwWsX: title = '_MOD_مسلسل '+yTz8SOkAhu24j6apo9BmZHvwWsX[0]
					if title not in ORMkTYjJ1p7:
						ORMkTYjJ1p7.append(title)
						CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,371,uIGD4vZcP61QNmw78LXqoEpH)
				else: CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,372,uIGD4vZcP61QNmw78LXqoEpH)
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('class="pagination(.*?)</div>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
			MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
			items = DyVGS3dX0ZxR.findall('class="".*?href="(.*?)">(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
			for vn1grP3y4It9GmVuBbLJfz2A,title in items:
				vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+vn1grP3y4It9GmVuBbLJfz2A
				title = 'صفحة '+SVsiEWeRf6oIynqQx8pCrM4Tk(title)
				CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,371,HQmDERMFjx,HQmDERMFjx,'titles')
	return
def f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url):
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(LLwINhcX2RHSWqpmEnz,'GET',url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'BOKRA-PLAY-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	WWbJG6CrUL4tIRsjpNV = DyVGS3dX0ZxR.findall('label-success mrg-btm-5 ">(.*?)<',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if WWbJG6CrUL4tIRsjpNV and UzSYuZp3Pnhf1W4wyx7Fc0JX6jNb(HDLtdMAy7wPkl8aKC3O2,url,WWbJG6CrUL4tIRsjpNV): return
	jDcWv7MAkEV = HQmDERMFjx
	SSHjMN4uegZfb2 = DyVGS3dX0ZxR.findall('var url = "(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if SSHjMN4uegZfb2: SSHjMN4uegZfb2 = SSHjMN4uegZfb2[0]
	else: SSHjMN4uegZfb2 = url.replace('/vidpage_','/Play/')
	if 'http' not in SSHjMN4uegZfb2: SSHjMN4uegZfb2 = e2VR8nohduY+SSHjMN4uegZfb2
	SSHjMN4uegZfb2 = SSHjMN4uegZfb2.strip('-')
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(SwvFqCI7sc6bTAoeZY,'GET',SSHjMN4uegZfb2,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'BOKRA-PLAY-2nd')
	b3L20nx7qwHKTS6so = vGXnw9VcUN.content
	jDcWv7MAkEV = DyVGS3dX0ZxR.findall('src="(.*?)"',b3L20nx7qwHKTS6so,DyVGS3dX0ZxR.DOTALL)
	if jDcWv7MAkEV:
		jDcWv7MAkEV = jDcWv7MAkEV[-1]
		if 'http' not in jDcWv7MAkEV: jDcWv7MAkEV = 'http:'+jDcWv7MAkEV
		if '/PLAY/' not in SSHjMN4uegZfb2:
			if 'embed.min.js' in jDcWv7MAkEV:
				qqvmoiFXgRBC40k6SceZIuJO = DyVGS3dX0ZxR.findall('data-publisher-id="(.*?)" data-video-id="(.*?)"',b3L20nx7qwHKTS6so,DyVGS3dX0ZxR.DOTALL)
				if qqvmoiFXgRBC40k6SceZIuJO:
					mmgZiGshBkn23VFpjDcfTWauAMq8, RRhcKzPWdNiSDMbfIBF = qqvmoiFXgRBC40k6SceZIuJO[0]
					jDcWv7MAkEV = DpClq35GVjh(jDcWv7MAkEV,'url')+'/v2/'+mmgZiGshBkn23VFpjDcfTWauAMq8+'/config/'+RRhcKzPWdNiSDMbfIBF+'.json'
		import NsD5AomUqH
		NsD5AomUqH.NZcWGBmgFEen5hvJjUSIzOCVk7([jDcWv7MAkEV],HDLtdMAy7wPkl8aKC3O2,'video',url)
	return
def hm4kawIPKp3oMrC75dJZA9HS2(search):
	search,GXVabd4sc2u3zp0JI,showDialogs = x0pzMENwy84tBcZvXr(search)
	if search==HQmDERMFjx: search = q156m84QoYrn()
	if search==HQmDERMFjx: return
	search = search.replace(oQpxmKiRPlHeGsLXNrJF78O,'+')
	url = e2VR8nohduY+'/Search/'+search
	c8wfGju4CWZm(url)
	return
# -*- coding: utf-8 -*-
from FF68kA5BUy import *
HDLtdMAy7wPkl8aKC3O2 = 'ARABICTOONS'
EEJvXQzSZNt = '_ART_'
e2VR8nohduY = Jzthpc2nj5.SITESURLS[HDLtdMAy7wPkl8aKC3O2][0]
def kk6X5LxpsND(mode,url,text):
	if   mode==730: zLZUkrP7ac5 = afkxo7FyZWB4O6K1eXrs5I()
	elif mode==731: zLZUkrP7ac5 = c8wfGju4CWZm(url,text)
	elif mode==732: zLZUkrP7ac5 = f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url)
	elif mode==733: zLZUkrP7ac5 = XONC9osGSP4fW5HVrhM(url)
	elif mode==734: zLZUkrP7ac5 = QQYk3Rmcx0l9D6JoTuyZHMSCzAes7(url)
	elif mode==735: zLZUkrP7ac5 = jovtJXBwzSK0U953G(url)
	elif mode==739: zLZUkrP7ac5 = hm4kawIPKp3oMrC75dJZA9HS2(text)
	else: zLZUkrP7ac5 = False
	return zLZUkrP7ac5
def afkxo7FyZWB4O6K1eXrs5I():
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'بحث في الموقع',HQmDERMFjx,739,HQmDERMFjx,HQmDERMFjx,'_REMEMBERRESULTS_')
	CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+'افلام',e2VR8nohduY+'/movies.php',731)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+'مسلسلات',e2VR8nohduY+'/cartoon.php',734)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+'الحلقات الجديدة',e2VR8nohduY,731,'','','latest_episodes')
	CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+'مسلسلات جديدة',e2VR8nohduY,731,'','','latest_series')
	CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+'أفلام جديدة',e2VR8nohduY,731,'','','latest_movies')
	return
def QQYk3Rmcx0l9D6JoTuyZHMSCzAes7(url):
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'ARABICTOONS-SERIES_SUBMENU-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"series-fullpage"(.*?)</div>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('href="(.*?)".*?>(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,title in items:
			vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+xufJqQcGnhboiVy2wd+vn1grP3y4It9GmVuBbLJfz2A
			title = 'الكل' if 'الكل' in title else 'حرف '+title
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,731)
	return
def jovtJXBwzSK0U953G(url):
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'ARABICTOONS-SERIES_FEATURED-2nd')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('class="slider"(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('title="(.*?)" href="(.*?)".*?src="(.*?)"',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for title,vn1grP3y4It9GmVuBbLJfz2A,uIGD4vZcP61QNmw78LXqoEpH in items:
			vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+xufJqQcGnhboiVy2wd+vn1grP3y4It9GmVuBbLJfz2A
			uIGD4vZcP61QNmw78LXqoEpH = e2VR8nohduY+xufJqQcGnhboiVy2wd+uIGD4vZcP61QNmw78LXqoEpH
			title = title.strip(oQpxmKiRPlHeGsLXNrJF78O)
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,733,uIGD4vZcP61QNmw78LXqoEpH)
	return
def c8wfGju4CWZm(url,S46ZVrhN1gWY0Iiaj):
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'ARABICTOONS-TITLES-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	items = []
	if S46ZVrhN1gWY0Iiaj=='search':
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"section-header">(.*?)pagination',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
			MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
			items = DyVGS3dX0ZxR.findall('href="(.*?)".*?src="(.*?)".*?title">(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	elif 'latest' in S46ZVrhN1gWY0Iiaj:
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"section-header">(.*?)"swiper-pagination"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if S46ZVrhN1gWY0Iiaj=='latest_movies': MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[2]
		elif S46ZVrhN1gWY0Iiaj=='latest_series': MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[1]
		else: MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('href="(.*?)".*?src="(.*?)" alt="(.*?)"',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	else:
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"series-grid-swiper"(.*?)pagination',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('href="([^"]*)" title="([^"]*)".*?src="(.*?)"',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		jzTLleJs8x9Hb1,qP1wT2MFf0oK9Uv3u87QL,xWR90Dw2kZa4TGz51NQMU3hIv7rXE = zip(*items)
		items = zip(jzTLleJs8x9Hb1,xWR90Dw2kZa4TGz51NQMU3hIv7rXE,qP1wT2MFf0oK9Uv3u87QL)
	for vn1grP3y4It9GmVuBbLJfz2A,uIGD4vZcP61QNmw78LXqoEpH,title in items:
		if 'books' in vn1grP3y4It9GmVuBbLJfz2A: continue
		vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+xufJqQcGnhboiVy2wd+vn1grP3y4It9GmVuBbLJfz2A
		if 'http' not in uIGD4vZcP61QNmw78LXqoEpH: uIGD4vZcP61QNmw78LXqoEpH = e2VR8nohduY+xufJqQcGnhboiVy2wd+uIGD4vZcP61QNmw78LXqoEpH
		title = title.strip()
		if 'movies.php' in url or S46ZVrhN1gWY0Iiaj=='latest_movies': CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,732,uIGD4vZcP61QNmw78LXqoEpH)
		else: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,733,uIGD4vZcP61QNmw78LXqoEpH)
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('pagination(.*?)"series-grid-swiper"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('href="(.*?)".*?"page-number">(.*?)</a>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,title in items:
			if '>' in title: continue
			vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+xufJqQcGnhboiVy2wd+vn1grP3y4It9GmVuBbLJfz2A if '.php' in vn1grP3y4It9GmVuBbLJfz2A else url+vn1grP3y4It9GmVuBbLJfz2A
			title = title.strip()
			title = SVsiEWeRf6oIynqQx8pCrM4Tk(title)
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'صفحة '+title,vn1grP3y4It9GmVuBbLJfz2A,731)
	return
def XONC9osGSP4fW5HVrhM(url):
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'ARABICTOONS-EPISODES-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"episodes-section"(.*?)<script>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('href="([^"]*)" title="([^"]*)".*?src="(.*?)"',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,title,uIGD4vZcP61QNmw78LXqoEpH in items:
			vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+xufJqQcGnhboiVy2wd+vn1grP3y4It9GmVuBbLJfz2A
			uIGD4vZcP61QNmw78LXqoEpH = e2VR8nohduY+xufJqQcGnhboiVy2wd+uIGD4vZcP61QNmw78LXqoEpH
			title = title.strip()
			CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,732,uIGD4vZcP61QNmw78LXqoEpH)
	return
def f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url):
	KWnAuJIFyESQHjP3X5xzMqUbR6L = []
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'ARABICTOONS-PLAY-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	vn1grP3y4It9GmVuBbLJfz2A = DyVGS3dX0ZxR.findall('videoSrc = "(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if vn1grP3y4It9GmVuBbLJfz2A:
		vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A[0]
		vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A+'|Sec-Fetch-Dest=video'
		KWnAuJIFyESQHjP3X5xzMqUbR6L.append(vn1grP3y4It9GmVuBbLJfz2A+'?named=__embed')
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"player-switcher-form"(.*?)</form>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('value="(.*?)".*?"btn-text">(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for choice,title in items:
			vn1grP3y4It9GmVuBbLJfz2A = url+'?player_choice='+choice+'&form_submitted=1'
			KWnAuJIFyESQHjP3X5xzMqUbR6L.append(vn1grP3y4It9GmVuBbLJfz2A+'?named='+title+'__watch')
	XWZ6MYjdTQaxl3KtNU = DyVGS3dX0ZxR.findall(r'dynamique.*?}\);', CzNPJydxQLfw27tv4ZF8KORAbX5, DyVGS3dX0ZxR.DOTALL)
	if not XWZ6MYjdTQaxl3KtNU: XWZ6MYjdTQaxl3KtNU = DyVGS3dX0ZxR.findall(r'dynamique.*?}\)', CzNPJydxQLfw27tv4ZF8KORAbX5, DyVGS3dX0ZxR.DOTALL)
	if XWZ6MYjdTQaxl3KtNU:
		Ylov7UPRSGLeNm6X = XWZ6MYjdTQaxl3KtNU[0]
		kBPvyKCO5V60sT = dict(DyVGS3dX0ZxR.findall(r'(\w+):\s*"([^"]+)"', Ylov7UPRSGLeNm6X))
		yyIuwXN9b5GKJVLpRjMq2SFkioDa7 = DyVGS3dX0ZxR.search(r'const\s+(\w+)', Ylov7UPRSGLeNm6X)
		airVhHdqCb6Gf49eERSjv1 = yyIuwXN9b5GKJVLpRjMq2SFkioDa7.group(1) if yyIuwXN9b5GKJVLpRjMq2SFkioDa7 else ""
		keys = DyVGS3dX0ZxR.findall(r'\$\{' + airVhHdqCb6Gf49eERSjv1 + r'\.(\w+)\}', Ylov7UPRSGLeNm6X)
		if kBPvyKCO5V60sT and keys:
			vn1grP3y4It9GmVuBbLJfz2A = "%s://%s/%s?%s" % (kBPvyKCO5V60sT[keys[0]], kBPvyKCO5V60sT[keys[1]], kBPvyKCO5V60sT[keys[2]], kBPvyKCO5V60sT[keys[3]])
			KWnAuJIFyESQHjP3X5xzMqUbR6L.append(vn1grP3y4It9GmVuBbLJfz2A+'?named=__embed')
	vn1grP3y4It9GmVuBbLJfz2A = DyVGS3dX0ZxR.findall('source src="http(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if vn1grP3y4It9GmVuBbLJfz2A:
		vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A[0]
		if 'Referer=' not in vn1grP3y4It9GmVuBbLJfz2A: vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A+'|Referer=https://www.arabic-toons.com'
		KWnAuJIFyESQHjP3X5xzMqUbR6L.append(vn1grP3y4It9GmVuBbLJfz2A+'?named=__embed')
	import NsD5AomUqH
	NsD5AomUqH.NZcWGBmgFEen5hvJjUSIzOCVk7(KWnAuJIFyESQHjP3X5xzMqUbR6L,HDLtdMAy7wPkl8aKC3O2,'video',url)
	return
def hm4kawIPKp3oMrC75dJZA9HS2(search):
	search,GXVabd4sc2u3zp0JI,showDialogs = x0pzMENwy84tBcZvXr(search)
	if search==HQmDERMFjx: search = q156m84QoYrn()
	if search==HQmDERMFjx: return
	search = search.replace(oQpxmKiRPlHeGsLXNrJF78O,'%20')
	url = e2VR8nohduY+'/search_results.php?q='+search
	c8wfGju4CWZm(url,'search')
	return
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'ARABICTOONS-SEARCH-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	items = DyVGS3dX0ZxR.findall('href="(.*?)">(.*?)<',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	for vn1grP3y4It9GmVuBbLJfz2A,title in items:
		vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+xufJqQcGnhboiVy2wd+vn1grP3y4It9GmVuBbLJfz2A
		title = title.strip(oQpxmKiRPlHeGsLXNrJF78O)
		if type=='m': CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,732)
		else: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,733)
	return
# -*- coding: utf-8 -*-
from FF68kA5BUy import *
HDLtdMAy7wPkl8aKC3O2 = 'SERIES4WATCH'
headers = { 'User-Agent' : HQmDERMFjx }
EEJvXQzSZNt = '_SFW_'
e2VR8nohduY = Jzthpc2nj5.SITESURLS[HDLtdMAy7wPkl8aKC3O2][0]
def kk6X5LxpsND(mode,url,text):
	if   mode==210: zLZUkrP7ac5 = afkxo7FyZWB4O6K1eXrs5I()
	elif mode==211: zLZUkrP7ac5 = c8wfGju4CWZm(url)
	elif mode==212: zLZUkrP7ac5 = f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url)
	elif mode==213: zLZUkrP7ac5 = XONC9osGSP4fW5HVrhM(url)
	elif mode==214: zLZUkrP7ac5 = hhKxtdZbe6ENogyAazjVXL7p(url)
	elif mode==215: zLZUkrP7ac5 = RzJITw3i58Nln6GMBAd2pHSes7mhY(url)
	elif mode==218: zLZUkrP7ac5 = veU9QpiaqR7hOwZn()
	elif mode==219: zLZUkrP7ac5 = hm4kawIPKp3oMrC75dJZA9HS2(text)
	else: zLZUkrP7ac5 = False
	return zLZUkrP7ac5
def veU9QpiaqR7hOwZn():
	message = 'هذا الموقع تغير بالكامل ... وبحاجة الى اعادة برمجة من الصفر ... والمبرمج حاليا مشغول ويعاني من وعكة صحية ... ولهذا سوف يبقى الموقع مغلق الى ما شاء الله'
	u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,'الموقع تغير بالكامل',message)
	return
def afkxo7FyZWB4O6K1eXrs5I():
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'بحث في الموقع',HQmDERMFjx,219,HQmDERMFjx,HQmDERMFjx,'_REMEMBERRESULTS_')
	url = e2VR8nohduY+'/getpostsPin?type=one&data=pin&limit=25'
	CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+'المميزة',url,211)
	CzNPJydxQLfw27tv4ZF8KORAbX5 = D0GFPwY8ecAVI(H5x4Z2qPwR8vXM,e2VR8nohduY,HQmDERMFjx,headers,HQmDERMFjx,'SERIES4WATCH-MENU-1st')
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('FiltersButtons(.*?)</div>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	items = DyVGS3dX0ZxR.findall('data-get="(.*?)".*?</i>(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	for vn1grP3y4It9GmVuBbLJfz2A,title in items:
		url = e2VR8nohduY+'/getposts?type=one&data='+vn1grP3y4It9GmVuBbLJfz2A
		CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+title,url,211)
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('navigation-menu(.*?)</div>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	items = DyVGS3dX0ZxR.findall('href="(http.*?)">(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	FwhZ0nXtpoHTMarf = ['مسلسلات انمي','الرئيسية']
	for vn1grP3y4It9GmVuBbLJfz2A,title in items:
		title = title.strip(oQpxmKiRPlHeGsLXNrJF78O)
		if not any(value in title for value in FwhZ0nXtpoHTMarf):
			CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,211)
	return CzNPJydxQLfw27tv4ZF8KORAbX5
def c8wfGju4CWZm(url):
	CzNPJydxQLfw27tv4ZF8KORAbX5 = D0GFPwY8ecAVI(j9uzmBeEyK8,url,HQmDERMFjx,headers,HQmDERMFjx,'SERIES4WATCH-TITLES-1st')
	if 'getposts' in url or '/search?s=' in url: MJ2gSPyTl9hzoi1 = CzNPJydxQLfw27tv4ZF8KORAbX5
	else:
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('MediaGrid"(.*?)class="pagination"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1: MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		else: return
	items = DyVGS3dX0ZxR.findall('src="(.*?)".*?href="(.*?)".*?<h3>(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	ORMkTYjJ1p7 = []
	Dfbu0wOr6IcqhE2XCUKn = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for uIGD4vZcP61QNmw78LXqoEpH,vn1grP3y4It9GmVuBbLJfz2A,title in items:
		if '/series/' in vn1grP3y4It9GmVuBbLJfz2A: continue
		vn1grP3y4It9GmVuBbLJfz2A = xx9LK4VzpF6IHXSEyhmrQwbg25P0(vn1grP3y4It9GmVuBbLJfz2A).strip(xufJqQcGnhboiVy2wd)
		title = SVsiEWeRf6oIynqQx8pCrM4Tk(title)
		title = title.strip(oQpxmKiRPlHeGsLXNrJF78O)
		if '/film/' in vn1grP3y4It9GmVuBbLJfz2A or any(value in title for value in Dfbu0wOr6IcqhE2XCUKn):
			CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,212,uIGD4vZcP61QNmw78LXqoEpH)
		elif '/episode/' in vn1grP3y4It9GmVuBbLJfz2A and 'الحلقة' in title:
			yTz8SOkAhu24j6apo9BmZHvwWsX = DyVGS3dX0ZxR.findall('(.*?) الحلقة \d+',title,DyVGS3dX0ZxR.DOTALL)
			if yTz8SOkAhu24j6apo9BmZHvwWsX:
				title = '_MOD_' + yTz8SOkAhu24j6apo9BmZHvwWsX[0]
				if title not in ORMkTYjJ1p7:
					CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,213,uIGD4vZcP61QNmw78LXqoEpH)
					ORMkTYjJ1p7.append(title)
		else: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,213,uIGD4vZcP61QNmw78LXqoEpH)
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('class="pagination(.*?)</div>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('<a href=["\'](http.*?)["\'].*?>(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,title in items:
			vn1grP3y4It9GmVuBbLJfz2A = SVsiEWeRf6oIynqQx8pCrM4Tk(vn1grP3y4It9GmVuBbLJfz2A)
			title = SVsiEWeRf6oIynqQx8pCrM4Tk(title)
			title = title.replace('الصفحة ',HQmDERMFjx)
			if title!=HQmDERMFjx: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'صفحة '+title,vn1grP3y4It9GmVuBbLJfz2A,211)
	return
def XONC9osGSP4fW5HVrhM(url):
	xctI9sq8HVk4p5ga20LriEouYe3JfX,items,nK0kT8JCEQmXsGB3H = -1,[],[]
	CzNPJydxQLfw27tv4ZF8KORAbX5 = D0GFPwY8ecAVI(j9uzmBeEyK8,url,HQmDERMFjx,headers,HQmDERMFjx,'SERIES4WATCH-EPISODES-1st')
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('ti-list-numbered(.*?)</div>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		bUzHWnGg5t1 = HQmDERMFjx.join(Ut7reR0XioMjOdYWZKsLIuc3TQJmC1)
		items = DyVGS3dX0ZxR.findall('href="(.*?)"',bUzHWnGg5t1,DyVGS3dX0ZxR.DOTALL)
	items.append(url)
	items = set(items)
	for vn1grP3y4It9GmVuBbLJfz2A in items:
		vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A.strip(xufJqQcGnhboiVy2wd)
		title = '_MOD_' + vn1grP3y4It9GmVuBbLJfz2A.split(xufJqQcGnhboiVy2wd)[-1].replace('-',oQpxmKiRPlHeGsLXNrJF78O)
		mR2QPcrA3wqT5lONxtunW9J0bj8 = DyVGS3dX0ZxR.findall('الحلقة-(\d+)',vn1grP3y4It9GmVuBbLJfz2A.split(xufJqQcGnhboiVy2wd)[-1],DyVGS3dX0ZxR.DOTALL)
		if mR2QPcrA3wqT5lONxtunW9J0bj8: mR2QPcrA3wqT5lONxtunW9J0bj8 = mR2QPcrA3wqT5lONxtunW9J0bj8[0]
		else: mR2QPcrA3wqT5lONxtunW9J0bj8 = '0'
		nK0kT8JCEQmXsGB3H.append([vn1grP3y4It9GmVuBbLJfz2A,title,mR2QPcrA3wqT5lONxtunW9J0bj8])
	items = sorted(nK0kT8JCEQmXsGB3H, reverse=False, key=lambda key: int(key[2]))
	qyn9gakL5SZj = str(items).count('/season/')
	xctI9sq8HVk4p5ga20LriEouYe3JfX = str(items).count('/episode/')
	if qyn9gakL5SZj>1 and xctI9sq8HVk4p5ga20LriEouYe3JfX>0 and '/season/' not in url:
		for vn1grP3y4It9GmVuBbLJfz2A,title,mR2QPcrA3wqT5lONxtunW9J0bj8 in items:
			if '/season/' in vn1grP3y4It9GmVuBbLJfz2A: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,213)
	else:
		for vn1grP3y4It9GmVuBbLJfz2A,title,mR2QPcrA3wqT5lONxtunW9J0bj8 in items:
			if '/season/' not in vn1grP3y4It9GmVuBbLJfz2A: CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,212)
	return
def f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url):
	Na8vklCpUGYIzP0bjutWOT = []
	DDAoB3rdfJTXuE2RQwK8 = url.split(xufJqQcGnhboiVy2wd)
	CzNPJydxQLfw27tv4ZF8KORAbX5 = D0GFPwY8ecAVI(H5x4Z2qPwR8vXM,url,HQmDERMFjx,headers,HQmDERMFjx,'SERIES4WATCH-PLAY-1st')
	if '/watch/' in CzNPJydxQLfw27tv4ZF8KORAbX5:
		SSHjMN4uegZfb2 = url.replace(DDAoB3rdfJTXuE2RQwK8[3],'watch')
		b3L20nx7qwHKTS6so = D0GFPwY8ecAVI(H5x4Z2qPwR8vXM,SSHjMN4uegZfb2,HQmDERMFjx,headers,HQmDERMFjx,'SERIES4WATCH-PLAY-2nd')
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('class="servers-list(.*?)</div>',b3L20nx7qwHKTS6so,DyVGS3dX0ZxR.DOTALL)
		if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
			MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
			items = DyVGS3dX0ZxR.findall('data-embedd="(.*?)".*?server_image">\n(.*?)\n',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
			if items:
				id = DyVGS3dX0ZxR.findall('post_id=(.*?)"',b3L20nx7qwHKTS6so,DyVGS3dX0ZxR.DOTALL)
				if id:
					ZLRQYEUBNPSl3XTxze6Iug = id[0]
					for vn1grP3y4It9GmVuBbLJfz2A,title in items:
						vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+'/?postid='+ZLRQYEUBNPSl3XTxze6Iug+'&serverid='+vn1grP3y4It9GmVuBbLJfz2A+'?named='+title+'__watch'
						Na8vklCpUGYIzP0bjutWOT.append(vn1grP3y4It9GmVuBbLJfz2A)
			else:
				items = DyVGS3dX0ZxR.findall('data-embedd=".*?(http.*?)("|&quot;)',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
				for vn1grP3y4It9GmVuBbLJfz2A,RZ9V4eABCTfIO1FUrz2ks5DSwu in items:
					Na8vklCpUGYIzP0bjutWOT.append(vn1grP3y4It9GmVuBbLJfz2A)
	if '/download/' in CzNPJydxQLfw27tv4ZF8KORAbX5:
		SSHjMN4uegZfb2 = url.replace(DDAoB3rdfJTXuE2RQwK8[3],'download')
		b3L20nx7qwHKTS6so = D0GFPwY8ecAVI(H5x4Z2qPwR8vXM,SSHjMN4uegZfb2,HQmDERMFjx,headers,HQmDERMFjx,'SERIES4WATCH-PLAY-3rd')
		id = DyVGS3dX0ZxR.findall('postId:"(.*?)"',b3L20nx7qwHKTS6so,DyVGS3dX0ZxR.DOTALL)
		if id:
			ZLRQYEUBNPSl3XTxze6Iug = id[0]
			nJayb3s5zlOgQh9BwiCdEDq = { 'User-Agent':HQmDERMFjx , 'X-Requested-With':'XMLHttpRequest' }
			SSHjMN4uegZfb2 = e2VR8nohduY + '/ajaxCenter?_action=getdownloadlinks&postId='+ZLRQYEUBNPSl3XTxze6Iug
			b3L20nx7qwHKTS6so = D0GFPwY8ecAVI(H5x4Z2qPwR8vXM,SSHjMN4uegZfb2,HQmDERMFjx,nJayb3s5zlOgQh9BwiCdEDq,HQmDERMFjx,'SERIES4WATCH-PLAY-4th')
			Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('<h3.*?(\d+)(.*?)</div>',b3L20nx7qwHKTS6so,DyVGS3dX0ZxR.DOTALL)
			if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
				for sYiLzTXyB5vCtqI,MJ2gSPyTl9hzoi1 in Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
					items = DyVGS3dX0ZxR.findall('<td>(.*?)<.*?href="(.*?)"',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
					for name,vn1grP3y4It9GmVuBbLJfz2A in items:
						Na8vklCpUGYIzP0bjutWOT.append(vn1grP3y4It9GmVuBbLJfz2A+'?named='+name+'__download'+'____'+sYiLzTXyB5vCtqI)
			else:
				Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('<h6(.*?)</table>',b3L20nx7qwHKTS6so,DyVGS3dX0ZxR.DOTALL)
				if not Ut7reR0XioMjOdYWZKsLIuc3TQJmC1: Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = [b3L20nx7qwHKTS6so]
				for MJ2gSPyTl9hzoi1 in Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
					name = HQmDERMFjx
					items = DyVGS3dX0ZxR.findall('href="(http.*?)"',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
					for vn1grP3y4It9GmVuBbLJfz2A in items:
						pYVvlGR1ES0gdtzayiDqb9w = '&&' + vn1grP3y4It9GmVuBbLJfz2A.split(xufJqQcGnhboiVy2wd)[2].lower() + '&&'
						pYVvlGR1ES0gdtzayiDqb9w = pYVvlGR1ES0gdtzayiDqb9w.replace('.com&&',HQmDERMFjx).replace('.co&&',HQmDERMFjx)
						pYVvlGR1ES0gdtzayiDqb9w = pYVvlGR1ES0gdtzayiDqb9w.replace('.net&&',HQmDERMFjx).replace('.org&&',HQmDERMFjx)
						pYVvlGR1ES0gdtzayiDqb9w = pYVvlGR1ES0gdtzayiDqb9w.replace('.live&&',HQmDERMFjx).replace('.online&&',HQmDERMFjx)
						pYVvlGR1ES0gdtzayiDqb9w = pYVvlGR1ES0gdtzayiDqb9w.replace('&&hd.',HQmDERMFjx).replace('&&www.',HQmDERMFjx)
						pYVvlGR1ES0gdtzayiDqb9w = pYVvlGR1ES0gdtzayiDqb9w.replace('&&',HQmDERMFjx)
						vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A + '?named=' + name + pYVvlGR1ES0gdtzayiDqb9w + '__download'
						Na8vklCpUGYIzP0bjutWOT.append(vn1grP3y4It9GmVuBbLJfz2A)
	import NsD5AomUqH
	NsD5AomUqH.NZcWGBmgFEen5hvJjUSIzOCVk7(Na8vklCpUGYIzP0bjutWOT,HDLtdMAy7wPkl8aKC3O2,'video',url)
	return
def hm4kawIPKp3oMrC75dJZA9HS2(search):
	search,GXVabd4sc2u3zp0JI,showDialogs = x0pzMENwy84tBcZvXr(search)
	if search==HQmDERMFjx: search = q156m84QoYrn()
	if search==HQmDERMFjx: return
	search = search.replace(oQpxmKiRPlHeGsLXNrJF78O,'+')
	url = e2VR8nohduY + '/search?s='+search
	c8wfGju4CWZm(url)
	return
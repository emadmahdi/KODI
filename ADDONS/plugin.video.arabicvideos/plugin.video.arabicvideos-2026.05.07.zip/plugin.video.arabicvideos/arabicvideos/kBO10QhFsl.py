# -*- coding: utf-8 -*-
from FF68kA5BUy import *
HDLtdMAy7wPkl8aKC3O2 = 'FABRAKA'
EEJvXQzSZNt = '_FBK_'
e2VR8nohduY = Jzthpc2nj5.SITESURLS[HDLtdMAy7wPkl8aKC3O2][0]
FwhZ0nXtpoHTMarf = ['الصفحة الرئيسية','Sign in']
def kk6X5LxpsND(mode,url,text):
	if   mode==620: zLZUkrP7ac5 = afkxo7FyZWB4O6K1eXrs5I()
	elif mode==621: zLZUkrP7ac5 = c8wfGju4CWZm(url,text)
	elif mode==622: zLZUkrP7ac5 = f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url)
	elif mode==623: zLZUkrP7ac5 = QQp8orwMlAa1(url,text)
	elif mode==624: zLZUkrP7ac5 = REWBU20fyqaLprY(url)
	elif mode==629: zLZUkrP7ac5 = hm4kawIPKp3oMrC75dJZA9HS2(text)
	else: zLZUkrP7ac5 = False
	return zLZUkrP7ac5
def afkxo7FyZWB4O6K1eXrs5I():
	EFDgdaV4WT6U2yotAPX1B,url,vGXnw9VcUN = Lp6sIRBKlhmjJvDPO(rwjfOIqQU3ANa0JlWXvCDbFk,'GET',e2VR8nohduY,'fabraka','فبركة azureedge.net','كافة الحقوق محفوظة')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'بحث في الموقع',HQmDERMFjx,629,HQmDERMFjx,HQmDERMFjx,'_REMEMBERRESULTS_')
	CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+'جديد الحلقات',EFDgdaV4WT6U2yotAPX1B,621,HQmDERMFjx,HQmDERMFjx,'new_episodes')
	CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+'جديد الأفلام',EFDgdaV4WT6U2yotAPX1B,621,HQmDERMFjx,HQmDERMFjx,'new_movies')
	CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+'المسلسلات المميزة',EFDgdaV4WT6U2yotAPX1B,621,HQmDERMFjx,HQmDERMFjx,'featured_series')
	CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"navslide-wrap"(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if not Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,'موقع فبركة','البرنامج لم يستطيع إيجاد عنوان الموقع أو تصميم الموقع تغير')
		return
	MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	items = DyVGS3dX0ZxR.findall('href="(.*?)".*?</i>(.*?)</a>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	for vn1grP3y4It9GmVuBbLJfz2A,title in items:
		if title in FwhZ0nXtpoHTMarf: continue
		CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,624)
	CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('/category.php">(.*?)"navslide-divider"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall("'dropdown-menu'(.*?)</ul>",CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	for ej8EfB1iZ5Gh3X2gxWtSONH in Ut7reR0XioMjOdYWZKsLIuc3TQJmC1: MJ2gSPyTl9hzoi1 = MJ2gSPyTl9hzoi1.replace(ej8EfB1iZ5Gh3X2gxWtSONH,HQmDERMFjx)
	items = DyVGS3dX0ZxR.findall('href="(.*?)".*?>(.*?)</a>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	for vn1grP3y4It9GmVuBbLJfz2A,title in items:
		if title in FwhZ0nXtpoHTMarf: continue
		CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,624)
	return
def REWBU20fyqaLprY(url):
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'FABRAKA-SUBMENU-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	cOUkMZagDQftHLBoCivP = DyVGS3dX0ZxR.findall('"caret"(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if cOUkMZagDQftHLBoCivP:
		MJ2gSPyTl9hzoi1 = cOUkMZagDQftHLBoCivP[0]
		MJ2gSPyTl9hzoi1 = MJ2gSPyTl9hzoi1.replace('"presentation"','</ul>')
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		if not Ut7reR0XioMjOdYWZKsLIuc3TQJmC1: Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = [(HQmDERMFjx,MJ2gSPyTl9hzoi1)]
		CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' فرز أو فلتر أو ترتيب '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
		for XwidGQz8WkV1CorLYJ4Z9aqO0g,MJ2gSPyTl9hzoi1 in Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
			items = DyVGS3dX0ZxR.findall('href="(.*?)".*?>(.*?)</a>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
			if XwidGQz8WkV1CorLYJ4Z9aqO0g: XwidGQz8WkV1CorLYJ4Z9aqO0g = XwidGQz8WkV1CorLYJ4Z9aqO0g+': '
			for vn1grP3y4It9GmVuBbLJfz2A,title in items:
				title = XwidGQz8WkV1CorLYJ4Z9aqO0g+title
				CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,621)
	vuylTosVej845YfDNK = DyVGS3dX0ZxR.findall('"pm-category-subcats"(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if vuylTosVej845YfDNK:
		MJ2gSPyTl9hzoi1 = vuylTosVej845YfDNK[0]
		items = DyVGS3dX0ZxR.findall('href="(.*?)">(.*?)</a>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		if len(items)<30:
			CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
			for vn1grP3y4It9GmVuBbLJfz2A,title in items:
				CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,621)
	if not cOUkMZagDQftHLBoCivP and not vuylTosVej845YfDNK: c8wfGju4CWZm(url)
	return
def c8wfGju4CWZm(url,S46ZVrhN1gWY0Iiaj=HQmDERMFjx):
	if S46ZVrhN1gWY0Iiaj=='ajax-search':
		url,search = url.split('?',1)
		data = 'queryString='+search
		headers = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'POST',url,data,headers,HQmDERMFjx,HQmDERMFjx,'FABRAKA-TITLES-1st')
	else:
		vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'FABRAKA-TITLES-2nd')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	MJ2gSPyTl9hzoi1,items = HQmDERMFjx,[]
	EFDgdaV4WT6U2yotAPX1B = DpClq35GVjh(url,'url')
	if S46ZVrhN1gWY0Iiaj=='ajax-search':
		MJ2gSPyTl9hzoi1 = CzNPJydxQLfw27tv4ZF8KORAbX5
		bbiKcPz2RQOUwS = DyVGS3dX0ZxR.findall('href="(.*?)">(.*?)</a>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,title in bbiKcPz2RQOUwS: items.append((HQmDERMFjx,vn1grP3y4It9GmVuBbLJfz2A,title))
	elif S46ZVrhN1gWY0Iiaj=='featured':
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"pm-video-watch-featured"(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1: MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	elif S46ZVrhN1gWY0Iiaj=='new_episodes':
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"row pm-ul-browse-videos(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1: MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	elif S46ZVrhN1gWY0Iiaj=='new_movies':
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"row pm-ul-browse-videos(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if len(Ut7reR0XioMjOdYWZKsLIuc3TQJmC1)>1: MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[1]
	elif S46ZVrhN1gWY0Iiaj=='featured_series':
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"home-series-list"(.*?)</div>[\t|\n]*</div>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1: MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		bbiKcPz2RQOUwS = DyVGS3dX0ZxR.findall('href="(.*?)">(.*?)</a>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,title in bbiKcPz2RQOUwS: items.append((HQmDERMFjx,vn1grP3y4It9GmVuBbLJfz2A,title))
	else:
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('(data-echo=".*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1: MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	if MJ2gSPyTl9hzoi1 and not items: items = DyVGS3dX0ZxR.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	if not items: return
	ORMkTYjJ1p7 = []
	smLQwgO0BynVCcl3fYJ = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for uIGD4vZcP61QNmw78LXqoEpH,vn1grP3y4It9GmVuBbLJfz2A,title in items:
		yTz8SOkAhu24j6apo9BmZHvwWsX = DyVGS3dX0ZxR.findall('(.*?) (الحلقة|حلقة).\d+',title,DyVGS3dX0ZxR.DOTALL)
		if any(value in title for value in smLQwgO0BynVCcl3fYJ):
			CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,622,uIGD4vZcP61QNmw78LXqoEpH)
		elif S46ZVrhN1gWY0Iiaj=='new_episodes':
			CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,622,uIGD4vZcP61QNmw78LXqoEpH)
		elif yTz8SOkAhu24j6apo9BmZHvwWsX:
			title = '_MOD_' + yTz8SOkAhu24j6apo9BmZHvwWsX[0][0]
			if title not in ORMkTYjJ1p7:
				CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,623,uIGD4vZcP61QNmw78LXqoEpH)
				ORMkTYjJ1p7.append(title)
		else: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,623,uIGD4vZcP61QNmw78LXqoEpH)
	if 1:
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"pagination(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
			MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
			items = DyVGS3dX0ZxR.findall('href="(.*?)".*?>(.*?)</a>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
			for vn1grP3y4It9GmVuBbLJfz2A,title in items:
				if vn1grP3y4It9GmVuBbLJfz2A=='#': continue
				vn1grP3y4It9GmVuBbLJfz2A = EFDgdaV4WT6U2yotAPX1B+xufJqQcGnhboiVy2wd+vn1grP3y4It9GmVuBbLJfz2A.strip(xufJqQcGnhboiVy2wd)
				title = SVsiEWeRf6oIynqQx8pCrM4Tk(title)
				CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'صفحة '+title,vn1grP3y4It9GmVuBbLJfz2A,621)
	return
def QQp8orwMlAa1(url,Y2OHMQ7a5tFfS1n):
	EFDgdaV4WT6U2yotAPX1B = DpClq35GVjh(url,'url')
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'FABRAKA-EPISODES-2nd')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	cOUkMZagDQftHLBoCivP = DyVGS3dX0ZxR.findall('"SeasonsBox"(.*?)"SeasonsEpisodesMain',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	kALyrFT6KPNGI7Oiup82Qb4JCq0td = DyVGS3dX0ZxR.findall('"series-header".*?src="(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if kALyrFT6KPNGI7Oiup82Qb4JCq0td: uIGD4vZcP61QNmw78LXqoEpH = kALyrFT6KPNGI7Oiup82Qb4JCq0td[0]
	else: uIGD4vZcP61QNmw78LXqoEpH = HQmDERMFjx
	items = []
	VyueNkv1smz4MSdtWAiHapBTI8g = False
	if cOUkMZagDQftHLBoCivP and not Y2OHMQ7a5tFfS1n:
		MJ2gSPyTl9hzoi1 = cOUkMZagDQftHLBoCivP[0]
		items = DyVGS3dX0ZxR.findall('''onclick="openCity\(event, '(.*?)'\)">(.*?)</button>''',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for Y2OHMQ7a5tFfS1n,title in items:
			Y2OHMQ7a5tFfS1n = Y2OHMQ7a5tFfS1n.strip('#')
			if len(items)>1: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,url,623,uIGD4vZcP61QNmw78LXqoEpH,HQmDERMFjx,Y2OHMQ7a5tFfS1n)
			else: VyueNkv1smz4MSdtWAiHapBTI8g = True
	else: VyueNkv1smz4MSdtWAiHapBTI8g = True
	vuylTosVej845YfDNK = DyVGS3dX0ZxR.findall('id="'+Y2OHMQ7a5tFfS1n+'"(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if vuylTosVej845YfDNK and VyueNkv1smz4MSdtWAiHapBTI8g:
		MJ2gSPyTl9hzoi1 = vuylTosVej845YfDNK[0]
		bbiKcPz2RQOUwS = DyVGS3dX0ZxR.findall('''href=['"](.*?)['"]><li><em>(.*?)</span>''',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		items = []
		for vn1grP3y4It9GmVuBbLJfz2A,title in bbiKcPz2RQOUwS: items.append((vn1grP3y4It9GmVuBbLJfz2A,title,uIGD4vZcP61QNmw78LXqoEpH))
		if not items: items = DyVGS3dX0ZxR.findall('"thumbnail".*?href="([^"]*)" title="([^"]*)".*?src="(.*?)"',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,title,uIGD4vZcP61QNmw78LXqoEpH in items:
			vn1grP3y4It9GmVuBbLJfz2A = EFDgdaV4WT6U2yotAPX1B+xufJqQcGnhboiVy2wd+vn1grP3y4It9GmVuBbLJfz2A.strip(xufJqQcGnhboiVy2wd)
			title = title.replace('</em><span>',oQpxmKiRPlHeGsLXNrJF78O)
			CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,622,uIGD4vZcP61QNmw78LXqoEpH)
	return
def f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url):
	KWnAuJIFyESQHjP3X5xzMqUbR6L = []
	url = url.replace('watch.php','see.php')
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'FABRAKA-PLAY-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"WatchList"(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('embed-url="(.*?)".*?<strong>(.*?)</strong>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,title in items:
			vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A+'?named='+title+'__watch'
			KWnAuJIFyESQHjP3X5xzMqUbR6L.append(vn1grP3y4It9GmVuBbLJfz2A)
	vn1grP3y4It9GmVuBbLJfz2A = DyVGS3dX0ZxR.findall('<iframe src="(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if vn1grP3y4It9GmVuBbLJfz2A:
		vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A[0]+'?named='+title+'__embed'
		KWnAuJIFyESQHjP3X5xzMqUbR6L.append(vn1grP3y4It9GmVuBbLJfz2A)
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"downloadlist"(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('download-url="(.*?)".*?<strong>(.*?)</strong>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,title in items:
			vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A+'?named='+title+'__download'
			KWnAuJIFyESQHjP3X5xzMqUbR6L.append(vn1grP3y4It9GmVuBbLJfz2A)
	import NsD5AomUqH
	NsD5AomUqH.NZcWGBmgFEen5hvJjUSIzOCVk7(KWnAuJIFyESQHjP3X5xzMqUbR6L,HDLtdMAy7wPkl8aKC3O2,'video',url)
	return
def hm4kawIPKp3oMrC75dJZA9HS2(search):
	search,GXVabd4sc2u3zp0JI,showDialogs = x0pzMENwy84tBcZvXr(search)
	if search==HQmDERMFjx: search = q156m84QoYrn()
	if search==HQmDERMFjx: return
	search = search.replace(oQpxmKiRPlHeGsLXNrJF78O,'+')
	url = e2VR8nohduY+'/search.php?keywords='+search
	EFDgdaV4WT6U2yotAPX1B,SSHjMN4uegZfb2,x4Du7lGWPET6g0H23NAvbopQya = Lp6sIRBKlhmjJvDPO(rwjfOIqQU3ANa0JlWXvCDbFk,'GET',url,'fabraka','فبركة azureedge.net','كافة الحقوق محفوظة')
	c8wfGju4CWZm(SSHjMN4uegZfb2,'search')
	return
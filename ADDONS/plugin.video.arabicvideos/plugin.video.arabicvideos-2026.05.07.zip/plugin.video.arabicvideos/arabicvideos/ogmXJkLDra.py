# -*- coding: utf-8 -*-
from FF68kA5BUy import *
HDLtdMAy7wPkl8aKC3O2 = 'SHAHID4U'
EEJvXQzSZNt = '_SH4_'
e2VR8nohduY = Jzthpc2nj5.SITESURLS[HDLtdMAy7wPkl8aKC3O2][0]
headers = {'User-Agent':xK7D9yiBPEqvhmA8XIoJe(True)}
FwhZ0nXtpoHTMarf = ['عروض مصارعة','الكل','افلام','javascript','مصارعة حرة']
def kk6X5LxpsND(mode,url,text):
	if   mode==110: zLZUkrP7ac5 = afkxo7FyZWB4O6K1eXrs5I()
	elif mode==111: zLZUkrP7ac5 = c8wfGju4CWZm(url,text)
	elif mode==112: zLZUkrP7ac5 = f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url)
	elif mode==113: zLZUkrP7ac5 = XONC9osGSP4fW5HVrhM(url,True)
	elif mode==114: zLZUkrP7ac5 = ooxUXkcTj5PF4ad2SwYy(url,'FULL_FILTER___'+text)
	elif mode==115: zLZUkrP7ac5 = ooxUXkcTj5PF4ad2SwYy(url,'DEFINED_FILTER___'+text)
	elif mode==116: zLZUkrP7ac5 = XONC9osGSP4fW5HVrhM(url,False)
	elif mode==119: zLZUkrP7ac5 = hm4kawIPKp3oMrC75dJZA9HS2(text)
	else: zLZUkrP7ac5 = False
	return zLZUkrP7ac5
def afkxo7FyZWB4O6K1eXrs5I():
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'بحث في الموقع',HQmDERMFjx,119,HQmDERMFjx,HQmDERMFjx,'_REMEMBERRESULTS_')
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'فلتر محدد',e2VR8nohduY,115)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'فلتر كامل',e2VR8nohduY,114)
	CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'المميزة',e2VR8nohduY,111,HQmDERMFjx,HQmDERMFjx,'featured')
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',e2VR8nohduY,HQmDERMFjx,headers,HQmDERMFjx,HQmDERMFjx,'SHAHID4U-MENU-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('simple-filter(.*?)adv-filter',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if not Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,'موقع شاهد فوريو','البرنامج لم يستطيع إيجاد عنوان الموقع أو تصميم الموقع تغير')
		return
	else:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('location = \'(.*?)\'.*?src="(.*?)".*?<h3>(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for filter,uIGD4vZcP61QNmw78LXqoEpH,title in items:
			url = e2VR8nohduY+filter
			CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+title,url,111,uIGD4vZcP61QNmw78LXqoEpH,HQmDERMFjx,filter)
		CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('class="dropdown"(.*?)<script>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('href="(.*?)".*?>(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,title in items:
			title = title.replace(ti3SbXNV0aJ7n5Grc4OQY8Ll1s9,HQmDERMFjx).replace(GsgOT5Vp6UzIy87bh4vQBWdNjAX3c1,HQmDERMFjx).strip(oQpxmKiRPlHeGsLXNrJF78O)
			if title in FwhZ0nXtpoHTMarf: continue
			if 'http' not in vn1grP3y4It9GmVuBbLJfz2A: vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+vn1grP3y4It9GmVuBbLJfz2A
			if 'netflix' in vn1grP3y4It9GmVuBbLJfz2A: title = 'نيتفلكس'
			CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,111)
	return CzNPJydxQLfw27tv4ZF8KORAbX5
def c8wfGju4CWZm(url,KPloNJnsZ2kpHhum1=HQmDERMFjx,vGXnw9VcUN=HQmDERMFjx):
	if not vGXnw9VcUN: vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,headers,HQmDERMFjx,HQmDERMFjx,'SHAHID4U-TITLES-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1,items,ORMkTYjJ1p7 = [],[],[]
	if KPloNJnsZ2kpHhum1=='featured': Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('glide__slides(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	else: Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('shows-container(.*?)pagination',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if not Ut7reR0XioMjOdYWZKsLIuc3TQJmC1: return
	MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	if not items: items = DyVGS3dX0ZxR.findall('href="(.*?)".*?url\((.*?)\).*?"title">(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	smLQwgO0BynVCcl3fYJ = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for vn1grP3y4It9GmVuBbLJfz2A,uIGD4vZcP61QNmw78LXqoEpH,title in items:
		if 'WWE' in title: continue
		if 'javascript' in vn1grP3y4It9GmVuBbLJfz2A: continue
		vn1grP3y4It9GmVuBbLJfz2A = xx9LK4VzpF6IHXSEyhmrQwbg25P0(vn1grP3y4It9GmVuBbLJfz2A).strip(xufJqQcGnhboiVy2wd)
		title = SVsiEWeRf6oIynqQx8pCrM4Tk(title)
		title = title.strip(oQpxmKiRPlHeGsLXNrJF78O)
		yTz8SOkAhu24j6apo9BmZHvwWsX = DyVGS3dX0ZxR.findall('(.*?) الحلقة \d+',title,DyVGS3dX0ZxR.DOTALL)
		if '/film/' in vn1grP3y4It9GmVuBbLJfz2A or 'فيلم' in vn1grP3y4It9GmVuBbLJfz2A or any(value in title for value in smLQwgO0BynVCcl3fYJ):
			CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,112,uIGD4vZcP61QNmw78LXqoEpH)
		elif yTz8SOkAhu24j6apo9BmZHvwWsX and 'الحلقة' in title and '/list' not in url:
			title = '_MOD_' + yTz8SOkAhu24j6apo9BmZHvwWsX[0]
			if title not in ORMkTYjJ1p7:
				CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,113,uIGD4vZcP61QNmw78LXqoEpH)
				ORMkTYjJ1p7.append(title)
		elif '/actor/' in vn1grP3y4It9GmVuBbLJfz2A:
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,111,uIGD4vZcP61QNmw78LXqoEpH)
		elif '/series/' in vn1grP3y4It9GmVuBbLJfz2A and '/list' not in url:
			vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A+'/list'
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,111,uIGD4vZcP61QNmw78LXqoEpH)
		elif '/list' in url and 'حلقة' in title:
			CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,112,uIGD4vZcP61QNmw78LXqoEpH)
		else: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,113,uIGD4vZcP61QNmw78LXqoEpH)
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"pagination"(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 and KPloNJnsZ2kpHhum1!='featured':
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		if KPloNJnsZ2kpHhum1!='search': items = DyVGS3dX0ZxR.findall('(updateQuery).*?>(.+?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		else: items = DyVGS3dX0ZxR.findall('<li>.*?href="(.*?)">(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		if 'page=' in url: url = url.split('page=',1)[0][:-1]
		for vn1grP3y4It9GmVuBbLJfz2A,title in items:
			title = title.replace(ti3SbXNV0aJ7n5Grc4OQY8Ll1s9,HQmDERMFjx).replace(GsgOT5Vp6UzIy87bh4vQBWdNjAX3c1,HQmDERMFjx)
			title = title.strip(oQpxmKiRPlHeGsLXNrJF78O)
			if KPloNJnsZ2kpHhum1!='search':
				vn1grP3y4It9GmVuBbLJfz2A = url+'&page='+title if '?' in url else url+'?page='+title
			title = SVsiEWeRf6oIynqQx8pCrM4Tk(title)
			if title: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'صفحة '+title,vn1grP3y4It9GmVuBbLJfz2A,111,HQmDERMFjx,HQmDERMFjx,KPloNJnsZ2kpHhum1)
	return
def XONC9osGSP4fW5HVrhM(url,m76GIcBuL4fiHvsF3VpDACQRMeS0):
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,headers,HQmDERMFjx,HQmDERMFjx,'SHAHID4U-EPISODES-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('items d-flex(.*?)</div>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if len(Ut7reR0XioMjOdYWZKsLIuc3TQJmC1)>1:
		if '/season/' in Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]: WTgZPcmVih38IjnSJ2U,EX6nDt50Hih9mIxulw7kpMCZfaOsJR = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0],Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[1]
		else: WTgZPcmVih38IjnSJ2U,EX6nDt50Hih9mIxulw7kpMCZfaOsJR = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[1],Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	else: WTgZPcmVih38IjnSJ2U,EX6nDt50Hih9mIxulw7kpMCZfaOsJR = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0],Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	for DvGaoUZE5S4wxfHc910sz in range(2):
		if m76GIcBuL4fiHvsF3VpDACQRMeS0: mode,type,MJ2gSPyTl9hzoi1 = 116,'folder',WTgZPcmVih38IjnSJ2U
		else: mode,type,MJ2gSPyTl9hzoi1 = 112,'video',EX6nDt50Hih9mIxulw7kpMCZfaOsJR
		items = DyVGS3dX0ZxR.findall('href="(.*?)".*?span.*?">(.*?)<.*?span.*?">(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		if m76GIcBuL4fiHvsF3VpDACQRMeS0 and len(items)<2:
			m76GIcBuL4fiHvsF3VpDACQRMeS0 = False
			continue
		for vn1grP3y4It9GmVuBbLJfz2A,Uo6C7vBYqD9uOS,eyLMq9Enup0jiJT42RDWafg in items:
			title = Uo6C7vBYqD9uOS+oQpxmKiRPlHeGsLXNrJF78O+eyLMq9Enup0jiJT42RDWafg
			CfgK4s13Q0hZcHyleT2bVJO9(type,EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,mode)
		break
	if not items and '/episodes' in CzNPJydxQLfw27tv4ZF8KORAbX5:
		OcECt9hJvjmMWBVwNR2 = DyVGS3dX0ZxR.findall('class="breadcrumb"(.*?)</div>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if OcECt9hJvjmMWBVwNR2:
			MJ2gSPyTl9hzoi1 = OcECt9hJvjmMWBVwNR2[0]
			jzTLleJs8x9Hb1 = DyVGS3dX0ZxR.findall('href="(.*?)"',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
			if len(jzTLleJs8x9Hb1)>2:
				vn1grP3y4It9GmVuBbLJfz2A = jzTLleJs8x9Hb1[2]+'list'
				c8wfGju4CWZm(vn1grP3y4It9GmVuBbLJfz2A)
	return
def f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url):
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(H5x4Z2qPwR8vXM,'GET',url,HQmDERMFjx,headers,HQmDERMFjx,HQmDERMFjx,'SHAHID4U-PLAY-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('class="actions(.*?)</div>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if not Ut7reR0XioMjOdYWZKsLIuc3TQJmC1: return
	MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	jzTLleJs8x9Hb1 = DyVGS3dX0ZxR.findall('href="(.*?)"',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	AAZ5C2Mdirf = '/watch/' in MJ2gSPyTl9hzoi1
	download = '/download/' in MJ2gSPyTl9hzoi1
	if   AAZ5C2Mdirf and not download: wwmEVad1obxMSBXick2zI8qnRpr,otP07csEQAmMKal = jzTLleJs8x9Hb1[0],HQmDERMFjx
	elif not AAZ5C2Mdirf and download: wwmEVad1obxMSBXick2zI8qnRpr,otP07csEQAmMKal = HQmDERMFjx,jzTLleJs8x9Hb1[0]
	elif AAZ5C2Mdirf and download: wwmEVad1obxMSBXick2zI8qnRpr,otP07csEQAmMKal = jzTLleJs8x9Hb1[0],jzTLleJs8x9Hb1[1]
	else: wwmEVad1obxMSBXick2zI8qnRpr,otP07csEQAmMKal = HQmDERMFjx,HQmDERMFjx
	Na8vklCpUGYIzP0bjutWOT = []
	if AAZ5C2Mdirf:
		vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(H5x4Z2qPwR8vXM,'GET',wwmEVad1obxMSBXick2zI8qnRpr,HQmDERMFjx,headers,HQmDERMFjx,HQmDERMFjx,'SHAHID4U-PLAY-2nd')
		b3L20nx7qwHKTS6so = vGXnw9VcUN.content
		vuylTosVej845YfDNK = DyVGS3dX0ZxR.findall('let servers(.*?)player',b3L20nx7qwHKTS6so,DyVGS3dX0ZxR.DOTALL|DyVGS3dX0ZxR.IGNORECASE)
		if vuylTosVej845YfDNK:
			ej8EfB1iZ5Gh3X2gxWtSONH = vuylTosVej845YfDNK[0]
			bbiKcPz2RQOUwS = DyVGS3dX0ZxR.findall('"name":"(.*?)".*?"url":"(.*?)"',ej8EfB1iZ5Gh3X2gxWtSONH,DyVGS3dX0ZxR.DOTALL)
			for title,vn1grP3y4It9GmVuBbLJfz2A in bbiKcPz2RQOUwS:
				vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A.replace('\\/',xufJqQcGnhboiVy2wd)
				vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A+'?named='+title+'__watch'
				Na8vklCpUGYIzP0bjutWOT.append(vn1grP3y4It9GmVuBbLJfz2A)
	if download:
		vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(H5x4Z2qPwR8vXM,'GET',otP07csEQAmMKal,HQmDERMFjx,headers,HQmDERMFjx,HQmDERMFjx,'SHAHID4U-PLAY-3rd')
		b3L20nx7qwHKTS6so = vGXnw9VcUN.content
		vuylTosVej845YfDNK = DyVGS3dX0ZxR.findall('"servers"(.*?)info-container',b3L20nx7qwHKTS6so,DyVGS3dX0ZxR.DOTALL)
		if vuylTosVej845YfDNK:
			ej8EfB1iZ5Gh3X2gxWtSONH = vuylTosVej845YfDNK[0]
			bbiKcPz2RQOUwS = DyVGS3dX0ZxR.findall('href="(.*?)".*?<span>(.*?)<.*?</i>.*?<span>(.*?)<',ej8EfB1iZ5Gh3X2gxWtSONH,DyVGS3dX0ZxR.DOTALL)
			for vn1grP3y4It9GmVuBbLJfz2A,title,RRpfksr1PbZagwCIOJXYNHTo in bbiKcPz2RQOUwS:
				vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A+'?named='+title+'__download'+'____'+RRpfksr1PbZagwCIOJXYNHTo
				Na8vklCpUGYIzP0bjutWOT.append(vn1grP3y4It9GmVuBbLJfz2A)
	import NsD5AomUqH
	NsD5AomUqH.NZcWGBmgFEen5hvJjUSIzOCVk7(Na8vklCpUGYIzP0bjutWOT,HDLtdMAy7wPkl8aKC3O2,'video',url)
	return
def hm4kawIPKp3oMrC75dJZA9HS2(search):
	search,GXVabd4sc2u3zp0JI,showDialogs = x0pzMENwy84tBcZvXr(search)
	if not search:
		search = q156m84QoYrn()
		if not search: return
	search = search.replace(oQpxmKiRPlHeGsLXNrJF78O,'+')
	url = e2VR8nohduY+'/search?s='+search
	c8wfGju4CWZm(url,'search')
	return
def Fhzowv4lbkLBY(url):
	url = url.split('/smartemadfilter?')[0]
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(H5x4Z2qPwR8vXM,'GET',url,HQmDERMFjx,headers,HQmDERMFjx,HQmDERMFjx,'SHAHID4U-GET_FILTERS_BLOCKS-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	jnPZuGqg9F5viBUp = []
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('adv-filter(.*?)shows-container',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		jnPZuGqg9F5viBUp = DyVGS3dX0ZxR.findall('''updateQuery\('(.*?)'.*?value.*?>(.*?)<(.*?)</select''',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		PPxLnY9KDefQulFd5C8vU,szxwkVQTmqev0jGiK78HJIbN4uDOd,bUzHWnGg5t1 = zip(*jnPZuGqg9F5viBUp)
		jnPZuGqg9F5viBUp = zip(szxwkVQTmqev0jGiK78HJIbN4uDOd,PPxLnY9KDefQulFd5C8vU,bUzHWnGg5t1)
	return jnPZuGqg9F5viBUp
def jfcC3ErztgW9dw(MJ2gSPyTl9hzoi1):
	items = DyVGS3dX0ZxR.findall('value="(.*?)".*?>\s*(.*?)\s*<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	return items
def gghkponM41G6TdLBsrS3(url):
	if '/smartemadfilter?' not in url: url = url+'/smartemadfilter?'
	Fewh9HDYiA7jJWS5c6dgr = url.split('/smartemadfilter?')[0]
	EdxGKyuW1mvZSBDf0o947h8Rik = DpClq35GVjh(url,'url')
	url = url.replace(Fewh9HDYiA7jJWS5c6dgr,EdxGKyuW1mvZSBDf0o947h8Rik)
	url = url.replace('/smartemadfilter?','/?')
	return url
XXC6FzPWVjQnMEldGeTLwpxD = ['quality','year','genre','category']
PydiDZOp6H = ['category','genre','year']
def ooxUXkcTj5PF4ad2SwYy(url,filter):
	url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==HQmDERMFjx: eA0pnTuMvxrdmoRC9zPBh,mwhEr8eXxD21MAKfHUSlB = HQmDERMFjx,HQmDERMFjx
	else: eA0pnTuMvxrdmoRC9zPBh,mwhEr8eXxD21MAKfHUSlB = filter.split('___')
	if type=='DEFINED_FILTER':
		if PydiDZOp6H[0]+'=' not in eA0pnTuMvxrdmoRC9zPBh: WF2vkePC5gbXAGUarcqlpmB3Q = PydiDZOp6H[0]
		for yuYts1RONXgp in range(len(PydiDZOp6H[0:-1])):
			if PydiDZOp6H[yuYts1RONXgp]+'=' in eA0pnTuMvxrdmoRC9zPBh: WF2vkePC5gbXAGUarcqlpmB3Q = PydiDZOp6H[yuYts1RONXgp+1]
		Cm5jWJgr28TlUnoZYHAxdPI3OB = eA0pnTuMvxrdmoRC9zPBh+'&'+WF2vkePC5gbXAGUarcqlpmB3Q+'=0'
		RRDtwVh6LbFiEycHNQkId5Cefmq = mwhEr8eXxD21MAKfHUSlB+'&'+WF2vkePC5gbXAGUarcqlpmB3Q+'=0'
		GSPtdslyxQURmB5obg69VJMY1jE = Cm5jWJgr28TlUnoZYHAxdPI3OB.strip('&')+'___'+RRDtwVh6LbFiEycHNQkId5Cefmq.strip('&')
		J4asIxU7Zyq5PiN2rKEctegFV = jlZtWwMfosJFIKenicqU1(mwhEr8eXxD21MAKfHUSlB,'modified_filters')
		SSHjMN4uegZfb2 = url+'/smartemadfilter?'+J4asIxU7Zyq5PiN2rKEctegFV
	elif type=='FULL_FILTER':
		v2s9V6uhIT0aCjkPOl7iUqZxB = jlZtWwMfosJFIKenicqU1(eA0pnTuMvxrdmoRC9zPBh,'modified_values')
		v2s9V6uhIT0aCjkPOl7iUqZxB = xx9LK4VzpF6IHXSEyhmrQwbg25P0(v2s9V6uhIT0aCjkPOl7iUqZxB)
		if mwhEr8eXxD21MAKfHUSlB!=HQmDERMFjx: mwhEr8eXxD21MAKfHUSlB = jlZtWwMfosJFIKenicqU1(mwhEr8eXxD21MAKfHUSlB,'modified_filters')
		if mwhEr8eXxD21MAKfHUSlB==HQmDERMFjx: SSHjMN4uegZfb2 = url
		else: SSHjMN4uegZfb2 = url+'/smartemadfilter?'+mwhEr8eXxD21MAKfHUSlB
		jDcWv7MAkEV = gghkponM41G6TdLBsrS3(SSHjMN4uegZfb2)
		CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'أظهار قائمة الفيديو التي تم اختيارها ',jDcWv7MAkEV,111)
		CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+' [[   '+v2s9V6uhIT0aCjkPOl7iUqZxB+'   ]]',jDcWv7MAkEV,111)
		CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	jnPZuGqg9F5viBUp = Fhzowv4lbkLBY(url)
	dict = {}
	for name,DcpbqKxWsJRCSVkQyjf1,MJ2gSPyTl9hzoi1 in jnPZuGqg9F5viBUp:
		name = name.replace('كل ',HQmDERMFjx)
		items = jfcC3ErztgW9dw(MJ2gSPyTl9hzoi1)
		if '=' not in SSHjMN4uegZfb2: SSHjMN4uegZfb2 = url
		if type=='DEFINED_FILTER':
			if WF2vkePC5gbXAGUarcqlpmB3Q!=DcpbqKxWsJRCSVkQyjf1: continue
			elif len(items)<2:
				if DcpbqKxWsJRCSVkQyjf1==PydiDZOp6H[-1]:
					jDcWv7MAkEV = gghkponM41G6TdLBsrS3(SSHjMN4uegZfb2)
					c8wfGju4CWZm(jDcWv7MAkEV)
				else: ooxUXkcTj5PF4ad2SwYy(SSHjMN4uegZfb2,'DEFINED_FILTER___'+GSPtdslyxQURmB5obg69VJMY1jE)
				return
			else:
				if DcpbqKxWsJRCSVkQyjf1==PydiDZOp6H[-1]:
					jDcWv7MAkEV = gghkponM41G6TdLBsrS3(SSHjMN4uegZfb2)
					CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'الجميع',jDcWv7MAkEV,111)
				else: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'الجميع',SSHjMN4uegZfb2,115,HQmDERMFjx,HQmDERMFjx,GSPtdslyxQURmB5obg69VJMY1jE)
		elif type=='FULL_FILTER':
			Cm5jWJgr28TlUnoZYHAxdPI3OB = eA0pnTuMvxrdmoRC9zPBh+'&'+DcpbqKxWsJRCSVkQyjf1+'=0'
			RRDtwVh6LbFiEycHNQkId5Cefmq = mwhEr8eXxD21MAKfHUSlB+'&'+DcpbqKxWsJRCSVkQyjf1+'=0'
			GSPtdslyxQURmB5obg69VJMY1jE = Cm5jWJgr28TlUnoZYHAxdPI3OB+'___'+RRDtwVh6LbFiEycHNQkId5Cefmq
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'الجميع :'+name,SSHjMN4uegZfb2,114,HQmDERMFjx,HQmDERMFjx,GSPtdslyxQURmB5obg69VJMY1jE)
		dict[DcpbqKxWsJRCSVkQyjf1] = {}
		for value,yewoKb5dkfHu1xEZMAsY in items:
			if value=='196533': yewoKb5dkfHu1xEZMAsY = 'أفلام نيتفلكس'
			elif value=='196531': yewoKb5dkfHu1xEZMAsY = 'مسلسلات نيتفلكس'
			if yewoKb5dkfHu1xEZMAsY in FwhZ0nXtpoHTMarf: continue
			dict[DcpbqKxWsJRCSVkQyjf1][value] = yewoKb5dkfHu1xEZMAsY
			Cm5jWJgr28TlUnoZYHAxdPI3OB = eA0pnTuMvxrdmoRC9zPBh+'&'+DcpbqKxWsJRCSVkQyjf1+'='+yewoKb5dkfHu1xEZMAsY
			RRDtwVh6LbFiEycHNQkId5Cefmq = mwhEr8eXxD21MAKfHUSlB+'&'+DcpbqKxWsJRCSVkQyjf1+'='+value
			CEniUGWr4jMy = Cm5jWJgr28TlUnoZYHAxdPI3OB+'___'+RRDtwVh6LbFiEycHNQkId5Cefmq
			title = yewoKb5dkfHu1xEZMAsY+' :'#+dict[DcpbqKxWsJRCSVkQyjf1]['0']
			title = yewoKb5dkfHu1xEZMAsY+' :'+name
			if type=='FULL_FILTER': CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,url,114,HQmDERMFjx,HQmDERMFjx,CEniUGWr4jMy)
			elif type=='DEFINED_FILTER' and PydiDZOp6H[-2]+'=' in eA0pnTuMvxrdmoRC9zPBh:
				J4asIxU7Zyq5PiN2rKEctegFV = jlZtWwMfosJFIKenicqU1(RRDtwVh6LbFiEycHNQkId5Cefmq,'modified_filters')
				SSHjMN4uegZfb2 = url+'/smartemadfilter?'+J4asIxU7Zyq5PiN2rKEctegFV
				jDcWv7MAkEV = gghkponM41G6TdLBsrS3(SSHjMN4uegZfb2)
				CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,jDcWv7MAkEV,111)
			else: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,url,115,HQmDERMFjx,HQmDERMFjx,CEniUGWr4jMy)
	return
def jlZtWwMfosJFIKenicqU1(Eya9L4IY3GxqtNoVWegDcPuOR,mode):
	Eya9L4IY3GxqtNoVWegDcPuOR = Eya9L4IY3GxqtNoVWegDcPuOR.replace('=&','=0&')
	Eya9L4IY3GxqtNoVWegDcPuOR = Eya9L4IY3GxqtNoVWegDcPuOR.strip('&')
	AAwtDoF34Y890RXse = {}
	if '=' in Eya9L4IY3GxqtNoVWegDcPuOR:
		items = Eya9L4IY3GxqtNoVWegDcPuOR.split('&')
		for A07BpVeRJToLb in items:
			airVhHdqCb6Gf49eERSjv1,value = A07BpVeRJToLb.split('=')
			AAwtDoF34Y890RXse[airVhHdqCb6Gf49eERSjv1] = value
	n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6 = HQmDERMFjx
	for key in XXC6FzPWVjQnMEldGeTLwpxD:
		if key in list(AAwtDoF34Y890RXse.keys()): value = AAwtDoF34Y890RXse[key]
		else: value = '0'
		if '%' not in value: value = VVkOtyQLzxBr(value)
		if mode=='modified_values' and value!='0': n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6 = n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6+' + '+value
		elif mode=='modified_filters' and value!='0': n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6 = n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6+'&'+key+'='+value
		elif mode=='all': n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6 = n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6+'&'+key+'='+value
	n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6 = n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6.strip(' + ')
	n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6 = n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6.strip('&')
	n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6 = n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6.replace('=0','=')
	return n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6
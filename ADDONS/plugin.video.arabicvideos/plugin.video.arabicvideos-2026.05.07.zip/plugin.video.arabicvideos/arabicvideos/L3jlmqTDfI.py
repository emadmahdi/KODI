# -*- coding: utf-8 -*-
from FF68kA5BUy import *
HDLtdMAy7wPkl8aKC3O2 = 'ALARAB'
headers = {'User-Agent':HQmDERMFjx}
EEJvXQzSZNt = '_KLA_'
e2VR8nohduY = Jzthpc2nj5.SITESURLS[HDLtdMAy7wPkl8aKC3O2][0]
def kk6X5LxpsND(mode,url,text):
	if   mode==10: zLZUkrP7ac5 = afkxo7FyZWB4O6K1eXrs5I()
	elif mode==11: zLZUkrP7ac5 = c8wfGju4CWZm(url)
	elif mode==12: zLZUkrP7ac5 = f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url)
	elif mode==13: zLZUkrP7ac5 = XONC9osGSP4fW5HVrhM(url)
	elif mode==14: zLZUkrP7ac5 = dnBbVP3FSUHM6eAow8GDkiZEjWlpm()
	elif mode==15: zLZUkrP7ac5 = A5lo8B4VdYTKUzycZxsrQGgnFtW()
	elif mode==16: zLZUkrP7ac5 = vxAnDqGWVloRdTJgIZPu()
	elif mode==19: zLZUkrP7ac5 = hm4kawIPKp3oMrC75dJZA9HS2(text)
	else: zLZUkrP7ac5 = False
	return zLZUkrP7ac5
def afkxo7FyZWB4O6K1eXrs5I():
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'بحث في الموقع',HQmDERMFjx,19,HQmDERMFjx,HQmDERMFjx,'_REMEMBERRESULTS_')
	CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+'آخر الإضافات',HQmDERMFjx,14)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+'مسلسلات رمضان',HQmDERMFjx,15)
	CzNPJydxQLfw27tv4ZF8KORAbX5 = D0GFPwY8ecAVI(H5x4Z2qPwR8vXM,e2VR8nohduY,HQmDERMFjx,headers,HQmDERMFjx,'ALARAB-MENU-1st')
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1=DyVGS3dX0ZxR.findall('id="nav-slider"(.*?)</div>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	D8aKOjdgRe = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	items = DyVGS3dX0ZxR.findall('href="(.*?)".*?>(.*?)<',D8aKOjdgRe,DyVGS3dX0ZxR.DOTALL)
	for vn1grP3y4It9GmVuBbLJfz2A,title in items:
		vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+vn1grP3y4It9GmVuBbLJfz2A
		title = title.strip(oQpxmKiRPlHeGsLXNrJF78O)
		CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,11)
	CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('id="navbar"(.*?)</div>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	ej8EfB1iZ5Gh3X2gxWtSONH = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	items = DyVGS3dX0ZxR.findall('href="(.*?)".*?>(.*?)<',ej8EfB1iZ5Gh3X2gxWtSONH,DyVGS3dX0ZxR.DOTALL)
	for vn1grP3y4It9GmVuBbLJfz2A,title in items:
		vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+vn1grP3y4It9GmVuBbLJfz2A
		CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,11)
	return CzNPJydxQLfw27tv4ZF8KORAbX5
def A5lo8B4VdYTKUzycZxsrQGgnFtW():
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'جميع المسلسلات العربية',e2VR8nohduY+'/view-8/مسلسلات-عربية',11)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'مسلسلات السنة الأخيرة',HQmDERMFjx,16)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'مسلسلات رمضان الأخيرة 1',e2VR8nohduY+'/view-8/مسلسلات-رمضان-2022',11)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'مسلسلات رمضان الأخيرة 2',e2VR8nohduY+'/view-8/مسلسلات-رمضان-2023',11)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'مسلسلات رمضان 2023',e2VR8nohduY+'/ramadan2023/مصرية',11)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'مسلسلات رمضان 2022',e2VR8nohduY+'/ramadan2022/مصرية',11)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'مسلسلات رمضان 2021',e2VR8nohduY+'/ramadan2021/مصرية',11)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'مسلسلات رمضان 2020',e2VR8nohduY+'/ramadan2020/مصرية',11)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'مسلسلات رمضان 2019',e2VR8nohduY+'/ramadan2019/مصرية',11)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'مسلسلات رمضان 2018',e2VR8nohduY+'/ramadan2018/مصرية',11)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'مسلسلات رمضان 2017',e2VR8nohduY+'/ramadan2017/مصرية',11)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'مسلسلات رمضان 2016',e2VR8nohduY+'/ramadan2016/مصرية',11)
	return
def dnBbVP3FSUHM6eAow8GDkiZEjWlpm():
	CzNPJydxQLfw27tv4ZF8KORAbX5 = D0GFPwY8ecAVI(j9uzmBeEyK8,e2VR8nohduY,HQmDERMFjx,headers,True,'ALARAB-LATEST-1st')
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1=DyVGS3dX0ZxR.findall('heading-top(.*?)div class=',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]+Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[1]
	items=DyVGS3dX0ZxR.findall('href="(.*?)".*?data-src="(.*?)" alt="(.*?)"',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	for vn1grP3y4It9GmVuBbLJfz2A,uIGD4vZcP61QNmw78LXqoEpH,title in items:
		url = e2VR8nohduY + vn1grP3y4It9GmVuBbLJfz2A
		if 'series' in url: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,url,11,uIGD4vZcP61QNmw78LXqoEpH)
		else: CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,url,12,uIGD4vZcP61QNmw78LXqoEpH)
	return
def c8wfGju4CWZm(url):
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,headers,True,True,'ALARAB-TITLES-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('video-category(.*?)right_content',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if not Ut7reR0XioMjOdYWZKsLIuc3TQJmC1: return
	MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	EyvGPbueNt4YUaT93lhj50R = False
	items = DyVGS3dX0ZxR.findall('video-box.*?href="(.*?)".*?src="(http.*?)" alt="(.*?)"',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	ORMkTYjJ1p7,nK0kT8JCEQmXsGB3H = [],[]
	for vn1grP3y4It9GmVuBbLJfz2A,uIGD4vZcP61QNmw78LXqoEpH,title in items:
		if title==HQmDERMFjx: title = vn1grP3y4It9GmVuBbLJfz2A.split(xufJqQcGnhboiVy2wd)[-1].replace('-',oQpxmKiRPlHeGsLXNrJF78O)
		mR2QPcrA3wqT5lONxtunW9J0bj8 = DyVGS3dX0ZxR.findall('(\d+)',title,DyVGS3dX0ZxR.DOTALL)
		if mR2QPcrA3wqT5lONxtunW9J0bj8: mR2QPcrA3wqT5lONxtunW9J0bj8 = int(mR2QPcrA3wqT5lONxtunW9J0bj8[0])
		else: mR2QPcrA3wqT5lONxtunW9J0bj8 = 0
		nK0kT8JCEQmXsGB3H.append([uIGD4vZcP61QNmw78LXqoEpH,vn1grP3y4It9GmVuBbLJfz2A,title,mR2QPcrA3wqT5lONxtunW9J0bj8])
	nK0kT8JCEQmXsGB3H = sorted(nK0kT8JCEQmXsGB3H, reverse=True, key=lambda key: key[3])
	for uIGD4vZcP61QNmw78LXqoEpH,vn1grP3y4It9GmVuBbLJfz2A,title,mR2QPcrA3wqT5lONxtunW9J0bj8 in nK0kT8JCEQmXsGB3H:
		vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY + vn1grP3y4It9GmVuBbLJfz2A
		title = title.replace('مشاهدة مسلسل','مسلسل')
		title = title.replace('مشاهدة المسلسل','المسلسل')
		title = title.replace('مشاهدة فيلم','فيلم')
		title = title.replace('مشاهدة الفيلم','الفيلم')
		title = title.replace('مباشرة كواليتي',HQmDERMFjx)
		title = title.replace('عالية على العرب',HQmDERMFjx)
		title = title.replace('مشاهدة مباشرة',HQmDERMFjx)
		title = title.replace('اون لاين',HQmDERMFjx)
		title = title.replace('اونلاين',HQmDERMFjx)
		title = title.replace('بجودة عالية',HQmDERMFjx)
		title = title.replace('جودة عالية',HQmDERMFjx)
		title = title.replace('بدون تحميل',HQmDERMFjx)
		title = title.replace('على العرب',HQmDERMFjx)
		title = title.replace('مباشرة',HQmDERMFjx)
		title = title.strip(oQpxmKiRPlHeGsLXNrJF78O).replace(MSnXBQNUg1jF3W2fRlE9OLaCT8ds4,oQpxmKiRPlHeGsLXNrJF78O).replace(MSnXBQNUg1jF3W2fRlE9OLaCT8ds4,oQpxmKiRPlHeGsLXNrJF78O)
		title = '_MOD_'+title
		eyLMq9Enup0jiJT42RDWafg = title
		if '/q/' in url and ('الحلقة' in title or 'الحلقه' in title):
			yTz8SOkAhu24j6apo9BmZHvwWsX = DyVGS3dX0ZxR.findall('(.*?) الحلقة \d+',title,DyVGS3dX0ZxR.DOTALL)
			if yTz8SOkAhu24j6apo9BmZHvwWsX: eyLMq9Enup0jiJT42RDWafg = yTz8SOkAhu24j6apo9BmZHvwWsX[0]
		if eyLMq9Enup0jiJT42RDWafg not in ORMkTYjJ1p7:
			ORMkTYjJ1p7.append(eyLMq9Enup0jiJT42RDWafg)
			if '/q/' in url and ('الحلقة' in title or 'الحلقه' in title):
				CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+eyLMq9Enup0jiJT42RDWafg,vn1grP3y4It9GmVuBbLJfz2A,13,uIGD4vZcP61QNmw78LXqoEpH)
				EyvGPbueNt4YUaT93lhj50R = True
			elif 'series' in vn1grP3y4It9GmVuBbLJfz2A:
				CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,11,uIGD4vZcP61QNmw78LXqoEpH)
				EyvGPbueNt4YUaT93lhj50R = True
			else:
				CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,12,uIGD4vZcP61QNmw78LXqoEpH)
				EyvGPbueNt4YUaT93lhj50R = True
	if EyvGPbueNt4YUaT93lhj50R:
		items = DyVGS3dX0ZxR.findall('tsc_3d_button red.*?href="([^"]*)" title="([^"]*)"',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,zmL397efNlks5uTEV in items:
			url = e2VR8nohduY + vn1grP3y4It9GmVuBbLJfz2A
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+zmL397efNlks5uTEV,url,11)
	return
def XONC9osGSP4fW5HVrhM(url):
	CzNPJydxQLfw27tv4ZF8KORAbX5 = D0GFPwY8ecAVI(j9uzmBeEyK8,url,HQmDERMFjx,headers,True,'ALARAB-EPISODES-1st')
	ww3gmiXOLR0S = DyVGS3dX0ZxR.findall('href="(/series.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	SSHjMN4uegZfb2 = e2VR8nohduY+ww3gmiXOLR0S[0]
	zLZUkrP7ac5 = c8wfGju4CWZm(SSHjMN4uegZfb2)
	return
def f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url):
	Na8vklCpUGYIzP0bjutWOT = []
	CzNPJydxQLfw27tv4ZF8KORAbX5 = D0GFPwY8ecAVI(LLwINhcX2RHSWqpmEnz,url,HQmDERMFjx,headers,True,'ALARAB-PLAY-1st')
	SSHjMN4uegZfb2 = DyVGS3dX0ZxR.findall('class="resp-iframe" src="(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if SSHjMN4uegZfb2:
		SSHjMN4uegZfb2 = SSHjMN4uegZfb2[0]
		jzTLleJs8x9Hb1 = DyVGS3dX0ZxR.findall('^(http.*?)(http.*?)$',SSHjMN4uegZfb2,DyVGS3dX0ZxR.DOTALL)
		if jzTLleJs8x9Hb1:
			B1eTDbEXUfs8lqtywGoFC3jRc29 = jzTLleJs8x9Hb1[0][0]
			Ki6uQ8AdH41frzaP9bp32gDmjVqy,ploHkKgIiACXNrqfYO = jzTLleJs8x9Hb1[0][1].rsplit(xufJqQcGnhboiVy2wd,1)
			jDcWv7MAkEV = Ki6uQ8AdH41frzaP9bp32gDmjVqy+'?named=__watch'
			Na8vklCpUGYIzP0bjutWOT.append(jDcWv7MAkEV)
			fVkhY4eGsLdDb = B1eTDbEXUfs8lqtywGoFC3jRc29+ploHkKgIiACXNrqfYO
		else:
			b3L20nx7qwHKTS6so = D0GFPwY8ecAVI(H5x4Z2qPwR8vXM,SSHjMN4uegZfb2,HQmDERMFjx,headers,False,'ALARAB-PLAY-2nd')
			SSHjMN4uegZfb2 = DyVGS3dX0ZxR.findall('"src": "(.*?)"',b3L20nx7qwHKTS6so,DyVGS3dX0ZxR.DOTALL)
			if SSHjMN4uegZfb2:
				SSHjMN4uegZfb2 = SSHjMN4uegZfb2[0]+'?named=__watch__m3u8'
				Na8vklCpUGYIzP0bjutWOT.append(SSHjMN4uegZfb2)
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('searchBox(.*?)<style>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		SSHjMN4uegZfb2 = DyVGS3dX0ZxR.findall('href="(.*?)"',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		if SSHjMN4uegZfb2:
			SSHjMN4uegZfb2 = SSHjMN4uegZfb2[0]+'?named=__watch'
			Na8vklCpUGYIzP0bjutWOT.append(SSHjMN4uegZfb2)
	import NsD5AomUqH
	NsD5AomUqH.NZcWGBmgFEen5hvJjUSIzOCVk7(Na8vklCpUGYIzP0bjutWOT,HDLtdMAy7wPkl8aKC3O2,'video',url)
	return
def vxAnDqGWVloRdTJgIZPu():
	CzNPJydxQLfw27tv4ZF8KORAbX5 = D0GFPwY8ecAVI(H5x4Z2qPwR8vXM,e2VR8nohduY,HQmDERMFjx,headers,True,'ALARAB-RAMADAN-1st')
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('id="content_sec"(.*?)id="left_content"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	items = DyVGS3dX0ZxR.findall('href="(.*?)".*?>(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	SSFzcUtxXsCYIf = DyVGS3dX0ZxR.findall('/ramadan([0-9]+)/',str(items),DyVGS3dX0ZxR.DOTALL)
	SSFzcUtxXsCYIf = SSFzcUtxXsCYIf[0]
	for vn1grP3y4It9GmVuBbLJfz2A,title in items:
		url = e2VR8nohduY+vn1grP3y4It9GmVuBbLJfz2A
		title = title.strip(oQpxmKiRPlHeGsLXNrJF78O)+oQpxmKiRPlHeGsLXNrJF78O+SSFzcUtxXsCYIf
		CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,url,11)
	return
def hm4kawIPKp3oMrC75dJZA9HS2(search):
	search,GXVabd4sc2u3zp0JI,showDialogs = x0pzMENwy84tBcZvXr(search)
	if search==HQmDERMFjx: search = q156m84QoYrn()
	if search==HQmDERMFjx: return
	q5qfEX4yA6lDop1 = search.replace(oQpxmKiRPlHeGsLXNrJF78O,'+')
	url = e2VR8nohduY + "/q/" + q5qfEX4yA6lDop1
	zLZUkrP7ac5 = c8wfGju4CWZm(url)
	return
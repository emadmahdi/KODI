# -*- coding: utf-8 -*-
from FF68kA5BUy import *
NlTos5YhHEcig6yFMn7Qb42zDvq = 'IPTV'
ovnIAFkN3W2yr = '_IPT_'
AAxYkKDhIZpwTVFe = [
		 'IGNORED'
		,'LIVE_UNKNOWN_GROUPED','LIVE_UNKNOWN_GROUPED_SORTED'
		,'VOD_UNKNOWN_GROUPED','VOD_UNKNOWN_GROUPED_SORTED'
		,'LIVE_ARCHIVED_GROUPED_SORTED','LIVE_EPG_GROUPED_SORTED','LIVE_TIMESHIFT_GROUPED_SORTED'
		,'LIVE_GROUPED','LIVE_GROUPED_SORTED'
		,'LIVE_ORIGINAL_GROUPED','LIVE_FROM_GROUP_SORTED','LIVE_FROM_NAME_SORTED'
		,'VOD_MOVIES_GROUPED','VOD_MOVIES_GROUPED_SORTED'
		,'VOD_SERIES_GROUPED','VOD_SERIES_GROUPED_SORTED'
		,'VOD_ORIGINAL_GROUPED','VOD_FROM_GROUP_SORTED','VOD_FROM_NAME_SORTED'
		]
def QyCO8veMRoXDUlzhgd(lXBL3WrM2JFYm,GUiCEYZjm5,NN9niuC7RoqmhkL2,arsOBITUkup7x3eSfEvM,JTMSUFcWn0XQa63GBI9qEAk7,xxwvNBlKpYESrqo0hPcdsutR):
	global ovnIAFkN3W2yr
	try:
		yFgXClRIeSBhm6QVKuYMJ = str(xxwvNBlKpYESrqo0hPcdsutR['folder'])
		ovnIAFkN3W2yr = '_IP'+yFgXClRIeSBhm6QVKuYMJ+'_'
	except: yFgXClRIeSBhm6QVKuYMJ = HQmDERMFjx
	if   lXBL3WrM2JFYm==230: USFh9yauLTlCXb2nZIw5tqQmO4dH = zoiEh3muqXtI()
	elif lXBL3WrM2JFYm==231: USFh9yauLTlCXb2nZIw5tqQmO4dH = tIdcTg4nU7YLEvu9qHWx(yFgXClRIeSBhm6QVKuYMJ)
	elif lXBL3WrM2JFYm==232: USFh9yauLTlCXb2nZIw5tqQmO4dH = FdKcOzDbp3EoY(yFgXClRIeSBhm6QVKuYMJ)
	elif lXBL3WrM2JFYm==233: USFh9yauLTlCXb2nZIw5tqQmO4dH = QQJzovgOaCt5yLFkeN(yFgXClRIeSBhm6QVKuYMJ,GUiCEYZjm5,NN9niuC7RoqmhkL2,JTMSUFcWn0XQa63GBI9qEAk7)
	elif lXBL3WrM2JFYm==234: USFh9yauLTlCXb2nZIw5tqQmO4dH = ddJ6F4hjPOTzKf0ulbQEoq7nwCV2(yFgXClRIeSBhm6QVKuYMJ,GUiCEYZjm5,NN9niuC7RoqmhkL2,JTMSUFcWn0XQa63GBI9qEAk7)
	elif lXBL3WrM2JFYm==235: USFh9yauLTlCXb2nZIw5tqQmO4dH = f0vdEa8oPRTYSesnmNuklQx7I2zXbq(yFgXClRIeSBhm6QVKuYMJ,GUiCEYZjm5,arsOBITUkup7x3eSfEvM)
	elif lXBL3WrM2JFYm==236: USFh9yauLTlCXb2nZIw5tqQmO4dH = zuxQYPmV1Eiqtv(yFgXClRIeSBhm6QVKuYMJ,True)
	elif lXBL3WrM2JFYm==237: USFh9yauLTlCXb2nZIw5tqQmO4dH = KKTv8PfYH3mOrFysU6DQtz9e7ELwu(yFgXClRIeSBhm6QVKuYMJ,True)
	elif lXBL3WrM2JFYm==238: USFh9yauLTlCXb2nZIw5tqQmO4dH = KKeiCBSDcja(yFgXClRIeSBhm6QVKuYMJ,GUiCEYZjm5,NN9niuC7RoqmhkL2)
	elif lXBL3WrM2JFYm==239: USFh9yauLTlCXb2nZIw5tqQmO4dH = MEdwlqBgOsTUp45(NN9niuC7RoqmhkL2,yFgXClRIeSBhm6QVKuYMJ,GUiCEYZjm5,JTMSUFcWn0XQa63GBI9qEAk7)
	elif lXBL3WrM2JFYm==280: USFh9yauLTlCXb2nZIw5tqQmO4dH = oNU0gTtmAYeRpMS(yFgXClRIeSBhm6QVKuYMJ,True)
	elif lXBL3WrM2JFYm==281: USFh9yauLTlCXb2nZIw5tqQmO4dH = x4Yns6HLyqo5DlGRkZ87(yFgXClRIeSBhm6QVKuYMJ)
	elif lXBL3WrM2JFYm==282: USFh9yauLTlCXb2nZIw5tqQmO4dH = IIFEA8COqmspW01X6(yFgXClRIeSBhm6QVKuYMJ)
	elif lXBL3WrM2JFYm==283: USFh9yauLTlCXb2nZIw5tqQmO4dH = zrKdvwQR6caEUyTk(yFgXClRIeSBhm6QVKuYMJ)
	elif lXBL3WrM2JFYm==285: USFh9yauLTlCXb2nZIw5tqQmO4dH = Bae5NXxpfoiJVLCl6(yFgXClRIeSBhm6QVKuYMJ,GUiCEYZjm5,NN9niuC7RoqmhkL2)
	elif lXBL3WrM2JFYm==286: USFh9yauLTlCXb2nZIw5tqQmO4dH = TUfrqGZvPgxVQS0su5zkO(yFgXClRIeSBhm6QVKuYMJ)
	elif lXBL3WrM2JFYm==289: USFh9yauLTlCXb2nZIw5tqQmO4dH = ffRKVxyrgTDd5QFZYiaIGWLjH(NN9niuC7RoqmhkL2,yFgXClRIeSBhm6QVKuYMJ,GUiCEYZjm5,JTMSUFcWn0XQa63GBI9qEAk7)
	else: USFh9yauLTlCXb2nZIw5tqQmO4dH = False
	return USFh9yauLTlCXb2nZIw5tqQmO4dH
def zoiEh3muqXtI():
	for yFgXClRIeSBhm6QVKuYMJ in range(1,L3C1YrQDi840ShlOJcNGe+1):
		ovnIAFkN3W2yr = '_IP'+str(yFgXClRIeSBhm6QVKuYMJ)+'_'
		CfgK4s13Q0hZcHyleT2bVJO9('folder',ovnIAFkN3W2yr+'قائمة مجلد '+ccoph2TqA8fJG4KO6YRwm[yFgXClRIeSBhm6QVKuYMJ],HQmDERMFjx,280,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,{'folder':yFgXClRIeSBhm6QVKuYMJ})
	return
def oNU0gTtmAYeRpMS(yFgXClRIeSBhm6QVKuYMJ=HQmDERMFjx,KKQiYlWruNFZSo=HQmDERMFjx):
	if yFgXClRIeSBhm6QVKuYMJ:
		N017xyu9UO = {'folder':yFgXClRIeSBhm6QVKuYMJ}
		WKw08t4Ajcz1sqPh6vlfEBuHNiX5d = HQmDERMFjx
	else:
		N017xyu9UO = HQmDERMFjx
		WKw08t4Ajcz1sqPh6vlfEBuHNiX5d = HQmDERMFjx
	xufiHJKc2b93ApsDBaYh0mRPe8 = NJUG7VWM1tLgQKBip0d(yFgXClRIeSBhm6QVKuYMJ,KKQiYlWruNFZSo)
	if not xufiHJKc2b93ApsDBaYh0mRPe8:
		CfgK4s13Q0hZcHyleT2bVJO9('link',ovnIAFkN3W2yr+s7d549VgeP+' إضافة أو تغيير اشتراك'+WKw08t4Ajcz1sqPh6vlfEBuHNiX5d+' '+cjqzOQ5GXD4kR,HQmDERMFjx,231,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,N017xyu9UO)
		CfgK4s13Q0hZcHyleT2bVJO9('link',ovnIAFkN3W2yr+s7d549VgeP+' جلب ملفات'+WKw08t4Ajcz1sqPh6vlfEBuHNiX5d+' '+cjqzOQ5GXD4kR,HQmDERMFjx,232,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,N017xyu9UO)
		CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	else:
		CfgK4s13Q0hZcHyleT2bVJO9('folder',ovnIAFkN3W2yr+'بحث في الملفات'+WKw08t4Ajcz1sqPh6vlfEBuHNiX5d,HQmDERMFjx,289,HQmDERMFjx,HQmDERMFjx,'_REMEMBERRESULTS_',HQmDERMFjx,N017xyu9UO)
		CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
		CfgK4s13Q0hZcHyleT2bVJO9('folder',ovnIAFkN3W2yr+'قنوات بدون جلب ملفات','XTREAM_LIVE_GROUPS',285,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,N017xyu9UO)
		CfgK4s13Q0hZcHyleT2bVJO9('folder',ovnIAFkN3W2yr+'قنوات مصنفة مرتبة'+WKw08t4Ajcz1sqPh6vlfEBuHNiX5d,'LIVE_GROUPED_SORTED',233,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,N017xyu9UO)
		CfgK4s13Q0hZcHyleT2bVJO9('folder',ovnIAFkN3W2yr+'قنوات مصنفة من القسم'+WKw08t4Ajcz1sqPh6vlfEBuHNiX5d,'LIVE_FROM_GROUP_SORTED',233,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,N017xyu9UO)
		CfgK4s13Q0hZcHyleT2bVJO9('folder',ovnIAFkN3W2yr+'قنوات مصنفة من الاسم'+WKw08t4Ajcz1sqPh6vlfEBuHNiX5d,'LIVE_FROM_NAME_SORTED',233,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,N017xyu9UO)
		CfgK4s13Q0hZcHyleT2bVJO9('folder',ovnIAFkN3W2yr+'قنوات مصنفة بلا ترتيب'+WKw08t4Ajcz1sqPh6vlfEBuHNiX5d,'LIVE_GROUPED',233,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,N017xyu9UO)
		CfgK4s13Q0hZcHyleT2bVJO9('folder',ovnIAFkN3W2yr+'قنوات بلا ترتيب'+WKw08t4Ajcz1sqPh6vlfEBuHNiX5d,'LIVE_ORIGINAL_GROUPED',233,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,N017xyu9UO)
		CfgK4s13Q0hZcHyleT2bVJO9('folder',ovnIAFkN3W2yr+'قنوات مجهولة مرتبة'+WKw08t4Ajcz1sqPh6vlfEBuHNiX5d,'LIVE_UNKNOWN_GROUPED_SORTED',233,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,N017xyu9UO)
		CfgK4s13Q0hZcHyleT2bVJO9('folder',ovnIAFkN3W2yr+'قنوات مجهولة بلا ترتيب'+WKw08t4Ajcz1sqPh6vlfEBuHNiX5d,'LIVE_UNKNOWN_GROUPED',233,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,N017xyu9UO)
		CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
		CfgK4s13Q0hZcHyleT2bVJO9('folder',ovnIAFkN3W2yr+'أفلام بدون جلب ملفات','XTREAM_VOD_GROUPS',285,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,N017xyu9UO)
		CfgK4s13Q0hZcHyleT2bVJO9('folder',ovnIAFkN3W2yr+'أفلام مصنفة بلا ترتيب'+WKw08t4Ajcz1sqPh6vlfEBuHNiX5d,'VOD_MOVIES_GROUPED',233,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,N017xyu9UO)
		CfgK4s13Q0hZcHyleT2bVJO9('folder',ovnIAFkN3W2yr+'أفلام مصنفة مرتبة'+WKw08t4Ajcz1sqPh6vlfEBuHNiX5d,'VOD_MOVIES_GROUPED_SORTED',233,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,N017xyu9UO)
		CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
		CfgK4s13Q0hZcHyleT2bVJO9('folder',ovnIAFkN3W2yr+'مسلسلات بدون جلب ملفات','XTREAM_SERIES_GROUPS',285,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,N017xyu9UO)
		CfgK4s13Q0hZcHyleT2bVJO9('folder',ovnIAFkN3W2yr+'مسلسلات مصنفة بلا ترتيب'+WKw08t4Ajcz1sqPh6vlfEBuHNiX5d,'VOD_SERIES_GROUPED',233,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,N017xyu9UO)
		CfgK4s13Q0hZcHyleT2bVJO9('folder',ovnIAFkN3W2yr+'مسلسلات مصنفة مرتبة'+WKw08t4Ajcz1sqPh6vlfEBuHNiX5d,'VOD_SERIES_GROUPED_SORTED',233,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,N017xyu9UO)
		CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
		CfgK4s13Q0hZcHyleT2bVJO9('folder',ovnIAFkN3W2yr+'فيديوهات بلا ترتيب'+WKw08t4Ajcz1sqPh6vlfEBuHNiX5d,'VOD_ORIGINAL_GROUPED',233,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,N017xyu9UO)
		CfgK4s13Q0hZcHyleT2bVJO9('folder',ovnIAFkN3W2yr+'فيديوهات مصنفة من القسم'+WKw08t4Ajcz1sqPh6vlfEBuHNiX5d,'VOD_FROM_GROUP_SORTED',233,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,N017xyu9UO)
		CfgK4s13Q0hZcHyleT2bVJO9('folder',ovnIAFkN3W2yr+'فيديوهات مصنفة من الاسم'+WKw08t4Ajcz1sqPh6vlfEBuHNiX5d,'VOD_FROM_NAME_SORTED',233,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,N017xyu9UO)
		CfgK4s13Q0hZcHyleT2bVJO9('folder',ovnIAFkN3W2yr+'فيديوهات مجهولة بلا ترتيب'+WKw08t4Ajcz1sqPh6vlfEBuHNiX5d,'VOD_UNKNOWN_GROUPED',233,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,N017xyu9UO)
		CfgK4s13Q0hZcHyleT2bVJO9('folder',ovnIAFkN3W2yr+'فيديوهات مجهولة مرتبة'+WKw08t4Ajcz1sqPh6vlfEBuHNiX5d,'VOD_UNKNOWN_GROUPED_SORTED',233,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,N017xyu9UO)
		CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
		CfgK4s13Q0hZcHyleT2bVJO9('folder',ovnIAFkN3W2yr+'برامج القنوات (جدول فقط)'+WKw08t4Ajcz1sqPh6vlfEBuHNiX5d,'LIVE_EPG_GROUPED_SORTED',233,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,N017xyu9UO)
		CfgK4s13Q0hZcHyleT2bVJO9('folder',ovnIAFkN3W2yr+'أرشيف القنوات للأيام الماضية'+WKw08t4Ajcz1sqPh6vlfEBuHNiX5d,'LIVE_TIMESHIFT_GROUPED_SORTED',233,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,N017xyu9UO)
		CfgK4s13Q0hZcHyleT2bVJO9('folder',ovnIAFkN3W2yr+'أرشيف برامج القنوات للأيام الماضية'+WKw08t4Ajcz1sqPh6vlfEBuHNiX5d,'LIVE_ARCHIVED_GROUPED_SORTED',233,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,N017xyu9UO)
		CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	CfgK4s13Q0hZcHyleT2bVJO9('link',ovnIAFkN3W2yr+'إضافة أو تغيير اشتراك'+WKw08t4Ajcz1sqPh6vlfEBuHNiX5d,HQmDERMFjx,231,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,N017xyu9UO)
	CfgK4s13Q0hZcHyleT2bVJO9('link',ovnIAFkN3W2yr+'جلب ملفات'+WKw08t4Ajcz1sqPh6vlfEBuHNiX5d,HQmDERMFjx,232,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,N017xyu9UO)
	CfgK4s13Q0hZcHyleT2bVJO9('link',ovnIAFkN3W2yr+'مسح ملفات'+WKw08t4Ajcz1sqPh6vlfEBuHNiX5d,HQmDERMFjx,237,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,N017xyu9UO)
	CfgK4s13Q0hZcHyleT2bVJO9('link',ovnIAFkN3W2yr+'فحص اشتراك'+WKw08t4Ajcz1sqPh6vlfEBuHNiX5d,HQmDERMFjx,236,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,N017xyu9UO)
	CfgK4s13Q0hZcHyleT2bVJO9('link',ovnIAFkN3W2yr+'عدد فيديوهات'+WKw08t4Ajcz1sqPh6vlfEBuHNiX5d,HQmDERMFjx,281,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,N017xyu9UO)
	CfgK4s13Q0hZcHyleT2bVJO9('link',ovnIAFkN3W2yr+'Referer تغيير'+WKw08t4Ajcz1sqPh6vlfEBuHNiX5d,HQmDERMFjx,286,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,N017xyu9UO)
	CfgK4s13Q0hZcHyleT2bVJO9('link',ovnIAFkN3W2yr+'User-Agent تغيير'+WKw08t4Ajcz1sqPh6vlfEBuHNiX5d,HQmDERMFjx,283,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,N017xyu9UO)
	CfgK4s13Q0hZcHyleT2bVJO9('link',ovnIAFkN3W2yr+'استخدم السيرفر الأسرع'+WKw08t4Ajcz1sqPh6vlfEBuHNiX5d,HQmDERMFjx,282,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,N017xyu9UO)
	return
def zuxQYPmV1Eiqtv(yFgXClRIeSBhm6QVKuYMJ,KKQiYlWruNFZSo=True):
	UxHTKvo2Bs9LWe0JrkEVC14wNhp7,E5iuPLgsqjDFMc4 = False,HQmDERMFjx
	BInugzioNsV,lPSfjsuBTgR7q6I9ZcWnUQh1ArLbxY = HQmDERMFjx,HQmDERMFjx
	uIaC4JbUr7YQVhsey0nf,W1x398GwYvCTdPaNLh64r,XjZ6beJF1vH57KUkw2,Vg7Djl1ASx2TftcNevWmHaUq,DDFCVWKHbmg9JtzjT1oU = X3l7NG6egiMtj0u(yFgXClRIeSBhm6QVKuYMJ)
	if Vg7Djl1ASx2TftcNevWmHaUq==HQmDERMFjx: return False,HQmDERMFjx,HQmDERMFjx
	WW2BEsh58O = RGMjHDTLevQ3htNwnkFr1q6z0V85KJ(yFgXClRIeSBhm6QVKuYMJ)
	if uIaC4JbUr7YQVhsey0nf:
		Pmwd7O4bJj82oUSYiBR1hrEkNstXlK = U3GBj7agXTD1Lwze5SvO0H(rwjfOIqQU3ANa0JlWXvCDbFk,'GET',uIaC4JbUr7YQVhsey0nf,HQmDERMFjx,WW2BEsh58O,False,HQmDERMFjx,'IPTV-CHECK_ACCOUNT-1st')
		Y0E2pIKH7s6mbvfSciOBDd = Pmwd7O4bJj82oUSYiBR1hrEkNstXlK.content
		if Pmwd7O4bJj82oUSYiBR1hrEkNstXlK.succeeded:
			BRxOYh3jHXovdbeIPWU28rmc,yMeig5Pw7clqR,SYOl8krmUvXnJqDjHzRxpo7ZsuNiBt,EHDxQl0tdm3ru82TybBvGik1U7,aaZWBCzxpgNSX95GL6RVcP7 = 0,0,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx
			try:
				sL6HIOVb7SmCh235cYuT8tDf4 = aknZqSJyUrFgc9VhH2Psot6e7b8('dict',Y0E2pIKH7s6mbvfSciOBDd)
				E5iuPLgsqjDFMc4 = sL6HIOVb7SmCh235cYuT8tDf4['user_info']['status']
				UxHTKvo2Bs9LWe0JrkEVC14wNhp7 = True
				SYOl8krmUvXnJqDjHzRxpo7ZsuNiBt = sL6HIOVb7SmCh235cYuT8tDf4['server_info']['time_now']
			except: pass
			if SYOl8krmUvXnJqDjHzRxpo7ZsuNiBt:
				try:
					Xm0DJqv1PrlUo29uGORZ3s = jHWkt18govGwY7iUbduAfxCyRc.strptime(SYOl8krmUvXnJqDjHzRxpo7ZsuNiBt,'%Y.%m.%d %H:%M:%S')
					BRxOYh3jHXovdbeIPWU28rmc = int(jHWkt18govGwY7iUbduAfxCyRc.mktime(Xm0DJqv1PrlUo29uGORZ3s))
					yMeig5Pw7clqR = int(ggq0fc2wNbkFOzryxdZae-BRxOYh3jHXovdbeIPWU28rmc)
					yMeig5Pw7clqR = int((yMeig5Pw7clqR+900)/1800)*1800
				except: pass
				try:
					Xm0DJqv1PrlUo29uGORZ3s = jHWkt18govGwY7iUbduAfxCyRc.localtime(int(sL6HIOVb7SmCh235cYuT8tDf4['user_info']['created_at']))
					EHDxQl0tdm3ru82TybBvGik1U7 = jHWkt18govGwY7iUbduAfxCyRc.strftime('%Y.%m.%d %H:%M:%S',Xm0DJqv1PrlUo29uGORZ3s)
				except: pass
				try:
					Xm0DJqv1PrlUo29uGORZ3s = jHWkt18govGwY7iUbduAfxCyRc.localtime(int(sL6HIOVb7SmCh235cYuT8tDf4['user_info']['exp_date']))
					aaZWBCzxpgNSX95GL6RVcP7 = jHWkt18govGwY7iUbduAfxCyRc.strftime('%Y.%m.%d %H:%M:%S',Xm0DJqv1PrlUo29uGORZ3s)
				except: pass
			H8jfvMtXa7Neiu.setSetting('av.iptv.timestamp_'+yFgXClRIeSBhm6QVKuYMJ,str(ggq0fc2wNbkFOzryxdZae))
			H8jfvMtXa7Neiu.setSetting('av.iptv.timediff_'+yFgXClRIeSBhm6QVKuYMJ,str(yMeig5Pw7clqR))
			try:
				OTkS3j0J4YM8nL95 = '"server_info":'+Y0E2pIKH7s6mbvfSciOBDd.split('"server_info":')[1]
				OTkS3j0J4YM8nL95 = OTkS3j0J4YM8nL95.replace(':',': ').replace(',',', ').replace('}}','}')
				elqPSOUu6D81HY4XmMv9w3G5oy0jC2 = DyVGS3dX0ZxR.findall('"url": "(.*?)", "port": "(.*?)"',OTkS3j0J4YM8nL95,DyVGS3dX0ZxR.DOTALL)
				BInugzioNsV,lPSfjsuBTgR7q6I9ZcWnUQh1ArLbxY = elqPSOUu6D81HY4XmMv9w3G5oy0jC2[0]
			except: UxHTKvo2Bs9LWe0JrkEVC14wNhp7 = False
			if UxHTKvo2Bs9LWe0JrkEVC14wNhp7 and KKQiYlWruNFZSo:
				max = sL6HIOVb7SmCh235cYuT8tDf4['user_info']['max_connections']
				uqbtlEUFgG6AYQ = sL6HIOVb7SmCh235cYuT8tDf4['user_info']['active_cons']
				Iq49baTBlAYD38Ni0rsFW2j6J = sL6HIOVb7SmCh235cYuT8tDf4['user_info']['is_trial']
				gAs4BtuGUw2cf = uIaC4JbUr7YQVhsey0nf.split('?',1)
				wwpQTfixYD23X = 'URL:  '+ao3Q5jP8H0sMxK2iUYwZGE+uIaC4JbUr7YQVhsey0nf+cjqzOQ5GXD4kR
				wwpQTfixYD23X += '\n\nStatus:  '+ao3Q5jP8H0sMxK2iUYwZGE+E5iuPLgsqjDFMc4+cjqzOQ5GXD4kR
				wwpQTfixYD23X += '\nTrial:    '+ao3Q5jP8H0sMxK2iUYwZGE+str(Iq49baTBlAYD38Ni0rsFW2j6J=='1')+cjqzOQ5GXD4kR
				wwpQTfixYD23X += '\nCreated  At:  '+ao3Q5jP8H0sMxK2iUYwZGE+EHDxQl0tdm3ru82TybBvGik1U7+cjqzOQ5GXD4kR
				wwpQTfixYD23X += '\nExpiry Date:  '+ao3Q5jP8H0sMxK2iUYwZGE+aaZWBCzxpgNSX95GL6RVcP7+cjqzOQ5GXD4kR
				wwpQTfixYD23X += '\nConnections   ( Active / Maximum ) :  '+ao3Q5jP8H0sMxK2iUYwZGE+uqbtlEUFgG6AYQ+' / '+max+cjqzOQ5GXD4kR
				wwpQTfixYD23X += '\nAllowed Outputs:   '+ao3Q5jP8H0sMxK2iUYwZGE+" , ".join(sL6HIOVb7SmCh235cYuT8tDf4['user_info']['allowed_output_formats'])+cjqzOQ5GXD4kR
				wwpQTfixYD23X += '\n\n'+OTkS3j0J4YM8nL95
				if E5iuPLgsqjDFMc4=='Active': ivtUDrV92ZjEWdHu('الاشتراك يعمل بدون مشاكل',wwpQTfixYD23X)
				else: ivtUDrV92ZjEWdHu('يبدو أن هناك مشكلة في الاشتراك',wwpQTfixYD23X)
	if uIaC4JbUr7YQVhsey0nf and UxHTKvo2Bs9LWe0JrkEVC14wNhp7 and E5iuPLgsqjDFMc4=='Active':
		vv8DyVrLOPAXFIMZ9h(RRWFdpe04EK1Qn,'.\tChecking IPTV URL   [ IPTV account is OK ]   [ '+uIaC4JbUr7YQVhsey0nf+' ]')
		D0WANGMbpv4zXV = True
	else:
		vv8DyVrLOPAXFIMZ9h(GmyBXr3kYHdlvJ,'Checking IPTV URL   [ Does not work ]   [ '+uIaC4JbUr7YQVhsey0nf+' ]')
		if KKQiYlWruNFZSo: u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,'فحص اشتراك ـIPTV','رابط اشتراك ـIPTV الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـIPTV وقم بإضافة رابط ـIPTV جديد أو قم بإصلاح الرابط القديم')
		D0WANGMbpv4zXV = False
	return D0WANGMbpv4zXV,BInugzioNsV,lPSfjsuBTgR7q6I9ZcWnUQh1ArLbxY
def ddJ6F4hjPOTzKf0ulbQEoq7nwCV2(yFgXClRIeSBhm6QVKuYMJ,II6AvVR1hB,lWxyXfM4hRuDg3,XpNdFaq5h7LB1nlx6mMU,KKQiYlWruNFZSo=True):
	if not XpNdFaq5h7LB1nlx6mMU: XpNdFaq5h7LB1nlx6mMU = '1'
	if not NJUG7VWM1tLgQKBip0d(yFgXClRIeSBhm6QVKuYMJ,KKQiYlWruNFZSo): return
	QqCgJmo8LhArijE5kIMc4vXpNad3nx = ALlXpdDjYiTqu4ORc3J(yFgXClRIeSBhm6QVKuYMJ,II6AvVR1hB)
	wUCFk2gAo5KiXxEzscP6OuHTMLrWQ = FcSRPu295Ot1Jv0Bip3IDom(QqCgJmo8LhArijE5kIMc4vXpNad3nx,'list',II6AvVR1hB,lWxyXfM4hRuDg3)
	lywsP8fDGQmKI9Nkv3e1nYS7bJ = int(XpNdFaq5h7LB1nlx6mMU)*100
	mscoIfJ01hdP4UGZzN6eLw = lywsP8fDGQmKI9Nkv3e1nYS7bJ-100
	for wWqEgiB75LpjyPuaDTOU,obS1eBlf0WMLOPDwET8UgCqIJKzm4,GUiCEYZjm5,y2hFMKLYlmwQ9u in wUCFk2gAo5KiXxEzscP6OuHTMLrWQ[mscoIfJ01hdP4UGZzN6eLw:lywsP8fDGQmKI9Nkv3e1nYS7bJ]:
		gWfVJru3lQBT8wP5Y17je = ('GROUPED' in II6AvVR1hB or II6AvVR1hB=='ALL')
		BBM4dE1UlgWfrocR3JXL = ('GROUPED' not in II6AvVR1hB and II6AvVR1hB!='ALL')
		if gWfVJru3lQBT8wP5Y17je or BBM4dE1UlgWfrocR3JXL:
			if   'ARCHIVED'  in II6AvVR1hB: Jzthpc2nj5.menuItemsLIST.append(['folder',ovnIAFkN3W2yr+obS1eBlf0WMLOPDwET8UgCqIJKzm4,GUiCEYZjm5,238,y2hFMKLYlmwQ9u,HQmDERMFjx,'ARCHIVED',HQmDERMFjx,{'folder':yFgXClRIeSBhm6QVKuYMJ}])
			elif 'EPG' 		 in II6AvVR1hB: Jzthpc2nj5.menuItemsLIST.append(['folder',ovnIAFkN3W2yr+obS1eBlf0WMLOPDwET8UgCqIJKzm4,GUiCEYZjm5,238,y2hFMKLYlmwQ9u,HQmDERMFjx,'FULL_EPG',HQmDERMFjx,{'folder':yFgXClRIeSBhm6QVKuYMJ}])
			elif 'TIMESHIFT' in II6AvVR1hB: Jzthpc2nj5.menuItemsLIST.append(['folder',ovnIAFkN3W2yr+obS1eBlf0WMLOPDwET8UgCqIJKzm4,GUiCEYZjm5,238,y2hFMKLYlmwQ9u,HQmDERMFjx,'TIMESHIFT',HQmDERMFjx,{'folder':yFgXClRIeSBhm6QVKuYMJ}])
			elif 'LIVE' 	 in II6AvVR1hB: Jzthpc2nj5.menuItemsLIST.append(['live',ovnIAFkN3W2yr+obS1eBlf0WMLOPDwET8UgCqIJKzm4,GUiCEYZjm5,235,y2hFMKLYlmwQ9u,HQmDERMFjx,HQmDERMFjx,wWqEgiB75LpjyPuaDTOU,{'folder':yFgXClRIeSBhm6QVKuYMJ}])
			else: Jzthpc2nj5.menuItemsLIST.append(['video',ovnIAFkN3W2yr+obS1eBlf0WMLOPDwET8UgCqIJKzm4,GUiCEYZjm5,235,y2hFMKLYlmwQ9u,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,{'folder':yFgXClRIeSBhm6QVKuYMJ}])
	bkVw3mSFtPXz1DWxaYgZKqT0Qp865 = len(wUCFk2gAo5KiXxEzscP6OuHTMLrWQ)
	SjaDEl6u9ZXroLw(yFgXClRIeSBhm6QVKuYMJ,XpNdFaq5h7LB1nlx6mMU,II6AvVR1hB,234,bkVw3mSFtPXz1DWxaYgZKqT0Qp865,lWxyXfM4hRuDg3)
	return
def WxbcoVFqD6pzrUMlJiaAX4w(IIAEepb4GT6BZHcwP7YoQzfL8F):
	CfgK4s13Q0hZcHyleT2bVJO9('link',IIAEepb4GT6BZHcwP7YoQzfL8F+'هذه القائمة إما فارغة أو غير موجودة',HQmDERMFjx,9999)
	CfgK4s13Q0hZcHyleT2bVJO9('link',IIAEepb4GT6BZHcwP7YoQzfL8F+'أو الخدمة غير موجودة في اشتراكك',HQmDERMFjx,9999)
	CfgK4s13Q0hZcHyleT2bVJO9('link',IIAEepb4GT6BZHcwP7YoQzfL8F+'أو رابط IPTVـ الذي أنت أضفته غير صحيح',HQmDERMFjx,9999)
	return
def QQJzovgOaCt5yLFkeN(yFgXClRIeSBhm6QVKuYMJ,II6AvVR1hB,lWxyXfM4hRuDg3,XpNdFaq5h7LB1nlx6mMU,jxpaGgVeSdL7E=HQmDERMFjx,KKQiYlWruNFZSo=True):
	if not XpNdFaq5h7LB1nlx6mMU: XpNdFaq5h7LB1nlx6mMU = '1'
	IIAEepb4GT6BZHcwP7YoQzfL8F = ovnIAFkN3W2yr
	if not NJUG7VWM1tLgQKBip0d(yFgXClRIeSBhm6QVKuYMJ,KKQiYlWruNFZSo): return False
	if '__SERIES__' in lWxyXfM4hRuDg3: n3GZLUmzlkh4Aec9btYM8ydx5X,OdcD9H1lbUZ = lWxyXfM4hRuDg3.split('__SERIES__')
	else: n3GZLUmzlkh4Aec9btYM8ydx5X,OdcD9H1lbUZ = lWxyXfM4hRuDg3,HQmDERMFjx
	QqCgJmo8LhArijE5kIMc4vXpNad3nx = ALlXpdDjYiTqu4ORc3J(yFgXClRIeSBhm6QVKuYMJ,II6AvVR1hB)
	p1ZnSQrVfY2D38tbJRhzWom0eF = FcSRPu295Ot1Jv0Bip3IDom(QqCgJmo8LhArijE5kIMc4vXpNad3nx,'list',II6AvVR1hB,'__GROUPS__')
	if not p1ZnSQrVfY2D38tbJRhzWom0eF: return False
	faZnChjygHtbq7UA5o9EkV = []
	for gQqERUJHSTVe28xWyoKIhPcCDAm,y2hFMKLYlmwQ9u in p1ZnSQrVfY2D38tbJRhzWom0eF:
		if jxpaGgVeSdL7E:
			if '__SERIES__' in gQqERUJHSTVe28xWyoKIhPcCDAm: IIAEepb4GT6BZHcwP7YoQzfL8F = 'SERIES'
			elif '!!__UNKNOWN__!!' in gQqERUJHSTVe28xWyoKIhPcCDAm: IIAEepb4GT6BZHcwP7YoQzfL8F = 'UNKNOWN'
			elif 'LIVE' in II6AvVR1hB: IIAEepb4GT6BZHcwP7YoQzfL8F = 'LIVE'
			else: IIAEepb4GT6BZHcwP7YoQzfL8F = 'VIDEOS'
			IIAEepb4GT6BZHcwP7YoQzfL8F = ','+ao3Q5jP8H0sMxK2iUYwZGE+IIAEepb4GT6BZHcwP7YoQzfL8F+': '+cjqzOQ5GXD4kR
		if '__SERIES__' in gQqERUJHSTVe28xWyoKIhPcCDAm: I0oltSCUu7rN8Fi4sGpMKQ5j61Y2,xBpzg5DJtsU2KQVnyiovak1f = gQqERUJHSTVe28xWyoKIhPcCDAm.split('__SERIES__')
		else: I0oltSCUu7rN8Fi4sGpMKQ5j61Y2,xBpzg5DJtsU2KQVnyiovak1f = gQqERUJHSTVe28xWyoKIhPcCDAm,HQmDERMFjx
		if not lWxyXfM4hRuDg3:
			if I0oltSCUu7rN8Fi4sGpMKQ5j61Y2 in faZnChjygHtbq7UA5o9EkV: continue
			faZnChjygHtbq7UA5o9EkV.append(I0oltSCUu7rN8Fi4sGpMKQ5j61Y2)
			if 'RANDOM' in jxpaGgVeSdL7E: CfgK4s13Q0hZcHyleT2bVJO9('folder',IIAEepb4GT6BZHcwP7YoQzfL8F+I0oltSCUu7rN8Fi4sGpMKQ5j61Y2,II6AvVR1hB,167,HQmDERMFjx,'1',gQqERUJHSTVe28xWyoKIhPcCDAm,HQmDERMFjx,{'folder':yFgXClRIeSBhm6QVKuYMJ})
			elif '__SERIES__' in gQqERUJHSTVe28xWyoKIhPcCDAm: CfgK4s13Q0hZcHyleT2bVJO9('folder',IIAEepb4GT6BZHcwP7YoQzfL8F+I0oltSCUu7rN8Fi4sGpMKQ5j61Y2,II6AvVR1hB,233,HQmDERMFjx,'1',gQqERUJHSTVe28xWyoKIhPcCDAm,HQmDERMFjx,{'folder':yFgXClRIeSBhm6QVKuYMJ})
			else: CfgK4s13Q0hZcHyleT2bVJO9('folder',IIAEepb4GT6BZHcwP7YoQzfL8F+I0oltSCUu7rN8Fi4sGpMKQ5j61Y2,II6AvVR1hB,234,HQmDERMFjx,'1',gQqERUJHSTVe28xWyoKIhPcCDAm,HQmDERMFjx,{'folder':yFgXClRIeSBhm6QVKuYMJ})
		elif '__SERIES__' in gQqERUJHSTVe28xWyoKIhPcCDAm and I0oltSCUu7rN8Fi4sGpMKQ5j61Y2==n3GZLUmzlkh4Aec9btYM8ydx5X:
			if xBpzg5DJtsU2KQVnyiovak1f in faZnChjygHtbq7UA5o9EkV: continue
			faZnChjygHtbq7UA5o9EkV.append(xBpzg5DJtsU2KQVnyiovak1f)
			if 'RANDOM' in jxpaGgVeSdL7E: CfgK4s13Q0hZcHyleT2bVJO9('folder',IIAEepb4GT6BZHcwP7YoQzfL8F+xBpzg5DJtsU2KQVnyiovak1f,II6AvVR1hB,167,HQmDERMFjx,'1',gQqERUJHSTVe28xWyoKIhPcCDAm,HQmDERMFjx,{'folder':yFgXClRIeSBhm6QVKuYMJ})
			else: CfgK4s13Q0hZcHyleT2bVJO9('folder',IIAEepb4GT6BZHcwP7YoQzfL8F+xBpzg5DJtsU2KQVnyiovak1f,II6AvVR1hB,234,y2hFMKLYlmwQ9u,'1',gQqERUJHSTVe28xWyoKIhPcCDAm,HQmDERMFjx,{'folder':yFgXClRIeSBhm6QVKuYMJ})
	Jzthpc2nj5.menuItemsLIST[:] = sorted(Jzthpc2nj5.menuItemsLIST,reverse=False,key=lambda Rinkx4B0rUOXlpFqQuKPC2oA: Rinkx4B0rUOXlpFqQuKPC2oA[1].lower())
	if not jxpaGgVeSdL7E:
		lywsP8fDGQmKI9Nkv3e1nYS7bJ = int(XpNdFaq5h7LB1nlx6mMU)*100
		mscoIfJ01hdP4UGZzN6eLw = lywsP8fDGQmKI9Nkv3e1nYS7bJ-100
		bkVw3mSFtPXz1DWxaYgZKqT0Qp865 = len(Jzthpc2nj5.menuItemsLIST)
		Jzthpc2nj5.menuItemsLIST[:] = Jzthpc2nj5.menuItemsLIST[mscoIfJ01hdP4UGZzN6eLw:lywsP8fDGQmKI9Nkv3e1nYS7bJ]
		SjaDEl6u9ZXroLw(yFgXClRIeSBhm6QVKuYMJ,XpNdFaq5h7LB1nlx6mMU,II6AvVR1hB,233,bkVw3mSFtPXz1DWxaYgZKqT0Qp865,lWxyXfM4hRuDg3)
	return True
def KKeiCBSDcja(yFgXClRIeSBhm6QVKuYMJ,GUiCEYZjm5,lfS37xo0kE2ca1):
	if not NJUG7VWM1tLgQKBip0d(yFgXClRIeSBhm6QVKuYMJ,True): return
	WW2BEsh58O = RGMjHDTLevQ3htNwnkFr1q6z0V85KJ(yFgXClRIeSBhm6QVKuYMJ)
	BRxOYh3jHXovdbeIPWU28rmc = H8jfvMtXa7Neiu.getSetting('av.iptv.timestamp_'+yFgXClRIeSBhm6QVKuYMJ)
	if not BRxOYh3jHXovdbeIPWU28rmc or ggq0fc2wNbkFOzryxdZae-int(BRxOYh3jHXovdbeIPWU28rmc)>24*F2FDLsV4dMtl:
		D0WANGMbpv4zXV,BInugzioNsV,lPSfjsuBTgR7q6I9ZcWnUQh1ArLbxY = zuxQYPmV1Eiqtv(yFgXClRIeSBhm6QVKuYMJ,False)
		if not D0WANGMbpv4zXV: return
	yMeig5Pw7clqR = int(H8jfvMtXa7Neiu.getSetting('av.iptv.timediff_'+yFgXClRIeSBhm6QVKuYMJ))
	XjZ6beJF1vH57KUkw2 = H8jfvMtXa7Neiu.getSetting('av.iptv.server_'+yFgXClRIeSBhm6QVKuYMJ)
	Vg7Djl1ASx2TftcNevWmHaUq = H8jfvMtXa7Neiu.getSetting('av.iptv.username_'+yFgXClRIeSBhm6QVKuYMJ)
	DDFCVWKHbmg9JtzjT1oU = H8jfvMtXa7Neiu.getSetting('av.iptv.password_'+yFgXClRIeSBhm6QVKuYMJ)
	FFxuUCZOQ9SA31D4rW8NR5PwtIbhVj = GUiCEYZjm5.split(xufJqQcGnhboiVy2wd)
	PA15v8JInbkCeQhKZ9pE = FFxuUCZOQ9SA31D4rW8NR5PwtIbhVj[-1].replace('.ts',HQmDERMFjx).replace('.m3u8',HQmDERMFjx)
	if lfS37xo0kE2ca1=='SHORT_EPG': U2UkaZHKR6omeOrfBbF14hsXTS5 = 'get_short_epg'
	else: U2UkaZHKR6omeOrfBbF14hsXTS5 = 'get_simple_data_table'
	uIaC4JbUr7YQVhsey0nf,W1x398GwYvCTdPaNLh64r,XjZ6beJF1vH57KUkw2,Vg7Djl1ASx2TftcNevWmHaUq,DDFCVWKHbmg9JtzjT1oU = X3l7NG6egiMtj0u(yFgXClRIeSBhm6QVKuYMJ)
	if not Vg7Djl1ASx2TftcNevWmHaUq: return
	fadQeci7xPAhRyGYVZNqF = uIaC4JbUr7YQVhsey0nf+'&action='+U2UkaZHKR6omeOrfBbF14hsXTS5+'&stream_id='+PA15v8JInbkCeQhKZ9pE
	Y0E2pIKH7s6mbvfSciOBDd = eQM97xUKjqTl(rwjfOIqQU3ANa0JlWXvCDbFk,fadQeci7xPAhRyGYVZNqF,HQmDERMFjx,WW2BEsh58O,HQmDERMFjx,'IPTV-EPG_ITEMS-2nd')
	CpNFJYK54klMzxtBQiGg69VU2sD1 = aknZqSJyUrFgc9VhH2Psot6e7b8('dict',Y0E2pIKH7s6mbvfSciOBDd)
	JJUz4VN68TtWXQ2RI0Kmoq = CpNFJYK54klMzxtBQiGg69VU2sD1['epg_listings']
	Y2ItMkXQZ8Bf0bSnjADwNWhKHUL = []
	if lfS37xo0kE2ca1 in ['ARCHIVED','TIMESHIFT']:
		for sL6HIOVb7SmCh235cYuT8tDf4 in JJUz4VN68TtWXQ2RI0Kmoq:
			if sL6HIOVb7SmCh235cYuT8tDf4['has_archive']==1:
				Y2ItMkXQZ8Bf0bSnjADwNWhKHUL.append(sL6HIOVb7SmCh235cYuT8tDf4)
				if lfS37xo0kE2ca1 in ['TIMESHIFT']: break
		if not Y2ItMkXQZ8Bf0bSnjADwNWhKHUL: return
		CfgK4s13Q0hZcHyleT2bVJO9('link',ovnIAFkN3W2yr+ao3Q5jP8H0sMxK2iUYwZGE+'الملفات الأولي بهذه القائمة قد لا تعمل'+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
		if lfS37xo0kE2ca1 in ['TIMESHIFT']:
			MMqb9iUyxHBtr4PZKEGenfoVR = 2
			XSvLZaojFIp5 = MMqb9iUyxHBtr4PZKEGenfoVR*F2FDLsV4dMtl
			Y2ItMkXQZ8Bf0bSnjADwNWhKHUL = []
			uP7Q1TjABaHqgZGOSzeW3tph = int(int(sL6HIOVb7SmCh235cYuT8tDf4['start_timestamp'])/XSvLZaojFIp5)*XSvLZaojFIp5
			MulgwsLnY4CJpPIfOyqBG = ggq0fc2wNbkFOzryxdZae+XSvLZaojFIp5
			DrU0OGVd6mqleBLS2zRgEpvI = int((MulgwsLnY4CJpPIfOyqBG-uP7Q1TjABaHqgZGOSzeW3tph)/F2FDLsV4dMtl)
			for BB5K8NCkstbxORuAm in range(DrU0OGVd6mqleBLS2zRgEpvI):
				if BB5K8NCkstbxORuAm>=6:
					if BB5K8NCkstbxORuAm%MMqb9iUyxHBtr4PZKEGenfoVR!=0: continue
					u5NEQMFZdijUpP6oJKOGa8 = XSvLZaojFIp5
				else: u5NEQMFZdijUpP6oJKOGa8 = XSvLZaojFIp5//2
				Nu6pD8TO3Yx1rIEac0nS = uP7Q1TjABaHqgZGOSzeW3tph+BB5K8NCkstbxORuAm*F2FDLsV4dMtl
				sL6HIOVb7SmCh235cYuT8tDf4 = {}
				sL6HIOVb7SmCh235cYuT8tDf4['title'] = HQmDERMFjx
				Xm0DJqv1PrlUo29uGORZ3s = jHWkt18govGwY7iUbduAfxCyRc.localtime(Nu6pD8TO3Yx1rIEac0nS-yMeig5Pw7clqR-F2FDLsV4dMtl)
				sL6HIOVb7SmCh235cYuT8tDf4['start'] = jHWkt18govGwY7iUbduAfxCyRc.strftime('%Y.%m.%d %H:%M:%S',Xm0DJqv1PrlUo29uGORZ3s)
				sL6HIOVb7SmCh235cYuT8tDf4['start_timestamp'] = str(Nu6pD8TO3Yx1rIEac0nS)
				sL6HIOVb7SmCh235cYuT8tDf4['stop_timestamp'] = str(Nu6pD8TO3Yx1rIEac0nS+u5NEQMFZdijUpP6oJKOGa8)
				Y2ItMkXQZ8Bf0bSnjADwNWhKHUL.append(sL6HIOVb7SmCh235cYuT8tDf4)
	elif lfS37xo0kE2ca1 in ['SHORT_EPG','FULL_EPG']: Y2ItMkXQZ8Bf0bSnjADwNWhKHUL = JJUz4VN68TtWXQ2RI0Kmoq
	if lfS37xo0kE2ca1=='FULL_EPG' and len(Y2ItMkXQZ8Bf0bSnjADwNWhKHUL)>0:
		CfgK4s13Q0hZcHyleT2bVJO9('link',ovnIAFkN3W2yr+ao3Q5jP8H0sMxK2iUYwZGE+'هذه قائمة برامج القنوات (جدول فقط)ـ'+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	CNg5meMD4AlkI6FGuwRO2riH1EPqo = []
	y2hFMKLYlmwQ9u = FpGenVlw4Tzxi2WY3JuXcb.getInfoLabel('ListItem.Icon')
	for sL6HIOVb7SmCh235cYuT8tDf4 in Y2ItMkXQZ8Bf0bSnjADwNWhKHUL:
		obS1eBlf0WMLOPDwET8UgCqIJKzm4 = x4aBluXo02G1eTPr9c.b64decode(sL6HIOVb7SmCh235cYuT8tDf4['title'])
		if HH6mxXjgcrEN1aenMFWQkS: obS1eBlf0WMLOPDwET8UgCqIJKzm4 = obS1eBlf0WMLOPDwET8UgCqIJKzm4.decode(Zex6D4tJE52r)
		Nu6pD8TO3Yx1rIEac0nS = int(sL6HIOVb7SmCh235cYuT8tDf4['start_timestamp'])
		E8E4z0Tls169SGNFnX = int(sL6HIOVb7SmCh235cYuT8tDf4['stop_timestamp'])
		iizLZrSjGWEtvNQakM1xs = str(int((E8E4z0Tls169SGNFnX-Nu6pD8TO3Yx1rIEac0nS+59)/60))
		hMbdcTs4HS0OA6w = sL6HIOVb7SmCh235cYuT8tDf4['start'].replace(oQpxmKiRPlHeGsLXNrJF78O,':')
		Xm0DJqv1PrlUo29uGORZ3s = jHWkt18govGwY7iUbduAfxCyRc.localtime(Nu6pD8TO3Yx1rIEac0nS-F2FDLsV4dMtl)
		kxmqZdy2H3aKp9fOwrhV = jHWkt18govGwY7iUbduAfxCyRc.strftime('%H:%M',Xm0DJqv1PrlUo29uGORZ3s)
		K9tmR50ckXLyAPbNJDG2638njafh = jHWkt18govGwY7iUbduAfxCyRc.strftime('%a',Xm0DJqv1PrlUo29uGORZ3s)
		if lfS37xo0kE2ca1=='SHORT_EPG': obS1eBlf0WMLOPDwET8UgCqIJKzm4 = s7d549VgeP+kxmqZdy2H3aKp9fOwrhV+' ـ '+obS1eBlf0WMLOPDwET8UgCqIJKzm4+cjqzOQ5GXD4kR
		elif lfS37xo0kE2ca1=='TIMESHIFT': obS1eBlf0WMLOPDwET8UgCqIJKzm4 = K9tmR50ckXLyAPbNJDG2638njafh+oQpxmKiRPlHeGsLXNrJF78O+kxmqZdy2H3aKp9fOwrhV+' ('+iizLZrSjGWEtvNQakM1xs+'min)'
		else: obS1eBlf0WMLOPDwET8UgCqIJKzm4 = K9tmR50ckXLyAPbNJDG2638njafh+oQpxmKiRPlHeGsLXNrJF78O+kxmqZdy2H3aKp9fOwrhV+' ('+iizLZrSjGWEtvNQakM1xs+'min)   '+obS1eBlf0WMLOPDwET8UgCqIJKzm4+' ـ'
		if lfS37xo0kE2ca1 in ['ARCHIVED','FULL_EPG','TIMESHIFT']:
			FGXYIDNtBdULb76ckuEmyzC9qj5 = XjZ6beJF1vH57KUkw2+'/timeshift/'+Vg7Djl1ASx2TftcNevWmHaUq+xufJqQcGnhboiVy2wd+DDFCVWKHbmg9JtzjT1oU+xufJqQcGnhboiVy2wd+iizLZrSjGWEtvNQakM1xs+xufJqQcGnhboiVy2wd+hMbdcTs4HS0OA6w+xufJqQcGnhboiVy2wd+PA15v8JInbkCeQhKZ9pE+'.m3u8'
			if lfS37xo0kE2ca1=='FULL_EPG': CfgK4s13Q0hZcHyleT2bVJO9('link',ovnIAFkN3W2yr+obS1eBlf0WMLOPDwET8UgCqIJKzm4,FGXYIDNtBdULb76ckuEmyzC9qj5,9999,y2hFMKLYlmwQ9u,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,{'folder':yFgXClRIeSBhm6QVKuYMJ})
			else: CfgK4s13Q0hZcHyleT2bVJO9('video',ovnIAFkN3W2yr+obS1eBlf0WMLOPDwET8UgCqIJKzm4,FGXYIDNtBdULb76ckuEmyzC9qj5,235,y2hFMKLYlmwQ9u,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,{'folder':yFgXClRIeSBhm6QVKuYMJ})
		CNg5meMD4AlkI6FGuwRO2riH1EPqo.append(obS1eBlf0WMLOPDwET8UgCqIJKzm4)
	if lfS37xo0kE2ca1=='SHORT_EPG' and CNg5meMD4AlkI6FGuwRO2riH1EPqo: OwFuAVqbdg0WfhUe8YL = lxyYqQiXjM9EwvHFPA6k2zRVSJe(CNg5meMD4AlkI6FGuwRO2riH1EPqo)
	return CNg5meMD4AlkI6FGuwRO2riH1EPqo
def IIFEA8COqmspW01X6(yFgXClRIeSBhm6QVKuYMJ):
	if not NJUG7VWM1tLgQKBip0d(yFgXClRIeSBhm6QVKuYMJ,True): return
	XjZ6beJF1vH57KUkw2,Ypeam6LKXnhIgHQi,tGxyiKZ0roqdseu = HQmDERMFjx,0,0
	D0WANGMbpv4zXV,BInugzioNsV,lPSfjsuBTgR7q6I9ZcWnUQh1ArLbxY = zuxQYPmV1Eiqtv(yFgXClRIeSBhm6QVKuYMJ,False)
	if D0WANGMbpv4zXV:
		aJbZ75VBvcKhu = zzeUZup9YobgLh1Vt8(BInugzioNsV)
		Ypeam6LKXnhIgHQi = Fz7fkR12ecHOhPj0N5wiU(aJbZ75VBvcKhu[0],int(lPSfjsuBTgR7q6I9ZcWnUQh1ArLbxY))
		QqCgJmo8LhArijE5kIMc4vXpNad3nx = ALlXpdDjYiTqu4ORc3J(yFgXClRIeSBhm6QVKuYMJ,'LIVE_GROUPED')
		vvJHodinpg7LKONDG24MyATVuw = FcSRPu295Ot1Jv0Bip3IDom(QqCgJmo8LhArijE5kIMc4vXpNad3nx,'list','LIVE_GROUPED')
		wUCFk2gAo5KiXxEzscP6OuHTMLrWQ = FcSRPu295Ot1Jv0Bip3IDom(QqCgJmo8LhArijE5kIMc4vXpNad3nx,'list','LIVE_GROUPED',vvJHodinpg7LKONDG24MyATVuw[1])
		GUiCEYZjm5 = wUCFk2gAo5KiXxEzscP6OuHTMLrWQ[0][2]
		WyK2zl415kTEixnZFg3X = DyVGS3dX0ZxR.findall('://(.*?)/',GUiCEYZjm5,DyVGS3dX0ZxR.DOTALL)
		WyK2zl415kTEixnZFg3X = WyK2zl415kTEixnZFg3X[0]
		if ':' in WyK2zl415kTEixnZFg3X: TyBKx8o1LF7Uif3,lX7Vw9Eo2DCcTqOSvJg = WyK2zl415kTEixnZFg3X.split(':')
		else: TyBKx8o1LF7Uif3,lX7Vw9Eo2DCcTqOSvJg = WyK2zl415kTEixnZFg3X,'80'
		zEpD8XKSG69s = zzeUZup9YobgLh1Vt8(TyBKx8o1LF7Uif3)
		tGxyiKZ0roqdseu = Fz7fkR12ecHOhPj0N5wiU(zEpD8XKSG69s[0],int(lX7Vw9Eo2DCcTqOSvJg))
	if Ypeam6LKXnhIgHQi and tGxyiKZ0roqdseu:
		wwpQTfixYD23X = 'هل تريد استخدام السيرفر الأصلي أم السيرفر الأسرع ؟!!'
		wwpQTfixYD23X += '\n\n'+'وقت ضائع في السيرفر الأصلي'+ti3SbXNV0aJ7n5Grc4OQY8Ll1s9+str(int(tGxyiKZ0roqdseu*1000))+' ملي ثانية'
		wwpQTfixYD23X += '\n\n'+'وقت ضائع في السيرفر البديل'+ti3SbXNV0aJ7n5Grc4OQY8Ll1s9+str(int(Ypeam6LKXnhIgHQi*1000))+' ملي ثانية'
		oLUahkgyX95xC6FpDn = HUJZy0SrTbBYv1('center','السيرفر الأصلي','السيرفر الأسرع',OO2BXYhI8UPNq6L,wwpQTfixYD23X)
		if oLUahkgyX95xC6FpDn==1 and Ypeam6LKXnhIgHQi<tGxyiKZ0roqdseu: XjZ6beJF1vH57KUkw2 = BInugzioNsV+':'+lPSfjsuBTgR7q6I9ZcWnUQh1ArLbxY
	else: u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,'البرنامج لم يجد السيرفر البديل')
	H8jfvMtXa7Neiu.setSetting('av.iptv.server_'+yFgXClRIeSBhm6QVKuYMJ,XjZ6beJF1vH57KUkw2)
	return
def f0vdEa8oPRTYSesnmNuklQx7I2zXbq(yFgXClRIeSBhm6QVKuYMJ,GUiCEYZjm5,arsOBITUkup7x3eSfEvM):
	Eag4vYKQOFBT0Vp9XUCAk1RSL3tw = H8jfvMtXa7Neiu.getSetting('av.iptv.useragent_'+yFgXClRIeSBhm6QVKuYMJ)
	e5mbFds8kyl = H8jfvMtXa7Neiu.getSetting('av.iptv.referer_'+yFgXClRIeSBhm6QVKuYMJ)
	if Eag4vYKQOFBT0Vp9XUCAk1RSL3tw or e5mbFds8kyl:
		GUiCEYZjm5 += '|'
		if Eag4vYKQOFBT0Vp9XUCAk1RSL3tw: GUiCEYZjm5 += '&User-Agent='+Eag4vYKQOFBT0Vp9XUCAk1RSL3tw
		if e5mbFds8kyl: GUiCEYZjm5 += '&Referer='+e5mbFds8kyl
		GUiCEYZjm5 = GUiCEYZjm5.replace('|&','|')
	zi4rPchF9IjKqyGBpmnsXVtRAvC3W = H8jfvMtXa7Neiu.getSetting('av.iptv.server_'+yFgXClRIeSBhm6QVKuYMJ)
	if zi4rPchF9IjKqyGBpmnsXVtRAvC3W:
		E2PreFgsSd6yJl3kvVmOWUND4GfaH = DyVGS3dX0ZxR.findall('://(.*?)/',GUiCEYZjm5,DyVGS3dX0ZxR.DOTALL)
		GUiCEYZjm5 = GUiCEYZjm5.replace(E2PreFgsSd6yJl3kvVmOWUND4GfaH[0],zi4rPchF9IjKqyGBpmnsXVtRAvC3W)
	uZVS3DcJbEULoxpve9IOTgmW6(GUiCEYZjm5,NlTos5YhHEcig6yFMn7Qb42zDvq,arsOBITUkup7x3eSfEvM)
	return
def zrKdvwQR6caEUyTk(yFgXClRIeSBhm6QVKuYMJ):
	u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,'تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـIPTV أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـIPTV تحتاج ـUser-Agent خاص')
	Eag4vYKQOFBT0Vp9XUCAk1RSL3tw = H8jfvMtXa7Neiu.getSetting('av.iptv.useragent_'+yFgXClRIeSBhm6QVKuYMJ)
	EiUoLhjwM3RXKBsqC87 = HUJZy0SrTbBYv1('center','استخدام الأصلي','تعديل القديم',Eag4vYKQOFBT0Vp9XUCAk1RSL3tw,'هذا هو ـUser-Agent المستخدم حاليا مع ـIPTV الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـIPTV ؟!')
	if EiUoLhjwM3RXKBsqC87==1: Eag4vYKQOFBT0Vp9XUCAk1RSL3tw = q156m84QoYrn('أكتب ـIPTV User-Agent جديد',Eag4vYKQOFBT0Vp9XUCAk1RSL3tw,True)
	else: Eag4vYKQOFBT0Vp9XUCAk1RSL3tw = 'Unknown'
	if Eag4vYKQOFBT0Vp9XUCAk1RSL3tw==oQpxmKiRPlHeGsLXNrJF78O:
		u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,'غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	EiUoLhjwM3RXKBsqC87 = HUJZy0SrTbBYv1('center',HQmDERMFjx,HQmDERMFjx,Eag4vYKQOFBT0Vp9XUCAk1RSL3tw,'هل تريد استخدام هذا ـUser-Agent بدلا من  القديم ؟')
	if EiUoLhjwM3RXKBsqC87!=1:
		u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,'تم الإلغاء')
		return
	H8jfvMtXa7Neiu.setSetting('av.iptv.useragent_'+yFgXClRIeSBhm6QVKuYMJ,Eag4vYKQOFBT0Vp9XUCAk1RSL3tw)
	uu6OqMGbdP2NKZe3(yFgXClRIeSBhm6QVKuYMJ)
	return
def TUfrqGZvPgxVQS0su5zkO(yFgXClRIeSBhm6QVKuYMJ):
	u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,'تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـIPTV أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـIPTV تحتاج ـReferer خاص')
	e5mbFds8kyl = H8jfvMtXa7Neiu.getSetting('av.iptv.referer_'+yFgXClRIeSBhm6QVKuYMJ)
	EiUoLhjwM3RXKBsqC87 = HUJZy0SrTbBYv1('center','استخدام الأصلي','تعديل القديم',e5mbFds8kyl,'هذا هو ـReferer المستخدم حاليا مع ـIPTV الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـIPTV ؟!')
	if EiUoLhjwM3RXKBsqC87==1: e5mbFds8kyl = q156m84QoYrn('أكتب ـIPTV Referer جديد',e5mbFds8kyl,True)
	else: e5mbFds8kyl = HQmDERMFjx
	if e5mbFds8kyl==oQpxmKiRPlHeGsLXNrJF78O:
		u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,'غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	EiUoLhjwM3RXKBsqC87 = HUJZy0SrTbBYv1('center',HQmDERMFjx,HQmDERMFjx,e5mbFds8kyl,'هل تريد استخدام هذا ـReferer بدلا من  القديم ؟')
	if EiUoLhjwM3RXKBsqC87!=1:
		u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,'تم الإلغاء')
		return
	H8jfvMtXa7Neiu.setSetting('av.iptv.referer_'+yFgXClRIeSBhm6QVKuYMJ,e5mbFds8kyl)
	uu6OqMGbdP2NKZe3(yFgXClRIeSBhm6QVKuYMJ)
	return
def X3l7NG6egiMtj0u(yFgXClRIeSBhm6QVKuYMJ,BJuICgitRHprZ1NSYmV=HQmDERMFjx):
	if not BJuICgitRHprZ1NSYmV: BJuICgitRHprZ1NSYmV = H8jfvMtXa7Neiu.getSetting('av.iptv.url_'+yFgXClRIeSBhm6QVKuYMJ)
	XjZ6beJF1vH57KUkw2 = DpClq35GVjh(BJuICgitRHprZ1NSYmV,'url')
	Vg7Djl1ASx2TftcNevWmHaUq = DyVGS3dX0ZxR.findall('username=(.*?)&',BJuICgitRHprZ1NSYmV+'&',DyVGS3dX0ZxR.DOTALL)
	DDFCVWKHbmg9JtzjT1oU = DyVGS3dX0ZxR.findall('password=(.*?)&',BJuICgitRHprZ1NSYmV+'&',DyVGS3dX0ZxR.DOTALL)
	if not Vg7Djl1ASx2TftcNevWmHaUq or not DDFCVWKHbmg9JtzjT1oU:
		u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,'فحص اشتراك ـIPTV','رابط اشتراك ـIPTV الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـIPTV وقم بإضافة رابط ـIPTV جديد أو قم بإصلاح الرابط القديم')
		return HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx
	Vg7Djl1ASx2TftcNevWmHaUq = Vg7Djl1ASx2TftcNevWmHaUq[0]
	DDFCVWKHbmg9JtzjT1oU = DDFCVWKHbmg9JtzjT1oU[0]
	uIaC4JbUr7YQVhsey0nf = XjZ6beJF1vH57KUkw2+'/player_api.php?username='+Vg7Djl1ASx2TftcNevWmHaUq+'&password='+DDFCVWKHbmg9JtzjT1oU
	W1x398GwYvCTdPaNLh64r = XjZ6beJF1vH57KUkw2+'/get.php?username='+Vg7Djl1ASx2TftcNevWmHaUq+'&password='+DDFCVWKHbmg9JtzjT1oU+'&type=m3u_plus'
	return uIaC4JbUr7YQVhsey0nf,W1x398GwYvCTdPaNLh64r,XjZ6beJF1vH57KUkw2,Vg7Djl1ASx2TftcNevWmHaUq,DDFCVWKHbmg9JtzjT1oU
def jzRwZl7cMLkI(yFgXClRIeSBhm6QVKuYMJ,c2vPNDnW5UYqTodS=HQmDERMFjx):
	hfBQrV8qtM7EHkSKo9cATnpew = c2vPNDnW5UYqTodS.replace(xufJqQcGnhboiVy2wd,'_').replace(':','_').replace('.','_')
	hfBQrV8qtM7EHkSKo9cATnpew = hfBQrV8qtM7EHkSKo9cATnpew.replace('?','_').replace('=','_').replace('&','_')
	hfBQrV8qtM7EHkSKo9cATnpew = S9Y5kUoRga3EVN.path.join(cZeYBhl0CKsg1EwxAXnRVf427F,hfBQrV8qtM7EHkSKo9cATnpew).strip('.m3u')+'.m3u'
	return hfBQrV8qtM7EHkSKo9cATnpew
def tIdcTg4nU7YLEvu9qHWx(yFgXClRIeSBhm6QVKuYMJ):
	yyaLp0Cbe1hYXFfD2SoRJOmr3zEnx9 = H8jfvMtXa7Neiu.getSetting('av.iptv.url_'+yFgXClRIeSBhm6QVKuYMJ)
	AgLmNX8MxIBPkdrs2 = True
	if yyaLp0Cbe1hYXFfD2SoRJOmr3zEnx9:
		EiUoLhjwM3RXKBsqC87 = uumd4lZkWVE81cI7p0eXgtTQjxhHJ('center','كتابة جديد','تعديل القديم','مسح القديم','الرابط الحالي هو:',ao3Q5jP8H0sMxK2iUYwZGE+yyaLp0Cbe1hYXFfD2SoRJOmr3zEnx9+cjqzOQ5GXD4kR+'\n\n هذا هو رابط ـIPTV المسجل في البرنامج ... هل تريد تعديله أم تريد كتابة رابط جديد ؟!')
		if EiUoLhjwM3RXKBsqC87==-1: return
		elif EiUoLhjwM3RXKBsqC87==0: yyaLp0Cbe1hYXFfD2SoRJOmr3zEnx9 = HQmDERMFjx
		elif EiUoLhjwM3RXKBsqC87==2:
			EiUoLhjwM3RXKBsqC87 = HUJZy0SrTbBYv1('center',HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,'هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if EiUoLhjwM3RXKBsqC87 in [-1,0]: return
			u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,'تم مسح الرابط')
			AgLmNX8MxIBPkdrs2 = False
			gjF4rsQ5RK3dE = HQmDERMFjx
	if AgLmNX8MxIBPkdrs2:
		gjF4rsQ5RK3dE = q156m84QoYrn('اكتب رابط ـIPTV كاملا',yyaLp0Cbe1hYXFfD2SoRJOmr3zEnx9)
		gjF4rsQ5RK3dE = gjF4rsQ5RK3dE.strip(oQpxmKiRPlHeGsLXNrJF78O)
		if not gjF4rsQ5RK3dE:
			EiUoLhjwM3RXKBsqC87 = HUJZy0SrTbBYv1('center',HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,'لقد قمت بإدخال رابط فارغ .. هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if EiUoLhjwM3RXKBsqC87 in [-1,0]: return
			u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,'تم مسح الرابط')
	else:
		uIaC4JbUr7YQVhsey0nf,W1x398GwYvCTdPaNLh64r,XjZ6beJF1vH57KUkw2,Vg7Djl1ASx2TftcNevWmHaUq,DDFCVWKHbmg9JtzjT1oU = X3l7NG6egiMtj0u(yFgXClRIeSBhm6QVKuYMJ,gjF4rsQ5RK3dE)
		if not Vg7Djl1ASx2TftcNevWmHaUq: return
		wwpQTfixYD23X = 'هذه المعلومات تم أخذها من رابط ـIPTV الذي انت كتبته . هل تريد استخدامها ؟!\n'
		wwpQTfixYD23X += ti3SbXNV0aJ7n5Grc4OQY8Ll1s9+s7d549VgeP+XjZ6beJF1vH57KUkw2+cjqzOQ5GXD4kR+'عنوان السيرفر: '
		wwpQTfixYD23X += ti3SbXNV0aJ7n5Grc4OQY8Ll1s9+s7d549VgeP+Vg7Djl1ASx2TftcNevWmHaUq+cjqzOQ5GXD4kR+'اسم المستخدم: '
		wwpQTfixYD23X += ti3SbXNV0aJ7n5Grc4OQY8Ll1s9+s7d549VgeP+AtOXmdbGaRP++'كلمة السر: '
		EiUoLhjwM3RXKBsqC87 = HUJZy0SrTbBYv1('right',HQmDERMFjx,HQmDERMFjx,'الرابط الجديد هو:',ao3Q5jP8H0sMxK2iUYwZGE+gjF4rsQ5RK3dE+cjqzOQ5GXD4kR+'\n\n'+wwpQTfixYD23X)
		if EiUoLhjwM3RXKBsqC87!=1:
			u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,'تم الإلغاء')
			return
	H8jfvMtXa7Neiu.setSetting('av.iptv.url_'+yFgXClRIeSBhm6QVKuYMJ,gjF4rsQ5RK3dE)
	H8jfvMtXa7Neiu.setSetting('av.iptv.timestamp_'+yFgXClRIeSBhm6QVKuYMJ,HQmDERMFjx)
	H8jfvMtXa7Neiu.setSetting('av.iptv.timediff_'+yFgXClRIeSBhm6QVKuYMJ,HQmDERMFjx)
	Eag4vYKQOFBT0Vp9XUCAk1RSL3tw = H8jfvMtXa7Neiu.getSetting('av.iptv.useragent_'+yFgXClRIeSBhm6QVKuYMJ)
	if not Eag4vYKQOFBT0Vp9XUCAk1RSL3tw: H8jfvMtXa7Neiu.setSetting('av.iptv.useragent_'+yFgXClRIeSBhm6QVKuYMJ,'Unknown')
	OD0oiLgw5NvZ2 = HUJZy0SrTbBYv1('center',HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,gjF4rsQ5RK3dE+'\n\nتم تغير رابط اشتراك ـIPTV إلى هذا الرابط الجديد ... هل تريد فحص هذا الرابط الآن ؟')
	if OD0oiLgw5NvZ2==1: D0WANGMbpv4zXV,BInugzioNsV,lPSfjsuBTgR7q6I9ZcWnUQh1ArLbxY = zuxQYPmV1Eiqtv(yFgXClRIeSBhm6QVKuYMJ,True)
	uu6OqMGbdP2NKZe3(yFgXClRIeSBhm6QVKuYMJ)
	return
def aSkfTzXBAje0FZhv5oRU81(cYvZWInp7liJCRfKXuG,Y1tLUNIuOly6FDkArZmW,mIdvZP1ylV7cLJtOu6Yikzn0bGW,JMXnYbigT286wDos0RIAqpux9CyFmO,sSAk0x8WbEt3OUDRgVK7wQuJjmvf,UUBHcnTDi521SwmfltGjXVoEz,W1x398GwYvCTdPaNLh64r):
	wUCFk2gAo5KiXxEzscP6OuHTMLrWQ,F5LByUrx62svKdWGp1Z = [],[]
	GpQv9FC2Jf6hoLVqwbHNUzxXnjg = ['.avi','.mp4','.mkv','.mp3','.webm','.aac']
	for Im4LX01gwfluTFQ2cYvrknydpe in cYvZWInp7liJCRfKXuG:
		if UUBHcnTDi521SwmfltGjXVoEz%473==0:
			BwPd4IbMUKZEWAHo0ug8pn(JMXnYbigT286wDos0RIAqpux9CyFmO,40+int(10*UUBHcnTDi521SwmfltGjXVoEz/sSAk0x8WbEt3OUDRgVK7wQuJjmvf),'قراءة الفيديوهات','الفيديو رقم:-',str(UUBHcnTDi521SwmfltGjXVoEz)+' / '+str(sSAk0x8WbEt3OUDRgVK7wQuJjmvf))
			if JMXnYbigT286wDos0RIAqpux9CyFmO.iscanceled():
				JMXnYbigT286wDos0RIAqpux9CyFmO.close()
				return None,None,None
		GUiCEYZjm5 = DyVGS3dX0ZxR.findall('^(.*?)\n+((http|https|rtmp).*?)$',Im4LX01gwfluTFQ2cYvrknydpe,DyVGS3dX0ZxR.DOTALL)
		if GUiCEYZjm5:
			Im4LX01gwfluTFQ2cYvrknydpe,GUiCEYZjm5,Vn2dcZrLCeyMIfKDGgqm0w6jszRp = GUiCEYZjm5[0]
			GUiCEYZjm5 = GUiCEYZjm5.replace(ti3SbXNV0aJ7n5Grc4OQY8Ll1s9,HQmDERMFjx)
			Im4LX01gwfluTFQ2cYvrknydpe = Im4LX01gwfluTFQ2cYvrknydpe.replace(ti3SbXNV0aJ7n5Grc4OQY8Ll1s9,HQmDERMFjx)
		else:
			F5LByUrx62svKdWGp1Z.append({'line':Im4LX01gwfluTFQ2cYvrknydpe})
			continue
		oq7t5DVbNZnAMK,wWqEgiB75LpjyPuaDTOU,gQqERUJHSTVe28xWyoKIhPcCDAm,obS1eBlf0WMLOPDwET8UgCqIJKzm4,arsOBITUkup7x3eSfEvM,PqEbykIGp7e5mUTvCno = {},HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,False
		try:
			Im4LX01gwfluTFQ2cYvrknydpe,obS1eBlf0WMLOPDwET8UgCqIJKzm4 = Im4LX01gwfluTFQ2cYvrknydpe.rsplit('",',1)
			Im4LX01gwfluTFQ2cYvrknydpe = Im4LX01gwfluTFQ2cYvrknydpe+'"'
		except:
			try: Im4LX01gwfluTFQ2cYvrknydpe,obS1eBlf0WMLOPDwET8UgCqIJKzm4 = Im4LX01gwfluTFQ2cYvrknydpe.rsplit('1,',1)
			except: obS1eBlf0WMLOPDwET8UgCqIJKzm4 = HQmDERMFjx
		oq7t5DVbNZnAMK['url'] = GUiCEYZjm5
		hDljImPRMoztQH3ObYyKF = DyVGS3dX0ZxR.findall(' (.*?)="(.*?)"',Im4LX01gwfluTFQ2cYvrknydpe,DyVGS3dX0ZxR.DOTALL)
		for Rinkx4B0rUOXlpFqQuKPC2oA,RrgIp9Xsn5dPufHT in hDljImPRMoztQH3ObYyKF:
			Rinkx4B0rUOXlpFqQuKPC2oA = Rinkx4B0rUOXlpFqQuKPC2oA.replace('"',HQmDERMFjx).strip(oQpxmKiRPlHeGsLXNrJF78O)
			oq7t5DVbNZnAMK[Rinkx4B0rUOXlpFqQuKPC2oA] = RrgIp9Xsn5dPufHT.strip(oQpxmKiRPlHeGsLXNrJF78O)
		jzwaySlhvxqR3pEGWbI6nJ1HDtAXMP = list(oq7t5DVbNZnAMK.keys())
		if not obS1eBlf0WMLOPDwET8UgCqIJKzm4:
			if 'name' in jzwaySlhvxqR3pEGWbI6nJ1HDtAXMP and oq7t5DVbNZnAMK['name']: obS1eBlf0WMLOPDwET8UgCqIJKzm4 = oq7t5DVbNZnAMK['name']
		oq7t5DVbNZnAMK['title'] = obS1eBlf0WMLOPDwET8UgCqIJKzm4.strip(oQpxmKiRPlHeGsLXNrJF78O).replace(MSnXBQNUg1jF3W2fRlE9OLaCT8ds4,oQpxmKiRPlHeGsLXNrJF78O).replace(MSnXBQNUg1jF3W2fRlE9OLaCT8ds4,oQpxmKiRPlHeGsLXNrJF78O)
		if 'logo' in jzwaySlhvxqR3pEGWbI6nJ1HDtAXMP:
			oq7t5DVbNZnAMK['img'] = oq7t5DVbNZnAMK['logo']
			del oq7t5DVbNZnAMK['logo']
		else: oq7t5DVbNZnAMK['img'] = HQmDERMFjx
		if 'group' in jzwaySlhvxqR3pEGWbI6nJ1HDtAXMP and oq7t5DVbNZnAMK['group']: gQqERUJHSTVe28xWyoKIhPcCDAm = oq7t5DVbNZnAMK['group']
		if any(value in GUiCEYZjm5.lower() for value in GpQv9FC2Jf6hoLVqwbHNUzxXnjg):
			PqEbykIGp7e5mUTvCno = True if 'm3u' not in GUiCEYZjm5 else False
		if PqEbykIGp7e5mUTvCno or '__SERIES__' in gQqERUJHSTVe28xWyoKIhPcCDAm or '__MOVIES__' in gQqERUJHSTVe28xWyoKIhPcCDAm:
			arsOBITUkup7x3eSfEvM = 'VOD'
			if '__SERIES__' in gQqERUJHSTVe28xWyoKIhPcCDAm: arsOBITUkup7x3eSfEvM = arsOBITUkup7x3eSfEvM+'_SERIES'
			elif '__MOVIES__' in gQqERUJHSTVe28xWyoKIhPcCDAm: arsOBITUkup7x3eSfEvM = arsOBITUkup7x3eSfEvM+'_MOVIES'
			else: arsOBITUkup7x3eSfEvM = arsOBITUkup7x3eSfEvM+'_UNKNOWN'
			gQqERUJHSTVe28xWyoKIhPcCDAm = gQqERUJHSTVe28xWyoKIhPcCDAm.replace('__SERIES__',HQmDERMFjx).replace('__MOVIES__',HQmDERMFjx)
		else:
			arsOBITUkup7x3eSfEvM = 'LIVE'
			if obS1eBlf0WMLOPDwET8UgCqIJKzm4 in Y1tLUNIuOly6FDkArZmW: wWqEgiB75LpjyPuaDTOU = wWqEgiB75LpjyPuaDTOU+'_EPG'
			if obS1eBlf0WMLOPDwET8UgCqIJKzm4 in mIdvZP1ylV7cLJtOu6Yikzn0bGW: wWqEgiB75LpjyPuaDTOU = wWqEgiB75LpjyPuaDTOU+'_ARCHIVED'
			if not gQqERUJHSTVe28xWyoKIhPcCDAm: arsOBITUkup7x3eSfEvM = arsOBITUkup7x3eSfEvM+'_UNKNOWN'
			else: arsOBITUkup7x3eSfEvM = arsOBITUkup7x3eSfEvM+wWqEgiB75LpjyPuaDTOU
		gQqERUJHSTVe28xWyoKIhPcCDAm = gQqERUJHSTVe28xWyoKIhPcCDAm.strip(oQpxmKiRPlHeGsLXNrJF78O).replace(MSnXBQNUg1jF3W2fRlE9OLaCT8ds4,oQpxmKiRPlHeGsLXNrJF78O).replace(MSnXBQNUg1jF3W2fRlE9OLaCT8ds4,oQpxmKiRPlHeGsLXNrJF78O)
		if 'LIVE_UNKNOWN' in arsOBITUkup7x3eSfEvM: gQqERUJHSTVe28xWyoKIhPcCDAm = '!!__UNKNOWN_LIVE__!!'
		elif 'VOD_UNKNOWN' in arsOBITUkup7x3eSfEvM: gQqERUJHSTVe28xWyoKIhPcCDAm = '!!__UNKNOWN_VOD__!!'
		elif 'VOD_SERIES' in arsOBITUkup7x3eSfEvM:
			atpoK4ME5u = DyVGS3dX0ZxR.findall('(.*?) [Ss]\d+ +[Ee]\d+',oq7t5DVbNZnAMK['title'],DyVGS3dX0ZxR.DOTALL)
			if atpoK4ME5u: atpoK4ME5u = atpoK4ME5u[0]
			else: atpoK4ME5u = '!!__UNKNOWN_SERIES__!!'
			gQqERUJHSTVe28xWyoKIhPcCDAm = gQqERUJHSTVe28xWyoKIhPcCDAm+'__SERIES__'+atpoK4ME5u
		if 'id' in jzwaySlhvxqR3pEGWbI6nJ1HDtAXMP: del oq7t5DVbNZnAMK['id']
		if 'ID' in jzwaySlhvxqR3pEGWbI6nJ1HDtAXMP: del oq7t5DVbNZnAMK['ID']
		if 'name' in jzwaySlhvxqR3pEGWbI6nJ1HDtAXMP: del oq7t5DVbNZnAMK['name']
		obS1eBlf0WMLOPDwET8UgCqIJKzm4 = oq7t5DVbNZnAMK['title']
		obS1eBlf0WMLOPDwET8UgCqIJKzm4 = ArwuTXMNsaO9fmjWdI(obS1eBlf0WMLOPDwET8UgCqIJKzm4)
		obS1eBlf0WMLOPDwET8UgCqIJKzm4 = OtShp9FAKmLPblcqkrBzMTIwd07(obS1eBlf0WMLOPDwET8UgCqIJKzm4)
		uc3DEriqMvOoWbPyK,gQqERUJHSTVe28xWyoKIhPcCDAm = Pu3kSozqYI6r2W1(gQqERUJHSTVe28xWyoKIhPcCDAm)
		OHIXTtM3wFhrVmi,obS1eBlf0WMLOPDwET8UgCqIJKzm4 = Pu3kSozqYI6r2W1(obS1eBlf0WMLOPDwET8UgCqIJKzm4)
		oq7t5DVbNZnAMK['type'] = arsOBITUkup7x3eSfEvM
		oq7t5DVbNZnAMK['context'] = wWqEgiB75LpjyPuaDTOU
		oq7t5DVbNZnAMK['group'] = gQqERUJHSTVe28xWyoKIhPcCDAm.upper()
		oq7t5DVbNZnAMK['title'] = obS1eBlf0WMLOPDwET8UgCqIJKzm4.upper()
		oq7t5DVbNZnAMK['country'] = OHIXTtM3wFhrVmi.upper()
		oq7t5DVbNZnAMK['language'] = uc3DEriqMvOoWbPyK.upper()
		wUCFk2gAo5KiXxEzscP6OuHTMLrWQ.append(oq7t5DVbNZnAMK)
		UUBHcnTDi521SwmfltGjXVoEz += 1
	return wUCFk2gAo5KiXxEzscP6OuHTMLrWQ,UUBHcnTDi521SwmfltGjXVoEz,F5LByUrx62svKdWGp1Z
def OtShp9FAKmLPblcqkrBzMTIwd07(obS1eBlf0WMLOPDwET8UgCqIJKzm4):
	obS1eBlf0WMLOPDwET8UgCqIJKzm4 = obS1eBlf0WMLOPDwET8UgCqIJKzm4.replace(MSnXBQNUg1jF3W2fRlE9OLaCT8ds4,oQpxmKiRPlHeGsLXNrJF78O).replace(MSnXBQNUg1jF3W2fRlE9OLaCT8ds4,oQpxmKiRPlHeGsLXNrJF78O).replace(MSnXBQNUg1jF3W2fRlE9OLaCT8ds4,oQpxmKiRPlHeGsLXNrJF78O)
	obS1eBlf0WMLOPDwET8UgCqIJKzm4 = obS1eBlf0WMLOPDwET8UgCqIJKzm4.replace('||','|').replace('___',':').replace('--','-')
	obS1eBlf0WMLOPDwET8UgCqIJKzm4 = obS1eBlf0WMLOPDwET8UgCqIJKzm4.replace('[[','[').replace(']]',']')
	obS1eBlf0WMLOPDwET8UgCqIJKzm4 = obS1eBlf0WMLOPDwET8UgCqIJKzm4.replace('((','(').replace('))',')')
	obS1eBlf0WMLOPDwET8UgCqIJKzm4 = obS1eBlf0WMLOPDwET8UgCqIJKzm4.replace('<<','<').replace('>>','>')
	obS1eBlf0WMLOPDwET8UgCqIJKzm4 = obS1eBlf0WMLOPDwET8UgCqIJKzm4.strip(oQpxmKiRPlHeGsLXNrJF78O)
	return obS1eBlf0WMLOPDwET8UgCqIJKzm4
def zkHYGFdxib46(Vx6fSAcotNUgr2R,JMXnYbigT286wDos0RIAqpux9CyFmO):
	s9sMhnvmwSRCOD8 = {}
	for jjAmOigbf34w2 in AAxYkKDhIZpwTVFe: s9sMhnvmwSRCOD8[jjAmOigbf34w2] = []
	sSAk0x8WbEt3OUDRgVK7wQuJjmvf = len(Vx6fSAcotNUgr2R)
	ffM6walsPijSKDmonhUE0pxWkAg = str(sSAk0x8WbEt3OUDRgVK7wQuJjmvf)
	UUBHcnTDi521SwmfltGjXVoEz = 0
	F5LByUrx62svKdWGp1Z = []
	for oq7t5DVbNZnAMK in Vx6fSAcotNUgr2R:
		if UUBHcnTDi521SwmfltGjXVoEz%873==0:
			BwPd4IbMUKZEWAHo0ug8pn(JMXnYbigT286wDos0RIAqpux9CyFmO,50+int(5*UUBHcnTDi521SwmfltGjXVoEz/sSAk0x8WbEt3OUDRgVK7wQuJjmvf),'تصنيف الفيديوهات الغير مرتبة','الفيديو رقم:-',str(UUBHcnTDi521SwmfltGjXVoEz)+' / '+ffM6walsPijSKDmonhUE0pxWkAg)
			if JMXnYbigT286wDos0RIAqpux9CyFmO.iscanceled():
				JMXnYbigT286wDos0RIAqpux9CyFmO.close()
				return None,None
		gQqERUJHSTVe28xWyoKIhPcCDAm,wWqEgiB75LpjyPuaDTOU,obS1eBlf0WMLOPDwET8UgCqIJKzm4,GUiCEYZjm5,y2hFMKLYlmwQ9u = oq7t5DVbNZnAMK['group'],oq7t5DVbNZnAMK['context'],oq7t5DVbNZnAMK['title'],oq7t5DVbNZnAMK['url'],oq7t5DVbNZnAMK['img']
		OHIXTtM3wFhrVmi,uc3DEriqMvOoWbPyK,jjAmOigbf34w2 = oq7t5DVbNZnAMK['country'],oq7t5DVbNZnAMK['language'],oq7t5DVbNZnAMK['type']
		HHlsxvb8fAMnmLcQwtg742BRdk0YOh = (gQqERUJHSTVe28xWyoKIhPcCDAm,wWqEgiB75LpjyPuaDTOU,obS1eBlf0WMLOPDwET8UgCqIJKzm4,GUiCEYZjm5,y2hFMKLYlmwQ9u)
		GG8DrcoaKPbdxJAFz7BC = False
		if 'LIVE' in jjAmOigbf34w2:
			if 'UNKNOWN' in jjAmOigbf34w2: s9sMhnvmwSRCOD8['LIVE_UNKNOWN_GROUPED'].append(HHlsxvb8fAMnmLcQwtg742BRdk0YOh)
			elif 'LIVE' in jjAmOigbf34w2: s9sMhnvmwSRCOD8['LIVE_GROUPED'].append(HHlsxvb8fAMnmLcQwtg742BRdk0YOh)
			else: GG8DrcoaKPbdxJAFz7BC = True
			s9sMhnvmwSRCOD8['LIVE_ORIGINAL_GROUPED'].append(HHlsxvb8fAMnmLcQwtg742BRdk0YOh)
		elif 'VOD' in jjAmOigbf34w2:
			if 'UNKNOWN' in jjAmOigbf34w2: s9sMhnvmwSRCOD8['VOD_UNKNOWN_GROUPED'].append(HHlsxvb8fAMnmLcQwtg742BRdk0YOh)
			elif 'MOVIES' in jjAmOigbf34w2: s9sMhnvmwSRCOD8['VOD_MOVIES_GROUPED'].append(HHlsxvb8fAMnmLcQwtg742BRdk0YOh)
			elif 'SERIES' in jjAmOigbf34w2: s9sMhnvmwSRCOD8['VOD_SERIES_GROUPED'].append(HHlsxvb8fAMnmLcQwtg742BRdk0YOh)
			else: GG8DrcoaKPbdxJAFz7BC = True
			s9sMhnvmwSRCOD8['VOD_ORIGINAL_GROUPED'].append(HHlsxvb8fAMnmLcQwtg742BRdk0YOh)
		else: GG8DrcoaKPbdxJAFz7BC = True
		if GG8DrcoaKPbdxJAFz7BC: F5LByUrx62svKdWGp1Z.append(oq7t5DVbNZnAMK)
		UUBHcnTDi521SwmfltGjXVoEz += 1
	VVEhKcNBjg6D798orU5tO4nsif = sorted(Vx6fSAcotNUgr2R,reverse=False,key=lambda Rinkx4B0rUOXlpFqQuKPC2oA: Rinkx4B0rUOXlpFqQuKPC2oA['title'].lower())
	del Vx6fSAcotNUgr2R
	ffM6walsPijSKDmonhUE0pxWkAg = str(sSAk0x8WbEt3OUDRgVK7wQuJjmvf)
	UUBHcnTDi521SwmfltGjXVoEz = 0
	for oq7t5DVbNZnAMK in VVEhKcNBjg6D798orU5tO4nsif:
		UUBHcnTDi521SwmfltGjXVoEz += 1
		if UUBHcnTDi521SwmfltGjXVoEz%873==0:
			BwPd4IbMUKZEWAHo0ug8pn(JMXnYbigT286wDos0RIAqpux9CyFmO,55+int(5*UUBHcnTDi521SwmfltGjXVoEz/sSAk0x8WbEt3OUDRgVK7wQuJjmvf),'تصنيف الفيديوهات المرتبة','الفيديو رقم:-',str(UUBHcnTDi521SwmfltGjXVoEz)+' / '+ffM6walsPijSKDmonhUE0pxWkAg)
			if JMXnYbigT286wDos0RIAqpux9CyFmO.iscanceled():
				JMXnYbigT286wDos0RIAqpux9CyFmO.close()
				return None,None
		jjAmOigbf34w2 = oq7t5DVbNZnAMK['type']
		gQqERUJHSTVe28xWyoKIhPcCDAm,wWqEgiB75LpjyPuaDTOU,obS1eBlf0WMLOPDwET8UgCqIJKzm4,GUiCEYZjm5,y2hFMKLYlmwQ9u = oq7t5DVbNZnAMK['group'],oq7t5DVbNZnAMK['context'],oq7t5DVbNZnAMK['title'],oq7t5DVbNZnAMK['url'],oq7t5DVbNZnAMK['img']
		OHIXTtM3wFhrVmi,uc3DEriqMvOoWbPyK = oq7t5DVbNZnAMK['country'],oq7t5DVbNZnAMK['language']
		GGe28s4gRblAfxdvnpcQLr = (gQqERUJHSTVe28xWyoKIhPcCDAm,wWqEgiB75LpjyPuaDTOU+'_TIMESHIFT',obS1eBlf0WMLOPDwET8UgCqIJKzm4,GUiCEYZjm5,y2hFMKLYlmwQ9u)
		HHlsxvb8fAMnmLcQwtg742BRdk0YOh = (gQqERUJHSTVe28xWyoKIhPcCDAm,wWqEgiB75LpjyPuaDTOU,obS1eBlf0WMLOPDwET8UgCqIJKzm4,GUiCEYZjm5,y2hFMKLYlmwQ9u)
		KWfh97LmnGueiNUV2DPQj40IAb = (OHIXTtM3wFhrVmi,wWqEgiB75LpjyPuaDTOU,obS1eBlf0WMLOPDwET8UgCqIJKzm4,GUiCEYZjm5,y2hFMKLYlmwQ9u)
		RRaMSmOwoPkb = (uc3DEriqMvOoWbPyK,wWqEgiB75LpjyPuaDTOU,obS1eBlf0WMLOPDwET8UgCqIJKzm4,GUiCEYZjm5,y2hFMKLYlmwQ9u)
		if 'LIVE' in jjAmOigbf34w2:
			if 'UNKNOWN' in jjAmOigbf34w2: s9sMhnvmwSRCOD8['LIVE_UNKNOWN_GROUPED_SORTED'].append(HHlsxvb8fAMnmLcQwtg742BRdk0YOh)
			else: s9sMhnvmwSRCOD8['LIVE_GROUPED_SORTED'].append(HHlsxvb8fAMnmLcQwtg742BRdk0YOh)
			if 'EPG'		in jjAmOigbf34w2: s9sMhnvmwSRCOD8['LIVE_EPG_GROUPED_SORTED'].append(HHlsxvb8fAMnmLcQwtg742BRdk0YOh)
			if 'ARCHIVED'	in jjAmOigbf34w2: s9sMhnvmwSRCOD8['LIVE_ARCHIVED_GROUPED_SORTED'].append(HHlsxvb8fAMnmLcQwtg742BRdk0YOh)
			if 'ARCHIVED'	in jjAmOigbf34w2: s9sMhnvmwSRCOD8['LIVE_TIMESHIFT_GROUPED_SORTED'].append(GGe28s4gRblAfxdvnpcQLr)
			s9sMhnvmwSRCOD8['LIVE_FROM_NAME_SORTED'].append(KWfh97LmnGueiNUV2DPQj40IAb)
			s9sMhnvmwSRCOD8['LIVE_FROM_GROUP_SORTED'].append(RRaMSmOwoPkb)
		elif 'VOD' in jjAmOigbf34w2:
			if   'UNKNOWN'	in jjAmOigbf34w2: s9sMhnvmwSRCOD8['VOD_UNKNOWN_GROUPED_SORTED'].append(HHlsxvb8fAMnmLcQwtg742BRdk0YOh)
			elif 'MOVIES'	in jjAmOigbf34w2: s9sMhnvmwSRCOD8['VOD_MOVIES_GROUPED_SORTED'].append(HHlsxvb8fAMnmLcQwtg742BRdk0YOh)
			elif 'SERIES'	in jjAmOigbf34w2: s9sMhnvmwSRCOD8['VOD_SERIES_GROUPED_SORTED'].append(HHlsxvb8fAMnmLcQwtg742BRdk0YOh)
			s9sMhnvmwSRCOD8['VOD_FROM_NAME_SORTED'].append(KWfh97LmnGueiNUV2DPQj40IAb)
			s9sMhnvmwSRCOD8['VOD_FROM_GROUP_SORTED'].append(RRaMSmOwoPkb)
	return s9sMhnvmwSRCOD8,F5LByUrx62svKdWGp1Z
def Pu3kSozqYI6r2W1(obS1eBlf0WMLOPDwET8UgCqIJKzm4):
	if len(obS1eBlf0WMLOPDwET8UgCqIJKzm4)<3: return obS1eBlf0WMLOPDwET8UgCqIJKzm4,obS1eBlf0WMLOPDwET8UgCqIJKzm4
	FGAf0QeViq1YyS4J2LcUT,E9KYXahgmx023wFol = HQmDERMFjx,HQmDERMFjx
	oovMEjpD1HU = obS1eBlf0WMLOPDwET8UgCqIJKzm4
	tJ4znbTgBuZmISNOXrVyfWwh19A6 = obS1eBlf0WMLOPDwET8UgCqIJKzm4[:1]
	iUFOk8jM2aqQfpJ = obS1eBlf0WMLOPDwET8UgCqIJKzm4[1:]
	if   tJ4znbTgBuZmISNOXrVyfWwh19A6=='(': E9KYXahgmx023wFol = ')'
	elif tJ4znbTgBuZmISNOXrVyfWwh19A6=='[': E9KYXahgmx023wFol = ']'
	elif tJ4znbTgBuZmISNOXrVyfWwh19A6=='<': E9KYXahgmx023wFol = '>'
	elif tJ4znbTgBuZmISNOXrVyfWwh19A6=='|': E9KYXahgmx023wFol = '|'
	if E9KYXahgmx023wFol and (E9KYXahgmx023wFol in iUFOk8jM2aqQfpJ):
		WW8eHGONxZbPw,zbaeYdhGMxOQ107WmwZ = iUFOk8jM2aqQfpJ.split(E9KYXahgmx023wFol,1)
		FGAf0QeViq1YyS4J2LcUT = WW8eHGONxZbPw
		oovMEjpD1HU = tJ4znbTgBuZmISNOXrVyfWwh19A6+WW8eHGONxZbPw+E9KYXahgmx023wFol+oQpxmKiRPlHeGsLXNrJF78O+zbaeYdhGMxOQ107WmwZ
	elif obS1eBlf0WMLOPDwET8UgCqIJKzm4.count('|')>=2:
		WW8eHGONxZbPw,zbaeYdhGMxOQ107WmwZ = obS1eBlf0WMLOPDwET8UgCqIJKzm4.split('|',1)
		FGAf0QeViq1YyS4J2LcUT = WW8eHGONxZbPw
		oovMEjpD1HU = WW8eHGONxZbPw+' |'+zbaeYdhGMxOQ107WmwZ
	else:
		E9KYXahgmx023wFol = DyVGS3dX0ZxR.findall('^\w{2}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',obS1eBlf0WMLOPDwET8UgCqIJKzm4,DyVGS3dX0ZxR.DOTALL)
		if not E9KYXahgmx023wFol: E9KYXahgmx023wFol = DyVGS3dX0ZxR.findall('^\w{3}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',obS1eBlf0WMLOPDwET8UgCqIJKzm4,DyVGS3dX0ZxR.DOTALL)
		if not E9KYXahgmx023wFol: E9KYXahgmx023wFol = DyVGS3dX0ZxR.findall('^\w{4}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',obS1eBlf0WMLOPDwET8UgCqIJKzm4,DyVGS3dX0ZxR.DOTALL)
		if E9KYXahgmx023wFol:
			WW8eHGONxZbPw,zbaeYdhGMxOQ107WmwZ = obS1eBlf0WMLOPDwET8UgCqIJKzm4.split(E9KYXahgmx023wFol[0],1)
			FGAf0QeViq1YyS4J2LcUT = WW8eHGONxZbPw
			oovMEjpD1HU = WW8eHGONxZbPw+oQpxmKiRPlHeGsLXNrJF78O+E9KYXahgmx023wFol[0]+oQpxmKiRPlHeGsLXNrJF78O+zbaeYdhGMxOQ107WmwZ
	oovMEjpD1HU = oovMEjpD1HU.replace(xoZHpTRUzS9,oQpxmKiRPlHeGsLXNrJF78O).replace(MSnXBQNUg1jF3W2fRlE9OLaCT8ds4,oQpxmKiRPlHeGsLXNrJF78O)
	FGAf0QeViq1YyS4J2LcUT = FGAf0QeViq1YyS4J2LcUT.replace(MSnXBQNUg1jF3W2fRlE9OLaCT8ds4,oQpxmKiRPlHeGsLXNrJF78O)
	if not FGAf0QeViq1YyS4J2LcUT: FGAf0QeViq1YyS4J2LcUT = '!!__UNKNOWN__!!'
	FGAf0QeViq1YyS4J2LcUT = FGAf0QeViq1YyS4J2LcUT.strip(oQpxmKiRPlHeGsLXNrJF78O)
	oovMEjpD1HU = oovMEjpD1HU.strip(oQpxmKiRPlHeGsLXNrJF78O)
	return FGAf0QeViq1YyS4J2LcUT,oovMEjpD1HU
def RGMjHDTLevQ3htNwnkFr1q6z0V85KJ(yFgXClRIeSBhm6QVKuYMJ):
	WW2BEsh58O = {}
	Eag4vYKQOFBT0Vp9XUCAk1RSL3tw = H8jfvMtXa7Neiu.getSetting('av.iptv.useragent_'+yFgXClRIeSBhm6QVKuYMJ)
	if Eag4vYKQOFBT0Vp9XUCAk1RSL3tw: WW2BEsh58O['User-Agent'] = Eag4vYKQOFBT0Vp9XUCAk1RSL3tw
	e5mbFds8kyl = H8jfvMtXa7Neiu.getSetting('av.iptv.referer_'+yFgXClRIeSBhm6QVKuYMJ)
	if e5mbFds8kyl: WW2BEsh58O['Referer'] = e5mbFds8kyl
	return WW2BEsh58O
def FdKcOzDbp3EoY(yFgXClRIeSBhm6QVKuYMJ):
	global JMXnYbigT286wDos0RIAqpux9CyFmO,s9sMhnvmwSRCOD8,D5BWrfX1monOtA84Cv0Q7MLFcb,JkAyQjIlDEoiTmKVZdCXPWx37,romMBNWIL2il,vvJHodinpg7LKONDG24MyATVuw,W3NhXgAHwp,M3D9RwXlt8Wovx4,p7tbqOEHxR6lyw9GoB0fjVih
	uIaC4JbUr7YQVhsey0nf,W1x398GwYvCTdPaNLh64r,XjZ6beJF1vH57KUkw2,Vg7Djl1ASx2TftcNevWmHaUq,DDFCVWKHbmg9JtzjT1oU = X3l7NG6egiMtj0u(yFgXClRIeSBhm6QVKuYMJ)
	if not Vg7Djl1ASx2TftcNevWmHaUq: return
	WW2BEsh58O = RGMjHDTLevQ3htNwnkFr1q6z0V85KJ(yFgXClRIeSBhm6QVKuYMJ)
	oLUahkgyX95xC6FpDn = HUJZy0SrTbBYv1('center',HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,'جلب ملفات ـIPTV جديدة قد تحتاج عدة دقائق . هل تريد أن تجلب الملفات الآن ؟')
	if oLUahkgyX95xC6FpDn!=1: return
	hfBQrV8qtM7EHkSKo9cATnpew = ffOXNqsbi9ZScTH7EKg2B.replace('___','_'+yFgXClRIeSBhm6QVKuYMJ)
	if 1:
		D0WANGMbpv4zXV,BInugzioNsV,lPSfjsuBTgR7q6I9ZcWnUQh1ArLbxY = zuxQYPmV1Eiqtv(yFgXClRIeSBhm6QVKuYMJ,False)
		if not D0WANGMbpv4zXV:
			u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,'فشل بسحب ملفات ـIPTV . أحتمال رابط ـIPTV غير صحيح أو قديم أو لا يعمل .. علما أن هذه الخدمة تحتاج اشتراك مدفوع وصحيح ويجب أن تضيف رابط الاشتراك بنفسك للبرنامج باستخدام قائمة ـIPTV الموجودة بهذا البرنامج')
			if not W1x398GwYvCTdPaNLh64r: vv8DyVrLOPAXFIMZ9h(GmyBXr3kYHdlvJ,LLe5QGmjCZigv(NlTos5YhHEcig6yFMn7Qb42zDvq)+'   No IPTV URL found to download IPTV files')
			else: vv8DyVrLOPAXFIMZ9h(GmyBXr3kYHdlvJ,LLe5QGmjCZigv(NlTos5YhHEcig6yFMn7Qb42zDvq)+'   Failed to download IPTV files')
			return
		c0hNpWtVjuklOimKs6IQ = I3InS4QiTJ5K(W1x398GwYvCTdPaNLh64r,WW2BEsh58O,True)
		if not c0hNpWtVjuklOimKs6IQ: return
		open(hfBQrV8qtM7EHkSKo9cATnpew,'wb').write(c0hNpWtVjuklOimKs6IQ)
	else: c0hNpWtVjuklOimKs6IQ = open(hfBQrV8qtM7EHkSKo9cATnpew,'rb').read()
	if HH6mxXjgcrEN1aenMFWQkS and c0hNpWtVjuklOimKs6IQ: c0hNpWtVjuklOimKs6IQ = c0hNpWtVjuklOimKs6IQ.decode(Zex6D4tJE52r)
	JMXnYbigT286wDos0RIAqpux9CyFmO = uu2bfv7V3FS()
	JMXnYbigT286wDos0RIAqpux9CyFmO.create('جلب ملفات ـIPTV جديدة',HQmDERMFjx)
	BwPd4IbMUKZEWAHo0ug8pn(JMXnYbigT286wDos0RIAqpux9CyFmO,15,'تنظيف الملف الرئيسي',HQmDERMFjx)
	c0hNpWtVjuklOimKs6IQ = c0hNpWtVjuklOimKs6IQ.replace('"tvg-','" tvg-')
	c0hNpWtVjuklOimKs6IQ = c0hNpWtVjuklOimKs6IQ.replace('َ',HQmDERMFjx).replace('ً',HQmDERMFjx).replace('ُ',HQmDERMFjx).replace('ٌ',HQmDERMFjx)
	c0hNpWtVjuklOimKs6IQ = c0hNpWtVjuklOimKs6IQ.replace('ّ',HQmDERMFjx).replace('ِ',HQmDERMFjx).replace('ٍ',HQmDERMFjx).replace('ْ',HQmDERMFjx)
	c0hNpWtVjuklOimKs6IQ = c0hNpWtVjuklOimKs6IQ.replace('group-title=','group=').replace('tvg-',HQmDERMFjx)
	mIdvZP1ylV7cLJtOu6Yikzn0bGW,Y1tLUNIuOly6FDkArZmW = [],[]
	BwPd4IbMUKZEWAHo0ug8pn(JMXnYbigT286wDos0RIAqpux9CyFmO,20,'جلب الملفات الثانوية','الملف رقم:-','1 / 3')
	if JMXnYbigT286wDos0RIAqpux9CyFmO.iscanceled():
		JMXnYbigT286wDos0RIAqpux9CyFmO.close()
		return
	GUiCEYZjm5 = uIaC4JbUr7YQVhsey0nf+'&action=get_series_categories'
	Pmwd7O4bJj82oUSYiBR1hrEkNstXlK = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',GUiCEYZjm5,HQmDERMFjx,WW2BEsh58O,HQmDERMFjx,HQmDERMFjx,'IPTV-CREATE_STREAMS-1st')
	Y0E2pIKH7s6mbvfSciOBDd = Pmwd7O4bJj82oUSYiBR1hrEkNstXlK.content
	Y0E2pIKH7s6mbvfSciOBDd = ArwuTXMNsaO9fmjWdI(Y0E2pIKH7s6mbvfSciOBDd)
	CBmoTuRPraLc = DyVGS3dX0ZxR.findall('category_name":"(.*?)"',Y0E2pIKH7s6mbvfSciOBDd,DyVGS3dX0ZxR.DOTALL)
	del Y0E2pIKH7s6mbvfSciOBDd
	for gQqERUJHSTVe28xWyoKIhPcCDAm in CBmoTuRPraLc:
		gQqERUJHSTVe28xWyoKIhPcCDAm = gQqERUJHSTVe28xWyoKIhPcCDAm.replace('\/',xufJqQcGnhboiVy2wd)
		if C6H1qXua3SMQiIrzxNvJWZE: gQqERUJHSTVe28xWyoKIhPcCDAm = gQqERUJHSTVe28xWyoKIhPcCDAm.decode(Zex6D4tJE52r).encode(Zex6D4tJE52r)
		c0hNpWtVjuklOimKs6IQ = c0hNpWtVjuklOimKs6IQ.replace('group="'+gQqERUJHSTVe28xWyoKIhPcCDAm+'"','group="__SERIES__'+gQqERUJHSTVe28xWyoKIhPcCDAm+'"')
	del CBmoTuRPraLc
	BwPd4IbMUKZEWAHo0ug8pn(JMXnYbigT286wDos0RIAqpux9CyFmO,25,'جلب الملفات الثانوية','الملف رقم:-','2 / 3')
	if JMXnYbigT286wDos0RIAqpux9CyFmO.iscanceled():
		JMXnYbigT286wDos0RIAqpux9CyFmO.close()
		return
	GUiCEYZjm5 = uIaC4JbUr7YQVhsey0nf+'&action=get_vod_categories'
	Pmwd7O4bJj82oUSYiBR1hrEkNstXlK = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',GUiCEYZjm5,HQmDERMFjx,WW2BEsh58O,HQmDERMFjx,HQmDERMFjx,'IPTV-CREATE_STREAMS-2nd')
	Y0E2pIKH7s6mbvfSciOBDd = Pmwd7O4bJj82oUSYiBR1hrEkNstXlK.content
	Y0E2pIKH7s6mbvfSciOBDd = ArwuTXMNsaO9fmjWdI(Y0E2pIKH7s6mbvfSciOBDd)
	Zc0PRQEoUIu21aBbGgdkOxh8eC = DyVGS3dX0ZxR.findall('category_name":"(.*?)"',Y0E2pIKH7s6mbvfSciOBDd,DyVGS3dX0ZxR.DOTALL)
	del Y0E2pIKH7s6mbvfSciOBDd
	for gQqERUJHSTVe28xWyoKIhPcCDAm in Zc0PRQEoUIu21aBbGgdkOxh8eC:
		gQqERUJHSTVe28xWyoKIhPcCDAm = gQqERUJHSTVe28xWyoKIhPcCDAm.replace('\/',xufJqQcGnhboiVy2wd)
		if C6H1qXua3SMQiIrzxNvJWZE: gQqERUJHSTVe28xWyoKIhPcCDAm = gQqERUJHSTVe28xWyoKIhPcCDAm.decode(Zex6D4tJE52r).encode(Zex6D4tJE52r)
		c0hNpWtVjuklOimKs6IQ = c0hNpWtVjuklOimKs6IQ.replace('group="'+gQqERUJHSTVe28xWyoKIhPcCDAm+'"','group="__MOVIES__'+gQqERUJHSTVe28xWyoKIhPcCDAm+'"')
	del Zc0PRQEoUIu21aBbGgdkOxh8eC
	BwPd4IbMUKZEWAHo0ug8pn(JMXnYbigT286wDos0RIAqpux9CyFmO,30,'جلب الملفات الثانوية','الملف رقم:-','3 / 3')
	if JMXnYbigT286wDos0RIAqpux9CyFmO.iscanceled():
		JMXnYbigT286wDos0RIAqpux9CyFmO.close()
		return
	GUiCEYZjm5 = uIaC4JbUr7YQVhsey0nf+'&action=get_live_streams'
	Pmwd7O4bJj82oUSYiBR1hrEkNstXlK = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',GUiCEYZjm5,HQmDERMFjx,WW2BEsh58O,HQmDERMFjx,HQmDERMFjx,'IPTV-CREATE_STREAMS-3rd')
	Y0E2pIKH7s6mbvfSciOBDd = Pmwd7O4bJj82oUSYiBR1hrEkNstXlK.content
	Y0E2pIKH7s6mbvfSciOBDd = ArwuTXMNsaO9fmjWdI(Y0E2pIKH7s6mbvfSciOBDd)
	b3bGcxBpkV = DyVGS3dX0ZxR.findall('"name":"(.*?)".*?"tv_archive":(.*?),',Y0E2pIKH7s6mbvfSciOBDd,DyVGS3dX0ZxR.DOTALL)
	for XyOvPTlmBK4hDVjfi,ppfjARk8y2ONDPB7rg6 in b3bGcxBpkV:
		if ppfjARk8y2ONDPB7rg6=='1': mIdvZP1ylV7cLJtOu6Yikzn0bGW.append(XyOvPTlmBK4hDVjfi)
	del b3bGcxBpkV
	mULwCZKY8Juzv5s26dE0ia1RxDk = DyVGS3dX0ZxR.findall('"name":"(.*?)".*?"epg_channel_id":(.*?),',Y0E2pIKH7s6mbvfSciOBDd,DyVGS3dX0ZxR.DOTALL)
	del Y0E2pIKH7s6mbvfSciOBDd
	for XyOvPTlmBK4hDVjfi,lCBP5TDujtJ8pd in mULwCZKY8Juzv5s26dE0ia1RxDk:
		if lCBP5TDujtJ8pd!='null': Y1tLUNIuOly6FDkArZmW.append(XyOvPTlmBK4hDVjfi)
	del mULwCZKY8Juzv5s26dE0ia1RxDk
	c0hNpWtVjuklOimKs6IQ = c0hNpWtVjuklOimKs6IQ.replace(GsgOT5Vp6UzIy87bh4vQBWdNjAX3c1,ti3SbXNV0aJ7n5Grc4OQY8Ll1s9)
	cYvZWInp7liJCRfKXuG = DyVGS3dX0ZxR.findall('NF:(.+?)'+'#'+'EXTI',c0hNpWtVjuklOimKs6IQ+'\n+'+'#'+'EXTINF:',DyVGS3dX0ZxR.DOTALL)
	if not cYvZWInp7liJCRfKXuG:
		vv8DyVrLOPAXFIMZ9h(GmyBXr3kYHdlvJ,LLe5QGmjCZigv(NlTos5YhHEcig6yFMn7Qb42zDvq)+'   Folder:'+yFgXClRIeSBhm6QVKuYMJ+'   No video links found in IPTV file')
		u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,'رابط ـIPTV الذي أنت أضفته لا توجد فيه فيديوهات .. احتمال رابط ـIPTV غير صحيح'+ti3SbXNV0aJ7n5Grc4OQY8Ll1s9+s7d549VgeP+'مجلد رقم '+yFgXClRIeSBhm6QVKuYMJ)
		JMXnYbigT286wDos0RIAqpux9CyFmO.close()
		return
	Fe95otXKaApg4WmhY6TfZ = []
	for Im4LX01gwfluTFQ2cYvrknydpe in cYvZWInp7liJCRfKXuG:
		pBVOLUAx3PlNdb98qrMXiS6 = Im4LX01gwfluTFQ2cYvrknydpe.lower()
		if 'adult' in pBVOLUAx3PlNdb98qrMXiS6: continue
		if 'xxx' in pBVOLUAx3PlNdb98qrMXiS6: continue
		Fe95otXKaApg4WmhY6TfZ.append(Im4LX01gwfluTFQ2cYvrknydpe)
	cYvZWInp7liJCRfKXuG = Fe95otXKaApg4WmhY6TfZ
	del Fe95otXKaApg4WmhY6TfZ
	ktRTPQhWI17VnaM9u = 1024*1024
	jMuwG2qskUciLbQW0z4A7YKtO9 = 1+len(c0hNpWtVjuklOimKs6IQ)//ktRTPQhWI17VnaM9u//10
	del c0hNpWtVjuklOimKs6IQ
	OoAbn349U60dahVHBISGrEfYi1 = len(cYvZWInp7liJCRfKXuG)
	q7DmtxiQ5EcWr = gLmys74Xo0NQ8kpYqWrJ9PfVt6vB(cYvZWInp7liJCRfKXuG,jMuwG2qskUciLbQW0z4A7YKtO9)
	del cYvZWInp7liJCRfKXuG
	for OLRSzDCVZUm in range(jMuwG2qskUciLbQW0z4A7YKtO9):
		BwPd4IbMUKZEWAHo0ug8pn(JMXnYbigT286wDos0RIAqpux9CyFmO,35+int(5*OLRSzDCVZUm/jMuwG2qskUciLbQW0z4A7YKtO9),'تقطيع الملف الرئيسي','الجزء رقم:-',str(OLRSzDCVZUm+1)+' / '+str(jMuwG2qskUciLbQW0z4A7YKtO9))
		if JMXnYbigT286wDos0RIAqpux9CyFmO.iscanceled():
			JMXnYbigT286wDos0RIAqpux9CyFmO.close()
			return
		HZLE8pSw0h175GPd = str(q7DmtxiQ5EcWr[OLRSzDCVZUm])
		if HH6mxXjgcrEN1aenMFWQkS: HZLE8pSw0h175GPd = HZLE8pSw0h175GPd.encode(Zex6D4tJE52r)
		open(hfBQrV8qtM7EHkSKo9cATnpew+'.00'+str(OLRSzDCVZUm),'wb').write(HZLE8pSw0h175GPd)
	del q7DmtxiQ5EcWr,HZLE8pSw0h175GPd
	YPyxhWRKDLJSNFMOQ5Ae,Vx6fSAcotNUgr2R,UUBHcnTDi521SwmfltGjXVoEz = [],[],0
	for OLRSzDCVZUm in range(jMuwG2qskUciLbQW0z4A7YKtO9):
		if JMXnYbigT286wDos0RIAqpux9CyFmO.iscanceled():
			JMXnYbigT286wDos0RIAqpux9CyFmO.close()
			return
		HZLE8pSw0h175GPd = open(hfBQrV8qtM7EHkSKo9cATnpew+'.00'+str(OLRSzDCVZUm),'rb').read()
		jHWkt18govGwY7iUbduAfxCyRc.sleep(1)
		try: S9Y5kUoRga3EVN.remove(hfBQrV8qtM7EHkSKo9cATnpew+'.00'+str(OLRSzDCVZUm))
		except: pass
		if HH6mxXjgcrEN1aenMFWQkS: HZLE8pSw0h175GPd = HZLE8pSw0h175GPd.decode(Zex6D4tJE52r)
		MMwWvjhYcnVbJzxmtLaTpkgqO = aknZqSJyUrFgc9VhH2Psot6e7b8('list',HZLE8pSw0h175GPd)
		del HZLE8pSw0h175GPd
		wUCFk2gAo5KiXxEzscP6OuHTMLrWQ,UUBHcnTDi521SwmfltGjXVoEz,F5LByUrx62svKdWGp1Z = aSkfTzXBAje0FZhv5oRU81(MMwWvjhYcnVbJzxmtLaTpkgqO,Y1tLUNIuOly6FDkArZmW,mIdvZP1ylV7cLJtOu6Yikzn0bGW,JMXnYbigT286wDos0RIAqpux9CyFmO,OoAbn349U60dahVHBISGrEfYi1,UUBHcnTDi521SwmfltGjXVoEz,W1x398GwYvCTdPaNLh64r)
		if JMXnYbigT286wDos0RIAqpux9CyFmO.iscanceled():
			JMXnYbigT286wDos0RIAqpux9CyFmO.close()
			return
		if not wUCFk2gAo5KiXxEzscP6OuHTMLrWQ:
			JMXnYbigT286wDos0RIAqpux9CyFmO.close()
			return
		Vx6fSAcotNUgr2R += wUCFk2gAo5KiXxEzscP6OuHTMLrWQ
		YPyxhWRKDLJSNFMOQ5Ae += F5LByUrx62svKdWGp1Z
	del MMwWvjhYcnVbJzxmtLaTpkgqO,wUCFk2gAo5KiXxEzscP6OuHTMLrWQ
	s9sMhnvmwSRCOD8,F5LByUrx62svKdWGp1Z = zkHYGFdxib46(Vx6fSAcotNUgr2R,JMXnYbigT286wDos0RIAqpux9CyFmO)
	if JMXnYbigT286wDos0RIAqpux9CyFmO.iscanceled():
		JMXnYbigT286wDos0RIAqpux9CyFmO.close()
		return
	YPyxhWRKDLJSNFMOQ5Ae += F5LByUrx62svKdWGp1Z
	del Vx6fSAcotNUgr2R,F5LByUrx62svKdWGp1Z
	JkAyQjIlDEoiTmKVZdCXPWx37,romMBNWIL2il,vvJHodinpg7LKONDG24MyATVuw,W3NhXgAHwp,M3D9RwXlt8Wovx4 = {},{},{},0,0
	ffxXbQ8jAy3NozaV0mHKw5tEI = list(s9sMhnvmwSRCOD8.keys())
	p7tbqOEHxR6lyw9GoB0fjVih = len(ffxXbQ8jAy3NozaV0mHKw5tEI)*3
	if 1:
		zovIsMbhidf2Ru1WwnFK30tP7O = {}
		for II6AvVR1hB in ffxXbQ8jAy3NozaV0mHKw5tEI:
			zovIsMbhidf2Ru1WwnFK30tP7O[II6AvVR1hB] = Lk21XpCMZto(daemon=gyd2rf0UR5,target=DdFcKYhJgPr9w3qu8bz7eGSxZT6lMO,args=(II6AvVR1hB,))
			zovIsMbhidf2Ru1WwnFK30tP7O[II6AvVR1hB].start()
		for II6AvVR1hB in ffxXbQ8jAy3NozaV0mHKw5tEI:
			zovIsMbhidf2Ru1WwnFK30tP7O[II6AvVR1hB].join()
		if JMXnYbigT286wDos0RIAqpux9CyFmO.iscanceled():
			JMXnYbigT286wDos0RIAqpux9CyFmO.close()
			return
	else:
		for II6AvVR1hB in ffxXbQ8jAy3NozaV0mHKw5tEI:
			DdFcKYhJgPr9w3qu8bz7eGSxZT6lMO(II6AvVR1hB)
			if JMXnYbigT286wDos0RIAqpux9CyFmO.iscanceled():
				JMXnYbigT286wDos0RIAqpux9CyFmO.close()
				return
	KKTv8PfYH3mOrFysU6DQtz9e7ELwu(yFgXClRIeSBhm6QVKuYMJ,False)
	ffxXbQ8jAy3NozaV0mHKw5tEI = list(JkAyQjIlDEoiTmKVZdCXPWx37.keys())
	D5BWrfX1monOtA84Cv0Q7MLFcb = 0
	if 1:
		zovIsMbhidf2Ru1WwnFK30tP7O = {}
		for II6AvVR1hB in ffxXbQ8jAy3NozaV0mHKw5tEI:
			zovIsMbhidf2Ru1WwnFK30tP7O[II6AvVR1hB] = Lk21XpCMZto(daemon=gyd2rf0UR5,target=XsFVcibMHQtx3,args=(yFgXClRIeSBhm6QVKuYMJ,II6AvVR1hB))
			zovIsMbhidf2Ru1WwnFK30tP7O[II6AvVR1hB].start()
		for II6AvVR1hB in ffxXbQ8jAy3NozaV0mHKw5tEI:
			zovIsMbhidf2Ru1WwnFK30tP7O[II6AvVR1hB].join()
		if JMXnYbigT286wDos0RIAqpux9CyFmO.iscanceled():
			JMXnYbigT286wDos0RIAqpux9CyFmO.close()
			return
	else:
		for II6AvVR1hB in ffxXbQ8jAy3NozaV0mHKw5tEI:
			XsFVcibMHQtx3(yFgXClRIeSBhm6QVKuYMJ,II6AvVR1hB)
			if JMXnYbigT286wDos0RIAqpux9CyFmO.iscanceled():
				JMXnYbigT286wDos0RIAqpux9CyFmO.close()
				return
	OLRSzDCVZUm = 0
	jwsrm37ePFBkO2aVR = len(YPyxhWRKDLJSNFMOQ5Ae)
	QqCgJmo8LhArijE5kIMc4vXpNad3nx = ALlXpdDjYiTqu4ORc3J(yFgXClRIeSBhm6QVKuYMJ,'IGNORED')
	for I2JZhRS93lXjcLOuG51AUeDszH7V in YPyxhWRKDLJSNFMOQ5Ae:
		if OLRSzDCVZUm%27==0:
			BwPd4IbMUKZEWAHo0ug8pn(JMXnYbigT286wDos0RIAqpux9CyFmO,95+int(5*OLRSzDCVZUm//jwsrm37ePFBkO2aVR),'تخزين المهملة','الفيديو رقم:-',str(OLRSzDCVZUm)+' / '+str(jwsrm37ePFBkO2aVR))
			if JMXnYbigT286wDos0RIAqpux9CyFmO.iscanceled():
				JMXnYbigT286wDos0RIAqpux9CyFmO.close()
				return
		HqD3sxo0fJX(QqCgJmo8LhArijE5kIMc4vXpNad3nx,'IGNORED',str(I2JZhRS93lXjcLOuG51AUeDszH7V),HQmDERMFjx,h8CF5iEB9RXNf0G)
		OLRSzDCVZUm += 1
	HqD3sxo0fJX(QqCgJmo8LhArijE5kIMc4vXpNad3nx,'IGNORED','__COUNT__',str(jwsrm37ePFBkO2aVR),h8CF5iEB9RXNf0G)
	HqD3sxo0fJX(QqCgJmo8LhArijE5kIMc4vXpNad3nx,'DUMMY','__DUMMY__','1',h8CF5iEB9RXNf0G)
	JMXnYbigT286wDos0RIAqpux9CyFmO.close()
	jHWkt18govGwY7iUbduAfxCyRc.sleep(1)
	plz1sao9uytT = x4Yns6HLyqo5DlGRkZ87(yFgXClRIeSBhm6QVKuYMJ,False)
	u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,s7d549VgeP+'تم جلب ملفات ـIPTV جديدة'+cjqzOQ5GXD4kR+'\n\n'+plz1sao9uytT)
	uu6OqMGbdP2NKZe3(yFgXClRIeSBhm6QVKuYMJ)
	omJpWSLeDbKG(False)
	dXUwsnOGKBF57cNaok(False)
	return
def DdFcKYhJgPr9w3qu8bz7eGSxZT6lMO(II6AvVR1hB):
	global JMXnYbigT286wDos0RIAqpux9CyFmO,s9sMhnvmwSRCOD8,D5BWrfX1monOtA84Cv0Q7MLFcb,JkAyQjIlDEoiTmKVZdCXPWx37,romMBNWIL2il,vvJHodinpg7LKONDG24MyATVuw,W3NhXgAHwp,M3D9RwXlt8Wovx4,p7tbqOEHxR6lyw9GoB0fjVih
	JkAyQjIlDEoiTmKVZdCXPWx37[II6AvVR1hB] = {}
	e27NgsHj3dWGf,PWuzInOiCYxSJN60Z8XcF1wdlrMseK = {},[]
	EqkUTvC4BSeHhrK3ijO9t5Q6zL8sl = len(s9sMhnvmwSRCOD8[II6AvVR1hB])
	JkAyQjIlDEoiTmKVZdCXPWx37[II6AvVR1hB]['__COUNT__'] = EqkUTvC4BSeHhrK3ijO9t5Q6zL8sl
	if EqkUTvC4BSeHhrK3ijO9t5Q6zL8sl>0:
		mmsyP61HtFRjbE,kkS76jloTdpn4gqHvs,hTYN7FnG4BL,DCqNcKyeo9EhsOd,Zaye3MtkJwcXmbYO8UzuFfjPo6isr = zip(*s9sMhnvmwSRCOD8[II6AvVR1hB])
		del kkS76jloTdpn4gqHvs,hTYN7FnG4BL,DCqNcKyeo9EhsOd
		ujBNrDo49KxYTpS7Ls0vygiF2 = list(set(mmsyP61HtFRjbE))
		for gQqERUJHSTVe28xWyoKIhPcCDAm in ujBNrDo49KxYTpS7Ls0vygiF2:
			e27NgsHj3dWGf[gQqERUJHSTVe28xWyoKIhPcCDAm] = HQmDERMFjx
			JkAyQjIlDEoiTmKVZdCXPWx37[II6AvVR1hB][gQqERUJHSTVe28xWyoKIhPcCDAm] = []
		BwPd4IbMUKZEWAHo0ug8pn(JMXnYbigT286wDos0RIAqpux9CyFmO,60+int(15*M3D9RwXlt8Wovx4//p7tbqOEHxR6lyw9GoB0fjVih),'تصنيع القوائم','الجزء رقم:-',str(M3D9RwXlt8Wovx4)+' / '+str(p7tbqOEHxR6lyw9GoB0fjVih))
		if JMXnYbigT286wDos0RIAqpux9CyFmO.iscanceled(): return
		M3D9RwXlt8Wovx4 += 1
		q87qEn3l5wOGiZvNdgyTLsJe0RADY4 = len(ujBNrDo49KxYTpS7Ls0vygiF2)
		del ujBNrDo49KxYTpS7Ls0vygiF2
		PWuzInOiCYxSJN60Z8XcF1wdlrMseK = list(set(zip(mmsyP61HtFRjbE,Zaye3MtkJwcXmbYO8UzuFfjPo6isr)))
		del mmsyP61HtFRjbE,Zaye3MtkJwcXmbYO8UzuFfjPo6isr
		for gQqERUJHSTVe28xWyoKIhPcCDAm,Hdtu4n2qcfGBjV in PWuzInOiCYxSJN60Z8XcF1wdlrMseK:
			if not e27NgsHj3dWGf[gQqERUJHSTVe28xWyoKIhPcCDAm] and Hdtu4n2qcfGBjV: e27NgsHj3dWGf[gQqERUJHSTVe28xWyoKIhPcCDAm] = Hdtu4n2qcfGBjV
		BwPd4IbMUKZEWAHo0ug8pn(JMXnYbigT286wDos0RIAqpux9CyFmO,60+int(15*M3D9RwXlt8Wovx4//p7tbqOEHxR6lyw9GoB0fjVih),'تصنيع القوائم','الجزء رقم:-',str(M3D9RwXlt8Wovx4)+' / '+str(p7tbqOEHxR6lyw9GoB0fjVih))
		if JMXnYbigT286wDos0RIAqpux9CyFmO.iscanceled(): return
		M3D9RwXlt8Wovx4 += 1
		yL47F6CiUJ2 = list(e27NgsHj3dWGf.keys())
		sJRGLgFQ9zCAwxkHXo6qPBcZ = list(e27NgsHj3dWGf.values())
		del e27NgsHj3dWGf
		PWuzInOiCYxSJN60Z8XcF1wdlrMseK = list(zip(yL47F6CiUJ2,sJRGLgFQ9zCAwxkHXo6qPBcZ))
		del yL47F6CiUJ2,sJRGLgFQ9zCAwxkHXo6qPBcZ
		PWuzInOiCYxSJN60Z8XcF1wdlrMseK = sorted(PWuzInOiCYxSJN60Z8XcF1wdlrMseK)
	else: M3D9RwXlt8Wovx4 += 2
	JkAyQjIlDEoiTmKVZdCXPWx37[II6AvVR1hB]['__GROUPS__'] = PWuzInOiCYxSJN60Z8XcF1wdlrMseK
	del PWuzInOiCYxSJN60Z8XcF1wdlrMseK
	for gQqERUJHSTVe28xWyoKIhPcCDAm,wWqEgiB75LpjyPuaDTOU,obS1eBlf0WMLOPDwET8UgCqIJKzm4,GUiCEYZjm5,y2hFMKLYlmwQ9u in s9sMhnvmwSRCOD8[II6AvVR1hB]:
		JkAyQjIlDEoiTmKVZdCXPWx37[II6AvVR1hB][gQqERUJHSTVe28xWyoKIhPcCDAm].append((wWqEgiB75LpjyPuaDTOU,obS1eBlf0WMLOPDwET8UgCqIJKzm4,GUiCEYZjm5,y2hFMKLYlmwQ9u))
	BwPd4IbMUKZEWAHo0ug8pn(JMXnYbigT286wDos0RIAqpux9CyFmO,60+int(15*M3D9RwXlt8Wovx4//p7tbqOEHxR6lyw9GoB0fjVih),'تصنيع القوائم','الجزء رقم:-',str(M3D9RwXlt8Wovx4)+' / '+str(p7tbqOEHxR6lyw9GoB0fjVih))
	if JMXnYbigT286wDos0RIAqpux9CyFmO.iscanceled(): return
	M3D9RwXlt8Wovx4 += 1
	del s9sMhnvmwSRCOD8[II6AvVR1hB]
	vvJHodinpg7LKONDG24MyATVuw[II6AvVR1hB] = list(JkAyQjIlDEoiTmKVZdCXPWx37[II6AvVR1hB].keys())
	romMBNWIL2il[II6AvVR1hB] = len(vvJHodinpg7LKONDG24MyATVuw[II6AvVR1hB])
	W3NhXgAHwp += romMBNWIL2il[II6AvVR1hB]
	return
def XsFVcibMHQtx3(yFgXClRIeSBhm6QVKuYMJ,II6AvVR1hB):
	global JMXnYbigT286wDos0RIAqpux9CyFmO,s9sMhnvmwSRCOD8,D5BWrfX1monOtA84Cv0Q7MLFcb,JkAyQjIlDEoiTmKVZdCXPWx37,romMBNWIL2il,vvJHodinpg7LKONDG24MyATVuw,W3NhXgAHwp,M3D9RwXlt8Wovx4,p7tbqOEHxR6lyw9GoB0fjVih
	QqCgJmo8LhArijE5kIMc4vXpNad3nx = ALlXpdDjYiTqu4ORc3J(yFgXClRIeSBhm6QVKuYMJ,II6AvVR1hB)
	for UUBHcnTDi521SwmfltGjXVoEz in range(1+romMBNWIL2il[II6AvVR1hB]//273):
		QC5Lov1MNxIcw = []
		zZX5jpgkQ8TS7w21HiIcn9EaoMhGB = vvJHodinpg7LKONDG24MyATVuw[II6AvVR1hB][0:273]
		for gQqERUJHSTVe28xWyoKIhPcCDAm in zZX5jpgkQ8TS7w21HiIcn9EaoMhGB:
			QC5Lov1MNxIcw.append(JkAyQjIlDEoiTmKVZdCXPWx37[II6AvVR1hB][gQqERUJHSTVe28xWyoKIhPcCDAm])
		HqD3sxo0fJX(QqCgJmo8LhArijE5kIMc4vXpNad3nx,II6AvVR1hB,zZX5jpgkQ8TS7w21HiIcn9EaoMhGB,QC5Lov1MNxIcw,h8CF5iEB9RXNf0G,True)
		D5BWrfX1monOtA84Cv0Q7MLFcb += len(zZX5jpgkQ8TS7w21HiIcn9EaoMhGB)
		BwPd4IbMUKZEWAHo0ug8pn(JMXnYbigT286wDos0RIAqpux9CyFmO,75+int(20*D5BWrfX1monOtA84Cv0Q7MLFcb//W3NhXgAHwp),'تخزين القوائم','القائمة رقم:-',str(D5BWrfX1monOtA84Cv0Q7MLFcb)+' / '+str(W3NhXgAHwp))
		if JMXnYbigT286wDos0RIAqpux9CyFmO.iscanceled(): return
		del vvJHodinpg7LKONDG24MyATVuw[II6AvVR1hB][0:273]
	del JkAyQjIlDEoiTmKVZdCXPWx37[II6AvVR1hB],vvJHodinpg7LKONDG24MyATVuw[II6AvVR1hB],romMBNWIL2il[II6AvVR1hB]
	return
def x4Yns6HLyqo5DlGRkZ87(yFgXClRIeSBhm6QVKuYMJ,KKQiYlWruNFZSo=True):
	if not NJUG7VWM1tLgQKBip0d(yFgXClRIeSBhm6QVKuYMJ,KKQiYlWruNFZSo): return
	IlFgZehsybn = OO2BXYhI8UPNq6L
	ko3HUg6lORSLc19dyJtVGpTMvZi7C = ALlXpdDjYiTqu4ORc3J(yFgXClRIeSBhm6QVKuYMJ,'LIVE_ORIGINAL_GROUPED')
	RRQt3ZOFiYHXaPkDbfI6W1wE8ps = ALlXpdDjYiTqu4ORc3J(yFgXClRIeSBhm6QVKuYMJ,'VOD_ORIGINAL_GROUPED')
	jwsrm37ePFBkO2aVR = FcSRPu295Ot1Jv0Bip3IDom(ko3HUg6lORSLc19dyJtVGpTMvZi7C,'int','IGNORED','__COUNT__')
	okNp3TGvhYK8 = FcSRPu295Ot1Jv0Bip3IDom(ko3HUg6lORSLc19dyJtVGpTMvZi7C,'int','LIVE_ORIGINAL_GROUPED','__COUNT__')
	uuZ3txyDebdlsVnvW857Kqc = FcSRPu295Ot1Jv0Bip3IDom(RRQt3ZOFiYHXaPkDbfI6W1wE8ps,'int','VOD_ORIGINAL_GROUPED','__COUNT__')
	uptmS25ERw91UvqsNZnxg = FcSRPu295Ot1Jv0Bip3IDom(ko3HUg6lORSLc19dyJtVGpTMvZi7C,'int','LIVE_GROUPED','__COUNT__')
	YnsIt2CJT6rZ78xUDVRvoXcQi1j = FcSRPu295Ot1Jv0Bip3IDom(ko3HUg6lORSLc19dyJtVGpTMvZi7C,'int','LIVE_UNKNOWN_GROUPED','__COUNT__')
	Fuwn1ZdSXWrA3MH6L = FcSRPu295Ot1Jv0Bip3IDom(ko3HUg6lORSLc19dyJtVGpTMvZi7C,'int','VOD_MOVIES_GROUPED','__COUNT__')
	nURx3ItdY5GLeFoQ1Ew7KBPbJg = FcSRPu295Ot1Jv0Bip3IDom(RRQt3ZOFiYHXaPkDbfI6W1wE8ps,'int','VOD_SERIES_GROUPED','__COUNT__')
	MEuHBa5cQy6i = FcSRPu295Ot1Jv0Bip3IDom(ko3HUg6lORSLc19dyJtVGpTMvZi7C,'int','VOD_UNKNOWN_GROUPED','__COUNT__')
	vvJHodinpg7LKONDG24MyATVuw = FcSRPu295Ot1Jv0Bip3IDom(RRQt3ZOFiYHXaPkDbfI6W1wE8ps,'list','VOD_SERIES_GROUPED','__GROUPS__')
	yIO3v1GModC98ifSk = []
	for gQqERUJHSTVe28xWyoKIhPcCDAm,y2hFMKLYlmwQ9u in vvJHodinpg7LKONDG24MyATVuw:
		ttWAkinX81OrzDvKgdleEcpuFyG4QY = gQqERUJHSTVe28xWyoKIhPcCDAm.split('__SERIES__')[1]
		yIO3v1GModC98ifSk.append(ttWAkinX81OrzDvKgdleEcpuFyG4QY)
	tto9WLf1sKYrwaScGyND = len(yIO3v1GModC98ifSk)
	bkVw3mSFtPXz1DWxaYgZKqT0Qp865 = int(Fuwn1ZdSXWrA3MH6L)+int(nURx3ItdY5GLeFoQ1Ew7KBPbJg)+int(MEuHBa5cQy6i)+int(YnsIt2CJT6rZ78xUDVRvoXcQi1j)+int(uptmS25ERw91UvqsNZnxg)
	plz1sao9uytT = HQmDERMFjx
	plz1sao9uytT += 'قنوات: '+str(uptmS25ERw91UvqsNZnxg)
	plz1sao9uytT += '   .   أفلام: '+str(Fuwn1ZdSXWrA3MH6L)
	plz1sao9uytT += '\nمسلسلات: '+str(tto9WLf1sKYrwaScGyND)
	plz1sao9uytT += '   .   حلقات: '+str(nURx3ItdY5GLeFoQ1Ew7KBPbJg)
	plz1sao9uytT += '\nقنوات مجهولة: '+str(YnsIt2CJT6rZ78xUDVRvoXcQi1j)
	plz1sao9uytT += '   .   فيدوهات مجهولة: '+str(MEuHBa5cQy6i)
	plz1sao9uytT += '\nمجموع القنوات: '+str(okNp3TGvhYK8)
	plz1sao9uytT += '   .   مجموع الفيديوهات: '+str(uuZ3txyDebdlsVnvW857Kqc)
	plz1sao9uytT += '\n\nمجموع المضافة: '+str(bkVw3mSFtPXz1DWxaYgZKqT0Qp865)
	plz1sao9uytT += '   .   مجموع المهملة: '+str(jwsrm37ePFBkO2aVR)
	if KKQiYlWruNFZSo: u0W7PAndK1IXU8rxz2jQaM('center',HQmDERMFjx,IlFgZehsybn,plz1sao9uytT)
	Of0ksKrwETialyWnVMozxeGY = plz1sao9uytT.replace('\n\n',ti3SbXNV0aJ7n5Grc4OQY8Ll1s9)
	vv8DyVrLOPAXFIMZ9h(RRWFdpe04EK1Qn,'.\tCounts of IPTV videos   Folder: '+yFgXClRIeSBhm6QVKuYMJ+ti3SbXNV0aJ7n5Grc4OQY8Ll1s9+Of0ksKrwETialyWnVMozxeGY)
	return plz1sao9uytT
def KKTv8PfYH3mOrFysU6DQtz9e7ELwu(yFgXClRIeSBhm6QVKuYMJ,KKQiYlWruNFZSo=True):
	if KKQiYlWruNFZSo:
		oLUahkgyX95xC6FpDn = HUJZy0SrTbBYv1('center',HQmDERMFjx,HQmDERMFjx,'مسح ملفات ـIPTV','تستطيع في أي وقت الدخول إلى قائمة ـIPTV وجلب ملفات ـIPTV جديدة .. هل تريد الآن مسح الملفات القديمة المخزنة في البرنامج ؟!')
		if oLUahkgyX95xC6FpDn!=1: return
		pb7tsOhkEPVZvD0iB61JfSdcIlFoQx = ffOXNqsbi9ZScTH7EKg2B.replace('___','_'+yFgXClRIeSBhm6QVKuYMJ)
		try: S9Y5kUoRga3EVN.remove(pb7tsOhkEPVZvD0iB61JfSdcIlFoQx)
		except: pass
	pb7tsOhkEPVZvD0iB61JfSdcIlFoQx = kkfZMPQ5IjEHieJAn1L.replace('___','_'+yFgXClRIeSBhm6QVKuYMJ)
	try: S9Y5kUoRga3EVN.remove(pb7tsOhkEPVZvD0iB61JfSdcIlFoQx)
	except: pass
	pb7tsOhkEPVZvD0iB61JfSdcIlFoQx = BmpjYhznbSgZa2ElrcHD7Ww3k.replace('___','_'+yFgXClRIeSBhm6QVKuYMJ)
	try: S9Y5kUoRga3EVN.remove(pb7tsOhkEPVZvD0iB61JfSdcIlFoQx)
	except: pass
	X8X1TJW3AmVdy0ZrFvqjDba7Bg2(rDy4FoKpEOsXfT8WZjli,'SECTIONS_IPTV','SECTIONS_IPTV_'+yFgXClRIeSBhm6QVKuYMJ)
	X8X1TJW3AmVdy0ZrFvqjDba7Bg2(rDy4FoKpEOsXfT8WZjli,'SECTIONS_IPTV','SECTIONS_IPTV_ALL')
	omJpWSLeDbKG(False)
	uu6OqMGbdP2NKZe3(yFgXClRIeSBhm6QVKuYMJ)
	if KKQiYlWruNFZSo:
		u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,'تم مسح جميع ملفات ـIPTV')
		dXUwsnOGKBF57cNaok(False)
	return
def NJUG7VWM1tLgQKBip0d(yFgXClRIeSBhm6QVKuYMJ=HQmDERMFjx,KKQiYlWruNFZSo=True):
	if yFgXClRIeSBhm6QVKuYMJ:
		QqCgJmo8LhArijE5kIMc4vXpNad3nx = ALlXpdDjYiTqu4ORc3J(str(yFgXClRIeSBhm6QVKuYMJ),'DUMMY')
		Vn2dcZrLCeyMIfKDGgqm0w6jszRp = FcSRPu295Ot1Jv0Bip3IDom(QqCgJmo8LhArijE5kIMc4vXpNad3nx,'str','DUMMY','__DUMMY__')
		if Vn2dcZrLCeyMIfKDGgqm0w6jszRp: return True
	else:
		yFgXClRIeSBhm6QVKuYMJ = '1'
		for WKw08t4Ajcz1sqPh6vlfEBuHNiX5d in range(1,L3C1YrQDi840ShlOJcNGe+1):
			QqCgJmo8LhArijE5kIMc4vXpNad3nx = ALlXpdDjYiTqu4ORc3J(str(WKw08t4Ajcz1sqPh6vlfEBuHNiX5d),'DUMMY')
			Vn2dcZrLCeyMIfKDGgqm0w6jszRp = FcSRPu295Ot1Jv0Bip3IDom(QqCgJmo8LhArijE5kIMc4vXpNad3nx,'str','DUMMY','__DUMMY__')
			if Vn2dcZrLCeyMIfKDGgqm0w6jszRp: return True
	if KKQiYlWruNFZSo:
		u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,'هذا الجزء من البرنامج يحتاج اشتراك IPTV مدفوع من شركة IPTV .. ونوع الرابط المطلوب هو  m3u .. وهذا مثال لتوضيح شكل الرابط المطلوب في هذا البرنامج  '+ao3Q5jP8H0sMxK2iUYwZGE+' \n\nhttp://xyz.xyz/get.php?username=xyz&password=xyz&type=m3u_plus '+cjqzOQ5GXD4kR)
		IlFgZehsybn = 'إضافة وتغيير رابط '+ccoph2TqA8fJG4KO6YRwm[1]+' (مجلد '+ccoph2TqA8fJG4KO6YRwm[int(yFgXClRIeSBhm6QVKuYMJ)]+')'
		oLUahkgyX95xC6FpDn = HUJZy0SrTbBYv1(HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,IlFgZehsybn,'لإضافة رابط IPTV .. أولا أفتح قائمة IPTV .. وثانيا أنقر على إضافة رابط أو اشتراك ـIPTV .. وثالثا أنقر على جلب ملفات ـIPTV \n\n هل تريد إضافة أو تغيير رابط IPTV الآن ؟!')
		if oLUahkgyX95xC6FpDn==1: tIdcTg4nU7YLEvu9qHWx(yFgXClRIeSBhm6QVKuYMJ)
	return False
def MEdwlqBgOsTUp45(VMmBI2l9C6p,yFgXClRIeSBhm6QVKuYMJ=HQmDERMFjx,II6AvVR1hB=HQmDERMFjx,XpNdFaq5h7LB1nlx6mMU=HQmDERMFjx):
	if not XpNdFaq5h7LB1nlx6mMU: XpNdFaq5h7LB1nlx6mMU = '1'
	f5IwhEVtJQG9pODZAU2RnCx7cd80u,LlsCEXIte1n9TG0BAVOojqyvQkhb5,KKQiYlWruNFZSo = x0pzMENwy84tBcZvXr(VMmBI2l9C6p)
	if not NJUG7VWM1tLgQKBip0d(yFgXClRIeSBhm6QVKuYMJ,KKQiYlWruNFZSo): return
	if not f5IwhEVtJQG9pODZAU2RnCx7cd80u:
		f5IwhEVtJQG9pODZAU2RnCx7cd80u = q156m84QoYrn()
		if not f5IwhEVtJQG9pODZAU2RnCx7cd80u: return
	wwJl0gfEtVYuh1cGKFbmrMRBWLn = [HQmDERMFjx,'LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not II6AvVR1hB:
		if not KKQiYlWruNFZSo:
			if   '_IPTV-LIVE_' in LlsCEXIte1n9TG0BAVOojqyvQkhb5: II6AvVR1hB = wwJl0gfEtVYuh1cGKFbmrMRBWLn[1]
			elif '_IPTV-MOVIES' in LlsCEXIte1n9TG0BAVOojqyvQkhb5: II6AvVR1hB = wwJl0gfEtVYuh1cGKFbmrMRBWLn[2]
			elif '_IPTV-SERIES' in LlsCEXIte1n9TG0BAVOojqyvQkhb5: II6AvVR1hB = wwJl0gfEtVYuh1cGKFbmrMRBWLn[3]
			else: II6AvVR1hB = wwJl0gfEtVYuh1cGKFbmrMRBWLn[0]
		else:
			Uhx53OTvD6V2NtiE = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			Tk70cbAyLw = GGiSlWbqKDr5Ovkh2L7sHNTxz('أختر البحث المناسب', Uhx53OTvD6V2NtiE)
			if Tk70cbAyLw==-1: return
			II6AvVR1hB = wwJl0gfEtVYuh1cGKFbmrMRBWLn[Tk70cbAyLw]
	f5IwhEVtJQG9pODZAU2RnCx7cd80u = f5IwhEVtJQG9pODZAU2RnCx7cd80u+'_NODIALOGS_'
	if yFgXClRIeSBhm6QVKuYMJ: ffRKVxyrgTDd5QFZYiaIGWLjH(f5IwhEVtJQG9pODZAU2RnCx7cd80u,yFgXClRIeSBhm6QVKuYMJ,II6AvVR1hB,XpNdFaq5h7LB1nlx6mMU)
	else:
		for yFgXClRIeSBhm6QVKuYMJ in range(1,L3C1YrQDi840ShlOJcNGe+1):
			ffRKVxyrgTDd5QFZYiaIGWLjH(f5IwhEVtJQG9pODZAU2RnCx7cd80u,str(yFgXClRIeSBhm6QVKuYMJ),II6AvVR1hB,XpNdFaq5h7LB1nlx6mMU)
		Jzthpc2nj5.menuItemsLIST[:] = sorted(Jzthpc2nj5.menuItemsLIST,reverse=False,key=lambda Rinkx4B0rUOXlpFqQuKPC2oA: Rinkx4B0rUOXlpFqQuKPC2oA[1].lower())
	return
def ffRKVxyrgTDd5QFZYiaIGWLjH(VMmBI2l9C6p,yFgXClRIeSBhm6QVKuYMJ,II6AvVR1hB=HQmDERMFjx,XpNdFaq5h7LB1nlx6mMU=HQmDERMFjx):
	if not XpNdFaq5h7LB1nlx6mMU: XpNdFaq5h7LB1nlx6mMU = '1'
	f5IwhEVtJQG9pODZAU2RnCx7cd80u,LlsCEXIte1n9TG0BAVOojqyvQkhb5,KKQiYlWruNFZSo = x0pzMENwy84tBcZvXr(VMmBI2l9C6p)
	if not yFgXClRIeSBhm6QVKuYMJ: return
	if not NJUG7VWM1tLgQKBip0d(yFgXClRIeSBhm6QVKuYMJ,KKQiYlWruNFZSo): return
	if not f5IwhEVtJQG9pODZAU2RnCx7cd80u:
		f5IwhEVtJQG9pODZAU2RnCx7cd80u = q156m84QoYrn()
		if not f5IwhEVtJQG9pODZAU2RnCx7cd80u: return
	wwJl0gfEtVYuh1cGKFbmrMRBWLn = [HQmDERMFjx,'LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not II6AvVR1hB:
		if not KKQiYlWruNFZSo:
			if   '_IPTV-LIVE_' in LlsCEXIte1n9TG0BAVOojqyvQkhb5: II6AvVR1hB = wwJl0gfEtVYuh1cGKFbmrMRBWLn[1]
			elif '_IPTV-MOVIES' in LlsCEXIte1n9TG0BAVOojqyvQkhb5: II6AvVR1hB = wwJl0gfEtVYuh1cGKFbmrMRBWLn[2]
			elif '_IPTV-SERIES' in LlsCEXIte1n9TG0BAVOojqyvQkhb5: II6AvVR1hB = wwJl0gfEtVYuh1cGKFbmrMRBWLn[3]
			else: II6AvVR1hB = wwJl0gfEtVYuh1cGKFbmrMRBWLn[0]
		else:
			Uhx53OTvD6V2NtiE = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			Tk70cbAyLw = GGiSlWbqKDr5Ovkh2L7sHNTxz('أختر البحث المناسب', Uhx53OTvD6V2NtiE)
			if Tk70cbAyLw==-1: return
			II6AvVR1hB = wwJl0gfEtVYuh1cGKFbmrMRBWLn[Tk70cbAyLw]
	gioXrWxcbT2uzQ5KmD6I4Y = f5IwhEVtJQG9pODZAU2RnCx7cd80u.lower()
	QqCgJmo8LhArijE5kIMc4vXpNad3nx = ALlXpdDjYiTqu4ORc3J(yFgXClRIeSBhm6QVKuYMJ,'SEARCH')
	USFh9yauLTlCXb2nZIw5tqQmO4dH = FcSRPu295Ot1Jv0Bip3IDom(QqCgJmo8LhArijE5kIMc4vXpNad3nx,'list','SEARCH',(II6AvVR1hB,gioXrWxcbT2uzQ5KmD6I4Y))
	if not USFh9yauLTlCXb2nZIw5tqQmO4dH:
		Bd8JUPNLEWVR6svu1ZS,ErFviX2HJ584qt3 = [],[]
		if not II6AvVR1hB: GugkbqFonJH35RN49PXlmMe = [1,2,3,4,5]
		else: GugkbqFonJH35RN49PXlmMe = [wwJl0gfEtVYuh1cGKFbmrMRBWLn.index(II6AvVR1hB)]
		for OLRSzDCVZUm in GugkbqFonJH35RN49PXlmMe:
			QqCgJmo8LhArijE5kIMc4vXpNad3nx = ALlXpdDjYiTqu4ORc3J(yFgXClRIeSBhm6QVKuYMJ,wwJl0gfEtVYuh1cGKFbmrMRBWLn[OLRSzDCVZUm])
			if OLRSzDCVZUm!=3:
				wUCFk2gAo5KiXxEzscP6OuHTMLrWQ = FcSRPu295Ot1Jv0Bip3IDom(QqCgJmo8LhArijE5kIMc4vXpNad3nx,'dict',wwJl0gfEtVYuh1cGKFbmrMRBWLn[OLRSzDCVZUm])
				del wUCFk2gAo5KiXxEzscP6OuHTMLrWQ['__COUNT__']
				del wUCFk2gAo5KiXxEzscP6OuHTMLrWQ['__GROUPS__']
				del wUCFk2gAo5KiXxEzscP6OuHTMLrWQ['__SEQUENCED_COLUMNS__']
				vvJHodinpg7LKONDG24MyATVuw = list(wUCFk2gAo5KiXxEzscP6OuHTMLrWQ.keys())
				for gQqERUJHSTVe28xWyoKIhPcCDAm in vvJHodinpg7LKONDG24MyATVuw:
					for wWqEgiB75LpjyPuaDTOU,obS1eBlf0WMLOPDwET8UgCqIJKzm4,GUiCEYZjm5,y2hFMKLYlmwQ9u in wUCFk2gAo5KiXxEzscP6OuHTMLrWQ[gQqERUJHSTVe28xWyoKIhPcCDAm]:
						if gioXrWxcbT2uzQ5KmD6I4Y in obS1eBlf0WMLOPDwET8UgCqIJKzm4.lower(): ErFviX2HJ584qt3.append((obS1eBlf0WMLOPDwET8UgCqIJKzm4,GUiCEYZjm5,y2hFMKLYlmwQ9u))
					del wUCFk2gAo5KiXxEzscP6OuHTMLrWQ[gQqERUJHSTVe28xWyoKIhPcCDAm]
				del wUCFk2gAo5KiXxEzscP6OuHTMLrWQ
			else: vvJHodinpg7LKONDG24MyATVuw = FcSRPu295Ot1Jv0Bip3IDom(QqCgJmo8LhArijE5kIMc4vXpNad3nx,'list',wwJl0gfEtVYuh1cGKFbmrMRBWLn[OLRSzDCVZUm],'__GROUPS__')
			for gQqERUJHSTVe28xWyoKIhPcCDAm in vvJHodinpg7LKONDG24MyATVuw:
				try: gQqERUJHSTVe28xWyoKIhPcCDAm,y2hFMKLYlmwQ9u = gQqERUJHSTVe28xWyoKIhPcCDAm
				except: y2hFMKLYlmwQ9u = HQmDERMFjx
				if gioXrWxcbT2uzQ5KmD6I4Y in gQqERUJHSTVe28xWyoKIhPcCDAm.lower():
					if OLRSzDCVZUm!=3: nVtCO2bwr9TRIkSeJhZMG5 = gQqERUJHSTVe28xWyoKIhPcCDAm
					else:
						I0oltSCUu7rN8Fi4sGpMKQ5j61Y2,xBpzg5DJtsU2KQVnyiovak1f = gQqERUJHSTVe28xWyoKIhPcCDAm.split('__SERIES__')
						if gioXrWxcbT2uzQ5KmD6I4Y in I0oltSCUu7rN8Fi4sGpMKQ5j61Y2.lower(): nVtCO2bwr9TRIkSeJhZMG5 = I0oltSCUu7rN8Fi4sGpMKQ5j61Y2
						else: nVtCO2bwr9TRIkSeJhZMG5 = xBpzg5DJtsU2KQVnyiovak1f
					Bd8JUPNLEWVR6svu1ZS.append((gQqERUJHSTVe28xWyoKIhPcCDAm,nVtCO2bwr9TRIkSeJhZMG5,wwJl0gfEtVYuh1cGKFbmrMRBWLn[OLRSzDCVZUm],y2hFMKLYlmwQ9u))
			del vvJHodinpg7LKONDG24MyATVuw
		Bd8JUPNLEWVR6svu1ZS = set(Bd8JUPNLEWVR6svu1ZS)
		ErFviX2HJ584qt3 = set(ErFviX2HJ584qt3)
		Bd8JUPNLEWVR6svu1ZS = sorted(Bd8JUPNLEWVR6svu1ZS,reverse=False,key=lambda Rinkx4B0rUOXlpFqQuKPC2oA: Rinkx4B0rUOXlpFqQuKPC2oA[1])
		ErFviX2HJ584qt3 = sorted(ErFviX2HJ584qt3,reverse=False,key=lambda Rinkx4B0rUOXlpFqQuKPC2oA: Rinkx4B0rUOXlpFqQuKPC2oA[0])
		HqD3sxo0fJX(QqCgJmo8LhArijE5kIMc4vXpNad3nx,'SEARCH',(II6AvVR1hB,gioXrWxcbT2uzQ5KmD6I4Y),(Bd8JUPNLEWVR6svu1ZS,ErFviX2HJ584qt3),h8CF5iEB9RXNf0G)
	else: Bd8JUPNLEWVR6svu1ZS,ErFviX2HJ584qt3 = USFh9yauLTlCXb2nZIw5tqQmO4dH
	vvJHodinpg7LKONDG24MyATVuw = len(Bd8JUPNLEWVR6svu1ZS)
	PykvXEufGnMYzATlmNjgVh0 = len(ErFviX2HJ584qt3)
	JTMSUFcWn0XQa63GBI9qEAk7 = int(XpNdFaq5h7LB1nlx6mMU)
	Fms52ufEiMGbpKwhy6n = max(0,(JTMSUFcWn0XQa63GBI9qEAk7-1)*100)
	c3vI0QyHBXRWsbN4x = max(0,JTMSUFcWn0XQa63GBI9qEAk7*100)
	OKUi1j3NocCpP = max(0,Fms52ufEiMGbpKwhy6n-vvJHodinpg7LKONDG24MyATVuw)
	mow4VycliX2fLPUbQ6qRunj9KDWCsI = max(0,c3vI0QyHBXRWsbN4x-vvJHodinpg7LKONDG24MyATVuw)
	for gQqERUJHSTVe28xWyoKIhPcCDAm,nVtCO2bwr9TRIkSeJhZMG5,QG7ZYcz02gIKk3epEOfPnC86lt1,y2hFMKLYlmwQ9u in Bd8JUPNLEWVR6svu1ZS[Fms52ufEiMGbpKwhy6n:c3vI0QyHBXRWsbN4x]:
		CfgK4s13Q0hZcHyleT2bVJO9('folder',ovnIAFkN3W2yr+nVtCO2bwr9TRIkSeJhZMG5,QG7ZYcz02gIKk3epEOfPnC86lt1,234,y2hFMKLYlmwQ9u,'1',gQqERUJHSTVe28xWyoKIhPcCDAm,HQmDERMFjx,{'folder':yFgXClRIeSBhm6QVKuYMJ})
	del Bd8JUPNLEWVR6svu1ZS
	for obS1eBlf0WMLOPDwET8UgCqIJKzm4,GUiCEYZjm5,y2hFMKLYlmwQ9u in ErFviX2HJ584qt3[OKUi1j3NocCpP:mow4VycliX2fLPUbQ6qRunj9KDWCsI]:
		xPJn3XQUC1 = uk3fqJivW6(GUiCEYZjm5)
		arsOBITUkup7x3eSfEvM = 'live'
		if '.mkv' in xPJn3XQUC1 or 'VOD' in II6AvVR1hB: arsOBITUkup7x3eSfEvM = 'video'
		CfgK4s13Q0hZcHyleT2bVJO9(arsOBITUkup7x3eSfEvM,ovnIAFkN3W2yr+obS1eBlf0WMLOPDwET8UgCqIJKzm4,GUiCEYZjm5,235,y2hFMKLYlmwQ9u,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,{'folder':yFgXClRIeSBhm6QVKuYMJ})
	del ErFviX2HJ584qt3
	SjaDEl6u9ZXroLw(yFgXClRIeSBhm6QVKuYMJ,XpNdFaq5h7LB1nlx6mMU,II6AvVR1hB,239,vvJHodinpg7LKONDG24MyATVuw+PykvXEufGnMYzATlmNjgVh0,f5IwhEVtJQG9pODZAU2RnCx7cd80u+'_NODIALOGS_')
	return
def SjaDEl6u9ZXroLw(yFgXClRIeSBhm6QVKuYMJ,XpNdFaq5h7LB1nlx6mMU,II6AvVR1hB,lXBL3WrM2JFYm,bkVw3mSFtPXz1DWxaYgZKqT0Qp865,NN9niuC7RoqmhkL2):
	if XpNdFaq5h7LB1nlx6mMU!='1': CfgK4s13Q0hZcHyleT2bVJO9('folder',ovnIAFkN3W2yr+'صفحة '+str(1),II6AvVR1hB,lXBL3WrM2JFYm,HQmDERMFjx,str(1),NN9niuC7RoqmhkL2,HQmDERMFjx,{'folder':yFgXClRIeSBhm6QVKuYMJ})
	if not bkVw3mSFtPXz1DWxaYgZKqT0Qp865: bkVw3mSFtPXz1DWxaYgZKqT0Qp865 = 0
	tJSNAMf2UbwrjlQRHYh5iF = int(bkVw3mSFtPXz1DWxaYgZKqT0Qp865/100)+1
	for JTMSUFcWn0XQa63GBI9qEAk7 in range(2,tJSNAMf2UbwrjlQRHYh5iF):
		gWfVJru3lQBT8wP5Y17je = (JTMSUFcWn0XQa63GBI9qEAk7%10==0 or int(XpNdFaq5h7LB1nlx6mMU)-4<JTMSUFcWn0XQa63GBI9qEAk7<int(XpNdFaq5h7LB1nlx6mMU)+4)
		BBM4dE1UlgWfrocR3JXL = (gWfVJru3lQBT8wP5Y17je and int(XpNdFaq5h7LB1nlx6mMU)-40<JTMSUFcWn0XQa63GBI9qEAk7<int(XpNdFaq5h7LB1nlx6mMU)+40)
		if str(JTMSUFcWn0XQa63GBI9qEAk7)!=XpNdFaq5h7LB1nlx6mMU and (JTMSUFcWn0XQa63GBI9qEAk7%100==0 or BBM4dE1UlgWfrocR3JXL):
			CfgK4s13Q0hZcHyleT2bVJO9('folder',ovnIAFkN3W2yr+'صفحة '+str(JTMSUFcWn0XQa63GBI9qEAk7),II6AvVR1hB,lXBL3WrM2JFYm,HQmDERMFjx,str(JTMSUFcWn0XQa63GBI9qEAk7),NN9niuC7RoqmhkL2,HQmDERMFjx,{'folder':yFgXClRIeSBhm6QVKuYMJ})
	if str(tJSNAMf2UbwrjlQRHYh5iF)!=XpNdFaq5h7LB1nlx6mMU: CfgK4s13Q0hZcHyleT2bVJO9('folder',ovnIAFkN3W2yr+'أخر صفحة '+str(tJSNAMf2UbwrjlQRHYh5iF),II6AvVR1hB,lXBL3WrM2JFYm,HQmDERMFjx,str(tJSNAMf2UbwrjlQRHYh5iF),NN9niuC7RoqmhkL2,HQmDERMFjx,{'folder':yFgXClRIeSBhm6QVKuYMJ})
	return
def ALlXpdDjYiTqu4ORc3J(yFgXClRIeSBhm6QVKuYMJ,II6AvVR1hB):
	if 'SERIES' in II6AvVR1hB or 'VOD_ORIGINAL' in II6AvVR1hB: QqCgJmo8LhArijE5kIMc4vXpNad3nx = BmpjYhznbSgZa2ElrcHD7Ww3k
	else: QqCgJmo8LhArijE5kIMc4vXpNad3nx = kkfZMPQ5IjEHieJAn1L
	QqCgJmo8LhArijE5kIMc4vXpNad3nx = QqCgJmo8LhArijE5kIMc4vXpNad3nx.replace('___','_'+yFgXClRIeSBhm6QVKuYMJ)
	return QqCgJmo8LhArijE5kIMc4vXpNad3nx
def Bae5NXxpfoiJVLCl6(yFgXClRIeSBhm6QVKuYMJ,II6AvVR1hB,lWxyXfM4hRuDg3):
	uIaC4JbUr7YQVhsey0nf,W1x398GwYvCTdPaNLh64r,XjZ6beJF1vH57KUkw2,Vg7Djl1ASx2TftcNevWmHaUq,DDFCVWKHbmg9JtzjT1oU = X3l7NG6egiMtj0u(yFgXClRIeSBhm6QVKuYMJ)
	if not Vg7Djl1ASx2TftcNevWmHaUq: return
	WW2BEsh58O = RGMjHDTLevQ3htNwnkFr1q6z0V85KJ(yFgXClRIeSBhm6QVKuYMJ)
	if   II6AvVR1hB=='XTREAM_LIVE_GROUPS': GUiCEYZjm5 = uIaC4JbUr7YQVhsey0nf+'&action=get_live_categories'
	elif II6AvVR1hB=='XTREAM_VOD_GROUPS': GUiCEYZjm5 = uIaC4JbUr7YQVhsey0nf+'&action=get_vod_categories'
	elif II6AvVR1hB=='XTREAM_SERIES_GROUPS': GUiCEYZjm5 = uIaC4JbUr7YQVhsey0nf+'&action=get_series_categories'
	elif II6AvVR1hB=='XTREAM_LIVE_ITEMS': GUiCEYZjm5 = uIaC4JbUr7YQVhsey0nf+'&action=get_live_streams&category_id='+lWxyXfM4hRuDg3
	elif II6AvVR1hB=='XTREAM_VOD_ITEMS': GUiCEYZjm5 = uIaC4JbUr7YQVhsey0nf+'&action=get_vod_streams&category_id='+lWxyXfM4hRuDg3
	elif II6AvVR1hB=='XTREAM_SERIES_ITEMS': GUiCEYZjm5 = uIaC4JbUr7YQVhsey0nf+'&action=get_series&category_id='+lWxyXfM4hRuDg3
	elif II6AvVR1hB=='XTREAM_EPISODES': GUiCEYZjm5 = uIaC4JbUr7YQVhsey0nf+'&action=get_series_info&series_id='+lWxyXfM4hRuDg3
	else: return
	Pmwd7O4bJj82oUSYiBR1hrEkNstXlK = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',GUiCEYZjm5,HQmDERMFjx,WW2BEsh58O,HQmDERMFjx,HQmDERMFjx,'IPTV-XTREAM_MENUS-1st')
	Y0E2pIKH7s6mbvfSciOBDd = Pmwd7O4bJj82oUSYiBR1hrEkNstXlK.content
	if C6H1qXua3SMQiIrzxNvJWZE: Y0E2pIKH7s6mbvfSciOBDd = Y0E2pIKH7s6mbvfSciOBDd.decode(Zex6D4tJE52r).encode(Zex6D4tJE52r)
	SlP9gUsyaiQ2zqK5wjvFh = aknZqSJyUrFgc9VhH2Psot6e7b8('list',Y0E2pIKH7s6mbvfSciOBDd)
	if 'GROUPS' in II6AvVR1hB:
		II6AvVR1hB = II6AvVR1hB.replace('_GROUPS','_ITEMS')
		SlP9gUsyaiQ2zqK5wjvFh = sorted(SlP9gUsyaiQ2zqK5wjvFh,reverse=False,key=lambda Rinkx4B0rUOXlpFqQuKPC2oA: Rinkx4B0rUOXlpFqQuKPC2oA['category_name'].lower())
		for gQqERUJHSTVe28xWyoKIhPcCDAm in SlP9gUsyaiQ2zqK5wjvFh:
			VVDoRuyhKvLUG15dx7BarIXtTw2JmE = gQqERUJHSTVe28xWyoKIhPcCDAm['category_id']
			obS1eBlf0WMLOPDwET8UgCqIJKzm4 = gQqERUJHSTVe28xWyoKIhPcCDAm['category_name']
			CfgK4s13Q0hZcHyleT2bVJO9('folder',ovnIAFkN3W2yr+obS1eBlf0WMLOPDwET8UgCqIJKzm4,II6AvVR1hB,285,HQmDERMFjx,HQmDERMFjx,str(VVDoRuyhKvLUG15dx7BarIXtTw2JmE),HQmDERMFjx,{'folder':yFgXClRIeSBhm6QVKuYMJ})
	elif II6AvVR1hB=='XTREAM_SERIES_ITEMS':
		SlP9gUsyaiQ2zqK5wjvFh = sorted(SlP9gUsyaiQ2zqK5wjvFh,reverse=False,key=lambda Rinkx4B0rUOXlpFqQuKPC2oA: Rinkx4B0rUOXlpFqQuKPC2oA['name'].lower())
		for n9GcJRbaZm in SlP9gUsyaiQ2zqK5wjvFh:
			obS1eBlf0WMLOPDwET8UgCqIJKzm4 = n9GcJRbaZm['name']
			Hdtu4n2qcfGBjV = n9GcJRbaZm['cover']
			VVDoRuyhKvLUG15dx7BarIXtTw2JmE = n9GcJRbaZm['series_id']
			CfgK4s13Q0hZcHyleT2bVJO9('folder',ovnIAFkN3W2yr+obS1eBlf0WMLOPDwET8UgCqIJKzm4,'XTREAM_EPISODES',285,Hdtu4n2qcfGBjV,HQmDERMFjx,str(VVDoRuyhKvLUG15dx7BarIXtTw2JmE),HQmDERMFjx,{'folder':yFgXClRIeSBhm6QVKuYMJ})
	elif II6AvVR1hB=='XTREAM_EPISODES':
		Hdtu4n2qcfGBjV = SlP9gUsyaiQ2zqK5wjvFh['info']['cover']
		XyOvPTlmBK4hDVjfi = SlP9gUsyaiQ2zqK5wjvFh['info']['name']
		zz0vqjfVlsuTmikJLtyOgBSCrbKow = SlP9gUsyaiQ2zqK5wjvFh['episodes']
		for HDoiSpa1P2KhZej in zz0vqjfVlsuTmikJLtyOgBSCrbKow:
			NMLb94SqiH = zz0vqjfVlsuTmikJLtyOgBSCrbKow[HDoiSpa1P2KhZej]
			for AzkKieN9wUQ5b in NMLb94SqiH:
				obS1eBlf0WMLOPDwET8UgCqIJKzm4 = AzkKieN9wUQ5b['title']
				RYawONHq2iFL9Bn3vTMEx47S8Q = DyVGS3dX0ZxR.findall('\d+.(S\d+E\d+)',obS1eBlf0WMLOPDwET8UgCqIJKzm4,DyVGS3dX0ZxR.DOTALL)
				if RYawONHq2iFL9Bn3vTMEx47S8Q: obS1eBlf0WMLOPDwET8UgCqIJKzm4 = XyOvPTlmBK4hDVjfi+oQpxmKiRPlHeGsLXNrJF78O+RYawONHq2iFL9Bn3vTMEx47S8Q[0]
				VVDoRuyhKvLUG15dx7BarIXtTw2JmE = AzkKieN9wUQ5b['id']
				KAi9uTcpUr = AzkKieN9wUQ5b['container_extension']
				GUiCEYZjm5 = uIaC4JbUr7YQVhsey0nf.split('/player_api.php')[0]+'/series/'+Vg7Djl1ASx2TftcNevWmHaUq+xufJqQcGnhboiVy2wd+DDFCVWKHbmg9JtzjT1oU+xufJqQcGnhboiVy2wd+str(VVDoRuyhKvLUG15dx7BarIXtTw2JmE)+'.'+KAi9uTcpUr
				CfgK4s13Q0hZcHyleT2bVJO9('video',ovnIAFkN3W2yr+obS1eBlf0WMLOPDwET8UgCqIJKzm4,GUiCEYZjm5,235,Hdtu4n2qcfGBjV,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,{'folder':yFgXClRIeSBhm6QVKuYMJ})
	elif 'ITEMS' in II6AvVR1hB:
		arsOBITUkup7x3eSfEvM = 'live' if 'LIVE' in II6AvVR1hB else 'video'
		SlP9gUsyaiQ2zqK5wjvFh = sorted(SlP9gUsyaiQ2zqK5wjvFh,reverse=False,key=lambda Rinkx4B0rUOXlpFqQuKPC2oA: Rinkx4B0rUOXlpFqQuKPC2oA['name'].lower())
		for OOq7t5nLvFTw in SlP9gUsyaiQ2zqK5wjvFh:
			obS1eBlf0WMLOPDwET8UgCqIJKzm4 = OOq7t5nLvFTw['name']
			Hdtu4n2qcfGBjV = OOq7t5nLvFTw['stream_icon']
			VVDoRuyhKvLUG15dx7BarIXtTw2JmE = OOq7t5nLvFTw['stream_id']
			try:
				KAi9uTcpUr = OOq7t5nLvFTw['container_extension']
				if KAi9uTcpUr: KAi9uTcpUr = '.'+KAi9uTcpUr
			except: KAi9uTcpUr = HQmDERMFjx
			if OOq7t5nLvFTw['stream_type']=='live': jjAmOigbf34w2,b1cjgdqBP2VQ = HQmDERMFjx,'live'
			elif OOq7t5nLvFTw['stream_type']=='movie': jjAmOigbf34w2,b1cjgdqBP2VQ = 'movie/','video'
			GUiCEYZjm5 = uIaC4JbUr7YQVhsey0nf.split('/player_api.php')[0]+xufJqQcGnhboiVy2wd+jjAmOigbf34w2+Vg7Djl1ASx2TftcNevWmHaUq+xufJqQcGnhboiVy2wd+DDFCVWKHbmg9JtzjT1oU+xufJqQcGnhboiVy2wd+str(VVDoRuyhKvLUG15dx7BarIXtTw2JmE)+KAi9uTcpUr
			CfgK4s13Q0hZcHyleT2bVJO9(arsOBITUkup7x3eSfEvM,ovnIAFkN3W2yr+obS1eBlf0WMLOPDwET8UgCqIJKzm4,GUiCEYZjm5,235,Hdtu4n2qcfGBjV,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,{'folder':yFgXClRIeSBhm6QVKuYMJ})
	return
def uu6OqMGbdP2NKZe3(yFgXClRIeSBhm6QVKuYMJ):
	qdkv4CFs1cDoPGJRbLu2mlYg7O = H8jfvMtXa7Neiu.getSetting('av.language.provider')
	ZyVtovDJARHmufOp = H8jfvMtXa7Neiu.getSetting('av.language.code')
	X8X1TJW3AmVdy0ZrFvqjDba7Bg2(rDy4FoKpEOsXfT8WZjli,'MENUS_CACHE_'+qdkv4CFs1cDoPGJRbLu2mlYg7O+'_'+ZyVtovDJARHmufOp,'%_IP'+yFgXClRIeSBhm6QVKuYMJ+'_%')
	return
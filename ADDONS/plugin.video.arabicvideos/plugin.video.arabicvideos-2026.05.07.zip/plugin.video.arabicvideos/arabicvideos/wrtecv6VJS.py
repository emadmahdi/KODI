# -*- coding: utf-8 -*-
from FF68kA5BUy import *
HDLtdMAy7wPkl8aKC3O2 = 'ARABSEED'
headers = {'User-Agent':xK7D9yiBPEqvhmA8XIoJe()}
EEJvXQzSZNt = '_ARS_'
e2VR8nohduY = Jzthpc2nj5.SITESURLS[HDLtdMAy7wPkl8aKC3O2][0]
FwhZ0nXtpoHTMarf = ['رمضان','الرئيسية','المضاف حديثاً','مصارعه','اعلن معنا – For ads','موبايلات','برامج كمبيوتر','العاب كمبيوتر','اسلاميات','اخرى','اقسام اخري','اشتراكات']
def kk6X5LxpsND(mode,url,text):
	if   mode==250: zLZUkrP7ac5 = afkxo7FyZWB4O6K1eXrs5I()
	elif mode==251: zLZUkrP7ac5 = c8wfGju4CWZm(url,text)
	elif mode==252: zLZUkrP7ac5 = f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url)
	elif mode==253: zLZUkrP7ac5 = XONC9osGSP4fW5HVrhM(url)
	elif mode==254: zLZUkrP7ac5 = ooxUXkcTj5PF4ad2SwYy(url,'CATEGORIES___'+text)
	elif mode==255: zLZUkrP7ac5 = ooxUXkcTj5PF4ad2SwYy(url,'FILTERS___'+text)
	elif mode==259: zLZUkrP7ac5 = hm4kawIPKp3oMrC75dJZA9HS2(text)
	else: zLZUkrP7ac5 = False
	return zLZUkrP7ac5
def afkxo7FyZWB4O6K1eXrs5I():
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',e2VR8nohduY,HQmDERMFjx,headers,HQmDERMFjx,HQmDERMFjx,'ARABSEED-MENU-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	PPB1JrmtTzjRHn = DyVGS3dX0ZxR.findall('"maincontent".*?href="(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	PPB1JrmtTzjRHn = PPB1JrmtTzjRHn[0].rstrip('/') if PPB1JrmtTzjRHn else e2VR8nohduY
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'بحث في الموقع',HQmDERMFjx,259,HQmDERMFjx,HQmDERMFjx,'_REMEMBERRESULTS_')
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'فلتر محدد',e2VR8nohduY+'/category/اخرى',254)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'فلتر كامل',e2VR8nohduY+'/category/اخرى',255)
	CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'المميزة',PPB1JrmtTzjRHn,251,HQmDERMFjx,HQmDERMFjx,'featured_main')
	CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+'احدث الافلام',PPB1JrmtTzjRHn,251,HQmDERMFjx,HQmDERMFjx,'new_movies')
	CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+'احدث الحلقات',PPB1JrmtTzjRHn,251,HQmDERMFjx,HQmDERMFjx,'new_episodes')
	CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(H5x4Z2qPwR8vXM,'GET',PPB1JrmtTzjRHn,HQmDERMFjx,headers,HQmDERMFjx,HQmDERMFjx,'ARABSEED-MENU-2nd')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	vuylTosVej845YfDNK = DyVGS3dX0ZxR.findall('"menu__bar hide__md"(.*?)</div>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	ej8EfB1iZ5Gh3X2gxWtSONH = vuylTosVej845YfDNK[o4bNzIQGYj8En]
	bbiKcPz2RQOUwS = DyVGS3dX0ZxR.findall('href="(.*?)".*?<span>(.*?)<',ej8EfB1iZ5Gh3X2gxWtSONH,DyVGS3dX0ZxR.DOTALL)
	for vn1grP3y4It9GmVuBbLJfz2A,title in bbiKcPz2RQOUwS:
		if '/category/' not in vn1grP3y4It9GmVuBbLJfz2A: continue
		title = SVsiEWeRf6oIynqQx8pCrM4Tk(title)
		if title not in FwhZ0nXtpoHTMarf and title!=HQmDERMFjx:
			if 'http' not in vn1grP3y4It9GmVuBbLJfz2A: vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+vn1grP3y4It9GmVuBbLJfz2A
			CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,251)
	return CzNPJydxQLfw27tv4ZF8KORAbX5
def REWBU20fyqaLprY(url,type):
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,headers,HQmDERMFjx,HQmDERMFjx,'ARABSEED-SUBMENU-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	if 'class="SliderInSection' in CzNPJydxQLfw27tv4ZF8KORAbX5: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'الأكثر مشاهدة',url,251,HQmDERMFjx,HQmDERMFjx,'most')
	if 'class="MainSlides' in CzNPJydxQLfw27tv4ZF8KORAbX5: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'المميزة',url,251,HQmDERMFjx,HQmDERMFjx,'featured')
	if 'class="LinksList' in CzNPJydxQLfw27tv4ZF8KORAbX5:
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('class="LinksList(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
			MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
			if len(Ut7reR0XioMjOdYWZKsLIuc3TQJmC1)>1 and type=='new_episodes': MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[1]
			items = DyVGS3dX0ZxR.findall('href="(.*?)"(.*?)</a>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
			for vn1grP3y4It9GmVuBbLJfz2A,title in items:
				eyLMq9Enup0jiJT42RDWafg = DyVGS3dX0ZxR.findall('</i>(.*?)<span>(.*?)<',title,DyVGS3dX0ZxR.DOTALL)
				try: RxlF2vgU3cdnk8 = eyLMq9Enup0jiJT42RDWafg[0][0].replace(ti3SbXNV0aJ7n5Grc4OQY8Ll1s9,HQmDERMFjx).strip(oQpxmKiRPlHeGsLXNrJF78O)
				except: RxlF2vgU3cdnk8 = HQmDERMFjx
				try: vvIQyMacnt = eyLMq9Enup0jiJT42RDWafg[0][1].replace(ti3SbXNV0aJ7n5Grc4OQY8Ll1s9,HQmDERMFjx).strip(oQpxmKiRPlHeGsLXNrJF78O)
				except: vvIQyMacnt = HQmDERMFjx
				eyLMq9Enup0jiJT42RDWafg = RxlF2vgU3cdnk8+oQpxmKiRPlHeGsLXNrJF78O+vvIQyMacnt
				if '<strong>' in title:
					jjPkRhGuOqYLz7pBAVr1nc = DyVGS3dX0ZxR.findall('</i>(.*?)<',title,DyVGS3dX0ZxR.DOTALL)
					if jjPkRhGuOqYLz7pBAVr1nc: eyLMq9Enup0jiJT42RDWafg = jjPkRhGuOqYLz7pBAVr1nc[0]
				if not eyLMq9Enup0jiJT42RDWafg:
					jjPkRhGuOqYLz7pBAVr1nc = DyVGS3dX0ZxR.findall('alt="(.*?)"',title,DyVGS3dX0ZxR.DOTALL)
					if jjPkRhGuOqYLz7pBAVr1nc: eyLMq9Enup0jiJT42RDWafg = jjPkRhGuOqYLz7pBAVr1nc[0]
				if eyLMq9Enup0jiJT42RDWafg:
					if 'key=' in vn1grP3y4It9GmVuBbLJfz2A: type = vn1grP3y4It9GmVuBbLJfz2A.split('key=')[1]
					else: type = 'newest'
					eyLMq9Enup0jiJT42RDWafg = eyLMq9Enup0jiJT42RDWafg.strip(oQpxmKiRPlHeGsLXNrJF78O)
					CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+eyLMq9Enup0jiJT42RDWafg,vn1grP3y4It9GmVuBbLJfz2A,251,HQmDERMFjx,HQmDERMFjx,type)
	return
def c8wfGju4CWZm(url,GQB0WzyICDK7mXxN2Acdi):
	ZLElwPjz5neAf1pSD,data,items = 'GET',HQmDERMFjx,[]
	if GQB0WzyICDK7mXxN2Acdi=='filters':
		if '?' in url:
			RLgNXyJ8Aov6HQDmCiE4B1sOU,Vi9fwvbSBCI0K6hgXA8EpFrT = 'POST',{}
			SSHjMN4uegZfb2,y4MTtLsPzU35SHa = url.split('?')
			Nb3rHkOs6yKCJAlSW5DPLTciBVq2 = y4MTtLsPzU35SHa.split('&')
			for Z8rQtIjXYHz6d in Nb3rHkOs6yKCJAlSW5DPLTciBVq2:
				key,value = Z8rQtIjXYHz6d.split('=')
				Vi9fwvbSBCI0K6hgXA8EpFrT[key] = value
			if Nb3rHkOs6yKCJAlSW5DPLTciBVq2: ZLElwPjz5neAf1pSD,url,data = RLgNXyJ8Aov6HQDmCiE4B1sOU,SSHjMN4uegZfb2,Vi9fwvbSBCI0K6hgXA8EpFrT
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,ZLElwPjz5neAf1pSD,url,data,headers,HQmDERMFjx,HQmDERMFjx,'ARABSEED-TITLES-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	if GQB0WzyICDK7mXxN2Acdi=='filters': Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = [CzNPJydxQLfw27tv4ZF8KORAbX5]
	elif 'featured' in GQB0WzyICDK7mXxN2Acdi: Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"swiper-wrapper"(.*?)</section>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	elif GQB0WzyICDK7mXxN2Acdi=='new_movies': Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('<b>احدث الافلام</b>(.*?)</section>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	elif GQB0WzyICDK7mXxN2Acdi=='new_episodes': Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('<b>احدث الحلقات</b>(.*?)</section>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	elif GQB0WzyICDK7mXxN2Acdi=='most': Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('class="SliderInSection(.*?)class="LinksList',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	else: Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"blocks__section(.*?)"paginate"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if 'featured' in GQB0WzyICDK7mXxN2Acdi:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	else: MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	items = DyVGS3dX0ZxR.findall('"item__contents.*?href="(.*?)".*? title="(.*?)".*?src="(.*?)"',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	if not items: items = DyVGS3dX0ZxR.findall('href="([^"]*)" title="([^"]*)".*?src="(.*?)"',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	ORMkTYjJ1p7 = []
	for vn1grP3y4It9GmVuBbLJfz2A,title,uIGD4vZcP61QNmw78LXqoEpH in items:
		if 'WWE' in title: continue
		title = SVsiEWeRf6oIynqQx8pCrM4Tk(title)
		if 'الحلقة' in title:
			yTz8SOkAhu24j6apo9BmZHvwWsX = DyVGS3dX0ZxR.findall('(.*?) الحلقة \d+',title,DyVGS3dX0ZxR.DOTALL)
			if yTz8SOkAhu24j6apo9BmZHvwWsX:
				title = '_MOD_' + yTz8SOkAhu24j6apo9BmZHvwWsX[0]
				if title not in ORMkTYjJ1p7:
					ORMkTYjJ1p7.append(title)
					CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,253,uIGD4vZcP61QNmw78LXqoEpH)
			else: CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,252,uIGD4vZcP61QNmw78LXqoEpH)
		elif '/selary/' in vn1grP3y4It9GmVuBbLJfz2A or 'مسلسل' in title:
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,253,uIGD4vZcP61QNmw78LXqoEpH)
		else:
			CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,252,uIGD4vZcP61QNmw78LXqoEpH)
	if not GQB0WzyICDK7mXxN2Acdi or GQB0WzyICDK7mXxN2Acdi in ['search','filters']:
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"paginate"(.*?)</section>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
			MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
			items = DyVGS3dX0ZxR.findall('href="(.*?)">(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
			for vn1grP3y4It9GmVuBbLJfz2A,title in items:
				title = SVsiEWeRf6oIynqQx8pCrM4Tk(title)
				CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'صفحة '+title,vn1grP3y4It9GmVuBbLJfz2A,251,HQmDERMFjx,HQmDERMFjx,GQB0WzyICDK7mXxN2Acdi)
	return
def XONC9osGSP4fW5HVrhM(url):
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,headers,HQmDERMFjx,HQmDERMFjx,'ARABSEED-EPISODES-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	items = DyVGS3dX0ZxR.findall('"poster__single".*?src="(.*?)".*?alt="(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if not items: return
	uIGD4vZcP61QNmw78LXqoEpH,name = items[0]
	if 'الحلقة' in name: name = name.split('الحلقة')[0].strip(oQpxmKiRPlHeGsLXNrJF78O)
	elif 'حلقة' in name: name = name.split('حلقة')[0].strip(oQpxmKiRPlHeGsLXNrJF78O)
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"episodes__list boxs__wrapper(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('href="(.*?)".*?"epi__num">.*?<b>(.*?)</b>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,yTz8SOkAhu24j6apo9BmZHvwWsX in items:
			title = name+' - حلقة رقم '+yTz8SOkAhu24j6apo9BmZHvwWsX
			CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,252,uIGD4vZcP61QNmw78LXqoEpH)
	else: CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+'ملف التشغيل',url,252,uIGD4vZcP61QNmw78LXqoEpH)
	return
def iDkZdurf8OPwBnbe4HYcmaUv50Sxp(title,vn1grP3y4It9GmVuBbLJfz2A):
	eyLMq9Enup0jiJT42RDWafg = DyVGS3dX0ZxR.findall('[a-zA-Z-]+',title,DyVGS3dX0ZxR.DOTALL)
	if eyLMq9Enup0jiJT42RDWafg: title = eyLMq9Enup0jiJT42RDWafg[0]
	else: title = title+oQpxmKiRPlHeGsLXNrJF78O+DpClq35GVjh(vn1grP3y4It9GmVuBbLJfz2A,'name')
	title = title.replace('عرب سيد',HQmDERMFjx).replace('مباشر',HQmDERMFjx).replace('مشاهدة',HQmDERMFjx)
	title = title.replace('ٍ',HQmDERMFjx)
	title = title.replace(MSnXBQNUg1jF3W2fRlE9OLaCT8ds4,oQpxmKiRPlHeGsLXNrJF78O).replace(MSnXBQNUg1jF3W2fRlE9OLaCT8ds4,oQpxmKiRPlHeGsLXNrJF78O)
	return title
def f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url):
	pYVvlGR1ES0gdtzayiDqb9w = DpClq35GVjh(url,'url')
	headers = {'Referer':pYVvlGR1ES0gdtzayiDqb9w}
	KWnAuJIFyESQHjP3X5xzMqUbR6L,ceF5tR6GPC4 = [],[]
	otP07csEQAmMKal = url.rstrip('/')+'/download'
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(H5x4Z2qPwR8vXM,'GET',otP07csEQAmMKal,HQmDERMFjx,headers,HQmDERMFjx,HQmDERMFjx,'ARABSEED-PLAY-1st')
	b3L20nx7qwHKTS6so = vGXnw9VcUN.content
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"downloads__tabs"(.*?)</section>',b3L20nx7qwHKTS6so,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('href="([^"]*)".*?<h4>(.*?)</h4>.*?<p>(.*?)</p>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,Uo6C7vBYqD9uOS,eyLMq9Enup0jiJT42RDWafg in items:
			RRpfksr1PbZagwCIOJXYNHTo = DyVGS3dX0ZxR.findall('\d+',eyLMq9Enup0jiJT42RDWafg,DyVGS3dX0ZxR.DOTALL)
			RRpfksr1PbZagwCIOJXYNHTo = '__'+RRpfksr1PbZagwCIOJXYNHTo[0] if RRpfksr1PbZagwCIOJXYNHTo else HQmDERMFjx
			if '/l/' in vn1grP3y4It9GmVuBbLJfz2A:
				vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A.split('/l/')[1]
				vn1grP3y4It9GmVuBbLJfz2A = x4aBluXo02G1eTPr9c.b64decode(vn1grP3y4It9GmVuBbLJfz2A)
				if HH6mxXjgcrEN1aenMFWQkS: vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A.decode(Zex6D4tJE52r)
			if vn1grP3y4It9GmVuBbLJfz2A in ceF5tR6GPC4: continue
			ceF5tR6GPC4.append(vn1grP3y4It9GmVuBbLJfz2A)
			vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A+'?named='+Uo6C7vBYqD9uOS+'__download'+RRpfksr1PbZagwCIOJXYNHTo
			KWnAuJIFyESQHjP3X5xzMqUbR6L.append(vn1grP3y4It9GmVuBbLJfz2A)
	wwmEVad1obxMSBXick2zI8qnRpr = url.rstrip('/')+'/watch'
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(H5x4Z2qPwR8vXM,'GET',wwmEVad1obxMSBXick2zI8qnRpr,HQmDERMFjx,headers,HQmDERMFjx,HQmDERMFjx,'ARABSEED-PLAY-2nd')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('class="servers__list(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('data-qu="(.*?)".*?data-link="(.*?)".*?<span>(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for RRpfksr1PbZagwCIOJXYNHTo,vn1grP3y4It9GmVuBbLJfz2A,title in items:
			if '=aHR0' in vn1grP3y4It9GmVuBbLJfz2A:
				QVCFcvb5RE3i0Ajw41nXIK = DyVGS3dX0ZxR.findall('=(aHR0.*?)$',vn1grP3y4It9GmVuBbLJfz2A,DyVGS3dX0ZxR.DOTALL)
				if QVCFcvb5RE3i0Ajw41nXIK:
					vn1grP3y4It9GmVuBbLJfz2A = x4aBluXo02G1eTPr9c.b64decode(QVCFcvb5RE3i0Ajw41nXIK[0]+'===').decode(Zex6D4tJE52r)
					vn1grP3y4It9GmVuBbLJfz2A = Dv4BW0g8de6qKQtVrGJ1PEXRpywc7A(vn1grP3y4It9GmVuBbLJfz2A)
			if 'http' not in vn1grP3y4It9GmVuBbLJfz2A: vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+vn1grP3y4It9GmVuBbLJfz2A
			if vn1grP3y4It9GmVuBbLJfz2A in ceF5tR6GPC4: continue
			ceF5tR6GPC4.append(vn1grP3y4It9GmVuBbLJfz2A)
			vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A+'?named='+title+'__watch__'+RRpfksr1PbZagwCIOJXYNHTo
			KWnAuJIFyESQHjP3X5xzMqUbR6L.append(vn1grP3y4It9GmVuBbLJfz2A)
	A07BpVeRJToLb = DyVGS3dX0ZxR.findall('"video_frame" src="(.*?)".*?height="(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL|DyVGS3dX0ZxR.IGNORECASE)
	if A07BpVeRJToLb:
		vn1grP3y4It9GmVuBbLJfz2A,RRpfksr1PbZagwCIOJXYNHTo = A07BpVeRJToLb[0]
		if '=aHR0' in vn1grP3y4It9GmVuBbLJfz2A:
			QVCFcvb5RE3i0Ajw41nXIK = DyVGS3dX0ZxR.findall('=(aHR0.*?)$',vn1grP3y4It9GmVuBbLJfz2A,DyVGS3dX0ZxR.DOTALL)
			if QVCFcvb5RE3i0Ajw41nXIK:
				vn1grP3y4It9GmVuBbLJfz2A = x4aBluXo02G1eTPr9c.b64decode(QVCFcvb5RE3i0Ajw41nXIK[0]+'===').decode(Zex6D4tJE52r)
				vn1grP3y4It9GmVuBbLJfz2A = Dv4BW0g8de6qKQtVrGJ1PEXRpywc7A(vn1grP3y4It9GmVuBbLJfz2A)
		if 'http' not in vn1grP3y4It9GmVuBbLJfz2A: vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+vn1grP3y4It9GmVuBbLJfz2A
		name = DpClq35GVjh(vn1grP3y4It9GmVuBbLJfz2A,'name')
		if vn1grP3y4It9GmVuBbLJfz2A not in ceF5tR6GPC4:
			ceF5tR6GPC4.append(vn1grP3y4It9GmVuBbLJfz2A)
			vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A+'?named='+name+'__embed__'+RRpfksr1PbZagwCIOJXYNHTo
			KWnAuJIFyESQHjP3X5xzMqUbR6L.append(vn1grP3y4It9GmVuBbLJfz2A)
	import NsD5AomUqH
	NsD5AomUqH.NZcWGBmgFEen5hvJjUSIzOCVk7(KWnAuJIFyESQHjP3X5xzMqUbR6L,HDLtdMAy7wPkl8aKC3O2,'video',url)
	return
def TcumMxUIbFBSQ8gYfq3l7aLozrpyV(url):
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(H5x4Z2qPwR8vXM,'GET',url,HQmDERMFjx,headers,HQmDERMFjx,HQmDERMFjx,'ARABSEED-PLAY-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	SSHjMN4uegZfb2 = vGXnw9VcUN.url
	pYVvlGR1ES0gdtzayiDqb9w = DpClq35GVjh(SSHjMN4uegZfb2,'url')
	headers['Referer'] = pYVvlGR1ES0gdtzayiDqb9w+xufJqQcGnhboiVy2wd
	headers['Content-Type'] = 'application/x-www-form-urlencoded'
	Na8vklCpUGYIzP0bjutWOT,tjkSneJ5qVHhY89 = [],[]
	VkUOGoBAPlqgxabLy92HWSTid8I,Wqfk389zaeXGlyir6VsE1,LYyJVkp3MvrRhTn715O4HsBKqZG = HQmDERMFjx,HQmDERMFjx,HQmDERMFjx
	lLfiZerI7FMkKBjC,NjscXEdPMqx01QVG4tTSZ2knA3Rgv,qNpXzmhe6CJ94AHoYkywQTSluRIM = HQmDERMFjx,HQmDERMFjx,HQmDERMFjx
	lS0Qk6nq9g35ZrvaIM8wWOzjxiPKH = DyVGS3dX0ZxR.findall('"WatchButtons"(.*?)</div>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if lS0Qk6nq9g35ZrvaIM8wWOzjxiPKH:
		MJ2gSPyTl9hzoi1 = lS0Qk6nq9g35ZrvaIM8wWOzjxiPKH[o4bNzIQGYj8En]
		if '<form' in MJ2gSPyTl9hzoi1:
			tjkSneJ5qVHhY89 = DyVGS3dX0ZxR.findall('<form action="(.*?)".*?name="(.*?)".*?value="(.*?)"',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
			if tjkSneJ5qVHhY89:
				ZLElwPjz5neAf1pSD = 'POST'
				for D451McqY2LVhkFZ9dXeo,name,value in tjkSneJ5qVHhY89:
					if 'wpost' in name: VkUOGoBAPlqgxabLy92HWSTid8I,Wqfk389zaeXGlyir6VsE1,LYyJVkp3MvrRhTn715O4HsBKqZG = D451McqY2LVhkFZ9dXeo,name,value
					elif 'dpost' in name: lLfiZerI7FMkKBjC,NjscXEdPMqx01QVG4tTSZ2knA3Rgv,qNpXzmhe6CJ94AHoYkywQTSluRIM = D451McqY2LVhkFZ9dXeo,name,value
				TT7AILcftW = Wqfk389zaeXGlyir6VsE1+'='+LYyJVkp3MvrRhTn715O4HsBKqZG
				mmF2VS3jM0paz = NjscXEdPMqx01QVG4tTSZ2knA3Rgv+'='+qNpXzmhe6CJ94AHoYkywQTSluRIM
		else:
			tjkSneJ5qVHhY89 = DyVGS3dX0ZxR.findall('href="(.*?)"',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
			if tjkSneJ5qVHhY89:
				ZLElwPjz5neAf1pSD = 'GET'
				for vn1grP3y4It9GmVuBbLJfz2A in tjkSneJ5qVHhY89:
					if 'wpost' in vn1grP3y4It9GmVuBbLJfz2A: VkUOGoBAPlqgxabLy92HWSTid8I = vn1grP3y4It9GmVuBbLJfz2A
					elif 'dpost' in vn1grP3y4It9GmVuBbLJfz2A: lLfiZerI7FMkKBjC = vn1grP3y4It9GmVuBbLJfz2A
				TT7AILcftW = HQmDERMFjx
				mmF2VS3jM0paz = HQmDERMFjx
	if VkUOGoBAPlqgxabLy92HWSTid8I:
		vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(H5x4Z2qPwR8vXM,ZLElwPjz5neAf1pSD,VkUOGoBAPlqgxabLy92HWSTid8I,TT7AILcftW,headers,HQmDERMFjx,HQmDERMFjx,'ARABSEED-PLAY-2nd')
		CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('class="WatcherArea(.*?</ul>)',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
			yPVGFNSOr8anHBXeY1oJRk6MCdKDm = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
			yPVGFNSOr8anHBXeY1oJRk6MCdKDm = yPVGFNSOr8anHBXeY1oJRk6MCdKDm.replace('</ul>','<h3>')
			yPVGFNSOr8anHBXeY1oJRk6MCdKDm = yPVGFNSOr8anHBXeY1oJRk6MCdKDm.replace('<h3>','<h3><h3>')
			bUzHWnGg5t1 = DyVGS3dX0ZxR.findall('<h3>.*?(\d+)(.*?)<h3>',yPVGFNSOr8anHBXeY1oJRk6MCdKDm,DyVGS3dX0ZxR.DOTALL)
			if not bUzHWnGg5t1: bUzHWnGg5t1 = [(HQmDERMFjx,yPVGFNSOr8anHBXeY1oJRk6MCdKDm)]
			for RRpfksr1PbZagwCIOJXYNHTo,MJ2gSPyTl9hzoi1 in bUzHWnGg5t1:
				if RRpfksr1PbZagwCIOJXYNHTo: RRpfksr1PbZagwCIOJXYNHTo = '____'+RRpfksr1PbZagwCIOJXYNHTo
				items = DyVGS3dX0ZxR.findall('data-link="(.*?)".*?<span>(.*?)</span>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
				for vn1grP3y4It9GmVuBbLJfz2A,name in items:
					if 'http' not in vn1grP3y4It9GmVuBbLJfz2A: vn1grP3y4It9GmVuBbLJfz2A = 'http:'+vn1grP3y4It9GmVuBbLJfz2A
					vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A+'?named='+name+'__watch'+RRpfksr1PbZagwCIOJXYNHTo
					Na8vklCpUGYIzP0bjutWOT.append(vn1grP3y4It9GmVuBbLJfz2A)
		jzTLleJs8x9Hb1 = DyVGS3dX0ZxR.findall('class="containerIframe".*? src="(.*?)".*? height="(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL|DyVGS3dX0ZxR.IGNORECASE)
		if jzTLleJs8x9Hb1:
			vn1grP3y4It9GmVuBbLJfz2A,RRpfksr1PbZagwCIOJXYNHTo = jzTLleJs8x9Hb1[0]
			name = DpClq35GVjh(vn1grP3y4It9GmVuBbLJfz2A,'name')
			if '%' in RRpfksr1PbZagwCIOJXYNHTo: vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A+'?named='+name+'__embed__'
			else: vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A+'?named='+name+'__embed____'+RRpfksr1PbZagwCIOJXYNHTo
			Na8vklCpUGYIzP0bjutWOT.append(vn1grP3y4It9GmVuBbLJfz2A)
	if lLfiZerI7FMkKBjC:
		vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(H5x4Z2qPwR8vXM,ZLElwPjz5neAf1pSD,lLfiZerI7FMkKBjC,mmF2VS3jM0paz,headers,HQmDERMFjx,HQmDERMFjx,'ARABSEED-PLAY-3rd')
		CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('class="DownloadArea(.*?)<script src=',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
			yPVGFNSOr8anHBXeY1oJRk6MCdKDm = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
			bUzHWnGg5t1 = DyVGS3dX0ZxR.findall('class="DownloadServers(.*?)</ul>',yPVGFNSOr8anHBXeY1oJRk6MCdKDm,DyVGS3dX0ZxR.DOTALL)
			for MJ2gSPyTl9hzoi1 in bUzHWnGg5t1:
				items = DyVGS3dX0ZxR.findall('href="(.*?)".*?<span>(.*?)</span>.*?<p>(.*?)</p>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
				for vn1grP3y4It9GmVuBbLJfz2A,title,RRpfksr1PbZagwCIOJXYNHTo in items:
					if not vn1grP3y4It9GmVuBbLJfz2A: continue
					if 'reviewstation' in vn1grP3y4It9GmVuBbLJfz2A: continue
					vn1grP3y4It9GmVuBbLJfz2A = xx9LK4VzpF6IHXSEyhmrQwbg25P0(vn1grP3y4It9GmVuBbLJfz2A)
					vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A+'?named='+title+'__download____'+RRpfksr1PbZagwCIOJXYNHTo
					Na8vklCpUGYIzP0bjutWOT.append(vn1grP3y4It9GmVuBbLJfz2A)
	BeaxQMA9soc3VE2itKW6zJ0HC = str(Na8vklCpUGYIzP0bjutWOT)
	TJeVSOQADMsW = ['.zip?','.rar?','.txt?','.pdf?','.tar?','.iso?','.zip.','.rar.','.txt.','.pdf.','.tar.','.iso.']
	if any(value in BeaxQMA9soc3VE2itKW6zJ0HC for value in TJeVSOQADMsW):
		u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,'جرب رابط مختلف لأن هذا الرابط ليس من نوع الروابط التي فيها ملفات فيديو .. لأن هذا الموقع فيه خدمات أخرى غير ملفات الفيديو')
		return
	import NsD5AomUqH
	NsD5AomUqH.NZcWGBmgFEen5hvJjUSIzOCVk7(Na8vklCpUGYIzP0bjutWOT,HDLtdMAy7wPkl8aKC3O2,'video',url)
	return
def hm4kawIPKp3oMrC75dJZA9HS2(search):
	search,GXVabd4sc2u3zp0JI,showDialogs = x0pzMENwy84tBcZvXr(search)
	if not search: search = q156m84QoYrn()
	if not search: return
	search = search.replace(oQpxmKiRPlHeGsLXNrJF78O,'+')
	url = e2VR8nohduY+'/find/?word='+search+'&type='
	c8wfGju4CWZm(url,'search')
	return
def ooxUXkcTj5PF4ad2SwYy(url,filter):
	if '??' in url: url = url.split('//getposts??')[0]
	type,filter = filter.split('___',1)
	if filter==HQmDERMFjx: eA0pnTuMvxrdmoRC9zPBh,mwhEr8eXxD21MAKfHUSlB = HQmDERMFjx,HQmDERMFjx
	else: eA0pnTuMvxrdmoRC9zPBh,mwhEr8eXxD21MAKfHUSlB = filter.split('___')
	if type=='CATEGORIES':
		if pprqLo46Mmyt[0]+'==' not in eA0pnTuMvxrdmoRC9zPBh: WF2vkePC5gbXAGUarcqlpmB3Q = pprqLo46Mmyt[0]
		for yuYts1RONXgp in range(len(pprqLo46Mmyt[0:-1])):
			if pprqLo46Mmyt[yuYts1RONXgp]+'==' in eA0pnTuMvxrdmoRC9zPBh: WF2vkePC5gbXAGUarcqlpmB3Q = pprqLo46Mmyt[yuYts1RONXgp+1]
		Cm5jWJgr28TlUnoZYHAxdPI3OB = eA0pnTuMvxrdmoRC9zPBh+'&&'+WF2vkePC5gbXAGUarcqlpmB3Q+'==0'
		RRDtwVh6LbFiEycHNQkId5Cefmq = mwhEr8eXxD21MAKfHUSlB+'&&'+WF2vkePC5gbXAGUarcqlpmB3Q+'==0'
		GSPtdslyxQURmB5obg69VJMY1jE = Cm5jWJgr28TlUnoZYHAxdPI3OB.strip('&&')+'___'+RRDtwVh6LbFiEycHNQkId5Cefmq.strip('&&')
		J4asIxU7Zyq5PiN2rKEctegFV = jlZtWwMfosJFIKenicqU1(mwhEr8eXxD21MAKfHUSlB,'modified_filters')
		SSHjMN4uegZfb2 = url+'//getposts??'+J4asIxU7Zyq5PiN2rKEctegFV
	elif type=='FILTERS':
		v2s9V6uhIT0aCjkPOl7iUqZxB = jlZtWwMfosJFIKenicqU1(eA0pnTuMvxrdmoRC9zPBh,'modified_values')
		v2s9V6uhIT0aCjkPOl7iUqZxB = xx9LK4VzpF6IHXSEyhmrQwbg25P0(v2s9V6uhIT0aCjkPOl7iUqZxB)
		if mwhEr8eXxD21MAKfHUSlB!=HQmDERMFjx: mwhEr8eXxD21MAKfHUSlB = jlZtWwMfosJFIKenicqU1(mwhEr8eXxD21MAKfHUSlB,'modified_filters')
		if mwhEr8eXxD21MAKfHUSlB==HQmDERMFjx: SSHjMN4uegZfb2 = url
		else: SSHjMN4uegZfb2 = url+'//getposts??'+mwhEr8eXxD21MAKfHUSlB
		fVkhY4eGsLdDb = uxCSl20HwrRZBv3g8tqnYUDzQPVp(SSHjMN4uegZfb2)
		CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'أظهار قائمة الفيديو التي تم اختيارها ',fVkhY4eGsLdDb,251,HQmDERMFjx,HQmDERMFjx,'filters')
		CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+' [[   '+v2s9V6uhIT0aCjkPOl7iUqZxB+'   ]]',fVkhY4eGsLdDb,251,HQmDERMFjx,HQmDERMFjx,'filters')
		CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(H5x4Z2qPwR8vXM,'POST',url,HQmDERMFjx,headers,HQmDERMFjx,HQmDERMFjx,'ARABSEED-FILTERS_MENU-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('class="TaxPageFilter"(.*?)class="TermBTNs"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	dkOzIfYvutj7 = DyVGS3dX0ZxR.findall('class="TaxPageFilterItem".*?<em>(.*?)</em>.*?data-tax="(.*?)"(.*?)</ul>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	WMsEcZUu4qwHkv = DyVGS3dX0ZxR.findall('class="RatingFilter".*?<h4>(.*?)</h4>.*?(<ul>)(.*?)</ul>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	jnPZuGqg9F5viBUp = dkOzIfYvutj7+WMsEcZUu4qwHkv
	dict = {}
	for name,DcpbqKxWsJRCSVkQyjf1,MJ2gSPyTl9hzoi1 in jnPZuGqg9F5viBUp:
		items = DyVGS3dX0ZxR.findall('data-name="(.*?)".*?data-tax="(.*?)".*?data-term="(.*?)"',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		if name=='اخرى': name = 'الاقسام'
		if not items:
			bbiKcPz2RQOUwS = DyVGS3dX0ZxR.findall('data-rate="(.*?)".*?<em>(.*?)</em>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
			items = []
			for yewoKb5dkfHu1xEZMAsY,value in bbiKcPz2RQOUwS: items.append([yewoKb5dkfHu1xEZMAsY,HQmDERMFjx,value])
			DcpbqKxWsJRCSVkQyjf1 = 'rate'
			name = 'التقييم'
		else: DcpbqKxWsJRCSVkQyjf1 = items[0][1]
		if '==' not in SSHjMN4uegZfb2: SSHjMN4uegZfb2 = url
		if type=='CATEGORIES':
			if WF2vkePC5gbXAGUarcqlpmB3Q!=DcpbqKxWsJRCSVkQyjf1: continue
			elif len(items)<=1:
				if DcpbqKxWsJRCSVkQyjf1==pprqLo46Mmyt[-1]: c8wfGju4CWZm(SSHjMN4uegZfb2)
				else: ooxUXkcTj5PF4ad2SwYy(SSHjMN4uegZfb2,'CATEGORIES___'+GSPtdslyxQURmB5obg69VJMY1jE)
				return
			else:
				fVkhY4eGsLdDb = uxCSl20HwrRZBv3g8tqnYUDzQPVp(SSHjMN4uegZfb2)
				if DcpbqKxWsJRCSVkQyjf1==pprqLo46Mmyt[-1]: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'الجميع ',fVkhY4eGsLdDb,251,HQmDERMFjx,HQmDERMFjx,'filters')
				else: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'الجميع ',SSHjMN4uegZfb2,254,HQmDERMFjx,HQmDERMFjx,GSPtdslyxQURmB5obg69VJMY1jE)
		elif type=='FILTERS':
			Cm5jWJgr28TlUnoZYHAxdPI3OB = eA0pnTuMvxrdmoRC9zPBh+'&&'+DcpbqKxWsJRCSVkQyjf1+'==0'
			RRDtwVh6LbFiEycHNQkId5Cefmq = mwhEr8eXxD21MAKfHUSlB+'&&'+DcpbqKxWsJRCSVkQyjf1+'==0'
			GSPtdslyxQURmB5obg69VJMY1jE = Cm5jWJgr28TlUnoZYHAxdPI3OB+'___'+RRDtwVh6LbFiEycHNQkId5Cefmq
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'الجميع :'+name,SSHjMN4uegZfb2,255,HQmDERMFjx,HQmDERMFjx,GSPtdslyxQURmB5obg69VJMY1jE)
		dict[DcpbqKxWsJRCSVkQyjf1] = {}
		for yewoKb5dkfHu1xEZMAsY,RZ9V4eABCTfIO1FUrz2ks5DSwu,value in items:
			if yewoKb5dkfHu1xEZMAsY in FwhZ0nXtpoHTMarf: continue
			if 'الكل' in yewoKb5dkfHu1xEZMAsY: continue
			yewoKb5dkfHu1xEZMAsY = SVsiEWeRf6oIynqQx8pCrM4Tk(yewoKb5dkfHu1xEZMAsY)
			Uo6C7vBYqD9uOS,eyLMq9Enup0jiJT42RDWafg = yewoKb5dkfHu1xEZMAsY,yewoKb5dkfHu1xEZMAsY
			eyLMq9Enup0jiJT42RDWafg = name+': '+Uo6C7vBYqD9uOS
			dict[DcpbqKxWsJRCSVkQyjf1][value] = eyLMq9Enup0jiJT42RDWafg
			Cm5jWJgr28TlUnoZYHAxdPI3OB = eA0pnTuMvxrdmoRC9zPBh+'&&'+DcpbqKxWsJRCSVkQyjf1+'=='+Uo6C7vBYqD9uOS
			RRDtwVh6LbFiEycHNQkId5Cefmq = mwhEr8eXxD21MAKfHUSlB+'&&'+DcpbqKxWsJRCSVkQyjf1+'=='+value
			CEniUGWr4jMy = Cm5jWJgr28TlUnoZYHAxdPI3OB+'___'+RRDtwVh6LbFiEycHNQkId5Cefmq
			if type=='FILTERS':
				CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+eyLMq9Enup0jiJT42RDWafg,url,255,HQmDERMFjx,HQmDERMFjx,CEniUGWr4jMy)
			elif type=='CATEGORIES' and pprqLo46Mmyt[-2]+'==' in eA0pnTuMvxrdmoRC9zPBh:
				J4asIxU7Zyq5PiN2rKEctegFV = jlZtWwMfosJFIKenicqU1(RRDtwVh6LbFiEycHNQkId5Cefmq,'modified_filters')
				jDcWv7MAkEV = url+'//getposts??'+J4asIxU7Zyq5PiN2rKEctegFV
				fVkhY4eGsLdDb = uxCSl20HwrRZBv3g8tqnYUDzQPVp(jDcWv7MAkEV)
				CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+eyLMq9Enup0jiJT42RDWafg,fVkhY4eGsLdDb,251,HQmDERMFjx,HQmDERMFjx,'filters')
			else: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+eyLMq9Enup0jiJT42RDWafg,url,254,HQmDERMFjx,HQmDERMFjx,CEniUGWr4jMy)
	return
pprqLo46Mmyt = ['category','country','release-year']
mZFuJUesnayLvz0jMBOfxw = ['category','country','genre','release-year','language','quality','rate']
def uxCSl20HwrRZBv3g8tqnYUDzQPVp(url):
	wHgYBZ1FPD = '/wp-content/themes/Elshaikh2021/Ajaxat/Home/FilteringHome.php'
	url = url.replace('//getposts',wHgYBZ1FPD)
	url = url.replace('/category/اخرى',HQmDERMFjx)
	if wHgYBZ1FPD not in url: url = url+wHgYBZ1FPD
	url = url.replace('release-year','year')
	url = url.replace('??','?')
	url = url.replace('&&','&')
	url = url.replace('==','=')
	return url
def jlZtWwMfosJFIKenicqU1(Eya9L4IY3GxqtNoVWegDcPuOR,mode):
	Eya9L4IY3GxqtNoVWegDcPuOR = Eya9L4IY3GxqtNoVWegDcPuOR.strip('&&')
	AAwtDoF34Y890RXse,n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6 = {},HQmDERMFjx
	if '==' in Eya9L4IY3GxqtNoVWegDcPuOR:
		items = Eya9L4IY3GxqtNoVWegDcPuOR.split('&&')
		for A07BpVeRJToLb in items:
			airVhHdqCb6Gf49eERSjv1,value = A07BpVeRJToLb.split('==')
			AAwtDoF34Y890RXse[airVhHdqCb6Gf49eERSjv1] = value
	for key in mZFuJUesnayLvz0jMBOfxw:
		if key in list(AAwtDoF34Y890RXse.keys()): value = AAwtDoF34Y890RXse[key]
		else: value = '0'
		if '%' not in value: value = VVkOtyQLzxBr(value)
		if mode=='modified_values' and value!='0': n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6 = n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6+' + '+value
		elif mode=='modified_filters' and value!='0': n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6 = n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6+'&&'+key+'=='+value
		elif mode=='all': n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6 = n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6+'&&'+key+'=='+value
	n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6 = n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6.strip(' + ')
	n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6 = n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6.strip('&&')
	return n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6
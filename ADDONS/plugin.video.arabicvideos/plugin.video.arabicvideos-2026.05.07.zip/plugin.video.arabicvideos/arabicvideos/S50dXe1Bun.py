# -*- coding: utf-8 -*-
from FF68kA5BUy import *
HDLtdMAy7wPkl8aKC3O2 = 'ARBLIONZ'
headers = { 'User-Agent' : HQmDERMFjx }
EEJvXQzSZNt = '_ARL_'
e2VR8nohduY = Jzthpc2nj5.SITESURLS[HDLtdMAy7wPkl8aKC3O2][0]
FwhZ0nXtpoHTMarf = ['عروض المصارعة','الكل','الرئيسية','العاب','برامج كمبيوتر','موبايل و جوال','القسم الاسلامي']
def kk6X5LxpsND(mode,url,text):
	if   mode==200: zLZUkrP7ac5 = afkxo7FyZWB4O6K1eXrs5I()
	elif mode==201: zLZUkrP7ac5 = c8wfGju4CWZm(url)
	elif mode==202: zLZUkrP7ac5 = f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url)
	elif mode==203: zLZUkrP7ac5 = XONC9osGSP4fW5HVrhM(url)
	elif mode==204: zLZUkrP7ac5 = ooxUXkcTj5PF4ad2SwYy(url,'FILTERS___'+text)
	elif mode==205: zLZUkrP7ac5 = ooxUXkcTj5PF4ad2SwYy(url,'CATEGORIES___'+text)
	elif mode==209: zLZUkrP7ac5 = hm4kawIPKp3oMrC75dJZA9HS2(text)
	else: zLZUkrP7ac5 = False
	return zLZUkrP7ac5
def afkxo7FyZWB4O6K1eXrs5I():
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'بحث في الموقع',HQmDERMFjx,209,HQmDERMFjx,HQmDERMFjx,'_REMEMBERRESULTS_')
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'فلتر محدد',e2VR8nohduY,205)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'فلتر كامل',e2VR8nohduY,204)
	CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+'مميزة',e2VR8nohduY+'??trending',201)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+'أفلام مميزة',e2VR8nohduY+'??trending_movies',201)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+'مسلسلات مميزة',e2VR8nohduY+'??trending_series',201)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+'الصفحة الرئيسية',e2VR8nohduY+'??mainpage',201)
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(H5x4Z2qPwR8vXM,'GET',e2VR8nohduY,HQmDERMFjx,headers,True,HQmDERMFjx,'ARBLIONZ-MENU-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('categories-tabs(.*?)MainRow',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('data-get="(.*?)".*?<h3>(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for filter,title in items:
			vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+'/ajax/home/more?filter='+filter
			CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,201)
		CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('navigation-menu(.*?)</div>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	items = DyVGS3dX0ZxR.findall('href="(.*?)".*?>(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	for vn1grP3y4It9GmVuBbLJfz2A,title in items:
		if 'http' not in vn1grP3y4It9GmVuBbLJfz2A: vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+vn1grP3y4It9GmVuBbLJfz2A
		title = title.strip(oQpxmKiRPlHeGsLXNrJF78O)
		if not any(value in title for value in FwhZ0nXtpoHTMarf):
			CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,201)
	return CzNPJydxQLfw27tv4ZF8KORAbX5
def c8wfGju4CWZm(url):
	if '??' in url: url,type = url.split('??')
	else: type = HQmDERMFjx
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,headers,True,HQmDERMFjx,'ARBLIONZ-TITLES-2nd')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content.encode(Zex6D4tJE52r)
	if 'getposts' in url: Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = [CzNPJydxQLfw27tv4ZF8KORAbX5]
	elif type=='trending':
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('MasterSlider(.*?)</div>\n *</div>\n *</div>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	elif type=='trending_movies':
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('Slider_1(.*?)</div>.</div>.</div>.</div>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	elif type=='trending_series':
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('Slider_2(.*?)</div>.</div>.</div>.</div>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	elif type=='111mainpage':
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('class="container page-content"(.*?)class="tabs"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	else:
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('page-content(.*?)main-footer',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if not Ut7reR0XioMjOdYWZKsLIuc3TQJmC1: return
	MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	Dfbu0wOr6IcqhE2XCUKn = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	items = DyVGS3dX0ZxR.findall('content-box".*?src="(.*?)".*?href="(.*?)".*?<h3>(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	if not items:
		items = DyVGS3dX0ZxR.findall('SliderItem".*?href="(.*?)".*?image: url\((.*?)\).*?<h2>(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		jzTLleJs8x9Hb1,xWR90Dw2kZa4TGz51NQMU3hIv7rXE,qP1wT2MFf0oK9Uv3u87QL = zip(*items)
		items = zip(xWR90Dw2kZa4TGz51NQMU3hIv7rXE,jzTLleJs8x9Hb1,qP1wT2MFf0oK9Uv3u87QL)
	ORMkTYjJ1p7 = []
	for uIGD4vZcP61QNmw78LXqoEpH,vn1grP3y4It9GmVuBbLJfz2A,title in items:
		if '/series/' in vn1grP3y4It9GmVuBbLJfz2A: continue
		vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A.strip(xufJqQcGnhboiVy2wd)
		title = SVsiEWeRf6oIynqQx8pCrM4Tk(title)
		title = title.strip(oQpxmKiRPlHeGsLXNrJF78O)
		if '/film/' in vn1grP3y4It9GmVuBbLJfz2A or any(value in title for value in Dfbu0wOr6IcqhE2XCUKn):
			CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,202,uIGD4vZcP61QNmw78LXqoEpH)
		elif '/episode/' in vn1grP3y4It9GmVuBbLJfz2A and 'الحلقة' in title:
			yTz8SOkAhu24j6apo9BmZHvwWsX = DyVGS3dX0ZxR.findall('(.*?) الحلقة \d+',title,DyVGS3dX0ZxR.DOTALL)
			if yTz8SOkAhu24j6apo9BmZHvwWsX:
				title = '_MOD_' + yTz8SOkAhu24j6apo9BmZHvwWsX[0]
				if title not in ORMkTYjJ1p7:
					CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,203,uIGD4vZcP61QNmw78LXqoEpH)
					ORMkTYjJ1p7.append(title)
		elif '/pack/' in vn1grP3y4It9GmVuBbLJfz2A:
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A+'/films',201,uIGD4vZcP61QNmw78LXqoEpH)
		else: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,203,uIGD4vZcP61QNmw78LXqoEpH)
	if type in [HQmDERMFjx,'mainpage']:
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('class="pagination(.*?)</div>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
			MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
			items = DyVGS3dX0ZxR.findall('href=["\'](http.*?)["\'].*?>(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
			for vn1grP3y4It9GmVuBbLJfz2A,title in items:
				vn1grP3y4It9GmVuBbLJfz2A = SVsiEWeRf6oIynqQx8pCrM4Tk(vn1grP3y4It9GmVuBbLJfz2A)
				title = SVsiEWeRf6oIynqQx8pCrM4Tk(title)
				title = title.replace('الصفحة ',HQmDERMFjx)
				if 'search?s=' in url:
					sukRy4lfgUo8tGQDA = vn1grP3y4It9GmVuBbLJfz2A.split('page=')[1]
					GGteSaHkpXnRir = url.split('page=')[1]
					vn1grP3y4It9GmVuBbLJfz2A = url.replace('page='+GGteSaHkpXnRir,'page='+sukRy4lfgUo8tGQDA)
				if title!=HQmDERMFjx: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'صفحة '+title,vn1grP3y4It9GmVuBbLJfz2A,201)
	return
def XONC9osGSP4fW5HVrhM(url):
	xctI9sq8HVk4p5ga20LriEouYe3JfX,items,nK0kT8JCEQmXsGB3H = -1,[],[]
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,headers,True,HQmDERMFjx,'ARBLIONZ-EPISODES-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content.encode(Zex6D4tJE52r)
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('ti-list-numbered(.*?)</div>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		nK0kT8JCEQmXsGB3H = []
		bUzHWnGg5t1 = HQmDERMFjx.join(Ut7reR0XioMjOdYWZKsLIuc3TQJmC1)
		items = DyVGS3dX0ZxR.findall('href="(.*?)"',bUzHWnGg5t1,DyVGS3dX0ZxR.DOTALL)
	items.append(url)
	items = set(items)
	for vn1grP3y4It9GmVuBbLJfz2A in items:
		vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A.strip(xufJqQcGnhboiVy2wd)
		title = '_MOD_' + vn1grP3y4It9GmVuBbLJfz2A.split(xufJqQcGnhboiVy2wd)[-1].replace('-',oQpxmKiRPlHeGsLXNrJF78O)
		mR2QPcrA3wqT5lONxtunW9J0bj8 = DyVGS3dX0ZxR.findall('الحلقة-(\d+)',vn1grP3y4It9GmVuBbLJfz2A.split(xufJqQcGnhboiVy2wd)[-1],DyVGS3dX0ZxR.DOTALL)
		if mR2QPcrA3wqT5lONxtunW9J0bj8: mR2QPcrA3wqT5lONxtunW9J0bj8 = mR2QPcrA3wqT5lONxtunW9J0bj8[0]
		else: mR2QPcrA3wqT5lONxtunW9J0bj8 = '0'
		nK0kT8JCEQmXsGB3H.append([vn1grP3y4It9GmVuBbLJfz2A,title,mR2QPcrA3wqT5lONxtunW9J0bj8])
	items = sorted(nK0kT8JCEQmXsGB3H, reverse=False, key=lambda key: int(key[2]))
	qyn9gakL5SZj = str(items).count('/season/')
	xctI9sq8HVk4p5ga20LriEouYe3JfX = str(items).count('/episode/')
	if qyn9gakL5SZj>1 and xctI9sq8HVk4p5ga20LriEouYe3JfX>0 and '/season/' not in url:
		for vn1grP3y4It9GmVuBbLJfz2A,title,mR2QPcrA3wqT5lONxtunW9J0bj8 in items:
			if '/season/' in vn1grP3y4It9GmVuBbLJfz2A:
				CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,203)
	else:
		for vn1grP3y4It9GmVuBbLJfz2A,title,mR2QPcrA3wqT5lONxtunW9J0bj8 in items:
			if '/season/' not in vn1grP3y4It9GmVuBbLJfz2A:
				title = xx9LK4VzpF6IHXSEyhmrQwbg25P0(title)
				CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,202)
	return
def f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url):
	Na8vklCpUGYIzP0bjutWOT = []
	DDAoB3rdfJTXuE2RQwK8 = url.split(xufJqQcGnhboiVy2wd)
	JlNSetqQCM9ZX = e2VR8nohduY
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(H5x4Z2qPwR8vXM,'GET',url,HQmDERMFjx,headers,True,True,'ARBLIONZ-PLAY-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content.encode(Zex6D4tJE52r)
	id = DyVGS3dX0ZxR.findall('postId:"(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if not id: id = DyVGS3dX0ZxR.findall('post_id=(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if not id: id = DyVGS3dX0ZxR.findall('post-id="(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if id: id = id[0]
	if '/watch/' in CzNPJydxQLfw27tv4ZF8KORAbX5:
		SSHjMN4uegZfb2 = url.replace(DDAoB3rdfJTXuE2RQwK8[3],'watch')
		vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(H5x4Z2qPwR8vXM,'GET',SSHjMN4uegZfb2,HQmDERMFjx,headers,True,True,'ARBLIONZ-PLAY-2nd')
		b3L20nx7qwHKTS6so = vGXnw9VcUN.content.encode(Zex6D4tJE52r)
		fVUt6k9dmSlo58OjK0uGNJMDqTQZHc = DyVGS3dX0ZxR.findall('data-embedd="(.*?)".*?alt="(.*?)"',b3L20nx7qwHKTS6so,DyVGS3dX0ZxR.DOTALL)
		bbiKcPz2RQOUwS = DyVGS3dX0ZxR.findall('data-embedd=".*?(http.*?)("|&quot;)',b3L20nx7qwHKTS6so,DyVGS3dX0ZxR.DOTALL)
		SmuFoKL4Gr8IYAXaty = DyVGS3dX0ZxR.findall('src=&quot;(.*?)&quot;.*?>(.*?)<',b3L20nx7qwHKTS6so,DyVGS3dX0ZxR.DOTALL|DyVGS3dX0ZxR.IGNORECASE)
		wwVJ1rtjsEH3QdAeMX54q = DyVGS3dX0ZxR.findall('data-embedd="(.*?)">\n*.*?server_image">\n(.*?)\n',b3L20nx7qwHKTS6so)
		LR5OIDdYb0v4CU3HVype = DyVGS3dX0ZxR.findall('src=&quot;(.*?)&quot;.*?alt="(.*?)"',b3L20nx7qwHKTS6so,DyVGS3dX0ZxR.DOTALL|DyVGS3dX0ZxR.IGNORECASE)
		JgMmtGN0YQbnTUhlL3dP = DyVGS3dX0ZxR.findall('server="(.*?)".*?<span>(.*?)<',b3L20nx7qwHKTS6so,DyVGS3dX0ZxR.DOTALL|DyVGS3dX0ZxR.IGNORECASE)
		items = fVUt6k9dmSlo58OjK0uGNJMDqTQZHc+bbiKcPz2RQOUwS+SmuFoKL4Gr8IYAXaty+wwVJ1rtjsEH3QdAeMX54q+LR5OIDdYb0v4CU3HVype+JgMmtGN0YQbnTUhlL3dP
		if not items:
			items = DyVGS3dX0ZxR.findall('<span>(.*?)</span>.*?src="(.*?)"',b3L20nx7qwHKTS6so,DyVGS3dX0ZxR.DOTALL|DyVGS3dX0ZxR.IGNORECASE)
			items = [(C0IXhz64tBceyNobpYxZ3j,HHEviNyY0ldhs) for HHEviNyY0ldhs,C0IXhz64tBceyNobpYxZ3j in items]
		for pYVvlGR1ES0gdtzayiDqb9w,title in items:
			if '.png' in pYVvlGR1ES0gdtzayiDqb9w: continue
			if '.jpg' in pYVvlGR1ES0gdtzayiDqb9w: continue
			if '&quot;' in pYVvlGR1ES0gdtzayiDqb9w: continue
			RRpfksr1PbZagwCIOJXYNHTo = DyVGS3dX0ZxR.findall('\d\d\d+',title,DyVGS3dX0ZxR.DOTALL)
			if RRpfksr1PbZagwCIOJXYNHTo:
				RRpfksr1PbZagwCIOJXYNHTo = RRpfksr1PbZagwCIOJXYNHTo[0]
				if RRpfksr1PbZagwCIOJXYNHTo in title: title = title.replace(RRpfksr1PbZagwCIOJXYNHTo+'p',HQmDERMFjx).replace(RRpfksr1PbZagwCIOJXYNHTo,HQmDERMFjx).strip(oQpxmKiRPlHeGsLXNrJF78O)
				RRpfksr1PbZagwCIOJXYNHTo = '____'+RRpfksr1PbZagwCIOJXYNHTo
			else: RRpfksr1PbZagwCIOJXYNHTo = HQmDERMFjx
			if pYVvlGR1ES0gdtzayiDqb9w.isdigit():
				vn1grP3y4It9GmVuBbLJfz2A = JlNSetqQCM9ZX+'/?postid='+id+'&serverid='+pYVvlGR1ES0gdtzayiDqb9w+'?named='+title+'__watch'+RRpfksr1PbZagwCIOJXYNHTo
			else:
				if 'http' not in pYVvlGR1ES0gdtzayiDqb9w: pYVvlGR1ES0gdtzayiDqb9w = 'http:'+pYVvlGR1ES0gdtzayiDqb9w
				RRpfksr1PbZagwCIOJXYNHTo = DyVGS3dX0ZxR.findall('\d\d\d+',title,DyVGS3dX0ZxR.DOTALL)
				if RRpfksr1PbZagwCIOJXYNHTo: RRpfksr1PbZagwCIOJXYNHTo = '____'+RRpfksr1PbZagwCIOJXYNHTo[0]
				else: RRpfksr1PbZagwCIOJXYNHTo = HQmDERMFjx
				vn1grP3y4It9GmVuBbLJfz2A = pYVvlGR1ES0gdtzayiDqb9w+'?named=__watch'+RRpfksr1PbZagwCIOJXYNHTo
			Na8vklCpUGYIzP0bjutWOT.append(vn1grP3y4It9GmVuBbLJfz2A)
	if 'DownloadNow' in CzNPJydxQLfw27tv4ZF8KORAbX5:
		nJayb3s5zlOgQh9BwiCdEDq = { 'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8' }
		SSHjMN4uegZfb2 = url+'/download'
		vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(H5x4Z2qPwR8vXM,'GET',SSHjMN4uegZfb2,HQmDERMFjx,nJayb3s5zlOgQh9BwiCdEDq,True,HQmDERMFjx,'ARBLIONZ-PLAY-3rd')
		b3L20nx7qwHKTS6so = vGXnw9VcUN.content.encode(Zex6D4tJE52r)
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('<ul class="download-items(.*?)</ul>',b3L20nx7qwHKTS6so,DyVGS3dX0ZxR.DOTALL)
		for MJ2gSPyTl9hzoi1 in Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
			items = DyVGS3dX0ZxR.findall('href="(http.*?)".*?<span>(.*?)<.*?<p>(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
			for vn1grP3y4It9GmVuBbLJfz2A,name,RRpfksr1PbZagwCIOJXYNHTo in items:
				vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A+'?named='+name+'__download'+'____'+RRpfksr1PbZagwCIOJXYNHTo
				Na8vklCpUGYIzP0bjutWOT.append(vn1grP3y4It9GmVuBbLJfz2A)
	elif '/download/' in CzNPJydxQLfw27tv4ZF8KORAbX5:
		nJayb3s5zlOgQh9BwiCdEDq = { 'User-Agent':HQmDERMFjx , 'X-Requested-With':'XMLHttpRequest' }
		SSHjMN4uegZfb2 = JlNSetqQCM9ZX + '/ajaxCenter?_action=getdownloadlinks&postId='+id
		vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(H5x4Z2qPwR8vXM,'GET',SSHjMN4uegZfb2,HQmDERMFjx,nJayb3s5zlOgQh9BwiCdEDq,True,True,'ARBLIONZ-PLAY-4th')
		b3L20nx7qwHKTS6so = vGXnw9VcUN.content.encode(Zex6D4tJE52r)
		if 'download-btns' in b3L20nx7qwHKTS6so:
			SmuFoKL4Gr8IYAXaty = DyVGS3dX0ZxR.findall('href="(.*?)"',b3L20nx7qwHKTS6so,DyVGS3dX0ZxR.DOTALL)
			for jDcWv7MAkEV in SmuFoKL4Gr8IYAXaty:
				if '/page/' not in jDcWv7MAkEV and 'http' in jDcWv7MAkEV:
					jDcWv7MAkEV = jDcWv7MAkEV+'?named=__download'
					Na8vklCpUGYIzP0bjutWOT.append(jDcWv7MAkEV)
				elif '/page/' in jDcWv7MAkEV:
					RRpfksr1PbZagwCIOJXYNHTo = HQmDERMFjx
					vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(H5x4Z2qPwR8vXM,'GET',jDcWv7MAkEV,HQmDERMFjx,headers,True,True,'ARBLIONZ-PLAY-5th')
					uB5P4yV7DQjq2MwmUgTXd6s = vGXnw9VcUN.content.encode(Zex6D4tJE52r)
					bUzHWnGg5t1 = DyVGS3dX0ZxR.findall('(<strong>.*?)-----',uB5P4yV7DQjq2MwmUgTXd6s,DyVGS3dX0ZxR.DOTALL)
					for eOSKwVIzRCtYuDaBHZ5vnXjpG6 in bUzHWnGg5t1:
						I2m4vTcHNLPzAtgXlhu8VUwSWY1 = HQmDERMFjx
						wwVJ1rtjsEH3QdAeMX54q = DyVGS3dX0ZxR.findall('<strong>(.*?)</strong>',eOSKwVIzRCtYuDaBHZ5vnXjpG6,DyVGS3dX0ZxR.DOTALL)
						for GpY7Xd0ra3kNoDSfbET in wwVJ1rtjsEH3QdAeMX54q:
							A07BpVeRJToLb = DyVGS3dX0ZxR.findall('\d\d\d+',GpY7Xd0ra3kNoDSfbET,DyVGS3dX0ZxR.DOTALL)
							if A07BpVeRJToLb:
								RRpfksr1PbZagwCIOJXYNHTo = '____'+A07BpVeRJToLb[0]
								break
						for GpY7Xd0ra3kNoDSfbET in reversed(wwVJ1rtjsEH3QdAeMX54q):
							A07BpVeRJToLb = DyVGS3dX0ZxR.findall('\w\w+',GpY7Xd0ra3kNoDSfbET,DyVGS3dX0ZxR.DOTALL)
							if A07BpVeRJToLb:
								I2m4vTcHNLPzAtgXlhu8VUwSWY1 = A07BpVeRJToLb[0]
								break
						LR5OIDdYb0v4CU3HVype = DyVGS3dX0ZxR.findall('href="(.*?)"',eOSKwVIzRCtYuDaBHZ5vnXjpG6,DyVGS3dX0ZxR.DOTALL)
						for VelFvp1irjL9uDAk6UxKON7T3bh0Y in LR5OIDdYb0v4CU3HVype:
							VelFvp1irjL9uDAk6UxKON7T3bh0Y = VelFvp1irjL9uDAk6UxKON7T3bh0Y+'?named='+I2m4vTcHNLPzAtgXlhu8VUwSWY1+'__download'+RRpfksr1PbZagwCIOJXYNHTo
							Na8vklCpUGYIzP0bjutWOT.append(VelFvp1irjL9uDAk6UxKON7T3bh0Y)
		elif 'slow-motion' in b3L20nx7qwHKTS6so:
			b3L20nx7qwHKTS6so = b3L20nx7qwHKTS6so.replace('<h6 ','==END== ==START==')+'==END=='
			b3L20nx7qwHKTS6so = b3L20nx7qwHKTS6so.replace('<h3 ','==END== ==START==')+'==END=='
			t5QufF1AaGMY = DyVGS3dX0ZxR.findall('==START==(.*?)==END==',b3L20nx7qwHKTS6so,DyVGS3dX0ZxR.DOTALL)
			if t5QufF1AaGMY:
				for eOSKwVIzRCtYuDaBHZ5vnXjpG6 in t5QufF1AaGMY:
					if 'href=' not in eOSKwVIzRCtYuDaBHZ5vnXjpG6: continue
					Qz6Y8hNycuTPiKmsL = HQmDERMFjx
					wwVJ1rtjsEH3QdAeMX54q = DyVGS3dX0ZxR.findall('slow-motion">(.*?)<',eOSKwVIzRCtYuDaBHZ5vnXjpG6,DyVGS3dX0ZxR.DOTALL)
					for GpY7Xd0ra3kNoDSfbET in wwVJ1rtjsEH3QdAeMX54q:
						A07BpVeRJToLb = DyVGS3dX0ZxR.findall('\d\d\d+',GpY7Xd0ra3kNoDSfbET,DyVGS3dX0ZxR.DOTALL)
						if A07BpVeRJToLb:
							Qz6Y8hNycuTPiKmsL = '____'+A07BpVeRJToLb[0]
							break
					wwVJ1rtjsEH3QdAeMX54q = DyVGS3dX0ZxR.findall('<td>(.*?)</td>.*?href="(http.*?)"',eOSKwVIzRCtYuDaBHZ5vnXjpG6,DyVGS3dX0ZxR.DOTALL)
					if wwVJ1rtjsEH3QdAeMX54q:
						for I2m4vTcHNLPzAtgXlhu8VUwSWY1,tQcGSvVknx7o0NJlKIEp5YfgA8R in wwVJ1rtjsEH3QdAeMX54q:
							tQcGSvVknx7o0NJlKIEp5YfgA8R = tQcGSvVknx7o0NJlKIEp5YfgA8R+'?named='+I2m4vTcHNLPzAtgXlhu8VUwSWY1+'__download'+Qz6Y8hNycuTPiKmsL
							Na8vklCpUGYIzP0bjutWOT.append(tQcGSvVknx7o0NJlKIEp5YfgA8R)
					else:
						wwVJ1rtjsEH3QdAeMX54q = DyVGS3dX0ZxR.findall('href="(.*?http.*?)".*?name">(.*?)<',eOSKwVIzRCtYuDaBHZ5vnXjpG6,DyVGS3dX0ZxR.DOTALL)
						for tQcGSvVknx7o0NJlKIEp5YfgA8R,I2m4vTcHNLPzAtgXlhu8VUwSWY1 in wwVJ1rtjsEH3QdAeMX54q:
							tQcGSvVknx7o0NJlKIEp5YfgA8R = tQcGSvVknx7o0NJlKIEp5YfgA8R.strip(oQpxmKiRPlHeGsLXNrJF78O)+'?named='+I2m4vTcHNLPzAtgXlhu8VUwSWY1+'__download'+Qz6Y8hNycuTPiKmsL
							Na8vklCpUGYIzP0bjutWOT.append(tQcGSvVknx7o0NJlKIEp5YfgA8R)
			else:
				wwVJ1rtjsEH3QdAeMX54q = DyVGS3dX0ZxR.findall('href="(.*?)".*?>(\w+)<',b3L20nx7qwHKTS6so,DyVGS3dX0ZxR.DOTALL)
				for tQcGSvVknx7o0NJlKIEp5YfgA8R,I2m4vTcHNLPzAtgXlhu8VUwSWY1 in wwVJ1rtjsEH3QdAeMX54q:
					tQcGSvVknx7o0NJlKIEp5YfgA8R = tQcGSvVknx7o0NJlKIEp5YfgA8R.strip(oQpxmKiRPlHeGsLXNrJF78O)+'?named='+I2m4vTcHNLPzAtgXlhu8VUwSWY1+'__download'
					Na8vklCpUGYIzP0bjutWOT.append(tQcGSvVknx7o0NJlKIEp5YfgA8R)
	import NsD5AomUqH
	NsD5AomUqH.NZcWGBmgFEen5hvJjUSIzOCVk7(Na8vklCpUGYIzP0bjutWOT,HDLtdMAy7wPkl8aKC3O2,'video',url)
	return
def hm4kawIPKp3oMrC75dJZA9HS2(search):
	search,GXVabd4sc2u3zp0JI,showDialogs = x0pzMENwy84tBcZvXr(search)
	if search==HQmDERMFjx: search = q156m84QoYrn()
	if search==HQmDERMFjx: return
	search = search.replace(oQpxmKiRPlHeGsLXNrJF78O,'+')
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(H5x4Z2qPwR8vXM,'GET',e2VR8nohduY+'/alz',HQmDERMFjx,headers,True,HQmDERMFjx,'ARBLIONZ-SEARCH-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content.encode(Zex6D4tJE52r)
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('chevron-select(.*?)</div>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if showDialogs and Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('value="(.*?)".*?>(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		IH6WtApDFSkcQ2TE,dr0NHB5IWYFE3vtC1Qg7fP9U4RyjV = [],[]
		for WF2vkePC5gbXAGUarcqlpmB3Q,title in items:
			IH6WtApDFSkcQ2TE.append(WF2vkePC5gbXAGUarcqlpmB3Q)
			dr0NHB5IWYFE3vtC1Qg7fP9U4RyjV.append(title)
		lwT9cdaH5AxMU8IpZif20jPX = GGiSlWbqKDr5Ovkh2L7sHNTxz('اختر الفلتر المناسب:', dr0NHB5IWYFE3vtC1Qg7fP9U4RyjV)
		if lwT9cdaH5AxMU8IpZif20jPX == -1 : return
		WF2vkePC5gbXAGUarcqlpmB3Q = IH6WtApDFSkcQ2TE[lwT9cdaH5AxMU8IpZif20jPX]
	else: WF2vkePC5gbXAGUarcqlpmB3Q = HQmDERMFjx
	url = e2VR8nohduY + '/search?s='+search+'&category='+WF2vkePC5gbXAGUarcqlpmB3Q+'&page=1'
	c8wfGju4CWZm(url)
	return
def ooxUXkcTj5PF4ad2SwYy(url,filter):
	rrdHuNZaRCOviqPmS4szhD0VcEjM3 = ['category','release-year','genre','Quality']
	if '?' in url: url = url.split('/getposts?')[0]
	type,filter = filter.split('___',1)
	if filter==HQmDERMFjx: eA0pnTuMvxrdmoRC9zPBh,mwhEr8eXxD21MAKfHUSlB = HQmDERMFjx,HQmDERMFjx
	else: eA0pnTuMvxrdmoRC9zPBh,mwhEr8eXxD21MAKfHUSlB = filter.split('___')
	if type=='CATEGORIES':
		if rrdHuNZaRCOviqPmS4szhD0VcEjM3[0]+'=' not in eA0pnTuMvxrdmoRC9zPBh: WF2vkePC5gbXAGUarcqlpmB3Q = rrdHuNZaRCOviqPmS4szhD0VcEjM3[0]
		for yuYts1RONXgp in range(len(rrdHuNZaRCOviqPmS4szhD0VcEjM3[0:-1])):
			if rrdHuNZaRCOviqPmS4szhD0VcEjM3[yuYts1RONXgp]+'=' in eA0pnTuMvxrdmoRC9zPBh: WF2vkePC5gbXAGUarcqlpmB3Q = rrdHuNZaRCOviqPmS4szhD0VcEjM3[yuYts1RONXgp+1]
		Cm5jWJgr28TlUnoZYHAxdPI3OB = eA0pnTuMvxrdmoRC9zPBh+'&'+WF2vkePC5gbXAGUarcqlpmB3Q+'=0'
		RRDtwVh6LbFiEycHNQkId5Cefmq = mwhEr8eXxD21MAKfHUSlB+'&'+WF2vkePC5gbXAGUarcqlpmB3Q+'=0'
		GSPtdslyxQURmB5obg69VJMY1jE = Cm5jWJgr28TlUnoZYHAxdPI3OB.strip('&')+'___'+RRDtwVh6LbFiEycHNQkId5Cefmq.strip('&')
		J4asIxU7Zyq5PiN2rKEctegFV = jlZtWwMfosJFIKenicqU1(mwhEr8eXxD21MAKfHUSlB,'modified_filters')
		SSHjMN4uegZfb2 = url+'/getposts?'+J4asIxU7Zyq5PiN2rKEctegFV
	elif type=='FILTERS':
		v2s9V6uhIT0aCjkPOl7iUqZxB = jlZtWwMfosJFIKenicqU1(eA0pnTuMvxrdmoRC9zPBh,'modified_values')
		v2s9V6uhIT0aCjkPOl7iUqZxB = xx9LK4VzpF6IHXSEyhmrQwbg25P0(v2s9V6uhIT0aCjkPOl7iUqZxB)
		if mwhEr8eXxD21MAKfHUSlB!=HQmDERMFjx: mwhEr8eXxD21MAKfHUSlB = jlZtWwMfosJFIKenicqU1(mwhEr8eXxD21MAKfHUSlB,'modified_filters')
		if mwhEr8eXxD21MAKfHUSlB==HQmDERMFjx: SSHjMN4uegZfb2 = url
		else: SSHjMN4uegZfb2 = url+'/getposts?'+mwhEr8eXxD21MAKfHUSlB
		CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'أظهار قائمة الفيديو التي تم اختيارها ',SSHjMN4uegZfb2,201)
		CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+' [[   '+v2s9V6uhIT0aCjkPOl7iUqZxB+'   ]]',SSHjMN4uegZfb2,201)
		CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	CzNPJydxQLfw27tv4ZF8KORAbX5 = D0GFPwY8ecAVI(H5x4Z2qPwR8vXM,url+'/alz',HQmDERMFjx,headers,HQmDERMFjx,'ARBLIONZ-FILTERS_MENU-1st')
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('AjaxFilteringData(.*?)FilterWord',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	jnPZuGqg9F5viBUp = DyVGS3dX0ZxR.findall('</i>(.*?)<.*?data-forTax="(.*?)"(.*?)<h2',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	dict = {}
	for name,DcpbqKxWsJRCSVkQyjf1,MJ2gSPyTl9hzoi1 in jnPZuGqg9F5viBUp:
		name = name.replace('اختيار ',HQmDERMFjx)
		name = name.replace('سنة الإنتاج','السنة')
		items = DyVGS3dX0ZxR.findall('value="(.*?)".*?</div>(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		if '=' not in SSHjMN4uegZfb2: SSHjMN4uegZfb2 = url
		if type=='CATEGORIES':
			if WF2vkePC5gbXAGUarcqlpmB3Q!=DcpbqKxWsJRCSVkQyjf1: continue
			elif len(items)<=1:
				if DcpbqKxWsJRCSVkQyjf1==rrdHuNZaRCOviqPmS4szhD0VcEjM3[-1]: c8wfGju4CWZm(SSHjMN4uegZfb2)
				else: ooxUXkcTj5PF4ad2SwYy(SSHjMN4uegZfb2,'CATEGORIES___'+GSPtdslyxQURmB5obg69VJMY1jE)
				return
			else:
				if DcpbqKxWsJRCSVkQyjf1==rrdHuNZaRCOviqPmS4szhD0VcEjM3[-1]: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'الجميع ',SSHjMN4uegZfb2,201)
				else: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'الجميع ',SSHjMN4uegZfb2,205,HQmDERMFjx,HQmDERMFjx,GSPtdslyxQURmB5obg69VJMY1jE)
		elif type=='FILTERS':
			Cm5jWJgr28TlUnoZYHAxdPI3OB = eA0pnTuMvxrdmoRC9zPBh+'&'+DcpbqKxWsJRCSVkQyjf1+'=0'
			RRDtwVh6LbFiEycHNQkId5Cefmq = mwhEr8eXxD21MAKfHUSlB+'&'+DcpbqKxWsJRCSVkQyjf1+'=0'
			GSPtdslyxQURmB5obg69VJMY1jE = Cm5jWJgr28TlUnoZYHAxdPI3OB+'___'+RRDtwVh6LbFiEycHNQkId5Cefmq
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'الجميع :'+name,SSHjMN4uegZfb2,204,HQmDERMFjx,HQmDERMFjx,GSPtdslyxQURmB5obg69VJMY1jE)
		dict[DcpbqKxWsJRCSVkQyjf1] = {}
		for value,yewoKb5dkfHu1xEZMAsY in items:
			yewoKb5dkfHu1xEZMAsY = yewoKb5dkfHu1xEZMAsY.replace(ti3SbXNV0aJ7n5Grc4OQY8Ll1s9,HQmDERMFjx)
			if yewoKb5dkfHu1xEZMAsY in FwhZ0nXtpoHTMarf: continue
			dict[DcpbqKxWsJRCSVkQyjf1][value] = yewoKb5dkfHu1xEZMAsY
			Cm5jWJgr28TlUnoZYHAxdPI3OB = eA0pnTuMvxrdmoRC9zPBh+'&'+DcpbqKxWsJRCSVkQyjf1+'='+yewoKb5dkfHu1xEZMAsY
			RRDtwVh6LbFiEycHNQkId5Cefmq = mwhEr8eXxD21MAKfHUSlB+'&'+DcpbqKxWsJRCSVkQyjf1+'='+value
			CEniUGWr4jMy = Cm5jWJgr28TlUnoZYHAxdPI3OB+'___'+RRDtwVh6LbFiEycHNQkId5Cefmq
			title = yewoKb5dkfHu1xEZMAsY+' :'#+dict[DcpbqKxWsJRCSVkQyjf1]['0']
			title = yewoKb5dkfHu1xEZMAsY+' :'+name
			if type=='FILTERS': CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,url,204,HQmDERMFjx,HQmDERMFjx,CEniUGWr4jMy)
			elif type=='CATEGORIES' and rrdHuNZaRCOviqPmS4szhD0VcEjM3[-2]+'=' in eA0pnTuMvxrdmoRC9zPBh:
				J4asIxU7Zyq5PiN2rKEctegFV = jlZtWwMfosJFIKenicqU1(RRDtwVh6LbFiEycHNQkId5Cefmq,'modified_filters')
				jDcWv7MAkEV = url+'/getposts?'+J4asIxU7Zyq5PiN2rKEctegFV
				CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,jDcWv7MAkEV,201)
			else: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,url,205,HQmDERMFjx,HQmDERMFjx,CEniUGWr4jMy)
	return
def jlZtWwMfosJFIKenicqU1(Eya9L4IY3GxqtNoVWegDcPuOR,mode):
	Eya9L4IY3GxqtNoVWegDcPuOR = Eya9L4IY3GxqtNoVWegDcPuOR.replace('=&','=0&')
	Eya9L4IY3GxqtNoVWegDcPuOR = Eya9L4IY3GxqtNoVWegDcPuOR.strip('&')
	AAwtDoF34Y890RXse = {}
	if '=' in Eya9L4IY3GxqtNoVWegDcPuOR:
		items = Eya9L4IY3GxqtNoVWegDcPuOR.split('&')
		for A07BpVeRJToLb in items:
			airVhHdqCb6Gf49eERSjv1,value = A07BpVeRJToLb.split('=')
			AAwtDoF34Y890RXse[airVhHdqCb6Gf49eERSjv1] = value
	n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6 = HQmDERMFjx
	xSMWIOb5tFvh = ['category','release-year','genre','Quality']
	for key in xSMWIOb5tFvh:
		if key in list(AAwtDoF34Y890RXse.keys()): value = AAwtDoF34Y890RXse[key]
		else: value = '0'
		if '%' not in value: value = VVkOtyQLzxBr(value)
		if mode=='modified_values' and value!='0': n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6 = n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6+' + '+value
		elif mode=='modified_filters' and value!='0': n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6 = n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6+'&'+key+'='+value
		elif mode=='all': n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6 = n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6+'&'+key+'='+value
	n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6 = n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6.strip(' + ')
	n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6 = n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6.strip('&')
	n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6 = n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6.replace('=0','=')
	n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6 = n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6.replace('Quality','quality')
	return n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6
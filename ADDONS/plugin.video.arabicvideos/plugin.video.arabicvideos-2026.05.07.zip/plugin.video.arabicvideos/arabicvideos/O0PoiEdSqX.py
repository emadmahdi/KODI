# -*- coding: utf-8 -*-
from FF68kA5BUy import *
HDLtdMAy7wPkl8aKC3O2 = 'IFILM'
EEJvXQzSZNt = '_IFL_'
e2VR8nohduY = Jzthpc2nj5.SITESURLS[HDLtdMAy7wPkl8aKC3O2][0]
waE5LXVN0BOiQjCUur3oTt6eYSIHJK = Jzthpc2nj5.SITESURLS[HDLtdMAy7wPkl8aKC3O2][1]
IsK7MxWgSEa9JkHQntoh = Jzthpc2nj5.SITESURLS[HDLtdMAy7wPkl8aKC3O2][2]
DCjTaEdrxubcWABgoL = Jzthpc2nj5.SITESURLS[HDLtdMAy7wPkl8aKC3O2][3]
def kk6X5LxpsND(mode,url,zmL397efNlks5uTEV,text):
	if   mode==20: zLZUkrP7ac5 = idGSgeotIlfD()
	elif mode==21: zLZUkrP7ac5 = afkxo7FyZWB4O6K1eXrs5I(url)
	elif mode==22: zLZUkrP7ac5 = c8wfGju4CWZm(url,zmL397efNlks5uTEV)
	elif mode==23: zLZUkrP7ac5 = XONC9osGSP4fW5HVrhM(url,zmL397efNlks5uTEV)
	elif mode==24: zLZUkrP7ac5 = f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url,text)
	elif mode==25: zLZUkrP7ac5 = kxW3wzMmigh8l1pJ4IYHFUnTOt(url)
	elif mode==27: zLZUkrP7ac5 = eY4DutR9cHF(url)
	elif mode==28: zLZUkrP7ac5 = kSrhPWAGmsBvHTKtozgc9jLnUD6()
	elif mode==29: zLZUkrP7ac5 = hm4kawIPKp3oMrC75dJZA9HS2(text)
	else: zLZUkrP7ac5 = False
	return zLZUkrP7ac5
def idGSgeotIlfD():
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'عربي',e2VR8nohduY,21,HQmDERMFjx,'101')
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'English',waE5LXVN0BOiQjCUur3oTt6eYSIHJK,21,HQmDERMFjx,'101')
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'فارسى',IsK7MxWgSEa9JkHQntoh,21,HQmDERMFjx,'101')
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'فارسى 2',DCjTaEdrxubcWABgoL,21,HQmDERMFjx,'101')
	return
def kSrhPWAGmsBvHTKtozgc9jLnUD6():
	CfgK4s13Q0hZcHyleT2bVJO9('live',EEJvXQzSZNt+'عربي',e2VR8nohduY,27)
	CfgK4s13Q0hZcHyleT2bVJO9('live',EEJvXQzSZNt+'English',waE5LXVN0BOiQjCUur3oTt6eYSIHJK,27)
	CfgK4s13Q0hZcHyleT2bVJO9('live',EEJvXQzSZNt+'فارسى',IsK7MxWgSEa9JkHQntoh,27)
	CfgK4s13Q0hZcHyleT2bVJO9('live',EEJvXQzSZNt+'فارسى 2',DCjTaEdrxubcWABgoL,27)
	return
def afkxo7FyZWB4O6K1eXrs5I(ei1Udas8znN5blIGC4qx2HwgQ):
	HDLtdMAy7wPkl8aKC3O2 = ei1Udas8znN5blIGC4qx2HwgQ
	if ei1Udas8znN5blIGC4qx2HwgQ=='IFILM-ARABIC': ei1Udas8znN5blIGC4qx2HwgQ = e2VR8nohduY
	elif ei1Udas8znN5blIGC4qx2HwgQ=='IFILM-ENGLISH': ei1Udas8znN5blIGC4qx2HwgQ = waE5LXVN0BOiQjCUur3oTt6eYSIHJK
	else: HDLtdMAy7wPkl8aKC3O2 = HQmDERMFjx
	ooJVyEN7CjtcOgGSeaRA = NCZ7jowcBuMW8PUL6Idhvx(ei1Udas8znN5blIGC4qx2HwgQ)
	if ooJVyEN7CjtcOgGSeaRA=='ar' or HDLtdMAy7wPkl8aKC3O2=='IFILM-ARABIC':
		H5PO4cLeuDvwbiI1rFZEsQUj = 'بحث في الموقع'
		SLTf7GeYAM = 'مسلسلات - حالية'
		hQGaZWkesbXDYn7Altz2oudM = 'مسلسلات - أحدث'
		ZlyH0jVYBJNe2PIvCzLEK3T = 'مسلسلات - أبجدي'
		EiWhVk1u6J8eIzMs7cv9qS = 'بث حي آي فيلم'
		QFv4q3RmsZkpBlW1rK6eHJg2dw5NL = 'أفلام'
		uDkV1iYnTFrK8 = 'موسيقى'
		xA9TBLU83bkuC0oSi = 'برامج'
	elif ooJVyEN7CjtcOgGSeaRA=='en' or HDLtdMAy7wPkl8aKC3O2=='IFILM-ENGLISH':
		H5PO4cLeuDvwbiI1rFZEsQUj = 'Search in site'
		SLTf7GeYAM = 'Series - Current'
		hQGaZWkesbXDYn7Altz2oudM = 'Series - Latest'
		ZlyH0jVYBJNe2PIvCzLEK3T = 'Series - Alphabet'
		EiWhVk1u6J8eIzMs7cv9qS = 'Live iFilm channel'
		QFv4q3RmsZkpBlW1rK6eHJg2dw5NL = 'Movies'
		uDkV1iYnTFrK8 = 'Music'
		xA9TBLU83bkuC0oSi = 'Shows'
	elif ooJVyEN7CjtcOgGSeaRA in ['fa','fa2']:
		H5PO4cLeuDvwbiI1rFZEsQUj = 'جستجو در سایت'
		SLTf7GeYAM = 'سريال - جاری'
		hQGaZWkesbXDYn7Altz2oudM = 'سريال - آخرین'
		ZlyH0jVYBJNe2PIvCzLEK3T = 'سريال - الفبا'
		EiWhVk1u6J8eIzMs7cv9qS = 'پخش زنده اي فيلم'
		QFv4q3RmsZkpBlW1rK6eHJg2dw5NL = 'فيلم'
		uDkV1iYnTFrK8 = 'موسيقى'
		xA9TBLU83bkuC0oSi = 'برنامه ها'
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+H5PO4cLeuDvwbiI1rFZEsQUj,ei1Udas8znN5blIGC4qx2HwgQ,29,HQmDERMFjx,HQmDERMFjx,'_REMEMBERRESULTS_')
	CfgK4s13Q0hZcHyleT2bVJO9('live',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+EiWhVk1u6J8eIzMs7cv9qS,ei1Udas8znN5blIGC4qx2HwgQ,27)
	CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	t7IyszW0jv = ['Series','Program','Music']
	CzNPJydxQLfw27tv4ZF8KORAbX5 = D0GFPwY8ecAVI(H5x4Z2qPwR8vXM,ei1Udas8znN5blIGC4qx2HwgQ+'/home',HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'IFILM-MENU-1st')
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1=DyVGS3dX0ZxR.findall('button-menu(.*?)/Contact',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('href="(.*?)">(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,title in items:
			if any(value in vn1grP3y4It9GmVuBbLJfz2A for value in t7IyszW0jv):
				url = ei1Udas8znN5blIGC4qx2HwgQ+vn1grP3y4It9GmVuBbLJfz2A
				if 'Series' in vn1grP3y4It9GmVuBbLJfz2A:
					CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+SLTf7GeYAM,url,22,HQmDERMFjx,'100')
					CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+hQGaZWkesbXDYn7Altz2oudM,url,22,HQmDERMFjx,'101')
					CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+ZlyH0jVYBJNe2PIvCzLEK3T,url,22,HQmDERMFjx,'201')
				elif 'Film' in vn1grP3y4It9GmVuBbLJfz2A: CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+QFv4q3RmsZkpBlW1rK6eHJg2dw5NL,url,22,HQmDERMFjx,'100')
				elif 'Music' in vn1grP3y4It9GmVuBbLJfz2A: CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+uDkV1iYnTFrK8,url,25,HQmDERMFjx,'101')
				elif 'Program' in vn1grP3y4It9GmVuBbLJfz2A: CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+xA9TBLU83bkuC0oSi,url,22,HQmDERMFjx,'101')
	return CzNPJydxQLfw27tv4ZF8KORAbX5
def kxW3wzMmigh8l1pJ4IYHFUnTOt(url):
	ei1Udas8znN5blIGC4qx2HwgQ = sgbOXABfk8uYQj6ql41(url)
	CzNPJydxQLfw27tv4ZF8KORAbX5 = D0GFPwY8ecAVI(H5x4Z2qPwR8vXM,url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'IFILM-MUSIC_MENU-1st')
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('Music-tools-header(.*?)Music-body',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	title = DyVGS3dX0ZxR.findall('<p>(.*?)</p>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)[0]
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,url,22,HQmDERMFjx,'101')
	items = DyVGS3dX0ZxR.findall('href="(.*?)">(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	for vn1grP3y4It9GmVuBbLJfz2A,title in items:
		vn1grP3y4It9GmVuBbLJfz2A = ei1Udas8znN5blIGC4qx2HwgQ + vn1grP3y4It9GmVuBbLJfz2A
		CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,23,HQmDERMFjx,'101')
	return
def c8wfGju4CWZm(url,zmL397efNlks5uTEV):
	ei1Udas8znN5blIGC4qx2HwgQ = sgbOXABfk8uYQj6ql41(url)
	ooJVyEN7CjtcOgGSeaRA = NCZ7jowcBuMW8PUL6Idhvx(url)
	type = url.split(xufJqQcGnhboiVy2wd)[-1]
	V5lY03jQ2oKCWNhnzBicImgS = str(int(zmL397efNlks5uTEV)//100)
	zmL397efNlks5uTEV = str(int(zmL397efNlks5uTEV)%100)
	if type=='Series' and zmL397efNlks5uTEV=='0':
		CzNPJydxQLfw27tv4ZF8KORAbX5 = D0GFPwY8ecAVI(j9uzmBeEyK8,url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'IFILM-TITLES-1st')
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('serial-body(.*?)class="row',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('href="(.*?)".*?src=(.*?)>.*?h3>(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,uIGD4vZcP61QNmw78LXqoEpH,title in items:
			title = ArwuTXMNsaO9fmjWdI(title)
			title = SVsiEWeRf6oIynqQx8pCrM4Tk(title)
			vn1grP3y4It9GmVuBbLJfz2A = ei1Udas8znN5blIGC4qx2HwgQ + vn1grP3y4It9GmVuBbLJfz2A
			uIGD4vZcP61QNmw78LXqoEpH = ei1Udas8znN5blIGC4qx2HwgQ + VVkOtyQLzxBr(uIGD4vZcP61QNmw78LXqoEpH)
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,23,uIGD4vZcP61QNmw78LXqoEpH,V5lY03jQ2oKCWNhnzBicImgS+'01')
	qRF8YQeUsyC=0
	if type=='Series': WF2vkePC5gbXAGUarcqlpmB3Q='3'
	if type=='Film': WF2vkePC5gbXAGUarcqlpmB3Q='5'
	if type=='Program': WF2vkePC5gbXAGUarcqlpmB3Q='7'
	if type in ['Series','Program','Film'] and zmL397efNlks5uTEV!='0':
		SSHjMN4uegZfb2 = ei1Udas8znN5blIGC4qx2HwgQ+'/Home/PageingItem?category='+WF2vkePC5gbXAGUarcqlpmB3Q+'&page='+zmL397efNlks5uTEV+'&size=30&orderby='+V5lY03jQ2oKCWNhnzBicImgS
		CzNPJydxQLfw27tv4ZF8KORAbX5 = D0GFPwY8ecAVI(j9uzmBeEyK8,SSHjMN4uegZfb2,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'IFILM-TITLES-2nd')
		items = DyVGS3dX0ZxR.findall('"Id":(.*?),"Title":(.*?),.+?"ImageAddress_S":"(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		for id,title,uIGD4vZcP61QNmw78LXqoEpH in items:
			title = ArwuTXMNsaO9fmjWdI(title)
			title = title.replace('\\',HQmDERMFjx)
			title = title.replace('"',HQmDERMFjx)
			qRF8YQeUsyC += 1
			vn1grP3y4It9GmVuBbLJfz2A = ei1Udas8znN5blIGC4qx2HwgQ + xufJqQcGnhboiVy2wd + type + '/Content/' + id
			uIGD4vZcP61QNmw78LXqoEpH = ei1Udas8znN5blIGC4qx2HwgQ + VVkOtyQLzxBr(uIGD4vZcP61QNmw78LXqoEpH)
			if type=='Film': CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,24,uIGD4vZcP61QNmw78LXqoEpH,V5lY03jQ2oKCWNhnzBicImgS+'01')
			else: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,23,uIGD4vZcP61QNmw78LXqoEpH,V5lY03jQ2oKCWNhnzBicImgS+'01')
	if type=='Music':
		CzNPJydxQLfw27tv4ZF8KORAbX5 = D0GFPwY8ecAVI(j9uzmBeEyK8,ei1Udas8znN5blIGC4qx2HwgQ+'/Music/Index?page='+zmL397efNlks5uTEV,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'IFILM-TITLES-3rd')
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('pagination-demo(.*?)pagination-demo',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('href="(.*?)".*?src="(.*?)".*?<h3>(.*?)</h3>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,uIGD4vZcP61QNmw78LXqoEpH,title in items:
			qRF8YQeUsyC += 1
			uIGD4vZcP61QNmw78LXqoEpH = ei1Udas8znN5blIGC4qx2HwgQ + uIGD4vZcP61QNmw78LXqoEpH
			vn1grP3y4It9GmVuBbLJfz2A = ei1Udas8znN5blIGC4qx2HwgQ + vn1grP3y4It9GmVuBbLJfz2A
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,23,uIGD4vZcP61QNmw78LXqoEpH,'101')
	if qRF8YQeUsyC>20:
		title='صفحة '
		if ooJVyEN7CjtcOgGSeaRA=='en': title = 'Page '
		if ooJVyEN7CjtcOgGSeaRA=='fa': title = 'صفحه '
		if ooJVyEN7CjtcOgGSeaRA=='fa2': title = 'صفحه '
		for TTDKxdHL6XzbY2agoPNQBqeyZc in range(1,11) :
			if not zmL397efNlks5uTEV==str(TTDKxdHL6XzbY2agoPNQBqeyZc):
				uSRBQleYZF6Gb417EnCjvAkM = '0'+str(TTDKxdHL6XzbY2agoPNQBqeyZc)
				CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title+str(TTDKxdHL6XzbY2agoPNQBqeyZc),url,22,HQmDERMFjx,V5lY03jQ2oKCWNhnzBicImgS+uSRBQleYZF6Gb417EnCjvAkM[-2:])
	return
def XONC9osGSP4fW5HVrhM(url,zmL397efNlks5uTEV):
	if not zmL397efNlks5uTEV: zmL397efNlks5uTEV = 0
	ei1Udas8znN5blIGC4qx2HwgQ = sgbOXABfk8uYQj6ql41(url)
	E2fS6e0WmwFQP58Xx9ZJygIAYbTna = sgbOXABfk8uYQj6ql41(url)
	ooJVyEN7CjtcOgGSeaRA = NCZ7jowcBuMW8PUL6Idhvx(url)
	DDAoB3rdfJTXuE2RQwK8 = url.split(xufJqQcGnhboiVy2wd)
	id,type = DDAoB3rdfJTXuE2RQwK8[-1],DDAoB3rdfJTXuE2RQwK8[3]
	V5lY03jQ2oKCWNhnzBicImgS = str(int(zmL397efNlks5uTEV)//100)
	zmL397efNlks5uTEV = str(int(zmL397efNlks5uTEV)%100)
	qRF8YQeUsyC = 0
	if type=='Series':
		CzNPJydxQLfw27tv4ZF8KORAbX5 = D0GFPwY8ecAVI(j9uzmBeEyK8,url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'IFILM-EPISODES-1st')
		items = DyVGS3dX0ZxR.findall('Comment_panel_Item.*?p>(.*?)<i.+?var inter_ = (.*?);.*?src="(.*?)\'.*?data-url="(.*?)\'',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		title = ' - الحلقة '
		if ooJVyEN7CjtcOgGSeaRA=='en': title = ' - Episode '
		if ooJVyEN7CjtcOgGSeaRA=='fa': title = ' - قسمت '
		if ooJVyEN7CjtcOgGSeaRA=='fa2': title = ' - قسمت '
		if ooJVyEN7CjtcOgGSeaRA=='fa': JF5bQiNKYHMaWj9t4VO1BSZCro = HQmDERMFjx
		else: JF5bQiNKYHMaWj9t4VO1BSZCro = ooJVyEN7CjtcOgGSeaRA
		BRO8S9fLultdQk = DyVGS3dX0ZxR.findall('data-video="(.*?)(\'.*?\'_)(.*?)">',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		for name,count,uIGD4vZcP61QNmw78LXqoEpH,vn1grP3y4It9GmVuBbLJfz2A in items:
			for yTz8SOkAhu24j6apo9BmZHvwWsX in range(int(count),0,-1):
				jdpu1yA8f2haDx = uIGD4vZcP61QNmw78LXqoEpH + JF5bQiNKYHMaWj9t4VO1BSZCro + id + xufJqQcGnhboiVy2wd + str(yTz8SOkAhu24j6apo9BmZHvwWsX) + '.png'
				SLTf7GeYAM = name + title + str(yTz8SOkAhu24j6apo9BmZHvwWsX)
				SLTf7GeYAM = SVsiEWeRf6oIynqQx8pCrM4Tk(SLTf7GeYAM)
				CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+SLTf7GeYAM,url,24,jdpu1yA8f2haDx,HQmDERMFjx,str(yTz8SOkAhu24j6apo9BmZHvwWsX))
	elif type=='Program':
		SSHjMN4uegZfb2 = ei1Udas8znN5blIGC4qx2HwgQ+'/Home/PageingAttachmentItem?id='+str(id)+'&page='+zmL397efNlks5uTEV+'&size=30&orderby=1'
		CzNPJydxQLfw27tv4ZF8KORAbX5 = D0GFPwY8ecAVI(j9uzmBeEyK8,SSHjMN4uegZfb2,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'IFILM-EPISODES-2nd')
		items = DyVGS3dX0ZxR.findall('Episode":(.*?),.*?ImageAddress_S":"(.*?)".*?VideoAddress":"(.*?)".*?Discription":"(.*?)".*?Caption":"(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		title = ' - الحلقة '
		if ooJVyEN7CjtcOgGSeaRA=='en': title = ' - Episode '
		if ooJVyEN7CjtcOgGSeaRA=='fa': title = ' - قسمت '
		if ooJVyEN7CjtcOgGSeaRA=='fa2': title = ' - قسمت '
		for yTz8SOkAhu24j6apo9BmZHvwWsX,uIGD4vZcP61QNmw78LXqoEpH,vn1grP3y4It9GmVuBbLJfz2A,EH7GY1oredfs2z0N,name in items:
			qRF8YQeUsyC += 1
			jdpu1yA8f2haDx = E2fS6e0WmwFQP58Xx9ZJygIAYbTna + VVkOtyQLzxBr(uIGD4vZcP61QNmw78LXqoEpH)
			name = ArwuTXMNsaO9fmjWdI(name)
			SLTf7GeYAM = name + title + str(yTz8SOkAhu24j6apo9BmZHvwWsX)
			CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+SLTf7GeYAM,SSHjMN4uegZfb2,24,jdpu1yA8f2haDx,HQmDERMFjx,str(qRF8YQeUsyC))
	elif type=='Music':
		if 'Content' in url and 'category' not in url:
			SSHjMN4uegZfb2 = ei1Udas8znN5blIGC4qx2HwgQ+'/Music/GetTracksBy?id='+str(id)+'&page='+zmL397efNlks5uTEV+'&size=30&type=0'
			CzNPJydxQLfw27tv4ZF8KORAbX5 = D0GFPwY8ecAVI(j9uzmBeEyK8,SSHjMN4uegZfb2,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'IFILM-EPISODES-3rd')
			items = DyVGS3dX0ZxR.findall('ImageAddress_S":"(.*?)".*?VoiceAddress":"(.*?)".*?Caption":"(.*?)","Title":"(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
			for uIGD4vZcP61QNmw78LXqoEpH,vn1grP3y4It9GmVuBbLJfz2A,name,title in items:
				qRF8YQeUsyC += 1
				jdpu1yA8f2haDx = E2fS6e0WmwFQP58Xx9ZJygIAYbTna + VVkOtyQLzxBr(uIGD4vZcP61QNmw78LXqoEpH)
				SLTf7GeYAM = name + ' - ' + title
				SLTf7GeYAM = SLTf7GeYAM.strip(oQpxmKiRPlHeGsLXNrJF78O)
				SLTf7GeYAM = ArwuTXMNsaO9fmjWdI(SLTf7GeYAM)
				CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+SLTf7GeYAM,SSHjMN4uegZfb2,24,jdpu1yA8f2haDx,HQmDERMFjx,str(qRF8YQeUsyC))
		elif 'Clips' in url:
			SSHjMN4uegZfb2 = ei1Udas8znN5blIGC4qx2HwgQ+'/Music/GetTracksBy?id=0&page='+zmL397efNlks5uTEV+'&size=30&type=15'
			CzNPJydxQLfw27tv4ZF8KORAbX5 = D0GFPwY8ecAVI(j9uzmBeEyK8,SSHjMN4uegZfb2,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'IFILM-EPISODES-4th')
			items = DyVGS3dX0ZxR.findall('ImageAddress_S":"(.*?)".*?Caption":"(.*?)".*?VideoAddress":"(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
			for uIGD4vZcP61QNmw78LXqoEpH,title,vn1grP3y4It9GmVuBbLJfz2A in items:
				qRF8YQeUsyC += 1
				jdpu1yA8f2haDx = E2fS6e0WmwFQP58Xx9ZJygIAYbTna + VVkOtyQLzxBr(uIGD4vZcP61QNmw78LXqoEpH)
				SLTf7GeYAM = title.strip(oQpxmKiRPlHeGsLXNrJF78O)
				SLTf7GeYAM = ArwuTXMNsaO9fmjWdI(SLTf7GeYAM)
				CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+SLTf7GeYAM,SSHjMN4uegZfb2,24,jdpu1yA8f2haDx,HQmDERMFjx,str(qRF8YQeUsyC))
		elif 'category' in url:
			if 'category=6' in url:
				SSHjMN4uegZfb2 = ei1Udas8znN5blIGC4qx2HwgQ+'/Music/GetTracksBy?id=0&page='+zmL397efNlks5uTEV+'&size=30&type=6'
				CzNPJydxQLfw27tv4ZF8KORAbX5 = D0GFPwY8ecAVI(j9uzmBeEyK8,SSHjMN4uegZfb2,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'IFILM-EPISODES-5th')
			elif 'category=4' in url:
				SSHjMN4uegZfb2 = ei1Udas8znN5blIGC4qx2HwgQ+'/Music/GetTracksBy?id=0&page='+zmL397efNlks5uTEV+'&size=30&type=4'
				CzNPJydxQLfw27tv4ZF8KORAbX5 = D0GFPwY8ecAVI(j9uzmBeEyK8,SSHjMN4uegZfb2,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'IFILM-EPISODES-6th')
			items = DyVGS3dX0ZxR.findall('ImageAddress_S":"(.*?)".*?VoiceAddress":"(.*?)".*?Caption":"(.*?)","Title":"(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
			for uIGD4vZcP61QNmw78LXqoEpH,vn1grP3y4It9GmVuBbLJfz2A,name,title in items:
				qRF8YQeUsyC += 1
				jdpu1yA8f2haDx = E2fS6e0WmwFQP58Xx9ZJygIAYbTna + VVkOtyQLzxBr(uIGD4vZcP61QNmw78LXqoEpH)
				SLTf7GeYAM = name + ' - ' + title
				SLTf7GeYAM = SLTf7GeYAM.strip(oQpxmKiRPlHeGsLXNrJF78O)
				SLTf7GeYAM = ArwuTXMNsaO9fmjWdI(SLTf7GeYAM)
				CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+SLTf7GeYAM,SSHjMN4uegZfb2,24,jdpu1yA8f2haDx,HQmDERMFjx,str(qRF8YQeUsyC))
	if type=='Music' or type=='Program':
		if qRF8YQeUsyC>25:
			title='صفحة '
			if ooJVyEN7CjtcOgGSeaRA=='en': title = ' Page '
			if ooJVyEN7CjtcOgGSeaRA=='fa': title = ' صفحه '
			if ooJVyEN7CjtcOgGSeaRA=='fa2': title = ' صفحه '
			for TTDKxdHL6XzbY2agoPNQBqeyZc in range(1,11):
				if not zmL397efNlks5uTEV==str(TTDKxdHL6XzbY2agoPNQBqeyZc):
					uSRBQleYZF6Gb417EnCjvAkM = '0'+str(TTDKxdHL6XzbY2agoPNQBqeyZc)
					CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title+str(TTDKxdHL6XzbY2agoPNQBqeyZc),url,23,HQmDERMFjx,V5lY03jQ2oKCWNhnzBicImgS+uSRBQleYZF6Gb417EnCjvAkM[-2:])
	return
def f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url,yTz8SOkAhu24j6apo9BmZHvwWsX):
	E2fS6e0WmwFQP58Xx9ZJygIAYbTna = sgbOXABfk8uYQj6ql41(url)
	gBzGTxKMSVWFLPvfAI0UZ98D5,Na8vklCpUGYIzP0bjutWOT = [],[]
	CzNPJydxQLfw27tv4ZF8KORAbX5 = D0GFPwY8ecAVI(j9uzmBeEyK8,url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'IFILM-PLAY-1st')
	items = DyVGS3dX0ZxR.findall('data-video="(.*?)(\'.*?\'_)(.*?)">',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if items:
		ooJVyEN7CjtcOgGSeaRA = NCZ7jowcBuMW8PUL6Idhvx(url)
		DDAoB3rdfJTXuE2RQwK8 = url.split(xufJqQcGnhboiVy2wd)
		id,type = DDAoB3rdfJTXuE2RQwK8[-1],DDAoB3rdfJTXuE2RQwK8[3]
		vn1grP3y4It9GmVuBbLJfz2A = items[0][0]+ooJVyEN7CjtcOgGSeaRA+id+'/,'+yTz8SOkAhu24j6apo9BmZHvwWsX+','+yTz8SOkAhu24j6apo9BmZHvwWsX+'_'+items[0][2]
		gBzGTxKMSVWFLPvfAI0UZ98D5.append('m3u8')
		Na8vklCpUGYIzP0bjutWOT.append(vn1grP3y4It9GmVuBbLJfz2A)
	items = DyVGS3dX0ZxR.findall('data-url="(http.*?)(\'.*?\')(\..*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if items:
		ooJVyEN7CjtcOgGSeaRA = NCZ7jowcBuMW8PUL6Idhvx(url)
		DDAoB3rdfJTXuE2RQwK8 = url.split(xufJqQcGnhboiVy2wd)
		id,type = DDAoB3rdfJTXuE2RQwK8[-1],DDAoB3rdfJTXuE2RQwK8[3]
		vn1grP3y4It9GmVuBbLJfz2A = items[0][0]+ooJVyEN7CjtcOgGSeaRA+id+xufJqQcGnhboiVy2wd+yTz8SOkAhu24j6apo9BmZHvwWsX+items[0][2]
		gBzGTxKMSVWFLPvfAI0UZ98D5.append('mp4 url')
		Na8vklCpUGYIzP0bjutWOT.append(vn1grP3y4It9GmVuBbLJfz2A)
	items = DyVGS3dX0ZxR.findall('source src="(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	for vn1grP3y4It9GmVuBbLJfz2A in items:
		vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A.replace(mKqAOsD5p0C,xufJqQcGnhboiVy2wd)
		gBzGTxKMSVWFLPvfAI0UZ98D5.append('mp4 src')
		Na8vklCpUGYIzP0bjutWOT.append(vn1grP3y4It9GmVuBbLJfz2A)
	items = DyVGS3dX0ZxR.findall('VideoAddress":"(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if items:
		vn1grP3y4It9GmVuBbLJfz2A = items[int(yTz8SOkAhu24j6apo9BmZHvwWsX)-1]
		vn1grP3y4It9GmVuBbLJfz2A = E2fS6e0WmwFQP58Xx9ZJygIAYbTna+VVkOtyQLzxBr(vn1grP3y4It9GmVuBbLJfz2A)
		gBzGTxKMSVWFLPvfAI0UZ98D5.append('mp4 address')
		Na8vklCpUGYIzP0bjutWOT.append(vn1grP3y4It9GmVuBbLJfz2A)
	items = DyVGS3dX0ZxR.findall('VoiceAddress":"(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if items:
		vn1grP3y4It9GmVuBbLJfz2A = items[int(yTz8SOkAhu24j6apo9BmZHvwWsX)-1]
		vn1grP3y4It9GmVuBbLJfz2A = E2fS6e0WmwFQP58Xx9ZJygIAYbTna+VVkOtyQLzxBr(vn1grP3y4It9GmVuBbLJfz2A)
		gBzGTxKMSVWFLPvfAI0UZ98D5.append('mp3 address')
		Na8vklCpUGYIzP0bjutWOT.append(vn1grP3y4It9GmVuBbLJfz2A)
	if len(Na8vklCpUGYIzP0bjutWOT)==1: vn1grP3y4It9GmVuBbLJfz2A = Na8vklCpUGYIzP0bjutWOT[0]
	else:
		lwT9cdaH5AxMU8IpZif20jPX = GGiSlWbqKDr5Ovkh2L7sHNTxz('اختر الفيديو المناسب:', gBzGTxKMSVWFLPvfAI0UZ98D5)
		if lwT9cdaH5AxMU8IpZif20jPX == -1 : return
		vn1grP3y4It9GmVuBbLJfz2A = Na8vklCpUGYIzP0bjutWOT[lwT9cdaH5AxMU8IpZif20jPX]
	uZVS3DcJbEULoxpve9IOTgmW6(vn1grP3y4It9GmVuBbLJfz2A,HDLtdMAy7wPkl8aKC3O2,'video')
	return
def sgbOXABfk8uYQj6ql41(url):
	if e2VR8nohduY in url: ZvCajmoUedFL = e2VR8nohduY
	elif waE5LXVN0BOiQjCUur3oTt6eYSIHJK in url: ZvCajmoUedFL = waE5LXVN0BOiQjCUur3oTt6eYSIHJK
	elif IsK7MxWgSEa9JkHQntoh in url: ZvCajmoUedFL = IsK7MxWgSEa9JkHQntoh
	elif DCjTaEdrxubcWABgoL in url: ZvCajmoUedFL = DCjTaEdrxubcWABgoL
	else: ZvCajmoUedFL = HQmDERMFjx
	return ZvCajmoUedFL
def NCZ7jowcBuMW8PUL6Idhvx(url):
	if   e2VR8nohduY in url: ooJVyEN7CjtcOgGSeaRA = 'ar'
	elif waE5LXVN0BOiQjCUur3oTt6eYSIHJK in url: ooJVyEN7CjtcOgGSeaRA = 'en'
	elif IsK7MxWgSEa9JkHQntoh in url: ooJVyEN7CjtcOgGSeaRA = 'fa'
	elif DCjTaEdrxubcWABgoL in url: ooJVyEN7CjtcOgGSeaRA = 'fa2'
	else: ooJVyEN7CjtcOgGSeaRA = HQmDERMFjx
	return ooJVyEN7CjtcOgGSeaRA
def eY4DutR9cHF(url):
	ooJVyEN7CjtcOgGSeaRA = NCZ7jowcBuMW8PUL6Idhvx(url)
	SSHjMN4uegZfb2 = url + '/Home/Live'
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(H5x4Z2qPwR8vXM,'GET',SSHjMN4uegZfb2,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'IFILM-LIVE-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	items = DyVGS3dX0ZxR.findall('source src="(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	jDcWv7MAkEV = items[0]
	uZVS3DcJbEULoxpve9IOTgmW6(jDcWv7MAkEV,HDLtdMAy7wPkl8aKC3O2,'live')
	return
def hm4kawIPKp3oMrC75dJZA9HS2(search):
	search,GXVabd4sc2u3zp0JI,showDialogs = x0pzMENwy84tBcZvXr(search)
	if not search:
		search = q156m84QoYrn()
		if not search: return
	q5qfEX4yA6lDop1 = search.replace(oQpxmKiRPlHeGsLXNrJF78O,'+')
	if showDialogs:
		zpmZyYS7gTje0xJnqFO2kXI4oiA8aR = [ e2VR8nohduY , waE5LXVN0BOiQjCUur3oTt6eYSIHJK , IsK7MxWgSEa9JkHQntoh , DCjTaEdrxubcWABgoL ]
		YCr6BwK1sluTnO3xg5MN74GXQkLPm = [ 'عربي' , 'English' , 'فارسى' , 'فارسى 2' ]
		lwT9cdaH5AxMU8IpZif20jPX = GGiSlWbqKDr5Ovkh2L7sHNTxz('اختر اللغة المناسبة:', YCr6BwK1sluTnO3xg5MN74GXQkLPm)
		if lwT9cdaH5AxMU8IpZif20jPX == -1 : return
		website = zpmZyYS7gTje0xJnqFO2kXI4oiA8aR[lwT9cdaH5AxMU8IpZif20jPX]
	else:
		if '_IFILM-ARABIC_' in GXVabd4sc2u3zp0JI: website = e2VR8nohduY
		elif '_IFILM-ENGLISH_' in GXVabd4sc2u3zp0JI: website = waE5LXVN0BOiQjCUur3oTt6eYSIHJK
		else: website = HQmDERMFjx
	if not website: return
	ooJVyEN7CjtcOgGSeaRA = NCZ7jowcBuMW8PUL6Idhvx(website)
	SSHjMN4uegZfb2 = website + "/Home/Search?searchstring=" + q5qfEX4yA6lDop1
	CzNPJydxQLfw27tv4ZF8KORAbX5 = D0GFPwY8ecAVI(j9uzmBeEyK8,SSHjMN4uegZfb2,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'IFILM-SEARCH-1st')
	items = DyVGS3dX0ZxR.findall('"ImageAddress_[SML]":"(.*?\/.*?)".*?"CategoryId":(.*?),"Id":(.*?),"Title":"(.*?)",',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if items:
		for uIGD4vZcP61QNmw78LXqoEpH,WF2vkePC5gbXAGUarcqlpmB3Q,id,title in items:
			if WF2vkePC5gbXAGUarcqlpmB3Q in ['3','7']:
				title = title.replace('\\',HQmDERMFjx)
				title = title.replace('"',HQmDERMFjx)
				if WF2vkePC5gbXAGUarcqlpmB3Q=='3':
					type = 'Series'
					if ooJVyEN7CjtcOgGSeaRA=='ar': name = 'مسلسل : '
					elif ooJVyEN7CjtcOgGSeaRA=='en': name = 'Series : '
					elif ooJVyEN7CjtcOgGSeaRA=='fa': name = 'سريال ها : '
					elif ooJVyEN7CjtcOgGSeaRA=='fa2': name = 'سريال ها : '
				elif WF2vkePC5gbXAGUarcqlpmB3Q=='5':
					type = 'Film'
					if ooJVyEN7CjtcOgGSeaRA=='ar': name = 'فيلم : '
					elif ooJVyEN7CjtcOgGSeaRA=='en': name = 'Movie : '
					elif ooJVyEN7CjtcOgGSeaRA=='fa': name = 'فيلم : '
					elif ooJVyEN7CjtcOgGSeaRA=='fa2': name = 'فلم ها : '
				elif WF2vkePC5gbXAGUarcqlpmB3Q=='7':
					type = 'Program'
					if ooJVyEN7CjtcOgGSeaRA=='ar': name = 'برنامج : '
					elif ooJVyEN7CjtcOgGSeaRA=='en': name = 'Program : '
					elif ooJVyEN7CjtcOgGSeaRA=='fa': name = 'برنامه ها : '
					elif ooJVyEN7CjtcOgGSeaRA=='fa2': name = 'برنامه ها : '
				title = name + title
				vn1grP3y4It9GmVuBbLJfz2A = website + xufJqQcGnhboiVy2wd + type + '/Content/' + id
				uIGD4vZcP61QNmw78LXqoEpH = VVkOtyQLzxBr(uIGD4vZcP61QNmw78LXqoEpH)
				uIGD4vZcP61QNmw78LXqoEpH = website+uIGD4vZcP61QNmw78LXqoEpH
				CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,23,uIGD4vZcP61QNmw78LXqoEpH,'101')
	return
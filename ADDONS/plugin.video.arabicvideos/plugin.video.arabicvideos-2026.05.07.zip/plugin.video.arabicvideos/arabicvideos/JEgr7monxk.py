# -*- coding: utf-8 -*-
from FF68kA5BUy import *
HDLtdMAy7wPkl8aKC3O2 = 'GLOBALSEARCH'
EEJvXQzSZNt = '_GLS_'
def kk6X5LxpsND(lXBL3WrM2JFYm,GUiCEYZjm5,NN9niuC7RoqmhkL2,zmL397efNlks5uTEV):
	if   lXBL3WrM2JFYm==540: zLZUkrP7ac5 = afkxo7FyZWB4O6K1eXrs5I()
	elif lXBL3WrM2JFYm==541: zLZUkrP7ac5 = zFthePyxOd83o96MVHTl5(NN9niuC7RoqmhkL2)
	elif lXBL3WrM2JFYm==542: zLZUkrP7ac5 = ly3vPB6IbYJfG(NN9niuC7RoqmhkL2,GUiCEYZjm5,zmL397efNlks5uTEV)
	elif lXBL3WrM2JFYm==543: zLZUkrP7ac5 = XX1eyLnvftQ8d0aNwHkcsCJGP4x()
	elif lXBL3WrM2JFYm==548: zLZUkrP7ac5 = ku2TANEVQDY130jKm(GUiCEYZjm5,NN9niuC7RoqmhkL2)
	elif lXBL3WrM2JFYm==549: zLZUkrP7ac5 = hm4kawIPKp3oMrC75dJZA9HS2(NN9niuC7RoqmhkL2)
	else: zLZUkrP7ac5 = False
	return zLZUkrP7ac5
def afkxo7FyZWB4O6K1eXrs5I():
	CfgK4s13Q0hZcHyleT2bVJO9('folder','بحث جديد لجميع المواقع',HQmDERMFjx,549)
	CfgK4s13Q0hZcHyleT2bVJO9('link','كيف يعمل بحث جميع المواقع','',543)
	CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+'==== كلمات البحث المخزنة ===='+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	AADoyWB6xKYzICleVNvjU8 = FcSRPu295Ot1Jv0Bip3IDom(rDy4FoKpEOsXfT8WZjli,'dict','GLOBALSEARCH_SPLITTED_ALL')
	if AADoyWB6xKYzICleVNvjU8:
		AADoyWB6xKYzICleVNvjU8 = AADoyWB6xKYzICleVNvjU8['__SEQUENCED_COLUMNS__']
		for f5IwhEVtJQG9pODZAU2RnCx7cd80u in reversed(AADoyWB6xKYzICleVNvjU8):
			CfgK4s13Q0hZcHyleT2bVJO9('folder',f5IwhEVtJQG9pODZAU2RnCx7cd80u,HQmDERMFjx,549,HQmDERMFjx,HQmDERMFjx,f5IwhEVtJQG9pODZAU2RnCx7cd80u)
	return
def hm4kawIPKp3oMrC75dJZA9HS2(f5IwhEVtJQG9pODZAU2RnCx7cd80u):
	if not f5IwhEVtJQG9pODZAU2RnCx7cd80u:
		f5IwhEVtJQG9pODZAU2RnCx7cd80u = q156m84QoYrn()
		if not f5IwhEVtJQG9pODZAU2RnCx7cd80u: return
		f5IwhEVtJQG9pODZAU2RnCx7cd80u = f5IwhEVtJQG9pODZAU2RnCx7cd80u.lower()
	JNFUAM0L4BQ = f5IwhEVtJQG9pODZAU2RnCx7cd80u.replace(EEJvXQzSZNt,HQmDERMFjx)
	zBneiOxaNmXVcW2s1MDjItAqk(JNFUAM0L4BQ,'_ALL',True)
	CfgK4s13Q0hZcHyleT2bVJO9('link','بحث جماعي للمواقع - '+JNFUAM0L4BQ,'search_sites_all',542,HQmDERMFjx,HQmDERMFjx,JNFUAM0L4BQ)
	CfgK4s13Q0hZcHyleT2bVJO9('folder','بحث منفرد للمواقع - '+JNFUAM0L4BQ,HQmDERMFjx,541,HQmDERMFjx,HQmDERMFjx,JNFUAM0L4BQ)
	CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+'===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	CfgK4s13Q0hZcHyleT2bVJO9('folder','نتائج البحث مفصلة - '+JNFUAM0L4BQ,'opened_sites_all',542,HQmDERMFjx,HQmDERMFjx,JNFUAM0L4BQ)
	CfgK4s13Q0hZcHyleT2bVJO9('folder','نتائج البحث مقسمة - '+JNFUAM0L4BQ,'listed_sites_all',542,HQmDERMFjx,HQmDERMFjx,JNFUAM0L4BQ)
	return
def zBneiOxaNmXVcW2s1MDjItAqk(VnfwOdRyBizEICJHFW0P5o2s,MNCHE4uaIG6J792fDxbQFWgSKZ05Rv,DZb7KB0LSyutA6TrCG):
	if MNCHE4uaIG6J792fDxbQFWgSKZ05Rv=='_ALL': WBkbsHztUu4ZEahRYgD5rfQdyNp = '_GLS_'
	elif MNCHE4uaIG6J792fDxbQFWgSKZ05Rv=='_GOOGLE': WBkbsHztUu4ZEahRYgD5rfQdyNp = '_GOS_'
	QcJnR4TKWD1bzO7ZmwF = FcSRPu295Ot1Jv0Bip3IDom(rDy4FoKpEOsXfT8WZjli,'list','GLOBALSEARCH_SPLITTED'+MNCHE4uaIG6J792fDxbQFWgSKZ05Rv,VnfwOdRyBizEICJHFW0P5o2s)
	KyCN5SUIkc9ndhjf3ADzxHF = FcSRPu295Ot1Jv0Bip3IDom(rDy4FoKpEOsXfT8WZjli,'list','GLOBALSEARCH_SPLITTED'+MNCHE4uaIG6J792fDxbQFWgSKZ05Rv,WBkbsHztUu4ZEahRYgD5rfQdyNp+VnfwOdRyBizEICJHFW0P5o2s)
	X8X1TJW3AmVdy0ZrFvqjDba7Bg2(rDy4FoKpEOsXfT8WZjli,'GLOBALSEARCH_SPLITTED'+MNCHE4uaIG6J792fDxbQFWgSKZ05Rv,VnfwOdRyBizEICJHFW0P5o2s)
	X8X1TJW3AmVdy0ZrFvqjDba7Bg2(rDy4FoKpEOsXfT8WZjli,'GLOBALSEARCH_SPLITTED'+MNCHE4uaIG6J792fDxbQFWgSKZ05Rv,WBkbsHztUu4ZEahRYgD5rfQdyNp+VnfwOdRyBizEICJHFW0P5o2s)
	wwWNL9icm8rRxeQJICajT = QcJnR4TKWD1bzO7ZmwF+KyCN5SUIkc9ndhjf3ADzxHF
	if wwWNL9icm8rRxeQJICajT and DZb7KB0LSyutA6TrCG: VnfwOdRyBizEICJHFW0P5o2s = WBkbsHztUu4ZEahRYgD5rfQdyNp+VnfwOdRyBizEICJHFW0P5o2s
	HqD3sxo0fJX(rDy4FoKpEOsXfT8WZjli,'GLOBALSEARCH_SPLITTED'+MNCHE4uaIG6J792fDxbQFWgSKZ05Rv,VnfwOdRyBizEICJHFW0P5o2s,wwWNL9icm8rRxeQJICajT,ppxzXEh5md4Dwota3gBQFc)
	return
def OBUCs5ipL2dnw(MNCHE4uaIG6J792fDxbQFWgSKZ05Rv):
	N7gs9UBCeDR3 = HUJZy0SrTbBYv1(HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,'هل تريد مسح جميع كلمات البحث المخزنة في البرنامج ؟!!')
	if N7gs9UBCeDR3!=1: return
	X8X1TJW3AmVdy0ZrFvqjDba7Bg2(rDy4FoKpEOsXfT8WZjli,'GLOBALSEARCH_SPLITTED'+MNCHE4uaIG6J792fDxbQFWgSKZ05Rv)
	X8X1TJW3AmVdy0ZrFvqjDba7Bg2(rDy4FoKpEOsXfT8WZjli,'GLOBALSEARCH_DETAILED'+MNCHE4uaIG6J792fDxbQFWgSKZ05Rv)
	X8X1TJW3AmVdy0ZrFvqjDba7Bg2(rDy4FoKpEOsXfT8WZjli,'GLOBALSEARCH_DIVIDED'+MNCHE4uaIG6J792fDxbQFWgSKZ05Rv)
	if MNCHE4uaIG6J792fDxbQFWgSKZ05Rv=='_GOOGLE': X8X1TJW3AmVdy0ZrFvqjDba7Bg2(rDy4FoKpEOsXfT8WZjli,'GOOGLESEARCH_RESULTS')
	u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,'تم بنجاح مسح جميع كلمات البحث المخزنة في البرنامج')
	return
def ly3vPB6IbYJfG(ixkJ7PTUnZYvOX2WIV,CymIGXMrN9,EwbVy4Z7fp2rnks0MTCF8WUBQR3gl=HQmDERMFjx,ssdQe9VYxu0Dg1Nwl7yi84tOrILv=bychWmvV7a,Y30puSIPxTNKR9O5aZbrosD={}):
	pR2xGuf58imZW,UeurntcIvFJ6bVY,nKEC4U9uBjRe1H,zvEKw9DMPJOoUFdpB,zovIsMbhidf2Ru1WwnFK30tP7O = [],{},{},{},{}
	if '_all' in CymIGXMrN9: MNCHE4uaIG6J792fDxbQFWgSKZ05Rv,QG65xDvLnrhmFb9UaRI7,WBkbsHztUu4ZEahRYgD5rfQdyNp = '_ALL','_all','_GLS_'
	elif '_google' in CymIGXMrN9: MNCHE4uaIG6J792fDxbQFWgSKZ05Rv,QG65xDvLnrhmFb9UaRI7,WBkbsHztUu4ZEahRYgD5rfQdyNp = '_GOOGLE','_google','_GOS_'
	if CymIGXMrN9 in ['listed_sites'+QG65xDvLnrhmFb9UaRI7,'opened_sites'+QG65xDvLnrhmFb9UaRI7,'closed_sites'+QG65xDvLnrhmFb9UaRI7]:
		if CymIGXMrN9=='listed_sites'+QG65xDvLnrhmFb9UaRI7: pR2xGuf58imZW = FcSRPu295Ot1Jv0Bip3IDom(rDy4FoKpEOsXfT8WZjli,'list','GLOBALSEARCH_SPLITTED'+MNCHE4uaIG6J792fDxbQFWgSKZ05Rv,WBkbsHztUu4ZEahRYgD5rfQdyNp+ixkJ7PTUnZYvOX2WIV)
		elif CymIGXMrN9=='opened_sites'+QG65xDvLnrhmFb9UaRI7: pR2xGuf58imZW = FcSRPu295Ot1Jv0Bip3IDom(rDy4FoKpEOsXfT8WZjli,'list','GLOBALSEARCH_DETAILED'+MNCHE4uaIG6J792fDxbQFWgSKZ05Rv,ixkJ7PTUnZYvOX2WIV)
		elif CymIGXMrN9=='closed_sites'+QG65xDvLnrhmFb9UaRI7: pR2xGuf58imZW = FcSRPu295Ot1Jv0Bip3IDom(rDy4FoKpEOsXfT8WZjli,'list','GLOBALSEARCH_DIVIDED'+MNCHE4uaIG6J792fDxbQFWgSKZ05Rv,(EwbVy4Z7fp2rnks0MTCF8WUBQR3gl,ixkJ7PTUnZYvOX2WIV))
	if not pR2xGuf58imZW:
		rGIDET0OmyFiUL8q = 'هذا البحث غير موجود في كاش البرنامج \n\n\n'
		iCDE40qzXlhxrvf = 'هل تريد الآن البحث في جميع المواقع عن \n "'+s7d549VgeP+oQpxmKiRPlHeGsLXNrJF78O+ixkJ7PTUnZYvOX2WIV+oQpxmKiRPlHeGsLXNrJF78O+cjqzOQ5GXD4kR+'" \n علما أن هذا البحث قد يحتاج بعض الوقت'
		if CymIGXMrN9=='search_sites'+QG65xDvLnrhmFb9UaRI7: wwpQTfixYD23X = iCDE40qzXlhxrvf
		else: wwpQTfixYD23X = rGIDET0OmyFiUL8q+iCDE40qzXlhxrvf
		N7gs9UBCeDR3 = HUJZy0SrTbBYv1(HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,wwpQTfixYD23X)
		if N7gs9UBCeDR3!=1: return
		XgW8wuKsyUDpmRQvSV0cNfhxAiFJE(xjD4NgpEkFCrnw8S,xjD4NgpEkFCrnw8S,xjD4NgpEkFCrnw8S)
		vv8DyVrLOPAXFIMZ9h(RRWFdpe04EK1Qn,LLe5QGmjCZigv(HDLtdMAy7wPkl8aKC3O2)+'   Search For: [ '+ixkJ7PTUnZYvOX2WIV+' ]')
		NiLEY4T6QfvWIbuHBPa9S = 1
		for ZvCajmoUedFL in ssdQe9VYxu0Dg1Nwl7yi84tOrILv:
			MNljE7832SpHPa5U6Dr0G = Y30puSIPxTNKR9O5aZbrosD[ZvCajmoUedFL] if Y30puSIPxTNKR9O5aZbrosD else ixkJ7PTUnZYvOX2WIV
			try: ddCehb9TygPN5HnMZKBEJA3W42romX,yG0k5pe3mH2,TZRm3tqUKHucWGQ9h08 = h8J6YwoHNtia4LXDVjs0GbW(ZvCajmoUedFL)
			except: continue
			UeurntcIvFJ6bVY[ZvCajmoUedFL] = []
			LlsCEXIte1n9TG0BAVOojqyvQkhb5 = '_NODIALOGS_'
			if '-' in ZvCajmoUedFL: LlsCEXIte1n9TG0BAVOojqyvQkhb5 = LlsCEXIte1n9TG0BAVOojqyvQkhb5+'_REMEMBERRESULTS__'+ZvCajmoUedFL+'_'
			if NiLEY4T6QfvWIbuHBPa9S:
				jHWkt18govGwY7iUbduAfxCyRc.sleep(0.75)
				zovIsMbhidf2Ru1WwnFK30tP7O[ZvCajmoUedFL] = Lk21XpCMZto(daemon=gyd2rf0UR5,target=yG0k5pe3mH2,args=(MNljE7832SpHPa5U6Dr0G+LlsCEXIte1n9TG0BAVOojqyvQkhb5,))
				zovIsMbhidf2Ru1WwnFK30tP7O[ZvCajmoUedFL].start()
			else: yG0k5pe3mH2(MNljE7832SpHPa5U6Dr0G+LlsCEXIte1n9TG0BAVOojqyvQkhb5)
			x8a2FGB1jAef94byI(oFLajW6gOrufM7I(ZvCajmoUedFL),HQmDERMFjx,jHWkt18govGwY7iUbduAfxCyRc=1000)
		if NiLEY4T6QfvWIbuHBPa9S:
			jHWkt18govGwY7iUbduAfxCyRc.sleep(2)
			for ZvCajmoUedFL in ssdQe9VYxu0Dg1Nwl7yi84tOrILv: zovIsMbhidf2Ru1WwnFK30tP7O[ZvCajmoUedFL].join(10)
			jHWkt18govGwY7iUbduAfxCyRc.sleep(2)
		for ZvCajmoUedFL in ssdQe9VYxu0Dg1Nwl7yi84tOrILv:
			try: ddCehb9TygPN5HnMZKBEJA3W42romX,yG0k5pe3mH2,TZRm3tqUKHucWGQ9h08 = h8J6YwoHNtia4LXDVjs0GbW(ZvCajmoUedFL)
			except: continue
			for Xao8y1RQZSG in Jzthpc2nj5.menuItemsLIST:
				arsOBITUkup7x3eSfEvM,XyOvPTlmBK4hDVjfi,GUiCEYZjm5,lXBL3WrM2JFYm,kALyrFT6KPNGI7Oiup82Qb4JCq0td,zmL397efNlks5uTEV,NN9niuC7RoqmhkL2,nObHm3uEzJ,GoC84Eq3azJwpSWxkctF1MdTruOIyb = Xao8y1RQZSG
				if TZRm3tqUKHucWGQ9h08 in XyOvPTlmBK4hDVjfi:
					if 'IPTV-' in ZvCajmoUedFL and (239>=lXBL3WrM2JFYm>=230 or 289>=lXBL3WrM2JFYm>=280):
						if Xao8y1RQZSG in UeurntcIvFJ6bVY['IPTV-LIVE']: continue
						if Xao8y1RQZSG in UeurntcIvFJ6bVY['IPTV-MOVIES']: continue
						if Xao8y1RQZSG in UeurntcIvFJ6bVY['IPTV-SERIES']: continue
						if 'صفحة' not in XyOvPTlmBK4hDVjfi:
							if   arsOBITUkup7x3eSfEvM=='live': ZvCajmoUedFL = 'IPTV-LIVE'
							elif arsOBITUkup7x3eSfEvM=='video': ZvCajmoUedFL = 'IPTV-MOVIES'
							elif arsOBITUkup7x3eSfEvM=='folder': ZvCajmoUedFL = 'IPTV-SERIES'
						else:
							if   'LIVE' in GUiCEYZjm5: ZvCajmoUedFL = 'IPTV-LIVE'
							elif 'MOVIES' in GUiCEYZjm5: ZvCajmoUedFL = 'IPTV-MOVIES'
							elif 'SERIES' in GUiCEYZjm5: ZvCajmoUedFL = 'IPTV-SERIES'
					elif 'M3U-' in ZvCajmoUedFL and 729>=lXBL3WrM2JFYm>=710:
						if Xao8y1RQZSG in UeurntcIvFJ6bVY['M3U-LIVE']: continue
						if Xao8y1RQZSG in UeurntcIvFJ6bVY['M3U-MOVIES']: continue
						if Xao8y1RQZSG in UeurntcIvFJ6bVY['M3U-SERIES']: continue
						if 'صفحة' not in XyOvPTlmBK4hDVjfi:
							if   arsOBITUkup7x3eSfEvM=='live': ZvCajmoUedFL = 'M3U-LIVE'
							elif arsOBITUkup7x3eSfEvM=='video': ZvCajmoUedFL = 'M3U-MOVIES'
							elif arsOBITUkup7x3eSfEvM=='folder': ZvCajmoUedFL = 'M3U-SERIES'
						else:
							if   'LIVE' in GUiCEYZjm5: ZvCajmoUedFL = 'M3U-LIVE'
							elif 'MOVIES' in GUiCEYZjm5: ZvCajmoUedFL = 'M3U-MOVIES'
							elif 'SERIES' in GUiCEYZjm5: ZvCajmoUedFL = 'M3U-SERIES'
					elif 'YOUTUBE-' in ZvCajmoUedFL and 149>=lXBL3WrM2JFYm>=140:
						if Xao8y1RQZSG in UeurntcIvFJ6bVY['YOUTUBE-CHANNELS']: continue
						if Xao8y1RQZSG in UeurntcIvFJ6bVY['YOUTUBE-PLAYLISTS']: continue
						if Xao8y1RQZSG in UeurntcIvFJ6bVY['YOUTUBE-VIDEOS']: continue
						if 'صفحة أخرى' in XyOvPTlmBK4hDVjfi or ':: ' in XyOvPTlmBK4hDVjfi:
							continue
						else:
							if   lXBL3WrM2JFYm==144 and 'USER' in XyOvPTlmBK4hDVjfi: ZvCajmoUedFL = 'YOUTUBE-CHANNELS'
							elif lXBL3WrM2JFYm==144 and 'CHNL' in XyOvPTlmBK4hDVjfi: ZvCajmoUedFL = 'YOUTUBE-CHANNELS'
							elif lXBL3WrM2JFYm==144 and 'LIST' in XyOvPTlmBK4hDVjfi: ZvCajmoUedFL = 'YOUTUBE-PLAYLISTS'
							elif lXBL3WrM2JFYm==143: ZvCajmoUedFL = 'YOUTUBE-VIDEOS'
							else: continue
					elif 'DAILYMOTION-' in ZvCajmoUedFL and 419>=lXBL3WrM2JFYm>=400:
						if Xao8y1RQZSG in UeurntcIvFJ6bVY['DAILYMOTION-PLAYLISTS']: continue
						if Xao8y1RQZSG in UeurntcIvFJ6bVY['DAILYMOTION-CHANNELS']: continue
						if Xao8y1RQZSG in UeurntcIvFJ6bVY['DAILYMOTION-VIDEOS']: continue
						if Xao8y1RQZSG in UeurntcIvFJ6bVY['DAILYMOTION-LIVES']: continue
						if Xao8y1RQZSG in UeurntcIvFJ6bVY['DAILYMOTION-HASHTAGS']: continue
						if   lXBL3WrM2JFYm in [401,405]: ZvCajmoUedFL = 'DAILYMOTION-PLAYLISTS'
						elif lXBL3WrM2JFYm in [402,406]: ZvCajmoUedFL = 'DAILYMOTION-CHANNELS'
						elif lXBL3WrM2JFYm in [404]: ZvCajmoUedFL = 'DAILYMOTION-VIDEOS'
						elif lXBL3WrM2JFYm in [415]: ZvCajmoUedFL = 'DAILYMOTION-LIVES'
						elif lXBL3WrM2JFYm in [416]: ZvCajmoUedFL = 'DAILYMOTION-HASHTAGS'
					elif 'PANET-' in ZvCajmoUedFL and 39>=lXBL3WrM2JFYm>=30:
						if Xao8y1RQZSG in UeurntcIvFJ6bVY['PANET-SERIES']: continue
						if Xao8y1RQZSG in UeurntcIvFJ6bVY['PANET-MOVIES']: continue
						if   lXBL3WrM2JFYm in [32,39]: ZvCajmoUedFL = 'PANET-SERIES'
						elif lXBL3WrM2JFYm in [33,39]: ZvCajmoUedFL = 'PANET-MOVIES'
					elif 'IFILM-' in ZvCajmoUedFL and 29>=lXBL3WrM2JFYm>=20:
						if Xao8y1RQZSG in UeurntcIvFJ6bVY['IFILM-ARABIC']: continue
						if Xao8y1RQZSG in UeurntcIvFJ6bVY['IFILM-ENGLISH']: continue
						if   '/ar.' in GUiCEYZjm5: ZvCajmoUedFL = 'IFILM-ARABIC'
						elif '/en.' in GUiCEYZjm5: ZvCajmoUedFL = 'IFILM-ENGLISH'
					UeurntcIvFJ6bVY[ZvCajmoUedFL].append(Xao8y1RQZSG)
		for ZvCajmoUedFL in list(UeurntcIvFJ6bVY.keys()):
			nKEC4U9uBjRe1H[ZvCajmoUedFL] = []
			zvEKw9DMPJOoUFdpB[ZvCajmoUedFL] = []
			for arsOBITUkup7x3eSfEvM,XyOvPTlmBK4hDVjfi,GUiCEYZjm5,lXBL3WrM2JFYm,kALyrFT6KPNGI7Oiup82Qb4JCq0td,zmL397efNlks5uTEV,NN9niuC7RoqmhkL2,nObHm3uEzJ,GoC84Eq3azJwpSWxkctF1MdTruOIyb in UeurntcIvFJ6bVY[ZvCajmoUedFL]:
				Xao8y1RQZSG = (arsOBITUkup7x3eSfEvM,XyOvPTlmBK4hDVjfi,GUiCEYZjm5,lXBL3WrM2JFYm,kALyrFT6KPNGI7Oiup82Qb4JCq0td,zmL397efNlks5uTEV,NN9niuC7RoqmhkL2,nObHm3uEzJ,GoC84Eq3azJwpSWxkctF1MdTruOIyb)
				if 'صفحة' in XyOvPTlmBK4hDVjfi and arsOBITUkup7x3eSfEvM=='folder': zvEKw9DMPJOoUFdpB[ZvCajmoUedFL].append(Xao8y1RQZSG)
				else: nKEC4U9uBjRe1H[ZvCajmoUedFL].append(Xao8y1RQZSG)
		ULAfj9NzeiqF,xxBPWDU0NoX8rbVfZES3izLs9Kwh = [],[]
		Va0Sd4ATlP1G = list(nKEC4U9uBjRe1H.keys())
		I3ZSjDFpnQsEGYLykt2a1C = XIZRe7uAVJ(Va0Sd4ATlP1G)
		ld8KFtWcr2AnLGJYPsBHQz6 = []
		for ZvCajmoUedFL in I3ZSjDFpnQsEGYLykt2a1C:
			if isinstance(ZvCajmoUedFL,tuple):
				ld8KFtWcr2AnLGJYPsBHQz6 = [ZvCajmoUedFL]
				continue
			if ZvCajmoUedFL not in ssdQe9VYxu0Dg1Nwl7yi84tOrILv: continue
			if nKEC4U9uBjRe1H[ZvCajmoUedFL]:
				K8k5ENeDAZl = oFLajW6gOrufM7I(ZvCajmoUedFL)
				l7Zke8dMpvKYUoRS9hNEsIjA = [('link',s7d549VgeP+'===== '+K8k5ENeDAZl+' ====='+cjqzOQ5GXD4kR,HQmDERMFjx,9999,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx)]
				if 0: eWvmd6nXU9uJ = ixkJ7PTUnZYvOX2WIV+' - '+'بحث'+oQpxmKiRPlHeGsLXNrJF78O+K8k5ENeDAZl
				else: eWvmd6nXU9uJ = 'بحث'+oQpxmKiRPlHeGsLXNrJF78O+K8k5ENeDAZl+' - '+ixkJ7PTUnZYvOX2WIV
				if len(nKEC4U9uBjRe1H[ZvCajmoUedFL])<8: ImXhez83SW5 = []
				else:
					KHeC3IpwSRx2cWU0nOQaN5y8t6Amqu = ao3Q5jP8H0sMxK2iUYwZGE+eWvmd6nXU9uJ+cjqzOQ5GXD4kR
					ImXhez83SW5 = [('folder',WBkbsHztUu4ZEahRYgD5rfQdyNp+KHeC3IpwSRx2cWU0nOQaN5y8t6Amqu,'closed_sites'+QG65xDvLnrhmFb9UaRI7,542,HQmDERMFjx,ZvCajmoUedFL,ixkJ7PTUnZYvOX2WIV,HQmDERMFjx,HQmDERMFjx)]
				c3ejHIGlR18d5zBYs4FaM = nKEC4U9uBjRe1H[ZvCajmoUedFL]+zvEKw9DMPJOoUFdpB[ZvCajmoUedFL]
				B8BWT1tIUngL = ld8KFtWcr2AnLGJYPsBHQz6+l7Zke8dMpvKYUoRS9hNEsIjA+c3ejHIGlR18d5zBYs4FaM[:7]+ImXhez83SW5
				ULAfj9NzeiqF += B8BWT1tIUngL
				c03LuglZPvBe21hI9MDayYt = [('folder',WBkbsHztUu4ZEahRYgD5rfQdyNp+eWvmd6nXU9uJ,'closed_sites'+QG65xDvLnrhmFb9UaRI7,542,HQmDERMFjx,ZvCajmoUedFL,ixkJ7PTUnZYvOX2WIV,HQmDERMFjx,HQmDERMFjx)]
				H3HO817KCxZifAuSbF = ld8KFtWcr2AnLGJYPsBHQz6+c03LuglZPvBe21hI9MDayYt
				xxBPWDU0NoX8rbVfZES3izLs9Kwh += H3HO817KCxZifAuSbF
				HqD3sxo0fJX(rDy4FoKpEOsXfT8WZjli,'GLOBALSEARCH_DIVIDED'+MNCHE4uaIG6J792fDxbQFWgSKZ05Rv,(ZvCajmoUedFL,ixkJ7PTUnZYvOX2WIV),c3ejHIGlR18d5zBYs4FaM,ppxzXEh5md4Dwota3gBQFc)
				ld8KFtWcr2AnLGJYPsBHQz6 = []
		HqD3sxo0fJX(rDy4FoKpEOsXfT8WZjli,'GLOBALSEARCH_DETAILED'+MNCHE4uaIG6J792fDxbQFWgSKZ05Rv,ixkJ7PTUnZYvOX2WIV,ULAfj9NzeiqF,ppxzXEh5md4Dwota3gBQFc)
		X8X1TJW3AmVdy0ZrFvqjDba7Bg2(rDy4FoKpEOsXfT8WZjli,'GLOBALSEARCH_SPLITTED'+MNCHE4uaIG6J792fDxbQFWgSKZ05Rv,ixkJ7PTUnZYvOX2WIV)
		HqD3sxo0fJX(rDy4FoKpEOsXfT8WZjli,'GLOBALSEARCH_SPLITTED'+MNCHE4uaIG6J792fDxbQFWgSKZ05Rv,WBkbsHztUu4ZEahRYgD5rfQdyNp+ixkJ7PTUnZYvOX2WIV,xxBPWDU0NoX8rbVfZES3izLs9Kwh,ppxzXEh5md4Dwota3gBQFc)
		u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,'البحث الجماعي انتهى بنجاح \n\n تم تخزين النتائج في كاش البرنامج لمدة ثلاثين يوم حتى تستطيع العودة إليها بدون عمل بحث جديد')
		pR2xGuf58imZW = xxBPWDU0NoX8rbVfZES3izLs9Kwh if CymIGXMrN9=='listed_sites'+QG65xDvLnrhmFb9UaRI7 and xxBPWDU0NoX8rbVfZES3izLs9Kwh else ULAfj9NzeiqF
	if CymIGXMrN9 in ['listed_sites'+QG65xDvLnrhmFb9UaRI7,'opened_sites'+QG65xDvLnrhmFb9UaRI7,'closed_sites'+QG65xDvLnrhmFb9UaRI7]:
		for arsOBITUkup7x3eSfEvM,XyOvPTlmBK4hDVjfi,GUiCEYZjm5,lXBL3WrM2JFYm,kALyrFT6KPNGI7Oiup82Qb4JCq0td,zmL397efNlks5uTEV,NN9niuC7RoqmhkL2,nObHm3uEzJ,GoC84Eq3azJwpSWxkctF1MdTruOIyb in pR2xGuf58imZW:
			if CymIGXMrN9 in ['listed_sites'+QG65xDvLnrhmFb9UaRI7,'opened_sites'+QG65xDvLnrhmFb9UaRI7] and 'صفحة' in XyOvPTlmBK4hDVjfi and arsOBITUkup7x3eSfEvM=='folder': continue
			CfgK4s13Q0hZcHyleT2bVJO9(arsOBITUkup7x3eSfEvM,XyOvPTlmBK4hDVjfi,GUiCEYZjm5,lXBL3WrM2JFYm,kALyrFT6KPNGI7Oiup82Qb4JCq0td,zmL397efNlks5uTEV,NN9niuC7RoqmhkL2,nObHm3uEzJ,GoC84Eq3azJwpSWxkctF1MdTruOIyb)
	XgW8wuKsyUDpmRQvSV0cNfhxAiFJE(SLgzAKNoYhFUR,SLgzAKNoYhFUR,SLgzAKNoYhFUR)
	return
def zFthePyxOd83o96MVHTl5(search):
	I3ZSjDFpnQsEGYLykt2a1C = XIZRe7uAVJ(FWwniG0Em8kBIT3QV6tKfpa4)
	for ZvCajmoUedFL in I3ZSjDFpnQsEGYLykt2a1C:
		if '-' in ZvCajmoUedFL: continue
		if isinstance(ZvCajmoUedFL,tuple):
			Jzthpc2nj5.menuItemsLIST.append(ZvCajmoUedFL)
			continue
		ddCehb9TygPN5HnMZKBEJA3W42romX,yG0k5pe3mH2,TZRm3tqUKHucWGQ9h08 = h8J6YwoHNtia4LXDVjs0GbW(ZvCajmoUedFL)
		name = oFLajW6gOrufM7I(ZvCajmoUedFL)+' - '+search
		CfgK4s13Q0hZcHyleT2bVJO9('folder',TZRm3tqUKHucWGQ9h08+name,ZvCajmoUedFL,548,'','',search)
	return
def ku2TANEVQDY130jKm(ZvCajmoUedFL,search):
	ddCehb9TygPN5HnMZKBEJA3W42romX,yG0k5pe3mH2,TZRm3tqUKHucWGQ9h08 = h8J6YwoHNtia4LXDVjs0GbW(ZvCajmoUedFL)
	yG0k5pe3mH2(search)
	return
def XX1eyLnvftQ8d0aNwHkcsCJGP4x():
	u0W7PAndK1IXU8rxz2jQaM('','',OO2BXYhI8UPNq6L,'هذا البحث يستخدم محركات البحث الصغيرة الموجودة في كل موقع من مواقع البرنامج .. ونتائج هذا البحث تعتمد على دقة وفعالية وبرمجة كل موقع منها\n\nللأسف هذه المحركات الصغيرة لا تفهم جميع تفاصيل الفيديوهات ولا تفهم طريقة تفكير البشر ولا تستطيع إصلاح الأخطاء الإملائية .. ولهذا هي تحتاج دقة كبيرة جدا في اختيار وكتابة كلمات البحث المناسبة الصحيحة الدقيقة حتى تجد لك طلبك')
	return
def ciLTnJIfRMblwOZUz9uahyBdY(ixkJ7PTUnZYvOX2WIV=HQmDERMFjx):
	f5IwhEVtJQG9pODZAU2RnCx7cd80u,LlsCEXIte1n9TG0BAVOojqyvQkhb5,showDialogs = x0pzMENwy84tBcZvXr(ixkJ7PTUnZYvOX2WIV)
	if not f5IwhEVtJQG9pODZAU2RnCx7cd80u:
		f5IwhEVtJQG9pODZAU2RnCx7cd80u = q156m84QoYrn()
		if not f5IwhEVtJQG9pODZAU2RnCx7cd80u: return
		f5IwhEVtJQG9pODZAU2RnCx7cd80u = f5IwhEVtJQG9pODZAU2RnCx7cd80u.lower()
	vv8DyVrLOPAXFIMZ9h(RRWFdpe04EK1Qn,LLe5QGmjCZigv(HDLtdMAy7wPkl8aKC3O2)+'   Search For: [ '+f5IwhEVtJQG9pODZAU2RnCx7cd80u+' ]')
	q5qfEX4yA6lDop1 = f5IwhEVtJQG9pODZAU2RnCx7cd80u+LlsCEXIte1n9TG0BAVOojqyvQkhb5
	if 0: HxbqiUokgXNs43wc1tlfvjCL6Zz,JNFUAM0L4BQ = f5IwhEVtJQG9pODZAU2RnCx7cd80u+' - ',HQmDERMFjx
	else: HxbqiUokgXNs43wc1tlfvjCL6Zz,JNFUAM0L4BQ = HQmDERMFjx,' - '+f5IwhEVtJQG9pODZAU2RnCx7cd80u
	CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+'مواقع سيرفرات خاصة - قليلة المشاكل'+cjqzOQ5GXD4kR,HQmDERMFjx,157)
	CfgK4s13Q0hZcHyleT2bVJO9('folder','_M3U_'+HxbqiUokgXNs43wc1tlfvjCL6Zz+'بحث M3U'+JNFUAM0L4BQ,HQmDERMFjx,719,HQmDERMFjx,HQmDERMFjx,q5qfEX4yA6lDop1)
	CfgK4s13Q0hZcHyleT2bVJO9('folder','_IPT_'+HxbqiUokgXNs43wc1tlfvjCL6Zz+'بحث IPTV'+JNFUAM0L4BQ,HQmDERMFjx,239,HQmDERMFjx,HQmDERMFjx,q5qfEX4yA6lDop1)
	CfgK4s13Q0hZcHyleT2bVJO9('folder','_BKR_'+HxbqiUokgXNs43wc1tlfvjCL6Zz+'بحث موقع بكرا'+JNFUAM0L4BQ,HQmDERMFjx,379,HQmDERMFjx,HQmDERMFjx,q5qfEX4yA6lDop1)
	CfgK4s13Q0hZcHyleT2bVJO9('folder','_ART_'+HxbqiUokgXNs43wc1tlfvjCL6Zz+'بحث موقع تونز عربية'+JNFUAM0L4BQ,HQmDERMFjx,739,HQmDERMFjx,HQmDERMFjx,q5qfEX4yA6lDop1)
	CfgK4s13Q0hZcHyleT2bVJO9('folder','_KRB_'+HxbqiUokgXNs43wc1tlfvjCL6Zz+'بحث موقع قناة كربلاء'+JNFUAM0L4BQ,HQmDERMFjx,329,HQmDERMFjx,HQmDERMFjx,q5qfEX4yA6lDop1)
	CfgK4s13Q0hZcHyleT2bVJO9('folder','_FH2_'+HxbqiUokgXNs43wc1tlfvjCL6Zz+'بحث موقع فاصل الثاني'+JNFUAM0L4BQ,HQmDERMFjx,599,HQmDERMFjx,HQmDERMFjx,q5qfEX4yA6lDop1)
	CfgK4s13Q0hZcHyleT2bVJO9('folder','_KTV_'+HxbqiUokgXNs43wc1tlfvjCL6Zz+'بحث موقع كتكوت تيفي'+JNFUAM0L4BQ,HQmDERMFjx,819,HQmDERMFjx,HQmDERMFjx,q5qfEX4yA6lDop1)
	CfgK4s13Q0hZcHyleT2bVJO9('folder','_EB1_'+HxbqiUokgXNs43wc1tlfvjCL6Zz+'بحث موقع ايجي بيست 1'+JNFUAM0L4BQ,HQmDERMFjx,779,HQmDERMFjx,HQmDERMFjx,q5qfEX4yA6lDop1)
	CfgK4s13Q0hZcHyleT2bVJO9('folder','_EB2_'+HxbqiUokgXNs43wc1tlfvjCL6Zz+'بحث موقع ايجي بيست 2'+JNFUAM0L4BQ,HQmDERMFjx,789,HQmDERMFjx,HQmDERMFjx,q5qfEX4yA6lDop1)
	CfgK4s13Q0hZcHyleT2bVJO9('folder','_IFL_'+HxbqiUokgXNs43wc1tlfvjCL6Zz+'  بحث موقع قناة آي فيلم'+JNFUAM0L4BQ+MSnXBQNUg1jF3W2fRlE9OLaCT8ds4,HQmDERMFjx,29,HQmDERMFjx,HQmDERMFjx,q5qfEX4yA6lDop1)
	CfgK4s13Q0hZcHyleT2bVJO9('folder','_AKO_'+HxbqiUokgXNs43wc1tlfvjCL6Zz+'بحث موقع أكوام القديم'+JNFUAM0L4BQ,HQmDERMFjx,79,HQmDERMFjx,HQmDERMFjx,q5qfEX4yA6lDop1)
	CfgK4s13Q0hZcHyleT2bVJO9('folder','_AKW_'+HxbqiUokgXNs43wc1tlfvjCL6Zz+'بحث موقع أكوام الجديد'+JNFUAM0L4BQ,HQmDERMFjx,249,HQmDERMFjx,HQmDERMFjx,q5qfEX4yA6lDop1)
	CfgK4s13Q0hZcHyleT2bVJO9('folder','_MRF_'+HxbqiUokgXNs43wc1tlfvjCL6Zz+'بحث موقع قناة المعارف'+JNFUAM0L4BQ,HQmDERMFjx,49,HQmDERMFjx,HQmDERMFjx,q5qfEX4yA6lDop1)
	CfgK4s13Q0hZcHyleT2bVJO9('folder','_SHM_'+HxbqiUokgXNs43wc1tlfvjCL6Zz+'بحث موقع شوف ماكس'+JNFUAM0L4BQ,HQmDERMFjx,59,HQmDERMFjx,HQmDERMFjx,q5qfEX4yA6lDop1)
	CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+'مواقع سيرفرات خاصة وعامة - كثيرة المشاكل'+cjqzOQ5GXD4kR,HQmDERMFjx,157)
	CfgK4s13Q0hZcHyleT2bVJO9('folder','_LRZ_'+HxbqiUokgXNs43wc1tlfvjCL6Zz+'بحث موقع لاروزا'+JNFUAM0L4BQ,HQmDERMFjx,709,HQmDERMFjx,HQmDERMFjx,q5qfEX4yA6lDop1)
	CfgK4s13Q0hZcHyleT2bVJO9('folder','_FJS_'+HxbqiUokgXNs43wc1tlfvjCL6Zz+' بحث موقع فجر شو'+JNFUAM0L4BQ+oQpxmKiRPlHeGsLXNrJF78O,HQmDERMFjx,399,HQmDERMFjx,HQmDERMFjx,q5qfEX4yA6lDop1)
	CfgK4s13Q0hZcHyleT2bVJO9('folder','_TVF_'+HxbqiUokgXNs43wc1tlfvjCL6Zz+'بحث موقع تيفي فان'+JNFUAM0L4BQ,HQmDERMFjx,469,HQmDERMFjx,HQmDERMFjx,q5qfEX4yA6lDop1)
	CfgK4s13Q0hZcHyleT2bVJO9('folder','_LDN_'+HxbqiUokgXNs43wc1tlfvjCL6Zz+'بحث موقع لودي نت'+JNFUAM0L4BQ,HQmDERMFjx,459,HQmDERMFjx,HQmDERMFjx,q5qfEX4yA6lDop1)
	CfgK4s13Q0hZcHyleT2bVJO9('folder','_CMN_'+HxbqiUokgXNs43wc1tlfvjCL6Zz+'بحث موقع سيما ناو'+JNFUAM0L4BQ,HQmDERMFjx,309,HQmDERMFjx,HQmDERMFjx,q5qfEX4yA6lDop1)
	CfgK4s13Q0hZcHyleT2bVJO9('folder','_SHN_'+HxbqiUokgXNs43wc1tlfvjCL6Zz+'بحث موقع شاهد نيوز'+JNFUAM0L4BQ,HQmDERMFjx,589,HQmDERMFjx,HQmDERMFjx,q5qfEX4yA6lDop1+'_NODIALOGS_')
	CfgK4s13Q0hZcHyleT2bVJO9('folder','_ARS_'+HxbqiUokgXNs43wc1tlfvjCL6Zz+'بحث موقع عرب سييد'+JNFUAM0L4BQ,HQmDERMFjx,259,HQmDERMFjx,HQmDERMFjx,q5qfEX4yA6lDop1)
	CfgK4s13Q0hZcHyleT2bVJO9('folder','_CCB_'+HxbqiUokgXNs43wc1tlfvjCL6Zz+'بحث موقع سيما كلوب'+JNFUAM0L4BQ,HQmDERMFjx,829,HQmDERMFjx,HQmDERMFjx,q5qfEX4yA6lDop1)
	CfgK4s13Q0hZcHyleT2bVJO9('folder','_SH4_'+HxbqiUokgXNs43wc1tlfvjCL6Zz+'بحث موقع شاهد فوريو'+JNFUAM0L4BQ,HQmDERMFjx,119,HQmDERMFjx,HQmDERMFjx,q5qfEX4yA6lDop1+'_NODIALOGS_')
	CfgK4s13Q0hZcHyleT2bVJO9('folder','_SHT_'+HxbqiUokgXNs43wc1tlfvjCL6Zz+'بحث موقع شوفها تيفي'+JNFUAM0L4BQ,HQmDERMFjx,649,HQmDERMFjx,HQmDERMFjx,q5qfEX4yA6lDop1)
	CfgK4s13Q0hZcHyleT2bVJO9('folder','_WC1_'+HxbqiUokgXNs43wc1tlfvjCL6Zz+'بحث موقع وي سيما 1'+JNFUAM0L4BQ,HQmDERMFjx,569,HQmDERMFjx,HQmDERMFjx,q5qfEX4yA6lDop1)
	CfgK4s13Q0hZcHyleT2bVJO9('folder','_WC2_'+HxbqiUokgXNs43wc1tlfvjCL6Zz+'بحث موقع وي سيما 2'+JNFUAM0L4BQ,HQmDERMFjx,1009,HQmDERMFjx,HQmDERMFjx,q5qfEX4yA6lDop1)
	CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+'مواقع سيرفرات عامة - كثيرة المشاكل'+cjqzOQ5GXD4kR,HQmDERMFjx,157)
	CfgK4s13Q0hZcHyleT2bVJO9('folder','_TKT_'+HxbqiUokgXNs43wc1tlfvjCL6Zz+'بحث موقع تكات'+JNFUAM0L4BQ,HQmDERMFjx,949,HQmDERMFjx,HQmDERMFjx,q5qfEX4yA6lDop1)
	CfgK4s13Q0hZcHyleT2bVJO9('folder','_FST_'+HxbqiUokgXNs43wc1tlfvjCL6Zz+'بحث موقع فوستا'+JNFUAM0L4BQ,HQmDERMFjx,609,HQmDERMFjx,HQmDERMFjx,q5qfEX4yA6lDop1)
	CfgK4s13Q0hZcHyleT2bVJO9('folder','_FBK_'+HxbqiUokgXNs43wc1tlfvjCL6Zz+'بحث موقع فبركة'+JNFUAM0L4BQ,HQmDERMFjx,629,HQmDERMFjx,HQmDERMFjx,q5qfEX4yA6lDop1)
	CfgK4s13Q0hZcHyleT2bVJO9('folder','_YQT_'+HxbqiUokgXNs43wc1tlfvjCL6Zz+'بحث موقع ياقوت'+JNFUAM0L4BQ,HQmDERMFjx,669,HQmDERMFjx,HQmDERMFjx,q5qfEX4yA6lDop1)
	CfgK4s13Q0hZcHyleT2bVJO9('folder','_SHB_'+HxbqiUokgXNs43wc1tlfvjCL6Zz+'بحث موقع شبكتي'+JNFUAM0L4BQ,HQmDERMFjx,969,HQmDERMFjx,HQmDERMFjx,q5qfEX4yA6lDop1)
	CfgK4s13Q0hZcHyleT2bVJO9('folder','_VRB_'+HxbqiUokgXNs43wc1tlfvjCL6Zz+'بحث موقع فاربون'+JNFUAM0L4BQ,HQmDERMFjx,879,HQmDERMFjx,HQmDERMFjx,q5qfEX4yA6lDop1)
	CfgK4s13Q0hZcHyleT2bVJO9('folder','_BRS_'+HxbqiUokgXNs43wc1tlfvjCL6Zz+'بحث موقع برستيج'+JNFUAM0L4BQ,HQmDERMFjx,659,HQmDERMFjx,HQmDERMFjx,q5qfEX4yA6lDop1)
	CfgK4s13Q0hZcHyleT2bVJO9('folder','_KRM_'+HxbqiUokgXNs43wc1tlfvjCL6Zz+'بحث موقع كرمالك'+JNFUAM0L4BQ,HQmDERMFjx,929,HQmDERMFjx,HQmDERMFjx,q5qfEX4yA6lDop1)
	CfgK4s13Q0hZcHyleT2bVJO9('folder','_ANZ_'+HxbqiUokgXNs43wc1tlfvjCL6Zz+'بحث موقع انمي زد'+JNFUAM0L4BQ,HQmDERMFjx,979,HQmDERMFjx,HQmDERMFjx,q5qfEX4yA6lDop1)
	CfgK4s13Q0hZcHyleT2bVJO9('folder','_FSK_'+HxbqiUokgXNs43wc1tlfvjCL6Zz+'بحث موقع فارسكو'+JNFUAM0L4BQ,HQmDERMFjx,999,HQmDERMFjx,HQmDERMFjx,q5qfEX4yA6lDop1)
	CfgK4s13Q0hZcHyleT2bVJO9('folder','_HLC_'+HxbqiUokgXNs43wc1tlfvjCL6Zz+'بحث موقع هلا سيما'+JNFUAM0L4BQ,HQmDERMFjx,89,HQmDERMFjx,HQmDERMFjx,q5qfEX4yA6lDop1)
	CfgK4s13Q0hZcHyleT2bVJO9('folder','_MST_'+HxbqiUokgXNs43wc1tlfvjCL6Zz+'بحث موقع المصطبة'+JNFUAM0L4BQ,HQmDERMFjx,869,HQmDERMFjx,HQmDERMFjx,q5qfEX4yA6lDop1)
	CfgK4s13Q0hZcHyleT2bVJO9('folder','_SNT_'+HxbqiUokgXNs43wc1tlfvjCL6Zz+'بحث موقع شوف نت'+JNFUAM0L4BQ,HQmDERMFjx,849,HQmDERMFjx,HQmDERMFjx,q5qfEX4yA6lDop1)
	CfgK4s13Q0hZcHyleT2bVJO9('folder','_DR7_'+HxbqiUokgXNs43wc1tlfvjCL6Zz+'بحث موقع دراما صح'+JNFUAM0L4BQ,HQmDERMFjx,689,HQmDERMFjx,HQmDERMFjx,q5qfEX4yA6lDop1)
	CfgK4s13Q0hZcHyleT2bVJO9('folder','_CFR_'+HxbqiUokgXNs43wc1tlfvjCL6Zz+'بحث موقع سيما فري'+JNFUAM0L4BQ,HQmDERMFjx,839,HQmDERMFjx,HQmDERMFjx,q5qfEX4yA6lDop1)
	CfgK4s13Q0hZcHyleT2bVJO9('folder','_CMF_'+HxbqiUokgXNs43wc1tlfvjCL6Zz+'بحث موقع سيما فانز'+JNFUAM0L4BQ,HQmDERMFjx,99,HQmDERMFjx,HQmDERMFjx,q5qfEX4yA6lDop1)
	CfgK4s13Q0hZcHyleT2bVJO9('folder','_CML_'+HxbqiUokgXNs43wc1tlfvjCL6Zz+'بحث موقع سيما لايت'+JNFUAM0L4BQ,HQmDERMFjx,479,HQmDERMFjx,HQmDERMFjx,q5qfEX4yA6lDop1)
	CfgK4s13Q0hZcHyleT2bVJO9('folder','_C4H_'+HxbqiUokgXNs43wc1tlfvjCL6Zz+'بحث موقع سيما 400'+JNFUAM0L4BQ,HQmDERMFjx,699,HQmDERMFjx,HQmDERMFjx,q5qfEX4yA6lDop1)
	CfgK4s13Q0hZcHyleT2bVJO9('folder','_ABD_'+HxbqiUokgXNs43wc1tlfvjCL6Zz+'بحث موقع سيما عبدو'+JNFUAM0L4BQ,HQmDERMFjx,559,HQmDERMFjx,HQmDERMFjx,q5qfEX4yA6lDop1)
	CfgK4s13Q0hZcHyleT2bVJO9('folder','_AKT_'+HxbqiUokgXNs43wc1tlfvjCL6Zz+'بحث موقع اكوام تيوب'+JNFUAM0L4BQ,HQmDERMFjx,859,HQmDERMFjx,HQmDERMFjx,q5qfEX4yA6lDop1)
	CfgK4s13Q0hZcHyleT2bVJO9('folder','_DCF_'+HxbqiUokgXNs43wc1tlfvjCL6Zz+'بحث موقع دراما كافيه'+JNFUAM0L4BQ,HQmDERMFjx,939,HQmDERMFjx,HQmDERMFjx,q5qfEX4yA6lDop1)
	CfgK4s13Q0hZcHyleT2bVJO9('folder','_FTV_'+HxbqiUokgXNs43wc1tlfvjCL6Zz+'بحث موقع فوشار تيفي'+JNFUAM0L4BQ,HQmDERMFjx,919,HQmDERMFjx,HQmDERMFjx,q5qfEX4yA6lDop1)
	CfgK4s13Q0hZcHyleT2bVJO9('folder','_CWB_'+HxbqiUokgXNs43wc1tlfvjCL6Zz+'بحث موقع سيما وبس'+JNFUAM0L4BQ,HQmDERMFjx,989,HQmDERMFjx,HQmDERMFjx,q5qfEX4yA6lDop1)
	CfgK4s13Q0hZcHyleT2bVJO9('folder','_AHK_'+HxbqiUokgXNs43wc1tlfvjCL6Zz+'بحث موقع أهواك تيفي'+JNFUAM0L4BQ,HQmDERMFjx,619,HQmDERMFjx,HQmDERMFjx,q5qfEX4yA6lDop1)
	CfgK4s13Q0hZcHyleT2bVJO9('folder','_SRT_'+HxbqiUokgXNs43wc1tlfvjCL6Zz+'بحث موقع سيريس تايم'+JNFUAM0L4BQ,HQmDERMFjx,899,HQmDERMFjx,HQmDERMFjx,q5qfEX4yA6lDop1)
	CfgK4s13Q0hZcHyleT2bVJO9('folder','_FVD_'+HxbqiUokgXNs43wc1tlfvjCL6Zz+'بحث موقع فوشار فيديو'+JNFUAM0L4BQ,HQmDERMFjx,909,HQmDERMFjx,HQmDERMFjx,q5qfEX4yA6lDop1)
	CfgK4s13Q0hZcHyleT2bVJO9('folder','_C4P_'+HxbqiUokgXNs43wc1tlfvjCL6Zz+'بحث موقع سيما فور بي'+JNFUAM0L4BQ,HQmDERMFjx,889,HQmDERMFjx,HQmDERMFjx,q5qfEX4yA6lDop1)
	CfgK4s13Q0hZcHyleT2bVJO9('folder','_EB4_'+HxbqiUokgXNs43wc1tlfvjCL6Zz+'بحث موقع ايجي بيست 4'+JNFUAM0L4BQ,HQmDERMFjx,809,HQmDERMFjx,HQmDERMFjx,q5qfEX4yA6lDop1)
	CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+'مواقع سيرفرات خاصة - قليلة المشاكل'+cjqzOQ5GXD4kR,HQmDERMFjx,157)
	CfgK4s13Q0hZcHyleT2bVJO9('folder','_YUT_'+HxbqiUokgXNs43wc1tlfvjCL6Zz+'بحث موقع يوتيوب'+JNFUAM0L4BQ,HQmDERMFjx,149,HQmDERMFjx,HQmDERMFjx,q5qfEX4yA6lDop1)
	CfgK4s13Q0hZcHyleT2bVJO9('folder','_DLM_'+HxbqiUokgXNs43wc1tlfvjCL6Zz+'بحث موقع دايلي موشن'+JNFUAM0L4BQ,HQmDERMFjx,409,HQmDERMFjx,HQmDERMFjx,q5qfEX4yA6lDop1)
	return
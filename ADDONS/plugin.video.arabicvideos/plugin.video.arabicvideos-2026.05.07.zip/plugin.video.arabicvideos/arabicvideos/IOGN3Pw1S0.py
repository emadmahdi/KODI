# -*- coding: utf-8 -*-
import sys as TPW58slaVE9OrYQXZnGo2yAfFzpBxc
tbYWAoeMyHTsgFG5x6huz1 = TPW58slaVE9OrYQXZnGo2yAfFzpBxc.version_info [0] == 2
CUJSAbZztE8vYdGByLH0KcnWqe = 2048
R0QCXnpyL1DJwBH67FW = 7
def kSod2AxqugH0 (LURfCucn30xKsMdTiG):
	global ghCyPxkWILcXrGjVut6MQo59fsv
	MfIpC9TDz7Qa5g2vVqPtXh4 = ord (LURfCucn30xKsMdTiG [-1])
	nndScZEtapB74 = LURfCucn30xKsMdTiG [:-1]
	LRbqugZJAa3192OCewWGHvEcP = MfIpC9TDz7Qa5g2vVqPtXh4 % len (nndScZEtapB74)
	qLc7RGgDQE = nndScZEtapB74 [:LRbqugZJAa3192OCewWGHvEcP] + nndScZEtapB74 [LRbqugZJAa3192OCewWGHvEcP:]
	if tbYWAoeMyHTsgFG5x6huz1:
		XUczap3yA0QqFRC82OH6E5mL = unicode () .join ([unichr (ord (ah5u39EBY81MlrwA0cmoz4ngb7TLed) - CUJSAbZztE8vYdGByLH0KcnWqe - (YMjpxPr8WsJ1Bg6Xd + MfIpC9TDz7Qa5g2vVqPtXh4) % R0QCXnpyL1DJwBH67FW) for YMjpxPr8WsJ1Bg6Xd, ah5u39EBY81MlrwA0cmoz4ngb7TLed in enumerate (qLc7RGgDQE)])
	else:
		XUczap3yA0QqFRC82OH6E5mL = str () .join ([chr (ord (ah5u39EBY81MlrwA0cmoz4ngb7TLed) - CUJSAbZztE8vYdGByLH0KcnWqe - (YMjpxPr8WsJ1Bg6Xd + MfIpC9TDz7Qa5g2vVqPtXh4) % R0QCXnpyL1DJwBH67FW) for YMjpxPr8WsJ1Bg6Xd, ah5u39EBY81MlrwA0cmoz4ngb7TLed in enumerate (qLc7RGgDQE)])
	return eval (XUczap3yA0QqFRC82OH6E5mL)
jL1E5AKfwBDv6xmeQtUXcJ3d,JJA7fypmZFVlazvNI,dBi72erQEtKDOwjNFaoAgSP=kSod2AxqugH0,kSod2AxqugH0,kSod2AxqugH0
CDwSWB4v39N7,k4IUieraScH9DV1N7pJgQosYAx5l,Tcf5Ppn9UajDbzyM=dBi72erQEtKDOwjNFaoAgSP,JJA7fypmZFVlazvNI,jL1E5AKfwBDv6xmeQtUXcJ3d
X2crmy67eZpkGTRd,HDpmv4UXzlf72SK9,C3ZK1pu4rfmj8TsWUtBaM=Tcf5Ppn9UajDbzyM,k4IUieraScH9DV1N7pJgQosYAx5l,CDwSWB4v39N7
mg3CbXMA2ouZzQDhRqB,OBsrtQo2pPlgURCxJYbj9iXMD,ssnfOzb16wVog9GKdqcXR3JC7ktSPA=C3ZK1pu4rfmj8TsWUtBaM,HDpmv4UXzlf72SK9,X2crmy67eZpkGTRd
ShnRVsifKtc60zqQ,KKi79PFqsYB0dWSRgaJ3DyE,OzU6t0qcH7MQabeBYK8vgoG=ssnfOzb16wVog9GKdqcXR3JC7ktSPA,OBsrtQo2pPlgURCxJYbj9iXMD,mg3CbXMA2ouZzQDhRqB
mgLADoQ1pbtY,U0VwOviFaYPz2QGs45mJhMXf7Zk,pCTzbw4GyVJHjkcIMQ=OzU6t0qcH7MQabeBYK8vgoG,KKi79PFqsYB0dWSRgaJ3DyE,ShnRVsifKtc60zqQ
owbMhINBQsmx70guApW,SODvU3Ibq5VzC,PPAUFrY8cduRT=pCTzbw4GyVJHjkcIMQ,U0VwOviFaYPz2QGs45mJhMXf7Zk,mgLADoQ1pbtY
knTyjJ0sGIzuwbxRae,nz8x32hX0qcjUPFZk5RdJsiwED,A0aqj9uclgOtByJ6F4bz=PPAUFrY8cduRT,SODvU3Ibq5VzC,owbMhINBQsmx70guApW
YJxaX0MQOHb8oyCBFdnIAe,n6sfYuHBlVdzgmvpXwR3irON0KIj8,LHX65I9nkx0PstgcVY24uSi=A0aqj9uclgOtByJ6F4bz,nz8x32hX0qcjUPFZk5RdJsiwED,knTyjJ0sGIzuwbxRae
EAVanJj1ers2GQud,ELfMeDTIFhJt685K,EF2tvxZHz5n4UruPhaViXKycI6SQR=LHX65I9nkx0PstgcVY24uSi,n6sfYuHBlVdzgmvpXwR3irON0KIj8,YJxaX0MQOHb8oyCBFdnIAe
KhUG1NV9bln5zXjptqFW6dgo,cWbkR6iUZsnJQj14,maUl7SPesynF1j=EF2tvxZHz5n4UruPhaViXKycI6SQR,ELfMeDTIFhJt685K,EAVanJj1ers2GQud
from FF68kA5BUy import *
HDLtdMAy7wPkl8aKC3O2 = EAVanJj1ers2GQud(u"࠭ࡄࡐ࡙ࡑࡐࡔࡇࡄࠨ೧")
def kk6X5LxpsND(lXBL3WrM2JFYm,GUiCEYZjm5):
	if   lXBL3WrM2JFYm==CDwSWB4v39N7(u"࠸࠹࠰൫"): zLZUkrP7ac5 = EKXLu5orZMRk6eylqJab347HCwm()
	elif lXBL3WrM2JFYm==KKi79PFqsYB0dWSRgaJ3DyE(u"࠹࠳࠲൬"): zLZUkrP7ac5 = f0vdEa8oPRTYSesnmNuklQx7I2zXbq(GUiCEYZjm5)
	elif lXBL3WrM2JFYm==cWbkR6iUZsnJQj14(u"࠳࠴࠴൭"): zLZUkrP7ac5 = h71oa2vl05MOHXBSqjnV4yt()
	elif lXBL3WrM2JFYm==A0aqj9uclgOtByJ6F4bz(u"࠴࠵࠶൮"): zLZUkrP7ac5 = cBLbIDmyEVdnlUR()
	else: zLZUkrP7ac5 = mic3MEN709xOkrjD5ZvbGIlX6
	return zLZUkrP7ac5
def f0vdEa8oPRTYSesnmNuklQx7I2zXbq(GUiCEYZjm5):
	uZVS3DcJbEULoxpve9IOTgmW6(GUiCEYZjm5,HDLtdMAy7wPkl8aKC3O2,X2crmy67eZpkGTRd(u"ࠧࡷ࡫ࡧࡩࡴ࠭೨"))
	return
def cBLbIDmyEVdnlUR():
	wwpQTfixYD23X = KKi79PFqsYB0dWSRgaJ3DyE(u"ࠨลำ๋อࠦลๅ๋ࠣีฬฮืࠡษ็ๅ๏ี๊้ࠢฦ์ࠥอไึ๊อࠤๆ๐ࠠศๆ่์็฿ࠠศๆ่฻้๎ศࠡอ่ࠤศ฼ฺุࠢ฼่๎ࠦาาࠢส่็อฦๆหࠣห้๐ๅ๋่ࠣฯ๊ࠦรฯฬสีࠥࠨสฮ็ํ่๋ࠥไโษอࠤๆ๐ฯ๋๊ࠥࠤะ๋ࠠศะอหึࠦฯใหࠣห้฻่าหࠣ์ฬิสศำ๊ࠣํ฿ࠠๆๆไࠤฬ๊ี้ำฬࠤํฮูะ้สࠤุ๎แࠡ์หำศࠦวๅฬะ้๏๊ࠧ೩")
	u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,C3ZK1pu4rfmj8TsWUtBaM(u"ฺࠩี๏่ษࠡฬะ้๏๊ࠠศๆ่่ๆอสࠨ೪"),wwpQTfixYD23X)
	return
def EKXLu5orZMRk6eylqJab347HCwm():
	CfgK4s13Q0hZcHyleT2bVJO9(ShnRVsifKtc60zqQ(u"ࠪࡰ࡮ࡴ࡫ࠨ೫"),OBsrtQo2pPlgURCxJYbj9iXMD(u"ࠫ฼ื๊ใหࠣฮา๋๊ๅ่่ࠢๆอสࠡษ็ๅ๏ี๊้ࠩ೬"),HQmDERMFjx,ELfMeDTIFhJt685K(u"࠵࠶࠷൯"))
	CfgK4s13Q0hZcHyleT2bVJO9(LHX65I9nkx0PstgcVY24uSi(u"ࠬࡲࡩ࡯࡭ࠪ೭"),ShnRVsifKtc60zqQ(u"࠭ส฻์ํี๋ࠥใศ่ࠣฮา๋๊ๅࠢส่ๆ๐ฯ๋๊๊หฯ࠭೮"),HQmDERMFjx,PPAUFrY8cduRT(u"࠶࠷࠷൰"))
	CfgK4s13Q0hZcHyleT2bVJO9(KhUG1NV9bln5zXjptqFW6dgo(u"ࠧ࡭࡫ࡱ࡯ࠬ೯"),ao3Q5jP8H0sMxK2iUYwZGE+cWbkR6iUZsnJQj14(u"ࠨࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦࠧ೰")+cjqzOQ5GXD4kR,HQmDERMFjx,maUl7SPesynF1j(u"࠽࠾࠿࠹൱"))
	aaxXK2Q90p13kEqTbmZlhd5 = k6LlmZy0O7()
	ffRAOuPWQplg = S9Y5kUoRga3EVN.stat(aaxXK2Q90p13kEqTbmZlhd5).st_mtime
	sqfoI1aVJtUi8RnEedA = []
	if HH6mxXjgcrEN1aenMFWQkS: iuLVJtfFBcXC4pPOeSGsx67nvgHEr = S9Y5kUoRga3EVN.listdir(aaxXK2Q90p13kEqTbmZlhd5.encode(Zex6D4tJE52r))
	else: iuLVJtfFBcXC4pPOeSGsx67nvgHEr = S9Y5kUoRga3EVN.listdir(aaxXK2Q90p13kEqTbmZlhd5.decode(Zex6D4tJE52r))
	for J7iFhSAmDr5ZGXb in iuLVJtfFBcXC4pPOeSGsx67nvgHEr:
		if HH6mxXjgcrEN1aenMFWQkS: J7iFhSAmDr5ZGXb = J7iFhSAmDr5ZGXb.decode(Zex6D4tJE52r)
		if not J7iFhSAmDr5ZGXb.startswith(ShnRVsifKtc60zqQ(u"ࠩࡩ࡭ࡱ࡫࡟ࠨೱ")): continue
		mUNDTjq35fJB4zLvp2KZCs = S9Y5kUoRga3EVN.path.join(aaxXK2Q90p13kEqTbmZlhd5,J7iFhSAmDr5ZGXb)
		ffRAOuPWQplg = S9Y5kUoRga3EVN.path.getmtime(mUNDTjq35fJB4zLvp2KZCs)
		sqfoI1aVJtUi8RnEedA.append([J7iFhSAmDr5ZGXb,ffRAOuPWQplg])
	sqfoI1aVJtUi8RnEedA = sorted(sqfoI1aVJtUi8RnEedA,reverse=gyd2rf0UR5,key=lambda key: key[CH7RKuDVzN9f06q8MtXPhlvIxakEWg])
	for J7iFhSAmDr5ZGXb,ffRAOuPWQplg in sqfoI1aVJtUi8RnEedA:
		if C6H1qXua3SMQiIrzxNvJWZE:
			try: J7iFhSAmDr5ZGXb = J7iFhSAmDr5ZGXb.decode(Zex6D4tJE52r)
			except: pass
			J7iFhSAmDr5ZGXb = J7iFhSAmDr5ZGXb.encode(Zex6D4tJE52r)
		mUNDTjq35fJB4zLvp2KZCs = S9Y5kUoRga3EVN.path.join(aaxXK2Q90p13kEqTbmZlhd5,J7iFhSAmDr5ZGXb)
		CfgK4s13Q0hZcHyleT2bVJO9(X2crmy67eZpkGTRd(u"ࠪࡺ࡮ࡪࡥࡰࠩೲ"),J7iFhSAmDr5ZGXb,mUNDTjq35fJB4zLvp2KZCs,dBi72erQEtKDOwjNFaoAgSP(u"࠸࠹࠱൲"))
	return
def k6LlmZy0O7():
	aaxXK2Q90p13kEqTbmZlhd5 = H8jfvMtXa7Neiu.getSetting(U0VwOviFaYPz2QGs45mJhMXf7Zk(u"ࠫࡦࡼ࠮ࡥࡱࡺࡲࡱࡵࡡࡥ࠰ࡳࡥࡹ࡮ࠧೳ"))
	if aaxXK2Q90p13kEqTbmZlhd5: return aaxXK2Q90p13kEqTbmZlhd5
	H8jfvMtXa7Neiu.setSetting(jL1E5AKfwBDv6xmeQtUXcJ3d(u"ࠬࡧࡶ࠯ࡦࡲࡻࡳࡲ࡯ࡢࡦ࠱ࡴࡦࡺࡨࠨ೴"),cZeYBhl0CKsg1EwxAXnRVf427F)
	return cZeYBhl0CKsg1EwxAXnRVf427F
def h71oa2vl05MOHXBSqjnV4yt():
	aaxXK2Q90p13kEqTbmZlhd5 = k6LlmZy0O7()
	i7iy06WB5KMuUkevx2JfjwVGPSd = HUJZy0SrTbBYv1(ShnRVsifKtc60zqQ(u"࠭ࡣࡦࡰࡷࡩࡷ࠭೵"),HQmDERMFjx,HQmDERMFjx,ShnRVsifKtc60zqQ(u"ࠧๆๅส๊ࠥะฮำ์้ࠤ๊๊แศฬࠣห้ะอๆ์็ࠫ೶"),s7d549VgeP+aaxXK2Q90p13kEqTbmZlhd5+cjqzOQ5GXD4kR+nz8x32hX0qcjUPFZk5RdJsiwED(u"ࠨ࡞ࡱࡠࡳํะศ๊ࠢ์๋ࠥใศ่ࠣฮำุ๊็่่ࠢๆอสࠡษ็ๅ๏ี๊้ࠢส่ฯ๐ࠠหฯ่่์อࠠศ่อࠤออำหะาห๊ࠦ็ัษࠣห้ฮั็ษ่ะࠥ࠴่ࠠๆࠣฮึ๐ฯࠡฬ฽๎๏ืࠠศๆ่็ฬ์ࠠภࠩ೷"))
	if i7iy06WB5KMuUkevx2JfjwVGPSd==nz8x32hX0qcjUPFZk5RdJsiwED(u"࠷൳"):
		XX1aC2NizsfwKHvh0uDk = Iwa81pXHmnceuGyF9dq(owbMhINBQsmx70guApW(u"࠳൴"),EAVanJj1ers2GQud(u"่ࠩ็ฬ์ࠠหฯ่๎้ࠦๅๅใสฮࠥอไโ์า๎ํ࠭೸"),OBsrtQo2pPlgURCxJYbj9iXMD(u"ࠪࡰࡴࡩࡡ࡭ࠩ೹"),HQmDERMFjx,mic3MEN709xOkrjD5ZvbGIlX6,gyd2rf0UR5,aaxXK2Q90p13kEqTbmZlhd5)
		N7gs9UBCeDR3 = HUJZy0SrTbBYv1(KKi79PFqsYB0dWSRgaJ3DyE(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ೺"),HQmDERMFjx,HQmDERMFjx,Tcf5Ppn9UajDbzyM(u"๋ࠬใศ่ࠣฮำุ๊็่่ࠢๆอสࠡษ็ฮา๋๊ๅࠩ೻"),s7d549VgeP+aaxXK2Q90p13kEqTbmZlhd5+cjqzOQ5GXD4kR+JJA7fypmZFVlazvNI(u"࠭࡜࡯࡞ࡱ๋ีอ่๊ࠠࠣห้๋ใศ่ࠣห้าฯ๋ั่ࠣฯิา๋่้้ࠣ็วหࠢส่ๆ๐ฯ๋๊ࠣห้ะ๊ࠡฬะ้้ํวࠡษ้ฮࠥฮวิฬัำฬ๋่ࠠาสࠤฬ๊ศา่ส้ัࠦ࠮้ࠡ็ࠤฯื๊ะࠢสืฯิฯศ็๊ࠤอีไศ่๊ࠢࠥอไๆๅส๊ࠥอไใัํ้ࠥลࠧ೼"))
		if N7gs9UBCeDR3==mgLADoQ1pbtY(u"࠲൵"):
			H8jfvMtXa7Neiu.setSetting(EAVanJj1ers2GQud(u"ࠧࡢࡸ࠱ࡨࡴࡽ࡮࡭ࡱࡤࡨ࠳ࡶࡡࡵࡪࠪ೽"),XX1aC2NizsfwKHvh0uDk)
			u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,ELfMeDTIFhJt685K(u"ࠨฬ่ࠤฯเ๊๋ำ้่ࠣอๆࠡฬัึ๏์ࠠศๆ่่ๆอสࠡษ็้า๋ไสࠩ೾"))
	return
def nnWXYbZ1Or9lQtmF8vBLS0K(GUiCEYZjm5,C9xTKEP6NVqbwOLu1GckmS2D58Zls=HQmDERMFjx,website=HQmDERMFjx):
	vv8DyVrLOPAXFIMZ9h(RRWFdpe04EK1Qn,LLe5QGmjCZigv(HDLtdMAy7wPkl8aKC3O2)+dBi72erQEtKDOwjNFaoAgSP(u"ࠩࠣࠤࠥࡖࡲࡦࡲࡤࡶ࡮ࡴࡧࠡࡶࡲࠤࡩࡵࡷ࡯࡮ࡲࡥࡩࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ೿")+GUiCEYZjm5+mgLADoQ1pbtY(u"ࠪࠤࡢ࠭ഀ"))
	if not C9xTKEP6NVqbwOLu1GckmS2D58Zls: C9xTKEP6NVqbwOLu1GckmS2D58Zls = uk3fqJivW6(GUiCEYZjm5)
	aaxXK2Q90p13kEqTbmZlhd5 = k6LlmZy0O7()
	eeC29yfH18kaWPEsqcMARVTiJ = rCt3zFWNQGA1hmbl(mic3MEN709xOkrjD5ZvbGIlX6)
	J7iFhSAmDr5ZGXb = eeC29yfH18kaWPEsqcMARVTiJ.replace(oQpxmKiRPlHeGsLXNrJF78O,C3ZK1pu4rfmj8TsWUtBaM(u"ࠫࡤ࠭ഁ"))
	J7iFhSAmDr5ZGXb = nCu7m5V1eb9Dj8Pyf(J7iFhSAmDr5ZGXb)
	J7iFhSAmDr5ZGXb = ELfMeDTIFhJt685K(u"ࠬ࡬ࡩ࡭ࡧࡢࠫം")+str(int(ggq0fc2wNbkFOzryxdZae))[-jL1E5AKfwBDv6xmeQtUXcJ3d(u"࠶൶"):]+dBi72erQEtKDOwjNFaoAgSP(u"࠭࡟ࠨഃ")+J7iFhSAmDr5ZGXb+C9xTKEP6NVqbwOLu1GckmS2D58Zls
	UIvKkdirJw7jS6XOeAt2Po8NL1HfbE = S9Y5kUoRga3EVN.path.join(aaxXK2Q90p13kEqTbmZlhd5,J7iFhSAmDr5ZGXb)
	WW2BEsh58O = {}
	WW2BEsh58O[ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"ࠧࡂࡥࡦࡩࡵࡺ࠭ࡆࡰࡦࡳࡩ࡯࡮ࡨࠩഄ")] = HQmDERMFjx
	WW2BEsh58O[pCTzbw4GyVJHjkcIMQ(u"ࠨࡃࡦࡧࡪࡶࡴࠨഅ")] = nz8x32hX0qcjUPFZk5RdJsiwED(u"ࠩ࠭࠳࠯࠭ആ")
	GUiCEYZjm5 = GUiCEYZjm5.replace(nz8x32hX0qcjUPFZk5RdJsiwED(u"ࠪࡺࡪࡸࡩࡧࡻࡳࡩࡪࡸ࠽ࡧࡣ࡯ࡷࡪ࠭ഇ"),HQmDERMFjx)
	if C3ZK1pu4rfmj8TsWUtBaM(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴ࠾ࠩഈ") in GUiCEYZjm5:
		SSHjMN4uegZfb2,c0SzxdJ6Mbw9BsLm5O = GUiCEYZjm5.rsplit(LHX65I9nkx0PstgcVY24uSi(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ࠿ࠪഉ"),HDpmv4UXzlf72SK9(u"࠴൷"))
		c0SzxdJ6Mbw9BsLm5O = c0SzxdJ6Mbw9BsLm5O.replace(U0VwOviFaYPz2QGs45mJhMXf7Zk(u"࠭ࡼࠨഊ"),HQmDERMFjx).replace(pCTzbw4GyVJHjkcIMQ(u"ࠧࠧࠩഋ"),HQmDERMFjx)
	else: SSHjMN4uegZfb2,c0SzxdJ6Mbw9BsLm5O = GUiCEYZjm5,None
	if not c0SzxdJ6Mbw9BsLm5O: c0SzxdJ6Mbw9BsLm5O = xK7D9yiBPEqvhmA8XIoJe()
	if c0SzxdJ6Mbw9BsLm5O: WW2BEsh58O[mg3CbXMA2ouZzQDhRqB(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬഌ")] = c0SzxdJ6Mbw9BsLm5O
	if cWbkR6iUZsnJQj14(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࡀࠫ഍") in SSHjMN4uegZfb2: SSHjMN4uegZfb2,dKm1UGJ6eWQ3ita2gYSsf7Np = SSHjMN4uegZfb2.rsplit(JJA7fypmZFVlazvNI(u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࡁࠬഎ"),EF2tvxZHz5n4UruPhaViXKycI6SQR(u"࠵൸"))
	else: SSHjMN4uegZfb2,dKm1UGJ6eWQ3ita2gYSsf7Np = SSHjMN4uegZfb2,HQmDERMFjx
	SSHjMN4uegZfb2 = SSHjMN4uegZfb2.strip(maUl7SPesynF1j(u"ࠫࢁ࠭ഏ")).strip(KhUG1NV9bln5zXjptqFW6dgo(u"ࠬࠬࠧഐ")).strip(knTyjJ0sGIzuwbxRae(u"࠭ࡼࠨ഑")).strip(jL1E5AKfwBDv6xmeQtUXcJ3d(u"ࠧࠧࠩഒ"))
	dKm1UGJ6eWQ3ita2gYSsf7Np = dKm1UGJ6eWQ3ita2gYSsf7Np.replace(ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"ࠨࡾࠪഓ"),HQmDERMFjx).replace(pCTzbw4GyVJHjkcIMQ(u"ࠩࠩࠫഔ"),HQmDERMFjx)
	if dKm1UGJ6eWQ3ita2gYSsf7Np:	WW2BEsh58O[JJA7fypmZFVlazvNI(u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫക")] = dKm1UGJ6eWQ3ita2gYSsf7Np
	vv8DyVrLOPAXFIMZ9h(RRWFdpe04EK1Qn,LLe5QGmjCZigv(HDLtdMAy7wPkl8aKC3O2)+EF2tvxZHz5n4UruPhaViXKycI6SQR(u"ࠫࠥࠦࠠࡅࡱࡺࡲࡱࡵࡡࡥ࡫ࡱ࡫ࠥࡼࡩࡥࡧࡲࠤ࡫࡯࡬ࡦࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬഖ")+SSHjMN4uegZfb2+HDpmv4UXzlf72SK9(u"ࠬࠦ࡝ࠡࠢࠣࡌࡪࡧࡤࡦࡴࡶ࠾ࠥࡡࠠࠨഗ")+str(WW2BEsh58O)+LHX65I9nkx0PstgcVY24uSi(u"࠭ࠠ࡞ࠢࠣࠤࡋ࡯࡬ࡦ࠼ࠣ࡟ࠥ࠭ഘ")+UIvKkdirJw7jS6XOeAt2Po8NL1HfbE+k4IUieraScH9DV1N7pJgQosYAx5l(u"ࠧࠡ࡟ࠪങ"))
	PMaTdFmOBHSCWJsRhy = CDwSWB4v39N7(u"࠶࠶࠲࠵൹")*CDwSWB4v39N7(u"࠶࠶࠲࠵൹")
	TPCRAXj1tNUvnSfkzmsihw2Fub3 = NEVGfakZpwsDMA2()//PMaTdFmOBHSCWJsRhy
	if not TPCRAXj1tNUvnSfkzmsihw2Fub3:
		LQf1jSRk4tA32a(U0VwOviFaYPz2QGs45mJhMXf7Zk(u"ࠨࡴ࡬࡫࡭ࡺࠧച"),X2crmy67eZpkGTRd(u"่ࠩืฬำษࠡษ็ฮำุ๊็่ࠢะ์๎ไสࠩഛ"),cWbkR6iUZsnJQj14(u"่้ࠪษำโࠢส่อืๆศ็ฯࠤ฿๐ัࠡไสำึࠦร็ࠢํัิีࠠๆไาหึࠦๅิษะอࠥอไหะี๎๋ࠦวๅใสี฿ฯࠠโ์ࠣะ์อาไ๋ࠢ฽้๐็ࠡใส๊ࠥะอๆ์็ࠤฬ๊แ๋ัํ์์อสࠡๆ้ࠤ๏฿ๅๅࠢ฼๊ิ้ࠠฦๆ์ࠤศ์๋ࠠไ๋้๋ࠥศา็ฯ๎ࠥฮั็ษ่ะ้่ࠥะ์ࠣฬา๊่ࠠา๊ࠤฬ๊ๅีๅ็อ๊ࠥว็ࠢอั๊๐ไࠡษ็ๅ๏ี๊้้สฮ่ࠥฯࠡ์ึฬอࠦวๆฬ็หฦࠦฬ่ษี็ࠥฮวๅ็็ๅฬะ้้ࠠำหࠥ็๊่ࠢั฻ํืษࠡ฻็ํࠥ฿ๅๅࠢฯ๋ฬุใࠡสุ์ึฯࠠึฯํัฮ่ࠦๅ้ำหࠥอไิสหࠤ็อๅࠡษ็้อืๅอ่ࠢศ็ะวࠡส่๊฾ࠦวๅสิ๊ฬ๋ฬࠡ็้ࠤฯำๅ๋ๆࠣห้็๊ะ์๋๋ฬะࠧജ"),A0aqj9uclgOtByJ6F4bz(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧഝ"))
		vv8DyVrLOPAXFIMZ9h(GmyBXr3kYHdlvJ,LLe5QGmjCZigv(HDLtdMAy7wPkl8aKC3O2)+Tcf5Ppn9UajDbzyM(u"ࠬࠦࠠࠡࡗࡱࡥࡧࡲࡥࠡࡶࡲࠤࡩ࡫ࡴࡦࡴࡰ࡭ࡳ࡫ࠠࡵࡪࡨࠤࡩ࡯ࡳ࡬ࠢࡩࡶࡪ࡫ࠠࡴࡲࡤࡧࡪ࠭ഞ"))
		return mic3MEN709xOkrjD5ZvbGIlX6
	if C9xTKEP6NVqbwOLu1GckmS2D58Zls==A0aqj9uclgOtByJ6F4bz(u"࠭࠮࡮࠵ࡸ࠼ࠬട"):
		gBzGTxKMSVWFLPvfAI0UZ98D5,Na8vklCpUGYIzP0bjutWOT = OjH71iMvK3JXoyqGVuCbIhR(HDLtdMAy7wPkl8aKC3O2,SSHjMN4uegZfb2,WW2BEsh58O)
		if len(gBzGTxKMSVWFLPvfAI0UZ98D5)==OzU6t0qcH7MQabeBYK8vgoG(u"࠶ൺ"):
			x8a2FGB1jAef94byI(maUl7SPesynF1j(u"ࠧโึ็ࠤๆ๐ࠠฦ์ฯหิࠦๅๅใࠣห้ะอๆ์็ࠫഠ"),HQmDERMFjx)
			return mic3MEN709xOkrjD5ZvbGIlX6
		elif len(gBzGTxKMSVWFLPvfAI0UZ98D5)==X2crmy67eZpkGTRd(u"࠱ൻ"): lwT9cdaH5AxMU8IpZif20jPX = maUl7SPesynF1j(u"࠱ർ")
		elif len(gBzGTxKMSVWFLPvfAI0UZ98D5)>ShnRVsifKtc60zqQ(u"࠳ൽ"):
			lwT9cdaH5AxMU8IpZif20jPX = GGiSlWbqKDr5Ovkh2L7sHNTxz(nz8x32hX0qcjUPFZk5RdJsiwED(u"ࠨษัฮึࠦวๅ็็ๅࠥอไๆ่สือ࠭ഡ"), gBzGTxKMSVWFLPvfAI0UZ98D5)
			if lwT9cdaH5AxMU8IpZif20jPX == -ELfMeDTIFhJt685K(u"࠴ൾ") :
				x8a2FGB1jAef94byI(pCTzbw4GyVJHjkcIMQ(u"ࠩอ้ࠥหไ฻ษฤࠤฬ๊สฮ็ํ่ࠬഢ"),HQmDERMFjx)
				return mic3MEN709xOkrjD5ZvbGIlX6
		SSHjMN4uegZfb2 = Na8vklCpUGYIzP0bjutWOT[lwT9cdaH5AxMU8IpZif20jPX]
	fJN6A4SrxMkIlZ = YJxaX0MQOHb8oyCBFdnIAe(u"࠴ൿ")
	import requests as JJOvzYyVTMBF
	if C9xTKEP6NVqbwOLu1GckmS2D58Zls==C3ZK1pu4rfmj8TsWUtBaM(u"ࠪ࠲ࡲ࠹ࡵ࠹ࠩണ"):
		UIvKkdirJw7jS6XOeAt2Po8NL1HfbE = UIvKkdirJw7jS6XOeAt2Po8NL1HfbE.rsplit(OzU6t0qcH7MQabeBYK8vgoG(u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪത"))[o4bNzIQGYj8En]+KhUG1NV9bln5zXjptqFW6dgo(u"ࠬ࠴࡭ࡱ࠶ࠪഥ")
		Pmwd7O4bJj82oUSYiBR1hrEkNstXlK = U3GBj7agXTD1Lwze5SvO0H(LLwINhcX2RHSWqpmEnz,OzU6t0qcH7MQabeBYK8vgoG(u"࠭ࡇࡆࡖࠪദ"),SSHjMN4uegZfb2,HQmDERMFjx,WW2BEsh58O,HQmDERMFjx,HQmDERMFjx,YJxaX0MQOHb8oyCBFdnIAe(u"ࠧࡅࡑ࡚ࡒࡑࡕࡁࡅ࠯ࡇࡓ࡜ࡔࡌࡐࡃࡇࡣ࡛ࡏࡄࡆࡑ࠰࠵ࡸࡺࠧധ"))
		e03SCyR6svHWPtoc = Pmwd7O4bJj82oUSYiBR1hrEkNstXlK.content
		jzTLleJs8x9Hb1 = DyVGS3dX0ZxR.findall(knTyjJ0sGIzuwbxRae(u"ࠨࠥࡈ࡜࡙ࡏࡎࡇ࠼࠱࠮ࡄࡡ࡜࡯࡞ࡵࡡ࠭࠴ࠪࡀࠫ࡞ࡠࡳࡢࡲ࡞ࠩന"),e03SCyR6svHWPtoc+maUl7SPesynF1j(u"ࠩ࡟ࡲࡡࡸࠧഩ"),DyVGS3dX0ZxR.DOTALL)
		if not jzTLleJs8x9Hb1:
			vv8DyVrLOPAXFIMZ9h(GmyBXr3kYHdlvJ,LLe5QGmjCZigv(HDLtdMAy7wPkl8aKC3O2)+LHX65I9nkx0PstgcVY24uSi(u"ࠪࠤࠥࠦࡔࡩࡧࠣࡱ࠸ࡻ࠸ࠡࡨ࡬ࡰࡪࠦࡤࡪࡦࠣࡲࡴࡺࠠࡩࡣࡹࡩࠥࡺࡨࡦࠢࡵࡩࡶࡻࡩࡳࡧࡧࠤࡱ࡯࡮࡬ࡵࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭പ")+SSHjMN4uegZfb2+knTyjJ0sGIzuwbxRae(u"ࠫࠥࡣࠧഫ"))
			return mic3MEN709xOkrjD5ZvbGIlX6
		vn1grP3y4It9GmVuBbLJfz2A = jzTLleJs8x9Hb1[o4bNzIQGYj8En]
		if not vn1grP3y4It9GmVuBbLJfz2A.startswith(ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"ࠬ࡮ࡴࡵࡲࠪബ")):
			if vn1grP3y4It9GmVuBbLJfz2A.startswith(mKqAOsD5p0C): vn1grP3y4It9GmVuBbLJfz2A = SSHjMN4uegZfb2.split(JJA7fypmZFVlazvNI(u"࠭࠺ࠨഭ"),LHX65I9nkx0PstgcVY24uSi(u"࠶඀"))[o4bNzIQGYj8En]+LHX65I9nkx0PstgcVY24uSi(u"ࠧ࠻ࠩമ")+vn1grP3y4It9GmVuBbLJfz2A
			elif vn1grP3y4It9GmVuBbLJfz2A.startswith(xufJqQcGnhboiVy2wd): vn1grP3y4It9GmVuBbLJfz2A = DpClq35GVjh(SSHjMN4uegZfb2,KhUG1NV9bln5zXjptqFW6dgo(u"ࠨࡷࡵࡰࠬയ"))+vn1grP3y4It9GmVuBbLJfz2A
			else: vn1grP3y4It9GmVuBbLJfz2A = SSHjMN4uegZfb2.rsplit(xufJqQcGnhboiVy2wd,C3ZK1pu4rfmj8TsWUtBaM(u"࠷ඁ"))[o4bNzIQGYj8En]+xufJqQcGnhboiVy2wd+vn1grP3y4It9GmVuBbLJfz2A
		Pmwd7O4bJj82oUSYiBR1hrEkNstXlK = JJOvzYyVTMBF.request(U0VwOviFaYPz2QGs45mJhMXf7Zk(u"ࠩࡊࡉ࡙࠭ര"),vn1grP3y4It9GmVuBbLJfz2A,headers=WW2BEsh58O,verify=mic3MEN709xOkrjD5ZvbGIlX6)
		J2ty4PSfup8A = Pmwd7O4bJj82oUSYiBR1hrEkNstXlK.content
		eeEW6p3MbIaN2YFSO = len(J2ty4PSfup8A)
		QSKyrLMqWHVFIieacNgfxAzvh5RuOZ = len(jzTLleJs8x9Hb1)
		fJN6A4SrxMkIlZ = eeEW6p3MbIaN2YFSO*QSKyrLMqWHVFIieacNgfxAzvh5RuOZ
	else:
		eeEW6p3MbIaN2YFSO = maUl7SPesynF1j(u"࠱ං")*PMaTdFmOBHSCWJsRhy
		Pmwd7O4bJj82oUSYiBR1hrEkNstXlK = JJOvzYyVTMBF.request(JJA7fypmZFVlazvNI(u"ࠪࡋࡊ࡚ࠧറ"),SSHjMN4uegZfb2,headers=WW2BEsh58O,verify=mic3MEN709xOkrjD5ZvbGIlX6,stream=gyd2rf0UR5)
		if EF2tvxZHz5n4UruPhaViXKycI6SQR(u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲ࡒࡥ࡯ࡩࡷ࡬ࠬല") in Pmwd7O4bJj82oUSYiBR1hrEkNstXlK.headers: fJN6A4SrxMkIlZ = int(Pmwd7O4bJj82oUSYiBR1hrEkNstXlK.headers[EF2tvxZHz5n4UruPhaViXKycI6SQR(u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡌࡦࡰࡪࡸ࡭࠭ള")])
		QSKyrLMqWHVFIieacNgfxAzvh5RuOZ = int(fJN6A4SrxMkIlZ//eeEW6p3MbIaN2YFSO)
	f8VldUL9Kg2zo06 = int(fJN6A4SrxMkIlZ//PMaTdFmOBHSCWJsRhy)+dBi72erQEtKDOwjNFaoAgSP(u"࠲ඃ")
	if fJN6A4SrxMkIlZ<nz8x32hX0qcjUPFZk5RdJsiwED(u"࠴࠴࠴࠵࠶඄"):
		vv8DyVrLOPAXFIMZ9h(GmyBXr3kYHdlvJ,LLe5QGmjCZigv(HDLtdMAy7wPkl8aKC3O2)+JJA7fypmZFVlazvNI(u"࡙࠭ࠠࠡࠢ࡭ࡩ࡫࡯ࠡࡨ࡬ࡰࡪࠦࡩࡴࠢࡷࡳࡴࠦࡳ࡮ࡣ࡯ࡰࠥࡵࡲࠡ࡫ࡷࠤ࡮ࡹࠠ࡮࠵ࡸ࠼ࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨഴ")+SSHjMN4uegZfb2+YJxaX0MQOHb8oyCBFdnIAe(u"ࠧࠡ࡟ࠣࠤࠥ࡜ࡩࡥࡧࡲࠤ࡫࡯࡬ࡦࠢࡶ࡭ࡿ࡫࠺ࠡ࡝ࠣࠫവ")+str(f8VldUL9Kg2zo06)+LHX65I9nkx0PstgcVY24uSi(u"ࠨࠢࡐࡆࠥࡣࠠࠡࠢࡄࡺࡦ࡯࡬ࡢࡤ࡯ࡩࠥࡹࡩࡻࡧ࠽ࠤࡠࠦࠧശ")+str(TPCRAXj1tNUvnSfkzmsihw2Fub3)+EAVanJj1ers2GQud(u"ࠩࠣࡑࡇࠦ࡝ࠡࠢࠣࡊ࡮ࡲࡥ࠻ࠢ࡞ࠤࠬഷ")+UIvKkdirJw7jS6XOeAt2Po8NL1HfbE+pCTzbw4GyVJHjkcIMQ(u"ࠪࠤࡢ࠭സ"))
		u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,EAVanJj1ers2GQud(u"ࠫๆฺไࠡใํࠤ๊฿ัโหࠣัั๋ࠠๆๆไࠤฬ๊แ๋ัํ์ࠥษ่ࠡษ็้้็ࠠึ฼ํีࠥาฯศ๋่ࠢ์ึวࠡๆสࠤ๏๋ใ็ࠢ็่อืๆศ็ฯࠤฯำๅ๋ๆ๋ࠣีอࠠศๆ่่ๆ࠭ഹ"))
		return mic3MEN709xOkrjD5ZvbGIlX6
	hZkl0KbiSBfgA = KKi79PFqsYB0dWSRgaJ3DyE(u"࠷࠴࠵අ")
	G2YbsgXzQxV4vZnkaLWdO8q6rfcEw = TPCRAXj1tNUvnSfkzmsihw2Fub3-f8VldUL9Kg2zo06
	if G2YbsgXzQxV4vZnkaLWdO8q6rfcEw<hZkl0KbiSBfgA:
		vv8DyVrLOPAXFIMZ9h(GmyBXr3kYHdlvJ,LLe5QGmjCZigv(HDLtdMAy7wPkl8aKC3O2)+YJxaX0MQOHb8oyCBFdnIAe(u"ࠬࠦࠠࠡࡐࡲࡸࠥ࡫࡮ࡰࡷࡪ࡬ࠥࡪࡩࡴ࡭ࠣࡷࡵࡧࡣࡦࠢࡷࡳࠥࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠠࡵࡪࡨࠤࡻ࡯ࡤࡦࡱࠣࡪ࡮ࡲࡥ࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫഺ")+SSHjMN4uegZfb2+ELfMeDTIFhJt685K(u"࠭ࠠ࡞ࠢࠣࠤ࡛࡯ࡤࡦࡱࠣࡪ࡮ࡲࡥࠡࡵ࡬ࡾࡪࡀࠠ࡜഻ࠢࠪ")+str(f8VldUL9Kg2zo06)+mgLADoQ1pbtY(u"ࠧࠡࡏࡅࠤࡢࠦࠠࠡࡃࡹࡥ࡮ࡲࡡࡣ࡮ࡨࠤࡸ࡯ࡺࡦ࠼ࠣ࡟഼ࠥ࠭")+str(TPCRAXj1tNUvnSfkzmsihw2Fub3)+nz8x32hX0qcjUPFZk5RdJsiwED(u"ࠨࠢࡐࡆࠥ࠳ࠠࠨഽ")+str(hZkl0KbiSBfgA)+LHX65I9nkx0PstgcVY24uSi(u"ࠩࠣࡑࡇࠦ࡝ࠡࠢࠣࡊ࡮ࡲࡥ࠻ࠢ࡞ࠤࠬാ")+UIvKkdirJw7jS6XOeAt2Po8NL1HfbE+mg3CbXMA2ouZzQDhRqB(u"ࠪࠤࡢ࠭ി"))
		u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,U0VwOviFaYPz2QGs45mJhMXf7Zk(u"้ࠫอ๋๊ࠠฯำ๋ࠥำศฯฬࠤ่อแ๋ห่้ࠣะอๆ์็ࠫീ"),Tcf5Ppn9UajDbzyM(u"ࠬอไๆๆไࠤฬ๊ๅุๆ๋ฬࠥะอๆ์็๋ࠥำฬๆ้ࠣࠫു")+str(f8VldUL9Kg2zo06)+LHX65I9nkx0PstgcVY24uSi(u"࠭ࠠๆ์฽หออ๊ห๋ࠢะ์อาไࠢไ๎์ࠦๅิษะอࠥ็วา฼ฬࠤࠬൂ")+str(TPCRAXj1tNUvnSfkzmsihw2Fub3)+JJA7fypmZFVlazvNI(u"ࠧࠡ็ํ฾ฬฮว๋ฬࠣ์้๊ๅฮษไ฼ฮูࠦๅ๋ࠣ฽๊๊ࠠอ้สึ่ࠦศะ๊้ࠤฺ๊วไๆࠣ๎ัฮࠠฦสๅหฦࠦࠧൃ")+str(hZkl0KbiSBfgA)+dBi72erQEtKDOwjNFaoAgSP(u"ࠨ่ࠢ๎฿อศศ์อࠤๆอั฻หࠣำฬฬๅศ๋๋ࠢีอࠠๆ฻้ห์ࠦร็ࠢฯ๋ฬุใࠡๆสࠤฯ๎ฬะࠢไ๎์ࠦๅิษะอ้ࠥวโ์ฬࠤ้ะอๆ์็ࠤ๊๊แࠡษ็ๅ๏ี๊้ࠢส่๊฽ไ้สࠪൄ"))
		return mic3MEN709xOkrjD5ZvbGIlX6
	N7gs9UBCeDR3 = HUJZy0SrTbBYv1(EAVanJj1ers2GQud(u"ࠩࡦࡩࡳࡺࡥࡳࠩ൅"),HQmDERMFjx,HQmDERMFjx,pCTzbw4GyVJHjkcIMQ(u"๋้ࠪࠦสา์าࠤฯำๅ๋ๆࠣห้๋ไโࠢยࠫെ"),C3ZK1pu4rfmj8TsWUtBaM(u"ࠫฬ๊ๅๅใࠣห้๋ืๅ๊หࠤาาๅ่ࠢอๆึ๐ศศࠢࠪേ")+str(f8VldUL9Kg2zo06)+ShnRVsifKtc60zqQ(u"ࠬࠦๅ๋฼สฬฬ๐ส๊ࠡฯ๋ฬุใࠡใํ๋๋ࠥำศฯฬࠤๆอั฻หࠣฮ็ื๊ษษࠣࠫൈ")+str(TPCRAXj1tNUvnSfkzmsihw2Fub3)+PPAUFrY8cduRT(u"࠭ࠠๆ์฽หออ๊ห๋๋ࠢีอࠠศๆ่่ๆࠦโะࠢํัฯอฬࠡส฼ฺࠥอไ้ไอࠤ้๊สฮ็ํ่๋ࠥๆࠡษ็ษ๋ะั็ฬࠣษ้๏ࠠอ้สึ่ࠦ࠮้ࠡ็ࠤฬ์สࠡ็อว่ี้ࠠฬิ๎ิࠦวๅษึฮ๊ืวาࠢหฮา๋๊ๅ่่ࠢๆࠦวๅใํำ๏๎ࠠภࠩ൉"))
	if N7gs9UBCeDR3!=X2crmy67eZpkGTRd(u"࠵ආ"):
		u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,knTyjJ0sGIzuwbxRae(u"ࠧห็ࠣษ้เวยࠢ฼้้๐ษࠡฬะ้๏๊ࠠๆๆไࠤฬ๊แ๋ัํ์ࠬൊ"))
		vv8DyVrLOPAXFIMZ9h(RRWFdpe04EK1Qn,LLe5QGmjCZigv(HDLtdMAy7wPkl8aKC3O2)+knTyjJ0sGIzuwbxRae(u"ࠨࠢࠣࠤ࡚ࡹࡥࡳࠢࡦࡥࡳࡩࡥ࡭ࡧࡧࠤࡹ࡮ࡥࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࠣࡳ࡫ࠦࡴࡩࡧࠣࡺ࡮ࡪࡥࡰࠢࡩ࡭ࡱ࡫ࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪോ")+SSHjMN4uegZfb2+SODvU3Ibq5VzC(u"ࠩࠣࡡࠥࠦࠠࡇ࡫࡯ࡩ࠿࡛ࠦࠡࠩൌ")+UIvKkdirJw7jS6XOeAt2Po8NL1HfbE+pCTzbw4GyVJHjkcIMQ(u"ࠪࠤࡢ്࠭"))
		return mic3MEN709xOkrjD5ZvbGIlX6
	vv8DyVrLOPAXFIMZ9h(RRWFdpe04EK1Qn,LLe5QGmjCZigv(HDLtdMAy7wPkl8aKC3O2)+OBsrtQo2pPlgURCxJYbj9iXMD(u"ࠫࠥࠦࠠࡅࡱࡺࡲࡱࡵࡡࡥࠢࡶࡸࡦࡸࡴࡦࡦࠣࡷࡺࡩࡣࡦࡵࡶࡪࡺࡲ࡬ࡺࠩൎ"))
	fHFmBo6bzTsC = uu2bfv7V3FS()
	fHFmBo6bzTsC.create(UIvKkdirJw7jS6XOeAt2Po8NL1HfbE,Tcf5Ppn9UajDbzyM(u"ࠬอไิูิࠤๆ๎โ้๋ࠡࠤ๊้ว็ࠢอาื๐ๆࠡ็็ๅࠥอไโ์า๎ํ࠭൏"))
	uC0Utqej2zRHxP7 = gyd2rf0UR5
	RxlF2vgU3cdnk8 = jHWkt18govGwY7iUbduAfxCyRc.time()
	if not Jzthpc2nj5.rE7CO4gbqvZWSU3L:
		u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,mg3CbXMA2ouZzQDhRqB(u"࠭ศิสหࠤ฾ีๅࠡษ็ฮอืูࠡฬ่ࠤสฺ๊ศรࠣฮา๋๊ๅ่่ࠢๆࠦวๅใํำ๏๎ࠧ൐"))
		return mic3MEN709xOkrjD5ZvbGIlX6
	if HH6mxXjgcrEN1aenMFWQkS: pb7tsOhkEPVZvD0iB61JfSdcIlFoQx = open(UIvKkdirJw7jS6XOeAt2Po8NL1HfbE,SODvU3Ibq5VzC(u"ࠧࡸࡤࠪ൑"))
	else: pb7tsOhkEPVZvD0iB61JfSdcIlFoQx = open(UIvKkdirJw7jS6XOeAt2Po8NL1HfbE.decode(Zex6D4tJE52r),pCTzbw4GyVJHjkcIMQ(u"ࠨࡹࡥࠫ൒"))
	if C9xTKEP6NVqbwOLu1GckmS2D58Zls==mgLADoQ1pbtY(u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨ൓"):
		for DvGaoUZE5S4wxfHc910sz in range(SODvU3Ibq5VzC(u"࠶ඇ"),QSKyrLMqWHVFIieacNgfxAzvh5RuOZ+SODvU3Ibq5VzC(u"࠶ඇ")):
			vn1grP3y4It9GmVuBbLJfz2A = jzTLleJs8x9Hb1[DvGaoUZE5S4wxfHc910sz-k4IUieraScH9DV1N7pJgQosYAx5l(u"࠷ඈ")]
			if not vn1grP3y4It9GmVuBbLJfz2A.startswith(jL1E5AKfwBDv6xmeQtUXcJ3d(u"ࠪ࡬ࡹࡺࡰࠨൔ")):
				if vn1grP3y4It9GmVuBbLJfz2A.startswith(mKqAOsD5p0C): vn1grP3y4It9GmVuBbLJfz2A = SSHjMN4uegZfb2.split(C3ZK1pu4rfmj8TsWUtBaM(u"ࠫ࠿࠭ൕ"),JJA7fypmZFVlazvNI(u"࠱ඉ"))[o4bNzIQGYj8En]+ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"ࠬࡀࠧൖ")+vn1grP3y4It9GmVuBbLJfz2A
				elif vn1grP3y4It9GmVuBbLJfz2A.startswith(xufJqQcGnhboiVy2wd): vn1grP3y4It9GmVuBbLJfz2A = DpClq35GVjh(SSHjMN4uegZfb2,Tcf5Ppn9UajDbzyM(u"࠭ࡵࡳ࡮ࠪൗ"))+vn1grP3y4It9GmVuBbLJfz2A
				else: vn1grP3y4It9GmVuBbLJfz2A = SSHjMN4uegZfb2.rsplit(xufJqQcGnhboiVy2wd,nz8x32hX0qcjUPFZk5RdJsiwED(u"࠲ඊ"))[o4bNzIQGYj8En]+xufJqQcGnhboiVy2wd+vn1grP3y4It9GmVuBbLJfz2A
			Pmwd7O4bJj82oUSYiBR1hrEkNstXlK = JJOvzYyVTMBF.request(PPAUFrY8cduRT(u"ࠧࡈࡇࡗࠫ൘"),vn1grP3y4It9GmVuBbLJfz2A,headers=WW2BEsh58O,verify=mic3MEN709xOkrjD5ZvbGIlX6)
			J2ty4PSfup8A = Pmwd7O4bJj82oUSYiBR1hrEkNstXlK.content
			Pmwd7O4bJj82oUSYiBR1hrEkNstXlK.close()
			pb7tsOhkEPVZvD0iB61JfSdcIlFoQx.write(J2ty4PSfup8A)
			skp74G2v35UrPOEbMWgxFthj = jHWkt18govGwY7iUbduAfxCyRc.time()
			vW8rtXZTeNAPI4Yx = skp74G2v35UrPOEbMWgxFthj-RxlF2vgU3cdnk8
			Owgm3FjloaxKRfECVzr7DkpJMbG = vW8rtXZTeNAPI4Yx//DvGaoUZE5S4wxfHc910sz
			Cy5AvNPJ1cKLk6lg9thZSe = Owgm3FjloaxKRfECVzr7DkpJMbG*(QSKyrLMqWHVFIieacNgfxAzvh5RuOZ+KhUG1NV9bln5zXjptqFW6dgo(u"࠳උ"))
			qq5jASaIQ1leOE = Cy5AvNPJ1cKLk6lg9thZSe-vW8rtXZTeNAPI4Yx
			BwPd4IbMUKZEWAHo0ug8pn(fHFmBo6bzTsC,int(JJA7fypmZFVlazvNI(u"࠵࠵࠶ඍ")*DvGaoUZE5S4wxfHc910sz//(QSKyrLMqWHVFIieacNgfxAzvh5RuOZ+X2crmy67eZpkGTRd(u"࠴ඌ"))),dBi72erQEtKDOwjNFaoAgSP(u"ࠨษ็ื฼ืࠠโ๊ๅࠤ์๎ࠠๆๅส๊ࠥะฮำ์้ࠤ๊๊แࠡษ็ๅ๏ี๊้ࠩ൙"),dBi72erQEtKDOwjNFaoAgSP(u"ࠩฯ่อࠦๅๅใࠣห้็๊ะ์๋࠾࠲ࠦวๅฮีลࠥืโๆࠩ൚"),str(DvGaoUZE5S4wxfHc910sz*eeEW6p3MbIaN2YFSO//PMaTdFmOBHSCWJsRhy)+xufJqQcGnhboiVy2wd+str(f8VldUL9Kg2zo06)+PPAUFrY8cduRT(u"ࠪࠤࡒࡈࠠࠡࠢࠣ์็ะࠠๆฬหๆ๏ࡀࠠࠨ൛")+jHWkt18govGwY7iUbduAfxCyRc.strftime(PPAUFrY8cduRT(u"ࠦࠪࡎ࠺ࠦࡏ࠽ࠩࡘࠨ൜"),jHWkt18govGwY7iUbduAfxCyRc.gmtime(qq5jASaIQ1leOE))+EF2tvxZHz5n4UruPhaViXKycI6SQR(u"ࠬࠦเࠨ൝"))
			if fHFmBo6bzTsC.iscanceled():
				uC0Utqej2zRHxP7 = mic3MEN709xOkrjD5ZvbGIlX6
				break
	else:
		DvGaoUZE5S4wxfHc910sz = mgLADoQ1pbtY(u"࠵ඎ")
		for J2ty4PSfup8A in Pmwd7O4bJj82oUSYiBR1hrEkNstXlK.iter_content(chunk_size=eeEW6p3MbIaN2YFSO):
			pb7tsOhkEPVZvD0iB61JfSdcIlFoQx.write(J2ty4PSfup8A)
			DvGaoUZE5S4wxfHc910sz = DvGaoUZE5S4wxfHc910sz+JJA7fypmZFVlazvNI(u"࠷ඏ")
			skp74G2v35UrPOEbMWgxFthj = jHWkt18govGwY7iUbduAfxCyRc.time()
			vW8rtXZTeNAPI4Yx = skp74G2v35UrPOEbMWgxFthj-RxlF2vgU3cdnk8
			Owgm3FjloaxKRfECVzr7DkpJMbG = vW8rtXZTeNAPI4Yx/DvGaoUZE5S4wxfHc910sz
			Cy5AvNPJ1cKLk6lg9thZSe = Owgm3FjloaxKRfECVzr7DkpJMbG*(QSKyrLMqWHVFIieacNgfxAzvh5RuOZ+ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"࠱ඐ"))
			qq5jASaIQ1leOE = Cy5AvNPJ1cKLk6lg9thZSe-vW8rtXZTeNAPI4Yx
			BwPd4IbMUKZEWAHo0ug8pn(fHFmBo6bzTsC,int(nz8x32hX0qcjUPFZk5RdJsiwED(u"࠳࠳࠴ඒ")*DvGaoUZE5S4wxfHc910sz/(QSKyrLMqWHVFIieacNgfxAzvh5RuOZ+ShnRVsifKtc60zqQ(u"࠲එ"))),PPAUFrY8cduRT(u"࠭วๅีฺีࠥ็่ใ๊ࠢ์๋ࠥใศ่ࠣฮำุ๊็่่ࠢๆࠦวๅใํำ๏๎ࠧ൞"),X2crmy67eZpkGTRd(u"ࠧอๆหࠤ๊๊แࠡษ็ๅ๏ี๊้࠼࠰ࠤฬ๊ฬำรࠣี็๋ࠧൟ"),str(DvGaoUZE5S4wxfHc910sz*eeEW6p3MbIaN2YFSO//PMaTdFmOBHSCWJsRhy)+xufJqQcGnhboiVy2wd+str(f8VldUL9Kg2zo06)+EF2tvxZHz5n4UruPhaViXKycI6SQR(u"ࠨࠢࡐࡆ๊ࠥࠦࠠࠡๅฮ๋ࠥสษไํ࠾ࠥ࠭ൠ")+jHWkt18govGwY7iUbduAfxCyRc.strftime(OBsrtQo2pPlgURCxJYbj9iXMD(u"ࠤࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠦൡ"),jHWkt18govGwY7iUbduAfxCyRc.gmtime(qq5jASaIQ1leOE))+knTyjJ0sGIzuwbxRae(u"ࠪࠤๅ࠭ൢ"))
			if fHFmBo6bzTsC.iscanceled():
				uC0Utqej2zRHxP7 = mic3MEN709xOkrjD5ZvbGIlX6
				break
		Pmwd7O4bJj82oUSYiBR1hrEkNstXlK.close()
	pb7tsOhkEPVZvD0iB61JfSdcIlFoQx.close()
	fHFmBo6bzTsC.close()
	if not uC0Utqej2zRHxP7:
		vv8DyVrLOPAXFIMZ9h(RRWFdpe04EK1Qn,LLe5QGmjCZigv(HDLtdMAy7wPkl8aKC3O2)+ELfMeDTIFhJt685K(u"ࠫࠥࠦࠠࡖࡵࡨࡶࠥࡩࡡ࡯ࡥࡨࡰࡪࡪ࠯ࡪࡰࡷࡩࡷࡸࡵࡱࡶࡨࡨࠥࡺࡨࡦࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤࡵࡸ࡯ࡤࡧࡶࡷࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨൣ")+SSHjMN4uegZfb2+SODvU3Ibq5VzC(u"ࠬࠦ࡝ࠡࠢࠣࡊ࡮ࡲࡥ࠻ࠢ࡞ࠤࠬ൤")+UIvKkdirJw7jS6XOeAt2Po8NL1HfbE+X2crmy67eZpkGTRd(u"࠭ࠠ࡞ࠩ൥"))
		u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,PPAUFrY8cduRT(u"ࠧษฯึฬࠥ฽ไษๅࠣฮ๊ࠦลๅ฼สลࠥ฿ๅๅ์ฬࠤฯำๅ๋ๆ้้ࠣ็ࠠศๆไ๎ิ๐่ࠨ൦"))
		return gyd2rf0UR5
	vv8DyVrLOPAXFIMZ9h(RRWFdpe04EK1Qn,LLe5QGmjCZigv(HDLtdMAy7wPkl8aKC3O2)+nz8x32hX0qcjUPFZk5RdJsiwED(u"ࠨࠢࠣࠤ࡛࡯ࡤࡦࡱࠣࡪ࡮ࡲࡥࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࡨࡨࠥࡹࡵࡤࡥࡨࡷࡸ࡬ࡵ࡭࡮ࡼࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ൧")+SSHjMN4uegZfb2+owbMhINBQsmx70guApW(u"ࠩࠣࡡࠥࠦࠠࡇ࡫࡯ࡩ࠿࡛ࠦࠡࠩ൨")+UIvKkdirJw7jS6XOeAt2Po8NL1HfbE+LHX65I9nkx0PstgcVY24uSi(u"ࠪࠤࡢ࠭൩"))
	u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,Tcf5Ppn9UajDbzyM(u"ࠫฯ๋ࠠหฯ่๎้ࠦๅๅใࠣห้็๊ะ์๋ࠤอ์ฬศฯࠪ൪"))
	return gyd2rf0UR5
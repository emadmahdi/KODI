# -*- coding: utf-8 -*-
from FF68kA5BUy import *
import bs4 as UpotMRwv0hzQs
HDLtdMAy7wPkl8aKC3O2 = 'ELCINEMA'
EEJvXQzSZNt = '_ELC_'
e2VR8nohduY = Jzthpc2nj5.SITESURLS[HDLtdMAy7wPkl8aKC3O2][0]
headers = {'Referer':e2VR8nohduY}
FwhZ0nXtpoHTMarf = []
def kk6X5LxpsND(mode,url,text):
	if   mode==510: zLZUkrP7ac5 = afkxo7FyZWB4O6K1eXrs5I()
	elif mode==511: zLZUkrP7ac5 = uUHomB0Mnl6kINQVCZz(url)
	elif mode==512: zLZUkrP7ac5 = CU9JvOuNxKYP1y8new4m(url)
	elif mode==513: zLZUkrP7ac5 = wqHnLCe91RarcE4VTb865h(url)
	elif mode==514: zLZUkrP7ac5 = XBF8DQPdySwL4hZ0OrE(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==515: zLZUkrP7ac5 = XBF8DQPdySwL4hZ0OrE(url,'SPECIFIED_FILTER___'+text)
	elif mode==516: zLZUkrP7ac5 = QdfsEwgt8HmP(text)
	elif mode==517: zLZUkrP7ac5 = FfM1cGbBDoRuxr7SAHXVZKL4Q(url)
	elif mode==518: zLZUkrP7ac5 = aIkfheWjTG3AnuH19K(url)
	elif mode==519: zLZUkrP7ac5 = hm4kawIPKp3oMrC75dJZA9HS2(text)
	elif mode==520: zLZUkrP7ac5 = bOdzIwWavQSjRm(url)
	elif mode==521: zLZUkrP7ac5 = ctWG0qOAnYw(url)
	elif mode==522: zLZUkrP7ac5 = f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url)
	elif mode==523: zLZUkrP7ac5 = vHZ0XDwj2xB5Nbln847cIq(text)
	elif mode==524: zLZUkrP7ac5 = dNO8YzJDtLXl0QhnxWMuVC()
	elif mode==525: zLZUkrP7ac5 = CLmcp0qzMfYG()
	elif mode==526: zLZUkrP7ac5 = LoI2Bcs17Al4jCuX8WYUOybPMvRtF()
	elif mode==527: zLZUkrP7ac5 = MMa6eyH8fDQGts17AqwXpB()
	else: zLZUkrP7ac5 = False
	return zLZUkrP7ac5
def afkxo7FyZWB4O6K1eXrs5I():
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'بحث بموسوعة السينما',HQmDERMFjx,519)
	CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'موسوعة الأعمال',HQmDERMFjx,525)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'موسوعة الأشخاص',HQmDERMFjx,526)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'موسوعة المصنفات',HQmDERMFjx,527)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'موسوعة المنوعات',HQmDERMFjx,524)
	return
def dNO8YzJDtLXl0QhnxWMuVC():
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+' فيديوهات - خاصة',e2VR8nohduY+'/video',520)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'فيديوهات - أحدث',e2VR8nohduY+'/video/latest',521)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'فيديوهات - أقدم',e2VR8nohduY+'/video/oldest',521)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'فيديوهات - أكثر مشاهدة',e2VR8nohduY+'/video/views',521)
	return
def CLmcp0qzMfYG():
	LMc214Pn0S9Ve = e2VR8nohduY+'/lineup?utf8=%E2%9C%93'
	zj5ir21Z9ypHU = LMc214Pn0S9Ve+'&type=2&category=1&foreign=false&tag='
	POgEIoksUL = LMc214Pn0S9Ve+'&type=2&category=3&foreign=false&tag='
	dETGvgu74xkDYQWsOqNIB8yPK = LMc214Pn0S9Ve+'&type=2&category=1&foreign=true&tag='
	DRWK7JvdGcH4o3f8r5nap = LMc214Pn0S9Ve+'&type=2&category=3&foreign=true&tag='
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'مصنفات أفلام عربي',zj5ir21Z9ypHU,511)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'مصنفات مسلسلات عربي',POgEIoksUL,511)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'مصنفات أفلام اجنبي',dETGvgu74xkDYQWsOqNIB8yPK,511)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'مصنفات مسلسلات اجنبي',DRWK7JvdGcH4o3f8r5nap,511)
	CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'فهرس أعمال أبجدي',e2VR8nohduY+'/index/work/alphabet',517)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'فهرس  بلد الإنتاج',e2VR8nohduY+'/index/work/country',517)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'فهرس اللغة',e2VR8nohduY+'/index/work/language',517)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'فهرس مصنفات العمل',e2VR8nohduY+'/index/work/genre',517)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'فهرس سنة الإصدار',e2VR8nohduY+'/index/work/release_year',517)
	CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'مواسم - فلتر محدد',e2VR8nohduY+'/seasonals',515)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'مواسم - فلتر كامل',e2VR8nohduY+'/seasonals',514)
	CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'مصنفات - فلتر محدد',e2VR8nohduY+'/lineup',515)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'مصنفات - فلتر كامل',e2VR8nohduY+'/lineup',514)
	return
def MMa6eyH8fDQGts17AqwXpB():
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(H5x4Z2qPwR8vXM,'GET',e2VR8nohduY+'/lineup',HQmDERMFjx,headers,HQmDERMFjx,HQmDERMFjx,'ELCINEMA-MENU-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	EI8ca97h1NzpqLUlu3MnfWHCx2TRF = UpotMRwv0hzQs.BeautifulSoup(CzNPJydxQLfw27tv4ZF8KORAbX5,'html.parser',multi_valued_attributes=None)
	MJ2gSPyTl9hzoi1 = EI8ca97h1NzpqLUlu3MnfWHCx2TRF.find('select',attrs={'name':'tag'})
	GXVabd4sc2u3zp0JI = MJ2gSPyTl9hzoi1.find_all('option')
	for yewoKb5dkfHu1xEZMAsY in GXVabd4sc2u3zp0JI:
		value = yewoKb5dkfHu1xEZMAsY.get('value')
		if not value: continue
		title = yewoKb5dkfHu1xEZMAsY.text
		if C6H1qXua3SMQiIrzxNvJWZE:
			title = title.encode(Zex6D4tJE52r)
			value = value.encode(Zex6D4tJE52r)
		vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+'/lineup?utf8=%E2%9C%93&type=&category=&foreign=&tag='+value
		title = title.replace('قائمة ',HQmDERMFjx)
		CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,511)
	return
def LoI2Bcs17Al4jCuX8WYUOybPMvRtF():
	LMc214Pn0S9Ve = e2VR8nohduY+'/lineup?utf8=%E2%9C%93'
	Jq6yRaXtmufPFIjBOz4ZQ8 = LMc214Pn0S9Ve+'&type=1&category=&foreign=&tag='
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'مصنفات أشخاص',Jq6yRaXtmufPFIjBOz4ZQ8,511)
	CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'فهرس أشخاص أبجدي',e2VR8nohduY+'/index/person/alphabet',517)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'فهرس موطن',e2VR8nohduY+'/index/person/nationality',517)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'فهرس  تاريخ الميلاد',e2VR8nohduY+'/index/person/birth_year',517)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'فهرس  تاريخ الوفاة',e2VR8nohduY+'/index/person/death_year',517)
	CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'مصنفات - فلتر محدد',e2VR8nohduY+'/lineup',515)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'مصنفات - فلتر كامل',e2VR8nohduY+'/lineup',514)
	return
def uUHomB0Mnl6kINQVCZz(url):
	if '/seasonals' in url: bbiEfNgaGDK3tOSoAe0uZy4B = 0
	elif '/lineup' in url: bbiEfNgaGDK3tOSoAe0uZy4B = 1
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(H5x4Z2qPwR8vXM,'GET',url,HQmDERMFjx,headers,HQmDERMFjx,HQmDERMFjx,'ELCINEMA-LISTS-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	EI8ca97h1NzpqLUlu3MnfWHCx2TRF = UpotMRwv0hzQs.BeautifulSoup(CzNPJydxQLfw27tv4ZF8KORAbX5,'html.parser',multi_valued_attributes=None)
	bUzHWnGg5t1 = EI8ca97h1NzpqLUlu3MnfWHCx2TRF.find_all(class_='jumbo-theater clearfix')
	for MJ2gSPyTl9hzoi1 in bUzHWnGg5t1:
		title = MJ2gSPyTl9hzoi1.find_all('a')[bbiEfNgaGDK3tOSoAe0uZy4B].text
		vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+MJ2gSPyTl9hzoi1.find_all('a')[bbiEfNgaGDK3tOSoAe0uZy4B].get('href')
		if C6H1qXua3SMQiIrzxNvJWZE:
			title = title.encode(Zex6D4tJE52r)
			vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A.encode(Zex6D4tJE52r)
		if not bUzHWnGg5t1:
			CU9JvOuNxKYP1y8new4m(vn1grP3y4It9GmVuBbLJfz2A)
			return
		else:
			title = title.replace('قائمة ',HQmDERMFjx)
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,512)
	SjaDEl6u9ZXroLw(EI8ca97h1NzpqLUlu3MnfWHCx2TRF,511)
	return
def SjaDEl6u9ZXroLw(EI8ca97h1NzpqLUlu3MnfWHCx2TRF,mode):
	MJ2gSPyTl9hzoi1 = EI8ca97h1NzpqLUlu3MnfWHCx2TRF.find(class_='pagination')
	if MJ2gSPyTl9hzoi1:
		pHCa6BiYtFR8K7cufxJ4OhLbWSMU = MJ2gSPyTl9hzoi1.find_all('a')
		j1rBT6qE95sCeDSodu8XZ = MJ2gSPyTl9hzoi1.find_all('li')
		IRx5Dvw8CT6HhouN = list(zip(pHCa6BiYtFR8K7cufxJ4OhLbWSMU,j1rBT6qE95sCeDSodu8XZ))
		DvGaoUZE5S4wxfHc910sz = -1
		NZIBEHr7ecQV6iSTfL4qKFdAUWn3xj = len(IRx5Dvw8CT6HhouN)
		for sibPMcaz4K,OOhXNpeiq6Ctx in IRx5Dvw8CT6HhouN:
			DvGaoUZE5S4wxfHc910sz += 1
			OOhXNpeiq6Ctx = OOhXNpeiq6Ctx['class']
			if 'unavailable' in OOhXNpeiq6Ctx or 'current' in OOhXNpeiq6Ctx: continue
			hQGaZWkesbXDYn7Altz2oudM = sibPMcaz4K.text
			cjfepMobZyFTuwq7WS1EV945L3g = e2VR8nohduY+sibPMcaz4K.get('href')
			if C6H1qXua3SMQiIrzxNvJWZE:
				hQGaZWkesbXDYn7Altz2oudM = hQGaZWkesbXDYn7Altz2oudM.encode(Zex6D4tJE52r)
				cjfepMobZyFTuwq7WS1EV945L3g = cjfepMobZyFTuwq7WS1EV945L3g.encode(Zex6D4tJE52r)
			if   DvGaoUZE5S4wxfHc910sz==0: hQGaZWkesbXDYn7Altz2oudM = 'أولى'
			elif DvGaoUZE5S4wxfHc910sz==1: hQGaZWkesbXDYn7Altz2oudM = 'سابقة'
			elif DvGaoUZE5S4wxfHc910sz==NZIBEHr7ecQV6iSTfL4qKFdAUWn3xj-2: hQGaZWkesbXDYn7Altz2oudM = 'لاحقة'
			elif DvGaoUZE5S4wxfHc910sz==NZIBEHr7ecQV6iSTfL4qKFdAUWn3xj-1: hQGaZWkesbXDYn7Altz2oudM = 'أخيرة'
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'صفحة '+hQGaZWkesbXDYn7Altz2oudM,cjfepMobZyFTuwq7WS1EV945L3g,mode)
	return
def CU9JvOuNxKYP1y8new4m(url):
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(H5x4Z2qPwR8vXM,'GET',url,HQmDERMFjx,headers,HQmDERMFjx,HQmDERMFjx,'ELCINEMA-TITLES1-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	EI8ca97h1NzpqLUlu3MnfWHCx2TRF = UpotMRwv0hzQs.BeautifulSoup(CzNPJydxQLfw27tv4ZF8KORAbX5,'html.parser',multi_valued_attributes=None)
	bUzHWnGg5t1 = EI8ca97h1NzpqLUlu3MnfWHCx2TRF.find_all(class_='row')
	items,B1eTDbEXUfs8lqtywGoFC3jRc29 = [],True
	for MJ2gSPyTl9hzoi1 in bUzHWnGg5t1:
		if not MJ2gSPyTl9hzoi1.find(class_='thumbnail-wrapper'): continue
		if B1eTDbEXUfs8lqtywGoFC3jRc29: B1eTDbEXUfs8lqtywGoFC3jRc29 = False ; continue
		O5vzYpwQ9TDWKfLBXqsc48xHEAZe = []
		cLxJ3aw7UH = MJ2gSPyTl9hzoi1.find_all(class_=['censorship red','censorship purple'])
		for u5MDN12THO9swKX in cLxJ3aw7UH:
			yFqX7gzGWhJ = u5MDN12THO9swKX.find_all('li')[1].text
			if C6H1qXua3SMQiIrzxNvJWZE:
				yFqX7gzGWhJ = yFqX7gzGWhJ.encode(Zex6D4tJE52r)
			O5vzYpwQ9TDWKfLBXqsc48xHEAZe.append(yFqX7gzGWhJ)
		if not UzSYuZp3Pnhf1W4wyx7Fc0JX6jNb(HDLtdMAy7wPkl8aKC3O2,HQmDERMFjx,O5vzYpwQ9TDWKfLBXqsc48xHEAZe,False):
			kALyrFT6KPNGI7Oiup82Qb4JCq0td = MJ2gSPyTl9hzoi1.find('img').get('data-src')
			title = MJ2gSPyTl9hzoi1.find('h3')
			name = title.find('a').text
			vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+title.find('a').get('href')
			dtCrnYWf0m = MJ2gSPyTl9hzoi1.find(class_='no-margin')
			aRk1m5Ny8xKfFCEd9tI = MJ2gSPyTl9hzoi1.find(class_='legend')
			if dtCrnYWf0m: dtCrnYWf0m = dtCrnYWf0m.text
			if aRk1m5Ny8xKfFCEd9tI: aRk1m5Ny8xKfFCEd9tI = aRk1m5Ny8xKfFCEd9tI.text
			if C6H1qXua3SMQiIrzxNvJWZE:
				kALyrFT6KPNGI7Oiup82Qb4JCq0td = kALyrFT6KPNGI7Oiup82Qb4JCq0td.encode(Zex6D4tJE52r)
				name = name.encode(Zex6D4tJE52r)
				vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A.encode(Zex6D4tJE52r)
				if dtCrnYWf0m: dtCrnYWf0m = dtCrnYWf0m.encode(Zex6D4tJE52r)
			GoC84Eq3azJwpSWxkctF1MdTruOIyb = {}
			if aRk1m5Ny8xKfFCEd9tI: GoC84Eq3azJwpSWxkctF1MdTruOIyb['stars'] = aRk1m5Ny8xKfFCEd9tI
			if dtCrnYWf0m:
				dtCrnYWf0m = dtCrnYWf0m.replace(ti3SbXNV0aJ7n5Grc4OQY8Ll1s9,' .. ')
				GoC84Eq3azJwpSWxkctF1MdTruOIyb['plot'] = dtCrnYWf0m.replace('...اقرأ المزيد',HQmDERMFjx)
			if '/work/' in vn1grP3y4It9GmVuBbLJfz2A:
				CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+name,vn1grP3y4It9GmVuBbLJfz2A,516,kALyrFT6KPNGI7Oiup82Qb4JCq0td,HQmDERMFjx,name,HQmDERMFjx,GoC84Eq3azJwpSWxkctF1MdTruOIyb)
			elif '/person/' in vn1grP3y4It9GmVuBbLJfz2A: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+name,vn1grP3y4It9GmVuBbLJfz2A,513,kALyrFT6KPNGI7Oiup82Qb4JCq0td,HQmDERMFjx,name,HQmDERMFjx,GoC84Eq3azJwpSWxkctF1MdTruOIyb)
	SjaDEl6u9ZXroLw(EI8ca97h1NzpqLUlu3MnfWHCx2TRF,512)
	return
def wqHnLCe91RarcE4VTb865h(url):
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(H5x4Z2qPwR8vXM,'GET',url,HQmDERMFjx,headers,HQmDERMFjx,HQmDERMFjx,'ELCINEMA-TITLES2-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	EI8ca97h1NzpqLUlu3MnfWHCx2TRF = UpotMRwv0hzQs.BeautifulSoup(CzNPJydxQLfw27tv4ZF8KORAbX5,'html.parser',multi_valued_attributes=None)
	bUzHWnGg5t1 = EI8ca97h1NzpqLUlu3MnfWHCx2TRF.find_all('li')
	szxwkVQTmqev0jGiK78HJIbN4uDOd,items = [],[]
	for MJ2gSPyTl9hzoi1 in bUzHWnGg5t1:
		if not MJ2gSPyTl9hzoi1.find(class_='thumbnail-wrapper'): continue
		if not MJ2gSPyTl9hzoi1.find(class_=['unstyled','unstyled text-center']): continue
		if MJ2gSPyTl9hzoi1.find(class_='hide'): continue
		title = MJ2gSPyTl9hzoi1.find(class_=['unstyled','unstyled text-center'])
		name = title.find('a').text
		if name in szxwkVQTmqev0jGiK78HJIbN4uDOd: continue
		szxwkVQTmqev0jGiK78HJIbN4uDOd.append(name)
		vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+title.find('a').get('href')
		if '/search/work/' in url: kALyrFT6KPNGI7Oiup82Qb4JCq0td = MJ2gSPyTl9hzoi1.find('img').get('src')
		elif '/search/person/' in url: kALyrFT6KPNGI7Oiup82Qb4JCq0td = MJ2gSPyTl9hzoi1.find('img').get('data-src')
		elif '/search/video/' in url: kALyrFT6KPNGI7Oiup82Qb4JCq0td = MJ2gSPyTl9hzoi1.find('img').get('data-src')
		else: kALyrFT6KPNGI7Oiup82Qb4JCq0td = MJ2gSPyTl9hzoi1.find('img').get('src')
		if C6H1qXua3SMQiIrzxNvJWZE:
			name = name.encode(Zex6D4tJE52r)
			vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A.encode(Zex6D4tJE52r)
			kALyrFT6KPNGI7Oiup82Qb4JCq0td = kALyrFT6KPNGI7Oiup82Qb4JCq0td.encode(Zex6D4tJE52r)
		name = name.strip(oQpxmKiRPlHeGsLXNrJF78O)
		items.append((name,vn1grP3y4It9GmVuBbLJfz2A,kALyrFT6KPNGI7Oiup82Qb4JCq0td))
	if '/search/person/' in url: items = sorted(items,reverse=False,key=lambda key: key[0])
	for name,vn1grP3y4It9GmVuBbLJfz2A,kALyrFT6KPNGI7Oiup82Qb4JCq0td in items:
		if '/search/video/' in url: CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+name,vn1grP3y4It9GmVuBbLJfz2A,522,kALyrFT6KPNGI7Oiup82Qb4JCq0td)
		elif '/search/person/' in url: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+name,vn1grP3y4It9GmVuBbLJfz2A,513,kALyrFT6KPNGI7Oiup82Qb4JCq0td,HQmDERMFjx,name)
		else: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+name,vn1grP3y4It9GmVuBbLJfz2A,516,kALyrFT6KPNGI7Oiup82Qb4JCq0td,HQmDERMFjx,name)
	return
def QdfsEwgt8HmP(text):
	text = text.replace('الإعلان',HQmDERMFjx).replace('لفيلم',HQmDERMFjx).replace('الرسمي',HQmDERMFjx)
	text = text.replace('إعلان',HQmDERMFjx).replace('فيلم',HQmDERMFjx).replace('البرومو',HQmDERMFjx)
	text = text.replace('التشويقي',HQmDERMFjx).replace('لمسلسل',HQmDERMFjx).replace('مسلسل',HQmDERMFjx)
	text = text.replace(':',HQmDERMFjx).replace(')',HQmDERMFjx).replace('(',HQmDERMFjx).replace(',',HQmDERMFjx)
	text = text.replace('_',HQmDERMFjx).replace(';',HQmDERMFjx).replace('-',HQmDERMFjx).replace('.',HQmDERMFjx)
	text = text.replace('\'',HQmDERMFjx).replace('\"',HQmDERMFjx)
	text = text.replace(pVzyOequnZtI,oQpxmKiRPlHeGsLXNrJF78O).replace(xoZHpTRUzS9,oQpxmKiRPlHeGsLXNrJF78O).replace(MSnXBQNUg1jF3W2fRlE9OLaCT8ds4,oQpxmKiRPlHeGsLXNrJF78O)
	text = text.strip(oQpxmKiRPlHeGsLXNrJF78O)
	pNbFlYg57y4eShKnI92dQ = text.count(oQpxmKiRPlHeGsLXNrJF78O)+1
	if pNbFlYg57y4eShKnI92dQ==1:
		vHZ0XDwj2xB5Nbln847cIq(text)
		return
	CfgK4s13Q0hZcHyleT2bVJO9('link',EEJvXQzSZNt+ao3Q5jP8H0sMxK2iUYwZGE+'==== كلمات للبحث ===='+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	Gz4N1prCPyMF0uXKmYQbhaIcVg = text.split(oQpxmKiRPlHeGsLXNrJF78O)
	hbx736sKMm8izNyuRHBQw1nfFTW = pow(2,pNbFlYg57y4eShKnI92dQ)
	hD9d7n4VRGbSQCaLpXWcTjNo3KA = []
	def W241SoeCzFRXD9H83jypAOcBKquxa(HHEviNyY0ldhs,C0IXhz64tBceyNobpYxZ3j):
		if HHEviNyY0ldhs=='1': return C0IXhz64tBceyNobpYxZ3j
		return HQmDERMFjx
	for DvGaoUZE5S4wxfHc910sz in range(hbx736sKMm8izNyuRHBQw1nfFTW,0,-1):
		se7rw5aXZh = list(pNbFlYg57y4eShKnI92dQ*'0'+bin(DvGaoUZE5S4wxfHc910sz)[2:])[-pNbFlYg57y4eShKnI92dQ:]
		se7rw5aXZh = reversed(se7rw5aXZh)
		Q5h3NlAKkaPpmXtF8uEqV = map(W241SoeCzFRXD9H83jypAOcBKquxa,se7rw5aXZh,Gz4N1prCPyMF0uXKmYQbhaIcVg)
		title = oQpxmKiRPlHeGsLXNrJF78O.join(filter(None,Q5h3NlAKkaPpmXtF8uEqV))
		if C6H1qXua3SMQiIrzxNvJWZE: eyLMq9Enup0jiJT42RDWafg = title.decode(Zex6D4tJE52r)
		else: eyLMq9Enup0jiJT42RDWafg = title
		if len(eyLMq9Enup0jiJT42RDWafg)>2 and title not in hD9d7n4VRGbSQCaLpXWcTjNo3KA:
			hD9d7n4VRGbSQCaLpXWcTjNo3KA.append(title)
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,HQmDERMFjx,523,HQmDERMFjx,HQmDERMFjx,title)
	return
def vHZ0XDwj2xB5Nbln847cIq(JNFUAM0L4BQ):
	if C6H1qXua3SMQiIrzxNvJWZE:
		JNFUAM0L4BQ = JNFUAM0L4BQ.decode(Zex6D4tJE52r)
		import arabic_reshaper as EP1ToeBYxpgLclAkXG7H5w,bidi.algorithm as PkGYL8jmwOEgN3WFQJ271
		JNFUAM0L4BQ = EP1ToeBYxpgLclAkXG7H5w.ArabicReshaper().reshape(JNFUAM0L4BQ)
		JNFUAM0L4BQ = PkGYL8jmwOEgN3WFQJ271.get_display(JNFUAM0L4BQ)
	import JEgr7monxk
	JNFUAM0L4BQ = q156m84QoYrn(InbGgjXfiDsSN9ze=JNFUAM0L4BQ)
	JEgr7monxk.hm4kawIPKp3oMrC75dJZA9HS2(JNFUAM0L4BQ)
	return
def FfM1cGbBDoRuxr7SAHXVZKL4Q(url):
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(H5x4Z2qPwR8vXM,'GET',url,HQmDERMFjx,headers,HQmDERMFjx,HQmDERMFjx,'ELCINEMA-INDEXES_LISTS-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	EI8ca97h1NzpqLUlu3MnfWHCx2TRF = UpotMRwv0hzQs.BeautifulSoup(CzNPJydxQLfw27tv4ZF8KORAbX5,'html.parser',multi_valued_attributes=None)
	MJ2gSPyTl9hzoi1 = EI8ca97h1NzpqLUlu3MnfWHCx2TRF.find(class_='list-separator list-title')
	qP1wT2MFf0oK9Uv3u87QL = MJ2gSPyTl9hzoi1.find_all('a')
	items = []
	for title in qP1wT2MFf0oK9Uv3u87QL:
		name = title.text
		vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+title.get('href')
		if C6H1qXua3SMQiIrzxNvJWZE:
			name = name.encode(Zex6D4tJE52r)
			vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A.encode(Zex6D4tJE52r)
		if '#' not in vn1grP3y4It9GmVuBbLJfz2A: items.append((name,vn1grP3y4It9GmVuBbLJfz2A))
	items = sorted(items,reverse=False,key=lambda key: key[0])
	for A07BpVeRJToLb in items:
		name,vn1grP3y4It9GmVuBbLJfz2A = A07BpVeRJToLb
		CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+name,vn1grP3y4It9GmVuBbLJfz2A,518)
	return
def aIkfheWjTG3AnuH19K(url):
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(H5x4Z2qPwR8vXM,'GET',url,HQmDERMFjx,headers,HQmDERMFjx,HQmDERMFjx,'ELCINEMA-INDEXES_TITLES-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	EI8ca97h1NzpqLUlu3MnfWHCx2TRF = UpotMRwv0hzQs.BeautifulSoup(CzNPJydxQLfw27tv4ZF8KORAbX5,'html.parser',multi_valued_attributes=None)
	bUzHWnGg5t1 = EI8ca97h1NzpqLUlu3MnfWHCx2TRF.find(class_='expand').find_all('tr')
	for MJ2gSPyTl9hzoi1 in bUzHWnGg5t1:
		PRT9JuYN86izlUr5Sn2aZ1jv = MJ2gSPyTl9hzoi1.find_all('a')
		if not PRT9JuYN86izlUr5Sn2aZ1jv: continue
		kALyrFT6KPNGI7Oiup82Qb4JCq0td = MJ2gSPyTl9hzoi1.find('img').get('data-src')
		name = PRT9JuYN86izlUr5Sn2aZ1jv[1].text
		vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+PRT9JuYN86izlUr5Sn2aZ1jv[1].get('href')
		aRk1m5Ny8xKfFCEd9tI = MJ2gSPyTl9hzoi1.find(class_='legend')
		if aRk1m5Ny8xKfFCEd9tI: aRk1m5Ny8xKfFCEd9tI = aRk1m5Ny8xKfFCEd9tI.text
		if C6H1qXua3SMQiIrzxNvJWZE:
			name = name.encode(Zex6D4tJE52r)
			vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A.encode(Zex6D4tJE52r)
			kALyrFT6KPNGI7Oiup82Qb4JCq0td = kALyrFT6KPNGI7Oiup82Qb4JCq0td.encode(Zex6D4tJE52r)
		GoC84Eq3azJwpSWxkctF1MdTruOIyb = {}
		if aRk1m5Ny8xKfFCEd9tI: GoC84Eq3azJwpSWxkctF1MdTruOIyb['stars'] = aRk1m5Ny8xKfFCEd9tI
		if '/work/' in vn1grP3y4It9GmVuBbLJfz2A:
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+name,vn1grP3y4It9GmVuBbLJfz2A,516,kALyrFT6KPNGI7Oiup82Qb4JCq0td,HQmDERMFjx,name,HQmDERMFjx,GoC84Eq3azJwpSWxkctF1MdTruOIyb)
		elif '/person/' in vn1grP3y4It9GmVuBbLJfz2A: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+name,vn1grP3y4It9GmVuBbLJfz2A,513,kALyrFT6KPNGI7Oiup82Qb4JCq0td,HQmDERMFjx,name,HQmDERMFjx,GoC84Eq3azJwpSWxkctF1MdTruOIyb)
	SjaDEl6u9ZXroLw(EI8ca97h1NzpqLUlu3MnfWHCx2TRF,518)
	return
def bOdzIwWavQSjRm(url):
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(H5x4Z2qPwR8vXM,'GET',url,HQmDERMFjx,headers,HQmDERMFjx,HQmDERMFjx,'ELCINEMA-VIDEOS_LISTS-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	EI8ca97h1NzpqLUlu3MnfWHCx2TRF = UpotMRwv0hzQs.BeautifulSoup(CzNPJydxQLfw27tv4ZF8KORAbX5,'html.parser',multi_valued_attributes=None)
	qP1wT2MFf0oK9Uv3u87QL = EI8ca97h1NzpqLUlu3MnfWHCx2TRF.find_all(class_='section-title inline')
	jzTLleJs8x9Hb1 = EI8ca97h1NzpqLUlu3MnfWHCx2TRF.find_all(class_='button green small right')
	items = zip(qP1wT2MFf0oK9Uv3u87QL,jzTLleJs8x9Hb1)
	for title,vn1grP3y4It9GmVuBbLJfz2A in items:
		title = title.text
		vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+vn1grP3y4It9GmVuBbLJfz2A.get('href')
		if C6H1qXua3SMQiIrzxNvJWZE:
			title = title.encode(Zex6D4tJE52r)
			vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A.encode(Zex6D4tJE52r)
		title = title.replace(pVzyOequnZtI,oQpxmKiRPlHeGsLXNrJF78O).replace(xoZHpTRUzS9,oQpxmKiRPlHeGsLXNrJF78O).replace(MSnXBQNUg1jF3W2fRlE9OLaCT8ds4,oQpxmKiRPlHeGsLXNrJF78O)
		CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,521)
	return
def ctWG0qOAnYw(url):
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(H5x4Z2qPwR8vXM,'GET',url,HQmDERMFjx,headers,HQmDERMFjx,HQmDERMFjx,'ELCINEMA-VIDEOS_TITLES-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	EI8ca97h1NzpqLUlu3MnfWHCx2TRF = UpotMRwv0hzQs.BeautifulSoup(CzNPJydxQLfw27tv4ZF8KORAbX5,'html.parser',multi_valued_attributes=None)
	aVu6tlB512iny8DUbpQ7kNo = EI8ca97h1NzpqLUlu3MnfWHCx2TRF.find(class_='large-block-grid-4 medium-block-grid-4 small-block-grid-2')
	bUzHWnGg5t1 = aVu6tlB512iny8DUbpQ7kNo.find_all('li')
	for MJ2gSPyTl9hzoi1 in bUzHWnGg5t1:
		title = MJ2gSPyTl9hzoi1.find(class_='title').text
		vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+MJ2gSPyTl9hzoi1.find('a').get('href')
		kALyrFT6KPNGI7Oiup82Qb4JCq0td = MJ2gSPyTl9hzoi1.find('img').get('data-src')
		OMDCpSL7ZB = MJ2gSPyTl9hzoi1.find(class_='duration').text
		if C6H1qXua3SMQiIrzxNvJWZE:
			title = title.encode(Zex6D4tJE52r)
			vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A.encode(Zex6D4tJE52r)
			kALyrFT6KPNGI7Oiup82Qb4JCq0td = kALyrFT6KPNGI7Oiup82Qb4JCq0td.encode(Zex6D4tJE52r)
			OMDCpSL7ZB = OMDCpSL7ZB.encode(Zex6D4tJE52r)
		OMDCpSL7ZB = OMDCpSL7ZB.replace(ti3SbXNV0aJ7n5Grc4OQY8Ll1s9,HQmDERMFjx).strip(oQpxmKiRPlHeGsLXNrJF78O)
		CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,522,kALyrFT6KPNGI7Oiup82Qb4JCq0td,OMDCpSL7ZB)
	SjaDEl6u9ZXroLw(EI8ca97h1NzpqLUlu3MnfWHCx2TRF,521)
	return
def f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url):
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(H5x4Z2qPwR8vXM,'GET',url,HQmDERMFjx,headers,HQmDERMFjx,HQmDERMFjx,'ELCINEMA-PLAY-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	EI8ca97h1NzpqLUlu3MnfWHCx2TRF = UpotMRwv0hzQs.BeautifulSoup(CzNPJydxQLfw27tv4ZF8KORAbX5,'html.parser',multi_valued_attributes=None)
	vn1grP3y4It9GmVuBbLJfz2A = EI8ca97h1NzpqLUlu3MnfWHCx2TRF.find(class_='flex-video').find('iframe').get('src')
	if C6H1qXua3SMQiIrzxNvJWZE: vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A.encode(Zex6D4tJE52r)
	import NsD5AomUqH
	NsD5AomUqH.NZcWGBmgFEen5hvJjUSIzOCVk7([vn1grP3y4It9GmVuBbLJfz2A],HDLtdMAy7wPkl8aKC3O2,'video',url)
	return
def hm4kawIPKp3oMrC75dJZA9HS2(search):
	search,GXVabd4sc2u3zp0JI,showDialogs = x0pzMENwy84tBcZvXr(search)
	if search==HQmDERMFjx: search = q156m84QoYrn()
	if search==HQmDERMFjx: return
	search = search.replace(oQpxmKiRPlHeGsLXNrJF78O,'%20')
	url = e2VR8nohduY+'/search/?q='+search
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(H5x4Z2qPwR8vXM,'GET',url,HQmDERMFjx,headers,HQmDERMFjx,HQmDERMFjx,'ELCINEMA-SEARCH-1st')
	if not vGXnw9VcUN.succeeded:
		Jq6yRaXtmufPFIjBOz4ZQ8 = e2VR8nohduY+'/search_entity/?q='+search+'&entity=work'
		cjfepMobZyFTuwq7WS1EV945L3g = e2VR8nohduY+'/search_entity/?q='+search+'&entity=person'
		tkSPaqKuJxBbXMLYiVR3mA = e2VR8nohduY+'/search_entity/?q='+search+'&entity=video'
		CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'بحث عن أعمال',Jq6yRaXtmufPFIjBOz4ZQ8,513,HQmDERMFjx,search)
		CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'بحث عن أشخاص',cjfepMobZyFTuwq7WS1EV945L3g,513,HQmDERMFjx,search)
		CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'بحث عن فيديوهات',tkSPaqKuJxBbXMLYiVR3mA,513,HQmDERMFjx,search)
		return
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	EI8ca97h1NzpqLUlu3MnfWHCx2TRF = UpotMRwv0hzQs.BeautifulSoup(CzNPJydxQLfw27tv4ZF8KORAbX5,'html.parser',multi_valued_attributes=None)
	bUzHWnGg5t1 = EI8ca97h1NzpqLUlu3MnfWHCx2TRF.find_all(class_='section-title left')
	for MJ2gSPyTl9hzoi1 in bUzHWnGg5t1:
		title = MJ2gSPyTl9hzoi1.text
		if C6H1qXua3SMQiIrzxNvJWZE:
			title = title.encode(Zex6D4tJE52r)
		title = title.split('(',1)[0].strip(oQpxmKiRPlHeGsLXNrJF78O)
		if   'أعمال' in title: vn1grP3y4It9GmVuBbLJfz2A = url.replace('/search/','/search/work/')
		elif 'أشخاص' in title: vn1grP3y4It9GmVuBbLJfz2A = url.replace('/search/','/search/person/')
		elif 'فيديوهات' in title: vn1grP3y4It9GmVuBbLJfz2A = url.replace('/search/','/search/video/')
		else: continue
		CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,513)
	return
def XBF8DQPdySwL4hZ0OrE(url,text):
	global rrdHuNZaRCOviqPmS4szhD0VcEjM3,xSMWIOb5tFvh
	if '/seasonals' in url:
		rrdHuNZaRCOviqPmS4szhD0VcEjM3 = ['seasonal','year','category']
		xSMWIOb5tFvh = ['seasonal','year','category']
	elif '/lineup' in url:
		rrdHuNZaRCOviqPmS4szhD0VcEjM3 = ['category','foreign','type']
		xSMWIOb5tFvh = ['category','foreign','type']
	ooxUXkcTj5PF4ad2SwYy(url,text)
	return
def Fhzowv4lbkLBY(url):
	url = url.split('/smartemadfilter?')[0]
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(H5x4Z2qPwR8vXM,'GET',url,HQmDERMFjx,headers,HQmDERMFjx,HQmDERMFjx,'ELCINEMA-GET_FILTERS_BLOCKS-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('form action="/(.*?)</form>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	jnPZuGqg9F5viBUp = DyVGS3dX0ZxR.findall('<select name="(.*?)" id="(.*?)".*?>(.*?)</div>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	return jnPZuGqg9F5viBUp
def jfcC3ErztgW9dw(MJ2gSPyTl9hzoi1):
	items = DyVGS3dX0ZxR.findall('<option value="(.*?)">(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	return items
def IeFlCiJPASD4r2Y6NUbX0k7hVRxBa(url):
	Fewh9HDYiA7jJWS5c6dgr = url.split('/smartemadfilter?')[0]
	EdxGKyuW1mvZSBDf0o947h8Rik = DpClq35GVjh(url,'url')
	url = url.replace('/smartemadfilter?','/?utf8=%E2%9C%93&')
	return url
def kYrMAXxe9EJoR8zOuvQ6(RRDtwVh6LbFiEycHNQkId5Cefmq,url):
	J4asIxU7Zyq5PiN2rKEctegFV = jlZtWwMfosJFIKenicqU1(RRDtwVh6LbFiEycHNQkId5Cefmq,'all_filters')
	jDcWv7MAkEV = url+'/smartemadfilter?'+J4asIxU7Zyq5PiN2rKEctegFV
	jDcWv7MAkEV = IeFlCiJPASD4r2Y6NUbX0k7hVRxBa(jDcWv7MAkEV)
	return jDcWv7MAkEV
def ooxUXkcTj5PF4ad2SwYy(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==HQmDERMFjx: eA0pnTuMvxrdmoRC9zPBh,mwhEr8eXxD21MAKfHUSlB = HQmDERMFjx,HQmDERMFjx
	else: eA0pnTuMvxrdmoRC9zPBh,mwhEr8eXxD21MAKfHUSlB = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if rrdHuNZaRCOviqPmS4szhD0VcEjM3[0]+'=' not in eA0pnTuMvxrdmoRC9zPBh: WF2vkePC5gbXAGUarcqlpmB3Q = rrdHuNZaRCOviqPmS4szhD0VcEjM3[0]
		for yuYts1RONXgp in range(len(rrdHuNZaRCOviqPmS4szhD0VcEjM3[0:-1])):
			if rrdHuNZaRCOviqPmS4szhD0VcEjM3[yuYts1RONXgp]+'=' in eA0pnTuMvxrdmoRC9zPBh: WF2vkePC5gbXAGUarcqlpmB3Q = rrdHuNZaRCOviqPmS4szhD0VcEjM3[yuYts1RONXgp+1]
		Cm5jWJgr28TlUnoZYHAxdPI3OB = eA0pnTuMvxrdmoRC9zPBh+'&'+WF2vkePC5gbXAGUarcqlpmB3Q+'=0'
		RRDtwVh6LbFiEycHNQkId5Cefmq = mwhEr8eXxD21MAKfHUSlB+'&'+WF2vkePC5gbXAGUarcqlpmB3Q+'=0'
		GSPtdslyxQURmB5obg69VJMY1jE = Cm5jWJgr28TlUnoZYHAxdPI3OB.strip('&')+'___'+RRDtwVh6LbFiEycHNQkId5Cefmq.strip('&')
		J4asIxU7Zyq5PiN2rKEctegFV = jlZtWwMfosJFIKenicqU1(mwhEr8eXxD21MAKfHUSlB,'modified_filters')
		SSHjMN4uegZfb2 = url+'/smartemadfilter?'+J4asIxU7Zyq5PiN2rKEctegFV
	elif type=='ALL_ITEMS_FILTER':
		v2s9V6uhIT0aCjkPOl7iUqZxB = jlZtWwMfosJFIKenicqU1(eA0pnTuMvxrdmoRC9zPBh,'modified_values')
		v2s9V6uhIT0aCjkPOl7iUqZxB = xx9LK4VzpF6IHXSEyhmrQwbg25P0(v2s9V6uhIT0aCjkPOl7iUqZxB)
		if mwhEr8eXxD21MAKfHUSlB!=HQmDERMFjx: mwhEr8eXxD21MAKfHUSlB = jlZtWwMfosJFIKenicqU1(mwhEr8eXxD21MAKfHUSlB,'modified_filters')
		if mwhEr8eXxD21MAKfHUSlB==HQmDERMFjx: SSHjMN4uegZfb2 = url
		else: SSHjMN4uegZfb2 = url+'/smartemadfilter?'+mwhEr8eXxD21MAKfHUSlB
		SSHjMN4uegZfb2 = IeFlCiJPASD4r2Y6NUbX0k7hVRxBa(SSHjMN4uegZfb2)
		CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'أظهار قائمة الفيديو التي تم اختيارها ',SSHjMN4uegZfb2,511)
		CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+' [[   '+v2s9V6uhIT0aCjkPOl7iUqZxB+'   ]]',SSHjMN4uegZfb2,511)
		CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	jnPZuGqg9F5viBUp = Fhzowv4lbkLBY(url)
	dict = {}
	for name,DcpbqKxWsJRCSVkQyjf1,MJ2gSPyTl9hzoi1 in jnPZuGqg9F5viBUp:
		name = name.replace('--',HQmDERMFjx)
		items = jfcC3ErztgW9dw(MJ2gSPyTl9hzoi1)
		if '=' not in SSHjMN4uegZfb2: SSHjMN4uegZfb2 = url
		if type=='SPECIFIED_FILTER':
			if DcpbqKxWsJRCSVkQyjf1 not in rrdHuNZaRCOviqPmS4szhD0VcEjM3: continue
			if WF2vkePC5gbXAGUarcqlpmB3Q!=DcpbqKxWsJRCSVkQyjf1: continue
			elif len(items)<2:
				if DcpbqKxWsJRCSVkQyjf1==rrdHuNZaRCOviqPmS4szhD0VcEjM3[-1]:
					url = IeFlCiJPASD4r2Y6NUbX0k7hVRxBa(url)
					CU9JvOuNxKYP1y8new4m(url)
				else: ooxUXkcTj5PF4ad2SwYy(SSHjMN4uegZfb2,'SPECIFIED_FILTER___'+GSPtdslyxQURmB5obg69VJMY1jE)
				return
			else:
				SSHjMN4uegZfb2 = IeFlCiJPASD4r2Y6NUbX0k7hVRxBa(SSHjMN4uegZfb2)
				if DcpbqKxWsJRCSVkQyjf1==rrdHuNZaRCOviqPmS4szhD0VcEjM3[-1]: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'الجميع',SSHjMN4uegZfb2,511)
				else: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'الجميع',SSHjMN4uegZfb2,515,HQmDERMFjx,HQmDERMFjx,GSPtdslyxQURmB5obg69VJMY1jE)
		elif type=='ALL_ITEMS_FILTER':
			if DcpbqKxWsJRCSVkQyjf1 not in xSMWIOb5tFvh: continue
			Cm5jWJgr28TlUnoZYHAxdPI3OB = eA0pnTuMvxrdmoRC9zPBh+'&'+DcpbqKxWsJRCSVkQyjf1+'=0'
			RRDtwVh6LbFiEycHNQkId5Cefmq = mwhEr8eXxD21MAKfHUSlB+'&'+DcpbqKxWsJRCSVkQyjf1+'=0'
			GSPtdslyxQURmB5obg69VJMY1jE = Cm5jWJgr28TlUnoZYHAxdPI3OB+'___'+RRDtwVh6LbFiEycHNQkId5Cefmq
			if   name=='type': name = 'النوع'
			elif name=='category': name = 'العمل'
			elif name=='foreign': name = 'اللغة'
			elif name=='year': name = 'السنة'
			elif name=='seasonal': name = 'الموسم'
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'الجميع: '+name,SSHjMN4uegZfb2,514,HQmDERMFjx,HQmDERMFjx,GSPtdslyxQURmB5obg69VJMY1jE)
		dict[DcpbqKxWsJRCSVkQyjf1] = {}
		for value,yewoKb5dkfHu1xEZMAsY in items:
			if yewoKb5dkfHu1xEZMAsY in FwhZ0nXtpoHTMarf: continue
			if 'مصنفات أخرى' in yewoKb5dkfHu1xEZMAsY: continue
			if 'الكل' in yewoKb5dkfHu1xEZMAsY: continue
			if 'اللغة' in yewoKb5dkfHu1xEZMAsY: continue
			yewoKb5dkfHu1xEZMAsY = yewoKb5dkfHu1xEZMAsY.replace('قائمة ',HQmDERMFjx)
			if   name=='type': name = 'النوع'
			elif name=='category': name = 'العمل'
			elif name=='foreign': name = 'اللغة'
			elif name=='year': name = 'السنة'
			elif name=='seasonal': name = 'الموسم'
			dict[DcpbqKxWsJRCSVkQyjf1][value] = yewoKb5dkfHu1xEZMAsY
			Cm5jWJgr28TlUnoZYHAxdPI3OB = eA0pnTuMvxrdmoRC9zPBh+'&'+DcpbqKxWsJRCSVkQyjf1+'='+yewoKb5dkfHu1xEZMAsY
			RRDtwVh6LbFiEycHNQkId5Cefmq = mwhEr8eXxD21MAKfHUSlB+'&'+DcpbqKxWsJRCSVkQyjf1+'='+value
			CEniUGWr4jMy = Cm5jWJgr28TlUnoZYHAxdPI3OB+'___'+RRDtwVh6LbFiEycHNQkId5Cefmq
			if name: title = yewoKb5dkfHu1xEZMAsY+' :'+name
			else: title = yewoKb5dkfHu1xEZMAsY
			if type=='ALL_ITEMS_FILTER': CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,url,514,HQmDERMFjx,HQmDERMFjx,CEniUGWr4jMy)
			elif type=='SPECIFIED_FILTER' and rrdHuNZaRCOviqPmS4szhD0VcEjM3[-2]+'=' in eA0pnTuMvxrdmoRC9zPBh:
				jDcWv7MAkEV = kYrMAXxe9EJoR8zOuvQ6(RRDtwVh6LbFiEycHNQkId5Cefmq,url)
				CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,jDcWv7MAkEV,511)
			else: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,url,515,HQmDERMFjx,HQmDERMFjx,CEniUGWr4jMy)
	return
def jlZtWwMfosJFIKenicqU1(Eya9L4IY3GxqtNoVWegDcPuOR,mode):
	Eya9L4IY3GxqtNoVWegDcPuOR = Eya9L4IY3GxqtNoVWegDcPuOR.replace('=&','=0&')
	Eya9L4IY3GxqtNoVWegDcPuOR = Eya9L4IY3GxqtNoVWegDcPuOR.strip('&')
	AAwtDoF34Y890RXse = {}
	if '=' in Eya9L4IY3GxqtNoVWegDcPuOR:
		items = Eya9L4IY3GxqtNoVWegDcPuOR.split('&')
		for A07BpVeRJToLb in items:
			airVhHdqCb6Gf49eERSjv1,value = A07BpVeRJToLb.split('=')
			AAwtDoF34Y890RXse[airVhHdqCb6Gf49eERSjv1] = value
	n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6 = HQmDERMFjx
	for key in xSMWIOb5tFvh:
		if key in list(AAwtDoF34Y890RXse.keys()): value = AAwtDoF34Y890RXse[key]
		else: value = '0'
		if '%' not in value: value = VVkOtyQLzxBr(value)
		if mode=='modified_values' and value!='0': n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6 = n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6+' + '+value
		elif mode=='modified_filters' and value!='0': n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6 = n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6+'&'+key+'='+value
		elif mode=='all_filters': n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6 = n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6+'&'+key+'='+value
	n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6 = n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6.strip(' + ')
	n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6 = n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6.strip('&')
	n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6 = n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6.replace('=0','=')
	return n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6
rrdHuNZaRCOviqPmS4szhD0VcEjM3 = []
xSMWIOb5tFvh = []
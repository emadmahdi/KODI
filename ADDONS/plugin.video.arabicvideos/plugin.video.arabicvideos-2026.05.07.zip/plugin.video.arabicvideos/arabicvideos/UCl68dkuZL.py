# -*- coding: utf-8 -*-
from FF68kA5BUy import *
HDLtdMAy7wPkl8aKC3O2 = 'MOVS4U'
EEJvXQzSZNt = '_M4U_'
e2VR8nohduY = Jzthpc2nj5.SITESURLS[HDLtdMAy7wPkl8aKC3O2][0]
FwhZ0nXtpoHTMarf = ['انواع افلام','جودات افلام']
def kk6X5LxpsND(mode,url,text):
	if   mode==380: zLZUkrP7ac5 = afkxo7FyZWB4O6K1eXrs5I()
	elif mode==381: zLZUkrP7ac5 = c8wfGju4CWZm(url,text)
	elif mode==382: zLZUkrP7ac5 = f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url)
	elif mode==383: zLZUkrP7ac5 = XONC9osGSP4fW5HVrhM(url)
	elif mode==389: zLZUkrP7ac5 = hm4kawIPKp3oMrC75dJZA9HS2(text)
	else: zLZUkrP7ac5 = False
	return zLZUkrP7ac5
def afkxo7FyZWB4O6K1eXrs5I():
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'بحث في الموقع',HQmDERMFjx,389,HQmDERMFjx,HQmDERMFjx,'_REMEMBERRESULTS_')
	CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+'المميزة',e2VR8nohduY,381,HQmDERMFjx,HQmDERMFjx,'featured')
	CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+'الجانبية',e2VR8nohduY,381,HQmDERMFjx,HQmDERMFjx,'sider')
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(H5x4Z2qPwR8vXM,'GET',e2VR8nohduY,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'MOVS4U-MENU-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	items = DyVGS3dX0ZxR.findall('<header>.*?<h2>(.*?)<',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	for AeXOdC4y3QVZgjMDn8 in range(len(items)):
		title = items[AeXOdC4y3QVZgjMDn8]
		CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+title,e2VR8nohduY,381,HQmDERMFjx,HQmDERMFjx,'latest'+str(AeXOdC4y3QVZgjMDn8))
	MJ2gSPyTl9hzoi1 = HQmDERMFjx
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('class="menu"(.*?)id="contenedor"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1: MJ2gSPyTl9hzoi1 += Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('class="sidebar(.*?)aside',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1: MJ2gSPyTl9hzoi1 += Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	items = DyVGS3dX0ZxR.findall('href="(.*?)">(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	B1eTDbEXUfs8lqtywGoFC3jRc29 = True
	for vn1grP3y4It9GmVuBbLJfz2A,title in items:
		title = SVsiEWeRf6oIynqQx8pCrM4Tk(title)
		if title=='الأعلى مشاهدة':
			if B1eTDbEXUfs8lqtywGoFC3jRc29:
				title = 'الافلام '+title
				B1eTDbEXUfs8lqtywGoFC3jRc29 = False
			else: title = 'المسلسلات '+title
		if title not in FwhZ0nXtpoHTMarf:
			CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,381)
	return CzNPJydxQLfw27tv4ZF8KORAbX5
def c8wfGju4CWZm(url,type):
	MJ2gSPyTl9hzoi1,items = [],[]
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'MOVS4U-TITLES-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	if type=='search':
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('class="search-page"(.*?)class="sidebar',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
			MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
			items = DyVGS3dX0ZxR.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	elif type=='sider':
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('class="widget(.*?)class="widget',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		fGyl2NMIhtwki6sgqY8Fv7zUdOLH0 = DyVGS3dX0ZxR.findall('href="(.*?)".*?img src="(.*?)".*?<h3>(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		Na8vklCpUGYIzP0bjutWOT,eXfxRim3IPS4h60sVTqKWOU1FaurAo,gBzGTxKMSVWFLPvfAI0UZ98D5 = zip(*fGyl2NMIhtwki6sgqY8Fv7zUdOLH0)
		items = zip(eXfxRim3IPS4h60sVTqKWOU1FaurAo,Na8vklCpUGYIzP0bjutWOT,gBzGTxKMSVWFLPvfAI0UZ98D5)
	elif type=='featured':
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('id="slider-movies-tvshows"(.*?)<header>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	elif 'latest' in type:
		AeXOdC4y3QVZgjMDn8 = int(type[-1:])
		CzNPJydxQLfw27tv4ZF8KORAbX5 = CzNPJydxQLfw27tv4ZF8KORAbX5.replace('<header>','<end><start>')
		CzNPJydxQLfw27tv4ZF8KORAbX5 = CzNPJydxQLfw27tv4ZF8KORAbX5.replace('<div class="sidebar','<end><div class="sidebar')
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('<start>(.*?)<end>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[AeXOdC4y3QVZgjMDn8]
		if AeXOdC4y3QVZgjMDn8==2: items = DyVGS3dX0ZxR.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	else:
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('class="content"(.*?)class="(pagination|sidebar)',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
			MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0][0]
			if '/collection/' in url:
				items = DyVGS3dX0ZxR.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
			elif '/quality/' in url:
				items = DyVGS3dX0ZxR.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	if not items and MJ2gSPyTl9hzoi1:
		items = DyVGS3dX0ZxR.findall('img src="(.*?)".*?href=.*?href="(.*?)">(.*?)</div>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	ORMkTYjJ1p7 = []
	for uIGD4vZcP61QNmw78LXqoEpH,vn1grP3y4It9GmVuBbLJfz2A,title in items:
		if 'serie' in title:
			title = DyVGS3dX0ZxR.findall('^(.*?)<.*?serie">(.*?)<',title,DyVGS3dX0ZxR.DOTALL)
			title = title[0][1]
			if title in ORMkTYjJ1p7: continue
			ORMkTYjJ1p7.append(title)
			title = '_MOD_'+title
		eyLMq9Enup0jiJT42RDWafg = DyVGS3dX0ZxR.findall('^(.*?)<',title,DyVGS3dX0ZxR.DOTALL)
		if eyLMq9Enup0jiJT42RDWafg: title = eyLMq9Enup0jiJT42RDWafg[0]
		title = SVsiEWeRf6oIynqQx8pCrM4Tk(title)
		if '/tvshows/' in vn1grP3y4It9GmVuBbLJfz2A: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,383,uIGD4vZcP61QNmw78LXqoEpH)
		elif '/episodes/' in vn1grP3y4It9GmVuBbLJfz2A: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,383,uIGD4vZcP61QNmw78LXqoEpH)
		elif '/seasons/' in vn1grP3y4It9GmVuBbLJfz2A: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,383,uIGD4vZcP61QNmw78LXqoEpH)
		elif '/collection/' in vn1grP3y4It9GmVuBbLJfz2A: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,381,uIGD4vZcP61QNmw78LXqoEpH)
		else: CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,382,uIGD4vZcP61QNmw78LXqoEpH)
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('class="pagination".*?Page (.*?) of (.*?)<(.*?)</div>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		XjJGsulb8Yi9V1Hma = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0][0]
		ij3m0WRQquGYX7aoLvfpk4UgyE = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0][1]
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0][2]
		items = DyVGS3dX0ZxR.findall("href='(.*?)'.*?>(.*?)<",MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,title in items:
			if title==HQmDERMFjx or title==ij3m0WRQquGYX7aoLvfpk4UgyE: continue
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'صفحة '+title,vn1grP3y4It9GmVuBbLJfz2A,381,HQmDERMFjx,HQmDERMFjx,type)
		vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A.replace('/page/'+title+xufJqQcGnhboiVy2wd,'/page/'+ij3m0WRQquGYX7aoLvfpk4UgyE+xufJqQcGnhboiVy2wd)
		CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'اخر صفحة '+ij3m0WRQquGYX7aoLvfpk4UgyE,vn1grP3y4It9GmVuBbLJfz2A,381,HQmDERMFjx,HQmDERMFjx,type)
	return
def XONC9osGSP4fW5HVrhM(url):
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'MOVS4U-EPISODES-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	WWbJG6CrUL4tIRsjpNV = DyVGS3dX0ZxR.findall('class="C rated".*?>(.*?)<',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if WWbJG6CrUL4tIRsjpNV and UzSYuZp3Pnhf1W4wyx7Fc0JX6jNb(HDLtdMAy7wPkl8aKC3O2,url,WWbJG6CrUL4tIRsjpNV,False):
		CfgK4s13Q0hZcHyleT2bVJO9('link',EEJvXQzSZNt+'المسلسل للكبار والمبرمج منعه',HQmDERMFjx,9999)
		return
	if '/episodes/' in url or '/tvshows/' in url:
		SSHjMN4uegZfb2 = DyVGS3dX0ZxR.findall('''class='item'><a href="(.*?)"''',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if SSHjMN4uegZfb2:
			SSHjMN4uegZfb2 = SSHjMN4uegZfb2[1]
			XONC9osGSP4fW5HVrhM(SSHjMN4uegZfb2)
			return
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('''class='episodios'(.*?)id="cast"''',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('''src='(.*?)'.*?class='numerando'>(.*?)<.*?href='(.*?)'>(.*?)<''',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for uIGD4vZcP61QNmw78LXqoEpH,yTz8SOkAhu24j6apo9BmZHvwWsX,vn1grP3y4It9GmVuBbLJfz2A,name in items:
			title = yTz8SOkAhu24j6apo9BmZHvwWsX+' : '+name+' الحلقة'
			CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,382)
	return
def f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url):
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'MOVS4U-PLAY-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	WWbJG6CrUL4tIRsjpNV = DyVGS3dX0ZxR.findall('class="C rated".*?>(.*?)<',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if WWbJG6CrUL4tIRsjpNV and UzSYuZp3Pnhf1W4wyx7Fc0JX6jNb(HDLtdMAy7wPkl8aKC3O2,url,WWbJG6CrUL4tIRsjpNV): return
	Na8vklCpUGYIzP0bjutWOT = []
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('''id='player-option-1'(.*?)class=("sheader"|'pag_episodes')''',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0][0]
		items = DyVGS3dX0ZxR.findall("data-url='(.*?)'.*?class='server'>(.*?)<",MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,title in items:
			vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A+'?named='+title+'__watch'
			Na8vklCpUGYIzP0bjutWOT.append(vn1grP3y4It9GmVuBbLJfz2A)
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('class="remodal"(.*?)class="remodal-close"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('class="___dl_gdrive.*?href="(.*?)".*?">(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,title in items:
			vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+vn1grP3y4It9GmVuBbLJfz2A
			vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A+'?named='+title+'__download'
			Na8vklCpUGYIzP0bjutWOT.append(vn1grP3y4It9GmVuBbLJfz2A)
	import NsD5AomUqH
	NsD5AomUqH.NZcWGBmgFEen5hvJjUSIzOCVk7(Na8vklCpUGYIzP0bjutWOT,HDLtdMAy7wPkl8aKC3O2,'video',url)
	return
def hm4kawIPKp3oMrC75dJZA9HS2(search):
	search,GXVabd4sc2u3zp0JI,showDialogs = x0pzMENwy84tBcZvXr(search)
	if search==HQmDERMFjx: search = q156m84QoYrn()
	if search==HQmDERMFjx: return
	search = search.replace(oQpxmKiRPlHeGsLXNrJF78O,'+')
	url = e2VR8nohduY+'/?s='+search
	c8wfGju4CWZm(url,'search')
	return
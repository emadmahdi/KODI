﻿# -*- coding: utf-8 -*-
from FF68kA5BUy import *
HDLtdMAy7wPkl8aKC3O2 = 'ALMAAREF'
headers = {'User-Agent':HQmDERMFjx}
EEJvXQzSZNt = '_MRF_'
e2VR8nohduY = Jzthpc2nj5.SITESURLS[HDLtdMAy7wPkl8aKC3O2][0]
FwhZ0nXtpoHTMarf = ['التواصل الاجتماعي','صور التواصل الاجتماعي','أرشيف جميع البرامج']
def kk6X5LxpsND(mode,url,text,zmL397efNlks5uTEV):
	if   mode==40: zLZUkrP7ac5 = afkxo7FyZWB4O6K1eXrs5I()
	elif mode==41: zLZUkrP7ac5 = eY4DutR9cHF()
	elif mode==42: zLZUkrP7ac5 = H1DRU435Ws(text,zmL397efNlks5uTEV)
	elif mode==43: zLZUkrP7ac5 = f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url)
	elif mode==44: zLZUkrP7ac5 = c8wfGju4CWZm(text,zmL397efNlks5uTEV)
	elif mode==49: zLZUkrP7ac5 = hm4kawIPKp3oMrC75dJZA9HS2(text)
	else: zLZUkrP7ac5 = False
	return zLZUkrP7ac5
def afkxo7FyZWB4O6K1eXrs5I():
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'بحث في الموقع',HQmDERMFjx,49)
	CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	CfgK4s13Q0hZcHyleT2bVJO9('live',EEJvXQzSZNt+'البث الحي لقناة المعارف',HQmDERMFjx,41)
	H1DRU435Ws(HQmDERMFjx,'1')
	return
def TTeIXmzC0cZtoE79hGRJPS(GXVabd4sc2u3zp0JI,N25ftd3Pb9cjHkLRz):
	search,sort,ww3gmiXOLR0S,WF2vkePC5gbXAGUarcqlpmB3Q,v2qM67cXi1pfatJL = HQmDERMFjx,[],[],[],[]
	RZ9V4eABCTfIO1FUrz2ks5DSwu,gPsU3YOHmDh5SCjM2xRFK4GA7 = Oy2YNHPzuJl(GXVabd4sc2u3zp0JI)
	for yewoKb5dkfHu1xEZMAsY in list(gPsU3YOHmDh5SCjM2xRFK4GA7.keys()):
		value = gPsU3YOHmDh5SCjM2xRFK4GA7[yewoKb5dkfHu1xEZMAsY]
		if not value: continue
		if   yewoKb5dkfHu1xEZMAsY=='sort': sort = [value]
		elif yewoKb5dkfHu1xEZMAsY=='series': ww3gmiXOLR0S = [value]
		elif yewoKb5dkfHu1xEZMAsY=='search': search = value
		elif yewoKb5dkfHu1xEZMAsY=='category': WF2vkePC5gbXAGUarcqlpmB3Q = [value]
		elif yewoKb5dkfHu1xEZMAsY=='specialist': v2qM67cXi1pfatJL = [value]
	QRw49Dc0SXgn6lzP5jFBe = {"action":"facetwp_refresh","data":{"facets":{"search":search,"video_categories":WF2vkePC5gbXAGUarcqlpmB3Q,"specialist":v2qM67cXi1pfatJL,"series":ww3gmiXOLR0S,"number":[],"sort_video":sort,"count":[],"pagination":[]},"frozen_facets":{},"template":"video_desktop_posts","extras":{"sort":"default"},"soft_refresh":0,"is_bfcache":1,"first_load":0,"paged":int(N25ftd3Pb9cjHkLRz)}}
	QRw49Dc0SXgn6lzP5jFBe = IsGwR1YyfQqa4picCZ6m.dumps(QRw49Dc0SXgn6lzP5jFBe)
	vn1grP3y4It9GmVuBbLJfz2A = 'https://almaaref.ch/wp-json/facetwp/v1/refresh'
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'POST',vn1grP3y4It9GmVuBbLJfz2A,QRw49Dc0SXgn6lzP5jFBe,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'ALMAAREF-REQUEST_DATA_PAGE-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	data = aknZqSJyUrFgc9VhH2Psot6e7b8('dict',CzNPJydxQLfw27tv4ZF8KORAbX5)
	return data
def H1DRU435Ws(GXVabd4sc2u3zp0JI,level):
	bUzHWnGg5t1 = TTeIXmzC0cZtoE79hGRJPS(GXVabd4sc2u3zp0JI,'1')
	MJ2gSPyTl9hzoi1 = bUzHWnGg5t1['facets']
	if level=='1':
		MJ2gSPyTl9hzoi1 = MJ2gSPyTl9hzoi1['video_categories']
		items = DyVGS3dX0ZxR.findall('<div(.*?)/div>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for A07BpVeRJToLb in items:
			ccmtSYej7D = DyVGS3dX0ZxR.findall('data-value=\\"(.*?)\\".*?display-value\\">(.*?)<',A07BpVeRJToLb+'<',DyVGS3dX0ZxR.DOTALL)
			if not ccmtSYej7D: ccmtSYej7D = DyVGS3dX0ZxR.findall('data-value=\\"(.*?)\\">(.*?)<',A07BpVeRJToLb+'<',DyVGS3dX0ZxR.DOTALL)
			WF2vkePC5gbXAGUarcqlpmB3Q,title = ccmtSYej7D[0]
			if C6H1qXua3SMQiIrzxNvJWZE: title = ArwuTXMNsaO9fmjWdI(title)
			if not GXVabd4sc2u3zp0JI: CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+title,HQmDERMFjx,42,HQmDERMFjx,'2','?category='+WF2vkePC5gbXAGUarcqlpmB3Q)
			else: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,HQmDERMFjx,42,HQmDERMFjx,'2',GXVabd4sc2u3zp0JI+'&category='+WF2vkePC5gbXAGUarcqlpmB3Q)
	if level=='2':
		MJ2gSPyTl9hzoi1 = MJ2gSPyTl9hzoi1['specialist']
		items = DyVGS3dX0ZxR.findall('value="(.*?)".*?>(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for v2qM67cXi1pfatJL,title in items:
			if C6H1qXua3SMQiIrzxNvJWZE: title = ArwuTXMNsaO9fmjWdI(title)
			if not v2qM67cXi1pfatJL: title = title = 'الجميع'
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,HQmDERMFjx,42,HQmDERMFjx,'3',GXVabd4sc2u3zp0JI+'&specialist='+v2qM67cXi1pfatJL)
	elif level=='3':
		MJ2gSPyTl9hzoi1 = MJ2gSPyTl9hzoi1['series']
		items = DyVGS3dX0ZxR.findall('value="(.*?)".*?>(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for ww3gmiXOLR0S,title in items:
			if C6H1qXua3SMQiIrzxNvJWZE: title = ArwuTXMNsaO9fmjWdI(title)
			if not ww3gmiXOLR0S: title = title = 'الجميع'
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,HQmDERMFjx,42,HQmDERMFjx,'4',GXVabd4sc2u3zp0JI+'&series='+ww3gmiXOLR0S)
	elif level=='4':
		MJ2gSPyTl9hzoi1 = MJ2gSPyTl9hzoi1['sort_video']
		items = DyVGS3dX0ZxR.findall('value="(.*?)".*?>(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for sort,title in items:
			if not sort: continue
			if C6H1qXua3SMQiIrzxNvJWZE: title = ArwuTXMNsaO9fmjWdI(title)
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,HQmDERMFjx,44,HQmDERMFjx,'1',GXVabd4sc2u3zp0JI+'&sort='+sort)
	return
def c8wfGju4CWZm(GXVabd4sc2u3zp0JI,N25ftd3Pb9cjHkLRz):
	bUzHWnGg5t1 = TTeIXmzC0cZtoE79hGRJPS(GXVabd4sc2u3zp0JI,N25ftd3Pb9cjHkLRz)
	MJ2gSPyTl9hzoi1 = bUzHWnGg5t1['template']
	items = DyVGS3dX0ZxR.findall('src="(.*?)".*?href="(.*?)">(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	for uIGD4vZcP61QNmw78LXqoEpH,vn1grP3y4It9GmVuBbLJfz2A,title in items:
		if C6H1qXua3SMQiIrzxNvJWZE: title = ArwuTXMNsaO9fmjWdI(title)
		CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,43,uIGD4vZcP61QNmw78LXqoEpH)
	MJ2gSPyTl9hzoi1 = bUzHWnGg5t1['facets']['pagination']
	items = DyVGS3dX0ZxR.findall('data-page="(.*?)">(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	for zmL397efNlks5uTEV,title in items:
		if N25ftd3Pb9cjHkLRz==zmL397efNlks5uTEV: continue
		if C6H1qXua3SMQiIrzxNvJWZE: title = ArwuTXMNsaO9fmjWdI(title)
		CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'صفحة '+title,HQmDERMFjx,44,HQmDERMFjx,zmL397efNlks5uTEV,GXVabd4sc2u3zp0JI)
	return
def f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url):
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'ALMAAREF-PLAY-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	vn1grP3y4It9GmVuBbLJfz2A = DyVGS3dX0ZxR.findall('<video src="(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if not vn1grP3y4It9GmVuBbLJfz2A: vn1grP3y4It9GmVuBbLJfz2A = DyVGS3dX0ZxR.findall('youtube_url.*?(http.*?)&',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	KWnAuJIFyESQHjP3X5xzMqUbR6L = []
	if vn1grP3y4It9GmVuBbLJfz2A:
		vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A[0].replace('\/',xufJqQcGnhboiVy2wd)
		KWnAuJIFyESQHjP3X5xzMqUbR6L.append(vn1grP3y4It9GmVuBbLJfz2A)
	import NsD5AomUqH
	NsD5AomUqH.NZcWGBmgFEen5hvJjUSIzOCVk7(KWnAuJIFyESQHjP3X5xzMqUbR6L,HDLtdMAy7wPkl8aKC3O2,'video',url)
	return
def eY4DutR9cHF():
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(H5x4Z2qPwR8vXM,'GET',e2VR8nohduY+'/البث-المباشر-6',HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'ALMAAREF-LIVE-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	url = DyVGS3dX0ZxR.findall('data-item=.*?(http.*?)&',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	url = url[0].replace('\/',xufJqQcGnhboiVy2wd)
	uZVS3DcJbEULoxpve9IOTgmW6(url,HDLtdMAy7wPkl8aKC3O2,'live')
	return
def hm4kawIPKp3oMrC75dJZA9HS2(search):
	search,GXVabd4sc2u3zp0JI,showDialogs = x0pzMENwy84tBcZvXr(search)
	nnFcLJ7vY8Q = False
	if search==HQmDERMFjx:
		search = q156m84QoYrn()
		nnFcLJ7vY8Q = True
	if search==HQmDERMFjx: return
	if not nnFcLJ7vY8Q: c8wfGju4CWZm('?search='+search,'1')
	else: H1DRU435Ws('?search='+search,'1')
	return
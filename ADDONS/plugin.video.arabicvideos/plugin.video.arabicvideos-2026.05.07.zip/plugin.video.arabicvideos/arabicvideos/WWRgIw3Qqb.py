# -*- coding: utf-8 -*-
import sys as TPW58slaVE9OrYQXZnGo2yAfFzpBxc
tbYWAoeMyHTsgFG5x6huz1 = TPW58slaVE9OrYQXZnGo2yAfFzpBxc.version_info [0] == 2
CUJSAbZztE8vYdGByLH0KcnWqe = 2048
R0QCXnpyL1DJwBH67FW = 7
def kSod2AxqugH0 (LURfCucn30xKsMdTiG):
	global ghCyPxkWILcXrGjVut6MQo59fsv
	MfIpC9TDz7Qa5g2vVqPtXh4 = ord (LURfCucn30xKsMdTiG [-1])
	nndScZEtapB74 = LURfCucn30xKsMdTiG [:-1]
	LRbqugZJAa3192OCewWGHvEcP = MfIpC9TDz7Qa5g2vVqPtXh4 % len (nndScZEtapB74)
	qLc7RGgDQE = nndScZEtapB74 [:LRbqugZJAa3192OCewWGHvEcP] + nndScZEtapB74 [LRbqugZJAa3192OCewWGHvEcP:]
	if tbYWAoeMyHTsgFG5x6huz1:
		XUczap3yA0QqFRC82OH6E5mL = unicode () .join ([unichr (ord (ah5u39EBY81MlrwA0cmoz4ngb7TLed) - CUJSAbZztE8vYdGByLH0KcnWqe - (YMjpxPr8WsJ1Bg6Xd + MfIpC9TDz7Qa5g2vVqPtXh4) % R0QCXnpyL1DJwBH67FW) for YMjpxPr8WsJ1Bg6Xd, ah5u39EBY81MlrwA0cmoz4ngb7TLed in enumerate (qLc7RGgDQE)])
	else:
		XUczap3yA0QqFRC82OH6E5mL = str () .join ([chr (ord (ah5u39EBY81MlrwA0cmoz4ngb7TLed) - CUJSAbZztE8vYdGByLH0KcnWqe - (YMjpxPr8WsJ1Bg6Xd + MfIpC9TDz7Qa5g2vVqPtXh4) % R0QCXnpyL1DJwBH67FW) for YMjpxPr8WsJ1Bg6Xd, ah5u39EBY81MlrwA0cmoz4ngb7TLed in enumerate (qLc7RGgDQE)])
	return eval (XUczap3yA0QqFRC82OH6E5mL)
jL1E5AKfwBDv6xmeQtUXcJ3d,JJA7fypmZFVlazvNI,dBi72erQEtKDOwjNFaoAgSP=kSod2AxqugH0,kSod2AxqugH0,kSod2AxqugH0
CDwSWB4v39N7,k4IUieraScH9DV1N7pJgQosYAx5l,Tcf5Ppn9UajDbzyM=dBi72erQEtKDOwjNFaoAgSP,JJA7fypmZFVlazvNI,jL1E5AKfwBDv6xmeQtUXcJ3d
X2crmy67eZpkGTRd,HDpmv4UXzlf72SK9,C3ZK1pu4rfmj8TsWUtBaM=Tcf5Ppn9UajDbzyM,k4IUieraScH9DV1N7pJgQosYAx5l,CDwSWB4v39N7
mg3CbXMA2ouZzQDhRqB,OBsrtQo2pPlgURCxJYbj9iXMD,ssnfOzb16wVog9GKdqcXR3JC7ktSPA=C3ZK1pu4rfmj8TsWUtBaM,HDpmv4UXzlf72SK9,X2crmy67eZpkGTRd
ShnRVsifKtc60zqQ,KKi79PFqsYB0dWSRgaJ3DyE,OzU6t0qcH7MQabeBYK8vgoG=ssnfOzb16wVog9GKdqcXR3JC7ktSPA,OBsrtQo2pPlgURCxJYbj9iXMD,mg3CbXMA2ouZzQDhRqB
mgLADoQ1pbtY,U0VwOviFaYPz2QGs45mJhMXf7Zk,pCTzbw4GyVJHjkcIMQ=OzU6t0qcH7MQabeBYK8vgoG,KKi79PFqsYB0dWSRgaJ3DyE,ShnRVsifKtc60zqQ
owbMhINBQsmx70guApW,SODvU3Ibq5VzC,PPAUFrY8cduRT=pCTzbw4GyVJHjkcIMQ,U0VwOviFaYPz2QGs45mJhMXf7Zk,mgLADoQ1pbtY
knTyjJ0sGIzuwbxRae,nz8x32hX0qcjUPFZk5RdJsiwED,A0aqj9uclgOtByJ6F4bz=PPAUFrY8cduRT,SODvU3Ibq5VzC,owbMhINBQsmx70guApW
YJxaX0MQOHb8oyCBFdnIAe,n6sfYuHBlVdzgmvpXwR3irON0KIj8,LHX65I9nkx0PstgcVY24uSi=A0aqj9uclgOtByJ6F4bz,nz8x32hX0qcjUPFZk5RdJsiwED,knTyjJ0sGIzuwbxRae
EAVanJj1ers2GQud,ELfMeDTIFhJt685K,EF2tvxZHz5n4UruPhaViXKycI6SQR=LHX65I9nkx0PstgcVY24uSi,n6sfYuHBlVdzgmvpXwR3irON0KIj8,YJxaX0MQOHb8oyCBFdnIAe
KhUG1NV9bln5zXjptqFW6dgo,cWbkR6iUZsnJQj14,maUl7SPesynF1j=EF2tvxZHz5n4UruPhaViXKycI6SQR,ELfMeDTIFhJt685K,EAVanJj1ers2GQud
from FF68kA5BUy import *
HDLtdMAy7wPkl8aKC3O2 = LHX65I9nkx0PstgcVY24uSi(u"࠭ࡒࡂࡐࡇࡓࡒ࡙ࠧ᳑")
EEJvXQzSZNt = U0VwOviFaYPz2QGs45mJhMXf7Zk(u"ࠧࡠࡎࡖࡘࡤ࠭᳒")
xg58yJ9YKiPbnoupDIwsqOC2m6H3 = ihRKM0HpwdVstIF2ZjuTeCmXG
t5KxA9pi7BmC = LHX65I9nkx0PstgcVY24uSi(u"࠴࠴Ἵ")
def kk6X5LxpsND(lXBL3WrM2JFYm,url,NN9niuC7RoqmhkL2,zmL397efNlks5uTEV,GoC84Eq3azJwpSWxkctF1MdTruOIyb):
	try: fyJ27mwDtuZgzKXG6jbE = str(GoC84Eq3azJwpSWxkctF1MdTruOIyb[SODvU3Ibq5VzC(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᳓")])
	except: fyJ27mwDtuZgzKXG6jbE = HQmDERMFjx
	if   lXBL3WrM2JFYm==jL1E5AKfwBDv6xmeQtUXcJ3d(u"࠵࠻࠶Ἶ"): zLZUkrP7ac5 = afkxo7FyZWB4O6K1eXrs5I()
	elif lXBL3WrM2JFYm==knTyjJ0sGIzuwbxRae(u"࠶࠼࠱Ἷ"): zLZUkrP7ac5 = Hu3IMT8Nh1e9aA(NN9niuC7RoqmhkL2)
	elif lXBL3WrM2JFYm==mgLADoQ1pbtY(u"࠷࠶࠳ὀ"): zLZUkrP7ac5 = CdKgn9oB4GQA(NN9niuC7RoqmhkL2,mgLADoQ1pbtY(u"࠷࠶࠳ὀ"))
	elif lXBL3WrM2JFYm==X2crmy67eZpkGTRd(u"࠱࠷࠵ὁ"): zLZUkrP7ac5 = CdKgn9oB4GQA(NN9niuC7RoqmhkL2,X2crmy67eZpkGTRd(u"࠱࠷࠵ὁ"))
	elif lXBL3WrM2JFYm==knTyjJ0sGIzuwbxRae(u"࠲࠸࠷ὂ"): zLZUkrP7ac5 = f7v1Cc8JjIDpSyoi6FWgtzNh2KM(NN9niuC7RoqmhkL2)
	elif lXBL3WrM2JFYm==SODvU3Ibq5VzC(u"࠳࠹࠹ὃ"): zLZUkrP7ac5 = atk5xn9cpgzvi3dGmyMXs6rhLF(url,NN9niuC7RoqmhkL2)
	elif lXBL3WrM2JFYm==PPAUFrY8cduRT(u"࠴࠺࠻ὄ"): zLZUkrP7ac5 = SS3ukvBbjKrAVci4F(url,NN9niuC7RoqmhkL2)
	elif lXBL3WrM2JFYm==cWbkR6iUZsnJQj14(u"࠵࠻࠽ὅ"): zLZUkrP7ac5 = ni8TFoORQ5WBLC4tck(url,NN9niuC7RoqmhkL2)
	elif lXBL3WrM2JFYm==ELfMeDTIFhJt685K(u"࠶࠼࠸὆"): zLZUkrP7ac5 = RpWGSOYl1PsITL7wZeiH8(url,NN9niuC7RoqmhkL2)
	elif lXBL3WrM2JFYm==owbMhINBQsmx70guApW(u"࠽࠶࠲὇"): zLZUkrP7ac5 = HHGmc3tr6iW2IhjR()
	elif lXBL3WrM2JFYm==PPAUFrY8cduRT(u"࠷࠷࠴Ὀ"): zLZUkrP7ac5 = kzvZlKBpT5nq9oOL2ijDUeg()
	elif lXBL3WrM2JFYm==jL1E5AKfwBDv6xmeQtUXcJ3d(u"࠸࠸࠶Ὁ"): zLZUkrP7ac5 = TPQsa58vBGdnY21HrR7zCWKj(fyJ27mwDtuZgzKXG6jbE,NN9niuC7RoqmhkL2,zmL397efNlks5uTEV)
	elif lXBL3WrM2JFYm==A0aqj9uclgOtByJ6F4bz(u"࠹࠹࠸Ὂ"): zLZUkrP7ac5 = nYNwJg6aXqbyGLStfj9sQoRUxT(fyJ27mwDtuZgzKXG6jbE,NN9niuC7RoqmhkL2)
	elif lXBL3WrM2JFYm==jL1E5AKfwBDv6xmeQtUXcJ3d(u"࠺࠺࠺Ὃ"): zLZUkrP7ac5 = fbiJ0Tl6sV7ntHBZoIz3F(fyJ27mwDtuZgzKXG6jbE,NN9niuC7RoqmhkL2)
	else: zLZUkrP7ac5 = mic3MEN709xOkrjD5ZvbGIlX6
	return zLZUkrP7ac5
def afkxo7FyZWB4O6K1eXrs5I():
	CfgK4s13Q0hZcHyleT2bVJO9(k4IUieraScH9DV1N7pJgQosYAx5l(u"ࠩࡩࡳࡱࡪࡥࡳ᳔ࠩ"),EF2tvxZHz5n4UruPhaViXKycI6SQR(u"ࠪๆ๋๎วหࠢอ่ๆุ๊้่ࠣ฽ู๎วว์ฬ᳕ࠫ"),HQmDERMFjx,nz8x32hX0qcjUPFZk5RdJsiwED(u"࠵࠻࠷Ὄ"),HQmDERMFjx,HQmDERMFjx,dBi72erQEtKDOwjNFaoAgSP(u"ࠫࡤࡒࡉࡗࡇࡗ࡚ࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡ᳖ࠪ"))
	CfgK4s13Q0hZcHyleT2bVJO9(maUl7SPesynF1j(u"ࠬ࡬࡯࡭ࡦࡨࡶ᳗ࠬ"),LHX65I9nkx0PstgcVY24uSi(u"࠭โิ็ࠣ฽ู๎วว์᳘ࠪ"),HQmDERMFjx,ShnRVsifKtc60zqQ(u"࠶࠼࠲Ὅ"),HQmDERMFjx,HQmDERMFjx,LHX65I9nkx0PstgcVY24uSi(u"ࠧࡠࡕࡌࡘࡊ࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢ᳙ࠫ"))
	CfgK4s13Q0hZcHyleT2bVJO9(PPAUFrY8cduRT(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᳚"),SODvU3Ibq5VzC(u"ࠩไ๎ิ๐่่ษอࠤ฾ฺ่ศศํอࠬ᳛"),HQmDERMFjx,C3ZK1pu4rfmj8TsWUtBaM(u"࠷࠶࠴὎"),HQmDERMFjx,HQmDERMFjx,PPAUFrY8cduRT(u"ࠪࡣࡘࡏࡔࡆࡕࡢࡣࡗࡇࡎࡅࡑࡐࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ᳜"))
	CfgK4s13Q0hZcHyleT2bVJO9(maUl7SPesynF1j(u"ࠫ࡫ࡵ࡬ࡥࡧࡵ᳝ࠫ"),A0aqj9uclgOtByJ6F4bz(u"ࠬ็๊ะ์๋๋ฬะࠠษฯฮࠤ฾ฺ่ศศํ᳞ࠫ"),HQmDERMFjx,n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"࠱࠷࠶὏"),HQmDERMFjx,HQmDERMFjx,knTyjJ0sGIzuwbxRae(u"࠭࡟ࡔࡋࡗࡉࡘࡥ࡟ࡓࡃࡑࡈࡔࡓ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢ᳟ࠫ"))
	CfgK4s13Q0hZcHyleT2bVJO9(EF2tvxZHz5n4UruPhaViXKycI6SQR(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᳠"),A0aqj9uclgOtByJ6F4bz(u"ࠨใํำ๏๎็ศฬࠣ฽ู๎วว์ฬࠤ๊์ࠠใี่ࠫ᳡"),HQmDERMFjx,U0VwOviFaYPz2QGs45mJhMXf7Zk(u"࠸࠸࠶ὐ"),HQmDERMFjx,HQmDERMFjx,dBi72erQEtKDOwjNFaoAgSP(u"ࠩࡢࡗࡎ࡚ࡅࡔࡡࡢࡖࡆࡔࡄࡐࡏࡢ᳢ࠫ"))
	CfgK4s13Q0hZcHyleT2bVJO9(ShnRVsifKtc60zqQ(u"ࠪࡰ࡮ࡴ࡫ࠨ᳣"),ao3Q5jP8H0sMxK2iUYwZGE+n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"ࠫࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾᳤ࠢࠪ")+cjqzOQ5GXD4kR,HQmDERMFjx,EAVanJj1ers2GQud(u"࠻࠼࠽࠾ὑ"))
	CfgK4s13Q0hZcHyleT2bVJO9(jL1E5AKfwBDv6xmeQtUXcJ3d(u"ࠬ࡬࡯࡭ࡦࡨࡶ᳥ࠬ"),Tcf5Ppn9UajDbzyM(u"࠭โ็๊สฮࠥࡓ࠳ࡖࠢ฼ุํอฦ๋ห᳦ࠪ"),HQmDERMFjx,ELfMeDTIFhJt685K(u"࠴࠺࠸ὒ"),HQmDERMFjx,HQmDERMFjx,Tcf5Ppn9UajDbzyM(u"ࠧࡠࡏ࠶࡙ࡤࡥࡌࡊࡘࡈࡣࡤࡘࡁࡏࡆࡒࡑࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠ᳧ࠩ"))
	CfgK4s13Q0hZcHyleT2bVJO9(U0VwOviFaYPz2QGs45mJhMXf7Zk(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᳨"),maUl7SPesynF1j(u"ࠩไ๎ิ๐่่ษอࠤࡒ࠹ࡕࠡ฻ื์ฬฬ๊สࠩᳩ"),HQmDERMFjx,maUl7SPesynF1j(u"࠵࠻࠹ὓ"),HQmDERMFjx,HQmDERMFjx,k4IUieraScH9DV1N7pJgQosYAx5l(u"ࠪࡣࡒ࠹ࡕࡠࡡ࡙ࡓࡉࡥ࡟ࡓࡃࡑࡈࡔࡓ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᳪ"))
	CfgK4s13Q0hZcHyleT2bVJO9(n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᳫ"),CDwSWB4v39N7(u"่ࠬำๆࠢๅ๊ํอสࠡࡏ࠶࡙ࠥ฿ิ้ษษ๎ࠬᳬ"),HQmDERMFjx,mg3CbXMA2ouZzQDhRqB(u"࠶࠼࠲ὔ"),HQmDERMFjx,HQmDERMFjx,A0aqj9uclgOtByJ6F4bz(u"࠭࡟ࡎ࠵ࡘࡣࡤࡒࡉࡗࡇࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥ᳭ࠧ"))
	CfgK4s13Q0hZcHyleT2bVJO9(HDpmv4UXzlf72SK9(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᳮ"),HDpmv4UXzlf72SK9(u"ࠨไึ้ࠥ็๊ะ์๋ࠤࡒ࠹ࡕࠡ฻ื์ฬฬ๊ࠨᳯ"),HQmDERMFjx,ShnRVsifKtc60zqQ(u"࠷࠶࠳ὕ"),HQmDERMFjx,HQmDERMFjx,JJA7fypmZFVlazvNI(u"ࠩࡢࡑ࠸࡛࡟ࡠࡘࡒࡈࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᳰ"))
	CfgK4s13Q0hZcHyleT2bVJO9(YJxaX0MQOHb8oyCBFdnIAe(u"ࠪࡪࡴࡲࡤࡦࡴࠪᳱ"),ShnRVsifKtc60zqQ(u"ࠫๆ๐ฯ๋๊๊หฯࠦࡍ࠴ࡗࠣฬาัฺࠠึ๋หห๐ࠧᳲ"),HQmDERMFjx,nz8x32hX0qcjUPFZk5RdJsiwED(u"࠱࠷࠶ὖ"),HQmDERMFjx,HQmDERMFjx,cWbkR6iUZsnJQj14(u"ࠬࡥࡍ࠴ࡗࡢࡣࡗࡇࡎࡅࡑࡐࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᳳ"))
	CfgK4s13Q0hZcHyleT2bVJO9(LHX65I9nkx0PstgcVY24uSi(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭᳴"),OzU6t0qcH7MQabeBYK8vgoG(u"ࠧโ์า๎ํํวหࠢࡐ࠷ู࡚ࠦี๊สส๏ฯࠠๆ่ࠣๆุ๋ࠧᳵ"),HQmDERMFjx,mgLADoQ1pbtY(u"࠸࠸࠸ὗ"),HQmDERMFjx,HQmDERMFjx,mg3CbXMA2ouZzQDhRqB(u"ࠨࡡࡐ࠷࡚ࡥ࡟ࡓࡃࡑࡈࡔࡓ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᳶ"))
	CfgK4s13Q0hZcHyleT2bVJO9(dBi72erQEtKDOwjNFaoAgSP(u"ࠩ࡯࡭ࡳࡱࠧ᳷"),ao3Q5jP8H0sMxK2iUYwZGE+X2crmy67eZpkGTRd(u"ࠪࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡࠩ᳸")+cjqzOQ5GXD4kR,HQmDERMFjx,dBi72erQEtKDOwjNFaoAgSP(u"࠻࠼࠽࠾὘"))
	CfgK4s13Q0hZcHyleT2bVJO9(C3ZK1pu4rfmj8TsWUtBaM(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ᳹"),mgLADoQ1pbtY(u"่ࠬๆ้ษอࠤࡎࡖࡔࡗࠢ฼ุํอฦ๋หࠪᳺ"),HQmDERMFjx,U0VwOviFaYPz2QGs45mJhMXf7Zk(u"࠴࠺࠸Ὑ"),HQmDERMFjx,HQmDERMFjx,k4IUieraScH9DV1N7pJgQosYAx5l(u"࠭࡟ࡊࡒࡗ࡚ࡤࡥࡌࡊࡘࡈࡣࡤࡘࡁࡏࡆࡒࡑࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ᳻"))
	CfgK4s13Q0hZcHyleT2bVJO9(JJA7fypmZFVlazvNI(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᳼"),mg3CbXMA2ouZzQDhRqB(u"ࠨใํำ๏๎็ศฬࠣࡍࡕ࡚ࡖࠡ฻ื์ฬฬ๊สࠩ᳽"),HQmDERMFjx,U0VwOviFaYPz2QGs45mJhMXf7Zk(u"࠵࠻࠹὚"),HQmDERMFjx,HQmDERMFjx,mgLADoQ1pbtY(u"ࠩࡢࡍࡕ࡚ࡖࡠࡡ࡙ࡓࡉࡥ࡟ࡓࡃࡑࡈࡔࡓ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ᳾"))
	CfgK4s13Q0hZcHyleT2bVJO9(X2crmy67eZpkGTRd(u"ࠪࡪࡴࡲࡤࡦࡴࠪ᳿"),KKi79PFqsYB0dWSRgaJ3DyE(u"ࠫ็ูๅࠡไ้์ฬะࠠࡊࡒࡗ࡚ࠥ฿ิ้ษษ๎ࠬᴀ"),HQmDERMFjx,JJA7fypmZFVlazvNI(u"࠶࠼࠲Ὓ"),HQmDERMFjx,HQmDERMFjx,k4IUieraScH9DV1N7pJgQosYAx5l(u"ࠬࡥࡉࡑࡖ࡙ࡣࡤࡒࡉࡗࡇࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧᴁ"))
	CfgK4s13Q0hZcHyleT2bVJO9(jL1E5AKfwBDv6xmeQtUXcJ3d(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᴂ"),U0VwOviFaYPz2QGs45mJhMXf7Zk(u"ࠧใี่ࠤๆ๐ฯ๋๊ࠣࡍࡕ࡚ࡖࠡ฻ื์ฬฬ๊ࠨᴃ"),HQmDERMFjx,n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"࠷࠶࠳὜"),HQmDERMFjx,HQmDERMFjx,JJA7fypmZFVlazvNI(u"ࠨࡡࡌࡔ࡙࡜࡟ࡠࡘࡒࡈࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᴄ"))
	CfgK4s13Q0hZcHyleT2bVJO9(X2crmy67eZpkGTRd(u"ࠩࡩࡳࡱࡪࡥࡳࠩᴅ"),jL1E5AKfwBDv6xmeQtUXcJ3d(u"ࠪๅ๏ี๊้้สฮࠥࡏࡐࡕࡘࠣฬาัฺࠠึ๋หห๐ࠧᴆ"),HQmDERMFjx,LHX65I9nkx0PstgcVY24uSi(u"࠱࠷࠶Ὕ"),HQmDERMFjx,HQmDERMFjx,OzU6t0qcH7MQabeBYK8vgoG(u"ࠫࡤࡏࡐࡕࡘࡢࡣࡗࡇࡎࡅࡑࡐࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᴇ"))
	CfgK4s13Q0hZcHyleT2bVJO9(n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᴈ"),ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"࠭แ๋ัํ์์อสࠡࡋࡓࡘู࡛ࠦี๊สส๏ฯࠠๆ่ࠣๆุ๋ࠧᴉ"),HQmDERMFjx,U0VwOviFaYPz2QGs45mJhMXf7Zk(u"࠸࠸࠷὞"),HQmDERMFjx,HQmDERMFjx,HDpmv4UXzlf72SK9(u"ࠧࡠࡋࡓࡘ࡛ࡥ࡟ࡓࡃࡑࡈࡔࡓ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᴊ"))
	return
def HHGmc3tr6iW2IhjR():
	CfgK4s13Q0hZcHyleT2bVJO9(SODvU3Ibq5VzC(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᴋ"),KKi79PFqsYB0dWSRgaJ3DyE(u"ࠩࡢࡍࡕ࡚࡟ࠨᴌ")+OzU6t0qcH7MQabeBYK8vgoG(u"ࠪๅ๏ี๊้้สฮࠥาๅ๋฻ࠣࡍࡕ࡚ࡖࠨᴍ"),HQmDERMFjx,HDpmv4UXzlf72SK9(u"࠹࠹࠸Ὗ"))
	CfgK4s13Q0hZcHyleT2bVJO9(mgLADoQ1pbtY(u"ࠫࡱ࡯࡮࡬ࠩᴎ"),ao3Q5jP8H0sMxK2iUYwZGE+EF2tvxZHz5n4UruPhaViXKycI6SQR(u"ࠬࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࠪᴏ")+cjqzOQ5GXD4kR,HQmDERMFjx,maUl7SPesynF1j(u"࠼࠽࠾࠿ὠ"))
	for fyJ27mwDtuZgzKXG6jbE in range(CH7RKuDVzN9f06q8MtXPhlvIxakEWg,L3C1YrQDi840ShlOJcNGe+CH7RKuDVzN9f06q8MtXPhlvIxakEWg):
		EEJvXQzSZNt = EF2tvxZHz5n4UruPhaViXKycI6SQR(u"࠭࡟ࡊࡒࠪᴐ")+str(fyJ27mwDtuZgzKXG6jbE)+ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"ࠧࡠࠩᴑ")
		CfgK4s13Q0hZcHyleT2bVJO9(HDpmv4UXzlf72SK9(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᴒ"),EEJvXQzSZNt+YJxaX0MQOHb8oyCBFdnIAe(u"ࠩࠣๅ๏ี๊้้สฮ๋ࠥฬๅัࠣࠫᴓ")+ccoph2TqA8fJG4KO6YRwm[fyJ27mwDtuZgzKXG6jbE],HQmDERMFjx,YJxaX0MQOHb8oyCBFdnIAe(u"࠻࠻࠺ὡ"),HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,{OBsrtQo2pPlgURCxJYbj9iXMD(u"ࠪࡪࡴࡲࡤࡦࡴࠪᴔ"):fyJ27mwDtuZgzKXG6jbE})
	return
def kzvZlKBpT5nq9oOL2ijDUeg():
	CfgK4s13Q0hZcHyleT2bVJO9(X2crmy67eZpkGTRd(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᴕ"),cWbkR6iUZsnJQj14(u"ࠬࡥࡍ࠴ࡗࡢࠫᴖ")+X2crmy67eZpkGTRd(u"࠭แ๋ัํ์์อสࠡฮ่๎฾ࠦࡍ࠴ࡗࠪᴗ"),HQmDERMFjx,nz8x32hX0qcjUPFZk5RdJsiwED(u"࠼࠼࠵ὢ"))
	CfgK4s13Q0hZcHyleT2bVJO9(Tcf5Ppn9UajDbzyM(u"ࠧ࡭࡫ࡱ࡯ࠬᴘ"),ao3Q5jP8H0sMxK2iUYwZGE+knTyjJ0sGIzuwbxRae(u"ࠨ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥ࠭ᴙ")+cjqzOQ5GXD4kR,HQmDERMFjx,C3ZK1pu4rfmj8TsWUtBaM(u"࠿࠹࠺࠻ὣ"))
	for fyJ27mwDtuZgzKXG6jbE in range(CH7RKuDVzN9f06q8MtXPhlvIxakEWg,L3C1YrQDi840ShlOJcNGe+CH7RKuDVzN9f06q8MtXPhlvIxakEWg):
		EEJvXQzSZNt = HDpmv4UXzlf72SK9(u"ࠩࡢࡑ࡚࠭ᴚ")+str(fyJ27mwDtuZgzKXG6jbE)+X2crmy67eZpkGTRd(u"ࠪࡣࠬᴛ")
		CfgK4s13Q0hZcHyleT2bVJO9(mgLADoQ1pbtY(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᴜ"),EEJvXQzSZNt+HDpmv4UXzlf72SK9(u"ࠬࠦแ๋ัํ์์อสࠡ็ฯ่ิࠦࠧᴝ")+ccoph2TqA8fJG4KO6YRwm[fyJ27mwDtuZgzKXG6jbE],HQmDERMFjx,ShnRVsifKtc60zqQ(u"࠷࠷࠷ὤ"),HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,{YJxaX0MQOHb8oyCBFdnIAe(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᴞ"):fyJ27mwDtuZgzKXG6jbE})
	return
def UuLBv1Ghj3ETiQVq(ZvCajmoUedFL):
	global nD5ejWhQV108OocGbP9ai6g,dzltDXSU4y18IoOA2p7i6Cnr
	ddCehb9TygPN5HnMZKBEJA3W42romX,yG0k5pe3mH2,TZRm3tqUKHucWGQ9h08 = h8J6YwoHNtia4LXDVjs0GbW(ZvCajmoUedFL)
	try:
		if ELfMeDTIFhJt685K(u"ࠧࡊࡈࡌࡐࡒ࠭ᴟ") in ZvCajmoUedFL: ddCehb9TygPN5HnMZKBEJA3W42romX(ZvCajmoUedFL)
		else: ddCehb9TygPN5HnMZKBEJA3W42romX()
		Z7ZLxTFXKdYgkm1BJyq08aUW = mic3MEN709xOkrjD5ZvbGIlX6
	except:
		s1s8Ub3WODAlkq5zSnP()
		Z7ZLxTFXKdYgkm1BJyq08aUW = gyd2rf0UR5
	ZvCajmoUedFL = oFLajW6gOrufM7I(ZvCajmoUedFL)
	if Z7ZLxTFXKdYgkm1BJyq08aUW:
		x8a2FGB1jAef94byI(ZvCajmoUedFL,mg3CbXMA2ouZzQDhRqB(u"ࠨใื่๊ࠥไฤีไࠫᴠ"),jHWkt18govGwY7iUbduAfxCyRc=ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"࠳࠲࠳࠴ὥ"))
		nD5ejWhQV108OocGbP9ai6g += CH7RKuDVzN9f06q8MtXPhlvIxakEWg
		dzltDXSU4y18IoOA2p7i6Cnr += knTyjJ0sGIzuwbxRae(u"ࠩࠣ࠲ࠥ࠭ᴡ")+ZvCajmoUedFL
	else: x8a2FGB1jAef94byI(ZvCajmoUedFL,HQmDERMFjx,jHWkt18govGwY7iUbduAfxCyRc=CDwSWB4v39N7(u"࠳࠳࠴࠵ὦ"))
	return
f9n0wLB5oxavA = {}
def XxspN4wUYiuK50fvbCB1LAk(DR3Xo2cMv1=gyd2rf0UR5):
	global nD5ejWhQV108OocGbP9ai6g,dzltDXSU4y18IoOA2p7i6Cnr,f9n0wLB5oxavA
	if not DR3Xo2cMv1:
		f9n0wLB5oxavA = FcSRPu295Ot1Jv0Bip3IDom(rDy4FoKpEOsXfT8WZjli,YJxaX0MQOHb8oyCBFdnIAe(u"ࠪࡨ࡮ࡩࡴࠨᴢ"),ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡓࡊࡖࡈࡗࠬᴣ"),nz8x32hX0qcjUPFZk5RdJsiwED(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡔࡋࡗࡉࡘࡥࡁࡍࡎࠪᴤ"))
		if f9n0wLB5oxavA: return
	N7gs9UBCeDR3 = HUJZy0SrTbBYv1(X2crmy67eZpkGTRd(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ᴥ"),HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,maUl7SPesynF1j(u"ࠧฮฬ์ࠤฯ๋ไว๊ࠢิ์ࠦวๅไสส๊ฯࠠ࠯࠰ࠣื๏็อึࠢส่อืๆศ็ฯࠤัฺ๋๊่ࠢ์ฬู่ࠡษ็ๅ๏ี๊้ࠢส่ฯ๐ࠠโ์ࠣห้ฮั็ษ่ะࠥำส๊ࠢํืฯิัอ่๊ࠢ์อࠠโไฺࠤฬ๊รใีส้ࠥอไาศํื๏ฯࠠ࠯࠰ࠣฯ๊๊ࠦใ๊่ࠤฬ๊ศา่ส้ัࠦศฯิ้ࠤ์ึ็ࠡษ็ว็ูวๆࠢะฮ๎ࠦไศࠢอัฯอฬࠡล้ࠤฯ๋ไว้สࠤ๊ืษࠡลัี๎ࠦ࠮࠯๊ࠢิ์ࠦวๅ฻่่๏ฯࠠหฯอหัูࠦศัฬࠤศ่ไࠡ็้ࠤ࠸ࠦฯใษษๆࠥࡢ࡮࡝ࡰࠪᴦ")+ao3Q5jP8H0sMxK2iUYwZGE+n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"ࠨ้็ࠤฯื๊ะࠢฦ๊ࠥะฬๆ฻ࠣๆฬฬๅสࠢส่ศ่ำศ็ࠣห้ศๆࠡมࠪᴧ")+cjqzOQ5GXD4kR)
	if N7gs9UBCeDR3!=CH7RKuDVzN9f06q8MtXPhlvIxakEWg: return
	XgW8wuKsyUDpmRQvSV0cNfhxAiFJE(xjD4NgpEkFCrnw8S,xjD4NgpEkFCrnw8S,xjD4NgpEkFCrnw8S)
	LLtZOlNzAC = Jzthpc2nj5.menuItemsLIST
	nD5ejWhQV108OocGbP9ai6g,dzltDXSU4y18IoOA2p7i6Cnr,s1sxIwDh4blF = o4bNzIQGYj8En,HQmDERMFjx,{}
	for ZvCajmoUedFL in HCGlQVYcUfeuShJXAjv02n9KNEO:
		jHWkt18govGwY7iUbduAfxCyRc.sleep(CH7RKuDVzN9f06q8MtXPhlvIxakEWg)
		s1sxIwDh4blF[ZvCajmoUedFL] = Lk21XpCMZto(daemon=gyd2rf0UR5,target=UuLBv1Ghj3ETiQVq,args=(ZvCajmoUedFL,))
		s1sxIwDh4blF[ZvCajmoUedFL].start()
	else:
		for ZvCajmoUedFL in list(s1sxIwDh4blF.keys()): s1sxIwDh4blF[ZvCajmoUedFL].join()
	Jzthpc2nj5.menuItemsLIST[:] = LLtZOlNzAC
	f9n0wLB5oxavA = {}
	for ZvCajmoUedFL in list(s1sxIwDh4blF.keys()):
		try: K8plWsxgVjoSbCm = Jzthpc2nj5.menuItemsDICT[ZvCajmoUedFL]
		except: continue
		ZvCajmoUedFL = YJxaX0MQOHb8oyCBFdnIAe(u"ࠩࡢࡐࡘ࡚࡟ࠨᴨ")+oFLajW6gOrufM7I(ZvCajmoUedFL)
		for arsOBITUkup7x3eSfEvM,XyOvPTlmBK4hDVjfi,GUiCEYZjm5,lXBL3WrM2JFYm,Hdtu4n2qcfGBjV,JTMSUFcWn0XQa63GBI9qEAk7,NN9niuC7RoqmhkL2,wWqEgiB75LpjyPuaDTOU,xxwvNBlKpYESrqo0hPcdsutR in K8plWsxgVjoSbCm:
			if not XyOvPTlmBK4hDVjfi: XyOvPTlmBK4hDVjfi = KhUG1NV9bln5zXjptqFW6dgo(u"ࠪ࠲࠳࠴࠮ࠨᴩ")
			else:
				if XyOvPTlmBK4hDVjfi.count(KKi79PFqsYB0dWSRgaJ3DyE(u"ࠫࡤ࠭ᴪ"))>CH7RKuDVzN9f06q8MtXPhlvIxakEWg: XyOvPTlmBK4hDVjfi = XyOvPTlmBK4hDVjfi.split(YJxaX0MQOHb8oyCBFdnIAe(u"ࠬࡥࠧᴫ"),FFHRwuxQmbh8BaTqyX3)[FFHRwuxQmbh8BaTqyX3]
				XyOvPTlmBK4hDVjfi = XyOvPTlmBK4hDVjfi.replace(KKi79PFqsYB0dWSRgaJ3DyE(u"࠭ࢠࠨᴬ"),HQmDERMFjx).replace(SODvU3Ibq5VzC(u"ࠧࠡࡊࡇࠫᴭ"),HQmDERMFjx).replace(knTyjJ0sGIzuwbxRae(u"ࠨࡊࡇࠤࠬᴮ"),HQmDERMFjx)
				XyOvPTlmBK4hDVjfi = XyOvPTlmBK4hDVjfi.replace(mg3CbXMA2ouZzQDhRqB(u"ࠩใࠫᴯ"),HQmDERMFjx).replace(C3ZK1pu4rfmj8TsWUtBaM(u"ࠪอࠬᴰ"),YJxaX0MQOHb8oyCBFdnIAe(u"ࠫ์࠭ᴱ")).replace(C3ZK1pu4rfmj8TsWUtBaM(u"ࠬสࠧᴲ"),OBsrtQo2pPlgURCxJYbj9iXMD(u"่࠭ࠨᴳ"))
				XyOvPTlmBK4hDVjfi = XyOvPTlmBK4hDVjfi.replace(X2crmy67eZpkGTRd(u"ࠧฤࠩᴴ"),k4IUieraScH9DV1N7pJgQosYAx5l(u"ࠨษࠪᴵ")).replace(LHX65I9nkx0PstgcVY24uSi(u"ࠩศࠫᴶ"),maUl7SPesynF1j(u"ࠪหࠬᴷ")).replace(jL1E5AKfwBDv6xmeQtUXcJ3d(u"ࠫว࠭ᴸ"),JJA7fypmZFVlazvNI(u"ࠬอࠧᴹ"))
				XyOvPTlmBK4hDVjfi = XyOvPTlmBK4hDVjfi.replace(Tcf5Ppn9UajDbzyM(u"࠭ไฤࠩᴺ"),owbMhINBQsmx70guApW(u"ࠧๅษࠪᴻ")).replace(X2crmy67eZpkGTRd(u"ࠨๆศࠫᴼ"),knTyjJ0sGIzuwbxRae(u"ࠩ็หࠬᴽ")).replace(CDwSWB4v39N7(u"่ࠪว࠭ᴾ"),A0aqj9uclgOtByJ6F4bz(u"้ࠫอࠧᴿ"))
				XyOvPTlmBK4hDVjfi = XyOvPTlmBK4hDVjfi.replace(LHX65I9nkx0PstgcVY24uSi(u"ࠬ๔ࠧᵀ"),HQmDERMFjx).replace(ELfMeDTIFhJt685K(u"๋࠭ࠨᵁ"),HQmDERMFjx).replace(KhUG1NV9bln5zXjptqFW6dgo(u"ࠧ๐ࠩᵂ"),HQmDERMFjx).replace(JJA7fypmZFVlazvNI(u"ࠨ๎ࠪᵃ"),HQmDERMFjx)
				XyOvPTlmBK4hDVjfi = XyOvPTlmBK4hDVjfi.replace(knTyjJ0sGIzuwbxRae(u"ࠩ๓ࠫᵄ"),HQmDERMFjx).replace(KKi79PFqsYB0dWSRgaJ3DyE(u"ࠪ๑ࠬᵅ"),HQmDERMFjx).replace(X2crmy67eZpkGTRd(u"ࠫ๗࠭ᵆ"),HQmDERMFjx).replace(KKi79PFqsYB0dWSRgaJ3DyE(u"ࠬ๗ࠧᵇ"),HQmDERMFjx)
				XyOvPTlmBK4hDVjfi = XyOvPTlmBK4hDVjfi.replace(OBsrtQo2pPlgURCxJYbj9iXMD(u"࠭ࡼࠨᵈ"),HQmDERMFjx).replace(ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"ࠧࡿࠩᵉ"),HQmDERMFjx)
				XyOvPTlmBK4hDVjfi = XyOvPTlmBK4hDVjfi.replace(YJxaX0MQOHb8oyCBFdnIAe(u"ࠨษ๋๊๊ࠥว๋่ࠪᵊ"),HQmDERMFjx).replace(X2crmy67eZpkGTRd(u"ࠩึ๎๊อࠠๅษํฮࠬᵋ"),HQmDERMFjx)
				SSAyIPL70dqUTGNnBgolzFsDj4m = [A0aqj9uclgOtByJ6F4bz(u"ࠪห้฿วษࠩᵌ"),CDwSWB4v39N7(u"ࠫำ๐วๅࠩᵍ"),pCTzbw4GyVJHjkcIMQ(u"ࠬอไษ๊่ࠫᵎ"),OBsrtQo2pPlgURCxJYbj9iXMD(u"࠭วๅษ้ࠫᵏ"),JJA7fypmZFVlazvNI(u"ࠧศูไห้࠭ᵐ"),JJA7fypmZFVlazvNI(u"ࠨฯส่๏ํࠧᵑ"),JJA7fypmZFVlazvNI(u"ࠩส่฿อาࠨᵒ"),X2crmy67eZpkGTRd(u"ูࠪฬ๊อࠨᵓ"),ELfMeDTIFhJt685K(u"ࠫฬ๊ฯ๋่ࠪᵔ"),EAVanJj1ers2GQud(u"๋่ࠬศๆํำࠬᵕ"),Tcf5Ppn9UajDbzyM(u"࠭วๅ฻ส่๊࠭ᵖ"),SODvU3Ibq5VzC(u"ࠧศ฻่ห้࠭ᵗ")]
				if not any(RrgIp9Xsn5dPufHT in XyOvPTlmBK4hDVjfi for RrgIp9Xsn5dPufHT in SSAyIPL70dqUTGNnBgolzFsDj4m): XyOvPTlmBK4hDVjfi = XyOvPTlmBK4hDVjfi.replace(YJxaX0MQOHb8oyCBFdnIAe(u"ࠨษ็ࠫᵘ"),HQmDERMFjx)
				XyOvPTlmBK4hDVjfi = XyOvPTlmBK4hDVjfi.replace(mg3CbXMA2ouZzQDhRqB(u"ࠩสาึ๐ࠧᵙ"),jL1E5AKfwBDv6xmeQtUXcJ3d(u"ࠪหำื้ࠨᵚ")).replace(U0VwOviFaYPz2QGs45mJhMXf7Zk(u"ࠫฬาๆษ๋ࠪᵛ"),X2crmy67eZpkGTRd(u"ࠬอฬ็สํࠫᵜ")).replace(OBsrtQo2pPlgURCxJYbj9iXMD(u"ู࠭ศศ็๎์࠭ᵝ"),CDwSWB4v39N7(u"ฺࠧษษ่๏࠭ᵞ"))
				XyOvPTlmBK4hDVjfi = XyOvPTlmBK4hDVjfi.replace(JJA7fypmZFVlazvNI(u"ࠨษฯ๊อ๐็ࠨᵟ"),EF2tvxZHz5n4UruPhaViXKycI6SQR(u"ࠩสะ๋ฮ๊ࠨᵠ")).replace(maUl7SPesynF1j(u"ࠪ฽ึฮ๊่ࠩᵡ"),C3ZK1pu4rfmj8TsWUtBaM(u"ࠫ฾ืศ๋ࠩᵢ")).replace(EAVanJj1ers2GQud(u"ࠬื่ๆษ้ื๏ํࠧᵣ"),EF2tvxZHz5n4UruPhaViXKycI6SQR(u"࠭ั้็สุ๊๐ࠧᵤ"))
				XyOvPTlmBK4hDVjfi = XyOvPTlmBK4hDVjfi.replace(k4IUieraScH9DV1N7pJgQosYAx5l(u"ࠧ฻ำห๎์࠭ᵥ"),ELfMeDTIFhJt685K(u"ࠨ฼ิฬ๏࠭ᵦ")).replace(dBi72erQEtKDOwjNFaoAgSP(u"๋ࠩࠤู๊ไิๆสฮࠬᵧ"),n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"ุ้๊ࠪำๅษอࠫᵨ")).replace(KKi79PFqsYB0dWSRgaJ3DyE(u"ࠫฬเว็๋ࠪᵩ"),YJxaX0MQOHb8oyCBFdnIAe(u"ࠬอฺศ่ํࠫᵪ"))
				XyOvPTlmBK4hDVjfi = XyOvPTlmBK4hDVjfi.replace(U0VwOviFaYPz2QGs45mJhMXf7Zk(u"࠭สศำํา๏࠭ᵫ"),EAVanJj1ers2GQud(u"ࠧหษิ๎ำ࠭ᵬ")).replace(k4IUieraScH9DV1N7pJgQosYAx5l(u"ࠨะํหู้ࠦๅ็ํࠫᵭ"),ShnRVsifKtc60zqQ(u"ࠩั๎ฬ๊ࠧᵮ")).replace(ShnRVsifKtc60zqQ(u"้ࠪํู๊ใ์๊ࠫᵯ"),jL1E5AKfwBDv6xmeQtUXcJ3d(u"๊ࠫ๎ำ๋ไ์ࠫᵰ"))
				XyOvPTlmBK4hDVjfi = XyOvPTlmBK4hDVjfi.replace(KhUG1NV9bln5zXjptqFW6dgo(u"ࠬํๆะ๋ࠪᵱ"),PPAUFrY8cduRT(u"࠭็็ัํࠫᵲ")).replace(mg3CbXMA2ouZzQDhRqB(u"่่ࠧา๎์࠭ᵳ"),X2crmy67eZpkGTRd(u"ࠨ้้ำ๏࠭ᵴ")).replace(maUl7SPesynF1j(u"๋ࠩฯฬฬโ๋้ࠪᵵ"),nz8x32hX0qcjUPFZk5RdJsiwED(u"ࠪ์ะอฦใ์ࠪᵶ"))
				XyOvPTlmBK4hDVjfi = XyOvPTlmBK4hDVjfi.replace(U0VwOviFaYPz2QGs45mJhMXf7Zk(u"ࠫฯ๊๊โิํ์๋๐็ࠨᵷ"),cWbkR6iUZsnJQj14(u"ࠬะไโิํ์๋࠭ᵸ")).replace(A0aqj9uclgOtByJ6F4bz(u"࠭สๅใี๎ํ์๊่ࠩᵹ"),KKi79PFqsYB0dWSRgaJ3DyE(u"ࠧหๆไึ๏๎ๆࠨᵺ")).replace(LHX65I9nkx0PstgcVY24uSi(u"ࠨ๊ࠣ็ึะ่็ࠩᵻ"),HDpmv4UXzlf72SK9(u"๋ࠩ็ึะ่็ࠩᵼ"))
				XyOvPTlmBK4hDVjfi = XyOvPTlmBK4hDVjfi.replace(PPAUFrY8cduRT(u"ࠪห้ำวๅ์๊ࠫᵽ"),OzU6t0qcH7MQabeBYK8vgoG(u"ࠫาอไ๋้ࠪᵾ")).replace(EAVanJj1ers2GQud(u"๋่ࠬิ໎ๅ๎ࠬᵿ"),U0VwOviFaYPz2QGs45mJhMXf7Zk(u"࠭ๅ้ีํๆ๎࠭ᶀ")).replace(maUl7SPesynF1j(u"ࠧศๆส๊๊๐ࠧᶁ"),ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"ࠨษ้้๏࠭ᶂ"))
				XyOvPTlmBK4hDVjfi = XyOvPTlmBK4hDVjfi.replace(KKi79PFqsYB0dWSRgaJ3DyE(u"ࠩสู่๊ไิๆสฮࠬᶃ"),maUl7SPesynF1j(u"ุ้๊ࠪำๅษอࠫᶄ")).replace(YJxaX0MQOHb8oyCBFdnIAe(u"ࠫฬ๊ศาษ่ะࠬᶅ"),PPAUFrY8cduRT(u"ࠬฮัศ็ฯࠫᶆ")).replace(C3ZK1pu4rfmj8TsWUtBaM(u"࠭ใศำอ์๋࠭ᶇ"),U0VwOviFaYPz2QGs45mJhMXf7Zk(u"ࠧไำอ์๋࠭ᶈ"))
				XyOvPTlmBK4hDVjfi = XyOvPTlmBK4hDVjfi.replace(X2crmy67eZpkGTRd(u"ࠨฯิ์อ࠭ᶉ"),n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"ࠩะีอ࠭ᶊ")).replace(JJA7fypmZFVlazvNI(u"ࠪห้อๆศึํำࠬᶋ"),X2crmy67eZpkGTRd(u"ࠫฬ์วี์าࠫᶌ")).replace(knTyjJ0sGIzuwbxRae(u"ࠬอำ๋๊ํ๋ࠬᶍ"),ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"࠭วิ์๋๎ࠬᶎ"))
				XyOvPTlmBK4hDVjfi = XyOvPTlmBK4hDVjfi.replace(X2crmy67eZpkGTRd(u"ฺࠧำหํࠬᶏ"),U0VwOviFaYPz2QGs45mJhMXf7Zk(u"ࠨ฻ิฬ๏࠭ᶐ")).replace(LHX65I9nkx0PstgcVY24uSi(u"ࠩอี่๏ࠧᶑ"),ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"ࠪฮึ้๊ࠨᶒ")).replace(knTyjJ0sGIzuwbxRae(u"ࠫฯืใ๋้ࠪᶓ"),A0aqj9uclgOtByJ6F4bz(u"ࠬะัไ์ࠪᶔ")).replace(mg3CbXMA2ouZzQDhRqB(u"࠭วๅ็ูหๆ࠭ᶕ"),ELfMeDTIFhJt685K(u"ࠧๆุสๅࠬᶖ"))
				XyOvPTlmBK4hDVjfi = XyOvPTlmBK4hDVjfi.replace(OBsrtQo2pPlgURCxJYbj9iXMD(u"ࠨำํห฻๐ࠧᶗ"),JJA7fypmZFVlazvNI(u"ࠩิ๎ฬ฼ษࠨᶘ")).replace(SODvU3Ibq5VzC(u"ࠪี๏อึ่ࠩᶙ"),k4IUieraScH9DV1N7pJgQosYAx5l(u"ࠫึ๐วืหࠪᶚ")).replace(KhUG1NV9bln5zXjptqFW6dgo(u"ࠬอำ๋๊ํ๋ࠬᶛ"),YJxaX0MQOHb8oyCBFdnIAe(u"࠭วิ์๋๎ࠬᶜ"))
				XyOvPTlmBK4hDVjfi = XyOvPTlmBK4hDVjfi.replace(ShnRVsifKtc60zqQ(u"ࠧไ๊่๎ิ๏ࠧᶝ"),nz8x32hX0qcjUPFZk5RdJsiwED(u"ࠨๅ๋้๏ี๊ࠨᶞ")).replace(PPAUFrY8cduRT(u"ࠩๆ์๊๐ฯ๋้ࠪᶟ"),LHX65I9nkx0PstgcVY24uSi(u"ࠪ็ํ๋๊ะ์ࠪᶠ")).replace(nz8x32hX0qcjUPFZk5RdJsiwED(u"ࠫฬ์๊ๆ์ࠪᶡ"),C3ZK1pu4rfmj8TsWUtBaM(u"ࠬอๆๆ์ࠪᶢ"))
				XyOvPTlmBK4hDVjfi = XyOvPTlmBK4hDVjfi.replace(Tcf5Ppn9UajDbzyM(u"࠭ว็์่๎ู์ࠧᶣ"),mgLADoQ1pbtY(u"ࠧศ่่๎ู์ࠧᶤ")).replace(k4IUieraScH9DV1N7pJgQosYAx5l(u"ࠨษ้้๎࠭ᶥ"),OBsrtQo2pPlgURCxJYbj9iXMD(u"ࠩส๊๊๐ิ็ࠩᶦ")).replace(U0VwOviFaYPz2QGs45mJhMXf7Zk(u"ࠪห๋๋๊ࠨᶧ"),OBsrtQo2pPlgURCxJYbj9iXMD(u"ࠫฬ์ๅ๋ึ้ࠫᶨ"))
				XyOvPTlmBK4hDVjfi = XyOvPTlmBK4hDVjfi.replace(cWbkR6iUZsnJQj14(u"ࠬอๆๆ์ืู๊์ࠧᶩ"),knTyjJ0sGIzuwbxRae(u"࠭ว็็ํุ๋࠭ᶪ")).replace(mgLADoQ1pbtY(u"ࠧศๆส๊๊๐ิ็ࠩᶫ"),k4IUieraScH9DV1N7pJgQosYAx5l(u"ࠨษ้้๏ฺๆࠨᶬ")).replace(cWbkR6iUZsnJQj14(u"ࠩสๅ้อๅࠡ็ึุ่๊วหࠩᶭ"),CDwSWB4v39N7(u"ࠪหๆ๊วๆุ๋้๊ࠢำๅษอࠫᶮ"))
				XyOvPTlmBK4hDVjfi = XyOvPTlmBK4hDVjfi.replace(MSnXBQNUg1jF3W2fRlE9OLaCT8ds4,oQpxmKiRPlHeGsLXNrJF78O).strip(Tcf5Ppn9UajDbzyM(u"ࠫ࠲࠭ᶯ")).strip(oQpxmKiRPlHeGsLXNrJF78O)
			if XyOvPTlmBK4hDVjfi not in list(f9n0wLB5oxavA.keys()): f9n0wLB5oxavA[XyOvPTlmBK4hDVjfi] = {}
			f9n0wLB5oxavA[XyOvPTlmBK4hDVjfi][ZvCajmoUedFL] = [arsOBITUkup7x3eSfEvM,XyOvPTlmBK4hDVjfi,GUiCEYZjm5,lXBL3WrM2JFYm,Hdtu4n2qcfGBjV,JTMSUFcWn0XQa63GBI9qEAk7,NN9niuC7RoqmhkL2,wWqEgiB75LpjyPuaDTOU,xxwvNBlKpYESrqo0hPcdsutR]
	HqD3sxo0fJX(rDy4FoKpEOsXfT8WZjli,PPAUFrY8cduRT(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡔࡋࡗࡉࡘ࠭ᶰ"),X2crmy67eZpkGTRd(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡕࡌࡘࡊ࡙࡟ࡂࡎࡏࠫᶱ"),f9n0wLB5oxavA,h8CF5iEB9RXNf0G)
	if nD5ejWhQV108OocGbP9ai6g>=t5KxA9pi7BmC: u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,CDwSWB4v39N7(u"ࠧๅัํ็๋ࠥิไๆฬࠤๆ๐ࠠࠨᶲ")+str(nD5ejWhQV108OocGbP9ai6g)+dBi72erQEtKDOwjNFaoAgSP(u"ࠨ่ࠢ์็฿ࠠๆ่้ࠣํอโฺࠢส่อืๆศ็ฯࠤ࠳࠴࠮๊๊ࠡ็ีอࠠๆึๆ่ฮࠦำษส๊หࠥ฿วะห้๋ࠣࠦวๅว้ฮึ์๊หࠢ฼๊ิ้้ࠠษ็้ํอโฺ๊ࠢ๎࠿࠭ᶳ")+dzltDXSU4y18IoOA2p7i6Cnr)
	u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,C3ZK1pu4rfmj8TsWUtBaM(u"ࠩอ้ࠥาไษࠢฯ้๏฿ࠠศๆฦๆุอๅࠡษ็้ฯ๎แาหࠣๅ๏ࠦวๅสิ๊ฬ๋ฬࠨᶴ"))
	XgW8wuKsyUDpmRQvSV0cNfhxAiFJE(SLgzAKNoYhFUR,SLgzAKNoYhFUR,SLgzAKNoYhFUR)
	h3e5luaABRYkZsgTVWj1OQ()
	return
def vv1GdoOpbLR2gfVxrlj4IQz9t(fyJ27mwDtuZgzKXG6jbE,LlsCEXIte1n9TG0BAVOojqyvQkhb5):
	LnricPbQjug6yt0lUIeMKpVDTa = mic3MEN709xOkrjD5ZvbGIlX6
	bIKWSZ1NoxE52mRyvQGeLuVl = Jzthpc2nj5.menuItemsLIST
	Jzthpc2nj5.menuItemsLIST[:] = []
	if LnricPbQjug6yt0lUIeMKpVDTa and knTyjJ0sGIzuwbxRae(u"ࠪࡣࡈࡘࡅࡂࡖࡈࡒࡊ࡝࡟ࠨᶵ") not in LlsCEXIte1n9TG0BAVOojqyvQkhb5:
		zLZUkrP7ac5 = FcSRPu295Ot1Jv0Bip3IDom(rDy4FoKpEOsXfT8WZjli,mg3CbXMA2ouZzQDhRqB(u"ࠫࡱ࡯ࡳࡵࠩᶶ"),SODvU3Ibq5VzC(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡊࡒࡗ࡚ࠬᶷ"),PPAUFrY8cduRT(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡋࡓࡘ࡛ࡥࠧᶸ")+fyJ27mwDtuZgzKXG6jbE)
	elif EF2tvxZHz5n4UruPhaViXKycI6SQR(u"ࠧࡠࡎࡌ࡚ࡊࡥࠧᶹ") not in LlsCEXIte1n9TG0BAVOojqyvQkhb5 or maUl7SPesynF1j(u"ࠨࡡ࡙ࡓࡉࡥࠧᶺ") not in LlsCEXIte1n9TG0BAVOojqyvQkhb5:
		import rrF9yjmgo4
		wwpQTfixYD23X = pCTzbw4GyVJHjkcIMQ(u"ࠩ็่ศูแࠡๆา๎่ࠦๅีๅ็อࠥ็๊้ࠡำหࠥอไๆ๊ๅ฽ࠥ࠴้ࠠำึห้ฯࠠศๆั฻ศࠦใศ่ࠣๅ๏ํวࠡฬไหฺ๐ไࠡษ็ู้้ไสࠢ࠱ࠤศึวࠡษ็ู้้ไสࠢ็๎ุะࠠฮฮหࠤๆาัษࠢศีุอไ้ࠡำ๋ࠥอไๆึๆ่ฮࠦลๅ๋ࠣห้๋ศา็ฯࠤ๊์ࠠใษษ้ฮࠦัิษษ่ࠥอไษำ้ห๊าࠧᶻ")
		if YJxaX0MQOHb8oyCBFdnIAe(u"ࠪࡣࡑࡏࡖࡆࡡࠪᶼ") not in LlsCEXIte1n9TG0BAVOojqyvQkhb5:
			try: rrF9yjmgo4.QQJzovgOaCt5yLFkeN(fyJ27mwDtuZgzKXG6jbE,SODvU3Ibq5VzC(u"࡛ࠫࡕࡄࡠࡗࡑࡏࡓࡕࡗࡏࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪᶽ"),HQmDERMFjx,HQmDERMFjx,LlsCEXIte1n9TG0BAVOojqyvQkhb5+A0aqj9uclgOtByJ6F4bz(u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᶾ"),mic3MEN709xOkrjD5ZvbGIlX6)
			except: u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,knTyjJ0sGIzuwbxRae(u"࠭ๅ้ไ฼ࠤๅࡏࡐࡕࡘ่้ࠣ็๊ะ์๋๋ฬะࠧᶿ"),wwpQTfixYD23X)
			try: rrF9yjmgo4.QQJzovgOaCt5yLFkeN(fyJ27mwDtuZgzKXG6jbE,LHX65I9nkx0PstgcVY24uSi(u"ࠧࡗࡑࡇࡣࡒࡕࡖࡊࡇࡖࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬ᷀"),HQmDERMFjx,HQmDERMFjx,LlsCEXIte1n9TG0BAVOojqyvQkhb5+n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭᷁"),mic3MEN709xOkrjD5ZvbGIlX6)
			except: u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,knTyjJ0sGIzuwbxRae(u"่ࠩ์็฿ࠠแࡋࡓࡘ࡛ࠦไๅใํำ๏๎็ศฬ᷂ࠪ"),wwpQTfixYD23X)
			try: rrF9yjmgo4.QQJzovgOaCt5yLFkeN(fyJ27mwDtuZgzKXG6jbE,dBi72erQEtKDOwjNFaoAgSP(u"࡚ࠪࡔࡊ࡟ࡔࡇࡕࡍࡊ࡙࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨ᷃"),HQmDERMFjx,HQmDERMFjx,LlsCEXIte1n9TG0BAVOojqyvQkhb5+LHX65I9nkx0PstgcVY24uSi(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ᷄"),mic3MEN709xOkrjD5ZvbGIlX6)
			except: u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,ELfMeDTIFhJt685K(u"๋่ࠬใ฻ࠣไࡎࡖࡔࡗࠢ็่ๆ๐ฯ๋๊๊หฯ࠭᷅"),wwpQTfixYD23X)
		if mg3CbXMA2ouZzQDhRqB(u"࠭࡟ࡗࡑࡇࡣࠬ᷆") not in LlsCEXIte1n9TG0BAVOojqyvQkhb5:
			try: rrF9yjmgo4.QQJzovgOaCt5yLFkeN(fyJ27mwDtuZgzKXG6jbE,KKi79PFqsYB0dWSRgaJ3DyE(u"ࠧࡍࡋ࡙ࡉࡤ࡛ࡎࡌࡐࡒ࡛ࡓࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧ᷇"),HQmDERMFjx,HQmDERMFjx,LlsCEXIte1n9TG0BAVOojqyvQkhb5+X2crmy67eZpkGTRd(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭᷈"),mic3MEN709xOkrjD5ZvbGIlX6)
			except: u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"่ࠩ์็฿ࠠแࡋࡓࡘ࡛ࠦไๅไ้์ฬะࠧ᷉"),wwpQTfixYD23X)
			try: rrF9yjmgo4.QQJzovgOaCt5yLFkeN(fyJ27mwDtuZgzKXG6jbE,A0aqj9uclgOtByJ6F4bz(u"ࠪࡐࡎ࡜ࡅࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅ᷊ࠩ"),HQmDERMFjx,HQmDERMFjx,LlsCEXIte1n9TG0BAVOojqyvQkhb5+maUl7SPesynF1j(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ᷋"),mic3MEN709xOkrjD5ZvbGIlX6)
			except: u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,owbMhINBQsmx70guApW(u"๋่ࠬใ฻ࠣไࡎࡖࡔࡗࠢ็่็์่ศฬࠪ᷌"),wwpQTfixYD23X)
		zLZUkrP7ac5 = Jzthpc2nj5.menuItemsLIST
		if LnricPbQjug6yt0lUIeMKpVDTa: HqD3sxo0fJX(rDy4FoKpEOsXfT8WZjli,ELfMeDTIFhJt685K(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡋࡓࡘ࡛࠭᷍"),dBi72erQEtKDOwjNFaoAgSP(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡌࡔ࡙࡜࡟ࠨ᷎")+fyJ27mwDtuZgzKXG6jbE,zLZUkrP7ac5,h8CF5iEB9RXNf0G)
	Jzthpc2nj5.menuItemsLIST[:] = bIKWSZ1NoxE52mRyvQGeLuVl
	return zLZUkrP7ac5
def gwzqWMVAEU48SdxpH9D(fyJ27mwDtuZgzKXG6jbE,LlsCEXIte1n9TG0BAVOojqyvQkhb5):
	LnricPbQjug6yt0lUIeMKpVDTa = mic3MEN709xOkrjD5ZvbGIlX6
	bIKWSZ1NoxE52mRyvQGeLuVl = Jzthpc2nj5.menuItemsLIST
	Jzthpc2nj5.menuItemsLIST[:] = []
	if LnricPbQjug6yt0lUIeMKpVDTa and maUl7SPesynF1j(u"ࠨࡡࡆࡖࡊࡇࡔࡆࡐࡈ࡛ࡤ᷏࠭") not in LlsCEXIte1n9TG0BAVOojqyvQkhb5:
		zLZUkrP7ac5 = FcSRPu295Ot1Jv0Bip3IDom(rDy4FoKpEOsXfT8WZjli,cWbkR6iUZsnJQj14(u"ࠩ࡯࡭ࡸࡺ᷐ࠧ"),mg3CbXMA2ouZzQDhRqB(u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡓ࠳ࡖࠩ᷑"),EF2tvxZHz5n4UruPhaViXKycI6SQR(u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡍ࠴ࡗࡢࠫ᷒")+fyJ27mwDtuZgzKXG6jbE)
	elif pCTzbw4GyVJHjkcIMQ(u"ࠬࡥࡌࡊࡘࡈࡣࠬᷓ") not in LlsCEXIte1n9TG0BAVOojqyvQkhb5 or EAVanJj1ers2GQud(u"࠭࡟ࡗࡑࡇࡣࠬᷔ") not in LlsCEXIte1n9TG0BAVOojqyvQkhb5:
		import BBlniQqbfT
		wwpQTfixYD23X = owbMhINBQsmx70guApW(u"ࠧๅๆฦืๆࠦไะ์ๆࠤฺ๊ใๅหࠣๅ๏ࠦ็ัษࠣห้๋่ใ฻ࠣ࠲ࠥ๎ัิษ็อࠥอไฯูฦࠤ่อๆࠡใํ๋ฬࠦสโษุ๎้ࠦวๅ็ื็้ฯࠠ࠯ࠢฦิฬࠦวๅ็ื็้ฯࠠๅ์ึฮࠥำฬษࠢไะึฮࠠฦำึห้ࠦ็ั้ࠣห้๋ิไๆฬࠤส๊้ࠡษ็้อืๅอ่๊่ࠢࠥวว็ฬࠤึูววๆࠣห้ฮั็ษ่ะࠬᷕ")
		if PPAUFrY8cduRT(u"ࠨࡡࡏࡍ࡛ࡋ࡟ࠨᷖ") not in LlsCEXIte1n9TG0BAVOojqyvQkhb5:
			try: BBlniQqbfT.QQJzovgOaCt5yLFkeN(fyJ27mwDtuZgzKXG6jbE,EAVanJj1ers2GQud(u"࡙ࠩࡓࡉࡥࡕࡏࡍࡑࡓ࡜ࡔ࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨᷗ"),HQmDERMFjx,HQmDERMFjx,LlsCEXIte1n9TG0BAVOojqyvQkhb5+ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᷘ"),mic3MEN709xOkrjD5ZvbGIlX6)
			except: u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,mg3CbXMA2ouZzQDhRqB(u"๊ࠫ๎โฺࠢใࡑ࠸࡛ࠠๅๆไ๎ิ๐่่ษอࠫᷙ"),wwpQTfixYD23X)
			try: BBlniQqbfT.QQJzovgOaCt5yLFkeN(fyJ27mwDtuZgzKXG6jbE,maUl7SPesynF1j(u"ࠬ࡜ࡏࡅࡡࡐࡓ࡛ࡏࡅࡔࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪᷚ"),HQmDERMFjx,HQmDERMFjx,LlsCEXIte1n9TG0BAVOojqyvQkhb5+pCTzbw4GyVJHjkcIMQ(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᷛ"),mic3MEN709xOkrjD5ZvbGIlX6)
			except: u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,cWbkR6iUZsnJQj14(u"ࠧๆ๊ๅ฽ࠥๆࡍ࠴ࡗ่้ࠣ็๊ะ์๋๋ฬะࠧᷜ"),wwpQTfixYD23X)
			try: BBlniQqbfT.QQJzovgOaCt5yLFkeN(fyJ27mwDtuZgzKXG6jbE,U0VwOviFaYPz2QGs45mJhMXf7Zk(u"ࠨࡘࡒࡈࡤ࡙ࡅࡓࡋࡈࡗࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭ᷝ"),HQmDERMFjx,HQmDERMFjx,LlsCEXIte1n9TG0BAVOojqyvQkhb5+U0VwOviFaYPz2QGs45mJhMXf7Zk(u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧᷞ"),mic3MEN709xOkrjD5ZvbGIlX6)
			except: u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,EF2tvxZHz5n4UruPhaViXKycI6SQR(u"้ࠪํู่ࠡโࡐ࠷࡚ࠦไๅใํำ๏๎็ศฬࠪᷟ"),wwpQTfixYD23X)
		if Tcf5Ppn9UajDbzyM(u"ࠫࡤ࡜ࡏࡅࡡࠪᷠ") not in LlsCEXIte1n9TG0BAVOojqyvQkhb5:
			try: BBlniQqbfT.QQJzovgOaCt5yLFkeN(fyJ27mwDtuZgzKXG6jbE,k4IUieraScH9DV1N7pJgQosYAx5l(u"ࠬࡒࡉࡗࡇࡢ࡙ࡓࡑࡎࡐ࡙ࡑࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬᷡ"),HQmDERMFjx,HQmDERMFjx,LlsCEXIte1n9TG0BAVOojqyvQkhb5+C3ZK1pu4rfmj8TsWUtBaM(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᷢ"),mic3MEN709xOkrjD5ZvbGIlX6)
			except: u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,ELfMeDTIFhJt685K(u"ࠧๆ๊ๅ฽ࠥๆࡍ࠴ࡗ่้่ࠣๆ้ษอࠫᷣ"),wwpQTfixYD23X)
			try: BBlniQqbfT.QQJzovgOaCt5yLFkeN(fyJ27mwDtuZgzKXG6jbE,jL1E5AKfwBDv6xmeQtUXcJ3d(u"ࠨࡎࡌ࡚ࡊࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧᷤ"),HQmDERMFjx,HQmDERMFjx,LlsCEXIte1n9TG0BAVOojqyvQkhb5+PPAUFrY8cduRT(u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧᷥ"),mic3MEN709xOkrjD5ZvbGIlX6)
			except: u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,k4IUieraScH9DV1N7pJgQosYAx5l(u"้ࠪํู่ࠡโࡐ࠷࡚ࠦไๅไ้์ฬะࠧᷦ"),wwpQTfixYD23X)
		zLZUkrP7ac5 = Jzthpc2nj5.menuItemsLIST
		if LnricPbQjug6yt0lUIeMKpVDTa: HqD3sxo0fJX(rDy4FoKpEOsXfT8WZjli,ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡍ࠴ࡗࠪᷧ"),HDpmv4UXzlf72SK9(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡎ࠵ࡘࡣࠬᷨ")+fyJ27mwDtuZgzKXG6jbE,zLZUkrP7ac5,h8CF5iEB9RXNf0G)
	Jzthpc2nj5.menuItemsLIST[:] = bIKWSZ1NoxE52mRyvQGeLuVl
	return zLZUkrP7ac5
def TPQsa58vBGdnY21HrR7zCWKj(fyJ27mwDtuZgzKXG6jbE,LlsCEXIte1n9TG0BAVOojqyvQkhb5,eKrCqWnGBufF2):
	XgW8wuKsyUDpmRQvSV0cNfhxAiFJE(xWfmqtAck6vZbDhoda73GNrOHnKpjF,xWfmqtAck6vZbDhoda73GNrOHnKpjF,xjD4NgpEkFCrnw8S)
	if eKrCqWnGBufF2: XxspN4wUYiuK50fvbCB1LAk(mic3MEN709xOkrjD5ZvbGIlX6)
	elif EF2tvxZHz5n4UruPhaViXKycI6SQR(u"࠭࡟ࡄࡔࡈࡅ࡙ࡋࡎࡆ࡙ࡢࠫᷩ") in LlsCEXIte1n9TG0BAVOojqyvQkhb5 and not eKrCqWnGBufF2: XxspN4wUYiuK50fvbCB1LAk(gyd2rf0UR5)
	aNGfo9USX3678MunH = LlsCEXIte1n9TG0BAVOojqyvQkhb5.replace(YJxaX0MQOHb8oyCBFdnIAe(u"ࠧࡠࡅࡕࡉࡆ࡚ࡅࡏࡇ࡚ࡣࠬᷪ"),HQmDERMFjx).replace(nz8x32hX0qcjUPFZk5RdJsiwED(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᷫ"),HQmDERMFjx).replace(maUl7SPesynF1j(u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᷬ"),HQmDERMFjx)
	if not eKrCqWnGBufF2:
		CfgK4s13Q0hZcHyleT2bVJO9(jL1E5AKfwBDv6xmeQtUXcJ3d(u"ࠪࡰ࡮ࡴ࡫ࠨᷭ"),cWbkR6iUZsnJQj14(u"ࠫฯำฯ๋อࠣๆฬฬๅสࠢส่ศ่ำศ็ࠪᷮ"),HQmDERMFjx,U0VwOviFaYPz2QGs45mJhMXf7Zk(u"࠺࠺࠸ὧ"),HQmDERMFjx,HQmDERMFjx,EF2tvxZHz5n4UruPhaViXKycI6SQR(u"ࠬࡥࡃࡓࡇࡄࡘࡊࡔࡅࡘࡡࠪᷯ")+aNGfo9USX3678MunH,HQmDERMFjx,{nz8x32hX0qcjUPFZk5RdJsiwED(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᷰ"):fyJ27mwDtuZgzKXG6jbE})
		CfgK4s13Q0hZcHyleT2bVJO9(C3ZK1pu4rfmj8TsWUtBaM(u"ࠧ࡭࡫ࡱ࡯ࠬᷱ"),ao3Q5jP8H0sMxK2iUYwZGE+CDwSWB4v39N7(u"ࠨ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥ࠭ᷲ")+cjqzOQ5GXD4kR,HQmDERMFjx,OBsrtQo2pPlgURCxJYbj9iXMD(u"࠽࠾࠿࠹Ὠ"))
		CGfLEIZtjWqlz = [mg3CbXMA2ouZzQDhRqB(u"ࠩฦๅ้อๅࠨᷳ"),KhUG1NV9bln5zXjptqFW6dgo(u"ุ้๊ࠪำๅษอࠫᷴ"),n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"ู๊ࠫัฮ์สฮࠬ᷵"),C3ZK1pu4rfmj8TsWUtBaM(u"ࠬฮัศ็ฯࠫ᷶"),dBi72erQEtKDOwjNFaoAgSP(u"࠭รุใส่ࠥ๎ใาฬ๋๊᷷ࠬ"),U0VwOviFaYPz2QGs45mJhMXf7Zk(u"ࠧา็ูห๋᷸࠭"),ELfMeDTIFhJt685K(u"ࠨละำะ࠳รฯำ᷹ࠪ"),X2crmy67eZpkGTRd(u"ࠩึ่ฬูไࠨ᷺"),CDwSWB4v39N7(u"้ࠪํู๊ใ๋ࠪ᷻"),ELfMeDTIFhJt685K(u"ࠫศฺ็า࠯ฦ็ะืࠧ᷼"),JJA7fypmZFVlazvNI(u"ࠬอไร่᷽ࠪ"),OBsrtQo2pPlgURCxJYbj9iXMD(u"࠭ึฮๅࠪ᷾"),jL1E5AKfwBDv6xmeQtUXcJ3d(u"ࠧา์สฺฮ᷿࠭"),ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"ࠨ่ํฮๆ๊ใิࠩḀ"),jL1E5AKfwBDv6xmeQtUXcJ3d(u"่้ࠩะ๊๊็ࠩḁ"),n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"ࠪฬะࠦอ๋ࠩḂ"),CDwSWB4v39N7(u"ࠫิ๐ๆ๋หࠪḃ"),LHX65I9nkx0PstgcVY24uSi(u"ูࠬๆ้ษอࠫḄ"),SODvU3Ibq5VzC(u"࠭รฯำ์ࠫḅ")]
		eKrCqWnGBufF2 = o4bNzIQGYj8En
		for rLsIH0NC6Pe4RWODBGn3Zfi7Eqz in CGfLEIZtjWqlz:
			eKrCqWnGBufF2 += CH7RKuDVzN9f06q8MtXPhlvIxakEWg
			CfgK4s13Q0hZcHyleT2bVJO9(owbMhINBQsmx70guApW(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧḆ"),EEJvXQzSZNt+rLsIH0NC6Pe4RWODBGn3Zfi7Eqz,HQmDERMFjx,OBsrtQo2pPlgURCxJYbj9iXMD(u"࠼࠼࠳Ὡ"),HQmDERMFjx,str(eKrCqWnGBufF2),aNGfo9USX3678MunH,HQmDERMFjx,{HDpmv4UXzlf72SK9(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨḇ"):fyJ27mwDtuZgzKXG6jbE})
	else:
		bb4KJfEpVFPwjxGk6me381gUznrHTt = [OBsrtQo2pPlgURCxJYbj9iXMD(u"ࠩสๅ้อๅࠨḈ"),EAVanJj1ers2GQud(u"ࠪࡱࡴࡼࡩࡦࠩḉ"),EF2tvxZHz5n4UruPhaViXKycI6SQR(u"ࠫๆ๐ไๆࠩḊ"),dBi72erQEtKDOwjNFaoAgSP(u"ࠬ็ไๆࠩḋ")]
		vVEYRBwQnUfWx1KGMIucF4h = [SODvU3Ibq5VzC(u"࠭ๅิๆึ่ࠬḌ"),X2crmy67eZpkGTRd(u"ࠧࡴࡧࡵ࡭ࡪࡹࠧḍ")]
		nfyQreEVHA = [A0aqj9uclgOtByJ6F4bz(u"ࠨ็ึหึำࠧḎ"),maUl7SPesynF1j(u"่ࠩืึำ๊ศฬࠪḏ")]
		EMDZSbitRa5kdhpIjzr9P = [mgLADoQ1pbtY(u"ࠪฬึอๅอࠩḐ"),ShnRVsifKtc60zqQ(u"ࠫࡸ࡮࡯ࡸࠩḑ"),Tcf5Ppn9UajDbzyM(u"ࠬะไโิํ์๋࠭Ḓ"),ELfMeDTIFhJt685K(u"࠭สๅ์ไึ๏๎ๆࠨḓ")]
		IBrhu3MKtPGikcC6A72jFsdEV = [jL1E5AKfwBDv6xmeQtUXcJ3d(u"ࠧศ่่๎ࠬḔ"),EF2tvxZHz5n4UruPhaViXKycI6SQR(u"ࠨๅิฮํ์ࠧḕ"),ShnRVsifKtc60zqQ(u"ࠩๆหึะ่็ࠩḖ"),KhUG1NV9bln5zXjptqFW6dgo(u"ࠪ࡯࡮ࡪࡳࠨḗ"),JJA7fypmZFVlazvNI(u"ࠫ฼็ไࠨḘ"),CDwSWB4v39N7(u"ࠬอืโษ็ࠫḙ")]
		vxAnDqGWVloRdTJgIZPu = [YJxaX0MQOHb8oyCBFdnIAe(u"࠭ัๆุส๊ࠬḚ")]
		dnBbVP3FSUHM6eAow8GDkiZEjWlpm = [CDwSWB4v39N7(u"ࠧศฯาฯࠬḛ"),EAVanJj1ers2GQud(u"ࠨษัีࠬḜ"),owbMhINBQsmx70guApW(u"่ࠩ์ำืࠧḝ"),knTyjJ0sGIzuwbxRae(u"ࠪะิ๐ฯࠨḞ"),JJA7fypmZFVlazvNI(u"๊ࠫ฼วโࠩḟ"),Tcf5Ppn9UajDbzyM(u"ࠬำฯ๋อࠪḠ")]
		w9eR2g3XdN = [OBsrtQo2pPlgURCxJYbj9iXMD(u"࠭ำๅษึ่ࠬḡ"),ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"ࠧิๆึ่์࠭Ḣ")]
		aLKNEqM1ACIP = [U0VwOviFaYPz2QGs45mJhMXf7Zk(u"ࠨษ฽ห๋๐ࠧḣ"),ShnRVsifKtc60zqQ(u"่ࠩ์ุ๐โ๊ࠩḤ"),owbMhINBQsmx70guApW(u"ࠪ็้๐ศࠨḥ"),EF2tvxZHz5n4UruPhaViXKycI6SQR(u"ࠫา็ไࠨḦ"),mgLADoQ1pbtY(u"ࠬࡳࡵࡴ࡫ࡦࠫḧ")]
		iE29B4W0VOlwuytoFxT = [EAVanJj1ers2GQud(u"࠭วไอิࠫḨ"),maUl7SPesynF1j(u"ࠧศึ๊ีࠬḩ"),knTyjJ0sGIzuwbxRae(u"ࠨ็่๎ืํࠧḪ"),Tcf5Ppn9UajDbzyM(u"ࠩส฽้๏ࠧḫ"),cWbkR6iUZsnJQj14(u"้ࠪำะวา้ࠪḬ"),EAVanJj1ers2GQud(u"๊ࠫิสศำสฮࠬḭ"),mg3CbXMA2ouZzQDhRqB(u"ࠬอโ้๋ࠪḮ")]
		NNmq0PafDwQ9zXspx4B = [cWbkR6iUZsnJQj14(u"࠭วๅษ้ࠫḯ"),ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"ࠧฮษ็๎ࠬḰ"),KhUG1NV9bln5zXjptqFW6dgo(u"ࠨ็ฮฬฯ࠭ḱ"),EAVanJj1ers2GQud(u"ࠩิหหาࠧḲ")]
		JlxGUh6wgqA5zFWs = [EAVanJj1ers2GQud(u"ฺࠪา้ࠧḳ"),cWbkR6iUZsnJQj14(u"่ࠫ๎ๅ๋ัํࠫḴ")]
		ezNsAMwuEbi5YDy9t8vOPGkoq7T = [k4IUieraScH9DV1N7pJgQosYAx5l(u"ࠬื๊ศุ๊ࠫḵ"),JJA7fypmZFVlazvNI(u"࠭ใ้ำ๊ࠫḶ"),n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"ࠧๆืสี฾ํࠧḷ"),OBsrtQo2pPlgURCxJYbj9iXMD(u"ࠨึ๋ฮࠬḸ"),dBi72erQEtKDOwjNFaoAgSP(u"ࠩิ๎ฬ฼ษࠨḹ")]
		VTBeWdquvx5fJtH = [KKi79PFqsYB0dWSRgaJ3DyE(u"๊ࠪ๏ะแๅๅึࠫḺ"),pCTzbw4GyVJHjkcIMQ(u"ࠫࡳ࡫ࡴࡧ࡮࡬ࡼࠬḻ"),ShnRVsifKtc60zqQ(u"ࠬ์๊หใ็๎ู่ࠧḼ")]
		WlxKq9dzeS8QhVk = [OzU6t0qcH7MQabeBYK8vgoG(u"࠭ๅๆอ็๎๋࠭ḽ"),C3ZK1pu4rfmj8TsWUtBaM(u"ࠧศึัหฺ࠭Ḿ"),KKi79PFqsYB0dWSRgaJ3DyE(u"ࠨ่ฯ์๊࠭ḿ")]
		eY4DutR9cHF = [dBi72erQEtKDOwjNFaoAgSP(u"ࠩหฯࠥำ๊ࠨṀ"),EAVanJj1ers2GQud(u"ࠪࡰ࡮ࡼࡥࠨṁ"),cWbkR6iUZsnJQj14(u"ࠫ็์ว่ࠩṂ"),ELfMeDTIFhJt685K(u"่ࠬๆ้ษอࠫṃ")]
		XHgnLhj92maQlizI015EKuGsBTo = [YJxaX0MQOHb8oyCBFdnIAe(u"࠭ฯ๋่ࠪṄ"),EF2tvxZHz5n4UruPhaViXKycI6SQR(u"ࠧศั฼๎์࠭ṅ"),OBsrtQo2pPlgURCxJYbj9iXMD(u"ࠨิํหึอสࠨṆ"),jL1E5AKfwBDv6xmeQtUXcJ3d(u"ࠩ็฻๊๐วหࠩṇ"),knTyjJ0sGIzuwbxRae(u"ࠪำ฾อมࠨṈ"),KhUG1NV9bln5zXjptqFW6dgo(u"ࠫ็ืว็ࠩṉ"),X2crmy67eZpkGTRd(u"่ࠬีศศาࠫṊ"),HDpmv4UXzlf72SK9(u"࠭ัฬษฤࠫṋ"),EF2tvxZHz5n4UruPhaViXKycI6SQR(u"ࠧๆำฯ฽๏ํࠧṌ"),A0aqj9uclgOtByJ6F4bz(u"ࠨษำห๋࠭ṍ"),KKi79PFqsYB0dWSRgaJ3DyE(u"ࠩสื้อๅࠨṎ"),EAVanJj1ers2GQud(u"ࠪฮํอิ๋ฯࠪṏ"),Tcf5Ppn9UajDbzyM(u"ࠫำ฽ศࠨṐ"),cWbkR6iUZsnJQj14(u"ࠬำ่ำ๊ํࠫṑ"),dBi72erQEtKDOwjNFaoAgSP(u"ู࠭หสสฮࠬṒ"),KhUG1NV9bln5zXjptqFW6dgo(u"ࠧๆ๊ส่๏ีࠧṓ"),cWbkR6iUZsnJQj14(u"ࠨ่๋ห฾๐ࠧṔ"),OBsrtQo2pPlgURCxJYbj9iXMD(u"ࠩ฼ๆฬฬฯࠨṕ"),dBi72erQEtKDOwjNFaoAgSP(u"ࠪห๋อิ๋ัࠪṖ")]
		Ph96q0ZOAFLHuiXbmek2G3D8UMJYlj = [Tcf5Ppn9UajDbzyM(u"ࠫ࠷࠶࠱࠱ࠩṗ"),jL1E5AKfwBDv6xmeQtUXcJ3d(u"ࠬ࠸࠰࠲࠳ࠪṘ"),U0VwOviFaYPz2QGs45mJhMXf7Zk(u"࠭࠲࠱࠳࠵ࠫṙ"),KKi79PFqsYB0dWSRgaJ3DyE(u"ࠧ࠳࠲࠴࠷ࠬṚ"),LHX65I9nkx0PstgcVY24uSi(u"ࠨ࠴࠳࠵࠹࠭ṛ"),mgLADoQ1pbtY(u"ࠩ࠵࠴࠶࠻ࠧṜ"),A0aqj9uclgOtByJ6F4bz(u"ࠪ࠶࠵࠷࠶ࠨṝ"),KKi79PFqsYB0dWSRgaJ3DyE(u"ࠫ࠷࠶࠱࠸ࠩṞ"),KhUG1NV9bln5zXjptqFW6dgo(u"ࠬ࠸࠰࠲࠺ࠪṟ"),nz8x32hX0qcjUPFZk5RdJsiwED(u"࠭࠲࠱࠳࠼ࠫṠ"),PPAUFrY8cduRT(u"ࠧ࠳࠲࠵࠴ࠬṡ"),mgLADoQ1pbtY(u"ࠨ࠴࠳࠶࠶࠭Ṣ"),HDpmv4UXzlf72SK9(u"ࠩ࠵࠴࠷࠸ࠧṣ"),KhUG1NV9bln5zXjptqFW6dgo(u"ࠪ࠶࠵࠸࠳ࠨṤ"),KhUG1NV9bln5zXjptqFW6dgo(u"ࠫ࠷࠶࠲࠵ࠩṥ"),X2crmy67eZpkGTRd(u"ࠬ࠸࠰࠳࠷ࠪṦ"),pCTzbw4GyVJHjkcIMQ(u"࠭࠲࠱࠴࠹ࠫṧ"),SODvU3Ibq5VzC(u"ࠧ࠳࠲࠵࠻ࠬṨ"),owbMhINBQsmx70guApW(u"ࠨ࠴࠳࠶࠽࠭ṩ")]
		for XyOvPTlmBK4hDVjfi in sorted(list(f9n0wLB5oxavA.keys())):
			hQGaZWkesbXDYn7Altz2oudM = XyOvPTlmBK4hDVjfi.lower()
			WF2vkePC5gbXAGUarcqlpmB3Q = []
			if any(value in hQGaZWkesbXDYn7Altz2oudM for value in bb4KJfEpVFPwjxGk6me381gUznrHTt): WF2vkePC5gbXAGUarcqlpmB3Q.append(CH7RKuDVzN9f06q8MtXPhlvIxakEWg)
			if any(value in hQGaZWkesbXDYn7Altz2oudM for value in vVEYRBwQnUfWx1KGMIucF4h): WF2vkePC5gbXAGUarcqlpmB3Q.append(FFHRwuxQmbh8BaTqyX3)
			if any(value in hQGaZWkesbXDYn7Altz2oudM for value in nfyQreEVHA): WF2vkePC5gbXAGUarcqlpmB3Q.append(UUR70c8L9yTp3A2ajlmJqkQz)
			if any(value in hQGaZWkesbXDYn7Altz2oudM for value in EMDZSbitRa5kdhpIjzr9P): WF2vkePC5gbXAGUarcqlpmB3Q.append(ihRKM0HpwdVstIF2ZjuTeCmXG)
			if any(value in hQGaZWkesbXDYn7Altz2oudM for value in IBrhu3MKtPGikcC6A72jFsdEV): WF2vkePC5gbXAGUarcqlpmB3Q.append(MVXFsAiZbSvHTtq8he5GwLaOxzW)
			if any(value in hQGaZWkesbXDYn7Altz2oudM for value in vxAnDqGWVloRdTJgIZPu): WF2vkePC5gbXAGUarcqlpmB3Q.append(dBi72erQEtKDOwjNFaoAgSP(u"࠼Ὢ"))
			if any(value in hQGaZWkesbXDYn7Altz2oudM for value in dnBbVP3FSUHM6eAow8GDkiZEjWlpm) and hQGaZWkesbXDYn7Altz2oudM not in [EF2tvxZHz5n4UruPhaViXKycI6SQR(u"ࠩสาึ๏ࠧṪ")]: WF2vkePC5gbXAGUarcqlpmB3Q.append(mg3CbXMA2ouZzQDhRqB(u"࠷Ὣ"))
			if any(value in hQGaZWkesbXDYn7Altz2oudM for value in w9eR2g3XdN): WF2vkePC5gbXAGUarcqlpmB3Q.append(cWbkR6iUZsnJQj14(u"࠹Ὤ"))
			if any(value in hQGaZWkesbXDYn7Altz2oudM for value in aLKNEqM1ACIP): WF2vkePC5gbXAGUarcqlpmB3Q.append(owbMhINBQsmx70guApW(u"࠻Ὥ"))
			if any(value in hQGaZWkesbXDYn7Altz2oudM for value in iE29B4W0VOlwuytoFxT): WF2vkePC5gbXAGUarcqlpmB3Q.append(knTyjJ0sGIzuwbxRae(u"࠴࠴Ὦ"))
			if any(value in hQGaZWkesbXDYn7Altz2oudM for value in NNmq0PafDwQ9zXspx4B): WF2vkePC5gbXAGUarcqlpmB3Q.append(knTyjJ0sGIzuwbxRae(u"࠵࠶Ὧ"))
			if any(value in hQGaZWkesbXDYn7Altz2oudM for value in JlxGUh6wgqA5zFWs): WF2vkePC5gbXAGUarcqlpmB3Q.append(U0VwOviFaYPz2QGs45mJhMXf7Zk(u"࠶࠸ὰ"))
			if any(value in hQGaZWkesbXDYn7Altz2oudM for value in ezNsAMwuEbi5YDy9t8vOPGkoq7T): WF2vkePC5gbXAGUarcqlpmB3Q.append(mgLADoQ1pbtY(u"࠷࠳ά"))
			if any(value in hQGaZWkesbXDYn7Altz2oudM for value in VTBeWdquvx5fJtH): WF2vkePC5gbXAGUarcqlpmB3Q.append(YJxaX0MQOHb8oyCBFdnIAe(u"࠱࠵ὲ"))
			if any(value in hQGaZWkesbXDYn7Altz2oudM for value in WlxKq9dzeS8QhVk): WF2vkePC5gbXAGUarcqlpmB3Q.append(n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"࠲࠷έ"))
			if any(value in hQGaZWkesbXDYn7Altz2oudM for value in eY4DutR9cHF): WF2vkePC5gbXAGUarcqlpmB3Q.append(cWbkR6iUZsnJQj14(u"࠳࠹ὴ"))
			if any(value in hQGaZWkesbXDYn7Altz2oudM for value in XHgnLhj92maQlizI015EKuGsBTo): WF2vkePC5gbXAGUarcqlpmB3Q.append(A0aqj9uclgOtByJ6F4bz(u"࠴࠻ή"))
			if any(value in hQGaZWkesbXDYn7Altz2oudM for value in Ph96q0ZOAFLHuiXbmek2G3D8UMJYlj): WF2vkePC5gbXAGUarcqlpmB3Q.append(CDwSWB4v39N7(u"࠵࠽ὶ"))
			if not WF2vkePC5gbXAGUarcqlpmB3Q: WF2vkePC5gbXAGUarcqlpmB3Q = [k4IUieraScH9DV1N7pJgQosYAx5l(u"࠶࠿ί")]
			for kpf0W2rZIRHuoNPnjhEDmTG in WF2vkePC5gbXAGUarcqlpmB3Q:
				if str(kpf0W2rZIRHuoNPnjhEDmTG)==eKrCqWnGBufF2:
					CfgK4s13Q0hZcHyleT2bVJO9(JJA7fypmZFVlazvNI(u"ࠪࡪࡴࡲࡤࡦࡴࠪṫ"),EEJvXQzSZNt+XyOvPTlmBK4hDVjfi,XyOvPTlmBK4hDVjfi,ShnRVsifKtc60zqQ(u"࠷࠶࠷ὸ"),HQmDERMFjx,HQmDERMFjx,aNGfo9USX3678MunH+knTyjJ0sGIzuwbxRae(u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨṬ"))
	XgW8wuKsyUDpmRQvSV0cNfhxAiFJE(xWfmqtAck6vZbDhoda73GNrOHnKpjF,xWfmqtAck6vZbDhoda73GNrOHnKpjF,SLgzAKNoYhFUR)
	return
def nYNwJg6aXqbyGLStfj9sQoRUxT(fyJ27mwDtuZgzKXG6jbE,LlsCEXIte1n9TG0BAVOojqyvQkhb5):
	LnricPbQjug6yt0lUIeMKpVDTa = mic3MEN709xOkrjD5ZvbGIlX6
	if LnricPbQjug6yt0lUIeMKpVDTa:
		CfgK4s13Q0hZcHyleT2bVJO9(knTyjJ0sGIzuwbxRae(u"ࠬࡲࡩ࡯࡭ࠪṭ"),CDwSWB4v39N7(u"࠭สฮัํฯ่ࠥวว็ฬࠤศ่ำศ็ࠣࡍࡕ࡚ࡖࠨṮ"),HQmDERMFjx,owbMhINBQsmx70guApW(u"࠷࠷࠶ό"),HQmDERMFjx,HQmDERMFjx,C3ZK1pu4rfmj8TsWUtBaM(u"ࠧࡠࡅࡕࡉࡆ࡚ࡅࡏࡇ࡚ࡣࠬṯ"),HQmDERMFjx,{k4IUieraScH9DV1N7pJgQosYAx5l(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨṰ"):fyJ27mwDtuZgzKXG6jbE})
		CfgK4s13Q0hZcHyleT2bVJO9(jL1E5AKfwBDv6xmeQtUXcJ3d(u"ࠩ࡯࡭ࡳࡱࠧṱ"),ao3Q5jP8H0sMxK2iUYwZGE+EF2tvxZHz5n4UruPhaViXKycI6SQR(u"ࠪࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠࠨṲ")+cjqzOQ5GXD4kR,HQmDERMFjx,KKi79PFqsYB0dWSRgaJ3DyE(u"࠺࠻࠼࠽ὺ"))
	bIKWSZ1NoxE52mRyvQGeLuVl = Jzthpc2nj5.menuItemsLIST[:]
	import rrF9yjmgo4
	if fyJ27mwDtuZgzKXG6jbE:
		if not rrF9yjmgo4.NJUG7VWM1tLgQKBip0d(fyJ27mwDtuZgzKXG6jbE,gyd2rf0UR5): return
		sbdfuJV6H8PNpySO9KBFilZRDTxhv = vv1GdoOpbLR2gfVxrlj4IQz9t(fyJ27mwDtuZgzKXG6jbE,LlsCEXIte1n9TG0BAVOojqyvQkhb5)
		f4fmxb3dPe = sorted(sbdfuJV6H8PNpySO9KBFilZRDTxhv,reverse=mic3MEN709xOkrjD5ZvbGIlX6,key=lambda key: key[CH7RKuDVzN9f06q8MtXPhlvIxakEWg].lower())
	else:
		if not rrF9yjmgo4.NJUG7VWM1tLgQKBip0d(HQmDERMFjx,gyd2rf0UR5): return
		if LnricPbQjug6yt0lUIeMKpVDTa and ShnRVsifKtc60zqQ(u"ࠫࡤࡉࡒࡆࡃࡗࡉࡓࡋࡗࡠࠩṳ") not in LlsCEXIte1n9TG0BAVOojqyvQkhb5:
			f4fmxb3dPe = FcSRPu295Ot1Jv0Bip3IDom(rDy4FoKpEOsXfT8WZjli,mgLADoQ1pbtY(u"ࠬࡲࡩࡴࡶࠪṴ"),OzU6t0qcH7MQabeBYK8vgoG(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡋࡓࡘ࡛࠭ṵ"),knTyjJ0sGIzuwbxRae(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡌࡔ࡙࡜࡟ࡂࡎࡏࠫṶ"))
		else:
			WOr49YuSe18XNBFLtfEiHqbA,f4fmxb3dPe,sbdfuJV6H8PNpySO9KBFilZRDTxhv = [],[],[]
			for EHmNQxD6KIRGSpzniB9YvAc0jdrh in range(CH7RKuDVzN9f06q8MtXPhlvIxakEWg,L3C1YrQDi840ShlOJcNGe+CH7RKuDVzN9f06q8MtXPhlvIxakEWg):
				f4fmxb3dPe += vv1GdoOpbLR2gfVxrlj4IQz9t(str(EHmNQxD6KIRGSpzniB9YvAc0jdrh),LlsCEXIte1n9TG0BAVOojqyvQkhb5)
			for type,XyOvPTlmBK4hDVjfi,url,lXBL3WrM2JFYm,kALyrFT6KPNGI7Oiup82Qb4JCq0td,zmL397efNlks5uTEV,NN9niuC7RoqmhkL2,nObHm3uEzJ,GoC84Eq3azJwpSWxkctF1MdTruOIyb in f4fmxb3dPe:
				if NN9niuC7RoqmhkL2 not in WOr49YuSe18XNBFLtfEiHqbA:
					WOr49YuSe18XNBFLtfEiHqbA.append(NN9niuC7RoqmhkL2)
					oOLrEYljPJRGK42n = type,XyOvPTlmBK4hDVjfi,NN9niuC7RoqmhkL2,U0VwOviFaYPz2QGs45mJhMXf7Zk(u"࠳࠹࠹ύ"),kALyrFT6KPNGI7Oiup82Qb4JCq0td,zmL397efNlks5uTEV,LlsCEXIte1n9TG0BAVOojqyvQkhb5,nObHm3uEzJ,GoC84Eq3azJwpSWxkctF1MdTruOIyb
					sbdfuJV6H8PNpySO9KBFilZRDTxhv.append(oOLrEYljPJRGK42n)
			f4fmxb3dPe = sorted(sbdfuJV6H8PNpySO9KBFilZRDTxhv,reverse=mic3MEN709xOkrjD5ZvbGIlX6,key=lambda key: key[CH7RKuDVzN9f06q8MtXPhlvIxakEWg].lower())
			if LnricPbQjug6yt0lUIeMKpVDTa: HqD3sxo0fJX(rDy4FoKpEOsXfT8WZjli,pCTzbw4GyVJHjkcIMQ(u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡍࡕ࡚ࡖࠨṷ"),k4IUieraScH9DV1N7pJgQosYAx5l(u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡎࡖࡔࡗࡡࡄࡐࡑ࠭Ṹ"),f4fmxb3dPe,h8CF5iEB9RXNf0G)
	Jzthpc2nj5.menuItemsLIST[:] = bIKWSZ1NoxE52mRyvQGeLuVl+f4fmxb3dPe
	dXUwsnOGKBF57cNaok(mic3MEN709xOkrjD5ZvbGIlX6)
	return
def fbiJ0Tl6sV7ntHBZoIz3F(fyJ27mwDtuZgzKXG6jbE,LlsCEXIte1n9TG0BAVOojqyvQkhb5):
	LnricPbQjug6yt0lUIeMKpVDTa = mic3MEN709xOkrjD5ZvbGIlX6
	if LnricPbQjug6yt0lUIeMKpVDTa:
		CfgK4s13Q0hZcHyleT2bVJO9(dBi72erQEtKDOwjNFaoAgSP(u"ࠪࡰ࡮ࡴ࡫ࠨṹ"),YJxaX0MQOHb8oyCBFdnIAe(u"ࠫฯำฯ๋อࠣๆฬฬๅสࠢฦๆุอๅࠡࡏ࠶࡙ࠬṺ"),HQmDERMFjx,pCTzbw4GyVJHjkcIMQ(u"࠺࠺࠺ὼ"),HQmDERMFjx,HQmDERMFjx,PPAUFrY8cduRT(u"ࠬࡥࡃࡓࡇࡄࡘࡊࡔࡅࡘࡡࠪṻ"),HQmDERMFjx,{mg3CbXMA2ouZzQDhRqB(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ṽ"):fyJ27mwDtuZgzKXG6jbE})
		CfgK4s13Q0hZcHyleT2bVJO9(mg3CbXMA2ouZzQDhRqB(u"ࠧ࡭࡫ࡱ࡯ࠬṽ"),ao3Q5jP8H0sMxK2iUYwZGE+jL1E5AKfwBDv6xmeQtUXcJ3d(u"ࠨ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥ࠭Ṿ")+cjqzOQ5GXD4kR,HQmDERMFjx,dBi72erQEtKDOwjNFaoAgSP(u"࠽࠾࠿࠹ώ"))
	bIKWSZ1NoxE52mRyvQGeLuVl = Jzthpc2nj5.menuItemsLIST[:]
	import BBlniQqbfT
	if fyJ27mwDtuZgzKXG6jbE:
		if not BBlniQqbfT.NJUG7VWM1tLgQKBip0d(fyJ27mwDtuZgzKXG6jbE,gyd2rf0UR5): return
		sbdfuJV6H8PNpySO9KBFilZRDTxhv = gwzqWMVAEU48SdxpH9D(fyJ27mwDtuZgzKXG6jbE,LlsCEXIte1n9TG0BAVOojqyvQkhb5)
		f4fmxb3dPe = sorted(sbdfuJV6H8PNpySO9KBFilZRDTxhv,reverse=mic3MEN709xOkrjD5ZvbGIlX6,key=lambda key: key[CH7RKuDVzN9f06q8MtXPhlvIxakEWg].lower())
	else:
		if not BBlniQqbfT.NJUG7VWM1tLgQKBip0d(HQmDERMFjx,gyd2rf0UR5): return
		if LnricPbQjug6yt0lUIeMKpVDTa and OBsrtQo2pPlgURCxJYbj9iXMD(u"ࠩࡢࡇࡗࡋࡁࡕࡇࡑࡉ࡜ࡥࠧṿ") not in LlsCEXIte1n9TG0BAVOojqyvQkhb5:
			f4fmxb3dPe = FcSRPu295Ot1Jv0Bip3IDom(rDy4FoKpEOsXfT8WZjli,ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"ࠪࡰ࡮ࡹࡴࠨẀ"),X2crmy67eZpkGTRd(u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡍ࠴ࡗࠪẁ"),mgLADoQ1pbtY(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡎ࠵ࡘࡣࡆࡒࡌࠨẂ"))
		else:
			WOr49YuSe18XNBFLtfEiHqbA,f4fmxb3dPe,sbdfuJV6H8PNpySO9KBFilZRDTxhv = [],[],[]
			for EHmNQxD6KIRGSpzniB9YvAc0jdrh in range(CH7RKuDVzN9f06q8MtXPhlvIxakEWg,L3C1YrQDi840ShlOJcNGe+CH7RKuDVzN9f06q8MtXPhlvIxakEWg):
				f4fmxb3dPe += gwzqWMVAEU48SdxpH9D(str(EHmNQxD6KIRGSpzniB9YvAc0jdrh),LlsCEXIte1n9TG0BAVOojqyvQkhb5)
			for type,XyOvPTlmBK4hDVjfi,url,lXBL3WrM2JFYm,kALyrFT6KPNGI7Oiup82Qb4JCq0td,zmL397efNlks5uTEV,NN9niuC7RoqmhkL2,nObHm3uEzJ,GoC84Eq3azJwpSWxkctF1MdTruOIyb in f4fmxb3dPe:
				if NN9niuC7RoqmhkL2 not in WOr49YuSe18XNBFLtfEiHqbA:
					WOr49YuSe18XNBFLtfEiHqbA.append(NN9niuC7RoqmhkL2)
					oOLrEYljPJRGK42n = type,XyOvPTlmBK4hDVjfi,NN9niuC7RoqmhkL2,EF2tvxZHz5n4UruPhaViXKycI6SQR(u"࠶࠼࠵὾"),kALyrFT6KPNGI7Oiup82Qb4JCq0td,zmL397efNlks5uTEV,LlsCEXIte1n9TG0BAVOojqyvQkhb5,nObHm3uEzJ,GoC84Eq3azJwpSWxkctF1MdTruOIyb
					sbdfuJV6H8PNpySO9KBFilZRDTxhv.append(oOLrEYljPJRGK42n)
			f4fmxb3dPe = sorted(sbdfuJV6H8PNpySO9KBFilZRDTxhv,reverse=mic3MEN709xOkrjD5ZvbGIlX6,key=lambda key: key[CH7RKuDVzN9f06q8MtXPhlvIxakEWg].lower())
			if LnricPbQjug6yt0lUIeMKpVDTa: HqD3sxo0fJX(rDy4FoKpEOsXfT8WZjli,EF2tvxZHz5n4UruPhaViXKycI6SQR(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡏ࠶࡙ࠬẃ"),KhUG1NV9bln5zXjptqFW6dgo(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡐ࠷࡚ࡥࡁࡍࡎࠪẄ"),f4fmxb3dPe,h8CF5iEB9RXNf0G)
	Jzthpc2nj5.menuItemsLIST[:] = bIKWSZ1NoxE52mRyvQGeLuVl+f4fmxb3dPe
	dXUwsnOGKBF57cNaok(mic3MEN709xOkrjD5ZvbGIlX6)
	return
def atk5xn9cpgzvi3dGmyMXs6rhLF(group,LlsCEXIte1n9TG0BAVOojqyvQkhb5):
	LnricPbQjug6yt0lUIeMKpVDTa = mic3MEN709xOkrjD5ZvbGIlX6
	zLZUkrP7ac5 = []
	k1L4rIgdRU0mSeVxaNwHcphoPQ = A0aqj9uclgOtByJ6F4bz(u"ࠨࡡࡌࡔ࡙࡜࡟ࠨẅ") if dBi72erQEtKDOwjNFaoAgSP(u"ࠩࡌࡔ࡙࡜ࠧẆ") in LlsCEXIte1n9TG0BAVOojqyvQkhb5 else C3ZK1pu4rfmj8TsWUtBaM(u"ࠪࡣࡒ࠹ࡕࡠࠩẇ")
	if LnricPbQjug6yt0lUIeMKpVDTa: zLZUkrP7ac5 = FcSRPu295Ot1Jv0Bip3IDom(rDy4FoKpEOsXfT8WZjli,pCTzbw4GyVJHjkcIMQ(u"ࠫࡱ࡯ࡳࡵࠩẈ"),EAVanJj1ers2GQud(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙ࠧẉ")+k1L4rIgdRU0mSeVxaNwHcphoPQ[:-CH7RKuDVzN9f06q8MtXPhlvIxakEWg],group)
	if not zLZUkrP7ac5:
		for fyJ27mwDtuZgzKXG6jbE in range(CH7RKuDVzN9f06q8MtXPhlvIxakEWg,L3C1YrQDi840ShlOJcNGe+CH7RKuDVzN9f06q8MtXPhlvIxakEWg):
			if LnricPbQjug6yt0lUIeMKpVDTa: zLZUkrP7ac5 += FcSRPu295Ot1Jv0Bip3IDom(rDy4FoKpEOsXfT8WZjli,C3ZK1pu4rfmj8TsWUtBaM(u"࠭࡬ࡪࡵࡷࠫẊ"),mgLADoQ1pbtY(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࠩẋ")+k1L4rIgdRU0mSeVxaNwHcphoPQ[:-CH7RKuDVzN9f06q8MtXPhlvIxakEWg],YJxaX0MQOHb8oyCBFdnIAe(u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࠪẌ")+k1L4rIgdRU0mSeVxaNwHcphoPQ+str(fyJ27mwDtuZgzKXG6jbE))
			elif k1L4rIgdRU0mSeVxaNwHcphoPQ==n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"ࠩࡢࡍࡕ࡚ࡖࡠࠩẍ"): zLZUkrP7ac5 += vv1GdoOpbLR2gfVxrlj4IQz9t(str(fyJ27mwDtuZgzKXG6jbE),cWbkR6iUZsnJQj14(u"ࠪࡣࡈࡘࡅࡂࡖࡈࡒࡊ࡝࡟ࠨẎ"))
			elif k1L4rIgdRU0mSeVxaNwHcphoPQ==JJA7fypmZFVlazvNI(u"ࠫࡤࡓ࠳ࡖࡡࠪẏ"): zLZUkrP7ac5 += gwzqWMVAEU48SdxpH9D(str(fyJ27mwDtuZgzKXG6jbE),KKi79PFqsYB0dWSRgaJ3DyE(u"ࠬࡥࡃࡓࡇࡄࡘࡊࡔࡅࡘࡡࠪẐ"))
		for type,XyOvPTlmBK4hDVjfi,url,lXBL3WrM2JFYm,kALyrFT6KPNGI7Oiup82Qb4JCq0td,zmL397efNlks5uTEV,NN9niuC7RoqmhkL2,nObHm3uEzJ,GoC84Eq3azJwpSWxkctF1MdTruOIyb in zLZUkrP7ac5:
			if NN9niuC7RoqmhkL2==group: RdOsz9X36gaxeuQWEvJ7wVIp02i8F(type,XyOvPTlmBK4hDVjfi,url,lXBL3WrM2JFYm,kALyrFT6KPNGI7Oiup82Qb4JCq0td,zmL397efNlks5uTEV,NN9niuC7RoqmhkL2,nObHm3uEzJ,GoC84Eq3azJwpSWxkctF1MdTruOIyb)
		items,bbiKcPz2RQOUwS = [],[]
		for type,XyOvPTlmBK4hDVjfi,url,lXBL3WrM2JFYm,kALyrFT6KPNGI7Oiup82Qb4JCq0td,zmL397efNlks5uTEV,NN9niuC7RoqmhkL2,nObHm3uEzJ,GoC84Eq3azJwpSWxkctF1MdTruOIyb in Jzthpc2nj5.menuItemsLIST:
			ItmyKOxPWpMozAl6Yuk7nfsqaF09 = type,XyOvPTlmBK4hDVjfi[ihRKM0HpwdVstIF2ZjuTeCmXG:],url,lXBL3WrM2JFYm,kALyrFT6KPNGI7Oiup82Qb4JCq0td,zmL397efNlks5uTEV,NN9niuC7RoqmhkL2,nObHm3uEzJ,HQmDERMFjx
			if ItmyKOxPWpMozAl6Yuk7nfsqaF09 not in bbiKcPz2RQOUwS:
				bbiKcPz2RQOUwS.append(ItmyKOxPWpMozAl6Yuk7nfsqaF09)
				A07BpVeRJToLb = type,XyOvPTlmBK4hDVjfi,url,lXBL3WrM2JFYm,kALyrFT6KPNGI7Oiup82Qb4JCq0td,zmL397efNlks5uTEV,NN9niuC7RoqmhkL2,nObHm3uEzJ,GoC84Eq3azJwpSWxkctF1MdTruOIyb
				items.append(A07BpVeRJToLb)
		zLZUkrP7ac5 = sorted(items,reverse=mic3MEN709xOkrjD5ZvbGIlX6,key=lambda key: key[CH7RKuDVzN9f06q8MtXPhlvIxakEWg].lower()[C3ZK1pu4rfmj8TsWUtBaM(u"࠻὿"):])
		if LnricPbQjug6yt0lUIeMKpVDTa: HqD3sxo0fJX(rDy4FoKpEOsXfT8WZjli,OzU6t0qcH7MQabeBYK8vgoG(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࠨẑ")+k1L4rIgdRU0mSeVxaNwHcphoPQ[:-CH7RKuDVzN9f06q8MtXPhlvIxakEWg],group,zLZUkrP7ac5,h8CF5iEB9RXNf0G)
	if U0VwOviFaYPz2QGs45mJhMXf7Zk(u"ࠧࡠࡔࡄࡒࡉࡕࡍࡠࠩẒ") in LlsCEXIte1n9TG0BAVOojqyvQkhb5 and len(zLZUkrP7ac5)>xg58yJ9YKiPbnoupDIwsqOC2m6H3:
		Jzthpc2nj5.menuItemsLIST[:] = []
		CfgK4s13Q0hZcHyleT2bVJO9(ELfMeDTIFhJt685K(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨẓ"),maUl7SPesynF1j(u"ࠩ࡞ࠫẔ")+ao3Q5jP8H0sMxK2iUYwZGE+group+cjqzOQ5GXD4kR+SODvU3Ibq5VzC(u"ࠪࠤ࠿อไใี่ࡡࠬẕ"),group,owbMhINBQsmx70guApW(u"࠱࠷࠷ᾀ"),HQmDERMFjx,HQmDERMFjx,k1L4rIgdRU0mSeVxaNwHcphoPQ+knTyjJ0sGIzuwbxRae(u"ࠫࡤࡘࡁࡏࡆࡒࡑࡤࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪẖ"))
		CfgK4s13Q0hZcHyleT2bVJO9(HDpmv4UXzlf72SK9(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬẗ"),n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"࠭ลฺษาอࠥอไุๆหࠤฬู๊ี๊สส๏ࠦๅ็้ࠢๅุࠦวๅไึ้ࠬẘ"),group,LHX65I9nkx0PstgcVY24uSi(u"࠲࠸࠸ᾁ"),HQmDERMFjx,HQmDERMFjx,k1L4rIgdRU0mSeVxaNwHcphoPQ+KKi79PFqsYB0dWSRgaJ3DyE(u"ࠧࡠࡔࡄࡒࡉࡕࡍࡠࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ẙ"))
		CfgK4s13Q0hZcHyleT2bVJO9(Tcf5Ppn9UajDbzyM(u"ࠨ࡮࡬ࡲࡰ࠭ẚ"),ao3Q5jP8H0sMxK2iUYwZGE+EAVanJj1ers2GQud(u"ࠩࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦࠧẛ")+cjqzOQ5GXD4kR,HQmDERMFjx,ELfMeDTIFhJt685K(u"࠻࠼࠽࠾ᾂ"))
		zLZUkrP7ac5 = Jzthpc2nj5.menuItemsLIST+AAlMouYR7549BDtWw.sample(zLZUkrP7ac5,xg58yJ9YKiPbnoupDIwsqOC2m6H3)
	Jzthpc2nj5.menuItemsLIST[:] = zLZUkrP7ac5
	dXUwsnOGKBF57cNaok(mic3MEN709xOkrjD5ZvbGIlX6)
	return
def Hu3IMT8Nh1e9aA(LlsCEXIte1n9TG0BAVOojqyvQkhb5):
	CfgK4s13Q0hZcHyleT2bVJO9(owbMhINBQsmx70guApW(u"ࠪࡪࡴࡲࡤࡦࡴࠪẜ"),KKi79PFqsYB0dWSRgaJ3DyE(u"ࠫส฿วะหࠣ฻้ฮࠠใ่๋หฯูࠦี๊สส๏ฯࠧẝ"),HQmDERMFjx,EF2tvxZHz5n4UruPhaViXKycI6SQR(u"࠴࠺࠶ᾃ"),HQmDERMFjx,HQmDERMFjx,CDwSWB4v39N7(u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡐࡎ࡜ࡅࡕࡘࡢࡣࡗࡇࡎࡅࡑࡐࡣࠬẞ"))
	CfgK4s13Q0hZcHyleT2bVJO9(C3ZK1pu4rfmj8TsWUtBaM(u"࠭࡬ࡪࡰ࡮ࠫẟ"),ao3Q5jP8H0sMxK2iUYwZGE+U0VwOviFaYPz2QGs45mJhMXf7Zk(u"ࠧ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࠬẠ")+cjqzOQ5GXD4kR,HQmDERMFjx,jL1E5AKfwBDv6xmeQtUXcJ3d(u"࠽࠾࠿࠹ᾄ"))
	onNW5fkypV0QDr = Jzthpc2nj5.menuItemsLIST[:]
	Jzthpc2nj5.menuItemsLIST[:] = []
	import pqlRw7xLou
	pqlRw7xLou.ddJ6F4hjPOTzKf0ulbQEoq7nwCV2(EF2tvxZHz5n4UruPhaViXKycI6SQR(u"ࠨ࠲ࠪạ"),mic3MEN709xOkrjD5ZvbGIlX6)
	pqlRw7xLou.ddJ6F4hjPOTzKf0ulbQEoq7nwCV2(ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"ࠩ࠴ࠫẢ"),mic3MEN709xOkrjD5ZvbGIlX6)
	pqlRw7xLou.ddJ6F4hjPOTzKf0ulbQEoq7nwCV2(ELfMeDTIFhJt685K(u"ࠪ࠶ࠬả"),mic3MEN709xOkrjD5ZvbGIlX6)
	if n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"ࠫࡤࡘࡁࡏࡆࡒࡑࡤ࠭Ấ") in LlsCEXIte1n9TG0BAVOojqyvQkhb5:
		Jzthpc2nj5.menuItemsLIST[:] = DpYuWyCUZ6OTezPS7ba2o9KFnR1mt(Jzthpc2nj5.menuItemsLIST)
		if len(Jzthpc2nj5.menuItemsLIST)>xg58yJ9YKiPbnoupDIwsqOC2m6H3: Jzthpc2nj5.menuItemsLIST[:] = AAlMouYR7549BDtWw.sample(Jzthpc2nj5.menuItemsLIST,xg58yJ9YKiPbnoupDIwsqOC2m6H3)
	Jzthpc2nj5.menuItemsLIST[:] = onNW5fkypV0QDr+Jzthpc2nj5.menuItemsLIST
	return
def f7v1Cc8JjIDpSyoi6FWgtzNh2KM(LlsCEXIte1n9TG0BAVOojqyvQkhb5):
	LlsCEXIte1n9TG0BAVOojqyvQkhb5 = LlsCEXIte1n9TG0BAVOojqyvQkhb5.replace(jL1E5AKfwBDv6xmeQtUXcJ3d(u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧấ"),HQmDERMFjx).replace(k4IUieraScH9DV1N7pJgQosYAx5l(u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪẦ"),HQmDERMFjx)
	headers = { EAVanJj1ers2GQud(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫầ") : HQmDERMFjx }
	url = SODvU3Ibq5VzC(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡢࡦࡵࡷࡶࡦࡴࡤࡰ࡯ࡶ࠲ࡨࡵ࡭࠰ࡴࡤࡲࡩࡵ࡭࠮ࡣࡵࡥࡧ࡯ࡣ࠮ࡹࡲࡶࡩࡹࠧẨ")
	data = {PPAUFrY8cduRT(u"ࠩࡴࡹࡦࡴࡴࡪࡶࡼࠫẩ"):LHX65I9nkx0PstgcVY24uSi(u"ࠪ࠹࠵࠭Ẫ")}
	data = LGHywlEc41qpeCFiSNX(data)
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(SwvFqCI7sc6bTAoeZY,knTyjJ0sGIzuwbxRae(u"ࠫࡌࡋࡔࠨẫ"),url,data,headers,HQmDERMFjx,HQmDERMFjx,U0VwOviFaYPz2QGs45mJhMXf7Zk(u"ࠬࡘࡁࡏࡆࡒࡑࡘ࠳ࡒࡂࡐࡇࡓࡒࡥࡖࡊࡆࡈࡓࡘࡥࡆࡓࡑࡐࡣ࡜ࡕࡒࡅࡕ࠰࠵ࡸࡺࠧẬ"))
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall(Tcf5Ppn9UajDbzyM(u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡣࡰࡰࡷࡩࡳࡺࠢࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧࡩ࡬ࡦࡣࡵࡪ࡮ࡾࠢࠨậ"),CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[o4bNzIQGYj8En]
	items = DyVGS3dX0ZxR.findall(CDwSWB4v39N7(u"ࠧ࠽ࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂ࠳࠰࠿࠽ࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂࠬẮ"),MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	WW1Xeq5trl,BzCK8GUSl7VHRnjI431 = list(zip(*items))
	Cn2Ubwv8h5xzqudSgFt7IDPmYLc = []
	RS4NkDI5UXVjOtwi1yA7ocZE3Kmz = [oQpxmKiRPlHeGsLXNrJF78O,C3ZK1pu4rfmj8TsWUtBaM(u"ࠨࠤࠪắ"),cWbkR6iUZsnJQj14(u"ࠩࡣࠫẰ"),nz8x32hX0qcjUPFZk5RdJsiwED(u"ࠪ࠰ࠬằ"),LHX65I9nkx0PstgcVY24uSi(u"ࠫ࠳࠭Ẳ"),PPAUFrY8cduRT(u"ࠬࡀࠧẳ"),YJxaX0MQOHb8oyCBFdnIAe(u"࠭࠻ࠨẴ"),OBsrtQo2pPlgURCxJYbj9iXMD(u"ࠢࠨࠤẵ"),ShnRVsifKtc60zqQ(u"ࠨ࠯ࠪẶ")]
	i9Jnag7PHMRNVmTr4khvyLb = BzCK8GUSl7VHRnjI431+WW1Xeq5trl
	for YHufWLyqEMNQ2 in i9Jnag7PHMRNVmTr4khvyLb:
		if YHufWLyqEMNQ2 in BzCK8GUSl7VHRnjI431: uKYUGpdPZjXyFLAkr2Tf5W73Rhog = FFHRwuxQmbh8BaTqyX3
		if YHufWLyqEMNQ2 in WW1Xeq5trl: uKYUGpdPZjXyFLAkr2Tf5W73Rhog = ihRKM0HpwdVstIF2ZjuTeCmXG
		bxwhj8E1NrnT32KXSWM9ZoP45A = [yuYts1RONXgp in YHufWLyqEMNQ2 for yuYts1RONXgp in RS4NkDI5UXVjOtwi1yA7ocZE3Kmz]
		if any(bxwhj8E1NrnT32KXSWM9ZoP45A):
			bbiEfNgaGDK3tOSoAe0uZy4B = bxwhj8E1NrnT32KXSWM9ZoP45A.index(gyd2rf0UR5)
			GWfyTnCEHBSO5p8jV = RS4NkDI5UXVjOtwi1yA7ocZE3Kmz[bbiEfNgaGDK3tOSoAe0uZy4B]
			UqPuJrCHEyKSA3iWbTZfws2xcD4F = HQmDERMFjx
			if YHufWLyqEMNQ2.count(GWfyTnCEHBSO5p8jV)>CH7RKuDVzN9f06q8MtXPhlvIxakEWg: KF0ExeLP8zfZGJbyv,CTYeZvkyu3DQ9oUzOxldi2cS,UqPuJrCHEyKSA3iWbTZfws2xcD4F = YHufWLyqEMNQ2.split(GWfyTnCEHBSO5p8jV,FFHRwuxQmbh8BaTqyX3)
			else: KF0ExeLP8zfZGJbyv,CTYeZvkyu3DQ9oUzOxldi2cS = YHufWLyqEMNQ2.split(GWfyTnCEHBSO5p8jV,CH7RKuDVzN9f06q8MtXPhlvIxakEWg)
			if len(KF0ExeLP8zfZGJbyv)>uKYUGpdPZjXyFLAkr2Tf5W73Rhog: Cn2Ubwv8h5xzqudSgFt7IDPmYLc.append(KF0ExeLP8zfZGJbyv.lower())
			if len(CTYeZvkyu3DQ9oUzOxldi2cS)>uKYUGpdPZjXyFLAkr2Tf5W73Rhog: Cn2Ubwv8h5xzqudSgFt7IDPmYLc.append(CTYeZvkyu3DQ9oUzOxldi2cS.lower())
			if len(UqPuJrCHEyKSA3iWbTZfws2xcD4F)>uKYUGpdPZjXyFLAkr2Tf5W73Rhog: Cn2Ubwv8h5xzqudSgFt7IDPmYLc.append(UqPuJrCHEyKSA3iWbTZfws2xcD4F.lower())
		elif len(YHufWLyqEMNQ2)>uKYUGpdPZjXyFLAkr2Tf5W73Rhog: Cn2Ubwv8h5xzqudSgFt7IDPmYLc.append(YHufWLyqEMNQ2.lower())
	for yuYts1RONXgp in range(EF2tvxZHz5n4UruPhaViXKycI6SQR(u"࠾ᾅ")): AAlMouYR7549BDtWw.shuffle(Cn2Ubwv8h5xzqudSgFt7IDPmYLc)
	if HDpmv4UXzlf72SK9(u"ࠩࡢࡗࡎ࡚ࡅࡔࡡࠪặ") in LlsCEXIte1n9TG0BAVOojqyvQkhb5:
		szNbDL2SXAPyGcTU0pREu6 = FWwniG0Em8kBIT3QV6tKfpa4
	elif SODvU3Ibq5VzC(u"ࠪࡣࡎࡖࡔࡗࡡࠪẸ") in LlsCEXIte1n9TG0BAVOojqyvQkhb5:
		szNbDL2SXAPyGcTU0pREu6 = [Tcf5Ppn9UajDbzyM(u"ࠫࡎࡖࡔࡗࠩẹ")]
		import rrF9yjmgo4
		if not rrF9yjmgo4.NJUG7VWM1tLgQKBip0d(HQmDERMFjx,gyd2rf0UR5): return
	elif CDwSWB4v39N7(u"ࠬࡥࡍ࠴ࡗࡢࠫẺ") in LlsCEXIte1n9TG0BAVOojqyvQkhb5:
		szNbDL2SXAPyGcTU0pREu6 = [Tcf5Ppn9UajDbzyM(u"࠭ࡍ࠴ࡗࠪẻ")]
		import BBlniQqbfT
		if not BBlniQqbfT.NJUG7VWM1tLgQKBip0d(HQmDERMFjx,gyd2rf0UR5): return
	count,mp48IvFXsAL9dY3iEfcRj2b = o4bNzIQGYj8En,o4bNzIQGYj8En
	CfgK4s13Q0hZcHyleT2bVJO9(X2crmy67eZpkGTRd(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧẼ"),k4IUieraScH9DV1N7pJgQosYAx5l(u"ࠨ࡝ࠣࠤࡢࠦ࠺ศๆหัะูࠦ็ࠩẽ"),HQmDERMFjx,JJA7fypmZFVlazvNI(u"࠷࠶࠵ᾆ"),HQmDERMFjx,HQmDERMFjx,A0aqj9uclgOtByJ6F4bz(u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧẾ")+LlsCEXIte1n9TG0BAVOojqyvQkhb5)
	CfgK4s13Q0hZcHyleT2bVJO9(ELfMeDTIFhJt685K(u"ࠪࡪࡴࡲࡤࡦࡴࠪế"),CDwSWB4v39N7(u"ࠫส฿วะหࠣห้ฮอฬࠢส่฾ฺ่ศศํࠫỀ"),HQmDERMFjx,owbMhINBQsmx70guApW(u"࠱࠷࠶ᾇ"),HQmDERMFjx,HQmDERMFjx,EF2tvxZHz5n4UruPhaViXKycI6SQR(u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪề")+LlsCEXIte1n9TG0BAVOojqyvQkhb5)
	CfgK4s13Q0hZcHyleT2bVJO9(LHX65I9nkx0PstgcVY24uSi(u"࠭࡬ࡪࡰ࡮ࠫỂ"),ao3Q5jP8H0sMxK2iUYwZGE+ShnRVsifKtc60zqQ(u"ࠧ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࠬể")+cjqzOQ5GXD4kR,HQmDERMFjx,EF2tvxZHz5n4UruPhaViXKycI6SQR(u"࠺࠻࠼࠽ᾈ"))
	F3aCcfSlKPU4RjiLvA1Z7Er = Jzthpc2nj5.menuItemsLIST[:]
	Jzthpc2nj5.menuItemsLIST[:] = []
	wUx9pu5DKRHcGYstkJfTr6Q3FCeXmE = []
	for YHufWLyqEMNQ2 in Cn2Ubwv8h5xzqudSgFt7IDPmYLc:
		CTYeZvkyu3DQ9oUzOxldi2cS = DyVGS3dX0ZxR.findall(JJA7fypmZFVlazvNI(u"ࠨ࡝ࠣࡠ࠱ࡢ࠻࡝࠼࡟࠱ࡡ࠱࡜࠾࡞ࠥࡠࠬࡢ࡛࡝࡟࡟ࠬࡡ࠯࡜ࡼ࡞ࢀࡠࠦࡢࡀࠨỄ")+EF2tvxZHz5n4UruPhaViXKycI6SQR(u"ࠩࠦࠫễ")+U0VwOviFaYPz2QGs45mJhMXf7Zk(u"ࠪࡠࠩࡢࠥ࡝ࡠ࡟ࠪࡡ࠰࡜ࡠ࡞࠿ࡠࡃࡣࠧỆ"),YHufWLyqEMNQ2,DyVGS3dX0ZxR.DOTALL)
		if CTYeZvkyu3DQ9oUzOxldi2cS: YHufWLyqEMNQ2 = YHufWLyqEMNQ2.split(CTYeZvkyu3DQ9oUzOxldi2cS[o4bNzIQGYj8En],CH7RKuDVzN9f06q8MtXPhlvIxakEWg)[o4bNzIQGYj8En]
		yyE1rWYKlMaJfLv = YHufWLyqEMNQ2.replace(HDpmv4UXzlf72SK9(u"ࠫ๖࠭ệ"),HQmDERMFjx).replace(U0VwOviFaYPz2QGs45mJhMXf7Zk(u"ࠬ๔ࠧỈ"),HQmDERMFjx).replace(n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"๋࠭ࠨỉ"),HQmDERMFjx).replace(mg3CbXMA2ouZzQDhRqB(u"ࠧ๐ࠩỊ"),HQmDERMFjx).replace(SODvU3Ibq5VzC(u"ࠨ๎ࠪị"),HQmDERMFjx)
		yyE1rWYKlMaJfLv = yyE1rWYKlMaJfLv.replace(YJxaX0MQOHb8oyCBFdnIAe(u"ࠩ๓ࠫỌ"),HQmDERMFjx).replace(OzU6t0qcH7MQabeBYK8vgoG(u"ࠪ๑ࠬọ"),HQmDERMFjx).replace(dBi72erQEtKDOwjNFaoAgSP(u"ࠫ๗࠭Ỏ"),HQmDERMFjx).replace(HDpmv4UXzlf72SK9(u"ࠬฒࠧỏ"),HQmDERMFjx).replace(mgLADoQ1pbtY(u"࠭เࠨỐ"),HQmDERMFjx)
		if yyE1rWYKlMaJfLv: wUx9pu5DKRHcGYstkJfTr6Q3FCeXmE.append(yyE1rWYKlMaJfLv)
	vvLFY8CiE0sVrwM1zAWjt5ePR4cIhy = []
	for DvGaoUZE5S4wxfHc910sz in range(o4bNzIQGYj8En,X2crmy67eZpkGTRd(u"࠴࠳ᾉ")):
		search = AAlMouYR7549BDtWw.sample(wUx9pu5DKRHcGYstkJfTr6Q3FCeXmE,CH7RKuDVzN9f06q8MtXPhlvIxakEWg)[o4bNzIQGYj8En]
		if search in vvLFY8CiE0sVrwM1zAWjt5ePR4cIhy: continue
		vvLFY8CiE0sVrwM1zAWjt5ePR4cIhy.append(search)
		ZvCajmoUedFL = AAlMouYR7549BDtWw.sample(szNbDL2SXAPyGcTU0pREu6,CH7RKuDVzN9f06q8MtXPhlvIxakEWg)[o4bNzIQGYj8En]
		vv8DyVrLOPAXFIMZ9h(RRWFdpe04EK1Qn,LLe5QGmjCZigv(HDLtdMAy7wPkl8aKC3O2)+k4IUieraScH9DV1N7pJgQosYAx5l(u"ࠧࠡࠢࠣࡖࡦࡴࡤࡰ࡯࡚ࠣ࡮ࡪࡥࡰࠢࡖࡩࡦࡸࡣࡩࠢࠣࠤࡸ࡯ࡴࡦ࠼ࠪố")+str(ZvCajmoUedFL)+ShnRVsifKtc60zqQ(u"ࠨࠢࠣࡷࡪࡧࡲࡤࡪ࠽ࠫỒ")+search)
		ddCehb9TygPN5HnMZKBEJA3W42romX,yG0k5pe3mH2,TZRm3tqUKHucWGQ9h08 = h8J6YwoHNtia4LXDVjs0GbW(ZvCajmoUedFL)
		yG0k5pe3mH2(search+maUl7SPesynF1j(u"ࠩࡢࡒࡔࡊࡉࡂࡎࡒࡋࡘࡥࠧồ"))
		if len(Jzthpc2nj5.menuItemsLIST)>o4bNzIQGYj8En: break
	search = search.replace(SODvU3Ibq5VzC(u"ࠪࡣࡒࡕࡄࡠࠩỔ"),HQmDERMFjx)
	F3aCcfSlKPU4RjiLvA1Z7Er[o4bNzIQGYj8En][CH7RKuDVzN9f06q8MtXPhlvIxakEWg] = HDpmv4UXzlf72SK9(u"ࠫࡠ࠭ổ")+ao3Q5jP8H0sMxK2iUYwZGE+search+cjqzOQ5GXD4kR+CDwSWB4v39N7(u"ࠬࠦ࠺ษฯฮࠤ฾์࡝ࠨỖ")
	Jzthpc2nj5.menuItemsLIST[:] = DpYuWyCUZ6OTezPS7ba2o9KFnR1mt(Jzthpc2nj5.menuItemsLIST)
	if len(Jzthpc2nj5.menuItemsLIST)>xg58yJ9YKiPbnoupDIwsqOC2m6H3: Jzthpc2nj5.menuItemsLIST[:] = AAlMouYR7549BDtWw.sample(Jzthpc2nj5.menuItemsLIST,xg58yJ9YKiPbnoupDIwsqOC2m6H3)
	Jzthpc2nj5.menuItemsLIST[:] = F3aCcfSlKPU4RjiLvA1Z7Er+Jzthpc2nj5.menuItemsLIST
	return
def SS3ukvBbjKrAVci4F(XPEt4S3Idjofp0CsHOVkKzg67,LlsCEXIte1n9TG0BAVOojqyvQkhb5):
	XPEt4S3Idjofp0CsHOVkKzg67 = XPEt4S3Idjofp0CsHOVkKzg67.replace(ELfMeDTIFhJt685K(u"࠭࡟ࡎࡑࡇࡣࠬỗ"),HQmDERMFjx)
	LlsCEXIte1n9TG0BAVOojqyvQkhb5 = LlsCEXIte1n9TG0BAVOojqyvQkhb5.replace(KhUG1NV9bln5zXjptqFW6dgo(u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩỘ"),HQmDERMFjx).replace(k4IUieraScH9DV1N7pJgQosYAx5l(u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬộ"),HQmDERMFjx)
	XxspN4wUYiuK50fvbCB1LAk(mic3MEN709xOkrjD5ZvbGIlX6)
	if not f9n0wLB5oxavA: return
	if OBsrtQo2pPlgURCxJYbj9iXMD(u"ࠩࡢࡖࡆࡔࡄࡐࡏࡢࠫỚ") in LlsCEXIte1n9TG0BAVOojqyvQkhb5:
		CfgK4s13Q0hZcHyleT2bVJO9(n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"ࠪࡪࡴࡲࡤࡦࡴࠪớ"),OBsrtQo2pPlgURCxJYbj9iXMD(u"ࠫࡠ࠭Ờ")+ao3Q5jP8H0sMxK2iUYwZGE+XPEt4S3Idjofp0CsHOVkKzg67+cjqzOQ5GXD4kR+OzU6t0qcH7MQabeBYK8vgoG(u"ࠬࠦ࠺ศๆๅื๊ࡣࠧờ"),XPEt4S3Idjofp0CsHOVkKzg67,HDpmv4UXzlf72SK9(u"࠴࠺࠻ᾊ"),HQmDERMFjx,HQmDERMFjx,ELfMeDTIFhJt685K(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫỞ")+LlsCEXIte1n9TG0BAVOojqyvQkhb5)
		CfgK4s13Q0hZcHyleT2bVJO9(EAVanJj1ers2GQud(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧở"),LHX65I9nkx0PstgcVY24uSi(u"ࠨว฼หิฯࠠศๆฺ่อࠦวๅ฻ื์ฬฬ๊ࠡ็้ࠤ๋็ำࠡษ็ๆุ๋ࠧỠ"),XPEt4S3Idjofp0CsHOVkKzg67,KhUG1NV9bln5zXjptqFW6dgo(u"࠵࠻࠼ᾋ"),HQmDERMFjx,HQmDERMFjx,owbMhINBQsmx70guApW(u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧỡ")+LlsCEXIte1n9TG0BAVOojqyvQkhb5)
		CfgK4s13Q0hZcHyleT2bVJO9(KhUG1NV9bln5zXjptqFW6dgo(u"ࠪࡰ࡮ࡴ࡫ࠨỢ"),ao3Q5jP8H0sMxK2iUYwZGE+Tcf5Ppn9UajDbzyM(u"ࠫࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡࠩợ")+cjqzOQ5GXD4kR,HQmDERMFjx,maUl7SPesynF1j(u"࠾࠿࠹࠺ᾌ"))
	for website in sorted(list(f9n0wLB5oxavA[XPEt4S3Idjofp0CsHOVkKzg67].keys())):
		arsOBITUkup7x3eSfEvM,XyOvPTlmBK4hDVjfi,url,sO2tCugL8I,kALyrFT6KPNGI7Oiup82Qb4JCq0td,zmL397efNlks5uTEV,NN9niuC7RoqmhkL2,nObHm3uEzJ,GoC84Eq3azJwpSWxkctF1MdTruOIyb = f9n0wLB5oxavA[XPEt4S3Idjofp0CsHOVkKzg67][website]
		if SODvU3Ibq5VzC(u"ࠬࡥࡒࡂࡐࡇࡓࡒࡥࠧỤ") in LlsCEXIte1n9TG0BAVOojqyvQkhb5 or len(f9n0wLB5oxavA[XPEt4S3Idjofp0CsHOVkKzg67])==CH7RKuDVzN9f06q8MtXPhlvIxakEWg:
			RdOsz9X36gaxeuQWEvJ7wVIp02i8F(arsOBITUkup7x3eSfEvM,HQmDERMFjx,url,sO2tCugL8I,HQmDERMFjx,zmL397efNlks5uTEV,NN9niuC7RoqmhkL2,HQmDERMFjx,HQmDERMFjx)
			Jzthpc2nj5.menuItemsLIST[:] = DpYuWyCUZ6OTezPS7ba2o9KFnR1mt(Jzthpc2nj5.menuItemsLIST)
			bIKWSZ1NoxE52mRyvQGeLuVl,f4fmxb3dPe = Jzthpc2nj5.menuItemsLIST[:UUR70c8L9yTp3A2ajlmJqkQz],Jzthpc2nj5.menuItemsLIST[UUR70c8L9yTp3A2ajlmJqkQz:]
			if PPAUFrY8cduRT(u"࠭࡟ࡓࡃࡑࡈࡔࡓ࡟ࠨụ") in LlsCEXIte1n9TG0BAVOojqyvQkhb5:
				for yuYts1RONXgp in range(YJxaX0MQOHb8oyCBFdnIAe(u"࠿ᾍ")): AAlMouYR7549BDtWw.shuffle(f4fmxb3dPe)
				Jzthpc2nj5.menuItemsLIST[:] = bIKWSZ1NoxE52mRyvQGeLuVl+f4fmxb3dPe[:xg58yJ9YKiPbnoupDIwsqOC2m6H3]
			else: Jzthpc2nj5.menuItemsLIST[:] = bIKWSZ1NoxE52mRyvQGeLuVl+f4fmxb3dPe
		elif A0aqj9uclgOtByJ6F4bz(u"ࠧࡠࡕࡌࡘࡊ࡙࡟ࠨỦ") in LlsCEXIte1n9TG0BAVOojqyvQkhb5: CfgK4s13Q0hZcHyleT2bVJO9(ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨủ"),website,url,sO2tCugL8I,kALyrFT6KPNGI7Oiup82Qb4JCq0td,zmL397efNlks5uTEV,NN9niuC7RoqmhkL2,nObHm3uEzJ,GoC84Eq3azJwpSWxkctF1MdTruOIyb)
	return
def CdKgn9oB4GQA(LlsCEXIte1n9TG0BAVOojqyvQkhb5,lXBL3WrM2JFYm):
	LlsCEXIte1n9TG0BAVOojqyvQkhb5 = LlsCEXIte1n9TG0BAVOojqyvQkhb5.replace(U0VwOviFaYPz2QGs45mJhMXf7Zk(u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫỨ"),HQmDERMFjx).replace(ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧứ"),HQmDERMFjx)
	XyOvPTlmBK4hDVjfi,f4fmxb3dPe = HQmDERMFjx,[]
	CfgK4s13Q0hZcHyleT2bVJO9(mg3CbXMA2ouZzQDhRqB(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫỪ"),KKi79PFqsYB0dWSRgaJ3DyE(u"ࠬࡡࠧừ")+ao3Q5jP8H0sMxK2iUYwZGE+XyOvPTlmBK4hDVjfi+cjqzOQ5GXD4kR+pCTzbw4GyVJHjkcIMQ(u"࠭ࠠ࠻ษ็ๆุ๋࡝ࠨỬ"),HQmDERMFjx,lXBL3WrM2JFYm,HQmDERMFjx,HQmDERMFjx,nz8x32hX0qcjUPFZk5RdJsiwED(u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬử")+LlsCEXIte1n9TG0BAVOojqyvQkhb5)
	CfgK4s13Q0hZcHyleT2bVJO9(pCTzbw4GyVJHjkcIMQ(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨỮ"),EAVanJj1ers2GQud(u"ࠩศ฽ฬีษูࠡ็ฬ่ࠥำๆࠢ฼ุํอฦ๋ࠩữ"),HQmDERMFjx,lXBL3WrM2JFYm,HQmDERMFjx,HQmDERMFjx,owbMhINBQsmx70guApW(u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨỰ")+LlsCEXIte1n9TG0BAVOojqyvQkhb5)
	CfgK4s13Q0hZcHyleT2bVJO9(ShnRVsifKtc60zqQ(u"ࠫࡱ࡯࡮࡬ࠩự"),ao3Q5jP8H0sMxK2iUYwZGE+ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"ࠬࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࠪỲ")+cjqzOQ5GXD4kR,HQmDERMFjx,KhUG1NV9bln5zXjptqFW6dgo(u"࠹࠺࠻࠼ᾎ"))
	bIKWSZ1NoxE52mRyvQGeLuVl = Jzthpc2nj5.menuItemsLIST[:]
	Jzthpc2nj5.menuItemsLIST[:] = []
	zLZUkrP7ac5 = []
	if A0aqj9uclgOtByJ6F4bz(u"࠭࡟ࡔࡋࡗࡉࡘࡥࠧỳ") in LlsCEXIte1n9TG0BAVOojqyvQkhb5:
		XxspN4wUYiuK50fvbCB1LAk(mic3MEN709xOkrjD5ZvbGIlX6)
		if not f9n0wLB5oxavA: return
		hmwXkxLt6jnQ0JN = list(f9n0wLB5oxavA.keys())
		XPEt4S3Idjofp0CsHOVkKzg67 = AAlMouYR7549BDtWw.sample(hmwXkxLt6jnQ0JN,CH7RKuDVzN9f06q8MtXPhlvIxakEWg)[o4bNzIQGYj8En]
		Cn2Ubwv8h5xzqudSgFt7IDPmYLc = list(f9n0wLB5oxavA[XPEt4S3Idjofp0CsHOVkKzg67].keys())
		website = AAlMouYR7549BDtWw.sample(Cn2Ubwv8h5xzqudSgFt7IDPmYLc,CH7RKuDVzN9f06q8MtXPhlvIxakEWg)[o4bNzIQGYj8En]
		arsOBITUkup7x3eSfEvM,XyOvPTlmBK4hDVjfi,url,sO2tCugL8I,kALyrFT6KPNGI7Oiup82Qb4JCq0td,zmL397efNlks5uTEV,NN9niuC7RoqmhkL2,nObHm3uEzJ,GoC84Eq3azJwpSWxkctF1MdTruOIyb = f9n0wLB5oxavA[XPEt4S3Idjofp0CsHOVkKzg67][website]
		vv8DyVrLOPAXFIMZ9h(RRWFdpe04EK1Qn,LLe5QGmjCZigv(HDLtdMAy7wPkl8aKC3O2)+EF2tvxZHz5n4UruPhaViXKycI6SQR(u"ࠧࠡࠢࠣࡖࡦࡴࡤࡰ࡯ࠣࡇࡦࡺࡥࡨࡱࡵࡽࠥࠦࠠࡸࡧࡥࡷ࡮ࡺࡥ࠻ࠢࠪỴ")+website+HDpmv4UXzlf72SK9(u"ࠨࠢࠣࠤࡳࡧ࡭ࡦ࠼ࠣࠫỵ")+XyOvPTlmBK4hDVjfi+Tcf5Ppn9UajDbzyM(u"ࠩࠣࠤࠥࡻࡲ࡭࠼ࠣࠫỶ")+url+HDpmv4UXzlf72SK9(u"ࠪࠤࠥࠦ࡭ࡰࡦࡨ࠾ࠥ࠭ỷ")+str(sO2tCugL8I))
	elif maUl7SPesynF1j(u"ࠫࡤࡏࡐࡕࡘࡢࠫỸ") in LlsCEXIte1n9TG0BAVOojqyvQkhb5:
		import rrF9yjmgo4
		if not rrF9yjmgo4.NJUG7VWM1tLgQKBip0d(HQmDERMFjx,gyd2rf0UR5): return
		for fyJ27mwDtuZgzKXG6jbE in range(CH7RKuDVzN9f06q8MtXPhlvIxakEWg,L3C1YrQDi840ShlOJcNGe+CH7RKuDVzN9f06q8MtXPhlvIxakEWg):
			zLZUkrP7ac5 += vv1GdoOpbLR2gfVxrlj4IQz9t(str(fyJ27mwDtuZgzKXG6jbE),LlsCEXIte1n9TG0BAVOojqyvQkhb5)
		if not zLZUkrP7ac5: return
		arsOBITUkup7x3eSfEvM,XyOvPTlmBK4hDVjfi,url,sO2tCugL8I,kALyrFT6KPNGI7Oiup82Qb4JCq0td,zmL397efNlks5uTEV,NN9niuC7RoqmhkL2,nObHm3uEzJ,GoC84Eq3azJwpSWxkctF1MdTruOIyb = AAlMouYR7549BDtWw.sample(zLZUkrP7ac5,CH7RKuDVzN9f06q8MtXPhlvIxakEWg)[o4bNzIQGYj8En]
		vv8DyVrLOPAXFIMZ9h(RRWFdpe04EK1Qn,LLe5QGmjCZigv(HDLtdMAy7wPkl8aKC3O2)+OBsrtQo2pPlgURCxJYbj9iXMD(u"ࠬࠦࠠࠡࡔࡤࡲࡩࡵ࡭ࠡࡅࡤࡸࡪ࡭࡯ࡳࡻࠣࠤࠥࡴࡡ࡮ࡧ࠽ࠤࠬỹ")+XyOvPTlmBK4hDVjfi+OBsrtQo2pPlgURCxJYbj9iXMD(u"࠭ࠠࠡࠢࡸࡶࡱࡀࠠࠨỺ")+url+OBsrtQo2pPlgURCxJYbj9iXMD(u"ࠧࠡࠢࠣࡱࡴࡪࡥ࠻ࠢࠪỻ")+str(sO2tCugL8I))
	elif EAVanJj1ers2GQud(u"ࠨࡡࡐ࠷࡚ࡥࠧỼ") in LlsCEXIte1n9TG0BAVOojqyvQkhb5:
		import BBlniQqbfT
		if not BBlniQqbfT.NJUG7VWM1tLgQKBip0d(HQmDERMFjx,gyd2rf0UR5): return
		for fyJ27mwDtuZgzKXG6jbE in range(CH7RKuDVzN9f06q8MtXPhlvIxakEWg,L3C1YrQDi840ShlOJcNGe+CH7RKuDVzN9f06q8MtXPhlvIxakEWg):
			zLZUkrP7ac5 += gwzqWMVAEU48SdxpH9D(str(fyJ27mwDtuZgzKXG6jbE),LlsCEXIte1n9TG0BAVOojqyvQkhb5)
		if not zLZUkrP7ac5: return
		arsOBITUkup7x3eSfEvM,XyOvPTlmBK4hDVjfi,url,sO2tCugL8I,kALyrFT6KPNGI7Oiup82Qb4JCq0td,zmL397efNlks5uTEV,NN9niuC7RoqmhkL2,nObHm3uEzJ,GoC84Eq3azJwpSWxkctF1MdTruOIyb = AAlMouYR7549BDtWw.sample(zLZUkrP7ac5,CH7RKuDVzN9f06q8MtXPhlvIxakEWg)[o4bNzIQGYj8En]
		vv8DyVrLOPAXFIMZ9h(RRWFdpe04EK1Qn,LLe5QGmjCZigv(HDLtdMAy7wPkl8aKC3O2)+knTyjJ0sGIzuwbxRae(u"ࠩࠣࠤࠥࡘࡡ࡯ࡦࡲࡱࠥࡉࡡࡵࡧࡪࡳࡷࡿࠠࠡࠢࡱࡥࡲ࡫࠺ࠡࠩỽ")+XyOvPTlmBK4hDVjfi+knTyjJ0sGIzuwbxRae(u"ࠪࠤࠥࠦࡵࡳ࡮࠽ࠤࠬỾ")+url+OBsrtQo2pPlgURCxJYbj9iXMD(u"ࠫࠥࠦࠠ࡮ࡱࡧࡩ࠿ࠦࠧỿ")+str(sO2tCugL8I))
	XXNe4H7oW5GQP = XyOvPTlmBK4hDVjfi
	XHGt1ubQnLOiZTfJaC0YVxqsASD5 = []
	for yuYts1RONXgp in range(o4bNzIQGYj8En,cWbkR6iUZsnJQj14(u"࠲࠲ᾏ")):
		if yuYts1RONXgp>o4bNzIQGYj8En: vv8DyVrLOPAXFIMZ9h(RRWFdpe04EK1Qn,LLe5QGmjCZigv(HDLtdMAy7wPkl8aKC3O2)+OBsrtQo2pPlgURCxJYbj9iXMD(u"ࠬࠦࠠࠡࡔࡤࡲࡩࡵ࡭ࠡࡅࡤࡸࡪ࡭࡯ࡳࡻࠣࠤࠥࡴࡡ࡮ࡧ࠽ࠤࠬἀ")+XyOvPTlmBK4hDVjfi+mgLADoQ1pbtY(u"࠭ࠠࠡࠢࡸࡶࡱࡀࠠࠨἁ")+url+owbMhINBQsmx70guApW(u"ࠧࠡࠢࠣࡱࡴࡪࡥ࠻ࠢࠪἂ")+str(sO2tCugL8I))
		Jzthpc2nj5.menuItemsLIST[:] = []
		if sO2tCugL8I==JJA7fypmZFVlazvNI(u"࠴࠶࠸ᾐ") and X2crmy67eZpkGTRd(u"ࠨࡡࡢࡍࡕ࡚ࡖࡔࡧࡵ࡭ࡪࡹ࡟ࡠࠩἃ") in NN9niuC7RoqmhkL2: sO2tCugL8I = k4IUieraScH9DV1N7pJgQosYAx5l(u"࠵࠷࠸ᾑ")
		if sO2tCugL8I==A0aqj9uclgOtByJ6F4bz(u"࠻࠶࠺ᾒ") and ShnRVsifKtc60zqQ(u"ࠩࡢࡣࡒ࠹ࡕࡔࡧࡵ࡭ࡪࡹ࡟ࡠࠩἄ") in NN9niuC7RoqmhkL2: sO2tCugL8I = C3ZK1pu4rfmj8TsWUtBaM(u"࠼࠷࠳ᾓ")
		if sO2tCugL8I==OBsrtQo2pPlgURCxJYbj9iXMD(u"࠷࠴࠵ᾔ"): sO2tCugL8I = OzU6t0qcH7MQabeBYK8vgoG(u"࠲࠺࠳ᾕ")
		RZ9V4eABCTfIO1FUrz2ks5DSwu = RdOsz9X36gaxeuQWEvJ7wVIp02i8F(arsOBITUkup7x3eSfEvM,XyOvPTlmBK4hDVjfi,url,sO2tCugL8I,kALyrFT6KPNGI7Oiup82Qb4JCq0td,zmL397efNlks5uTEV,NN9niuC7RoqmhkL2,nObHm3uEzJ,GoC84Eq3azJwpSWxkctF1MdTruOIyb)
		if X2crmy67eZpkGTRd(u"ࠪࡣࡎࡖࡔࡗࡡࠪἅ") in LlsCEXIte1n9TG0BAVOojqyvQkhb5 and sO2tCugL8I==mg3CbXMA2ouZzQDhRqB(u"࠲࠸࠺ᾖ"): del Jzthpc2nj5.menuItemsLIST[:UUR70c8L9yTp3A2ajlmJqkQz]
		if A0aqj9uclgOtByJ6F4bz(u"ࠫࡤࡓ࠳ࡖࡡࠪἆ") in LlsCEXIte1n9TG0BAVOojqyvQkhb5 and sO2tCugL8I==KKi79PFqsYB0dWSRgaJ3DyE(u"࠳࠹࠼ᾗ"): del Jzthpc2nj5.menuItemsLIST[:UUR70c8L9yTp3A2ajlmJqkQz]
		f4fmxb3dPe[:] = DpYuWyCUZ6OTezPS7ba2o9KFnR1mt(Jzthpc2nj5.menuItemsLIST)
		if XHGt1ubQnLOiZTfJaC0YVxqsASD5 and DmOqnYKsWSbE1X9VMGQR4gvAUejPf(EF2tvxZHz5n4UruPhaViXKycI6SQR(u"ࡺ࠭อๅไฬࠫἇ")) in str(f4fmxb3dPe) or DmOqnYKsWSbE1X9VMGQR4gvAUejPf(CDwSWB4v39N7(u"ࡻࠧฮๆๅ๋ࠬἈ")) in str(f4fmxb3dPe):
			XyOvPTlmBK4hDVjfi = XXNe4H7oW5GQP
			f4fmxb3dPe[:] = XHGt1ubQnLOiZTfJaC0YVxqsASD5
			break
		XXNe4H7oW5GQP = XyOvPTlmBK4hDVjfi
		XHGt1ubQnLOiZTfJaC0YVxqsASD5 = f4fmxb3dPe
		if str(f4fmxb3dPe).count(mg3CbXMA2ouZzQDhRqB(u"ࠧࡷ࡫ࡧࡩࡴ࠭Ἁ"))>o4bNzIQGYj8En: break
		if str(f4fmxb3dPe).count(knTyjJ0sGIzuwbxRae(u"ࠨ࡮࡬ࡺࡪ࠭Ἂ"))>o4bNzIQGYj8En: break
		if sO2tCugL8I==EF2tvxZHz5n4UruPhaViXKycI6SQR(u"࠵࠷࠸ᾘ"): break
		if sO2tCugL8I==ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"࠻࠶࠹ᾙ"): break
		if sO2tCugL8I==U0VwOviFaYPz2QGs45mJhMXf7Zk(u"࠷࠿࠱ᾚ"): break
		if YJxaX0MQOHb8oyCBFdnIAe(u"ࠩࡢࡖࡆࡔࡄࡐࡏࡢࠫἋ") in LlsCEXIte1n9TG0BAVOojqyvQkhb5 and f4fmxb3dPe: arsOBITUkup7x3eSfEvM,XyOvPTlmBK4hDVjfi,url,sO2tCugL8I,kALyrFT6KPNGI7Oiup82Qb4JCq0td,zmL397efNlks5uTEV,NN9niuC7RoqmhkL2,nObHm3uEzJ,GoC84Eq3azJwpSWxkctF1MdTruOIyb = AAlMouYR7549BDtWw.sample(f4fmxb3dPe,CH7RKuDVzN9f06q8MtXPhlvIxakEWg)[o4bNzIQGYj8En]
	if not XyOvPTlmBK4hDVjfi: XyOvPTlmBK4hDVjfi = knTyjJ0sGIzuwbxRae(u"ࠪ࠲࠳࠴࠮ࠨἌ")
	elif XyOvPTlmBK4hDVjfi.count(HDpmv4UXzlf72SK9(u"ࠫࡤ࠭Ἅ"))>CH7RKuDVzN9f06q8MtXPhlvIxakEWg: XyOvPTlmBK4hDVjfi = XyOvPTlmBK4hDVjfi.split(EAVanJj1ers2GQud(u"ࠬࡥࠧἎ"),FFHRwuxQmbh8BaTqyX3)[FFHRwuxQmbh8BaTqyX3]
	XyOvPTlmBK4hDVjfi = XyOvPTlmBK4hDVjfi.replace(n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"࠭ࡕࡏࡍࡑࡓ࡜ࡔ࠺ࠡࠩἏ"),HQmDERMFjx)
	XyOvPTlmBK4hDVjfi = XyOvPTlmBK4hDVjfi.replace(mgLADoQ1pbtY(u"ࠧࡠࡏࡒࡈࡤ࠭ἐ"),HQmDERMFjx)
	bIKWSZ1NoxE52mRyvQGeLuVl[o4bNzIQGYj8En][CH7RKuDVzN9f06q8MtXPhlvIxakEWg] = dBi72erQEtKDOwjNFaoAgSP(u"ࠨ࡝ࠪἑ")+ao3Q5jP8H0sMxK2iUYwZGE+XyOvPTlmBK4hDVjfi+cjqzOQ5GXD4kR+KKi79PFqsYB0dWSRgaJ3DyE(u"ࠩࠣ࠾ฬ๊โิ็ࡠࠫἒ")
	if KhUG1NV9bln5zXjptqFW6dgo(u"ࠪࡣࡗࡇࡎࡅࡑࡐࡣࠬἓ") in LlsCEXIte1n9TG0BAVOojqyvQkhb5:
		for yuYts1RONXgp in range(X2crmy67eZpkGTRd(u"࠿ᾛ")): AAlMouYR7549BDtWw.shuffle(f4fmxb3dPe)
		Jzthpc2nj5.menuItemsLIST[:] = bIKWSZ1NoxE52mRyvQGeLuVl+f4fmxb3dPe[:xg58yJ9YKiPbnoupDIwsqOC2m6H3]
	else: Jzthpc2nj5.menuItemsLIST[:] = bIKWSZ1NoxE52mRyvQGeLuVl+f4fmxb3dPe
	return
def ni8TFoORQ5WBLC4tck(l9JMy14zeW5xVurfkZImGUP,Em1DCWYtFd79yU2PlpvMBOqJbhGz):
	Em1DCWYtFd79yU2PlpvMBOqJbhGz = Em1DCWYtFd79yU2PlpvMBOqJbhGz.replace(YJxaX0MQOHb8oyCBFdnIAe(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭ἔ"),HQmDERMFjx).replace(Tcf5Ppn9UajDbzyM(u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩἕ"),HQmDERMFjx)
	uyn2omAtRCKrvUG5WZXS1Q = Em1DCWYtFd79yU2PlpvMBOqJbhGz
	if YJxaX0MQOHb8oyCBFdnIAe(u"࠭࡟ࡠࡋࡓࡘ࡛࡙ࡥࡳ࡫ࡨࡷࡤࡥࠧ἖") in Em1DCWYtFd79yU2PlpvMBOqJbhGz:
		uyn2omAtRCKrvUG5WZXS1Q = Em1DCWYtFd79yU2PlpvMBOqJbhGz.split(mgLADoQ1pbtY(u"ࠧࡠࡡࡌࡔ࡙࡜ࡓࡦࡴ࡬ࡩࡸࡥ࡟ࠨ἗"))[o4bNzIQGYj8En]
		type = EAVanJj1ers2GQud(u"ࠨ࠮ࡖࡉࡗࡏࡅࡔ࠼ࠣࠫἘ")
	elif ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"࡙ࠩࡓࡉ࠭Ἑ") in l9JMy14zeW5xVurfkZImGUP: type = ELfMeDTIFhJt685K(u"ࠪ࠰࡛ࡏࡄࡆࡑࡖ࠾ࠥ࠭Ἒ")
	elif pCTzbw4GyVJHjkcIMQ(u"ࠫࡑࡏࡖࡆࠩἛ") in l9JMy14zeW5xVurfkZImGUP: type = maUl7SPesynF1j(u"ࠬ࠲ࡌࡊࡘࡈ࠾ࠥ࠭Ἔ")
	CfgK4s13Q0hZcHyleT2bVJO9(k4IUieraScH9DV1N7pJgQosYAx5l(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ἕ"),LHX65I9nkx0PstgcVY24uSi(u"ࠧ࡜ࠩ἞")+ao3Q5jP8H0sMxK2iUYwZGE+type+uyn2omAtRCKrvUG5WZXS1Q+cjqzOQ5GXD4kR+U0VwOviFaYPz2QGs45mJhMXf7Zk(u"ࠨࠢ࠽ห้่ำๆ࡟ࠪ἟"),l9JMy14zeW5xVurfkZImGUP,n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"࠱࠷࠹ᾜ"),HQmDERMFjx,HQmDERMFjx,EAVanJj1ers2GQud(u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧἠ")+Em1DCWYtFd79yU2PlpvMBOqJbhGz)
	CfgK4s13Q0hZcHyleT2bVJO9(A0aqj9uclgOtByJ6F4bz(u"ࠪࡪࡴࡲࡤࡦࡴࠪἡ"),dBi72erQEtKDOwjNFaoAgSP(u"ࠫส฿วะหࠣห้฽ไษࠢส่฾ฺ่ศศํࠤ๊์ࠠ็ใึࠤฬ๊โิ็ࠪἢ"),l9JMy14zeW5xVurfkZImGUP,KhUG1NV9bln5zXjptqFW6dgo(u"࠲࠸࠺ᾝ"),HQmDERMFjx,HQmDERMFjx,dBi72erQEtKDOwjNFaoAgSP(u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪἣ")+Em1DCWYtFd79yU2PlpvMBOqJbhGz)
	CfgK4s13Q0hZcHyleT2bVJO9(n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"࠭࡬ࡪࡰ࡮ࠫἤ"),ao3Q5jP8H0sMxK2iUYwZGE+owbMhINBQsmx70guApW(u"ࠧ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࠬἥ")+cjqzOQ5GXD4kR,HQmDERMFjx,Tcf5Ppn9UajDbzyM(u"࠻࠼࠽࠾ᾞ"))
	import rrF9yjmgo4
	for fyJ27mwDtuZgzKXG6jbE in range(CH7RKuDVzN9f06q8MtXPhlvIxakEWg,L3C1YrQDi840ShlOJcNGe+CH7RKuDVzN9f06q8MtXPhlvIxakEWg):
		if nz8x32hX0qcjUPFZk5RdJsiwED(u"ࠨࡡࡢࡍࡕ࡚ࡖࡔࡧࡵ࡭ࡪࡹ࡟ࡠࠩἦ") in Em1DCWYtFd79yU2PlpvMBOqJbhGz: rrF9yjmgo4.QQJzovgOaCt5yLFkeN(str(fyJ27mwDtuZgzKXG6jbE),l9JMy14zeW5xVurfkZImGUP,Em1DCWYtFd79yU2PlpvMBOqJbhGz,HQmDERMFjx,mic3MEN709xOkrjD5ZvbGIlX6)
		else: rrF9yjmgo4.ddJ6F4hjPOTzKf0ulbQEoq7nwCV2(str(fyJ27mwDtuZgzKXG6jbE),l9JMy14zeW5xVurfkZImGUP,Em1DCWYtFd79yU2PlpvMBOqJbhGz,HQmDERMFjx,mic3MEN709xOkrjD5ZvbGIlX6)
	Jzthpc2nj5.menuItemsLIST[:] = DpYuWyCUZ6OTezPS7ba2o9KFnR1mt(Jzthpc2nj5.menuItemsLIST)
	if len(Jzthpc2nj5.menuItemsLIST)>(xg58yJ9YKiPbnoupDIwsqOC2m6H3+UUR70c8L9yTp3A2ajlmJqkQz): Jzthpc2nj5.menuItemsLIST[:] = Jzthpc2nj5.menuItemsLIST[:UUR70c8L9yTp3A2ajlmJqkQz]+AAlMouYR7549BDtWw.sample(Jzthpc2nj5.menuItemsLIST[UUR70c8L9yTp3A2ajlmJqkQz:],xg58yJ9YKiPbnoupDIwsqOC2m6H3)
	return
def RpWGSOYl1PsITL7wZeiH8(l9JMy14zeW5xVurfkZImGUP,Em1DCWYtFd79yU2PlpvMBOqJbhGz):
	Em1DCWYtFd79yU2PlpvMBOqJbhGz = Em1DCWYtFd79yU2PlpvMBOqJbhGz.replace(A0aqj9uclgOtByJ6F4bz(u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫἧ"),HQmDERMFjx).replace(owbMhINBQsmx70guApW(u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧἨ"),HQmDERMFjx)
	uyn2omAtRCKrvUG5WZXS1Q = Em1DCWYtFd79yU2PlpvMBOqJbhGz
	if PPAUFrY8cduRT(u"ࠫࡤࡥࡍ࠴ࡗࡖࡩࡷ࡯ࡥࡴࡡࡢࠫἩ") in Em1DCWYtFd79yU2PlpvMBOqJbhGz:
		uyn2omAtRCKrvUG5WZXS1Q = Em1DCWYtFd79yU2PlpvMBOqJbhGz.split(nz8x32hX0qcjUPFZk5RdJsiwED(u"ࠬࡥ࡟ࡎ࠵ࡘࡗࡪࡸࡩࡦࡵࡢࡣࠬἪ"))[o4bNzIQGYj8En]
		type = ShnRVsifKtc60zqQ(u"࠭ࠬࡔࡇࡕࡍࡊ࡙࠺ࠡࠩἫ")
	elif X2crmy67eZpkGTRd(u"ࠧࡗࡑࡇࠫἬ") in l9JMy14zeW5xVurfkZImGUP: type = ShnRVsifKtc60zqQ(u"ࠨ࠮࡙ࡍࡉࡋࡏࡔ࠼ࠣࠫἭ")
	elif EF2tvxZHz5n4UruPhaViXKycI6SQR(u"ࠩࡏࡍ࡛ࡋࠧἮ") in l9JMy14zeW5xVurfkZImGUP: type = cWbkR6iUZsnJQj14(u"ࠪ࠰ࡑࡏࡖࡆ࠼ࠣࠫἯ")
	CfgK4s13Q0hZcHyleT2bVJO9(X2crmy67eZpkGTRd(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫἰ"),CDwSWB4v39N7(u"ࠬࡡࠧἱ")+ao3Q5jP8H0sMxK2iUYwZGE+type+uyn2omAtRCKrvUG5WZXS1Q+cjqzOQ5GXD4kR+OBsrtQo2pPlgURCxJYbj9iXMD(u"࠭ࠠ࠻ษ็ๆุ๋࡝ࠨἲ"),l9JMy14zeW5xVurfkZImGUP,EF2tvxZHz5n4UruPhaViXKycI6SQR(u"࠴࠺࠽ᾟ"),HQmDERMFjx,HQmDERMFjx,OBsrtQo2pPlgURCxJYbj9iXMD(u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬἳ")+Em1DCWYtFd79yU2PlpvMBOqJbhGz)
	CfgK4s13Q0hZcHyleT2bVJO9(EF2tvxZHz5n4UruPhaViXKycI6SQR(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨἴ"),LHX65I9nkx0PstgcVY24uSi(u"ࠩศ฽ฬีษࠡษ็฻้ฮࠠศๆ฼ุํอฦ๋่๊ࠢࠥ์แิࠢส่็ูๅࠨἵ"),l9JMy14zeW5xVurfkZImGUP,LHX65I9nkx0PstgcVY24uSi(u"࠵࠻࠾ᾠ"),HQmDERMFjx,HQmDERMFjx,n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨἶ")+Em1DCWYtFd79yU2PlpvMBOqJbhGz)
	CfgK4s13Q0hZcHyleT2bVJO9(HDpmv4UXzlf72SK9(u"ࠫࡱ࡯࡮࡬ࠩἷ"),ao3Q5jP8H0sMxK2iUYwZGE+nz8x32hX0qcjUPFZk5RdJsiwED(u"ࠬࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࠪἸ")+cjqzOQ5GXD4kR,HQmDERMFjx,HDpmv4UXzlf72SK9(u"࠾࠿࠹࠺ᾡ"))
	import BBlniQqbfT
	for fyJ27mwDtuZgzKXG6jbE in range(CH7RKuDVzN9f06q8MtXPhlvIxakEWg,L3C1YrQDi840ShlOJcNGe+CH7RKuDVzN9f06q8MtXPhlvIxakEWg):
		if OBsrtQo2pPlgURCxJYbj9iXMD(u"࠭࡟ࡠࡏ࠶࡙ࡘ࡫ࡲࡪࡧࡶࡣࡤ࠭Ἱ") in Em1DCWYtFd79yU2PlpvMBOqJbhGz: BBlniQqbfT.QQJzovgOaCt5yLFkeN(str(fyJ27mwDtuZgzKXG6jbE),l9JMy14zeW5xVurfkZImGUP,Em1DCWYtFd79yU2PlpvMBOqJbhGz,HQmDERMFjx,mic3MEN709xOkrjD5ZvbGIlX6)
		else: BBlniQqbfT.ddJ6F4hjPOTzKf0ulbQEoq7nwCV2(str(fyJ27mwDtuZgzKXG6jbE),l9JMy14zeW5xVurfkZImGUP,Em1DCWYtFd79yU2PlpvMBOqJbhGz,HQmDERMFjx,mic3MEN709xOkrjD5ZvbGIlX6)
	Jzthpc2nj5.menuItemsLIST[:] = DpYuWyCUZ6OTezPS7ba2o9KFnR1mt(Jzthpc2nj5.menuItemsLIST)
	if len(Jzthpc2nj5.menuItemsLIST)>(xg58yJ9YKiPbnoupDIwsqOC2m6H3+UUR70c8L9yTp3A2ajlmJqkQz): Jzthpc2nj5.menuItemsLIST[:] = Jzthpc2nj5.menuItemsLIST[:UUR70c8L9yTp3A2ajlmJqkQz]+AAlMouYR7549BDtWw.sample(Jzthpc2nj5.menuItemsLIST[UUR70c8L9yTp3A2ajlmJqkQz:],xg58yJ9YKiPbnoupDIwsqOC2m6H3)
	return
def DpYuWyCUZ6OTezPS7ba2o9KFnR1mt(AloaeInvq2EtcOKYZXSG0y1ujMpd):
	zGTyXIV4bxlAnLQhk3P = []
	for type,XyOvPTlmBK4hDVjfi,url,lXBL3WrM2JFYm,kALyrFT6KPNGI7Oiup82Qb4JCq0td,zmL397efNlks5uTEV,NN9niuC7RoqmhkL2,nObHm3uEzJ,GoC84Eq3azJwpSWxkctF1MdTruOIyb in AloaeInvq2EtcOKYZXSG0y1ujMpd:
		if ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"ࠧึใะอࠬἺ") in XyOvPTlmBK4hDVjfi or Tcf5Ppn9UajDbzyM(u"ࠨืไั์࠭Ἳ") in XyOvPTlmBK4hDVjfi or C3ZK1pu4rfmj8TsWUtBaM(u"ࠩࡳࡥ࡬࡫ࠧἼ") in XyOvPTlmBK4hDVjfi.lower(): continue
		zGTyXIV4bxlAnLQhk3P.append([type,XyOvPTlmBK4hDVjfi,url,lXBL3WrM2JFYm,kALyrFT6KPNGI7Oiup82Qb4JCq0td,zmL397efNlks5uTEV,NN9niuC7RoqmhkL2,nObHm3uEzJ,GoC84Eq3azJwpSWxkctF1MdTruOIyb])
	return zGTyXIV4bxlAnLQhk3P
# -*- coding: utf-8 -*-
import sys as TPW58slaVE9OrYQXZnGo2yAfFzpBxc
tbYWAoeMyHTsgFG5x6huz1 = TPW58slaVE9OrYQXZnGo2yAfFzpBxc.version_info [0] == 2
CUJSAbZztE8vYdGByLH0KcnWqe = 2048
R0QCXnpyL1DJwBH67FW = 7
def kSod2AxqugH0 (LURfCucn30xKsMdTiG):
	global ghCyPxkWILcXrGjVut6MQo59fsv
	MfIpC9TDz7Qa5g2vVqPtXh4 = ord (LURfCucn30xKsMdTiG [-1])
	nndScZEtapB74 = LURfCucn30xKsMdTiG [:-1]
	LRbqugZJAa3192OCewWGHvEcP = MfIpC9TDz7Qa5g2vVqPtXh4 % len (nndScZEtapB74)
	qLc7RGgDQE = nndScZEtapB74 [:LRbqugZJAa3192OCewWGHvEcP] + nndScZEtapB74 [LRbqugZJAa3192OCewWGHvEcP:]
	if tbYWAoeMyHTsgFG5x6huz1:
		XUczap3yA0QqFRC82OH6E5mL = unicode () .join ([unichr (ord (ah5u39EBY81MlrwA0cmoz4ngb7TLed) - CUJSAbZztE8vYdGByLH0KcnWqe - (YMjpxPr8WsJ1Bg6Xd + MfIpC9TDz7Qa5g2vVqPtXh4) % R0QCXnpyL1DJwBH67FW) for YMjpxPr8WsJ1Bg6Xd, ah5u39EBY81MlrwA0cmoz4ngb7TLed in enumerate (qLc7RGgDQE)])
	else:
		XUczap3yA0QqFRC82OH6E5mL = str () .join ([chr (ord (ah5u39EBY81MlrwA0cmoz4ngb7TLed) - CUJSAbZztE8vYdGByLH0KcnWqe - (YMjpxPr8WsJ1Bg6Xd + MfIpC9TDz7Qa5g2vVqPtXh4) % R0QCXnpyL1DJwBH67FW) for YMjpxPr8WsJ1Bg6Xd, ah5u39EBY81MlrwA0cmoz4ngb7TLed in enumerate (qLc7RGgDQE)])
	return eval (XUczap3yA0QqFRC82OH6E5mL)
jL1E5AKfwBDv6xmeQtUXcJ3d,JJA7fypmZFVlazvNI,dBi72erQEtKDOwjNFaoAgSP=kSod2AxqugH0,kSod2AxqugH0,kSod2AxqugH0
CDwSWB4v39N7,k4IUieraScH9DV1N7pJgQosYAx5l,Tcf5Ppn9UajDbzyM=dBi72erQEtKDOwjNFaoAgSP,JJA7fypmZFVlazvNI,jL1E5AKfwBDv6xmeQtUXcJ3d
X2crmy67eZpkGTRd,HDpmv4UXzlf72SK9,C3ZK1pu4rfmj8TsWUtBaM=Tcf5Ppn9UajDbzyM,k4IUieraScH9DV1N7pJgQosYAx5l,CDwSWB4v39N7
mg3CbXMA2ouZzQDhRqB,OBsrtQo2pPlgURCxJYbj9iXMD,ssnfOzb16wVog9GKdqcXR3JC7ktSPA=C3ZK1pu4rfmj8TsWUtBaM,HDpmv4UXzlf72SK9,X2crmy67eZpkGTRd
ShnRVsifKtc60zqQ,KKi79PFqsYB0dWSRgaJ3DyE,OzU6t0qcH7MQabeBYK8vgoG=ssnfOzb16wVog9GKdqcXR3JC7ktSPA,OBsrtQo2pPlgURCxJYbj9iXMD,mg3CbXMA2ouZzQDhRqB
mgLADoQ1pbtY,U0VwOviFaYPz2QGs45mJhMXf7Zk,pCTzbw4GyVJHjkcIMQ=OzU6t0qcH7MQabeBYK8vgoG,KKi79PFqsYB0dWSRgaJ3DyE,ShnRVsifKtc60zqQ
owbMhINBQsmx70guApW,SODvU3Ibq5VzC,PPAUFrY8cduRT=pCTzbw4GyVJHjkcIMQ,U0VwOviFaYPz2QGs45mJhMXf7Zk,mgLADoQ1pbtY
knTyjJ0sGIzuwbxRae,nz8x32hX0qcjUPFZk5RdJsiwED,A0aqj9uclgOtByJ6F4bz=PPAUFrY8cduRT,SODvU3Ibq5VzC,owbMhINBQsmx70guApW
YJxaX0MQOHb8oyCBFdnIAe,n6sfYuHBlVdzgmvpXwR3irON0KIj8,LHX65I9nkx0PstgcVY24uSi=A0aqj9uclgOtByJ6F4bz,nz8x32hX0qcjUPFZk5RdJsiwED,knTyjJ0sGIzuwbxRae
EAVanJj1ers2GQud,ELfMeDTIFhJt685K,EF2tvxZHz5n4UruPhaViXKycI6SQR=LHX65I9nkx0PstgcVY24uSi,n6sfYuHBlVdzgmvpXwR3irON0KIj8,YJxaX0MQOHb8oyCBFdnIAe
KhUG1NV9bln5zXjptqFW6dgo,cWbkR6iUZsnJQj14,maUl7SPesynF1j=EF2tvxZHz5n4UruPhaViXKycI6SQR,ELfMeDTIFhJt685K,EAVanJj1ers2GQud
from FF68kA5BUy import *
HDLtdMAy7wPkl8aKC3O2 = SODvU3Ibq5VzC(u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗࠬၹ")
def kk6X5LxpsND(lXBL3WrM2JFYm,NN9niuC7RoqmhkL2=HQmDERMFjx):
	if   lXBL3WrM2JFYm==EF2tvxZHz5n4UruPhaViXKycI6SQR(u"࠲፬"): NNRKIOUgP3(NN9niuC7RoqmhkL2)
	elif lXBL3WrM2JFYm==JJA7fypmZFVlazvNI(u"࠴፭"): pass
	elif lXBL3WrM2JFYm==U0VwOviFaYPz2QGs45mJhMXf7Zk(u"࠶፮"): YYxk6FtA4PCMr5Zco18LfiwBa(NN9niuC7RoqmhkL2)
	elif lXBL3WrM2JFYm==PPAUFrY8cduRT(u"࠸፯"): NtK32m7q8wRZfohH()
	elif lXBL3WrM2JFYm==A0aqj9uclgOtByJ6F4bz(u"࠺፰"): xxOfZk9LhUAd3jzY6HEBW7JqR8(NN9niuC7RoqmhkL2)
	elif lXBL3WrM2JFYm==n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"࠵፱"): ssL6HduBl7WfoYjZGVN()
	elif lXBL3WrM2JFYm==U0VwOviFaYPz2QGs45mJhMXf7Zk(u"࠷፲"): o5oC3zxwQJfI()
	elif lXBL3WrM2JFYm==OzU6t0qcH7MQabeBYK8vgoG(u"࠹፳"): nnEKsFRwX5ldCQx()
	elif lXBL3WrM2JFYm==HDpmv4UXzlf72SK9(u"࠻፴"): r7GI8c0Mbx5CYDuRfXmzkNLBn()
	elif lXBL3WrM2JFYm==KhUG1NV9bln5zXjptqFW6dgo(u"࠵࠺࠶፵"): z17KE2Wb63lOy()
	elif lXBL3WrM2JFYm==KKi79PFqsYB0dWSRgaJ3DyE(u"࠶࠻࠱፶"): HYLcwyik56E7Qmq1()
	elif lXBL3WrM2JFYm==OBsrtQo2pPlgURCxJYbj9iXMD(u"࠷࠵࠳፷"): Rlxc528tTziyGnmwp1E()
	elif lXBL3WrM2JFYm==pCTzbw4GyVJHjkcIMQ(u"࠱࠶࠵፸"): AzLp2Vv6x0NFajQ45()
	elif lXBL3WrM2JFYm==KhUG1NV9bln5zXjptqFW6dgo(u"࠲࠷࠷፹"): BiYv2rGX01bfR()
	elif lXBL3WrM2JFYm==U0VwOviFaYPz2QGs45mJhMXf7Zk(u"࠳࠸࠹፺"): D4NA7WRd2i15uME9()
	elif lXBL3WrM2JFYm==KKi79PFqsYB0dWSRgaJ3DyE(u"࠴࠹࠻፻"): ERtWfKUOsiI0doTDavk3cAPjJbn()
	elif lXBL3WrM2JFYm==Tcf5Ppn9UajDbzyM(u"࠵࠺࠽፼"): hqyFDZdGw6PBzE75nvsI()
	elif lXBL3WrM2JFYm==LHX65I9nkx0PstgcVY24uSi(u"࠶࠻࠸፽"): benVLch05zRtPUX4FyISxKJN()
	elif lXBL3WrM2JFYm==mgLADoQ1pbtY(u"࠷࠵࠺፾"): Vh0o3CxNYQmJ4ySRt(gyd2rf0UR5)
	elif lXBL3WrM2JFYm==SODvU3Ibq5VzC(u"࠱࠸࠲፿"): n9fQ4DPe16bpcL8()
	elif lXBL3WrM2JFYm==JJA7fypmZFVlazvNI(u"࠲࠹࠴ᎀ"): y5yE9CW1SUjZaMcxXQwTsHJPA()
	elif lXBL3WrM2JFYm==A0aqj9uclgOtByJ6F4bz(u"࠳࠺࠶ᎁ"): HB2RpU3Ehf1m4r([NN9niuC7RoqmhkL2],gyd2rf0UR5,gyd2rf0UR5,mic3MEN709xOkrjD5ZvbGIlX6)
	elif lXBL3WrM2JFYm==ELfMeDTIFhJt685K(u"࠴࠻࠸ᎂ"): ssb9ApI7G2wYURJ8mfhO(mgLADoQ1pbtY(u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡤࡨࡦࡶࡴࡪࡸࡨࠫၺ"),gyd2rf0UR5)
	elif lXBL3WrM2JFYm==maUl7SPesynF1j(u"࠵࠼࠺ᎃ"): ssb9ApI7G2wYURJ8mfhO(nz8x32hX0qcjUPFZk5RdJsiwED(u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡶࡹࡳࡰࠨၻ"),gyd2rf0UR5)
	elif lXBL3WrM2JFYm==KKi79PFqsYB0dWSRgaJ3DyE(u"࠶࠽࠵ᎄ"): QnMrpc0fK1CG8j2BkXVdO()
	elif lXBL3WrM2JFYm==A0aqj9uclgOtByJ6F4bz(u"࠷࠷࠷ᎅ"): mqpCH3ZGgMQt8rIXJD()
	elif lXBL3WrM2JFYm==k4IUieraScH9DV1N7pJgQosYAx5l(u"࠱࠸࠹ᎆ"): S9XInyVlie6HFWRLN8adZT(nz8x32hX0qcjUPFZk5RdJsiwED(u"࠭ࡳࡤࡴ࡬ࡴࡹ࠴࡭ࡰࡦࡸࡰࡪ࠴ࡲࡦࡵࡲࡰࡻ࡫ࡵࡳ࡮ࠪၼ"))
	elif lXBL3WrM2JFYm==pCTzbw4GyVJHjkcIMQ(u"࠲࠹࠼ᎇ"): S9XInyVlie6HFWRLN8adZT(LHX65I9nkx0PstgcVY24uSi(u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡹࡰࡷࡷࡹࡧ࡫ࠧၽ"))
	elif lXBL3WrM2JFYm==A0aqj9uclgOtByJ6F4bz(u"࠳࠼࠴ᎈ"): uELMyWtoGOCRz9A0b6Sam()
	elif lXBL3WrM2JFYm==JJA7fypmZFVlazvNI(u"࠴࠽࠶ᎉ"): j8smWnw9bv()
	elif lXBL3WrM2JFYm==OBsrtQo2pPlgURCxJYbj9iXMD(u"࠵࠾࠸ᎊ"): P8GlRHJDe0W()
	elif lXBL3WrM2JFYm==EF2tvxZHz5n4UruPhaViXKycI6SQR(u"࠶࠿࠳ᎋ"): w0BCQ1he5Hk6SrKuYTM7VxGRj()
	elif lXBL3WrM2JFYm==X2crmy67eZpkGTRd(u"࠷࠹࠵ᎌ"): B2g1P7vj59()
	elif lXBL3WrM2JFYm==CDwSWB4v39N7(u"࠱࠺࠷ᎍ"): R6lG25qB3TjZz()
	elif lXBL3WrM2JFYm==U0VwOviFaYPz2QGs45mJhMXf7Zk(u"࠲࠻࠹ᎎ"): hZf3WMaRwONknQPsXD2zyKpEdi9gj()
	elif lXBL3WrM2JFYm==pCTzbw4GyVJHjkcIMQ(u"࠳࠼࠻ᎏ"): GEfvbTKsB4N1OXZW()
	elif lXBL3WrM2JFYm==CDwSWB4v39N7(u"࠴࠽࠽᎐"): XQwhItHv1dPuE6foNsC2Rn()
	elif lXBL3WrM2JFYm==k4IUieraScH9DV1N7pJgQosYAx5l(u"࠵࠾࠿᎑"): TDLEguNK641i()
	elif lXBL3WrM2JFYm==Tcf5Ppn9UajDbzyM(u"࠸࠺࠰᎒"): wzJsfW6eiMXSdRyE(NN9niuC7RoqmhkL2)
	elif lXBL3WrM2JFYm==LHX65I9nkx0PstgcVY24uSi(u"࠹࠴࠲᎓"): jsRavVxfl702myeEdJtp3()
	elif lXBL3WrM2JFYm==EAVanJj1ers2GQud(u"࠳࠵࠴᎔"): yD1ZdvcFfJ8E()
	elif lXBL3WrM2JFYm==pCTzbw4GyVJHjkcIMQ(u"࠴࠶࠶᎕"): czgSs9FHiq()
	elif lXBL3WrM2JFYm==mg3CbXMA2ouZzQDhRqB(u"࠵࠷࠹᎖"): Fa218v0X9Pye()
	elif lXBL3WrM2JFYm==U0VwOviFaYPz2QGs45mJhMXf7Zk(u"࠶࠸࠻᎗"): bh3ABSfYLvlgqIDHwoCxM9Kzn(mic3MEN709xOkrjD5ZvbGIlX6)
	elif lXBL3WrM2JFYm==cWbkR6iUZsnJQj14(u"࠷࠹࠽᎘"): HMA5Z9hdu0KrfND(gyd2rf0UR5)
	elif lXBL3WrM2JFYm==ShnRVsifKtc60zqQ(u"࠸࠺࠸᎙"): Ob9VP5hvXSZJ0L()
	elif lXBL3WrM2JFYm==C3ZK1pu4rfmj8TsWUtBaM(u"࠹࠴࠺᎚"): yukl12eKA0P(YJxaX0MQOHb8oyCBFdnIAe(u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭ၾ"),gyd2rf0UR5,gyd2rf0UR5)
	elif lXBL3WrM2JFYm==X2crmy67eZpkGTRd(u"࠵࠱࠲᎛"): TLluUkGqK6i()
	elif lXBL3WrM2JFYm==jL1E5AKfwBDv6xmeQtUXcJ3d(u"࠶࠲࠴᎜"): R2nhwzDxdWp9KELr()
	elif lXBL3WrM2JFYm==ShnRVsifKtc60zqQ(u"࠷࠳࠶᎝"): UlJuPdVtRg9h25ADxBFIGEW()
	elif lXBL3WrM2JFYm==nz8x32hX0qcjUPFZk5RdJsiwED(u"࠸࠴࠸᎞"): ZN6s47Hw0rQRuXpkn8WF5h(UU8HRTMCuyFJ6Y07XNemn)
	elif lXBL3WrM2JFYm==HDpmv4UXzlf72SK9(u"࠹࠵࠺᎟"): ZN6s47Hw0rQRuXpkn8WF5h(qdCNzTivE0olpmk3jUYRc)
	elif lXBL3WrM2JFYm==jL1E5AKfwBDv6xmeQtUXcJ3d(u"࠺࠶࠵Ꭰ"): J7xThGy6Oi1HLbuqlgRpdeKSV()
	elif lXBL3WrM2JFYm==C3ZK1pu4rfmj8TsWUtBaM(u"࠻࠰࠷Ꭱ"): omJpWSLeDbKG(gyd2rf0UR5)
	elif lXBL3WrM2JFYm==owbMhINBQsmx70guApW(u"࠵࠱࠹Ꭲ"): Zb0PeUT27AFwDxrRQgN94JsW()
	elif lXBL3WrM2JFYm==jL1E5AKfwBDv6xmeQtUXcJ3d(u"࠶࠲࠻Ꭳ"): PQGVODzqpcS()
	elif lXBL3WrM2JFYm==knTyjJ0sGIzuwbxRae(u"࠳࠳࠶࠵Ꭴ"): RakyYgKt1Obpm()
	elif lXBL3WrM2JFYm==ELfMeDTIFhJt685K(u"࠴࠴࠷࠷Ꭵ"): UdWjrFYpVDic0NCZnBhftboLwz()
	elif lXBL3WrM2JFYm==A0aqj9uclgOtByJ6F4bz(u"࠵࠵࠸࠲Ꭶ"): S9XInyVlie6HFWRLN8adZT(C3ZK1pu4rfmj8TsWUtBaM(u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧၿ"))
	elif lXBL3WrM2JFYm==U0VwOviFaYPz2QGs45mJhMXf7Zk(u"࠶࠶࠲࠴Ꭷ"): pP8Nn4ztvEV0bhqJMIgOmrBYFZuR()
	elif lXBL3WrM2JFYm==owbMhINBQsmx70guApW(u"࠷࠰࠳࠶Ꭸ"): IO1aJxDijWG4ZzRruph2lCv8qA(gyd2rf0UR5)
	elif lXBL3WrM2JFYm==cWbkR6iUZsnJQj14(u"࠱࠱࠴࠸Ꭹ"): Eb8j7AGIJnHaFOw()
	elif lXBL3WrM2JFYm==U0VwOviFaYPz2QGs45mJhMXf7Zk(u"࠲࠲࠵࠺Ꭺ"): BERwqDILtsVuy()
	return
def IO1aJxDijWG4ZzRruph2lCv8qA(showDialogs=mic3MEN709xOkrjD5ZvbGIlX6):
	h9hpdBArqewHvDutWbIOiLy30l2FQ4 = FpGenVlw4Tzxi2WY3JuXcb.executeJSONRPC(maUl7SPesynF1j(u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡖࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡌ࡫ࡴࡔࡧࡷࡸ࡮ࡴࡧࡗࡣ࡯ࡹࡪࠨࠬࠣ࡫ࡧࠦ࠿࠷ࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡸ࡫ࡴࡵ࡫ࡱ࡫ࠧࡀࠢ࡭ࡱࡦࡥࡱ࡫࠮࡬ࡧࡼࡦࡴࡧࡲࡥ࡮ࡤࡽࡴࡻࡴࡴࠤࢀࢁࠬႀ"))
	h9hpdBArqewHvDutWbIOiLy30l2FQ4 = IsGwR1YyfQqa4picCZ6m.loads(h9hpdBArqewHvDutWbIOiLy30l2FQ4)[nz8x32hX0qcjUPFZk5RdJsiwED(u"ࠫࡷ࡫ࡳࡶ࡮ࡷࠫႁ")][ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"ࠬࡼࡡ࡭ࡷࡨࠫႂ")]
	choice,owHZWzMYd8nSVIAx5gBCeTOJv = FFHRwuxQmbh8BaTqyX3,h9hpdBArqewHvDutWbIOiLy30l2FQ4[:]
	if showDialogs:
		asGelEiqvjO = n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"࠭ไ้ฯฬࠤฬ๊ๅโษอ๎าࠦวๅ฻ิฬ๏ฯࠠๆใ฼่ฮ่ࠦห฻่่ࠬႃ") if X2crmy67eZpkGTRd(u"ࠧࡂࡴࡤࡦ࡮ࡩࠠࡒ࡙ࡈࡖ࡙࡟ࠧႄ") in h9hpdBArqewHvDutWbIOiLy30l2FQ4 else OzU6t0qcH7MQabeBYK8vgoG(u"ࠨๆ๋ัฮࠦวๅ็ไหฯ๐อࠡษ็฽ึฮ๊ส่ࠢฮํ่แสࠩႅ")
		choice = uumd4lZkWVE81cI7p0eXgtTQjxhHJ(PPAUFrY8cduRT(u"ࠩࡦࡩࡳࡺࡥࡳࠩႆ"),ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"ࠪาึ๎ฬࠨႇ"),Tcf5Ppn9UajDbzyM(u"ࠫส๐โศใࠪႈ"),jL1E5AKfwBDv6xmeQtUXcJ3d(u"ࠬะิ฻์็ࠫႉ"),OO2BXYhI8UPNq6L,ao3Q5jP8H0sMxK2iUYwZGE+asGelEiqvjO+cjqzOQ5GXD4kR+ti3SbXNV0aJ7n5Grc4OQY8Ll1s9+ti3SbXNV0aJ7n5Grc4OQY8Ll1s9+maUl7SPesynF1j(u"࠭็ั้ࠣห้๎ุ๋ใฬࠤฯูๅฮࠢหหุะฮะษ่ࠤ้๎อสࠢส่๊็วห์ะࠤฬู๊าสํอࠥอไๆ๊ฯ์ิฯࠠโ์ࠣ็ํี๊ࠡ࠰࠱ࠤํํะศ่ࠢ฽๋อ็ࠡษ้ฮࠥะำหูํ฽ࠥษๆࠡฬ฼้้ࠦศฮอࠣๅ๏ࠦๅ้ษๅ฽ࠥอไษำ้ห๊าࠠษษึฮำีวๆࠢส่้เษࠡษ็฽ึฮ๊สࠢ࠱࠲ࠥษ่ࠡฬึฮ฼๐ูࠡล้ࠤฯ้สษࠢิืฬ๊ษࠡๆ็้อืๅอࠢหหฺ้๊สࠢส่฾ืศ๋หࠣ࠲࠳ࠦ็ๅࠢอี๏ีࠠศๆล๊ࠥะิ฻์็ࠤ้๎อสࠢส่๊็วห์ะࠤฬู๊าสํอࠥษๅࠡวํๆฬ็็ศࠢยࠥࠦ࠭ႊ"))
	if choice==FFHRwuxQmbh8BaTqyX3 and mgLADoQ1pbtY(u"ࠧࡂࡴࡤࡦ࡮ࡩࠠࡒ࡙ࡈࡖ࡙࡟ࠧႋ") not in h9hpdBArqewHvDutWbIOiLy30l2FQ4: owHZWzMYd8nSVIAx5gBCeTOJv = [YJxaX0MQOHb8oyCBFdnIAe(u"ࠨࡃࡵࡥࡧ࡯ࡣࠡࡓ࡚ࡉࡗ࡚࡙ࠨႌ")]+h9hpdBArqewHvDutWbIOiLy30l2FQ4
	elif choice==CH7RKuDVzN9f06q8MtXPhlvIxakEWg and pCTzbw4GyVJHjkcIMQ(u"ࠩࡄࡶࡦࡨࡩࡤࠢࡔ࡛ࡊࡘࡔ࡚ႍࠩ") in h9hpdBArqewHvDutWbIOiLy30l2FQ4:
		owHZWzMYd8nSVIAx5gBCeTOJv = h9hpdBArqewHvDutWbIOiLy30l2FQ4[:]
		owHZWzMYd8nSVIAx5gBCeTOJv.remove(LHX65I9nkx0PstgcVY24uSi(u"ࠪࡅࡷࡧࡢࡪࡥࠣࡕ࡜ࡋࡒࡕ࡛ࠪႎ"))
	if owHZWzMYd8nSVIAx5gBCeTOJv!=h9hpdBArqewHvDutWbIOiLy30l2FQ4:
		owHZWzMYd8nSVIAx5gBCeTOJv = str(owHZWzMYd8nSVIAx5gBCeTOJv).replace(A0aqj9uclgOtByJ6F4bz(u"ࠦࠬࠨႏ"),mgLADoQ1pbtY(u"ࠬࠨࠧ႐"))
		zLZUkrP7ac5 = FpGenVlw4Tzxi2WY3JuXcb.executeJSONRPC(dBi72erQEtKDOwjNFaoAgSP(u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾࡙ࠧࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡔࡧࡷࡗࡪࡺࡴࡪࡰࡪ࡚ࡦࡲࡵࡦࠤ࠯ࠦ࡮ࡪࠢ࠻࠳࠯ࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡴࡧࡷࡸ࡮ࡴࡧࠣ࠼ࠥࡰࡴࡩࡡ࡭ࡧ࠱࡯ࡪࡿࡢࡰࡣࡵࡨࡱࡧࡹࡰࡷࡷࡷࠧ࠲ࠢࡷࡣ࡯ࡹࡪࠨ࠺ࠨ႑")+owHZWzMYd8nSVIAx5gBCeTOJv+k4IUieraScH9DV1N7pJgQosYAx5l(u"ࠧࡾࡿࠪ႒"))
		if showDialogs:
			if ELfMeDTIFhJt685K(u"ࠨࡶࡵࡹࡪ࠭႓") in str(zLZUkrP7ac5): u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,LHX65I9nkx0PstgcVY24uSi(u"ࠩอ้ฯࠦวๅ฻่่๏ฯࠠษ่ฯหา࠭႔"))
			else: u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,mgLADoQ1pbtY(u"่้ࠪษำโࠢส่฾๋ไ๋หࠣๅู๊สࠨ႕"))
	return
def pP8Nn4ztvEV0bhqJMIgOmrBYFZuR():
	iY2M7ps3CSfeQvX6gjqI = H8jfvMtXa7Neiu.getSetting(EF2tvxZHz5n4UruPhaViXKycI6SQR(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡣ࡫ࡷࡶࡦࡺࡥࠨ႖"))
	message = OBsrtQo2pPlgURCxJYbj9iXMD(u"ࠬอไาไ่ࠤฬ๊ๅฮัาࠤาอไ๋ษ๋ࠣํࠦ࠺ࠡࠢࠣࠫ႗")+str(iY2M7ps3CSfeQvX6gjqI)+U0VwOviFaYPz2QGs45mJhMXf7Zk(u"࠭ࠠ࡬ࡤࡳࡷࠬ႘") if iY2M7ps3CSfeQvX6gjqI else A0aqj9uclgOtByJ6F4bz(u"ࠧศๆฯ์ิฯࠠศๆฦ์ฯ๎ๅศฬํ็๏ฯࠠๆฬ๋ๆๆฯࠠฮษ็๎ฬ࠭႙")
	message = ao3Q5jP8H0sMxK2iUYwZGE+message+C3ZK1pu4rfmj8TsWUtBaM(u"ࠨ࡞ࡱ๋้ࠦสา์าࠤฬ๊ย็ࠢอุ฿๐ไࠡล๋ࠤฯเ๊๋ำࠣี็๋ࠠศๆฯ์ิฯࠠศๆฦ์ฯ๎ๅศฬํ็๏ฯࠧႚ")+cjqzOQ5GXD4kR
	Tk70cbAyLw = uumd4lZkWVE81cI7p0eXgtTQjxhHJ(mgLADoQ1pbtY(u"ࠩࡦࡩࡳࡺࡥࡳࠩႛ"),cWbkR6iUZsnJQj14(u"ࠪาึ๎ฬࠨႜ"),cWbkR6iUZsnJQj14(u"ࠫส๐โศใࠪႝ"),cWbkR6iUZsnJQj14(u"ࠬะิ฻์็ࠫ႞"),OO2BXYhI8UPNq6L,message+cWbkR6iUZsnJQj14(u"࠭࡜࡯࡞ࡱห้า่ะหࠣห้ษ่ห๊่หฯ๐ใ๋ห๋ࠣ๏ูࠦๆๆํอࠥ๐โ้็ࠣฬ์อࠠศๆหี๋อๅอࠢหหำะ๊ศำࠣว฾๊้ࠡฮ๋ำฮࠦๅห๊ไีฮࠦไาไ่ࠤฬ๊ฬ้ัฬࠤฬ๊ะ๋ࠢส๊ฯࠦสฮัา๋ࠥ็๊้ࠡำ๋ࠥอไีษือࠥ࠴࠮๊๊ࠡิฬࠦๅฺ่ส๋ࠥ฿ๆะ็สࠤฯ่่ๆࠢส๊ฯࠦศหึ฽๎้ࠦแ๋ัํ์ࠥ็ว็ࠢส่อืๆศ็ฯࠤ้์๋ࠠีฦู่่ࠦ็ࠢส่ั๎ฯสࠢส่ฯ๐ࠠหำํำ์อࠠๅล้ࠤฬ๊ศา่ส้ัࠦำ้ใࠣ๎ำะวาࠢส่ั๎ฯสࠢฦ์ฯ๎ๅศฬํ็๏อࠠ࠯࠰ࠣ฽้๋วࠡษ้๋ࠥ๐ฬษࠢสาฯ๐วาࠢิๆ๊ࠦฬ้ัฬࠤฺเ๊าࠢศิฬࠦใศ่อࠤฬ๊ล็ฬิ๊ฯูࠦ็ัๆࠤอ฽๊วหࠣวํࠦโๅ์็อࠬ႟"))
	if Tk70cbAyLw in [-nz8x32hX0qcjUPFZk5RdJsiwED(u"࠳Ꭻ"),maUl7SPesynF1j(u"࠳Ꭼ")]: return
	if Tk70cbAyLw==mgLADoQ1pbtY(u"࠵Ꭽ"):
		iY2M7ps3CSfeQvX6gjqI = HQmDERMFjx
		u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,k4IUieraScH9DV1N7pJgQosYAx5l(u"ࠧ็ฮะฮࠥ฿ๅๅ์ฬࠤส๐โศใࠣห้า่ะหࠣห้ษ่ห๊่หฯ๐ใ๋หࠪႠ"))
	else:
		items = [OzU6t0qcH7MQabeBYK8vgoG(u"ࠨ࠴࠸࠴ࠥࡱࡢࡱࡵࠪႡ"),mg3CbXMA2ouZzQDhRqB(u"ࠩ࠸࠴࠵ࠦ࡫ࡣࡲࡶࠫႢ"),JJA7fypmZFVlazvNI(u"ࠪ࠻࠺࠶ࠠ࡬ࡤࡳࡷࠬႣ"),jL1E5AKfwBDv6xmeQtUXcJ3d(u"ࠫ࠶࠶࠰࠱ࠢ࡮ࡦࡵࡹࠧႤ"),OBsrtQo2pPlgURCxJYbj9iXMD(u"ࠬ࠷࠲࠶࠲ࠣ࡯ࡧࡶࡳࠨႥ"),JJA7fypmZFVlazvNI(u"࠭࠱࠶࠲࠳ࠤࡰࡨࡰࡴࠩႦ"),CDwSWB4v39N7(u"ࠧ࠲࠹࠸࠴ࠥࡱࡢࡱࡵࠪႧ"),HDpmv4UXzlf72SK9(u"ࠨ࠴࠳࠴࠵ࠦ࡫ࡣࡲࡶࠫႨ"),ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"ࠩ࠵࠹࠵࠶ࠠ࡬ࡤࡳࡷࠬႩ"),Tcf5Ppn9UajDbzyM(u"ࠪ࠷࠵࠶࠰ࠡ࡭ࡥࡴࡸ࠭Ⴊ"),YJxaX0MQOHb8oyCBFdnIAe(u"ࠫ࠸࠻࠰࠱ࠢ࡮ࡦࡵࡹࠧႫ"),U0VwOviFaYPz2QGs45mJhMXf7Zk(u"ࠬ࠺࠰࠱࠲ࠣ࡯ࡧࡶࡳࠨႬ"),A0aqj9uclgOtByJ6F4bz(u"࠭࠴࠶࠲࠳ࠤࡰࡨࡰࡴࠩႭ"),JJA7fypmZFVlazvNI(u"ࠧ࠶࠲࠳࠴ࠥࡱࡢࡱࡵࠪႮ"),pCTzbw4GyVJHjkcIMQ(u"ࠨ࠸࠳࠴࠵ࠦ࡫ࡣࡲࡶࠫႯ"),cWbkR6iUZsnJQj14(u"ࠩ࠺࠴࠵࠶ࠠ࡬ࡤࡳࡷࠬႰ"),ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"ࠪ࠼࠵࠶࠰ࠡ࡭ࡥࡴࡸ࠭Ⴑ"),ShnRVsifKtc60zqQ(u"ࠫ࠾࠶࠰࠱ࠢ࡮ࡦࡵࡹࠧႲ"),KhUG1NV9bln5zXjptqFW6dgo(u"ࠬ࠷࠰࠱࠲࠳ࠤࡰࡨࡰࡴࠩႳ"),KKi79PFqsYB0dWSRgaJ3DyE(u"࠭࠱࠲࠲࠳࠴ࠥࡱࡢࡱࡵࠪႴ"),nz8x32hX0qcjUPFZk5RdJsiwED(u"ࠧ࠲࠴࠳࠴࠵ࠦ࡫ࡣࡲࡶࠫႵ"),maUl7SPesynF1j(u"ࠨ࠻࠼࠽࠾࠿ࠠ࡬ࡤࡳࡷࠬႶ")]
		lwT9cdaH5AxMU8IpZif20jPX = GGiSlWbqKDr5Ovkh2L7sHNTxz(A0aqj9uclgOtByJ6F4bz(u"ࠩสาฯืࠠศๆฯ์ิฯࠠศๆฦ์ฯ๎ๅศฬํ็๏ฯࠠศๆ่๊ฬูศสࠩႷ"),items)
		if lwT9cdaH5AxMU8IpZif20jPX==-OBsrtQo2pPlgURCxJYbj9iXMD(u"࠶Ꭾ"): return
		iY2M7ps3CSfeQvX6gjqI = str(items[lwT9cdaH5AxMU8IpZif20jPX][:-mg3CbXMA2ouZzQDhRqB(u"࠻Ꭿ")])
		u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,pCTzbw4GyVJHjkcIMQ(u"๊ࠪัำสࠡ฻่่๏ฯࠠหึ฽๎้่ࠦหฯา๎ิࠦัใ็ࠣห้า่ะหࠣห้ษ่ห๊่หฯ๐ใ๋ห࡟ࡲࡡࡴࠧႸ")+ao3Q5jP8H0sMxK2iUYwZGE+iY2M7ps3CSfeQvX6gjqI+OzU6t0qcH7MQabeBYK8vgoG(u"ࠫࠥࡱࡢࡱࡵࠪႹ")+cjqzOQ5GXD4kR)
	H8jfvMtXa7Neiu.setSetting(nz8x32hX0qcjUPFZk5RdJsiwED(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡤ࡬ࡸࡷࡧࡴࡦࠩႺ"),iY2M7ps3CSfeQvX6gjqI)
	return
def UdWjrFYpVDic0NCZnBhftboLwz(ccrAzjCSphT3=mic3MEN709xOkrjD5ZvbGIlX6):
	ttDZ69PJX1g = iXSFw0bjfWHo7h8atkReBJVC()
	asGelEiqvjO = EF2tvxZHz5n4UruPhaViXKycI6SQR(u"࠭วๅฬื฾๏๊ࠠศๆ็หา่๋ࠠ฻่่ࠬႻ") if ttDZ69PJX1g else A0aqj9uclgOtByJ6F4bz(u"ࠧศๆอุ฿๐ไࠡษ็่ฬำโࠡ็อ์็็ࠧႼ")
	Tk70cbAyLw = uumd4lZkWVE81cI7p0eXgtTQjxhHJ(HDpmv4UXzlf72SK9(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨႽ"),PPAUFrY8cduRT(u"ࠩัีําࠧႾ"),YJxaX0MQOHb8oyCBFdnIAe(u"ࠪษ๏่วโࠩႿ"),KhUG1NV9bln5zXjptqFW6dgo(u"ࠫฯฺฺ๋ๆࠪჀ"),OO2BXYhI8UPNq6L,ao3Q5jP8H0sMxK2iUYwZGE+asGelEiqvjO+cjqzOQ5GXD4kR+ti3SbXNV0aJ7n5Grc4OQY8Ll1s9+nz8x32hX0qcjUPFZk5RdJsiwED(u"ࠬํะ่ࠢส่ํ฾๊โหࠣฮั฿ไࠡๅ๋ำ๏ࠦร้ฬ๋้ฬะ๊ไ์สࠤ๏่่ๆࠢหฮูเ๊ๅࠢส่ๆ๐ฯ๋๊ࠣห้๊วฮไࠣ࠲࠳ࠦลๆษࠣฬ฾ีࠠศ่อ๋ฬวࠠศๆไ๎ิ๐่ࠡษ็ัฬ๊๊ࠡสฦ็๊๊็ࠡ࠰࠱ࠤศ๎ࠠษ฻าࠤฬ๊ๆใำࠣ฽้๏ࠠำำࠣࠦฯาว้ิࠣษ้๏ࠠศๆ็หา่ࠢࠡ࠰࠱ࠤํษ๊ืษ้๊้ࠣๆࠡว็฾ฬวࠠศๆอุ฿๐ไࠡษ็่ฬำโࠡสส่๋่ัࠡ฻็ํุࠥัࠡࠤศ๎็อแࠡษ็ๅ๏ี๊้ࠤࠣ࠲࠳่ࠦฤ์ูห๋ࠥๅไ่ࠣห้อำหใสำฮࠦๅ็ࠢอ฾๏๐ัࠡฬิฮ๏ฮࠠๆฯอ์๏อสࠡษ็ๆํอฦๆࠢ࠱࠲ࠥ๎ฮศืฬࠤฯืส๋สࠣั้่วหࠢสู่๊ไิๆสฮࠥ࠴࠮้ࠡ็ࠤฯื๊ะࠢส่ว์ࠠหึ฽๎้ࠦ็ั้ࠣห้๎ุ๋ใฬࠤศ๋ࠠฦ์ๅหๆํวࠡมࠤࠥࠬჁ"))
	if Tk70cbAyLw==CH7RKuDVzN9f06q8MtXPhlvIxakEWg: LdGiH7QZrquWvUDns1OlbI2E6 = FpGenVlw4Tzxi2WY3JuXcb.executeJSONRPC(ShnRVsifKtc60zqQ(u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾࡙ࠧࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡔࡧࡷࡗࡪࡺࡴࡪࡰࡪ࡚ࡦࡲࡵࡦࠤ࠯ࠦ࡮ࡪࠢ࠻࠳࠯ࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡴࡧࡷࡸ࡮ࡴࡧࠣ࠼ࠥࡺ࡮ࡪࡥࡰࡲ࡯ࡥࡾ࡫ࡲ࠯ࡣࡸࡸࡴࡶ࡬ࡢࡻࡱࡩࡽࡺࡩࡵࡧࡰࠦ࠱ࠨࡶࡢ࡮ࡸࡩࠧࡀ࡛࡞ࡿࢀࠫჂ"))
	elif Tk70cbAyLw==FFHRwuxQmbh8BaTqyX3: LdGiH7QZrquWvUDns1OlbI2E6 = FpGenVlw4Tzxi2WY3JuXcb.executeJSONRPC(CDwSWB4v39N7(u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡓࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡕࡨࡸࡘ࡫ࡴࡵ࡫ࡱ࡫࡛ࡧ࡬ࡶࡧࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡵࡨࡸࡹ࡯࡮ࡨࠤ࠽ࠦࡻ࡯ࡤࡦࡱࡳࡰࡦࡿࡥࡳ࠰ࡤࡹࡹࡵࡰ࡭ࡣࡼࡲࡪࡾࡴࡪࡶࡨࡱࠧ࠲ࠢࡷࡣ࡯ࡹࡪࠨ࠺࡜࠳ࡠࢁࢂ࠭Ⴣ"))
	if Tk70cbAyLw in [CH7RKuDVzN9f06q8MtXPhlvIxakEWg,FFHRwuxQmbh8BaTqyX3]:
		if A0aqj9uclgOtByJ6F4bz(u"ࠨࡶࡵࡹࡪ࠭Ⴤ") in str(LdGiH7QZrquWvUDns1OlbI2E6): u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,jL1E5AKfwBDv6xmeQtUXcJ3d(u"ࠩอ้ฯࠦวๅ฻่่๏ฯࠠษ่ฯหา࠭Ⴥ"))
		else: u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,owbMhINBQsmx70guApW(u"่้ࠪษำโࠢส่฾๋ไ๋หࠣๅู๊สࠨ჆"))
	return
def RakyYgKt1Obpm():
	url = Jzthpc2nj5.SITESURLS[jL1E5AKfwBDv6xmeQtUXcJ3d(u"ࠫࡗࡋࡌࡆࡃࡖࡉࡘ࠭Ⴧ")][nz8x32hX0qcjUPFZk5RdJsiwED(u"࠰Ꮀ")]
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(rwjfOIqQU3ANa0JlWXvCDbFk,EF2tvxZHz5n4UruPhaViXKycI6SQR(u"ࠬࡍࡅࡕࠩ჈"),url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,ELfMeDTIFhJt685K(u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓ࠮ࡋࡑࡗ࡙ࡇࡌࡍࡡࡒࡐࡉࡥࡒࡆࡎࡈࡅࡘࡋ࠭࠲ࡵࡷࠫ჉"))
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	sqfoI1aVJtUi8RnEedA = DyVGS3dX0ZxR.findall(OzU6t0qcH7MQabeBYK8vgoG(u"ࠧࡩࡴࡨࡪࡂࠨࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࠮ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷ࠳࠰࠿ࠪ࠰ࡽ࡭ࡵࠨࠧ჊"),CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	sqfoI1aVJtUi8RnEedA = sorted(sqfoI1aVJtUi8RnEedA,reverse=gyd2rf0UR5)
	lwT9cdaH5AxMU8IpZif20jPX = GGiSlWbqKDr5Ovkh2L7sHNTxz(PPAUFrY8cduRT(u"ࠨษัฮึࠦวๅวุำฬืࠠศๆำ๎ࠥะั๋ัࠣฮะฮ๊ห้ࠪ჋"),sqfoI1aVJtUi8RnEedA)
	if lwT9cdaH5AxMU8IpZif20jPX>=nz8x32hX0qcjUPFZk5RdJsiwED(u"࠱Ꮁ"):
		eeH6y8iEGgfwJ0IUdB72K9cmNr4SMq = url.rsplit(xufJqQcGnhboiVy2wd,U0VwOviFaYPz2QGs45mJhMXf7Zk(u"࠳Ꮂ"))[EF2tvxZHz5n4UruPhaViXKycI6SQR(u"࠳Ꮃ")]+CDwSWB4v39N7(u"ࠩ࠲ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࠪ჌")+sqfoI1aVJtUi8RnEedA[lwT9cdaH5AxMU8IpZif20jPX]+C3ZK1pu4rfmj8TsWUtBaM(u"ࠪ࠲ࡿ࡯ࡰࠨჍ")
		succeeded = RLcSMfNngFDO1maptW6sJKd(KhUG1NV9bln5zXjptqFW6dgo(u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩ჎"),eeH6y8iEGgfwJ0IUdB72K9cmNr4SMq,gyd2rf0UR5)
		if succeeded:
			H8jfvMtXa7Neiu.setSetting(KhUG1NV9bln5zXjptqFW6dgo(u"ࠬࡧࡶ࠯ࡸࡨࡶࡸ࡯࡯࡯ࠩ჏"),HQmDERMFjx)
			N7gs9UBCeDR3 = HUJZy0SrTbBYv1(HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,k4IUieraScH9DV1N7pJgQosYAx5l(u"࠭สๆࠢอฯอ๐สࠡวุำฬืࠠใัํ้๊ࠥไษำ้ห๊าࠠ࠯࠰่่ࠣ์ࠠษำ้ห๊าࠠไ๊า๎ࠥ๐โ้็ࠣวํะ่ๆษอ๎่๐วࠡสอัิ๐หࠡฮ่๎฾ࠦวๅสิห๊าࠠษษึฮำีวๆࠢลาึࠦลึัสี๋ࠥส้ใิࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡษ็ฦ๋ࠦล๋ไสๅࠥอไหฯา๎ะࠦวๅล๋ฮํ๋วห์ๆ๎๊ࠥ็ัษࠣห้ฮั็ษ่ะࠥลࠡࠢࠩა"))
			if N7gs9UBCeDR3: yukl12eKA0P(X2crmy67eZpkGTRd(u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬბ"),gyd2rf0UR5,gyd2rf0UR5)
	return
def Zb0PeUT27AFwDxrRQgN94JsW():
	N7gs9UBCeDR3 = HUJZy0SrTbBYv1(HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,dBi72erQEtKDOwjNFaoAgSP(u"ࠨ้็ࠤฯื๊ะࠢไ฽้อࠠๆีะࠤส฿ฯศัสฮࠥอไษำ้ห๊าࠠศๆัหฺฯࠠษ๊ๅฮࠥาไษࠢส่ฯำฯ๋อสฮࠥ࠴࠮้ࠡำหࠥอไๆีะࠤุ๎แࠡ์ึฬอࠦสฮัํฯࠥ็่า์่ࠣัฺ๋๊๋ࠢ฼ฬฬแࠡษ็ฬึ์วๆฮࠣห้ะ๊ࠡฬ฼ฮ๊ีฺࠠๆ์ࠤ๊ื่า๋ࠢๆฯࠦๅฺ์้ࠫგ"))
	if N7gs9UBCeDR3:
		H8jfvMtXa7Neiu.setSetting(jL1E5AKfwBDv6xmeQtUXcJ3d(u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯ࡵ࡫ࡳࡷࡺࠧდ"),HQmDERMFjx)
		H8jfvMtXa7Neiu.setSetting(KhUG1NV9bln5zXjptqFW6dgo(u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰ࡵࡩ࡬ࡻ࡬ࡢࡴࠪე"),HQmDERMFjx)
		H8jfvMtXa7Neiu.setSetting(LHX65I9nkx0PstgcVY24uSi(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡰࡴࡴࡧࠨვ"),HQmDERMFjx)
		H8jfvMtXa7Neiu.setSetting(knTyjJ0sGIzuwbxRae(u"ࠬࡧࡶ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮࠲ࡲ࡫ࡳࡴࡣࡪࡩࡸ࠭ზ"),HQmDERMFjx)
		H8jfvMtXa7Neiu.setSetting(jL1E5AKfwBDv6xmeQtUXcJ3d(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡷࡵࡦࡵࡷ࡭ࡴࡴࡳࠨთ"),HQmDERMFjx)
		u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"ࠧห็ุ้ࠣำࠠฦ฻าหิอสࠡษ็ฬึ์วๆฮࠣห้ิวึหࠣฬํ่สࠡฮ็ฬࠥอไหฯา๎ะอสࠡ࠰࠱ࠤํู่โࠢํๆํ๋ࠠศๆหี๋อๅอࠢส่ว์ࠠษฬะำ๏ั่ࠠา๊ࠤฬ๊ลฺัสำฬะࠠ࠯࠰ࠣ์ศ๐ึศࠢอัิ๐ห๊ࠡ฻หห็ࠠศๆหี๋อๅอࠢส่ฯ๐ࠠห฻อ้ิูࠦๅ๋ࠣห้๎โหࠩი"))
		dXUwsnOGKBF57cNaok(mic3MEN709xOkrjD5ZvbGIlX6)
	return
def J7xThGy6Oi1HLbuqlgRpdeKSV():
	X8X1TJW3AmVdy0ZrFvqjDba7Bg2(rDy4FoKpEOsXfT8WZjli,HDpmv4UXzlf72SK9(u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࡣ࠶࠭კ"),SODvU3Ibq5VzC(u"ࠩࡔ࡙ࡊ࡙ࡔࡊࡑࡑࡗࠬლ"))
	Ys1MPUmFJx = FvaWzEZCjUQrwiDhqopsKO(mic3MEN709xOkrjD5ZvbGIlX6)
	jMgeDJSwGi = ti3SbXNV0aJ7n5Grc4OQY8Ll1s9
	yM3TEaiDbIGKAVoet = s7d549VgeP+KhUG1NV9bln5zXjptqFW6dgo(u"ࠪࠤ࠲࠳࠭࠮࠯ࠣ࠱࠲࠳࠭࠮ࠢ࠰࠱࠲࠳࠭ࠡ࠯࠰࠱࠲࠳ࠠ࠮࠯࠰࠱࠲ࠦࠧმ")+cjqzOQ5GXD4kR
	kfBMPLOvHY3thpRQloUKXSwcrN = ti3SbXNV0aJ7n5Grc4OQY8Ll1s9+ao3Q5jP8H0sMxK2iUYwZGE+KhUG1NV9bln5zXjptqFW6dgo(u"ࠫࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠࠨნ")+cjqzOQ5GXD4kR+ShnRVsifKtc60zqQ(u"ࠬࡢ࡮࡝ࡰࠪო")
	for id,QXcqfBzUWRdgrn7JSsTi1Po83C,heEP6tMJ1GQHW8vA4,CFZz49jp6Ye,fG849OmcsHS3WLC5MuAJeKINUpl6,reason in reversed(Ys1MPUmFJx):
		if id==pCTzbw4GyVJHjkcIMQ(u"࠭࠰ࠨპ"):
			kndocJLZ2Azqmt8vDX7C0BIpPF,fgHDhIdESXZv = CFZz49jp6Ye.split(dBi72erQEtKDOwjNFaoAgSP(u"ࠧ࡝ࡰ࠾࠿ࠬჟ"))
			continue
		if jMgeDJSwGi!=ti3SbXNV0aJ7n5Grc4OQY8Ll1s9: jMgeDJSwGi += kfBMPLOvHY3thpRQloUKXSwcrN
		rGIDET0OmyFiUL8q = ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"ࠨ࡝ࡕࡘࡑࡣࠧრ")+s7d549VgeP+id+JJA7fypmZFVlazvNI(u"ࠩࠣ࠾ࠥ࠭ს")+pCTzbw4GyVJHjkcIMQ(u"ࠪหู้ฤศๆࠣ࠾ࠥ࠭ტ")+cjqzOQ5GXD4kR+heEP6tMJ1GQHW8vA4
		iCDE40qzXlhxrvf = jL1E5AKfwBDv6xmeQtUXcJ3d(u"ࠫࡡࡴ࡛ࡓࡖࡏࡡࠬუ")+s7d549VgeP+OBsrtQo2pPlgURCxJYbj9iXMD(u"ࠬอไอ๊สฬࠥࡀࠠࠨფ")+cjqzOQ5GXD4kR+CFZz49jp6Ye
		Q8QSUrGdpmul = LHX65I9nkx0PstgcVY24uSi(u"࡛࠭ࡓࡖࡏࡡࠬქ")+s7d549VgeP+Tcf5Ppn9UajDbzyM(u"ࠧศๆั฻ศࠦ࠺ࠡࠩღ")+cjqzOQ5GXD4kR+fG849OmcsHS3WLC5MuAJeKINUpl6
		wqI0MRzPSQoeph3nBN9Hcb = YJxaX0MQOHb8oyCBFdnIAe(u"ࠨ࡞ࡱ࡟ࡗ࡚ࡌ࡞ࠩყ")+s7d549VgeP+Tcf5Ppn9UajDbzyM(u"ࠩสุ่ฮศࠡ࠼ࠣࠫშ")+cjqzOQ5GXD4kR+reason
		jMgeDJSwGi += rGIDET0OmyFiUL8q+iCDE40qzXlhxrvf+ti3SbXNV0aJ7n5Grc4OQY8Ll1s9+yM3TEaiDbIGKAVoet+ti3SbXNV0aJ7n5Grc4OQY8Ll1s9+Q8QSUrGdpmul+wqI0MRzPSQoeph3nBN9Hcb+ti3SbXNV0aJ7n5Grc4OQY8Ll1s9
	LQf1jSRk4tA32a(Tcf5Ppn9UajDbzyM(u"ࠪࡶ࡮࡭ࡨࡵࠩჩ"),fgHDhIdESXZv,jMgeDJSwGi,KhUG1NV9bln5zXjptqFW6dgo(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺ࡟࡭ࡱࡱ࡫ࠬც"))
	return
def ZN6s47Hw0rQRuXpkn8WF5h(file):
	if file==qdCNzTivE0olpmk3jUYRc: WAadZh6oCLMb = OzU6t0qcH7MQabeBYK8vgoG(u"่่ࠬศศ่ࠤฬ๊ๅโุ็อࠬძ")
	elif file==UU8HRTMCuyFJ6Y07XNemn: WAadZh6oCLMb = C3ZK1pu4rfmj8TsWUtBaM(u"࠭โ้ษษ้ࠥศฮาࠢส่ๆ๐ฯ๋๊๊หฯ࠭წ")
	Tk70cbAyLw = uumd4lZkWVE81cI7p0eXgtTQjxhHJ(EF2tvxZHz5n4UruPhaViXKycI6SQR(u"ࠧࡤࡧࡱࡸࡪࡸࠧჭ"),PPAUFrY8cduRT(u"ࠨ็ึัࠬხ"),U0VwOviFaYPz2QGs45mJhMXf7Zk(u"ࠩศู้ออࠨჯ"),n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"ࠪาึ๎ฬࠨჰ"),OO2BXYhI8UPNq6L,OBsrtQo2pPlgURCxJYbj9iXMD(u"ࠫ์๊ࠠหำํำࠥหีๅษะࠤ๊๊แࠡࠩჱ")+WAadZh6oCLMb+A0aqj9uclgOtByJ6F4bz(u"ࠬࠦรๆࠢอี๏ีࠠๆีะࠤฬ๊ๅๅใࠣรࠬჲ"))
	if Tk70cbAyLw==JJA7fypmZFVlazvNI(u"࠴Ꮄ"):
		if S9Y5kUoRga3EVN.path.exists(file):
			try: S9Y5kUoRga3EVN.remove(file)
			except: pass
		u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,cWbkR6iUZsnJQj14(u"࠭สๆ่ࠢืาࠦๅๅใࠣࠫჳ")+WAadZh6oCLMb)
	elif Tk70cbAyLw==A0aqj9uclgOtByJ6F4bz(u"࠶Ꮅ"):
		data = DIHm5USjh3aATExn0(file)
		u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,ShnRVsifKtc60zqQ(u"ࠧห็ࠣษฺ๊วฮ่่ࠢๆࠦࠧჴ")+WAadZh6oCLMb)
	return
def R2nhwzDxdWp9KELr():
	if Oth25uIHDEC3f9kMKr7sLUoaZwblyi<Tcf5Ppn9UajDbzyM(u"࠷࠸Ꮆ"):
		wwpQTfixYD23X = ShnRVsifKtc60zqQ(u"ࠨๆ็วุ็ࠠฤ่อࠤฯูสฯั่ࠤส฻ฯศำࠣ็ํี๊ࠡไา๎๊ࠦัใ็ࠣࠫჵ")+str(Oth25uIHDEC3f9kMKr7sLUoaZwblyi)+A0aqj9uclgOtByJ6F4bz(u"ࠩࠣ์้ํะศࠢส่็๎วว็ࠣห้๋ี้ำฬࠤ้อࠠห฻่่ࠥ฿ๆะๅࠣ࠲ࠥํะ่ࠢส่๊๐าสࠢอ้่์ใࠡ็้ࠤึส๊สࠢๅ์ฬฬๅࠡษ็ๅ๏ี๊้้สฮࠥ็๊ࠡสิ๊ฬ๋ฬࠡ฻่หิࠦศีๅ็ࠤฺ๎ัࠡสา่ฬࠦๅ็ࠢส่่ะวษหࠣ࠲๊ࠥลึๆสัࠥอไๆึๆ่ฮࠦโๆࠢหฮาี๊ฬࠢหี๋อๅอࠢๆ์ิ๐ࠠฦๆ์ࠤส๐ࠠฦืาหึࠦัใ็๊ࠤศ฿ไ๊่๊ࠢࠥ࠷࠸࠯࠲ࠪჶ")
		u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,wwpQTfixYD23X)
		return
	K3dSZoF4R6i9TwtQsUhCa = FpGenVlw4Tzxi2WY3JuXcb.executeJSONRPC(KhUG1NV9bln5zXjptqFW6dgo(u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡖࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡌ࡫ࡴࡔࡧࡷࡸ࡮ࡴࡧࡗࡣ࡯ࡹࡪࠨࠬࠣ࡫ࡧࠦ࠿࠷ࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡸ࡫ࡴࡵ࡫ࡱ࡫ࠧࡀࠢ࡭ࡱࡲ࡯ࡦࡴࡤࡧࡧࡨࡰ࠳ࡹ࡫ࡪࡰࠥࢁࢂ࠭ჷ"))
	GN8T3gF7SozjaZidm = FBqpsWQkStgN([mgLADoQ1pbtY(u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪჸ")])
	f63nZaUBvzyFbHiVcte2Dk,tvrAfkiZT59ICncxdPR,gQY7chrDtVq9R6f8oPOTlKSXeuI,QcbVIWAHdjvyrLM,D1DUjZVNyv3MgWPKCi,I1rxAfm0y9cqGT,dfvL4IknztBD = GN8T3gF7SozjaZidm[LHX65I9nkx0PstgcVY24uSi(u"ࠬࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇࠫჹ")]
	if f63nZaUBvzyFbHiVcte2Dk or OzU6t0qcH7MQabeBYK8vgoG(u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈࠬჺ") not in str(K3dSZoF4R6i9TwtQsUhCa):
		u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,CDwSWB4v39N7(u"ࠧศๆๅ์ฬฬๅࠡษ็ฺ้๎ัสࠢอ฽๊๊ࠠโไฺࠤ๊฿ࠠอๆาࠤ๊ะั้สุู๋่ࠦๆษาࠤ࠳ࠦ็ั้ࠣห้่่ศศ่ࠤฯ๋ใ็ๅ้๋ࠣࠦัล์ฬࠤ็๎วว็ࠣฬึ์วๆฮࠣ฽๊อฯࠡสื็้ࠦี้ำࠣฬิ๊วࠡ็้ࠤฬ๊ใหษหอࠬ჻"))
		HH2hLvGCD3zfk = UlJuPdVtRg9h25ADxBFIGEW()
		if not HH2hLvGCD3zfk: return
	xXM5ihsw6HfAUBa39CRpk1o4qu(gyd2rf0UR5)
	return
def xXM5ihsw6HfAUBa39CRpk1o4qu(showDialogs=gyd2rf0UR5):
	K3dSZoF4R6i9TwtQsUhCa = FpGenVlw4Tzxi2WY3JuXcb.executeJSONRPC(mg3CbXMA2ouZzQDhRqB(u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡔࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡊࡩࡹ࡙ࡥࡵࡶ࡬ࡲ࡬࡜ࡡ࡭ࡷࡨࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡶࡩࡹࡺࡩ࡯ࡩࠥ࠾ࠧࡲ࡯ࡰ࡭ࡤࡲࡩ࡬ࡥࡦ࡮࠱ࡷࡰ࡯࡮ࠣࡿࢀࠫჼ"))
	if pCTzbw4GyVJHjkcIMQ(u"ࠩࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄࠨჽ") not in str(K3dSZoF4R6i9TwtQsUhCa):
		if showDialogs:
			u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,cWbkR6iUZsnJQj14(u"่้ࠪษำโࠢฯ๋ฬุใࠡๆสࠤ๏ูสฯั่ࠤั๊ฯࠡ็อีํฮ่ๅีࠣ฽๊อฯࠡ࠰ࠣห้่่ศศ่ࠤฬ๊ๅึ๊ิอࠥะูๆๆࠣๅ็฽ࠠๆ฻ࠣะ้ีࠠๆฬิ์อ๎ไิࠢ฼้ฬีࠠ࠯๊ࠢิ์ࠦวๅไ๋หห๋ࠠห็ๆ๊่ࠦๅ็ࠢิศ๏ฯࠠใ๊สส๊ࠦศา่ส้ัูࠦๆษาࠤอฺใๅุࠢ์ึࠦศะๆสࠤ๊์ࠠศๆๆฮฬฮษࠨჾ"))
		return
	kb5RY1AZOJvehCrp4Dygmd = S9Y5kUoRga3EVN.path.join(vZmS3d7AaDN5JsGqPTgxOpVBFw,nz8x32hX0qcjUPFZk5RdJsiwED(u"ࠫࡦࡪࡤࡰࡰࡶࠫჿ"),C3ZK1pu4rfmj8TsWUtBaM(u"ࠬࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇࠫᄀ"),owbMhINBQsmx70guApW(u"࠭࠷࠳࠲ࡳࠫᄁ"),pCTzbw4GyVJHjkcIMQ(u"ࠧࡎࡻ࡙࡭ࡩ࡫࡯ࡏࡣࡹ࠲ࡽࡳ࡬ࠨᄂ"))
	if not S9Y5kUoRga3EVN.path.exists(kb5RY1AZOJvehCrp4Dygmd): return
	Me76Qf4FcwoJE0 = open(kb5RY1AZOJvehCrp4Dygmd,knTyjJ0sGIzuwbxRae(u"ࠨࡴࡥࠫᄃ")).read()
	if HH6mxXjgcrEN1aenMFWQkS: Me76Qf4FcwoJE0 = Me76Qf4FcwoJE0.decode(Zex6D4tJE52r)
	JV7egCc6aXDZHn = DyVGS3dX0ZxR.findall(n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"ࠩ࠿ࡺ࡮࡫ࡷࡴࡀࠫࡠࡩ࠱ࠬ࡝ࡦ࠮࠰ࡡࡪࠫࠪ࠮ࠫ࠲࠯ࡅࠩ࠽࠱ࡹ࡭ࡪࡽࡳ࠿ࠩᄄ"),Me76Qf4FcwoJE0,DyVGS3dX0ZxR.DOTALL)
	mHxtdYlUSKXv0r6Q18eEiP,mZz2HaCJG8YK = JV7egCc6aXDZHn[o4bNzIQGYj8En]
	suoEqxQB0RX6K5 = SODvU3Ibq5VzC(u"ࠪࡀࡻ࡯ࡥࡸࡵࡁࠫᄅ")+mHxtdYlUSKXv0r6Q18eEiP+jL1E5AKfwBDv6xmeQtUXcJ3d(u"ࠫ࠱࠭ᄆ")+mZz2HaCJG8YK+Tcf5Ppn9UajDbzyM(u"ࠬࡂ࠯ࡷ࡫ࡨࡻࡸࡄࠧᄇ")
	if showDialogs:
		BPbqhELaVK0sjFC1Unf358QlzgG = FpGenVlw4Tzxi2WY3JuXcb.getInfoLabel(CDwSWB4v39N7(u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰࡙࡭ࡪࡽ࡭ࡰࡦࡨࠫᄈ"))
		if BPbqhELaVK0sjFC1Unf358QlzgG==A0aqj9uclgOtByJ6F4bz(u"ࠧࡆࡏࡄࡈࠥࡒࡩࡴࡶࠪᄉ"): j1kZ6KnxQyIv = X2crmy67eZpkGTRd(u"ࠨไ๋หห๋ࠠศๆๆฮฬฮษࠨᄊ")
		elif BPbqhELaVK0sjFC1Unf358QlzgG==pCTzbw4GyVJHjkcIMQ(u"ࠩࡈࡑࡆࡊࠠࡈࡣ࡯ࡰࡪࡸࡹࠨᄋ"): j1kZ6KnxQyIv = PPAUFrY8cduRT(u"ࠪๆํอฦๆࠢสฺ่๎ัࠨᄌ")
		else: j1kZ6KnxQyIv = HDpmv4UXzlf72SK9(u"ࠫ็๎วว็ࠣวำื้ࠨᄍ")
		Tk70cbAyLw = uumd4lZkWVE81cI7p0eXgtTQjxhHJ(jL1E5AKfwBDv6xmeQtUXcJ3d(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬᄎ"),Tcf5Ppn9UajDbzyM(u"࠭โ้ษษ้ࠥษฮา๋ࠪᄏ"),C3ZK1pu4rfmj8TsWUtBaM(u"ࠧใ๊สส๊ࠦวๅๅอหอฯࠧᄐ"),YJxaX0MQOHb8oyCBFdnIAe(u"ࠨไ๋หห๋ࠠศๆุ์ึ࠭ᄑ"),jL1E5AKfwBDv6xmeQtUXcJ3d(u"ࠩส๊ฯࠦอศๆํหࠥะำหะา้ࠥ࠭ᄒ")+j1kZ6KnxQyIv,PPAUFrY8cduRT(u"ࠪห๋ะࠠศๆล๊ࠥะำหะา้ࠥอไฦืาหึࠦวๅลั๎ึࠦไอๆาࠤ๊ะั้สุู๋่ࠦๆษาࠤ࠳่่ࠦาสࠤ๊฿ๆศ้ࠣห๋้ࠠหีอ฻๏฿ࠠศีอาิอๅࠡษ็ๆํอฦๆࠢส่๊฻่าหࠣฬิ๊วࠡ็้ࠤ็๎วว็ࠣห้้สศสฬࠤ࠳่ࠦฤ์ูหࠥะำหูํ฽ࠥห๊ใษไ๋ฬࠦแ๋ࠢฦ๎ࠥ๎โหࠢอุฬวࠠ࡝ࡰ࡟ࡲࠥ࠭ᄓ")+s7d549VgeP+cWbkR6iUZsnJQj14(u"ࠫࠥษฮหำࠣห้ศๆ่๋ࠡ฽ࠥอไใ๊สส๊ࠦวๅฬํࠤฯื๊ะࠢฦืฯิฯศ็๊หࠥลࠡࠨᄔ")+cjqzOQ5GXD4kR)
		if Tk70cbAyLw==X2crmy67eZpkGTRd(u"࠱Ꮇ"): PPtLfKOcVEzFn = jL1E5AKfwBDv6xmeQtUXcJ3d(u"ࠬࡋࡍࡂࡆࠣࡐ࡮ࡹࡴࠨᄕ")
		elif Tk70cbAyLw==OzU6t0qcH7MQabeBYK8vgoG(u"࠳Ꮈ"): PPtLfKOcVEzFn = ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"࠭ࡅࡎࡃࡇࠤࡌࡧ࡬࡭ࡧࡵࡽࠬᄖ")
		else: PPtLfKOcVEzFn = HQmDERMFjx
	else:
		BPbqhELaVK0sjFC1Unf358QlzgG = H8jfvMtXa7Neiu.getSetting(n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"ࠧࡢࡸ࠱ࡱࡾࡹ࡫ࡪࡰ࠱ࡺ࡮࡫ࡷ࡮ࡱࡧࡩࠬᄗ"))
		if   BPbqhELaVK0sjFC1Unf358QlzgG==HQmDERMFjx: Tk70cbAyLw = owbMhINBQsmx70guApW(u"࠲Ꮉ")
		elif BPbqhELaVK0sjFC1Unf358QlzgG==JJA7fypmZFVlazvNI(u"ࠨࡇࡐࡅࡉࠦࡌࡪࡵࡷࠫᄘ"): Tk70cbAyLw = OBsrtQo2pPlgURCxJYbj9iXMD(u"࠴Ꮊ")
		elif BPbqhELaVK0sjFC1Unf358QlzgG==YJxaX0MQOHb8oyCBFdnIAe(u"ࠩࡈࡑࡆࡊࠠࡈࡣ࡯ࡰࡪࡸࡹࠨᄙ"): Tk70cbAyLw = mg3CbXMA2ouZzQDhRqB(u"࠶Ꮋ")
		PPtLfKOcVEzFn = BPbqhELaVK0sjFC1Unf358QlzgG
	if   Tk70cbAyLw==A0aqj9uclgOtByJ6F4bz(u"࠵Ꮌ"): YhQHFdPNSG2psRqcMwafWOL3EZ = owbMhINBQsmx70guApW(u"ࠪ࠹࠺࠲࠵࠵࠶࠯࠹࠺࠻ࠧᄚ")
	elif Tk70cbAyLw==C3ZK1pu4rfmj8TsWUtBaM(u"࠷Ꮍ"): YhQHFdPNSG2psRqcMwafWOL3EZ = LHX65I9nkx0PstgcVY24uSi(u"ࠫ࠺࠺࠴࠭࠷࠸࠹࠱࠻࠵ࠨᄛ")
	elif Tk70cbAyLw==dBi72erQEtKDOwjNFaoAgSP(u"࠲Ꮎ"): YhQHFdPNSG2psRqcMwafWOL3EZ = OzU6t0qcH7MQabeBYK8vgoG(u"ࠬ࠻࠵࠶࠮࠸࠹࠱࠻࠴࠵ࠩᄜ")
	else: return
	H8jfvMtXa7Neiu.setSetting(EF2tvxZHz5n4UruPhaViXKycI6SQR(u"࠭ࡡࡷ࠰ࡰࡽࡸࡱࡩ࡯࠰ࡹ࡭ࡪࡽ࡭ࡰࡦࡨࠫᄝ"),PPtLfKOcVEzFn)
	kkztJMYD9j8FKGgZdx = owbMhINBQsmx70guApW(u"ࠧ࠽ࡸ࡬ࡩࡼࡹ࠾ࠨᄞ")+YhQHFdPNSG2psRqcMwafWOL3EZ+k4IUieraScH9DV1N7pJgQosYAx5l(u"ࠨ࠮ࠪᄟ")+mZz2HaCJG8YK+ShnRVsifKtc60zqQ(u"ࠩ࠿࠳ࡻ࡯ࡥࡸࡵࡁࠫᄠ")
	AP4bIWCDJTs = Me76Qf4FcwoJE0.replace(suoEqxQB0RX6K5,kkztJMYD9j8FKGgZdx)
	if HH6mxXjgcrEN1aenMFWQkS: AP4bIWCDJTs = AP4bIWCDJTs.encode(Zex6D4tJE52r)
	open(kb5RY1AZOJvehCrp4Dygmd,SODvU3Ibq5VzC(u"ࠪࡻࡧ࠭ᄡ")).write(AP4bIWCDJTs)
	vv8DyVrLOPAXFIMZ9h(RRWFdpe04EK1Qn,PPAUFrY8cduRT(u"ࠫ࠳ࡢࡴࡔ࡭࡬ࡲࠥࡊࡥࡧࡣࡸࡰࡹࠦࡖࡪࡧࡺࡷ࠿࡛ࠦࠡࠩᄢ")+YhQHFdPNSG2psRqcMwafWOL3EZ+owbMhINBQsmx70guApW(u"ࠬࠦ࡝ࠨᄣ"))
	if showDialogs: FpGenVlw4Tzxi2WY3JuXcb.executebuiltin(EF2tvxZHz5n4UruPhaViXKycI6SQR(u"࠭ࡒࡦ࡮ࡲࡥࡩ࡙࡫ࡪࡰࠫ࠭ࠬᄤ"))
	return
def TLluUkGqK6i():
	N7gs9UBCeDR3 = HUJZy0SrTbBYv1(HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,SODvU3Ibq5VzC(u"ࠧษำ้ห๊าฺࠠ็สำࠥ็ุ๊่่่๊ࠢษࠡ฻้ำ่ࠦ࠮࠯࠰ࠣษ๊อࠠฤๆศูิอัࠡไา๎๊ࠦ࠮࠯࠰ࠣวํࠦว็ฬ้๊ࠣ์ฺ่่๊ࠢࠥอำหะาห๊ࠦวๅสิ๊ฬ๋ฬࠡ࠰࠱࠲ࠥษ่ࠡๆา๎่ࠦๅีๅ็อࠥษฮา๋ࠣฮำ฻ࠠอ้สึ่ࠦร็ฬࠣ์้อࠠหะุࠤอ่๊สࠢั่็ࠦวๅๆ๊ࠤࡡࡴ࡜࡯ࠢะหํ๊ࠠหฯา๎ะࠦวๅสิ๊ฬ๋ฬࠡล๋ࠤฬะีๅࠢหห้๋ศา็ฯࠤู้๋าใฬࠤุฮศࠡษ็ู้้ไสࠢ฼๊ิ้ࠠ࠯࠰࠱ࠤ์๊ࠠหำํำࠥ็อึࠢส่ฯำฯ๋อสฮࠥอไร่ࠣรࠬᄥ"))
	if N7gs9UBCeDR3==JJA7fypmZFVlazvNI(u"࠲Ꮏ"): nnEKsFRwX5ldCQx()
	return
def r7GI8c0Mbx5CYDuRfXmzkNLBn():
	u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,A0aqj9uclgOtByJ6F4bz(u"ࠨ้ำหࠥอไๆ๊ๅ฽ฺ๋ࠥๅไ้๋ࠣࠦวๅ็ุำึ่ࠦ฻์ิࠤ๊฿ั้ใ้ࠣฯ๐๋ࠠำฯ฽๊ࠥไฺ็็ࠫᄦ"))
	return
def Ob9VP5hvXSZJ0L():
	rGIDET0OmyFiUL8q = s7d549VgeP+ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"ࠩอ฽ิอฯࠡึํ฽ฮࠦยๅ่ࠢั๊ีࠠๅี้อࠥ࠸࠰࠳࠳ࠣ࠾ࠥ࠭ᄧ")+cjqzOQ5GXD4kR
	rGIDET0OmyFiUL8q += EF2tvxZHz5n4UruPhaViXKycI6SQR(u"ࠪห้๋่ใ฻ࠣวิ์ว่ࠢไ๎์ࠦลฮืสส๏ฯࠠๅ฻าำࠥอไี์฼อࠥ็๊ࠡษ็฽ฬ๊ๅࠡฬ่ࠤัู๋่ษ้๋ࠣࠦฬๆ์฼ࠤฬ๊ๅึษาีࠥอไๆฬ๋ๅึฯࠠโ์ࠣห้หๆหำ้ฮࠥอไใัํ้ฮ่ࠦศๆฯำ๏ีษࠡษ็ั่๎ๅ๋หࠣ์ฬฺ๊๋ำࠣั่๎ๅ๋หࠣ์๊์ࠠอ็ํ฽ࠥี่ๅࠢส่฾อไๆࠢฮ้ࠥะๅࠡฬ๋ั๏ี็ศ๋ࠢัุอศࠡษ็้฾ีไࠡฯึฬูࠥใศ่ࠣำํ๊ࠠศๆ฼ห้๋ࠠๅี้อࠥ࠸࠰࠳࠳ࠣ์์๐ࠠศๆศัฺอฦ๋หࠣห้ษอะอࠣ์ฬ๊รี็็ࠤฬ๊ส๋ࠢอ้ࠥ฿ๅๅ้สࠤๆ๐ࠠศๆึ๊ํอสࠡษ็฽ูืษࠡษ็้ฬ฼๊สࠩᄨ")
	rGIDET0OmyFiUL8q += ti3SbXNV0aJ7n5Grc4OQY8Ll1s9+s7d549VgeP+cWbkR6iUZsnJQj14(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡺࡩ࡯ࡻ࠱ࡧࡨ࠵ࡳࡩ࡫ࡤࡧࡴࡻ࡮ࡵࠩᄩ")+cjqzOQ5GXD4kR
	iCDE40qzXlhxrvf = s7d549VgeP+PPAUFrY8cduRT(u"ࠬฮั็ษ่ะฺࠥัู๋ࠣห้๋ำๅ็ࠣ࠾ࠥ࠭ᄪ")+cjqzOQ5GXD4kR
	iCDE40qzXlhxrvf += KhUG1NV9bln5zXjptqFW6dgo(u"࠭็้ࠢ฼ฬฬืษࠡ฻้ࠤอืๆศ็ฯࠤ๏๎แา่ࠢ฽้๎ๅศฬࠣัุอศ๋หࠣ็ะ๐ัสࠢอ๋๊ࠦฬๆ์฼ࠤฬ๊ๅิๆ่๎๋ࠦๅฬๆࠣวํ่วหࠢสฺ่๊วส๋ࠢวํ่วหࠢสู่่่โ๋ࠢห้ิำ้ใࠣ์ู้ไࠡษ็ๆ๊ื้ࠠล๋ๆฬะࠠศๆๅ้ึ่ࠦฤ์ูหࠥ๐่โำࠣีษ๐ษࠡษ็๋้อไࠡใํࠤัฺ๋๊ࠢา์้ࠦวๅ฻ส่๊่ࠦฤ์ูหࠥ็๊่ࠢอๆํ๐ๅࠡ็ํ่ฬี๊๊๊ࠡะึ๐้ࠠใํ๋ࠥษ๊ืษࠣฬาั้ࠠไิหฦฯࠠศๆๅีว์้ࠠลํฺฬࠦแ๋้ࠣหุะฮศำฬࠤํะแศฦ็ࠤํ็๊่ࠢฦๆํอไࠡ็้ืํฮษࠡๆ็ว๊อๅࠡ฻็๎ࠥ๎รๆ๊ิࠤศิั๊ࠢอ๋๊ࠦใๅ่ࠢื้๋ࠠ࠯ࠢส่อืๆศ็ฯࠤ๊้ส้สࠣฬ้เษࠡฮสๅฬࠦำไำหฮࠥ๎๊ิฬัำ๊ࠦๆูษ่ࠤํ๐ๆะ๊ีࠤฯำสࠡสํสฮ่๋่ࠦา์ืࠦใศฮํฮࠥ๎ๅฯืุࠤๆ่ืࠡๆฦะ์ุษࠡษ็์๏์ฯ้ิࠣ࠲ࠥอไๆ๊ๅ฽ࠥอไาี่๎๊ࠥไษำ้ห๊า่๊ࠠࠪᄫ")
	iCDE40qzXlhxrvf += ti3SbXNV0aJ7n5Grc4OQY8Ll1s9+s7d549VgeP+KhUG1NV9bln5zXjptqFW6dgo(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡶ࡬ࡲࡾ࠴ࡣࡤ࠱ࡰࡹࡸࡲࡩ࡮ࡴࡸࡰࡪࡸࠧᄬ")+cjqzOQ5GXD4kR
	wwpQTfixYD23X = KKi79PFqsYB0dWSRgaJ3DyE(u"ࠨ࡝ࡕࡘࡑࡣࠧᄭ")+rGIDET0OmyFiUL8q+A0aqj9uclgOtByJ6F4bz(u"ࠩ࡟ࡲࡡࡴ࡜࡯࡝ࡕࡘࡑࡣࠧᄮ")+iCDE40qzXlhxrvf
	LQf1jSRk4tA32a(CDwSWB4v39N7(u"ࠪࡶ࡮࡭ࡨࡵࠩᄯ"),HQmDERMFjx,wwpQTfixYD23X)
	return
def bh3ABSfYLvlgqIDHwoCxM9Kzn(LnricPbQjug6yt0lUIeMKpVDTa):
	EJ095ZSqDBGj(rwjfOIqQU3ANa0JlWXvCDbFk)
	Ys1MPUmFJx = FvaWzEZCjUQrwiDhqopsKO(LnricPbQjug6yt0lUIeMKpVDTa)
	for wGuYfX8psIxR2Vi50bPgBOTk6 in [A0aqj9uclgOtByJ6F4bz(u"ࠫࡒࡋࡓࡔࡃࡊࡉࡘ࠭ᄰ"),ShnRVsifKtc60zqQ(u"ࠬࡗࡕࡆࡕࡗࡍࡔࡔࡓࠨᄱ"),OzU6t0qcH7MQabeBYK8vgoG(u"࠭ࡍࡆࡕࡖࡅࡌࡋࡓࡠࡖࡖࠫᄲ"),EAVanJj1ers2GQud(u"ࠧࡒࡗࡈࡗ࡙ࡏࡏࡏࡕࡢࡘࡘ࠭ᄳ")]:
		if wGuYfX8psIxR2Vi50bPgBOTk6 in Jzthpc2nj5.SEND_THESE_EVENTS: Jzthpc2nj5.SEND_THESE_EVENTS.remove(wGuYfX8psIxR2Vi50bPgBOTk6)
	yTwbG2EasgzRMkiO786cBm15FnxrD(owbMhINBQsmx70guApW(u"ࠨࡆࡒࡒࡆ࡚ࡉࡐࡐࡖࠫᄴ"))
	id,QXcqfBzUWRdgrn7JSsTi1Po83C,heEP6tMJ1GQHW8vA4,CFZz49jp6Ye,fG849OmcsHS3WLC5MuAJeKINUpl6,reason = Ys1MPUmFJx[o4bNzIQGYj8En]
	kndocJLZ2Azqmt8vDX7C0BIpPF,fgHDhIdESXZv = CFZz49jp6Ye.split(cWbkR6iUZsnJQj14(u"ࠩ࡟ࡲࡀࡁࠧᄵ"))
	iCDE40qzXlhxrvf,Q8QSUrGdpmul,wqI0MRzPSQoeph3nBN9Hcb = fG849OmcsHS3WLC5MuAJeKINUpl6.split(A0aqj9uclgOtByJ6F4bz(u"ࠪࡠࡳࡁ࠻ࠨᄶ"))
	N7dSwJ4AcoWx1PgE = gyd2rf0UR5
	while N7dSwJ4AcoWx1PgE:
		bxljcA64SnCef5ki8LB = uumd4lZkWVE81cI7p0eXgtTQjxhHJ(HQmDERMFjx,LHX65I9nkx0PstgcVY24uSi(u"ࠫำื่อࠩᄷ"),C3ZK1pu4rfmj8TsWUtBaM(u"ࠬหัิษ็ࠤึูวๅห่้๋ࠣศา็ฯࠫᄸ"),n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"࠭โศศ่อࠥอไหสิ฽ฬะࠧᄹ"),cWbkR6iUZsnJQj14(u"ࠧๅวํๆฬ็ࠠศๆศ฽้อๆศฬࠣ࠾ࠥࠦสษำ฼ࠤศ๎ࠠศ็ึัࠥอไษำ้ห๊าࠧᄺ"),iCDE40qzXlhxrvf)
		if bxljcA64SnCef5ki8LB==EAVanJj1ers2GQud(u"࠴Ꮐ"): EE6sr5owFGI3cWgRftNK = uumd4lZkWVE81cI7p0eXgtTQjxhHJ(HQmDERMFjx,HQmDERMFjx,OBsrtQo2pPlgURCxJYbj9iXMD(u"ࠨ฻๋ำฮ࠭ᄻ"),HQmDERMFjx,nz8x32hX0qcjUPFZk5RdJsiwED(u"่ࠩฬิษࠠศๆอฬึ฿ࠠ฻์ิࠤ็อศๅࠢ็่๋่วีࠩᄼ"),Q8QSUrGdpmul,n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"ࠪࡧࡴࡴࡦࡪࡴࡰࡣࡸࡳࡡ࡭࡮ࡩࡳࡳࡺࠧᄽ"))
		elif bxljcA64SnCef5ki8LB==YJxaX0MQOHb8oyCBFdnIAe(u"࠴Ꮑ"): YYxk6FtA4PCMr5Zco18LfiwBa()
		else: N7dSwJ4AcoWx1PgE = mic3MEN709xOkrjD5ZvbGIlX6
	if LnricPbQjug6yt0lUIeMKpVDTa: dXUwsnOGKBF57cNaok(mic3MEN709xOkrjD5ZvbGIlX6)
	return
def Fa218v0X9Pye():
	uELMyWtoGOCRz9A0b6Sam()
	mmbOuQFyfC3NsnkvHZYLR = H8jfvMtXa7Neiu.getSetting(nz8x32hX0qcjUPFZk5RdJsiwED(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡤࡣࡦ࡬ࡪ࠭ᄾ"))
	wwpQTfixYD23X = {}
	wwpQTfixYD23X[YJxaX0MQOHb8oyCBFdnIAe(u"ࠬࡇࡕࡕࡑࠪᄿ")] = CDwSWB4v39N7(u"࠭วๅๅสุࠥอไหๆๅหห๐๋ࠠ฻่่ࠬᅀ")
	wwpQTfixYD23X[owbMhINBQsmx70guApW(u"ࠧࡔࡖࡒࡔࠬᅁ")] = Tcf5Ppn9UajDbzyM(u"ࠨษ็็ฬฺࠠๆฬ๋ๆๆࠦสๆษ่หࠥ๎ศศๆๆห๊๊ࠧᅂ")
	wwpQTfixYD23X[CDwSWB4v39N7(u"ࠩࡏࡍࡒࡏࡔࡆࡆࠪᅃ")] = A0aqj9uclgOtByJ6F4bz(u"ࠪ็ฬฺࠠอัสࠤ็฻๊าࠢส่๊ี้ࠡ࠰ࠣࠫᅄ")+str(DAev91QlUOxzLSBaof/KKi79PFqsYB0dWSRgaJ3DyE(u"࠺࠵Ꮒ"))+HDpmv4UXzlf72SK9(u"ࠫࠥีโ๋ไฬࠤๆ่ืࠨᅅ")
	sNY0SWKb2g8qMoGLnfpvlF7HwC = wwpQTfixYD23X[mmbOuQFyfC3NsnkvHZYLR]
	Tk70cbAyLw = uumd4lZkWVE81cI7p0eXgtTQjxhHJ(HQmDERMFjx,LHX65I9nkx0PstgcVY24uSi(u"้ࠬวีࠢࠪᅆ")+str(DAev91QlUOxzLSBaof/ELfMeDTIFhJt685K(u"࠻࠶Ꮓ"))+dBi72erQEtKDOwjNFaoAgSP(u"࠭ࠠะไํๆฮ࠭ᅇ"),PPAUFrY8cduRT(u"ࠧหึ฽๎้ࠦสๅไสส๏࠭ᅈ"),JJA7fypmZFVlazvNI(u"ࠨวํๆฬ็ࠠไษ่่ࠬᅉ"),sNY0SWKb2g8qMoGLnfpvlF7HwC,mgLADoQ1pbtY(u"๊่ࠩࠥะั๋ัࠣหุะฮะษ่ࠤฬ๊ใศึࠣห้ึใ๋ࠢส่ฯ๊โศศํࠤศ๋ࠠหำํำࠥห๊ใษไࠤฬ๊ใศึࠣฬฬ๊ใศ็็ࠤศ๋ࠠหำํำ้ࠥวีࠢ฼้ึํࠠใืํีࠥาฯศࠢยࠥࠬᅊ"))
	if Tk70cbAyLw==ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"࠶Ꮔ"): gVSyswbztaFJNB0PrKd2uI = jL1E5AKfwBDv6xmeQtUXcJ3d(u"ࠪࡐࡎࡓࡉࡕࡇࡇࠫᅋ")
	elif Tk70cbAyLw==dBi72erQEtKDOwjNFaoAgSP(u"࠱Ꮕ"): gVSyswbztaFJNB0PrKd2uI = pCTzbw4GyVJHjkcIMQ(u"ࠫࡆ࡛ࡔࡐࠩᅌ")
	elif Tk70cbAyLw==ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"࠳Ꮖ"): gVSyswbztaFJNB0PrKd2uI = Tcf5Ppn9UajDbzyM(u"࡙ࠬࡔࡐࡒࠪᅍ")
	else: gVSyswbztaFJNB0PrKd2uI = HQmDERMFjx
	if gVSyswbztaFJNB0PrKd2uI:
		H8jfvMtXa7Neiu.setSetting(EF2tvxZHz5n4UruPhaViXKycI6SQR(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡦࡥࡨ࡮ࡥࠨᅎ"),gVSyswbztaFJNB0PrKd2uI)
		h3hGcQmqYLjC = wwpQTfixYD23X[gVSyswbztaFJNB0PrKd2uI]
		u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,h3hGcQmqYLjC)
	return
def czgSs9FHiq():
	wwpQTfixYD23X = {}
	wwpQTfixYD23X[OBsrtQo2pPlgURCxJYbj9iXMD(u"ࠧࡂࡗࡗࡓࠬᅏ")] = Tcf5Ppn9UajDbzyM(u"ࠨีํีๆืࠠࡅࡐࡖࠤฬ๊สๅไสส๏ฺ๊ࠦ็็࠾ࠥ࠭ᅐ")
	wwpQTfixYD23X[dBi72erQEtKDOwjNFaoAgSP(u"ࠩࡄࡗࡐ࠭ᅑ")] = cWbkR6iUZsnJQj14(u"ࠪื๏ืแาࠢࡇࡒࡘࠦำ๋฻่่ࠥฮูะࠢสุ่๋วฮࠢ็๋࠿ࠦࠧᅒ")
	wwpQTfixYD23X[EF2tvxZHz5n4UruPhaViXKycI6SQR(u"ࠫࡘ࡚ࡏࡑࠩᅓ")] = PPAUFrY8cduRT(u"ู๊ࠬาใิࠤࡉࡔࡓࠡ็อ์็็ࠠห็ส้ฬ่ࠦษษ็็ฬ๋ไࠨᅔ")
	ABGgXSh3VUMu5frva9TKo0wqOi = H8jfvMtXa7Neiu.getSetting(Tcf5Ppn9UajDbzyM(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡧࡲࡸ࠭ᅕ"))
	mmbOuQFyfC3NsnkvHZYLR = H8jfvMtXa7Neiu.getSetting(KhUG1NV9bln5zXjptqFW6dgo(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡹࡸ࡫ࡤ࡯ࡵࠪᅖ"))
	sNY0SWKb2g8qMoGLnfpvlF7HwC = wwpQTfixYD23X[mmbOuQFyfC3NsnkvHZYLR]+ABGgXSh3VUMu5frva9TKo0wqOi
	Tk70cbAyLw = uumd4lZkWVE81cI7p0eXgtTQjxhHJ(HQmDERMFjx,mgLADoQ1pbtY(u"ࠨฬื฾๏ฺ๊่ࠠาࠤฬ๊ๅ้ษไๆฮ࠭ᅗ"),EF2tvxZHz5n4UruPhaViXKycI6SQR(u"ࠩอุ฿๐ไࠡฬ็ๆฬฬ๊ࠨᅘ"),EF2tvxZHz5n4UruPhaViXKycI6SQR(u"ࠪษ๏่วโࠢๆห๊๊ࠧᅙ"),sNY0SWKb2g8qMoGLnfpvlF7HwC,HDpmv4UXzlf72SK9(u"ุࠫ๐ัโำࠣࡈࡓ่๊࡙ࠠࠣะ์อาࠡใํࠤฬ๊ล็ฬิ๊๏ะ๋ࠠไ๋้ࠥฮสฮ๊ํ่ࠥษำๆษฤࠤฬ๊ๅ้ษๅ฽ࠥ๎วๅีํีๆืวหࠢศ่๎ࠦราไส้ࠥ๎ู็ัࠣฬ฾฼ࠠศๆ้หุ๊ࠦใ๊่ࠤอำฬษ๋้๋ࠢ฿้ࠠฯูีࠥฮูืࠢส่๊๎วใ฻ࠣ࠲๊ࠥสี฼ํู่๊ࠥาใิࠤࡉࡔࡓࠡไ่ࠤออฮห์สีࠥอไิ์ิๅึࠦวๅ็้หุฮࠠฤ๊ࠣๆ๊ࠦศฦ์ๅหๆํࠠษษ็็ฬ๋ไࠨᅚ"))
	if Tk70cbAyLw==LHX65I9nkx0PstgcVY24uSi(u"࠲Ꮗ"): gVSyswbztaFJNB0PrKd2uI = dBi72erQEtKDOwjNFaoAgSP(u"ࠬࡇࡓࡌࠩᅛ")
	elif Tk70cbAyLw==k4IUieraScH9DV1N7pJgQosYAx5l(u"࠴Ꮘ"): gVSyswbztaFJNB0PrKd2uI = jL1E5AKfwBDv6xmeQtUXcJ3d(u"࠭ࡁࡖࡖࡒࠫᅜ")
	elif Tk70cbAyLw==ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"࠶Ꮙ"): gVSyswbztaFJNB0PrKd2uI = KKi79PFqsYB0dWSRgaJ3DyE(u"ࠧࡔࡖࡒࡔࠬᅝ")
	if Tk70cbAyLw in [jL1E5AKfwBDv6xmeQtUXcJ3d(u"࠶Ꮛ"),k4IUieraScH9DV1N7pJgQosYAx5l(u"࠶Ꮚ")]:
		N7gs9UBCeDR3 = HUJZy0SrTbBYv1(pCTzbw4GyVJHjkcIMQ(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨᅞ"),PPAUFrY8cduRT(u"ࠩึ๎ึ็ั࠻ࠢࠪᅟ")+Jzthpc2nj5.DNS_SERVERS[CH7RKuDVzN9f06q8MtXPhlvIxakEWg],n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"ࠪื๏ืแา࠼ࠣࠫᅠ")+Jzthpc2nj5.DNS_SERVERS[o4bNzIQGYj8En],HQmDERMFjx,OzU6t0qcH7MQabeBYK8vgoG(u"ࠫศิสศำࠣื๏ืแาࠢࡇࡒࡘࠦวๅ็้หุฮࠠๅๅࠪᅡ"))
		if N7gs9UBCeDR3==ShnRVsifKtc60zqQ(u"࠱Ꮜ"): YYsADrUILeXGcEmQhRo3OV = Jzthpc2nj5.DNS_SERVERS[o4bNzIQGYj8En]
		else: YYsADrUILeXGcEmQhRo3OV = Jzthpc2nj5.DNS_SERVERS[CH7RKuDVzN9f06q8MtXPhlvIxakEWg]
	elif Tk70cbAyLw==Tcf5Ppn9UajDbzyM(u"࠳Ꮝ"): YYsADrUILeXGcEmQhRo3OV = HQmDERMFjx
	else: gVSyswbztaFJNB0PrKd2uI = HQmDERMFjx
	if gVSyswbztaFJNB0PrKd2uI:
		H8jfvMtXa7Neiu.setSetting(owbMhINBQsmx70guApW(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡷࡶࡩࡩࡴࡳࠨᅢ"),gVSyswbztaFJNB0PrKd2uI)
		H8jfvMtXa7Neiu.setSetting(knTyjJ0sGIzuwbxRae(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡧࡲࡸ࠭ᅣ"),YYsADrUILeXGcEmQhRo3OV)
		h3hGcQmqYLjC = wwpQTfixYD23X[gVSyswbztaFJNB0PrKd2uI]+YYsADrUILeXGcEmQhRo3OV
		u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,h3hGcQmqYLjC)
	return
def yD1ZdvcFfJ8E():
	mmbOuQFyfC3NsnkvHZYLR = H8jfvMtXa7Neiu.getSetting(cWbkR6iUZsnJQj14(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡹࡸ࡫ࡰࡳࡱࡻࡽࠬᅤ"))
	wwpQTfixYD23X = {}
	wwpQTfixYD23X[Tcf5Ppn9UajDbzyM(u"ࠨࡃࡘࡘࡔ࠭ᅥ")] = Tcf5Ppn9UajDbzyM(u"ࠩส่อื่ไีํࠤฬ๊สๅไสส๏ࠦฬศ้ีࠤู้๊ๆๆࠪᅦ")
	wwpQTfixYD23X[JJA7fypmZFVlazvNI(u"ࠪࡅࡘࡑࠧᅧ")] = nz8x32hX0qcjUPFZk5RdJsiwED(u"ࠫฬ๊ศา๊ๆื๏ࠦำ๋฻่่ࠥฮูะࠢสุ่๋วฮࠢ็๋ࠬᅨ")
	wwpQTfixYD23X[JJA7fypmZFVlazvNI(u"࡙ࠬࡔࡐࡒࠪᅩ")] = maUl7SPesynF1j(u"࠭วๅสิ์ู่๊ࠡ็อ์็็ࠠห็ส้ฬ่ࠦษษ็็ฬ๋ไࠨᅪ")
	sNY0SWKb2g8qMoGLnfpvlF7HwC = wwpQTfixYD23X[mmbOuQFyfC3NsnkvHZYLR]
	Tk70cbAyLw = uumd4lZkWVE81cI7p0eXgtTQjxhHJ(HQmDERMFjx,cWbkR6iUZsnJQj14(u"ࠧหึ฽๎ู้ࠦ็ัࠣห้๋่ศใๅอࠬᅫ"),pCTzbw4GyVJHjkcIMQ(u"ࠨฬื฾๏๊ࠠหๆๅหห๐ࠧᅬ"),owbMhINBQsmx70guApW(u"ࠩศ๎็อแࠡๅส้้࠭ᅭ"),sNY0SWKb2g8qMoGLnfpvlF7HwC,KhUG1NV9bln5zXjptqFW6dgo(u"ࠪห้ฮั้ๅึ๎ࠥํ่ࠡฮ๊หืࠦแ๋ࠢส่ส์สา่ํฮࠥ๐ูๆๆࠣ์ุ๐ืࠡสํ๊ࠥา็ศิๆࠤํอไฦ่อี๋๐สࠡ࠰๋ࠣํ๊ࠦิฬ็้ࠥ฽ไษษอ็ࠥ๎๊ใ๊่ࠤอูอษ้สࠤอีไศ่๊่ࠢࠦหๆࠢํฬ฾ั็ศࠢ็็ࠥ࠴่ࠠๆࠣฮึ๐ฯࠡฬื฾๏๊ࠠฤ็ࠣษ๏่วโࠢส่อื่ไีํࠤฤ࠭ᅮ"))
	if Tk70cbAyLw==U0VwOviFaYPz2QGs45mJhMXf7Zk(u"࠲Ꮞ"): gVSyswbztaFJNB0PrKd2uI = jL1E5AKfwBDv6xmeQtUXcJ3d(u"ࠫࡆ࡙ࡋࠨᅯ")
	elif Tk70cbAyLw==k4IUieraScH9DV1N7pJgQosYAx5l(u"࠴Ꮟ"): gVSyswbztaFJNB0PrKd2uI = k4IUieraScH9DV1N7pJgQosYAx5l(u"ࠬࡇࡕࡕࡑࠪᅰ")
	elif Tk70cbAyLw==CDwSWB4v39N7(u"࠶Ꮠ"): gVSyswbztaFJNB0PrKd2uI = mg3CbXMA2ouZzQDhRqB(u"࠭ࡓࡕࡑࡓࠫᅱ")
	else: gVSyswbztaFJNB0PrKd2uI = HQmDERMFjx
	if gVSyswbztaFJNB0PrKd2uI:
		H8jfvMtXa7Neiu.setSetting(KKi79PFqsYB0dWSRgaJ3DyE(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡹࡸ࡫ࡰࡳࡱࡻࡽࠬᅲ"),gVSyswbztaFJNB0PrKd2uI)
		h3hGcQmqYLjC = wwpQTfixYD23X[gVSyswbztaFJNB0PrKd2uI]
		u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,h3hGcQmqYLjC)
	return
def BERwqDILtsVuy():
	qr8F1J4xpSTCiZ7 = H8jfvMtXa7Neiu.getSetting(Tcf5Ppn9UajDbzyM(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡦࡻࡴࡰࡵࡦࡶࡦࡶࡥࡳࡵࠪᅳ"))
	if qr8F1J4xpSTCiZ7==EF2tvxZHz5n4UruPhaViXKycI6SQR(u"ࠩࡖࡘࡔࡖࠧᅴ"): header = EF2tvxZHz5n4UruPhaViXKycI6SQR(u"ࠪฮัอ่ำࠢส่าาศࠡษ็วํะ่ๆษอ๎่๐ࠠๆฬ๋ๆๆ࠭ᅵ")
	else: header = nz8x32hX0qcjUPFZk5RdJsiwED(u"ࠫฯาว้ิࠣห้ำฬษࠢส่ศ๎ส้็สฮ๏้๊ࠡ็ไ฽้࠭ᅶ")
	N7gs9UBCeDR3 = HUJZy0SrTbBYv1(HQmDERMFjx,mg3CbXMA2ouZzQDhRqB(u"ࠬห๊ใษไࠫᅷ"),PPAUFrY8cduRT(u"࠭สโ฻ํ่ࠬᅸ"),header,C3ZK1pu4rfmj8TsWUtBaM(u"ࠧษ฻ูࠤฬ๊ๅ้ษๅ฽ࠥะูศ่ํࠤ๊์ࠠๆึๆ่ฮࠦวๅฯฯฬࠥ࠴࠮้ࠡำหࠥอไฮฮหࠤ๏๋ๆฺࠢส่อืๆศ็ฯࠤ๊์ࠠโฬะࠤฬ๊ีโฯสฮࠥ๎โาษฤฮ์อࠠ࠯࠰๋๋ࠣอࠠหีอ฻๏฿ࠠฤ่ࠣฮุ๋อࠡๆ็ฬึ์วๆฮࠣว๋๊ࠦใ๊่ࠤศ๎ส้็สฮ๏้๊ศࠢห้าอ่ๅหࠣฮัอ่ำ๊ࠢิฬࠦวๅฯฯฬࠥࡢ࡮࡝ࡰ๋้ࠣࠦสา์าࠤฯ็ู๋ๆࠣว๊ࠦล๋ไสๅࠥะฬศ๊ีࠤฬ๊ออสࠣห้ษ่ห๊่หฯ๐ใ๋ࠢยࠥࠦ࠭ᅹ"))
	if N7gs9UBCeDR3==-X2crmy67eZpkGTRd(u"࠶Ꮡ"): return
	elif N7gs9UBCeDR3:
		H8jfvMtXa7Neiu.setSetting(A0aqj9uclgOtByJ6F4bz(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡦࡻࡴࡰࡵࡦࡶࡦࡶࡥࡳࡵࠪᅺ"),k4IUieraScH9DV1N7pJgQosYAx5l(u"ࠩࡄ࡙࡙ࡕࠧᅻ"))
		u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,Tcf5Ppn9UajDbzyM(u"ࠪฮ๊ࠦสโ฻ํ่ࠥะฬศ๊ีࠤฬ๊ออสࠣห้ษ่ห๊่หฯ๐ใ๋ࠩᅼ"))
	else:
		H8jfvMtXa7Neiu.setSetting(owbMhINBQsmx70guApW(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡢࡷࡷࡳࡸࡩࡲࡢࡲࡨࡶࡸ࠭ᅽ"),KKi79PFqsYB0dWSRgaJ3DyE(u"࡙ࠬࡔࡐࡒࠪᅾ"))
		u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,SODvU3Ibq5VzC(u"࠭สๆࠢศ๎็อแࠡฬฯหํุࠠศๆะะอࠦวๅล๋ฮํ๋วห์ๆ๎ࠬᅿ"))
	return
def PQGVODzqpcS():
	qr8F1J4xpSTCiZ7 = H8jfvMtXa7Neiu.getSetting(HDpmv4UXzlf72SK9(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡱࡪࡴࡵࡴࡥࡤࡧ࡭࡫ࠧᆀ"))
	if qr8F1J4xpSTCiZ7==nz8x32hX0qcjUPFZk5RdJsiwED(u"ࠨࡕࡗࡓࡕ࠭ᆁ"): header = CDwSWB4v39N7(u"ࠩอาื๐ๆࠡษ็ๆํอฦๆ่ࠢฮํ่แࠨᆂ")
	else: header = knTyjJ0sGIzuwbxRae(u"ࠪฮำุ๊็ࠢส่็๎วว็้ࠣๆ฿ไࠨᆃ")
	N7gs9UBCeDR3 = HUJZy0SrTbBYv1(HQmDERMFjx,cWbkR6iUZsnJQj14(u"ࠫส๐โศใࠪᆄ"),ELfMeDTIFhJt685K(u"ࠬะแฺ์็ࠫᆅ"),header,Tcf5Ppn9UajDbzyM(u"࠭โ้ษษ้ࠥอไษำ้ห๊า๋ࠠฬ่ࠤฯำฯ๋อ๊หࠥษ่ห๊่หฯ๐ใ๋ษࠣฬ฾ีࠠ࠲࠸ࠣืฬ฿ษࠡ็้ࠤศ๎ไࠡลึฮำีวๆࠢ࠱࠲ࠥ๎ล๋ไสๅࠥะฮำ์้ࠤฬ๊โ้ษษ้ࠥ๐ฤะ์ࠣษ้๏ࠠหฯา๎ะํวࠡใํࠤ่๊ࠠๆำฬࠤ๏ะๅࠡษึฮำีวๆࠢส่็๎วว็ࠣ࠲࠳่่ࠦาสࠤ๏ูศษࠢห฻หࠦแ๋ࠢไฮาࠦโ้ษษ้ࠥอไษำ้ห๊า࡜࡯࡞ࡱࠤ์๊ࠠหำํำࠥะแฺ์็ࠤศ๋ࠠฦ์ๅหๆࠦสฯิํ๊ࠥอไใ๊สส๊ࠦฟࠢࠣࠪᆆ"))
	if N7gs9UBCeDR3==-cWbkR6iUZsnJQj14(u"࠷Ꮢ"): return
	elif N7gs9UBCeDR3:
		H8jfvMtXa7Neiu.setSetting(PPAUFrY8cduRT(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡱࡪࡴࡵࡴࡥࡤࡧ࡭࡫ࠧᆇ"),KKi79PFqsYB0dWSRgaJ3DyE(u"ࠨࡃࡘࡘࡔ࠭ᆈ"))
		u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,CDwSWB4v39N7(u"ࠩอ้ࠥะแฺ์็ࠤฯิา๋่ࠣห้่่ศศ่ࠫᆉ"))
	else:
		H8jfvMtXa7Neiu.setSetting(mg3CbXMA2ouZzQDhRqB(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴࡭ࡦࡰࡸࡷࡨࡧࡣࡩࡧࠪᆊ"),CDwSWB4v39N7(u"ࠫࡘ࡚ࡏࡑࠩᆋ"))
		u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"ࠬะๅࠡวํๆฬ็ࠠหะี๎๋ࠦวๅไ๋หห๋ࠧᆌ"))
	return
def Eb8j7AGIJnHaFOw():
	ZRNjJVpHr43PCBIvkmz9U = H8jfvMtXa7Neiu.getSetting(n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡰࡩࡳࡻࡳࡸࡧࡥࡧࡦࡩࡨࡦࠩᆍ"))
	if ZRNjJVpHr43PCBIvkmz9U==pCTzbw4GyVJHjkcIMQ(u"ࠧࡔࡖࡒࡔࠬᆎ"): header = HDpmv4UXzlf72SK9(u"ࠨฮ็ฬࠥอไใ๊สส๊ࠦๅ็ࠢส่ส์สา่อࠤ๊ะ่ใใࠪᆏ")
	else: header = PPAUFrY8cduRT(u"ࠩฯ่อࠦวๅไ๋หห๋ࠠๆ่ࠣห้หๆหำ้ฮ๋ࠥแฺๆࠪᆐ")
	N7gs9UBCeDR3 = HUJZy0SrTbBYv1(HQmDERMFjx,ShnRVsifKtc60zqQ(u"ࠪษ๏่วโࠩᆑ"),Tcf5Ppn9UajDbzyM(u"ࠫฯ็ู๋ๆࠪᆒ"),header,knTyjJ0sGIzuwbxRae(u"่่ࠬศศ่ࠤอ฿ึࠡษ็้ํอโฺ๋ࠢาฬ฻ษࠡษ็้าา่ษห้๊้ࠣๆࠡฬัึ๏์็ศࠢไ๎ࠥอไฦ่อี๋ะࠠโ์ࠣื๏ืแาษอࠤ้อ๋๊ࠠฯำࠥ็๊่ษู้้ࠣไสࠢะะอࠦ࠮࠯๊ࠢิ์ࠦวๅูิ๎็ฯࠠหีส฽ิࠦแ๋ࠢๅีฬวษ๊ࠡสืฯิฯศ็ࠣห้๋่ศไ฼ࠤฬ๊ๅฮฮ๋ฬฮࠦไไ่้๋ࠣࠦๅ้ไ฼ࠤอี๊ๅ่ࠢฮํ็ั๊ࠡ฽๎ึࠦๅฮฮ๋ฬࠥࡢ࡮࡝ࡰ࡟ࡲࠥํไࠡฬิ๎ิࠦสโ฻ํ่ࠥษๅࠡวํๆฬ็ࠠอๆหࠤฬ๊โ้ษษ้๋ࠥๆࠡษ็ษ๋ะั็ฬࠣรࠦࠧࠧᆓ"))
	if N7gs9UBCeDR3==-HDpmv4UXzlf72SK9(u"࠱Ꮣ"): return
	elif N7gs9UBCeDR3:
		H8jfvMtXa7Neiu.setSetting(nz8x32hX0qcjUPFZk5RdJsiwED(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡰࡩࡳࡻࡳࡸࡧࡥࡧࡦࡩࡨࡦࠩᆔ"),ShnRVsifKtc60zqQ(u"ࠧࡂࡗࡗࡓࠬᆕ"))
		u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,CDwSWB4v39N7(u"ࠨฬ่ࠤฯ็ู๋ๆࠣะ้ฮࠠศๆๅ์ฬฬๅࠡ็้ࠤฬ๊่๋สࠪᆖ"))
	else:
		H8jfvMtXa7Neiu.setSetting(maUl7SPesynF1j(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡳࡥ࡯ࡷࡶࡻࡪࡨࡣࡢࡥ࡫ࡩࠬᆗ"),PPAUFrY8cduRT(u"ࠪࡗ࡙ࡕࡐࠨᆘ"))
		u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,EF2tvxZHz5n4UruPhaViXKycI6SQR(u"ࠫฯ๋ࠠฦ์ๅหๆࠦฬๅสࠣห้่่ศศ่ࠤ๊์ࠠศๆ๋๎อ࠭ᆙ"))
	return
def NNRKIOUgP3(NN9niuC7RoqmhkL2):
	if NN9niuC7RoqmhkL2!=HQmDERMFjx:
		NN9niuC7RoqmhkL2 = hMt6yjiJ2DpwBE(NN9niuC7RoqmhkL2)
		NN9niuC7RoqmhkL2 = NN9niuC7RoqmhkL2.decode(Zex6D4tJE52r).encode(Zex6D4tJE52r)
		T7ktndxrcMCj = YJxaX0MQOHb8oyCBFdnIAe(u"࠲࠲࠴࠴࠸Ꮤ")
		HBrpsCLNuT0XOPGZA6IJSy3ai = P3qhMC0OYJ9UBWEG7ia4fkd.Window(T7ktndxrcMCj)
		HBrpsCLNuT0XOPGZA6IJSy3ai.getControl(PPAUFrY8cduRT(u"࠵࠴࠵Ꮥ")).setLabel(NN9niuC7RoqmhkL2)
	return
fLvePCBhFRs = [
			 LHX65I9nkx0PstgcVY24uSi(u"ࠧ࡫ࡸࡵࡧࡱࡷ࡮ࡵ࡮ࠡࡣࡹࡷࡵࡧࡣࡦࡵ࠳ࠤ࡮ࡹࠠ࡯ࡱࡷࠤࡨࡻࡲࡳࡧࡱࡸࡱࡿࠠࡴࡷࡳࡴࡴࡸࡴࡦࡦࠥᆚ")
			,JJA7fypmZFVlazvNI(u"࠭ࡃࡩࡧࡦ࡯࡮ࡴࡧࠡࡨࡲࡶࠥࡓࡡ࡭࡫ࡦ࡭ࡴࡻࡳࠡࡵࡦࡶ࡮ࡶࡴࡴࠩᆛ")
			,CDwSWB4v39N7(u"ࠧࡑࡘࡕࠤࡎࡖࡔࡗࠢࡖ࡭ࡲࡶ࡬ࡦࠢࡆࡰ࡮࡫࡮ࡵࠩᆜ")
			,SODvU3Ibq5VzC(u"ࠨࡗࡱ࡯ࡳࡵࡷ࡯࡙ࠢ࡭ࡩ࡫࡯ࠡࡋࡱࡪࡴࠦࡋࡦࡻࠪᆝ")
			,cWbkR6iUZsnJQj14(u"ࠩࡷ࡬࡮ࡹࠠࡩࡣࡶ࡬ࠥ࡬ࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡪࡵࠣࡦࡷࡵ࡫ࡦࡰࠪᆞ")
			,maUl7SPesynF1j(u"ࠪࡹࡸ࡫ࡳࠡࡲ࡯ࡥ࡮ࡴࠠࡉࡖࡗࡔࠥ࡬࡯ࡳࠢࡤࡨࡩ࠳࡯࡯ࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࡷࠬᆟ")
			,dBi72erQEtKDOwjNFaoAgSP(u"ࠫࡦࡪࡶࡢࡰࡦࡩࡩ࠳ࡵࡴࡣࡪࡩ࠳࡮ࡴ࡮࡮ࠪᆠ")+HDpmv4UXzlf72SK9(u"ࠬࠩࠧᆡ")+C3ZK1pu4rfmj8TsWUtBaM(u"࠭ࡳࡴ࡮࠰ࡻࡦࡸ࡮ࡪࡰࡪࡷࠬᆢ")
			,U0VwOviFaYPz2QGs45mJhMXf7Zk(u"ࠧࡊࡰࡶࡩࡨࡻࡲࡦࡔࡨࡵࡺ࡫ࡳࡵ࡙ࡤࡶࡳ࡯࡮ࡨ࠮ࠪᆣ")
			,jL1E5AKfwBDv6xmeQtUXcJ3d(u"ࠨࡇࡵࡶࡴࡸࠠࡨࡧࡷࡸ࡮ࡴࡧࠡࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࡷࡰ࡯࡮࠯࡯ࡨࡸࡷࡵࡰࡰ࡮࡬ࡷࡊࡓࡁࡅ࠱ࡂࡱࡴࡪࡥࡦ࠿࠳ࠪࡹ࡫ࡸࡵࡶࡀࠫᆤ")
			,EF2tvxZHz5n4UruPhaViXKycI6SQR(u"ࠩࡺࡥࡷࡴࡩ࡯ࡩࡶ࠲ࡼࡧࡲ࡯ࠪࠪᆥ")
			,SODvU3Ibq5VzC(u"ࠪࡢࡣࡤ࡞࡟ࠩᆦ")
			,k4IUieraScH9DV1N7pJgQosYAx5l(u"ࠫࡑࡵࡡࡥ࡫ࡱ࡫ࠥࡹ࡫ࡪࡰࠣࡪ࡮ࡲࡥ࠻ࠩᆧ")
			,owbMhINBQsmx70guApW(u"ࠬࡲࡡࡳࡩࡨࠤࡦࡻࡤࡪࡱࠣࡷࡾࡴࡣࠡࡧࡵࡶࡴࡸ࠺ࠨᆨ")
			,ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"࠭ࡩ࡯ࡨࡲ࠾ࠥࡓࡥࡥ࡫ࡤࡧࡴࡪࡥࡤࠢࡧࡩࡨࡵࡤࡦࡴ࠽ࠫᆩ")
			]
def BaHETJZDmy8F(Z8rQtIjXYHz6d):
	if EAVanJj1ers2GQud(u"ࠧࡍࡱࡤࡨ࡮ࡴࡧࠡࡵ࡮࡭ࡳࠦࡦࡪ࡮ࡨ࠾ࠬᆪ") in Z8rQtIjXYHz6d and k4IUieraScH9DV1N7pJgQosYAx5l(u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭ᆫ") in Z8rQtIjXYHz6d: return gyd2rf0UR5
	for NN9niuC7RoqmhkL2 in fLvePCBhFRs:
		if NN9niuC7RoqmhkL2 in Z8rQtIjXYHz6d: return gyd2rf0UR5
	return mic3MEN709xOkrjD5ZvbGIlX6
def mmOtseXRQKN7gDTMBL4Gnl(data):
	csuaOCyx54UgLtzBIQ6 = ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"࠻Ꮧ") if HH6mxXjgcrEN1aenMFWQkS else U0VwOviFaYPz2QGs45mJhMXf7Zk(u"࠴࠹Ꮦ")
	data = data.replace(ShnRVsifKtc60zqQ(u"࠸࠶Ꮨ")*oQpxmKiRPlHeGsLXNrJF78O,csuaOCyx54UgLtzBIQ6*oQpxmKiRPlHeGsLXNrJF78O)
	data = data.replace(cWbkR6iUZsnJQj14(u"ࠩࠣࡀ࡬࡫࡮ࡦࡴࡤࡰࡃࡀࠠࠨᆬ"),ShnRVsifKtc60zqQ(u"ࠪ࠾ࠥ࠭ᆭ"))
	Vi9fwvbSBCI0K6hgXA8EpFrT = HQmDERMFjx
	for Z8rQtIjXYHz6d in data.splitlines():
		y2OVgDNYT6humdGKI1nPrqiv4Cecf = DyVGS3dX0ZxR.findall(A0aqj9uclgOtByJ6F4bz(u"ࠫࠥࠦࠠࠡࠢࡉ࡭ࡱ࡫ࠠࠣࠪ࠱࠮ࡄࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵ࠱࠭ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪᆮ"),Z8rQtIjXYHz6d,DyVGS3dX0ZxR.DOTALL)
		if y2OVgDNYT6humdGKI1nPrqiv4Cecf: Z8rQtIjXYHz6d = Z8rQtIjXYHz6d.replace(y2OVgDNYT6humdGKI1nPrqiv4Cecf[o4bNzIQGYj8En],HQmDERMFjx)
		Vi9fwvbSBCI0K6hgXA8EpFrT += ti3SbXNV0aJ7n5Grc4OQY8Ll1s9+Z8rQtIjXYHz6d
	return Vi9fwvbSBCI0K6hgXA8EpFrT
def wzJsfW6eiMXSdRyE(kpdCgMLQixW83HNnDX1ZYKPGR):
	if LHX65I9nkx0PstgcVY24uSi(u"ࠬࡕࡌࡅࠩᆯ") in kpdCgMLQixW83HNnDX1ZYKPGR:
		Wfmt3evi4Nwo7Rc6gr = XG79oE8lD1uZ24Mef
		header = cWbkR6iUZsnJQj14(u"࠭โาษฤอࠥอไิฮ็ࠤฬ๊โะ์่ࠤฤ࠭ᆰ")
	else:
		Wfmt3evi4Nwo7Rc6gr = wK3146lA92ubXszFGL
		header = knTyjJ0sGIzuwbxRae(u"ࠧใำสลฮࠦวๅีฯ่ࠥอไฮษ็๎ࠥลࠧᆱ")
	N7gs9UBCeDR3 = HUJZy0SrTbBYv1(HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,header,knTyjJ0sGIzuwbxRae(u"ࠨีฯ่ࠥอไฤะฺหฦ๊ࠦฮฬ๋๎ࠥษ๊ืษࠣ฽้๏ࠠิฮ็ࠤฬ๊วิฬัำฬ๋ࠠ࠯๋ࠢห้อห็์้ࠤ฻ื่า์ฬࠤู้๋าใฬࠤ่๐แࠡฯาฯฯࠦวๅ็ื็้ฯ้ࠠ็สࠤ์๎ࠠศๆ่็ฬ์ࠠศๆำ๎ูࠥศษࠢะำํัࠠศๆุ่่๊ษࠡ࠰ࠣ็ํี๊ࠡ์ะฮๆ฾ࠠษีฯ่๏์ࠠ࠯ࠢส่ศ๎ไ้๋ࠡࠤฬ๊ำอๆࠣห้ำวๅ์ࠣ์ๆ๐็ࠡ็฼่ํ๋วหࠢอฬิษࠠๆ่ำࠤอีว๋หࠣห้ะิ฻์็ࠤฬ๊อศๆํࠤ้ฮั็ษ่ะ้่ࠥะ์ࠣ์ฬ๊้ࠡษ็ฦ๋ࠦ࠮ࠡล่หࠥอไิฮ็ࠤฬ๊โะ์่ࠤๆํ่ࠡษ็ืั๊ࠠศๆึหอ่ࠠศๆำ๎ࠥะๅࠡฮ่฽์ࠦๅ็ࠢหี๋อๅอࠢๆ์ิ๐ࠠใส็ࠤวิัࠡวฺๅฬวࠠๅ้ࠣ࠲ࠥํไࠡฬิ๎ิࠦวๅษึฮ๊ืวาࠢยࠫᆲ"))
	if N7gs9UBCeDR3!=CDwSWB4v39N7(u"࠷Ꮩ"): return
	vSgOyFqf5Ya6ZB,oWRrAQ4PHUDuw76KsBZ2 = [],X2crmy67eZpkGTRd(u"࠰Ꮪ")
	size,count = e6eB5OgKHw4kf1C73IJWNZqAPRbyn(Wfmt3evi4Nwo7Rc6gr)
	file = open(Wfmt3evi4Nwo7Rc6gr,EAVanJj1ers2GQud(u"ࠩࡵࡦࠬᆳ"))
	if size>OzU6t0qcH7MQabeBYK8vgoG(u"࠳࠳࠴࠷࠶࠰Ꮬ"): file.seek(-X2crmy67eZpkGTRd(u"࠲࠲࠳࠵࠵࠶Ꮫ"),S9Y5kUoRga3EVN.SEEK_END)
	data = file.read()
	file.close()
	if HH6mxXjgcrEN1aenMFWQkS: data = data.decode(Zex6D4tJE52r)
	data = mmOtseXRQKN7gDTMBL4Gnl(data)
	Nb3rHkOs6yKCJAlSW5DPLTciBVq2 = data.split(ti3SbXNV0aJ7n5Grc4OQY8Ll1s9)
	for Z8rQtIjXYHz6d in reversed(Nb3rHkOs6yKCJAlSW5DPLTciBVq2):
		AzKdQxpZGXng03 = BaHETJZDmy8F(Z8rQtIjXYHz6d)
		if AzKdQxpZGXng03: continue
		Z8rQtIjXYHz6d = Z8rQtIjXYHz6d.replace(OzU6t0qcH7MQabeBYK8vgoG(u"ࠪࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡣࠬᆴ"),s7d549VgeP+owbMhINBQsmx70guApW(u"ࠫࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦࠧᆵ")+cjqzOQ5GXD4kR)
		Z8rQtIjXYHz6d = Z8rQtIjXYHz6d.replace(EF2tvxZHz5n4UruPhaViXKycI6SQR(u"ࠬࡋࡒࡓࡑࡕ࠾ࠬᆶ"),ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉ࠴࠵࠶࠰࡞ࠩᆷ")+YJxaX0MQOHb8oyCBFdnIAe(u"ࠧࡆࡔࡕࡓࡗࡀࠧᆸ")+cjqzOQ5GXD4kR)
		CzWgM3fBetXS6ADvGs9xN54 = HQmDERMFjx
		D4J0moOTurANclgW = DyVGS3dX0ZxR.findall(n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"ࠨࡠࠫࡠࡩ࠱࠭ࠩ࡞ࡧ࠯࠲ࡢࡤࠬࠢ࡟ࡨ࠰ࡀ࡜ࡥ࠭࠽ࡠࡩ࠱࡜࠯࡞ࡧ࠯࠮࠯ࠨࠡࡖ࠽ࡠࡩ࠱ࠩࠨᆹ"),Z8rQtIjXYHz6d,DyVGS3dX0ZxR.DOTALL)
		if D4J0moOTurANclgW:
			Z8rQtIjXYHz6d = Z8rQtIjXYHz6d.replace(D4J0moOTurANclgW[o4bNzIQGYj8En][o4bNzIQGYj8En],D4J0moOTurANclgW[o4bNzIQGYj8En][CH7RKuDVzN9f06q8MtXPhlvIxakEWg]).replace(D4J0moOTurANclgW[o4bNzIQGYj8En][FFHRwuxQmbh8BaTqyX3],HQmDERMFjx)
			CzWgM3fBetXS6ADvGs9xN54 = D4J0moOTurANclgW[o4bNzIQGYj8En][CH7RKuDVzN9f06q8MtXPhlvIxakEWg]
		else:
			D4J0moOTurANclgW = DyVGS3dX0ZxR.findall(cWbkR6iUZsnJQj14(u"ࠩࡡࠬࡡࡪࠫ࠻࡞ࡧ࠯࠿ࡢࡤࠬ࡞࠱ࡠࡩ࠱ࠩࠩࠢࡗ࠾ࡡࡪࠫࠪࠩᆺ"),Z8rQtIjXYHz6d,DyVGS3dX0ZxR.DOTALL)
			if D4J0moOTurANclgW:
				Z8rQtIjXYHz6d = Z8rQtIjXYHz6d.replace(D4J0moOTurANclgW[o4bNzIQGYj8En][CH7RKuDVzN9f06q8MtXPhlvIxakEWg],HQmDERMFjx)
				CzWgM3fBetXS6ADvGs9xN54 = D4J0moOTurANclgW[o4bNzIQGYj8En][o4bNzIQGYj8En]
		if CzWgM3fBetXS6ADvGs9xN54: Z8rQtIjXYHz6d = Z8rQtIjXYHz6d.replace(CzWgM3fBetXS6ADvGs9xN54,ao3Q5jP8H0sMxK2iUYwZGE+CzWgM3fBetXS6ADvGs9xN54+cjqzOQ5GXD4kR)
		vSgOyFqf5Ya6ZB.append(Z8rQtIjXYHz6d)
		if len(str(vSgOyFqf5Ya6ZB))>jL1E5AKfwBDv6xmeQtUXcJ3d(u"࠸࠴࠶࠶࠰Ꮭ"): break
	vSgOyFqf5Ya6ZB = reversed(vSgOyFqf5Ya6ZB)
	CCV7vi8Uaxkqf2nSdjNI = ti3SbXNV0aJ7n5Grc4OQY8Ll1s9.join(vSgOyFqf5Ya6ZB)
	LQf1jSRk4tA32a(pCTzbw4GyVJHjkcIMQ(u"ࠪࡰࡪ࡬ࡴࠨᆻ"),YJxaX0MQOHb8oyCBFdnIAe(u"ࠫวิัࠡลึ฻ึࠦำอๆࠣห้ษฮุษฤࠤํอไศีอาิอๅࠨᆼ"),CCV7vi8Uaxkqf2nSdjNI,EAVanJj1ers2GQud(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡴ࡯ࡤࡰࡱ࡬࡯࡯ࡶࡢࡰࡴࡴࡧࠨᆽ"))
	return
def TDLEguNK641i():
	tuc7A83whConkdvXKW0rmMs96 = open(kiLFva6gEu3pd0xPV,jL1E5AKfwBDv6xmeQtUXcJ3d(u"࠭ࡲࡣࠩᆾ")).read()
	if HH6mxXjgcrEN1aenMFWQkS: tuc7A83whConkdvXKW0rmMs96 = tuc7A83whConkdvXKW0rmMs96.decode(Zex6D4tJE52r)
	tuc7A83whConkdvXKW0rmMs96 = tuc7A83whConkdvXKW0rmMs96.replace(jL1E5AKfwBDv6xmeQtUXcJ3d(u"ࠧ࡝ࡶࠪᆿ"),ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"ࠨࠢࠣࠤࠥࠦࠠࠡࠢࠪᇀ"))
	GN8T3gF7SozjaZidm = DyVGS3dX0ZxR.findall(YJxaX0MQOHb8oyCBFdnIAe(u"ࠩࠫࡺࡡࡪ࠮ࠫࡁࠬ࡟ࡡࡴ࡜ࡳ࡟ࠪᇁ"),tuc7A83whConkdvXKW0rmMs96,DyVGS3dX0ZxR.DOTALL)
	for Z8rQtIjXYHz6d in GN8T3gF7SozjaZidm:
		tuc7A83whConkdvXKW0rmMs96 = tuc7A83whConkdvXKW0rmMs96.replace(Z8rQtIjXYHz6d,s7d549VgeP+Z8rQtIjXYHz6d+cjqzOQ5GXD4kR)
	ivtUDrV92ZjEWdHu(YJxaX0MQOHb8oyCBFdnIAe(u"ࠪห้ะฺ๋์ิหฯࠦวๅลั๎ึฯࠠโ์ࠣห้ฮัศ็ฯࠫᇂ"),tuc7A83whConkdvXKW0rmMs96)
	return
def XQwhItHv1dPuE6foNsC2Rn():
	rGIDET0OmyFiUL8q = nz8x32hX0qcjUPFZk5RdJsiwED(u"ࠫอ฿ึࠡษ็วืืวาࠢ฼่๎ࠦวๅำํ้ํะࠠไ๊้ฮึ๎ไࠡฬ๋ๅึࠦลๆๅส๊๏ฯࠠหไา๎๊่ࠦหลั๎ึࠦวๅใํำ๏๎้้ࠠำ๋ࠥอไฤิิหึࠦ็๋ࠢส่ศู็ๆ๋ࠢห้ษัใษ่ࠤ๊฿ࠠษ฻ูࠤํ้วๅฬส่๏࠭ᇃ")
	iCDE40qzXlhxrvf = A0aqj9uclgOtByJ6F4bz(u"๊ࠬสใัํ้ࠥอไโ์า๎ํࠦวิฬัำ๊ࠦวๅี๊้ࠥอไ๋็ํ๊ࠥ๎ไหลั๎ึํࠠศีอาิ๋ࠠศๆึ๋๊ࠦวๅ์ึหึࠦ࠮ࠡล่หࠥ฿ฯสࠢสื์๋ࠠๆฬอห้๐ษࠡใ๊ิ์ࠦสใ๊่ࠤอะอา์ๆࠤฬ๊แ๋ัํ์ࠥฮ่ใฬࠣห่ฮัࠡ็้ࠤํ่สࠡษ็ื์๋ࠠศๆ๋หาีࠠ࠯ࠢฦ้ฬࠦวๅี๊้ࠥอไฤ฻็ํࠥ๎วๅลึๅ้ࠦแ่๊ࠣ๎าืใࠡษ็ๅ๏ี๊้ࠢศ่๎ࠦวๅล่ห๊ࠦร้ࠢศ่๎ࠦวๅ๊ิหฦ่ࠦๅๅ้ࠤอ่แำหࠣ็อ๐ัสࠩᇄ")
	Q8QSUrGdpmul = KhUG1NV9bln5zXjptqFW6dgo(u"࠭รๆษࠣห้ษัใษ่ࠤๆํ๊ࠡฬึฮำีๅࠡๆ็ฮ็ี๊ๆ๋ࠢห้ะรฯ์ิࠤํ๊ใ็ࠢห้็ีวาࠢ฼ำิࠦวๅอ๋ห๋๐้ࠠษ็ำ็อฦใࠢ࠱ࠤ๊ัไศࠢิๆ๊ࠦ࠵࠵࠶ࠣฮ฾์๊ࠡ࠷ࠣำ็อฦใ๋ࠢࠤ࠹࠺ࠠฬษ้๎ฮࠦลๅ๋ࠣห้ษๅศ็ࠣวํࠦลๅ๋ࠣห้๎ัศรࠣฬาูศࠡษึฮำีวๆๅู่้ࠣ็ๆࠢส่๏๋๊็ࠢฦ์ูࠥ็ๆࠢส่๏ูวาࠩᇅ")
	wwpQTfixYD23X = rGIDET0OmyFiUL8q+ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"ࠧ࠻ࠢࠪᇆ")+iCDE40qzXlhxrvf+EAVanJj1ers2GQud(u"ࠨࠢ࠱ࠤࠬᇇ")+Q8QSUrGdpmul
	LQf1jSRk4tA32a(CDwSWB4v39N7(u"ࠩࡦࡩࡳࡺࡥࡳࠩᇈ"),OO2BXYhI8UPNq6L,wwpQTfixYD23X,HDpmv4UXzlf72SK9(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭ᇉ"))
	return
def NTkhJef1lWrZi4B6q9xIHavpnc(type,wwpQTfixYD23X,showDialogs=gyd2rf0UR5,url=HQmDERMFjx,Zj0LzdFcx6AeNwM=HQmDERMFjx,NN9niuC7RoqmhkL2=HQmDERMFjx,UUcSCOWTuGfN3kvgs=HQmDERMFjx):
	djUaLD37Ezv521N9JS8H4MFWT = gyd2rf0UR5
	if not Jzthpc2nj5.gYWMTQAJqayd9VOPKNf7c6pbtej4w5:
		if showDialogs:
			dbesqj31NM2ORUW8xcn6wLmg0TJ = (C3ZK1pu4rfmj8TsWUtBaM(u"ࠫฬ๊ำุำ࠽ࠫᇊ") in wwpQTfixYD23X and PPAUFrY8cduRT(u"ࠬอไๆๅส๊࠿࠭ᇋ") in wwpQTfixYD23X and ShnRVsifKtc60zqQ(u"࠭วๅ็็ๅ࠿࠭ᇌ") in wwpQTfixYD23X and cWbkR6iUZsnJQj14(u"ࠧศๆั฻ศ࠭ᇍ") in wwpQTfixYD23X and CDwSWB4v39N7(u"ࠨษ็ฺ้ีั࠻ࠩᇎ") in wwpQTfixYD23X)
			if not dbesqj31NM2ORUW8xcn6wLmg0TJ: djUaLD37Ezv521N9JS8H4MFWT = HUJZy0SrTbBYv1(OBsrtQo2pPlgURCxJYbj9iXMD(u"ࠩࡦࡩࡳࡺࡥࡳࠩᇏ"),HQmDERMFjx,HQmDERMFjx,KhUG1NV9bln5zXjptqFW6dgo(u"๋้ࠪࠦสาี็ࠤ์ึ็ࠡษ็ีุอไสࠢศ่๎ࠦวๅ็หี๊าࠧᇐ"),wwpQTfixYD23X.replace(A0aqj9uclgOtByJ6F4bz(u"ࠫࡡࡢ࡮ࠨᇑ"),ti3SbXNV0aJ7n5Grc4OQY8Ll1s9))
	elif showDialogs:
		wwpQTfixYD23X = HDpmv4UXzlf72SK9(u"ࠬࡢ࡜࡯ฬ่ࠤู๊อࠡษ็ีุอไส࡞࡟ࡲฯ๋ࠠๆีะࠤึูวๅห࡟ࡠࡳะๅࠡ็ึัࠥอไาีส่ฮࡢ࡜࡯ฬ่ࠤู๊อࠡษ็ีุอไส࡞࡟ࡲฯ๋ࠠๆีะࠤฬ๊ัิษ็อࠬᇒ")
		vmJ6IZ0xGChjuc7qioO = HUJZy0SrTbBYv1(knTyjJ0sGIzuwbxRae(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ᇓ"),HQmDERMFjx,HQmDERMFjx,pCTzbw4GyVJHjkcIMQ(u"ࠧห็ุ้ࠣำࠠาีส่ฯ้ࠧᇔ")+knTyjJ0sGIzuwbxRae(u"ࠨࠢࠣ࠵࠴࠻ࠧᇕ"),knTyjJ0sGIzuwbxRae(u"๊่ࠩࠥะั๋ัࠣษึูวๅࠢิืฬ๊ษࠡใสี฿ฯࠧᇖ"))
		jatQxepZ9wvmCFLksVz = HUJZy0SrTbBYv1(EAVanJj1ers2GQud(u"ࠪࡧࡪࡴࡴࡦࡴࠪᇗ"),HQmDERMFjx,HQmDERMFjx,mg3CbXMA2ouZzQDhRqB(u"ࠫฯ๋ࠠๆีะࠤึูวๅฬๆࠫᇘ")+U0VwOviFaYPz2QGs45mJhMXf7Zk(u"ࠬࠦࠠ࠳࠱࠸ࠫᇙ"),n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"࠭็ๅࠢอี๏ีࠠฦำึห้ࠦัิษ็อࠥ็วา฼ฬࠫᇚ"))
		wwgNCTcYfaXlIK56vo8Hx4ne7Z9 = HUJZy0SrTbBYv1(X2crmy67eZpkGTRd(u"ࠧࡤࡧࡱࡸࡪࡸࠧᇛ"),HQmDERMFjx,HQmDERMFjx,ShnRVsifKtc60zqQ(u"ࠨฬ่ࠤู๊อࠡำึห้ะใࠨᇜ")+mg3CbXMA2ouZzQDhRqB(u"ࠩࠣࠤ࠸࠵࠵ࠨᇝ"),KKi79PFqsYB0dWSRgaJ3DyE(u"๋้ࠪࠦสา์าࠤสืำศๆࠣีุอไสࠢไหึเษࠨᇞ"))
		zU4cKCdVyZfAHX6RxrT3oB = HUJZy0SrTbBYv1(nz8x32hX0qcjUPFZk5RdJsiwED(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫᇟ"),HQmDERMFjx,HQmDERMFjx,maUl7SPesynF1j(u"ࠬะๅࠡ็ึัࠥืำศๆอ็ࠬᇠ")+C3ZK1pu4rfmj8TsWUtBaM(u"࠭ࠠࠡ࠶࠲࠹ࠬᇡ"),owbMhINBQsmx70guApW(u"่ࠧๆࠣฮึ๐ฯࠡวิืฬ๊ࠠาีส่ฮࠦแศำ฽อࠬᇢ"))
		djUaLD37Ezv521N9JS8H4MFWT = HUJZy0SrTbBYv1(dBi72erQEtKDOwjNFaoAgSP(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨᇣ"),HQmDERMFjx,HQmDERMFjx,pCTzbw4GyVJHjkcIMQ(u"ࠩอ้๋ࠥำฮࠢิืฬ๊สไࠩᇤ")+maUl7SPesynF1j(u"ࠪࠤࠥ࠻࠯࠶ࠩᇥ"),ELfMeDTIFhJt685K(u"ࠫ์๊ࠠหำํำࠥหัิษ็ࠤึูวๅหࠣๅฬืฺสࠩᇦ"))
	QXcqfBzUWRdgrn7JSsTi1Po83C = aefuHsz19Dkv6gPMjchJIx(mic3MEN709xOkrjD5ZvbGIlX6)
	xRPZKb8SoG1Bqw = Tcf5Ppn9UajDbzyM(u"ࠬࡇࡖ࠻ࠢࠪᇧ")+QXcqfBzUWRdgrn7JSsTi1Po83C+dBi72erQEtKDOwjNFaoAgSP(u"࠭࠭ࠨᇨ")+type
	qGdrQouHXxIyRTDmEtesJ = gyd2rf0UR5 if YJxaX0MQOHb8oyCBFdnIAe(u"ࠧࡠࡒࡕࡓࡇࡒࡅࡎࡡࠪᇩ") in NN9niuC7RoqmhkL2 else mic3MEN709xOkrjD5ZvbGIlX6
	if not djUaLD37Ezv521N9JS8H4MFWT:
		if showDialogs: u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,KhUG1NV9bln5zXjptqFW6dgo(u"ࠨฬ่ࠤสฺ๊ศรࠣห้หัิษ็ࠤอ์วยࠢ฼่๎ࠦืๅสๆࠫᇪ"))
		return mic3MEN709xOkrjD5ZvbGIlX6
	WaZLC3zRDJ7mlU9od1IM2VxeHTcPpA = FpGenVlw4Tzxi2WY3JuXcb.getInfoLabel(pCTzbw4GyVJHjkcIMQ(u"ࠩࡖࡽࡸࡺࡥ࡮࠰ࡉࡶ࡮࡫࡮ࡥ࡮ࡼࡒࡦࡳࡥࠨᇫ"))
	wwpQTfixYD23X += ELfMeDTIFhJt685K(u"ࠪࠤࡡࡢ࡮࡝࡞ࡱࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࠤࡡࡢ࡮ࡂࡦࡧࡳࡳࠦࡖࡦࡴࡶ࡭ࡴࡴ࠺ࠡࠩᇬ")+sWordmy7qXJvLgOGTl+U0VwOviFaYPz2QGs45mJhMXf7Zk(u"ࠫࠥࡀ࡜࡝ࡰࠪᇭ")
	wwpQTfixYD23X += ELfMeDTIFhJt685K(u"ࠬࡋ࡭ࡢ࡫࡯ࠤࡘ࡫࡮ࡥࡧࡵ࠾ࠥ࠭ᇮ")+QXcqfBzUWRdgrn7JSsTi1Po83C+knTyjJ0sGIzuwbxRae(u"࠭ࠠ࠻࡞࡟ࡲࡐࡵࡤࡪ࡙ࠢࡩࡷࡹࡩࡰࡰ࠽ࠤࠬᇯ")+yyoUA4lLTYIrtX1EmdVBnjPRZv+ShnRVsifKtc60zqQ(u"ࠧࠡ࠼࡟ࡠࡳ࠭ᇰ")
	wwpQTfixYD23X += Tcf5Ppn9UajDbzyM(u"ࠨࡍࡲࡨ࡮ࠦࡎࡢ࡯ࡨ࠾ࠥ࠭ᇱ")+WaZLC3zRDJ7mlU9od1IM2VxeHTcPpA
	SJh2QFaGnBeEy = p7GqI5DJoB1vayChxg4Y()
	SJh2QFaGnBeEy = SJh2QFaGnBeEy.replace(ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"ࠩ࠯࠰ࠬᇲ"),C3ZK1pu4rfmj8TsWUtBaM(u"ࠪ࠰ࠬᇳ"))
	SJh2QFaGnBeEy = VVkOtyQLzxBr(SJh2QFaGnBeEy)
	if SJh2QFaGnBeEy: wwpQTfixYD23X += n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"ࠫࠥࡀ࡜࡝ࡰࡏࡳࡨࡧࡴࡪࡱࡱ࠾ࠥ࠭ᇴ")+SJh2QFaGnBeEy
	if url: wwpQTfixYD23X += YJxaX0MQOHb8oyCBFdnIAe(u"ࠬࠦ࠺࡝࡞ࡱ࡙ࡗࡒ࠺ࠡࠩᇵ")+url
	if Zj0LzdFcx6AeNwM: wwpQTfixYD23X += X2crmy67eZpkGTRd(u"࠭ࠠ࠻࡞࡟ࡲࡘࡵࡵࡳࡥࡨ࠾ࠥ࠭ᇶ")+Zj0LzdFcx6AeNwM
	wwpQTfixYD23X += owbMhINBQsmx70guApW(u"ࠧࠡ࠼࡟ࡠࡳ࠭ᇷ")
	if showDialogs: x8a2FGB1jAef94byI(owbMhINBQsmx70guApW(u"ࠨฮสี๏ࠦวๅวิืฬ๊ࠧᇸ"),pCTzbw4GyVJHjkcIMQ(u"ࠩส่ึาวยࠢส่ฬ์สูษิࠫᇹ"))
	if qGdrQouHXxIyRTDmEtesJ:
		if mg3CbXMA2ouZzQDhRqB(u"ࠪࡣࡕࡘࡏࡃࡎࡈࡑࡤࡕࡌࡅࡡࠪᇺ") in NN9niuC7RoqmhkL2: u6jMD7AKWpGP5RHUTmqs = XG79oE8lD1uZ24Mef
		else: u6jMD7AKWpGP5RHUTmqs = wK3146lA92ubXszFGL
		if not S9Y5kUoRga3EVN.path.exists(u6jMD7AKWpGP5RHUTmqs):
			u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,ELfMeDTIFhJt685K(u"ุࠫาไࠡษ็วำ฽วย๋ࠢห้อำหะาหฺ๊๋ࠦำ้ࠣํา่ะࠩᇻ"))
			return mic3MEN709xOkrjD5ZvbGIlX6
		vv8DyVrLOPAXFIMZ9h(RRWFdpe04EK1Qn,nz8x32hX0qcjUPFZk5RdJsiwED(u"ࠬ࠴࡜ࡵࡒࡵࡩࡵࡧࡲࡪࡰࡪࠤࡹࡵࠠࡴࡧࡱࡨࠥࡺࡨࡦࠢ࡯ࡳ࡬࡬ࡩ࡭ࡧࠪᇼ"))
		vSgOyFqf5Ya6ZB,oWRrAQ4PHUDuw76KsBZ2 = [],jL1E5AKfwBDv6xmeQtUXcJ3d(u"࠴Ꮮ")
		file = open(u6jMD7AKWpGP5RHUTmqs,jL1E5AKfwBDv6xmeQtUXcJ3d(u"࠭ࡲࡣࠩᇽ"))
		size,count = e6eB5OgKHw4kf1C73IJWNZqAPRbyn(u6jMD7AKWpGP5RHUTmqs)
		if size>mgLADoQ1pbtY(u"࠸࠶࠱࠱࠲࠳Ꮯ"): file.seek(-mgLADoQ1pbtY(u"࠸࠶࠱࠱࠲࠳Ꮯ"),S9Y5kUoRga3EVN.SEEK_END)
		data = file.read()
		file.close()
		data = data.decode(Zex6D4tJE52r)
		data = mmOtseXRQKN7gDTMBL4Gnl(data)
		Nb3rHkOs6yKCJAlSW5DPLTciBVq2 = data.splitlines()
		for Z8rQtIjXYHz6d in reversed(Nb3rHkOs6yKCJAlSW5DPLTciBVq2):
			AzKdQxpZGXng03 = BaHETJZDmy8F(Z8rQtIjXYHz6d)
			if AzKdQxpZGXng03: continue
			D4J0moOTurANclgW = DyVGS3dX0ZxR.findall(KKi79PFqsYB0dWSRgaJ3DyE(u"ࠧ࡟ࠪ࡟ࡨ࠰࠳ࠨ࡝ࡦ࠮࠱ࡡࡪࠫࠡ࡞ࡧ࠯࠿ࡢࡤࠬ࠼࡟ࡨ࠰ࡢ࠮࡝ࡦ࠮࠭࠮࠮ࠠࡕ࠼࡟ࡨ࠰࠯ࠧᇾ"),Z8rQtIjXYHz6d,DyVGS3dX0ZxR.DOTALL)
			if D4J0moOTurANclgW:
				Z8rQtIjXYHz6d = Z8rQtIjXYHz6d.replace(D4J0moOTurANclgW[o4bNzIQGYj8En][o4bNzIQGYj8En],D4J0moOTurANclgW[o4bNzIQGYj8En][CH7RKuDVzN9f06q8MtXPhlvIxakEWg]).replace(D4J0moOTurANclgW[o4bNzIQGYj8En][FFHRwuxQmbh8BaTqyX3],HQmDERMFjx)
			else:
				D4J0moOTurANclgW = DyVGS3dX0ZxR.findall(nz8x32hX0qcjUPFZk5RdJsiwED(u"ࠨࡠࠫࡠࡩ࠱࠺࡝ࡦ࠮࠾ࡡࡪࠫ࡝࠰࡟ࡨ࠰࠯ࠨࠡࡖ࠽ࡠࡩ࠱ࠩࠨᇿ"),Z8rQtIjXYHz6d,DyVGS3dX0ZxR.DOTALL)
				if D4J0moOTurANclgW: Z8rQtIjXYHz6d = Z8rQtIjXYHz6d.replace(D4J0moOTurANclgW[o4bNzIQGYj8En][CH7RKuDVzN9f06q8MtXPhlvIxakEWg],HQmDERMFjx)
			vSgOyFqf5Ya6ZB.append(Z8rQtIjXYHz6d)
			if len(str(vSgOyFqf5Ya6ZB))>SODvU3Ibq5VzC(u"࠸࠵࠲࠲࠳࠴Ꮰ"): break
		vSgOyFqf5Ya6ZB = reversed(vSgOyFqf5Ya6ZB)
		CCV7vi8Uaxkqf2nSdjNI = nz8x32hX0qcjUPFZk5RdJsiwED(u"ࠩ࡟ࡶࡡࡴࠧሀ").join(vSgOyFqf5Ya6ZB)
	elif UUcSCOWTuGfN3kvgs: CCV7vi8Uaxkqf2nSdjNI = UUcSCOWTuGfN3kvgs
	else: CCV7vi8Uaxkqf2nSdjNI = HQmDERMFjx
	url = Jzthpc2nj5.SITESURLS[cWbkR6iUZsnJQj14(u"ࠪࡔ࡞࡚ࡈࡐࡐࠪሁ")][FFHRwuxQmbh8BaTqyX3]
	QRw49Dc0SXgn6lzP5jFBe = {ShnRVsifKtc60zqQ(u"ࠫࡸࡻࡢ࡫ࡧࡦࡸࠬሂ"):xRPZKb8SoG1Bqw,mg3CbXMA2ouZzQDhRqB(u"ࠬࡳࡥࡴࡵࡤ࡫ࡪ࠭ሃ"):wwpQTfixYD23X,CDwSWB4v39N7(u"࠭࡬ࡰࡩࡩ࡭ࡱ࡫ࠧሄ"):CCV7vi8Uaxkqf2nSdjNI}
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(rwjfOIqQU3ANa0JlWXvCDbFk,PPAUFrY8cduRT(u"ࠧࡑࡑࡖࡘࠬህ"),url,QRw49Dc0SXgn6lzP5jFBe,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,cWbkR6iUZsnJQj14(u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕ࠰ࡗࡊࡔࡄࡠࡇࡐࡅࡎࡒ࠭࠲ࡵࡷࠫሆ"))
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	if pCTzbw4GyVJHjkcIMQ(u"ࠩࡶࡩࡳࡪ࡟ࡴࡷࡦࡧࡪ࡫ࡤࡦࡦࠪሇ") in CzNPJydxQLfw27tv4ZF8KORAbX5: HH2hLvGCD3zfk = gyd2rf0UR5
	else: HH2hLvGCD3zfk = mic3MEN709xOkrjD5ZvbGIlX6
	if showDialogs:
		if HH2hLvGCD3zfk:
			x8a2FGB1jAef94byI(YJxaX0MQOHb8oyCBFdnIAe(u"ࠪฮ๊ࠦวๅวิืฬ๊ࠠษ่ฯหา࠭ለ"),Tcf5Ppn9UajDbzyM(u"ࠫࡘࡻࡣࡤࡧࡶࡷࠬሉ"))
			u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,cWbkR6iUZsnJQj14(u"ࠬࡓࡥࡴࡵࡤ࡫ࡪࠦࡳࡦࡰࡷࠫሊ"),ShnRVsifKtc60zqQ(u"࠭สๆࠢศีุอไࠡษ็ีุอไสࠢห๊ัออࠨላ"))
		else:
			x8a2FGB1jAef94byI(HDpmv4UXzlf72SK9(u"ࠧๅๆฦืๆࠦแีๆࠣห้หัิษ็ࠫሌ"),maUl7SPesynF1j(u"ࠨࡈࡤ࡭ࡱࡻࡲࡦࠩል"))
			u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,A0aqj9uclgOtByJ6F4bz(u"ࠩั฻ศ่ࠦโึ็ࠤๆ๐ࠠฦำึห้ࠦวๅำึห้ฯࠧሎ"))
	return HH2hLvGCD3zfk
def HYLcwyik56E7Qmq1():
	rGIDET0OmyFiUL8q = knTyjJ0sGIzuwbxRae(u"ࠪࡈࡴࠦࡹࡰࡷࠣࡻࡦࡴࡴࠡࡶࡲࠤࡹࡸࡡ࡯ࡵ࡯ࡥࡹ࡫ࠠ࡮ࡧࡱࡹࠥ࡯ࡴࡦ࡯ࡶࠤࡹࡵࠠࡢࠢ࡯ࡥࡳ࡭ࡵࡢࡩࡨࠤࡴࡺࡨࡦࡴࠣࡸ࡭ࡧ࡮ࠡࡃࡵࡥࡧ࡯ࡣࠡ࠰࠱ࠤࡔࡸࠠࡺࡱࡸࠤࡼࡧ࡮ࡵࠢࡷࡳࠥࡹࡨࡰࡹࠣࡅࡷࡧࡢࡪࡥࠣࡰࡪࡺࡴࡦࡴࡶࠤࡦࡴࡤࠡࡶࡨࡼࡹࠦ࠿ࠢࠩሏ")
	iCDE40qzXlhxrvf = EF2tvxZHz5n4UruPhaViXKycI6SQR(u"ࠫ์๊ࠠหำํำࠥะัอ็ฬࠤ็๎วว็ࠣห้ฮั็ษ่ะࠥหไ๊ࠢ็฾ฮࠦรฯำ์ࠤ฿๐ัࠡษ็฽ึฮ๊สࠢ࠱࠲ࠥษๅࠡฬิ๎ิࠦลู้สีࠥอไฤฯิๅࠥ๎วๅๅอหอฯࠠศๆ฼ีอ๐ษࠡมࠤࠫሐ")
	choice = uumd4lZkWVE81cI7p0eXgtTQjxhHJ(KhUG1NV9bln5zXjptqFW6dgo(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬሑ"),Tcf5Ppn9UajDbzyM(u"࠭ฮา๊ฯࠤࡊࡾࡩࡵࠩሒ"),maUl7SPesynF1j(u"ࠧࡕࡴࡤࡲࡸࡲࡡࡵࡧࠣฮึาๅสࠩሓ"),jL1E5AKfwBDv6xmeQtUXcJ3d(u"ࠨ฻ิฬ๏ࠦࡁࡳࡣࡥ࡭ࡨ࠭ሔ"),OO2BXYhI8UPNq6L,rGIDET0OmyFiUL8q+jL1E5AKfwBDv6xmeQtUXcJ3d(u"ࠩ࡟ࡲࡡࡴࠧሕ")+iCDE40qzXlhxrvf)
	if choice in [-OBsrtQo2pPlgURCxJYbj9iXMD(u"࠱Ꮱ"),LHX65I9nkx0PstgcVY24uSi(u"࠱Ꮲ")]: return
	elif choice==LHX65I9nkx0PstgcVY24uSi(u"࠳Ꮳ"):
		import uuw5DA8isg
		uuw5DA8isg.DorUAZJS1jXVxLHad3yCe0()
		return
	O5Ii1apBMtrWnmhkvYd = gyd2rf0UR5
	while O5Ii1apBMtrWnmhkvYd:
		O5Ii1apBMtrWnmhkvYd = mic3MEN709xOkrjD5ZvbGIlX6
		message = HDpmv4UXzlf72SK9(u"ࠪษีอฺ่ࠠา็๋ࠥิไๆฬࠤๆ๐ࠠศๆฦัึ็ࠠศๆ฼ีอ๐ษࠡใสิ์ฮࠠฦๆ์ࠤࠧหูะษาหฯ่ࠦศฮ๊อ้่ࠥะ์ࠥࠤะ๋ࠠ฻์ิࠤฬ๊ฮุࠢศ่๎ࠦࠢࡂࡴ࡬ࡥࡱࠨࠠ࠯࠰ࠣษีอࠠๅ็ࠣฮัีࠠศๆั฻ࠥࠨࡁࡳ࡫ࡤࡰࠧࠦแ฻์ิࠤฬ๊ฬๅัࠣษ้๏ࠠฤ์ࠣะ้ีࠠฬษ้๎ࠥ็๊่ࠢส่ำ฽ࠠࠣࡃࡵ࡭ࡦࡲࠢࠡ࠰࠱ࠤะ๋ࠠษ฻า๋ฬฺ๋ࠦำࠣห้ิืࠡว็ํࠥࠨࡁࡳ࡫ࡤࡰࠧࠦ࡜࡯ࠢศิฬࠦไ้ฯฬࠤฬ๊ๅโษอ๎าࠦวๅ฻ิฬ๏ฯࠠๅษࠣฮ฽ํัࠡๆๆࠤ࠳࠴ࠠศา๊ฬࠥหไ๊ࠢࠥษ฾ีวะษอࠤํอฬ่หࠣ็ํี๊ࠣࠢ࠱࠲ࠥัๅࠡ฼ํีࠥหูะษาหฯࠦวๅ็๋ๆ฾ࠦวๅฮ฽ีฬ็๊ࠡ࡞ࡱࡠࡳࠦ็ๅࠢอี๏ีࠠศๆล๊ࠥ็สฮࠢࠥษ฾ีวะษอࠤํอฬ่หࠣ็ํี๊ࠣࠢยࠥࠬሖ")
		choice = uumd4lZkWVE81cI7p0eXgtTQjxhHJ(OBsrtQo2pPlgURCxJYbj9iXMD(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫሗ"),cWbkR6iUZsnJQj14(u"ࠬࡋࡸࡪࡶࠣาึ๎ฬࠨመ"),KhUG1NV9bln5zXjptqFW6dgo(u"࡙࠭ࡦࡵ๊ࠣ฾๋ࠧሙ"),mgLADoQ1pbtY(u"ࠧࡆࡰࡪࡰ࡮ࡹࡨࠡว้ะ้๐า๋ࠩሚ"),PPAUFrY8cduRT(u"ࠨ฻า้ࠥ฾็้ำࠣห้ษอาใࠣ์ฬ๊ใหษหอࠥอไฺำห๎ฮ࠭ማ"),message,profile=X2crmy67eZpkGTRd(u"ࠩࡦࡳࡳ࡬ࡩࡳ࡯ࡢࡱࡪࡪࡩࡶ࡯ࡩࡳࡳࡺࠧሜ"))
		if choice==EAVanJj1ers2GQud(u"࠵Ꮴ"):
			message = n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"ࠪࡍ࡫ࠦࡹࡰࡷࠣ࡬ࡦࡼࡥࠡࡲࡵࡳࡧࡲࡥ࡮ࠢࡺ࡭ࡹ࡮ࠠࡂࡴࡤࡦ࡮ࡩࠠ࡭ࡧࡷࡸࡪࡸࡳࠡࡶ࡫ࡩࡳࠦ࡯ࡱࡧࡱࠤࠧࡑ࡯ࡥ࡫ࠣࡍࡳࡺࡥࡳࡨࡤࡧࡪࠦࡓࡦࡶࡷ࡭ࡳ࡭ࡳࠣࠢࡤࡲࡩࠦࡣࡩࡣࡱ࡫ࡪࠦࡴࡩࡧࠣࡪࡴࡴࡴࠡࡶࡲࠤࠧࡇࡲࡪࡣ࡯ࠦࠥ࠴࠮ࠡࡋࡩࠤࡾࡵࡵࠡࡥࡤࡲࡡ࠭ࡴࠡࡨ࡬ࡲࡩࠦࠢࡂࡴ࡬ࡥࡱࠨࠠࡧࡱࡱࡸࠥࡺࡨࡦࡰࠣࡧ࡭ࡧ࡮ࡨࡧࠣࡸ࡭࡫ࠠࡴ࡭࡬ࡲࠥࡺ࡯ࠡࡣࡱࡽࠥࡵࡴࡩࡧࡵࠤࡸࡱࡩ࡯ࠢࡷ࡬ࡦࡺࠠࡩࡣࡹࡩࠥࡢࠢࡂࡴ࡬ࡥࡱࡢࠢࠡࡨࡲࡲࡹࠦ࠮࠯ࠢࡄࡲࡩࠦࡴࡩࡧࡱࠤࡨ࡮ࡡ࡯ࡩࡨࠤࡹ࡮ࡥࠡࡨࡲࡲࡹࠦࡴࡰࠢࠥࡅࡷ࡯ࡡ࡭ࠤࠣࡠࡳࠦࡉࡧࠢࡄࡶࡦࡨࡩࡤࠢࡎࡩࡾࡨ࡯ࡢࡴࡧࠤ࡮ࡹࠠ࡯ࡱࡷࠤࡦࡼࡡࡪ࡮ࡤࡦࡱ࡫ࠠ࠯࠰ࠣࡘ࡭࡫࡮ࠡࡱࡳࡩࡳࠦࠢࡌࡱࡧ࡭ࠥࡏ࡮ࡵࡧࡵࡪࡦࡩࡥࠡࡕࡨࡸࡹ࡯࡮ࡨࡵࠥࠤࡦࡴࡤࠡࡥ࡫ࡥࡳ࡭ࡥࠡࡶ࡫ࡩࠥࡸࡥࡨ࡫ࡲࡲࡦࡲࠠࡴࡧࡷࡸ࡮ࡴࡧࡴࠢ࡟ࡲࡡࡴࠠࡅࡱࠣࡽࡴࡻࠠࡸࡣࡱࡸࠥࡴ࡯ࡸࠢࡷࡳࠥࡵࡰࡦࡰࠣࡸ࡭࡫ࠠࠣࡍࡲࡨ࡮ࠦࡉ࡯ࡶࡨࡶ࡫ࡧࡣࡦࠢࡖࡩࡹࡺࡩ࡯ࡩࡶࠦࠥࡅࠡࠨም")
			choice = uumd4lZkWVE81cI7p0eXgtTQjxhHJ(LHX65I9nkx0PstgcVY24uSi(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫሞ"),YJxaX0MQOHb8oyCBFdnIAe(u"ࠬࡋࡸࡪࡶࠣาึ๎ฬࠨሟ"),YJxaX0MQOHb8oyCBFdnIAe(u"࡙࠭ࡦࡵ๊ࠣ฾๋ࠧሠ"),YJxaX0MQOHb8oyCBFdnIAe(u"ࠧࡂࡴࡤࡦ࡮ࡩฺࠠำห๎ࠬሡ"),jL1E5AKfwBDv6xmeQtUXcJ3d(u"ࠨࡏ࡬ࡷࡸ࡯࡮ࡨࠢࡄࡶࡦࡨࡩࡤࠢࡉࡳࡳࡺࠠࠧࠢࡗࡩࡽࡺࠧሢ"),message,profile=U0VwOviFaYPz2QGs45mJhMXf7Zk(u"ࠩࡦࡳࡳ࡬ࡩࡳ࡯ࡢࡱࡪࡪࡩࡶ࡯ࡩࡳࡳࡺࠧሣ"))
			if choice==SODvU3Ibq5VzC(u"࠶Ꮵ"): O5Ii1apBMtrWnmhkvYd = gyd2rf0UR5
		if choice==dBi72erQEtKDOwjNFaoAgSP(u"࠶Ꮶ"): o5oC3zxwQJfI()
	return
def AzLp2Vv6x0NFajQ45():
	u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,nz8x32hX0qcjUPFZk5RdJsiwED(u"ࠪ฾ฬ๊ศศࠢสุ่ฮศ้๋ࠡࠤ๊์ࠠศๆ่์็฿ࠠศๆฦู้๐ࠠศๆ่฾ี๐ࠠๅๆหี๋อๅอ๋่้ࠢะรไัࠣๆ๊ࠦศหึ฽๎้ࠦวๅำสฬ฼ࠦวๅาํࠤ้อ๋ࠠ฻่่ࠥัๅࠡไ่ࠤอหัิษ็ࠤฺ๊ใๅหࠣษ้๏ࠠศๆ่ฬึ๋ฬࠡ็้ࠤฬ๊โศศ่อࠥอไาศํื๏ฯࠠๅๆหี๋อๅอࠩሤ"))
	return
def BiYv2rGX01bfR():
	wwpQTfixYD23X = ELfMeDTIFhJt685K(u"ࠫ์ึวࠡษ็ฬึ์วๆฮ้ࠣำ฻ีࠡใๅ฻๊ࠥไ฻หࠣห้฿ัษ์ฬࠤํ๊ใ็๊ࠢิฬࠦไศࠢํ้๋฿้ࠠฮ๋ำ๋่ࠥศไ฼ࠤๆ๐็ศࠢฦๅ้อๅ๊่ࠡืู้ไศฬ้ࠣฯืฬๆหࠣวํࠦๅะส็ะฮࠦลๅ๋ࠣหฺ้๊สࠢส่฾ืศ๋หࠣ์ฬ๊้ࠡๆ฽หฯࠦวฯำ์ࠤํ๊วࠡ์๋ะิࠦำษส่้ࠣะใาษิࠫሥ")
	u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,wwpQTfixYD23X)
	return
def D4NA7WRd2i15uME9():
	wwpQTfixYD23X = maUl7SPesynF1j(u"ࠬอไา๊สฬ฼ࠦวๅสฺ๎หฯࠠๅษࠣ฽้อโสࠢ็๋ฬࠦศศๆหี๋อๅอ๋ࠢ฾ฬ๊ศศࠢสุ่ฮศ้๋ࠡࠤ๊์ࠠศๆ่์็฿ࠠศๆฦู้๐ࠠศๆ่฾ี๐ࠠๅๆหี๋อๅอࠩሦ")
	u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,wwpQTfixYD23X)
	return
def ERtWfKUOsiI0doTDavk3cAPjJbn():
	wwpQTfixYD23X = ELfMeDTIFhJt685K(u"࠭็๋ࠢึ๎ึ็ัศฬ่ࠣฬ๊ࠦิฬฺ๎฾ࠦวๅสิ๊ฬ๋ฬࠡษึฮำีวๆ้สࠤอูศษࠢๆ์๋ํวࠡ็ะ้๏ฯࠠๆ่ࠣห้๋ีะำࠣวํࠦศฮษฯอࠥหไ๊ࠢสุฯืวไࠢิื๊๐ࠠฤ๊ࠣะิ๐ฯสࠢฦ์๊ࠥวࠡ์฼ีๆํวࠡษ็ฬึ์วๆฮࠪሧ")
	u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,EAVanJj1ers2GQud(u"ࠧิ์ิๅึอสࠡีํสฮࠦร้่ࠢะ์๎ไสࠩረ"),wwpQTfixYD23X)
	return
def hqyFDZdGw6PBzE75nvsI():
	wwpQTfixYD23X = owbMhINBQsmx70guApW(u"ࠨษ็ื๏ืแาษอࠤฬู๊ศ็ฬࠤ์๐ࠠิ์ิๅึอสࠡะสีั๐ษ๊ࠡ฽๎ึࠦสศส฼อ๊ࠥไๆ๊ๅ฽ࠥอไฤื็๎ࠥ๎ฬๆ์฼ࠤฬ๊ๅ้ษๅ฽ࠥะำหะา้์อ้ࠠ฻สำฮࠦสไ๊้ࠤ๊าว็์ฬࠤํ๋ิศๅ็๋ฬࠦใฬ์ิอ๊ࠥว็ࠢส่ๆ๐ฯ๋๊๊หฯࠦแ๋้สࠤส๋วࠡสฺ๎หฯࠠฤ๊้๊ࠣ์ฺ่หࠣวํࠦๅฮา๋ๅฮࠦร้ࠢไ๎์อࠠๆึๆ่ฮࠦอใ๊ๅࠤฬ๊ๅๅๅํอࡡࡴ࡜࡯࡞ࡱหู้๊าใิหฯࠦวๅะสูฮࠦ็๋ࠢึ๎ึ็ัศฬࠣฮฬฮูสࠢ็่๊๎โฺࠢส่ศ฻ไุ๋๋้ࠢะฮะ็ฬࠤๆ๐ࠠๆ๊สๆ฾ࠦโๅ์็อࠥาฯศ๋ࠢ฽ฬีษࠡฬๆ์๋ࠦๅะใ๋฽ฮࠦวๅลฯีࠥษ่ࠡ์่่่ํวࠡษ็้ํู่ࠡษ็วฺ๊๊๊ࠡ็๋ีอࠠโ้ํࠤั๐ฯส้ࠢือ๐ว๊ࠡึี๏฿ษุ๊่ࠡฬ้ไ่ษࠣๆ้๐ไสࠢฯำฬ࠭ሩ")
	LQf1jSRk4tA32a(cWbkR6iUZsnJQj14(u"ࠩࡦࡩࡳࡺࡥࡳࠩሪ"),OO2BXYhI8UPNq6L,wwpQTfixYD23X,mg3CbXMA2ouZzQDhRqB(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭ራ"))
	return
def benVLch05zRtPUX4FyISxKJN():
	rGIDET0OmyFiUL8q = jL1E5AKfwBDv6xmeQtUXcJ3d(u"ࠫฬฮสฺัࠣ฽๋ࠦๅๅใสฮࠥอไะไฬࠤฬู๊ศๆํอࠬሬ")
	iCDE40qzXlhxrvf = dBi72erQEtKDOwjNFaoAgSP(u"ࠬอศห฻าࠤ฾์ࠠๆๆไหฯࠦรๅࠢࡰ࠷ࡺ࠾ࠧር")
	Q8QSUrGdpmul = SODvU3Ibq5VzC(u"࠭วษฬ฼ำࠥ฿ๆࠡ็็ๅฬะࠠศๆอั๊๐ไ๊ࠡส่ิอ่็ๆ๋ำࠥࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧሮ")
	u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,rGIDET0OmyFiUL8q,iCDE40qzXlhxrvf,Q8QSUrGdpmul)
	return
def uELMyWtoGOCRz9A0b6Sam():
	iCDE40qzXlhxrvf = JJA7fypmZFVlazvNI(u"ࠧศๆๆหูࠦ็้่ࠢาื์ࠠๆฦๅฮ๊ࠥไๆ฻็์๊อสࠡ์ึฮำีๅ่ࠢส่อืๆศ็ฯࠤ้ิา็ุࠢๅาอสࠡษ็ษ๋ะั็์อࠤํื่ศสฺࠤฬ๊แ๋ัํ์์อสࠡๆ็์ฺ๎ไࠡว็๎์อࠠษีิ฽ฮ่ࠦษั๋๊ࠥหๆหำ้๎ฯ่ࠦศๆหี๋อๅอࠢํุ้ำ็ศࠢอ่็อฦ๋ษࠣฬ฾ีࠠศ่อ๋ฬวฺࠠ็ิ๋ฬ่ࠦฤ์ูหࠥ฿ๆะࠢอัิ๐หࠡษ็ฬึ์วๆฮࠣ࠲ࠥ๎็ัษࠣห้ฮั็ษ่ะࠥ๐ำหะาู้ࠥศฺหࠣว๋๎วฺࠢ็฽๊ืࠠศๆๆหูࠦ࠺ࠨሯ")
	iCDE40qzXlhxrvf += A0aqj9uclgOtByJ6F4bz(u"ࠨ࡞ࡱࡠࡳ࠭ሰ") + YJxaX0MQOHb8oyCBFdnIAe(u"ࠩ࠴࠲ࠥัวษฬ่้ࠣ฻แฮษอࠤฬ๊ส๋่ࠢ฽ึ๎แࠡล้๋ฬࠦไศࠢอฮ฿๐ั่๊ࠡหห๐ว๊่ࠡำฯํࠠࠨሱ") + str(h8CF5iEB9RXNf0G/YJxaX0MQOHb8oyCBFdnIAe(u"࠼࠰Ꮷ")/YJxaX0MQOHb8oyCBFdnIAe(u"࠼࠰Ꮷ")/mg3CbXMA2ouZzQDhRqB(u"࠲࠵Ꮸ")/OzU6t0qcH7MQabeBYK8vgoG(u"࠴࠲Ꮹ")) + CDwSWB4v39N7(u"ࠪࠤูํัࠨሲ")
	iCDE40qzXlhxrvf += ti3SbXNV0aJ7n5Grc4OQY8Ll1s9 + mg3CbXMA2ouZzQDhRqB(u"ࠫ࠷࠴ࠠอัสࠤ฼๎๊ๅࠢส่๊ี้ࠡๆ็ูๆำวหࠢส่๊็ัุ้ࠣว๋ํวࠡๆสࠤฯะฺ๋ำࠣ์๊ีส่ࠢࠪሳ") + str(ppxzXEh5md4Dwota3gBQFc/cWbkR6iUZsnJQj14(u"࠸࠳Ꮺ")/cWbkR6iUZsnJQj14(u"࠸࠳Ꮺ")/HDpmv4UXzlf72SK9(u"࠵࠸Ꮻ")) + mg3CbXMA2ouZzQDhRqB(u"๊้ࠬࠦ็ࠪሴ")
	iCDE40qzXlhxrvf += ti3SbXNV0aJ7n5Grc4OQY8Ll1s9 + mg3CbXMA2ouZzQDhRqB(u"࠭࠳࠯ฺࠢ์๏๊ࠠศๆ่ำ๎ࠦไๅืไัฬะࠠศๆอ๎ࠥ์วะำสࠤฯะฺ๋ำࠣ์๊ีส่ࠢࠪስ") + str(H5x4Z2qPwR8vXM/PPAUFrY8cduRT(u"࠺࠵Ꮼ")/PPAUFrY8cduRT(u"࠺࠵Ꮼ")/LHX65I9nkx0PstgcVY24uSi(u"࠷࠺Ꮽ")) + YJxaX0MQOHb8oyCBFdnIAe(u"ࠧࠡ์๋้ࠬሶ")
	iCDE40qzXlhxrvf += ti3SbXNV0aJ7n5Grc4OQY8Ll1s9 + mg3CbXMA2ouZzQDhRqB(u"ࠨ࠶࠱ࠤ๊ะ่ิูࠣห้๋ฯ๊ࠢ็ฺ่็อศฬࠣห้ะ๊ࠡไาࠤฯะฺ๋ำࠣ์๊ีส่ࠢࠪሷ") + str(j9uzmBeEyK8/X2crmy67eZpkGTRd(u"࠼࠰Ꮾ")/X2crmy67eZpkGTRd(u"࠼࠰Ꮾ")) + U0VwOviFaYPz2QGs45mJhMXf7Zk(u"ࠩࠣืฬ฿ษࠨሸ")
	iCDE40qzXlhxrvf += ti3SbXNV0aJ7n5Grc4OQY8Ll1s9 + EF2tvxZHz5n4UruPhaViXKycI6SQR(u"ࠪ࠹࠳ࠦโึ์ิࠤฬ๊ๅะ๋่้ࠣ฻แฮษอࠤฬ๊ส๋ࠢอฮ฿๐ัࠡัสส๊อ้ࠠ็าฮ์ࠦࠧሹ") + str(LLwINhcX2RHSWqpmEnz/owbMhINBQsmx70guApW(u"࠶࠱Ꮿ")/owbMhINBQsmx70guApW(u"࠶࠱Ꮿ")) + LHX65I9nkx0PstgcVY24uSi(u"ูࠫࠥวฺหࠪሺ")
	iCDE40qzXlhxrvf += ti3SbXNV0aJ7n5Grc4OQY8Ll1s9 + ShnRVsifKtc60zqQ(u"ࠬ࠼࠮ࠡฮาห่ࠥี๋ำࠣห้๋ฯ๊ࠢ็ฺ่็อศฬࠣห้ะ๊ࠡฬอ฾๏ืࠠไอํีฬ่ࠦๆัอ๋ࠥ࠭ሻ") + str(SwvFqCI7sc6bTAoeZY/U0VwOviFaYPz2QGs45mJhMXf7Zk(u"࠷࠲Ᏸ")) + knTyjJ0sGIzuwbxRae(u"࠭ࠠะไํๆฮ࠭ሼ")
	iCDE40qzXlhxrvf += ti3SbXNV0aJ7n5Grc4OQY8Ll1s9 + X2crmy67eZpkGTRd(u"ࠧ࠸࠰ࠣฬิ๎ๆࠡๅสุ๊ࠥไึใะหฯࠦวๅฬํࠤฯะฺ๋ำࠣฬุืูส๋้ࠢิะ็ࠡࠩሽ") + str(rwjfOIqQU3ANa0JlWXvCDbFk) + owbMhINBQsmx70guApW(u"ࠨࠢาๆ๏่ษࠨሾ")
	iCDE40qzXlhxrvf += U0VwOviFaYPz2QGs45mJhMXf7Zk(u"ࠩ࡟ࡲࡡࡴࠧሿ") + YJxaX0MQOHb8oyCBFdnIAe(u"้ࠪะ๊ว࠻ุࠢๅาอสࠡไ๋หห๋ࠠศๆฦๅ้อๅ๊ࠡสู่๊ไิๆสฮࠥ๎วๅฯ็ๆฬะฺࠠ็ิ๋ฬࠦࠧቀ") + str(j9uzmBeEyK8/A0aqj9uclgOtByJ6F4bz(u"࠸࠳Ᏹ")/A0aqj9uclgOtByJ6F4bz(u"࠸࠳Ᏹ")) + JJA7fypmZFVlazvNI(u"ูࠫࠥวฺหࠣ࠲ࠥษๅศࠢๅ์ฬฬๅࠡล้์ฬ฿ࠠศๆไ๎ิ๐่่ษอࠤๆ฿ๅา้สࠤࠬቁ") + str(H5x4Z2qPwR8vXM/A0aqj9uclgOtByJ6F4bz(u"࠸࠳Ᏹ")/A0aqj9uclgOtByJ6F4bz(u"࠸࠳Ᏹ")/ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"࠵࠸Ᏺ")) + maUl7SPesynF1j(u"ࠬࠦร๋ษ่ࠤ࠳ࠦรๆษ้้ࠣ็วหࠢส่ๆ๐ฯ๋๊ࠣๅ฾๋ั่ษࠣࠫቂ") + str(LLwINhcX2RHSWqpmEnz/A0aqj9uclgOtByJ6F4bz(u"࠸࠳Ᏹ")/A0aqj9uclgOtByJ6F4bz(u"࠸࠳Ᏹ")) + knTyjJ0sGIzuwbxRae(u"࠭ࠠิษ฼อࠥ็โุࠢ࠱ࠤศ๋วࠡใะูࠥืโๆࠢส่ส฻ฯศำࠣๅ฾๋ั่ࠢࠪቃ") + str(SwvFqCI7sc6bTAoeZY/A0aqj9uclgOtByJ6F4bz(u"࠸࠳Ᏹ")) + A0aqj9uclgOtByJ6F4bz(u"ࠧࠡัๅ๎็ฯࠠ࠯ࠢฦ้ฬࠦแฮืࠣหูะัศๅࠣไࡎࡖࡔࡗࠢไ฽๊ื็ࠡࠩቄ") + str(rwjfOIqQU3ANa0JlWXvCDbFk) + OzU6t0qcH7MQabeBYK8vgoG(u"ࠨࠢาๆ๏่ษࠨቅ")
	LQf1jSRk4tA32a(ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"ࠩࡵ࡭࡬࡮ࡴࠨቆ"),U0VwOviFaYPz2QGs45mJhMXf7Zk(u"้ࠪฬࠦ็้ࠢส่่อิࠡษ็ุ้ะฮะ็ࠣๅ๏ࠦวๅสิ๊ฬ๋ฬࠨቇ"),iCDE40qzXlhxrvf,owbMhINBQsmx70guApW(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧቈ"))
	return
def j8smWnw9bv():
	wwpQTfixYD23X = nz8x32hX0qcjUPFZk5RdJsiwED(u"ࠬอไโษุ่ฮࠦสฺ่ํࠤ๊าไะࠢห๊ๆูࠠศี่๋ࠥอไฤื็๎ࠥ๎วๅ่ๅ฻ฮࠦสฺ่ํࠤศ์ࠠศๆสื๊ࠦวๅลุ่๏ࠦสๆࠢอ฽ิ๐ไ่๋ࠢๅฬ฻ไส๋๊ࠢ็฽ษࠡฬ฼๊๎ࠦๅอๆาࠤํะๅࠡฬ฼ำ๏๊ࠠศี่๋ࠥ๎ศะ๊้ࠤ฾๊วๆหࠣฮ฾์๊ࠡ็็ๅࠥฮๆโีࠣหุ๋็ࠡษ็วฺ๊๊ࠨ቉")
	u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,wwpQTfixYD23X)
	return
def P8GlRHJDe0W():
	wwpQTfixYD23X = JJA7fypmZFVlazvNI(u"࠭ลัษࠣ์ฬา็หๅู้้ࠣไสࠢไ๎ࠥอไีสๆอࠥ๎สๆࠢะ่์อࠠ࠯࠰࠱ࠤศ๎ࠠศ่ๆࠤฯ฾ๆࠡล้ࠤฬ๊ๅ้ไ฼ࠤฬ๊รึๆํࠤ่อๆࠡใํ๋๋ࠥิไๆฬࠤ๊สโห้ࠣ์ฯ๋ࠠฮๆ๊หࠥ࠴࠮࠯ࠢไษี์ࠠอำหࠤู๊อࠡๅสุࠥอไษำ้ห๊าࠠๅๅํࠤ๏่่ๆࠢส่อืๆศ็ฯࠤอ฽ไษࠢสฺ่็อสࠢสฺ่ำ๊ฮหࠣ์ฯิา๋่๊หࠥฮฯๅษ้๋ࠣࠦวๅืไัฮࠦวๅไา๎๊ฯࠧቊ")
	u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,wwpQTfixYD23X)
	return
def w0BCQ1he5Hk6SrKuYTM7VxGRj():
	wwpQTfixYD23X = C3ZK1pu4rfmj8TsWUtBaM(u"ࠧศๆ฽ี฻ࠦๅ็ࠢื๋ฬีษࠡษ็ฮู็๊า๊ࠢ์ࠥ฼ๅศู่ࠣาฯ้ࠠีิ๎ฮࠦวๅ็฼่ํ๋วหࠢส่๊ะศศั็อࠥฮ๊็ࠢส่อืๆศ็ฯࠤํอไๆ๊ๅ฽ࠥอไๆึไีࠥ๎็ัษࠣห้฼ๅศ่ࠣ฾๏ืࠠๆู็์อ่ࠦๅษࠣัฬาษࠡๆ๊ࠤ฾์ฯࠡษ็หฯ฻วๅࠢส์ࠥอไาสฺࠤ๊฿ࠠๆ๊สๆ฾ࠦวๅใํำ๏๎็ศฬࠣห้๋ิโำฬࠫቋ")
	u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,wwpQTfixYD23X)
	return
def B2g1P7vj59():
	u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,mg3CbXMA2ouZzQDhRqB(u"ࠨๆๆ๎ࠥ๐ูๆๆ๋ࠣีอࠠศๆ้์฾ࠦๅ็ࠢส่ๆ๐ฯ๋๊๊หฯࠦ࡜࡯ࠢํะอࠦสโ฻ํ่ࠥหึศใฬࠤฬูๅ่ษࠣࡠࡳࠦࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠭ቌ"))
	ssb9ApI7G2wYURJ8mfhO(OzU6t0qcH7MQabeBYK8vgoG(u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡢࡦࡤࡴࡹ࡯ࡶࡦࠩቍ"),gyd2rf0UR5)
	return
def R6lG25qB3TjZz():
	wwpQTfixYD23X  = LHX65I9nkx0PstgcVY24uSi(u"้ࠪษิัศࠢๅห๊ะࠠษ฻ูࠤูืใศฬࠣห้หๆหำ้ฮࠥอไะ๊็๎ࠥฮ่ื฻ࠣ฽ฬฬโุࠡาࠤฬ๊ศาษ่ะ๋ࠥหๅࠢๆ์ิ๐ࠠๅฬึ้าࠦแใู่ࠣอ฿ึࠡ็ึฮำีๅ๋ࠢส่๊ะีโฯࠣฬฬ๊ฯฯ๊็ࠤ้๋่ศไ฼ࠤฬ๊แ๋ัํ์ࠬ቎")
	wwpQTfixYD23X += OBsrtQo2pPlgURCxJYbj9iXMD(u"ࠫࠥ๎ๆห์ฯอ๊ࠥ็ัษࠣห้฿ววไࠣๅฬ์็ࠡฬๅี๏ฮวࠡฮ่๎฾ࠦๅิฬัำ๊๐ࠠษำ้ห๊าࠠไ๊า๎๊ࠥวࠡ์ึฮ฼๐ู้่ࠣห้ีฮ้ๆ่ࠣัฺ๋๊่ࠢ์ฬู่ࠡษ็ฬึ์วๆฮࠣัฯ๏ࠠๆ฻ࠣหุะฮะษ่ࠫ቏")
	wwpQTfixYD23X += ti3SbXNV0aJ7n5Grc4OQY8Ll1s9+ao3Q5jP8H0sMxK2iUYwZGE+Tcf5Ppn9UajDbzyM(u"ࠬๆࠠࠡࡘࡓࡒࠥࠦร้ࠢࠣࡔࡷࡵࡸࡺࠢࠣวํࠦࠠࡅࡐࡖࠤࠥษ่ࠡลํࠤา๊ࠠษีํ฻ࠥศฮาࠩቐ")+cjqzOQ5GXD4kR+ti3SbXNV0aJ7n5Grc4OQY8Ll1s9
	wwpQTfixYD23X += ShnRVsifKtc60zqQ(u"࠭࡜࡯ๆส๊ࠥํะศࠢ็๊ࠥ๐อๅࠢสฺ่๊ใๅหࠣ์ส์ๅศࠢไๆ฼ࠦำ๋ไ๋้ࠥฮลึๆสัࠥฮูืࠢส่๊๎วใ฻ࠣ์ส฿วให้ࠣํอโฺࠢสาึ๏ࠠไษ้ฮࠥะูๆๆࠣืฬฮโศࠢหำํ์ࠠๆึส็้࠭ቑ")
	LQf1jSRk4tA32a(ShnRVsifKtc60zqQ(u"ࠧࡳ࡫ࡪ࡬ࡹ࠭ቒ"),OO2BXYhI8UPNq6L,wwpQTfixYD23X,ELfMeDTIFhJt685K(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫቓ"))
	wwpQTfixYD23X = maUl7SPesynF1j(u"ࠩส่๊๎วใ฻ࠣห้ะ๊ࠡฬฦฯึะࠠษษ็฽ฬฬโࠡ฻้ำࠥฮูืࠢส่๋อำ้ࠡํ࠾ࠬቔ")
	wwpQTfixYD23X += ti3SbXNV0aJ7n5Grc4OQY8Ll1s9+ao3Q5jP8H0sMxK2iUYwZGE+knTyjJ0sGIzuwbxRae(u"ࠪࡥࡰࡵࡡ࡮ࠢࠣࡩ࡬ࡿࡢࡦࡵࡷࠤࠥ࡫ࡧࡺࡤࡨࡷࡹࡼࡩࡱࠢࠣࡱࡴࡼࡩࡻ࡮ࡤࡲࡩࠦࠠࡴࡧࡵ࡭ࡪࡹ࠴ࡸࡣࡷࡧ࡭ࠦࠠࡴࡪࡤ࡬࡮ࡪ࠴ࡶࠩቕ")+cjqzOQ5GXD4kR
	wwpQTfixYD23X += HDpmv4UXzlf72SK9(u"ࠫࡡࡴ࡜࡯ࠩቖ")+EF2tvxZHz5n4UruPhaViXKycI6SQR(u"ࠬอไะ๊็ࠤฬ๊ส๋ࠢอวะืสࠡสส่฾อฦใࠢ฼๊ิࠦศฺุࠣห้์วิ๊ࠢ๎࠿࠭቗")
	wwpQTfixYD23X += ti3SbXNV0aJ7n5Grc4OQY8Ll1s9+ao3Q5jP8H0sMxK2iUYwZGE+A0aqj9uclgOtByJ6F4bz(u"࠭ๅึำࠣࠤฬ๊ใ้์อࠤࠥษๅ๋ำๆหࠥࠦใ็ัสࠤࠥ็ั็ีสࠤࠥอไ๋๊้ห๋ࠦࠠษำํ฻ฬ์๊ศࠢส่ส๋วาษอࠤศ๊ๅศ่ํหࠥื่ิ์สࠤฬ๊๊ศสส๊ࠥอไิ฻๋ำ๏ฯࠠา๊่ห๋๐ว้๋่๋ࠡีวࠨቘ")+cjqzOQ5GXD4kR
	wwpQTfixYD23X += C3ZK1pu4rfmj8TsWUtBaM(u"ࠧ࡝ࡰ࡟ࡲࠬ቙")+EF2tvxZHz5n4UruPhaViXKycI6SQR(u"ࠨษ็้อืๅอ๋ࠢะิࠦืา์ๅอ๊ࠥสอษ๋ึࠥอไฺษษๆࠥ๎ไไ่๊หࠥะอหษฯࠤัํฯࠡๅห๎ึ่ࠦศๆ่ฬึ๋ฬࠡ์฻๊ࠥอไๆึๆ่ฮࠦี฻์ิอࠥ๎ไศࠢอืฯำโࠡษ็ฮ฾ฮࠠโวำห๊ࠥฯ๋ๅู้้ࠣไสࠢหห้ีฮ้ๆ่ࠣอ฿ึࠡษ็้ํอโฺ๋ࠢว๏฼วࠡๆๆ๎ࠥ๐สืฯࠣัั๋ࠠศๆุ่่๊ษࠡࠩቚ")
	wwpQTfixYD23X += ao3Q5jP8H0sMxK2iUYwZGE+X2crmy67eZpkGTRd(u"ࠩสีุ๊ࠠาีส่ฮࠦๅลัหอࠥหไ๊ࠢส่๊ฮัๆฮࠣ์ฬ้สษࠢไ๎์อࠠศี่ࠤอ๊ฯไ๋ࠢวุ๋วยࠢส่๊๎วใ฻ࠣห้ะ๊ࠡๆสࠤฯูสุ์฼ࠤิิ่ๅ้สࠫቛ")+cjqzOQ5GXD4kR
	LQf1jSRk4tA32a(OzU6t0qcH7MQabeBYK8vgoG(u"ࠪࡶ࡮࡭ࡨࡵࠩቜ"),OO2BXYhI8UPNq6L,wwpQTfixYD23X,A0aqj9uclgOtByJ6F4bz(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧቝ"))
	return
def hZf3WMaRwONknQPsXD2zyKpEdi9gj():
	u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,mg3CbXMA2ouZzQDhRqB(u"ࠬัไศอࠣ฻ึ่ࠠๅๆอ์ฬ฻ไࠡ็฼ࠤฬ๊ๅษำ่ะࠬ቞"),OzU6t0qcH7MQabeBYK8vgoG(u"࠭ราี็ࠤึูวๅหࠣวํࠦๅีๅ็อ๋ࠥๆࠡไสส๊ฯࠠาีสส้ࠦ็ัษࠣห้ฮั็ษ่ะࡡࡴ࡜࡯ล๋ࠤออำหะาห๊ࠦวๅใํือ๎ใࠡลา๊ฬํ࡜࡯ࠩ቟")+ao3Q5jP8H0sMxK2iUYwZGE+JJA7fypmZFVlazvNI(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡧࡣࡦࡩࡧࡵ࡯࡬࠰ࡦࡳࡲ࠵ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷ࠷࠶࠱࠹ࠩበ")+cjqzOQ5GXD4kR+mgLADoQ1pbtY(u"ࠨ࡞ࡱࡠࡳษ่ࠡสสีุอไࠡษํ้๏๊ࠠศๆ์ࠤศีๆศ้ࠣࠤࡡࡴࠠࠨቡ")+ao3Q5jP8H0sMxK2iUYwZGE+owbMhINBQsmx70guApW(u"ࠩࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳ࠳࠲࠴࠼ࡅ࡭࡭ࡢ࡫࡯࠲ࡨࡵ࡭ࠨቢ")+cjqzOQ5GXD4kR)
	return
def xxOfZk9LhUAd3jzY6HEBW7JqR8(showDialogs=gyd2rf0UR5):
	if not showDialogs: showDialogs = gyd2rf0UR5
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(rwjfOIqQU3ANa0JlWXvCDbFk,KhUG1NV9bln5zXjptqFW6dgo(u"ࠪࡋࡊ࡚ࠧባ"),knTyjJ0sGIzuwbxRae(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫ࡸࡢ࡯ࡳࡰࡪ࠴ࡣࡰ࡯ࠪቤ"),HQmDERMFjx,HQmDERMFjx,mic3MEN709xOkrjD5ZvbGIlX6,HQmDERMFjx,EAVanJj1ers2GQud(u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙࠭ࡉࡖࡗࡔࡘࡥࡔࡆࡕࡗ࠱࠶ࡹࡴࠨብ"))
	if not vGXnw9VcUN.succeeded:
		TTfSRhYlHaXUuE1AvFQLkcW0oi = mic3MEN709xOkrjD5ZvbGIlX6
		eeC29yfH18kaWPEsqcMARVTiJ = rCt3zFWNQGA1hmbl(mic3MEN709xOkrjD5ZvbGIlX6)
		vv8DyVrLOPAXFIMZ9h(GmyBXr3kYHdlvJ,LLe5QGmjCZigv(HDLtdMAy7wPkl8aKC3O2)+nz8x32hX0qcjUPFZk5RdJsiwED(u"࠭ࠠࠡࠢࡋࡘ࡙ࡖࡓࠡࡈࡤ࡭ࡱ࡫ࡤࠡࠢࠣࡐࡦࡨࡥ࡭࠼࡞ࠫቦ")+eeC29yfH18kaWPEsqcMARVTiJ+SODvU3Ibq5VzC(u"ࠧ࡞ࠩቧ"))
		if showDialogs: u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,k4IUieraScH9DV1N7pJgQosYAx5l(u"ࠨใะูࠥอไศฬุห้ࠦวๅ็ืๅึࠦ࠮࠯࠰ู้้ࠣไสࠢ࠱࠲࠳ࠦวๅษอูฬ๊ࠠศๆุ่ๆืࠠࠩษ็ีอ฽ࠠศๆุ่ๆืࠩࠡๆสࠤ๏฿ๅๅࠢ฼๊ิฺ้ࠠๆ์ࠤ่๎ฯ๋ࠢ࠱࠲࠳ฺ่่ࠦา็้่ࠥะ์ࠣ฾๏ืࠠใษาีࠥ฿ไ๊ࠢสืฯิฯศ็ࠣห้๋่ศไ฼ࠤฬ๊ๅีใิอࠬቨ"))
	else:
		TTfSRhYlHaXUuE1AvFQLkcW0oi = gyd2rf0UR5
		if showDialogs: u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,CDwSWB4v39N7(u"ࠩฯ๎ิࠦฬะษࠣ࠲࠳࠴ࠠศๆสฮฺอไࠡษ็ู้็ัࠡࠪส่ึฮืࠡษ็ู้็ัࠪࠢํ฽ฺ๊๊่ࠠา็ࠥ๎วๅสิ๊ฬ๋ฬࠡไสำึูࠦๅ๋ࠣหุะฮะษ่ࠤฬ๊ๅ้ษๅ฽ࠥอไๆึไีฮ࠭ቩ"))
	if not TTfSRhYlHaXUuE1AvFQLkcW0oi and showDialogs: Rlxc528tTziyGnmwp1E()
	return TTfSRhYlHaXUuE1AvFQLkcW0oi
def Rlxc528tTziyGnmwp1E():
	u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,LHX65I9nkx0PstgcVY24uSi(u"ࠪฬ฾฼ࠠศๆ่์ฬู่ࠡฬะฮฬาࠠาสฺࠤฺ๊แา๋ࠢๆิ๊ࠦไ๊้ࠤัํวำๅࠣ฾๏ืࠠใษาีࠥ฿ไ๊ࠢส่ึฮืࠡษ็ู้็ัࠡล๋ࠤ์์วไุ่่๊ࠢษࠡใํࠤูํวะหࠣห้ะิโ์ิࠤฬ๊ฮศืฬࠤอ้่ะ์ࠣ฽๋ีใࠡ฻็้ฬࠦว็้ࠣฮ๊ࠦแฮืࠣห้ฮั็ษ่ะࠥ฿ไ๊ࠢๆ์ิ๐ࠠศๆศูิอัศฬࠣࡠࡳࠦ࠱࠸࠰࠹ࠤࠥࠬࠠࠡ࠳࠻࠲ࡠ࠶࠭࠺࡟ࠣࠤࠫࠦࠠ࠲࠻࠱࡟࠵࠳࠳࡞ࠩቪ"))
	SCkwQfWsTo2p1x7()
	return
def YYxk6FtA4PCMr5Zco18LfiwBa(NN9niuC7RoqmhkL2=HQmDERMFjx):
	qGdrQouHXxIyRTDmEtesJ = gyd2rf0UR5
	if CDwSWB4v39N7(u"ࠫࡤࡖࡒࡐࡄࡏࡉࡒࡥࠧቫ") not in NN9niuC7RoqmhkL2:
		qGdrQouHXxIyRTDmEtesJ = mic3MEN709xOkrjD5ZvbGIlX6
		Tk70cbAyLw = uumd4lZkWVE81cI7p0eXgtTQjxhHJ(X2crmy67eZpkGTRd(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬቬ"),EAVanJj1ers2GQud(u"࠭ฮา๊ฯࠫቭ"),KKi79PFqsYB0dWSRgaJ3DyE(u"ࠧฦำึห้ࠦๅีๅ็อࠬቮ"),maUl7SPesynF1j(u"ࠨวิืฬ๊ࠠาีส่ฮ࠭ቯ"),OO2BXYhI8UPNq6L,U0VwOviFaYPz2QGs45mJhMXf7Zk(u"๊่ࠩࠥะั๋ัࠣว๋ࠦสาี็ࠤึูวๅหࠣษ้๏ࠠศๆ่ฬึ๋ฬࠡ࠰࠱ࠤศ๋ࠠหำํำࠥษๆࠡฬิื้ࠦๅีๅ็อ๋่ࠥอ๊าอࠥ็๊ࠡษ็ฬึ์วๆฮࠣรࠬተ"))
		if Tk70cbAyLw in [-EAVanJj1ers2GQud(u"࠵Ᏻ"),dBi72erQEtKDOwjNFaoAgSP(u"࠵Ᏼ")]: return
		elif Tk70cbAyLw==SODvU3Ibq5VzC(u"࠷Ᏽ"):
			qGdrQouHXxIyRTDmEtesJ = gyd2rf0UR5
			NN9niuC7RoqmhkL2 = ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"ࠪࡣࡕࡘࡏࡃࡎࡈࡑࡤ࠭ቱ")
	if qGdrQouHXxIyRTDmEtesJ:
		if SODvU3Ibq5VzC(u"ࠫࡤࡖࡒࡐࡄࡏࡉࡒࡥࡏࡍࡆࡢࠫቲ") not in NN9niuC7RoqmhkL2:
			N7gs9UBCeDR3 = HUJZy0SrTbBYv1(KhUG1NV9bln5zXjptqFW6dgo(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬታ"),HQmDERMFjx,HQmDERMFjx,JJA7fypmZFVlazvNI(u"่࠭ื฻ࠣห้๋ิไๆฬࠤๆ๐ࠠศๆึะ้࠭ቴ"),U0VwOviFaYPz2QGs45mJhMXf7Zk(u"ࠧใส็ࠤสืำศๆࠣหู้ฬๅࠢ฼่๏้ࠠฤ่ࠣฮ่ืั้ࠡࠢๅุࠦวๅใ฼่ࠥอไั์ࠣว฾฽วไࠢสฺ่๊ใๅหࠣ࠲๊ࠥใ๋ࠢํฮ๊ࠦสิฮํ่ࠥํะ่ࠢสฺ่๊ใๅหࠣๅ๏ࠦำอๆࠣห้ษฮุษฤࠤํอไศีอาิอๅࠡ࠰ࠣ์อี่็๊ࠢิฬࠦวๅฬึะ๏๊ࠠิ๊ไࠤฯืำๅ่่ࠢๆࠦไศࠢไหหีษࠡ็้๋๊ࠥล็้่ࠣฬ๊ࠦฮฬ๋๎ࠥ฿ไ๊ࠢสฺ่๊ใๅหࠣห้ะ๊ࠡฬิ๎ิࠦว็ฬࠣห้หศๅษ฽ࠤ฾์็ศࠢ࠱ࠤ์๊ࠠใ็อࠤอะใาษิࠤฬ๊ๅีๅ็อࠥลࠧት"))
			if N7gs9UBCeDR3!=LHX65I9nkx0PstgcVY24uSi(u"࠱᏶"):
				u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,SODvU3Ibq5VzC(u"ࠨฬ่ࠤสฺ๊ศรࠣห้หัิษ็ࠫቶ"),OzU6t0qcH7MQabeBYK8vgoG(u"ࠩ็่ศูแࠡสา์๋ࠦสิฮํ่ࠥอไๆึๆ่ฮࠦแ๋ࠢึะ้ࠦวๅลั฻ฬว้ࠠษ็หุะฮะษ่ࠤๆอๆࠡษ็้อืๅอࠢ็หࠥ๐ำหูํ฽ู๋ࠥาใฬࠤฬ๊ๅีๅ็อࠥ๎ไศࠢะ่์อࠠๅษ้ࠤฬ๊ๅษำ่ะ๊ࠥวࠡ์฼่๊ࠦวๅ฼ํฬࠬቷ"))
				return
	u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,HDpmv4UXzlf72SK9(u"ࠪๅ๏ࠦวๅึสุฮࠦวๅไสำ๊ฯࠠฮษ๋่ࠥษๆࠡฬๆฮอࠦัิษ็อࠥหไ๊ࠢส่๊ฮัๆฮࠣ์ฬฺัฮࠢไ๎์อࠠศๆุ่่๊ษࠡล๋ࠤฬ๊ๅุ้๋฽ࠥ๎ลัษࠣวึีสࠡฮ๋หอࠦๅ็ࠢส่๊ฮัๆฮࠣๅสึๆࠡลๆฮอูࠦ็๊ส๊ࠥฮั๋ัๆࠤศ๊ลๅๅอีํ์๊ࠡษ็ษ๏๋๊ๅ๋ࠢฮี้ั๊ࠡ็หࠥะๆิ๋ࠣว๋ࠦวๅ็หี๊าࠠๅษࠣ๎฾๊ๅࠡษ็฾๏ฮࠧቸ"))
	wwpQTfixYD23X = q156m84QoYrn(header=ShnRVsifKtc60zqQ(u"ࠫ࡜ࡸࡩࡵࡧࠣࡥࠥࡳࡥࡴࡵࡤ࡫ࡪࠦࠠࠡษๆฮอࠦัิษ็อࠬቹ"),source=HDLtdMAy7wPkl8aKC3O2)
	if not wwpQTfixYD23X: return
	if qGdrQouHXxIyRTDmEtesJ: type = C3ZK1pu4rfmj8TsWUtBaM(u"ࠬࡖࡲࡰࡤ࡯ࡩࡲ࠭ቺ")
	else: type = SODvU3Ibq5VzC(u"࠭ࡍࡦࡵࡶࡥ࡬࡫ࠧቻ")
	HH2hLvGCD3zfk = NTkhJef1lWrZi4B6q9xIHavpnc(type,wwpQTfixYD23X,gyd2rf0UR5,HQmDERMFjx,C3ZK1pu4rfmj8TsWUtBaM(u"ࠧࡆࡏࡄࡍࡑ࠳ࡆࡓࡑࡐ࠱࡚࡙ࡅࡓࡕࠪቼ"),NN9niuC7RoqmhkL2)
	return
def NtK32m7q8wRZfohH():
	NN9niuC7RoqmhkL2 = C3ZK1pu4rfmj8TsWUtBaM(u"ࠨ้ำหࠥอไษำ้ห๊าࠠๅษࠣ๎ําฯࠡๆ๊ࠤศ๐ࠠิ์ิๅึ๊ࠦิฬู๎ๆࠦร๋่ࠢัฯ๎๊ศฬ࠱ࠤฬ๊ศา่ส้ั๊ࠦิฬัำ๊ࠦั้ษห฻ࠥ๎สื็ํ๊๊ࠥๅฮฬ๋๎ฬะࠠๆำไ์฾ฯฺࠠๆ์ࠤุ๐ัโำสฮࠥิวาฮํอ࠳ࠦวๅสิ๊ฬ๋ฬࠡ฼ํี๋ࠥำล๊็ࠤ฾์ࠠฤ์้ࠣาะ่๋ษอࠤฯ๋ࠠหฯ่๎้ํวࠡ฻็ํู๊ࠥาใิหฯ่ࠦๆ๊สๆ฾ࠦฮศำฯ๎ฮࠦࠢๆ๊สๆ฾ࠦืาใࠣฯฬ๊หࠣ࠰ࠣะ๊๐ูࠡษ็วุ๋วย๋ࠢห้๋วาๅสฮࠥ๎วๅื๋ีࠥ๎วๅ็ุ้ํืวห๊ࠢ๎ࠥิวึหࠣฬฬ฻อศส๊ห࠳ࠦวๅสิ๊ฬ๋ฬࠡๆสࠤ๏์ส่ๅࠣั็๎โࠡษ็฻อ฿้ࠠษ็ู๊ื้ࠠไส๊ํ์ࠠศๆฦ่ๆ๐ษࠡๆ็้้้๊สࠢส่ึ่ๅ๋หࠣࡈࡒࡉࡁࠡวำห้ࠥว็ࠢ็ำ๏้ࠠีๅ๋ํࠥิวึหࠣฬฬ๊ั้ษห฻ࠥ๎วๅฬูห๊๐ๆࠡษ็าฬืฬ๋หࠣๅฬ๊ัอษฤࠤฬ๊ส้ษุู่๋ࠥࠡวาหึฯ่ࠠา๊ࠤฬ๊ำ๋ำไีฬะ้ࠠษ็้ํอโฺࠢส่ำอัอ์ฬ࠲ࠥํะศࠢส่อืๆศ็ฯࠤ์๎ࠠษสึห฼ฯࠠๆฬุๅาࠦไๆ๊สๆ฾ࠦวๅ๊ํฬࠬች")
	LQf1jSRk4tA32a(cWbkR6iUZsnJQj14(u"ࠩࡵ࡭࡬࡮ࡴࠨቾ"),ELfMeDTIFhJt685K(u"ࠪั็๎โࠡษ็฻อ฿้ࠠษ็ู๊ื้ࠠไส๊ํ์ࠠศๆฦ่ๆ๐ษࠡๆ็้้้๊สࠢส่ึ่ๅ๋หࠪቿ"),NN9niuC7RoqmhkL2,dBi72erQEtKDOwjNFaoAgSP(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧኀ"))
	NN9niuC7RoqmhkL2 = HDpmv4UXzlf72SK9(u"࡚ࠬࡨࡪࡵࠣࡴࡷࡵࡧࡳࡣࡰࠤࡩࡵࡥࡴࠢࡱࡳࡹࠦࡨࡰࡵࡷࠤࡦࡴࡹࠡࡥࡲࡲࡹ࡫࡮ࡵࠢࡲࡲࠥࡧ࡮ࡺࠢࡶࡩࡷࡼࡥࡳ࠰ࠣࡍࡹࠦ࡯࡯࡮ࡼࠤࡺࡹࡥࡴࠢ࡯࡭ࡳࡱࡳࠡࡶࡲࠤࡪࡳࡢࡦࡦࡧࡩࡩࠦࡣࡰࡰࡷࡩࡳࡺࠠࡵࡪࡤࡸࠥࡽࡡࡴࠢࡸࡴࡱࡵࡡࡥࡧࡧࠤࡹࡵࠠࡱࡱࡳࡹࡱࡧࡲࠡࡱࡱࡰ࡮ࡴࡥࠡࡸ࡬ࡨࡪࡵࠠࡩࡱࡶࡸ࡮ࡴࡧࠡࡵ࡬ࡸࡪࡹ࠮ࠡࡃ࡯ࡰࠥࡺࡲࡢࡦࡨࡱࡦࡸ࡫ࡴ࠮ࠣࡺ࡮ࡪࡥࡰࡵ࠯ࠤࡹࡸࡡࡥࡧࠣࡲࡦࡳࡥࡴ࠮ࠣࡷࡪࡸࡶࡪࡥࡨࠤࡲࡧࡲ࡬ࡵ࠯ࠤࡨࡵࡰࡺࡴ࡬࡫࡭ࡺࡥࡥࠢࡺࡳࡷࡱࠬࠡ࡮ࡲ࡫ࡴࡹࠠࡳࡧࡩࡩࡷ࡫࡮ࡤࡧࡧࠤ࡭࡫ࡲࡦ࡫ࡱࠤࡧ࡫࡬ࡰࡰࡪࠤࡹࡵࠠࡵࡪࡨ࡭ࡷࠦࡲࡦࡵࡳࡩࡨࡺࡩࡷࡧࠣࡳࡼࡴࡥࡳࡵࠣ࠳ࠥࡩ࡯࡮ࡲࡤࡲ࡮࡫ࡳ࠯ࠢࡗ࡬ࡪࠦࡰࡳࡱࡪࡶࡦࡳࠠࡪࡵࠣࡲࡴࡺࠠࡳࡧࡶࡴࡴࡴࡳࡪࡤ࡯ࡩࠥ࡬࡯ࡳࠢࡺ࡬ࡦࡺࠠࡰࡶ࡫ࡩࡷࠦࡰࡦࡱࡳࡰࡪࠦࡵࡱ࡮ࡲࡥࡩࠦࡴࡰࠢ࠶ࡶࡩࠦࡰࡢࡴࡷࡽࠥࡹࡩࡵࡧࡶ࠲ࠥ࡝ࡥࠡࡷࡵ࡫ࡪࠦࡡ࡭࡮ࠣࡧࡴࡶࡹࡳ࡫ࡪ࡬ࡹࠦ࡯ࡸࡰࡨࡶࡸ࠲ࠠࡵࡱࠣࡶࡪࡩ࡯ࡨࡰ࡬ࡾࡪࠦࡴࡩࡣࡷࠤࡹ࡮ࡥࠡ࡮࡬ࡲࡰࡹࠠࡤࡱࡱࡸࡦ࡯࡮ࡦࡦࠣࡻ࡮ࡺࡨࡪࡰࠣࡸ࡭࡯ࡳࠡࡲࡵࡳ࡬ࡸࡡ࡮ࠢࡤࡶࡪࠦ࡬ࡰࡥࡤࡸࡪࡪࠠࡴࡱࡰࡩࡼ࡮ࡥࡳࡧࠣࡩࡱࡹࡥࠡࡱࡱࠤࡹ࡮ࡥࠡࡹࡨࡦࠥࡵࡲࠡࡸ࡬ࡨࡪࡵࠠࡦ࡯ࡥࡩࡩࡪࡥࡥࠢࡤࡶࡪࠦࡦࡳࡱࡰࠤࡴࡺࡨࡦࡴࠣࡺࡦࡸࡩࡰࡷࡶࠤࡸ࡯ࡴࡦࡵ࠱ࠤࡎ࡬ࠠࡺࡱࡸࠤ࡭ࡧࡶࡦࠢࡤࡲࡾࠦ࡬ࡦࡩࡤࡰࠥ࡯ࡳࡴࡷࡨࡷࠥࡶ࡬ࡦࡣࡶࡩࠥࡩ࡯࡯ࡶࡤࡧࡹࠦࡡࡱࡲࡵࡳࡵࡸࡩࡢࡶࡨࠤࡲ࡫ࡤࡪࡣࠣࡪ࡮ࡲࡥࠡࡱࡺࡲࡪࡸࡳࠡ࠱ࠣ࡬ࡴࡹࡴࡦࡴࡶ࠲࡚ࠥࡨࡪࡵࠣࡴࡷࡵࡧࡳࡣࡰࠤ࡮ࡹࠠࡴ࡫ࡰࡴࡱࡿࠠࡢࠢࡺࡩࡧࠦࡢࡳࡱࡺࡷࡪࡸ࠮ࠨኁ")
	LQf1jSRk4tA32a(knTyjJ0sGIzuwbxRae(u"࠭࡬ࡦࡨࡷࠫኂ"),LHX65I9nkx0PstgcVY24uSi(u"ࠧࡅ࡫ࡪ࡭ࡹࡧ࡬ࠡࡏ࡬ࡰࡱ࡫࡮࡯࡫ࡸࡱࠥࡉ࡯ࡱࡻࡵ࡭࡬࡮ࡴࠡࡃࡦࡸࠥ࠮ࡄࡎࡅࡄ࠭ࠬኃ"),NN9niuC7RoqmhkL2,jL1E5AKfwBDv6xmeQtUXcJ3d(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫኄ"))
	return
def y5yE9CW1SUjZaMcxXQwTsHJPA():
	u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"ࠩส่อืๆศ็ฯࠤ้อ๋ࠠใะฺูࠥ็ศัฬࠤฬ๊สีใํีࠥ฿ๆะࠢส่ฬะีศๆࠣฬฬ๊ๅ้ษๅ฽ࠥอไๆึไีฮ่ࠦๅ้ำหࠥ็๊ࠡฯส่ࠥ๎ฬ้ัุࠣ์อฯสࠢ฽๎ึࠦีฮ์ะอࠥษ่ࠡ็้ฮ์๐ษࠡษ็ู้ออ๋หࠣวํࠦๅำ์ไอࠥ็ว็๊ࠢิฬࠦไ็ࠢํ์็็ࠠศๆิฬ฼ࠦวๅ็ืๅึ่ࠦๅ่ࠣ๎ํ่แࠡ฻่่ࠥอไษำ้ห๊าࠧኅ"))
	w0BCQ1he5Hk6SrKuYTM7VxGRj()
	return
def mqpCH3ZGgMQt8rIXJD():
	ouVK5nBAecz = {}
	IgevlL76OVTdXUYRcb2HmB9S,QVU0ze1PSrwZY2NAvt6EMq,l1HDQ4KjVe8 = iOoy6CqaNxHD1fcGI7Kh5jRXYp(mic3MEN709xOkrjD5ZvbGIlX6)
	rGIDET0OmyFiUL8q,iCDE40qzXlhxrvf,Q8QSUrGdpmul,wqI0MRzPSQoeph3nBN9Hcb,HZWC6fLmlkw408AvXMTIhc,RRwxHXv8G2s4,m1XRhCFQinw43K9VLaHf = HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx
	rGIDET0OmyFiUL8q = MSnXBQNUg1jF3W2fRlE9OLaCT8ds4.join(QVU0ze1PSrwZY2NAvt6EMq)
	iCDE40qzXlhxrvf = MSnXBQNUg1jF3W2fRlE9OLaCT8ds4.join(l1HDQ4KjVe8)
	ddvsKAhZlj8nYIJNBCFQ,HJmMalUn8XsC,UvXoOSmMcEbhIueQ8T2ntp6kgYG5N = IgevlL76OVTdXUYRcb2HmB9S
	for ZvCajmoUedFL,II7cyZKVksexAFCBX,Oj1a2sIk0Eq74hfegTFRbuoLXSGYJ in HJmMalUn8XsC:
		Oj1a2sIk0Eq74hfegTFRbuoLXSGYJ = ArwuTXMNsaO9fmjWdI(Oj1a2sIk0Eq74hfegTFRbuoLXSGYJ)
		Oj1a2sIk0Eq74hfegTFRbuoLXSGYJ = Oj1a2sIk0Eq74hfegTFRbuoLXSGYJ.strip(oQpxmKiRPlHeGsLXNrJF78O).strip(LHX65I9nkx0PstgcVY24uSi(u"ࠪࠤ࠳࠭ኆ"))
		RWLf1KiJyZtGg2s9lPSp3vN = ZvCajmoUedFL.replace(LHX65I9nkx0PstgcVY24uSi(u"ࠫࡕ࡟ࡔࡉࡑࡑࠫኇ"),k4IUieraScH9DV1N7pJgQosYAx5l(u"ࠬࡇࡐࡊࠩኈ"))
		wqI0MRzPSQoeph3nBN9Hcb += ti3SbXNV0aJ7n5Grc4OQY8Ll1s9+s7d549VgeP+RWLf1KiJyZtGg2s9lPSp3vN+CDwSWB4v39N7(u"࠭࠺ࠡࠩ኉")+cjqzOQ5GXD4kR+Oj1a2sIk0Eq74hfegTFRbuoLXSGYJ+ti3SbXNV0aJ7n5Grc4OQY8Ll1s9
		if II7cyZKVksexAFCBX.isdigit(): ouVK5nBAecz[ZvCajmoUedFL] = int(II7cyZKVksexAFCBX)
	oJYPLcUq8uF3K,Avwzof5DnJha6GLPEjgTUbMKSuqrHQ,lf8xoTuCeAPBSWHdc36i4a = list(zip(*HJmMalUn8XsC))
	for ZvCajmoUedFL in sorted(Lly9tr1nv2IA4):
		if ZvCajmoUedFL not in oJYPLcUq8uF3K:
			wqI0MRzPSQoeph3nBN9Hcb += ti3SbXNV0aJ7n5Grc4OQY8Ll1s9+s7d549VgeP+ZvCajmoUedFL+maUl7SPesynF1j(u"ࠧ࠻ࠢࠪኊ")+cjqzOQ5GXD4kR+SODvU3Ibq5VzC(u"ࠨๆสࠤ๏๎ฬะࠩኋ")+ti3SbXNV0aJ7n5Grc4OQY8Ll1s9
			if ZvCajmoUedFL not in Jzthpc2nj5.non_videos_actions: Q8QSUrGdpmul += MSnXBQNUg1jF3W2fRlE9OLaCT8ds4+ZvCajmoUedFL
	for Oj1a2sIk0Eq74hfegTFRbuoLXSGYJ,oWRrAQ4PHUDuw76KsBZ2 in ddvsKAhZlj8nYIJNBCFQ:
		Oj1a2sIk0Eq74hfegTFRbuoLXSGYJ = ArwuTXMNsaO9fmjWdI(Oj1a2sIk0Eq74hfegTFRbuoLXSGYJ)
		HZWC6fLmlkw408AvXMTIhc += Oj1a2sIk0Eq74hfegTFRbuoLXSGYJ+X2crmy67eZpkGTRd(u"ࠩ࠽ࠤࠬኌ")+ao3Q5jP8H0sMxK2iUYwZGE+str(oWRrAQ4PHUDuw76KsBZ2)+cjqzOQ5GXD4kR+xoZHpTRUzS9
	rGIDET0OmyFiUL8q = rGIDET0OmyFiUL8q.strip(oQpxmKiRPlHeGsLXNrJF78O)
	iCDE40qzXlhxrvf = iCDE40qzXlhxrvf.strip(oQpxmKiRPlHeGsLXNrJF78O)
	Q8QSUrGdpmul = Q8QSUrGdpmul.strip(oQpxmKiRPlHeGsLXNrJF78O)
	DxismuOJbzQM0EN6jLkq = rGIDET0OmyFiUL8q+knTyjJ0sGIzuwbxRae(u"ࠪࠤࠥ࠴࠮ࠡࠢࠪኍ")+iCDE40qzXlhxrvf
	zqcvniKSQ7sETLA4IoR89OkDX  = EF2tvxZHz5n4UruPhaViXKycI6SQR(u"๊ࠫ๎วใ฻ࠣะ๏ีษࠡึ฽่ࠥอไษำ้ห๊าࠠๆ่๊หࠥ็๊ะ์๋๋ฬะࠠโ์ࠣ࠷ࠥษ๊ศ็ࠣห้๋วื์ฬࠤ๋࠭ๆࠡษ็ว่ััࠡว็ํࠥอไฤไ็࠭ࠬ኎")+ti3SbXNV0aJ7n5Grc4OQY8Ll1s9+SODvU3Ibq5VzC(u"ࠬ๎็ัษ้ࠣ฾์ว่ࠢศิฬࠦไะ์ๆࠤฺ๊ใๅหࠣๅ๏ํๅࠡใ๊๎๋ࠥๆࠡ฻้ำ่่ࠦๅ์ึฮ๋ࠥๆࠡษ็ฬึ์วๆฮࠣ์้อࠠๆ่ࠣห้๋่ใ฻ࠪ኏")+ti3SbXNV0aJ7n5Grc4OQY8Ll1s9
	zqcvniKSQ7sETLA4IoR89OkDX += ao3Q5jP8H0sMxK2iUYwZGE+DxismuOJbzQM0EN6jLkq+cjqzOQ5GXD4kR+U0VwOviFaYPz2QGs45mJhMXf7Zk(u"࠭࡜࡯࡞ࡱࠫነ")
	zqcvniKSQ7sETLA4IoR89OkDX += KhUG1NV9bln5zXjptqFW6dgo(u"ࠧๆ๊สๆ฾ࠦไๆࠢํุ฿๊ࠠๆ่๊หࠥอไษำ้ห๊าࠠโ์า๎ํํวหࠢไ๎ࠥ࠹ࠠฤ์ส้ࠥอไๆษู๎ฮࠦࠨๆำอฬฮࠦรษฮา๎࠮࠭ኑ")+ti3SbXNV0aJ7n5Grc4OQY8Ll1s9+ELfMeDTIFhJt685K(u"ࠨ๊๊ิฬࠦๅฺ่ส๋ࠥออห็ส่ࠥ๎ฬ้ัู้้ࠣไสࠢ฼๊ิ้ࠠฤ๊ࠣๅ๏ࠦวๅ็๋ๆ฾ࠦร้ࠢไ๎ࠥอไษำ้ห๊าࠧኒ")+ti3SbXNV0aJ7n5Grc4OQY8Ll1s9
	Q8QSUrGdpmul = MSnXBQNUg1jF3W2fRlE9OLaCT8ds4.join(sorted(Q8QSUrGdpmul.split(MSnXBQNUg1jF3W2fRlE9OLaCT8ds4)))
	zqcvniKSQ7sETLA4IoR89OkDX += ao3Q5jP8H0sMxK2iUYwZGE+Q8QSUrGdpmul+cjqzOQ5GXD4kR
	y0qNQYPdTj5LCaWR,nlxdI8Xqgu,ZDj8nPIVEFH91qcd0pKuyJ6O,waDhC9GRjlgO8LnFEi37 = EAVanJj1ers2GQud(u"࠱᏷"),EAVanJj1ers2GQud(u"࠱᏷"),EAVanJj1ers2GQud(u"࠱᏷"),EAVanJj1ers2GQud(u"࠱᏷")
	all = ouVK5nBAecz[mgLADoQ1pbtY(u"ࠩࡄࡐࡑ࠭ና")]
	if PPAUFrY8cduRT(u"ࠪࡔ࡞࡚ࡈࡐࡐࠪኔ") in list(ouVK5nBAecz.keys()): y0qNQYPdTj5LCaWR = ouVK5nBAecz[YJxaX0MQOHb8oyCBFdnIAe(u"ࠫࡕ࡟ࡔࡉࡑࡑࠫን")]
	if owbMhINBQsmx70guApW(u"ࠬࡏࡎࡔࡖࡄࡐࡑ࠭ኖ") in list(ouVK5nBAecz.keys()): nlxdI8Xqgu = ouVK5nBAecz[OzU6t0qcH7MQabeBYK8vgoG(u"࠭ࡉࡏࡕࡗࡅࡑࡒࠧኗ")]
	if KhUG1NV9bln5zXjptqFW6dgo(u"ࠧࡎࡇࡗࡖࡔࡖࡏࡍࡋࡖࠫኘ") in list(ouVK5nBAecz.keys()): ZDj8nPIVEFH91qcd0pKuyJ6O = ouVK5nBAecz[EAVanJj1ers2GQud(u"ࠨࡏࡈࡘࡗࡕࡐࡐࡎࡌࡗࠬኙ")]
	if KKi79PFqsYB0dWSRgaJ3DyE(u"ࠩࡕࡉࡕࡕࡓࠨኚ") in list(ouVK5nBAecz.keys()): waDhC9GRjlgO8LnFEi37 = ouVK5nBAecz[ShnRVsifKtc60zqQ(u"ࠪࡖࡊࡖࡏࡔࠩኛ")]
	dXsj641cAYknwbrhToBv0m = all-y0qNQYPdTj5LCaWR-nlxdI8Xqgu-ZDj8nPIVEFH91qcd0pKuyJ6O-waDhC9GRjlgO8LnFEi37
	RZ9V4eABCTfIO1FUrz2ks5DSwu,rrAStfiGPo = UvXoOSmMcEbhIueQ8T2ntp6kgYG5N[o4bNzIQGYj8En]
	RZ9V4eABCTfIO1FUrz2ks5DSwu,HcbKS36gfXZ52sqiAlNz = UvXoOSmMcEbhIueQ8T2ntp6kgYG5N[CH7RKuDVzN9f06q8MtXPhlvIxakEWg]
	gTKD7tbrUZHiqQLJ16E8YyaxsnO9 = rrAStfiGPo-HcbKS36gfXZ52sqiAlNz
	m1XRhCFQinw43K9VLaHf += s7d549VgeP+str(HcbKS36gfXZ52sqiAlNz)+cjqzOQ5GXD4kR+U0VwOviFaYPz2QGs45mJhMXf7Zk(u"ࠫฬู๊ะัࠣห้ำโ๋ไํࠤ้๊รอ้ีอࠥࡀࠠࠨኜ")
	m1XRhCFQinw43K9VLaHf += ti3SbXNV0aJ7n5Grc4OQY8Ll1s9+s7d549VgeP+str(gTKD7tbrUZHiqQLJ16E8YyaxsnO9)+cjqzOQ5GXD4kR+EAVanJj1ers2GQud(u"ࠬฮวิฬัำฬ๋ࠠࡱࡴࡲࡼࡾࠦร้ࠢࡹࡴࡳࠦ࠺ࠡࠩኝ")
	m1XRhCFQinw43K9VLaHf += ti3SbXNV0aJ7n5Grc4OQY8Ll1s9+s7d549VgeP+str(rrAStfiGPo)+cjqzOQ5GXD4kR+n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"࠭วๅ฻าำࠥอไไๆํࠤ้าๅ๋฻ࠣห้ษฬ่ิฬࠤ࠿ࠦࠧኞ")
	m1XRhCFQinw43K9VLaHf += ti3SbXNV0aJ7n5Grc4OQY8Ll1s9+s7d549VgeP+str(len(UvXoOSmMcEbhIueQ8T2ntp6kgYG5N[ShnRVsifKtc60zqQ(u"࠴ᏸ"):]))+cjqzOQ5GXD4kR+OBsrtQo2pPlgURCxJYbj9iXMD(u"ฺࠧัาࠤฬ๊ฯ้ๆࠣห้ะ๊ࠡใํ๋ฬࠦรอ้ีอࠥࡀࠠ࡝ࡰ࡟ࡲࠬኟ")
	for lmsiLduHeBFVJcSjvzXp6,QXcqfBzUWRdgrn7JSsTi1Po83C in UvXoOSmMcEbhIueQ8T2ntp6kgYG5N[U0VwOviFaYPz2QGs45mJhMXf7Zk(u"࠵ᏹ"):]:
		lmsiLduHeBFVJcSjvzXp6 = ArwuTXMNsaO9fmjWdI(lmsiLduHeBFVJcSjvzXp6)
		lmsiLduHeBFVJcSjvzXp6 = lmsiLduHeBFVJcSjvzXp6.strip(oQpxmKiRPlHeGsLXNrJF78O).strip(PPAUFrY8cduRT(u"ࠨࠢ࠱ࠫአ"))
		m1XRhCFQinw43K9VLaHf += lmsiLduHeBFVJcSjvzXp6+KhUG1NV9bln5zXjptqFW6dgo(u"ࠩ࠽ࠤࠬኡ")+ao3Q5jP8H0sMxK2iUYwZGE+str(QXcqfBzUWRdgrn7JSsTi1Po83C)+cjqzOQ5GXD4kR+maUl7SPesynF1j(u"ࠪࠤࠥࠦࠧኢ")
	RRwxHXv8G2s4 += s7d549VgeP+str(dXsj641cAYknwbrhToBv0m)+cjqzOQ5GXD4kR+KhUG1NV9bln5zXjptqFW6dgo(u"ࠫๆ๐ฯ๋๊๊หฯࠦวีฬ฽่ฯࠦ࠺ࠡࠩኣ")
	RRwxHXv8G2s4 += ti3SbXNV0aJ7n5Grc4OQY8Ll1s9+s7d549VgeP+str(y0qNQYPdTj5LCaWR)+cjqzOQ5GXD4kR+HDpmv4UXzlf72SK9(u"ࠬ฽ไษษอࠤุ๐ัโำࠣࡅࡕࡏࠠ࠻ࠢࠪኤ")
	RRwxHXv8G2s4 += ti3SbXNV0aJ7n5Grc4OQY8Ll1s9+s7d549VgeP+str(waDhC9GRjlgO8LnFEi37)+cjqzOQ5GXD4kR+ELfMeDTIFhJt685K(u"࠭ืๅสสฮู๊ࠥาใิࠤฬ๊ๅิฬ๋ำ฾ࠦ࠺ࠡࠩእ")
	RRwxHXv8G2s4 += ti3SbXNV0aJ7n5Grc4OQY8Ll1s9+s7d549VgeP+str(nlxdI8Xqgu)+cjqzOQ5GXD4kR+Tcf5Ppn9UajDbzyM(u"ࠧหอห๎ฯࠦสุสํๆ้่ࠥะ์ࠣ฽๊อฯࠡ࠼ࠣࠫኦ")
	RRwxHXv8G2s4 += ti3SbXNV0aJ7n5Grc4OQY8Ll1s9+s7d549VgeP+str(ZDj8nPIVEFH91qcd0pKuyJ6O)+cjqzOQ5GXD4kR+C3ZK1pu4rfmj8TsWUtBaM(u"ࠨฬฮฬ๏ะࠠอๆาࠤ๊ะั้สุู๋่ࠦๆษาࠤ࠿ࠦࠧኧ")
	RRwxHXv8G2s4 += ti3SbXNV0aJ7n5Grc4OQY8Ll1s9+s7d549VgeP+str(len(ddvsKAhZlj8nYIJNBCFQ))+cjqzOQ5GXD4kR+mgLADoQ1pbtY(u"ࠩา์้ࠦิ฻ๆอࠤๆ๐ฯ๋๊๊หฯࠦ࠺ࠡࠩከ")
	RRwxHXv8G2s4 += OBsrtQo2pPlgURCxJYbj9iXMD(u"ࠪࡠࡳࡢ࡮ࠨኩ")+HZWC6fLmlkw408AvXMTIhc
	LQf1jSRk4tA32a(n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫኪ"),owbMhINBQsmx70guApW(u"ࠬ฿ฯะࠢส่ๆ๐ฯ๋๊๊หฯࠦวๅฬํࠤูเไ่ษ๋ࠣีอࠠศๆหี๋อๅอࠢไ๎ࠥ࠹ࠠฤ์ส้ࠥอไๆษู๎ฮࠦแ๋ࠢส่฾อไๆࠢๆ่์࠭ካ"),RRwxHXv8G2s4,k4IUieraScH9DV1N7pJgQosYAx5l(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩኬ"))
	LQf1jSRk4tA32a(cWbkR6iUZsnJQj14(u"ࠧࡤࡧࡱࡸࡪࡸࠧክ"),nz8x32hX0qcjUPFZk5RdJsiwED(u"ࠨ็๋ห็฿ࠠศึอ฾้ะࠠโ์ࠣ࠷ࠥษ๊ศ็ࠣห้๋วื์ฬࠤๆ๐ࠠศๆ฼ห้๋ࠠไๆ๊ࠫኮ"),zqcvniKSQ7sETLA4IoR89OkDX,X2crmy67eZpkGTRd(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬኯ"))
	LQf1jSRk4tA32a(U0VwOviFaYPz2QGs45mJhMXf7Zk(u"ࠪࡰࡪ࡬ࡴࠨኰ"),mg3CbXMA2ouZzQDhRqB(u"ࠫศ฿ไ๊ࠢส่ิ๎ไࠡษ็ฮ๏ࠦวิฬัำ๊ะࠠศๆหี๋อๅอࠢไ๎ࠥ࠹ࠠฤ์ส้ࠥอไๆษู๎ฮ࠭኱"),wqI0MRzPSQoeph3nBN9Hcb,Tcf5Ppn9UajDbzyM(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࡠ࡮ࡲࡲ࡬࠭ኲ"))
	dXUwsnOGKBF57cNaok(gyd2rf0UR5)
	return
def GEfvbTKsB4N1OXZW():
	wwpQTfixYD23X = ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"࠭็ัษࠣห้ฮั็ษ่ะࠥ๐ูๆๆࠣหๆ฼ไࠡสสืฯิฯศ็ࠣะ้ีࠠไ๊า๎ࠥ࠮ࡋࡰࡦ࡬ࠤࡘࡱࡩ࡯ࠫࠣห้ึ๊ࠡษึ้์ࡢ࡮ࠨኳ")+s7d549VgeP+EF2tvxZHz5n4UruPhaViXKycI6SQR(u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭ኴ")+cjqzOQ5GXD4kR+maUl7SPesynF1j(u"ࠨ࡞ࡱࡠࡳࡢ࡮๊่้่ࠡ์ࠠหอห๎ฯํࠠษษึฮำีวๆ่ࠢืฯ๎ฯฺࠢ฼้ฬีࠠࡆࡏࡄࡈࠥࡘࡥࡱࡱࡶ࡭ࡹࡵࡲࡺࠢฦ์ࠥะอๆ์็๋๋ࠥๆ࡝ࡰࠪኵ")+s7d549VgeP+CDwSWB4v39N7(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡲࡦࡲࡲ࠲ࡺࡱ࠮ࡵࡱࠪ኶")+cjqzOQ5GXD4kR+KKi79PFqsYB0dWSRgaJ3DyE(u"ࠪࡠࡳࡢ࡮࡝ࡰ๋ࠣีํࠠศๆิืฬ๊ษ๊ࠡ฽๎ึํวࠡๅฮ๎ึࠦๅ้ฮ๋ำฮࠦแ๋ࠢๅหห๋ษࠡืํห๋ฯࠠศๆหี๋อๅอ๋ࠢห้๋า๋ัࠣว๏฼วࠡ็๋ะํีࠠโ์ࠣๆฬฬๅส่ࠢ฽้๎ๅศฬࠣห้ฮั็ษ่ะࠬ኷")
	LQf1jSRk4tA32a(ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫኸ"),OO2BXYhI8UPNq6L,wwpQTfixYD23X,EAVanJj1ers2GQud(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨኹ"))
	return
def jsRavVxfl702myeEdJtp3():
	wwpQTfixYD23X = EF2tvxZHz5n4UruPhaViXKycI6SQR(u"࠭วๅำสฬ฼๐ๆࠡลา๊ฬํࠠโ์๊้ฬࠦสุสํๆ้่ࠥะ์ࠣ฽๊อฯ๊๊ࠡ์ࠥ฿ศศำฬࠤ฾์ࠠหอห๎ฯࠦใศ็็ࠤฬ๎ส้็สฮ๏้๊ࠡๆหี๋อๅอࠢๆ์ิ๐้ࠠ็฼๋ࠥอึศใฬࠤ฾๋วะࠢ็่ๆ๐ฯ๋๊๊หฯࠦวๅ฻ิฬ๏ฯ้ࠠ็฼๋ࠥอึศใฬࠤั๊ฯࠡ็อีํฮ่ๅีࠣ฽๊อฯ๊่ࠡ฽์ࠦวืษไอ๋ࠥำห๊า฽ࠥ฿ๅศัࠣ์ๆ๐็ࠡลํฺฬࠦฬๆ์฼ࠤฬ฿ฯศัอࠤ่๎ฯ๋ࠢส่๊฽ไ้สฬࠤ้฿ๅๅࠢหี๋อๅอࠢ฼้ฬี้ࠠๅ็๋ฬࠦสห็ࠣหํะ่ๆษอ๎่๐ว๊ࠡ็หࠥะอหษฯࠤศ๐ࠠ็๊฼ࠤ๊์ࠠศๆัฬึฯࠠโ์ࠣ็ํี๊ࠡล๋ࠤฬ๊ฮษำฬࠤๆ๐ࠠหอห๎ฯࠦรืษไหฯࠦใ้ัํࠫኺ")+ti3SbXNV0aJ7n5Grc4OQY8Ll1s9+ao3Q5jP8H0sMxK2iUYwZGE+Jzthpc2nj5.SITESURLS[SODvU3Ibq5VzC(u"ࠧࡌࡑࡇࡍࡊࡓࡁࡅࡡࡄࡔࡕ࠭ኻ")][o4bNzIQGYj8En]+cjqzOQ5GXD4kR+KhUG1NV9bln5zXjptqFW6dgo(u"ࠨࠢࠣࠤࠥษ่ࠡࠢࠣࠤࠬኼ")+ao3Q5jP8H0sMxK2iUYwZGE+Jzthpc2nj5.SITESURLS[ELfMeDTIFhJt685K(u"ࠩࡎࡓࡉࡏࡅࡎࡃࡇࡣࡆࡖࡐࠨኽ")][CH7RKuDVzN9f06q8MtXPhlvIxakEWg]+cjqzOQ5GXD4kR
	wwpQTfixYD23X += nz8x32hX0qcjUPFZk5RdJsiwED(u"ࠪࡠࡳࡢ࡮࡝ࡰส่ึอศุࠢฦำ๋อ็้๋ࠡࠤฬ๊ำ้ำึࠤฬ๊ะ๋ࠢํัฯอฬ่่ࠢำ๏ืࠠๆๆไหฯࠦใ้ัํࠤ้ะหษ์อࠤอืๆศ็ฯࠤ฾๋วะࠢหห้฽ั๋ไฬࠤฬ๊สใๆํำ๏ฯࠠศๆๅำ๏๋ษ࡝ࡰࠪኾ")+ao3Q5jP8H0sMxK2iUYwZGE+Jzthpc2nj5.SITESURLS[U0VwOviFaYPz2QGs45mJhMXf7Zk(u"ࠫࡐࡕࡄࡊࡡࡖࡓ࡚ࡘࡃࡆࡕࠪ኿")][o4bNzIQGYj8En]+cjqzOQ5GXD4kR+LHX65I9nkx0PstgcVY24uSi(u"ࠬࠦࠠࠡࠢฦ์ࠥࠦࠠࠡࠩዀ")+ao3Q5jP8H0sMxK2iUYwZGE+Jzthpc2nj5.SITESURLS[knTyjJ0sGIzuwbxRae(u"࠭ࡋࡐࡆࡌࡣࡘࡕࡕࡓࡅࡈࡗࠬ዁")][CH7RKuDVzN9f06q8MtXPhlvIxakEWg]+cjqzOQ5GXD4kR
	wwpQTfixYD23X += CDwSWB4v39N7(u"ࠧ࡝ࡰ࡟ࡲࡡࡴฬๆ์฼ࠤ๊๊แศฬࠣ฽๊อฯࠡ็๋ะํีษࠡใํࠤฬ๊ๅ้ไ฼ࠤศีๆศ้ࠪዂ")+ti3SbXNV0aJ7n5Grc4OQY8Ll1s9+ao3Q5jP8H0sMxK2iUYwZGE+Jzthpc2nj5.SITESURLS[cWbkR6iUZsnJQj14(u"ࠨࡈࡌࡐࡊ࡙࡟ࡔࡑࡘࡖࡈࡋࡓࠨዃ")][o4bNzIQGYj8En]+cjqzOQ5GXD4kR
	LQf1jSRk4tA32a(nz8x32hX0qcjUPFZk5RdJsiwED(u"ࠩࡦࡩࡳࡺࡥࡳࠩዄ"),k4IUieraScH9DV1N7pJgQosYAx5l(u"ࠪห้๋่ศไ฼ࠤฬ๊ัิ็ํอ๊ࠥศา่ส้ัูࠦๆษาࠤ้๊แ๋ัํ์์อสࠡษ็฽ึฮ๊สࠩዅ"),wwpQTfixYD23X,maUl7SPesynF1j(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧ዆"))
	return
def S9XInyVlie6HFWRLN8adZT(pYzFyqmeUgLDAOJCvw4):
	FpGenVlw4Tzxi2WY3JuXcb.executebuiltin(OBsrtQo2pPlgURCxJYbj9iXMD(u"ࠬࡇࡤࡥࡱࡱ࠲ࡔࡶࡥ࡯ࡕࡨࡸࡹ࡯࡮ࡨࡵࠫࠫ዇")+pYzFyqmeUgLDAOJCvw4+KhUG1NV9bln5zXjptqFW6dgo(u"࠭ࠩࠨወ"), gyd2rf0UR5)
	return
def o5oC3zxwQJfI():
	F7wvxO4AfsYuTtP62Hak50yj8g(ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"ࠧࡴࡶࡲࡴࠬዉ"))
	FpGenVlw4Tzxi2WY3JuXcb.executebuiltin(SODvU3Ibq5VzC(u"ࠣࡃࡦࡸ࡮ࡼࡡࡵࡧ࡚࡭ࡳࡪ࡯ࡸࠪࡌࡲࡹ࡫ࡲࡧࡣࡦࡩࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠯ࠢዊ"))
	return
def ssL6HduBl7WfoYjZGVN():
	FpGenVlw4Tzxi2WY3JuXcb.executebuiltin(U0VwOviFaYPz2QGs45mJhMXf7Zk(u"ࠩࡄࡨࡩࡵ࡮࠯ࡑࡳࡩࡳ࡙ࡥࡵࡶ࡬ࡲ࡬ࡹࠨࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡧࡤࡢࡲࡷ࡭ࡻ࡫ࠩࠨዋ"), gyd2rf0UR5)
	return
def n9fQ4DPe16bpcL8():
	u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,mg3CbXMA2ouZzQDhRqB(u"ู่๊ࠪอࠡ็ะฮํ๐วหࠢๅหห๋ษࠡ࠰ࠣหีํศࠡว็ํࠥอไใษษ้ฮࠦวๅฬํࠤฯื๊ะ่ࠢืาํว๊ࠡ็หࠥะฯฯๆࠣษ้๐็ศ๋่่ࠢ์ࠠษษึฮำีวๆࠢࠥห้๋ว้ีࠥࠤศ๎ࠠࠣษ็ี๏๋่หࠤࠣห฻เืࠡ฻็ํࠥอไำำࠣะ์ฯࠠศๆํ้๏์ࠠฤ๊ࠣหุะฮะ็ࠣࠦฬ๊ใ๋ส๋ีิࠨ้ࠠษู฾฼ูࠦๅ๋ࠣัึ็ࠠࠣࡅࠥࠤศ๎ฺࠠๆ์ࠤฬ฼ฺุࠢ฼่๎ࠦาาࠢࠥห้่วว็ฬࠦࠥอไั์ࠣๅ๏ࠦฬ่หࠣห้๐ๅ๋่ࠪዌ"))
	return
def z17KE2Wb63lOy():
	u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,U0VwOviFaYPz2QGs45mJhMXf7Zk(u"้๊ࠫสฺษู่่๋ࠥࠡษ็้ๆ฼ไสࠢ࠱ࠤฬึ็ษࠢศ่๎ࠦวๅำสฬ฼ࠦวๅาํࠤฯื๊ะࠢศฺฬ็ส่ࠢฦ์๋ࠥำฮ้้๋ࠣࠦࠠใษษ้ฮࠦวๅ็ไฺ้ฯ้ࠠๆๆ๊๊ࠥวࠡฬ้ๆึูࠦๅ์๊ࠤํ๊วࠡฬื฾้ํࠠ࠯๋ࠢฬฬูสฯัส้ࠥࠨวๅ็ส์ุࠨࠠฤ๊ࠣࠦฬ๊ั๋็๋ฮࠧࠦวื฼ฺࠤ฾๊้ࠡษ็ึึࠦฬ่หࠣห้๐ๅ๋่ࠣ࠲ࠥ๎รๆษࠣฬฬูสฯัส้ࠥࠨวๅๅํฬํืฯࠣࠢไห฻เืࠡ฻็ํࠥำัโࠢࠥࡇࠧࠦร้ࠢ฼่๎ࠦาาࠢࠥห้่วว็ฬࠦࠥอไั์ࠣๅ๏ࠦฬ่หࠣห้๐ๅ๋่ࠣ࠲ࠥ๎ๆโีࠣห้้ไศ็ࠣ์ฬ๊ืา์ๅอࠥ฿ๆะࠢส่ฯ฿วๆๆ้ࠣ฾ࠦๅฮฬ๋๎ฬะࠠใ๊สส๊ࠦวๅ็ไฺ้ฯࠧው"))
	return
def UlJuPdVtRg9h25ADxBFIGEW(iibeGPRv5uoF3LmUS91=EF2tvxZHz5n4UruPhaViXKycI6SQR(u"ࠬࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇࠫዎ"),showDialogs=gyd2rf0UR5):
	K3dSZoF4R6i9TwtQsUhCa = FpGenVlw4Tzxi2WY3JuXcb.executeJSONRPC(EAVanJj1ers2GQud(u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾࡙ࠧࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡈࡧࡷࡗࡪࡺࡴࡪࡰࡪ࡚ࡦࡲࡵࡦࠤ࠯ࠦ࡮ࡪࠢ࠻࠳࠯ࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡴࡧࡷࡸ࡮ࡴࡧࠣ࠼ࠥࡰࡴࡵ࡫ࡢࡰࡧࡪࡪ࡫࡬࠯ࡵ࡮࡭ࡳࠨࡽࡾࠩዏ"))
	data = IsGwR1YyfQqa4picCZ6m.loads(K3dSZoF4R6i9TwtQsUhCa)
	WcUhLbE7KBDzuFsTOn16HXw49jpgG = data[C3ZK1pu4rfmj8TsWUtBaM(u"ࠧࡳࡧࡶࡹࡱࡺࠧዐ")][n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"ࠨࡸࡤࡰࡺ࡫ࠧዑ")]
	if C6H1qXua3SMQiIrzxNvJWZE: WcUhLbE7KBDzuFsTOn16HXw49jpgG = WcUhLbE7KBDzuFsTOn16HXw49jpgG.encode(Zex6D4tJE52r)
	if showDialogs:
		N7gs9UBCeDR3 = HUJZy0SrTbBYv1(HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,X2crmy67eZpkGTRd(u"๊่ࠩࠥะั๋ัࠣฮ฿๐๊าࠢฯ่ิࠦࠧዒ")+WcUhLbE7KBDzuFsTOn16HXw49jpgG+jL1E5AKfwBDv6xmeQtUXcJ3d(u"ࠪࠤฬ๊ะ๋่ࠢืฯิฯๆࠢส่ว์ࠠโ์ࠣ็ํี๊ࠡว็ํࠥอไฦืาหึࠦวๅลั๎ึࠦไอๆาࠤࠬዓ")+iibeGPRv5uoF3LmUS91+CDwSWB4v39N7(u"ࠫࠥลࠡࠨዔ"))
		if N7gs9UBCeDR3!=LHX65I9nkx0PstgcVY24uSi(u"࠵ᏺ"): return mic3MEN709xOkrjD5ZvbGIlX6
	HH2hLvGCD3zfk,dSCqrTMaOHfP3z4U5V,AOMsNIwJUTrdKhQZLPiqXfYR = axgV1MLjKPtvr(iibeGPRv5uoF3LmUS91,mic3MEN709xOkrjD5ZvbGIlX6,mic3MEN709xOkrjD5ZvbGIlX6)
	if HH2hLvGCD3zfk:
		if showDialogs: u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,U0VwOviFaYPz2QGs45mJhMXf7Zk(u"ࠬะๅหࠢ฼้้๐ษࠡฬฮฬ๏ะࠠศๆฯ่ิࠦวๅฮา๎ิ่่๊ࠦࠣะฬําࠡๆ็หุะฮะษ่ࠤ࠳ࠦำ้ใࠣ๎ฯ๋ࠠศๆล๊ࠥะฺ๋์ิࠤส฿ฯศัสฮ้่ࠥะ์่่ࠣ๐๋ࠠีอ฽๊๊ࠠศๆฯ่ิࠦวๅฮา๎ิࠦศะๆสࠤ๊์ࠠศๆๅำ๏๋ࠧዕ"))
		Q5h3NlAKkaPpmXtF8uEqV = FpGenVlw4Tzxi2WY3JuXcb.executeJSONRPC(pCTzbw4GyVJHjkcIMQ(u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾࡙ࠧࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡔࡧࡷࡗࡪࡺࡴࡪࡰࡪ࡚ࡦࡲࡵࡦࠤ࠯ࠦ࡮ࡪࠢ࠻࠳࠯ࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡴࡧࡷࡸ࡮ࡴࡧࠣ࠼ࠥࡰࡴࡵ࡫ࡢࡰࡧࡪࡪ࡫࡬࠯ࡵ࡮࡭ࡳࠨࠬࠣࡸࡤࡰࡺ࡫ࠢ࠻ࠤࠪዖ")+iibeGPRv5uoF3LmUS91+EAVanJj1ers2GQud(u"ࠧࠣࡿࢀࠫ዗"))
		HH2hLvGCD3zfk = gyd2rf0UR5 if ShnRVsifKtc60zqQ(u"ࠨࡑࡎࠫዘ") in Q5h3NlAKkaPpmXtF8uEqV else mic3MEN709xOkrjD5ZvbGIlX6
		jHWkt18govGwY7iUbduAfxCyRc.sleep(JJA7fypmZFVlazvNI(u"࠶ᏻ"))
		FpGenVlw4Tzxi2WY3JuXcb.executebuiltin(OzU6t0qcH7MQabeBYK8vgoG(u"ࠩࡖࡩࡳࡪࡃ࡭࡫ࡦ࡯࠭࠷࠱ࠪࠩዙ"))
	elif showDialogs: u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,HDpmv4UXzlf72SK9(u"่้ࠪษำโࠢไุ้ะฺࠠ็็๎ฮࠦสฬสํฮࠥ๎สโ฻ํ่ࠥอไอๆาࠤฬ๊ๅุๆ๋ฬࠬዚ"))
	return HH2hLvGCD3zfk
def SCkwQfWsTo2p1x7():
	url = JJA7fypmZFVlazvNI(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡲ࡯ࡲࡳࡱࡵࡷ࠳ࡱ࡯ࡥ࡫࠱ࡸࡻ࠵ࡲࡦ࡮ࡨࡥࡸ࡫ࡳ࠰ࡹ࡬ࡲࡩࡵࡷࡴ࠱ࡺ࡭ࡳ࠼࠴࠰ࠩዛ")
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,LHX65I9nkx0PstgcVY24uSi(u"ࠬࡍࡅࡕࠩዜ"),url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,JJA7fypmZFVlazvNI(u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓ࠮ࡕࡋࡓ࡜ࡥࡌࡂࡖࡈࡗ࡙ࡥࡋࡐࡆࡌࡣ࡛ࡋࡒࡔࡋࡒࡒ࠲࠷ࡳࡵࠩዝ"))
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	nf6goVstZe7YdW9P8 = DyVGS3dX0ZxR.findall(OzU6t0qcH7MQabeBYK8vgoG(u"ࠧࡵ࡫ࡷࡰࡪࡃࠢ࡬ࡱࡧ࡭࠲࠮࡜ࡥ࠭࡟࠲ࡡࡪࠫ࠮࡝ࡤ࠱ࡿࡇ࡛࠭࡟࠮࠭࠲࠭ዞ"),CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	nf6goVstZe7YdW9P8 = nf6goVstZe7YdW9P8[o4bNzIQGYj8En].split(dBi72erQEtKDOwjNFaoAgSP(u"ࠨ࠯ࠪዟ"))[o4bNzIQGYj8En]
	L8kFGZ65TAO4ten7hCsJdojPv = str(Oth25uIHDEC3f9kMKr7sLUoaZwblyi)
	wqI0MRzPSQoeph3nBN9Hcb = OBsrtQo2pPlgURCxJYbj9iXMD(u"ࠩ࡞ࡖ࡙ࡒ࡝ฦืาหึࠦใ้ัํࠤฬ๊รฯ์ิࠤฬ๊ๅห๊ไีࠥอไร่๋ࠣํࠦ࠺ࠡࠢࠣࠫዠ")+s7d549VgeP+nf6goVstZe7YdW9P8+cjqzOQ5GXD4kR
	wqI0MRzPSQoeph3nBN9Hcb += SODvU3Ibq5VzC(u"ࠪࡠࡳࡢ࡮ࠨዡ")+LHX65I9nkx0PstgcVY24uSi(u"ࠫࡠࡘࡔࡍ࡟ศูิอัࠡๅ๋ำ๏ࠦวๅาํࠤฬ์สࠡฬึฮำีๅ่๊ࠢ์ࠥࡀࠠࠡࠢࠪዢ")+s7d549VgeP+L8kFGZ65TAO4ten7hCsJdojPv+cjqzOQ5GXD4kR
	u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,wqI0MRzPSQoeph3nBN9Hcb)
	return
def FrT70Bs1hOfuoS5LCI2cYv6gJn8():
	eTSZ6Xiwk9mOQL8o7,xwra1np5RZiHd0YF7uNX3JDl,k5rsPTBUx7SMhEWfICzn = mic3MEN709xOkrjD5ZvbGIlX6,HQmDERMFjx,HQmDERMFjx
	MM4lI5ibjAyr,FYwf3eSLVtGuKJdzWHgPRcB,e2NbXY5SCABqmxO3QGp = mic3MEN709xOkrjD5ZvbGIlX6,HQmDERMFjx,HQmDERMFjx
	ss59hv8PuQJWiKy3BYR7xCndTrZfG = [U0VwOviFaYPz2QGs45mJhMXf7Zk(u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪዣ"),owbMhINBQsmx70guApW(u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤࠨዤ"),pCTzbw4GyVJHjkcIMQ(u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭ዥ")]
	GN8T3gF7SozjaZidm = FBqpsWQkStgN(ss59hv8PuQJWiKy3BYR7xCndTrZfG)
	for nWpLJsUZe3d4zrBOMITDK6 in ss59hv8PuQJWiKy3BYR7xCndTrZfG:
		if nWpLJsUZe3d4zrBOMITDK6 not in list(GN8T3gF7SozjaZidm.keys()): continue
		f63nZaUBvzyFbHiVcte2Dk,y4kxFQma6M8B2gU0qWpT,PLKo98Wyrq015X,PD7gQUCAlWcs,QeVRl61G0LStT5DxIMq,RGzAaJWpFcMkTS4H16YKht8jbluZ2x,zk26NlshEwIGpZbRdSrFHB = GN8T3gF7SozjaZidm[nWpLJsUZe3d4zrBOMITDK6]
		if nWpLJsUZe3d4zrBOMITDK6==EAVanJj1ers2GQud(u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭ዦ"):
			MM4lI5ibjAyr = f63nZaUBvzyFbHiVcte2Dk
			FYwf3eSLVtGuKJdzWHgPRcB = y4kxFQma6M8B2gU0qWpT+U0VwOviFaYPz2QGs45mJhMXf7Zk(u"ࠩࠣࠤࠥࠦࠨࠡࠩዧ")+oFLajW6gOrufM7I(RGzAaJWpFcMkTS4H16YKht8jbluZ2x)+knTyjJ0sGIzuwbxRae(u"ࠪࠤ࠮࠭የ")
			e2NbXY5SCABqmxO3QGp = PD7gQUCAlWcs
		elif nWpLJsUZe3d4zrBOMITDK6==LHX65I9nkx0PstgcVY24uSi(u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠭ዩ"):
			eTSZ6Xiwk9mOQL8o7 = eTSZ6Xiwk9mOQL8o7 or f63nZaUBvzyFbHiVcte2Dk
			xwra1np5RZiHd0YF7uNX3JDl += mgLADoQ1pbtY(u"ࠬࠦࠠ࠭ࠢࠣࠫዪ")+y4kxFQma6M8B2gU0qWpT+owbMhINBQsmx70guApW(u"࠭ࠠࠡࠢࠣࠬࠥ࠭ያ")+oFLajW6gOrufM7I(RGzAaJWpFcMkTS4H16YKht8jbluZ2x)+PPAUFrY8cduRT(u"ࠧࠡࠫࠪዬ")
			k5rsPTBUx7SMhEWfICzn += SODvU3Ibq5VzC(u"ࠨࠢࠣ࠰ࠥࠦࠧይ")+PD7gQUCAlWcs
		elif nWpLJsUZe3d4zrBOMITDK6==PPAUFrY8cduRT(u"ࠩࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄࠨዮ"):
			m4IC73FPTUKEBZzwS2ro5kWiuGv1 = f63nZaUBvzyFbHiVcte2Dk
			PPZSrYTo7DmjERGQ5 = y4kxFQma6M8B2gU0qWpT+ShnRVsifKtc60zqQ(u"ࠪࠤࠥࠦࠠࠩࠢࠪዯ")+oFLajW6gOrufM7I(RGzAaJWpFcMkTS4H16YKht8jbluZ2x)+pCTzbw4GyVJHjkcIMQ(u"ࠫࠥ࠯ࠧደ")
			SSlO3QpbdA = PD7gQUCAlWcs
	xwra1np5RZiHd0YF7uNX3JDl = xwra1np5RZiHd0YF7uNX3JDl.strip(k4IUieraScH9DV1N7pJgQosYAx5l(u"ࠬࠦࠠ࠭ࠢࠣࠫዱ"))
	k5rsPTBUx7SMhEWfICzn = k5rsPTBUx7SMhEWfICzn.strip(LHX65I9nkx0PstgcVY24uSi(u"࠭ࠠࠡ࠮ࠣࠤࠬዲ"))
	Dl2CStgBcOJWIV  = KKi79PFqsYB0dWSRgaJ3DyE(u"ࠧ࡜ࡔࡗࡐࡢอไฦืาหึࠦวๅลั๎ึࠦไษำ้ห๊าฺࠠ็สำࠥอไๆฬ๋ๅึࠦวๅฤ้ࠤ์๎ࠠ࠻ࠢࠣࠤࠬዳ")+s7d549VgeP+e2NbXY5SCABqmxO3QGp+cjqzOQ5GXD4kR
	Dl2CStgBcOJWIV += ti3SbXNV0aJ7n5Grc4OQY8Ll1s9+mgLADoQ1pbtY(u"ࠨ࡝ࡕࡘࡑࡣวๅวุำฬืࠠศๆำ๎ࠥอๆหࠢอืฯิฯๆ้่ࠣอืๆศ็ฯࠤ฾๋วะ๊ࠢ์ࠥࡀࠠࠡࠢࠪዴ")+s7d549VgeP+FYwf3eSLVtGuKJdzWHgPRcB+cjqzOQ5GXD4kR
	Dl2CStgBcOJWIV += PPAUFrY8cduRT(u"ࠩ࡟ࡲࡡࡴࠧድ")+HDpmv4UXzlf72SK9(u"ࠪ࡟ࡗ࡚ࡌ࡞ษ็ษฺีวาࠢส่ศิ๊าࠢ็ุ้ะ่ะ฻ࠣ฽๊อฯࠡษ็้ฯ๎แาࠢส่ว์่๊ࠠࠣ࠾ࠥࠦࠠࠨዶ")+s7d549VgeP+k5rsPTBUx7SMhEWfICzn+cjqzOQ5GXD4kR
	Dl2CStgBcOJWIV += ti3SbXNV0aJ7n5Grc4OQY8Ll1s9+cWbkR6iUZsnJQj14(u"ࠫࡠࡘࡔࡍ࡟ส่ส฻ฯศำࠣห้ึ๊ࠡษ้ฮࠥะำหะา้์ࠦไๆีอ์ิ฿ฺࠠ็สำࠥํ่ࠡ࠼ࠣࠤࠥ࠭ዷ")+s7d549VgeP+xwra1np5RZiHd0YF7uNX3JDl+cjqzOQ5GXD4kR
	Dl2CStgBcOJWIV += CDwSWB4v39N7(u"ࠬࡢ࡮࡝ࡰࠪዸ")+n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"࡛࠭ࡓࡖࡏࡡฬ๊ลึัสีࠥอไฤะํี๊ࠥฬๅั้ࠣฯื่ษ๊็ืࠥ฿ๅศัࠣห้๋ส้ใิࠤฬ๊ย็๊ࠢ์ࠥࡀࠠࠡࠢࠪዹ")+s7d549VgeP+SSlO3QpbdA+cjqzOQ5GXD4kR
	Dl2CStgBcOJWIV += ti3SbXNV0aJ7n5Grc4OQY8Ll1s9+KKi79PFqsYB0dWSRgaJ3DyE(u"ࠧ࡜ࡔࡗࡐࡢอไฦืาหึࠦวๅาํࠤฬ์สࠡฬึฮำีๅ่ࠢ็ะ้ีࠠๆฬิ์อ๎ไิࠢ฼้ฬี่๊ࠠࠣ࠾ࠥࠦࠠࠨዺ")+s7d549VgeP+PPZSrYTo7DmjERGQ5+cjqzOQ5GXD4kR
	f63nZaUBvzyFbHiVcte2Dk = MM4lI5ibjAyr or eTSZ6Xiwk9mOQL8o7
	if f63nZaUBvzyFbHiVcte2Dk:
		header = LHX65I9nkx0PstgcVY24uSi(u"ࠨษ็ีัอมࠡฬะำ๏ัࠠฦุสๅฬะࠠไ๊า๎๊ࠥอๅࠢสฺ่๊วไๆࠪዻ")
		V2BYOtuyW9U = A0aqj9uclgOtByJ6F4bz(u"ࠩส๊ฯࠦศฮษฯอ๊ࠥสฮัํฯࠥฮั็ษ่ะࠥ฿ๅศัࠣวํࠦสฮัํฯ๋ࠥำห๊า฽ࠥ฿ๅศัࠪዼ")
	else:
		header = LHX65I9nkx0PstgcVY24uSi(u"ࠪัฬ๊๊ศࠢ็หࠥ๐่อัࠣฮาี๊ฬษอࠤ้ฮั็ษ่ะࠥ฿ๅศัࠣวํࠦๅิฬ๋ำ฾ูࠦๆษาࠫዽ")
		V2BYOtuyW9U = mg3CbXMA2ouZzQDhRqB(u"ࠫฬ๊ัอษฤࠤสฮไศ฼ࠣห้๋ศา็ฯࠤ฾์ࠠศๆุ่่๊ษࠡษ็ฮ๏ࠦส้ษฯ๋่࠭ዾ")
	CZFXa7H2Vm1R38zWM = OzU6t0qcH7MQabeBYK8vgoG(u"๊ࠬใ๋ࠢํ฽ฺ๊๊่ࠠา็ࠥอไหฯา๎ะࠦวๅฬ็ๆฬฬ๊ࠡ์ฯฬࠥษๆࠡ์ๆ์๋ࠦไะ์ๆࠤๆ๐ࠠไ๊า๎ࡡࡴๅิฬ๋ำ฾ูࠦๆษาࠤࡊࡓࡁࡅࠢࡕࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠭ዿ")
	ogPhLb7Q4CtxBzrFZyGKkRJUDIi = Dl2CStgBcOJWIV+n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"࠭࡜࡯࡞ࡱࠫጀ")+V2BYOtuyW9U+OzU6t0qcH7MQabeBYK8vgoG(u"ࠧ࡝ࡰ࡟ࡲࠬጁ")+CZFXa7H2Vm1R38zWM
	LQf1jSRk4tA32a(X2crmy67eZpkGTRd(u"ࠨࡴ࡬࡫࡭ࡺࠧጂ"),header,ogPhLb7Q4CtxBzrFZyGKkRJUDIi,PPAUFrY8cduRT(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬጃ"))
	return f63nZaUBvzyFbHiVcte2Dk
def RLcSMfNngFDO1maptW6sJKd(nWpLJsUZe3d4zrBOMITDK6,zk26NlshEwIGpZbRdSrFHB,showDialogs):
	HH2hLvGCD3zfk = mic3MEN709xOkrjD5ZvbGIlX6
	if showDialogs:
		N7gs9UBCeDR3 = HUJZy0SrTbBYv1(HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,owbMhINBQsmx70guApW(u"ࠪืํ็๋ࠠฬ่ࠤฬ๊ย็ࠢฯ่อࠦวๅ็็ๅࠥอไๆุ฽์฼ࠦไๅวูหๆฯࠠศๆ่฻้๎ศสࠢ็็๏๊ࠦห็ࠣฮะฮ๊ห้ࠣ฽้๏ࠠไ๊า๎ࠥ࠴ࠠศๆ่่ๆࠦโะࠢํ็ํ์ࠠไสํีࠥ๎โะࠢํัฯอฬࠡส฼ฺࠥอไ้ไอࠤ࠳ࠦ็ๅࠢอี๏ีࠠหฯ่๎้ࠦวๅ็็ๅࠥอไร่ࠣรࠦ࠭ጄ"))
		if N7gs9UBCeDR3!=CH7RKuDVzN9f06q8MtXPhlvIxakEWg: return mic3MEN709xOkrjD5ZvbGIlX6
	F8sMZxaDjrQpfXdgP = I3InS4QiTJ5K(zk26NlshEwIGpZbRdSrFHB,{},showDialogs)
	if F8sMZxaDjrQpfXdgP:
		M8t6k5zRU43nhgwBpoEImNK1d = S9Y5kUoRga3EVN.path.join(LLjS8IZtzBGTW,nWpLJsUZe3d4zrBOMITDK6)
		Nam0DyfXK5(M8t6k5zRU43nhgwBpoEImNK1d,gyd2rf0UR5,mic3MEN709xOkrjD5ZvbGIlX6)
		import zipfile as bsPnEtweGWhpLAvM,io as UUvZksN2oymRAzGQdhlJwK
		yGXA1bpMYRTOJesaol2FfnvchU3kj = UUvZksN2oymRAzGQdhlJwK.BytesIO(F8sMZxaDjrQpfXdgP)
		try:
			XZOSJAdUQFjaC8crHD = bsPnEtweGWhpLAvM.ZipFile(yGXA1bpMYRTOJesaol2FfnvchU3kj)
			XZOSJAdUQFjaC8crHD.extractall(LLjS8IZtzBGTW)
			jHWkt18govGwY7iUbduAfxCyRc.sleep(CH7RKuDVzN9f06q8MtXPhlvIxakEWg)
			FpGenVlw4Tzxi2WY3JuXcb.executebuiltin(C3ZK1pu4rfmj8TsWUtBaM(u"࡚ࠫࡶࡤࡢࡶࡨࡐࡴࡩࡡ࡭ࡃࡧࡨࡴࡴࡳࠨጅ"))
			jHWkt18govGwY7iUbduAfxCyRc.sleep(CH7RKuDVzN9f06q8MtXPhlvIxakEWg)
			HH2hLvGCD3zfk = h9MLKcOfuIq76rPXm(nWpLJsUZe3d4zrBOMITDK6)
		except: HH2hLvGCD3zfk = mic3MEN709xOkrjD5ZvbGIlX6
	if showDialogs:
		if HH2hLvGCD3zfk: u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,OzU6t0qcH7MQabeBYK8vgoG(u"ࠬะๅࠡส้ะฬำࠠหอห๎ฯࠦวๅวูหๆฯࠠศๆ่฻้๎ศสࠩጆ"))
		else: u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,owbMhINBQsmx70guApW(u"࠭ไๅลึๅࠥ็ิๅฬࠣ฽๊๊๊สࠢอฯอ๐สࠡษ็ษ฻อแสࠢส่๊฽ไ้สฬࠫጇ"))
	return HH2hLvGCD3zfk
def ssb9ApI7G2wYURJ8mfhO(nWpLJsUZe3d4zrBOMITDK6,showDialogs=gyd2rf0UR5):
	if showDialogs==HQmDERMFjx: showDialogs = gyd2rf0UR5
	FFSQh2CInVOK9o0GqmBlRTkdXs5M1 = I1IqvVHG2w7RygSK([nWpLJsUZe3d4zrBOMITDK6])
	sbiHpjONEB,q43NfJTxCgyj5FaQl7otXB9 = FFSQh2CInVOK9o0GqmBlRTkdXs5M1[nWpLJsUZe3d4zrBOMITDK6]
	if q43NfJTxCgyj5FaQl7otXB9:
		HH2hLvGCD3zfk = gyd2rf0UR5
		if showDialogs: u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,mg3CbXMA2ouZzQDhRqB(u"ࠧโฯุࠤฬ๊ลืษไอࠥࡢ࡮ࠡࠩገ")+nWpLJsUZe3d4zrBOMITDK6+mg3CbXMA2ouZzQDhRqB(u"ࠨࠢ࡟ࡲࠥํะ่ࠢฦ่ส฼วโหࠣ฽๋ีใࠡ็๋ะํีษ๊่ࠡๅ฾๊ษ๊ࠡฯห์ุษࠡๆ็หุะฮะษ่ࠫጉ"))
	else:
		HH2hLvGCD3zfk = mic3MEN709xOkrjD5ZvbGIlX6
		N7gs9UBCeDR3 = HUJZy0SrTbBYv1(X2crmy67eZpkGTRd(u"ࠩࡦࡩࡳࡺࡥࡳࠩጊ"),HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,HQmDERMFjx+nWpLJsUZe3d4zrBOMITDK6+CDwSWB4v39N7(u"ࠪࠤࡡࡴ࡜࡯๊ࠢิ์ࠦรๅวูหๆฯฺ่ࠠา็ࠥเ๊า่ࠢๅ฾๊ษࠡล๋ࠤ฿๐ัࠡ็๋ะํีษ๊ࠡส่อืๆศ็ฯࠤอำวอห่ࠣ์อࠠ࠯๊่ࠢࠥะั๋ัࠣฮะฮ๊ห๋ࠢฮๆ฿๊ๅ๊ࠢิ์ࠦวๅวูหๆฯࠠศๆล๊ࠥลࠧጋ"))
		if N7gs9UBCeDR3==EAVanJj1ers2GQud(u"࠷ᏼ"):
			FpGenVlw4Tzxi2WY3JuXcb.executebuiltin(nz8x32hX0qcjUPFZk5RdJsiwED(u"ࠫࡎࡴࡳࡵࡣ࡯ࡰࡆࡪࡤࡰࡰࠫࠫጌ")+nWpLJsUZe3d4zrBOMITDK6+OzU6t0qcH7MQabeBYK8vgoG(u"ࠬ࠯ࠧግ"))
			jHWkt18govGwY7iUbduAfxCyRc.sleep(ELfMeDTIFhJt685K(u"࠱ᏽ"))
			FpGenVlw4Tzxi2WY3JuXcb.executebuiltin(mg3CbXMA2ouZzQDhRqB(u"࠭ࡓࡦࡰࡧࡇࡱ࡯ࡣ࡬ࠪ࠴࠵࠮࠭ጎ"))
			jHWkt18govGwY7iUbduAfxCyRc.sleep(n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"࠲᏾"))
			while FpGenVlw4Tzxi2WY3JuXcb.getCondVisibility(YJxaX0MQOHb8oyCBFdnIAe(u"ࠧࡘ࡫ࡱࡨࡴࡽ࠮ࡊࡵࡄࡧࡹ࡯ࡶࡦࠪࡳࡶࡴ࡭ࡲࡦࡵࡶࡨ࡮ࡧ࡬ࡰࡩࠬࠫጏ")): jHWkt18govGwY7iUbduAfxCyRc.sleep(pCTzbw4GyVJHjkcIMQ(u"࠳᏿"))
			HH2hLvGCD3zfk = h9MLKcOfuIq76rPXm(nWpLJsUZe3d4zrBOMITDK6)
			if showDialogs and HH2hLvGCD3zfk: u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"ࠨฬ่ࠤๆำีࠡษ็ษ฻อแสࠢส่๊฽ไ้สฬࠤํํ๊ࠡษ็ฦ๋ࠦฬศ้ีอ๊ࠥไศีอาิอๅࠨጐ"))
			elif showDialogs: u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,ShnRVsifKtc60zqQ(u"ࠩไุ้ࠦแ๋ࠢอฯอ๐สࠡล๋ࠤฯ็ู๋ๆࠣวํࠦสฮัํฯࠥอไฦุสๅฮࠦวๅ็ฺ่ํฮษࠡ࠰ࠣ์ฬ๊อๅ๊ࠢ์ࠥะหษ์อ๋ฬ่ࠦหใ฼๎้ํวࠡ็้ࠤำอัอࠢส่อืๆศ็ฯࠫ጑"))
	return HH2hLvGCD3zfk
def Vh0o3CxNYQmJ4ySRt(showDialogs):
	if not showDialogs: N7gs9UBCeDR3 = gyd2rf0UR5
	else: N7gs9UBCeDR3 = HUJZy0SrTbBYv1(CDwSWB4v39N7(u"ࠪࡧࡪࡴࡴࡦࡴࠪጒ"),HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,CDwSWB4v39N7(u"ࠫอืๆศ็ฯࠤ่๎ฯ๋ࠢํๆํ๋ࠠษ฻่่๏ฯࠠหฯา๎ะࠦฬๆ์฼ࠤฬ๊ลืษไหฯࠦสๅไสส๏อࠠไๆࠣ࠶࠹ࠦำศ฻ฬࠤํ๊ใ็่้่ࠢ์ࠠฦฮิหฦํวࠡษ็ฦ๋ࠦ࠮้ࠡ็ࠤฯื๊ะࠢส่ว์ࠠฤ่ࠣฮ฼๊ศࠡ็้ࠤ่๎ฯ๋ࠢไัฺ่ࠦหฯา๎ะࠦฬๆ์฼ࠤฬ๊ลืษไหฯࠦฟࠨጓ"))
	if N7gs9UBCeDR3==LHX65I9nkx0PstgcVY24uSi(u"࠴᐀"):
		FpGenVlw4Tzxi2WY3JuXcb.executebuiltin(cWbkR6iUZsnJQj14(u"࡛ࠬࡰࡥࡣࡷࡩࡆࡪࡤࡰࡰࡕࡩࡵࡵࡳࠨጔ"))
		if showDialogs:
			u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,dBi72erQEtKDOwjNFaoAgSP(u"࠭สๆࠢศีุอไูࠡ็ฬࠥหไ๊ࠢหี๋อๅอࠢๆ์ิ๐ࠠศๆำ๎ࠥ็๊ࠡฮ๊หื้ࠠๅๅํࠤ๏่่ๆࠢหฮาี๊ฬࠢฯ้๏฿ࠠฦุสๅฬะࠠไ๊า๎ࠥ࠴ࠠษ็สࠤๆ๐็ศࠢอัิ๐ห้ࠡำหࠥอไษำ้ห๊า้ࠠฬะำ๏ัࠠๆีอ์ิ฿ฺࠠ็สำࠥ࠴๋ࠠำฯํࠥหูุษฤࠤ่๎ฯ๋ࠢ࠸ࠤิ่ววไࠣวํࠦรไอิࠤ้้๊ࠡ์้๋๏ูࠦๆๆํอࠥอไหฯา๎ะ࠭ጕ"))
	return
def nnEKsFRwX5ldCQx():
	X8X1TJW3AmVdy0ZrFvqjDba7Bg2(rDy4FoKpEOsXfT8WZjli,knTyjJ0sGIzuwbxRae(u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࡢ࠵ࠬ጖"),U0VwOviFaYPz2QGs45mJhMXf7Zk(u"ࠨࡃࡏࡐࡤࡇࡄࡅࡑࡑࡗࡤ࡞ࡍࡍࠩ጗"))
	SCkwQfWsTo2p1x7()
	f63nZaUBvzyFbHiVcte2Dk = FrT70Bs1hOfuoS5LCI2cYv6gJn8()
	if f63nZaUBvzyFbHiVcte2Dk:
		HMA5Z9hdu0KrfND(gyd2rf0UR5)
		Vh0o3CxNYQmJ4ySRt(gyd2rf0UR5)
		dXUwsnOGKBF57cNaok(mic3MEN709xOkrjD5ZvbGIlX6)
	return
def h9MLKcOfuIq76rPXm(nWpLJsUZe3d4zrBOMITDK6):
	zLZUkrP7ac5 = FpGenVlw4Tzxi2WY3JuXcb.executeJSONRPC(EAVanJj1ers2GQud(u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡃࡧࡨࡴࡴࡳ࠯ࡕࡨࡸࡆࡪࡤࡰࡰࡈࡲࡦࡨ࡬ࡦࡦࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡣࡧࡨࡴࡴࡩࡥࠤ࠽ࠦࠬጘ")+nWpLJsUZe3d4zrBOMITDK6+k4IUieraScH9DV1N7pJgQosYAx5l(u"ࠪࠦ࠱ࠨࡥ࡯ࡣࡥࡰࡪࡪࠢ࠻ࡶࡵࡹࡪࢃࡽࠨጙ"))
	succeeded = gyd2rf0UR5 if JJA7fypmZFVlazvNI(u"ࠫࡔࡑࠧጚ") in zLZUkrP7ac5 else mic3MEN709xOkrjD5ZvbGIlX6
	return succeeded
def C8GtJiuSnZkyzc3(nWpLJsUZe3d4zrBOMITDK6):
	zLZUkrP7ac5 = FpGenVlw4Tzxi2WY3JuXcb.executeJSONRPC(EF2tvxZHz5n4UruPhaViXKycI6SQR(u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡆࡪࡤࡰࡰࡶ࠲ࡘ࡫ࡴࡂࡦࡧࡳࡳࡋ࡮ࡢࡤ࡯ࡩࡩࠨࠬࠣ࡫ࡧࠦ࠿࠷ࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡦࡪࡤࡰࡰ࡬ࡨࠧࡀࠢࠨጛ")+nWpLJsUZe3d4zrBOMITDK6+owbMhINBQsmx70guApW(u"࠭ࠢ࠭ࠤࡨࡲࡦࡨ࡬ࡦࡦࠥ࠾࡫ࡧ࡬ࡴࡧࢀࢁࠬጜ"))
	succeeded = gyd2rf0UR5 if EF2tvxZHz5n4UruPhaViXKycI6SQR(u"ࠧࡐࡍࠪጝ") in zLZUkrP7ac5 else mic3MEN709xOkrjD5ZvbGIlX6
	return succeeded
def axgV1MLjKPtvr(nWpLJsUZe3d4zrBOMITDK6,showDialogs,wf1WuEhyrVj8L7eFMvR0BnlGpISo,GN8T3gF7SozjaZidm=None):
	N7gs9UBCeDR3,succeeded,dSCqrTMaOHfP3z4U5V,y4kxFQma6M8B2gU0qWpT = gyd2rf0UR5,mic3MEN709xOkrjD5ZvbGIlX6,ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨጞ"),HQmDERMFjx
	if not GN8T3gF7SozjaZidm: GN8T3gF7SozjaZidm = FBqpsWQkStgN([nWpLJsUZe3d4zrBOMITDK6])
	if nWpLJsUZe3d4zrBOMITDK6 in list(GN8T3gF7SozjaZidm.keys()):
		f63nZaUBvzyFbHiVcte2Dk,y4kxFQma6M8B2gU0qWpT,PLKo98Wyrq015X,PD7gQUCAlWcs,QeVRl61G0LStT5DxIMq,RGzAaJWpFcMkTS4H16YKht8jbluZ2x,zk26NlshEwIGpZbRdSrFHB = GN8T3gF7SozjaZidm[nWpLJsUZe3d4zrBOMITDK6]
		if RGzAaJWpFcMkTS4H16YKht8jbluZ2x==C3ZK1pu4rfmj8TsWUtBaM(u"ࠩࡪࡳࡴࡪࠧጟ"):
			succeeded,dSCqrTMaOHfP3z4U5V = gyd2rf0UR5,mgLADoQ1pbtY(u"ࠪࡲࡴࡺࡨࡪࡰࡪࠫጠ")
			if wf1WuEhyrVj8L7eFMvR0BnlGpISo and showDialogs:
				N7gs9UBCeDR3 = HUJZy0SrTbBYv1(HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,EF2tvxZHz5n4UruPhaViXKycI6SQR(u"ࠫั๐ฯࠡฮาหࠥ࠴࠮ࠡๅ๋ำ๏๊ࠦิฬัำ๊ࠦรฯำࠣษฺีวา่ࠢฮํ็ัࠡใํࠤ๊๎วใ฻ุ้ࠣะ่ะ฻ࠣ฽๊อฯࠡๆ๊ิ์ࠦวๅวูหๆฯ࡜࡯࡞ࡱࠫጡ")+nWpLJsUZe3d4zrBOMITDK6+mgLADoQ1pbtY(u"ࠬࡢ࡮࡝ࡰ๊่ࠥะั๋ัࠣษ฾อฯสࠢอฯอ๐ส้ࠡำ๋ࠥอไฦุสๅฮࠦๅาหࠣวำื้ࠨጢ"))
				if N7gs9UBCeDR3:
					succeeded = RLcSMfNngFDO1maptW6sJKd(nWpLJsUZe3d4zrBOMITDK6,zk26NlshEwIGpZbRdSrFHB,mic3MEN709xOkrjD5ZvbGIlX6)
					if succeeded:
						dSCqrTMaOHfP3z4U5V = A0aqj9uclgOtByJ6F4bz(u"࠭ࡲࡦ࡫ࡱࡷࡹࡧ࡬࡭ࡧࡧࠫጣ")
						if showDialogs: u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,Tcf5Ppn9UajDbzyM(u"ࠧอ์าࠤัีวࠡ࠰࠱ࠤฬ๊ลืษไอ้ࠥว็ฬ้ࠣํา่ะหࠣ࠲࠳่ࠦใษ่ࠤฬ๊ศา่ส้ัࠦศฦ฻สำฮࠦสฬสํฮ์อ࡜࡯࡞ࡱࠫጤ")+nWpLJsUZe3d4zrBOMITDK6)
					else:
						dSCqrTMaOHfP3z4U5V = EF2tvxZHz5n4UruPhaViXKycI6SQR(u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨጥ")
						u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,nz8x32hX0qcjUPFZk5RdJsiwED(u"ࠩ็่ศูแࠡ࠰࠱ࠤฬ๊ศา่ส้ัࠦไๆࠢํืฯ฽ฺ๊ࠢศ฽ฬีษࠡฬฮฬ๏ะ่ࠠา๊ࠤฬ๊ลืษไอࡡࡴ࡜࡯ࠩጦ")+nWpLJsUZe3d4zrBOMITDK6)
		else:
			if showDialogs:
				if RGzAaJWpFcMkTS4H16YKht8jbluZ2x==SODvU3Ibq5VzC(u"ࠪࡨ࡮ࡹࡡࡣ࡮ࡨࡨࠬጧ"): wwpQTfixYD23X = CDwSWB4v39N7(u"๊ࠫะ่ใใฬࠫጨ")
				elif RGzAaJWpFcMkTS4H16YKht8jbluZ2x==PPAUFrY8cduRT(u"ࠬࡵ࡬ࡥࠩጩ"): wwpQTfixYD23X = nz8x32hX0qcjUPFZk5RdJsiwED(u"࠭โะ์่อࠬጪ")
				elif RGzAaJWpFcMkTS4H16YKht8jbluZ2x==SODvU3Ibq5VzC(u"ࠧ࡮࡫ࡶࡷ࡮ࡴࡧࠨጫ"): wwpQTfixYD23X = k4IUieraScH9DV1N7pJgQosYAx5l(u"ࠨ฼ํี๋ࠥหษฬฬࠫጬ")
				N7gs9UBCeDR3 = HUJZy0SrTbBYv1(HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,CDwSWB4v39N7(u"๊ࠩิ์ࠦวๅวูหๆฯࠠࠨጭ")+wwpQTfixYD23X+X2crmy67eZpkGTRd(u"ࠪࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡวุ่ฬำ่ࠠา๊ࠤฬ๊ๅีๅ็อࠥลࠡ࡝ࡰ࡟ࡲࠬጮ")+nWpLJsUZe3d4zrBOMITDK6)
			if not N7gs9UBCeDR3: dSCqrTMaOHfP3z4U5V = ELfMeDTIFhJt685K(u"ࠫࡨࡧ࡮ࡤࡧ࡯ࡩࡩ࠭ጯ")
			else:
				if RGzAaJWpFcMkTS4H16YKht8jbluZ2x==EF2tvxZHz5n4UruPhaViXKycI6SQR(u"ࠬࡪࡩࡴࡣࡥࡰࡪࡪࠧጰ"):
					succeeded = h9MLKcOfuIq76rPXm(nWpLJsUZe3d4zrBOMITDK6)
					if succeeded:
						dSCqrTMaOHfP3z4U5V = OzU6t0qcH7MQabeBYK8vgoG(u"࠭ࡥ࡯ࡣࡥࡰࡪࡪࠧጱ")
						if showDialogs: u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,EAVanJj1ers2GQud(u"ࠧอ์าࠤัีวࠡ࠰࠱ࠤฬ๊ลืษไอ้ࠥว็ฬ้ࠣฯ๎โโหࠣ࠲࠳่ࠦใษ่ࠤฬ๊ศา่ส้ัࠦศหึ฽๎้ํว࡝ࡰ࡟ࡲࠬጲ")+nWpLJsUZe3d4zrBOMITDK6)
					elif showDialogs: u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,k4IUieraScH9DV1N7pJgQosYAx5l(u"ࠨๆ็วุ็ࠠ࠯࠰ࠣห้หึศใฬࠤ๊ะ่ใใฬࠤ࠳࠴้ࠠๆ่ࠤ๏ูสุ์฼ࠤฬ๊ศา่ส้ัࠦสี฼ํ่์อ࡜࡯࡞ࡱࠫጳ")+nWpLJsUZe3d4zrBOMITDK6)
				elif RGzAaJWpFcMkTS4H16YKht8jbluZ2x in [JJA7fypmZFVlazvNI(u"ࠩࡲࡰࡩ࠭ጴ"),ssnfOzb16wVog9GKdqcXR3JC7ktSPA(u"ࠪࡱ࡮ࡹࡳࡪࡰࡪࠫጵ")]:
					succeeded = RLcSMfNngFDO1maptW6sJKd(nWpLJsUZe3d4zrBOMITDK6,zk26NlshEwIGpZbRdSrFHB,mic3MEN709xOkrjD5ZvbGIlX6)
					if succeeded:
						if RGzAaJWpFcMkTS4H16YKht8jbluZ2x==nz8x32hX0qcjUPFZk5RdJsiwED(u"ࠫࡴࡲࡤࠨጶ"): dSCqrTMaOHfP3z4U5V = cWbkR6iUZsnJQj14(u"ࠬࡻࡰࡥࡣࡷࡩࡩ࠭ጷ")
						elif RGzAaJWpFcMkTS4H16YKht8jbluZ2x==LHX65I9nkx0PstgcVY24uSi(u"࠭࡭ࡪࡵࡶ࡭ࡳ࡭ࠧጸ"): dSCqrTMaOHfP3z4U5V = owbMhINBQsmx70guApW(u"ࠧࡪࡰࡶࡸࡦࡲ࡬ࡦࡦࠪጹ")
						y4kxFQma6M8B2gU0qWpT = PD7gQUCAlWcs
						if showDialogs:
							if dSCqrTMaOHfP3z4U5V==LHX65I9nkx0PstgcVY24uSi(u"ࠨࡷࡳࡨࡦࡺࡥࡥࠩጺ"): u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,owbMhINBQsmx70guApW(u"ࠩฯ๎ิࠦฬะษࠣ࠲࠳ࠦวๅวูหๆฯࠠไษ้ฮ่ࠥฯ๋็ฬࠤ࠳࠴้ࠠษ็ฬึ์วๆฮࠣๆฬ๋ࠠษฬะำ๏ั็ศ࡞ࡱࡠࡳ࠭ጻ")+nWpLJsUZe3d4zrBOMITDK6)
							elif dSCqrTMaOHfP3z4U5V==OzU6t0qcH7MQabeBYK8vgoG(u"ࠪ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩ࠭ጼ"): u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,mg3CbXMA2ouZzQDhRqB(u"ࠫั๐ฯࠡฮาหࠥ࠴࠮ࠡษ็ษ฻อแสࠢ็้ࠥะใ็่ࠢ์ั๎ฯสࠢไ๎้่ࠥะ์ࠣ࠲࠳่ࠦศๆหี๋อๅอࠢๅห๊ࠦศหอห๎ฯํว࡝ࡰ࡟ࡲࠬጽ")+nWpLJsUZe3d4zrBOMITDK6)
					elif showDialogs: u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,LHX65I9nkx0PstgcVY24uSi(u"๊ࠬไฤีไࠤ࠳࠴ࠠศๆหี๋อๅอࠢ็้ࠥ๐ำหูํ฽ࠥะอะ์ฮࠤศ๎ࠠหอห๎ฯࠦ็ั้ࠣห้หึศใฬࡠࡳࡢ࡮ࠨጾ")+nWpLJsUZe3d4zrBOMITDK6)
	elif showDialogs: u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,maUl7SPesynF1j(u"࠭ไๅลึๅࠥ࠴࠮้ࠡำ๋ࠥอไฦุสๅฮฺ๋ࠦำ้ࠣํา่ะหࠣๅ๏ࠦๅิฬ๋ำ฾ูࠦๆษาࠤ࠳࠴้ࠠๆ๊ิฬࠦไศࠢํืฯ฽ฺ๊ࠢส่อืๆศ็ฯࠤศ์๋ࠠไ๋้ࠥฮสฬสํฮࠥํะ่ࠢส่ส฼วโหࠣวํࠦสฮัํฯ์อ࡜࡯࡞ࡱࠫጿ")+nWpLJsUZe3d4zrBOMITDK6)
	return succeeded,dSCqrTMaOHfP3z4U5V,y4kxFQma6M8B2gU0qWpT
def yukl12eKA0P(nWpLJsUZe3d4zrBOMITDK6,showDialogs,mw50eKDsdYSb4gx8BJtaZ6R2hjClL):
	YY8cXpZoDLTOext = TGjo1FbB2IuhVeN985KPDJ7LZaOQ.connect(i1lgL8sKvZXdzntTSxmYc7yW5)
	YY8cXpZoDLTOext.text_factory = str
	qK0lfFmPQ8GCS5w3RVXz9ZyHxe = YY8cXpZoDLTOext.cursor()
	succeeded,X9XiqGMKzHSOfh6jF4uDJcsCRQ = gyd2rf0UR5,mic3MEN709xOkrjD5ZvbGIlX6
	try:
		XqoSuO3NYGC0QrWsIL = pCTzbw4GyVJHjkcIMQ(u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥࠩፀ")
		qK0lfFmPQ8GCS5w3RVXz9ZyHxe.execute(C3ZK1pu4rfmj8TsWUtBaM(u"ࠨࡕࡈࡐࡊࡉࡔࠡࡱࡵ࡭࡬࡯࡮ࠡࡈࡕࡓࡒࠦࡩ࡯ࡵࡷࡥࡱࡲࡥࡥ࡚ࠢࡌࡊࡘࡅࠡࡣࡧࡨࡴࡴࡉࡅࠢࡀࠤࠧ࠭ፁ")+nWpLJsUZe3d4zrBOMITDK6+LHX65I9nkx0PstgcVY24uSi(u"ࠩࠥࠤࡀ࠭ፂ"))
		nWfIEVyr2pXP96s84jKJ = qK0lfFmPQ8GCS5w3RVXz9ZyHxe.fetchall()
		if nWfIEVyr2pXP96s84jKJ and XqoSuO3NYGC0QrWsIL not in str(nWfIEVyr2pXP96s84jKJ): qK0lfFmPQ8GCS5w3RVXz9ZyHxe.execute(LHX65I9nkx0PstgcVY24uSi(u"࡙ࠪࡕࡊࡁࡕࡇࠣ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩࠦࡓࡆࡖࠣࡳࡷ࡯ࡧࡪࡰࠣࡁࠥࠨࠧፃ")+XqoSuO3NYGC0QrWsIL+YJxaX0MQOHb8oyCBFdnIAe(u"ࠫࠧࠦࡗࡉࡇࡕࡉࠥࡧࡤࡥࡱࡱࡍࡉࠦ࠽ࠡࠤࠪፄ")+nWpLJsUZe3d4zrBOMITDK6+JJA7fypmZFVlazvNI(u"ࠬࠨࠠ࠼ࠩፅ"))
		QY0UWOJqxrAtbHncazy = pCTzbw4GyVJHjkcIMQ(u"࠭ࡢ࡭ࡣࡦ࡯ࡱ࡯ࡳࡵࠩፆ") if C6H1qXua3SMQiIrzxNvJWZE else JJA7fypmZFVlazvNI(u"ࠧࡶࡲࡧࡥࡹ࡫࡟ࡳࡷ࡯ࡩࡸ࠭ፇ")
		qK0lfFmPQ8GCS5w3RVXz9ZyHxe.execute(cWbkR6iUZsnJQj14(u"ࠨࡕࡈࡐࡊࡉࡔࠡࠬࠣࡊࡗࡕࡍࠡࠩፈ")+QY0UWOJqxrAtbHncazy+CDwSWB4v39N7(u"࡛ࠩࠣࡍࡋࡒࡆࠢࡤࡨࡩࡵ࡮ࡊࡆࠣࡁࠥࠨࠧፉ")+nWpLJsUZe3d4zrBOMITDK6+Tcf5Ppn9UajDbzyM(u"ࠪࠦࠥࡁࠧፊ"))
		nWfIEVyr2pXP96s84jKJ = qK0lfFmPQ8GCS5w3RVXz9ZyHxe.fetchall()
		if nWfIEVyr2pXP96s84jKJ:
			if showDialogs: N7gs9UBCeDR3 = HUJZy0SrTbBYv1(HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,k4IUieraScH9DV1N7pJgQosYAx5l(u"ࠫฬ๊สฮัํฯࠥอไฤ๊อ์๊อส๋ๅํࠤ้หึศใฬࠤࡡࡴࠠࠨፋ")+nWpLJsUZe3d4zrBOMITDK6+pCTzbw4GyVJHjkcIMQ(u"ࠬࠦ࡜࡯࡞ࡱࠤࠬፌ")+ao3Q5jP8H0sMxK2iUYwZGE+ShnRVsifKtc60zqQ(u"࠭ࠠๆฬ๋ๆๆ่ࠦๅษࠣ๎฾๋ไࠡ࠰࠱ࠤ์๊ࠠหำํำࠥะแฺ์็๋ࠥอไร่ࠣรࠦࠧࠠࠨፍ")+cjqzOQ5GXD4kR+n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"ࠧࠡ࡞ࡱࡠࡳࠦสิฬฺ๎฾ࠦล๋ไสๅ์ࠦศิ้๋่ฮูࠦ็ัࠣห้฿่ะหࠣษ้๏่ࠠา๊ࠤฬ๊ิศึฬࠤฬ๊ๅ้ฮ๋ำฮࠦแ๋ࠢๅหห๋ษࠡืํห๋ฯࠠษำ้ห๊าฺࠠ็สำࠬፎ"))
			else: N7gs9UBCeDR3 = CH7RKuDVzN9f06q8MtXPhlvIxakEWg
			if N7gs9UBCeDR3==CH7RKuDVzN9f06q8MtXPhlvIxakEWg:
				X9XiqGMKzHSOfh6jF4uDJcsCRQ = gyd2rf0UR5
				qK0lfFmPQ8GCS5w3RVXz9ZyHxe.execute(mg3CbXMA2ouZzQDhRqB(u"ࠨࡆࡈࡐࡊ࡚ࡅࠡࡈࡕࡓࡒࠦࠧፏ")+QY0UWOJqxrAtbHncazy+knTyjJ0sGIzuwbxRae(u"࡛ࠩࠣࡍࡋࡒࡆࠢࡤࡨࡩࡵ࡮ࡊࡆࠣࡁࠥࠨࠧፐ")+nWpLJsUZe3d4zrBOMITDK6+HDpmv4UXzlf72SK9(u"ࠪࠦࠥࡁࠧፑ"))
		elif mw50eKDsdYSb4gx8BJtaZ6R2hjClL:
			if showDialogs: N7gs9UBCeDR3 = HUJZy0SrTbBYv1(HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,CDwSWB4v39N7(u"ࠫฬ๊สฮัํฯࠥอไฤ๊อ์๊อส๋ๅํࠤ้หึศใฬࠤࡡࡴࠠࠨፒ")+nWpLJsUZe3d4zrBOMITDK6+ShnRVsifKtc60zqQ(u"ࠬࠦ࡜࡯࡞ࡱࠤࠬፓ")+ao3Q5jP8H0sMxK2iUYwZGE+HDpmv4UXzlf72SK9(u"࠭ࠠๆใ฼่ࠥ๎ฺ๊็็ࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡวํๆฬ็็ࠡษ็ฦ๋ࠦฟࠢࠣࠣࠫፔ")+cjqzOQ5GXD4kR+OzU6t0qcH7MQabeBYK8vgoG(u"ࠧࠡ࡞ࡱࡠࡳࠦสิฬฺ๎฾ࠦสโ฻ํ่์ࠦศิ้๋่ฮูࠦ็ัࠣห้฿่ะหࠣษ้๏่ࠠา๊ࠤฬ๊ิศึฬࠤฬ๊ๅ้ฮ๋ำฮࠦแ๋ࠢๅหห๋ษࠡืํห๋ฯࠠษำ้ห๊าฺࠠ็สำࠬፕ"))
			else: N7gs9UBCeDR3 = CH7RKuDVzN9f06q8MtXPhlvIxakEWg
			if N7gs9UBCeDR3==CH7RKuDVzN9f06q8MtXPhlvIxakEWg:
				X9XiqGMKzHSOfh6jF4uDJcsCRQ = gyd2rf0UR5
				if C6H1qXua3SMQiIrzxNvJWZE: qK0lfFmPQ8GCS5w3RVXz9ZyHxe.execute(dBi72erQEtKDOwjNFaoAgSP(u"ࠨࡋࡑࡗࡊࡘࡔࠡࡋࡑࡘࡔࠦࠧፖ")+QY0UWOJqxrAtbHncazy+C3ZK1pu4rfmj8TsWUtBaM(u"ࠩࠣࠬࡦࡪࡤࡰࡰࡌࡈ࠮ࠦࡖࡂࡎࡘࡉࡘࠦࠨࠣࠩፗ")+nWpLJsUZe3d4zrBOMITDK6+YJxaX0MQOHb8oyCBFdnIAe(u"ࠪࠦ࠮ࠦ࠻ࠨፘ"))
				else: qK0lfFmPQ8GCS5w3RVXz9ZyHxe.execute(ELfMeDTIFhJt685K(u"ࠫࡎࡔࡓࡆࡔࡗࠤࡎࡔࡔࡐࠢࠪፙ")+QY0UWOJqxrAtbHncazy+cWbkR6iUZsnJQj14(u"ࠬࠦࠨࡢࡦࡧࡳࡳࡏࡄ࠭ࡷࡳࡨࡦࡺࡥࡓࡷ࡯ࡩ࠮ࠦࡖࡂࡎࡘࡉࡘࠦࠨࠣࠩፚ")+nWpLJsUZe3d4zrBOMITDK6+C3ZK1pu4rfmj8TsWUtBaM(u"࠭ࠢ࠭࠳ࠬࠤࡀ࠭፛"))
	except: succeeded = mic3MEN709xOkrjD5ZvbGIlX6
	YY8cXpZoDLTOext.commit()
	YY8cXpZoDLTOext.close()
	if X9XiqGMKzHSOfh6jF4uDJcsCRQ:
		jHWkt18govGwY7iUbduAfxCyRc.sleep(pCTzbw4GyVJHjkcIMQ(u"࠵ᐁ"))
		FpGenVlw4Tzxi2WY3JuXcb.executebuiltin(owbMhINBQsmx70guApW(u"ࠧࡖࡲࡧࡥࡹ࡫ࡌࡰࡥࡤࡰࡆࡪࡤࡰࡰࡶࠫ፜"))
		jHWkt18govGwY7iUbduAfxCyRc.sleep(n6sfYuHBlVdzgmvpXwR3irON0KIj8(u"࠶ᐂ"))
		if showDialogs:
			if succeeded: u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,Tcf5Ppn9UajDbzyM(u"ࠨ่ฯัฯูࠦๆๆํอࠥหีๅษะࠤฯำฯ๋อࠣห้หึศใฬࠤࡡࡴ࡜࡯ࠩ፝")+nWpLJsUZe3d4zrBOMITDK6)
			else: u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,CDwSWB4v39N7(u"ࠩไุ้ะฺࠠ็็๎ฮࠦลึๆสัࠥะอะ์ฮࠤฬ๊ลืษไอࠥࡢ࡮࡝ࡰࠪ፞")+nWpLJsUZe3d4zrBOMITDK6)
	return X9XiqGMKzHSOfh6jF4uDJcsCRQ
def HB2RpU3Ehf1m4r(ss59hv8PuQJWiKy3BYR7xCndTrZfG,showDialogs,wf1WuEhyrVj8L7eFMvR0BnlGpISo,mw50eKDsdYSb4gx8BJtaZ6R2hjClL):
	GN8T3gF7SozjaZidm = FBqpsWQkStgN(ss59hv8PuQJWiKy3BYR7xCndTrZfG)
	jjHt3ayFgJ5YSq = mic3MEN709xOkrjD5ZvbGIlX6
	for nWpLJsUZe3d4zrBOMITDK6 in ss59hv8PuQJWiKy3BYR7xCndTrZfG:
		succeeded,dSCqrTMaOHfP3z4U5V,y4kxFQma6M8B2gU0qWpT = axgV1MLjKPtvr(nWpLJsUZe3d4zrBOMITDK6,showDialogs,wf1WuEhyrVj8L7eFMvR0BnlGpISo,GN8T3gF7SozjaZidm)
		X9XiqGMKzHSOfh6jF4uDJcsCRQ = yukl12eKA0P(nWpLJsUZe3d4zrBOMITDK6,showDialogs,mw50eKDsdYSb4gx8BJtaZ6R2hjClL)
		if X9XiqGMKzHSOfh6jF4uDJcsCRQ: jjHt3ayFgJ5YSq = gyd2rf0UR5
	if jjHt3ayFgJ5YSq:
		jHWkt18govGwY7iUbduAfxCyRc.sleep(mgLADoQ1pbtY(u"࠷ᐃ"))
		FpGenVlw4Tzxi2WY3JuXcb.executebuiltin(jL1E5AKfwBDv6xmeQtUXcJ3d(u"࡙ࠪࡵࡪࡡࡵࡧࡏࡳࡨࡧ࡬ࡂࡦࡧࡳࡳࡹࠧ፟"))
		jHWkt18govGwY7iUbduAfxCyRc.sleep(KhUG1NV9bln5zXjptqFW6dgo(u"࠱ᐄ"))
	if showDialogs:
		if len(ss59hv8PuQJWiKy3BYR7xCndTrZfG)>dBi72erQEtKDOwjNFaoAgSP(u"࠲ᐅ"): u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,YJxaX0MQOHb8oyCBFdnIAe(u"ࠫฯ๋ࠠษ่ฯหาࠦแฮืࠣะ๊๐ูࠡษ็ษ฻อแศฬࠪ፠"))
		else: u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,pCTzbw4GyVJHjkcIMQ(u"ࠬะๅࠡส้ะฬำࠠโฯุࠤฬ๊ลืษไอࡡࡴ࡜࡯ࠩ፡")+ss59hv8PuQJWiKy3BYR7xCndTrZfG[dBi72erQEtKDOwjNFaoAgSP(u"࠲ᐆ")])
	return
def HMA5Z9hdu0KrfND(showDialogs):
	LtyvRNcd6YZw1BhjHei4u7kAr3f5C = [dBi72erQEtKDOwjNFaoAgSP(u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫ።"),PPAUFrY8cduRT(u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥࠩ፣"),mg3CbXMA2ouZzQDhRqB(u"ࠨࡵࡦࡶ࡮ࡶࡴ࠯࡯ࡲࡨࡺࡲࡥ࠯ࡴࡨࡷࡴࡲࡶࡦࡷࡵࡰࠬ፤"),C3ZK1pu4rfmj8TsWUtBaM(u"ࠩࡶࡧࡷ࡯ࡰࡵ࠰ࡰࡳࡩࡻ࡬ࡦ࠰ࡼࡸ࠲ࡪ࡬ࡱࠩ፥")]
	oYBGgqAfSD0lU = [CDwSWB4v39N7(u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨ࠳ࡵࡴࡩࡧࡵࡷࠬ፦"),KKi79PFqsYB0dWSRgaJ3DyE(u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠴ࡧࡪࡶࡨࡩࠬ፧"),OzU6t0qcH7MQabeBYK8vgoG(u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪ࠮ࡱࡻࡷ࡬ࡴࡴࡡ࡯ࡻࡺ࡬ࡪࡸࡥࠨ፨"),jL1E5AKfwBDv6xmeQtUXcJ3d(u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤ࠯ࡩ࡬ࡸ࡭ࡻࡢࠨ፩"),U0VwOviFaYPz2QGs45mJhMXf7Zk(u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥ࠰ࡪ࡭ࡹ࡫ࡡࠨ፪"),SODvU3Ibq5VzC(u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦ࠱ࡧࡴࡪࡥࡣࡧࡵ࡫ࠬ፫")]
	for nWpLJsUZe3d4zrBOMITDK6 in oYBGgqAfSD0lU: C8GtJiuSnZkyzc3(nWpLJsUZe3d4zrBOMITDK6)
	HB2RpU3Ehf1m4r(LtyvRNcd6YZw1BhjHei4u7kAr3f5C,showDialogs,mic3MEN709xOkrjD5ZvbGIlX6,mic3MEN709xOkrjD5ZvbGIlX6)
	return
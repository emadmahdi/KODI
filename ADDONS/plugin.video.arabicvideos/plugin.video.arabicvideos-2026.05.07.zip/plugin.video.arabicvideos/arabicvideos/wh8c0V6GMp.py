# -*- coding: utf-8 -*-
from FF68kA5BUy import *
HDLtdMAy7wPkl8aKC3O2 = 'CIMA4U'
headers = {'User-Agent':HQmDERMFjx}
EEJvXQzSZNt = '_C4U_'
e2VR8nohduY = Jzthpc2nj5.SITESURLS[HDLtdMAy7wPkl8aKC3O2][0]
FwhZ0nXtpoHTMarf = ['مصارعة حرة','اخري','اخرى','الرئيسية','بدون إختيار','افلام','مسلسلات']
def kk6X5LxpsND(mode,url,text):
	if   mode==420: zLZUkrP7ac5 = afkxo7FyZWB4O6K1eXrs5I()
	elif mode==421: zLZUkrP7ac5 = c8wfGju4CWZm(url,text)
	elif mode==422: zLZUkrP7ac5 = llPpZytTMq2rBh1UJC9u7Oij(url)
	elif mode==423: zLZUkrP7ac5 = XONC9osGSP4fW5HVrhM(url)
	elif mode==424: zLZUkrP7ac5 = ooxUXkcTj5PF4ad2SwYy(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==425: zLZUkrP7ac5 = ooxUXkcTj5PF4ad2SwYy(url,'SPECIFIED_FILTER___'+text)
	elif mode==426: zLZUkrP7ac5 = f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url)
	elif mode==427: zLZUkrP7ac5 = cc8Imp2jUeEJBit1ZVCzk(url)
	elif mode==429: zLZUkrP7ac5 = hm4kawIPKp3oMrC75dJZA9HS2(text)
	else: zLZUkrP7ac5 = False
	return zLZUkrP7ac5
def afkxo7FyZWB4O6K1eXrs5I():
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',e2VR8nohduY,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'CIMA4U-MENU-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	EFDgdaV4WT6U2yotAPX1B = DyVGS3dX0ZxR.findall('href="(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	EFDgdaV4WT6U2yotAPX1B = EFDgdaV4WT6U2yotAPX1B[0].strip(xufJqQcGnhboiVy2wd)
	EFDgdaV4WT6U2yotAPX1B = DpClq35GVjh(EFDgdaV4WT6U2yotAPX1B,'url')
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'بحث في الموقع',HQmDERMFjx,429,HQmDERMFjx,HQmDERMFjx,'_REMEMBERRESULTS_')
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'فلتر محدد',EFDgdaV4WT6U2yotAPX1B,425)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'فلتر كامل',EFDgdaV4WT6U2yotAPX1B,424)
	CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+'الرئيسية',EFDgdaV4WT6U2yotAPX1B,421)
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('NavigationMenu(.*?)</div>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	items = DyVGS3dX0ZxR.findall('href="*(.*?)"*>(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	for vn1grP3y4It9GmVuBbLJfz2A,title in items:
		if title in FwhZ0nXtpoHTMarf: continue
		if '/actors' in vn1grP3y4It9GmVuBbLJfz2A: title = 'أفلام النجوم'
		elif '/netflix' in vn1grP3y4It9GmVuBbLJfz2A: title = 'أفلام ومسلسلات نيتفلكس'
		CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,421)
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'قائمة تفصيلية',EFDgdaV4WT6U2yotAPX1B,427)
	return
def cc8Imp2jUeEJBit1ZVCzk(website=HQmDERMFjx):
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',e2VR8nohduY,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'CIMA4U-MENU-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('FilteringTitle(.*?)PageTitle',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	items = DyVGS3dX0ZxR.findall('data-tax="*(.*?)"* data-id="*(.*?)[">]*<a href="*(.*?)[">]+.*?</div>(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	for WF2vkePC5gbXAGUarcqlpmB3Q,id,vn1grP3y4It9GmVuBbLJfz2A,title in items:
		if title in FwhZ0nXtpoHTMarf: continue
		if 'netflix-movies' in vn1grP3y4It9GmVuBbLJfz2A: title = 'أفلام نيتفلكس'
		elif 'series-netflix' in vn1grP3y4It9GmVuBbLJfz2A: title = 'مسلسلات نيتفلكس'
		CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,421,HQmDERMFjx,HQmDERMFjx,WF2vkePC5gbXAGUarcqlpmB3Q+'|'+id)
	return
def c8wfGju4CWZm(url,KPloNJnsZ2kpHhum1=HQmDERMFjx):
	if '/HomepageLoader/' in url: url = url.strip(xufJqQcGnhboiVy2wd)+'/mpaa/family/'
	items = []
	EFDgdaV4WT6U2yotAPX1B = DpClq35GVjh(url,'url')
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,headers,HQmDERMFjx,HQmDERMFjx,'CIMA4U-TITLES-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	if not KPloNJnsZ2kpHhum1 or '|' in KPloNJnsZ2kpHhum1:
		if '|' not in KPloNJnsZ2kpHhum1: ACIi9pvLt2fm6a = HQmDERMFjx
		else: ACIi9pvLt2fm6a = '/archive/'+KPloNJnsZ2kpHhum1
		qCsgEyvo0U9c5Y7Dj = False
		if 'PinSlider' in CzNPJydxQLfw27tv4ZF8KORAbX5:
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'المميزة',url,421,HQmDERMFjx,HQmDERMFjx,'featured')
			qCsgEyvo0U9c5Y7Dj = True
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('PageTitle(.*?)PageContent',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
			ej8EfB1iZ5Gh3X2gxWtSONH = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
			bbiKcPz2RQOUwS = DyVGS3dX0ZxR.findall('data-tab="(.*?)".*?<span>(.*?)<',ej8EfB1iZ5Gh3X2gxWtSONH,DyVGS3dX0ZxR.DOTALL)
			for AN3P82KeMGg,eyLMq9Enup0jiJT42RDWafg in bbiKcPz2RQOUwS:
				cjfepMobZyFTuwq7WS1EV945L3g = EFDgdaV4WT6U2yotAPX1B+'/ajaxcenter/action/HomepageLoader/tab/'+AN3P82KeMGg+ACIi9pvLt2fm6a+xufJqQcGnhboiVy2wd
				CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+eyLMq9Enup0jiJT42RDWafg,cjfepMobZyFTuwq7WS1EV945L3g,421)
				qCsgEyvo0U9c5Y7Dj = True
		if qCsgEyvo0U9c5Y7Dj: CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	if KPloNJnsZ2kpHhum1=='featured':
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('PinSlider(.*?)MultiFilter',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if not Ut7reR0XioMjOdYWZKsLIuc3TQJmC1: Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('PinSlider(.*?)PageTitle',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1: MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		else: MJ2gSPyTl9hzoi1 = HQmDERMFjx
	elif '/HomepageLoader/' in url or '/searchcenter/' in url:
		MJ2gSPyTl9hzoi1 = CzNPJydxQLfw27tv4ZF8KORAbX5
	elif '/filter/' in url:
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('PageContent(.*?)class="*pagination"*',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	elif '/actors' in url:
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('PageContent(.*?)class="*pagination"*',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('href="*(.*?)[">]+.*?image:url\((.*?)\).*?ActorName">(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	else:
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('Cima4uBlocks(.*?)</li></ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1: MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		else: MJ2gSPyTl9hzoi1 = HQmDERMFjx
	if not items: items = DyVGS3dX0ZxR.findall('class="*MovieBlock"*.*?href="*(.*?)[">]+.*?image:url\((.*?)\).*?image.*?BoxTitleInfo.*?</div></div>(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	if not items: items = DyVGS3dX0ZxR.findall('class="MovieBlock".*?href="(.*?)".*?data-image="(.*?)".*?alt="(.*?)"',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	ORMkTYjJ1p7 = []
	for vn1grP3y4It9GmVuBbLJfz2A,uIGD4vZcP61QNmw78LXqoEpH,title in items:
		if not title: continue
		if '?news=' in vn1grP3y4It9GmVuBbLJfz2A: continue
		title = title.replace('مشاهدة ',HQmDERMFjx)
		title = SVsiEWeRf6oIynqQx8pCrM4Tk(title)
		yTz8SOkAhu24j6apo9BmZHvwWsX = DyVGS3dX0ZxR.findall('(.*?) حلقة \d+',title,DyVGS3dX0ZxR.DOTALL)
		if yTz8SOkAhu24j6apo9BmZHvwWsX and 'حلقة' in title:
			title = '_MOD_' + yTz8SOkAhu24j6apo9BmZHvwWsX[0]
			if title not in ORMkTYjJ1p7:
				CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,422,uIGD4vZcP61QNmw78LXqoEpH)
				ORMkTYjJ1p7.append(title)
		elif '/actor/' in vn1grP3y4It9GmVuBbLJfz2A: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,421,uIGD4vZcP61QNmw78LXqoEpH)
		else: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,422,uIGD4vZcP61QNmw78LXqoEpH)
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('pagination(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 and KPloNJnsZ2kpHhum1!='featured':
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('href=[\'\"](.*?)[\'\"]>(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,title in items:
			title = SVsiEWeRf6oIynqQx8pCrM4Tk(title)
			title = title.replace('الصفحة ',HQmDERMFjx)
			if title!=HQmDERMFjx: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'صفحة '+title,vn1grP3y4It9GmVuBbLJfz2A,421)
	cRGB60IvVUsywkjqu = DyVGS3dX0ZxR.findall('</li><a href="(.*?)".*?>(.*?)<',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if cRGB60IvVUsywkjqu:
		vn1grP3y4It9GmVuBbLJfz2A,title = cRGB60IvVUsywkjqu[0]
		CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,421)
	return
def llPpZytTMq2rBh1UJC9u7Oij(url):
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'CIMA4U-SEASONS-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('class="WatchNow".*?href="(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		url = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'CIMA4U-SEASONS-2nd')
		CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('SeasonsSections(.*?)</div></div></div>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if '/tag/' in url or '/actor' in url:
		c8wfGju4CWZm(url)
	elif Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		uIGD4vZcP61QNmw78LXqoEpH = FpGenVlw4Tzxi2WY3JuXcb.getInfoLabel('ListItem.Thumb')
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall("href='(.*?)'>(.*?)<",MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		FmBGkv7WyjNxc2zHTphAP = ['مسلسل','موسم','برنامج','حلقة']
		for vn1grP3y4It9GmVuBbLJfz2A,title in items:
			if any(value in title for value in FmBGkv7WyjNxc2zHTphAP):
				CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,423,uIGD4vZcP61QNmw78LXqoEpH)
			else: CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,426,uIGD4vZcP61QNmw78LXqoEpH)
	else: XONC9osGSP4fW5HVrhM(url)
	return
def XONC9osGSP4fW5HVrhM(url):
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'CIMA4U-EPISODES-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	uIGD4vZcP61QNmw78LXqoEpH = DyVGS3dX0ZxR.findall('"background-image:url\((.*?)\)',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if uIGD4vZcP61QNmw78LXqoEpH: uIGD4vZcP61QNmw78LXqoEpH = uIGD4vZcP61QNmw78LXqoEpH[0]
	else: uIGD4vZcP61QNmw78LXqoEpH = HQmDERMFjx
	OcECt9hJvjmMWBVwNR2 = DyVGS3dX0ZxR.findall('EpisodesSection(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if OcECt9hJvjmMWBVwNR2:
		MJ2gSPyTl9hzoi1 = OcECt9hJvjmMWBVwNR2[0]
		items = DyVGS3dX0ZxR.findall('href="(.*?)"><em>(.*?)<.*?<span>(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,title,yTz8SOkAhu24j6apo9BmZHvwWsX in items:
			title = title+oQpxmKiRPlHeGsLXNrJF78O+yTz8SOkAhu24j6apo9BmZHvwWsX
			CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,426,uIGD4vZcP61QNmw78LXqoEpH)
	else: CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+'رابط التشغيل',url,426,uIGD4vZcP61QNmw78LXqoEpH)
	return
def f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url):
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,headers,HQmDERMFjx,HQmDERMFjx,'CIMA4U-PLAY-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	uM1afLIz5bsjyeJgVxtB9H = vGXnw9VcUN.url
	if C6H1qXua3SMQiIrzxNvJWZE: uM1afLIz5bsjyeJgVxtB9H = uM1afLIz5bsjyeJgVxtB9H.encode(Zex6D4tJE52r)
	EFDgdaV4WT6U2yotAPX1B = DpClq35GVjh(uM1afLIz5bsjyeJgVxtB9H,'url')
	Na8vklCpUGYIzP0bjutWOT = []
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('WatchSection(.*?)</div></div>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('data-link="(.*?)".*? />(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for byuK6758AUTOrmqXNgzYwvSjiDtPV,title in items:
			title = title.strip(oQpxmKiRPlHeGsLXNrJF78O)
			if 'myvid' in title.lower(): title = 'خاص '+title
			vn1grP3y4It9GmVuBbLJfz2A = EFDgdaV4WT6U2yotAPX1B+'/structure/server.php?id='+byuK6758AUTOrmqXNgzYwvSjiDtPV+'?named='+title+'__watch'
			vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A.replace(GsgOT5Vp6UzIy87bh4vQBWdNjAX3c1,HQmDERMFjx)
			Na8vklCpUGYIzP0bjutWOT.append(vn1grP3y4It9GmVuBbLJfz2A)
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('DownloadServers(.*?)</div></div>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('href="(.*?)".*? />(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,title in items:
			title = title.strip(oQpxmKiRPlHeGsLXNrJF78O)
			if 'myvid' in title.lower(): eyLMq9Enup0jiJT42RDWafg = '__خاص'
			else: eyLMq9Enup0jiJT42RDWafg = HQmDERMFjx
			vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A+'?named='+title+'__download'+eyLMq9Enup0jiJT42RDWafg
			vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A.replace(GsgOT5Vp6UzIy87bh4vQBWdNjAX3c1,HQmDERMFjx)
			Na8vklCpUGYIzP0bjutWOT.append(vn1grP3y4It9GmVuBbLJfz2A)
	import NsD5AomUqH
	NsD5AomUqH.NZcWGBmgFEen5hvJjUSIzOCVk7(Na8vklCpUGYIzP0bjutWOT,HDLtdMAy7wPkl8aKC3O2,'video',url)
	return
def hm4kawIPKp3oMrC75dJZA9HS2(search):
	search,GXVabd4sc2u3zp0JI,showDialogs = x0pzMENwy84tBcZvXr(search)
	if search==HQmDERMFjx: search = q156m84QoYrn()
	if search==HQmDERMFjx: return
	search = search.replace(oQpxmKiRPlHeGsLXNrJF78O,'+')
	url = e2VR8nohduY+'/Search?q='+search
	c8wfGju4CWZm(url,'search')
	return
def Fhzowv4lbkLBY(url):
	if 'smartemadfilter' not in url: url = DpClq35GVjh(url,'url')
	else: url = url.split('/smartemadfilter?')[0]
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'CIMA4U-GET_FILTERS_BLOCKS-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('MultiFilter(.*?)PageTitle',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	jnPZuGqg9F5viBUp = DyVGS3dX0ZxR.findall('Hoverable.*?<span>(.*?)</span>.*?"all".*?(data-tax="(.*?)".*?)</ul>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	return jnPZuGqg9F5viBUp
def jfcC3ErztgW9dw(MJ2gSPyTl9hzoi1):
	items = DyVGS3dX0ZxR.findall('data-id="(.*?)".*?</div>(.*?)</a>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	return items
def IeFlCiJPASD4r2Y6NUbX0k7hVRxBa(url):
	Fewh9HDYiA7jJWS5c6dgr = url.split('/smartemadfilter?')[0]
	EdxGKyuW1mvZSBDf0o947h8Rik = DpClq35GVjh(url,'url')
	url = url.replace(Fewh9HDYiA7jJWS5c6dgr,EdxGKyuW1mvZSBDf0o947h8Rik)
	url = url.replace('/smartemadfilter?','/ajaxcenter/action/HomepageLoader/')
	url = url.replace('=',xufJqQcGnhboiVy2wd).replace('&',xufJqQcGnhboiVy2wd)
	url = url+xufJqQcGnhboiVy2wd
	return url
rrdHuNZaRCOviqPmS4szhD0VcEjM3 = ['category','types','release-year']
xSMWIOb5tFvh = ['Quality','release-year','types','category']
def ooxUXkcTj5PF4ad2SwYy(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==HQmDERMFjx: eA0pnTuMvxrdmoRC9zPBh,mwhEr8eXxD21MAKfHUSlB = HQmDERMFjx,HQmDERMFjx
	else: eA0pnTuMvxrdmoRC9zPBh,mwhEr8eXxD21MAKfHUSlB = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if '/category/' in url:
			global rrdHuNZaRCOviqPmS4szhD0VcEjM3
			rrdHuNZaRCOviqPmS4szhD0VcEjM3 = rrdHuNZaRCOviqPmS4szhD0VcEjM3[1:]
		if rrdHuNZaRCOviqPmS4szhD0VcEjM3[0]+'=' not in eA0pnTuMvxrdmoRC9zPBh: WF2vkePC5gbXAGUarcqlpmB3Q = rrdHuNZaRCOviqPmS4szhD0VcEjM3[0]
		for yuYts1RONXgp in range(len(rrdHuNZaRCOviqPmS4szhD0VcEjM3[0:-1])):
			if rrdHuNZaRCOviqPmS4szhD0VcEjM3[yuYts1RONXgp]+'=' in eA0pnTuMvxrdmoRC9zPBh: WF2vkePC5gbXAGUarcqlpmB3Q = rrdHuNZaRCOviqPmS4szhD0VcEjM3[yuYts1RONXgp+1]
		Cm5jWJgr28TlUnoZYHAxdPI3OB = eA0pnTuMvxrdmoRC9zPBh+'&'+WF2vkePC5gbXAGUarcqlpmB3Q+'=0'
		RRDtwVh6LbFiEycHNQkId5Cefmq = mwhEr8eXxD21MAKfHUSlB+'&'+WF2vkePC5gbXAGUarcqlpmB3Q+'=0'
		GSPtdslyxQURmB5obg69VJMY1jE = Cm5jWJgr28TlUnoZYHAxdPI3OB.strip('&')+'___'+RRDtwVh6LbFiEycHNQkId5Cefmq.strip('&')
		J4asIxU7Zyq5PiN2rKEctegFV = jlZtWwMfosJFIKenicqU1(mwhEr8eXxD21MAKfHUSlB,'modified_filters')
		SSHjMN4uegZfb2 = url+'/smartemadfilter?'+J4asIxU7Zyq5PiN2rKEctegFV
	elif type=='ALL_ITEMS_FILTER':
		v2s9V6uhIT0aCjkPOl7iUqZxB = jlZtWwMfosJFIKenicqU1(eA0pnTuMvxrdmoRC9zPBh,'modified_values')
		v2s9V6uhIT0aCjkPOl7iUqZxB = xx9LK4VzpF6IHXSEyhmrQwbg25P0(v2s9V6uhIT0aCjkPOl7iUqZxB)
		if mwhEr8eXxD21MAKfHUSlB!=HQmDERMFjx: mwhEr8eXxD21MAKfHUSlB = jlZtWwMfosJFIKenicqU1(mwhEr8eXxD21MAKfHUSlB,'modified_filters')
		if mwhEr8eXxD21MAKfHUSlB==HQmDERMFjx: SSHjMN4uegZfb2 = url
		else: SSHjMN4uegZfb2 = url+'/smartemadfilter?'+mwhEr8eXxD21MAKfHUSlB
		SSHjMN4uegZfb2 = IeFlCiJPASD4r2Y6NUbX0k7hVRxBa(SSHjMN4uegZfb2)
		CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'أظهار قائمة الفيديو التي تم اختيارها ',SSHjMN4uegZfb2,421,HQmDERMFjx,HQmDERMFjx,'filter')
		CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+' [[   '+v2s9V6uhIT0aCjkPOl7iUqZxB+'   ]]',SSHjMN4uegZfb2,421,HQmDERMFjx,HQmDERMFjx,'filter')
		CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	jnPZuGqg9F5viBUp = Fhzowv4lbkLBY(url)
	dict = {}
	for name,MJ2gSPyTl9hzoi1,DcpbqKxWsJRCSVkQyjf1 in jnPZuGqg9F5viBUp:
		if '/category/' in url and DcpbqKxWsJRCSVkQyjf1=='category': continue
		name = name.replace('--',HQmDERMFjx)
		items = jfcC3ErztgW9dw(MJ2gSPyTl9hzoi1)
		if '=' not in SSHjMN4uegZfb2: SSHjMN4uegZfb2 = url
		if type=='SPECIFIED_FILTER':
			if WF2vkePC5gbXAGUarcqlpmB3Q!=DcpbqKxWsJRCSVkQyjf1: continue
			elif len(items)<2:
				if DcpbqKxWsJRCSVkQyjf1==rrdHuNZaRCOviqPmS4szhD0VcEjM3[-1]:
					url = IeFlCiJPASD4r2Y6NUbX0k7hVRxBa(url)
					c8wfGju4CWZm(url)
				else: ooxUXkcTj5PF4ad2SwYy(SSHjMN4uegZfb2,'SPECIFIED_FILTER___'+GSPtdslyxQURmB5obg69VJMY1jE)
				return
			else:
				SSHjMN4uegZfb2 = IeFlCiJPASD4r2Y6NUbX0k7hVRxBa(SSHjMN4uegZfb2)
				if DcpbqKxWsJRCSVkQyjf1==rrdHuNZaRCOviqPmS4szhD0VcEjM3[-1]: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'الجميع',SSHjMN4uegZfb2,421,HQmDERMFjx,HQmDERMFjx,'filter')
				else: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'الجميع',SSHjMN4uegZfb2,425,HQmDERMFjx,HQmDERMFjx,GSPtdslyxQURmB5obg69VJMY1jE)
		elif type=='ALL_ITEMS_FILTER':
			Cm5jWJgr28TlUnoZYHAxdPI3OB = eA0pnTuMvxrdmoRC9zPBh+'&'+DcpbqKxWsJRCSVkQyjf1+'=0'
			RRDtwVh6LbFiEycHNQkId5Cefmq = mwhEr8eXxD21MAKfHUSlB+'&'+DcpbqKxWsJRCSVkQyjf1+'=0'
			GSPtdslyxQURmB5obg69VJMY1jE = Cm5jWJgr28TlUnoZYHAxdPI3OB+'___'+RRDtwVh6LbFiEycHNQkId5Cefmq
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'الجميع :'+name,SSHjMN4uegZfb2,424,HQmDERMFjx,HQmDERMFjx,GSPtdslyxQURmB5obg69VJMY1jE)
		dict[DcpbqKxWsJRCSVkQyjf1] = {}
		for value,yewoKb5dkfHu1xEZMAsY in items:
			if value=='196533': yewoKb5dkfHu1xEZMAsY = 'أفلام نيتفلكس'
			elif value=='196531': yewoKb5dkfHu1xEZMAsY = 'مسلسلات نيتفلكس'
			if yewoKb5dkfHu1xEZMAsY in FwhZ0nXtpoHTMarf: continue
			dict[DcpbqKxWsJRCSVkQyjf1][value] = yewoKb5dkfHu1xEZMAsY
			Cm5jWJgr28TlUnoZYHAxdPI3OB = eA0pnTuMvxrdmoRC9zPBh+'&'+DcpbqKxWsJRCSVkQyjf1+'='+yewoKb5dkfHu1xEZMAsY
			RRDtwVh6LbFiEycHNQkId5Cefmq = mwhEr8eXxD21MAKfHUSlB+'&'+DcpbqKxWsJRCSVkQyjf1+'='+value
			CEniUGWr4jMy = Cm5jWJgr28TlUnoZYHAxdPI3OB+'___'+RRDtwVh6LbFiEycHNQkId5Cefmq
			title = yewoKb5dkfHu1xEZMAsY+' :'#+dict[DcpbqKxWsJRCSVkQyjf1]['0']
			title = yewoKb5dkfHu1xEZMAsY+' :'+name
			if type=='ALL_ITEMS_FILTER': CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,url,424,HQmDERMFjx,HQmDERMFjx,CEniUGWr4jMy)
			elif type=='SPECIFIED_FILTER' and rrdHuNZaRCOviqPmS4szhD0VcEjM3[-2]+'=' in eA0pnTuMvxrdmoRC9zPBh:
				J4asIxU7Zyq5PiN2rKEctegFV = jlZtWwMfosJFIKenicqU1(RRDtwVh6LbFiEycHNQkId5Cefmq,'modified_filters')
				jDcWv7MAkEV = url+'/smartemadfilter?'+J4asIxU7Zyq5PiN2rKEctegFV
				jDcWv7MAkEV = IeFlCiJPASD4r2Y6NUbX0k7hVRxBa(jDcWv7MAkEV)
				CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,jDcWv7MAkEV,421,HQmDERMFjx,HQmDERMFjx,'filter')
			else: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,url,425,HQmDERMFjx,HQmDERMFjx,CEniUGWr4jMy)
	return
def jlZtWwMfosJFIKenicqU1(Eya9L4IY3GxqtNoVWegDcPuOR,mode):
	Eya9L4IY3GxqtNoVWegDcPuOR = Eya9L4IY3GxqtNoVWegDcPuOR.replace('=&','=0&')
	Eya9L4IY3GxqtNoVWegDcPuOR = Eya9L4IY3GxqtNoVWegDcPuOR.strip('&')
	AAwtDoF34Y890RXse = {}
	if '=' in Eya9L4IY3GxqtNoVWegDcPuOR:
		items = Eya9L4IY3GxqtNoVWegDcPuOR.split('&')
		for A07BpVeRJToLb in items:
			airVhHdqCb6Gf49eERSjv1,value = A07BpVeRJToLb.split('=')
			AAwtDoF34Y890RXse[airVhHdqCb6Gf49eERSjv1] = value
	n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6 = HQmDERMFjx
	for key in xSMWIOb5tFvh:
		if key in list(AAwtDoF34Y890RXse.keys()): value = AAwtDoF34Y890RXse[key]
		else: value = '0'
		if '%' not in value: value = VVkOtyQLzxBr(value)
		if mode=='modified_values' and value!='0': n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6 = n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6+' + '+value
		elif mode=='modified_filters' and value!='0': n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6 = n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6+'&'+key+'='+value
		elif mode=='all': n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6 = n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6+'&'+key+'='+value
	n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6 = n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6.strip(' + ')
	n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6 = n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6.strip('&')
	n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6 = n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6.replace('=0','=')
	return n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6
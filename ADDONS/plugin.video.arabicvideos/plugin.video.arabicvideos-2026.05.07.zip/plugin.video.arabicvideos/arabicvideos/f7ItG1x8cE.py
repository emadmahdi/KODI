# -*- coding: utf-8 -*-
from FF68kA5BUy import *
HDLtdMAy7wPkl8aKC3O2 = 'EGYBESTVIP'
EEJvXQzSZNt = '_EGV_'
e2VR8nohduY = Jzthpc2nj5.SITESURLS[HDLtdMAy7wPkl8aKC3O2][0]
def kk6X5LxpsND(mode,url,zmL397efNlks5uTEV,text):
	if   mode==220: zLZUkrP7ac5 = afkxo7FyZWB4O6K1eXrs5I()
	elif mode==221: zLZUkrP7ac5 = c8wfGju4CWZm(url,zmL397efNlks5uTEV)
	elif mode==222: zLZUkrP7ac5 = REWBU20fyqaLprY(url)
	elif mode==223: zLZUkrP7ac5 = f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url)
	elif mode==224: zLZUkrP7ac5 = ooxUXkcTj5PF4ad2SwYy(url)
	elif mode==229: zLZUkrP7ac5 = hm4kawIPKp3oMrC75dJZA9HS2(text)
	else: zLZUkrP7ac5 = False
	return zLZUkrP7ac5
def afkxo7FyZWB4O6K1eXrs5I():
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'بحث في الموقع',HQmDERMFjx,229,HQmDERMFjx,HQmDERMFjx,'_REMEMBERRESULTS_')
	CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(H5x4Z2qPwR8vXM,'GET',e2VR8nohduY,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'EGYBEST-MENU-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('class="i i-home"(.*?)</div>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('href="(.*?)"(.*?)</a>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,title in items:
			if '</i>' in title: title = title.split('</i>')[1]
			CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,222)
		CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('class="ba(.*?)<script',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('pda bdb"><strong>(.*?)<.*?href="(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		for title,vn1grP3y4It9GmVuBbLJfz2A in items:
			CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,221)
		CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
		items = DyVGS3dX0ZxR.findall('href="(.*?)".*?>(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,title in items:
			if 'html' not in vn1grP3y4It9GmVuBbLJfz2A: continue
			if not vn1grP3y4It9GmVuBbLJfz2A.endswith(xufJqQcGnhboiVy2wd): CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,221)
	return CzNPJydxQLfw27tv4ZF8KORAbX5
def REWBU20fyqaLprY(url):
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(H5x4Z2qPwR8vXM,'GET',url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'EGYBESTVIP-SUBMENU-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('class="rs_scroll"(.*?)</div>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	items = DyVGS3dX0ZxR.findall('href="(.*?)".*?</i>(.*?)</a>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	for vn1grP3y4It9GmVuBbLJfz2A,title in items:
		CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,224)
	return
def ooxUXkcTj5PF4ad2SwYy(url):
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'الجميع',url,221)
	CzNPJydxQLfw27tv4ZF8KORAbX5 = D0GFPwY8ecAVI(H5x4Z2qPwR8vXM,url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'EGYBESTVIP-FILTERS_MENU-1st')
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('class="sub_nav(.*?)id="movies',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('href="(.*?)".+?>(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,title in items:
			if vn1grP3y4It9GmVuBbLJfz2A=='#': name = title
			else:
				title = title + '  :  ' + 'فلتر ' + name
				CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,221)
	else: c8wfGju4CWZm(url)
	return
def c8wfGju4CWZm(url,zmL397efNlks5uTEV='1'):
	if zmL397efNlks5uTEV==HQmDERMFjx: zmL397efNlks5uTEV = '1'
	if '/search' in url or '?' in url: SSHjMN4uegZfb2 = url + '&'
	else: SSHjMN4uegZfb2 = url + '?'
	SSHjMN4uegZfb2 = SSHjMN4uegZfb2 + 'page=' + zmL397efNlks5uTEV
	CzNPJydxQLfw27tv4ZF8KORAbX5 = D0GFPwY8ecAVI(j9uzmBeEyK8,SSHjMN4uegZfb2,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'EGYBESTVIP-TITLES-1st')
	if '/season' in url:
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1=DyVGS3dX0ZxR.findall('class="pda"(.*?)div',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[-1]
	elif '/series/' in url:
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1=DyVGS3dX0ZxR.findall('class="owl-carousel owl-carousel(.*?)div',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	else:
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1=DyVGS3dX0ZxR.findall('id="movies(.*?)</div>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[-1]
	items = DyVGS3dX0ZxR.findall('<a href="(.*?)".*?src="(.*?)".*?title">(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	for vn1grP3y4It9GmVuBbLJfz2A,uIGD4vZcP61QNmw78LXqoEpH,title in items:
		title = SVsiEWeRf6oIynqQx8pCrM4Tk(title)
		if '/movie/' in vn1grP3y4It9GmVuBbLJfz2A or '/episode' in vn1grP3y4It9GmVuBbLJfz2A:
			CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A.rstrip(xufJqQcGnhboiVy2wd),223,uIGD4vZcP61QNmw78LXqoEpH)
		else:
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,221,uIGD4vZcP61QNmw78LXqoEpH)
	if len(items)>=16:
		gzQBmMpCfbDnk4EN6T2WhV0r7UFt = ['/movies','/tv','/search','/trending']
		zmL397efNlks5uTEV = int(zmL397efNlks5uTEV)
		if any(value in url for value in gzQBmMpCfbDnk4EN6T2WhV0r7UFt):
			for MfLEv6gSYUj8dnXubZJh1k4Qy7F in range(0,1000,100):
				if int(zmL397efNlks5uTEV/100)*100==MfLEv6gSYUj8dnXubZJh1k4Qy7F:
					for yuYts1RONXgp in range(MfLEv6gSYUj8dnXubZJh1k4Qy7F,MfLEv6gSYUj8dnXubZJh1k4Qy7F+100,10):
						if int(zmL397efNlks5uTEV/10)*10==yuYts1RONXgp:
							for jxqHdr3mcZW7RauyC4VstM in range(yuYts1RONXgp,yuYts1RONXgp+10,1):
								if not zmL397efNlks5uTEV==jxqHdr3mcZW7RauyC4VstM and jxqHdr3mcZW7RauyC4VstM!=0:
									CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'صفحة '+str(jxqHdr3mcZW7RauyC4VstM),url,221,HQmDERMFjx,str(jxqHdr3mcZW7RauyC4VstM))
						elif yuYts1RONXgp!=0: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'صفحة '+str(yuYts1RONXgp),url,221,HQmDERMFjx,str(yuYts1RONXgp))
						else: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'صفحة '+str(1),url,221,HQmDERMFjx,str(1))
				elif MfLEv6gSYUj8dnXubZJh1k4Qy7F!=0: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'صفحة '+str(MfLEv6gSYUj8dnXubZJh1k4Qy7F),url,221,HQmDERMFjx,str(MfLEv6gSYUj8dnXubZJh1k4Qy7F))
				else: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'صفحة '+str(1),url,221)
	return
def f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url):
	gBzGTxKMSVWFLPvfAI0UZ98D5,Na8vklCpUGYIzP0bjutWOT = [],[]
	CzNPJydxQLfw27tv4ZF8KORAbX5 = D0GFPwY8ecAVI(H5x4Z2qPwR8vXM,url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'EGYBESTVIP-PLAY-1st')
	WWbJG6CrUL4tIRsjpNV = DyVGS3dX0ZxR.findall('<td>التصنيف</td>.*?">(.*?)<',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if WWbJG6CrUL4tIRsjpNV and UzSYuZp3Pnhf1W4wyx7Fc0JX6jNb(HDLtdMAy7wPkl8aKC3O2,url,WWbJG6CrUL4tIRsjpNV): return
	VkUOGoBAPlqgxabLy92HWSTid8I,lLfiZerI7FMkKBjC = HQmDERMFjx,HQmDERMFjx
	XkMR3EvgqdFa,SSkwKLiFYHmobA5286QVEx = CzNPJydxQLfw27tv4ZF8KORAbX5,CzNPJydxQLfw27tv4ZF8KORAbX5
	SSeHgBTkA7IrfNCn = DyVGS3dX0ZxR.findall('show_dl api" href="(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if SSeHgBTkA7IrfNCn:
		for vn1grP3y4It9GmVuBbLJfz2A in SSeHgBTkA7IrfNCn:
			if '/watch/' in vn1grP3y4It9GmVuBbLJfz2A: VkUOGoBAPlqgxabLy92HWSTid8I = vn1grP3y4It9GmVuBbLJfz2A
			elif '/download/' in vn1grP3y4It9GmVuBbLJfz2A: lLfiZerI7FMkKBjC = vn1grP3y4It9GmVuBbLJfz2A
		if VkUOGoBAPlqgxabLy92HWSTid8I!=HQmDERMFjx: XkMR3EvgqdFa = D0GFPwY8ecAVI(H5x4Z2qPwR8vXM,VkUOGoBAPlqgxabLy92HWSTid8I,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'EGYBESTVIP-PLAY-2nd')
		if lLfiZerI7FMkKBjC!=HQmDERMFjx: SSkwKLiFYHmobA5286QVEx = D0GFPwY8ecAVI(H5x4Z2qPwR8vXM,lLfiZerI7FMkKBjC,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'EGYBESTVIP-PLAY-3rd')
	U7irM3L0TbR41aBJY = DyVGS3dX0ZxR.findall('id="video".*?data-src="(.*?)"',XkMR3EvgqdFa,DyVGS3dX0ZxR.DOTALL)
	if U7irM3L0TbR41aBJY:
		SSHjMN4uegZfb2 = U7irM3L0TbR41aBJY[0]
		if SSHjMN4uegZfb2!=HQmDERMFjx and 'uploaded.egybest.download' in SSHjMN4uegZfb2 and '/?id=_' not in SSHjMN4uegZfb2:
			b3L20nx7qwHKTS6so = D0GFPwY8ecAVI(H5x4Z2qPwR8vXM,SSHjMN4uegZfb2,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'EGYBESTVIP-PLAY-4th')
			EsXiQ6bnONg = DyVGS3dX0ZxR.findall('source src="(.*?)" title="(.*?)"',b3L20nx7qwHKTS6so,DyVGS3dX0ZxR.DOTALL)
			if EsXiQ6bnONg:
				for vn1grP3y4It9GmVuBbLJfz2A,RRpfksr1PbZagwCIOJXYNHTo in EsXiQ6bnONg:
					Na8vklCpUGYIzP0bjutWOT.append(vn1grP3y4It9GmVuBbLJfz2A+'?named=ed.egybest.do__watch__mp4__'+RRpfksr1PbZagwCIOJXYNHTo)
			else:
				pYVvlGR1ES0gdtzayiDqb9w = SSHjMN4uegZfb2.split(xufJqQcGnhboiVy2wd)[2]
				Na8vklCpUGYIzP0bjutWOT.append(SSHjMN4uegZfb2+'?named='+pYVvlGR1ES0gdtzayiDqb9w+'__watch')
		elif SSHjMN4uegZfb2!=HQmDERMFjx:
			pYVvlGR1ES0gdtzayiDqb9w = SSHjMN4uegZfb2.split(xufJqQcGnhboiVy2wd)[2]
			Na8vklCpUGYIzP0bjutWOT.append(SSHjMN4uegZfb2+'?named='+pYVvlGR1ES0gdtzayiDqb9w+'__watch')
	TTkctrBquV1EHJDRMhF9m3f7yXdnG = DyVGS3dX0ZxR.findall('<table class="dls_table(.*?)</table>',SSkwKLiFYHmobA5286QVEx,DyVGS3dX0ZxR.DOTALL)
	if TTkctrBquV1EHJDRMhF9m3f7yXdnG:
		TTkctrBquV1EHJDRMhF9m3f7yXdnG = TTkctrBquV1EHJDRMhF9m3f7yXdnG[0]
		qKVpt3czAo7YCM80L5NWGgSj = DyVGS3dX0ZxR.findall('<td>.*?<td>(.*?)<.*?href="(.*?)"',TTkctrBquV1EHJDRMhF9m3f7yXdnG,DyVGS3dX0ZxR.DOTALL)
		if qKVpt3czAo7YCM80L5NWGgSj:
			for RRpfksr1PbZagwCIOJXYNHTo,vn1grP3y4It9GmVuBbLJfz2A in qKVpt3czAo7YCM80L5NWGgSj:
				if 'myegyvip' not in vn1grP3y4It9GmVuBbLJfz2A: continue
				if vn1grP3y4It9GmVuBbLJfz2A.count(xufJqQcGnhboiVy2wd)>=2:
					pYVvlGR1ES0gdtzayiDqb9w = vn1grP3y4It9GmVuBbLJfz2A.split(xufJqQcGnhboiVy2wd)[2]
					Na8vklCpUGYIzP0bjutWOT.append(vn1grP3y4It9GmVuBbLJfz2A+'?named='+pYVvlGR1ES0gdtzayiDqb9w+'__download__mp4__'+RRpfksr1PbZagwCIOJXYNHTo)
	f4fmxb3dPe = []
	for vn1grP3y4It9GmVuBbLJfz2A in Na8vklCpUGYIzP0bjutWOT:
		f4fmxb3dPe.append(vn1grP3y4It9GmVuBbLJfz2A)
	import NsD5AomUqH
	NsD5AomUqH.NZcWGBmgFEen5hvJjUSIzOCVk7(f4fmxb3dPe,HDLtdMAy7wPkl8aKC3O2,'video',url)
	return
def hm4kawIPKp3oMrC75dJZA9HS2(search):
	search,GXVabd4sc2u3zp0JI,showDialogs = x0pzMENwy84tBcZvXr(search)
	if search==HQmDERMFjx: search = q156m84QoYrn()
	if search==HQmDERMFjx: return
	q5qfEX4yA6lDop1 = search.replace(oQpxmKiRPlHeGsLXNrJF78O,'+')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = D0GFPwY8ecAVI(LLwINhcX2RHSWqpmEnz,e2VR8nohduY,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'EGYBESTVIP-SEARCH-1st')
	WjA5SoTH673rqsB4lp0FNQyZe = DyVGS3dX0ZxR.findall('name="_token" value="(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if WjA5SoTH673rqsB4lp0FNQyZe:
		url = e2VR8nohduY+'/search?_token='+WjA5SoTH673rqsB4lp0FNQyZe[0]+'&q='+q5qfEX4yA6lDop1
		c8wfGju4CWZm(url)
	return
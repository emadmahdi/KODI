# -*- coding: utf-8 -*-
from FF68kA5BUy import *
NlTos5YhHEcig6yFMn7Qb42zDvq = 'FAVORITES'
def QyCO8veMRoXDUlzhgd(lXBL3WrM2JFYm,LRHB6UsxIuW):
	if   lXBL3WrM2JFYm==270: USFh9yauLTlCXb2nZIw5tqQmO4dH = oNU0gTtmAYeRpMS(LRHB6UsxIuW)
	else: USFh9yauLTlCXb2nZIw5tqQmO4dH = False
	return USFh9yauLTlCXb2nZIw5tqQmO4dH
def QMkNqYJ7cta0Khv218OAfWVPwdR(wWqEgiB75LpjyPuaDTOU,LRHB6UsxIuW,LhSoca86Yi0w):
	if not wWqEgiB75LpjyPuaDTOU: return
	if   LhSoca86Yi0w=='UP1'	: geK10zUWTX6c(LRHB6UsxIuW,True,CH7RKuDVzN9f06q8MtXPhlvIxakEWg)
	elif LhSoca86Yi0w=='DOWN1'	: geK10zUWTX6c(LRHB6UsxIuW,False,CH7RKuDVzN9f06q8MtXPhlvIxakEWg)
	elif LhSoca86Yi0w=='UP4'	: geK10zUWTX6c(LRHB6UsxIuW,True,ihRKM0HpwdVstIF2ZjuTeCmXG)
	elif LhSoca86Yi0w=='DOWN4'	: geK10zUWTX6c(LRHB6UsxIuW,False,ihRKM0HpwdVstIF2ZjuTeCmXG)
	elif LhSoca86Yi0w=='ADD1'	: WlRpHSymVQh0cLjXrtM1Ux(LRHB6UsxIuW)
	elif LhSoca86Yi0w=='REMOVE1': hN2cAltXGYTzrF0HIDs(LRHB6UsxIuW)
	elif LhSoca86Yi0w=='DELETELIST': lljUyh6zkPamRbSpNvMA8JTd24(LRHB6UsxIuW)
	return
def oNU0gTtmAYeRpMS(LRHB6UsxIuW):
	B1OLI0yCFXjVhAx = UwtKYfXMBEhT()
	if LRHB6UsxIuW in list(B1OLI0yCFXjVhAx.keys()):
		try:
			CbVscamdIKRXGPT8 = B1OLI0yCFXjVhAx[LRHB6UsxIuW]
			if o4bNzIQGYj8En and LRHB6UsxIuW in ['5','11','12','13']:
				for arsOBITUkup7x3eSfEvM,XyOvPTlmBK4hDVjfi,GUiCEYZjm5,lXBL3WrM2JFYm,Hdtu4n2qcfGBjV,JTMSUFcWn0XQa63GBI9qEAk7,NN9niuC7RoqmhkL2,wWqEgiB75LpjyPuaDTOU,xxwvNBlKpYESrqo0hPcdsutR in CbVscamdIKRXGPT8:
					if arsOBITUkup7x3eSfEvM=='video':
						CfgK4s13Q0hZcHyleT2bVJO9('video',ao3Q5jP8H0sMxK2iUYwZGE+'تشغيل من الأعلى إلى الأسفل'+cjqzOQ5GXD4kR,GUiCEYZjm5,lXBL3WrM2JFYm,Hdtu4n2qcfGBjV,JTMSUFcWn0XQa63GBI9qEAk7,NN9niuC7RoqmhkL2,wWqEgiB75LpjyPuaDTOU)
						CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
						break
			for arsOBITUkup7x3eSfEvM,XyOvPTlmBK4hDVjfi,GUiCEYZjm5,lXBL3WrM2JFYm,Hdtu4n2qcfGBjV,JTMSUFcWn0XQa63GBI9qEAk7,NN9niuC7RoqmhkL2,wWqEgiB75LpjyPuaDTOU,xxwvNBlKpYESrqo0hPcdsutR in CbVscamdIKRXGPT8:
				CfgK4s13Q0hZcHyleT2bVJO9(arsOBITUkup7x3eSfEvM,XyOvPTlmBK4hDVjfi,GUiCEYZjm5,lXBL3WrM2JFYm,Hdtu4n2qcfGBjV,JTMSUFcWn0XQa63GBI9qEAk7,NN9niuC7RoqmhkL2,wWqEgiB75LpjyPuaDTOU,xxwvNBlKpYESrqo0hPcdsutR)
		except:
			B1OLI0yCFXjVhAx = DIHm5USjh3aATExn0(qdCNzTivE0olpmk3jUYRc)
			CbVscamdIKRXGPT8 = B1OLI0yCFXjVhAx[LRHB6UsxIuW]
			for arsOBITUkup7x3eSfEvM,XyOvPTlmBK4hDVjfi,GUiCEYZjm5,lXBL3WrM2JFYm,Hdtu4n2qcfGBjV,JTMSUFcWn0XQa63GBI9qEAk7,NN9niuC7RoqmhkL2,wWqEgiB75LpjyPuaDTOU,xxwvNBlKpYESrqo0hPcdsutR in CbVscamdIKRXGPT8:
				CfgK4s13Q0hZcHyleT2bVJO9(arsOBITUkup7x3eSfEvM,XyOvPTlmBK4hDVjfi,GUiCEYZjm5,lXBL3WrM2JFYm,Hdtu4n2qcfGBjV,JTMSUFcWn0XQa63GBI9qEAk7,NN9niuC7RoqmhkL2,wWqEgiB75LpjyPuaDTOU,xxwvNBlKpYESrqo0hPcdsutR)
	return
def WlRpHSymVQh0cLjXrtM1Ux(LRHB6UsxIuW):
	arsOBITUkup7x3eSfEvM,XyOvPTlmBK4hDVjfi,GUiCEYZjm5,lXBL3WrM2JFYm,Hdtu4n2qcfGBjV,JTMSUFcWn0XQa63GBI9qEAk7,NN9niuC7RoqmhkL2,wWqEgiB75LpjyPuaDTOU,xxwvNBlKpYESrqo0hPcdsutR = aBgObvuP24e187(yLjouMD5TmVK7bO0de48BPSGh)
	if LRHB6UsxIuW in ['5','11','12','13'] and arsOBITUkup7x3eSfEvM!='video':
		u0W7PAndK1IXU8rxz2jQaM('','',OO2BXYhI8UPNq6L,'هذا العنصر ليس ملف فيديو .. قوائم التشغيل فائدتها تشغيل الفيديوهات خلف بعضها أوتوماتيكيا .. ولهذا قوائم التشغيل يجب أن تحتوي على فيديوهات فقط')
		return
	LLeOs6Guywp = arsOBITUkup7x3eSfEvM,XyOvPTlmBK4hDVjfi,GUiCEYZjm5,lXBL3WrM2JFYm,Hdtu4n2qcfGBjV,JTMSUFcWn0XQa63GBI9qEAk7,NN9niuC7RoqmhkL2,HQmDERMFjx,xxwvNBlKpYESrqo0hPcdsutR
	B1OLI0yCFXjVhAx = UwtKYfXMBEhT()
	eZtdLPlb7RC6nmpJNz9TFkq = {}
	for RFCNne3zcbXVu2va in list(B1OLI0yCFXjVhAx.keys()):
		if RFCNne3zcbXVu2va!=LRHB6UsxIuW: eZtdLPlb7RC6nmpJNz9TFkq[RFCNne3zcbXVu2va] = B1OLI0yCFXjVhAx[RFCNne3zcbXVu2va]
		else:
			if XyOvPTlmBK4hDVjfi and XyOvPTlmBK4hDVjfi!='..':
				cUMDHEVBQJ = B1OLI0yCFXjVhAx[RFCNne3zcbXVu2va]
				if LLeOs6Guywp in cUMDHEVBQJ:
					svxlAeZ3zBpHXUNTW = cUMDHEVBQJ.index(LLeOs6Guywp)
					del cUMDHEVBQJ[svxlAeZ3zBpHXUNTW]
				eeQRCLMqdaZ = cUMDHEVBQJ+[LLeOs6Guywp]
				eZtdLPlb7RC6nmpJNz9TFkq[RFCNne3zcbXVu2va] = eeQRCLMqdaZ
			else: eZtdLPlb7RC6nmpJNz9TFkq[RFCNne3zcbXVu2va] = B1OLI0yCFXjVhAx[RFCNne3zcbXVu2va]
	if LRHB6UsxIuW not in list(eZtdLPlb7RC6nmpJNz9TFkq.keys()): eZtdLPlb7RC6nmpJNz9TFkq[LRHB6UsxIuW] = [LLeOs6Guywp]
	p1tMwdJEgG = str(eZtdLPlb7RC6nmpJNz9TFkq)
	if HH6mxXjgcrEN1aenMFWQkS: p1tMwdJEgG = p1tMwdJEgG.encode(Zex6D4tJE52r)
	open(qdCNzTivE0olpmk3jUYRc,'wb').write(p1tMwdJEgG)
	return
def hN2cAltXGYTzrF0HIDs(LRHB6UsxIuW):
	arsOBITUkup7x3eSfEvM,XyOvPTlmBK4hDVjfi,GUiCEYZjm5,lXBL3WrM2JFYm,Hdtu4n2qcfGBjV,JTMSUFcWn0XQa63GBI9qEAk7,NN9niuC7RoqmhkL2,wWqEgiB75LpjyPuaDTOU,xxwvNBlKpYESrqo0hPcdsutR = aBgObvuP24e187(yLjouMD5TmVK7bO0de48BPSGh)
	LLeOs6Guywp = arsOBITUkup7x3eSfEvM,XyOvPTlmBK4hDVjfi,GUiCEYZjm5,lXBL3WrM2JFYm,Hdtu4n2qcfGBjV,JTMSUFcWn0XQa63GBI9qEAk7,NN9niuC7RoqmhkL2,HQmDERMFjx,xxwvNBlKpYESrqo0hPcdsutR
	B1OLI0yCFXjVhAx = UwtKYfXMBEhT()
	if LRHB6UsxIuW in list(B1OLI0yCFXjVhAx.keys()) and LLeOs6Guywp in B1OLI0yCFXjVhAx[LRHB6UsxIuW]:
		B1OLI0yCFXjVhAx[LRHB6UsxIuW].remove(LLeOs6Guywp)
		if len(B1OLI0yCFXjVhAx[LRHB6UsxIuW])==o4bNzIQGYj8En: del B1OLI0yCFXjVhAx[LRHB6UsxIuW]
		p1tMwdJEgG = str(B1OLI0yCFXjVhAx)
		if HH6mxXjgcrEN1aenMFWQkS: p1tMwdJEgG = p1tMwdJEgG.encode(Zex6D4tJE52r)
		open(qdCNzTivE0olpmk3jUYRc,'wb').write(p1tMwdJEgG)
	return
def geK10zUWTX6c(LRHB6UsxIuW,anoXuQGO8bLRAp0CeW2Fshc,HupcmM90rsdfqnJwR6xiPAI3tjK):
	arsOBITUkup7x3eSfEvM,XyOvPTlmBK4hDVjfi,GUiCEYZjm5,lXBL3WrM2JFYm,Hdtu4n2qcfGBjV,JTMSUFcWn0XQa63GBI9qEAk7,NN9niuC7RoqmhkL2,wWqEgiB75LpjyPuaDTOU,xxwvNBlKpYESrqo0hPcdsutR = aBgObvuP24e187(yLjouMD5TmVK7bO0de48BPSGh)
	LLeOs6Guywp = arsOBITUkup7x3eSfEvM,XyOvPTlmBK4hDVjfi,GUiCEYZjm5,lXBL3WrM2JFYm,Hdtu4n2qcfGBjV,JTMSUFcWn0XQa63GBI9qEAk7,NN9niuC7RoqmhkL2,HQmDERMFjx,xxwvNBlKpYESrqo0hPcdsutR
	B1OLI0yCFXjVhAx = UwtKYfXMBEhT()
	if LRHB6UsxIuW in list(B1OLI0yCFXjVhAx.keys()):
		cUMDHEVBQJ = B1OLI0yCFXjVhAx[LRHB6UsxIuW]
		if LLeOs6Guywp not in cUMDHEVBQJ: return
		YDwjEeScqd1o2G6xUaf = len(cUMDHEVBQJ)
		for OLRSzDCVZUm in range(o4bNzIQGYj8En,HupcmM90rsdfqnJwR6xiPAI3tjK):
			uFI9olMBzV5vkOfP7HTgsWy4eLR = cUMDHEVBQJ.index(LLeOs6Guywp)
			if anoXuQGO8bLRAp0CeW2Fshc: Oq05LIgPFT2axXemcyuHSk1EAir8 = uFI9olMBzV5vkOfP7HTgsWy4eLR-CH7RKuDVzN9f06q8MtXPhlvIxakEWg
			else: Oq05LIgPFT2axXemcyuHSk1EAir8 = uFI9olMBzV5vkOfP7HTgsWy4eLR+CH7RKuDVzN9f06q8MtXPhlvIxakEWg
			if Oq05LIgPFT2axXemcyuHSk1EAir8>=YDwjEeScqd1o2G6xUaf: Oq05LIgPFT2axXemcyuHSk1EAir8 = Oq05LIgPFT2axXemcyuHSk1EAir8-YDwjEeScqd1o2G6xUaf
			if Oq05LIgPFT2axXemcyuHSk1EAir8<o4bNzIQGYj8En: Oq05LIgPFT2axXemcyuHSk1EAir8 = Oq05LIgPFT2axXemcyuHSk1EAir8+YDwjEeScqd1o2G6xUaf
			cUMDHEVBQJ.insert(Oq05LIgPFT2axXemcyuHSk1EAir8, cUMDHEVBQJ.pop(uFI9olMBzV5vkOfP7HTgsWy4eLR))
		B1OLI0yCFXjVhAx[LRHB6UsxIuW] = cUMDHEVBQJ
		p1tMwdJEgG = str(B1OLI0yCFXjVhAx)
		if HH6mxXjgcrEN1aenMFWQkS: p1tMwdJEgG = p1tMwdJEgG.encode(Zex6D4tJE52r)
		open(qdCNzTivE0olpmk3jUYRc,'wb').write(p1tMwdJEgG)
	return
def ykEKzCxWGP2DiYn4Uj9SHQbFdg1t7(LRHB6UsxIuW):
	if LRHB6UsxIuW in ['1','2','3','4']: HSb7NPOi5lvVG,RXi9ZFQcp7BGr = 'مفضلة',LRHB6UsxIuW
	elif LRHB6UsxIuW in ['5']: HSb7NPOi5lvVG,RXi9ZFQcp7BGr = 'تشغيل','1'
	elif LRHB6UsxIuW in ['11']: HSb7NPOi5lvVG,RXi9ZFQcp7BGr = 'تشغيل','2'
	else: HSb7NPOi5lvVG,RXi9ZFQcp7BGr = HQmDERMFjx,HQmDERMFjx
	mVkxoKnlbc7RgTM5SOwe4qP0A = HSb7NPOi5lvVG+oQpxmKiRPlHeGsLXNrJF78O+RXi9ZFQcp7BGr
	return mVkxoKnlbc7RgTM5SOwe4qP0A
def lljUyh6zkPamRbSpNvMA8JTd24(LRHB6UsxIuW):
	mVkxoKnlbc7RgTM5SOwe4qP0A = ykEKzCxWGP2DiYn4Uj9SHQbFdg1t7(LRHB6UsxIuW)
	oLUahkgyX95xC6FpDn = HUJZy0SrTbBYv1('center',HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,'هل تريد فعلا مسح جميع محتويات قائمة '+mVkxoKnlbc7RgTM5SOwe4qP0A+' ؟!')
	if oLUahkgyX95xC6FpDn!=1: return
	B1OLI0yCFXjVhAx = UwtKYfXMBEhT()
	if LRHB6UsxIuW in list(B1OLI0yCFXjVhAx.keys()):
		del B1OLI0yCFXjVhAx[LRHB6UsxIuW]
		p1tMwdJEgG = str(B1OLI0yCFXjVhAx)
		if HH6mxXjgcrEN1aenMFWQkS: p1tMwdJEgG = p1tMwdJEgG.encode(Zex6D4tJE52r)
		open(qdCNzTivE0olpmk3jUYRc,'wb').write(p1tMwdJEgG)
		u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,'تم مسح جميع محتويات قائمة '+mVkxoKnlbc7RgTM5SOwe4qP0A)
	return
def UwtKYfXMBEhT():
	B1OLI0yCFXjVhAx = {}
	if S9Y5kUoRga3EVN.path.exists(qdCNzTivE0olpmk3jUYRc):
		ltq50HcFZJ4PbEeLw = open(qdCNzTivE0olpmk3jUYRc,'rb').read()
		if HH6mxXjgcrEN1aenMFWQkS: ltq50HcFZJ4PbEeLw = ltq50HcFZJ4PbEeLw.decode(Zex6D4tJE52r)
		B1OLI0yCFXjVhAx = aknZqSJyUrFgc9VhH2Psot6e7b8('dict',ltq50HcFZJ4PbEeLw)
	return B1OLI0yCFXjVhAx
def WWXiHVhxmO4R(B1OLI0yCFXjVhAx,LLeOs6Guywp,ooerxyOKF4VEztANGcnbC):
	arsOBITUkup7x3eSfEvM,XyOvPTlmBK4hDVjfi,GUiCEYZjm5,lXBL3WrM2JFYm,Hdtu4n2qcfGBjV,JTMSUFcWn0XQa63GBI9qEAk7,NN9niuC7RoqmhkL2,wWqEgiB75LpjyPuaDTOU,xxwvNBlKpYESrqo0hPcdsutR = LLeOs6Guywp
	if not lXBL3WrM2JFYm: arsOBITUkup7x3eSfEvM,lXBL3WrM2JFYm = 'folder','260'
	evYoOZHDbk,LRHB6UsxIuW = [],HQmDERMFjx
	if 'context=' in yLjouMD5TmVK7bO0de48BPSGh:
		RYawONHq2iFL9Bn3vTMEx47S8Q = DyVGS3dX0ZxR.findall('context=(\d+)',yLjouMD5TmVK7bO0de48BPSGh,DyVGS3dX0ZxR.DOTALL)
		if RYawONHq2iFL9Bn3vTMEx47S8Q: LRHB6UsxIuW = str(RYawONHq2iFL9Bn3vTMEx47S8Q[o4bNzIQGYj8En])
	if lXBL3WrM2JFYm=='270':
		LRHB6UsxIuW = wWqEgiB75LpjyPuaDTOU
		if LRHB6UsxIuW in list(B1OLI0yCFXjVhAx.keys()):
			mVkxoKnlbc7RgTM5SOwe4qP0A = ykEKzCxWGP2DiYn4Uj9SHQbFdg1t7(LRHB6UsxIuW)
			evYoOZHDbk.append(('مسح قائمة '+mVkxoKnlbc7RgTM5SOwe4qP0A,'RunPlugin('+ooerxyOKF4VEztANGcnbC+'&context='+LRHB6UsxIuW+'_DELETELIST'+')'))
	else:
		if LRHB6UsxIuW in list(B1OLI0yCFXjVhAx.keys()):
			count = len(B1OLI0yCFXjVhAx[LRHB6UsxIuW])
			if count>CH7RKuDVzN9f06q8MtXPhlvIxakEWg: evYoOZHDbk.append(('تحريك 1 للأعلى','RunPlugin('+ooerxyOKF4VEztANGcnbC+'&context='+LRHB6UsxIuW+'_UP1)'))
			if count>ihRKM0HpwdVstIF2ZjuTeCmXG: evYoOZHDbk.append(('تحريك 4 للأعلى','RunPlugin('+ooerxyOKF4VEztANGcnbC+'&context='+LRHB6UsxIuW+'_UP4)'))
			if count>CH7RKuDVzN9f06q8MtXPhlvIxakEWg: evYoOZHDbk.append(('تحريك 1 للأسفل','RunPlugin('+ooerxyOKF4VEztANGcnbC+'&context='+LRHB6UsxIuW+'_DOWN1)'))
			if count>ihRKM0HpwdVstIF2ZjuTeCmXG: evYoOZHDbk.append(('تحريك 4 للأسفل','RunPlugin('+ooerxyOKF4VEztANGcnbC+'&context='+LRHB6UsxIuW+'_DOWN4)'))
		for LRHB6UsxIuW in ['1','2','3','4','5','11']:
			mVkxoKnlbc7RgTM5SOwe4qP0A = ykEKzCxWGP2DiYn4Uj9SHQbFdg1t7(LRHB6UsxIuW)
			if LRHB6UsxIuW in list(B1OLI0yCFXjVhAx.keys()) and LLeOs6Guywp in B1OLI0yCFXjVhAx[LRHB6UsxIuW]:
				evYoOZHDbk.append(('مسح من '+mVkxoKnlbc7RgTM5SOwe4qP0A,'RunPlugin('+ooerxyOKF4VEztANGcnbC+'&context='+LRHB6UsxIuW+'_REMOVE1)'))
			else: evYoOZHDbk.append(('إضافة ل'+mVkxoKnlbc7RgTM5SOwe4qP0A,'RunPlugin('+ooerxyOKF4VEztANGcnbC+'&context='+LRHB6UsxIuW+'_ADD1)'))
	mM34l5Pb2jiEGqeB6yFA0WZhvS = []
	for dVfBjmk4iFI0TC,fxjdNT76MuUy8 in evYoOZHDbk:
		dVfBjmk4iFI0TC = s7d549VgeP+dVfBjmk4iFI0TC+cjqzOQ5GXD4kR
		mM34l5Pb2jiEGqeB6yFA0WZhvS.append((dVfBjmk4iFI0TC,fxjdNT76MuUy8,))
	return mM34l5Pb2jiEGqeB6yFA0WZhvS
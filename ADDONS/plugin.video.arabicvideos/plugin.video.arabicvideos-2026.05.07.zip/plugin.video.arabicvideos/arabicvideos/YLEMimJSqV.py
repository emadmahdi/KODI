# -*- coding: utf-8 -*-
from FF68kA5BUy import *
HDLtdMAy7wPkl8aKC3O2 = 'CIMANOW'
EEJvXQzSZNt = '_CMN_'
e2VR8nohduY = Jzthpc2nj5.SITESURLS[HDLtdMAy7wPkl8aKC3O2][0]
FwhZ0nXtpoHTMarf = ['قائمتي']
def kk6X5LxpsND(mode,url,text):
	if   mode==300: zLZUkrP7ac5 = afkxo7FyZWB4O6K1eXrs5I()
	elif mode==301: zLZUkrP7ac5 = REWBU20fyqaLprY(url)
	elif mode==302: zLZUkrP7ac5 = c8wfGju4CWZm(url)
	elif mode==303: zLZUkrP7ac5 = llPpZytTMq2rBh1UJC9u7Oij(url)
	elif mode==304: zLZUkrP7ac5 = XONC9osGSP4fW5HVrhM(url)
	elif mode==305: zLZUkrP7ac5 = f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url)
	elif mode==306: zLZUkrP7ac5 = lRPnk9MH7S1BJaTeih()
	elif mode==309: zLZUkrP7ac5 = hm4kawIPKp3oMrC75dJZA9HS2(text)
	else: zLZUkrP7ac5 = False
	return zLZUkrP7ac5
def afkxo7FyZWB4O6K1eXrs5I():
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'بحث في الموقع',HQmDERMFjx,309,HQmDERMFjx,HQmDERMFjx,'_REMEMBERRESULTS_')
	CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(H5x4Z2qPwR8vXM,'GET',e2VR8nohduY+'/home',HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'CIMANOW-MENU-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('<header(.*?)</header>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	items = DyVGS3dX0ZxR.findall('<li><a href="(.*?)">(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	for vn1grP3y4It9GmVuBbLJfz2A,title in items:
		title = title.strip(oQpxmKiRPlHeGsLXNrJF78O)
		if not any(value in title for value in FwhZ0nXtpoHTMarf):
			CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,301)
	CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	REWBU20fyqaLprY(e2VR8nohduY+'/home',CzNPJydxQLfw27tv4ZF8KORAbX5)
	return CzNPJydxQLfw27tv4ZF8KORAbX5
def lRPnk9MH7S1BJaTeih():
	u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,'موقع سيما ناو بطيء من المصدر .. بسبب قيام أصحاب الموقع بتشفير محتويات جميع صفحات الموقع .. والوقت الضائع يذهب في معالجة تشفير الصفحات المشفرة قبل عرض محتوياتها في قوائم هذا البرنامج')
	return
def REWBU20fyqaLprY(url,CzNPJydxQLfw27tv4ZF8KORAbX5=HQmDERMFjx):
	if not CzNPJydxQLfw27tv4ZF8KORAbX5:
		vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(H5x4Z2qPwR8vXM,'GET',url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'CIMANOW-SUBMENU-1st')
		CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	AeXOdC4y3QVZgjMDn8 = 0
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('<section>.*?</section>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	for MJ2gSPyTl9hzoi1 in Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		AeXOdC4y3QVZgjMDn8 += 1
		items = DyVGS3dX0ZxR.findall('<section>.*?<span>(.*?)<(.*?)href="(.*?)"',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for title,xxt6XOk9wF2QJg,vn1grP3y4It9GmVuBbLJfz2A in items:
			title = title.strip(oQpxmKiRPlHeGsLXNrJF78O)
			if title==HQmDERMFjx: title = 'بووووو'
			if 'em><a' not in xxt6XOk9wF2QJg:
				if MJ2gSPyTl9hzoi1.count('/category/')>0:
					CGfLEIZtjWqlz = DyVGS3dX0ZxR.findall('href="(.*?)"',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
					for vn1grP3y4It9GmVuBbLJfz2A in CGfLEIZtjWqlz:
						title = vn1grP3y4It9GmVuBbLJfz2A.split(xufJqQcGnhboiVy2wd)[-2]
						CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,301)
					continue
				else: vn1grP3y4It9GmVuBbLJfz2A = url+'?sequence='+str(AeXOdC4y3QVZgjMDn8)
			if not any(value in title for value in FwhZ0nXtpoHTMarf):
				CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,302)
	if not Ut7reR0XioMjOdYWZKsLIuc3TQJmC1: c8wfGju4CWZm(url,CzNPJydxQLfw27tv4ZF8KORAbX5)
	return
def c8wfGju4CWZm(url,CzNPJydxQLfw27tv4ZF8KORAbX5=HQmDERMFjx):
	if CzNPJydxQLfw27tv4ZF8KORAbX5==HQmDERMFjx:
		vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'CIMANOW-TITLES-1st')
		CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	if '?sequence=' in url:
		url,AeXOdC4y3QVZgjMDn8 = url.split('?sequence=')
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('(<section>.*?</section>)',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[int(AeXOdC4y3QVZgjMDn8)-1]
	else:
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"posts"(.*?)</body>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	items = DyVGS3dX0ZxR.findall('<a.*?href="(.*?)"(.*?)data-src="(.*?)"',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	ORMkTYjJ1p7 = []
	for vn1grP3y4It9GmVuBbLJfz2A,data,uIGD4vZcP61QNmw78LXqoEpH in items:
		title = DyVGS3dX0ZxR.findall('<em>(.*?)</em>(.*?)</li>.*?</em>(.*?)<em>',data,DyVGS3dX0ZxR.DOTALL)
		if title: title = title[0][2].replace(ti3SbXNV0aJ7n5Grc4OQY8Ll1s9,HQmDERMFjx).strip(oQpxmKiRPlHeGsLXNrJF78O)
		if not title or title==HQmDERMFjx:
			title = DyVGS3dX0ZxR.findall('title">.*?</em>(.*?)<',data,DyVGS3dX0ZxR.DOTALL)
			if title: title = title[0].replace(ti3SbXNV0aJ7n5Grc4OQY8Ll1s9,HQmDERMFjx).strip(oQpxmKiRPlHeGsLXNrJF78O)
			if not title or title==HQmDERMFjx:
				title = DyVGS3dX0ZxR.findall('title">(.*?)<',data,DyVGS3dX0ZxR.DOTALL)
				title = title[0].replace(ti3SbXNV0aJ7n5Grc4OQY8Ll1s9,HQmDERMFjx).strip(oQpxmKiRPlHeGsLXNrJF78O)
		title = SVsiEWeRf6oIynqQx8pCrM4Tk(title)
		title = title.replace(MSnXBQNUg1jF3W2fRlE9OLaCT8ds4,oQpxmKiRPlHeGsLXNrJF78O)
		if title not in ORMkTYjJ1p7:
			ORMkTYjJ1p7.append(title)
			ej8EfB1iZ5Gh3X2gxWtSONH = vn1grP3y4It9GmVuBbLJfz2A+data+uIGD4vZcP61QNmw78LXqoEpH
			if '/selary/' in ej8EfB1iZ5Gh3X2gxWtSONH or 'مسلسل' in ej8EfB1iZ5Gh3X2gxWtSONH or '"episode"' in ej8EfB1iZ5Gh3X2gxWtSONH:
				if 'برامج' in data: title = 'برنامج '+title
				elif 'مسلسل' in data or 'موسم' in data: title = 'مسلسل '+title
				CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,303,uIGD4vZcP61QNmw78LXqoEpH)
			else: CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,305,uIGD4vZcP61QNmw78LXqoEpH)
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"pagination"(.*?)</div>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('<li><a href="(.*?)">(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,title in items:
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'صفحة '+title,vn1grP3y4It9GmVuBbLJfz2A,302)
	return
def llPpZytTMq2rBh1UJC9u7Oij(url):
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'CIMANOW-SEASONS-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	name = DyVGS3dX0ZxR.findall('<title>(.*?)</title>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if name:
		name = name[0].replace('| سيما ناو',HQmDERMFjx).replace('Cima Now',HQmDERMFjx).strip(oQpxmKiRPlHeGsLXNrJF78O).replace(MSnXBQNUg1jF3W2fRlE9OLaCT8ds4,oQpxmKiRPlHeGsLXNrJF78O)
		name = name.split('الحلقة')[0].strip(oQpxmKiRPlHeGsLXNrJF78O)+' - '
	else: name = HQmDERMFjx
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('<section(.*?)</section>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('href="(.*?)">(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		if len(items)>1:
			for vn1grP3y4It9GmVuBbLJfz2A,title in items:
				title = name+title.replace(ti3SbXNV0aJ7n5Grc4OQY8Ll1s9,HQmDERMFjx).strip(oQpxmKiRPlHeGsLXNrJF78O)
				CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,304)
		elif len(items)==1:
			vn1grP3y4It9GmVuBbLJfz2A,title = items[0]
			XONC9osGSP4fW5HVrhM(vn1grP3y4It9GmVuBbLJfz2A)
		else: XONC9osGSP4fW5HVrhM(url)
	return
def XONC9osGSP4fW5HVrhM(url):
	if '/selary/' not in url: url = url.strip(xufJqQcGnhboiVy2wd)+'/watching'
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'CIMANOW-EPISODES-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	if '/selary/' not in url:
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"episodes"(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[o4bNzIQGYj8En]
		items = DyVGS3dX0ZxR.findall('href="(.*?)">(.*?)</a>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,title in items:
			title = title.replace(ti3SbXNV0aJ7n5Grc4OQY8Ll1s9,HQmDERMFjx).strip(oQpxmKiRPlHeGsLXNrJF78O)
			title = 'الحلقة '+title
			CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,305)
	else:
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"details"(.*?)"related"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[o4bNzIQGYj8En]
		items = DyVGS3dX0ZxR.findall('href="(.*?)".*?src=.*?src="(.*?)".*?alt="(.*?)"',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,uIGD4vZcP61QNmw78LXqoEpH,title in items:
			title = title.replace(ti3SbXNV0aJ7n5Grc4OQY8Ll1s9,HQmDERMFjx).strip(oQpxmKiRPlHeGsLXNrJF78O)
			CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,305,uIGD4vZcP61QNmw78LXqoEpH)
	return
def f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url):
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'CIMANOW-PLAY-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	b5Xun4t3QVzFxhgYpD8A1ok = DyVGS3dX0ZxR.findall('class="shine" href="(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if b5Xun4t3QVzFxhgYpD8A1ok:
		pYVvlGR1ES0gdtzayiDqb9w = DpClq35GVjh(b5Xun4t3QVzFxhgYpD8A1ok[0],'url')
		headers = {'Referer':pYVvlGR1ES0gdtzayiDqb9w}
	else: headers = HQmDERMFjx
	SSHjMN4uegZfb2 = url+'watching/'
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',SSHjMN4uegZfb2,HQmDERMFjx,headers,HQmDERMFjx,HQmDERMFjx,'CIMANOW-PLAY-5th')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	Na8vklCpUGYIzP0bjutWOT = []
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"download"(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('href="(.*?)".*?</i>(.*?)</a>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,title in items:
			title = title.replace(ti3SbXNV0aJ7n5Grc4OQY8Ll1s9,HQmDERMFjx).strip(oQpxmKiRPlHeGsLXNrJF78O)
			RRpfksr1PbZagwCIOJXYNHTo = DyVGS3dX0ZxR.findall('\d\d\d+',title,DyVGS3dX0ZxR.DOTALL)
			if RRpfksr1PbZagwCIOJXYNHTo:
				RRpfksr1PbZagwCIOJXYNHTo = '____'+RRpfksr1PbZagwCIOJXYNHTo[0]
				title = DpClq35GVjh(vn1grP3y4It9GmVuBbLJfz2A,'name')
			else: RRpfksr1PbZagwCIOJXYNHTo = HQmDERMFjx
			cjfepMobZyFTuwq7WS1EV945L3g = vn1grP3y4It9GmVuBbLJfz2A+'?named='+title+'__download'+RRpfksr1PbZagwCIOJXYNHTo
			Na8vklCpUGYIzP0bjutWOT.append(cjfepMobZyFTuwq7WS1EV945L3g)
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"watch"(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		jzTLleJs8x9Hb1 = DyVGS3dX0ZxR.findall('"embed".*?src="(.*?)"',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A in jzTLleJs8x9Hb1:
			if 'http' not in vn1grP3y4It9GmVuBbLJfz2A: vn1grP3y4It9GmVuBbLJfz2A = 'http:'+vn1grP3y4It9GmVuBbLJfz2A
			title = DpClq35GVjh(vn1grP3y4It9GmVuBbLJfz2A,'name')
			vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A+'?named='+title+'__embed'
			Na8vklCpUGYIzP0bjutWOT.append(vn1grP3y4It9GmVuBbLJfz2A)
		jzTLleJs8x9Hb1 = [e2VR8nohduY+'/wp-content/themes/Cima%20Now%20New/core.php']
		if jzTLleJs8x9Hb1:
			items = DyVGS3dX0ZxR.findall('data-index="(.*?)".*?data-id="(.*?)".*?>(.*?)</li>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
			for bbiEfNgaGDK3tOSoAe0uZy4B,id,title in items:
				title = title.replace(ti3SbXNV0aJ7n5Grc4OQY8Ll1s9,HQmDERMFjx).strip(oQpxmKiRPlHeGsLXNrJF78O)
				vn1grP3y4It9GmVuBbLJfz2A = jzTLleJs8x9Hb1[0]+'?action=switch&index='+bbiEfNgaGDK3tOSoAe0uZy4B+'&id='+id+'?named='+title+'__watch'
				Na8vklCpUGYIzP0bjutWOT.append(vn1grP3y4It9GmVuBbLJfz2A)
	import NsD5AomUqH
	NsD5AomUqH.NZcWGBmgFEen5hvJjUSIzOCVk7(Na8vklCpUGYIzP0bjutWOT,HDLtdMAy7wPkl8aKC3O2,'video',url)
	return
def hm4kawIPKp3oMrC75dJZA9HS2(search):
	search,GXVabd4sc2u3zp0JI,showDialogs = x0pzMENwy84tBcZvXr(search)
	if search==HQmDERMFjx: search = q156m84QoYrn()
	if search==HQmDERMFjx: return
	search = search.replace(oQpxmKiRPlHeGsLXNrJF78O,'+')
	url = e2VR8nohduY + '/?s='+search
	c8wfGju4CWZm(url)
	return
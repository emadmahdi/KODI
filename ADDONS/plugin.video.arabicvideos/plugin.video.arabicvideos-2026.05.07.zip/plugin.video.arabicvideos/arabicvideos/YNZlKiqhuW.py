# -*- coding: utf-8 -*-
from FF68kA5BUy import *
HDLtdMAy7wPkl8aKC3O2 = 'MOVIZLAND'
headers = { 'User-Agent' : HQmDERMFjx }
EEJvXQzSZNt = '_MVZ_'
e2VR8nohduY = Jzthpc2nj5.SITESURLS[HDLtdMAy7wPkl8aKC3O2][0]
waE5LXVN0BOiQjCUur3oTt6eYSIHJK = Jzthpc2nj5.SITESURLS[HDLtdMAy7wPkl8aKC3O2][1]
def kk6X5LxpsND(mode,url,text):
	if   mode==180: zLZUkrP7ac5 = afkxo7FyZWB4O6K1eXrs5I()
	elif mode==181: zLZUkrP7ac5 = c8wfGju4CWZm(url,text)
	elif mode==182: zLZUkrP7ac5 = f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url)
	elif mode==183: zLZUkrP7ac5 = XONC9osGSP4fW5HVrhM(url)
	elif mode==188: zLZUkrP7ac5 = veU9QpiaqR7hOwZn()
	elif mode==189: zLZUkrP7ac5 = hm4kawIPKp3oMrC75dJZA9HS2(text)
	else: zLZUkrP7ac5 = False
	return zLZUkrP7ac5
def veU9QpiaqR7hOwZn():
	message = 'هذا الموقع تغير بالكامل ... وبحاجة الى اعادة برمجة من الصفر ... والمبرمج حاليا مشغول ويعاني من وعكة صحية ... ولهذا سوف يبقى الموقع مغلق الى ما شاء الله'
	u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,message)
	return
def afkxo7FyZWB4O6K1eXrs5I():
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'بحث في الموقع',HQmDERMFjx,189,HQmDERMFjx,HQmDERMFjx,'_REMEMBERRESULTS_')
	CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+'بوكس اوفيس موفيز لاند',e2VR8nohduY,181,HQmDERMFjx,HQmDERMFjx,'box-office')
	CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+'أحدث الافلام',e2VR8nohduY,181,HQmDERMFjx,HQmDERMFjx,'latest-movies')
	CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+'تليفزيون موفيز لاند',e2VR8nohduY,181,HQmDERMFjx,HQmDERMFjx,'tv')
	CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+'الاكثر مشاهدة',e2VR8nohduY,181,HQmDERMFjx,HQmDERMFjx,'top-views')
	CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+'أقوى الافلام الحالية',e2VR8nohduY,181,HQmDERMFjx,HQmDERMFjx,'top-movies')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = D0GFPwY8ecAVI(H5x4Z2qPwR8vXM,e2VR8nohduY,HQmDERMFjx,headers,HQmDERMFjx,'MOVIZLAND-MENU-1st')
	items = DyVGS3dX0ZxR.findall('<h2><a href="(.*?)".*?">(.*?)<',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	for vn1grP3y4It9GmVuBbLJfz2A,title in items:
		CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,181)
	return CzNPJydxQLfw27tv4ZF8KORAbX5
def c8wfGju4CWZm(url,type=HQmDERMFjx):
	CzNPJydxQLfw27tv4ZF8KORAbX5 = D0GFPwY8ecAVI(j9uzmBeEyK8,url,HQmDERMFjx,headers,HQmDERMFjx,'MOVIZLAND-ITEMS-1st')
	if type=='latest-movies': MJ2gSPyTl9hzoi1 = DyVGS3dX0ZxR.findall('class="titleSection">أحدث الأفلام</h1>(.*?)<h1',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)[0]
	elif type=='box-office': MJ2gSPyTl9hzoi1 = DyVGS3dX0ZxR.findall('class="titleSection">بوكس اوفيس موفيز لاند</h1>(.*?)<h1',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)[0]
	elif type=='top-movies': MJ2gSPyTl9hzoi1 = DyVGS3dX0ZxR.findall('btn-2-overlay(.*?)<style>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)[0]
	elif type=='top-views': MJ2gSPyTl9hzoi1 = DyVGS3dX0ZxR.findall('btn-1 btn-absoly(.*?)btn-2 btn-absoly',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)[0]
	elif type=='tv': MJ2gSPyTl9hzoi1 = DyVGS3dX0ZxR.findall('class="titleSection">تليفزيون موفيز لاند</h1>(.*?)class="paging"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)[0]
	else: MJ2gSPyTl9hzoi1 = CzNPJydxQLfw27tv4ZF8KORAbX5
	if type in ['top-views','top-movies']:
		items = DyVGS3dX0ZxR.findall('style="background-image:url\(\'(.*?)\'.*?href="(.*?)".*?href="(.*?)".*?bottom-title.*?>(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	else: items = DyVGS3dX0ZxR.findall('height="3[0-9]+" src="(.*?)".*?bottom-title.*?href=.*?>(.*?)<.*?href="(.*?)".*?href="(.*?)"',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	ORMkTYjJ1p7 = []
	Dfbu0wOr6IcqhE2XCUKn = ['فيلم','الحلقة','الحلقه','عرض','Raw','SmackDown','اعلان','اجزاء']
	for uIGD4vZcP61QNmw78LXqoEpH,kZIMuFGpqb,RiE7fCIjK2qADY51aJsQOcSmNtVHy,yyrDPsjmYcHN6Sfz in items:
		if type in ['top-views','top-movies']:
			uIGD4vZcP61QNmw78LXqoEpH,vn1grP3y4It9GmVuBbLJfz2A,cjfepMobZyFTuwq7WS1EV945L3g,title = uIGD4vZcP61QNmw78LXqoEpH,kZIMuFGpqb,RiE7fCIjK2qADY51aJsQOcSmNtVHy,yyrDPsjmYcHN6Sfz
		else: uIGD4vZcP61QNmw78LXqoEpH,title,vn1grP3y4It9GmVuBbLJfz2A,cjfepMobZyFTuwq7WS1EV945L3g = uIGD4vZcP61QNmw78LXqoEpH,kZIMuFGpqb,RiE7fCIjK2qADY51aJsQOcSmNtVHy,yyrDPsjmYcHN6Sfz
		vn1grP3y4It9GmVuBbLJfz2A = xx9LK4VzpF6IHXSEyhmrQwbg25P0(vn1grP3y4It9GmVuBbLJfz2A)
		vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A.replace('?view=true',HQmDERMFjx)
		title = SVsiEWeRf6oIynqQx8pCrM4Tk(title)
		if 'بجودة ' in title or 'بجوده ' in title:
			title = '_MOD_' + title.replace('بجودة ',HQmDERMFjx).replace('بجوده ',HQmDERMFjx)
		title = title.strip(oQpxmKiRPlHeGsLXNrJF78O)
		if 'الحلقة' in title or 'الحلقه' in title:
			yTz8SOkAhu24j6apo9BmZHvwWsX = DyVGS3dX0ZxR.findall('(.*?) (الحلقة|الحلقه) \d+',title,DyVGS3dX0ZxR.DOTALL)
			if yTz8SOkAhu24j6apo9BmZHvwWsX:
				title = '_MOD_' + yTz8SOkAhu24j6apo9BmZHvwWsX[0][0]
				if title not in ORMkTYjJ1p7:
					CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,183,uIGD4vZcP61QNmw78LXqoEpH)
					ORMkTYjJ1p7.append(title)
		elif any(value in title for value in Dfbu0wOr6IcqhE2XCUKn):
			vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A + '?servers=' + cjfepMobZyFTuwq7WS1EV945L3g
			CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,182,uIGD4vZcP61QNmw78LXqoEpH)
		else:
			vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A + '?servers=' + cjfepMobZyFTuwq7WS1EV945L3g
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,183,uIGD4vZcP61QNmw78LXqoEpH)
	if type==HQmDERMFjx:
		items = DyVGS3dX0ZxR.findall('\n<li><a href="(.*?)".*?>(.*?)<',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,title in items:
			title = SVsiEWeRf6oIynqQx8pCrM4Tk(title)
			title = title.replace('الصفحة ',HQmDERMFjx)
			if title!=HQmDERMFjx:
				CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'صفحة '+title,vn1grP3y4It9GmVuBbLJfz2A,181)
	return
def XONC9osGSP4fW5HVrhM(url):
	SSHjMN4uegZfb2 = url.split('?servers=')[0]
	CzNPJydxQLfw27tv4ZF8KORAbX5 = D0GFPwY8ecAVI(j9uzmBeEyK8,SSHjMN4uegZfb2,HQmDERMFjx,headers,HQmDERMFjx,'MOVIZLAND-EPISODES-1st')
	MJ2gSPyTl9hzoi1 = DyVGS3dX0ZxR.findall('<title>(.*?)</title>.*?height="([0-9]+)" src="(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	title,RZ9V4eABCTfIO1FUrz2ks5DSwu,uIGD4vZcP61QNmw78LXqoEpH = MJ2gSPyTl9hzoi1[0]
	name = DyVGS3dX0ZxR.findall('(.*?) (الحلقة|الحلقه) [0-9]+',title,DyVGS3dX0ZxR.DOTALL)
	if name: name = '_MOD_' + name[0][0]
	else: name = title
	items = []
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('class="episodesNumbers"(.*?)</div>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('href="(.*?)"',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A in items:
			vn1grP3y4It9GmVuBbLJfz2A = xx9LK4VzpF6IHXSEyhmrQwbg25P0(vn1grP3y4It9GmVuBbLJfz2A)
			title = DyVGS3dX0ZxR.findall('(الحلقة|الحلقه)-([0-9]+)',vn1grP3y4It9GmVuBbLJfz2A.split(xufJqQcGnhboiVy2wd)[-2],DyVGS3dX0ZxR.DOTALL)
			if not title: title = DyVGS3dX0ZxR.findall('()-([0-9]+)',vn1grP3y4It9GmVuBbLJfz2A.split(xufJqQcGnhboiVy2wd)[-2],DyVGS3dX0ZxR.DOTALL)
			if title: title = oQpxmKiRPlHeGsLXNrJF78O + title[0][1]
			else: title = HQmDERMFjx
			title = name + ' - ' + 'الحلقة' + title
			title = SVsiEWeRf6oIynqQx8pCrM4Tk(title)
			CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,182,uIGD4vZcP61QNmw78LXqoEpH)
	if not items:
		title = SVsiEWeRf6oIynqQx8pCrM4Tk(title)
		if 'بجودة ' in title or 'بجوده ' in title:
			title = '_MOD_' + title.replace('بجودة ',HQmDERMFjx).replace('بجوده ',HQmDERMFjx)
		CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,url,182,uIGD4vZcP61QNmw78LXqoEpH)
	return
def f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url):
	XbwB9KAPneoEgSydqzN7xG = url.split('?servers=')
	SSHjMN4uegZfb2 = XbwB9KAPneoEgSydqzN7xG[0]
	del XbwB9KAPneoEgSydqzN7xG[0]
	CzNPJydxQLfw27tv4ZF8KORAbX5 = D0GFPwY8ecAVI(H5x4Z2qPwR8vXM,SSHjMN4uegZfb2,HQmDERMFjx,headers,HQmDERMFjx,'MOVIZLAND-PLAY-1st')
	vn1grP3y4It9GmVuBbLJfz2A = DyVGS3dX0ZxR.findall('font-size: 25px;" href="(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)[0]
	if vn1grP3y4It9GmVuBbLJfz2A not in XbwB9KAPneoEgSydqzN7xG: XbwB9KAPneoEgSydqzN7xG.append(vn1grP3y4It9GmVuBbLJfz2A)
	Na8vklCpUGYIzP0bjutWOT = []
	for vn1grP3y4It9GmVuBbLJfz2A in XbwB9KAPneoEgSydqzN7xG:
		if '://moshahda.' in vn1grP3y4It9GmVuBbLJfz2A:
			cxS5EomYnfIwGFPph = vn1grP3y4It9GmVuBbLJfz2A
			Na8vklCpUGYIzP0bjutWOT.append(cxS5EomYnfIwGFPph+'?named=Main')
	for vn1grP3y4It9GmVuBbLJfz2A in XbwB9KAPneoEgSydqzN7xG:
		if '://vb.movizland.' in vn1grP3y4It9GmVuBbLJfz2A:
			CzNPJydxQLfw27tv4ZF8KORAbX5 = D0GFPwY8ecAVI(H5x4Z2qPwR8vXM,vn1grP3y4It9GmVuBbLJfz2A,HQmDERMFjx,headers,HQmDERMFjx,'MOVIZLAND-PLAY-2nd')
			CzNPJydxQLfw27tv4ZF8KORAbX5 = CzNPJydxQLfw27tv4ZF8KORAbX5.decode(yNqJ4UpZ0wngGi1hHeuEMK).encode(Zex6D4tJE52r)
			CzNPJydxQLfw27tv4ZF8KORAbX5 = CzNPJydxQLfw27tv4ZF8KORAbX5.replace('src="http://up.movizland.com/uploads/13721411411.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"')
			CzNPJydxQLfw27tv4ZF8KORAbX5 = CzNPJydxQLfw27tv4ZF8KORAbX5.replace('src="http://up.movizland.online/uploads/13721411411.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"')
			CzNPJydxQLfw27tv4ZF8KORAbX5 = CzNPJydxQLfw27tv4ZF8KORAbX5.replace('</a></div><br /><div align="center">','src="/uploads/13721411411.png"')
			CzNPJydxQLfw27tv4ZF8KORAbX5 = CzNPJydxQLfw27tv4ZF8KORAbX5.replace('class="tborder" align="center"','src="/uploads/13721411411.png"')
			Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('(src="/uploads/13721411411.png".*?href="http://moshahda\..*?/\w+.html".*?src="/uploads/13721411411.png")',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
			if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
				aYrCHIJkpe6qUDS4Tl0tKPGoZ7,cfPzN4RdXSMIaBWGtsHEVuh = [],[]
				if len(Ut7reR0XioMjOdYWZKsLIuc3TQJmC1)==1:
					title = HQmDERMFjx
					MJ2gSPyTl9hzoi1 = CzNPJydxQLfw27tv4ZF8KORAbX5
				else:
					for MJ2gSPyTl9hzoi1 in Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
						ej8EfB1iZ5Gh3X2gxWtSONH = DyVGS3dX0ZxR.findall('src="/uploads/13721411411.png".*?http://up.movizland.(online|com)/uploads/.*?\*\*\*\*\*\*\*+(.*?src="/uploads/13721411411.png")',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
						if ej8EfB1iZ5Gh3X2gxWtSONH: MJ2gSPyTl9hzoi1 = 'src="/uploads/13721411411.png"  \n  ' + ej8EfB1iZ5Gh3X2gxWtSONH[0][1]
						ej8EfB1iZ5Gh3X2gxWtSONH = DyVGS3dX0ZxR.findall('src="/uploads/13721411411.png".*?<hr size="1" style="color:'+'#'+'333; background-color:'+'#'+'333" />(.*?href="http://moshahda\..*?/\w+.html".*?src="/uploads/13721411411.png")',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
						if ej8EfB1iZ5Gh3X2gxWtSONH: MJ2gSPyTl9hzoi1 = 'src="/uploads/13721411411.png"  \n  ' + ej8EfB1iZ5Gh3X2gxWtSONH[0]
						ej8EfB1iZ5Gh3X2gxWtSONH = DyVGS3dX0ZxR.findall('(src="/uploads/13721411411.png".*?href="http://moshahda\..*?/\w+.html".*?)<hr size="1" style="color:'+'#'+'333; background-color:'+'#'+'333" />.*?src="/uploads/13721411411.png"',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
						if ej8EfB1iZ5Gh3X2gxWtSONH: MJ2gSPyTl9hzoi1 = ej8EfB1iZ5Gh3X2gxWtSONH[0] + '  \n  src="/uploads/13721411411.png"'
						NzCdHvaBFo9iZVqIt = DyVGS3dX0ZxR.findall('<(.*?)http://up.movizland.(online|com)/uploads/',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
						title = DyVGS3dX0ZxR.findall('> *([^<>]+) *<',NzCdHvaBFo9iZVqIt[0][0],DyVGS3dX0ZxR.DOTALL)
						title = oQpxmKiRPlHeGsLXNrJF78O.join(title)
						title = title.strip(oQpxmKiRPlHeGsLXNrJF78O)
						title = title.replace(MSnXBQNUg1jF3W2fRlE9OLaCT8ds4,oQpxmKiRPlHeGsLXNrJF78O).replace(MSnXBQNUg1jF3W2fRlE9OLaCT8ds4,oQpxmKiRPlHeGsLXNrJF78O).replace(MSnXBQNUg1jF3W2fRlE9OLaCT8ds4,oQpxmKiRPlHeGsLXNrJF78O).replace(MSnXBQNUg1jF3W2fRlE9OLaCT8ds4,oQpxmKiRPlHeGsLXNrJF78O).replace(MSnXBQNUg1jF3W2fRlE9OLaCT8ds4,oQpxmKiRPlHeGsLXNrJF78O)
						aYrCHIJkpe6qUDS4Tl0tKPGoZ7.append(title)
					lwT9cdaH5AxMU8IpZif20jPX = GGiSlWbqKDr5Ovkh2L7sHNTxz('أختر الفيديو المطلوب:', aYrCHIJkpe6qUDS4Tl0tKPGoZ7)
					if lwT9cdaH5AxMU8IpZif20jPX == -1 : return
					title = aYrCHIJkpe6qUDS4Tl0tKPGoZ7[lwT9cdaH5AxMU8IpZif20jPX]
					MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[lwT9cdaH5AxMU8IpZif20jPX]
				vn1grP3y4It9GmVuBbLJfz2A = DyVGS3dX0ZxR.findall('href="(http://moshahda\..*?/\w+.html)"',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
				i1Pn5Il8V3FEqTtbuxO = vn1grP3y4It9GmVuBbLJfz2A[0]
				Na8vklCpUGYIzP0bjutWOT.append(i1Pn5Il8V3FEqTtbuxO+'?named=Forum')
				MJ2gSPyTl9hzoi1 = MJ2gSPyTl9hzoi1.replace('ـ',HQmDERMFjx)
				MJ2gSPyTl9hzoi1 = MJ2gSPyTl9hzoi1.replace('src="http://up.movizland.online/uploads/1517412175296.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="both"  \n  ')
				MJ2gSPyTl9hzoi1 = MJ2gSPyTl9hzoi1.replace('src="http://up.movizland.com/uploads/1517412175296.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="both"  \n  ')
				MJ2gSPyTl9hzoi1 = MJ2gSPyTl9hzoi1.replace('سيرفرات التحميل','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="download"  \n  ')
				MJ2gSPyTl9hzoi1 = MJ2gSPyTl9hzoi1.replace('روابط التحميل','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="download"  \n  ')
				MJ2gSPyTl9hzoi1 = MJ2gSPyTl9hzoi1.replace('سيرفرات المشاهد','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="watch"  \n  ')
				MJ2gSPyTl9hzoi1 = MJ2gSPyTl9hzoi1.replace('روابط المشاهد','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="watch"  \n  ')
				ttfsj84irp6zTQVyLg = DyVGS3dX0ZxR.findall('(src="/uploads/13721411411.png".*?href="http://e5tsar.com/\d+".*?src="/uploads/13721411411.png")',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
				for QwpvW3qiTZolCfkA0uNHsU2Bb in ttfsj84irp6zTQVyLg:
					type = DyVGS3dX0ZxR.findall(' typetype="(.*?)" ',QwpvW3qiTZolCfkA0uNHsU2Bb)
					if type:
						if type[0]!='both': type = '__'+type[0]
						else: type = HQmDERMFjx
					items = DyVGS3dX0ZxR.findall('(?<!http://e5tsar.com/)(\w+[ \w]*</font>.*?|\w+[ \w]*<br />.*?)href="(http://e5tsar.com/.*?)"',QwpvW3qiTZolCfkA0uNHsU2Bb,DyVGS3dX0ZxR.DOTALL)
					for Xl2M4v7ftoFgd38ChsRr5Kp,vn1grP3y4It9GmVuBbLJfz2A in items:
						title = DyVGS3dX0ZxR.findall('(\w+[ \w]*)<',Xl2M4v7ftoFgd38ChsRr5Kp)
						title = title[-1]
						vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A + '?named=' + title + type
						Na8vklCpUGYIzP0bjutWOT.append(vn1grP3y4It9GmVuBbLJfz2A)
	jDcWv7MAkEV = SSHjMN4uegZfb2.replace(e2VR8nohduY,waE5LXVN0BOiQjCUur3oTt6eYSIHJK)
	CzNPJydxQLfw27tv4ZF8KORAbX5 = D0GFPwY8ecAVI(H5x4Z2qPwR8vXM,jDcWv7MAkEV,HQmDERMFjx,headers,HQmDERMFjx,'MOVIZLAND-PLAY-3rd')
	items = DyVGS3dX0ZxR.findall('" href="(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if items:
		UYEyVqnTDOXed1bFCugiRjvZ0k9szP = items[-1]
		Na8vklCpUGYIzP0bjutWOT.append(UYEyVqnTDOXed1bFCugiRjvZ0k9szP+'?named=Mobile')
	import NsD5AomUqH
	NsD5AomUqH.NZcWGBmgFEen5hvJjUSIzOCVk7(Na8vklCpUGYIzP0bjutWOT,HDLtdMAy7wPkl8aKC3O2,'video',url)
	return
def hm4kawIPKp3oMrC75dJZA9HS2(search):
	search,GXVabd4sc2u3zp0JI,showDialogs = x0pzMENwy84tBcZvXr(search)
	if search==HQmDERMFjx: search = q156m84QoYrn()
	if search==HQmDERMFjx: return
	search = search.replace(oQpxmKiRPlHeGsLXNrJF78O,'+')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = D0GFPwY8ecAVI(j9uzmBeEyK8,e2VR8nohduY,HQmDERMFjx,headers,HQmDERMFjx,'MOVIZLAND-SEARCH-1st')
	items = DyVGS3dX0ZxR.findall('<option value="(.*?)">(.*?)</option>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	IH6WtApDFSkcQ2TE = [ HQmDERMFjx ]
	dr0NHB5IWYFE3vtC1Qg7fP9U4RyjV = [ 'الكل وبدون فلتر' ]
	for WF2vkePC5gbXAGUarcqlpmB3Q,title in items:
		IH6WtApDFSkcQ2TE.append(WF2vkePC5gbXAGUarcqlpmB3Q)
		dr0NHB5IWYFE3vtC1Qg7fP9U4RyjV.append(title)
	if WF2vkePC5gbXAGUarcqlpmB3Q:
		lwT9cdaH5AxMU8IpZif20jPX = GGiSlWbqKDr5Ovkh2L7sHNTxz('اختر الفلتر المناسب:', dr0NHB5IWYFE3vtC1Qg7fP9U4RyjV)
		if lwT9cdaH5AxMU8IpZif20jPX == -1 : return
		WF2vkePC5gbXAGUarcqlpmB3Q = IH6WtApDFSkcQ2TE[lwT9cdaH5AxMU8IpZif20jPX]
	else: WF2vkePC5gbXAGUarcqlpmB3Q = HQmDERMFjx
	url = e2VR8nohduY + '/?s='+search+'&mcat='+WF2vkePC5gbXAGUarcqlpmB3Q
	c8wfGju4CWZm(url)
	return
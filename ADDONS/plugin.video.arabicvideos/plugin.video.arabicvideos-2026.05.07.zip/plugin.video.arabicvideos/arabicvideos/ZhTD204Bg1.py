# -*- coding: utf-8 -*-
from FF68kA5BUy import *
HDLtdMAy7wPkl8aKC3O2 = 'EGYBEST1'
EEJvXQzSZNt = '_EB1_'
e2VR8nohduY = Jzthpc2nj5.SITESURLS[HDLtdMAy7wPkl8aKC3O2][0]
FwhZ0nXtpoHTMarf = ['مكتبتي','ايجي بست']
def kk6X5LxpsND(mode,url,zmL397efNlks5uTEV,text):
	if   mode==770: zLZUkrP7ac5 = afkxo7FyZWB4O6K1eXrs5I()
	elif mode==771: zLZUkrP7ac5 = c8wfGju4CWZm(url,zmL397efNlks5uTEV)
	elif mode==772: zLZUkrP7ac5 = REWBU20fyqaLprY(url)
	elif mode==773: zLZUkrP7ac5 = f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url)
	elif mode==774: zLZUkrP7ac5 = ooxUXkcTj5PF4ad2SwYy(url,'FULL_FILTER___'+text)
	elif mode==775: zLZUkrP7ac5 = ooxUXkcTj5PF4ad2SwYy(url,'DEFINED_FILTER___'+text)
	elif mode==776: zLZUkrP7ac5 = OeIkhc6dCf01i2BFSKX5L8E9Nvr(url,zmL397efNlks5uTEV)
	elif mode==779: zLZUkrP7ac5 = hm4kawIPKp3oMrC75dJZA9HS2(text,url)
	else: zLZUkrP7ac5 = False
	return zLZUkrP7ac5
def afkxo7FyZWB4O6K1eXrs5I():
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'بحث في الموقع',HQmDERMFjx,779,HQmDERMFjx,HQmDERMFjx,'_REMEMBERRESULTS_')
	CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(H5x4Z2qPwR8vXM,'GET',e2VR8nohduY,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'EGYBEST1-MENU-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('nav-list(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('href="(.*?)".*?<span>(.*?)</span>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,title in items:
			title = title.strip(oQpxmKiRPlHeGsLXNrJF78O)
			if any(value in title for value in FwhZ0nXtpoHTMarf): continue
			CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,771)
		CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('main-article(.*?)social-box',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('main-title.*?">(.*?)<.*?href="(.*?)"',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for title,vn1grP3y4It9GmVuBbLJfz2A in items:
			title = title.strip(oQpxmKiRPlHeGsLXNrJF78O)
			CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,771,HQmDERMFjx,'mainmenu')
		CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('main-menu(.*?)</div></div>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('href="(.*?)">(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,title in items:
			title = title.strip(oQpxmKiRPlHeGsLXNrJF78O)
			CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,771)
	return CzNPJydxQLfw27tv4ZF8KORAbX5
def OeIkhc6dCf01i2BFSKX5L8E9Nvr(url,type=HQmDERMFjx):
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'EGYBEST1-SEASONS_EPISODES-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('main-article".*?">(.*?)<(.*?)article',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		WTgZPcmVih38IjnSJ2U,EX6nDt50Hih9mIxulw7kpMCZfaOsJR,items = HQmDERMFjx,HQmDERMFjx,[]
		for name,MJ2gSPyTl9hzoi1 in Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
			if 'حلقات' in name: EX6nDt50Hih9mIxulw7kpMCZfaOsJR = MJ2gSPyTl9hzoi1
			if 'مواسم' in name: WTgZPcmVih38IjnSJ2U = MJ2gSPyTl9hzoi1
		if WTgZPcmVih38IjnSJ2U and not type:
			items = DyVGS3dX0ZxR.findall('href="(.*?)".*?data-src="(.*?)".*?"title">(.*?)<',WTgZPcmVih38IjnSJ2U,DyVGS3dX0ZxR.DOTALL)
			if len(items)>1:
				for vn1grP3y4It9GmVuBbLJfz2A,uIGD4vZcP61QNmw78LXqoEpH,title in items:
					CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,776,uIGD4vZcP61QNmw78LXqoEpH,'season')
		if EX6nDt50Hih9mIxulw7kpMCZfaOsJR and len(items)<2:
			items = DyVGS3dX0ZxR.findall('href="(.*?)".*?data-src="(.*?)".*?title="(.*?)"',EX6nDt50Hih9mIxulw7kpMCZfaOsJR,DyVGS3dX0ZxR.DOTALL)
			if items:
				for vn1grP3y4It9GmVuBbLJfz2A,uIGD4vZcP61QNmw78LXqoEpH,title in items:
					CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,773,uIGD4vZcP61QNmw78LXqoEpH)
			else:
				items = DyVGS3dX0ZxR.findall('href="(.*?)">(.*?)<',EX6nDt50Hih9mIxulw7kpMCZfaOsJR,DyVGS3dX0ZxR.DOTALL)
				for vn1grP3y4It9GmVuBbLJfz2A,title in items:
					CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,773)
	return
def c8wfGju4CWZm(url,type=HQmDERMFjx):
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'EGYBEST1-TITLES-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	items,ooMNC7KvzXqmsT2ke3JL9SIFi,Eya9L4IY3GxqtNoVWegDcPuOR = [],False,False
	if not type:
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('main-content(.*?)</div>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
			MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
			items = DyVGS3dX0ZxR.findall('href="(.*?)".*?</i>(.*?)</a>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
			for vn1grP3y4It9GmVuBbLJfz2A,title in items:
				title = title.strip(oQpxmKiRPlHeGsLXNrJF78O)
				CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,771,HQmDERMFjx,'submenu')
				ooMNC7KvzXqmsT2ke3JL9SIFi = True
	if not type and 'p=' not in url:
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('searchform(.*?)</form>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
			if ooMNC7KvzXqmsT2ke3JL9SIFi: CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'فلتر محدد',url,775,HQmDERMFjx,'filter')
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'فلتر كامل',url,774,HQmDERMFjx,'filter')
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'بحث',url,779)
			CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
			Eya9L4IY3GxqtNoVWegDcPuOR = True
	if not ooMNC7KvzXqmsT2ke3JL9SIFi:
		Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('blocks(.*?)article',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
			MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
			items = DyVGS3dX0ZxR.findall('href="(.*?)".*?src="(.*?)".*?class="title">(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
			for vn1grP3y4It9GmVuBbLJfz2A,uIGD4vZcP61QNmw78LXqoEpH,title in items:
				uIGD4vZcP61QNmw78LXqoEpH = uIGD4vZcP61QNmw78LXqoEpH.strip(ti3SbXNV0aJ7n5Grc4OQY8Ll1s9)
				vn1grP3y4It9GmVuBbLJfz2A = xx9LK4VzpF6IHXSEyhmrQwbg25P0(vn1grP3y4It9GmVuBbLJfz2A)
				if '/serie/' in vn1grP3y4It9GmVuBbLJfz2A: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,776,uIGD4vZcP61QNmw78LXqoEpH,'season')
				else: CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,773,uIGD4vZcP61QNmw78LXqoEpH)
			zmL397efNlks5uTEV = '1'
			if 'p=' in url: url,zmL397efNlks5uTEV = url.split('p=',1)
			k4JH0LWUI8KC7iDRB2xPonhjtqA = '&' if '?' in url else '?'
			url = url+k4JH0LWUI8KC7iDRB2xPonhjtqA
			url = url.replace('?&','?')
			if len(items)==40:
				url = url+'p='+str(int(zmL397efNlks5uTEV)+1)
				CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'الصفحة التالية',url,771)
			elif zmL397efNlks5uTEV!='1':
				url = url+'p='+str(int(zmL397efNlks5uTEV)-1)
				CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'الصفحة السابقة',url,771)
	return
def f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url):
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(rwjfOIqQU3ANa0JlWXvCDbFk,'GET',url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'EGYBEST1-PLAY-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	WWbJG6CrUL4tIRsjpNV = DyVGS3dX0ZxR.findall('<label>التصنيف</label>.*?">(.*?)<',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if WWbJG6CrUL4tIRsjpNV and UzSYuZp3Pnhf1W4wyx7Fc0JX6jNb(HDLtdMAy7wPkl8aKC3O2,url,WWbJG6CrUL4tIRsjpNV): return
	YUrbiMnkFBDdJSOoqymh8WV0IaC1,KWnAuJIFyESQHjP3X5xzMqUbR6L,QYDSpJHjizlW = [],[],[]
	vn1grP3y4It9GmVuBbLJfz2A = DyVGS3dX0ZxR.findall('download-section.*?action="(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if vn1grP3y4It9GmVuBbLJfz2A:
		vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A[0]
		if vn1grP3y4It9GmVuBbLJfz2A not in QYDSpJHjizlW:
			QYDSpJHjizlW.append(vn1grP3y4It9GmVuBbLJfz2A)
			KWnAuJIFyESQHjP3X5xzMqUbR6L.append(vn1grP3y4It9GmVuBbLJfz2A+'?named=__embed______'+VVkOtyQLzxBr(url))
	bUzHWnGg5t1 = DyVGS3dX0ZxR.findall('WatchServers(.*?)</div>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	for MJ2gSPyTl9hzoi1 in bUzHWnGg5t1:
		jzTLleJs8x9Hb1 = DyVGS3dX0ZxR.findall("url='(.*?)'.*?>(.*?)<",MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,pYVvlGR1ES0gdtzayiDqb9w in jzTLleJs8x9Hb1:
			if vn1grP3y4It9GmVuBbLJfz2A not in QYDSpJHjizlW:
				QYDSpJHjizlW.append(vn1grP3y4It9GmVuBbLJfz2A)
				KWnAuJIFyESQHjP3X5xzMqUbR6L.append(vn1grP3y4It9GmVuBbLJfz2A+'?named='+pYVvlGR1ES0gdtzayiDqb9w+'__both______'+VVkOtyQLzxBr(url))
	import NsD5AomUqH
	NsD5AomUqH.NZcWGBmgFEen5hvJjUSIzOCVk7(KWnAuJIFyESQHjP3X5xzMqUbR6L,HDLtdMAy7wPkl8aKC3O2,'video',url)
	return
def hm4kawIPKp3oMrC75dJZA9HS2(search,url=HQmDERMFjx):
	search,GXVabd4sc2u3zp0JI,showDialogs = x0pzMENwy84tBcZvXr(search)
	if not search: search = q156m84QoYrn()
	if not search: return
	q5qfEX4yA6lDop1 = search.replace(oQpxmKiRPlHeGsLXNrJF78O,'%20')
	if not url: url = e2VR8nohduY+'/search?query='+q5qfEX4yA6lDop1
	else: url = url+'?title='+q5qfEX4yA6lDop1+'&genre=&year=&lang='
	c8wfGju4CWZm(url,'search')
	return
def Fhzowv4lbkLBY(url):
	url = url.split('/smartemadfilter?')[0]
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(H5x4Z2qPwR8vXM,'GET',url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'EGYBEST1-GET_FILTERS_BLOCKS-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	jnPZuGqg9F5viBUp = []
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('form-row(.*?)</form>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		jnPZuGqg9F5viBUp = DyVGS3dX0ZxR.findall('select name="(.*?)".*?value>(.*?)<(.*?)</select',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		PPxLnY9KDefQulFd5C8vU,szxwkVQTmqev0jGiK78HJIbN4uDOd,bUzHWnGg5t1 = zip(*jnPZuGqg9F5viBUp)
		jnPZuGqg9F5viBUp = zip(szxwkVQTmqev0jGiK78HJIbN4uDOd,PPxLnY9KDefQulFd5C8vU,bUzHWnGg5t1)
	return jnPZuGqg9F5viBUp
def jfcC3ErztgW9dw(MJ2gSPyTl9hzoi1):
	items = DyVGS3dX0ZxR.findall('value="(.*?)">(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	return items
def gghkponM41G6TdLBsrS3(url):
	url = url.replace('/smartemadfilter?','?title=&')
	return url
XXC6FzPWVjQnMEldGeTLwpxD = ['year','lang','genre']
PydiDZOp6H = ['year','lang','genre']
def ooxUXkcTj5PF4ad2SwYy(url,filter):
	url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==HQmDERMFjx: eA0pnTuMvxrdmoRC9zPBh,mwhEr8eXxD21MAKfHUSlB = HQmDERMFjx,HQmDERMFjx
	else: eA0pnTuMvxrdmoRC9zPBh,mwhEr8eXxD21MAKfHUSlB = filter.split('___')
	if type=='DEFINED_FILTER':
		if PydiDZOp6H[0]+'=' not in eA0pnTuMvxrdmoRC9zPBh: WF2vkePC5gbXAGUarcqlpmB3Q = PydiDZOp6H[0]
		for yuYts1RONXgp in range(len(PydiDZOp6H[0:-1])):
			if PydiDZOp6H[yuYts1RONXgp]+'=' in eA0pnTuMvxrdmoRC9zPBh: WF2vkePC5gbXAGUarcqlpmB3Q = PydiDZOp6H[yuYts1RONXgp+1]
		Cm5jWJgr28TlUnoZYHAxdPI3OB = eA0pnTuMvxrdmoRC9zPBh+'&'+WF2vkePC5gbXAGUarcqlpmB3Q+'=0'
		RRDtwVh6LbFiEycHNQkId5Cefmq = mwhEr8eXxD21MAKfHUSlB+'&'+WF2vkePC5gbXAGUarcqlpmB3Q+'=0'
		GSPtdslyxQURmB5obg69VJMY1jE = Cm5jWJgr28TlUnoZYHAxdPI3OB.strip('&')+'___'+RRDtwVh6LbFiEycHNQkId5Cefmq.strip('&')
		J4asIxU7Zyq5PiN2rKEctegFV = jlZtWwMfosJFIKenicqU1(mwhEr8eXxD21MAKfHUSlB,'all')
		SSHjMN4uegZfb2 = url+'/smartemadfilter?'+J4asIxU7Zyq5PiN2rKEctegFV
	elif type=='FULL_FILTER':
		v2s9V6uhIT0aCjkPOl7iUqZxB = jlZtWwMfosJFIKenicqU1(eA0pnTuMvxrdmoRC9zPBh,'modified_values')
		v2s9V6uhIT0aCjkPOl7iUqZxB = xx9LK4VzpF6IHXSEyhmrQwbg25P0(v2s9V6uhIT0aCjkPOl7iUqZxB)
		if mwhEr8eXxD21MAKfHUSlB: mwhEr8eXxD21MAKfHUSlB = jlZtWwMfosJFIKenicqU1(mwhEr8eXxD21MAKfHUSlB,'all')
		if not mwhEr8eXxD21MAKfHUSlB: SSHjMN4uegZfb2 = url
		else: SSHjMN4uegZfb2 = url+'/smartemadfilter?'+mwhEr8eXxD21MAKfHUSlB
		jDcWv7MAkEV = gghkponM41G6TdLBsrS3(SSHjMN4uegZfb2)
		CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'أظهار قائمة الفيديو التي تم اختيارها ',jDcWv7MAkEV,771,HQmDERMFjx,'filter')
		CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+' [[   '+v2s9V6uhIT0aCjkPOl7iUqZxB+'   ]]',jDcWv7MAkEV,771,HQmDERMFjx,'filter')
		CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	jnPZuGqg9F5viBUp = Fhzowv4lbkLBY(url)
	dict = {}
	for name,DcpbqKxWsJRCSVkQyjf1,MJ2gSPyTl9hzoi1 in jnPZuGqg9F5viBUp:
		name = name.replace('كل ',HQmDERMFjx)
		items = jfcC3ErztgW9dw(MJ2gSPyTl9hzoi1)
		if '=' not in SSHjMN4uegZfb2: SSHjMN4uegZfb2 = url
		if type=='DEFINED_FILTER':
			if WF2vkePC5gbXAGUarcqlpmB3Q!=DcpbqKxWsJRCSVkQyjf1: continue
			elif len(items)<2:
				if DcpbqKxWsJRCSVkQyjf1==PydiDZOp6H[-1]:
					jDcWv7MAkEV = gghkponM41G6TdLBsrS3(SSHjMN4uegZfb2)
					c8wfGju4CWZm(jDcWv7MAkEV)
				else: ooxUXkcTj5PF4ad2SwYy(SSHjMN4uegZfb2,'DEFINED_FILTER___'+GSPtdslyxQURmB5obg69VJMY1jE)
				return
			else:
				if DcpbqKxWsJRCSVkQyjf1==PydiDZOp6H[-1]:
					jDcWv7MAkEV = gghkponM41G6TdLBsrS3(SSHjMN4uegZfb2)
					CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'الجميع ',jDcWv7MAkEV,771,HQmDERMFjx,'filter')
				else: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'الجميع ',SSHjMN4uegZfb2,775,HQmDERMFjx,HQmDERMFjx,GSPtdslyxQURmB5obg69VJMY1jE)
		elif type=='FULL_FILTER':
			Cm5jWJgr28TlUnoZYHAxdPI3OB = eA0pnTuMvxrdmoRC9zPBh+'&'+DcpbqKxWsJRCSVkQyjf1+'=0'
			RRDtwVh6LbFiEycHNQkId5Cefmq = mwhEr8eXxD21MAKfHUSlB+'&'+DcpbqKxWsJRCSVkQyjf1+'=0'
			GSPtdslyxQURmB5obg69VJMY1jE = Cm5jWJgr28TlUnoZYHAxdPI3OB+'___'+RRDtwVh6LbFiEycHNQkId5Cefmq
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'الجميع :'+name,SSHjMN4uegZfb2,774,HQmDERMFjx,HQmDERMFjx,GSPtdslyxQURmB5obg69VJMY1jE)
		dict[DcpbqKxWsJRCSVkQyjf1] = {}
		for value,yewoKb5dkfHu1xEZMAsY in items:
			if not value: continue
			if yewoKb5dkfHu1xEZMAsY in FwhZ0nXtpoHTMarf: continue
			dict[DcpbqKxWsJRCSVkQyjf1][value] = yewoKb5dkfHu1xEZMAsY
			Cm5jWJgr28TlUnoZYHAxdPI3OB = eA0pnTuMvxrdmoRC9zPBh+'&'+DcpbqKxWsJRCSVkQyjf1+'='+yewoKb5dkfHu1xEZMAsY
			RRDtwVh6LbFiEycHNQkId5Cefmq = mwhEr8eXxD21MAKfHUSlB+'&'+DcpbqKxWsJRCSVkQyjf1+'='+value
			CEniUGWr4jMy = Cm5jWJgr28TlUnoZYHAxdPI3OB+'___'+RRDtwVh6LbFiEycHNQkId5Cefmq
			title = yewoKb5dkfHu1xEZMAsY+' :'#+dict[DcpbqKxWsJRCSVkQyjf1]['0']
			title = yewoKb5dkfHu1xEZMAsY+' :'+name
			if type=='FULL_FILTER': CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,url,774,HQmDERMFjx,HQmDERMFjx,CEniUGWr4jMy)
			elif type=='DEFINED_FILTER' and PydiDZOp6H[-2]+'=' in eA0pnTuMvxrdmoRC9zPBh:
				J4asIxU7Zyq5PiN2rKEctegFV = jlZtWwMfosJFIKenicqU1(RRDtwVh6LbFiEycHNQkId5Cefmq,'modified_filters')
				SSHjMN4uegZfb2 = url+'/smartemadfilter?'+J4asIxU7Zyq5PiN2rKEctegFV
				jDcWv7MAkEV = gghkponM41G6TdLBsrS3(SSHjMN4uegZfb2)
				CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,jDcWv7MAkEV,771,HQmDERMFjx,'filter')
			elif type=='DEFINED_FILTER': CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,url,775,HQmDERMFjx,HQmDERMFjx,CEniUGWr4jMy)
	return
def jlZtWwMfosJFIKenicqU1(Eya9L4IY3GxqtNoVWegDcPuOR,mode):
	Eya9L4IY3GxqtNoVWegDcPuOR = Eya9L4IY3GxqtNoVWegDcPuOR.replace('=&','=0&')
	Eya9L4IY3GxqtNoVWegDcPuOR = Eya9L4IY3GxqtNoVWegDcPuOR.strip('&')
	AAwtDoF34Y890RXse = {}
	if '=' in Eya9L4IY3GxqtNoVWegDcPuOR:
		items = Eya9L4IY3GxqtNoVWegDcPuOR.split('&')
		for A07BpVeRJToLb in items:
			airVhHdqCb6Gf49eERSjv1,value = A07BpVeRJToLb.split('=')
			AAwtDoF34Y890RXse[airVhHdqCb6Gf49eERSjv1] = value
	n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6 = HQmDERMFjx
	for key in XXC6FzPWVjQnMEldGeTLwpxD:
		if key in list(AAwtDoF34Y890RXse.keys()): value = AAwtDoF34Y890RXse[key]
		else: value = '0'
		if '%' not in value: value = VVkOtyQLzxBr(value)
		if mode=='modified_values' and value!='0': n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6 = n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6+' + '+value
		elif mode=='modified_filters' and value!='0': n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6 = n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6+'&'+key+'='+value
		elif mode=='all': n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6 = n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6+'&'+key+'='+value
	n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6 = n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6.strip(' + ')
	n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6 = n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6.strip('&')
	n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6 = n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6.replace('=0','=')
	return n0nmrIHWQBKqS4t9iNOfYJdyEwAUV6
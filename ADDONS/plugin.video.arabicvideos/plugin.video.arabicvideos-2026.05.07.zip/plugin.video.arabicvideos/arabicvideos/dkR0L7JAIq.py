# -*- coding: utf-8 -*-
from FF68kA5BUy import *
HDLtdMAy7wPkl8aKC3O2 = 'CIMA4P'
EEJvXQzSZNt = '_C4P_'
e2VR8nohduY = Jzthpc2nj5.SITESURLS[HDLtdMAy7wPkl8aKC3O2][0]
FwhZ0nXtpoHTMarf = ['الرئيسية','يلا شوت','مشاهدة لاحقا']
def kk6X5LxpsND(mode,url,text):
	if   mode==880: zLZUkrP7ac5 = afkxo7FyZWB4O6K1eXrs5I()
	elif mode==881: zLZUkrP7ac5 = c8wfGju4CWZm(url,text)
	elif mode==882: zLZUkrP7ac5 = f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url)
	elif mode==883: zLZUkrP7ac5 = vVEYRBwQnUfWx1KGMIucF4h(url)
	elif mode==889: zLZUkrP7ac5 = hm4kawIPKp3oMrC75dJZA9HS2(text)
	else: zLZUkrP7ac5 = False
	return zLZUkrP7ac5
def afkxo7FyZWB4O6K1eXrs5I():
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',e2VR8nohduY,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'CIMA4P-MENU-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'بحث في الموقع',HQmDERMFjx,889,HQmDERMFjx,HQmDERMFjx,'_REMEMBERRESULTS_')
	CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"primary-links"(.*?)</u',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('href="(.*?)".*?<span>(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,title in items:
			if title in FwhZ0nXtpoHTMarf: continue
			CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,881)
	return
def c8wfGju4CWZm(url,type=HQmDERMFjx):
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'CIMA4P-TITLES-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('"home-content"(.*?)"footer"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		MJ2gSPyTl9hzoi1 = MJ2gSPyTl9hzoi1.replace('"overlay"','"duration"><')
		items = DyVGS3dX0ZxR.findall('"thumb".*?data-src="(.*?)".*?"duration">(.*?)<.*?href="([^"]*)" title="([^"]*)"',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		ORMkTYjJ1p7 = []
		for uIGD4vZcP61QNmw78LXqoEpH,OMDCpSL7ZB,vn1grP3y4It9GmVuBbLJfz2A,title in items:
			title = title.strip(' ')
			title = SVsiEWeRf6oIynqQx8pCrM4Tk(title)
			yTz8SOkAhu24j6apo9BmZHvwWsX = DyVGS3dX0ZxR.findall('(.*?) (الحلقة|حلقة).\d+',title,DyVGS3dX0ZxR.DOTALL)
			if 'episodes' not in type and yTz8SOkAhu24j6apo9BmZHvwWsX:
				title = '_MOD_' + yTz8SOkAhu24j6apo9BmZHvwWsX[0][0]
				title = title.replace('اون لاين',HQmDERMFjx)
				if title not in ORMkTYjJ1p7:
					CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,883,uIGD4vZcP61QNmw78LXqoEpH)
					ORMkTYjJ1p7.append(title)
			else: CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,882,uIGD4vZcP61QNmw78LXqoEpH,OMDCpSL7ZB)
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('''["']pagination["'](.*?)["']footer["']''',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		type = 'episodes_pages' if 'episodes' in type else 'pages'
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('href="(.*?)">(.*?)</a>',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,title in items:
			title = SVsiEWeRf6oIynqQx8pCrM4Tk(title)
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'صفحة '+title,vn1grP3y4It9GmVuBbLJfz2A,881,HQmDERMFjx,HQmDERMFjx,type)
	return
def vVEYRBwQnUfWx1KGMIucF4h(url):
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'CIMA4P-SERIES-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('class="eplist"(.*?)</div>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		EX6nDt50Hih9mIxulw7kpMCZfaOsJR = DyVGS3dX0ZxR.findall('href="([^"]*)" title="([^"]*)"',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,title in EX6nDt50Hih9mIxulw7kpMCZfaOsJR:
			CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,882)
	else:
		vn1grP3y4It9GmVuBbLJfz2A = DyVGS3dX0ZxR.findall('"category".*?href="(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if vn1grP3y4It9GmVuBbLJfz2A:
			vn1grP3y4It9GmVuBbLJfz2A = VVkOtyQLzxBr(vn1grP3y4It9GmVuBbLJfz2A[0])
			c8wfGju4CWZm(vn1grP3y4It9GmVuBbLJfz2A,'episodes')
	return
def f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url):
	KWnAuJIFyESQHjP3X5xzMqUbR6L = []
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'CIMA4P-PLAY-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	if 'hash=' in CzNPJydxQLfw27tv4ZF8KORAbX5:
		kJwLndeiCfbKDUMOVyhXAZg5qB2cTs = DyVGS3dX0ZxR.findall('hash=(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		kJwLndeiCfbKDUMOVyhXAZg5qB2cTs = list(set(kJwLndeiCfbKDUMOVyhXAZg5qB2cTs))
		for mmQfkxEvd9GnXU0ZCNOriYyJql1aF in kJwLndeiCfbKDUMOVyhXAZg5qB2cTs:
			C9DNEqITybLQ4KjpZ8u37tPJGw = []
			DDAoB3rdfJTXuE2RQwK8 = mmQfkxEvd9GnXU0ZCNOriYyJql1aF.split('__')
			for UtpTluQS06HA in DDAoB3rdfJTXuE2RQwK8:
				try:
					UtpTluQS06HA = x4aBluXo02G1eTPr9c.b64decode(UtpTluQS06HA+'=')
					if HH6mxXjgcrEN1aenMFWQkS: UtpTluQS06HA = UtpTluQS06HA.decode(Zex6D4tJE52r)
					C9DNEqITybLQ4KjpZ8u37tPJGw.append(UtpTluQS06HA)
				except: pass
			jzTLleJs8x9Hb1 = '>'.join(C9DNEqITybLQ4KjpZ8u37tPJGw)
			jzTLleJs8x9Hb1 = jzTLleJs8x9Hb1.splitlines()
			for vn1grP3y4It9GmVuBbLJfz2A in jzTLleJs8x9Hb1:
				if ' => ' in vn1grP3y4It9GmVuBbLJfz2A:
					title,vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A.split(' => ')
					vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A+'?named='+title+'__watch'
					KWnAuJIFyESQHjP3X5xzMqUbR6L.append(vn1grP3y4It9GmVuBbLJfz2A)
	elif 'post_id' in CzNPJydxQLfw27tv4ZF8KORAbX5:
		oogPV1HKSJbGBql46sD25 = DyVGS3dX0ZxR.findall("post_id = '(.*?)'",CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		if oogPV1HKSJbGBql46sD25:
			oogPV1HKSJbGBql46sD25 = oogPV1HKSJbGBql46sD25[0]
			headers = {'X-Requested-With':'XMLHttpRequest'}
			Jq6yRaXtmufPFIjBOz4ZQ8 = e2VR8nohduY+'/wp-content/themes/cima2026/admin-ajax.php?action=mwp_post_data&post_id='+oogPV1HKSJbGBql46sD25
			vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',Jq6yRaXtmufPFIjBOz4ZQ8,HQmDERMFjx,headers,HQmDERMFjx,HQmDERMFjx,'CIMA4P-PLAY-2nd')
			irX8f7Yv4BGM5O = vGXnw9VcUN.content
			of3WcCOFazKTk7 = DyVGS3dX0ZxR.findall('"name":"(.*?)","src":"(.*?)"',irX8f7Yv4BGM5O,DyVGS3dX0ZxR.DOTALL)
			if not of3WcCOFazKTk7:
				of3WcCOFazKTk7 = DyVGS3dX0ZxR.findall('"src":"(.*?)"',irX8f7Yv4BGM5O,DyVGS3dX0ZxR.DOTALL)
				if of3WcCOFazKTk7:
					DhQsuTOgbRUv = ['']*len(of3WcCOFazKTk7)
					of3WcCOFazKTk7 = list(zip(DhQsuTOgbRUv,of3WcCOFazKTk7))
			for name,vn1grP3y4It9GmVuBbLJfz2A in of3WcCOFazKTk7:
				vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A.replace('\\/',xufJqQcGnhboiVy2wd)
				vn1grP3y4It9GmVuBbLJfz2A = VVkOtyQLzxBr(vn1grP3y4It9GmVuBbLJfz2A)
				KWnAuJIFyESQHjP3X5xzMqUbR6L.append(vn1grP3y4It9GmVuBbLJfz2A+'?named='+name+'__watch')
			cjfepMobZyFTuwq7WS1EV945L3g = e2VR8nohduY+'/wp-content/themes/cima2026/admin-ajax.php?action=mwp_generate_video_download_link&post_id='+oogPV1HKSJbGBql46sD25+'&video_id=null&video_url=null&video_source=custom'
			vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',cjfepMobZyFTuwq7WS1EV945L3g,HQmDERMFjx,headers,HQmDERMFjx,HQmDERMFjx,'CIMA4P-PLAY-3rd')
			b3L20nx7qwHKTS6so = vGXnw9VcUN.content
			lZaPL0ctONk = DyVGS3dX0ZxR.findall('href="(.*?)".*?>(.*?)<',b3L20nx7qwHKTS6so,DyVGS3dX0ZxR.DOTALL)
			if lZaPL0ctONk:
				ZZxvK9f2og1z3Ik5GSHr,rYnH3JTL05Sd = zip(*lZaPL0ctONk)
				lZaPL0ctONk = list(zip(rYnH3JTL05Sd,ZZxvK9f2og1z3Ik5GSHr))
			for name,vn1grP3y4It9GmVuBbLJfz2A in lZaPL0ctONk:
				vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A.replace('\\/',xufJqQcGnhboiVy2wd)
				vn1grP3y4It9GmVuBbLJfz2A = VVkOtyQLzxBr(vn1grP3y4It9GmVuBbLJfz2A)
				KWnAuJIFyESQHjP3X5xzMqUbR6L.append(vn1grP3y4It9GmVuBbLJfz2A+'?named='+name+'__download')
	import NsD5AomUqH
	NsD5AomUqH.NZcWGBmgFEen5hvJjUSIzOCVk7(KWnAuJIFyESQHjP3X5xzMqUbR6L,HDLtdMAy7wPkl8aKC3O2,'video',url)
	return
def hm4kawIPKp3oMrC75dJZA9HS2(search):
	search,GXVabd4sc2u3zp0JI,showDialogs = x0pzMENwy84tBcZvXr(search)
	if search==HQmDERMFjx: search = q156m84QoYrn()
	if search==HQmDERMFjx: return
	search = search.replace(oQpxmKiRPlHeGsLXNrJF78O,'+')
	url = e2VR8nohduY+'/?s='+search
	c8wfGju4CWZm(url,'search')
	return
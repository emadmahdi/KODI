# -*- coding: utf-8 -*-
from FF68kA5BUy import *
HDLtdMAy7wPkl8aKC3O2 = 'LIVETV'
e2VR8nohduY = Jzthpc2nj5.SITESURLS['PYTHON'][0]
def kk6X5LxpsND(mode,url):
	if   mode==100: zLZUkrP7ac5 = afkxo7FyZWB4O6K1eXrs5I()
	elif mode==101: zLZUkrP7ac5 = ddJ6F4hjPOTzKf0ulbQEoq7nwCV2('0',True)
	elif mode==102: zLZUkrP7ac5 = ddJ6F4hjPOTzKf0ulbQEoq7nwCV2('1',True)
	elif mode==103: zLZUkrP7ac5 = ddJ6F4hjPOTzKf0ulbQEoq7nwCV2('2',True)
	elif mode==104: zLZUkrP7ac5 = ddJ6F4hjPOTzKf0ulbQEoq7nwCV2('3',True)
	elif mode==105: zLZUkrP7ac5 = f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url)
	elif mode==106: zLZUkrP7ac5 = ddJ6F4hjPOTzKf0ulbQEoq7nwCV2('4',True)
	else: zLZUkrP7ac5 = False
	return zLZUkrP7ac5
def afkxo7FyZWB4O6K1eXrs5I():
	CfgK4s13Q0hZcHyleT2bVJO9('folder','_M3U_'+'قوائم فيديوهات M3U',HQmDERMFjx,762)
	CfgK4s13Q0hZcHyleT2bVJO9('folder','_IPT_'+'قوائم فيديوهات IPTV',HQmDERMFjx,761)
	CfgK4s13Q0hZcHyleT2bVJO9('folder','_TV0_'+'قنوات من مواقعها الأصلية',HQmDERMFjx,101)
	CfgK4s13Q0hZcHyleT2bVJO9('folder','_TV4_'+'قنوات مختارة من يوتيوب',HQmDERMFjx,106)
	CfgK4s13Q0hZcHyleT2bVJO9('folder','_YUT_'+'قنوات عربية من يوتيوب',HQmDERMFjx,147)
	CfgK4s13Q0hZcHyleT2bVJO9('folder','_YUT_'+'قنوات أجنبية من يوتيوب',HQmDERMFjx,148)
	CfgK4s13Q0hZcHyleT2bVJO9('folder','_IFL_'+'  قناة آي فيلم من موقعهم  ',HQmDERMFjx,28)
	CfgK4s13Q0hZcHyleT2bVJO9('live','_MRF_'+'قناة المعارف من موقعهم',HQmDERMFjx,41)
	CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	CfgK4s13Q0hZcHyleT2bVJO9('folder','_TV1_'+'قنوات تلفزيونية عامة',HQmDERMFjx,102)
	CfgK4s13Q0hZcHyleT2bVJO9('folder','_TV2_'+'قنوات تلفزيونية خاصة',HQmDERMFjx,103)
	CfgK4s13Q0hZcHyleT2bVJO9('folder','_TV3_'+'قنوات تلفزيونية للفحص',HQmDERMFjx,104)
	return
def ddJ6F4hjPOTzKf0ulbQEoq7nwCV2(t7IyszW0jv,showDialogs=True):
	EEJvXQzSZNt = '_TV'+t7IyszW0jv+'_'
	QRw49Dc0SXgn6lzP5jFBe = {'id':HQmDERMFjx,'user':Jzthpc2nj5.AV_CLIENT_IDS,'function':'list','menu':t7IyszW0jv}
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(LLwINhcX2RHSWqpmEnz,'POST',e2VR8nohduY,QRw49Dc0SXgn6lzP5jFBe,HQmDERMFjx,HQmDERMFjx,HQmDERMFjx,'LIVETV-ITEMS-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	items = DyVGS3dX0ZxR.findall('([^;\r\n]+?);;(.*?);;(.*?);;(.*?);;(.*?);;',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if items:
		for yuYts1RONXgp in range(len(items)):
			name = items[yuYts1RONXgp][3]
			start = name[0:2]
			start = start.replace('al','Al')
			start = start.replace('El','Al')
			start = start.replace('AL','Al')
			start = start.replace('EL','Al')
			name = start+name[2:]
			start = name[0:3]
			start = start.replace('Al-','Al')
			start = start.replace('Al ','Al')
			name = start+name[3:]
			items[yuYts1RONXgp] = items[yuYts1RONXgp][0],items[yuYts1RONXgp][1],items[yuYts1RONXgp][2],name,items[yuYts1RONXgp][4]
		items = set(items)
		items = sorted(items, reverse=False, key=lambda key: key[0].lower())
		items = sorted(items, reverse=False, key=lambda key: key[3].lower())
		for Zj0LzdFcx6AeNwM,pYVvlGR1ES0gdtzayiDqb9w,ZLRQYEUBNPSl3XTxze6Iug,name,uIGD4vZcP61QNmw78LXqoEpH in items:
			if '#' in Zj0LzdFcx6AeNwM: continue
			if Zj0LzdFcx6AeNwM!='URL': name = name+ao3Q5jP8H0sMxK2iUYwZGE+xoZHpTRUzS9+Zj0LzdFcx6AeNwM+cjqzOQ5GXD4kR
			url = Zj0LzdFcx6AeNwM+';;'+pYVvlGR1ES0gdtzayiDqb9w+';;'+ZLRQYEUBNPSl3XTxze6Iug+';;'+t7IyszW0jv
			CfgK4s13Q0hZcHyleT2bVJO9('live',EEJvXQzSZNt+HQmDERMFjx+name,url,105,uIGD4vZcP61QNmw78LXqoEpH)
	else:
		if showDialogs: CfgK4s13Q0hZcHyleT2bVJO9('link',EEJvXQzSZNt+'هذه الخدمة مخصصة للمبرمج فقط',HQmDERMFjx,9999)
	return
def f0vdEa8oPRTYSesnmNuklQx7I2zXbq(id):
	Zj0LzdFcx6AeNwM,pYVvlGR1ES0gdtzayiDqb9w,ZLRQYEUBNPSl3XTxze6Iug,t7IyszW0jv = id.split(';;')
	url = HQmDERMFjx
	if Zj0LzdFcx6AeNwM=='URL': url = ZLRQYEUBNPSl3XTxze6Iug
	elif Zj0LzdFcx6AeNwM=='YOUTUBE':
		url = Jzthpc2nj5.SITESURLS['YOUTUBE'][0]+'/watch?v='+ZLRQYEUBNPSl3XTxze6Iug
		import NsD5AomUqH
		NsD5AomUqH.NZcWGBmgFEen5hvJjUSIzOCVk7([url],HDLtdMAy7wPkl8aKC3O2,'live',url)
		return
	elif Zj0LzdFcx6AeNwM=='GA':
		QRw49Dc0SXgn6lzP5jFBe = { 'id' : HQmDERMFjx, 'user' : Jzthpc2nj5.AV_CLIENT_IDS , 'function' : 'playGA1' , 'menu' : HQmDERMFjx }
		vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(LLwINhcX2RHSWqpmEnz,'GET',e2VR8nohduY,QRw49Dc0SXgn6lzP5jFBe,HQmDERMFjx,False,HQmDERMFjx,'LIVETV-PLAY-1st')
		if not vGXnw9VcUN.succeeded:
			u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,'هذه الخدمة مخصصة للمبرمج فقط')
			return
		CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
		cookies = vGXnw9VcUN.cookies
		rL09QFiCp23R5c1xYIXJTn = cookies['ASP.NET_SessionId']
		url = vGXnw9VcUN.headers['Location']
		QRw49Dc0SXgn6lzP5jFBe = { 'id' : ZLRQYEUBNPSl3XTxze6Iug , 'user' : Jzthpc2nj5.AV_CLIENT_IDS , 'function' : 'playGA2' , 'menu' : HQmDERMFjx }
		headers = { 'Cookie' : 'ASP.NET_SessionId='+rL09QFiCp23R5c1xYIXJTn }
		vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(LLwINhcX2RHSWqpmEnz,'GET',e2VR8nohduY,QRw49Dc0SXgn6lzP5jFBe,headers,HQmDERMFjx,HQmDERMFjx,'LIVETV-PLAY-2nd')
		if not vGXnw9VcUN.succeeded:
			u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,'هذه الخدمة مخصصة للمبرمج فقط')
			return
		CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
		url = DyVGS3dX0ZxR.findall('resp":"(http.*?m3u8)(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		vn1grP3y4It9GmVuBbLJfz2A = url[0][0]
		lew3BALR7s = url[0][1]
		R8LyhzAiNbUro2mnfauVxdpEMKclX0 = 'http://38.'+pYVvlGR1ES0gdtzayiDqb9w+'777/'+ZLRQYEUBNPSl3XTxze6Iug+'_HD.m3u8'+lew3BALR7s
		xlj8BP1w4p73zSmohfVDQ = R8LyhzAiNbUro2mnfauVxdpEMKclX0.replace('36:7','40:7').replace('_HD.m3u8','.m3u8')
		Ot6hYbx5cKTzN = R8LyhzAiNbUro2mnfauVxdpEMKclX0.replace('36:7','42:7').replace('_HD.m3u8','.m3u8')
		gBzGTxKMSVWFLPvfAI0UZ98D5 = ['HD','SD1','SD2']
		Na8vklCpUGYIzP0bjutWOT = [R8LyhzAiNbUro2mnfauVxdpEMKclX0,xlj8BP1w4p73zSmohfVDQ,Ot6hYbx5cKTzN]
		lwT9cdaH5AxMU8IpZif20jPX = 0
		if lwT9cdaH5AxMU8IpZif20jPX == -1: return
		else: url = Na8vklCpUGYIzP0bjutWOT[lwT9cdaH5AxMU8IpZif20jPX]
	elif Zj0LzdFcx6AeNwM=='NT':
		headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
		QRw49Dc0SXgn6lzP5jFBe = { 'id' : ZLRQYEUBNPSl3XTxze6Iug , 'user' : Jzthpc2nj5.AV_CLIENT_IDS , 'function' : 'playNT' , 'menu' : t7IyszW0jv }
		vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(LLwINhcX2RHSWqpmEnz,'POST', e2VR8nohduY, QRw49Dc0SXgn6lzP5jFBe, headers, False,HQmDERMFjx,'LIVETV-PLAY-3rd')
		if not vGXnw9VcUN.succeeded:
			u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,'هذه الخدمة مخصصة للمبرمج فقط')
			return
		CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
		url = vGXnw9VcUN.headers['Location']
		url = url.replace('%20',oQpxmKiRPlHeGsLXNrJF78O)
		url = url.replace('%3D','=')
		if 'Learn' in ZLRQYEUBNPSl3XTxze6Iug:
			url = url.replace('NTNNile',HQmDERMFjx)
			url = url.replace('learning1','Learning')
	elif Zj0LzdFcx6AeNwM=='PL':
		QRw49Dc0SXgn6lzP5jFBe = { 'id' : ZLRQYEUBNPSl3XTxze6Iug , 'user' : Jzthpc2nj5.AV_CLIENT_IDS , 'function' : 'playPL' , 'menu' : t7IyszW0jv }
		vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(LLwINhcX2RHSWqpmEnz,'POST', e2VR8nohduY, QRw49Dc0SXgn6lzP5jFBe, HQmDERMFjx,False,HQmDERMFjx,'LIVETV-PLAY-4th')
		if not vGXnw9VcUN.succeeded:
			u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,'هذه الخدمة مخصصة للمبرمج فقط')
			return
		CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
		url = vGXnw9VcUN.headers['Location']
		headers = {'Referer':vGXnw9VcUN.headers['Referer']}
		vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(rwjfOIqQU3ANa0JlWXvCDbFk,'POST',url, HQmDERMFjx,headers , HQmDERMFjx,HQmDERMFjx,'LIVETV-PLAY-5th')
		if not vGXnw9VcUN.succeeded:
			u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,'هذه الخدمة مخصصة للمبرمج فقط')
			return
		CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
		items = DyVGS3dX0ZxR.findall('source src="(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
		url = items[0]
	elif Zj0LzdFcx6AeNwM in ['TA','FM','YU','WS1','WS2','RL1','RL2']:
		if Zj0LzdFcx6AeNwM=='TA': ZLRQYEUBNPSl3XTxze6Iug = id
		headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
		QRw49Dc0SXgn6lzP5jFBe = { 'id' : ZLRQYEUBNPSl3XTxze6Iug , 'user' : Jzthpc2nj5.AV_CLIENT_IDS , 'function' : 'play'+Zj0LzdFcx6AeNwM , 'menu' : t7IyszW0jv }
		vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(LLwINhcX2RHSWqpmEnz,'POST',e2VR8nohduY,QRw49Dc0SXgn6lzP5jFBe,headers,HQmDERMFjx,HQmDERMFjx,'LIVETV-PLAY-6th')
		if not vGXnw9VcUN.succeeded:
			u0W7PAndK1IXU8rxz2jQaM(HQmDERMFjx,HQmDERMFjx,OO2BXYhI8UPNq6L,'هذه الخدمة مخصصة للمبرمج فقط')
			return
		CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
		url = vGXnw9VcUN.headers['Location']
		if Zj0LzdFcx6AeNwM=='FM':
			vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(rwjfOIqQU3ANa0JlWXvCDbFk,'GET', url, HQmDERMFjx, HQmDERMFjx, False,HQmDERMFjx,'LIVETV-PLAY-7th')
			url = vGXnw9VcUN.headers['Location']
			url = url.replace('https','http')
	uZVS3DcJbEULoxpve9IOTgmW6(url,HDLtdMAy7wPkl8aKC3O2,'live')
	return
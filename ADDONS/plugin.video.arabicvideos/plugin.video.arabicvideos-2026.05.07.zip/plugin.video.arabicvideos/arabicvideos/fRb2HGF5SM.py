# -*- coding: utf-8 -*-
from FF68kA5BUy import *
HDLtdMAy7wPkl8aKC3O2 = 'KARBALATV'
EEJvXQzSZNt = '_KRB_'
e2VR8nohduY = Jzthpc2nj5.SITESURLS[HDLtdMAy7wPkl8aKC3O2][0]
headers = {'User-Agent':HQmDERMFjx}
def kk6X5LxpsND(mode,url,text):
	if   mode==320: zLZUkrP7ac5 = afkxo7FyZWB4O6K1eXrs5I()
	elif mode==321: zLZUkrP7ac5 = c8wfGju4CWZm(url)
	elif mode==322: zLZUkrP7ac5 = f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url)
	elif mode==329: zLZUkrP7ac5 = hm4kawIPKp3oMrC75dJZA9HS2(text)
	else: zLZUkrP7ac5 = False
	return zLZUkrP7ac5
def afkxo7FyZWB4O6K1eXrs5I():
	CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'بحث في الموقع',HQmDERMFjx,329,HQmDERMFjx,HQmDERMFjx,'_REMEMBERRESULTS_')
	CfgK4s13Q0hZcHyleT2bVJO9('link',ao3Q5jP8H0sMxK2iUYwZGE+' ===== ===== ===== '+cjqzOQ5GXD4kR,HQmDERMFjx,9999)
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(H5x4Z2qPwR8vXM,'GET',e2VR8nohduY+'/video.php',HQmDERMFjx,headers,HQmDERMFjx,HQmDERMFjx,'KARBALATV-MENU-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('class="icono-plus"(.*?)</ul>',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	items = DyVGS3dX0ZxR.findall('href="(.*?)">(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	for vn1grP3y4It9GmVuBbLJfz2A,title in items:
		if title=='المكتبة المرئية': continue
		vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+vn1grP3y4It9GmVuBbLJfz2A
		CfgK4s13Q0hZcHyleT2bVJO9('folder',HDLtdMAy7wPkl8aKC3O2+'_SCRIPT_'+EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,321)
	return CzNPJydxQLfw27tv4ZF8KORAbX5
def c8wfGju4CWZm(url):
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(j9uzmBeEyK8,'GET',url,HQmDERMFjx,headers,HQmDERMFjx,HQmDERMFjx,'KARBALATV-TITLES-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('class="container"(.*?)class="footer',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
	items = DyVGS3dX0ZxR.findall('href="(.*?)".*?url\((.*?)\).*?pd5">(.*?)<.*?<h3.*?">(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	if not items: items = DyVGS3dX0ZxR.findall('href="(.*?)".*?src="(.*?)".*?alt="(.*?)".*?<p.*?>(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
	if not items:
		items = DyVGS3dX0ZxR.findall('href="([^"]*)" title="([^"]*)".*?background:url\(\'(.*?)\'\)',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		if items:
			jzTLleJs8x9Hb1,qP1wT2MFf0oK9Uv3u87QL,iT75pU3QIh0CWtwVj9Edr = zip(*items)
			items = zip(jzTLleJs8x9Hb1,iT75pU3QIh0CWtwVj9Edr,len(jzTLleJs8x9Hb1)*[HQmDERMFjx],qP1wT2MFf0oK9Uv3u87QL)
	for vn1grP3y4It9GmVuBbLJfz2A,uIGD4vZcP61QNmw78LXqoEpH,count,title in items:
		count = count.replace('عدد ',HQmDERMFjx).replace(oQpxmKiRPlHeGsLXNrJF78O,HQmDERMFjx)
		vn1grP3y4It9GmVuBbLJfz2A = vn1grP3y4It9GmVuBbLJfz2A.replace(xufJqQcGnhboiVy2wd,HQmDERMFjx)
		uIGD4vZcP61QNmw78LXqoEpH = uIGD4vZcP61QNmw78LXqoEpH.replace("'",HQmDERMFjx)
		if '.php' not in vn1grP3y4It9GmVuBbLJfz2A: vn1grP3y4It9GmVuBbLJfz2A = 'video.php'+vn1grP3y4It9GmVuBbLJfz2A
		vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+xufJqQcGnhboiVy2wd+vn1grP3y4It9GmVuBbLJfz2A
		uIGD4vZcP61QNmw78LXqoEpH = e2VR8nohduY+uIGD4vZcP61QNmw78LXqoEpH
		title = title.strip(oQpxmKiRPlHeGsLXNrJF78O)
		title = title+' ('+count+')'
		if 'video.php' in vn1grP3y4It9GmVuBbLJfz2A: CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,321,uIGD4vZcP61QNmw78LXqoEpH)
		elif 'watch.php' in vn1grP3y4It9GmVuBbLJfz2A: CfgK4s13Q0hZcHyleT2bVJO9('video',EEJvXQzSZNt+title,vn1grP3y4It9GmVuBbLJfz2A,322,uIGD4vZcP61QNmw78LXqoEpH)
	Ut7reR0XioMjOdYWZKsLIuc3TQJmC1 = DyVGS3dX0ZxR.findall('class="pagination(.*?)class="footer',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	if Ut7reR0XioMjOdYWZKsLIuc3TQJmC1:
		MJ2gSPyTl9hzoi1 = Ut7reR0XioMjOdYWZKsLIuc3TQJmC1[0]
		items = DyVGS3dX0ZxR.findall('href="(.*?)">(.*?)<',MJ2gSPyTl9hzoi1,DyVGS3dX0ZxR.DOTALL)
		for vn1grP3y4It9GmVuBbLJfz2A,title in items:
			vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+'/video.php'+vn1grP3y4It9GmVuBbLJfz2A
			CfgK4s13Q0hZcHyleT2bVJO9('folder',EEJvXQzSZNt+'صفحة '+title,vn1grP3y4It9GmVuBbLJfz2A,321)
	return
def f0vdEa8oPRTYSesnmNuklQx7I2zXbq(url):
	vGXnw9VcUN = U3GBj7agXTD1Lwze5SvO0H(LLwINhcX2RHSWqpmEnz,'GET',url,HQmDERMFjx,headers,HQmDERMFjx,HQmDERMFjx,'KARBALATV-PLAY-1st')
	CzNPJydxQLfw27tv4ZF8KORAbX5 = vGXnw9VcUN.content
	vn1grP3y4It9GmVuBbLJfz2A = DyVGS3dX0ZxR.findall('<video.*?src="(.*?)"',CzNPJydxQLfw27tv4ZF8KORAbX5,DyVGS3dX0ZxR.DOTALL)
	vn1grP3y4It9GmVuBbLJfz2A = e2VR8nohduY+vn1grP3y4It9GmVuBbLJfz2A[0]
	uZVS3DcJbEULoxpve9IOTgmW6(vn1grP3y4It9GmVuBbLJfz2A,HDLtdMAy7wPkl8aKC3O2,'video')
	return
def hm4kawIPKp3oMrC75dJZA9HS2(search):
	search,GXVabd4sc2u3zp0JI,showDialogs = x0pzMENwy84tBcZvXr(search)
	if search==HQmDERMFjx: search = q156m84QoYrn()
	if search==HQmDERMFjx: return
	search = search.replace(oQpxmKiRPlHeGsLXNrJF78O,'+')
	url = e2VR8nohduY+'/search.php?q='+search
	c8wfGju4CWZm(url)
	return
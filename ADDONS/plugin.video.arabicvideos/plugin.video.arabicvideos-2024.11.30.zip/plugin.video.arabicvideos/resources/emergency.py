# -*- coding: utf-8 -*-
import sys as oNvHiYIdn2346z8QG
WhBI4UY7dvcZNrS635oiGQgOKD = oNvHiYIdn2346z8QG.version_info [0] == 2
ZI6m0xBTKtVuU = 2048
lkZ8vxchL9SaRd = 7
def x09foHgpMNUZVKY (ibQjuow08NyKDgI4SxHze7s):
	global CCWOcJwYytX4hFAT
	r3HzlWeo957bwCNcvXhp0T8iZKUD = ord (ibQjuow08NyKDgI4SxHze7s [-1])
	RTkxb3lqDP4K = ibQjuow08NyKDgI4SxHze7s [:-1]
	B0fcFPYgHr = r3HzlWeo957bwCNcvXhp0T8iZKUD % len (RTkxb3lqDP4K)
	EIUJQqRop45DdGWH = RTkxb3lqDP4K [:B0fcFPYgHr] + RTkxb3lqDP4K [B0fcFPYgHr:]
	if WhBI4UY7dvcZNrS635oiGQgOKD:
		yyajsFfL8dR = unicode () .join ([unichr (ord (LLJOrIWlg1) - ZI6m0xBTKtVuU - (fFVBIehCL9RZ4mKtHvPEi1 + r3HzlWeo957bwCNcvXhp0T8iZKUD) % lkZ8vxchL9SaRd) for fFVBIehCL9RZ4mKtHvPEi1, LLJOrIWlg1 in enumerate (EIUJQqRop45DdGWH)])
	else:
		yyajsFfL8dR = str () .join ([chr (ord (LLJOrIWlg1) - ZI6m0xBTKtVuU - (fFVBIehCL9RZ4mKtHvPEi1 + r3HzlWeo957bwCNcvXhp0T8iZKUD) % lkZ8vxchL9SaRd) for fFVBIehCL9RZ4mKtHvPEi1, LLJOrIWlg1 in enumerate (EIUJQqRop45DdGWH)])
	return eval (yyajsFfL8dR)
dAghyP2kFUYu,LGxPjA6Rd53hcTq,N39vI0G5wRdPHobA4tJWCgKFpiXluh=x09foHgpMNUZVKY,x09foHgpMNUZVKY,x09foHgpMNUZVKY
UpQgk50KIXu,MVLWDmZrYcvK9Pyg2,ooY0IDFmUz2E=N39vI0G5wRdPHobA4tJWCgKFpiXluh,LGxPjA6Rd53hcTq,dAghyP2kFUYu
ciepk6LTmaxuvSRWtG8D,MpIKBxVyswh9Q2zRv6fWUGPbcrl,SDTHloJMxZPmfLI7OhbNtcdsAXi=ooY0IDFmUz2E,MVLWDmZrYcvK9Pyg2,UpQgk50KIXu
WhEBLNgqblsZ7IyQakUK4HduJA3,J2FhdIkMi7owqp4,EEKbUf7ScjA3vOWhG4=SDTHloJMxZPmfLI7OhbNtcdsAXi,MpIKBxVyswh9Q2zRv6fWUGPbcrl,ciepk6LTmaxuvSRWtG8D
RRO10nhebEQiGVp24YH9,Bca1Te4WjF2pQk,KFAPw7peyTmr3k6V=EEKbUf7ScjA3vOWhG4,J2FhdIkMi7owqp4,WhEBLNgqblsZ7IyQakUK4HduJA3
YHWjykwBox74Qhsp,PTcYq9k5WLAxN,CFonwOKY107qrB9axPdvUQ=KFAPw7peyTmr3k6V,Bca1Te4WjF2pQk,RRO10nhebEQiGVp24YH9
NEIcsFOGD1lax4HuywQX27S0,zzqH2aJ6Co0Vy8OrXxuGsiNBZAQ,g3tfivrqOXBRIUCzYh2TD7V=CFonwOKY107qrB9axPdvUQ,PTcYq9k5WLAxN,YHWjykwBox74Qhsp
bjqyL7uod61sghGnFX53WMVaZU0,R2fi4MGJrzWIVQ,V6VBGEAHRxW39FPisnmJSuYfK7=g3tfivrqOXBRIUCzYh2TD7V,zzqH2aJ6Co0Vy8OrXxuGsiNBZAQ,NEIcsFOGD1lax4HuywQX27S0
i4Lq2pMEB6xnJuAQfkst,jaq1LyS2t4,MWckCAmjTs1u=V6VBGEAHRxW39FPisnmJSuYfK7,R2fi4MGJrzWIVQ,bjqyL7uod61sghGnFX53WMVaZU0
bbn2AgoaGfmT6cXDRdY,r0vw6m2FOkRYpWnsSq8ao1,KuU9eiXySd3BvwmMtlYzIZp15nQsWk=MWckCAmjTs1u,jaq1LyS2t4,i4Lq2pMEB6xnJuAQfkst
vfm6ycVojL1gwnlJ,SzO6leLmiIsf24EBPNqtJGu0,PotxGOldnLMh=KuU9eiXySd3BvwmMtlYzIZp15nQsWk,r0vw6m2FOkRYpWnsSq8ao1,bbn2AgoaGfmT6cXDRdY
import xbmc as Q8DmKY2rtPRxh0LdEkXO7,xbmcgui as QQLYoJNE2WHlMnUO1Ak6apqDC,sys as oNvHiYIdn2346z8QG,os as isS3ugcCIPwDV6oZHJ48EYpWf,requests as yANfdYokznVgsCUXK24xM0R,re as ZgOyK1lM3xE0CpIGVP5thr,xbmcvfs as kTBsDOUNF21J,base64 as TvXAsdaGeKM,time as wyglQ3Tx10f2H9bLYqVZmJG8C
def evOEGw2r4FL0Yb(request):
	Lgcnf6Gzq4Oe8TN = ciepk6LTmaxuvSRWtG8D(u"ࠫࡧࡻࡳࡺࡦ࡬ࡥࡱࡵࡧ࡯ࡱࡦࡥࡳࡩࡥ࡭ࠩࠀ")
	if request==jaq1LyS2t4(u"ࠬࡹࡴࡢࡴࡷࠫࠁ"): Q8DmKY2rtPRxh0LdEkXO7.executebuiltin(bjqyL7uod61sghGnFX53WMVaZU0(u"࠭ࡁࡤࡶ࡬ࡺࡦࡺࡥࡘ࡫ࡱࡨࡴࡽࠨࠨࠂ")+Lgcnf6Gzq4Oe8TN+KFAPw7peyTmr3k6V(u"ࠧࠪࠩࠃ"))
	elif request==J2FhdIkMi7owqp4(u"ࠨࡵࡷࡳࡵ࠭ࠄ"): Q8DmKY2rtPRxh0LdEkXO7.executebuiltin(RRO10nhebEQiGVp24YH9(u"ࠩࡇ࡭ࡦࡲ࡯ࡨ࠰ࡆࡰࡴࡹࡥࠩࠩࠅ")+Lgcnf6Gzq4Oe8TN+YHWjykwBox74Qhsp(u"ࠪ࠭ࠬࠆ"))
	return
def zXcmWaS9dv2(athirBo9WHck7=KuU9eiXySd3BvwmMtlYzIZp15nQsWk(u"้ࠫ๎อสࠢส่๊็วห์ะࠫࠇ"),ZMj0iKCXlNO4PFWfva=EEKbUf7ScjA3vOWhG4(u"ࠬ࠭ࠈ")):
	x9enb6RpS3UKzdLWyfACjZwgQP5k71 = QQLYoJNE2WHlMnUO1Ak6apqDC.Dialog().input(athirBo9WHck7,ZMj0iKCXlNO4PFWfva,type=QQLYoJNE2WHlMnUO1Ak6apqDC.INPUT_ALPHANUM)
	x9enb6RpS3UKzdLWyfACjZwgQP5k71 = x9enb6RpS3UKzdLWyfACjZwgQP5k71.strip(r0vw6m2FOkRYpWnsSq8ao1(u"࠭ࠠࠨࠉ")).replace(jaq1LyS2t4(u"ࠧࠡࠢࠣࠤࠬࠊ"),i4Lq2pMEB6xnJuAQfkst(u"ࠨࠢࠪࠋ")).replace(r0vw6m2FOkRYpWnsSq8ao1(u"ࠩࠣࠤࠥ࠭ࠌ"),J2FhdIkMi7owqp4(u"ࠪࠤࠬࠍ")).replace(ooY0IDFmUz2E(u"ࠫࠥࠦࠧࠎ"),g3tfivrqOXBRIUCzYh2TD7V(u"ࠬࠦࠧࠏ"))
	return x9enb6RpS3UKzdLWyfACjZwgQP5k71
def oslIfbZvR3(text):
	athirBo9WHck7 = V6VBGEAHRxW39FPisnmJSuYfK7(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩࠐ")
	if fUHdliX5FgJR9cr8QxLZpTsKo6n3w: v7DtX1oNdg2kj = QQLYoJNE2WHlMnUO1Ak6apqDC.Dialog().yesno(athirBo9WHck7,text,jaq1LyS2t4(u"ࠧࠨࠑ"),bjqyL7uod61sghGnFX53WMVaZU0(u"ࠨࠩࠒ"),EEKbUf7ScjA3vOWhG4(u"ࠩๆ่ฬ࠭ࠓ"),N39vI0G5wRdPHobA4tJWCgKFpiXluh(u"๊ࠪ฾๋ࠧࠔ"))
	else: v7DtX1oNdg2kj = QQLYoJNE2WHlMnUO1Ak6apqDC.Dialog().yesno(athirBo9WHck7,text,LGxPjA6Rd53hcTq(u"่๊ࠫวࠨࠕ"),RRO10nhebEQiGVp24YH9(u"ࠬ์ูๆࠩࠖ"))
	return v7DtX1oNdg2kj
def crfdRND8sLkzQ9wlU(ORHnhQrDqGd9sSIpcYlyX1iwPZFtzj):
	v7DtX1oNdg2kj = oslIfbZvR3(KFAPw7peyTmr3k6V(u"࠭โษๆࠣษึูวๅࠢึะ้ࠦวๅลั฻ฬว๋ࠠฮหࠤศ์ࠠหึ฽่ࠥฮั็ษ่ะࠥ฿ๅศัࠣ์ฯ์สูำࠣัฯ๏ࠠหฺ๊ี๊ࠥใࠡษ็ู้อใๅ๋ࠢห้ษฮุษฤࠤ࠳࠴ฺ่ࠠา๋ฬࠦำ๋ไ๋้้่ࠥะ์ࠣฬฯูฬ๋ๆ๋ࠣีํࠠศๆุ่ฬ้ไ๊ࠡส่ศิืศรࠣๅ๏ࠦำอๆࠣห้ษฮุษฤࠤ࠳࠴้ࠠส฼ำ์อࠠใ็ࠣฬสืำศๆࠣืั๊ࠠศๆฦา฼อมࠡๆ็้อืๅอࠢ࠱࠲ࠥํไࠡฬิ๎ิࠦวๅฤ้ࠤสืำศๆࠣืั๊ࠠศๆฦา฼อมࠡว็ํࠥอไๆสิ้ัࠦฟࠢࠩࠗ"))
	if v7DtX1oNdg2kj==LGxPjA6Rd53hcTq(u"࠷ࢇ") and isS3ugcCIPwDV6oZHJ48EYpWf.path.exists(ORHnhQrDqGd9sSIpcYlyX1iwPZFtzj):
		message = zXcmWaS9dv2(MpIKBxVyswh9Q2zRv6fWUGPbcrl(u"ࠧฤๅอฬࠥืำศๆอ็ࠥอไห์ࠣฮึ๐ฯࠡวิืฬ๊็ศ่ࠢ฽ูࠥฬๅࠢส่ศิืศรࠪ࠘"))
		evOEGw2r4FL0Yb(SzO6leLmiIsf24EBPNqtJGu0(u"ࠨࡵࡷࡥࡷࡺࠧ࠙"))
		zGFBDdlr2J4bIgSQfmvh0OaWyon = Q8DmKY2rtPRxh0LdEkXO7.getInfoLabel(PTcYq9k5WLAxN(u"ࠩࡖࡽࡸࡺࡥ࡮࠰ࡄࡨࡩࡵ࡮ࡗࡧࡵࡷ࡮ࡵ࡮ࠩࠩࠚ")+zz0RpE3TmyCOjuvX7hLB+KFAPw7peyTmr3k6V(u"ࠪ࠭ࠬࠛ"))
		file = open(ORHnhQrDqGd9sSIpcYlyX1iwPZFtzj,WhEBLNgqblsZ7IyQakUK4HduJA3(u"ࠫࡷࡨࠧࠜ"))
		SSGltweajDKp8i1OZAmXqC7bBMJ = isS3ugcCIPwDV6oZHJ48EYpWf.path.getsize(ORHnhQrDqGd9sSIpcYlyX1iwPZFtzj)
		if SSGltweajDKp8i1OZAmXqC7bBMJ>dAghyP2kFUYu(u"࠳࠱࠳࠳࠴࠵࢈"): file.seek(-dAghyP2kFUYu(u"࠳࠱࠳࠳࠴࠵࢈"),isS3ugcCIPwDV6oZHJ48EYpWf.SEEK_END)
		data = file.read()
		file.close()
		data = data.decode(i4Lq2pMEB6xnJuAQfkst(u"ࠬࡻࡴࡧ࠺ࠪࠝ"))
		exYFwWvQNdAogC5 = ZgOyK1lM3xE0CpIGVP5thr.findall(N39vI0G5wRdPHobA4tJWCgKFpiXluh(u"ࠨࠧࡶࡵࡨࡶࡤ࡯ࡤࠨ࠼ࠣࠫ࠭࠴ࠪࡀࠫࠪࠦࠞ"),data,ZgOyK1lM3xE0CpIGVP5thr.DOTALL)
		if not exYFwWvQNdAogC5: exYFwWvQNdAogC5 = ZgOyK1lM3xE0CpIGVP5thr.findall(jaq1LyS2t4(u"ࠢࠨࡷࡶࡩࡷ࠭࠺ࠡࠩࠫ࠲࠯ࡅࠩࠨࠤࠟ"),data,ZgOyK1lM3xE0CpIGVP5thr.DOTALL)
		exYFwWvQNdAogC5 = exYFwWvQNdAogC5[i4Lq2pMEB6xnJuAQfkst(u"࠱ࢉ")] if exYFwWvQNdAogC5 else SDTHloJMxZPmfLI7OhbNtcdsAXi(u"ࠨ࠲࠳࠴࠵࠭ࠠ")
		exYFwWvQNdAogC5 = exYFwWvQNdAogC5.split(vfm6ycVojL1gwnlJ(u"ࠩ࡟ࡲࠬࠡ"),ciepk6LTmaxuvSRWtG8D(u"࠳ࢊ"))[SDTHloJMxZPmfLI7OhbNtcdsAXi(u"࠳ࢋ")]
		if fUHdliX5FgJR9cr8QxLZpTsKo6n3w: exYFwWvQNdAogC5 = exYFwWvQNdAogC5.encode(KuU9eiXySd3BvwmMtlYzIZp15nQsWk(u"ࠪࡹࡹ࡬࠸ࠨࠢ"))
		VgvTJqr3pIxykiYPt1eCo0h4l = MpIKBxVyswh9Q2zRv6fWUGPbcrl(u"ࠫࡆ࡜࠺ࠡࠩࠣ")+exYFwWvQNdAogC5+LGxPjA6Rd53hcTq(u"ࠬ࠳ࡅ࡮ࡧࡵ࡫ࡪࡴࡣࡺࠩࠤ")
		message += V6VBGEAHRxW39FPisnmJSuYfK7(u"࠭࡜࡯࡞ࡱࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡠࡳࡋ࡭ࡢ࡫࡯ࠤࡘ࡫࡮ࡥࡧࡵ࠾ࠥ࠭ࠥ")+exYFwWvQNdAogC5+ciepk6LTmaxuvSRWtG8D(u"ࠧࠡ࠼ࠪࠦ")+PTcYq9k5WLAxN(u"ࠨ࡞ࡱࠫࠧ")+jaq1LyS2t4(u"ࠩࡄࡨࡩࡵ࡮ࠡࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠫࠨ")+zGFBDdlr2J4bIgSQfmvh0OaWyon+J2FhdIkMi7owqp4(u"ࠪࠤ࠿ࡢ࡮ࠨࠩ")
		data = data.encode(V6VBGEAHRxW39FPisnmJSuYfK7(u"ࠫࡺࡺࡦ࠹ࠩࠪ"))
		XXYWk6E4c1KJMQfyndGpx8m0VHO59 = TvXAsdaGeKM.b64encode(data)
		U1QP3kpzW6iKe = {zzqH2aJ6Co0Vy8OrXxuGsiNBZAQ(u"ࠬࡹࡵࡣ࡬ࡨࡧࡹ࠭ࠫ"):VgvTJqr3pIxykiYPt1eCo0h4l,UpQgk50KIXu(u"࠭࡭ࡦࡵࡶࡥ࡬࡫ࠧࠬ"):message,r0vw6m2FOkRYpWnsSq8ao1(u"ࠧ࡭ࡱࡪࡪ࡮ࡲࡥࠨ࠭"):XXYWk6E4c1KJMQfyndGpx8m0VHO59}
		gmJwGcAp1TnFeK6vQlbOqYiM2U = bjqyL7uod61sghGnFX53WMVaZU0(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡻ࡫ࡲࡤࡧ࡯࠲ࡦࡶࡰ࠰ࡵࡨࡲࡩ࡫࡭ࡢ࡫࡯ࠫ࠮")
		Av7otd9rSb8ek1TwYy = yANfdYokznVgsCUXK24xM0R.request(zzqH2aJ6Co0Vy8OrXxuGsiNBZAQ(u"ࠩࡓࡓࡘ࡚ࠧ࠯"),gmJwGcAp1TnFeK6vQlbOqYiM2U,data=U1QP3kpzW6iKe)
		evOEGw2r4FL0Yb(KuU9eiXySd3BvwmMtlYzIZp15nQsWk(u"ࠪࡷࡹࡵࡰࠨ࠰"))
		if Av7otd9rSb8ek1TwYy.status_code==vfm6ycVojL1gwnlJ(u"࠶࠵࠶ࢌ"): QQLYoJNE2WHlMnUO1Ak6apqDC.Dialog().ok(J2FhdIkMi7owqp4(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ࠱"),RRO10nhebEQiGVp24YH9(u"ࠬา๊ะࠢ࠱࠲ࠥ์ฬฮฬࠣ฽๊๊๊สࠢศีุอไࠡีฯ่ࠥอไฤะฺหฦ࠭࠲"))
		else: QQLYoJNE2WHlMnUO1Ak6apqDC.Dialog().ok(V6VBGEAHRxW39FPisnmJSuYfK7(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ࠳"),R2fi4MGJrzWIVQ(u"ࠧๅๆฦืๆࠦ࠮࠯ࠢไุ้ะฺࠠ็็๎ฮࠦลาีสู่ࠥฬๅࠢส่ศิืศรࠪ࠴"))
	return
def W26WK4fzuIseXOp3nSraVEGLZkJlc():
	v7DtX1oNdg2kj = oslIfbZvR3(EEKbUf7ScjA3vOWhG4(u"ࠨ็็ๅࠥหูะษาหฯࠦวๅสิ๊ฬ๋ฬࠡ์ะฮํ๐ฺࠠๆ์ࠤ๊฿ไ้็สฮࠥะฮึࠢอัิ๐หࠡษ็ฬึ์วๆฮࠣ์ฯ์ุ๋็ࠣ฽๊๊ࠠศๆหี๋อๅอࠢ࠱࠲ࠥ฿ๆะ่ࠢืาࠦ็ัษࠣห้๋ไโࠢึ๎็๎ๅࠡษ็ฬึ์วๆฮࠣฬำ๊โࠡ็็ๅࠥาฯ๋ัࠣๅฬืฺࠡ࠰࠱ࠤ์๊ࠠหำํำࠥอไรุ่้ࠣำࠠๆๆไࠤส฿ฯศัสฮࠥอไษำ้ห๊าࠠภࠣࠪ࠵"))
	if v7DtX1oNdg2kj==bjqyL7uod61sghGnFX53WMVaZU0(u"࠶ࢍ"):
		DD2yvF0xEolaCV1BQuitK6ckbwZjdm = KFAPw7peyTmr3k6V(u"ࡕࡴࡸࡩ࢞")
		io0JLy5e7lPukmv3 = isS3ugcCIPwDV6oZHJ48EYpWf.path.join(brUKNucAd2,UpQgk50KIXu(u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫ࠶"),g3tfivrqOXBRIUCzYh2TD7V(u"ࠪࡥࡩࡪ࡯࡯ࡡࡧࡥࡹࡧࠧ࠷"),zz0RpE3TmyCOjuvX7hLB)
		NAoviVXJYgU = isS3ugcCIPwDV6oZHJ48EYpWf.path.join(io0JLy5e7lPukmv3,dAghyP2kFUYu(u"ࠫࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡸ࡮࡮ࠪ࠸"))
		if isS3ugcCIPwDV6oZHJ48EYpWf.path.exists(NAoviVXJYgU):
			try: isS3ugcCIPwDV6oZHJ48EYpWf.remove(NAoviVXJYgU)
			except Exception as pRoZwr0QJUHIiOmyl4jd: DD2yvF0xEolaCV1BQuitK6ckbwZjdm = PotxGOldnLMh(u"ࡈࡤࡰࡸ࡫࢟")
		if DD2yvF0xEolaCV1BQuitK6ckbwZjdm: QQLYoJNE2WHlMnUO1Ak6apqDC.Dialog().ok(ciepk6LTmaxuvSRWtG8D(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ࠹"),SzO6leLmiIsf24EBPNqtJGu0(u"࠭ฬ๋ัࠣ࠲࠳ࠦๆอฯอࠤ฾๋ไ๋หุ้ࠣำࠠศๆ่่ๆ࠭࠺"))
		else: QQLYoJNE2WHlMnUO1Ak6apqDC.Dialog().ok(YHWjykwBox74Qhsp(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ࠻"),Bca1Te4WjF2pQk(u"ࠨๆ็วุ็ࠠ࠯࠰ࠣๅู๊สࠡ฻่่๏ฯࠠๆีะࠤฬ๊ๅๅใࠪ࠼"))
	return
def ksvAB4KpSQOV1Y():
	v7DtX1oNdg2kj = oslIfbZvR3(R2fi4MGJrzWIVQ(u"่ࠩะ้ีࠠไษืࠤฬ๊ศา่ส้ั๊ࠦฮฬ๋๎ࠥ฿ไ๊่่ࠢๆอสࠡฬัูࠥะๆู์่ࠤ฾๋ไࠡษ็ฬึ์วๆฮ้ࠣะ๊ࠠๆๆไหฯࠦวๅ็ไฺ้ฯ้ࠠ็็ๅฬะࠠࡊࡒࡗ࡚ࠥ๎ࠠࡎ࠵ࡘࠤํ฻่าࠢส่็๎วว็ࠣ࠲࠳ูࠦ็ัุ้ࠣำ่ࠠาสࠤฬ๊ๅอๆาࠤุ๐โ้็ࠣห้ฮั็ษ่ะࠥฮฮๅไ้ࠣั๊ฯࠡฮา๎ิࠦแศำ฽ࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡษ็ฦ๋ࠦๅิฯ้ࠣั๊ฯࠡๅสุࠥอไษำ้ห๊าࠠภࠣࠪ࠽"))
	if v7DtX1oNdg2kj==WhEBLNgqblsZ7IyQakUK4HduJA3(u"࠷ࢎ"):
		if bIwNRi8AGuoCgekJlDZa2dH9E: HmWrowB3NjXkavbcsASfg = kTBsDOUNF21J.translatePath(PotxGOldnLMh(u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡴࡦ࡯ࡳࠫ࠾"))
		else: HmWrowB3NjXkavbcsASfg = Q8DmKY2rtPRxh0LdEkXO7.translatePath(vfm6ycVojL1gwnlJ(u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯ࡵࡧࡰࡴࠬ࠿"))
		aaSTMc9NdFtJgU3Dp0b = isS3ugcCIPwDV6oZHJ48EYpWf.path.join(HmWrowB3NjXkavbcsASfg,zz0RpE3TmyCOjuvX7hLB)
		DD2yvF0xEolaCV1BQuitK6ckbwZjdm = i4Lq2pMEB6xnJuAQfkst(u"ࡗࡶࡺ࡫ࢠ")
		if isS3ugcCIPwDV6oZHJ48EYpWf.path.exists(aaSTMc9NdFtJgU3Dp0b):
			for eexJyCmKlTs3XiRguakGpP,LktJW4yqcH8buKV1SU0os2FQarxG,HBjuipvgtTQ3UsRDdSzZV0OhIwMJ in isS3ugcCIPwDV6oZHJ48EYpWf.walk(aaSTMc9NdFtJgU3Dp0b,topdown=bbn2AgoaGfmT6cXDRdY(u"ࡊࡦࡲࡳࡦࢡ")):
				for bloycH5vE6pV23qjLFNtBQPn in HBjuipvgtTQ3UsRDdSzZV0OhIwMJ:
					JKMd1DZXn4QeBAjI8fRgk2hUTixW9P = isS3ugcCIPwDV6oZHJ48EYpWf.path.join(eexJyCmKlTs3XiRguakGpP,bloycH5vE6pV23qjLFNtBQPn)
					try: isS3ugcCIPwDV6oZHJ48EYpWf.remove(JKMd1DZXn4QeBAjI8fRgk2hUTixW9P)
					except Exception as pRoZwr0QJUHIiOmyl4jd: DD2yvF0xEolaCV1BQuitK6ckbwZjdm = R2fi4MGJrzWIVQ(u"ࡋࡧ࡬ࡴࡧࢢ")
				for hOW6yGJkIdCgiZ7B8z4qpxem in LktJW4yqcH8buKV1SU0os2FQarxG:
					ZtPidwVDUXqus0m4 = isS3ugcCIPwDV6oZHJ48EYpWf.path.join(eexJyCmKlTs3XiRguakGpP,hOW6yGJkIdCgiZ7B8z4qpxem)
					try: isS3ugcCIPwDV6oZHJ48EYpWf.rmdir(ZtPidwVDUXqus0m4)
					except: pass
			try: isS3ugcCIPwDV6oZHJ48EYpWf.rmdir(eexJyCmKlTs3XiRguakGpP)
			except: pass
		if DD2yvF0xEolaCV1BQuitK6ckbwZjdm: QQLYoJNE2WHlMnUO1Ak6apqDC.Dialog().ok(YHWjykwBox74Qhsp(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨࡀ"),Bca1Te4WjF2pQk(u"࠭ฬ๋ัࠣ࠲࠳ࠦๆอฯอࠤ฾๋ไ๋หุ้ࠣำࠠๆฮ็ำ้ࠥวีࠢส่อืๆศ็ฯࠫࡁ"))
		else: QQLYoJNE2WHlMnUO1Ak6apqDC.Dialog().ok(ooY0IDFmUz2E(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪࡂ"),V6VBGEAHRxW39FPisnmJSuYfK7(u"ࠨๆ็วุ็ࠠ࠯࠰ࠣๅู๊สࠡ฻่่๏ฯࠠๆีะࠤ๊าไะࠢๆหูࠦวๅสิ๊ฬ๋ฬࠨࡃ"))
	return
def N2FoYLMc6dsQBt():
	gmJwGcAp1TnFeK6vQlbOqYiM2U = KFAPw7peyTmr3k6V(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡹࡵࡳࡩࡨ࠲ࡸ࡮࠯࡬ࡱࡧ࡭࠴࡫࡭ࡢࡦࡢࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴ࠱ࡲࡰࡩ࠵ࡩ࡯ࡦࡨࡼ࠳࡮ࡴ࡮࡮ࠪࡄ")
	Av7otd9rSb8ek1TwYy = yANfdYokznVgsCUXK24xM0R.request(LGxPjA6Rd53hcTq(u"ࠪࡋࡊ࡚ࠧࡅ"),gmJwGcAp1TnFeK6vQlbOqYiM2U)
	ddSRue3GLt6hENo = Av7otd9rSb8ek1TwYy.content
	ddSRue3GLt6hENo = ddSRue3GLt6hENo.decode(PTcYq9k5WLAxN(u"ࠫࡺࡺࡦ࠹ࠩࡆ"))
	HBjuipvgtTQ3UsRDdSzZV0OhIwMJ = ZgOyK1lM3xE0CpIGVP5thr.findall(PTcYq9k5WLAxN(u"ࠬ࡮ࡲࡦࡨࡀࠦࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࠬ࠳࠰࠿ࠪ࠰ࡽ࡭ࡵࠨࠧࡇ"),ddSRue3GLt6hENo,ZgOyK1lM3xE0CpIGVP5thr.DOTALL)
	HBjuipvgtTQ3UsRDdSzZV0OhIwMJ = sorted(HBjuipvgtTQ3UsRDdSzZV0OhIwMJ,reverse=EEKbUf7ScjA3vOWhG4(u"࡚ࡲࡶࡧࢣ"))
	Ae7EGZFnu2JH6dYxskLfmq8o50 = QQLYoJNE2WHlMnUO1Ak6apqDC.Dialog().select(jaq1LyS2t4(u"࠭วฯฬิࠤฬ๊ลึัสีࠥอไั์ࠣฮึ๐ฯࠡฬฮฬ๏ะ็ࠨࡈ"),HBjuipvgtTQ3UsRDdSzZV0OhIwMJ)
	if Ae7EGZFnu2JH6dYxskLfmq8o50==-zzqH2aJ6Co0Vy8OrXxuGsiNBZAQ(u"࠱࢏"): return
	filename = HBjuipvgtTQ3UsRDdSzZV0OhIwMJ[Ae7EGZFnu2JH6dYxskLfmq8o50]
	if fUHdliX5FgJR9cr8QxLZpTsKo6n3w: filename = filename.encode(LGxPjA6Rd53hcTq(u"ࠧࡶࡶࡩ࠼ࠬࡉ"))
	zSuDMGEBFyn = gmJwGcAp1TnFeK6vQlbOqYiM2U.rsplit(bbn2AgoaGfmT6cXDRdY(u"ࠨ࠱ࠪࡊ"),jaq1LyS2t4(u"࠲࢐"))[EEKbUf7ScjA3vOWhG4(u"࠲࢑")]+i4Lq2pMEB6xnJuAQfkst(u"ࠩ࠲ࠫࡋ")+LGxPjA6Rd53hcTq(u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࠪࡌ")+filename+NEIcsFOGD1lax4HuywQX27S0(u"ࠫ࠳ࢀࡩࡱࠩࡍ")
	DD2yvF0xEolaCV1BQuitK6ckbwZjdm = V6VBGEAHRxW39FPisnmJSuYfK7(u"ࡆࡢ࡮ࡶࡩࢤ")
	Av7otd9rSb8ek1TwYy = yANfdYokznVgsCUXK24xM0R.request(MpIKBxVyswh9Q2zRv6fWUGPbcrl(u"ࠬࡍࡅࡕࠩࡎ"),zSuDMGEBFyn)
	if Av7otd9rSb8ek1TwYy.status_code==YHWjykwBox74Qhsp(u"࠵࠴࠵࢒"):
		oecPzOi83Gxyv4MpW9gVKX0Q = Av7otd9rSb8ek1TwYy.content
		import zipfile as GKhnAoIOZirP7M,io as YHBQ6sXUhGvqm9O13Vp5W2KjdDPiet
		J9emb1lcTxtySXrhazLM = YHBQ6sXUhGvqm9O13Vp5W2KjdDPiet.BytesIO(oecPzOi83Gxyv4MpW9gVKX0Q)
		ffw6COqnXU3AmioIa0dGsRpuJbH = isS3ugcCIPwDV6oZHJ48EYpWf.path.join(brUKNucAd2,KFAPw7peyTmr3k6V(u"࠭ࡡࡥࡦࡲࡲࡸ࠭ࡏ"))
		ltDQv5hmgXzokTyV = GKhnAoIOZirP7M.ZipFile(J9emb1lcTxtySXrhazLM)
		ltDQv5hmgXzokTyV.extractall(ffw6COqnXU3AmioIa0dGsRpuJbH)
		wyglQ3Tx10f2H9bLYqVZmJG8C.sleep(V6VBGEAHRxW39FPisnmJSuYfK7(u"࠵࢓"))
		Q8DmKY2rtPRxh0LdEkXO7.executebuiltin(bjqyL7uod61sghGnFX53WMVaZU0(u"ࠧࡖࡲࡧࡥࡹ࡫ࡌࡰࡥࡤࡰࡆࡪࡤࡰࡰࡶࠫࡐ"))
		wyglQ3Tx10f2H9bLYqVZmJG8C.sleep(YHWjykwBox74Qhsp(u"࠶࢔"))
		qpQ0ORVY8cHZxM2KeX = Q8DmKY2rtPRxh0LdEkXO7.executeJSONRPC(YHWjykwBox74Qhsp(u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡂࡦࡧࡳࡳࡹ࠮ࡔࡧࡷࡅࡩࡪ࡯࡯ࡇࡱࡥࡧࡲࡥࡥࠤ࠯ࠦ࡮ࡪࠢ࠻࠳࠯ࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡢࡦࡧࡳࡳ࡯ࡤࠣ࠼ࠥࠫࡑ")+zz0RpE3TmyCOjuvX7hLB+bbn2AgoaGfmT6cXDRdY(u"ࠩࠥ࠰ࠧ࡫࡮ࡢࡤ࡯ࡩࡩࠨ࠺ࡵࡴࡸࡩࢂࢃࠧࡒ"))
		if Bca1Te4WjF2pQk(u"ࠪࡓࡐ࠭ࡓ") in qpQ0ORVY8cHZxM2KeX: DD2yvF0xEolaCV1BQuitK6ckbwZjdm = SDTHloJMxZPmfLI7OhbNtcdsAXi(u"ࡕࡴࡸࡩࢥ")
	if DD2yvF0xEolaCV1BQuitK6ckbwZjdm: QQLYoJNE2WHlMnUO1Ak6apqDC.Dialog().ok(jaq1LyS2t4(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧࡔ"),KuU9eiXySd3BvwmMtlYzIZp15nQsWk(u"ࠬา๊ะࠢ࠱࠲ࠥ์ฬฮฬࠣ฽๊๊๊สࠢอฯอ๐สࠡษ็ษฺีวาࠢส่็ี๊ๆࠢ࡟ࡲࡡࡴࠠࠨࡕ")+filename)
	else: QQLYoJNE2WHlMnUO1Ak6apqDC.Dialog().ok(R2fi4MGJrzWIVQ(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩࡖ"),g3tfivrqOXBRIUCzYh2TD7V(u"ࠧๅๆฦืๆࠦ࠮࠯ࠢไุ้ะฺࠠ็็๎ฮࠦสฬสํฮࠥอไฦืาหึࠦวๅไา๎๊ࠦ࡜࡯࡞ࡱࠤࠬࡗ")+filename)
	i3IWqbQMjFcTA()
	return
def i3IWqbQMjFcTA(J24Z9gEwQKX=None):
	if J24Z9gEwQKX==None:
		v7DtX1oNdg2kj = oslIfbZvR3(N39vI0G5wRdPHobA4tJWCgKFpiXluh(u"ࠨฯอํࠥ๐ศใ๋ࠣห้หีะษิࠤฬ๊โะ์่ࠤๆ๐ࠠอ้สึ่่ࠦๅษࠣ๎ฯ๋ࠠหฯา๎ะํࠠฤ๊อ์๊อส๋ๅํหࠥ࠴࠮ࠡ์ฯฬࠥษๆࠡฬๅ์๊ࠦศฦ์ๅหๆࠦวๅฬะำ๏ัࠠศๆฦ์ฯ๎ๅศฬํ็๏ࠦ࠮࠯๊่ࠢࠥะั๋ัࠣษ๏่วโࠢส่ฯำฯ๋อࠣห้ษ่ห๊่หฯ๐ใ๋ࠢ็่อืๆศ็ฯࠤฤࠧࠧࡘ"))
		if v7DtX1oNdg2kj in [-dAghyP2kFUYu(u"࠷࢕"),N39vI0G5wRdPHobA4tJWCgKFpiXluh(u"࠰࢖")]: return
		J24Z9gEwQKX = ciepk6LTmaxuvSRWtG8D(u"ࡗࡶࡺ࡫ࢧ") if v7DtX1oNdg2kj==PotxGOldnLMh(u"࠲ࢗ") else PotxGOldnLMh(u"ࡈࡤࡰࡸ࡫ࢦ")
	if bIwNRi8AGuoCgekJlDZa2dH9E: btguDwosMQ9xcy = isS3ugcCIPwDV6oZHJ48EYpWf.path.join(brUKNucAd2,i4Lq2pMEB6xnJuAQfkst(u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤ࡙ࠫ"),N39vI0G5wRdPHobA4tJWCgKFpiXluh(u"ࠪࡈࡦࡺࡡࡣࡣࡶࡩ࡚ࠬ"),MWckCAmjTs1u(u"ࠫࡆࡪࡤࡰࡰࡶ࠷࠸࠴ࡤࡣ࡛ࠩ"))
	else: btguDwosMQ9xcy = isS3ugcCIPwDV6oZHJ48EYpWf.path.join(brUKNucAd2,dAghyP2kFUYu(u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧ࡜"),dAghyP2kFUYu(u"࠭ࡄࡢࡶࡤࡦࡦࡹࡥࠨ࡝"),vfm6ycVojL1gwnlJ(u"ࠧࡂࡦࡧࡳࡳࡹ࠲࠸࠰ࡧࡦࠬ࡞"))
	import sqlite3 as m8Pz51UQbJfAk9D
	DD2yvF0xEolaCV1BQuitK6ckbwZjdm = LGxPjA6Rd53hcTq(u"ࡊࡦࡲࡳࡦࢨ")
	m0bBLAMvuyhSKO = CFonwOKY107qrB9axPdvUQ(u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦࠪ࡟")
	kBJ7sv1P6DoVN = g3tfivrqOXBRIUCzYh2TD7V(u"ࠩࡥࡰࡦࡩ࡫࡭࡫ࡶࡸࠬࡠ") if fUHdliX5FgJR9cr8QxLZpTsKo6n3w else NEIcsFOGD1lax4HuywQX27S0(u"ࠪࡹࡵࡪࡡࡵࡧࡢࡶࡺࡲࡥࡴࠩࡡ")
	try:
		qWg2BAt7CL30vem = m8Pz51UQbJfAk9D.connect(btguDwosMQ9xcy)
		qWg2BAt7CL30vem.text_factory = str
		SpVeCLlJmRwc18vkT = qWg2BAt7CL30vem.cursor()
		SpVeCLlJmRwc18vkT.execute(PotxGOldnLMh(u"ࠫࡘࡋࡌࡆࡅࡗࠤࡴࡸࡩࡨ࡫ࡱࠤࡋࡘࡏࡎࠢ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨࠥ࡝ࡈࡆࡔࡈࠤࡦࡪࡤࡰࡰࡌࡈࠥࡃࠠࠣࠩࡢ")+zz0RpE3TmyCOjuvX7hLB+RRO10nhebEQiGVp24YH9(u"ࠬࠨࠠ࠼ࠩࡣ"))
		qBp9uhaGxi3s1 = SpVeCLlJmRwc18vkT.fetchall()
		if qBp9uhaGxi3s1 and m0bBLAMvuyhSKO not in str(qBp9uhaGxi3s1): SpVeCLlJmRwc18vkT.execute(PotxGOldnLMh(u"࠭ࡕࡑࡆࡄࡘࡊࠦࡩ࡯ࡵࡷࡥࡱࡲࡥࡥࠢࡖࡉ࡙ࠦ࡯ࡳ࡫ࡪ࡭ࡳࠦ࠽ࠡࠤࠪࡤ")+m0bBLAMvuyhSKO+SDTHloJMxZPmfLI7OhbNtcdsAXi(u"࡚ࠧࠣࠢࡌࡊࡘࡅࠡࡣࡧࡨࡴࡴࡉࡅࠢࡀࠤࠧ࠭ࡥ")+zz0RpE3TmyCOjuvX7hLB+KFAPw7peyTmr3k6V(u"ࠨࠤࠣ࠿ࠬࡦ"))
		SpVeCLlJmRwc18vkT.execute(dAghyP2kFUYu(u"ࠩࡖࡉࡑࡋࡃࡕࠢ࠭ࠤࡋࡘࡏࡎࠢࠪࡧ")+kBJ7sv1P6DoVN+J2FhdIkMi7owqp4(u"ࠪࠤ࡜ࡎࡅࡓࡇࠣࡥࡩࡪ࡯࡯ࡋࡇࠤࡂࠦࠢࠨࡨ")+zz0RpE3TmyCOjuvX7hLB+zzqH2aJ6Co0Vy8OrXxuGsiNBZAQ(u"ࠫࠧࠦ࠻ࠨࡩ"))
		qBp9uhaGxi3s1 = SpVeCLlJmRwc18vkT.fetchall()
		DOpldHsQtNXr3Gy67Px8IToZ4 = g3tfivrqOXBRIUCzYh2TD7V(u"ࡌࡡ࡭ࡵࡨࢪ") if qBp9uhaGxi3s1 else N39vI0G5wRdPHobA4tJWCgKFpiXluh(u"࡙ࡸࡵࡦࢩ")
		if not DOpldHsQtNXr3Gy67Px8IToZ4 and not J24Z9gEwQKX: SpVeCLlJmRwc18vkT.execute(g3tfivrqOXBRIUCzYh2TD7V(u"ࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࠫࡪ")+kBJ7sv1P6DoVN+PTcYq9k5WLAxN(u"࠭ࠠࡘࡊࡈࡖࡊࠦࡡࡥࡦࡲࡲࡎࡊࠠ࠾ࠢࠥࠫ࡫")+zz0RpE3TmyCOjuvX7hLB+RRO10nhebEQiGVp24YH9(u"ࠧࠣࠢ࠾ࠫ࡬"))
		elif DOpldHsQtNXr3Gy67Px8IToZ4 and J24Z9gEwQKX:
			if fUHdliX5FgJR9cr8QxLZpTsKo6n3w: SpVeCLlJmRwc18vkT.execute(V6VBGEAHRxW39FPisnmJSuYfK7(u"ࠨࡋࡑࡗࡊࡘࡔࠡࡋࡑࡘࡔࠦࠧ࡭")+kBJ7sv1P6DoVN+UpQgk50KIXu(u"ࠩࠣࠬࡦࡪࡤࡰࡰࡌࡈ࠮ࠦࡖࡂࡎࡘࡉࡘࠦࠨࠣࠩ࡮")+zz0RpE3TmyCOjuvX7hLB+vfm6ycVojL1gwnlJ(u"ࠪࠦ࠮ࠦ࠻ࠨ࡯"))
			else: SpVeCLlJmRwc18vkT.execute(ooY0IDFmUz2E(u"ࠫࡎࡔࡓࡆࡔࡗࠤࡎࡔࡔࡐࠢࠪࡰ")+kBJ7sv1P6DoVN+vfm6ycVojL1gwnlJ(u"ࠬࠦࠨࡢࡦࡧࡳࡳࡏࡄ࠭ࡷࡳࡨࡦࡺࡥࡓࡷ࡯ࡩ࠮ࠦࡖࡂࡎࡘࡉࡘࠦࠨࠣࠩࡱ")+zz0RpE3TmyCOjuvX7hLB+MpIKBxVyswh9Q2zRv6fWUGPbcrl(u"࠭ࠢ࠭࠳ࠬࠤࡀ࠭ࡲ"))
		qWg2BAt7CL30vem.commit()
		qWg2BAt7CL30vem.close()
		DD2yvF0xEolaCV1BQuitK6ckbwZjdm = UpQgk50KIXu(u"ࡔࡳࡷࡨࢫ")
	except: pass
	if DD2yvF0xEolaCV1BQuitK6ckbwZjdm:
		wyglQ3Tx10f2H9bLYqVZmJG8C.sleep(KuU9eiXySd3BvwmMtlYzIZp15nQsWk(u"࠳࢘"))
		Q8DmKY2rtPRxh0LdEkXO7.executebuiltin(bjqyL7uod61sghGnFX53WMVaZU0(u"ࠧࡖࡲࡧࡥࡹ࡫ࡌࡰࡥࡤࡰࡆࡪࡤࡰࡰࡶࠫࡳ"))
		wyglQ3Tx10f2H9bLYqVZmJG8C.sleep(i4Lq2pMEB6xnJuAQfkst(u"࠴࢙"))
		QQLYoJNE2WHlMnUO1Ak6apqDC.Dialog().ok(MVLWDmZrYcvK9Pyg2(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫࡴ"),SzO6leLmiIsf24EBPNqtJGu0(u"ࠩฯ๎ิࠦ࠮࠯้ࠢะาะࠠศๆ฼้้๐ษࠨࡵ"))
	else: QQLYoJNE2WHlMnUO1Ak6apqDC.Dialog().ok(V6VBGEAHRxW39FPisnmJSuYfK7(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ࡶ"),RRO10nhebEQiGVp24YH9(u"้๊ࠫริใࠣ࠲࠳ࠦแีๆอࠤฬู๊ๆๆํอࠬࡷ"))
	return
bHQ5r1mF8AuD7GPeZYWUl09nTM = oNvHiYIdn2346z8QG.argv[MVLWDmZrYcvK9Pyg2(u"࠵࢚")]
zz0RpE3TmyCOjuvX7hLB = ciepk6LTmaxuvSRWtG8D(u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪࡸ")
np7VA3y5lIPTWwSsue86zb9Cj = Q8DmKY2rtPRxh0LdEkXO7.getInfoLabel(LGxPjA6Rd53hcTq(u"ࠨࡓࡺࡵࡷࡩࡲ࠴ࡂࡶ࡫࡯ࡨ࡛࡫ࡲࡴ࡫ࡲࡲࠧࡹ"))
WFKRUp1ryeG0wHV = ZgOyK1lM3xE0CpIGVP5thr.findall(bbn2AgoaGfmT6cXDRdY(u"ࠧࠩ࡞ࡧࡠࡩࡢ࠮࡝ࡦࠬࠫࡺ"),np7VA3y5lIPTWwSsue86zb9Cj,ZgOyK1lM3xE0CpIGVP5thr.DOTALL)
WFKRUp1ryeG0wHV = float(WFKRUp1ryeG0wHV[NEIcsFOGD1lax4HuywQX27S0(u"࠵࢛")])
fUHdliX5FgJR9cr8QxLZpTsKo6n3w = WFKRUp1ryeG0wHV<MpIKBxVyswh9Q2zRv6fWUGPbcrl(u"࠷࠹࢜")
bIwNRi8AGuoCgekJlDZa2dH9E = WFKRUp1ryeG0wHV>i4Lq2pMEB6xnJuAQfkst(u"࠱࠹࠰࠼࠽࢝")
if bIwNRi8AGuoCgekJlDZa2dH9E:
	YJKy8FZwHlIb95EGfjCkQnTR = kTBsDOUNF21J.translatePath(CFonwOKY107qrB9axPdvUQ(u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳ࡱࡵࡧࡱࡣࡷ࡬ࠬࡻ"))
	brUKNucAd2 = kTBsDOUNF21J.translatePath(MpIKBxVyswh9Q2zRv6fWUGPbcrl(u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴࡮࡯࡮ࡧࠪࡼ"))
else:
	YJKy8FZwHlIb95EGfjCkQnTR = Q8DmKY2rtPRxh0LdEkXO7.translatePath(bbn2AgoaGfmT6cXDRdY(u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵࡬ࡰࡩࡳࡥࡹ࡮ࠧࡽ"))
	brUKNucAd2 = Q8DmKY2rtPRxh0LdEkXO7.translatePath(N39vI0G5wRdPHobA4tJWCgKFpiXluh(u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯ࡩࡱࡰࡩࠬࡾ"))
ppCBtV98uiDQlo = isS3ugcCIPwDV6oZHJ48EYpWf.path.join(YJKy8FZwHlIb95EGfjCkQnTR,bjqyL7uod61sghGnFX53WMVaZU0(u"ࠬࡱ࡯ࡥ࡫࠱ࡰࡴ࡭ࠧࡿ"))
rNmPKWS8MyGEsVHzo5t = isS3ugcCIPwDV6oZHJ48EYpWf.path.join(YJKy8FZwHlIb95EGfjCkQnTR,WhEBLNgqblsZ7IyQakUK4HduJA3(u"࠭࡫ࡰࡦ࡬࠲ࡴࡲࡤ࠯࡮ࡲ࡫ࠬࢀ"))
if   bHQ5r1mF8AuD7GPeZYWUl09nTM==zzqH2aJ6Co0Vy8OrXxuGsiNBZAQ(u"ࠧࡴࡧࡱࡨࡤࡲ࡯ࡨࡨ࡬ࡰࡪ࠭ࢁ")		: crfdRND8sLkzQ9wlU(ppCBtV98uiDQlo)
elif bHQ5r1mF8AuD7GPeZYWUl09nTM==MpIKBxVyswh9Q2zRv6fWUGPbcrl(u"ࠨࡵࡨࡲࡩࡥ࡯࡭ࡦࡢࡰࡴ࡭ࡦࡪ࡮ࡨࠫࢂ")	: crfdRND8sLkzQ9wlU(rNmPKWS8MyGEsVHzo5t)
elif bHQ5r1mF8AuD7GPeZYWUl09nTM==J2FhdIkMi7owqp4(u"ࠩࡧࡩࡱ࡫ࡴࡦࡡࡶࡩࡹࡺࡩ࡯ࡩࡶࠫࢃ")		: W26WK4fzuIseXOp3nSraVEGLZkJlc()
elif bHQ5r1mF8AuD7GPeZYWUl09nTM==KFAPw7peyTmr3k6V(u"ࠪࡨࡪࡲࡥࡵࡧࡢࡧࡦࡩࡨࡦࠩࢄ")		: ksvAB4KpSQOV1Y()
elif bHQ5r1mF8AuD7GPeZYWUl09nTM==KuU9eiXySd3BvwmMtlYzIZp15nQsWk(u"ࠫ࡮ࡴࡳࡵࡣ࡯ࡰࡤࡵ࡬ࡥࡡࡹࡩࡷࡹࡩࡰࡰࠪࢅ")	: N2FoYLMc6dsQBt()
elif bHQ5r1mF8AuD7GPeZYWUl09nTM==KuU9eiXySd3BvwmMtlYzIZp15nQsWk(u"ࠬࡳ࡯ࡥ࡫ࡩࡽࡤࡧࡵࡵࡱࡸࡴࡩࡧࡴࡦࠩࢆ")	: i3IWqbQMjFcTA()
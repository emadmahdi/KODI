# -*- coding: utf-8 -*-
from hIVCFnfxSO import *
QQ8pvXNcBfVkP5rRJ7o = 'FASELHD1'
headers = {'User-Agent':b8Qe150xVaJsnDSv}
WbzmKSZiuOYrBN7oysJ2dUv = '_FH1_'
wQjs1XZ3AO24g8y9bEeoKMiGIu7 = nTHXJIiah2qK[QQ8pvXNcBfVkP5rRJ7o][0]
v1vJEhoNQBVPkjG = ['جوائز الأوسكار','المراجعات','wwe']
def x8IFqMZeJj7suCR4AaGoNXfEHm(mode,url,text):
	if   mode==570: XXxlOLJ9KRjPH382WVCvr6n71 = Y72YmLgw4vqlHxTCkbeKSicasD()
	elif mode==571: XXxlOLJ9KRjPH382WVCvr6n71 = Je4TwC30iOG5DLKWAtbYvhs(url,text)
	elif mode==572: XXxlOLJ9KRjPH382WVCvr6n71 = Hkij627uCDJKyIM(url)
	elif mode==573: XXxlOLJ9KRjPH382WVCvr6n71 = N8NlUOucBtJkbvdKmL1n7I2sa0x(url,text)
	elif mode==576: XXxlOLJ9KRjPH382WVCvr6n71 = bn9ZvjB1acOpSFf()
	elif mode==579: XXxlOLJ9KRjPH382WVCvr6n71 = kstJfK6jHQWrXDSMRIGB7(text)
	else: XXxlOLJ9KRjPH382WVCvr6n71 = False
	return XXxlOLJ9KRjPH382WVCvr6n71
def Y72YmLgw4vqlHxTCkbeKSicasD():
	MQtuaShrKTbdZFJ5nsR7D('link',WbzmKSZiuOYrBN7oysJ2dUv+'لماذا الموقع بطيء',b8Qe150xVaJsnDSv,576)
	OZSA7QNfeE,url = wQjs1XZ3AO24g8y9bEeoKMiGIu7,wQjs1XZ3AO24g8y9bEeoKMiGIu7
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'FASELHD1-MENU-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'بحث في الموقع',OZSA7QNfeE,579,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'_REMEMBERRESULTS_')
	MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+' ===== ===== ===== '+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999)
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'المميزة',OZSA7QNfeE,571,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'featured1')
	items = YYBlm36zd0Jst18LXwo4.findall('class="h3">(.*?)<.*?href="(.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	for title,pcA1dzy7LXwGfMPg9mTkuh5tine3 in items:
		MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,571,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'details1')
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('"menu-primary"(.*?)</ul>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		aLh6cZoTErd = YYBlm36zd0Jst18LXwo4.findall('<li (.*?)</li>',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		UCYKgOE8uiFTBHGP52xQ7 = [b8Qe150xVaJsnDSv,'أفلام: ','مسلسلات: ','برامج: ','آسيوي: ','أنمي: ']
		s9s45taoNBh60XL1zykOmTK3jJCrE = 0
		for XsMYjhI4QHz0yJ3OBqvW in aLh6cZoTErd:
			if s9s45taoNBh60XL1zykOmTK3jJCrE>0: MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+' ===== ===== ===== '+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999)
			items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)".*?>(.*?)<',XsMYjhI4QHz0yJ3OBqvW,YYBlm36zd0Jst18LXwo4.DOTALL)
			for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
				if pcA1dzy7LXwGfMPg9mTkuh5tine3=='#': continue
				if 'http' not in pcA1dzy7LXwGfMPg9mTkuh5tine3: pcA1dzy7LXwGfMPg9mTkuh5tine3 = OZSA7QNfeE+pcA1dzy7LXwGfMPg9mTkuh5tine3
				if title==b8Qe150xVaJsnDSv: continue
				if any(Y8aiFZsLKw in title.lower() for Y8aiFZsLKw in v1vJEhoNQBVPkjG): continue
				title = UCYKgOE8uiFTBHGP52xQ7[s9s45taoNBh60XL1zykOmTK3jJCrE]+title
				MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,571,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'details2')
			s9s45taoNBh60XL1zykOmTK3jJCrE += 1
	return
def bn9ZvjB1acOpSFf():
	tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'رسالة من المبرمج','موقع فاصل الأول بطيء من المصدر .. بسبب قيام أصحاب الموقع بإضافة فحص وتحقق أمني ضد هجوم البرامج وهجوم القراصنة على صفحات الموقع .. والوقت الضائع يذهب في محاولة تجاوز هذا الفحص واثبات أن هذا البرنامج هو مجرد متصفح للمواقع ولا يقوم بالهجوم على المواقع')
	return
def Je4TwC30iOG5DLKWAtbYvhs(url,type=b8Qe150xVaJsnDSv):
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'FASELHD1-TITLES-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	U8UnzJgXuMIE5GV = YYBlm36zd0Jst18LXwo4.findall('class="h4">(.*?)</div>(.*?)"container"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if not U8UnzJgXuMIE5GV: return
	if type=='filters':
		ZV5rRvabhxJ = [jLtdbeYiQHnf4SpU2MTly.replace('\\/','/').replace('\\"','"')]
	elif type=='featured1':
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('"homeSlide"(.*?)"container"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		items = YYBlm36zd0Jst18LXwo4.findall(' src="(.*?)".*? href="(.*?)">(.*?)</a>',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		a4BNgd5ov1,tzdvaEpMHOCZLXDYg08T,YRtyADTLUrGc = zip(*items)
		items = zip(tzdvaEpMHOCZLXDYg08T,a4BNgd5ov1,YRtyADTLUrGc)
	elif type=='featured2':
		title,OTKx7aVb2hdS16Wrweky4FXfIN0g9 = U8UnzJgXuMIE5GV[0]
		items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)".*? data-src="(.*?)".*? alt="(.*?)"',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	elif type=='details2' and len(U8UnzJgXuMIE5GV)>1:
		title = U8UnzJgXuMIE5GV[0][0]
		MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,url,571,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'featured2')
		title = U8UnzJgXuMIE5GV[1][0]
		MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,url,571,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'details3')
		return
	else:
		title,OTKx7aVb2hdS16Wrweky4FXfIN0g9 = U8UnzJgXuMIE5GV[-1]
		items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)".*? data-src="(.*?)".*?"h1">(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	d3VSIefbHnvqiut = []
	for pcA1dzy7LXwGfMPg9mTkuh5tine3,lvtGpMZHb9,title in items:
		if any(Y8aiFZsLKw in title.lower() for Y8aiFZsLKw in v1vJEhoNQBVPkjG): continue
		lvtGpMZHb9 = ggtn0PzV7aMe(lvtGpMZHb9)
		lvtGpMZHb9 = lvtGpMZHb9.split('?resize=')[0]
		title = pTP49ckGDYrofa2KxenumbH0(title)
		HHr42WSgBjAeU7TkQcVaL6yEJz8PF = YYBlm36zd0Jst18LXwo4.findall('(.*?) (الحلقة|حلقة).\d+',title,YYBlm36zd0Jst18LXwo4.DOTALL)
		if '/collections/' in pcA1dzy7LXwGfMPg9mTkuh5tine3:
			MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,571,lvtGpMZHb9)
		elif HHr42WSgBjAeU7TkQcVaL6yEJz8PF and type==b8Qe150xVaJsnDSv:
			title = '_MOD_'+HHr42WSgBjAeU7TkQcVaL6yEJz8PF[0][0]
			title = title.strip(' –')
			if title not in d3VSIefbHnvqiut:
				MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,573,lvtGpMZHb9)
				d3VSIefbHnvqiut.append(title)
		elif 'episodes/' in pcA1dzy7LXwGfMPg9mTkuh5tine3 or 'movies/' in pcA1dzy7LXwGfMPg9mTkuh5tine3 or 'hindi/' in pcA1dzy7LXwGfMPg9mTkuh5tine3:
			MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,572,lvtGpMZHb9)
		else: MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,573,lvtGpMZHb9)
	if type=='filters':
		yzv5xbQhcgpOt4dajB = YYBlm36zd0Jst18LXwo4.findall('"more_button_page":(.*?),',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		if yzv5xbQhcgpOt4dajB:
			count = yzv5xbQhcgpOt4dajB[0]
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = url+'/offset/'+count
			MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'صفحة أخرى',pcA1dzy7LXwGfMPg9mTkuh5tine3,571,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'filters')
	elif 'details' in type:
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall("class='pagination(.*?)</div>",jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if ZV5rRvabhxJ:
			OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
			items = YYBlm36zd0Jst18LXwo4.findall("href='(.*?)'.*?>(.*?)<",OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
			for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
				title = 'صفحة '+pTP49ckGDYrofa2KxenumbH0(title)
				MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,571,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'details4')
	return
def N8NlUOucBtJkbvdKmL1n7I2sa0x(url,type=b8Qe150xVaJsnDSv):
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'FASELHD1-SEASONS_EPISODES-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	FYIl2eqyG1afdLbuOA6s = False
	if not type:
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('"seasonList"(.*?)"container"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if ZV5rRvabhxJ:
			OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
			items = YYBlm36zd0Jst18LXwo4.findall('href = \'(.*?)\'.*? data-src="(.*?)".*?alt="(.*?)".*?"title">(.*?)</div>',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
			if len(items)>1:
				OZSA7QNfeE = Wl2eu1PavfQ(url,'url')
				FYIl2eqyG1afdLbuOA6s = True
				for pcA1dzy7LXwGfMPg9mTkuh5tine3,lvtGpMZHb9,name,title in items:
					name = pTP49ckGDYrofa2KxenumbH0(name)
					if 'http' not in pcA1dzy7LXwGfMPg9mTkuh5tine3: pcA1dzy7LXwGfMPg9mTkuh5tine3 = OZSA7QNfeE+pcA1dzy7LXwGfMPg9mTkuh5tine3
					title = name+' - '+title
					MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,573,lvtGpMZHb9,b8Qe150xVaJsnDSv,'episodes')
	if type=='episodes' or not FYIl2eqyG1afdLbuOA6s:
		I6YPOSofrpnTwRm8b = YYBlm36zd0Jst18LXwo4.findall('"posterImg".*?src="(.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if I6YPOSofrpnTwRm8b: lvtGpMZHb9 = I6YPOSofrpnTwRm8b[0]
		else: lvtGpMZHb9 = b8Qe150xVaJsnDSv
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('"epAll"(.*?)</div>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if ZV5rRvabhxJ:
			OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
			items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)".*?>(.*?)</a>',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
			for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
				title = title.strip(pldxivXC5wbTB2O8q)
				title = pTP49ckGDYrofa2KxenumbH0(title)
				MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,572,lvtGpMZHb9)
	return
def Hkij627uCDJKyIM(url):
	n92bB0YwDLqyadQRlmGW,GGBcERn1PkZ73yzv,bAZ28SMxhtIWmT314 = [],[],[]
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(LtlXH3fvMydAx,'GET',url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'FASELHD1-PLAY-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	w3vKeM0TD6oUBHqRQhJnP27uXr = YYBlm36zd0Jst18LXwo4.findall('مستوى المشاهدة.*?">(.*?)</span>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if w3vKeM0TD6oUBHqRQhJnP27uXr:
		EQUkgc3PLy5mhBiZINJ0HO1A6 = YYBlm36zd0Jst18LXwo4.findall('"tag">(.*?)</a>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if EQUkgc3PLy5mhBiZINJ0HO1A6 and vvIMS2DeraLfJ(QQ8pvXNcBfVkP5rRJ7o,url,EQUkgc3PLy5mhBiZINJ0HO1A6): return
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('"videoRow"(.*?)</div>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		items = YYBlm36zd0Jst18LXwo4.findall('src="(.*?)"',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for pcA1dzy7LXwGfMPg9mTkuh5tine3 in items:
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3.split('&img=')[0]
			n92bB0YwDLqyadQRlmGW.append(pcA1dzy7LXwGfMPg9mTkuh5tine3+'?named=__embed')
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('class="streamHeader(.*?)</ul>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		items = YYBlm36zd0Jst18LXwo4.findall("href = '(.*?)'.*?</i>(.*?)</a>",OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,name in items:
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3.split('&img=')[0]
			name = name.strip(pldxivXC5wbTB2O8q)
			n92bB0YwDLqyadQRlmGW.append(pcA1dzy7LXwGfMPg9mTkuh5tine3+'?named='+name+'__watch')
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('class="downloadLinks(.*?)blackwindow',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)".*?</span>(.*?)</a>',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,name in items:
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3.split('&img=')[0]
			n92bB0YwDLqyadQRlmGW.append(pcA1dzy7LXwGfMPg9mTkuh5tine3+'?named='+name+'__download')
	for MMY0Rr5EaG3HT in n92bB0YwDLqyadQRlmGW:
		pcA1dzy7LXwGfMPg9mTkuh5tine3,name = MMY0Rr5EaG3HT.split('?named')
		if pcA1dzy7LXwGfMPg9mTkuh5tine3 not in GGBcERn1PkZ73yzv:
			GGBcERn1PkZ73yzv.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
			bAZ28SMxhtIWmT314.append(MMY0Rr5EaG3HT)
	import QNeGEq8sWn
	QNeGEq8sWn.nqu2GCT9gHAbpIPSFZz5(bAZ28SMxhtIWmT314,QQ8pvXNcBfVkP5rRJ7o,'video',url)
	return
def kstJfK6jHQWrXDSMRIGB7(search):
	search,v7Rxw52Z4X0,showDialogs = JimhUH0SEf6w(search)
	if search==b8Qe150xVaJsnDSv: search = FT2oXWtPQpVGuexmLqKN3srdzYn()
	if search==b8Qe150xVaJsnDSv: return
	search = search.replace(pldxivXC5wbTB2O8q,'+')
	MUJCtfYVBLODrFbaZn = wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/?s='+search
	Je4TwC30iOG5DLKWAtbYvhs(MUJCtfYVBLODrFbaZn,'details5')
	return
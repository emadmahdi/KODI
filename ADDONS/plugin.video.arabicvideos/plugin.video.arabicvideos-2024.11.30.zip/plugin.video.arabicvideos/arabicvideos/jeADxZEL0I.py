# -*- coding: utf-8 -*-
from hIVCFnfxSO import *
QQ8pvXNcBfVkP5rRJ7o = 'CIMANOW'
WbzmKSZiuOYrBN7oysJ2dUv = '_CMN_'
wQjs1XZ3AO24g8y9bEeoKMiGIu7 = nTHXJIiah2qK[QQ8pvXNcBfVkP5rRJ7o][0]
v1vJEhoNQBVPkjG = ['قائمتي']
def x8IFqMZeJj7suCR4AaGoNXfEHm(mode,url,text):
	if   mode==300: XXxlOLJ9KRjPH382WVCvr6n71 = Y72YmLgw4vqlHxTCkbeKSicasD()
	elif mode==301: XXxlOLJ9KRjPH382WVCvr6n71 = Q6mUHMbNlirVXPRgKWJAt8ap5hSE(url)
	elif mode==302: XXxlOLJ9KRjPH382WVCvr6n71 = Je4TwC30iOG5DLKWAtbYvhs(url)
	elif mode==303: XXxlOLJ9KRjPH382WVCvr6n71 = u9umIE5RBNelHSkqhArpCnW80(url)
	elif mode==304: XXxlOLJ9KRjPH382WVCvr6n71 = bIpskeGhBlqH(url)
	elif mode==305: XXxlOLJ9KRjPH382WVCvr6n71 = Hkij627uCDJKyIM(url)
	elif mode==306: XXxlOLJ9KRjPH382WVCvr6n71 = bn9ZvjB1acOpSFf()
	elif mode==309: XXxlOLJ9KRjPH382WVCvr6n71 = kstJfK6jHQWrXDSMRIGB7(text)
	else: XXxlOLJ9KRjPH382WVCvr6n71 = False
	return XXxlOLJ9KRjPH382WVCvr6n71
def Y72YmLgw4vqlHxTCkbeKSicasD():
	MQtuaShrKTbdZFJ5nsR7D('link',WbzmKSZiuOYrBN7oysJ2dUv+'لماذا الموقع بطيء',b8Qe150xVaJsnDSv,306)
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'بحث في الموقع',b8Qe150xVaJsnDSv,309,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'_REMEMBERRESULTS_')
	MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+' ===== ===== ===== '+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999)
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(Q49IsrlSuYRAVbGKhwdckLDOetF2PZ,'GET',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/home',b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'CIMANOW-MENU-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('<header>(.*?)</header>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
	items = YYBlm36zd0Jst18LXwo4.findall('<li><a href="(.*?)">(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
		title = title.strip(pldxivXC5wbTB2O8q)
		if not any(Y8aiFZsLKw in title for Y8aiFZsLKw in v1vJEhoNQBVPkjG):
			MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,301)
	MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+' ===== ===== ===== '+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999)
	Q6mUHMbNlirVXPRgKWJAt8ap5hSE(wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/home',jLtdbeYiQHnf4SpU2MTly)
	return jLtdbeYiQHnf4SpU2MTly
def bn9ZvjB1acOpSFf():
	tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'رسالة من المبرمج','موقع سيما ناو بطيء من المصدر .. بسبب قيام أصحاب الموقع بتشفير محتويات جميع صفحات الموقع .. والوقت الضائع يذهب في معالجة تشفير الصفحات المشفرة قبل عرض محتوياتها في قوائم هذا البرنامج')
	return
def Q6mUHMbNlirVXPRgKWJAt8ap5hSE(url,jLtdbeYiQHnf4SpU2MTly=b8Qe150xVaJsnDSv):
	if not jLtdbeYiQHnf4SpU2MTly:
		b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(Q49IsrlSuYRAVbGKhwdckLDOetF2PZ,'GET',url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'CIMANOW-SUBMENU-1st')
		jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	JZMvR4mp2rX7Kf6n = 0
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('(<section>.*?</section>)',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ:
		for OTKx7aVb2hdS16Wrweky4FXfIN0g9 in ZV5rRvabhxJ:
			JZMvR4mp2rX7Kf6n += 1
			items = YYBlm36zd0Jst18LXwo4.findall('<section>.<span>(.*?)<(.*?)href="(.*?)"',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
			for title,McEoY7XlBkuhePgxwF,pcA1dzy7LXwGfMPg9mTkuh5tine3 in items:
				title = title.strip(pldxivXC5wbTB2O8q)
				if title==b8Qe150xVaJsnDSv: title = 'بووووو'
				if 'em><a' not in McEoY7XlBkuhePgxwF:
					if OTKx7aVb2hdS16Wrweky4FXfIN0g9.count('/category/')>0:
						UYsh9fbVInMj = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)"',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
						for pcA1dzy7LXwGfMPg9mTkuh5tine3 in UYsh9fbVInMj:
							title = pcA1dzy7LXwGfMPg9mTkuh5tine3.split('/')[-2]
							MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,301)
						continue
					else: pcA1dzy7LXwGfMPg9mTkuh5tine3 = url+'?sequence='+str(JZMvR4mp2rX7Kf6n)
				if not any(Y8aiFZsLKw in title for Y8aiFZsLKw in v1vJEhoNQBVPkjG):
					MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,302)
	else: Je4TwC30iOG5DLKWAtbYvhs(url,jLtdbeYiQHnf4SpU2MTly)
	return
def Je4TwC30iOG5DLKWAtbYvhs(url,jLtdbeYiQHnf4SpU2MTly=b8Qe150xVaJsnDSv):
	if jLtdbeYiQHnf4SpU2MTly==b8Qe150xVaJsnDSv:
		b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'CIMANOW-TITLES-1st')
		jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	if '?sequence=' in url:
		url,JZMvR4mp2rX7Kf6n = url.split('?sequence=')
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('(<section>.*?</section>)',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[int(JZMvR4mp2rX7Kf6n)-1]
	else:
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('"posts"(.*?)</body>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
	items = YYBlm36zd0Jst18LXwo4.findall('<a.*?href="(.*?)"(.*?)data-src="(.*?)"',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	d3VSIefbHnvqiut = []
	for pcA1dzy7LXwGfMPg9mTkuh5tine3,data,lvtGpMZHb9 in items:
		title = YYBlm36zd0Jst18LXwo4.findall('<em>(.*?)</em>(.*?)</li>.*?</em>(.*?)<em>',data,YYBlm36zd0Jst18LXwo4.DOTALL)
		if title: title = title[0][2].replace(eeN6dTEnkJxI,b8Qe150xVaJsnDSv).strip(pldxivXC5wbTB2O8q)
		if not title or title==b8Qe150xVaJsnDSv:
			title = YYBlm36zd0Jst18LXwo4.findall('title">.*?</em>(.*?)<',data,YYBlm36zd0Jst18LXwo4.DOTALL)
			if title: title = title[0].replace(eeN6dTEnkJxI,b8Qe150xVaJsnDSv).strip(pldxivXC5wbTB2O8q)
			if not title or title==b8Qe150xVaJsnDSv:
				title = YYBlm36zd0Jst18LXwo4.findall('title">(.*?)<',data,YYBlm36zd0Jst18LXwo4.DOTALL)
				title = title[0].replace(eeN6dTEnkJxI,b8Qe150xVaJsnDSv).strip(pldxivXC5wbTB2O8q)
		title = pTP49ckGDYrofa2KxenumbH0(title)
		title = title.replace(k5bCDErUSmv,pldxivXC5wbTB2O8q)
		if title not in d3VSIefbHnvqiut:
			d3VSIefbHnvqiut.append(title)
			CmEkolxes7Q6hB01fGTPZi4 = pcA1dzy7LXwGfMPg9mTkuh5tine3+data+lvtGpMZHb9
			if '/selary/' in CmEkolxes7Q6hB01fGTPZi4 or 'مسلسل' in CmEkolxes7Q6hB01fGTPZi4 or '"episode"' in CmEkolxes7Q6hB01fGTPZi4:
				if 'برامج' in data: title = 'برنامج '+title
				elif 'مسلسل' in data or 'موسم' in data: title = 'مسلسل '+title
				MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,303,lvtGpMZHb9)
			else: MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,305,lvtGpMZHb9)
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('"pagination"(.*?)</div>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		items = YYBlm36zd0Jst18LXwo4.findall('<li><a href="(.*?)">(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
			MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'صفحة '+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,302)
	return
def u9umIE5RBNelHSkqhArpCnW80(url):
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'CIMANOW-SEASONS-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	name = YYBlm36zd0Jst18LXwo4.findall('<title>(.*?)</title>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	name = name[0].replace('| سيما ناو',b8Qe150xVaJsnDSv).replace('Cima Now',b8Qe150xVaJsnDSv).strip(pldxivXC5wbTB2O8q).replace(k5bCDErUSmv,pldxivXC5wbTB2O8q)
	name = name.split('الحلقة')[0].strip(pldxivXC5wbTB2O8q)
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('<section(.*?)</section>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)">(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		if len(items)>1:
			for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
				title = name+' - '+title.replace(eeN6dTEnkJxI,b8Qe150xVaJsnDSv).strip(pldxivXC5wbTB2O8q)
				MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,304)
		else: bIpskeGhBlqH(url)
	return
def bIpskeGhBlqH(url):
	if '/selary/' not in url: url = url.strip('/')+'/watching'
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'CIMANOW-EPISODES-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	if '/selary/' not in url:
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('"episodes"(.*?)</ul>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)">(.*?)</a>',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
			title = title.replace(eeN6dTEnkJxI,b8Qe150xVaJsnDSv).strip(pldxivXC5wbTB2O8q)
			title = 'الحلقة '+title
			MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,305)
	else:
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('"details"(.*?)"related"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)".*?src=.*?src="(.*?)".*?alt="(.*?)"',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,lvtGpMZHb9,title in items:
			title = title.replace(eeN6dTEnkJxI,b8Qe150xVaJsnDSv).strip(pldxivXC5wbTB2O8q)
			MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,305,lvtGpMZHb9)
	return
def Hkij627uCDJKyIM(url):
	MUJCtfYVBLODrFbaZn = url+'watching/'
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(LtlXH3fvMydAx,'GET',MUJCtfYVBLODrFbaZn,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'CIMANOW-PLAY-5th')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = []
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('"download"(.*?)</ul>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)".*?</i>(.*?)</a>',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
			title = title.replace(eeN6dTEnkJxI,b8Qe150xVaJsnDSv).strip(pldxivXC5wbTB2O8q)
			c1EdszLx3mkb8QYX9 = YYBlm36zd0Jst18LXwo4.findall('\d\d\d+',title,YYBlm36zd0Jst18LXwo4.DOTALL)
			if c1EdszLx3mkb8QYX9:
				c1EdszLx3mkb8QYX9 = '____'+c1EdszLx3mkb8QYX9[0]
				title = Wl2eu1PavfQ(pcA1dzy7LXwGfMPg9mTkuh5tine3,'name')
			else: c1EdszLx3mkb8QYX9 = b8Qe150xVaJsnDSv
			eiFs3pQPyZtjb0W = pcA1dzy7LXwGfMPg9mTkuh5tine3+'?named='+title+'__download'+c1EdszLx3mkb8QYX9
			KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j.append(eiFs3pQPyZtjb0W)
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('"watch"(.*?)</ul>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		tzdvaEpMHOCZLXDYg08T = YYBlm36zd0Jst18LXwo4.findall('"embed".*?src="(.*?)"',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for pcA1dzy7LXwGfMPg9mTkuh5tine3 in tzdvaEpMHOCZLXDYg08T:
			if 'http' not in pcA1dzy7LXwGfMPg9mTkuh5tine3: pcA1dzy7LXwGfMPg9mTkuh5tine3 = 'http:'+pcA1dzy7LXwGfMPg9mTkuh5tine3
			title = Wl2eu1PavfQ(pcA1dzy7LXwGfMPg9mTkuh5tine3,'name')
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3+'?named='+title+'__embed'
			KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
		tzdvaEpMHOCZLXDYg08T = [wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/wp-content/themes/Cima%20Now%20New/core.php']
		if tzdvaEpMHOCZLXDYg08T:
			items = YYBlm36zd0Jst18LXwo4.findall('data-index="(.*?)".*?data-id="(.*?)".*?>(.*?)</li>',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
			for tmaChESsDcO9dxLW4GQb,id,title in items:
				title = title.replace(eeN6dTEnkJxI,b8Qe150xVaJsnDSv).strip(pldxivXC5wbTB2O8q)
				pcA1dzy7LXwGfMPg9mTkuh5tine3 = tzdvaEpMHOCZLXDYg08T[0]+'?action=switch&index='+tmaChESsDcO9dxLW4GQb+'&id='+id+'?named='+title+'__watch'
				KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
	import QNeGEq8sWn
	QNeGEq8sWn.nqu2GCT9gHAbpIPSFZz5(KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j,QQ8pvXNcBfVkP5rRJ7o,'video',url)
	return
def kstJfK6jHQWrXDSMRIGB7(search):
	search,v7Rxw52Z4X0,showDialogs = JimhUH0SEf6w(search)
	if search==b8Qe150xVaJsnDSv: search = FT2oXWtPQpVGuexmLqKN3srdzYn()
	if search==b8Qe150xVaJsnDSv: return
	search = search.replace(pldxivXC5wbTB2O8q,'+')
	url = wQjs1XZ3AO24g8y9bEeoKMiGIu7 + '/?s='+search
	Je4TwC30iOG5DLKWAtbYvhs(url)
	return
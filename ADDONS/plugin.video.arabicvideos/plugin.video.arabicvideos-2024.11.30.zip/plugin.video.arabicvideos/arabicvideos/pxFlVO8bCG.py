# -*- coding: utf-8 -*-
from hIVCFnfxSO import *
ALwGbyiBFzY7H = 'M3U'
i4lR3ISvhqJFGBwcrNtCY2mAZu9 = '_M3U_'
YlEVuPr4LqIB6m7xHJ = [
		 'IGNORED'
		,'LIVE_UNKNOWN_GROUPED','LIVE_UNKNOWN_GROUPED_SORTED'
		,'VOD_UNKNOWN_GROUPED','VOD_UNKNOWN_GROUPED_SORTED'
		,'LIVE_GROUPED','LIVE_GROUPED_SORTED'
		,'LIVE_ORIGINAL_GROUPED','LIVE_FROM_GROUP_SORTED','LIVE_FROM_NAME_SORTED'
		,'VOD_MOVIES_GROUPED','VOD_MOVIES_GROUPED_SORTED'
		,'VOD_SERIES_GROUPED','VOD_SERIES_GROUPED_SORTED'
		,'VOD_ORIGINAL_GROUPED','VOD_FROM_GROUP_SORTED','VOD_FROM_NAME_SORTED'
		]
yrzdN9Z7pLmkjI = 4
def BBC8ziWGv2TLl5sjHm9uZk14b(ZZtDTHnBXMz,uuNDjbit4hOpx,pnmsJqCWIHVk2Y6xPvl9Q0Ez8r,A60AIQZCYRzdhaeWfOtmrSUVoq2nN,EAlZ2zKn6uagcqtY3yBoMxDmSbOwk,ZzHaCLyPtIk1iurbW):
	global i4lR3ISvhqJFGBwcrNtCY2mAZu9
	try:
		rA1p4eTdbhi69sotZkuP0QafYNDn = str(ZzHaCLyPtIk1iurbW['folder'])
		i4lR3ISvhqJFGBwcrNtCY2mAZu9 = '_MU'+rA1p4eTdbhi69sotZkuP0QafYNDn+'_'
	except: rA1p4eTdbhi69sotZkuP0QafYNDn = b8Qe150xVaJsnDSv
	try: KHiQ5Z6kBVYoPjUsa = str(ZzHaCLyPtIk1iurbW['sequence'])
	except: KHiQ5Z6kBVYoPjUsa = b8Qe150xVaJsnDSv
	if   ZZtDTHnBXMz==710: kpd8hRM9mn = QQKHriu7fyZSX6qwO3FvUekJBsjI()
	elif ZZtDTHnBXMz==711: kpd8hRM9mn = NGe8Whf2qj5isU3cJaYd1wXx(rA1p4eTdbhi69sotZkuP0QafYNDn,KHiQ5Z6kBVYoPjUsa)
	elif ZZtDTHnBXMz==712: kpd8hRM9mn = exw87PJcKOSo30mLWTrhdpEYVMD(rA1p4eTdbhi69sotZkuP0QafYNDn)
	elif ZZtDTHnBXMz==713: kpd8hRM9mn = YhgBJAG0zwX5i(rA1p4eTdbhi69sotZkuP0QafYNDn,uuNDjbit4hOpx,pnmsJqCWIHVk2Y6xPvl9Q0Ez8r,EAlZ2zKn6uagcqtY3yBoMxDmSbOwk)
	elif ZZtDTHnBXMz==714: kpd8hRM9mn = iyZpId2R5sL7F0kDb3AKH9xS(rA1p4eTdbhi69sotZkuP0QafYNDn,uuNDjbit4hOpx,pnmsJqCWIHVk2Y6xPvl9Q0Ez8r,EAlZ2zKn6uagcqtY3yBoMxDmSbOwk)
	elif ZZtDTHnBXMz==715: kpd8hRM9mn = Hkij627uCDJKyIM(rA1p4eTdbhi69sotZkuP0QafYNDn,uuNDjbit4hOpx,A60AIQZCYRzdhaeWfOtmrSUVoq2nN)
	elif ZZtDTHnBXMz==716: kpd8hRM9mn = tNH3wo1W7TPhV9Lx6Y4MFckGn5(rA1p4eTdbhi69sotZkuP0QafYNDn,True)
	elif ZZtDTHnBXMz==717: kpd8hRM9mn = zmpSMKk62PBL(rA1p4eTdbhi69sotZkuP0QafYNDn,True)
	elif ZZtDTHnBXMz==718: kpd8hRM9mn = ddBQqIfREpXoaGN9MH(rA1p4eTdbhi69sotZkuP0QafYNDn,uuNDjbit4hOpx,pnmsJqCWIHVk2Y6xPvl9Q0Ez8r)
	elif ZZtDTHnBXMz==719: kpd8hRM9mn = YZtbF9MC8LiySHKjmD4gkxwnsT3dRv(pnmsJqCWIHVk2Y6xPvl9Q0Ez8r,rA1p4eTdbhi69sotZkuP0QafYNDn,uuNDjbit4hOpx,EAlZ2zKn6uagcqtY3yBoMxDmSbOwk)
	elif ZZtDTHnBXMz==720: kpd8hRM9mn = faCzcxFZWbO9ULQs70Y(rA1p4eTdbhi69sotZkuP0QafYNDn,True)
	elif ZZtDTHnBXMz==721: kpd8hRM9mn = b7n4Kjtk3OuhAm0aFNo5wfHgs(rA1p4eTdbhi69sotZkuP0QafYNDn)
	elif ZZtDTHnBXMz==722: kpd8hRM9mn = MFWl3wdPecfkxDXS2OK(rA1p4eTdbhi69sotZkuP0QafYNDn)
	elif ZZtDTHnBXMz==723: kpd8hRM9mn = FgSuBI8CoaVeh(rA1p4eTdbhi69sotZkuP0QafYNDn)
	elif ZZtDTHnBXMz==726: kpd8hRM9mn = DDjSzaYGWuJw(rA1p4eTdbhi69sotZkuP0QafYNDn)
	elif ZZtDTHnBXMz==729: kpd8hRM9mn = btuQcD9l23RWKJACB(pnmsJqCWIHVk2Y6xPvl9Q0Ez8r,rA1p4eTdbhi69sotZkuP0QafYNDn,uuNDjbit4hOpx,EAlZ2zKn6uagcqtY3yBoMxDmSbOwk)
	else: kpd8hRM9mn = False
	return kpd8hRM9mn
def QQKHriu7fyZSX6qwO3FvUekJBsjI():
	for rA1p4eTdbhi69sotZkuP0QafYNDn in range(1,PINQnUL6h3XA9at+1):
		i4lR3ISvhqJFGBwcrNtCY2mAZu9 = '_MU'+str(rA1p4eTdbhi69sotZkuP0QafYNDn)+'_'
		MQtuaShrKTbdZFJ5nsR7D('folder',i4lR3ISvhqJFGBwcrNtCY2mAZu9+'قائمة مجلد '+iP9ZMSrYOJQhB73CN2yj4Kg1p6V5aT[rA1p4eTdbhi69sotZkuP0QafYNDn],b8Qe150xVaJsnDSv,720,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,{'folder':rA1p4eTdbhi69sotZkuP0QafYNDn})
	return
def faCzcxFZWbO9ULQs70Y(rA1p4eTdbhi69sotZkuP0QafYNDn=b8Qe150xVaJsnDSv,ZUPyYNpfLTgIFG4rW38So1kqzRE7du=b8Qe150xVaJsnDSv):
	if rA1p4eTdbhi69sotZkuP0QafYNDn:
		ZPsQl84SDtEAo2wfWj = {'folder':rA1p4eTdbhi69sotZkuP0QafYNDn}
		agjsvpHDx8SX93WUhqizm5NbCQeGFY = b8Qe150xVaJsnDSv
	else:
		ZPsQl84SDtEAo2wfWj = b8Qe150xVaJsnDSv
		agjsvpHDx8SX93WUhqizm5NbCQeGFY = b8Qe150xVaJsnDSv
	AZ6zfKXJwoLMNp2iPdsl = yyq2ZDzu5wSeCKA84pxf7PRWTOrBtY(rA1p4eTdbhi69sotZkuP0QafYNDn,ZUPyYNpfLTgIFG4rW38So1kqzRE7du)
	if not AZ6zfKXJwoLMNp2iPdsl:
		MQtuaShrKTbdZFJ5nsR7D('link',i4lR3ISvhqJFGBwcrNtCY2mAZu9+OkuB9nwhD8U1+' إضافة وتغيير رابط'+agjsvpHDx8SX93WUhqizm5NbCQeGFY+pldxivXC5wbTB2O8q+iP9ZMSrYOJQhB73CN2yj4Kg1p6V5aT[1]+' '+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,711,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,{'folder':rA1p4eTdbhi69sotZkuP0QafYNDn,'sequence':1})
		MQtuaShrKTbdZFJ5nsR7D('link',i4lR3ISvhqJFGBwcrNtCY2mAZu9+OkuB9nwhD8U1+' جلب ملفات'+agjsvpHDx8SX93WUhqizm5NbCQeGFY+' '+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,712,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,ZPsQl84SDtEAo2wfWj)
		MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+' ===== ===== ===== '+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999)
	else:
		MQtuaShrKTbdZFJ5nsR7D('folder',i4lR3ISvhqJFGBwcrNtCY2mAZu9+'بحث في الملفات'+agjsvpHDx8SX93WUhqizm5NbCQeGFY,b8Qe150xVaJsnDSv,729,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'_REMEMBERRESULTS_',b8Qe150xVaJsnDSv,ZPsQl84SDtEAo2wfWj)
		MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+' ===== ===== ===== '+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999)
		MQtuaShrKTbdZFJ5nsR7D('folder',i4lR3ISvhqJFGBwcrNtCY2mAZu9+'قنوات مصنفة مرتبة'+agjsvpHDx8SX93WUhqizm5NbCQeGFY,'LIVE_GROUPED_SORTED',713,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,ZPsQl84SDtEAo2wfWj)
		MQtuaShrKTbdZFJ5nsR7D('folder',i4lR3ISvhqJFGBwcrNtCY2mAZu9+'قنوات مصنفة من القسم'+agjsvpHDx8SX93WUhqizm5NbCQeGFY,'LIVE_FROM_GROUP_SORTED',713,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,ZPsQl84SDtEAo2wfWj)
		MQtuaShrKTbdZFJ5nsR7D('folder',i4lR3ISvhqJFGBwcrNtCY2mAZu9+'قنوات مصنفة من الاسم'+agjsvpHDx8SX93WUhqizm5NbCQeGFY,'LIVE_FROM_NAME_SORTED',713,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,ZPsQl84SDtEAo2wfWj)
		MQtuaShrKTbdZFJ5nsR7D('folder',i4lR3ISvhqJFGBwcrNtCY2mAZu9+'قنوات مصنفة بلا ترتيب'+agjsvpHDx8SX93WUhqizm5NbCQeGFY,'LIVE_GROUPED',713,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,ZPsQl84SDtEAo2wfWj)
		MQtuaShrKTbdZFJ5nsR7D('folder',i4lR3ISvhqJFGBwcrNtCY2mAZu9+'قنوات بلا ترتيب'+agjsvpHDx8SX93WUhqizm5NbCQeGFY,'LIVE_ORIGINAL_GROUPED',713,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,ZPsQl84SDtEAo2wfWj)
		MQtuaShrKTbdZFJ5nsR7D('folder',i4lR3ISvhqJFGBwcrNtCY2mAZu9+'قنوات مجهولة مرتبة'+agjsvpHDx8SX93WUhqizm5NbCQeGFY,'LIVE_UNKNOWN_GROUPED_SORTED',713,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,ZPsQl84SDtEAo2wfWj)
		MQtuaShrKTbdZFJ5nsR7D('folder',i4lR3ISvhqJFGBwcrNtCY2mAZu9+'قنوات مجهولة بلا ترتيب'+agjsvpHDx8SX93WUhqizm5NbCQeGFY,'LIVE_UNKNOWN_GROUPED',713,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,ZPsQl84SDtEAo2wfWj)
		MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+' ===== ===== ===== '+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999)
		MQtuaShrKTbdZFJ5nsR7D('folder',i4lR3ISvhqJFGBwcrNtCY2mAZu9+'فيديوهات بلا ترتيب'+agjsvpHDx8SX93WUhqizm5NbCQeGFY,'VOD_ORIGINAL_GROUPED',713,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,ZPsQl84SDtEAo2wfWj)
		MQtuaShrKTbdZFJ5nsR7D('folder',i4lR3ISvhqJFGBwcrNtCY2mAZu9+'فيديوهات مصنفة القسم'+agjsvpHDx8SX93WUhqizm5NbCQeGFY,'VOD_FROM_GROUP_SORTED',713,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,ZPsQl84SDtEAo2wfWj)
		MQtuaShrKTbdZFJ5nsR7D('folder',i4lR3ISvhqJFGBwcrNtCY2mAZu9+'فيديوهات مصنفة من الاسم'+agjsvpHDx8SX93WUhqizm5NbCQeGFY,'VOD_FROM_NAME_SORTED',713,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,ZPsQl84SDtEAo2wfWj)
		MQtuaShrKTbdZFJ5nsR7D('folder',i4lR3ISvhqJFGBwcrNtCY2mAZu9+'فيديوهات مجهولة بلا ترتيب'+agjsvpHDx8SX93WUhqizm5NbCQeGFY,'VOD_UNKNOWN_GROUPED',713,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,ZPsQl84SDtEAo2wfWj)
		MQtuaShrKTbdZFJ5nsR7D('folder',i4lR3ISvhqJFGBwcrNtCY2mAZu9+'فيديوهات مجهولة مرتبة'+agjsvpHDx8SX93WUhqizm5NbCQeGFY,'VOD_UNKNOWN_GROUPED_SORTED',713,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,ZPsQl84SDtEAo2wfWj)
		MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+' ===== ===== ===== '+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999)
	for iNdb241X5QmGjzfhopLkc0wUgCl6DM in range(1,yrzdN9Z7pLmkjI+1):
		MQtuaShrKTbdZFJ5nsR7D('link',i4lR3ISvhqJFGBwcrNtCY2mAZu9+'إضافة وتغيير رابط'+agjsvpHDx8SX93WUhqizm5NbCQeGFY+pldxivXC5wbTB2O8q+iP9ZMSrYOJQhB73CN2yj4Kg1p6V5aT[iNdb241X5QmGjzfhopLkc0wUgCl6DM],b8Qe150xVaJsnDSv,711,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,{'folder':rA1p4eTdbhi69sotZkuP0QafYNDn,'sequence':iNdb241X5QmGjzfhopLkc0wUgCl6DM})
	MQtuaShrKTbdZFJ5nsR7D('link',i4lR3ISvhqJFGBwcrNtCY2mAZu9+'جلب ملفات'+agjsvpHDx8SX93WUhqizm5NbCQeGFY,b8Qe150xVaJsnDSv,712,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,ZPsQl84SDtEAo2wfWj)
	MQtuaShrKTbdZFJ5nsR7D('link',i4lR3ISvhqJFGBwcrNtCY2mAZu9+'مسح ملفات'+agjsvpHDx8SX93WUhqizm5NbCQeGFY,b8Qe150xVaJsnDSv,717,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,ZPsQl84SDtEAo2wfWj)
	MQtuaShrKTbdZFJ5nsR7D('link',i4lR3ISvhqJFGBwcrNtCY2mAZu9+'عدد فيديوهات'+agjsvpHDx8SX93WUhqizm5NbCQeGFY,b8Qe150xVaJsnDSv,721,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,ZPsQl84SDtEAo2wfWj)
	MQtuaShrKTbdZFJ5nsR7D('link',i4lR3ISvhqJFGBwcrNtCY2mAZu9+'Referer تغيير'+agjsvpHDx8SX93WUhqizm5NbCQeGFY,b8Qe150xVaJsnDSv,726,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,ZPsQl84SDtEAo2wfWj)
	MQtuaShrKTbdZFJ5nsR7D('link',i4lR3ISvhqJFGBwcrNtCY2mAZu9+'User-Agent تغيير'+agjsvpHDx8SX93WUhqizm5NbCQeGFY,b8Qe150xVaJsnDSv,723,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,ZPsQl84SDtEAo2wfWj)
	return
def tNH3wo1W7TPhV9Lx6Y4MFckGn5(rA1p4eTdbhi69sotZkuP0QafYNDn,ZUPyYNpfLTgIFG4rW38So1kqzRE7du=True):
	rrAx3PhQXi,m8YJUjRwaGX4O6MEevsi5tFx0IAonL = False,b8Qe150xVaJsnDSv
	dgJF1846SsPuVEexvaLnQp7rHOU,kSorHcEWFs503dwvDblhOyJ6T9f = b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv
	W8XSop4zRMrQIyJxnYsVq6BlA5mLkE,UUGcBS73g1,DLyvH8FaW2VOJXIsqMR9gYEKB6C,LdqjiZRmEoPpO30BUMFT4ryHAXG97z,WEyfpNCg5zBlewL0rYoj = atsVLJ5h3XMgGnoDS8mzCZK92(rA1p4eTdbhi69sotZkuP0QafYNDn)
	if LdqjiZRmEoPpO30BUMFT4ryHAXG97z==b8Qe150xVaJsnDSv: return False,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv
	NNB43WbKMVnrktmcsZXUR6wvfJq = F04FsYgKcE(rA1p4eTdbhi69sotZkuP0QafYNDn)
	if W8XSop4zRMrQIyJxnYsVq6BlA5mLkE:
		mJegc5bW2YjVwD = dcLRAZWFzODax2jf0tHCX81pJveNY(nCUMfrlZvuiLe5x,'GET',W8XSop4zRMrQIyJxnYsVq6BlA5mLkE,b8Qe150xVaJsnDSv,NNB43WbKMVnrktmcsZXUR6wvfJq,False,b8Qe150xVaJsnDSv,'M3U-CHECK_ACCOUNT-1st')
		RgtGekOpZJTE4 = mJegc5bW2YjVwD.content
		if mJegc5bW2YjVwD.succeeded:
			XkwLHgZdc0hEN1COVnjSPqG2vF,yB7a90zc6Hbj,itYj2ec5Zwp1VyLqMhlEUG,Rdq2yOmc5lPzUWbsXCN9,Pm2cxyYfZMrs0XVi4nWTN7SJAbLUj = 0,0,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv
			try:
				W0sGaMZXq8nrSvj6K2fU = oJsUwXA0yGOI1mTjxQ('dict',RgtGekOpZJTE4)
				m8YJUjRwaGX4O6MEevsi5tFx0IAonL = W0sGaMZXq8nrSvj6K2fU['user_info']['status']
				rrAx3PhQXi = True
				itYj2ec5Zwp1VyLqMhlEUG = W0sGaMZXq8nrSvj6K2fU['server_info']['time_now']
			except: pass
			if itYj2ec5Zwp1VyLqMhlEUG:
				try:
					cIM6kgyVSGaBW = wLQCTr5lqbsVYeAHdzfhZ1F.strptime(itYj2ec5Zwp1VyLqMhlEUG,'%Y.%m.%d %H:%M:%S')
					XkwLHgZdc0hEN1COVnjSPqG2vF = int(wLQCTr5lqbsVYeAHdzfhZ1F.mktime(cIM6kgyVSGaBW))
					yB7a90zc6Hbj = int(T3Axql94cU0BpO1wudEDtWXsf-XkwLHgZdc0hEN1COVnjSPqG2vF)
					yB7a90zc6Hbj = int((yB7a90zc6Hbj+900)/1800)*1800
				except: pass
				try:
					cIM6kgyVSGaBW = wLQCTr5lqbsVYeAHdzfhZ1F.localtime(int(W0sGaMZXq8nrSvj6K2fU['user_info']['created_at']))
					Rdq2yOmc5lPzUWbsXCN9 = wLQCTr5lqbsVYeAHdzfhZ1F.strftime('%Y.%m.%d %H:%M:%S',cIM6kgyVSGaBW)
				except: pass
				try:
					cIM6kgyVSGaBW = wLQCTr5lqbsVYeAHdzfhZ1F.localtime(int(W0sGaMZXq8nrSvj6K2fU['user_info']['exp_date']))
					Pm2cxyYfZMrs0XVi4nWTN7SJAbLUj = wLQCTr5lqbsVYeAHdzfhZ1F.strftime('%Y.%m.%d %H:%M:%S',cIM6kgyVSGaBW)
				except: pass
			hRWC8YSFvsm4JHOMVIne3jquZ.setSetting('av.m3u.timestamp_'+rA1p4eTdbhi69sotZkuP0QafYNDn,str(T3Axql94cU0BpO1wudEDtWXsf))
			hRWC8YSFvsm4JHOMVIne3jquZ.setSetting('av.m3u.timediff_'+rA1p4eTdbhi69sotZkuP0QafYNDn,str(yB7a90zc6Hbj))
			try:
				Xwjq4tgeMk70h = '"server_info":'+RgtGekOpZJTE4.split('"server_info":')[1]
				Xwjq4tgeMk70h = Xwjq4tgeMk70h.replace(':',': ').replace(',',', ').replace('}}','}')
				KB7PG5jkWeUmS2iTaCz9ZcD13sIp = YYBlm36zd0Jst18LXwo4.findall('"url": "(.*?)", "port": "(.*?)"',Xwjq4tgeMk70h,YYBlm36zd0Jst18LXwo4.DOTALL)
				dgJF1846SsPuVEexvaLnQp7rHOU,kSorHcEWFs503dwvDblhOyJ6T9f = KB7PG5jkWeUmS2iTaCz9ZcD13sIp[0]
			except: rrAx3PhQXi = False
			if rrAx3PhQXi and ZUPyYNpfLTgIFG4rW38So1kqzRE7du:
				max = W0sGaMZXq8nrSvj6K2fU['user_info']['max_connections']
				whENtaPz85udMqpI4YHBk2A = W0sGaMZXq8nrSvj6K2fU['user_info']['active_cons']
				ssP4nUHawJljvWXFhi = W0sGaMZXq8nrSvj6K2fU['user_info']['is_trial']
				CNMVo850ODPatQXTvBriYq1W = W8XSop4zRMrQIyJxnYsVq6BlA5mLkE.split('?',1)
				A4gdSTQDP2FyBIVuba85RvYqKU = 'URL:  '+rC3Tlno96KjLDIvBaSWUbR8+W8XSop4zRMrQIyJxnYsVq6BlA5mLkE+hAIp8kmC36T5WFPMSXOwnNbtD
				A4gdSTQDP2FyBIVuba85RvYqKU += '\n\nStatus:  '+rC3Tlno96KjLDIvBaSWUbR8+m8YJUjRwaGX4O6MEevsi5tFx0IAonL+hAIp8kmC36T5WFPMSXOwnNbtD
				A4gdSTQDP2FyBIVuba85RvYqKU += '\nTrial:    '+rC3Tlno96KjLDIvBaSWUbR8+str(ssP4nUHawJljvWXFhi=='1')+hAIp8kmC36T5WFPMSXOwnNbtD
				A4gdSTQDP2FyBIVuba85RvYqKU += '\nCreated  At:  '+rC3Tlno96KjLDIvBaSWUbR8+Rdq2yOmc5lPzUWbsXCN9+hAIp8kmC36T5WFPMSXOwnNbtD
				A4gdSTQDP2FyBIVuba85RvYqKU += '\nExpiry Date:  '+rC3Tlno96KjLDIvBaSWUbR8+Pm2cxyYfZMrs0XVi4nWTN7SJAbLUj+hAIp8kmC36T5WFPMSXOwnNbtD
				A4gdSTQDP2FyBIVuba85RvYqKU += '\nConnections   ( Active / Maximum ) :  '+rC3Tlno96KjLDIvBaSWUbR8+whENtaPz85udMqpI4YHBk2A+' / '+max+hAIp8kmC36T5WFPMSXOwnNbtD
				A4gdSTQDP2FyBIVuba85RvYqKU += '\nAllowed Outputs:   '+rC3Tlno96KjLDIvBaSWUbR8+" , ".join(W0sGaMZXq8nrSvj6K2fU['user_info']['allowed_output_formats'])+hAIp8kmC36T5WFPMSXOwnNbtD
				A4gdSTQDP2FyBIVuba85RvYqKU += '\n\n'+Xwjq4tgeMk70h
				if m8YJUjRwaGX4O6MEevsi5tFx0IAonL=='Active': ryTNDEf2xWFCdi60AMKBomSVRpP5('الاشتراك يعمل بدون مشاكل',A4gdSTQDP2FyBIVuba85RvYqKU)
				else: ryTNDEf2xWFCdi60AMKBomSVRpP5('يبدو أن هناك مشكلة في الاشتراك',A4gdSTQDP2FyBIVuba85RvYqKU)
	if W8XSop4zRMrQIyJxnYsVq6BlA5mLkE and rrAx3PhQXi and m8YJUjRwaGX4O6MEevsi5tFx0IAonL=='Active':
		mwIxD3GBPgLVc2aq9(MtTygrzXFlQ,'.\tChecking M3U URL   [ M3U account is OK ]   [ '+W8XSop4zRMrQIyJxnYsVq6BlA5mLkE+' ]')
		LhFtNIEfT6WHVi50bMYvRmCzro9A = True
	else:
		mwIxD3GBPgLVc2aq9(WG2BfeyzMa,'Checking M3U URL   [ Does not work ]   [ '+W8XSop4zRMrQIyJxnYsVq6BlA5mLkE+' ]')
		if ZUPyYNpfLTgIFG4rW38So1kqzRE7du: tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'فحص اشتراك ـM3U','رابط اشتراك ـM3U الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـM3U وقم بإضافة رابط ـM3U جديد أو قم بإصلاح الرابط القديم')
		LhFtNIEfT6WHVi50bMYvRmCzro9A = False
	return LhFtNIEfT6WHVi50bMYvRmCzro9A,dgJF1846SsPuVEexvaLnQp7rHOU,kSorHcEWFs503dwvDblhOyJ6T9f
def iyZpId2R5sL7F0kDb3AKH9xS(rA1p4eTdbhi69sotZkuP0QafYNDn,BxP4plOuSfmjn8Xd51sUVgrqy,YH8SsEpvKoFeq6,kR8Wp5NO9hcEvIQ1F4PM,ZUPyYNpfLTgIFG4rW38So1kqzRE7du=True):
	if not kR8Wp5NO9hcEvIQ1F4PM: kR8Wp5NO9hcEvIQ1F4PM = '1'
	if not yyq2ZDzu5wSeCKA84pxf7PRWTOrBtY(rA1p4eTdbhi69sotZkuP0QafYNDn,ZUPyYNpfLTgIFG4rW38So1kqzRE7du): return
	AGBKp17l0b6VURQ = uwgvq5oDNAdsfCPEcYy7HFRBWrkmj6(rA1p4eTdbhi69sotZkuP0QafYNDn,BxP4plOuSfmjn8Xd51sUVgrqy)
	xehYsVJtBRz = SS2OK7hjLagvUAm(AGBKp17l0b6VURQ,'list',BxP4plOuSfmjn8Xd51sUVgrqy,YH8SsEpvKoFeq6)
	kkNZlMWQrJg5OX4c = int(kR8Wp5NO9hcEvIQ1F4PM)*100
	rryAORupGNEvU2Z9CLz6QMfcWY = kkNZlMWQrJg5OX4c-100
	for czG0PxAmlw4vtWrH5eL3RubT,sbat1zOx0HydLjm5qvTPgR,uuNDjbit4hOpx,PVvXoB0pye37Sckg45QNDGlw62FjE in xehYsVJtBRz[rryAORupGNEvU2Z9CLz6QMfcWY:kkNZlMWQrJg5OX4c]:
		FVOybXuJh062gNajtPGkm5vLo = ('GROUPED' in BxP4plOuSfmjn8Xd51sUVgrqy or BxP4plOuSfmjn8Xd51sUVgrqy=='ALL')
		SQTnRFboZe86MDadJLWpB9NiKVqOG4 = ('GROUPED' not in BxP4plOuSfmjn8Xd51sUVgrqy and BxP4plOuSfmjn8Xd51sUVgrqy!='ALL')
		if FVOybXuJh062gNajtPGkm5vLo or SQTnRFboZe86MDadJLWpB9NiKVqOG4:
			if   'ARCHIVED'  in BxP4plOuSfmjn8Xd51sUVgrqy: GyjmfosC59Jub.append(['folder',i4lR3ISvhqJFGBwcrNtCY2mAZu9+sbat1zOx0HydLjm5qvTPgR,uuNDjbit4hOpx,718,PVvXoB0pye37Sckg45QNDGlw62FjE,b8Qe150xVaJsnDSv,'ARCHIVED',b8Qe150xVaJsnDSv,{'folder':rA1p4eTdbhi69sotZkuP0QafYNDn}])
			elif 'EPG' 		 in BxP4plOuSfmjn8Xd51sUVgrqy: GyjmfosC59Jub.append(['folder',i4lR3ISvhqJFGBwcrNtCY2mAZu9+sbat1zOx0HydLjm5qvTPgR,uuNDjbit4hOpx,718,PVvXoB0pye37Sckg45QNDGlw62FjE,b8Qe150xVaJsnDSv,'FULL_EPG',b8Qe150xVaJsnDSv,{'folder':rA1p4eTdbhi69sotZkuP0QafYNDn}])
			elif 'TIMESHIFT' in BxP4plOuSfmjn8Xd51sUVgrqy: GyjmfosC59Jub.append(['folder',i4lR3ISvhqJFGBwcrNtCY2mAZu9+sbat1zOx0HydLjm5qvTPgR,uuNDjbit4hOpx,718,PVvXoB0pye37Sckg45QNDGlw62FjE,b8Qe150xVaJsnDSv,'TIMESHIFT',b8Qe150xVaJsnDSv,{'folder':rA1p4eTdbhi69sotZkuP0QafYNDn}])
			elif 'LIVE' 	 in BxP4plOuSfmjn8Xd51sUVgrqy: GyjmfosC59Jub.append(['live',i4lR3ISvhqJFGBwcrNtCY2mAZu9+sbat1zOx0HydLjm5qvTPgR,uuNDjbit4hOpx,715,PVvXoB0pye37Sckg45QNDGlw62FjE,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,czG0PxAmlw4vtWrH5eL3RubT,{'folder':rA1p4eTdbhi69sotZkuP0QafYNDn}])
			else: GyjmfosC59Jub.append(['video',i4lR3ISvhqJFGBwcrNtCY2mAZu9+sbat1zOx0HydLjm5qvTPgR,uuNDjbit4hOpx,715,PVvXoB0pye37Sckg45QNDGlw62FjE,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,{'folder':rA1p4eTdbhi69sotZkuP0QafYNDn}])
	rxZjzaTRFS5 = len(xehYsVJtBRz)
	ZCkrKgME82qhdlIzND1oSQH(rA1p4eTdbhi69sotZkuP0QafYNDn,kR8Wp5NO9hcEvIQ1F4PM,BxP4plOuSfmjn8Xd51sUVgrqy,714,rxZjzaTRFS5,YH8SsEpvKoFeq6)
	return
def aume6xIr1FLqH4Q(xSMdp4WX7LK1PEN9eJ0R3UThnVsvm):
	MQtuaShrKTbdZFJ5nsR7D('link',xSMdp4WX7LK1PEN9eJ0R3UThnVsvm+'هذه القائمة إما فارغة أو غير موجودة',b8Qe150xVaJsnDSv,9999)
	MQtuaShrKTbdZFJ5nsR7D('link',xSMdp4WX7LK1PEN9eJ0R3UThnVsvm+'أو الخدمة غير موجودة في اشتراكك',b8Qe150xVaJsnDSv,9999)
	MQtuaShrKTbdZFJ5nsR7D('link',xSMdp4WX7LK1PEN9eJ0R3UThnVsvm+'أو رابط M3U الذي أنت أضفته غير صحيح',b8Qe150xVaJsnDSv,9999)
	return
def YhgBJAG0zwX5i(rA1p4eTdbhi69sotZkuP0QafYNDn,BxP4plOuSfmjn8Xd51sUVgrqy,YH8SsEpvKoFeq6,kR8Wp5NO9hcEvIQ1F4PM,LqVctwEz2x=b8Qe150xVaJsnDSv,ZUPyYNpfLTgIFG4rW38So1kqzRE7du=True):
	if not kR8Wp5NO9hcEvIQ1F4PM: kR8Wp5NO9hcEvIQ1F4PM = '1'
	xSMdp4WX7LK1PEN9eJ0R3UThnVsvm = i4lR3ISvhqJFGBwcrNtCY2mAZu9
	if not yyq2ZDzu5wSeCKA84pxf7PRWTOrBtY(rA1p4eTdbhi69sotZkuP0QafYNDn,ZUPyYNpfLTgIFG4rW38So1kqzRE7du): return False
	if '__SERIES__' in YH8SsEpvKoFeq6: ohTwWFjOuCrbXfdA2V,idzxVTYq67jc = YH8SsEpvKoFeq6.split('__SERIES__')
	else: ohTwWFjOuCrbXfdA2V,idzxVTYq67jc = YH8SsEpvKoFeq6,b8Qe150xVaJsnDSv
	AGBKp17l0b6VURQ = uwgvq5oDNAdsfCPEcYy7HFRBWrkmj6(rA1p4eTdbhi69sotZkuP0QafYNDn,BxP4plOuSfmjn8Xd51sUVgrqy)
	EEJgnkcl2yUrfRPC6VouTh1 = SS2OK7hjLagvUAm(AGBKp17l0b6VURQ,'list',BxP4plOuSfmjn8Xd51sUVgrqy,'__GROUPS__')
	if not EEJgnkcl2yUrfRPC6VouTh1: return False
	iqY5gf03XcF = []
	for LDRy15Hwv72mVgartIBWU,PVvXoB0pye37Sckg45QNDGlw62FjE in EEJgnkcl2yUrfRPC6VouTh1:
		if '===== ===== =====' in LDRy15Hwv72mVgartIBWU:
			MQtuaShrKTbdZFJ5nsR7D('link',xSMdp4WX7LK1PEN9eJ0R3UThnVsvm+LDRy15Hwv72mVgartIBWU,b8Qe150xVaJsnDSv,9999)
			MQtuaShrKTbdZFJ5nsR7D('link',xSMdp4WX7LK1PEN9eJ0R3UThnVsvm+LDRy15Hwv72mVgartIBWU,b8Qe150xVaJsnDSv,9999)
			continue
		if LqVctwEz2x:
			if '__SERIES__' in LDRy15Hwv72mVgartIBWU: xSMdp4WX7LK1PEN9eJ0R3UThnVsvm = 'SERIES'
			elif '!!__UNKNOWN__!!' in LDRy15Hwv72mVgartIBWU: xSMdp4WX7LK1PEN9eJ0R3UThnVsvm = 'UNKNOWN'
			elif 'LIVE' in BxP4plOuSfmjn8Xd51sUVgrqy: xSMdp4WX7LK1PEN9eJ0R3UThnVsvm = 'LIVE'
			else: xSMdp4WX7LK1PEN9eJ0R3UThnVsvm = 'VIDEOS'
			xSMdp4WX7LK1PEN9eJ0R3UThnVsvm = ','+rC3Tlno96KjLDIvBaSWUbR8+xSMdp4WX7LK1PEN9eJ0R3UThnVsvm+': '+hAIp8kmC36T5WFPMSXOwnNbtD
		if '__SERIES__' in LDRy15Hwv72mVgartIBWU: r23ClajcOPNvbi1,JJFHTRzPNhAsnZOa0WMwpuxylvr6 = LDRy15Hwv72mVgartIBWU.split('__SERIES__')
		else: r23ClajcOPNvbi1,JJFHTRzPNhAsnZOa0WMwpuxylvr6 = LDRy15Hwv72mVgartIBWU,b8Qe150xVaJsnDSv
		if not YH8SsEpvKoFeq6:
			if r23ClajcOPNvbi1 in iqY5gf03XcF: continue
			iqY5gf03XcF.append(r23ClajcOPNvbi1)
			if 'RANDOM' in LqVctwEz2x: MQtuaShrKTbdZFJ5nsR7D('folder',xSMdp4WX7LK1PEN9eJ0R3UThnVsvm+r23ClajcOPNvbi1,BxP4plOuSfmjn8Xd51sUVgrqy,168,b8Qe150xVaJsnDSv,'1',LDRy15Hwv72mVgartIBWU,b8Qe150xVaJsnDSv,{'folder':rA1p4eTdbhi69sotZkuP0QafYNDn})
			elif '__SERIES__' in LDRy15Hwv72mVgartIBWU: MQtuaShrKTbdZFJ5nsR7D('folder',xSMdp4WX7LK1PEN9eJ0R3UThnVsvm+r23ClajcOPNvbi1,BxP4plOuSfmjn8Xd51sUVgrqy,713,b8Qe150xVaJsnDSv,'1',LDRy15Hwv72mVgartIBWU,b8Qe150xVaJsnDSv,{'folder':rA1p4eTdbhi69sotZkuP0QafYNDn})
			else: MQtuaShrKTbdZFJ5nsR7D('folder',xSMdp4WX7LK1PEN9eJ0R3UThnVsvm+r23ClajcOPNvbi1,BxP4plOuSfmjn8Xd51sUVgrqy,714,b8Qe150xVaJsnDSv,'1',LDRy15Hwv72mVgartIBWU,b8Qe150xVaJsnDSv,{'folder':rA1p4eTdbhi69sotZkuP0QafYNDn})
		elif '__SERIES__' in LDRy15Hwv72mVgartIBWU and r23ClajcOPNvbi1==ohTwWFjOuCrbXfdA2V:
			if JJFHTRzPNhAsnZOa0WMwpuxylvr6 in iqY5gf03XcF: continue
			iqY5gf03XcF.append(JJFHTRzPNhAsnZOa0WMwpuxylvr6)
			if 'RANDOM' in LqVctwEz2x: MQtuaShrKTbdZFJ5nsR7D('folder',xSMdp4WX7LK1PEN9eJ0R3UThnVsvm+JJFHTRzPNhAsnZOa0WMwpuxylvr6,BxP4plOuSfmjn8Xd51sUVgrqy,168,b8Qe150xVaJsnDSv,'1',LDRy15Hwv72mVgartIBWU,b8Qe150xVaJsnDSv,{'folder':rA1p4eTdbhi69sotZkuP0QafYNDn})
			else: MQtuaShrKTbdZFJ5nsR7D('folder',xSMdp4WX7LK1PEN9eJ0R3UThnVsvm+JJFHTRzPNhAsnZOa0WMwpuxylvr6,BxP4plOuSfmjn8Xd51sUVgrqy,714,PVvXoB0pye37Sckg45QNDGlw62FjE,'1',LDRy15Hwv72mVgartIBWU,b8Qe150xVaJsnDSv,{'folder':rA1p4eTdbhi69sotZkuP0QafYNDn})
	GyjmfosC59Jub[:] = sorted(GyjmfosC59Jub,reverse=False,key=lambda w2wJmSDK8fitdLVAaMRpNEPGc0g: w2wJmSDK8fitdLVAaMRpNEPGc0g[1].lower())
	if not LqVctwEz2x:
		kkNZlMWQrJg5OX4c = int(kR8Wp5NO9hcEvIQ1F4PM)*100
		rryAORupGNEvU2Z9CLz6QMfcWY = kkNZlMWQrJg5OX4c-100
		rxZjzaTRFS5 = len(GyjmfosC59Jub)
		GyjmfosC59Jub[:] = GyjmfosC59Jub[rryAORupGNEvU2Z9CLz6QMfcWY:kkNZlMWQrJg5OX4c]
		ZCkrKgME82qhdlIzND1oSQH(rA1p4eTdbhi69sotZkuP0QafYNDn,kR8Wp5NO9hcEvIQ1F4PM,BxP4plOuSfmjn8Xd51sUVgrqy,713,rxZjzaTRFS5,YH8SsEpvKoFeq6)
	return True
def ddBQqIfREpXoaGN9MH(rA1p4eTdbhi69sotZkuP0QafYNDn,uuNDjbit4hOpx,hOMFodkaU91iDuIAw):
	if not yyq2ZDzu5wSeCKA84pxf7PRWTOrBtY(rA1p4eTdbhi69sotZkuP0QafYNDn,True): return
	NNB43WbKMVnrktmcsZXUR6wvfJq = F04FsYgKcE(rA1p4eTdbhi69sotZkuP0QafYNDn)
	XkwLHgZdc0hEN1COVnjSPqG2vF = hRWC8YSFvsm4JHOMVIne3jquZ.getSetting('av.m3u.timestamp_'+rA1p4eTdbhi69sotZkuP0QafYNDn)
	if not XkwLHgZdc0hEN1COVnjSPqG2vF or T3Axql94cU0BpO1wudEDtWXsf-int(XkwLHgZdc0hEN1COVnjSPqG2vF)>24*n4GUoTyqdKik9VSLE3W5pt8zJlug:
		LhFtNIEfT6WHVi50bMYvRmCzro9A,dgJF1846SsPuVEexvaLnQp7rHOU,kSorHcEWFs503dwvDblhOyJ6T9f = tNH3wo1W7TPhV9Lx6Y4MFckGn5(rA1p4eTdbhi69sotZkuP0QafYNDn,False)
		if not LhFtNIEfT6WHVi50bMYvRmCzro9A: return
	yB7a90zc6Hbj = int(hRWC8YSFvsm4JHOMVIne3jquZ.getSetting('av.m3u.timediff_'+rA1p4eTdbhi69sotZkuP0QafYNDn))
	DLyvH8FaW2VOJXIsqMR9gYEKB6C = hRWC8YSFvsm4JHOMVIne3jquZ.getSetting('av.m3u.server_'+rA1p4eTdbhi69sotZkuP0QafYNDn)
	LdqjiZRmEoPpO30BUMFT4ryHAXG97z = hRWC8YSFvsm4JHOMVIne3jquZ.getSetting('av.m3u.username_'+rA1p4eTdbhi69sotZkuP0QafYNDn)
	WEyfpNCg5zBlewL0rYoj = hRWC8YSFvsm4JHOMVIne3jquZ.getSetting('av.m3u.password_'+rA1p4eTdbhi69sotZkuP0QafYNDn)
	RxyFH1EGUVYBfPnheLNkmt3A2Tl = uuNDjbit4hOpx.split('/')
	CMfTgYhqBNeXltAKUWQHEJcP = RxyFH1EGUVYBfPnheLNkmt3A2Tl[-1].replace('.ts',b8Qe150xVaJsnDSv).replace('.m3u8',b8Qe150xVaJsnDSv)
	if hOMFodkaU91iDuIAw=='SHORT_EPG': GGZ0DiLu2OpsU3jlyzXvINTt = 'get_short_epg'
	else: GGZ0DiLu2OpsU3jlyzXvINTt = 'get_simple_data_table'
	W8XSop4zRMrQIyJxnYsVq6BlA5mLkE,UUGcBS73g1,DLyvH8FaW2VOJXIsqMR9gYEKB6C,LdqjiZRmEoPpO30BUMFT4ryHAXG97z,WEyfpNCg5zBlewL0rYoj = atsVLJ5h3XMgGnoDS8mzCZK92(rA1p4eTdbhi69sotZkuP0QafYNDn)
	if not LdqjiZRmEoPpO30BUMFT4ryHAXG97z: return
	IdmGqbcyzfx = W8XSop4zRMrQIyJxnYsVq6BlA5mLkE+'&action='+GGZ0DiLu2OpsU3jlyzXvINTt+'&stream_id='+CMfTgYhqBNeXltAKUWQHEJcP
	RgtGekOpZJTE4 = yoG67HvnOzdqagmwW(nCUMfrlZvuiLe5x,IdmGqbcyzfx,b8Qe150xVaJsnDSv,NNB43WbKMVnrktmcsZXUR6wvfJq,b8Qe150xVaJsnDSv,'M3U-EPG_ITEMS-2nd')
	mbhOSB0Q3VyT98 = oJsUwXA0yGOI1mTjxQ('dict',RgtGekOpZJTE4)
	FaG01hMBI6f5DHx9iCRsgYZWOl = mbhOSB0Q3VyT98['epg_listings']
	Ye2RdQlpFyqMTEDWVuv7UO4S9ZgxA = []
	if hOMFodkaU91iDuIAw in ['ARCHIVED','TIMESHIFT']:
		for W0sGaMZXq8nrSvj6K2fU in FaG01hMBI6f5DHx9iCRsgYZWOl:
			if W0sGaMZXq8nrSvj6K2fU['has_archive']==1:
				Ye2RdQlpFyqMTEDWVuv7UO4S9ZgxA.append(W0sGaMZXq8nrSvj6K2fU)
				if hOMFodkaU91iDuIAw in ['TIMESHIFT']: break
		if not Ye2RdQlpFyqMTEDWVuv7UO4S9ZgxA: return
		MQtuaShrKTbdZFJ5nsR7D('link',i4lR3ISvhqJFGBwcrNtCY2mAZu9+rC3Tlno96KjLDIvBaSWUbR8+'الملفات الأولي بهذه القائمة قد لا تعمل'+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999)
		if hOMFodkaU91iDuIAw in ['TIMESHIFT']:
			f6naHFtwOgomCV3XASU = 2
			LPKIr7spFz9v = f6naHFtwOgomCV3XASU*n4GUoTyqdKik9VSLE3W5pt8zJlug
			Ye2RdQlpFyqMTEDWVuv7UO4S9ZgxA = []
			ID4JGjyLZXReuYEwT8c = int(int(W0sGaMZXq8nrSvj6K2fU['start_timestamp'])/LPKIr7spFz9v)*LPKIr7spFz9v
			oYFvLkAN3h86HpRf29euTUQml7E = T3Axql94cU0BpO1wudEDtWXsf+LPKIr7spFz9v
			x5yj3hN4tegSXFpKkI9HaTVv6 = int((oYFvLkAN3h86HpRf29euTUQml7E-ID4JGjyLZXReuYEwT8c)/n4GUoTyqdKik9VSLE3W5pt8zJlug)
			for vvKNfzy0VtHxObGpT in range(x5yj3hN4tegSXFpKkI9HaTVv6):
				if vvKNfzy0VtHxObGpT>=6:
					if vvKNfzy0VtHxObGpT%f6naHFtwOgomCV3XASU!=0: continue
					DAtpbZWyz0aS4r3q8HLd1 = LPKIr7spFz9v
				else: DAtpbZWyz0aS4r3q8HLd1 = LPKIr7spFz9v//2
				f1VwE0yWK5iO8GALMHvU7STqetk = ID4JGjyLZXReuYEwT8c+vvKNfzy0VtHxObGpT*n4GUoTyqdKik9VSLE3W5pt8zJlug
				W0sGaMZXq8nrSvj6K2fU = {}
				W0sGaMZXq8nrSvj6K2fU['title'] = b8Qe150xVaJsnDSv
				cIM6kgyVSGaBW = wLQCTr5lqbsVYeAHdzfhZ1F.localtime(f1VwE0yWK5iO8GALMHvU7STqetk-yB7a90zc6Hbj-n4GUoTyqdKik9VSLE3W5pt8zJlug)
				W0sGaMZXq8nrSvj6K2fU['start'] = wLQCTr5lqbsVYeAHdzfhZ1F.strftime('%Y.%m.%d %H:%M:%S',cIM6kgyVSGaBW)
				W0sGaMZXq8nrSvj6K2fU['start_timestamp'] = str(f1VwE0yWK5iO8GALMHvU7STqetk)
				W0sGaMZXq8nrSvj6K2fU['stop_timestamp'] = str(f1VwE0yWK5iO8GALMHvU7STqetk+DAtpbZWyz0aS4r3q8HLd1)
				Ye2RdQlpFyqMTEDWVuv7UO4S9ZgxA.append(W0sGaMZXq8nrSvj6K2fU)
	elif hOMFodkaU91iDuIAw in ['SHORT_EPG','FULL_EPG']: Ye2RdQlpFyqMTEDWVuv7UO4S9ZgxA = FaG01hMBI6f5DHx9iCRsgYZWOl
	if hOMFodkaU91iDuIAw=='FULL_EPG' and len(Ye2RdQlpFyqMTEDWVuv7UO4S9ZgxA)>0:
		MQtuaShrKTbdZFJ5nsR7D('link',i4lR3ISvhqJFGBwcrNtCY2mAZu9+rC3Tlno96KjLDIvBaSWUbR8+'هذه قائمة برامج القنوات (جدول فقط)ـ'+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999)
	P69wfxqmbXBYRO = []
	PVvXoB0pye37Sckg45QNDGlw62FjE = uuxVm0bTwdnCUAL4s6NKHEBF3M.getInfoLabel('ListItem.Icon')
	for W0sGaMZXq8nrSvj6K2fU in Ye2RdQlpFyqMTEDWVuv7UO4S9ZgxA:
		sbat1zOx0HydLjm5qvTPgR = lnFeUkiZtQ7E1.b64decode(W0sGaMZXq8nrSvj6K2fU['title'])
		if i1thmHk7AZquD4cM0fnp62: sbat1zOx0HydLjm5qvTPgR = sbat1zOx0HydLjm5qvTPgR.decode(OVauxZzLI10vcXT74K)
		f1VwE0yWK5iO8GALMHvU7STqetk = int(W0sGaMZXq8nrSvj6K2fU['start_timestamp'])
		Ain9DKEFbW1v = int(W0sGaMZXq8nrSvj6K2fU['stop_timestamp'])
		O0eBaWmfbI = str(int((Ain9DKEFbW1v-f1VwE0yWK5iO8GALMHvU7STqetk+59)/60))
		JJWjLYruxtmcqDksi = W0sGaMZXq8nrSvj6K2fU['start'].replace(pldxivXC5wbTB2O8q,':')
		cIM6kgyVSGaBW = wLQCTr5lqbsVYeAHdzfhZ1F.localtime(f1VwE0yWK5iO8GALMHvU7STqetk-n4GUoTyqdKik9VSLE3W5pt8zJlug)
		Bp3DlLWHXRx9EoJ1 = wLQCTr5lqbsVYeAHdzfhZ1F.strftime('%H:%M',cIM6kgyVSGaBW)
		v891RMucpOnA2of64W = wLQCTr5lqbsVYeAHdzfhZ1F.strftime('%a',cIM6kgyVSGaBW)
		if hOMFodkaU91iDuIAw=='SHORT_EPG': sbat1zOx0HydLjm5qvTPgR = OkuB9nwhD8U1+Bp3DlLWHXRx9EoJ1+' ـ '+sbat1zOx0HydLjm5qvTPgR+hAIp8kmC36T5WFPMSXOwnNbtD
		elif hOMFodkaU91iDuIAw=='TIMESHIFT': sbat1zOx0HydLjm5qvTPgR = v891RMucpOnA2of64W+pldxivXC5wbTB2O8q+Bp3DlLWHXRx9EoJ1+' ('+O0eBaWmfbI+'min)'
		else: sbat1zOx0HydLjm5qvTPgR = v891RMucpOnA2of64W+pldxivXC5wbTB2O8q+Bp3DlLWHXRx9EoJ1+' ('+O0eBaWmfbI+'min)   '+sbat1zOx0HydLjm5qvTPgR+' ـ'
		if hOMFodkaU91iDuIAw in ['ARCHIVED','FULL_EPG','TIMESHIFT']:
			ddqTgWUa3bG = DLyvH8FaW2VOJXIsqMR9gYEKB6C+'/timeshift/'+LdqjiZRmEoPpO30BUMFT4ryHAXG97z+'/'+WEyfpNCg5zBlewL0rYoj+'/'+O0eBaWmfbI+'/'+JJWjLYruxtmcqDksi+'/'+CMfTgYhqBNeXltAKUWQHEJcP+'.m3u8'
			if hOMFodkaU91iDuIAw=='FULL_EPG': MQtuaShrKTbdZFJ5nsR7D('link',i4lR3ISvhqJFGBwcrNtCY2mAZu9+sbat1zOx0HydLjm5qvTPgR,ddqTgWUa3bG,9999,PVvXoB0pye37Sckg45QNDGlw62FjE,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,{'folder':rA1p4eTdbhi69sotZkuP0QafYNDn})
			else: MQtuaShrKTbdZFJ5nsR7D('video',i4lR3ISvhqJFGBwcrNtCY2mAZu9+sbat1zOx0HydLjm5qvTPgR,ddqTgWUa3bG,715,PVvXoB0pye37Sckg45QNDGlw62FjE,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,{'folder':rA1p4eTdbhi69sotZkuP0QafYNDn})
		P69wfxqmbXBYRO.append(sbat1zOx0HydLjm5qvTPgR)
	if hOMFodkaU91iDuIAw=='SHORT_EPG' and P69wfxqmbXBYRO: QQMjXBl6m5N2wzVvuAgZ9iq = m1pyo0fC2w8jr7xY5LcgV(P69wfxqmbXBYRO)
	return P69wfxqmbXBYRO
def MFWl3wdPecfkxDXS2OK(rA1p4eTdbhi69sotZkuP0QafYNDn):
	if not yyq2ZDzu5wSeCKA84pxf7PRWTOrBtY(rA1p4eTdbhi69sotZkuP0QafYNDn,True): return
	DLyvH8FaW2VOJXIsqMR9gYEKB6C,hCXxGNFeYokPu1HMim,JKnuDrNFY5e1Eq = b8Qe150xVaJsnDSv,0,0
	LhFtNIEfT6WHVi50bMYvRmCzro9A,dgJF1846SsPuVEexvaLnQp7rHOU,kSorHcEWFs503dwvDblhOyJ6T9f = tNH3wo1W7TPhV9Lx6Y4MFckGn5(rA1p4eTdbhi69sotZkuP0QafYNDn,False)
	if LhFtNIEfT6WHVi50bMYvRmCzro9A:
		PmztV8pnNAZKRGhx91oEvi7eWX3 = ppyKRhnr3doQ9P5HlMTSCveNu1(dgJF1846SsPuVEexvaLnQp7rHOU)
		hCXxGNFeYokPu1HMim = LZQYdBUN2FKbj5cgP9zJfx0VE(PmztV8pnNAZKRGhx91oEvi7eWX3[0],int(kSorHcEWFs503dwvDblhOyJ6T9f))
		AGBKp17l0b6VURQ = uwgvq5oDNAdsfCPEcYy7HFRBWrkmj6(rA1p4eTdbhi69sotZkuP0QafYNDn,'LIVE_GROUPED')
		P9MuDKe5WdAkqQTEJ8mU7 = SS2OK7hjLagvUAm(AGBKp17l0b6VURQ,'list','LIVE_GROUPED')
		xehYsVJtBRz = SS2OK7hjLagvUAm(AGBKp17l0b6VURQ,'list','LIVE_GROUPED',P9MuDKe5WdAkqQTEJ8mU7[1])
		uuNDjbit4hOpx = xehYsVJtBRz[0][2]
		OqnZ4t3wJmuCl = YYBlm36zd0Jst18LXwo4.findall('://(.*?)/',uuNDjbit4hOpx,YYBlm36zd0Jst18LXwo4.DOTALL)
		OqnZ4t3wJmuCl = OqnZ4t3wJmuCl[0]
		if ':' in OqnZ4t3wJmuCl: QksWoPtrg3Lq8l,jrRW27ANb0MGCZ6QuPIBc = OqnZ4t3wJmuCl.split(':')
		else: QksWoPtrg3Lq8l,jrRW27ANb0MGCZ6QuPIBc = OqnZ4t3wJmuCl,'80'
		xiZGmgEzlyvR2u = ppyKRhnr3doQ9P5HlMTSCveNu1(QksWoPtrg3Lq8l)
		JKnuDrNFY5e1Eq = LZQYdBUN2FKbj5cgP9zJfx0VE(xiZGmgEzlyvR2u[0],int(jrRW27ANb0MGCZ6QuPIBc))
	if hCXxGNFeYokPu1HMim and JKnuDrNFY5e1Eq:
		A4gdSTQDP2FyBIVuba85RvYqKU = 'هل تريد استخدام السيرفر الأصلي أم السيرفر الأسرع ؟!!'
		A4gdSTQDP2FyBIVuba85RvYqKU += '\n\n'+'وقت ضائع في السيرفر الأصلي'+eeN6dTEnkJxI+str(int(JKnuDrNFY5e1Eq*1000))+' ملي ثانية'
		A4gdSTQDP2FyBIVuba85RvYqKU += '\n\n'+'وقت ضائع في السيرفر البديل'+eeN6dTEnkJxI+str(int(hCXxGNFeYokPu1HMim*1000))+' ملي ثانية'
		Dltpz9hNv72iZFQPE158U = BjMmX1vNrnzSAf('center','السيرفر الأصلي','السيرفر الأسرع','رسالة من المبرمج',A4gdSTQDP2FyBIVuba85RvYqKU)
		if Dltpz9hNv72iZFQPE158U==1 and hCXxGNFeYokPu1HMim<JKnuDrNFY5e1Eq: DLyvH8FaW2VOJXIsqMR9gYEKB6C = dgJF1846SsPuVEexvaLnQp7rHOU+':'+kSorHcEWFs503dwvDblhOyJ6T9f
	else: tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'رسالة من المبرمج','البرنامج لم يجد السيرفر البديل')
	hRWC8YSFvsm4JHOMVIne3jquZ.setSetting('av.m3u.server_'+rA1p4eTdbhi69sotZkuP0QafYNDn,DLyvH8FaW2VOJXIsqMR9gYEKB6C)
	return
def Hkij627uCDJKyIM(rA1p4eTdbhi69sotZkuP0QafYNDn,uuNDjbit4hOpx,A60AIQZCYRzdhaeWfOtmrSUVoq2nN):
	O4NjAwLMCfqEYl30yiUd9mgH = hRWC8YSFvsm4JHOMVIne3jquZ.getSetting('av.m3u.useragent_'+rA1p4eTdbhi69sotZkuP0QafYNDn)
	x4xQjnNYV1XfFgU7hzkq9v5K = hRWC8YSFvsm4JHOMVIne3jquZ.getSetting('av.m3u.referer_'+rA1p4eTdbhi69sotZkuP0QafYNDn)
	if O4NjAwLMCfqEYl30yiUd9mgH or x4xQjnNYV1XfFgU7hzkq9v5K:
		uuNDjbit4hOpx += '|'
		if O4NjAwLMCfqEYl30yiUd9mgH: uuNDjbit4hOpx += '&User-Agent='+O4NjAwLMCfqEYl30yiUd9mgH
		if x4xQjnNYV1XfFgU7hzkq9v5K: uuNDjbit4hOpx += '&Referer='+x4xQjnNYV1XfFgU7hzkq9v5K
		uuNDjbit4hOpx = uuNDjbit4hOpx.replace('|&','|')
	yulQjIFbzM(uuNDjbit4hOpx,ALwGbyiBFzY7H,A60AIQZCYRzdhaeWfOtmrSUVoq2nN)
	return
def FgSuBI8CoaVeh(rA1p4eTdbhi69sotZkuP0QafYNDn):
	tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'رسالة من المبرمج','تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـM3U أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـM3U تحتاج ـUser-Agent خاص')
	O4NjAwLMCfqEYl30yiUd9mgH = hRWC8YSFvsm4JHOMVIne3jquZ.getSetting('av.m3u.useragent_'+rA1p4eTdbhi69sotZkuP0QafYNDn)
	WnGS0uHyegjYDkJ6Ma8qKti = BjMmX1vNrnzSAf('center','استخدام الأصلي','تعديل القديم',O4NjAwLMCfqEYl30yiUd9mgH,'هذا هو ـUser-Agent المستخدم حاليا مع ـM3U الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـM3U ؟!')
	if WnGS0uHyegjYDkJ6Ma8qKti==1: O4NjAwLMCfqEYl30yiUd9mgH = FT2oXWtPQpVGuexmLqKN3srdzYn('أكتب ـM3U User-Agent جديد',O4NjAwLMCfqEYl30yiUd9mgH,True)
	else: O4NjAwLMCfqEYl30yiUd9mgH = 'Unknown'
	if O4NjAwLMCfqEYl30yiUd9mgH==pldxivXC5wbTB2O8q:
		tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'رسالة من المبرمج','غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	WnGS0uHyegjYDkJ6Ma8qKti = BjMmX1vNrnzSAf('center',b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,O4NjAwLMCfqEYl30yiUd9mgH,'هل تريد استخدام هذا ـUser-Agent بدلا من  القديم ؟')
	if WnGS0uHyegjYDkJ6Ma8qKti!=1:
		tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'رسالة من المبرمج','تم الإلغاء')
		return
	hRWC8YSFvsm4JHOMVIne3jquZ.setSetting('av.m3u.useragent_'+rA1p4eTdbhi69sotZkuP0QafYNDn,O4NjAwLMCfqEYl30yiUd9mgH)
	WIiopcT2R9PdLt7VExswk0HmnYZe5(rA1p4eTdbhi69sotZkuP0QafYNDn)
	return
def DDjSzaYGWuJw(rA1p4eTdbhi69sotZkuP0QafYNDn):
	tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'رسالة من المبرمج','تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـM3U أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـM3U تحتاج ـReferer خاص')
	x4xQjnNYV1XfFgU7hzkq9v5K = hRWC8YSFvsm4JHOMVIne3jquZ.getSetting('av.m3u.referer_'+rA1p4eTdbhi69sotZkuP0QafYNDn)
	WnGS0uHyegjYDkJ6Ma8qKti = BjMmX1vNrnzSAf('center','استخدام الأصلي','تعديل القديم',x4xQjnNYV1XfFgU7hzkq9v5K,'هذا هو ـReferer المستخدم حاليا مع ـM3U الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـM3U ؟!')
	if WnGS0uHyegjYDkJ6Ma8qKti==1: x4xQjnNYV1XfFgU7hzkq9v5K = FT2oXWtPQpVGuexmLqKN3srdzYn('أكتب ـM3U Referer جديد',x4xQjnNYV1XfFgU7hzkq9v5K,True)
	else: x4xQjnNYV1XfFgU7hzkq9v5K = b8Qe150xVaJsnDSv
	if x4xQjnNYV1XfFgU7hzkq9v5K==pldxivXC5wbTB2O8q:
		tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'رسالة من المبرمج','غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	WnGS0uHyegjYDkJ6Ma8qKti = BjMmX1vNrnzSAf('center',b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,x4xQjnNYV1XfFgU7hzkq9v5K,'هل تريد استخدام هذا ـReferer بدلا من  القديم ؟')
	if WnGS0uHyegjYDkJ6Ma8qKti!=1:
		tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'رسالة من المبرمج','تم الإلغاء')
		return
	hRWC8YSFvsm4JHOMVIne3jquZ.setSetting('av.m3u.referer_'+rA1p4eTdbhi69sotZkuP0QafYNDn,x4xQjnNYV1XfFgU7hzkq9v5K)
	WIiopcT2R9PdLt7VExswk0HmnYZe5(rA1p4eTdbhi69sotZkuP0QafYNDn)
	return
def atsVLJ5h3XMgGnoDS8mzCZK92(rA1p4eTdbhi69sotZkuP0QafYNDn,HLA0hbCwkXc=b8Qe150xVaJsnDSv):
	if not SQO2oHF5c6AD9pYs4rxITEUk7PCW: SQO2oHF5c6AD9pYs4rxITEUk7PCW = hRWC8YSFvsm4JHOMVIne3jquZ.getSetting('av.m3u.url_'+rA1p4eTdbhi69sotZkuP0QafYNDn)
	DLyvH8FaW2VOJXIsqMR9gYEKB6C = Wl2eu1PavfQ(SQO2oHF5c6AD9pYs4rxITEUk7PCW,'url')
	LdqjiZRmEoPpO30BUMFT4ryHAXG97z = YYBlm36zd0Jst18LXwo4.findall('username=(.*?)&',SQO2oHF5c6AD9pYs4rxITEUk7PCW+'&',YYBlm36zd0Jst18LXwo4.DOTALL)
	WEyfpNCg5zBlewL0rYoj = YYBlm36zd0Jst18LXwo4.findall('password=(.*?)&',SQO2oHF5c6AD9pYs4rxITEUk7PCW+'&',YYBlm36zd0Jst18LXwo4.DOTALL)
	if not LdqjiZRmEoPpO30BUMFT4ryHAXG97z or not WEyfpNCg5zBlewL0rYoj:
		tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'فحص اشتراك M3U','رابط اشتراك ـM3U الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـM3U وقم بإضافة رابط ـM3U جديد أو قم بإصلاح الرابط القديم')
		return b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv
	LdqjiZRmEoPpO30BUMFT4ryHAXG97z = LdqjiZRmEoPpO30BUMFT4ryHAXG97z[0]
	WEyfpNCg5zBlewL0rYoj = WEyfpNCg5zBlewL0rYoj[0]
	W8XSop4zRMrQIyJxnYsVq6BlA5mLkE = DLyvH8FaW2VOJXIsqMR9gYEKB6C+'/player_api.php?username='+LdqjiZRmEoPpO30BUMFT4ryHAXG97z+'&password='+WEyfpNCg5zBlewL0rYoj
	UUGcBS73g1 = DLyvH8FaW2VOJXIsqMR9gYEKB6C+'/get.php?username='+LdqjiZRmEoPpO30BUMFT4ryHAXG97z+'&password='+WEyfpNCg5zBlewL0rYoj+'&type=m3u_plus'
	return W8XSop4zRMrQIyJxnYsVq6BlA5mLkE,UUGcBS73g1,DLyvH8FaW2VOJXIsqMR9gYEKB6C,LdqjiZRmEoPpO30BUMFT4ryHAXG97z,WEyfpNCg5zBlewL0rYoj
def tInU8Me6W1(rA1p4eTdbhi69sotZkuP0QafYNDn,VLIC9xSDcTOHnm2qwd3F4t=b8Qe150xVaJsnDSv):
	BpLjE4kVDZovfuS5mI817cAtb = VLIC9xSDcTOHnm2qwd3F4t.replace('/','_').replace(':','_').replace('.','_')
	BpLjE4kVDZovfuS5mI817cAtb = BpLjE4kVDZovfuS5mI817cAtb.replace('?','_').replace('=','_').replace('&','_')
	BpLjE4kVDZovfuS5mI817cAtb = x76PfMyAp1L2WejkU3.path.join(vIaQF8hqXeiJERYuD,BpLjE4kVDZovfuS5mI817cAtb).strip('.m3u')+'.m3u'
	return BpLjE4kVDZovfuS5mI817cAtb
def NGe8Whf2qj5isU3cJaYd1wXx(rA1p4eTdbhi69sotZkuP0QafYNDn,KHiQ5Z6kBVYoPjUsa):
	LNaJCFTSOjr7gzo = hRWC8YSFvsm4JHOMVIne3jquZ.getSetting('av.m3u.url_'+rA1p4eTdbhi69sotZkuP0QafYNDn+'_'+KHiQ5Z6kBVYoPjUsa)
	zz0mZ6A1Lu8q = True
	if LNaJCFTSOjr7gzo:
		WnGS0uHyegjYDkJ6Ma8qKti = QlaM6yHe0bgh58Vx3BAZD('center','كتابة جديد','تعديل القديم','مسح القديم','الرابط الحالي هو:',rC3Tlno96KjLDIvBaSWUbR8+LNaJCFTSOjr7gzo+hAIp8kmC36T5WFPMSXOwnNbtD+'\n\n هذا هو رابط M3U المسجل في البرنامج .. هل تريد تعديله أم تريد كتابة رابط جديد ؟!')
		if WnGS0uHyegjYDkJ6Ma8qKti==-1: return
		elif WnGS0uHyegjYDkJ6Ma8qKti==0: LNaJCFTSOjr7gzo = b8Qe150xVaJsnDSv
		elif WnGS0uHyegjYDkJ6Ma8qKti==2:
			WnGS0uHyegjYDkJ6Ma8qKti = BjMmX1vNrnzSAf('center',b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'رسالة من المبرمج','هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if WnGS0uHyegjYDkJ6Ma8qKti in [-1,0]: return
			tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'رسالة من المبرمج','تم مسح الرابط')
			zz0mZ6A1Lu8q = False
			y6UjiEQ9vdaJc3NT2u = b8Qe150xVaJsnDSv
	if zz0mZ6A1Lu8q:
		y6UjiEQ9vdaJc3NT2u = FT2oXWtPQpVGuexmLqKN3srdzYn('اكتب رابط M3U كاملا',LNaJCFTSOjr7gzo)
		y6UjiEQ9vdaJc3NT2u = y6UjiEQ9vdaJc3NT2u.strip(pldxivXC5wbTB2O8q)
		if not y6UjiEQ9vdaJc3NT2u:
			WnGS0uHyegjYDkJ6Ma8qKti = BjMmX1vNrnzSAf('center',b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'رسالة من المبرمج','لقد قمت بإدخال رابط فارغ .. هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if WnGS0uHyegjYDkJ6Ma8qKti in [-1,0]: return
			tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'رسالة من المبرمج','تم مسح الرابط')
		else:
			A4gdSTQDP2FyBIVuba85RvYqKU = 'هذه المعلومات تم أخذها من رابط ـM3U الذي انت كتبته . هل تريد استخدامها ؟!\n'
			WnGS0uHyegjYDkJ6Ma8qKti = BjMmX1vNrnzSAf(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'الرابط الجديد هو:',rC3Tlno96KjLDIvBaSWUbR8+y6UjiEQ9vdaJc3NT2u+hAIp8kmC36T5WFPMSXOwnNbtD+'\n\n'+A4gdSTQDP2FyBIVuba85RvYqKU)
			if WnGS0uHyegjYDkJ6Ma8qKti!=1:
				tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'رسالة من المبرمج','تم الإلغاء')
				return
	hRWC8YSFvsm4JHOMVIne3jquZ.setSetting('av.m3u.url_'+rA1p4eTdbhi69sotZkuP0QafYNDn+'_'+KHiQ5Z6kBVYoPjUsa,y6UjiEQ9vdaJc3NT2u)
	O4NjAwLMCfqEYl30yiUd9mgH = hRWC8YSFvsm4JHOMVIne3jquZ.getSetting('av.m3u.useragent_'+rA1p4eTdbhi69sotZkuP0QafYNDn)
	if not O4NjAwLMCfqEYl30yiUd9mgH: hRWC8YSFvsm4JHOMVIne3jquZ.setSetting('av.m3u.useragent_'+rA1p4eTdbhi69sotZkuP0QafYNDn,'Unknown')
	WIiopcT2R9PdLt7VExswk0HmnYZe5(rA1p4eTdbhi69sotZkuP0QafYNDn)
	return
def iYbAhL3GjzoZmc0PBu(bbRcgP2UL3pV7IkSdWJ1OZm6AvYXw,SDCyhZx6WK0rEA1XUeQMVbk9Piv,q2qH6xOspywVYcB5uLrhnm,cmvIRA5eW2OiZQdyw4VX,lyJOSdVDRvqGHnBxPU,LLsyevc6KqA4QG,UUGcBS73g1):
	xehYsVJtBRz,eyo3Gtb5XC2DhWYqsakw = [],[]
	g6E79JZIsS5A = ['.avi','.mp4','.mkv','.mp3','.webm','.aac']
	for XcB7EqbZMOW9RuYnD62V4F3jrhvp in bbRcgP2UL3pV7IkSdWJ1OZm6AvYXw:
		if LLsyevc6KqA4QG%473==0:
			NrM3XJ8sD2pEHz(cmvIRA5eW2OiZQdyw4VX,40+int(10*LLsyevc6KqA4QG/lyJOSdVDRvqGHnBxPU),'قراءة الفيديوهات','الفيديو رقم:-',str(LLsyevc6KqA4QG)+' / '+str(lyJOSdVDRvqGHnBxPU))
			if cmvIRA5eW2OiZQdyw4VX.iscanceled():
				cmvIRA5eW2OiZQdyw4VX.close()
				return None,None,None
		uuNDjbit4hOpx = YYBlm36zd0Jst18LXwo4.findall('^(.*?)\n+((http|https|rtmp).*?)$',XcB7EqbZMOW9RuYnD62V4F3jrhvp,YYBlm36zd0Jst18LXwo4.DOTALL)
		if uuNDjbit4hOpx:
			XcB7EqbZMOW9RuYnD62V4F3jrhvp,uuNDjbit4hOpx,qipmn9G8hQf74UsRD = uuNDjbit4hOpx[0]
			uuNDjbit4hOpx = uuNDjbit4hOpx.replace(eeN6dTEnkJxI,b8Qe150xVaJsnDSv)
			XcB7EqbZMOW9RuYnD62V4F3jrhvp = XcB7EqbZMOW9RuYnD62V4F3jrhvp.replace(eeN6dTEnkJxI,b8Qe150xVaJsnDSv)
		else:
			eyo3Gtb5XC2DhWYqsakw.append({'line':XcB7EqbZMOW9RuYnD62V4F3jrhvp})
			continue
		MlUKDx4pvThGN,czG0PxAmlw4vtWrH5eL3RubT,LDRy15Hwv72mVgartIBWU,sbat1zOx0HydLjm5qvTPgR,A60AIQZCYRzdhaeWfOtmrSUVoq2nN,g6ylacBYiUs9PKT = {},b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,False
		try:
			XcB7EqbZMOW9RuYnD62V4F3jrhvp,sbat1zOx0HydLjm5qvTPgR = XcB7EqbZMOW9RuYnD62V4F3jrhvp.rsplit('",',1)
			XcB7EqbZMOW9RuYnD62V4F3jrhvp = XcB7EqbZMOW9RuYnD62V4F3jrhvp+'"'
		except:
			try: XcB7EqbZMOW9RuYnD62V4F3jrhvp,sbat1zOx0HydLjm5qvTPgR = XcB7EqbZMOW9RuYnD62V4F3jrhvp.rsplit('1,',1)
			except: sbat1zOx0HydLjm5qvTPgR = b8Qe150xVaJsnDSv
		MlUKDx4pvThGN['url'] = uuNDjbit4hOpx
		nPTLVDasAfKyiOJmvpkSBeq6dlIt = YYBlm36zd0Jst18LXwo4.findall(' (.*?)="(.*?)"',XcB7EqbZMOW9RuYnD62V4F3jrhvp,YYBlm36zd0Jst18LXwo4.DOTALL)
		for w2wJmSDK8fitdLVAaMRpNEPGc0g,vB1tbwXDzUanu in nPTLVDasAfKyiOJmvpkSBeq6dlIt:
			w2wJmSDK8fitdLVAaMRpNEPGc0g = w2wJmSDK8fitdLVAaMRpNEPGc0g.replace('"',b8Qe150xVaJsnDSv).strip(pldxivXC5wbTB2O8q)
			MlUKDx4pvThGN[w2wJmSDK8fitdLVAaMRpNEPGc0g] = vB1tbwXDzUanu.strip(pldxivXC5wbTB2O8q)
		YMHq4aCwhb = list(MlUKDx4pvThGN.keys())
		if not sbat1zOx0HydLjm5qvTPgR:
			if 'name' in YMHq4aCwhb and MlUKDx4pvThGN['name']: sbat1zOx0HydLjm5qvTPgR = MlUKDx4pvThGN['name']
		MlUKDx4pvThGN['title'] = sbat1zOx0HydLjm5qvTPgR.strip(pldxivXC5wbTB2O8q).replace(k5bCDErUSmv,pldxivXC5wbTB2O8q).replace(k5bCDErUSmv,pldxivXC5wbTB2O8q)
		if 'logo' in YMHq4aCwhb:
			MlUKDx4pvThGN['img'] = MlUKDx4pvThGN['logo']
			del MlUKDx4pvThGN['logo']
		else: MlUKDx4pvThGN['img'] = b8Qe150xVaJsnDSv
		if 'group' in YMHq4aCwhb and MlUKDx4pvThGN['group']: LDRy15Hwv72mVgartIBWU = MlUKDx4pvThGN['group']
		if any(Y8aiFZsLKw in uuNDjbit4hOpx.lower() for Y8aiFZsLKw in g6E79JZIsS5A):
			g6ylacBYiUs9PKT = True if 'm3u' not in uuNDjbit4hOpx else False
		if g6ylacBYiUs9PKT or '__SERIES__' in LDRy15Hwv72mVgartIBWU or '__MOVIES__' in LDRy15Hwv72mVgartIBWU:
			A60AIQZCYRzdhaeWfOtmrSUVoq2nN = 'VOD'
			if '__SERIES__' in LDRy15Hwv72mVgartIBWU: A60AIQZCYRzdhaeWfOtmrSUVoq2nN = A60AIQZCYRzdhaeWfOtmrSUVoq2nN+'_SERIES'
			elif '__MOVIES__' in LDRy15Hwv72mVgartIBWU: A60AIQZCYRzdhaeWfOtmrSUVoq2nN = A60AIQZCYRzdhaeWfOtmrSUVoq2nN+'_MOVIES'
			else: A60AIQZCYRzdhaeWfOtmrSUVoq2nN = A60AIQZCYRzdhaeWfOtmrSUVoq2nN+'_UNKNOWN'
			LDRy15Hwv72mVgartIBWU = LDRy15Hwv72mVgartIBWU.replace('__SERIES__',b8Qe150xVaJsnDSv).replace('__MOVIES__',b8Qe150xVaJsnDSv)
		else:
			A60AIQZCYRzdhaeWfOtmrSUVoq2nN = 'LIVE'
			if sbat1zOx0HydLjm5qvTPgR in SDCyhZx6WK0rEA1XUeQMVbk9Piv: czG0PxAmlw4vtWrH5eL3RubT = czG0PxAmlw4vtWrH5eL3RubT+'_EPG'
			if sbat1zOx0HydLjm5qvTPgR in q2qH6xOspywVYcB5uLrhnm: czG0PxAmlw4vtWrH5eL3RubT = czG0PxAmlw4vtWrH5eL3RubT+'_ARCHIVED'
			if not LDRy15Hwv72mVgartIBWU: A60AIQZCYRzdhaeWfOtmrSUVoq2nN = A60AIQZCYRzdhaeWfOtmrSUVoq2nN+'_UNKNOWN'
			else: A60AIQZCYRzdhaeWfOtmrSUVoq2nN = A60AIQZCYRzdhaeWfOtmrSUVoq2nN+czG0PxAmlw4vtWrH5eL3RubT
		LDRy15Hwv72mVgartIBWU = LDRy15Hwv72mVgartIBWU.strip(pldxivXC5wbTB2O8q).replace(k5bCDErUSmv,pldxivXC5wbTB2O8q).replace(k5bCDErUSmv,pldxivXC5wbTB2O8q)
		if 'LIVE_UNKNOWN' in A60AIQZCYRzdhaeWfOtmrSUVoq2nN: LDRy15Hwv72mVgartIBWU = '!!__UNKNOWN_LIVE__!!'
		elif 'VOD_UNKNOWN' in A60AIQZCYRzdhaeWfOtmrSUVoq2nN: LDRy15Hwv72mVgartIBWU = '!!__UNKNOWN_VOD__!!'
		elif 'VOD_SERIES' in A60AIQZCYRzdhaeWfOtmrSUVoq2nN:
			eUN5Vo4yRJcWAv2dnXt9qbEglFQ0 = YYBlm36zd0Jst18LXwo4.findall('(.*?) [Ss]\d+ +[Ee]\d+',MlUKDx4pvThGN['title'],YYBlm36zd0Jst18LXwo4.DOTALL)
			if eUN5Vo4yRJcWAv2dnXt9qbEglFQ0: eUN5Vo4yRJcWAv2dnXt9qbEglFQ0 = eUN5Vo4yRJcWAv2dnXt9qbEglFQ0[0]
			else: eUN5Vo4yRJcWAv2dnXt9qbEglFQ0 = '!!__UNKNOWN_SERIES__!!'
			LDRy15Hwv72mVgartIBWU = LDRy15Hwv72mVgartIBWU+'__SERIES__'+eUN5Vo4yRJcWAv2dnXt9qbEglFQ0
		if 'id' in YMHq4aCwhb: del MlUKDx4pvThGN['id']
		if 'ID' in YMHq4aCwhb: del MlUKDx4pvThGN['ID']
		if 'name' in YMHq4aCwhb: del MlUKDx4pvThGN['name']
		sbat1zOx0HydLjm5qvTPgR = MlUKDx4pvThGN['title']
		sbat1zOx0HydLjm5qvTPgR = ggtn0PzV7aMe(sbat1zOx0HydLjm5qvTPgR)
		sbat1zOx0HydLjm5qvTPgR = GsgzEMcqfBLju(sbat1zOx0HydLjm5qvTPgR)
		vTWkU48E7ZGyeagCPLFKOSAltRq,LDRy15Hwv72mVgartIBWU = EnMUyLKvBQ7JR2rda(LDRy15Hwv72mVgartIBWU)
		lHJTYMq6fvP9ywuXsc,sbat1zOx0HydLjm5qvTPgR = EnMUyLKvBQ7JR2rda(sbat1zOx0HydLjm5qvTPgR)
		MlUKDx4pvThGN['type'] = A60AIQZCYRzdhaeWfOtmrSUVoq2nN
		MlUKDx4pvThGN['context'] = czG0PxAmlw4vtWrH5eL3RubT
		MlUKDx4pvThGN['group'] = LDRy15Hwv72mVgartIBWU.upper()
		MlUKDx4pvThGN['title'] = sbat1zOx0HydLjm5qvTPgR.upper()
		MlUKDx4pvThGN['country'] = lHJTYMq6fvP9ywuXsc.upper()
		MlUKDx4pvThGN['language'] = vTWkU48E7ZGyeagCPLFKOSAltRq.upper()
		xehYsVJtBRz.append(MlUKDx4pvThGN)
		LLsyevc6KqA4QG += 1
	return xehYsVJtBRz,LLsyevc6KqA4QG,eyo3Gtb5XC2DhWYqsakw
def GsgzEMcqfBLju(sbat1zOx0HydLjm5qvTPgR):
	sbat1zOx0HydLjm5qvTPgR = sbat1zOx0HydLjm5qvTPgR.replace(k5bCDErUSmv,pldxivXC5wbTB2O8q).replace(k5bCDErUSmv,pldxivXC5wbTB2O8q).replace(k5bCDErUSmv,pldxivXC5wbTB2O8q)
	sbat1zOx0HydLjm5qvTPgR = sbat1zOx0HydLjm5qvTPgR.replace('||','|').replace('___',':').replace('--','-')
	sbat1zOx0HydLjm5qvTPgR = sbat1zOx0HydLjm5qvTPgR.replace('[[','[').replace(']]',']')
	sbat1zOx0HydLjm5qvTPgR = sbat1zOx0HydLjm5qvTPgR.replace('((','(').replace('))',')')
	sbat1zOx0HydLjm5qvTPgR = sbat1zOx0HydLjm5qvTPgR.replace('<<','<').replace('>>','>')
	sbat1zOx0HydLjm5qvTPgR = sbat1zOx0HydLjm5qvTPgR.strip(pldxivXC5wbTB2O8q)
	return sbat1zOx0HydLjm5qvTPgR
def RNUQLkHJ32gSZBbf47OVCqa(TWmrzFENYkR2C7,cmvIRA5eW2OiZQdyw4VX,KHiQ5Z6kBVYoPjUsa):
	WhqwJr0DRAE7 = {}
	for oN9AXKfSGYjRug7aZ in YlEVuPr4LqIB6m7xHJ: WhqwJr0DRAE7[oN9AXKfSGYjRug7aZ+'_'+KHiQ5Z6kBVYoPjUsa] = []
	lyJOSdVDRvqGHnBxPU = len(TWmrzFENYkR2C7)
	cEy0h4HolN2eV = str(lyJOSdVDRvqGHnBxPU)
	LLsyevc6KqA4QG = 0
	eyo3Gtb5XC2DhWYqsakw = []
	for MlUKDx4pvThGN in TWmrzFENYkR2C7:
		if LLsyevc6KqA4QG%873==0:
			NrM3XJ8sD2pEHz(cmvIRA5eW2OiZQdyw4VX,50+int(5*LLsyevc6KqA4QG/lyJOSdVDRvqGHnBxPU),'تصنيف الفيديوهات الغير مرتبة','الفيديو رقم:-',str(LLsyevc6KqA4QG)+' / '+cEy0h4HolN2eV)
			if cmvIRA5eW2OiZQdyw4VX.iscanceled():
				cmvIRA5eW2OiZQdyw4VX.close()
				return None,None
		LDRy15Hwv72mVgartIBWU,czG0PxAmlw4vtWrH5eL3RubT,sbat1zOx0HydLjm5qvTPgR,uuNDjbit4hOpx,PVvXoB0pye37Sckg45QNDGlw62FjE = MlUKDx4pvThGN['group'],MlUKDx4pvThGN['context'],MlUKDx4pvThGN['title'],MlUKDx4pvThGN['url'],MlUKDx4pvThGN['img']
		lHJTYMq6fvP9ywuXsc,vTWkU48E7ZGyeagCPLFKOSAltRq,oN9AXKfSGYjRug7aZ = MlUKDx4pvThGN['country'],MlUKDx4pvThGN['language'],MlUKDx4pvThGN['type']
		DnfTi6mhjBVebEx9M1JaR = (LDRy15Hwv72mVgartIBWU,czG0PxAmlw4vtWrH5eL3RubT,sbat1zOx0HydLjm5qvTPgR,uuNDjbit4hOpx,PVvXoB0pye37Sckg45QNDGlw62FjE)
		rrDau6MzcswtF4 = False
		if 'LIVE' in oN9AXKfSGYjRug7aZ:
			if 'UNKNOWN' in oN9AXKfSGYjRug7aZ: WhqwJr0DRAE7['LIVE_UNKNOWN_GROUPED_'+KHiQ5Z6kBVYoPjUsa].append(DnfTi6mhjBVebEx9M1JaR)
			elif 'LIVE' in oN9AXKfSGYjRug7aZ: WhqwJr0DRAE7['LIVE_GROUPED_'+KHiQ5Z6kBVYoPjUsa].append(DnfTi6mhjBVebEx9M1JaR)
			else: rrDau6MzcswtF4 = True
			WhqwJr0DRAE7['LIVE_ORIGINAL_GROUPED_'+KHiQ5Z6kBVYoPjUsa].append(DnfTi6mhjBVebEx9M1JaR)
		elif 'VOD' in oN9AXKfSGYjRug7aZ:
			if 'UNKNOWN' in oN9AXKfSGYjRug7aZ: WhqwJr0DRAE7['VOD_UNKNOWN_GROUPED_'+KHiQ5Z6kBVYoPjUsa].append(DnfTi6mhjBVebEx9M1JaR)
			elif 'MOVIES' in oN9AXKfSGYjRug7aZ: WhqwJr0DRAE7['VOD_MOVIES_GROUPED_'+KHiQ5Z6kBVYoPjUsa].append(DnfTi6mhjBVebEx9M1JaR)
			elif 'SERIES' in oN9AXKfSGYjRug7aZ: WhqwJr0DRAE7['VOD_SERIES_GROUPED_'+KHiQ5Z6kBVYoPjUsa].append(DnfTi6mhjBVebEx9M1JaR)
			else: rrDau6MzcswtF4 = True
			WhqwJr0DRAE7['VOD_ORIGINAL_GROUPED_'+KHiQ5Z6kBVYoPjUsa].append(DnfTi6mhjBVebEx9M1JaR)
		else: rrDau6MzcswtF4 = True
		if rrDau6MzcswtF4: eyo3Gtb5XC2DhWYqsakw.append(MlUKDx4pvThGN)
		LLsyevc6KqA4QG += 1
	ppE8PuRSrc6CDx1MoqyTgH4U = sorted(TWmrzFENYkR2C7,reverse=False,key=lambda w2wJmSDK8fitdLVAaMRpNEPGc0g: w2wJmSDK8fitdLVAaMRpNEPGc0g['title'].lower())
	del TWmrzFENYkR2C7
	cEy0h4HolN2eV = str(lyJOSdVDRvqGHnBxPU)
	LLsyevc6KqA4QG = 0
	for MlUKDx4pvThGN in ppE8PuRSrc6CDx1MoqyTgH4U:
		LLsyevc6KqA4QG += 1
		if LLsyevc6KqA4QG%873==0:
			NrM3XJ8sD2pEHz(cmvIRA5eW2OiZQdyw4VX,55+int(5*LLsyevc6KqA4QG/lyJOSdVDRvqGHnBxPU),'تصنيف الفيديوهات المرتبة','الفيديو رقم:-',str(LLsyevc6KqA4QG)+' / '+cEy0h4HolN2eV)
			if cmvIRA5eW2OiZQdyw4VX.iscanceled():
				cmvIRA5eW2OiZQdyw4VX.close()
				return None,None
		oN9AXKfSGYjRug7aZ = MlUKDx4pvThGN['type']
		LDRy15Hwv72mVgartIBWU,czG0PxAmlw4vtWrH5eL3RubT,sbat1zOx0HydLjm5qvTPgR,uuNDjbit4hOpx,PVvXoB0pye37Sckg45QNDGlw62FjE = MlUKDx4pvThGN['group'],MlUKDx4pvThGN['context'],MlUKDx4pvThGN['title'],MlUKDx4pvThGN['url'],MlUKDx4pvThGN['img']
		lHJTYMq6fvP9ywuXsc,vTWkU48E7ZGyeagCPLFKOSAltRq = MlUKDx4pvThGN['country'],MlUKDx4pvThGN['language']
		f6t9E5eDZQlNSYosw2y7 = (LDRy15Hwv72mVgartIBWU,czG0PxAmlw4vtWrH5eL3RubT+'_TIMESHIFT',sbat1zOx0HydLjm5qvTPgR,uuNDjbit4hOpx,PVvXoB0pye37Sckg45QNDGlw62FjE)
		DnfTi6mhjBVebEx9M1JaR = (LDRy15Hwv72mVgartIBWU,czG0PxAmlw4vtWrH5eL3RubT,sbat1zOx0HydLjm5qvTPgR,uuNDjbit4hOpx,PVvXoB0pye37Sckg45QNDGlw62FjE)
		m2G5buhxafPoXIqUZcTeiVd = (lHJTYMq6fvP9ywuXsc,czG0PxAmlw4vtWrH5eL3RubT,sbat1zOx0HydLjm5qvTPgR,uuNDjbit4hOpx,PVvXoB0pye37Sckg45QNDGlw62FjE)
		EuXysHgmciBh = (vTWkU48E7ZGyeagCPLFKOSAltRq,czG0PxAmlw4vtWrH5eL3RubT,sbat1zOx0HydLjm5qvTPgR,uuNDjbit4hOpx,PVvXoB0pye37Sckg45QNDGlw62FjE)
		if 'LIVE' in oN9AXKfSGYjRug7aZ:
			if 'UNKNOWN' in oN9AXKfSGYjRug7aZ: WhqwJr0DRAE7['LIVE_UNKNOWN_GROUPED_SORTED_'+KHiQ5Z6kBVYoPjUsa].append(DnfTi6mhjBVebEx9M1JaR)
			else: WhqwJr0DRAE7['LIVE_GROUPED_SORTED_'+KHiQ5Z6kBVYoPjUsa].append(DnfTi6mhjBVebEx9M1JaR)
			if 'EPG'		in oN9AXKfSGYjRug7aZ: WhqwJr0DRAE7['LIVE_EPG_GROUPED_SORTED_'+KHiQ5Z6kBVYoPjUsa].append(DnfTi6mhjBVebEx9M1JaR)
			if 'ARCHIVED'	in oN9AXKfSGYjRug7aZ: WhqwJr0DRAE7['LIVE_ARCHIVED_GROUPED_SORTED_'+KHiQ5Z6kBVYoPjUsa].append(DnfTi6mhjBVebEx9M1JaR)
			if 'ARCHIVED'	in oN9AXKfSGYjRug7aZ: WhqwJr0DRAE7['LIVE_TIMESHIFT_GROUPED_SORTED_'+KHiQ5Z6kBVYoPjUsa].append(f6t9E5eDZQlNSYosw2y7)
			WhqwJr0DRAE7['LIVE_FROM_NAME_SORTED_'+KHiQ5Z6kBVYoPjUsa].append(m2G5buhxafPoXIqUZcTeiVd)
			WhqwJr0DRAE7['LIVE_FROM_GROUP_SORTED_'+KHiQ5Z6kBVYoPjUsa].append(EuXysHgmciBh)
		elif 'VOD' in oN9AXKfSGYjRug7aZ:
			if   'UNKNOWN'	in oN9AXKfSGYjRug7aZ: WhqwJr0DRAE7['VOD_UNKNOWN_GROUPED_SORTED_'+KHiQ5Z6kBVYoPjUsa].append(DnfTi6mhjBVebEx9M1JaR)
			elif 'MOVIES'	in oN9AXKfSGYjRug7aZ: WhqwJr0DRAE7['VOD_MOVIES_GROUPED_SORTED_'+KHiQ5Z6kBVYoPjUsa].append(DnfTi6mhjBVebEx9M1JaR)
			elif 'SERIES'	in oN9AXKfSGYjRug7aZ: WhqwJr0DRAE7['VOD_SERIES_GROUPED_SORTED_'+KHiQ5Z6kBVYoPjUsa].append(DnfTi6mhjBVebEx9M1JaR)
			WhqwJr0DRAE7['VOD_FROM_NAME_SORTED_'+KHiQ5Z6kBVYoPjUsa].append(m2G5buhxafPoXIqUZcTeiVd)
			WhqwJr0DRAE7['VOD_FROM_GROUP_SORTED_'+KHiQ5Z6kBVYoPjUsa].append(EuXysHgmciBh)
	return WhqwJr0DRAE7,eyo3Gtb5XC2DhWYqsakw
def EnMUyLKvBQ7JR2rda(sbat1zOx0HydLjm5qvTPgR):
	if len(sbat1zOx0HydLjm5qvTPgR)<3: return sbat1zOx0HydLjm5qvTPgR,sbat1zOx0HydLjm5qvTPgR
	xxVBKUpfE5vAH6XtzJLTnCuo,xpWi4l1NQXSkIKeB5EuV9 = b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv
	wLXfQ1Vh30vYjirCaWHtdEIAs2Jp6 = sbat1zOx0HydLjm5qvTPgR
	GGqwm43gCv6YiTXRLOz9lB1KaV = sbat1zOx0HydLjm5qvTPgR[:1]
	mwC6OgY2J1yESQk8tzUBi = sbat1zOx0HydLjm5qvTPgR[1:]
	if   GGqwm43gCv6YiTXRLOz9lB1KaV=='(': xpWi4l1NQXSkIKeB5EuV9 = ')'
	elif GGqwm43gCv6YiTXRLOz9lB1KaV=='[': xpWi4l1NQXSkIKeB5EuV9 = ']'
	elif GGqwm43gCv6YiTXRLOz9lB1KaV=='<': xpWi4l1NQXSkIKeB5EuV9 = '>'
	elif GGqwm43gCv6YiTXRLOz9lB1KaV=='|': xpWi4l1NQXSkIKeB5EuV9 = '|'
	if xpWi4l1NQXSkIKeB5EuV9 and (xpWi4l1NQXSkIKeB5EuV9 in mwC6OgY2J1yESQk8tzUBi):
		HVOCZoUyRNe3Lfs4bKgXSEx7Fn,rpYntk3HSJj8gv0e761hIOsC = mwC6OgY2J1yESQk8tzUBi.split(xpWi4l1NQXSkIKeB5EuV9,1)
		xxVBKUpfE5vAH6XtzJLTnCuo = HVOCZoUyRNe3Lfs4bKgXSEx7Fn
		wLXfQ1Vh30vYjirCaWHtdEIAs2Jp6 = GGqwm43gCv6YiTXRLOz9lB1KaV+HVOCZoUyRNe3Lfs4bKgXSEx7Fn+xpWi4l1NQXSkIKeB5EuV9+pldxivXC5wbTB2O8q+rpYntk3HSJj8gv0e761hIOsC
	elif sbat1zOx0HydLjm5qvTPgR.count('|')>=2:
		HVOCZoUyRNe3Lfs4bKgXSEx7Fn,rpYntk3HSJj8gv0e761hIOsC = sbat1zOx0HydLjm5qvTPgR.split('|',1)
		xxVBKUpfE5vAH6XtzJLTnCuo = HVOCZoUyRNe3Lfs4bKgXSEx7Fn
		wLXfQ1Vh30vYjirCaWHtdEIAs2Jp6 = HVOCZoUyRNe3Lfs4bKgXSEx7Fn+' |'+rpYntk3HSJj8gv0e761hIOsC
	else:
		xpWi4l1NQXSkIKeB5EuV9 = YYBlm36zd0Jst18LXwo4.findall('^\w{2}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',sbat1zOx0HydLjm5qvTPgR,YYBlm36zd0Jst18LXwo4.DOTALL)
		if not xpWi4l1NQXSkIKeB5EuV9: xpWi4l1NQXSkIKeB5EuV9 = YYBlm36zd0Jst18LXwo4.findall('^\w{3}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',sbat1zOx0HydLjm5qvTPgR,YYBlm36zd0Jst18LXwo4.DOTALL)
		if not xpWi4l1NQXSkIKeB5EuV9: xpWi4l1NQXSkIKeB5EuV9 = YYBlm36zd0Jst18LXwo4.findall('^\w{4}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',sbat1zOx0HydLjm5qvTPgR,YYBlm36zd0Jst18LXwo4.DOTALL)
		if xpWi4l1NQXSkIKeB5EuV9:
			HVOCZoUyRNe3Lfs4bKgXSEx7Fn,rpYntk3HSJj8gv0e761hIOsC = sbat1zOx0HydLjm5qvTPgR.split(xpWi4l1NQXSkIKeB5EuV9[0],1)
			xxVBKUpfE5vAH6XtzJLTnCuo = HVOCZoUyRNe3Lfs4bKgXSEx7Fn
			wLXfQ1Vh30vYjirCaWHtdEIAs2Jp6 = HVOCZoUyRNe3Lfs4bKgXSEx7Fn+pldxivXC5wbTB2O8q+xpWi4l1NQXSkIKeB5EuV9[0]+pldxivXC5wbTB2O8q+rpYntk3HSJj8gv0e761hIOsC
	wLXfQ1Vh30vYjirCaWHtdEIAs2Jp6 = wLXfQ1Vh30vYjirCaWHtdEIAs2Jp6.replace(R1BKXhzpGH6CoO9jLsPwQWu,pldxivXC5wbTB2O8q).replace(k5bCDErUSmv,pldxivXC5wbTB2O8q)
	xxVBKUpfE5vAH6XtzJLTnCuo = xxVBKUpfE5vAH6XtzJLTnCuo.replace(k5bCDErUSmv,pldxivXC5wbTB2O8q)
	if not xxVBKUpfE5vAH6XtzJLTnCuo: xxVBKUpfE5vAH6XtzJLTnCuo = '!!__UNKNOWN__!!'
	xxVBKUpfE5vAH6XtzJLTnCuo = xxVBKUpfE5vAH6XtzJLTnCuo.strip(pldxivXC5wbTB2O8q)
	wLXfQ1Vh30vYjirCaWHtdEIAs2Jp6 = wLXfQ1Vh30vYjirCaWHtdEIAs2Jp6.strip(pldxivXC5wbTB2O8q)
	return xxVBKUpfE5vAH6XtzJLTnCuo,wLXfQ1Vh30vYjirCaWHtdEIAs2Jp6
def F04FsYgKcE(rA1p4eTdbhi69sotZkuP0QafYNDn):
	NNB43WbKMVnrktmcsZXUR6wvfJq = {}
	O4NjAwLMCfqEYl30yiUd9mgH = hRWC8YSFvsm4JHOMVIne3jquZ.getSetting('av.m3u.useragent_'+rA1p4eTdbhi69sotZkuP0QafYNDn)
	if O4NjAwLMCfqEYl30yiUd9mgH: NNB43WbKMVnrktmcsZXUR6wvfJq['User-Agent'] = O4NjAwLMCfqEYl30yiUd9mgH
	x4xQjnNYV1XfFgU7hzkq9v5K = hRWC8YSFvsm4JHOMVIne3jquZ.getSetting('av.m3u.referer_'+rA1p4eTdbhi69sotZkuP0QafYNDn)
	if x4xQjnNYV1XfFgU7hzkq9v5K: NNB43WbKMVnrktmcsZXUR6wvfJq['Referer'] = x4xQjnNYV1XfFgU7hzkq9v5K
	return NNB43WbKMVnrktmcsZXUR6wvfJq
def jiMFRB3HEmDX5JUNd80ybKuGAxCZP(rA1p4eTdbhi69sotZkuP0QafYNDn,KHiQ5Z6kBVYoPjUsa):
	global cmvIRA5eW2OiZQdyw4VX,WhqwJr0DRAE7,oigfd9M6WRy3Pt2m84CjDZUxe,LLV36Id5hDrXCRu,J6bUR4WnHLkElTAoO,P9MuDKe5WdAkqQTEJ8mU7,PY7Om8BICLceMJq26,LS510M4qymPtYpw2RHzsjKaJ9nT,PumF2YrWAxK9ha4jE
	UUGcBS73g1 = hRWC8YSFvsm4JHOMVIne3jquZ.getSetting('av.m3u.url_'+rA1p4eTdbhi69sotZkuP0QafYNDn+'_'+KHiQ5Z6kBVYoPjUsa)
	O4NjAwLMCfqEYl30yiUd9mgH = hRWC8YSFvsm4JHOMVIne3jquZ.getSetting('av.m3u.useragent_'+rA1p4eTdbhi69sotZkuP0QafYNDn)
	NNB43WbKMVnrktmcsZXUR6wvfJq = {'User-Agent':O4NjAwLMCfqEYl30yiUd9mgH}
	BpLjE4kVDZovfuS5mI817cAtb = c5wOJ98CasX3VYykR1dKSN7qx.replace('___','_'+rA1p4eTdbhi69sotZkuP0QafYNDn+'_'+KHiQ5Z6kBVYoPjUsa)
	if 1:
		LhFtNIEfT6WHVi50bMYvRmCzro9A,dgJF1846SsPuVEexvaLnQp7rHOU,kSorHcEWFs503dwvDblhOyJ6T9f = True,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv
		if not LhFtNIEfT6WHVi50bMYvRmCzro9A:
			tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'رسالة من المبرمج','فشل بسحب ملفات ـM3U . أحتمال رابط ـM3U غير صحيح أو قديم أو لا يعمل .. علما أن هذه الخدمة تحتاج اشتراك مدفوع وصحيح ويجب أن تضيف رابط الاشتراك بنفسك للبرنامج باستخدام قائمة ـM3U الموجودة بهذا البرنامج')
			if not UUGcBS73g1: mwIxD3GBPgLVc2aq9(WG2BfeyzMa,EECz06teoykrNFfq(QQ8pvXNcBfVkP5rRJ7o)+'   No M3U URL found to download M3U files')
			else: mwIxD3GBPgLVc2aq9(WG2BfeyzMa,EECz06teoykrNFfq(ALwGbyiBFzY7H)+'   Failed to download M3U files')
			return
		lSCUsuW8Xx0aFYvzMrKc6p = d0dDAEXWNf(UUGcBS73g1,NNB43WbKMVnrktmcsZXUR6wvfJq,True)
		if not lSCUsuW8Xx0aFYvzMrKc6p: return
		open(BpLjE4kVDZovfuS5mI817cAtb,'wb').write(lSCUsuW8Xx0aFYvzMrKc6p)
	else: lSCUsuW8Xx0aFYvzMrKc6p = open(BpLjE4kVDZovfuS5mI817cAtb,'rb').read()
	if i1thmHk7AZquD4cM0fnp62 and lSCUsuW8Xx0aFYvzMrKc6p: lSCUsuW8Xx0aFYvzMrKc6p = lSCUsuW8Xx0aFYvzMrKc6p.decode(OVauxZzLI10vcXT74K)
	cmvIRA5eW2OiZQdyw4VX = F6kGteqcvBXWCKdASUZmnjP()
	cmvIRA5eW2OiZQdyw4VX.create('جلب ملفات M3U جديدة',b8Qe150xVaJsnDSv)
	NrM3XJ8sD2pEHz(cmvIRA5eW2OiZQdyw4VX,15,'تنظيف الملف الرئيسي',b8Qe150xVaJsnDSv)
	lSCUsuW8Xx0aFYvzMrKc6p = lSCUsuW8Xx0aFYvzMrKc6p.replace('"tvg-','" tvg-')
	lSCUsuW8Xx0aFYvzMrKc6p = lSCUsuW8Xx0aFYvzMrKc6p.replace('َ',b8Qe150xVaJsnDSv).replace('ً',b8Qe150xVaJsnDSv).replace('ُ',b8Qe150xVaJsnDSv).replace('ٌ',b8Qe150xVaJsnDSv)
	lSCUsuW8Xx0aFYvzMrKc6p = lSCUsuW8Xx0aFYvzMrKc6p.replace('ّ',b8Qe150xVaJsnDSv).replace('ِ',b8Qe150xVaJsnDSv).replace('ٍ',b8Qe150xVaJsnDSv).replace('ْ',b8Qe150xVaJsnDSv)
	lSCUsuW8Xx0aFYvzMrKc6p = lSCUsuW8Xx0aFYvzMrKc6p.replace('group-title=','group=').replace('tvg-',b8Qe150xVaJsnDSv)
	q2qH6xOspywVYcB5uLrhnm,SDCyhZx6WK0rEA1XUeQMVbk9Piv = [],[]
	lSCUsuW8Xx0aFYvzMrKc6p = lSCUsuW8Xx0aFYvzMrKc6p.replace(d6ekSEojpFUANKJ7r9WTlI3niLBOu,eeN6dTEnkJxI)
	bbRcgP2UL3pV7IkSdWJ1OZm6AvYXw = YYBlm36zd0Jst18LXwo4.findall('NF:(.+?)'+'#'+'EXTI',lSCUsuW8Xx0aFYvzMrKc6p+'\n+'+'#'+'EXTINF:',YYBlm36zd0Jst18LXwo4.DOTALL)
	if not bbRcgP2UL3pV7IkSdWJ1OZm6AvYXw:
		mwIxD3GBPgLVc2aq9(WG2BfeyzMa,EECz06teoykrNFfq(ALwGbyiBFzY7H)+'   Folder:'+rA1p4eTdbhi69sotZkuP0QafYNDn+'  Sequence:'+KHiQ5Z6kBVYoPjUsa+'   No video links found in M3U file')
		tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'رسالة من المبرمج','رابط ـM3U الذي أنت أضفته لا توجد فيه فيديوهات .. احتمال رابط ـM3U غير صحيح'+eeN6dTEnkJxI+OkuB9nwhD8U1+'مجلد رقم '+rA1p4eTdbhi69sotZkuP0QafYNDn+'      رابط رقم '+KHiQ5Z6kBVYoPjUsa+hAIp8kmC36T5WFPMSXOwnNbtD)
		cmvIRA5eW2OiZQdyw4VX.close()
		return
	Ajid97z3x6sSFwX = []
	for XcB7EqbZMOW9RuYnD62V4F3jrhvp in bbRcgP2UL3pV7IkSdWJ1OZm6AvYXw:
		u2C4pdAMGl = XcB7EqbZMOW9RuYnD62V4F3jrhvp.lower()
		if 'adult' in u2C4pdAMGl: continue
		if 'xxx' in u2C4pdAMGl: continue
		Ajid97z3x6sSFwX.append(XcB7EqbZMOW9RuYnD62V4F3jrhvp)
	bbRcgP2UL3pV7IkSdWJ1OZm6AvYXw = Ajid97z3x6sSFwX
	del Ajid97z3x6sSFwX
	if 'iptv-org' in UUGcBS73g1:
		Ajid97z3x6sSFwX,BJZ6RjucX23CG81YWki5NOxF4hyHEa = [],[]
		for XcB7EqbZMOW9RuYnD62V4F3jrhvp in bbRcgP2UL3pV7IkSdWJ1OZm6AvYXw:
			P9MuDKe5WdAkqQTEJ8mU7 = YYBlm36zd0Jst18LXwo4.findall('group="(.*?)"',XcB7EqbZMOW9RuYnD62V4F3jrhvp,YYBlm36zd0Jst18LXwo4.DOTALL)
			if P9MuDKe5WdAkqQTEJ8mU7:
				P9MuDKe5WdAkqQTEJ8mU7 = P9MuDKe5WdAkqQTEJ8mU7[0]
				I7I8qsAHUE = P9MuDKe5WdAkqQTEJ8mU7.split(';')
				if 'region' in UUGcBS73g1: nXYfG5KDdmNrAu0Wx9 = '1_'
				elif 'category' in UUGcBS73g1: nXYfG5KDdmNrAu0Wx9 = '2_'
				elif 'language' in UUGcBS73g1: nXYfG5KDdmNrAu0Wx9 = '3_'
				elif 'country' in UUGcBS73g1: nXYfG5KDdmNrAu0Wx9 = '4_'
				else: nXYfG5KDdmNrAu0Wx9 = '5_'
				ASrd5b2e9JgsiyRQjazv8CoIY = XcB7EqbZMOW9RuYnD62V4F3jrhvp.replace('group="'+P9MuDKe5WdAkqQTEJ8mU7+'"','group="'+nXYfG5KDdmNrAu0Wx9+'~'+rC3Tlno96KjLDIvBaSWUbR8+' ===== ===== ===== '+hAIp8kmC36T5WFPMSXOwnNbtD+'"')
				Ajid97z3x6sSFwX.append(ASrd5b2e9JgsiyRQjazv8CoIY)
				for LDRy15Hwv72mVgartIBWU in I7I8qsAHUE:
					ASrd5b2e9JgsiyRQjazv8CoIY = XcB7EqbZMOW9RuYnD62V4F3jrhvp.replace('group="'+P9MuDKe5WdAkqQTEJ8mU7+'"','group="'+nXYfG5KDdmNrAu0Wx9+LDRy15Hwv72mVgartIBWU+'"')
					Ajid97z3x6sSFwX.append(ASrd5b2e9JgsiyRQjazv8CoIY)
			else: Ajid97z3x6sSFwX.append(XcB7EqbZMOW9RuYnD62V4F3jrhvp)
		bbRcgP2UL3pV7IkSdWJ1OZm6AvYXw = Ajid97z3x6sSFwX
		del Ajid97z3x6sSFwX,BJZ6RjucX23CG81YWki5NOxF4hyHEa
	cd15EajuF7UJIt = 1024*1024
	uVcU4JntNiqPgesD78dZApBEKbm0Rz = 1+len(lSCUsuW8Xx0aFYvzMrKc6p)//cd15EajuF7UJIt//10
	del lSCUsuW8Xx0aFYvzMrKc6p
	ddsuigTC3vPIp4 = len(bbRcgP2UL3pV7IkSdWJ1OZm6AvYXw)
	BJZ6RjucX23CG81YWki5NOxF4hyHEa = rhltO6QX0U4nq(bbRcgP2UL3pV7IkSdWJ1OZm6AvYXw,uVcU4JntNiqPgesD78dZApBEKbm0Rz)
	del bbRcgP2UL3pV7IkSdWJ1OZm6AvYXw
	for H9JbVKORYEGt3jo2g in range(uVcU4JntNiqPgesD78dZApBEKbm0Rz):
		NrM3XJ8sD2pEHz(cmvIRA5eW2OiZQdyw4VX,35+int(5*H9JbVKORYEGt3jo2g/uVcU4JntNiqPgesD78dZApBEKbm0Rz),'تقطيع الملف الرئيسي','الجزء رقم:-',str(H9JbVKORYEGt3jo2g+1)+' / '+str(uVcU4JntNiqPgesD78dZApBEKbm0Rz))
		if cmvIRA5eW2OiZQdyw4VX.iscanceled():
			cmvIRA5eW2OiZQdyw4VX.close()
			return
		jbD3CguhHySzscQMN5GA = str(BJZ6RjucX23CG81YWki5NOxF4hyHEa[H9JbVKORYEGt3jo2g])
		if i1thmHk7AZquD4cM0fnp62: jbD3CguhHySzscQMN5GA = jbD3CguhHySzscQMN5GA.encode(OVauxZzLI10vcXT74K)
		open(BpLjE4kVDZovfuS5mI817cAtb+'.00'+str(H9JbVKORYEGt3jo2g),'wb').write(jbD3CguhHySzscQMN5GA)
	del BJZ6RjucX23CG81YWki5NOxF4hyHEa,jbD3CguhHySzscQMN5GA
	ywvS7tXaMcEgF0mCuYq958OJA,TWmrzFENYkR2C7,LLsyevc6KqA4QG = [],[],0
	for H9JbVKORYEGt3jo2g in range(uVcU4JntNiqPgesD78dZApBEKbm0Rz):
		if cmvIRA5eW2OiZQdyw4VX.iscanceled():
			cmvIRA5eW2OiZQdyw4VX.close()
			return
		jbD3CguhHySzscQMN5GA = open(BpLjE4kVDZovfuS5mI817cAtb+'.00'+str(H9JbVKORYEGt3jo2g),'rb').read()
		wLQCTr5lqbsVYeAHdzfhZ1F.sleep(1)
		try: x76PfMyAp1L2WejkU3.remove(BpLjE4kVDZovfuS5mI817cAtb+'.00'+str(H9JbVKORYEGt3jo2g))
		except: pass
		if i1thmHk7AZquD4cM0fnp62: jbD3CguhHySzscQMN5GA = jbD3CguhHySzscQMN5GA.decode(OVauxZzLI10vcXT74K)
		cR1Hs4oSJnGVz8ulLUXt6Kp = oJsUwXA0yGOI1mTjxQ('list',jbD3CguhHySzscQMN5GA)
		del jbD3CguhHySzscQMN5GA
		xehYsVJtBRz,LLsyevc6KqA4QG,eyo3Gtb5XC2DhWYqsakw = iYbAhL3GjzoZmc0PBu(cR1Hs4oSJnGVz8ulLUXt6Kp,SDCyhZx6WK0rEA1XUeQMVbk9Piv,q2qH6xOspywVYcB5uLrhnm,cmvIRA5eW2OiZQdyw4VX,ddsuigTC3vPIp4,LLsyevc6KqA4QG,UUGcBS73g1)
		if cmvIRA5eW2OiZQdyw4VX.iscanceled():
			cmvIRA5eW2OiZQdyw4VX.close()
			return
		if not xehYsVJtBRz:
			cmvIRA5eW2OiZQdyw4VX.close()
			return
		TWmrzFENYkR2C7 += xehYsVJtBRz
		ywvS7tXaMcEgF0mCuYq958OJA += eyo3Gtb5XC2DhWYqsakw
	del cR1Hs4oSJnGVz8ulLUXt6Kp,xehYsVJtBRz
	WhqwJr0DRAE7,eyo3Gtb5XC2DhWYqsakw = RNUQLkHJ32gSZBbf47OVCqa(TWmrzFENYkR2C7,cmvIRA5eW2OiZQdyw4VX,KHiQ5Z6kBVYoPjUsa)
	if cmvIRA5eW2OiZQdyw4VX.iscanceled():
		cmvIRA5eW2OiZQdyw4VX.close()
		return
	ywvS7tXaMcEgF0mCuYq958OJA += eyo3Gtb5XC2DhWYqsakw
	del TWmrzFENYkR2C7,eyo3Gtb5XC2DhWYqsakw
	LLV36Id5hDrXCRu,J6bUR4WnHLkElTAoO,P9MuDKe5WdAkqQTEJ8mU7,PY7Om8BICLceMJq26,LS510M4qymPtYpw2RHzsjKaJ9nT = {},{},{},0,0
	PGLtQsE1iY = list(WhqwJr0DRAE7.keys())
	PumF2YrWAxK9ha4jE = len(PGLtQsE1iY)*3
	if 1:
		ppEmnd9lvrHBK6tNwL5MjkR = {}
		for BxP4plOuSfmjn8Xd51sUVgrqy in PGLtQsE1iY:
			ppEmnd9lvrHBK6tNwL5MjkR[BxP4plOuSfmjn8Xd51sUVgrqy] = Ay1SMOzkx5CU3aGTL4Zf.Thread(target=HKUB7ePOMtnikAzmXgRj2LJSIG8,args=(BxP4plOuSfmjn8Xd51sUVgrqy,))
			ppEmnd9lvrHBK6tNwL5MjkR[BxP4plOuSfmjn8Xd51sUVgrqy].start()
		for BxP4plOuSfmjn8Xd51sUVgrqy in PGLtQsE1iY:
			ppEmnd9lvrHBK6tNwL5MjkR[BxP4plOuSfmjn8Xd51sUVgrqy].join()
		if cmvIRA5eW2OiZQdyw4VX.iscanceled():
			cmvIRA5eW2OiZQdyw4VX.close()
			return
	else:
		for BxP4plOuSfmjn8Xd51sUVgrqy in PGLtQsE1iY:
			HKUB7ePOMtnikAzmXgRj2LJSIG8(BxP4plOuSfmjn8Xd51sUVgrqy)
			if cmvIRA5eW2OiZQdyw4VX.iscanceled():
				cmvIRA5eW2OiZQdyw4VX.close()
				return
	VcF7wfAQhe3osv650(rA1p4eTdbhi69sotZkuP0QafYNDn,KHiQ5Z6kBVYoPjUsa,False)
	PGLtQsE1iY = list(LLV36Id5hDrXCRu.keys())
	oigfd9M6WRy3Pt2m84CjDZUxe = 0
	if 1:
		ppEmnd9lvrHBK6tNwL5MjkR = {}
		for BxP4plOuSfmjn8Xd51sUVgrqy in PGLtQsE1iY:
			ppEmnd9lvrHBK6tNwL5MjkR[BxP4plOuSfmjn8Xd51sUVgrqy] = Ay1SMOzkx5CU3aGTL4Zf.Thread(target=HPm4rJk956nK2A7gqvIca,args=(rA1p4eTdbhi69sotZkuP0QafYNDn,BxP4plOuSfmjn8Xd51sUVgrqy))
			ppEmnd9lvrHBK6tNwL5MjkR[BxP4plOuSfmjn8Xd51sUVgrqy].start()
		for BxP4plOuSfmjn8Xd51sUVgrqy in PGLtQsE1iY:
			ppEmnd9lvrHBK6tNwL5MjkR[BxP4plOuSfmjn8Xd51sUVgrqy].join()
		if cmvIRA5eW2OiZQdyw4VX.iscanceled():
			cmvIRA5eW2OiZQdyw4VX.close()
			return
	else:
		for BxP4plOuSfmjn8Xd51sUVgrqy in PGLtQsE1iY:
			HPm4rJk956nK2A7gqvIca(rA1p4eTdbhi69sotZkuP0QafYNDn,BxP4plOuSfmjn8Xd51sUVgrqy)
			if cmvIRA5eW2OiZQdyw4VX.iscanceled():
				cmvIRA5eW2OiZQdyw4VX.close()
				return
	H9JbVKORYEGt3jo2g = 0
	vfjIFokMpg0 = len(ywvS7tXaMcEgF0mCuYq958OJA)
	AGBKp17l0b6VURQ = uwgvq5oDNAdsfCPEcYy7HFRBWrkmj6(rA1p4eTdbhi69sotZkuP0QafYNDn,'IGNORED')
	for EOPwMxWfsuhjcX1tkdR7830l5ITD in ywvS7tXaMcEgF0mCuYq958OJA:
		if H9JbVKORYEGt3jo2g%27==0:
			NrM3XJ8sD2pEHz(cmvIRA5eW2OiZQdyw4VX,95+int(5*H9JbVKORYEGt3jo2g//vfjIFokMpg0),'تخزين المهملة','الفيديو رقم:-',str(H9JbVKORYEGt3jo2g)+' / '+str(vfjIFokMpg0))
			if cmvIRA5eW2OiZQdyw4VX.iscanceled():
				cmvIRA5eW2OiZQdyw4VX.close()
				return
		PGudrhJF8iDkSq96XVHEQZYf5L(AGBKp17l0b6VURQ,'IGNORED_'+KHiQ5Z6kBVYoPjUsa,str(EOPwMxWfsuhjcX1tkdR7830l5ITD),b8Qe150xVaJsnDSv,t58tnzAgevxkoIOdMFbE2PsD64q0C9)
		H9JbVKORYEGt3jo2g += 1
	PGudrhJF8iDkSq96XVHEQZYf5L(AGBKp17l0b6VURQ,'IGNORED_'+KHiQ5Z6kBVYoPjUsa,'__COUNT__',str(vfjIFokMpg0),t58tnzAgevxkoIOdMFbE2PsD64q0C9)
	cmvIRA5eW2OiZQdyw4VX.close()
	wLQCTr5lqbsVYeAHdzfhZ1F.sleep(1)
	WIiopcT2R9PdLt7VExswk0HmnYZe5(rA1p4eTdbhi69sotZkuP0QafYNDn)
	return
def HKUB7ePOMtnikAzmXgRj2LJSIG8(BxP4plOuSfmjn8Xd51sUVgrqy):
	global cmvIRA5eW2OiZQdyw4VX,WhqwJr0DRAE7,oigfd9M6WRy3Pt2m84CjDZUxe,LLV36Id5hDrXCRu,J6bUR4WnHLkElTAoO,P9MuDKe5WdAkqQTEJ8mU7,PY7Om8BICLceMJq26,LS510M4qymPtYpw2RHzsjKaJ9nT,PumF2YrWAxK9ha4jE
	LLV36Id5hDrXCRu[BxP4plOuSfmjn8Xd51sUVgrqy] = {}
	Y1Pz6QNbB9LRMvJl0r2jI,oop0Y68xvJzSjVumXDgGaiUbO9 = {},[]
	Z972rck85iqesAVGwCBEH4oKal = len(WhqwJr0DRAE7[BxP4plOuSfmjn8Xd51sUVgrqy])
	LLV36Id5hDrXCRu[BxP4plOuSfmjn8Xd51sUVgrqy]['__COUNT__'] = Z972rck85iqesAVGwCBEH4oKal
	if Z972rck85iqesAVGwCBEH4oKal>0:
		VE2g4vHncwQBPy61UI73aDTOXt,nCKuicfs3Bbok1Q4RHEz6x0Tr958D2,LL9o2vVPDhNxEKmar6,dFoxMDue4t,nX4871IdczGoKO5gSADybpsVm0f2UZ = zip(*WhqwJr0DRAE7[BxP4plOuSfmjn8Xd51sUVgrqy])
		del nCKuicfs3Bbok1Q4RHEz6x0Tr958D2,LL9o2vVPDhNxEKmar6,dFoxMDue4t
		I7I8qsAHUE = list(set(VE2g4vHncwQBPy61UI73aDTOXt))
		for LDRy15Hwv72mVgartIBWU in I7I8qsAHUE:
			Y1Pz6QNbB9LRMvJl0r2jI[LDRy15Hwv72mVgartIBWU] = b8Qe150xVaJsnDSv
			LLV36Id5hDrXCRu[BxP4plOuSfmjn8Xd51sUVgrqy][LDRy15Hwv72mVgartIBWU] = []
		NrM3XJ8sD2pEHz(cmvIRA5eW2OiZQdyw4VX,60+int(15*LS510M4qymPtYpw2RHzsjKaJ9nT//PumF2YrWAxK9ha4jE),'تصنيع القوائم','الجزء رقم:-',str(LS510M4qymPtYpw2RHzsjKaJ9nT)+' / '+str(PumF2YrWAxK9ha4jE))
		if cmvIRA5eW2OiZQdyw4VX.iscanceled(): return
		LS510M4qymPtYpw2RHzsjKaJ9nT += 1
		mGYfTzvyZsajc = len(I7I8qsAHUE)
		del I7I8qsAHUE
		oop0Y68xvJzSjVumXDgGaiUbO9 = list(set(zip(VE2g4vHncwQBPy61UI73aDTOXt,nX4871IdczGoKO5gSADybpsVm0f2UZ)))
		del VE2g4vHncwQBPy61UI73aDTOXt,nX4871IdczGoKO5gSADybpsVm0f2UZ
		for LDRy15Hwv72mVgartIBWU,ChvkSxHr6QoKJg in oop0Y68xvJzSjVumXDgGaiUbO9:
			if not Y1Pz6QNbB9LRMvJl0r2jI[LDRy15Hwv72mVgartIBWU] and ChvkSxHr6QoKJg: Y1Pz6QNbB9LRMvJl0r2jI[LDRy15Hwv72mVgartIBWU] = ChvkSxHr6QoKJg
		NrM3XJ8sD2pEHz(cmvIRA5eW2OiZQdyw4VX,60+int(15*LS510M4qymPtYpw2RHzsjKaJ9nT//PumF2YrWAxK9ha4jE),'تصنيع القوائم','الجزء رقم:-',str(LS510M4qymPtYpw2RHzsjKaJ9nT)+' / '+str(PumF2YrWAxK9ha4jE))
		if cmvIRA5eW2OiZQdyw4VX.iscanceled(): return
		LS510M4qymPtYpw2RHzsjKaJ9nT += 1
		ci9gsA8OPu = list(Y1Pz6QNbB9LRMvJl0r2jI.keys())
		QwU8uMh1cH7LnyRVmoIAEtOq = list(Y1Pz6QNbB9LRMvJl0r2jI.values())
		del Y1Pz6QNbB9LRMvJl0r2jI
		oop0Y68xvJzSjVumXDgGaiUbO9 = list(zip(ci9gsA8OPu,QwU8uMh1cH7LnyRVmoIAEtOq))
		del ci9gsA8OPu,QwU8uMh1cH7LnyRVmoIAEtOq
		oop0Y68xvJzSjVumXDgGaiUbO9 = sorted(oop0Y68xvJzSjVumXDgGaiUbO9)
	else: LS510M4qymPtYpw2RHzsjKaJ9nT += 2
	LLV36Id5hDrXCRu[BxP4plOuSfmjn8Xd51sUVgrqy]['__GROUPS__'] = oop0Y68xvJzSjVumXDgGaiUbO9
	del oop0Y68xvJzSjVumXDgGaiUbO9
	for LDRy15Hwv72mVgartIBWU,czG0PxAmlw4vtWrH5eL3RubT,sbat1zOx0HydLjm5qvTPgR,uuNDjbit4hOpx,PVvXoB0pye37Sckg45QNDGlw62FjE in WhqwJr0DRAE7[BxP4plOuSfmjn8Xd51sUVgrqy]:
		LLV36Id5hDrXCRu[BxP4plOuSfmjn8Xd51sUVgrqy][LDRy15Hwv72mVgartIBWU].append((czG0PxAmlw4vtWrH5eL3RubT,sbat1zOx0HydLjm5qvTPgR,uuNDjbit4hOpx,PVvXoB0pye37Sckg45QNDGlw62FjE))
	NrM3XJ8sD2pEHz(cmvIRA5eW2OiZQdyw4VX,60+int(15*LS510M4qymPtYpw2RHzsjKaJ9nT//PumF2YrWAxK9ha4jE),'تصنيع القوائم','الجزء رقم:-',str(LS510M4qymPtYpw2RHzsjKaJ9nT)+' / '+str(PumF2YrWAxK9ha4jE))
	if cmvIRA5eW2OiZQdyw4VX.iscanceled(): return
	LS510M4qymPtYpw2RHzsjKaJ9nT += 1
	del WhqwJr0DRAE7[BxP4plOuSfmjn8Xd51sUVgrqy]
	P9MuDKe5WdAkqQTEJ8mU7[BxP4plOuSfmjn8Xd51sUVgrqy] = list(LLV36Id5hDrXCRu[BxP4plOuSfmjn8Xd51sUVgrqy].keys())
	J6bUR4WnHLkElTAoO[BxP4plOuSfmjn8Xd51sUVgrqy] = len(P9MuDKe5WdAkqQTEJ8mU7[BxP4plOuSfmjn8Xd51sUVgrqy])
	PY7Om8BICLceMJq26 += J6bUR4WnHLkElTAoO[BxP4plOuSfmjn8Xd51sUVgrqy]
	return
def HPm4rJk956nK2A7gqvIca(rA1p4eTdbhi69sotZkuP0QafYNDn,BxP4plOuSfmjn8Xd51sUVgrqy):
	global cmvIRA5eW2OiZQdyw4VX,WhqwJr0DRAE7,oigfd9M6WRy3Pt2m84CjDZUxe,LLV36Id5hDrXCRu,J6bUR4WnHLkElTAoO,P9MuDKe5WdAkqQTEJ8mU7,PY7Om8BICLceMJq26,LS510M4qymPtYpw2RHzsjKaJ9nT,PumF2YrWAxK9ha4jE
	AGBKp17l0b6VURQ = uwgvq5oDNAdsfCPEcYy7HFRBWrkmj6(rA1p4eTdbhi69sotZkuP0QafYNDn,BxP4plOuSfmjn8Xd51sUVgrqy)
	for LLsyevc6KqA4QG in range(1+J6bUR4WnHLkElTAoO[BxP4plOuSfmjn8Xd51sUVgrqy]//273):
		wiIULybjoP8uHZXVvsBSEQrCfNT1tz = []
		bo8yNTEfD2AIOH7pntR0ULw31JCec = P9MuDKe5WdAkqQTEJ8mU7[BxP4plOuSfmjn8Xd51sUVgrqy][0:273]
		for LDRy15Hwv72mVgartIBWU in bo8yNTEfD2AIOH7pntR0ULw31JCec:
			wiIULybjoP8uHZXVvsBSEQrCfNT1tz.append(LLV36Id5hDrXCRu[BxP4plOuSfmjn8Xd51sUVgrqy][LDRy15Hwv72mVgartIBWU])
		PGudrhJF8iDkSq96XVHEQZYf5L(AGBKp17l0b6VURQ,BxP4plOuSfmjn8Xd51sUVgrqy,bo8yNTEfD2AIOH7pntR0ULw31JCec,wiIULybjoP8uHZXVvsBSEQrCfNT1tz,t58tnzAgevxkoIOdMFbE2PsD64q0C9,True)
		oigfd9M6WRy3Pt2m84CjDZUxe += len(bo8yNTEfD2AIOH7pntR0ULw31JCec)
		NrM3XJ8sD2pEHz(cmvIRA5eW2OiZQdyw4VX,75+int(20*oigfd9M6WRy3Pt2m84CjDZUxe//PY7Om8BICLceMJq26),'تخزين القوائم','القائمة رقم:-',str(oigfd9M6WRy3Pt2m84CjDZUxe)+' / '+str(PY7Om8BICLceMJq26))
		if cmvIRA5eW2OiZQdyw4VX.iscanceled(): return
		del P9MuDKe5WdAkqQTEJ8mU7[BxP4plOuSfmjn8Xd51sUVgrqy][0:273]
	del LLV36Id5hDrXCRu[BxP4plOuSfmjn8Xd51sUVgrqy],P9MuDKe5WdAkqQTEJ8mU7[BxP4plOuSfmjn8Xd51sUVgrqy],J6bUR4WnHLkElTAoO[BxP4plOuSfmjn8Xd51sUVgrqy]
	return
def I1Ix8jpZKSUYFDVwMXrltHCcsW9B(rA1p4eTdbhi69sotZkuP0QafYNDn,KHiQ5Z6kBVYoPjUsa,ZUPyYNpfLTgIFG4rW38So1kqzRE7du=True):
	YK89a5A7H1j4vnEfRSglMycGotwz = 'عدد فيديوهات جميع الروابط'
	vvpt1F78AJ = uwgvq5oDNAdsfCPEcYy7HFRBWrkmj6(rA1p4eTdbhi69sotZkuP0QafYNDn,'LIVE_ORIGINAL_GROUPED')
	icOvWbJFShmZfUnBz = uwgvq5oDNAdsfCPEcYy7HFRBWrkmj6(rA1p4eTdbhi69sotZkuP0QafYNDn,'VOD_ORIGINAL_GROUPED')
	if KHiQ5Z6kBVYoPjUsa:
		YK89a5A7H1j4vnEfRSglMycGotwz = 'عدد فيديوهات رابط '+iP9ZMSrYOJQhB73CN2yj4Kg1p6V5aT[int(KHiQ5Z6kBVYoPjUsa)]
		KHiQ5Z6kBVYoPjUsa = '_'+KHiQ5Z6kBVYoPjUsa
	vfjIFokMpg0 = SS2OK7hjLagvUAm(vvpt1F78AJ,'int','IGNORED'+KHiQ5Z6kBVYoPjUsa,'__COUNT__')
	t72Em8HjyYdW = SS2OK7hjLagvUAm(vvpt1F78AJ,'int','LIVE_ORIGINAL_GROUPED'+KHiQ5Z6kBVYoPjUsa,'__COUNT__')
	o0ochzOyXqSu = SS2OK7hjLagvUAm(icOvWbJFShmZfUnBz,'int','VOD_ORIGINAL_GROUPED'+KHiQ5Z6kBVYoPjUsa,'__COUNT__')
	DszRcIYpuK4a = SS2OK7hjLagvUAm(vvpt1F78AJ,'int','LIVE_GROUPED'+KHiQ5Z6kBVYoPjUsa,'__COUNT__')
	f8qZvOskogU = SS2OK7hjLagvUAm(vvpt1F78AJ,'int','LIVE_UNKNOWN_GROUPED'+KHiQ5Z6kBVYoPjUsa,'__COUNT__')
	j9m5ZuJLroxB7FAKGpe4UlqN = SS2OK7hjLagvUAm(vvpt1F78AJ,'int','VOD_MOVIES_GROUPED'+KHiQ5Z6kBVYoPjUsa,'__COUNT__')
	ljr6JA9HMLsRqfPhEiyUu5 = SS2OK7hjLagvUAm(icOvWbJFShmZfUnBz,'int','VOD_SERIES_GROUPED'+KHiQ5Z6kBVYoPjUsa,'__COUNT__')
	OMyZ9Q4jIKRwVSF1kWd0HAln = SS2OK7hjLagvUAm(vvpt1F78AJ,'int','VOD_UNKNOWN_GROUPED'+KHiQ5Z6kBVYoPjUsa,'__COUNT__')
	P9MuDKe5WdAkqQTEJ8mU7 = SS2OK7hjLagvUAm(icOvWbJFShmZfUnBz,'list','VOD_SERIES_GROUPED'+KHiQ5Z6kBVYoPjUsa,'__GROUPS__')
	Y9gh8ucrGMFfxPRlSo5aL14zK3p7Z = []
	for LDRy15Hwv72mVgartIBWU,PVvXoB0pye37Sckg45QNDGlw62FjE in P9MuDKe5WdAkqQTEJ8mU7:
		Yw3nRH6JUhXDcq9zfx = LDRy15Hwv72mVgartIBWU.split('__SERIES__')[1]
		Y9gh8ucrGMFfxPRlSo5aL14zK3p7Z.append(Yw3nRH6JUhXDcq9zfx)
	lFX5xSBc7pND = len(Y9gh8ucrGMFfxPRlSo5aL14zK3p7Z)
	rxZjzaTRFS5 = int(j9m5ZuJLroxB7FAKGpe4UlqN)+int(ljr6JA9HMLsRqfPhEiyUu5)+int(OMyZ9Q4jIKRwVSF1kWd0HAln)+int(f8qZvOskogU)+int(DszRcIYpuK4a)
	T7BXe6lmC4PJn21Iqvyw0GkAxdH = b8Qe150xVaJsnDSv
	T7BXe6lmC4PJn21Iqvyw0GkAxdH += 'قنوات: '+str(DszRcIYpuK4a)
	T7BXe6lmC4PJn21Iqvyw0GkAxdH += '   .   أفلام: '+str(j9m5ZuJLroxB7FAKGpe4UlqN)
	T7BXe6lmC4PJn21Iqvyw0GkAxdH += '\nمسلسلات: '+str(lFX5xSBc7pND)
	T7BXe6lmC4PJn21Iqvyw0GkAxdH += '   .   حلقات: '+str(ljr6JA9HMLsRqfPhEiyUu5)
	T7BXe6lmC4PJn21Iqvyw0GkAxdH += '\nقنوات مجهولة: '+str(f8qZvOskogU)
	T7BXe6lmC4PJn21Iqvyw0GkAxdH += '   .   فيدوهات مجهولة: '+str(OMyZ9Q4jIKRwVSF1kWd0HAln)
	T7BXe6lmC4PJn21Iqvyw0GkAxdH += '\nمجموع القنوات: '+str(t72Em8HjyYdW)
	T7BXe6lmC4PJn21Iqvyw0GkAxdH += '   .   مجموع الفيديوهات: '+str(o0ochzOyXqSu)
	T7BXe6lmC4PJn21Iqvyw0GkAxdH += '\n\nمجموع المضافة: '+str(rxZjzaTRFS5)
	T7BXe6lmC4PJn21Iqvyw0GkAxdH += '   .   مجموع المهملة: '+str(vfjIFokMpg0)
	if ZUPyYNpfLTgIFG4rW38So1kqzRE7du: tuJ9fQgDl8oineCrFPT('center',b8Qe150xVaJsnDSv,YK89a5A7H1j4vnEfRSglMycGotwz,T7BXe6lmC4PJn21Iqvyw0GkAxdH)
	jigC0F1aqXO5lxJ8 = T7BXe6lmC4PJn21Iqvyw0GkAxdH.replace('\n\n',eeN6dTEnkJxI)
	if not KHiQ5Z6kBVYoPjUsa: KHiQ5Z6kBVYoPjUsa = 'All'
	else: KHiQ5Z6kBVYoPjUsa = KHiQ5Z6kBVYoPjUsa[1]
	mwIxD3GBPgLVc2aq9(MtTygrzXFlQ,'.\tCounts of M3U videos   Folder: '+rA1p4eTdbhi69sotZkuP0QafYNDn+'   Sequence: '+KHiQ5Z6kBVYoPjUsa+eeN6dTEnkJxI+jigC0F1aqXO5lxJ8)
	return T7BXe6lmC4PJn21Iqvyw0GkAxdH
def VcF7wfAQhe3osv650(rA1p4eTdbhi69sotZkuP0QafYNDn,KHiQ5Z6kBVYoPjUsa,ZUPyYNpfLTgIFG4rW38So1kqzRE7du=True):
	if ZUPyYNpfLTgIFG4rW38So1kqzRE7du:
		Dltpz9hNv72iZFQPE158U = BjMmX1vNrnzSAf('center',b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'مسح ملفات M3U','هل تريد مسح الملفات القديمة المخزنة في البرنامج ؟! \n\n علما انك تستطيع في أي وقت الدخول إلى قائمة M3U وجلب ملفات M3U جديدة')
		if Dltpz9hNv72iZFQPE158U!=1: return
		dhZ4awfOob5EQx = c5wOJ98CasX3VYykR1dKSN7qx.replace('___','_'+rA1p4eTdbhi69sotZkuP0QafYNDn+'_'+KHiQ5Z6kBVYoPjUsa)
		try: x76PfMyAp1L2WejkU3.remove(dhZ4awfOob5EQx)
		except: pass
	AGBKp17l0b6VURQ = uwgvq5oDNAdsfCPEcYy7HFRBWrkmj6(rA1p4eTdbhi69sotZkuP0QafYNDn,b8Qe150xVaJsnDSv)
	if KHiQ5Z6kBVYoPjUsa:
		WWeFusagMHfvOPImc4 = []
		for laGk8msO2v in YlEVuPr4LqIB6m7xHJ:
			WWeFusagMHfvOPImc4.append(laGk8msO2v+'_'+KHiQ5Z6kBVYoPjUsa)
		zqbhiLmQfC3VK9Arku(AGBKp17l0b6VURQ,'LINK_'+KHiQ5Z6kBVYoPjUsa)
	else:
		WWeFusagMHfvOPImc4 = YlEVuPr4LqIB6m7xHJ
		zqbhiLmQfC3VK9Arku(AGBKp17l0b6VURQ,'DUMMY')
		zqbhiLmQfC3VK9Arku(AGBKp17l0b6VURQ,'GROUPS')
		zqbhiLmQfC3VK9Arku(AGBKp17l0b6VURQ,'ITEMS')
		zqbhiLmQfC3VK9Arku(AGBKp17l0b6VURQ,'SEARCH')
	zqbhiLmQfC3VK9Arku(mshLJcKH1fv03yRnDOr4ZT,'SECTIONS_M3U','SECTIONS_M3U_'+rA1p4eTdbhi69sotZkuP0QafYNDn)
	zqbhiLmQfC3VK9Arku(mshLJcKH1fv03yRnDOr4ZT,'SECTIONS_M3U','SECTIONS_M3U_ALL')
	for BxP4plOuSfmjn8Xd51sUVgrqy in WWeFusagMHfvOPImc4:
		zqbhiLmQfC3VK9Arku(AGBKp17l0b6VURQ,BxP4plOuSfmjn8Xd51sUVgrqy)
	bb80Orl1IgxV6(False)
	WIiopcT2R9PdLt7VExswk0HmnYZe5(rA1p4eTdbhi69sotZkuP0QafYNDn)
	if ZUPyYNpfLTgIFG4rW38So1kqzRE7du: tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'رسالة من المبرمج','تم مسح جميع ملفات ـM3U')
	return
def yyq2ZDzu5wSeCKA84pxf7PRWTOrBtY(rA1p4eTdbhi69sotZkuP0QafYNDn=b8Qe150xVaJsnDSv,ZUPyYNpfLTgIFG4rW38So1kqzRE7du=True):
	if rA1p4eTdbhi69sotZkuP0QafYNDn:
		AGBKp17l0b6VURQ = uwgvq5oDNAdsfCPEcYy7HFRBWrkmj6(str(rA1p4eTdbhi69sotZkuP0QafYNDn),'DUMMY')
		qipmn9G8hQf74UsRD = SS2OK7hjLagvUAm(AGBKp17l0b6VURQ,'str','DUMMY','__DUMMY__')
		if qipmn9G8hQf74UsRD: return True
	else:
		rA1p4eTdbhi69sotZkuP0QafYNDn = '1'
		for agjsvpHDx8SX93WUhqizm5NbCQeGFY in range(1,PINQnUL6h3XA9at+1):
			AGBKp17l0b6VURQ = uwgvq5oDNAdsfCPEcYy7HFRBWrkmj6(str(agjsvpHDx8SX93WUhqizm5NbCQeGFY),'DUMMY')
			qipmn9G8hQf74UsRD = SS2OK7hjLagvUAm(AGBKp17l0b6VURQ,'str','DUMMY','__DUMMY__')
			if qipmn9G8hQf74UsRD: return True
	if ZUPyYNpfLTgIFG4rW38So1kqzRE7du:
		UaWiNfnrmDQT6wB5xFtqus = 'https://iptv-org.github.io/iptv/index.region.m3u'
		iWOjHoe4N6Q7JZc2AK0hpP = 'https://iptv-org.github.io/iptv/index.category.m3u'
		RcUkEQsmDpWMaPYxui2z = 'https://iptv-org.github.io/iptv/index.language.m3u'
		aAmRNVwIzEixGMdOKfXhTgpDrtu7L = 'https://iptv-org.github.io/iptv/index.country.m3u'
		pavgu7QKhnmbGMj = UaWiNfnrmDQT6wB5xFtqus+eeN6dTEnkJxI+iWOjHoe4N6Q7JZc2AK0hpP+eeN6dTEnkJxI+RcUkEQsmDpWMaPYxui2z+eeN6dTEnkJxI+aAmRNVwIzEixGMdOKfXhTgpDrtu7L
		Dltpz9hNv72iZFQPE158U = BjMmX1vNrnzSAf(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'رسالة من المبرمج','هذه القوائم تحتاج رابط فيديوهات نوعه M3U . وهو متوفر في الإنترنت مجانا . وأيضا تبيعه الشركات المختصة . الموقع أدناه فيه روابط مجانية وهي ليست ملك المبرمج (صاحب هذا البرنامج) . ولا علاقة للمبرمج بمحتوياتها . والمبرمج لا يتحمل أي مسؤولية بسبب استخدام روابط مجانية أو غير مجانية\n'+rC3Tlno96KjLDIvBaSWUbR8+'http://github.com/iptv-org/iptv'+hAIp8kmC36T5WFPMSXOwnNbtD+'\nالروابط أدناه مجانية ومأخوذة من الموقع أعلاه هل تريد استخدامها\n '+rC3Tlno96KjLDIvBaSWUbR8+pavgu7QKhnmbGMj+hAIp8kmC36T5WFPMSXOwnNbtD,profile='confirm_smallfont')
		if Dltpz9hNv72iZFQPE158U==1:
			hRWC8YSFvsm4JHOMVIne3jquZ.setSetting('av.m3u.url_'+str(rA1p4eTdbhi69sotZkuP0QafYNDn)+'_1',UaWiNfnrmDQT6wB5xFtqus)
			hRWC8YSFvsm4JHOMVIne3jquZ.setSetting('av.m3u.url_'+str(rA1p4eTdbhi69sotZkuP0QafYNDn)+'_2',iWOjHoe4N6Q7JZc2AK0hpP)
			hRWC8YSFvsm4JHOMVIne3jquZ.setSetting('av.m3u.url_'+str(rA1p4eTdbhi69sotZkuP0QafYNDn)+'_3',RcUkEQsmDpWMaPYxui2z)
			hRWC8YSFvsm4JHOMVIne3jquZ.setSetting('av.m3u.url_'+str(rA1p4eTdbhi69sotZkuP0QafYNDn)+'_4',aAmRNVwIzEixGMdOKfXhTgpDrtu7L)
			Dltpz9hNv72iZFQPE158U = BjMmX1vNrnzSAf(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'رسالة من المبرمج','للاستفادة من روابط M3U التي أنت أضفتها للبرنامج .. أنت بحاجة إلى جلب ملفات هذه الروابط الجديدة .. هل تريد الآن جلب ملفات روابط M3U التي أنت أضفتها للبرنامج ؟!')
			if Dltpz9hNv72iZFQPE158U==1:
				JefY4Il0gPLDmNRtpn5MaTAXCdvZE = exw87PJcKOSo30mLWTrhdpEYVMD(rA1p4eTdbhi69sotZkuP0QafYNDn)
				return JefY4Il0gPLDmNRtpn5MaTAXCdvZE
		else:
			YK89a5A7H1j4vnEfRSglMycGotwz = 'إضافة وتغيير رابط '+iP9ZMSrYOJQhB73CN2yj4Kg1p6V5aT[1]+' (مجلد '+iP9ZMSrYOJQhB73CN2yj4Kg1p6V5aT[int(rA1p4eTdbhi69sotZkuP0QafYNDn)]+')'
			Dltpz9hNv72iZFQPE158U = BjMmX1vNrnzSAf(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,YK89a5A7H1j4vnEfRSglMycGotwz,'لإضافة رابط M3U .. أولا أفتح قائمة M3U .. وثانيا أنقر على إضافة رابط أو اشتراك M3U .. وثالثا أنقر على جلب ملفات ـM3U \n\n هل تريد إضافة أو تغيير رابط M3U الآن ؟!')
			if Dltpz9hNv72iZFQPE158U==1: NGe8Whf2qj5isU3cJaYd1wXx(rA1p4eTdbhi69sotZkuP0QafYNDn,'1')
	return False
def YZtbF9MC8LiySHKjmD4gkxwnsT3dRv(TTLD8UjCgSJGaHXF6hiY5NsEQfPyZM,rA1p4eTdbhi69sotZkuP0QafYNDn=b8Qe150xVaJsnDSv,BxP4plOuSfmjn8Xd51sUVgrqy=b8Qe150xVaJsnDSv,kR8Wp5NO9hcEvIQ1F4PM=b8Qe150xVaJsnDSv):
	if not kR8Wp5NO9hcEvIQ1F4PM: kR8Wp5NO9hcEvIQ1F4PM = '1'
	oGjfrQp5bLaN6dYFhkTx9sWJ,SHk0ThDndgJW,ZUPyYNpfLTgIFG4rW38So1kqzRE7du = JimhUH0SEf6w(TTLD8UjCgSJGaHXF6hiY5NsEQfPyZM)
	if not yyq2ZDzu5wSeCKA84pxf7PRWTOrBtY(rA1p4eTdbhi69sotZkuP0QafYNDn,ZUPyYNpfLTgIFG4rW38So1kqzRE7du): return
	if not oGjfrQp5bLaN6dYFhkTx9sWJ:
		oGjfrQp5bLaN6dYFhkTx9sWJ = FT2oXWtPQpVGuexmLqKN3srdzYn()
		if not oGjfrQp5bLaN6dYFhkTx9sWJ: return
	eoZ2gKUC7f40wWq19RXjGs6JBu = [b8Qe150xVaJsnDSv,'LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not BxP4plOuSfmjn8Xd51sUVgrqy:
		if not ZUPyYNpfLTgIFG4rW38So1kqzRE7du:
			if   '_M3U-LIVE_' in SHk0ThDndgJW: BxP4plOuSfmjn8Xd51sUVgrqy = eoZ2gKUC7f40wWq19RXjGs6JBu[1]
			elif '_M3U-MOVIES' in SHk0ThDndgJW: BxP4plOuSfmjn8Xd51sUVgrqy = eoZ2gKUC7f40wWq19RXjGs6JBu[2]
			elif '_M3U-SERIES' in SHk0ThDndgJW: BxP4plOuSfmjn8Xd51sUVgrqy = eoZ2gKUC7f40wWq19RXjGs6JBu[3]
			else: BxP4plOuSfmjn8Xd51sUVgrqy = eoZ2gKUC7f40wWq19RXjGs6JBu[0]
		else:
			xhn4wrzGX2sbegmRc86k = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			c9Wbh7raCVlyPKqpL6GwNZz1u = XXprCMzuNP2mElUxfdA('أختر البحث المناسب', xhn4wrzGX2sbegmRc86k)
			if c9Wbh7raCVlyPKqpL6GwNZz1u==-1: return
			BxP4plOuSfmjn8Xd51sUVgrqy = eoZ2gKUC7f40wWq19RXjGs6JBu[c9Wbh7raCVlyPKqpL6GwNZz1u]
	oGjfrQp5bLaN6dYFhkTx9sWJ = oGjfrQp5bLaN6dYFhkTx9sWJ+'_NODIALOGS_'
	if rA1p4eTdbhi69sotZkuP0QafYNDn: btuQcD9l23RWKJACB(oGjfrQp5bLaN6dYFhkTx9sWJ,rA1p4eTdbhi69sotZkuP0QafYNDn,BxP4plOuSfmjn8Xd51sUVgrqy,kR8Wp5NO9hcEvIQ1F4PM)
	else:
		for rA1p4eTdbhi69sotZkuP0QafYNDn in range(1,PINQnUL6h3XA9at+1):
			btuQcD9l23RWKJACB(oGjfrQp5bLaN6dYFhkTx9sWJ,str(rA1p4eTdbhi69sotZkuP0QafYNDn),BxP4plOuSfmjn8Xd51sUVgrqy,kR8Wp5NO9hcEvIQ1F4PM)
		GyjmfosC59Jub[:] = sorted(GyjmfosC59Jub,reverse=False,key=lambda w2wJmSDK8fitdLVAaMRpNEPGc0g: w2wJmSDK8fitdLVAaMRpNEPGc0g[1].lower())
	return
def btuQcD9l23RWKJACB(TTLD8UjCgSJGaHXF6hiY5NsEQfPyZM,rA1p4eTdbhi69sotZkuP0QafYNDn,BxP4plOuSfmjn8Xd51sUVgrqy=b8Qe150xVaJsnDSv,kR8Wp5NO9hcEvIQ1F4PM=b8Qe150xVaJsnDSv):
	if not kR8Wp5NO9hcEvIQ1F4PM: kR8Wp5NO9hcEvIQ1F4PM = '1'
	oGjfrQp5bLaN6dYFhkTx9sWJ,SHk0ThDndgJW,ZUPyYNpfLTgIFG4rW38So1kqzRE7du = JimhUH0SEf6w(TTLD8UjCgSJGaHXF6hiY5NsEQfPyZM)
	if not rA1p4eTdbhi69sotZkuP0QafYNDn: return
	if not yyq2ZDzu5wSeCKA84pxf7PRWTOrBtY(rA1p4eTdbhi69sotZkuP0QafYNDn,ZUPyYNpfLTgIFG4rW38So1kqzRE7du): return
	if not oGjfrQp5bLaN6dYFhkTx9sWJ:
		oGjfrQp5bLaN6dYFhkTx9sWJ = FT2oXWtPQpVGuexmLqKN3srdzYn()
		if not oGjfrQp5bLaN6dYFhkTx9sWJ: return
	eoZ2gKUC7f40wWq19RXjGs6JBu = [b8Qe150xVaJsnDSv,'LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not BxP4plOuSfmjn8Xd51sUVgrqy:
		if not ZUPyYNpfLTgIFG4rW38So1kqzRE7du:
			if   '_M3U-LIVE_' in SHk0ThDndgJW: BxP4plOuSfmjn8Xd51sUVgrqy = eoZ2gKUC7f40wWq19RXjGs6JBu[1]
			elif '_M3U-MOVIES' in SHk0ThDndgJW: BxP4plOuSfmjn8Xd51sUVgrqy = eoZ2gKUC7f40wWq19RXjGs6JBu[2]
			elif '_M3U-SERIES' in SHk0ThDndgJW: BxP4plOuSfmjn8Xd51sUVgrqy = eoZ2gKUC7f40wWq19RXjGs6JBu[3]
			else: BxP4plOuSfmjn8Xd51sUVgrqy = eoZ2gKUC7f40wWq19RXjGs6JBu[0]
		else:
			xhn4wrzGX2sbegmRc86k = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			c9Wbh7raCVlyPKqpL6GwNZz1u = XXprCMzuNP2mElUxfdA('أختر البحث المناسب', xhn4wrzGX2sbegmRc86k)
			if c9Wbh7raCVlyPKqpL6GwNZz1u==-1: return
			BxP4plOuSfmjn8Xd51sUVgrqy = eoZ2gKUC7f40wWq19RXjGs6JBu[c9Wbh7raCVlyPKqpL6GwNZz1u]
	Sxf0vyYusTcrE4k8DIGOHtejaplNX = oGjfrQp5bLaN6dYFhkTx9sWJ.lower()
	AGBKp17l0b6VURQ = uwgvq5oDNAdsfCPEcYy7HFRBWrkmj6(rA1p4eTdbhi69sotZkuP0QafYNDn,'SEARCH')
	kpd8hRM9mn = SS2OK7hjLagvUAm(AGBKp17l0b6VURQ,'list','SEARCH',(BxP4plOuSfmjn8Xd51sUVgrqy,Sxf0vyYusTcrE4k8DIGOHtejaplNX))
	if not kpd8hRM9mn:
		JpSlTw8rqMhx0fCU61RdnyzbuL,NB1Rt4e0YoO = [],[]
		if not BxP4plOuSfmjn8Xd51sUVgrqy: DTIKzlckP4VQWRw2aopLs = [1,2,3,4,5]
		else: DTIKzlckP4VQWRw2aopLs = [eoZ2gKUC7f40wWq19RXjGs6JBu.index(BxP4plOuSfmjn8Xd51sUVgrqy)]
		for H9JbVKORYEGt3jo2g in DTIKzlckP4VQWRw2aopLs:
			if H9JbVKORYEGt3jo2g!=3:
				xehYsVJtBRz = SS2OK7hjLagvUAm(AGBKp17l0b6VURQ,'dict',eoZ2gKUC7f40wWq19RXjGs6JBu[H9JbVKORYEGt3jo2g])
				del xehYsVJtBRz['__COUNT__']
				del xehYsVJtBRz['__GROUPS__']
				del xehYsVJtBRz['__SEQUENCED_COLUMNS__']
				P9MuDKe5WdAkqQTEJ8mU7 = list(xehYsVJtBRz.keys())
				for LDRy15Hwv72mVgartIBWU in P9MuDKe5WdAkqQTEJ8mU7:
					for czG0PxAmlw4vtWrH5eL3RubT,sbat1zOx0HydLjm5qvTPgR,uuNDjbit4hOpx,PVvXoB0pye37Sckg45QNDGlw62FjE in xehYsVJtBRz[LDRy15Hwv72mVgartIBWU]:
						if Sxf0vyYusTcrE4k8DIGOHtejaplNX in sbat1zOx0HydLjm5qvTPgR.lower(): NB1Rt4e0YoO.append((sbat1zOx0HydLjm5qvTPgR,uuNDjbit4hOpx,PVvXoB0pye37Sckg45QNDGlw62FjE))
					del xehYsVJtBRz[LDRy15Hwv72mVgartIBWU]
				del xehYsVJtBRz
			else: P9MuDKe5WdAkqQTEJ8mU7 = SS2OK7hjLagvUAm(AGBKp17l0b6VURQ,'list',eoZ2gKUC7f40wWq19RXjGs6JBu[H9JbVKORYEGt3jo2g],'__GROUPS__')
			for LDRy15Hwv72mVgartIBWU in P9MuDKe5WdAkqQTEJ8mU7:
				try: LDRy15Hwv72mVgartIBWU,PVvXoB0pye37Sckg45QNDGlw62FjE = LDRy15Hwv72mVgartIBWU
				except: PVvXoB0pye37Sckg45QNDGlw62FjE = b8Qe150xVaJsnDSv
				if Sxf0vyYusTcrE4k8DIGOHtejaplNX in LDRy15Hwv72mVgartIBWU.lower():
					if H9JbVKORYEGt3jo2g!=3: sLHFWJoU26bh0ruT9 = LDRy15Hwv72mVgartIBWU
					else:
						r23ClajcOPNvbi1,JJFHTRzPNhAsnZOa0WMwpuxylvr6 = LDRy15Hwv72mVgartIBWU.split('__SERIES__')
						if Sxf0vyYusTcrE4k8DIGOHtejaplNX in r23ClajcOPNvbi1.lower(): sLHFWJoU26bh0ruT9 = r23ClajcOPNvbi1
						else: sLHFWJoU26bh0ruT9 = JJFHTRzPNhAsnZOa0WMwpuxylvr6
					JpSlTw8rqMhx0fCU61RdnyzbuL.append((LDRy15Hwv72mVgartIBWU,sLHFWJoU26bh0ruT9,eoZ2gKUC7f40wWq19RXjGs6JBu[H9JbVKORYEGt3jo2g],PVvXoB0pye37Sckg45QNDGlw62FjE))
			del P9MuDKe5WdAkqQTEJ8mU7
		JpSlTw8rqMhx0fCU61RdnyzbuL = set(JpSlTw8rqMhx0fCU61RdnyzbuL)
		NB1Rt4e0YoO = set(NB1Rt4e0YoO)
		JpSlTw8rqMhx0fCU61RdnyzbuL = sorted(JpSlTw8rqMhx0fCU61RdnyzbuL,reverse=False,key=lambda w2wJmSDK8fitdLVAaMRpNEPGc0g: w2wJmSDK8fitdLVAaMRpNEPGc0g[1])
		NB1Rt4e0YoO = sorted(NB1Rt4e0YoO,reverse=False,key=lambda w2wJmSDK8fitdLVAaMRpNEPGc0g: w2wJmSDK8fitdLVAaMRpNEPGc0g[0])
		PGudrhJF8iDkSq96XVHEQZYf5L(AGBKp17l0b6VURQ,'SEARCH',(BxP4plOuSfmjn8Xd51sUVgrqy,Sxf0vyYusTcrE4k8DIGOHtejaplNX),(JpSlTw8rqMhx0fCU61RdnyzbuL,NB1Rt4e0YoO),t58tnzAgevxkoIOdMFbE2PsD64q0C9)
	else: JpSlTw8rqMhx0fCU61RdnyzbuL,NB1Rt4e0YoO = kpd8hRM9mn
	P9MuDKe5WdAkqQTEJ8mU7 = len(JpSlTw8rqMhx0fCU61RdnyzbuL)
	aZ6ejNd2WlXJOkv4IgEcq9FK = len(NB1Rt4e0YoO)
	EAlZ2zKn6uagcqtY3yBoMxDmSbOwk = int(kR8Wp5NO9hcEvIQ1F4PM)
	ddmVz7wXL2OGIkWnTAyjpFRru4ts = max(0,(EAlZ2zKn6uagcqtY3yBoMxDmSbOwk-1)*100)
	fPK8hdEpryuR3cHbCBW = max(0,EAlZ2zKn6uagcqtY3yBoMxDmSbOwk*100)
	N7A20ErJTmnMIFce5df93vub8DqlZ = max(0,ddmVz7wXL2OGIkWnTAyjpFRru4ts-P9MuDKe5WdAkqQTEJ8mU7)
	o9Ejl6hpGYRkf = max(0,fPK8hdEpryuR3cHbCBW-P9MuDKe5WdAkqQTEJ8mU7)
	for LDRy15Hwv72mVgartIBWU,sLHFWJoU26bh0ruT9,NI1kYw9iaO7rctd,PVvXoB0pye37Sckg45QNDGlw62FjE in JpSlTw8rqMhx0fCU61RdnyzbuL[ddmVz7wXL2OGIkWnTAyjpFRru4ts:fPK8hdEpryuR3cHbCBW]:
		MQtuaShrKTbdZFJ5nsR7D('folder',i4lR3ISvhqJFGBwcrNtCY2mAZu9+sLHFWJoU26bh0ruT9,NI1kYw9iaO7rctd,714,PVvXoB0pye37Sckg45QNDGlw62FjE,'1',LDRy15Hwv72mVgartIBWU,b8Qe150xVaJsnDSv,{'folder':rA1p4eTdbhi69sotZkuP0QafYNDn})
	del JpSlTw8rqMhx0fCU61RdnyzbuL
	for sbat1zOx0HydLjm5qvTPgR,uuNDjbit4hOpx,PVvXoB0pye37Sckg45QNDGlw62FjE in NB1Rt4e0YoO[N7A20ErJTmnMIFce5df93vub8DqlZ:o9Ejl6hpGYRkf]:
		GwL4iI7vMzyg0TQWY1lq8RSN = Gz7MH0glBw8Eb(uuNDjbit4hOpx)
		A60AIQZCYRzdhaeWfOtmrSUVoq2nN = 'live'
		if '.mkv' in GwL4iI7vMzyg0TQWY1lq8RSN or 'VOD' in BxP4plOuSfmjn8Xd51sUVgrqy: A60AIQZCYRzdhaeWfOtmrSUVoq2nN = 'video'
		MQtuaShrKTbdZFJ5nsR7D(A60AIQZCYRzdhaeWfOtmrSUVoq2nN,i4lR3ISvhqJFGBwcrNtCY2mAZu9+sbat1zOx0HydLjm5qvTPgR,uuNDjbit4hOpx,715,PVvXoB0pye37Sckg45QNDGlw62FjE,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,{'folder':rA1p4eTdbhi69sotZkuP0QafYNDn})
	del NB1Rt4e0YoO
	ZCkrKgME82qhdlIzND1oSQH(rA1p4eTdbhi69sotZkuP0QafYNDn,kR8Wp5NO9hcEvIQ1F4PM,BxP4plOuSfmjn8Xd51sUVgrqy,719,P9MuDKe5WdAkqQTEJ8mU7+aZ6ejNd2WlXJOkv4IgEcq9FK,oGjfrQp5bLaN6dYFhkTx9sWJ+'_NODIALOGS_')
	return
def ZCkrKgME82qhdlIzND1oSQH(rA1p4eTdbhi69sotZkuP0QafYNDn,kR8Wp5NO9hcEvIQ1F4PM,BxP4plOuSfmjn8Xd51sUVgrqy,ZZtDTHnBXMz,rxZjzaTRFS5,pnmsJqCWIHVk2Y6xPvl9Q0Ez8r):
	if not kR8Wp5NO9hcEvIQ1F4PM: kR8Wp5NO9hcEvIQ1F4PM = '1'
	if kR8Wp5NO9hcEvIQ1F4PM!='1': MQtuaShrKTbdZFJ5nsR7D('folder',i4lR3ISvhqJFGBwcrNtCY2mAZu9+'صفحة '+str(1),BxP4plOuSfmjn8Xd51sUVgrqy,ZZtDTHnBXMz,b8Qe150xVaJsnDSv,str(1),pnmsJqCWIHVk2Y6xPvl9Q0Ez8r,b8Qe150xVaJsnDSv,{'folder':rA1p4eTdbhi69sotZkuP0QafYNDn})
	if not rxZjzaTRFS5: rxZjzaTRFS5 = 0
	Xbs7iefrg0GzRKF8 = int(rxZjzaTRFS5/100)+1
	for EAlZ2zKn6uagcqtY3yBoMxDmSbOwk in range(2,Xbs7iefrg0GzRKF8):
		FVOybXuJh062gNajtPGkm5vLo = (EAlZ2zKn6uagcqtY3yBoMxDmSbOwk%10==0 or int(kR8Wp5NO9hcEvIQ1F4PM)-4<EAlZ2zKn6uagcqtY3yBoMxDmSbOwk<int(kR8Wp5NO9hcEvIQ1F4PM)+4)
		SQTnRFboZe86MDadJLWpB9NiKVqOG4 = (FVOybXuJh062gNajtPGkm5vLo and int(kR8Wp5NO9hcEvIQ1F4PM)-40<EAlZ2zKn6uagcqtY3yBoMxDmSbOwk<int(kR8Wp5NO9hcEvIQ1F4PM)+40)
		if str(EAlZ2zKn6uagcqtY3yBoMxDmSbOwk)!=kR8Wp5NO9hcEvIQ1F4PM and (EAlZ2zKn6uagcqtY3yBoMxDmSbOwk%100==0 or SQTnRFboZe86MDadJLWpB9NiKVqOG4):
			MQtuaShrKTbdZFJ5nsR7D('folder',i4lR3ISvhqJFGBwcrNtCY2mAZu9+'صفحة '+str(EAlZ2zKn6uagcqtY3yBoMxDmSbOwk),BxP4plOuSfmjn8Xd51sUVgrqy,ZZtDTHnBXMz,b8Qe150xVaJsnDSv,str(EAlZ2zKn6uagcqtY3yBoMxDmSbOwk),pnmsJqCWIHVk2Y6xPvl9Q0Ez8r,b8Qe150xVaJsnDSv,{'folder':rA1p4eTdbhi69sotZkuP0QafYNDn})
	if str(Xbs7iefrg0GzRKF8)!=kR8Wp5NO9hcEvIQ1F4PM: MQtuaShrKTbdZFJ5nsR7D('folder',i4lR3ISvhqJFGBwcrNtCY2mAZu9+'أخر صفحة '+str(Xbs7iefrg0GzRKF8),BxP4plOuSfmjn8Xd51sUVgrqy,ZZtDTHnBXMz,b8Qe150xVaJsnDSv,str(Xbs7iefrg0GzRKF8),pnmsJqCWIHVk2Y6xPvl9Q0Ez8r,b8Qe150xVaJsnDSv,{'folder':rA1p4eTdbhi69sotZkuP0QafYNDn})
	return
def uwgvq5oDNAdsfCPEcYy7HFRBWrkmj6(rA1p4eTdbhi69sotZkuP0QafYNDn,BxP4plOuSfmjn8Xd51sUVgrqy):
	AGBKp17l0b6VURQ = OQ4oLMtwZN7vch.replace('___','_'+rA1p4eTdbhi69sotZkuP0QafYNDn)
	return AGBKp17l0b6VURQ
def exw87PJcKOSo30mLWTrhdpEYVMD(rA1p4eTdbhi69sotZkuP0QafYNDn):
	AGBKp17l0b6VURQ = uwgvq5oDNAdsfCPEcYy7HFRBWrkmj6(rA1p4eTdbhi69sotZkuP0QafYNDn,b8Qe150xVaJsnDSv)
	Dltpz9hNv72iZFQPE158U = BjMmX1vNrnzSAf('center',b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'رسالة من المبرمج','جلب ملفات M3U جديدة قد تحتاج عدة دقائق .. هل تريد أن تجلب الملفات الآن ؟!')
	if Dltpz9hNv72iZFQPE158U!=1: return False
	zmpSMKk62PBL(rA1p4eTdbhi69sotZkuP0QafYNDn,False)
	geJUtF9bysMSqEm3a5hRiH02CWLPz = [0]
	for iNdb241X5QmGjzfhopLkc0wUgCl6DM in range(1,yrzdN9Z7pLmkjI+1):
		VLIC9xSDcTOHnm2qwd3F4t = hRWC8YSFvsm4JHOMVIne3jquZ.getSetting('av.m3u.url_'+rA1p4eTdbhi69sotZkuP0QafYNDn+'_'+str(iNdb241X5QmGjzfhopLkc0wUgCl6DM))
		if VLIC9xSDcTOHnm2qwd3F4t: jiMFRB3HEmDX5JUNd80ybKuGAxCZP(rA1p4eTdbhi69sotZkuP0QafYNDn,str(iNdb241X5QmGjzfhopLkc0wUgCl6DM))
		geJUtF9bysMSqEm3a5hRiH02CWLPz.append(0)
	for BxP4plOuSfmjn8Xd51sUVgrqy in YlEVuPr4LqIB6m7xHJ:
		ZjP7JfQs1K6o32OREWibApBay,lzhv0HiqYGbMx3X1C,ENQBv8XoZetqUmr,dyTw1mvofKgGAP,Y1Pz6QNbB9LRMvJl0r2jI = 0,{},[],[],[]
		for iNdb241X5QmGjzfhopLkc0wUgCl6DM in range(1,yrzdN9Z7pLmkjI+1):
			NI1kYw9iaO7rctd = BxP4plOuSfmjn8Xd51sUVgrqy+'_'+str(iNdb241X5QmGjzfhopLkc0wUgCl6DM)
			WhqwJr0DRAE7 = SS2OK7hjLagvUAm(AGBKp17l0b6VURQ,'dict',NI1kYw9iaO7rctd)
			try:
				VhaA5crD4YKJIC2s1ig = WhqwJr0DRAE7['__GROUPS__']
				vvKNfzy0VtHxObGpT = WhqwJr0DRAE7['__COUNT__']
			except: VhaA5crD4YKJIC2s1ig,vvKNfzy0VtHxObGpT = [],'0'
			for BBXprbjY14tgLaHkx0GmSQTn in VhaA5crD4YKJIC2s1ig:
				LDRy15Hwv72mVgartIBWU,ChvkSxHr6QoKJg = BBXprbjY14tgLaHkx0GmSQTn
				xehYsVJtBRz = WhqwJr0DRAE7[LDRy15Hwv72mVgartIBWU]
				if LDRy15Hwv72mVgartIBWU not in dyTw1mvofKgGAP:
					dyTw1mvofKgGAP.append(LDRy15Hwv72mVgartIBWU)
					Y1Pz6QNbB9LRMvJl0r2jI.append(BBXprbjY14tgLaHkx0GmSQTn)
					lzhv0HiqYGbMx3X1C[LDRy15Hwv72mVgartIBWU] = []
				lzhv0HiqYGbMx3X1C[LDRy15Hwv72mVgartIBWU] += xehYsVJtBRz
			zqbhiLmQfC3VK9Arku(AGBKp17l0b6VURQ,NI1kYw9iaO7rctd)
			PGudrhJF8iDkSq96XVHEQZYf5L(AGBKp17l0b6VURQ,NI1kYw9iaO7rctd,'__COUNT__',vvKNfzy0VtHxObGpT,t58tnzAgevxkoIOdMFbE2PsD64q0C9)
			geJUtF9bysMSqEm3a5hRiH02CWLPz[iNdb241X5QmGjzfhopLkc0wUgCl6DM] += int(vvKNfzy0VtHxObGpT)
		for LDRy15Hwv72mVgartIBWU in dyTw1mvofKgGAP:
			xehYsVJtBRz = list(set(lzhv0HiqYGbMx3X1C[LDRy15Hwv72mVgartIBWU]))
			if 'SORTED' in BxP4plOuSfmjn8Xd51sUVgrqy: xehYsVJtBRz = sorted(xehYsVJtBRz,reverse=False,key=lambda key: key[1].lower())
			ZjP7JfQs1K6o32OREWibApBay += len(xehYsVJtBRz)
			ENQBv8XoZetqUmr.append(xehYsVJtBRz)
		PGudrhJF8iDkSq96XVHEQZYf5L(AGBKp17l0b6VURQ,BxP4plOuSfmjn8Xd51sUVgrqy,'__COUNT__',str(ZjP7JfQs1K6o32OREWibApBay),t58tnzAgevxkoIOdMFbE2PsD64q0C9)
		PGudrhJF8iDkSq96XVHEQZYf5L(AGBKp17l0b6VURQ,BxP4plOuSfmjn8Xd51sUVgrqy,'__GROUPS__',Y1Pz6QNbB9LRMvJl0r2jI,t58tnzAgevxkoIOdMFbE2PsD64q0C9)
		PGudrhJF8iDkSq96XVHEQZYf5L(AGBKp17l0b6VURQ,BxP4plOuSfmjn8Xd51sUVgrqy,dyTw1mvofKgGAP,ENQBv8XoZetqUmr,t58tnzAgevxkoIOdMFbE2PsD64q0C9,True)
	Zc6VWEbuF7YfvQAwMPs5 = False
	for iNdb241X5QmGjzfhopLkc0wUgCl6DM in range(1,yrzdN9Z7pLmkjI+1):
		if int(geJUtF9bysMSqEm3a5hRiH02CWLPz[iNdb241X5QmGjzfhopLkc0wUgCl6DM])>0:
			VLIC9xSDcTOHnm2qwd3F4t = hRWC8YSFvsm4JHOMVIne3jquZ.getSetting('av.m3u.url_'+rA1p4eTdbhi69sotZkuP0QafYNDn+'_'+str(iNdb241X5QmGjzfhopLkc0wUgCl6DM))
			PGudrhJF8iDkSq96XVHEQZYf5L(AGBKp17l0b6VURQ,'LINK_'+str(iNdb241X5QmGjzfhopLkc0wUgCl6DM),'__LINK__',VLIC9xSDcTOHnm2qwd3F4t,t58tnzAgevxkoIOdMFbE2PsD64q0C9)
			Zc6VWEbuF7YfvQAwMPs5 = True
	PGudrhJF8iDkSq96XVHEQZYf5L(AGBKp17l0b6VURQ,'DUMMY','__DUMMY__','DUMMY',t58tnzAgevxkoIOdMFbE2PsD64q0C9)
	if not Zc6VWEbuF7YfvQAwMPs5:
		tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'رسالة من المبرمج','فشل بسحب ملفات M3U .. أحتمال روابط M3U التي أنت أضفتها للبرنامج غير صحيحة .. علما أن هذه الخدمة تحتاج منك أن تضيف الرابط بنفسك للبرنامج باستخدام قائمة M3U الموجودة في هذا البرنامج')
		return False
	tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'رسالة من المبرمج','تم جلب ملفات M3U جديدة')
	b7n4Kjtk3OuhAm0aFNo5wfHgs(rA1p4eTdbhi69sotZkuP0QafYNDn)
	bb80Orl1IgxV6(False)
	qMGn9u2ckaXejCgUQhYTDP(False)
	return True
def b7n4Kjtk3OuhAm0aFNo5wfHgs(rA1p4eTdbhi69sotZkuP0QafYNDn):
	AGBKp17l0b6VURQ = uwgvq5oDNAdsfCPEcYy7HFRBWrkmj6(rA1p4eTdbhi69sotZkuP0QafYNDn,b8Qe150xVaJsnDSv)
	if not yyq2ZDzu5wSeCKA84pxf7PRWTOrBtY(rA1p4eTdbhi69sotZkuP0QafYNDn,True): return
	for iNdb241X5QmGjzfhopLkc0wUgCl6DM in range(1,yrzdN9Z7pLmkjI+1):
		VLIC9xSDcTOHnm2qwd3F4t = SS2OK7hjLagvUAm(AGBKp17l0b6VURQ,'str','LINK_'+str(iNdb241X5QmGjzfhopLkc0wUgCl6DM),'__LINK__')
		if VLIC9xSDcTOHnm2qwd3F4t: T7BXe6lmC4PJn21Iqvyw0GkAxdH = I1Ix8jpZKSUYFDVwMXrltHCcsW9B(rA1p4eTdbhi69sotZkuP0QafYNDn,str(iNdb241X5QmGjzfhopLkc0wUgCl6DM))
	I1Ix8jpZKSUYFDVwMXrltHCcsW9B(rA1p4eTdbhi69sotZkuP0QafYNDn,b8Qe150xVaJsnDSv)
	return
def zmpSMKk62PBL(rA1p4eTdbhi69sotZkuP0QafYNDn,ZUPyYNpfLTgIFG4rW38So1kqzRE7du):
	if ZUPyYNpfLTgIFG4rW38So1kqzRE7du:
		Dltpz9hNv72iZFQPE158U = BjMmX1vNrnzSAf('center',b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'مسح ملفات ـM3U','هل تريد مسح الملفات القديمة المخزنة في البرنامج ؟! \n\n علما انك تستطيع في أي وقت الدخول إلى قائمة M3U وجلب ملفات M3U جديدة')
		if Dltpz9hNv72iZFQPE158U!=1: return
	AGBKp17l0b6VURQ = uwgvq5oDNAdsfCPEcYy7HFRBWrkmj6(rA1p4eTdbhi69sotZkuP0QafYNDn,b8Qe150xVaJsnDSv)
	try: x76PfMyAp1L2WejkU3.remove(AGBKp17l0b6VURQ)
	except: pass
	for iNdb241X5QmGjzfhopLkc0wUgCl6DM in range(1,yrzdN9Z7pLmkjI+1):
		zzIgsTAGUu0wQ8eEKq = c5wOJ98CasX3VYykR1dKSN7qx.replace('___','_'+rA1p4eTdbhi69sotZkuP0QafYNDn+'_'+str(iNdb241X5QmGjzfhopLkc0wUgCl6DM))
		J4Grupmf5q8t32IiabLUnMWV = x76PfMyAp1L2WejkU3.path.join(vIaQF8hqXeiJERYuD,zzIgsTAGUu0wQ8eEKq)
		try: x76PfMyAp1L2WejkU3.remove(J4Grupmf5q8t32IiabLUnMWV)
		except: pass
	zqbhiLmQfC3VK9Arku(mshLJcKH1fv03yRnDOr4ZT,'SECTIONS_M3U','SECTIONS_M3U_'+rA1p4eTdbhi69sotZkuP0QafYNDn)
	zqbhiLmQfC3VK9Arku(mshLJcKH1fv03yRnDOr4ZT,'SECTIONS_M3U','SECTIONS_M3U_ALL')
	if ZUPyYNpfLTgIFG4rW38So1kqzRE7du:
		tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'رسالة من المبرمج','تم مسح جميع ملفات ـM3U')
		qMGn9u2ckaXejCgUQhYTDP(False)
	return
def WIiopcT2R9PdLt7VExswk0HmnYZe5(rA1p4eTdbhi69sotZkuP0QafYNDn):
	dLz0kawybCP24Zq1VS6hXKm = hRWC8YSFvsm4JHOMVIne3jquZ.getSetting('av.language.provider')
	X5AD4r3iQUuLnP87t0Ncz1bq = hRWC8YSFvsm4JHOMVIne3jquZ.getSetting('av.language.code')
	zqbhiLmQfC3VK9Arku(mshLJcKH1fv03yRnDOr4ZT,'MENUS_CACHE_'+dLz0kawybCP24Zq1VS6hXKm+'_'+X5AD4r3iQUuLnP87t0Ncz1bq,'%_MU'+rA1p4eTdbhi69sotZkuP0QafYNDn+'_%')
	return
MMwVK8rb2lh1TvQpFxASWEPLuOdq5 = {
		 'AF':'Afghanistan'
		,'AL':'Albania'
		,'DZ':'Algeria'
		,'AS':'American Samoa'
		,'AD':'Andorra'
		,'AO':'Angola'
		,'AI':'Anguilla'
		,'AQ':'Antarctica'
		,'AG':'Antigua and Barbuda'
		,'AR':'Argentina'
		,'AM':'Armenia'
		,'AW':'Aruba'
		,'AU':'Australia'
		,'AT':'Austria'
		,'AZ':'Azerbaijan'
		,'BS':'Bahamas'
		,'BH':'Bahrain'
		,'BD':'Bangladesh'
		,'BB':'Barbados'
		,'BY':'Belarus'
		,'BE':'Belgium'
		,'BZ':'Belize'
		,'BJ':'Benin'
		,'BM':'Bermuda'
		,'BT':'Bhutan'
		,'BO':'Bolivia'
		,'BQ':'Bonaire'
		,'BA':'Bosnia and Herzegovina'
		,'BW':'Botswana'
		,'BV':'Bouvet Island'
		,'BR':'Brazil'
		,'IO':'British Indian Ocean Territory'
		,'VG':'British Virgin Islands'
		,'BN':'Brunei'
		,'BG':'Bulgaria'
		,'BF':'Burkina Faso'
		,'BI':'Burundi'
		,'KH':'Cambodia'
		,'CM':'Cameroon'
		,'CA':'Canada'
		,'CV':'Cape Verde'
		,'KY':'Cayman Islands'
		,'CF':'Central African Republic'
		,'TD':'Chad'
		,'CL':'Chile'
		,'CN':'China'
		,'CX':'Christmas Island'
		,'CC':'Cocos (Keeling) Islands'
		,'CO':'Colombia'
		,'KM':'Comoros'
		,'CK':'Cook Islands'
		,'CR':'Costa Rica'
		,'HR':'Croatia'
		,'CU':'Cuba'
		,'CW':'Curacao'
		,'CY':'Cyprus'
		,'CZ':'Czech Republic'
		,'CD':'Democratic Republic of the Congo'
		,'DK':'Denmark'
		,'DJ':'Djibouti'
		,'DM':'Dominica'
		,'DO':'Dominican Republic'
		,'TL':'East Timor'
		,'EC':'Ecuador'
		,'EG':'Egypt'
		,'SV':'El Salvador'
		,'GQ':'Equatorial Guinea'
		,'ER':'Eritrea'
		,'EE':'Estonia'
		,'ET':'Ethiopia'
		,'FK':'Falkland Islands'
		,'FO':'Faroe Islands'
		,'FJ':'Fiji'
		,'FI':'Finland'
		,'FR':'France'
		,'GF':'French Guiana'
		,'PF':'French Polynesia'
		,'TF':'French Southern Territories'
		,'GA':'Gabon'
		,'GM':'Gambia'
		,'GE':'Georgia'
		,'DE':'Germany'
		,'GH':'Ghana'
		,'GI':'Gibraltar'
		,'GR':'Greece'
		,'GL':'Greenland'
		,'GD':'Grenada'
		,'GP':'Guadeloupe'
		,'GU':'Guam'
		,'GT':'Guatemala'
		,'GG':'Guernsey'
		,'GN':'Guinea'
		,'GW':'Guinea-Bissau'
		,'GY':'Guyana'
		,'HT':'Haiti'
		,'HM':'Heard Island and McDonald Islands'
		,'HN':'Honduras'
		,'HK':'Hong Kong'
		,'HU':'Hungary'
		,'IS':'Iceland'
		,'IN':'India'
		,'ID':'Indonesia'
		,'IR':'Iran'
		,'IQ':'Iraq'
		,'IE':'Ireland'
		,'IM':'Isle of Man'
		,'IL':'Israel'
		,'IT':'Italy'
		,'CI':'Ivory Coast'
		,'JM':'Jamaica'
		,'JP':'Japan'
		,'JE':'Jersey'
		,'JO':'Jordan'
		,'KZ':'Kazakhstan'
		,'KE':'Kenya'
		,'KI':'Kiribati'
		,'XK':'Kosovo'
		,'KW':'Kuwait'
		,'KG':'Kyrgyzstan'
		,'LA':'Laos'
		,'LV':'Latvia'
		,'LB':'Lebanon'
		,'LS':'Lesotho'
		,'LR':'Liberia'
		,'LY':'Libya'
		,'LI':'Liechtenstein'
		,'LT':'Lithuania'
		,'LU':'Luxembourg'
		,'MO':'Macao'
		,'MG':'Madagascar'
		,'MW':'Malawi'
		,'MY':'Malaysia'
		,'MV':'Maldives'
		,'ML':'Mali'
		,'MT':'Malta'
		,'MH':'Marshall Islands'
		,'MQ':'Martinique'
		,'MR':'Mauritania'
		,'MU':'Mauritius'
		,'YT':'Mayotte'
		,'MX':'Mexico'
		,'FM':'Micronesia'
		,'MD':'Moldova'
		,'MC':'Monaco'
		,'MN':'Mongolia'
		,'ME':'Montenegro'
		,'MS':'Montserrat'
		,'MA':'Morocco'
		,'MZ':'Mozambique'
		,'MM':'Myanmar (Burma)'
		,'NA':'Namibia'
		,'NR':'Nauru'
		,'NP':'Nepal'
		,'NL':'Netherlands'
		,'NC':'New Caledonia'
		,'NZ':'New Zealand'
		,'NI':'Nicaragua'
		,'NE':'Niger'
		,'NG':'Nigeria'
		,'NU':'Niue'
		,'NF':'Norfolk Island'
		,'KP':'North Korea'
		,'MK':'North Macedonia'
		,'MP':'Northern Mariana Islands'
		,'NO':'Norway'
		,'OM':'Oman'
		,'PK':'Pakistan'
		,'PW':'Palau'
		,'PS':'Palestine'
		,'PA':'Panama'
		,'PG':'Papua New Guinea'
		,'PY':'Paraguay'
		,'PE':'Peru'
		,'PH':'Philippines'
		,'PN':'Pitcairn Islands'
		,'PL':'Poland'
		,'PT':'Portugal'
		,'PR':'Puerto Rico'
		,'QA':'Qatar'
		,'CG':'Republic of the Congo'
		,'RO':'Romania'
		,'RU':'Russia'
		,'RW':'Rwanda'
		,'RE':'Réunion'
		,'BL':'Saint Barthélemy'
		,'SH':'Saint Helena'
		,'KN':'Saint Kitts and Nevis'
		,'LC':'Saint Lucia'
		,'MF':'Saint Martin'
		,'PM':'Saint Pierre and Miquelon'
		,'VC':'Saint Vincent and the Grenadines'
		,'WS':'Samoa'
		,'SM':'San Marino'
		,'SA':'Saudi Arabia'
		,'SN':'Senegal'
		,'RS':'Serbia'
		,'SC':'Seychelles'
		,'SL':'Sierra Leone'
		,'SG':'Singapore'
		,'SX':'Sint Maarten'
		,'SK':'Slovakia'
		,'SI':'Slovenia'
		,'SB':'Solomon Islands'
		,'SO':'Somalia'
		,'ZA':'South Africa'
		,'GS':'South Georgia and the South Sandwich Islands'
		,'KR':'South Korea'
		,'SS':'South Sudan'
		,'ES':'Spain'
		,'LK':'Sri Lanka'
		,'SD':'Sudan'
		,'SR':'Suriname'
		,'SJ':'Svalbard and Jan Mayen'
		,'SZ':'Swaziland'
		,'SE':'Sweden'
		,'CH':'Switzerland'
		,'SY':'Syria'
		,'ST':'São Tomé and Príncipe'
		,'TW':'Taiwan'
		,'TJ':'Tajikistan'
		,'TZ':'Tanzania'
		,'TH':'Thailand'
		,'TG':'Togo'
		,'TK':'Tokelau'
		,'TO':'Tonga'
		,'TT':'Trinidad and Tobago'
		,'TN':'Tunisia'
		,'TR':'Turkey'
		,'TM':'Turkmenistan'
		,'TC':'Turks and Caicos Islands'
		,'TV':'Tuvalu'
		,'UM':'U.S. Minor Outlying Islands'
		,'VI':'U.S. Virgin Islands'
		,'UG':'Uganda'
		,'UA':'Ukraine'
		,'AE':'United Arab Emirates'
		,'UK':'United Kingdom'
		,'US':'United States'
		,'UY':'Uruguay'
		,'UZ':'Uzbekistan'
		,'VU':'Vanuatu'
		,'VA':'Vatican City'
		,'VE':'Venezuela'
		,'VN':'Vietnam'
		,'WF':'Wallis and Futuna'
		,'EH':'Western Sahara'
		,'YE':'Yemen'
		,'ZM':'Zambia'
		,'ZW':'Zimbabwe'
		,'AX':'Åland'
		}
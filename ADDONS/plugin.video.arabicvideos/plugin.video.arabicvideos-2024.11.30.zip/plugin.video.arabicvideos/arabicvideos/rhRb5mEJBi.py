# -*- coding: utf-8 -*-
from hIVCFnfxSO import *
QQ8pvXNcBfVkP5rRJ7o = 'GOOGLESEARCH'
WbzmKSZiuOYrBN7oysJ2dUv = '_GOS_'
def x8IFqMZeJj7suCR4AaGoNXfEHm(ZZtDTHnBXMz,uuNDjbit4hOpx,pnmsJqCWIHVk2Y6xPvl9Q0Ez8r):
	if   ZZtDTHnBXMz==1010: XXxlOLJ9KRjPH382WVCvr6n71 = Y72YmLgw4vqlHxTCkbeKSicasD()
	elif ZZtDTHnBXMz==1011: XXxlOLJ9KRjPH382WVCvr6n71 = nATzSwh2eMjbiv6y0r1QJC7lUuZ(pnmsJqCWIHVk2Y6xPvl9Q0Ez8r)
	elif ZZtDTHnBXMz==1012: XXxlOLJ9KRjPH382WVCvr6n71 = qqJHVyNLnWZskK2fg3cEQrwibFOC(uuNDjbit4hOpx,pnmsJqCWIHVk2Y6xPvl9Q0Ez8r)
	elif ZZtDTHnBXMz==1013: XXxlOLJ9KRjPH382WVCvr6n71 = Aip73u5PFbyZdgSXOtYG()
	elif ZZtDTHnBXMz==1014: XXxlOLJ9KRjPH382WVCvr6n71 = nndimOaNp5ce(uuNDjbit4hOpx,pnmsJqCWIHVk2Y6xPvl9Q0Ez8r)
	elif ZZtDTHnBXMz==1015: XXxlOLJ9KRjPH382WVCvr6n71 = XUF3JOeaft21GwoL64(pnmsJqCWIHVk2Y6xPvl9Q0Ez8r)
	elif ZZtDTHnBXMz==1016: XXxlOLJ9KRjPH382WVCvr6n71 = dicUTESRAXBrDPfM6a81Zys3zYL(pnmsJqCWIHVk2Y6xPvl9Q0Ez8r)
	elif ZZtDTHnBXMz==1018: XXxlOLJ9KRjPH382WVCvr6n71 = kstJfK6jHQWrXDSMRIGB7(pnmsJqCWIHVk2Y6xPvl9Q0Ez8r,-xkDunX3BfFiYG)
	elif ZZtDTHnBXMz==1019: XXxlOLJ9KRjPH382WVCvr6n71 = kstJfK6jHQWrXDSMRIGB7(pnmsJqCWIHVk2Y6xPvl9Q0Ez8r)
	else: XXxlOLJ9KRjPH382WVCvr6n71 = False
	return XXxlOLJ9KRjPH382WVCvr6n71
def Y72YmLgw4vqlHxTCkbeKSicasD():
	MQtuaShrKTbdZFJ5nsR7D('folder','بحث جوجل جديد',b8Qe150xVaJsnDSv,1019,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'_REMEMBERRESULTS_')
	MQtuaShrKTbdZFJ5nsR7D('link','كيف يعمل بحث جوجل','',1013)
	MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+'==== كلمات البحث المخزنة ===='+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999)
	ssHGOFoRvzanWq4wIDcQiy7VteUf5 = SS2OK7hjLagvUAm(mshLJcKH1fv03yRnDOr4ZT,'dict','GLOBALSEARCH_SPLITTED_GOOGLE')
	if ssHGOFoRvzanWq4wIDcQiy7VteUf5:
		ssHGOFoRvzanWq4wIDcQiy7VteUf5 = ssHGOFoRvzanWq4wIDcQiy7VteUf5['__SEQUENCED_COLUMNS__']
		for oGjfrQp5bLaN6dYFhkTx9sWJ in reversed(ssHGOFoRvzanWq4wIDcQiy7VteUf5):
			MQtuaShrKTbdZFJ5nsR7D('folder',oGjfrQp5bLaN6dYFhkTx9sWJ,b8Qe150xVaJsnDSv,1019,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,oGjfrQp5bLaN6dYFhkTx9sWJ)
	return
def kstJfK6jHQWrXDSMRIGB7(search,L1Jb09ScOun=xkDunX3BfFiYG):
	search,SHk0ThDndgJW,showDialogs = JimhUH0SEf6w(search)
	if search==b8Qe150xVaJsnDSv: search = FT2oXWtPQpVGuexmLqKN3srdzYn()
	if search==b8Qe150xVaJsnDSv: return
	RRk9Ki5nPSfAZqC = search.replace(WbzmKSZiuOYrBN7oysJ2dUv,b8Qe150xVaJsnDSv).lower()
	vM5rV2kc7Qd,VxUyMinZLJRDuoArdPG7mYBh = [],[]
	if L1Jb09ScOun>0: VxUyMinZLJRDuoArdPG7mYBh = SS2OK7hjLagvUAm(mshLJcKH1fv03yRnDOr4ZT,'list','GOOGLESEARCH_RESULTS',RRk9Ki5nPSfAZqC)
	if VxUyMinZLJRDuoArdPG7mYBh: vM5rV2kc7Qd,ccNAgum3ODr = VxUyMinZLJRDuoArdPG7mYBh
	if not VxUyMinZLJRDuoArdPG7mYBh or L1Jb09ScOun<0:
		wQmfeZD0pLnVbhIHagvyqYGur = POxU8lEHRFboK2tf4(RRk9Ki5nPSfAZqC,L1Jb09ScOun)
		vM5rV2kc7Qd,ccNAgum3ODr = [],[]
		for tgoJCpq8KGrdaUSjsLh0FTxDRPfIAB in wQmfeZD0pLnVbhIHagvyqYGur:
			name,pcA1dzy7LXwGfMPg9mTkuh5tine3,title,text,b89GuUX5OixP,TFAmLfwypkzsP1UYCMr8c = tgoJCpq8KGrdaUSjsLh0FTxDRPfIAB
			if name==TFAmLfwypkzsP1UYCMr8c: ccNAgum3ODr.append(tgoJCpq8KGrdaUSjsLh0FTxDRPfIAB)
			else: vM5rV2kc7Qd.append(tgoJCpq8KGrdaUSjsLh0FTxDRPfIAB)
		import jtKsxUZvgl
		if L1Jb09ScOun>=0: jtKsxUZvgl.osEQDReMbav(RRk9Ki5nPSfAZqC,'_GOOGLE',True)
		vM5rV2kc7Qd = sorted(vM5rV2kc7Qd,reverse=DD5cFIejQa2X4BgAu9GWPyJ3tC7,key=lambda key: key[LzYQg91SIxDeOGtCKd5])
		ccNAgum3ODr = sorted(ccNAgum3ODr,reverse=DD5cFIejQa2X4BgAu9GWPyJ3tC7,key=lambda key: key[LzYQg91SIxDeOGtCKd5])
		PGudrhJF8iDkSq96XVHEQZYf5L(mshLJcKH1fv03yRnDOr4ZT,'GOOGLESEARCH_RESULTS',RRk9Ki5nPSfAZqC,[vM5rV2kc7Qd,ccNAgum3ODr],xkDunX3BfFiYG)
		if L1Jb09ScOun<0:
			zqbhiLmQfC3VK9Arku(mshLJcKH1fv03yRnDOr4ZT,'GLOBALSEARCH_DETAILED_GOOGLE',RRk9Ki5nPSfAZqC)
			jtKsxUZvgl.osEQDReMbav(RRk9Ki5nPSfAZqC,'_GOOGLE',False)
			zqbhiLmQfC3VK9Arku(mshLJcKH1fv03yRnDOr4ZT,'GLOBALSEARCH_DIVIDED_GOOGLE',"%, '"+RRk9Ki5nPSfAZqC+"')")
			if vM5rV2kc7Qd: tuJ9fQgDl8oineCrFPT('','','رسالة من المبرمج','تم عمل بحث جوجل جديد وتم إيجاد\n\n'+str(len(vM5rV2kc7Qd))+'  موقع')
			else: vM5rV2kc7Qd,ccNAgum3ODr = pIgHcFRO2XNJ(RRk9Ki5nPSfAZqC,DD5cFIejQa2X4BgAu9GWPyJ3tC7)
	MQtuaShrKTbdZFJ5nsR7D('link','بحث جماعي لمواقع جوجل','search_sites_google',1012,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,RRk9Ki5nPSfAZqC)
	MQtuaShrKTbdZFJ5nsR7D('folder','بحث منفرد لمواقع جوجل',b8Qe150xVaJsnDSv,1011,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,RRk9Ki5nPSfAZqC)
	MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+'===== ===== ===== '+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999)
	MQtuaShrKTbdZFJ5nsR7D('folder','نتائج البحث مفصلة - '+RRk9Ki5nPSfAZqC,'opened_sites_google',1012,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,RRk9Ki5nPSfAZqC)
	MQtuaShrKTbdZFJ5nsR7D('folder','نتائج البحث مقسمة - '+RRk9Ki5nPSfAZqC,'listed_sites_google',1012,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,RRk9Ki5nPSfAZqC)
	MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+'===== ===== ===== '+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999)
	MQtuaShrKTbdZFJ5nsR7D('folder','مواقع جوجل ('+str(len(vM5rV2kc7Qd))+') - '+RRk9Ki5nPSfAZqC,'',1016,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,RRk9Ki5nPSfAZqC)
	MQtuaShrKTbdZFJ5nsR7D('link','إعادة بحث جوجل - '+RRk9Ki5nPSfAZqC,'',1018,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,RRk9Ki5nPSfAZqC)
	return
def dicUTESRAXBrDPfM6a81Zys3zYL(RRk9Ki5nPSfAZqC):
	vM5rV2kc7Qd,ccNAgum3ODr = pIgHcFRO2XNJ(RRk9Ki5nPSfAZqC)
	if not vM5rV2kc7Qd and not ccNAgum3ODr: return
	JO8xelvBpz26bLYq5 = {}
	for name,pcA1dzy7LXwGfMPg9mTkuh5tine3,title,text,b89GuUX5OixP,TFAmLfwypkzsP1UYCMr8c in vM5rV2kc7Qd: JO8xelvBpz26bLYq5[TFAmLfwypkzsP1UYCMr8c] = name,pcA1dzy7LXwGfMPg9mTkuh5tine3,title,text,b89GuUX5OixP,TFAmLfwypkzsP1UYCMr8c
	M6VfOXgtvuFd2UGr = list(JO8xelvBpz26bLYq5.keys())
	import jtKsxUZvgl
	uaOf3Ajwiv = jtKsxUZvgl.aOAE24IDufWJlKUyrFsYz(M6VfOXgtvuFd2UGr)
	for TFAmLfwypkzsP1UYCMr8c in uaOf3Ajwiv:
		if 'tuple' in str(type(TFAmLfwypkzsP1UYCMr8c)):
			GyjmfosC59Jub.append(TFAmLfwypkzsP1UYCMr8c)
			continue
		name,pcA1dzy7LXwGfMPg9mTkuh5tine3,title,text,b89GuUX5OixP,TFAmLfwypkzsP1UYCMr8c = JO8xelvBpz26bLYq5[TFAmLfwypkzsP1UYCMr8c]
		drHgqFcWbNv82tVEhDMT5,Bgb2Tkp6fK0CGvWYUZFtAzr,bhNwipmnY26A83qIEyDt0jQTso = MMUq0NsIxei5bK(TFAmLfwypkzsP1UYCMr8c)
		MQtuaShrKTbdZFJ5nsR7D('folder',bhNwipmnY26A83qIEyDt0jQTso+name,pcA1dzy7LXwGfMPg9mTkuh5tine3,1014,b89GuUX5OixP,'',TFAmLfwypkzsP1UYCMr8c)
	MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+'===== ===== ===== '+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999)
	MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+'مواقع بجوجل غير موجودة بالبرنامج'+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,1015)
	ccNAgum3ODr = sorted(ccNAgum3ODr,reverse=DD5cFIejQa2X4BgAu9GWPyJ3tC7,key=lambda key: key[LzYQg91SIxDeOGtCKd5])
	for name,pcA1dzy7LXwGfMPg9mTkuh5tine3,title,text,b89GuUX5OixP,TFAmLfwypkzsP1UYCMr8c in ccNAgum3ODr:
		MQtuaShrKTbdZFJ5nsR7D('link','_GOS_'+rC3Tlno96KjLDIvBaSWUbR8+name+pldxivXC5wbTB2O8q+hAIp8kmC36T5WFPMSXOwnNbtD,pcA1dzy7LXwGfMPg9mTkuh5tine3,1015,b89GuUX5OixP,'',TFAmLfwypkzsP1UYCMr8c)
	return
def pIgHcFRO2XNJ(RRk9Ki5nPSfAZqC,Mhsrgdq3jpIDTlFG7eOfQo5k0uV=CCxMXuNUEzolDZTKrBJ):
	vM5rV2kc7Qd,ccNAgum3ODr = [],[]
	if Mhsrgdq3jpIDTlFG7eOfQo5k0uV:
		VxUyMinZLJRDuoArdPG7mYBh = SS2OK7hjLagvUAm(mshLJcKH1fv03yRnDOr4ZT,'list','GOOGLESEARCH_RESULTS',RRk9Ki5nPSfAZqC)
		if VxUyMinZLJRDuoArdPG7mYBh: vM5rV2kc7Qd,ccNAgum3ODr = VxUyMinZLJRDuoArdPG7mYBh
	if not vM5rV2kc7Qd and not ccNAgum3ODr: tuJ9fQgDl8oineCrFPT('','','رسالة من المبرمج','للأسف جوجل لم يجد مواقع فيها طلبك')
	return vM5rV2kc7Qd,ccNAgum3ODr
def qqJHVyNLnWZskK2fg3cEQrwibFOC(dwZ5a7InmqCcH,RRk9Ki5nPSfAZqC):
	vM5rV2kc7Qd,ccNAgum3ODr = pIgHcFRO2XNJ(RRk9Ki5nPSfAZqC)
	if not vM5rV2kc7Qd and not ccNAgum3ODr: return
	DdO1CL4U5kFJl08M6c,vQ78NLSD5PbCc3FXes6MuRGTihOr = [],{}
	for name,pcA1dzy7LXwGfMPg9mTkuh5tine3,title,text,b89GuUX5OixP,TFAmLfwypkzsP1UYCMr8c in vM5rV2kc7Qd:
		DdO1CL4U5kFJl08M6c.append(TFAmLfwypkzsP1UYCMr8c)
		vQ78NLSD5PbCc3FXes6MuRGTihOr[TFAmLfwypkzsP1UYCMr8c] = Y5Y4pSiWD19aLTfJxVrBQOjzqKHsle(title)
	import jtKsxUZvgl
	jtKsxUZvgl.YQW7EwP2saL(RRk9Ki5nPSfAZqC,dwZ5a7InmqCcH,b8Qe150xVaJsnDSv,DdO1CL4U5kFJl08M6c,vQ78NLSD5PbCc3FXes6MuRGTihOr)
	return
def nATzSwh2eMjbiv6y0r1QJC7lUuZ(RRk9Ki5nPSfAZqC):
	vM5rV2kc7Qd,ccNAgum3ODr = pIgHcFRO2XNJ(RRk9Ki5nPSfAZqC)
	if not vM5rV2kc7Qd and not ccNAgum3ODr: return
	JO8xelvBpz26bLYq5 = {}
	for name,pcA1dzy7LXwGfMPg9mTkuh5tine3,title,text,b89GuUX5OixP,TFAmLfwypkzsP1UYCMr8c in vM5rV2kc7Qd:
		JO8xelvBpz26bLYq5[TFAmLfwypkzsP1UYCMr8c] = name,pcA1dzy7LXwGfMPg9mTkuh5tine3,title,text,b89GuUX5OixP,TFAmLfwypkzsP1UYCMr8c
	M6VfOXgtvuFd2UGr = list(JO8xelvBpz26bLYq5.keys())
	import jtKsxUZvgl
	uaOf3Ajwiv = jtKsxUZvgl.aOAE24IDufWJlKUyrFsYz(M6VfOXgtvuFd2UGr)
	for TFAmLfwypkzsP1UYCMr8c in uaOf3Ajwiv:
		if 'tuple' in str(type(TFAmLfwypkzsP1UYCMr8c)):
			GyjmfosC59Jub.append(TFAmLfwypkzsP1UYCMr8c)
			continue
		name,pcA1dzy7LXwGfMPg9mTkuh5tine3,title,text,b89GuUX5OixP,TFAmLfwypkzsP1UYCMr8c = JO8xelvBpz26bLYq5[TFAmLfwypkzsP1UYCMr8c]
		drHgqFcWbNv82tVEhDMT5,Bgb2Tkp6fK0CGvWYUZFtAzr,bhNwipmnY26A83qIEyDt0jQTso = MMUq0NsIxei5bK(TFAmLfwypkzsP1UYCMr8c)
		title = Y5Y4pSiWD19aLTfJxVrBQOjzqKHsle(title)
		name = name+' - '+RRk9Ki5nPSfAZqC
		MQtuaShrKTbdZFJ5nsR7D('folder',bhNwipmnY26A83qIEyDt0jQTso+name,TFAmLfwypkzsP1UYCMr8c,548,b89GuUX5OixP,'',title)
	return
def Y5Y4pSiWD19aLTfJxVrBQOjzqKHsle(title):
	HHr42WSgBjAeU7TkQcVaL6yEJz8PF = YYBlm36zd0Jst18LXwo4.findall('(.*?) (الحلقة|حلقة)',title,YYBlm36zd0Jst18LXwo4.DOTALL)
	HoXz65T8ph1CMeZgF = HHr42WSgBjAeU7TkQcVaL6yEJz8PF[0][0] if HHr42WSgBjAeU7TkQcVaL6yEJz8PF else title
	HoXz65T8ph1CMeZgF = HoXz65T8ph1CMeZgF.replace('مشاهدة اونلاين، فيديو، الإعلان، صور - السينما.كوم','').replace('- ‎عرب سيد - Arabseed','')
	HoXz65T8ph1CMeZgF = HoXz65T8ph1CMeZgF.replace('- وى سيما wecima ماى سيما mycima - وي سيما','').replace('- فيديو Dailymotion','')
	HoXz65T8ph1CMeZgF = HoXz65T8ph1CMeZgF.replace('الموسم','').replace('الموقع','').replace('- شوف نت','').replace('موسم','').replace('HD','')
	HoXz65T8ph1CMeZgF = HoXz65T8ph1CMeZgF.replace('مشاهدة','').replace('نتائج البحث:','').replace('اونلاين','').replace('- سيما فور بي','')
	HoXz65T8ph1CMeZgF = HoXz65T8ph1CMeZgF.replace('موقع','').replace('| اكوام','').replace('','').replace('','').replace('','').replace('','')
	HoXz65T8ph1CMeZgF = HoXz65T8ph1CMeZgF.strip(' ').replace('    ',' ').replace('   ',' ').replace('  ',' ').replace('  ',' ')
	return HoXz65T8ph1CMeZgF
def POxU8lEHRFboK2tf4(search,L1Jb09ScOun):
	search = search.replace(pldxivXC5wbTB2O8q,'%20')
	url = 'https://www.google.com/search?hl=en&filter=1&imgSize=small&safe=active&num=100&start=0&q='+search
	headers = {'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36 Edg/128.0.0.0'}
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(L1Jb09ScOun,'GET',url,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'GOOGLESEARCH-SEARCH-1st')
	WtK4CrnH9EV1sIzTdYNGP0a,DGetJq3lVdY9uIngaRjB2OK = [],[]
	if not b3HKopTY9zLUyhJmt.succeeded: return WtK4CrnH9EV1sIzTdYNGP0a
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	y58pSntYPc0bxousv = x76PfMyAp1L2WejkU3.path.join(fH3Ie4SrRCsFMVo98hpN,'googlesearch')
	if not x76PfMyAp1L2WejkU3.path.exists(y58pSntYPc0bxousv):
		try: x76PfMyAp1L2WejkU3.makedirs(y58pSntYPc0bxousv)
		except: pass
	JQjNkD10xehK8bXUalY3EgZAVmvI = YYBlm36zd0Jst18LXwo4.findall('(\[null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,".*?\]\])',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	for OTKx7aVb2hdS16Wrweky4FXfIN0g9 in JQjNkD10xehK8bXUalY3EgZAVmvI:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = oJsUwXA0yGOI1mTjxQ('list',OTKx7aVb2hdS16Wrweky4FXfIN0g9)
		if len(OTKx7aVb2hdS16Wrweky4FXfIN0g9)>17:
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = OTKx7aVb2hdS16Wrweky4FXfIN0g9[17]
			title,text,name,I6YPOSofrpnTwRm8b = OTKx7aVb2hdS16Wrweky4FXfIN0g9[31][0:4]
			name = name.strip(' ')
			if not name: name = Wl2eu1PavfQ(pcA1dzy7LXwGfMPg9mTkuh5tine3,'name')
			name = LL1ZqB5WQHbd38JXhNRF(name)
			if 'http://' in I6YPOSofrpnTwRm8b or 'https://' in I6YPOSofrpnTwRm8b: b89GuUX5OixP = I6YPOSofrpnTwRm8b
			elif 'data:image/' in I6YPOSofrpnTwRm8b and ';base64,' in I6YPOSofrpnTwRm8b:
				ihpGSyaRD3ZNecBmU1d = YYBlm36zd0Jst18LXwo4.findall('data:image/(\w+);base64,',I6YPOSofrpnTwRm8b)
				ihpGSyaRD3ZNecBmU1d = ihpGSyaRD3ZNecBmU1d[0]
				b89GuUX5OixP = x76PfMyAp1L2WejkU3.path.join(y58pSntYPc0bxousv,name+'.'+ihpGSyaRD3ZNecBmU1d)
				if not x76PfMyAp1L2WejkU3.path.exists(b89GuUX5OixP):
					I6YPOSofrpnTwRm8b = I6YPOSofrpnTwRm8b.replace('\\u003d','=')
					I6YPOSofrpnTwRm8b = I6YPOSofrpnTwRm8b.replace('data:image/'+ihpGSyaRD3ZNecBmU1d+';base64,','')
					iNaDZtue4bdWVUPlFK1CzBQMG8 = lnFeUkiZtQ7E1.b64decode(I6YPOSofrpnTwRm8b)
					open(b89GuUX5OixP,'wb').write(iNaDZtue4bdWVUPlFK1CzBQMG8)
			else: b89GuUX5OixP = ''
			TFAmLfwypkzsP1UYCMr8c = HVlQctpSP2R5ZF0sYr(name,pcA1dzy7LXwGfMPg9mTkuh5tine3)
			if TFAmLfwypkzsP1UYCMr8c not in DGetJq3lVdY9uIngaRjB2OK:
				DGetJq3lVdY9uIngaRjB2OK.append(TFAmLfwypkzsP1UYCMr8c)
				name = OJ5kiNTSpIdCco0H(TFAmLfwypkzsP1UYCMr8c)
				WtK4CrnH9EV1sIzTdYNGP0a.append([name,pcA1dzy7LXwGfMPg9mTkuh5tine3,title,text,b89GuUX5OixP,TFAmLfwypkzsP1UYCMr8c])
	return WtK4CrnH9EV1sIzTdYNGP0a
def nndimOaNp5ce(pcA1dzy7LXwGfMPg9mTkuh5tine3,TFAmLfwypkzsP1UYCMr8c):
	drHgqFcWbNv82tVEhDMT5,Bgb2Tkp6fK0CGvWYUZFtAzr,bhNwipmnY26A83qIEyDt0jQTso = MMUq0NsIxei5bK(TFAmLfwypkzsP1UYCMr8c)
	if bhNwipmnY26A83qIEyDt0jQTso: drHgqFcWbNv82tVEhDMT5()
	else: XUF3JOeaft21GwoL64()
	return
def Aip73u5PFbyZdgSXOtYG():
	tuJ9fQgDl8oineCrFPT('','','رسالة من المبرمج','هذا البحث يستخدم ذكاء وشمولية وسرعة محرك بحث جوجل .. ونتائج هذا البحث هي أسماء مواقع الإنترنت التي موجودة في هذا البرنامج والتي فيها الفيديوهات المطلوبة\n\nهذا البحث يحتاج كلمات بحث عادية جدا بدون أي مراعاة لدقة الكلمات أو تفاصيل الفيديوهات أو حتى إملاء الكلمات\n\nهذا البحث يستطيع أيضا أن يفحص محتويات المواقع التي وجدها جوجل إذا كانت هذه المواقع موجودة بهذا البرنامج')
	return
def XUF3JOeaft21GwoL64(TFAmLfwypkzsP1UYCMr8c=''):
	tuJ9fQgDl8oineCrFPT('','',TFAmLfwypkzsP1UYCMr8c,'هذا الموقع غير موجود في البرنامج .. أو أسم الموقع مختلف وغير مطابق للاسم المستخدم في البرنامج')
	return
def HVlQctpSP2R5ZF0sYr(name,pcA1dzy7LXwGfMPg9mTkuh5tine3):
	dUkiv0QIBerKqwa = {
	 'فشار فيديو مشاهدة افلام ومسلسلات اون لاين'	:'FUSHARVIDEO'
	,'وى سيما wecima ماى سيما mycima'			:'WECIMA1'
	,'شبكتي تي في - SHABAKATY TV'				:'SHABAKATY'
	,'اكوام  شبكة اكوام AKWAM'					:'AKWAM'
	,'سيما كلوب  CIMACLUB'						:'CIMACLUB'
	,'سيما فري CIMAFREE':'CIMAFREE'
	,'هلا سيما'			:'HALACIMA'
	,'لاروزا'			:'LAROZA'
	,'برستيج'			:'BRSTEJ'
	,'كرمالك TV'		:'KIRMALK'
	,'سيما فور بي'		:'CIMA4P'
	,'اهواك تي في'		:'AHWAK'
	,'CIMA CLUB'		:'CIMACLUB'
	,'اكوام'			:'AKWAM'
	,'وي سيما'			:'WECIMA1'
	,'سيما ناو'			:'CIMANOW'
	,'سيما لايت'			:'CIMALIGHT'
	,'عرب سيد'			:'ARABSEED'
	,'فيديو ياقوت'		:'YAQOT'
	,'المصطبة TV'		:'ALMSTBA'
	,'دراما كافيه'		:'DRAMACAFE'
	,'سيما 400'			:'CIMA400'
	,'فيديو تكات'		:'TIKAAT'
	,'السينما.كوم'		:'ELCINEMA'
	,'فوستا'			:'FOSTA'
	,'سيما عبدو'		:'CIMAABDO'
	,'فاصل إعلاني'		:'FASELHD1'
	,'مسلسلات تايم'		:'SERIESTIME'
	,'برس3تيج'		:''
	,'برس3تيج'		:''
	,'برس3تيج'		:''
	,'برس3تيج'		:''
	,'برس3تيج'		:''
	,'برس3تيج'		:''
	,'برس3تيج'		:''
	,'برس3تيج'		:''
	}
	WUj71fhxld3rqONpBzmEuC = name.lower()
	wnsCBgrI9EJtPdyYp3T7bocXF = ''
	for key in list(dUkiv0QIBerKqwa.keys()):
		if key.lower() in WUj71fhxld3rqONpBzmEuC: wnsCBgrI9EJtPdyYp3T7bocXF = dUkiv0QIBerKqwa[key]
	if not wnsCBgrI9EJtPdyYp3T7bocXF:
		eiFs3pQPyZtjb0W = Wl2eu1PavfQ(pcA1dzy7LXwGfMPg9mTkuh5tine3,'url')
		for TFAmLfwypkzsP1UYCMr8c in list(nTHXJIiah2qK.keys()):
			XZ8LDH3n70Bpble6 = Wl2eu1PavfQ(nTHXJIiah2qK[TFAmLfwypkzsP1UYCMr8c][0],'url')
			if eiFs3pQPyZtjb0W==XZ8LDH3n70Bpble6: wnsCBgrI9EJtPdyYp3T7bocXF = TFAmLfwypkzsP1UYCMr8c
	if not wnsCBgrI9EJtPdyYp3T7bocXF:
		WUj71fhxld3rqONpBzmEuC = Wl2eu1PavfQ(pcA1dzy7LXwGfMPg9mTkuh5tine3,'name')
		for TFAmLfwypkzsP1UYCMr8c in list(nTHXJIiah2qK.keys()):
			kU8rztvRXfE590OMuP6 = Wl2eu1PavfQ(nTHXJIiah2qK[TFAmLfwypkzsP1UYCMr8c][0],'name')
			if WUj71fhxld3rqONpBzmEuC==kU8rztvRXfE590OMuP6: wnsCBgrI9EJtPdyYp3T7bocXF = TFAmLfwypkzsP1UYCMr8c
	if not wnsCBgrI9EJtPdyYp3T7bocXF: wnsCBgrI9EJtPdyYp3T7bocXF = name
	wnsCBgrI9EJtPdyYp3T7bocXF = wnsCBgrI9EJtPdyYp3T7bocXF.upper()
	return wnsCBgrI9EJtPdyYp3T7bocXF
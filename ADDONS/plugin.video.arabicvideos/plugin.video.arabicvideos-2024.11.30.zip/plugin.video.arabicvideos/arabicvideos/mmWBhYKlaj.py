# -*- coding: utf-8 -*-
from hIVCFnfxSO import *
ALwGbyiBFzY7H = 'EXCLUDES'
def L1R02Yko4KX(c17XeRIH2gVh3px8sw,oOa5sj9qdpB0iFCGuIWwSDUKx8):
	oOa5sj9qdpB0iFCGuIWwSDUKx8 = oOa5sj9qdpB0iFCGuIWwSDUKx8.replace(rC3Tlno96KjLDIvBaSWUbR8,b8Qe150xVaJsnDSv).replace(' '+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv)[1:]
	L0bGoTIUaDW = YYBlm36zd0Jst18LXwo4.findall('[a-zA-Z]',c17XeRIH2gVh3px8sw,YYBlm36zd0Jst18LXwo4.DOTALL)
	if 'بحث IPTV - ' in c17XeRIH2gVh3px8sw: c17XeRIH2gVh3px8sw = c17XeRIH2gVh3px8sw.replace('بحث IPTV - ',VfHYrPvolqbxLOd+'بحث IPTV - '+VfHYrPvolqbxLOd)
	elif ' IPTV' in c17XeRIH2gVh3px8sw and oOa5sj9qdpB0iFCGuIWwSDUKx8=='IPT': c17XeRIH2gVh3px8sw = VfHYrPvolqbxLOd+c17XeRIH2gVh3px8sw
	elif 'بحث M3U - ' in c17XeRIH2gVh3px8sw: c17XeRIH2gVh3px8sw = c17XeRIH2gVh3px8sw.replace('بحث M3U - ',VfHYrPvolqbxLOd+'بحث M3U - '+VfHYrPvolqbxLOd)
	elif ' M3U' in c17XeRIH2gVh3px8sw and oOa5sj9qdpB0iFCGuIWwSDUKx8=='M3U': c17XeRIH2gVh3px8sw = VfHYrPvolqbxLOd+c17XeRIH2gVh3px8sw
	elif 'بحث ' in c17XeRIH2gVh3px8sw and ' - ' in c17XeRIH2gVh3px8sw: c17XeRIH2gVh3px8sw = VfHYrPvolqbxLOd+c17XeRIH2gVh3px8sw
	elif not L0bGoTIUaDW:
		RKT5uLgmswSUOIy3l4ctM0H9bjYW = YYBlm36zd0Jst18LXwo4.findall('^( *?)(.*?)( *?)$',c17XeRIH2gVh3px8sw)
		IIUKoDL5Gn,JhZzepcPxA,P6Ks29wacYRJzZFi1fk5LQputjOATH = RKT5uLgmswSUOIy3l4ctM0H9bjYW[0]
		C7p3VwtsaBjGLm1 = YYBlm36zd0Jst18LXwo4.findall('^([!-~])',JhZzepcPxA)
		if C7p3VwtsaBjGLm1: c17XeRIH2gVh3px8sw = IIUKoDL5Gn+W0LQbFfMVG46dKrPzJCmvD+JhZzepcPxA+P6Ks29wacYRJzZFi1fk5LQputjOATH
		else: c17XeRIH2gVh3px8sw = P6Ks29wacYRJzZFi1fk5LQputjOATH+VfHYrPvolqbxLOd+JhZzepcPxA+IIUKoDL5Gn
	else:
		import bidi.algorithm as cEQtfYbzRv8Z
		if 1:
			Keo3x90WGZqyEgXunYAQhzt = c17XeRIH2gVh3px8sw
			c3ctqVNOU5DL7wl = cEQtfYbzRv8Z.get_display(c17XeRIH2gVh3px8sw,base_dir='L')
			if hDTluNxe7tCwrpqXHzdEcYRfbs: Keo3x90WGZqyEgXunYAQhzt = Keo3x90WGZqyEgXunYAQhzt.decode(OVauxZzLI10vcXT74K)
			if hDTluNxe7tCwrpqXHzdEcYRfbs: c3ctqVNOU5DL7wl = c3ctqVNOU5DL7wl.decode(OVauxZzLI10vcXT74K)
			HFR6PlGvAO8b4Q5ZYVIXWk0t = Keo3x90WGZqyEgXunYAQhzt.split(pldxivXC5wbTB2O8q)
			MOdWs8F9q4YKgJaLypZwiePR3bvHxf = c3ctqVNOU5DL7wl.split(pldxivXC5wbTB2O8q)
			FtUrk6Gq15MZsVoKHfLeh,AG6nB2KW7Ja,n7OMfroc4UvuYaQLFJEjWymN5,KjHeuEPGScT4tLOd2r = [],[],b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv
			II9Fij8AspqlQdS0CeZVkfWJuaX = zip(HFR6PlGvAO8b4Q5ZYVIXWk0t,MOdWs8F9q4YKgJaLypZwiePR3bvHxf)
			for fxzGZ8YHdk,HAPFRgkhNVj3ao51 in II9Fij8AspqlQdS0CeZVkfWJuaX:
				if fxzGZ8YHdk==HAPFRgkhNVj3ao51==b8Qe150xVaJsnDSv and KjHeuEPGScT4tLOd2r:
					n7OMfroc4UvuYaQLFJEjWymN5 += pldxivXC5wbTB2O8q
					continue
				if fxzGZ8YHdk==HAPFRgkhNVj3ao51:
					xxVBKUpfE5vAH6XtzJLTnCuo = 'EN'
					if KjHeuEPGScT4tLOd2r==xxVBKUpfE5vAH6XtzJLTnCuo: n7OMfroc4UvuYaQLFJEjWymN5 += pldxivXC5wbTB2O8q+fxzGZ8YHdk
					elif fxzGZ8YHdk:
						if n7OMfroc4UvuYaQLFJEjWymN5:
							AG6nB2KW7Ja.append(n7OMfroc4UvuYaQLFJEjWymN5)
							FtUrk6Gq15MZsVoKHfLeh.append(b8Qe150xVaJsnDSv)
						n7OMfroc4UvuYaQLFJEjWymN5 = fxzGZ8YHdk
				else:
					xxVBKUpfE5vAH6XtzJLTnCuo = 'AR'
					if KjHeuEPGScT4tLOd2r==xxVBKUpfE5vAH6XtzJLTnCuo: n7OMfroc4UvuYaQLFJEjWymN5 += pldxivXC5wbTB2O8q+fxzGZ8YHdk
					elif fxzGZ8YHdk:
						if n7OMfroc4UvuYaQLFJEjWymN5:
							FtUrk6Gq15MZsVoKHfLeh.append(n7OMfroc4UvuYaQLFJEjWymN5)
							AG6nB2KW7Ja.append(b8Qe150xVaJsnDSv)
						n7OMfroc4UvuYaQLFJEjWymN5 = fxzGZ8YHdk
				KjHeuEPGScT4tLOd2r = xxVBKUpfE5vAH6XtzJLTnCuo
			if xxVBKUpfE5vAH6XtzJLTnCuo=='EN':
				FtUrk6Gq15MZsVoKHfLeh.append(n7OMfroc4UvuYaQLFJEjWymN5)
				AG6nB2KW7Ja.append(b8Qe150xVaJsnDSv)
			else:
				AG6nB2KW7Ja.append(n7OMfroc4UvuYaQLFJEjWymN5)
				FtUrk6Gq15MZsVoKHfLeh.append(b8Qe150xVaJsnDSv)
			iZeXULFvTRtzw0 = b8Qe150xVaJsnDSv
			II9Fij8AspqlQdS0CeZVkfWJuaX = zip(FtUrk6Gq15MZsVoKHfLeh,AG6nB2KW7Ja)
			import bidi.mirror as vvb2kEhwaMADsFOUc40Ro5u
			for ccdpUiXTwaV9fqFxPEzLvSCGoNems,Kihct6vpdxN2g4abFBk in II9Fij8AspqlQdS0CeZVkfWJuaX:
				if ccdpUiXTwaV9fqFxPEzLvSCGoNems: iZeXULFvTRtzw0 += pldxivXC5wbTB2O8q+ccdpUiXTwaV9fqFxPEzLvSCGoNems
				else:
					C7p3VwtsaBjGLm1 = YYBlm36zd0Jst18LXwo4.findall('([!-~]) *$',Kihct6vpdxN2g4abFBk)
					if C7p3VwtsaBjGLm1:
						C7p3VwtsaBjGLm1 = C7p3VwtsaBjGLm1[0]
						try:
							D1FQbpV0SjK23oC = vvb2kEhwaMADsFOUc40Ro5u.MIRRORED[C7p3VwtsaBjGLm1]
							RKT5uLgmswSUOIy3l4ctM0H9bjYW = YYBlm36zd0Jst18LXwo4.findall('^( *?)(.*?)( *?)$',Kihct6vpdxN2g4abFBk)
							if RKT5uLgmswSUOIy3l4ctM0H9bjYW: IIUKoDL5Gn,Kihct6vpdxN2g4abFBk,P6Ks29wacYRJzZFi1fk5LQputjOATH = RKT5uLgmswSUOIy3l4ctM0H9bjYW[0]
							Kihct6vpdxN2g4abFBk = IIUKoDL5Gn+D1FQbpV0SjK23oC+Kihct6vpdxN2g4abFBk[:-1]+P6Ks29wacYRJzZFi1fk5LQputjOATH
						except: pass
					iZeXULFvTRtzw0 += pldxivXC5wbTB2O8q+Kihct6vpdxN2g4abFBk
			c17XeRIH2gVh3px8sw = iZeXULFvTRtzw0[1:]
			if hDTluNxe7tCwrpqXHzdEcYRfbs: c17XeRIH2gVh3px8sw = c17XeRIH2gVh3px8sw.encode(OVauxZzLI10vcXT74K)
		else:
			if hDTluNxe7tCwrpqXHzdEcYRfbs: c17XeRIH2gVh3px8sw = c17XeRIH2gVh3px8sw.decode(OVauxZzLI10vcXT74K)
			c17XeRIH2gVh3px8sw = cEQtfYbzRv8Z.get_display(c17XeRIH2gVh3px8sw)
			Keo3x90WGZqyEgXunYAQhzt,c3ctqVNOU5DL7wl = c17XeRIH2gVh3px8sw,c17XeRIH2gVh3px8sw
			if 1:
				KjHeuEPGScT4tLOd2r,LLmMi9rpCognBGVyzD4t = b8Qe150xVaJsnDSv,[]
				Pik34bgwEUj1ap7JGN8Ah = c17XeRIH2gVh3px8sw.split(pldxivXC5wbTB2O8q)
				for vCoxVzrcHuQnT315StJ in Pik34bgwEUj1ap7JGN8Ah:
					if not vCoxVzrcHuQnT315StJ:
						if LLmMi9rpCognBGVyzD4t: LLmMi9rpCognBGVyzD4t[-1] += pldxivXC5wbTB2O8q
						else: LLmMi9rpCognBGVyzD4t.append(b8Qe150xVaJsnDSv)
						continue
					Ev20fRPZiyM = YYBlm36zd0Jst18LXwo4.findall('[!-~]',vCoxVzrcHuQnT315StJ[0])
					if Ev20fRPZiyM==KjHeuEPGScT4tLOd2r and LLmMi9rpCognBGVyzD4t: LLmMi9rpCognBGVyzD4t[-1] += pldxivXC5wbTB2O8q+vCoxVzrcHuQnT315StJ
					else:
						if LLmMi9rpCognBGVyzD4t:
							bb7eDklIzXgB = YYBlm36zd0Jst18LXwo4.findall('[^!-~]',LLmMi9rpCognBGVyzD4t[-1])
							if bb7eDklIzXgB:
								LLmMi9rpCognBGVyzD4t[-1] = cEQtfYbzRv8Z.get_display(LLmMi9rpCognBGVyzD4t[-1])
								PGsHnoM3ESqxXLtlzKOd80eAWgh6Qw = YYBlm36zd0Jst18LXwo4.findall('^ +',LLmMi9rpCognBGVyzD4t[-1])
								if PGsHnoM3ESqxXLtlzKOd80eAWgh6Qw: LLmMi9rpCognBGVyzD4t[-1] = LLmMi9rpCognBGVyzD4t[-1].lstrip(pldxivXC5wbTB2O8q)+PGsHnoM3ESqxXLtlzKOd80eAWgh6Qw[0]
						LLmMi9rpCognBGVyzD4t.append(vCoxVzrcHuQnT315StJ)
					KjHeuEPGScT4tLOd2r = Ev20fRPZiyM
				if LLmMi9rpCognBGVyzD4t: LLmMi9rpCognBGVyzD4t[-1] = cEQtfYbzRv8Z.get_display(LLmMi9rpCognBGVyzD4t[-1])
				c17XeRIH2gVh3px8sw = pldxivXC5wbTB2O8q.join(LLmMi9rpCognBGVyzD4t)
			if hDTluNxe7tCwrpqXHzdEcYRfbs: c17XeRIH2gVh3px8sw = c17XeRIH2gVh3px8sw.encode(OVauxZzLI10vcXT74K)
	return c17XeRIH2gVh3px8sw
def jjvaJcbTrUMf7XVBFNZEtCqHmwhP(KKHsXdETa4uckBQJWlRVPU3mbrh,KxCsNutraQ0b,k0x2QVr6LOd):
	A60AIQZCYRzdhaeWfOtmrSUVoq2nN,c17XeRIH2gVh3px8sw,uuNDjbit4hOpx,ZZtDTHnBXMz,ChvkSxHr6QoKJg,fo6RghJpm4cHa1OPjL,noZHx9cPhOMr4TvBfuSK,czG0PxAmlw4vtWrH5eL3RubT,ZzHaCLyPtIk1iurbW = KKHsXdETa4uckBQJWlRVPU3mbrh
	ZZtDTHnBXMz = int(ZZtDTHnBXMz)
	sK19n3DhM0GEBld7Pb = YYBlm36zd0Jst18LXwo4.findall('(_(\d\d\.\d\d)_(\d\d\:\d\d)_)',c17XeRIH2gVh3px8sw,YYBlm36zd0Jst18LXwo4.DOTALL)
	if sK19n3DhM0GEBld7Pb:
		sK19n3DhM0GEBld7Pb,wEKYAVUvSpy7Jt9ke,EuQ9dNC0nAjvTsxRbKlPzrY = sK19n3DhM0GEBld7Pb[0]
		c17XeRIH2gVh3px8sw = c17XeRIH2gVh3px8sw.replace(sK19n3DhM0GEBld7Pb,b8Qe150xVaJsnDSv)
	gw0keTB57SVo2I = c17XeRIH2gVh3px8sw
	oOa5sj9qdpB0iFCGuIWwSDUKx8 = YYBlm36zd0Jst18LXwo4.findall('^_(\w\w\w)_(.*?)$',c17XeRIH2gVh3px8sw,YYBlm36zd0Jst18LXwo4.DOTALL)
	if oOa5sj9qdpB0iFCGuIWwSDUKx8:
		oOa5sj9qdpB0iFCGuIWwSDUKx8,c17XeRIH2gVh3px8sw = oOa5sj9qdpB0iFCGuIWwSDUKx8[0]
		ImzUvY48BiOE = '_MOD_' in c17XeRIH2gVh3px8sw
		rA1p4eTdbhi69sotZkuP0QafYNDn = A60AIQZCYRzdhaeWfOtmrSUVoq2nN=='folder'
		if ImzUvY48BiOE and rA1p4eTdbhi69sotZkuP0QafYNDn: rryAORupGNEvU2Z9CLz6QMfcWY = ';'
		elif ImzUvY48BiOE and not rA1p4eTdbhi69sotZkuP0QafYNDn: rryAORupGNEvU2Z9CLz6QMfcWY = Iceb2XPnm6a3Tqx
		elif not ImzUvY48BiOE and rA1p4eTdbhi69sotZkuP0QafYNDn: rryAORupGNEvU2Z9CLz6QMfcWY = ','
		elif not ImzUvY48BiOE and not rA1p4eTdbhi69sotZkuP0QafYNDn: rryAORupGNEvU2Z9CLz6QMfcWY = pldxivXC5wbTB2O8q
		c17XeRIH2gVh3px8sw = c17XeRIH2gVh3px8sw.replace('_MOD_',b8Qe150xVaJsnDSv)
		oOa5sj9qdpB0iFCGuIWwSDUKx8 = rryAORupGNEvU2Z9CLz6QMfcWY+rC3Tlno96KjLDIvBaSWUbR8+oOa5sj9qdpB0iFCGuIWwSDUKx8+' '+hAIp8kmC36T5WFPMSXOwnNbtD
	else: oOa5sj9qdpB0iFCGuIWwSDUKx8 = b8Qe150xVaJsnDSv
	if sK19n3DhM0GEBld7Pb:
		if hDTluNxe7tCwrpqXHzdEcYRfbs:
			sK19n3DhM0GEBld7Pb = OkuB9nwhD8U1+wEKYAVUvSpy7Jt9ke+pldxivXC5wbTB2O8q+EuQ9dNC0nAjvTsxRbKlPzrY+hAIp8kmC36T5WFPMSXOwnNbtD
			if oOa5sj9qdpB0iFCGuIWwSDUKx8: c17XeRIH2gVh3px8sw = sK19n3DhM0GEBld7Pb+pldxivXC5wbTB2O8q+VfHYrPvolqbxLOd+oOa5sj9qdpB0iFCGuIWwSDUKx8+c17XeRIH2gVh3px8sw
			else: c17XeRIH2gVh3px8sw = sK19n3DhM0GEBld7Pb+VfHYrPvolqbxLOd+c17XeRIH2gVh3px8sw+pldxivXC5wbTB2O8q
		elif i1thmHk7AZquD4cM0fnp62:
			if oOa5sj9qdpB0iFCGuIWwSDUKx8:
				sK19n3DhM0GEBld7Pb = OkuB9nwhD8U1+wEKYAVUvSpy7Jt9ke+pldxivXC5wbTB2O8q+EuQ9dNC0nAjvTsxRbKlPzrY+hAIp8kmC36T5WFPMSXOwnNbtD
				c17XeRIH2gVh3px8sw = sK19n3DhM0GEBld7Pb+pldxivXC5wbTB2O8q+oOa5sj9qdpB0iFCGuIWwSDUKx8+c17XeRIH2gVh3px8sw
			else:
				sK19n3DhM0GEBld7Pb = OkuB9nwhD8U1+EuQ9dNC0nAjvTsxRbKlPzrY+pldxivXC5wbTB2O8q+wEKYAVUvSpy7Jt9ke+hAIp8kmC36T5WFPMSXOwnNbtD
				c17XeRIH2gVh3px8sw = c17XeRIH2gVh3px8sw+pldxivXC5wbTB2O8q+VfHYrPvolqbxLOd+sK19n3DhM0GEBld7Pb
	elif oOa5sj9qdpB0iFCGuIWwSDUKx8:
		c17XeRIH2gVh3px8sw = L1R02Yko4KX(c17XeRIH2gVh3px8sw,oOa5sj9qdpB0iFCGuIWwSDUKx8)
		c17XeRIH2gVh3px8sw = oOa5sj9qdpB0iFCGuIWwSDUKx8+c17XeRIH2gVh3px8sw
	KKHsXdETa4uckBQJWlRVPU3mbrh = A60AIQZCYRzdhaeWfOtmrSUVoq2nN,gw0keTB57SVo2I,uuNDjbit4hOpx,str(ZZtDTHnBXMz),ChvkSxHr6QoKJg,fo6RghJpm4cHa1OPjL,noZHx9cPhOMr4TvBfuSK,czG0PxAmlw4vtWrH5eL3RubT,ZzHaCLyPtIk1iurbW
	u9KcxZ0jPni35TrEoXpmDhLH = {'type':b8Qe150xVaJsnDSv,'mode':b8Qe150xVaJsnDSv,'url':b8Qe150xVaJsnDSv,'text':b8Qe150xVaJsnDSv,'page':b8Qe150xVaJsnDSv,'name':b8Qe150xVaJsnDSv,'image':b8Qe150xVaJsnDSv,'context':b8Qe150xVaJsnDSv,'infodict':b8Qe150xVaJsnDSv}
	if i1thmHk7AZquD4cM0fnp62: gw0keTB57SVo2I = gw0keTB57SVo2I.encode(OVauxZzLI10vcXT74K,'ignore').decode(OVauxZzLI10vcXT74K)
	u9KcxZ0jPni35TrEoXpmDhLH['name'] = HHbaVYqFRy6v0c(gw0keTB57SVo2I)
	u9KcxZ0jPni35TrEoXpmDhLH['type'] = A60AIQZCYRzdhaeWfOtmrSUVoq2nN.strip(pldxivXC5wbTB2O8q)
	u9KcxZ0jPni35TrEoXpmDhLH['mode'] = str(ZZtDTHnBXMz).strip(pldxivXC5wbTB2O8q)
	if A60AIQZCYRzdhaeWfOtmrSUVoq2nN=='folder' and fo6RghJpm4cHa1OPjL: u9KcxZ0jPni35TrEoXpmDhLH['page'] = HHbaVYqFRy6v0c(fo6RghJpm4cHa1OPjL.strip(pldxivXC5wbTB2O8q))
	if czG0PxAmlw4vtWrH5eL3RubT: u9KcxZ0jPni35TrEoXpmDhLH['context'] = czG0PxAmlw4vtWrH5eL3RubT.strip(pldxivXC5wbTB2O8q)
	if noZHx9cPhOMr4TvBfuSK: u9KcxZ0jPni35TrEoXpmDhLH['text'] = HHbaVYqFRy6v0c(noZHx9cPhOMr4TvBfuSK.strip(pldxivXC5wbTB2O8q))
	if ChvkSxHr6QoKJg: u9KcxZ0jPni35TrEoXpmDhLH['image'] = HHbaVYqFRy6v0c(ChvkSxHr6QoKJg.strip(pldxivXC5wbTB2O8q))
	if ZzHaCLyPtIk1iurbW:
		ZzHaCLyPtIk1iurbW = str(ZzHaCLyPtIk1iurbW)
		u9KcxZ0jPni35TrEoXpmDhLH['infodict'] = HHbaVYqFRy6v0c(ZzHaCLyPtIk1iurbW.strip(pldxivXC5wbTB2O8q))
		ZzHaCLyPtIk1iurbW = eval(ZzHaCLyPtIk1iurbW)
	else: ZzHaCLyPtIk1iurbW = {}
	if uuNDjbit4hOpx: u9KcxZ0jPni35TrEoXpmDhLH['url'] = HHbaVYqFRy6v0c(uuNDjbit4hOpx.strip(pldxivXC5wbTB2O8q))
	m9xqXkhIA6rGCDpnRBtFT0 = {'name':b8Qe150xVaJsnDSv,'context_menu':b8Qe150xVaJsnDSv,'plot':b8Qe150xVaJsnDSv,'stars':b8Qe150xVaJsnDSv,'image':b8Qe150xVaJsnDSv,'type':b8Qe150xVaJsnDSv,'isFolder':b8Qe150xVaJsnDSv,'newpath':b8Qe150xVaJsnDSv,'duration':b8Qe150xVaJsnDSv}
	NNj0O8UubPyDmJ9pZEkeRCQxMrB61n = []
	zCraF3NZ4o5xUOeESbAflhTH7 = 'plugin://'+DFUIv2KGj9ke+'/?type='+u9KcxZ0jPni35TrEoXpmDhLH['type']+'&mode='+u9KcxZ0jPni35TrEoXpmDhLH['mode']
	if u9KcxZ0jPni35TrEoXpmDhLH['page']: zCraF3NZ4o5xUOeESbAflhTH7 += '&page='+u9KcxZ0jPni35TrEoXpmDhLH['page']
	if u9KcxZ0jPni35TrEoXpmDhLH['name']: zCraF3NZ4o5xUOeESbAflhTH7 += '&name='+u9KcxZ0jPni35TrEoXpmDhLH['name']
	if u9KcxZ0jPni35TrEoXpmDhLH['text']: zCraF3NZ4o5xUOeESbAflhTH7 += '&text='+u9KcxZ0jPni35TrEoXpmDhLH['text']
	if u9KcxZ0jPni35TrEoXpmDhLH['infodict']: zCraF3NZ4o5xUOeESbAflhTH7 += '&infodict='+u9KcxZ0jPni35TrEoXpmDhLH['infodict']
	if u9KcxZ0jPni35TrEoXpmDhLH['image']: zCraF3NZ4o5xUOeESbAflhTH7 += '&image='+u9KcxZ0jPni35TrEoXpmDhLH['image']
	if u9KcxZ0jPni35TrEoXpmDhLH['url']: zCraF3NZ4o5xUOeESbAflhTH7 += '&url='+u9KcxZ0jPni35TrEoXpmDhLH['url']
	if ZZtDTHnBXMz!=265: m9xqXkhIA6rGCDpnRBtFT0['favorites'] = True
	else: m9xqXkhIA6rGCDpnRBtFT0['favorites'] = False
	if u9KcxZ0jPni35TrEoXpmDhLH['context']: zCraF3NZ4o5xUOeESbAflhTH7 += '&context='+u9KcxZ0jPni35TrEoXpmDhLH['context']
	if ZZtDTHnBXMz in [235,238] and A60AIQZCYRzdhaeWfOtmrSUVoq2nN=='live' and 'EPG' in czG0PxAmlw4vtWrH5eL3RubT:
		ttv3hOw5DMnA9XcSz8m = 'plugin://'+DFUIv2KGj9ke+'?mode=238&text=SHORT_EPG&url='+uuNDjbit4hOpx
		yyCDnI7HSdZOzguebE4j2XoBKThQ = OkuB9nwhD8U1+'البرامج القادمة'+hAIp8kmC36T5WFPMSXOwnNbtD
		Y5Yv2huKOTtC9DFmwGI0 = (yyCDnI7HSdZOzguebE4j2XoBKThQ,'RunPlugin('+ttv3hOw5DMnA9XcSz8m+')')
		NNj0O8UubPyDmJ9pZEkeRCQxMrB61n.append(Y5Yv2huKOTtC9DFmwGI0)
	if ZZtDTHnBXMz==265:
		lyJOSdVDRvqGHnBxPU = KxCsNutraQ0b(noZHx9cPhOMr4TvBfuSK,True)
		if lyJOSdVDRvqGHnBxPU>0:
			ttv3hOw5DMnA9XcSz8m = 'plugin://'+DFUIv2KGj9ke+'?mode=266&text='+noZHx9cPhOMr4TvBfuSK
			yyCDnI7HSdZOzguebE4j2XoBKThQ = OkuB9nwhD8U1+'مسح قائمة آخر 50 '+OJ5kiNTSpIdCco0H(noZHx9cPhOMr4TvBfuSK)+hAIp8kmC36T5WFPMSXOwnNbtD
			Y5Yv2huKOTtC9DFmwGI0 = (yyCDnI7HSdZOzguebE4j2XoBKThQ,'RunPlugin('+ttv3hOw5DMnA9XcSz8m+')')
			NNj0O8UubPyDmJ9pZEkeRCQxMrB61n.append(Y5Yv2huKOTtC9DFmwGI0)
	if A60AIQZCYRzdhaeWfOtmrSUVoq2nN=='video' and ZZtDTHnBXMz!=331:
		ttv3hOw5DMnA9XcSz8m = zCraF3NZ4o5xUOeESbAflhTH7+'&context=6_DOWNLOAD'
		yyCDnI7HSdZOzguebE4j2XoBKThQ = OkuB9nwhD8U1+'تحميل ملف الفيديو'+hAIp8kmC36T5WFPMSXOwnNbtD
		Y5Yv2huKOTtC9DFmwGI0 = (yyCDnI7HSdZOzguebE4j2XoBKThQ,'RunPlugin('+ttv3hOw5DMnA9XcSz8m+')')
		NNj0O8UubPyDmJ9pZEkeRCQxMrB61n.append(Y5Yv2huKOTtC9DFmwGI0)
	if ZZtDTHnBXMz==331:
		ttv3hOw5DMnA9XcSz8m = zCraF3NZ4o5xUOeESbAflhTH7+'&context=6_DELETE'
		yyCDnI7HSdZOzguebE4j2XoBKThQ = OkuB9nwhD8U1+'حذف ملف الفيديو'+hAIp8kmC36T5WFPMSXOwnNbtD
		Y5Yv2huKOTtC9DFmwGI0 = (yyCDnI7HSdZOzguebE4j2XoBKThQ,'RunPlugin('+ttv3hOw5DMnA9XcSz8m+')')
		NNj0O8UubPyDmJ9pZEkeRCQxMrB61n.append(Y5Yv2huKOTtC9DFmwGI0)
	if A60AIQZCYRzdhaeWfOtmrSUVoq2nN=='folder' and ZZtDTHnBXMz==540:
		IInW3iltANQvjVxUpDqKJSR = SS2OK7hjLagvUAm(mshLJcKH1fv03yRnDOr4ZT,'list','GLOBALSEARCH_SPLITTED_ALL')
		if IInW3iltANQvjVxUpDqKJSR:
			ttv3hOw5DMnA9XcSz8m = 'plugin://'+DFUIv2KGj9ke+'?context=7'
			yyCDnI7HSdZOzguebE4j2XoBKThQ = OkuB9nwhD8U1+'مسح كلمات بحث المواقع'+hAIp8kmC36T5WFPMSXOwnNbtD
			Y5Yv2huKOTtC9DFmwGI0 = (yyCDnI7HSdZOzguebE4j2XoBKThQ,'RunPlugin('+ttv3hOw5DMnA9XcSz8m+')')
			NNj0O8UubPyDmJ9pZEkeRCQxMrB61n.append(Y5Yv2huKOTtC9DFmwGI0)
	if A60AIQZCYRzdhaeWfOtmrSUVoq2nN=='folder' and ZZtDTHnBXMz==1010:
		IInW3iltANQvjVxUpDqKJSR = SS2OK7hjLagvUAm(mshLJcKH1fv03yRnDOr4ZT,'list','GLOBALSEARCH_SPLITTED_GOOGLE')
		if IInW3iltANQvjVxUpDqKJSR:
			ttv3hOw5DMnA9XcSz8m = 'plugin://'+DFUIv2KGj9ke+'?context=10'
			yyCDnI7HSdZOzguebE4j2XoBKThQ = OkuB9nwhD8U1+'مسح كلمات بحث جوجل'+hAIp8kmC36T5WFPMSXOwnNbtD
			Y5Yv2huKOTtC9DFmwGI0 = (yyCDnI7HSdZOzguebE4j2XoBKThQ,'RunPlugin('+ttv3hOw5DMnA9XcSz8m+')')
			NNj0O8UubPyDmJ9pZEkeRCQxMrB61n.append(Y5Yv2huKOTtC9DFmwGI0)
	st6m3R7zk1oDfbN8cY = [9990,9999,2,7,100,151,159,176,196,199,230,239,260,261,262,263,264,265,267,270,290,330,341,346,348,501,505,510,540,710,719,761,762,1010,1022]
	if ZZtDTHnBXMz not in st6m3R7zk1oDfbN8cY:
		ttv3hOw5DMnA9XcSz8m = 'plugin://'+DFUIv2KGj9ke+'?context=8&mode=260'
		yyCDnI7HSdZOzguebE4j2XoBKThQ = OkuB9nwhD8U1+'القائمة الرئيسية'+hAIp8kmC36T5WFPMSXOwnNbtD
		Y5Yv2huKOTtC9DFmwGI0 = (yyCDnI7HSdZOzguebE4j2XoBKThQ,'RunPlugin('+ttv3hOw5DMnA9XcSz8m+')')
		NNj0O8UubPyDmJ9pZEkeRCQxMrB61n.append(Y5Yv2huKOTtC9DFmwGI0)
	wkTDKi3RbnxGJhM2zBPW1cHXV = [0,150,160,170,190,260,280,330,340,410,500,520,530,540,760,1010,9990]
	WWaxKrwNJs7vmG5XuFD8 = ZZtDTHnBXMz-ZZtDTHnBXMz%10
	if ZZtDTHnBXMz%10:
		if WWaxKrwNJs7vmG5XuFD8==280: WWaxKrwNJs7vmG5XuFD8 = 230
		if WWaxKrwNJs7vmG5XuFD8==410: WWaxKrwNJs7vmG5XuFD8 = 400
		if WWaxKrwNJs7vmG5XuFD8==520: WWaxKrwNJs7vmG5XuFD8 = 510
		if WWaxKrwNJs7vmG5XuFD8 not in wkTDKi3RbnxGJhM2zBPW1cHXV:
			ttv3hOw5DMnA9XcSz8m = 'plugin://'+DFUIv2KGj9ke+'?context=8&mode='+str(WWaxKrwNJs7vmG5XuFD8)
			yyCDnI7HSdZOzguebE4j2XoBKThQ = OkuB9nwhD8U1+'قائمة الموقع'+hAIp8kmC36T5WFPMSXOwnNbtD
			Y5Yv2huKOTtC9DFmwGI0 = (yyCDnI7HSdZOzguebE4j2XoBKThQ,'RunPlugin('+ttv3hOw5DMnA9XcSz8m+')')
			NNj0O8UubPyDmJ9pZEkeRCQxMrB61n.append(Y5Yv2huKOTtC9DFmwGI0)
	ttv3hOw5DMnA9XcSz8m = zCraF3NZ4o5xUOeESbAflhTH7+'&context=9'
	yyCDnI7HSdZOzguebE4j2XoBKThQ = OkuB9nwhD8U1+'تحديث القائمة'+hAIp8kmC36T5WFPMSXOwnNbtD
	Y5Yv2huKOTtC9DFmwGI0 = (yyCDnI7HSdZOzguebE4j2XoBKThQ,'RunPlugin('+ttv3hOw5DMnA9XcSz8m+')')
	NNj0O8UubPyDmJ9pZEkeRCQxMrB61n.append(Y5Yv2huKOTtC9DFmwGI0)
	if A60AIQZCYRzdhaeWfOtmrSUVoq2nN in ['video','live']:
		ttv3hOw5DMnA9XcSz8m = zCraF3NZ4o5xUOeESbAflhTH7+'&context=18'
		yyCDnI7HSdZOzguebE4j2XoBKThQ = OkuB9nwhD8U1+'إظهار قوائم الجودة'+hAIp8kmC36T5WFPMSXOwnNbtD
		Y5Yv2huKOTtC9DFmwGI0 = (yyCDnI7HSdZOzguebE4j2XoBKThQ,'RunPlugin('+ttv3hOw5DMnA9XcSz8m+')')
		NNj0O8UubPyDmJ9pZEkeRCQxMrB61n.append(Y5Yv2huKOTtC9DFmwGI0)
	if A60AIQZCYRzdhaeWfOtmrSUVoq2nN in ['link','video','live']: gcwvEB9LebnltOjCKMm5IYuiRq = False
	elif A60AIQZCYRzdhaeWfOtmrSUVoq2nN=='folder': gcwvEB9LebnltOjCKMm5IYuiRq = True
	m9xqXkhIA6rGCDpnRBtFT0['name'] = c17XeRIH2gVh3px8sw
	m9xqXkhIA6rGCDpnRBtFT0['context_menu'] = NNj0O8UubPyDmJ9pZEkeRCQxMrB61n
	if 'plot' in list(ZzHaCLyPtIk1iurbW.keys()): m9xqXkhIA6rGCDpnRBtFT0['plot'] = ZzHaCLyPtIk1iurbW['plot']
	if 'stars' in list(ZzHaCLyPtIk1iurbW.keys()): m9xqXkhIA6rGCDpnRBtFT0['stars'] = ZzHaCLyPtIk1iurbW['stars']
	if ChvkSxHr6QoKJg: m9xqXkhIA6rGCDpnRBtFT0['image'] = ChvkSxHr6QoKJg
	if A60AIQZCYRzdhaeWfOtmrSUVoq2nN=='video' and fo6RghJpm4cHa1OPjL:
		DAtpbZWyz0aS4r3q8HLd1 = YYBlm36zd0Jst18LXwo4.findall('[\d:]+',fo6RghJpm4cHa1OPjL,YYBlm36zd0Jst18LXwo4.DOTALL)
		if DAtpbZWyz0aS4r3q8HLd1:
			DAtpbZWyz0aS4r3q8HLd1 = '0:0:0:0:0:'+DAtpbZWyz0aS4r3q8HLd1[0]
			qipmn9G8hQf74UsRD,ap9CdE4ePfXDFi5M,tBo9If51cdWyJ2S4nVrz6U,YYBSRyEmOvrFHp1tNJP9ZQa5MLDfVh,FCaTY6DKhWfidoBZJVsk1RE = DAtpbZWyz0aS4r3q8HLd1.rsplit(':',4)
			YtLwjVMNO5Hkc = int(ap9CdE4ePfXDFi5M)*24*n4GUoTyqdKik9VSLE3W5pt8zJlug+int(tBo9If51cdWyJ2S4nVrz6U)*n4GUoTyqdKik9VSLE3W5pt8zJlug+int(YYBSRyEmOvrFHp1tNJP9ZQa5MLDfVh)*60+int(FCaTY6DKhWfidoBZJVsk1RE)
			m9xqXkhIA6rGCDpnRBtFT0['duration'] = YtLwjVMNO5Hkc
	m9xqXkhIA6rGCDpnRBtFT0['type'] = A60AIQZCYRzdhaeWfOtmrSUVoq2nN
	m9xqXkhIA6rGCDpnRBtFT0['isFolder'] = gcwvEB9LebnltOjCKMm5IYuiRq
	m9xqXkhIA6rGCDpnRBtFT0['newpath'] = zCraF3NZ4o5xUOeESbAflhTH7
	m9xqXkhIA6rGCDpnRBtFT0['menuItem'] = KKHsXdETa4uckBQJWlRVPU3mbrh
	m9xqXkhIA6rGCDpnRBtFT0['mode'] = ZZtDTHnBXMz
	return m9xqXkhIA6rGCDpnRBtFT0
def UNdoh3qEzIe2g(KxCsNutraQ0b):
	zD7ltW4mNcZqKojFJb3I6OgVfT,u2jARE57amCQSwZLkiO9qzrg1P = [],b8Qe150xVaJsnDSv
	from pxDVAc9OnY import osUVxR3cueih25tjHwQf,BsO7uWjxMtDA9a23H1
	k0x2QVr6LOd = osUVxR3cueih25tjHwQf()
	iPKbSRLnl2HJxFMjwQkGza = hRWC8YSFvsm4JHOMVIne3jquZ.getSetting('av.status.refresh')
	if ZqDQCMovyXKFG7ki4BrahuWt1IS8 and (not iPKbSRLnl2HJxFMjwQkGza or iPKbSRLnl2HJxFMjwQkGza=='REFRESH_CACHE'): iPKbSRLnl2HJxFMjwQkGza = SS2OK7hjLagvUAm(mshLJcKH1fv03yRnDOr4ZT,'str','FOLDERS_SORT',ZqDQCMovyXKFG7ki4BrahuWt1IS8)
	if iPKbSRLnl2HJxFMjwQkGza:
		if   '_PERM' in iPKbSRLnl2HJxFMjwQkGza: u2jARE57amCQSwZLkiO9qzrg1P = 'دائمي'
		elif '_TEMP' in iPKbSRLnl2HJxFMjwQkGza: u2jARE57amCQSwZLkiO9qzrg1P = 'مؤقت'
		if   '_REVERSED_' in iPKbSRLnl2HJxFMjwQkGza: WUj71fhxld3rqONpBzmEuC = 'عكسي' ; GyjmfosC59Jub[:] = reversed(GyjmfosC59Jub)
		elif '_ASCENDED_' in iPKbSRLnl2HJxFMjwQkGza: WUj71fhxld3rqONpBzmEuC = 'تصاعدي' ; GyjmfosC59Jub[:] = sorted(GyjmfosC59Jub,reverse=DD5cFIejQa2X4BgAu9GWPyJ3tC7,key=lambda key:key[qHYIWnOZLPkrQU])
		elif '_DESCENDED_' in iPKbSRLnl2HJxFMjwQkGza: WUj71fhxld3rqONpBzmEuC = 'تنازلي' ; GyjmfosC59Jub[:] = sorted(GyjmfosC59Jub,reverse=CCxMXuNUEzolDZTKrBJ,key=lambda key:key[qHYIWnOZLPkrQU])
		elif '_RANDOMIZED_' in iPKbSRLnl2HJxFMjwQkGza: WUj71fhxld3rqONpBzmEuC = 'عشوائي' ; qHiNBx6PXjKatkWf37AwFClzsp2DmE.shuffle(GyjmfosC59Jub)
	name = 'ترتيب '+WUj71fhxld3rqONpBzmEuC+pldxivXC5wbTB2O8q+u2jARE57amCQSwZLkiO9qzrg1P if u2jARE57amCQSwZLkiO9qzrg1P else 'بدون ترتيب (أصلي)'
	name = OkuB9nwhD8U1+name+hAIp8kmC36T5WFPMSXOwnNbtD
	if iPKbSRLnl2HJxFMjwQkGza in UhVAT46l59JBLO2rKI0zZ: hRWC8YSFvsm4JHOMVIne3jquZ.setSetting('av.status.refresh',b8Qe150xVaJsnDSv)
	E57WK4m31C8,rlqNUcK9vYgkT,YabJfs3q7yjpzvXioO,Q8ZnJhRz2mINwrY6VPf,I6YPOSofrpnTwRm8b,NGQDwOCXx1BZmd9Huc,vv5M4UfJS9ucKEiNbxtnaOZ,wc0Z9FAdf2B1J,XXra5dzn8tcLOxYZIE7pPof49Hh = rhoGF8ta4UesmTucY6V2O1A(ZqDQCMovyXKFG7ki4BrahuWt1IS8)
	wkTDKi3RbnxGJhM2zBPW1cHXV = [0,150,160,170,190,260,280,330,340,410,500,520,530,540,760,1010,9990,1020]
	ZZtDTHnBXMz = int(Q8ZnJhRz2mINwrY6VPf)
	WWaxKrwNJs7vmG5XuFD8 = ZZtDTHnBXMz-ZZtDTHnBXMz%10
	if ZZtDTHnBXMz%10 and WWaxKrwNJs7vmG5XuFD8 not in wkTDKi3RbnxGJhM2zBPW1cHXV and len(GyjmfosC59Jub)>1:
		GyjmfosC59Jub[:] = [('link',name,'',533,'','',ZqDQCMovyXKFG7ki4BrahuWt1IS8,'','')]+GyjmfosC59Jub
	for KKHsXdETa4uckBQJWlRVPU3mbrh in GyjmfosC59Jub:
		m9xqXkhIA6rGCDpnRBtFT0 = jjvaJcbTrUMf7XVBFNZEtCqHmwhP(KKHsXdETa4uckBQJWlRVPU3mbrh,KxCsNutraQ0b,k0x2QVr6LOd)
		if m9xqXkhIA6rGCDpnRBtFT0['favorites']:
			lrXuCKaYjZLV7pqOWdPQwFcoiBHen = BsO7uWjxMtDA9a23H1(k0x2QVr6LOd,m9xqXkhIA6rGCDpnRBtFT0['menuItem'],m9xqXkhIA6rGCDpnRBtFT0['newpath'])
			m9xqXkhIA6rGCDpnRBtFT0['context_menu'] = lrXuCKaYjZLV7pqOWdPQwFcoiBHen+m9xqXkhIA6rGCDpnRBtFT0['context_menu']
		zD7ltW4mNcZqKojFJb3I6OgVfT.append(m9xqXkhIA6rGCDpnRBtFT0)
	return zD7ltW4mNcZqKojFJb3I6OgVfT
def hEsak1gHpZjOUFGtRlPdC5JrM(bbRcgP2UL3pV7IkSdWJ1OZm6AvYXw):
	rryAORupGNEvU2Z9CLz6QMfcWY,LI145HqhSfdRbu3NMvexwcyYE7Fn2Z, = [],b8Qe150xVaJsnDSv
	for XcB7EqbZMOW9RuYnD62V4F3jrhvp in bbRcgP2UL3pV7IkSdWJ1OZm6AvYXw:
		if not XcB7EqbZMOW9RuYnD62V4F3jrhvp: rryAORupGNEvU2Z9CLz6QMfcWY.append(b8Qe150xVaJsnDSv)
		else: break
	bbRcgP2UL3pV7IkSdWJ1OZm6AvYXw = bbRcgP2UL3pV7IkSdWJ1OZm6AvYXw[len(rryAORupGNEvU2Z9CLz6QMfcWY):]
	pnmsJqCWIHVk2Y6xPvl9Q0Ez8r = '\n\n\n\n'.join(bbRcgP2UL3pV7IkSdWJ1OZm6AvYXw)
	pnmsJqCWIHVk2Y6xPvl9Q0Ez8r = pnmsJqCWIHVk2Y6xPvl9Q0Ez8r.replace('===== ===== =====','000001')
	pnmsJqCWIHVk2Y6xPvl9Q0Ez8r = pnmsJqCWIHVk2Y6xPvl9Q0Ez8r.replace(rC3Tlno96KjLDIvBaSWUbR8,'000002')
	pnmsJqCWIHVk2Y6xPvl9Q0Ez8r = pnmsJqCWIHVk2Y6xPvl9Q0Ez8r.replace(OkuB9nwhD8U1,'000003')
	pnmsJqCWIHVk2Y6xPvl9Q0Ez8r = pnmsJqCWIHVk2Y6xPvl9Q0Ez8r.replace(hAIp8kmC36T5WFPMSXOwnNbtD,'000004')
	pnmsJqCWIHVk2Y6xPvl9Q0Ez8r = pnmsJqCWIHVk2Y6xPvl9Q0Ez8r.replace('[RIGHT]','000005')
	iNdb241X5QmGjzfhopLkc0wUgCl6DM = 100000
	xl480zmFIdhtiZVTyDCnA2kSMU6Gu1 = {}
	lHdqEivZ2x3tU1 = YYBlm36zd0Jst18LXwo4.findall('http.*?[\r\n ]',pnmsJqCWIHVk2Y6xPvl9Q0Ez8r,YYBlm36zd0Jst18LXwo4.DOTALL)
	for lToFaBexGu7Rzf86L9XIS in lHdqEivZ2x3tU1:
		iNdb241X5QmGjzfhopLkc0wUgCl6DM += 1
		pnmsJqCWIHVk2Y6xPvl9Q0Ez8r = pnmsJqCWIHVk2Y6xPvl9Q0Ez8r.replace(lToFaBexGu7Rzf86L9XIS,str(iNdb241X5QmGjzfhopLkc0wUgCl6DM))
		xl480zmFIdhtiZVTyDCnA2kSMU6Gu1[str(iNdb241X5QmGjzfhopLkc0wUgCl6DM)] = lToFaBexGu7Rzf86L9XIS
	for H9JbVKORYEGt3jo2g in range(0,len(pnmsJqCWIHVk2Y6xPvl9Q0Ez8r),4800):
		IchUYpfMSteTL1iqJuHDW8dz = pnmsJqCWIHVk2Y6xPvl9Q0Ez8r[H9JbVKORYEGt3jo2g:H9JbVKORYEGt3jo2g+4800]
		X5AD4r3iQUuLnP87t0Ncz1bq = hRWC8YSFvsm4JHOMVIne3jquZ.getSetting('av.language.code')
		uuNDjbit4hOpx = 'https://translator-api.glosbe.com/translateByLangDetect?sourceLang=ar&targetLang='+X5AD4r3iQUuLnP87t0Ncz1bq
		NNB43WbKMVnrktmcsZXUR6wvfJq = {'Content-Type':'text/plain'}
		jGiJorZRvUbXuOTL = IchUYpfMSteTL1iqJuHDW8dz.encode(OVauxZzLI10vcXT74K)
		mJegc5bW2YjVwD = dcLRAZWFzODax2jf0tHCX81pJveNY(nCUMfrlZvuiLe5x,'POST',uuNDjbit4hOpx,jGiJorZRvUbXuOTL,NNB43WbKMVnrktmcsZXUR6wvfJq,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'LIBRARY-GLOSBE_TRANSLATE-1st')
		if mJegc5bW2YjVwD.succeeded:
			RgtGekOpZJTE4 = mJegc5bW2YjVwD.content
			yZGd8e2DFYK46uP51vpAI = oJsUwXA0yGOI1mTjxQ('str',RgtGekOpZJTE4)
			if yZGd8e2DFYK46uP51vpAI:
				yZGd8e2DFYK46uP51vpAI = yZGd8e2DFYK46uP51vpAI['translation']
				yZGd8e2DFYK46uP51vpAI = ggtn0PzV7aMe(yZGd8e2DFYK46uP51vpAI)
				for LLsyevc6KqA4QG in range(len(yZGd8e2DFYK46uP51vpAI)):
					LI145HqhSfdRbu3NMvexwcyYE7Fn2Z += yZGd8e2DFYK46uP51vpAI[LLsyevc6KqA4QG][0]
	LI145HqhSfdRbu3NMvexwcyYE7Fn2Z = LI145HqhSfdRbu3NMvexwcyYE7Fn2Z.replace('000001','===== ===== =====')
	LI145HqhSfdRbu3NMvexwcyYE7Fn2Z = LI145HqhSfdRbu3NMvexwcyYE7Fn2Z.replace('000002',rC3Tlno96KjLDIvBaSWUbR8)
	LI145HqhSfdRbu3NMvexwcyYE7Fn2Z = LI145HqhSfdRbu3NMvexwcyYE7Fn2Z.replace('000003',OkuB9nwhD8U1)
	LI145HqhSfdRbu3NMvexwcyYE7Fn2Z = LI145HqhSfdRbu3NMvexwcyYE7Fn2Z.replace('000004',hAIp8kmC36T5WFPMSXOwnNbtD)
	LI145HqhSfdRbu3NMvexwcyYE7Fn2Z = LI145HqhSfdRbu3NMvexwcyYE7Fn2Z.replace('000005','[RIGHT]')
	for iNdb241X5QmGjzfhopLkc0wUgCl6DM in list(xl480zmFIdhtiZVTyDCnA2kSMU6Gu1.keys()):
		lToFaBexGu7Rzf86L9XIS = xl480zmFIdhtiZVTyDCnA2kSMU6Gu1[iNdb241X5QmGjzfhopLkc0wUgCl6DM]
		LI145HqhSfdRbu3NMvexwcyYE7Fn2Z = LI145HqhSfdRbu3NMvexwcyYE7Fn2Z.replace(iNdb241X5QmGjzfhopLkc0wUgCl6DM,lToFaBexGu7Rzf86L9XIS)
	LI145HqhSfdRbu3NMvexwcyYE7Fn2Z = LI145HqhSfdRbu3NMvexwcyYE7Fn2Z.split('\n\n\n\n')
	return rryAORupGNEvU2Z9CLz6QMfcWY+LI145HqhSfdRbu3NMvexwcyYE7Fn2Z
def wyZC6Ou4XVk(bbRcgP2UL3pV7IkSdWJ1OZm6AvYXw):
	rryAORupGNEvU2Z9CLz6QMfcWY,LI145HqhSfdRbu3NMvexwcyYE7Fn2Z, = [],b8Qe150xVaJsnDSv
	for XcB7EqbZMOW9RuYnD62V4F3jrhvp in bbRcgP2UL3pV7IkSdWJ1OZm6AvYXw:
		if not XcB7EqbZMOW9RuYnD62V4F3jrhvp: rryAORupGNEvU2Z9CLz6QMfcWY.append(b8Qe150xVaJsnDSv)
		else: break
	bbRcgP2UL3pV7IkSdWJ1OZm6AvYXw = bbRcgP2UL3pV7IkSdWJ1OZm6AvYXw[len(rryAORupGNEvU2Z9CLz6QMfcWY):]
	pnmsJqCWIHVk2Y6xPvl9Q0Ez8r = '\\n\\n\\n\\n'.join(bbRcgP2UL3pV7IkSdWJ1OZm6AvYXw)
	pnmsJqCWIHVk2Y6xPvl9Q0Ez8r = pnmsJqCWIHVk2Y6xPvl9Q0Ez8r.replace('كلا','no')
	pnmsJqCWIHVk2Y6xPvl9Q0Ez8r = pnmsJqCWIHVk2Y6xPvl9Q0Ez8r.replace('استمرار','continue')
	pnmsJqCWIHVk2Y6xPvl9Q0Ez8r = pnmsJqCWIHVk2Y6xPvl9Q0Ez8r.replace('===== ===== =====','000001')
	pnmsJqCWIHVk2Y6xPvl9Q0Ez8r = pnmsJqCWIHVk2Y6xPvl9Q0Ez8r.replace(rC3Tlno96KjLDIvBaSWUbR8,'000002')
	pnmsJqCWIHVk2Y6xPvl9Q0Ez8r = pnmsJqCWIHVk2Y6xPvl9Q0Ez8r.replace(OkuB9nwhD8U1,'000003')
	pnmsJqCWIHVk2Y6xPvl9Q0Ez8r = pnmsJqCWIHVk2Y6xPvl9Q0Ez8r.replace(hAIp8kmC36T5WFPMSXOwnNbtD,'000004')
	pnmsJqCWIHVk2Y6xPvl9Q0Ez8r = pnmsJqCWIHVk2Y6xPvl9Q0Ez8r.replace('[RIGHT]','000005')
	pnmsJqCWIHVk2Y6xPvl9Q0Ez8r = pnmsJqCWIHVk2Y6xPvl9Q0Ez8r.replace('[CENTER]','000006')
	pnmsJqCWIHVk2Y6xPvl9Q0Ez8r = pnmsJqCWIHVk2Y6xPvl9Q0Ez8r.replace('[RTL]','000007')
	pnmsJqCWIHVk2Y6xPvl9Q0Ez8r = pnmsJqCWIHVk2Y6xPvl9Q0Ez8r.replace("'","\\\\\\'")
	pnmsJqCWIHVk2Y6xPvl9Q0Ez8r = pnmsJqCWIHVk2Y6xPvl9Q0Ez8r.replace('"','\\\\\\"')
	pnmsJqCWIHVk2Y6xPvl9Q0Ez8r = pnmsJqCWIHVk2Y6xPvl9Q0Ez8r.replace(eeN6dTEnkJxI,'\\n')
	pnmsJqCWIHVk2Y6xPvl9Q0Ez8r = pnmsJqCWIHVk2Y6xPvl9Q0Ez8r.replace(d6ekSEojpFUANKJ7r9WTlI3niLBOu,'\\\\r')
	for H9JbVKORYEGt3jo2g in range(0,len(pnmsJqCWIHVk2Y6xPvl9Q0Ez8r),4800):
		IchUYpfMSteTL1iqJuHDW8dz = pnmsJqCWIHVk2Y6xPvl9Q0Ez8r[H9JbVKORYEGt3jo2g:H9JbVKORYEGt3jo2g+4800]
		uuNDjbit4hOpx = 'https://translate.google.com/_/TranslateWebserverUi/data/batchexecute'
		NNB43WbKMVnrktmcsZXUR6wvfJq = {'Content-Type':'application/x-www-form-urlencoded'}
		X5AD4r3iQUuLnP87t0Ncz1bq = hRWC8YSFvsm4JHOMVIne3jquZ.getSetting('av.language.code')
		jGiJorZRvUbXuOTL = 'f.req='+HHbaVYqFRy6v0c('[[["MkEWBc","[[\\"'+IchUYpfMSteTL1iqJuHDW8dz+'\\",\\"ar\\",\\"'+X5AD4r3iQUuLnP87t0Ncz1bq+'\\",1],[]]",null,"generic"]]]',b8Qe150xVaJsnDSv)
		jGiJorZRvUbXuOTL = jGiJorZRvUbXuOTL.replace('%5Cn','%5C%5Cn')
		mJegc5bW2YjVwD = dcLRAZWFzODax2jf0tHCX81pJveNY(nCUMfrlZvuiLe5x,'POST',uuNDjbit4hOpx,jGiJorZRvUbXuOTL,NNB43WbKMVnrktmcsZXUR6wvfJq,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'LIBRARY-GOOGLE_TRANSLATE-1st')
		if mJegc5bW2YjVwD.succeeded:
			RgtGekOpZJTE4 = mJegc5bW2YjVwD.content
			RgtGekOpZJTE4 = RgtGekOpZJTE4.split(eeN6dTEnkJxI)[-1]
			yZGd8e2DFYK46uP51vpAI = oJsUwXA0yGOI1mTjxQ('str',RgtGekOpZJTE4)[0][2]
			if yZGd8e2DFYK46uP51vpAI:
				yZGd8e2DFYK46uP51vpAI = oJsUwXA0yGOI1mTjxQ('str',yZGd8e2DFYK46uP51vpAI)[1][0][0][5]
				yZGd8e2DFYK46uP51vpAI = ggtn0PzV7aMe(yZGd8e2DFYK46uP51vpAI)
				for LLsyevc6KqA4QG in range(len(yZGd8e2DFYK46uP51vpAI)):
					LI145HqhSfdRbu3NMvexwcyYE7Fn2Z += yZGd8e2DFYK46uP51vpAI[LLsyevc6KqA4QG][0]
	LI145HqhSfdRbu3NMvexwcyYE7Fn2Z = LI145HqhSfdRbu3NMvexwcyYE7Fn2Z.replace('00000','0000').replace('0000','000')
	LI145HqhSfdRbu3NMvexwcyYE7Fn2Z = LI145HqhSfdRbu3NMvexwcyYE7Fn2Z.replace('0001','===== ===== =====')
	LI145HqhSfdRbu3NMvexwcyYE7Fn2Z = LI145HqhSfdRbu3NMvexwcyYE7Fn2Z.replace('0002',rC3Tlno96KjLDIvBaSWUbR8)
	LI145HqhSfdRbu3NMvexwcyYE7Fn2Z = LI145HqhSfdRbu3NMvexwcyYE7Fn2Z.replace('0003',OkuB9nwhD8U1)
	LI145HqhSfdRbu3NMvexwcyYE7Fn2Z = LI145HqhSfdRbu3NMvexwcyYE7Fn2Z.replace('0004',hAIp8kmC36T5WFPMSXOwnNbtD)
	LI145HqhSfdRbu3NMvexwcyYE7Fn2Z = LI145HqhSfdRbu3NMvexwcyYE7Fn2Z.replace('0005','[RIGHT]')
	LI145HqhSfdRbu3NMvexwcyYE7Fn2Z = LI145HqhSfdRbu3NMvexwcyYE7Fn2Z.replace('0006','[CENTER]')
	LI145HqhSfdRbu3NMvexwcyYE7Fn2Z = LI145HqhSfdRbu3NMvexwcyYE7Fn2Z.replace('0007','[RTL]')
	LI145HqhSfdRbu3NMvexwcyYE7Fn2Z = LI145HqhSfdRbu3NMvexwcyYE7Fn2Z.split('\n\n\n\n')
	return rryAORupGNEvU2Z9CLz6QMfcWY+LI145HqhSfdRbu3NMvexwcyYE7Fn2Z
def kkR09edIXCGbvDWMt7comurSV(bbRcgP2UL3pV7IkSdWJ1OZm6AvYXw):
	rryAORupGNEvU2Z9CLz6QMfcWY,vvTKQZb8HnpajMXAoUg3fYN = [],[]
	for XcB7EqbZMOW9RuYnD62V4F3jrhvp in bbRcgP2UL3pV7IkSdWJ1OZm6AvYXw:
		if not XcB7EqbZMOW9RuYnD62V4F3jrhvp: rryAORupGNEvU2Z9CLz6QMfcWY.append(b8Qe150xVaJsnDSv)
		else: break
	bbRcgP2UL3pV7IkSdWJ1OZm6AvYXw = bbRcgP2UL3pV7IkSdWJ1OZm6AvYXw[len(rryAORupGNEvU2Z9CLz6QMfcWY):]
	pnmsJqCWIHVk2Y6xPvl9Q0Ez8r = '\n\n\n\n'.join(bbRcgP2UL3pV7IkSdWJ1OZm6AvYXw)
	pnmsJqCWIHVk2Y6xPvl9Q0Ez8r = pnmsJqCWIHVk2Y6xPvl9Q0Ez8r.replace('كلا','no')
	pnmsJqCWIHVk2Y6xPvl9Q0Ez8r = pnmsJqCWIHVk2Y6xPvl9Q0Ez8r.replace('استمرار','continue')
	pnmsJqCWIHVk2Y6xPvl9Q0Ez8r = pnmsJqCWIHVk2Y6xPvl9Q0Ez8r.replace('أدناه','below')
	pnmsJqCWIHVk2Y6xPvl9Q0Ez8r = pnmsJqCWIHVk2Y6xPvl9Q0Ez8r.replace(rC3Tlno96KjLDIvBaSWUbR8,'00001')
	pnmsJqCWIHVk2Y6xPvl9Q0Ez8r = pnmsJqCWIHVk2Y6xPvl9Q0Ez8r.replace(OkuB9nwhD8U1,'00002')
	pnmsJqCWIHVk2Y6xPvl9Q0Ez8r = pnmsJqCWIHVk2Y6xPvl9Q0Ez8r.replace(hAIp8kmC36T5WFPMSXOwnNbtD,'00003')
	pnmsJqCWIHVk2Y6xPvl9Q0Ez8r = pnmsJqCWIHVk2Y6xPvl9Q0Ez8r.replace('=====','00004')
	pnmsJqCWIHVk2Y6xPvl9Q0Ez8r = pnmsJqCWIHVk2Y6xPvl9Q0Ez8r.replace(',','00005')
	pnmsJqCWIHVk2Y6xPvl9Q0Ez8r = pnmsJqCWIHVk2Y6xPvl9Q0Ez8r.replace('[RTL]','00009')
	pnmsJqCWIHVk2Y6xPvl9Q0Ez8r = pnmsJqCWIHVk2Y6xPvl9Q0Ez8r.replace('[CENTER]','0000A')
	pnmsJqCWIHVk2Y6xPvl9Q0Ez8r = pnmsJqCWIHVk2Y6xPvl9Q0Ez8r.replace(d6ekSEojpFUANKJ7r9WTlI3niLBOu,'0000B')
	bbRcgP2UL3pV7IkSdWJ1OZm6AvYXw = pnmsJqCWIHVk2Y6xPvl9Q0Ez8r.split(eeN6dTEnkJxI)
	pnmsJqCWIHVk2Y6xPvl9Q0Ez8r,LI145HqhSfdRbu3NMvexwcyYE7Fn2Z = b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv
	for XcB7EqbZMOW9RuYnD62V4F3jrhvp in bbRcgP2UL3pV7IkSdWJ1OZm6AvYXw:
		if len(pnmsJqCWIHVk2Y6xPvl9Q0Ez8r+XcB7EqbZMOW9RuYnD62V4F3jrhvp)<1800: pnmsJqCWIHVk2Y6xPvl9Q0Ez8r += eeN6dTEnkJxI+XcB7EqbZMOW9RuYnD62V4F3jrhvp
		else:
			vvTKQZb8HnpajMXAoUg3fYN.append(pnmsJqCWIHVk2Y6xPvl9Q0Ez8r)
			pnmsJqCWIHVk2Y6xPvl9Q0Ez8r = XcB7EqbZMOW9RuYnD62V4F3jrhvp
	vvTKQZb8HnpajMXAoUg3fYN.append(pnmsJqCWIHVk2Y6xPvl9Q0Ez8r)
	for XcB7EqbZMOW9RuYnD62V4F3jrhvp in vvTKQZb8HnpajMXAoUg3fYN:
		NNB43WbKMVnrktmcsZXUR6wvfJq = {'Content-Type':'application/json','User-Agent':b8Qe150xVaJsnDSv}
		uuNDjbit4hOpx = 'https://api.reverso.net/translate/v1/translation'
		X5AD4r3iQUuLnP87t0Ncz1bq = hRWC8YSFvsm4JHOMVIne3jquZ.getSetting('av.language.code')
		jGiJorZRvUbXuOTL = {"format":"text","from":"ara","to":X5AD4r3iQUuLnP87t0Ncz1bq,"input":XcB7EqbZMOW9RuYnD62V4F3jrhvp,"options":{"sentenceSplitter":True,"origin":"translation.web","contextResults":False,"languageDetection":False}}
		jGiJorZRvUbXuOTL = AFIDMBehNx5QH6g21E8kq9JzrLi.dumps(jGiJorZRvUbXuOTL)
		mJegc5bW2YjVwD = dcLRAZWFzODax2jf0tHCX81pJveNY(nCUMfrlZvuiLe5x,'POST',uuNDjbit4hOpx,jGiJorZRvUbXuOTL,NNB43WbKMVnrktmcsZXUR6wvfJq,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'LIBRARY-REVERSO_TRANSLATE-1st')
		if mJegc5bW2YjVwD.succeeded:
			RgtGekOpZJTE4 = mJegc5bW2YjVwD.content
			RgtGekOpZJTE4 = oJsUwXA0yGOI1mTjxQ('dict',RgtGekOpZJTE4)
			LI145HqhSfdRbu3NMvexwcyYE7Fn2Z += eeN6dTEnkJxI+b8Qe150xVaJsnDSv.join(RgtGekOpZJTE4['translation'])
	LI145HqhSfdRbu3NMvexwcyYE7Fn2Z = LI145HqhSfdRbu3NMvexwcyYE7Fn2Z[2:]
	LI145HqhSfdRbu3NMvexwcyYE7Fn2Z = LI145HqhSfdRbu3NMvexwcyYE7Fn2Z.replace('000000','00000').replace('00000','0000').replace('0000','000')
	LI145HqhSfdRbu3NMvexwcyYE7Fn2Z = LI145HqhSfdRbu3NMvexwcyYE7Fn2Z.replace('0001',rC3Tlno96KjLDIvBaSWUbR8)
	LI145HqhSfdRbu3NMvexwcyYE7Fn2Z = LI145HqhSfdRbu3NMvexwcyYE7Fn2Z.replace('0002',OkuB9nwhD8U1)
	LI145HqhSfdRbu3NMvexwcyYE7Fn2Z = LI145HqhSfdRbu3NMvexwcyYE7Fn2Z.replace('0003',hAIp8kmC36T5WFPMSXOwnNbtD)
	LI145HqhSfdRbu3NMvexwcyYE7Fn2Z = LI145HqhSfdRbu3NMvexwcyYE7Fn2Z.replace('0004','=====')
	LI145HqhSfdRbu3NMvexwcyYE7Fn2Z = LI145HqhSfdRbu3NMvexwcyYE7Fn2Z.replace('0005',',')
	LI145HqhSfdRbu3NMvexwcyYE7Fn2Z = LI145HqhSfdRbu3NMvexwcyYE7Fn2Z.replace('0009','[RTL]')
	LI145HqhSfdRbu3NMvexwcyYE7Fn2Z = LI145HqhSfdRbu3NMvexwcyYE7Fn2Z.replace('000A','[CENTER]')
	LI145HqhSfdRbu3NMvexwcyYE7Fn2Z = LI145HqhSfdRbu3NMvexwcyYE7Fn2Z.replace('000B',d6ekSEojpFUANKJ7r9WTlI3niLBOu)
	LI145HqhSfdRbu3NMvexwcyYE7Fn2Z = LI145HqhSfdRbu3NMvexwcyYE7Fn2Z.split('\n\n\n\n')
	return rryAORupGNEvU2Z9CLz6QMfcWY+LI145HqhSfdRbu3NMvexwcyYE7Fn2Z
def eqElgfi0P8r16ms(bbRcgP2UL3pV7IkSdWJ1OZm6AvYXw):
	mrOBv5Ac6NxZXegqs1GaI8 = hRWC8YSFvsm4JHOMVIne3jquZ.getSetting('av.language.translate')
	if not mrOBv5Ac6NxZXegqs1GaI8 or not bbRcgP2UL3pV7IkSdWJ1OZm6AvYXw: return bbRcgP2UL3pV7IkSdWJ1OZm6AvYXw
	dLz0kawybCP24Zq1VS6hXKm = hRWC8YSFvsm4JHOMVIne3jquZ.getSetting('av.language.provider')
	X5AD4r3iQUuLnP87t0Ncz1bq = hRWC8YSFvsm4JHOMVIne3jquZ.getSetting('av.language.code')
	DXIy7hveckSr = X5AD4r3iQUuLnP87t0Ncz1bq+'__'+str(bbRcgP2UL3pV7IkSdWJ1OZm6AvYXw)
	hRWC8YSFvsm4JHOMVIne3jquZ.setSetting('av.language.translate',b8Qe150xVaJsnDSv)
	LI145HqhSfdRbu3NMvexwcyYE7Fn2Z = SS2OK7hjLagvUAm(mshLJcKH1fv03yRnDOr4ZT,'list','TRANSLATE_'+dLz0kawybCP24Zq1VS6hXKm,DXIy7hveckSr)
	if not LI145HqhSfdRbu3NMvexwcyYE7Fn2Z:
		if dLz0kawybCP24Zq1VS6hXKm=='GOOGLE': LI145HqhSfdRbu3NMvexwcyYE7Fn2Z = wyZC6Ou4XVk(bbRcgP2UL3pV7IkSdWJ1OZm6AvYXw)
		elif dLz0kawybCP24Zq1VS6hXKm=='REVERSO': LI145HqhSfdRbu3NMvexwcyYE7Fn2Z = kkR09edIXCGbvDWMt7comurSV(bbRcgP2UL3pV7IkSdWJ1OZm6AvYXw)
		elif dLz0kawybCP24Zq1VS6hXKm=='GLOSBE': LI145HqhSfdRbu3NMvexwcyYE7Fn2Z = hEsak1gHpZjOUFGtRlPdC5JrM(bbRcgP2UL3pV7IkSdWJ1OZm6AvYXw)
		if len(bbRcgP2UL3pV7IkSdWJ1OZm6AvYXw)==len(LI145HqhSfdRbu3NMvexwcyYE7Fn2Z):
			PGudrhJF8iDkSq96XVHEQZYf5L(mshLJcKH1fv03yRnDOr4ZT,'TRANSLATE_'+dLz0kawybCP24Zq1VS6hXKm,DXIy7hveckSr,LI145HqhSfdRbu3NMvexwcyYE7Fn2Z,xkDunX3BfFiYG)
		else:
			LI145HqhSfdRbu3NMvexwcyYE7Fn2Z = bbRcgP2UL3pV7IkSdWJ1OZm6AvYXw
			yicQV3gj4q('الترجمة فشلت','Translation Failed')
	hRWC8YSFvsm4JHOMVIne3jquZ.setSetting('av.language.translate','1')
	return LI145HqhSfdRbu3NMvexwcyYE7Fn2Z
def IDZHg5QJ9YdOBCbwxSy(KKHsXdETa4uckBQJWlRVPU3mbrh,zD7ltW4mNcZqKojFJb3I6OgVfT,LhFtNIEfT6WHVi50bMYvRmCzro9A,hhrHMZbgWAySaqGo30JfpkwK,xYWR4uyPf0Um8XvQS):
	A60AIQZCYRzdhaeWfOtmrSUVoq2nN,c17XeRIH2gVh3px8sw,uuNDjbit4hOpx,ZZtDTHnBXMz,ChvkSxHr6QoKJg,EAlZ2zKn6uagcqtY3yBoMxDmSbOwk,pnmsJqCWIHVk2Y6xPvl9Q0Ez8r,czG0PxAmlw4vtWrH5eL3RubT,ZzHaCLyPtIk1iurbW = KKHsXdETa4uckBQJWlRVPU3mbrh
	x5v8p2UoT7VGwH = []
	mrOBv5Ac6NxZXegqs1GaI8 = hRWC8YSFvsm4JHOMVIne3jquZ.getSetting('av.language.translate')
	if mrOBv5Ac6NxZXegqs1GaI8:
		Jy4bKhWtn7aEQk8DUeP5iloLXTZS,OiPK0v3xS6eo,uTHnscO1yEiKBpW65FZ7A4eUC8mz = [],[],[]
		if not x5v8p2UoT7VGwH:
			for m9xqXkhIA6rGCDpnRBtFT0 in zD7ltW4mNcZqKojFJb3I6OgVfT:
				c17XeRIH2gVh3px8sw = m9xqXkhIA6rGCDpnRBtFT0['name'].replace(VfHYrPvolqbxLOd,b8Qe150xVaJsnDSv).replace(W0LQbFfMVG46dKrPzJCmvD,b8Qe150xVaJsnDSv)
				sK19n3DhM0GEBld7Pb = YYBlm36zd0Jst18LXwo4.findall('^(\[COLOR FFFFFF00\])(\d\d.\d\d) (\d\d.\d\d)(\[/COLOR\]) (.*?)$',c17XeRIH2gVh3px8sw,YYBlm36zd0Jst18LXwo4.DOTALL)
				if sK19n3DhM0GEBld7Pb:
					rryAORupGNEvU2Z9CLz6QMfcWY,wEKYAVUvSpy7Jt9ke,EuQ9dNC0nAjvTsxRbKlPzrY,kkNZlMWQrJg5OX4c,c17XeRIH2gVh3px8sw = sK19n3DhM0GEBld7Pb[0]
					sK19n3DhM0GEBld7Pb = rryAORupGNEvU2Z9CLz6QMfcWY+wEKYAVUvSpy7Jt9ke+pldxivXC5wbTB2O8q+EuQ9dNC0nAjvTsxRbKlPzrY+kkNZlMWQrJg5OX4c+pldxivXC5wbTB2O8q
				else:
					sK19n3DhM0GEBld7Pb = YYBlm36zd0Jst18LXwo4.findall('^(.*?) (\[COLOR FFFFFF00\])(\d\d.\d\d) (\d\d.\d\d)(\[/COLOR\])$',c17XeRIH2gVh3px8sw,YYBlm36zd0Jst18LXwo4.DOTALL)
					if sK19n3DhM0GEBld7Pb:
						c17XeRIH2gVh3px8sw,rryAORupGNEvU2Z9CLz6QMfcWY,EuQ9dNC0nAjvTsxRbKlPzrY,wEKYAVUvSpy7Jt9ke,kkNZlMWQrJg5OX4c = sK19n3DhM0GEBld7Pb[0]
						sK19n3DhM0GEBld7Pb = rryAORupGNEvU2Z9CLz6QMfcWY+wEKYAVUvSpy7Jt9ke+pldxivXC5wbTB2O8q+EuQ9dNC0nAjvTsxRbKlPzrY+kkNZlMWQrJg5OX4c+pldxivXC5wbTB2O8q
					else: sK19n3DhM0GEBld7Pb = b8Qe150xVaJsnDSv
				oOa5sj9qdpB0iFCGuIWwSDUKx8 = YYBlm36zd0Jst18LXwo4.findall('^(.\[COLOR FFF08C1F\]\w\w\w \[/COLOR\])(.*?)$',c17XeRIH2gVh3px8sw,YYBlm36zd0Jst18LXwo4.DOTALL)
				if oOa5sj9qdpB0iFCGuIWwSDUKx8: oOa5sj9qdpB0iFCGuIWwSDUKx8,c17XeRIH2gVh3px8sw = oOa5sj9qdpB0iFCGuIWwSDUKx8[0]
				else: oOa5sj9qdpB0iFCGuIWwSDUKx8 = b8Qe150xVaJsnDSv
				Jy4bKhWtn7aEQk8DUeP5iloLXTZS.append(sK19n3DhM0GEBld7Pb+oOa5sj9qdpB0iFCGuIWwSDUKx8)
				OiPK0v3xS6eo.append(c17XeRIH2gVh3px8sw)
			uTHnscO1yEiKBpW65FZ7A4eUC8mz = eqElgfi0P8r16ms(OiPK0v3xS6eo)
			if uTHnscO1yEiKBpW65FZ7A4eUC8mz:
				for H9JbVKORYEGt3jo2g in range(len(zD7ltW4mNcZqKojFJb3I6OgVfT)):
					m9xqXkhIA6rGCDpnRBtFT0 = zD7ltW4mNcZqKojFJb3I6OgVfT[H9JbVKORYEGt3jo2g]
					m9xqXkhIA6rGCDpnRBtFT0['name'] = Jy4bKhWtn7aEQk8DUeP5iloLXTZS[H9JbVKORYEGt3jo2g]+uTHnscO1yEiKBpW65FZ7A4eUC8mz[H9JbVKORYEGt3jo2g]
					x5v8p2UoT7VGwH.append(m9xqXkhIA6rGCDpnRBtFT0)
	if x5v8p2UoT7VGwH: zD7ltW4mNcZqKojFJb3I6OgVfT = x5v8p2UoT7VGwH
	QQvgEYCONo4WpKewsTLtia0lu,uuoxJUXYk70,YULMgiW8RI1H9d = [],0,0
	gjGOtzvkwle = hRWC8YSFvsm4JHOMVIne3jquZ.getSetting('av.status.menusimages')
	IswCxHLkpon27qdNOzvh0Ee4ibj1 = gjGOtzvkwle!='STOP'
	eiBD14I8o0P25wGqm = []
	if IswCxHLkpon27qdNOzvh0Ee4ibj1:
		q80bwurNsYAi6JXDS = x76PfMyAp1L2WejkU3.path.join(fH3Ie4SrRCsFMVo98hpN,ZZtDTHnBXMz)
		try: eiBD14I8o0P25wGqm = x76PfMyAp1L2WejkU3.listdir(q80bwurNsYAi6JXDS)
		except:
			if not x76PfMyAp1L2WejkU3.path.exists(q80bwurNsYAi6JXDS):
				try: x76PfMyAp1L2WejkU3.makedirs(q80bwurNsYAi6JXDS)
				except: pass
	B6NHVvotnPLGyeiZ8 = BBQOpJjvz5NsUenTtm('menu_item')
	VVsXSo3OEi6azHg2LhMtqWj7 = eiBD14I8o0P25wGqm
	if hDTluNxe7tCwrpqXHzdEcYRfbs and Pft6y0LvwSh48iYg7b.platform=='win32':
		VVsXSo3OEi6azHg2LhMtqWj7 = []
		for ruGITpmVgtB9lMedZ in eiBD14I8o0P25wGqm:
			ruGITpmVgtB9lMedZ = ruGITpmVgtB9lMedZ.decode('windows-1256').encode(OVauxZzLI10vcXT74K)
			VVsXSo3OEi6azHg2LhMtqWj7.append(ruGITpmVgtB9lMedZ)
	for m9xqXkhIA6rGCDpnRBtFT0 in zD7ltW4mNcZqKojFJb3I6OgVfT:
		c17XeRIH2gVh3px8sw = m9xqXkhIA6rGCDpnRBtFT0['name']
		if i1thmHk7AZquD4cM0fnp62: c17XeRIH2gVh3px8sw = c17XeRIH2gVh3px8sw.encode(OVauxZzLI10vcXT74K,'ignore').decode(OVauxZzLI10vcXT74K)
		NNj0O8UubPyDmJ9pZEkeRCQxMrB61n = m9xqXkhIA6rGCDpnRBtFT0['context_menu']
		zZyMi8PsKOT0jrC3eWFAdvnBpLXU = m9xqXkhIA6rGCDpnRBtFT0['plot']
		bbjMqa5VKOURrGlSmZ1NfP62Jz = m9xqXkhIA6rGCDpnRBtFT0['stars']
		ChvkSxHr6QoKJg = m9xqXkhIA6rGCDpnRBtFT0['image']
		A60AIQZCYRzdhaeWfOtmrSUVoq2nN = m9xqXkhIA6rGCDpnRBtFT0['type']
		DAtpbZWyz0aS4r3q8HLd1 = m9xqXkhIA6rGCDpnRBtFT0['duration']
		gcwvEB9LebnltOjCKMm5IYuiRq = m9xqXkhIA6rGCDpnRBtFT0['isFolder']
		zCraF3NZ4o5xUOeESbAflhTH7 = m9xqXkhIA6rGCDpnRBtFT0['newpath']
		BEy3Z8sT1ghmo = evil9I2DnLJcy8.ListItem(c17XeRIH2gVh3px8sw)
		BEy3Z8sT1ghmo.addContextMenuItems(NNj0O8UubPyDmJ9pZEkeRCQxMrB61n)
		gWhCoizlNtjYO6uZ = False if IswCxHLkpon27qdNOzvh0Ee4ibj1 else True
		if ChvkSxHr6QoKJg:
			BEy3Z8sT1ghmo.setArt({'icon':ChvkSxHr6QoKJg,'thumb':ChvkSxHr6QoKJg,'fanart':ChvkSxHr6QoKJg,'banner':ChvkSxHr6QoKJg,'clearart':ChvkSxHr6QoKJg,'poster':ChvkSxHr6QoKJg,'clearlogo':ChvkSxHr6QoKJg,'landscape':ChvkSxHr6QoKJg})
			gWhCoizlNtjYO6uZ = False
		elif not gWhCoizlNtjYO6uZ:
			gWhCoizlNtjYO6uZ = True
			c17XeRIH2gVh3px8sw = RkNASsitM7eYvhqL62FVlfDuZW4x(DD5cFIejQa2X4BgAu9GWPyJ3tC7,c17XeRIH2gVh3px8sw)
			c17XeRIH2gVh3px8sw = LL1ZqB5WQHbd38JXhNRF(c17XeRIH2gVh3px8sw)
			FydmOuJSj8LTz = c17XeRIH2gVh3px8sw+'.png'
			TT0c6RzP3um4Qw8nl9I = x76PfMyAp1L2WejkU3.path.join(q80bwurNsYAi6JXDS,FydmOuJSj8LTz)
			if FydmOuJSj8LTz in VVsXSo3OEi6azHg2LhMtqWj7:
				BEy3Z8sT1ghmo.setArt({'icon':TT0c6RzP3um4Qw8nl9I,'thumb':TT0c6RzP3um4Qw8nl9I,'fanart':TT0c6RzP3um4Qw8nl9I,'banner':TT0c6RzP3um4Qw8nl9I,'clearart':TT0c6RzP3um4Qw8nl9I,'poster':TT0c6RzP3um4Qw8nl9I,'clearlogo':TT0c6RzP3um4Qw8nl9I,'landscape':TT0c6RzP3um4Qw8nl9I})
				gWhCoizlNtjYO6uZ = False
			elif uuoxJUXYk70<40 and YULMgiW8RI1H9d<=3:
				try:
					NNyGtlqidQrwaS5 = asJD30IPeV(B6NHVvotnPLGyeiZ8,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,c17XeRIH2gVh3px8sw,'menu_item','center',False,TT0c6RzP3um4Qw8nl9I)
					BEy3Z8sT1ghmo.setArt({'icon':TT0c6RzP3um4Qw8nl9I,'thumb':TT0c6RzP3um4Qw8nl9I,'fanart':TT0c6RzP3um4Qw8nl9I,'banner':TT0c6RzP3um4Qw8nl9I,'clearart':TT0c6RzP3um4Qw8nl9I,'poster':TT0c6RzP3um4Qw8nl9I,'clearlogo':TT0c6RzP3um4Qw8nl9I,'landscape':TT0c6RzP3um4Qw8nl9I})
					uuoxJUXYk70 += 1
					gWhCoizlNtjYO6uZ = False
					VVsXSo3OEi6azHg2LhMtqWj7.append(FydmOuJSj8LTz)
					if uuoxJUXYk70==5: yicQV3gj4q('إضافة الكتابة لصور القائمة','انتظار',wLQCTr5lqbsVYeAHdzfhZ1F=500)
				except: YULMgiW8RI1H9d += 1
		if gWhCoizlNtjYO6uZ:
			BEy3Z8sT1ghmo.setArt({'icon':vqLz13dHTx7IaibSmfQUNeh,'thumb':vqLz13dHTx7IaibSmfQUNeh,'fanart':vqLz13dHTx7IaibSmfQUNeh,'banner':vqLz13dHTx7IaibSmfQUNeh,'clearart':vqLz13dHTx7IaibSmfQUNeh,'poster':vqLz13dHTx7IaibSmfQUNeh,'clearlogo':vqLz13dHTx7IaibSmfQUNeh,'landscape':vqLz13dHTx7IaibSmfQUNeh})
		if g1gmkxOtc2oeEZHhBiy<20:
			if zZyMi8PsKOT0jrC3eWFAdvnBpLXU: BEy3Z8sT1ghmo.setInfo('video',{'Plot':zZyMi8PsKOT0jrC3eWFAdvnBpLXU,'PlotOutline':zZyMi8PsKOT0jrC3eWFAdvnBpLXU})
			if bbjMqa5VKOURrGlSmZ1NfP62Jz: BEy3Z8sT1ghmo.setInfo('video',{'Rating':bbjMqa5VKOURrGlSmZ1NfP62Jz})
			if not ChvkSxHr6QoKJg:
				BEy3Z8sT1ghmo.setInfo('video',{'Title':c17XeRIH2gVh3px8sw})
			if A60AIQZCYRzdhaeWfOtmrSUVoq2nN=='video':
				BEy3Z8sT1ghmo.setInfo('video',{'mediatype':'tvshow'})
				if DAtpbZWyz0aS4r3q8HLd1: BEy3Z8sT1ghmo.setInfo('video',{'duration':DAtpbZWyz0aS4r3q8HLd1})
				BEy3Z8sT1ghmo.setProperty('IsPlayable','true')
		else:
			z0LD1CwlcPebGiU = BEy3Z8sT1ghmo.getVideoInfoTag()
			if bbjMqa5VKOURrGlSmZ1NfP62Jz: z0LD1CwlcPebGiU.setRating(float(bbjMqa5VKOURrGlSmZ1NfP62Jz))
			if not ChvkSxHr6QoKJg:
				z0LD1CwlcPebGiU.setTitle(c17XeRIH2gVh3px8sw)
			if A60AIQZCYRzdhaeWfOtmrSUVoq2nN=='video':
				z0LD1CwlcPebGiU.setMediaType('tvshow')
				if DAtpbZWyz0aS4r3q8HLd1: z0LD1CwlcPebGiU.setDuration(DAtpbZWyz0aS4r3q8HLd1)
				BEy3Z8sT1ghmo.setProperty('IsPlayable','true')
		QQvgEYCONo4WpKewsTLtia0lu.append((zCraF3NZ4o5xUOeESbAflhTH7,BEy3Z8sT1ghmo,gcwvEB9LebnltOjCKMm5IYuiRq))
	xMTL52Bgvu1csftCe4bq6VFpXK.setContent(IaCU04ZS1qx,'tvshows')
	DbmuE3w5VfZB = xMTL52Bgvu1csftCe4bq6VFpXK.addDirectoryItems(IaCU04ZS1qx,QQvgEYCONo4WpKewsTLtia0lu)
	xMTL52Bgvu1csftCe4bq6VFpXK.endOfDirectory(IaCU04ZS1qx,LhFtNIEfT6WHVi50bMYvRmCzro9A,hhrHMZbgWAySaqGo30JfpkwK,xYWR4uyPf0Um8XvQS)
	return DbmuE3w5VfZB
def MQtuaShrKTbdZFJ5nsR7D(A60AIQZCYRzdhaeWfOtmrSUVoq2nN,c17XeRIH2gVh3px8sw,uuNDjbit4hOpx,ZZtDTHnBXMz,ChvkSxHr6QoKJg=b8Qe150xVaJsnDSv,EAlZ2zKn6uagcqtY3yBoMxDmSbOwk=b8Qe150xVaJsnDSv,pnmsJqCWIHVk2Y6xPvl9Q0Ez8r=b8Qe150xVaJsnDSv,czG0PxAmlw4vtWrH5eL3RubT=b8Qe150xVaJsnDSv,ZzHaCLyPtIk1iurbW={}):
	c17XeRIH2gVh3px8sw = c17XeRIH2gVh3px8sw.replace(d6ekSEojpFUANKJ7r9WTlI3niLBOu,b8Qe150xVaJsnDSv).replace(eeN6dTEnkJxI,b8Qe150xVaJsnDSv).replace('\t',b8Qe150xVaJsnDSv)
	uuNDjbit4hOpx = uuNDjbit4hOpx.replace(d6ekSEojpFUANKJ7r9WTlI3niLBOu,b8Qe150xVaJsnDSv).replace(eeN6dTEnkJxI,b8Qe150xVaJsnDSv).replace('\t',b8Qe150xVaJsnDSv)
	if '_SCRIPT_' in c17XeRIH2gVh3px8sw:
		ALwGbyiBFzY7H,c17XeRIH2gVh3px8sw = c17XeRIH2gVh3px8sw.split('_SCRIPT_',qHYIWnOZLPkrQU)
		if ALwGbyiBFzY7H not in list(Jlx4HMPfuYok8zCWwhESdA29F5s.keys()): Jlx4HMPfuYok8zCWwhESdA29F5s[ALwGbyiBFzY7H] = []
		Jlx4HMPfuYok8zCWwhESdA29F5s[ALwGbyiBFzY7H].append([A60AIQZCYRzdhaeWfOtmrSUVoq2nN,c17XeRIH2gVh3px8sw,uuNDjbit4hOpx,ZZtDTHnBXMz,ChvkSxHr6QoKJg,EAlZ2zKn6uagcqtY3yBoMxDmSbOwk,pnmsJqCWIHVk2Y6xPvl9Q0Ez8r,czG0PxAmlw4vtWrH5eL3RubT,ZzHaCLyPtIk1iurbW])
	GyjmfosC59Jub.append([A60AIQZCYRzdhaeWfOtmrSUVoq2nN,c17XeRIH2gVh3px8sw,uuNDjbit4hOpx,ZZtDTHnBXMz,ChvkSxHr6QoKJg,EAlZ2zKn6uagcqtY3yBoMxDmSbOwk,pnmsJqCWIHVk2Y6xPvl9Q0Ez8r,czG0PxAmlw4vtWrH5eL3RubT,ZzHaCLyPtIk1iurbW])
	return
def pTP49ckGDYrofa2KxenumbH0(FU9Ln2K43qx5):
	if i1thmHk7AZquD4cM0fnp62: from html import unescape as _sotgkTZhGDFa7
	else:
		from HTMLParser import HTMLParser as E1rRXyFNJ2m4xien9bGhZ
		_sotgkTZhGDFa7 = E1rRXyFNJ2m4xien9bGhZ().unescape
	if '&' in FU9Ln2K43qx5 and ';' in FU9Ln2K43qx5:
		if hDTluNxe7tCwrpqXHzdEcYRfbs: FU9Ln2K43qx5 = FU9Ln2K43qx5.decode(OVauxZzLI10vcXT74K)
		FU9Ln2K43qx5 = _sotgkTZhGDFa7(FU9Ln2K43qx5)
		if hDTluNxe7tCwrpqXHzdEcYRfbs: FU9Ln2K43qx5 = FU9Ln2K43qx5.encode(OVauxZzLI10vcXT74K)
	return FU9Ln2K43qx5
def ggtn0PzV7aMe(FU9Ln2K43qx5):
	if '\\u' in FU9Ln2K43qx5:
		if hDTluNxe7tCwrpqXHzdEcYRfbs: FU9Ln2K43qx5 = FU9Ln2K43qx5.decode('unicode_escape','ignore').encode(OVauxZzLI10vcXT74K)
		elif i1thmHk7AZquD4cM0fnp62: FU9Ln2K43qx5 = FU9Ln2K43qx5.encode(OVauxZzLI10vcXT74K).decode('unicode_escape','ignore')
	return FU9Ln2K43qx5
def uTSaCs2f9dtPJ3RqGZYhywc(vvroXgl9fw5Ec6CqHMtPjn8s3iDJV,h56hnXsIuvNSLojP,vSEwNaHGgVfL8cyK7k32Xzr9dbRuY,pUW6yt1jb7GdmLzah,pnmsJqCWIHVk2Y6xPvl9Q0Ez8r,t9ZVkIrP5iSG,Iux20iOKwF4bs39zJHnMBlAPem6,cfCmEsTv7z2RoW0gjHMX5iD48atOeG,K0acEXrehU6IGPw3Lm):
	vQNpgIiU3k1caJMb0L5C = x76PfMyAp1L2WejkU3.path.dirname(K0acEXrehU6IGPw3Lm)
	if not x76PfMyAp1L2WejkU3.path.exists(vQNpgIiU3k1caJMb0L5C):
		try: x76PfMyAp1L2WejkU3.makedirs(vQNpgIiU3k1caJMb0L5C)
		except: pass
	oorGcpyguUb7z6L201dnv = BBQOpJjvz5NsUenTtm(t9ZVkIrP5iSG)
	NNyGtlqidQrwaS5 = asJD30IPeV(oorGcpyguUb7z6L201dnv,vvroXgl9fw5Ec6CqHMtPjn8s3iDJV,h56hnXsIuvNSLojP,vSEwNaHGgVfL8cyK7k32Xzr9dbRuY,pUW6yt1jb7GdmLzah,pnmsJqCWIHVk2Y6xPvl9Q0Ez8r,t9ZVkIrP5iSG,Iux20iOKwF4bs39zJHnMBlAPem6,cfCmEsTv7z2RoW0gjHMX5iD48atOeG,K0acEXrehU6IGPw3Lm)
	return NNyGtlqidQrwaS5
def BBQOpJjvz5NsUenTtm(t9ZVkIrP5iSG):
	MMgoxqaiRNZds = 5
	MMuJp3KLAsD6xCnY = 20
	E7yr4SW2fT = 20
	hhuZiLKoScWQq7nB0IvMadwr8 = 0
	XLrBMA4ipgbj = 'center'
	d2dh1YNjnlF5SMoAkvCrbH4BV = 0
	HOcs3X6RqdpCa = 19
	coHBavAgSRQrbC = 30
	A1uRvmwKzcn58DNZkxgXCqj = 8
	n6iIgMWz8TDaG2vrUdV = True
	xU6a3PlwLGf1ZqcmrV = 375
	xxRE0pSfXT5cynAHOGzkauJvb8rL = 410
	mK1dHwE4AU8kfshZ = 50
	qURKMAfXlhGNI45mWCeJxbic6D3 = 280
	ctz4fZRY0qCyaVgso5NlkE = 28
	rrexwPHcjtE = 5
	uifQmNy7xRSPJvOKDUkTGHo0XL4p2 = 0
	zPL8ofDBnFgtua = 31
	MM6jCvFOywH = [36,32,28]
	from PIL import ImageDraw as S4TFcnYvxCGyBa1ZReLUD6srzI,ImageFont as gIpbXNR8rzLOKDdv57Z0twCEiF,Image as XhvOTF0nH63MiUYz
	if 'notification' in t9ZVkIrP5iSG:
		if t9ZVkIrP5iSG=='notification_regular':
			eLBCHMFdXo5qaDp7trEU0ZhA23 = 117
			XLrBMA4ipgbj = 'left'
			n6iIgMWz8TDaG2vrUdV = False
		elif t9ZVkIrP5iSG=='notification_auto':
			eLBCHMFdXo5qaDp7trEU0ZhA23 = 'UPPER'
			XLrBMA4ipgbj = 'right'
			hhuZiLKoScWQq7nB0IvMadwr8 = 10
		hH4gzqLnR5lME7 = 720
		MM6jCvFOywH = [33,33,33]
		E7yr4SW2fT = 20
		MMuJp3KLAsD6xCnY = 0
		coHBavAgSRQrbC = 20
		HOcs3X6RqdpCa = 35
	elif t9ZVkIrP5iSG=='menu_item':
		MM6jCvFOywH,hH4gzqLnR5lME7,eLBCHMFdXo5qaDp7trEU0ZhA23 = [28,28,28],200,250
		d2dh1YNjnlF5SMoAkvCrbH4BV,coHBavAgSRQrbC,HOcs3X6RqdpCa, = 0,-12,-30
		MMuJp3KLAsD6xCnY = 0
		nYTgm0R3wqIGNAoiK8pjkE9az = XhvOTF0nH63MiUYz.open(vqLz13dHTx7IaibSmfQUNeh)
		qAHc0iwyRJdYmS = XhvOTF0nH63MiUYz.new('RGBA',(hH4gzqLnR5lME7,eLBCHMFdXo5qaDp7trEU0ZhA23),(255,0,0,255))
	elif t9ZVkIrP5iSG=='confirm_smallfont': MM6jCvFOywH,eLBCHMFdXo5qaDp7trEU0ZhA23,hH4gzqLnR5lME7 = [28,24,20],500,900
	elif t9ZVkIrP5iSG=='confirm_mediumfont': MM6jCvFOywH,eLBCHMFdXo5qaDp7trEU0ZhA23,hH4gzqLnR5lME7 = [32,28,24],500,900
	elif t9ZVkIrP5iSG=='confirm_bigfont': MM6jCvFOywH,eLBCHMFdXo5qaDp7trEU0ZhA23,hH4gzqLnR5lME7 = [36,32,28],500,900
	elif t9ZVkIrP5iSG=='textview_bigfont': eLBCHMFdXo5qaDp7trEU0ZhA23,hH4gzqLnR5lME7 = 740,1270
	elif t9ZVkIrP5iSG=='textview_bigfont_long': eLBCHMFdXo5qaDp7trEU0ZhA23,hH4gzqLnR5lME7 = 'UPPER',1270
	elif t9ZVkIrP5iSG=='textview_smallfont': MM6jCvFOywH,eLBCHMFdXo5qaDp7trEU0ZhA23,hH4gzqLnR5lME7 = [28,23,18],740,1270
	elif t9ZVkIrP5iSG=='textview_smallfont_long': MM6jCvFOywH,eLBCHMFdXo5qaDp7trEU0ZhA23,hH4gzqLnR5lME7 = [28,23,18],'UPPER',1270
	c68gYyA2ZGhLCrR4PolD3,As1qEgnF5peU82P0rb,rNH7S5FVMti8IvZAD63phBkCqau = MM6jCvFOywH
	oDC0i3NHmYX9Ed4Mgnq7yaOFPSUx = gIpbXNR8rzLOKDdv57Z0twCEiF.truetype(qumpT0Qr1ZhUWnHO7,size=c68gYyA2ZGhLCrR4PolD3)
	OOdqUmir7h = gIpbXNR8rzLOKDdv57Z0twCEiF.truetype(qumpT0Qr1ZhUWnHO7,size=As1qEgnF5peU82P0rb)
	teRQO2gBnbrPD9qL = gIpbXNR8rzLOKDdv57Z0twCEiF.truetype(qumpT0Qr1ZhUWnHO7,size=rNH7S5FVMti8IvZAD63phBkCqau)
	M1CRIUtvfik3jLasHSDFu6XOcb2 = hH4gzqLnR5lME7-coHBavAgSRQrbC*2
	gTB1QcZeJLqDM3h29a7izy8kGvWAjs = XhvOTF0nH63MiUYz.new('RGBA',(M1CRIUtvfik3jLasHSDFu6XOcb2,100),(255,255,255,0))
	TTpWOv0XsEYbdcZC2PlM = S4TFcnYvxCGyBa1ZReLUD6srzI.Draw(gTB1QcZeJLqDM3h29a7izy8kGvWAjs)
	qAcsVuhQGEFSO9x,LLgVG7TX4JS2er8cniO5tNP6vKM = TTpWOv0XsEYbdcZC2PlM.textsize('HHH BBB 888 000',font=oDC0i3NHmYX9Ed4Mgnq7yaOFPSUx)
	qxgV7jb4uHT,V5JiKByc0AWFpahGr = TTpWOv0XsEYbdcZC2PlM.textsize('HHH BBB 888 000',font=OOdqUmir7h)
	A45Ti8Pzx7b = {'delete_harakat':False,'support_ligatures':True,'ARABIC LIGATURE ALLAH':False}
	from arabic_reshaper import ArabicReshaper as CIgP8ZvyWFDULb
	MIdGngazWmElAtRiSuK6 = CIgP8ZvyWFDULb(configuration=A45Ti8Pzx7b)
	oorGcpyguUb7z6L201dnv = {}
	qZ1VctP4g7xdi8u320LUeSIW = locals()
	for w2wJmSDK8fitdLVAaMRpNEPGc0g in qZ1VctP4g7xdi8u320LUeSIW: oorGcpyguUb7z6L201dnv[w2wJmSDK8fitdLVAaMRpNEPGc0g] = qZ1VctP4g7xdi8u320LUeSIW[w2wJmSDK8fitdLVAaMRpNEPGc0g]
	return oorGcpyguUb7z6L201dnv
def asJD30IPeV(oorGcpyguUb7z6L201dnv,vvroXgl9fw5Ec6CqHMtPjn8s3iDJV,h56hnXsIuvNSLojP,vSEwNaHGgVfL8cyK7k32Xzr9dbRuY,pUW6yt1jb7GdmLzah,pnmsJqCWIHVk2Y6xPvl9Q0Ez8r,t9ZVkIrP5iSG,Iux20iOKwF4bs39zJHnMBlAPem6,cfCmEsTv7z2RoW0gjHMX5iD48atOeG,K0acEXrehU6IGPw3Lm):
	for w2wJmSDK8fitdLVAaMRpNEPGc0g in oorGcpyguUb7z6L201dnv: globals()[w2wJmSDK8fitdLVAaMRpNEPGc0g] = oorGcpyguUb7z6L201dnv[w2wJmSDK8fitdLVAaMRpNEPGc0g]
	global ctz4fZRY0qCyaVgso5NlkE,rrexwPHcjtE
	if t9ZVkIrP5iSG!='menu_item':
		mrOBv5Ac6NxZXegqs1GaI8 = hRWC8YSFvsm4JHOMVIne3jquZ.getSetting('av.language.translate')
		if mrOBv5Ac6NxZXegqs1GaI8:
			if vvroXgl9fw5Ec6CqHMtPjn8s3iDJV=='نعم  Yes': vvroXgl9fw5Ec6CqHMtPjn8s3iDJV = 'Yes'
			elif vvroXgl9fw5Ec6CqHMtPjn8s3iDJV=='كلا  No': vvroXgl9fw5Ec6CqHMtPjn8s3iDJV = 'No'
			if h56hnXsIuvNSLojP=='نعم  Yes': h56hnXsIuvNSLojP = 'Yes'
			elif h56hnXsIuvNSLojP=='كلا  No': h56hnXsIuvNSLojP = 'No'
			if vSEwNaHGgVfL8cyK7k32Xzr9dbRuY=='نعم  Yes': vSEwNaHGgVfL8cyK7k32Xzr9dbRuY = 'Yes'
			elif vSEwNaHGgVfL8cyK7k32Xzr9dbRuY=='كلا  No': vSEwNaHGgVfL8cyK7k32Xzr9dbRuY = 'No'
			kpd8hRM9mn = eqElgfi0P8r16ms([vvroXgl9fw5Ec6CqHMtPjn8s3iDJV,h56hnXsIuvNSLojP,vSEwNaHGgVfL8cyK7k32Xzr9dbRuY,pUW6yt1jb7GdmLzah,pnmsJqCWIHVk2Y6xPvl9Q0Ez8r])
			if kpd8hRM9mn: vvroXgl9fw5Ec6CqHMtPjn8s3iDJV,h56hnXsIuvNSLojP,vSEwNaHGgVfL8cyK7k32Xzr9dbRuY,pUW6yt1jb7GdmLzah,pnmsJqCWIHVk2Y6xPvl9Q0Ez8r = kpd8hRM9mn
	if hDTluNxe7tCwrpqXHzdEcYRfbs:
		pnmsJqCWIHVk2Y6xPvl9Q0Ez8r = pnmsJqCWIHVk2Y6xPvl9Q0Ez8r.decode(OVauxZzLI10vcXT74K)
		pUW6yt1jb7GdmLzah = pUW6yt1jb7GdmLzah.decode(OVauxZzLI10vcXT74K)
		vvroXgl9fw5Ec6CqHMtPjn8s3iDJV = vvroXgl9fw5Ec6CqHMtPjn8s3iDJV.decode(OVauxZzLI10vcXT74K)
		h56hnXsIuvNSLojP = h56hnXsIuvNSLojP.decode(OVauxZzLI10vcXT74K)
		vSEwNaHGgVfL8cyK7k32Xzr9dbRuY = vSEwNaHGgVfL8cyK7k32Xzr9dbRuY.decode(OVauxZzLI10vcXT74K)
	lAWzPEZMjGnkd1h07wK = pUW6yt1jb7GdmLzah.count(eeN6dTEnkJxI)+1
	FaMLlCx8Vtz4 = MMuJp3KLAsD6xCnY+lAWzPEZMjGnkd1h07wK*(LLgVG7TX4JS2er8cniO5tNP6vKM+hhuZiLKoScWQq7nB0IvMadwr8)-hhuZiLKoScWQq7nB0IvMadwr8
	if pnmsJqCWIHVk2Y6xPvl9Q0Ez8r:
		hGTbJ0I8EMFj3 = V5JiKByc0AWFpahGr+A1uRvmwKzcn58DNZkxgXCqj
		ojCSYG8PkAI9MXq = MIdGngazWmElAtRiSuK6.reshape(pnmsJqCWIHVk2Y6xPvl9Q0Ez8r)
		if n6iIgMWz8TDaG2vrUdV:
			EQMfcLYqh3jivaTgbImyClDJeHz = Rpt3i0BYnG7MjT5PcJ4uDaZS8lsX(TTpWOv0XsEYbdcZC2PlM,OOdqUmir7h,ojCSYG8PkAI9MXq,As1qEgnF5peU82P0rb,M1CRIUtvfik3jLasHSDFu6XOcb2,hGTbJ0I8EMFj3)
			JJLVUQrpke1dfn = f7Hl8kTOqsQ0VrD2XKBLpeFAoMwg(EQMfcLYqh3jivaTgbImyClDJeHz)
			sAyZ3XnKMP = JJLVUQrpke1dfn.count(eeN6dTEnkJxI)+1
			iR9pcbek7MX8HI = HOcs3X6RqdpCa+sAyZ3XnKMP*hGTbJ0I8EMFj3-A1uRvmwKzcn58DNZkxgXCqj
		else:
			iR9pcbek7MX8HI = HOcs3X6RqdpCa+V5JiKByc0AWFpahGr
			JJLVUQrpke1dfn = ojCSYG8PkAI9MXq.split(eeN6dTEnkJxI)[0]
			EQMfcLYqh3jivaTgbImyClDJeHz = ojCSYG8PkAI9MXq.split(eeN6dTEnkJxI)[0]
	else: iR9pcbek7MX8HI = HOcs3X6RqdpCa
	VLuq58AJWE2ReNidwBzUHmcjFPIrp = uifQmNy7xRSPJvOKDUkTGHo0XL4p2+zPL8ofDBnFgtua
	if cfCmEsTv7z2RoW0gjHMX5iD48atOeG:
		ehVwk0l6CZrHD = xxRE0pSfXT5cynAHOGzkauJvb8rL-xU6a3PlwLGf1ZqcmrV
		VLuq58AJWE2ReNidwBzUHmcjFPIrp += ehVwk0l6CZrHD
	else: ehVwk0l6CZrHD = 0
	if vvroXgl9fw5Ec6CqHMtPjn8s3iDJV or h56hnXsIuvNSLojP or vSEwNaHGgVfL8cyK7k32Xzr9dbRuY: VLuq58AJWE2ReNidwBzUHmcjFPIrp += mK1dHwE4AU8kfshZ
	NNyGtlqidQrwaS5 = eLBCHMFdXo5qaDp7trEU0ZhA23 if eLBCHMFdXo5qaDp7trEU0ZhA23!='UPPER' else FaMLlCx8Vtz4+iR9pcbek7MX8HI+VLuq58AJWE2ReNidwBzUHmcjFPIrp
	gTB1QcZeJLqDM3h29a7izy8kGvWAjs = XhvOTF0nH63MiUYz.new('RGBA',(hH4gzqLnR5lME7,NNyGtlqidQrwaS5),(255,255,255,0))
	qpHn0MYIk5GcP4i = S4TFcnYvxCGyBa1ZReLUD6srzI.Draw(gTB1QcZeJLqDM3h29a7izy8kGvWAjs)
	IIoOnXCkYmlUsSr7 = NNyGtlqidQrwaS5-FaMLlCx8Vtz4-VLuq58AJWE2ReNidwBzUHmcjFPIrp-HOcs3X6RqdpCa
	if not h56hnXsIuvNSLojP and vvroXgl9fw5Ec6CqHMtPjn8s3iDJV and vSEwNaHGgVfL8cyK7k32Xzr9dbRuY:
		ctz4fZRY0qCyaVgso5NlkE += 105
		rrexwPHcjtE -= 110
	import bidi.algorithm as cEQtfYbzRv8Z
	if pUW6yt1jb7GdmLzah:
		fyNZqew5VA6gMnTYtu9HQLoK = MMuJp3KLAsD6xCnY
		pUW6yt1jb7GdmLzah = cEQtfYbzRv8Z.get_display(MIdGngazWmElAtRiSuK6.reshape(pUW6yt1jb7GdmLzah))
		bbRcgP2UL3pV7IkSdWJ1OZm6AvYXw = pUW6yt1jb7GdmLzah.splitlines()
		for XcB7EqbZMOW9RuYnD62V4F3jrhvp in bbRcgP2UL3pV7IkSdWJ1OZm6AvYXw:
			if XcB7EqbZMOW9RuYnD62V4F3jrhvp:
				C4Uu8gpaSykID21jzxKQ,sqnTD6F9c3RGCVpN2fBY4Ml = qpHn0MYIk5GcP4i.textsize(XcB7EqbZMOW9RuYnD62V4F3jrhvp,font=oDC0i3NHmYX9Ed4Mgnq7yaOFPSUx)
				if XLrBMA4ipgbj=='center': s5jH7Zw3rti4g9nWQJhcqbv = MMgoxqaiRNZds+(hH4gzqLnR5lME7-C4Uu8gpaSykID21jzxKQ)/2
				elif XLrBMA4ipgbj=='right': s5jH7Zw3rti4g9nWQJhcqbv = MMgoxqaiRNZds+hH4gzqLnR5lME7-C4Uu8gpaSykID21jzxKQ-E7yr4SW2fT
				elif XLrBMA4ipgbj=='left': s5jH7Zw3rti4g9nWQJhcqbv = MMgoxqaiRNZds+E7yr4SW2fT
				qpHn0MYIk5GcP4i.text((s5jH7Zw3rti4g9nWQJhcqbv,fyNZqew5VA6gMnTYtu9HQLoK),XcB7EqbZMOW9RuYnD62V4F3jrhvp,font=oDC0i3NHmYX9Ed4Mgnq7yaOFPSUx,fill='yellow')
			fyNZqew5VA6gMnTYtu9HQLoK += c68gYyA2ZGhLCrR4PolD3+hhuZiLKoScWQq7nB0IvMadwr8
	if vvroXgl9fw5Ec6CqHMtPjn8s3iDJV or h56hnXsIuvNSLojP or vSEwNaHGgVfL8cyK7k32Xzr9dbRuY:
		ECHgvbW2YAVN0Boc6mIJ = FaMLlCx8Vtz4+IIoOnXCkYmlUsSr7+HOcs3X6RqdpCa+ehVwk0l6CZrHD+uifQmNy7xRSPJvOKDUkTGHo0XL4p2
		if vvroXgl9fw5Ec6CqHMtPjn8s3iDJV:
			vvroXgl9fw5Ec6CqHMtPjn8s3iDJV = cEQtfYbzRv8Z.get_display(MIdGngazWmElAtRiSuK6.reshape(vvroXgl9fw5Ec6CqHMtPjn8s3iDJV))
			dDzCN6GmlBw7huS9abnfp,SS1huEHFeiwg7DTNZG = qpHn0MYIk5GcP4i.textsize(vvroXgl9fw5Ec6CqHMtPjn8s3iDJV,font=teRQO2gBnbrPD9qL)
			HkTvFa3UCGrZqIWE8B5c4 = ctz4fZRY0qCyaVgso5NlkE+0*(rrexwPHcjtE+qURKMAfXlhGNI45mWCeJxbic6D3)+(qURKMAfXlhGNI45mWCeJxbic6D3-dDzCN6GmlBw7huS9abnfp)/2
			qpHn0MYIk5GcP4i.text((HkTvFa3UCGrZqIWE8B5c4,ECHgvbW2YAVN0Boc6mIJ),vvroXgl9fw5Ec6CqHMtPjn8s3iDJV,font=teRQO2gBnbrPD9qL,fill='yellow')
		if h56hnXsIuvNSLojP:
			h56hnXsIuvNSLojP = cEQtfYbzRv8Z.get_display(MIdGngazWmElAtRiSuK6.reshape(h56hnXsIuvNSLojP))
			txsmJAXLi25rH7jaVkBlySCqI,Y8EIQqOdwes5RZgbi6 = qpHn0MYIk5GcP4i.textsize(h56hnXsIuvNSLojP,font=teRQO2gBnbrPD9qL)
			YrTfRX1iGqtJPe4n8pw5Z = ctz4fZRY0qCyaVgso5NlkE+1*(rrexwPHcjtE+qURKMAfXlhGNI45mWCeJxbic6D3)+(qURKMAfXlhGNI45mWCeJxbic6D3-txsmJAXLi25rH7jaVkBlySCqI)/2
			qpHn0MYIk5GcP4i.text((YrTfRX1iGqtJPe4n8pw5Z,ECHgvbW2YAVN0Boc6mIJ),h56hnXsIuvNSLojP,font=teRQO2gBnbrPD9qL,fill='yellow')
		if vSEwNaHGgVfL8cyK7k32Xzr9dbRuY:
			vSEwNaHGgVfL8cyK7k32Xzr9dbRuY = cEQtfYbzRv8Z.get_display(MIdGngazWmElAtRiSuK6.reshape(vSEwNaHGgVfL8cyK7k32Xzr9dbRuY))
			SWP0TwKi1pEQ6lq5gZaDBnmbfM,EV2O0B3roGHlpCiaNRh14 = qpHn0MYIk5GcP4i.textsize(vSEwNaHGgVfL8cyK7k32Xzr9dbRuY,font=teRQO2gBnbrPD9qL)
			nW1KUF9f0AzEvehYpjyPw5k = ctz4fZRY0qCyaVgso5NlkE+2*(rrexwPHcjtE+qURKMAfXlhGNI45mWCeJxbic6D3)+(qURKMAfXlhGNI45mWCeJxbic6D3-SWP0TwKi1pEQ6lq5gZaDBnmbfM)/2
			qpHn0MYIk5GcP4i.text((nW1KUF9f0AzEvehYpjyPw5k,ECHgvbW2YAVN0Boc6mIJ),vSEwNaHGgVfL8cyK7k32Xzr9dbRuY,font=teRQO2gBnbrPD9qL,fill='yellow')
	if pnmsJqCWIHVk2Y6xPvl9Q0Ez8r:
		MM9RATrLyhF3qPYv5VC,wHQplo3kOZ8DCzGS70jcvV2Bfm4EqJ = [],[]
		EQMfcLYqh3jivaTgbImyClDJeHz = eShl6QJ4IGwE1CgjHtiLMmNqRfVrBX(EQMfcLYqh3jivaTgbImyClDJeHz)
		JJ4rWTNuz86BMLHF5QRP = EQMfcLYqh3jivaTgbImyClDJeHz.split('_sss__newline_')
		for dd9T8Ps6VeuC4BkMIWX1tKqy in JJ4rWTNuz86BMLHF5QRP:
			GS58w6OtEl9kdLKMHCjy = Iux20iOKwF4bs39zJHnMBlAPem6
			if   '_sss__lineleft_' in dd9T8Ps6VeuC4BkMIWX1tKqy: GS58w6OtEl9kdLKMHCjy = 'left'
			elif '_sss__lineright_' in dd9T8Ps6VeuC4BkMIWX1tKqy: GS58w6OtEl9kdLKMHCjy = 'right'
			elif '_sss__linecenter_' in dd9T8Ps6VeuC4BkMIWX1tKqy: GS58w6OtEl9kdLKMHCjy = 'center'
			bo5WxQqaENK6MtvTZ8hAOkB0i = dd9T8Ps6VeuC4BkMIWX1tKqy
			bQoxtR3CB5vl = YYBlm36zd0Jst18LXwo4.findall('_sss__.*?_',dd9T8Ps6VeuC4BkMIWX1tKqy,YYBlm36zd0Jst18LXwo4.DOTALL)
			for aa3fdJFwWh5PkRO4Ame68GZj in bQoxtR3CB5vl: bo5WxQqaENK6MtvTZ8hAOkB0i = bo5WxQqaENK6MtvTZ8hAOkB0i.replace(aa3fdJFwWh5PkRO4Ame68GZj,b8Qe150xVaJsnDSv)
			if bo5WxQqaENK6MtvTZ8hAOkB0i==b8Qe150xVaJsnDSv: C4Uu8gpaSykID21jzxKQ,sqnTD6F9c3RGCVpN2fBY4Ml = 0,hGTbJ0I8EMFj3
			else: C4Uu8gpaSykID21jzxKQ,sqnTD6F9c3RGCVpN2fBY4Ml = qpHn0MYIk5GcP4i.textsize(bo5WxQqaENK6MtvTZ8hAOkB0i,font=OOdqUmir7h)
			if   GS58w6OtEl9kdLKMHCjy=='left': fhrpkUS2B7PEDFI0a5m6OsZuTVnY = d2dh1YNjnlF5SMoAkvCrbH4BV+coHBavAgSRQrbC
			elif GS58w6OtEl9kdLKMHCjy=='right': fhrpkUS2B7PEDFI0a5m6OsZuTVnY = d2dh1YNjnlF5SMoAkvCrbH4BV+coHBavAgSRQrbC+M1CRIUtvfik3jLasHSDFu6XOcb2-C4Uu8gpaSykID21jzxKQ
			elif GS58w6OtEl9kdLKMHCjy=='center': fhrpkUS2B7PEDFI0a5m6OsZuTVnY = d2dh1YNjnlF5SMoAkvCrbH4BV+coHBavAgSRQrbC+(M1CRIUtvfik3jLasHSDFu6XOcb2-C4Uu8gpaSykID21jzxKQ)/2
			if fhrpkUS2B7PEDFI0a5m6OsZuTVnY<coHBavAgSRQrbC: fhrpkUS2B7PEDFI0a5m6OsZuTVnY = d2dh1YNjnlF5SMoAkvCrbH4BV+coHBavAgSRQrbC
			MM9RATrLyhF3qPYv5VC.append(fhrpkUS2B7PEDFI0a5m6OsZuTVnY)
			wHQplo3kOZ8DCzGS70jcvV2Bfm4EqJ.append(C4Uu8gpaSykID21jzxKQ)
		fhrpkUS2B7PEDFI0a5m6OsZuTVnY = MM9RATrLyhF3qPYv5VC[0]
		yQflDaGqLj = EQMfcLYqh3jivaTgbImyClDJeHz.split('_sss_')
		tDp8lxbA0cZCW6n = (255,255,255,255)
		FotSu7P8hOGv5rcqTmdp2EXxAfB9LW = tDp8lxbA0cZCW6n
		TPvuoFZGjf21a45k7IHAyL6nbVz,Feqm6TGZ2g5 = 0,0
		in83LVh6x2rgt = False
		ENLIASWqf6Z3g7DbRxFyUCd = 0
		aG5c1btvYgUqJpNDm2CS84P = FaMLlCx8Vtz4+HOcs3X6RqdpCa/2
		if iR9pcbek7MX8HI<(IIoOnXCkYmlUsSr7+HOcs3X6RqdpCa):
			OQGnyCAZ2RN6PLJiqSbDz = (IIoOnXCkYmlUsSr7+HOcs3X6RqdpCa-iR9pcbek7MX8HI)/2
			aG5c1btvYgUqJpNDm2CS84P = FaMLlCx8Vtz4+HOcs3X6RqdpCa+OQGnyCAZ2RN6PLJiqSbDz-V5JiKByc0AWFpahGr/2
		for XcB7EqbZMOW9RuYnD62V4F3jrhvp in yQflDaGqLj:
			if not XcB7EqbZMOW9RuYnD62V4F3jrhvp or (XcB7EqbZMOW9RuYnD62V4F3jrhvp and ord(XcB7EqbZMOW9RuYnD62V4F3jrhvp[0])==65279): continue
			qJtoP4NRIp = XcB7EqbZMOW9RuYnD62V4F3jrhvp.split('_newline_',1)
			WY7EocrGV9gHfCDKvj = XcB7EqbZMOW9RuYnD62V4F3jrhvp.split('_newcolor',1)
			gxSJTFVKUXnvH9Czc1bursG = XcB7EqbZMOW9RuYnD62V4F3jrhvp.split('_endcolor_',1)
			ppv8IueyfojMY9cT07sLg52UEJGlHq = XcB7EqbZMOW9RuYnD62V4F3jrhvp.split('_linertl_',1)
			njcLRIGDOdxZMh80iQ3r5WaNlg1m = XcB7EqbZMOW9RuYnD62V4F3jrhvp.split('_lineleft_',1)
			CGXeLWgl1rBhQn27sU4uZSIwRyi = XcB7EqbZMOW9RuYnD62V4F3jrhvp.split('_lineright_',1)
			NZRAEvehUz43tbkKa5MGSL9rW = XcB7EqbZMOW9RuYnD62V4F3jrhvp.split('_linecenter_',1)
			if len(qJtoP4NRIp)>1:
				ENLIASWqf6Z3g7DbRxFyUCd += 1
				XcB7EqbZMOW9RuYnD62V4F3jrhvp = qJtoP4NRIp[1]
				TPvuoFZGjf21a45k7IHAyL6nbVz = 0
				fhrpkUS2B7PEDFI0a5m6OsZuTVnY = MM9RATrLyhF3qPYv5VC[ENLIASWqf6Z3g7DbRxFyUCd]
				Feqm6TGZ2g5 += hGTbJ0I8EMFj3
				in83LVh6x2rgt = False
			elif len(WY7EocrGV9gHfCDKvj)>1:
				XcB7EqbZMOW9RuYnD62V4F3jrhvp = WY7EocrGV9gHfCDKvj[1]
				FotSu7P8hOGv5rcqTmdp2EXxAfB9LW = XcB7EqbZMOW9RuYnD62V4F3jrhvp[0:8]
				FotSu7P8hOGv5rcqTmdp2EXxAfB9LW = '#'+FotSu7P8hOGv5rcqTmdp2EXxAfB9LW[2:]
				XcB7EqbZMOW9RuYnD62V4F3jrhvp = XcB7EqbZMOW9RuYnD62V4F3jrhvp[9:]
			elif len(gxSJTFVKUXnvH9Czc1bursG)>1:
				XcB7EqbZMOW9RuYnD62V4F3jrhvp = gxSJTFVKUXnvH9Czc1bursG[1]
				FotSu7P8hOGv5rcqTmdp2EXxAfB9LW = tDp8lxbA0cZCW6n
			elif len(ppv8IueyfojMY9cT07sLg52UEJGlHq)>1:
				XcB7EqbZMOW9RuYnD62V4F3jrhvp = ppv8IueyfojMY9cT07sLg52UEJGlHq[1]
				in83LVh6x2rgt = True
				TPvuoFZGjf21a45k7IHAyL6nbVz = wHQplo3kOZ8DCzGS70jcvV2Bfm4EqJ[ENLIASWqf6Z3g7DbRxFyUCd]
			elif len(njcLRIGDOdxZMh80iQ3r5WaNlg1m)>1: XcB7EqbZMOW9RuYnD62V4F3jrhvp = njcLRIGDOdxZMh80iQ3r5WaNlg1m[1]
			elif len(CGXeLWgl1rBhQn27sU4uZSIwRyi)>1: XcB7EqbZMOW9RuYnD62V4F3jrhvp = CGXeLWgl1rBhQn27sU4uZSIwRyi[1]
			elif len(NZRAEvehUz43tbkKa5MGSL9rW)>1: XcB7EqbZMOW9RuYnD62V4F3jrhvp = NZRAEvehUz43tbkKa5MGSL9rW[1]
			if XcB7EqbZMOW9RuYnD62V4F3jrhvp:
				Wl6hDg5BZd8VvMeC0TJwk2KNFfHER = aG5c1btvYgUqJpNDm2CS84P+Feqm6TGZ2g5
				XcB7EqbZMOW9RuYnD62V4F3jrhvp = cEQtfYbzRv8Z.get_display(XcB7EqbZMOW9RuYnD62V4F3jrhvp)
				C4Uu8gpaSykID21jzxKQ,sqnTD6F9c3RGCVpN2fBY4Ml = qpHn0MYIk5GcP4i.textsize(XcB7EqbZMOW9RuYnD62V4F3jrhvp,font=OOdqUmir7h)
				if in83LVh6x2rgt: TPvuoFZGjf21a45k7IHAyL6nbVz -= C4Uu8gpaSykID21jzxKQ
				U17hDnYOs95jlX4EeCBRxcq = fhrpkUS2B7PEDFI0a5m6OsZuTVnY+TPvuoFZGjf21a45k7IHAyL6nbVz
				qpHn0MYIk5GcP4i.text((U17hDnYOs95jlX4EeCBRxcq,Wl6hDg5BZd8VvMeC0TJwk2KNFfHER),XcB7EqbZMOW9RuYnD62V4F3jrhvp,font=OOdqUmir7h,fill=FotSu7P8hOGv5rcqTmdp2EXxAfB9LW)
				if t9ZVkIrP5iSG=='menu_item': qpHn0MYIk5GcP4i.text((U17hDnYOs95jlX4EeCBRxcq+1,Wl6hDg5BZd8VvMeC0TJwk2KNFfHER+1),XcB7EqbZMOW9RuYnD62V4F3jrhvp,font=OOdqUmir7h,fill=FotSu7P8hOGv5rcqTmdp2EXxAfB9LW)
				if not in83LVh6x2rgt: TPvuoFZGjf21a45k7IHAyL6nbVz += C4Uu8gpaSykID21jzxKQ
				if Wl6hDg5BZd8VvMeC0TJwk2KNFfHER>IIoOnXCkYmlUsSr7+hGTbJ0I8EMFj3: break
	if t9ZVkIrP5iSG=='menu_item':
		hDTfyqAXtSP8w7dNKWxjzEYCm0nJ = nYTgm0R3wqIGNAoiK8pjkE9az.copy()
		wLQCTr5lqbsVYeAHdzfhZ1F.sleep(0.05)
		hDTfyqAXtSP8w7dNKWxjzEYCm0nJ.paste(qAHc0iwyRJdYmS,(0,0),mask=gTB1QcZeJLqDM3h29a7izy8kGvWAjs)
	else: hDTfyqAXtSP8w7dNKWxjzEYCm0nJ = gTB1QcZeJLqDM3h29a7izy8kGvWAjs
	if hDTluNxe7tCwrpqXHzdEcYRfbs: K0acEXrehU6IGPw3Lm = K0acEXrehU6IGPw3Lm.decode(OVauxZzLI10vcXT74K)
	try: hDTfyqAXtSP8w7dNKWxjzEYCm0nJ.save(K0acEXrehU6IGPw3Lm)
	except UnicodeError:
		if hDTluNxe7tCwrpqXHzdEcYRfbs:
			K0acEXrehU6IGPw3Lm = K0acEXrehU6IGPw3Lm.encode(OVauxZzLI10vcXT74K)
			hDTfyqAXtSP8w7dNKWxjzEYCm0nJ.save(K0acEXrehU6IGPw3Lm)
	return NNyGtlqidQrwaS5
def Rpt3i0BYnG7MjT5PcJ4uDaZS8lsX(TTpWOv0XsEYbdcZC2PlM,OOdqUmir7h,jjZAPQDxHNFok,iVEAsIWou5RCtNUbrm4hTHDQnYL6wx,M1CRIUtvfik3jLasHSDFu6XOcb2,lyTzfP70moYU429QAjekhbVvLJDRS):
	bOoizxjAg3JZs4CXHnYLWI,WUxEyr2KCO,WBNLAx4GnCqo0Dl = b8Qe150xVaJsnDSv,0,15000
	jjZAPQDxHNFok = jjZAPQDxHNFok.replace('[COLOR ','[COLOR:::')
	nYjv0JGgcZSazW = M1CRIUtvfik3jLasHSDFu6XOcb2-iVEAsIWou5RCtNUbrm4hTHDQnYL6wx*2
	for VKohOmrsI6J1eUySTGEA48xZR5gQdu in jjZAPQDxHNFok.splitlines():
		WUxEyr2KCO += lyTzfP70moYU429QAjekhbVvLJDRS
		hYsWolOpAUM1eyjFdQJfLbrqu,MrxSVRUgzAXe7cOhBmEZWwdQ90Ful = 0,b8Qe150xVaJsnDSv
		for vCoxVzrcHuQnT315StJ in VKohOmrsI6J1eUySTGEA48xZR5gQdu.split(pldxivXC5wbTB2O8q):
			eR6bgvyzuXiA2pFQNDWaBE = f7Hl8kTOqsQ0VrD2XKBLpeFAoMwg(pldxivXC5wbTB2O8q+vCoxVzrcHuQnT315StJ)
			roCa5HNcWxfm1LsRpY7zXqwhU,bbuydmkWoRGNCLtJZwpO7U = TTpWOv0XsEYbdcZC2PlM.textsize(eR6bgvyzuXiA2pFQNDWaBE,font=OOdqUmir7h)
			if hYsWolOpAUM1eyjFdQJfLbrqu+roCa5HNcWxfm1LsRpY7zXqwhU<nYjv0JGgcZSazW:
				if not MrxSVRUgzAXe7cOhBmEZWwdQ90Ful: MrxSVRUgzAXe7cOhBmEZWwdQ90Ful += vCoxVzrcHuQnT315StJ
				else: MrxSVRUgzAXe7cOhBmEZWwdQ90Ful += pldxivXC5wbTB2O8q+vCoxVzrcHuQnT315StJ
				hYsWolOpAUM1eyjFdQJfLbrqu += roCa5HNcWxfm1LsRpY7zXqwhU
			else:
				if roCa5HNcWxfm1LsRpY7zXqwhU<nYjv0JGgcZSazW:
					MrxSVRUgzAXe7cOhBmEZWwdQ90Ful += '\n '+vCoxVzrcHuQnT315StJ
					WUxEyr2KCO += lyTzfP70moYU429QAjekhbVvLJDRS
					hYsWolOpAUM1eyjFdQJfLbrqu = roCa5HNcWxfm1LsRpY7zXqwhU
				else:
					while roCa5HNcWxfm1LsRpY7zXqwhU>nYjv0JGgcZSazW:
						for H9JbVKORYEGt3jo2g in range(1,len(pldxivXC5wbTB2O8q+vCoxVzrcHuQnT315StJ),1):
							wOhyVAi59HJsQz2L6fmeGFMpcPW = pldxivXC5wbTB2O8q+vCoxVzrcHuQnT315StJ[:H9JbVKORYEGt3jo2g]
							teivcQpEdjlPDzk0qfa9wFu6YN = vCoxVzrcHuQnT315StJ[H9JbVKORYEGt3jo2g:]
							dQiL3MV7eTfnjr8vOgm0SC9yWp = f7Hl8kTOqsQ0VrD2XKBLpeFAoMwg(wOhyVAi59HJsQz2L6fmeGFMpcPW)
							l8VwW6QNFsJc5T3UYo,zJ7P8MungTOEr90xUk5mqSXAjiv = TTpWOv0XsEYbdcZC2PlM.textsize(dQiL3MV7eTfnjr8vOgm0SC9yWp,font=OOdqUmir7h)
							if hYsWolOpAUM1eyjFdQJfLbrqu+l8VwW6QNFsJc5T3UYo>nYjv0JGgcZSazW:
								LcfkFPj9wU6zV8rtd = roCa5HNcWxfm1LsRpY7zXqwhU-l8VwW6QNFsJc5T3UYo
								MrxSVRUgzAXe7cOhBmEZWwdQ90Ful += wOhyVAi59HJsQz2L6fmeGFMpcPW+eeN6dTEnkJxI
								WUxEyr2KCO += lyTzfP70moYU429QAjekhbVvLJDRS
								roCa5HNcWxfm1LsRpY7zXqwhU = LcfkFPj9wU6zV8rtd
								if LcfkFPj9wU6zV8rtd>nYjv0JGgcZSazW:
									hYsWolOpAUM1eyjFdQJfLbrqu = 0
									vCoxVzrcHuQnT315StJ = teivcQpEdjlPDzk0qfa9wFu6YN
								else:
									hYsWolOpAUM1eyjFdQJfLbrqu = LcfkFPj9wU6zV8rtd
									MrxSVRUgzAXe7cOhBmEZWwdQ90Ful += teivcQpEdjlPDzk0qfa9wFu6YN
								break
				if WUxEyr2KCO>WBNLAx4GnCqo0Dl: break
		bOoizxjAg3JZs4CXHnYLWI += eeN6dTEnkJxI+MrxSVRUgzAXe7cOhBmEZWwdQ90Ful
		if WUxEyr2KCO>WBNLAx4GnCqo0Dl: break
	bOoizxjAg3JZs4CXHnYLWI = bOoizxjAg3JZs4CXHnYLWI[1:]
	bOoizxjAg3JZs4CXHnYLWI = bOoizxjAg3JZs4CXHnYLWI.replace('[COLOR:::','[COLOR ')
	return bOoizxjAg3JZs4CXHnYLWI
def f7Hl8kTOqsQ0VrD2XKBLpeFAoMwg(vCoxVzrcHuQnT315StJ):
	if '[' in vCoxVzrcHuQnT315StJ and ']' in vCoxVzrcHuQnT315StJ:
		bQoxtR3CB5vl = [hAIp8kmC36T5WFPMSXOwnNbtD,'[/RTL]','[/LEFT]','[/RIGHT]','[/CENTER]','[RTL]','[LEFT]','[RIGHT]','[CENTER]']
		bbf01ERJnCsepBqKLimVWHUry4FAt = YYBlm36zd0Jst18LXwo4.findall('\[COLOR .*?\]',vCoxVzrcHuQnT315StJ,YYBlm36zd0Jst18LXwo4.DOTALL)
		rBxFwR0V2vkyepo51ch4tIN9ZQ = YYBlm36zd0Jst18LXwo4.findall('\[COLOR:::.*?\]',vCoxVzrcHuQnT315StJ,YYBlm36zd0Jst18LXwo4.DOTALL)
		Vy1fExt5qCr396 = bQoxtR3CB5vl+bbf01ERJnCsepBqKLimVWHUry4FAt+rBxFwR0V2vkyepo51ch4tIN9ZQ
		for aa3fdJFwWh5PkRO4Ame68GZj in Vy1fExt5qCr396: vCoxVzrcHuQnT315StJ = vCoxVzrcHuQnT315StJ.replace(aa3fdJFwWh5PkRO4Ame68GZj,b8Qe150xVaJsnDSv)
	return vCoxVzrcHuQnT315StJ
def eShl6QJ4IGwE1CgjHtiLMmNqRfVrBX(pnmsJqCWIHVk2Y6xPvl9Q0Ez8r):
	pnmsJqCWIHVk2Y6xPvl9Q0Ez8r = pnmsJqCWIHVk2Y6xPvl9Q0Ez8r.replace(eeN6dTEnkJxI,'_sss__newline_')
	pnmsJqCWIHVk2Y6xPvl9Q0Ez8r = pnmsJqCWIHVk2Y6xPvl9Q0Ez8r.replace('[RTL]','_sss__linertl_')
	pnmsJqCWIHVk2Y6xPvl9Q0Ez8r = pnmsJqCWIHVk2Y6xPvl9Q0Ez8r.replace('[LEFT]','_sss__lineleft_')
	pnmsJqCWIHVk2Y6xPvl9Q0Ez8r = pnmsJqCWIHVk2Y6xPvl9Q0Ez8r.replace('[RIGHT]','_sss__lineright_')
	pnmsJqCWIHVk2Y6xPvl9Q0Ez8r = pnmsJqCWIHVk2Y6xPvl9Q0Ez8r.replace('[CENTER]','_sss__linecenter_')
	pnmsJqCWIHVk2Y6xPvl9Q0Ez8r = pnmsJqCWIHVk2Y6xPvl9Q0Ez8r.replace(hAIp8kmC36T5WFPMSXOwnNbtD,'_sss__endcolor_')
	fJLd2UG6baTvxKM58ulwCNHO3Xp = YYBlm36zd0Jst18LXwo4.findall('\[COLOR (.*?)\]',pnmsJqCWIHVk2Y6xPvl9Q0Ez8r,YYBlm36zd0Jst18LXwo4.DOTALL)
	for bXNVEnRvcH in fJLd2UG6baTvxKM58ulwCNHO3Xp: pnmsJqCWIHVk2Y6xPvl9Q0Ez8r = pnmsJqCWIHVk2Y6xPvl9Q0Ez8r.replace('[COLOR '+bXNVEnRvcH+']','_sss__newcolor'+bXNVEnRvcH+'_')
	return pnmsJqCWIHVk2Y6xPvl9Q0Ez8r
def RkNASsitM7eYvhqL62FVlfDuZW4x(uUGfD9te3WCjTOzxsVRiqB2gak7SYH,c17XeRIH2gVh3px8sw=b8Qe150xVaJsnDSv):
	if not c17XeRIH2gVh3px8sw: c17XeRIH2gVh3px8sw = uuxVm0bTwdnCUAL4s6NKHEBF3M.getInfoLabel('ListItem.Label')
	c17XeRIH2gVh3px8sw = c17XeRIH2gVh3px8sw.replace(eiopkn4y9uWDQ5,pldxivXC5wbTB2O8q).replace(R1BKXhzpGH6CoO9jLsPwQWu,pldxivXC5wbTB2O8q).replace(k5bCDErUSmv,pldxivXC5wbTB2O8q).strip(pldxivXC5wbTB2O8q)
	if uUGfD9te3WCjTOzxsVRiqB2gak7SYH: c17XeRIH2gVh3px8sw = c17XeRIH2gVh3px8sw.replace('[COLOR ',b8Qe150xVaJsnDSv).replace(']',b8Qe150xVaJsnDSv)
	else: c17XeRIH2gVh3px8sw = c17XeRIH2gVh3px8sw.replace(OkuB9nwhD8U1,b8Qe150xVaJsnDSv).replace(rC3Tlno96KjLDIvBaSWUbR8,b8Qe150xVaJsnDSv).replace(Vx5N0eIvPChf6SyXiMz,b8Qe150xVaJsnDSv).replace(n1a97RTs0wA8EzjVYcXtSP,b8Qe150xVaJsnDSv)
	c17XeRIH2gVh3px8sw = c17XeRIH2gVh3px8sw.replace(eeN6dTEnkJxI,b8Qe150xVaJsnDSv).replace(d6ekSEojpFUANKJ7r9WTlI3niLBOu,b8Qe150xVaJsnDSv).replace(hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv)
	c17XeRIH2gVh3px8sw = c17XeRIH2gVh3px8sw.replace(VfHYrPvolqbxLOd,b8Qe150xVaJsnDSv).replace(W0LQbFfMVG46dKrPzJCmvD,b8Qe150xVaJsnDSv)
	ZZno0bO9kYscxD4mtFCRJME5uhqLl = YYBlm36zd0Jst18LXwo4.findall('\d\d:\d\d ',c17XeRIH2gVh3px8sw,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZZno0bO9kYscxD4mtFCRJME5uhqLl: c17XeRIH2gVh3px8sw = c17XeRIH2gVh3px8sw.split(ZZno0bO9kYscxD4mtFCRJME5uhqLl[0],1)[1]
	if not c17XeRIH2gVh3px8sw: c17XeRIH2gVh3px8sw = 'Main Menu'
	return c17XeRIH2gVh3px8sw
def LL1ZqB5WQHbd38JXhNRF(zzIgsTAGUu0wQ8eEKq):
	YuPNC1vQJ4Ht = b8Qe150xVaJsnDSv.join(H9JbVKORYEGt3jo2g for H9JbVKORYEGt3jo2g in zzIgsTAGUu0wQ8eEKq if H9JbVKORYEGt3jo2g not in '\/":*?<>|'+Iceb2XPnm6a3Tqx)
	return YuPNC1vQJ4Ht
def KvkLRyF6ahWxpPGX4cn(EAlZ2zKn6uagcqtY3yBoMxDmSbOwk):
	jGiJorZRvUbXuOTL = YYBlm36zd0Jst18LXwo4.findall("adilbo_HTML_encoder(.*?)/g.....(.*?)\)",EAlZ2zKn6uagcqtY3yBoMxDmSbOwk,YYBlm36zd0Jst18LXwo4.S)
	if jGiJorZRvUbXuOTL:
		On4DqFkCmshjSBI,tIyobsDFROkCGVJzE2WUP58T = jGiJorZRvUbXuOTL[0]
		On4DqFkCmshjSBI = YYBlm36zd0Jst18LXwo4.findall("=[\r\n\s\t]+'(.*?)';", On4DqFkCmshjSBI, YYBlm36zd0Jst18LXwo4.S)[0]
		if On4DqFkCmshjSBI and tIyobsDFROkCGVJzE2WUP58T:
			c6xzNlJ4ujemVZW0Ha5nyXgTUoDk = On4DqFkCmshjSBI.replace("'",b8Qe150xVaJsnDSv).replace("+",b8Qe150xVaJsnDSv).replace("\n",b8Qe150xVaJsnDSv).replace("\r",b8Qe150xVaJsnDSv)
			ZdMfQ1VznG3JemBH78 = c6xzNlJ4ujemVZW0Ha5nyXgTUoDk.split('.')
			EAlZ2zKn6uagcqtY3yBoMxDmSbOwk = b8Qe150xVaJsnDSv
			for nqHy8sokcN2ztQCbUxdhTXG in ZdMfQ1VznG3JemBH78:
				EJKQyLlRt2cvwZ0IgsjUTWF = lnFeUkiZtQ7E1.b64decode(nqHy8sokcN2ztQCbUxdhTXG+'==').decode(OVauxZzLI10vcXT74K)
				uubItCyUG9Tx3 = YYBlm36zd0Jst18LXwo4.findall('\d+', EJKQyLlRt2cvwZ0IgsjUTWF, YYBlm36zd0Jst18LXwo4.S)
				if uubItCyUG9Tx3:
					rufX9OTkdFpx1W = int(uubItCyUG9Tx3[0])
					rufX9OTkdFpx1W += int(tIyobsDFROkCGVJzE2WUP58T)
					EAlZ2zKn6uagcqtY3yBoMxDmSbOwk = EAlZ2zKn6uagcqtY3yBoMxDmSbOwk + chr(rufX9OTkdFpx1W)
			if i1thmHk7AZquD4cM0fnp62: EAlZ2zKn6uagcqtY3yBoMxDmSbOwk = EAlZ2zKn6uagcqtY3yBoMxDmSbOwk.encode('iso-8859-1').decode(OVauxZzLI10vcXT74K)
	return EAlZ2zKn6uagcqtY3yBoMxDmSbOwk
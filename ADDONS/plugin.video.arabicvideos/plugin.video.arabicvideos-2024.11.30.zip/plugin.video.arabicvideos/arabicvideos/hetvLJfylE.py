# -*- coding: utf-8 -*-
from hIVCFnfxSO import *
QQ8pvXNcBfVkP5rRJ7o = 'MOVS4U'
WbzmKSZiuOYrBN7oysJ2dUv = '_M4U_'
wQjs1XZ3AO24g8y9bEeoKMiGIu7 = nTHXJIiah2qK[QQ8pvXNcBfVkP5rRJ7o][0]
v1vJEhoNQBVPkjG = ['انواع افلام','جودات افلام']
def x8IFqMZeJj7suCR4AaGoNXfEHm(mode,url,text):
	if   mode==380: XXxlOLJ9KRjPH382WVCvr6n71 = Y72YmLgw4vqlHxTCkbeKSicasD()
	elif mode==381: XXxlOLJ9KRjPH382WVCvr6n71 = Je4TwC30iOG5DLKWAtbYvhs(url,text)
	elif mode==382: XXxlOLJ9KRjPH382WVCvr6n71 = Hkij627uCDJKyIM(url)
	elif mode==383: XXxlOLJ9KRjPH382WVCvr6n71 = bIpskeGhBlqH(url)
	elif mode==389: XXxlOLJ9KRjPH382WVCvr6n71 = kstJfK6jHQWrXDSMRIGB7(text)
	else: XXxlOLJ9KRjPH382WVCvr6n71 = False
	return XXxlOLJ9KRjPH382WVCvr6n71
def Y72YmLgw4vqlHxTCkbeKSicasD():
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'بحث في الموقع',b8Qe150xVaJsnDSv,389,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'_REMEMBERRESULTS_')
	MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+' ===== ===== ===== '+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999)
	MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+'المميزة',wQjs1XZ3AO24g8y9bEeoKMiGIu7,381,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'featured')
	MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+'الجانبية',wQjs1XZ3AO24g8y9bEeoKMiGIu7,381,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'sider')
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(Q49IsrlSuYRAVbGKhwdckLDOetF2PZ,'GET',wQjs1XZ3AO24g8y9bEeoKMiGIu7,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'MOVS4U-MENU-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	items = YYBlm36zd0Jst18LXwo4.findall('<header>.*?<h2>(.*?)<',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	for JZMvR4mp2rX7Kf6n in range(len(items)):
		title = items[JZMvR4mp2rX7Kf6n]
		MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+title,wQjs1XZ3AO24g8y9bEeoKMiGIu7,381,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'latest'+str(JZMvR4mp2rX7Kf6n))
	OTKx7aVb2hdS16Wrweky4FXfIN0g9 = b8Qe150xVaJsnDSv
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('class="menu"(.*?)id="contenedor"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ: OTKx7aVb2hdS16Wrweky4FXfIN0g9 += ZV5rRvabhxJ[0]
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('class="sidebar(.*?)aside',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ: OTKx7aVb2hdS16Wrweky4FXfIN0g9 += ZV5rRvabhxJ[0]
	items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)">(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+' ===== ===== ===== '+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999)
	CGQ914dXgqhLswByzFSKEWkPmv8j = True
	for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
		title = pTP49ckGDYrofa2KxenumbH0(title)
		if title=='الأعلى مشاهدة':
			if CGQ914dXgqhLswByzFSKEWkPmv8j:
				title = 'الافلام '+title
				CGQ914dXgqhLswByzFSKEWkPmv8j = False
			else: title = 'المسلسلات '+title
		if title not in v1vJEhoNQBVPkjG:
			MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,381)
	return jLtdbeYiQHnf4SpU2MTly
def Je4TwC30iOG5DLKWAtbYvhs(url,type):
	OTKx7aVb2hdS16Wrweky4FXfIN0g9,items = [],[]
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'MOVS4U-TITLES-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	if type=='search':
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('class="search-page"(.*?)class="sidebar',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if ZV5rRvabhxJ:
			OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
			items = YYBlm36zd0Jst18LXwo4.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	elif type=='sider':
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('class="widget(.*?)class="widget',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		YpNBOa78Kd = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)".*?img src="(.*?)".*?<h3>(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j,mLRifACEnrvgjyqz,uuSKUinvP4EGLxWZYmTsF = zip(*YpNBOa78Kd)
		items = zip(mLRifACEnrvgjyqz,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j,uuSKUinvP4EGLxWZYmTsF)
	elif type=='featured':
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('id="slider-movies-tvshows"(.*?)<header>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		items = YYBlm36zd0Jst18LXwo4.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	elif 'latest' in type:
		JZMvR4mp2rX7Kf6n = int(type[-1:])
		jLtdbeYiQHnf4SpU2MTly = jLtdbeYiQHnf4SpU2MTly.replace('<header>','<end><start>')
		jLtdbeYiQHnf4SpU2MTly = jLtdbeYiQHnf4SpU2MTly.replace('<div class="sidebar','<end><div class="sidebar')
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('<start>(.*?)<end>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[JZMvR4mp2rX7Kf6n]
		if JZMvR4mp2rX7Kf6n==2: items = YYBlm36zd0Jst18LXwo4.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	else:
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('class="content"(.*?)class="(pagination|sidebar)',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if ZV5rRvabhxJ:
			OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0][0]
			if '/collection/' in url:
				items = YYBlm36zd0Jst18LXwo4.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
			elif '/quality/' in url:
				items = YYBlm36zd0Jst18LXwo4.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	if not items and OTKx7aVb2hdS16Wrweky4FXfIN0g9:
		items = YYBlm36zd0Jst18LXwo4.findall('img src="(.*?)".*?href=.*?href="(.*?)">(.*?)</div>',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	d3VSIefbHnvqiut = []
	for lvtGpMZHb9,pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
		if 'serie' in title:
			title = YYBlm36zd0Jst18LXwo4.findall('^(.*?)<.*?serie">(.*?)<',title,YYBlm36zd0Jst18LXwo4.DOTALL)
			title = title[0][1]
			if title in d3VSIefbHnvqiut: continue
			d3VSIefbHnvqiut.append(title)
			title = '_MOD_'+title
		HoXz65T8ph1CMeZgF = YYBlm36zd0Jst18LXwo4.findall('^(.*?)<',title,YYBlm36zd0Jst18LXwo4.DOTALL)
		if HoXz65T8ph1CMeZgF: title = HoXz65T8ph1CMeZgF[0]
		title = pTP49ckGDYrofa2KxenumbH0(title)
		if '/tvshows/' in pcA1dzy7LXwGfMPg9mTkuh5tine3: MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,383,lvtGpMZHb9)
		elif '/episodes/' in pcA1dzy7LXwGfMPg9mTkuh5tine3: MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,383,lvtGpMZHb9)
		elif '/seasons/' in pcA1dzy7LXwGfMPg9mTkuh5tine3: MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,383,lvtGpMZHb9)
		elif '/collection/' in pcA1dzy7LXwGfMPg9mTkuh5tine3: MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,381,lvtGpMZHb9)
		else: MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,382,lvtGpMZHb9)
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('class="pagination".*?Page (.*?) of (.*?)<(.*?)</div>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ:
		VVcHZmT08X6AhlnaGkwzbEPCOuMKqL = ZV5rRvabhxJ[0][0]
		zfHjVMcnbvdDL = ZV5rRvabhxJ[0][1]
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0][2]
		items = YYBlm36zd0Jst18LXwo4.findall("href='(.*?)'.*?>(.*?)<",OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
			if title==b8Qe150xVaJsnDSv or title==zfHjVMcnbvdDL: continue
			MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'صفحة '+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,381,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,type)
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3.replace('/page/'+title+'/','/page/'+zfHjVMcnbvdDL+'/')
		MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'اخر صفحة '+zfHjVMcnbvdDL,pcA1dzy7LXwGfMPg9mTkuh5tine3,381,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,type)
	return
def bIpskeGhBlqH(url):
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'MOVS4U-EPISODES-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	EQUkgc3PLy5mhBiZINJ0HO1A6 = YYBlm36zd0Jst18LXwo4.findall('class="C rated".*?>(.*?)<',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if EQUkgc3PLy5mhBiZINJ0HO1A6 and vvIMS2DeraLfJ(QQ8pvXNcBfVkP5rRJ7o,url,EQUkgc3PLy5mhBiZINJ0HO1A6,False):
		MQtuaShrKTbdZFJ5nsR7D('link',WbzmKSZiuOYrBN7oysJ2dUv+'المسلسل للكبار والمبرمج منعه',b8Qe150xVaJsnDSv,9999)
		return
	if '/episodes/' in url or '/tvshows/' in url:
		MUJCtfYVBLODrFbaZn = YYBlm36zd0Jst18LXwo4.findall('''class='item'><a href="(.*?)"''',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if MUJCtfYVBLODrFbaZn:
			MUJCtfYVBLODrFbaZn = MUJCtfYVBLODrFbaZn[1]
			bIpskeGhBlqH(MUJCtfYVBLODrFbaZn)
			return
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('''class='episodios'(.*?)id="cast"''',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		items = YYBlm36zd0Jst18LXwo4.findall('''src='(.*?)'.*?class='numerando'>(.*?)<.*?href='(.*?)'>(.*?)<''',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for lvtGpMZHb9,HHr42WSgBjAeU7TkQcVaL6yEJz8PF,pcA1dzy7LXwGfMPg9mTkuh5tine3,name in items:
			title = HHr42WSgBjAeU7TkQcVaL6yEJz8PF+' : '+name+' الحلقة'
			MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,382)
	return
def Hkij627uCDJKyIM(url):
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'MOVS4U-PLAY-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	EQUkgc3PLy5mhBiZINJ0HO1A6 = YYBlm36zd0Jst18LXwo4.findall('class="C rated".*?>(.*?)<',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if EQUkgc3PLy5mhBiZINJ0HO1A6 and vvIMS2DeraLfJ(QQ8pvXNcBfVkP5rRJ7o,url,EQUkgc3PLy5mhBiZINJ0HO1A6): return
	KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = []
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('''id='player-option-1'(.*?)class=("sheader"|'pag_episodes')''',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0][0]
		items = YYBlm36zd0Jst18LXwo4.findall("data-url='(.*?)'.*?class='server'>(.*?)<",OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3+'?named='+title+'__watch'
			KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('class="remodal"(.*?)class="remodal-close"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		items = YYBlm36zd0Jst18LXwo4.findall('class="___dl_gdrive.*?href="(.*?)".*?">(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = wQjs1XZ3AO24g8y9bEeoKMiGIu7+pcA1dzy7LXwGfMPg9mTkuh5tine3
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3+'?named='+title+'__download'
			KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
	import QNeGEq8sWn
	QNeGEq8sWn.nqu2GCT9gHAbpIPSFZz5(KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j,QQ8pvXNcBfVkP5rRJ7o,'video',url)
	return
def kstJfK6jHQWrXDSMRIGB7(search):
	search,v7Rxw52Z4X0,showDialogs = JimhUH0SEf6w(search)
	if search==b8Qe150xVaJsnDSv: search = FT2oXWtPQpVGuexmLqKN3srdzYn()
	if search==b8Qe150xVaJsnDSv: return
	search = search.replace(pldxivXC5wbTB2O8q,'+')
	url = wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/?s='+search
	Je4TwC30iOG5DLKWAtbYvhs(url,'search')
	return
# -*- coding: utf-8 -*-
from hIVCFnfxSO import *
QQ8pvXNcBfVkP5rRJ7o = 'LIVETV'
wQjs1XZ3AO24g8y9bEeoKMiGIu7 = nTHXJIiah2qK['PYTHON'][0]
def x8IFqMZeJj7suCR4AaGoNXfEHm(mode,url):
	if   mode==100: XXxlOLJ9KRjPH382WVCvr6n71 = Y72YmLgw4vqlHxTCkbeKSicasD()
	elif mode==101: XXxlOLJ9KRjPH382WVCvr6n71 = iyZpId2R5sL7F0kDb3AKH9xS('0',True)
	elif mode==102: XXxlOLJ9KRjPH382WVCvr6n71 = iyZpId2R5sL7F0kDb3AKH9xS('1',True)
	elif mode==103: XXxlOLJ9KRjPH382WVCvr6n71 = iyZpId2R5sL7F0kDb3AKH9xS('2',True)
	elif mode==104: XXxlOLJ9KRjPH382WVCvr6n71 = iyZpId2R5sL7F0kDb3AKH9xS('3',True)
	elif mode==105: XXxlOLJ9KRjPH382WVCvr6n71 = Hkij627uCDJKyIM(url)
	elif mode==106: XXxlOLJ9KRjPH382WVCvr6n71 = iyZpId2R5sL7F0kDb3AKH9xS('4',True)
	else: XXxlOLJ9KRjPH382WVCvr6n71 = False
	return XXxlOLJ9KRjPH382WVCvr6n71
def Y72YmLgw4vqlHxTCkbeKSicasD():
	MQtuaShrKTbdZFJ5nsR7D('folder','_M3U_'+'قوائم فيديوهات M3U',b8Qe150xVaJsnDSv,762)
	MQtuaShrKTbdZFJ5nsR7D('folder','_IPT_'+'قوائم فيديوهات IPTV',b8Qe150xVaJsnDSv,761)
	MQtuaShrKTbdZFJ5nsR7D('folder','_TV0_'+'قنوات من مواقعها الأصلية',b8Qe150xVaJsnDSv,101)
	MQtuaShrKTbdZFJ5nsR7D('folder','_TV4_'+'قنوات مختارة من يوتيوب',b8Qe150xVaJsnDSv,106)
	MQtuaShrKTbdZFJ5nsR7D('folder','_YUT_'+'قنوات عربية من يوتيوب',b8Qe150xVaJsnDSv,147)
	MQtuaShrKTbdZFJ5nsR7D('folder','_YUT_'+'قنوات أجنبية من يوتيوب',b8Qe150xVaJsnDSv,148)
	MQtuaShrKTbdZFJ5nsR7D('folder','_IFL_'+'  قناة آي فيلم من موقعهم  ',b8Qe150xVaJsnDSv,28)
	MQtuaShrKTbdZFJ5nsR7D('live','_MRF_'+'قناة المعارف من موقعهم',b8Qe150xVaJsnDSv,41)
	MQtuaShrKTbdZFJ5nsR7D('live','_PNT_'+'قناة هلا من موقع بانيت',b8Qe150xVaJsnDSv,38)
	MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+' ===== ===== ===== '+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999)
	MQtuaShrKTbdZFJ5nsR7D('folder','_TV1_'+'قنوات تلفزيونية عامة',b8Qe150xVaJsnDSv,102)
	MQtuaShrKTbdZFJ5nsR7D('folder','_TV2_'+'قنوات تلفزيونية خاصة',b8Qe150xVaJsnDSv,103)
	MQtuaShrKTbdZFJ5nsR7D('folder','_TV3_'+'قنوات تلفزيونية للفحص',b8Qe150xVaJsnDSv,104)
	return
def iyZpId2R5sL7F0kDb3AKH9xS(XsMYjhI4QHz0yJ3OBqvW,showDialogs=True):
	WbzmKSZiuOYrBN7oysJ2dUv = '_TV'+XsMYjhI4QHz0yJ3OBqvW+'_'
	lo6biSg2NR3eUB1OpEPxzyXwF8sYWI = {'id':b8Qe150xVaJsnDSv,'user':EtvK0T2LNPcsIrAFlufpM,'function':'list','menu':XsMYjhI4QHz0yJ3OBqvW}
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(LtlXH3fvMydAx,'POST',wQjs1XZ3AO24g8y9bEeoKMiGIu7,lo6biSg2NR3eUB1OpEPxzyXwF8sYWI,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'LIVETV-ITEMS-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	items = YYBlm36zd0Jst18LXwo4.findall('([^;\r\n]+?);;(.*?);;(.*?);;(.*?);;(.*?);;',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if items:
		for FbcUxvE17ewlWNBHgS8Jn in range(len(items)):
			name = items[FbcUxvE17ewlWNBHgS8Jn][3]
			start = name[0:2]
			start = start.replace('al','Al')
			start = start.replace('El','Al')
			start = start.replace('AL','Al')
			start = start.replace('EL','Al')
			name = start+name[2:]
			start = name[0:3]
			start = start.replace('Al-','Al')
			start = start.replace('Al ','Al')
			name = start+name[3:]
			items[FbcUxvE17ewlWNBHgS8Jn] = items[FbcUxvE17ewlWNBHgS8Jn][0],items[FbcUxvE17ewlWNBHgS8Jn][1],items[FbcUxvE17ewlWNBHgS8Jn][2],name,items[FbcUxvE17ewlWNBHgS8Jn][4]
		items = set(items)
		items = sorted(items, reverse=False, key=lambda key: key[0].lower())
		items = sorted(items, reverse=False, key=lambda key: key[3].lower())
		for fOzS45youKYdNDqwm61aEI3A,LLOCdZ3sS2enzXx4fVB18YRvbHNwky,MLBDXlxEbU9WJQImfHOnK3zpvdR,name,lvtGpMZHb9 in items:
			if '#' in fOzS45youKYdNDqwm61aEI3A: continue
			if fOzS45youKYdNDqwm61aEI3A!='URL': name = name+rC3Tlno96KjLDIvBaSWUbR8+R1BKXhzpGH6CoO9jLsPwQWu+fOzS45youKYdNDqwm61aEI3A+hAIp8kmC36T5WFPMSXOwnNbtD
			url = fOzS45youKYdNDqwm61aEI3A+';;'+LLOCdZ3sS2enzXx4fVB18YRvbHNwky+';;'+MLBDXlxEbU9WJQImfHOnK3zpvdR+';;'+XsMYjhI4QHz0yJ3OBqvW
			MQtuaShrKTbdZFJ5nsR7D('live',WbzmKSZiuOYrBN7oysJ2dUv+b8Qe150xVaJsnDSv+name,url,105,lvtGpMZHb9)
	else:
		if showDialogs: MQtuaShrKTbdZFJ5nsR7D('link',WbzmKSZiuOYrBN7oysJ2dUv+'هذه الخدمة مخصصة للمبرمج فقط',b8Qe150xVaJsnDSv,9999)
	return
def Hkij627uCDJKyIM(id):
	fOzS45youKYdNDqwm61aEI3A,LLOCdZ3sS2enzXx4fVB18YRvbHNwky,MLBDXlxEbU9WJQImfHOnK3zpvdR,XsMYjhI4QHz0yJ3OBqvW = id.split(';;')
	url = b8Qe150xVaJsnDSv
	if fOzS45youKYdNDqwm61aEI3A=='URL': url = MLBDXlxEbU9WJQImfHOnK3zpvdR
	elif fOzS45youKYdNDqwm61aEI3A=='YOUTUBE':
		url = nTHXJIiah2qK['YOUTUBE'][0]+'/watch?v='+MLBDXlxEbU9WJQImfHOnK3zpvdR
		import QNeGEq8sWn
		QNeGEq8sWn.nqu2GCT9gHAbpIPSFZz5([url],QQ8pvXNcBfVkP5rRJ7o,'live',url)
		return
	elif fOzS45youKYdNDqwm61aEI3A=='GA':
		lo6biSg2NR3eUB1OpEPxzyXwF8sYWI = { 'id' : b8Qe150xVaJsnDSv, 'user' : EtvK0T2LNPcsIrAFlufpM , 'function' : 'playGA1' , 'menu' : b8Qe150xVaJsnDSv }
		b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(LtlXH3fvMydAx,'GET',wQjs1XZ3AO24g8y9bEeoKMiGIu7,lo6biSg2NR3eUB1OpEPxzyXwF8sYWI,b8Qe150xVaJsnDSv,False,b8Qe150xVaJsnDSv,'LIVETV-PLAY-1st')
		if not b3HKopTY9zLUyhJmt.succeeded:
			tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
		cookies = b3HKopTY9zLUyhJmt.cookies
		bEovYkr9Ai6DtL14XIOc7VSgew = cookies['ASP.NET_SessionId']
		url = b3HKopTY9zLUyhJmt.headers['Location']
		lo6biSg2NR3eUB1OpEPxzyXwF8sYWI = { 'id' : MLBDXlxEbU9WJQImfHOnK3zpvdR , 'user' : EtvK0T2LNPcsIrAFlufpM , 'function' : 'playGA2' , 'menu' : b8Qe150xVaJsnDSv }
		headers = { 'Cookie' : 'ASP.NET_SessionId='+bEovYkr9Ai6DtL14XIOc7VSgew }
		b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(LtlXH3fvMydAx,'GET',wQjs1XZ3AO24g8y9bEeoKMiGIu7,lo6biSg2NR3eUB1OpEPxzyXwF8sYWI,headers,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'LIVETV-PLAY-2nd')
		if not b3HKopTY9zLUyhJmt.succeeded:
			tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
		url = YYBlm36zd0Jst18LXwo4.findall('resp":"(http.*?m3u8)(.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = url[0][0]
		ZNXAYzgFWyiJPGt = url[0][1]
		n7c6HISZv4yO = 'http://38.'+LLOCdZ3sS2enzXx4fVB18YRvbHNwky+'777/'+MLBDXlxEbU9WJQImfHOnK3zpvdR+'_HD.m3u8'+ZNXAYzgFWyiJPGt
		JmcauqoLjA = n7c6HISZv4yO.replace('36:7','40:7').replace('_HD.m3u8','.m3u8')
		RF34erxjiZw7Wt = n7c6HISZv4yO.replace('36:7','42:7').replace('_HD.m3u8','.m3u8')
		uuSKUinvP4EGLxWZYmTsF = ['HD','SD1','SD2']
		KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = [n7c6HISZv4yO,JmcauqoLjA,RF34erxjiZw7Wt]
		cMZGTsAR2E = 0
		if cMZGTsAR2E == -1: return
		else: url = KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j[cMZGTsAR2E]
	elif fOzS45youKYdNDqwm61aEI3A=='NT':
		headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
		lo6biSg2NR3eUB1OpEPxzyXwF8sYWI = { 'id' : MLBDXlxEbU9WJQImfHOnK3zpvdR , 'user' : EtvK0T2LNPcsIrAFlufpM , 'function' : 'playNT' , 'menu' : XsMYjhI4QHz0yJ3OBqvW }
		b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(LtlXH3fvMydAx,'POST', wQjs1XZ3AO24g8y9bEeoKMiGIu7, lo6biSg2NR3eUB1OpEPxzyXwF8sYWI, headers, False,b8Qe150xVaJsnDSv,'LIVETV-PLAY-3rd')
		if not b3HKopTY9zLUyhJmt.succeeded:
			tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
		url = b3HKopTY9zLUyhJmt.headers['Location']
		url = url.replace('%20',pldxivXC5wbTB2O8q)
		url = url.replace('%3D','=')
		if 'Learn' in MLBDXlxEbU9WJQImfHOnK3zpvdR:
			url = url.replace('NTNNile',b8Qe150xVaJsnDSv)
			url = url.replace('learning1','Learning')
	elif fOzS45youKYdNDqwm61aEI3A=='PL':
		lo6biSg2NR3eUB1OpEPxzyXwF8sYWI = { 'id' : MLBDXlxEbU9WJQImfHOnK3zpvdR , 'user' : EtvK0T2LNPcsIrAFlufpM , 'function' : 'playPL' , 'menu' : XsMYjhI4QHz0yJ3OBqvW }
		b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(LtlXH3fvMydAx,'POST', wQjs1XZ3AO24g8y9bEeoKMiGIu7, lo6biSg2NR3eUB1OpEPxzyXwF8sYWI, b8Qe150xVaJsnDSv,False,b8Qe150xVaJsnDSv,'LIVETV-PLAY-4th')
		if not b3HKopTY9zLUyhJmt.succeeded:
			tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
		url = b3HKopTY9zLUyhJmt.headers['Location']
		headers = {'Referer':b3HKopTY9zLUyhJmt.headers['Referer']}
		b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(nCUMfrlZvuiLe5x,'POST',url, b8Qe150xVaJsnDSv,headers , b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'LIVETV-PLAY-5th')
		if not b3HKopTY9zLUyhJmt.succeeded:
			tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
		items = YYBlm36zd0Jst18LXwo4.findall('source src="(.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		url = items[0]
	elif fOzS45youKYdNDqwm61aEI3A in ['TA','FM','YU','WS1','WS2','RL1','RL2']:
		if fOzS45youKYdNDqwm61aEI3A=='TA': MLBDXlxEbU9WJQImfHOnK3zpvdR = id
		headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
		lo6biSg2NR3eUB1OpEPxzyXwF8sYWI = { 'id' : MLBDXlxEbU9WJQImfHOnK3zpvdR , 'user' : EtvK0T2LNPcsIrAFlufpM , 'function' : 'play'+fOzS45youKYdNDqwm61aEI3A , 'menu' : XsMYjhI4QHz0yJ3OBqvW }
		b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(LtlXH3fvMydAx,'POST',wQjs1XZ3AO24g8y9bEeoKMiGIu7,lo6biSg2NR3eUB1OpEPxzyXwF8sYWI,headers,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'LIVETV-PLAY-6th')
		if not b3HKopTY9zLUyhJmt.succeeded:
			tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
		url = b3HKopTY9zLUyhJmt.headers['Location']
		if fOzS45youKYdNDqwm61aEI3A=='FM':
			b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(nCUMfrlZvuiLe5x,'GET', url, b8Qe150xVaJsnDSv, b8Qe150xVaJsnDSv, False,b8Qe150xVaJsnDSv,'LIVETV-PLAY-7th')
			url = b3HKopTY9zLUyhJmt.headers['Location']
			url = url.replace('https','http')
	yulQjIFbzM(url,QQ8pvXNcBfVkP5rRJ7o,'live')
	return
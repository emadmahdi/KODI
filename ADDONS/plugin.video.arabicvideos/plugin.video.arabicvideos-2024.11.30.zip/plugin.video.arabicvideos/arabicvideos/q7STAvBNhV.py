# -*- coding: utf-8 -*-
from hIVCFnfxSO import *
QQ8pvXNcBfVkP5rRJ7o = 'BOKRA'
WbzmKSZiuOYrBN7oysJ2dUv = '_BKR_'
wQjs1XZ3AO24g8y9bEeoKMiGIu7 = nTHXJIiah2qK[QQ8pvXNcBfVkP5rRJ7o][0]
headers = {'User-Agent':b8Qe150xVaJsnDSv}
v1vJEhoNQBVPkjG = ['افلام للكبار','بكرا TV']
def x8IFqMZeJj7suCR4AaGoNXfEHm(mode,url,text):
	if   mode==370: XXxlOLJ9KRjPH382WVCvr6n71 = Y72YmLgw4vqlHxTCkbeKSicasD()
	elif mode==371: XXxlOLJ9KRjPH382WVCvr6n71 = Je4TwC30iOG5DLKWAtbYvhs(url,text)
	elif mode==372: XXxlOLJ9KRjPH382WVCvr6n71 = Hkij627uCDJKyIM(url)
	elif mode==374: XXxlOLJ9KRjPH382WVCvr6n71 = hGE2AUas1mwv4TcuKW8lC(url)
	elif mode==375: XXxlOLJ9KRjPH382WVCvr6n71 = E39EPbfvCJ7NFSpnhMs2B4L51wAx(url)
	elif mode==376: XXxlOLJ9KRjPH382WVCvr6n71 = TLyOQCp35x(0,url)
	elif mode==377: XXxlOLJ9KRjPH382WVCvr6n71 = TLyOQCp35x(1,url)
	elif mode==379: XXxlOLJ9KRjPH382WVCvr6n71 = kstJfK6jHQWrXDSMRIGB7(text)
	else: XXxlOLJ9KRjPH382WVCvr6n71 = False
	return XXxlOLJ9KRjPH382WVCvr6n71
def Y72YmLgw4vqlHxTCkbeKSicasD():
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(Q49IsrlSuYRAVbGKhwdckLDOetF2PZ,'GET',wQjs1XZ3AO24g8y9bEeoKMiGIu7,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'BOKRA-MENU-1st')
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'بحث في الموقع',b8Qe150xVaJsnDSv,379,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'_REMEMBERRESULTS_')
	MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+' ===== ===== ===== '+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999)
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('right-side(.*?)</ul>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)">(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = wQjs1XZ3AO24g8y9bEeoKMiGIu7+pcA1dzy7LXwGfMPg9mTkuh5tine3
			if not any(Y8aiFZsLKw in title for Y8aiFZsLKw in v1vJEhoNQBVPkjG):
				MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,371)
	MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+'المميزة',wQjs1XZ3AO24g8y9bEeoKMiGIu7,375)
	MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+'الأحدث',wQjs1XZ3AO24g8y9bEeoKMiGIu7,376)
	MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+'قائمة الممثلين',wQjs1XZ3AO24g8y9bEeoKMiGIu7,374)
	MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+' ===== ===== ===== '+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999)
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('class="container"(.*?)top-menu',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)">(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items[7:]:
			title = title.strip(pldxivXC5wbTB2O8q)
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = wQjs1XZ3AO24g8y9bEeoKMiGIu7+pcA1dzy7LXwGfMPg9mTkuh5tine3
			if not any(Y8aiFZsLKw in title for Y8aiFZsLKw in v1vJEhoNQBVPkjG):
				MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,371)
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items[0:7]:
			title = title.strip(pldxivXC5wbTB2O8q)
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = wQjs1XZ3AO24g8y9bEeoKMiGIu7+pcA1dzy7LXwGfMPg9mTkuh5tine3
			if not any(Y8aiFZsLKw in title for Y8aiFZsLKw in v1vJEhoNQBVPkjG):
				MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,371)
	return
def hGE2AUas1mwv4TcuKW8lC(website=b8Qe150xVaJsnDSv):
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(Q49IsrlSuYRAVbGKhwdckLDOetF2PZ,'GET',wQjs1XZ3AO24g8y9bEeoKMiGIu7,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'BOKRA-ACTORSMENU-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('class="row cat Tags"(.*?)</div>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)" title="(.*?)"',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
			if 'http' in pcA1dzy7LXwGfMPg9mTkuh5tine3: continue
			else: pcA1dzy7LXwGfMPg9mTkuh5tine3 = wQjs1XZ3AO24g8y9bEeoKMiGIu7+pcA1dzy7LXwGfMPg9mTkuh5tine3
			if not any(Y8aiFZsLKw in title for Y8aiFZsLKw in v1vJEhoNQBVPkjG):
				MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,371)
	return
def E39EPbfvCJ7NFSpnhMs2B4L51wAx(website=b8Qe150xVaJsnDSv):
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(LtlXH3fvMydAx,'GET',wQjs1XZ3AO24g8y9bEeoKMiGIu7,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'BOKRA-FEATURED-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('"MainContent"(.*?)main-title2',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		items = YYBlm36zd0Jst18LXwo4.findall('href="(/vidpage_.*?)".*? src="(.*?)".*?<h3>(.*?)</h3>',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,lvtGpMZHb9,title in items:
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = wQjs1XZ3AO24g8y9bEeoKMiGIu7+pcA1dzy7LXwGfMPg9mTkuh5tine3
			if not any(Y8aiFZsLKw in title for Y8aiFZsLKw in v1vJEhoNQBVPkjG):
				lvtGpMZHb9 = lvtGpMZHb9.replace('://',':///').replace('//','/').replace(pldxivXC5wbTB2O8q,'%20')
				MQtuaShrKTbdZFJ5nsR7D('video',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,372,lvtGpMZHb9)
	return
def TLyOQCp35x(id,website=b8Qe150xVaJsnDSv):
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(LtlXH3fvMydAx,'GET',wQjs1XZ3AO24g8y9bEeoKMiGIu7,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'BOKRA-WATCHINGNOW-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('main-title2(.*?)class="row',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[id]
		items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)".*? src="(.*?)".*?<h4>(.*?)</h4>',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,lvtGpMZHb9,title in items:
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = wQjs1XZ3AO24g8y9bEeoKMiGIu7+pcA1dzy7LXwGfMPg9mTkuh5tine3
			if not any(Y8aiFZsLKw in title for Y8aiFZsLKw in v1vJEhoNQBVPkjG):
				lvtGpMZHb9 = lvtGpMZHb9.replace('://',':///').replace('//','/').replace(pldxivXC5wbTB2O8q,'%20')
				MQtuaShrKTbdZFJ5nsR7D('video',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,372,lvtGpMZHb9)
	return
def Je4TwC30iOG5DLKWAtbYvhs(url,oYe8RpT3jO17qBKDLkZd2gCJ=b8Qe150xVaJsnDSv):
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'BOKRA-TITLES-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	if 'vidpage_' in url:
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = YYBlm36zd0Jst18LXwo4.findall('href="(/Album-.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if pcA1dzy7LXwGfMPg9mTkuh5tine3:
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = wQjs1XZ3AO24g8y9bEeoKMiGIu7+pcA1dzy7LXwGfMPg9mTkuh5tine3[0]
			Je4TwC30iOG5DLKWAtbYvhs(pcA1dzy7LXwGfMPg9mTkuh5tine3)
			return
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('class=" subcats"(.*?)class="col-md-3',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if oYe8RpT3jO17qBKDLkZd2gCJ==b8Qe150xVaJsnDSv and ZV5rRvabhxJ and ZV5rRvabhxJ[0].count('href')>1:
		MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'الجميع',url,371,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'titles')
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)" title="(.*?)"',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/'+pcA1dzy7LXwGfMPg9mTkuh5tine3
			title = title.strip(pldxivXC5wbTB2O8q)
			MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,371)
	else:
		d3VSIefbHnvqiut = []
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('class="col-md-3(.*?)col-xs-12',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if not ZV5rRvabhxJ: ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('class="col-sm-8"(.*?)col-xs-12',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if ZV5rRvabhxJ:
			OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
			items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)".*?src="(.*?)".*?<h4>(.*?)</h4>',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
			for pcA1dzy7LXwGfMPg9mTkuh5tine3,lvtGpMZHb9,title in items:
				pcA1dzy7LXwGfMPg9mTkuh5tine3 = wQjs1XZ3AO24g8y9bEeoKMiGIu7+pcA1dzy7LXwGfMPg9mTkuh5tine3
				title = title.strip(pldxivXC5wbTB2O8q)
				lvtGpMZHb9 = lvtGpMZHb9.replace('://',':///').replace('//','/').replace(pldxivXC5wbTB2O8q,'%20')
				if '/al_' in pcA1dzy7LXwGfMPg9mTkuh5tine3:
					MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,371,lvtGpMZHb9)
				elif 'الحلقة' in title and ('/Cat-' in url or '/Search/' in url):
					HHr42WSgBjAeU7TkQcVaL6yEJz8PF = YYBlm36zd0Jst18LXwo4.findall('(.*?) - +الحلقة +\d+',title,YYBlm36zd0Jst18LXwo4.DOTALL)
					if HHr42WSgBjAeU7TkQcVaL6yEJz8PF: title = '_MOD_مسلسل '+HHr42WSgBjAeU7TkQcVaL6yEJz8PF[0]
					if title not in d3VSIefbHnvqiut:
						d3VSIefbHnvqiut.append(title)
						MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,371,lvtGpMZHb9)
				else: MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,372,lvtGpMZHb9)
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('class="pagination(.*?)</div>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if ZV5rRvabhxJ:
			OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
			items = YYBlm36zd0Jst18LXwo4.findall('class="".*?href="(.*?)">(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
			for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
				pcA1dzy7LXwGfMPg9mTkuh5tine3 = wQjs1XZ3AO24g8y9bEeoKMiGIu7+pcA1dzy7LXwGfMPg9mTkuh5tine3
				title = 'صفحة '+pTP49ckGDYrofa2KxenumbH0(title)
				MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,371,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'titles')
	return
def Hkij627uCDJKyIM(url):
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(LtlXH3fvMydAx,'GET',url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'BOKRA-PLAY-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	EQUkgc3PLy5mhBiZINJ0HO1A6 = YYBlm36zd0Jst18LXwo4.findall('label-success mrg-btm-5 ">(.*?)<',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if EQUkgc3PLy5mhBiZINJ0HO1A6 and vvIMS2DeraLfJ(QQ8pvXNcBfVkP5rRJ7o,url,EQUkgc3PLy5mhBiZINJ0HO1A6): return
	GSh0nJxEXgZjd48u7mBwWOeafyAp5b = b8Qe150xVaJsnDSv
	MUJCtfYVBLODrFbaZn = YYBlm36zd0Jst18LXwo4.findall('var url = "(.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if MUJCtfYVBLODrFbaZn: MUJCtfYVBLODrFbaZn = MUJCtfYVBLODrFbaZn[0]
	else: MUJCtfYVBLODrFbaZn = url.replace('/vidpage_','/Play/')
	if 'http' not in MUJCtfYVBLODrFbaZn: MUJCtfYVBLODrFbaZn = wQjs1XZ3AO24g8y9bEeoKMiGIu7+MUJCtfYVBLODrFbaZn
	MUJCtfYVBLODrFbaZn = MUJCtfYVBLODrFbaZn.strip('-')
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(IiYS8Jg4da3UuDP0qr6vy,'GET',MUJCtfYVBLODrFbaZn,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'BOKRA-PLAY-2nd')
	vWsMIpk1n6rlLqH52 = b3HKopTY9zLUyhJmt.content
	GSh0nJxEXgZjd48u7mBwWOeafyAp5b = YYBlm36zd0Jst18LXwo4.findall('src="(.*?)"',vWsMIpk1n6rlLqH52,YYBlm36zd0Jst18LXwo4.DOTALL)
	if GSh0nJxEXgZjd48u7mBwWOeafyAp5b:
		GSh0nJxEXgZjd48u7mBwWOeafyAp5b = GSh0nJxEXgZjd48u7mBwWOeafyAp5b[-1]
		if 'http' not in GSh0nJxEXgZjd48u7mBwWOeafyAp5b: GSh0nJxEXgZjd48u7mBwWOeafyAp5b = 'http:'+GSh0nJxEXgZjd48u7mBwWOeafyAp5b
		if '/PLAY/' not in MUJCtfYVBLODrFbaZn:
			if 'embed.min.js' in GSh0nJxEXgZjd48u7mBwWOeafyAp5b:
				sGOr2uHF8WbCK3E4S6hP0y1ptoU = YYBlm36zd0Jst18LXwo4.findall('data-publisher-id="(.*?)" data-video-id="(.*?)"',vWsMIpk1n6rlLqH52,YYBlm36zd0Jst18LXwo4.DOTALL)
				if sGOr2uHF8WbCK3E4S6hP0y1ptoU:
					m4mB96zV2Wcy3, K0qigcTlGazySrIdYNuZ5wV6 = sGOr2uHF8WbCK3E4S6hP0y1ptoU[0]
					GSh0nJxEXgZjd48u7mBwWOeafyAp5b = Wl2eu1PavfQ(GSh0nJxEXgZjd48u7mBwWOeafyAp5b,'url')+'/v2/'+m4mB96zV2Wcy3+'/config/'+K0qigcTlGazySrIdYNuZ5wV6+'.json'
		import QNeGEq8sWn
		QNeGEq8sWn.nqu2GCT9gHAbpIPSFZz5([GSh0nJxEXgZjd48u7mBwWOeafyAp5b],QQ8pvXNcBfVkP5rRJ7o,'video',url)
	return
def kstJfK6jHQWrXDSMRIGB7(search):
	search,v7Rxw52Z4X0,showDialogs = JimhUH0SEf6w(search)
	if search==b8Qe150xVaJsnDSv: search = FT2oXWtPQpVGuexmLqKN3srdzYn()
	if search==b8Qe150xVaJsnDSv: return
	search = search.replace(pldxivXC5wbTB2O8q,'+')
	url = wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/Search/'+search
	Je4TwC30iOG5DLKWAtbYvhs(url)
	return
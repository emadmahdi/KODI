# -*- coding: utf-8 -*-
from hIVCFnfxSO import *
QQ8pvXNcBfVkP5rRJ7o = 'FAJERSHOW'
WbzmKSZiuOYrBN7oysJ2dUv = '_FJS_'
wQjs1XZ3AO24g8y9bEeoKMiGIu7 = nTHXJIiah2qK[QQ8pvXNcBfVkP5rRJ7o][0]
v1vJEhoNQBVPkjG = ['التصنيفات','انشاء حساب','طلبات الزوّار']
def x8IFqMZeJj7suCR4AaGoNXfEHm(mode,url,text):
	if   mode==390: XXxlOLJ9KRjPH382WVCvr6n71 = Y72YmLgw4vqlHxTCkbeKSicasD()
	elif mode==391: XXxlOLJ9KRjPH382WVCvr6n71 = Je4TwC30iOG5DLKWAtbYvhs(url,text)
	elif mode==392: XXxlOLJ9KRjPH382WVCvr6n71 = Hkij627uCDJKyIM(url)
	elif mode==393: XXxlOLJ9KRjPH382WVCvr6n71 = bIpskeGhBlqH(url)
	elif mode==399: XXxlOLJ9KRjPH382WVCvr6n71 = kstJfK6jHQWrXDSMRIGB7(text)
	else: XXxlOLJ9KRjPH382WVCvr6n71 = False
	return XXxlOLJ9KRjPH382WVCvr6n71
def Y72YmLgw4vqlHxTCkbeKSicasD():
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'بحث في الموقع',b8Qe150xVaJsnDSv,399,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'_REMEMBERRESULTS_')
	MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+' ===== ===== ===== '+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999)
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(Q49IsrlSuYRAVbGKhwdckLDOetF2PZ,'GET',wQjs1XZ3AO24g8y9bEeoKMiGIu7,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'FAJERSHOW-MENU-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	items = YYBlm36zd0Jst18LXwo4.findall('<header>.*?<h2>(.*?)<',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	for JZMvR4mp2rX7Kf6n in range(len(items)):
		title = items[JZMvR4mp2rX7Kf6n]
		MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+title,wQjs1XZ3AO24g8y9bEeoKMiGIu7,391,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'latest'+str(JZMvR4mp2rX7Kf6n))
	MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+'مختارات عشوائية',wQjs1XZ3AO24g8y9bEeoKMiGIu7,391,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'randoms')
	MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+'أعلى الأفلام تقييماً',wQjs1XZ3AO24g8y9bEeoKMiGIu7,391,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'top_imdb_movies')
	MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+'أعلى المسلسلات تقييماً',wQjs1XZ3AO24g8y9bEeoKMiGIu7,391,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'top_imdb_series')
	MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+'أفلام مميزة',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/movies',391,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'featured_movies')
	MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+'مسلسلات مميزة',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/tvshows',391,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'featured_tvshows')
	OTKx7aVb2hdS16Wrweky4FXfIN0g9 = b8Qe150xVaJsnDSv
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('class="menu"(.*?)id="contenedor"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ: OTKx7aVb2hdS16Wrweky4FXfIN0g9 += ZV5rRvabhxJ[0]
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(Q49IsrlSuYRAVbGKhwdckLDOetF2PZ,'GET',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/movies',b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'FAJERSHOW-MENU-2nd')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('class="releases"(.*?)aside',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ: OTKx7aVb2hdS16Wrweky4FXfIN0g9 += ZV5rRvabhxJ[0]
	MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+' ===== ===== ===== '+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999)
	items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)">(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	CGQ914dXgqhLswByzFSKEWkPmv8j = True
	for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
		title = pTP49ckGDYrofa2KxenumbH0(title)
		if title=='الأعلى مشاهدة':
			if CGQ914dXgqhLswByzFSKEWkPmv8j:
				title = 'الافلام '+title
				CGQ914dXgqhLswByzFSKEWkPmv8j = False
			else: title = 'المسلسلات '+title
		if title not in v1vJEhoNQBVPkjG:
			if title=='أفلام': MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+title,wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/movies',391,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'all_movies_tvshows')
			elif title=='مسلسلات': MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+title,wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/tvshows',391,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'all_movies_tvshows')
			else: MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,391)
	return jLtdbeYiQHnf4SpU2MTly
def Je4TwC30iOG5DLKWAtbYvhs(url,type):
	OTKx7aVb2hdS16Wrweky4FXfIN0g9,items = [],[]
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'FAJERSHOW-TITLES-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	if type in ['featured_movies','featured_tvshows']:
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('class="content"(.*?)id="archive-content"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if ZV5rRvabhxJ: OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
	elif type=='all_movies_tvshows':
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('id="archive-content"(.*?)class="pagination"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if ZV5rRvabhxJ: OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
	elif type=='top_imdb_movies':
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall("class='top-imdb-list tleft(.*?)class='top-imdb-list tright",jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if ZV5rRvabhxJ:
			OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
			items = YYBlm36zd0Jst18LXwo4.findall("img src='(.*?)'.*?href='(.*?)'>(.*?)<",OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	elif type=='top_imdb_series':
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall("class='top-imdb-list tright(.*?)footer",jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if ZV5rRvabhxJ:
			OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
			items = YYBlm36zd0Jst18LXwo4.findall("img src='(.*?)'.*?href='(.*?)'>(.*?)<",OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	elif type=='search':
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('class="search-page"(.*?)class="sidebar',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if ZV5rRvabhxJ:
			OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
			items = YYBlm36zd0Jst18LXwo4.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	elif type=='sider':
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('class="widget(.*?)class="widget',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		TJuDfURKbI6MynChiEXqAYQS4d58j = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)".*?img src="(.*?)".*?<h3>(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j,mLRifACEnrvgjyqz,uuSKUinvP4EGLxWZYmTsF = zip(*TJuDfURKbI6MynChiEXqAYQS4d58j)
		items = zip(mLRifACEnrvgjyqz,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j,uuSKUinvP4EGLxWZYmTsF)
	elif type=='randoms':
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('id="slider-movies-tvshows"(.*?)<header>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		items = YYBlm36zd0Jst18LXwo4.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	elif 'latest' in type:
		JZMvR4mp2rX7Kf6n = int(type[-1:])
		jLtdbeYiQHnf4SpU2MTly = jLtdbeYiQHnf4SpU2MTly.replace('<header>','<end><start>')
		jLtdbeYiQHnf4SpU2MTly = jLtdbeYiQHnf4SpU2MTly.replace('</div></div></div>','</div></div></div><end>')
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('<start>(.*?)<end>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[JZMvR4mp2rX7Kf6n]
		if JZMvR4mp2rX7Kf6n==6:
			TJuDfURKbI6MynChiEXqAYQS4d58j = YYBlm36zd0Jst18LXwo4.findall('img src="(.*?)" alt="(.*?)".*?href="(.*?)"',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
			mLRifACEnrvgjyqz,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = zip(*TJuDfURKbI6MynChiEXqAYQS4d58j)
			items = zip(mLRifACEnrvgjyqz,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j,uuSKUinvP4EGLxWZYmTsF)
	else:
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('class="content"(.*?)class="(pagination|sidebar)',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if ZV5rRvabhxJ:
			OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0][0]
			if '/collection/' in url:
				items = YYBlm36zd0Jst18LXwo4.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
			elif '/quality/' in url:
				items = YYBlm36zd0Jst18LXwo4.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	if not items and OTKx7aVb2hdS16Wrweky4FXfIN0g9:
		items = YYBlm36zd0Jst18LXwo4.findall('img src="(.*?)".*?href=.*?href="(.*?)">(.*?)</div>',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	d3VSIefbHnvqiut = []
	for lvtGpMZHb9,pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
		if 'src=' in title: continue
		if 'serie' in title:
			title = YYBlm36zd0Jst18LXwo4.findall('^(.*?)<.*?serie">(.*?)<',title,YYBlm36zd0Jst18LXwo4.DOTALL)
			title = title[0][1]
			if title in d3VSIefbHnvqiut: continue
			d3VSIefbHnvqiut.append(title)
			title = '_MOD_'+title
		HoXz65T8ph1CMeZgF = YYBlm36zd0Jst18LXwo4.findall('^(.*?)<',title,YYBlm36zd0Jst18LXwo4.DOTALL)
		if HoXz65T8ph1CMeZgF: title = HoXz65T8ph1CMeZgF[0]
		title = pTP49ckGDYrofa2KxenumbH0(title)
		if '/tvshows/' in pcA1dzy7LXwGfMPg9mTkuh5tine3: MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,393,lvtGpMZHb9)
		elif '/episodes/' in pcA1dzy7LXwGfMPg9mTkuh5tine3: MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,393,lvtGpMZHb9)
		elif '/seasons/' in pcA1dzy7LXwGfMPg9mTkuh5tine3: MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,393,lvtGpMZHb9)
		elif '/collection/' in pcA1dzy7LXwGfMPg9mTkuh5tine3: MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,391,lvtGpMZHb9)
		else: MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,392,lvtGpMZHb9)
	if type not in ['featured_movies','featured_tvshows']:
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('"pagination"(.*?)</div>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if ZV5rRvabhxJ:
			OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
			items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)".*?>(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
			for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
				MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'صفحة '+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,391,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,type)
	return
def bIpskeGhBlqH(url):
	LLOCdZ3sS2enzXx4fVB18YRvbHNwky = Wl2eu1PavfQ(url,'url')
	url = url.replace(LLOCdZ3sS2enzXx4fVB18YRvbHNwky,wQjs1XZ3AO24g8y9bEeoKMiGIu7)
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'FAJERSHOW-EPISODES-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	EQUkgc3PLy5mhBiZINJ0HO1A6 = YYBlm36zd0Jst18LXwo4.findall('class="C rated".*?>(.*?)<',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if EQUkgc3PLy5mhBiZINJ0HO1A6 and vvIMS2DeraLfJ(QQ8pvXNcBfVkP5rRJ7o,url,EQUkgc3PLy5mhBiZINJ0HO1A6): return
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('<ul class="episodios">(.*?)</ul></div></div></div>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		items = YYBlm36zd0Jst18LXwo4.findall('src="(.*?)".*?href="(.*?)">(.*?)</a>',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for lvtGpMZHb9,pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
			MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,392,lvtGpMZHb9)
	return
def Hkij627uCDJKyIM(url):
	jLtdbeYiQHnf4SpU2MTly = iPw18YvqUjlGMoL2N(GMkNL1RXxKFentp0Zh9d,'GET',url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'FAJERSHOW-PLAY-1st')
	EQUkgc3PLy5mhBiZINJ0HO1A6 = YYBlm36zd0Jst18LXwo4.findall('class="C rated".*?>(.*?)<',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if EQUkgc3PLy5mhBiZINJ0HO1A6 and vvIMS2DeraLfJ(QQ8pvXNcBfVkP5rRJ7o,url,EQUkgc3PLy5mhBiZINJ0HO1A6): return
	KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = []
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('id="player-option-1"(.*?)class=["|\'](sheader|pag_episodes)["|\']',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0][0]
		items = YYBlm36zd0Jst18LXwo4.findall('data-type="(.*?)" data-post="(.*?)" data-nume="(.*?)".*?class="vid_title">(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for type,EEZLmsCMxVl07kRfzAih,PxN8A5g1pVYb,title in items:
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/wp-admin/admin-ajax.php?action=doo_player_ajax&post='+EEZLmsCMxVl07kRfzAih+'&nume='+PxN8A5g1pVYb+'&type='+type
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3+'?named='+title+'__watch'
			KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('''id=["']download["'] class(.*?)class=["']sbox["']''',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		items = YYBlm36zd0Jst18LXwo4.findall('''img src=["'](.*?)["'].*?href=["'](.*?)["'].*?["']quality["']>(.*?)<.*?<td>(.*?)<''',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for lvtGpMZHb9,pcA1dzy7LXwGfMPg9mTkuh5tine3,c1EdszLx3mkb8QYX9,Z39mxoGwr0QWVKB2chSIqd in items:
			if '=' in lvtGpMZHb9:
				ADZvOGKc6yBEl9bVwm3U4 = lvtGpMZHb9.split('=')[1]
				title = Wl2eu1PavfQ(ADZvOGKc6yBEl9bVwm3U4,'host')
			else: title = b8Qe150xVaJsnDSv
			title = Z39mxoGwr0QWVKB2chSIqd+pldxivXC5wbTB2O8q+title
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3+'?named='+title+'__download____'+c1EdszLx3mkb8QYX9
			KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
	import QNeGEq8sWn
	QNeGEq8sWn.nqu2GCT9gHAbpIPSFZz5(KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j,QQ8pvXNcBfVkP5rRJ7o,'video',url)
	return
def kstJfK6jHQWrXDSMRIGB7(search):
	search,v7Rxw52Z4X0,showDialogs = JimhUH0SEf6w(search)
	if search==b8Qe150xVaJsnDSv: search = FT2oXWtPQpVGuexmLqKN3srdzYn()
	if search==b8Qe150xVaJsnDSv: return
	search = search.replace(pldxivXC5wbTB2O8q,'+')
	url = wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/?s='+search
	Je4TwC30iOG5DLKWAtbYvhs(url,'search')
	return
# -*- coding: utf-8 -*-
from hIVCFnfxSO import *
QQ8pvXNcBfVkP5rRJ7o = 'IFILM'
WbzmKSZiuOYrBN7oysJ2dUv = '_IFL_'
wQjs1XZ3AO24g8y9bEeoKMiGIu7 = nTHXJIiah2qK[QQ8pvXNcBfVkP5rRJ7o][0]
RRtlZAxNcPqnOHgzLY7ude5rBXGToK = nTHXJIiah2qK[QQ8pvXNcBfVkP5rRJ7o][1]
ssLvF98DfYKnzAh7dTkuw6Zly51 = nTHXJIiah2qK[QQ8pvXNcBfVkP5rRJ7o][2]
tPqKaGfh8mOW = nTHXJIiah2qK[QQ8pvXNcBfVkP5rRJ7o][3]
def x8IFqMZeJj7suCR4AaGoNXfEHm(mode,url,NGQDwOCXx1BZmd9Huc,text):
	if   mode==20: XXxlOLJ9KRjPH382WVCvr6n71 = CxDtKMiX1IaQEpOFNe98dWuUBPbl()
	elif mode==21: XXxlOLJ9KRjPH382WVCvr6n71 = Y72YmLgw4vqlHxTCkbeKSicasD(url)
	elif mode==22: XXxlOLJ9KRjPH382WVCvr6n71 = Je4TwC30iOG5DLKWAtbYvhs(url,NGQDwOCXx1BZmd9Huc)
	elif mode==23: XXxlOLJ9KRjPH382WVCvr6n71 = bIpskeGhBlqH(url,NGQDwOCXx1BZmd9Huc)
	elif mode==24: XXxlOLJ9KRjPH382WVCvr6n71 = Hkij627uCDJKyIM(url,text)
	elif mode==25: XXxlOLJ9KRjPH382WVCvr6n71 = IIarLlWP57qkNd(url)
	elif mode==27: XXxlOLJ9KRjPH382WVCvr6n71 = vtqABUEyi7jeLRWSkV5b8KpMH(url)
	elif mode==28: XXxlOLJ9KRjPH382WVCvr6n71 = jrw80tk6So()
	elif mode==29: XXxlOLJ9KRjPH382WVCvr6n71 = kstJfK6jHQWrXDSMRIGB7(text)
	else: XXxlOLJ9KRjPH382WVCvr6n71 = False
	return XXxlOLJ9KRjPH382WVCvr6n71
def CxDtKMiX1IaQEpOFNe98dWuUBPbl():
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'عربي',wQjs1XZ3AO24g8y9bEeoKMiGIu7,21,b8Qe150xVaJsnDSv,'101')
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'English',RRtlZAxNcPqnOHgzLY7ude5rBXGToK,21,b8Qe150xVaJsnDSv,'101')
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'فارسى',ssLvF98DfYKnzAh7dTkuw6Zly51,21,b8Qe150xVaJsnDSv,'101')
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'فارسى 2',tPqKaGfh8mOW,21,b8Qe150xVaJsnDSv,'101')
	return
def jrw80tk6So():
	MQtuaShrKTbdZFJ5nsR7D('live',WbzmKSZiuOYrBN7oysJ2dUv+'عربي',wQjs1XZ3AO24g8y9bEeoKMiGIu7,27)
	MQtuaShrKTbdZFJ5nsR7D('live',WbzmKSZiuOYrBN7oysJ2dUv+'English',RRtlZAxNcPqnOHgzLY7ude5rBXGToK,27)
	MQtuaShrKTbdZFJ5nsR7D('live',WbzmKSZiuOYrBN7oysJ2dUv+'فارسى',ssLvF98DfYKnzAh7dTkuw6Zly51,27)
	MQtuaShrKTbdZFJ5nsR7D('live',WbzmKSZiuOYrBN7oysJ2dUv+'فارسى 2',tPqKaGfh8mOW,27)
	return
def Y72YmLgw4vqlHxTCkbeKSicasD(lGitcTywSI0YK1N):
	QQ8pvXNcBfVkP5rRJ7o = lGitcTywSI0YK1N
	if lGitcTywSI0YK1N=='IFILM-ARABIC': lGitcTywSI0YK1N = wQjs1XZ3AO24g8y9bEeoKMiGIu7
	elif lGitcTywSI0YK1N=='IFILM-ENGLISH': lGitcTywSI0YK1N = RRtlZAxNcPqnOHgzLY7ude5rBXGToK
	else: QQ8pvXNcBfVkP5rRJ7o = b8Qe150xVaJsnDSv
	Z39mxoGwr0QWVKB2chSIqd = o4Zn1YEgkixa2PXldwqJ3FsjB7(lGitcTywSI0YK1N)
	if Z39mxoGwr0QWVKB2chSIqd=='ar' or QQ8pvXNcBfVkP5rRJ7o=='IFILM-ARABIC':
		LCO9XdUASxDbuWRrzyjKN34TqMfp = 'بحث في الموقع'
		u2jARE57amCQSwZLkiO9qzrg1P = 'مسلسلات - حالية'
		WUj71fhxld3rqONpBzmEuC = 'مسلسلات - أحدث'
		kU8rztvRXfE590OMuP6 = 'مسلسلات - أبجدي'
		DdJvyxS5pVo90 = 'بث حي آي فيلم'
		yKFBiUMt3YevqPd = 'أفلام'
		GifCYu7XRJLAPNw = 'موسيقى'
		yBbmMvxPFA5976SQtO = 'برامج'
	elif Z39mxoGwr0QWVKB2chSIqd=='en' or QQ8pvXNcBfVkP5rRJ7o=='IFILM-ENGLISH':
		LCO9XdUASxDbuWRrzyjKN34TqMfp = 'Search in site'
		u2jARE57amCQSwZLkiO9qzrg1P = 'Series - Current'
		WUj71fhxld3rqONpBzmEuC = 'Series - Latest'
		kU8rztvRXfE590OMuP6 = 'Series - Alphabet'
		DdJvyxS5pVo90 = 'Live iFilm channel'
		yKFBiUMt3YevqPd = 'Movies'
		GifCYu7XRJLAPNw = 'Music'
		yBbmMvxPFA5976SQtO = 'Shows'
	elif Z39mxoGwr0QWVKB2chSIqd in ['fa','fa2']:
		LCO9XdUASxDbuWRrzyjKN34TqMfp = 'جستجو در سایت'
		u2jARE57amCQSwZLkiO9qzrg1P = 'سريال - جاری'
		WUj71fhxld3rqONpBzmEuC = 'سريال - آخرین'
		kU8rztvRXfE590OMuP6 = 'سريال - الفبا'
		DdJvyxS5pVo90 = 'پخش زنده اي فيلم'
		yKFBiUMt3YevqPd = 'فيلم'
		GifCYu7XRJLAPNw = 'موسيقى'
		yBbmMvxPFA5976SQtO = 'برنامه ها'
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+LCO9XdUASxDbuWRrzyjKN34TqMfp,lGitcTywSI0YK1N,29,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'_REMEMBERRESULTS_')
	MQtuaShrKTbdZFJ5nsR7D('live',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+DdJvyxS5pVo90,lGitcTywSI0YK1N,27)
	MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+' ===== ===== ===== '+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999)
	XsMYjhI4QHz0yJ3OBqvW = ['Series','Program','Music']
	jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(Q49IsrlSuYRAVbGKhwdckLDOetF2PZ,lGitcTywSI0YK1N+'/home',b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'IFILM-MENU-1st')
	ZV5rRvabhxJ=YYBlm36zd0Jst18LXwo4.findall('button-menu(.*?)/Contact',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)">(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
			if any(Y8aiFZsLKw in pcA1dzy7LXwGfMPg9mTkuh5tine3 for Y8aiFZsLKw in XsMYjhI4QHz0yJ3OBqvW):
				url = lGitcTywSI0YK1N+pcA1dzy7LXwGfMPg9mTkuh5tine3
				if 'Series' in pcA1dzy7LXwGfMPg9mTkuh5tine3:
					MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+u2jARE57amCQSwZLkiO9qzrg1P,url,22,b8Qe150xVaJsnDSv,'100')
					MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+WUj71fhxld3rqONpBzmEuC,url,22,b8Qe150xVaJsnDSv,'101')
					MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+kU8rztvRXfE590OMuP6,url,22,b8Qe150xVaJsnDSv,'201')
				elif 'Film' in pcA1dzy7LXwGfMPg9mTkuh5tine3: MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+yKFBiUMt3YevqPd,url,22,b8Qe150xVaJsnDSv,'100')
				elif 'Music' in pcA1dzy7LXwGfMPg9mTkuh5tine3: MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+GifCYu7XRJLAPNw,url,25,b8Qe150xVaJsnDSv,'101')
				elif 'Program' in pcA1dzy7LXwGfMPg9mTkuh5tine3: MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+yBbmMvxPFA5976SQtO,url,22,b8Qe150xVaJsnDSv,'101')
	return jLtdbeYiQHnf4SpU2MTly
def IIarLlWP57qkNd(url):
	lGitcTywSI0YK1N = pNshVZDwTFS4yWdxq7(url)
	jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(Q49IsrlSuYRAVbGKhwdckLDOetF2PZ,url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'IFILM-MUSIC_MENU-1st')
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('Music-tools-header(.*?)Music-body',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
	title = YYBlm36zd0Jst18LXwo4.findall('<p>(.*?)</p>',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)[0]
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,url,22,b8Qe150xVaJsnDSv,'101')
	items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)">(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = lGitcTywSI0YK1N + pcA1dzy7LXwGfMPg9mTkuh5tine3
		MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,23,b8Qe150xVaJsnDSv,'101')
	return
def Je4TwC30iOG5DLKWAtbYvhs(url,NGQDwOCXx1BZmd9Huc):
	lGitcTywSI0YK1N = pNshVZDwTFS4yWdxq7(url)
	Z39mxoGwr0QWVKB2chSIqd = o4Zn1YEgkixa2PXldwqJ3FsjB7(url)
	type = url.split('/')[-1]
	WUFYnvEMJzSOkArTV72 = str(int(NGQDwOCXx1BZmd9Huc)//100)
	NGQDwOCXx1BZmd9Huc = str(int(NGQDwOCXx1BZmd9Huc)%100)
	if type=='Series' and NGQDwOCXx1BZmd9Huc=='0':
		jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(GMkNL1RXxKFentp0Zh9d,url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'IFILM-TITLES-1st')
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('serial-body(.*?)class="row',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)".*?src=(.*?)>.*?h3>(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,lvtGpMZHb9,title in items:
			title = ggtn0PzV7aMe(title)
			title = pTP49ckGDYrofa2KxenumbH0(title)
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = lGitcTywSI0YK1N + pcA1dzy7LXwGfMPg9mTkuh5tine3
			lvtGpMZHb9 = lGitcTywSI0YK1N + HHbaVYqFRy6v0c(lvtGpMZHb9)
			MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,23,lvtGpMZHb9,WUFYnvEMJzSOkArTV72+'01')
	KdCf3JEAnSmxgBepTXrIk2NMF=0
	if type=='Series': Z8s0Lov2UiWF1qGjO='3'
	if type=='Film': Z8s0Lov2UiWF1qGjO='5'
	if type=='Program': Z8s0Lov2UiWF1qGjO='7'
	if type in ['Series','Program','Film'] and NGQDwOCXx1BZmd9Huc!='0':
		MUJCtfYVBLODrFbaZn = lGitcTywSI0YK1N+'/Home/PageingItem?category='+Z8s0Lov2UiWF1qGjO+'&page='+NGQDwOCXx1BZmd9Huc+'&size=30&orderby='+WUFYnvEMJzSOkArTV72
		jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(GMkNL1RXxKFentp0Zh9d,MUJCtfYVBLODrFbaZn,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'IFILM-TITLES-2nd')
		items = YYBlm36zd0Jst18LXwo4.findall('"Id":(.*?),"Title":(.*?),.+?"ImageAddress_S":"(.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		for id,title,lvtGpMZHb9 in items:
			title = ggtn0PzV7aMe(title)
			title = title.replace('\\',b8Qe150xVaJsnDSv)
			title = title.replace('"',b8Qe150xVaJsnDSv)
			KdCf3JEAnSmxgBepTXrIk2NMF += 1
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = lGitcTywSI0YK1N + '/' + type + '/Content/' + id
			lvtGpMZHb9 = lGitcTywSI0YK1N + HHbaVYqFRy6v0c(lvtGpMZHb9)
			if type=='Film': MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,24,lvtGpMZHb9,WUFYnvEMJzSOkArTV72+'01')
			else: MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,23,lvtGpMZHb9,WUFYnvEMJzSOkArTV72+'01')
	if type=='Music':
		jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(GMkNL1RXxKFentp0Zh9d,lGitcTywSI0YK1N+'/Music/Index?page='+NGQDwOCXx1BZmd9Huc,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'IFILM-TITLES-3rd')
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('pagination-demo(.*?)pagination-demo',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)".*?src="(.*?)".*?<h3>(.*?)</h3>',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,lvtGpMZHb9,title in items:
			KdCf3JEAnSmxgBepTXrIk2NMF += 1
			lvtGpMZHb9 = lGitcTywSI0YK1N + lvtGpMZHb9
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = lGitcTywSI0YK1N + pcA1dzy7LXwGfMPg9mTkuh5tine3
			MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,23,lvtGpMZHb9,'101')
	if KdCf3JEAnSmxgBepTXrIk2NMF>20:
		title='صفحة '
		if Z39mxoGwr0QWVKB2chSIqd=='en': title = 'Page '
		if Z39mxoGwr0QWVKB2chSIqd=='fa': title = 'صفحه '
		if Z39mxoGwr0QWVKB2chSIqd=='fa2': title = 'صفحه '
		for m91jT0JuBKDLbQqxy6pA4 in range(1,11) :
			if not NGQDwOCXx1BZmd9Huc==str(m91jT0JuBKDLbQqxy6pA4):
				SFZiMN0Jhv9yBaxzC6wtK2 = '0'+str(m91jT0JuBKDLbQqxy6pA4)
				MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title+str(m91jT0JuBKDLbQqxy6pA4),url,22,b8Qe150xVaJsnDSv,WUFYnvEMJzSOkArTV72+SFZiMN0Jhv9yBaxzC6wtK2[-2:])
	return
def bIpskeGhBlqH(url,NGQDwOCXx1BZmd9Huc):
	if not NGQDwOCXx1BZmd9Huc: NGQDwOCXx1BZmd9Huc = 0
	lGitcTywSI0YK1N = pNshVZDwTFS4yWdxq7(url)
	EXkDIZP8nlteMQ4oFfLxuJYy03VHr = pNshVZDwTFS4yWdxq7(url)
	Z39mxoGwr0QWVKB2chSIqd = o4Zn1YEgkixa2PXldwqJ3FsjB7(url)
	GGYbRJxlHWKpQ2ihCD = url.split('/')
	id,type = GGYbRJxlHWKpQ2ihCD[-1],GGYbRJxlHWKpQ2ihCD[3]
	WUFYnvEMJzSOkArTV72 = str(int(NGQDwOCXx1BZmd9Huc)//100)
	NGQDwOCXx1BZmd9Huc = str(int(NGQDwOCXx1BZmd9Huc)%100)
	KdCf3JEAnSmxgBepTXrIk2NMF = 0
	if type=='Series':
		jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(GMkNL1RXxKFentp0Zh9d,url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'IFILM-EPISODES-1st')
		items = YYBlm36zd0Jst18LXwo4.findall('Comment_panel_Item.*?p>(.*?)<i.+?var inter_ = (.*?);.*?src="(.*?)\'.*?data-url="(.*?)\'',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		title = ' - الحلقة '
		if Z39mxoGwr0QWVKB2chSIqd=='en': title = ' - Episode '
		if Z39mxoGwr0QWVKB2chSIqd=='fa': title = ' - قسمت '
		if Z39mxoGwr0QWVKB2chSIqd=='fa2': title = ' - قسمت '
		if Z39mxoGwr0QWVKB2chSIqd=='fa': dSjB5GzM9NWsvTHuayA0he = b8Qe150xVaJsnDSv
		else: dSjB5GzM9NWsvTHuayA0he = Z39mxoGwr0QWVKB2chSIqd
		J4JFHyCnYTV = YYBlm36zd0Jst18LXwo4.findall('data-video="(.*?)(\'.*?\'_)(.*?)">',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		for name,count,lvtGpMZHb9,pcA1dzy7LXwGfMPg9mTkuh5tine3 in items:
			for HHr42WSgBjAeU7TkQcVaL6yEJz8PF in range(int(count),0,-1):
				g4gonwbGt8 = lvtGpMZHb9 + dSjB5GzM9NWsvTHuayA0he + id + '/' + str(HHr42WSgBjAeU7TkQcVaL6yEJz8PF) + '.png'
				u2jARE57amCQSwZLkiO9qzrg1P = name + title + str(HHr42WSgBjAeU7TkQcVaL6yEJz8PF)
				u2jARE57amCQSwZLkiO9qzrg1P = pTP49ckGDYrofa2KxenumbH0(u2jARE57amCQSwZLkiO9qzrg1P)
				MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+u2jARE57amCQSwZLkiO9qzrg1P,url,24,g4gonwbGt8,b8Qe150xVaJsnDSv,str(HHr42WSgBjAeU7TkQcVaL6yEJz8PF))
	elif type=='Program':
		MUJCtfYVBLODrFbaZn = lGitcTywSI0YK1N+'/Home/PageingAttachmentItem?id='+str(id)+'&page='+NGQDwOCXx1BZmd9Huc+'&size=30&orderby=1'
		jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(GMkNL1RXxKFentp0Zh9d,MUJCtfYVBLODrFbaZn,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'IFILM-EPISODES-2nd')
		items = YYBlm36zd0Jst18LXwo4.findall('Episode":(.*?),.*?ImageAddress_S":"(.*?)".*?VideoAddress":"(.*?)".*?Discription":"(.*?)".*?Caption":"(.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		title = ' - الحلقة '
		if Z39mxoGwr0QWVKB2chSIqd=='en': title = ' - Episode '
		if Z39mxoGwr0QWVKB2chSIqd=='fa': title = ' - قسمت '
		if Z39mxoGwr0QWVKB2chSIqd=='fa2': title = ' - قسمت '
		for HHr42WSgBjAeU7TkQcVaL6yEJz8PF,lvtGpMZHb9,pcA1dzy7LXwGfMPg9mTkuh5tine3,jHuglF23N5K0y6Qcna4fCPdsB,name in items:
			KdCf3JEAnSmxgBepTXrIk2NMF += 1
			g4gonwbGt8 = EXkDIZP8nlteMQ4oFfLxuJYy03VHr + HHbaVYqFRy6v0c(lvtGpMZHb9)
			name = ggtn0PzV7aMe(name)
			u2jARE57amCQSwZLkiO9qzrg1P = name + title + str(HHr42WSgBjAeU7TkQcVaL6yEJz8PF)
			MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+u2jARE57amCQSwZLkiO9qzrg1P,MUJCtfYVBLODrFbaZn,24,g4gonwbGt8,b8Qe150xVaJsnDSv,str(KdCf3JEAnSmxgBepTXrIk2NMF))
	elif type=='Music':
		if 'Content' in url and 'category' not in url:
			MUJCtfYVBLODrFbaZn = lGitcTywSI0YK1N+'/Music/GetTracksBy?id='+str(id)+'&page='+NGQDwOCXx1BZmd9Huc+'&size=30&type=0'
			jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(GMkNL1RXxKFentp0Zh9d,MUJCtfYVBLODrFbaZn,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'IFILM-EPISODES-3rd')
			items = YYBlm36zd0Jst18LXwo4.findall('ImageAddress_S":"(.*?)".*?VoiceAddress":"(.*?)".*?Caption":"(.*?)","Title":"(.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
			for lvtGpMZHb9,pcA1dzy7LXwGfMPg9mTkuh5tine3,name,title in items:
				KdCf3JEAnSmxgBepTXrIk2NMF += 1
				g4gonwbGt8 = EXkDIZP8nlteMQ4oFfLxuJYy03VHr + HHbaVYqFRy6v0c(lvtGpMZHb9)
				u2jARE57amCQSwZLkiO9qzrg1P = name + ' - ' + title
				u2jARE57amCQSwZLkiO9qzrg1P = u2jARE57amCQSwZLkiO9qzrg1P.strip(pldxivXC5wbTB2O8q)
				u2jARE57amCQSwZLkiO9qzrg1P = ggtn0PzV7aMe(u2jARE57amCQSwZLkiO9qzrg1P)
				MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+u2jARE57amCQSwZLkiO9qzrg1P,MUJCtfYVBLODrFbaZn,24,g4gonwbGt8,b8Qe150xVaJsnDSv,str(KdCf3JEAnSmxgBepTXrIk2NMF))
		elif 'Clips' in url:
			MUJCtfYVBLODrFbaZn = lGitcTywSI0YK1N+'/Music/GetTracksBy?id=0&page='+NGQDwOCXx1BZmd9Huc+'&size=30&type=15'
			jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(GMkNL1RXxKFentp0Zh9d,MUJCtfYVBLODrFbaZn,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'IFILM-EPISODES-4th')
			items = YYBlm36zd0Jst18LXwo4.findall('ImageAddress_S":"(.*?)".*?Caption":"(.*?)".*?VideoAddress":"(.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
			for lvtGpMZHb9,title,pcA1dzy7LXwGfMPg9mTkuh5tine3 in items:
				KdCf3JEAnSmxgBepTXrIk2NMF += 1
				g4gonwbGt8 = EXkDIZP8nlteMQ4oFfLxuJYy03VHr + HHbaVYqFRy6v0c(lvtGpMZHb9)
				u2jARE57amCQSwZLkiO9qzrg1P = title.strip(pldxivXC5wbTB2O8q)
				u2jARE57amCQSwZLkiO9qzrg1P = ggtn0PzV7aMe(u2jARE57amCQSwZLkiO9qzrg1P)
				MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+u2jARE57amCQSwZLkiO9qzrg1P,MUJCtfYVBLODrFbaZn,24,g4gonwbGt8,b8Qe150xVaJsnDSv,str(KdCf3JEAnSmxgBepTXrIk2NMF))
		elif 'category' in url:
			if 'category=6' in url:
				MUJCtfYVBLODrFbaZn = lGitcTywSI0YK1N+'/Music/GetTracksBy?id=0&page='+NGQDwOCXx1BZmd9Huc+'&size=30&type=6'
				jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(GMkNL1RXxKFentp0Zh9d,MUJCtfYVBLODrFbaZn,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'IFILM-EPISODES-5th')
			elif 'category=4' in url:
				MUJCtfYVBLODrFbaZn = lGitcTywSI0YK1N+'/Music/GetTracksBy?id=0&page='+NGQDwOCXx1BZmd9Huc+'&size=30&type=4'
				jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(GMkNL1RXxKFentp0Zh9d,MUJCtfYVBLODrFbaZn,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'IFILM-EPISODES-6th')
			items = YYBlm36zd0Jst18LXwo4.findall('ImageAddress_S":"(.*?)".*?VoiceAddress":"(.*?)".*?Caption":"(.*?)","Title":"(.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
			for lvtGpMZHb9,pcA1dzy7LXwGfMPg9mTkuh5tine3,name,title in items:
				KdCf3JEAnSmxgBepTXrIk2NMF += 1
				g4gonwbGt8 = EXkDIZP8nlteMQ4oFfLxuJYy03VHr + HHbaVYqFRy6v0c(lvtGpMZHb9)
				u2jARE57amCQSwZLkiO9qzrg1P = name + ' - ' + title
				u2jARE57amCQSwZLkiO9qzrg1P = u2jARE57amCQSwZLkiO9qzrg1P.strip(pldxivXC5wbTB2O8q)
				u2jARE57amCQSwZLkiO9qzrg1P = ggtn0PzV7aMe(u2jARE57amCQSwZLkiO9qzrg1P)
				MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+u2jARE57amCQSwZLkiO9qzrg1P,MUJCtfYVBLODrFbaZn,24,g4gonwbGt8,b8Qe150xVaJsnDSv,str(KdCf3JEAnSmxgBepTXrIk2NMF))
	if type=='Music' or type=='Program':
		if KdCf3JEAnSmxgBepTXrIk2NMF>25:
			title='صفحة '
			if Z39mxoGwr0QWVKB2chSIqd=='en': title = ' Page '
			if Z39mxoGwr0QWVKB2chSIqd=='fa': title = ' صفحه '
			if Z39mxoGwr0QWVKB2chSIqd=='fa2': title = ' صفحه '
			for m91jT0JuBKDLbQqxy6pA4 in range(1,11):
				if not NGQDwOCXx1BZmd9Huc==str(m91jT0JuBKDLbQqxy6pA4):
					SFZiMN0Jhv9yBaxzC6wtK2 = '0'+str(m91jT0JuBKDLbQqxy6pA4)
					MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title+str(m91jT0JuBKDLbQqxy6pA4),url,23,b8Qe150xVaJsnDSv,WUFYnvEMJzSOkArTV72+SFZiMN0Jhv9yBaxzC6wtK2[-2:])
	return
def Hkij627uCDJKyIM(url,HHr42WSgBjAeU7TkQcVaL6yEJz8PF):
	EXkDIZP8nlteMQ4oFfLxuJYy03VHr = pNshVZDwTFS4yWdxq7(url)
	uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = [],[]
	jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(GMkNL1RXxKFentp0Zh9d,url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'IFILM-PLAY-1st')
	items = YYBlm36zd0Jst18LXwo4.findall('data-video="(.*?)(\'.*?\'_)(.*?)">',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if items:
		Z39mxoGwr0QWVKB2chSIqd = o4Zn1YEgkixa2PXldwqJ3FsjB7(url)
		GGYbRJxlHWKpQ2ihCD = url.split('/')
		id,type = GGYbRJxlHWKpQ2ihCD[-1],GGYbRJxlHWKpQ2ihCD[3]
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = items[0][0]+Z39mxoGwr0QWVKB2chSIqd+id+'/,'+HHr42WSgBjAeU7TkQcVaL6yEJz8PF+','+HHr42WSgBjAeU7TkQcVaL6yEJz8PF+'_'+items[0][2]
		uuSKUinvP4EGLxWZYmTsF.append('m3u8')
		KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
	items = YYBlm36zd0Jst18LXwo4.findall('data-url="(http.*?)(\'.*?\')(\..*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if items:
		Z39mxoGwr0QWVKB2chSIqd = o4Zn1YEgkixa2PXldwqJ3FsjB7(url)
		GGYbRJxlHWKpQ2ihCD = url.split('/')
		id,type = GGYbRJxlHWKpQ2ihCD[-1],GGYbRJxlHWKpQ2ihCD[3]
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = items[0][0]+Z39mxoGwr0QWVKB2chSIqd+id+'/'+HHr42WSgBjAeU7TkQcVaL6yEJz8PF+items[0][2]
		uuSKUinvP4EGLxWZYmTsF.append('mp4 url')
		KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
	items = YYBlm36zd0Jst18LXwo4.findall('source src="(.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	for pcA1dzy7LXwGfMPg9mTkuh5tine3 in items:
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3.replace('//','/')
		uuSKUinvP4EGLxWZYmTsF.append('mp4 src')
		KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
	items = YYBlm36zd0Jst18LXwo4.findall('VideoAddress":"(.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if items:
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = items[int(HHr42WSgBjAeU7TkQcVaL6yEJz8PF)-1]
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = EXkDIZP8nlteMQ4oFfLxuJYy03VHr+HHbaVYqFRy6v0c(pcA1dzy7LXwGfMPg9mTkuh5tine3)
		uuSKUinvP4EGLxWZYmTsF.append('mp4 address')
		KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
	items = YYBlm36zd0Jst18LXwo4.findall('VoiceAddress":"(.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if items:
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = items[int(HHr42WSgBjAeU7TkQcVaL6yEJz8PF)-1]
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = EXkDIZP8nlteMQ4oFfLxuJYy03VHr+HHbaVYqFRy6v0c(pcA1dzy7LXwGfMPg9mTkuh5tine3)
		uuSKUinvP4EGLxWZYmTsF.append('mp3 address')
		KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
	if len(KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j)==1: pcA1dzy7LXwGfMPg9mTkuh5tine3 = KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j[0]
	else:
		cMZGTsAR2E = XXprCMzuNP2mElUxfdA('اختر الفيديو المناسب:', uuSKUinvP4EGLxWZYmTsF)
		if cMZGTsAR2E == -1 : return
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j[cMZGTsAR2E]
	yulQjIFbzM(pcA1dzy7LXwGfMPg9mTkuh5tine3,QQ8pvXNcBfVkP5rRJ7o,'video')
	return
def pNshVZDwTFS4yWdxq7(url):
	if wQjs1XZ3AO24g8y9bEeoKMiGIu7 in url: TFAmLfwypkzsP1UYCMr8c = wQjs1XZ3AO24g8y9bEeoKMiGIu7
	elif RRtlZAxNcPqnOHgzLY7ude5rBXGToK in url: TFAmLfwypkzsP1UYCMr8c = RRtlZAxNcPqnOHgzLY7ude5rBXGToK
	elif ssLvF98DfYKnzAh7dTkuw6Zly51 in url: TFAmLfwypkzsP1UYCMr8c = ssLvF98DfYKnzAh7dTkuw6Zly51
	elif tPqKaGfh8mOW in url: TFAmLfwypkzsP1UYCMr8c = tPqKaGfh8mOW
	else: TFAmLfwypkzsP1UYCMr8c = b8Qe150xVaJsnDSv
	return TFAmLfwypkzsP1UYCMr8c
def o4Zn1YEgkixa2PXldwqJ3FsjB7(url):
	if   wQjs1XZ3AO24g8y9bEeoKMiGIu7 in url: Z39mxoGwr0QWVKB2chSIqd = 'ar'
	elif RRtlZAxNcPqnOHgzLY7ude5rBXGToK in url: Z39mxoGwr0QWVKB2chSIqd = 'en'
	elif ssLvF98DfYKnzAh7dTkuw6Zly51 in url: Z39mxoGwr0QWVKB2chSIqd = 'fa'
	elif tPqKaGfh8mOW in url: Z39mxoGwr0QWVKB2chSIqd = 'fa2'
	else: Z39mxoGwr0QWVKB2chSIqd = b8Qe150xVaJsnDSv
	return Z39mxoGwr0QWVKB2chSIqd
def vtqABUEyi7jeLRWSkV5b8KpMH(url):
	Z39mxoGwr0QWVKB2chSIqd = o4Zn1YEgkixa2PXldwqJ3FsjB7(url)
	MUJCtfYVBLODrFbaZn = url + '/Home/Live'
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(Q49IsrlSuYRAVbGKhwdckLDOetF2PZ,'GET',MUJCtfYVBLODrFbaZn,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'IFILM-LIVE-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	items = YYBlm36zd0Jst18LXwo4.findall('source src="(.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	GSh0nJxEXgZjd48u7mBwWOeafyAp5b = items[0]
	yulQjIFbzM(GSh0nJxEXgZjd48u7mBwWOeafyAp5b,QQ8pvXNcBfVkP5rRJ7o,'live')
	return
def kstJfK6jHQWrXDSMRIGB7(search):
	search,v7Rxw52Z4X0,showDialogs = JimhUH0SEf6w(search)
	if not search:
		search = FT2oXWtPQpVGuexmLqKN3srdzYn()
		if not search: return
	LgXO1RhbDV7cx6EaeYCNm4zjJdBS = search.replace(pldxivXC5wbTB2O8q,'+')
	if showDialogs:
		WrRF4UXtDz = [ wQjs1XZ3AO24g8y9bEeoKMiGIu7 , RRtlZAxNcPqnOHgzLY7ude5rBXGToK , ssLvF98DfYKnzAh7dTkuw6Zly51 , tPqKaGfh8mOW ]
		ss5a84IOvBGKTCZPwtj = [ 'عربي' , 'English' , 'فارسى' , 'فارسى 2' ]
		cMZGTsAR2E = XXprCMzuNP2mElUxfdA('اختر اللغة المناسبة:', ss5a84IOvBGKTCZPwtj)
		if cMZGTsAR2E == -1 : return
		website = WrRF4UXtDz[cMZGTsAR2E]
	else:
		if '_IFILM-ARABIC_' in v7Rxw52Z4X0: website = wQjs1XZ3AO24g8y9bEeoKMiGIu7
		elif '_IFILM-ENGLISH_' in v7Rxw52Z4X0: website = RRtlZAxNcPqnOHgzLY7ude5rBXGToK
		else: website = b8Qe150xVaJsnDSv
	if not website: return
	Z39mxoGwr0QWVKB2chSIqd = o4Zn1YEgkixa2PXldwqJ3FsjB7(website)
	MUJCtfYVBLODrFbaZn = website + "/Home/Search?searchstring=" + LgXO1RhbDV7cx6EaeYCNm4zjJdBS
	jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(GMkNL1RXxKFentp0Zh9d,MUJCtfYVBLODrFbaZn,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'IFILM-SEARCH-1st')
	items = YYBlm36zd0Jst18LXwo4.findall('"ImageAddress_S":"(.*?)".*?"CategoryId":(.*?),"Id":(.*?),"Title":"(.*?)",',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if items:
		for lvtGpMZHb9,Z8s0Lov2UiWF1qGjO,id,title in items:
			if Z8s0Lov2UiWF1qGjO in ['3','7']:
				title = title.replace('\\',b8Qe150xVaJsnDSv)
				title = title.replace('"',b8Qe150xVaJsnDSv)
				if Z8s0Lov2UiWF1qGjO=='3':
					type = 'Series'
					if Z39mxoGwr0QWVKB2chSIqd=='ar': name = 'مسلسل : '
					elif Z39mxoGwr0QWVKB2chSIqd=='en': name = 'Series : '
					elif Z39mxoGwr0QWVKB2chSIqd=='fa': name = 'سريال ها : '
					elif Z39mxoGwr0QWVKB2chSIqd=='fa2': name = 'سريال ها : '
				elif Z8s0Lov2UiWF1qGjO=='5':
					type = 'Film'
					if Z39mxoGwr0QWVKB2chSIqd=='ar': name = 'فيلم : '
					elif Z39mxoGwr0QWVKB2chSIqd=='en': name = 'Movie : '
					elif Z39mxoGwr0QWVKB2chSIqd=='fa': name = 'فيلم : '
					elif Z39mxoGwr0QWVKB2chSIqd=='fa2': name = 'فلم ها : '
				elif Z8s0Lov2UiWF1qGjO=='7':
					type = 'Program'
					if Z39mxoGwr0QWVKB2chSIqd=='ar': name = 'برنامج : '
					elif Z39mxoGwr0QWVKB2chSIqd=='en': name = 'Program : '
					elif Z39mxoGwr0QWVKB2chSIqd=='fa': name = 'برنامه ها : '
					elif Z39mxoGwr0QWVKB2chSIqd=='fa2': name = 'برنامه ها : '
				title = name + title
				pcA1dzy7LXwGfMPg9mTkuh5tine3 = website + '/' + type + '/Content/' + id
				lvtGpMZHb9 = HHbaVYqFRy6v0c(lvtGpMZHb9)
				lvtGpMZHb9 = website+lvtGpMZHb9
				MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,23,lvtGpMZHb9,'101')
	return
# -*- coding: utf-8 -*-
from hIVCFnfxSO import *
QQ8pvXNcBfVkP5rRJ7o = 'SHOOFMAX'
WbzmKSZiuOYrBN7oysJ2dUv = '_SHM_'
wQjs1XZ3AO24g8y9bEeoKMiGIu7 = nTHXJIiah2qK[QQ8pvXNcBfVkP5rRJ7o][0]
RRtlZAxNcPqnOHgzLY7ude5rBXGToK = nTHXJIiah2qK[QQ8pvXNcBfVkP5rRJ7o][1]
ssLvF98DfYKnzAh7dTkuw6Zly51 = nTHXJIiah2qK[QQ8pvXNcBfVkP5rRJ7o][2]
def x8IFqMZeJj7suCR4AaGoNXfEHm(mode,url,text):
	if   mode==50: XXxlOLJ9KRjPH382WVCvr6n71 = Y72YmLgw4vqlHxTCkbeKSicasD()
	elif mode==51: XXxlOLJ9KRjPH382WVCvr6n71 = Je4TwC30iOG5DLKWAtbYvhs(url)
	elif mode==52: XXxlOLJ9KRjPH382WVCvr6n71 = bIpskeGhBlqH(url)
	elif mode==53: XXxlOLJ9KRjPH382WVCvr6n71 = Hkij627uCDJKyIM(url)
	elif mode==55: XXxlOLJ9KRjPH382WVCvr6n71 = y0QRta6dxGYh3ON4oiBCU2frgFZ()
	elif mode==56: XXxlOLJ9KRjPH382WVCvr6n71 = wJdGaWmjEqBAHvRkx3ZPCUech5Qz4L()
	elif mode==57: XXxlOLJ9KRjPH382WVCvr6n71 = yyRapzN1OPXEC47GAVrUjo3TwfutW(url,1)
	elif mode==58: XXxlOLJ9KRjPH382WVCvr6n71 = yyRapzN1OPXEC47GAVrUjo3TwfutW(url,2)
	elif mode==59: XXxlOLJ9KRjPH382WVCvr6n71 = kstJfK6jHQWrXDSMRIGB7(text)
	else: XXxlOLJ9KRjPH382WVCvr6n71 = False
	return XXxlOLJ9KRjPH382WVCvr6n71
def Y72YmLgw4vqlHxTCkbeKSicasD():
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'بحث في الموقع',b8Qe150xVaJsnDSv,59,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'_REMEMBERRESULTS_')
	MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+' ===== ===== ===== '+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999)
	MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+'المسلسلات',b8Qe150xVaJsnDSv,56)
	MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+'الافلام',b8Qe150xVaJsnDSv,55)
	return b8Qe150xVaJsnDSv
def y0QRta6dxGYh3ON4oiBCU2frgFZ():
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'أفلام مرتبة بسنة الإنتاج',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/movie/1/yop',57)
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'أفلام مرتبة بالأفضل تقييم',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/movie/1/review',57)
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'أفلام مرتبة بالأكثر مشاهدة',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/movie/1/views',57)
	return
def wJdGaWmjEqBAHvRkx3ZPCUech5Qz4L():
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'مسلسلات مرتبة بسنة الإنتاج',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/series/1/yop',57)
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'مسلسلات مرتبة بالأفضل تقييم',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/series/1/review',57)
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'مسلسلات مرتبة بالأكثر مشاهدة',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/series/1/views',57)
	return
def Je4TwC30iOG5DLKWAtbYvhs(url):
	if '?' in url:
		GGYbRJxlHWKpQ2ihCD = url.split('?')
		url = GGYbRJxlHWKpQ2ihCD[0]
		filter = '?' + HHbaVYqFRy6v0c(GGYbRJxlHWKpQ2ihCD[1],'=&:/%')
	else: filter = b8Qe150xVaJsnDSv
	type,NGQDwOCXx1BZmd9Huc,sort = url.split('/')[-3:]
	if sort in ['yop','review','views']:
		if type=='movie': oYe8RpT3jO17qBKDLkZd2gCJ='فيلم'
		elif type=='series': oYe8RpT3jO17qBKDLkZd2gCJ='مسلسل'
		url = wQjs1XZ3AO24g8y9bEeoKMiGIu7 + '/genre/filter/' + HHbaVYqFRy6v0c(oYe8RpT3jO17qBKDLkZd2gCJ) + '/' + NGQDwOCXx1BZmd9Huc + '/' + sort + filter
		jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(GMkNL1RXxKFentp0Zh9d,url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'SHOOFMAX-TITLES-1st')
		items = YYBlm36zd0Jst18LXwo4.findall('"pid":(.*?),.*?"ptitle":"(.*?)".+?"pepisodes":(.*?),"presbase":"(.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		KdCf3JEAnSmxgBepTXrIk2NMF=0
		for id,title,qqG0TxZaNe5Ad,lvtGpMZHb9 in items:
			KdCf3JEAnSmxgBepTXrIk2NMF += 1
			lvtGpMZHb9 = ssLvF98DfYKnzAh7dTkuw6Zly51 + '/v2/img/program/main/' + lvtGpMZHb9 + '-2.jpg'
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = wQjs1XZ3AO24g8y9bEeoKMiGIu7 + '/program/' + id
			if type=='movie': MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,53,lvtGpMZHb9)
			if type=='series': MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'مسلسل '+title,pcA1dzy7LXwGfMPg9mTkuh5tine3+'?ep='+qqG0TxZaNe5Ad+'='+title+'='+lvtGpMZHb9,52,lvtGpMZHb9)
	else:
		if type=='movie': oYe8RpT3jO17qBKDLkZd2gCJ='movies'
		elif type=='series': oYe8RpT3jO17qBKDLkZd2gCJ='series'
		url = RRtlZAxNcPqnOHgzLY7ude5rBXGToK + '/json/selected/' + sort + '-' + oYe8RpT3jO17qBKDLkZd2gCJ + '-WW.json'
		jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(GMkNL1RXxKFentp0Zh9d,url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'SHOOFMAX-TITLES-2nd')
		items = YYBlm36zd0Jst18LXwo4.findall('"ref":(.*?),"ep":(.*?),"base":"(.*?)","title":"(.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		KdCf3JEAnSmxgBepTXrIk2NMF=0
		for id,qqG0TxZaNe5Ad,lvtGpMZHb9,title in items:
			KdCf3JEAnSmxgBepTXrIk2NMF += 1
			lvtGpMZHb9 = RRtlZAxNcPqnOHgzLY7ude5rBXGToK + '/img/program/' + lvtGpMZHb9 + '-2.jpg'
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = wQjs1XZ3AO24g8y9bEeoKMiGIu7 + '/program/' + id
			if type=='movie': MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,53,lvtGpMZHb9)
			elif type=='series': MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'مسلسل '+title,pcA1dzy7LXwGfMPg9mTkuh5tine3+'?ep='+qqG0TxZaNe5Ad+'='+title+'='+lvtGpMZHb9,52,lvtGpMZHb9)
	title='صفحة '
	if KdCf3JEAnSmxgBepTXrIk2NMF==16:
		for m91jT0JuBKDLbQqxy6pA4 in range(1,13) :
			if not NGQDwOCXx1BZmd9Huc==str(m91jT0JuBKDLbQqxy6pA4):
				url = wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/genre/filter/'+type+'/'+str(m91jT0JuBKDLbQqxy6pA4)+'/'+sort+filter
				MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title+str(m91jT0JuBKDLbQqxy6pA4),url,51)
	return
def bIpskeGhBlqH(url):
	GGYbRJxlHWKpQ2ihCD = url.split('=')
	qqG0TxZaNe5Ad = int(GGYbRJxlHWKpQ2ihCD[1])
	name = SgrGWuAHcLKBQMJetb9(GGYbRJxlHWKpQ2ihCD[2])
	name = name.replace('_MOD_مسلسل ',b8Qe150xVaJsnDSv)
	lvtGpMZHb9 = GGYbRJxlHWKpQ2ihCD[3]
	url = url.split('?')[0]
	if qqG0TxZaNe5Ad==0:
		jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(GMkNL1RXxKFentp0Zh9d,url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'SHOOFMAX-EPISODES-1st')
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('<select(.*?)</select>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		items = YYBlm36zd0Jst18LXwo4.findall('option value="(.*?)"',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		qqG0TxZaNe5Ad = int(items[-1])
	for HHr42WSgBjAeU7TkQcVaL6yEJz8PF in range(qqG0TxZaNe5Ad,0,-1):
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = url + '?ep=' + str(HHr42WSgBjAeU7TkQcVaL6yEJz8PF)
		title = '_MOD_مسلسل '+name+' - الحلقة '+str(HHr42WSgBjAeU7TkQcVaL6yEJz8PF)
		MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,53,lvtGpMZHb9)
	return
def Hkij627uCDJKyIM(url):
	jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(Q49IsrlSuYRAVbGKhwdckLDOetF2PZ,url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'SHOOFMAX-PLAY-1st')
	fm9H6wVqjrW1yQO35RUNaZdMcTbkp = YYBlm36zd0Jst18LXwo4.findall('متوفر على شوف ماكس بعد.*?moment\("(.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if fm9H6wVqjrW1yQO35RUNaZdMcTbkp:
		wLQCTr5lqbsVYeAHdzfhZ1F = fm9H6wVqjrW1yQO35RUNaZdMcTbkp[1].replace('T',eiopkn4y9uWDQ5)
		tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'رسالة من الموقع الأصلي','هذا الفيديو سيكون متوفر على شوف ماكس بعد هذا الوقت'+eeN6dTEnkJxI+wLQCTr5lqbsVYeAHdzfhZ1F)
		return
	skgaNbEytdDLlKJWpz2OTm4,IqB3iplnm1PCrNYQkfTydX = [],[]
	BSpUrsbWxEjh8Ick3Cn2z = YYBlm36zd0Jst18LXwo4.findall('var origin_link = "(.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)[0]
	QLKOV3BeA1NTbw2XM4jfaF8rdnEtW = YYBlm36zd0Jst18LXwo4.findall('var backup_origin_link = "(.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)[0]
	tzdvaEpMHOCZLXDYg08T = YYBlm36zd0Jst18LXwo4.findall('hls: (.*?)_link\+"(.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	for LLOCdZ3sS2enzXx4fVB18YRvbHNwky,pcA1dzy7LXwGfMPg9mTkuh5tine3 in tzdvaEpMHOCZLXDYg08T:
		if 'backup' in LLOCdZ3sS2enzXx4fVB18YRvbHNwky:
			LLOCdZ3sS2enzXx4fVB18YRvbHNwky = 'backup server'
			url = QLKOV3BeA1NTbw2XM4jfaF8rdnEtW + pcA1dzy7LXwGfMPg9mTkuh5tine3
		else:
			LLOCdZ3sS2enzXx4fVB18YRvbHNwky = 'main server'
			url = BSpUrsbWxEjh8Ick3Cn2z + pcA1dzy7LXwGfMPg9mTkuh5tine3
		if '.m3u8' in url:
			skgaNbEytdDLlKJWpz2OTm4.append(url)
			IqB3iplnm1PCrNYQkfTydX.append('m3u8  '+LLOCdZ3sS2enzXx4fVB18YRvbHNwky)
	tzdvaEpMHOCZLXDYg08T = YYBlm36zd0Jst18LXwo4.findall('mp4:.*?_link.*?\t(.*?)_link\+"(.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	tzdvaEpMHOCZLXDYg08T += YYBlm36zd0Jst18LXwo4.findall('mp4:.*?\t(.*?)_link\+"(.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	for LLOCdZ3sS2enzXx4fVB18YRvbHNwky,pcA1dzy7LXwGfMPg9mTkuh5tine3 in tzdvaEpMHOCZLXDYg08T:
		filename = pcA1dzy7LXwGfMPg9mTkuh5tine3.split('/')[-1]
		filename = filename.replace('fallback',b8Qe150xVaJsnDSv)
		filename = filename.replace('.mp4',b8Qe150xVaJsnDSv)
		filename = filename.replace('-',b8Qe150xVaJsnDSv)
		if 'backup' in LLOCdZ3sS2enzXx4fVB18YRvbHNwky:
			LLOCdZ3sS2enzXx4fVB18YRvbHNwky = 'backup server'
			url = QLKOV3BeA1NTbw2XM4jfaF8rdnEtW + pcA1dzy7LXwGfMPg9mTkuh5tine3
		else:
			LLOCdZ3sS2enzXx4fVB18YRvbHNwky = 'main server'
			url = BSpUrsbWxEjh8Ick3Cn2z + pcA1dzy7LXwGfMPg9mTkuh5tine3
		skgaNbEytdDLlKJWpz2OTm4.append(url)
		IqB3iplnm1PCrNYQkfTydX.append('mp4  '+LLOCdZ3sS2enzXx4fVB18YRvbHNwky+k5bCDErUSmv+filename)
	cMZGTsAR2E = XXprCMzuNP2mElUxfdA('Select Video Quality:', IqB3iplnm1PCrNYQkfTydX)
	if cMZGTsAR2E == -1 : return
	url = skgaNbEytdDLlKJWpz2OTm4[cMZGTsAR2E]
	yulQjIFbzM(url,QQ8pvXNcBfVkP5rRJ7o,'video')
	return
def yyRapzN1OPXEC47GAVrUjo3TwfutW(url,type):
	if 'series' in url: MUJCtfYVBLODrFbaZn = wQjs1XZ3AO24g8y9bEeoKMiGIu7 + '/genre/مسلسل'
	else: MUJCtfYVBLODrFbaZn = wQjs1XZ3AO24g8y9bEeoKMiGIu7 + '/genre/فيلم'
	MUJCtfYVBLODrFbaZn = HHbaVYqFRy6v0c(MUJCtfYVBLODrFbaZn)
	jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(Q49IsrlSuYRAVbGKhwdckLDOetF2PZ,MUJCtfYVBLODrFbaZn,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'SHOOFMAX-FILTERS-1st')
	if type==1: ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('subgenre(.*?)div',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	elif type==2: ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('country(.*?)div',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
	items = YYBlm36zd0Jst18LXwo4.findall('option value="(.*?)">(.*?)</option',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	if type==1:
		for cc6Cx7MFmBagP4WGKq052d,title in items:
			MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,url+'?subgenre='+cc6Cx7MFmBagP4WGKq052d,58)
	elif type==2:
		url,cc6Cx7MFmBagP4WGKq052d = url.split('?')
		for dHf3gSt5yWFKhPjZRN16iqeoc7O,title in items:
			MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,url+'?country='+dHf3gSt5yWFKhPjZRN16iqeoc7O+'&'+cc6Cx7MFmBagP4WGKq052d,51)
	return
def kstJfK6jHQWrXDSMRIGB7(search):
	search,v7Rxw52Z4X0,showDialogs = JimhUH0SEf6w(search)
	if not search: search = FT2oXWtPQpVGuexmLqKN3srdzYn()
	if not search: return
	LgXO1RhbDV7cx6EaeYCNm4zjJdBS = search.replace(pldxivXC5wbTB2O8q,'%20')
	url = wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/search?q='+LgXO1RhbDV7cx6EaeYCNm4zjJdBS
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,True,b8Qe150xVaJsnDSv,'SHOOFMAX-SEARCH-2nd')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('general-body(.*?)search-bottom-padding',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
	items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)".*?background-image: url\((.*?)\).*?<span>(.*?)</span>',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	if items:
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,lvtGpMZHb9,title in items:
			url = wQjs1XZ3AO24g8y9bEeoKMiGIu7 + pcA1dzy7LXwGfMPg9mTkuh5tine3
			if '/program/' in url:
				if '?ep=' in url:
					title = '_MOD_مسلسل '+title
					url = url.replace('?ep=1','?ep=0')
					url = url+'='+HHbaVYqFRy6v0c(title)+'='+lvtGpMZHb9
					MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,url,52,lvtGpMZHb9)
				else:
					title = '_MOD_فيلم '+title
					MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+title,url,53,lvtGpMZHb9)
	return
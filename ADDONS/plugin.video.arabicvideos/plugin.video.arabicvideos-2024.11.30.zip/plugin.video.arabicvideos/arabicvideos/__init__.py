# -*- coding: utf-8 -*-
import sys as Pft6y0LvwSh48iYg7b
MQBw2uYHcWbpxF8tKAV = Pft6y0LvwSh48iYg7b.version_info [0] == 2
myc93k4htNU67 = 2048
h8lCkw1d3LepDVuvfoicEXj5K6sPz = 7
def JanmRV2MtcH (VwngrDb8fEytv4kMTdQu95cIejsC):
	global oPFYqewitzj
	WBrAFcJPVXdS2UzxLEGM0omkD = ord (VwngrDb8fEytv4kMTdQu95cIejsC [-1])
	V13jmfpwhlcyCKMRLY5TiaG = VwngrDb8fEytv4kMTdQu95cIejsC [:-1]
	gyF4Uq9l1NQKCtT = WBrAFcJPVXdS2UzxLEGM0omkD % len (V13jmfpwhlcyCKMRLY5TiaG)
	BN5pdqozP2v9Ur1Swsia = V13jmfpwhlcyCKMRLY5TiaG [:gyF4Uq9l1NQKCtT] + V13jmfpwhlcyCKMRLY5TiaG [gyF4Uq9l1NQKCtT:]
	if MQBw2uYHcWbpxF8tKAV:
		D3MGYw1ceHQ4UbrNJSq = unicode () .join ([unichr (ord (bb1FgjciZqDzeQTBC2hplaPkmRIyUf) - myc93k4htNU67 - (Ni5bJjhpks6SfCc + WBrAFcJPVXdS2UzxLEGM0omkD) % h8lCkw1d3LepDVuvfoicEXj5K6sPz) for Ni5bJjhpks6SfCc, bb1FgjciZqDzeQTBC2hplaPkmRIyUf in enumerate (BN5pdqozP2v9Ur1Swsia)])
	else:
		D3MGYw1ceHQ4UbrNJSq = str () .join ([chr (ord (bb1FgjciZqDzeQTBC2hplaPkmRIyUf) - myc93k4htNU67 - (Ni5bJjhpks6SfCc + WBrAFcJPVXdS2UzxLEGM0omkD) % h8lCkw1d3LepDVuvfoicEXj5K6sPz) for Ni5bJjhpks6SfCc, bb1FgjciZqDzeQTBC2hplaPkmRIyUf in enumerate (BN5pdqozP2v9Ur1Swsia)])
	return eval (D3MGYw1ceHQ4UbrNJSq)
TYf7Dc06PQgy1vEV9,ubxGUTt1LraKhVZgpAP,Y2t8baH5GWikvOZ7NsCeq3TKrgMV=JanmRV2MtcH,JanmRV2MtcH,JanmRV2MtcH
BWNPxIG7vqdTy85pjHzUOrK3,Mmpr0o76iWJvz1kTtfgI8hES,QTUBCcehw6qPd4x=Y2t8baH5GWikvOZ7NsCeq3TKrgMV,ubxGUTt1LraKhVZgpAP,TYf7Dc06PQgy1vEV9
mQNonhS7CV2BXOv,HwB7ydlWVJeCtPuQ6MDE1RTYOo,uVQd103XyvUce2EBtzbYaC=QTUBCcehw6qPd4x,Mmpr0o76iWJvz1kTtfgI8hES,BWNPxIG7vqdTy85pjHzUOrK3
yST5AHEfvPmcWpwGuh2BJ,BmePGjS7FxK6kutUM,S0IlDPhBN3gMEUvnjRLXsYAc2Zf=uVQd103XyvUce2EBtzbYaC,HwB7ydlWVJeCtPuQ6MDE1RTYOo,mQNonhS7CV2BXOv
Xz3bA2PFENVCUtplu51,LAQD5wEkr18bUiGaYen3J,P0qdZI384LKleuo=S0IlDPhBN3gMEUvnjRLXsYAc2Zf,BmePGjS7FxK6kutUM,yST5AHEfvPmcWpwGuh2BJ
shC5qBRV2A0lZ,mmcNLrXtzfpyCkZlvK5VwG2gujh,m6hwdgP31a2zjN7lkpX=P0qdZI384LKleuo,LAQD5wEkr18bUiGaYen3J,Xz3bA2PFENVCUtplu51
IjZbnrBJmM2N,Nh0BWuiSndf,kke1PDGRBLuY8y=m6hwdgP31a2zjN7lkpX,mmcNLrXtzfpyCkZlvK5VwG2gujh,shC5qBRV2A0lZ
ddo23ZJtgcY,vvWwO3Tx2dAgcijrFXq,DYakr9g4PVU=kke1PDGRBLuY8y,Nh0BWuiSndf,IjZbnrBJmM2N
zI3ROAZtiUq42rE9WDST68,Dzs8qU2gQMcCSyRhiZn4TFbeGk,dDYUoKi6JFM23p=DYakr9g4PVU,vvWwO3Tx2dAgcijrFXq,ddo23ZJtgcY
QQdAXWBc2GPw,VFjQx6Is28KvzLOmMXtg4GqTwa3,TT8Mxv5Wq7nlC9IscdpPUY6=dDYUoKi6JFM23p,Dzs8qU2gQMcCSyRhiZn4TFbeGk,zI3ROAZtiUq42rE9WDST68
SbjiWeHLQPoazqwp3cODkd7YxVgn,UUkIBz1sgQ9WfNeG6trKXvu0,RRIHDFjoW9w7bSfVPhC=TT8Mxv5Wq7nlC9IscdpPUY6,VFjQx6Is28KvzLOmMXtg4GqTwa3,QQdAXWBc2GPw
from Yf92JP7d13 import *
QQ8pvXNcBfVkP5rRJ7o = TYf7Dc06PQgy1vEV9(u"ࠧࡊࡐࡌࡘࠬሚ")
ghCFeN0fbKHlnrSB = Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠨ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠨማ")
E57WK4m31C8,rlqNUcK9vYgkT,YabJfs3q7yjpzvXioO,Q8ZnJhRz2mINwrY6VPf,I6YPOSofrpnTwRm8b,NGQDwOCXx1BZmd9Huc,vv5M4UfJS9ucKEiNbxtnaOZ,wc0Z9FAdf2B1J,XXra5dzn8tcLOxYZIE7pPof49Hh = rhoGF8ta4UesmTucY6V2O1A(ZqDQCMovyXKFG7ki4BrahuWt1IS8)
zombcuDBIxEeSdOlZq1tsUH4f = int(Q8ZnJhRz2mINwrY6VPf)
okYWP4Hxyb = uuxVm0bTwdnCUAL4s6NKHEBF3M.getInfoLabel(P0qdZI384LKleuo(u"ࠩࡏ࡭ࡸࡺࡉࡵࡧࡰ࠲ࡑࡧࡢࡦ࡮ࠪሜ"))
okYWP4Hxyb = okYWP4Hxyb.replace(W0LQbFfMVG46dKrPzJCmvD,b8Qe150xVaJsnDSv).replace(VfHYrPvolqbxLOd,b8Qe150xVaJsnDSv)
if zombcuDBIxEeSdOlZq1tsUH4f==VFjQx6Is28KvzLOmMXtg4GqTwa3(u"࠷࠼࠰ቂ"): hk4eiopgcfB = zI3ROAZtiUq42rE9WDST68(u"ࠪࠤࠥࠦࡖࡦࡴࡶ࡭ࡴࡴ࠺ࠡ࡝ࠣࠫም")+cpGrK6qnPi+HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠫࠥࡣࠠࠡࠢࡎࡳࡩ࡯࠺ࠡ࡝ࠣࠫሞ")+xsc9o3jWnC5H4+yST5AHEfvPmcWpwGuh2BJ(u"ࠬࠦ࡝ࠨሟ")
else:
	YyFKcSzhGjdRM8Pn = SgrGWuAHcLKBQMJetb9(ZqDQCMovyXKFG7ki4BrahuWt1IS8).replace(rC3Tlno96KjLDIvBaSWUbR8,b8Qe150xVaJsnDSv).replace(OkuB9nwhD8U1,b8Qe150xVaJsnDSv)
	YyFKcSzhGjdRM8Pn = YyFKcSzhGjdRM8Pn.replace(hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv).strip(pldxivXC5wbTB2O8q)
	YyFKcSzhGjdRM8Pn = YyFKcSzhGjdRM8Pn.replace(eiopkn4y9uWDQ5,pldxivXC5wbTB2O8q).replace(R1BKXhzpGH6CoO9jLsPwQWu,pldxivXC5wbTB2O8q).replace(k5bCDErUSmv,pldxivXC5wbTB2O8q)
	hk4eiopgcfB = DYakr9g4PVU(u"࠭ࠠࠡࠢࡏࡥࡧ࡫࡬࠻ࠢ࡞ࠤࠬሠ")+okYWP4Hxyb+TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠧࠡ࡟ࠣࠤࠥࡓ࡯ࡥࡧ࠽ࠤࡠࠦࠧሡ")+Q8ZnJhRz2mINwrY6VPf+QQdAXWBc2GPw(u"ࠨࠢࡠࠤࠥࠦࡐࡢࡶ࡫࠾ࠥࡡࠠࠨሢ")+YyFKcSzhGjdRM8Pn+Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠩࠣࡡࠬሣ")
mwIxD3GBPgLVc2aq9(MtTygrzXFlQ,ghCFeN0fbKHlnrSB+eeN6dTEnkJxI+EECz06teoykrNFfq(QQ8pvXNcBfVkP5rRJ7o)+hk4eiopgcfB)
if Mmpr0o76iWJvz1kTtfgI8hES(u"ࠪࡣࠬሤ") in wc0Z9FAdf2B1J: QJ0qZc2WYEBRu894kiSvT3aUAMtf6,qbzaH87okmFhuPxgJVRDB29 = wc0Z9FAdf2B1J.split(HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠫࡤ࠭ሥ"),vvWwO3Tx2dAgcijrFXq(u"࠷ቃ"))
else: QJ0qZc2WYEBRu894kiSvT3aUAMtf6,qbzaH87okmFhuPxgJVRDB29 = wc0Z9FAdf2B1J,b8Qe150xVaJsnDSv
uqTvH9CQaSkmBM1Dth,yABitW02UXORGEJQPsTujcL = DD5cFIejQa2X4BgAu9GWPyJ3tC7,b8Qe150xVaJsnDSv
if QJ0qZc2WYEBRu894kiSvT3aUAMtf6 in [dDYUoKi6JFM23p(u"ࠬ࠷ࠧሦ"),Mmpr0o76iWJvz1kTtfgI8hES(u"࠭࠲ࠨሧ"),LAQD5wEkr18bUiGaYen3J(u"ࠧ࠴ࠩረ"),TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠨ࠶ࠪሩ"),S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠩ࠸ࠫሪ"),zI3ROAZtiUq42rE9WDST68(u"ࠪ࠵࠶࠭ራ"),Nh0BWuiSndf(u"ࠫ࠶࠸ࠧሬ"),IjZbnrBJmM2N(u"ࠬ࠷࠳ࠨር")] and (uVQd103XyvUce2EBtzbYaC(u"࠭ࡁࡅࡆࠪሮ") in qbzaH87okmFhuPxgJVRDB29 or DYakr9g4PVU(u"ࠧࡓࡇࡐࡓ࡛ࡋࠧሯ") in qbzaH87okmFhuPxgJVRDB29 or Xz3bA2PFENVCUtplu51(u"ࠨࡗࡓࠫሰ") in qbzaH87okmFhuPxgJVRDB29 or mQNonhS7CV2BXOv(u"ࠩࡇࡓ࡜ࡔࠧሱ") in qbzaH87okmFhuPxgJVRDB29):
	from pxDVAc9OnY import L4Uf2PYJbSnDd5NBu
	L4Uf2PYJbSnDd5NBu(wc0Z9FAdf2B1J,QJ0qZc2WYEBRu894kiSvT3aUAMtf6,qbzaH87okmFhuPxgJVRDB29)
	hRWC8YSFvsm4JHOMVIne3jquZ.setSetting(Xz3bA2PFENVCUtplu51(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡲࡦࡨࡵࡩࡸ࡮ࠧሲ"),ZqDQCMovyXKFG7ki4BrahuWt1IS8)
	uqTvH9CQaSkmBM1Dth = CCxMXuNUEzolDZTKrBJ
elif not l1RsIerQAtbJjMTzGEWP2L and zombcuDBIxEeSdOlZq1tsUH4f in [UUkIBz1sgQ9WfNeG6trKXvu0(u"࠲࠴࠷ቄ"),yST5AHEfvPmcWpwGuh2BJ(u"࠸࠳࠸ቅ")]:
	Bm6RlzFt7j10nr395yLAoDuiIaq = str(XXra5dzn8tcLOxYZIE7pPof49Hh[UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫሳ")])
	QQ8pvXNcBfVkP5rRJ7o = shC5qBRV2A0lZ(u"ࠬࡏࡐࡕࡘࠪሴ") if zombcuDBIxEeSdOlZq1tsUH4f==P0qdZI384LKleuo(u"࠴࠶࠹ቆ") else DYakr9g4PVU(u"࠭ࡍ࠴ࡗࠪስ")
	dBnAKsiYLazvmPRWMNo = QQ8pvXNcBfVkP5rRJ7o.lower()
	quhyD5749GRVfBUTCHZ3t2lpXvWx = hRWC8YSFvsm4JHOMVIne3jquZ.getSetting(SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠧࡢࡸ࠱ࠫሶ")+dBnAKsiYLazvmPRWMNo+IjZbnrBJmM2N(u"ࠨ࠰ࡸࡷࡪࡸࡡࡨࡧࡱࡸࡤ࠭ሷ")+Bm6RlzFt7j10nr395yLAoDuiIaq)
	JVrK4ste3qUM9iy2mNIgdXHhcSwQP6 = hRWC8YSFvsm4JHOMVIne3jquZ.getSetting(kke1PDGRBLuY8y(u"ࠩࡤࡺ࠳࠭ሸ")+dBnAKsiYLazvmPRWMNo+S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠪ࠲ࡷ࡫ࡦࡦࡴࡨࡶࡤ࠭ሹ")+Bm6RlzFt7j10nr395yLAoDuiIaq)
	if quhyD5749GRVfBUTCHZ3t2lpXvWx or JVrK4ste3qUM9iy2mNIgdXHhcSwQP6:
		YabJfs3q7yjpzvXioO += mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠫࢁ࠭ሺ")
		if quhyD5749GRVfBUTCHZ3t2lpXvWx: YabJfs3q7yjpzvXioO += Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠬࠬࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࡀࠫሻ")+quhyD5749GRVfBUTCHZ3t2lpXvWx
		if JVrK4ste3qUM9iy2mNIgdXHhcSwQP6: YabJfs3q7yjpzvXioO += QTUBCcehw6qPd4x(u"࠭ࠦࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠩሼ")+JVrK4ste3qUM9iy2mNIgdXHhcSwQP6
		YabJfs3q7yjpzvXioO = YabJfs3q7yjpzvXioO.replace(m6hwdgP31a2zjN7lkpX(u"ࠧࡽࠨࠪሽ"),yST5AHEfvPmcWpwGuh2BJ(u"ࠨࡾࠪሾ"))
	MyKjBu82cFIpod5 = hRWC8YSFvsm4JHOMVIne3jquZ.getSetting(Xz3bA2PFENVCUtplu51(u"ࠩࡤࡺ࠳࠭ሿ")+dBnAKsiYLazvmPRWMNo+ubxGUTt1LraKhVZgpAP(u"ࠪ࠲ࡸ࡫ࡲࡷࡧࡵࡣࠬቀ")+Bm6RlzFt7j10nr395yLAoDuiIaq)
	if MyKjBu82cFIpod5:
		k7gElKqfd6w3M8H95LiG = YYBlm36zd0Jst18LXwo4.findall(ubxGUTt1LraKhVZgpAP(u"ࠫ࠿࠵࠯ࠩ࠰࠭ࡃ࠮࠵ࠧቁ"),YabJfs3q7yjpzvXioO,YYBlm36zd0Jst18LXwo4.DOTALL)
		YabJfs3q7yjpzvXioO = YabJfs3q7yjpzvXioO.replace(k7gElKqfd6w3M8H95LiG[LzYQg91SIxDeOGtCKd5],MyKjBu82cFIpod5)
	yulQjIFbzM(YabJfs3q7yjpzvXioO,QQ8pvXNcBfVkP5rRJ7o,E57WK4m31C8)
else:
	import hIVCFnfxSO
	try: hIVCFnfxSO.wXetdoVAq0ZByn7ukLPONr3U(E57WK4m31C8,rlqNUcK9vYgkT,YabJfs3q7yjpzvXioO,Q8ZnJhRz2mINwrY6VPf,I6YPOSofrpnTwRm8b,NGQDwOCXx1BZmd9Huc,vv5M4UfJS9ucKEiNbxtnaOZ,wc0Z9FAdf2B1J,XXra5dzn8tcLOxYZIE7pPof49Hh,zombcuDBIxEeSdOlZq1tsUH4f,QJ0qZc2WYEBRu894kiSvT3aUAMtf6,qbzaH87okmFhuPxgJVRDB29,okYWP4Hxyb)
	except Exception as DXh6Ta4KnjN: yABitW02UXORGEJQPsTujcL = n9dSEJTBOWlY6.format_exc()
	uqTvH9CQaSkmBM1Dth = hIVCFnfxSO.uqTvH9CQaSkmBM1Dth
NXpaA3f9eE(uqTvH9CQaSkmBM1Dth,yABitW02UXORGEJQPsTujcL)
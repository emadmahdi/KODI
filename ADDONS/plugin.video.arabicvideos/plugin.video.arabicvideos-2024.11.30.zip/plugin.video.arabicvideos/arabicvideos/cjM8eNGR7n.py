# -*- coding: utf-8 -*-
from hIVCFnfxSO import *
QQ8pvXNcBfVkP5rRJ7o = 'SERIES4WATCH'
headers = { 'User-Agent' : b8Qe150xVaJsnDSv }
WbzmKSZiuOYrBN7oysJ2dUv = '_SFW_'
wQjs1XZ3AO24g8y9bEeoKMiGIu7 = nTHXJIiah2qK[QQ8pvXNcBfVkP5rRJ7o][0]
def x8IFqMZeJj7suCR4AaGoNXfEHm(mode,url,text):
	if   mode==210: XXxlOLJ9KRjPH382WVCvr6n71 = Y72YmLgw4vqlHxTCkbeKSicasD()
	elif mode==211: XXxlOLJ9KRjPH382WVCvr6n71 = Je4TwC30iOG5DLKWAtbYvhs(url)
	elif mode==212: XXxlOLJ9KRjPH382WVCvr6n71 = Hkij627uCDJKyIM(url)
	elif mode==213: XXxlOLJ9KRjPH382WVCvr6n71 = bIpskeGhBlqH(url)
	elif mode==214: XXxlOLJ9KRjPH382WVCvr6n71 = bJpw3zT5FrV1DLvOxNBSGZHl(url)
	elif mode==215: XXxlOLJ9KRjPH382WVCvr6n71 = nCkhzlUEsM(url)
	elif mode==218: XXxlOLJ9KRjPH382WVCvr6n71 = FXn01pzGy7isNWxtOoIZSJM2acCudf()
	elif mode==219: XXxlOLJ9KRjPH382WVCvr6n71 = kstJfK6jHQWrXDSMRIGB7(text)
	else: XXxlOLJ9KRjPH382WVCvr6n71 = False
	return XXxlOLJ9KRjPH382WVCvr6n71
def FXn01pzGy7isNWxtOoIZSJM2acCudf():
	message = 'هذا الموقع تغير بالكامل ... وبحاجة الى اعادة برمجة من الصفر ... والمبرمج حاليا مشغول ويعاني من وعكة صحية ... ولهذا سوف يبقى الموقع مغلق الى ما شاء الله'
	tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'رسالة من المبرمج','الموقع تغير بالكامل',message)
	return
def Y72YmLgw4vqlHxTCkbeKSicasD():
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'بحث في الموقع',b8Qe150xVaJsnDSv,219,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'_REMEMBERRESULTS_')
	url = wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/getpostsPin?type=one&data=pin&limit=25'
	MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+'المميزة',url,211)
	jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(Q49IsrlSuYRAVbGKhwdckLDOetF2PZ,wQjs1XZ3AO24g8y9bEeoKMiGIu7,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,'SERIES4WATCH-MENU-1st')
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('FiltersButtons(.*?)</div>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
	items = YYBlm36zd0Jst18LXwo4.findall('data-get="(.*?)".*?</i>(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
		url = wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/getposts?type=one&data='+pcA1dzy7LXwGfMPg9mTkuh5tine3
		MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+title,url,211)
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('navigation-menu(.*?)</div>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
	items = YYBlm36zd0Jst18LXwo4.findall('href="(http.*?)">(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	v1vJEhoNQBVPkjG = ['مسلسلات انمي','الرئيسية']
	for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
		title = title.strip(pldxivXC5wbTB2O8q)
		if not any(Y8aiFZsLKw in title for Y8aiFZsLKw in v1vJEhoNQBVPkjG):
			MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,211)
	return jLtdbeYiQHnf4SpU2MTly
def Je4TwC30iOG5DLKWAtbYvhs(url):
	jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(GMkNL1RXxKFentp0Zh9d,url,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,'SERIES4WATCH-TITLES-1st')
	if 'getposts' in url or '/search?s=' in url: OTKx7aVb2hdS16Wrweky4FXfIN0g9 = jLtdbeYiQHnf4SpU2MTly
	else:
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('MediaGrid"(.*?)class="pagination"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if ZV5rRvabhxJ: OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		else: return
	items = YYBlm36zd0Jst18LXwo4.findall('src="(.*?)".*?href="(.*?)".*?<h3>(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	d3VSIefbHnvqiut = []
	tU9doZbu1l5MOai = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for lvtGpMZHb9,pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
		if '/series/' in pcA1dzy7LXwGfMPg9mTkuh5tine3: continue
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = SgrGWuAHcLKBQMJetb9(pcA1dzy7LXwGfMPg9mTkuh5tine3).strip('/')
		title = pTP49ckGDYrofa2KxenumbH0(title)
		title = title.strip(pldxivXC5wbTB2O8q)
		if '/film/' in pcA1dzy7LXwGfMPg9mTkuh5tine3 or any(Y8aiFZsLKw in title for Y8aiFZsLKw in tU9doZbu1l5MOai):
			MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,212,lvtGpMZHb9)
		elif '/episode/' in pcA1dzy7LXwGfMPg9mTkuh5tine3 and 'الحلقة' in title:
			HHr42WSgBjAeU7TkQcVaL6yEJz8PF = YYBlm36zd0Jst18LXwo4.findall('(.*?) الحلقة \d+',title,YYBlm36zd0Jst18LXwo4.DOTALL)
			if HHr42WSgBjAeU7TkQcVaL6yEJz8PF:
				title = '_MOD_' + HHr42WSgBjAeU7TkQcVaL6yEJz8PF[0]
				if title not in d3VSIefbHnvqiut:
					MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,213,lvtGpMZHb9)
					d3VSIefbHnvqiut.append(title)
		else: MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,213,lvtGpMZHb9)
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('class="pagination(.*?)</div>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		items = YYBlm36zd0Jst18LXwo4.findall('<a href=["\'](http.*?)["\'].*?>(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = pTP49ckGDYrofa2KxenumbH0(pcA1dzy7LXwGfMPg9mTkuh5tine3)
			title = pTP49ckGDYrofa2KxenumbH0(title)
			title = title.replace('الصفحة ',b8Qe150xVaJsnDSv)
			if title!=b8Qe150xVaJsnDSv: MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'صفحة '+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,211)
	return
def bIpskeGhBlqH(url):
	my5NaxQ4YRl,items,SqlabXdx6T8zU = -1,[],[]
	jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(GMkNL1RXxKFentp0Zh9d,url,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,'SERIES4WATCH-EPISODES-1st')
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('ti-list-numbered(.*?)</div>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ:
		JQjNkD10xehK8bXUalY3EgZAVmvI = b8Qe150xVaJsnDSv.join(ZV5rRvabhxJ)
		items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)"',JQjNkD10xehK8bXUalY3EgZAVmvI,YYBlm36zd0Jst18LXwo4.DOTALL)
	items.append(url)
	items = set(items)
	for pcA1dzy7LXwGfMPg9mTkuh5tine3 in items:
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3.strip('/')
		title = '_MOD_' + pcA1dzy7LXwGfMPg9mTkuh5tine3.split('/')[-1].replace('-',pldxivXC5wbTB2O8q)
		sWCftVuO3gyXJ1UK4T = YYBlm36zd0Jst18LXwo4.findall('الحلقة-(\d+)',pcA1dzy7LXwGfMPg9mTkuh5tine3.split('/')[-1],YYBlm36zd0Jst18LXwo4.DOTALL)
		if sWCftVuO3gyXJ1UK4T: sWCftVuO3gyXJ1UK4T = sWCftVuO3gyXJ1UK4T[0]
		else: sWCftVuO3gyXJ1UK4T = '0'
		SqlabXdx6T8zU.append([pcA1dzy7LXwGfMPg9mTkuh5tine3,title,sWCftVuO3gyXJ1UK4T])
	items = sorted(SqlabXdx6T8zU, reverse=False, key=lambda key: int(key[2]))
	rL9bMuwBVE7OJaG2UNQg0tAXRSW = str(items).count('/season/')
	my5NaxQ4YRl = str(items).count('/episode/')
	if rL9bMuwBVE7OJaG2UNQg0tAXRSW>1 and my5NaxQ4YRl>0 and '/season/' not in url:
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,title,sWCftVuO3gyXJ1UK4T in items:
			if '/season/' in pcA1dzy7LXwGfMPg9mTkuh5tine3: MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,213)
	else:
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,title,sWCftVuO3gyXJ1UK4T in items:
			if '/season/' not in pcA1dzy7LXwGfMPg9mTkuh5tine3: MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,212)
	return
def Hkij627uCDJKyIM(url):
	KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = []
	GGYbRJxlHWKpQ2ihCD = url.split('/')
	jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(Q49IsrlSuYRAVbGKhwdckLDOetF2PZ,url,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,'SERIES4WATCH-PLAY-1st')
	if '/watch/' in jLtdbeYiQHnf4SpU2MTly:
		MUJCtfYVBLODrFbaZn = url.replace(GGYbRJxlHWKpQ2ihCD[3],'watch')
		vWsMIpk1n6rlLqH52 = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(Q49IsrlSuYRAVbGKhwdckLDOetF2PZ,MUJCtfYVBLODrFbaZn,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,'SERIES4WATCH-PLAY-2nd')
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('class="servers-list(.*?)</div>',vWsMIpk1n6rlLqH52,YYBlm36zd0Jst18LXwo4.DOTALL)
		if ZV5rRvabhxJ:
			OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
			items = YYBlm36zd0Jst18LXwo4.findall('data-embedd="(.*?)".*?server_image">\n(.*?)\n',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
			if items:
				id = YYBlm36zd0Jst18LXwo4.findall('post_id=(.*?)"',vWsMIpk1n6rlLqH52,YYBlm36zd0Jst18LXwo4.DOTALL)
				if id:
					MLBDXlxEbU9WJQImfHOnK3zpvdR = id[0]
					for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
						pcA1dzy7LXwGfMPg9mTkuh5tine3 = wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/?postid='+MLBDXlxEbU9WJQImfHOnK3zpvdR+'&serverid='+pcA1dzy7LXwGfMPg9mTkuh5tine3+'?named='+title+'__watch'
						KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
			else:
				items = YYBlm36zd0Jst18LXwo4.findall('data-embedd=".*?(http.*?)("|&quot;)',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
				for pcA1dzy7LXwGfMPg9mTkuh5tine3,jprAaOYCD6yM8P5VZXK1B2ldNbuR in items:
					KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
	if '/download/' in jLtdbeYiQHnf4SpU2MTly:
		MUJCtfYVBLODrFbaZn = url.replace(GGYbRJxlHWKpQ2ihCD[3],'download')
		vWsMIpk1n6rlLqH52 = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(Q49IsrlSuYRAVbGKhwdckLDOetF2PZ,MUJCtfYVBLODrFbaZn,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,'SERIES4WATCH-PLAY-3rd')
		id = YYBlm36zd0Jst18LXwo4.findall('postId:"(.*?)"',vWsMIpk1n6rlLqH52,YYBlm36zd0Jst18LXwo4.DOTALL)
		if id:
			MLBDXlxEbU9WJQImfHOnK3zpvdR = id[0]
			ybF0H85nUohsiRQcpaTfZAKzjMY7wB = { 'User-Agent':b8Qe150xVaJsnDSv , 'X-Requested-With':'XMLHttpRequest' }
			MUJCtfYVBLODrFbaZn = wQjs1XZ3AO24g8y9bEeoKMiGIu7 + '/ajaxCenter?_action=getdownloadlinks&postId='+MLBDXlxEbU9WJQImfHOnK3zpvdR
			vWsMIpk1n6rlLqH52 = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(Q49IsrlSuYRAVbGKhwdckLDOetF2PZ,MUJCtfYVBLODrFbaZn,b8Qe150xVaJsnDSv,ybF0H85nUohsiRQcpaTfZAKzjMY7wB,b8Qe150xVaJsnDSv,'SERIES4WATCH-PLAY-4th')
			ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('<h3.*?(\d+)(.*?)</div>',vWsMIpk1n6rlLqH52,YYBlm36zd0Jst18LXwo4.DOTALL)
			if ZV5rRvabhxJ:
				for rA6gtZN7RJfP,OTKx7aVb2hdS16Wrweky4FXfIN0g9 in ZV5rRvabhxJ:
					items = YYBlm36zd0Jst18LXwo4.findall('<td>(.*?)<.*?href="(.*?)"',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
					for name,pcA1dzy7LXwGfMPg9mTkuh5tine3 in items:
						KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j.append(pcA1dzy7LXwGfMPg9mTkuh5tine3+'?named='+name+'__download'+'____'+rA6gtZN7RJfP)
			else:
				ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('<h6(.*?)</table>',vWsMIpk1n6rlLqH52,YYBlm36zd0Jst18LXwo4.DOTALL)
				if not ZV5rRvabhxJ: ZV5rRvabhxJ = [vWsMIpk1n6rlLqH52]
				for OTKx7aVb2hdS16Wrweky4FXfIN0g9 in ZV5rRvabhxJ:
					name = b8Qe150xVaJsnDSv
					items = YYBlm36zd0Jst18LXwo4.findall('href="(http.*?)"',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
					for pcA1dzy7LXwGfMPg9mTkuh5tine3 in items:
						LLOCdZ3sS2enzXx4fVB18YRvbHNwky = '&&' + pcA1dzy7LXwGfMPg9mTkuh5tine3.split('/')[2].lower() + '&&'
						LLOCdZ3sS2enzXx4fVB18YRvbHNwky = LLOCdZ3sS2enzXx4fVB18YRvbHNwky.replace('.com&&',b8Qe150xVaJsnDSv).replace('.co&&',b8Qe150xVaJsnDSv)
						LLOCdZ3sS2enzXx4fVB18YRvbHNwky = LLOCdZ3sS2enzXx4fVB18YRvbHNwky.replace('.net&&',b8Qe150xVaJsnDSv).replace('.org&&',b8Qe150xVaJsnDSv)
						LLOCdZ3sS2enzXx4fVB18YRvbHNwky = LLOCdZ3sS2enzXx4fVB18YRvbHNwky.replace('.live&&',b8Qe150xVaJsnDSv).replace('.online&&',b8Qe150xVaJsnDSv)
						LLOCdZ3sS2enzXx4fVB18YRvbHNwky = LLOCdZ3sS2enzXx4fVB18YRvbHNwky.replace('&&hd.',b8Qe150xVaJsnDSv).replace('&&www.',b8Qe150xVaJsnDSv)
						LLOCdZ3sS2enzXx4fVB18YRvbHNwky = LLOCdZ3sS2enzXx4fVB18YRvbHNwky.replace('&&',b8Qe150xVaJsnDSv)
						pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3 + '?named=' + name + LLOCdZ3sS2enzXx4fVB18YRvbHNwky + '__download'
						KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
	import QNeGEq8sWn
	QNeGEq8sWn.nqu2GCT9gHAbpIPSFZz5(KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j,QQ8pvXNcBfVkP5rRJ7o,'video',url)
	return
def kstJfK6jHQWrXDSMRIGB7(search):
	search,v7Rxw52Z4X0,showDialogs = JimhUH0SEf6w(search)
	if search==b8Qe150xVaJsnDSv: search = FT2oXWtPQpVGuexmLqKN3srdzYn()
	if search==b8Qe150xVaJsnDSv: return
	search = search.replace(pldxivXC5wbTB2O8q,'+')
	url = wQjs1XZ3AO24g8y9bEeoKMiGIu7 + '/search?s='+search
	Je4TwC30iOG5DLKWAtbYvhs(url)
	return
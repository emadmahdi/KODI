# -*- coding: utf-8 -*-
import sys as Pft6y0LvwSh48iYg7b
MQBw2uYHcWbpxF8tKAV = Pft6y0LvwSh48iYg7b.version_info [0] == 2
myc93k4htNU67 = 2048
h8lCkw1d3LepDVuvfoicEXj5K6sPz = 7
def JanmRV2MtcH (VwngrDb8fEytv4kMTdQu95cIejsC):
	global oPFYqewitzj
	WBrAFcJPVXdS2UzxLEGM0omkD = ord (VwngrDb8fEytv4kMTdQu95cIejsC [-1])
	V13jmfpwhlcyCKMRLY5TiaG = VwngrDb8fEytv4kMTdQu95cIejsC [:-1]
	gyF4Uq9l1NQKCtT = WBrAFcJPVXdS2UzxLEGM0omkD % len (V13jmfpwhlcyCKMRLY5TiaG)
	BN5pdqozP2v9Ur1Swsia = V13jmfpwhlcyCKMRLY5TiaG [:gyF4Uq9l1NQKCtT] + V13jmfpwhlcyCKMRLY5TiaG [gyF4Uq9l1NQKCtT:]
	if MQBw2uYHcWbpxF8tKAV:
		D3MGYw1ceHQ4UbrNJSq = unicode () .join ([unichr (ord (bb1FgjciZqDzeQTBC2hplaPkmRIyUf) - myc93k4htNU67 - (Ni5bJjhpks6SfCc + WBrAFcJPVXdS2UzxLEGM0omkD) % h8lCkw1d3LepDVuvfoicEXj5K6sPz) for Ni5bJjhpks6SfCc, bb1FgjciZqDzeQTBC2hplaPkmRIyUf in enumerate (BN5pdqozP2v9Ur1Swsia)])
	else:
		D3MGYw1ceHQ4UbrNJSq = str () .join ([chr (ord (bb1FgjciZqDzeQTBC2hplaPkmRIyUf) - myc93k4htNU67 - (Ni5bJjhpks6SfCc + WBrAFcJPVXdS2UzxLEGM0omkD) % h8lCkw1d3LepDVuvfoicEXj5K6sPz) for Ni5bJjhpks6SfCc, bb1FgjciZqDzeQTBC2hplaPkmRIyUf in enumerate (BN5pdqozP2v9Ur1Swsia)])
	return eval (D3MGYw1ceHQ4UbrNJSq)
TYf7Dc06PQgy1vEV9,ubxGUTt1LraKhVZgpAP,Y2t8baH5GWikvOZ7NsCeq3TKrgMV=JanmRV2MtcH,JanmRV2MtcH,JanmRV2MtcH
BWNPxIG7vqdTy85pjHzUOrK3,Mmpr0o76iWJvz1kTtfgI8hES,QTUBCcehw6qPd4x=Y2t8baH5GWikvOZ7NsCeq3TKrgMV,ubxGUTt1LraKhVZgpAP,TYf7Dc06PQgy1vEV9
mQNonhS7CV2BXOv,HwB7ydlWVJeCtPuQ6MDE1RTYOo,uVQd103XyvUce2EBtzbYaC=QTUBCcehw6qPd4x,Mmpr0o76iWJvz1kTtfgI8hES,BWNPxIG7vqdTy85pjHzUOrK3
yST5AHEfvPmcWpwGuh2BJ,BmePGjS7FxK6kutUM,S0IlDPhBN3gMEUvnjRLXsYAc2Zf=uVQd103XyvUce2EBtzbYaC,HwB7ydlWVJeCtPuQ6MDE1RTYOo,mQNonhS7CV2BXOv
Xz3bA2PFENVCUtplu51,LAQD5wEkr18bUiGaYen3J,P0qdZI384LKleuo=S0IlDPhBN3gMEUvnjRLXsYAc2Zf,BmePGjS7FxK6kutUM,yST5AHEfvPmcWpwGuh2BJ
shC5qBRV2A0lZ,mmcNLrXtzfpyCkZlvK5VwG2gujh,m6hwdgP31a2zjN7lkpX=P0qdZI384LKleuo,LAQD5wEkr18bUiGaYen3J,Xz3bA2PFENVCUtplu51
IjZbnrBJmM2N,Nh0BWuiSndf,kke1PDGRBLuY8y=m6hwdgP31a2zjN7lkpX,mmcNLrXtzfpyCkZlvK5VwG2gujh,shC5qBRV2A0lZ
ddo23ZJtgcY,vvWwO3Tx2dAgcijrFXq,DYakr9g4PVU=kke1PDGRBLuY8y,Nh0BWuiSndf,IjZbnrBJmM2N
zI3ROAZtiUq42rE9WDST68,Dzs8qU2gQMcCSyRhiZn4TFbeGk,dDYUoKi6JFM23p=DYakr9g4PVU,vvWwO3Tx2dAgcijrFXq,ddo23ZJtgcY
QQdAXWBc2GPw,VFjQx6Is28KvzLOmMXtg4GqTwa3,TT8Mxv5Wq7nlC9IscdpPUY6=dDYUoKi6JFM23p,Dzs8qU2gQMcCSyRhiZn4TFbeGk,zI3ROAZtiUq42rE9WDST68
SbjiWeHLQPoazqwp3cODkd7YxVgn,UUkIBz1sgQ9WfNeG6trKXvu0,RRIHDFjoW9w7bSfVPhC=TT8Mxv5Wq7nlC9IscdpPUY6,VFjQx6Is28KvzLOmMXtg4GqTwa3,QQdAXWBc2GPw
from hIVCFnfxSO import *
QQ8pvXNcBfVkP5rRJ7o = QQdAXWBc2GPw(u"ࠫࡉࡕࡗࡏࡎࡒࡅࡉ࠭ࢡ")
def x8IFqMZeJj7suCR4AaGoNXfEHm(ZZtDTHnBXMz,uuNDjbit4hOpx):
	if   ZZtDTHnBXMz==ubxGUTt1LraKhVZgpAP(u"࠹࠳࠱श"): XXxlOLJ9KRjPH382WVCvr6n71 = pdZ1jcFORt()
	elif ZZtDTHnBXMz==P0qdZI384LKleuo(u"࠳࠴࠳ष"): XXxlOLJ9KRjPH382WVCvr6n71 = Hkij627uCDJKyIM(uuNDjbit4hOpx)
	elif ZZtDTHnBXMz==BWNPxIG7vqdTy85pjHzUOrK3(u"࠴࠵࠵स"): XXxlOLJ9KRjPH382WVCvr6n71 = jrHqc5IPizwvgTQEA2UJCYxLG3()
	elif ZZtDTHnBXMz==QQdAXWBc2GPw(u"࠵࠶࠷ह"): XXxlOLJ9KRjPH382WVCvr6n71 = RqTn8pJBIZt7hgdHXGoEOKDmYc3U1()
	else: XXxlOLJ9KRjPH382WVCvr6n71 = DD5cFIejQa2X4BgAu9GWPyJ3tC7
	return XXxlOLJ9KRjPH382WVCvr6n71
def Hkij627uCDJKyIM(uuNDjbit4hOpx):
	yulQjIFbzM(uuNDjbit4hOpx,QQ8pvXNcBfVkP5rRJ7o,ubxGUTt1LraKhVZgpAP(u"ࠬࡼࡩࡥࡧࡲࠫࢢ"))
	return
def RqTn8pJBIZt7hgdHXGoEOKDmYc3U1():
	A4gdSTQDP2FyBIVuba85RvYqKU = uVQd103XyvUce2EBtzbYaC(u"࠭รั้หࠤส๊้ࠡำสฬ฼ࠦวๅใํำ๏๎ࠠฤ๊ࠣห้฻่หࠢไ๎ࠥอไๆ๊ๅ฽ࠥอไๆู็์อࠦหๆࠢฦฺ฿฽ฺࠠๆ์ࠤืืࠠศๆๅหห๋ษࠡษ็๎๊๐ๆࠡอ่ࠤศิสศำࠣࠦฯำๅ๋ๆ้้ࠣ็วหࠢไ๎ิ๐่ࠣࠢฮ้ࠥอฮหษิࠤิ่ษࠡษ็ูํืษ๊ࠡสาฯอั่๋ࠡ฽๋ࠥไโࠢสฺ่๎ัส๋ࠢฬ฾ี็ศࠢึ์ๆ๊ࠦษัฦࠤฬ๊สฮ็ํ่ࠬࢣ")
	tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,P0qdZI384LKleuo(u"ุࠧำํๆฮࠦสฮ็ํ่ࠥอไๆๆไหฯ࠭ࢤ"),A4gdSTQDP2FyBIVuba85RvYqKU)
	return
def pdZ1jcFORt():
	MQtuaShrKTbdZFJ5nsR7D(shC5qBRV2A0lZ(u"ࠨ࡮࡬ࡲࡰ࠭ࢥ"),rC3Tlno96KjLDIvBaSWUbR8+TT8Mxv5Wq7nlC9IscdpPUY6(u"ฺࠩี๏่ษࠡฬะ้๏๊ࠠๆๆไหฯࠦวๅใํำ๏๎ࠧࢦ")+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,zI3ROAZtiUq42rE9WDST68(u"࠶࠷࠸ऺ"))
	MQtuaShrKTbdZFJ5nsR7D(uVQd103XyvUce2EBtzbYaC(u"ࠪࡰ࡮ࡴ࡫ࠨࢧ"),rC3Tlno96KjLDIvBaSWUbR8+UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠫฯเ๊๋ำ้่ࠣอๆࠡฬะ้๏๊ࠠศๆไ๎ิ๐่่ษอࠫࢨ")+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,IjZbnrBJmM2N(u"࠷࠸࠸ऻ"))
	MQtuaShrKTbdZFJ5nsR7D(zI3ROAZtiUq42rE9WDST68(u"ࠬࡲࡩ࡯࡭ࠪࢩ"),rC3Tlno96KjLDIvBaSWUbR8+Xz3bA2PFENVCUtplu51(u"࠭ࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࠬࢪ")+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,QTUBCcehw6qPd4x(u"࠾࠿࠹࠺़"))
	BVaT7dbG9ihYvckAf3 = O86aeIsQ5cSUB4fDwNtTbCgljzZ1()
	aI4GESHfgiDUz2wXehJmQOPCv8t56W = x76PfMyAp1L2WejkU3.stat(BVaT7dbG9ihYvckAf3).st_mtime
	G4upaV8ed9NfPAc = []
	if i1thmHk7AZquD4cM0fnp62: CJaBO31uA7YPxvFTRjQ89 = x76PfMyAp1L2WejkU3.listdir(BVaT7dbG9ihYvckAf3.encode(OVauxZzLI10vcXT74K))
	else: CJaBO31uA7YPxvFTRjQ89 = x76PfMyAp1L2WejkU3.listdir(BVaT7dbG9ihYvckAf3.decode(OVauxZzLI10vcXT74K))
	for zzIgsTAGUu0wQ8eEKq in CJaBO31uA7YPxvFTRjQ89:
		if i1thmHk7AZquD4cM0fnp62: zzIgsTAGUu0wQ8eEKq = zzIgsTAGUu0wQ8eEKq.decode(OVauxZzLI10vcXT74K)
		if not zzIgsTAGUu0wQ8eEKq.startswith(Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠧࡧ࡫࡯ࡩࡤ࠭ࢫ")): continue
		zO2QyE4Cc6ZvmDfkWK = x76PfMyAp1L2WejkU3.path.join(BVaT7dbG9ihYvckAf3,zzIgsTAGUu0wQ8eEKq)
		aI4GESHfgiDUz2wXehJmQOPCv8t56W = x76PfMyAp1L2WejkU3.path.getmtime(zO2QyE4Cc6ZvmDfkWK)
		G4upaV8ed9NfPAc.append([zzIgsTAGUu0wQ8eEKq,aI4GESHfgiDUz2wXehJmQOPCv8t56W])
	G4upaV8ed9NfPAc = sorted(G4upaV8ed9NfPAc,reverse=CCxMXuNUEzolDZTKrBJ,key=lambda key: key[qHYIWnOZLPkrQU])
	for zzIgsTAGUu0wQ8eEKq,aI4GESHfgiDUz2wXehJmQOPCv8t56W in G4upaV8ed9NfPAc:
		if hDTluNxe7tCwrpqXHzdEcYRfbs:
			try: zzIgsTAGUu0wQ8eEKq = zzIgsTAGUu0wQ8eEKq.decode(OVauxZzLI10vcXT74K)
			except: pass
			zzIgsTAGUu0wQ8eEKq = zzIgsTAGUu0wQ8eEKq.encode(OVauxZzLI10vcXT74K)
		zO2QyE4Cc6ZvmDfkWK = x76PfMyAp1L2WejkU3.path.join(BVaT7dbG9ihYvckAf3,zzIgsTAGUu0wQ8eEKq)
		MQtuaShrKTbdZFJ5nsR7D(Mmpr0o76iWJvz1kTtfgI8hES(u"ࠨࡸ࡬ࡨࡪࡵࠧࢬ"),zzIgsTAGUu0wQ8eEKq,zO2QyE4Cc6ZvmDfkWK,HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"࠹࠳࠲ऽ"))
	return
def O86aeIsQ5cSUB4fDwNtTbCgljzZ1():
	BVaT7dbG9ihYvckAf3 = hRWC8YSFvsm4JHOMVIne3jquZ.getSetting(HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠩࡤࡺ࠳ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠮ࡱࡣࡷ࡬ࠬࢭ"))
	if BVaT7dbG9ihYvckAf3: return BVaT7dbG9ihYvckAf3
	hRWC8YSFvsm4JHOMVIne3jquZ.setSetting(uVQd103XyvUce2EBtzbYaC(u"ࠪࡥࡻ࠴ࡤࡰࡹࡱࡰࡴࡧࡤ࠯ࡲࡤࡸ࡭࠭ࢮ"),vIaQF8hqXeiJERYuD)
	return vIaQF8hqXeiJERYuD
def jrHqc5IPizwvgTQEA2UJCYxLG3():
	BVaT7dbG9ihYvckAf3 = O86aeIsQ5cSUB4fDwNtTbCgljzZ1()
	aatkrzn40HZ6TuvOxQNAYFXLDB = BjMmX1vNrnzSAf(ddo23ZJtgcY(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫࢯ"),b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,LAQD5wEkr18bUiGaYen3J(u"๋ࠬใศ่ࠣฮำุ๊็่่ࠢๆอสࠡษ็ฮา๋๊ๅࠩࢰ"),OkuB9nwhD8U1+BVaT7dbG9ihYvckAf3+hAIp8kmC36T5WFPMSXOwnNbtD+SbjiWeHLQPoazqwp3cODkd7YxVgn(u"࠭࡜࡯࡞ࡱ๋ีอ่๊้่ࠠࠣอๆࠡฬัึ๏์ࠠๆๆไหฯࠦวๅใํำ๏๎ࠠศๆอ๎ࠥะอๆๆ๊หࠥอๆหࠢหหุะฮะษ่ࠤ์ึวࠡษ็ฬึ์วๆฮࠣ࠲ࠥํไࠡฬิ๎ิࠦส฻์ํีࠥอไๆๅส๊ࠥลࠧࢱ"))
	if aatkrzn40HZ6TuvOxQNAYFXLDB==ddo23ZJtgcY(u"࠱ा"):
		tBzJrd1ScZ = o37f6ZQNakWxw4Lg8c9r1BAtm(Xz3bA2PFENVCUtplu51(u"࠴ि"),SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠧๆๅส๊ࠥะอๆ์็ࠤ๊๊แศฬࠣห้็๊ะ์๋ࠫࢲ"),TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠨ࡮ࡲࡧࡦࡲࠧࢳ"),b8Qe150xVaJsnDSv,DD5cFIejQa2X4BgAu9GWPyJ3tC7,CCxMXuNUEzolDZTKrBJ,BVaT7dbG9ihYvckAf3)
		aVwGA2kFY6u4m = BjMmX1vNrnzSAf(mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠩࡦࡩࡳࡺࡥࡳࠩࢴ"),b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,TT8Mxv5Wq7nlC9IscdpPUY6(u"้่ࠪอๆࠡฬัึ๏์ࠠๆๆไหฯࠦวๅฬะ้๏๊ࠧࢵ"),OkuB9nwhD8U1+BVaT7dbG9ihYvckAf3+hAIp8kmC36T5WFPMSXOwnNbtD+S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠫࡡࡴ࡜࡯้ำหࠥํ่ࠡษ็้่อๆࠡษ็ะิ๐ฯࠡๆอาื๐ๆࠡ็็ๅฬะࠠศๆไ๎ิ๐่ࠡษ็ฮ๏ࠦสฮ็็๋ฬࠦว็ฬࠣฬฬูสฯัส้ࠥํะศࠢส่อืๆศ็ฯࠤ࠳ࠦ็ๅࠢอี๏ีࠠศีอาิอๅ่ࠢหำ้อࠠๆ่ࠣห้๋ใศ่ࠣห้่ฯ๋็ࠣรࠬࢶ"))
		if aVwGA2kFY6u4m==Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"࠳ी"):
			hRWC8YSFvsm4JHOMVIne3jquZ.setSetting(SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠬࡧࡶ࠯ࡦࡲࡻࡳࡲ࡯ࡢࡦ࠱ࡴࡦࡺࡨࠨࢷ"),tBzJrd1ScZ)
			tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩࢸ"),VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠧห็ࠣฮ฿๐๊า่ࠢ็ฬ์ࠠหะี๎๋ࠦวๅ็็ๅฬะࠠศๆ่ั๊๊ษࠨࢹ"))
	return
def vXyb5udOTP1gqRjf(uuNDjbit4hOpx,xZds9ITEWatF7Kb=b8Qe150xVaJsnDSv,website=b8Qe150xVaJsnDSv):
	mwIxD3GBPgLVc2aq9(MtTygrzXFlQ,EECz06teoykrNFfq(QQ8pvXNcBfVkP5rRJ7o)+dDYUoKi6JFM23p(u"ࠨࠢࠣࠤࡕࡸࡥࡱࡣࡵ࡭ࡳ࡭ࠠࡵࡱࠣࡨࡴࡽ࡮࡭ࡱࡤࡨࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨࢺ")+uuNDjbit4hOpx+HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠩࠣࡡࠬࢻ"))
	if not xZds9ITEWatF7Kb: xZds9ITEWatF7Kb = Gz7MH0glBw8Eb(uuNDjbit4hOpx)
	BVaT7dbG9ihYvckAf3 = O86aeIsQ5cSUB4fDwNtTbCgljzZ1()
	ZbGDcPgUyw7S0 = RkNASsitM7eYvhqL62FVlfDuZW4x(DD5cFIejQa2X4BgAu9GWPyJ3tC7)
	zzIgsTAGUu0wQ8eEKq = ZbGDcPgUyw7S0.replace(pldxivXC5wbTB2O8q,TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠪࡣࠬࢼ"))
	zzIgsTAGUu0wQ8eEKq = LL1ZqB5WQHbd38JXhNRF(zzIgsTAGUu0wQ8eEKq)
	zzIgsTAGUu0wQ8eEKq = LAQD5wEkr18bUiGaYen3J(u"ࠫ࡫࡯࡬ࡦࡡࠪࢽ")+str(int(T3Axql94cU0BpO1wudEDtWXsf))[-ddo23ZJtgcY(u"࠷ु"):]+Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠬࡥࠧࢾ")+zzIgsTAGUu0wQ8eEKq+xZds9ITEWatF7Kb
	Z401tDY6IygxTRi5oMvsElBkKuj3Nh = x76PfMyAp1L2WejkU3.path.join(BVaT7dbG9ihYvckAf3,zzIgsTAGUu0wQ8eEKq)
	NNB43WbKMVnrktmcsZXUR6wvfJq = {}
	NNB43WbKMVnrktmcsZXUR6wvfJq[HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"࠭ࡁࡤࡥࡨࡴࡹ࠳ࡅ࡯ࡥࡲࡨ࡮ࡴࡧࠨࢿ")] = b8Qe150xVaJsnDSv
	NNB43WbKMVnrktmcsZXUR6wvfJq[uVQd103XyvUce2EBtzbYaC(u"ࠧࡂࡥࡦࡩࡵࡺࠧࣀ")] = S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠨࠬ࠲࠮ࠬࣁ")
	uuNDjbit4hOpx = uuNDjbit4hOpx.replace(uVQd103XyvUce2EBtzbYaC(u"ࠩࡹࡩࡷ࡯ࡦࡺࡲࡨࡩࡷࡃࡦࡢ࡮ࡶࡩࠬࣂ"),b8Qe150xVaJsnDSv)
	if VFjQx6Is28KvzLOmMXtg4GqTwa3(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺ࠽ࠨࣃ") in uuNDjbit4hOpx:
		MUJCtfYVBLODrFbaZn,quhyD5749GRVfBUTCHZ3t2lpXvWx = uuNDjbit4hOpx.rsplit(Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴ࠾ࠩࣄ"),LAQD5wEkr18bUiGaYen3J(u"࠵ू"))
		quhyD5749GRVfBUTCHZ3t2lpXvWx = quhyD5749GRVfBUTCHZ3t2lpXvWx.replace(UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠬࢂࠧࣅ"),b8Qe150xVaJsnDSv).replace(zI3ROAZtiUq42rE9WDST68(u"࠭ࠦࠨࣆ"),b8Qe150xVaJsnDSv)
	else: MUJCtfYVBLODrFbaZn,quhyD5749GRVfBUTCHZ3t2lpXvWx = uuNDjbit4hOpx,None
	if not quhyD5749GRVfBUTCHZ3t2lpXvWx: quhyD5749GRVfBUTCHZ3t2lpXvWx = kIMmsSG9NW6BOjlTpnEcuRzgwK()
	if quhyD5749GRVfBUTCHZ3t2lpXvWx: NNB43WbKMVnrktmcsZXUR6wvfJq[uVQd103XyvUce2EBtzbYaC(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫࣇ")] = quhyD5749GRVfBUTCHZ3t2lpXvWx
	if QTUBCcehw6qPd4x(u"ࠨࡔࡨࡪࡪࡸࡥࡳ࠿ࠪࣈ") in MUJCtfYVBLODrFbaZn: MUJCtfYVBLODrFbaZn,JVrK4ste3qUM9iy2mNIgdXHhcSwQP6 = MUJCtfYVBLODrFbaZn.rsplit(mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࡀࠫࣉ"),uVQd103XyvUce2EBtzbYaC(u"࠶ृ"))
	else: MUJCtfYVBLODrFbaZn,JVrK4ste3qUM9iy2mNIgdXHhcSwQP6 = MUJCtfYVBLODrFbaZn,b8Qe150xVaJsnDSv
	MUJCtfYVBLODrFbaZn = MUJCtfYVBLODrFbaZn.strip(S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠪࢀࠬ࣊")).strip(BmePGjS7FxK6kutUM(u"ࠫࠫ࠭࣋")).strip(VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠬࢂࠧ࣌")).strip(vvWwO3Tx2dAgcijrFXq(u"࠭ࠦࠨ࣍"))
	JVrK4ste3qUM9iy2mNIgdXHhcSwQP6 = JVrK4ste3qUM9iy2mNIgdXHhcSwQP6.replace(TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠧࡽࠩ࣎"),b8Qe150xVaJsnDSv).replace(LAQD5wEkr18bUiGaYen3J(u"ࠨࠨ࣏ࠪ"),b8Qe150xVaJsnDSv)
	if JVrK4ste3qUM9iy2mNIgdXHhcSwQP6:	NNB43WbKMVnrktmcsZXUR6wvfJq[QQdAXWBc2GPw(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴ࣐ࠪ")] = JVrK4ste3qUM9iy2mNIgdXHhcSwQP6
	mwIxD3GBPgLVc2aq9(MtTygrzXFlQ,EECz06teoykrNFfq(QQ8pvXNcBfVkP5rRJ7o)+shC5qBRV2A0lZ(u"ࠪࠤࠥࠦࡄࡰࡹࡱࡰࡴࡧࡤࡪࡰࡪࠤࡻ࡯ࡤࡦࡱࠣࡪ࡮ࡲࡥ࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝࣑ࠣࠫ")+MUJCtfYVBLODrFbaZn+VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠫࠥࡣࠠࠡࠢࡋࡩࡦࡪࡥࡳࡵ࠽ࠤࡠ࣒ࠦࠧ")+str(NNB43WbKMVnrktmcsZXUR6wvfJq)+yST5AHEfvPmcWpwGuh2BJ(u"ࠬࠦ࡝ࠡࠢࠣࡊ࡮ࡲࡥ࠻ࠢ࡞ࠤ࣓ࠬ")+Z401tDY6IygxTRi5oMvsElBkKuj3Nh+Xz3bA2PFENVCUtplu51(u"࠭ࠠ࡞ࠩࣔ"))
	aD3XhMLIHycqN = LAQD5wEkr18bUiGaYen3J(u"࠷࠰࠳࠶ॄ")*LAQD5wEkr18bUiGaYen3J(u"࠷࠰࠳࠶ॄ")
	ldbr4ynCNSQPqxFomAYpEVMzhLG7U = dDYUoKi6JFM23p(u"࠰ॅ")
	try:
		ewmVUJrMAWYG1qFCbsP2Eu =	uuxVm0bTwdnCUAL4s6NKHEBF3M.getInfoLabel(BWNPxIG7vqdTy85pjHzUOrK3(u"ࠧࡔࡻࡶࡸࡪࡳ࠮ࡇࡴࡨࡩࡘࡶࡡࡤࡧࠪࣕ"))
		ewmVUJrMAWYG1qFCbsP2Eu = YYBlm36zd0Jst18LXwo4.findall(BWNPxIG7vqdTy85pjHzUOrK3(u"ࠨ࡞ࡧ࠯ࠬࣖ"),ewmVUJrMAWYG1qFCbsP2Eu)
		ldbr4ynCNSQPqxFomAYpEVMzhLG7U = int(ewmVUJrMAWYG1qFCbsP2Eu[LzYQg91SIxDeOGtCKd5])
	except: pass
	if not ldbr4ynCNSQPqxFomAYpEVMzhLG7U:
		try:
			mBh7uK6bdWYUS = x76PfMyAp1L2WejkU3.statvfs(BVaT7dbG9ihYvckAf3)
			ldbr4ynCNSQPqxFomAYpEVMzhLG7U = mBh7uK6bdWYUS.f_frsize*mBh7uK6bdWYUS.f_bavail//aD3XhMLIHycqN
		except: pass
	if not ldbr4ynCNSQPqxFomAYpEVMzhLG7U:
		try:
			mBh7uK6bdWYUS = x76PfMyAp1L2WejkU3.fstatvfs(BVaT7dbG9ihYvckAf3)
			ldbr4ynCNSQPqxFomAYpEVMzhLG7U = mBh7uK6bdWYUS.f_frsize*mBh7uK6bdWYUS.f_bavail//aD3XhMLIHycqN
		except: pass
	if not ldbr4ynCNSQPqxFomAYpEVMzhLG7U:
		try:
			import shutil as HnfctgClzFpoYMOjm4N9bT
			ZLWoKIJEyx96uf,xx4gF3KHBJjiOrC19I0c5NombdelXa,EEvqLKk5AafeSbOU9jy = HnfctgClzFpoYMOjm4N9bT.disk_usage(BVaT7dbG9ihYvckAf3)
			ldbr4ynCNSQPqxFomAYpEVMzhLG7U = EEvqLKk5AafeSbOU9jy//aD3XhMLIHycqN
		except: pass
	if not ldbr4ynCNSQPqxFomAYpEVMzhLG7U:
		bJvWMFh8G3eas(shC5qBRV2A0lZ(u"ࠩࡵ࡭࡬࡮ࡴࠨࣗ"),BWNPxIG7vqdTy85pjHzUOrK3(u"ุ้ࠪออสࠢส่ฯิา๋่้ࠣัํ่ๅหࠪࣘ"),RRIHDFjoW9w7bSfVPhC(u"้๊ࠫริใࠣห้ฮั็ษ่ะࠥเ๊าࠢๅหิืࠠฤ่ࠣ๎าีฯࠡ็ๅำฬืࠠๆีสัฮࠦวๅฬัึ๏์ࠠศๆไหึเษࠡใํࠤัํวำๅࠣ์฾๊๊่ࠢไห๋ࠦสฮ็ํ่ࠥอไโ์า๎ํํวหࠢ็๊ࠥ๐ูๆๆࠣ฽๋ีใࠡว็ํࠥษๆࠡ์ๅ์๊ࠦๅษำ่ะ๏ࠦศา่ส้ัࠦใ้ัํࠤอำไ้ࠡำ๋ࠥอไๆึๆ่ฮࠦไศ่ࠣฮา๋๊ๅࠢส่ๆ๐ฯ๋๊๊หฯࠦโะࠢํือฮࠠศ็อ่ฬวࠠอ้สึ่ࠦศศๆ่่ๆอส๊๊ࠡิฬࠦแ๋้ࠣา฼๎ัสࠢ฼่๎ูࠦๆๆࠣะ์อาไࠢหูํืษࠡืะ๎าฯ้ࠠๆ๊ิฬࠦวๅีหฬ่ࠥวๆࠢส่๊ฮัๆฮ้ࠣษ่สศࠢห้๋฿ࠠศๆหี๋อๅอ่๊ࠢࠥะอๆ์็ࠤฬ๊แ๋ัํ์์อสࠨࣙ"),TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨࣚ"))
		mwIxD3GBPgLVc2aq9(WG2BfeyzMa,EECz06teoykrNFfq(QQ8pvXNcBfVkP5rRJ7o)+shC5qBRV2A0lZ(u"࠭ࠠࠡࠢࡘࡲࡦࡨ࡬ࡦࠢࡷࡳࠥࡪࡥࡵࡧࡵࡱ࡮ࡴࡥࠡࡶ࡫ࡩࠥࡪࡩࡴ࡭ࠣࡪࡷ࡫ࡥࠡࡵࡳࡥࡨ࡫ࠧࣛ"))
		return DD5cFIejQa2X4BgAu9GWPyJ3tC7
	if xZds9ITEWatF7Kb==UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠧ࠯࡯࠶ࡹ࠽࠭ࣜ"):
		uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = TTO3ZpWq9FCzhuMAY0RdaDIfX5kw(QQ8pvXNcBfVkP5rRJ7o,MUJCtfYVBLODrFbaZn,NNB43WbKMVnrktmcsZXUR6wvfJq)
		if len(uuSKUinvP4EGLxWZYmTsF)==Mmpr0o76iWJvz1kTtfgI8hES(u"࠱ॆ"):
			yicQV3gj4q(mQNonhS7CV2BXOv(u"ࠨใื่ࠥ็๊ࠡวํะฬีࠠๆๆไࠤฬ๊สฮ็ํ่ࠬࣝ"),b8Qe150xVaJsnDSv)
			return DD5cFIejQa2X4BgAu9GWPyJ3tC7
		elif len(uuSKUinvP4EGLxWZYmTsF)==kke1PDGRBLuY8y(u"࠳े"): cMZGTsAR2E = mmcNLrXtzfpyCkZlvK5VwG2gujh(u"࠳ै")
		elif len(uuSKUinvP4EGLxWZYmTsF)>kke1PDGRBLuY8y(u"࠵ॉ"):
			cMZGTsAR2E = XXprCMzuNP2mElUxfdA(IjZbnrBJmM2N(u"ࠩสาฯืࠠศๆ่่ๆࠦวๅ็้หุฮࠧࣞ"), uuSKUinvP4EGLxWZYmTsF)
			if cMZGTsAR2E == -m6hwdgP31a2zjN7lkpX(u"࠶ॊ") :
				yicQV3gj4q(zI3ROAZtiUq42rE9WDST68(u"ࠪฮ๊ࠦลๅ฼สลࠥอไหฯ่๎้࠭ࣟ"),b8Qe150xVaJsnDSv)
				return DD5cFIejQa2X4BgAu9GWPyJ3tC7
		MUJCtfYVBLODrFbaZn = KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j[cMZGTsAR2E]
	UlItCLzoa8 = vvWwO3Tx2dAgcijrFXq(u"࠶ो")
	import requests as gehRtQT6u2cZIrB5m3
	if xZds9ITEWatF7Kb==TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪ࣠"):
		Z401tDY6IygxTRi5oMvsElBkKuj3Nh = Z401tDY6IygxTRi5oMvsElBkKuj3Nh.rsplit(mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠬ࠴࡭࠴ࡷ࠻ࠫ࣡"))[LzYQg91SIxDeOGtCKd5]+DYakr9g4PVU(u"࠭࠮࡮ࡲ࠷ࠫ࣢")
		mJegc5bW2YjVwD = dcLRAZWFzODax2jf0tHCX81pJveNY(LtlXH3fvMydAx,Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠧࡈࡇࡗࣣࠫ"),MUJCtfYVBLODrFbaZn,b8Qe150xVaJsnDSv,NNB43WbKMVnrktmcsZXUR6wvfJq,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,RRIHDFjoW9w7bSfVPhC(u"ࠨࡆࡒ࡛ࡓࡒࡏࡂࡆ࠰ࡈࡔ࡝ࡎࡍࡑࡄࡈࡤ࡜ࡉࡅࡇࡒ࠱࠶ࡹࡴࠨࣤ"))
		BR6qm9eaJXo8 = mJegc5bW2YjVwD.content
		tzdvaEpMHOCZLXDYg08T = YYBlm36zd0Jst18LXwo4.findall(ddo23ZJtgcY(u"ࠩࠦࡉ࡝࡚ࡉࡏࡈ࠽࠲࠯ࡅ࡛࡝ࡰ࡟ࡶࡢ࠮࠮ࠫࡁࠬ࡟ࡡࡴ࡜ࡳ࡟ࠪࣥ"),BR6qm9eaJXo8+zI3ROAZtiUq42rE9WDST68(u"ࠪࡠࡳࡢࡲࠨࣦ"),YYBlm36zd0Jst18LXwo4.DOTALL)
		if not tzdvaEpMHOCZLXDYg08T:
			mwIxD3GBPgLVc2aq9(WG2BfeyzMa,EECz06teoykrNFfq(QQ8pvXNcBfVkP5rRJ7o)+Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠫࠥࠦࠠࡕࡪࡨࠤࡲ࠹ࡵ࠹ࠢࡩ࡭ࡱ࡫ࠠࡥ࡫ࡧࠤࡳࡵࡴࠡࡪࡤࡺࡪࠦࡴࡩࡧࠣࡶࡪࡷࡵࡪࡴࡨࡨࠥࡲࡩ࡯࡭ࡶࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧࣧ")+MUJCtfYVBLODrFbaZn+TYf7Dc06PQgy1vEV9(u"ࠬࠦ࡝ࠨࣨ"))
			return DD5cFIejQa2X4BgAu9GWPyJ3tC7
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = tzdvaEpMHOCZLXDYg08T[LzYQg91SIxDeOGtCKd5]
		if not pcA1dzy7LXwGfMPg9mTkuh5tine3.startswith(P0qdZI384LKleuo(u"࠭ࡨࡵࡶࡳࣩࠫ")):
			if pcA1dzy7LXwGfMPg9mTkuh5tine3.startswith(zI3ROAZtiUq42rE9WDST68(u"ࠧ࠰࠱ࠪ࣪")): pcA1dzy7LXwGfMPg9mTkuh5tine3 = MUJCtfYVBLODrFbaZn.split(P0qdZI384LKleuo(u"ࠨ࠼ࠪ࣫"),VFjQx6Is28KvzLOmMXtg4GqTwa3(u"࠱ौ"))[LzYQg91SIxDeOGtCKd5]+mQNonhS7CV2BXOv(u"ࠩ࠽ࠫ࣬")+pcA1dzy7LXwGfMPg9mTkuh5tine3
			elif pcA1dzy7LXwGfMPg9mTkuh5tine3.startswith(kke1PDGRBLuY8y(u"ࠪ࠳࣭ࠬ")): pcA1dzy7LXwGfMPg9mTkuh5tine3 = Wl2eu1PavfQ(MUJCtfYVBLODrFbaZn,TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠫࡺࡸ࡬ࠨ࣮"))+pcA1dzy7LXwGfMPg9mTkuh5tine3
			else: pcA1dzy7LXwGfMPg9mTkuh5tine3 = MUJCtfYVBLODrFbaZn.rsplit(S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠬ࠵࣯ࠧ"),yST5AHEfvPmcWpwGuh2BJ(u"࠲्"))[LzYQg91SIxDeOGtCKd5]+LAQD5wEkr18bUiGaYen3J(u"࠭࠯ࠨࣰ")+pcA1dzy7LXwGfMPg9mTkuh5tine3
		mJegc5bW2YjVwD = gehRtQT6u2cZIrB5m3.request(zI3ROAZtiUq42rE9WDST68(u"ࠧࡈࡇࡗࣱࠫ"),pcA1dzy7LXwGfMPg9mTkuh5tine3,headers=NNB43WbKMVnrktmcsZXUR6wvfJq,verify=DD5cFIejQa2X4BgAu9GWPyJ3tC7)
		yWcnAUFQ1vz = mJegc5bW2YjVwD.content
		dtbgHLmZcqCjPiRx6QMlfX = len(yWcnAUFQ1vz)
		NeMyKLqFzsAQ9E7rV = len(tzdvaEpMHOCZLXDYg08T)
		UlItCLzoa8 = dtbgHLmZcqCjPiRx6QMlfX*NeMyKLqFzsAQ9E7rV
	else:
		dtbgHLmZcqCjPiRx6QMlfX = QQdAXWBc2GPw(u"࠳ॎ")*aD3XhMLIHycqN
		mJegc5bW2YjVwD = gehRtQT6u2cZIrB5m3.request(BWNPxIG7vqdTy85pjHzUOrK3(u"ࠨࡉࡈࡘࣲࠬ"),MUJCtfYVBLODrFbaZn,headers=NNB43WbKMVnrktmcsZXUR6wvfJq,verify=DD5cFIejQa2X4BgAu9GWPyJ3tC7,stream=CCxMXuNUEzolDZTKrBJ)
		if S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡐࡪࡴࡧࡵࡪࠪࣳ") in mJegc5bW2YjVwD.headers: UlItCLzoa8 = int(mJegc5bW2YjVwD.headers[ddo23ZJtgcY(u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱ࡑ࡫࡮ࡨࡶ࡫ࠫࣴ")])
		NeMyKLqFzsAQ9E7rV = int(UlItCLzoa8//dtbgHLmZcqCjPiRx6QMlfX)
	mkZPXKTJ6dVB0EqlYjNWzx = int(UlItCLzoa8//aD3XhMLIHycqN)+LAQD5wEkr18bUiGaYen3J(u"࠴ॏ")
	if UlItCLzoa8<S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"࠶࠶࠶࠰࠱ॐ"):
		mwIxD3GBPgLVc2aq9(WG2BfeyzMa,EECz06teoykrNFfq(QQ8pvXNcBfVkP5rRJ7o)+QTUBCcehw6qPd4x(u"ࠫࠥࠦࠠࡗ࡫ࡧࡩࡴࠦࡦࡪ࡮ࡨࠤ࡮ࡹࠠࡵࡱࡲࠤࡸࡳࡡ࡭࡮ࠣࡳࡷࠦࡩࡵࠢ࡬ࡷࠥࡳ࠳ࡶ࠺ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭ࣵ")+MUJCtfYVBLODrFbaZn+BWNPxIG7vqdTy85pjHzUOrK3(u"ࠬࠦ࡝࡚ࠡࠢࠣ࡮ࡪࡥࡰࠢࡩ࡭ࡱ࡫ࠠࡴ࡫ࡽࡩ࠿࡛ࣶࠦࠡࠩ")+str(mkZPXKTJ6dVB0EqlYjNWzx)+LAQD5wEkr18bUiGaYen3J(u"࠭ࠠࡎࡄࠣࡡࠥࠦࠠࡂࡸࡤ࡭ࡱࡧࡢ࡭ࡧࠣࡷ࡮ࢀࡥ࠻ࠢ࡞ࠤࠬࣷ")+str(ldbr4ynCNSQPqxFomAYpEVMzhLG7U)+P0qdZI384LKleuo(u"ࠧࠡࡏࡅࠤࡢࠦࠠࠡࡈ࡬ࡰࡪࡀࠠ࡜ࠢࠪࣸ")+Z401tDY6IygxTRi5oMvsElBkKuj3Nh+ubxGUTt1LraKhVZgpAP(u"ࠨࠢࡠࣹࠫ"))
		tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,shC5qBRV2A0lZ(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࣺࠬ"),vvWwO3Tx2dAgcijrFXq(u"ࠪๅู๊ࠠโ์้ࠣ฾ืแสࠢะะ๊ࠦๅๅใࠣห้็๊ะ์๋ࠤศ๎ࠠศๆ่่ๆࠦี฻์ิࠤัีว๊ࠡ็๋ีอࠠๅษࠣ๎๊้ๆࠡๆ็ฬึ์วๆฮࠣฮา๋๊ๅ๊ࠢิฬࠦวๅ็็ๅࠬࣻ"))
		return DD5cFIejQa2X4BgAu9GWPyJ3tC7
	ChoHmKqcvs3GOrMaURtjpnNixT = HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"࠹࠶࠰॑")
	I1sKanz6gcxW70jmESr = ldbr4ynCNSQPqxFomAYpEVMzhLG7U-mkZPXKTJ6dVB0EqlYjNWzx
	if I1sKanz6gcxW70jmESr<ChoHmKqcvs3GOrMaURtjpnNixT:
		mwIxD3GBPgLVc2aq9(WG2BfeyzMa,EECz06teoykrNFfq(QQ8pvXNcBfVkP5rRJ7o)+zI3ROAZtiUq42rE9WDST68(u"ࠫࠥࠦࠠࡏࡱࡷࠤࡪࡴ࡯ࡶࡩ࡫ࠤࡩ࡯ࡳ࡬ࠢࡶࡴࡦࡩࡥࠡࡶࡲࠤࡩࡵࡷ࡯࡮ࡲࡥࡩࠦࡴࡩࡧࠣࡺ࡮ࡪࡥࡰࠢࡩ࡭ࡱ࡫ࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪࣼ")+MUJCtfYVBLODrFbaZn+dDYUoKi6JFM23p(u"ࠬࠦ࡝࡚ࠡࠢࠣ࡮ࡪࡥࡰࠢࡩ࡭ࡱ࡫ࠠࡴ࡫ࡽࡩ࠿࡛ࠦࠡࠩࣽ")+str(mkZPXKTJ6dVB0EqlYjNWzx)+mmcNLrXtzfpyCkZlvK5VwG2gujh(u"࠭ࠠࡎࡄࠣࡡࠥࠦࠠࡂࡸࡤ࡭ࡱࡧࡢ࡭ࡧࠣࡷ࡮ࢀࡥ࠻ࠢ࡞ࠤࠬࣾ")+str(ldbr4ynCNSQPqxFomAYpEVMzhLG7U)+IjZbnrBJmM2N(u"ࠧࠡࡏࡅࠤ࠲ࠦࠧࣿ")+str(ChoHmKqcvs3GOrMaURtjpnNixT)+VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠨࠢࡐࡆࠥࡣࠠࠡࠢࡉ࡭ࡱ࡫࠺ࠡ࡝ࠣࠫऀ")+Z401tDY6IygxTRi5oMvsElBkKuj3Nh+LAQD5wEkr18bUiGaYen3J(u"ࠩࠣࡡࠬँ"))
		tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,LAQD5wEkr18bUiGaYen3J(u"่ࠪฬ๊้ࠦฮาࠤู๊วฮหࠣ็ฬ็๊สࠢ็่ฯำๅ๋ๆࠪं"),VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠫฬ๊ๅๅใࠣห้๋ืๅ๊หࠤฯำๅ๋ๆ๊ࠤาาๅ่ࠢࠪः")+str(mkZPXKTJ6dVB0EqlYjNWzx)+BWNPxIG7vqdTy85pjHzUOrK3(u"ࠬࠦๅ๋฼สฬฬ๐ส๊ࠡฯ๋ฬุใࠡใํ๋๋ࠥำศฯฬࠤๆอั฻หࠣࠫऄ")+str(ldbr4ynCNSQPqxFomAYpEVMzhLG7U)+SbjiWeHLQPoazqwp3cODkd7YxVgn(u"࠭ࠠๆ์฽หออ๊ห๋่้๋ࠢอศใ฻อࠥ฿ไ๊ࠢ฼้้ࠦฬ่ษี็ࠥฮฯู้่้ࠣอใๅࠢํะอࠦลษไสลࠥ࠭अ")+str(ChoHmKqcvs3GOrMaURtjpnNixT)+dDYUoKi6JFM23p(u"ࠧࠡ็ํ฾ฬฮว๋ฬࠣๅฬืฺสࠢาหห๋ว๊๊ࠡิฬࠦๅฺ่ส๋ࠥษๆࠡฮ๊หื้ࠠๅษࠣฮําฯࠡใํ๋๋ࠥำศฯฬࠤ่อแ๋ห่ࠣฯำๅ๋ๆ้้ࠣ็ࠠศๆไ๎ิ๐่ࠡษ็้฼๊่ษࠩआ"))
		return DD5cFIejQa2X4BgAu9GWPyJ3tC7
	aVwGA2kFY6u4m = BjMmX1vNrnzSAf(RRIHDFjoW9w7bSfVPhC(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨइ"),b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"๊่ࠩࠥะั๋ัࠣฮา๋๊ๅࠢส่๊๊แࠡมࠪई"),Nh0BWuiSndf(u"ࠪห้๋ไโࠢส่๊฽ไ้สࠣัั๋็ࠡฬๅี๏ฮวࠡࠩउ")+str(mkZPXKTJ6dVB0EqlYjNWzx)+BWNPxIG7vqdTy85pjHzUOrK3(u"๋๊ࠫࠥ฻ษหห๏ะ้ࠠฮ๊หื้ࠠโ์๊ࠤู๊วฮหࠣๅฬืฺสࠢอๆึ๐ศศࠢࠪऊ")+str(ldbr4ynCNSQPqxFomAYpEVMzhLG7U)+IjZbnrBJmM2N(u"ࠬࠦๅ๋฼สฬฬ๐ส๊๊ࠡิฬࠦวๅ็็ๅ่ࠥฯࠡ์ะฮฬาࠠษ฻ูࠤฬ๊่ใฬ่้ࠣะอๆ์็ࠤ๊์ࠠศๆศ๊ฯืๆหࠢศ่๎ࠦฬ่ษี็ࠥ࠴่ࠠๆࠣห๋ะࠠๆฬฦ็ิ่ࠦหำํำࠥอไศีอ้ึอัࠡสอั๊๐ไࠡ็็ๅࠥอไโ์า๎ํࠦฟࠨऋ"))
	if aVwGA2kFY6u4m!=yST5AHEfvPmcWpwGuh2BJ(u"࠷॒"):
		tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,RRIHDFjoW9w7bSfVPhC(u"࠭สๆࠢศ่฿อมࠡ฻่่๏ฯࠠหฯ่๎้ࠦๅๅใࠣห้็๊ะ์๋ࠫऌ"))
		mwIxD3GBPgLVc2aq9(MtTygrzXFlQ,EECz06teoykrNFfq(QQ8pvXNcBfVkP5rRJ7o)+Nh0BWuiSndf(u"࡙ࠧࠡࠢࠣࡸ࡫ࡲࠡࡥࡤࡲࡨ࡫࡬ࡦࡦࠣࡸ࡭࡫ࠠࡥࡱࡺࡲࡱࡵࡡࡥࠢࡲࡪࠥࡺࡨࡦࠢࡹ࡭ࡩ࡫࡯ࠡࡨ࡬ࡰࡪࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩऍ")+MUJCtfYVBLODrFbaZn+IjZbnrBJmM2N(u"ࠨࠢࡠࠤࠥࠦࡆࡪ࡮ࡨ࠾ࠥࡡࠠࠨऎ")+Z401tDY6IygxTRi5oMvsElBkKuj3Nh+BWNPxIG7vqdTy85pjHzUOrK3(u"ࠩࠣࡡࠬए"))
		return DD5cFIejQa2X4BgAu9GWPyJ3tC7
	mwIxD3GBPgLVc2aq9(MtTygrzXFlQ,EECz06teoykrNFfq(QQ8pvXNcBfVkP5rRJ7o)+QTUBCcehw6qPd4x(u"ࠪࠤࠥࠦࡄࡰࡹࡱࡰࡴࡧࡤࠡࡵࡷࡥࡷࡺࡥࡥࠢࡶࡹࡨࡩࡥࡴࡵࡩࡹࡱࡲࡹࠨऐ"))
	vN2KjutDaTCsUY5x = F6kGteqcvBXWCKdASUZmnjP()
	vN2KjutDaTCsUY5x.create(Z401tDY6IygxTRi5oMvsElBkKuj3Nh,S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠫฬ๊ำุำࠣๅํ่่๊้่ࠠࠣอๆࠡฬัึ๏์ࠠๆๆไࠤฬ๊แ๋ัํ์ࠬऑ"))
	mvhnqEjIdzTWUaG07iZxlOo4J = CCxMXuNUEzolDZTKrBJ
	xhWaiNzZPjTfLQV9b7H382ovXrEKBe = wLQCTr5lqbsVYeAHdzfhZ1F.time()
	if not XrloM5pTyK.xd4VjQuvJDC2ms:
		tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,DYakr9g4PVU(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨऒ"),LAQD5wEkr18bUiGaYen3J(u"࠭ศิสหࠤ฾ีๅࠡษ็ฮอืูࠡฬ่ࠤสฺ๊ศรࠣฮา๋๊ๅ่่ࠢๆࠦวๅใํำ๏๎ࠧओ"))
		return DD5cFIejQa2X4BgAu9GWPyJ3tC7
	if i1thmHk7AZquD4cM0fnp62: dhZ4awfOob5EQx = open(Z401tDY6IygxTRi5oMvsElBkKuj3Nh,yST5AHEfvPmcWpwGuh2BJ(u"ࠧࡸࡤࠪऔ"))
	else: dhZ4awfOob5EQx = open(Z401tDY6IygxTRi5oMvsElBkKuj3Nh.decode(OVauxZzLI10vcXT74K),Nh0BWuiSndf(u"ࠨࡹࡥࠫक"))
	if xZds9ITEWatF7Kb==S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨख"):
		for s9s45taoNBh60XL1zykOmTK3jJCrE in range(shC5qBRV2A0lZ(u"࠱॓"),NeMyKLqFzsAQ9E7rV+shC5qBRV2A0lZ(u"࠱॓")):
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = tzdvaEpMHOCZLXDYg08T[s9s45taoNBh60XL1zykOmTK3jJCrE-mQNonhS7CV2BXOv(u"࠲॔")]
			if not pcA1dzy7LXwGfMPg9mTkuh5tine3.startswith(UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠪ࡬ࡹࡺࡰࠨग")):
				if pcA1dzy7LXwGfMPg9mTkuh5tine3.startswith(shC5qBRV2A0lZ(u"ࠫ࠴࠵ࠧघ")): pcA1dzy7LXwGfMPg9mTkuh5tine3 = MUJCtfYVBLODrFbaZn.split(QQdAXWBc2GPw(u"ࠬࡀࠧङ"),Xz3bA2PFENVCUtplu51(u"࠳ॕ"))[LzYQg91SIxDeOGtCKd5]+HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"࠭࠺ࠨच")+pcA1dzy7LXwGfMPg9mTkuh5tine3
				elif pcA1dzy7LXwGfMPg9mTkuh5tine3.startswith(mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠧ࠰ࠩछ")): pcA1dzy7LXwGfMPg9mTkuh5tine3 = Wl2eu1PavfQ(MUJCtfYVBLODrFbaZn,uVQd103XyvUce2EBtzbYaC(u"ࠨࡷࡵࡰࠬज"))+pcA1dzy7LXwGfMPg9mTkuh5tine3
				else: pcA1dzy7LXwGfMPg9mTkuh5tine3 = MUJCtfYVBLODrFbaZn.rsplit(Xz3bA2PFENVCUtplu51(u"ࠩ࠲ࠫझ"),BmePGjS7FxK6kutUM(u"࠴ॖ"))[LzYQg91SIxDeOGtCKd5]+yST5AHEfvPmcWpwGuh2BJ(u"ࠪ࠳ࠬञ")+pcA1dzy7LXwGfMPg9mTkuh5tine3
			mJegc5bW2YjVwD = gehRtQT6u2cZIrB5m3.request(Xz3bA2PFENVCUtplu51(u"ࠫࡌࡋࡔࠨट"),pcA1dzy7LXwGfMPg9mTkuh5tine3,headers=NNB43WbKMVnrktmcsZXUR6wvfJq,verify=DD5cFIejQa2X4BgAu9GWPyJ3tC7)
			yWcnAUFQ1vz = mJegc5bW2YjVwD.content
			mJegc5bW2YjVwD.close()
			dhZ4awfOob5EQx.write(yWcnAUFQ1vz)
			reZcQSj7ybTR = wLQCTr5lqbsVYeAHdzfhZ1F.time()
			vhpbu3daYNXDotf4rmLwx1 = reZcQSj7ybTR-xhWaiNzZPjTfLQV9b7H382ovXrEKBe
			P3b9HGqTj0ZR = vhpbu3daYNXDotf4rmLwx1//s9s45taoNBh60XL1zykOmTK3jJCrE
			OO5WfpBMQvUjoknlRm23tTaCKN9YS = P3b9HGqTj0ZR*(NeMyKLqFzsAQ9E7rV+VFjQx6Is28KvzLOmMXtg4GqTwa3(u"࠵ॗ"))
			ewImoODax5RCJ2TuNY = OO5WfpBMQvUjoknlRm23tTaCKN9YS-vhpbu3daYNXDotf4rmLwx1
			NrM3XJ8sD2pEHz(vN2KjutDaTCsUY5x,int(uVQd103XyvUce2EBtzbYaC(u"࠷࠰࠱ख़")*s9s45taoNBh60XL1zykOmTK3jJCrE//(NeMyKLqFzsAQ9E7rV+Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"࠶क़"))),TYf7Dc06PQgy1vEV9(u"ࠬอไิูิࠤๆ๎โ้๋ࠡࠤ๊้ว็ࠢอาื๐ๆࠡ็็ๅࠥอไโ์า๎ํ࠭ठ"),Nh0BWuiSndf(u"࠭ฬๅส้้ࠣ็ࠠศๆไ๎ิ๐่࠻࠯ࠣห้าายࠢิๆ๊࠭ड"),str(s9s45taoNBh60XL1zykOmTK3jJCrE*dtbgHLmZcqCjPiRx6QMlfX//aD3XhMLIHycqN)+vvWwO3Tx2dAgcijrFXq(u"ࠧ࠰ࠩढ")+str(mkZPXKTJ6dVB0EqlYjNWzx)+Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠨࠢࡐࡆ๊ࠥࠦࠠࠡๅฮ๋ࠥสษไํ࠾ࠥ࠭ण")+wLQCTr5lqbsVYeAHdzfhZ1F.strftime(DYakr9g4PVU(u"ࠤࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠦत"),wLQCTr5lqbsVYeAHdzfhZ1F.gmtime(ewImoODax5RCJ2TuNY))+TYf7Dc06PQgy1vEV9(u"ࠪࠤๅ࠭थ"))
			if vN2KjutDaTCsUY5x.iscanceled():
				mvhnqEjIdzTWUaG07iZxlOo4J = DD5cFIejQa2X4BgAu9GWPyJ3tC7
				break
	else:
		s9s45taoNBh60XL1zykOmTK3jJCrE = Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"࠰ग़")
		for yWcnAUFQ1vz in mJegc5bW2YjVwD.iter_content(chunk_size=dtbgHLmZcqCjPiRx6QMlfX):
			dhZ4awfOob5EQx.write(yWcnAUFQ1vz)
			s9s45taoNBh60XL1zykOmTK3jJCrE = s9s45taoNBh60XL1zykOmTK3jJCrE+S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"࠲ज़")
			reZcQSj7ybTR = wLQCTr5lqbsVYeAHdzfhZ1F.time()
			vhpbu3daYNXDotf4rmLwx1 = reZcQSj7ybTR-xhWaiNzZPjTfLQV9b7H382ovXrEKBe
			P3b9HGqTj0ZR = vhpbu3daYNXDotf4rmLwx1/s9s45taoNBh60XL1zykOmTK3jJCrE
			OO5WfpBMQvUjoknlRm23tTaCKN9YS = P3b9HGqTj0ZR*(NeMyKLqFzsAQ9E7rV+ddo23ZJtgcY(u"࠳ड़"))
			ewImoODax5RCJ2TuNY = OO5WfpBMQvUjoknlRm23tTaCKN9YS-vhpbu3daYNXDotf4rmLwx1
			NrM3XJ8sD2pEHz(vN2KjutDaTCsUY5x,int(LAQD5wEkr18bUiGaYen3J(u"࠵࠵࠶फ़")*s9s45taoNBh60XL1zykOmTK3jJCrE/(NeMyKLqFzsAQ9E7rV+UUkIBz1sgQ9WfNeG6trKXvu0(u"࠴ढ़"))),LAQD5wEkr18bUiGaYen3J(u"ࠫฬ๊ำุำࠣๅํ่่๊้่ࠠࠣอๆࠡฬัึ๏์ࠠๆๆไࠤฬ๊แ๋ัํ์ࠬद"),LAQD5wEkr18bUiGaYen3J(u"ࠬาไษ่่ࠢๆࠦวๅใํำ๏๎࠺࠮ࠢส่ัุมࠡำๅ้ࠬध"),str(s9s45taoNBh60XL1zykOmTK3jJCrE*dtbgHLmZcqCjPiRx6QMlfX//aD3XhMLIHycqN)+mmcNLrXtzfpyCkZlvK5VwG2gujh(u"࠭࠯ࠨन")+str(mkZPXKTJ6dVB0EqlYjNWzx)+uVQd103XyvUce2EBtzbYaC(u"ࠧࠡࡏࡅࠤ้ࠥࠦࠠไอࠤ๊ะศใ์࠽ࠤࠬऩ")+wLQCTr5lqbsVYeAHdzfhZ1F.strftime(Nh0BWuiSndf(u"ࠣࠧࡋ࠾ࠪࡓ࠺ࠦࡕࠥप"),wLQCTr5lqbsVYeAHdzfhZ1F.gmtime(ewImoODax5RCJ2TuNY))+m6hwdgP31a2zjN7lkpX(u"ࠩࠣไࠬफ"))
			if vN2KjutDaTCsUY5x.iscanceled():
				mvhnqEjIdzTWUaG07iZxlOo4J = DD5cFIejQa2X4BgAu9GWPyJ3tC7
				break
		mJegc5bW2YjVwD.close()
	dhZ4awfOob5EQx.close()
	vN2KjutDaTCsUY5x.close()
	if not mvhnqEjIdzTWUaG07iZxlOo4J:
		mwIxD3GBPgLVc2aq9(MtTygrzXFlQ,EECz06teoykrNFfq(QQ8pvXNcBfVkP5rRJ7o)+LAQD5wEkr18bUiGaYen3J(u"ࠪࠤࠥࠦࡕࡴࡧࡵࠤࡨࡧ࡮ࡤࡧ࡯ࡩࡩ࠵ࡩ࡯ࡶࡨࡶࡷࡻࡰࡵࡧࡧࠤࡹ࡮ࡥࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࠣࡴࡷࡵࡣࡦࡵࡶࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧब")+MUJCtfYVBLODrFbaZn+dDYUoKi6JFM23p(u"ࠫࠥࡣࠠࠡࠢࡉ࡭ࡱ࡫࠺ࠡ࡝ࠣࠫभ")+Z401tDY6IygxTRi5oMvsElBkKuj3Nh+zI3ROAZtiUq42rE9WDST68(u"ࠬࠦ࡝ࠨम"))
		tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩय"),zI3ROAZtiUq42rE9WDST68(u"ࠧษฯึฬࠥ฽ไษๅࠣฮ๊ࠦลๅ฼สลࠥ฿ๅๅ์ฬࠤฯำๅ๋ๆ้้ࠣ็ࠠศๆไ๎ิ๐่ࠨर"))
		return CCxMXuNUEzolDZTKrBJ
	mwIxD3GBPgLVc2aq9(MtTygrzXFlQ,EECz06teoykrNFfq(QQ8pvXNcBfVkP5rRJ7o)+yST5AHEfvPmcWpwGuh2BJ(u"ࠨࠢࠣࠤ࡛࡯ࡤࡦࡱࠣࡪ࡮ࡲࡥࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࡨࡨࠥࡹࡵࡤࡥࡨࡷࡸ࡬ࡵ࡭࡮ࡼࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧऱ")+MUJCtfYVBLODrFbaZn+BmePGjS7FxK6kutUM(u"ࠩࠣࡡࠥࠦࠠࡇ࡫࡯ࡩ࠿࡛ࠦࠡࠩल")+Z401tDY6IygxTRi5oMvsElBkKuj3Nh+BmePGjS7FxK6kutUM(u"ࠪࠤࡢ࠭ळ"))
	tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧऴ"),yST5AHEfvPmcWpwGuh2BJ(u"ࠬะๅࠡฬะ้๏๊ࠠๆๆไࠤฬ๊แ๋ัํ์ࠥฮๆอษะࠫव"))
	return CCxMXuNUEzolDZTKrBJ
﻿# -*- coding: utf-8 -*-
from hIVCFnfxSO import *
QQ8pvXNcBfVkP5rRJ7o = 'ALMAAREF'
headers = {'User-Agent':b8Qe150xVaJsnDSv}
WbzmKSZiuOYrBN7oysJ2dUv = '_MRF_'
wQjs1XZ3AO24g8y9bEeoKMiGIu7 = nTHXJIiah2qK[QQ8pvXNcBfVkP5rRJ7o][0]
v1vJEhoNQBVPkjG = ['التواصل الاجتماعي','صور التواصل الاجتماعي','أرشيف جميع البرامج']
def x8IFqMZeJj7suCR4AaGoNXfEHm(mode,url,text,NGQDwOCXx1BZmd9Huc):
	if   mode==40: XXxlOLJ9KRjPH382WVCvr6n71 = Y72YmLgw4vqlHxTCkbeKSicasD()
	elif mode==41: XXxlOLJ9KRjPH382WVCvr6n71 = vtqABUEyi7jeLRWSkV5b8KpMH()
	elif mode==42: XXxlOLJ9KRjPH382WVCvr6n71 = AAmZdnBFJxcXHpt(text,NGQDwOCXx1BZmd9Huc)
	elif mode==43: XXxlOLJ9KRjPH382WVCvr6n71 = Hkij627uCDJKyIM(url)
	elif mode==44: XXxlOLJ9KRjPH382WVCvr6n71 = Je4TwC30iOG5DLKWAtbYvhs(text,NGQDwOCXx1BZmd9Huc)
	elif mode==49: XXxlOLJ9KRjPH382WVCvr6n71 = kstJfK6jHQWrXDSMRIGB7(text)
	else: XXxlOLJ9KRjPH382WVCvr6n71 = False
	return XXxlOLJ9KRjPH382WVCvr6n71
def Y72YmLgw4vqlHxTCkbeKSicasD():
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'بحث في الموقع',b8Qe150xVaJsnDSv,49)
	MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+' ===== ===== ===== '+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999)
	MQtuaShrKTbdZFJ5nsR7D('live',WbzmKSZiuOYrBN7oysJ2dUv+'البث الحي لقناة المعارف',b8Qe150xVaJsnDSv,41)
	AAmZdnBFJxcXHpt(b8Qe150xVaJsnDSv,'1')
	return
def ppsqCvkQ4h(v7Rxw52Z4X0,tVT8fHPiojOl72Ub):
	search,sort,r6o4AXjf7CLhF,Z8s0Lov2UiWF1qGjO,Z5fEN7SKihG0BrqCu8 = b8Qe150xVaJsnDSv,[],[],[],[]
	jprAaOYCD6yM8P5VZXK1B2ldNbuR,jVwzC2EBAtcDr6HWm8vZdlUa7X = FNIhDd4uLfev0q5YHVGx8oWm6CsiJ(v7Rxw52Z4X0)
	for Ny03TjaY7bBxWwm2GI in list(jVwzC2EBAtcDr6HWm8vZdlUa7X.keys()):
		Y8aiFZsLKw = jVwzC2EBAtcDr6HWm8vZdlUa7X[Ny03TjaY7bBxWwm2GI]
		if not Y8aiFZsLKw: continue
		if   Ny03TjaY7bBxWwm2GI=='sort': sort = [Y8aiFZsLKw]
		elif Ny03TjaY7bBxWwm2GI=='series': r6o4AXjf7CLhF = [Y8aiFZsLKw]
		elif Ny03TjaY7bBxWwm2GI=='search': search = Y8aiFZsLKw
		elif Ny03TjaY7bBxWwm2GI=='category': Z8s0Lov2UiWF1qGjO = [Y8aiFZsLKw]
		elif Ny03TjaY7bBxWwm2GI=='specialist': Z5fEN7SKihG0BrqCu8 = [Y8aiFZsLKw]
	lo6biSg2NR3eUB1OpEPxzyXwF8sYWI = {"action":"facetwp_refresh","data":{"facets":{"search":search,"video_categories":Z8s0Lov2UiWF1qGjO,"specialist":Z5fEN7SKihG0BrqCu8,"series":r6o4AXjf7CLhF,"number":[],"sort_video":sort,"count":[],"pagination":[]},"frozen_facets":{},"template":"video_desktop_posts","extras":{"sort":"default"},"soft_refresh":0,"is_bfcache":1,"first_load":0,"paged":int(tVT8fHPiojOl72Ub)}}
	lo6biSg2NR3eUB1OpEPxzyXwF8sYWI = AFIDMBehNx5QH6g21E8kq9JzrLi.dumps(lo6biSg2NR3eUB1OpEPxzyXwF8sYWI)
	pcA1dzy7LXwGfMPg9mTkuh5tine3 = 'https://almaaref.ch/wp-json/facetwp/v1/refresh'
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'POST',pcA1dzy7LXwGfMPg9mTkuh5tine3,lo6biSg2NR3eUB1OpEPxzyXwF8sYWI,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'ALMAAREF-REQUEST_DATA_PAGE-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	data = oJsUwXA0yGOI1mTjxQ('dict',jLtdbeYiQHnf4SpU2MTly)
	return data
def AAmZdnBFJxcXHpt(v7Rxw52Z4X0,level):
	JQjNkD10xehK8bXUalY3EgZAVmvI = ppsqCvkQ4h(v7Rxw52Z4X0,'1')
	OTKx7aVb2hdS16Wrweky4FXfIN0g9 = JQjNkD10xehK8bXUalY3EgZAVmvI['facets']
	if level=='1':
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = OTKx7aVb2hdS16Wrweky4FXfIN0g9['video_categories']
		items = YYBlm36zd0Jst18LXwo4.findall('<div(.*?)/div>',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for tgoJCpq8KGrdaUSjsLh0FTxDRPfIAB in items:
			N6gCa1OZ9HnU2 = YYBlm36zd0Jst18LXwo4.findall('data-value=\\"(.*?)\\".*?display-value\\">(.*?)<',tgoJCpq8KGrdaUSjsLh0FTxDRPfIAB+'<',YYBlm36zd0Jst18LXwo4.DOTALL)
			if not N6gCa1OZ9HnU2: N6gCa1OZ9HnU2 = YYBlm36zd0Jst18LXwo4.findall('data-value=\\"(.*?)\\">(.*?)<',tgoJCpq8KGrdaUSjsLh0FTxDRPfIAB+'<',YYBlm36zd0Jst18LXwo4.DOTALL)
			Z8s0Lov2UiWF1qGjO,title = N6gCa1OZ9HnU2[0]
			if hDTluNxe7tCwrpqXHzdEcYRfbs: title = ggtn0PzV7aMe(title)
			if not v7Rxw52Z4X0: MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+title,b8Qe150xVaJsnDSv,42,b8Qe150xVaJsnDSv,'2','?category='+Z8s0Lov2UiWF1qGjO)
			else: MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,b8Qe150xVaJsnDSv,42,b8Qe150xVaJsnDSv,'2',v7Rxw52Z4X0+'&category='+Z8s0Lov2UiWF1qGjO)
	if level=='2':
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = OTKx7aVb2hdS16Wrweky4FXfIN0g9['specialist']
		items = YYBlm36zd0Jst18LXwo4.findall('value="(.*?)".*?>(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for Z5fEN7SKihG0BrqCu8,title in items:
			if hDTluNxe7tCwrpqXHzdEcYRfbs: title = ggtn0PzV7aMe(title)
			if not Z5fEN7SKihG0BrqCu8: title = title = 'الجميع'
			MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,b8Qe150xVaJsnDSv,42,b8Qe150xVaJsnDSv,'3',v7Rxw52Z4X0+'&specialist='+Z5fEN7SKihG0BrqCu8)
	elif level=='3':
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = OTKx7aVb2hdS16Wrweky4FXfIN0g9['series']
		items = YYBlm36zd0Jst18LXwo4.findall('value="(.*?)".*?>(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for r6o4AXjf7CLhF,title in items:
			if hDTluNxe7tCwrpqXHzdEcYRfbs: title = ggtn0PzV7aMe(title)
			if not r6o4AXjf7CLhF: title = title = 'الجميع'
			MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,b8Qe150xVaJsnDSv,42,b8Qe150xVaJsnDSv,'4',v7Rxw52Z4X0+'&series='+r6o4AXjf7CLhF)
	elif level=='4':
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = OTKx7aVb2hdS16Wrweky4FXfIN0g9['sort_video']
		items = YYBlm36zd0Jst18LXwo4.findall('value="(.*?)".*?>(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for sort,title in items:
			if not sort: continue
			if hDTluNxe7tCwrpqXHzdEcYRfbs: title = ggtn0PzV7aMe(title)
			MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,b8Qe150xVaJsnDSv,44,b8Qe150xVaJsnDSv,'1',v7Rxw52Z4X0+'&sort='+sort)
	return
def Je4TwC30iOG5DLKWAtbYvhs(v7Rxw52Z4X0,tVT8fHPiojOl72Ub):
	JQjNkD10xehK8bXUalY3EgZAVmvI = ppsqCvkQ4h(v7Rxw52Z4X0,tVT8fHPiojOl72Ub)
	OTKx7aVb2hdS16Wrweky4FXfIN0g9 = JQjNkD10xehK8bXUalY3EgZAVmvI['template']
	items = YYBlm36zd0Jst18LXwo4.findall('src="(.*?)".*?href="(.*?)">(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	for lvtGpMZHb9,pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
		if hDTluNxe7tCwrpqXHzdEcYRfbs: title = ggtn0PzV7aMe(title)
		MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,43,lvtGpMZHb9)
	OTKx7aVb2hdS16Wrweky4FXfIN0g9 = JQjNkD10xehK8bXUalY3EgZAVmvI['facets']['pagination']
	items = YYBlm36zd0Jst18LXwo4.findall('data-page="(.*?)">(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	for NGQDwOCXx1BZmd9Huc,title in items:
		if tVT8fHPiojOl72Ub==NGQDwOCXx1BZmd9Huc: continue
		if hDTluNxe7tCwrpqXHzdEcYRfbs: title = ggtn0PzV7aMe(title)
		MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'صفحة '+title,b8Qe150xVaJsnDSv,44,b8Qe150xVaJsnDSv,NGQDwOCXx1BZmd9Huc,v7Rxw52Z4X0)
	return
def Hkij627uCDJKyIM(url):
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'ALMAAREF-PLAY-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	pcA1dzy7LXwGfMPg9mTkuh5tine3 = YYBlm36zd0Jst18LXwo4.findall('<video src="(.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if not pcA1dzy7LXwGfMPg9mTkuh5tine3: pcA1dzy7LXwGfMPg9mTkuh5tine3 = YYBlm36zd0Jst18LXwo4.findall('youtube_url.*?(http.*?)&',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	n92bB0YwDLqyadQRlmGW = []
	if pcA1dzy7LXwGfMPg9mTkuh5tine3:
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3[0].replace('\/','/')
		n92bB0YwDLqyadQRlmGW.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
	import QNeGEq8sWn
	QNeGEq8sWn.nqu2GCT9gHAbpIPSFZz5(n92bB0YwDLqyadQRlmGW,QQ8pvXNcBfVkP5rRJ7o,'video',url)
	return
def vtqABUEyi7jeLRWSkV5b8KpMH():
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(Q49IsrlSuYRAVbGKhwdckLDOetF2PZ,'GET',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/بث-مباشر',b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'ALMAAREF-LIVE-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	url = YYBlm36zd0Jst18LXwo4.findall('"svpPlayer".*?(http.*?)&',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	url = url[0].replace('\\',b8Qe150xVaJsnDSv)
	yulQjIFbzM(url,QQ8pvXNcBfVkP5rRJ7o,'live')
	return
def kstJfK6jHQWrXDSMRIGB7(search):
	search,v7Rxw52Z4X0,showDialogs = JimhUH0SEf6w(search)
	tLUcR1oPSx48ebpVuslakm7 = False
	if search==b8Qe150xVaJsnDSv:
		search = FT2oXWtPQpVGuexmLqKN3srdzYn()
		tLUcR1oPSx48ebpVuslakm7 = True
	if search==b8Qe150xVaJsnDSv: return
	if not tLUcR1oPSx48ebpVuslakm7: Je4TwC30iOG5DLKWAtbYvhs('?search='+search,'1')
	else: AAmZdnBFJxcXHpt('?search='+search,'1')
	return
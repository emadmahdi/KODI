# -*- coding: utf-8 -*-
from hIVCFnfxSO import *
QQ8pvXNcBfVkP5rRJ7o = 'EGYNOW'
WbzmKSZiuOYrBN7oysJ2dUv = '_EGN_'
wQjs1XZ3AO24g8y9bEeoKMiGIu7 = nTHXJIiah2qK[QQ8pvXNcBfVkP5rRJ7o][0]
v1vJEhoNQBVPkjG = ['عروض مصارعة','الكل','n/A','المزيد','قصة عشق']
def x8IFqMZeJj7suCR4AaGoNXfEHm(mode,url,text):
	if   mode==430: XXxlOLJ9KRjPH382WVCvr6n71 = Y72YmLgw4vqlHxTCkbeKSicasD()
	elif mode==431: XXxlOLJ9KRjPH382WVCvr6n71 = Je4TwC30iOG5DLKWAtbYvhs(url,text)
	elif mode==432: XXxlOLJ9KRjPH382WVCvr6n71 = Hkij627uCDJKyIM(url)
	elif mode==433: XXxlOLJ9KRjPH382WVCvr6n71 = bIpskeGhBlqH(url)
	elif mode==434: XXxlOLJ9KRjPH382WVCvr6n71 = eszTQbMvkmRwCAxGDPdYJUi(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==435: XXxlOLJ9KRjPH382WVCvr6n71 = eszTQbMvkmRwCAxGDPdYJUi(url,'SPECIFIED_FILTER___'+text)
	elif mode==436: XXxlOLJ9KRjPH382WVCvr6n71 = Q6mUHMbNlirVXPRgKWJAt8ap5hSE(url)
	elif mode==437: XXxlOLJ9KRjPH382WVCvr6n71 = BBSmZ6QRHn4CjxN(url)
	elif mode==439: XXxlOLJ9KRjPH382WVCvr6n71 = kstJfK6jHQWrXDSMRIGB7(text)
	else: XXxlOLJ9KRjPH382WVCvr6n71 = False
	return XXxlOLJ9KRjPH382WVCvr6n71
def Y72YmLgw4vqlHxTCkbeKSicasD():
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/films',b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'EGYNOW-MENU-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	OZSA7QNfeE = YYBlm36zd0Jst18LXwo4.findall('"canonical" href="(.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	OZSA7QNfeE = OZSA7QNfeE[0].strip('/')
	OZSA7QNfeE = Wl2eu1PavfQ(OZSA7QNfeE,'url')
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'بحث في الموقع',b8Qe150xVaJsnDSv,439,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'_REMEMBERRESULTS_')
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'فلتر محدد',OZSA7QNfeE,435)
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'فلتر كامل',OZSA7QNfeE,434)
	MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+' ===== ===== ===== '+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999)
	MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+'المضاف حديثا',OZSA7QNfeE,431)
	MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+'افلام اون لاين',OZSA7QNfeE+'/films1',436)
	MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+'مسلسلات اون لاين',OZSA7QNfeE+'/series-all1',436)
	MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+'قائمة تفصيلية',OZSA7QNfeE,437)
	MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+' ===== ===== ===== '+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999)
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('"SiteNavigation"(.*?)"Search"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
	items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)".*?>(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
		if title in v1vJEhoNQBVPkjG: continue
		if title=='الرئيسية': continue
		if 'اون لاين' in title: continue
		MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,431)
	return
def BBSmZ6QRHn4CjxN(website=b8Qe150xVaJsnDSv):
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',website+'/films',b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'EGYNOW-MENU-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	OZSA7QNfeE = YYBlm36zd0Jst18LXwo4.findall('"canonical" href="(.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	OZSA7QNfeE = OZSA7QNfeE[0].strip('/')
	OZSA7QNfeE = Wl2eu1PavfQ(OZSA7QNfeE,'url')
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('"ListDroped"(.*?)"SearchingMaster"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
	items = YYBlm36zd0Jst18LXwo4.findall('data-tax="(.*?)" data-term="(.*?)" data-name="(.*?)"',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	for Z8s0Lov2UiWF1qGjO,Y8aiFZsLKw,title in items:
		if title in v1vJEhoNQBVPkjG: continue
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = website+'/explore/?'+Z8s0Lov2UiWF1qGjO+'='+Y8aiFZsLKw
		MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,431)
	return
def Q6mUHMbNlirVXPRgKWJAt8ap5hSE(url):
	OZSA7QNfeE = Wl2eu1PavfQ(url,'url')
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'EGYNOW-SUBMENU-1st')
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'الجميع',url,431)
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('"titleSectionCon"(.*?)</div></div>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
	items = YYBlm36zd0Jst18LXwo4.findall('data-key="(.*?)".*?<em>(.*?)</em>',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	for vI9QYJckeTmfRFV,title in items:
		if title in v1vJEhoNQBVPkjG: continue
		MUJCtfYVBLODrFbaZn = OZSA7QNfeE+'/wp-content/themes/EgyNowByElshaikh/Ajaxt/Movies/Keys.php?key='+vI9QYJckeTmfRFV
		MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,MUJCtfYVBLODrFbaZn,431)
	return
def Je4TwC30iOG5DLKWAtbYvhs(url,rC39wAIKjUuS=b8Qe150xVaJsnDSv):
	OZSA7QNfeE = Wl2eu1PavfQ(url,'url')
	items = []
	if '/Terms.php' in url or '/Get.php' in url or '/Keys.php' in url:
		MUJCtfYVBLODrFbaZn,EEkjQFxOabod08Nr = FNIhDd4uLfev0q5YHVGx8oWm6CsiJ(url)
		ybF0H85nUohsiRQcpaTfZAKzjMY7wB = {'X-Requested-With':'XMLHttpRequest','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'POST',MUJCtfYVBLODrFbaZn,EEkjQFxOabod08Nr,ybF0H85nUohsiRQcpaTfZAKzjMY7wB,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'EGYNOW-TITLES-1st')
		jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = jLtdbeYiQHnf4SpU2MTly
	elif rC39wAIKjUuS=='featured':
		b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'EGYNOW-TITLES-2nd')
		jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('"MainSlider"(.*?)"MatchesTable"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		items = YYBlm36zd0Jst18LXwo4.findall('<a href="(.*?)" title="(.*?)".*?image: url\((.*?)\)',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	else:
		b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'EGYNOW-TITLES-2nd')
		jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('"BlocksList"(.*?)"Paginate"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if not ZV5rRvabhxJ: ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('"BlocksList"(.*?)"titleSectionCon"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
	if not items: items = YYBlm36zd0Jst18LXwo4.findall('<a href="(.*?)" title="(.*?)".*?data-image="(.*?)"',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	d3VSIefbHnvqiut = []
	PBFVNlrcUMOSzC04 = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for pcA1dzy7LXwGfMPg9mTkuh5tine3,title,lvtGpMZHb9 in items:
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = SgrGWuAHcLKBQMJetb9(pcA1dzy7LXwGfMPg9mTkuh5tine3).strip('/')
		title = pTP49ckGDYrofa2KxenumbH0(title)
		HHr42WSgBjAeU7TkQcVaL6yEJz8PF = YYBlm36zd0Jst18LXwo4.findall('(.*?) الحلقة \d+',title,YYBlm36zd0Jst18LXwo4.DOTALL)
		if any(Y8aiFZsLKw in title for Y8aiFZsLKw in PBFVNlrcUMOSzC04):
			MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,432,lvtGpMZHb9)
		elif HHr42WSgBjAeU7TkQcVaL6yEJz8PF and 'الحلقة' in title:
			title = '_MOD_' + HHr42WSgBjAeU7TkQcVaL6yEJz8PF[0]
			if title not in d3VSIefbHnvqiut:
				MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,433,lvtGpMZHb9)
				d3VSIefbHnvqiut.append(title)
		elif '/movseries/' in pcA1dzy7LXwGfMPg9mTkuh5tine3:
			MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,431,lvtGpMZHb9)
		else: MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,433,lvtGpMZHb9)
	if rC39wAIKjUuS!='featured':
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('"Paginate"(.*?)</ul>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if ZV5rRvabhxJ:
			OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
			items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)">(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
			for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
				if 'http' not in pcA1dzy7LXwGfMPg9mTkuh5tine3: pcA1dzy7LXwGfMPg9mTkuh5tine3 = OZSA7QNfeE+pcA1dzy7LXwGfMPg9mTkuh5tine3
				pcA1dzy7LXwGfMPg9mTkuh5tine3 = pTP49ckGDYrofa2KxenumbH0(pcA1dzy7LXwGfMPg9mTkuh5tine3)
				title = pTP49ckGDYrofa2KxenumbH0(title)
				if title!=b8Qe150xVaJsnDSv: MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'صفحة '+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,431)
		SArDcVYZRkXvC4xpaiQIfE35K = YYBlm36zd0Jst18LXwo4.findall('showmore" href="(.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if SArDcVYZRkXvC4xpaiQIfE35K:
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = SArDcVYZRkXvC4xpaiQIfE35K[0]
			MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'مشاهدة المزيد',pcA1dzy7LXwGfMPg9mTkuh5tine3,431)
	return
def bIpskeGhBlqH(url):
	OZSA7QNfeE = Wl2eu1PavfQ(url,'url')
	Pmt5K6LAEZBcb,U8UnzJgXuMIE5GV = [],[]
	if 'Episodes.php' in url:
		MUJCtfYVBLODrFbaZn,EEkjQFxOabod08Nr = FNIhDd4uLfev0q5YHVGx8oWm6CsiJ(url)
		ybF0H85nUohsiRQcpaTfZAKzjMY7wB = {'X-Requested-With':'XMLHttpRequest','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'POST',MUJCtfYVBLODrFbaZn,EEkjQFxOabod08Nr,ybF0H85nUohsiRQcpaTfZAKzjMY7wB,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'EGYNOW-EPISODES-1st')
		jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
		U8UnzJgXuMIE5GV = [jLtdbeYiQHnf4SpU2MTly]
	else:
		b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'EGYNOW-EPISODES-2nd')
		jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
		Pmt5K6LAEZBcb = YYBlm36zd0Jst18LXwo4.findall('"SeasonsList"(.*?)</ul>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		U8UnzJgXuMIE5GV = YYBlm36zd0Jst18LXwo4.findall('"EpisodesList"(.*?)</ul>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if Pmt5K6LAEZBcb:
		lvtGpMZHb9 = YYBlm36zd0Jst18LXwo4.findall('"og:image" content="(.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		lvtGpMZHb9 = lvtGpMZHb9[0]
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = Pmt5K6LAEZBcb[0]
		items = YYBlm36zd0Jst18LXwo4.findall('data-id="(.*?)".*?data-season="(.*?)".*?">(.*?)</a>',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for EEZLmsCMxVl07kRfzAih,L40VtflHyZBbXAQigo92uUhDN1r,title in items:
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = OZSA7QNfeE+'/wp-content/themes/EgyNowByElshaikh/Ajaxt/Single/Episodes.php?'+'season='+L40VtflHyZBbXAQigo92uUhDN1r+'&post_id='+EEZLmsCMxVl07kRfzAih
			MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,433,lvtGpMZHb9)
	elif U8UnzJgXuMIE5GV:
		lvtGpMZHb9 = uuxVm0bTwdnCUAL4s6NKHEBF3M.getInfoLabel('ListItem.Thumb')
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = U8UnzJgXuMIE5GV[0]
		items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)".*?</i>(.*?)<em>(.*?)</em>',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,title,HHr42WSgBjAeU7TkQcVaL6yEJz8PF in items:
			title = title+pldxivXC5wbTB2O8q+HHr42WSgBjAeU7TkQcVaL6yEJz8PF
			MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,432,lvtGpMZHb9)
	return
def Hkij627uCDJKyIM(url):
	MUJCtfYVBLODrFbaZn = url+'/watch/'
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',MUJCtfYVBLODrFbaZn,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'EGYNOW-PLAY-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = []
	OZSA7QNfeE = Wl2eu1PavfQ(MUJCtfYVBLODrFbaZn,'url')
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('"container-servers"(.*?)</ul>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		wwq9UajEkVIlK2zrN3gx = YYBlm36zd0Jst18LXwo4.findall('data-id="(.*?)"',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		if wwq9UajEkVIlK2zrN3gx:
			wwq9UajEkVIlK2zrN3gx = wwq9UajEkVIlK2zrN3gx[0]
			items = YYBlm36zd0Jst18LXwo4.findall('data-server="(.*?)".*?<span>(.*?)</span>',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
			for LLOCdZ3sS2enzXx4fVB18YRvbHNwky,title in items:
				pcA1dzy7LXwGfMPg9mTkuh5tine3 = OZSA7QNfeE+'/wp-content/themes/EgyNowByElshaikh/Ajaxt/Single/Server.php?server='+LLOCdZ3sS2enzXx4fVB18YRvbHNwky+'&post_id='+wwq9UajEkVIlK2zrN3gx+'?named='+title+'__watch'
				KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
	NGQbtdCeMU8F = YYBlm36zd0Jst18LXwo4.findall('"container-iframe"><iframe src="(.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if NGQbtdCeMU8F:
		NGQbtdCeMU8F = NGQbtdCeMU8F[0].replace(eeN6dTEnkJxI,b8Qe150xVaJsnDSv)
		title = Wl2eu1PavfQ(NGQbtdCeMU8F,'name')
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = NGQbtdCeMU8F+'?named='+title+'__embed'
		KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('"container-download"(.*?)</ul>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)".*?span>(.*?)<.*?em>(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,title,c1EdszLx3mkb8QYX9 in items:
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3.replace(eeN6dTEnkJxI,b8Qe150xVaJsnDSv)
			if c1EdszLx3mkb8QYX9!=b8Qe150xVaJsnDSv: c1EdszLx3mkb8QYX9 = '____'+c1EdszLx3mkb8QYX9
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3+'?named='+title+'__download'+c1EdszLx3mkb8QYX9
			KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
	import QNeGEq8sWn
	QNeGEq8sWn.nqu2GCT9gHAbpIPSFZz5(KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j,QQ8pvXNcBfVkP5rRJ7o,'video',url)
	return
def kstJfK6jHQWrXDSMRIGB7(search):
	search,v7Rxw52Z4X0,showDialogs = JimhUH0SEf6w(search)
	if search==b8Qe150xVaJsnDSv: search = FT2oXWtPQpVGuexmLqKN3srdzYn()
	if search==b8Qe150xVaJsnDSv: return
	search = search.replace(pldxivXC5wbTB2O8q,'%20')
	url = wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/?s='+search
	Je4TwC30iOG5DLKWAtbYvhs(url)
	return
def wwtH4LbAYj2OvQ7DTpdJx(url):
	url = url.split('/smartemadfilter?')[0]
	OZSA7QNfeE = Wl2eu1PavfQ(url,'url')
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(Q49IsrlSuYRAVbGKhwdckLDOetF2PZ,'GET',OZSA7QNfeE,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'EGYNOW-GET_FILTERS_BLOCKS-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('("dropdown-button".*?)"SearchingMaster"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
	RYqsiFGfj07T2VKXrx3y6Hb = YYBlm36zd0Jst18LXwo4.findall('"dropdown-button".*?<em>(.*?)</em>(.*?data-tax="(.*?)".*?</div>)',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	return RYqsiFGfj07T2VKXrx3y6Hb
def DwEj517Ty94KWU8Y2nSZI3C6vgG(OTKx7aVb2hdS16Wrweky4FXfIN0g9):
	items = YYBlm36zd0Jst18LXwo4.findall('data-term="(\d+)" data-name="(.*?)"',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	return items
def DahRB3A9gNvuFT1eI6lzO5Z(url):
	e3To7sm0Nzn1CruYWxGh = url.split('/smartemadfilter?')[0]
	cCxjKQGYDfZWpd5 = Wl2eu1PavfQ(url,'url')
	url = url.replace(e3To7sm0Nzn1CruYWxGh,cCxjKQGYDfZWpd5)
	url = url.replace('/smartemadfilter?','/explore/?')
	return url
def Ul5KY3BZwA9EGO8j61JfsIquLF(XFJqUiePG7aSf0N,url):
	JXAZh9EQjse2qirMa8DRSYvGLO0kgf = W57WXlwPhyrfVu6oij(XFJqUiePG7aSf0N,'modified_filters')
	GSh0nJxEXgZjd48u7mBwWOeafyAp5b = url+'/smartemadfilter?'+JXAZh9EQjse2qirMa8DRSYvGLO0kgf
	GSh0nJxEXgZjd48u7mBwWOeafyAp5b = DahRB3A9gNvuFT1eI6lzO5Z(GSh0nJxEXgZjd48u7mBwWOeafyAp5b)
	return GSh0nJxEXgZjd48u7mBwWOeafyAp5b
HiGtBb5m673JPE = ['category','country','genre','release-year']
cEjiOo6IGCD2pAzJ4B9bkmXYT = ['quality','release-year','genre','category','language','country']
def eszTQbMvkmRwCAxGDPdYJUi(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==b8Qe150xVaJsnDSv: us8FE67ImlDBS,bxTQdyVe57Bh0P8sG = b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv
	else: us8FE67ImlDBS,bxTQdyVe57Bh0P8sG = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if HiGtBb5m673JPE[0]+'=' not in us8FE67ImlDBS: Z8s0Lov2UiWF1qGjO = HiGtBb5m673JPE[0]
		for FbcUxvE17ewlWNBHgS8Jn in range(len(HiGtBb5m673JPE[0:-1])):
			if HiGtBb5m673JPE[FbcUxvE17ewlWNBHgS8Jn]+'=' in us8FE67ImlDBS: Z8s0Lov2UiWF1qGjO = HiGtBb5m673JPE[FbcUxvE17ewlWNBHgS8Jn+1]
		x5gCnOb9wjSPit6sVclHNZIkFyD0 = us8FE67ImlDBS+'&'+Z8s0Lov2UiWF1qGjO+'=0'
		XFJqUiePG7aSf0N = bxTQdyVe57Bh0P8sG+'&'+Z8s0Lov2UiWF1qGjO+'=0'
		Dnkl4UdcKRILWi6m7TqYJh98vu = x5gCnOb9wjSPit6sVclHNZIkFyD0.strip('&')+'___'+XFJqUiePG7aSf0N.strip('&')
		JXAZh9EQjse2qirMa8DRSYvGLO0kgf = W57WXlwPhyrfVu6oij(bxTQdyVe57Bh0P8sG,'modified_filters')
		MUJCtfYVBLODrFbaZn = url+'/smartemadfilter?'+JXAZh9EQjse2qirMa8DRSYvGLO0kgf
	elif type=='ALL_ITEMS_FILTER':
		pRfP0YvVnLJdukUHstQA8cm = W57WXlwPhyrfVu6oij(us8FE67ImlDBS,'modified_values')
		pRfP0YvVnLJdukUHstQA8cm = SgrGWuAHcLKBQMJetb9(pRfP0YvVnLJdukUHstQA8cm)
		if bxTQdyVe57Bh0P8sG!=b8Qe150xVaJsnDSv: bxTQdyVe57Bh0P8sG = W57WXlwPhyrfVu6oij(bxTQdyVe57Bh0P8sG,'modified_filters')
		if bxTQdyVe57Bh0P8sG==b8Qe150xVaJsnDSv: MUJCtfYVBLODrFbaZn = url
		else: MUJCtfYVBLODrFbaZn = url+'/smartemadfilter?'+bxTQdyVe57Bh0P8sG
		MUJCtfYVBLODrFbaZn = DahRB3A9gNvuFT1eI6lzO5Z(MUJCtfYVBLODrFbaZn)
		MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'أظهار قائمة الفيديو التي تم اختيارها ',MUJCtfYVBLODrFbaZn,431)
		MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+' [[   '+pRfP0YvVnLJdukUHstQA8cm+'   ]]',MUJCtfYVBLODrFbaZn,431)
		MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+' ===== ===== ===== '+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999)
	RYqsiFGfj07T2VKXrx3y6Hb = wwtH4LbAYj2OvQ7DTpdJx(url)
	dict = {}
	for name,OTKx7aVb2hdS16Wrweky4FXfIN0g9,BnHr3VSlN5cMhZ7miAfGLovdbQJWa in RYqsiFGfj07T2VKXrx3y6Hb:
		name = name.replace('--',b8Qe150xVaJsnDSv)
		items = DwEj517Ty94KWU8Y2nSZI3C6vgG(OTKx7aVb2hdS16Wrweky4FXfIN0g9)
		if '=' not in MUJCtfYVBLODrFbaZn: MUJCtfYVBLODrFbaZn = url
		if type=='SPECIFIED_FILTER':
			if Z8s0Lov2UiWF1qGjO!=BnHr3VSlN5cMhZ7miAfGLovdbQJWa: continue
			elif len(items)<2:
				if BnHr3VSlN5cMhZ7miAfGLovdbQJWa==HiGtBb5m673JPE[-1]:
					url = DahRB3A9gNvuFT1eI6lzO5Z(url)
					Je4TwC30iOG5DLKWAtbYvhs(url)
				else: eszTQbMvkmRwCAxGDPdYJUi(MUJCtfYVBLODrFbaZn,'SPECIFIED_FILTER___'+Dnkl4UdcKRILWi6m7TqYJh98vu)
				return
			else:
				MUJCtfYVBLODrFbaZn = DahRB3A9gNvuFT1eI6lzO5Z(MUJCtfYVBLODrFbaZn)
				if BnHr3VSlN5cMhZ7miAfGLovdbQJWa==HiGtBb5m673JPE[-1]: MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'الجميع ',MUJCtfYVBLODrFbaZn,431)
				else: MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'الجميع ',MUJCtfYVBLODrFbaZn,435,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,Dnkl4UdcKRILWi6m7TqYJh98vu)
		elif type=='ALL_ITEMS_FILTER':
			x5gCnOb9wjSPit6sVclHNZIkFyD0 = us8FE67ImlDBS+'&'+BnHr3VSlN5cMhZ7miAfGLovdbQJWa+'=0'
			XFJqUiePG7aSf0N = bxTQdyVe57Bh0P8sG+'&'+BnHr3VSlN5cMhZ7miAfGLovdbQJWa+'=0'
			Dnkl4UdcKRILWi6m7TqYJh98vu = x5gCnOb9wjSPit6sVclHNZIkFyD0+'___'+XFJqUiePG7aSf0N
			MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'الجميع :'+name,MUJCtfYVBLODrFbaZn,434,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,Dnkl4UdcKRILWi6m7TqYJh98vu)
		dict[BnHr3VSlN5cMhZ7miAfGLovdbQJWa] = {}
		for Y8aiFZsLKw,Ny03TjaY7bBxWwm2GI in items:
			if Y8aiFZsLKw=='196533': Ny03TjaY7bBxWwm2GI = 'أفلام نيتفلكس'
			elif Y8aiFZsLKw=='196531': Ny03TjaY7bBxWwm2GI = 'مسلسلات نيتفلكس'
			if Ny03TjaY7bBxWwm2GI in v1vJEhoNQBVPkjG: continue
			dict[BnHr3VSlN5cMhZ7miAfGLovdbQJWa][Y8aiFZsLKw] = Ny03TjaY7bBxWwm2GI
			x5gCnOb9wjSPit6sVclHNZIkFyD0 = us8FE67ImlDBS+'&'+BnHr3VSlN5cMhZ7miAfGLovdbQJWa+'='+Ny03TjaY7bBxWwm2GI
			XFJqUiePG7aSf0N = bxTQdyVe57Bh0P8sG+'&'+BnHr3VSlN5cMhZ7miAfGLovdbQJWa+'='+Y8aiFZsLKw
			NHEdmMD3qPj4zay2nb5O8xKX = x5gCnOb9wjSPit6sVclHNZIkFyD0+'___'+XFJqUiePG7aSf0N
			title = Ny03TjaY7bBxWwm2GI+' :'#+dict[BnHr3VSlN5cMhZ7miAfGLovdbQJWa]['0']
			title = Ny03TjaY7bBxWwm2GI+' :'+name
			if type=='ALL_ITEMS_FILTER': MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,url,434,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,NHEdmMD3qPj4zay2nb5O8xKX)
			elif type=='SPECIFIED_FILTER' and HiGtBb5m673JPE[-2]+'=' in us8FE67ImlDBS:
				GSh0nJxEXgZjd48u7mBwWOeafyAp5b = Ul5KY3BZwA9EGO8j61JfsIquLF(XFJqUiePG7aSf0N,url)
				MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,GSh0nJxEXgZjd48u7mBwWOeafyAp5b,431)
			else: MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,url,435,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,NHEdmMD3qPj4zay2nb5O8xKX)
	return
def W57WXlwPhyrfVu6oij(J6rINOCGlW5M4SXjgwc9U7,mode):
	J6rINOCGlW5M4SXjgwc9U7 = J6rINOCGlW5M4SXjgwc9U7.replace('=&','=0&')
	J6rINOCGlW5M4SXjgwc9U7 = J6rINOCGlW5M4SXjgwc9U7.strip('&')
	hj1lf3cGzLMURVTKkBZmDoyix28 = {}
	if '=' in J6rINOCGlW5M4SXjgwc9U7:
		items = J6rINOCGlW5M4SXjgwc9U7.split('&')
		for tgoJCpq8KGrdaUSjsLh0FTxDRPfIAB in items:
			VRcGtBaO1xun,Y8aiFZsLKw = tgoJCpq8KGrdaUSjsLh0FTxDRPfIAB.split('=')
			hj1lf3cGzLMURVTKkBZmDoyix28[VRcGtBaO1xun] = Y8aiFZsLKw
	sBF1epSJZbIUAgM4hVLPD50 = b8Qe150xVaJsnDSv
	for key in cEjiOo6IGCD2pAzJ4B9bkmXYT:
		if key in list(hj1lf3cGzLMURVTKkBZmDoyix28.keys()): Y8aiFZsLKw = hj1lf3cGzLMURVTKkBZmDoyix28[key]
		else: Y8aiFZsLKw = '0'
		if '%' not in Y8aiFZsLKw: Y8aiFZsLKw = HHbaVYqFRy6v0c(Y8aiFZsLKw)
		if mode=='modified_values' and Y8aiFZsLKw!='0': sBF1epSJZbIUAgM4hVLPD50 = sBF1epSJZbIUAgM4hVLPD50+' + '+Y8aiFZsLKw
		elif mode=='modified_filters' and Y8aiFZsLKw!='0': sBF1epSJZbIUAgM4hVLPD50 = sBF1epSJZbIUAgM4hVLPD50+'&'+key+'='+Y8aiFZsLKw
		elif mode=='all_filters': sBF1epSJZbIUAgM4hVLPD50 = sBF1epSJZbIUAgM4hVLPD50+'&'+key+'='+Y8aiFZsLKw
	sBF1epSJZbIUAgM4hVLPD50 = sBF1epSJZbIUAgM4hVLPD50.strip(' + ')
	sBF1epSJZbIUAgM4hVLPD50 = sBF1epSJZbIUAgM4hVLPD50.strip('&')
	sBF1epSJZbIUAgM4hVLPD50 = sBF1epSJZbIUAgM4hVLPD50.replace('=0','=')
	return sBF1epSJZbIUAgM4hVLPD50
# -*- coding: utf-8 -*-
from hIVCFnfxSO import *
QQ8pvXNcBfVkP5rRJ7o = 'YOUTUBE'
WbzmKSZiuOYrBN7oysJ2dUv = '_YUT_'
wQjs1XZ3AO24g8y9bEeoKMiGIu7 = nTHXJIiah2qK[QQ8pvXNcBfVkP5rRJ7o][0]
NdoRY7MGVt = 0
def x8IFqMZeJj7suCR4AaGoNXfEHm(mode,url,text,type,NGQDwOCXx1BZmd9Huc,name,I6YPOSofrpnTwRm8b):
	if	 mode==140: XXxlOLJ9KRjPH382WVCvr6n71 = Y72YmLgw4vqlHxTCkbeKSicasD()
	elif mode==141: XXxlOLJ9KRjPH382WVCvr6n71 = mt5cKxYQP3vs(url,name,I6YPOSofrpnTwRm8b)
	elif mode==143: XXxlOLJ9KRjPH382WVCvr6n71 = Hkij627uCDJKyIM(url,type)
	elif mode==144: XXxlOLJ9KRjPH382WVCvr6n71 = Je4TwC30iOG5DLKWAtbYvhs(url,NGQDwOCXx1BZmd9Huc,text)
	elif mode==145: XXxlOLJ9KRjPH382WVCvr6n71 = rphSUzZN2awRHuO4in96MgtFId3q(url,NGQDwOCXx1BZmd9Huc)
	elif mode==147: XXxlOLJ9KRjPH382WVCvr6n71 = gjKrtSad1lpq9kJOMcV6H7xzbTn()
	elif mode==148: XXxlOLJ9KRjPH382WVCvr6n71 = GDJk6wgeT7dv()
	elif mode==149: XXxlOLJ9KRjPH382WVCvr6n71 = kstJfK6jHQWrXDSMRIGB7(text)
	else: XXxlOLJ9KRjPH382WVCvr6n71 = False
	return XXxlOLJ9KRjPH382WVCvr6n71
def Y72YmLgw4vqlHxTCkbeKSicasD():
	if 0:
		MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'قائمة 1',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/playlist?list=PLDJPKWWTSFaaGNjpDcPUsWZJVePmAYk_E&pp=iAQB',144)
		MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'قائمة 2',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/playlist?list=PLAj5Gs8FH8ZnUbF0RV-7G3BoqIyZA4uSA',144)
		MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'شخص',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/user/TCNofficial',144)
		MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'موقع',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/channel/UCq59aGNsq9bbhwVTq1Utvgw',144)
		MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'حساب',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/@TheSocialCTV',144)
		MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'العاب',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/gaming',144)
		MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'افلام',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/feed/storefront',144)
		MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'مختارات',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/feed/guide_builder',144)
		MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'قصيرة',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/shorts',144,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'_REMEMBERRESULTS_')
		MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'تصفح',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/youtubei/v1/guide?key=',144)
		MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'رئيسية',wQjs1XZ3AO24g8y9bEeoKMiGIu7+b8Qe150xVaJsnDSv,144)
		MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'رائج',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/feed/trending?bp=',144)
		MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+' ===== ===== ===== '+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999)
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'بحث في الموقع',b8Qe150xVaJsnDSv,149,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'_REMEMBERRESULTS_')
	MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+' ===== ===== ===== '+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999)
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'الرائجة',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/feed/trending',144)
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'التصفح',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/youtubei/v1/guide?key=',144)
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'القصيرة',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/shorts',144,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'_REMEMBERRESULTS_')
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'مختارات يوتيوب',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/feed/guide_builder',144)
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'مختارات البرنامج',b8Qe150xVaJsnDSv,290)
	MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+' ===== ===== ===== '+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999)
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'بحث: قنوات عربية',b8Qe150xVaJsnDSv,147)
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'بحث: قنوات أجنبية',b8Qe150xVaJsnDSv,148)
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'بحث: افلام عربية',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/results?search_query=فيلم',144)
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'بحث: افلام اجنبية',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/results?search_query=movie',144)
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'بحث: مسرحيات عربية',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/results?search_query=مسرحية',144)
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'بحث: مسلسلات عربية',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/results?search_query=مسلسل&sp=EgIQAw==',144)
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'بحث: مسلسلات اجنبية',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/results?search_query=series&sp=EgIQAw==',144)
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'بحث: مسلسلات كارتون',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/results?search_query=كارتون&sp=EgIQAw==',144)
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'بحث: خطبة المرجعية',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/results?search_query=قناة+كربلاء+الفضائية+خطبة+الجمعة&sp=CAISAhAB',144)
	return
def mt5cKxYQP3vs(url,name,I6YPOSofrpnTwRm8b):
	name = dIAn5x3eGWtEVMfHQKoN8g(name)
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'CHNL:  '+name,url,144,I6YPOSofrpnTwRm8b)
	return
def gjKrtSad1lpq9kJOMcV6H7xzbTn():
	Je4TwC30iOG5DLKWAtbYvhs(wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/results?search_query=قناة+بث&sp=EgJAAQ==')
	return
def GDJk6wgeT7dv():
	Je4TwC30iOG5DLKWAtbYvhs(wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/results?search_query=tv&sp=EgJAAQ==')
	return
def Hkij627uCDJKyIM(url,type):
	url = url.split('&',1)[0]
	import QNeGEq8sWn
	QNeGEq8sWn.nqu2GCT9gHAbpIPSFZz5([url],QQ8pvXNcBfVkP5rRJ7o,type,url)
	return
def Sfi5NX0hbvBsmKEaQg4LP(bdk7Tj9rCsoIeGNvt6VF80mzM,url,tmaChESsDcO9dxLW4GQb):
	level,MbHwEh9aSAdDGoy6K4z3,oJndPH29UuAO,DROCbfxPgqnYGuJMV2jleLF = tmaChESsDcO9dxLW4GQb.split('::')
	pj0lTSamoCFfzGyIBPx,Q7W1yNtLIVzuFChv4YlOcDR5iojfJ = [],[]
	if '/youtubei/v1/browse' in url: pj0lTSamoCFfzGyIBPx.append("yccc['onResponseReceivedActions']")
	if '/youtubei/v1/search' in url: pj0lTSamoCFfzGyIBPx.append("yccc['onResponseReceivedCommands']")
	pj0lTSamoCFfzGyIBPx.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs'][0]['tabRenderer']['content']['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['playlistVideoListRenderer']['contents']")
	if level=='1': pj0lTSamoCFfzGyIBPx.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs'][0]['tabRenderer']['content']['richGridRenderer']['header']['feedFilterChipBarRenderer']['contents']")
	pj0lTSamoCFfzGyIBPx.append("yccc['contents']['twoColumnWatchNextResults']['playlist']['playlist']['contents']")
	pj0lTSamoCFfzGyIBPx.append("yccc['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['contents']")
	pj0lTSamoCFfzGyIBPx.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs']")
	pj0lTSamoCFfzGyIBPx.append("yccc['entries']")
	pj0lTSamoCFfzGyIBPx.append("yccc['items'][3]['guideSectionRenderer']['items']")
	uJ9bAGMoPmqZT7nyWV,DDXTxdkSNAIuB4UsFbRQ1t3hqrymLP,UNQLweimEYRxGM = JJM9563yznCwEeUm0j1THW(bdk7Tj9rCsoIeGNvt6VF80mzM,b8Qe150xVaJsnDSv,pj0lTSamoCFfzGyIBPx)
	if level=='1' and uJ9bAGMoPmqZT7nyWV:
		if len(DDXTxdkSNAIuB4UsFbRQ1t3hqrymLP)>1 and 'search_query' not in url:
			for nEBd3XP4IHqN0MyQozeuCbxVhRa2S in range(len(DDXTxdkSNAIuB4UsFbRQ1t3hqrymLP)):
				MbHwEh9aSAdDGoy6K4z3 = str(nEBd3XP4IHqN0MyQozeuCbxVhRa2S)
				pj0lTSamoCFfzGyIBPx = []
				pj0lTSamoCFfzGyIBPx.append("yddd["+MbHwEh9aSAdDGoy6K4z3+"]['reloadContinuationItemsCommand']['continuationItems']")
				pj0lTSamoCFfzGyIBPx.append("yddd["+MbHwEh9aSAdDGoy6K4z3+"]['command']")
				pj0lTSamoCFfzGyIBPx.append("yddd["+MbHwEh9aSAdDGoy6K4z3+"]")
				ip6CohvO5Tya9mFWVf3JdY1qL,tgoJCpq8KGrdaUSjsLh0FTxDRPfIAB,sWCftVuO3gyXJ1UK4T = JJM9563yznCwEeUm0j1THW(DDXTxdkSNAIuB4UsFbRQ1t3hqrymLP,b8Qe150xVaJsnDSv,pj0lTSamoCFfzGyIBPx)
				if ip6CohvO5Tya9mFWVf3JdY1qL: Q7W1yNtLIVzuFChv4YlOcDR5iojfJ.append([tgoJCpq8KGrdaUSjsLh0FTxDRPfIAB,url,'2::'+MbHwEh9aSAdDGoy6K4z3+'::0::0'])
			pj0lTSamoCFfzGyIBPx.append("yccc['continuationEndpoint']")
			ip6CohvO5Tya9mFWVf3JdY1qL,tgoJCpq8KGrdaUSjsLh0FTxDRPfIAB,sWCftVuO3gyXJ1UK4T = JJM9563yznCwEeUm0j1THW(bdk7Tj9rCsoIeGNvt6VF80mzM,b8Qe150xVaJsnDSv,pj0lTSamoCFfzGyIBPx)
			if ip6CohvO5Tya9mFWVf3JdY1qL and Q7W1yNtLIVzuFChv4YlOcDR5iojfJ and 'continuationCommand' in list(tgoJCpq8KGrdaUSjsLh0FTxDRPfIAB.keys()):
				pcA1dzy7LXwGfMPg9mTkuh5tine3 = wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/my_main_page_shorts_link'
				Q7W1yNtLIVzuFChv4YlOcDR5iojfJ.append([tgoJCpq8KGrdaUSjsLh0FTxDRPfIAB,pcA1dzy7LXwGfMPg9mTkuh5tine3,'1::0::0::0'])
	return DDXTxdkSNAIuB4UsFbRQ1t3hqrymLP,uJ9bAGMoPmqZT7nyWV,Q7W1yNtLIVzuFChv4YlOcDR5iojfJ,UNQLweimEYRxGM
def nOHWtAr8w4Ia7iV0e6uLvjf(bdk7Tj9rCsoIeGNvt6VF80mzM,DDXTxdkSNAIuB4UsFbRQ1t3hqrymLP,url,tmaChESsDcO9dxLW4GQb):
	level,MbHwEh9aSAdDGoy6K4z3,oJndPH29UuAO,DROCbfxPgqnYGuJMV2jleLF = tmaChESsDcO9dxLW4GQb.split('::')
	pj0lTSamoCFfzGyIBPx,s6k7H3PImdw0uGUOc = [],[]
	pj0lTSamoCFfzGyIBPx.append("yddd[0]['itemSectionRenderer']['contents']")
	pj0lTSamoCFfzGyIBPx.append("yddd["+MbHwEh9aSAdDGoy6K4z3+"]['reloadContinuationItemsCommand']['continuationItems']")
	pj0lTSamoCFfzGyIBPx.append("yddd[1]['reloadContinuationItemsCommand']['continuationItems']")
	if '/youtubei/v1/browse' in url: pj0lTSamoCFfzGyIBPx.append("yddd[0]['appendContinuationItemsAction']['continuationItems']")
	elif '/youtubei/v1/search' in url: pj0lTSamoCFfzGyIBPx.append("yddd[0]['appendContinuationItemsAction']['continuationItems'][0]['itemSectionRenderer']['contents']")
	pj0lTSamoCFfzGyIBPx.append("yddd["+MbHwEh9aSAdDGoy6K4z3+"]['tabRenderer']['content']['sectionListRenderer']['contents']")
	if '/videos' in url or ('/shorts' in url and '/shorts/' not in url):
		pj0lTSamoCFfzGyIBPx.append("yddd["+MbHwEh9aSAdDGoy6K4z3+"]['tabRenderer']['content']['richGridRenderer']['header']['feedFilterChipBarRenderer']['contents']")
	pj0lTSamoCFfzGyIBPx.append("yddd["+MbHwEh9aSAdDGoy6K4z3+"]['tabRenderer']['content']['richGridRenderer']['contents']")
	pj0lTSamoCFfzGyIBPx.append("yddd["+MbHwEh9aSAdDGoy6K4z3+"]['expandableTabRenderer']['content']['sectionListRenderer']['contents']")
	pj0lTSamoCFfzGyIBPx.append("yddd["+MbHwEh9aSAdDGoy6K4z3+"]['richSectionRenderer']['content']['richShelfRenderer']['contents']")
	pj0lTSamoCFfzGyIBPx.append("yddd["+MbHwEh9aSAdDGoy6K4z3+"]")
	dlHXEYsP6Gk3jRAnTfqaeQtv2,aCwGRWo6vkHImtr7J3As,WHuLTeZCB6 = JJM9563yznCwEeUm0j1THW(DDXTxdkSNAIuB4UsFbRQ1t3hqrymLP,b8Qe150xVaJsnDSv,pj0lTSamoCFfzGyIBPx)
	if level=='2' and dlHXEYsP6Gk3jRAnTfqaeQtv2:
		if len(aCwGRWo6vkHImtr7J3As)>1:
			for nEBd3XP4IHqN0MyQozeuCbxVhRa2S in range(len(aCwGRWo6vkHImtr7J3As)):
				oJndPH29UuAO = str(nEBd3XP4IHqN0MyQozeuCbxVhRa2S)
				pj0lTSamoCFfzGyIBPx = []
				pj0lTSamoCFfzGyIBPx.append("yeee["+oJndPH29UuAO+"]['richSectionRenderer']['content']")
				pj0lTSamoCFfzGyIBPx.append("yeee["+oJndPH29UuAO+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['header']")
				pj0lTSamoCFfzGyIBPx.append("yeee["+oJndPH29UuAO+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
				pj0lTSamoCFfzGyIBPx.append("yeee["+oJndPH29UuAO+"]['itemSectionRenderer']['contents'][0]")
				pj0lTSamoCFfzGyIBPx.append("yeee["+oJndPH29UuAO+"]['richItemRenderer']['content']")
				pj0lTSamoCFfzGyIBPx.append("yeee["+oJndPH29UuAO+"]")
				ip6CohvO5Tya9mFWVf3JdY1qL,tgoJCpq8KGrdaUSjsLh0FTxDRPfIAB,sWCftVuO3gyXJ1UK4T = JJM9563yznCwEeUm0j1THW(aCwGRWo6vkHImtr7J3As,b8Qe150xVaJsnDSv,pj0lTSamoCFfzGyIBPx)
				if ip6CohvO5Tya9mFWVf3JdY1qL: s6k7H3PImdw0uGUOc.append([tgoJCpq8KGrdaUSjsLh0FTxDRPfIAB,url,'3::'+MbHwEh9aSAdDGoy6K4z3+'::'+oJndPH29UuAO+'::0'])
			pj0lTSamoCFfzGyIBPx.append("yddd[0]['appendContinuationItemsAction']['continuationItems'][1]")
			pj0lTSamoCFfzGyIBPx.append("yddd[1]")
			ip6CohvO5Tya9mFWVf3JdY1qL,tgoJCpq8KGrdaUSjsLh0FTxDRPfIAB,sWCftVuO3gyXJ1UK4T = JJM9563yznCwEeUm0j1THW(DDXTxdkSNAIuB4UsFbRQ1t3hqrymLP,b8Qe150xVaJsnDSv,pj0lTSamoCFfzGyIBPx)
			if ip6CohvO5Tya9mFWVf3JdY1qL and s6k7H3PImdw0uGUOc and 'continuationItemRenderer' in list(tgoJCpq8KGrdaUSjsLh0FTxDRPfIAB.keys()):
				s6k7H3PImdw0uGUOc.append([tgoJCpq8KGrdaUSjsLh0FTxDRPfIAB,url,'3::0::0::0'])
	return aCwGRWo6vkHImtr7J3As,dlHXEYsP6Gk3jRAnTfqaeQtv2,s6k7H3PImdw0uGUOc,WHuLTeZCB6
def RLtPo8DUnwK7VOdXQvxiq32e45NG(bdk7Tj9rCsoIeGNvt6VF80mzM,aCwGRWo6vkHImtr7J3As,url,tmaChESsDcO9dxLW4GQb):
	level,MbHwEh9aSAdDGoy6K4z3,oJndPH29UuAO,DROCbfxPgqnYGuJMV2jleLF = tmaChESsDcO9dxLW4GQb.split('::')
	pj0lTSamoCFfzGyIBPx,pgnu7WQBJrmiOd4yvKNxP1aD9M = [],[]
	pj0lTSamoCFfzGyIBPx.append("yeee["+oJndPH29UuAO+"]['shelfRenderer']['content']['verticalListRenderer']['items']")
	pj0lTSamoCFfzGyIBPx.append("yeee["+oJndPH29UuAO+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalMovieListRenderer']['items']")
	pj0lTSamoCFfzGyIBPx.append("yeee["+oJndPH29UuAO+"]['itemSectionRenderer']['contents'][0]['reelShelfRenderer']['items']")
	pj0lTSamoCFfzGyIBPx.append("yeee["+oJndPH29UuAO+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	pj0lTSamoCFfzGyIBPx.append("yeee["+oJndPH29UuAO+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalListRenderer']['items']")
	pj0lTSamoCFfzGyIBPx.append("yeee["+oJndPH29UuAO+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['expandedShelfContentsRenderer']['items']")
	pj0lTSamoCFfzGyIBPx.append("yeee["+oJndPH29UuAO+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
	pj0lTSamoCFfzGyIBPx.append("yeee["+oJndPH29UuAO+"]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	pj0lTSamoCFfzGyIBPx.append("yeee[0]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	pj0lTSamoCFfzGyIBPx.append("yeee[0]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	pj0lTSamoCFfzGyIBPx.append("yeee[0]['itemSectionRenderer']['contents'][0]['playlistVideoListRenderer']['contents']")
	pj0lTSamoCFfzGyIBPx.append("yeee["+oJndPH29UuAO+"]['reelShelfRenderer']['items']")
	pj0lTSamoCFfzGyIBPx.append("yeee["+oJndPH29UuAO+"]['richSectionRenderer']['content']['richShelfRenderer']['contents']")
	pj0lTSamoCFfzGyIBPx.append("yeee")
	Wyp51lSvPrK,CHQ8VMThNfnuK4m5ezSbvkU2Lp10,IIeaTjybx2 = JJM9563yznCwEeUm0j1THW(aCwGRWo6vkHImtr7J3As,b8Qe150xVaJsnDSv,pj0lTSamoCFfzGyIBPx)
	if level=='3' and Wyp51lSvPrK:
		if len(CHQ8VMThNfnuK4m5ezSbvkU2Lp10)>0:
			for nEBd3XP4IHqN0MyQozeuCbxVhRa2S in range(len(CHQ8VMThNfnuK4m5ezSbvkU2Lp10)):
				DROCbfxPgqnYGuJMV2jleLF = str(nEBd3XP4IHqN0MyQozeuCbxVhRa2S)
				pj0lTSamoCFfzGyIBPx = []
				pj0lTSamoCFfzGyIBPx.append("yfff["+DROCbfxPgqnYGuJMV2jleLF+"]['richItemRenderer']['content']")
				pj0lTSamoCFfzGyIBPx.append("yfff["+DROCbfxPgqnYGuJMV2jleLF+"]['gameCardRenderer']['game']")
				pj0lTSamoCFfzGyIBPx.append("yfff["+DROCbfxPgqnYGuJMV2jleLF+"]['itemSectionRenderer']['contents'][0]")
				pj0lTSamoCFfzGyIBPx.append("yfff["+DROCbfxPgqnYGuJMV2jleLF+"]")
				pj0lTSamoCFfzGyIBPx.append("yfff")
				ip6CohvO5Tya9mFWVf3JdY1qL,tgoJCpq8KGrdaUSjsLh0FTxDRPfIAB,sWCftVuO3gyXJ1UK4T = JJM9563yznCwEeUm0j1THW(CHQ8VMThNfnuK4m5ezSbvkU2Lp10,b8Qe150xVaJsnDSv,pj0lTSamoCFfzGyIBPx)
				if ip6CohvO5Tya9mFWVf3JdY1qL: pgnu7WQBJrmiOd4yvKNxP1aD9M.append([tgoJCpq8KGrdaUSjsLh0FTxDRPfIAB,url,'4::'+MbHwEh9aSAdDGoy6K4z3+'::'+oJndPH29UuAO+'::'+DROCbfxPgqnYGuJMV2jleLF])
	return CHQ8VMThNfnuK4m5ezSbvkU2Lp10,Wyp51lSvPrK,pgnu7WQBJrmiOd4yvKNxP1aD9M,IIeaTjybx2
def JJM9563yznCwEeUm0j1THW(ZQVWXszwbyp2fhiSA9kUGN5dFT7C,HzrMfS9DkQn5jV4xbTOs,KSaMRh9Q0lBJb):
	bdk7Tj9rCsoIeGNvt6VF80mzM,HzrMfS9DkQn5jV4xbTOs = ZQVWXszwbyp2fhiSA9kUGN5dFT7C,HzrMfS9DkQn5jV4xbTOs
	DDXTxdkSNAIuB4UsFbRQ1t3hqrymLP,HzrMfS9DkQn5jV4xbTOs = ZQVWXszwbyp2fhiSA9kUGN5dFT7C,HzrMfS9DkQn5jV4xbTOs
	aCwGRWo6vkHImtr7J3As,HzrMfS9DkQn5jV4xbTOs = ZQVWXszwbyp2fhiSA9kUGN5dFT7C,HzrMfS9DkQn5jV4xbTOs
	CHQ8VMThNfnuK4m5ezSbvkU2Lp10,HzrMfS9DkQn5jV4xbTOs = ZQVWXszwbyp2fhiSA9kUGN5dFT7C,HzrMfS9DkQn5jV4xbTOs
	tgoJCpq8KGrdaUSjsLh0FTxDRPfIAB,hI5C9T6gim = ZQVWXszwbyp2fhiSA9kUGN5dFT7C,HzrMfS9DkQn5jV4xbTOs
	count = len(KSaMRh9Q0lBJb)
	for s9s45taoNBh60XL1zykOmTK3jJCrE in range(count):
		try:
			tnB3vG6mLSiZrdluFKhTAR4CNacM = eval(KSaMRh9Q0lBJb[s9s45taoNBh60XL1zykOmTK3jJCrE])
			return True,tnB3vG6mLSiZrdluFKhTAR4CNacM,s9s45taoNBh60XL1zykOmTK3jJCrE+1
		except: pass
	return False,b8Qe150xVaJsnDSv,0
def Je4TwC30iOG5DLKWAtbYvhs(url,tmaChESsDcO9dxLW4GQb=b8Qe150xVaJsnDSv,data=b8Qe150xVaJsnDSv):
	Q7W1yNtLIVzuFChv4YlOcDR5iojfJ,s6k7H3PImdw0uGUOc,pgnu7WQBJrmiOd4yvKNxP1aD9M = [],[],[]
	if '::' not in tmaChESsDcO9dxLW4GQb: tmaChESsDcO9dxLW4GQb = '1::0::0::0'
	level,MbHwEh9aSAdDGoy6K4z3,oJndPH29UuAO,DROCbfxPgqnYGuJMV2jleLF = tmaChESsDcO9dxLW4GQb.split('::')
	if level=='4': level,MbHwEh9aSAdDGoy6K4z3,oJndPH29UuAO,DROCbfxPgqnYGuJMV2jleLF = '1',MbHwEh9aSAdDGoy6K4z3,oJndPH29UuAO,DROCbfxPgqnYGuJMV2jleLF
	data = data.replace('_REMEMBERRESULTS_',b8Qe150xVaJsnDSv)
	jLtdbeYiQHnf4SpU2MTly,bdk7Tj9rCsoIeGNvt6VF80mzM,EEkjQFxOabod08Nr = tIOCLY6PQ1u9sjcny8HKqdDgfbkX(url,data)
	tmaChESsDcO9dxLW4GQb = level+'::'+MbHwEh9aSAdDGoy6K4z3+'::'+oJndPH29UuAO+'::'+DROCbfxPgqnYGuJMV2jleLF
	if level in ['1','2','3']:
		DDXTxdkSNAIuB4UsFbRQ1t3hqrymLP,uJ9bAGMoPmqZT7nyWV,Q7W1yNtLIVzuFChv4YlOcDR5iojfJ,UNQLweimEYRxGM = Sfi5NX0hbvBsmKEaQg4LP(bdk7Tj9rCsoIeGNvt6VF80mzM,url,tmaChESsDcO9dxLW4GQb)
		if not uJ9bAGMoPmqZT7nyWV: return
		vahKXMJqIAdSsrN = len(Q7W1yNtLIVzuFChv4YlOcDR5iojfJ)
		if vahKXMJqIAdSsrN<2:
			if level=='1': level = '2'
			Q7W1yNtLIVzuFChv4YlOcDR5iojfJ = []
	tmaChESsDcO9dxLW4GQb = level+'::'+MbHwEh9aSAdDGoy6K4z3+'::'+oJndPH29UuAO+'::'+DROCbfxPgqnYGuJMV2jleLF
	if level in ['2','3']:
		aCwGRWo6vkHImtr7J3As,dlHXEYsP6Gk3jRAnTfqaeQtv2,s6k7H3PImdw0uGUOc,WHuLTeZCB6 = nOHWtAr8w4Ia7iV0e6uLvjf(bdk7Tj9rCsoIeGNvt6VF80mzM,DDXTxdkSNAIuB4UsFbRQ1t3hqrymLP,url,tmaChESsDcO9dxLW4GQb)
		if not dlHXEYsP6Gk3jRAnTfqaeQtv2: return
		yyUMH5a6LjzheVEFTrOs8kdPu01m = len(s6k7H3PImdw0uGUOc)
		if yyUMH5a6LjzheVEFTrOs8kdPu01m<2:
			if level=='2': level = '3'
			s6k7H3PImdw0uGUOc = []
	tmaChESsDcO9dxLW4GQb = level+'::'+MbHwEh9aSAdDGoy6K4z3+'::'+oJndPH29UuAO+'::'+DROCbfxPgqnYGuJMV2jleLF
	if level in ['3']:
		CHQ8VMThNfnuK4m5ezSbvkU2Lp10,Wyp51lSvPrK,pgnu7WQBJrmiOd4yvKNxP1aD9M,IIeaTjybx2 = RLtPo8DUnwK7VOdXQvxiq32e45NG(bdk7Tj9rCsoIeGNvt6VF80mzM,aCwGRWo6vkHImtr7J3As,url,tmaChESsDcO9dxLW4GQb)
		if not Wyp51lSvPrK: return
		FF84iVqzbjBgPLCQNYwTvJ3X1n = len(pgnu7WQBJrmiOd4yvKNxP1aD9M)
	for tgoJCpq8KGrdaUSjsLh0FTxDRPfIAB,url,tmaChESsDcO9dxLW4GQb in Q7W1yNtLIVzuFChv4YlOcDR5iojfJ+s6k7H3PImdw0uGUOc+pgnu7WQBJrmiOd4yvKNxP1aD9M:
		DrCzdglG0ut6YkXp1c5J7BMHwU = OhPE8ZbKrimX0Iun64lk(tgoJCpq8KGrdaUSjsLh0FTxDRPfIAB,url,tmaChESsDcO9dxLW4GQb)
	return
def OhPE8ZbKrimX0Iun64lk(tgoJCpq8KGrdaUSjsLh0FTxDRPfIAB,url=b8Qe150xVaJsnDSv,tmaChESsDcO9dxLW4GQb=b8Qe150xVaJsnDSv):
	if '::' in tmaChESsDcO9dxLW4GQb: level,MbHwEh9aSAdDGoy6K4z3,oJndPH29UuAO,DROCbfxPgqnYGuJMV2jleLF = tmaChESsDcO9dxLW4GQb.split('::')
	else: level,MbHwEh9aSAdDGoy6K4z3,oJndPH29UuAO,DROCbfxPgqnYGuJMV2jleLF = '1','0','0','0'
	ip6CohvO5Tya9mFWVf3JdY1qL,title,pcA1dzy7LXwGfMPg9mTkuh5tine3,lvtGpMZHb9,count,D5taEr6hnuFCcRMpTq4wSoyQOivx,tG7QMH8F06zvVERIbrAidTyx5X1hK,N5nu0JZAaMXz,KKt3ZvXoO9Wp = fdGaUXOyNWAJgt3M1(tgoJCpq8KGrdaUSjsLh0FTxDRPfIAB)
	xMLBRWcjiauQdHK9t23YsUrz = '/videos?' in pcA1dzy7LXwGfMPg9mTkuh5tine3 or '/streams?' in pcA1dzy7LXwGfMPg9mTkuh5tine3 or '/playlists?' in pcA1dzy7LXwGfMPg9mTkuh5tine3
	fu2taQeqLwhr6SCZ7pKJPB8vHNsGic = '/channels?' in pcA1dzy7LXwGfMPg9mTkuh5tine3 or '/shorts?' in pcA1dzy7LXwGfMPg9mTkuh5tine3
	if xMLBRWcjiauQdHK9t23YsUrz or fu2taQeqLwhr6SCZ7pKJPB8vHNsGic: pcA1dzy7LXwGfMPg9mTkuh5tine3 = url
	xMLBRWcjiauQdHK9t23YsUrz = 'watch?v=' not in pcA1dzy7LXwGfMPg9mTkuh5tine3 and '/playlist?list=' not in pcA1dzy7LXwGfMPg9mTkuh5tine3
	fu2taQeqLwhr6SCZ7pKJPB8vHNsGic = '/gaming' not in pcA1dzy7LXwGfMPg9mTkuh5tine3  and '/feed/storefront' not in pcA1dzy7LXwGfMPg9mTkuh5tine3
	if tmaChESsDcO9dxLW4GQb[0:5]=='3::0::' and xMLBRWcjiauQdHK9t23YsUrz and fu2taQeqLwhr6SCZ7pKJPB8vHNsGic: pcA1dzy7LXwGfMPg9mTkuh5tine3 = url
	if '/youtubei/v1/guide?key=' in url or '/gaming' in pcA1dzy7LXwGfMPg9mTkuh5tine3:
		level,MbHwEh9aSAdDGoy6K4z3,oJndPH29UuAO,DROCbfxPgqnYGuJMV2jleLF = '1','0','0','0'
		tmaChESsDcO9dxLW4GQb = b8Qe150xVaJsnDSv
	EEkjQFxOabod08Nr = b8Qe150xVaJsnDSv
	if '/youtubei/v1/browse' in pcA1dzy7LXwGfMPg9mTkuh5tine3 or '/youtubei/v1/search' in pcA1dzy7LXwGfMPg9mTkuh5tine3 or '/my_main_page_shorts_link' in url:
		data = hRWC8YSFvsm4JHOMVIne3jquZ.getSetting('av.youtube.data')
		if data.count(':::')==4:
			IIdorwqOBVlAX6RUys14hCY,key,ewod03HpgskOFhRXU,KzvbsNldkVZLw86jFa5BxhciMpe3,ee9oNwUnb1RcGzukmpMOfV = data.split(':::')
			EEkjQFxOabod08Nr = IIdorwqOBVlAX6RUys14hCY+':::'+key+':::'+ewod03HpgskOFhRXU+':::'+KzvbsNldkVZLw86jFa5BxhciMpe3+':::'+KKt3ZvXoO9Wp
			if '/my_main_page_shorts_link' in url and not pcA1dzy7LXwGfMPg9mTkuh5tine3: pcA1dzy7LXwGfMPg9mTkuh5tine3 = url
			else: pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3+'?key='+key
	if not title:
		global NdoRY7MGVt
		NdoRY7MGVt += 1
		title = 'فيديوهات '+str(NdoRY7MGVt)
		tmaChESsDcO9dxLW4GQb = '3'+'::'+MbHwEh9aSAdDGoy6K4z3+'::'+oJndPH29UuAO+'::'+DROCbfxPgqnYGuJMV2jleLF
	if not ip6CohvO5Tya9mFWVf3JdY1qL: return False
	elif 'searchPyvRenderer' in str(tgoJCpq8KGrdaUSjsLh0FTxDRPfIAB): return False
	elif '/about' in pcA1dzy7LXwGfMPg9mTkuh5tine3: return False
	elif '/community' in pcA1dzy7LXwGfMPg9mTkuh5tine3: return False
	elif 'continuationItemRenderer' in list(tgoJCpq8KGrdaUSjsLh0FTxDRPfIAB.keys()) or 'continuationCommand' in list(tgoJCpq8KGrdaUSjsLh0FTxDRPfIAB.keys()):
		if int(level)>1: level = str(int(level)-1)
		tmaChESsDcO9dxLW4GQb = level+'::'+MbHwEh9aSAdDGoy6K4z3+'::'+oJndPH29UuAO+'::'+DROCbfxPgqnYGuJMV2jleLF
		MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+':: '+'صفحة أخرى',pcA1dzy7LXwGfMPg9mTkuh5tine3,144,lvtGpMZHb9,tmaChESsDcO9dxLW4GQb,EEkjQFxOabod08Nr)
	elif '/search' in pcA1dzy7LXwGfMPg9mTkuh5tine3:
		title = ':: '+title
		tmaChESsDcO9dxLW4GQb = '3'+'::'+MbHwEh9aSAdDGoy6K4z3+'::'+oJndPH29UuAO+'::'+DROCbfxPgqnYGuJMV2jleLF
		url = url.replace('/search',b8Qe150xVaJsnDSv)
		MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,url,145,b8Qe150xVaJsnDSv,tmaChESsDcO9dxLW4GQb,'_REMEMBERRESULTS_')
	elif 'search_query' in url and not pcA1dzy7LXwGfMPg9mTkuh5tine3:
		tmaChESsDcO9dxLW4GQb = '3'+'::'+MbHwEh9aSAdDGoy6K4z3+'::'+oJndPH29UuAO+'::'+DROCbfxPgqnYGuJMV2jleLF
		title = ':: '+title
		MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,url,144,lvtGpMZHb9,tmaChESsDcO9dxLW4GQb,EEkjQFxOabod08Nr)
	elif '/browse' in pcA1dzy7LXwGfMPg9mTkuh5tine3 and url==wQjs1XZ3AO24g8y9bEeoKMiGIu7:
		title = ':: '+title
		tmaChESsDcO9dxLW4GQb = '2::0::0::0'
		MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,144,lvtGpMZHb9,tmaChESsDcO9dxLW4GQb,EEkjQFxOabod08Nr)
	elif not pcA1dzy7LXwGfMPg9mTkuh5tine3 and 'horizontalMovieListRenderer' in str(tgoJCpq8KGrdaUSjsLh0FTxDRPfIAB):
		title = ':: '+title
		tmaChESsDcO9dxLW4GQb = '3::0::0::0'
		MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,url,144,lvtGpMZHb9,tmaChESsDcO9dxLW4GQb)
	elif 'messageRenderer' in str(tgoJCpq8KGrdaUSjsLh0FTxDRPfIAB):
		MQtuaShrKTbdZFJ5nsR7D('link',WbzmKSZiuOYrBN7oysJ2dUv+title,b8Qe150xVaJsnDSv,9999)
	elif tG7QMH8F06zvVERIbrAidTyx5X1hK:
		MQtuaShrKTbdZFJ5nsR7D('live',WbzmKSZiuOYrBN7oysJ2dUv+tG7QMH8F06zvVERIbrAidTyx5X1hK+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,143,lvtGpMZHb9)
	elif '/playlist?list=' in pcA1dzy7LXwGfMPg9mTkuh5tine3:
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3.replace('&playnext=1',b8Qe150xVaJsnDSv)
		MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'LIST'+count+':  '+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,144,lvtGpMZHb9,tmaChESsDcO9dxLW4GQb)
	elif '/shorts/' in pcA1dzy7LXwGfMPg9mTkuh5tine3:
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3.split('&list=',1)[0]
		MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,143,lvtGpMZHb9,D5taEr6hnuFCcRMpTq4wSoyQOivx)
	elif '/watch?v=' in pcA1dzy7LXwGfMPg9mTkuh5tine3:
		if '&list=' in pcA1dzy7LXwGfMPg9mTkuh5tine3 and count:
			Rbvj6eZisGArz3p1SlBWtaQ49PwDX = pcA1dzy7LXwGfMPg9mTkuh5tine3.split('&list=',1)[1]
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/playlist?list='+Rbvj6eZisGArz3p1SlBWtaQ49PwDX
			tmaChESsDcO9dxLW4GQb = '1::0::0::0'
			MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'LIST'+count+':  '+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,144,lvtGpMZHb9,tmaChESsDcO9dxLW4GQb)
		else:
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3.split('&list=',1)[0]
			MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,143,lvtGpMZHb9,D5taEr6hnuFCcRMpTq4wSoyQOivx)
	elif '/channel/' in pcA1dzy7LXwGfMPg9mTkuh5tine3 or '/c/' in pcA1dzy7LXwGfMPg9mTkuh5tine3 or ('/@' in pcA1dzy7LXwGfMPg9mTkuh5tine3 and pcA1dzy7LXwGfMPg9mTkuh5tine3.count('/')==3):
		if hDTluNxe7tCwrpqXHzdEcYRfbs:
			title = title.decode(OVauxZzLI10vcXT74K).encode('raw_unicode_escape')
			title = ggtn0PzV7aMe(title)
		MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'CHNL'+count+':  '+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,144,lvtGpMZHb9,tmaChESsDcO9dxLW4GQb)
	elif '/user/' in pcA1dzy7LXwGfMPg9mTkuh5tine3:
		MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'USER'+count+':  '+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,144,lvtGpMZHb9,tmaChESsDcO9dxLW4GQb)
	else:
		if not pcA1dzy7LXwGfMPg9mTkuh5tine3: pcA1dzy7LXwGfMPg9mTkuh5tine3 = url
		title = ':: '+title
		MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,144,lvtGpMZHb9,tmaChESsDcO9dxLW4GQb,EEkjQFxOabod08Nr)
	return True
def fdGaUXOyNWAJgt3M1(tgoJCpq8KGrdaUSjsLh0FTxDRPfIAB):
	ip6CohvO5Tya9mFWVf3JdY1qL,title,pcA1dzy7LXwGfMPg9mTkuh5tine3,lvtGpMZHb9,count,D5taEr6hnuFCcRMpTq4wSoyQOivx,tG7QMH8F06zvVERIbrAidTyx5X1hK,N5nu0JZAaMXz,ee9oNwUnb1RcGzukmpMOfV = False,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv
	if not isinstance(tgoJCpq8KGrdaUSjsLh0FTxDRPfIAB,dict): return ip6CohvO5Tya9mFWVf3JdY1qL,title,pcA1dzy7LXwGfMPg9mTkuh5tine3,lvtGpMZHb9,count,D5taEr6hnuFCcRMpTq4wSoyQOivx,tG7QMH8F06zvVERIbrAidTyx5X1hK,N5nu0JZAaMXz,ee9oNwUnb1RcGzukmpMOfV
	for fQU16rTVxBedt7NDgnJXjw in list(tgoJCpq8KGrdaUSjsLh0FTxDRPfIAB.keys()):
		hI5C9T6gim = tgoJCpq8KGrdaUSjsLh0FTxDRPfIAB[fQU16rTVxBedt7NDgnJXjw]
		if isinstance(hI5C9T6gim,dict): break
	pj0lTSamoCFfzGyIBPx = []
	pj0lTSamoCFfzGyIBPx.append("yrender['header']['playlistHeaderRenderer']['title']['simpleText']")
	pj0lTSamoCFfzGyIBPx.append("yrender['header']['richListHeaderRenderer']['title']['simpleText']")
	pj0lTSamoCFfzGyIBPx.append("yrender['header']['richListHeaderRenderer']['title']")
	pj0lTSamoCFfzGyIBPx.append("yrender['headline']['simpleText']")
	pj0lTSamoCFfzGyIBPx.append("yrender['unplayableText']['simpleText']")
	pj0lTSamoCFfzGyIBPx.append("yrender['formattedTitle']['simpleText']")
	pj0lTSamoCFfzGyIBPx.append("yrender['title']['simpleText']")
	pj0lTSamoCFfzGyIBPx.append("yrender['title']['runs'][0]['text']")
	pj0lTSamoCFfzGyIBPx.append("yrender['text']['simpleText']")
	pj0lTSamoCFfzGyIBPx.append("yrender['text']['runs'][0]['text']")
	pj0lTSamoCFfzGyIBPx.append("yrender['title']['content']")
	pj0lTSamoCFfzGyIBPx.append("yrender['title']")
	pj0lTSamoCFfzGyIBPx.append("item['title']")
	pj0lTSamoCFfzGyIBPx.append("item['reelWatchEndpoint']['videoId']")
	ip6CohvO5Tya9mFWVf3JdY1qL,title,sWCftVuO3gyXJ1UK4T = JJM9563yznCwEeUm0j1THW(tgoJCpq8KGrdaUSjsLh0FTxDRPfIAB,hI5C9T6gim,pj0lTSamoCFfzGyIBPx)
	pj0lTSamoCFfzGyIBPx = []
	pj0lTSamoCFfzGyIBPx.append("yrender['title']['runs'][0]['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	pj0lTSamoCFfzGyIBPx.append("yrender['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	pj0lTSamoCFfzGyIBPx.append("yrender['continuationEndpoint']['commandMetadata']['webCommandMetadata']['apiUrl']")
	pj0lTSamoCFfzGyIBPx.append("yrender['navigationEndpoint']['commandMetadata']['webCommandMetadata']['apiUrl']")
	pj0lTSamoCFfzGyIBPx.append("yrender['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	pj0lTSamoCFfzGyIBPx.append("item['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	pj0lTSamoCFfzGyIBPx.append("item['commandMetadata']['webCommandMetadata']['url']")
	ip6CohvO5Tya9mFWVf3JdY1qL,pcA1dzy7LXwGfMPg9mTkuh5tine3,sWCftVuO3gyXJ1UK4T = JJM9563yznCwEeUm0j1THW(tgoJCpq8KGrdaUSjsLh0FTxDRPfIAB,hI5C9T6gim,pj0lTSamoCFfzGyIBPx)
	pj0lTSamoCFfzGyIBPx = []
	pj0lTSamoCFfzGyIBPx.append("yrender['thumbnail']['thumbnails'][0]['url']")
	pj0lTSamoCFfzGyIBPx.append("yrender['thumbnails'][0]['thumbnails'][0]['url']")
	pj0lTSamoCFfzGyIBPx.append("item['reelWatchEndpoint']['thumbnail']['thumbnails'][0]['url']")
	ip6CohvO5Tya9mFWVf3JdY1qL,lvtGpMZHb9,sWCftVuO3gyXJ1UK4T = JJM9563yznCwEeUm0j1THW(tgoJCpq8KGrdaUSjsLh0FTxDRPfIAB,hI5C9T6gim,pj0lTSamoCFfzGyIBPx)
	pj0lTSamoCFfzGyIBPx = []
	pj0lTSamoCFfzGyIBPx.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayBottomPanelRenderer']['text']['runs'][0]['text']")
	pj0lTSamoCFfzGyIBPx.append("yrender['videoCountShortText']['simpleText']")
	pj0lTSamoCFfzGyIBPx.append("yrender['videoCountText']['runs'][0]['text']")
	pj0lTSamoCFfzGyIBPx.append("yrender['videoCount']")
	ip6CohvO5Tya9mFWVf3JdY1qL,count,sWCftVuO3gyXJ1UK4T = JJM9563yznCwEeUm0j1THW(tgoJCpq8KGrdaUSjsLh0FTxDRPfIAB,hI5C9T6gim,pj0lTSamoCFfzGyIBPx)
	pj0lTSamoCFfzGyIBPx = []
	pj0lTSamoCFfzGyIBPx.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['runs'][0]['text']")
	pj0lTSamoCFfzGyIBPx.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['simpleText']")
	pj0lTSamoCFfzGyIBPx.append("yrender['lengthText']['simpleText']")
	pj0lTSamoCFfzGyIBPx.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['icon']['iconType']")
	pj0lTSamoCFfzGyIBPx.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['style']")
	ip6CohvO5Tya9mFWVf3JdY1qL,D5taEr6hnuFCcRMpTq4wSoyQOivx,sWCftVuO3gyXJ1UK4T = JJM9563yznCwEeUm0j1THW(tgoJCpq8KGrdaUSjsLh0FTxDRPfIAB,hI5C9T6gim,pj0lTSamoCFfzGyIBPx)
	pj0lTSamoCFfzGyIBPx = []
	pj0lTSamoCFfzGyIBPx.append("yrender['navigationEndpoint']['continuationCommand']['token']")
	pj0lTSamoCFfzGyIBPx.append("yrender['continuationEndpoint']['continuationCommand']['token']")
	ip6CohvO5Tya9mFWVf3JdY1qL,ee9oNwUnb1RcGzukmpMOfV,sWCftVuO3gyXJ1UK4T = JJM9563yznCwEeUm0j1THW(tgoJCpq8KGrdaUSjsLh0FTxDRPfIAB,hI5C9T6gim,pj0lTSamoCFfzGyIBPx)
	if 'LIVE' in D5taEr6hnuFCcRMpTq4wSoyQOivx: D5taEr6hnuFCcRMpTq4wSoyQOivx,tG7QMH8F06zvVERIbrAidTyx5X1hK = b8Qe150xVaJsnDSv,'LIVE:  '
	if 'مباشر' in D5taEr6hnuFCcRMpTq4wSoyQOivx: D5taEr6hnuFCcRMpTq4wSoyQOivx,tG7QMH8F06zvVERIbrAidTyx5X1hK = b8Qe150xVaJsnDSv,'LIVE:  '
	if 'badges' in list(hI5C9T6gim.keys()):
		QMFaU7KjJxdp3PY5hOrVWcm2fyCD = str(hI5C9T6gim['badges'])
		if 'Free with Ads' in QMFaU7KjJxdp3PY5hOrVWcm2fyCD: N5nu0JZAaMXz = '$:  '
		if 'LIVE' in QMFaU7KjJxdp3PY5hOrVWcm2fyCD: tG7QMH8F06zvVERIbrAidTyx5X1hK = 'LIVE:  '
		if 'Buy' in QMFaU7KjJxdp3PY5hOrVWcm2fyCD or 'Rent' in QMFaU7KjJxdp3PY5hOrVWcm2fyCD: N5nu0JZAaMXz = '$$:  '
		if rfoi91Gyj64WCYJsvc(u'مباشر') in QMFaU7KjJxdp3PY5hOrVWcm2fyCD: tG7QMH8F06zvVERIbrAidTyx5X1hK = 'LIVE:  '
		if rfoi91Gyj64WCYJsvc(u'شراء') in QMFaU7KjJxdp3PY5hOrVWcm2fyCD: N5nu0JZAaMXz = '$$:  '
		if rfoi91Gyj64WCYJsvc(u'استئجار') in QMFaU7KjJxdp3PY5hOrVWcm2fyCD: N5nu0JZAaMXz = '$$:  '
		if rfoi91Gyj64WCYJsvc(u'إعلانات') in QMFaU7KjJxdp3PY5hOrVWcm2fyCD: N5nu0JZAaMXz = '$:  '
	pcA1dzy7LXwGfMPg9mTkuh5tine3 = ggtn0PzV7aMe(pcA1dzy7LXwGfMPg9mTkuh5tine3)
	if pcA1dzy7LXwGfMPg9mTkuh5tine3 and 'http' not in pcA1dzy7LXwGfMPg9mTkuh5tine3: pcA1dzy7LXwGfMPg9mTkuh5tine3 = wQjs1XZ3AO24g8y9bEeoKMiGIu7+pcA1dzy7LXwGfMPg9mTkuh5tine3
	lvtGpMZHb9 = lvtGpMZHb9.split('?')[0]
	if  lvtGpMZHb9 and 'http' not in lvtGpMZHb9: lvtGpMZHb9 = 'https:'+lvtGpMZHb9
	title = ggtn0PzV7aMe(title)
	if N5nu0JZAaMXz: title = N5nu0JZAaMXz+title
	D5taEr6hnuFCcRMpTq4wSoyQOivx = D5taEr6hnuFCcRMpTq4wSoyQOivx.replace(',',b8Qe150xVaJsnDSv)
	count = count.replace(',',b8Qe150xVaJsnDSv)
	count = YYBlm36zd0Jst18LXwo4.findall('\d+',count)
	if count: count = count[0]
	else: count = b8Qe150xVaJsnDSv
	return True,title,pcA1dzy7LXwGfMPg9mTkuh5tine3,lvtGpMZHb9,count,D5taEr6hnuFCcRMpTq4wSoyQOivx,tG7QMH8F06zvVERIbrAidTyx5X1hK,N5nu0JZAaMXz,ee9oNwUnb1RcGzukmpMOfV
def tIOCLY6PQ1u9sjcny8HKqdDgfbkX(url,data=b8Qe150xVaJsnDSv,rC39wAIKjUuS=b8Qe150xVaJsnDSv):
	if rC39wAIKjUuS==b8Qe150xVaJsnDSv: rC39wAIKjUuS = 'ytInitialData'
	quhyD5749GRVfBUTCHZ3t2lpXvWx = kIMmsSG9NW6BOjlTpnEcuRzgwK()
	ybF0H85nUohsiRQcpaTfZAKzjMY7wB = {'User-Agent':quhyD5749GRVfBUTCHZ3t2lpXvWx,'Cookie':'PREF=hl=ar'}
	global hRWC8YSFvsm4JHOMVIne3jquZ
	if not data: data = hRWC8YSFvsm4JHOMVIne3jquZ.getSetting('av.youtube.data')
	if data.count(':::')==4: IIdorwqOBVlAX6RUys14hCY,key,ewod03HpgskOFhRXU,KzvbsNldkVZLw86jFa5BxhciMpe3,ee9oNwUnb1RcGzukmpMOfV = data.split(':::')
	else: IIdorwqOBVlAX6RUys14hCY,key,ewod03HpgskOFhRXU,KzvbsNldkVZLw86jFa5BxhciMpe3,ee9oNwUnb1RcGzukmpMOfV = b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv
	EEkjQFxOabod08Nr = {"context":{"client":{"hl":"ar","clientName":"WEB","clientVersion":ewod03HpgskOFhRXU}}}
	if url==wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/shorts' or '/my_main_page_shorts_link' in url:
		url = wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/youtubei/v1/reel/reel_watch_sequence'+'?key='+key
		EEkjQFxOabod08Nr['sequenceParams'] = IIdorwqOBVlAX6RUys14hCY
		EEkjQFxOabod08Nr = str(EEkjQFxOabod08Nr)
		b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(LtlXH3fvMydAx,'POST',url,EEkjQFxOabod08Nr,ybF0H85nUohsiRQcpaTfZAKzjMY7wB,True,True,'YOUTUBE-GET_PAGE_DATA-1st')
	elif '/guide?key=' in url:
		url = wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/youtubei/v1/guide?key='+key
		EEkjQFxOabod08Nr = str(EEkjQFxOabod08Nr)
		b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(LtlXH3fvMydAx,'POST',url,EEkjQFxOabod08Nr,ybF0H85nUohsiRQcpaTfZAKzjMY7wB,True,True,'YOUTUBE-GET_PAGE_DATA-3rd')
	elif 'key=' in url and IIdorwqOBVlAX6RUys14hCY:
		EEkjQFxOabod08Nr['continuation'] = ee9oNwUnb1RcGzukmpMOfV
		EEkjQFxOabod08Nr['context']['client']['visitorData'] = IIdorwqOBVlAX6RUys14hCY
		EEkjQFxOabod08Nr = str(EEkjQFxOabod08Nr)
		b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(LtlXH3fvMydAx,'POST',url,EEkjQFxOabod08Nr,ybF0H85nUohsiRQcpaTfZAKzjMY7wB,True,True,'YOUTUBE-GET_PAGE_DATA-4th')
	elif 'ctoken=' in url and KzvbsNldkVZLw86jFa5BxhciMpe3:
		ybF0H85nUohsiRQcpaTfZAKzjMY7wB.update({'X-YouTube-Client-Name':'1','X-YouTube-Client-Version':ewod03HpgskOFhRXU})
		ybF0H85nUohsiRQcpaTfZAKzjMY7wB.update({'Cookie':'VISITOR_INFO1_LIVE='+KzvbsNldkVZLw86jFa5BxhciMpe3})
		b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(LtlXH3fvMydAx,'GET',url,b8Qe150xVaJsnDSv,ybF0H85nUohsiRQcpaTfZAKzjMY7wB,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'YOUTUBE-GET_PAGE_DATA-5th')
	else:
		b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(LtlXH3fvMydAx,'GET',url,b8Qe150xVaJsnDSv,ybF0H85nUohsiRQcpaTfZAKzjMY7wB,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'YOUTUBE-GET_PAGE_DATA-6th')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	N6gCa1OZ9HnU2 = YYBlm36zd0Jst18LXwo4.findall('"innertubeApiKey".*?"(.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL|YYBlm36zd0Jst18LXwo4.I)
	if N6gCa1OZ9HnU2: key = N6gCa1OZ9HnU2[0]
	N6gCa1OZ9HnU2 = YYBlm36zd0Jst18LXwo4.findall('"cver".*?"value".*?"(.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL|YYBlm36zd0Jst18LXwo4.I)
	if N6gCa1OZ9HnU2: ewod03HpgskOFhRXU = N6gCa1OZ9HnU2[0]
	N6gCa1OZ9HnU2 = YYBlm36zd0Jst18LXwo4.findall('"visitorData".*?"(.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL|YYBlm36zd0Jst18LXwo4.I)
	if N6gCa1OZ9HnU2: IIdorwqOBVlAX6RUys14hCY = N6gCa1OZ9HnU2[0]
	cookies = b3HKopTY9zLUyhJmt.cookies
	if 'VISITOR_INFO1_LIVE' in list(cookies.keys()): KzvbsNldkVZLw86jFa5BxhciMpe3 = cookies['VISITOR_INFO1_LIVE']
	RnS0DVXIxG6KgBc584Cas9q = IIdorwqOBVlAX6RUys14hCY+':::'+key+':::'+ewod03HpgskOFhRXU+':::'+KzvbsNldkVZLw86jFa5BxhciMpe3+':::'+ee9oNwUnb1RcGzukmpMOfV
	if rC39wAIKjUuS=='ytInitialData' and 'ytInitialData' in jLtdbeYiQHnf4SpU2MTly:
		tiISDW68g53C9bxmT = YYBlm36zd0Jst18LXwo4.findall('window\["ytInitialData"\] = ({.*?});',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if not tiISDW68g53C9bxmT: tiISDW68g53C9bxmT = YYBlm36zd0Jst18LXwo4.findall('var ytInitialData = ({.*?});',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		t1tgUZ4oAyzGpnmT = oJsUwXA0yGOI1mTjxQ('str',tiISDW68g53C9bxmT[0])
	elif rC39wAIKjUuS=='ytInitialGuideData' and 'ytInitialGuideData' in jLtdbeYiQHnf4SpU2MTly:
		tiISDW68g53C9bxmT = YYBlm36zd0Jst18LXwo4.findall('var ytInitialGuideData = ({.*?});',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		t1tgUZ4oAyzGpnmT = oJsUwXA0yGOI1mTjxQ('str',tiISDW68g53C9bxmT[0])
	elif '</script>' not in jLtdbeYiQHnf4SpU2MTly: t1tgUZ4oAyzGpnmT = oJsUwXA0yGOI1mTjxQ('str',jLtdbeYiQHnf4SpU2MTly)
	else: t1tgUZ4oAyzGpnmT = b8Qe150xVaJsnDSv
	if 0:
		bdk7Tj9rCsoIeGNvt6VF80mzM = str(t1tgUZ4oAyzGpnmT)
		if i1thmHk7AZquD4cM0fnp62: bdk7Tj9rCsoIeGNvt6VF80mzM = bdk7Tj9rCsoIeGNvt6VF80mzM.encode(OVauxZzLI10vcXT74K)
		open('S:\\0000emad.dat','wb').write(bdk7Tj9rCsoIeGNvt6VF80mzM)
	hRWC8YSFvsm4JHOMVIne3jquZ.setSetting('av.youtube.data',RnS0DVXIxG6KgBc584Cas9q)
	return jLtdbeYiQHnf4SpU2MTly,t1tgUZ4oAyzGpnmT,RnS0DVXIxG6KgBc584Cas9q
def rphSUzZN2awRHuO4in96MgtFId3q(url,tmaChESsDcO9dxLW4GQb):
	search = FT2oXWtPQpVGuexmLqKN3srdzYn()
	if not search: return
	search = search.replace(pldxivXC5wbTB2O8q,'+')
	MUJCtfYVBLODrFbaZn = url+'/search?query='+search
	Je4TwC30iOG5DLKWAtbYvhs(MUJCtfYVBLODrFbaZn,tmaChESsDcO9dxLW4GQb)
	return
def kstJfK6jHQWrXDSMRIGB7(search):
	search,v7Rxw52Z4X0,showDialogs = JimhUH0SEf6w(search)
	if not search:
		search = FT2oXWtPQpVGuexmLqKN3srdzYn()
		if not search: return
	search = search.replace(pldxivXC5wbTB2O8q,'+')
	MUJCtfYVBLODrFbaZn = wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/results?search_query='+search
	if not showDialogs:
		if '_YOUTUBE-VIDEOS_' in v7Rxw52Z4X0: nnCzEvBgN58iurQmdRIT = '&sp=EgIQAQ%253D%253D'
		elif '_YOUTUBE-PLAYLISTS_' in v7Rxw52Z4X0: nnCzEvBgN58iurQmdRIT = '&sp=EgIQAw%253D%253D'
		elif '_YOUTUBE-CHANNELS_' in v7Rxw52Z4X0: nnCzEvBgN58iurQmdRIT = '&sp=EgIQAg%253D%253D'
		else: nnCzEvBgN58iurQmdRIT = b8Qe150xVaJsnDSv
		GSh0nJxEXgZjd48u7mBwWOeafyAp5b = MUJCtfYVBLODrFbaZn+nnCzEvBgN58iurQmdRIT
	else:
		ccXJMLAvfU1,fYkc4mZvSXM5IQDN0e93W2rwULF1,HoXz65T8ph1CMeZgF = [],[],b8Qe150xVaJsnDSv
		nqTySQ2WFBsZJNzKIhc1tbvprlA = ['فيديوهات مرتبة بالصلة','فيديوهات مرتبة بالتاريخ','فيديوهات مرتبة بعدد المشاهدات','فيديوهات مرتبة بالتقييم','(جيد للمسلسلات) قوائم تشغيل','قنوات','بث حي']
		AmQVfvSeYXnLBHJculRWG = ['&sp=CAASAhAB','&sp=CAISAhAB','&sp=CAMSAhAB','&sp=CAESAhAB','&sp=EgIQAw==','&sp=EgIQAg==','&sp=EgJAAQ==']
		drDghcZ3f50zU = XXprCMzuNP2mElUxfdA('اختر البحث المناسب',nqTySQ2WFBsZJNzKIhc1tbvprlA)
		if drDghcZ3f50zU == -1: return
		VVSQNqdFWBn96YeRwtE = AmQVfvSeYXnLBHJculRWG[drDghcZ3f50zU]
		jLtdbeYiQHnf4SpU2MTly,L7dow8QMgCz,data = tIOCLY6PQ1u9sjcny8HKqdDgfbkX(MUJCtfYVBLODrFbaZn+VVSQNqdFWBn96YeRwtE)
		if L7dow8QMgCz:
			try:
				u6FlkReJy0ZqTSXx28DcnfHKGigb7N = L7dow8QMgCz['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['subMenu']['searchSubMenuRenderer']['groups']
				for xGVToBiadWPzkfr in range(len(u6FlkReJy0ZqTSXx28DcnfHKGigb7N)):
					group = u6FlkReJy0ZqTSXx28DcnfHKGigb7N[xGVToBiadWPzkfr]['searchFilterGroupRenderer']['filters']
					for Jb7fv3pDtkcWyIVUdSnw9 in range(len(group)):
						hI5C9T6gim = group[Jb7fv3pDtkcWyIVUdSnw9]['searchFilterRenderer']
						if 'navigationEndpoint' in list(hI5C9T6gim.keys()):
							pcA1dzy7LXwGfMPg9mTkuh5tine3 = hI5C9T6gim['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']
							pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3.replace('\u0026','&')
							title = hI5C9T6gim['tooltip']
							title = title.replace('البحث عن ',b8Qe150xVaJsnDSv)
							if 'إزالة الفلتر' in title: continue
							if 'قائمة تشغيل' in title:
								title = 'جيد للمسلسلات '+title
								HoXz65T8ph1CMeZgF = title
								eiFs3pQPyZtjb0W = pcA1dzy7LXwGfMPg9mTkuh5tine3
							if 'ترتيب حسب' in title: continue
							title = title.replace('Search for ',b8Qe150xVaJsnDSv)
							if 'Remove' in title: continue
							if 'Playlist' in title:
								title = 'جيد للمسلسلات '+title
								HoXz65T8ph1CMeZgF = title
								eiFs3pQPyZtjb0W = pcA1dzy7LXwGfMPg9mTkuh5tine3
							if 'Sort by' in title: continue
							ccXJMLAvfU1.append(ggtn0PzV7aMe(title))
							fYkc4mZvSXM5IQDN0e93W2rwULF1.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
			except: pass
		if not HoXz65T8ph1CMeZgF: G50K7PTAUQ43ZeIbVap6xFiBdD = b8Qe150xVaJsnDSv
		else:
			ccXJMLAvfU1 = ['بدون فلتر',HoXz65T8ph1CMeZgF]+ccXJMLAvfU1
			fYkc4mZvSXM5IQDN0e93W2rwULF1 = [b8Qe150xVaJsnDSv,eiFs3pQPyZtjb0W]+fYkc4mZvSXM5IQDN0e93W2rwULF1
			HFKsZQicxbqS1a6f = XXprCMzuNP2mElUxfdA('موقع يوتيوب - اختر الفلتر',ccXJMLAvfU1)
			if HFKsZQicxbqS1a6f == -1: return
			G50K7PTAUQ43ZeIbVap6xFiBdD = fYkc4mZvSXM5IQDN0e93W2rwULF1[HFKsZQicxbqS1a6f]
		if G50K7PTAUQ43ZeIbVap6xFiBdD: GSh0nJxEXgZjd48u7mBwWOeafyAp5b = wQjs1XZ3AO24g8y9bEeoKMiGIu7+G50K7PTAUQ43ZeIbVap6xFiBdD
		elif VVSQNqdFWBn96YeRwtE: GSh0nJxEXgZjd48u7mBwWOeafyAp5b = MUJCtfYVBLODrFbaZn+VVSQNqdFWBn96YeRwtE
		else: GSh0nJxEXgZjd48u7mBwWOeafyAp5b = MUJCtfYVBLODrFbaZn
	Je4TwC30iOG5DLKWAtbYvhs(GSh0nJxEXgZjd48u7mBwWOeafyAp5b)
	return
# -*- coding: utf-8 -*-
from hIVCFnfxSO import *
QQ8pvXNcBfVkP5rRJ7o = 'ALARAB'
headers = {'User-Agent':b8Qe150xVaJsnDSv}
WbzmKSZiuOYrBN7oysJ2dUv = '_KLA_'
wQjs1XZ3AO24g8y9bEeoKMiGIu7 = nTHXJIiah2qK[QQ8pvXNcBfVkP5rRJ7o][0]
def x8IFqMZeJj7suCR4AaGoNXfEHm(mode,url,text):
	if   mode==10: XXxlOLJ9KRjPH382WVCvr6n71 = Y72YmLgw4vqlHxTCkbeKSicasD()
	elif mode==11: XXxlOLJ9KRjPH382WVCvr6n71 = Je4TwC30iOG5DLKWAtbYvhs(url)
	elif mode==12: XXxlOLJ9KRjPH382WVCvr6n71 = Hkij627uCDJKyIM(url)
	elif mode==13: XXxlOLJ9KRjPH382WVCvr6n71 = bIpskeGhBlqH(url)
	elif mode==14: XXxlOLJ9KRjPH382WVCvr6n71 = eewcWksvSlYIXTHG5()
	elif mode==15: XXxlOLJ9KRjPH382WVCvr6n71 = HDG4TMacyJ()
	elif mode==16: XXxlOLJ9KRjPH382WVCvr6n71 = HHLQYNbcur()
	elif mode==19: XXxlOLJ9KRjPH382WVCvr6n71 = kstJfK6jHQWrXDSMRIGB7(text)
	else: XXxlOLJ9KRjPH382WVCvr6n71 = False
	return XXxlOLJ9KRjPH382WVCvr6n71
def Y72YmLgw4vqlHxTCkbeKSicasD():
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'بحث في الموقع',b8Qe150xVaJsnDSv,19,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'_REMEMBERRESULTS_')
	MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+' ===== ===== ===== '+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999)
	MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+'آخر الإضافات',b8Qe150xVaJsnDSv,14)
	MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+'مسلسلات رمضان',b8Qe150xVaJsnDSv,15)
	jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(Q49IsrlSuYRAVbGKhwdckLDOetF2PZ,wQjs1XZ3AO24g8y9bEeoKMiGIu7,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,'ALARAB-MENU-1st')
	ZV5rRvabhxJ=YYBlm36zd0Jst18LXwo4.findall('id="nav-slider"(.*?)</div>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	kkbOMqxXtGL40aDTgBjoifhd8K9A = ZV5rRvabhxJ[0]
	items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)".*?>(.*?)<',kkbOMqxXtGL40aDTgBjoifhd8K9A,YYBlm36zd0Jst18LXwo4.DOTALL)
	for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = wQjs1XZ3AO24g8y9bEeoKMiGIu7+pcA1dzy7LXwGfMPg9mTkuh5tine3
		title = title.strip(pldxivXC5wbTB2O8q)
		MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,11)
	MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+' ===== ===== ===== '+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999)
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('id="navbar"(.*?)</div>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	CmEkolxes7Q6hB01fGTPZi4 = ZV5rRvabhxJ[0]
	items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)".*?>(.*?)<',CmEkolxes7Q6hB01fGTPZi4,YYBlm36zd0Jst18LXwo4.DOTALL)
	for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = wQjs1XZ3AO24g8y9bEeoKMiGIu7+pcA1dzy7LXwGfMPg9mTkuh5tine3
		MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,11)
	return jLtdbeYiQHnf4SpU2MTly
def HDG4TMacyJ():
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'جميع المسلسلات العربية',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/view-8/مسلسلات-عربية',11)
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'مسلسلات السنة الأخيرة',b8Qe150xVaJsnDSv,16)
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'مسلسلات رمضان الأخيرة 1',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/view-8/مسلسلات-رمضان-2022',11)
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'مسلسلات رمضان الأخيرة 2',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/view-8/مسلسلات-رمضان-2023',11)
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'مسلسلات رمضان 2023',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/ramadan2023/مصرية',11)
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'مسلسلات رمضان 2022',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/ramadan2022/مصرية',11)
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'مسلسلات رمضان 2021',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/ramadan2021/مصرية',11)
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'مسلسلات رمضان 2020',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/ramadan2020/مصرية',11)
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'مسلسلات رمضان 2019',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/ramadan2019/مصرية',11)
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'مسلسلات رمضان 2018',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/ramadan2018/مصرية',11)
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'مسلسلات رمضان 2017',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/ramadan2017/مصرية',11)
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'مسلسلات رمضان 2016',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/ramadan2016/مصرية',11)
	return
def eewcWksvSlYIXTHG5():
	jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(GMkNL1RXxKFentp0Zh9d,wQjs1XZ3AO24g8y9bEeoKMiGIu7,b8Qe150xVaJsnDSv,headers,True,'ALARAB-LATEST-1st')
	ZV5rRvabhxJ=YYBlm36zd0Jst18LXwo4.findall('heading-top(.*?)div class=',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]+ZV5rRvabhxJ[1]
	items=YYBlm36zd0Jst18LXwo4.findall('href="(.*?)".*?data-src="(.*?)" alt="(.*?)"',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	for pcA1dzy7LXwGfMPg9mTkuh5tine3,lvtGpMZHb9,title in items:
		url = wQjs1XZ3AO24g8y9bEeoKMiGIu7 + pcA1dzy7LXwGfMPg9mTkuh5tine3
		if 'series' in url: MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,url,11,lvtGpMZHb9)
		else: MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+title,url,12,lvtGpMZHb9)
	return
def Je4TwC30iOG5DLKWAtbYvhs(url):
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',url,b8Qe150xVaJsnDSv,headers,True,True,'ALARAB-TITLES-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('video-category(.*?)right_content',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if not ZV5rRvabhxJ: return
	OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
	ap7kVRWP42Dvj0zml6GwC9nu = False
	items = YYBlm36zd0Jst18LXwo4.findall('video-box.*?href="(.*?)".*?src="(http.*?)" alt="(.*?)"',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	d3VSIefbHnvqiut,SqlabXdx6T8zU = [],[]
	for pcA1dzy7LXwGfMPg9mTkuh5tine3,lvtGpMZHb9,title in items:
		if title==b8Qe150xVaJsnDSv: title = pcA1dzy7LXwGfMPg9mTkuh5tine3.split('/')[-1].replace('-',pldxivXC5wbTB2O8q)
		sWCftVuO3gyXJ1UK4T = YYBlm36zd0Jst18LXwo4.findall('(\d+)',title,YYBlm36zd0Jst18LXwo4.DOTALL)
		if sWCftVuO3gyXJ1UK4T: sWCftVuO3gyXJ1UK4T = int(sWCftVuO3gyXJ1UK4T[0])
		else: sWCftVuO3gyXJ1UK4T = 0
		SqlabXdx6T8zU.append([lvtGpMZHb9,pcA1dzy7LXwGfMPg9mTkuh5tine3,title,sWCftVuO3gyXJ1UK4T])
	SqlabXdx6T8zU = sorted(SqlabXdx6T8zU, reverse=True, key=lambda key: key[3])
	for lvtGpMZHb9,pcA1dzy7LXwGfMPg9mTkuh5tine3,title,sWCftVuO3gyXJ1UK4T in SqlabXdx6T8zU:
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = wQjs1XZ3AO24g8y9bEeoKMiGIu7 + pcA1dzy7LXwGfMPg9mTkuh5tine3
		title = title.replace('مشاهدة مسلسل','مسلسل')
		title = title.replace('مشاهدة المسلسل','المسلسل')
		title = title.replace('مشاهدة فيلم','فيلم')
		title = title.replace('مشاهدة الفيلم','الفيلم')
		title = title.replace('مباشرة كواليتي',b8Qe150xVaJsnDSv)
		title = title.replace('عالية على العرب',b8Qe150xVaJsnDSv)
		title = title.replace('مشاهدة مباشرة',b8Qe150xVaJsnDSv)
		title = title.replace('اون لاين',b8Qe150xVaJsnDSv)
		title = title.replace('اونلاين',b8Qe150xVaJsnDSv)
		title = title.replace('بجودة عالية',b8Qe150xVaJsnDSv)
		title = title.replace('جودة عالية',b8Qe150xVaJsnDSv)
		title = title.replace('بدون تحميل',b8Qe150xVaJsnDSv)
		title = title.replace('على العرب',b8Qe150xVaJsnDSv)
		title = title.replace('مباشرة',b8Qe150xVaJsnDSv)
		title = title.strip(pldxivXC5wbTB2O8q).replace(k5bCDErUSmv,pldxivXC5wbTB2O8q).replace(k5bCDErUSmv,pldxivXC5wbTB2O8q)
		title = '_MOD_'+title
		HoXz65T8ph1CMeZgF = title
		if '/q/' in url and ('الحلقة' in title or 'الحلقه' in title):
			HHr42WSgBjAeU7TkQcVaL6yEJz8PF = YYBlm36zd0Jst18LXwo4.findall('(.*?) الحلقة \d+',title,YYBlm36zd0Jst18LXwo4.DOTALL)
			if HHr42WSgBjAeU7TkQcVaL6yEJz8PF: HoXz65T8ph1CMeZgF = HHr42WSgBjAeU7TkQcVaL6yEJz8PF[0]
		if HoXz65T8ph1CMeZgF not in d3VSIefbHnvqiut:
			d3VSIefbHnvqiut.append(HoXz65T8ph1CMeZgF)
			if '/q/' in url and ('الحلقة' in title or 'الحلقه' in title):
				MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+HoXz65T8ph1CMeZgF,pcA1dzy7LXwGfMPg9mTkuh5tine3,13,lvtGpMZHb9)
				ap7kVRWP42Dvj0zml6GwC9nu = True
			elif 'series' in pcA1dzy7LXwGfMPg9mTkuh5tine3:
				MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,11,lvtGpMZHb9)
				ap7kVRWP42Dvj0zml6GwC9nu = True
			else:
				MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,12,lvtGpMZHb9)
				ap7kVRWP42Dvj0zml6GwC9nu = True
	if ap7kVRWP42Dvj0zml6GwC9nu:
		items = YYBlm36zd0Jst18LXwo4.findall('tsc_3d_button red.*?href="(.*?)" title="(.*?)"',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,NGQDwOCXx1BZmd9Huc in items:
			url = wQjs1XZ3AO24g8y9bEeoKMiGIu7 + pcA1dzy7LXwGfMPg9mTkuh5tine3
			MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+NGQDwOCXx1BZmd9Huc,url,11)
	return
def bIpskeGhBlqH(url):
	jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(GMkNL1RXxKFentp0Zh9d,url,b8Qe150xVaJsnDSv,headers,True,'ALARAB-EPISODES-1st')
	r6o4AXjf7CLhF = YYBlm36zd0Jst18LXwo4.findall('href="(/series.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	MUJCtfYVBLODrFbaZn = wQjs1XZ3AO24g8y9bEeoKMiGIu7+r6o4AXjf7CLhF[0]
	XXxlOLJ9KRjPH382WVCvr6n71 = Je4TwC30iOG5DLKWAtbYvhs(MUJCtfYVBLODrFbaZn)
	return
def Hkij627uCDJKyIM(url):
	KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = []
	jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(LtlXH3fvMydAx,url,b8Qe150xVaJsnDSv,headers,True,'ALARAB-PLAY-1st')
	MUJCtfYVBLODrFbaZn = YYBlm36zd0Jst18LXwo4.findall('class="resp-iframe" src="(.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if MUJCtfYVBLODrFbaZn:
		MUJCtfYVBLODrFbaZn = MUJCtfYVBLODrFbaZn[0]
		tzdvaEpMHOCZLXDYg08T = YYBlm36zd0Jst18LXwo4.findall('^(http.*?)(http.*?)$',MUJCtfYVBLODrFbaZn,YYBlm36zd0Jst18LXwo4.DOTALL)
		if tzdvaEpMHOCZLXDYg08T:
			CGQ914dXgqhLswByzFSKEWkPmv8j = tzdvaEpMHOCZLXDYg08T[0][0]
			KOzIDeGrqF0pfoWS79RyZdUua3Q,CYiz7nXBF5V8tLmghs4KyM96bl = tzdvaEpMHOCZLXDYg08T[0][1].rsplit('/',1)
			GSh0nJxEXgZjd48u7mBwWOeafyAp5b = KOzIDeGrqF0pfoWS79RyZdUua3Q+'?named=__watch'
			KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j.append(GSh0nJxEXgZjd48u7mBwWOeafyAp5b)
			ps2ueZoatbCrwq7mIHLiVMPxN9Q = CGQ914dXgqhLswByzFSKEWkPmv8j+CYiz7nXBF5V8tLmghs4KyM96bl
		else:
			vWsMIpk1n6rlLqH52 = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(Q49IsrlSuYRAVbGKhwdckLDOetF2PZ,MUJCtfYVBLODrFbaZn,b8Qe150xVaJsnDSv,headers,False,'ALARAB-PLAY-2nd')
			MUJCtfYVBLODrFbaZn = YYBlm36zd0Jst18LXwo4.findall('"src": "(.*?)"',vWsMIpk1n6rlLqH52,YYBlm36zd0Jst18LXwo4.DOTALL)
			if MUJCtfYVBLODrFbaZn:
				MUJCtfYVBLODrFbaZn = MUJCtfYVBLODrFbaZn[0]+'?named=__watch__m3u8'
				KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j.append(MUJCtfYVBLODrFbaZn)
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('searchBox(.*?)<style>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		MUJCtfYVBLODrFbaZn = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)"',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		if MUJCtfYVBLODrFbaZn:
			MUJCtfYVBLODrFbaZn = MUJCtfYVBLODrFbaZn[0]+'?named=__watch'
			KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j.append(MUJCtfYVBLODrFbaZn)
	import QNeGEq8sWn
	QNeGEq8sWn.nqu2GCT9gHAbpIPSFZz5(KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j,QQ8pvXNcBfVkP5rRJ7o,'video',url)
	return
def HHLQYNbcur():
	jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(Q49IsrlSuYRAVbGKhwdckLDOetF2PZ,wQjs1XZ3AO24g8y9bEeoKMiGIu7,b8Qe150xVaJsnDSv,headers,True,'ALARAB-RAMADAN-1st')
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('id="content_sec"(.*?)id="left_content"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
	items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)".*?>(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	T9tyXnpWOUb2imcFlz = YYBlm36zd0Jst18LXwo4.findall('/ramadan([0-9]+)/',str(items),YYBlm36zd0Jst18LXwo4.DOTALL)
	T9tyXnpWOUb2imcFlz = T9tyXnpWOUb2imcFlz[0]
	for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
		url = wQjs1XZ3AO24g8y9bEeoKMiGIu7+pcA1dzy7LXwGfMPg9mTkuh5tine3
		title = title.strip(pldxivXC5wbTB2O8q)+pldxivXC5wbTB2O8q+T9tyXnpWOUb2imcFlz
		MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,url,11)
	return
def kstJfK6jHQWrXDSMRIGB7(search):
	search,v7Rxw52Z4X0,showDialogs = JimhUH0SEf6w(search)
	if search==b8Qe150xVaJsnDSv: search = FT2oXWtPQpVGuexmLqKN3srdzYn()
	if search==b8Qe150xVaJsnDSv: return
	LgXO1RhbDV7cx6EaeYCNm4zjJdBS = search.replace(pldxivXC5wbTB2O8q,'+')
	url = wQjs1XZ3AO24g8y9bEeoKMiGIu7 + "/q/" + LgXO1RhbDV7cx6EaeYCNm4zjJdBS
	XXxlOLJ9KRjPH382WVCvr6n71 = Je4TwC30iOG5DLKWAtbYvhs(url)
	return
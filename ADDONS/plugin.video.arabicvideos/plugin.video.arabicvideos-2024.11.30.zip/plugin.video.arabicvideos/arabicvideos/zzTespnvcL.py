# -*- coding: utf-8 -*-
import sys as Pft6y0LvwSh48iYg7b
MQBw2uYHcWbpxF8tKAV = Pft6y0LvwSh48iYg7b.version_info [0] == 2
myc93k4htNU67 = 2048
h8lCkw1d3LepDVuvfoicEXj5K6sPz = 7
def JanmRV2MtcH (VwngrDb8fEytv4kMTdQu95cIejsC):
	global oPFYqewitzj
	WBrAFcJPVXdS2UzxLEGM0omkD = ord (VwngrDb8fEytv4kMTdQu95cIejsC [-1])
	V13jmfpwhlcyCKMRLY5TiaG = VwngrDb8fEytv4kMTdQu95cIejsC [:-1]
	gyF4Uq9l1NQKCtT = WBrAFcJPVXdS2UzxLEGM0omkD % len (V13jmfpwhlcyCKMRLY5TiaG)
	BN5pdqozP2v9Ur1Swsia = V13jmfpwhlcyCKMRLY5TiaG [:gyF4Uq9l1NQKCtT] + V13jmfpwhlcyCKMRLY5TiaG [gyF4Uq9l1NQKCtT:]
	if MQBw2uYHcWbpxF8tKAV:
		D3MGYw1ceHQ4UbrNJSq = unicode () .join ([unichr (ord (bb1FgjciZqDzeQTBC2hplaPkmRIyUf) - myc93k4htNU67 - (Ni5bJjhpks6SfCc + WBrAFcJPVXdS2UzxLEGM0omkD) % h8lCkw1d3LepDVuvfoicEXj5K6sPz) for Ni5bJjhpks6SfCc, bb1FgjciZqDzeQTBC2hplaPkmRIyUf in enumerate (BN5pdqozP2v9Ur1Swsia)])
	else:
		D3MGYw1ceHQ4UbrNJSq = str () .join ([chr (ord (bb1FgjciZqDzeQTBC2hplaPkmRIyUf) - myc93k4htNU67 - (Ni5bJjhpks6SfCc + WBrAFcJPVXdS2UzxLEGM0omkD) % h8lCkw1d3LepDVuvfoicEXj5K6sPz) for Ni5bJjhpks6SfCc, bb1FgjciZqDzeQTBC2hplaPkmRIyUf in enumerate (BN5pdqozP2v9Ur1Swsia)])
	return eval (D3MGYw1ceHQ4UbrNJSq)
TYf7Dc06PQgy1vEV9,ubxGUTt1LraKhVZgpAP,Y2t8baH5GWikvOZ7NsCeq3TKrgMV=JanmRV2MtcH,JanmRV2MtcH,JanmRV2MtcH
BWNPxIG7vqdTy85pjHzUOrK3,Mmpr0o76iWJvz1kTtfgI8hES,QTUBCcehw6qPd4x=Y2t8baH5GWikvOZ7NsCeq3TKrgMV,ubxGUTt1LraKhVZgpAP,TYf7Dc06PQgy1vEV9
mQNonhS7CV2BXOv,HwB7ydlWVJeCtPuQ6MDE1RTYOo,uVQd103XyvUce2EBtzbYaC=QTUBCcehw6qPd4x,Mmpr0o76iWJvz1kTtfgI8hES,BWNPxIG7vqdTy85pjHzUOrK3
yST5AHEfvPmcWpwGuh2BJ,BmePGjS7FxK6kutUM,S0IlDPhBN3gMEUvnjRLXsYAc2Zf=uVQd103XyvUce2EBtzbYaC,HwB7ydlWVJeCtPuQ6MDE1RTYOo,mQNonhS7CV2BXOv
Xz3bA2PFENVCUtplu51,LAQD5wEkr18bUiGaYen3J,P0qdZI384LKleuo=S0IlDPhBN3gMEUvnjRLXsYAc2Zf,BmePGjS7FxK6kutUM,yST5AHEfvPmcWpwGuh2BJ
shC5qBRV2A0lZ,mmcNLrXtzfpyCkZlvK5VwG2gujh,m6hwdgP31a2zjN7lkpX=P0qdZI384LKleuo,LAQD5wEkr18bUiGaYen3J,Xz3bA2PFENVCUtplu51
IjZbnrBJmM2N,Nh0BWuiSndf,kke1PDGRBLuY8y=m6hwdgP31a2zjN7lkpX,mmcNLrXtzfpyCkZlvK5VwG2gujh,shC5qBRV2A0lZ
ddo23ZJtgcY,vvWwO3Tx2dAgcijrFXq,DYakr9g4PVU=kke1PDGRBLuY8y,Nh0BWuiSndf,IjZbnrBJmM2N
zI3ROAZtiUq42rE9WDST68,Dzs8qU2gQMcCSyRhiZn4TFbeGk,dDYUoKi6JFM23p=DYakr9g4PVU,vvWwO3Tx2dAgcijrFXq,ddo23ZJtgcY
QQdAXWBc2GPw,VFjQx6Is28KvzLOmMXtg4GqTwa3,TT8Mxv5Wq7nlC9IscdpPUY6=dDYUoKi6JFM23p,Dzs8qU2gQMcCSyRhiZn4TFbeGk,zI3ROAZtiUq42rE9WDST68
SbjiWeHLQPoazqwp3cODkd7YxVgn,UUkIBz1sgQ9WfNeG6trKXvu0,RRIHDFjoW9w7bSfVPhC=TT8Mxv5Wq7nlC9IscdpPUY6,VFjQx6Is28KvzLOmMXtg4GqTwa3,QQdAXWBc2GPw
from hIVCFnfxSO import *
yicQV3gj4q(DYakr9g4PVU(u"ࠨࡖࡈࡗ࡙࠭ሔ"),uVQd103XyvUce2EBtzbYaC(u"ࠩࡗࡉࡘ࡚ࠧሕ"))
iXRADl2M5E = Nh0BWuiSndf(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡭ࡵࡼ࠴࠯ࡦࡲࡻࡳࡲ࡯ࡢࡦ࠱ࡸ࡭࡯࡮࡬ࡤࡵࡳࡦࡪࡢࡢࡰࡧ࠲ࡨࡵ࡭࠰࠳࠳ࡑࡇ࠴ࡺࡪࡲࠪሖ")
iXRADl2M5E = S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡸࡶࡥࡦࡦࡷࡩࡸࡺ࠮ࡧࡶࡳ࠲ࡴࡺࡥ࡯ࡧࡷ࠲࡬ࡸ࠯ࡧ࡫࡯ࡩࡸ࠵ࡴࡦࡵࡷ࠵࠵࠶࡫࠯ࡦࡥࠫሗ")
d0dDAEXWNf(iXRADl2M5E,{},CCxMXuNUEzolDZTKrBJ)
uuNDjbit4hOpx = LAQD5wEkr18bUiGaYen3J(u"ࠬࡉ࠺࡝࡞ࡗࡉࡒࡖ࡜࡝ࡶࡨࡱࡵࡢ࡜ࡢࡣࠣࡦࡧࡢ࡜โฯุ࠲ࡲࡶ࠳ࠨመ")
uuNDjbit4hOpx = Nh0BWuiSndf(u"࠭ࡃ࠻࡞࡟ࡘࡊࡓࡐ࡝࡞ࡷࡩࡲࡶ࡜࡝ࡣࡤࠤࡧࡨ࡜࡝ࡨ࡬ࡰࡪࡥ࠴࠹࠵࠷ࡣࡘࡎࡖࡠิํหึฯ࡟ศๆิืํ๊࡟ศๆฦ฽฽๋࡟ࠩืࠬࡣ࠭ษศศาิࡣฬ๊อๅ๊สะ๏࠯࠮࡮ࡲ࠶ࠫሙ")
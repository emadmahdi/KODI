# -*- coding: utf-8 -*-
from hIVCFnfxSO import *
QQ8pvXNcBfVkP5rRJ7o = 'CIMA4U'
headers = {'User-Agent':b8Qe150xVaJsnDSv}
WbzmKSZiuOYrBN7oysJ2dUv = '_C4U_'
wQjs1XZ3AO24g8y9bEeoKMiGIu7 = nTHXJIiah2qK[QQ8pvXNcBfVkP5rRJ7o][0]
v1vJEhoNQBVPkjG = ['مصارعة حرة','اخري','اخرى','الرئيسية','بدون إختيار','افلام','مسلسلات']
def x8IFqMZeJj7suCR4AaGoNXfEHm(mode,url,text):
	if   mode==420: XXxlOLJ9KRjPH382WVCvr6n71 = Y72YmLgw4vqlHxTCkbeKSicasD()
	elif mode==421: XXxlOLJ9KRjPH382WVCvr6n71 = Je4TwC30iOG5DLKWAtbYvhs(url,text)
	elif mode==422: XXxlOLJ9KRjPH382WVCvr6n71 = u9umIE5RBNelHSkqhArpCnW80(url)
	elif mode==423: XXxlOLJ9KRjPH382WVCvr6n71 = bIpskeGhBlqH(url)
	elif mode==424: XXxlOLJ9KRjPH382WVCvr6n71 = eszTQbMvkmRwCAxGDPdYJUi(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==425: XXxlOLJ9KRjPH382WVCvr6n71 = eszTQbMvkmRwCAxGDPdYJUi(url,'SPECIFIED_FILTER___'+text)
	elif mode==426: XXxlOLJ9KRjPH382WVCvr6n71 = Hkij627uCDJKyIM(url)
	elif mode==427: XXxlOLJ9KRjPH382WVCvr6n71 = BBSmZ6QRHn4CjxN(url)
	elif mode==429: XXxlOLJ9KRjPH382WVCvr6n71 = kstJfK6jHQWrXDSMRIGB7(text)
	else: XXxlOLJ9KRjPH382WVCvr6n71 = False
	return XXxlOLJ9KRjPH382WVCvr6n71
def Y72YmLgw4vqlHxTCkbeKSicasD():
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',wQjs1XZ3AO24g8y9bEeoKMiGIu7,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'CIMA4U-MENU-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	OZSA7QNfeE = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	OZSA7QNfeE = OZSA7QNfeE[0].strip('/')
	OZSA7QNfeE = Wl2eu1PavfQ(OZSA7QNfeE,'url')
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'بحث في الموقع',b8Qe150xVaJsnDSv,429,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'_REMEMBERRESULTS_')
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'فلتر محدد',OZSA7QNfeE,425)
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'فلتر كامل',OZSA7QNfeE,424)
	MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+' ===== ===== ===== '+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999)
	MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+'الرئيسية',OZSA7QNfeE,421)
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('NavigationMenu(.*?)</div>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
	items = YYBlm36zd0Jst18LXwo4.findall('href="*(.*?)"*>(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
		if title in v1vJEhoNQBVPkjG: continue
		if '/actors' in pcA1dzy7LXwGfMPg9mTkuh5tine3: title = 'أفلام النجوم'
		elif '/netflix' in pcA1dzy7LXwGfMPg9mTkuh5tine3: title = 'أفلام ومسلسلات نيتفلكس'
		MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,421)
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'قائمة تفصيلية',OZSA7QNfeE,427)
	return
def BBSmZ6QRHn4CjxN(website=b8Qe150xVaJsnDSv):
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',wQjs1XZ3AO24g8y9bEeoKMiGIu7,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'CIMA4U-MENU-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('FilteringTitle(.*?)PageTitle',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
	items = YYBlm36zd0Jst18LXwo4.findall('data-tax="*(.*?)"* data-id="*(.*?)[">]*<a href="*(.*?)[">]+.*?</div>(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	for Z8s0Lov2UiWF1qGjO,id,pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
		if title in v1vJEhoNQBVPkjG: continue
		if 'netflix-movies' in pcA1dzy7LXwGfMPg9mTkuh5tine3: title = 'أفلام نيتفلكس'
		elif 'series-netflix' in pcA1dzy7LXwGfMPg9mTkuh5tine3: title = 'مسلسلات نيتفلكس'
		MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,421,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,Z8s0Lov2UiWF1qGjO+'|'+id)
	return
def Je4TwC30iOG5DLKWAtbYvhs(url,vI9QYJckeTmfRFV=b8Qe150xVaJsnDSv):
	if '/HomepageLoader/' in url: url = url.strip('/')+'/mpaa/family/'
	items = []
	OZSA7QNfeE = Wl2eu1PavfQ(url,'url')
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',url,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'CIMA4U-TITLES-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	if not vI9QYJckeTmfRFV or '|' in vI9QYJckeTmfRFV:
		if '|' not in vI9QYJckeTmfRFV: djOW5hobpKCyA = b8Qe150xVaJsnDSv
		else: djOW5hobpKCyA = '/archive/'+vI9QYJckeTmfRFV
		ZrBtKnWX8I6PLxF = False
		if 'PinSlider' in jLtdbeYiQHnf4SpU2MTly:
			MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'المميزة',url,421,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'featured')
			ZrBtKnWX8I6PLxF = True
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('PageTitle(.*?)PageContent',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if ZV5rRvabhxJ:
			CmEkolxes7Q6hB01fGTPZi4 = ZV5rRvabhxJ[0]
			xxnATEUzH6Djmq0NrBveh = YYBlm36zd0Jst18LXwo4.findall('data-tab="(.*?)".*?<span>(.*?)<',CmEkolxes7Q6hB01fGTPZi4,YYBlm36zd0Jst18LXwo4.DOTALL)
			for EWUraThxDpqzvsd4webotfmcB,HoXz65T8ph1CMeZgF in xxnATEUzH6Djmq0NrBveh:
				eiFs3pQPyZtjb0W = OZSA7QNfeE+'/ajaxcenter/action/HomepageLoader/tab/'+EWUraThxDpqzvsd4webotfmcB+djOW5hobpKCyA+'/'
				MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+HoXz65T8ph1CMeZgF,eiFs3pQPyZtjb0W,421)
				ZrBtKnWX8I6PLxF = True
		if ZrBtKnWX8I6PLxF: MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+' ===== ===== ===== '+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999)
	if vI9QYJckeTmfRFV=='featured':
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('PinSlider(.*?)MultiFilter',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if not ZV5rRvabhxJ: ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('PinSlider(.*?)PageTitle',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if ZV5rRvabhxJ: OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		else: OTKx7aVb2hdS16Wrweky4FXfIN0g9 = b8Qe150xVaJsnDSv
	elif '/HomepageLoader/' in url or '/searchcenter/' in url:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = jLtdbeYiQHnf4SpU2MTly
	elif '/filter/' in url:
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('PageContent(.*?)class="*pagination"*',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
	elif '/actors' in url:
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('PageContent(.*?)class="*pagination"*',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		items = YYBlm36zd0Jst18LXwo4.findall('href="*(.*?)[">]+.*?image:url\((.*?)\).*?ActorName">(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	else:
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('Cima4uBlocks(.*?)</li></ul>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if ZV5rRvabhxJ: OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		else: OTKx7aVb2hdS16Wrweky4FXfIN0g9 = b8Qe150xVaJsnDSv
	if not items: items = YYBlm36zd0Jst18LXwo4.findall('class="*MovieBlock"*.*?href="*(.*?)[">]+.*?image:url\((.*?)\).*?image.*?BoxTitleInfo.*?</div></div>(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	if not items: items = YYBlm36zd0Jst18LXwo4.findall('class="MovieBlock".*?href="(.*?)".*?data-image="(.*?)".*?alt="(.*?)"',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	d3VSIefbHnvqiut = []
	for pcA1dzy7LXwGfMPg9mTkuh5tine3,lvtGpMZHb9,title in items:
		if not title: continue
		if '?news=' in pcA1dzy7LXwGfMPg9mTkuh5tine3: continue
		title = title.replace('مشاهدة ',b8Qe150xVaJsnDSv)
		title = pTP49ckGDYrofa2KxenumbH0(title)
		HHr42WSgBjAeU7TkQcVaL6yEJz8PF = YYBlm36zd0Jst18LXwo4.findall('(.*?) حلقة \d+',title,YYBlm36zd0Jst18LXwo4.DOTALL)
		if HHr42WSgBjAeU7TkQcVaL6yEJz8PF and 'حلقة' in title:
			title = '_MOD_' + HHr42WSgBjAeU7TkQcVaL6yEJz8PF[0]
			if title not in d3VSIefbHnvqiut:
				MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,422,lvtGpMZHb9)
				d3VSIefbHnvqiut.append(title)
		elif '/actor/' in pcA1dzy7LXwGfMPg9mTkuh5tine3: MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,421,lvtGpMZHb9)
		else: MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,422,lvtGpMZHb9)
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('pagination(.*?)</ul>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ and vI9QYJckeTmfRFV!='featured':
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		items = YYBlm36zd0Jst18LXwo4.findall('href=[\'\"](.*?)[\'\"]>(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
			title = pTP49ckGDYrofa2KxenumbH0(title)
			title = title.replace('الصفحة ',b8Qe150xVaJsnDSv)
			if title!=b8Qe150xVaJsnDSv: MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'صفحة '+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,421)
	SArDcVYZRkXvC4xpaiQIfE35K = YYBlm36zd0Jst18LXwo4.findall('</li><a href="(.*?)".*?>(.*?)<',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if SArDcVYZRkXvC4xpaiQIfE35K:
		pcA1dzy7LXwGfMPg9mTkuh5tine3,title = SArDcVYZRkXvC4xpaiQIfE35K[0]
		MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,421)
	return
def u9umIE5RBNelHSkqhArpCnW80(url):
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'CIMA4U-SEASONS-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('class="WatchNow".*?href="(.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ:
		url = ZV5rRvabhxJ[0]
		b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'CIMA4U-SEASONS-2nd')
		jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('SeasonsSections(.*?)</div></div></div>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if '/tag/' in url or '/actor' in url:
		Je4TwC30iOG5DLKWAtbYvhs(url)
	elif ZV5rRvabhxJ:
		lvtGpMZHb9 = uuxVm0bTwdnCUAL4s6NKHEBF3M.getInfoLabel('ListItem.Thumb')
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		items = YYBlm36zd0Jst18LXwo4.findall("href='(.*?)'>(.*?)<",OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		SyMqxsnH0GuUb9ABwrztJeDNIkhQT = ['مسلسل','موسم','برنامج','حلقة']
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
			if any(Y8aiFZsLKw in title for Y8aiFZsLKw in SyMqxsnH0GuUb9ABwrztJeDNIkhQT):
				MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,423,lvtGpMZHb9)
			else: MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,426,lvtGpMZHb9)
	else: bIpskeGhBlqH(url)
	return
def bIpskeGhBlqH(url):
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'CIMA4U-EPISODES-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	lvtGpMZHb9 = YYBlm36zd0Jst18LXwo4.findall('"background-image:url\((.*?)\)',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if lvtGpMZHb9: lvtGpMZHb9 = lvtGpMZHb9[0]
	else: lvtGpMZHb9 = b8Qe150xVaJsnDSv
	CVR80cUXuqyWZakMh75tF3vTpJE1w = YYBlm36zd0Jst18LXwo4.findall('EpisodesSection(.*?)</ul>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if CVR80cUXuqyWZakMh75tF3vTpJE1w:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = CVR80cUXuqyWZakMh75tF3vTpJE1w[0]
		items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)"><em>(.*?)<.*?<span>(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,title,HHr42WSgBjAeU7TkQcVaL6yEJz8PF in items:
			title = title+pldxivXC5wbTB2O8q+HHr42WSgBjAeU7TkQcVaL6yEJz8PF
			MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,426,lvtGpMZHb9)
	else: MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+'رابط التشغيل',url,426,lvtGpMZHb9)
	return
def Hkij627uCDJKyIM(url):
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',url,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'CIMA4U-PLAY-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	Nkj2OKXtCTgJuV1opzf5q = b3HKopTY9zLUyhJmt.url
	if hDTluNxe7tCwrpqXHzdEcYRfbs: Nkj2OKXtCTgJuV1opzf5q = Nkj2OKXtCTgJuV1opzf5q.encode(OVauxZzLI10vcXT74K)
	OZSA7QNfeE = Wl2eu1PavfQ(Nkj2OKXtCTgJuV1opzf5q,'url')
	KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = []
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('WatchSection(.*?)</div></div>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		items = YYBlm36zd0Jst18LXwo4.findall('data-link="(.*?)".*? />(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for zEO5iu267rjZ1qphcCUvl,title in items:
			title = title.strip(pldxivXC5wbTB2O8q)
			if 'myvid' in title.lower(): title = 'خاص '+title
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = OZSA7QNfeE+'/structure/server.php?id='+zEO5iu267rjZ1qphcCUvl+'?named='+title+'__watch'
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3.replace(d6ekSEojpFUANKJ7r9WTlI3niLBOu,b8Qe150xVaJsnDSv)
			KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('DownloadServers(.*?)</div></div>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)".*? />(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
			title = title.strip(pldxivXC5wbTB2O8q)
			if 'myvid' in title.lower(): HoXz65T8ph1CMeZgF = '__خاص'
			else: HoXz65T8ph1CMeZgF = b8Qe150xVaJsnDSv
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3+'?named='+title+'__download'+HoXz65T8ph1CMeZgF
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3.replace(d6ekSEojpFUANKJ7r9WTlI3niLBOu,b8Qe150xVaJsnDSv)
			KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
	import QNeGEq8sWn
	QNeGEq8sWn.nqu2GCT9gHAbpIPSFZz5(KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j,QQ8pvXNcBfVkP5rRJ7o,'video',url)
	return
def kstJfK6jHQWrXDSMRIGB7(search):
	search,v7Rxw52Z4X0,showDialogs = JimhUH0SEf6w(search)
	if search==b8Qe150xVaJsnDSv: search = FT2oXWtPQpVGuexmLqKN3srdzYn()
	if search==b8Qe150xVaJsnDSv: return
	search = search.replace(pldxivXC5wbTB2O8q,'+')
	url = wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/Search?q='+search
	Je4TwC30iOG5DLKWAtbYvhs(url,'search')
	return
def wwtH4LbAYj2OvQ7DTpdJx(url):
	if 'smartemadfilter' not in url: url = Wl2eu1PavfQ(url,'url')
	else: url = url.split('/smartemadfilter?')[0]
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'CIMA4U-GET_FILTERS_BLOCKS-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('MultiFilter(.*?)PageTitle',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
	RYqsiFGfj07T2VKXrx3y6Hb = YYBlm36zd0Jst18LXwo4.findall('Hoverable.*?<span>(.*?)</span>.*?"all".*?(data-tax="(.*?)".*?)</ul>',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	return RYqsiFGfj07T2VKXrx3y6Hb
def DwEj517Ty94KWU8Y2nSZI3C6vgG(OTKx7aVb2hdS16Wrweky4FXfIN0g9):
	items = YYBlm36zd0Jst18LXwo4.findall('data-id="(.*?)".*?</div>(.*?)</a>',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	return items
def DahRB3A9gNvuFT1eI6lzO5Z(url):
	e3To7sm0Nzn1CruYWxGh = url.split('/smartemadfilter?')[0]
	cCxjKQGYDfZWpd5 = Wl2eu1PavfQ(url,'url')
	url = url.replace(e3To7sm0Nzn1CruYWxGh,cCxjKQGYDfZWpd5)
	url = url.replace('/smartemadfilter?','/ajaxcenter/action/HomepageLoader/')
	url = url.replace('=','/').replace('&','/')
	url = url+'/'
	return url
HiGtBb5m673JPE = ['category','types','release-year']
cEjiOo6IGCD2pAzJ4B9bkmXYT = ['Quality','release-year','types','category']
def eszTQbMvkmRwCAxGDPdYJUi(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==b8Qe150xVaJsnDSv: us8FE67ImlDBS,bxTQdyVe57Bh0P8sG = b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv
	else: us8FE67ImlDBS,bxTQdyVe57Bh0P8sG = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if '/category/' in url:
			global HiGtBb5m673JPE
			HiGtBb5m673JPE = HiGtBb5m673JPE[1:]
		if HiGtBb5m673JPE[0]+'=' not in us8FE67ImlDBS: Z8s0Lov2UiWF1qGjO = HiGtBb5m673JPE[0]
		for FbcUxvE17ewlWNBHgS8Jn in range(len(HiGtBb5m673JPE[0:-1])):
			if HiGtBb5m673JPE[FbcUxvE17ewlWNBHgS8Jn]+'=' in us8FE67ImlDBS: Z8s0Lov2UiWF1qGjO = HiGtBb5m673JPE[FbcUxvE17ewlWNBHgS8Jn+1]
		x5gCnOb9wjSPit6sVclHNZIkFyD0 = us8FE67ImlDBS+'&'+Z8s0Lov2UiWF1qGjO+'=0'
		XFJqUiePG7aSf0N = bxTQdyVe57Bh0P8sG+'&'+Z8s0Lov2UiWF1qGjO+'=0'
		Dnkl4UdcKRILWi6m7TqYJh98vu = x5gCnOb9wjSPit6sVclHNZIkFyD0.strip('&')+'___'+XFJqUiePG7aSf0N.strip('&')
		JXAZh9EQjse2qirMa8DRSYvGLO0kgf = W57WXlwPhyrfVu6oij(bxTQdyVe57Bh0P8sG,'modified_filters')
		MUJCtfYVBLODrFbaZn = url+'/smartemadfilter?'+JXAZh9EQjse2qirMa8DRSYvGLO0kgf
	elif type=='ALL_ITEMS_FILTER':
		pRfP0YvVnLJdukUHstQA8cm = W57WXlwPhyrfVu6oij(us8FE67ImlDBS,'modified_values')
		pRfP0YvVnLJdukUHstQA8cm = SgrGWuAHcLKBQMJetb9(pRfP0YvVnLJdukUHstQA8cm)
		if bxTQdyVe57Bh0P8sG!=b8Qe150xVaJsnDSv: bxTQdyVe57Bh0P8sG = W57WXlwPhyrfVu6oij(bxTQdyVe57Bh0P8sG,'modified_filters')
		if bxTQdyVe57Bh0P8sG==b8Qe150xVaJsnDSv: MUJCtfYVBLODrFbaZn = url
		else: MUJCtfYVBLODrFbaZn = url+'/smartemadfilter?'+bxTQdyVe57Bh0P8sG
		MUJCtfYVBLODrFbaZn = DahRB3A9gNvuFT1eI6lzO5Z(MUJCtfYVBLODrFbaZn)
		MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'أظهار قائمة الفيديو التي تم اختيارها ',MUJCtfYVBLODrFbaZn,421,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'filter')
		MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+' [[   '+pRfP0YvVnLJdukUHstQA8cm+'   ]]',MUJCtfYVBLODrFbaZn,421,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'filter')
		MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+' ===== ===== ===== '+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999)
	RYqsiFGfj07T2VKXrx3y6Hb = wwtH4LbAYj2OvQ7DTpdJx(url)
	dict = {}
	for name,OTKx7aVb2hdS16Wrweky4FXfIN0g9,BnHr3VSlN5cMhZ7miAfGLovdbQJWa in RYqsiFGfj07T2VKXrx3y6Hb:
		if '/category/' in url and BnHr3VSlN5cMhZ7miAfGLovdbQJWa=='category': continue
		name = name.replace('--',b8Qe150xVaJsnDSv)
		items = DwEj517Ty94KWU8Y2nSZI3C6vgG(OTKx7aVb2hdS16Wrweky4FXfIN0g9)
		if '=' not in MUJCtfYVBLODrFbaZn: MUJCtfYVBLODrFbaZn = url
		if type=='SPECIFIED_FILTER':
			if Z8s0Lov2UiWF1qGjO!=BnHr3VSlN5cMhZ7miAfGLovdbQJWa: continue
			elif len(items)<2:
				if BnHr3VSlN5cMhZ7miAfGLovdbQJWa==HiGtBb5m673JPE[-1]:
					url = DahRB3A9gNvuFT1eI6lzO5Z(url)
					Je4TwC30iOG5DLKWAtbYvhs(url)
				else: eszTQbMvkmRwCAxGDPdYJUi(MUJCtfYVBLODrFbaZn,'SPECIFIED_FILTER___'+Dnkl4UdcKRILWi6m7TqYJh98vu)
				return
			else:
				MUJCtfYVBLODrFbaZn = DahRB3A9gNvuFT1eI6lzO5Z(MUJCtfYVBLODrFbaZn)
				if BnHr3VSlN5cMhZ7miAfGLovdbQJWa==HiGtBb5m673JPE[-1]: MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'الجميع',MUJCtfYVBLODrFbaZn,421,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'filter')
				else: MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'الجميع',MUJCtfYVBLODrFbaZn,425,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,Dnkl4UdcKRILWi6m7TqYJh98vu)
		elif type=='ALL_ITEMS_FILTER':
			x5gCnOb9wjSPit6sVclHNZIkFyD0 = us8FE67ImlDBS+'&'+BnHr3VSlN5cMhZ7miAfGLovdbQJWa+'=0'
			XFJqUiePG7aSf0N = bxTQdyVe57Bh0P8sG+'&'+BnHr3VSlN5cMhZ7miAfGLovdbQJWa+'=0'
			Dnkl4UdcKRILWi6m7TqYJh98vu = x5gCnOb9wjSPit6sVclHNZIkFyD0+'___'+XFJqUiePG7aSf0N
			MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'الجميع :'+name,MUJCtfYVBLODrFbaZn,424,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,Dnkl4UdcKRILWi6m7TqYJh98vu)
		dict[BnHr3VSlN5cMhZ7miAfGLovdbQJWa] = {}
		for Y8aiFZsLKw,Ny03TjaY7bBxWwm2GI in items:
			if Y8aiFZsLKw=='196533': Ny03TjaY7bBxWwm2GI = 'أفلام نيتفلكس'
			elif Y8aiFZsLKw=='196531': Ny03TjaY7bBxWwm2GI = 'مسلسلات نيتفلكس'
			if Ny03TjaY7bBxWwm2GI in v1vJEhoNQBVPkjG: continue
			dict[BnHr3VSlN5cMhZ7miAfGLovdbQJWa][Y8aiFZsLKw] = Ny03TjaY7bBxWwm2GI
			x5gCnOb9wjSPit6sVclHNZIkFyD0 = us8FE67ImlDBS+'&'+BnHr3VSlN5cMhZ7miAfGLovdbQJWa+'='+Ny03TjaY7bBxWwm2GI
			XFJqUiePG7aSf0N = bxTQdyVe57Bh0P8sG+'&'+BnHr3VSlN5cMhZ7miAfGLovdbQJWa+'='+Y8aiFZsLKw
			NHEdmMD3qPj4zay2nb5O8xKX = x5gCnOb9wjSPit6sVclHNZIkFyD0+'___'+XFJqUiePG7aSf0N
			title = Ny03TjaY7bBxWwm2GI+' :'#+dict[BnHr3VSlN5cMhZ7miAfGLovdbQJWa]['0']
			title = Ny03TjaY7bBxWwm2GI+' :'+name
			if type=='ALL_ITEMS_FILTER': MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,url,424,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,NHEdmMD3qPj4zay2nb5O8xKX)
			elif type=='SPECIFIED_FILTER' and HiGtBb5m673JPE[-2]+'=' in us8FE67ImlDBS:
				JXAZh9EQjse2qirMa8DRSYvGLO0kgf = W57WXlwPhyrfVu6oij(XFJqUiePG7aSf0N,'modified_filters')
				GSh0nJxEXgZjd48u7mBwWOeafyAp5b = url+'/smartemadfilter?'+JXAZh9EQjse2qirMa8DRSYvGLO0kgf
				GSh0nJxEXgZjd48u7mBwWOeafyAp5b = DahRB3A9gNvuFT1eI6lzO5Z(GSh0nJxEXgZjd48u7mBwWOeafyAp5b)
				MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,GSh0nJxEXgZjd48u7mBwWOeafyAp5b,421,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'filter')
			else: MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,url,425,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,NHEdmMD3qPj4zay2nb5O8xKX)
	return
def W57WXlwPhyrfVu6oij(J6rINOCGlW5M4SXjgwc9U7,mode):
	J6rINOCGlW5M4SXjgwc9U7 = J6rINOCGlW5M4SXjgwc9U7.replace('=&','=0&')
	J6rINOCGlW5M4SXjgwc9U7 = J6rINOCGlW5M4SXjgwc9U7.strip('&')
	hj1lf3cGzLMURVTKkBZmDoyix28 = {}
	if '=' in J6rINOCGlW5M4SXjgwc9U7:
		items = J6rINOCGlW5M4SXjgwc9U7.split('&')
		for tgoJCpq8KGrdaUSjsLh0FTxDRPfIAB in items:
			VRcGtBaO1xun,Y8aiFZsLKw = tgoJCpq8KGrdaUSjsLh0FTxDRPfIAB.split('=')
			hj1lf3cGzLMURVTKkBZmDoyix28[VRcGtBaO1xun] = Y8aiFZsLKw
	sBF1epSJZbIUAgM4hVLPD50 = b8Qe150xVaJsnDSv
	for key in cEjiOo6IGCD2pAzJ4B9bkmXYT:
		if key in list(hj1lf3cGzLMURVTKkBZmDoyix28.keys()): Y8aiFZsLKw = hj1lf3cGzLMURVTKkBZmDoyix28[key]
		else: Y8aiFZsLKw = '0'
		if '%' not in Y8aiFZsLKw: Y8aiFZsLKw = HHbaVYqFRy6v0c(Y8aiFZsLKw)
		if mode=='modified_values' and Y8aiFZsLKw!='0': sBF1epSJZbIUAgM4hVLPD50 = sBF1epSJZbIUAgM4hVLPD50+' + '+Y8aiFZsLKw
		elif mode=='modified_filters' and Y8aiFZsLKw!='0': sBF1epSJZbIUAgM4hVLPD50 = sBF1epSJZbIUAgM4hVLPD50+'&'+key+'='+Y8aiFZsLKw
		elif mode=='all': sBF1epSJZbIUAgM4hVLPD50 = sBF1epSJZbIUAgM4hVLPD50+'&'+key+'='+Y8aiFZsLKw
	sBF1epSJZbIUAgM4hVLPD50 = sBF1epSJZbIUAgM4hVLPD50.strip(' + ')
	sBF1epSJZbIUAgM4hVLPD50 = sBF1epSJZbIUAgM4hVLPD50.strip('&')
	sBF1epSJZbIUAgM4hVLPD50 = sBF1epSJZbIUAgM4hVLPD50.replace('=0','=')
	return sBF1epSJZbIUAgM4hVLPD50
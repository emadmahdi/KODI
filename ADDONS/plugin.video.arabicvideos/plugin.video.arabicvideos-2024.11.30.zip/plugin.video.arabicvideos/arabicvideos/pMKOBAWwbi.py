# -*- coding: utf-8 -*-
from hIVCFnfxSO import *
QQ8pvXNcBfVkP5rRJ7o = 'SHIAVOICE'
WbzmKSZiuOYrBN7oysJ2dUv = '_SHV_'
wQjs1XZ3AO24g8y9bEeoKMiGIu7 = nTHXJIiah2qK[QQ8pvXNcBfVkP5rRJ7o][0]
headers = {'User-Agent':None}
def x8IFqMZeJj7suCR4AaGoNXfEHm(mode,url,text):
	if   mode==310: XXxlOLJ9KRjPH382WVCvr6n71 = Y72YmLgw4vqlHxTCkbeKSicasD()
	elif mode==311: XXxlOLJ9KRjPH382WVCvr6n71 = Je4TwC30iOG5DLKWAtbYvhs(url)
	elif mode==312: XXxlOLJ9KRjPH382WVCvr6n71 = Hkij627uCDJKyIM(url)
	elif mode==313: XXxlOLJ9KRjPH382WVCvr6n71 = xhOqb0o7nj(url)
	elif mode==314: XXxlOLJ9KRjPH382WVCvr6n71 = eewcWksvSlYIXTHG5(text)
	elif mode==319: XXxlOLJ9KRjPH382WVCvr6n71 = kstJfK6jHQWrXDSMRIGB7(text)
	else: XXxlOLJ9KRjPH382WVCvr6n71 = False
	return XXxlOLJ9KRjPH382WVCvr6n71
def Y72YmLgw4vqlHxTCkbeKSicasD():
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'بحث في الموقع',b8Qe150xVaJsnDSv,319,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'_REMEMBERRESULTS_')
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(Q49IsrlSuYRAVbGKhwdckLDOetF2PZ,'GET',wQjs1XZ3AO24g8y9bEeoKMiGIu7,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'SHIAVOICE-MENU-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('id="menulinks"(.*?)</ul>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
	MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+' ===== ===== ===== '+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999)
	items = YYBlm36zd0Jst18LXwo4.findall('<h5>(.*?)</h5>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL|YYBlm36zd0Jst18LXwo4.IGNORECASE)
	for JZMvR4mp2rX7Kf6n in range(len(items)):
		title = items[JZMvR4mp2rX7Kf6n].strip(pldxivXC5wbTB2O8q)
		MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+title,wQjs1XZ3AO24g8y9bEeoKMiGIu7,314,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,str(JZMvR4mp2rX7Kf6n+1))
	MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+'مقاطع شهر',wQjs1XZ3AO24g8y9bEeoKMiGIu7,314,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'0')
	MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+' ===== ===== ===== '+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999)
	items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)".*?<B>(.*?)</B>',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/'+pcA1dzy7LXwGfMPg9mTkuh5tine3
		MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,311)
	return jLtdbeYiQHnf4SpU2MTly
def eewcWksvSlYIXTHG5(JZMvR4mp2rX7Kf6n):
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(LtlXH3fvMydAx,'GET',wQjs1XZ3AO24g8y9bEeoKMiGIu7,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'SHIAVOICE-LATEST-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	if JZMvR4mp2rX7Kf6n=='0':
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('class="tab-content"(.*?)</table>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)".*?title="(.*?)".*?</i>(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,name,title in items:
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/'+pcA1dzy7LXwGfMPg9mTkuh5tine3
			title = title.strip(pldxivXC5wbTB2O8q)
			name = name.strip(pldxivXC5wbTB2O8q)
			title = title+' ('+name+')'
			MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,312)
	elif JZMvR4mp2rX7Kf6n in ['1','2','3']:
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('(<h5>.*?)<div class="col-lg',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		FeO9dQpXG6ZCNIzi1M = int(JZMvR4mp2rX7Kf6n)-1
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[FeO9dQpXG6ZCNIzi1M]
		if JZMvR4mp2rX7Kf6n=='1': items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)".*?src="(.*?)".*?<strong>(.*?)<.*?</i>(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		else: items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)".*?src="(.*?)".*?<strong>(.*?)<.*?href=".*?">(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,lvtGpMZHb9,title,name in items:
			lvtGpMZHb9 = wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/'+lvtGpMZHb9
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/'+pcA1dzy7LXwGfMPg9mTkuh5tine3
			title = title.strip(pldxivXC5wbTB2O8q)
			name = name.strip(pldxivXC5wbTB2O8q)
			title = title+' ('+name+')'
			MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,311,lvtGpMZHb9)
	elif JZMvR4mp2rX7Kf6n in ['4','5','6']:
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('(<h5>.*?)</table>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		JZMvR4mp2rX7Kf6n = int(JZMvR4mp2rX7Kf6n)-4
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[JZMvR4mp2rX7Kf6n]
		items = YYBlm36zd0Jst18LXwo4.findall('src="(.*?)".*?href="(.*?)".*?title="(.*?)".*?<strong.*?>(.*?)</strong>.*?-cell">(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for lvtGpMZHb9,pcA1dzy7LXwGfMPg9mTkuh5tine3,u2jARE57amCQSwZLkiO9qzrg1P,title,WUj71fhxld3rqONpBzmEuC in items:
			lvtGpMZHb9 = wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/'+lvtGpMZHb9
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/'+pcA1dzy7LXwGfMPg9mTkuh5tine3
			title = title.strip(pldxivXC5wbTB2O8q)
			u2jARE57amCQSwZLkiO9qzrg1P = u2jARE57amCQSwZLkiO9qzrg1P.strip(pldxivXC5wbTB2O8q)
			WUj71fhxld3rqONpBzmEuC = WUj71fhxld3rqONpBzmEuC.strip(pldxivXC5wbTB2O8q)
			if u2jARE57amCQSwZLkiO9qzrg1P: name = u2jARE57amCQSwZLkiO9qzrg1P
			else: name = WUj71fhxld3rqONpBzmEuC
			title = title+' ('+name+')'
			MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,312,lvtGpMZHb9)
	return
def Je4TwC30iOG5DLKWAtbYvhs(url):
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'SHIAVOICE-TITLES-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('ibox-heading"(.*?)class="float-right',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
	if 'catsum-mobile' in OTKx7aVb2hdS16Wrweky4FXfIN0g9:
		items = YYBlm36zd0Jst18LXwo4.findall('src="(.*?)".*?href="(.*?)".*?<strong>(.*?)</strong>.*?catsum-mobile">(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		if items:
			for lvtGpMZHb9,pcA1dzy7LXwGfMPg9mTkuh5tine3,title,count in items:
				lvtGpMZHb9 = wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/'+lvtGpMZHb9
				pcA1dzy7LXwGfMPg9mTkuh5tine3 = wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/'+pcA1dzy7LXwGfMPg9mTkuh5tine3
				count = count.replace(' الصوتية: ',':')
				title = title.strip(pldxivXC5wbTB2O8q)
				title = title+' ('+count+')'
				MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,311,lvtGpMZHb9)
	else:
		items = YYBlm36zd0Jst18LXwo4.findall('" href="(.*?)".*?</i>(.*?)</a>.*?">(.*?)<.*?<span.*?<span.*?<span.*?">(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,title,oeQKEN0zauUOnJskGWPLjrhq8ID,D5taEr6hnuFCcRMpTq4wSoyQOivx in items:
			if title==b8Qe150xVaJsnDSv or oeQKEN0zauUOnJskGWPLjrhq8ID==b8Qe150xVaJsnDSv: continue
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/'+pcA1dzy7LXwGfMPg9mTkuh5tine3
			title = title+' ('+D5taEr6hnuFCcRMpTq4wSoyQOivx+')'
			MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,312)
	if not items: bIpskeGhBlqH(jLtdbeYiQHnf4SpU2MTly)
	return
def bIpskeGhBlqH(jLtdbeYiQHnf4SpU2MTly):
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('class="ibox-content"(.*?)class="pagination',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
	items = YYBlm36zd0Jst18LXwo4.findall('href="(http.*?)".*?</i>(.*?)<.*?cell">(.*?)<.*?cell">(.*?)<.*?cell">(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	for pcA1dzy7LXwGfMPg9mTkuh5tine3,title,name,count,D5taEr6hnuFCcRMpTq4wSoyQOivx in items:
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/'+pcA1dzy7LXwGfMPg9mTkuh5tine3
		title = title.strip(pldxivXC5wbTB2O8q)
		name = name.strip(pldxivXC5wbTB2O8q)
		title = title+' ('+name+')'
		MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,312,b8Qe150xVaJsnDSv,D5taEr6hnuFCcRMpTq4wSoyQOivx)
	return
def xhOqb0o7nj(url):
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'SHIAVOICE-SEARCH_ITEMS-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('class="ibox-content p-1"(.*?)class="ibox-content"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if not ZV5rRvabhxJ:
		Je4TwC30iOG5DLKWAtbYvhs(url)
		return
	OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
	items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)".*?<strong>(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/'+pcA1dzy7LXwGfMPg9mTkuh5tine3
		title = title.strip(pldxivXC5wbTB2O8q)
		if '/play-' in pcA1dzy7LXwGfMPg9mTkuh5tine3: MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,312)
		else: MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,311)
	return
def Hkij627uCDJKyIM(url):
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(LtlXH3fvMydAx,'GET',url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'SHIAVOICE-PLAY-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	pcA1dzy7LXwGfMPg9mTkuh5tine3 = YYBlm36zd0Jst18LXwo4.findall('<audio.*?src="(.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if not pcA1dzy7LXwGfMPg9mTkuh5tine3: pcA1dzy7LXwGfMPg9mTkuh5tine3 = YYBlm36zd0Jst18LXwo4.findall('<video.*?src="(.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	pcA1dzy7LXwGfMPg9mTkuh5tine3 = wQjs1XZ3AO24g8y9bEeoKMiGIu7+pcA1dzy7LXwGfMPg9mTkuh5tine3[0]
	yulQjIFbzM(pcA1dzy7LXwGfMPg9mTkuh5tine3,QQ8pvXNcBfVkP5rRJ7o,'video')
	return
def kstJfK6jHQWrXDSMRIGB7(search):
	search,v7Rxw52Z4X0,showDialogs = JimhUH0SEf6w(search)
	if search==b8Qe150xVaJsnDSv: search = FT2oXWtPQpVGuexmLqKN3srdzYn()
	if search==b8Qe150xVaJsnDSv: return
	search = search.replace(pldxivXC5wbTB2O8q,'+')
	k3tw7oFLP9eJznEBINdXQVg = ['&t=a','&t=c','&t=s']
	if showDialogs:
		LLdXt0lcrS8Nw = ['قارئ','إصدار / مجلد','مقطع الصوتي']
		cMZGTsAR2E = XXprCMzuNP2mElUxfdA('موقع صوت الشيعة - أختر البحث', LLdXt0lcrS8Nw)
		if cMZGTsAR2E == -1: return
	elif '_SHIAVOICE-PERSONS_' in v7Rxw52Z4X0: cMZGTsAR2E = 0
	elif '_SHIAVOICE-ALBUMS_' in v7Rxw52Z4X0: cMZGTsAR2E = 1
	elif '_SHIAVOICE-AUDIOS_' in v7Rxw52Z4X0: cMZGTsAR2E = 2
	else: return
	type = k3tw7oFLP9eJznEBINdXQVg[cMZGTsAR2E]
	url = wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/search.php?q='+search+type
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'SHIAVOICE-SEARCH-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('class="ibox-content"(.*?)class="ibox-content"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		if cMZGTsAR2E in [0,1]:
			items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)".*?src="(.*?)".*?href=".*?">(.*?)<.*?">(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
			for pcA1dzy7LXwGfMPg9mTkuh5tine3,lvtGpMZHb9,title,name in items:
				title = title.strip(pldxivXC5wbTB2O8q)
				name = name.strip(pldxivXC5wbTB2O8q)
				title = title+' ('+name+')'
				MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,313,lvtGpMZHb9)
		elif cMZGTsAR2E==2:
			items = YYBlm36zd0Jst18LXwo4.findall('href="(http.*?)".*?</i>(.*?)</a></td><td>(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
			for pcA1dzy7LXwGfMPg9mTkuh5tine3,title,name in items:
				title = title.strip(pldxivXC5wbTB2O8q)
				name = name.strip(pldxivXC5wbTB2O8q)
				title = title+' ('+name+')'
				MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,312)
	return
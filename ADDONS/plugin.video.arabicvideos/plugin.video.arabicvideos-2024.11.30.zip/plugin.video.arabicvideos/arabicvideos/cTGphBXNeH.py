# -*- coding: utf-8 -*-
import sys as Pft6y0LvwSh48iYg7b
MQBw2uYHcWbpxF8tKAV = Pft6y0LvwSh48iYg7b.version_info [0] == 2
myc93k4htNU67 = 2048
h8lCkw1d3LepDVuvfoicEXj5K6sPz = 7
def JanmRV2MtcH (VwngrDb8fEytv4kMTdQu95cIejsC):
	global oPFYqewitzj
	WBrAFcJPVXdS2UzxLEGM0omkD = ord (VwngrDb8fEytv4kMTdQu95cIejsC [-1])
	V13jmfpwhlcyCKMRLY5TiaG = VwngrDb8fEytv4kMTdQu95cIejsC [:-1]
	gyF4Uq9l1NQKCtT = WBrAFcJPVXdS2UzxLEGM0omkD % len (V13jmfpwhlcyCKMRLY5TiaG)
	BN5pdqozP2v9Ur1Swsia = V13jmfpwhlcyCKMRLY5TiaG [:gyF4Uq9l1NQKCtT] + V13jmfpwhlcyCKMRLY5TiaG [gyF4Uq9l1NQKCtT:]
	if MQBw2uYHcWbpxF8tKAV:
		D3MGYw1ceHQ4UbrNJSq = unicode () .join ([unichr (ord (bb1FgjciZqDzeQTBC2hplaPkmRIyUf) - myc93k4htNU67 - (Ni5bJjhpks6SfCc + WBrAFcJPVXdS2UzxLEGM0omkD) % h8lCkw1d3LepDVuvfoicEXj5K6sPz) for Ni5bJjhpks6SfCc, bb1FgjciZqDzeQTBC2hplaPkmRIyUf in enumerate (BN5pdqozP2v9Ur1Swsia)])
	else:
		D3MGYw1ceHQ4UbrNJSq = str () .join ([chr (ord (bb1FgjciZqDzeQTBC2hplaPkmRIyUf) - myc93k4htNU67 - (Ni5bJjhpks6SfCc + WBrAFcJPVXdS2UzxLEGM0omkD) % h8lCkw1d3LepDVuvfoicEXj5K6sPz) for Ni5bJjhpks6SfCc, bb1FgjciZqDzeQTBC2hplaPkmRIyUf in enumerate (BN5pdqozP2v9Ur1Swsia)])
	return eval (D3MGYw1ceHQ4UbrNJSq)
TYf7Dc06PQgy1vEV9,ubxGUTt1LraKhVZgpAP,Y2t8baH5GWikvOZ7NsCeq3TKrgMV=JanmRV2MtcH,JanmRV2MtcH,JanmRV2MtcH
BWNPxIG7vqdTy85pjHzUOrK3,Mmpr0o76iWJvz1kTtfgI8hES,QTUBCcehw6qPd4x=Y2t8baH5GWikvOZ7NsCeq3TKrgMV,ubxGUTt1LraKhVZgpAP,TYf7Dc06PQgy1vEV9
mQNonhS7CV2BXOv,HwB7ydlWVJeCtPuQ6MDE1RTYOo,uVQd103XyvUce2EBtzbYaC=QTUBCcehw6qPd4x,Mmpr0o76iWJvz1kTtfgI8hES,BWNPxIG7vqdTy85pjHzUOrK3
yST5AHEfvPmcWpwGuh2BJ,BmePGjS7FxK6kutUM,S0IlDPhBN3gMEUvnjRLXsYAc2Zf=uVQd103XyvUce2EBtzbYaC,HwB7ydlWVJeCtPuQ6MDE1RTYOo,mQNonhS7CV2BXOv
Xz3bA2PFENVCUtplu51,LAQD5wEkr18bUiGaYen3J,P0qdZI384LKleuo=S0IlDPhBN3gMEUvnjRLXsYAc2Zf,BmePGjS7FxK6kutUM,yST5AHEfvPmcWpwGuh2BJ
shC5qBRV2A0lZ,mmcNLrXtzfpyCkZlvK5VwG2gujh,m6hwdgP31a2zjN7lkpX=P0qdZI384LKleuo,LAQD5wEkr18bUiGaYen3J,Xz3bA2PFENVCUtplu51
IjZbnrBJmM2N,Nh0BWuiSndf,kke1PDGRBLuY8y=m6hwdgP31a2zjN7lkpX,mmcNLrXtzfpyCkZlvK5VwG2gujh,shC5qBRV2A0lZ
ddo23ZJtgcY,vvWwO3Tx2dAgcijrFXq,DYakr9g4PVU=kke1PDGRBLuY8y,Nh0BWuiSndf,IjZbnrBJmM2N
zI3ROAZtiUq42rE9WDST68,Dzs8qU2gQMcCSyRhiZn4TFbeGk,dDYUoKi6JFM23p=DYakr9g4PVU,vvWwO3Tx2dAgcijrFXq,ddo23ZJtgcY
QQdAXWBc2GPw,VFjQx6Is28KvzLOmMXtg4GqTwa3,TT8Mxv5Wq7nlC9IscdpPUY6=dDYUoKi6JFM23p,Dzs8qU2gQMcCSyRhiZn4TFbeGk,zI3ROAZtiUq42rE9WDST68
SbjiWeHLQPoazqwp3cODkd7YxVgn,UUkIBz1sgQ9WfNeG6trKXvu0,RRIHDFjoW9w7bSfVPhC=TT8Mxv5Wq7nlC9IscdpPUY6,VFjQx6Is28KvzLOmMXtg4GqTwa3,QQdAXWBc2GPw
from hIVCFnfxSO import *
QQ8pvXNcBfVkP5rRJ7o = HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔࠩๆ")
def x8IFqMZeJj7suCR4AaGoNXfEHm(ZZtDTHnBXMz,pnmsJqCWIHVk2Y6xPvl9Q0Ez8r=b8Qe150xVaJsnDSv):
	if   ZZtDTHnBXMz==TT8Mxv5Wq7nlC9IscdpPUY6(u"࠴ᅽ"): qFBV54ijXemHTf0(pnmsJqCWIHVk2Y6xPvl9Q0Ez8r)
	elif ZZtDTHnBXMz==P0qdZI384LKleuo(u"࠶ᅾ"): pass
	elif ZZtDTHnBXMz==yST5AHEfvPmcWpwGuh2BJ(u"࠸ᅿ"): lcA0mHzo1TQUIwMKZa8(pnmsJqCWIHVk2Y6xPvl9Q0Ez8r)
	elif ZZtDTHnBXMz==kke1PDGRBLuY8y(u"࠳ᆀ"): HBxa6Ggn8hq()
	elif ZZtDTHnBXMz==vvWwO3Tx2dAgcijrFXq(u"࠵ᆁ"): PPvHDeXL8Uxpy(pnmsJqCWIHVk2Y6xPvl9Q0Ez8r)
	elif ZZtDTHnBXMz==Mmpr0o76iWJvz1kTtfgI8hES(u"࠷ᆂ"): OOgUL1YPxskvi5WT2wn0acuQj()
	elif ZZtDTHnBXMz==LAQD5wEkr18bUiGaYen3J(u"࠹ᆃ"): Bah3px6DHs04w()
	elif ZZtDTHnBXMz==Xz3bA2PFENVCUtplu51(u"࠻ᆄ"): Ef82HhjNckZGo1Xvy0()
	elif ZZtDTHnBXMz==Xz3bA2PFENVCUtplu51(u"࠽ᆅ"): Njpw9ear7PYf1EBdtTyILMcHnv8Gx()
	elif ZZtDTHnBXMz==vvWwO3Tx2dAgcijrFXq(u"࠿ᆆ"): yZS8NxF02XCzB63idOAJ()
	elif ZZtDTHnBXMz==UUkIBz1sgQ9WfNeG6trKXvu0(u"࠱࠶࠲ᆇ"): r2P9ci76sKGM80OQhUzqTn()
	elif ZZtDTHnBXMz==Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"࠲࠷࠴ᆈ"): ZZH1qK3YWwDg9so0kVEMQcyIr()
	elif ZZtDTHnBXMz==shC5qBRV2A0lZ(u"࠳࠸࠶ᆉ"): DnKPbv5JXO()
	elif ZZtDTHnBXMz==yST5AHEfvPmcWpwGuh2BJ(u"࠴࠹࠸ᆊ"): F34lsJmaBxhWiHZ9RA()
	elif ZZtDTHnBXMz==QQdAXWBc2GPw(u"࠵࠺࠺ᆋ"): IhmE5fGjcbetvCd3iTQWwLM()
	elif ZZtDTHnBXMz==VFjQx6Is28KvzLOmMXtg4GqTwa3(u"࠶࠻࠵ᆌ"): JEIZpTLHzQhjm695teSdiqs()
	elif ZZtDTHnBXMz==mmcNLrXtzfpyCkZlvK5VwG2gujh(u"࠷࠵࠷ᆍ"): rsC2nwNj4cfHQg3MGYp1hZ8v9OV()
	elif ZZtDTHnBXMz==SbjiWeHLQPoazqwp3cODkd7YxVgn(u"࠱࠶࠹ᆎ"): E0JeLy8YxZb23AmpNU()
	elif ZZtDTHnBXMz==m6hwdgP31a2zjN7lkpX(u"࠲࠷࠻ᆏ"): O4u8cfLixWrQGw()
	elif ZZtDTHnBXMz==UUkIBz1sgQ9WfNeG6trKXvu0(u"࠳࠸࠽ᆐ"): xk701eJupZ6nU(CCxMXuNUEzolDZTKrBJ)
	elif ZZtDTHnBXMz==UUkIBz1sgQ9WfNeG6trKXvu0(u"࠴࠻࠵ᆑ"): YvG9ESojmWCUZ54Lq7bif()
	elif ZZtDTHnBXMz==Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"࠵࠼࠷ᆒ"): X1y9V2Wc0jpHP()
	elif ZZtDTHnBXMz==mmcNLrXtzfpyCkZlvK5VwG2gujh(u"࠶࠽࠲ᆓ"): YB30hP8KoEXSCOQb4vJ([pnmsJqCWIHVk2Y6xPvl9Q0Ez8r],CCxMXuNUEzolDZTKrBJ,CCxMXuNUEzolDZTKrBJ,DD5cFIejQa2X4BgAu9GWPyJ3tC7)
	elif ZZtDTHnBXMz==HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"࠷࠷࠴ᆔ"): iYa4V16rHzIO(S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡡࡥࡣࡳࡸ࡮ࡼࡥࠨ็"),CCxMXuNUEzolDZTKrBJ)
	elif ZZtDTHnBXMz==ubxGUTt1LraKhVZgpAP(u"࠱࠸࠶ᆕ"): iYa4V16rHzIO(LAQD5wEkr18bUiGaYen3J(u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡳࡶࡰࡴ่ࠬ"),CCxMXuNUEzolDZTKrBJ)
	elif ZZtDTHnBXMz==RRIHDFjoW9w7bSfVPhC(u"࠲࠹࠸ᆖ"): qIOSLT9BEF()
	elif ZZtDTHnBXMz==VFjQx6Is28KvzLOmMXtg4GqTwa3(u"࠳࠺࠺ᆗ"): f9OabsGvIuE()
	elif ZZtDTHnBXMz==dDYUoKi6JFM23p(u"࠴࠻࠼ᆘ"): sn1dEKqwSJP5Nypj8D6ivoQYHc0(BWNPxIG7vqdTy85pjHzUOrK3(u"ࠪࡷࡨࡸࡩࡱࡶ࠱ࡱࡴࡪࡵ࡭ࡧ࠱ࡶࡪࡹ࡯࡭ࡸࡨࡹࡷࡲ้ࠧ"))
	elif ZZtDTHnBXMz==SbjiWeHLQPoazqwp3cODkd7YxVgn(u"࠵࠼࠿ᆙ"): sn1dEKqwSJP5Nypj8D6ivoQYHc0(BmePGjS7FxK6kutUM(u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡽࡴࡻࡴࡶࡤࡨ๊ࠫ"))
	elif ZZtDTHnBXMz==yST5AHEfvPmcWpwGuh2BJ(u"࠶࠿࠰ᆚ"): m3mZndtTeo5ADCWYr6b0()
	elif ZZtDTHnBXMz==VFjQx6Is28KvzLOmMXtg4GqTwa3(u"࠷࠹࠲ᆛ"): qfVZtFsrzTIa4gdX()
	elif ZZtDTHnBXMz==Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"࠱࠺࠴ᆜ"): eIATdmLcnPxkWG07fOEr()
	elif ZZtDTHnBXMz==Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"࠲࠻࠶ᆝ"): hTxW53Qgw81()
	elif ZZtDTHnBXMz==shC5qBRV2A0lZ(u"࠳࠼࠸ᆞ"): ZlAOgj92Tq()
	elif ZZtDTHnBXMz==kke1PDGRBLuY8y(u"࠴࠽࠺ᆟ"): gxPVWNCO7Qr6DXf0vIAiTHycqnSGd2()
	elif ZZtDTHnBXMz==mQNonhS7CV2BXOv(u"࠵࠾࠼ᆠ"): I34lRoMfySGVxBmY()
	elif ZZtDTHnBXMz==P0qdZI384LKleuo(u"࠶࠿࠷ᆡ"): pD8yINQe2T3qZ4tvlX()
	elif ZZtDTHnBXMz==zI3ROAZtiUq42rE9WDST68(u"࠷࠹࠹ᆢ"): EEsP4Tk9L6iyeZj()
	elif ZZtDTHnBXMz==ddo23ZJtgcY(u"࠱࠺࠻ᆣ"): fbapl6HkWdIo2KE()
	elif ZZtDTHnBXMz==kke1PDGRBLuY8y(u"࠴࠶࠳ᆤ"): JwVFResqbM5Dk126z3fQWuOP7YBv0(pnmsJqCWIHVk2Y6xPvl9Q0Ez8r)
	elif ZZtDTHnBXMz==S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"࠵࠷࠵ᆥ"): KMHWjelkc5I()
	elif ZZtDTHnBXMz==LAQD5wEkr18bUiGaYen3J(u"࠶࠸࠷ᆦ"): G0GQRsjE6Z1XM4x3b()
	elif ZZtDTHnBXMz==IjZbnrBJmM2N(u"࠷࠹࠹ᆧ"): nkxCvmzdXP5qI1UTOL4j()
	elif ZZtDTHnBXMz==Mmpr0o76iWJvz1kTtfgI8hES(u"࠸࠺࠴ᆨ"): v03F6pMmYs2hBfUT(CCxMXuNUEzolDZTKrBJ)
	elif ZZtDTHnBXMz==P0qdZI384LKleuo(u"࠹࠴࠶ᆩ"): FpaODNuVeSTnG()
	elif ZZtDTHnBXMz==TT8Mxv5Wq7nlC9IscdpPUY6(u"࠳࠵࠸ᆪ"): X5Q6PnJcimdhwT7H(DD5cFIejQa2X4BgAu9GWPyJ3tC7)
	elif ZZtDTHnBXMz==ddo23ZJtgcY(u"࠴࠶࠺ᆫ"): OsdWDnBA5bgqZlXPhmeuK60cCU7(CCxMXuNUEzolDZTKrBJ)
	elif ZZtDTHnBXMz==S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"࠵࠷࠼ᆬ"): nVBI5RPDkU01FmE8XZv2pOotj4aG()
	elif ZZtDTHnBXMz==Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"࠶࠸࠾ᆭ"): FjhoxKe0ERbO8(Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵ๋ࠪ"),CCxMXuNUEzolDZTKrBJ,CCxMXuNUEzolDZTKrBJ)
	elif ZZtDTHnBXMz==Xz3bA2PFENVCUtplu51(u"࠹࠵࠶ᆮ"): vRrl9O7fbc1IWEY8KBw0T()
	elif ZZtDTHnBXMz==SbjiWeHLQPoazqwp3cODkd7YxVgn(u"࠺࠶࠱ᆯ"): I5zXZqsxiDMPYmFcpleS7K()
	elif ZZtDTHnBXMz==Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"࠻࠰࠳ᆰ"): xekZcFabtTw()
	elif ZZtDTHnBXMz==RRIHDFjoW9w7bSfVPhC(u"࠵࠱࠵ᆱ"): TTKB4unWj6yLdEeDoR(oYXBd89zTnZPipv56Qf1UxurbC3)
	elif ZZtDTHnBXMz==SbjiWeHLQPoazqwp3cODkd7YxVgn(u"࠶࠲࠷ᆲ"): TTKB4unWj6yLdEeDoR(KNTV1H9Dl32a6yxiUEBdvZ7qgr)
	elif ZZtDTHnBXMz==RRIHDFjoW9w7bSfVPhC(u"࠷࠳࠹ᆳ"): Nld5Fv8rwobfXG4JPpEcMCO2B()
	elif ZZtDTHnBXMz==vvWwO3Tx2dAgcijrFXq(u"࠸࠴࠻ᆴ"): bb80Orl1IgxV6(CCxMXuNUEzolDZTKrBJ)
	elif ZZtDTHnBXMz==UUkIBz1sgQ9WfNeG6trKXvu0(u"࠹࠵࠽ᆵ"): yYr1MnihScwLCE()
	elif ZZtDTHnBXMz==QQdAXWBc2GPw(u"࠺࠶࠸ᆶ"): UUKYJwONZhkcIAyixg7WC9R()
	elif ZZtDTHnBXMz==S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"࠻࠰࠺ᆷ"): AkVKUSHc3QdyqIpF9N4MvZWTf5()
	elif ZZtDTHnBXMz==BWNPxIG7vqdTy85pjHzUOrK3(u"࠱࠱࠴࠳ᆸ"): yYK3NwnZaDkBgjQmU1HcTPOJ4u()
	elif ZZtDTHnBXMz==Xz3bA2PFENVCUtplu51(u"࠲࠲࠵࠵ᆹ"): gTKPUBYE3Jkv9cus()
	elif ZZtDTHnBXMz==DYakr9g4PVU(u"࠳࠳࠶࠷ᆺ"): sn1dEKqwSJP5Nypj8D6ivoQYHc0(Xz3bA2PFENVCUtplu51(u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫ์"))
	elif ZZtDTHnBXMz==BWNPxIG7vqdTy85pjHzUOrK3(u"࠴࠴࠷࠹ᆻ"): GvYcUV9CpTbXrFt()
	return
def GvYcUV9CpTbXrFt():
	F8Ef6K7kCy9mbQPx = hRWC8YSFvsm4JHOMVIne3jquZ.getSetting(HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡦ࡮ࡺࡲࡢࡶࡨࠫํ"))
	message = ubxGUTt1LraKhVZgpAP(u"ࠨษ็ี็๋ࠠศๆ่ัิีࠠฮษ็๎ฬࠦ็้ࠢ࠽ࠤࠥࠦࠧ๎")+str(F8Ef6K7kCy9mbQPx)+m6hwdgP31a2zjN7lkpX(u"ࠩࠣ࡯ࡧࡶࡳࠨ๏") if F8Ef6K7kCy9mbQPx else HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠪห้า่ะหࠣห้ษ่ห๊่หฯ๐ใ๋ห้ࠣฯ๎โโหࠣัฬ๊๊ศࠩ๐")
	message = rC3Tlno96KjLDIvBaSWUbR8+message+S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠫࡡࡴ็ๅࠢอี๏ีࠠศๆล๊ࠥะิ฻์็ࠤศ๎ࠠห฼ํ๎ึࠦัใ็ࠣห้า่ะหࠣห้ษ่ห๊่หฯ๐ใ๋หࠪ๑")+hAIp8kmC36T5WFPMSXOwnNbtD
	c9Wbh7raCVlyPKqpL6GwNZz1u = QlaM6yHe0bgh58Vx3BAZD(m6hwdgP31a2zjN7lkpX(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ๒"),QTUBCcehw6qPd4x(u"࠭ฮา๊ฯࠫ๓"),uVQd103XyvUce2EBtzbYaC(u"ࠧฦ์ๅหๆ࠭๔"),TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠨฬื฾๏๊ࠧ๕"),VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ๖"),mQNonhS7CV2BXOv(u"ࠪห้า่ะหࠣห้ษ่ห๊่หฯ๐ใ๋ห๋ࠣ๏ูࠦๆๆํอࠥ๐โ้็ࠣฬ์อࠠศๆหี๋อๅอࠢหหำะ๊ศำࠣว฾๊้ࠡฮ๋ำฮࠦๅห๊ไีฮࠦไาไ่ࠤฬ๊ฬ้ัฬࠤฬ๊ะ๋ࠢส๊ฯࠦสฮัา๋ࠥ็๊้ࠡำ๋ࠥอไีษือࠥ࠴࠮๊๊ࠡิฬࠦๅฺ่ส๋ࠥ฿ๆะ็สࠤฯ่่ๆࠢส๊ฯࠦศหึ฽๎้ࠦแ๋ัํ์ࠥ็ว็ࠢส่อืๆศ็ฯࠤ้์๋ࠠีฦู่่ࠦ็ࠢส่ั๎ฯสࠢส่ฯ๐ࠠหำํำ์อࠠๅล้ࠤฬ๊ศา่ส้ัࠦำ้ใࠣ๎ำะวาࠢส่ั๎ฯสࠢฦ์ฯ๎ๅศฬํ็๏อࠠ࠯࠰ࠣ฽้๋วࠡษ้๋ࠥ๐ฬษࠢสาฯ๐วาࠢิๆ๊ࠦฬ้ัฬࠤฺเ๊าࠢศิฬࠦใศ่อࠤฬ๊ล็ฬิ๊ฯูࠦ็ัๆࠤอ฽๊วหࠣวํࠦโๅ์็อࡡࡴ࡜࡯ࠩ๗")+message)
	if c9Wbh7raCVlyPKqpL6GwNZz1u in [-QQdAXWBc2GPw(u"࠵ᆼ"),Mmpr0o76iWJvz1kTtfgI8hES(u"࠵ᆽ")]: return
	if c9Wbh7raCVlyPKqpL6GwNZz1u==Mmpr0o76iWJvz1kTtfgI8hES(u"࠷ᆾ"):
		F8Ef6K7kCy9mbQPx = b8Qe150xVaJsnDSv
		tuJ9fQgDl8oineCrFPT(UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠫࠬ๘"),BmePGjS7FxK6kutUM(u"ࠬ࠭๙"),yST5AHEfvPmcWpwGuh2BJ(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ๚"),ubxGUTt1LraKhVZgpAP(u"ࠧ็ฮะฮࠥ฿ๅๅ์ฬࠤส๐โศใࠣห้า่ะหࠣห้ษ่ห๊่หฯ๐ใ๋หࠪ๛"))
	else:
		items = [SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠨ࠴࠸࠴ࠥࡱࡢࡱࡵࠪ๜"),uVQd103XyvUce2EBtzbYaC(u"ࠩ࠸࠴࠵ࠦ࡫ࡣࡲࡶࠫ๝"),HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠪ࠻࠺࠶ࠠ࡬ࡤࡳࡷࠬ๞"),UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠫ࠶࠶࠰࠱ࠢ࡮ࡦࡵࡹࠧ๟"),ddo23ZJtgcY(u"ࠬ࠷࠲࠶࠲ࠣ࡯ࡧࡶࡳࠨ๠"),mmcNLrXtzfpyCkZlvK5VwG2gujh(u"࠭࠱࠶࠲࠳ࠤࡰࡨࡰࡴࠩ๡"),TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠧ࠲࠹࠸࠴ࠥࡱࡢࡱࡵࠪ๢"),TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠨ࠴࠳࠴࠵ࠦ࡫ࡣࡲࡶࠫ๣"),QQdAXWBc2GPw(u"ࠩ࠵࠹࠵࠶ࠠ࡬ࡤࡳࡷࠬ๤"),shC5qBRV2A0lZ(u"ࠪ࠷࠵࠶࠰ࠡ࡭ࡥࡴࡸ࠭๥"),SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠫ࠸࠻࠰࠱ࠢ࡮ࡦࡵࡹࠧ๦"),BWNPxIG7vqdTy85pjHzUOrK3(u"ࠬ࠺࠰࠱࠲ࠣ࡯ࡧࡶࡳࠨ๧"),S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"࠭࠴࠶࠲࠳ࠤࡰࡨࡰࡴࠩ๨"),TYf7Dc06PQgy1vEV9(u"ࠧ࠶࠲࠳࠴ࠥࡱࡢࡱࡵࠪ๩"),Xz3bA2PFENVCUtplu51(u"ࠨ࠸࠳࠴࠵ࠦ࡫ࡣࡲࡶࠫ๪"),VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠩ࠺࠴࠵࠶ࠠ࡬ࡤࡳࡷࠬ๫"),DYakr9g4PVU(u"ࠪ࠼࠵࠶࠰ࠡ࡭ࡥࡴࡸ࠭๬"),BmePGjS7FxK6kutUM(u"ࠫ࠾࠶࠰࠱ࠢ࡮ࡦࡵࡹࠧ๭"),BWNPxIG7vqdTy85pjHzUOrK3(u"ࠬ࠷࠰࠱࠲࠳ࠤࡰࡨࡰࡴࠩ๮"),QTUBCcehw6qPd4x(u"࠭࠱࠲࠲࠳࠴ࠥࡱࡢࡱࡵࠪ๯"),P0qdZI384LKleuo(u"ࠧ࠲࠴࠳࠴࠵ࠦ࡫ࡣࡲࡶࠫ๰"),S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠨ࠻࠼࠽࠾࠿ࠠ࡬ࡤࡳࡷࠬ๱")]
		cMZGTsAR2E = XXprCMzuNP2mElUxfdA(uVQd103XyvUce2EBtzbYaC(u"ࠩสาฯืࠠศๆฯ์ิฯࠠศๆฦ์ฯ๎ๅศฬํ็๏ฯࠠศๆ่๊ฬูศสࠩ๲"),items)
		if cMZGTsAR2E==-shC5qBRV2A0lZ(u"࠱ᆿ"): return
		F8Ef6K7kCy9mbQPx = str(items[cMZGTsAR2E][:-S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"࠶ᇀ")])
		tuJ9fQgDl8oineCrFPT(BWNPxIG7vqdTy85pjHzUOrK3(u"ࠪࠫ๳"),m6hwdgP31a2zjN7lkpX(u"ࠫࠬ๴"),vvWwO3Tx2dAgcijrFXq(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ๵"),ddo23ZJtgcY(u"࠭ๆอฯอࠤ฾๋ไ๋หࠣฮูเ๊ๅ๋ࠢฮาี๊ะࠢิๆ๊ࠦวๅฮ๋ำฮࠦวๅล๋ฮํ๋วห์ๆ๎ฮࡢ࡮࡝ࡰࠪ๶")+rC3Tlno96KjLDIvBaSWUbR8+F8Ef6K7kCy9mbQPx+Nh0BWuiSndf(u"ࠧࠡ࡭ࡥࡴࡸ࠭๷")+hAIp8kmC36T5WFPMSXOwnNbtD)
	hRWC8YSFvsm4JHOMVIne3jquZ.setSetting(QQdAXWBc2GPw(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡧ࡯ࡴࡳࡣࡷࡩࠬ๸"),F8Ef6K7kCy9mbQPx)
	return
def gTKPUBYE3Jkv9cus(Mhsrgdq3jpIDTlFG7eOfQo5k0uV=DD5cFIejQa2X4BgAu9GWPyJ3tC7):
	g8URiqaPVe4chEY = pRA1LmxBJN3SzIjPansgt()
	AVtJw7b48zEdfxCyLg5TS = IjZbnrBJmM2N(u"ࠩส่ฯฺฺ๋ๆࠣห้๊วฮไࠣ๎฾๋ไࠨ๹") if g8URiqaPVe4chEY else Xz3bA2PFENVCUtplu51(u"ࠪห้ะิ฻์็ࠤฬ๊ไศฯๅࠤ๊ะ่ใใࠪ๺")
	c9Wbh7raCVlyPKqpL6GwNZz1u = QlaM6yHe0bgh58Vx3BAZD(mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ๻"),zI3ROAZtiUq42rE9WDST68(u"ࠬิั้ฮࠪ๼"),TT8Mxv5Wq7nlC9IscdpPUY6(u"࠭ล๋ไสๅࠬ๽"),VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠧหึ฽๎้࠭๾"),S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ๿"),rC3Tlno96KjLDIvBaSWUbR8+AVtJw7b48zEdfxCyLg5TS+hAIp8kmC36T5WFPMSXOwnNbtD+eeN6dTEnkJxI+RRIHDFjoW9w7bSfVPhC(u"๊ࠩิ์ࠦวๅ๊฻๎ๆฯࠠหฮ฼่้่ࠥะ์ࠣวํะ่ๆษอ๎่๐วࠡ์ๅ์๊ࠦศหึ฽๎้ࠦวๅใํำ๏๎ࠠศๆ็หา่ࠠ࠯࠰ࠣษ๊อࠠษ฻าࠤฬ์ส่ษฤࠤฬ๊แ๋ัํ์ࠥอไฮษ็๎ࠥฮรไ็็๋ࠥ࠴࠮ࠡล๋ࠤอ฿ฯࠡษ็๊็ืฺࠠๆ์ࠤืืࠠࠣฬฯหํุࠠฦๆ์ࠤฬ๊ไศฯๅࠦࠥ࠴࠮๊ࠡฦ๎฻อࠠๆ็ๆ๊ࠥหไ฻ษฤࠤฬ๊สี฼ํ่ࠥอไๅษะๆࠥฮวๅ่ๅีࠥ฿ไ๊ࠢีีࠥࠨล๋ไสๅࠥอไโ์า๎ํࠨࠠ࠯࠰ࠣ์ศ๐ึศ่้่ࠢ์ࠠศๆสืฯ็วะห้๋ࠣࠦส฻์ํีࠥะัห์หࠤ๊ำส้์สฮࠥอไใ๊สส๊ࠦ࠮࠯๋ࠢาฬ฻ษࠡฬิฮ๏ฮࠠฮๆๅหฯࠦวๅ็ึุ่๊วหࠢ࠱࠲ࠥํไࠡฬิ๎ิࠦวๅฤ้ࠤฯฺฺ๋ๆ๋ࠣีํࠠศๆ๋฼๏็ษࠡล่ࠤส๐โศใ๊หࠥลࠡࠢࠩ຀"))
	if c9Wbh7raCVlyPKqpL6GwNZz1u==qHYIWnOZLPkrQU: pie0DRMAtn = uuxVm0bTwdnCUAL4s6NKHEBF3M.executeJSONRPC(S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡖࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡘ࡫ࡴࡔࡧࡷࡸ࡮ࡴࡧࡗࡣ࡯ࡹࡪࠨࠬࠣ࡫ࡧࠦ࠿࠷ࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡸ࡫ࡴࡵ࡫ࡱ࡫ࠧࡀࠢࡷ࡫ࡧࡩࡴࡶ࡬ࡢࡻࡨࡶ࠳ࡧࡵࡵࡱࡳࡰࡦࡿ࡮ࡦࡺࡷ࡭ࡹ࡫࡭ࠣ࠮ࠥࡺࡦࡲࡵࡦࠤ࠽࡟ࡢࢃࡽࠨກ"))
	elif c9Wbh7raCVlyPKqpL6GwNZz1u==IgQimel18t: pie0DRMAtn = uuxVm0bTwdnCUAL4s6NKHEBF3M.executeJSONRPC(m6hwdgP31a2zjN7lkpX(u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡗࡪࡺࡴࡪࡰࡪࡷ࠳࡙ࡥࡵࡕࡨࡸࡹ࡯࡮ࡨࡘࡤࡰࡺ࡫ࠢ࠭ࠤ࡬ࡨࠧࡀ࠱࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡹࡥࡵࡶ࡬ࡲ࡬ࠨ࠺ࠣࡸ࡬ࡨࡪࡵࡰ࡭ࡣࡼࡩࡷ࠴ࡡࡶࡶࡲࡴࡱࡧࡹ࡯ࡧࡻࡸ࡮ࡺࡥ࡮ࠤ࠯ࠦࡻࡧ࡬ࡶࡧࠥ࠾ࡠ࠷࡝ࡾࡿࠪຂ"))
	if c9Wbh7raCVlyPKqpL6GwNZz1u in [qHYIWnOZLPkrQU,IgQimel18t]:
		if BWNPxIG7vqdTy85pjHzUOrK3(u"ࠬࡺࡲࡶࡧࠪ຃") in str(pie0DRMAtn): tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩຄ"),uVQd103XyvUce2EBtzbYaC(u"ࠧห็อࠤฬู๊ๆๆํอࠥฮๆอษะࠫ຅"))
		else: tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,zI3ROAZtiUq42rE9WDST68(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫຆ"),HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠩ็่ศูแࠡษ็฽๊๊๊สࠢไุ้ะࠧງ"))
	return
def yYK3NwnZaDkBgjQmU1HcTPOJ4u():
	url = nTHXJIiah2qK[BmePGjS7FxK6kutUM(u"ࠪࡖࡊࡒࡅࡂࡕࡈࡗࠬຈ")][Nh0BWuiSndf(u"࠲ᇁ")]
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(nCUMfrlZvuiLe5x,TYf7Dc06PQgy1vEV9(u"ࠫࡌࡋࡔࠨຉ"),url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙࠭ࡊࡐࡖࡘࡆࡒࡌࡠࡑࡏࡈࡤࡘࡅࡍࡇࡄࡗࡊ࠳࠱ࡴࡶࠪຊ"))
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	G4upaV8ed9NfPAc = YYBlm36zd0Jst18LXwo4.findall(BmePGjS7FxK6kutUM(u"࠭ࡨࡳࡧࡩࡁࠧࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࠭ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶ࠲࠯ࡅࠩ࠯ࡼ࡬ࡴࠧ࠭຋"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	G4upaV8ed9NfPAc = sorted(G4upaV8ed9NfPAc,reverse=CCxMXuNUEzolDZTKrBJ)
	cMZGTsAR2E = XXprCMzuNP2mElUxfdA(SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠧศะอีࠥอไฦืาหึࠦวๅาํࠤฯื๊ะࠢอฯอ๐ส่ࠩຌ"),G4upaV8ed9NfPAc)
	if cMZGTsAR2E>=kke1PDGRBLuY8y(u"࠳ᇂ"):
		DWLEMbQ9TuK4Y1JHIAvFl = url.rsplit(S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠨ࠱ࠪຍ"),QQdAXWBc2GPw(u"࠵ᇃ"))[LAQD5wEkr18bUiGaYen3J(u"࠵ᇄ")]+m6hwdgP31a2zjN7lkpX(u"ࠩ࠲ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࠪຎ")+G4upaV8ed9NfPAc[cMZGTsAR2E]+TYf7Dc06PQgy1vEV9(u"ࠪ࠲ࡿ࡯ࡰࠨຏ")
		succeeded = KURVy7LWmI6Btc(ddo23ZJtgcY(u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩຐ"),DWLEMbQ9TuK4Y1JHIAvFl,Mmpr0o76iWJvz1kTtfgI8hES(u"ࡔࡳࡷࡨሓ"))
		if succeeded:
			hRWC8YSFvsm4JHOMVIne3jquZ.setSetting(Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠬࡧࡶ࠯ࡸࡨࡶࡸ࡯࡯࡯ࠩຑ"),b8Qe150xVaJsnDSv)
			aVwGA2kFY6u4m = BjMmX1vNrnzSAf(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,TT8Mxv5Wq7nlC9IscdpPUY6(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩຒ"),BWNPxIG7vqdTy85pjHzUOrK3(u"ࠧห็ࠣฮะฮ๊หࠢศูิอัࠡไา๎๊ࠦไๅสิ๊ฬ๋ฬࠡ࠰࠱ࠤ้้ๆࠡสิ๊ฬ๋ฬࠡๅ๋ำ๏๊ࠦใ๊่ࠤศ๎ส้็สฮ๏้๊ศࠢหฮาี๊ฬࠢฯ้๏฿ࠠศๆหีฬ๋ฬࠡสสืฯิฯศ็ࠣฦำืࠠฦืาหึࠦๅห๊ไีࠥ࠴࠮้ࠡ็ࠤฯื๊ะࠢส่ว์ࠠฦ์ๅหๆࠦวๅฬะำ๏ัࠠศๆฦ์ฯ๎ๅศฬํ็๏ࠦไ่าสࠤฬ๊ศา่ส้ัࠦฟࠢࠣࠪຓ"))
			if aVwGA2kFY6u4m: FjhoxKe0ERbO8(Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭ດ"),CCxMXuNUEzolDZTKrBJ,CCxMXuNUEzolDZTKrBJ)
	return
def yYr1MnihScwLCE():
	aVwGA2kFY6u4m = BjMmX1vNrnzSAf(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,LAQD5wEkr18bUiGaYen3J(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬຕ"),BmePGjS7FxK6kutUM(u"๋้ࠪࠦสา์าࠤๆ฿ไศ่ࠢืาࠦลฺัสำฬะࠠศๆหี๋อๅอࠢส่ำอีสࠢห์็ะࠠอๆหࠤฬ๊สฮัํฯฬะࠠ࠯࠰๋ࠣีอࠠศๆ่ืาࠦำ้ใࠣ๎ุฮศࠡฬะำ๏ัࠠโ๊ิ๎๊ࠥฬๆ์฼ࠤํ฾ววใࠣห้ฮั็ษ่ะࠥอไห์ࠣฮ฾ะๅะࠢ฼่๎ࠦๅา๊ิࠤํ่สࠡ็฼๎๋࠭ຖ"))
	if aVwGA2kFY6u4m:
		hRWC8YSFvsm4JHOMVIne3jquZ.setSetting(mQNonhS7CV2BXOv(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡷ࡭ࡵࡲࡵࠩທ"),b8Qe150xVaJsnDSv)
		hRWC8YSFvsm4JHOMVIne3jquZ.setSetting(m6hwdgP31a2zjN7lkpX(u"ࠬࡧࡶ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮࠲ࡷ࡫ࡧࡶ࡮ࡤࡶࠬຘ"),b8Qe150xVaJsnDSv)
		hRWC8YSFvsm4JHOMVIne3jquZ.setSetting(LAQD5wEkr18bUiGaYen3J(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡲ࡯࡯ࡩࠪນ"),b8Qe150xVaJsnDSv)
		hRWC8YSFvsm4JHOMVIne3jquZ.setSetting(mQNonhS7CV2BXOv(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴࡭ࡦࡵࡶࡥ࡬࡫ࡳࠨບ"),b8Qe150xVaJsnDSv)
		hRWC8YSFvsm4JHOMVIne3jquZ.setSetting(DYakr9g4PVU(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮ࡲࡷࡨࡷࡹ࡯࡯࡯ࡵࠪປ"),b8Qe150xVaJsnDSv)
		tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬຜ"),IjZbnrBJmM2N(u"ࠪฮ๊ࠦๅิฯࠣษ฾ีวะษอࠤฬ๊ศา่ส้ัࠦวๅะสูฮࠦศ้ไอࠤั๊ศࠡษ็ฮาี๊ฬษอࠤ࠳࠴้ࠠี๋ๅࠥ๐โ้็ࠣห้ฮั็ษ่ะࠥอไร่ࠣฬฯำฯ๋อ๋ࠣีํࠠศๆศ฽ิอฯศฬࠣ࠲࠳่ࠦฤ์ูหࠥะอะ์ฮࠤํ฾ววใࠣห้ฮั็ษ่ะࠥอไห์ࠣฮ฾ะๅะࠢ฼่๎ࠦวๅ๊ๅฮࠬຝ"))
		qMGn9u2ckaXejCgUQhYTDP(DD5cFIejQa2X4BgAu9GWPyJ3tC7)
	return
def AkVKUSHc3QdyqIpF9N4MvZWTf5():
	aVwGA2kFY6u4m = BjMmX1vNrnzSAf(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,dDYUoKi6JFM23p(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧພ"),DYakr9g4PVU(u"ࠬํไࠡฬิ๎ิࠦแฺๆสࠤู๊อࠡฮ่๎฾ࠦลฺัสำฬะࠠศๆหี๋อๅอࠢ࠱࠲ࠥ๎ๅิฯࠣะ๊๐ูࠡ็็ๅฬะࠠศๆหี๋อๅอࠢส่็ี๊ๆหࠣ࠲࠳ࠦไไ์ࠣ๎฾๎ฯࠡษ็ฬึ์วๆฮࠣษ้๏ࠠฮษ็อࠥอไึใิࠤ࠳࠴๋ࠠ฻้๎ࠥะฬะ์าࠤฬ๊ศา่ส้ั่ࠦหืไ๎ึํู้๊ࠠ฽์ࠦศฮษ็อࠥอไๆื้฽ࠥอไห์ࠣ์฻฿็ศࠢส่๊ฮัๆฮࠣรࠦࠧࠧຟ"))
	if aVwGA2kFY6u4m:
		v03F6pMmYs2hBfUT(DD5cFIejQa2X4BgAu9GWPyJ3tC7)
		p3pjrEcdKBfsDZw4qSJ(vIaQF8hqXeiJERYuD,CCxMXuNUEzolDZTKrBJ,DD5cFIejQa2X4BgAu9GWPyJ3tC7)
		tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,UUkIBz1sgQ9WfNeG6trKXvu0(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩຠ"),QQdAXWBc2GPw(u"ࠧห็ุ้ࠣำࠠอ็ํ฽ࠥอไๆๆไหฯࠦวๅไา๎๊ฯࠠๅๆหี๋อๅอࠢ࠱࠲ࠥ๎ูศัࠣห้ฮั็ษ่ะࠥหไฺ๊๋ࠢ฾๐ษࠡษ็ูๆืࠠ࠯࠰ࠣ์฻฿๊สࠢส่๊฻ๆฺࠩມ"))
	return
def Nld5Fv8rwobfXG4JPpEcMCO2B():
	zqbhiLmQfC3VK9Arku(mshLJcKH1fv03yRnDOr4ZT,LAQD5wEkr18bUiGaYen3J(u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫຢ"),RRIHDFjoW9w7bSfVPhC(u"ࠩࡔ࡙ࡊ࡙ࡔࡊࡑࡑࡗࠬຣ"))
	I6EPVkCug24fet = Lv5gTyYmiskeUS(DD5cFIejQa2X4BgAu9GWPyJ3tC7)
	fnsMXVz1pTgrjtkLE = eeN6dTEnkJxI
	euFIvVSjD5 = OkuB9nwhD8U1+mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠪࠤ࠲࠳࠭࠮࠯ࠣ࠱࠲࠳࠭࠮ࠢ࠰࠱࠲࠳࠭ࠡ࠯࠰࠱࠲࠳ࠠ࠮࠯࠰࠱࠲ࠦࠧ຤")+hAIp8kmC36T5WFPMSXOwnNbtD
	iTWwMXD2rfQIAJGR34 = eeN6dTEnkJxI+rC3Tlno96KjLDIvBaSWUbR8+LAQD5wEkr18bUiGaYen3J(u"ࠫࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠࠨລ")+hAIp8kmC36T5WFPMSXOwnNbtD+RRIHDFjoW9w7bSfVPhC(u"ࠬࡢ࡮࡝ࡰࠪ຦")
	for id,y9i63b5jQSGqUsfguZxPkTK,wqxUVjrJvLpasn2YyGh0zuAi9E7,PPTURnwu345Xji,uua931OmCgEBHP8pDMdsjzXVRSGc4,reason in reversed(I6EPVkCug24fet):
		if id==S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"࠭࠰ࠨວ"):
			iCdDq1Lwx9AtIeUBcp8HFZgKf,PPcnGAwkyrhOSC5fdtNIso8U = PPTURnwu345Xji.split(VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠧ࡝ࡰ࠾࠿ࠬຨ"))
			continue
		if fnsMXVz1pTgrjtkLE!=eeN6dTEnkJxI: fnsMXVz1pTgrjtkLE += iTWwMXD2rfQIAJGR34
		FSpIEkeP1D3ai4VZ5oB92zhy = uVQd103XyvUce2EBtzbYaC(u"ࠨ࡝ࡕࡘࡑࡣࠧຩ")+OkuB9nwhD8U1+id+HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠩࠣ࠾ࠥ࠭ສ")+UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠪหู้ฤศๆࠣ࠾ࠥ࠭ຫ")+hAIp8kmC36T5WFPMSXOwnNbtD+wqxUVjrJvLpasn2YyGh0zuAi9E7
		eqURlBsy0m82xwA = HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠫࡡࡴ࡛ࡓࡖࡏࡡࠬຬ")+OkuB9nwhD8U1+Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠬอไอ๊สฬࠥࡀࠠࠨອ")+hAIp8kmC36T5WFPMSXOwnNbtD+PPTURnwu345Xji
		zzi8PC6qjXNa5hBw = LAQD5wEkr18bUiGaYen3J(u"࡛࠭ࡓࡖࡏࡡࠬຮ")+OkuB9nwhD8U1+vvWwO3Tx2dAgcijrFXq(u"ࠧศๆั฻ศࠦ࠺ࠡࠩຯ")+hAIp8kmC36T5WFPMSXOwnNbtD+uua931OmCgEBHP8pDMdsjzXVRSGc4
		xVzSyEukoGicNQs18elLm = kke1PDGRBLuY8y(u"ࠨ࡞ࡱ࡟ࡗ࡚ࡌ࡞ࠩະ")+OkuB9nwhD8U1+UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠩสุ่ฮศࠡ࠼ࠣࠫັ")+hAIp8kmC36T5WFPMSXOwnNbtD+reason
		fnsMXVz1pTgrjtkLE += FSpIEkeP1D3ai4VZ5oB92zhy+eqURlBsy0m82xwA+eeN6dTEnkJxI+euFIvVSjD5+eeN6dTEnkJxI+zzi8PC6qjXNa5hBw+xVzSyEukoGicNQs18elLm+eeN6dTEnkJxI
	bJvWMFh8G3eas(VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠪࡶ࡮࡭ࡨࡵࠩາ"),PPcnGAwkyrhOSC5fdtNIso8U,fnsMXVz1pTgrjtkLE,zI3ROAZtiUq42rE9WDST68(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺ࡟࡭ࡱࡱ࡫ࠬຳ"))
	return
def TTKB4unWj6yLdEeDoR(file):
	if file==KNTV1H9Dl32a6yxiUEBdvZ7qgr: pkJ2vhMlKqQF5d6 = BmePGjS7FxK6kutUM(u"่่ࠬศศ่ࠤฬ๊ๅโุ็อࠬິ")
	elif file==oYXBd89zTnZPipv56Qf1UxurbC3: pkJ2vhMlKqQF5d6 = Nh0BWuiSndf(u"࠭โ้ษษ้ࠥศฮาࠢส่ๆ๐ฯ๋๊๊หฯ࠭ີ")
	c9Wbh7raCVlyPKqpL6GwNZz1u = QlaM6yHe0bgh58Vx3BAZD(shC5qBRV2A0lZ(u"ࠧࡤࡧࡱࡸࡪࡸࠧຶ"),uVQd103XyvUce2EBtzbYaC(u"ࠨ็ึัࠬື"),TYf7Dc06PQgy1vEV9(u"ࠩศู้ออࠨຸ"),mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠪาึ๎ฬࠨູ"),dDYUoKi6JFM23p(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊า຺ࠧ"),zI3ROAZtiUq42rE9WDST68(u"ࠬํไࠡฬิ๎ิࠦลึๆสั๋ࠥไโࠢࠪົ")+pkJ2vhMlKqQF5d6+ubxGUTt1LraKhVZgpAP(u"࠭ࠠฤ็ࠣฮึ๐ฯࠡ็ึัࠥอไๆๆไࠤฤ࠭ຼ"))
	if c9Wbh7raCVlyPKqpL6GwNZz1u==Xz3bA2PFENVCUtplu51(u"࠶ᇅ"):
		if x76PfMyAp1L2WejkU3.path.exists(file):
			try: x76PfMyAp1L2WejkU3.remove(file)
			except: pass
		tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,shC5qBRV2A0lZ(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪຽ"),shC5qBRV2A0lZ(u"ࠨฬ่ࠤู๊อࠡ็็ๅࠥ࠭຾")+pkJ2vhMlKqQF5d6)
	elif c9Wbh7raCVlyPKqpL6GwNZz1u==HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"࠱ᇆ"):
		data = dyWw4klir2R3uM8DUthJxKP(file)
		tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ຿"),Nh0BWuiSndf(u"ࠪฮ๊ࠦลึๆสั๋ࠥไโࠢࠪເ")+pkJ2vhMlKqQF5d6)
	return
def I5zXZqsxiDMPYmFcpleS7K():
	if g1gmkxOtc2oeEZHhBiy<SbjiWeHLQPoazqwp3cODkd7YxVgn(u"࠲࠺ᇇ"):
		A4gdSTQDP2FyBIVuba85RvYqKU = Nh0BWuiSndf(u"้๊ࠫริใࠣว๋ะࠠหีอาิ๋ࠠฦืาหึࠦใ้ัํࠤ็ี๊ๆࠢิๆ๊ࠦࠧແ")+str(g1gmkxOtc2oeEZHhBiy)+ddo23ZJtgcY(u"่ࠬࠦๅ้ำหࠥอไใ๊สส๊ࠦวๅ็ุ์ึฯࠠๅษࠣฮ฾๋ไࠡ฻้ำ่ࠦ࠮้ࠡำ๋ࠥอไๆ์ีอࠥะๅไ่ๆࠤ๊์ࠠาฦํอ่่ࠥศศ่ࠤฬ๊แ๋ัํ์์อสࠡใํࠤอืๆศ็ฯࠤ฾๋วะࠢหุ่๊ࠠึ๊ิࠤอีไศ่๊ࠢࠥอไไฬสฬฮࠦ࠮ࠡๆศู้ออࠡษ็ู้้ไสࠢๅ้ࠥฮสฮัํฯࠥฮั็ษ่ะ้่ࠥะ์ࠣษ้๏ࠠฦ์ࠣษฺีวาࠢิๆ๊ํࠠฤ฻็ํ๋ࠥๆࠡ࠳࠻࠲࠵࠭ໂ")
		tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩໃ"),A4gdSTQDP2FyBIVuba85RvYqKU)
		return
	autQ6O2JANPLKyk3Y = uuxVm0bTwdnCUAL4s6NKHEBF3M.executeJSONRPC(DYakr9g4PVU(u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡓࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡉࡨࡸࡘ࡫ࡴࡵ࡫ࡱ࡫࡛ࡧ࡬ࡶࡧࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡵࡨࡸࡹ࡯࡮ࡨࠤ࠽ࠦࡱࡵ࡯࡬ࡣࡱࡨ࡫࡫ࡥ࡭࠰ࡶ࡯࡮ࡴࠢࡾࡿࠪໄ"))
	EJcfC7seYxiG = YqPryjvitICmH([yST5AHEfvPmcWpwGuh2BJ(u"ࠨࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊࠧ໅")])
	mEvj8WVaX6fNFD4eCdgtn5,WPrXihn9IZ6,DGAp2B7kLwX,fi9ehsMGT3tInZlmU6vF8E5qp,LLIAmpfHaJDGYTs9cwB,ln62BFgAxmM1b,P63wAzQKXdbJvsn = EJcfC7seYxiG[RRIHDFjoW9w7bSfVPhC(u"ࠩࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄࠨໆ")]
	if mEvj8WVaX6fNFD4eCdgtn5 or Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠪࡷࡰ࡯࡮࠯࡯ࡨࡸࡷࡵࡰࡰ࡮࡬ࡷࡊࡓࡁࡅࠩ໇") not in str(autQ6O2JANPLKyk3Y):
		tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,shC5qBRV2A0lZ(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊า່ࠧ"),uVQd103XyvUce2EBtzbYaC(u"ࠬอไใ๊สส๊ࠦวๅ็ุ์ึฯࠠห฻่่ࠥ็โุ่ࠢ฽ࠥาไะ่ࠢฮึ๎ศ้ๆึࠤ฾๋วะࠢ࠱ࠤ์ึ็ࠡษ็ๆํอฦๆࠢอ้่์ใࠡ็้ࠤึส๊สࠢๅ์ฬฬๅࠡสิ๊ฬ๋ฬࠡ฻่หิࠦศีๅ็ࠤฺ๎ัࠡสา่ฬࠦๅ็ࠢส่่ะวษห້ࠪ"))
		ip6CohvO5Tya9mFWVf3JdY1qL = xekZcFabtTw()
		if not ip6CohvO5Tya9mFWVf3JdY1qL: return
	UWBjmvw5CIz3Dt8i(CCxMXuNUEzolDZTKrBJ)
	return
def UWBjmvw5CIz3Dt8i(showDialogs=CCxMXuNUEzolDZTKrBJ):
	autQ6O2JANPLKyk3Y = uuxVm0bTwdnCUAL4s6NKHEBF3M.executeJSONRPC(IjZbnrBJmM2N(u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾࡙ࠧࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡈࡧࡷࡗࡪࡺࡴࡪࡰࡪ࡚ࡦࡲࡵࡦࠤ࠯ࠦ࡮ࡪࠢ࠻࠳࠯ࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡴࡧࡷࡸ࡮ࡴࡧࠣ࠼ࠥࡰࡴࡵ࡫ࡢࡰࡧࡪࡪ࡫࡬࠯ࡵ࡮࡭ࡳࠨࡽࡾ໊ࠩ"))
	if dDYUoKi6JFM23p(u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ໋࠭") not in str(autQ6O2JANPLKyk3Y):
		if showDialogs:
			tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,kke1PDGRBLuY8y(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ໌"),mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠩ็่ศูแࠡฮ๊หื้ࠠๅษࠣ๎ุะฮะ็ࠣะ้ีࠠๆฬิ์อ๎ไิࠢ฼้ฬีࠠ࠯ࠢส่็๎วว็ࠣห้๋ี้ำฬࠤฯ฿ๅๅࠢไๆ฼ࠦๅฺࠢฯ่ิࠦๅหำ๋ฬํ๊ำࠡ฻่หิࠦ࠮้ࠡำ๋ࠥอไใ๊สส๊ࠦสๆๅ้็๋ࠥๆࠡำว๎ฮࠦโ้ษษ้ࠥฮั็ษ่ะࠥ฿ๅศัࠣฬู้ไࠡื๋ีࠥฮฯๅษ้๋ࠣࠦวๅๅอหอฯࠧໍ"))
		return
	Ji09BCwjselHnRorZGuY5v3fO6Vm = x76PfMyAp1L2WejkU3.path.join(BdO6FDlYv4naqZf1gCGbS7V,UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠪࡥࡩࡪ࡯࡯ࡵࠪ໎"),yST5AHEfvPmcWpwGuh2BJ(u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪ໏"),mQNonhS7CV2BXOv(u"ࠬ࠽࠲࠱ࡲࠪ໐"),VFjQx6Is28KvzLOmMXtg4GqTwa3(u"࠭ࡍࡺࡘ࡬ࡨࡪࡵࡎࡢࡸ࠱ࡼࡲࡲࠧ໑"))
	if not x76PfMyAp1L2WejkU3.path.exists(Ji09BCwjselHnRorZGuY5v3fO6Vm): return
	xgjifnIWe3aDs5kK81vu04U7FE = open(Ji09BCwjselHnRorZGuY5v3fO6Vm,Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠧࡳࡤࠪ໒")).read()
	if i1thmHk7AZquD4cM0fnp62: xgjifnIWe3aDs5kK81vu04U7FE = xgjifnIWe3aDs5kK81vu04U7FE.decode(OVauxZzLI10vcXT74K)
	Wcjp4nHalZkC = YYBlm36zd0Jst18LXwo4.findall(UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠨ࠾ࡹ࡭ࡪࡽࡳ࠿ࠪ࡟ࡨ࠰࠲࡜ࡥ࠭࠯ࡠࡩ࠱ࠩ࠭ࠪ࠱࠮ࡄ࠯࠼࠰ࡸ࡬ࡩࡼࡹ࠾ࠨ໓"),xgjifnIWe3aDs5kK81vu04U7FE,YYBlm36zd0Jst18LXwo4.DOTALL)
	wu3729shgBy,ZMmTw1xodq = Wcjp4nHalZkC[LzYQg91SIxDeOGtCKd5]
	dMOHxlGXCnKSUzbBiRv1 = P0qdZI384LKleuo(u"ࠩ࠿ࡺ࡮࡫ࡷࡴࡀࠪ໔")+wu3729shgBy+ubxGUTt1LraKhVZgpAP(u"ࠪ࠰ࠬ໕")+ZMmTw1xodq+P0qdZI384LKleuo(u"ࠫࡁ࠵ࡶࡪࡧࡺࡷࡃ࠭໖")
	if showDialogs:
		LLRFKwuM0dEh = uuxVm0bTwdnCUAL4s6NKHEBF3M.getInfoLabel(ubxGUTt1LraKhVZgpAP(u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡘ࡬ࡩࡼࡳ࡯ࡥࡧࠪ໗"))
		if LLRFKwuM0dEh==HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"࠭ࡅࡎࡃࡇࠤࡑ࡯ࡳࡵࠩ໘"): P39CEXwDGUVl2e65cyS71Bvqu4O = RRIHDFjoW9w7bSfVPhC(u"ࠧใ๊สส๊ࠦวๅๅอหอฯࠧ໙")
		elif LLRFKwuM0dEh==SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠨࡇࡐࡅࡉࠦࡇࡢ࡮࡯ࡩࡷࡿࠧ໚"): P39CEXwDGUVl2e65cyS71Bvqu4O = Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠩๅ์ฬฬๅࠡษ็ูํืࠧ໛")
		else: P39CEXwDGUVl2e65cyS71Bvqu4O = ddo23ZJtgcY(u"ࠪๆํอฦๆࠢฦาึ๏ࠧໜ")
		c9Wbh7raCVlyPKqpL6GwNZz1u = QlaM6yHe0bgh58Vx3BAZD(TYf7Dc06PQgy1vEV9(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫໝ"),Nh0BWuiSndf(u"่่ࠬศศ่ࠤศิั๊ࠩໞ"),SbjiWeHLQPoazqwp3cODkd7YxVgn(u"࠭โ้ษษ้ࠥอไไฬสฬฮ࠭ໟ"),shC5qBRV2A0lZ(u"ࠧใ๊สส๊ࠦวๅื๋ีࠬ໠"),RRIHDFjoW9w7bSfVPhC(u"ࠨษ้ฮࠥำวๅ์สࠤฯูสฯั่ࠤࠬ໡")+P39CEXwDGUVl2e65cyS71Bvqu4O,BWNPxIG7vqdTy85pjHzUOrK3(u"ࠩส๊ฯࠦวๅฤ้ࠤฯูสฯั่ࠤฬ๊ลึัสีࠥอไฤะํี๊ࠥฬๅั้ࠣฯื่ษ๊็ืࠥ฿ๅศัࠣ࠲ࠥ๎็ัษ้ࠣ฾์ว่ࠢส๊่ࠦสิฬฺ๎฾ࠦวิฬัำฬ๋ࠠศๆๅ์ฬฬๅࠡษ็ฺ้๎ัสࠢหำ้อࠠๆ่ࠣๆํอฦๆࠢส่่ะวษหࠣ࠲ࠥ๎รุ๋สࠤฯูสุ์฼ࠤส๐โศใ๊หࠥ็๊ࠡลํࠤํ่สࠡฬืหฦࠦ࡜࡯࡞ࡱࠤࠬ໢")+OkuB9nwhD8U1+RRIHDFjoW9w7bSfVPhC(u"ࠪࠤศิสาࠢส่ว์ࠠ็๊฼ࠤฬ๊โ้ษษ้ࠥอไห์ࠣฮึ๐ฯࠡลึฮำีวๆ้สࠤฤࠧࠧ໣")+hAIp8kmC36T5WFPMSXOwnNbtD)
		if c9Wbh7raCVlyPKqpL6GwNZz1u==QTUBCcehw6qPd4x(u"࠳ᇈ"): Xgkm8ZVN7vzxe = TYf7Dc06PQgy1vEV9(u"ࠫࡊࡓࡁࡅࠢࡏ࡭ࡸࡺࠧ໤")
		elif c9Wbh7raCVlyPKqpL6GwNZz1u==Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"࠵ᇉ"): Xgkm8ZVN7vzxe = yST5AHEfvPmcWpwGuh2BJ(u"ࠬࡋࡍࡂࡆࠣࡋࡦࡲ࡬ࡦࡴࡼࠫ໥")
		else: Xgkm8ZVN7vzxe = b8Qe150xVaJsnDSv
	else:
		LLRFKwuM0dEh = hRWC8YSFvsm4JHOMVIne3jquZ.getSetting(ddo23ZJtgcY(u"࠭ࡡࡷ࠰ࡰࡽࡸࡱࡩ࡯࠰ࡹ࡭ࡪࡽ࡭ࡰࡦࡨࠫ໦"))
		if   LLRFKwuM0dEh==b8Qe150xVaJsnDSv: c9Wbh7raCVlyPKqpL6GwNZz1u = zI3ROAZtiUq42rE9WDST68(u"࠴ᇊ")
		elif LLRFKwuM0dEh==Mmpr0o76iWJvz1kTtfgI8hES(u"ࠧࡆࡏࡄࡈࠥࡒࡩࡴࡶࠪ໧"): c9Wbh7raCVlyPKqpL6GwNZz1u = m6hwdgP31a2zjN7lkpX(u"࠶ᇋ")
		elif LLRFKwuM0dEh==mQNonhS7CV2BXOv(u"ࠨࡇࡐࡅࡉࠦࡇࡢ࡮࡯ࡩࡷࡿࠧ໨"): c9Wbh7raCVlyPKqpL6GwNZz1u = mQNonhS7CV2BXOv(u"࠸ᇌ")
		Xgkm8ZVN7vzxe = LLRFKwuM0dEh
	if   c9Wbh7raCVlyPKqpL6GwNZz1u==QQdAXWBc2GPw(u"࠰ᇍ"): HrLgeVNKYf2zOnosIT6t5 = SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠩ࠸࠹࠱࠻࠴࠵࠮࠸࠹࠺࠭໩")
	elif c9Wbh7raCVlyPKqpL6GwNZz1u==shC5qBRV2A0lZ(u"࠲ᇎ"): HrLgeVNKYf2zOnosIT6t5 = HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠪ࠹࠹࠺ࠬ࠶࠷࠸࠰࠺࠻ࠧ໪")
	elif c9Wbh7raCVlyPKqpL6GwNZz1u==yST5AHEfvPmcWpwGuh2BJ(u"࠴ᇏ"): HrLgeVNKYf2zOnosIT6t5 = m6hwdgP31a2zjN7lkpX(u"ࠫ࠺࠻࠵࠭࠷࠸࠰࠺࠺࠴ࠨ໫")
	else: return
	hRWC8YSFvsm4JHOMVIne3jquZ.setSetting(shC5qBRV2A0lZ(u"ࠬࡧࡶ࠯࡯ࡼࡷࡰ࡯࡮࠯ࡸ࡬ࡩࡼࡳ࡯ࡥࡧࠪ໬"),Xgkm8ZVN7vzxe)
	EjKT2bJmL9nNySUx4R03Dlz = Mmpr0o76iWJvz1kTtfgI8hES(u"࠭࠼ࡷ࡫ࡨࡻࡸࡄࠧ໭")+HrLgeVNKYf2zOnosIT6t5+LAQD5wEkr18bUiGaYen3J(u"ࠧ࠭ࠩ໮")+ZMmTw1xodq+S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠨ࠾࠲ࡺ࡮࡫ࡷࡴࡀࠪ໯")
	SacP9lh0WiMUZrGDq = xgjifnIWe3aDs5kK81vu04U7FE.replace(dMOHxlGXCnKSUzbBiRv1,EjKT2bJmL9nNySUx4R03Dlz)
	if i1thmHk7AZquD4cM0fnp62: SacP9lh0WiMUZrGDq = SacP9lh0WiMUZrGDq.encode(OVauxZzLI10vcXT74K)
	open(Ji09BCwjselHnRorZGuY5v3fO6Vm,vvWwO3Tx2dAgcijrFXq(u"ࠩࡺࡦࠬ໰")).write(SacP9lh0WiMUZrGDq)
	mwIxD3GBPgLVc2aq9(MtTygrzXFlQ,TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠪ࠲ࡡࡺࡓ࡬࡫ࡱࠤࡉ࡫ࡦࡢࡷ࡯ࡸࠥ࡜ࡩࡦࡹࡶ࠾ࠥࡡࠠࠨ໱")+HrLgeVNKYf2zOnosIT6t5+S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠫࠥࡣࠧ໲"))
	if showDialogs: uuxVm0bTwdnCUAL4s6NKHEBF3M.executebuiltin(shC5qBRV2A0lZ(u"ࠬࡘࡥ࡭ࡱࡤࡨࡘࡱࡩ࡯ࠪࠬࠫ໳"))
	return
def vRrl9O7fbc1IWEY8KBw0T():
	aVwGA2kFY6u4m = BjMmX1vNrnzSAf(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,UUkIBz1sgQ9WfNeG6trKXvu0(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ໴"),ddo23ZJtgcY(u"ࠧษำ้ห๊าฺࠠ็สำࠥ็ุ๊่่่๊ࠢษࠡ฻้ำ่ࠦ࠮࠯࠰ࠣษ๊อࠠฤๆศูิอัࠡไา๎๊ࠦ࠮࠯࠰ࠣวํࠦว็ฬ้๊ࠣ์ฺ่่๊ࠢࠥอำหะาห๊ࠦวๅสิ๊ฬ๋ฬࠡ࠰࠱࠲ࠥษ่ࠡๆา๎่ࠦๅีๅ็อࠥษฮา๋ࠣฮำ฻ࠠอ้สึ่ࠦร็ฬࠣ์้อࠠหะุࠤอ่๊สࠢั่็ࠦวๅๆ๊ࠤࡡࡴ࡜࡯ࠢะหํ๊ࠠหฯา๎ะࠦวๅสิ๊ฬ๋ฬࠡล๋ࠤฬะีๅࠢหห้๋ศา็ฯࠤู้๋าใฬࠤุฮศࠡษ็ู้้ไสࠢ฼๊ิ้ࠠ࠯࠰࠱ࠤ์๊ࠠหำํำࠥ็อึࠢส่ฯำฯ๋อสฮࠥอไร่ࠣรࠬ໵"))
	if aVwGA2kFY6u4m==dDYUoKi6JFM23p(u"࠴ᇐ"): Ef82HhjNckZGo1Xvy0()
	return
def Njpw9ear7PYf1EBdtTyILMcHnv8Gx():
	tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,LAQD5wEkr18bUiGaYen3J(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ໶"),Xz3bA2PFENVCUtplu51(u"๊ࠩิฬࠦวๅ็๋ๆ฾ࠦๅ฻ๆๅࠤ๊์ࠠศๆู่ิื้ࠠ฼ํีู๋ࠥา๊ไࠤ๊ะ๊ࠡ์ิะ฾ࠦไๅ฻่่ࠬ໷"))
	return
def nVBI5RPDkU01FmE8XZv2pOotj4aG():
	FSpIEkeP1D3ai4VZ5oB92zhy = OkuB9nwhD8U1+mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠪฮ฾ีวะࠢื๎฾ฯࠠรๆ้ࠣา๋ฯࠡๆึ๊ฮࠦ࠲࠱࠴࠴ࠤ࠿ࠦࠧ໸")+hAIp8kmC36T5WFPMSXOwnNbtD
	FSpIEkeP1D3ai4VZ5oB92zhy += ubxGUTt1LraKhVZgpAP(u"ࠫฬ๊ๅ้ไ฼ࠤศีๆศ้ࠣๅ๏ํࠠฦฯุหห๐ษࠡๆ฼ำิࠦวๅึํ฽ฮࠦแ๋ࠢส่฾อไๆࠢอ้ࠥาๅฺ้สࠤ๊์ࠠอ็ํ฽ࠥอไๆืสำึࠦวๅ็อ์ๆืษࠡใํࠤฬ๊ล็ฬิ๊ฯࠦวๅไา๎๊ฯ้ࠠษ็ะิ๐ฯสࠢส่า้่ๆ์ฬࠤํอไ฻์ิࠤา้่ๆ์ฬࠤํ๋ๆࠡฮ่๎฾ࠦฯ้ๆࠣห้฿วๅ็ࠣฯ๊ࠦสๆࠢอ์า๐ฯ่ษࠣ์าูวษࠢส่๊฿ฯๅࠢะือࠦำไษ้ࠤิ๎ไࠡษ็฽ฬ๊ๅࠡๆึ๊ฮࠦ࠲࠱࠴࠴ࠤํํ๊ࠡษ็ษา฻วว์ฬࠤฬ๊รฮัฮࠤํอไฤึ่่ࠥอไห์ࠣฮู๊ࠦๆๆ๊หࠥ็๊ࠡษ็ื๋๎วหࠢส่฾ฺัสࠢส่๊อึ๋หࠪ໹")
	FSpIEkeP1D3ai4VZ5oB92zhy += eeN6dTEnkJxI+OkuB9nwhD8U1+BmePGjS7FxK6kutUM(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡴࡪࡰࡼ࠲ࡨࡩ࠯ࡴࡪ࡬ࡥࡨࡵࡵ࡯ࡶࠪ໺")+hAIp8kmC36T5WFPMSXOwnNbtD
	eqURlBsy0m82xwA = OkuB9nwhD8U1+BmePGjS7FxK6kutUM(u"࠭ศา่ส้ัࠦิา์ฺࠤฬ๊ๅิๆ่ࠤ࠿ࠦࠧ໻")+hAIp8kmC36T5WFPMSXOwnNbtD
	eqURlBsy0m82xwA += TT8Mxv5Wq7nlC9IscdpPUY6(u"่๊ࠧࠣ฽ออัสࠢ฼๊ࠥฮั็ษ่ะࠥ๐่โำ้ࠣ฾๊่ๆษอࠤาูวษ์ฬࠤ่ั๊าหࠣฮ์๋ࠠอ็ํ฽ࠥอไๆี็้๏์ࠠๆอ็ࠤศ๎โศฬࠣห้฻ไศหࠣ์ศ๎โศฬࠣห้้ำ้ใࠣ์ฬ๊ฮิ๊ไࠤํฺใๅࠢส่็๋ั๊ࠡฦ์็อสࠡษ็ๆ๊ื้ࠠลํฺฬ๊้ࠦใิࠤึส๊สࠢส่์๊วๅࠢไ๎ࠥาๅ๋฻ࠣำํ๊ࠠศๆ฼ห้๋้ࠠลํฺฬࠦแ๋้ࠣฮ็๎๊ๆ่ࠢ๎้อฯ๋๋๋ࠢัื๊๊ࠡไ๎์ࠦรุ๋สࠤอำห๊ࠡๅีฬวษࠡษ็ๆึศๆ๊ࠡฦ๎฻อࠠโ์๊ࠤฬูสฯษิอࠥ๎สโษว่ࠥ๎แ๋้ࠣว็๎วๅุ่๊ࠢ๎ศสࠢ็่ศ๋วๆࠢ฼่๏่ࠦฤ็๋ีࠥษฮา๋ࠣฮ์๋ࠠไๆุ้๊ࠣๅࠡ࠰ࠣห้ฮั็ษ่ะ๋ࠥให๊หࠤอฺ๊สࠢฯหๆอࠠิๅิฬฯ่๋ࠦีอาิ๋ࠠ็ฺส้ࠥ๎๊็ั๋ึࠥะอหࠢห๎หฯ้ࠠ์้ำํุࠠไษฯ๎ฯ่ࠦๆะุูࠥ็โุࠢ็วัําสࠢส่ํ๐ๆะ๊ีࠤ࠳ࠦวๅ็๋ๆ฾ࠦวๅำึ้๏ࠦไๅสิ๊ฬ๋ฬ้๋ࠡࠫ໼")
	eqURlBsy0m82xwA += eeN6dTEnkJxI+OkuB9nwhD8U1+DYakr9g4PVU(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡷ࡭ࡳࡿ࠮ࡤࡥ࠲ࡱࡺࡹ࡬ࡪ࡯ࡵࡹࡱ࡫ࡲࠨ໽")+hAIp8kmC36T5WFPMSXOwnNbtD
	A4gdSTQDP2FyBIVuba85RvYqKU = VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠩ࡞ࡖ࡙ࡒ࡝ࠨ໾")+FSpIEkeP1D3ai4VZ5oB92zhy+ubxGUTt1LraKhVZgpAP(u"ࠪࡠࡳࡢ࡮࡝ࡰ࡞ࡖ࡙ࡒ࡝ࠨ໿")+eqURlBsy0m82xwA
	bJvWMFh8G3eas(zI3ROAZtiUq42rE9WDST68(u"ࠫࡷ࡯ࡧࡩࡶࠪༀ"),b8Qe150xVaJsnDSv,A4gdSTQDP2FyBIVuba85RvYqKU)
	return
def X5Q6PnJcimdhwT7H(XX8FguGmKp5DVB2Twifsc):
	lp8eUQ9rw25BhRgWNPHT7K(nCUMfrlZvuiLe5x)
	I6EPVkCug24fet = Lv5gTyYmiskeUS(XX8FguGmKp5DVB2Twifsc)
	for Eqh4xYr9VWQSc2kf0biID in [LAQD5wEkr18bUiGaYen3J(u"ࠬࡓࡅࡔࡕࡄࡋࡊ࡙ࠧ༁"),m6hwdgP31a2zjN7lkpX(u"࠭ࡑࡖࡇࡖࡘࡎࡕࡎࡔࠩ༂"),TYf7Dc06PQgy1vEV9(u"ࠧࡎࡇࡖࡗࡆࡍࡅࡔࡡࡗࡗࠬ༃"),m6hwdgP31a2zjN7lkpX(u"ࠨࡓࡘࡉࡘ࡚ࡉࡐࡐࡖࡣ࡙࡙ࠧ༄")]:
		if Eqh4xYr9VWQSc2kf0biID in ZHIif0JXSYpqh1OKuoR: ZHIif0JXSYpqh1OKuoR.remove(Eqh4xYr9VWQSc2kf0biID)
	chmoCAX8ab7kIirTfJy6YM3zsGq4(yST5AHEfvPmcWpwGuh2BJ(u"ࠩࡇࡓࡓࡇࡔࡊࡑࡑࡗࠬ༅"))
	id,y9i63b5jQSGqUsfguZxPkTK,wqxUVjrJvLpasn2YyGh0zuAi9E7,PPTURnwu345Xji,uua931OmCgEBHP8pDMdsjzXVRSGc4,reason = I6EPVkCug24fet[LzYQg91SIxDeOGtCKd5]
	iCdDq1Lwx9AtIeUBcp8HFZgKf,PPcnGAwkyrhOSC5fdtNIso8U = PPTURnwu345Xji.split(HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠪࡠࡳࡁ࠻ࠨ༆"))
	eqURlBsy0m82xwA,zzi8PC6qjXNa5hBw,xVzSyEukoGicNQs18elLm = uua931OmCgEBHP8pDMdsjzXVRSGc4.split(UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠫࡡࡴ࠻࠼ࠩ༇"))
	nCcwph7Rai1EOGsKlgxV = CCxMXuNUEzolDZTKrBJ
	while nCcwph7Rai1EOGsKlgxV:
		zzcNSad4T7C2KBMEL9ky = QlaM6yHe0bgh58Vx3BAZD(b8Qe150xVaJsnDSv,DYakr9g4PVU(u"ࠬิั้ฮࠪ༈"),uVQd103XyvUce2EBtzbYaC(u"࠭ลาีส่ࠥืำศๆฬࠤ้๊ๅษำ่ะࠬ༉"),mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠧใษษ้ฮࠦวๅฬหี฾อสࠨ༊"),UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠨๆศ๎็อแࠡษ็ษ฾๊ว็ษอࠤ࠿ࠦࠠหสิ฽ࠥษ่ࠡษ่ืาࠦวๅสิ๊ฬ๋ฬࠨ་"),eqURlBsy0m82xwA)
		if zzcNSad4T7C2KBMEL9ky==BmePGjS7FxK6kutUM(u"࠶ᇑ"): qzY6Am2c0MH5kSalptL = QlaM6yHe0bgh58Vx3BAZD(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,QQdAXWBc2GPw(u"ࠩ฼์ิฯࠧ༌"),b8Qe150xVaJsnDSv,DYakr9g4PVU(u"้ࠪอีรࠡษ็ฮอืูࠡ฼ํี่ࠥวษๆ่้ࠣ์โศึࠪ།"),zzi8PC6qjXNa5hBw,HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠫࡨࡵ࡮ࡧ࡫ࡵࡱࡤࡹ࡭ࡢ࡮࡯ࡪࡴࡴࡴࠨ༎"))
		elif zzcNSad4T7C2KBMEL9ky==DYakr9g4PVU(u"࠶ᇒ"): lcA0mHzo1TQUIwMKZa8()
		else: nCcwph7Rai1EOGsKlgxV = DD5cFIejQa2X4BgAu9GWPyJ3tC7
	if XX8FguGmKp5DVB2Twifsc: qMGn9u2ckaXejCgUQhYTDP(DD5cFIejQa2X4BgAu9GWPyJ3tC7)
	return
def v03F6pMmYs2hBfUT(showDialogs):
	aVwGA2kFY6u4m = CCxMXuNUEzolDZTKrBJ
	if showDialogs: aVwGA2kFY6u4m = BjMmX1vNrnzSAf(shC5qBRV2A0lZ(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ༏"),b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"࠭ำลษ็ࠫ༐"),mQNonhS7CV2BXOv(u"่ࠧๆࠣว๋ะࠠๆฬฦ็ิ่ࠦหำํำ๋ࠥำฮ๋ࠢฮฺ็๊าࠢฯ้๏฿ࠠฦ฻าหิอสࠡสิ๊ฬ๋ฬࠡ฻่หิࠦไๅใํำ๏๎็ศฬࠣห้฿ัษ์ฬࠤ࠳ࠦอ๋อࠣฮ฾๎ฯࠡฮ่๎฾ࠦวๅว฼ำฬีวหࠢศ่๎่ࠦื฻ํอࠥะหษ์อࠤฬ๊ศา่ส้ัࠦฟࠨ༑"))
	if aVwGA2kFY6u4m:
		ip6CohvO5Tya9mFWVf3JdY1qL = CCxMXuNUEzolDZTKrBJ
		if x76PfMyAp1L2WejkU3.path.exists(JFdIziR9upbBfls0ZL468V):
			try: x76PfMyAp1L2WejkU3.remove(JFdIziR9upbBfls0ZL468V)
			except: ip6CohvO5Tya9mFWVf3JdY1qL = DD5cFIejQa2X4BgAu9GWPyJ3tC7
		if showDialogs:
			if ip6CohvO5Tya9mFWVf3JdY1qL: tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠨฬ่ࠤอ์ฬศฯุ้ࠣำ้ࠠฬุๅ๏ืࠠๆๆไࠤส฿ฯศัสฮࠥฮั็ษ่ะࠥ฿ๅศั่้ࠣ็๊ะ์๋๋ฬะࠠศๆ฼ีอ๐ษࠨ༒"))
			else: tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,P0qdZI384LKleuo(u"ࠩ็่ศูแࠡใื่ฯูࠦๆๆํอ๋ࠥำฮ่่ࠢๆࠦวๅว฼ำฬีวหࠩ༓"))
	return
def FpaODNuVeSTnG():
	m3mZndtTeo5ADCWYr6b0()
	OOufwJ7zNaA4Zs2 = hRWC8YSFvsm4JHOMVIne3jquZ.getSetting(SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡨࡵࡶࡳࡧࡦࡩࡨࡦࠩ༔"))
	A4gdSTQDP2FyBIVuba85RvYqKU = {}
	A4gdSTQDP2FyBIVuba85RvYqKU[Mmpr0o76iWJvz1kTtfgI8hES(u"ࠫࡆ࡛ࡔࡐࠩ༕")] = ubxGUTt1LraKhVZgpAP(u"ࠬอไไษืࠤฬ๊สๅไสส๏ฺ๊ࠦ็็ࠫ༖")
	A4gdSTQDP2FyBIVuba85RvYqKU[DYakr9g4PVU(u"࠭ࡓࡕࡑࡓࠫ༗")] = vvWwO3Tx2dAgcijrFXq(u"ࠧศๆๆหูࠦๅห๊ๅๅࠥะๅศ็สࠤํฮวๅๅส้้༘࠭")
	A4gdSTQDP2FyBIVuba85RvYqKU[IjZbnrBJmM2N(u"ࠨࡎࡌࡑࡎ࡚ࡅࡅ༙ࠩ")] = BmePGjS7FxK6kutUM(u"ࠩๆหูࠦฬะษࠣๆฺ๐ัࠡษ็้ิ๏ࠠ࠯ࠢࠪ༚")+str(CulwpQfz75qMK0PIJSDcaNZ4G/DYakr9g4PVU(u"࠼࠰ᇓ"))+vvWwO3Tx2dAgcijrFXq(u"ࠪࠤิ่๊ใหࠣๅ็฽ࠧ༛")
	FAVpsU1uKjxIXLkrQE9TbmR = A4gdSTQDP2FyBIVuba85RvYqKU[OOufwJ7zNaA4Zs2]
	c9Wbh7raCVlyPKqpL6GwNZz1u = QlaM6yHe0bgh58Vx3BAZD(b8Qe150xVaJsnDSv,uVQd103XyvUce2EBtzbYaC(u"่ࠫอิࠡࠩ༜")+str(CulwpQfz75qMK0PIJSDcaNZ4G/Xz3bA2PFENVCUtplu51(u"࠶࠱ᇔ"))+Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠬࠦฯใ์ๅอࠬ༝"),Xz3bA2PFENVCUtplu51(u"࠭สี฼ํ่ࠥะไใษษ๎ࠬ༞"),zI3ROAZtiUq42rE9WDST68(u"ࠧฦ์ๅหๆࠦใศ็็ࠫ༟"),FAVpsU1uKjxIXLkrQE9TbmR,zI3ROAZtiUq42rE9WDST68(u"ࠨ้็ࠤฯื๊ะࠢสืฯิฯศ็ࠣห้้วีࠢส่ี้๊ࠡษ็ฮ้่วว์ࠣว๊ࠦสา์าࠤส๐โศใࠣห้้วีࠢหห้้วๆๆࠣว๊ࠦสา์าࠤ่อิࠡ฻่ี์ࠦโึ์ิࠤัีวࠡมࠤࠫ༠"))
	if c9Wbh7raCVlyPKqpL6GwNZz1u==P0qdZI384LKleuo(u"࠱ᇕ"): MXAjE1Jqh8UN43RcPOLkb5ZTVCs = mQNonhS7CV2BXOv(u"ࠩࡏࡍࡒࡏࡔࡆࡆࠪ༡")
	elif c9Wbh7raCVlyPKqpL6GwNZz1u==vvWwO3Tx2dAgcijrFXq(u"࠳ᇖ"): MXAjE1Jqh8UN43RcPOLkb5ZTVCs = Xz3bA2PFENVCUtplu51(u"ࠪࡅ࡚࡚ࡏࠨ༢")
	elif c9Wbh7raCVlyPKqpL6GwNZz1u==BWNPxIG7vqdTy85pjHzUOrK3(u"࠵ᇗ"): MXAjE1Jqh8UN43RcPOLkb5ZTVCs = Xz3bA2PFENVCUtplu51(u"ࠫࡘ࡚ࡏࡑࠩ༣")
	else: MXAjE1Jqh8UN43RcPOLkb5ZTVCs = b8Qe150xVaJsnDSv
	if MXAjE1Jqh8UN43RcPOLkb5ZTVCs:
		hRWC8YSFvsm4JHOMVIne3jquZ.setSetting(ddo23ZJtgcY(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡪࡷࡸࡵࡩࡡࡤࡪࡨࠫ༤"),MXAjE1Jqh8UN43RcPOLkb5ZTVCs)
		zqxOCWTFMBEvL2ebarQl7JVy3Kgo = A4gdSTQDP2FyBIVuba85RvYqKU[MXAjE1Jqh8UN43RcPOLkb5ZTVCs]
		tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,zqxOCWTFMBEvL2ebarQl7JVy3Kgo)
	return
def nkxCvmzdXP5qI1UTOL4j():
	A4gdSTQDP2FyBIVuba85RvYqKU = {}
	A4gdSTQDP2FyBIVuba85RvYqKU[yST5AHEfvPmcWpwGuh2BJ(u"࠭ࡁࡖࡖࡒࠫ༥")] = mQNonhS7CV2BXOv(u"ࠧิ์ิๅึࠦࡄࡏࡕࠣห้ะไใษษ๎ࠥ๐ูๆๆ࠽ࠤࠬ༦")
	A4gdSTQDP2FyBIVuba85RvYqKU[Mmpr0o76iWJvz1kTtfgI8hES(u"ࠨࡃࡖࡏࠬ༧")] = ddo23ZJtgcY(u"ࠩึ๎ึ็ัࠡࡆࡑࡗฺู๊ࠥ็็ࠤอ฿ฯࠡษ็ื๊ออࠡๆ๊࠾ࠥ࠭༨")
	A4gdSTQDP2FyBIVuba85RvYqKU[DYakr9g4PVU(u"ࠪࡗ࡙ࡕࡐࠨ༩")] = QTUBCcehw6qPd4x(u"ุࠫ๐ัโำࠣࡈࡓ࡙ࠠๆฬ๋ๆๆࠦสๆษ่หࠥ๎ศศๆๆห๊๊ࠧ༪")
	SNZspJknrBEVDqI0vjz = hRWC8YSFvsm4JHOMVIne3jquZ.getSetting(m6hwdgP31a2zjN7lkpX(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡦࡱࡷࠬ༫"))
	OOufwJ7zNaA4Zs2 = hRWC8YSFvsm4JHOMVIne3jquZ.getSetting(m6hwdgP31a2zjN7lkpX(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡸࡷࡪࡪ࡮ࡴࠩ༬"))
	FAVpsU1uKjxIXLkrQE9TbmR = A4gdSTQDP2FyBIVuba85RvYqKU[OOufwJ7zNaA4Zs2]+SNZspJknrBEVDqI0vjz
	c9Wbh7raCVlyPKqpL6GwNZz1u = QlaM6yHe0bgh58Vx3BAZD(b8Qe150xVaJsnDSv,vvWwO3Tx2dAgcijrFXq(u"ࠧหึ฽๎ู้ࠦ็ัࠣห้๋่ศใๅอࠬ༭"),vvWwO3Tx2dAgcijrFXq(u"ࠨฬื฾๏๊ࠠหๆๅหห๐ࠧ༮"),VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠩศ๎็อแࠡๅส้้࠭༯"),FAVpsU1uKjxIXLkrQE9TbmR,zI3ROAZtiUq42rE9WDST68(u"ࠪื๏ืแาࠢࡇࡒࡘࠦ็้ࠢฯ๋ฬุࠠโ์ࠣห้หๆหำ้๎ฯ๊ࠦใ๊่ࠤอะอ้์็ࠤศูๅศรࠣห้๋่ศไ฼ࠤํอไิ์ิๅึอสࠡว็ํࠥษัใษ่ࠤํ฿ๆะࠢห฽฻ࠦวๅ่สืࠥ๐โ้็ࠣฬาาศ๊่๊ࠡ฾่ࠦฮุิࠤอ฿ึࠡษ็้ํอโฺࠢ࠱ࠤ้ะิ฻์็ࠤุ๐ัโำࠣࡈࡓ࡙ࠠใ็ࠣฬฬิส๋ษิࠤฬ๊ำ๋ำไีࠥอไๆ่สือࠦร้ࠢๅ้ࠥฮล๋ไสๅ์ࠦศศๆๆห๊๊ࠧ༰"))
	if c9Wbh7raCVlyPKqpL6GwNZz1u==HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"࠴ᇘ"): MXAjE1Jqh8UN43RcPOLkb5ZTVCs = HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠫࡆ࡙ࡋࠨ༱")
	elif c9Wbh7raCVlyPKqpL6GwNZz1u==UUkIBz1sgQ9WfNeG6trKXvu0(u"࠶ᇙ"): MXAjE1Jqh8UN43RcPOLkb5ZTVCs = Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠬࡇࡕࡕࡑࠪ༲")
	elif c9Wbh7raCVlyPKqpL6GwNZz1u==kke1PDGRBLuY8y(u"࠸ᇚ"): MXAjE1Jqh8UN43RcPOLkb5ZTVCs = kke1PDGRBLuY8y(u"࠭ࡓࡕࡑࡓࠫ༳")
	if c9Wbh7raCVlyPKqpL6GwNZz1u in [mmcNLrXtzfpyCkZlvK5VwG2gujh(u"࠱ᇜ"),DYakr9g4PVU(u"࠱ᇛ")]:
		aVwGA2kFY6u4m = BjMmX1vNrnzSAf(zI3ROAZtiUq42rE9WDST68(u"ࠧࡤࡧࡱࡸࡪࡸࠧ༴"),VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠨีํีๆื࠺༵ࠡࠩ")+aZN3l1t6JE4oPmpkzLQSW5[qHYIWnOZLPkrQU],ddo23ZJtgcY(u"ࠩึ๎ึ็ั࠻ࠢࠪ༶")+aZN3l1t6JE4oPmpkzLQSW5[LzYQg91SIxDeOGtCKd5],b8Qe150xVaJsnDSv,S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠪวำะวาࠢึ๎ึ็ัࠡࡆࡑࡗࠥอไๆ่สือࠦไไ༷ࠩ"))
		if aVwGA2kFY6u4m==BmePGjS7FxK6kutUM(u"࠳ᇝ"): qnaioW9cTuU = aZN3l1t6JE4oPmpkzLQSW5[LzYQg91SIxDeOGtCKd5]
		else: qnaioW9cTuU = aZN3l1t6JE4oPmpkzLQSW5[qHYIWnOZLPkrQU]
	elif c9Wbh7raCVlyPKqpL6GwNZz1u==QTUBCcehw6qPd4x(u"࠵ᇞ"): qnaioW9cTuU = b8Qe150xVaJsnDSv
	else: MXAjE1Jqh8UN43RcPOLkb5ZTVCs = b8Qe150xVaJsnDSv
	if MXAjE1Jqh8UN43RcPOLkb5ZTVCs:
		hRWC8YSFvsm4JHOMVIne3jquZ.setSetting(IjZbnrBJmM2N(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡵࡨࡨࡳࡹࠧ༸"),MXAjE1Jqh8UN43RcPOLkb5ZTVCs)
		hRWC8YSFvsm4JHOMVIne3jquZ.setSetting(UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡦࡱࡷ༹ࠬ"),qnaioW9cTuU)
		zqxOCWTFMBEvL2ebarQl7JVy3Kgo = A4gdSTQDP2FyBIVuba85RvYqKU[MXAjE1Jqh8UN43RcPOLkb5ZTVCs]+qnaioW9cTuU
		tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,zqxOCWTFMBEvL2ebarQl7JVy3Kgo)
	return
def G0GQRsjE6Z1XM4x3b():
	OOufwJ7zNaA4Zs2 = hRWC8YSFvsm4JHOMVIne3jquZ.getSetting(DYakr9g4PVU(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡸࡷࡪࡶࡲࡰࡺࡼࠫ༺"))
	A4gdSTQDP2FyBIVuba85RvYqKU = {}
	A4gdSTQDP2FyBIVuba85RvYqKU[uVQd103XyvUce2EBtzbYaC(u"ࠧࡂࡗࡗࡓࠬ༻")] = yST5AHEfvPmcWpwGuh2BJ(u"ࠨษ็ฬึ๎ใิ์ࠣห้ะไใษษ๎ࠥาว่ิ่้ࠣ฿ๅๅࠩ༼")
	A4gdSTQDP2FyBIVuba85RvYqKU[VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠩࡄࡗࡐ࠭༽")] = BmePGjS7FxK6kutUM(u"ࠪห้ฮั้ๅึ๎ฺู๊ࠥ็็ࠤอ฿ฯࠡษ็ื๊ออࠡๆ๊ࠫ༾")
	A4gdSTQDP2FyBIVuba85RvYqKU[HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠫࡘ࡚ࡏࡑࠩ༿")] = Mmpr0o76iWJvz1kTtfgI8hES(u"ࠬอไษำ๋็ุ๐ࠠๆฬ๋ๆๆࠦสๆษ่หࠥ๎ศศๆๆห๊๊ࠧཀ")
	FAVpsU1uKjxIXLkrQE9TbmR = A4gdSTQDP2FyBIVuba85RvYqKU[OOufwJ7zNaA4Zs2]
	c9Wbh7raCVlyPKqpL6GwNZz1u = QlaM6yHe0bgh58Vx3BAZD(b8Qe150xVaJsnDSv,P0qdZI384LKleuo(u"࠭สี฼ํ่ࠥ฿ๆะࠢส่๊๎วโไฬࠫཁ"),TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠧหึ฽๎้ࠦสๅไสส๏࠭ག"),mQNonhS7CV2BXOv(u"ࠨวํๆฬ็ࠠไษ่่ࠬགྷ"),FAVpsU1uKjxIXLkrQE9TbmR,TYf7Dc06PQgy1vEV9(u"ࠩส่อื่ไีํࠤ์๎ࠠอ้สึࠥ็๊ࠡษ็ษ๋ะั็์อࠤ๏฿ๅๅ๋ࠢื๏฽ࠠษ์้ࠤัํวำๅࠣ์ฬ๊ล็ฬิ๊๏ะࠠ࠯๊ࠢ์ࠥ๐ำหๆ่ࠤ฼๊ศศฬๆࠤํ๐โ้็ࠣฬุำศ่ษࠣฬิ๊วࠡ็้็ࠥัๅࠡ์ห฽ะํวࠡๆๆࠤ࠳ࠦ็ๅࠢอี๏ีࠠหึ฽๎้ࠦรๆࠢศ๎็อแࠡษ็ฬึ๎ใิ์ࠣรࠬང"))
	if c9Wbh7raCVlyPKqpL6GwNZz1u==mmcNLrXtzfpyCkZlvK5VwG2gujh(u"࠴ᇟ"): MXAjE1Jqh8UN43RcPOLkb5ZTVCs = BmePGjS7FxK6kutUM(u"ࠪࡅࡘࡑࠧཅ")
	elif c9Wbh7raCVlyPKqpL6GwNZz1u==dDYUoKi6JFM23p(u"࠶ᇠ"): MXAjE1Jqh8UN43RcPOLkb5ZTVCs = kke1PDGRBLuY8y(u"ࠫࡆ࡛ࡔࡐࠩཆ")
	elif c9Wbh7raCVlyPKqpL6GwNZz1u==mQNonhS7CV2BXOv(u"࠸ᇡ"): MXAjE1Jqh8UN43RcPOLkb5ZTVCs = zI3ROAZtiUq42rE9WDST68(u"࡙ࠬࡔࡐࡒࠪཇ")
	else: MXAjE1Jqh8UN43RcPOLkb5ZTVCs = b8Qe150xVaJsnDSv
	if MXAjE1Jqh8UN43RcPOLkb5ZTVCs:
		hRWC8YSFvsm4JHOMVIne3jquZ.setSetting(ubxGUTt1LraKhVZgpAP(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡸࡷࡪࡶࡲࡰࡺࡼࠫ཈"),MXAjE1Jqh8UN43RcPOLkb5ZTVCs)
		zqxOCWTFMBEvL2ebarQl7JVy3Kgo = A4gdSTQDP2FyBIVuba85RvYqKU[MXAjE1Jqh8UN43RcPOLkb5ZTVCs]
		tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,zqxOCWTFMBEvL2ebarQl7JVy3Kgo)
	return
def UUKYJwONZhkcIAyixg7WC9R():
	y12ytelkWaGNARq3B0 = hRWC8YSFvsm4JHOMVIne3jquZ.getSetting(uVQd103XyvUce2EBtzbYaC(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡱࡪࡴࡵࡴࡥࡤࡧ࡭࡫ࠧཉ"))
	if y12ytelkWaGNARq3B0==TYf7Dc06PQgy1vEV9(u"ࠨࡕࡗࡓࡕ࠭ཊ"): header = mQNonhS7CV2BXOv(u"ࠩอาื๐ๆࠡษ็ๆํอฦๆ่ࠢฮํ่แࠨཋ")
	else: header = uVQd103XyvUce2EBtzbYaC(u"ࠪฮำุ๊็ࠢส่็๎วว็้ࠣๆ฿ไࠨཌ")
	aVwGA2kFY6u4m = BjMmX1vNrnzSAf(b8Qe150xVaJsnDSv,dDYUoKi6JFM23p(u"ࠫส๐โศใࠪཌྷ"),TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠬะแฺ์็ࠫཎ"),header,ddo23ZJtgcY(u"࠭โ้ษษ้ࠥอไษำ้ห๊า๋ࠠฬ่ࠤฯำฯ๋อ๊หࠥษ่ห๊่หฯ๐ใ๋ษࠣฬ฾ีࠠ࠲࠸ࠣืฬ฿ษࠡ็้ࠤศ๎ไࠡลึฮำีวๆࠢ࠱࠲ࠥ๎ล๋ไสๅࠥะฮำ์้ࠤฬ๊โ้ษษ้ࠥ๐ฤะ์ࠣษ้๏ࠠหฯา๎ะํวࠡใํࠤ่๊ࠠๆำฬࠤ๏ะๅࠡษึฮำีวๆࠢส่็๎วว็ࠣ࠲࠳่่ࠦาสࠤ๏ูศษࠢห฻หࠦแ๋ࠢไฮาࠦโ้ษษ้ࠥอไษำ้ห๊า࡜࡯࡞ࡱࠤ์๊ࠠหำํำࠥะแฺ์็ࠤศ๋ࠠฦ์ๅหๆࠦสฯิํ๊ࠥอไใ๊สส๊ࠦฟࠢࠣࠪཏ"))
	if aVwGA2kFY6u4m==-P0qdZI384LKleuo(u"࠱ᇢ"): return
	elif aVwGA2kFY6u4m:
		hRWC8YSFvsm4JHOMVIne3jquZ.setSetting(S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡱࡪࡴࡵࡴࡥࡤࡧ࡭࡫ࠧཐ"),P0qdZI384LKleuo(u"ࠨࡃࡘࡘࡔ࠭ད"))
		tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,ubxGUTt1LraKhVZgpAP(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬདྷ"),P0qdZI384LKleuo(u"ࠪฮ๊ࠦสโ฻ํ่ࠥะฮำ์้ࠤฬ๊โ้ษษ้ࠬན"))
	else:
		hRWC8YSFvsm4JHOMVIne3jquZ.setSetting(TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮࡮ࡧࡱࡹࡸࡩࡡࡤࡪࡨࠫཔ"),TYf7Dc06PQgy1vEV9(u"࡙ࠬࡔࡐࡒࠪཕ"))
		tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,vvWwO3Tx2dAgcijrFXq(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩབ"),Xz3bA2PFENVCUtplu51(u"ࠧห็ࠣษ๏่วโࠢอาื๐ๆࠡษ็ๆํอฦๆࠩབྷ"))
	return
def qFBV54ijXemHTf0(pnmsJqCWIHVk2Y6xPvl9Q0Ez8r):
	if pnmsJqCWIHVk2Y6xPvl9Q0Ez8r!=b8Qe150xVaJsnDSv:
		pnmsJqCWIHVk2Y6xPvl9Q0Ez8r = ZZN9Mjkl4wWy0OV5axfqz(pnmsJqCWIHVk2Y6xPvl9Q0Ez8r)
		pnmsJqCWIHVk2Y6xPvl9Q0Ez8r = pnmsJqCWIHVk2Y6xPvl9Q0Ez8r.decode(OVauxZzLI10vcXT74K).encode(OVauxZzLI10vcXT74K)
		jrJnaqCTcAusIvKB1lF0XStZEHxoy = ddo23ZJtgcY(u"࠲࠲࠴࠴࠸ᇣ")
		ADozXkQPlKr6ZJnMYiOc7Rq2Ip = evil9I2DnLJcy8.Window(jrJnaqCTcAusIvKB1lF0XStZEHxoy)
		ADozXkQPlKr6ZJnMYiOc7Rq2Ip.getControl(TT8Mxv5Wq7nlC9IscdpPUY6(u"࠵࠴࠵ᇤ")).setLabel(pnmsJqCWIHVk2Y6xPvl9Q0Ez8r)
	return
QM5EXnNo6ul9 = [
			 QQdAXWBc2GPw(u"ࠣࡧࡻࡸࡪࡴࡳࡪࡱࡱࠤࡦࡼࡳࡱࡣࡦࡩࡸ࠶ࠠࡪࡵࠣࡲࡴࡺࠠࡤࡷࡵࡶࡪࡴࡴ࡭ࡻࠣࡷࡺࡶࡰࡰࡴࡷࡩࡩࠨམ")
			,zI3ROAZtiUq42rE9WDST68(u"ࠩࡆ࡬ࡪࡩ࡫ࡪࡰࡪࠤ࡫ࡵࡲࠡࡏࡤࡰ࡮ࡩࡩࡰࡷࡶࠤࡸࡩࡲࡪࡲࡷࡷࠬཙ")
			,BmePGjS7FxK6kutUM(u"ࠪࡔ࡛ࡘࠠࡊࡒࡗ࡚࡙ࠥࡩ࡮ࡲ࡯ࡩࠥࡉ࡬ࡪࡧࡱࡸࠬཚ")
			,UUkIBz1sgQ9WfNeG6trKXvu0(u"࡚ࠫࡴ࡫࡯ࡱࡺࡲࠥ࡜ࡩࡥࡧࡲࠤࡎࡴࡦࡰࠢࡎࡩࡾ࠭ཛ")
			,VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠬࡺࡨࡪࡵࠣ࡬ࡦࡹࡨࠡࡨࡸࡲࡨࡺࡩࡰࡰࠣ࡭ࡸࠦࡢࡳࡱ࡮ࡩࡳ࠭ཛྷ")
			,vvWwO3Tx2dAgcijrFXq(u"࠭ࡵࡴࡧࡶࠤࡵࡲࡡࡪࡰࠣࡌ࡙࡚ࡐࠡࡨࡲࡶࠥࡧࡤࡥ࠯ࡲࡲࠥࡪ࡯ࡸࡰ࡯ࡳࡦࡪࡳࠨཝ")
			,Mmpr0o76iWJvz1kTtfgI8hES(u"ࠧࡢࡦࡹࡥࡳࡩࡥࡥ࠯ࡸࡷࡦ࡭ࡥ࠯ࡪࡷࡱࡱ࠭ཞ")+zI3ROAZtiUq42rE9WDST68(u"ࠨࠥࠪཟ")+QQdAXWBc2GPw(u"ࠩࡶࡷࡱ࠳ࡷࡢࡴࡱ࡭ࡳ࡭ࡳࠨའ")
			,SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠪࡍࡳࡹࡥࡤࡷࡵࡩࡗ࡫ࡱࡶࡧࡶࡸ࡜ࡧࡲ࡯࡫ࡱ࡫࠱࠭ཡ")
			,LAQD5wEkr18bUiGaYen3J(u"ࠫࡊࡸࡲࡰࡴࠣ࡫ࡪࡺࡴࡪࡰࡪࠤࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈ࠴ࡅ࡭ࡰࡦࡨࡩࡂ࠶ࠦࡵࡧࡻࡸࡹࡃࠧར")
			,mQNonhS7CV2BXOv(u"ࠬࡽࡡࡳࡰ࡬ࡲ࡬ࡹ࠮ࡸࡣࡵࡲ࠭࠭ལ")
			,ddo23ZJtgcY(u"࠭࡞࡟ࡠࡡࡢࠬཤ")
			,IjZbnrBJmM2N(u"ࠧࡍࡱࡤࡨ࡮ࡴࡧࠡࡵ࡮࡭ࡳࠦࡦࡪ࡮ࡨ࠾ࠬཥ")
			]
def jiUqmd7Qc1olAeMTJBbP4nEp(CspH3o0yQVkReLwX8K9ql):
	if P0qdZI384LKleuo(u"ࠨࡎࡲࡥࡩ࡯࡮ࡨࠢࡶ࡯࡮ࡴࠠࡧ࡫࡯ࡩ࠿࠭ས") in CspH3o0yQVkReLwX8K9ql and DYakr9g4PVU(u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧཧ") in CspH3o0yQVkReLwX8K9ql: return CCxMXuNUEzolDZTKrBJ
	for pnmsJqCWIHVk2Y6xPvl9Q0Ez8r in QM5EXnNo6ul9:
		if pnmsJqCWIHVk2Y6xPvl9Q0Ez8r in CspH3o0yQVkReLwX8K9ql: return CCxMXuNUEzolDZTKrBJ
	return DD5cFIejQa2X4BgAu9GWPyJ3tC7
def ISzlJXg0Guwpj4(data):
	QQPZWT5bJX23N7cAuvtrnaxDmkgC = ubxGUTt1LraKhVZgpAP(u"࠻ᇦ") if i1thmHk7AZquD4cM0fnp62 else m6hwdgP31a2zjN7lkpX(u"࠴࠹ᇥ")
	data = data.replace(TYf7Dc06PQgy1vEV9(u"࠸࠶ᇧ")*pldxivXC5wbTB2O8q,QQPZWT5bJX23N7cAuvtrnaxDmkgC*pldxivXC5wbTB2O8q)
	data = data.replace(IjZbnrBJmM2N(u"ࠪࠤࡁ࡭ࡥ࡯ࡧࡵࡥࡱࡄ࠺ࠡࠩཨ"),P0qdZI384LKleuo(u"ࠫ࠿ࠦࠧཀྵ"))
	EEkjQFxOabod08Nr = b8Qe150xVaJsnDSv
	for CspH3o0yQVkReLwX8K9ql in data.splitlines():
		biDrQcnPtdRKlBxLMefW1CaGjOJm = YYBlm36zd0Jst18LXwo4.findall(LAQD5wEkr18bUiGaYen3J(u"ࠬࠦࠠࠡࠢࠣࡊ࡮ࡲࡥࠡࠤࠫ࠲࠯ࡅࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶ࠲࠮ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫཪ"),CspH3o0yQVkReLwX8K9ql,YYBlm36zd0Jst18LXwo4.DOTALL)
		if biDrQcnPtdRKlBxLMefW1CaGjOJm: CspH3o0yQVkReLwX8K9ql = CspH3o0yQVkReLwX8K9ql.replace(biDrQcnPtdRKlBxLMefW1CaGjOJm[LzYQg91SIxDeOGtCKd5],b8Qe150xVaJsnDSv)
		EEkjQFxOabod08Nr += eeN6dTEnkJxI+CspH3o0yQVkReLwX8K9ql
	return EEkjQFxOabod08Nr
def JwVFResqbM5Dk126z3fQWuOP7YBv0(M7M2KwpA3oSBX9QR05qai):
	if mQNonhS7CV2BXOv(u"࠭ࡏࡍࡆࠪཫ") in M7M2KwpA3oSBX9QR05qai:
		NMiFW2cEopdawOxQ8Dn35 = o8hpvj4GIc53mBFkH6OSzYu0W
		header = shC5qBRV2A0lZ(u"ࠧใำสลฮࠦวๅีฯ่ࠥอไใัํ้ࠥลࠧཬ")
	else:
		NMiFW2cEopdawOxQ8Dn35 = v3Sd26atO0oRKA5ig
		header = Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠨไิหฦฯࠠศๆึะ้ࠦวๅฯส่๏ࠦฟࠨ཭")
	aVwGA2kFY6u4m = BjMmX1vNrnzSAf(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,header,ubxGUTt1LraKhVZgpAP(u"ࠩึะ้ࠦวๅลั฻ฬว๋ࠠฯอ์๏ࠦรุ๋สࠤ฾๊้ࠡีฯ่ࠥอไศีอาิอๅࠡ࠰ࠣ์ฬ๊วฬ่ํ๊ࠥ฼ั้ำํอ๊ࠥๅฺำไอ้๊ࠥโࠢะำะะࠠศๆุ่่๊ษ๊่ࠡหࠥํ่ࠡษ็้่อๆࠡษ็ิ๏ࠦำษสࠣัิ๎หࠡษ็ู้้ไสࠢ࠱ࠤ่๎ฯ๋ࠢํัฯ็ุࠡสึะ้๐ๆࠡ࠰ࠣห้ษ่ๅ๊ࠢ์ࠥอไิฮ็ࠤฬ๊อศๆํࠤํ็๊่่ࠢ฽้๎ๅศฬࠣฮอีรࠡ็้ิࠥฮฯศ์ฬࠤฬ๊สี฼ํ่ࠥอไฮษ็๎๊ࠥศา่ส้ัࠦใ้ัํࠤํอไ๊ࠢส่ว์ࠠ࠯ࠢฦ้ฬࠦวๅีฯ่ࠥอไใัํ้ࠥ็็้ࠢสุ่าไࠡษ็ืฬฮโࠡษ็ิ๏ࠦสๆࠢฯ้฾ํࠠๆ่ࠣฬึ์วๆฮࠣ็ํี๊ࠡไห่ࠥศฮาࠢศ฻ๆอมࠡๆ๊ࠤ࠳ࠦ็ๅࠢอี๏ีࠠศๆสืฯ๋ัศำࠣรࠬ཮"))
	if aVwGA2kFY6u4m!=yST5AHEfvPmcWpwGuh2BJ(u"࠷ᇨ"): return
	JYVuQCzoKw03aDRcbIgdeP7mLGFp,iG0zufnFdZMAqHWJtOKXaE = [],UUkIBz1sgQ9WfNeG6trKXvu0(u"࠰ᇩ")
	size,count = HTuoYBfsP0GE(NMiFW2cEopdawOxQ8Dn35)
	file = open(NMiFW2cEopdawOxQ8Dn35,uVQd103XyvUce2EBtzbYaC(u"ࠪࡶࡧ࠭཯"))
	if size>IjZbnrBJmM2N(u"࠳࠳࠴࠷࠶࠰ᇫ"): file.seek(-yST5AHEfvPmcWpwGuh2BJ(u"࠲࠲࠳࠵࠵࠶ᇪ"),x76PfMyAp1L2WejkU3.SEEK_END)
	data = file.read()
	file.close()
	if i1thmHk7AZquD4cM0fnp62: data = data.decode(OVauxZzLI10vcXT74K)
	data = ISzlJXg0Guwpj4(data)
	bCoNUQ3TXW7un = data.split(eeN6dTEnkJxI)
	for CspH3o0yQVkReLwX8K9ql in reversed(bCoNUQ3TXW7un):
		e5yOU0kPv7Sjp9BX3TGCm6YxlErcJ1 = jiUqmd7Qc1olAeMTJBbP4nEp(CspH3o0yQVkReLwX8K9ql)
		if e5yOU0kPv7Sjp9BX3TGCm6YxlErcJ1: continue
		CspH3o0yQVkReLwX8K9ql = CspH3o0yQVkReLwX8K9ql.replace(DYakr9g4PVU(u"ࠫࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡤ࠭཰"),OkuB9nwhD8U1+SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠬࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠࠨཱ")+hAIp8kmC36T5WFPMSXOwnNbtD)
		CspH3o0yQVkReLwX8K9ql = CspH3o0yQVkReLwX8K9ql.replace(P0qdZI384LKleuo(u"࠭ࡅࡓࡔࡒࡖ࠿ི࠭"),BWNPxIG7vqdTy85pjHzUOrK3(u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊ࠵࠶࠰࠱࡟ཱིࠪ")+P0qdZI384LKleuo(u"ࠨࡇࡕࡖࡔࡘ࠺ࠨུ")+hAIp8kmC36T5WFPMSXOwnNbtD)
		lh3tM7VADUxQPo = b8Qe150xVaJsnDSv
		jMoI40N3fApTaDKsGy = YYBlm36zd0Jst18LXwo4.findall(dDYUoKi6JFM23p(u"ࠩࡡࠬࡡࡪࠫ࠮ࠪ࡟ࡨ࠰࠳࡜ࡥ࠭ࠣࡠࡩ࠱࠺࡝ࡦ࠮࠾ࡡࡪࠫ࡝࠰࡟ࡨ࠰࠯ࠩࠩࠢࡗ࠾ࡡࡪཱུࠫࠪࠩ"),CspH3o0yQVkReLwX8K9ql,YYBlm36zd0Jst18LXwo4.DOTALL)
		if jMoI40N3fApTaDKsGy:
			CspH3o0yQVkReLwX8K9ql = CspH3o0yQVkReLwX8K9ql.replace(jMoI40N3fApTaDKsGy[LzYQg91SIxDeOGtCKd5][LzYQg91SIxDeOGtCKd5],jMoI40N3fApTaDKsGy[LzYQg91SIxDeOGtCKd5][qHYIWnOZLPkrQU]).replace(jMoI40N3fApTaDKsGy[LzYQg91SIxDeOGtCKd5][IgQimel18t],b8Qe150xVaJsnDSv)
			lh3tM7VADUxQPo = jMoI40N3fApTaDKsGy[LzYQg91SIxDeOGtCKd5][qHYIWnOZLPkrQU]
		else:
			jMoI40N3fApTaDKsGy = YYBlm36zd0Jst18LXwo4.findall(BmePGjS7FxK6kutUM(u"ࠪࡢ࠭ࡢࡤࠬ࠼࡟ࡨ࠰ࡀ࡜ࡥ࠭࡟࠲ࡡࡪࠫࠪࠪࠣࡘ࠿ࡢࡤࠬࠫࠪྲྀ"),CspH3o0yQVkReLwX8K9ql,YYBlm36zd0Jst18LXwo4.DOTALL)
			if jMoI40N3fApTaDKsGy:
				CspH3o0yQVkReLwX8K9ql = CspH3o0yQVkReLwX8K9ql.replace(jMoI40N3fApTaDKsGy[LzYQg91SIxDeOGtCKd5][qHYIWnOZLPkrQU],b8Qe150xVaJsnDSv)
				lh3tM7VADUxQPo = jMoI40N3fApTaDKsGy[LzYQg91SIxDeOGtCKd5][LzYQg91SIxDeOGtCKd5]
		if lh3tM7VADUxQPo: CspH3o0yQVkReLwX8K9ql = CspH3o0yQVkReLwX8K9ql.replace(lh3tM7VADUxQPo,rC3Tlno96KjLDIvBaSWUbR8+lh3tM7VADUxQPo+hAIp8kmC36T5WFPMSXOwnNbtD)
		JYVuQCzoKw03aDRcbIgdeP7mLGFp.append(CspH3o0yQVkReLwX8K9ql)
		if len(str(JYVuQCzoKw03aDRcbIgdeP7mLGFp))>LAQD5wEkr18bUiGaYen3J(u"࠸࠴࠶࠶࠰ᇬ"): break
	JYVuQCzoKw03aDRcbIgdeP7mLGFp = reversed(JYVuQCzoKw03aDRcbIgdeP7mLGFp)
	Ifr17m0z8RKh9cSYwyo = eeN6dTEnkJxI.join(JYVuQCzoKw03aDRcbIgdeP7mLGFp)
	bJvWMFh8G3eas(QQdAXWBc2GPw(u"ࠫࡱ࡫ࡦࡵࠩཷ"),QTUBCcehw6qPd4x(u"ࠬศฮาࠢฦื฼ืࠠิฮ็ࠤฬ๊รฯูสลࠥ๎วๅษึฮำีวๆࠩླྀ"),Ifr17m0z8RKh9cSYwyo,QQdAXWBc2GPw(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡵࡰࡥࡱࡲࡦࡰࡰࡷࡣࡱࡵ࡮ࡨࠩཹ"))
	return
def fbapl6HkWdIo2KE():
	fNXterPjvhwux02I7CiY9OnH = open(MdhHKoP7yn8eCk6JsY9ZfBgG5bXLrj,m6hwdgP31a2zjN7lkpX(u"ࠧࡳࡤེࠪ")).read()
	if i1thmHk7AZquD4cM0fnp62: fNXterPjvhwux02I7CiY9OnH = fNXterPjvhwux02I7CiY9OnH.decode(OVauxZzLI10vcXT74K)
	fNXterPjvhwux02I7CiY9OnH = fNXterPjvhwux02I7CiY9OnH.replace(SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠨ࡞ࡷཻࠫ"),LAQD5wEkr18bUiGaYen3J(u"ࠩࠣࠤོࠥࠦࠠࠡࠢࠣࠫ"))
	EJcfC7seYxiG = YYBlm36zd0Jst18LXwo4.findall(LAQD5wEkr18bUiGaYen3J(u"ࠪࠬࡻࡢࡤ࠯ࠬࡂ࠭ࡠࡢ࡮࡝ࡴࡠཽࠫ"),fNXterPjvhwux02I7CiY9OnH,YYBlm36zd0Jst18LXwo4.DOTALL)
	for CspH3o0yQVkReLwX8K9ql in EJcfC7seYxiG:
		fNXterPjvhwux02I7CiY9OnH = fNXterPjvhwux02I7CiY9OnH.replace(CspH3o0yQVkReLwX8K9ql,OkuB9nwhD8U1+CspH3o0yQVkReLwX8K9ql+hAIp8kmC36T5WFPMSXOwnNbtD)
	ryTNDEf2xWFCdi60AMKBomSVRpP5(VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠫฬ๊ส฻์ํีฬะࠠศๆฦา๏ืษࠡใํࠤฬ๊ศาษ่ะࠬཾ"),fNXterPjvhwux02I7CiY9OnH)
	return
def EEsP4Tk9L6iyeZj():
	FSpIEkeP1D3ai4VZ5oB92zhy = VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠬฮูืࠢส่ศุัศำࠣ฽้๏ࠠศๆิ๎๊๎สࠡๅ๋๊ฯื่ๅࠢอ์ๆืࠠฦ็ๆห๋๐ษࠡฬๅำ๏๋้ࠠฬฦา๏ืࠠศๆไ๎ิ๐่๊๊ࠡิ์ࠦวๅลีีฬื่ࠠ์ࠣห้ษำ่็ࠣ์ฬ๊ราไสู้๋ࠥࠡส฼ฺࠥ๎ใศๆอห้๐ࠧཿ")
	eqURlBsy0m82xwA = mmcNLrXtzfpyCkZlvK5VwG2gujh(u"࠭ไหไา๎๊ࠦวๅใํำ๏๎ࠠศีอาิ๋ࠠศๆึ๋๊ࠦวๅ์่๎๋่ࠦๅฬฦา๏ื็ࠡษึฮำีๅࠡษ็ื์๋ࠠศๆํืฬืࠠ࠯ࠢฦ้ฬูࠦะหࠣหุํๅࠡ็อฮฬ๊๊สࠢไ๋ีํࠠหไ๋้ࠥฮสฮำํ็ࠥอไโ์า๎ํࠦศ้ไอࠤฬ้ศา่๊ࠢࠥ๎โหࠢสุ่ํๅࠡษ็์ฬำฯࠡ࠰ࠣว๊อࠠศๆึ๋๊ࠦวๅล฼่๎่ࠦศๆฦืๆ๊ࠠโ้๋ࠤ๏ำัไࠢส่ๆ๐ฯ๋๊ࠣษ้๏ࠠศๆฦ้ฬ๋ࠠฤ๊ࠣษ้๏ࠠศๆ๋ีฬว้ࠠๆๆ๊ࠥฮโโิฬࠤ่ฮ๊าหྀࠪ")
	zzi8PC6qjXNa5hBw = Nh0BWuiSndf(u"ࠧฤ็สࠤฬ๊ราไส้ࠥ็็๋ࠢอืฯิฯๆࠢ็่ฯ่ฯ๋็ࠣ์ฬ๊สฤะํีࠥ๎ไไ่ࠣฬ๊่ฯศำࠣ฽ิีࠠศๆฮ์ฬ์๊๊ࠡส่ิ่ววไࠣ࠲๋ࠥหๅษࠣี็๋ࠠ࠶࠶࠷ࠤฯ฿ๆ๋ࠢ࠸ࠤิ่ววไࠣ์ࠥ࠺࠴ࠡอส๊๏ฯࠠฦๆ์ࠤฬ๊รๆษ่ࠤศ๎ࠠฦๆ์ࠤฬ๊่าษฤࠤอำำษࠢสืฯิฯศ็ๆࠤ้๊ำ่็ࠣห้๐ๅ๋่ࠣวํࠦำ่็ࠣห้๐ำศำཱྀࠪ")
	A4gdSTQDP2FyBIVuba85RvYqKU = FSpIEkeP1D3ai4VZ5oB92zhy+kke1PDGRBLuY8y(u"ࠨ࠼ࠣࠫྂ")+eqURlBsy0m82xwA+Mmpr0o76iWJvz1kTtfgI8hES(u"ࠩࠣ࠲ࠥ࠭ྃ")+zzi8PC6qjXNa5hBw
	bJvWMFh8G3eas(Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠪࡧࡪࡴࡴࡦࡴ྄ࠪ"),S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ྅"),A4gdSTQDP2FyBIVuba85RvYqKU,UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨ྆"))
	return
def a53FKP79mzt(type,A4gdSTQDP2FyBIVuba85RvYqKU,showDialogs=CCxMXuNUEzolDZTKrBJ,url=b8Qe150xVaJsnDSv,fOzS45youKYdNDqwm61aEI3A=b8Qe150xVaJsnDSv,pnmsJqCWIHVk2Y6xPvl9Q0Ez8r=b8Qe150xVaJsnDSv,xx2MZfsNim4IzFQLUgWkJD7nbXeq=b8Qe150xVaJsnDSv):
	fHhKXqcmtlF3pGzZj7x0TsnRI = CCxMXuNUEzolDZTKrBJ
	if not XrloM5pTyK.r6rSFTpNl5nqd4s9GbEK8zhoXY:
		if showDialogs:
			JJZFS8LAE5I6DqYhVQegatMRHlw = (TYf7Dc06PQgy1vEV9(u"࠭วๅีฺี࠿࠭྇") in A4gdSTQDP2FyBIVuba85RvYqKU and VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠧศๆ่็ฬ์࠺ࠨྈ") in A4gdSTQDP2FyBIVuba85RvYqKU and DYakr9g4PVU(u"ࠨษ็้้็࠺ࠨྉ") in A4gdSTQDP2FyBIVuba85RvYqKU and Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠩส่ำ฽รࠨྊ") in A4gdSTQDP2FyBIVuba85RvYqKU and mQNonhS7CV2BXOv(u"ࠪห้๋ีะำ࠽ࠫྋ") in A4gdSTQDP2FyBIVuba85RvYqKU)
			if not JJZFS8LAE5I6DqYhVQegatMRHlw: fHhKXqcmtlF3pGzZj7x0TsnRI = BjMmX1vNrnzSAf(UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫྌ"),b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠬํไࠡฬิื้ࠦ็ั้ࠣห้ืำศๆฬࠤส๊้ࠡษ็้อืๅอࠩྍ"),A4gdSTQDP2FyBIVuba85RvYqKU.replace(ubxGUTt1LraKhVZgpAP(u"࠭࡜࡝ࡰࠪྎ"),eeN6dTEnkJxI))
	elif showDialogs:
		A4gdSTQDP2FyBIVuba85RvYqKU = Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠧ࡝࡞ࡱฮ๊ࠦๅิฯࠣห้ืำศๆฬࡠࡡࡴสๆ่ࠢืาࠦัิษ็อࡡࡢ࡮ห็ุ้ࠣำࠠศๆิืฬ๊ษ࡝࡞ࡱฮ๊ࠦๅิฯࠣห้ืำศๆฬࡠࡡࡴสๆ่ࠢืาࠦวๅำึห้ฯࠧྏ")
		jQF9x2mq6fgGYZ4AwtUHM05onBP = BjMmX1vNrnzSAf(QTUBCcehw6qPd4x(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨྐ"),b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,ddo23ZJtgcY(u"ࠩอ้๋ࠥำฮࠢิืฬ๊สไࠩྑ")+kke1PDGRBLuY8y(u"ࠪࠤࠥ࠷࠯࠶ࠩྒ"),Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠫ์๊ࠠหำํำࠥหัิษ็ࠤึูวๅหࠣๅฬืฺสࠩྒྷ"))
		HTZqLUh80ukzt4r7g2fd6a = BjMmX1vNrnzSAf(shC5qBRV2A0lZ(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬྔ"),b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,dDYUoKi6JFM23p(u"࠭สๆ่ࠢืาࠦัิษ็ฮ่࠭ྕ")+UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠧࠡࠢ࠵࠳࠺࠭ྖ"),TYf7Dc06PQgy1vEV9(u"ࠨ้็ࠤฯื๊ะࠢศีุอไࠡำึห้ฯࠠโษิ฾ฮ࠭ྗ"))
		TofUg8z5b7hYxcqRslQVFPIBanK9e = BjMmX1vNrnzSAf(IjZbnrBJmM2N(u"ࠩࡦࡩࡳࡺࡥࡳࠩ྘"),b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,mQNonhS7CV2BXOv(u"ࠪฮ๊ࠦๅิฯࠣีุอไหๅࠪྙ")+TYf7Dc06PQgy1vEV9(u"ࠫࠥࠦ࠳࠰࠷ࠪྚ"),dDYUoKi6JFM23p(u"ࠬํไࠡฬิ๎ิࠦลาีส่ࠥืำศๆฬࠤๆอั฻หࠪྛ"))
		VWhgvIeG73Z1zS5uY8RO4M = BjMmX1vNrnzSAf(DYakr9g4PVU(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ྜ"),b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,LAQD5wEkr18bUiGaYen3J(u"ࠧห็ุ้ࠣำࠠาีส่ฯ้ࠧྜྷ")+BmePGjS7FxK6kutUM(u"ࠨࠢࠣ࠸࠴࠻ࠧྞ"),ubxGUTt1LraKhVZgpAP(u"๊่ࠩࠥะั๋ัࠣษึูวๅࠢิืฬ๊ษࠡใสี฿ฯࠧྟ"))
		fHhKXqcmtlF3pGzZj7x0TsnRI = BjMmX1vNrnzSAf(RRIHDFjoW9w7bSfVPhC(u"ࠪࡧࡪࡴࡴࡦࡴࠪྠ"),b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠫฯ๋ࠠๆีะࠤึูวๅฬๆࠫྡ")+VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠬࠦࠠ࠶࠱࠸ࠫྡྷ"),VFjQx6Is28KvzLOmMXtg4GqTwa3(u"࠭็ๅࠢอี๏ีࠠฦำึห้ࠦัิษ็อࠥ็วา฼ฬࠫྣ"))
	y9i63b5jQSGqUsfguZxPkTK = P1u7tUzG9XMxHjSlnk6QvARoNVCO5i(DD5cFIejQa2X4BgAu9GWPyJ3tC7)
	PJKIlqFutvbapGnHYf07oZXDsW8Vxz = P0qdZI384LKleuo(u"ࠧࡂࡘ࠽ࠤࠬྤ")+y9i63b5jQSGqUsfguZxPkTK+HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠨ࠯ࠪྥ")+type
	AuPNC4MLr9E = CCxMXuNUEzolDZTKrBJ if VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠩࡢࡔࡗࡕࡂࡍࡇࡐࡣࠬྦ") in pnmsJqCWIHVk2Y6xPvl9Q0Ez8r else DD5cFIejQa2X4BgAu9GWPyJ3tC7
	if not fHhKXqcmtlF3pGzZj7x0TsnRI:
		if showDialogs: tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,shC5qBRV2A0lZ(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ྦྷ"),zI3ROAZtiUq42rE9WDST68(u"ࠫฯ๋ࠠฦๆ฽หฦࠦวๅวิืฬ๊ࠠษ่สลࠥ฿ไฺ๊่ࠢอ้ࠧྨ"))
		return DD5cFIejQa2X4BgAu9GWPyJ3tC7
	ZiBmhC8s6nTN5cR = uuxVm0bTwdnCUAL4s6NKHEBF3M.getInfoLabel(kke1PDGRBLuY8y(u"࡙ࠬࡹࡴࡶࡨࡱ࠳ࡌࡲࡪࡧࡱࡨࡱࡿࡎࡢ࡯ࡨࠫྩ"))
	A4gdSTQDP2FyBIVuba85RvYqKU += VFjQx6Is28KvzLOmMXtg4GqTwa3(u"࠭ࠠ࡝࡞ࡱࡠࡡࡴ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾ࠢࡀࡁࡂࡃࠠ࡝࡞ࡱࡅࡩࡪ࡯࡯࡙ࠢࡩࡷࡹࡩࡰࡰ࠽ࠤࠬྪ")+cpGrK6qnPi+Nh0BWuiSndf(u"ࠧࠡ࠼࡟ࡠࡳ࠭ྫ")
	A4gdSTQDP2FyBIVuba85RvYqKU += ubxGUTt1LraKhVZgpAP(u"ࠨࡇࡰࡥ࡮ࡲࠠࡔࡧࡱࡨࡪࡸ࠺ࠡࠩྫྷ")+y9i63b5jQSGqUsfguZxPkTK+Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠩࠣ࠾ࡡࡢ࡮ࡌࡱࡧ࡭ࠥ࡜ࡥࡳࡵ࡬ࡳࡳࡀࠠࠨྭ")+xsc9o3jWnC5H4+ubxGUTt1LraKhVZgpAP(u"ࠪࠤ࠿ࡢ࡜࡯ࠩྮ")
	A4gdSTQDP2FyBIVuba85RvYqKU += TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠫࡐࡵࡤࡪࠢࡑࡥࡲ࡫࠺ࠡࠩྯ")+ZiBmhC8s6nTN5cR
	sT3ueLokq1riU5FBMWaQA = CGb8nOoSct2xEhyf0WzUmY()
	sT3ueLokq1riU5FBMWaQA = HHbaVYqFRy6v0c(sT3ueLokq1riU5FBMWaQA)
	if sT3ueLokq1riU5FBMWaQA: A4gdSTQDP2FyBIVuba85RvYqKU += RRIHDFjoW9w7bSfVPhC(u"ࠬࠦ࠺࡝࡞ࡱࡐࡴࡩࡡࡵ࡫ࡲࡲ࠿ࠦࠧྰ")+sT3ueLokq1riU5FBMWaQA
	if url: A4gdSTQDP2FyBIVuba85RvYqKU += SbjiWeHLQPoazqwp3cODkd7YxVgn(u"࠭ࠠ࠻࡞࡟ࡲ࡚ࡘࡌ࠻ࠢࠪྱ")+url
	if fOzS45youKYdNDqwm61aEI3A: A4gdSTQDP2FyBIVuba85RvYqKU += Nh0BWuiSndf(u"ࠧࠡ࠼࡟ࡠࡳ࡙࡯ࡶࡴࡦࡩ࠿ࠦࠧྲ")+fOzS45youKYdNDqwm61aEI3A
	A4gdSTQDP2FyBIVuba85RvYqKU += DYakr9g4PVU(u"ࠨࠢ࠽ࡠࡡࡴࠧླ")
	if showDialogs: yicQV3gj4q(RRIHDFjoW9w7bSfVPhC(u"ࠩฯหึ๐ࠠศๆศีุอไࠨྴ"),dDYUoKi6JFM23p(u"ࠪห้ืฬศรࠣห้อๆหฺสีࠬྵ"))
	if xx2MZfsNim4IzFQLUgWkJD7nbXeq:
		Ifr17m0z8RKh9cSYwyo = xx2MZfsNim4IzFQLUgWkJD7nbXeq
		if i1thmHk7AZquD4cM0fnp62: Ifr17m0z8RKh9cSYwyo = Ifr17m0z8RKh9cSYwyo.encode(OVauxZzLI10vcXT74K)
		Ifr17m0z8RKh9cSYwyo = lnFeUkiZtQ7E1.b64encode(Ifr17m0z8RKh9cSYwyo)
	elif AuPNC4MLr9E:
		if S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠫࡤࡖࡒࡐࡄࡏࡉࡒࡥࡏࡍࡆࡢࠫྶ") in pnmsJqCWIHVk2Y6xPvl9Q0Ez8r: XcwJuo8MqdEeKhn = o8hpvj4GIc53mBFkH6OSzYu0W
		else: XcwJuo8MqdEeKhn = v3Sd26atO0oRKA5ig
		if not x76PfMyAp1L2WejkU3.path.exists(XcwJuo8MqdEeKhn):
			tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,QTUBCcehw6qPd4x(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨྷ"),BmePGjS7FxK6kutUM(u"࠭ำอๆࠣห้ษฮุษฤࠤํอไศีอาิอๅࠡ฼ํี๋่ࠥอ๊าࠫྸ"))
			return DD5cFIejQa2X4BgAu9GWPyJ3tC7
		mwIxD3GBPgLVc2aq9(MtTygrzXFlQ,uVQd103XyvUce2EBtzbYaC(u"ࠧ࠯࡞ࡷࡔࡷ࡫ࡰࡢࡴ࡬ࡲ࡬ࠦࡴࡰࠢࡶࡩࡳࡪࠠࡵࡪࡨࠤࡱࡵࡧࡧ࡫࡯ࡩࠬྐྵ"))
		JYVuQCzoKw03aDRcbIgdeP7mLGFp,iG0zufnFdZMAqHWJtOKXaE = [],Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"࠴ᇭ")
		file = open(XcwJuo8MqdEeKhn,Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠨࡴࡥࠫྺ"))
		size,count = HTuoYBfsP0GE(XcwJuo8MqdEeKhn)
		if size>Nh0BWuiSndf(u"࠸࠶࠱࠱࠲࠳ᇮ"): file.seek(-Nh0BWuiSndf(u"࠸࠶࠱࠱࠲࠳ᇮ"),x76PfMyAp1L2WejkU3.SEEK_END)
		data = file.read()
		file.close()
		data = data.decode(OVauxZzLI10vcXT74K)
		data = ISzlJXg0Guwpj4(data)
		bCoNUQ3TXW7un = data.splitlines()
		for CspH3o0yQVkReLwX8K9ql in reversed(bCoNUQ3TXW7un):
			e5yOU0kPv7Sjp9BX3TGCm6YxlErcJ1 = jiUqmd7Qc1olAeMTJBbP4nEp(CspH3o0yQVkReLwX8K9ql)
			if e5yOU0kPv7Sjp9BX3TGCm6YxlErcJ1: continue
			jMoI40N3fApTaDKsGy = YYBlm36zd0Jst18LXwo4.findall(P0qdZI384LKleuo(u"ࠩࡡࠬࡡࡪࠫ࠮ࠪ࡟ࡨ࠰࠳࡜ࡥ࠭ࠣࡠࡩ࠱࠺࡝ࡦ࠮࠾ࡡࡪࠫ࡝࠰࡟ࡨ࠰࠯ࠩࠩࠢࡗ࠾ࡡࡪࠫࠪࠩྻ"),CspH3o0yQVkReLwX8K9ql,YYBlm36zd0Jst18LXwo4.DOTALL)
			if jMoI40N3fApTaDKsGy:
				CspH3o0yQVkReLwX8K9ql = CspH3o0yQVkReLwX8K9ql.replace(jMoI40N3fApTaDKsGy[LzYQg91SIxDeOGtCKd5][LzYQg91SIxDeOGtCKd5],jMoI40N3fApTaDKsGy[LzYQg91SIxDeOGtCKd5][qHYIWnOZLPkrQU]).replace(jMoI40N3fApTaDKsGy[LzYQg91SIxDeOGtCKd5][IgQimel18t],b8Qe150xVaJsnDSv)
			else:
				jMoI40N3fApTaDKsGy = YYBlm36zd0Jst18LXwo4.findall(IjZbnrBJmM2N(u"ࠪࡢ࠭ࡢࡤࠬ࠼࡟ࡨ࠰ࡀ࡜ࡥ࠭࡟࠲ࡡࡪࠫࠪࠪࠣࡘ࠿ࡢࡤࠬࠫࠪྼ"),CspH3o0yQVkReLwX8K9ql,YYBlm36zd0Jst18LXwo4.DOTALL)
				if jMoI40N3fApTaDKsGy: CspH3o0yQVkReLwX8K9ql = CspH3o0yQVkReLwX8K9ql.replace(jMoI40N3fApTaDKsGy[LzYQg91SIxDeOGtCKd5][qHYIWnOZLPkrQU],b8Qe150xVaJsnDSv)
			JYVuQCzoKw03aDRcbIgdeP7mLGFp.append(CspH3o0yQVkReLwX8K9ql)
			if len(str(JYVuQCzoKw03aDRcbIgdeP7mLGFp))>UUkIBz1sgQ9WfNeG6trKXvu0(u"࠸࠵࠲࠲࠳࠴ᇯ"): break
		JYVuQCzoKw03aDRcbIgdeP7mLGFp = reversed(JYVuQCzoKw03aDRcbIgdeP7mLGFp)
		Ifr17m0z8RKh9cSYwyo = VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠫࡡࡸ࡜࡯ࠩ྽").join(JYVuQCzoKw03aDRcbIgdeP7mLGFp)
		Ifr17m0z8RKh9cSYwyo = Ifr17m0z8RKh9cSYwyo.encode(OVauxZzLI10vcXT74K)
		Ifr17m0z8RKh9cSYwyo = lnFeUkiZtQ7E1.b64encode(Ifr17m0z8RKh9cSYwyo)
	else: Ifr17m0z8RKh9cSYwyo = b8Qe150xVaJsnDSv
	url = nTHXJIiah2qK[Mmpr0o76iWJvz1kTtfgI8hES(u"ࠬࡖ࡙ࡕࡊࡒࡒࠬ྾")][IgQimel18t]
	lo6biSg2NR3eUB1OpEPxzyXwF8sYWI = {IjZbnrBJmM2N(u"࠭ࡳࡶࡤ࡭ࡩࡨࡺࠧ྿"):PJKIlqFutvbapGnHYf07oZXDsW8Vxz,mQNonhS7CV2BXOv(u"ࠧ࡮ࡧࡶࡷࡦ࡭ࡥࠨ࿀"):A4gdSTQDP2FyBIVuba85RvYqKU,LAQD5wEkr18bUiGaYen3J(u"ࠨ࡮ࡲ࡫࡫࡯࡬ࡦࠩ࿁"):Ifr17m0z8RKh9cSYwyo}
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(nCUMfrlZvuiLe5x,IjZbnrBJmM2N(u"ࠩࡓࡓࡘ࡚ࠧ࿂"),url,lo6biSg2NR3eUB1OpEPxzyXwF8sYWI,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,vvWwO3Tx2dAgcijrFXq(u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗ࠲࡙ࡅࡏࡆࡢࡉࡒࡇࡉࡍ࠯࠴ࡷࡹ࠭࿃"))
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	if ubxGUTt1LraKhVZgpAP(u"ࠫࠧࡹࡵࡤࡥࡨࡩࡩ࡫ࡤࠣ࠼ࠣ࠵࠱࠭࿄") in jLtdbeYiQHnf4SpU2MTly: ip6CohvO5Tya9mFWVf3JdY1qL = CCxMXuNUEzolDZTKrBJ
	else: ip6CohvO5Tya9mFWVf3JdY1qL = DD5cFIejQa2X4BgAu9GWPyJ3tC7
	if showDialogs:
		if ip6CohvO5Tya9mFWVf3JdY1qL:
			yicQV3gj4q(Xz3bA2PFENVCUtplu51(u"ࠬะๅࠡษ็ษึูวๅࠢห๊ัออࠨ࿅"),ubxGUTt1LraKhVZgpAP(u"࠭ࡓࡶࡥࡦࡩࡸࡹ࿆ࠧ"))
			tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,IjZbnrBJmM2N(u"ࠧࡎࡧࡶࡷࡦ࡭ࡥࠡࡵࡨࡲࡹ࠭࿇"),mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠨฬ่ࠤสืำศๆࠣห้ืำศๆฬࠤอ์ฬศฯࠪ࿈"))
		else:
			yicQV3gj4q(mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠩ็่ศูแࠡใื่ࠥอไฦำึห้࠭࿉"),ubxGUTt1LraKhVZgpAP(u"ࠪࡊࡦ࡯࡬ࡶࡴࡨࠫ࿊"))
			tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ࿋"),yST5AHEfvPmcWpwGuh2BJ(u"ࠬิืฤ๋ࠢๅู๊ࠠโ์ࠣษึูวๅࠢส่ึูวๅหࠪ࿌"))
	return ip6CohvO5Tya9mFWVf3JdY1qL
def ZZH1qK3YWwDg9so0kVEMQcyIr():
	FSpIEkeP1D3ai4VZ5oB92zhy = zI3ROAZtiUq42rE9WDST68(u"࠭࠱࠯ࠢࠣࠤࡎ࡬ࠠࡺࡱࡸࠤ࡭ࡧࡶࡦࠢࡳࡶࡴࡨ࡬ࡦ࡯ࠣࡻ࡮ࡺࡨࠡࡃࡵࡥࡧ࡯ࡣࠡࡶࡨࡼࡹࡺࠠࡵࡪࡨࡲࠥ࡭࡯ࠡࡶࡲࠤࠧࡑ࡯ࡥ࡫ࠣࡍࡳࡺࡥࡳࡨࡤࡧࡪࠦࡓࡦࡶࡷ࡭ࡳ࡭ࡳࠣࠢࡤࡲࡩࠦࡣࡩࡣࡱ࡫ࡪࠦࡴࡩࡧࠣࡪࡴࡴࡴࠡࡶࡲࠤࠧࡇࡲࡪࡣ࡯ࠦࠬ࿍")
	eqURlBsy0m82xwA = TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠧ࠲࠰ࠣࠤࠥหะศࠢ็ำ๏้ࠠๆึๆ่ฮࠦแ๋ࠢส่ศำัโࠢส่฾ืศ๋หࠣๅฬึ็ษࠢศ่๎ࠦลฺัสำฬะ้ࠠษฯ๋ฮࠦใ้ัํࠤะ๋ࠠ฻์ิࠤฬ๊ฮุࠢสู่๊สฯั่ࠤส๊้ࠡࠤࡄࡶ࡮ࡧ࡬ࠣࠩ࿎")
	tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,LAQD5wEkr18bUiGaYen3J(u"ࠨࡃࡵࡥࡧ࡯ࡣࠡࡒࡵࡳࡧࡲࡥ࡮ࠩ࿏"),FSpIEkeP1D3ai4VZ5oB92zhy+kke1PDGRBLuY8y(u"ࠩ࡟ࡲࡡࡴࠧ࿐")+eqURlBsy0m82xwA)
	FSpIEkeP1D3ai4VZ5oB92zhy = IjZbnrBJmM2N(u"ࠪ࠶࠳ࠦࠠࠡࡋࡩࠤࡾࡵࡵࠡࡥࡤࡲࡡ࠭ࡴࠡࡨ࡬ࡲࡩࠦࠢࡂࡴ࡬ࡥࡱࠨࠠࡧࡱࡱࡸࠥࡺࡨࡦࡰࠣࡧ࡭ࡧ࡮ࡨࡧࠣࡸ࡭࡫ࠠࡴ࡭࡬ࡲࠥࡧ࡮ࡥࠢࡷ࡬ࡪࡴࠠࡤࡪࡤࡲ࡬࡫ࠠࡵࡪࡨࠤ࡫ࡵ࡮ࡵࠩ࿑")
	eqURlBsy0m82xwA = ddo23ZJtgcY(u"ࠫ࠷࠴ࠠࠡࠢศิฬࠦไๆࠢอะิࠦวๅะฺࠤࠧࡇࡲࡪࡣ࡯ࠦࠥ็โๆࠢหฮ฿๐๊าࠢส่ั๊ฯࠡอ่ࠤ็๋ࠠษฬ฽๎ึࠦวๅะฺࠤฬ๊ๅิฬัำ๊ࠦลๅ๋ࠣࠦࡆࡸࡩࡢ࡮ࠥࠫ࿒")
	tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠬࡌ࡯࡯ࡶࠣࡔࡷࡵࡢ࡭ࡧࡰࠫ࿓"),FSpIEkeP1D3ai4VZ5oB92zhy+S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"࠭࡜࡯࡞ࡱࠫ࿔")+eqURlBsy0m82xwA)
	FSpIEkeP1D3ai4VZ5oB92zhy = P0qdZI384LKleuo(u"ࠧ࠴࠰ࠣࠤࠥࡏࡦࠡࡻࡲࡹࠥࡪ࡯࡯࡞ࠪࡸࠥ࡮ࡡࡷࡧࠣࡅࡷࡧࡢࡪࡥࠣࡏࡪࡿࡢࡰࡣࡵࡨࠥࡺࡨࡦࡰࠣ࡫ࡴࠦࡴࡰࠢࠥࡏࡴࡪࡩࠡࡋࡱࡸࡪࡸࡦࡢࡥࡨࠤࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸࠨࠠࡢࡰࡧࠤࡨ࡮ࡡ࡯ࡩࡨࠤࡹ࡮ࡥࠡࡴࡨ࡫࡮ࡵ࡮ࡢ࡮ࠣࡷࡪࡺࡴࡪࡰࡪࡷࠬ࿕")
	eqURlBsy0m82xwA = QTUBCcehw6qPd4x(u"ࠨ࠵࠱ࠤࠥࠦลัษ่๊๊ࠣࠦไ่่ࠣิ๐ใࠡๆ๋ัฮࠦๅโษอ๎าูࠦาสํอࠥ็วั้หࠤส๊้ࠡว฼ำฬีวห๋ࠢหัํษࠡๅ๋ำ๏ࠦหๆࠢ฽๎ึࠦลฺัสำฬะࠠศๆ่๊฼่ษࠡษ็ะ฿ืวโ์ฬࠫ࿖")
	tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,mQNonhS7CV2BXOv(u"ࠩࡉࡳࡳࡺࠠࡑࡴࡲࡦࡱ࡫࡭ࠨ࿗"),FSpIEkeP1D3ai4VZ5oB92zhy+LAQD5wEkr18bUiGaYen3J(u"ࠪࡠࡳࡢ࡮ࠨ࿘")+eqURlBsy0m82xwA)
	aVwGA2kFY6u4m = BjMmX1vNrnzSAf(ubxGUTt1LraKhVZgpAP(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ࿙"),b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,yST5AHEfvPmcWpwGuh2BJ(u"ࠬࡌ࡯࡯ࡶࠣࡷࡪࡺࡴࡪࡰࡪࡷࠬ࿚"),QQdAXWBc2GPw(u"࠭ࡄࡰࠢࡼࡳࡺࠦࡷࡢࡰࡷࠤࡹࡵࠠࡨࡱࠣࡸࡴࠦࠢࡌࡱࡧ࡭ࠥࡏ࡮ࡵࡧࡵࡪࡦࡩࡥࠡࡕࡨࡸࡹ࡯࡮ࡨࡵࠥࠤࡳࡵࡷࠡࡁࠪ࿛")+TYf7Dc06PQgy1vEV9(u"ࠧ࡝ࡰ࡟ࡲࠬ࿜")+Xz3bA2PFENVCUtplu51(u"ࠨ้็ࠤฯื๊ะࠢส่ีํวษࠢศ่๎ࠦไ้ฯฬࠤส฿ฯศัสฮࠥ๎วอ้ฬࠤ่๎ฯ๋ࠢฦ่ว์ฟࠨ࿝"))
	if aVwGA2kFY6u4m==DYakr9g4PVU(u"࠱ᇰ"): Bah3px6DHs04w()
	return
def F34lsJmaBxhWiHZ9RA():
	tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ࿞"),SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠪ฾ฬ๊ศศࠢสุ่ฮศ้๋ࠡࠤ๊์ࠠศๆ่์็฿ࠠศๆฦู้๐ࠠศๆ่฾ี๐ࠠๅๆหี๋อๅอ๋่้ࠢะรไัࠣๆ๊ࠦศหึ฽๎้ࠦวๅำสฬ฼ࠦวๅาํࠤ้อ๋ࠠ฻่่ࠥัๅࠡไ่ࠤอหัิษ็ࠤฺ๊ใๅหࠣษ้๏ࠠศๆ่ฬึ๋ฬࠡ็้ࠤฬ๊โศศ่อࠥอไาศํื๏ฯࠠๅๆหี๋อๅอࠩ࿟"))
	return
def IhmE5fGjcbetvCd3iTQWwLM():
	A4gdSTQDP2FyBIVuba85RvYqKU = UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠫ์ึวࠡษ็ฬึ์วๆฮ้ࠣำ฻ีࠡใๅ฻๊ࠥไ฻หࠣห้฿ัษ์ฬࠤํ๊ใ็๊ࠢิฬࠦไศࠢํ้๋฿้ࠠฮ๋ำ๋่ࠥศไ฼ࠤๆ๐็ศࠢฦๅ้อๅ๊่ࠡืู้ไศฬ้ࠣฯืฬๆหࠣวํࠦๅะส็ะฮࠦลๅ๋ࠣหฺ้๊สࠢส่฾ืศ๋หࠣ์ฬ๊้ࠡๆ฽หฯࠦวฯำ์ࠤํ๊วࠡ์๋ะิࠦำษส่้ࠣะใาษิࠫ࿠")
	tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,zI3ROAZtiUq42rE9WDST68(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ࿡"),A4gdSTQDP2FyBIVuba85RvYqKU)
	return
def JEIZpTLHzQhjm695teSdiqs():
	A4gdSTQDP2FyBIVuba85RvYqKU = SbjiWeHLQPoazqwp3cODkd7YxVgn(u"࠭วๅำ๋หอ฽ࠠศๆห฻๏ฬษࠡๆสࠤ฾๊วให่ࠣ์อࠠษษ็ฬึ์วๆฮࠣ์฿อไษษࠣหู้ศษ๊ࠢ์๋ࠥๆࠡษ็้ํู่ࠡษ็วฺ๊๊ࠡษ็้฿ึ๊ࠡๆ็ฬึ์วๆฮࠪ࿢")
	tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,mQNonhS7CV2BXOv(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ࿣"),A4gdSTQDP2FyBIVuba85RvYqKU)
	return
def rsC2nwNj4cfHQg3MGYp1hZ8v9OV():
	A4gdSTQDP2FyBIVuba85RvYqKU = TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠨ้ํࠤุ๐ัโำสฮ๊ࠥวࠡ์ึฮ฼๐ูࠡษ็ฬึ์วๆฮࠣหุะฮะษ่๋ฬࠦศิสหࠤ่๎ๆ่ษ้ࠣา๋๊ส่๊ࠢࠥอไๆืาีࠥษ่ࠡสะหัฯࠠฦๆ์ࠤฬฺสาษๆࠤึูๅ๋ࠢฦ์ࠥาฯ๋ัฬࠤศ๎ࠠๅษࠣ๎฾ืแ่ษࠣห้ฮั็ษ่ะࠬ࿤")
	tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,uVQd103XyvUce2EBtzbYaC(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ࿥"),Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠪื๏ืแาษอࠤุ๐ฦสࠢฦ์๋ࠥฬ่๊็อࠬ࿦"),A4gdSTQDP2FyBIVuba85RvYqKU)
	return
def E0JeLy8YxZb23AmpNU():
	A4gdSTQDP2FyBIVuba85RvYqKU = vvWwO3Tx2dAgcijrFXq(u"ࠫฬ๊ำ๋ำไีฬะࠠศๆ฼ห๊ฯ่ࠠ์ࠣื๏ืแาษอࠤำอัอ์ฬࠤํเ๊าࠢอหอ฿ษࠡๆ็้ํู่ࠡษ็วฺ๊๊๊ࠡฯ้๏฿ࠠศๆ่์ฬู่ࠡฬึฮำีๅ่ษࠣ์฾อฯสࠢอ็ํ์ࠠๆฮส๊๏ฯ้ࠠ็ืห่๊็ศࠢๆฯ๏ืษࠡๆส๊ࠥอไโ์า๎ํํวหࠢไ๎์อࠠฦ็สࠤอ฽๊วหࠣวํࠦๅๆ่๋฽ฮࠦร้่ࠢัี๎แสࠢฦ์ࠥ็๊่ษู้้ࠣไสࠢะๆํ่ࠠศๆ่่่๐ษ࡝ࡰ࡟ࡲࡡࡴวๅีํีๆืวหࠢส่ำอีส๊ࠢ๎ู๊ࠥาใิหฯࠦสศส฼อ๊ࠥไๆ๊ๅ฽ࠥอไฤื็๎ࠥ๎ๅิฬัำ๊ฯࠠโ์้ࠣํอโฺࠢๅ่๏๊ษࠡฮาหࠥ๎ูศัฬࠤฯ้่็่ࠢำๆ๎ูสࠢส่ศาัࠡล๋ࠤ๏๋ไไ้สࠤฬ๊ๅ้ไ฼ࠤฬ๊รึๆํࠤํ๊็ัษࠣๅ์๐ࠠอ์าอࠥ์ำษ์สࠤํูั๋฻ฬࠤํ๋ิศๅ็๋ฬࠦโๅ์็อࠥาฯศࠩ࿧")
	bJvWMFh8G3eas(Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ࿨"),VFjQx6Is28KvzLOmMXtg4GqTwa3(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ࿩"),A4gdSTQDP2FyBIVuba85RvYqKU,IjZbnrBJmM2N(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪ࿪"))
	return
def O4u8cfLixWrQGw():
	FSpIEkeP1D3ai4VZ5oB92zhy = BWNPxIG7vqdTy85pjHzUOrK3(u"ࠨษหฮ฾ีฺ่้้ࠠࠣ็วหࠢส่ิ่ษࠡษ็฽ฬ๊๊สࠩ࿫")
	eqURlBsy0m82xwA = kke1PDGRBLuY8y(u"ࠩสฬฯ฿ฯࠡ฻้ࠤ๊๊แศฬࠣว้ࠦ࡭࠴ࡷ࠻ࠫ࿬")
	zzi8PC6qjXNa5hBw = QTUBCcehw6qPd4x(u"ࠪหอะูะࠢ฼๊๋ࠥไโษอࠤฬ๊สฮ็ํ่ࠥ๎วๅัส์๋๊่ะࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ࿭")
	tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,DYakr9g4PVU(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ࿮"),FSpIEkeP1D3ai4VZ5oB92zhy,eqURlBsy0m82xwA,zzi8PC6qjXNa5hBw)
	return
def m3mZndtTeo5ADCWYr6b0():
	eqURlBsy0m82xwA = shC5qBRV2A0lZ(u"ࠬอไไษืࠤ์๎ࠠๆะี๊๋ࠥฤใฬู่้๋ࠣๅ๊่หฯ๊ࠦิฬัำ๊ํࠠศๆหี๋อๅอࠢ็าื์ࠠึใะหฯࠦวๅว้ฮึ์๊ห๋ࠢีํอศุࠢส่ๆ๐ฯ๋๊๊หฯࠦไๅุ๊์้ࠦลๅ์๊หࠥฮำา฻ฬࠤํฮฯ้่ࠣษ๋ะั็์อࠤํอไษำ้ห๊า๋ࠠ็ึั์อࠠหๆๅหห๐วࠡส฼ำࠥอๆห้สลࠥ฿ๅา้สࠤํษ๊ืษࠣ฽๋ีࠠหฯา๎ะࠦวๅสิ๊ฬ๋ฬࠡ࠰ࠣ์์ึวࠡษ็ฬึ์วๆฮࠣ๎ุะฮะ็ࠣือ฿ษࠡล้์ฬ฿ࠠๅ฻่ีࠥอไไษืࠤ࠿࠭࿯")
	eqURlBsy0m82xwA += shC5qBRV2A0lZ(u"࠭࡜࡯࡞ࡱࠫ࿰") + yST5AHEfvPmcWpwGuh2BJ(u"ࠧ࠲࠰ࠣฯฬฮสࠡๆ็ูๆำวหࠢส่ฯ๐ࠠๆ฻ิ์ๆࠦร็้สࠤ้อࠠหฬ฽๎ึࠦๆ่ษษ๎ฬ่ࠦๆัอ๋ࠥ࠭࿱") + str(t58tnzAgevxkoIOdMFbE2PsD64q0C9/mmcNLrXtzfpyCkZlvK5VwG2gujh(u"࠷࠲ᇱ")/mmcNLrXtzfpyCkZlvK5VwG2gujh(u"࠷࠲ᇱ")/TYf7Dc06PQgy1vEV9(u"࠴࠷ᇲ")/m6hwdgP31a2zjN7lkpX(u"࠶࠴ᇳ")) + P0qdZI384LKleuo(u"ࠨࠢื๋ึ࠭࿲")
	eqURlBsy0m82xwA += eeN6dTEnkJxI + vvWwO3Tx2dAgcijrFXq(u"ࠩ࠵࠲ࠥาฯศฺࠢ์๏๊ࠠศๆ่ำ๎ࠦไๅืไัฬะࠠศๆ่ๅึ๎ึࠡล้๋ฬࠦไศࠢอฮ฿๐ั๊่ࠡำฯํࠠࠨ࿳") + str(xkDunX3BfFiYG/Xz3bA2PFENVCUtplu51(u"࠺࠵ᇴ")/Xz3bA2PFENVCUtplu51(u"࠺࠵ᇴ")/DYakr9g4PVU(u"࠷࠺ᇵ")) + Xz3bA2PFENVCUtplu51(u"ࠪࠤ๏๎ๅࠨ࿴")
	eqURlBsy0m82xwA += eeN6dTEnkJxI + m6hwdgP31a2zjN7lkpX(u"ࠫ࠸࠴ุ๊ࠠํ่ࠥอไๆั์ࠤ้๊ีโฯสฮࠥอไห์๊ࠣฬีัศࠢอฮ฿๐ั๊่ࠡำฯํࠠࠨ࿵") + str(Q49IsrlSuYRAVbGKhwdckLDOetF2PZ/QQdAXWBc2GPw(u"࠼࠰ᇶ")/QQdAXWBc2GPw(u"࠼࠰ᇶ")/TT8Mxv5Wq7nlC9IscdpPUY6(u"࠲࠵ᇷ")) + vvWwO3Tx2dAgcijrFXq(u"๊้ࠬࠦ็ࠪ࿶")
	eqURlBsy0m82xwA += eeN6dTEnkJxI + S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"࠭࠴࠯่ࠢฮํูืࠡษ็้ิ๏ࠠๅๆุๅาอสࠡษ็ฮ๏ࠦโะࠢอฮ฿๐ั๊่ࠡำฯํࠠࠨ࿷") + str(GMkNL1RXxKFentp0Zh9d/QTUBCcehw6qPd4x(u"࠷࠲ᇸ")/QTUBCcehw6qPd4x(u"࠷࠲ᇸ")) + P0qdZI384LKleuo(u"ࠧࠡีส฽ฮ࠭࿸")
	eqURlBsy0m82xwA += eeN6dTEnkJxI + RRIHDFjoW9w7bSfVPhC(u"ࠨ࠷࠱ࠤ็฻๊าࠢส่๊ี้ࠡๆ็ูๆำวหࠢส่ฯ๐ࠠหฬ฽๎ึࠦฯศศ่หࠥ๎ๅะฬ๊ࠤࠬ࿹") + str(LtlXH3fvMydAx/BWNPxIG7vqdTy85pjHzUOrK3(u"࠸࠳ᇹ")/BWNPxIG7vqdTy85pjHzUOrK3(u"࠸࠳ᇹ")) + Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠩࠣืฬ฿ษࠨ࿺")
	eqURlBsy0m82xwA += eeN6dTEnkJxI + mQNonhS7CV2BXOv(u"ࠪ࠺࠳ࠦฬะษࠣๆฺ๐ัࠡษ็้ิ๏ࠠๅๆุๅาอสࠡษ็ฮ๏ࠦสห฼ํี้ࠥห๋ำสࠤํ๋ฯห้ࠣࠫ࿻") + str(IiYS8Jg4da3UuDP0qr6vy/BWNPxIG7vqdTy85pjHzUOrK3(u"࠹࠴ᇺ")) + ddo23ZJtgcY(u"ࠫࠥีโ๋ไฬࠫ࿼")
	eqURlBsy0m82xwA += eeN6dTEnkJxI + Xz3bA2PFENVCUtplu51(u"ࠬ࠽࠮ࠡสา์๋ࠦใศึ่้ࠣ฻แฮษอࠤฬ๊ส๋ࠢอฮ฿๐ัࠡสึี฾ฯ้ࠠ็าฮ์ࠦࠧ࿽") + str(nCUMfrlZvuiLe5x) + DYakr9g4PVU(u"࠭ࠠะไํๆฮ࠭࿾")
	eqURlBsy0m82xwA += VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠧ࡝ࡰ࡟ࡲࠬ࿿") + RRIHDFjoW9w7bSfVPhC(u"ࠨ็ฮ่ฬࡀࠠึใะหฯࠦโ้ษษ้ࠥอไฤใ็ห๊่ࠦศๆ่ืู้ไศฬࠣ์ฬ๊อๅไสฮࠥ฿ๅา้สࠤࠬက") + str(GMkNL1RXxKFentp0Zh9d/vvWwO3Tx2dAgcijrFXq(u"࠺࠵ᇻ")/vvWwO3Tx2dAgcijrFXq(u"࠺࠵ᇻ")) + TYf7Dc06PQgy1vEV9(u"ࠩࠣืฬ฿ษࠡ࠰ࠣว๊อࠠใ๊สส๊ࠦร็๊ส฽ࠥอไโ์า๎ํํวหࠢไ฽๊ื็ศࠢࠪခ") + str(Q49IsrlSuYRAVbGKhwdckLDOetF2PZ/vvWwO3Tx2dAgcijrFXq(u"࠺࠵ᇻ")/vvWwO3Tx2dAgcijrFXq(u"࠺࠵ᇻ")/kke1PDGRBLuY8y(u"࠷࠺ᇼ")) + QTUBCcehw6qPd4x(u"ࠪࠤศ๐วๆࠢ࠱ࠤศ๋วࠡ็็ๅฬะࠠศๆไ๎ิ๐่ࠡใ฼้ึํวࠡࠩဂ") + str(LtlXH3fvMydAx/vvWwO3Tx2dAgcijrFXq(u"࠺࠵ᇻ")/vvWwO3Tx2dAgcijrFXq(u"࠺࠵ᇻ")) + Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ูࠫࠥวฺหࠣๅ็฽ࠠ࠯ࠢฦ้ฬࠦแฮืࠣี็๋ࠠศๆศูิอัࠡใ฼้ึํࠠࠨဃ") + str(IiYS8Jg4da3UuDP0qr6vy/vvWwO3Tx2dAgcijrFXq(u"࠺࠵ᇻ")) + TYf7Dc06PQgy1vEV9(u"ࠬࠦฯใ์ๅอࠥ࠴ࠠฤ็สࠤๆำีࠡษืฮึอใࠡโࡌࡔ࡙࡜ࠠโ฻่ี์ࠦࠧင") + str(nCUMfrlZvuiLe5x) + TT8Mxv5Wq7nlC9IscdpPUY6(u"࠭ࠠะไํๆฮ࠭စ")
	bJvWMFh8G3eas(Xz3bA2PFENVCUtplu51(u"ࠧࡳ࡫ࡪ࡬ࡹ࠭ဆ"),TYf7Dc06PQgy1vEV9(u"ࠨ็สࠤ์๎ࠠศๆๆหูࠦวๅ็ึฮำีๅࠡใํࠤฬ๊ศา่ส้ั࠭ဇ"),eqURlBsy0m82xwA,ddo23ZJtgcY(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬဈ"))
	return
def qfVZtFsrzTIa4gdX():
	A4gdSTQDP2FyBIVuba85RvYqKU = Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠪห้็วึๆฬࠤฯ฿ๆ๋่ࠢะ้ีࠠษ่ไืࠥอำๆ้ࠣห้ษีๅ์ࠣ์ฬ๊ๆใูฬࠤฯ฿ๆ๋ࠢฦ๊ࠥอไศี่ࠤฬ๊รึๆํࠤฯ๋ࠠห฻า๎้ํ้ࠠใสู้ฯ้่ࠠๅ฻ฮࠦสฺ่์ࠤ๊าไะ๋ࠢฮ๊ࠦสฺัํ่ࠥอำๆ้ࠣ์อี่็ࠢ฼่ฬ๋ษࠡฬ฼๊๏ࠦๅๅใࠣฬ๋็ำࠡษึ้์ࠦวๅลุ่๏࠭ဉ")
	tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧည"),A4gdSTQDP2FyBIVuba85RvYqKU)
	return
def eIATdmLcnPxkWG07fOEr():
	A4gdSTQDP2FyBIVuba85RvYqKU = kke1PDGRBLuY8y(u"ࠬหะศ๋ࠢหัํสไุ่่๊ࠢษࠡใํࠤฬ๊ิษๅฬࠤํะๅࠡฯ็๋ฬࠦ࠮࠯࠰ࠣวํࠦว็ๅࠣฮ฽์ࠠฤ่ࠣห้๋่ใ฻ࠣห้ษีๅ์ࠣ็ฬ์ࠠโ์๊ࠤฺ๊ใๅห้ࠣษ่ส่๋ࠢฮ๊ࠦอๅ้สࠤ࠳࠴࠮ࠡใศิ๋ࠦฬาสุ้ࠣำࠠไษืࠤฬ๊ศา่ส้ัࠦไไ์ࠣ๎็๎ๅࠡษ็ฬึ์วๆฮࠣฬ฼๊ศࠡษ็ูๆำษࠡษ็ูา๐อส๋ࠢฮำุ๊็้สࠤอีไศ่๊ࠢࠥอไึใะอࠥอไใัํ้ฮ࠭ဋ")
	tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,ddo23ZJtgcY(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩဌ"),A4gdSTQDP2FyBIVuba85RvYqKU)
	return
def hTxW53Qgw81():
	A4gdSTQDP2FyBIVuba85RvYqKU = QTUBCcehw6qPd4x(u"ࠧศๆ฽ี฻ࠦๅ็ࠢื๋ฬีษࠡษ็ฮู็๊า๊ࠢ์ࠥ฼ๅศู่ࠣาฯ้ࠠีิ๎ฮࠦวๅ็฼่ํ๋วหࠢส่๊ะศศั็อࠥฮ๊็ࠢส่อืๆศ็ฯࠤํอไๆ๊ๅ฽ࠥอไๆึไีࠥ๎็ัษࠣห้฼ๅศ่ࠣ฾๏ืࠠๆู็์อ่ࠦๅษࠣัฬาษࠡๆ๊ࠤ฾์ฯࠡษ็หฯ฻วๅࠢส์ࠥอไาสฺࠤ๊฿ࠠๆ๊สๆ฾ࠦวๅใํำ๏๎็ศฬࠣห้๋ิโำฬࠫဍ")
	tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,DYakr9g4PVU(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫဎ"),A4gdSTQDP2FyBIVuba85RvYqKU)
	return
def ZlAOgj92Tq():
	tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,zI3ROAZtiUq42rE9WDST68(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬဏ"),Nh0BWuiSndf(u"่่ࠪ๐๋ࠠ฻่่ࠥํะศࠢส่๋๎ูࠡ็้ࠤฬ๊แ๋ัํ์์อสࠡ࡞ࡱࠤ๏าศࠡฬไ฽๏๊ࠠฦุสๅฮࠦวิ็๊หࠥࡢ࡮ࠡ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡡࡥࡣࡳࡸ࡮ࡼࡥࠨတ"))
	iYa4V16rHzIO(VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡤࡨࡦࡶࡴࡪࡸࡨࠫထ"),CCxMXuNUEzolDZTKrBJ)
	return
def gxPVWNCO7Qr6DXf0vIAiTHycqnSGd2():
	A4gdSTQDP2FyBIVuba85RvYqKU  = TT8Mxv5Wq7nlC9IscdpPUY6(u"๋ࠬฤฯำสࠤ็อๅหࠢห฽฻ࠦิาๅสฮࠥอไฦ่อี๋ะࠠศๆา์้๐ࠠษู๊฽ࠥ฿ววไฺࠣิࠦวๅสิห๊าࠠๆอ็ࠤ่๎ฯ๋ࠢ็ฮุ๋อࠡใๅ฻๊ࠥศฺุุ้ࠣะฮะ็ํࠤฬ๊ๅหืไัࠥฮวๅัั์้ࠦไๆ๊สๆ฾ࠦวๅใํำ๏๎ࠧဒ")
	A4gdSTQDP2FyBIVuba85RvYqKU += yST5AHEfvPmcWpwGuh2BJ(u"้่࠭ࠠอ๎ัฯࠠๅ้ำหࠥอไฺษษๆࠥ็ว็้ࠣฮ็ื๊ษษࠣะ๊๐ูࠡ็ึฮำีๅ๋ࠢหี๋อๅอࠢๆ์ิ๐ࠠๅษࠣ๎ุะื๋฻๋๊ࠥอไะะ๋่๊ࠥฬๆ์฼ࠤ๊๎วใ฻ࠣห้ฮั็ษ่ะࠥำส๊่ࠢ฽ࠥอำหะาห๊࠭ဓ")
	A4gdSTQDP2FyBIVuba85RvYqKU += eeN6dTEnkJxI+rC3Tlno96KjLDIvBaSWUbR8+Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠧแ࡚ࠢࠣࡕࡔࠠࠡล๋ࠤࠥࡖࡲࡰࡺࡼࠤࠥษ่ࠡࠢࡇࡒࡘࠦࠠฤ๊ࠣว๏ࠦอๅࠢหื๏฽ࠠระิࠫန")+hAIp8kmC36T5WFPMSXOwnNbtD+eeN6dTEnkJxI
	A4gdSTQDP2FyBIVuba85RvYqKU += VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠨ࡞ࡱ่ฬ์่ࠠาสࠤ้์๋ࠠฯ็ࠤฬ๊ๅีๅ็อࠥ๎ล็็สࠤๆ่ืࠡีํๆํ๋ࠠษวุ่ฬำࠠษ฻ูࠤฬ๊ๅ้ษๅ฽ࠥ๎ลฺษๅอ๋่ࠥศไ฼ࠤฬิั๊ࠢๆห๋ะࠠห฻ู่่ࠥวษไสࠤอี่็ุ่ࠢฬ้ไࠨပ")
	bJvWMFh8G3eas(zI3ROAZtiUq42rE9WDST68(u"ࠩࡵ࡭࡬࡮ࡴࠨဖ"),DYakr9g4PVU(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ဗ"),A4gdSTQDP2FyBIVuba85RvYqKU,VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧဘ"))
	A4gdSTQDP2FyBIVuba85RvYqKU = IjZbnrBJmM2N(u"ࠬอไๆ๊สๆ฾ࠦวๅฬํࠤฯษหาฬࠣฬฬู๊ศศๅࠤ฾์ฯࠡส฼ฺࠥอไ็ษึࠤ์๐࠺ࠨမ")
	A4gdSTQDP2FyBIVuba85RvYqKU += eeN6dTEnkJxI+rC3Tlno96KjLDIvBaSWUbR8+Mmpr0o76iWJvz1kTtfgI8hES(u"࠭ࡡ࡬ࡱࡤࡱࠥࠦࡥࡨࡻࡥࡩࡸࡺࠠࠡࡧࡪࡽࡧ࡫ࡳࡵࡸ࡬ࡴࠥࠦ࡭ࡰࡸ࡬ࡾࡱࡧ࡮ࡥࠢࠣࡷࡪࡸࡩࡦࡵ࠷ࡻࡦࡺࡣࡩࠢࠣࡷ࡭ࡧࡨࡪࡦ࠷ࡹࠬယ")+hAIp8kmC36T5WFPMSXOwnNbtD
	A4gdSTQDP2FyBIVuba85RvYqKU += Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠧ࡝ࡰ࡟ࡲࠬရ")+IjZbnrBJmM2N(u"ࠨษ็ำํ๊ࠠศๆอ๎ࠥะรฬำอࠤออไฺษษๆࠥ฿ๆะࠢห฽฻ࠦวๅ่สืࠥํ๊࠻ࠩလ")
	A4gdSTQDP2FyBIVuba85RvYqKU += eeN6dTEnkJxI+rC3Tlno96KjLDIvBaSWUbR8+LAQD5wEkr18bUiGaYen3J(u"ู่ࠩึࠦࠠศๆๆ์๏ะࠠࠡล่๎ึ้วࠡࠢๆ๊ิอࠠࠡใิุ๊อࠠࠡษ็๎ํ์ว็ࠢࠣฬึ๐ืศ่ํหࠥอไฦ็สีฬะࠠฤๆ่ห๋๐วࠡำ๋ื๏อࠠศๆํหออๆࠡษ็ื฾๎ฯ๋หࠣีํ๋ว็์สࠤ์๎ไ็ัสࠫဝ")+hAIp8kmC36T5WFPMSXOwnNbtD
	A4gdSTQDP2FyBIVuba85RvYqKU += BmePGjS7FxK6kutUM(u"ࠪࡠࡳࡢ࡮ࠨသ")+zI3ROAZtiUq42rE9WDST68(u"ࠫฬ๊ๅษำ่ะࠥ๎ฬะฺࠢี๏่ษࠡๆอะฬ๎าࠡษ็฽ฬฬโ๊ࠡ็็๋ํวࠡฬะฮฬาࠠอ้าࠤ่ฮ๊า๋ࠢห้๋ศา็ฯࠤ๏฾ๆࠡษ็ู้้ไสุࠢ฾๏ืษ๊ࠡ็หࠥะำหฯๅࠤฬ๊สฺสࠣๅสึวࠡๆา๎่ࠦๅีๅ็อࠥฮวๅัั์้ࠦไษ฻ูࠤฬ๊ๅ้ษๅ฽ࠥ๎รุ๋สࠤ้้๊ࠡ์อฺาࠦออ็ࠣห้๋ิไๆฬࠤࠬဟ")
	A4gdSTQDP2FyBIVuba85RvYqKU += rC3Tlno96KjLDIvBaSWUbR8+yST5AHEfvPmcWpwGuh2BJ(u"ࠬอัิๆࠣีุอไส่ࠢศิฮษࠡว็ํࠥอไๆสิ้ั่ࠦศๅอฬࠥ็๊่ษࠣหุ๋ࠠษๆา็ࠥ๎ริ็สลࠥอไๆ๊สๆ฾ࠦวๅฬํࠤ้อࠠหีอ฻๏฿ࠠะะ๋่์อࠧဠ")+hAIp8kmC36T5WFPMSXOwnNbtD
	bJvWMFh8G3eas(TT8Mxv5Wq7nlC9IscdpPUY6(u"࠭ࡲࡪࡩ࡫ࡸࠬအ"),Mmpr0o76iWJvz1kTtfgI8hES(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪဢ"),A4gdSTQDP2FyBIVuba85RvYqKU,yST5AHEfvPmcWpwGuh2BJ(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫဣ"))
	return
def I34lRoMfySGVxBmY():
	tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,QTUBCcehw6qPd4x(u"ࠩฮ่ฬัุࠠำๅࠤ้๊ส้ษุู่๋ࠥࠡษ็้อืๅอࠩဤ"),RRIHDFjoW9w7bSfVPhC(u"ࠪวึูไࠡำึห้ฯࠠฤู๊้้ࠣไส่๊่ࠢࠥวว็ฬࠤำีๅศฬ๋ࠣีอࠠศๆหี๋อๅอ࡞ࡱࡠࡳษ่ࠡสสืฯิฯศ็ࠣห้็๊ิส๋็ࠥษฯ็ษ๊ࡠࡳ࠭ဥ")+rC3Tlno96KjLDIvBaSWUbR8+shC5qBRV2A0lZ(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࡫ࡧࡣࡦࡤࡲࡳࡰ࠴ࡣࡰ࡯࠲ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴ࠴࠳࠵࠽࠭ဦ")+hAIp8kmC36T5WFPMSXOwnNbtD+VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠬࡢ࡮࡝ࡰฦ์ࠥฮวาีส่ࠥอ๊ๆ์็ࠤฬ๊้ࠡลา๊ฬํࠠࠡ࡞ࡱࠤࠬဧ")+rC3Tlno96KjLDIvBaSWUbR8+RRIHDFjoW9w7bSfVPhC(u"࠭ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷ࠷࠶࠱࠹ࡂࡪࡱࡦ࡯࡬࠯ࡥࡲࡱࠬဨ")+hAIp8kmC36T5WFPMSXOwnNbtD)
	return
def yZS8NxF02XCzB63idOAJ():
	m3mZndtTeo5ADCWYr6b0()
	aVwGA2kFY6u4m = BjMmX1vNrnzSAf(LAQD5wEkr18bUiGaYen3J(u"ࠧࡤࡧࡱࡸࡪࡸࠧဩ"),b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠨ้็ࠤฯื๊ะ่ࠢืาࠦฬๆ์฼ࠤฬ๊ใศึࠣรࠬဪ"),HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠩส่่อิࠡ์ึี฾ูࠦๆๆࠣห้ฮั็ษ่ะࠥ๎ๅิฯ๊ࠤ๏฿๊ะࠢึัอࠦวๅืไัฬะࠠๆ่ࠣห้หๆหำ้ฮࠥ฿ๆะࠢส่าอฬสࠢศ่๏ํว๊ࠡสู่๊อࠡ์อ้ࠥะไใษษ๎ฬูࠦ็ัࠣห๋ะ็ศรࠣ฽๊ืࠠศๆุๅาอส๊ࠡสู่๊อࠡๆสࠤ๏฼ั๊่้่ࠡ์๋ࠠฯ็ࠤอ฿ึࠡษ็ู้อใๅࠩါ"))
	if aVwGA2kFY6u4m==TT8Mxv5Wq7nlC9IscdpPUY6(u"࠷ᇽ"):
		thjSw2b6gur9s(CCxMXuNUEzolDZTKrBJ)
		tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,m6hwdgP31a2zjN7lkpX(u"ࠪฮ๊ࠦๅิฯࠣ็ฬฺࠠศๆหี๋อๅอࠢหห้้วๆๆࠪာ"),uVQd103XyvUce2EBtzbYaC(u"ࠫสึวࠡๅส๊ฯูࠦ็ัๆࠤฺ๊ใๅหࠣๅ๏ࠦวฮัࠣห้๋่ศไ฼ࠤๆาัษࠢส่๊๎โฺࠢส่ว์ࠠ࠯࠰࠱ࠤํษะศࠢสฺ่๊ใๅหุ้ࠣะๅาหࠣๅสึๆࠡษิื้ࠦวๅ็ื็้ฯࠠฦๆ์ࠤฬ๊ๅษำ่ะࠬိ"))
	return aVwGA2kFY6u4m
def PPvHDeXL8Uxpy(showDialogs=CCxMXuNUEzolDZTKrBJ):
	if not showDialogs: showDialogs = CCxMXuNUEzolDZTKrBJ
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(nCUMfrlZvuiLe5x,IjZbnrBJmM2N(u"ࠬࡍࡅࡕࠩီ"),QTUBCcehw6qPd4x(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦࡺࡤࡱࡵࡲࡥ࠯ࡥࡲࡱࠬု"),b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,DD5cFIejQa2X4BgAu9GWPyJ3tC7,b8Qe150xVaJsnDSv,SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࡋࡘ࡙ࡖࡓࡠࡖࡈࡗ࡙࠳࠱ࡴࡶࠪူ"))
	if not b3HKopTY9zLUyhJmt.succeeded:
		n0cw7OKbM4ruo = DD5cFIejQa2X4BgAu9GWPyJ3tC7
		ZbGDcPgUyw7S0 = RkNASsitM7eYvhqL62FVlfDuZW4x(DD5cFIejQa2X4BgAu9GWPyJ3tC7)
		mwIxD3GBPgLVc2aq9(WG2BfeyzMa,EECz06teoykrNFfq(QQ8pvXNcBfVkP5rRJ7o)+HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠨࠢࠣࠤࡍ࡚ࡔࡑࡕࠣࡊࡦ࡯࡬ࡦࡦࠣࠤࠥࡒࡡࡣࡧ࡯࠾ࡠ࠭ေ")+ZbGDcPgUyw7S0+TYf7Dc06PQgy1vEV9(u"ࠩࡠࠫဲ"))
		if showDialogs: tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,TYf7Dc06PQgy1vEV9(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ဳ"),DYakr9g4PVU(u"ࠫๆำีࠡษ็หฯ฻วๅࠢสฺ่๊แาࠢ࠱࠲࠳ࠦๅีๅ็อࠥ࠴࠮࠯ࠢส่ฬะีศๆࠣห้๋ิโำࠣࠬฬ๊ัษูࠣห้๋ิโำࠬࠤ้อ๋ࠠ฻่่ࠥ฿ๆะๅࠣ฽้๏ࠠไ๊า๎ࠥ࠴࠮࠯๋ࠢ฽๋ีใࠡๅ๋ำ๏ฺ๋ࠦำࠣๆฬีัࠡ฻็ํࠥอำหะาห๊ࠦวๅ็๋ห็฿ࠠศๆุ่ๆืษࠨဴ"))
	else:
		n0cw7OKbM4ruo = CCxMXuNUEzolDZTKrBJ
		if showDialogs: tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨဵ"),uVQd103XyvUce2EBtzbYaC(u"࠭ฬ๋ัࠣะิอࠠ࠯࠰࠱ࠤฬ๊วหืส่ࠥอไๆึไีࠥ࠮วๅำห฻ࠥอไๆึไี࠮ฺ๊ࠦ็็ࠤ฾์ฯไ๋ࠢห้ฮั็ษ่ะ่ࠥวะำࠣ฽้๏ࠠศีอาิอๅࠡษ็้ํอโฺࠢสฺ่๊แาหࠪံ"))
	if not n0cw7OKbM4ruo and showDialogs: DnKPbv5JXO()
	return n0cw7OKbM4ruo
def DnKPbv5JXO():
	tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,mQNonhS7CV2BXOv(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮ့ࠪ"),yST5AHEfvPmcWpwGuh2BJ(u"ࠨส฼ฺࠥอไๆ๊สๆ฾ࠦสฮฬสะࠥืศุุ่ࠢๆื้ࠠไาࠤ๏้่็ࠢฯ๋ฬุใࠡ฼ํี่ࠥวะำࠣ฽้๏ࠠศๆิฬ฼ࠦวๅ็ืๅึࠦร้๊๊ࠢฬ้ࠠๆึๆ่ฮࠦแ๋ࠢื๋ฬีษࠡษ็ฮู็๊าࠢส่ำอีสࠢห็ํี๊ࠡ฻้ำู่ࠦๅ็สࠤฬ์็ࠡฬ่ࠤๆำีࠡษ็ฬึ์วๆฮࠣ฽้๏ࠠไ๊า๎ࠥอไฦืาหึอสࠡ࡞ࡱࠤ࠶࠽࠮࠷ࠢࠣࠪࠥࠦ࠱࠹࠰࡞࠴࠲࠿࡝ࠡࠢࠩࠤࠥ࠷࠹࠯࡝࠳࠱࠸ࡣࠧး"))
	yyfh6GLPUwI7r0J1De()
	return
def lcA0mHzo1TQUIwMKZa8(pnmsJqCWIHVk2Y6xPvl9Q0Ez8r=b8Qe150xVaJsnDSv):
	AuPNC4MLr9E = CCxMXuNUEzolDZTKrBJ
	if LAQD5wEkr18bUiGaYen3J(u"ࠩࡢࡔࡗࡕࡂࡍࡇࡐࡣ္ࠬ") not in pnmsJqCWIHVk2Y6xPvl9Q0Ez8r:
		AuPNC4MLr9E = DD5cFIejQa2X4BgAu9GWPyJ3tC7
		c9Wbh7raCVlyPKqpL6GwNZz1u = QlaM6yHe0bgh58Vx3BAZD(IjZbnrBJmM2N(u"ࠪࡧࡪࡴࡴࡦࡴ်ࠪ"),UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠫำื่อࠩျ"),QTUBCcehw6qPd4x(u"ࠬหัิษ็ࠤฺ๊ใๅหࠪြ"),RRIHDFjoW9w7bSfVPhC(u"࠭ลาีส่ࠥืำศๆฬࠫွ"),HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪှ"),Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠨ้็ࠤฯื๊ะࠢฦ๊ࠥะัิๆࠣีุอไสࠢศ่๎ࠦวๅ็หี๊าࠠ࠯࠰ࠣว๊ࠦสา์าࠤศ์ࠠหำึ่๋ࠥิไๆฬࠤ๊๎ฬ้ัฬࠤๆ๐ࠠศๆหี๋อๅอࠢยࠫဿ"))
		if c9Wbh7raCVlyPKqpL6GwNZz1u in [-HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"࠱ᇾ"),P0qdZI384LKleuo(u"࠱ᇿ")]: return
		elif c9Wbh7raCVlyPKqpL6GwNZz1u==ubxGUTt1LraKhVZgpAP(u"࠳ሀ"):
			AuPNC4MLr9E = CCxMXuNUEzolDZTKrBJ
			pnmsJqCWIHVk2Y6xPvl9Q0Ez8r = mQNonhS7CV2BXOv(u"ࠩࡢࡔࡗࡕࡂࡍࡇࡐࡣࠬ၀")
	if AuPNC4MLr9E:
		if DYakr9g4PVU(u"ࠪࡣࡕࡘࡏࡃࡎࡈࡑࡤࡕࡌࡅࡡࠪ၁") not in pnmsJqCWIHVk2Y6xPvl9Q0Ez8r:
			aVwGA2kFY6u4m = BjMmX1vNrnzSAf(vvWwO3Tx2dAgcijrFXq(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ၂"),b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,ubxGUTt1LraKhVZgpAP(u"ࠬ๎ึฺࠢสฺ่๊ใๅหࠣๅ๏ࠦวๅีฯ่ࠬ၃"),Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"࠭โษๆࠣษึูวๅࠢสุ่าไࠡ฻็๎่ࠦร็ࠢอ็ึื่ࠠࠡไืࠥอไโ฻็ࠤฬ๊ะ๋ࠢฦ฽฼อใࠡษ็ู้้ไสࠢ࠱ࠤ้้๊ࠡ์อ้ࠥะำอ์็ࠤ์ึ็ࠡษ็ู้้ไสࠢไ๎ูࠥฬๅࠢส่ศิืศรࠣ์ฬ๊วิฬัำฬ๋ࠠ࠯๋ࠢฬิ๎ๆ้ࠡำหࠥอไหีฯ๎้ࠦำ้ใࠣฮึูไࠡ็็ๅ๊ࠥวࠡใสสิฯࠠๆ่๊ࠤ้หๆ่ࠢ็หࠥ๐อห๊ํࠤ฾๊้ࠡษ็ู้้ไสࠢส่ฯ๐ࠠหำํำࠥอๆหࠢส่สฮไศ฼ࠣ฽๋ํวࠡ࠰๋้ࠣࠦโๆฬࠣฬฯ้ัศำࠣห้๋ิไๆฬࠤฤ࠭၄"))
			if aVwGA2kFY6u4m!=DYakr9g4PVU(u"࠴ሁ"):
				tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,mQNonhS7CV2BXOv(u"ࠧห็ࠣษ้เวยࠢส่สืำศๆࠪ၅"),DYakr9g4PVU(u"ࠨๆ็วุ็ࠠษั๋๊ࠥะำอ์็ࠤฬ๊ๅีๅ็อࠥ็๊ࠡีฯ่ࠥอไฤะฺหฦ่ࠦศๆสืฯิฯศ็ࠣๅฬ์ࠠศๆ่ฬึ๋ฬࠡๆสࠤ๏ูสุ์฼ࠤ๊฿ัโหࠣห้๋ิไๆฬࠤํ๊วࠡฯ็๋ฬࠦไศ่ࠣห้๋ศา็ฯࠤ้อ๋ࠠ฻็้ࠥอไ฻์หࠫ၆"))
				return
	tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,ubxGUTt1LraKhVZgpAP(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ၇"),uVQd103XyvUce2EBtzbYaC(u"ࠪๅ๏ࠦวๅึสุฮࠦวๅไสำ๊ฯࠠฮษ๋่ࠥษๆࠡฬๆฮอࠦัิษ็อࠥหไ๊ࠢส่๊ฮัๆฮࠣ์ฬฺัฮࠢไ๎์อࠠศๆุ่่๊ษࠡล๋ࠤฬ๊ๅุ้๋฽ࠥ๎ลัษࠣวึีสࠡฮ๋หอࠦๅ็ࠢส่๊ฮัๆฮࠣๅสึๆࠡลๆฮอูࠦ็๊ส๊ࠥฮั๋ัๆࠤศ๊ลๅๅอีํ์๊ࠡษ็ษ๏๋๊ๅ๋ࠢฮี้ั๊ࠡ็หࠥะๆิ๋ࠣว๋ࠦวๅ็หี๊าࠠๅษࠣ๎฾๊ๅࠡษ็฾๏ฮࠧ၈"))
	search = FT2oXWtPQpVGuexmLqKN3srdzYn(header=mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠫ࡜ࡸࡩࡵࡧࠣࡥࠥࡳࡥࡴࡵࡤ࡫ࡪ࡫ࠠࠡࠢส็ฯฮࠠาีส่ฮ࠭၉"),source=QQ8pvXNcBfVkP5rRJ7o)
	if not search: return
	A4gdSTQDP2FyBIVuba85RvYqKU = search
	if AuPNC4MLr9E: type = HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠬࡖࡲࡰࡤ࡯ࡩࡲ࠭၊")
	else: type = LAQD5wEkr18bUiGaYen3J(u"࠭ࡍࡦࡵࡶࡥ࡬࡫ࠧ။")
	ip6CohvO5Tya9mFWVf3JdY1qL = a53FKP79mzt(type,A4gdSTQDP2FyBIVuba85RvYqKU,CCxMXuNUEzolDZTKrBJ,b8Qe150xVaJsnDSv,SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠧࡆࡏࡄࡍࡑ࠳ࡆࡓࡑࡐ࠱࡚࡙ࡅࡓࡕࠪ၌"),pnmsJqCWIHVk2Y6xPvl9Q0Ez8r)
	return
def HBxa6Ggn8hq():
	pnmsJqCWIHVk2Y6xPvl9Q0Ez8r = Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠨ้ำหࠥอไษำ้ห๊าࠠๅษࠣ๎ําฯࠡๆ๊ࠤศ๐ࠠิ์ิๅึ๊ࠦิฬู๎ๆࠦร๋่ࠢัฯ๎๊ศฬ࠱ࠤฬ๊ศา่ส้ั๊ࠦิฬัำ๊ࠦั้ษห฻ࠥ๎สื็ํ๊๊ࠥๅฮฬ๋๎ฬะࠠๆำไ์฾ฯฺࠠๆ์ࠤุ๐ัโำสฮࠥิวาฮํอ࠳ࠦวๅสิ๊ฬ๋ฬࠡ฼ํี๋ࠥำล๊็ࠤ฾์ࠠฤ์้ࠣาะ่๋ษอࠤฯ๋ࠠหฯ่๎้ํวࠡ฻็ํู๊ࠥาใิหฯ่ࠦๆ๊สๆ฾ࠦฮศำฯ๎ฮࠦࠢๆ๊สๆ฾ࠦืาใࠣฯฬ๊หࠣ࠰ࠣะ๊๐ูࠡษ็วุ๋วย๋ࠢห้๋วาๅสฮࠥ๎วๅื๋ีࠥ๎วๅ็ุ้ํืวห๊ࠢ๎ࠥิวึหࠣฬฬ฻อศส๊ห࠳ࠦวๅสิ๊ฬ๋ฬࠡๆสࠤ๏์ส่ๅࠣั็๎โࠡษ็฻อ฿้ࠠษ็ู๊ื้ࠠไส๊ํ์ࠠศๆฦ่ๆ๐ษࠡๆ็้้้๊สࠢส่ึ่ๅ๋หࠣࡈࡒࡉࡁࠡวำห้ࠥว็ࠢ็ำ๏้ࠠีๅ๋ํࠥิวึหࠣฬฬ๊ั้ษห฻ࠥ๎วๅฬูห๊๐ๆࠡษ็าฬืฬ๋หࠣๅฬ๊ัอษฤࠤฬ๊ส้ษุู่๋ࠥࠡวาหึฯ่ࠠา๊ࠤฬ๊ำ๋ำไีฬะ้ࠠษ็้ํอโฺࠢส่ำอัอ์ฬ࠲ࠥํะศࠢส่อืๆศ็ฯࠤ์๎ࠠษสึห฼ฯࠠๆฬุๅาࠦไๆ๊สๆ฾ࠦวๅ๊ํฬࠬ၍")
	bJvWMFh8G3eas(uVQd103XyvUce2EBtzbYaC(u"ࠩࡵ࡭࡬࡮ࡴࠨ၎"),mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠪั็๎โࠡษ็฻อ฿้ࠠษ็ู๊ื้ࠠไส๊ํ์ࠠศๆฦ่ๆ๐ษࠡๆ็้้้๊สࠢส่ึ่ๅ๋หࠪ၏"),pnmsJqCWIHVk2Y6xPvl9Q0Ez8r,HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧၐ"))
	pnmsJqCWIHVk2Y6xPvl9Q0Ez8r = Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"࡚ࠬࡨࡪࡵࠣࡴࡷࡵࡧࡳࡣࡰࠤࡩࡵࡥࡴࠢࡱࡳࡹࠦࡨࡰࡵࡷࠤࡦࡴࡹࠡࡥࡲࡲࡹ࡫࡮ࡵࠢࡲࡲࠥࡧ࡮ࡺࠢࡶࡩࡷࡼࡥࡳ࠰ࠣࡍࡹࠦ࡯࡯࡮ࡼࠤࡺࡹࡥࡴࠢ࡯࡭ࡳࡱࡳࠡࡶࡲࠤࡪࡳࡢࡦࡦࡧࡩࡩࠦࡣࡰࡰࡷࡩࡳࡺࠠࡵࡪࡤࡸࠥࡽࡡࡴࠢࡸࡴࡱࡵࡡࡥࡧࡧࠤࡹࡵࠠࡱࡱࡳࡹࡱࡧࡲࠡࡱࡱࡰ࡮ࡴࡥࠡࡸ࡬ࡨࡪࡵࠠࡩࡱࡶࡸ࡮ࡴࡧࠡࡵ࡬ࡸࡪࡹ࠮ࠡࡃ࡯ࡰࠥࡺࡲࡢࡦࡨࡱࡦࡸ࡫ࡴ࠮ࠣࡺ࡮ࡪࡥࡰࡵ࠯ࠤࡹࡸࡡࡥࡧࠣࡲࡦࡳࡥࡴ࠮ࠣࡷࡪࡸࡶࡪࡥࡨࠤࡲࡧࡲ࡬ࡵ࠯ࠤࡨࡵࡰࡺࡴ࡬࡫࡭ࡺࡥࡥࠢࡺࡳࡷࡱࠬࠡ࡮ࡲ࡫ࡴࡹࠠࡳࡧࡩࡩࡷ࡫࡮ࡤࡧࡧࠤ࡭࡫ࡲࡦ࡫ࡱࠤࡧ࡫࡬ࡰࡰࡪࠤࡹࡵࠠࡵࡪࡨ࡭ࡷࠦࡲࡦࡵࡳࡩࡨࡺࡩࡷࡧࠣࡳࡼࡴࡥࡳࡵࠣ࠳ࠥࡩ࡯࡮ࡲࡤࡲ࡮࡫ࡳ࠯ࠢࡗ࡬ࡪࠦࡰࡳࡱࡪࡶࡦࡳࠠࡪࡵࠣࡲࡴࡺࠠࡳࡧࡶࡴࡴࡴࡳࡪࡤ࡯ࡩࠥ࡬࡯ࡳࠢࡺ࡬ࡦࡺࠠࡰࡶ࡫ࡩࡷࠦࡰࡦࡱࡳࡰࡪࠦࡵࡱ࡮ࡲࡥࡩࠦࡴࡰࠢ࠶ࡶࡩࠦࡰࡢࡴࡷࡽࠥࡹࡩࡵࡧࡶ࠲ࠥ࡝ࡥࠡࡷࡵ࡫ࡪࠦࡡ࡭࡮ࠣࡧࡴࡶࡹࡳ࡫ࡪ࡬ࡹࠦ࡯ࡸࡰࡨࡶࡸ࠲ࠠࡵࡱࠣࡶࡪࡩ࡯ࡨࡰ࡬ࡾࡪࠦࡴࡩࡣࡷࠤࡹ࡮ࡥࠡ࡮࡬ࡲࡰࡹࠠࡤࡱࡱࡸࡦ࡯࡮ࡦࡦࠣࡻ࡮ࡺࡨࡪࡰࠣࡸ࡭࡯ࡳࠡࡲࡵࡳ࡬ࡸࡡ࡮ࠢࡤࡶࡪࠦ࡬ࡰࡥࡤࡸࡪࡪࠠࡴࡱࡰࡩࡼ࡮ࡥࡳࡧࠣࡩࡱࡹࡥࠡࡱࡱࠤࡹ࡮ࡥࠡࡹࡨࡦࠥࡵࡲࠡࡸ࡬ࡨࡪࡵࠠࡦ࡯ࡥࡩࡩࡪࡥࡥࠢࡤࡶࡪࠦࡦࡳࡱࡰࠤࡴࡺࡨࡦࡴࠣࡺࡦࡸࡩࡰࡷࡶࠤࡸ࡯ࡴࡦࡵ࠱ࠤࡎ࡬ࠠࡺࡱࡸࠤ࡭ࡧࡶࡦࠢࡤࡲࡾࠦ࡬ࡦࡩࡤࡰࠥ࡯ࡳࡴࡷࡨࡷࠥࡶ࡬ࡦࡣࡶࡩࠥࡩ࡯࡯ࡶࡤࡧࡹࠦࡡࡱࡲࡵࡳࡵࡸࡩࡢࡶࡨࠤࡲ࡫ࡤࡪࡣࠣࡪ࡮ࡲࡥࠡࡱࡺࡲࡪࡸࡳࠡ࠱ࠣ࡬ࡴࡹࡴࡦࡴࡶ࠲࡚ࠥࡨࡪࡵࠣࡴࡷࡵࡧࡳࡣࡰࠤ࡮ࡹࠠࡴ࡫ࡰࡴࡱࡿࠠࡢࠢࡺࡩࡧࠦࡢࡳࡱࡺࡷࡪࡸ࠮ࠨၑ")
	bJvWMFh8G3eas(TYf7Dc06PQgy1vEV9(u"࠭࡬ࡦࡨࡷࠫၒ"),SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠧࡅ࡫ࡪ࡭ࡹࡧ࡬ࠡࡏ࡬ࡰࡱ࡫࡮࡯࡫ࡸࡱࠥࡉ࡯ࡱࡻࡵ࡭࡬࡮ࡴࠡࡃࡦࡸࠥ࠮ࡄࡎࡅࡄ࠭ࠬၓ"),pnmsJqCWIHVk2Y6xPvl9Q0Ez8r,shC5qBRV2A0lZ(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫၔ"))
	return
def X1y9V2Wc0jpHP():
	tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,RRIHDFjoW9w7bSfVPhC(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬၕ"),S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠪห้ฮั็ษ่ะ๊ࠥวࠡ์ไัฺࠦิ่ษาอࠥอไหึไ๎ึูࠦ็ัࠣห้อสึษ็ࠤออไๆ๊สๆ฾ࠦวๅ็ืๅึฯ้ࠠๆ๊ิฬࠦแ๋ࠢะห้่ࠦอ๊าࠤูํวะหࠣ฾๏ืࠠึฯํัฮࠦร้่๊ࠢฯํ๊สࠢสฺ่๊วฮ์ฬࠤศ๎ࠠๆิํๅฮࠦแศ่๋ࠣีอࠠๅ่ࠣ๎ํ่แࠡษ็ีอ฽ࠠศๆุ่ๆื้ࠠๆ้ࠤ๏๎โโࠢ฼้้ࠦวๅสิ๊ฬ๋ฬࠨၖ"))
	hTxW53Qgw81()
	return
def f9OabsGvIuE():
	FSpIEkeP1D3ai4VZ5oB92zhy,eqURlBsy0m82xwA,zzi8PC6qjXNa5hBw,xVzSyEukoGicNQs18elLm,eeLwmZ4kvNHo,ShYm12ClbIHGgWJKvzsjaAf,CXrL8kUlFMJHmKWVda3YoQjEO1Beh = b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv
	lo6biSg2NR3eUB1OpEPxzyXwF8sYWI,UQxmywCKp87ic,aO3knDtUuvCA8jbFBlIG7KcT5y6m,e3Ko09qvL4 = {ddo23ZJtgcY(u"ࠫࡦ࠭ၗ"):kke1PDGRBLuY8y(u"ࠬࡧࠧၘ")},{},[],{}
	url = nTHXJIiah2qK[QQdAXWBc2GPw(u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭ၙ")][qHYIWnOZLPkrQU]
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(IiYS8Jg4da3UuDP0qr6vy,UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠧࡑࡑࡖࡘࠬၚ"),url,lo6biSg2NR3eUB1OpEPxzyXwF8sYWI,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕ࠰࡙ࡘࡇࡇࡆࡡࡕࡉࡕࡕࡒࡕ࠯࠴ࡷࡹ࠭ၛ"))
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	jLtdbeYiQHnf4SpU2MTly = jLtdbeYiQHnf4SpU2MTly.replace(kke1PDGRBLuY8y(u"ࠩࡘࡲ࡮ࡺࡥࡥࠢࡖࡸࡦࡺࡥࡴࠩၜ"),Nh0BWuiSndf(u"࡙ࠪࡘࡇࠧၝ"))
	jLtdbeYiQHnf4SpU2MTly = jLtdbeYiQHnf4SpU2MTly.replace(TYf7Dc06PQgy1vEV9(u"࡚ࠫࡴࡩࡵࡧࡧࠤࡐ࡯࡮ࡨࡦࡲࡱࠬၞ"),uVQd103XyvUce2EBtzbYaC(u"࡛ࠬࡋࠨၟ"))
	jLtdbeYiQHnf4SpU2MTly = jLtdbeYiQHnf4SpU2MTly.replace(zI3ROAZtiUq42rE9WDST68(u"࠭ࡕ࡯࡫ࡷࡩࡩࠦࡁࡳࡣࡥࠤࡊࡳࡩࡳࡣࡷࡩࡸ࠭ၠ"),RRIHDFjoW9w7bSfVPhC(u"ࠧࡖࡃࡈࠫၡ"))
	jLtdbeYiQHnf4SpU2MTly = jLtdbeYiQHnf4SpU2MTly.replace(zI3ROAZtiUq42rE9WDST68(u"ࠨࡕࡤࡹࡩ࡯ࠠࡂࡴࡤࡦ࡮ࡧࠧၢ"),yST5AHEfvPmcWpwGuh2BJ(u"ࠩࡎࡗࡆ࠭ၣ"))
	jLtdbeYiQHnf4SpU2MTly = jLtdbeYiQHnf4SpU2MTly.replace(QQdAXWBc2GPw(u"ࠪࡒࡴࡸࡴࡩࠢࡐࡥࡨ࡫ࡤࡰࡰ࡬ࡥࠬၤ"),Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠫࡓ࠴ࡍࡢࡥࡨࡨࡴࡴࡩࡢࠩၥ"))
	jLtdbeYiQHnf4SpU2MTly = jLtdbeYiQHnf4SpU2MTly.replace(P0qdZI384LKleuo(u"ࠬ࡝ࡥࡴࡶࡨࡶࡳࠦࡓࡢࡪࡤࡶࡦ࠭ၦ"),TT8Mxv5Wq7nlC9IscdpPUY6(u"࠭ࡗ࠯ࡕࡤ࡬ࡦࡸࡡࠨၧ"))
	jLtdbeYiQHnf4SpU2MTly = jLtdbeYiQHnf4SpU2MTly.replace(DYakr9g4PVU(u"ࠧࡠࡡࡢࠫၨ"),k5bCDErUSmv)
	try: uCZf2YbsNGM58gc6kItdDTXApUHPa = oJsUwXA0yGOI1mTjxQ(DYakr9g4PVU(u"ࠨ࡮࡬ࡷࡹ࠭ၩ"),jLtdbeYiQHnf4SpU2MTly)
	except:
		tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,BmePGjS7FxK6kutUM(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬၪ"),TYf7Dc06PQgy1vEV9(u"ࠪๅู๊ࠠโ์ࠣะ้ฮࠠๆฯอ์๏อสࠡฬๅี๏ืࠠศๆสืฯิฯศ็ࠪၫ"))
		return
	kDsJ9XfBhIwR6vj8C,qTZn6bLKS8uIy,BfdNDtiuOZJ46WQ5RLAorI7w23n = uCZf2YbsNGM58gc6kItdDTXApUHPa
	e3Ko09qvL4 = {}
	cKF9LHuU4ewq2RS0 = [shC5qBRV2A0lZ(u"ࠫࡈࡇࡐࡕࡅࡋࡅࡎࡊࠧၬ"),uVQd103XyvUce2EBtzbYaC(u"ࠬࡉࡁࡑࡖࡆࡌࡆ࡚ࡏࡌࡇࡑࠫၭ")]
	PGzti9gJhm = [m6hwdgP31a2zjN7lkpX(u"࠭ࡁࡍࡎࠪၮ"),vvWwO3Tx2dAgcijrFXq(u"ࠧࡑ࡛ࡗࡌࡔࡔࠧၯ"),S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠨࡋࡑࡗ࡙ࡇࡌࡍࠩၰ"),ddo23ZJtgcY(u"ࠩࡐࡉ࡙ࡘࡏࡑࡑࡏࡍࡘ࠭ၱ"),IjZbnrBJmM2N(u"ࠪࡖࡊࡖࡏࡔࠩၲ")]+cKF9LHuU4ewq2RS0+Fk2qc5asKtOQUSIo9+SmnwfjDprzZhuY
	for TFAmLfwypkzsP1UYCMr8c,pGUNokgnrF0dzmACXBKa43tsh,j54jCNzRhF7SkUa in qTZn6bLKS8uIy:
		j54jCNzRhF7SkUa = ggtn0PzV7aMe(j54jCNzRhF7SkUa)
		j54jCNzRhF7SkUa = j54jCNzRhF7SkUa.strip(pldxivXC5wbTB2O8q).strip(dDYUoKi6JFM23p(u"ࠫࠥ࠴ࠧၳ"))
		xVzSyEukoGicNQs18elLm += eeN6dTEnkJxI+OkuB9nwhD8U1+TFAmLfwypkzsP1UYCMr8c+Mmpr0o76iWJvz1kTtfgI8hES(u"ࠬࡀࠠࠨၴ")+hAIp8kmC36T5WFPMSXOwnNbtD+j54jCNzRhF7SkUa+eeN6dTEnkJxI
		if pGUNokgnrF0dzmACXBKa43tsh.isdigit():
			e3Ko09qvL4[TFAmLfwypkzsP1UYCMr8c] = int(pGUNokgnrF0dzmACXBKa43tsh)
			if int(pGUNokgnrF0dzmACXBKa43tsh)>VFjQx6Is28KvzLOmMXtg4GqTwa3(u"࠵࠵࠶ሂ"): pGUNokgnrF0dzmACXBKa43tsh = mQNonhS7CV2BXOv(u"࠭ࡨࡪࡩ࡫ࡹࡸࡧࡧࡦࠩၵ")
			else: pGUNokgnrF0dzmACXBKa43tsh = Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠧ࡭ࡱࡺࡹࡸࡧࡧࡦࠩၶ")
		if TFAmLfwypkzsP1UYCMr8c not in PGzti9gJhm:
			if   pGUNokgnrF0dzmACXBKa43tsh==uVQd103XyvUce2EBtzbYaC(u"ࠨࡪ࡬࡫࡭ࡻࡳࡢࡩࡨࠫၷ"): FSpIEkeP1D3ai4VZ5oB92zhy += k5bCDErUSmv+TFAmLfwypkzsP1UYCMr8c
			elif pGUNokgnrF0dzmACXBKa43tsh==LAQD5wEkr18bUiGaYen3J(u"ࠩ࡯ࡳࡼࡻࡳࡢࡩࡨࠫၸ"): eqURlBsy0m82xwA += k5bCDErUSmv+TFAmLfwypkzsP1UYCMr8c
	p2phveftWDKUquaA7z8yG5T,LWglNBiUjQIZOfdePxb2nKrF4EtD,MXnk82qwx5KGWPYjgbENVpH1UQfCz3 = list(zip(*qTZn6bLKS8uIy))
	for TFAmLfwypkzsP1UYCMr8c in sorted(WOXHyD1V5jBlvRSQzYtp87):
		if TFAmLfwypkzsP1UYCMr8c not in p2phveftWDKUquaA7z8yG5T:
			xVzSyEukoGicNQs18elLm += eeN6dTEnkJxI+OkuB9nwhD8U1+TFAmLfwypkzsP1UYCMr8c+SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠪ࠾ࠥ࠭ၹ")+hAIp8kmC36T5WFPMSXOwnNbtD+yST5AHEfvPmcWpwGuh2BJ(u"้ࠫอ๋๊ࠠฯำࠬၺ")+Mmpr0o76iWJvz1kTtfgI8hES(u"ࠬࡢ࡮࡝ࡰࠪၻ")
			if TFAmLfwypkzsP1UYCMr8c not in PGzti9gJhm: zzi8PC6qjXNa5hBw += k5bCDErUSmv+TFAmLfwypkzsP1UYCMr8c
	for j54jCNzRhF7SkUa,iG0zufnFdZMAqHWJtOKXaE in kDsJ9XfBhIwR6vj8C:
		j54jCNzRhF7SkUa = ggtn0PzV7aMe(j54jCNzRhF7SkUa)
		eeLwmZ4kvNHo += j54jCNzRhF7SkUa+uVQd103XyvUce2EBtzbYaC(u"࠭࠺ࠡࠩၼ")+rC3Tlno96KjLDIvBaSWUbR8+str(iG0zufnFdZMAqHWJtOKXaE)+hAIp8kmC36T5WFPMSXOwnNbtD+QTUBCcehw6qPd4x(u"ࠧࠡࠢࠣࠫၽ")
	FSpIEkeP1D3ai4VZ5oB92zhy = FSpIEkeP1D3ai4VZ5oB92zhy.strip(pldxivXC5wbTB2O8q)
	eqURlBsy0m82xwA = eqURlBsy0m82xwA.strip(pldxivXC5wbTB2O8q)
	zzi8PC6qjXNa5hBw = zzi8PC6qjXNa5hBw.strip(pldxivXC5wbTB2O8q)
	y7LeYsCOjVoltIN = FSpIEkeP1D3ai4VZ5oB92zhy+k5bCDErUSmv+eqURlBsy0m82xwA
	KZSi3W4l8QrDbUHtBFduz6  = LAQD5wEkr18bUiGaYen3J(u"ࠨ็๋ห็฿ࠠ็ฮะࠤฬ๊ศา่ส้ัࠦศหึ฽๎้ࠦแ๋ัํ์์อสࠡใํࠤ࠸ࠦร๋ษ่ࠤฬ๊ๅศุํอࠬၾ")+eeN6dTEnkJxI+BWNPxIG7vqdTy85pjHzUOrK3(u"๋๋ࠩีอࠠๆ฻้ห์ࠦลัษ่ࠣิ๐ใࠡ็ื็้ฯࠠโ้ํࠤ้๐ำห่๊ࠢࠥอไษำ้ห๊าࠧၿ")+eeN6dTEnkJxI
	KZSi3W4l8QrDbUHtBFduz6 += rC3Tlno96KjLDIvBaSWUbR8+y7LeYsCOjVoltIN+hAIp8kmC36T5WFPMSXOwnNbtD+S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠪࡠࡳࡢ࡮ࠨႀ")
	KZSi3W4l8QrDbUHtBFduz6 += HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"๊ࠫ๎วใ฻่๊๊ࠣࠦี฼็ࠤฬ๊ศา่ส้ัࠦๅ็้สࠤๆ๐ฯ๋๊๊หฯࠦแ๋ࠢ࠶ࠤศ๐วๆࠢส่๊อึ๋หࠪႁ")+eeN6dTEnkJxI+SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠬ๎็ัษ้ࠣ฾์ว่ࠢสัฯ๋วๅࠢๆฬ๏ื้ࠠฮ๋ำ๋ࠥิไๆฬࠤๆ๐ࠠศๆหี๋อๅอࠩႂ")+eeN6dTEnkJxI
	KZSi3W4l8QrDbUHtBFduz6 += rC3Tlno96KjLDIvBaSWUbR8+zzi8PC6qjXNa5hBw+hAIp8kmC36T5WFPMSXOwnNbtD
	VVsYldSgGJcKHao1qz08X2QMy,mFciYXNvoR2p8UbzGsnraf,h3ZbKxTUD5W8iLa2wjedOmqA4RlIV,bFfCwGQluo8XJcx57y = DYakr9g4PVU(u"࠵ሃ"),DYakr9g4PVU(u"࠵ሃ"),DYakr9g4PVU(u"࠵ሃ"),DYakr9g4PVU(u"࠵ሃ")
	all = e3Ko09qvL4[BmePGjS7FxK6kutUM(u"࠭ࡁࡍࡎࠪႃ")]
	if DYakr9g4PVU(u"ࠧࡑ࡛ࡗࡌࡔࡔࠧႄ") in list(e3Ko09qvL4.keys()): VVsYldSgGJcKHao1qz08X2QMy = e3Ko09qvL4[dDYUoKi6JFM23p(u"ࠨࡒ࡜ࡘࡍࡕࡎࠨႅ")]
	if UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠩࡌࡒࡘ࡚ࡁࡍࡎࠪႆ") in list(e3Ko09qvL4.keys()): mFciYXNvoR2p8UbzGsnraf = e3Ko09qvL4[m6hwdgP31a2zjN7lkpX(u"ࠪࡍࡓ࡙ࡔࡂࡎࡏࠫႇ")]
	if Mmpr0o76iWJvz1kTtfgI8hES(u"ࠫࡒࡋࡔࡓࡑࡓࡓࡑࡏࡓࠨႈ") in list(e3Ko09qvL4.keys()): h3ZbKxTUD5W8iLa2wjedOmqA4RlIV = e3Ko09qvL4[mQNonhS7CV2BXOv(u"ࠬࡓࡅࡕࡔࡒࡔࡔࡒࡉࡔࠩႉ")]
	if dDYUoKi6JFM23p(u"࠭ࡒࡆࡒࡒࡗࠬႊ") in list(e3Ko09qvL4.keys()): bFfCwGQluo8XJcx57y = e3Ko09qvL4[TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠧࡓࡇࡓࡓࡘ࠭ႋ")]
	O3tFXpzJV6RUh72D9sAElNkKfPL = all-VVsYldSgGJcKHao1qz08X2QMy-mFciYXNvoR2p8UbzGsnraf-h3ZbKxTUD5W8iLa2wjedOmqA4RlIV-bFfCwGQluo8XJcx57y
	jprAaOYCD6yM8P5VZXK1B2ldNbuR,CJ0bPcDWqw8kshMjtuUYOTzyL = BfdNDtiuOZJ46WQ5RLAorI7w23n[LzYQg91SIxDeOGtCKd5]
	jprAaOYCD6yM8P5VZXK1B2ldNbuR,h9so6FGOCTBfbjSPH = BfdNDtiuOZJ46WQ5RLAorI7w23n[qHYIWnOZLPkrQU]
	KO6jc5Di0JT492xvRMFYou3LW = CJ0bPcDWqw8kshMjtuUYOTzyL-h9so6FGOCTBfbjSPH
	CXrL8kUlFMJHmKWVda3YoQjEO1Beh += OkuB9nwhD8U1+str(h9so6FGOCTBfbjSPH)+hAIp8kmC36T5WFPMSXOwnNbtD+uVQd103XyvUce2EBtzbYaC(u"ࠨษ็฽ิีࠠศๆะๆ๏่๊ࠡๆ็วัําสࠢ࠽ࠤࠬႌ")
	CXrL8kUlFMJHmKWVda3YoQjEO1Beh += eeN6dTEnkJxI+OkuB9nwhD8U1+str(KO6jc5Di0JT492xvRMFYou3LW)+hAIp8kmC36T5WFPMSXOwnNbtD+mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠩหหุะฮะษ่ࠤࡵࡸ࡯ࡹࡻࠣวํࠦࡶࡱࡰࠣ࠾ႍࠥ࠭")
	CXrL8kUlFMJHmKWVda3YoQjEO1Beh += eeN6dTEnkJxI+OkuB9nwhD8U1+str(CJ0bPcDWqw8kshMjtuUYOTzyL)+hAIp8kmC36T5WFPMSXOwnNbtD+shC5qBRV2A0lZ(u"ࠪห้฿ฯะࠢส่่๊๊ࠡๆฯ้๏฿ࠠศๆฦะ์ุษࠡ࠼ࠣࠫႎ")
	CXrL8kUlFMJHmKWVda3YoQjEO1Beh += eeN6dTEnkJxI+OkuB9nwhD8U1+str(len(BfdNDtiuOZJ46WQ5RLAorI7w23n[ddo23ZJtgcY(u"࠸ሄ"):]))+hAIp8kmC36T5WFPMSXOwnNbtD+Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠫ฾ีฯࠡษ็ำํ๊ࠠศๆอ๎ࠥ็๊่ษࠣวัําสࠢ࠽ࠤࡡࡴ࡜࡯ࠩႏ")
	for dHf3gSt5yWFKhPjZRN16iqeoc7O,y9i63b5jQSGqUsfguZxPkTK in BfdNDtiuOZJ46WQ5RLAorI7w23n[SbjiWeHLQPoazqwp3cODkd7YxVgn(u"࠲ህ"):]:
		dHf3gSt5yWFKhPjZRN16iqeoc7O = ggtn0PzV7aMe(dHf3gSt5yWFKhPjZRN16iqeoc7O)
		dHf3gSt5yWFKhPjZRN16iqeoc7O = dHf3gSt5yWFKhPjZRN16iqeoc7O.strip(pldxivXC5wbTB2O8q).strip(kke1PDGRBLuY8y(u"ࠬࠦ࠮ࠨ႐"))
		CXrL8kUlFMJHmKWVda3YoQjEO1Beh += dHf3gSt5yWFKhPjZRN16iqeoc7O+TYf7Dc06PQgy1vEV9(u"࠭࠺ࠡࠩ႑")+rC3Tlno96KjLDIvBaSWUbR8+str(y9i63b5jQSGqUsfguZxPkTK)+hAIp8kmC36T5WFPMSXOwnNbtD+mQNonhS7CV2BXOv(u"ࠧࠡࠢࠣࠫ႒")
	ShYm12ClbIHGgWJKvzsjaAf += OkuB9nwhD8U1+str(O3tFXpzJV6RUh72D9sAElNkKfPL)+hAIp8kmC36T5WFPMSXOwnNbtD+shC5qBRV2A0lZ(u"ࠨใํำ๏๎็ศฬࠣหูะฺๅฬࠣ࠾ࠥ࠭႓")
	ShYm12ClbIHGgWJKvzsjaAf += eeN6dTEnkJxI+OkuB9nwhD8U1+str(VVsYldSgGJcKHao1qz08X2QMy)+hAIp8kmC36T5WFPMSXOwnNbtD+Xz3bA2PFENVCUtplu51(u"ฺ่ࠩออสࠡีํีๆืࠠษษํฯํ์ࠠ࠻ࠢࠪ႔")
	ShYm12ClbIHGgWJKvzsjaAf += eeN6dTEnkJxI+OkuB9nwhD8U1+str(bFfCwGQluo8XJcx57y)+hAIp8kmC36T5WFPMSXOwnNbtD+VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠪ฻้ฮวหࠢึ๎ึ็ัࠡษ็ุ้ะ่ะ฻ࠣ࠾ࠥ࠭႕")
	ShYm12ClbIHGgWJKvzsjaAf += eeN6dTEnkJxI+OkuB9nwhD8U1+str(mFciYXNvoR2p8UbzGsnraf)+hAIp8kmC36T5WFPMSXOwnNbtD+SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠫฯัศ๋ฬࠣฮ฼ฮ๊ใࠢๆ์ิ๐ฺࠠ็สำࠥࡀࠠࠨ႖")
	ShYm12ClbIHGgWJKvzsjaAf += eeN6dTEnkJxI+OkuB9nwhD8U1+str(h3ZbKxTUD5W8iLa2wjedOmqA4RlIV)+hAIp8kmC36T5WFPMSXOwnNbtD+UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠬะหษ์อࠤั๊ฯࠡ็อีํฮ่ๅีࠣ฽๊อฯࠡ࠼ࠣࠫ႗")
	ShYm12ClbIHGgWJKvzsjaAf += eeN6dTEnkJxI+OkuB9nwhD8U1+str(len(kDsJ9XfBhIwR6vj8C))+hAIp8kmC36T5WFPMSXOwnNbtD+Mmpr0o76iWJvz1kTtfgI8hES(u"࠭ฯ้ๆุࠣ฿๊สࠡใํำ๏๎็ศฬࠣ࠾ࠥ࠭႘")
	ShYm12ClbIHGgWJKvzsjaAf += RRIHDFjoW9w7bSfVPhC(u"ࠧ࡝ࡰ࡟ࡲࠬ႙")+eeLwmZ4kvNHo
	bJvWMFh8G3eas(TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨႚ"),Mmpr0o76iWJvz1kTtfgI8hES(u"ࠩ฼ำิࠦวๅลฯ๋ืฯࠠศๆอ๎ࠥอำหะา้ฯࠦ็ัษࠣห้ฮั็ษ่ะࠥ็๊ࠡ࠵ࠣว๏อๅࠡษ็้ฬ฼๊สࠢไ๎ࠥอไฺษ็้้ࠥไ่ࠩႛ"),CXrL8kUlFMJHmKWVda3YoQjEO1Beh,QQdAXWBc2GPw(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭ႜ"))
	bJvWMFh8G3eas(HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫႝ"),shC5qBRV2A0lZ(u"ࠬ฿ฯะࠢส่ๆ๐ฯ๋๊๊หฯࠦวๅฬํࠤูเไ่ษ๋ࠣีอࠠศๆหี๋อๅอࠢไ๎ࠥ࠹ࠠฤ์ส้ࠥอไๆษู๎ฮࠦแ๋ࠢส่฾อไๆࠢๆ่์࠭႞"),ShYm12ClbIHGgWJKvzsjaAf,LAQD5wEkr18bUiGaYen3J(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩ႟"))
	bJvWMFh8G3eas(TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠧࡤࡧࡱࡸࡪࡸࠧႠ"),RRIHDFjoW9w7bSfVPhC(u"ࠨ็๋ห็฿ࠠศึอ฾้ะࠠโ์ࠣ࠷ࠥษ๊ศ็ࠣห้๋วื์ฬࠤๆ๐ࠠศๆ฼ห้๋ࠠไๆ๊ࠫႡ"),KZSi3W4l8QrDbUHtBFduz6,dDYUoKi6JFM23p(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬႢ"))
	bJvWMFh8G3eas(SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠪࡰࡪ࡬ࡴࠨႣ"),uVQd103XyvUce2EBtzbYaC(u"ࠫศ฿ไ๊ࠢส่ิ๎ไࠡษ็ฮ๏ࠦแ๋ࠢ࠶ࠤศ๐วๆࠢส่๊อึ๋หࠣหุะฮะ็อࠤฬ๊ศา่ส้ั࠭Ⴄ"),xVzSyEukoGicNQs18elLm,TYf7Dc06PQgy1vEV9(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࡠ࡮ࡲࡲ࡬࠭Ⴅ"))
	return
def pD8yINQe2T3qZ4tvlX():
	A4gdSTQDP2FyBIVuba85RvYqKU = Mmpr0o76iWJvz1kTtfgI8hES(u"࠭็ัษࠣห้ฮั็ษ่ะࠥ๐ูๆๆࠣหๆ฼ไࠡสสืฯิฯศ็ࠣะ้ีࠠไ๊า๎ࠥ࠮ࡋࡰࡦ࡬ࠤࡘࡱࡩ࡯ࠫࠣห้ึ๊ࠡษึ้์ࡢ࡮ࠨႦ")+OkuB9nwhD8U1+VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭Ⴇ")+hAIp8kmC36T5WFPMSXOwnNbtD+TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠨ࡞ࡱࡠࡳࡢ࡮๊่้่ࠡ์ࠠหอห๎ฯํࠠษษึฮำีวๆ่ࠢืฯ๎ฯฺࠢ฼้ฬีࠠࡆࡏࡄࡈࠥࡘࡥࡱࡱࡶ࡭ࡹࡵࡲࡺࠢฦ์ࠥะอๆ์็๋๋ࠥๆ࡝ࡰࠪႨ")+OkuB9nwhD8U1+Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡲࡦࡲࡲ࠲ࡺࡱ࠮ࡵࡱࠪႩ")+hAIp8kmC36T5WFPMSXOwnNbtD+ubxGUTt1LraKhVZgpAP(u"ࠪࡠࡳࡢ࡮࡝ࡰ๋ࠣีํࠠศๆิืฬ๊ษ๊ࠡ฽๎ึํวࠡๅฮ๎ึࠦๅ้ฮ๋ำฮࠦแ๋ࠢๅหห๋ษࠡะา้ฬะࠠศๆหี๋อๅอ๋ࠢห้๋า๋ัࠣว๏฼วࠡ็๋ะํีࠠโ์ࠣๆฬฬๅสࠢฦะํฮษࠡษ็ฬึ์วๆฮࠪႪ")
	bJvWMFh8G3eas(RRIHDFjoW9w7bSfVPhC(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫႫ"),BWNPxIG7vqdTy85pjHzUOrK3(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨႬ"),A4gdSTQDP2FyBIVuba85RvYqKU,ubxGUTt1LraKhVZgpAP(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩႭ"))
	return
def KMHWjelkc5I():
	A4gdSTQDP2FyBIVuba85RvYqKU = QQdAXWBc2GPw(u"ࠧศๆิหอ฽๊็ࠢฦำ๋อ็ࠡใํ๋๊อࠠหูห๎็ࠦใ้ัํࠤ฾๋วะ๋๋ࠢํูࠦษษิอࠥ฿ๆࠡฬฮฬ๏ะࠠไษ่่ࠥอ่ห๊่หฯ๐ใ๋ࠢ็ฬึ์วๆฮࠣ็ํี๊๊่ࠡ฽์ࠦวืษไอࠥ฿ๅศั่้ࠣ็๊ะ์๋๋ฬะࠠศๆ฼ีอ๐ษ๊่ࠡ฽์ࠦวืษไอࠥาไะ่ࠢฮึ๎ศ้ๆึࠤ฾๋วะ๋้ࠢ฾ํࠠศุสๅฮࠦๅิฬ๋ำ฾ูࠦๆษาࠤํ็๊่ࠢฦ๎฻อࠠอ็ํ฽ࠥอูะษาฮ้่ࠥะ์ࠣห้๋ืๅ๊หอู๊ࠥๆๆࠣฬึ์วๆฮࠣ฽๊อฯ๊ࠡๆ่์อࠠหฬ่ࠤฬ๎ส้็สฮ๏้๊ศ๋่ࠢฬࠦสฮฬสะࠥษ๊่๋ࠡ฽๋ࠥๆࠡษ็าอืษࠡใํࠤ่๎ฯ๋ࠢฦ์ࠥอไฯสิอࠥ็๊ࠡฬฮฬ๏ะࠠฤุสๅฬะࠠไ๊า๎ࠬႮ")+eeN6dTEnkJxI+rC3Tlno96KjLDIvBaSWUbR8+nTHXJIiah2qK[P0qdZI384LKleuo(u"ࠨࡍࡒࡈࡎࡋࡍࡂࡆࡢࡅࡕࡖࠧႯ")][LzYQg91SIxDeOGtCKd5]+hAIp8kmC36T5WFPMSXOwnNbtD+mQNonhS7CV2BXOv(u"ࠩࠣࠤࠥࠦࠠࠡล๋ࠤࠥࠦࠠࠡࠢࠪႰ")+rC3Tlno96KjLDIvBaSWUbR8+nTHXJIiah2qK[BmePGjS7FxK6kutUM(u"ࠪࡏࡔࡊࡉࡆࡏࡄࡈࡤࡇࡐࡑࠩႱ")][qHYIWnOZLPkrQU]+hAIp8kmC36T5WFPMSXOwnNbtD
	A4gdSTQDP2FyBIVuba85RvYqKU += ddo23ZJtgcY(u"ࠫࡡࡴ࡜࡯࡞ࡱห้ืวษูࠣวิ์ว่๊ࠢ์ࠥอไิ๊ิืࠥอไั์ࠣ๎าะวอ้้ࠣิ๐ัࠡ็็ๅฬะࠠไ๊า๎๊ࠥสฬสํฮࠥฮั็ษ่ะࠥ฿ๅศัࠣฬฬ๊ืา์ๅอࠥอไหไ็๎ิ๐ษࠡษ็ๆิ๐ๅส࡞ࡱࠫႲ")+rC3Tlno96KjLDIvBaSWUbR8+nTHXJIiah2qK[UUkIBz1sgQ9WfNeG6trKXvu0(u"࡙ࠬࡏࡖࡔࡆࡉࡘ࠭Ⴓ")][qHYIWnOZLPkrQU]+hAIp8kmC36T5WFPMSXOwnNbtD
	A4gdSTQDP2FyBIVuba85RvYqKU += kke1PDGRBLuY8y(u"࠭࡜࡯࡞ࡱࡠࡳาๅ๋฻้้ࠣ็วหࠢ฼้ฬีࠠๆ๊ฯ์ิฯࠠโ์ࠣห้๋่ใ฻ࠣวิ์ว่ࠩႴ")+eeN6dTEnkJxI+rC3Tlno96KjLDIvBaSWUbR8+nTHXJIiah2qK[mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠧࡔࡑࡘࡖࡈࡋࡓࠨႵ")][IgQimel18t]+hAIp8kmC36T5WFPMSXOwnNbtD
	bJvWMFh8G3eas(Xz3bA2PFENVCUtplu51(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨႶ"),Nh0BWuiSndf(u"ࠩส่๊๎วใ฻ࠣห้ืำๆ์ฬࠤ้ฮั็ษ่ะࠥ฿ๅศั่้ࠣ็๊ะ์๋๋ฬะࠠศๆ฼ีอ๐ษࠨႷ"),A4gdSTQDP2FyBIVuba85RvYqKU,TYf7Dc06PQgy1vEV9(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭Ⴘ"))
	return
def sn1dEKqwSJP5Nypj8D6ivoQYHc0(U8bcwul3GzXiavJH0oYkryAeTq):
	uuxVm0bTwdnCUAL4s6NKHEBF3M.executebuiltin(m6hwdgP31a2zjN7lkpX(u"ࠫࡆࡪࡤࡰࡰ࠱ࡓࡵ࡫࡮ࡔࡧࡷࡸ࡮ࡴࡧࡴࠪࠪႹ")+U8bcwul3GzXiavJH0oYkryAeTq+DYakr9g4PVU(u"ࠬ࠯ࠧႺ"), CCxMXuNUEzolDZTKrBJ)
	return
def Bah3px6DHs04w():
	Ljkr2F3IQgNn8v6(BWNPxIG7vqdTy85pjHzUOrK3(u"࠭ࡳࡵࡱࡳࠫႻ"))
	uuxVm0bTwdnCUAL4s6NKHEBF3M.executebuiltin(m6hwdgP31a2zjN7lkpX(u"ࠢࡂࡥࡷ࡭ࡻࡧࡴࡦ࡙࡬ࡲࡩࡵࡷࠩࡋࡱࡸࡪࡸࡦࡢࡥࡨࡗࡪࡺࡴࡪࡰࡪࡷ࠮ࠨႼ"))
	return
def OOgUL1YPxskvi5WT2wn0acuQj():
	uuxVm0bTwdnCUAL4s6NKHEBF3M.executebuiltin(SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠨࡃࡧࡨࡴࡴ࠮ࡐࡲࡨࡲࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠮ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠯ࠧႽ"), CCxMXuNUEzolDZTKrBJ)
	return
def YvG9ESojmWCUZ54Lq7bif():
	tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,TYf7Dc06PQgy1vEV9(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬႾ"),kke1PDGRBLuY8y(u"ู่๊ࠪอࠡ็ะฮํ๐วหࠢๅหห๋ษࠡ࠰ࠣหีํศࠡว็ํࠥอไใษษ้ฮࠦวๅฬํࠤฯื๊ะ่ࠢืาํว๊ࠡ็หࠥะฯฯๆࠣษ้๐็ศ๋่่ࠢ์ࠠษษึฮำีวๆࠢࠥห้๋ว้ีࠥࠤศ๎ࠠࠣษ็ี๏๋่หࠤࠣห฻เืࠡ฻็ํࠥอไำำࠣะ์ฯࠠศๆํ้๏์ࠠฤ๊ࠣหุะฮะ็ࠣࠦฬ๊ใ๋ส๋ีิࠨ้ࠠษู฾฼ูࠦๅ๋ࠣัึ็ࠠࠣࡅࠥࠤศ๎ฺࠠๆ์ࠤฬ฼ฺุࠢ฼่๎ࠦาาࠢࠥห้่วว็ฬࠦࠥอไั์ࠣๅ๏ࠦฬ่หࠣห้๐ๅ๋่ࠪႿ"))
	return
def r2P9ci76sKGM80OQhUzqTn():
	tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,kke1PDGRBLuY8y(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧჀ"),TYf7Dc06PQgy1vEV9(u"๊ࠬไห฻ส้้ࠦๅฺࠢส่๊็ึๅหࠣ࠲ࠥอะ่สࠣษ้๏ࠠศๆิหอ฽ࠠศๆำ๎ࠥะั๋ัࠣษ฻อแห้ࠣวํࠦๅิฯ๊ࠤ๊์ࠠࠡไสส๊ฯࠠศๆ่ๅ฻๊ษ๊ࠡ็็๋ࠦไศࠢอ๊็ืฺࠠๆํ๋ࠥ๎ไศࠢอุ฿๊็ࠡ࠰ࠣ์ออำหะาห๊ࠦࠢศๆ่หํูࠢࠡล๋ࠤࠧอไา์่์ฯࠨࠠศุ฽฻ࠥ฿ไ๊ࠢส่ืืࠠอ้ฬࠤฬ๊๊ๆ์้ࠤ࠳่ࠦฤ็สࠤออำหะาห๊ࠦࠢศๆๆ๎อ๎ัะࠤࠣๅฬ฼ฺุࠢ฼่๎ࠦอาใࠣࠦࡈࠨࠠฤ๊ࠣ฽้๏ࠠำำࠣࠦฬ๊โศศ่อࠧࠦวๅาํࠤๆ๐ࠠอ้ฬࠤฬ๊๊ๆ์้ࠤ࠳่ࠦ็ใึࠤฬ๊ใๅษ่ࠤํอไุำํๆฮูࠦ็ัࠣห้ะูศ็็ࠤ๊฿ࠠๆฯอ์๏อสࠡไ๋หห๋ࠠศๆ่ๅ฻๊ษࠨჁ"))
	return
def xekZcFabtTw(IkmYl8b0TcPwsp2nAjWFJ16Q=DYakr9g4PVU(u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈࠬჂ"),showDialogs=CCxMXuNUEzolDZTKrBJ):
	autQ6O2JANPLKyk3Y = uuxVm0bTwdnCUAL4s6NKHEBF3M.executeJSONRPC(Nh0BWuiSndf(u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡓࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡉࡨࡸࡘ࡫ࡴࡵ࡫ࡱ࡫࡛ࡧ࡬ࡶࡧࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡵࡨࡸࡹ࡯࡮ࡨࠤ࠽ࠦࡱࡵ࡯࡬ࡣࡱࡨ࡫࡫ࡥ࡭࠰ࡶ࡯࡮ࡴࠢࡾࡿࠪჃ"))
	data = AFIDMBehNx5QH6g21E8kq9JzrLi.loads(autQ6O2JANPLKyk3Y)
	l0jcdGgYXJR = data[Mmpr0o76iWJvz1kTtfgI8hES(u"ࠨࡴࡨࡷࡺࡲࡴࠨჄ")][TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠩࡹࡥࡱࡻࡥࠨჅ")]
	if hDTluNxe7tCwrpqXHzdEcYRfbs: l0jcdGgYXJR = l0jcdGgYXJR.encode(OVauxZzLI10vcXT74K)
	if showDialogs:
		aVwGA2kFY6u4m = BjMmX1vNrnzSAf(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭჆"),mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠫ์๊ࠠหำํำࠥะฺ๋์ิࠤั๊ฯࠡࠩჇ")+l0jcdGgYXJR+uVQd103XyvUce2EBtzbYaC(u"ࠬࠦวๅาํࠤู๊สฯั่ࠤฬ๊ย็ࠢไ๎้่ࠥะ์ࠣษ้๏ࠠศๆศูิอัࠡษ็วำ๐ัࠡๆฯ่ิࠦࠧ჈")+IkmYl8b0TcPwsp2nAjWFJ16Q+HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"࠭ࠠภࠣࠪ჉"))
		if aVwGA2kFY6u4m!=kke1PDGRBLuY8y(u"࠲ሆ"): return DD5cFIejQa2X4BgAu9GWPyJ3tC7
	ip6CohvO5Tya9mFWVf3JdY1qL,SrZcYwJuohQlLWntPGTEbADFeC7,ODIVtf7zgp03bHA4UuT = S6lDdjHGs9mQhwpzZU(IkmYl8b0TcPwsp2nAjWFJ16Q,DD5cFIejQa2X4BgAu9GWPyJ3tC7,DD5cFIejQa2X4BgAu9GWPyJ3tC7)
	if ip6CohvO5Tya9mFWVf3JdY1qL:
		if showDialogs: tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ჊"),Xz3bA2PFENVCUtplu51(u"ࠨฬ่ฮࠥ฿ๅๅ์ฬࠤฯัศ๋ฬࠣห้าไะࠢส่ัี๊ะ๋๋ࠢํࠦฬศ้ีࠤ้๊วิฬัำฬ๋ࠠ࠯ࠢึ์ๆ๊ࠦห็ࠣห้ศๆࠡฬ฽๎๏ืࠠฦ฻าหิอสࠡๅ๋ำ๏ࠦไไ์ࠣ๎ุะูๆๆࠣห้าไะࠢส่ัี๊ะࠢหำ้อࠠๆ่ࠣห้่ฯ๋็ࠪ჋"))
		wnsCBgrI9EJtPdyYp3T7bocXF = uuxVm0bTwdnCUAL4s6NKHEBF3M.executeJSONRPC(Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡕࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡗࡪࡺࡓࡦࡶࡷ࡭ࡳ࡭ࡖࡢ࡮ࡸࡩࠧ࠲ࠢࡪࡦࠥ࠾࠶࠲ࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡷࡪࡺࡴࡪࡰࡪࠦ࠿ࠨ࡬ࡰࡱ࡮ࡥࡳࡪࡦࡦࡧ࡯࠲ࡸࡱࡩ࡯ࠤ࠯ࠦࡻࡧ࡬ࡶࡧࠥ࠾ࠧ࠭჌")+IkmYl8b0TcPwsp2nAjWFJ16Q+LAQD5wEkr18bUiGaYen3J(u"ࠪࠦࢂࢃࠧჍ"))
		ip6CohvO5Tya9mFWVf3JdY1qL = CCxMXuNUEzolDZTKrBJ if QTUBCcehw6qPd4x(u"ࠫࡔࡑࠧ჎") in wnsCBgrI9EJtPdyYp3T7bocXF else DD5cFIejQa2X4BgAu9GWPyJ3tC7
		wLQCTr5lqbsVYeAHdzfhZ1F.sleep(TYf7Dc06PQgy1vEV9(u"࠳ሇ"))
		uuxVm0bTwdnCUAL4s6NKHEBF3M.executebuiltin(Nh0BWuiSndf(u"࡙ࠬࡥ࡯ࡦࡆࡰ࡮ࡩ࡫ࠩ࠳࠴࠭ࠬ჏"))
	elif showDialogs: tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,BWNPxIG7vqdTy85pjHzUOrK3(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩა"),LAQD5wEkr18bUiGaYen3J(u"ࠧๅๆฦืๆࠦแีๆอࠤ฾๋ไ๋หࠣฮะฮ๊ห๋ࠢฮๆ฿๊ๅࠢส่ั๊ฯࠡษ็้฼๊่ษࠩბ"))
	return ip6CohvO5Tya9mFWVf3JdY1qL
def yyfh6GLPUwI7r0J1De():
	url = SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡯࡬ࡶࡷࡵࡲࡴ࠰࡮ࡳࡩ࡯࠮ࡵࡸ࠲ࡶࡪࡲࡥࡢࡵࡨࡷ࠴ࡽࡩ࡯ࡦࡲࡻࡸ࠵ࡷࡪࡰ࠹࠸࠴࠭გ")
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠩࡊࡉ࡙࠭დ"),url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗ࠲࡙ࡈࡐ࡙ࡢࡐࡆ࡚ࡅࡔࡖࡢࡏࡔࡊࡉࡠࡘࡈࡖࡘࡏࡏࡏ࠯࠴ࡷࡹ࠭ე"))
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	bWGTSx5elJP7khV4 = YYBlm36zd0Jst18LXwo4.findall(Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠫࡹ࡯ࡴ࡭ࡧࡀࠦࡰࡵࡤࡪ࠯ࠫࡠࡩ࠱࡜࠯࡞ࡧ࠯࠲ࡡࡡ࠮ࡼࡄ࠱࡟ࡣࠫࠪ࠯ࠪვ"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	bWGTSx5elJP7khV4 = bWGTSx5elJP7khV4[LzYQg91SIxDeOGtCKd5].split(Nh0BWuiSndf(u"ࠬ࠳ࠧზ"))[LzYQg91SIxDeOGtCKd5]
	glFIPQ5sLV2rWeKpawvHt = str(g1gmkxOtc2oeEZHhBiy)
	xVzSyEukoGicNQs18elLm = dDYUoKi6JFM23p(u"࡛࠭ࡓࡖࡏࡡส฻ฯศำࠣ็ํี๊ࠡษ็วำ๐ัࠡษ็้ฯ๎แาࠢส่ว์่๊ࠠࠣ࠾ࠥࠦࠠࠨთ")+OkuB9nwhD8U1+bWGTSx5elJP7khV4+hAIp8kmC36T5WFPMSXOwnNbtD
	xVzSyEukoGicNQs18elLm += VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠧ࡝ࡰ࡟ࡲࠬი")+TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠨ࡝ࡕࡘࡑࡣลึัสี้่ࠥะ์ࠣห้ึ๊ࠡษ้ฮࠥะำหะา้์ࠦ็้ࠢ࠽ࠤࠥࠦࠧკ")+OkuB9nwhD8U1+glFIPQ5sLV2rWeKpawvHt+hAIp8kmC36T5WFPMSXOwnNbtD
	tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,zI3ROAZtiUq42rE9WDST68(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬლ"),xVzSyEukoGicNQs18elLm)
	return
def FItk8GQb9dWfH0Bh6():
	YwnJ4kDv5ioZBMj6tIgKWR0u7hST,x8s641FwaJRc7m,ZeonTQqXsulgpUfYha1vS2K8I = DD5cFIejQa2X4BgAu9GWPyJ3tC7,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv
	J5XjHOYq7WGDT,wioYva1L3z,eOraCjXd5KyukH = DD5cFIejQa2X4BgAu9GWPyJ3tC7,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv
	kBjDnsUC8y4 = [TYf7Dc06PQgy1vEV9(u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨმ"),BmePGjS7FxK6kutUM(u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠭ნ"),ddo23ZJtgcY(u"ࠬࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇࠫო")]
	EJcfC7seYxiG = YqPryjvitICmH(kBjDnsUC8y4)
	for DFUIv2KGj9ke in kBjDnsUC8y4:
		if DFUIv2KGj9ke not in list(EJcfC7seYxiG.keys()): continue
		mEvj8WVaX6fNFD4eCdgtn5,ww5RBJWz8japXAlCYqSxgEf0NFVK7G,FNqXBKMYgCPe6itk59AwTnOr1,p7zHTPBakINxtG3ylXjAwvKfEDS,l75ag8db26Iy04u1LmYRxfWH,i7dhFEmQycVr5qj6sNzl4BO01uGvUe,kPfXiCJtG3HZympedv1N0LA = EJcfC7seYxiG[DFUIv2KGj9ke]
		if DFUIv2KGj9ke==IjZbnrBJmM2N(u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫპ"):
			J5XjHOYq7WGDT = mEvj8WVaX6fNFD4eCdgtn5
			wioYva1L3z = ww5RBJWz8japXAlCYqSxgEf0NFVK7G+ubxGUTt1LraKhVZgpAP(u"ࠧࠡࠢࠣࠤ࠭ࠦࠧჟ")+OJ5kiNTSpIdCco0H(i7dhFEmQycVr5qj6sNzl4BO01uGvUe)+dDYUoKi6JFM23p(u"ࠨࠢࠬࠫრ")
			eOraCjXd5KyukH = p7zHTPBakINxtG3ylXjAwvKfEDS
		elif DFUIv2KGj9ke==QQdAXWBc2GPw(u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧࠫს"):
			YwnJ4kDv5ioZBMj6tIgKWR0u7hST = YwnJ4kDv5ioZBMj6tIgKWR0u7hST or mEvj8WVaX6fNFD4eCdgtn5
			x8s641FwaJRc7m += DYakr9g4PVU(u"ࠪࠤࠥ࠲ࠠࠡࠩტ")+ww5RBJWz8japXAlCYqSxgEf0NFVK7G+zI3ROAZtiUq42rE9WDST68(u"ࠫࠥࠦࠠࠡࠪࠣࠫუ")+OJ5kiNTSpIdCco0H(i7dhFEmQycVr5qj6sNzl4BO01uGvUe)+Mmpr0o76iWJvz1kTtfgI8hES(u"ࠬࠦࠩࠨფ")
			ZeonTQqXsulgpUfYha1vS2K8I += Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"࠭ࠠࠡ࠮ࠣࠤࠬქ")+p7zHTPBakINxtG3ylXjAwvKfEDS
		elif DFUIv2KGj9ke==m6hwdgP31a2zjN7lkpX(u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭ღ"):
			ya8NnWPzBjLlcDFS6mUCOwK = mEvj8WVaX6fNFD4eCdgtn5
			eegGhoR5lPFMbnI7VjXqQKiLWuf = ww5RBJWz8japXAlCYqSxgEf0NFVK7G+UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠨࠢࠣࠤࠥ࠮ࠠࠨყ")+OJ5kiNTSpIdCco0H(i7dhFEmQycVr5qj6sNzl4BO01uGvUe)+vvWwO3Tx2dAgcijrFXq(u"ࠩࠣ࠭ࠬშ")
			gcsIObSG0wZ9uozYX7BlJHxUM3 = p7zHTPBakINxtG3ylXjAwvKfEDS
	x8s641FwaJRc7m = x8s641FwaJRc7m.strip(BmePGjS7FxK6kutUM(u"ࠪࠤࠥ࠲ࠠࠡࠩჩ"))
	ZeonTQqXsulgpUfYha1vS2K8I = ZeonTQqXsulgpUfYha1vS2K8I.strip(BWNPxIG7vqdTy85pjHzUOrK3(u"ࠫࠥࠦࠬࠡࠢࠪც"))
	uvA8ymg3UDos17pckI  = BmePGjS7FxK6kutUM(u"ࠬࡡࡒࡕࡎࡠห้หีะษิࠤฬ๊รฯ์ิࠤ้ฮั็ษ่ะࠥ฿ๅศัࠣห้๋ส้ใิࠤฬ๊ย็๊ࠢ์ࠥࡀࠠࠡࠢࠪძ")+OkuB9nwhD8U1+eOraCjXd5KyukH+hAIp8kmC36T5WFPMSXOwnNbtD
	uvA8ymg3UDos17pckI += eeN6dTEnkJxI+mmcNLrXtzfpyCkZlvK5VwG2gujh(u"࡛࠭ࡓࡖࡏࡡฬ๊ลึัสีࠥอไั์ࠣห๋ะࠠหีอาิ๋็ࠡๆหี๋อๅอࠢ฼้ฬี่๊ࠠࠣ࠾ࠥࠦࠠࠨწ")+OkuB9nwhD8U1+wioYva1L3z+hAIp8kmC36T5WFPMSXOwnNbtD
	uvA8ymg3UDos17pckI += uVQd103XyvUce2EBtzbYaC(u"ࠧ࡝ࡰ࡟ࡲࠬჭ")+dDYUoKi6JFM23p(u"ࠨ࡝ࡕࡘࡑࡣวๅวุำฬืࠠศๆฦา๏ืࠠๅ็ึฮํีูࠡ฻่หิࠦวๅ็อ์ๆืࠠศๆล๊ࠥํ่ࠡ࠼ࠣࠤࠥ࠭ხ")+OkuB9nwhD8U1+ZeonTQqXsulgpUfYha1vS2K8I+hAIp8kmC36T5WFPMSXOwnNbtD
	uvA8ymg3UDos17pckI += eeN6dTEnkJxI+LAQD5wEkr18bUiGaYen3J(u"ࠩ࡞ࡖ࡙ࡒ࡝ศๆศูิอัࠡษ็ิ๏ࠦว็ฬࠣฮุะฮะ็๊ࠤ้๋ำห๊า฽ࠥ฿ๅศั๋ࠣํࠦ࠺ࠡࠢࠣࠫჯ")+OkuB9nwhD8U1+x8s641FwaJRc7m+hAIp8kmC36T5WFPMSXOwnNbtD
	uvA8ymg3UDos17pckI += m6hwdgP31a2zjN7lkpX(u"ࠪࡠࡳࡢ࡮ࠨჰ")+RRIHDFjoW9w7bSfVPhC(u"ࠫࡠࡘࡔࡍ࡟ส่ส฻ฯศำࠣห้ษฮ๋ำ่ࠣั๊ฯࠡ็อีํฮ่ๅีࠣ฽๊อฯࠡษ็้ฯ๎แาࠢส่ว์่๊ࠠࠣ࠾ࠥࠦࠠࠨჱ")+OkuB9nwhD8U1+gcsIObSG0wZ9uozYX7BlJHxUM3+hAIp8kmC36T5WFPMSXOwnNbtD
	uvA8ymg3UDos17pckI += eeN6dTEnkJxI+kke1PDGRBLuY8y(u"ࠬࡡࡒࡕࡎࡠห้หีะษิࠤฬ๊ะ๋ࠢส๊ฯࠦสิฬัำ๊ํࠠๅฮ็ำ๋ࠥสา๊ห์ฺู้ࠠ็สำࠥํ่ࠡ࠼ࠣࠤࠥ࠭ჲ")+OkuB9nwhD8U1+eegGhoR5lPFMbnI7VjXqQKiLWuf+hAIp8kmC36T5WFPMSXOwnNbtD
	mEvj8WVaX6fNFD4eCdgtn5 = J5XjHOYq7WGDT or YwnJ4kDv5ioZBMj6tIgKWR0u7hST
	if mEvj8WVaX6fNFD4eCdgtn5:
		header = LAQD5wEkr18bUiGaYen3J(u"࠭วๅำฯหฦࠦสฮัํฯࠥหึศใสฮ้่ࠥะ์่ࠣา๊ࠠศๆุ่ฬ้ไࠨჳ")
		NNjD4IlzdF = LAQD5wEkr18bUiGaYen3J(u"ࠧศ่อࠤอำวอห่ࠣฯำฯ๋อࠣฬึ์วๆฮࠣ฽๊อฯࠡล๋ࠤฯำฯ๋อุ้ࠣะ่ะ฻ࠣ฽๊อฯࠨჴ")
	else:
		header = vvWwO3Tx2dAgcijrFXq(u"ࠨฯส่๏อࠠๅษࠣ๎ําฯࠡฬะำ๏ัวหࠢ็ฬึ์วๆฮࠣ฽๊อฯࠡล๋ࠤู๊ส้ั฼ࠤ฾๋วะࠩჵ")
		NNjD4IlzdF = shC5qBRV2A0lZ(u"ࠩส่ึาวยࠢศฬ้อฺࠡษ็้อืๅอࠢ฼๊ࠥอไๆึๆ่ฮࠦวๅฬํࠤฯ๎วอ้ๆࠫჶ")
	ZH7xA3UEkKgi9wpOco = mQNonhS7CV2BXOv(u"่่ࠪ๐๋ࠠ฻่่ࠥ฿ๆะๅࠣห้ะอะ์ฮࠤฬ๊สๅไสส๏๊ࠦอสࠣว๋๊ࠦไ๊้ࠤ้ี๊ไࠢไ๎้่ࠥะ์࡟ࡲู๊ส้ั฼ࠤ฾๋วะࠢࡈࡑࡆࡊࠠࡓࡧࡳࡳࡸ࡯ࡴࡰࡴࡼࠫჷ")
	xBEdu9nP64gUk70 = uvA8ymg3UDos17pckI+Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠫࡡࡴ࡜࡯ࠩჸ")+NNjD4IlzdF+BWNPxIG7vqdTy85pjHzUOrK3(u"ࠬࡢ࡮࡝ࡰࠪჹ")+ZH7xA3UEkKgi9wpOco
	bJvWMFh8G3eas(DYakr9g4PVU(u"࠭ࡲࡪࡩ࡫ࡸࠬჺ"),header,xBEdu9nP64gUk70,dDYUoKi6JFM23p(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪ჻"))
	return mEvj8WVaX6fNFD4eCdgtn5
def KURVy7LWmI6Btc(DFUIv2KGj9ke,kPfXiCJtG3HZympedv1N0LA,showDialogs):
	ip6CohvO5Tya9mFWVf3JdY1qL = DD5cFIejQa2X4BgAu9GWPyJ3tC7
	if showDialogs:
		aVwGA2kFY6u4m = BjMmX1vNrnzSAf(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫჼ"),S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠩึ์ๆ๊ࠦห็ࠣห้ศๆࠡฮ็ฬࠥอไๆๆไࠤฬ๊ๅื฼๋฻๊ࠥไฦุสๅฮࠦวๅ็ฺ่ํฮษࠡๆๆ๎ࠥ๐สๆࠢอฯอ๐ส่ࠢ฼่๎ࠦใ้ัํࠤ࠳ࠦวๅ็็ๅ่ࠥฯࠡ์ๆ์๋ࠦใษ์ิࠤํ่ฯࠡ์ะฮฬาࠠษ฻ูࠤฬ๊่ใฬࠣ࠲ࠥํไࠡฬิ๎ิࠦสฮ็ํ่ࠥอไๆๆไࠤฬ๊ย็ࠢยࠥࠬჽ"))
		if aVwGA2kFY6u4m!=qHYIWnOZLPkrQU: return DD5cFIejQa2X4BgAu9GWPyJ3tC7
	zms2LFdEhTpORHUqM618DQXeIBc0w = d0dDAEXWNf(kPfXiCJtG3HZympedv1N0LA,{},showDialogs)
	if zms2LFdEhTpORHUqM618DQXeIBc0w:
		EW57j4lF6RwZzCeOuG = x76PfMyAp1L2WejkU3.path.join(ph6VQImjWsE4BT5KUnAN,DFUIv2KGj9ke)
		p3pjrEcdKBfsDZw4qSJ(EW57j4lF6RwZzCeOuG,CCxMXuNUEzolDZTKrBJ,DD5cFIejQa2X4BgAu9GWPyJ3tC7)
		import zipfile as EP2VN08hXeDxZfjuwok,io as HH4k5YaihmL6o9
		dxvQ35j1aFlNftOn = HH4k5YaihmL6o9.BytesIO(zms2LFdEhTpORHUqM618DQXeIBc0w)
		try:
			NPROECgqcbmayIUWT1D6ut = EP2VN08hXeDxZfjuwok.ZipFile(dxvQ35j1aFlNftOn)
			NPROECgqcbmayIUWT1D6ut.extractall(ph6VQImjWsE4BT5KUnAN)
			wLQCTr5lqbsVYeAHdzfhZ1F.sleep(qHYIWnOZLPkrQU)
			uuxVm0bTwdnCUAL4s6NKHEBF3M.executebuiltin(Nh0BWuiSndf(u"࡙ࠪࡵࡪࡡࡵࡧࡏࡳࡨࡧ࡬ࡂࡦࡧࡳࡳࡹࠧჾ"))
			wLQCTr5lqbsVYeAHdzfhZ1F.sleep(qHYIWnOZLPkrQU)
			ip6CohvO5Tya9mFWVf3JdY1qL = em9WgKbTO2G6fYxQ8zowB(DFUIv2KGj9ke)
		except: ip6CohvO5Tya9mFWVf3JdY1qL = DD5cFIejQa2X4BgAu9GWPyJ3tC7
	if showDialogs:
		if ip6CohvO5Tya9mFWVf3JdY1qL: tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧჿ"),yST5AHEfvPmcWpwGuh2BJ(u"ࠬะๅࠡส้ะฬำࠠหอห๎ฯࠦวๅวูหๆฯࠠศๆ่฻้๎ศสࠩᄀ"))
		else: tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,vvWwO3Tx2dAgcijrFXq(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᄁ"),DYakr9g4PVU(u"ࠧๅๆฦืๆࠦแีๆอࠤ฾๋ไ๋หࠣฮะฮ๊หࠢส่ส฼วโหࠣห้๋ืๅ๊หอࠬᄂ"))
	return ip6CohvO5Tya9mFWVf3JdY1qL
def iYa4V16rHzIO(DFUIv2KGj9ke,showDialogs=CCxMXuNUEzolDZTKrBJ):
	if showDialogs==b8Qe150xVaJsnDSv: showDialogs = CCxMXuNUEzolDZTKrBJ
	WbN5HnlUGLO6EBM1vK9cej = ccBOVxQkTgGR5z1([DFUIv2KGj9ke])
	XKYls8p3Tz4HfrJWQyN67m,ky713umSnL4Rsclrf9 = WbN5HnlUGLO6EBM1vK9cej[DFUIv2KGj9ke]
	if ky713umSnL4Rsclrf9:
		ip6CohvO5Tya9mFWVf3JdY1qL = CCxMXuNUEzolDZTKrBJ
		if showDialogs: tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᄃ"),Xz3bA2PFENVCUtplu51(u"ࠩไัฺࠦวๅวูหๆฯࠠ࡝ࡰࠣࠫᄄ")+DFUIv2KGj9ke+ddo23ZJtgcY(u"ࠪࠤࡡࡴ่ࠠา๊ࠤศ๊ลืษไอࠥ฿ๆะๅ้ࠣํา่ะหࠣ์๊็ูๅหࠣ์ัอ็ำห่้ࠣอำหะาห๊࠭ᄅ"))
	else:
		ip6CohvO5Tya9mFWVf3JdY1qL = DD5cFIejQa2X4BgAu9GWPyJ3tC7
		aVwGA2kFY6u4m = BjMmX1vNrnzSAf(LAQD5wEkr18bUiGaYen3J(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫᄆ"),b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,LAQD5wEkr18bUiGaYen3J(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᄇ"),b8Qe150xVaJsnDSv+DFUIv2KGj9ke+BmePGjS7FxK6kutUM(u"࠭ࠠ࡝ࡰ๋ࠣีํࠠฤๆศฺฬ็ษࠡ฻้ำฺ่๋ࠦำ้ࠣๆ฿ไสࠢฦ์ࠥเ๊า่ࠢ์ั๎ฯสࠢ࠱ࠤ๏าศࠡฬฮฬ๏ะ็ศ๋ࠢฮๆ฿๊ๅ้สࠤ้้๊ࠡ์฼้้ࠦวๅสิ๊ฬ๋ฬࠡ฻้ำ่ࠦศึ๊ิอࠥ฻อ๋ฯฬࠤ࠳ࠦ็ๅࠢอี๏ีࠠหอห๎ฯ่ࠦหใ฼๎้ࠦ็ั้ࠣห้หึศใฬࠤฬ๊ย็ࠢยࠫᄈ"))
		if aVwGA2kFY6u4m==vvWwO3Tx2dAgcijrFXq(u"࠴ለ"):
			uuxVm0bTwdnCUAL4s6NKHEBF3M.executebuiltin(RRIHDFjoW9w7bSfVPhC(u"ࠧࡊࡰࡶࡸࡦࡲ࡬ࡂࡦࡧࡳࡳ࠮ࠧᄉ")+DFUIv2KGj9ke+TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠨࠫࠪᄊ"))
			wLQCTr5lqbsVYeAHdzfhZ1F.sleep(UUkIBz1sgQ9WfNeG6trKXvu0(u"࠵ሉ"))
			uuxVm0bTwdnCUAL4s6NKHEBF3M.executebuiltin(UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠩࡖࡩࡳࡪࡃ࡭࡫ࡦ࡯࠭࠷࠱ࠪࠩᄋ"))
			wLQCTr5lqbsVYeAHdzfhZ1F.sleep(dDYUoKi6JFM23p(u"࠶ሊ"))
			while uuxVm0bTwdnCUAL4s6NKHEBF3M.getCondVisibility(TYf7Dc06PQgy1vEV9(u"࡛ࠪ࡮ࡴࡤࡰࡹ࠱ࡍࡸࡇࡣࡵ࡫ࡹࡩ࠭ࡶࡲࡰࡩࡵࡩࡸࡹࡤࡪࡣ࡯ࡳ࡬࠯ࠧᄌ")): wLQCTr5lqbsVYeAHdzfhZ1F.sleep(ddo23ZJtgcY(u"࠷ላ"))
			ip6CohvO5Tya9mFWVf3JdY1qL = em9WgKbTO2G6fYxQ8zowB(DFUIv2KGj9ke)
			if showDialogs and ip6CohvO5Tya9mFWVf3JdY1qL: tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,BmePGjS7FxK6kutUM(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᄍ"),mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠬะๅࠡใะูࠥษ่ࠡฬฮฬ๏ะࠠฤ๊ࠣฮๆ฿๊ๅࠢฦ์ࠥะอะ์ฮࠤฬ๊ลืษไอࠥอไๆู็์อฯ้้ࠠํࠤฬ๊ย็ࠢฯห์ุษࠡๆ็หุะฮะษ่ࠫᄎ"))
			elif showDialogs: tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,Xz3bA2PFENVCUtplu51(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᄏ"),BWNPxIG7vqdTy85pjHzUOrK3(u"ࠧโึ็ࠤๆ๐ࠠหอห๎ฯࠦร้ࠢอๅ฾๐ไࠡล๋ࠤฯำฯ๋อࠣห้หึศใฬࠤฬ๊ๅุๆ๋ฬฮࠦ࠮๊ࠡส่า๊่๊ࠠࠣฮะฮ๊ห้สࠤํะแฺ์็๋ฬࠦๅ็ࠢัหึาࠠศๆหี๋อๅอࠩᄐ"))
	return ip6CohvO5Tya9mFWVf3JdY1qL
def xk701eJupZ6nU(showDialogs):
	if not showDialogs: aVwGA2kFY6u4m = CCxMXuNUEzolDZTKrBJ
	else: aVwGA2kFY6u4m = BjMmX1vNrnzSAf(BWNPxIG7vqdTy85pjHzUOrK3(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨᄑ"),b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,mQNonhS7CV2BXOv(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬᄒ"),vvWwO3Tx2dAgcijrFXq(u"ࠪฬึ์วๆฮࠣ็ํี๊ࠡ์ๅ์๊ࠦศฺ็็๎ฮࠦสฮัํฯࠥาๅ๋฻ࠣห้หึศใสฮࠥะไใษษ๎ฬࠦใๅࠢ࠵࠸ูࠥวฺหࠣ์้้ๆࠡ็่็๋ࠦลอำสล์อࠠศๆล๊ࠥ࠴่ࠠๆࠣฮึ๐ฯࠡฬะำ๏ัࠠอ็ํ฽ࠥหึศใสฮ้่ࠥะ์ࠣห้ศๆࠡมࠪᄓ"))
	if aVwGA2kFY6u4m==QQdAXWBc2GPw(u"࠱ሌ"):
		uuxVm0bTwdnCUAL4s6NKHEBF3M.executebuiltin(Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"࡚ࠫࡶࡤࡢࡶࡨࡅࡩࡪ࡯࡯ࡔࡨࡴࡴࡹࠧᄔ"))
		if showDialogs:
			tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᄕ"),vvWwO3Tx2dAgcijrFXq(u"࠭สๆࠢศีุอไูࠡ็ฬࠥหไ๊ࠢหี๋อๅอࠢๆ์ิ๐ࠠศๆำ๎ࠥ็๊ࠡฮ๊หื้ࠠๅๅํࠤ๏่่ๆࠢหฮาี๊ฬࠢฯ้๏฿ࠠฦุสๅฬะࠠไ๊า๎ࠥ࠴ࠠษ็สࠤๆ๐็ศࠢอัิ๐ห้ࠡำหࠥอไษำ้ห๊า้ࠠฬะำ๏ัࠠๆีอ์ิ฿ฺࠠ็สำࠥ࠴๋ࠠำฯํࠥหูุษฤࠤ่๎ฯ๋ࠢ࠸ࠤิ่ววไࠣวํࠦรไอิࠤ้้๊ࠡ์้๋๏ูࠦๆๆํอࠥอไหฯา๎ะ࠭ᄖ"))
	return
def Ef82HhjNckZGo1Xvy0():
	zqbhiLmQfC3VK9Arku(mshLJcKH1fv03yRnDOr4ZT,TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪᄗ"),RRIHDFjoW9w7bSfVPhC(u"ࠨࡃࡏࡐࡤࡇࡄࡅࡑࡑࡗࡤ࡞ࡍࡍࠩᄘ"))
	yyfh6GLPUwI7r0J1De()
	mEvj8WVaX6fNFD4eCdgtn5 = FItk8GQb9dWfH0Bh6()
	if mEvj8WVaX6fNFD4eCdgtn5:
		OsdWDnBA5bgqZlXPhmeuK60cCU7(CCxMXuNUEzolDZTKrBJ)
		xk701eJupZ6nU(CCxMXuNUEzolDZTKrBJ)
		qMGn9u2ckaXejCgUQhYTDP(DD5cFIejQa2X4BgAu9GWPyJ3tC7)
	return
def em9WgKbTO2G6fYxQ8zowB(DFUIv2KGj9ke):
	XXxlOLJ9KRjPH382WVCvr6n71 = uuxVm0bTwdnCUAL4s6NKHEBF3M.executeJSONRPC(shC5qBRV2A0lZ(u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡃࡧࡨࡴࡴࡳ࠯ࡕࡨࡸࡆࡪࡤࡰࡰࡈࡲࡦࡨ࡬ࡦࡦࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡣࡧࡨࡴࡴࡩࡥࠤ࠽ࠦࠬᄙ")+DFUIv2KGj9ke+SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠪࠦ࠱ࠨࡥ࡯ࡣࡥࡰࡪࡪࠢ࠻ࡶࡵࡹࡪࢃࡽࠨᄚ"))
	succeeded = CCxMXuNUEzolDZTKrBJ if Mmpr0o76iWJvz1kTtfgI8hES(u"ࠫࡔࡑࠧᄛ") in XXxlOLJ9KRjPH382WVCvr6n71 else DD5cFIejQa2X4BgAu9GWPyJ3tC7
	return succeeded
def oomkStHMlTuQR9nsh6pdK(DFUIv2KGj9ke):
	XXxlOLJ9KRjPH382WVCvr6n71 = uuxVm0bTwdnCUAL4s6NKHEBF3M.executeJSONRPC(RRIHDFjoW9w7bSfVPhC(u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡆࡪࡤࡰࡰࡶ࠲ࡘ࡫ࡴࡂࡦࡧࡳࡳࡋ࡮ࡢࡤ࡯ࡩࡩࠨࠬࠣ࡫ࡧࠦ࠿࠷ࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡦࡪࡤࡰࡰ࡬ࡨࠧࡀࠢࠨᄜ")+DFUIv2KGj9ke+Nh0BWuiSndf(u"࠭ࠢ࠭ࠤࡨࡲࡦࡨ࡬ࡦࡦࠥ࠾࡫ࡧ࡬ࡴࡧࢀࢁࠬᄝ"))
	succeeded = CCxMXuNUEzolDZTKrBJ if mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠧࡐࡍࠪᄞ") in XXxlOLJ9KRjPH382WVCvr6n71 else DD5cFIejQa2X4BgAu9GWPyJ3tC7
	return succeeded
def S6lDdjHGs9mQhwpzZU(DFUIv2KGj9ke,showDialogs,coT5hMDd4HJrlA,EJcfC7seYxiG=None):
	aVwGA2kFY6u4m,succeeded,SrZcYwJuohQlLWntPGTEbADFeC7,ww5RBJWz8japXAlCYqSxgEf0NFVK7G = CCxMXuNUEzolDZTKrBJ,DD5cFIejQa2X4BgAu9GWPyJ3tC7,yST5AHEfvPmcWpwGuh2BJ(u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨᄟ"),b8Qe150xVaJsnDSv
	if not EJcfC7seYxiG: EJcfC7seYxiG = YqPryjvitICmH([DFUIv2KGj9ke])
	if DFUIv2KGj9ke in list(EJcfC7seYxiG.keys()):
		mEvj8WVaX6fNFD4eCdgtn5,ww5RBJWz8japXAlCYqSxgEf0NFVK7G,FNqXBKMYgCPe6itk59AwTnOr1,p7zHTPBakINxtG3ylXjAwvKfEDS,l75ag8db26Iy04u1LmYRxfWH,i7dhFEmQycVr5qj6sNzl4BO01uGvUe,kPfXiCJtG3HZympedv1N0LA = EJcfC7seYxiG[DFUIv2KGj9ke]
		if i7dhFEmQycVr5qj6sNzl4BO01uGvUe==TYf7Dc06PQgy1vEV9(u"ࠩࡪࡳࡴࡪࠧᄠ"):
			succeeded,SrZcYwJuohQlLWntPGTEbADFeC7 = CCxMXuNUEzolDZTKrBJ,m6hwdgP31a2zjN7lkpX(u"ࠪࡲࡴࡺࡨࡪࡰࡪࠫᄡ")
			if coT5hMDd4HJrlA and showDialogs:
				aVwGA2kFY6u4m = BjMmX1vNrnzSAf(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,BWNPxIG7vqdTy85pjHzUOrK3(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᄢ"),QQdAXWBc2GPw(u"ࠬา๊ะࠢฯำฬࠦ࠮࠯ࠢๆ์ิ๐๋ࠠีอาิ๋ࠠฤะิࠤส฻ฯศำ้ࠣฯ๎แาࠢไ๎๋่ࠥศไ฼ࠤู๊ส้ั฼ࠤ฾๋วะࠢ็๋ีํࠠศๆศฺฬ็ษ࡝ࡰ࡟ࡲࠬᄣ")+DFUIv2KGj9ke+yST5AHEfvPmcWpwGuh2BJ(u"࠭࡜࡯࡞ࡱ๋้ࠦสา์าࠤส฿วะหࠣฮะฮ๊ห๊ࠢิ์ࠦวๅวูหๆฯࠠๆำฬࠤศิั๊ࠩᄤ"))
				if aVwGA2kFY6u4m:
					succeeded = KURVy7LWmI6Btc(DFUIv2KGj9ke,kPfXiCJtG3HZympedv1N0LA,DD5cFIejQa2X4BgAu9GWPyJ3tC7)
					if succeeded:
						SrZcYwJuohQlLWntPGTEbADFeC7 = ddo23ZJtgcY(u"ࠧࡳࡧ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨࠬᄥ")
						if showDialogs: tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,Xz3bA2PFENVCUtplu51(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᄦ"),P0qdZI384LKleuo(u"ࠩฯ๎ิࠦฬะษࠣ࠲࠳ࠦวๅวูหๆฯࠠไษ้ฮ๋่ࠥอ๊าอࠥ࠴࠮๊ࠡๅห๊ࠦวๅสิ๊ฬ๋ฬࠡสศ฽ฬีษࠡฬฮฬ๏ะ็ศ࡞ࡱࡠࡳ࠭ᄧ")+DFUIv2KGj9ke)
					else:
						SrZcYwJuohQlLWntPGTEbADFeC7 = yST5AHEfvPmcWpwGuh2BJ(u"ࠪࡪࡦ࡯࡬ࡦࡦࠪᄨ")
						tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,vvWwO3Tx2dAgcijrFXq(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᄩ"),UUkIBz1sgQ9WfNeG6trKXvu0(u"๊ࠬไฤีไࠤ࠳࠴ࠠศๆหี๋อๅอࠢ็้ࠥ๐ำหูํ฽ࠥหูศัฬࠤฯัศ๋ฬ๋ࠣีํࠠศๆศฺฬ็ษ࡝ࡰ࡟ࡲࠬᄪ")+DFUIv2KGj9ke)
		else:
			if showDialogs:
				if i7dhFEmQycVr5qj6sNzl4BO01uGvUe==ddo23ZJtgcY(u"࠭ࡤࡪࡵࡤࡦࡱ࡫ࡤࠨᄫ"): A4gdSTQDP2FyBIVuba85RvYqKU = Nh0BWuiSndf(u"ࠧๆฬ๋ๆๆฯࠧᄬ")
				elif i7dhFEmQycVr5qj6sNzl4BO01uGvUe==QQdAXWBc2GPw(u"ࠨࡱ࡯ࡨࠬᄭ"): A4gdSTQDP2FyBIVuba85RvYqKU = shC5qBRV2A0lZ(u"ࠩๅำ๏๋ษࠨᄮ")
				elif i7dhFEmQycVr5qj6sNzl4BO01uGvUe==vvWwO3Tx2dAgcijrFXq(u"ࠪࡱ࡮ࡹࡳࡪࡰࡪࠫᄯ"): A4gdSTQDP2FyBIVuba85RvYqKU = SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠫ฿๐ัࠡ็ฮฬฯฯࠧᄰ")
				aVwGA2kFY6u4m = BjMmX1vNrnzSAf(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᄱ"),IjZbnrBJmM2N(u"࠭็ั้ࠣห้หึศใฬࠤࠬᄲ")+A4gdSTQDP2FyBIVuba85RvYqKU+Xz3bA2PFENVCUtplu51(u"ࠧࠡ࠰࠱ࠤ์๊ࠠหำํำࠥหีๅษะࠤ์ึ็ࠡษ็ู้้ไสࠢยࠥࡡࡴ࡜࡯ࠩᄳ")+DFUIv2KGj9ke)
			if not aVwGA2kFY6u4m: SrZcYwJuohQlLWntPGTEbADFeC7 = Mmpr0o76iWJvz1kTtfgI8hES(u"ࠨࡥࡤࡲࡨ࡫࡬ࡦࡦࠪᄴ")
			else:
				if i7dhFEmQycVr5qj6sNzl4BO01uGvUe==yST5AHEfvPmcWpwGuh2BJ(u"ࠩࡧ࡭ࡸࡧࡢ࡭ࡧࡧࠫᄵ"):
					succeeded = em9WgKbTO2G6fYxQ8zowB(DFUIv2KGj9ke)
					if succeeded:
						SrZcYwJuohQlLWntPGTEbADFeC7 = RRIHDFjoW9w7bSfVPhC(u"ࠪࡩࡳࡧࡢ࡭ࡧࡧࠫᄶ")
						if showDialogs: tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,ddo23ZJtgcY(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᄷ"),Mmpr0o76iWJvz1kTtfgI8hES(u"ࠬา๊ะࠢฯำฬࠦ࠮࠯ࠢส่ส฼วโหࠣ็ฬ์สࠡ็อ์็็ษࠡ࠰࠱ࠤํ่วๆࠢส่อืๆศ็ฯࠤอะิ฻์็๋ฬࡢ࡮࡝ࡰࠪᄸ")+DFUIv2KGj9ke)
					elif showDialogs: tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,UUkIBz1sgQ9WfNeG6trKXvu0(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᄹ"),dDYUoKi6JFM23p(u"ࠧๅๆฦืๆࠦ࠮࠯ࠢส่ส฼วโห้ࠣฯ๎โโหࠣ࠲࠳่ࠦๅ็ࠣ๎ุะื๋฻ࠣห้ฮั็ษ่ะࠥะิ฻์็๋ฬࡢ࡮࡝ࡰࠪᄺ")+DFUIv2KGj9ke)
				elif i7dhFEmQycVr5qj6sNzl4BO01uGvUe in [S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠨࡱ࡯ࡨࠬᄻ"),zI3ROAZtiUq42rE9WDST68(u"ࠩࡰ࡭ࡸࡹࡩ࡯ࡩࠪᄼ")]:
					succeeded = KURVy7LWmI6Btc(DFUIv2KGj9ke,kPfXiCJtG3HZympedv1N0LA,DD5cFIejQa2X4BgAu9GWPyJ3tC7)
					if succeeded:
						if i7dhFEmQycVr5qj6sNzl4BO01uGvUe==uVQd103XyvUce2EBtzbYaC(u"ࠪࡳࡱࡪࠧᄽ"): SrZcYwJuohQlLWntPGTEbADFeC7 = VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠫࡺࡶࡤࡢࡶࡨࡨࠬᄾ")
						elif i7dhFEmQycVr5qj6sNzl4BO01uGvUe==S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠬࡳࡩࡴࡵ࡬ࡲ࡬࠭ᄿ"): SrZcYwJuohQlLWntPGTEbADFeC7 = P0qdZI384LKleuo(u"࠭ࡩ࡯ࡵࡷࡥࡱࡲࡥࡥࠩᅀ")
						ww5RBJWz8japXAlCYqSxgEf0NFVK7G = p7zHTPBakINxtG3ylXjAwvKfEDS
						if showDialogs:
							if SrZcYwJuohQlLWntPGTEbADFeC7==QTUBCcehw6qPd4x(u"ࠧࡶࡲࡧࡥࡹ࡫ࡤࠨᅁ"): tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,Xz3bA2PFENVCUtplu51(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᅂ"),QTUBCcehw6qPd4x(u"ࠩฯ๎ิࠦฬะษࠣ࠲࠳ࠦวๅวูหๆฯࠠไษ้ฮ่ࠥฯ๋็ฬࠤ࠳࠴้ࠠษ็ฬึ์วๆฮࠣๆฬ๋ࠠษฬะำ๏ั็ศ࡞ࡱࡠࡳ࠭ᅃ")+DFUIv2KGj9ke)
							elif SrZcYwJuohQlLWntPGTEbADFeC7==BWNPxIG7vqdTy85pjHzUOrK3(u"ࠪ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩ࠭ᅄ"): tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,zI3ROAZtiUq42rE9WDST68(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᅅ"),yST5AHEfvPmcWpwGuh2BJ(u"ࠬา๊ะࠢฯำฬࠦ࠮࠯ࠢส่ส฼วโห่๊ࠣࠦสไ่้ࠣํา่ะหࠣๅ๏ࠦใ้ัํࠤ࠳࠴้ࠠษ็ฬึ์วๆฮࠣๆฬ๋ࠠษฬฮฬ๏ะ็ศ࡞ࡱࡠࡳ࠭ᅆ")+DFUIv2KGj9ke)
					elif showDialogs: tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,dDYUoKi6JFM23p(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᅇ"),Xz3bA2PFENVCUtplu51(u"ࠧๅๆฦืๆࠦ࠮࠯ࠢส่อืๆศ็ฯࠤ้๋๋ࠠีอ฻๏฿ࠠหฯา๎ะࠦร้ࠢอฯอ๐ส้ࠡำ๋ࠥอไฦุสๅฮࡢ࡮࡝ࡰࠪᅈ")+DFUIv2KGj9ke)
	elif showDialogs: tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,dDYUoKi6JFM23p(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᅉ"),kke1PDGRBLuY8y(u"ࠩ็่ศูแࠡ࠰࠱ࠤ์ึ็ࠡษ็ษ฻อแสࠢ฽๎ึࠦๅ้ฮ๋ำฮࠦแ๋่ࠢืฯ๎ฯฺࠢ฼้ฬีࠠ࠯࠰ࠣ์้ํะศࠢ็หࠥ๐ำหูํ฽ࠥอไษำ้ห๊าࠠฤ่ࠣ๎็๎ๅࠡสอฯอ๐ส้ࠡำ๋ࠥอไฦุสๅฮࠦร้ࠢอัิ๐ห่ษ࡟ࡲࡡࡴࠧᅊ")+DFUIv2KGj9ke)
	return succeeded,SrZcYwJuohQlLWntPGTEbADFeC7,ww5RBJWz8japXAlCYqSxgEf0NFVK7G
def FjhoxKe0ERbO8(DFUIv2KGj9ke,showDialogs,mU80y7KPE9DTCuFHLNQwdc,yw2LscNDdvZOKIpHVuUQ891J4gTeG=None,Yn98v3MRdasNfWB2SAG6TOV1m4tq=None):
	wva0mEQhP3un6fSj4BGF7ZCTNOWDJU = CCxMXuNUEzolDZTKrBJ if yw2LscNDdvZOKIpHVuUQ891J4gTeG else DD5cFIejQa2X4BgAu9GWPyJ3tC7
	if not wva0mEQhP3un6fSj4BGF7ZCTNOWDJU:
		yw2LscNDdvZOKIpHVuUQ891J4gTeG = jA69Ts3CqJli7.connect(YakNVvKg8rqWUPTxef)
		yw2LscNDdvZOKIpHVuUQ891J4gTeG.text_factory = str
		Yn98v3MRdasNfWB2SAG6TOV1m4tq = yw2LscNDdvZOKIpHVuUQ891J4gTeG.cursor()
	succeeded,b1R7qLJjAISrMdVDQ0m3ya4t8p9n = CCxMXuNUEzolDZTKrBJ,DD5cFIejQa2X4BgAu9GWPyJ3tC7
	try:
		SyLBVCP9zk = zI3ROAZtiUq42rE9WDST68(u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨࠬᅋ")
		Yn98v3MRdasNfWB2SAG6TOV1m4tq.execute(TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠫࡘࡋࡌࡆࡅࡗࠤࡴࡸࡩࡨ࡫ࡱࠤࡋࡘࡏࡎࠢ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨࠥ࡝ࡈࡆࡔࡈࠤࡦࡪࡤࡰࡰࡌࡈࠥࡃࠠࠣࠩᅌ")+DFUIv2KGj9ke+Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠬࠨࠠ࠼ࠩᅍ"))
		tG5TJBEmWonrxFvRdXq76c8febiQVS = Yn98v3MRdasNfWB2SAG6TOV1m4tq.fetchall()
		if tG5TJBEmWonrxFvRdXq76c8febiQVS and SyLBVCP9zk not in str(tG5TJBEmWonrxFvRdXq76c8febiQVS): Yn98v3MRdasNfWB2SAG6TOV1m4tq.execute(shC5qBRV2A0lZ(u"࠭ࡕࡑࡆࡄࡘࡊࠦࡩ࡯ࡵࡷࡥࡱࡲࡥࡥࠢࡖࡉ࡙ࠦ࡯ࡳ࡫ࡪ࡭ࡳࠦ࠽ࠡࠤࠪᅎ")+SyLBVCP9zk+Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"࡚ࠧࠣࠢࡌࡊࡘࡅࠡࡣࡧࡨࡴࡴࡉࡅࠢࡀࠤࠧ࠭ᅏ")+DFUIv2KGj9ke+TYf7Dc06PQgy1vEV9(u"ࠨࠤࠣ࠿ࠬᅐ"))
		PPXRmWlHtuBf35 = dDYUoKi6JFM23p(u"ࠩࡥࡰࡦࡩ࡫࡭࡫ࡶࡸࠬᅑ") if hDTluNxe7tCwrpqXHzdEcYRfbs else TYf7Dc06PQgy1vEV9(u"ࠪࡹࡵࡪࡡࡵࡧࡢࡶࡺࡲࡥࡴࠩᅒ")
		Yn98v3MRdasNfWB2SAG6TOV1m4tq.execute(RRIHDFjoW9w7bSfVPhC(u"ࠫࡘࡋࡌࡆࡅࡗࠤ࠯ࠦࡆࡓࡑࡐࠤࠬᅓ")+PPXRmWlHtuBf35+ddo23ZJtgcY(u"ࠬࠦࡗࡉࡇࡕࡉࠥࡧࡤࡥࡱࡱࡍࡉࠦ࠽ࠡࠤࠪᅔ")+DFUIv2KGj9ke+ubxGUTt1LraKhVZgpAP(u"࠭ࠢࠡ࠽ࠪᅕ"))
		tG5TJBEmWonrxFvRdXq76c8febiQVS = Yn98v3MRdasNfWB2SAG6TOV1m4tq.fetchall()
		if tG5TJBEmWonrxFvRdXq76c8febiQVS:
			if showDialogs: aVwGA2kFY6u4m = BjMmX1vNrnzSAf(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,ubxGUTt1LraKhVZgpAP(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᅖ"),RRIHDFjoW9w7bSfVPhC(u"ࠨษ็ฮาี๊ฬࠢส่ศ๎ส้็สฮ๏้๊ࠡๆศฺฬ็ษࠡ࡞ࡱࠤࠬᅗ")+DFUIv2KGj9ke+HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠩࠣࡠࡳࡢ࡮ࠡࠩᅘ")+rC3Tlno96KjLDIvBaSWUbR8+UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠪࠤ๊ะ่ใใࠣ์้อ๋ࠠ฻่่ࠥ࠴࠮้ࠡ็ࠤฯื๊ะࠢอๅ฾๐ไ่ࠢส่ว์ࠠภࠣࠤࠤࠬᅙ")+hAIp8kmC36T5WFPMSXOwnNbtD+Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠫࠥࡢ࡮࡝ࡰࠣฮุะื๋฻ࠣษ๏่วโ้ࠣฬุํ่ๅหࠣ฽๋ีࠠศๆ฼์ิฯࠠฦๆ์ࠤ์ึ็ࠡษ็ุฬฺษࠡษ็้ํา่ะหࠣๅ๏ࠦโศศ่อࠥิฯๆษอࠤอืๆศ็ฯࠤ฾๋วะࠩᅚ"))
			else: aVwGA2kFY6u4m = qHYIWnOZLPkrQU
			if aVwGA2kFY6u4m==qHYIWnOZLPkrQU:
				b1R7qLJjAISrMdVDQ0m3ya4t8p9n = CCxMXuNUEzolDZTKrBJ
				Yn98v3MRdasNfWB2SAG6TOV1m4tq.execute(DYakr9g4PVU(u"ࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࠫᅛ")+PPXRmWlHtuBf35+Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"࠭ࠠࡘࡊࡈࡖࡊࠦࡡࡥࡦࡲࡲࡎࡊࠠ࠾ࠢࠥࠫᅜ")+DFUIv2KGj9ke+BmePGjS7FxK6kutUM(u"ࠧࠣࠢ࠾ࠫᅝ"))
		elif mU80y7KPE9DTCuFHLNQwdc:
			if showDialogs: aVwGA2kFY6u4m = BjMmX1vNrnzSAf(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,BWNPxIG7vqdTy85pjHzUOrK3(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᅞ"),ubxGUTt1LraKhVZgpAP(u"ࠩส่ฯำฯ๋อࠣห้ษ่ห๊่หฯ๐ใ๋ࠢ็ษ฻อแสࠢ࡟ࡲࠥ࠭ᅟ")+DFUIv2KGj9ke+kke1PDGRBLuY8y(u"ࠪࠤࡡࡴ࡜࡯ࠢࠪᅠ")+rC3Tlno96KjLDIvBaSWUbR8+BmePGjS7FxK6kutUM(u"๋ࠫࠥแฺๆࠣ์๏฿ๅๅࠢ࠱࠲ࠥํไࠡฬิ๎ิࠦล๋ไสๅ์ࠦวๅฤ้ࠤฤࠧࠡࠡࠩᅡ")+hAIp8kmC36T5WFPMSXOwnNbtD+vvWwO3Tx2dAgcijrFXq(u"ࠬࠦ࡜࡯࡞ࡱࠤฯูสุ์฼ࠤฯ็ู๋ๆ๊ࠤอู็้ๆฬࠤ฾์ฯࠡษ็฽ํีษࠡว็ํࠥํะ่ࠢสู่อิสࠢส่๊๎ฬ้ัฬࠤๆ๐ࠠใษษ้ฮࠦฮะ็สฮࠥฮั็ษ่ะࠥ฿ๅศัࠪᅢ"))
			else: aVwGA2kFY6u4m = qHYIWnOZLPkrQU
			if aVwGA2kFY6u4m==qHYIWnOZLPkrQU:
				b1R7qLJjAISrMdVDQ0m3ya4t8p9n = CCxMXuNUEzolDZTKrBJ
				if hDTluNxe7tCwrpqXHzdEcYRfbs: Yn98v3MRdasNfWB2SAG6TOV1m4tq.execute(Mmpr0o76iWJvz1kTtfgI8hES(u"࠭ࡉࡏࡕࡈࡖ࡙ࠦࡉࡏࡖࡒࠤࠬᅣ")+PPXRmWlHtuBf35+BWNPxIG7vqdTy85pjHzUOrK3(u"ࠧࠡࠪࡤࡨࡩࡵ࡮ࡊࡆࠬࠤ࡛ࡇࡌࡖࡇࡖࠤ࠭ࠨࠧᅤ")+DFUIv2KGj9ke+m6hwdgP31a2zjN7lkpX(u"ࠨࠤࠬࠤࡀ࠭ᅥ"))
				else: Yn98v3MRdasNfWB2SAG6TOV1m4tq.execute(HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠩࡌࡒࡘࡋࡒࡕࠢࡌࡒ࡙ࡕࠠࠨᅦ")+PPXRmWlHtuBf35+TYf7Dc06PQgy1vEV9(u"ࠪࠤ࠭ࡧࡤࡥࡱࡱࡍࡉ࠲ࡵࡱࡦࡤࡸࡪࡘࡵ࡭ࡧࠬࠤ࡛ࡇࡌࡖࡇࡖࠤ࠭ࠨࠧᅧ")+DFUIv2KGj9ke+RRIHDFjoW9w7bSfVPhC(u"ࠫࠧ࠲࠱ࠪࠢ࠾ࠫᅨ"))
	except: succeeded = DD5cFIejQa2X4BgAu9GWPyJ3tC7
	if showDialogs and b1R7qLJjAISrMdVDQ0m3ya4t8p9n:
		if succeeded: tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,yST5AHEfvPmcWpwGuh2BJ(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᅩ"),TT8Mxv5Wq7nlC9IscdpPUY6(u"࠭ๆอฯอࠤ฾๋ไ๋หࠣษฺ๊วฮࠢอัิ๐หࠡษ็ษ฻อแสࠢ࡟ࡲࡡࡴࠧᅪ")+DFUIv2KGj9ke)
		else: tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,zI3ROAZtiUq42rE9WDST68(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᅫ"),QTUBCcehw6qPd4x(u"ࠨใื่ฯูࠦๆๆํอࠥหีๅษะࠤฯำฯ๋อࠣห้หึศใฬࠤࡡࡴ࡜࡯ࠩᅬ")+DFUIv2KGj9ke)
	if not wva0mEQhP3un6fSj4BGF7ZCTNOWDJU:
		yw2LscNDdvZOKIpHVuUQ891J4gTeG.commit()
		yw2LscNDdvZOKIpHVuUQ891J4gTeG.close()
		if b1R7qLJjAISrMdVDQ0m3ya4t8p9n:
			wLQCTr5lqbsVYeAHdzfhZ1F.sleep(QQdAXWBc2GPw(u"࠲ል"))
			uuxVm0bTwdnCUAL4s6NKHEBF3M.executebuiltin(P0qdZI384LKleuo(u"ࠩࡘࡴࡩࡧࡴࡦࡎࡲࡧࡦࡲࡁࡥࡦࡲࡲࡸ࠭ᅭ"))
			wLQCTr5lqbsVYeAHdzfhZ1F.sleep(vvWwO3Tx2dAgcijrFXq(u"࠳ሎ"))
	return b1R7qLJjAISrMdVDQ0m3ya4t8p9n
def YB30hP8KoEXSCOQb4vJ(kBjDnsUC8y4,showDialogs,coT5hMDd4HJrlA,mU80y7KPE9DTCuFHLNQwdc):
	yw2LscNDdvZOKIpHVuUQ891J4gTeG = jA69Ts3CqJli7.connect(YakNVvKg8rqWUPTxef)
	yw2LscNDdvZOKIpHVuUQ891J4gTeG.text_factory = str
	Yn98v3MRdasNfWB2SAG6TOV1m4tq = yw2LscNDdvZOKIpHVuUQ891J4gTeG.cursor()
	EJcfC7seYxiG = YqPryjvitICmH(kBjDnsUC8y4)
	Km315rcTMykLfvPiDqGR8uY = DD5cFIejQa2X4BgAu9GWPyJ3tC7
	for DFUIv2KGj9ke in kBjDnsUC8y4:
		succeeded,SrZcYwJuohQlLWntPGTEbADFeC7,ww5RBJWz8japXAlCYqSxgEf0NFVK7G = S6lDdjHGs9mQhwpzZU(DFUIv2KGj9ke,showDialogs,coT5hMDd4HJrlA,EJcfC7seYxiG)
		b1R7qLJjAISrMdVDQ0m3ya4t8p9n = FjhoxKe0ERbO8(DFUIv2KGj9ke,showDialogs,mU80y7KPE9DTCuFHLNQwdc,yw2LscNDdvZOKIpHVuUQ891J4gTeG,Yn98v3MRdasNfWB2SAG6TOV1m4tq)
		if b1R7qLJjAISrMdVDQ0m3ya4t8p9n: Km315rcTMykLfvPiDqGR8uY = CCxMXuNUEzolDZTKrBJ
	yw2LscNDdvZOKIpHVuUQ891J4gTeG.commit()
	yw2LscNDdvZOKIpHVuUQ891J4gTeG.close()
	if Km315rcTMykLfvPiDqGR8uY:
		wLQCTr5lqbsVYeAHdzfhZ1F.sleep(Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"࠴ሏ"))
		uuxVm0bTwdnCUAL4s6NKHEBF3M.executebuiltin(m6hwdgP31a2zjN7lkpX(u"࡙ࠪࡵࡪࡡࡵࡧࡏࡳࡨࡧ࡬ࡂࡦࡧࡳࡳࡹࠧᅮ"))
		wLQCTr5lqbsVYeAHdzfhZ1F.sleep(dDYUoKi6JFM23p(u"࠵ሐ"))
	if showDialogs:
		if len(kBjDnsUC8y4)>Nh0BWuiSndf(u"࠶ሑ"): tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,uVQd103XyvUce2EBtzbYaC(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᅯ"),Nh0BWuiSndf(u"ࠬะๅࠡส้ะฬำࠠโฯุࠤัฺ๋๊ࠢส่ส฼วโษอࠫᅰ"))
		else: tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,BWNPxIG7vqdTy85pjHzUOrK3(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᅱ"),QQdAXWBc2GPw(u"ࠧห็ࠣฬ๋าวฮࠢไัฺࠦวๅวูหๆฯ࡜࡯࡞ࡱࠫᅲ")+kBjDnsUC8y4[Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"࠶ሒ")])
	return
def OsdWDnBA5bgqZlXPhmeuK60cCU7(showDialogs):
	QFxjYDVs8i7OSld5UnhC = [P0qdZI384LKleuo(u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭ᅳ"),VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧࠫᅴ"),vvWwO3Tx2dAgcijrFXq(u"ࠪࡷࡨࡸࡩࡱࡶ࠱ࡱࡴࡪࡵ࡭ࡧ࠱ࡶࡪࡹ࡯࡭ࡸࡨࡹࡷࡲࠧᅵ"),shC5qBRV2A0lZ(u"ࠫࡸࡩࡲࡪࡲࡷ࠲ࡲࡵࡤࡶ࡮ࡨ࠲ࡾࡺ࠭ࡥ࡮ࡳࠫᅶ")]
	hsEdgM9fcRQLnC3OtqB7JGb1jmFo = [dDYUoKi6JFM23p(u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪ࠮ࡰࡶ࡫ࡩࡷࡹࠧᅷ"),QQdAXWBc2GPw(u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤ࠯ࡩ࡬ࡸࡪ࡫ࠧᅸ"),mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥ࠰ࡳࡽࡹ࡮࡯࡯ࡣࡱࡽࡼ࡮ࡥࡳࡧࠪᅹ"),P0qdZI384LKleuo(u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦ࠱࡫࡮ࡺࡨࡶࡤࠪᅺ"),RRIHDFjoW9w7bSfVPhC(u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧ࠲࡬࡯ࡴࡦࡣࠪᅻ"),RRIHDFjoW9w7bSfVPhC(u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨ࠳ࡩ࡯ࡥࡧࡥࡩࡷ࡭ࠧᅼ")]
	for DFUIv2KGj9ke in hsEdgM9fcRQLnC3OtqB7JGb1jmFo: oomkStHMlTuQR9nsh6pdK(DFUIv2KGj9ke)
	YB30hP8KoEXSCOQb4vJ(QFxjYDVs8i7OSld5UnhC,showDialogs,DD5cFIejQa2X4BgAu9GWPyJ3tC7,DD5cFIejQa2X4BgAu9GWPyJ3tC7)
	return
# -*- coding: utf-8 -*-
import sys as Pft6y0LvwSh48iYg7b
MQBw2uYHcWbpxF8tKAV = Pft6y0LvwSh48iYg7b.version_info [0] == 2
myc93k4htNU67 = 2048
h8lCkw1d3LepDVuvfoicEXj5K6sPz = 7
def JanmRV2MtcH (VwngrDb8fEytv4kMTdQu95cIejsC):
	global oPFYqewitzj
	WBrAFcJPVXdS2UzxLEGM0omkD = ord (VwngrDb8fEytv4kMTdQu95cIejsC [-1])
	V13jmfpwhlcyCKMRLY5TiaG = VwngrDb8fEytv4kMTdQu95cIejsC [:-1]
	gyF4Uq9l1NQKCtT = WBrAFcJPVXdS2UzxLEGM0omkD % len (V13jmfpwhlcyCKMRLY5TiaG)
	BN5pdqozP2v9Ur1Swsia = V13jmfpwhlcyCKMRLY5TiaG [:gyF4Uq9l1NQKCtT] + V13jmfpwhlcyCKMRLY5TiaG [gyF4Uq9l1NQKCtT:]
	if MQBw2uYHcWbpxF8tKAV:
		D3MGYw1ceHQ4UbrNJSq = unicode () .join ([unichr (ord (bb1FgjciZqDzeQTBC2hplaPkmRIyUf) - myc93k4htNU67 - (Ni5bJjhpks6SfCc + WBrAFcJPVXdS2UzxLEGM0omkD) % h8lCkw1d3LepDVuvfoicEXj5K6sPz) for Ni5bJjhpks6SfCc, bb1FgjciZqDzeQTBC2hplaPkmRIyUf in enumerate (BN5pdqozP2v9Ur1Swsia)])
	else:
		D3MGYw1ceHQ4UbrNJSq = str () .join ([chr (ord (bb1FgjciZqDzeQTBC2hplaPkmRIyUf) - myc93k4htNU67 - (Ni5bJjhpks6SfCc + WBrAFcJPVXdS2UzxLEGM0omkD) % h8lCkw1d3LepDVuvfoicEXj5K6sPz) for Ni5bJjhpks6SfCc, bb1FgjciZqDzeQTBC2hplaPkmRIyUf in enumerate (BN5pdqozP2v9Ur1Swsia)])
	return eval (D3MGYw1ceHQ4UbrNJSq)
TYf7Dc06PQgy1vEV9,ubxGUTt1LraKhVZgpAP,Y2t8baH5GWikvOZ7NsCeq3TKrgMV=JanmRV2MtcH,JanmRV2MtcH,JanmRV2MtcH
BWNPxIG7vqdTy85pjHzUOrK3,Mmpr0o76iWJvz1kTtfgI8hES,QTUBCcehw6qPd4x=Y2t8baH5GWikvOZ7NsCeq3TKrgMV,ubxGUTt1LraKhVZgpAP,TYf7Dc06PQgy1vEV9
mQNonhS7CV2BXOv,HwB7ydlWVJeCtPuQ6MDE1RTYOo,uVQd103XyvUce2EBtzbYaC=QTUBCcehw6qPd4x,Mmpr0o76iWJvz1kTtfgI8hES,BWNPxIG7vqdTy85pjHzUOrK3
yST5AHEfvPmcWpwGuh2BJ,BmePGjS7FxK6kutUM,S0IlDPhBN3gMEUvnjRLXsYAc2Zf=uVQd103XyvUce2EBtzbYaC,HwB7ydlWVJeCtPuQ6MDE1RTYOo,mQNonhS7CV2BXOv
Xz3bA2PFENVCUtplu51,LAQD5wEkr18bUiGaYen3J,P0qdZI384LKleuo=S0IlDPhBN3gMEUvnjRLXsYAc2Zf,BmePGjS7FxK6kutUM,yST5AHEfvPmcWpwGuh2BJ
shC5qBRV2A0lZ,mmcNLrXtzfpyCkZlvK5VwG2gujh,m6hwdgP31a2zjN7lkpX=P0qdZI384LKleuo,LAQD5wEkr18bUiGaYen3J,Xz3bA2PFENVCUtplu51
IjZbnrBJmM2N,Nh0BWuiSndf,kke1PDGRBLuY8y=m6hwdgP31a2zjN7lkpX,mmcNLrXtzfpyCkZlvK5VwG2gujh,shC5qBRV2A0lZ
ddo23ZJtgcY,vvWwO3Tx2dAgcijrFXq,DYakr9g4PVU=kke1PDGRBLuY8y,Nh0BWuiSndf,IjZbnrBJmM2N
zI3ROAZtiUq42rE9WDST68,Dzs8qU2gQMcCSyRhiZn4TFbeGk,dDYUoKi6JFM23p=DYakr9g4PVU,vvWwO3Tx2dAgcijrFXq,ddo23ZJtgcY
QQdAXWBc2GPw,VFjQx6Is28KvzLOmMXtg4GqTwa3,TT8Mxv5Wq7nlC9IscdpPUY6=dDYUoKi6JFM23p,Dzs8qU2gQMcCSyRhiZn4TFbeGk,zI3ROAZtiUq42rE9WDST68
SbjiWeHLQPoazqwp3cODkd7YxVgn,UUkIBz1sgQ9WfNeG6trKXvu0,RRIHDFjoW9w7bSfVPhC=TT8Mxv5Wq7nlC9IscdpPUY6,VFjQx6Is28KvzLOmMXtg4GqTwa3,QQdAXWBc2GPw
from hIVCFnfxSO import *
QQ8pvXNcBfVkP5rRJ7o = mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠫࡈࡒࡅࡂࡐࡈࡖࠬࠀ")
WbzmKSZiuOYrBN7oysJ2dUv = VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠬࡥࡃࡍࡐࡢࠫࠁ")
fyeASVtnR4LshgkWb = x76PfMyAp1L2WejkU3.path.join(ph6VQImjWsE4BT5KUnAN,uVQd103XyvUce2EBtzbYaC(u"࠭ࡴࡦ࡯ࡳࠫࠂ"))
c3cChw0Rua8X = x76PfMyAp1L2WejkU3.path.join(ph6VQImjWsE4BT5KUnAN,Xz3bA2PFENVCUtplu51(u"ࠧࡱࡣࡦ࡯ࡦ࡭ࡥࡴࠩࠃ"))
xhOZdfIkmLaQXio4s3SKW1jC8 = x76PfMyAp1L2WejkU3.path.join(BdO6FDlYv4naqZf1gCGbS7V,UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪࠄ"),ubxGUTt1LraKhVZgpAP(u"ࠩࡗ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡸ࠭ࠅ"))
fHyzKrvteBsh0D6j = KmYxP4q3zoXjrU0JReM
YYbsBdhirgX85GQItzKLoF9cO = TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠪ࠳ࡩࡧࡴࡢ࠱ࡶࡽࡸࡺࡥ࡮࠱ࡸࡷࡦ࡭ࡥࡴࡶࡤࡸࡸ࠭ࠆ")
eviR23cZCwHEVX41F5njWBzpToh7 = uVQd103XyvUce2EBtzbYaC(u"ࠫ࠴ࡪࡡࡵࡣ࠲ࡷࡾࡹࡴࡦ࡯࠲ࡨࡷࡵࡰࡣࡱࡻࠫࠇ")
IgVoGQ16h9Tqi = zI3ROAZtiUq42rE9WDST68(u"ࠬ࠵ࡤࡢࡶࡤ࠳ࡹࡵ࡭ࡣࡵࡷࡳࡳ࡫ࡳࠨࠈ")
zG809xfRJi7yHmeYDwWpbsXot5cU3V = ubxGUTt1LraKhVZgpAP(u"࠭࠯ࡥࡣࡷࡥ࠴ࡲ࡯ࡨࡩࡨࡶࠬࠉ")
UXJ2aVCNoqLB = Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠧ࠰ࡦࡤࡸࡦ࠵࡬ࡰࡩࠪࠊ")
Fo5DCndVi7 = VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠨ࠱ࡧࡥࡹࡧ࠯ࡢࡰࡵࠫࠋ")
def x8IFqMZeJj7suCR4AaGoNXfEHm(ZZtDTHnBXMz):
	if   ZZtDTHnBXMz==HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"࠼࠺࠰ࡸ"): XXxlOLJ9KRjPH382WVCvr6n71 = qPSLFokpQc61Jm4ve0CRGUHhnz()
	elif ZZtDTHnBXMz==QQdAXWBc2GPw(u"࠽࠴࠲ࡹ"): XXxlOLJ9KRjPH382WVCvr6n71 = p3pjrEcdKBfsDZw4qSJ(fyeASVtnR4LshgkWb,CCxMXuNUEzolDZTKrBJ,CCxMXuNUEzolDZTKrBJ)
	elif ZZtDTHnBXMz==QQdAXWBc2GPw(u"࠷࠵࠴ࡺ"): XXxlOLJ9KRjPH382WVCvr6n71 = p3pjrEcdKBfsDZw4qSJ(c3cChw0Rua8X,CCxMXuNUEzolDZTKrBJ,CCxMXuNUEzolDZTKrBJ)
	elif ZZtDTHnBXMz==SbjiWeHLQPoazqwp3cODkd7YxVgn(u"࠸࠶࠶ࡻ"): XXxlOLJ9KRjPH382WVCvr6n71 = p3pjrEcdKBfsDZw4qSJ(xhOZdfIkmLaQXio4s3SKW1jC8,DD5cFIejQa2X4BgAu9GWPyJ3tC7,CCxMXuNUEzolDZTKrBJ)
	elif ZZtDTHnBXMz==yST5AHEfvPmcWpwGuh2BJ(u"࠹࠷࠸ࡼ"): XXxlOLJ9KRjPH382WVCvr6n71 = KV7Fd863DOjaUP(fHyzKrvteBsh0D6j,CCxMXuNUEzolDZTKrBJ)
	elif ZZtDTHnBXMz==P0qdZI384LKleuo(u"࠺࠸࠺ࡽ"): XXxlOLJ9KRjPH382WVCvr6n71 = htSoaxBMVvLl5ATR1gKP7jYn(CCxMXuNUEzolDZTKrBJ)
	elif ZZtDTHnBXMz==kke1PDGRBLuY8y(u"࠻࠺࠶ࡾ"): XXxlOLJ9KRjPH382WVCvr6n71 = UbLgiyCKjaneD1qp45vlF2rhdA()
	elif ZZtDTHnBXMz==UUkIBz1sgQ9WfNeG6trKXvu0(u"࠼࠻࠱ࡿ"): XXxlOLJ9KRjPH382WVCvr6n71 = p3pjrEcdKBfsDZw4qSJ(YYbsBdhirgX85GQItzKLoF9cO,DD5cFIejQa2X4BgAu9GWPyJ3tC7,CCxMXuNUEzolDZTKrBJ)
	elif ZZtDTHnBXMz==LAQD5wEkr18bUiGaYen3J(u"࠽࠵࠳ࢀ"): XXxlOLJ9KRjPH382WVCvr6n71 = p3pjrEcdKBfsDZw4qSJ(eviR23cZCwHEVX41F5njWBzpToh7,DD5cFIejQa2X4BgAu9GWPyJ3tC7,CCxMXuNUEzolDZTKrBJ)
	elif ZZtDTHnBXMz==IjZbnrBJmM2N(u"࠷࠶࠵ࢁ"): XXxlOLJ9KRjPH382WVCvr6n71 = p3pjrEcdKBfsDZw4qSJ(IgVoGQ16h9Tqi,DD5cFIejQa2X4BgAu9GWPyJ3tC7,CCxMXuNUEzolDZTKrBJ)
	elif ZZtDTHnBXMz==Mmpr0o76iWJvz1kTtfgI8hES(u"࠸࠷࠷ࢂ"): XXxlOLJ9KRjPH382WVCvr6n71 = p3pjrEcdKBfsDZw4qSJ(zG809xfRJi7yHmeYDwWpbsXot5cU3V,DD5cFIejQa2X4BgAu9GWPyJ3tC7,CCxMXuNUEzolDZTKrBJ)
	elif ZZtDTHnBXMz==Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"࠹࠸࠹ࢃ"): XXxlOLJ9KRjPH382WVCvr6n71 = p3pjrEcdKBfsDZw4qSJ(UXJ2aVCNoqLB,DD5cFIejQa2X4BgAu9GWPyJ3tC7,CCxMXuNUEzolDZTKrBJ)
	elif ZZtDTHnBXMz==S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"࠺࠹࠻ࢄ"): XXxlOLJ9KRjPH382WVCvr6n71 = p3pjrEcdKBfsDZw4qSJ(Fo5DCndVi7,DD5cFIejQa2X4BgAu9GWPyJ3tC7,CCxMXuNUEzolDZTKrBJ)
	elif ZZtDTHnBXMz==SbjiWeHLQPoazqwp3cODkd7YxVgn(u"࠻࠺࠽ࢅ"): XXxlOLJ9KRjPH382WVCvr6n71 = LvyIPAjbNRTeEskM85(CCxMXuNUEzolDZTKrBJ)
	elif ZZtDTHnBXMz==QTUBCcehw6qPd4x(u"࠼࠻࠸ࢆ"): XXxlOLJ9KRjPH382WVCvr6n71 = TMPGe7x3OCJ()
	else: XXxlOLJ9KRjPH382WVCvr6n71 = DD5cFIejQa2X4BgAu9GWPyJ3tC7
	return XXxlOLJ9KRjPH382WVCvr6n71
def qPSLFokpQc61Jm4ve0CRGUHhnz():
	xEWOGoXfnYsj,vahKXMJqIAdSsrN = qXH7aUcZCjb21E(fyeASVtnR4LshgkWb)
	ccd5GVOTbFZALtQmyxBY6EkwH,yyUMH5a6LjzheVEFTrOs8kdPu01m = qXH7aUcZCjb21E(c3cChw0Rua8X)
	wKE7k8Y4ZVSC,FF84iVqzbjBgPLCQNYwTvJ3X1n = qXH7aUcZCjb21E(xhOZdfIkmLaQXio4s3SKW1jC8)
	vvbuCBOaDK1EJIqic3SlhzYe,taLeJ6GzwNQ18u7Bxc4UvPbfor = HTuoYBfsP0GE(fHyzKrvteBsh0D6j)
	vvbuCBOaDK1EJIqic3SlhzYe -= Xz3bA2PFENVCUtplu51(u"࠹࠶࠹࠸࠷ࢇ")
	taLeJ6GzwNQ18u7Bxc4UvPbfor -= DYakr9g4PVU(u"࠱࢈")
	uvA8ymg3UDos17pckI = mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠩࠣࠬࠬࠌ")+N7VBgMsDtbvc(xEWOGoXfnYsj)+IjZbnrBJmM2N(u"ࠪࠤ࠲ࠦࠧࠍ")+str(vahKXMJqIAdSsrN)+QQdAXWBc2GPw(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬࠎ")
	NNjD4IlzdF = mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠬࠦࠨࠨࠏ")+N7VBgMsDtbvc(ccd5GVOTbFZALtQmyxBY6EkwH)+Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"࠭ࠠ࠮ࠢࠪࠐ")+str(yyUMH5a6LjzheVEFTrOs8kdPu01m)+ddo23ZJtgcY(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨࠑ")
	ZH7xA3UEkKgi9wpOco = DYakr9g4PVU(u"ࠨࠢࠫࠫࠒ")+N7VBgMsDtbvc(wKE7k8Y4ZVSC)+yST5AHEfvPmcWpwGuh2BJ(u"ࠩࠣ࠱ࠥ࠭ࠓ")+str(FF84iVqzbjBgPLCQNYwTvJ3X1n)+TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࠔ")
	xBEdu9nP64gUk70 = ubxGUTt1LraKhVZgpAP(u"ࠫࠥ࠮ࠧࠕ")+N7VBgMsDtbvc(vvbuCBOaDK1EJIqic3SlhzYe)+yST5AHEfvPmcWpwGuh2BJ(u"ࠬ࠯ࠧࠖ")
	hvgOo9D3itx8umIB = xEWOGoXfnYsj+ccd5GVOTbFZALtQmyxBY6EkwH+wKE7k8Y4ZVSC+vvbuCBOaDK1EJIqic3SlhzYe
	vvKNfzy0VtHxObGpT = vahKXMJqIAdSsrN+yyUMH5a6LjzheVEFTrOs8kdPu01m+FF84iVqzbjBgPLCQNYwTvJ3X1n+taLeJ6GzwNQ18u7Bxc4UvPbfor
	pnmsJqCWIHVk2Y6xPvl9Q0Ez8r = BWNPxIG7vqdTy85pjHzUOrK3(u"࠭ࠠࠩࠩࠗ")+N7VBgMsDtbvc(hvgOo9D3itx8umIB)+Nh0BWuiSndf(u"ࠧࠡ࠯ࠣࠫ࠘")+str(vvKNfzy0VtHxObGpT)+SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩ࠙")
	MQtuaShrKTbdZFJ5nsR7D(S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠩ࡯࡭ࡳࡱࠧࠚ"),WbzmKSZiuOYrBN7oysJ2dUv+Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ุ้ࠪำࠠศๆฯ้๏฿ࠧࠛ")+pnmsJqCWIHVk2Y6xPvl9Q0Ez8r,b8Qe150xVaJsnDSv,TT8Mxv5Wq7nlC9IscdpPUY6(u"࠸࠶࠸ࢉ"))
	MQtuaShrKTbdZFJ5nsR7D(VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠫࡱ࡯࡮࡬ࠩࠜ"),rC3Tlno96KjLDIvBaSWUbR8+RRIHDFjoW9w7bSfVPhC(u"ࠬࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫࠝ")+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,yST5AHEfvPmcWpwGuh2BJ(u"࠻࠼࠽࠾ࢊ"))
	MQtuaShrKTbdZFJ5nsR7D(ubxGUTt1LraKhVZgpAP(u"࠭࡬ࡪࡰ࡮ࠫࠞ"),WbzmKSZiuOYrBN7oysJ2dUv+Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠧๆีะࠤฬ๊ๅๅใสฮࠥอไๆฦๅฮฮ࠭ࠟ")+uvA8ymg3UDos17pckI,b8Qe150xVaJsnDSv,kke1PDGRBLuY8y(u"࠺࠸࠶ࢋ"))
	MQtuaShrKTbdZFJ5nsR7D(SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠨ࡮࡬ࡲࡰ࠭ࠠ"),WbzmKSZiuOYrBN7oysJ2dUv+dDYUoKi6JFM23p(u"่ࠩืาࠦวๅ็็ๅฬะࠠศๆฺ่฿๎ืสࠩࠡ")+NNjD4IlzdF,b8Qe150xVaJsnDSv,S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"࠻࠹࠸ࢌ"))
	MQtuaShrKTbdZFJ5nsR7D(BWNPxIG7vqdTy85pjHzUOrK3(u"ࠪࡰ࡮ࡴ࡫ࠨࠢ"),WbzmKSZiuOYrBN7oysJ2dUv+kke1PDGRBLuY8y(u"ู๊ࠫอࠡษ็ูํืࠠศๆๅำ๏๋ษࠨࠣ")+ZH7xA3UEkKgi9wpOco,b8Qe150xVaJsnDSv,zI3ROAZtiUq42rE9WDST68(u"࠼࠺࠳ࢍ"))
	MQtuaShrKTbdZFJ5nsR7D(shC5qBRV2A0lZ(u"ࠬࡲࡩ࡯࡭ࠪࠤ"),WbzmKSZiuOYrBN7oysJ2dUv+dDYUoKi6JFM23p(u"࠭สโำํ฾๋ࠥไโุࠢ์ึࠦวๅวูหๆอสࠨࠥ")+xBEdu9nP64gUk70,b8Qe150xVaJsnDSv,dDYUoKi6JFM23p(u"࠽࠴࠵ࢎ"))
	hRWC8YSFvsm4JHOMVIne3jquZ.setSetting(LAQD5wEkr18bUiGaYen3J(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡶࡪ࡬ࡲࡦࡵ࡫ࠫࠦ"),b8Qe150xVaJsnDSv)
	return
def UbLgiyCKjaneD1qp45vlF2rhdA():
	gjZ48TKqayoQ0w1FXLhSJ9AdVBMrE = CCxMXuNUEzolDZTKrBJ if uVQd103XyvUce2EBtzbYaC(u"ࠨ࠱ࠪࠧ") in BdO6FDlYv4naqZf1gCGbS7V else DD5cFIejQa2X4BgAu9GWPyJ3tC7
	if not gjZ48TKqayoQ0w1FXLhSJ9AdVBMrE:
		tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,vvWwO3Tx2dAgcijrFXq(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬࠨ"),Nh0BWuiSndf(u"ࠪ฽๊๊๊สࠢอ๊฽๐แࠡษ็ะ์อาࠡ็อ์ๆืษࠡใๅ฻๊ࠥรอ้ีอࠥ๐่็ๅึࠤ࠳࠴้ࠠฮ๊หื้ࠠๅ์ึࠤ๊์ࠠ็๊฼ࠤ๏๎ๆไีࠪࠩ"))
		return
	iPKbSRLnl2HJxFMjwQkGza = hRWC8YSFvsm4JHOMVIne3jquZ.getSetting(QTUBCcehw6qPd4x(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡳࡧࡩࡶࡪࡹࡨࠨࠪ"))
	if not iPKbSRLnl2HJxFMjwQkGza: TMPGe7x3OCJ()
	xEWOGoXfnYsj,vahKXMJqIAdSsrN = qXH7aUcZCjb21E(YYbsBdhirgX85GQItzKLoF9cO)
	ccd5GVOTbFZALtQmyxBY6EkwH,yyUMH5a6LjzheVEFTrOs8kdPu01m = qXH7aUcZCjb21E(eviR23cZCwHEVX41F5njWBzpToh7)
	wKE7k8Y4ZVSC,FF84iVqzbjBgPLCQNYwTvJ3X1n = qXH7aUcZCjb21E(IgVoGQ16h9Tqi)
	vvbuCBOaDK1EJIqic3SlhzYe,taLeJ6GzwNQ18u7Bxc4UvPbfor = qXH7aUcZCjb21E(zG809xfRJi7yHmeYDwWpbsXot5cU3V)
	bqUs6c2iIm,fJBOAm4a2uZckWVGbLtqM = qXH7aUcZCjb21E(UXJ2aVCNoqLB)
	zze2Ep7yrIYGVlL4twZm,tR2EP973knOj1MbGKxWB5csAyvQ = qXH7aUcZCjb21E(Fo5DCndVi7)
	uvA8ymg3UDos17pckI = uVQd103XyvUce2EBtzbYaC(u"ࠬࠦࠨࠨࠫ")+N7VBgMsDtbvc(xEWOGoXfnYsj)+ddo23ZJtgcY(u"࠭ࠠ࠮ࠢࠪࠬ")+str(vahKXMJqIAdSsrN)+shC5qBRV2A0lZ(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨ࠭")
	NNjD4IlzdF = RRIHDFjoW9w7bSfVPhC(u"ࠨࠢࠫࠫ࠮")+N7VBgMsDtbvc(ccd5GVOTbFZALtQmyxBY6EkwH)+uVQd103XyvUce2EBtzbYaC(u"ࠩࠣ࠱ࠥ࠭࠯")+str(yyUMH5a6LjzheVEFTrOs8kdPu01m)+RRIHDFjoW9w7bSfVPhC(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫ࠰")
	ZH7xA3UEkKgi9wpOco = ddo23ZJtgcY(u"ࠫࠥ࠮ࠧ࠱")+N7VBgMsDtbvc(wKE7k8Y4ZVSC)+vvWwO3Tx2dAgcijrFXq(u"ࠬࠦ࠭ࠡࠩ࠲")+str(FF84iVqzbjBgPLCQNYwTvJ3X1n)+ubxGUTt1LraKhVZgpAP(u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧ࠳")
	xBEdu9nP64gUk70 = dDYUoKi6JFM23p(u"ࠧࠡࠪࠪ࠴")+N7VBgMsDtbvc(vvbuCBOaDK1EJIqic3SlhzYe)+shC5qBRV2A0lZ(u"ࠨࠢ࠰ࠤࠬ࠵")+str(taLeJ6GzwNQ18u7Bxc4UvPbfor)+TYf7Dc06PQgy1vEV9(u"ࠩࠣࡪ࡮ࡲࡥࡴࠫࠪ࠶")
	SV9MbwKsyeg375iu = kke1PDGRBLuY8y(u"ࠪࠤ࠭࠭࠷")+N7VBgMsDtbvc(bqUs6c2iIm)+mQNonhS7CV2BXOv(u"ࠫࠥ࠳ࠠࠨ࠸")+str(fJBOAm4a2uZckWVGbLtqM)+dDYUoKi6JFM23p(u"ࠬࠦࡦࡪ࡮ࡨࡷ࠮࠭࠹")
	PufAmS6avGxZqJT0Mezi8Xo12 = DYakr9g4PVU(u"࠭ࠠࠩࠩ࠺")+N7VBgMsDtbvc(zze2Ep7yrIYGVlL4twZm)+Xz3bA2PFENVCUtplu51(u"ࠧࠡ࠯ࠣࠫ࠻")+str(tR2EP973knOj1MbGKxWB5csAyvQ)+mQNonhS7CV2BXOv(u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩ࠼")
	hvgOo9D3itx8umIB = xEWOGoXfnYsj+ccd5GVOTbFZALtQmyxBY6EkwH+wKE7k8Y4ZVSC+vvbuCBOaDK1EJIqic3SlhzYe+bqUs6c2iIm+zze2Ep7yrIYGVlL4twZm
	vvKNfzy0VtHxObGpT = vahKXMJqIAdSsrN+yyUMH5a6LjzheVEFTrOs8kdPu01m+FF84iVqzbjBgPLCQNYwTvJ3X1n+taLeJ6GzwNQ18u7Bxc4UvPbfor+fJBOAm4a2uZckWVGbLtqM+tR2EP973knOj1MbGKxWB5csAyvQ
	pnmsJqCWIHVk2Y6xPvl9Q0Ez8r = Mmpr0o76iWJvz1kTtfgI8hES(u"ࠩࠣࠬࠬ࠽")+N7VBgMsDtbvc(hvgOo9D3itx8umIB)+uVQd103XyvUce2EBtzbYaC(u"ࠪࠤ࠲ࠦࠧ࠾")+str(vvKNfzy0VtHxObGpT)+m6hwdgP31a2zjN7lkpX(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬ࠿")
	MQtuaShrKTbdZFJ5nsR7D(VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠬࡲࡩ࡯࡭ࠪࡀ"),WbzmKSZiuOYrBN7oysJ2dUv+shC5qBRV2A0lZ(u"࠭ลฺูสลࠥืฮึหࠣๆึอมส๋ࠢ็ฯอศสࠩࡁ"),b8Qe150xVaJsnDSv,ubxGUTt1LraKhVZgpAP(u"࠷࠶࠺࢏"))
	MQtuaShrKTbdZFJ5nsR7D(Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠧ࡭࡫ࡱ࡯ࠬࡂ"),WbzmKSZiuOYrBN7oysJ2dUv+RRIHDFjoW9w7bSfVPhC(u"ࠨ็ึัࠥอไอ็ํ฽ࠬࡃ")+pnmsJqCWIHVk2Y6xPvl9Q0Ez8r,b8Qe150xVaJsnDSv,vvWwO3Tx2dAgcijrFXq(u"࠸࠷࠺࢐"))
	MQtuaShrKTbdZFJ5nsR7D(TYf7Dc06PQgy1vEV9(u"ࠩ࡯࡭ࡳࡱࠧࡄ"),rC3Tlno96KjLDIvBaSWUbR8+Mmpr0o76iWJvz1kTtfgI8hES(u"ࠪࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡࠩࡅ")+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,zI3ROAZtiUq42rE9WDST68(u"࠻࠼࠽࠾࢑"))
	MQtuaShrKTbdZFJ5nsR7D(ddo23ZJtgcY(u"ࠫࡱ࡯࡮࡬ࠩࡆ"),WbzmKSZiuOYrBN7oysJ2dUv+Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"๋ࠬำฮ่่ࠢๆอสࠡࡷࡶࡥ࡬࡫ࡳࡵࡣࡷࡷࠬࡇ")+uvA8ymg3UDos17pckI,b8Qe150xVaJsnDSv,vvWwO3Tx2dAgcijrFXq(u"࠺࠹࠶࢒"))
	MQtuaShrKTbdZFJ5nsR7D(S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"࠭࡬ࡪࡰ࡮ࠫࡈ"),WbzmKSZiuOYrBN7oysJ2dUv+SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠧๆีะࠤ๊๊แศฬࠣࡨࡷࡵࡰࡣࡱࡻࠫࡉ")+NNjD4IlzdF,b8Qe150xVaJsnDSv,yST5AHEfvPmcWpwGuh2BJ(u"࠻࠺࠸࢓"))
	MQtuaShrKTbdZFJ5nsR7D(UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠨ࡮࡬ࡲࡰ࠭ࡊ"),WbzmKSZiuOYrBN7oysJ2dUv+mQNonhS7CV2BXOv(u"่ࠩืาࠦๅๅใสฮࠥࡺ࡯࡮ࡤࡶࡸࡴࡴࡥࡴࠩࡋ")+ZH7xA3UEkKgi9wpOco,b8Qe150xVaJsnDSv,mQNonhS7CV2BXOv(u"࠼࠻࠳࢔"))
	MQtuaShrKTbdZFJ5nsR7D(BWNPxIG7vqdTy85pjHzUOrK3(u"ࠪࡰ࡮ࡴ࡫ࠨࡌ"),WbzmKSZiuOYrBN7oysJ2dUv+yST5AHEfvPmcWpwGuh2BJ(u"ู๊ࠫอࠡ็็ๅฬะࠠ࡭ࡱࡪ࡫ࡪࡸࠧࡍ")+xBEdu9nP64gUk70,b8Qe150xVaJsnDSv,Mmpr0o76iWJvz1kTtfgI8hES(u"࠽࠵࠵࢕"))
	MQtuaShrKTbdZFJ5nsR7D(QTUBCcehw6qPd4x(u"ࠬࡲࡩ࡯࡭ࠪࡎ"),WbzmKSZiuOYrBN7oysJ2dUv+vvWwO3Tx2dAgcijrFXq(u"࠭ๅิฯ้้ࠣ็วหࠢ࡯ࡳ࡬࠭ࡏ")+SV9MbwKsyeg375iu,b8Qe150xVaJsnDSv,DYakr9g4PVU(u"࠷࠶࠷࢖"))
	MQtuaShrKTbdZFJ5nsR7D(shC5qBRV2A0lZ(u"ࠧ࡭࡫ࡱ࡯ࠬࡐ"),WbzmKSZiuOYrBN7oysJ2dUv+TYf7Dc06PQgy1vEV9(u"ࠨ็ึั๋ࠥไโษอࠤࡦࡴࡲࠨࡑ")+PufAmS6avGxZqJT0Mezi8Xo12,b8Qe150xVaJsnDSv,VFjQx6Is28KvzLOmMXtg4GqTwa3(u"࠸࠷࠹ࢗ"))
	hRWC8YSFvsm4JHOMVIne3jquZ.setSetting(BWNPxIG7vqdTy85pjHzUOrK3(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡸࡥࡧࡴࡨࡷ࡭࠭ࡒ"),b8Qe150xVaJsnDSv)
	return
def TMPGe7x3OCJ():
	aVwGA2kFY6u4m = BjMmX1vNrnzSAf(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ࡓ"),kke1PDGRBLuY8y(u"้้๊ࠫࠡ์฼้้ࠦวๅฬ้฼๏็ฺ่ࠠา็ࠥ࠴࠮ࠡสิ๊ฬ๋ฬࠡ฻่หิࠦศฮษฯอࠥหไ๊ࠢศ฽฼อมࠡำัูฮࠦวๅไิหฦฯ้ࠠษ็็ฯอศสࠢ็่๊๊แศฬࠣ์ฬ๊ๅอๆาหฯࠦวๅฬํࠤุ๎แࠡ์่ืาํวࠡษ็ฬึ์วๆฮࠣ࠲࠳ࠦ็ๅࠢอี๏ีࠠฦ฻ฺหฦࠦ็ั้ࠣห้ืฮึหࠣห้ศๆࠡมࠤࠫࡔ"))
	if aVwGA2kFY6u4m==-shC5qBRV2A0lZ(u"࠳࢘"): return
	if aVwGA2kFY6u4m:
		import subprocess as BN0RwpG46vZbYz
		try:
			BN0RwpG46vZbYz.Popen(TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠬࡹࡵࠨࡕ"))
			xxHp6vZ9YM8AJfRVhG3 = CCxMXuNUEzolDZTKrBJ
		except: xxHp6vZ9YM8AJfRVhG3 = DD5cFIejQa2X4BgAu9GWPyJ3tC7
		if xxHp6vZ9YM8AJfRVhG3:
			ddFLp7Kov9EZyqPuJfg = YYbsBdhirgX85GQItzKLoF9cO+pldxivXC5wbTB2O8q+eviR23cZCwHEVX41F5njWBzpToh7+pldxivXC5wbTB2O8q+IgVoGQ16h9Tqi+pldxivXC5wbTB2O8q+zG809xfRJi7yHmeYDwWpbsXot5cU3V+pldxivXC5wbTB2O8q+UXJ2aVCNoqLB+pldxivXC5wbTB2O8q+Fo5DCndVi7
			rrl0HN4ZdziIoa2EDsAp96y8tOGq = BN0RwpG46vZbYz.Popen(mmcNLrXtzfpyCkZlvK5VwG2gujh(u"࠭ࡳࡶࠢ࠰ࡧࠥࠨࡣࡩ࡯ࡲࡨࠥ࠳ࡒࠡ࠲࠺࠻࠼ࠦࠧࡖ")+ddFLp7Kov9EZyqPuJfg+Mmpr0o76iWJvz1kTtfgI8hES(u"ࠧࠣࠩࡗ"),shell=CCxMXuNUEzolDZTKrBJ,stdin=BN0RwpG46vZbYz.PIPE,stdout=BN0RwpG46vZbYz.PIPE,stderr=BN0RwpG46vZbYz.PIPE)
			tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,RRIHDFjoW9w7bSfVPhC(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫࡘ"),LAQD5wEkr18bUiGaYen3J(u"้ࠩะาะฺࠠ็็๎ฮࠦลฺูสลࠥอไาะุอ࡙ࠬ"))
			qMGn9u2ckaXejCgUQhYTDP(DD5cFIejQa2X4BgAu9GWPyJ3tC7)
		else: tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,mQNonhS7CV2BXOv(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࡚࠭"),ubxGUTt1LraKhVZgpAP(u"ࠫ฾๋ไ๋หࠣษ฾฽วยࠢิาฺฯࠠศๆๅีฬวษ๊ࠡส่่ะวษหࠣฮาะวอࠢหี๋อๅอࠢࠣࡶࡴࡵࡴࠡࠢฦ์ࠥࠦࡳࡶࡲࡨࡶࡺࡹࡥࡳࠢࠣวํࠦࠠࡴࡷࠣࠤํา็ศิๆࠤ้อ๋๊ࠠฯำࠥ็๊่๊ࠢิฬࠦวๅสิ๊ฬ๋ฬࠡ࠰࠱ࠤศ๎ࠠไ๊า๎ࠥเ๊าࠢๅหิืฺࠠๆ์ࠤฬูสฯัส้ࠥํะศࠢส่อืๆศ็ฯ࡛ࠫ"))
	return
def N7VBgMsDtbvc(hvgOo9D3itx8umIB):
	for aBuKDWVb3eg2d5Ch in [dDYUoKi6JFM23p(u"ࠬࡈࠧ࡜"),TT8Mxv5Wq7nlC9IscdpPUY6(u"࠭ࡋࡃࠩ࡝"),DYakr9g4PVU(u"ࠧࡎࡄࠪ࡞"),QTUBCcehw6qPd4x(u"ࠨࡉࡅࠫ࡟"),DYakr9g4PVU(u"ࠩࡗࡆࠬࡠ")]:
		if hvgOo9D3itx8umIB<QTUBCcehw6qPd4x(u"࠴࠴࠷࠺࢙"): break
		else: hvgOo9D3itx8umIB /= vvWwO3Tx2dAgcijrFXq(u"࠵࠵࠸࠴࠯࠲࢚")
	pnmsJqCWIHVk2Y6xPvl9Q0Ez8r = BWNPxIG7vqdTy85pjHzUOrK3(u"ࠥࠩ࠸࠴࠱ࡧࠢࠨࡷࠧࡡ")%(hvgOo9D3itx8umIB,aBuKDWVb3eg2d5Ch)
	return pnmsJqCWIHVk2Y6xPvl9Q0Ez8r
def qXH7aUcZCjb21E(nAzCvXVpUgOW56l2SJb0Iw1qo=SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠫ࠳࠭ࡢ")):
	global NgF7IL2ZUdJVnXcujKrey,uVTWyEIYMCbLt0AlqGR4Qi2kFKO
	NgF7IL2ZUdJVnXcujKrey,uVTWyEIYMCbLt0AlqGR4Qi2kFKO = zI3ROAZtiUq42rE9WDST68(u"࠵࢛"),zI3ROAZtiUq42rE9WDST68(u"࠵࢛")
	def GbfoVWSe5mZQKAyF4O1(nAzCvXVpUgOW56l2SJb0Iw1qo):
		global NgF7IL2ZUdJVnXcujKrey,uVTWyEIYMCbLt0AlqGR4Qi2kFKO
		if x76PfMyAp1L2WejkU3.path.exists(nAzCvXVpUgOW56l2SJb0Iw1qo):
			if ddo23ZJtgcY(u"࠶࢜") and Xz3bA2PFENVCUtplu51(u"ࠬࡹࡣࡢࡰࡧ࡭ࡷ࠭ࡣ") in dir(x76PfMyAp1L2WejkU3):
				for H2q1t9ucDiQfZN0p5m in x76PfMyAp1L2WejkU3.scandir(nAzCvXVpUgOW56l2SJb0Iw1qo):
					if H2q1t9ucDiQfZN0p5m.is_dir(follow_symlinks=DD5cFIejQa2X4BgAu9GWPyJ3tC7):
						GbfoVWSe5mZQKAyF4O1(H2q1t9ucDiQfZN0p5m.path)
					elif H2q1t9ucDiQfZN0p5m.is_file(follow_symlinks=DD5cFIejQa2X4BgAu9GWPyJ3tC7):
						NgF7IL2ZUdJVnXcujKrey += H2q1t9ucDiQfZN0p5m.stat().st_size
						uVTWyEIYMCbLt0AlqGR4Qi2kFKO += Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"࠱࢝")
			else:
				for H2q1t9ucDiQfZN0p5m in x76PfMyAp1L2WejkU3.listdir(nAzCvXVpUgOW56l2SJb0Iw1qo):
					xYV8a72btiCTfXgdlk5u1S6pMWy = x76PfMyAp1L2WejkU3.path.abspath(x76PfMyAp1L2WejkU3.path.join(nAzCvXVpUgOW56l2SJb0Iw1qo,H2q1t9ucDiQfZN0p5m))
					if x76PfMyAp1L2WejkU3.path.isdir(xYV8a72btiCTfXgdlk5u1S6pMWy):
						GbfoVWSe5mZQKAyF4O1(xYV8a72btiCTfXgdlk5u1S6pMWy)
					elif x76PfMyAp1L2WejkU3.path.isfile(xYV8a72btiCTfXgdlk5u1S6pMWy):
						hvgOo9D3itx8umIB,vvKNfzy0VtHxObGpT = HTuoYBfsP0GE(xYV8a72btiCTfXgdlk5u1S6pMWy)
						NgF7IL2ZUdJVnXcujKrey += hvgOo9D3itx8umIB
						uVTWyEIYMCbLt0AlqGR4Qi2kFKO += vvKNfzy0VtHxObGpT
		return
	try: GbfoVWSe5mZQKAyF4O1(nAzCvXVpUgOW56l2SJb0Iw1qo)
	except: pass
	return NgF7IL2ZUdJVnXcujKrey,uVTWyEIYMCbLt0AlqGR4Qi2kFKO
def htSoaxBMVvLl5ATR1gKP7jYn(showDialogs):
	if showDialogs:
		aVwGA2kFY6u4m = BjMmX1vNrnzSAf(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,UUkIBz1sgQ9WfNeG6trKXvu0(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩࡤ"),rC3Tlno96KjLDIvBaSWUbR8+IjZbnrBJmM2N(u"่ࠧๆࠣฮึ๐ฯࠡ็ึัࠬࡥ")+eeN6dTEnkJxI+dDYUoKi6JFM23p(u"ࠨ็ฯ่ิࠦวๅ็็ๅฬะࠠศๆ่ศ็ะษࠡ࠰࠱ࠤํ๋ฬๅัࠣห้๋ไโษอࠤฬ๊ๅื฼๋฻ฮࠦ࠮࠯๋้ࠢั๊ฯࠡษ็ูํืࠠศๆๅำ๏๋ษࠡ࠰࠱ࠤํะแา์฽ࠤ๊๊แࠡื๋ีࠥอไฦุสๅฬะࠧࡦ")+eeN6dTEnkJxI+UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠩยࠥࠦ࠭ࡧ")+hAIp8kmC36T5WFPMSXOwnNbtD)
		if aVwGA2kFY6u4m!=yST5AHEfvPmcWpwGuh2BJ(u"࠲࢞"): return
	p3pjrEcdKBfsDZw4qSJ(fyeASVtnR4LshgkWb,CCxMXuNUEzolDZTKrBJ,DD5cFIejQa2X4BgAu9GWPyJ3tC7)
	p3pjrEcdKBfsDZw4qSJ(c3cChw0Rua8X,CCxMXuNUEzolDZTKrBJ,DD5cFIejQa2X4BgAu9GWPyJ3tC7)
	p3pjrEcdKBfsDZw4qSJ(xhOZdfIkmLaQXio4s3SKW1jC8,DD5cFIejQa2X4BgAu9GWPyJ3tC7,DD5cFIejQa2X4BgAu9GWPyJ3tC7)
	KV7Fd863DOjaUP(fHyzKrvteBsh0D6j,DD5cFIejQa2X4BgAu9GWPyJ3tC7)
	if showDialogs:
		tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,QQdAXWBc2GPw(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ࡨ"),HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠫฯ๋ࠠศๆ่ืาࠦศ็ฮสัࠬࡩ"))
		qMGn9u2ckaXejCgUQhYTDP(DD5cFIejQa2X4BgAu9GWPyJ3tC7)
	return
def LvyIPAjbNRTeEskM85(showDialogs):
	if showDialogs:
		aVwGA2kFY6u4m = BjMmX1vNrnzSAf(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,Nh0BWuiSndf(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨࡪ"),rC3Tlno96KjLDIvBaSWUbR8+m6hwdgP31a2zjN7lkpX(u"࠭็ๅࠢอี๏ีࠠๆีะࠤ๊๊แศฬࠪ࡫")+eeN6dTEnkJxI+vvWwO3Tx2dAgcijrFXq(u"ࠧࡶࡵࡤ࡫ࡪࡹࡴࡢࡶࡶࠤ࠳࠴ࠠࡥࡴࡲࡴࡧࡵࡸࠡ࠰࠱ࠤࡹࡵ࡭ࡣࡵࡷࡳࡳ࡫ࡳࠡ࠰࠱ࠤࡱࡵࡧࡨࡧࡵࠤ࠳࠴ࠠ࡭ࡱࡪࠤ࠳࠴ࠠࡢࡰࡵࠫ࡬")+eeN6dTEnkJxI+vvWwO3Tx2dAgcijrFXq(u"ࠨࡁࠤࠥࠬ࡭")+hAIp8kmC36T5WFPMSXOwnNbtD)
		if aVwGA2kFY6u4m!=VFjQx6Is28KvzLOmMXtg4GqTwa3(u"࠳࢟"): return
	p3pjrEcdKBfsDZw4qSJ(YYbsBdhirgX85GQItzKLoF9cO,DD5cFIejQa2X4BgAu9GWPyJ3tC7,DD5cFIejQa2X4BgAu9GWPyJ3tC7)
	p3pjrEcdKBfsDZw4qSJ(eviR23cZCwHEVX41F5njWBzpToh7,DD5cFIejQa2X4BgAu9GWPyJ3tC7,DD5cFIejQa2X4BgAu9GWPyJ3tC7)
	p3pjrEcdKBfsDZw4qSJ(IgVoGQ16h9Tqi,DD5cFIejQa2X4BgAu9GWPyJ3tC7,DD5cFIejQa2X4BgAu9GWPyJ3tC7)
	p3pjrEcdKBfsDZw4qSJ(zG809xfRJi7yHmeYDwWpbsXot5cU3V,DD5cFIejQa2X4BgAu9GWPyJ3tC7,DD5cFIejQa2X4BgAu9GWPyJ3tC7)
	p3pjrEcdKBfsDZw4qSJ(UXJ2aVCNoqLB,DD5cFIejQa2X4BgAu9GWPyJ3tC7,DD5cFIejQa2X4BgAu9GWPyJ3tC7)
	p3pjrEcdKBfsDZw4qSJ(Fo5DCndVi7,DD5cFIejQa2X4BgAu9GWPyJ3tC7,DD5cFIejQa2X4BgAu9GWPyJ3tC7)
	if showDialogs:
		tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,kke1PDGRBLuY8y(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ࡮"),BWNPxIG7vqdTy85pjHzUOrK3(u"ࠪฮ๊ࠦวๅ็ึัࠥฮๆอษะࠫ࡯"))
		qMGn9u2ckaXejCgUQhYTDP(DD5cFIejQa2X4BgAu9GWPyJ3tC7)
	return
def KV7Fd863DOjaUP(BqDs7wImSo05JbjR9nLrTzF,showDialogs):
	if showDialogs:
		aVwGA2kFY6u4m = BjMmX1vNrnzSAf(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧࡰ"),rC3Tlno96KjLDIvBaSWUbR8+IjZbnrBJmM2N(u"ࠬํไࠡฬิ๎ิࠦๅิฯ้ࠣาะ่๋ษอࠤ๊๊แࠡื๋ีࠥอไอๆาࠤฤࠧࠡࠨࡱ")+hAIp8kmC36T5WFPMSXOwnNbtD)
		if aVwGA2kFY6u4m!=VFjQx6Is28KvzLOmMXtg4GqTwa3(u"࠴ࢠ"): return
	KWfFCYyj7iTlts = jA69Ts3CqJli7.connect(BqDs7wImSo05JbjR9nLrTzF)
	KWfFCYyj7iTlts.text_factory = str
	Yn98v3MRdasNfWB2SAG6TOV1m4tq = KWfFCYyj7iTlts.cursor()
	Yn98v3MRdasNfWB2SAG6TOV1m4tq.execute(QQdAXWBc2GPw(u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࡵࡧࡴࡩ࠽ࠪࡲ"))
	Yn98v3MRdasNfWB2SAG6TOV1m4tq.execute(LAQD5wEkr18bUiGaYen3J(u"ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥࡹࡩࡻࡧࡶ࠿ࠬࡳ"))
	Yn98v3MRdasNfWB2SAG6TOV1m4tq.execute(kke1PDGRBLuY8y(u"ࠨࡆࡈࡐࡊ࡚ࡅࠡࡈࡕࡓࡒࠦࡴࡦࡺࡷࡹࡷ࡫࠻ࠨࡴ"))
	KWfFCYyj7iTlts.commit()
	Yn98v3MRdasNfWB2SAG6TOV1m4tq.execute(shC5qBRV2A0lZ(u"࡙ࠩࡅࡈ࡛ࡕࡎ࠽ࠪࡵ"))
	KWfFCYyj7iTlts.close()
	if showDialogs:
		tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,yST5AHEfvPmcWpwGuh2BJ(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ࡶ"),Xz3bA2PFENVCUtplu51(u"ࠫฯ๋ࠠศๆ่ืาࠦศ็ฮสัࠬࡷ"))
		qMGn9u2ckaXejCgUQhYTDP(DD5cFIejQa2X4BgAu9GWPyJ3tC7)
	return
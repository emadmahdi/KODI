# -*- coding: utf-8 -*-
from hIVCFnfxSO import *
QQ8pvXNcBfVkP5rRJ7o = 'FUSHARTV'
WbzmKSZiuOYrBN7oysJ2dUv = '_FTV_'
wQjs1XZ3AO24g8y9bEeoKMiGIu7 = nTHXJIiah2qK[QQ8pvXNcBfVkP5rRJ7o][0]
v1vJEhoNQBVPkjG = ['الصفحة الرئيسية','Sign in','تسجيل']
def x8IFqMZeJj7suCR4AaGoNXfEHm(mode,url,text):
	if   mode==910: XXxlOLJ9KRjPH382WVCvr6n71 = Y72YmLgw4vqlHxTCkbeKSicasD()
	elif mode==911: XXxlOLJ9KRjPH382WVCvr6n71 = Je4TwC30iOG5DLKWAtbYvhs(url,text)
	elif mode==912: XXxlOLJ9KRjPH382WVCvr6n71 = Hkij627uCDJKyIM(url)
	elif mode==913: XXxlOLJ9KRjPH382WVCvr6n71 = Writ3OlNChGRBoPFD4e9ugSVsmfx(url,text)
	elif mode==914: XXxlOLJ9KRjPH382WVCvr6n71 = Q6mUHMbNlirVXPRgKWJAt8ap5hSE(url)
	elif mode==919: XXxlOLJ9KRjPH382WVCvr6n71 = kstJfK6jHQWrXDSMRIGB7(text)
	else: XXxlOLJ9KRjPH382WVCvr6n71 = False
	return XXxlOLJ9KRjPH382WVCvr6n71
def Y72YmLgw4vqlHxTCkbeKSicasD():
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',wQjs1XZ3AO24g8y9bEeoKMiGIu7,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'FUSHARTV-MENU-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'بحث في الموقع',b8Qe150xVaJsnDSv,919,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'_REMEMBERRESULTS_')
	MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+' ===== ===== ===== '+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999)
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('"navslide-wrap"(.*?)</ul>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)".*?</i>(.*?)</a>',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
			if title in v1vJEhoNQBVPkjG: continue
			MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,914)
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('/category.php">(.*?)"navslide-divider"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall("'dropdown-menu'(.*?)</ul>",jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	for CmEkolxes7Q6hB01fGTPZi4 in ZV5rRvabhxJ: OTKx7aVb2hdS16Wrweky4FXfIN0g9 = OTKx7aVb2hdS16Wrweky4FXfIN0g9.replace(CmEkolxes7Q6hB01fGTPZi4,b8Qe150xVaJsnDSv)
	items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)".*?>(.*?)</a>',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
		if title in v1vJEhoNQBVPkjG: continue
		if title=='جديد الأفلام': title = 'المضاف حديثا'
		MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,914)
	return
def Q6mUHMbNlirVXPRgKWJAt8ap5hSE(url):
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'FUSHARTV-SUBMENU-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	Pmt5K6LAEZBcb = YYBlm36zd0Jst18LXwo4.findall('"caret"(.*?)</ul>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if Pmt5K6LAEZBcb:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = Pmt5K6LAEZBcb[0]
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = OTKx7aVb2hdS16Wrweky4FXfIN0g9.replace('"presentation"','</ul>')
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		if not ZV5rRvabhxJ: ZV5rRvabhxJ = [(b8Qe150xVaJsnDSv,OTKx7aVb2hdS16Wrweky4FXfIN0g9)]
		MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+' فرز أو فلتر أو ترتيب '+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999)
		for kUOgpBX9V4TSjEcZ,OTKx7aVb2hdS16Wrweky4FXfIN0g9 in ZV5rRvabhxJ:
			items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)".*?>(.*?)</a>',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
			if kUOgpBX9V4TSjEcZ: kUOgpBX9V4TSjEcZ = kUOgpBX9V4TSjEcZ+': '
			for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
				title = kUOgpBX9V4TSjEcZ+title
				MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,911)
	U8UnzJgXuMIE5GV = YYBlm36zd0Jst18LXwo4.findall('"pm-category-subcats"(.*?)</ul>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if U8UnzJgXuMIE5GV:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = U8UnzJgXuMIE5GV[0]
		items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)">(.*?)</a>',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		if len(items)<30:
			MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+' ===== ===== ===== '+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999)
			for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
				MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,911)
	if not Pmt5K6LAEZBcb and not U8UnzJgXuMIE5GV: Je4TwC30iOG5DLKWAtbYvhs(url)
	return
def Je4TwC30iOG5DLKWAtbYvhs(url,rC39wAIKjUuS=b8Qe150xVaJsnDSv):
	if rC39wAIKjUuS=='ajax-search':
		url,search = url.split('?',1)
		data = 'queryString='+search
		headers = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'POST',url,data,headers,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'FUSHARTV-TITLES-1st')
	else:
		b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'FUSHARTV-TITLES-2nd')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	OTKx7aVb2hdS16Wrweky4FXfIN0g9,items = b8Qe150xVaJsnDSv,[]
	OZSA7QNfeE = Wl2eu1PavfQ(url,'url')
	if rC39wAIKjUuS=='ajax-search':
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = jLtdbeYiQHnf4SpU2MTly
		xxnATEUzH6Djmq0NrBveh = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)">(.*?)</a>',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in xxnATEUzH6Djmq0NrBveh: items.append((b8Qe150xVaJsnDSv,pcA1dzy7LXwGfMPg9mTkuh5tine3,title))
	elif rC39wAIKjUuS=='featured':
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('"pm-carousel_featured"(.*?)</ul>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if ZV5rRvabhxJ: OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
	elif rC39wAIKjUuS=='new_episodes':
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('"row pm-ul-browse-videos(.*?)</ul>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if ZV5rRvabhxJ: OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
	elif rC39wAIKjUuS=='new_movies':
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('"row pm-ul-browse-videos(.*?)</ul>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if len(ZV5rRvabhxJ)>1: OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[1]
	elif rC39wAIKjUuS=='featured_series':
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('"home-series-list"(.*?)</div>[\t|\n]*</div>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if ZV5rRvabhxJ: OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
	else:
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('(data-echo=".*?)</ul>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if ZV5rRvabhxJ: OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
	if OTKx7aVb2hdS16Wrweky4FXfIN0g9 and not items: items = YYBlm36zd0Jst18LXwo4.findall('"thumbnail".*?<a href="(.*?)" title="(.*?)".*?data-echo="(.*?)"',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	if not items: return
	d3VSIefbHnvqiut = []
	PBFVNlrcUMOSzC04 = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for pcA1dzy7LXwGfMPg9mTkuh5tine3,title,lvtGpMZHb9 in items:
		if 'http' not in pcA1dzy7LXwGfMPg9mTkuh5tine3: pcA1dzy7LXwGfMPg9mTkuh5tine3 = OZSA7QNfeE+'/'+pcA1dzy7LXwGfMPg9mTkuh5tine3.strip('/')
		HHr42WSgBjAeU7TkQcVaL6yEJz8PF = YYBlm36zd0Jst18LXwo4.findall('(.*?) (الحلقة|حلقة).\d+',title,YYBlm36zd0Jst18LXwo4.DOTALL)
		if any(Y8aiFZsLKw in title for Y8aiFZsLKw in PBFVNlrcUMOSzC04):
			MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,912,lvtGpMZHb9)
		elif rC39wAIKjUuS=='new_episodes':
			MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,912,lvtGpMZHb9)
		elif HHr42WSgBjAeU7TkQcVaL6yEJz8PF:
			title = '_MOD_' + HHr42WSgBjAeU7TkQcVaL6yEJz8PF[0][0]
			if title not in d3VSIefbHnvqiut:
				MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,913,lvtGpMZHb9)
				d3VSIefbHnvqiut.append(title)
		else: MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,913,lvtGpMZHb9)
	if 1:
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('"pagination(.*?)</ul>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if ZV5rRvabhxJ:
			OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
			items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)".*?>(.*?)</a>',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
			for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
				if pcA1dzy7LXwGfMPg9mTkuh5tine3=='#': continue
				pcA1dzy7LXwGfMPg9mTkuh5tine3 = OZSA7QNfeE+'/'+pcA1dzy7LXwGfMPg9mTkuh5tine3.strip('/')
				title = pTP49ckGDYrofa2KxenumbH0(title)
				MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'صفحة '+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,911)
	return
def Writ3OlNChGRBoPFD4e9ugSVsmfx(url,ywbiNqdBD6makJ):
	OZSA7QNfeE = Wl2eu1PavfQ(url,'url')
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'FUSHARTV-EPISODES-2nd')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	Pmt5K6LAEZBcb = YYBlm36zd0Jst18LXwo4.findall('"SeasonsBox"(.*?)"SeasonsEpisodesMain',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	I6YPOSofrpnTwRm8b = YYBlm36zd0Jst18LXwo4.findall('preview_image_url: "(.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if I6YPOSofrpnTwRm8b: lvtGpMZHb9 = I6YPOSofrpnTwRm8b[0]
	else: lvtGpMZHb9 = b8Qe150xVaJsnDSv
	items = []
	RXBJtDjl0Z8267ArET = False
	if Pmt5K6LAEZBcb and not ywbiNqdBD6makJ:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = Pmt5K6LAEZBcb[0]
		items = YYBlm36zd0Jst18LXwo4.findall('''onclick=".*?openCity\(event, '(.*?)'\)".*?>(.*?)</button>''',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for ywbiNqdBD6makJ,title in items:
			ywbiNqdBD6makJ = ywbiNqdBD6makJ.strip('#')
			if len(items)>1: MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,url,913,lvtGpMZHb9,b8Qe150xVaJsnDSv,ywbiNqdBD6makJ)
			else: RXBJtDjl0Z8267ArET = True
	else: RXBJtDjl0Z8267ArET = True
	U8UnzJgXuMIE5GV = YYBlm36zd0Jst18LXwo4.findall('id="'+ywbiNqdBD6makJ+'"(.*?)</ul>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if U8UnzJgXuMIE5GV and RXBJtDjl0Z8267ArET:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = U8UnzJgXuMIE5GV[0]
		xxnATEUzH6Djmq0NrBveh = YYBlm36zd0Jst18LXwo4.findall('''href=['"](.*?)['"]><li><em>(.*?)</span>''',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		items = []
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in xxnATEUzH6Djmq0NrBveh: items.append((pcA1dzy7LXwGfMPg9mTkuh5tine3,title,lvtGpMZHb9))
		if not items: items = YYBlm36zd0Jst18LXwo4.findall('"thumbnail".*?<a href="(.*?)" title="(.*?)".*?data-echo="(.*?)"',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,title,lvtGpMZHb9 in items:
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = OZSA7QNfeE+'/'+pcA1dzy7LXwGfMPg9mTkuh5tine3.strip('/')
			title = title.replace('</em><span>',pldxivXC5wbTB2O8q)
			MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,912,lvtGpMZHb9)
	return
def Hkij627uCDJKyIM(url):
	n92bB0YwDLqyadQRlmGW,Vw6ELd0ReyubDGkj87FA1Zin = [],[]
	jLtdbeYiQHnf4SpU2MTly = ''
	if 'post=' in jLtdbeYiQHnf4SpU2MTly:
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = YYBlm36zd0Jst18LXwo4.findall('id="player".*?href="(.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3[0]
		EEZLmsCMxVl07kRfzAih = pcA1dzy7LXwGfMPg9mTkuh5tine3.split('post=')[1]
		EEZLmsCMxVl07kRfzAih = lnFeUkiZtQ7E1.b64decode(EEZLmsCMxVl07kRfzAih)
		if i1thmHk7AZquD4cM0fnp62: EEZLmsCMxVl07kRfzAih = EEZLmsCMxVl07kRfzAih.decode(OVauxZzLI10vcXT74K)
		EEZLmsCMxVl07kRfzAih = oJsUwXA0yGOI1mTjxQ('dict',EEZLmsCMxVl07kRfzAih)
		tzdvaEpMHOCZLXDYg08T = EEZLmsCMxVl07kRfzAih['servers']
		YRtyADTLUrGc = list(tzdvaEpMHOCZLXDYg08T.keys())
		tzdvaEpMHOCZLXDYg08T = list(tzdvaEpMHOCZLXDYg08T.values())
		TJuDfURKbI6MynChiEXqAYQS4d58j = zip(YRtyADTLUrGc,tzdvaEpMHOCZLXDYg08T)
		for title,pcA1dzy7LXwGfMPg9mTkuh5tine3 in TJuDfURKbI6MynChiEXqAYQS4d58j:
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3+'?named='+title+'__watch'
			n92bB0YwDLqyadQRlmGW.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
	else:
		MUJCtfYVBLODrFbaZn = url.replace('watch.php','play.php')
		b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',MUJCtfYVBLODrFbaZn,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'FUSHARTV-PLAY-2nd')
		jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = YYBlm36zd0Jst18LXwo4.findall('<iframe src="(.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if pcA1dzy7LXwGfMPg9mTkuh5tine3:
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3[0]
			if pcA1dzy7LXwGfMPg9mTkuh5tine3 not in Vw6ELd0ReyubDGkj87FA1Zin:
				Vw6ELd0ReyubDGkj87FA1Zin.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
				LLOCdZ3sS2enzXx4fVB18YRvbHNwky = Wl2eu1PavfQ(pcA1dzy7LXwGfMPg9mTkuh5tine3,'name')
				pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3+'?named='+LLOCdZ3sS2enzXx4fVB18YRvbHNwky+'__embed'
				n92bB0YwDLqyadQRlmGW.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('"WatchList"(.*?)</ul>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if ZV5rRvabhxJ:
			OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
			items = YYBlm36zd0Jst18LXwo4.findall('embed-url="(.*?)".*?<strong>(.*?)</strong>',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
			for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
				if pcA1dzy7LXwGfMPg9mTkuh5tine3 not in Vw6ELd0ReyubDGkj87FA1Zin:
					Vw6ELd0ReyubDGkj87FA1Zin.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
					LLOCdZ3sS2enzXx4fVB18YRvbHNwky = Wl2eu1PavfQ(pcA1dzy7LXwGfMPg9mTkuh5tine3,'name')
					pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3+'?named='+LLOCdZ3sS2enzXx4fVB18YRvbHNwky+'__watch'
					n92bB0YwDLqyadQRlmGW.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
		if 'pm-download' not in jLtdbeYiQHnf4SpU2MTly:
			MUJCtfYVBLODrFbaZn = url.replace('watch.php','download.php')
			b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',MUJCtfYVBLODrFbaZn,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,False,'FUSHARTV-PLAY-3rd')
			jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('pm-download(.*?)</ul>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if ZV5rRvabhxJ:
			OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
			items = YYBlm36zd0Jst18LXwo4.findall('download-url="(.*?)".*?<span>(.*?)</span>',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
			for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
				if pcA1dzy7LXwGfMPg9mTkuh5tine3 not in Vw6ELd0ReyubDGkj87FA1Zin:
					Vw6ELd0ReyubDGkj87FA1Zin.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
					LLOCdZ3sS2enzXx4fVB18YRvbHNwky = Wl2eu1PavfQ(pcA1dzy7LXwGfMPg9mTkuh5tine3,'name')
					pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3+'?named='+LLOCdZ3sS2enzXx4fVB18YRvbHNwky+'__download'
					n92bB0YwDLqyadQRlmGW.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
	import QNeGEq8sWn
	QNeGEq8sWn.nqu2GCT9gHAbpIPSFZz5(n92bB0YwDLqyadQRlmGW,QQ8pvXNcBfVkP5rRJ7o,'video',url)
	return
def kstJfK6jHQWrXDSMRIGB7(search):
	search,v7Rxw52Z4X0,showDialogs = JimhUH0SEf6w(search)
	if search==b8Qe150xVaJsnDSv: search = FT2oXWtPQpVGuexmLqKN3srdzYn()
	if search==b8Qe150xVaJsnDSv: return
	search = search.replace(pldxivXC5wbTB2O8q,'+')
	url = wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/search.php?keywords='+search
	Je4TwC30iOG5DLKWAtbYvhs(url,'search')
	return
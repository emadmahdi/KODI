# -*- coding: utf-8 -*-
from hIVCFnfxSO import *
QQ8pvXNcBfVkP5rRJ7o = 'DAILYMOTION'
WbzmKSZiuOYrBN7oysJ2dUv = '_DLM_'
wQjs1XZ3AO24g8y9bEeoKMiGIu7 = nTHXJIiah2qK[QQ8pvXNcBfVkP5rRJ7o][0]
RRtlZAxNcPqnOHgzLY7ude5rBXGToK = nTHXJIiah2qK[QQ8pvXNcBfVkP5rRJ7o][1]
def x8IFqMZeJj7suCR4AaGoNXfEHm(mode,url,text,type,NGQDwOCXx1BZmd9Huc):
	if	 mode==400: XXxlOLJ9KRjPH382WVCvr6n71 = Y72YmLgw4vqlHxTCkbeKSicasD()
	elif mode==401: XXxlOLJ9KRjPH382WVCvr6n71 = joBLkQuaR2dCU9yZOw(url,text)
	elif mode==402: XXxlOLJ9KRjPH382WVCvr6n71 = q9i6ZneTjVahSOR(url,text)
	elif mode==403: XXxlOLJ9KRjPH382WVCvr6n71 = Hkij627uCDJKyIM(url,text)
	elif mode==404: XXxlOLJ9KRjPH382WVCvr6n71 = ya2xbq6eIvJcOEPMQnrj7D4z(text,NGQDwOCXx1BZmd9Huc)
	elif mode==405: XXxlOLJ9KRjPH382WVCvr6n71 = mcu9MHDE0GyfSdastFpVi(text,NGQDwOCXx1BZmd9Huc)
	elif mode==406: XXxlOLJ9KRjPH382WVCvr6n71 = fSDagBuHtGZRQeFnMPk8XNWv6A9(text,NGQDwOCXx1BZmd9Huc)
	elif mode==407: XXxlOLJ9KRjPH382WVCvr6n71 = h5xPMpNETzVuYmH4OQj7F0nfC28r(url,NGQDwOCXx1BZmd9Huc)
	elif mode==408: XXxlOLJ9KRjPH382WVCvr6n71 = HDA7raBO28(url,NGQDwOCXx1BZmd9Huc)
	elif mode==409: XXxlOLJ9KRjPH382WVCvr6n71 = kstJfK6jHQWrXDSMRIGB7(text,NGQDwOCXx1BZmd9Huc)
	elif mode==411: XXxlOLJ9KRjPH382WVCvr6n71 = l8NrPyfjmRS(url,text)
	elif mode==414: XXxlOLJ9KRjPH382WVCvr6n71 = nydvD3M4jEe0VW65CfitFYroOaTgh(text)
	elif mode==415: XXxlOLJ9KRjPH382WVCvr6n71 = GERO8jdBC5Mmt0Fa2o7XVlrI4cgY(text,NGQDwOCXx1BZmd9Huc)
	elif mode==416: XXxlOLJ9KRjPH382WVCvr6n71 = KKiWXsfLZ9Um(text,NGQDwOCXx1BZmd9Huc)
	elif mode==417: XXxlOLJ9KRjPH382WVCvr6n71 = ggUKZzhi7dvS9qA61lwNRBCx4(url,NGQDwOCXx1BZmd9Huc)
	else: XXxlOLJ9KRjPH382WVCvr6n71 = False
	return XXxlOLJ9KRjPH382WVCvr6n71
def Y72YmLgw4vqlHxTCkbeKSicasD():
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'الرئيسية',b8Qe150xVaJsnDSv,414)
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'بحث في الموقع',b8Qe150xVaJsnDSv,409,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'_REMEMBERRESULTS_')
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'بحث عن فيديوهات',b8Qe150xVaJsnDSv,409,b8Qe150xVaJsnDSv,'videos?sortBy=','_REMEMBERRESULTS_')
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'بحث عن آخر الفيديوهات',b8Qe150xVaJsnDSv,409,b8Qe150xVaJsnDSv,'videos?sortBy=RECENT','_REMEMBERRESULTS_')
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'بحث عن الفيديوهات الأكثر مشاهدة',b8Qe150xVaJsnDSv,409,b8Qe150xVaJsnDSv,'videos?sortBy=VIEW_COUNT','_REMEMBERRESULTS_')
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'بحث عن قوائم التشغيل',b8Qe150xVaJsnDSv,409,b8Qe150xVaJsnDSv,'playlists','_REMEMBERRESULTS_')
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'بحث عن مستخدم',b8Qe150xVaJsnDSv,409,b8Qe150xVaJsnDSv,'channels','_REMEMBERRESULTS_')
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'بحث عن بث حي',b8Qe150xVaJsnDSv,409,b8Qe150xVaJsnDSv,'lives','_REMEMBERRESULTS_')
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'بحث عن هاشتاك',b8Qe150xVaJsnDSv,409,b8Qe150xVaJsnDSv,'hashtags','_REMEMBERRESULTS_')
	return
def q9i6ZneTjVahSOR(url,cTlfYkLbmDH6xz9qAQj):
	if '/dm_' in url:
		b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(LtlXH3fvMydAx,'GET',url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,False,b8Qe150xVaJsnDSv,'DAILYMOTION-CHANNELS_SUBMENU-1st',False,False)
		headers = b3HKopTY9zLUyhJmt.headers
		if 'Location' in list(headers.keys()): url = wQjs1XZ3AO24g8y9bEeoKMiGIu7+headers['Location']
	cTlfYkLbmDH6xz9qAQj = rC3Tlno96KjLDIvBaSWUbR8+cTlfYkLbmDH6xz9qAQj+hAIp8kmC36T5WFPMSXOwnNbtD
	cTlfYkLbmDH6xz9qAQj = utSpEeMwhcRb(cTlfYkLbmDH6xz9qAQj)
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+':: بث حي',url,411,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'channel_lives_now')
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+':: آخر الفيديوهات',url+'/videos',408)
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+':: الأكثر مشاهدة',url+'/videos?sort=visited',408)
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+':: المميزة',url,411,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'channel_featured_videos')
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+':: قوائم التشغيل',url+'/playlists',407)
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+':: قوائم التشغيل أبجدية',url+'/playlists?sort=alphaaz',407)
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+':: قنوات ذات صلة',url,411,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'channel_related_channel')
	return
def utSpEeMwhcRb(title):
	title = title.rstrip('\\').strip(pldxivXC5wbTB2O8q).replace('\\\\','\\')
	title = ggtn0PzV7aMe(title)
	return title
def Hkij627uCDJKyIM(url,OwIo2yinF3kgHC5xVa):
	import QNeGEq8sWn
	QNeGEq8sWn.nqu2GCT9gHAbpIPSFZz5([url],QQ8pvXNcBfVkP5rRJ7o,'video',url)
	return
def ya2xbq6eIvJcOEPMQnrj7D4z(search,NGQDwOCXx1BZmd9Huc=b8Qe150xVaJsnDSv):
	if NGQDwOCXx1BZmd9Huc==b8Qe150xVaJsnDSv: NGQDwOCXx1BZmd9Huc = '1'
	if 'sortBy=' in search: sort = search.split('sortBy=')[1].split('&')[0]
	else: sort = b8Qe150xVaJsnDSv
	search = search.split('/videos')[0]
	rC39wAIKjUuS = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeVideos":true,"page":mypagenumber,"limit":mypagelimitmysortmethod},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    views {      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment VIDEO_WATCH_LATER_FRAGMENT on Video {  id  isInWatchLater  __typename}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    videos {      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_WATCH_LATER_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	rC39wAIKjUuS = rC39wAIKjUuS.replace('mysearchwords',search)
	rC39wAIKjUuS = rC39wAIKjUuS.replace('mypagelimit','40')
	rC39wAIKjUuS = rC39wAIKjUuS.replace('mypagenumber',NGQDwOCXx1BZmd9Huc)
	if sort==b8Qe150xVaJsnDSv: rC39wAIKjUuS = rC39wAIKjUuS.replace('mysortmethod',b8Qe150xVaJsnDSv)
	else: rC39wAIKjUuS = rC39wAIKjUuS.replace('mysortmethod',',"sortByVideos":"'+sort+'"')
	url = wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/search/'+search+'/videos'
	jLtdbeYiQHnf4SpU2MTly = Du5hjHVRAOJvXdGl(rC39wAIKjUuS,search)
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('"videos"(.*?)"VideoConnection"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		items = YYBlm36zd0Jst18LXwo4.findall('"node":.*?"xid":"(.*?)",.*?"title":"(.*?)",.*?"name":"(.*?)",.*?"displayName":"(.*?)",.*?"duration":(.*?),".*?thumbnailx240":"(.*?)",',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for id,title,dJQDlGz1FViAyxeIH7YNZrbT8,cTlfYkLbmDH6xz9qAQj,D5taEr6hnuFCcRMpTq4wSoyQOivx,lvtGpMZHb9 in items:
			lvtGpMZHb9 = lvtGpMZHb9.replace('\/','/')
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/video/'+id
			title = utSpEeMwhcRb(title)
			OwIo2yinF3kgHC5xVa = dJQDlGz1FViAyxeIH7YNZrbT8+'::'+cTlfYkLbmDH6xz9qAQj
			MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,403,lvtGpMZHb9,D5taEr6hnuFCcRMpTq4wSoyQOivx,OwIo2yinF3kgHC5xVa)
		if '"hasNextPage":true' in jLtdbeYiQHnf4SpU2MTly:
			NGQDwOCXx1BZmd9Huc = str(int(NGQDwOCXx1BZmd9Huc)+1)
			MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'صفحة '+NGQDwOCXx1BZmd9Huc,url,404,b8Qe150xVaJsnDSv,NGQDwOCXx1BZmd9Huc,search)
	return
def mcu9MHDE0GyfSdastFpVi(search,NGQDwOCXx1BZmd9Huc=b8Qe150xVaJsnDSv):
	if NGQDwOCXx1BZmd9Huc==b8Qe150xVaJsnDSv: NGQDwOCXx1BZmd9Huc = '1'
	rC39wAIKjUuS = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":true,"shouldIncludeVideos":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    views {      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment VIDEO_WATCH_LATER_FRAGMENT on Video {  id  isInWatchLater  __typename}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    videos {      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_WATCH_LATER_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	rC39wAIKjUuS = rC39wAIKjUuS.replace('mysearchwords',search)
	rC39wAIKjUuS = rC39wAIKjUuS.replace('mypagelimit','40')
	rC39wAIKjUuS = rC39wAIKjUuS.replace('mypagenumber',NGQDwOCXx1BZmd9Huc)
	url = wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/search/'+search+'/playlists'
	jLtdbeYiQHnf4SpU2MTly = Du5hjHVRAOJvXdGl(rC39wAIKjUuS,search)
	items = YYBlm36zd0Jst18LXwo4.findall('"node".*?"xid":"(.*?)",.*?"name":"(.*?)",.*?"xid":"(.*?)",.*?"name":"(.*?)",.*?"displayName":"(.*?)",.*?"thumbnailx240":"(.*?)",.*?"total":(.*?),"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	for id,name,KtASGsPpz8q0mWaVwFg1knY9LX,dJQDlGz1FViAyxeIH7YNZrbT8,cTlfYkLbmDH6xz9qAQj,lvtGpMZHb9,count in items:
		lvtGpMZHb9 = lvtGpMZHb9.replace('\/','/')
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/playlist/'+id
		title = 'LIST'+count+':  '+name
		title = utSpEeMwhcRb(title)
		OwIo2yinF3kgHC5xVa = dJQDlGz1FViAyxeIH7YNZrbT8+'::'+cTlfYkLbmDH6xz9qAQj
		MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,401,lvtGpMZHb9,b8Qe150xVaJsnDSv,OwIo2yinF3kgHC5xVa)
	if '"hasNextPage":true' in jLtdbeYiQHnf4SpU2MTly:
		NGQDwOCXx1BZmd9Huc = str(int(NGQDwOCXx1BZmd9Huc)+1)
		MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'صفحة '+NGQDwOCXx1BZmd9Huc,url,405,b8Qe150xVaJsnDSv,NGQDwOCXx1BZmd9Huc,search)
	return
def fSDagBuHtGZRQeFnMPk8XNWv6A9(search,NGQDwOCXx1BZmd9Huc=b8Qe150xVaJsnDSv):
	if NGQDwOCXx1BZmd9Huc==b8Qe150xVaJsnDSv: NGQDwOCXx1BZmd9Huc = '1'
	rC39wAIKjUuS = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":true,"shouldIncludePlaylists":false,"shouldIncludeVideos":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    views {      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment VIDEO_WATCH_LATER_FRAGMENT on Video {  id  isInWatchLater  __typename}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    videos {      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_WATCH_LATER_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	rC39wAIKjUuS = rC39wAIKjUuS.replace('mysearchwords',search)
	rC39wAIKjUuS = rC39wAIKjUuS.replace('mypagelimit','40')
	rC39wAIKjUuS = rC39wAIKjUuS.replace('mypagenumber',NGQDwOCXx1BZmd9Huc)
	url = wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/search/'+search+'/channels'
	jLtdbeYiQHnf4SpU2MTly = Du5hjHVRAOJvXdGl(rC39wAIKjUuS,search)
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('"channels"(.*?)"ChannelConnection"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		items = YYBlm36zd0Jst18LXwo4.findall('"node".*?"name":"(.*?)",.*?"displayName":"(.*?)",.*?"thumbnailx240":"(.*?)",',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for id,name,lvtGpMZHb9 in items:
			lvtGpMZHb9 = lvtGpMZHb9.replace('\/','/')
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/'+id
			title = 'USER:  '+name
			title = utSpEeMwhcRb(title)
			MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,402,lvtGpMZHb9,b8Qe150xVaJsnDSv,name)
		if '"hasNextPage":true' in jLtdbeYiQHnf4SpU2MTly:
			NGQDwOCXx1BZmd9Huc = str(int(NGQDwOCXx1BZmd9Huc)+1)
			MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'صفحة '+NGQDwOCXx1BZmd9Huc,url,406,b8Qe150xVaJsnDSv,NGQDwOCXx1BZmd9Huc,search)
	return
def nydvD3M4jEe0VW65CfitFYroOaTgh(PT2Z8wyhXNqoflUJHpkB30):
	rC39wAIKjUuS = '''{"operationName":"HOME_QUERY","variables":{"space":"nextplore"},"query":"fragment TOPIC_BASE_FRAG on Topic {  id  xid  name  thumbnail: coverURL(size: \\"x532\\")  coverURL: coverURL(size: \\"x532\\")  isFollowed  whitelistStatus {    id    isWhitelisted    __typename  }  __typename}query HOME_QUERY($space: String!) {  home: views {    id    neon {      id      sections(space: $space) {        edges {          node {            id            name            title            description            groupingType            type            relatedComponent {              __typename              ... on Collection {                id                xid                __typename              }              ... on Channel {                id                xid                name                displayName                logoURL(size: \\"x60\\")                __typename              }              ... on Topic {                id                __typename                ...TOPIC_BASE_FRAG              }            }            components {              edges {                node {                  __typename                  ... on Video {                    id                    xid                    title                    thumbnailx60: thumbnailURL(size: \\"x60\\")                    thumbnailx120: thumbnailURL(size: \\"x120\\")                    thumbnailx240: thumbnailURL(size: \\"x240\\")                    thumbnailx360: thumbnailURL(size: \\"x360\\")                    thumbnailx480: thumbnailURL(size: \\"x480\\")                    thumbnailx720: thumbnailURL(size: \\"x720\\")                    aspectRatio                    createdAt                    channel {                      id                      xid                      name                      displayName                      logoURLx25: logoURL(size: \\"x25\\")                      accountType                      __typename                    }                    description                    duration                    __typename                  }                  ... on Live {                    id                    xid                    title                    thumbnailx60: thumbnailURL(size: \\"x60\\")                    thumbnailx120: thumbnailURL(size: \\"x120\\")                    thumbnailx240: thumbnailURL(size: \\"x240\\")                    thumbnailx360: thumbnailURL(size: \\"x360\\")                    thumbnailx480: thumbnailURL(size: \\"x480\\")                    thumbnailx720: thumbnailURL(size: \\"x720\\")                    aspectRatio                    createdAt                    channel {                      id                      xid                      name                      displayName                      logoURLx25: logoURL(size: \\"x25\\")                      accountType                      __typename                    }                    startAt                    __typename                  }                }                __typename              }              __typename            }            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	M43f6vQclCZObzn9aFUWTH = Du5hjHVRAOJvXdGl(rC39wAIKjUuS)
	if M43f6vQclCZObzn9aFUWTH:
		NzvEkKgJ29pFlZrRB = oJsUwXA0yGOI1mTjxQ('dict',M43f6vQclCZObzn9aFUWTH)
		jRq4oQ3XGtp2 = NzvEkKgJ29pFlZrRB['data']['home']['neon']['sections']['edges']
		if not PT2Z8wyhXNqoflUJHpkB30:
			lxBLuGUS4sQeHgbNRm9ZfMaTK7vd = []
			for ibUT9CL0XahAxFZBleOyzHq27cotQ in jRq4oQ3XGtp2:
				OOLdc9triTa1EGBg = ibUT9CL0XahAxFZBleOyzHq27cotQ['node']['title']
				if OOLdc9triTa1EGBg not in lxBLuGUS4sQeHgbNRm9ZfMaTK7vd: MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+OOLdc9triTa1EGBg,b8Qe150xVaJsnDSv,414,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,OOLdc9triTa1EGBg)
				lxBLuGUS4sQeHgbNRm9ZfMaTK7vd.append(OOLdc9triTa1EGBg)
		else:
			for ibUT9CL0XahAxFZBleOyzHq27cotQ in jRq4oQ3XGtp2:
				OOLdc9triTa1EGBg = ibUT9CL0XahAxFZBleOyzHq27cotQ['node']['title']
				if OOLdc9triTa1EGBg==PT2Z8wyhXNqoflUJHpkB30:
					XD8JCA3W2eF7zuY96Bx = ibUT9CL0XahAxFZBleOyzHq27cotQ['node']['components']['edges']
					for Ndp32o1Pav6eVrURSfIA8BTZGWsJ in XD8JCA3W2eF7zuY96Bx:
						D5taEr6hnuFCcRMpTq4wSoyQOivx = str(Ndp32o1Pav6eVrURSfIA8BTZGWsJ['node']['duration'])
						title = ggtn0PzV7aMe(Ndp32o1Pav6eVrURSfIA8BTZGWsJ['node']['title'])
						title = title.replace('\/','/')
						coE0fkBtgU759GiDKquMx = Ndp32o1Pav6eVrURSfIA8BTZGWsJ['node']['xid']
						lvtGpMZHb9 = Ndp32o1Pav6eVrURSfIA8BTZGWsJ['node']['thumbnailx480']
						lvtGpMZHb9 = lvtGpMZHb9.replace('\/','/')
						pcA1dzy7LXwGfMPg9mTkuh5tine3 = wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/video/'+coE0fkBtgU759GiDKquMx
						MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,403,lvtGpMZHb9,D5taEr6hnuFCcRMpTq4wSoyQOivx)
	return
def GERO8jdBC5Mmt0Fa2o7XVlrI4cgY(search,NGQDwOCXx1BZmd9Huc=b8Qe150xVaJsnDSv):
	if NGQDwOCXx1BZmd9Huc==b8Qe150xVaJsnDSv: NGQDwOCXx1BZmd9Huc = '1'
	rC39wAIKjUuS = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeTopics":false,"shouldIncludeVideos":false,"shouldIncludeLives":true,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    id    views {      id      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  aspectRatio  __typename}fragment VIDEO_FAVORITES_FRAGMENT on Media {  __typename  ... on Video {    id    viewerEngagement {      id      favorited      __typename    }    __typename  }  ... on Live {    id    viewerEngagement {      id      favorited      __typename    }    __typename  }}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}fragment TOPIC_BASE_FRAG on Topic {  id  xid  name  videos(sort: \\"recent\\", first: 5) {    pageInfo {      hasNextPage      nextPage      __typename    }    edges {      node {        id        ...VIDEO_BASE_FRAGMENT        ...VIDEO_FAVORITES_FRAGMENT        __typename      }      __typename    }    __typename  }  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeTopics: Boolean!, $shouldIncludeLives: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(      query: $query      first: $limit      page: $page      sort: $sortByVideos      durationMin: $durationMinVideos      durationMax: $durationMaxVideos      createdAfter: $createdAfterVideos    ) @include(if: $shouldIncludeVideos) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_FAVORITES_FRAGMENT          __typename        }        __typename      }      __typename    }    lives(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeLives) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          xid          title          thumbnail: thumbnailURL(size: \\"x240\\")          thumbnailx60: thumbnailURL(size: \\"x60\\")          thumbnailx120: thumbnailURL(size: \\"x120\\")          thumbnailx240: thumbnailURL(size: \\"x240\\")          thumbnailx720: thumbnailURL(size: \\"x720\\")          audienceCount          aspectRatio          isOnAir          channel {            id            xid            name            displayName            accountType            __typename          }          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    topics(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeTopics) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...TOPIC_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	rC39wAIKjUuS = rC39wAIKjUuS.replace('mysearchwords',search)
	rC39wAIKjUuS = rC39wAIKjUuS.replace('mypagelimit','40')
	rC39wAIKjUuS = rC39wAIKjUuS.replace('mypagenumber',NGQDwOCXx1BZmd9Huc)
	url = wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/search/'+search+'/lives'
	M43f6vQclCZObzn9aFUWTH = Du5hjHVRAOJvXdGl(rC39wAIKjUuS,search)
	if M43f6vQclCZObzn9aFUWTH:
		NzvEkKgJ29pFlZrRB = oJsUwXA0yGOI1mTjxQ('dict',M43f6vQclCZObzn9aFUWTH)
		try: jRq4oQ3XGtp2 = NzvEkKgJ29pFlZrRB['data']['search']['lives']['edges']
		except: jRq4oQ3XGtp2 = []
		for ibUT9CL0XahAxFZBleOyzHq27cotQ in jRq4oQ3XGtp2:
			name = ibUT9CL0XahAxFZBleOyzHq27cotQ['node']['title']
			name = ggtn0PzV7aMe(name)
			coE0fkBtgU759GiDKquMx = ibUT9CL0XahAxFZBleOyzHq27cotQ['node']['xid']
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/video/'+coE0fkBtgU759GiDKquMx
			MQtuaShrKTbdZFJ5nsR7D('live',WbzmKSZiuOYrBN7oysJ2dUv+'LIVE: '+name,pcA1dzy7LXwGfMPg9mTkuh5tine3,403)
		if '"hasNextPage":true' in M43f6vQclCZObzn9aFUWTH:
			NGQDwOCXx1BZmd9Huc = str(int(NGQDwOCXx1BZmd9Huc)+1)
			MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'صفحة '+NGQDwOCXx1BZmd9Huc,url,415,b8Qe150xVaJsnDSv,NGQDwOCXx1BZmd9Huc,search)
	return
def EcQZzjehxAvFXGWd(search,NGQDwOCXx1BZmd9Huc=b8Qe150xVaJsnDSv):
	if NGQDwOCXx1BZmd9Huc==b8Qe150xVaJsnDSv: NGQDwOCXx1BZmd9Huc = '1'
	rC39wAIKjUuS = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeTopics":true,"shouldIncludeVideos":false,"shouldIncludeLives":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    id    views {      id      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  aspectRatio  __typename}fragment VIDEO_FAVORITES_FRAGMENT on Media {  __typename  ... on Video {    id    isInWatchLater    __typename  }  ... on Live {    id    isInWatchLater    __typename  }}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}fragment TOPIC_BASE_FRAG on Topic {  id  xid  name  videos(sort: \\"recent\\", first: 5) {    pageInfo {      hasNextPage      nextPage      __typename    }    edges {      node {        id        ...VIDEO_BASE_FRAGMENT        ...VIDEO_FAVORITES_FRAGMENT        __typename      }      __typename    }    __typename  }  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeTopics: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(      query: $query      first: $limit      page: $page      sort: $sortByVideos      durationMin: $durationMinVideos      durationMax: $durationMaxVideos      createdAfter: $createdAfterVideos    ) @include(if: $shouldIncludeVideos) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_FAVORITES_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    topics(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeTopics) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...TOPIC_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	rC39wAIKjUuS = rC39wAIKjUuS.replace('mysearchwords',search)
	rC39wAIKjUuS = rC39wAIKjUuS.replace('mypagelimit','40')
	rC39wAIKjUuS = rC39wAIKjUuS.replace('mypagenumber',NGQDwOCXx1BZmd9Huc)
	url = wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/search/'+search+'/topics'
	M43f6vQclCZObzn9aFUWTH = Du5hjHVRAOJvXdGl(rC39wAIKjUuS,search)
	if M43f6vQclCZObzn9aFUWTH:
		NzvEkKgJ29pFlZrRB = oJsUwXA0yGOI1mTjxQ('dict',M43f6vQclCZObzn9aFUWTH)
		try: jRq4oQ3XGtp2 = NzvEkKgJ29pFlZrRB['data']['search']['topics']['edges']
		except: jRq4oQ3XGtp2 = []
		for ibUT9CL0XahAxFZBleOyzHq27cotQ in jRq4oQ3XGtp2:
			name = ibUT9CL0XahAxFZBleOyzHq27cotQ['node']['name']
			coE0fkBtgU759GiDKquMx = ibUT9CL0XahAxFZBleOyzHq27cotQ['node']['xid']
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/topic/'+coE0fkBtgU759GiDKquMx
			MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'TOPIC: '+name,pcA1dzy7LXwGfMPg9mTkuh5tine3,413)
		if '"hasNextPage":true' in M43f6vQclCZObzn9aFUWTH:
			NGQDwOCXx1BZmd9Huc = str(int(NGQDwOCXx1BZmd9Huc)+1)
			MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'صفحة '+NGQDwOCXx1BZmd9Huc,url,412,b8Qe150xVaJsnDSv,NGQDwOCXx1BZmd9Huc,search)
	return
def AR7eBk5HyWwv0J(url,NGQDwOCXx1BZmd9Huc=b8Qe150xVaJsnDSv):
	if NGQDwOCXx1BZmd9Huc==b8Qe150xVaJsnDSv: NGQDwOCXx1BZmd9Huc = '1'
	coE0fkBtgU759GiDKquMx = url.split('/')[-1]
	rC39wAIKjUuS = '''{"operationName":"DISCOVERY_TOPIC_MAIN_QUERY","variables":{"page":mypagenumber,"xid":"mytopicid"},"query":"fragment TOPIC_VIDEO_FRAGMENT on Video {  id  xid  title  duration  isLiked  isInWatchLater  isCreatedForKids  createdAt  isExplicit  videoHeight: height  videoWidth: width  category  channel {    id    xid    name    displayName    logoURLx25: logoURL(size: \\"x25\\")    logoURL(size: \\"x60\\")    accountType    __typename  }  stats {    id    views {      id      total      __typename    }    __typename  }  language {    id    codeAlpha2    __typename  }  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  bestAvailableQuality  aspectRatio  isPublished  __typename}query DISCOVERY_TOPIC_MAIN_QUERY($xid: String!, $page: Int = 1) {  topic(xid: $xid) {    id    xid    name    videos(sort: \\"recent\\", first: 30, page: $page) {      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...TOPIC_VIDEO_FRAGMENT          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	rC39wAIKjUuS = rC39wAIKjUuS.replace('mytopicid',coE0fkBtgU759GiDKquMx)
	rC39wAIKjUuS = rC39wAIKjUuS.replace('mypagenumber',NGQDwOCXx1BZmd9Huc)
	M43f6vQclCZObzn9aFUWTH = Du5hjHVRAOJvXdGl(rC39wAIKjUuS)
	if M43f6vQclCZObzn9aFUWTH:
		NzvEkKgJ29pFlZrRB = oJsUwXA0yGOI1mTjxQ('dict',M43f6vQclCZObzn9aFUWTH)
		jRq4oQ3XGtp2 = NzvEkKgJ29pFlZrRB['data']['topic']['videos']['edges']
		for ibUT9CL0XahAxFZBleOyzHq27cotQ in jRq4oQ3XGtp2:
			D5taEr6hnuFCcRMpTq4wSoyQOivx = str(ibUT9CL0XahAxFZBleOyzHq27cotQ['node']['duration'])
			title = ggtn0PzV7aMe(ibUT9CL0XahAxFZBleOyzHq27cotQ['node']['title'])
			title = title.replace('\/','/')
			coE0fkBtgU759GiDKquMx = ibUT9CL0XahAxFZBleOyzHq27cotQ['node']['xid']
			lvtGpMZHb9 = ibUT9CL0XahAxFZBleOyzHq27cotQ['node']['thumbnailx480']
			lvtGpMZHb9 = lvtGpMZHb9.replace('\/','/')
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/video/'+coE0fkBtgU759GiDKquMx
			MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,403,lvtGpMZHb9,D5taEr6hnuFCcRMpTq4wSoyQOivx)
		if '"hasNextPage":true' in M43f6vQclCZObzn9aFUWTH:
			NGQDwOCXx1BZmd9Huc = str(int(NGQDwOCXx1BZmd9Huc)+1)
			MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'صفحة '+NGQDwOCXx1BZmd9Huc,url,413,b8Qe150xVaJsnDSv,NGQDwOCXx1BZmd9Huc)
	return
def joBLkQuaR2dCU9yZOw(url,OwIo2yinF3kgHC5xVa):
	id = url.split('/')[-1]
	dJQDlGz1FViAyxeIH7YNZrbT8,cTlfYkLbmDH6xz9qAQj = OwIo2yinF3kgHC5xVa.split('::',1)
	pcA1dzy7LXwGfMPg9mTkuh5tine3 = wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/'+dJQDlGz1FViAyxeIH7YNZrbT8
	cTlfYkLbmDH6xz9qAQj = utSpEeMwhcRb(cTlfYkLbmDH6xz9qAQj)
	title = rC3Tlno96KjLDIvBaSWUbR8+'OWNER:  '+cTlfYkLbmDH6xz9qAQj+hAIp8kmC36T5WFPMSXOwnNbtD
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,402,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,cTlfYkLbmDH6xz9qAQj)
	rC39wAIKjUuS = '''{"operationName":"DISCOVERY_QUEUE_QUERY","variables":{"collectionXid":"myplaylistid","videoXid":"x7s7qbn"},"query":"query DISCOVERY_QUEUE_QUERY($videoXid: String!, $collectionXid: String, $device: String, $videoCountPerSection: Int) {  views {    id    neon {      id      sections(device: $device, space: \\"watching\\", followingChannelXids: [], followingTopicXids: [], watchedVideoXids: [], context: {mediaXid: $videoXid, collectionXid: $collectionXid}, first: 20) {        edges {          node {            id            name            groupingType            relatedComponent {              ... on Channel {                __typename                id                xid                name                displayName                logoURL(size: \\"x60\\")                logoURLx25: logoURL(size: \\"x25\\")              }              ... on Topic {                __typename                id                xid                name                names {                  edges {                    node {                      id                      name                      language {                        id                        codeAlpha2                        __typename                      }                      __typename                    }                    __typename                  }                  __typename                }              }              ... on Collection {                __typename                id                xid                name              }              __typename            }            components(first: $videoCountPerSection) {              metadata {                algorithm {                  name                  version                  uuid                  __typename                }                __typename              }              edges {                node {                  ... on Video {                    __typename                    id                    xid                    title                    duration                    thumbnailx60: thumbnailURL(size: \\"x60\\")                    thumbnailx120: thumbnailURL(size: \\"x120\\")                    thumbnailx240: thumbnailURL(size: \\"x240\\")                    thumbnailx720: thumbnailURL(size: \\"x720\\")                    channel {                      id                      xid                      accountType                      displayName                      logoURLx25: logoURL(size: \\"x25\\")                      logoURL(size: \\"x60\\")                      __typename                    }                  }                  ... on Channel {                    __typename                    id                    xid                    name                    displayName                    accountType                    logoURL(size: \\"x60\\")                  }                  __typename                }                __typename              }              __typename            }            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	rC39wAIKjUuS = rC39wAIKjUuS.replace('myplaylistid',id)
	jLtdbeYiQHnf4SpU2MTly = Du5hjHVRAOJvXdGl(rC39wAIKjUuS)
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('"collection_videos"(.*?)"SectionEdge"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		items = YYBlm36zd0Jst18LXwo4.findall('"node".*?"xid":"(.*?)",.*?"title":"(.*?)",.*?"duration":(.*?),".*?thumbnailx240":"(.*?)",.*?"xid":"(.*?)",.*?"displayName":"(.*?)",',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for id,title,D5taEr6hnuFCcRMpTq4wSoyQOivx,lvtGpMZHb9,dJQDlGz1FViAyxeIH7YNZrbT8,cTlfYkLbmDH6xz9qAQj in items:
			lvtGpMZHb9 = lvtGpMZHb9.replace('\/','/')
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/video/'+id
			title = utSpEeMwhcRb(title)
			OwIo2yinF3kgHC5xVa = dJQDlGz1FViAyxeIH7YNZrbT8+'::'+cTlfYkLbmDH6xz9qAQj
			MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,403,lvtGpMZHb9,D5taEr6hnuFCcRMpTq4wSoyQOivx,OwIo2yinF3kgHC5xVa)
	return
def HDA7raBO28(url,NGQDwOCXx1BZmd9Huc=b8Qe150xVaJsnDSv):
	if NGQDwOCXx1BZmd9Huc==b8Qe150xVaJsnDSv: NGQDwOCXx1BZmd9Huc = '1'
	MLBDXlxEbU9WJQImfHOnK3zpvdR = url.split('/')[-2]
	if 'sort=' in url: sort = url.split('sort=')[1].split('&')[0]
	else: sort = 'recent'
	rC39wAIKjUuS = '''{"operationName":"CHANNEL_VIDEOS_QUERY","variables":{"channel_xid":"mychannelid","sort":"mysortmethod","page":mypagenumber},"query":"fragment CHANNEL_BASE_FRAGMENT on Channel {  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  isFollowed  accountType  __typename}fragment CHANNEL_IMAGES_FRAGMENT on Channel {  id  coverURLx375: coverURL(size: \\"x375\\")  __typename}fragment CHANNEL_UPDATED_FRAGMENT on Channel {  id  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}fragment CHANNEL_COMPLETE_FRAGMENT on Channel {  id  ...CHANNEL_BASE_FRAGMENT  ...CHANNEL_IMAGES_FRAGMENT  ...CHANNEL_UPDATED_FRAGMENT  description  coverURL1024x: coverURL(size: \\"1024x\\")  coverURL1920x: coverURL(size: \\"1920x\\")  externalLinks {    facebookURL    twitterURL    websiteURL    instagramURL    __typename  }  __typename}fragment CHANNEL_FRAGMENT on Channel {  accountType  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  coverURLx375: coverURL(size: \\"x375\\")  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}fragment VIDEO_FRAGMENT on Video {  id  xid  title  viewCount  duration  createdAt  isInWatchLater  channel {    id    ...CHANNEL_FRAGMENT    __typename  }  thumbURLx240: thumbnailURL(size: \\"x240\\")  thumbURLx360: thumbnailURL(size: \\"x360\\")  thumbURLx480: thumbnailURL(size: \\"x480\\")  thumbURLx720: thumbnailURL(size: \\"x720\\")  __typename}query CHANNEL_VIDEOS_QUERY($channel_xid: String!, $sort: String, $page: Int!) {  channel(xid: $channel_xid) {    id    ...CHANNEL_COMPLETE_FRAGMENT    channel_videos_all_videos: videos(sort: $sort, page: $page, first: mypagelimit) {      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...VIDEO_FRAGMENT          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	rC39wAIKjUuS = rC39wAIKjUuS.replace('mychannelid',MLBDXlxEbU9WJQImfHOnK3zpvdR)
	rC39wAIKjUuS = rC39wAIKjUuS.replace('mypagelimit','40')
	rC39wAIKjUuS = rC39wAIKjUuS.replace('mypagenumber',NGQDwOCXx1BZmd9Huc)
	rC39wAIKjUuS = rC39wAIKjUuS.replace('mysortmethod',sort)
	jLtdbeYiQHnf4SpU2MTly = Du5hjHVRAOJvXdGl(rC39wAIKjUuS)
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('"channel_videos_all_videos"(.*?)"VideoConnection"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		items = YYBlm36zd0Jst18LXwo4.findall('"node".*?"xid":"(.*?)",.*?"title":"(.*?)",.*?"duration":(.*?),".*?name":"(.*?)",.*?"displayName":"(.*?)",.*?"thumbURLx240":"(.*?)",',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for id,title,D5taEr6hnuFCcRMpTq4wSoyQOivx,dJQDlGz1FViAyxeIH7YNZrbT8,cTlfYkLbmDH6xz9qAQj,lvtGpMZHb9 in items:
			lvtGpMZHb9 = lvtGpMZHb9.replace('\/','/')
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/video/'+id
			title = utSpEeMwhcRb(title)
			OwIo2yinF3kgHC5xVa = dJQDlGz1FViAyxeIH7YNZrbT8+'::'+cTlfYkLbmDH6xz9qAQj
			MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,403,lvtGpMZHb9,D5taEr6hnuFCcRMpTq4wSoyQOivx,OwIo2yinF3kgHC5xVa)
		if '"hasNextPage":true' in jLtdbeYiQHnf4SpU2MTly:
			NGQDwOCXx1BZmd9Huc = str(int(NGQDwOCXx1BZmd9Huc)+1)
			MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'صفحة '+NGQDwOCXx1BZmd9Huc,url,408,b8Qe150xVaJsnDSv,NGQDwOCXx1BZmd9Huc)
	return
def h5xPMpNETzVuYmH4OQj7F0nfC28r(url,NGQDwOCXx1BZmd9Huc=b8Qe150xVaJsnDSv):
	if NGQDwOCXx1BZmd9Huc==b8Qe150xVaJsnDSv: NGQDwOCXx1BZmd9Huc = '1'
	MLBDXlxEbU9WJQImfHOnK3zpvdR = url.split('/')[-2]
	if 'sort=' in url: sort = url.split('sort=')[1].split('&')[0]
	else: sort = 'recent'
	rC39wAIKjUuS = '''{"operationName":"CHANNEL_COLLECTIONS_QUERY","variables":{"channel_xid":"mychannelid","sort":"mysortmethod","page":mypagenumber},"query":"fragment CHANNEL_BASE_FRAGMENT on Channel {  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  isFollowed  accountType  __typename}fragment CHANNEL_IMAGES_FRAGMENT on Channel {  id  coverURLx375: coverURL(size: \\"x375\\")  __typename}fragment CHANNEL_UPDATED_FRAGMENT on Channel {  id  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}fragment CHANNEL_COMPLETE_FRAGMENT on Channel {  id  ...CHANNEL_BASE_FRAGMENT  ...CHANNEL_IMAGES_FRAGMENT  ...CHANNEL_UPDATED_FRAGMENT  description  coverURL1024x: coverURL(size: \\"1024x\\")  coverURL1920x: coverURL(size: \\"1920x\\")  externalLinks {    facebookURL    twitterURL    websiteURL    instagramURL    __typename  }  __typename}fragment CHANNEL_FRAGMENT on Channel {  accountType  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  coverURLx375: coverURL(size: \\"x375\\")  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}query CHANNEL_COLLECTIONS_QUERY($channel_xid: String!, $sort: String, $page: Int!) {  channel(xid: $channel_xid) {    id    ...CHANNEL_COMPLETE_FRAGMENT    channel_playlist_collections: collections(sort: $sort, page: $page, first: mypagelimit) {      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          xid          updatedAt          name          description          thumbURLx240: thumbnailURL(size: \\"x240\\")          thumbURLx360: thumbnailURL(size: \\"x360\\")          thumbURLx480: thumbnailURL(size: \\"x480\\")          stats {            videos {              total              __typename            }            __typename          }          channel {            id            ...CHANNEL_FRAGMENT            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	rC39wAIKjUuS = rC39wAIKjUuS.replace('mychannelid',MLBDXlxEbU9WJQImfHOnK3zpvdR)
	rC39wAIKjUuS = rC39wAIKjUuS.replace('mypagelimit','40')
	rC39wAIKjUuS = rC39wAIKjUuS.replace('mypagenumber',NGQDwOCXx1BZmd9Huc)
	rC39wAIKjUuS = rC39wAIKjUuS.replace('mysortmethod',sort)
	jLtdbeYiQHnf4SpU2MTly = Du5hjHVRAOJvXdGl(rC39wAIKjUuS)
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('"channel_playlist_collections"(.*?)"CollectionConnection"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		items = YYBlm36zd0Jst18LXwo4.findall('"node".*?"xid":"(.*?)",.*?"name":"(.*?)",.*?"thumbURLx240":"(.*?)",.*?"total":(.*?),".*?xid":"(.*?)",.*?"name":"(.*?)",.*?"displayName":"(.*?)",',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for id,name,lvtGpMZHb9,count,KtASGsPpz8q0mWaVwFg1knY9LX,dJQDlGz1FViAyxeIH7YNZrbT8,cTlfYkLbmDH6xz9qAQj in items:
			lvtGpMZHb9 = lvtGpMZHb9.replace('\/','/')
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/playlist/'+id
			title = 'LIST'+count+':  '+name
			title = utSpEeMwhcRb(title)
			OwIo2yinF3kgHC5xVa = dJQDlGz1FViAyxeIH7YNZrbT8+'::'+cTlfYkLbmDH6xz9qAQj
			MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,401,lvtGpMZHb9,b8Qe150xVaJsnDSv,OwIo2yinF3kgHC5xVa)
		if '"hasNextPage":true' in jLtdbeYiQHnf4SpU2MTly:
			NGQDwOCXx1BZmd9Huc = str(int(NGQDwOCXx1BZmd9Huc)+1)
			MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'صفحة '+NGQDwOCXx1BZmd9Huc,url,407,b8Qe150xVaJsnDSv,NGQDwOCXx1BZmd9Huc)
	return
def l8NrPyfjmRS(url,h5J2kRlBjpYTvCx3Em6wrstnc08G):
	MLBDXlxEbU9WJQImfHOnK3zpvdR = url.split('/')[3]
	rC39wAIKjUuS = '''{"operationName":"CHANNEL_QUERY_DESKTOP","variables":{"channel_name":"mychannelid","relatedChannels":100},"query":"fragment CHANNEL_FRAGMENT on Channel {  accountType  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  coverURLx375: coverURL(size: \\"x375\\")  isFollowed  stats {    id    views {      id      total      __typename    }    followers {      id      total      __typename    }    videos {      id      total      __typename    }    __typename  }  __typename}fragment LIVE_FRAGMENT on Live {  id  xid  title  startAt  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  channel {    id    ...CHANNEL_FRAGMENT    __typename  }  __typename}fragment VIDEO_FRAGMENT on Video {  id  xid  title  viewCount  duration  createdAt  isInWatchLater  channel {    id    ...CHANNEL_FRAGMENT    __typename  }  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment CHANNEL_MAIN_FRAGMENT on Channel {  id  xid  name  displayName  description  accountType  isArtist  logoURL(size: \\"x60\\")  coverURL1024x: coverURL(size: \\"1024x\\")  coverURL1920x: coverURL(size: \\"1920x\\")  isFollowed  tagline  country {    id    codeAlpha2    __typename  }  stats {    id    views {      id      total      __typename    }    followers {      id      total      __typename    }    videos {      id      total      __typename    }    __typename  }  externalLinks {    id    facebookURL    twitterURL    websiteURL    instagramURL    pinterestURL    __typename  }  channel_lives_now: lives(first: 4, isOnAir: true) {    edges {      node {        id        ...LIVE_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_lives_scheduled: lives(first: 4, startIn: 7200) {    edges {      node {        id        ...LIVE_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_featured_videos: videos(first: 4, isFeatured: true) {    edges {      node {        id        ...VIDEO_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_all_videos: videos(first: 4) {    edges {      node {        id        ...VIDEO_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_most_viewed: videos(first: 4, sort: \\"visited\\") {    edges {      node {        id        ...VIDEO_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_collections: collections(first: 4) {    edges {      node {        id        xid        name        description        stats {          id          videos {            id            total            __typename          }          __typename        }        thumbnailx240: thumbnailURL(size: \\"x240\\")        thumbnailx360: thumbnailURL(size: \\"x360\\")        thumbnailx480: thumbnailURL(size: \\"x480\\")        channel {          id          ...CHANNEL_FRAGMENT          __typename        }        __typename      }      __typename    }    __typename  }  channel_related_channel: networkChannels(    hasPublicVideos: true    first: $relatedChannels  ) {    edges {      node {        id        ...CHANNEL_FRAGMENT        __typename      }      __typename    }    __typename  }  __typename}query CHANNEL_QUERY_DESKTOP($channel_name: String!, $relatedChannels: Int) {  channel(name: $channel_name) {    id    ...CHANNEL_MAIN_FRAGMENT    __typename  }}"}'''
	rC39wAIKjUuS = rC39wAIKjUuS.replace('mychannelid',MLBDXlxEbU9WJQImfHOnK3zpvdR)
	jLtdbeYiQHnf4SpU2MTly = Du5hjHVRAOJvXdGl(rC39wAIKjUuS)
	WW25V3KLSnAQol = AFIDMBehNx5QH6g21E8kq9JzrLi.loads(jLtdbeYiQHnf4SpU2MTly)
	try: items = WW25V3KLSnAQol['data']['channel'][h5J2kRlBjpYTvCx3Em6wrstnc08G]['edges']
	except: items = []
	if not items: MQtuaShrKTbdZFJ5nsR7D('link',WbzmKSZiuOYrBN7oysJ2dUv+'لا توجد نتائج',b8Qe150xVaJsnDSv,9999)
	else:
		for tgoJCpq8KGrdaUSjsLh0FTxDRPfIAB in items:
			S5SnaC0IN6jFh4 = tgoJCpq8KGrdaUSjsLh0FTxDRPfIAB['node']
			coE0fkBtgU759GiDKquMx = S5SnaC0IN6jFh4['xid']
			keys = list(S5SnaC0IN6jFh4.keys())
			frvWkymeSjbVpws4QLYK9u73Z0IxT = S5SnaC0IN6jFh4['__typename'].lower()
			if frvWkymeSjbVpws4QLYK9u73Z0IxT=='channel':
				name = S5SnaC0IN6jFh4['name']
				ggseOLm7P8vih3U1kC2zq = S5SnaC0IN6jFh4['displayName']
				title = 'USER:  '+ggseOLm7P8vih3U1kC2zq
				lvtGpMZHb9 = S5SnaC0IN6jFh4['coverURLx375']
			else:
				name = S5SnaC0IN6jFh4['channel']['name']
				ggseOLm7P8vih3U1kC2zq = S5SnaC0IN6jFh4['channel']['displayName']
				title = S5SnaC0IN6jFh4['title']
				lvtGpMZHb9 = S5SnaC0IN6jFh4['thumbnailx360']
				if frvWkymeSjbVpws4QLYK9u73Z0IxT=='live': title = 'LIVE:  '+title
			title = utSpEeMwhcRb(title)
			OwIo2yinF3kgHC5xVa = name+'::'+ggseOLm7P8vih3U1kC2zq
			if hDTluNxe7tCwrpqXHzdEcYRfbs:
				title = title.encode(OVauxZzLI10vcXT74K)
				OwIo2yinF3kgHC5xVa = OwIo2yinF3kgHC5xVa.encode(OVauxZzLI10vcXT74K)
			lvtGpMZHb9 = lvtGpMZHb9.replace('\/','/')
			if frvWkymeSjbVpws4QLYK9u73Z0IxT=='channel':
				pcA1dzy7LXwGfMPg9mTkuh5tine3 = wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/'+coE0fkBtgU759GiDKquMx
				MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,402,lvtGpMZHb9,b8Qe150xVaJsnDSv,OwIo2yinF3kgHC5xVa)
			else:
				if frvWkymeSjbVpws4QLYK9u73Z0IxT=='video': D5taEr6hnuFCcRMpTq4wSoyQOivx = str(S5SnaC0IN6jFh4['duration'])
				else: D5taEr6hnuFCcRMpTq4wSoyQOivx = b8Qe150xVaJsnDSv
				pcA1dzy7LXwGfMPg9mTkuh5tine3 = wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/video/'+coE0fkBtgU759GiDKquMx
				MQtuaShrKTbdZFJ5nsR7D(frvWkymeSjbVpws4QLYK9u73Z0IxT,WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,403,lvtGpMZHb9,D5taEr6hnuFCcRMpTq4wSoyQOivx,OwIo2yinF3kgHC5xVa)
	return
def KKiWXsfLZ9Um(search,NGQDwOCXx1BZmd9Huc=b8Qe150xVaJsnDSv):
	if NGQDwOCXx1BZmd9Huc==b8Qe150xVaJsnDSv: NGQDwOCXx1BZmd9Huc = '1'
	rC39wAIKjUuS = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeHashtags":true,"shouldIncludeVideos":false,"shouldIncludeLives":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  duration  aspectRatio  thumbnail(height: PORTRAIT_240) {    id    url    __typename  }  creator {    id    xid    name    displayName    accountType    avatar(height: SQUARE_60) {      id      url      __typename    }    __typename  }  __typename}fragment CHANNEL_BASE_FRAG on Channel {  id  xid  name  displayName  accountType  isFollowed  avatar(height: SQUARE_120) {    id    url    __typename  }  followerEngagement {    id    followDate    __typename  }  metrics {    id    engagement {      id      followers {        edges {          node {            id            total            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  description  thumbnail(height: PORTRAIT_240) {    id    url    __typename  }  creator {    id    xid    name    displayName    accountType    avatar(height: SQUARE_60) {      id      url      __typename    }    __typename  }  metrics {    id    engagement {      id      videos(filter: {visibility: {eq: PUBLIC}}) {        edges {          node {            id            total            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }  __typename}fragment HASHTAG_BASE_FRAG on Hashtag {  id  xid  name  metrics {    id    engagement {      id      videos {        edges {          node {            id            total            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }  __typename}fragment LIVE_BASE_FRAGMENT on Live {  id  xid  title  audienceCount  aspectRatio  isOnAir  thumbnail(height: PORTRAIT_240) {    id    url    __typename  }  creator {    id    xid    name    displayName    accountType    avatar(height: SQUARE_60) {      id      url      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeHashtags: Boolean!, $shouldIncludeLives: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(      query: $query      first: $limit      page: $page      sort: $sortByVideos      durationMin: $durationMinVideos      durationMax: $durationMaxVideos      createdAfter: $createdAfterVideos    ) @include(if: $shouldIncludeVideos) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          __typename        }        __typename      }      __typename    }    lives(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeLives) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...LIVE_BASE_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    hashtags(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeHashtags) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...HASHTAG_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	rC39wAIKjUuS = rC39wAIKjUuS.replace('mysearchwords',search)
	rC39wAIKjUuS = rC39wAIKjUuS.replace('mypagelimit','40')
	rC39wAIKjUuS = rC39wAIKjUuS.replace('mypagenumber',NGQDwOCXx1BZmd9Huc)
	url = wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/search/'+search+'/hashtags'
	M43f6vQclCZObzn9aFUWTH = Du5hjHVRAOJvXdGl(rC39wAIKjUuS,search)
	if M43f6vQclCZObzn9aFUWTH:
		NzvEkKgJ29pFlZrRB = oJsUwXA0yGOI1mTjxQ('dict',M43f6vQclCZObzn9aFUWTH)
		try: jRq4oQ3XGtp2 = NzvEkKgJ29pFlZrRB['data']['search']['hashtags']['edges']
		except: jRq4oQ3XGtp2 = []
		for ibUT9CL0XahAxFZBleOyzHq27cotQ in jRq4oQ3XGtp2:
			name = ibUT9CL0XahAxFZBleOyzHq27cotQ['node']['name']
			name = ggtn0PzV7aMe(name)
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/hashtag/'+name[1:]
			MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'HSHTG: '+name,pcA1dzy7LXwGfMPg9mTkuh5tine3,417)
		if '"hasNextPage":true' in M43f6vQclCZObzn9aFUWTH:
			NGQDwOCXx1BZmd9Huc = str(int(NGQDwOCXx1BZmd9Huc)+1)
			MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'صفحة '+NGQDwOCXx1BZmd9Huc,url,416,b8Qe150xVaJsnDSv,NGQDwOCXx1BZmd9Huc,search)
	return
def ggUKZzhi7dvS9qA61lwNRBCx4(url,NGQDwOCXx1BZmd9Huc=b8Qe150xVaJsnDSv):
	if NGQDwOCXx1BZmd9Huc==b8Qe150xVaJsnDSv: NGQDwOCXx1BZmd9Huc = '1'
	name = url.split('/')[-1]
	rC39wAIKjUuS = '''{"operationName":"HASHTAG_VIDEOS_QUERY","variables":{"hashtag_name":"#myhashtagname","page":mypagenumber},"query":"fragment FRAG_VIDEO_BASE on Video {  id  xid  title  description  thumbnail: thumbnailURL(size: \\"x240\\")  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  bestAvailableQuality  duration  createdAt  viewerEngagement {    id    liked    favorited    __typename  }  isExplicit  canDisplayAds  aspectRatio  stats {    id    views {      id      total      __typename    }    __typename  }  language {    id    codeAlpha2    __typename  }  videoHeight: height  videoWidth: width  __typename}fragment CHANNEL_BASE_FRAG on Channel {  id  xid  name  displayName  description  logoURL(size: \\"x25\\")  logoURLx60: logoURL(size: \\"x60\\")  coverURL(size: \\"x200\\")  coverURLx1024: coverURL(size: \\"1024x\\")  isFollowed  isArtist  accountType  __typename}fragment VIDEO_FRAG on Video {  id  ...FRAG_VIDEO_BASE  channel {    id    ...CHANNEL_BASE_FRAG    __typename  }  __typename}query HASHTAG_VIDEOS_QUERY($hashtag_name: String!, $page: Int!) {  contentFeed(    name: HASHTAG    filter: {name: {eq: $hashtag_name}, post: {eq: VIDEO}}    sort: {create: DESC}    page: $page    first: 30  ) {    totalCount    pageInfo {      hasNextPage      nextPage      __typename    }    edges {      node {        post {          ...VIDEO_FRAG          __typename        }        featured        __typename      }      __typename    }    __typename  }}"}'''
	rC39wAIKjUuS = rC39wAIKjUuS.replace('myhashtagname',name)
	rC39wAIKjUuS = rC39wAIKjUuS.replace('mypagenumber',NGQDwOCXx1BZmd9Huc)
	M43f6vQclCZObzn9aFUWTH = Du5hjHVRAOJvXdGl(rC39wAIKjUuS)
	if M43f6vQclCZObzn9aFUWTH:
		NzvEkKgJ29pFlZrRB = oJsUwXA0yGOI1mTjxQ('dict',M43f6vQclCZObzn9aFUWTH)
		jRq4oQ3XGtp2 = NzvEkKgJ29pFlZrRB['data']['contentFeed']['edges']
		for ibUT9CL0XahAxFZBleOyzHq27cotQ in jRq4oQ3XGtp2:
			D5taEr6hnuFCcRMpTq4wSoyQOivx = str(ibUT9CL0XahAxFZBleOyzHq27cotQ['node']['post']['duration'])
			title = ggtn0PzV7aMe(ibUT9CL0XahAxFZBleOyzHq27cotQ['node']['post']['title'])
			title = title.replace('\/','/')
			coE0fkBtgU759GiDKquMx = ibUT9CL0XahAxFZBleOyzHq27cotQ['node']['post']['xid']
			lvtGpMZHb9 = ibUT9CL0XahAxFZBleOyzHq27cotQ['node']['post']['thumbnailx480']
			lvtGpMZHb9 = lvtGpMZHb9.replace('\/','/')
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/video/'+coE0fkBtgU759GiDKquMx
			MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,403,lvtGpMZHb9,D5taEr6hnuFCcRMpTq4wSoyQOivx)
		if '"hasNextPage":true' in M43f6vQclCZObzn9aFUWTH:
			NGQDwOCXx1BZmd9Huc = str(int(NGQDwOCXx1BZmd9Huc)+1)
			MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'صفحة '+NGQDwOCXx1BZmd9Huc,url,416,b8Qe150xVaJsnDSv,NGQDwOCXx1BZmd9Huc)
	return
def Du5hjHVRAOJvXdGl(rC39wAIKjUuS,search=b8Qe150xVaJsnDSv):
	if i1thmHk7AZquD4cM0fnp62: rC39wAIKjUuS = rC39wAIKjUuS.encode(OVauxZzLI10vcXT74K)
	SPY5DImFtpH8Oc9KW0hwViRJbfQl = KREtN9IJx1ujL2ZvrDoyOdaXUni()
	headers = {"Authorization":SPY5DImFtpH8Oc9KW0hwViRJbfQl,"Origin":wQjs1XZ3AO24g8y9bEeoKMiGIu7,'Content-Type':'text/plain; charset=utf-8'}
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(LtlXH3fvMydAx,'POST',RRtlZAxNcPqnOHgzLY7ude5rBXGToK,rC39wAIKjUuS,headers,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'DAILYMOTION-GET_PAGEDATA-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	return jLtdbeYiQHnf4SpU2MTly
def KREtN9IJx1ujL2ZvrDoyOdaXUni():
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(LtlXH3fvMydAx,'GET',wQjs1XZ3AO24g8y9bEeoKMiGIu7,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'DAILYMOTION-GET_AUTHINTICATION-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	vFnuA9gxrhBES2HaWJQq1Cid = YYBlm36zd0Jst18LXwo4.findall('var r="(.*?)",o="(.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	nNRc40Kp95bY,TTH7DByNztnYo0EXGQACs = vFnuA9gxrhBES2HaWJQq1Cid[-1]
	APSj0DRz6t25nMu4ax3CUcH = 'https://graphql.api.dailymotion.com/oauth/token'
	JV8hteIvzQZwxU = 'client_credentials'
	data = {'client_id':nNRc40Kp95bY,'client_secret':TTH7DByNztnYo0EXGQACs,'grant_type':JV8hteIvzQZwxU}
	headers = {'Content-Type':'application/x-www-form-urlencoded'}
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(LtlXH3fvMydAx,'POST',APSj0DRz6t25nMu4ax3CUcH,data,headers,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'DAILYMOTION-GET_AUTHINTICATION-2nd')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	vFnuA9gxrhBES2HaWJQq1Cid = YYBlm36zd0Jst18LXwo4.findall('"access_token": *"(.*?)".*?"token_type": *"(.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	yAgoeBV2fCUYirbPqnas,r9qhjYt0MkAW8l63 = vFnuA9gxrhBES2HaWJQq1Cid[0]
	SPY5DImFtpH8Oc9KW0hwViRJbfQl = r9qhjYt0MkAW8l63+" "+yAgoeBV2fCUYirbPqnas
	return SPY5DImFtpH8Oc9KW0hwViRJbfQl
def kstJfK6jHQWrXDSMRIGB7(search,jWqKYXlEZzQ=b8Qe150xVaJsnDSv):
	search,v7Rxw52Z4X0,showDialogs = JimhUH0SEf6w(search)
	if not jWqKYXlEZzQ and showDialogs:
		oXhFTNqtEuUpzIQWYy5PbS4 = ['بحث عن فيديوهات','بحث عن آخر الفيديوهات','بحث عن الفيديوهات الاكثر مشاهدة','(جيد للمسلسلات) بحث عن قوائم تشغيل','بحث عن مستخدم','بحث عن بث حي','بحث عن هاشتاك']
		cMZGTsAR2E = XXprCMzuNP2mElUxfdA('موقع ديلي موشن - اختر البحث',oXhFTNqtEuUpzIQWYy5PbS4)
		if cMZGTsAR2E==-1: return
		elif cMZGTsAR2E==0: jWqKYXlEZzQ = 'videos?sortBy='
		elif cMZGTsAR2E==1: jWqKYXlEZzQ = 'videos?sortBy=RECENT'
		elif cMZGTsAR2E==2: jWqKYXlEZzQ = 'videos?sortBy=VIEW_COUNT'
		elif cMZGTsAR2E==3: jWqKYXlEZzQ = 'playlists'
		elif cMZGTsAR2E==4: jWqKYXlEZzQ = 'channels'
		elif cMZGTsAR2E==5: jWqKYXlEZzQ = 'lives'
		elif cMZGTsAR2E==6: jWqKYXlEZzQ = 'hashtags'
	elif '_DAILYMOTION-VIDEOS_' in v7Rxw52Z4X0: jWqKYXlEZzQ = 'videos?sortBy='
	elif '_DAILYMOTION-PLAYLISTS_' in v7Rxw52Z4X0: jWqKYXlEZzQ = 'playlists'
	elif '_DAILYMOTION-CHANNELS_' in v7Rxw52Z4X0: jWqKYXlEZzQ = 'channels'
	elif '_DAILYMOTION-LIVES_' in v7Rxw52Z4X0: jWqKYXlEZzQ = 'lives'
	elif '_DAILYMOTION-HASHTAGS_' in v7Rxw52Z4X0: jWqKYXlEZzQ = 'hashtags'
	elif not jWqKYXlEZzQ: jWqKYXlEZzQ = 'videos?sortBy='
	if not search:
		search = FT2oXWtPQpVGuexmLqKN3srdzYn()
		if not search: return
	if 'videos' in jWqKYXlEZzQ: ya2xbq6eIvJcOEPMQnrj7D4z(search+'/'+jWqKYXlEZzQ)
	elif 'playlists' in jWqKYXlEZzQ: mcu9MHDE0GyfSdastFpVi(search)
	elif 'channels' in jWqKYXlEZzQ: fSDagBuHtGZRQeFnMPk8XNWv6A9(search)
	elif 'lives' in jWqKYXlEZzQ: GERO8jdBC5Mmt0Fa2o7XVlrI4cgY(search)
	elif 'hashtags' in jWqKYXlEZzQ: KKiWXsfLZ9Um(search)
	return
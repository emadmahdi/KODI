﻿# -*- coding: utf-8 -*-
from hIVCFnfxSO import *
def x8IFqMZeJj7suCR4AaGoNXfEHm(ZZtDTHnBXMz,cforq8jxC6K725dTnISa3kXg04zulY):
	if cforq8jxC6K725dTnISa3kXg04zulY==b8Qe150xVaJsnDSv: return
	if ZZtDTHnBXMz==1:
		jrJnaqCTcAusIvKB1lF0XStZEHxoy = evil9I2DnLJcy8.getCurrentWindowDialogId()
		ADozXkQPlKr6ZJnMYiOc7Rq2Ip = evil9I2DnLJcy8.Window(jrJnaqCTcAusIvKB1lF0XStZEHxoy)
		cforq8jxC6K725dTnISa3kXg04zulY = ZZN9Mjkl4wWy0OV5axfqz(cforq8jxC6K725dTnISa3kXg04zulY)
		ADozXkQPlKr6ZJnMYiOc7Rq2Ip.getControl(311).setLabel(cforq8jxC6K725dTnISa3kXg04zulY)
	if ZZtDTHnBXMz==0:
		E57WK4m31C8='X'
		if i1thmHk7AZquD4cM0fnp62: nkr5IQ20stWEwNCMJuabFi = isinstance(cforq8jxC6K725dTnISa3kXg04zulY,str)
		else: nkr5IQ20stWEwNCMJuabFi = isinstance(cforq8jxC6K725dTnISa3kXg04zulY,unicode)
		if nkr5IQ20stWEwNCMJuabFi==True: E57WK4m31C8='U'
		I1IixJepof4qCThSUnQ9G5lkaO=str(type(cforq8jxC6K725dTnISa3kXg04zulY))+pldxivXC5wbTB2O8q+cforq8jxC6K725dTnISa3kXg04zulY+pldxivXC5wbTB2O8q+E57WK4m31C8+pldxivXC5wbTB2O8q
		for FbcUxvE17ewlWNBHgS8Jn in range(0,len(cforq8jxC6K725dTnISa3kXg04zulY),1):
			I1IixJepof4qCThSUnQ9G5lkaO += hex(ord(cforq8jxC6K725dTnISa3kXg04zulY[FbcUxvE17ewlWNBHgS8Jn])).replace('0x',b8Qe150xVaJsnDSv)+pldxivXC5wbTB2O8q
		cforq8jxC6K725dTnISa3kXg04zulY = ZZN9Mjkl4wWy0OV5axfqz(cforq8jxC6K725dTnISa3kXg04zulY)
		E57WK4m31C8='X'
		if i1thmHk7AZquD4cM0fnp62: nkr5IQ20stWEwNCMJuabFi = isinstance(cforq8jxC6K725dTnISa3kXg04zulY, str)
		else: nkr5IQ20stWEwNCMJuabFi = isinstance(cforq8jxC6K725dTnISa3kXg04zulY, unicode)
		if nkr5IQ20stWEwNCMJuabFi==True: E57WK4m31C8='U'
		Ru17ot6fZn53FwaVDLE=str(type(cforq8jxC6K725dTnISa3kXg04zulY))+pldxivXC5wbTB2O8q+cforq8jxC6K725dTnISa3kXg04zulY+pldxivXC5wbTB2O8q+E57WK4m31C8+pldxivXC5wbTB2O8q
		for FbcUxvE17ewlWNBHgS8Jn in range(0,len(cforq8jxC6K725dTnISa3kXg04zulY),1):
			Ru17ot6fZn53FwaVDLE += hex(ord(cforq8jxC6K725dTnISa3kXg04zulY[FbcUxvE17ewlWNBHgS8Jn])).replace('0x',b8Qe150xVaJsnDSv)+pldxivXC5wbTB2O8q
	return
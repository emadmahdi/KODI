# -*- coding: utf-8 -*-
from hIVCFnfxSO import *
QQ8pvXNcBfVkP5rRJ7o = 'GLOBALSEARCH'
WbzmKSZiuOYrBN7oysJ2dUv = '_GLS_'
def x8IFqMZeJj7suCR4AaGoNXfEHm(ZZtDTHnBXMz,uuNDjbit4hOpx,pnmsJqCWIHVk2Y6xPvl9Q0Ez8r,NGQDwOCXx1BZmd9Huc):
	if   ZZtDTHnBXMz==540: XXxlOLJ9KRjPH382WVCvr6n71 = Y72YmLgw4vqlHxTCkbeKSicasD()
	elif ZZtDTHnBXMz==541: XXxlOLJ9KRjPH382WVCvr6n71 = qDOI7Yo463TJF2LrHuXUj(pnmsJqCWIHVk2Y6xPvl9Q0Ez8r)
	elif ZZtDTHnBXMz==542: XXxlOLJ9KRjPH382WVCvr6n71 = YQW7EwP2saL(pnmsJqCWIHVk2Y6xPvl9Q0Ez8r,uuNDjbit4hOpx,NGQDwOCXx1BZmd9Huc)
	elif ZZtDTHnBXMz==543: XXxlOLJ9KRjPH382WVCvr6n71 = Aip73u5PFbyZdgSXOtYG()
	elif ZZtDTHnBXMz==548: XXxlOLJ9KRjPH382WVCvr6n71 = C4rys9lhF7dxiUL(uuNDjbit4hOpx,pnmsJqCWIHVk2Y6xPvl9Q0Ez8r)
	elif ZZtDTHnBXMz==549: XXxlOLJ9KRjPH382WVCvr6n71 = kstJfK6jHQWrXDSMRIGB7(pnmsJqCWIHVk2Y6xPvl9Q0Ez8r)
	else: XXxlOLJ9KRjPH382WVCvr6n71 = False
	return XXxlOLJ9KRjPH382WVCvr6n71
def Y72YmLgw4vqlHxTCkbeKSicasD():
	MQtuaShrKTbdZFJ5nsR7D('folder','بحث جديد لجميع المواقع',b8Qe150xVaJsnDSv,549)
	MQtuaShrKTbdZFJ5nsR7D('link','كيف يعمل بحث جميع المواقع','',543)
	MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+'==== كلمات البحث المخزنة ===='+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999)
	ssHGOFoRvzanWq4wIDcQiy7VteUf5 = SS2OK7hjLagvUAm(mshLJcKH1fv03yRnDOr4ZT,'dict','GLOBALSEARCH_SPLITTED_ALL')
	if ssHGOFoRvzanWq4wIDcQiy7VteUf5:
		ssHGOFoRvzanWq4wIDcQiy7VteUf5 = ssHGOFoRvzanWq4wIDcQiy7VteUf5['__SEQUENCED_COLUMNS__']
		for oGjfrQp5bLaN6dYFhkTx9sWJ in reversed(ssHGOFoRvzanWq4wIDcQiy7VteUf5):
			MQtuaShrKTbdZFJ5nsR7D('folder',oGjfrQp5bLaN6dYFhkTx9sWJ,b8Qe150xVaJsnDSv,549,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,oGjfrQp5bLaN6dYFhkTx9sWJ)
	return
def kstJfK6jHQWrXDSMRIGB7(oGjfrQp5bLaN6dYFhkTx9sWJ):
	if not oGjfrQp5bLaN6dYFhkTx9sWJ:
		oGjfrQp5bLaN6dYFhkTx9sWJ = FT2oXWtPQpVGuexmLqKN3srdzYn()
		if not oGjfrQp5bLaN6dYFhkTx9sWJ: return
		oGjfrQp5bLaN6dYFhkTx9sWJ = oGjfrQp5bLaN6dYFhkTx9sWJ.lower()
	RRk9Ki5nPSfAZqC = oGjfrQp5bLaN6dYFhkTx9sWJ.replace(WbzmKSZiuOYrBN7oysJ2dUv,b8Qe150xVaJsnDSv)
	osEQDReMbav(RRk9Ki5nPSfAZqC,'_ALL',True)
	MQtuaShrKTbdZFJ5nsR7D('link','بحث جماعي للمواقع - '+RRk9Ki5nPSfAZqC,'search_sites_all',542,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,RRk9Ki5nPSfAZqC)
	MQtuaShrKTbdZFJ5nsR7D('folder','بحث منفرد للمواقع - '+RRk9Ki5nPSfAZqC,b8Qe150xVaJsnDSv,541,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,RRk9Ki5nPSfAZqC)
	MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+'===== ===== ===== '+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999)
	MQtuaShrKTbdZFJ5nsR7D('folder','نتائج البحث مفصلة - '+RRk9Ki5nPSfAZqC,'opened_sites_all',542,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,RRk9Ki5nPSfAZqC)
	MQtuaShrKTbdZFJ5nsR7D('folder','نتائج البحث مقسمة - '+RRk9Ki5nPSfAZqC,'listed_sites_all',542,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,RRk9Ki5nPSfAZqC)
	return
def osEQDReMbav(owWkDqGErbBC3TzcuxjYeXOMA5dK,YWQTJiArzc2,o61p9qFsVB7KQt8z):
	if YWQTJiArzc2=='_ALL': ovTraZ2MmfLDWt3SeKXiHwOFB = '_GLS_'
	elif YWQTJiArzc2=='_GOOGLE': ovTraZ2MmfLDWt3SeKXiHwOFB = '_GOS_'
	tlVaYSnMG7m6fvCTgi1I9rQe = SS2OK7hjLagvUAm(mshLJcKH1fv03yRnDOr4ZT,'list','GLOBALSEARCH_SPLITTED'+YWQTJiArzc2,owWkDqGErbBC3TzcuxjYeXOMA5dK)
	iiMqY6SVLdPhxbaF53t7wv = SS2OK7hjLagvUAm(mshLJcKH1fv03yRnDOr4ZT,'list','GLOBALSEARCH_SPLITTED'+YWQTJiArzc2,ovTraZ2MmfLDWt3SeKXiHwOFB+owWkDqGErbBC3TzcuxjYeXOMA5dK)
	zqbhiLmQfC3VK9Arku(mshLJcKH1fv03yRnDOr4ZT,'GLOBALSEARCH_SPLITTED'+YWQTJiArzc2,owWkDqGErbBC3TzcuxjYeXOMA5dK)
	zqbhiLmQfC3VK9Arku(mshLJcKH1fv03yRnDOr4ZT,'GLOBALSEARCH_SPLITTED'+YWQTJiArzc2,ovTraZ2MmfLDWt3SeKXiHwOFB+owWkDqGErbBC3TzcuxjYeXOMA5dK)
	LLNk3wIqyOPW = tlVaYSnMG7m6fvCTgi1I9rQe+iiMqY6SVLdPhxbaF53t7wv
	if LLNk3wIqyOPW and o61p9qFsVB7KQt8z: owWkDqGErbBC3TzcuxjYeXOMA5dK = ovTraZ2MmfLDWt3SeKXiHwOFB+owWkDqGErbBC3TzcuxjYeXOMA5dK
	PGudrhJF8iDkSq96XVHEQZYf5L(mshLJcKH1fv03yRnDOr4ZT,'GLOBALSEARCH_SPLITTED'+YWQTJiArzc2,owWkDqGErbBC3TzcuxjYeXOMA5dK,LLNk3wIqyOPW,xkDunX3BfFiYG)
	return
def ideYhTS9Kxw6njU3kW(YWQTJiArzc2):
	aVwGA2kFY6u4m = BjMmX1vNrnzSAf(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'رسالة من المبرمج','هل تريد مسح جميع كلمات البحث المخزنة في البرنامج ؟!!')
	if aVwGA2kFY6u4m!=1: return
	zqbhiLmQfC3VK9Arku(mshLJcKH1fv03yRnDOr4ZT,'GLOBALSEARCH_SPLITTED'+YWQTJiArzc2)
	zqbhiLmQfC3VK9Arku(mshLJcKH1fv03yRnDOr4ZT,'GLOBALSEARCH_DETAILED'+YWQTJiArzc2)
	zqbhiLmQfC3VK9Arku(mshLJcKH1fv03yRnDOr4ZT,'GLOBALSEARCH_DIVIDED'+YWQTJiArzc2)
	if YWQTJiArzc2=='_GOOGLE': zqbhiLmQfC3VK9Arku(mshLJcKH1fv03yRnDOr4ZT,'GOOGLESEARCH_RESULTS')
	tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'رسالة من المبرمج','تم بنجاح مسح جميع كلمات البحث المخزنة في البرنامج')
	return
def YQW7EwP2saL(n7nJFXtWAE4K92vY,ve2AaVRldtLnZNDFGXiTwm3g,fA5THLmdZw9ljNqiFDWB=b8Qe150xVaJsnDSv,oWsYTLKj58EFwQDS3vBmzCZu=djEh4qtWn9H,rMUsC23e4XEyAv9x1c7RjH={}):
	CrMsjSZ7VW1DPxyvAgYUpRTJ,vNLVUShBK3koM,nZfcuvozPXSQ,i0GQPkL6gIrbOW1F,ppEmnd9lvrHBK6tNwL5MjkR = [],{},{},{},{}
	if '_all' in ve2AaVRldtLnZNDFGXiTwm3g: YWQTJiArzc2,dwZ5a7InmqCcH,ovTraZ2MmfLDWt3SeKXiHwOFB = '_ALL','_all','_GLS_'
	elif '_google' in ve2AaVRldtLnZNDFGXiTwm3g: YWQTJiArzc2,dwZ5a7InmqCcH,ovTraZ2MmfLDWt3SeKXiHwOFB = '_GOOGLE','_google','_GOS_'
	if ve2AaVRldtLnZNDFGXiTwm3g in ['listed_sites'+dwZ5a7InmqCcH,'opened_sites'+dwZ5a7InmqCcH,'closed_sites'+dwZ5a7InmqCcH]:
		if ve2AaVRldtLnZNDFGXiTwm3g=='listed_sites'+dwZ5a7InmqCcH: CrMsjSZ7VW1DPxyvAgYUpRTJ = SS2OK7hjLagvUAm(mshLJcKH1fv03yRnDOr4ZT,'list','GLOBALSEARCH_SPLITTED'+YWQTJiArzc2,ovTraZ2MmfLDWt3SeKXiHwOFB+n7nJFXtWAE4K92vY)
		elif ve2AaVRldtLnZNDFGXiTwm3g=='opened_sites'+dwZ5a7InmqCcH: CrMsjSZ7VW1DPxyvAgYUpRTJ = SS2OK7hjLagvUAm(mshLJcKH1fv03yRnDOr4ZT,'list','GLOBALSEARCH_DETAILED'+YWQTJiArzc2,n7nJFXtWAE4K92vY)
		elif ve2AaVRldtLnZNDFGXiTwm3g=='closed_sites'+dwZ5a7InmqCcH: CrMsjSZ7VW1DPxyvAgYUpRTJ = SS2OK7hjLagvUAm(mshLJcKH1fv03yRnDOr4ZT,'list','GLOBALSEARCH_DIVIDED'+YWQTJiArzc2,(fA5THLmdZw9ljNqiFDWB,n7nJFXtWAE4K92vY))
	if not CrMsjSZ7VW1DPxyvAgYUpRTJ:
		FSpIEkeP1D3ai4VZ5oB92zhy = 'هذا البحث غير موجود في كاش البرنامج \n\n\n'
		eqURlBsy0m82xwA = 'هل تريد الآن البحث في جميع المواقع عن \n "'+OkuB9nwhD8U1+pldxivXC5wbTB2O8q+n7nJFXtWAE4K92vY+pldxivXC5wbTB2O8q+hAIp8kmC36T5WFPMSXOwnNbtD+'" \n علما أن هذا البحث قد يحتاج بعض الوقت'
		if ve2AaVRldtLnZNDFGXiTwm3g=='search_sites'+dwZ5a7InmqCcH: A4gdSTQDP2FyBIVuba85RvYqKU = eqURlBsy0m82xwA
		else: A4gdSTQDP2FyBIVuba85RvYqKU = FSpIEkeP1D3ai4VZ5oB92zhy+eqURlBsy0m82xwA
		aVwGA2kFY6u4m = BjMmX1vNrnzSAf(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'رسالة من المبرمج',A4gdSTQDP2FyBIVuba85RvYqKU)
		if aVwGA2kFY6u4m!=1: return
		PDanwWu4bFAhe3m(False,False,False)
		mwIxD3GBPgLVc2aq9(MtTygrzXFlQ,EECz06teoykrNFfq(QQ8pvXNcBfVkP5rRJ7o)+'   Search For: [ '+n7nJFXtWAE4K92vY+' ]')
		Oxc6CJVZgnEjkhoLiduHrKDSv = 1
		for TFAmLfwypkzsP1UYCMr8c in oWsYTLKj58EFwQDS3vBmzCZu:
			y5Pwi3cmBU = rMUsC23e4XEyAv9x1c7RjH[TFAmLfwypkzsP1UYCMr8c] if rMUsC23e4XEyAv9x1c7RjH else n7nJFXtWAE4K92vY
			try: drHgqFcWbNv82tVEhDMT5,Bgb2Tkp6fK0CGvWYUZFtAzr,bhNwipmnY26A83qIEyDt0jQTso = MMUq0NsIxei5bK(TFAmLfwypkzsP1UYCMr8c)
			except: continue
			vNLVUShBK3koM[TFAmLfwypkzsP1UYCMr8c] = []
			SHk0ThDndgJW = '_NODIALOGS_'
			if '-' in TFAmLfwypkzsP1UYCMr8c: SHk0ThDndgJW = SHk0ThDndgJW+'_REMEMBERRESULTS__'+TFAmLfwypkzsP1UYCMr8c+'_'
			if Oxc6CJVZgnEjkhoLiduHrKDSv:
				wLQCTr5lqbsVYeAHdzfhZ1F.sleep(0.75)
				ppEmnd9lvrHBK6tNwL5MjkR[TFAmLfwypkzsP1UYCMr8c] = Ay1SMOzkx5CU3aGTL4Zf.Thread(target=Bgb2Tkp6fK0CGvWYUZFtAzr,args=(y5Pwi3cmBU+SHk0ThDndgJW,))
				ppEmnd9lvrHBK6tNwL5MjkR[TFAmLfwypkzsP1UYCMr8c].start()
			else: Bgb2Tkp6fK0CGvWYUZFtAzr(y5Pwi3cmBU+SHk0ThDndgJW)
			yicQV3gj4q(OJ5kiNTSpIdCco0H(TFAmLfwypkzsP1UYCMr8c),b8Qe150xVaJsnDSv,wLQCTr5lqbsVYeAHdzfhZ1F=1000)
		if Oxc6CJVZgnEjkhoLiduHrKDSv:
			wLQCTr5lqbsVYeAHdzfhZ1F.sleep(2)
			for TFAmLfwypkzsP1UYCMr8c in oWsYTLKj58EFwQDS3vBmzCZu: ppEmnd9lvrHBK6tNwL5MjkR[TFAmLfwypkzsP1UYCMr8c].join(10)
			wLQCTr5lqbsVYeAHdzfhZ1F.sleep(2)
		for TFAmLfwypkzsP1UYCMr8c in oWsYTLKj58EFwQDS3vBmzCZu:
			try: drHgqFcWbNv82tVEhDMT5,Bgb2Tkp6fK0CGvWYUZFtAzr,bhNwipmnY26A83qIEyDt0jQTso = MMUq0NsIxei5bK(TFAmLfwypkzsP1UYCMr8c)
			except: continue
			for aA3sfhwtnGR2Plv8Ou in GyjmfosC59Jub:
				A60AIQZCYRzdhaeWfOtmrSUVoq2nN,c17XeRIH2gVh3px8sw,uuNDjbit4hOpx,ZZtDTHnBXMz,I6YPOSofrpnTwRm8b,NGQDwOCXx1BZmd9Huc,pnmsJqCWIHVk2Y6xPvl9Q0Ez8r,wc0Z9FAdf2B1J,XXra5dzn8tcLOxYZIE7pPof49Hh = aA3sfhwtnGR2Plv8Ou
				if bhNwipmnY26A83qIEyDt0jQTso in c17XeRIH2gVh3px8sw:
					if 'IPTV-' in TFAmLfwypkzsP1UYCMr8c and (239>=ZZtDTHnBXMz>=230 or 289>=ZZtDTHnBXMz>=280):
						if aA3sfhwtnGR2Plv8Ou in vNLVUShBK3koM['IPTV-LIVE']: continue
						if aA3sfhwtnGR2Plv8Ou in vNLVUShBK3koM['IPTV-MOVIES']: continue
						if aA3sfhwtnGR2Plv8Ou in vNLVUShBK3koM['IPTV-SERIES']: continue
						if 'صفحة' not in c17XeRIH2gVh3px8sw:
							if   A60AIQZCYRzdhaeWfOtmrSUVoq2nN=='live': TFAmLfwypkzsP1UYCMr8c = 'IPTV-LIVE'
							elif A60AIQZCYRzdhaeWfOtmrSUVoq2nN=='video': TFAmLfwypkzsP1UYCMr8c = 'IPTV-MOVIES'
							elif A60AIQZCYRzdhaeWfOtmrSUVoq2nN=='folder': TFAmLfwypkzsP1UYCMr8c = 'IPTV-SERIES'
						else:
							if   'LIVE' in uuNDjbit4hOpx: TFAmLfwypkzsP1UYCMr8c = 'IPTV-LIVE'
							elif 'MOVIES' in uuNDjbit4hOpx: TFAmLfwypkzsP1UYCMr8c = 'IPTV-MOVIES'
							elif 'SERIES' in uuNDjbit4hOpx: TFAmLfwypkzsP1UYCMr8c = 'IPTV-SERIES'
					elif 'M3U-' in TFAmLfwypkzsP1UYCMr8c and 729>=ZZtDTHnBXMz>=710:
						if aA3sfhwtnGR2Plv8Ou in vNLVUShBK3koM['M3U-LIVE']: continue
						if aA3sfhwtnGR2Plv8Ou in vNLVUShBK3koM['M3U-MOVIES']: continue
						if aA3sfhwtnGR2Plv8Ou in vNLVUShBK3koM['M3U-SERIES']: continue
						if 'صفحة' not in c17XeRIH2gVh3px8sw:
							if   A60AIQZCYRzdhaeWfOtmrSUVoq2nN=='live': TFAmLfwypkzsP1UYCMr8c = 'M3U-LIVE'
							elif A60AIQZCYRzdhaeWfOtmrSUVoq2nN=='video': TFAmLfwypkzsP1UYCMr8c = 'M3U-MOVIES'
							elif A60AIQZCYRzdhaeWfOtmrSUVoq2nN=='folder': TFAmLfwypkzsP1UYCMr8c = 'M3U-SERIES'
						else:
							if   'LIVE' in uuNDjbit4hOpx: TFAmLfwypkzsP1UYCMr8c = 'M3U-LIVE'
							elif 'MOVIES' in uuNDjbit4hOpx: TFAmLfwypkzsP1UYCMr8c = 'M3U-MOVIES'
							elif 'SERIES' in uuNDjbit4hOpx: TFAmLfwypkzsP1UYCMr8c = 'M3U-SERIES'
					elif 'YOUTUBE-' in TFAmLfwypkzsP1UYCMr8c and 149>=ZZtDTHnBXMz>=140:
						if aA3sfhwtnGR2Plv8Ou in vNLVUShBK3koM['YOUTUBE-CHANNELS']: continue
						if aA3sfhwtnGR2Plv8Ou in vNLVUShBK3koM['YOUTUBE-PLAYLISTS']: continue
						if aA3sfhwtnGR2Plv8Ou in vNLVUShBK3koM['YOUTUBE-VIDEOS']: continue
						if 'صفحة أخرى' in c17XeRIH2gVh3px8sw or ':: ' in c17XeRIH2gVh3px8sw:
							continue
						else:
							if   ZZtDTHnBXMz==144 and 'USER' in c17XeRIH2gVh3px8sw: TFAmLfwypkzsP1UYCMr8c = 'YOUTUBE-CHANNELS'
							elif ZZtDTHnBXMz==144 and 'CHNL' in c17XeRIH2gVh3px8sw: TFAmLfwypkzsP1UYCMr8c = 'YOUTUBE-CHANNELS'
							elif ZZtDTHnBXMz==144 and 'LIST' in c17XeRIH2gVh3px8sw: TFAmLfwypkzsP1UYCMr8c = 'YOUTUBE-PLAYLISTS'
							elif ZZtDTHnBXMz==143: TFAmLfwypkzsP1UYCMr8c = 'YOUTUBE-VIDEOS'
							else: continue
					elif 'DAILYMOTION-' in TFAmLfwypkzsP1UYCMr8c and 419>=ZZtDTHnBXMz>=400:
						if aA3sfhwtnGR2Plv8Ou in vNLVUShBK3koM['DAILYMOTION-PLAYLISTS']: continue
						if aA3sfhwtnGR2Plv8Ou in vNLVUShBK3koM['DAILYMOTION-CHANNELS']: continue
						if aA3sfhwtnGR2Plv8Ou in vNLVUShBK3koM['DAILYMOTION-VIDEOS']: continue
						if aA3sfhwtnGR2Plv8Ou in vNLVUShBK3koM['DAILYMOTION-LIVES']: continue
						if aA3sfhwtnGR2Plv8Ou in vNLVUShBK3koM['DAILYMOTION-HASHTAGS']: continue
						if   ZZtDTHnBXMz in [401,405]: TFAmLfwypkzsP1UYCMr8c = 'DAILYMOTION-PLAYLISTS'
						elif ZZtDTHnBXMz in [402,406]: TFAmLfwypkzsP1UYCMr8c = 'DAILYMOTION-CHANNELS'
						elif ZZtDTHnBXMz in [404]: TFAmLfwypkzsP1UYCMr8c = 'DAILYMOTION-VIDEOS'
						elif ZZtDTHnBXMz in [415]: TFAmLfwypkzsP1UYCMr8c = 'DAILYMOTION-LIVES'
						elif ZZtDTHnBXMz in [416]: TFAmLfwypkzsP1UYCMr8c = 'DAILYMOTION-HASHTAGS'
					elif 'PANET-' in TFAmLfwypkzsP1UYCMr8c and 39>=ZZtDTHnBXMz>=30:
						if aA3sfhwtnGR2Plv8Ou in vNLVUShBK3koM['PANET-SERIES']: continue
						if aA3sfhwtnGR2Plv8Ou in vNLVUShBK3koM['PANET-MOVIES']: continue
						if   ZZtDTHnBXMz in [32,39]: TFAmLfwypkzsP1UYCMr8c = 'PANET-SERIES'
						elif ZZtDTHnBXMz in [33,39]: TFAmLfwypkzsP1UYCMr8c = 'PANET-MOVIES'
					elif 'IFILM-' in TFAmLfwypkzsP1UYCMr8c and 29>=ZZtDTHnBXMz>=20:
						if aA3sfhwtnGR2Plv8Ou in vNLVUShBK3koM['IFILM-ARABIC']: continue
						if aA3sfhwtnGR2Plv8Ou in vNLVUShBK3koM['IFILM-ENGLISH']: continue
						if   '/ar.' in uuNDjbit4hOpx: TFAmLfwypkzsP1UYCMr8c = 'IFILM-ARABIC'
						elif '/en.' in uuNDjbit4hOpx: TFAmLfwypkzsP1UYCMr8c = 'IFILM-ENGLISH'
					vNLVUShBK3koM[TFAmLfwypkzsP1UYCMr8c].append(aA3sfhwtnGR2Plv8Ou)
		for TFAmLfwypkzsP1UYCMr8c in list(vNLVUShBK3koM.keys()):
			nZfcuvozPXSQ[TFAmLfwypkzsP1UYCMr8c] = []
			i0GQPkL6gIrbOW1F[TFAmLfwypkzsP1UYCMr8c] = []
			for A60AIQZCYRzdhaeWfOtmrSUVoq2nN,c17XeRIH2gVh3px8sw,uuNDjbit4hOpx,ZZtDTHnBXMz,I6YPOSofrpnTwRm8b,NGQDwOCXx1BZmd9Huc,pnmsJqCWIHVk2Y6xPvl9Q0Ez8r,wc0Z9FAdf2B1J,XXra5dzn8tcLOxYZIE7pPof49Hh in vNLVUShBK3koM[TFAmLfwypkzsP1UYCMr8c]:
				aA3sfhwtnGR2Plv8Ou = (A60AIQZCYRzdhaeWfOtmrSUVoq2nN,c17XeRIH2gVh3px8sw,uuNDjbit4hOpx,ZZtDTHnBXMz,I6YPOSofrpnTwRm8b,NGQDwOCXx1BZmd9Huc,pnmsJqCWIHVk2Y6xPvl9Q0Ez8r,wc0Z9FAdf2B1J,XXra5dzn8tcLOxYZIE7pPof49Hh)
				if 'صفحة' in c17XeRIH2gVh3px8sw and A60AIQZCYRzdhaeWfOtmrSUVoq2nN=='folder': i0GQPkL6gIrbOW1F[TFAmLfwypkzsP1UYCMr8c].append(aA3sfhwtnGR2Plv8Ou)
				else: nZfcuvozPXSQ[TFAmLfwypkzsP1UYCMr8c].append(aA3sfhwtnGR2Plv8Ou)
		kkvdyNBxT5ZWlA0n9weu42zDY,p3BFgEAIvN6kQd0a = [],[]
		M6VfOXgtvuFd2UGr = list(nZfcuvozPXSQ.keys())
		uaOf3Ajwiv = aOAE24IDufWJlKUyrFsYz(M6VfOXgtvuFd2UGr)
		D0X6QWl1gMFIypOUZCqd4 = []
		for TFAmLfwypkzsP1UYCMr8c in uaOf3Ajwiv:
			if 'tuple' in str(type(TFAmLfwypkzsP1UYCMr8c)):
				D0X6QWl1gMFIypOUZCqd4 = [TFAmLfwypkzsP1UYCMr8c]
				continue
			if TFAmLfwypkzsP1UYCMr8c not in oWsYTLKj58EFwQDS3vBmzCZu: continue
			if nZfcuvozPXSQ[TFAmLfwypkzsP1UYCMr8c]:
				NtWZkgdDsv8nJyTiXIA = OJ5kiNTSpIdCco0H(TFAmLfwypkzsP1UYCMr8c)
				GrVtF3ujJMDeL15v6OWIznqiABobT = [('link',OkuB9nwhD8U1+'===== '+NtWZkgdDsv8nJyTiXIA+' ====='+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv)]
				if 0: HDcr7hGSb04niAqVYkNWam1y = n7nJFXtWAE4K92vY+' - '+'بحث'+pldxivXC5wbTB2O8q+NtWZkgdDsv8nJyTiXIA
				else: HDcr7hGSb04niAqVYkNWam1y = 'بحث'+pldxivXC5wbTB2O8q+NtWZkgdDsv8nJyTiXIA+' - '+n7nJFXtWAE4K92vY
				if len(nZfcuvozPXSQ[TFAmLfwypkzsP1UYCMr8c])<8: d4lMfVgheHQ9UG1aW6EI3n8ALJD7 = []
				else:
					Ft5XEcNzmLO0vSsM6lCRZoq = rC3Tlno96KjLDIvBaSWUbR8+HDcr7hGSb04niAqVYkNWam1y+hAIp8kmC36T5WFPMSXOwnNbtD
					d4lMfVgheHQ9UG1aW6EI3n8ALJD7 = [('folder',ovTraZ2MmfLDWt3SeKXiHwOFB+Ft5XEcNzmLO0vSsM6lCRZoq,'closed_sites'+dwZ5a7InmqCcH,542,b8Qe150xVaJsnDSv,TFAmLfwypkzsP1UYCMr8c,n7nJFXtWAE4K92vY,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv)]
				gWqwdL7jpxImrZac = nZfcuvozPXSQ[TFAmLfwypkzsP1UYCMr8c]+i0GQPkL6gIrbOW1F[TFAmLfwypkzsP1UYCMr8c]
				RRG06KXhlVz2JwqQrfnBHPsW = D0X6QWl1gMFIypOUZCqd4+GrVtF3ujJMDeL15v6OWIznqiABobT+gWqwdL7jpxImrZac[:7]+d4lMfVgheHQ9UG1aW6EI3n8ALJD7
				kkvdyNBxT5ZWlA0n9weu42zDY += RRG06KXhlVz2JwqQrfnBHPsW
				kNBRLEHTnx9iuf7 = [('folder',ovTraZ2MmfLDWt3SeKXiHwOFB+HDcr7hGSb04niAqVYkNWam1y,'closed_sites'+dwZ5a7InmqCcH,542,b8Qe150xVaJsnDSv,TFAmLfwypkzsP1UYCMr8c,n7nJFXtWAE4K92vY,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv)]
				s16WAfG97qMTvjuE0tJb = D0X6QWl1gMFIypOUZCqd4+kNBRLEHTnx9iuf7
				p3BFgEAIvN6kQd0a += s16WAfG97qMTvjuE0tJb
				PGudrhJF8iDkSq96XVHEQZYf5L(mshLJcKH1fv03yRnDOr4ZT,'GLOBALSEARCH_DIVIDED'+YWQTJiArzc2,(TFAmLfwypkzsP1UYCMr8c,n7nJFXtWAE4K92vY),gWqwdL7jpxImrZac,xkDunX3BfFiYG)
				D0X6QWl1gMFIypOUZCqd4 = []
		PGudrhJF8iDkSq96XVHEQZYf5L(mshLJcKH1fv03yRnDOr4ZT,'GLOBALSEARCH_DETAILED'+YWQTJiArzc2,n7nJFXtWAE4K92vY,kkvdyNBxT5ZWlA0n9weu42zDY,xkDunX3BfFiYG)
		zqbhiLmQfC3VK9Arku(mshLJcKH1fv03yRnDOr4ZT,'GLOBALSEARCH_SPLITTED'+YWQTJiArzc2,n7nJFXtWAE4K92vY)
		PGudrhJF8iDkSq96XVHEQZYf5L(mshLJcKH1fv03yRnDOr4ZT,'GLOBALSEARCH_SPLITTED'+YWQTJiArzc2,ovTraZ2MmfLDWt3SeKXiHwOFB+n7nJFXtWAE4K92vY,p3BFgEAIvN6kQd0a,xkDunX3BfFiYG)
		tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'رسالة من المبرمج','البحث الجماعي انتهى بنجاح \n\n تم تخزين النتائج في كاش البرنامج لمدة ثلاثين يوم لكي تستطيع العودة إليها بدون عمل بحث جديد')
		CrMsjSZ7VW1DPxyvAgYUpRTJ = p3BFgEAIvN6kQd0a if ve2AaVRldtLnZNDFGXiTwm3g=='listed_sites'+dwZ5a7InmqCcH and p3BFgEAIvN6kQd0a else kkvdyNBxT5ZWlA0n9weu42zDY
	if ve2AaVRldtLnZNDFGXiTwm3g in ['listed_sites'+dwZ5a7InmqCcH,'opened_sites'+dwZ5a7InmqCcH,'closed_sites'+dwZ5a7InmqCcH]:
		for A60AIQZCYRzdhaeWfOtmrSUVoq2nN,c17XeRIH2gVh3px8sw,uuNDjbit4hOpx,ZZtDTHnBXMz,I6YPOSofrpnTwRm8b,NGQDwOCXx1BZmd9Huc,pnmsJqCWIHVk2Y6xPvl9Q0Ez8r,wc0Z9FAdf2B1J,XXra5dzn8tcLOxYZIE7pPof49Hh in CrMsjSZ7VW1DPxyvAgYUpRTJ:
			if ve2AaVRldtLnZNDFGXiTwm3g in ['listed_sites'+dwZ5a7InmqCcH,'opened_sites'+dwZ5a7InmqCcH] and 'صفحة' in c17XeRIH2gVh3px8sw and A60AIQZCYRzdhaeWfOtmrSUVoq2nN=='folder': continue
			MQtuaShrKTbdZFJ5nsR7D(A60AIQZCYRzdhaeWfOtmrSUVoq2nN,c17XeRIH2gVh3px8sw,uuNDjbit4hOpx,ZZtDTHnBXMz,I6YPOSofrpnTwRm8b,NGQDwOCXx1BZmd9Huc,pnmsJqCWIHVk2Y6xPvl9Q0Ez8r,wc0Z9FAdf2B1J,XXra5dzn8tcLOxYZIE7pPof49Hh)
	PDanwWu4bFAhe3m(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv)
	return
def qDOI7Yo463TJF2LrHuXUj(search):
	uaOf3Ajwiv = aOAE24IDufWJlKUyrFsYz(bT46adeyIWDBiArPH3V5027)
	for TFAmLfwypkzsP1UYCMr8c in uaOf3Ajwiv:
		if '-' in TFAmLfwypkzsP1UYCMr8c: continue
		if 'tuple' in str(type(TFAmLfwypkzsP1UYCMr8c)):
			GyjmfosC59Jub.append(TFAmLfwypkzsP1UYCMr8c)
			continue
		drHgqFcWbNv82tVEhDMT5,Bgb2Tkp6fK0CGvWYUZFtAzr,bhNwipmnY26A83qIEyDt0jQTso = MMUq0NsIxei5bK(TFAmLfwypkzsP1UYCMr8c)
		name = OJ5kiNTSpIdCco0H(TFAmLfwypkzsP1UYCMr8c)+' - '+search
		MQtuaShrKTbdZFJ5nsR7D('folder',bhNwipmnY26A83qIEyDt0jQTso+name,TFAmLfwypkzsP1UYCMr8c,548,'','',search)
	return
def C4rys9lhF7dxiUL(TFAmLfwypkzsP1UYCMr8c,search):
	drHgqFcWbNv82tVEhDMT5,Bgb2Tkp6fK0CGvWYUZFtAzr,bhNwipmnY26A83qIEyDt0jQTso = MMUq0NsIxei5bK(TFAmLfwypkzsP1UYCMr8c)
	Bgb2Tkp6fK0CGvWYUZFtAzr(search)
	return
def Aip73u5PFbyZdgSXOtYG():
	tuJ9fQgDl8oineCrFPT('','','رسالة من المبرمج','هذا البحث يستخدم محركات البحث الصغيرة الموجودة في كل موقع من مواقع البرنامج .. ونتائج هذا البحث تعتمد على دقة وفعالية وبرمجة كل موقع منها\n\nللأسف هذه المحركات الصغيرة لا تفهم جميع تفاصيل الفيديوهات ولا تفهم طريقة تفكير البشر ولا تستطيع إصلاح الأخطاء الإملائية .. ولهذا هي تحتاج دقة كبيرة جدا في اختيار وكتابة كلمات البحث المناسبة الصحيحة الدقيقة حتى تجد لك طلبك')
	return
def z5CmafZOhUq3IDgywnvk(n7nJFXtWAE4K92vY=b8Qe150xVaJsnDSv):
	oGjfrQp5bLaN6dYFhkTx9sWJ,SHk0ThDndgJW,showDialogs = JimhUH0SEf6w(n7nJFXtWAE4K92vY)
	if not oGjfrQp5bLaN6dYFhkTx9sWJ:
		oGjfrQp5bLaN6dYFhkTx9sWJ = FT2oXWtPQpVGuexmLqKN3srdzYn()
		if not oGjfrQp5bLaN6dYFhkTx9sWJ: return
		oGjfrQp5bLaN6dYFhkTx9sWJ = oGjfrQp5bLaN6dYFhkTx9sWJ.lower()
	mwIxD3GBPgLVc2aq9(MtTygrzXFlQ,EECz06teoykrNFfq(QQ8pvXNcBfVkP5rRJ7o)+'   Search For: [ '+oGjfrQp5bLaN6dYFhkTx9sWJ+' ]')
	LgXO1RhbDV7cx6EaeYCNm4zjJdBS = oGjfrQp5bLaN6dYFhkTx9sWJ+SHk0ThDndgJW
	if 0: LVnpNsW0Y7P4U6kcleqED8XwA3bvQ5,RRk9Ki5nPSfAZqC = oGjfrQp5bLaN6dYFhkTx9sWJ+' - ',b8Qe150xVaJsnDSv
	else: LVnpNsW0Y7P4U6kcleqED8XwA3bvQ5,RRk9Ki5nPSfAZqC = b8Qe150xVaJsnDSv,' - '+oGjfrQp5bLaN6dYFhkTx9sWJ
	MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+'مواقع سيرفرات خاصة - قليلة المشاكل'+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,157)
	MQtuaShrKTbdZFJ5nsR7D('folder','_M3U_'+LVnpNsW0Y7P4U6kcleqED8XwA3bvQ5+'بحث M3U'+RRk9Ki5nPSfAZqC,b8Qe150xVaJsnDSv,719,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,LgXO1RhbDV7cx6EaeYCNm4zjJdBS)
	MQtuaShrKTbdZFJ5nsR7D('folder','_IPT_'+LVnpNsW0Y7P4U6kcleqED8XwA3bvQ5+'بحث IPTV'+RRk9Ki5nPSfAZqC,b8Qe150xVaJsnDSv,239,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,LgXO1RhbDV7cx6EaeYCNm4zjJdBS)
	MQtuaShrKTbdZFJ5nsR7D('folder','_BKR_'+LVnpNsW0Y7P4U6kcleqED8XwA3bvQ5+'بحث موقع بكرا'+RRk9Ki5nPSfAZqC,b8Qe150xVaJsnDSv,379,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,LgXO1RhbDV7cx6EaeYCNm4zjJdBS)
	MQtuaShrKTbdZFJ5nsR7D('folder','_ART_'+LVnpNsW0Y7P4U6kcleqED8XwA3bvQ5+'بحث موقع تونز عربية'+RRk9Ki5nPSfAZqC,b8Qe150xVaJsnDSv,739,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,LgXO1RhbDV7cx6EaeYCNm4zjJdBS)
	MQtuaShrKTbdZFJ5nsR7D('folder','_KRB_'+LVnpNsW0Y7P4U6kcleqED8XwA3bvQ5+'بحث موقع قناة كربلاء'+RRk9Ki5nPSfAZqC,b8Qe150xVaJsnDSv,329,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,LgXO1RhbDV7cx6EaeYCNm4zjJdBS)
	MQtuaShrKTbdZFJ5nsR7D('folder','_FH2_'+LVnpNsW0Y7P4U6kcleqED8XwA3bvQ5+'بحث موقع فاصل الثاني'+RRk9Ki5nPSfAZqC,b8Qe150xVaJsnDSv,599,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,LgXO1RhbDV7cx6EaeYCNm4zjJdBS)
	MQtuaShrKTbdZFJ5nsR7D('folder','_KTV_'+LVnpNsW0Y7P4U6kcleqED8XwA3bvQ5+'بحث موقع كتكوت تيفي'+RRk9Ki5nPSfAZqC,b8Qe150xVaJsnDSv,819,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,LgXO1RhbDV7cx6EaeYCNm4zjJdBS)
	MQtuaShrKTbdZFJ5nsR7D('folder','_EB1_'+LVnpNsW0Y7P4U6kcleqED8XwA3bvQ5+'بحث موقع ايجي بيست 1'+RRk9Ki5nPSfAZqC,b8Qe150xVaJsnDSv,779,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,LgXO1RhbDV7cx6EaeYCNm4zjJdBS)
	MQtuaShrKTbdZFJ5nsR7D('folder','_EB2_'+LVnpNsW0Y7P4U6kcleqED8XwA3bvQ5+'بحث موقع ايجي بيست 2'+RRk9Ki5nPSfAZqC,b8Qe150xVaJsnDSv,789,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,LgXO1RhbDV7cx6EaeYCNm4zjJdBS)
	MQtuaShrKTbdZFJ5nsR7D('folder','_IFL_'+LVnpNsW0Y7P4U6kcleqED8XwA3bvQ5+'  بحث موقع قناة آي فيلم'+RRk9Ki5nPSfAZqC+k5bCDErUSmv,b8Qe150xVaJsnDSv,29,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,LgXO1RhbDV7cx6EaeYCNm4zjJdBS)
	MQtuaShrKTbdZFJ5nsR7D('folder','_AKO_'+LVnpNsW0Y7P4U6kcleqED8XwA3bvQ5+'بحث موقع أكوام القديم'+RRk9Ki5nPSfAZqC,b8Qe150xVaJsnDSv,79,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,LgXO1RhbDV7cx6EaeYCNm4zjJdBS)
	MQtuaShrKTbdZFJ5nsR7D('folder','_AKW_'+LVnpNsW0Y7P4U6kcleqED8XwA3bvQ5+'بحث موقع أكوام الجديد'+RRk9Ki5nPSfAZqC,b8Qe150xVaJsnDSv,249,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,LgXO1RhbDV7cx6EaeYCNm4zjJdBS)
	MQtuaShrKTbdZFJ5nsR7D('folder','_MRF_'+LVnpNsW0Y7P4U6kcleqED8XwA3bvQ5+'بحث موقع قناة المعارف'+RRk9Ki5nPSfAZqC,b8Qe150xVaJsnDSv,49,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,LgXO1RhbDV7cx6EaeYCNm4zjJdBS)
	MQtuaShrKTbdZFJ5nsR7D('folder','_SHM_'+LVnpNsW0Y7P4U6kcleqED8XwA3bvQ5+'بحث موقع شوف ماكس'+RRk9Ki5nPSfAZqC,b8Qe150xVaJsnDSv,59,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,LgXO1RhbDV7cx6EaeYCNm4zjJdBS)
	MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+'مواقع سيرفرات خاصة وعامة - كثيرة المشاكل'+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,157)
	MQtuaShrKTbdZFJ5nsR7D('folder','_LRZ_'+LVnpNsW0Y7P4U6kcleqED8XwA3bvQ5+'بحث موقع لاروزا'+RRk9Ki5nPSfAZqC,b8Qe150xVaJsnDSv,709,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,LgXO1RhbDV7cx6EaeYCNm4zjJdBS)
	MQtuaShrKTbdZFJ5nsR7D('folder','_FJS_'+LVnpNsW0Y7P4U6kcleqED8XwA3bvQ5+' بحث موقع فجر شو'+RRk9Ki5nPSfAZqC+pldxivXC5wbTB2O8q,b8Qe150xVaJsnDSv,399,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,LgXO1RhbDV7cx6EaeYCNm4zjJdBS)
	MQtuaShrKTbdZFJ5nsR7D('folder','_TVF_'+LVnpNsW0Y7P4U6kcleqED8XwA3bvQ5+'بحث موقع تيفي فان'+RRk9Ki5nPSfAZqC,b8Qe150xVaJsnDSv,469,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,LgXO1RhbDV7cx6EaeYCNm4zjJdBS)
	MQtuaShrKTbdZFJ5nsR7D('folder','_LDN_'+LVnpNsW0Y7P4U6kcleqED8XwA3bvQ5+'بحث موقع لودي نت'+RRk9Ki5nPSfAZqC,b8Qe150xVaJsnDSv,459,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,LgXO1RhbDV7cx6EaeYCNm4zjJdBS)
	MQtuaShrKTbdZFJ5nsR7D('folder','_CMN_'+LVnpNsW0Y7P4U6kcleqED8XwA3bvQ5+'بحث موقع سيما ناو'+RRk9Ki5nPSfAZqC,b8Qe150xVaJsnDSv,309,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,LgXO1RhbDV7cx6EaeYCNm4zjJdBS)
	MQtuaShrKTbdZFJ5nsR7D('folder','_SHN_'+LVnpNsW0Y7P4U6kcleqED8XwA3bvQ5+'بحث موقع شاهد نيوز'+RRk9Ki5nPSfAZqC,b8Qe150xVaJsnDSv,589,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,LgXO1RhbDV7cx6EaeYCNm4zjJdBS+'_NODIALOGS_')
	MQtuaShrKTbdZFJ5nsR7D('folder','_ARS_'+LVnpNsW0Y7P4U6kcleqED8XwA3bvQ5+'بحث موقع عرب سييد'+RRk9Ki5nPSfAZqC,b8Qe150xVaJsnDSv,259,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,LgXO1RhbDV7cx6EaeYCNm4zjJdBS)
	MQtuaShrKTbdZFJ5nsR7D('folder','_CCB_'+LVnpNsW0Y7P4U6kcleqED8XwA3bvQ5+'بحث موقع سيما كلوب'+RRk9Ki5nPSfAZqC,b8Qe150xVaJsnDSv,829,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,LgXO1RhbDV7cx6EaeYCNm4zjJdBS)
	MQtuaShrKTbdZFJ5nsR7D('folder','_SH4_'+LVnpNsW0Y7P4U6kcleqED8XwA3bvQ5+'بحث موقع شاهد فوريو'+RRk9Ki5nPSfAZqC,b8Qe150xVaJsnDSv,119,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,LgXO1RhbDV7cx6EaeYCNm4zjJdBS+'_NODIALOGS_')
	MQtuaShrKTbdZFJ5nsR7D('folder','_SHT_'+LVnpNsW0Y7P4U6kcleqED8XwA3bvQ5+'بحث موقع شوفها تيفي'+RRk9Ki5nPSfAZqC,b8Qe150xVaJsnDSv,649,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,LgXO1RhbDV7cx6EaeYCNm4zjJdBS)
	MQtuaShrKTbdZFJ5nsR7D('folder','_WC1_'+LVnpNsW0Y7P4U6kcleqED8XwA3bvQ5+'بحث موقع وي سيما 1'+RRk9Ki5nPSfAZqC,b8Qe150xVaJsnDSv,569,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,LgXO1RhbDV7cx6EaeYCNm4zjJdBS)
	MQtuaShrKTbdZFJ5nsR7D('folder','_WC2_'+LVnpNsW0Y7P4U6kcleqED8XwA3bvQ5+'بحث موقع وي سيما 2'+RRk9Ki5nPSfAZqC,b8Qe150xVaJsnDSv,1009,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,LgXO1RhbDV7cx6EaeYCNm4zjJdBS)
	MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+'مواقع سيرفرات عامة - كثيرة المشاكل'+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,157)
	MQtuaShrKTbdZFJ5nsR7D('folder','_TKT_'+LVnpNsW0Y7P4U6kcleqED8XwA3bvQ5+'بحث موقع تكات'+RRk9Ki5nPSfAZqC,b8Qe150xVaJsnDSv,949,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,LgXO1RhbDV7cx6EaeYCNm4zjJdBS)
	MQtuaShrKTbdZFJ5nsR7D('folder','_FST_'+LVnpNsW0Y7P4U6kcleqED8XwA3bvQ5+'بحث موقع فوستا'+RRk9Ki5nPSfAZqC,b8Qe150xVaJsnDSv,609,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,LgXO1RhbDV7cx6EaeYCNm4zjJdBS)
	MQtuaShrKTbdZFJ5nsR7D('folder','_FBK_'+LVnpNsW0Y7P4U6kcleqED8XwA3bvQ5+'بحث موقع فبركة'+RRk9Ki5nPSfAZqC,b8Qe150xVaJsnDSv,629,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,LgXO1RhbDV7cx6EaeYCNm4zjJdBS)
	MQtuaShrKTbdZFJ5nsR7D('folder','_YQT_'+LVnpNsW0Y7P4U6kcleqED8XwA3bvQ5+'بحث موقع ياقوت'+RRk9Ki5nPSfAZqC,b8Qe150xVaJsnDSv,669,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,LgXO1RhbDV7cx6EaeYCNm4zjJdBS)
	MQtuaShrKTbdZFJ5nsR7D('folder','_SHB_'+LVnpNsW0Y7P4U6kcleqED8XwA3bvQ5+'بحث موقع شبكتي'+RRk9Ki5nPSfAZqC,b8Qe150xVaJsnDSv,969,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,LgXO1RhbDV7cx6EaeYCNm4zjJdBS)
	MQtuaShrKTbdZFJ5nsR7D('folder','_VRB_'+LVnpNsW0Y7P4U6kcleqED8XwA3bvQ5+'بحث موقع فاربون'+RRk9Ki5nPSfAZqC,b8Qe150xVaJsnDSv,879,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,LgXO1RhbDV7cx6EaeYCNm4zjJdBS)
	MQtuaShrKTbdZFJ5nsR7D('folder','_BRS_'+LVnpNsW0Y7P4U6kcleqED8XwA3bvQ5+'بحث موقع برستيج'+RRk9Ki5nPSfAZqC,b8Qe150xVaJsnDSv,659,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,LgXO1RhbDV7cx6EaeYCNm4zjJdBS)
	MQtuaShrKTbdZFJ5nsR7D('folder','_KRM_'+LVnpNsW0Y7P4U6kcleqED8XwA3bvQ5+'بحث موقع كرمالك'+RRk9Ki5nPSfAZqC,b8Qe150xVaJsnDSv,929,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,LgXO1RhbDV7cx6EaeYCNm4zjJdBS)
	MQtuaShrKTbdZFJ5nsR7D('folder','_ANZ_'+LVnpNsW0Y7P4U6kcleqED8XwA3bvQ5+'بحث موقع انمي زد'+RRk9Ki5nPSfAZqC,b8Qe150xVaJsnDSv,979,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,LgXO1RhbDV7cx6EaeYCNm4zjJdBS)
	MQtuaShrKTbdZFJ5nsR7D('folder','_FSK_'+LVnpNsW0Y7P4U6kcleqED8XwA3bvQ5+'بحث موقع فاريسكو'+RRk9Ki5nPSfAZqC,b8Qe150xVaJsnDSv,999,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,LgXO1RhbDV7cx6EaeYCNm4zjJdBS)
	MQtuaShrKTbdZFJ5nsR7D('folder','_HLC_'+LVnpNsW0Y7P4U6kcleqED8XwA3bvQ5+'بحث موقع هلا سيما'+RRk9Ki5nPSfAZqC,b8Qe150xVaJsnDSv,89,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,LgXO1RhbDV7cx6EaeYCNm4zjJdBS)
	MQtuaShrKTbdZFJ5nsR7D('folder','_MST_'+LVnpNsW0Y7P4U6kcleqED8XwA3bvQ5+'بحث موقع المصطبة'+RRk9Ki5nPSfAZqC,b8Qe150xVaJsnDSv,869,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,LgXO1RhbDV7cx6EaeYCNm4zjJdBS)
	MQtuaShrKTbdZFJ5nsR7D('folder','_SNT_'+LVnpNsW0Y7P4U6kcleqED8XwA3bvQ5+'بحث موقع شوف نت'+RRk9Ki5nPSfAZqC,b8Qe150xVaJsnDSv,849,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,LgXO1RhbDV7cx6EaeYCNm4zjJdBS)
	MQtuaShrKTbdZFJ5nsR7D('folder','_DR7_'+LVnpNsW0Y7P4U6kcleqED8XwA3bvQ5+'بحث موقع دراما صح'+RRk9Ki5nPSfAZqC,b8Qe150xVaJsnDSv,689,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,LgXO1RhbDV7cx6EaeYCNm4zjJdBS)
	MQtuaShrKTbdZFJ5nsR7D('folder','_CFR_'+LVnpNsW0Y7P4U6kcleqED8XwA3bvQ5+'بحث موقع سيما فري'+RRk9Ki5nPSfAZqC,b8Qe150xVaJsnDSv,839,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,LgXO1RhbDV7cx6EaeYCNm4zjJdBS)
	MQtuaShrKTbdZFJ5nsR7D('folder','_CMF_'+LVnpNsW0Y7P4U6kcleqED8XwA3bvQ5+'بحث موقع سيما فانز'+RRk9Ki5nPSfAZqC,b8Qe150xVaJsnDSv,99,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,LgXO1RhbDV7cx6EaeYCNm4zjJdBS)
	MQtuaShrKTbdZFJ5nsR7D('folder','_CML_'+LVnpNsW0Y7P4U6kcleqED8XwA3bvQ5+'بحث موقع سيما لايت'+RRk9Ki5nPSfAZqC,b8Qe150xVaJsnDSv,479,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,LgXO1RhbDV7cx6EaeYCNm4zjJdBS)
	MQtuaShrKTbdZFJ5nsR7D('folder','_C4H_'+LVnpNsW0Y7P4U6kcleqED8XwA3bvQ5+'بحث موقع سيما 400'+RRk9Ki5nPSfAZqC,b8Qe150xVaJsnDSv,699,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,LgXO1RhbDV7cx6EaeYCNm4zjJdBS)
	MQtuaShrKTbdZFJ5nsR7D('folder','_ABD_'+LVnpNsW0Y7P4U6kcleqED8XwA3bvQ5+'بحث موقع سيما عبدو'+RRk9Ki5nPSfAZqC,b8Qe150xVaJsnDSv,559,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,LgXO1RhbDV7cx6EaeYCNm4zjJdBS)
	MQtuaShrKTbdZFJ5nsR7D('folder','_AKT_'+LVnpNsW0Y7P4U6kcleqED8XwA3bvQ5+'بحث موقع اكوام تيوب'+RRk9Ki5nPSfAZqC,b8Qe150xVaJsnDSv,859,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,LgXO1RhbDV7cx6EaeYCNm4zjJdBS)
	MQtuaShrKTbdZFJ5nsR7D('folder','_DCF_'+LVnpNsW0Y7P4U6kcleqED8XwA3bvQ5+'بحث موقع دراما كافيه'+RRk9Ki5nPSfAZqC,b8Qe150xVaJsnDSv,939,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,LgXO1RhbDV7cx6EaeYCNm4zjJdBS)
	MQtuaShrKTbdZFJ5nsR7D('folder','_FTV_'+LVnpNsW0Y7P4U6kcleqED8XwA3bvQ5+'بحث موقع فوشار تيفي'+RRk9Ki5nPSfAZqC,b8Qe150xVaJsnDSv,919,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,LgXO1RhbDV7cx6EaeYCNm4zjJdBS)
	MQtuaShrKTbdZFJ5nsR7D('folder','_CWB_'+LVnpNsW0Y7P4U6kcleqED8XwA3bvQ5+'بحث موقع سيما وبس'+RRk9Ki5nPSfAZqC,b8Qe150xVaJsnDSv,989,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,LgXO1RhbDV7cx6EaeYCNm4zjJdBS)
	MQtuaShrKTbdZFJ5nsR7D('folder','_AHK_'+LVnpNsW0Y7P4U6kcleqED8XwA3bvQ5+'بحث موقع أهواك تيفي'+RRk9Ki5nPSfAZqC,b8Qe150xVaJsnDSv,619,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,LgXO1RhbDV7cx6EaeYCNm4zjJdBS)
	MQtuaShrKTbdZFJ5nsR7D('folder','_SRT_'+LVnpNsW0Y7P4U6kcleqED8XwA3bvQ5+'بحث موقع سيريس تايم'+RRk9Ki5nPSfAZqC,b8Qe150xVaJsnDSv,899,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,LgXO1RhbDV7cx6EaeYCNm4zjJdBS)
	MQtuaShrKTbdZFJ5nsR7D('folder','_FVD_'+LVnpNsW0Y7P4U6kcleqED8XwA3bvQ5+'بحث موقع فوشار فيديو'+RRk9Ki5nPSfAZqC,b8Qe150xVaJsnDSv,909,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,LgXO1RhbDV7cx6EaeYCNm4zjJdBS)
	MQtuaShrKTbdZFJ5nsR7D('folder','_C4P_'+LVnpNsW0Y7P4U6kcleqED8XwA3bvQ5+'بحث موقع سيما فور بي'+RRk9Ki5nPSfAZqC,b8Qe150xVaJsnDSv,889,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,LgXO1RhbDV7cx6EaeYCNm4zjJdBS)
	MQtuaShrKTbdZFJ5nsR7D('folder','_EB4_'+LVnpNsW0Y7P4U6kcleqED8XwA3bvQ5+'بحث موقع ايجي بيست 4'+RRk9Ki5nPSfAZqC,b8Qe150xVaJsnDSv,809,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,LgXO1RhbDV7cx6EaeYCNm4zjJdBS)
	MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+'مواقع سيرفرات خاصة - قليلة المشاكل'+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,157)
	MQtuaShrKTbdZFJ5nsR7D('folder','_YUT_'+LVnpNsW0Y7P4U6kcleqED8XwA3bvQ5+'بحث موقع يوتيوب'+RRk9Ki5nPSfAZqC,b8Qe150xVaJsnDSv,149,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,LgXO1RhbDV7cx6EaeYCNm4zjJdBS)
	MQtuaShrKTbdZFJ5nsR7D('folder','_DLM_'+LVnpNsW0Y7P4U6kcleqED8XwA3bvQ5+'بحث موقع دايلي موشن'+RRk9Ki5nPSfAZqC,b8Qe150xVaJsnDSv,409,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,LgXO1RhbDV7cx6EaeYCNm4zjJdBS)
	return
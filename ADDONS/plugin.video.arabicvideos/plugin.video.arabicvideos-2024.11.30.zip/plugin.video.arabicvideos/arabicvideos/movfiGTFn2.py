# -*- coding: utf-8 -*-
from hIVCFnfxSO import *
QQ8pvXNcBfVkP5rRJ7o = 'CIMAABDO'
WbzmKSZiuOYrBN7oysJ2dUv = '_ABD_'
wQjs1XZ3AO24g8y9bEeoKMiGIu7 = nTHXJIiah2qK[QQ8pvXNcBfVkP5rRJ7o][0]
v1vJEhoNQBVPkjG = ['الرئيسية']
def x8IFqMZeJj7suCR4AaGoNXfEHm(mode,url,text):
	if   mode==550: XXxlOLJ9KRjPH382WVCvr6n71 = Y72YmLgw4vqlHxTCkbeKSicasD()
	elif mode==551: XXxlOLJ9KRjPH382WVCvr6n71 = Je4TwC30iOG5DLKWAtbYvhs(url,text)
	elif mode==552: XXxlOLJ9KRjPH382WVCvr6n71 = Hkij627uCDJKyIM(url)
	elif mode==553: XXxlOLJ9KRjPH382WVCvr6n71 = bIpskeGhBlqH(url)
	elif mode==559: XXxlOLJ9KRjPH382WVCvr6n71 = kstJfK6jHQWrXDSMRIGB7(text)
	else: XXxlOLJ9KRjPH382WVCvr6n71 = False
	return XXxlOLJ9KRjPH382WVCvr6n71
def Y72YmLgw4vqlHxTCkbeKSicasD():
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/home',b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'CIMAABDO-MENU-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	OZSA7QNfeE = Wl2eu1PavfQ(wQjs1XZ3AO24g8y9bEeoKMiGIu7,'url')
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'بحث في الموقع',b8Qe150xVaJsnDSv,559,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'_REMEMBERRESULTS_')
	MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+' ===== ===== ===== '+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999)
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'اخترنا لك',OZSA7QNfeE+'/home',551,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'featured')
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('main-content(.*?)</ul>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
	items = YYBlm36zd0Jst18LXwo4.findall('data-name="(.*?)".*?</i>(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	for vI9QYJckeTmfRFV,title in items:
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = OZSA7QNfeE+'/ajax/getItem?item='+vI9QYJckeTmfRFV+'&Ajax=1'
		MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,551)
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('"nav-main"(.*?)</nav>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
	items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)">(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
		if pcA1dzy7LXwGfMPg9mTkuh5tine3=='#': continue
		if title in v1vJEhoNQBVPkjG: continue
		if 'مسلسل ' in title: continue
		if 'أحدث' in title: MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,551)
	MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+' ===== ===== ===== '+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999)
	for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
		if pcA1dzy7LXwGfMPg9mTkuh5tine3=='#': continue
		if title in v1vJEhoNQBVPkjG: continue
		if 'مسلسل ' in title: continue
		if 'أحدث' not in title: MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,551)
	return
def Je4TwC30iOG5DLKWAtbYvhs(url,vI9QYJckeTmfRFV=b8Qe150xVaJsnDSv):
	items = []
	if '/ajax/getItem' in url or '/ajax/loadMore' in url:
		MUJCtfYVBLODrFbaZn,EEkjQFxOabod08Nr = FNIhDd4uLfev0q5YHVGx8oWm6CsiJ(url)
		ybF0H85nUohsiRQcpaTfZAKzjMY7wB = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'POST',MUJCtfYVBLODrFbaZn,EEkjQFxOabod08Nr,ybF0H85nUohsiRQcpaTfZAKzjMY7wB,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'CIMAABDO-TITLES-1st')
		jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
		ZV5rRvabhxJ = [jLtdbeYiQHnf4SpU2MTly]
	else:
		b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'CIMAABDO-TITLES-2nd')
		jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
		if vI9QYJckeTmfRFV=='featured':
			ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('"container"(.*?)"container"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
			OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
			items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		elif '"section-post mb-10"' in jLtdbeYiQHnf4SpU2MTly:
			ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('"section-post mb-10"(.*?)"container"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		else:
			ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('<article(.*?)"pagination"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if not ZV5rRvabhxJ: return
	OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
	if not items:
		items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)" title="(.*?)".*?data-original="(.*?)"',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		if not items: items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	d3VSIefbHnvqiut = []
	PBFVNlrcUMOSzC04 = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for pcA1dzy7LXwGfMPg9mTkuh5tine3,title,lvtGpMZHb9 in items:
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = SgrGWuAHcLKBQMJetb9(pcA1dzy7LXwGfMPg9mTkuh5tine3).strip('/')
		HHr42WSgBjAeU7TkQcVaL6yEJz8PF = YYBlm36zd0Jst18LXwo4.findall('(.*?) الحلقة \d+',title,YYBlm36zd0Jst18LXwo4.DOTALL)
		if 'سلاسل' not in url and any(Y8aiFZsLKw in title for Y8aiFZsLKw in PBFVNlrcUMOSzC04):
			MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,552,lvtGpMZHb9)
		elif HHr42WSgBjAeU7TkQcVaL6yEJz8PF and 'الحلقة' in title:
			title = '_MOD_' + HHr42WSgBjAeU7TkQcVaL6yEJz8PF[0]
			if title not in d3VSIefbHnvqiut:
				MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,553,lvtGpMZHb9)
				d3VSIefbHnvqiut.append(title)
		elif '/movies/' in pcA1dzy7LXwGfMPg9mTkuh5tine3:
			MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,551,lvtGpMZHb9)
		else: MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,553,lvtGpMZHb9)
	if vI9QYJckeTmfRFV==b8Qe150xVaJsnDSv:
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('"pagination"(.*?)<footer',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if ZV5rRvabhxJ:
			OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
			items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)".*?>(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
			for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
				if pcA1dzy7LXwGfMPg9mTkuh5tine3=="": continue
				if title!=b8Qe150xVaJsnDSv: MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'صفحة '+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,551)
	if '/ajax/getItem' in url or '/ajax/loadMore' in url:
		if '/ajax/getItem' in url:
			url = url.replace('/ajax/getItem','/ajax/loadMore')+'&offset=20'
		elif '/ajax/loadMore' in url:
			url,offset = url.split('&offset=')
			offset = int(offset)+20
			url = url+'&offset='+str(offset)
		MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'هناك المزيد',url,551)
	return
def bIpskeGhBlqH(url):
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'CIMAABDO-EPISODES-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	Pmt5K6LAEZBcb = YYBlm36zd0Jst18LXwo4.findall('"getSeasonsBySeries(.*?)"container"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	U8UnzJgXuMIE5GV = YYBlm36zd0Jst18LXwo4.findall('"list-episodes"(.*?)"container"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if Pmt5K6LAEZBcb and '/series/' not in url:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = Pmt5K6LAEZBcb[0]
		items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,title,lvtGpMZHb9 in items:
			MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,553,lvtGpMZHb9)
	elif U8UnzJgXuMIE5GV:
		lvtGpMZHb9 = YYBlm36zd0Jst18LXwo4.findall('"image" src="(.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		lvtGpMZHb9 = lvtGpMZHb9[0]
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = U8UnzJgXuMIE5GV[0]
		items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)" title="(.*?)"',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
			MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,552,lvtGpMZHb9)
	return
def Hkij627uCDJKyIM(url):
	GSh0nJxEXgZjd48u7mBwWOeafyAp5b = url.replace('/movies/','/watch_movies/')
	GSh0nJxEXgZjd48u7mBwWOeafyAp5b = GSh0nJxEXgZjd48u7mBwWOeafyAp5b.replace('/episodes/','/watch_episodes/')
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',GSh0nJxEXgZjd48u7mBwWOeafyAp5b,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'CIMAABDO-PLAY-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	OZSA7QNfeE = Wl2eu1PavfQ(GSh0nJxEXgZjd48u7mBwWOeafyAp5b,'url')
	n92bB0YwDLqyadQRlmGW = []
	pcA1dzy7LXwGfMPg9mTkuh5tine3 = YYBlm36zd0Jst18LXwo4.findall('''<iframe.*?src=["'](.*?)["']''',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if pcA1dzy7LXwGfMPg9mTkuh5tine3:
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3[0]
		LLOCdZ3sS2enzXx4fVB18YRvbHNwky = Wl2eu1PavfQ(pcA1dzy7LXwGfMPg9mTkuh5tine3,'url')
		n92bB0YwDLqyadQRlmGW.append(pcA1dzy7LXwGfMPg9mTkuh5tine3+'?named='+LLOCdZ3sS2enzXx4fVB18YRvbHNwky+'__embed')
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('"servers"(.*?)</ul>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		DlhJPky307SxBNGUL = YYBlm36zd0Jst18LXwo4.findall('postID = "(.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		DlhJPky307SxBNGUL = DlhJPky307SxBNGUL[0]
		items = YYBlm36zd0Jst18LXwo4.findall("getPlayer\('(.*?)'.*?</i>(.*?)</a>",OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		if items:
			for LLOCdZ3sS2enzXx4fVB18YRvbHNwky,title in items:
				title = title.replace(eeN6dTEnkJxI,b8Qe150xVaJsnDSv).strip(pldxivXC5wbTB2O8q)
				pcA1dzy7LXwGfMPg9mTkuh5tine3 = OZSA7QNfeE+'/ajax/getPlayer?server='+LLOCdZ3sS2enzXx4fVB18YRvbHNwky+'&postID='+DlhJPky307SxBNGUL+'&Ajax=1'
				pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3+'?named='+title+'__watch'
				n92bB0YwDLqyadQRlmGW.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
		else:
			items = YYBlm36zd0Jst18LXwo4.findall("getPlayerByName\('(.*?)','(.*?)'.*?\"server\">(.*?)</a>",OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
			if items:
				LLOCdZ3sS2enzXx4fVB18YRvbHNwky,QxXzW3wbZdmjMTftq4OBUVHgGp9,title = items[0]
				pcA1dzy7LXwGfMPg9mTkuh5tine3 = OZSA7QNfeE+'/ajax/getPlayerByName?server='+LLOCdZ3sS2enzXx4fVB18YRvbHNwky+'&multipleServers='+QxXzW3wbZdmjMTftq4OBUVHgGp9+'&postID='+DlhJPky307SxBNGUL+'&Ajax=1'
				MUJCtfYVBLODrFbaZn,EEkjQFxOabod08Nr = FNIhDd4uLfev0q5YHVGx8oWm6CsiJ(pcA1dzy7LXwGfMPg9mTkuh5tine3)
				ybF0H85nUohsiRQcpaTfZAKzjMY7wB = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
				b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'POST',MUJCtfYVBLODrFbaZn,EEkjQFxOabod08Nr,ybF0H85nUohsiRQcpaTfZAKzjMY7wB,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'CIMAABDO-PLAY-2nd')
				jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
				p5FQgfzqT2tI = YYBlm36zd0Jst18LXwo4.findall('''<iframe src=["'](.*?)["']''',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL|YYBlm36zd0Jst18LXwo4.IGNORECASE)
				eiFs3pQPyZtjb0W = p5FQgfzqT2tI[0] if p5FQgfzqT2tI else b8Qe150xVaJsnDSv
				if '/iframe/' in eiFs3pQPyZtjb0W:
					b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',eiFs3pQPyZtjb0W,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'CIMAABDO-PLAY-3rd')
					jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
					OPzdnZpc8oKM57hR9AU01FDb = YYBlm36zd0Jst18LXwo4.findall('version&quot;:&quot;(.*?)&',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
					OPzdnZpc8oKM57hR9AU01FDb = OPzdnZpc8oKM57hR9AU01FDb[0]
					ybF0H85nUohsiRQcpaTfZAKzjMY7wB = {}
					ybF0H85nUohsiRQcpaTfZAKzjMY7wB['X-Inertia-Partial-Component'] = 'files/mirror/video'
					ybF0H85nUohsiRQcpaTfZAKzjMY7wB['X-Inertia'] = 'true'
					ybF0H85nUohsiRQcpaTfZAKzjMY7wB['X-Inertia-Partial-Data'] = 'streams'
					ybF0H85nUohsiRQcpaTfZAKzjMY7wB['X-Inertia-Version'] = OPzdnZpc8oKM57hR9AU01FDb
					b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',eiFs3pQPyZtjb0W,b8Qe150xVaJsnDSv,ybF0H85nUohsiRQcpaTfZAKzjMY7wB,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'CIMAABDO-PLAY-4th')
					jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
					vvJHxfOAoskaUXjL5Wrw1gyMZ982 = oJsUwXA0yGOI1mTjxQ('dict',jLtdbeYiQHnf4SpU2MTly)
					groups = vvJHxfOAoskaUXjL5Wrw1gyMZ982['props']['streams']['data']
					for group in groups:
						c1EdszLx3mkb8QYX9 = group['label'].replace(' (source)',b8Qe150xVaJsnDSv)
						Psd4E0eUlT9hNO = group['mirrors']
						for UW4gq2Taf0mcwJzOQ in Psd4E0eUlT9hNO:
							LLOCdZ3sS2enzXx4fVB18YRvbHNwky = UW4gq2Taf0mcwJzOQ['driver']
							pcA1dzy7LXwGfMPg9mTkuh5tine3 = 'http:'+UW4gq2Taf0mcwJzOQ['link']+'?named='+LLOCdZ3sS2enzXx4fVB18YRvbHNwky+'__watch____'+c1EdszLx3mkb8QYX9
							n92bB0YwDLqyadQRlmGW.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('"downs"(.*?)</ul>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)" title="(.*?)"',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,name in items:
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3+'?named='+name+'__download'
			if 'http' not in pcA1dzy7LXwGfMPg9mTkuh5tine3: pcA1dzy7LXwGfMPg9mTkuh5tine3 = 'http:'+pcA1dzy7LXwGfMPg9mTkuh5tine3
			n92bB0YwDLqyadQRlmGW.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
	import QNeGEq8sWn
	QNeGEq8sWn.nqu2GCT9gHAbpIPSFZz5(n92bB0YwDLqyadQRlmGW,QQ8pvXNcBfVkP5rRJ7o,'video',url)
	return
def kstJfK6jHQWrXDSMRIGB7(search):
	search,v7Rxw52Z4X0,showDialogs = JimhUH0SEf6w(search)
	if search==b8Qe150xVaJsnDSv: search = FT2oXWtPQpVGuexmLqKN3srdzYn()
	if search==b8Qe150xVaJsnDSv: return
	search = search.replace(pldxivXC5wbTB2O8q,'-')
	url = wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/search/'+search+'.html'
	Je4TwC30iOG5DLKWAtbYvhs(url)
	return
# -*- coding: utf-8 -*-
from hIVCFnfxSO import *
QQ8pvXNcBfVkP5rRJ7o = 'ARABSEED'
headers = {'User-Agent':kIMmsSG9NW6BOjlTpnEcuRzgwK()}
WbzmKSZiuOYrBN7oysJ2dUv = '_ARS_'
wQjs1XZ3AO24g8y9bEeoKMiGIu7 = nTHXJIiah2qK[QQ8pvXNcBfVkP5rRJ7o][0]
v1vJEhoNQBVPkjG = ['الرئيسية','المضاف حديثاً','مصارعه','اعلن معنا – For ads','موبايلات','برامج كمبيوتر','العاب كمبيوتر','اسلاميات','اخرى','اقسام اخري','اشتراكات']
def x8IFqMZeJj7suCR4AaGoNXfEHm(mode,url,text):
	if   mode==250: XXxlOLJ9KRjPH382WVCvr6n71 = Y72YmLgw4vqlHxTCkbeKSicasD()
	elif mode==251: XXxlOLJ9KRjPH382WVCvr6n71 = Je4TwC30iOG5DLKWAtbYvhs(url,text)
	elif mode==252: XXxlOLJ9KRjPH382WVCvr6n71 = Hkij627uCDJKyIM(url)
	elif mode==253: XXxlOLJ9KRjPH382WVCvr6n71 = bIpskeGhBlqH(url)
	elif mode==254: XXxlOLJ9KRjPH382WVCvr6n71 = eszTQbMvkmRwCAxGDPdYJUi(url,'CATEGORIES___'+text)
	elif mode==255: XXxlOLJ9KRjPH382WVCvr6n71 = eszTQbMvkmRwCAxGDPdYJUi(url,'FILTERS___'+text)
	elif mode==256: XXxlOLJ9KRjPH382WVCvr6n71 = Q6mUHMbNlirVXPRgKWJAt8ap5hSE(url,text)
	elif mode==259: XXxlOLJ9KRjPH382WVCvr6n71 = kstJfK6jHQWrXDSMRIGB7(text)
	else: XXxlOLJ9KRjPH382WVCvr6n71 = False
	return XXxlOLJ9KRjPH382WVCvr6n71
def Y72YmLgw4vqlHxTCkbeKSicasD():
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(Q49IsrlSuYRAVbGKhwdckLDOetF2PZ,'GET',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/main',b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'ARABSEED-MENU-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'بحث في الموقع',b8Qe150xVaJsnDSv,259,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'_REMEMBERRESULTS_')
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'فلتر محدد',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/category/اخرى',254)
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'فلتر كامل',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/category/اخرى',255)
	MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+' ===== ===== ===== '+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999)
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'المميزة',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/main',251,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'featured_main')
	MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+'جديد الأفلام',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/main',251,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'new_movies')
	MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+'جديد الحلقات',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/main',251,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'new_episodes')
	MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+'المضاف حديثاً',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/latest',251,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'lastest')
	MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+' ===== ===== ===== '+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999)
	U8UnzJgXuMIE5GV = YYBlm36zd0Jst18LXwo4.findall('class="MenuHeader"(.*?)</div>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	CmEkolxes7Q6hB01fGTPZi4 = U8UnzJgXuMIE5GV[0]
	xxnATEUzH6Djmq0NrBveh = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)".*?>(.*?)<',CmEkolxes7Q6hB01fGTPZi4,YYBlm36zd0Jst18LXwo4.DOTALL)
	for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in xxnATEUzH6Djmq0NrBveh:
		title = pTP49ckGDYrofa2KxenumbH0(title)
		if title not in v1vJEhoNQBVPkjG and title!=b8Qe150xVaJsnDSv:
			if 'http' not in pcA1dzy7LXwGfMPg9mTkuh5tine3: pcA1dzy7LXwGfMPg9mTkuh5tine3 = wQjs1XZ3AO24g8y9bEeoKMiGIu7+pcA1dzy7LXwGfMPg9mTkuh5tine3
			MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,256)
	return jLtdbeYiQHnf4SpU2MTly
def Q6mUHMbNlirVXPRgKWJAt8ap5hSE(url,type):
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',url,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'ARABSEED-SUBMENU-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	if 'class="SliderInSection' in jLtdbeYiQHnf4SpU2MTly: MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'الأكثر مشاهدة',url,251,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'most')
	if 'class="MainSlides' in jLtdbeYiQHnf4SpU2MTly: MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'المميزة',url,251,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'featured')
	if 'class="LinksList' in jLtdbeYiQHnf4SpU2MTly:
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('class="LinksList(.*?)</ul>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if ZV5rRvabhxJ:
			OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
			if len(ZV5rRvabhxJ)>1 and type=='new_episodes': OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[1]
			items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)"(.*?)</a>',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
			for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
				HoXz65T8ph1CMeZgF = YYBlm36zd0Jst18LXwo4.findall('</i>(.*?)<span>(.*?)<',title,YYBlm36zd0Jst18LXwo4.DOTALL)
				try: xhWaiNzZPjTfLQV9b7H382ovXrEKBe = HoXz65T8ph1CMeZgF[0][0].replace(eeN6dTEnkJxI,b8Qe150xVaJsnDSv).strip(pldxivXC5wbTB2O8q)
				except: xhWaiNzZPjTfLQV9b7H382ovXrEKBe = b8Qe150xVaJsnDSv
				try: zRDNtpElrcUmhTkC = HoXz65T8ph1CMeZgF[0][1].replace(eeN6dTEnkJxI,b8Qe150xVaJsnDSv).strip(pldxivXC5wbTB2O8q)
				except: zRDNtpElrcUmhTkC = b8Qe150xVaJsnDSv
				HoXz65T8ph1CMeZgF = xhWaiNzZPjTfLQV9b7H382ovXrEKBe+pldxivXC5wbTB2O8q+zRDNtpElrcUmhTkC
				if '<strong>' in title:
					lEODY4eWsj30yMupk6mT8IwXPotR = YYBlm36zd0Jst18LXwo4.findall('</i>(.*?)<',title,YYBlm36zd0Jst18LXwo4.DOTALL)
					if lEODY4eWsj30yMupk6mT8IwXPotR: HoXz65T8ph1CMeZgF = lEODY4eWsj30yMupk6mT8IwXPotR[0]
				if not HoXz65T8ph1CMeZgF:
					lEODY4eWsj30yMupk6mT8IwXPotR = YYBlm36zd0Jst18LXwo4.findall('alt="(.*?)"',title,YYBlm36zd0Jst18LXwo4.DOTALL)
					if lEODY4eWsj30yMupk6mT8IwXPotR: HoXz65T8ph1CMeZgF = lEODY4eWsj30yMupk6mT8IwXPotR[0]
				if HoXz65T8ph1CMeZgF:
					if 'key=' in pcA1dzy7LXwGfMPg9mTkuh5tine3: type = pcA1dzy7LXwGfMPg9mTkuh5tine3.split('key=')[1]
					else: type = 'newest'
					HoXz65T8ph1CMeZgF = HoXz65T8ph1CMeZgF.strip(pldxivXC5wbTB2O8q)
					MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+HoXz65T8ph1CMeZgF,pcA1dzy7LXwGfMPg9mTkuh5tine3,251,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,type)
	return
def Je4TwC30iOG5DLKWAtbYvhs(url,type):
	qqgRSb3B5paTrzl8ANDFE2QCjJdZXe,data,items = 'GET',b8Qe150xVaJsnDSv,[]
	if type=='filters':
		if '?' in url:
			Ede3nm9tcg2,EEkjQFxOabod08Nr = 'POST',{}
			MUJCtfYVBLODrFbaZn,RnS0DVXIxG6KgBc584Cas9q = url.split('?')
			bCoNUQ3TXW7un = RnS0DVXIxG6KgBc584Cas9q.split('&')
			for CspH3o0yQVkReLwX8K9ql in bCoNUQ3TXW7un:
				key,Y8aiFZsLKw = CspH3o0yQVkReLwX8K9ql.split('=')
				EEkjQFxOabod08Nr[key] = Y8aiFZsLKw
			if bCoNUQ3TXW7un: qqgRSb3B5paTrzl8ANDFE2QCjJdZXe,url,data = Ede3nm9tcg2,MUJCtfYVBLODrFbaZn,EEkjQFxOabod08Nr
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,qqgRSb3B5paTrzl8ANDFE2QCjJdZXe,url,data,headers,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'ARABSEED-TITLES-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	if type=='filters': ZV5rRvabhxJ = [jLtdbeYiQHnf4SpU2MTly]
	elif 'featured' in type: ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('class="MainSlides(.*?)class="LinksList',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	elif type=='new_movies': ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('جديد الافلام.*?class="SliderInSection"(.*?)</ul>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	elif type=='new_episodes': ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('جديد الحلقات.*?class="SliderInSection"(.*?)</ul>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	elif type=='most': ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('class="SliderInSection(.*?)class="LinksList',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	else: ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('class="Blocks-UL"(.*?)class="AboElSeed"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if 'featured' in type:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		nEBd3XP4IHqN0MyQozeuCbxVhRa2S = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)" title="(.*?)".*?data-lazy.*? (src|data-image)="(.*?)"',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		if nEBd3XP4IHqN0MyQozeuCbxVhRa2S:
			KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j,uuSKUinvP4EGLxWZYmTsF,RRJIKrg0ivjomkpGhP,mLRifACEnrvgjyqz = zip(*nEBd3XP4IHqN0MyQozeuCbxVhRa2S)
			items = zip(KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j,mLRifACEnrvgjyqz,uuSKUinvP4EGLxWZYmTsF)
	else:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		items = YYBlm36zd0Jst18LXwo4.findall('LoadingArea.*? href="(.*?)".*? data-\w{3,5}="(.*?)".*? alt="(.*?)"',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	d3VSIefbHnvqiut = []
	for pcA1dzy7LXwGfMPg9mTkuh5tine3,lvtGpMZHb9,title in items:
		if 'WWE' in title: continue
		title = pTP49ckGDYrofa2KxenumbH0(title)
		if 'الحلقة' in title:
			HHr42WSgBjAeU7TkQcVaL6yEJz8PF = YYBlm36zd0Jst18LXwo4.findall('(.*?) الحلقة \d+',title,YYBlm36zd0Jst18LXwo4.DOTALL)
			if HHr42WSgBjAeU7TkQcVaL6yEJz8PF:
				title = '_MOD_' + HHr42WSgBjAeU7TkQcVaL6yEJz8PF[0]
				if title not in d3VSIefbHnvqiut:
					d3VSIefbHnvqiut.append(title)
					MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,253,lvtGpMZHb9)
			else: MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,252,lvtGpMZHb9)
		elif '/selary/' in pcA1dzy7LXwGfMPg9mTkuh5tine3 or 'مسلسل' in title:
			MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,253,lvtGpMZHb9)
		else:
			MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,252,lvtGpMZHb9)
	if type in ['newest','best','most']:
		items = YYBlm36zd0Jst18LXwo4.findall('page-numbers" href="(.*?)">(.*?)<',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = wQjs1XZ3AO24g8y9bEeoKMiGIu7+pcA1dzy7LXwGfMPg9mTkuh5tine3
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = pTP49ckGDYrofa2KxenumbH0(pcA1dzy7LXwGfMPg9mTkuh5tine3)
			title = pTP49ckGDYrofa2KxenumbH0(title)
			MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'صفحة '+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,251,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,type)
	return
def bIpskeGhBlqH(url):
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',url,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'ARABSEED-EPISODES-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	jLtdbeYiQHnf4SpU2MTly = jLtdbeYiQHnf4SpU2MTly[10000:]
	items = YYBlm36zd0Jst18LXwo4.findall('data-src="(.*?)".*?alt="(.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if not items: return
	lvtGpMZHb9,name = items[0]
	if 'الحلقة' in name: name = name.split('الحلقة')[0].strip(pldxivXC5wbTB2O8q)
	elif 'حلقة' in name: name = name.split('حلقة')[0].strip(pldxivXC5wbTB2O8q)
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('class="ContainerEpisodesList"(.*?)</div>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)".*?<em>(.*?)</em>',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,HHr42WSgBjAeU7TkQcVaL6yEJz8PF in items:
			title = name+' - الحلقة رقم '+HHr42WSgBjAeU7TkQcVaL6yEJz8PF
			MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,252,lvtGpMZHb9)
	else: MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+'ملف التشغيل',url,252,lvtGpMZHb9)
	return
def ue8t9LqHFixA6IsPvJyQW3(title,pcA1dzy7LXwGfMPg9mTkuh5tine3):
	HoXz65T8ph1CMeZgF = YYBlm36zd0Jst18LXwo4.findall('[a-zA-Z-]+',title,YYBlm36zd0Jst18LXwo4.DOTALL)
	if HoXz65T8ph1CMeZgF: title = HoXz65T8ph1CMeZgF[0]
	else: title = title+pldxivXC5wbTB2O8q+Wl2eu1PavfQ(pcA1dzy7LXwGfMPg9mTkuh5tine3,'name')
	title = title.replace('عرب سيد',b8Qe150xVaJsnDSv).replace('مباشر',b8Qe150xVaJsnDSv).replace('مشاهدة',b8Qe150xVaJsnDSv)
	title = title.replace('ٍ',b8Qe150xVaJsnDSv)
	title = title.replace(k5bCDErUSmv,pldxivXC5wbTB2O8q).replace(k5bCDErUSmv,pldxivXC5wbTB2O8q)
	return title
def Hkij627uCDJKyIM(url):
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(Q49IsrlSuYRAVbGKhwdckLDOetF2PZ,'GET',url,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'ARABSEED-PLAY-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	MUJCtfYVBLODrFbaZn = b3HKopTY9zLUyhJmt.url
	LLOCdZ3sS2enzXx4fVB18YRvbHNwky = Wl2eu1PavfQ(MUJCtfYVBLODrFbaZn,'url')
	headers['Referer'] = LLOCdZ3sS2enzXx4fVB18YRvbHNwky+'/'
	u6ukL3ViSptNXm50nGl2xwezWZ1bA,UqpKgJo1YRWx9y0n4C7wm8,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,[]
	GxFOEemTywB = YYBlm36zd0Jst18LXwo4.findall('class="WatchButtons".*?href="(.*?)" class="(watch.*?)".*?href="(.*?)" class="(download.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if GxFOEemTywB: u6ukL3ViSptNXm50nGl2xwezWZ1bA,oYe8RpT3jO17qBKDLkZd2gCJ,UqpKgJo1YRWx9y0n4C7wm8,jWqKYXlEZzQ = GxFOEemTywB[0]
	else:
		GxFOEemTywB = YYBlm36zd0Jst18LXwo4.findall('class="WatchButtons".*?href="(.*?)" class="(.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if GxFOEemTywB:
			pcA1dzy7LXwGfMPg9mTkuh5tine3,oYe8RpT3jO17qBKDLkZd2gCJ = GxFOEemTywB[0]
			if 'watch' in oYe8RpT3jO17qBKDLkZd2gCJ: u6ukL3ViSptNXm50nGl2xwezWZ1bA = pcA1dzy7LXwGfMPg9mTkuh5tine3
			else: UqpKgJo1YRWx9y0n4C7wm8 = pcA1dzy7LXwGfMPg9mTkuh5tine3
	if u6ukL3ViSptNXm50nGl2xwezWZ1bA:
		b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(Q49IsrlSuYRAVbGKhwdckLDOetF2PZ,'GET',u6ukL3ViSptNXm50nGl2xwezWZ1bA,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'ARABSEED-PLAY-2nd')
		jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('class="WatcherArea(.*?</ul>)',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if ZV5rRvabhxJ:
			Msj5nW9lTJaKduEF = ZV5rRvabhxJ[0]
			Msj5nW9lTJaKduEF = Msj5nW9lTJaKduEF.replace('</ul>','<h3>')
			Msj5nW9lTJaKduEF = Msj5nW9lTJaKduEF.replace('<h3>','<h3><h3>')
			JQjNkD10xehK8bXUalY3EgZAVmvI = YYBlm36zd0Jst18LXwo4.findall('<h3>.*?(\d+)(.*?)<h3>',Msj5nW9lTJaKduEF,YYBlm36zd0Jst18LXwo4.DOTALL)
			if not JQjNkD10xehK8bXUalY3EgZAVmvI: JQjNkD10xehK8bXUalY3EgZAVmvI = [(b8Qe150xVaJsnDSv,Msj5nW9lTJaKduEF)]
			for c1EdszLx3mkb8QYX9,OTKx7aVb2hdS16Wrweky4FXfIN0g9 in JQjNkD10xehK8bXUalY3EgZAVmvI:
				if c1EdszLx3mkb8QYX9: c1EdszLx3mkb8QYX9 = '____'+c1EdszLx3mkb8QYX9
				items = YYBlm36zd0Jst18LXwo4.findall('data-link="(.*?)".*?<span>(.*?)</span>',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
				for pcA1dzy7LXwGfMPg9mTkuh5tine3,name in items:
					if 'http' not in pcA1dzy7LXwGfMPg9mTkuh5tine3: pcA1dzy7LXwGfMPg9mTkuh5tine3 = 'http:'+pcA1dzy7LXwGfMPg9mTkuh5tine3
					pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3+'?named='+name+'__watch'+c1EdszLx3mkb8QYX9
					KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
		tzdvaEpMHOCZLXDYg08T = YYBlm36zd0Jst18LXwo4.findall('class="containerIframe".*? src="(.*?)".*? height="(.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if not tzdvaEpMHOCZLXDYg08T: tzdvaEpMHOCZLXDYg08T = YYBlm36zd0Jst18LXwo4.findall('class="containerIframe".*? SRC="(.*?)".*? HEIGHT="(.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if tzdvaEpMHOCZLXDYg08T:
			pcA1dzy7LXwGfMPg9mTkuh5tine3,c1EdszLx3mkb8QYX9 = tzdvaEpMHOCZLXDYg08T[0]
			name = Wl2eu1PavfQ(pcA1dzy7LXwGfMPg9mTkuh5tine3,'name')
			if '%' in c1EdszLx3mkb8QYX9: pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3+'?named='+name+'__embed__'
			else: pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3+'?named='+name+'__embed____'+c1EdszLx3mkb8QYX9
			KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
	if UqpKgJo1YRWx9y0n4C7wm8:
		b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(Q49IsrlSuYRAVbGKhwdckLDOetF2PZ,'GET',UqpKgJo1YRWx9y0n4C7wm8,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'ARABSEED-PLAY-3rd')
		jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('class="DownloadArea(.*?)<script src=',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if ZV5rRvabhxJ:
			Msj5nW9lTJaKduEF = ZV5rRvabhxJ[0]
			JQjNkD10xehK8bXUalY3EgZAVmvI = YYBlm36zd0Jst18LXwo4.findall('class="DownloadServers(.*?)</ul>',Msj5nW9lTJaKduEF,YYBlm36zd0Jst18LXwo4.DOTALL)
			for OTKx7aVb2hdS16Wrweky4FXfIN0g9 in JQjNkD10xehK8bXUalY3EgZAVmvI:
				items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)".*?<span>(.*?)</span>.*?<p>(.*?)</p>',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
				for pcA1dzy7LXwGfMPg9mTkuh5tine3,title,c1EdszLx3mkb8QYX9 in items:
					if not pcA1dzy7LXwGfMPg9mTkuh5tine3: continue
					if 'reviewstation' in pcA1dzy7LXwGfMPg9mTkuh5tine3: continue
					pcA1dzy7LXwGfMPg9mTkuh5tine3 = SgrGWuAHcLKBQMJetb9(pcA1dzy7LXwGfMPg9mTkuh5tine3)
					pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3+'?named='+title+'__download____'+c1EdszLx3mkb8QYX9
					KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
	qgUEOyNvC9r806MkoL = str(KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j)
	oVnfUpjMt8YCuzZNce2D = ['.zip?','.rar?','.txt?','.pdf?','.tar?','.iso?','.zip.','.rar.','.txt.','.pdf.','.tar.','.iso.']
	if any(Y8aiFZsLKw in qgUEOyNvC9r806MkoL for Y8aiFZsLKw in oVnfUpjMt8YCuzZNce2D):
		tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'رسالة من المبرمج','جرب رابط مختلف لأن هذا الرابط ليس من نوع الروابط التي فيها ملفات فيديو .. لأن هذا الموقع فيه خدمات أخرى غير ملفات الفيديو')
		return
	import QNeGEq8sWn
	QNeGEq8sWn.nqu2GCT9gHAbpIPSFZz5(KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j,QQ8pvXNcBfVkP5rRJ7o,'video',url)
	return
def kstJfK6jHQWrXDSMRIGB7(search):
	search,v7Rxw52Z4X0,showDialogs = JimhUH0SEf6w(search)
	if not search: search = FT2oXWtPQpVGuexmLqKN3srdzYn()
	if not search: return
	search = search.replace(pldxivXC5wbTB2O8q,'+')
	url = wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/find/?find='+search
	Je4TwC30iOG5DLKWAtbYvhs(url,'search')
	return
def eszTQbMvkmRwCAxGDPdYJUi(url,filter):
	if '??' in url: url = url.split('//getposts??')[0]
	type,filter = filter.split('___',1)
	if filter==b8Qe150xVaJsnDSv: us8FE67ImlDBS,bxTQdyVe57Bh0P8sG = b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv
	else: us8FE67ImlDBS,bxTQdyVe57Bh0P8sG = filter.split('___')
	if type=='CATEGORIES':
		if bSqGmCue8BQIUN9Pc7[0]+'==' not in us8FE67ImlDBS: Z8s0Lov2UiWF1qGjO = bSqGmCue8BQIUN9Pc7[0]
		for FbcUxvE17ewlWNBHgS8Jn in range(len(bSqGmCue8BQIUN9Pc7[0:-1])):
			if bSqGmCue8BQIUN9Pc7[FbcUxvE17ewlWNBHgS8Jn]+'==' in us8FE67ImlDBS: Z8s0Lov2UiWF1qGjO = bSqGmCue8BQIUN9Pc7[FbcUxvE17ewlWNBHgS8Jn+1]
		x5gCnOb9wjSPit6sVclHNZIkFyD0 = us8FE67ImlDBS+'&&'+Z8s0Lov2UiWF1qGjO+'==0'
		XFJqUiePG7aSf0N = bxTQdyVe57Bh0P8sG+'&&'+Z8s0Lov2UiWF1qGjO+'==0'
		Dnkl4UdcKRILWi6m7TqYJh98vu = x5gCnOb9wjSPit6sVclHNZIkFyD0.strip('&&')+'___'+XFJqUiePG7aSf0N.strip('&&')
		JXAZh9EQjse2qirMa8DRSYvGLO0kgf = W57WXlwPhyrfVu6oij(bxTQdyVe57Bh0P8sG,'modified_filters')
		MUJCtfYVBLODrFbaZn = url+'//getposts??'+JXAZh9EQjse2qirMa8DRSYvGLO0kgf
	elif type=='FILTERS':
		pRfP0YvVnLJdukUHstQA8cm = W57WXlwPhyrfVu6oij(us8FE67ImlDBS,'modified_values')
		pRfP0YvVnLJdukUHstQA8cm = SgrGWuAHcLKBQMJetb9(pRfP0YvVnLJdukUHstQA8cm)
		if bxTQdyVe57Bh0P8sG!=b8Qe150xVaJsnDSv: bxTQdyVe57Bh0P8sG = W57WXlwPhyrfVu6oij(bxTQdyVe57Bh0P8sG,'modified_filters')
		if bxTQdyVe57Bh0P8sG==b8Qe150xVaJsnDSv: MUJCtfYVBLODrFbaZn = url
		else: MUJCtfYVBLODrFbaZn = url+'//getposts??'+bxTQdyVe57Bh0P8sG
		ps2ueZoatbCrwq7mIHLiVMPxN9Q = wiH31OoSrnNCFzD(MUJCtfYVBLODrFbaZn)
		MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'أظهار قائمة الفيديو التي تم اختيارها ',ps2ueZoatbCrwq7mIHLiVMPxN9Q,251,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'filters')
		MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+' [[   '+pRfP0YvVnLJdukUHstQA8cm+'   ]]',ps2ueZoatbCrwq7mIHLiVMPxN9Q,251,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'filters')
		MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+' ===== ===== ===== '+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999)
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(Q49IsrlSuYRAVbGKhwdckLDOetF2PZ,'POST',url,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'ARABSEED-FILTERS_MENU-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('class="TaxPageFilter"(.*?)class="TermBTNs"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
	uX3icZLY0wHTa = YYBlm36zd0Jst18LXwo4.findall('class="TaxPageFilterItem".*?<em>(.*?)</em>.*?data-tax="(.*?)"(.*?)</ul>',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	Y6Zw9aHmf3UAC = YYBlm36zd0Jst18LXwo4.findall('class="RatingFilter".*?<h4>(.*?)</h4>.*?(<ul>)(.*?)</ul>',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	RYqsiFGfj07T2VKXrx3y6Hb = uX3icZLY0wHTa+Y6Zw9aHmf3UAC
	dict = {}
	for name,BnHr3VSlN5cMhZ7miAfGLovdbQJWa,OTKx7aVb2hdS16Wrweky4FXfIN0g9 in RYqsiFGfj07T2VKXrx3y6Hb:
		items = YYBlm36zd0Jst18LXwo4.findall('data-name="(.*?)".*?data-tax="(.*?)".*?data-term="(.*?)"',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		if name=='اخرى': name = 'الاقسام'
		if not items:
			xxnATEUzH6Djmq0NrBveh = YYBlm36zd0Jst18LXwo4.findall('data-rate="(.*?)".*?<em>(.*?)</em>',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
			items = []
			for Ny03TjaY7bBxWwm2GI,Y8aiFZsLKw in xxnATEUzH6Djmq0NrBveh: items.append([Ny03TjaY7bBxWwm2GI,b8Qe150xVaJsnDSv,Y8aiFZsLKw])
			BnHr3VSlN5cMhZ7miAfGLovdbQJWa = 'rate'
			name = 'التقييم'
		else: BnHr3VSlN5cMhZ7miAfGLovdbQJWa = items[0][1]
		if '==' not in MUJCtfYVBLODrFbaZn: MUJCtfYVBLODrFbaZn = url
		if type=='CATEGORIES':
			if Z8s0Lov2UiWF1qGjO!=BnHr3VSlN5cMhZ7miAfGLovdbQJWa: continue
			elif len(items)<=1:
				if BnHr3VSlN5cMhZ7miAfGLovdbQJWa==bSqGmCue8BQIUN9Pc7[-1]: Je4TwC30iOG5DLKWAtbYvhs(MUJCtfYVBLODrFbaZn)
				else: eszTQbMvkmRwCAxGDPdYJUi(MUJCtfYVBLODrFbaZn,'CATEGORIES___'+Dnkl4UdcKRILWi6m7TqYJh98vu)
				return
			else:
				ps2ueZoatbCrwq7mIHLiVMPxN9Q = wiH31OoSrnNCFzD(MUJCtfYVBLODrFbaZn)
				if BnHr3VSlN5cMhZ7miAfGLovdbQJWa==bSqGmCue8BQIUN9Pc7[-1]: MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'الجميع ',ps2ueZoatbCrwq7mIHLiVMPxN9Q,251,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'filters')
				else: MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'الجميع ',MUJCtfYVBLODrFbaZn,254,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,Dnkl4UdcKRILWi6m7TqYJh98vu)
		elif type=='FILTERS':
			x5gCnOb9wjSPit6sVclHNZIkFyD0 = us8FE67ImlDBS+'&&'+BnHr3VSlN5cMhZ7miAfGLovdbQJWa+'==0'
			XFJqUiePG7aSf0N = bxTQdyVe57Bh0P8sG+'&&'+BnHr3VSlN5cMhZ7miAfGLovdbQJWa+'==0'
			Dnkl4UdcKRILWi6m7TqYJh98vu = x5gCnOb9wjSPit6sVclHNZIkFyD0+'___'+XFJqUiePG7aSf0N
			MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'الجميع :'+name,MUJCtfYVBLODrFbaZn,255,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,Dnkl4UdcKRILWi6m7TqYJh98vu)
		dict[BnHr3VSlN5cMhZ7miAfGLovdbQJWa] = {}
		for Ny03TjaY7bBxWwm2GI,jprAaOYCD6yM8P5VZXK1B2ldNbuR,Y8aiFZsLKw in items:
			if Ny03TjaY7bBxWwm2GI in v1vJEhoNQBVPkjG: continue
			if 'الكل' in Ny03TjaY7bBxWwm2GI: continue
			Ny03TjaY7bBxWwm2GI = pTP49ckGDYrofa2KxenumbH0(Ny03TjaY7bBxWwm2GI)
			t0TJBoN2dZzE4xKSQw1FfV7scC9,HoXz65T8ph1CMeZgF = Ny03TjaY7bBxWwm2GI,Ny03TjaY7bBxWwm2GI
			HoXz65T8ph1CMeZgF = name+': '+t0TJBoN2dZzE4xKSQw1FfV7scC9
			dict[BnHr3VSlN5cMhZ7miAfGLovdbQJWa][Y8aiFZsLKw] = HoXz65T8ph1CMeZgF
			x5gCnOb9wjSPit6sVclHNZIkFyD0 = us8FE67ImlDBS+'&&'+BnHr3VSlN5cMhZ7miAfGLovdbQJWa+'=='+t0TJBoN2dZzE4xKSQw1FfV7scC9
			XFJqUiePG7aSf0N = bxTQdyVe57Bh0P8sG+'&&'+BnHr3VSlN5cMhZ7miAfGLovdbQJWa+'=='+Y8aiFZsLKw
			NHEdmMD3qPj4zay2nb5O8xKX = x5gCnOb9wjSPit6sVclHNZIkFyD0+'___'+XFJqUiePG7aSf0N
			if type=='FILTERS':
				MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+HoXz65T8ph1CMeZgF,url,255,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,NHEdmMD3qPj4zay2nb5O8xKX)
			elif type=='CATEGORIES' and bSqGmCue8BQIUN9Pc7[-2]+'==' in us8FE67ImlDBS:
				JXAZh9EQjse2qirMa8DRSYvGLO0kgf = W57WXlwPhyrfVu6oij(XFJqUiePG7aSf0N,'modified_filters')
				GSh0nJxEXgZjd48u7mBwWOeafyAp5b = url+'//getposts??'+JXAZh9EQjse2qirMa8DRSYvGLO0kgf
				ps2ueZoatbCrwq7mIHLiVMPxN9Q = wiH31OoSrnNCFzD(GSh0nJxEXgZjd48u7mBwWOeafyAp5b)
				MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+HoXz65T8ph1CMeZgF,ps2ueZoatbCrwq7mIHLiVMPxN9Q,251,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'filters')
			else: MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+HoXz65T8ph1CMeZgF,url,254,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,NHEdmMD3qPj4zay2nb5O8xKX)
	return
bSqGmCue8BQIUN9Pc7 = ['category','country','release-year']
k48PqwdL0S = ['category','country','genre','release-year','language','quality','rate']
def wiH31OoSrnNCFzD(url):
	rPBC5DOamfVSXc0wq = '/wp-content/themes/Elshaikh2021/Ajaxat/Home/FilteringHome.php'
	url = url.replace('//getposts',rPBC5DOamfVSXc0wq)
	url = url.replace('/category/اخرى',b8Qe150xVaJsnDSv)
	if rPBC5DOamfVSXc0wq not in url: url = url+rPBC5DOamfVSXc0wq
	url = url.replace('release-year','year')
	url = url.replace('??','?')
	url = url.replace('&&','&')
	url = url.replace('==','=')
	return url
def W57WXlwPhyrfVu6oij(J6rINOCGlW5M4SXjgwc9U7,mode):
	J6rINOCGlW5M4SXjgwc9U7 = J6rINOCGlW5M4SXjgwc9U7.strip('&&')
	hj1lf3cGzLMURVTKkBZmDoyix28,sBF1epSJZbIUAgM4hVLPD50 = {},b8Qe150xVaJsnDSv
	if '==' in J6rINOCGlW5M4SXjgwc9U7:
		items = J6rINOCGlW5M4SXjgwc9U7.split('&&')
		for tgoJCpq8KGrdaUSjsLh0FTxDRPfIAB in items:
			VRcGtBaO1xun,Y8aiFZsLKw = tgoJCpq8KGrdaUSjsLh0FTxDRPfIAB.split('==')
			hj1lf3cGzLMURVTKkBZmDoyix28[VRcGtBaO1xun] = Y8aiFZsLKw
	for key in k48PqwdL0S:
		if key in list(hj1lf3cGzLMURVTKkBZmDoyix28.keys()): Y8aiFZsLKw = hj1lf3cGzLMURVTKkBZmDoyix28[key]
		else: Y8aiFZsLKw = '0'
		if '%' not in Y8aiFZsLKw: Y8aiFZsLKw = HHbaVYqFRy6v0c(Y8aiFZsLKw)
		if mode=='modified_values' and Y8aiFZsLKw!='0': sBF1epSJZbIUAgM4hVLPD50 = sBF1epSJZbIUAgM4hVLPD50+' + '+Y8aiFZsLKw
		elif mode=='modified_filters' and Y8aiFZsLKw!='0': sBF1epSJZbIUAgM4hVLPD50 = sBF1epSJZbIUAgM4hVLPD50+'&&'+key+'=='+Y8aiFZsLKw
		elif mode=='all': sBF1epSJZbIUAgM4hVLPD50 = sBF1epSJZbIUAgM4hVLPD50+'&&'+key+'=='+Y8aiFZsLKw
	sBF1epSJZbIUAgM4hVLPD50 = sBF1epSJZbIUAgM4hVLPD50.strip(' + ')
	sBF1epSJZbIUAgM4hVLPD50 = sBF1epSJZbIUAgM4hVLPD50.strip('&&')
	return sBF1epSJZbIUAgM4hVLPD50
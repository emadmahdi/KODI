# -*- coding: utf-8 -*-
from hIVCFnfxSO import *
QQ8pvXNcBfVkP5rRJ7o = 'CIMALIGHT'
WbzmKSZiuOYrBN7oysJ2dUv = '_CML_'
wQjs1XZ3AO24g8y9bEeoKMiGIu7 = nTHXJIiah2qK[QQ8pvXNcBfVkP5rRJ7o][0]
v1vJEhoNQBVPkjG = ['قنوات فضائية']
def x8IFqMZeJj7suCR4AaGoNXfEHm(mode,url,text):
	if   mode==470: XXxlOLJ9KRjPH382WVCvr6n71 = Y72YmLgw4vqlHxTCkbeKSicasD()
	elif mode==471: XXxlOLJ9KRjPH382WVCvr6n71 = Je4TwC30iOG5DLKWAtbYvhs(url,text)
	elif mode==472: XXxlOLJ9KRjPH382WVCvr6n71 = Hkij627uCDJKyIM(url)
	elif mode==473: XXxlOLJ9KRjPH382WVCvr6n71 = Writ3OlNChGRBoPFD4e9ugSVsmfx(url,text)
	elif mode==474: XXxlOLJ9KRjPH382WVCvr6n71 = Q6mUHMbNlirVXPRgKWJAt8ap5hSE(url)
	elif mode==479: XXxlOLJ9KRjPH382WVCvr6n71 = kstJfK6jHQWrXDSMRIGB7(text)
	else: XXxlOLJ9KRjPH382WVCvr6n71 = False
	return XXxlOLJ9KRjPH382WVCvr6n71
def Y72YmLgw4vqlHxTCkbeKSicasD():
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',wQjs1XZ3AO24g8y9bEeoKMiGIu7,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'CIMALIGHT-MENU-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	OZSA7QNfeE = YYBlm36zd0Jst18LXwo4.findall('"url": "(.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	OZSA7QNfeE = OZSA7QNfeE[0].strip('/')
	OZSA7QNfeE = Wl2eu1PavfQ(OZSA7QNfeE,'url')
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'بحث في الموقع',b8Qe150xVaJsnDSv,479,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'_REMEMBERRESULTS_')
	MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+' ===== ===== ===== '+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999)
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('"content"(.*?)</div>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
	items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)".*?</i>(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
		title = title.replace(k5bCDErUSmv,b8Qe150xVaJsnDSv).strip(pldxivXC5wbTB2O8q)
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3.replace('cat=online-movies1','cat=online-movies')
		MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,474)
	MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+' ===== ===== ===== '+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999)
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('/category.php">(.*?)"navslide-divider"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall("'dropdown-menu'(.*?)</ul>",jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)".*?>(.*?)</a>',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
		if title in v1vJEhoNQBVPkjG: continue
		if 'مسلسل ' in title: continue
		if 'برنامج ' in title: continue
		if 'للكبار' in title: continue
		MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,474)
	return
def Q6mUHMbNlirVXPRgKWJAt8ap5hSE(url):
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'CIMALIGHT-TITLES-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	if 'topvideos.php' in url: ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('"caret"(.*?)id="pm-grid"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	else: ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('"caret"(.*?)</ul>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)".*?>(.*?)</a>',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
			if 'topvideos.php' in pcA1dzy7LXwGfMPg9mTkuh5tine3:
				if 'topvideos.php?c=english-movies' in pcA1dzy7LXwGfMPg9mTkuh5tine3: continue
				if 'topvideos.php?c=online-movies1' in pcA1dzy7LXwGfMPg9mTkuh5tine3: continue
				if 'topvideos.php?c=misc' in pcA1dzy7LXwGfMPg9mTkuh5tine3: continue
				if 'topvideos.php?c=tv-channel' in pcA1dzy7LXwGfMPg9mTkuh5tine3: continue
				if 'منذ البداية' in title and 'do=rating' not in pcA1dzy7LXwGfMPg9mTkuh5tine3: continue
			MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,471)
	else: Je4TwC30iOG5DLKWAtbYvhs(url)
	return
def Je4TwC30iOG5DLKWAtbYvhs(url,rC39wAIKjUuS=b8Qe150xVaJsnDSv):
	OZSA7QNfeE = Wl2eu1PavfQ(url,'url')
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'CIMALIGHT-TITLES-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	items = []
	if rC39wAIKjUuS=='featured_movies':
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('"container-fluid"(.*?)</ul>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)".*?"title">(.*?)</div>.*?image:url\(\'(.*?)\'\)',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		tzdvaEpMHOCZLXDYg08T,YRtyADTLUrGc,M5PhpbrxvZkXwJN7tTDAF1SmKf = zip(*items)
		items = zip(M5PhpbrxvZkXwJN7tTDAF1SmKf,tzdvaEpMHOCZLXDYg08T,YRtyADTLUrGc)
	elif rC39wAIKjUuS=='featured_series':
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('المسلسلات المميزة(.*?)<style>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)".*?title="(.*?)".*?image:url\(\'(.*?)\'\)',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		tzdvaEpMHOCZLXDYg08T,YRtyADTLUrGc,M5PhpbrxvZkXwJN7tTDAF1SmKf = zip(*items)
		items = zip(M5PhpbrxvZkXwJN7tTDAF1SmKf,tzdvaEpMHOCZLXDYg08T,YRtyADTLUrGc)
	else:
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('(data-echo=".*?)</ul>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if not ZV5rRvabhxJ: ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('"BlocksList"(.*?)"titleSectionCon"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if not ZV5rRvabhxJ: ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('id="pm-grid"(.*?)</ul>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if not ZV5rRvabhxJ: ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('id="pm-related"(.*?)</ul>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if not ZV5rRvabhxJ: ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('pm-ul-browse-videos(.*?)clearfix',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if not ZV5rRvabhxJ: return
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
	if not items: items = YYBlm36zd0Jst18LXwo4.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	if not items: items = YYBlm36zd0Jst18LXwo4.findall('src="(.*?)".*?href="(.*?)".*?>(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	d3VSIefbHnvqiut = []
	PBFVNlrcUMOSzC04 = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for lvtGpMZHb9,pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = SgrGWuAHcLKBQMJetb9(pcA1dzy7LXwGfMPg9mTkuh5tine3).strip('/')
		title = title.replace('ماي سيما',b8Qe150xVaJsnDSv).replace('مشاهدة',b8Qe150xVaJsnDSv).strip(pldxivXC5wbTB2O8q).replace(k5bCDErUSmv,pldxivXC5wbTB2O8q)
		if 'http' not in pcA1dzy7LXwGfMPg9mTkuh5tine3: pcA1dzy7LXwGfMPg9mTkuh5tine3 = OZSA7QNfeE+'/'+pcA1dzy7LXwGfMPg9mTkuh5tine3.strip('/')
		if 'http' not in lvtGpMZHb9: lvtGpMZHb9 = OZSA7QNfeE+'/'+lvtGpMZHb9.strip('/')
		HHr42WSgBjAeU7TkQcVaL6yEJz8PF = YYBlm36zd0Jst18LXwo4.findall('(.*?) (الحلقة|حلقة) \d+',title,YYBlm36zd0Jst18LXwo4.DOTALL)
		if any(Y8aiFZsLKw in title for Y8aiFZsLKw in PBFVNlrcUMOSzC04):
			title = '_MOD_'+title
			MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,472,lvtGpMZHb9)
		elif HHr42WSgBjAeU7TkQcVaL6yEJz8PF and 'حلقة' in title:
			title = '_MOD_'+HHr42WSgBjAeU7TkQcVaL6yEJz8PF[0][0]
			if title not in d3VSIefbHnvqiut:
				MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,473,lvtGpMZHb9)
				d3VSIefbHnvqiut.append(title)
		elif '/movseries/' in pcA1dzy7LXwGfMPg9mTkuh5tine3:
			MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,471,lvtGpMZHb9)
		else: MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,473,lvtGpMZHb9)
	if rC39wAIKjUuS not in ['featured_movies','featured_series']:
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('"pagination(.*?)</ul>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if ZV5rRvabhxJ:
			OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
			items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)".*?>(.*?)</a>',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
			for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
				if pcA1dzy7LXwGfMPg9mTkuh5tine3=='#': continue
				pcA1dzy7LXwGfMPg9mTkuh5tine3 = OZSA7QNfeE+'/'+pcA1dzy7LXwGfMPg9mTkuh5tine3.strip('/')
				title = pTP49ckGDYrofa2KxenumbH0(title)
				MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'صفحة '+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,471)
		SArDcVYZRkXvC4xpaiQIfE35K = YYBlm36zd0Jst18LXwo4.findall('showmore" href="(.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if SArDcVYZRkXvC4xpaiQIfE35K:
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = SArDcVYZRkXvC4xpaiQIfE35K[0]
			MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'مشاهدة المزيد',pcA1dzy7LXwGfMPg9mTkuh5tine3,471)
	return
def Writ3OlNChGRBoPFD4e9ugSVsmfx(url,ywbiNqdBD6makJ):
	OZSA7QNfeE = Wl2eu1PavfQ(url,'url')
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'CIMALIGHT-EPISODES-2nd')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	Pmt5K6LAEZBcb = YYBlm36zd0Jst18LXwo4.findall('"SeasonsBox"(.*?)</div>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	items = []
	if Pmt5K6LAEZBcb and not ywbiNqdBD6makJ:
		lvtGpMZHb9 = YYBlm36zd0Jst18LXwo4.findall('"series-header".*?src="(.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		lvtGpMZHb9 = lvtGpMZHb9[0] if lvtGpMZHb9 else b8Qe150xVaJsnDSv
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = Pmt5K6LAEZBcb[0]
		items = YYBlm36zd0Jst18LXwo4.findall('openCity\(event\, \'(.*?)\'\)".*?>(.*?)</button>',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		if len(items)==1: ywbiNqdBD6makJ = items[0][0]
		elif len(items)>1:
			for ywbiNqdBD6makJ,title in items: MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,url,473,lvtGpMZHb9,b8Qe150xVaJsnDSv,ywbiNqdBD6makJ)
	U8UnzJgXuMIE5GV = YYBlm36zd0Jst18LXwo4.findall('id="'+ywbiNqdBD6makJ+'"(.*?)</ul>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if U8UnzJgXuMIE5GV and len(items)<2:
		lvtGpMZHb9 = YYBlm36zd0Jst18LXwo4.findall('"series-header".*?src="(.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		lvtGpMZHb9 = lvtGpMZHb9[0] if lvtGpMZHb9 else b8Qe150xVaJsnDSv
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = U8UnzJgXuMIE5GV[0]
		items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)".*?title="(.*?)"',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		if items:
			for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
				title = title.replace('ماي سيما',b8Qe150xVaJsnDSv).replace('مسلسل',b8Qe150xVaJsnDSv).strip(pldxivXC5wbTB2O8q)
				if 'http' not in pcA1dzy7LXwGfMPg9mTkuh5tine3: pcA1dzy7LXwGfMPg9mTkuh5tine3 = OZSA7QNfeE+'/'+pcA1dzy7LXwGfMPg9mTkuh5tine3.strip('/')
				MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,472,lvtGpMZHb9)
		else:
			items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)".*?title="(.*?)".*?image:url\((.*?)\)',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
			for pcA1dzy7LXwGfMPg9mTkuh5tine3,title,lvtGpMZHb9 in items:
				if 'http' not in pcA1dzy7LXwGfMPg9mTkuh5tine3: pcA1dzy7LXwGfMPg9mTkuh5tine3 = OZSA7QNfeE+'/'+pcA1dzy7LXwGfMPg9mTkuh5tine3.strip('/')
				MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,472,lvtGpMZHb9)
	if 'id="pm-related"' in jLtdbeYiQHnf4SpU2MTly:
		if items: MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+' ===== ===== ===== '+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999)
		MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'مواضيع ذات صلة',url,471)
	return
def Hkij627uCDJKyIM(url):
	KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = []
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'CIMALIGHT-PLAY-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('<div itemprop="description">(.*?)href=',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		EQUkgc3PLy5mhBiZINJ0HO1A6 = YYBlm36zd0Jst18LXwo4.findall('<p>(.*?)</p>',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		if EQUkgc3PLy5mhBiZINJ0HO1A6 and vvIMS2DeraLfJ(QQ8pvXNcBfVkP5rRJ7o,url,EQUkgc3PLy5mhBiZINJ0HO1A6,True): return
	MUJCtfYVBLODrFbaZn = url.replace('/watch.php','/play.php')
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',MUJCtfYVBLODrFbaZn,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'CIMALIGHT-PLAY-2nd')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	WR6UgVpdXBPxvOtiSJIn = []
	pcA1dzy7LXwGfMPg9mTkuh5tine3 = YYBlm36zd0Jst18LXwo4.findall('"embedURL" href="(.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if pcA1dzy7LXwGfMPg9mTkuh5tine3:
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3[0]
		if pcA1dzy7LXwGfMPg9mTkuh5tine3 and pcA1dzy7LXwGfMPg9mTkuh5tine3 not in WR6UgVpdXBPxvOtiSJIn:
			WR6UgVpdXBPxvOtiSJIn.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3+'?named=__embed'
			if 'http' not in pcA1dzy7LXwGfMPg9mTkuh5tine3: pcA1dzy7LXwGfMPg9mTkuh5tine3 = 'http:'+pcA1dzy7LXwGfMPg9mTkuh5tine3
			KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
	items = YYBlm36zd0Jst18LXwo4.findall("<iframe src='(.*?)'.*?<strong>(.*?)</strong>",jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
		if pcA1dzy7LXwGfMPg9mTkuh5tine3 not in WR6UgVpdXBPxvOtiSJIn:
			WR6UgVpdXBPxvOtiSJIn.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3+'?named='+title+'__watch'
			if 'http' not in pcA1dzy7LXwGfMPg9mTkuh5tine3: pcA1dzy7LXwGfMPg9mTkuh5tine3 = 'http:'+pcA1dzy7LXwGfMPg9mTkuh5tine3
			KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
	MUJCtfYVBLODrFbaZn = url.replace('/watch.php','/downloads.php')
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',MUJCtfYVBLODrFbaZn,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'CIMALIGHT-PLAY-3rd')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('"downloadlist"(.*?)</ul>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)".*?<strong>(.*?)</strong>',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
			if pcA1dzy7LXwGfMPg9mTkuh5tine3 not in WR6UgVpdXBPxvOtiSJIn:
				WR6UgVpdXBPxvOtiSJIn.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
				pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3+'?named='+title+'__download'
				if 'http' not in pcA1dzy7LXwGfMPg9mTkuh5tine3: pcA1dzy7LXwGfMPg9mTkuh5tine3 = 'http:'+pcA1dzy7LXwGfMPg9mTkuh5tine3
				KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
	import QNeGEq8sWn
	QNeGEq8sWn.nqu2GCT9gHAbpIPSFZz5(KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j,QQ8pvXNcBfVkP5rRJ7o,'video',url)
	return
def kstJfK6jHQWrXDSMRIGB7(search):
	search,v7Rxw52Z4X0,showDialogs = JimhUH0SEf6w(search)
	if search==b8Qe150xVaJsnDSv: search = FT2oXWtPQpVGuexmLqKN3srdzYn()
	if search==b8Qe150xVaJsnDSv: return
	search = search.replace(pldxivXC5wbTB2O8q,'+')
	LLOCdZ3sS2enzXx4fVB18YRvbHNwky = Wl2eu1PavfQ(wQjs1XZ3AO24g8y9bEeoKMiGIu7,'url')
	url = LLOCdZ3sS2enzXx4fVB18YRvbHNwky+'/search.php?keywords='+search
	Je4TwC30iOG5DLKWAtbYvhs(url,'search')
	return
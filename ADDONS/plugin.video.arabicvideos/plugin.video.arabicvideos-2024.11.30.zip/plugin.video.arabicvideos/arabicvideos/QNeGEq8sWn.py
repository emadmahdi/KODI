# -*- coding: utf-8 -*-
import sys as Pft6y0LvwSh48iYg7b
MQBw2uYHcWbpxF8tKAV = Pft6y0LvwSh48iYg7b.version_info [0] == 2
myc93k4htNU67 = 2048
h8lCkw1d3LepDVuvfoicEXj5K6sPz = 7
def JanmRV2MtcH (VwngrDb8fEytv4kMTdQu95cIejsC):
	global oPFYqewitzj
	WBrAFcJPVXdS2UzxLEGM0omkD = ord (VwngrDb8fEytv4kMTdQu95cIejsC [-1])
	V13jmfpwhlcyCKMRLY5TiaG = VwngrDb8fEytv4kMTdQu95cIejsC [:-1]
	gyF4Uq9l1NQKCtT = WBrAFcJPVXdS2UzxLEGM0omkD % len (V13jmfpwhlcyCKMRLY5TiaG)
	BN5pdqozP2v9Ur1Swsia = V13jmfpwhlcyCKMRLY5TiaG [:gyF4Uq9l1NQKCtT] + V13jmfpwhlcyCKMRLY5TiaG [gyF4Uq9l1NQKCtT:]
	if MQBw2uYHcWbpxF8tKAV:
		D3MGYw1ceHQ4UbrNJSq = unicode () .join ([unichr (ord (bb1FgjciZqDzeQTBC2hplaPkmRIyUf) - myc93k4htNU67 - (Ni5bJjhpks6SfCc + WBrAFcJPVXdS2UzxLEGM0omkD) % h8lCkw1d3LepDVuvfoicEXj5K6sPz) for Ni5bJjhpks6SfCc, bb1FgjciZqDzeQTBC2hplaPkmRIyUf in enumerate (BN5pdqozP2v9Ur1Swsia)])
	else:
		D3MGYw1ceHQ4UbrNJSq = str () .join ([chr (ord (bb1FgjciZqDzeQTBC2hplaPkmRIyUf) - myc93k4htNU67 - (Ni5bJjhpks6SfCc + WBrAFcJPVXdS2UzxLEGM0omkD) % h8lCkw1d3LepDVuvfoicEXj5K6sPz) for Ni5bJjhpks6SfCc, bb1FgjciZqDzeQTBC2hplaPkmRIyUf in enumerate (BN5pdqozP2v9Ur1Swsia)])
	return eval (D3MGYw1ceHQ4UbrNJSq)
TYf7Dc06PQgy1vEV9,ubxGUTt1LraKhVZgpAP,Y2t8baH5GWikvOZ7NsCeq3TKrgMV=JanmRV2MtcH,JanmRV2MtcH,JanmRV2MtcH
BWNPxIG7vqdTy85pjHzUOrK3,Mmpr0o76iWJvz1kTtfgI8hES,QTUBCcehw6qPd4x=Y2t8baH5GWikvOZ7NsCeq3TKrgMV,ubxGUTt1LraKhVZgpAP,TYf7Dc06PQgy1vEV9
mQNonhS7CV2BXOv,HwB7ydlWVJeCtPuQ6MDE1RTYOo,uVQd103XyvUce2EBtzbYaC=QTUBCcehw6qPd4x,Mmpr0o76iWJvz1kTtfgI8hES,BWNPxIG7vqdTy85pjHzUOrK3
yST5AHEfvPmcWpwGuh2BJ,BmePGjS7FxK6kutUM,S0IlDPhBN3gMEUvnjRLXsYAc2Zf=uVQd103XyvUce2EBtzbYaC,HwB7ydlWVJeCtPuQ6MDE1RTYOo,mQNonhS7CV2BXOv
Xz3bA2PFENVCUtplu51,LAQD5wEkr18bUiGaYen3J,P0qdZI384LKleuo=S0IlDPhBN3gMEUvnjRLXsYAc2Zf,BmePGjS7FxK6kutUM,yST5AHEfvPmcWpwGuh2BJ
shC5qBRV2A0lZ,mmcNLrXtzfpyCkZlvK5VwG2gujh,m6hwdgP31a2zjN7lkpX=P0qdZI384LKleuo,LAQD5wEkr18bUiGaYen3J,Xz3bA2PFENVCUtplu51
IjZbnrBJmM2N,Nh0BWuiSndf,kke1PDGRBLuY8y=m6hwdgP31a2zjN7lkpX,mmcNLrXtzfpyCkZlvK5VwG2gujh,shC5qBRV2A0lZ
ddo23ZJtgcY,vvWwO3Tx2dAgcijrFXq,DYakr9g4PVU=kke1PDGRBLuY8y,Nh0BWuiSndf,IjZbnrBJmM2N
zI3ROAZtiUq42rE9WDST68,Dzs8qU2gQMcCSyRhiZn4TFbeGk,dDYUoKi6JFM23p=DYakr9g4PVU,vvWwO3Tx2dAgcijrFXq,ddo23ZJtgcY
QQdAXWBc2GPw,VFjQx6Is28KvzLOmMXtg4GqTwa3,TT8Mxv5Wq7nlC9IscdpPUY6=dDYUoKi6JFM23p,Dzs8qU2gQMcCSyRhiZn4TFbeGk,zI3ROAZtiUq42rE9WDST68
SbjiWeHLQPoazqwp3cODkd7YxVgn,UUkIBz1sgQ9WfNeG6trKXvu0,RRIHDFjoW9w7bSfVPhC=TT8Mxv5Wq7nlC9IscdpPUY6,VFjQx6Is28KvzLOmMXtg4GqTwa3,QQdAXWBc2GPw
from hIVCFnfxSO import *
QQ8pvXNcBfVkP5rRJ7o = Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫạ")
Ffvnme6CyOpsxXUMN0V1zQdj4TAi = []
headers = {uVQd103XyvUce2EBtzbYaC(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭Ả"):b8Qe150xVaJsnDSv}
def PSmWeXc21CIaUOi3rAu5Zwz8s9vkM(source,E57WK4m31C8,url):
	mwIxD3GBPgLVc2aq9(WG2BfeyzMa,EECz06teoykrNFfq(QQ8pvXNcBfVkP5rRJ7o)+ubxGUTt1LraKhVZgpAP(u"ࠪࠤࠥࠦࡆࡢ࡫࡯ࡩࡩࠦࡦࡪࡰࡧ࡭ࡳ࡭ࠠࡷ࡫ࡧࡩࡴࠦࡦࡪ࡮ࡨࡷࠥࠦࠠࠡࡕ࡬ࡸࡪࡀࠠ࡜ࠢࠪả")+source+ddo23ZJtgcY(u"ࠫࠥࡣࠠࠡࠢࠣࡘࡾࡶࡥ࠻ࠢ࡞ࠤࠬẤ")+E57WK4m31C8+S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠬࠦ࡝ࠨấ"))
	auEf3hRNpv = SS2OK7hjLagvUAm(mshLJcKH1fv03yRnDOr4ZT,SbjiWeHLQPoazqwp3cODkd7YxVgn(u"࠭ࡤࡪࡥࡷࠫẦ"),Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪầ"),ddo23ZJtgcY(u"ࠨࡕࡌࡘࡊ࡙࡟ࡆࡔࡕࡓࡗ࡙ࠧẨ"))
	OJLzFcW1bdij5 = wLQCTr5lqbsVYeAHdzfhZ1F.strftime(TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠩࠨ࡝࠳ࠫ࡭࠯ࠧࡧࠤࠪࡎ࠺ࠦࡏࠪẩ"),wLQCTr5lqbsVYeAHdzfhZ1F.gmtime(T3Axql94cU0BpO1wudEDtWXsf))
	CspH3o0yQVkReLwX8K9ql = OJLzFcW1bdij5,url
	key = source+eiopkn4y9uWDQ5+cpGrK6qnPi+eiopkn4y9uWDQ5+str(g1gmkxOtc2oeEZHhBiy)
	A4gdSTQDP2FyBIVuba85RvYqKU = b8Qe150xVaJsnDSv
	if key not in list(auEf3hRNpv.keys()): auEf3hRNpv[key] = [CspH3o0yQVkReLwX8K9ql]
	else:
		if url not in str(auEf3hRNpv[key]): auEf3hRNpv[key].append(CspH3o0yQVkReLwX8K9ql)
		else: A4gdSTQDP2FyBIVuba85RvYqKU = kke1PDGRBLuY8y(u"ࠪࡠࡳࠦ็ัษࠣห้็๊ะ์๋ࠤ๊๎ฬ้ัࠣๅ๏ࠦโศศ่อࠥอไโ์า๎ํํวหࠢส่ฯ๐ࠠๅ็ࠣฮ฾๋ไࠨẪ")
	ZLWoKIJEyx96uf = LzYQg91SIxDeOGtCKd5
	for key in list(auEf3hRNpv.keys()):
		auEf3hRNpv[key] = list(set(auEf3hRNpv[key]))
		ZLWoKIJEyx96uf += len(auEf3hRNpv[key])
	tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧẫ"),Xz3bA2PFENVCUtplu51(u"๊ࠬไฤีไࠤฬ๊ศา่ส้ัࠦไๆࠢํะิࠦๅๅใสฮࠥอไโ์า๎ํ࠭Ậ")+A4gdSTQDP2FyBIVuba85RvYqKU+TT8Mxv5Wq7nlC9IscdpPUY6(u"࠭࡜࡯࡞ࡱࠤู้๊ๅ็ࠣห้ฮั็ษ่ะࠥ๐โ้็ࠣฬัู๋ࠡไสส๊ฯࠠษษ็ๅ๏ี๊้้สฮࠥอไห์่๊๊ࠣࠦอั่ࠣ์อࠠๆๆไหฯࠦแ๋ัํ์ࠥ๎ำ้ใࠣ๎฾ืึࠡ฻็๎่ࠦวๅสิ๊ฬ๋ฬࠡล้ࠤฯืำๅ๊ࠢิ์ࠦวๅไสส๊ฯࠠฦๆ์ࠤฬ๊ๅษำ่ะࠥ฿ๆะ็สࠤ๏฻ศฮࠢ฼ำิํวࠡ࠷ࠣๅ๏ี๊้้สฮࠬậ")+uVQd103XyvUce2EBtzbYaC(u"ࠧ࡝ࡰ࡟ࡲࠬẮ")+P0qdZI384LKleuo(u"ࠨ฻าำࠥอไโ์า๎ํํวหࠢไ๎ࠥอไใษษ้ฮࠦวๅฤ้ࠤ์๎ࠠ࠻ࠢࠣࠫắ")+str(ZLWoKIJEyx96uf))
	if ZLWoKIJEyx96uf>=Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"࠷ෑ"):
		aVwGA2kFY6u4m = BjMmX1vNrnzSAf(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,mQNonhS7CV2BXOv(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬẰ"),mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠪห้ฮั็ษ่ะࠥาๅฺࠢๅหห๋ษࠡใํ๋ฬࠦ࠵ࠡใํำ๏๎็ศฬ่๊๊ࠣࠦอัࠣห้ฮั็ษ่ะ๊ࠥ็ศ่่ࠢๆอสࠡใํำ๏๎ࠠ࠯࠰ࠣืํ็๋ࠠไ๋้ࠥอไษำ้ห๊าࠠศๆล๊ࠥฮๅิฯ๋ࠣีํࠠศๆๅหห๋ษࠡ࡞ࡱࡠࡳࠦ็ๅࠢอี๏ีࠠฦำึห้ࠦ็ั้ࠣห้่วว็ฬࠤ็ฮไࠡ็ึั์อࠠฦๆ์ࠤฬ๊ๅษำ่ะ๊ࠥใ๋ࠢํๆํ๋ࠠศๆ่ฬึ๋ฬࠡสไัฺࠦ็ั้ࠣห้็๊ะ์๋๋ฬะࠠภࠣࠤࠫằ"))
		if aVwGA2kFY6u4m==SbjiWeHLQPoazqwp3cODkd7YxVgn(u"࠴ි"):
			xx2MZfsNim4IzFQLUgWkJD7nbXeq = b8Qe150xVaJsnDSv
			for key in list(auEf3hRNpv.keys()):
				xx2MZfsNim4IzFQLUgWkJD7nbXeq += eeN6dTEnkJxI+key
				ssQeuZ2IqP5tD7Xxh = sorted(auEf3hRNpv[key],reverse=DD5cFIejQa2X4BgAu9GWPyJ3tC7,key=lambda yx3ILR46nrfj28Mq95tDAh: yx3ILR46nrfj28Mq95tDAh[LzYQg91SIxDeOGtCKd5])
				for OJLzFcW1bdij5,url in ssQeuZ2IqP5tD7Xxh:
					xx2MZfsNim4IzFQLUgWkJD7nbXeq += eeN6dTEnkJxI+OJLzFcW1bdij5+eiopkn4y9uWDQ5+SgrGWuAHcLKBQMJetb9(url)
				xx2MZfsNim4IzFQLUgWkJD7nbXeq += zI3ROAZtiUq42rE9WDST68(u"ࠫࡡࡴ࡜࡯ࠩẲ")
			import cTGphBXNeH
			ip6CohvO5Tya9mFWVf3JdY1qL = cTGphBXNeH.a53FKP79mzt(QQdAXWBc2GPw(u"ࠬ࡜ࡩࡥࡧࡲࡷࠬẳ"),b8Qe150xVaJsnDSv,DD5cFIejQa2X4BgAu9GWPyJ3tC7,b8Qe150xVaJsnDSv,mmcNLrXtzfpyCkZlvK5VwG2gujh(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡓࡐࡆ࡟࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪẴ"),b8Qe150xVaJsnDSv,xx2MZfsNim4IzFQLUgWkJD7nbXeq)
			if ip6CohvO5Tya9mFWVf3JdY1qL: tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪẵ"),RRIHDFjoW9w7bSfVPhC(u"ࠨฬ่ࠤฬ๊ลาีส่ࠥฮๆอษะࠫẶ"))
			else: tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,Xz3bA2PFENVCUtplu51(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬặ"),BWNPxIG7vqdTy85pjHzUOrK3(u"ࠪๅู๊สࠡ฻่่๏ฯࠠศๆศีุอไࠨẸ"))
		if aVwGA2kFY6u4m!=-qHYIWnOZLPkrQU:
			auEf3hRNpv = {}
			zqbhiLmQfC3VK9Arku(mshLJcKH1fv03yRnDOr4ZT,shC5qBRV2A0lZ(u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧẹ"),TT8Mxv5Wq7nlC9IscdpPUY6(u"࡙ࠬࡉࡕࡇࡖࡣࡊࡘࡒࡐࡔࡖࠫẺ"))
	if auEf3hRNpv: PGudrhJF8iDkSq96XVHEQZYf5L(mshLJcKH1fv03yRnDOr4ZT,HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩẻ"),QQdAXWBc2GPw(u"ࠧࡔࡋࡗࡉࡘࡥࡅࡓࡔࡒࡖࡘ࠭Ẽ"),auEf3hRNpv,t58tnzAgevxkoIOdMFbE2PsD64q0C9)
	return
def MtXriKNGj2(hiQUmpe2E4s6TGWcVl,source):
	bAZ28SMxhtIWmT314,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j,Vw6ELd0ReyubDGkj87FA1Zin = [],[],[],[]
	for ZR1fdSsBJVeLUm9y7rit2CHTKau in hiQUmpe2E4s6TGWcVl[:]:
		zoGU1n2QebPclw8,qMoEVg9n2vGxKpt = ZR1fdSsBJVeLUm9y7rit2CHTKau,zI3ROAZtiUq42rE9WDST68(u"ࠨࠩẽ")
		if ubxGUTt1LraKhVZgpAP(u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪẾ") in ZR1fdSsBJVeLUm9y7rit2CHTKau: zoGU1n2QebPclw8,qMoEVg9n2vGxKpt = ZR1fdSsBJVeLUm9y7rit2CHTKau.split(QQdAXWBc2GPw(u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫế"),qHYIWnOZLPkrQU)
		if zoGU1n2QebPclw8 in Vw6ELd0ReyubDGkj87FA1Zin: continue
		if source==BmePGjS7FxK6kutUM(u"ࠫࡆࡒࡍࡔࡖࡅࡅࠬỀ"): bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = dR3IXFnWwevCsSBiTM1uAl(zoGU1n2QebPclw8)
		elif BWNPxIG7vqdTy85pjHzUOrK3(u"ࠬࡷࡶࡪࡦࠪề") in zoGU1n2QebPclw8: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = dR3IXFnWwevCsSBiTM1uAl(zoGU1n2QebPclw8)
		if KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j:
			hiQUmpe2E4s6TGWcVl.remove(ZR1fdSsBJVeLUm9y7rit2CHTKau)
			oYe8RpT3jO17qBKDLkZd2gCJ = YYBlm36zd0Jst18LXwo4.findall(RRIHDFjoW9w7bSfVPhC(u"࠭࡮ࡢ࡯ࡨࡨࡂ࠴ࠪࡀࡡࡢࠬ࠳࠰࠿ࠪࡡࡢࠫỂ"),ZR1fdSsBJVeLUm9y7rit2CHTKau+shC5qBRV2A0lZ(u"ࠧࡠࡡࠪể"),YYBlm36zd0Jst18LXwo4.DOTALL)
			oYe8RpT3jO17qBKDLkZd2gCJ = oYe8RpT3jO17qBKDLkZd2gCJ[UUkIBz1sgQ9WfNeG6trKXvu0(u"࠴ී")] if oYe8RpT3jO17qBKDLkZd2gCJ else Mmpr0o76iWJvz1kTtfgI8hES(u"ࠨࠩỄ")
			for HoXz65T8ph1CMeZgF,eiFs3pQPyZtjb0W in zip(uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j):
				if eiFs3pQPyZtjb0W in Vw6ELd0ReyubDGkj87FA1Zin: continue
				Vw6ELd0ReyubDGkj87FA1Zin.append(eiFs3pQPyZtjb0W)
				eiFs3pQPyZtjb0W = eiFs3pQPyZtjb0W+vvWwO3Tx2dAgcijrFXq(u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪễ")+HoXz65T8ph1CMeZgF+Xz3bA2PFENVCUtplu51(u"ࠪࡣࡤ࠭Ệ")+oYe8RpT3jO17qBKDLkZd2gCJ
				bAZ28SMxhtIWmT314.append(eiFs3pQPyZtjb0W)
	return hiQUmpe2E4s6TGWcVl+bAZ28SMxhtIWmT314
def nqu2GCT9gHAbpIPSFZz5(n92bB0YwDLqyadQRlmGW,source,E57WK4m31C8,url):
	if not n92bB0YwDLqyadQRlmGW:
		PSmWeXc21CIaUOi3rAu5Zwz8s9vkM(source,E57WK4m31C8,url)
		return
	n92bB0YwDLqyadQRlmGW = MtXriKNGj2(n92bB0YwDLqyadQRlmGW,source)
	n92bB0YwDLqyadQRlmGW = list(set(n92bB0YwDLqyadQRlmGW))
	uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = KkyD5Cxmzj48L27XQsAwMYEvNUI(n92bB0YwDLqyadQRlmGW,source)
	if XrloM5pTyK.resolveonly:
		AdXon6zeR7EGx = IIiGp42rjXOqaUFnVtSBZhELs3Dx0(uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j,source,DD5cFIejQa2X4BgAu9GWPyJ3tC7)
		return
	y19yC6zku4pb7SmsElVQdIXr,bqCG6DEkf705Z9enS4pmN2,c19oGFSd4rpMPmksgKlWV3XQ7,AdXon6zeR7EGx,qbgKrowBEldjpDaYGNsT91SA0ZUWI,tgoJCpq8KGrdaUSjsLh0FTxDRPfIAB = DD5cFIejQa2X4BgAu9GWPyJ3tC7,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,[],b8Qe150xVaJsnDSv,[]
	XjDKsClQudp7ZiMm2N9vog4F5 = not any(Y8aiFZsLKw in source for Y8aiFZsLKw in S8Czlw0Fthk)
	if XjDKsClQudp7ZiMm2N9vog4F5:
		g5S4iLCbcWvwaFnu = LzYQg91SIxDeOGtCKd5
		IJ6y2uz1w4cOoRbntC = SS2OK7hjLagvUAm(mshLJcKH1fv03yRnDOr4ZT,Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠫࡱ࡯ࡳࡵࠩệ"),Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡊ࡟ࡔࡗࡆࡇࡊࡋࡄࡆࡆࠪỈ"))
		A9OGmltypjdB0I2eMWKahDqTQ3Zf = SS2OK7hjLagvUAm(mshLJcKH1fv03yRnDOr4ZT,shC5qBRV2A0lZ(u"࠭࡬ࡪࡵࡷࠫỉ"),dDYUoKi6JFM23p(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡅࡡࡉࡅࡎࡒࡅࡅࠩỊ"))
		JZMvR4mp2rX7Kf6n = LzYQg91SIxDeOGtCKd5
		for title,pcA1dzy7LXwGfMPg9mTkuh5tine3 in zip(uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j):
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3.split(SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩị"),qHYIWnOZLPkrQU)[LzYQg91SIxDeOGtCKd5]
			if pcA1dzy7LXwGfMPg9mTkuh5tine3 in IJ6y2uz1w4cOoRbntC:
				g5S4iLCbcWvwaFnu += qHYIWnOZLPkrQU
				uuSKUinvP4EGLxWZYmTsF[JZMvR4mp2rX7Kf6n] = Vx5N0eIvPChf6SyXiMz+title+hAIp8kmC36T5WFPMSXOwnNbtD
			elif pcA1dzy7LXwGfMPg9mTkuh5tine3 in A9OGmltypjdB0I2eMWKahDqTQ3Zf:
				g5S4iLCbcWvwaFnu += qHYIWnOZLPkrQU
				uuSKUinvP4EGLxWZYmTsF[JZMvR4mp2rX7Kf6n] = rC3Tlno96KjLDIvBaSWUbR8+title+hAIp8kmC36T5WFPMSXOwnNbtD
			JZMvR4mp2rX7Kf6n += qHYIWnOZLPkrQU
		tgoJCpq8KGrdaUSjsLh0FTxDRPfIAB = [OkuB9nwhD8U1+BmePGjS7FxK6kutUM(u"ࠩไัฺࠦฬๆ์฼ࠤฬ๊ำ๋ำไีฬะࠧỌ")+hAIp8kmC36T5WFPMSXOwnNbtD]
	else: qbgKrowBEldjpDaYGNsT91SA0ZUWI = OkuB9nwhD8U1+mQNonhS7CV2BXOv(u"ࠪวำะัࠡษ็ื๏ืแาࠢส่๊์วิสࠪọ")+hAIp8kmC36T5WFPMSXOwnNbtD
	SxJIWAMj86cQms5agzf0 = hRWC8YSFvsm4JHOMVIne3jquZ.getSetting(BWNPxIG7vqdTy85pjHzUOrK3(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡣ࡫ࡷࡶࡦࡺࡥࠨỎ"))
	aawe1hV3nbEX7YqO = TYf7Dc06PQgy1vEV9(u"ࠬ࠳ࠧỏ") not in SxJIWAMj86cQms5agzf0
	while CCxMXuNUEzolDZTKrBJ:
		N1f5IKMQ0UrRqSHke2lX7jma = CCxMXuNUEzolDZTKrBJ
		if XjDKsClQudp7ZiMm2N9vog4F5:
			if aawe1hV3nbEX7YqO and len(uuSKUinvP4EGLxWZYmTsF)==qHYIWnOZLPkrQU: cMZGTsAR2E = qHYIWnOZLPkrQU
			else:
				UUmlFJ3pseHaNOZVyWrhP76qu = str(uuSKUinvP4EGLxWZYmTsF).count(Vx5N0eIvPChf6SyXiMz)
				VPlyT6XY5cxQsKu = str(uuSKUinvP4EGLxWZYmTsF).count(rC3Tlno96KjLDIvBaSWUbR8)
				wv3lQrX2Uuqm = len(uuSKUinvP4EGLxWZYmTsF)-UUmlFJ3pseHaNOZVyWrhP76qu-VPlyT6XY5cxQsKu
				if hDTluNxe7tCwrpqXHzdEcYRfbs: qbgKrowBEldjpDaYGNsT91SA0ZUWI = rC3Tlno96KjLDIvBaSWUbR8+QTUBCcehw6qPd4x(u"࠭ࠠࠡࠢึ๎หฯ࠺ࠨỐ")+str(VPlyT6XY5cxQsKu)+hAIp8kmC36T5WFPMSXOwnNbtD+LAQD5wEkr18bUiGaYen3J(u"้ࠧࠡࠢࠣัํ่ๅห࠽ࠫố")+str(wv3lQrX2Uuqm)+Vx5N0eIvPChf6SyXiMz+HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠨฮํำฮࡀࠧỒ")+str(UUmlFJ3pseHaNOZVyWrhP76qu)+hAIp8kmC36T5WFPMSXOwnNbtD
				else: qbgKrowBEldjpDaYGNsT91SA0ZUWI = Vx5N0eIvPChf6SyXiMz+yST5AHEfvPmcWpwGuh2BJ(u"ࠩฯ๎ิฯ࠺ࠨồ")+str(UUmlFJ3pseHaNOZVyWrhP76qu)+hAIp8kmC36T5WFPMSXOwnNbtD+VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠪࠤࠥࠦๅอ้๋่ฮࡀࠧỔ")+str(wv3lQrX2Uuqm)+rC3Tlno96KjLDIvBaSWUbR8+zI3ROAZtiUq42rE9WDST68(u"ࠫࠥࠦࠠิ์ษอ࠿࠭ổ")+str(VPlyT6XY5cxQsKu)+hAIp8kmC36T5WFPMSXOwnNbtD
				cMZGTsAR2E = XXprCMzuNP2mElUxfdA(qbgKrowBEldjpDaYGNsT91SA0ZUWI,tgoJCpq8KGrdaUSjsLh0FTxDRPfIAB+uuSKUinvP4EGLxWZYmTsF)
			if cMZGTsAR2E==LzYQg91SIxDeOGtCKd5:
				N1f5IKMQ0UrRqSHke2lX7jma = DD5cFIejQa2X4BgAu9GWPyJ3tC7
				start,end = LzYQg91SIxDeOGtCKd5,len(uuSKUinvP4EGLxWZYmTsF)-qHYIWnOZLPkrQU
				AdXon6zeR7EGx = IIiGp42rjXOqaUFnVtSBZhELs3Dx0(uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j,source,CCxMXuNUEzolDZTKrBJ)
				c19oGFSd4rpMPmksgKlWV3XQ7 = SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠬࡸࡥࡴࡱ࡯ࡺࡪࡪ࡟ࡢ࡮࡯ࠫỖ") if AdXon6zeR7EGx else kke1PDGRBLuY8y(u"࠭࡮ࡰࡶࡢࡶࡪࡹ࡯࡭ࡸࡤࡦࡱ࡫ࠧỗ")
			elif cMZGTsAR2E>LzYQg91SIxDeOGtCKd5: start,end = cMZGTsAR2E-qHYIWnOZLPkrQU,cMZGTsAR2E-qHYIWnOZLPkrQU
		else:
			if aawe1hV3nbEX7YqO and len(uuSKUinvP4EGLxWZYmTsF)==qHYIWnOZLPkrQU: cMZGTsAR2E = LzYQg91SIxDeOGtCKd5
			else: cMZGTsAR2E = XXprCMzuNP2mElUxfdA(qbgKrowBEldjpDaYGNsT91SA0ZUWI,uuSKUinvP4EGLxWZYmTsF)
			start,end = cMZGTsAR2E,cMZGTsAR2E
		if cMZGTsAR2E==-qHYIWnOZLPkrQU:
			c19oGFSd4rpMPmksgKlWV3XQ7 = RRIHDFjoW9w7bSfVPhC(u"ࠧࡤࡣࡱࡧࡪࡲࡥࡥࠩỘ")
			break
		if N1f5IKMQ0UrRqSHke2lX7jma:
			c19oGFSd4rpMPmksgKlWV3XQ7 = QTUBCcehw6qPd4x(u"ࠨࡴࡨࡷࡴࡲࡶࡦࡦࡢࡳࡳ࡫ࠧộ")
			AdXon6zeR7EGx = IIiGp42rjXOqaUFnVtSBZhELs3Dx0([uuSKUinvP4EGLxWZYmTsF[start]],[KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j[start]],source,CCxMXuNUEzolDZTKrBJ)
			title,pcA1dzy7LXwGfMPg9mTkuh5tine3,bqCG6DEkf705Z9enS4pmN2,YRtyADTLUrGc,tzdvaEpMHOCZLXDYg08T = AdXon6zeR7EGx[LzYQg91SIxDeOGtCKd5]
			bfog7xK6hEWjOJRpIXSy2uZAM,rRmglCLye5p7uOUq4GZP9coHf3t = zZtQy08d1HFTi2qnUKYvjJLurNDp(title,pcA1dzy7LXwGfMPg9mTkuh5tine3,YRtyADTLUrGc,tzdvaEpMHOCZLXDYg08T,source,E57WK4m31C8)
			if bfog7xK6hEWjOJRpIXSy2uZAM in [UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧ࡭ࡳ࡭ࠧỚ"),HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠪࡴࡱࡧࡹࡪࡰࡪࠫớ"),Xz3bA2PFENVCUtplu51(u"ࠫࡹ࡫ࡳࡵ࡫ࡱ࡫ࠬỜ")]:
				y19yC6zku4pb7SmsElVQdIXr = CCxMXuNUEzolDZTKrBJ
				break
			else:
				if not bqCG6DEkf705Z9enS4pmN2: bqCG6DEkf705Z9enS4pmN2 = S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠬ࡜ࡩࡥࡧࡲࠤࡵࡲࡡࡺࠢࡩࡥ࡮ࡲࡥࡥࠩờ")
				title = rC3Tlno96KjLDIvBaSWUbR8+title+hAIp8kmC36T5WFPMSXOwnNbtD
				AdXon6zeR7EGx[LzYQg91SIxDeOGtCKd5] = title,pcA1dzy7LXwGfMPg9mTkuh5tine3,bqCG6DEkf705Z9enS4pmN2,YRtyADTLUrGc,tzdvaEpMHOCZLXDYg08T
				WTutML3fbjNhp0cayg6oRPOl = pcA1dzy7LXwGfMPg9mTkuh5tine3.split(HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧỞ"),qHYIWnOZLPkrQU)[LzYQg91SIxDeOGtCKd5]
				zqbhiLmQfC3VK9Arku(mshLJcKH1fv03yRnDOr4ZT,HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡅࡡࡖ࡙ࡈࡉࡅࡆࡆࡈࡈࠬở"),WTutML3fbjNhp0cayg6oRPOl)
				PGudrhJF8iDkSq96XVHEQZYf5L(mshLJcKH1fv03yRnDOr4ZT,Xz3bA2PFENVCUtplu51(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡆࡢࡊࡆࡏࡌࡆࡆࠪỠ"),WTutML3fbjNhp0cayg6oRPOl,[bqCG6DEkf705Z9enS4pmN2,title,pcA1dzy7LXwGfMPg9mTkuh5tine3],GMkNL1RXxKFentp0Zh9d)
			if bqCG6DEkf705Z9enS4pmN2==QTUBCcehw6qPd4x(u"ࠩࡈ࡜ࡎ࡚࡟ࡂࡎࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧỡ"): break
			SoHpkrjLnzxKMPAOb = DYakr9g4PVU(u"ࠪ࡟ࡑࡋࡆࡕ࡟ࠣࠤࠬỢ")+bqCG6DEkf705Z9enS4pmN2.replace(eeN6dTEnkJxI,TYf7Dc06PQgy1vEV9(u"ࠫࡡࡴ࡛ࡍࡇࡉࡘࡢࠦࠠࠨợ")) if bqCG6DEkf705Z9enS4pmN2.count(eeN6dTEnkJxI)>yST5AHEfvPmcWpwGuh2BJ(u"࠸ු") else eeN6dTEnkJxI+bqCG6DEkf705Z9enS4pmN2
			if Mmpr0o76iWJvz1kTtfgI8hES(u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭Ụ") not in source: tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,uVQd103XyvUce2EBtzbYaC(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩụ"),mQNonhS7CV2BXOv(u"ࠧศๆึ๎ึ็ัࠡๆ่ࠤ๏฿ๅๅࠢฯีอࠦำ๋ำไีࠥเ๊า้ࠪỦ")+eeN6dTEnkJxI+SoHpkrjLnzxKMPAOb,profile=Nh0BWuiSndf(u"ࠨࡥࡲࡲ࡫࡯ࡲ࡮ࡡࡰࡩࡩ࡯ࡵ࡮ࡨࡲࡲࡹ࠭ủ"))
			if len(KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j)==qHYIWnOZLPkrQU and bqCG6DEkf705Z9enS4pmN2: break
		for JZMvR4mp2rX7Kf6n in range(start,end+qHYIWnOZLPkrQU):
			crLB2QgWyjCi8YZxFmElDNs = LzYQg91SIxDeOGtCKd5 if N1f5IKMQ0UrRqSHke2lX7jma else JZMvR4mp2rX7Kf6n
			title,pcA1dzy7LXwGfMPg9mTkuh5tine3,bqCG6DEkf705Z9enS4pmN2,YRtyADTLUrGc,tzdvaEpMHOCZLXDYg08T = AdXon6zeR7EGx[crLB2QgWyjCi8YZxFmElDNs]
			uuSKUinvP4EGLxWZYmTsF[JZMvR4mp2rX7Kf6n] = uuSKUinvP4EGLxWZYmTsF[JZMvR4mp2rX7Kf6n].replace(rC3Tlno96KjLDIvBaSWUbR8,b8Qe150xVaJsnDSv).replace(Vx5N0eIvPChf6SyXiMz,b8Qe150xVaJsnDSv).replace(hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv)
			if bqCG6DEkf705Z9enS4pmN2: uuSKUinvP4EGLxWZYmTsF[JZMvR4mp2rX7Kf6n] = rC3Tlno96KjLDIvBaSWUbR8+uuSKUinvP4EGLxWZYmTsF[JZMvR4mp2rX7Kf6n]+hAIp8kmC36T5WFPMSXOwnNbtD
			else: uuSKUinvP4EGLxWZYmTsF[JZMvR4mp2rX7Kf6n] = Vx5N0eIvPChf6SyXiMz+uuSKUinvP4EGLxWZYmTsF[JZMvR4mp2rX7Kf6n]+hAIp8kmC36T5WFPMSXOwnNbtD
	if c19oGFSd4rpMPmksgKlWV3XQ7==HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠩࡱࡳࡹࡥࡲࡦࡵࡲࡰࡻࡧࡢ࡭ࡧࠪỨ"): tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ứ"),yST5AHEfvPmcWpwGuh2BJ(u"้๊ࠫริใ่ࠣฬ๊้ࠦฮาࠤุ๐ัโำสฮࠥา๊ะหࠣๅ๏ࠦ็ัษࠣห้็๊ะ์๋ࠤ࠳࠴ࠠฮษ๋่ࠥษๆࠡฬหัะูࠦ็๊ࠢิฬࠦวๅใํำ๏๎ࠠโ์้ࠣํอโฺࠢฦาึ๏ࠠโ์๋ࠣีอࠠศๆหี๋อๅอࠩỪ"))
	if not y19yC6zku4pb7SmsElVQdIXr or c19oGFSd4rpMPmksgKlWV3XQ7 in [ubxGUTt1LraKhVZgpAP(u"ࠬࡩࡡ࡯ࡥࡨࡰࡪࡪࠧừ"),TYf7Dc06PQgy1vEV9(u"࠭࡮ࡰࡶࡢࡶࡪࡹ࡯࡭ࡸࡤࡦࡱ࡫ࠧỬ")] or bqCG6DEkf705Z9enS4pmN2:
		pie0DRMAtn = uuxVm0bTwdnCUAL4s6NKHEBF3M.executeJSONRPC(IjZbnrBJmM2N(u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦ࡮ࡪࠢ࠻࠳࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡐ࡭ࡣࡼࡰ࡮ࡹࡴ࠯ࡅ࡯ࡩࡦࡸࠢ࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡶ࡬ࡢࡻ࡯࡭ࡸࡺࡩࡥࠤ࠽࠵ࢂࢃࠧử"))
	return
ssIkizmnZpySOJb14MVuNcUwFGjdh3,Kf2nteDo0v,V7uZ9KaXwopxPhbte,At3RlKLcWFuzjrYUIwQDg,hvtcQJpTWmeonuzVB2kPMqE6,R2IoqgyBkNAGtDrCVMs54 = [],[],[],[],[],[]
def IIiGp42rjXOqaUFnVtSBZhELs3Dx0(zMaDJPY25fQK96VvUBAgxlROmI8,n92bB0YwDLqyadQRlmGW,source,showDialogs):
	global ssIkizmnZpySOJb14MVuNcUwFGjdh3,Kf2nteDo0v,V7uZ9KaXwopxPhbte,At3RlKLcWFuzjrYUIwQDg,hvtcQJpTWmeonuzVB2kPMqE6,R2IoqgyBkNAGtDrCVMs54
	XXxlOLJ9KRjPH382WVCvr6n71,l21gx4o0rcChqRtWXJ6,new = [],[],[]
	PDanwWu4bFAhe3m(DD5cFIejQa2X4BgAu9GWPyJ3tC7,DD5cFIejQa2X4BgAu9GWPyJ3tC7,DD5cFIejQa2X4BgAu9GWPyJ3tC7)
	count = len(n92bB0YwDLqyadQRlmGW)
	for p8R0YcsOIP4KUMEkbVgABZTtN9w in range(count):
		ssIkizmnZpySOJb14MVuNcUwFGjdh3.append(None)
		Kf2nteDo0v.append(None)
		V7uZ9KaXwopxPhbte.append(None)
		At3RlKLcWFuzjrYUIwQDg.append(None)
		hvtcQJpTWmeonuzVB2kPMqE6.append(None)
		R2IoqgyBkNAGtDrCVMs54.append(LzYQg91SIxDeOGtCKd5)
		title = zMaDJPY25fQK96VvUBAgxlROmI8[p8R0YcsOIP4KUMEkbVgABZTtN9w]
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = n92bB0YwDLqyadQRlmGW[p8R0YcsOIP4KUMEkbVgABZTtN9w].strip(pldxivXC5wbTB2O8q).strip(zI3ROAZtiUq42rE9WDST68(u"ࠨࠨࠪỮ")).strip(HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠩࡂࠫữ")).strip(BWNPxIG7vqdTy85pjHzUOrK3(u"ࠪ࠳ࠬỰ"))
		if count>qHYIWnOZLPkrQU and showDialogs: yicQV3gj4q(uVQd103XyvUce2EBtzbYaC(u"ࠫๆำีࠡีํีๆืࠠาไ่ࠤࠥ࠭ự")+str(p8R0YcsOIP4KUMEkbVgABZTtN9w+Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"࠷෕")),title)
		e6pb1YlyL27dzHFqngaIGc = [kke1PDGRBLuY8y(u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭Ỳ"),m6hwdgP31a2zjN7lkpX(u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑࠫỳ"),LAQD5wEkr18bUiGaYen3J(u"ࠧࡂࡍ࡚ࡅࡒ࠭Ỵ")]
		if source in e6pb1YlyL27dzHFqngaIGc: ssIkizmnZpySOJb14MVuNcUwFGjdh3[p8R0YcsOIP4KUMEkbVgABZTtN9w] = ddEQTG1mbD(title,pcA1dzy7LXwGfMPg9mTkuh5tine3,source,p8R0YcsOIP4KUMEkbVgABZTtN9w)
		else:
			if ddo23ZJtgcY(u"࠱ූ"):
				DDqwUifaJTIBrLzyZ = Ay1SMOzkx5CU3aGTL4Zf.Thread(target=ddEQTG1mbD,args=(title,pcA1dzy7LXwGfMPg9mTkuh5tine3,source,p8R0YcsOIP4KUMEkbVgABZTtN9w))
				DDqwUifaJTIBrLzyZ.start()
				l21gx4o0rcChqRtWXJ6.append(DDqwUifaJTIBrLzyZ)
				new.append(p8R0YcsOIP4KUMEkbVgABZTtN9w)
				wLQCTr5lqbsVYeAHdzfhZ1F.sleep(HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"࠲෗"))
	timeout = Xz3bA2PFENVCUtplu51(u"࠸࠳ෘ") if source==ubxGUTt1LraKhVZgpAP(u"ࠨࡃࡎ࡛ࡆࡓࠧỵ") else uVQd103XyvUce2EBtzbYaC(u"࠶࠴ෙ")
	xhWaiNzZPjTfLQV9b7H382ovXrEKBe = wLQCTr5lqbsVYeAHdzfhZ1F.time()
	for DDqwUifaJTIBrLzyZ in l21gx4o0rcChqRtWXJ6: DDqwUifaJTIBrLzyZ.join(timeout)
	for p8R0YcsOIP4KUMEkbVgABZTtN9w in range(count):
		title = zMaDJPY25fQK96VvUBAgxlROmI8[p8R0YcsOIP4KUMEkbVgABZTtN9w]
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = n92bB0YwDLqyadQRlmGW[p8R0YcsOIP4KUMEkbVgABZTtN9w].strip(pldxivXC5wbTB2O8q).strip(zI3ROAZtiUq42rE9WDST68(u"ࠩࠩࠫỶ")).strip(BWNPxIG7vqdTy85pjHzUOrK3(u"ࠪࡃࠬỷ")).strip(mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠫ࠴࠭Ỹ"))
		Tmg2jEyePuQht0 = CCxMXuNUEzolDZTKrBJ if R2IoqgyBkNAGtDrCVMs54[p8R0YcsOIP4KUMEkbVgABZTtN9w]+qHYIWnOZLPkrQU>timeout else DD5cFIejQa2X4BgAu9GWPyJ3tC7
		if ssIkizmnZpySOJb14MVuNcUwFGjdh3[p8R0YcsOIP4KUMEkbVgABZTtN9w] and len(ssIkizmnZpySOJb14MVuNcUwFGjdh3[p8R0YcsOIP4KUMEkbVgABZTtN9w])==QQdAXWBc2GPw(u"࠷ේ") and (ssIkizmnZpySOJb14MVuNcUwFGjdh3[p8R0YcsOIP4KUMEkbVgABZTtN9w][LzYQg91SIxDeOGtCKd5] or ssIkizmnZpySOJb14MVuNcUwFGjdh3[p8R0YcsOIP4KUMEkbVgABZTtN9w][IgQimel18t]): SoHpkrjLnzxKMPAOb,HoXz65T8ph1CMeZgF,eiFs3pQPyZtjb0W = ssIkizmnZpySOJb14MVuNcUwFGjdh3[p8R0YcsOIP4KUMEkbVgABZTtN9w]
		elif Tmg2jEyePuQht0: SoHpkrjLnzxKMPAOb,HoXz65T8ph1CMeZgF,eiFs3pQPyZtjb0W = HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠬࡌࡡࡪ࡮ࡨࡨ࠿ࠦࠠࡕ࡫ࡰࡩࡩࠦࡏࡶࡶࠣࠬࠬỹ")+str(timeout)+DYakr9g4PVU(u"࠭ࠠࡴࡧࡦࡳࡳࡪࡳࠪࠩỺ"),[],[]
		else: SoHpkrjLnzxKMPAOb,HoXz65T8ph1CMeZgF,eiFs3pQPyZtjb0W = BWNPxIG7vqdTy85pjHzUOrK3(u"ࠧࡇࡣ࡬ࡰࡪࡪ࠺ࠡࠢࡆࡳࡺࡲࡤࠡࡰࡲࡸࠥ࡬ࡩ࡯ࡦࠣࡸ࡭࡫ࠠࡷ࡫ࡧࡩࡴࠦࡦࡪ࡮ࡨࠫỻ"),[],[]
		XXxlOLJ9KRjPH382WVCvr6n71.append([title,pcA1dzy7LXwGfMPg9mTkuh5tine3,SoHpkrjLnzxKMPAOb,HoXz65T8ph1CMeZgF,eiFs3pQPyZtjb0W])
		if p8R0YcsOIP4KUMEkbVgABZTtN9w in new:
			WTutML3fbjNhp0cayg6oRPOl = pcA1dzy7LXwGfMPg9mTkuh5tine3.split(QTUBCcehw6qPd4x(u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩỼ"),qHYIWnOZLPkrQU)[LzYQg91SIxDeOGtCKd5]
			if not SoHpkrjLnzxKMPAOb: PGudrhJF8iDkSq96XVHEQZYf5L(mshLJcKH1fv03yRnDOr4ZT,UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡇࡣࡘ࡛ࡃࡄࡇࡈࡈࡊࡊࠧỽ"),WTutML3fbjNhp0cayg6oRPOl,[SoHpkrjLnzxKMPAOb,HoXz65T8ph1CMeZgF,eiFs3pQPyZtjb0W],GMkNL1RXxKFentp0Zh9d)
			else: PGudrhJF8iDkSq96XVHEQZYf5L(mshLJcKH1fv03yRnDOr4ZT,BWNPxIG7vqdTy85pjHzUOrK3(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡈࡤࡌࡁࡊࡎࡈࡈࠬỾ"),WTutML3fbjNhp0cayg6oRPOl,[SoHpkrjLnzxKMPAOb,HoXz65T8ph1CMeZgF,eiFs3pQPyZtjb0W],GMkNL1RXxKFentp0Zh9d)
	PDanwWu4bFAhe3m(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv)
	return XXxlOLJ9KRjPH382WVCvr6n71
def ddEQTG1mbD(LLOCdZ3sS2enzXx4fVB18YRvbHNwky,url,source,iNdb241X5QmGjzfhopLkc0wUgCl6DM):
	global ssIkizmnZpySOJb14MVuNcUwFGjdh3,R2IoqgyBkNAGtDrCVMs54
	R2IoqgyBkNAGtDrCVMs54[iNdb241X5QmGjzfhopLkc0wUgCl6DM] = LzYQg91SIxDeOGtCKd5
	xhWaiNzZPjTfLQV9b7H382ovXrEKBe = wLQCTr5lqbsVYeAHdzfhZ1F.time()
	mwIxD3GBPgLVc2aq9(iebCpLE8fuxTRg,EECz06teoykrNFfq(QQ8pvXNcBfVkP5rRJ7o)+UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠫࠥࠦࠠࡓࡧࡶࡳࡱࡼࡩ࡯ࡩࠣࡷࡹࡧࡲࡵࡧࡧࠤࠥࠦࡓࡦ࡮ࡨࡧࡹ࡫ࡤ࠻ࠢ࡞ࠤࠬỿ")+LLOCdZ3sS2enzXx4fVB18YRvbHNwky+ubxGUTt1LraKhVZgpAP(u"ࠬࠦ࡝ࠡࠢࠣࡓࡷ࡯ࡧࡪࡰࡤࡰ࠿࡛ࠦࠡࠩἀ")+url+zI3ROAZtiUq42rE9WDST68(u"࠭ࠠ࡞ࠩἁ"))
	pcA1dzy7LXwGfMPg9mTkuh5tine3,pku4PVSrUet = url,b8Qe150xVaJsnDSv
	EMiV9oQlX3gts1WhuTGrkvZaUycL4m = IjZbnrBJmM2N(u"ࠧࡊࡐࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࠫἂ")
	bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = ysjXzQUtSR9euol(url,source)
	if bqCG6DEkf705Z9enS4pmN2==IjZbnrBJmM2N(u"ࠨࡇ࡛ࡍ࡙ࡥࡁࡍࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ἃ"):
		ssIkizmnZpySOJb14MVuNcUwFGjdh3[iNdb241X5QmGjzfhopLkc0wUgCl6DM] = Nh0BWuiSndf(u"ࠩࡈ࡜ࡎ࡚࡟ࡂࡎࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧἄ"),[],[]
		R2IoqgyBkNAGtDrCVMs54[iNdb241X5QmGjzfhopLkc0wUgCl6DM] = wLQCTr5lqbsVYeAHdzfhZ1F.time()-xhWaiNzZPjTfLQV9b7H382ovXrEKBe
		return ssIkizmnZpySOJb14MVuNcUwFGjdh3[iNdb241X5QmGjzfhopLkc0wUgCl6DM]
	elif LAQD5wEkr18bUiGaYen3J(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ἅ") in bqCG6DEkf705Z9enS4pmN2:
		pku4PVSrUet = shC5qBRV2A0lZ(u"ࠫࡡࡴࡒࡦࡵࡲࡰࡻ࡫ࡲࠡ࠳࠽ࠤࠥࡔࡥࡦࡦࠣࡉࡽࡺࡥࡳࡰࡤࡰࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠧἆ")
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = w9lxG2adH3CbYQRMpBqzAms(KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j)[LzYQg91SIxDeOGtCKd5]
		EMiV9oQlX3gts1WhuTGrkvZaUycL4m,pku4PVSrUet,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = Dj9lY70NVqcO83aEh(pku4PVSrUet,pcA1dzy7LXwGfMPg9mTkuh5tine3,source,iNdb241X5QmGjzfhopLkc0wUgCl6DM)
		if pku4PVSrUet==LAQD5wEkr18bUiGaYen3J(u"ࠬࡋࡘࡊࡖࡢࡅࡑࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪἇ"):
			R2IoqgyBkNAGtDrCVMs54[iNdb241X5QmGjzfhopLkc0wUgCl6DM] = wLQCTr5lqbsVYeAHdzfhZ1F.time()-xhWaiNzZPjTfLQV9b7H382ovXrEKBe
			return pku4PVSrUet,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j
	elif bqCG6DEkf705Z9enS4pmN2: pku4PVSrUet = SbjiWeHLQPoazqwp3cODkd7YxVgn(u"࠭ࡒࡦࡵࡲࡰࡻ࡫ࡲࠡ࠳࠽ࠤࠥ࠭Ἀ")+bqCG6DEkf705Z9enS4pmN2.replace(eeN6dTEnkJxI,b8Qe150xVaJsnDSv).replace(d6ekSEojpFUANKJ7r9WTlI3niLBOu,b8Qe150xVaJsnDSv)[:HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"࠽࠶ෛ")]
	if KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j:
		KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = w9lxG2adH3CbYQRMpBqzAms(KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j)
		mwIxD3GBPgLVc2aq9(iebCpLE8fuxTRg,EECz06teoykrNFfq(QQ8pvXNcBfVkP5rRJ7o)+vvWwO3Tx2dAgcijrFXq(u"ࠧࠡࠢࠣࡖࡪࡹ࡯࡭ࡸ࡬ࡲ࡬ࠦࡳࡶࡥࡦࡩࡪࡪࡥࡥࠢࠣࠤࡘ࡫࡬ࡦࡥࡷࡩࡩࡀࠠ࡜ࠢࠪἉ")+LLOCdZ3sS2enzXx4fVB18YRvbHNwky+TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠨࠢࡠࠤࠥࠦࡒࡦࡵࡲࡰࡻ࡫ࡲ࠻ࠢ࡞ࠤࠬἊ")+EMiV9oQlX3gts1WhuTGrkvZaUycL4m+S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠩࠣࡡࠥࠦࠠࡐࡴ࡬࡫࡮ࡴࡡ࡭࠼ࠣ࡟ࠥ࠭Ἃ")+url+Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠪࠤࡢࠦࠠࠡࡎ࡬ࡲࡰࡀࠠ࡜ࠢࠪἌ")+pcA1dzy7LXwGfMPg9mTkuh5tine3+HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠫࠥࡣ࡙ࠠࠡࠢ࡭ࡩ࡫࡯ࡴ࠼ࠣ࡟ࠥ࠭Ἅ")+str(KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j)+LAQD5wEkr18bUiGaYen3J(u"ࠬࠦ࡝ࠨἎ"))
	else: mwIxD3GBPgLVc2aq9(iebCpLE8fuxTRg,EECz06teoykrNFfq(QQ8pvXNcBfVkP5rRJ7o)+shC5qBRV2A0lZ(u"࠭ࠠࠡࠢࡕࡩࡸࡵ࡬ࡷ࡫ࡱ࡫ࠥ࡬ࡡࡪ࡮ࡨࡨࠥࠦࠠࡔࡧ࡯ࡩࡨࡺࡥࡥ࠼ࠣ࡟ࠥ࠭Ἇ")+LLOCdZ3sS2enzXx4fVB18YRvbHNwky+DYakr9g4PVU(u"ࠧࠡ࡟ࠣࠤࠥࡕࡲࡪࡩ࡬ࡲࡦࡲ࠺ࠡ࡝ࠣࠫἐ")+url+mQNonhS7CV2BXOv(u"ࠨࠢࡠࠤࠥࠦࡌࡪࡰ࡮࠾ࠥࡡࠠࠨἑ")+pcA1dzy7LXwGfMPg9mTkuh5tine3+shC5qBRV2A0lZ(u"ࠩࠣࡡࠥࠦࠠࡆࡴࡵࡳࡷࡹ࠺ࠡ࡝ࠣࠫἒ")+pku4PVSrUet+QTUBCcehw6qPd4x(u"ࠪࠤࡢ࠭ἓ"))
	pku4PVSrUet = SgrGWuAHcLKBQMJetb9(pku4PVSrUet)
	ssIkizmnZpySOJb14MVuNcUwFGjdh3[iNdb241X5QmGjzfhopLkc0wUgCl6DM] = pku4PVSrUet,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j
	R2IoqgyBkNAGtDrCVMs54[iNdb241X5QmGjzfhopLkc0wUgCl6DM] = wLQCTr5lqbsVYeAHdzfhZ1F.time()-xhWaiNzZPjTfLQV9b7H382ovXrEKBe
	return pku4PVSrUet,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j
def zZtQy08d1HFTi2qnUKYvjJLurNDp(title,pcA1dzy7LXwGfMPg9mTkuh5tine3,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j,source,E57WK4m31C8=b8Qe150xVaJsnDSv):
	if KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j:
		if not uuSKUinvP4EGLxWZYmTsF[dDYUoKi6JFM23p(u"࠶ො")]: uuSKUinvP4EGLxWZYmTsF = KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j
		SxJIWAMj86cQms5agzf0 = hRWC8YSFvsm4JHOMVIne3jquZ.getSetting(ddo23ZJtgcY(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡣ࡫ࡷࡶࡦࡺࡥࠨἔ"))
		aawe1hV3nbEX7YqO = TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠬ࠳ࠧἕ") not in SxJIWAMj86cQms5agzf0
		while CCxMXuNUEzolDZTKrBJ:
			if aawe1hV3nbEX7YqO and len(KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j)==qHYIWnOZLPkrQU: cMZGTsAR2E = LzYQg91SIxDeOGtCKd5
			else: cMZGTsAR2E = XXprCMzuNP2mElUxfdA(Nh0BWuiSndf(u"࠭วฯฬิࠤฬ๊ๅๅใࠣห้๋ๆศีห࠾ࠬ἖"), uuSKUinvP4EGLxWZYmTsF)
			if cMZGTsAR2E==-qHYIWnOZLPkrQU: wnsCBgrI9EJtPdyYp3T7bocXF = QTUBCcehw6qPd4x(u"ࠧࡤࡣࡱࡧࡪࡲࡥࡥࠩ἗")
			else:
				xgtypNdv8UlOSBHTY7QGIsRhVuXwWc = KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j[cMZGTsAR2E]
				mwIxD3GBPgLVc2aq9(iebCpLE8fuxTRg,EECz06teoykrNFfq(QQ8pvXNcBfVkP5rRJ7o)+dDYUoKi6JFM23p(u"ࠨࠢࠣࠤࡕࡲࡡࡺ࡫ࡱ࡫ࠥࡹࡴࡢࡴࡷࡩࡩࠦࠠࠡࡕࡨࡰࡪࡩࡴࡦࡦ࠽ࠤࡠࠦࠧἘ")+title+vvWwO3Tx2dAgcijrFXq(u"ࠩࠣࡡࠥࠦࠠࡐࡴ࡬࡫࡮ࡴࡡ࡭࠼ࠣ࡟ࠥ࠭Ἑ")+pcA1dzy7LXwGfMPg9mTkuh5tine3+SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠪࠤࡢࠦࠠࠡࡘ࡬ࡨࡪࡵ࠺ࠡ࡝ࠣࠫἚ")+str(xgtypNdv8UlOSBHTY7QGIsRhVuXwWc)+TYf7Dc06PQgy1vEV9(u"ࠫࠥࡣࠧἛ"))
				if P0qdZI384LKleuo(u"ࠬࡳ࡯ࡴࡪࡤ࡬ࡩࡧ࠮ࠨἜ") in xgtypNdv8UlOSBHTY7QGIsRhVuXwWc and QQdAXWBc2GPw(u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤࡠࡱࡵ࡭࡬࠭Ἕ") in xgtypNdv8UlOSBHTY7QGIsRhVuXwWc:
					SoHpkrjLnzxKMPAOb,vvnQALE5cIPDKXWxUktGwg,BB6xwqVdZC13JQPujR2sUtz = mTrHl15VxQFAqCX(xgtypNdv8UlOSBHTY7QGIsRhVuXwWc)
					if BB6xwqVdZC13JQPujR2sUtz: xgtypNdv8UlOSBHTY7QGIsRhVuXwWc = BB6xwqVdZC13JQPujR2sUtz[LzYQg91SIxDeOGtCKd5]
					else: xgtypNdv8UlOSBHTY7QGIsRhVuXwWc = b8Qe150xVaJsnDSv
				if not xgtypNdv8UlOSBHTY7QGIsRhVuXwWc: wnsCBgrI9EJtPdyYp3T7bocXF = shC5qBRV2A0lZ(u"ࠧࡶࡰࡵࡩࡸࡵ࡬ࡷࡧࡧࠫ἞")
				else: wnsCBgrI9EJtPdyYp3T7bocXF = yulQjIFbzM(xgtypNdv8UlOSBHTY7QGIsRhVuXwWc,source,E57WK4m31C8)
			if wnsCBgrI9EJtPdyYp3T7bocXF in [uVQd103XyvUce2EBtzbYaC(u"ࠨࡲ࡯ࡥࡾ࡯࡮ࡨࠩ἟"),zI3ROAZtiUq42rE9WDST68(u"ࠩࡷࡩࡸࡺࡩ࡯ࡩࠪἠ"),dDYUoKi6JFM23p(u"ࠪࡨࡴࡽ࡮࡭ࡱࡤࡨ࡮ࡴࡧࠨἡ"),zI3ROAZtiUq42rE9WDST68(u"ࠫࡨࡧ࡮ࡤࡧ࡯ࡩࡩ࠭ἢ")] or len(KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j)==Xz3bA2PFENVCUtplu51(u"࠱ෝ"): break
			elif wnsCBgrI9EJtPdyYp3T7bocXF in [IjZbnrBJmM2N(u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬἣ"),TT8Mxv5Wq7nlC9IscdpPUY6(u"࠭ࡴࡪ࡯ࡨࡳࡺࡺࠧἤ"),VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠧࡵࡴ࡬ࡩࡩ࠭ἥ")]: break
			else: tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,Mmpr0o76iWJvz1kTtfgI8hES(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫἦ"),HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠩส่๊๊แࠡๆ่ࠤ๏฿ๅๅࠢฯีอࠦๅๅใࠣ฾๏ื็ࠨἧ"))
	else:
		wnsCBgrI9EJtPdyYp3T7bocXF = LAQD5wEkr18bUiGaYen3J(u"ࠪࡹࡳࡸࡥࡴࡱ࡯ࡺࡪࡪࠧἨ")
		if Gz7MH0glBw8Eb(pcA1dzy7LXwGfMPg9mTkuh5tine3): wnsCBgrI9EJtPdyYp3T7bocXF = yulQjIFbzM(pcA1dzy7LXwGfMPg9mTkuh5tine3,source,E57WK4m31C8)
	return wnsCBgrI9EJtPdyYp3T7bocXF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j
def K5dQxkb9qnGPaWM2jNERIyDCg41Z(url,source):
	MUJCtfYVBLODrFbaZn,pXJvBb4nkuZDqAGFlorOML,LLOCdZ3sS2enzXx4fVB18YRvbHNwky,iiKm9uPnofhLXGktjHVFdAI1,c17XeRIH2gVh3px8sw,E57WK4m31C8,UYat1jqNzCdDlWGuPF60T9i,c1EdszLx3mkb8QYX9,JVrK4ste3qUM9iy2mNIgdXHhcSwQP6 = url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv
	if UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬἩ") in url:
		MUJCtfYVBLODrFbaZn,pXJvBb4nkuZDqAGFlorOML = url.split(IjZbnrBJmM2N(u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭Ἢ"),qHYIWnOZLPkrQU)
		pXJvBb4nkuZDqAGFlorOML = pXJvBb4nkuZDqAGFlorOML+P0qdZI384LKleuo(u"࠭࡟ࡠࠩἫ")+zI3ROAZtiUq42rE9WDST68(u"ࠧࡠࡡࠪἬ")+BmePGjS7FxK6kutUM(u"ࠨࡡࡢࠫἭ")+uVQd103XyvUce2EBtzbYaC(u"ࠩࡢࡣࠬἮ")+BmePGjS7FxK6kutUM(u"ࠪࡣࡤ࠭Ἧ")
		c17XeRIH2gVh3px8sw,E57WK4m31C8,UYat1jqNzCdDlWGuPF60T9i,c1EdszLx3mkb8QYX9,JVrK4ste3qUM9iy2mNIgdXHhcSwQP6,dM73wSoBq80FpIXY6Pb1mTAZyue, = pXJvBb4nkuZDqAGFlorOML.split(UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠫࡤࡥࠧἰ"))[:P0qdZI384LKleuo(u"࠷ෞ")]
	if not c1EdszLx3mkb8QYX9: c1EdszLx3mkb8QYX9 = LAQD5wEkr18bUiGaYen3J(u"ࠬ࠶ࠧἱ")
	else: c1EdszLx3mkb8QYX9 = c1EdszLx3mkb8QYX9.replace(S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"࠭ࡰࠨἲ"),b8Qe150xVaJsnDSv).replace(pldxivXC5wbTB2O8q,b8Qe150xVaJsnDSv)
	MUJCtfYVBLODrFbaZn = MUJCtfYVBLODrFbaZn.strip(Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠧࡀࠩἳ")).strip(Xz3bA2PFENVCUtplu51(u"ࠨ࠱ࠪἴ")).strip(mQNonhS7CV2BXOv(u"ࠩࠩࠫἵ"))
	LLOCdZ3sS2enzXx4fVB18YRvbHNwky = Wl2eu1PavfQ(MUJCtfYVBLODrFbaZn,RRIHDFjoW9w7bSfVPhC(u"ࠪ࡬ࡴࡹࡴࠨἶ"))
	if c17XeRIH2gVh3px8sw: iiKm9uPnofhLXGktjHVFdAI1 = c17XeRIH2gVh3px8sw
	else: iiKm9uPnofhLXGktjHVFdAI1 = LLOCdZ3sS2enzXx4fVB18YRvbHNwky
	iiKm9uPnofhLXGktjHVFdAI1 = Wl2eu1PavfQ(iiKm9uPnofhLXGktjHVFdAI1,mQNonhS7CV2BXOv(u"ࠫࡳࡧ࡭ࡦࠩἷ"))
	c17XeRIH2gVh3px8sw = c17XeRIH2gVh3px8sw.replace(BWNPxIG7vqdTy85pjHzUOrK3(u"๋ࠬศศึิࠫἸ"),b8Qe150xVaJsnDSv).replace(uVQd103XyvUce2EBtzbYaC(u"࠭ำ๋ำไีࠬἹ"),b8Qe150xVaJsnDSv).replace(vvWwO3Tx2dAgcijrFXq(u"ࠧศๆࠣࠫἺ"),pldxivXC5wbTB2O8q).replace(k5bCDErUSmv,pldxivXC5wbTB2O8q)
	pXJvBb4nkuZDqAGFlorOML = pXJvBb4nkuZDqAGFlorOML.replace(VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠨ็หหูืࠧἻ"),b8Qe150xVaJsnDSv).replace(Mmpr0o76iWJvz1kTtfgI8hES(u"ࠩึ๎ึ็ัࠨἼ"),b8Qe150xVaJsnDSv).replace(Mmpr0o76iWJvz1kTtfgI8hES(u"ࠪห้ࠦࠧἽ"),pldxivXC5wbTB2O8q).replace(k5bCDErUSmv,pldxivXC5wbTB2O8q)
	iiKm9uPnofhLXGktjHVFdAI1 = iiKm9uPnofhLXGktjHVFdAI1.replace(kke1PDGRBLuY8y(u"๊ࠫฮวีำࠪἾ"),b8Qe150xVaJsnDSv).replace(uVQd103XyvUce2EBtzbYaC(u"ู๊ࠬาใิࠫἿ"),b8Qe150xVaJsnDSv).replace(Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"࠭วๅࠢࠪὀ"),pldxivXC5wbTB2O8q).replace(k5bCDErUSmv,pldxivXC5wbTB2O8q)
	return MUJCtfYVBLODrFbaZn,pXJvBb4nkuZDqAGFlorOML,LLOCdZ3sS2enzXx4fVB18YRvbHNwky,iiKm9uPnofhLXGktjHVFdAI1,c17XeRIH2gVh3px8sw,E57WK4m31C8,UYat1jqNzCdDlWGuPF60T9i,c1EdszLx3mkb8QYX9,JVrK4ste3qUM9iy2mNIgdXHhcSwQP6
def McvYKS1wxIW(url,source):
	uRzobLkq3vC7sxcKVZtger58Od,c17XeRIH2gVh3px8sw,fXPHo5vUMiEeAzcsyV3ObSw,ebmgnU3IGCVA7Dx,O2fJR0pZ5TPErmcIsMjlVYk7,qMoEVg9n2vGxKpt,EMiV9oQlX3gts1WhuTGrkvZaUycL4m = b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,None,None,None,None,None
	MUJCtfYVBLODrFbaZn,pXJvBb4nkuZDqAGFlorOML,LLOCdZ3sS2enzXx4fVB18YRvbHNwky,iiKm9uPnofhLXGktjHVFdAI1,c17XeRIH2gVh3px8sw,E57WK4m31C8,UYat1jqNzCdDlWGuPF60T9i,c1EdszLx3mkb8QYX9,JVrK4ste3qUM9iy2mNIgdXHhcSwQP6 = K5dQxkb9qnGPaWM2jNERIyDCg41Z(url,source)
	if S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨὁ") in url:
		if   E57WK4m31C8==uVQd103XyvUce2EBtzbYaC(u"ࠨࡧࡰࡦࡪࡪࠧὂ"): E57WK4m31C8 = pldxivXC5wbTB2O8q+VFjQx6Is28KvzLOmMXtg4GqTwa3(u"่ࠩๅ฻๊ࠧὃ")
		elif E57WK4m31C8==TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠪࡻࡦࡺࡣࡩࠩὄ"): E57WK4m31C8 = pldxivXC5wbTB2O8q+Nh0BWuiSndf(u"๋ࠫࠪิศ้าอࠬὅ")
		elif E57WK4m31C8==QTUBCcehw6qPd4x(u"ࠬࡨ࡯ࡵࡪࠪ὆"): E57WK4m31C8 = pldxivXC5wbTB2O8q+LAQD5wEkr18bUiGaYen3J(u"࠭ࠥࠦ็ืห์ีษ๊ࠡอั๊๐ไࠨ὇")
		elif E57WK4m31C8==m6hwdgP31a2zjN7lkpX(u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥࠩὈ"): E57WK4m31C8 = pldxivXC5wbTB2O8q+TYf7Dc06PQgy1vEV9(u"ࠨࠧࠨࠩฯำๅ๋ๆࠪὉ")
		elif E57WK4m31C8==b8Qe150xVaJsnDSv: E57WK4m31C8 = pldxivXC5wbTB2O8q+QQdAXWBc2GPw(u"ࠩࠨࠩࠪࠫࠧὊ")
		if UYat1jqNzCdDlWGuPF60T9i!=b8Qe150xVaJsnDSv:
			if ubxGUTt1LraKhVZgpAP(u"ࠪࡱࡵ࠺ࠧὋ") not in UYat1jqNzCdDlWGuPF60T9i: UYat1jqNzCdDlWGuPF60T9i = DYakr9g4PVU(u"ࠫࠪ࠭Ὄ")+UYat1jqNzCdDlWGuPF60T9i
			UYat1jqNzCdDlWGuPF60T9i = pldxivXC5wbTB2O8q+UYat1jqNzCdDlWGuPF60T9i
		if c1EdszLx3mkb8QYX9!=b8Qe150xVaJsnDSv:
			c1EdszLx3mkb8QYX9 = TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠬࠫࠥࠦࠧࠨࠩࠪࠫࠥࠨὍ")+c1EdszLx3mkb8QYX9
			c1EdszLx3mkb8QYX9 = pldxivXC5wbTB2O8q+c1EdszLx3mkb8QYX9[-Nh0BWuiSndf(u"࠻ෟ"):]
	if   ddo23ZJtgcY(u"࠭ࡁࡌࡑࡄࡑࠬ὎")		in source: qMoEVg9n2vGxKpt	= iiKm9uPnofhLXGktjHVFdAI1
	elif Mmpr0o76iWJvz1kTtfgI8hES(u"ࠧࡂࡍ࡚ࡅࡒ࠭὏")		in source: fXPHo5vUMiEeAzcsyV3ObSw	= ubxGUTt1LraKhVZgpAP(u"ࠨࡣ࡮ࡻࡦࡳࠧὐ")
	elif Mmpr0o76iWJvz1kTtfgI8hES(u"ࠩ࡮ࡥࡹࡱ࡯ࡶࡶࡨࠫὑ")		in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: fXPHo5vUMiEeAzcsyV3ObSw	= iiKm9uPnofhLXGktjHVFdAI1
	elif RRIHDFjoW9w7bSfVPhC(u"ࠪࡴ࡭ࡵࡴࡰࡵ࠱ࡥࡵࡶ࠮ࡨࠩὒ")	in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: fXPHo5vUMiEeAzcsyV3ObSw	= iiKm9uPnofhLXGktjHVFdAI1
	elif shC5qBRV2A0lZ(u"ࠫࡦࡸࡡࡣࡵࡨࡩࡩ࠭ὓ")		in source: fXPHo5vUMiEeAzcsyV3ObSw	= iiKm9uPnofhLXGktjHVFdAI1
	elif VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠬࡧ࡬ࡢࡴࡤࡦࠬὔ")		in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: fXPHo5vUMiEeAzcsyV3ObSw	= iiKm9uPnofhLXGktjHVFdAI1
	elif Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"࠭ࡦࡢࡵࡨࡰࠬὕ")		in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: fXPHo5vUMiEeAzcsyV3ObSw	= iiKm9uPnofhLXGktjHVFdAI1
	elif ubxGUTt1LraKhVZgpAP(u"ࠧࡵ࠹ࡰࡩࡪࡲࠧὖ")		in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: fXPHo5vUMiEeAzcsyV3ObSw	= iiKm9uPnofhLXGktjHVFdAI1
	elif UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠨ࡯ࡲࡺࡸ࠺ࡵࠨὗ")		in c17XeRIH2gVh3px8sw:   fXPHo5vUMiEeAzcsyV3ObSw	= iiKm9uPnofhLXGktjHVFdAI1
	elif shC5qBRV2A0lZ(u"ࠩࡰࡽࡪ࡭ࡹࡷ࡫ࡳࠫ὘")		in c17XeRIH2gVh3px8sw:   fXPHo5vUMiEeAzcsyV3ObSw	= iiKm9uPnofhLXGktjHVFdAI1
	elif HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠪࡪࡦࡰࡥࡳࠩὙ")		in c17XeRIH2gVh3px8sw:   fXPHo5vUMiEeAzcsyV3ObSw	= iiKm9uPnofhLXGktjHVFdAI1
	elif Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠫๆาัࠨ὚")			in c17XeRIH2gVh3px8sw:   fXPHo5vUMiEeAzcsyV3ObSw	= QQdAXWBc2GPw(u"ࠬ࡬ࡡ࡫ࡧࡵࠫὛ")
	elif vvWwO3Tx2dAgcijrFXq(u"࠭แๅีฺ๎๋࠭὜")		in c17XeRIH2gVh3px8sw:   fXPHo5vUMiEeAzcsyV3ObSw	= RRIHDFjoW9w7bSfVPhC(u"ࠧࡱࡣ࡯ࡩࡸࡺࡩ࡯ࡧࠪὝ")
	elif vvWwO3Tx2dAgcijrFXq(u"ࠨࡩࡧࡶ࡮ࡼࡥࠨ὞")		in MUJCtfYVBLODrFbaZn:   fXPHo5vUMiEeAzcsyV3ObSw	= uVQd103XyvUce2EBtzbYaC(u"ࠩࡪࡳࡴ࡭࡬ࡦࠩὟ")
	elif m6hwdgP31a2zjN7lkpX(u"ࠪࡱࡾࡩࡩ࡮ࡣࠪὠ")		in c17XeRIH2gVh3px8sw:   fXPHo5vUMiEeAzcsyV3ObSw	= iiKm9uPnofhLXGktjHVFdAI1
	elif ddo23ZJtgcY(u"ࠫࡼ࡫ࡣࡪ࡯ࡤࠫὡ")		in c17XeRIH2gVh3px8sw:   fXPHo5vUMiEeAzcsyV3ObSw	= iiKm9uPnofhLXGktjHVFdAI1
	elif ddo23ZJtgcY(u"ࠬࡩࡩ࡮ࡣࡱࡳࡼ࠭ὢ")		in c17XeRIH2gVh3px8sw:   fXPHo5vUMiEeAzcsyV3ObSw	= iiKm9uPnofhLXGktjHVFdAI1
	elif DYakr9g4PVU(u"࠭࡮ࡦࡹࡦ࡭ࡲࡧࠧὣ")		in c17XeRIH2gVh3px8sw:   fXPHo5vUMiEeAzcsyV3ObSw	= iiKm9uPnofhLXGktjHVFdAI1
	elif vvWwO3Tx2dAgcijrFXq(u"ࠧࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲࠬὤ")	in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: fXPHo5vUMiEeAzcsyV3ObSw	= iiKm9uPnofhLXGktjHVFdAI1
	elif mQNonhS7CV2BXOv(u"ࠨࡤࡲ࡯ࡷࡧࠧὥ")		in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: fXPHo5vUMiEeAzcsyV3ObSw	= iiKm9uPnofhLXGktjHVFdAI1
	elif S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠩࡷࡺ࡫ࡻ࡮ࠨὦ")		in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: fXPHo5vUMiEeAzcsyV3ObSw	= iiKm9uPnofhLXGktjHVFdAI1
	elif HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠪࡸࡻࡱࡳࡢࠩὧ")		in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: fXPHo5vUMiEeAzcsyV3ObSw	= iiKm9uPnofhLXGktjHVFdAI1
	elif IjZbnrBJmM2N(u"ࠫࡦࡴࡡࡷ࡫ࡧࡾࠬὨ")		in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: fXPHo5vUMiEeAzcsyV3ObSw	= iiKm9uPnofhLXGktjHVFdAI1
	elif VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠬࡹࡨࡰࡱࡩࡴࡷࡵࠧὩ")		in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: fXPHo5vUMiEeAzcsyV3ObSw	= iiKm9uPnofhLXGktjHVFdAI1
	elif LAQD5wEkr18bUiGaYen3J(u"࠭ࡳࡩࡣ࡫࡭ࡩ࠺ࡵࠨὪ")		in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: qMoEVg9n2vGxKpt	= iiKm9uPnofhLXGktjHVFdAI1
	elif shC5qBRV2A0lZ(u"ࠧࡴࡪࡤ࡬ࡪࡪ࠴ࡶࠩὫ")		in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: qMoEVg9n2vGxKpt	= iiKm9uPnofhLXGktjHVFdAI1
	elif DYakr9g4PVU(u"ࠨࡥ࡬ࡱࡦ࠺ࡵࠨὬ")		in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: qMoEVg9n2vGxKpt	= iiKm9uPnofhLXGktjHVFdAI1
	elif dDYUoKi6JFM23p(u"ࠩࡨ࡫ࡾࡴ࡯ࡸࠩὭ")		in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: qMoEVg9n2vGxKpt	= iiKm9uPnofhLXGktjHVFdAI1
	elif BmePGjS7FxK6kutUM(u"ࠪ࡬ࡦࡲࡡࡤ࡫ࡰࡥࠬὮ")		in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: qMoEVg9n2vGxKpt	= iiKm9uPnofhLXGktjHVFdAI1
	elif kke1PDGRBLuY8y(u"ࠫࡨ࡯࡭ࡢࡣࡥࡨࡴ࠭Ὧ")		in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: qMoEVg9n2vGxKpt	= iiKm9uPnofhLXGktjHVFdAI1
	elif mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠬࡸࡥࡥ࡯ࡲࡨࡽ࠭ὰ")	 	in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: fXPHo5vUMiEeAzcsyV3ObSw	= Mmpr0o76iWJvz1kTtfgI8hES(u"࠭ࡲࡦࡦࡰࡳࡩࡾࠧά")
	elif BmePGjS7FxK6kutUM(u"ࠧࡺࡱࡸࡸࡺ࠭ὲ")	 	in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: fXPHo5vUMiEeAzcsyV3ObSw	= dDYUoKi6JFM23p(u"ࠨࡻࡲࡹࡹࡻࡢࡦࠩέ")
	elif HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠩࡼ࠶ࡺ࠴ࡢࡦࠩὴ")	 	in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: fXPHo5vUMiEeAzcsyV3ObSw	= TYf7Dc06PQgy1vEV9(u"ࠪࡽࡴࡻࡴࡶࡤࡨࠫή")
	elif Nh0BWuiSndf(u"ࠫࡪ࡭ࡹ࠮ࡤࡨࡷࡹ࠴࡮ࡦࡶࠪὶ")	in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: fXPHo5vUMiEeAzcsyV3ObSw	= iiKm9uPnofhLXGktjHVFdAI1
	elif RRIHDFjoW9w7bSfVPhC(u"ࠬࡪ࠮ࡦࡩࡼࡦࡪࡹࡴ࠯ࡦࠪί")	in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: fXPHo5vUMiEeAzcsyV3ObSw	= Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"࠭ࡥࡨࡻࡥࡩࡸࡺࡶࡪࡲࠪὸ")
	elif BmePGjS7FxK6kutUM(u"ࠧࡦࡩࡼ࠲ࡧ࡫ࡳࡵࠩό")		in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: fXPHo5vUMiEeAzcsyV3ObSw	= HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠨࡧࡪࡽࡧ࡫ࡳࡵ࠳ࠪὺ")
	elif RRIHDFjoW9w7bSfVPhC(u"ࠩࡨ࡫ࡾࡨࡥࡴࡶࠪύ")		in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: fXPHo5vUMiEeAzcsyV3ObSw	= UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠪࡩ࡬ࡿࡢࡦࡵࡷ࠷ࠬὼ")
	elif mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠫࡲࡵࡳࡩࡣ࡫ࡨࡦ࠭ώ")		in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: fXPHo5vUMiEeAzcsyV3ObSw	= Xz3bA2PFENVCUtplu51(u"ࠬࡳ࡯ࡴࡪࡤ࡬ࡩࡧࠧ὾")
	elif UUkIBz1sgQ9WfNeG6trKXvu0(u"࠭ࡦࡢࡥࡸࡰࡹࡿࡢࡰࡱ࡮ࡷࠬ὿")	in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: fXPHo5vUMiEeAzcsyV3ObSw	= BWNPxIG7vqdTy85pjHzUOrK3(u"ࠧࡧࡣࡦࡹࡱࡺࡹࡣࡱࡲ࡯ࡸ࠭ᾀ")
	elif UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠨ࡫ࡱࡪࡱࡧ࡭࠯ࡥࡦࠫᾁ")	in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: fXPHo5vUMiEeAzcsyV3ObSw	= vvWwO3Tx2dAgcijrFXq(u"ࠩ࡬ࡲ࡫ࡲࡡ࡮ࠩᾂ")
	elif RRIHDFjoW9w7bSfVPhC(u"ࠪࡦࡺࢀࡺࡷࡴ࡯ࠫᾃ")		in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: fXPHo5vUMiEeAzcsyV3ObSw	= yST5AHEfvPmcWpwGuh2BJ(u"ࠫࡧࡻࡺࡻࡸࡵࡰࠬᾄ")
	elif m6hwdgP31a2zjN7lkpX(u"ࠬࡧࡲࡢࡤ࡯ࡳࡦࡪࡳࠨᾅ")	in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: ebmgnU3IGCVA7Dx	= HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"࠭ࡡࡳࡣࡥࡰࡴࡧࡤࡴࠩᾆ")
	elif BWNPxIG7vqdTy85pjHzUOrK3(u"ࠧࡢࡴࡦ࡬࡮ࡼࡥࠨᾇ")		in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: ebmgnU3IGCVA7Dx	= BWNPxIG7vqdTy85pjHzUOrK3(u"ࠨࡣࡵࡧ࡭࡯ࡶࡦࠩᾈ")
	elif vvWwO3Tx2dAgcijrFXq(u"ࠩࡦࡥࡹࡩࡨ࠯࡫ࡶࠫᾉ")	 	in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: ebmgnU3IGCVA7Dx	= Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠪࡧࡦࡺࡣࡩࠩᾊ")
	elif Mmpr0o76iWJvz1kTtfgI8hES(u"ࠫ࡫࡯࡬ࡦࡴ࡬ࡳࠬᾋ")		in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: ebmgnU3IGCVA7Dx	= BmePGjS7FxK6kutUM(u"ࠬ࡬ࡩ࡭ࡧࡵ࡭ࡴ࠭ᾌ")
	elif shC5qBRV2A0lZ(u"࠭ࡶࡪࡦࡥࡱࠬᾍ")		in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: ebmgnU3IGCVA7Dx	= P0qdZI384LKleuo(u"ࠧࡷ࡫ࡧࡦࡲ࠭ᾎ")
	elif ubxGUTt1LraKhVZgpAP(u"ࠨࡸ࡬ࡨ࡭ࡪࠧᾏ")		in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: qMoEVg9n2vGxKpt	= iiKm9uPnofhLXGktjHVFdAI1
	elif QQdAXWBc2GPw(u"ࠩࡰࡽࡻ࡯ࡤࠨᾐ")		in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: qMoEVg9n2vGxKpt	= iiKm9uPnofhLXGktjHVFdAI1
	elif S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠪࡱࡾࡼࡩࡪࡦࠪᾑ")		in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: qMoEVg9n2vGxKpt	= iiKm9uPnofhLXGktjHVFdAI1
	elif UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠫࡻ࡯ࡤࡦࡱࡥ࡭ࡳ࠭ᾒ")		in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: ebmgnU3IGCVA7Dx	= TYf7Dc06PQgy1vEV9(u"ࠬࡼࡩࡥࡧࡲࡦ࡮ࡴࠧᾓ")
	elif QQdAXWBc2GPw(u"࠭ࡧࡰࡸ࡬ࡨࠬᾔ")		in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: ebmgnU3IGCVA7Dx	= TYf7Dc06PQgy1vEV9(u"ࠧࡨࡱࡹ࡭ࡩ࠭ᾕ")
	elif RRIHDFjoW9w7bSfVPhC(u"ࠨ࡮࡬࡭ࡻ࡯ࡤࡦࡱࠪᾖ") 	in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: ebmgnU3IGCVA7Dx	= BWNPxIG7vqdTy85pjHzUOrK3(u"ࠩ࡯࡭࡮ࡼࡩࡥࡧࡲࠫᾗ")
	elif QTUBCcehw6qPd4x(u"ࠪࡱࡵ࠺ࡵࡱ࡮ࡲࡥࡩ࠭ᾘ")	in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: ebmgnU3IGCVA7Dx	= dDYUoKi6JFM23p(u"ࠫࡲࡶ࠴ࡶࡲ࡯ࡳࡦࡪࠧᾙ")
	elif zI3ROAZtiUq42rE9WDST68(u"ࠬࡶࡵࡣ࡮࡬ࡧࡻ࡯ࡤࡦࡱࠪᾚ")	in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: ebmgnU3IGCVA7Dx	= DYakr9g4PVU(u"࠭ࡰࡶࡤ࡯࡭ࡨࡼࡩࡥࡧࡲࠫᾛ")
	elif P0qdZI384LKleuo(u"ࠧࡳࡣࡳ࡭ࡩࡼࡩࡥࡧࡲࠫᾜ") 	in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: ebmgnU3IGCVA7Dx	= zI3ROAZtiUq42rE9WDST68(u"ࠨࡴࡤࡴ࡮ࡪࡶࡪࡦࡨࡳࠬᾝ")
	elif BmePGjS7FxK6kutUM(u"ࠩࡷࡳࡵ࠺ࡴࡰࡲࠪᾞ")		in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: ebmgnU3IGCVA7Dx	= Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠪࡸࡴࡶ࠴ࡵࡱࡳࠫᾟ")
	elif TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠫࡺࡶࡰࠨᾠ") 			in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: ebmgnU3IGCVA7Dx	= ddo23ZJtgcY(u"ࠬࡻࡰࡣࡱࡰࠫᾡ")
	elif Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"࠭ࡵࡱࡤࠪᾢ") 			in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: ebmgnU3IGCVA7Dx	= uVQd103XyvUce2EBtzbYaC(u"ࠧࡶࡲࡥࡳࡲ࠭ᾣ")
	elif Xz3bA2PFENVCUtplu51(u"ࠨࡷࡴࡰࡴࡧࡤࠨᾤ") 		in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: ebmgnU3IGCVA7Dx	= Mmpr0o76iWJvz1kTtfgI8hES(u"ࠩࡸࡵࡱࡵࡡࡥࠩᾥ")
	elif ddo23ZJtgcY(u"ࠪࡺࡨࡹࡴࡳࡧࡤࡱࠬᾦ") 	in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: ebmgnU3IGCVA7Dx	= QQdAXWBc2GPw(u"ࠫࡻࡩࡳࡵࡴࡨࡥࡲ࠭ᾧ")
	elif shC5qBRV2A0lZ(u"ࠬࡼࡩࡥࡤࡲࡦࠬᾨ")		in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: ebmgnU3IGCVA7Dx	= VFjQx6Is28KvzLOmMXtg4GqTwa3(u"࠭ࡶࡪࡦࡥࡳࡧ࠭ᾩ")
	elif uVQd103XyvUce2EBtzbYaC(u"ࠧࡷ࡫ࡧࡳࡿࡧࠧᾪ") 		in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: ebmgnU3IGCVA7Dx	= Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠨࡸ࡬ࡨࡴࢀࡡࠨᾫ")
	elif P0qdZI384LKleuo(u"ࠩࡺࡥࡹࡩࡨࡷ࡫ࡧࡩࡴ࠭ᾬ") 	in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: ebmgnU3IGCVA7Dx	= shC5qBRV2A0lZ(u"ࠪࡻࡦࡺࡣࡩࡸ࡬ࡨࡪࡵࠧᾭ")
	elif dDYUoKi6JFM23p(u"ࠫࡼ࡯࡮ࡵࡸ࠱ࡰ࡮ࡼࡥࠨᾮ")	in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: ebmgnU3IGCVA7Dx	= QQdAXWBc2GPw(u"ࠬࡽࡩ࡯ࡶࡹ࠲ࡱ࡯ࡶࡦࠩᾯ")
	elif HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"࠭ࡺࡪࡲࡳࡽࡸ࡮ࡡࡳࡧࠪᾰ")	in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: ebmgnU3IGCVA7Dx	= BWNPxIG7vqdTy85pjHzUOrK3(u"ࠧࡻ࡫ࡳࡴࡾࡹࡨࡢࡴࡨࠫᾱ")
	elif zI3ROAZtiUq42rE9WDST68(u"ࠨࡪࡧ࠱ࡨࡪ࡮ࠨᾲ")		in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: ebmgnU3IGCVA7Dx	= kke1PDGRBLuY8y(u"ࠩ࡫ࡨ࠲ࡩࡤ࡯ࠩᾳ")
	if   fXPHo5vUMiEeAzcsyV3ObSw:	uRzobLkq3vC7sxcKVZtger58Od,c17XeRIH2gVh3px8sw = UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠪาฬ฻ࠧᾴ"),fXPHo5vUMiEeAzcsyV3ObSw
	elif qMoEVg9n2vGxKpt:		uRzobLkq3vC7sxcKVZtger58Od,c17XeRIH2gVh3px8sw = P0qdZI384LKleuo(u"๋ࠫࠪอะัࠪ᾵"),qMoEVg9n2vGxKpt
	elif ebmgnU3IGCVA7Dx:		uRzobLkq3vC7sxcKVZtger58Od,c17XeRIH2gVh3px8sw = RRIHDFjoW9w7bSfVPhC(u"ฺࠬࠫࠥษ่ࠤ๊฿ั้ใࠪᾶ"),ebmgnU3IGCVA7Dx
	elif O2fJR0pZ5TPErmcIsMjlVYk7:	uRzobLkq3vC7sxcKVZtger58Od,c17XeRIH2gVh3px8sw = BmePGjS7FxK6kutUM(u"࠭ࠥࠦࠧ฼ห๊ࠦฮศำฯ๎ࠬᾷ"),O2fJR0pZ5TPErmcIsMjlVYk7
	elif EMiV9oQlX3gts1WhuTGrkvZaUycL4m:	uRzobLkq3vC7sxcKVZtger58Od,c17XeRIH2gVh3px8sw = RRIHDFjoW9w7bSfVPhC(u"ࠧࠦࠧࠨࠩ฾อๅࠡะสีั๐ࠧᾸ"),iiKm9uPnofhLXGktjHVFdAI1
	else:			uRzobLkq3vC7sxcKVZtger58Od,c17XeRIH2gVh3px8sw = kke1PDGRBLuY8y(u"ࠨࠧࠨูࠩࠪࠫศ็้ࠣัํ่ๅࠩᾹ"),iiKm9uPnofhLXGktjHVFdAI1
	return uRzobLkq3vC7sxcKVZtger58Od,c17XeRIH2gVh3px8sw,E57WK4m31C8,UYat1jqNzCdDlWGuPF60T9i,c1EdszLx3mkb8QYX9
def Za5JDdsnlFw4W8mxzPb0yq(bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j):
	YRtyADTLUrGc,tzdvaEpMHOCZLXDYg08T = [],[]
	for title,pcA1dzy7LXwGfMPg9mTkuh5tine3 in zip(uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j):
		if Gz7MH0glBw8Eb(pcA1dzy7LXwGfMPg9mTkuh5tine3):
			YRtyADTLUrGc.append(title)
			tzdvaEpMHOCZLXDYg08T.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
	if not tzdvaEpMHOCZLXDYg08T and not bqCG6DEkf705Z9enS4pmN2: bqCG6DEkf705Z9enS4pmN2 = RRIHDFjoW9w7bSfVPhC(u"ࠩࡉࡥ࡮ࡲࡥࡥࠩᾺ")
	return bqCG6DEkf705Z9enS4pmN2,YRtyADTLUrGc,tzdvaEpMHOCZLXDYg08T
def ysjXzQUtSR9euol(url,source):
	MUJCtfYVBLODrFbaZn,qMoEVg9n2vGxKpt,LLOCdZ3sS2enzXx4fVB18YRvbHNwky,iiKm9uPnofhLXGktjHVFdAI1,c17XeRIH2gVh3px8sw,E57WK4m31C8,UYat1jqNzCdDlWGuPF60T9i,c1EdszLx3mkb8QYX9,JVrK4ste3qUM9iy2mNIgdXHhcSwQP6 = K5dQxkb9qnGPaWM2jNERIyDCg41Z(url,source)
	if   ubxGUTt1LraKhVZgpAP(u"ࠪࡽࡴࡻࡴࡶࠩΆ")		in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = IjZbnrBJmM2N(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧᾼ"),[b8Qe150xVaJsnDSv],[url]
	elif Nh0BWuiSndf(u"ࠬࡿ࠲ࡶ࠰ࡥࡩࠬ᾽")		in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = vvWwO3Tx2dAgcijrFXq(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩι"),[b8Qe150xVaJsnDSv],[url]
	elif QTUBCcehw6qPd4x(u"ࠧࡲࡸ࡬ࡨࠬ᾿")			in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = dR3IXFnWwevCsSBiTM1uAl(MUJCtfYVBLODrFbaZn)
	elif vvWwO3Tx2dAgcijrFXq(u"ࠨࡨ࡬ࡰࡲ࡫ࡹࠨ῀")		in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = dR3IXFnWwevCsSBiTM1uAl(MUJCtfYVBLODrFbaZn)
	elif Nh0BWuiSndf(u"ࠩࡄࡐࡒ࡙ࡔࡃࡃࠪ῁")		in source: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = dR3IXFnWwevCsSBiTM1uAl(MUJCtfYVBLODrFbaZn)
	elif Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠪࡅࡐࡕࡁࡎࠩῂ")		in source: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = AvLtXWDMhP(MUJCtfYVBLODrFbaZn,c17XeRIH2gVh3px8sw)
	elif TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠫࡆࡑࡗࡂࡏࠪῃ")		in source: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = pn57ui6YOm(MUJCtfYVBLODrFbaZn,E57WK4m31C8,c1EdszLx3mkb8QYX9)
	elif mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠬࡌࡁࡔࡇࡏࡌࡉ࠷ࠧῄ")		in source: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = zzypDIMWSQ(MUJCtfYVBLODrFbaZn)
	elif RRIHDFjoW9w7bSfVPhC(u"࡙࠭ࡐࡗࡗ࡙ࡇࡋࠧ῅")		in source: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪῆ"),[b8Qe150xVaJsnDSv],[url]
	elif UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠨࡅࡌࡑࡆ࠺ࡕࠨῇ")		in source: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = dzqHvb2nFt(MUJCtfYVBLODrFbaZn)
	elif mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅࠫῈ")		in source: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = QBl6HJObqY(MUJCtfYVBLODrFbaZn)
	elif Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠪࡅࡗࡇࡂࡔࡇࡈࡈࠬΈ")		in source: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = CZJ7QPaeh2(MUJCtfYVBLODrFbaZn)
	elif Xz3bA2PFENVCUtplu51(u"ࠫࡈࡏࡍࡂࡃࡅࡈࡔ࠭Ὴ")		in source: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = movfiGTFn2(MUJCtfYVBLODrFbaZn)
	elif BWNPxIG7vqdTy85pjHzUOrK3(u"࡙ࠬࡈࡐࡈࡋࡅࠬΉ")		in source: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = d4dNXL87qj(MUJCtfYVBLODrFbaZn)
	elif TT8Mxv5Wq7nlC9IscdpPUY6(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠱ࠨῌ")		in source: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = c7rXmiApNg(MUJCtfYVBLODrFbaZn,JVrK4ste3qUM9iy2mNIgdXHhcSwQP6)
	elif SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠧࡍࡃࡕࡓ࡟ࡇࠧ῍")		in source: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = D5SKEimOC4(MUJCtfYVBLODrFbaZn)
	elif RRIHDFjoW9w7bSfVPhC(u"ࠨ࡭ࡤࡸࡰࡵࡵࡵࡧࠪ῎")		in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = F97FYjQaNH(MUJCtfYVBLODrFbaZn)
	elif Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠩࡤ࡯ࡴࡧ࡭࠯ࡥࡤࡱࠬ῏")	in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = MxkbhgKr40(MUJCtfYVBLODrFbaZn)
	elif BmePGjS7FxK6kutUM(u"ࠪࡥࡱࡧࡲࡢࡤࠪῐ")		in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = QXRr9sd1gBe5Kl6vbU0cuyNZPz(MUJCtfYVBLODrFbaZn)
	elif TYf7Dc06PQgy1vEV9(u"ࠫࡸ࡮ࡡࡩ࡫ࡧ࠸ࡺ࠭ῑ")		in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = LLXhstl7gG(MUJCtfYVBLODrFbaZn)
	elif kke1PDGRBLuY8y(u"ࠬࡹࡨࡢࡪࡨࡨ࠹ࡻࠧῒ")		in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = LLXhstl7gG(MUJCtfYVBLODrFbaZn)
	elif HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"࠭ࡥࡨࡻࡱࡳࡼ࠭ΐ")		in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = P98kZm1TK7(MUJCtfYVBLODrFbaZn)
	elif Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠧࡵࡸࡩࡹࡳ࠭῔")		in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = X3cLRkjer9(MUJCtfYVBLODrFbaZn)
	elif TYf7Dc06PQgy1vEV9(u"ࠨࡶࡹ࡯ࡸࡧࠧ῕")		in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = X3cLRkjer9(MUJCtfYVBLODrFbaZn)
	elif BmePGjS7FxK6kutUM(u"ࠩࡷࡺ࠲࡬࠮ࡤࡱࡰࠫῖ")		in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = X3cLRkjer9(MUJCtfYVBLODrFbaZn)
	elif RRIHDFjoW9w7bSfVPhC(u"ࠪ࡬ࡦࡲࡡࡤ࡫ࡰࡥࠬῗ")		in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = mQAFeP4aYr(MUJCtfYVBLODrFbaZn)
	elif m6hwdgP31a2zjN7lkpX(u"ࠫࡸ࡮࡯ࡰࡨࡳࡶࡴ࠭Ῐ")		in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = AXH64EOWgQ(MUJCtfYVBLODrFbaZn)
	elif LAQD5wEkr18bUiGaYen3J(u"ࠬࡳࡹࡦࡩࡼࡺ࡮ࡶࠧῙ")		in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = KaueH6Yb8Sq(MUJCtfYVBLODrFbaZn)
	elif TT8Mxv5Wq7nlC9IscdpPUY6(u"࠭ࡶࡴ࠶ࡸࠫῚ")			in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = hetvLJfylE(MUJCtfYVBLODrFbaZn)
	elif TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠧࡧࡣ࡭ࡩࡷ࠭Ί")		in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = WO3GF0r9ls(MUJCtfYVBLODrFbaZn)
	elif P0qdZI384LKleuo(u"ࠨࡥ࡬ࡱࡦࡴ࡯ࡸࠩ῜")		in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = jeADxZEL0I(MUJCtfYVBLODrFbaZn)
	elif SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠩࡱࡩࡼࡩࡩ࡮ࡣࠪ῝")		in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = jeADxZEL0I(MUJCtfYVBLODrFbaZn)
	elif Nh0BWuiSndf(u"ࠪࡧ࡮ࡳࡡ࠮࡮࡬࡫࡭ࡺࠧ῞")	in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = qfcDtmraLC(MUJCtfYVBLODrFbaZn)
	elif Nh0BWuiSndf(u"ࠫࡨ࡯࡭ࡢ࡮࡬࡫࡭ࡺࠧ῟")	in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = qfcDtmraLC(MUJCtfYVBLODrFbaZn)
	elif Xz3bA2PFENVCUtplu51(u"ࠬࡳࡹࡤ࡫ࡰࡥࠬῠ")		in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = quCJpzXv4r(MUJCtfYVBLODrFbaZn)
	elif mQNonhS7CV2BXOv(u"࠭ࡷࡦࡥ࡬ࡱࡦ࠭ῡ")		in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = EXCsxBM5TGupzSIkql(MUJCtfYVBLODrFbaZn)
	elif P0qdZI384LKleuo(u"ࠧࡣࡱ࡮ࡶࡦ࠭ῢ")		in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = q7STAvBNhV(MUJCtfYVBLODrFbaZn)
	elif zI3ROAZtiUq42rE9WDST68(u"ࠨࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠭ΰ")	in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = PWzLngkZar(MUJCtfYVBLODrFbaZn)
	elif BmePGjS7FxK6kutUM(u"ࠩࡤࡶࡧࡲࡩࡰࡰࡽࠫῤ")		in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = twBo6ILYAy(MUJCtfYVBLODrFbaZn)
	elif Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠪࡩ࡬ࡿ࠭ࡣࡧࡶࡸ࠳ࡴࡥࡵࠩῥ")	in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = rcz6XESfRt(MUJCtfYVBLODrFbaZn)
	elif Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠫࡩ࠴ࡥࡨࡻࡥࡩࡸࡺ࠮ࡥࠩῦ")	in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = b8Qe150xVaJsnDSv,[b8Qe150xVaJsnDSv],[MUJCtfYVBLODrFbaZn]
	elif TYf7Dc06PQgy1vEV9(u"ࠬ࡫ࡧࡺࡤࡨࡷࡹ࠭ῧ")		in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = KTWbR9QiUY(MUJCtfYVBLODrFbaZn)
	elif m6hwdgP31a2zjN7lkpX(u"࠭ࡳࡦࡴ࡬ࡩࡸ࠺ࡷࡢࡶࡦ࡬ࠬῨ")	in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = cjM8eNGR7n(MUJCtfYVBLODrFbaZn)
	elif dDYUoKi6JFM23p(u"ࠧࡶࡲࡥࡥࡲ࠭Ῡ") 		in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = b8Qe150xVaJsnDSv,[b8Qe150xVaJsnDSv],[MUJCtfYVBLODrFbaZn]
	else: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = m6hwdgP31a2zjN7lkpX(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫῪ"),[b8Qe150xVaJsnDSv],[MUJCtfYVBLODrFbaZn]
	if bqCG6DEkf705Z9enS4pmN2 not in [Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠩࠪΎ"),BWNPxIG7vqdTy85pjHzUOrK3(u"ࠪࡉ࡝ࡏࡔࡠࡃࡏࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨῬ"),Xz3bA2PFENVCUtplu51(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ῭")]: bqCG6DEkf705Z9enS4pmN2 = TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠬࡌࡡࡪ࡮ࡨࡨ࠿ࠦࠠࠨ΅")+bqCG6DEkf705Z9enS4pmN2
	return bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j
def Dj9lY70NVqcO83aEh(pku4PVSrUet,url,source,iNdb241X5QmGjzfhopLkc0wUgCl6DM):
	global ssIkizmnZpySOJb14MVuNcUwFGjdh3,Kf2nteDo0v,V7uZ9KaXwopxPhbte,At3RlKLcWFuzjrYUIwQDg,hvtcQJpTWmeonuzVB2kPMqE6
	u6MsxLSY9UQKNtIAJakjdP21mnWcOg = []
	for EMiV9oQlX3gts1WhuTGrkvZaUycL4m in [Kf2nteDo0v,V7uZ9KaXwopxPhbte,At3RlKLcWFuzjrYUIwQDg,hvtcQJpTWmeonuzVB2kPMqE6]: EMiV9oQlX3gts1WhuTGrkvZaUycL4m[iNdb241X5QmGjzfhopLkc0wUgCl6DM] = dDYUoKi6JFM23p(u"࠭ࡔࡪ࡯ࡨࡳࡺࡺࠧ`"),[],[]
	NBaA9lt5k0IL8yJ,w7ukNxVMfCvdrGIL59pba14 = [vkewLp8YhADjgxy,PPYWBa8yriR7,GaJfehHtTiQDb47d2KL,iJotXIjZHBhU950AQedY3lOCG],[]
	if shC5qBRV2A0lZ(u"ࠧࡧࡴࡧࡰࠬ῰") in url: NBaA9lt5k0IL8yJ,w7ukNxVMfCvdrGIL59pba14 = [vkewLp8YhADjgxy,PPYWBa8yriR7,iJotXIjZHBhU950AQedY3lOCG],[At3RlKLcWFuzjrYUIwQDg]
	if ubxGUTt1LraKhVZgpAP(u"ࠨࡻࡲࡹࡹࡻࡢࡦࠩ῱") in url: NBaA9lt5k0IL8yJ,w7ukNxVMfCvdrGIL59pba14 = [vkewLp8YhADjgxy],[V7uZ9KaXwopxPhbte,At3RlKLcWFuzjrYUIwQDg,hvtcQJpTWmeonuzVB2kPMqE6]
	for EMiV9oQlX3gts1WhuTGrkvZaUycL4m in w7ukNxVMfCvdrGIL59pba14: EMiV9oQlX3gts1WhuTGrkvZaUycL4m[iNdb241X5QmGjzfhopLkc0wUgCl6DM] = Xz3bA2PFENVCUtplu51(u"ࠩࡖ࡯࡮ࡶࡰࡦࡦࠪῲ"),[],[]
	for EMiV9oQlX3gts1WhuTGrkvZaUycL4m in NBaA9lt5k0IL8yJ:
		N5xVkFe13bltAI = Ay1SMOzkx5CU3aGTL4Zf.Thread(target=EMiV9oQlX3gts1WhuTGrkvZaUycL4m,args=(url,source,iNdb241X5QmGjzfhopLkc0wUgCl6DM))
		u6MsxLSY9UQKNtIAJakjdP21mnWcOg.append(N5xVkFe13bltAI)
		N5xVkFe13bltAI.start()
		wLQCTr5lqbsVYeAHdzfhZ1F.sleep(QTUBCcehw6qPd4x(u"࠴෠"))
	CTgvX5QPfZEOWL6dzuBo3U,bGEAo7mgXLFj2MHBr9NiTO3a1qSQ,Dcltupzg3OoAS,vvRnkoIFUjGieJpDO5 = DD5cFIejQa2X4BgAu9GWPyJ3tC7,DD5cFIejQa2X4BgAu9GWPyJ3tC7,DD5cFIejQa2X4BgAu9GWPyJ3tC7,DD5cFIejQa2X4BgAu9GWPyJ3tC7
	timeout,step = Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"࠷࠵෡"),IgQimel18t
	for OyhU8u6LjGzVYea2STmbpfsE in range(timeout//step):
		if not CTgvX5QPfZEOWL6dzuBo3U and Kf2nteDo0v[iNdb241X5QmGjzfhopLkc0wUgCl6DM][LzYQg91SIxDeOGtCKd5]!=Nh0BWuiSndf(u"ࠪࡘ࡮ࡳࡥࡰࡷࡷࠫῳ"): CTgvX5QPfZEOWL6dzuBo3U = CCxMXuNUEzolDZTKrBJ
		if not bGEAo7mgXLFj2MHBr9NiTO3a1qSQ and V7uZ9KaXwopxPhbte[iNdb241X5QmGjzfhopLkc0wUgCl6DM][LzYQg91SIxDeOGtCKd5]!=Mmpr0o76iWJvz1kTtfgI8hES(u"࡙ࠫ࡯࡭ࡦࡱࡸࡸࠬῴ"): bGEAo7mgXLFj2MHBr9NiTO3a1qSQ = CCxMXuNUEzolDZTKrBJ
		if not Dcltupzg3OoAS and At3RlKLcWFuzjrYUIwQDg[iNdb241X5QmGjzfhopLkc0wUgCl6DM][LzYQg91SIxDeOGtCKd5]!=P0qdZI384LKleuo(u"࡚ࠬࡩ࡮ࡧࡲࡹࡹ࠭῵"): Dcltupzg3OoAS = CCxMXuNUEzolDZTKrBJ
		if not vvRnkoIFUjGieJpDO5 and hvtcQJpTWmeonuzVB2kPMqE6[iNdb241X5QmGjzfhopLkc0wUgCl6DM][LzYQg91SIxDeOGtCKd5]!=Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"࠭ࡔࡪ࡯ࡨࡳࡺࡺࠧῶ"): vvRnkoIFUjGieJpDO5 = CCxMXuNUEzolDZTKrBJ
		if CTgvX5QPfZEOWL6dzuBo3U and bGEAo7mgXLFj2MHBr9NiTO3a1qSQ and Dcltupzg3OoAS and vvRnkoIFUjGieJpDO5: break
		if not Kf2nteDo0v[iNdb241X5QmGjzfhopLkc0wUgCl6DM][LzYQg91SIxDeOGtCKd5] and Kf2nteDo0v[iNdb241X5QmGjzfhopLkc0wUgCl6DM][IgQimel18t]: break
		if not V7uZ9KaXwopxPhbte[iNdb241X5QmGjzfhopLkc0wUgCl6DM][LzYQg91SIxDeOGtCKd5] and V7uZ9KaXwopxPhbte[iNdb241X5QmGjzfhopLkc0wUgCl6DM][IgQimel18t]: break
		if not At3RlKLcWFuzjrYUIwQDg[iNdb241X5QmGjzfhopLkc0wUgCl6DM][LzYQg91SIxDeOGtCKd5] and At3RlKLcWFuzjrYUIwQDg[iNdb241X5QmGjzfhopLkc0wUgCl6DM][IgQimel18t]: break
		if not hvtcQJpTWmeonuzVB2kPMqE6[iNdb241X5QmGjzfhopLkc0wUgCl6DM][LzYQg91SIxDeOGtCKd5] and hvtcQJpTWmeonuzVB2kPMqE6[iNdb241X5QmGjzfhopLkc0wUgCl6DM][IgQimel18t]: break
		wLQCTr5lqbsVYeAHdzfhZ1F.sleep(step)
	for N5xVkFe13bltAI in u6MsxLSY9UQKNtIAJakjdP21mnWcOg: N5xVkFe13bltAI.join(UUkIBz1sgQ9WfNeG6trKXvu0(u"࠶෢"))
	jhtzsARou03iw9e = TYf7Dc06PQgy1vEV9(u"ࠧࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡣ࠷࠭ῷ")
	bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = Kf2nteDo0v[iNdb241X5QmGjzfhopLkc0wUgCl6DM]
	KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = w9lxG2adH3CbYQRMpBqzAms(KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j)
	ssIkizmnZpySOJb14MVuNcUwFGjdh3[iNdb241X5QmGjzfhopLkc0wUgCl6DM] = pku4PVSrUet,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j
	if bqCG6DEkf705Z9enS4pmN2==shC5qBRV2A0lZ(u"ࠨࡇ࡛ࡍ࡙ࡥࡁࡍࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭Ὸ") or KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j: return jhtzsARou03iw9e,bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j
	pku4PVSrUet += BWNPxIG7vqdTy85pjHzUOrK3(u"ࠩ࡟ࡲࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦ࠲࠻ࠢࠣࠫΌ")+bqCG6DEkf705Z9enS4pmN2.replace(eeN6dTEnkJxI,b8Qe150xVaJsnDSv).replace(d6ekSEojpFUANKJ7r9WTlI3niLBOu,b8Qe150xVaJsnDSv)[:S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"࠾࠰෣")]
	jhtzsARou03iw9e = SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠪࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘ࡟࠴ࠩῺ")
	bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = V7uZ9KaXwopxPhbte[iNdb241X5QmGjzfhopLkc0wUgCl6DM]
	KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = w9lxG2adH3CbYQRMpBqzAms(KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j)
	ssIkizmnZpySOJb14MVuNcUwFGjdh3[iNdb241X5QmGjzfhopLkc0wUgCl6DM] = pku4PVSrUet,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j
	if bqCG6DEkf705Z9enS4pmN2==uVQd103XyvUce2EBtzbYaC(u"ࠫࡊ࡞ࡉࡕࡡࡄࡐࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩΏ") or KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j: return jhtzsARou03iw9e,bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j
	pku4PVSrUet += ubxGUTt1LraKhVZgpAP(u"ࠬࡢ࡮ࡓࡧࡶࡳࡱࡼࡥࡳࠢ࠶࠾ࠥࠦࠧῼ")+bqCG6DEkf705Z9enS4pmN2.replace(eeN6dTEnkJxI,b8Qe150xVaJsnDSv).replace(d6ekSEojpFUANKJ7r9WTlI3niLBOu,b8Qe150xVaJsnDSv)[:dDYUoKi6JFM23p(u"࠸࠱෤")]
	jhtzsARou03iw9e = vvWwO3Tx2dAgcijrFXq(u"࠭ࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡢ࠸ࠬ´")
	bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = At3RlKLcWFuzjrYUIwQDg[iNdb241X5QmGjzfhopLkc0wUgCl6DM]
	KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = w9lxG2adH3CbYQRMpBqzAms(KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j)
	ssIkizmnZpySOJb14MVuNcUwFGjdh3[iNdb241X5QmGjzfhopLkc0wUgCl6DM] = pku4PVSrUet,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j
	if bqCG6DEkf705Z9enS4pmN2==BWNPxIG7vqdTy85pjHzUOrK3(u"ࠧࡆ࡚ࡌࡘࡤࡇࡌࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ῾") or KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j: return jhtzsARou03iw9e,bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j
	pku4PVSrUet += RRIHDFjoW9w7bSfVPhC(u"ࠨ࡞ࡱࡖࡪࡹ࡯࡭ࡸࡨࡶࠥ࠺࠺ࠡࠢࠪ῿")+bqCG6DEkf705Z9enS4pmN2.replace(eeN6dTEnkJxI,b8Qe150xVaJsnDSv).replace(d6ekSEojpFUANKJ7r9WTlI3niLBOu,b8Qe150xVaJsnDSv)[:SbjiWeHLQPoazqwp3cODkd7YxVgn(u"࠹࠲෥")]
	jhtzsARou03iw9e = P0qdZI384LKleuo(u"ࠫࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡠ࠷ࠪࠀ")
	bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = hvtcQJpTWmeonuzVB2kPMqE6[iNdb241X5QmGjzfhopLkc0wUgCl6DM]
	KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = w9lxG2adH3CbYQRMpBqzAms(KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j)
	ssIkizmnZpySOJb14MVuNcUwFGjdh3[iNdb241X5QmGjzfhopLkc0wUgCl6DM] = pku4PVSrUet,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j
	if bqCG6DEkf705Z9enS4pmN2==BmePGjS7FxK6kutUM(u"ࠬࡋࡘࡊࡖࡢࡅࡑࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪࠁ") or KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j: return jhtzsARou03iw9e,bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j
	pku4PVSrUet += P0qdZI384LKleuo(u"࠭࡜࡯ࡔࡨࡷࡴࡲࡶࡦࡴࠣ࠹࠿ࠦࠠࠨࠂ")+bqCG6DEkf705Z9enS4pmN2.replace(eeN6dTEnkJxI,b8Qe150xVaJsnDSv).replace(d6ekSEojpFUANKJ7r9WTlI3niLBOu,b8Qe150xVaJsnDSv)[:RRIHDFjoW9w7bSfVPhC(u"࠺࠳෦")]
	ssIkizmnZpySOJb14MVuNcUwFGjdh3[iNdb241X5QmGjzfhopLkc0wUgCl6DM] = pku4PVSrUet,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j
	return jhtzsARou03iw9e,pku4PVSrUet,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j
def vkewLp8YhADjgxy(url,source,iNdb241X5QmGjzfhopLkc0wUgCl6DM):
	LLOCdZ3sS2enzXx4fVB18YRvbHNwky = Wl2eu1PavfQ(url,P0qdZI384LKleuo(u"ࠧ࡯ࡣࡰࡩࠬࠃ"))
	KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = []
	if RRIHDFjoW9w7bSfVPhC(u"ࠨࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠭ࠄ")	in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = PWzLngkZar(url)
	elif ddo23ZJtgcY(u"ࠩࡪࡳࡴ࡭࡬ࡦࡷࡶࡩࡷࡩ࡯ࠨࠅ") in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = DQsl3U5MwSgh0VPy71k9RjbxpmAa(url)
	elif BWNPxIG7vqdTy85pjHzUOrK3(u"ࠪࡽࡴࡻࡴࡶࠩࠆ")		in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = wUvIhZ72APyNVpW8KiBrakOsctoj6G(url)
	elif SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠫࡾ࠸ࡵ࠯ࡤࡨࠫࠇ")		in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = wUvIhZ72APyNVpW8KiBrakOsctoj6G(url)
	elif VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠬࡶࡨࡰࡶࡲࡷ࠳ࡧࡰࡱ࠰ࡪࠫࠈ")	in url   : bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = ndgtjkPiCI0qJ7NbzUlma3p2B6(url)
	elif QTUBCcehw6qPd4x(u"࠭࡭ࡰࡵ࡫ࡥ࡭ࡪࡡࠨࠉ")		in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = mTrHl15VxQFAqCX(url)
	elif Mmpr0o76iWJvz1kTtfgI8hES(u"ࠧࡧࡣࡶࡩࡱ࡮ࡤࠨࠊ")		in url   : bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = zzypDIMWSQ(url)
	elif BWNPxIG7vqdTy85pjHzUOrK3(u"ࠨࡣࡵࡥࡧࡲ࡯ࡢࡦࡶࠫࠋ")	in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = H0Ou7SQqJpdN8o1xDZsKBPtMRc(url)
	elif Mmpr0o76iWJvz1kTtfgI8hES(u"ࠩࡤࡶࡨ࡮ࡩࡷࡧࠪࠌ")		in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = tVI9mWb20Oo5l3xUvehFP1(url)
	elif Mmpr0o76iWJvz1kTtfgI8hES(u"ࠪࡦࡺࢀࡺࡷࡴ࡯ࠫࠍ")		in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = sEwnOSP6CzIAl5tfeLj(url)
	elif VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠫࡪ࠻ࡴࡴࡣࡵࠫࠎ")		in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = qIFU5ln0KPchopeuZigM6NzE38Wt(url)
	elif BmePGjS7FxK6kutUM(u"ࠬ࡬ࡡࡤࡷ࡯ࡸࡾࡨ࡯ࡰ࡭ࡶࠫࠏ")	in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = U7JVqabxMABrngPHLedFw5GfsoXKYk(url)
	elif TT8Mxv5Wq7nlC9IscdpPUY6(u"࠭ࡩ࡯ࡨ࡯ࡥࡲ࠴ࡣࡤࠩࠐ")	in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = U7JVqabxMABrngPHLedFw5GfsoXKYk(url)
	elif vvWwO3Tx2dAgcijrFXq(u"ࠧࡶࡲࡥࡥࡲ࠭ࠑ") 		in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = b8Qe150xVaJsnDSv,[b8Qe150xVaJsnDSv],[url]
	elif DYakr9g4PVU(u"ࠨ࡮࡬࡭ࡻ࡯ࡤࡦࡱࠪࠒ") 	in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = PfJWu60GjSai(url)
	elif VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠩࡰࡴ࠹ࡻࡰ࡭ࡱࡤࡨࠬࠓ")	in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = gXu9orKSICHJZ0EjWYhAzplBOq3n(url)
	elif Nh0BWuiSndf(u"ࠪࡶࡦࡶࡩࡥࡸ࡬ࡨࡪࡵࠧࠔ") 	in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = Aue5MCqRLgpUr8xvokz(url)
	elif dDYUoKi6JFM23p(u"ࠫࡹࡵࡰ࠵ࡶࡲࡴࠬࠕ")		in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = mmGphNT56sUjfBx1doEIa(url)
	elif RRIHDFjoW9w7bSfVPhC(u"ࠬࡻࡰࡣࠩࠖ") 			in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = uuVCyTR4LBHXwfeG5gQZOMUidk(url)
	elif mQNonhS7CV2BXOv(u"࠭ࡵࡱࡲࠪࠗ") 			in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = uuVCyTR4LBHXwfeG5gQZOMUidk(url)
	elif yST5AHEfvPmcWpwGuh2BJ(u"ࠧࡶࡳ࡯ࡳࡦࡪࠧ࠘") 		in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = xyN2kAaiFj5Z4V9mUqE7KLGgn1p(url)
	elif TYf7Dc06PQgy1vEV9(u"ࠨࡸࡦࡷࡹࡸࡥࡢ࡯ࠪ࠙") 	in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = aktwebg5H93V6mnUDvi(url)
	elif UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠩࡹ࡭ࡩࡨ࡯ࡣࠩࠚ")		in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = y8atCrb0vVNHkgAIen7fwzG3LYiqJ(url)
	elif Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠪࡺ࡮ࡪ࡯ࡻࡣࠪࠛ") 		in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = WThi42cB0Re(url)
	elif shC5qBRV2A0lZ(u"ࠫࡼࡧࡴࡤࡪࡹ࡭ࡩ࡫࡯ࠨࠜ") 	in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = ibxZ9MDUWzfIX5CR(url)
	elif BmePGjS7FxK6kutUM(u"ࠬࡽࡩ࡯ࡶࡹ࠲ࡱ࡯ࡶࡦࠩࠝ")	in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = Os5zQIpHChR9g(url)
	elif S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"࠭ࡺࡪࡲࡳࡽࡸ࡮ࡡࡳࡧࠪࠞ")	in LLOCdZ3sS2enzXx4fVB18YRvbHNwky: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = tH7Gy6AJTwo5WuM1Pp3qKQ8CIcsa(url)
	else: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = b8Qe150xVaJsnDSv,[],[]
	global Kf2nteDo0v
	if bqCG6DEkf705Z9enS4pmN2 not in [ubxGUTt1LraKhVZgpAP(u"ࠧࠨࠟ"),BmePGjS7FxK6kutUM(u"ࠨࡇ࡛ࡍ࡙ࡥࡁࡍࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ࠠ"),dDYUoKi6JFM23p(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬࠡ")]: bqCG6DEkf705Z9enS4pmN2 = Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠪࡊࡦ࡯࡬ࡦࡦ࠽ࠤࠥ࠭ࠢ")+bqCG6DEkf705Z9enS4pmN2
	Kf2nteDo0v[iNdb241X5QmGjzfhopLkc0wUgCl6DM] = bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j
	return
def PPYWBa8yriR7(url,source,iNdb241X5QmGjzfhopLkc0wUgCl6DM):
	global V7uZ9KaXwopxPhbte
	if Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠫࡾࡵࡵࡵࡷࡥࡩࠬࠣ") in url:
		V7uZ9KaXwopxPhbte[iNdb241X5QmGjzfhopLkc0wUgCl6DM] = S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠬࡌࡡࡪ࡮ࡨࡨ࠿ࠦࠠࡔ࡭࡬ࡴࡵ࡫ࡤࠨࠤ"),[],[]
		return
	bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = b8Qe150xVaJsnDSv,[],[]
	if Gz7MH0glBw8Eb(url): bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = b8Qe150xVaJsnDSv,[b8Qe150xVaJsnDSv],[url]
	if not KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = z8ax7FlD1O2405yQcsuC(url)
	if not KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = MmjwzIKXpsSvYGRBdaLUi(url)
	if not KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j:
		if bqCG6DEkf705Z9enS4pmN2==shC5qBRV2A0lZ(u"࠭ࡅ࡙ࡋࡗࡣࡆࡒࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫࠥ"): bqCG6DEkf705Z9enS4pmN2 = b8Qe150xVaJsnDSv
		V7uZ9KaXwopxPhbte[iNdb241X5QmGjzfhopLkc0wUgCl6DM] = RRIHDFjoW9w7bSfVPhC(u"ࠧࡇࡣ࡬ࡰࡪࡪ࠺ࠡࠢࠪࠦ")+bqCG6DEkf705Z9enS4pmN2,[],[]
		return
	V7uZ9KaXwopxPhbte[iNdb241X5QmGjzfhopLkc0wUgCl6DM] = bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j
	return
def GaJfehHtTiQDb47d2KL(url,source,iNdb241X5QmGjzfhopLkc0wUgCl6DM):
	yABitW02UXORGEJQPsTujcL = b8Qe150xVaJsnDSv
	XXxlOLJ9KRjPH382WVCvr6n71 = DD5cFIejQa2X4BgAu9GWPyJ3tC7
	try:
		import resolveurl as iiJsMegIFfZVXr6EAjOKcmwoU
		XXxlOLJ9KRjPH382WVCvr6n71 = iiJsMegIFfZVXr6EAjOKcmwoU.resolve(url)
	except Exception as ixWk65EnU8pIA1S3FJCZTsuLjg7m: yABitW02UXORGEJQPsTujcL = str(ixWk65EnU8pIA1S3FJCZTsuLjg7m)
	global At3RlKLcWFuzjrYUIwQDg
	if not XXxlOLJ9KRjPH382WVCvr6n71:
		if yABitW02UXORGEJQPsTujcL==b8Qe150xVaJsnDSv:
			yABitW02UXORGEJQPsTujcL = n9dSEJTBOWlY6.format_exc()
			if yABitW02UXORGEJQPsTujcL!=yST5AHEfvPmcWpwGuh2BJ(u"ࠨࡐࡲࡲࡪ࡚ࡹࡱࡧ࠽ࠤࡓࡵ࡮ࡦ࡞ࡱࠫࠧ"): Pft6y0LvwSh48iYg7b.stderr.write(yABitW02UXORGEJQPsTujcL)
		bqCG6DEkf705Z9enS4pmN2 = yABitW02UXORGEJQPsTujcL.splitlines()[-qHYIWnOZLPkrQU]
		At3RlKLcWFuzjrYUIwQDg[iNdb241X5QmGjzfhopLkc0wUgCl6DM] = VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠩࡉࡥ࡮ࡲࡥࡥ࠼ࠣࠤࠬࠨ")+bqCG6DEkf705Z9enS4pmN2,[],[]
		return
	At3RlKLcWFuzjrYUIwQDg[iNdb241X5QmGjzfhopLkc0wUgCl6DM] = b8Qe150xVaJsnDSv,[b8Qe150xVaJsnDSv],[XXxlOLJ9KRjPH382WVCvr6n71]
	return
def iJotXIjZHBhU950AQedY3lOCG(url,source,iNdb241X5QmGjzfhopLkc0wUgCl6DM):
	yABitW02UXORGEJQPsTujcL = b8Qe150xVaJsnDSv
	XXxlOLJ9KRjPH382WVCvr6n71 = DD5cFIejQa2X4BgAu9GWPyJ3tC7
	try:
		import yt_dlp as EMZvjdoyeTBLkFNQ52Ur6
		rrjPC9GEzpyOAsUmDS4ZTQIJo = EMZvjdoyeTBLkFNQ52Ur6.YoutubeDL({yST5AHEfvPmcWpwGuh2BJ(u"ࠪࡲࡴࡥࡣࡰ࡮ࡲࡶࠬࠩ"): CCxMXuNUEzolDZTKrBJ})
		XXxlOLJ9KRjPH382WVCvr6n71 = rrjPC9GEzpyOAsUmDS4ZTQIJo.extract_info(url,download=DD5cFIejQa2X4BgAu9GWPyJ3tC7)
	except Exception as ixWk65EnU8pIA1S3FJCZTsuLjg7m: yABitW02UXORGEJQPsTujcL = str(ixWk65EnU8pIA1S3FJCZTsuLjg7m)
	global hvtcQJpTWmeonuzVB2kPMqE6
	if not XXxlOLJ9KRjPH382WVCvr6n71 or Nh0BWuiSndf(u"ࠫ࡫ࡵࡲ࡮ࡣࡷࡷࠬࠪ") not in list(XXxlOLJ9KRjPH382WVCvr6n71.keys()):
		if yABitW02UXORGEJQPsTujcL==b8Qe150xVaJsnDSv:
			yABitW02UXORGEJQPsTujcL = n9dSEJTBOWlY6.format_exc()
			if yABitW02UXORGEJQPsTujcL!=VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠬࡔ࡯࡯ࡧࡗࡽࡵ࡫࠺ࠡࡐࡲࡲࡪࡢ࡮ࠨࠫ"): Pft6y0LvwSh48iYg7b.stderr.write(yABitW02UXORGEJQPsTujcL)
		bqCG6DEkf705Z9enS4pmN2 = yABitW02UXORGEJQPsTujcL.splitlines()[-qHYIWnOZLPkrQU]
		hvtcQJpTWmeonuzVB2kPMqE6[iNdb241X5QmGjzfhopLkc0wUgCl6DM] = IjZbnrBJmM2N(u"࠭ࡆࡢ࡫࡯ࡩࡩࡀࠠࠡࠩࠬ")+bqCG6DEkf705Z9enS4pmN2,[],[]
	else:
		uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = [],[]
		for pcA1dzy7LXwGfMPg9mTkuh5tine3 in XXxlOLJ9KRjPH382WVCvr6n71[Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠧࡧࡱࡵࡱࡦࡺࡳࠨ࠭")]:
			uuSKUinvP4EGLxWZYmTsF.append(pcA1dzy7LXwGfMPg9mTkuh5tine3[m6hwdgP31a2zjN7lkpX(u"ࠨࡨࡲࡶࡲࡧࡴࠨ࠮")])
			KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j.append(pcA1dzy7LXwGfMPg9mTkuh5tine3[SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠩࡸࡶࡱ࠭࠯")])
		hvtcQJpTWmeonuzVB2kPMqE6[iNdb241X5QmGjzfhopLkc0wUgCl6DM] = b8Qe150xVaJsnDSv,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j
	return
def z8ax7FlD1O2405yQcsuC(url):
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(LtlXH3fvMydAx,S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠪࡋࡊ࡚ࠧ࠰"),url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,DD5cFIejQa2X4BgAu9GWPyJ3tC7,S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡓࡇࡇࡍࡗࡋࡃࡕࡡࡘࡖࡑ࠳࠱ࡴࡶࠪ࠱"))
	headers = b3HKopTY9zLUyhJmt.headers
	if TYf7Dc06PQgy1vEV9(u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ࠲") in list(headers.keys()):
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = b3HKopTY9zLUyhJmt.headers[S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ࠳")]
		if Gz7MH0glBw8Eb(pcA1dzy7LXwGfMPg9mTkuh5tine3): return b8Qe150xVaJsnDSv,[b8Qe150xVaJsnDSv],[pcA1dzy7LXwGfMPg9mTkuh5tine3]
	return IjZbnrBJmM2N(u"ࠧࡇࡣ࡬ࡰࡪࡪ࠺ࠡࠢࠪ࠴"),[],[]
def w9lxG2adH3CbYQRMpBqzAms(OC5ejho8i0pQ1):
	if zI3ROAZtiUq42rE9WDST68(u"ࠨ࡮࡬ࡷࡹ࠭࠵") in str(type(OC5ejho8i0pQ1)):
		tzdvaEpMHOCZLXDYg08T = []
		for pcA1dzy7LXwGfMPg9mTkuh5tine3 in OC5ejho8i0pQ1:
			if zI3ROAZtiUq42rE9WDST68(u"ࠩࡶࡸࡷ࠭࠶") in str(type(pcA1dzy7LXwGfMPg9mTkuh5tine3)): pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3.replace(d6ekSEojpFUANKJ7r9WTlI3niLBOu,b8Qe150xVaJsnDSv).replace(eeN6dTEnkJxI,b8Qe150xVaJsnDSv).strip(pldxivXC5wbTB2O8q)
			tzdvaEpMHOCZLXDYg08T.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
	else: tzdvaEpMHOCZLXDYg08T = OC5ejho8i0pQ1.replace(d6ekSEojpFUANKJ7r9WTlI3niLBOu,b8Qe150xVaJsnDSv).replace(eeN6dTEnkJxI,b8Qe150xVaJsnDSv).strip(pldxivXC5wbTB2O8q)
	return tzdvaEpMHOCZLXDYg08T
def KkyD5Cxmzj48L27XQsAwMYEvNUI(BB6xwqVdZC13JQPujR2sUtz,source):
	data = SS2OK7hjLagvUAm(mshLJcKH1fv03yRnDOr4ZT,Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠪࡰ࡮ࡹࡴࠨ࠷"),shC5qBRV2A0lZ(u"ࠫࡘࡋࡒࡗࡇࡕࡗࠬ࠸"),BB6xwqVdZC13JQPujR2sUtz)
	if data:
		uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = zip(*data)
		uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = list(uuSKUinvP4EGLxWZYmTsF),list(KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j)
		return uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j
	uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j,vKwDgnxRXsOpa = [],[],[]
	for pcA1dzy7LXwGfMPg9mTkuh5tine3 in BB6xwqVdZC13JQPujR2sUtz:
		if TYf7Dc06PQgy1vEV9(u"ࠬ࠵࠯ࠨ࠹") not in pcA1dzy7LXwGfMPg9mTkuh5tine3: continue
		uRzobLkq3vC7sxcKVZtger58Od,c17XeRIH2gVh3px8sw,E57WK4m31C8,UYat1jqNzCdDlWGuPF60T9i,c1EdszLx3mkb8QYX9 = McvYKS1wxIW(pcA1dzy7LXwGfMPg9mTkuh5tine3,source)
		c1EdszLx3mkb8QYX9 = YYBlm36zd0Jst18LXwo4.findall(ddo23ZJtgcY(u"࠭࡜ࡥ࠭ࠪ࠺"),c1EdszLx3mkb8QYX9,YYBlm36zd0Jst18LXwo4.DOTALL)
		if c1EdszLx3mkb8QYX9: c1EdszLx3mkb8QYX9 = int(c1EdszLx3mkb8QYX9[LzYQg91SIxDeOGtCKd5])
		else: c1EdszLx3mkb8QYX9 = LzYQg91SIxDeOGtCKd5
		LLOCdZ3sS2enzXx4fVB18YRvbHNwky = Wl2eu1PavfQ(pcA1dzy7LXwGfMPg9mTkuh5tine3,ddo23ZJtgcY(u"ࠧ࡯ࡣࡰࡩࠬ࠻"))
		vKwDgnxRXsOpa.append([uRzobLkq3vC7sxcKVZtger58Od,c17XeRIH2gVh3px8sw,E57WK4m31C8,UYat1jqNzCdDlWGuPF60T9i,c1EdszLx3mkb8QYX9,pcA1dzy7LXwGfMPg9mTkuh5tine3,LLOCdZ3sS2enzXx4fVB18YRvbHNwky])
	if vKwDgnxRXsOpa:
		fGxaws9FTYcUpq8ZO1t = sorted(vKwDgnxRXsOpa,reverse=CCxMXuNUEzolDZTKrBJ,key=lambda key: (key[NvHugPosYDzRJ],key[LzYQg91SIxDeOGtCKd5],key[VwApyDY1Jc],key[IgQimel18t],key[qHYIWnOZLPkrQU],key[HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"࠸෧")],key[QTUBCcehw6qPd4x(u"࠺෨")]))
		Vw6ELd0ReyubDGkj87FA1Zin,NGQbtdCeMU8F = [],[]
		for CspH3o0yQVkReLwX8K9ql in fGxaws9FTYcUpq8ZO1t:
			uRzobLkq3vC7sxcKVZtger58Od,c17XeRIH2gVh3px8sw,E57WK4m31C8,UYat1jqNzCdDlWGuPF60T9i,c1EdszLx3mkb8QYX9,pcA1dzy7LXwGfMPg9mTkuh5tine3,LLOCdZ3sS2enzXx4fVB18YRvbHNwky = CspH3o0yQVkReLwX8K9ql
			if UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠨ็ไฺ้࠭࠼") in E57WK4m31C8:
				NGQbtdCeMU8F.append(CspH3o0yQVkReLwX8K9ql)
				continue
			if CspH3o0yQVkReLwX8K9ql not in Vw6ELd0ReyubDGkj87FA1Zin: Vw6ELd0ReyubDGkj87FA1Zin.append(CspH3o0yQVkReLwX8K9ql)
		Vw6ELd0ReyubDGkj87FA1Zin = NGQbtdCeMU8F+Vw6ELd0ReyubDGkj87FA1Zin
		JZMvR4mp2rX7Kf6n = LzYQg91SIxDeOGtCKd5
		for uRzobLkq3vC7sxcKVZtger58Od,c17XeRIH2gVh3px8sw,E57WK4m31C8,UYat1jqNzCdDlWGuPF60T9i,c1EdszLx3mkb8QYX9,pcA1dzy7LXwGfMPg9mTkuh5tine3,LLOCdZ3sS2enzXx4fVB18YRvbHNwky in Vw6ELd0ReyubDGkj87FA1Zin:
			c1EdszLx3mkb8QYX9 = str(c1EdszLx3mkb8QYX9) if c1EdszLx3mkb8QYX9 else b8Qe150xVaJsnDSv
			title = TYf7Dc06PQgy1vEV9(u"ࠩึ๎ึ็ัࠨ࠽")+pldxivXC5wbTB2O8q+E57WK4m31C8+pldxivXC5wbTB2O8q+uRzobLkq3vC7sxcKVZtger58Od+pldxivXC5wbTB2O8q+c1EdszLx3mkb8QYX9+pldxivXC5wbTB2O8q+UYat1jqNzCdDlWGuPF60T9i+pldxivXC5wbTB2O8q+c17XeRIH2gVh3px8sw
			if LLOCdZ3sS2enzXx4fVB18YRvbHNwky.lower() not in title.lower(): title = title+pldxivXC5wbTB2O8q+LLOCdZ3sS2enzXx4fVB18YRvbHNwky
			title = title.replace(Nh0BWuiSndf(u"ࠪࠩࠬ࠾"),b8Qe150xVaJsnDSv).strip(pldxivXC5wbTB2O8q).replace(k5bCDErUSmv,pldxivXC5wbTB2O8q).replace(k5bCDErUSmv,pldxivXC5wbTB2O8q).replace(k5bCDErUSmv,pldxivXC5wbTB2O8q)
			JZMvR4mp2rX7Kf6n += qHYIWnOZLPkrQU
			title = str(JZMvR4mp2rX7Kf6n)+TYf7Dc06PQgy1vEV9(u"ࠫ࠳ࠦࠧ࠿")+title
			if pcA1dzy7LXwGfMPg9mTkuh5tine3 not in KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j:
				uuSKUinvP4EGLxWZYmTsF.append(title)
				KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
		if KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j:
			data = zip(uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j)
			if data: PGudrhJF8iDkSq96XVHEQZYf5L(mshLJcKH1fv03yRnDOr4ZT,SbjiWeHLQPoazqwp3cODkd7YxVgn(u"࡙ࠬࡅࡓࡘࡈࡖࡘ࠭ࡀ"),BB6xwqVdZC13JQPujR2sUtz,data,Q49IsrlSuYRAVbGKhwdckLDOetF2PZ)
	uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = list(uuSKUinvP4EGLxWZYmTsF),list(KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j)
	return uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j
def QXRr9sd1gBe5Kl6vbU0cuyNZPz(url):
	if Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"࠭࠮࡮࠵ࡸ࠼ࠬࡁ") in url:
		uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = TTO3ZpWq9FCzhuMAY0RdaDIfX5kw(QQ8pvXNcBfVkP5rRJ7o,url)
		if KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j: return b8Qe150xVaJsnDSv,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j
		return ubxGUTt1LraKhVZgpAP(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡐ࠷࡚࠾ࠧࡂ"),[],[]
	return kke1PDGRBLuY8y(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫࡃ"),[b8Qe150xVaJsnDSv],[url]
def F97FYjQaNH(url):
	n92bB0YwDLqyadQRlmGW,zMaDJPY25fQK96VvUBAgxlROmI8 = [],[]
	if vvWwO3Tx2dAgcijrFXq(u"ࠩ࠲ࡺ࡮ࡪࡥࡰࡵ࠱ࡱࡵ࠺࠿ࡷ࡫ࡧࡁࠬࡄ") in url:
		b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,QQdAXWBc2GPw(u"ࠪࡋࡊ࡚ࠧࡅ"),url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,DD5cFIejQa2X4BgAu9GWPyJ3tC7,b8Qe150xVaJsnDSv,Xz3bA2PFENVCUtplu51(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡌࡃࡗࡏࡔ࡛ࡔࡆ࠯࠴ࡷࡹ࠭ࡆ"))
		if QTUBCcehw6qPd4x(u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧࡇ") in b3HKopTY9zLUyhJmt.headers:
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = b3HKopTY9zLUyhJmt.headers[LAQD5wEkr18bUiGaYen3J(u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨࡈ")]
			n92bB0YwDLqyadQRlmGW.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
			LLOCdZ3sS2enzXx4fVB18YRvbHNwky = Wl2eu1PavfQ(pcA1dzy7LXwGfMPg9mTkuh5tine3,uVQd103XyvUce2EBtzbYaC(u"ࠧ࡯ࡣࡰࡩࠬࡉ"))
			zMaDJPY25fQK96VvUBAgxlROmI8.append(LLOCdZ3sS2enzXx4fVB18YRvbHNwky)
	elif QQdAXWBc2GPw(u"ࠨ࡭ࡤࡸࡰࡵࡵࡵࡧ࠱ࡧࡴࡳࠧࡊ") in url:
		b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,ubxGUTt1LraKhVZgpAP(u"ࠩࡊࡉ࡙࠭ࡋ"),url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,mQNonhS7CV2BXOv(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡋࡂࡖࡎࡓ࡚࡚ࡅ࠮࠴ࡱࡨࠬࡌ"))
		jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
		oacnYJr1pe4iC8GdRV9hSmqMk5xg6 = YYBlm36zd0Jst18LXwo4.findall(mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠫ࠭࡫ࡶࡢ࡮࡟ࠬ࡫ࡻ࡮ࡤࡶ࡬ࡳࡳࡢࠨࡱ࠮ࡤ࠰ࡨ࠲࡫࠭ࡧ࠯ࡨࡡ࠯࠮ࠫࡁ࡟࠭ࡡ࠯ࠩ࠯࠾࠲ࡷࡨࡸࡩࡱࡶࡁࠫࡍ"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if oacnYJr1pe4iC8GdRV9hSmqMk5xg6:
			oacnYJr1pe4iC8GdRV9hSmqMk5xg6 = oacnYJr1pe4iC8GdRV9hSmqMk5xg6[LzYQg91SIxDeOGtCKd5]
			FFpgZ0heR8aA = DNnEa1tuSBAzFH57GROwxTmg2M(oacnYJr1pe4iC8GdRV9hSmqMk5xg6)
			bKQLYJ2zqvCOARBkZlaITjxVXdiu6 = YYBlm36zd0Jst18LXwo4.findall(Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠬࡹ࡯ࡶࡴࡦࡩࡸࡀࠨ࡝࡝࠱࠮ࡄࡢ࡝ࠪ࠮ࠪࡎ"),FFpgZ0heR8aA,YYBlm36zd0Jst18LXwo4.DOTALL)
			if bKQLYJ2zqvCOARBkZlaITjxVXdiu6:
				bKQLYJ2zqvCOARBkZlaITjxVXdiu6 = bKQLYJ2zqvCOARBkZlaITjxVXdiu6[LzYQg91SIxDeOGtCKd5]
				bKQLYJ2zqvCOARBkZlaITjxVXdiu6 = oJsUwXA0yGOI1mTjxQ(yST5AHEfvPmcWpwGuh2BJ(u"࠭࡬ࡪࡵࡷࠫࡏ"),bKQLYJ2zqvCOARBkZlaITjxVXdiu6)
				for dict in bKQLYJ2zqvCOARBkZlaITjxVXdiu6:
					pcA1dzy7LXwGfMPg9mTkuh5tine3 = dict[mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠧࡧ࡫࡯ࡩࠬࡐ")]
					c1EdszLx3mkb8QYX9 = dict[ubxGUTt1LraKhVZgpAP(u"ࠨ࡮ࡤࡦࡪࡲࠧࡑ")]
					n92bB0YwDLqyadQRlmGW.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
					LLOCdZ3sS2enzXx4fVB18YRvbHNwky = Wl2eu1PavfQ(pcA1dzy7LXwGfMPg9mTkuh5tine3,HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠩࡱࡥࡲ࡫ࠧࡒ"))
					zMaDJPY25fQK96VvUBAgxlROmI8.append(c1EdszLx3mkb8QYX9+pldxivXC5wbTB2O8q+LLOCdZ3sS2enzXx4fVB18YRvbHNwky)
		elif Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬࡓ") in b3HKopTY9zLUyhJmt.headers:
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = b3HKopTY9zLUyhJmt.headers[mQNonhS7CV2BXOv(u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭ࡔ")]
			n92bB0YwDLqyadQRlmGW.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
			LLOCdZ3sS2enzXx4fVB18YRvbHNwky = Wl2eu1PavfQ(pcA1dzy7LXwGfMPg9mTkuh5tine3,LAQD5wEkr18bUiGaYen3J(u"ࠬࡴࡡ࡮ࡧࠪࡕ"))
			zMaDJPY25fQK96VvUBAgxlROmI8.append(LLOCdZ3sS2enzXx4fVB18YRvbHNwky)
		if Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"࠭࠿ࡶࡴ࡯ࡁ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡶࡨࡰࡶࡲࡷ࠳ࡧࡰࡱ࠰ࡪࡳࡴ࠭ࡖ") in url:
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = url.split(QTUBCcehw6qPd4x(u"ࠧࡀࡷࡵࡰࡂ࠭ࡗ"))[qHYIWnOZLPkrQU]
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3.split(kke1PDGRBLuY8y(u"ࠨࠨࠪࡘ"))[LzYQg91SIxDeOGtCKd5]
			if pcA1dzy7LXwGfMPg9mTkuh5tine3:
				n92bB0YwDLqyadQRlmGW.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
				zMaDJPY25fQK96VvUBAgxlROmI8.append(shC5qBRV2A0lZ(u"ࠩࡳ࡬ࡴࡺ࡯ࡴࠢࡪࡳࡴ࡭࡬ࡦ࡙ࠩ"))
	else:
		n92bB0YwDLqyadQRlmGW.append(url)
		LLOCdZ3sS2enzXx4fVB18YRvbHNwky = Wl2eu1PavfQ(url,BmePGjS7FxK6kutUM(u"ࠪࡲࡦࡳࡥࠨ࡚"))
		zMaDJPY25fQK96VvUBAgxlROmI8.append(LLOCdZ3sS2enzXx4fVB18YRvbHNwky)
	if not n92bB0YwDLqyadQRlmGW: return yST5AHEfvPmcWpwGuh2BJ(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡋࡂࡖࡎࡓ࡚࡚ࡅࠨ࡛"),[],[]
	elif len(n92bB0YwDLqyadQRlmGW)==qHYIWnOZLPkrQU: pcA1dzy7LXwGfMPg9mTkuh5tine3 = n92bB0YwDLqyadQRlmGW[LzYQg91SIxDeOGtCKd5]
	else:
		cMZGTsAR2E = XXprCMzuNP2mElUxfdA(QQdAXWBc2GPw(u"ࠬษฮหำࠣห้๋ไโࠢส่๊์วิสࠪ࡜"),zMaDJPY25fQK96VvUBAgxlROmI8)
		if cMZGTsAR2E==-qHYIWnOZLPkrQU: return vvWwO3Tx2dAgcijrFXq(u"࠭ࡅ࡙ࡋࡗࡣࡆࡒࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ࡝"),[],[]
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = n92bB0YwDLqyadQRlmGW[cMZGTsAR2E]
	return zI3ROAZtiUq42rE9WDST68(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ࡞"),[b8Qe150xVaJsnDSv],[pcA1dzy7LXwGfMPg9mTkuh5tine3]
def DQsl3U5MwSgh0VPy71k9RjbxpmAa(url):
	headers = {dDYUoKi6JFM23p(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ࡟"):LAQD5wEkr18bUiGaYen3J(u"ࠩࡎࡳࡩ࡯࠯ࠨࡠ")+str(g1gmkxOtc2oeEZHhBiy)}
	for s9s45taoNBh60XL1zykOmTK3jJCrE in range(ddo23ZJtgcY(u"࠺࠶෩")):
		wLQCTr5lqbsVYeAHdzfhZ1F.sleep(ubxGUTt1LraKhVZgpAP(u"࠶࠮࠲࠲࠳෪"))
		b3HKopTY9zLUyhJmt = Ndw0b1s4ayCoqxtkES3i2(SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠪࡋࡊ࡚ࠧࡡ"),url,b8Qe150xVaJsnDSv,headers,DD5cFIejQa2X4BgAu9GWPyJ3tC7,b8Qe150xVaJsnDSv,Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡈࡑࡒࡋࡑࡋࡕࡔࡇࡕࡇࡔࡔࡔࡆࡐࡗ࠱࠶ࡹࡴࠨࡢ"))
		if dDYUoKi6JFM23p(u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧࡣ") in list(b3HKopTY9zLUyhJmt.headers.keys()):
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = b3HKopTY9zLUyhJmt.headers[SbjiWeHLQPoazqwp3cODkd7YxVgn(u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨࡤ")]
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3+uVQd103XyvUce2EBtzbYaC(u"ࠧࡽࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࡂ࠭ࡥ")+headers[QQdAXWBc2GPw(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬࡦ")]
			return b8Qe150xVaJsnDSv,[b8Qe150xVaJsnDSv],[pcA1dzy7LXwGfMPg9mTkuh5tine3]
		if b3HKopTY9zLUyhJmt.code!=UUkIBz1sgQ9WfNeG6trKXvu0(u"࠴࠳࠻෫"): break
	return yST5AHEfvPmcWpwGuh2BJ(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡌࡕࡏࡈࡎࡈ࡙ࡘࡋࡒࡄࡑࡑࡘࡊࡔࡔࠨࡧ"),[],[]
def ndgtjkPiCI0qJ7NbzUlma3p2B6(url):
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,TYf7Dc06PQgy1vEV9(u"ࠪࡋࡊ࡚ࠧࡨ"),url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,LAQD5wEkr18bUiGaYen3J(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡑࡊࡒࡘࡔ࡙ࡇࡐࡑࡊࡐࡊ࠳࠱ࡴࡶࠪࡩ"))
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	pcA1dzy7LXwGfMPg9mTkuh5tine3 = YYBlm36zd0Jst18LXwo4.findall(Nh0BWuiSndf(u"ࠬࠨࠨࡩࡶࡷࡴࡸࡀ࠯࠰ࡸ࡬ࡨࡪࡵ࠭ࡥࡱࡺࡲࡱࡵࡡࡥࡵ࠱࠮ࡄ࠯ࠢ࠭࠰࠭ࡃ࠱࠴ࠪࡀ࠮ࠫ࠲࠯ࡅࠩ࠭ࠩࡪ"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if pcA1dzy7LXwGfMPg9mTkuh5tine3:
		pcA1dzy7LXwGfMPg9mTkuh5tine3,c1EdszLx3mkb8QYX9 = pcA1dzy7LXwGfMPg9mTkuh5tine3[LzYQg91SIxDeOGtCKd5]
		return b8Qe150xVaJsnDSv,[c1EdszLx3mkb8QYX9],[pcA1dzy7LXwGfMPg9mTkuh5tine3]
	return TYf7Dc06PQgy1vEV9(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡒࡋࡓ࡙ࡕࡓࡈࡑࡒࡋࡑࡋࠧ࡫"),[],[]
def ig8IlBb9uH(url):
	if TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠧ࠰ࡹࡨࡩࡵ࡯ࡳ࠰ࠩ࡬") in url:
		b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(LtlXH3fvMydAx,SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠨࡉࡈࡘࠬ࡭"),url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,kke1PDGRBLuY8y(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡝ࡅࡄࡋࡐࡅ࠷࠳࠱ࡴࡶࠪ࡮"))
		jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = YYBlm36zd0Jst18LXwo4.findall(Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡷࡵࡢ࡮࡬ࡸࡾࡄࠧ࡯"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if pcA1dzy7LXwGfMPg9mTkuh5tine3: url = pcA1dzy7LXwGfMPg9mTkuh5tine3[LzYQg91SIxDeOGtCKd5]
		else: return VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡗࡆࡅࡌࡑࡆ࠸ࠧࡰ"),[],[]
	return Nh0BWuiSndf(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨࡱ"),[b8Qe150xVaJsnDSv],[url]
def dR3IXFnWwevCsSBiTM1uAl(url):
	bqCG6DEkf705Z9enS4pmN2,zMaDJPY25fQK96VvUBAgxlROmI8,n92bB0YwDLqyadQRlmGW = b8Qe150xVaJsnDSv,[],[]
	if Nh0BWuiSndf(u"࠭࠯ࡥࡱࡺࡲࡱࡵࡡࡥ࠱ࠪࡲ") in url:
		b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(LtlXH3fvMydAx,RRIHDFjoW9w7bSfVPhC(u"ࠧࡈࡇࡗࠫࡳ"),url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,DD5cFIejQa2X4BgAu9GWPyJ3tC7,RRIHDFjoW9w7bSfVPhC(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡖ࡜ࡉࡅ࠯࠴ࡷࡹ࠭ࡴ"))
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = b3HKopTY9zLUyhJmt.url
		if pcA1dzy7LXwGfMPg9mTkuh5tine3: bqCG6DEkf705Z9enS4pmN2,zMaDJPY25fQK96VvUBAgxlROmI8,n92bB0YwDLqyadQRlmGW = b8Qe150xVaJsnDSv,[b8Qe150xVaJsnDSv],[pcA1dzy7LXwGfMPg9mTkuh5tine3]
	elif UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠩࡶࡩࡷࡼ࠽ࠨࡵ") in url:
		b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(LtlXH3fvMydAx,SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠪࡋࡊ࡚ࠧࡶ"),url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,m6hwdgP31a2zjN7lkpX(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡒࡘࡌࡈ࠲࠸࡮ࡥࠩࡷ"))
		jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = YYBlm36zd0Jst18LXwo4.findall(LAQD5wEkr18bUiGaYen3J(u"ࠬࡂࡩࡧࡴࡤࡱࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫࡸ"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if pcA1dzy7LXwGfMPg9mTkuh5tine3: url = pcA1dzy7LXwGfMPg9mTkuh5tine3[LzYQg91SIxDeOGtCKd5]
		else:
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = YYBlm36zd0Jst18LXwo4.findall(LAQD5wEkr18bUiGaYen3J(u"ࠨࡁ࡭ࡤࡤࡔࡱࡧࡹࡦࡴࡆࡳࡳࡺࡲࡰ࡮࡟ࠬࠬ࠮࠮ࠫࡁࠬࠫࠧࡹ"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
			if pcA1dzy7LXwGfMPg9mTkuh5tine3:
				url = pcA1dzy7LXwGfMPg9mTkuh5tine3[LzYQg91SIxDeOGtCKd5]
				url = lnFeUkiZtQ7E1.b64decode(url)
				if i1thmHk7AZquD4cM0fnp62: url = url.decode(OVauxZzLI10vcXT74K)
			else: return BWNPxIG7vqdTy85pjHzUOrK3(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡔ࡚ࡎࡊࠧࡺ"),[],[]
		bqCG6DEkf705Z9enS4pmN2,zMaDJPY25fQK96VvUBAgxlROmI8,n92bB0YwDLqyadQRlmGW = QTUBCcehw6qPd4x(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫࡻ"),[b8Qe150xVaJsnDSv],[url]
	else:
		b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,QTUBCcehw6qPd4x(u"ࠩࡊࡉ࡙࠭ࡼ"),url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,Nh0BWuiSndf(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡑࡗࡋࡇ࠱࠸ࡸࡤࠨࡽ"))
		jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall(Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠫࠧࡧࡰ࡭ࡴ࠰ࡱࡪࡴࡵࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬࡾ"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if ZV5rRvabhxJ:
			OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[RRIHDFjoW9w7bSfVPhC(u"࠱෬")]
			items = YYBlm36zd0Jst18LXwo4.findall(SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨࡿ"),OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
			for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
				zMaDJPY25fQK96VvUBAgxlROmI8.append(title)
				n92bB0YwDLqyadQRlmGW.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
	return bqCG6DEkf705Z9enS4pmN2,zMaDJPY25fQK96VvUBAgxlROmI8,n92bB0YwDLqyadQRlmGW
def zzypDIMWSQ(url):
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(LtlXH3fvMydAx,SbjiWeHLQPoazqwp3cODkd7YxVgn(u"࠭ࡇࡆࡖࠪࢀ"),url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,DYakr9g4PVU(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡊࡆ࡙ࡅࡍࡊࡇ࠵࠲࠷ࡳࡵࠩࢁ"))
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	jLtdbeYiQHnf4SpU2MTly = KvkLRyF6ahWxpPGX4cn(jLtdbeYiQHnf4SpU2MTly)
	pcA1dzy7LXwGfMPg9mTkuh5tine3 = YYBlm36zd0Jst18LXwo4.findall(yST5AHEfvPmcWpwGuh2BJ(u"ࠨࠤࡩ࡭ࡱ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩࢂ"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if pcA1dzy7LXwGfMPg9mTkuh5tine3: return b8Qe150xVaJsnDSv,[b8Qe150xVaJsnDSv],[pcA1dzy7LXwGfMPg9mTkuh5tine3[LzYQg91SIxDeOGtCKd5]]
	return dDYUoKi6JFM23p(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡋࡇࡓࡆࡎࡋࡈ࠶࠭ࢃ"),[],[]
def D5SKEimOC4(url):
	if len(url)>LAQD5wEkr18bUiGaYen3J(u"࠴࠳࠴෭"):
		url = url.strip(HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠪ࠳ࠬࢄ"))+kke1PDGRBLuY8y(u"ࠫ࠴࠭ࢅ")
		b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(LtlXH3fvMydAx,Mmpr0o76iWJvz1kTtfgI8hES(u"ࠬࡍࡅࡕࠩࢆ"),url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡏࡅࡗࡕ࡚ࡂ࠯࠴ࡷࡹ࠭ࢇ"))
		jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
		if LzYQg91SIxDeOGtCKd5 and ddo23ZJtgcY(u"ࠧࡧࡷࡱࡧࡹ࡯࡯࡯ࠪ࡫࠰ࡺ࠲࡮࠭ࡶ࠯ࡩ࠱ࡸࠩࠨ࢈") in jLtdbeYiQHnf4SpU2MTly:
			ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall(shC5qBRV2A0lZ(u"ࠨࠤ࡯ࡳࡦࡪࡥࡳࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧࢉ"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
			if ZV5rRvabhxJ:
				OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"࠳෮")]
				ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall(HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠩ࠿ࡷࡨࡸࡩࡱࡶࡁࡺࡦࡸࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡤࡴ࡬ࡴࡹ࠭ࢊ"),OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
				if ZV5rRvabhxJ:
					OTKx7aVb2hdS16Wrweky4FXfIN0g9 = WaSXqRbONY5mQEZ(ZV5rRvabhxJ[HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"࠴෯")])
		elif len(jLtdbeYiQHnf4SpU2MTly)<Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"࠹࠶࠰෰"): pcA1dzy7LXwGfMPg9mTkuh5tine3 = jLtdbeYiQHnf4SpU2MTly
		else: return HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡒࡁࡓࡑ࡝ࡅࠬࢋ"),[],[]
		return Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠫࠬࢌ"),[b8Qe150xVaJsnDSv],[pcA1dzy7LXwGfMPg9mTkuh5tine3]
	return BmePGjS7FxK6kutUM(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨࢍ"),[b8Qe150xVaJsnDSv],[url]
def d4dNXL87qj(url):
	if Mmpr0o76iWJvz1kTtfgI8hES(u"࠭࠯ࡥࡱࡺࡲ࠳ࡶࡨࡱࠩࢎ") in url:
		b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(LtlXH3fvMydAx,ddo23ZJtgcY(u"ࠧࡈࡇࡗࠫ࢏"),url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,Mmpr0o76iWJvz1kTtfgI8hES(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡘࡎࡏࡇࡊࡄ࠱࠶ࡹࡴࠨ࢐"))
		jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = YYBlm36zd0Jst18LXwo4.findall(HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠩࡹ࡭ࡩ࡫࡯࠮ࡹࡵࡥࡵࡶࡥࡳ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ࢑"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		url = pcA1dzy7LXwGfMPg9mTkuh5tine3[LzYQg91SIxDeOGtCKd5]
	return BWNPxIG7vqdTy85pjHzUOrK3(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭࢒"),[b8Qe150xVaJsnDSv],[url]
def dzqHvb2nFt(url):
	if TYf7Dc06PQgy1vEV9(u"ࠫࡸ࡫ࡲࡷࡧࡵ࠲ࡵ࡮ࡰࠨ࢓") in url:
		b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(LtlXH3fvMydAx,Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠬࡍࡅࡕࠩ࢔"),url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡆࡍࡒࡇ࠴ࡖ࠯࠴ࡷࡹ࠭࢕"))
		jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = YYBlm36zd0Jst18LXwo4.findall(mQNonhS7CV2BXOv(u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ࢖"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3[LzYQg91SIxDeOGtCKd5]
		if DYakr9g4PVU(u"ࠨࡪࡷࡸࡵ࠭ࢗ") in pcA1dzy7LXwGfMPg9mTkuh5tine3: return HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ࢘"),[b8Qe150xVaJsnDSv],[pcA1dzy7LXwGfMPg9mTkuh5tine3]
		return IjZbnrBJmM2N(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡉࡉࡎࡃ࠷࡙࢙ࠬ"),[],[]
	return SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࢚ࠧ"),[b8Qe150xVaJsnDSv],[url]
def P98kZm1TK7(url):
	MUJCtfYVBLODrFbaZn,EEkjQFxOabod08Nr = FNIhDd4uLfev0q5YHVGx8oWm6CsiJ(url)
	ybF0H85nUohsiRQcpaTfZAKzjMY7wB = {S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠬ࡞࠭ࡓࡧࡴࡹࡪࡹࡴࡦࡦ࠰࡛࡮ࡺࡨࠨ࢛"):mQNonhS7CV2BXOv(u"࠭ࡘࡎࡎࡋࡸࡹࡶࡒࡦࡳࡸࡩࡸࡺࠧ࢜"),yST5AHEfvPmcWpwGuh2BJ(u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭࢝"):Xz3bA2PFENVCUtplu51(u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪ࠻ࠡࡥ࡫ࡥࡷࡹࡥࡵ࠿ࡘࡘࡋ࠳࠸ࠨ࢞")}
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,kke1PDGRBLuY8y(u"ࠩࡓࡓࡘ࡚ࠧ࢟"),MUJCtfYVBLODrFbaZn,EEkjQFxOabod08Nr,ybF0H85nUohsiRQcpaTfZAKzjMY7wB,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,Nh0BWuiSndf(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅࡈ࡛ࡑࡓ࡜࠳࠱ࡴࡶࠪࢠ"))
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	pcA1dzy7LXwGfMPg9mTkuh5tine3 = YYBlm36zd0Jst18LXwo4.findall(Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩࢡ"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if not pcA1dzy7LXwGfMPg9mTkuh5tine3: return Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡆࡉ࡜ࡒࡔ࡝ࠧࢢ"),[],[]
	pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3[LzYQg91SIxDeOGtCKd5]
	return S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩࢣ"),[b8Qe150xVaJsnDSv],[pcA1dzy7LXwGfMPg9mTkuh5tine3]
def AXH64EOWgQ(url):
	headers = {Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"࡙ࠧ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪࠪࢤ"):dDYUoKi6JFM23p(u"ࠨ࡚ࡐࡐࡍࡺࡴࡱࡔࡨࡵࡺ࡫ࡳࡵࠩࢥ")}
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,BmePGjS7FxK6kutUM(u"ࠩࡊࡉ࡙࠭ࢦ"),url,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡓࡉࡑࡒࡊࡕࡘࡏ࠮࠳ࡶࡸࠬࢧ"))
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	pcA1dzy7LXwGfMPg9mTkuh5tine3 = YYBlm36zd0Jst18LXwo4.findall(RRIHDFjoW9w7bSfVPhC(u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩࢨ"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL|YYBlm36zd0Jst18LXwo4.IGNORECASE)
	if not pcA1dzy7LXwGfMPg9mTkuh5tine3: return HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡔࡊࡒࡓࡋࡖࡒࡐࠩࢩ"),[],[]
	pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3[LzYQg91SIxDeOGtCKd5]
	return HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩࢪ"),[b8Qe150xVaJsnDSv],[pcA1dzy7LXwGfMPg9mTkuh5tine3]
def mQAFeP4aYr(url):
	MUJCtfYVBLODrFbaZn,EEkjQFxOabod08Nr = FNIhDd4uLfev0q5YHVGx8oWm6CsiJ(url)
	ybF0H85nUohsiRQcpaTfZAKzjMY7wB = {QTUBCcehw6qPd4x(u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭ࢫ"):m6hwdgP31a2zjN7lkpX(u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪ࠻ࠡࡥ࡫ࡥࡷࡹࡥࡵ࠿ࡘࡘࡋ࠳࠸ࠨࢬ")}
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,vvWwO3Tx2dAgcijrFXq(u"ࠩࡓࡓࡘ࡚ࠧࢭ"),MUJCtfYVBLODrFbaZn,EEkjQFxOabod08Nr,ybF0H85nUohsiRQcpaTfZAKzjMY7wB,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,uVQd103XyvUce2EBtzbYaC(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡈࡂࡎࡄࡇࡎࡓࡁ࠮࠳ࡶࡸࠬࢮ"))
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	pcA1dzy7LXwGfMPg9mTkuh5tine3 = YYBlm36zd0Jst18LXwo4.findall(Nh0BWuiSndf(u"ࠫࠬ࠭࠼ࡪࡨࡵࡥࡲ࡫ࠠࡴࡴࡦࡁࡠࠨࠧ࡞ࠪ࠱࠮ࡄ࠯࡛ࠣࠩࡠࠫࠬ࠭ࢯ"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL|YYBlm36zd0Jst18LXwo4.IGNORECASE)
	if not pcA1dzy7LXwGfMPg9mTkuh5tine3: return yST5AHEfvPmcWpwGuh2BJ(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡉࡃࡏࡅࡈࡏࡍࡂࠩࢰ"),[],[]
	pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3[LzYQg91SIxDeOGtCKd5]
	if ddo23ZJtgcY(u"࠭ࡨࡵࡶࡳࠫࢱ") not in pcA1dzy7LXwGfMPg9mTkuh5tine3: pcA1dzy7LXwGfMPg9mTkuh5tine3 = shC5qBRV2A0lZ(u"ࠧࡩࡶࡷࡴ࠿࠭ࢲ")+pcA1dzy7LXwGfMPg9mTkuh5tine3
	return RRIHDFjoW9w7bSfVPhC(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫࢳ"),[b8Qe150xVaJsnDSv],[pcA1dzy7LXwGfMPg9mTkuh5tine3]
def movfiGTFn2(url):
	eiFs3pQPyZtjb0W,zMaDJPY25fQK96VvUBAgxlROmI8,n92bB0YwDLqyadQRlmGW = url,[],[]
	if SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠩ࠲ࡥ࡯ࡧࡸ࠰ࠩࢴ") in url:
		MUJCtfYVBLODrFbaZn,EEkjQFxOabod08Nr = FNIhDd4uLfev0q5YHVGx8oWm6CsiJ(url)
		ybF0H85nUohsiRQcpaTfZAKzjMY7wB = {Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩࢵ"):m6hwdgP31a2zjN7lkpX(u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦ࠾ࠤࡨ࡮ࡡࡳࡵࡨࡸࡂ࡛ࡔࡇ࠯࠻ࠫࢶ")}
		b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,zI3ROAZtiUq42rE9WDST68(u"ࠬࡖࡏࡔࡖࠪࢷ"),MUJCtfYVBLODrFbaZn,EEkjQFxOabod08Nr,ybF0H85nUohsiRQcpaTfZAKzjMY7wB,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,shC5qBRV2A0lZ(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡆࡍࡒࡇࡁࡃࡆࡒ࠱࠶ࡹࡴࠨࢸ"))
		jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
		p5FQgfzqT2tI = YYBlm36zd0Jst18LXwo4.findall(TYf7Dc06PQgy1vEV9(u"ࠧࠨࠩ࠿࡭࡫ࡸࡡ࡮ࡧ࠱࠮ࡄࡹࡲࡤ࠿࡞ࠦࠬࡣࠨ࠯ࠬࡂ࠭ࡠࠨࠧ࡞ࠩࠪࠫࢹ"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL|YYBlm36zd0Jst18LXwo4.IGNORECASE)
		if p5FQgfzqT2tI: eiFs3pQPyZtjb0W = p5FQgfzqT2tI[LzYQg91SIxDeOGtCKd5]
	return yST5AHEfvPmcWpwGuh2BJ(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫࢺ"),[b8Qe150xVaJsnDSv],[eiFs3pQPyZtjb0W]
def X3cLRkjer9(url):
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,LAQD5wEkr18bUiGaYen3J(u"ࠩࡊࡉ࡙࠭ࢻ"),url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡔࡗࡈࡘࡒ࠲࠷ࡳࡵࠩࢼ"))
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	kmLoCgs8EqXG = YYBlm36zd0Jst18LXwo4.findall(SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠦࡻࡧࡲࠡࡨࡶࡩࡷࡼࠠ࠾࠰࠭ࡃࠬ࠮࠮ࠫࡁࠬࠫࠧࢽ"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL|YYBlm36zd0Jst18LXwo4.IGNORECASE)
	if kmLoCgs8EqXG:
		kmLoCgs8EqXG = kmLoCgs8EqXG[LzYQg91SIxDeOGtCKd5][QTUBCcehw6qPd4x(u"࠸෱"):]
		kmLoCgs8EqXG = lnFeUkiZtQ7E1.b64decode(kmLoCgs8EqXG)
		if i1thmHk7AZquD4cM0fnp62: kmLoCgs8EqXG = kmLoCgs8EqXG.decode(OVauxZzLI10vcXT74K)
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = YYBlm36zd0Jst18LXwo4.findall(kke1PDGRBLuY8y(u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪࢾ"),kmLoCgs8EqXG,YYBlm36zd0Jst18LXwo4.DOTALL)
	else: pcA1dzy7LXwGfMPg9mTkuh5tine3 = b8Qe150xVaJsnDSv
	if not pcA1dzy7LXwGfMPg9mTkuh5tine3: return TYf7Dc06PQgy1vEV9(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡖ࡙ࡊ࡚ࡔࠧࢿ"),[],[]
	pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3[LzYQg91SIxDeOGtCKd5]
	if BWNPxIG7vqdTy85pjHzUOrK3(u"ࠧࡩࡶࡷࡴࠬࣀ") not in pcA1dzy7LXwGfMPg9mTkuh5tine3: pcA1dzy7LXwGfMPg9mTkuh5tine3 = m6hwdgP31a2zjN7lkpX(u"ࠨࡪࡷࡸࡵࡀࠧࣁ")+pcA1dzy7LXwGfMPg9mTkuh5tine3
	return Xz3bA2PFENVCUtplu51(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬࣂ"),[b8Qe150xVaJsnDSv],[pcA1dzy7LXwGfMPg9mTkuh5tine3]
def KaueH6Yb8Sq(url):
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(LtlXH3fvMydAx,DYakr9g4PVU(u"ࠪࡋࡊ࡚ࠧࣃ"),url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡎ࡛ࡈࡋ࡞࡜ࡉࡑ࠯࠴ࡷࡹ࠭ࣄ"))
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	pcA1dzy7LXwGfMPg9mTkuh5tine3 = YYBlm36zd0Jst18LXwo4.findall(TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡩ࡯࡭࠯ࡶࡱ࠲࠷࠲ࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪࣅ"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if not pcA1dzy7LXwGfMPg9mTkuh5tine3: return yST5AHEfvPmcWpwGuh2BJ(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡏ࡜ࡉࡌ࡟ࡖࡊࡒࠪࣆ"),[],[]
	pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3[LzYQg91SIxDeOGtCKd5]
	return VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪࣇ"),[b8Qe150xVaJsnDSv],[pcA1dzy7LXwGfMPg9mTkuh5tine3]
def PWzLngkZar(url):
	id = url.split(LAQD5wEkr18bUiGaYen3J(u"ࠨ࠱ࠪࣈ"))[-vvWwO3Tx2dAgcijrFXq(u"࠱ෲ")]
	if HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠩ࠲ࡩࡲࡨࡥࡥࠩࣉ") in url: url = url.replace(P0qdZI384LKleuo(u"ࠪ࠳ࡪࡳࡢࡦࡦࠪ࣊"),b8Qe150xVaJsnDSv)
	url = url.replace(dDYUoKi6JFM23p(u"ࠫ࠳ࡩ࡯࡮࠱ࠪ࣋"),Xz3bA2PFENVCUtplu51(u"ࠬ࠴ࡣࡰ࡯࠲ࡴࡱࡧࡹࡦࡴ࠲ࡱࡪࡺࡡࡥࡣࡷࡥ࠴࠭࣌"))
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(LtlXH3fvMydAx,uVQd103XyvUce2EBtzbYaC(u"࠭ࡇࡆࡖࠪ࣍"),url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,mQNonhS7CV2BXOv(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮࠳ࡶࡸࠬ࣎"))
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	bqCG6DEkf705Z9enS4pmN2 = Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎࠨ࣏")
	ixWk65EnU8pIA1S3FJCZTsuLjg7m = YYBlm36zd0Jst18LXwo4.findall(HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠩࠥࡩࡷࡸ࡯ࡳࠤ࠱࠮ࡄࠨ࡭ࡦࡵࡶࡥ࡬࡫ࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࣐ࠪ"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ixWk65EnU8pIA1S3FJCZTsuLjg7m: bqCG6DEkf705Z9enS4pmN2 = ixWk65EnU8pIA1S3FJCZTsuLjg7m[LzYQg91SIxDeOGtCKd5]
	url = YYBlm36zd0Jst18LXwo4.findall(zI3ROAZtiUq42rE9WDST68(u"ࠪࡼ࠲ࡳࡰࡦࡩࡘࡖࡑࠨࠬࠣࡷࡵࡰࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨ࣑ࠧ"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if not url and bqCG6DEkf705Z9enS4pmN2:
		return bqCG6DEkf705Z9enS4pmN2,[],[]
	pcA1dzy7LXwGfMPg9mTkuh5tine3 = url[LzYQg91SIxDeOGtCKd5].replace(Mmpr0o76iWJvz1kTtfgI8hES(u"ࠫࡡࡢ࣒ࠧ"),b8Qe150xVaJsnDSv)
	vvnQALE5cIPDKXWxUktGwg,BB6xwqVdZC13JQPujR2sUtz = TTO3ZpWq9FCzhuMAY0RdaDIfX5kw(QQ8pvXNcBfVkP5rRJ7o,pcA1dzy7LXwGfMPg9mTkuh5tine3)
	SxJIWAMj86cQms5agzf0 = hRWC8YSFvsm4JHOMVIne3jquZ.getSetting(QTUBCcehw6qPd4x(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡤ࡬ࡸࡷࡧࡴࡦ࣓ࠩ"))
	if SxJIWAMj86cQms5agzf0 and dDYUoKi6JFM23p(u"࠭࠭ࠨࣔ") not in SxJIWAMj86cQms5agzf0: title,pcA1dzy7LXwGfMPg9mTkuh5tine3 = vvnQALE5cIPDKXWxUktGwg[mmcNLrXtzfpyCkZlvK5VwG2gujh(u"࠱ෳ")],BB6xwqVdZC13JQPujR2sUtz[mmcNLrXtzfpyCkZlvK5VwG2gujh(u"࠱ෳ")]
	else:
		OwIo2yinF3kgHC5xVa = YYBlm36zd0Jst18LXwo4.findall(ubxGUTt1LraKhVZgpAP(u"ࠧࠣࡱࡺࡲࡪࡸࠢ࠻࡞ࡾࠦ࡮ࡪࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡹࡣࡳࡧࡨࡲࡳࡧ࡭ࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠰ࠧࡻࡲ࡭ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫࣕ"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if OwIo2yinF3kgHC5xVa: fGRmqVhgPldtewY,IW6sw9pPOoLNFYSMxbBrg,PPdHo9ACR2kTF = OwIo2yinF3kgHC5xVa[LzYQg91SIxDeOGtCKd5]
		else: fGRmqVhgPldtewY,IW6sw9pPOoLNFYSMxbBrg,PPdHo9ACR2kTF = b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv
		PPdHo9ACR2kTF = PPdHo9ACR2kTF.replace(mQNonhS7CV2BXOv(u"ࠨ࡞࠲ࠫࣖ"),UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠩ࠲ࠫࣗ"))
		IW6sw9pPOoLNFYSMxbBrg = ggtn0PzV7aMe(IW6sw9pPOoLNFYSMxbBrg)
		uuSKUinvP4EGLxWZYmTsF = [rC3Tlno96KjLDIvBaSWUbR8+TYf7Dc06PQgy1vEV9(u"ࠪࡓ࡜ࡔࡅࡓ࠼ࠣࠤࠬࣘ")+IW6sw9pPOoLNFYSMxbBrg+hAIp8kmC36T5WFPMSXOwnNbtD]+vvnQALE5cIPDKXWxUktGwg
		KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = [PPdHo9ACR2kTF]+BB6xwqVdZC13JQPujR2sUtz
		cMZGTsAR2E = XXprCMzuNP2mElUxfdA(TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠫฬิสาࠢส่๊๊แࠡษ็้๋อำษ࠼ࠣࠬࠬࣙ")+str(len(KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j)-yST5AHEfvPmcWpwGuh2BJ(u"࠳෴"))+BmePGjS7FxK6kutUM(u"ࠬࠦๅๅใࠬࠫࣚ"),uuSKUinvP4EGLxWZYmTsF)
		if cMZGTsAR2E==-qHYIWnOZLPkrQU: return m6hwdgP31a2zjN7lkpX(u"࠭ࡅ࡙ࡋࡗࡣࡆࡒࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫࣛ"),[],[]
		elif cMZGTsAR2E==LzYQg91SIxDeOGtCKd5:
			KcilsSDN8VIo7PF = Pft6y0LvwSh48iYg7b.argv[LzYQg91SIxDeOGtCKd5]+P0qdZI384LKleuo(u"ࠧࡀࡶࡼࡴࡪࡃࡦࡰ࡮ࡧࡩࡷࠬ࡭ࡰࡦࡨࡁ࠹࠶࠲ࠧࡷࡵࡰࡂ࠭ࣜ")+PPdHo9ACR2kTF+Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠨࠨࡷࡩࡽࡺࡴ࠾ࠩࣝ")+IW6sw9pPOoLNFYSMxbBrg
			uuxVm0bTwdnCUAL4s6NKHEBF3M.executebuiltin(SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠤࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳࡛ࡰࡥࡣࡷࡩ࠭ࠨࣞ")+KcilsSDN8VIo7PF+zI3ROAZtiUq42rE9WDST68(u"ࠥ࠭ࠧࣟ"))
			return HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠫࡊ࡞ࡉࡕࡡࡄࡐࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ࣠"),[],[]
		title,pcA1dzy7LXwGfMPg9mTkuh5tine3 = uuSKUinvP4EGLxWZYmTsF[cMZGTsAR2E],KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j[cMZGTsAR2E]
	return b8Qe150xVaJsnDSv,[title],[pcA1dzy7LXwGfMPg9mTkuh5tine3]
def q7STAvBNhV(pcA1dzy7LXwGfMPg9mTkuh5tine3):
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(LtlXH3fvMydAx,BWNPxIG7vqdTy85pjHzUOrK3(u"ࠬࡍࡅࡕࠩ࣡"),pcA1dzy7LXwGfMPg9mTkuh5tine3,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,IjZbnrBJmM2N(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡅࡓࡐࡘࡁ࠮࠳ࡶࡸࠬ࣢"))
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	if TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠧ࠯࡬ࡶࡳࡳࣣ࠭") in pcA1dzy7LXwGfMPg9mTkuh5tine3: url = YYBlm36zd0Jst18LXwo4.findall(zI3ROAZtiUq42rE9WDST68(u"ࠨࠤࡶࡶࡨࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨࣤ"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	else: url = YYBlm36zd0Jst18LXwo4.findall(Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠩࡶࡳࡺࡸࡣࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧࣥ"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if not url: return vvWwO3Tx2dAgcijrFXq(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡈࡏࡌࡔࡄࣦࠫ"),[],[]
	url = url[LzYQg91SIxDeOGtCKd5]
	if Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠫ࡭ࡺࡴࡱࠩࣧ") not in url: url = P0qdZI384LKleuo(u"ࠬ࡮ࡴࡵࡲ࠽ࠫࣨ")+url
	return b8Qe150xVaJsnDSv,[b8Qe150xVaJsnDSv],[url]
def mTrHl15VxQFAqCX(url):
	headers = { DYakr9g4PVU(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࣩࠪ") : b8Qe150xVaJsnDSv }
	if UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠧࡰࡲࡀࡨࡴࡽ࡮࡭ࡱࡤࡨࡤࡵࡲࡪࡩࠪ࣪") in url:
		jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(LtlXH3fvMydAx,url,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡒࡕࡓࡉࡃࡋࡈࡆ࠳࠱ࡴࡶࠪ࣫"))
		items = YYBlm36zd0Jst18LXwo4.findall(shC5qBRV2A0lZ(u"ࠩࡧ࡭ࡷ࡫ࡣࡵࠢ࡯࡭ࡳࡱ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ࣬"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if items: return b8Qe150xVaJsnDSv,[b8Qe150xVaJsnDSv],[items[LzYQg91SIxDeOGtCKd5]]
		else:
			A4gdSTQDP2FyBIVuba85RvYqKU = YYBlm36zd0Jst18LXwo4.findall(TYf7Dc06PQgy1vEV9(u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡩࡷࡸࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ࣭"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
			if A4gdSTQDP2FyBIVuba85RvYqKU:
				tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,Mmpr0o76iWJvz1kTtfgI8hES(u"ࠫึูวๅห้๋ࠣࠦวๅ็๋ๆ฾ࠦวๅษุ่๏࣮࠭"),A4gdSTQDP2FyBIVuba85RvYqKU[LzYQg91SIxDeOGtCKd5])
				return Xz3bA2PFENVCUtplu51(u"ࠬࡋࡲࡳࡱࡵ࠾࣯ࠥ࠭")+A4gdSTQDP2FyBIVuba85RvYqKU[LzYQg91SIxDeOGtCKd5],[],[]
	else:
		WUj71fhxld3rqONpBzmEuC = kke1PDGRBLuY8y(u"࠭࡭ࡰࡸ࡬ࡾࡱࡧ࡮ࡥࣰࠩ")
		jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(LtlXH3fvMydAx,url,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡑࡔ࡙ࡈࡂࡊࡇࡅ࠲࠸࡮ࡥࣱࠩ"))
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall(BWNPxIG7vqdTy85pjHzUOrK3(u"ࠨࡈࡲࡶࡲࠦ࡭ࡦࡶ࡫ࡳࡩࡃࠢࡑࡑࡖࡘࠧࠦࡡࡤࡶ࡬ࡳࡳࡃ࡜ࠨࠪ࠱࠮ࡄ࠯࡜ࠨࠪ࠱࠮ࡄ࠯ࡤࡪࡸࣲࠪ"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if not ZV5rRvabhxJ: return SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡒࡕࡓࡉࡃࡋࡈࡆ࠭ࣳ"),[],[]
		eiFs3pQPyZtjb0W = ZV5rRvabhxJ[LzYQg91SIxDeOGtCKd5][LzYQg91SIxDeOGtCKd5]
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[LzYQg91SIxDeOGtCKd5][qHYIWnOZLPkrQU]
		if S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠪ࠲ࡷࡧࡲࠨࣴ") in OTKx7aVb2hdS16Wrweky4FXfIN0g9 or uVQd103XyvUce2EBtzbYaC(u"ࠫ࠳ࢀࡩࡱࠩࣵ") in OTKx7aVb2hdS16Wrweky4FXfIN0g9: return Nh0BWuiSndf(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡓࡏࡔࡊࡄࡌࡉࡇࠠࡏࡱࡷࠤࡦࠦࡶࡪࡦࡨࡳࠥ࡬ࡩ࡭ࡧࣶࠪ"),[],[]
		items = YYBlm36zd0Jst18LXwo4.findall(Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"࠭࡮ࡢ࡯ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧࣷ"),OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		lo6biSg2NR3eUB1OpEPxzyXwF8sYWI = {}
		for c17XeRIH2gVh3px8sw,Y8aiFZsLKw in items:
			lo6biSg2NR3eUB1OpEPxzyXwF8sYWI[c17XeRIH2gVh3px8sw] = Y8aiFZsLKw
		data = uVsW5TNRM2vDOn(lo6biSg2NR3eUB1OpEPxzyXwF8sYWI)
		jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(LtlXH3fvMydAx,eiFs3pQPyZtjb0W,data,headers,b8Qe150xVaJsnDSv,SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡑࡔ࡙ࡈࡂࡊࡇࡅ࠲࠹ࡲࡥࠩࣸ"))
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall(IjZbnrBJmM2N(u"ࠨࡆࡲࡻࡳࡲ࡯ࡢࡦ࡚ࠣ࡮ࡪࡥࡰ࠰࠭ࡃ࡬࡫ࡴ࡝ࠪ࡟ࠫ࠭࠴ࠪࡀࠫ࡟ࠫ࠳࠰࠿ࡴࡱࡸࡶࡨ࡫ࡳ࠻ࠪ࠱࠮ࡄ࠯ࡩ࡮ࡣࡪࡩ࠿ࣹ࠭"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if not ZV5rRvabhxJ: return zI3ROAZtiUq42rE9WDST68(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡒࡕࡓࡉࡃࡋࡈࡆࣺ࠭"),[],[]
		download = ZV5rRvabhxJ[LzYQg91SIxDeOGtCKd5][LzYQg91SIxDeOGtCKd5]
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[LzYQg91SIxDeOGtCKd5][qHYIWnOZLPkrQU]
		items = YYBlm36zd0Jst18LXwo4.findall(ubxGUTt1LraKhVZgpAP(u"ࠪࡪ࡮ࡲࡥ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠪ࠯ࡰࡦࡨࡥ࡭࠼ࠥ࠲࠯ࡅࠢࡽࠫࠪࣻ"),OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		e1ZYt4vdj9MuD2oBWVhXPNnRrzIpiK,uuSKUinvP4EGLxWZYmTsF,OeHG3j8TyFDJC,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j,cc3obKIlD8fnOeJ = [],[],[],[],[]
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
			if VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪࣼ") in pcA1dzy7LXwGfMPg9mTkuh5tine3:
				e1ZYt4vdj9MuD2oBWVhXPNnRrzIpiK,OeHG3j8TyFDJC = TTO3ZpWq9FCzhuMAY0RdaDIfX5kw(QQ8pvXNcBfVkP5rRJ7o,pcA1dzy7LXwGfMPg9mTkuh5tine3)
				KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j + OeHG3j8TyFDJC
				if e1ZYt4vdj9MuD2oBWVhXPNnRrzIpiK[LzYQg91SIxDeOGtCKd5]==uVQd103XyvUce2EBtzbYaC(u"ࠬ࠳࠱ࠨࣽ"): uuSKUinvP4EGLxWZYmTsF.append(HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"࠭ࠠิ์ิๅึࠦฮศืࠣࠫࣾ")+VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠧ࡮࠵ࡸ࠼ࠥ࠭ࣿ")+WUj71fhxld3rqONpBzmEuC)
				else:
					for title in e1ZYt4vdj9MuD2oBWVhXPNnRrzIpiK:
						uuSKUinvP4EGLxWZYmTsF.append(Xz3bA2PFENVCUtplu51(u"ࠨࠢึ๎ึ็ัࠡะสูࠥ࠭ऀ")+ddo23ZJtgcY(u"ࠩࡰ࠷ࡺ࠾ࠠࠨँ")+WUj71fhxld3rqONpBzmEuC+pldxivXC5wbTB2O8q+title)
			else:
				title = title.replace(ubxGUTt1LraKhVZgpAP(u"ࠪ࠰ࡱࡧࡢࡦ࡮࠽ࠦࠬं"),b8Qe150xVaJsnDSv)
				title = title.strip(DYakr9g4PVU(u"ࠫࠧ࠭ः"))
				title = Nh0BWuiSndf(u"ࠬࠦำ๋ำไีࠥࠦฮศืࠣࠫऄ")+dDYUoKi6JFM23p(u"࠭ࠠ࡮ࡲ࠷ࠤࠬअ")+WUj71fhxld3rqONpBzmEuC+pldxivXC5wbTB2O8q+title
				uuSKUinvP4EGLxWZYmTsF.append(title)
				KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = QQdAXWBc2GPw(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡮ࡱࡶ࡬ࡦ࡮ࡤࡢ࠰ࡲࡲࡱ࡯࡮ࡦࠩआ") + download
		jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(LtlXH3fvMydAx,pcA1dzy7LXwGfMPg9mTkuh5tine3,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,ddo23ZJtgcY(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡒࡕࡓࡉࡃࡋࡈࡆ࠳࠵ࡵࡪࠪइ"))
		items = YYBlm36zd0Jst18LXwo4.findall(shC5qBRV2A0lZ(u"ࠤࡧࡳࡼࡴ࡬ࡰࡣࡧࡣࡻ࡯ࡤࡦࡱ࡟ࠬࠬ࠮࠮ࠫࡁࠬࠫ࠱࠭ࠨ࠯ࠬࡂ࠭ࠬ࠲ࠧࠩ࠰࠭ࡃ࠮࠭࠮ࠫࡁ࠿ࡸࡩࡄࠨ࠯ࠬࡂ࠭࠱ࠨई"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		for id,ZZtDTHnBXMz,hash,rA6gtZN7RJfP in items:
			title = SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠪࠤุ๐ัโำࠣฮา๋๊ๅࠢัหฺࠦࠧउ")+QQdAXWBc2GPw(u"ࠫࠥࡳࡰ࠵ࠢࠪऊ")+WUj71fhxld3rqONpBzmEuC+pldxivXC5wbTB2O8q+rA6gtZN7RJfP.split(IjZbnrBJmM2N(u"ࠬࡾࠧऋ"))[qHYIWnOZLPkrQU]
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = mmcNLrXtzfpyCkZlvK5VwG2gujh(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡭ࡰࡵ࡫ࡥ࡭ࡪࡡ࠯ࡱࡱࡰ࡮ࡴࡥ࠰ࡦ࡯ࡃࡴࡶ࠽ࡥࡱࡺࡲࡱࡵࡡࡥࡡࡲࡶ࡮࡭ࠦࡪࡦࡀࠫऌ")+id+Nh0BWuiSndf(u"ࠧࠧ࡯ࡲࡨࡪࡃࠧऍ")+ZZtDTHnBXMz+mQNonhS7CV2BXOv(u"ࠨࠨ࡫ࡥࡸ࡮࠽ࠨऎ")+hash
			cc3obKIlD8fnOeJ.append(rA6gtZN7RJfP)
			uuSKUinvP4EGLxWZYmTsF.append(title)
			KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
		cc3obKIlD8fnOeJ = set(cc3obKIlD8fnOeJ)
		gI9Mo2wSzDJQR8u,PdJO9v0LTQIuHtz8VwoqxbrgS = [],[]
		for title in uuSKUinvP4EGLxWZYmTsF:
			mR5n6CefjUyZKDNgIBsHJd = YYBlm36zd0Jst18LXwo4.findall(P0qdZI384LKleuo(u"ࠤࠣࠬࡡࡪࠪࡹࡾ࡟ࡨ࠯࠯ࠦࠧࠤए"),title+P0qdZI384LKleuo(u"ࠪࠪࠫ࠭ऐ"),YYBlm36zd0Jst18LXwo4.DOTALL)
			for rA6gtZN7RJfP in cc3obKIlD8fnOeJ:
				if mR5n6CefjUyZKDNgIBsHJd[LzYQg91SIxDeOGtCKd5] in rA6gtZN7RJfP:
					title = title.replace(mR5n6CefjUyZKDNgIBsHJd[LzYQg91SIxDeOGtCKd5],rA6gtZN7RJfP.split(UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠫࡽ࠭ऑ"))[qHYIWnOZLPkrQU])
			gI9Mo2wSzDJQR8u.append(title)
		for FbcUxvE17ewlWNBHgS8Jn in range(len(KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j)):
			items = YYBlm36zd0Jst18LXwo4.findall(m6hwdgP31a2zjN7lkpX(u"ࠧࠬࠦࠩ࠰࠭ࡃ࠮࠮࡜ࡥࠬࠬࠪࠫࠨऒ"),QQdAXWBc2GPw(u"࠭ࠦࠧࠩओ")+gI9Mo2wSzDJQR8u[FbcUxvE17ewlWNBHgS8Jn]+Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠧࠧࠨࠪऔ"),YYBlm36zd0Jst18LXwo4.DOTALL)
			PdJO9v0LTQIuHtz8VwoqxbrgS.append( [gI9Mo2wSzDJQR8u[FbcUxvE17ewlWNBHgS8Jn],KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j[FbcUxvE17ewlWNBHgS8Jn],items[LzYQg91SIxDeOGtCKd5][LzYQg91SIxDeOGtCKd5],items[LzYQg91SIxDeOGtCKd5][qHYIWnOZLPkrQU]] )
		PdJO9v0LTQIuHtz8VwoqxbrgS = sorted(PdJO9v0LTQIuHtz8VwoqxbrgS, key=lambda aBuKDWVb3eg2d5Ch: aBuKDWVb3eg2d5Ch[VwApyDY1Jc], reverse=CCxMXuNUEzolDZTKrBJ)
		PdJO9v0LTQIuHtz8VwoqxbrgS = sorted(PdJO9v0LTQIuHtz8VwoqxbrgS, key=lambda aBuKDWVb3eg2d5Ch: aBuKDWVb3eg2d5Ch[IgQimel18t], reverse=DD5cFIejQa2X4BgAu9GWPyJ3tC7)
		uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = [],[]
		for FbcUxvE17ewlWNBHgS8Jn in range(len(PdJO9v0LTQIuHtz8VwoqxbrgS)):
			uuSKUinvP4EGLxWZYmTsF.append(PdJO9v0LTQIuHtz8VwoqxbrgS[FbcUxvE17ewlWNBHgS8Jn][LzYQg91SIxDeOGtCKd5])
			KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j.append(PdJO9v0LTQIuHtz8VwoqxbrgS[FbcUxvE17ewlWNBHgS8Jn][qHYIWnOZLPkrQU])
	if len(KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j)==LzYQg91SIxDeOGtCKd5: return ddo23ZJtgcY(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡑࡔ࡙ࡈࡂࡊࡇࡅࠬक"),[],[]
	return b8Qe150xVaJsnDSv,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j
def qIFU5ln0KPchopeuZigM6NzE38Wt(url):
	GGYbRJxlHWKpQ2ihCD = url.split(uVQd103XyvUce2EBtzbYaC(u"ࠩࡂࠫख"))
	MUJCtfYVBLODrFbaZn = GGYbRJxlHWKpQ2ihCD[LzYQg91SIxDeOGtCKd5]
	headers = { QTUBCcehw6qPd4x(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧग") : b8Qe150xVaJsnDSv }
	jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(LtlXH3fvMydAx,MUJCtfYVBLODrFbaZn,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,QTUBCcehw6qPd4x(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆ࠷ࡗࡗࡆࡘ࠭࠲ࡵࡷࠫघ"))
	items = YYBlm36zd0Jst18LXwo4.findall(dDYUoKi6JFM23p(u"ࠬࡖ࡬ࡦࡣࡶࡩࠥࡽࡡࡪࡶ࠱࠮ࡄ࡮ࡲࡦࡨࡀࡠࠬ࠮࠮ࠫࡁࠬࡠࠬ࠭ङ"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	url = items[LzYQg91SIxDeOGtCKd5]
	return RRIHDFjoW9w7bSfVPhC(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩच"),[b8Qe150xVaJsnDSv],[url]
def sEwnOSP6CzIAl5tfeLj(url):
	uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = [],[]
	headers = { QTUBCcehw6qPd4x(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫछ") : b8Qe150xVaJsnDSv }
	jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(Q49IsrlSuYRAVbGKhwdckLDOetF2PZ,url,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,kke1PDGRBLuY8y(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡋࡇࡃࡖࡎࡗ࡝ࡇࡕࡏࡌࡕ࠰࠵ࡸࡺࠧज"))
	MUJCtfYVBLODrFbaZn = YYBlm36zd0Jst18LXwo4.findall(kke1PDGRBLuY8y(u"ࠩࡵࡩࡩ࡯ࡲࡦࡥࡷࡣࡺࡸ࡬࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩझ"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if MUJCtfYVBLODrFbaZn: return b8Qe150xVaJsnDSv,[b8Qe150xVaJsnDSv],[MUJCtfYVBLODrFbaZn[LzYQg91SIxDeOGtCKd5]]
	else: return HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡈࡕ࡛࡜࡙ࡖࡑ࠭ञ"),[],[]
def U7JVqabxMABrngPHLedFw5GfsoXKYk(url):
	uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = [],[]
	headers = { Mmpr0o76iWJvz1kTtfgI8hES(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨट") : b8Qe150xVaJsnDSv }
	jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(Q49IsrlSuYRAVbGKhwdckLDOetF2PZ,url,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡈࡄࡇ࡚ࡒࡔ࡚ࡄࡒࡓࡐ࡙࠭࠲ࡵࡷࠫठ"))
	MUJCtfYVBLODrFbaZn = YYBlm36zd0Jst18LXwo4.findall(VFjQx6Is28KvzLOmMXtg4GqTwa3(u"࠭ࡨࡳࡧࡩࠦ࠱ࠨࠨࡩࡶࡷ࠲࠯ࡅࠩࠣࠩड"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if MUJCtfYVBLODrFbaZn: return b8Qe150xVaJsnDSv,[b8Qe150xVaJsnDSv],[MUJCtfYVBLODrFbaZn[LzYQg91SIxDeOGtCKd5]]
	else: return kke1PDGRBLuY8y(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡉࡅࡈ࡛ࡌࡕ࡛ࡅࡓࡔࡑࡓࠨढ"),[],[]
def WO3GF0r9ls(url):
	uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j,errno = [],[],b8Qe150xVaJsnDSv
	if RRIHDFjoW9w7bSfVPhC(u"ࠨ࠱ࡺࡴ࠲ࡧࡤ࡮࡫ࡱ࠳ࠬण") in url:
		MUJCtfYVBLODrFbaZn,EEkjQFxOabod08Nr = FNIhDd4uLfev0q5YHVGx8oWm6CsiJ(url)
		ybF0H85nUohsiRQcpaTfZAKzjMY7wB = {TYf7Dc06PQgy1vEV9(u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨत"):SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥ࠽ࠣࡧ࡭ࡧࡲࡴࡧࡷࡁ࡚࡚ࡆ࠮࠺ࠪथ")}
		b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(LtlXH3fvMydAx,m6hwdgP31a2zjN7lkpX(u"ࠫࡕࡕࡓࡕࠩद"),MUJCtfYVBLODrFbaZn,EEkjQFxOabod08Nr,ybF0H85nUohsiRQcpaTfZAKzjMY7wB,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡈࡄࡎࡊࡘࡓࡉࡑ࡚࠱࠷ࡴࡤࠨध"))
		vWsMIpk1n6rlLqH52 = b3HKopTY9zLUyhJmt.content
		if vWsMIpk1n6rlLqH52.startswith(S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"࠭ࡨࡵࡶࡳࠫन")): MUJCtfYVBLODrFbaZn = vWsMIpk1n6rlLqH52
		else:
			GSh0nJxEXgZjd48u7mBwWOeafyAp5b = YYBlm36zd0Jst18LXwo4.findall(QTUBCcehw6qPd4x(u"ࠧࠨࠩࡶࡶࡨࡃ࡛ࠨࠤࡠࠬ࠳࠰࠿ࠪ࡝ࠪࠦࡢ࠭ࠧࠨऩ"),vWsMIpk1n6rlLqH52,YYBlm36zd0Jst18LXwo4.DOTALL)
			if GSh0nJxEXgZjd48u7mBwWOeafyAp5b:
				MUJCtfYVBLODrFbaZn = GSh0nJxEXgZjd48u7mBwWOeafyAp5b[LzYQg91SIxDeOGtCKd5]
				GSh0nJxEXgZjd48u7mBwWOeafyAp5b = YYBlm36zd0Jst18LXwo4.findall(S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠨࡵࡲࡹࡷࡩࡥ࠾ࠪ࠱࠮ࡄ࠯࡛ࠧࠦࡠࠫप"),MUJCtfYVBLODrFbaZn,YYBlm36zd0Jst18LXwo4.DOTALL)
				if GSh0nJxEXgZjd48u7mBwWOeafyAp5b:
					MUJCtfYVBLODrFbaZn = SgrGWuAHcLKBQMJetb9(GSh0nJxEXgZjd48u7mBwWOeafyAp5b[LzYQg91SIxDeOGtCKd5])
					return b8Qe150xVaJsnDSv,[b8Qe150xVaJsnDSv],[MUJCtfYVBLODrFbaZn]
	elif vvWwO3Tx2dAgcijrFXq(u"ࠩ࠲ࡰ࡮ࡴ࡫ࡴ࠱ࠪफ") in url:
		b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(LtlXH3fvMydAx,DYakr9g4PVU(u"ࠪࡋࡊ࡚ࠧब"),url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,CCxMXuNUEzolDZTKrBJ,b8Qe150xVaJsnDSv,HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡇࡃࡍࡉࡗ࡙ࡈࡐ࡙࠰࠵ࡸࡺࠧभ"))
		vWsMIpk1n6rlLqH52 = b3HKopTY9zLUyhJmt.content
		if kke1PDGRBLuY8y(u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧम") in list(b3HKopTY9zLUyhJmt.headers.keys()): MUJCtfYVBLODrFbaZn = b3HKopTY9zLUyhJmt.headers[ubxGUTt1LraKhVZgpAP(u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨय")]
		else: MUJCtfYVBLODrFbaZn = YYBlm36zd0Jst18LXwo4.findall(shC5qBRV2A0lZ(u"ࠧࡪࡦࡀࠦࡱ࡯࡮࡬ࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫर"),vWsMIpk1n6rlLqH52,YYBlm36zd0Jst18LXwo4.DOTALL)[LzYQg91SIxDeOGtCKd5]
	if UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠨ࠱ࡹ࠳ࠬऱ") in MUJCtfYVBLODrFbaZn or TYf7Dc06PQgy1vEV9(u"ࠩ࠲ࡪ࠴࠭ल") in MUJCtfYVBLODrFbaZn:
		MUJCtfYVBLODrFbaZn = MUJCtfYVBLODrFbaZn.replace(QQdAXWBc2GPw(u"ࠪ࠳࡫࠵ࠧळ"),HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠫ࠴ࡧࡰࡪ࠱ࡶࡳࡺࡸࡣࡦ࠱ࠪऴ"))
		MUJCtfYVBLODrFbaZn = MUJCtfYVBLODrFbaZn.replace(yST5AHEfvPmcWpwGuh2BJ(u"ࠬ࠵ࡶ࠰ࠩव"),P0qdZI384LKleuo(u"࠭࠯ࡢࡲ࡬࠳ࡸࡵࡵࡳࡥࡨ࠳ࠬश"))
		b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(LtlXH3fvMydAx,Xz3bA2PFENVCUtplu51(u"ࠧࡑࡑࡖࡘࠬष"),MUJCtfYVBLODrFbaZn,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,P0qdZI384LKleuo(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡋࡇࡊࡆࡔࡖࡌࡔ࡝࠭࠴ࡴࡧࠫस"))
		vWsMIpk1n6rlLqH52 = b3HKopTY9zLUyhJmt.content
		items = YYBlm36zd0Jst18LXwo4.findall(m6hwdgP31a2zjN7lkpX(u"ࠩࠥࡪ࡮ࡲࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠯ࠦࡱࡧࡢࡦ࡮ࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬह"),vWsMIpk1n6rlLqH52,YYBlm36zd0Jst18LXwo4.DOTALL)
		if items:
			for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
				pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3.replace(TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠪࡠࡡ࠭ऺ"),b8Qe150xVaJsnDSv)
				uuSKUinvP4EGLxWZYmTsF.append(title)
				KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
		else:
			items = YYBlm36zd0Jst18LXwo4.findall(SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠫࠧ࡬ࡩ࡭ࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬऻ"),vWsMIpk1n6rlLqH52,YYBlm36zd0Jst18LXwo4.DOTALL)
			if items:
				pcA1dzy7LXwGfMPg9mTkuh5tine3 = items[LzYQg91SIxDeOGtCKd5]
				pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3.replace(Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠬࡢ࡜ࠨ़"),b8Qe150xVaJsnDSv)
				uuSKUinvP4EGLxWZYmTsF.append(b8Qe150xVaJsnDSv)
				KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
	else: return m6hwdgP31a2zjN7lkpX(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩऽ"),[b8Qe150xVaJsnDSv],[MUJCtfYVBLODrFbaZn]
	if len(KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j)==LzYQg91SIxDeOGtCKd5: return vvWwO3Tx2dAgcijrFXq(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡉࡅࡏࡋࡒࡔࡊࡒ࡛ࠬा"),[],[]
	return b8Qe150xVaJsnDSv,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j
def hetvLJfylE(url):
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(LtlXH3fvMydAx,shC5qBRV2A0lZ(u"ࠨࡉࡈࡘࠬि"),url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡓࡏࡗࡕ࠷࡙࠲࠷ࡳࡵࠩी"))
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j,errno = [],[],b8Qe150xVaJsnDSv
	if Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠪࡴࡱࡧࡹࡦࡴࡢࡩࡲࡨࡥࡥ࠰ࡳ࡬ࡵ࠭ु") in url or vvWwO3Tx2dAgcijrFXq(u"ࠫ࠴࡫࡭ࡣࡧࡧ࠳ࠬू") in url:
		if RRIHDFjoW9w7bSfVPhC(u"ࠬࡶ࡬ࡢࡻࡨࡶࡤ࡫࡭ࡣࡧࡧ࠲ࡵ࡮ࡰࠨृ") in url:
			MUJCtfYVBLODrFbaZn = YYBlm36zd0Jst18LXwo4.findall(TT8Mxv5Wq7nlC9IscdpPUY6(u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫॄ"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
			MUJCtfYVBLODrFbaZn = MUJCtfYVBLODrFbaZn[LzYQg91SIxDeOGtCKd5]
		else: MUJCtfYVBLODrFbaZn = url
		if Xz3bA2PFENVCUtplu51(u"ࠧ࡮ࡱࡹࡷ࠹ࡻࠧॅ") not in MUJCtfYVBLODrFbaZn: return UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫॆ"),[b8Qe150xVaJsnDSv],[MUJCtfYVBLODrFbaZn]
		b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(LtlXH3fvMydAx,uVQd103XyvUce2EBtzbYaC(u"ࠩࡊࡉ࡙࠭े"),MUJCtfYVBLODrFbaZn,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,zI3ROAZtiUq42rE9WDST68(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡍࡐࡘࡖ࠸࡚࠳࠲࡯ࡦࠪै"))
		jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall(dDYUoKi6JFM23p(u"ࠫ࡮ࡪ࠽ࠣࡲ࡯ࡥࡾ࡫ࡲࠣࠪ࠱࠮ࡄ࠯ࡶࡪࡦࡨࡳ࡯ࡹࠧॉ"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[LzYQg91SIxDeOGtCKd5]
		items = YYBlm36zd0Jst18LXwo4.findall(TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠬࡂࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࡬ࡢࡤࡨࡰࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ॊ"),OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		if items:
			for pcA1dzy7LXwGfMPg9mTkuh5tine3,okYWP4Hxyb in items:
				uuSKUinvP4EGLxWZYmTsF.append(okYWP4Hxyb)
				KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
	elif Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"࠭࡭ࡢ࡫ࡱࡣࡵࡲࡡࡺࡧࡵ࠲ࡵ࡮ࡰࠨो") in url:
		MUJCtfYVBLODrFbaZn = YYBlm36zd0Jst18LXwo4.findall(LAQD5wEkr18bUiGaYen3J(u"ࠧࡶࡴ࡯ࡁ࠭࠴ࠪࡀࠫࠥࠫौ"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		MUJCtfYVBLODrFbaZn = MUJCtfYVBLODrFbaZn[LzYQg91SIxDeOGtCKd5]
		b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(LtlXH3fvMydAx,mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠨࡉࡈࡘ्ࠬ"),MUJCtfYVBLODrFbaZn,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,TYf7Dc06PQgy1vEV9(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡓࡏࡗࡕ࠷࡙࠲࠹ࡲࡥࠩॎ"))
		jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
		GSh0nJxEXgZjd48u7mBwWOeafyAp5b = YYBlm36zd0Jst18LXwo4.findall(zI3ROAZtiUq42rE9WDST68(u"ࠪࠦ࡫࡯࡬ࡦࠤ࠽ࠤࠧ࠮࠮ࠫࡁࠬࠦࠬॏ"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		GSh0nJxEXgZjd48u7mBwWOeafyAp5b = GSh0nJxEXgZjd48u7mBwWOeafyAp5b[LzYQg91SIxDeOGtCKd5]
		uuSKUinvP4EGLxWZYmTsF.append(b8Qe150xVaJsnDSv)
		KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j.append(GSh0nJxEXgZjd48u7mBwWOeafyAp5b)
	elif m6hwdgP31a2zjN7lkpX(u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩࡥ࡬ࡪࡰ࡮ࠫॐ") in url:
		MUJCtfYVBLODrFbaZn = YYBlm36zd0Jst18LXwo4.findall(vvWwO3Tx2dAgcijrFXq(u"ࠬࡂࡣࡦࡰࡷࡩࡷࡄ࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ॑"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if MUJCtfYVBLODrFbaZn:
			MUJCtfYVBLODrFbaZn = MUJCtfYVBLODrFbaZn[LzYQg91SIxDeOGtCKd5]
			return BmePGjS7FxK6kutUM(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ॒ࠩ"),[b8Qe150xVaJsnDSv],[MUJCtfYVBLODrFbaZn]
	if len(KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j)==LzYQg91SIxDeOGtCKd5: return ubxGUTt1LraKhVZgpAP(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡐࡓ࡛࡙࠴ࡖࠩ॓"),[],[]
	return b8Qe150xVaJsnDSv,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j
def QBl6HJObqY(url):
	if QTUBCcehw6qPd4x(u"ࠨࡁࡪࡩࡹࡃࠧ॔") in url:
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = url.split(Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠩࡂ࡫ࡪࡺ࠽ࠨॕ"),qHYIWnOZLPkrQU)[qHYIWnOZLPkrQU]
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = lnFeUkiZtQ7E1.b64decode(pcA1dzy7LXwGfMPg9mTkuh5tine3)
		if i1thmHk7AZquD4cM0fnp62: pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3.decode(OVauxZzLI10vcXT74K,Xz3bA2PFENVCUtplu51(u"ࠪ࡭࡬ࡴ࡯ࡳࡧࠪॖ"))
		return Mmpr0o76iWJvz1kTtfgI8hES(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧॗ"),[b8Qe150xVaJsnDSv],[pcA1dzy7LXwGfMPg9mTkuh5tine3]
	website = nTHXJIiah2qK[zI3ROAZtiUq42rE9WDST68(u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡈࠧक़")][LzYQg91SIxDeOGtCKd5]
	headers = {dDYUoKi6JFM23p(u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧख़"):website}
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(nCUMfrlZvuiLe5x,RRIHDFjoW9w7bSfVPhC(u"ࠧࡈࡇࡗࠫग़"),url,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,QQdAXWBc2GPw(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡈࡏࡍࡂࡅࡏ࡙ࡇ࠳࠲࡯ࡦࠪज़"))
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	LLOCdZ3sS2enzXx4fVB18YRvbHNwky = Wl2eu1PavfQ(url,DYakr9g4PVU(u"ࠩࡸࡶࡱ࠭ड़"))
	pcA1dzy7LXwGfMPg9mTkuh5tine3 = YYBlm36zd0Jst18LXwo4.findall(m6hwdgP31a2zjN7lkpX(u"ࠪࡨࡴࡽ࡮࡭ࡱࡤࡨࡂ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧढ़"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if not pcA1dzy7LXwGfMPg9mTkuh5tine3: pcA1dzy7LXwGfMPg9mTkuh5tine3 = YYBlm36zd0Jst18LXwo4.findall(VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠦࡸࡵࡵࡳࡥࡨࡷ࠿ࠦ࡜࡜ࠩࠫ࠲࠯ࡅࠩࠨࠤफ़"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if not pcA1dzy7LXwGfMPg9mTkuh5tine3: pcA1dzy7LXwGfMPg9mTkuh5tine3 = YYBlm36zd0Jst18LXwo4.findall(uVQd103XyvUce2EBtzbYaC(u"ࠧ࡬ࡩ࡭ࡧ࠽ࠫ࠭࠴ࠪࡀࠫࠪࠦय़"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if pcA1dzy7LXwGfMPg9mTkuh5tine3:
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3[LzYQg91SIxDeOGtCKd5]+ubxGUTt1LraKhVZgpAP(u"࠭ࡼࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠩॠ")+website
		return b8Qe150xVaJsnDSv,[b8Qe150xVaJsnDSv],[pcA1dzy7LXwGfMPg9mTkuh5tine3]
	if VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠧ࡯ࡣࡰࡩࡂࠨࡘࡵࡱ࡮ࡩࡳࠨࠧॡ") in jLtdbeYiQHnf4SpU2MTly:
		ES51wFgXvRcCnj0eh2LJ = YYBlm36zd0Jst18LXwo4.findall(Xz3bA2PFENVCUtplu51(u"ࠨࡰࡤࡱࡪࡃ࡙ࠢࡶࡲ࡯ࡪࡴࠢࠡࡥࡲࡲࡹ࡫࡮ࡵ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪॢ"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if ES51wFgXvRcCnj0eh2LJ:
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = ES51wFgXvRcCnj0eh2LJ[LzYQg91SIxDeOGtCKd5]
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = lnFeUkiZtQ7E1.b64decode(pcA1dzy7LXwGfMPg9mTkuh5tine3)
			if i1thmHk7AZquD4cM0fnp62: pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3.decode(OVauxZzLI10vcXT74K,HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠩ࡬࡫ࡳࡵࡲࡦࠩॣ"))
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = YYBlm36zd0Jst18LXwo4.findall(DYakr9g4PVU(u"ࠪ࡬ࡹࡺࡰ࠯ࠬࡂࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮࠲ࠧ।"),pcA1dzy7LXwGfMPg9mTkuh5tine3,YYBlm36zd0Jst18LXwo4.DOTALL)
			if pcA1dzy7LXwGfMPg9mTkuh5tine3:
				pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3[LzYQg91SIxDeOGtCKd5]+QQdAXWBc2GPw(u"ࠫࢁࡘࡥࡧࡧࡵࡩࡷࡃࠧ॥")+website
				return b8Qe150xVaJsnDSv,[b8Qe150xVaJsnDSv],[pcA1dzy7LXwGfMPg9mTkuh5tine3]
	return mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ०"),[b8Qe150xVaJsnDSv],[url]
def c7rXmiApNg(url,JVrK4ste3qUM9iy2mNIgdXHhcSwQP6):
	zMaDJPY25fQK96VvUBAgxlROmI8,n92bB0YwDLqyadQRlmGW = [],[]
	if BWNPxIG7vqdTy85pjHzUOrK3(u"࠭࠯࠲࠱ࠪ१") in url:
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = url.replace(QQdAXWBc2GPw(u"ࠧ࠰࠳࠲ࠫ२"),BmePGjS7FxK6kutUM(u"ࠨ࠱࠷࠳ࠬ३"))
		b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(nCUMfrlZvuiLe5x,mQNonhS7CV2BXOv(u"ࠩࡊࡉ࡙࠭४"),pcA1dzy7LXwGfMPg9mTkuh5tine3,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,DD5cFIejQa2X4BgAu9GWPyJ3tC7,b8Qe150xVaJsnDSv,LAQD5wEkr18bUiGaYen3J(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅࡈ࡛ࡅࡉࡘ࡚࠱࠮࠳ࡶࡸࠬ५"))
		vWsMIpk1n6rlLqH52 = b3HKopTY9zLUyhJmt.content
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall(Xz3bA2PFENVCUtplu51(u"ࠫࡁࡼࡩࡥࡧࡲࠬ࠳࠰࠿ࠪ࠾࠲ࡺ࡮ࡪࡥࡰࡀࠪ६"),vWsMIpk1n6rlLqH52,YYBlm36zd0Jst18LXwo4.DOTALL)
		if ZV5rRvabhxJ:
			OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[LzYQg91SIxDeOGtCKd5]
			items = YYBlm36zd0Jst18LXwo4.findall(RRIHDFjoW9w7bSfVPhC(u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡩࡻࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ७"),OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
			for pcA1dzy7LXwGfMPg9mTkuh5tine3,c1EdszLx3mkb8QYX9 in items:
				if pcA1dzy7LXwGfMPg9mTkuh5tine3 not in n92bB0YwDLqyadQRlmGW:
					n92bB0YwDLqyadQRlmGW.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
					LLOCdZ3sS2enzXx4fVB18YRvbHNwky = Wl2eu1PavfQ(pcA1dzy7LXwGfMPg9mTkuh5tine3,Mmpr0o76iWJvz1kTtfgI8hES(u"࠭࡮ࡢ࡯ࡨࠫ८"))
					zMaDJPY25fQK96VvUBAgxlROmI8.append(LLOCdZ3sS2enzXx4fVB18YRvbHNwky+k5bCDErUSmv+c1EdszLx3mkb8QYX9)
			return b8Qe150xVaJsnDSv,zMaDJPY25fQK96VvUBAgxlROmI8,n92bB0YwDLqyadQRlmGW
	elif shC5qBRV2A0lZ(u"ࠧ࠰ࡦ࠲ࠫ९") in url:
		b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(nCUMfrlZvuiLe5x,shC5qBRV2A0lZ(u"ࠨࡉࡈࡘࠬ॰"),url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡋࡇ࡚ࡄࡈࡗ࡙࠷࠭࠳ࡰࡧࠫॱ"))
		vWsMIpk1n6rlLqH52 = b3HKopTY9zLUyhJmt.content
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = YYBlm36zd0Jst18LXwo4.findall(DYakr9g4PVU(u"ࠪࡀ࡮࡬ࡲࡢ࡯ࡨ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫॲ"),vWsMIpk1n6rlLqH52,YYBlm36zd0Jst18LXwo4.DOTALL)
		if pcA1dzy7LXwGfMPg9mTkuh5tine3:
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3[LzYQg91SIxDeOGtCKd5].replace(BmePGjS7FxK6kutUM(u"ࠫ࠴࠷࠯ࠨॳ"),dDYUoKi6JFM23p(u"ࠬ࠵࠴࠰ࠩॴ"))
			b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(nCUMfrlZvuiLe5x,yST5AHEfvPmcWpwGuh2BJ(u"࠭ࡇࡆࡖࠪॵ"),pcA1dzy7LXwGfMPg9mTkuh5tine3,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,DD5cFIejQa2X4BgAu9GWPyJ3tC7,b8Qe150xVaJsnDSv,TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡉࡌ࡟ࡂࡆࡕࡗ࠵࠲࠹ࡲࡥࠩॶ"))
			vWsMIpk1n6rlLqH52 = b3HKopTY9zLUyhJmt.content
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = YYBlm36zd0Jst18LXwo4.findall(kke1PDGRBLuY8y(u"ࠨࡥ࡯ࡥࡸࡹ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨॷ"),vWsMIpk1n6rlLqH52,YYBlm36zd0Jst18LXwo4.DOTALL)
			if pcA1dzy7LXwGfMPg9mTkuh5tine3: return SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬॸ"),[b8Qe150xVaJsnDSv],[pcA1dzy7LXwGfMPg9mTkuh5tine3[LzYQg91SIxDeOGtCKd5]]
	elif Nh0BWuiSndf(u"ࠪ࠳ࡷࡵ࡬ࡦ࠱ࠪॹ") in url:
		headers = {uVQd103XyvUce2EBtzbYaC(u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬॺ"):JVrK4ste3qUM9iy2mNIgdXHhcSwQP6}
		b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(LtlXH3fvMydAx,Xz3bA2PFENVCUtplu51(u"ࠬࡍࡅࡕࠩॻ"),url,b8Qe150xVaJsnDSv,headers,DD5cFIejQa2X4BgAu9GWPyJ3tC7,b8Qe150xVaJsnDSv,kke1PDGRBLuY8y(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡈࡋ࡞ࡈࡅࡔࡖ࠴࠱࠹ࡺࡨࠨॼ"))
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = b3HKopTY9zLUyhJmt.headers[mQNonhS7CV2BXOv(u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩॽ")]
		b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(LtlXH3fvMydAx,kke1PDGRBLuY8y(u"ࠨࡉࡈࡘࠬॾ"),pcA1dzy7LXwGfMPg9mTkuh5tine3,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡋࡇ࡚ࡄࡈࡗ࡙࠷࠭࠶ࡶ࡫ࠫॿ"))
		jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
		bqCG6DEkf705Z9enS4pmN2,zMaDJPY25fQK96VvUBAgxlROmI8,n92bB0YwDLqyadQRlmGW = rrejSndG6mQ(pcA1dzy7LXwGfMPg9mTkuh5tine3,jLtdbeYiQHnf4SpU2MTly)
		return bqCG6DEkf705Z9enS4pmN2,zMaDJPY25fQK96VvUBAgxlROmI8,n92bB0YwDLqyadQRlmGW
	elif m6hwdgP31a2zjN7lkpX(u"ࠪ࠳ࡩࡵࡷ࡯࡮ࡲࡥࡩ࠵ࠧঀ") in url:
		MUJCtfYVBLODrFbaZn = url.replace(IjZbnrBJmM2N(u"ࠫ࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠯ࠨঁ"),ddo23ZJtgcY(u"ࠬ࠵ࡳࡤࡴ࡬ࡴࡹ࠵ࠧং"))
		ybF0H85nUohsiRQcpaTfZAKzjMY7wB = {ddo23ZJtgcY(u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧঃ"):JVrK4ste3qUM9iy2mNIgdXHhcSwQP6}
		b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(LtlXH3fvMydAx,QTUBCcehw6qPd4x(u"ࠧࡈࡇࡗࠫ঄"),MUJCtfYVBLODrFbaZn,b8Qe150xVaJsnDSv,ybF0H85nUohsiRQcpaTfZAKzjMY7wB,DD5cFIejQa2X4BgAu9GWPyJ3tC7,b8Qe150xVaJsnDSv,QQdAXWBc2GPw(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡊࡍ࡙ࡃࡇࡖࡘ࠶࠳࠶ࡵࡪࠪঅ"))
		jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = YYBlm36zd0Jst18LXwo4.findall(IjZbnrBJmM2N(u"ࠩ࠿࡭࡫ࡸࡡ࡮ࡧ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪআ"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if pcA1dzy7LXwGfMPg9mTkuh5tine3:
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3[LzYQg91SIxDeOGtCKd5]
			b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(LtlXH3fvMydAx,vvWwO3Tx2dAgcijrFXq(u"ࠪࡋࡊ࡚ࠧই"),pcA1dzy7LXwGfMPg9mTkuh5tine3,b8Qe150xVaJsnDSv,ybF0H85nUohsiRQcpaTfZAKzjMY7wB,DD5cFIejQa2X4BgAu9GWPyJ3tC7,b8Qe150xVaJsnDSv,QQdAXWBc2GPw(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆࡉ࡜ࡆࡊ࡙ࡔ࠲࠯࠺ࡸ࡭࠭ঈ"))
			jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
			if Xz3bA2PFENVCUtplu51(u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧউ") in list(b3HKopTY9zLUyhJmt.headers.keys()):
				pcA1dzy7LXwGfMPg9mTkuh5tine3 = b3HKopTY9zLUyhJmt.headers[P0qdZI384LKleuo(u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨঊ")]
				b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(LtlXH3fvMydAx,TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠧࡈࡇࡗࠫঋ"),pcA1dzy7LXwGfMPg9mTkuh5tine3,b8Qe150xVaJsnDSv,ybF0H85nUohsiRQcpaTfZAKzjMY7wB,DD5cFIejQa2X4BgAu9GWPyJ3tC7,b8Qe150xVaJsnDSv,TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡊࡍ࡙ࡃࡇࡖࡘ࠶࠳࠸ࡵࡪࠪঌ"))
				jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
				bqCG6DEkf705Z9enS4pmN2,zMaDJPY25fQK96VvUBAgxlROmI8,n92bB0YwDLqyadQRlmGW = rrejSndG6mQ(pcA1dzy7LXwGfMPg9mTkuh5tine3,jLtdbeYiQHnf4SpU2MTly)
				if n92bB0YwDLqyadQRlmGW: return bqCG6DEkf705Z9enS4pmN2,zMaDJPY25fQK96VvUBAgxlROmI8,n92bB0YwDLqyadQRlmGW
			elif TYf7Dc06PQgy1vEV9(u"ࠩ࠲ࡩࡲࡨࡥࡥ࠰ࡳ࡬ࡵࡅࡩࡥ࠿ࠪ঍") in pcA1dzy7LXwGfMPg9mTkuh5tine3:
				pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3.replace(dDYUoKi6JFM23p(u"ࠪ࠳ࡪࡳࡢࡦࡦ࠱ࡴ࡭ࡶ࠿ࡪࡦࡀࠫ঎"),yST5AHEfvPmcWpwGuh2BJ(u"ࠫ࠴ࡰࡷࡱ࡮ࡤࡽࡪࡸ࠮ࡱࡪࡳࡃ࡮ࡪ࠽ࠨএ"))
				return uVQd103XyvUce2EBtzbYaC(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨঐ"),[b8Qe150xVaJsnDSv],[pcA1dzy7LXwGfMPg9mTkuh5tine3]
	else: return uVQd103XyvUce2EBtzbYaC(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ঑"),[b8Qe150xVaJsnDSv],[url]
	return IjZbnrBJmM2N(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡈࡋ࡞ࡈࡅࡔࡖ࠴ࠫ঒"),[],[]
def KTWbR9QiUY(url):
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(nCUMfrlZvuiLe5x,shC5qBRV2A0lZ(u"ࠨࡉࡈࡘࠬও"),url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,ubxGUTt1LraKhVZgpAP(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡋࡇ࡚ࡄࡈࡗ࡙࠹࠭࠲ࡵࡷࠫঔ"))
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	data = YYBlm36zd0Jst18LXwo4.findall(zI3ROAZtiUq42rE9WDST68(u"ࠪࠦࡦࡩࡴࡪࡱࡱࠦ࠳࠰࠿ࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡹࡥࡱࡻࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡻࡧ࡬ࡶࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫক"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if data:
		Isy1nBEShY9XgjVNOv,id,c0AdKEpD67JCnlz = data[LzYQg91SIxDeOGtCKd5]
		data = uVQd103XyvUce2EBtzbYaC(u"ࠫࡴࡶ࠽ࠨখ")+Isy1nBEShY9XgjVNOv+mQNonhS7CV2BXOv(u"ࠬࠬࡩࡥ࠿ࠪগ")+id+P0qdZI384LKleuo(u"࠭ࠦࡧࡰࡤࡱࡪࡃࠧঘ")+c0AdKEpD67JCnlz
		headers = {TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭ঙ"):DYakr9g4PVU(u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪࠧচ")}
		b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(nCUMfrlZvuiLe5x,yST5AHEfvPmcWpwGuh2BJ(u"ࠩࡓࡓࡘ࡚ࠧছ"),url,data,headers,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,ddo23ZJtgcY(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅࡈ࡛ࡅࡉࡘ࡚࠳࠮࠴ࡱࡨࠬজ"))
		jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = YYBlm36zd0Jst18LXwo4.findall(S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠫࠧࡸࡥࡧࡧࡵࡩࡷࠨࠠࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧঝ"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if pcA1dzy7LXwGfMPg9mTkuh5tine3: return SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨঞ"),[b8Qe150xVaJsnDSv],[pcA1dzy7LXwGfMPg9mTkuh5tine3[LzYQg91SIxDeOGtCKd5]]
	return HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡇࡊ࡝ࡇࡋࡓࡕ࠳ࠪট"),[],[]
def rcz6XESfRt(url):
	headers = {yST5AHEfvPmcWpwGuh2BJ(u"࡙ࠧ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪࠪঠ"):UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠨ࡚ࡐࡐࡍࡺࡴࡱࡔࡨࡵࡺ࡫ࡳࡵࠩড")}
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(nCUMfrlZvuiLe5x,TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠩࡊࡉ࡙࠭ঢ"),url,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,vvWwO3Tx2dAgcijrFXq(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅࡈ࡛ࡅࡉࡘ࡚࠴࠮࠳ࡶࡸࠬণ"))
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	pcA1dzy7LXwGfMPg9mTkuh5tine3 = YYBlm36zd0Jst18LXwo4.findall(VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩত"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if pcA1dzy7LXwGfMPg9mTkuh5tine3:
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3[LzYQg91SIxDeOGtCKd5].replace(eeN6dTEnkJxI,b8Qe150xVaJsnDSv)
		return dDYUoKi6JFM23p(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨথ"),[b8Qe150xVaJsnDSv],[pcA1dzy7LXwGfMPg9mTkuh5tine3]
	return vvWwO3Tx2dAgcijrFXq(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡇࡊ࡝ࡇࡋࡓࡕ࠳ࠪদ"),[],[]
def yozpfunWgq(url):
	MUJCtfYVBLODrFbaZn = url.split(uVQd103XyvUce2EBtzbYaC(u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨধ"),qHYIWnOZLPkrQU)[LzYQg91SIxDeOGtCKd5].strip(BmePGjS7FxK6kutUM(u"ࠨࡁࠪন")).strip(DYakr9g4PVU(u"ࠩ࠲ࠫ঩")).strip(mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠪࠪࠬপ"))
	uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j,items,GSh0nJxEXgZjd48u7mBwWOeafyAp5b = [],[],[],b8Qe150xVaJsnDSv
	headers = { zI3ROAZtiUq42rE9WDST68(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨফ"):zI3ROAZtiUq42rE9WDST68(u"ࠬࡓ࡯ࡻ࡫࡯ࡰࡦ࠵࠵࠯࠲ࠣࠬ࡜࡯࡮ࡥࡱࡺࡷࠥࡔࡔࠡ࠳࠳࠲࠵ࡁࠠࡘ࡫ࡱ࠺࠹ࡁࠠࡹ࠸࠷࠭ࠬব") }
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(LtlXH3fvMydAx,QTUBCcehw6qPd4x(u"࠭ࡇࡆࡖࠪভ"),MUJCtfYVBLODrFbaZn,b8Qe150xVaJsnDSv,headers,CCxMXuNUEzolDZTKrBJ,b8Qe150xVaJsnDSv,ddo23ZJtgcY(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡉࡌ࡟ࡂࡆࡕࡗ࠱࠶ࡹࡴࠨম"))
	if TYf7Dc06PQgy1vEV9(u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪয") in list(b3HKopTY9zLUyhJmt.headers.keys()): GSh0nJxEXgZjd48u7mBwWOeafyAp5b = b3HKopTY9zLUyhJmt.headers[Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫর")]
	if ubxGUTt1LraKhVZgpAP(u"ࠪ࡬ࡹࡺࡰࠨ঱") in GSh0nJxEXgZjd48u7mBwWOeafyAp5b:
		if TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬল") in url: GSh0nJxEXgZjd48u7mBwWOeafyAp5b = GSh0nJxEXgZjd48u7mBwWOeafyAp5b.replace(TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠬ࠵ࡦ࠰ࠩ঳"),yST5AHEfvPmcWpwGuh2BJ(u"࠭࠯ࡷ࠱ࠪ঴"))
		SS8PYJtqjypheaXkOHngrD9Fwfmb3A = MUJCtfYVBLODrFbaZn.split(HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠧࡀࡒࡋࡔࡘࡏࡄ࠾ࠩ঵"))[qHYIWnOZLPkrQU]
		headers = { QTUBCcehw6qPd4x(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬশ"):headers[ddo23ZJtgcY(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ষ")] , Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠪࡇࡴࡵ࡫ࡪࡧࠪস"):dDYUoKi6JFM23p(u"ࠫࡕࡎࡐࡔࡋࡇࡁࠬহ")+SS8PYJtqjypheaXkOHngrD9Fwfmb3A }
		b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(LtlXH3fvMydAx,QQdAXWBc2GPw(u"ࠬࡍࡅࡕࠩ঺"),GSh0nJxEXgZjd48u7mBwWOeafyAp5b,b8Qe150xVaJsnDSv,headers,DD5cFIejQa2X4BgAu9GWPyJ3tC7,b8Qe150xVaJsnDSv,RRIHDFjoW9w7bSfVPhC(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠭ࡑࡎࡄ࡝࠲࠹ࡲࡥࠩ঻"))
		jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
		if kke1PDGRBLuY8y(u"ࠧ࠰ࡨ࠲়ࠫ") in GSh0nJxEXgZjd48u7mBwWOeafyAp5b: items = YYBlm36zd0Jst18LXwo4.findall(yST5AHEfvPmcWpwGuh2BJ(u"ࠨ࠾࡫࠶ࡃ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧঽ"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		elif Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠩ࠲ࡺ࠴࠭া") in GSh0nJxEXgZjd48u7mBwWOeafyAp5b: items = YYBlm36zd0Jst18LXwo4.findall(mQNonhS7CV2BXOv(u"ࠪ࡭ࡩࡃࠢࡷ࡫ࡧࡩࡴࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧি"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if items: return [],[b8Qe150xVaJsnDSv],[ items[LzYQg91SIxDeOGtCKd5] ]
		elif TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠫࡁ࡮࠱࠿࠶࠳࠸ࡁ࠵ࡨ࠲ࡀࠪী") in jLtdbeYiQHnf4SpU2MTly:
			return RRIHDFjoW9w7bSfVPhC(u"ࠬࡋࡲࡳࡱࡵ࠾ู๊ࠥาใิࠤฬ๊แ๋ัํ์ࠥ็๊่ࠢะะอࠦึะࠢๆ์ิ๐้ࠠ็ุำึํࠠๆ่ࠣห้หๆหำ้ฮࠥอไฯษุอࠥฮใࠨু"),[],[]
	else: return Nh0BWuiSndf(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡇࡊ࡝ࡇࡋࡓࡕࠩূ"),[],[]
def cjM8eNGR7n(pcA1dzy7LXwGfMPg9mTkuh5tine3):
	GGYbRJxlHWKpQ2ihCD = YYBlm36zd0Jst18LXwo4.findall(zI3ROAZtiUq42rE9WDST68(u"ࠧࡱࡱࡶࡸ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠬࡳࡦࡴࡹࡩࡷ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠦࠧࠩৃ"),pcA1dzy7LXwGfMPg9mTkuh5tine3+vvWwO3Tx2dAgcijrFXq(u"ࠨࠨࠩࠫৄ"),YYBlm36zd0Jst18LXwo4.DOTALL|YYBlm36zd0Jst18LXwo4.IGNORECASE)
	DlhJPky307SxBNGUL,zEO5iu267rjZ1qphcCUvl = GGYbRJxlHWKpQ2ihCD[LzYQg91SIxDeOGtCKd5]
	url = mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡷࡪࡸࡩࡦࡵ࠷ࡻࡦࡺࡣࡩ࠰ࡱࡩࡹ࠵ࡡ࡫ࡣࡻࡇࡪࡴࡴࡦࡴࡂࡣࡦࡩࡴࡪࡱࡱࡁ࡬࡫ࡴࡴࡧࡵࡺࡪࡸࠦࡠࡲࡲࡷࡹࡥࡩࡥ࠿ࠪ৅")+DlhJPky307SxBNGUL+ddo23ZJtgcY(u"ࠪࠪࡸ࡫ࡲࡷࡧࡵ࡭ࡩࡃࠧ৆")+zEO5iu267rjZ1qphcCUvl
	headers = { mQNonhS7CV2BXOv(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨে"):b8Qe150xVaJsnDSv , Xz3bA2PFENVCUtplu51(u"ࠬ࡞࠭ࡓࡧࡴࡹࡪࡹࡴࡦࡦ࠰࡛࡮ࡺࡨࠨৈ"):kke1PDGRBLuY8y(u"࠭ࡘࡎࡎࡋࡸࡹࡶࡒࡦࡳࡸࡩࡸࡺࠧ৉") }
	MUJCtfYVBLODrFbaZn = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(LtlXH3fvMydAx,url,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡗࡊࡘࡉࡆࡕ࠷࡛ࡆ࡚ࡃࡉ࠯࠴ࡷࡹ࠭৊"))
	return HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫো"),[b8Qe150xVaJsnDSv],[MUJCtfYVBLODrFbaZn]
def quCJpzXv4r(url):
	LLOCdZ3sS2enzXx4fVB18YRvbHNwky = Wl2eu1PavfQ(url,LAQD5wEkr18bUiGaYen3J(u"ࠩࡸࡶࡱ࠭ৌ"))
	ybF0H85nUohsiRQcpaTfZAKzjMY7wB = {mQNonhS7CV2BXOv(u"ࠪࡖࡪ࡬ࡥࡳࡧࡵ্ࠫ"):LLOCdZ3sS2enzXx4fVB18YRvbHNwky,m6hwdgP31a2zjN7lkpX(u"ࠫࡆࡩࡣࡦࡲࡷ࠱ࡊࡴࡣࡰࡦ࡬ࡲ࡬࠭ৎ"):shC5qBRV2A0lZ(u"ࠬ࡭ࡺࡪࡲ࠯ࠤࡩ࡫ࡦ࡭ࡣࡷࡩࠬ৏")}
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(IiYS8Jg4da3UuDP0qr6vy,zI3ROAZtiUq42rE9WDST68(u"࠭ࡇࡆࡖࠪ৐"),url,b8Qe150xVaJsnDSv,ybF0H85nUohsiRQcpaTfZAKzjMY7wB,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,yST5AHEfvPmcWpwGuh2BJ(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡑ࡞ࡉࡉࡎࡃ࠰࠵ࡸࡺࠧ৑"))
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall(vvWwO3Tx2dAgcijrFXq(u"ࠨࡲ࡯ࡥࡾ࡫ࡲ࠯ࡳࡸࡥࡱ࡯ࡴࡺࡵࡨࡰࡪࡩࡴࡰࡴࠫ࠲࠯ࡅࠩࡧࡱࡵࡱࡦࡺࡳ࠻ࠩ৒"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	MUJCtfYVBLODrFbaZn = b8Qe150xVaJsnDSv
	if ZV5rRvabhxJ:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[LzYQg91SIxDeOGtCKd5]
		items = YYBlm36zd0Jst18LXwo4.findall(uVQd103XyvUce2EBtzbYaC(u"ࠩࡩࡳࡷࡳࡡࡵ࠼ࠣࡠࠬ࠮࡜ࡥ࠰࠭ࡃ࠮ࡢࠧ࠭ࠢࡶࡶࡨࡀࠠࠣࠪ࠱࠮ࡄ࠯ࠢࠨ৓"),OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = [],[]
		for title,pcA1dzy7LXwGfMPg9mTkuh5tine3 in items:
			uuSKUinvP4EGLxWZYmTsF.append(title)
			KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
		if len(KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j)==qHYIWnOZLPkrQU: MUJCtfYVBLODrFbaZn = KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j[LzYQg91SIxDeOGtCKd5]
		elif len(KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j)>qHYIWnOZLPkrQU:
			cMZGTsAR2E = XXprCMzuNP2mElUxfdA(vvWwO3Tx2dAgcijrFXq(u"ࠪวำะัࠡษ็้้็ࠠศๆ่๊ฬูศࠨ৔"), uuSKUinvP4EGLxWZYmTsF)
			if cMZGTsAR2E==-qHYIWnOZLPkrQU: return HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠫࡊ࡞ࡉࡕࡡࡄࡐࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ৕"),[],[]
			MUJCtfYVBLODrFbaZn = KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j[cMZGTsAR2E]
	else:
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall(UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠬࡹ࡯ࡶࡴࡦࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ৖"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if ZV5rRvabhxJ: MUJCtfYVBLODrFbaZn = ZV5rRvabhxJ[LzYQg91SIxDeOGtCKd5]
	if not MUJCtfYVBLODrFbaZn: return Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡏ࡜ࡇࡎࡓࡁࠨৗ"),[],[]
	return mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ৘"),[b8Qe150xVaJsnDSv],[MUJCtfYVBLODrFbaZn]
def EXCsxBM5TGupzSIkql(url):
	LLOCdZ3sS2enzXx4fVB18YRvbHNwky = Wl2eu1PavfQ(url,BmePGjS7FxK6kutUM(u"ࠨࡷࡵࡰࠬ৙"))
	ybF0H85nUohsiRQcpaTfZAKzjMY7wB = {yST5AHEfvPmcWpwGuh2BJ(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ৚"):LLOCdZ3sS2enzXx4fVB18YRvbHNwky,m6hwdgP31a2zjN7lkpX(u"ࠪࡅࡨࡩࡥࡱࡶ࠰ࡉࡳࡩ࡯ࡥ࡫ࡱ࡫ࠬ৛"):RRIHDFjoW9w7bSfVPhC(u"ࠫ࡬ࢀࡩࡱ࠮ࠣࡨࡪ࡬࡬ࡢࡶࡨࠫড়")}
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(IiYS8Jg4da3UuDP0qr6vy,TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠬࡍࡅࡕࠩঢ়"),url,b8Qe150xVaJsnDSv,ybF0H85nUohsiRQcpaTfZAKzjMY7wB,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,dDYUoKi6JFM23p(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡚ࡉࡈࡏࡍࡂ࠯࠴ࡷࡹ࠭৞"))
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall(DYakr9g4PVU(u"ࠧࡱ࡮ࡤࡽࡪࡸ࠮ࡲࡷࡤࡰ࡮ࡺࡹࡴࡧ࡯ࡩࡨࡺ࡯ࡳࠪ࠱࠮ࡄ࠯ࡦࡰࡴࡰࡥࡹࡹ࠺ࠨয়"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	MUJCtfYVBLODrFbaZn = b8Qe150xVaJsnDSv
	if ZV5rRvabhxJ:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[LzYQg91SIxDeOGtCKd5]
		items = YYBlm36zd0Jst18LXwo4.findall(BmePGjS7FxK6kutUM(u"ࠨࡨࡲࡶࡲࡧࡴ࠻ࠢ࡟ࠫ࠭ࡢࡤ࠯ࠬࡂ࠭ࡡ࠭ࠬࠡࡵࡵࡧ࠿ࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠧৠ"),OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = [],[]
		for title,pcA1dzy7LXwGfMPg9mTkuh5tine3 in items:
			uuSKUinvP4EGLxWZYmTsF.append(title)
			KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
		if len(KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j)==qHYIWnOZLPkrQU: MUJCtfYVBLODrFbaZn = KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j[LzYQg91SIxDeOGtCKd5]
		elif len(KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j)>qHYIWnOZLPkrQU:
			cMZGTsAR2E = XXprCMzuNP2mElUxfdA(TYf7Dc06PQgy1vEV9(u"ࠩฦาฯืࠠศๆ่่ๆࠦวๅ็้หุฮࠧৡ"), uuSKUinvP4EGLxWZYmTsF)
			if cMZGTsAR2E==-qHYIWnOZLPkrQU: return vvWwO3Tx2dAgcijrFXq(u"ࠪࡉ࡝ࡏࡔࡠࡃࡏࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨৢ"),[],[]
			MUJCtfYVBLODrFbaZn = KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j[cMZGTsAR2E]
	if not MUJCtfYVBLODrFbaZn:
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall(dDYUoKi6JFM23p(u"ࠫࡸࡵࡵࡳࡥࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩৣ"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if ZV5rRvabhxJ: MUJCtfYVBLODrFbaZn = ZV5rRvabhxJ[LzYQg91SIxDeOGtCKd5]
	if not MUJCtfYVBLODrFbaZn: return LAQD5wEkr18bUiGaYen3J(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡘࡇࡆࡍࡒࡇࠧ৤"),[],[]
	return zI3ROAZtiUq42rE9WDST68(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ৥"),[b8Qe150xVaJsnDSv],[MUJCtfYVBLODrFbaZn]
def MxkbhgKr40(pcA1dzy7LXwGfMPg9mTkuh5tine3):
	GGYbRJxlHWKpQ2ihCD = YYBlm36zd0Jst18LXwo4.findall(mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠧࠩࡪࡷࡸࡵ࠴ࠪࡀࠫ࡟ࡃࡵࡵࡳࡵ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠩࡷࡪࡸࡶࡦࡴ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠪࠫ࠭০"),pcA1dzy7LXwGfMPg9mTkuh5tine3+uVQd103XyvUce2EBtzbYaC(u"ࠨࠨࠩࠫ১"),YYBlm36zd0Jst18LXwo4.DOTALL)
	url,DlhJPky307SxBNGUL,zEO5iu267rjZ1qphcCUvl = GGYbRJxlHWKpQ2ihCD[LzYQg91SIxDeOGtCKd5]
	data = {dDYUoKi6JFM23p(u"ࠩࡳࡳࡸࡺ࡟ࡪࡦࠪ২"):DlhJPky307SxBNGUL,kke1PDGRBLuY8y(u"ࠪࡷࡪࡸࡶࡦࡴࠪ৩"):zEO5iu267rjZ1qphcCUvl}
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,uVQd103XyvUce2EBtzbYaC(u"ࠫࡕࡕࡓࡕࠩ৪"),url,data,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,IjZbnrBJmM2N(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡎࡓࡆࡓࡃࡂࡏ࠰࠵ࡸࡺࠧ৫"))
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	MUJCtfYVBLODrFbaZn = YYBlm36zd0Jst18LXwo4.findall(LAQD5wEkr18bUiGaYen3J(u"࠭ࡩࡧࡴࡤࡱࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ৬"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)[LzYQg91SIxDeOGtCKd5]
	return TYf7Dc06PQgy1vEV9(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ৭"),[b8Qe150xVaJsnDSv],[MUJCtfYVBLODrFbaZn]
def qfcDtmraLC(url):
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,uVQd103XyvUce2EBtzbYaC(u"ࠨࡉࡈࡘࠬ৮"),url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,TYf7Dc06PQgy1vEV9(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡉࡉࡎࡃࡏࡍࡌࡎࡔ࠮࠳ࡶࡸࠬ৯"))
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	pcA1dzy7LXwGfMPg9mTkuh5tine3 = YYBlm36zd0Jst18LXwo4.findall(kke1PDGRBLuY8y(u"ࠪࡀ࡮࡬ࡲࡢ࡯ࡨ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫৰ"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if pcA1dzy7LXwGfMPg9mTkuh5tine3:
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3[LzYQg91SIxDeOGtCKd5]
		if pcA1dzy7LXwGfMPg9mTkuh5tine3: return yST5AHEfvPmcWpwGuh2BJ(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧৱ"),[b8Qe150xVaJsnDSv],[pcA1dzy7LXwGfMPg9mTkuh5tine3]
	return UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡄࡋࡐࡅࡑࡏࡇࡉࡖࠪ৲"),[],[]
def Ye1lI5r7E3(url):
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,SbjiWeHLQPoazqwp3cODkd7YxVgn(u"࠭ࡇࡆࡖࠪ৳"),url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,Nh0BWuiSndf(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡇࡎࡓࡁࡄࡎࡘࡔ࠲࠷ࡳࡵࠩ৴"))
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	pcA1dzy7LXwGfMPg9mTkuh5tine3 = YYBlm36zd0Jst18LXwo4.findall(IjZbnrBJmM2N(u"ࠨ࠾ࡌࡊࡗࡇࡍࡆࠢࡖࡖࡈࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ৵"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)[LzYQg91SIxDeOGtCKd5]
	return Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ৶"),[b8Qe150xVaJsnDSv],[pcA1dzy7LXwGfMPg9mTkuh5tine3]
def jeADxZEL0I(url):
	e3To7sm0Nzn1CruYWxGh = Wl2eu1PavfQ(url,Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠪࡹࡷࡲࠧ৷"))
	if P0qdZI384LKleuo(u"ࠫ࡮ࡴࡤࡦࡺࡀࠫ৸") in url:
		headers = {VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭৹"):e3To7sm0Nzn1CruYWxGh}
		b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,Xz3bA2PFENVCUtplu51(u"࠭ࡇࡆࡖࠪ৺"),url,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,QTUBCcehw6qPd4x(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡇࡎࡓࡁࡏࡑ࡚࠱࠶ࡹࡴࠨ৻"))
		jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
		MUJCtfYVBLODrFbaZn = YYBlm36zd0Jst18LXwo4.findall(ddo23ZJtgcY(u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ৼ"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if MUJCtfYVBLODrFbaZn:
			MUJCtfYVBLODrFbaZn = MUJCtfYVBLODrFbaZn[LzYQg91SIxDeOGtCKd5]
			if RRIHDFjoW9w7bSfVPhC(u"ࠩ࡫ࡸࡹࡶࠧ৽") not in MUJCtfYVBLODrFbaZn: MUJCtfYVBLODrFbaZn = BmePGjS7FxK6kutUM(u"ࠪ࡬ࡹࡺࡰ࠻ࠩ৾")+MUJCtfYVBLODrFbaZn
			if BWNPxIG7vqdTy85pjHzUOrK3(u"ࠫࡨ࡯࡭ࡢࡰࡲࡻࠬ৿") in MUJCtfYVBLODrFbaZn:
				MUJCtfYVBLODrFbaZn = MUJCtfYVBLODrFbaZn.replace(mQNonhS7CV2BXOv(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࠧ਀"),DYakr9g4PVU(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࠧਁ"))
				b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,dDYUoKi6JFM23p(u"ࠧࡈࡇࡗࠫਂ"),MUJCtfYVBLODrFbaZn,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡈࡏࡍࡂࡐࡒ࡛࠲࠸࡮ࡥࠩਃ"))
				vWsMIpk1n6rlLqH52 = b3HKopTY9zLUyhJmt.content
				items = YYBlm36zd0Jst18LXwo4.findall(kke1PDGRBLuY8y(u"ࠩࡶࡳࡺࡸࡣࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶ࡭ࡿ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ਄"),vWsMIpk1n6rlLqH52,YYBlm36zd0Jst18LXwo4.DOTALL)
				uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = [],[]
				cCxjKQGYDfZWpd5 = Wl2eu1PavfQ(MUJCtfYVBLODrFbaZn,BWNPxIG7vqdTy85pjHzUOrK3(u"ࠪࡹࡷࡲࠧਅ"))
				for pcA1dzy7LXwGfMPg9mTkuh5tine3,c1EdszLx3mkb8QYX9 in reversed(items):
					pcA1dzy7LXwGfMPg9mTkuh5tine3 = cCxjKQGYDfZWpd5+pcA1dzy7LXwGfMPg9mTkuh5tine3+S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠫࢁࡘࡥࡧࡧࡵࡩࡷࡃࠧਆ")+cCxjKQGYDfZWpd5
					uuSKUinvP4EGLxWZYmTsF.append(c1EdszLx3mkb8QYX9)
					KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
				return b8Qe150xVaJsnDSv,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j
			else: return zI3ROAZtiUq42rE9WDST68(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨਇ"),[b8Qe150xVaJsnDSv],[MUJCtfYVBLODrFbaZn]
	MUJCtfYVBLODrFbaZn = url+uVQd103XyvUce2EBtzbYaC(u"࠭ࡼࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠩਈ")+e3To7sm0Nzn1CruYWxGh
	if QQdAXWBc2GPw(u"ࠧࡩࡶࡷࡴࠬਉ") not in MUJCtfYVBLODrFbaZn: MUJCtfYVBLODrFbaZn = S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠨࡪࡷࡸࡵࡀࠧਊ")+MUJCtfYVBLODrFbaZn
	return b8Qe150xVaJsnDSv,[b8Qe150xVaJsnDSv],[MUJCtfYVBLODrFbaZn]
def KSUoNBzHhdabYuQptne3mxcPl(pcA1dzy7LXwGfMPg9mTkuh5tine3):
	e3To7sm0Nzn1CruYWxGh = Wl2eu1PavfQ(pcA1dzy7LXwGfMPg9mTkuh5tine3,DYakr9g4PVU(u"ࠩࡸࡶࡱ࠭਋"))
	if shC5qBRV2A0lZ(u"ࠪࡴࡴࡹࡴࡪࡦࠪ਌") in pcA1dzy7LXwGfMPg9mTkuh5tine3:
		GGYbRJxlHWKpQ2ihCD = YYBlm36zd0Jst18LXwo4.findall(ubxGUTt1LraKhVZgpAP(u"ࠫ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯࡜ࡀࡲࡲࡷࡹ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠦࡴࡧࡵࡺࡪࡸࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠧࠨࠪ਍"),pcA1dzy7LXwGfMPg9mTkuh5tine3+QTUBCcehw6qPd4x(u"ࠬࠬࠦࠨ਎"),YYBlm36zd0Jst18LXwo4.DOTALL)
		url,DlhJPky307SxBNGUL,zEO5iu267rjZ1qphcCUvl = GGYbRJxlHWKpQ2ihCD[LzYQg91SIxDeOGtCKd5]
		data = {RRIHDFjoW9w7bSfVPhC(u"࠭ࡩࡥࠩਏ"):DlhJPky307SxBNGUL,HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠧࡴࡧࡵࡺࡪࡸࠧਐ"):zEO5iu267rjZ1qphcCUvl}
		b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,Nh0BWuiSndf(u"ࠨࡒࡒࡗ࡙࠭਑"),url,data,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,zI3ROAZtiUq42rE9WDST68(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡉࡉࡎࡃࡑࡓ࡜࠳࠱ࡴࡶࠪ਒"))
		jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
		MUJCtfYVBLODrFbaZn = YYBlm36zd0Jst18LXwo4.findall(SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠪ࡭࡫ࡸࡡ࡮ࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨਓ"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)[LzYQg91SIxDeOGtCKd5]
		if TYf7Dc06PQgy1vEV9(u"ࠫࡨ࡯࡭ࡢࡰࡲࡻࠬਔ") in MUJCtfYVBLODrFbaZn:
			headers = {BmePGjS7FxK6kutUM(u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭ਕ"):e3To7sm0Nzn1CruYWxGh,Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪਖ"):b8Qe150xVaJsnDSv}
			b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠧࡈࡇࡗࠫਗ"),MUJCtfYVBLODrFbaZn,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,vvWwO3Tx2dAgcijrFXq(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡈࡏࡍࡂࡐࡒ࡛࠲࠸࡮ࡥࠩਘ"))
			vWsMIpk1n6rlLqH52 = b3HKopTY9zLUyhJmt.content
			items = YYBlm36zd0Jst18LXwo4.findall(Xz3bA2PFENVCUtplu51(u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶ࡭ࡿ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨਙ"),vWsMIpk1n6rlLqH52,YYBlm36zd0Jst18LXwo4.DOTALL)
			uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = [],[]
			cCxjKQGYDfZWpd5 = Wl2eu1PavfQ(MUJCtfYVBLODrFbaZn,dDYUoKi6JFM23p(u"ࠪࡹࡷࡲࠧਚ"))
			for pcA1dzy7LXwGfMPg9mTkuh5tine3,c1EdszLx3mkb8QYX9 in reversed(items):
				pcA1dzy7LXwGfMPg9mTkuh5tine3 = cCxjKQGYDfZWpd5+pcA1dzy7LXwGfMPg9mTkuh5tine3+VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠫࢁࡘࡥࡧࡧࡵࡩࡷࡃࠧਛ")+cCxjKQGYDfZWpd5
				uuSKUinvP4EGLxWZYmTsF.append(c1EdszLx3mkb8QYX9)
				KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
			return b8Qe150xVaJsnDSv,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j
		else: return shC5qBRV2A0lZ(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨਜ"),[b8Qe150xVaJsnDSv],[MUJCtfYVBLODrFbaZn]
	else:
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3+SbjiWeHLQPoazqwp3cODkd7YxVgn(u"࠭ࡼࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠩਝ")+e3To7sm0Nzn1CruYWxGh
		return b8Qe150xVaJsnDSv,[b8Qe150xVaJsnDSv],[pcA1dzy7LXwGfMPg9mTkuh5tine3]
def twBo6ILYAy(pcA1dzy7LXwGfMPg9mTkuh5tine3):
	if VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠧࡱࡱࡶࡸ࡮ࡪࠧਞ") in pcA1dzy7LXwGfMPg9mTkuh5tine3:
		GGYbRJxlHWKpQ2ihCD = YYBlm36zd0Jst18LXwo4.findall(yST5AHEfvPmcWpwGuh2BJ(u"ࠨࡲࡲࡷࡹ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠦࡴࡧࡵࡺࡪࡸࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠧࠨࠪਟ"),pcA1dzy7LXwGfMPg9mTkuh5tine3+m6hwdgP31a2zjN7lkpX(u"ࠩࠩࠪࠬਠ"),YYBlm36zd0Jst18LXwo4.DOTALL|YYBlm36zd0Jst18LXwo4.IGNORECASE)
		DlhJPky307SxBNGUL,zEO5iu267rjZ1qphcCUvl = GGYbRJxlHWKpQ2ihCD[LzYQg91SIxDeOGtCKd5]
		ADZvOGKc6yBEl9bVwm3U4 = Wl2eu1PavfQ(pcA1dzy7LXwGfMPg9mTkuh5tine3,BmePGjS7FxK6kutUM(u"ࠪࡹࡷࡲࠧਡ"))
		url = ADZvOGKc6yBEl9bVwm3U4+SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠫ࠴ࡧࡪࡢࡺࡆࡩࡳࡺࡥࡳࡁࡢࡥࡨࡺࡩࡰࡰࡀ࡫ࡪࡺࡳࡦࡴࡹࡩࡷࠬ࡟ࡱࡱࡶࡸࡤ࡯ࡤ࠾ࠩਢ")+DlhJPky307SxBNGUL+ubxGUTt1LraKhVZgpAP(u"ࠬࠬࡳࡦࡴࡹࡩࡷ࡯ࡤ࠾ࠩਣ")+zEO5iu267rjZ1qphcCUvl
		headers = { P0qdZI384LKleuo(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪਤ"):b8Qe150xVaJsnDSv , UUkIBz1sgQ9WfNeG6trKXvu0(u"࡙ࠧ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪࠪਥ"):ddo23ZJtgcY(u"ࠨ࡚ࡐࡐࡍࡺࡴࡱࡔࡨࡵࡺ࡫ࡳࡵࠩਦ") }
		MUJCtfYVBLODrFbaZn = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(LtlXH3fvMydAx,url,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,BmePGjS7FxK6kutUM(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡒࡃࡎࡌࡓࡓࡠ࠭࠲ࡵࡷࠫਧ"))
		MUJCtfYVBLODrFbaZn = MUJCtfYVBLODrFbaZn.replace(eeN6dTEnkJxI,b8Qe150xVaJsnDSv).replace(d6ekSEojpFUANKJ7r9WTlI3niLBOu,b8Qe150xVaJsnDSv)
		return uVQd103XyvUce2EBtzbYaC(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ਨ"),[b8Qe150xVaJsnDSv],[MUJCtfYVBLODrFbaZn]
	elif Xz3bA2PFENVCUtplu51(u"ࠫ࠴ࡸࡥࡥ࡫ࡵࡩࡨࡺ࠯ࠨ਩") in pcA1dzy7LXwGfMPg9mTkuh5tine3:
		iG0zufnFdZMAqHWJtOKXaE = LzYQg91SIxDeOGtCKd5
		while Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠬ࠵ࡲࡦࡦ࡬ࡶࡪࡩࡴ࠰ࠩਪ") in pcA1dzy7LXwGfMPg9mTkuh5tine3 and iG0zufnFdZMAqHWJtOKXaE<uVQd103XyvUce2EBtzbYaC(u"࠸෵"):
			b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(Q49IsrlSuYRAVbGKhwdckLDOetF2PZ,P0qdZI384LKleuo(u"࠭ࡇࡆࡖࠪਫ"),pcA1dzy7LXwGfMPg9mTkuh5tine3,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,mQNonhS7CV2BXOv(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡗࡈࡌࡊࡑࡑ࡞࠲࠸࡮ࡥࠩਬ"))
			if BmePGjS7FxK6kutUM(u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪਭ") in list(b3HKopTY9zLUyhJmt.headers.keys()): pcA1dzy7LXwGfMPg9mTkuh5tine3 = b3HKopTY9zLUyhJmt.headers[ddo23ZJtgcY(u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫਮ")]
			iG0zufnFdZMAqHWJtOKXaE += qHYIWnOZLPkrQU
		return b8Qe150xVaJsnDSv,[b8Qe150xVaJsnDSv],[pcA1dzy7LXwGfMPg9mTkuh5tine3]
	else: return m6hwdgP31a2zjN7lkpX(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡇࡒࡃࡎࡌࡓࡓࡠࠧਯ"),[],[]
def CZJ7QPaeh2(url):
	LLOCdZ3sS2enzXx4fVB18YRvbHNwky = Wl2eu1PavfQ(url,DYakr9g4PVU(u"ࠫࡺࡸ࡬ࠨਰ"))
	headers = {DYakr9g4PVU(u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭਱"):LLOCdZ3sS2enzXx4fVB18YRvbHNwky,Mmpr0o76iWJvz1kTtfgI8hES(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪਲ"):kIMmsSG9NW6BOjlTpnEcuRzgwK()}
	if VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠧ࠰ࡧࡰࡦࡪࡪ࠭ࠨਲ਼") in url:
		jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(LtlXH3fvMydAx,url,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,BmePGjS7FxK6kutUM(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡘࡁࡃࡕࡈࡉࡉ࠳࠲࡯ࡦࠪ਴"))
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = YYBlm36zd0Jst18LXwo4.findall(HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠩ࠿ࡷࡴࡻࡲࡤࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨਵ"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if pcA1dzy7LXwGfMPg9mTkuh5tine3:
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3[LzYQg91SIxDeOGtCKd5].replace(SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠪ࡬ࡹࡺࡰࡴࠩਸ਼"),TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠫ࡭ࡺࡴࡱࠩ਷"))
			return b8Qe150xVaJsnDSv,[b8Qe150xVaJsnDSv],[pcA1dzy7LXwGfMPg9mTkuh5tine3]
	else:
		wzHV6rqXs0 = dcLRAZWFzODax2jf0tHCX81pJveNY(Q49IsrlSuYRAVbGKhwdckLDOetF2PZ,HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠬࡍࡅࡕࠩਸ"),url,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,m6hwdgP31a2zjN7lkpX(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡖࡆࡈࡓࡆࡇࡇ࠱࠸ࡸࡤࠨਹ"))
		jLtdbeYiQHnf4SpU2MTly = wzHV6rqXs0.content
		ybF0H85nUohsiRQcpaTfZAKzjMY7wB = headers.copy()
		if Nh0BWuiSndf(u"ࠧࡠ࡮ࡱ࡯ࡤ࠭਺") in str(wzHV6rqXs0.cookies):
			cookies = wzHV6rqXs0.cookies
			ybF0H85nUohsiRQcpaTfZAKzjMY7wB[S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠨࡅࡲࡳࡰ࡯ࡥࠨ਻")] = SgrGWuAHcLKBQMJetb9(uVsW5TNRM2vDOn(cookies))
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = YYBlm36zd0Jst18LXwo4.findall(Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠩ࡯࡭ࡳࡱ࠮ࡩࡴࡨࡪࠥࡃࠠࠣࠪ࡫ࡸࡹࡶ࠮ࠫࡁ਼ࠬࠦࠬ"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if not pcA1dzy7LXwGfMPg9mTkuh5tine3: return Nh0BWuiSndf(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭਽"),[b8Qe150xVaJsnDSv],[url]
		else:
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = SgrGWuAHcLKBQMJetb9(pcA1dzy7LXwGfMPg9mTkuh5tine3[LzYQg91SIxDeOGtCKd5])+vvWwO3Tx2dAgcijrFXq(u"ࠫࠫࡪ࠽࠲ࠩਾ")
			Z8VU1cMugRwIjL2fpSyPJFHokYrqa = dcLRAZWFzODax2jf0tHCX81pJveNY(Q49IsrlSuYRAVbGKhwdckLDOetF2PZ,VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠬࡍࡅࡕࠩਿ"),pcA1dzy7LXwGfMPg9mTkuh5tine3,b8Qe150xVaJsnDSv,ybF0H85nUohsiRQcpaTfZAKzjMY7wB,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,vvWwO3Tx2dAgcijrFXq(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡖࡆࡈࡓࡆࡇࡇ࠱࠹ࡺࡨࠨੀ"))
			jLtdbeYiQHnf4SpU2MTly = Z8VU1cMugRwIjL2fpSyPJFHokYrqa.content
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = YYBlm36zd0Jst18LXwo4.findall(BWNPxIG7vqdTy85pjHzUOrK3(u"ࠧࡪࡦࡀࠦࡧࡺ࡮ࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪੁ"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
			if pcA1dzy7LXwGfMPg9mTkuh5tine3:
				pcA1dzy7LXwGfMPg9mTkuh5tine3 = SgrGWuAHcLKBQMJetb9(pcA1dzy7LXwGfMPg9mTkuh5tine3[LzYQg91SIxDeOGtCKd5])
				if TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠨ࡯ࡳ࠸ࠬੂ") in pcA1dzy7LXwGfMPg9mTkuh5tine3 and IjZbnrBJmM2N(u"ࠩ࠲ࡨ࠴࠭੃") in pcA1dzy7LXwGfMPg9mTkuh5tine3: return b8Qe150xVaJsnDSv,[b8Qe150xVaJsnDSv],[pcA1dzy7LXwGfMPg9mTkuh5tine3]
				else: return mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭੄"),[b8Qe150xVaJsnDSv],[pcA1dzy7LXwGfMPg9mTkuh5tine3]
	return UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡁࡓࡃࡅࡗࡊࡋࡄࠨ੅"),[],[]
def LLXhstl7gG(pcA1dzy7LXwGfMPg9mTkuh5tine3):
	if Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠬࡥࡡࡤࡶ࡬ࡳࡳࡃࡧࡦࡶࡶࡩࡷࡼࡥࡳࠩ੆") in pcA1dzy7LXwGfMPg9mTkuh5tine3:
		headers = {mmcNLrXtzfpyCkZlvK5VwG2gujh(u"࠭ࡘ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡧࡧ࠱࡜࡯ࡴࡩࠩੇ"):Xz3bA2PFENVCUtplu51(u"࡙ࠧࡏࡏࡌࡹࡺࡰࡓࡧࡴࡹࡪࡹࡴࠨੈ")}
		b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,QTUBCcehw6qPd4x(u"ࠨࡉࡈࡘࠬ੉"),pcA1dzy7LXwGfMPg9mTkuh5tine3,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡙ࡈࡂࡊࡌࡈ࠹࡛࠭࠲ࡵࡷࠫ੊"))
		url = b3HKopTY9zLUyhJmt.content
		if url: return uVQd103XyvUce2EBtzbYaC(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ੋ"),[b8Qe150xVaJsnDSv],[url]
	else:
		GGYbRJxlHWKpQ2ihCD = YYBlm36zd0Jst18LXwo4.findall(RRIHDFjoW9w7bSfVPhC(u"ࠫࡵࡵࡳࡵ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠩࡷࡪࡸࡶࡦࡴ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠨࠬੌ"),pcA1dzy7LXwGfMPg9mTkuh5tine3,YYBlm36zd0Jst18LXwo4.DOTALL|YYBlm36zd0Jst18LXwo4.IGNORECASE)
		if not GGYbRJxlHWKpQ2ihCD: GGYbRJxlHWKpQ2ihCD = YYBlm36zd0Jst18LXwo4.findall(LAQD5wEkr18bUiGaYen3J(u"ࠬࡥࡰࡰࡵࡷࡣ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠬࡳࡦࡴࡹࡩࡷ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠤࠨ੍"),pcA1dzy7LXwGfMPg9mTkuh5tine3,YYBlm36zd0Jst18LXwo4.DOTALL|YYBlm36zd0Jst18LXwo4.IGNORECASE)
		DlhJPky307SxBNGUL,zEO5iu267rjZ1qphcCUvl = GGYbRJxlHWKpQ2ihCD[LzYQg91SIxDeOGtCKd5]
		LLOCdZ3sS2enzXx4fVB18YRvbHNwky = Wl2eu1PavfQ(pcA1dzy7LXwGfMPg9mTkuh5tine3,TYf7Dc06PQgy1vEV9(u"࠭ࡵࡳ࡮ࠪ੎"))
		url = LLOCdZ3sS2enzXx4fVB18YRvbHNwky+uVQd103XyvUce2EBtzbYaC(u"ࠧ࠰ࡹࡳ࠱ࡨࡵ࡮ࡵࡧࡱࡸ࠴ࡺࡨࡦ࡯ࡨࡷ࠴ࡺࡨࡦ࡯ࡨ࠳ࡆࡰࡡࡹࡣࡷ࠳ࡘ࡯࡮ࡨ࡮ࡨ࠳ࡘ࡫ࡲࡷࡧࡵ࠲ࡵ࡮ࡰࠨ੏")
		data = {LAQD5wEkr18bUiGaYen3J(u"ࠨ࡫ࡧࠫ੐"):DlhJPky307SxBNGUL,SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠩ࡬ࠫੑ"):zEO5iu267rjZ1qphcCUvl}
		headers = {P0qdZI384LKleuo(u"ࠪ࡜࠲ࡘࡥࡲࡷࡨࡷࡹ࡫ࡤ࠮࡙࡬ࡸ࡭࠭੒"):TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠫ࡝ࡓࡌࡉࡶࡷࡴࡗ࡫ࡱࡶࡧࡶࡸࠬ੓"),yST5AHEfvPmcWpwGuh2BJ(u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭੔"):pcA1dzy7LXwGfMPg9mTkuh5tine3}
		b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"࠭ࡐࡐࡕࡗࠫ੕"),url,data,headers,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡗࡍࡇࡈࡊࡆ࠷࡙࠲࠸࡮ࡥࠩ੖"))
		vWsMIpk1n6rlLqH52 = b3HKopTY9zLUyhJmt.content
		MUJCtfYVBLODrFbaZn = YYBlm36zd0Jst18LXwo4.findall(ubxGUTt1LraKhVZgpAP(u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭੗"),vWsMIpk1n6rlLqH52,YYBlm36zd0Jst18LXwo4.DOTALL|YYBlm36zd0Jst18LXwo4.IGNORECASE)
		if MUJCtfYVBLODrFbaZn:
			MUJCtfYVBLODrFbaZn = MUJCtfYVBLODrFbaZn[LzYQg91SIxDeOGtCKd5]
			return vvWwO3Tx2dAgcijrFXq(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ੘"),[b8Qe150xVaJsnDSv],[MUJCtfYVBLODrFbaZn]
	return kke1PDGRBLuY8y(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨ࡙ࠥࡈࡂࡊࡌࡈ࠹࡛ࠧਖ਼"),[],[]
def uPvEGk29ZhBNJ7xAmCnOFygS(MMd8fKApWBEhGe):
	lO2Eg5wuaK8VX97WYRPDeis1f = hRWC8YSFvsm4JHOMVIne3jquZ.getSetting(UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠫࡦࡼ࠮ࡢ࡭ࡺࡥࡲ࠴ࡶࡦࡴ࡬ࡪ࡮ࡩࡡࡵ࡫ࡲࡲࠬਗ਼"))
	headers = {ddo23ZJtgcY(u"ࠬࡉ࡯ࡰ࡭࡬ࡩࠬਜ਼"):lO2Eg5wuaK8VX97WYRPDeis1f} if lO2Eg5wuaK8VX97WYRPDeis1f else b8Qe150xVaJsnDSv
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(Q49IsrlSuYRAVbGKhwdckLDOetF2PZ,dDYUoKi6JFM23p(u"࠭ࡇࡆࡖࠪੜ"),MMd8fKApWBEhGe,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,QQdAXWBc2GPw(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡆ࡞ࡖࡁࡔࡕࡢࡅࡐ࡝ࡁࡎࡡࡆࡅࡕ࡚ࡃࡉࡃ࠰࠵ࡸࡺࠧ੝"))
	PPR42FiTbg7Ze6p1LztO = b3HKopTY9zLUyhJmt.content
	nnaVxW7CiqAXDp9OvT5Q = str(b3HKopTY9zLUyhJmt.headers)
	CdcvZxWyAXe2b07BSszORUhtj = nnaVxW7CiqAXDp9OvT5Q+PPR42FiTbg7Ze6p1LztO
	if DYakr9g4PVU(u"ࠨ࠰ࡰࡴ࠹࠭ਫ਼") in CdcvZxWyAXe2b07BSszORUhtj: ap7kVRWP42Dvj0zml6GwC9nu = CCxMXuNUEzolDZTKrBJ
	else:
		vAeOZkVlqB1Ygi,ee9oNwUnb1RcGzukmpMOfV,FPId4KSGgmn,tzHKfIlOdu,ap7kVRWP42Dvj0zml6GwC9nu = b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,DD5cFIejQa2X4BgAu9GWPyJ3tC7
		captcha = YYBlm36zd0Jst18LXwo4.findall(mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠩࡳࡥ࡬࡫࠭ࡳࡧࡧ࡭ࡷ࡫ࡣࡵ࠰࠭ࡃࡦࡩࡴࡪࡱࡱࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡥࡣࡷࡥ࠲ࡹࡩࡵࡧ࡮ࡩࡾࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ੟"),PPR42FiTbg7Ze6p1LztO,YYBlm36zd0Jst18LXwo4.DOTALL)
		if captcha: FPId4KSGgmn,tzHKfIlOdu = captcha[LzYQg91SIxDeOGtCKd5]
		FFqdMSTYEOoK2HPfI1z = nTHXJIiah2qK[yST5AHEfvPmcWpwGuh2BJ(u"ࠪࡔ࡞࡚ࡈࡐࡐࠪ੠")][shC5qBRV2A0lZ(u"࠻෶")]
		if LzYQg91SIxDeOGtCKd5:
			data = {uVQd103XyvUce2EBtzbYaC(u"ࠫࡺࡹࡥࡳࠩ੡"):EtvK0T2LNPcsIrAFlufpM,Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠬࡼࡥࡳࡵ࡬ࡳࡳ࠭੢"):cpGrK6qnPi,RRIHDFjoW9w7bSfVPhC(u"࠭ࡵࡳ࡮ࠪ੣"):MMd8fKApWBEhGe,Mmpr0o76iWJvz1kTtfgI8hES(u"ࠧ࡬ࡧࡼࠫ੤"):tzHKfIlOdu,RRIHDFjoW9w7bSfVPhC(u"ࠨ࡫ࡧࠫ੥"):b8Qe150xVaJsnDSv,mQNonhS7CV2BXOv(u"ࠩ࡭ࡳࡧ࠭੦"):BmePGjS7FxK6kutUM(u"ࠪ࡫ࡪࡺࡵࡳ࡮ࡶࠫ੧")}
			b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(nCUMfrlZvuiLe5x,HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠫࡕࡕࡓࡕࠩ੨"),FFqdMSTYEOoK2HPfI1z,data,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,IjZbnrBJmM2N(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡄ࡜ࡔࡆ࡙ࡓࡠࡃࡎ࡛ࡆࡓ࡟ࡄࡃࡓࡘࡈࡎࡁ࠮࠴ࡱࡨࠬ੩"))
			jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
		jLtdbeYiQHnf4SpU2MTly = b8Qe150xVaJsnDSv
		if jLtdbeYiQHnf4SpU2MTly.startswith(DYakr9g4PVU(u"࠭ࡕࡓࡎࡖࡁࠬ੪")):
			OC5ejho8i0pQ1 = oJsUwXA0yGOI1mTjxQ(Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠧ࡭࡫ࡶࡸࠬ੫"),jLtdbeYiQHnf4SpU2MTly.split(BmePGjS7FxK6kutUM(u"ࠨࡗࡕࡐࡘࡃࠧ੬"),qHYIWnOZLPkrQU)[qHYIWnOZLPkrQU])
			for rC39wAIKjUuS in OC5ejho8i0pQ1:
				url = rC39wAIKjUuS[vvWwO3Tx2dAgcijrFXq(u"ࠩࡸࡶࡱ࠭੭")]
				qqgRSb3B5paTrzl8ANDFE2QCjJdZXe = rC39wAIKjUuS[dDYUoKi6JFM23p(u"ࠪࡱࡪࡺࡨࡰࡦࠪ੮")]
				data = rC39wAIKjUuS[uVQd103XyvUce2EBtzbYaC(u"ࠫࡩࡧࡴࡢࠩ੯")]
				headers = rC39wAIKjUuS[yST5AHEfvPmcWpwGuh2BJ(u"ࠬ࡮ࡥࡢࡦࡨࡶࡸ࠭ੰ")]
				b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(nCUMfrlZvuiLe5x,qqgRSb3B5paTrzl8ANDFE2QCjJdZXe,url,data,headers,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,P0qdZI384LKleuo(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡅ࡝ࡕࡇࡓࡔࡡࡄࡏ࡜ࡇࡍࡠࡅࡄࡔ࡙ࡉࡈࡂ࠯࠶ࡶࡩ࠭ੱ"))
				PPR42FiTbg7Ze6p1LztO = b3HKopTY9zLUyhJmt.content
				if Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠧ࠯࡯ࡳ࠸ࠬੲ") in PPR42FiTbg7Ze6p1LztO:
					ap7kVRWP42Dvj0zml6GwC9nu = CCxMXuNUEzolDZTKrBJ
					break
				nnaVxW7CiqAXDp9OvT5Q = str(b3HKopTY9zLUyhJmt.headers)
				CdcvZxWyAXe2b07BSszORUhtj = nnaVxW7CiqAXDp9OvT5Q+PPR42FiTbg7Ze6p1LztO
				vAeOZkVlqB1Ygi = YYBlm36zd0Jst18LXwo4.findall(IjZbnrBJmM2N(u"ࠨࠪࡤ࡯ࡼࡧ࡭ࡗࡧࡵ࡭࡫࡯ࡣࡢࡶ࡬ࡳࡳࡢࡷࠬࠫ࠱࠮ࡄࠨࠨࡦࡻࡍ࠲࠯ࡅࠩࠣࠩੳ"),CdcvZxWyAXe2b07BSszORUhtj,YYBlm36zd0Jst18LXwo4.DOTALL)
				ee9oNwUnb1RcGzukmpMOfV = YYBlm36zd0Jst18LXwo4.findall(QTUBCcehw6qPd4x(u"ࠩࡵࡩࡨࡧࡰࡵࡥ࡫ࡥ࠲ࡺ࡯࡬ࡧࡱ࠲࠯ࡅࠢࠩ࠲࠶ࡅ࠳࠰࠿ࠪࠤࠪੴ"),CdcvZxWyAXe2b07BSszORUhtj,YYBlm36zd0Jst18LXwo4.DOTALL)
				if ee9oNwUnb1RcGzukmpMOfV: ee9oNwUnb1RcGzukmpMOfV = ee9oNwUnb1RcGzukmpMOfV[LzYQg91SIxDeOGtCKd5]
				if vAeOZkVlqB1Ygi or ee9oNwUnb1RcGzukmpMOfV: break
		if not ap7kVRWP42Dvj0zml6GwC9nu:
			if not vAeOZkVlqB1Ygi:
				if captcha and not ee9oNwUnb1RcGzukmpMOfV:
					if qHYIWnOZLPkrQU: ee9oNwUnb1RcGzukmpMOfV = G6RteMu7d5Wo3vZFy1m0hUzcV8xH(tzHKfIlOdu,Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠪࡥࡷ࠭ੵ"),MMd8fKApWBEhGe)
					else:
						if not jLtdbeYiQHnf4SpU2MTly.startswith(Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠫࡎࡊ࠽ࠨ੶")):
							data = {S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠬࡻࡳࡦࡴࠪ੷"):EtvK0T2LNPcsIrAFlufpM,Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"࠭ࡶࡦࡴࡶ࡭ࡴࡴࠧ੸"):cpGrK6qnPi,Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠧࡶࡴ࡯ࠫ੹"):MMd8fKApWBEhGe,Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠨ࡭ࡨࡽࠬ੺"):tzHKfIlOdu,Xz3bA2PFENVCUtplu51(u"ࠩ࡬ࡨࠬ੻"):b8Qe150xVaJsnDSv,zI3ROAZtiUq42rE9WDST68(u"ࠪ࡮ࡴࡨࠧ੼"):m6hwdgP31a2zjN7lkpX(u"ࠫ࡬࡫ࡴࡪࡦࠪ੽")}
							b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(nCUMfrlZvuiLe5x,SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠬࡖࡏࡔࡖࠪ੾"),FFqdMSTYEOoK2HPfI1z,data,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,dDYUoKi6JFM23p(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡅ࡝ࡕࡇࡓࡔࡡࡄࡏ࡜ࡇࡍࡠࡅࡄࡔ࡙ࡉࡈࡂ࠯࠷ࡸ࡭࠭੿"))
							jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
						else: jLtdbeYiQHnf4SpU2MTly = uVQd103XyvUce2EBtzbYaC(u"ࠧࡊࡆࡀ࠵࠷࠹࠴࠻࠼࠽࠾࡙ࡏࡍࡆࡑࡘࡘࡂ࠺࠵ࠨ઀")
						if jLtdbeYiQHnf4SpU2MTly.startswith(ubxGUTt1LraKhVZgpAP(u"ࠨࡋࡇࡁࠬઁ")):
							wN8AtM5fdiSOQ7WkjDRrPpmEUy2lnc = YYBlm36zd0Jst18LXwo4.findall(BmePGjS7FxK6kutUM(u"ࠩࡌࡈࡂ࠮࠮ࠫࡁࠬ࠾࠿ࡀ࠺ࡕࡋࡐࡉࡔ࡛ࡔ࠾ࠪ࠱࠮ࡄ࠯ࠤࠨં"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
							opAUxsu5MG,S9WxYCoO3GDw = wN8AtM5fdiSOQ7WkjDRrPpmEUy2lnc[LzYQg91SIxDeOGtCKd5]
							A4gdSTQDP2FyBIVuba85RvYqKU = RRIHDFjoW9w7bSfVPhC(u"๋ࠪีํࠠศๆ฼้้๐ษࠡฬะฮฬา้ࠠไอࠤ๊์ࠠ࠲࠲ࠣษ้๏ࠠࠨઃ")+S9WxYCoO3GDw+VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠫࠥัว็์ฬࠫ઄")
							vN2KjutDaTCsUY5x = F6kGteqcvBXWCKdASUZmnjP()
							vN2KjutDaTCsUY5x.create(vvWwO3Tx2dAgcijrFXq(u"๋ࠬอศ๊็อࠥะฬศ๊ีࠤๆำีࠡล้หࠥษๆิษ้ࠤํ๊ำหࠢหี๋อๅอࠢๆ์๊ฮ๊้ฬิࠫઅ"),A4gdSTQDP2FyBIVuba85RvYqKU)
							wwVgz5AUEXFTl8ofYJkvtdn9 = wLQCTr5lqbsVYeAHdzfhZ1F.time()
							ttQGDVEvlTYU0wAKxIr1p,uO4CiNDGyz = LzYQg91SIxDeOGtCKd5,LzYQg91SIxDeOGtCKd5
							while ttQGDVEvlTYU0wAKxIr1p<int(S9WxYCoO3GDw):
								NrM3XJ8sD2pEHz(vN2KjutDaTCsUY5x,int(ttQGDVEvlTYU0wAKxIr1p/int(S9WxYCoO3GDw)*LAQD5wEkr18bUiGaYen3J(u"࠶࠶࠰෷")),A4gdSTQDP2FyBIVuba85RvYqKU,b8Qe150xVaJsnDSv,S9WxYCoO3GDw+QTUBCcehw6qPd4x(u"࠭ࠠ࠰ࠢࠪઆ")+str(int(ttQGDVEvlTYU0wAKxIr1p))+Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠧࠡࠢฮห๋๐ษࠨઇ"))
								if ttQGDVEvlTYU0wAKxIr1p>uO4CiNDGyz+ubxGUTt1LraKhVZgpAP(u"࠷࠰෸"):
									data = {mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠨࡷࡶࡩࡷ࠭ઈ"):EtvK0T2LNPcsIrAFlufpM,ubxGUTt1LraKhVZgpAP(u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪઉ"):cpGrK6qnPi,P0qdZI384LKleuo(u"ࠪࡹࡷࡲࠧઊ"):MMd8fKApWBEhGe,LAQD5wEkr18bUiGaYen3J(u"ࠫࡰ࡫ࡹࠨઋ"):tzHKfIlOdu,ubxGUTt1LraKhVZgpAP(u"ࠬ࡯ࡤࠨઌ"):opAUxsu5MG,dDYUoKi6JFM23p(u"࠭ࡪࡰࡤࠪઍ"):Xz3bA2PFENVCUtplu51(u"ࠧࡨࡧࡷࡸࡴࡱࡥ࡯ࠩ઎")}
									b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(nCUMfrlZvuiLe5x,S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠨࡒࡒࡗ࡙࠭એ"),FFqdMSTYEOoK2HPfI1z,data,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,Mmpr0o76iWJvz1kTtfgI8hES(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡈ࡙ࡑࡃࡖࡗࡤࡇࡋࡘࡃࡐࡣࡈࡇࡐࡕࡅࡋࡅ࠲࠻ࡴࡩࠩઐ"))
									jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
									if jLtdbeYiQHnf4SpU2MTly.startswith(mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠪࡘࡔࡑࡅࡏ࠿ࠪઑ")):
										ee9oNwUnb1RcGzukmpMOfV = jLtdbeYiQHnf4SpU2MTly.split(VFjQx6Is28KvzLOmMXtg4GqTwa3(u"࡙ࠫࡕࡋࡆࡐࡀࠫ઒"),S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"࠱෹"))[qHYIWnOZLPkrQU]
										break
									uO4CiNDGyz = ttQGDVEvlTYU0wAKxIr1p
								else: wLQCTr5lqbsVYeAHdzfhZ1F.sleep(qHYIWnOZLPkrQU)
								ttQGDVEvlTYU0wAKxIr1p = wLQCTr5lqbsVYeAHdzfhZ1F.time()-wwVgz5AUEXFTl8ofYJkvtdn9
							vN2KjutDaTCsUY5x.close()
				if ee9oNwUnb1RcGzukmpMOfV:
					Y8aIT4NCR2BFK = b3HKopTY9zLUyhJmt.cookies
					bEovYkr9Ai6DtL14XIOc7VSgew = YYBlm36zd0Jst18LXwo4.findall(TYf7Dc06PQgy1vEV9(u"ࠬࡧ࡫ࡸࡣࡰࡣࡸ࡫ࡳࡴ࡫ࡲࡲࡂ࠮࠮ࠫࡁࠬ࠿ࠬઓ"),CdcvZxWyAXe2b07BSszORUhtj,YYBlm36zd0Jst18LXwo4.DOTALL)
					if shC5qBRV2A0lZ(u"࠭ࡡ࡬ࡹࡤࡱࡤࡹࡥࡴࡵ࡬ࡳࡳ࠭ઔ") in list(Y8aIT4NCR2BFK.keys()): bEovYkr9Ai6DtL14XIOc7VSgew = Y8aIT4NCR2BFK[IjZbnrBJmM2N(u"ࠧࡢ࡭ࡺࡥࡲࡥࡳࡦࡵࡶ࡭ࡴࡴࠧક")]
					elif bEovYkr9Ai6DtL14XIOc7VSgew: bEovYkr9Ai6DtL14XIOc7VSgew = bEovYkr9Ai6DtL14XIOc7VSgew[LzYQg91SIxDeOGtCKd5]
					captcha = YYBlm36zd0Jst18LXwo4.findall(UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠨࡲࡤ࡫ࡪ࠳ࡲࡦࡦ࡬ࡶࡪࡩࡴ࠯ࠬࡂࡥࡨࡺࡩࡰࡰࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡤࡢࡶࡤ࠱ࡸ࡯ࡴࡦ࡭ࡨࡽࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ખ"),PPR42FiTbg7Ze6p1LztO,YYBlm36zd0Jst18LXwo4.DOTALL)
					if captcha: FPId4KSGgmn,tzHKfIlOdu = captcha[LzYQg91SIxDeOGtCKd5]
					if bEovYkr9Ai6DtL14XIOc7VSgew and captcha:
						headers = {m6hwdgP31a2zjN7lkpX(u"ࠩࡆࡳࡴࡱࡩࡦࠩગ"):HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠪࡥࡰࡽࡡ࡮ࡡࡶࡩࡸࡹࡩࡰࡰࡀࠫઘ")+bEovYkr9Ai6DtL14XIOc7VSgew,kke1PDGRBLuY8y(u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬઙ"):MMd8fKApWBEhGe,VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫચ"):QTUBCcehw6qPd4x(u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࠬછ")}
						data = vvWwO3Tx2dAgcijrFXq(u"ࠧࡨ࠯ࡵࡩࡨࡧࡰࡵࡥ࡫ࡥ࠲ࡸࡥࡴࡲࡲࡲࡸ࡫࠽ࠨજ")+ee9oNwUnb1RcGzukmpMOfV
						b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(Q49IsrlSuYRAVbGKhwdckLDOetF2PZ,Xz3bA2PFENVCUtplu51(u"ࠨࡒࡒࡗ࡙࠭ઝ"),FPId4KSGgmn,data,headers,DD5cFIejQa2X4BgAu9GWPyJ3tC7,b8Qe150xVaJsnDSv,BWNPxIG7vqdTy85pjHzUOrK3(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡈ࡙ࡑࡃࡖࡗࡤࡇࡋࡘࡃࡐࡣࡈࡇࡐࡕࡅࡋࡅ࠲࠼ࡴࡩࠩઞ"))
						PPR42FiTbg7Ze6p1LztO = b3HKopTY9zLUyhJmt.content
						try: cookies = b3HKopTY9zLUyhJmt.cookies
						except: cookies = {}
						vAeOZkVlqB1Ygi = YYBlm36zd0Jst18LXwo4.findall(mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠥࠫ࠭ࡧ࡫ࡸࡣࡰ࡚ࡪࡸࡩࡧ࡫ࡦࡥࡹ࡯࡯࡯࠰࠭ࡃ࠮࠭࠺ࠡࠩࠫ࠲࠯ࡅࠩࠨࠤટ"),str(cookies),YYBlm36zd0Jst18LXwo4.DOTALL)
			if vAeOZkVlqB1Ygi:
				c17XeRIH2gVh3px8sw,vAeOZkVlqB1Ygi = vAeOZkVlqB1Ygi[LzYQg91SIxDeOGtCKd5]
				lO2Eg5wuaK8VX97WYRPDeis1f = c17XeRIH2gVh3px8sw+SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠫࡂ࠭ઠ")+vAeOZkVlqB1Ygi
				hRWC8YSFvsm4JHOMVIne3jquZ.setSetting(uVQd103XyvUce2EBtzbYaC(u"ࠬࡧࡶ࠯ࡣ࡮ࡻࡦࡳ࠮ࡷࡧࡵ࡭࡫࡯ࡣࡢࡶ࡬ࡳࡳ࠭ડ"),lO2Eg5wuaK8VX97WYRPDeis1f)
				tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩઢ"),vvWwO3Tx2dAgcijrFXq(u"ࠧ็ฮะฮࠥ฿ๅๅ์ฬࠤๆำีࠡล้หࠥหๆิษ้ࠤ࠳࠴้ࠠไส้ࠥอไษำ้ห๊าࠠษะี๊ࠥ์สศศฯࠤ์ึวࠡษ็ๅา฻ࠠๅๅํࠤ๏ูสฯั่๋ฬࠦไศฯๅหࠥ࠴࠮๊ࠡ็หࠥะ่อัࠣัฬาษࠡๆศ฽ฬีษ้ࠡำหࠥอไโฯุࠤ้฿ฯสࠢฦุ์ืࠠ࡝ࡰ࡟ࡲࠥ฿ไๆษࠣว๋ࠦ็ัษࠣห้็อึࠢึ์ๆ๊ࠦหๅิีࠥ็๊ࠡฯส่ฮࠦส฻์ิࠤึฮืࠡษ็ะ์อาࠡสส่ส์สา่อࠤ࠳࠴ࠠฤ๊ࠣษ฼็วยࠢิหํะัࠡษ็ษ๋ะั็ฬࠣ࠲࠳ࠦร้ࠢไู้ࠦำๅๅࠣห้ืว้ฬิࠤ࠳࠴ࠠฤ๊ࠣหุะฮะษ่ࠤ࡛ࡖࡎࠡล๋ࠤอื่ไีํࠫણ"))
				if TYf7Dc06PQgy1vEV9(u"ࠨ࠰ࡰࡴ࠹࠭ત") not in PPR42FiTbg7Ze6p1LztO:
					headers = {BmePGjS7FxK6kutUM(u"ࠩࡆࡳࡴࡱࡩࡦࠩથ"):lO2Eg5wuaK8VX97WYRPDeis1f}
					b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(Q49IsrlSuYRAVbGKhwdckLDOetF2PZ,LAQD5wEkr18bUiGaYen3J(u"ࠪࡋࡊ࡚ࠧદ"),MMd8fKApWBEhGe,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,ubxGUTt1LraKhVZgpAP(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡃ࡛ࡓࡅࡘ࡙࡟ࡂࡍ࡚ࡅࡒࡥࡃࡂࡒࡗࡇࡍࡇ࠭࠸ࡶ࡫ࠫધ"))
					PPR42FiTbg7Ze6p1LztO = b3HKopTY9zLUyhJmt.content
	if not ap7kVRWP42Dvj0zml6GwC9nu and not lO2Eg5wuaK8VX97WYRPDeis1f: tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,BmePGjS7FxK6kutUM(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨન"),mQNonhS7CV2BXOv(u"࠭แีๆอࠤ฾๋ไ๋หࠣๅา฻ࠠฤ่สࠤศ์ำศ่ࠣ࠲࠳ࠦอศ๊็ࠤส฿วะหࠣห้฿ๅๅ์ฬࠤ๊ืษࠡลัี๎ࠦศศีอาิอๅ่ࠡไืࠥอไโ์า๎ํࠦร้ࠢไ๎ิ๐่ࠡ฼ํี์ࠦๅ็้ࠢๅุࠦวๅ็๋ๆ฾࠭઩"))
	return PPR42FiTbg7Ze6p1LztO
def pn57ui6YOm(url,E57WK4m31C8,c1EdszLx3mkb8QYX9):
	n92bB0YwDLqyadQRlmGW,zMaDJPY25fQK96VvUBAgxlROmI8 = [],[]
	MMd8fKApWBEhGe = url
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(Q49IsrlSuYRAVbGKhwdckLDOetF2PZ,RRIHDFjoW9w7bSfVPhC(u"ࠧࡈࡇࡗࠫપ"),url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,vvWwO3Tx2dAgcijrFXq(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡑࡗࡂࡏ࠰࠵ࡸࡺࠧફ"))
	vWsMIpk1n6rlLqH52 = b3HKopTY9zLUyhJmt.content
	F4zYTLgflhyPVW = []
	if vvWwO3Tx2dAgcijrFXq(u"ࠩ࠲ࡻࡦࡺࡣࡩ࠱ࠪબ") in vWsMIpk1n6rlLqH52 or Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠪ࠳ࡩࡵࡷ࡯࡮ࡲࡥࡩ࠵ࠧભ") in vWsMIpk1n6rlLqH52:
		JQjNkD10xehK8bXUalY3EgZAVmvI = YYBlm36zd0Jst18LXwo4.findall(Nh0BWuiSndf(u"ࠫࡁࡧࠠࡩࡴࡨࡪࡂࠨࡨࡵࡶࡳ࠲࠯ࡅ࠼࠰ࡣࡁࠫમ"),vWsMIpk1n6rlLqH52,YYBlm36zd0Jst18LXwo4.DOTALL)
		if JQjNkD10xehK8bXUalY3EgZAVmvI:
			for OTKx7aVb2hdS16Wrweky4FXfIN0g9 in JQjNkD10xehK8bXUalY3EgZAVmvI:
				tzdvaEpMHOCZLXDYg08T = YYBlm36zd0Jst18LXwo4.findall(uVQd103XyvUce2EBtzbYaC(u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡸࡶࡡ࡯࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩય"),OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
				for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in tzdvaEpMHOCZLXDYg08T:
					if pcA1dzy7LXwGfMPg9mTkuh5tine3 in n92bB0YwDLqyadQRlmGW: continue
					if TT8Mxv5Wq7nlC9IscdpPUY6(u"࠭࠯ࡸࡣࡷࡧ࡭࠵ࠧર") not in pcA1dzy7LXwGfMPg9mTkuh5tine3 and BmePGjS7FxK6kutUM(u"ࠧ࠰ࡦࡲࡻࡳࡲ࡯ࡢࡦ࠲ࠫ઱") not in pcA1dzy7LXwGfMPg9mTkuh5tine3: continue
					if BWNPxIG7vqdTy85pjHzUOrK3(u"ࠨษࠪલ") not in title:
						F4zYTLgflhyPVW.append((title,pcA1dzy7LXwGfMPg9mTkuh5tine3))
						continue
					title = title.replace(HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠩ࠿࠳ࡸࡶࡡ࡯ࡀࠪળ"),b8Qe150xVaJsnDSv).replace(TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠪࠤ࠲ࠦࠧ઴"),b8Qe150xVaJsnDSv).strip(pldxivXC5wbTB2O8q).replace(k5bCDErUSmv,pldxivXC5wbTB2O8q)
					if DYakr9g4PVU(u"ࠫࡸࡶࡡ࡯ࠩવ") in title: continue
					n92bB0YwDLqyadQRlmGW.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
					zMaDJPY25fQK96VvUBAgxlROmI8.append(title)
			for title,pcA1dzy7LXwGfMPg9mTkuh5tine3 in F4zYTLgflhyPVW:
				if pcA1dzy7LXwGfMPg9mTkuh5tine3 not in n92bB0YwDLqyadQRlmGW:
					n92bB0YwDLqyadQRlmGW.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
					zMaDJPY25fQK96VvUBAgxlROmI8.append(title)
			cMZGTsAR2E = LzYQg91SIxDeOGtCKd5
			if len(n92bB0YwDLqyadQRlmGW)>qHYIWnOZLPkrQU:
				cMZGTsAR2E = XXprCMzuNP2mElUxfdA(P0qdZI384LKleuo(u"ࠬฮูื้สࠤ๏ำสศฮࠣ࠺࠵ࠦหศ่ํอࠬશ"),zMaDJPY25fQK96VvUBAgxlROmI8)
				if cMZGTsAR2E==-qHYIWnOZLPkrQU: return DYakr9g4PVU(u"࠭ࡅ࡙ࡋࡗࡣࡆࡒࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫષ"),[],[]
			if n92bB0YwDLqyadQRlmGW and cMZGTsAR2E>=LzYQg91SIxDeOGtCKd5: MMd8fKApWBEhGe = n92bB0YwDLqyadQRlmGW[cMZGTsAR2E]
	PPR42FiTbg7Ze6p1LztO = uPvEGk29ZhBNJ7xAmCnOFygS(MMd8fKApWBEhGe)
	KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j,uuSKUinvP4EGLxWZYmTsF = [],[]
	if E57WK4m31C8==Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥࠩસ"):
		esHODYVfvAqXhP = YYBlm36zd0Jst18LXwo4.findall(S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠨࡤࡷࡲ࠲ࡲ࡯ࡢࡦࡨࡶ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭હ"),PPR42FiTbg7Ze6p1LztO,YYBlm36zd0Jst18LXwo4.DOTALL)
		if esHODYVfvAqXhP:
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = SgrGWuAHcLKBQMJetb9(esHODYVfvAqXhP[LzYQg91SIxDeOGtCKd5])
			KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
			uuSKUinvP4EGLxWZYmTsF.append(c1EdszLx3mkb8QYX9)
	elif E57WK4m31C8==Nh0BWuiSndf(u"ࠩࡺࡥࡹࡩࡨࠨ઺"):
		tzdvaEpMHOCZLXDYg08T = YYBlm36zd0Jst18LXwo4.findall(VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠪࡀࡸࡵࡵࡳࡥࡨ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡪࡼࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ઻"),PPR42FiTbg7Ze6p1LztO,YYBlm36zd0Jst18LXwo4.DOTALL)
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,size in tzdvaEpMHOCZLXDYg08T:
			if not pcA1dzy7LXwGfMPg9mTkuh5tine3: continue
			if c1EdszLx3mkb8QYX9 in size:
				uuSKUinvP4EGLxWZYmTsF.append(size)
				KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
				break
		if not KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j:
			for pcA1dzy7LXwGfMPg9mTkuh5tine3,size in tzdvaEpMHOCZLXDYg08T:
				if not pcA1dzy7LXwGfMPg9mTkuh5tine3: continue
				uuSKUinvP4EGLxWZYmTsF.append(size)
				KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
	if not KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j: return Xz3bA2PFENVCUtplu51(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡁࡌ࡙ࡄࡑ઼ࠬ"),[],[]
	return b8Qe150xVaJsnDSv,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j
def AvLtXWDMhP(url,c17XeRIH2gVh3px8sw):
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,uVQd103XyvUce2EBtzbYaC(u"ࠬࡍࡅࡕࠩઽ"),url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,CCxMXuNUEzolDZTKrBJ,b8Qe150xVaJsnDSv,SbjiWeHLQPoazqwp3cODkd7YxVgn(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡏࡔࡇࡍ࠮࠳ࡶࡸࠬા"))
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	cookies = b3HKopTY9zLUyhJmt.cookies
	if VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠧࡨࡱ࡯࡭ࡳࡱࠧિ") in list(cookies.keys()):
		lO2Eg5wuaK8VX97WYRPDeis1f = cookies[BWNPxIG7vqdTy85pjHzUOrK3(u"ࠨࡩࡲࡰ࡮ࡴ࡫ࠨી")]
		lO2Eg5wuaK8VX97WYRPDeis1f = SgrGWuAHcLKBQMJetb9(ggtn0PzV7aMe(lO2Eg5wuaK8VX97WYRPDeis1f))
		items = YYBlm36zd0Jst18LXwo4.findall(zI3ROAZtiUq42rE9WDST68(u"ࠩࡵࡳࡺࡺࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪુ"),lO2Eg5wuaK8VX97WYRPDeis1f,YYBlm36zd0Jst18LXwo4.DOTALL)
		MUJCtfYVBLODrFbaZn = items[LzYQg91SIxDeOGtCKd5].replace(uVQd103XyvUce2EBtzbYaC(u"ࠪࡠ࠴࠭ૂ"),P0qdZI384LKleuo(u"ࠫ࠴࠭ૃ"))
		MUJCtfYVBLODrFbaZn = ggtn0PzV7aMe(MUJCtfYVBLODrFbaZn)
	else: MUJCtfYVBLODrFbaZn = url
	if yST5AHEfvPmcWpwGuh2BJ(u"ࠬࡩࡡࡵࡥ࡫࠲࡮ࡹࠧૄ") in MUJCtfYVBLODrFbaZn:
		yXdtJT0UQL = MUJCtfYVBLODrFbaZn.split(mQNonhS7CV2BXOv(u"࠭ࠥ࠳ࡈࠪૅ"))[-qHYIWnOZLPkrQU]
		MUJCtfYVBLODrFbaZn = mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡤࡣࡷࡧ࡭࠴ࡩࡴ࠱ࠪ૆")+yXdtJT0UQL
		return Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫે"),[b8Qe150xVaJsnDSv],[MUJCtfYVBLODrFbaZn]
	else:
		website = nTHXJIiah2qK[S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠩࡄࡏࡔࡇࡍࠨૈ")][LzYQg91SIxDeOGtCKd5]
		b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,kke1PDGRBLuY8y(u"ࠪࡋࡊ࡚ࠧૉ"),website,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,CCxMXuNUEzolDZTKrBJ,b8Qe150xVaJsnDSv,dDYUoKi6JFM23p(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡍࡒࡅࡒ࠳࠲࡯ࡦࠪ૊"))
		ofWt0K2wudp6Re4HqzImb1xsP = b3HKopTY9zLUyhJmt.url
		tUZljVSGQKEPy5L3kRNXI79nCfoD = MUJCtfYVBLODrFbaZn.split(zI3ROAZtiUq42rE9WDST68(u"ࠬ࠵ࠧો"))[IgQimel18t]
		EIhnmpaJbvyQFsURPMgt7k = ofWt0K2wudp6Re4HqzImb1xsP.split(VFjQx6Is28KvzLOmMXtg4GqTwa3(u"࠭࠯ࠨૌ"))[IgQimel18t]
		GSh0nJxEXgZjd48u7mBwWOeafyAp5b = MUJCtfYVBLODrFbaZn.replace(tUZljVSGQKEPy5L3kRNXI79nCfoD,EIhnmpaJbvyQFsURPMgt7k)
		headers = { TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷ્ࠫ"):b8Qe150xVaJsnDSv , BWNPxIG7vqdTy85pjHzUOrK3(u"ࠨ࡚࠰ࡖࡪࡷࡵࡦࡵࡷࡩࡩ࠳ࡗࡪࡶ࡫ࠫ૎"):dDYUoKi6JFM23p(u"࡛ࠩࡑࡑࡎࡴࡵࡲࡕࡩࡶࡻࡥࡴࡶࠪ૏") , vvWwO3Tx2dAgcijrFXq(u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫૐ"):GSh0nJxEXgZjd48u7mBwWOeafyAp5b }
		b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(LtlXH3fvMydAx,mQNonhS7CV2BXOv(u"ࠫࡕࡕࡓࡕࠩ૑"), GSh0nJxEXgZjd48u7mBwWOeafyAp5b, b8Qe150xVaJsnDSv, headers, DD5cFIejQa2X4BgAu9GWPyJ3tC7,b8Qe150xVaJsnDSv,mQNonhS7CV2BXOv(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡎࡓࡆࡓ࠭࠴ࡴࡧࠫ૒"))
		jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
		items = YYBlm36zd0Jst18LXwo4.findall(ddo23ZJtgcY(u"࠭ࡤࡪࡴࡨࡧࡹࡥ࡬ࡪࡰ࡮ࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭૓"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL|YYBlm36zd0Jst18LXwo4.IGNORECASE)
		if not items:
			items = YYBlm36zd0Jst18LXwo4.findall(SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠧ࠽࡫ࡩࡶࡦࡳࡥ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ૔"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL|YYBlm36zd0Jst18LXwo4.IGNORECASE)
			if not items:
				items = YYBlm36zd0Jst18LXwo4.findall(ubxGUTt1LraKhVZgpAP(u"ࠨ࠾ࡨࡱࡧ࡫ࡤ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ૕"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL|YYBlm36zd0Jst18LXwo4.IGNORECASE)
		if items:
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = items[LzYQg91SIxDeOGtCKd5].replace(IjZbnrBJmM2N(u"ࠩ࡟࠳ࠬ૖"),DYakr9g4PVU(u"ࠪ࠳ࠬ૗"))
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3.rstrip(HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠫ࠴࠭૘"))
			if BWNPxIG7vqdTy85pjHzUOrK3(u"ࠬ࡮ࡴࡵࡲࠪ૙") not in pcA1dzy7LXwGfMPg9mTkuh5tine3: pcA1dzy7LXwGfMPg9mTkuh5tine3 = uVQd103XyvUce2EBtzbYaC(u"࠭ࡨࡵࡶࡳ࠾ࠬ૚") + pcA1dzy7LXwGfMPg9mTkuh5tine3
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3.replace(VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࠨ૛"),Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࠪ૜"))
			if c17XeRIH2gVh3px8sw==b8Qe150xVaJsnDSv: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = b8Qe150xVaJsnDSv,[b8Qe150xVaJsnDSv],[pcA1dzy7LXwGfMPg9mTkuh5tine3]
			else: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ૝"),[b8Qe150xVaJsnDSv],[pcA1dzy7LXwGfMPg9mTkuh5tine3]
		else: bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = TYf7Dc06PQgy1vEV9(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡇࡋࡐࡃࡐࠫ૞"),[],[]
		return bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j
def Aue5MCqRLgpUr8xvokz(url):
	headers = { yST5AHEfvPmcWpwGuh2BJ(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ૟") : b8Qe150xVaJsnDSv }
	jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(LtlXH3fvMydAx,url,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,Xz3bA2PFENVCUtplu51(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡔࡄࡔࡎࡊࡖࡊࡆࡈࡓ࠲࠷ࡳࡵࠩૠ"))
	items = YYBlm36zd0Jst18LXwo4.findall(TYf7Dc06PQgy1vEV9(u"࠭࠼ࡴࡱࡸࡶࡨ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࡭ࡣࡥࡩࡱࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧૡ"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j,errno = [],[],b8Qe150xVaJsnDSv
	if items:
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,okYWP4Hxyb in items:
			uuSKUinvP4EGLxWZYmTsF.append(okYWP4Hxyb)
			KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
	if len(KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j)==LzYQg91SIxDeOGtCKd5: return QTUBCcehw6qPd4x(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡕࡅࡕࡏࡄࡗࡋࡇࡉࡔ࠭ૢ"),[],[]
	return b8Qe150xVaJsnDSv,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j
def xyN2kAaiFj5Z4V9mUqE7KLGgn1p(url):
	headers = {Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬૣ"):b8Qe150xVaJsnDSv}
	jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(LtlXH3fvMydAx,url,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,m6hwdgP31a2zjN7lkpX(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡛ࡑࡍࡑࡄࡈ࠲࠷ࡳࡵࠩ૤"))
	items = YYBlm36zd0Jst18LXwo4.findall(mQNonhS7CV2BXOv(u"ࠪࡷࡴࡻࡲࡤࡧࡶ࠾ࠥࡢ࡛ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ૥"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if items:
		url = items[LzYQg91SIxDeOGtCKd5]+ddo23ZJtgcY(u"ࠫࢁࡘࡥࡧࡧࡵࡩࡷࡃࠧ૦")+url
		return b8Qe150xVaJsnDSv,[b8Qe150xVaJsnDSv],[url]
	else: return Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡖࡓࡏࡓࡆࡊࠧ૧"),[],[]
def aktwebg5H93V6mnUDvi(url):
	url = url.strip(BWNPxIG7vqdTy85pjHzUOrK3(u"࠭࠯ࠨ૨"))
	if DYakr9g4PVU(u"ࠧ࠰ࡧࡰࡦࡪࡪ࠯ࠨ૩") in url: yXdtJT0UQL = url.split(TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠨ࠱ࠪ૪"))[NvHugPosYDzRJ]
	else: yXdtJT0UQL = url.split(shC5qBRV2A0lZ(u"ࠩ࠲ࠫ૫"))[-qHYIWnOZLPkrQU]
	url = mQNonhS7CV2BXOv(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡻࡩࡳࡵࡴࡨࡥࡲ࠴ࡴࡰ࠱ࡳࡰࡦࡿࡥࡳࡁࡩ࡭ࡩࡃࠧ૬") + yXdtJT0UQL
	headers = { mmcNLrXtzfpyCkZlvK5VwG2gujh(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ૭") : b8Qe150xVaJsnDSv }
	jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(LtlXH3fvMydAx,url,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,uVQd103XyvUce2EBtzbYaC(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡘࡆࡗ࡙ࡘࡅࡂࡏ࠰࠵ࡸࡺࠧ૮"))
	jLtdbeYiQHnf4SpU2MTly = jLtdbeYiQHnf4SpU2MTly.replace(m6hwdgP31a2zjN7lkpX(u"࠭࡜࡝ࠩ૯"),b8Qe150xVaJsnDSv)
	items = YYBlm36zd0Jst18LXwo4.findall(ubxGUTt1LraKhVZgpAP(u"ࠧࡧ࡫࡯ࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ૰"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if items: return b8Qe150xVaJsnDSv,[b8Qe150xVaJsnDSv],[ items[LzYQg91SIxDeOGtCKd5] ]
	else: return kke1PDGRBLuY8y(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦ࡚ࠣࡈ࡙ࡔࡓࡇࡄࡑࠬ૱"),[],[]
def WThi42cB0Re(url):
	jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(LtlXH3fvMydAx,url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,ddo23ZJtgcY(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡜ࡉࡅࡑ࡝ࡅ࠲࠷ࡳࡵࠩ૲"))
	items = YYBlm36zd0Jst18LXwo4.findall(mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠪࡷࡷࡩ࠺ࠡࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡱࡧࡢࡦ࡮࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠰ࠥࡸࡥࡴ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ૳"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = [],[]
	for pcA1dzy7LXwGfMPg9mTkuh5tine3,okYWP4Hxyb,mR5n6CefjUyZKDNgIBsHJd in items:
		uuSKUinvP4EGLxWZYmTsF.append(okYWP4Hxyb+pldxivXC5wbTB2O8q+mR5n6CefjUyZKDNgIBsHJd)
		KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
	if len(KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j)==LzYQg91SIxDeOGtCKd5: return shC5qBRV2A0lZ(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡖࡊࡆࡒ࡞ࡆ࠭૴"),[],[]
	return b8Qe150xVaJsnDSv,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j
def ibxZ9MDUWzfIX5CR(url):
	jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(LtlXH3fvMydAx,url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,TYf7Dc06PQgy1vEV9(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡙ࡄࡘࡈࡎࡖࡊࡆࡈࡓ࠲࠷ࡳࡵࠩ૵"))
	items = YYBlm36zd0Jst18LXwo4.findall(IjZbnrBJmM2N(u"ࠨࡤࡰࡹࡱࡰࡴࡧࡤࡠࡸ࡬ࡨࡪࡵ࡜ࠩࠩࠫ࠲࠯ࡅࠩࠨ࠮ࠪࠬ࠳࠰࠿ࠪࠩ࠯ࠫ࠭࠴ࠪࡀࠫࠪࡠ࠮ࡢࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁ࠲࠯ࡅ࠼ࡵࡦࡁࠬ࠳࠰࠿ࠪ࠮࠱࠮ࡄࡂ࠯ࡵࡦࡁࠦ૶"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	items = set(items)
	uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = [],[]
	for yXdtJT0UQL,ZZtDTHnBXMz,OSxLAs1uPQDZ,okYWP4Hxyb,mR5n6CefjUyZKDNgIBsHJd in items:
		url = mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡤࡸࡨ࡮ࡶࡪࡦࡨࡳ࠳ࡻࡳ࠰ࡦ࡯ࡃࡴࡶ࠽ࡥࡱࡺࡲࡱࡵࡡࡥࡡࡲࡶ࡮࡭ࠦࡪࡦࡀࠫ૷")+yXdtJT0UQL+HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠨࠨࡰࡳࡩ࡫࠽ࠨ૸")+ZZtDTHnBXMz+Xz3bA2PFENVCUtplu51(u"ࠩࠩ࡬ࡦࡹࡨ࠾ࠩૹ")+OSxLAs1uPQDZ
		jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(LtlXH3fvMydAx,url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,LAQD5wEkr18bUiGaYen3J(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡗࡂࡖࡆࡌ࡛ࡏࡄࡆࡑ࠰࠶ࡳࡪࠧૺ"))
		items = YYBlm36zd0Jst18LXwo4.findall(shC5qBRV2A0lZ(u"ࠫࡩ࡯ࡲࡦࡥࡷࠤࡱ࡯࡮࡬࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪૻ"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		for pcA1dzy7LXwGfMPg9mTkuh5tine3 in items:
			uuSKUinvP4EGLxWZYmTsF.append(okYWP4Hxyb+pldxivXC5wbTB2O8q+mR5n6CefjUyZKDNgIBsHJd)
			KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
	if len(KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j)==LzYQg91SIxDeOGtCKd5: return RRIHDFjoW9w7bSfVPhC(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡘࡃࡗࡇࡍ࡜ࡉࡅࡇࡒࠫૼ"),[],[]
	return b8Qe150xVaJsnDSv,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j
def uuVCyTR4LBHXwfeG5gQZOMUidk(url):
	pcA1dzy7LXwGfMPg9mTkuh5tine3 = b8Qe150xVaJsnDSv
	if qHYIWnOZLPkrQU or BWNPxIG7vqdTy85pjHzUOrK3(u"࠭ࡋࡦࡻࡀࠫ૽") not in url:
		MUJCtfYVBLODrFbaZn = url.replace(zI3ROAZtiUq42rE9WDST68(u"ࠧࡶࡲࡥࡳࡲ࠴࡬ࡪࡸࡨࠫ૾"),shC5qBRV2A0lZ(u"ࠨࡷࡳࡴࡴࡳ࠮࡭࡫ࡹࡩࠬ૿"))
		MUJCtfYVBLODrFbaZn = MUJCtfYVBLODrFbaZn.split(QTUBCcehw6qPd4x(u"ࠩ࠲ࠫ଀"))
		yXdtJT0UQL = MUJCtfYVBLODrFbaZn[VwApyDY1Jc]
		MUJCtfYVBLODrFbaZn = BWNPxIG7vqdTy85pjHzUOrK3(u"ࠪ࠳ࠬଁ").join(MUJCtfYVBLODrFbaZn[LzYQg91SIxDeOGtCKd5:NvHugPosYDzRJ])
		lo6biSg2NR3eUB1OpEPxzyXwF8sYWI = {Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠫ࡮ࡪࠧଂ"):yXdtJT0UQL,shC5qBRV2A0lZ(u"ࠬࡵࡰࠨଃ"):UUkIBz1sgQ9WfNeG6trKXvu0(u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤ࠳ࠩ଄"),BmePGjS7FxK6kutUM(u"ࠧ࡮ࡧࡷ࡬ࡴࡪ࡟ࡧࡴࡨࡩࠬଅ"):UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠨࡈࡵࡩࡪ࠱ࡄࡰࡹࡱࡰࡴࡧࡤࠬࠧ࠶ࡉࠪ࠹ࡅࠨଆ")}
		b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(LtlXH3fvMydAx,shC5qBRV2A0lZ(u"ࠩࡓࡓࡘ࡚ࠧଇ"),MUJCtfYVBLODrFbaZn,lo6biSg2NR3eUB1OpEPxzyXwF8sYWI,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,P0qdZI384LKleuo(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡕࡑࡄࡒࡑ࠲࠷ࡳࡵࠩଈ"))
		if TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭ଉ") in list(b3HKopTY9zLUyhJmt.headers.keys()): pcA1dzy7LXwGfMPg9mTkuh5tine3 = b3HKopTY9zLUyhJmt.headers[QQdAXWBc2GPw(u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧଊ")]
		if not pcA1dzy7LXwGfMPg9mTkuh5tine3 and b3HKopTY9zLUyhJmt.succeeded:
			jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = YYBlm36zd0Jst18LXwo4.findall(SbjiWeHLQPoazqwp3cODkd7YxVgn(u"࠭ࡩࡥ࠿ࠥࡨ࡮ࡸࡥࡤࡶࡢࡰ࡮ࡴ࡫ࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪଋ"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
			if pcA1dzy7LXwGfMPg9mTkuh5tine3: pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3[LzYQg91SIxDeOGtCKd5]
	else:
		b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(LtlXH3fvMydAx,vvWwO3Tx2dAgcijrFXq(u"ࠧࡈࡇࡗࠫଌ"),url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,QTUBCcehw6qPd4x(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡚ࡖࡂࡐࡏ࠰࠶ࡳࡪࠧ଍"))
		if QQdAXWBc2GPw(u"ࠩ࡯ࡳࡨࡧࡴࡪࡱࡱࠫ଎") in list(b3HKopTY9zLUyhJmt.headers.keys()): pcA1dzy7LXwGfMPg9mTkuh5tine3 = b3HKopTY9zLUyhJmt.headers[LAQD5wEkr18bUiGaYen3J(u"ࠪࡰࡴࡩࡡࡵ࡫ࡲࡲࠬଏ")]
	if pcA1dzy7LXwGfMPg9mTkuh5tine3: return b8Qe150xVaJsnDSv,[b8Qe150xVaJsnDSv],[pcA1dzy7LXwGfMPg9mTkuh5tine3]
	return P0qdZI384LKleuo(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡕࡑࡄࡒࡑࠬଐ"),[],[]
def PfJWu60GjSai(url):
	headers = { shC5qBRV2A0lZ(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ଑") : b8Qe150xVaJsnDSv }
	jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(LtlXH3fvMydAx,url,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,DYakr9g4PVU(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡏࡍࡎ࡜ࡉࡅࡇࡒ࠱࠶ࡹࡴࠨ଒"))
	items = YYBlm36zd0Jst18LXwo4.findall(SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠧࡴࡱࡸࡶࡨ࡫ࡳ࠻࠰࠭ࡃࠧ࠮࠮ࠫࡁࠬࠦ࠱ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ଓ"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = [],[]
	if items:
		uuSKUinvP4EGLxWZYmTsF.append(yST5AHEfvPmcWpwGuh2BJ(u"ࠨ࡯ࡳ࠸ࠬଔ"))
		KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j.append(items[LzYQg91SIxDeOGtCKd5][qHYIWnOZLPkrQU])
		uuSKUinvP4EGLxWZYmTsF.append(TYf7Dc06PQgy1vEV9(u"ࠩࡰ࠷ࡺ࠾ࠧକ"))
		KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j.append(items[LzYQg91SIxDeOGtCKd5][LzYQg91SIxDeOGtCKd5])
		return b8Qe150xVaJsnDSv,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j
	else: return uVQd103XyvUce2EBtzbYaC(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡒࡉࡊࡘࡌࡈࡊࡕࠧଖ"),[],[]
def wUvIhZ72APyNVpW8KiBrakOsctoj6G(url):
	yXdtJT0UQL = url.split(QTUBCcehw6qPd4x(u"ࠫ࠴࠭ଗ"))[-qHYIWnOZLPkrQU]
	yXdtJT0UQL = yXdtJT0UQL.split(HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠬࠬࠧଘ"))[LzYQg91SIxDeOGtCKd5]
	yXdtJT0UQL = yXdtJT0UQL.replace(dDYUoKi6JFM23p(u"࠭ࡷࡢࡶࡦ࡬ࡄࡼ࠽ࠨଙ"),b8Qe150xVaJsnDSv)
	MUJCtfYVBLODrFbaZn = nTHXJIiah2qK[BmePGjS7FxK6kutUM(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨଚ")][LzYQg91SIxDeOGtCKd5]+vvWwO3Tx2dAgcijrFXq(u"ࠨ࠱ࡺࡥࡹࡩࡨࡀࡸࡀࠫଛ")+yXdtJT0UQL
	hDb03znZRCBs8M = m6hwdgP31a2zjN7lkpX(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡼࡳࡺࡺࡵ࠯ࡤࡨ࠳ࠬଜ")+yXdtJT0UQL
	KKN7hlEptWCVZ6IUdAPiQ,v5r8wqFZ2KE9QtdHmp0S = b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv
	headers = {mQNonhS7CV2BXOv(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧଝ"):b8Qe150xVaJsnDSv}
	if LzYQg91SIxDeOGtCKd5:
		jLtdbeYiQHnf4SpU2MTly = b8Qe150xVaJsnDSv
		for s9s45taoNBh60XL1zykOmTK3jJCrE in range(BmePGjS7FxK6kutUM(u"࠶෺")):
			b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(nCUMfrlZvuiLe5x,mQNonhS7CV2BXOv(u"ࠫࡌࡋࡔࠨଞ"),MUJCtfYVBLODrFbaZn,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,dDYUoKi6JFM23p(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡛ࡒ࡙࡙࡛ࡂࡆ࠯࠴ࡷࡹ࠭ଟ"))
			jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
			if RRIHDFjoW9w7bSfVPhC(u"࠭ࡩࡵࡣࡪࠫଠ") in jLtdbeYiQHnf4SpU2MTly: break
			wLQCTr5lqbsVYeAHdzfhZ1F.sleep(IgQimel18t)
		M43f6vQclCZObzn9aFUWTH = YYBlm36zd0Jst18LXwo4.findall(RRIHDFjoW9w7bSfVPhC(u"ࠧࡷࡣࡵࠤࡾࡺࡉ࡯࡫ࡷ࡭ࡦࡲࡐ࡭ࡣࡼࡩࡷࡘࡥࡴࡲࡲࡲࡸ࡫ࠠ࠾ࠢࠫ࠲࠯ࡅࠩ࠼࠾࠲ࡷࡨࡸࡩࡱࡶࡁࠫଡ"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if M43f6vQclCZObzn9aFUWTH: M43f6vQclCZObzn9aFUWTH = M43f6vQclCZObzn9aFUWTH[LzYQg91SIxDeOGtCKd5]
		else: M43f6vQclCZObzn9aFUWTH = jLtdbeYiQHnf4SpU2MTly
	else:
		jLtdbeYiQHnf4SpU2MTly = b8Qe150xVaJsnDSv
		ffVi1d3hA7z8SOFTxwj,ZMNRKClQqtSFpj5A0z1caoInVD = b8Qe150xVaJsnDSv,{}
		ktDueJnSZsWAEFp9z0VgxvB7YGXRci,OQXvFDYNboBAfUKCcpa7I5yHu = b8Qe150xVaJsnDSv,{}
		GSh0nJxEXgZjd48u7mBwWOeafyAp5b = nTHXJIiah2qK[QTUBCcehw6qPd4x(u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩଢ")][LzYQg91SIxDeOGtCKd5]+S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠩ࠲ࡽࡴࡻࡴࡶࡤࡨ࡭࠴ࡼ࠱࠰ࡲ࡯ࡥࡾ࡫ࡲࠨଣ")
		headers[Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩତ")] = uVQd103XyvUce2EBtzbYaC(u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱࡭ࡷࡴࡴࠧଥ")
		if qHYIWnOZLPkrQU:
			RnS0DVXIxG6KgBc584Cas9q = TYf7Dc06PQgy1vEV9(u"ࠬࢁࠢࡷ࡫ࡧࡩࡴࡏࡤࠣ࠼ࠣࠦࠬଦ")+yXdtJT0UQL+TYf7Dc06PQgy1vEV9(u"࠭ࠢ࠭ࠢࠥࡧࡴࡴࡴࡦࡺࡷࠦ࠿ࠦࡻࠣࡥ࡯࡭ࡪࡴࡴࠣ࠼ࠣࡿࠧࡩ࡬ࡪࡧࡱࡸ࡛࡫ࡲࡴ࡫ࡲࡲࠧࡀࠠࠣ࠺࠱࠵࠷࠴࠰ࠣ࠮ࠣࠦࡨࡲࡩࡦࡰࡷࡒࡦࡳࡥࠣ࠼ࠣࠦࡆࡔࡄࡓࡑࡌࡈࡤ࡛ࡎࡑࡎࡘࡋࡌࡋࡄࠣࡿࢀࢁࠬଧ")
			b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(nCUMfrlZvuiLe5x,shC5qBRV2A0lZ(u"ࠧࡑࡑࡖࡘࠬନ"),GSh0nJxEXgZjd48u7mBwWOeafyAp5b,RnS0DVXIxG6KgBc584Cas9q,headers,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,IjZbnrBJmM2N(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡞ࡕࡕࡕࡗࡅࡉ࠲࠸࡮ࡥࠩ଩"))
			M43f6vQclCZObzn9aFUWTH = b3HKopTY9zLUyhJmt.content
			if TYf7Dc06PQgy1vEV9(u"ࠩࡶࡸࡷ࡫ࡡ࡮࡫ࡱ࡫ࡉࡧࡴࡢࠩପ") in M43f6vQclCZObzn9aFUWTH:
				ffVi1d3hA7z8SOFTxwj = M43f6vQclCZObzn9aFUWTH.replace(LAQD5wEkr18bUiGaYen3J(u"ࠪࡠࡡࡻ࠰࠱࠴࠹ࠫଫ"),zI3ROAZtiUq42rE9WDST68(u"ࠫࠫ࠭ବ"))
				ZMNRKClQqtSFpj5A0z1caoInVD = oJsUwXA0yGOI1mTjxQ(shC5qBRV2A0lZ(u"ࠬࡪࡩࡤࡶࠪଭ"),ffVi1d3hA7z8SOFTxwj)
		if qHYIWnOZLPkrQU:
			RnS0DVXIxG6KgBc584Cas9q = QTUBCcehw6qPd4x(u"࠭ࡻࠣࡸ࡬ࡨࡪࡵࡉࡥࠤ࠽ࠤࠧ࠭ମ")+yXdtJT0UQL+TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠧࠣ࠮ࠣࠦࡨࡵ࡮ࡵࡧࡻࡸࠧࡀࠠࡼࠤࡦࡰ࡮࡫࡮ࡵࠤ࠽ࠤࢀࠨࡣ࡭࡫ࡨࡲࡹ࡜ࡥࡳࡵ࡬ࡳࡳࠨ࠺ࠡࠤ࠹࠲࠸࠼ࠢ࠭ࠢࠥࡧࡱ࡯ࡥ࡯ࡶࡑࡥࡲ࡫ࠢ࠻ࠢࠥࡍࡔ࡙࡟ࡖࡐࡓࡐ࡚ࡍࡇࡆࡆࠥࢁࢂࢃࠧଯ")
			b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(nCUMfrlZvuiLe5x,Xz3bA2PFENVCUtplu51(u"ࠨࡒࡒࡗ࡙࠭ର"),GSh0nJxEXgZjd48u7mBwWOeafyAp5b,RnS0DVXIxG6KgBc584Cas9q,headers,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,yST5AHEfvPmcWpwGuh2BJ(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡟ࡏࡖࡖࡘࡆࡊ࠳࠳ࡳࡦࠪ଱"))
			M43f6vQclCZObzn9aFUWTH = b3HKopTY9zLUyhJmt.content
			if RRIHDFjoW9w7bSfVPhC(u"ࠪࡷࡹࡸࡥࡢ࡯࡬ࡲ࡬ࡊࡡࡵࡣࠪଲ") in M43f6vQclCZObzn9aFUWTH:
				ktDueJnSZsWAEFp9z0VgxvB7YGXRci = M43f6vQclCZObzn9aFUWTH.replace(Xz3bA2PFENVCUtplu51(u"ࠫࡡࡢࡵ࠱࠲࠵࠺ࠬଳ"),m6hwdgP31a2zjN7lkpX(u"ࠬࠬࠧ଴"))
				OQXvFDYNboBAfUKCcpa7I5yHu = oJsUwXA0yGOI1mTjxQ(Nh0BWuiSndf(u"࠭ࡤࡪࡥࡷࠫଵ"),ktDueJnSZsWAEFp9z0VgxvB7YGXRci)
		if qHYIWnOZLPkrQU and kke1PDGRBLuY8y(u"ࠧࡴࡶࡵࡩࡦࡳࡩ࡯ࡩࡇࡥࡹࡧࠧଶ") not in ffVi1d3hA7z8SOFTxwj+ktDueJnSZsWAEFp9z0VgxvB7YGXRci:
			ffVi1d3hA7z8SOFTxwj,ktDueJnSZsWAEFp9z0VgxvB7YGXRci = b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv
			ZMNRKClQqtSFpj5A0z1caoInVD,OQXvFDYNboBAfUKCcpa7I5yHu = {},{}
			RnS0DVXIxG6KgBc584Cas9q = Nh0BWuiSndf(u"ࠨࡽࠥࡺ࡮ࡪࡥࡰࡋࡧࠦ࠿ࠦࠢࠨଷ")+yXdtJT0UQL+QQdAXWBc2GPw(u"ࠩࠥ࠰ࠥࠨࡣࡰࡰࡷࡩࡽࡺࠢ࠻ࠢࡾࠦࡨࡲࡩࡦࡰࡷࠦ࠿ࠦࡻࠣࡥ࡯࡭ࡪࡴࡴࡗࡧࡵࡷ࡮ࡵ࡮ࠣ࠼ࠣࠦ࠶࠿࠮࠳࠻࠱࠷࠼ࠨࠬࠡࠤࡦࡰ࡮࡫࡮ࡵࡐࡤࡱࡪࠨ࠺ࠡࠤࡌࡓࡘࠨࡽࡾࡿࠪସ")
			b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(nCUMfrlZvuiLe5x,SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠪࡔࡔ࡙ࡔࠨହ"),GSh0nJxEXgZjd48u7mBwWOeafyAp5b,RnS0DVXIxG6KgBc584Cas9q,headers,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,uVQd103XyvUce2EBtzbYaC(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࡚࠭ࡑࡘࡘ࡚ࡈࡅ࠮࠶ࡷ࡬ࠬ଺"))
			M43f6vQclCZObzn9aFUWTH = b3HKopTY9zLUyhJmt.content
			if S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠬࡹࡴࡳࡧࡤࡱ࡮ࡴࡧࡅࡣࡷࡥࠬ଻") in M43f6vQclCZObzn9aFUWTH:
				ffVi1d3hA7z8SOFTxwj = M43f6vQclCZObzn9aFUWTH.replace(DYakr9g4PVU(u"࠭࡜࡝ࡷ࠳࠴࠷࠼଼ࠧ"),IjZbnrBJmM2N(u"ࠧࠧࠩଽ"))
				ZMNRKClQqtSFpj5A0z1caoInVD = oJsUwXA0yGOI1mTjxQ(Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠨࡦ࡬ࡧࡹ࠭ା"),ffVi1d3hA7z8SOFTxwj)
	xohWA2V6IzLyRC,czDjnFViZUd5pLy8SMfmaEhvC,a71negwUJQiO,gg8bTKn7fGZWY = b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,[],[]
	xlStANfgiwdRFObmzyu82eY716WGk,UBZYD52kfGSX71gATo83yphin6uExc,adxv0VqWK7yltsT1ErnP,o6CO79fAkr5TdDjwY = b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,[],[]
	try: czDjnFViZUd5pLy8SMfmaEhvC = ZMNRKClQqtSFpj5A0z1caoInVD[QTUBCcehw6qPd4x(u"ࠩࡶࡸࡷ࡫ࡡ࡮࡫ࡱ࡫ࡉࡧࡴࡢࠩି")][dDYUoKi6JFM23p(u"ࠪ࡬ࡱࡹࡍࡢࡰ࡬ࡪࡪࡹࡴࡖࡴ࡯ࠫୀ")]
	except: pass
	try: UBZYD52kfGSX71gATo83yphin6uExc = OQXvFDYNboBAfUKCcpa7I5yHu[TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠫࡸࡺࡲࡦࡣࡰ࡭ࡳ࡭ࡄࡢࡶࡤࠫୁ")][TYf7Dc06PQgy1vEV9(u"ࠬ࡮࡬ࡴࡏࡤࡲ࡮࡬ࡥࡴࡶࡘࡶࡱ࠭ୂ")]
	except: pass
	try: xohWA2V6IzLyRC = ZMNRKClQqtSFpj5A0z1caoInVD[BWNPxIG7vqdTy85pjHzUOrK3(u"࠭ࡳࡵࡴࡨࡥࡲ࡯࡮ࡨࡆࡤࡸࡦ࠭ୃ")][ddo23ZJtgcY(u"ࠧࡥࡣࡶ࡬ࡒࡧ࡮ࡪࡨࡨࡷࡹ࡛ࡲ࡭ࠩୄ")]
	except: pass
	try: xlStANfgiwdRFObmzyu82eY716WGk = OQXvFDYNboBAfUKCcpa7I5yHu[QQdAXWBc2GPw(u"ࠨࡵࡷࡶࡪࡧ࡭ࡪࡰࡪࡈࡦࡺࡡࠨ୅")][BWNPxIG7vqdTy85pjHzUOrK3(u"ࠩࡧࡥࡸ࡮ࡍࡢࡰ࡬ࡪࡪࡹࡴࡖࡴ࡯ࠫ୆")]
	except: pass
	try: a71negwUJQiO = ZMNRKClQqtSFpj5A0z1caoInVD[Mmpr0o76iWJvz1kTtfgI8hES(u"ࠪࡷࡹࡸࡥࡢ࡯࡬ࡲ࡬ࡊࡡࡵࡣࠪେ")][Nh0BWuiSndf(u"ࠫ࡫ࡵࡲ࡮ࡣࡷࡷࠬୈ")]
	except: pass
	try: adxv0VqWK7yltsT1ErnP = OQXvFDYNboBAfUKCcpa7I5yHu[DYakr9g4PVU(u"ࠬࡹࡴࡳࡧࡤࡱ࡮ࡴࡧࡅࡣࡷࡥࠬ୉")][BmePGjS7FxK6kutUM(u"࠭ࡦࡰࡴࡰࡥࡹࡹࠧ୊")]
	except: pass
	try: gg8bTKn7fGZWY = ZMNRKClQqtSFpj5A0z1caoInVD[BmePGjS7FxK6kutUM(u"ࠧࡴࡶࡵࡩࡦࡳࡩ࡯ࡩࡇࡥࡹࡧࠧୋ")][UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠨࡣࡧࡥࡵࡺࡩࡷࡧࡉࡳࡷࡳࡡࡵࡵࠪୌ")]
	except: pass
	try: o6CO79fAkr5TdDjwY = OQXvFDYNboBAfUKCcpa7I5yHu[ddo23ZJtgcY(u"ࠩࡶࡸࡷ࡫ࡡ࡮࡫ࡱ࡫ࡉࡧࡴࡢ୍ࠩ")][QQdAXWBc2GPw(u"ࠪࡥࡩࡧࡰࡵ࡫ࡹࡩࡋࡵࡲ࡮ࡣࡷࡷࠬ୎")]
	except: pass
	uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = [UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠫอี่็ࠢอีั๋ษࠡ์๋ฮ๏๎ศࠨ୏")],[b8Qe150xVaJsnDSv]
	try:
		RsVb0n9QGPJfg8rA6hzNl = ZMNRKClQqtSFpj5A0z1caoInVD[m6hwdgP31a2zjN7lkpX(u"ࠬࡩࡡࡱࡶ࡬ࡳࡳࡹࠧ୐")][yST5AHEfvPmcWpwGuh2BJ(u"࠭ࡰ࡭ࡣࡼࡩࡷࡉࡡࡱࡶ࡬ࡳࡳࡹࡔࡳࡣࡦ࡯ࡱ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ୑")][HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠧࡤࡣࡳࡸ࡮ࡵ࡮ࡕࡴࡤࡧࡰࡹࠧ୒")]
		for CjF3DyvJwco6WAKkaPG in RsVb0n9QGPJfg8rA6hzNl:
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = CjF3DyvJwco6WAKkaPG[BWNPxIG7vqdTy85pjHzUOrK3(u"ࠨࡤࡤࡷࡪ࡛ࡲ࡭ࠩ୓")]
			try: title = CjF3DyvJwco6WAKkaPG[SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠩࡱࡥࡲ࡫ࠧ୔")][ubxGUTt1LraKhVZgpAP(u"ࠪࡷ࡮ࡳࡰ࡭ࡧࡗࡩࡽࡺࠧ୕")]
			except: title = CjF3DyvJwco6WAKkaPG[dDYUoKi6JFM23p(u"ࠫࡳࡧ࡭ࡦࠩୖ")][Nh0BWuiSndf(u"ࠬࡸࡵ࡯ࡵࠪୗ")][LzYQg91SIxDeOGtCKd5][RRIHDFjoW9w7bSfVPhC(u"࠭ࡴࡦࡺࡷࡸࠬ୘")]
			KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
			uuSKUinvP4EGLxWZYmTsF.append(title)
	except: pass
	try:
		RsVb0n9QGPJfg8rA6hzNl = OQXvFDYNboBAfUKCcpa7I5yHu[uVQd103XyvUce2EBtzbYaC(u"ࠧࡤࡣࡳࡸ࡮ࡵ࡮ࡴࠩ୙")][Nh0BWuiSndf(u"ࠨࡲ࡯ࡥࡾ࡫ࡲࡄࡣࡳࡸ࡮ࡵ࡮ࡴࡖࡵࡥࡨࡱ࡬ࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬ୚")][dDYUoKi6JFM23p(u"ࠩࡦࡥࡵࡺࡩࡰࡰࡗࡶࡦࡩ࡫ࡴࠩ୛")]
		for CjF3DyvJwco6WAKkaPG in RsVb0n9QGPJfg8rA6hzNl:
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = CjF3DyvJwco6WAKkaPG[ubxGUTt1LraKhVZgpAP(u"ࠪࡦࡦࡹࡥࡖࡴ࡯ࠫଡ଼")]
			try: title = CjF3DyvJwco6WAKkaPG[QQdAXWBc2GPw(u"ࠫࡳࡧ࡭ࡦࠩଢ଼")][QQdAXWBc2GPw(u"ࠬࡹࡩ࡮ࡲ࡯ࡩ࡙࡫ࡸࡵࠩ୞")]
			except: title = CjF3DyvJwco6WAKkaPG[BWNPxIG7vqdTy85pjHzUOrK3(u"࠭࡮ࡢ࡯ࡨࠫୟ")][uVQd103XyvUce2EBtzbYaC(u"ࠧࡳࡷࡱࡷࠬୠ")][LzYQg91SIxDeOGtCKd5][QQdAXWBc2GPw(u"ࠨࡶࡨࡼࡹࡺࠧୡ")]
			if pcA1dzy7LXwGfMPg9mTkuh5tine3 not in KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j:
				KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
				uuSKUinvP4EGLxWZYmTsF.append(title)
	except: pass
	if len(uuSKUinvP4EGLxWZYmTsF)>qHYIWnOZLPkrQU:
		cMZGTsAR2E = XXprCMzuNP2mElUxfdA(yST5AHEfvPmcWpwGuh2BJ(u"ࠩสาฯืࠠศๆอีั๋ษࠡࠪࠪୢ")+str(len(uuSKUinvP4EGLxWZYmTsF))+RRIHDFjoW9w7bSfVPhC(u"ࠪࠤ๊๊แࠪࠩୣ"), uuSKUinvP4EGLxWZYmTsF)
		if cMZGTsAR2E==-qHYIWnOZLPkrQU: return ubxGUTt1LraKhVZgpAP(u"ࠫࡊ࡞ࡉࡕࡡࡄࡐࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ୤"),[],[]
		elif cMZGTsAR2E!=LzYQg91SIxDeOGtCKd5:
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j[cMZGTsAR2E]+HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠬࠬࠧ୥")
			xQb1enrupit50aDqLC4vBIY = YYBlm36zd0Jst18LXwo4.findall(Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"࠭ࠦࠩࡨࡰࡸࡂ࠴ࠪࡀࠫࠩࠫ୦"),pcA1dzy7LXwGfMPg9mTkuh5tine3)
			if xQb1enrupit50aDqLC4vBIY: pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3.replace(xQb1enrupit50aDqLC4vBIY[LzYQg91SIxDeOGtCKd5],zI3ROAZtiUq42rE9WDST68(u"ࠧࡧ࡯ࡷࡁࡻࡺࡴࠨ୧"))
			else: pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3+ubxGUTt1LraKhVZgpAP(u"ࠨࡨࡰࡸࡂࡼࡴࡵࠩ୨")
			KKN7hlEptWCVZ6IUdAPiQ = pcA1dzy7LXwGfMPg9mTkuh5tine3.strip(vvWwO3Tx2dAgcijrFXq(u"ࠩࠩࠫ୩"))
	TLqWX5SmU4uNFn6GvhExH,HKtT0XZc2OQ,HoBXvrcyAfWuP2T67 = [],[],[]
	xbmCyiNsz9RBMwhWXLT = [czDjnFViZUd5pLy8SMfmaEhvC,UBZYD52kfGSX71gATo83yphin6uExc]
	Af7ySpsQaZ16 = [xohWA2V6IzLyRC,xlStANfgiwdRFObmzyu82eY716WGk]
	Vw6ELd0ReyubDGkj87FA1Zin,IJnULg7XsvifQHVY = [],[]
	for W0sGaMZXq8nrSvj6K2fU in a71negwUJQiO+adxv0VqWK7yltsT1ErnP:
		if W0sGaMZXq8nrSvj6K2fU[m6hwdgP31a2zjN7lkpX(u"ࠪ࡭ࡹࡧࡧࠨ୪")] not in Vw6ELd0ReyubDGkj87FA1Zin:
			Vw6ELd0ReyubDGkj87FA1Zin.append(W0sGaMZXq8nrSvj6K2fU[UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠫ࡮ࡺࡡࡨࠩ୫")])
			IJnULg7XsvifQHVY.append(W0sGaMZXq8nrSvj6K2fU)
	Vw6ELd0ReyubDGkj87FA1Zin,YF0XJ3tORCsufaQhIZ = [],[]
	for W0sGaMZXq8nrSvj6K2fU in gg8bTKn7fGZWY+o6CO79fAkr5TdDjwY:
		if W0sGaMZXq8nrSvj6K2fU[QTUBCcehw6qPd4x(u"ࠬ࡯ࡴࡢࡩࠪ୬")] not in Vw6ELd0ReyubDGkj87FA1Zin:
			Vw6ELd0ReyubDGkj87FA1Zin.append(W0sGaMZXq8nrSvj6K2fU[Mmpr0o76iWJvz1kTtfgI8hES(u"࠭ࡩࡵࡣࡪࠫ୭")])
			YF0XJ3tORCsufaQhIZ.append(W0sGaMZXq8nrSvj6K2fU)
	for dict in IJnULg7XsvifQHVY+YF0XJ3tORCsufaQhIZ:
		if LAQD5wEkr18bUiGaYen3J(u"ࠧࡪࡶࡤ࡫ࠬ୮") in list(dict.keys()): dict[dDYUoKi6JFM23p(u"ࠨ࡫ࡷࡥ࡬࠭୯")] = str(dict[dDYUoKi6JFM23p(u"ࠩ࡬ࡸࡦ࡭ࠧ୰")])
		if RRIHDFjoW9w7bSfVPhC(u"ࠪࡪࡵࡹࠧୱ") in list(dict.keys()): dict[vvWwO3Tx2dAgcijrFXq(u"ࠫ࡫ࡶࡳࠨ୲")] = str(dict[BmePGjS7FxK6kutUM(u"ࠬ࡬ࡰࡴࠩ୳")])
		if Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"࠭࡭ࡪ࡯ࡨࡘࡾࡶࡥࠨ୴") in list(dict.keys()): dict[S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠧࡵࡻࡳࡩࠬ୵")] = dict[Xz3bA2PFENVCUtplu51(u"ࠨ࡯࡬ࡱࡪ࡚ࡹࡱࡧࠪ୶")]
		if IjZbnrBJmM2N(u"ࠩࡤࡹࡩ࡯࡯ࡔࡣࡰࡴࡱ࡫ࡒࡢࡶࡨࠫ୷") in list(dict.keys()): dict[Nh0BWuiSndf(u"ࠪࡥࡺࡪࡩࡰࡡࡶࡥࡲࡶ࡬ࡦࡡࡵࡥࡹ࡫ࠧ୸")] = str(dict[vvWwO3Tx2dAgcijrFXq(u"ࠫࡦࡻࡤࡪࡱࡖࡥࡲࡶ࡬ࡦࡔࡤࡸࡪ࠭୹")])
		if IjZbnrBJmM2N(u"ࠬࡧࡵࡥ࡫ࡲࡇ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬ୺") in list(dict.keys()): dict[dDYUoKi6JFM23p(u"࠭ࡡࡶࡦ࡬ࡳࡤࡩࡨࡢࡰࡱࡩࡱࡹࠧ୻")] = str(dict[Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠧࡢࡷࡧ࡭ࡴࡉࡨࡢࡰࡱࡩࡱࡹࠧ୼")])
		if dDYUoKi6JFM23p(u"ࠨࡹ࡬ࡨࡹ࡮ࠧ୽") in list(dict.keys()): dict[P0qdZI384LKleuo(u"ࠩࡶ࡭ࡿ࡫ࠧ୾")] = str(dict[uVQd103XyvUce2EBtzbYaC(u"ࠪࡻ࡮ࡪࡴࡩࠩ୿")])+kke1PDGRBLuY8y(u"ࠫࡽ࠭஀")+str(dict[LAQD5wEkr18bUiGaYen3J(u"ࠬ࡮ࡥࡪࡩ࡫ࡸࠬ஁")])
		if uVQd103XyvUce2EBtzbYaC(u"࠭ࡩ࡯࡫ࡷࡖࡦࡴࡧࡦࠩஂ") in list(dict.keys()): dict[BmePGjS7FxK6kutUM(u"ࠧࡪࡰ࡬ࡸࠬஃ")] = dict[Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠨ࡫ࡱ࡭ࡹࡘࡡ࡯ࡩࡨࠫ஄")][ubxGUTt1LraKhVZgpAP(u"ࠩࡶࡸࡦࡸࡴࠨஅ")]+VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠪ࠱ࠬஆ")+dict[mQNonhS7CV2BXOv(u"ࠫ࡮ࡴࡩࡵࡔࡤࡲ࡬࡫ࠧஇ")][shC5qBRV2A0lZ(u"ࠬ࡫࡮ࡥࠩஈ")]
		if RRIHDFjoW9w7bSfVPhC(u"࠭ࡩ࡯ࡦࡨࡼࡗࡧ࡮ࡨࡧࠪஉ") in list(dict.keys()): dict[IjZbnrBJmM2N(u"ࠧࡪࡰࡧࡩࡽ࠭ஊ")] = dict[kke1PDGRBLuY8y(u"ࠨ࡫ࡱࡨࡪࡾࡒࡢࡰࡪࡩࠬ஋")][VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠩࡶࡸࡦࡸࡴࠨ஌")]+VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠪ࠱ࠬ஍")+dict[VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠫ࡮ࡴࡤࡦࡺࡕࡥࡳ࡭ࡥࠨஎ")][Mmpr0o76iWJvz1kTtfgI8hES(u"ࠬ࡫࡮ࡥࠩஏ")]
		if BWNPxIG7vqdTy85pjHzUOrK3(u"࠭ࡡࡷࡧࡵࡥ࡬࡫ࡂࡪࡶࡵࡥࡹ࡫ࠧஐ") in list(dict.keys()): dict[kke1PDGRBLuY8y(u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ஑")] = dict[shC5qBRV2A0lZ(u"ࠨࡣࡹࡩࡷࡧࡧࡦࡄ࡬ࡸࡷࡧࡴࡦࠩஒ")]
		if QTUBCcehw6qPd4x(u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪஓ") in list(dict.keys()) and int(dict[kke1PDGRBLuY8y(u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫஔ")])>SbjiWeHLQPoazqwp3cODkd7YxVgn(u"࠳࠴࠵࠷࠸࠲࠴࠵࠶෻"): del dict[yST5AHEfvPmcWpwGuh2BJ(u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬக")]
		if kke1PDGRBLuY8y(u"ࠬࡹࡩࡨࡰࡤࡸࡺࡸࡥࡄ࡫ࡳ࡬ࡪࡸࠧ஖") in list(dict.keys()):
			vb5gqoQVstrk0NCjwl8Ez96hP = dict[BWNPxIG7vqdTy85pjHzUOrK3(u"࠭ࡳࡪࡩࡱࡥࡹࡻࡲࡦࡅ࡬ࡴ࡭࡫ࡲࠨ஗")].split(dDYUoKi6JFM23p(u"ࠧࠧࠩ஘"))
			for tgoJCpq8KGrdaUSjsLh0FTxDRPfIAB in vb5gqoQVstrk0NCjwl8Ez96hP:
				key,Y8aiFZsLKw = tgoJCpq8KGrdaUSjsLh0FTxDRPfIAB.split(BmePGjS7FxK6kutUM(u"ࠨ࠿ࠪங"),m6hwdgP31a2zjN7lkpX(u"࠴෼"))
				dict[key] = SgrGWuAHcLKBQMJetb9(Y8aiFZsLKw)
		if HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠩࡸࡶࡱ࠭ச") in list(dict.keys()): dict[ubxGUTt1LraKhVZgpAP(u"ࠪࡹࡷࡲࠧ஛")] = SgrGWuAHcLKBQMJetb9(dict[SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠫࡺࡸ࡬ࠨஜ")])
		TLqWX5SmU4uNFn6GvhExH.append(dict)
	A8Gzf5RuFIr0QEX4k2Dy1qjlPcdU = b8Qe150xVaJsnDSv
	if Xz3bA2PFENVCUtplu51(u"ࠬࡹࡰ࠾ࡵ࡬࡫ࠬ஝") in ffVi1d3hA7z8SOFTxwj or UUkIBz1sgQ9WfNeG6trKXvu0(u"࠭ࡳࡱ࠿ࡶ࡭࡬࠭ஞ") in ktDueJnSZsWAEFp9z0VgxvB7YGXRci:
		if not jLtdbeYiQHnf4SpU2MTly:
			b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(nCUMfrlZvuiLe5x,QTUBCcehw6qPd4x(u"ࠧࡈࡇࡗࠫட"),MUJCtfYVBLODrFbaZn,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,P0qdZI384LKleuo(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡞ࡕࡕࡕࡗࡅࡉ࠲࠻ࡴࡩࠩ஠"))
			jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
		eHKZxdzgaMPqEsFI5U6vXci = YYBlm36zd0Jst18LXwo4.findall(ddo23ZJtgcY(u"ࠩࡶࡶࡨࡃࠢࠩ࠱ࡶ࠳ࡵࡲࡡࡺࡧࡵ࠳ࡡࡽࠪࡀ࠱ࡳࡰࡦࡿࡥࡳࡡ࡬ࡥࡸ࠴ࡶࡧ࡮ࡶࡩࡹ࠵ࡥ࡯ࡡ࠱࠲࠴ࡨࡡࡴࡧ࠱࡮ࡸ࠯ࠢࠨ஡"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if eHKZxdzgaMPqEsFI5U6vXci:
			eHKZxdzgaMPqEsFI5U6vXci = nTHXJIiah2qK[QQdAXWBc2GPw(u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫ஢")][LzYQg91SIxDeOGtCKd5]+eHKZxdzgaMPqEsFI5U6vXci[LzYQg91SIxDeOGtCKd5]
			b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(nCUMfrlZvuiLe5x,Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠫࡌࡋࡔࠨண"),eHKZxdzgaMPqEsFI5U6vXci,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,TYf7Dc06PQgy1vEV9(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡛ࡒ࡙࡙࡛ࡂࡆ࠯࠹ࡸ࡭࠭த"))
			A8Gzf5RuFIr0QEX4k2Dy1qjlPcdU = b3HKopTY9zLUyhJmt.content
			import youtube_signature.cipher as daAwrFK48DXkighJIHtEsv7pGLq,youtube_signature.json_script_engine as LFkWaCXYxE5QDiZUo2BJj4wutnsOTc
			vb5gqoQVstrk0NCjwl8Ez96hP = HHULCatuNF1d6DyJrc.vb5gqoQVstrk0NCjwl8Ez96hP.Cipher()
			vb5gqoQVstrk0NCjwl8Ez96hP._object_cache = {}
			FDV5UqhGj0LYv91mBKCO = vb5gqoQVstrk0NCjwl8Ez96hP._load_javascript(A8Gzf5RuFIr0QEX4k2Dy1qjlPcdU)
			wU70V3CphYxdJNftbMEozenyKjm = oJsUwXA0yGOI1mTjxQ(TT8Mxv5Wq7nlC9IscdpPUY6(u"࠭ࡳࡵࡴࠪ஥"),str(FDV5UqhGj0LYv91mBKCO))
			CCG3AMPxfqSipHEj0 = HHULCatuNF1d6DyJrc.jj74zcirXJ6gEoIV3dCT1blDWyxf.JsonScriptEngine(wU70V3CphYxdJNftbMEozenyKjm)
	for dict in TLqWX5SmU4uNFn6GvhExH:
		url = dict[QTUBCcehw6qPd4x(u"ࠧࡶࡴ࡯ࠫ஦")]
		if LAQD5wEkr18bUiGaYen3J(u"ࠨࡵ࡬࡫ࡳࡧࡴࡶࡴࡨࡁࠬ஧") in url or url.count(BWNPxIG7vqdTy85pjHzUOrK3(u"ࠩࡶ࡭࡬ࡃࠧந"))>qHYIWnOZLPkrQU:
			HKtT0XZc2OQ.append(dict)
		elif A8Gzf5RuFIr0QEX4k2Dy1qjlPcdU and IjZbnrBJmM2N(u"ࠪࡷࠬன") in list(dict.keys()) and IjZbnrBJmM2N(u"ࠫࡸࡶࠧப") in list(dict.keys()):
			JwhHxYg21pV7GdrPX3lk = CCG3AMPxfqSipHEj0.execute(dict[Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠬࡹࠧ஫")])
			if JwhHxYg21pV7GdrPX3lk!=dict[Xz3bA2PFENVCUtplu51(u"࠭ࡳࠨ஬")]:
				dict[RRIHDFjoW9w7bSfVPhC(u"ࠧࡶࡴ࡯ࠫ஭")] = url+Nh0BWuiSndf(u"ࠨࠨࠪம")+dict[Mmpr0o76iWJvz1kTtfgI8hES(u"ࠩࡶࡴࠬய")]+shC5qBRV2A0lZ(u"ࠪࡁࠬர")+JwhHxYg21pV7GdrPX3lk
				HKtT0XZc2OQ.append(dict)
	for dict in HKtT0XZc2OQ:
		UYat1jqNzCdDlWGuPF60T9i,R6Dpxibf4ZYOm,NUycq9VuGzi8k6x,jWqKYXlEZzQ,swh5pH21Cix9flUKcZ,F8Ef6K7kCy9mbQPx = dDYUoKi6JFM23p(u"ࠫࡺࡴ࡫࡯ࡱࡺࡲࠬற"),Nh0BWuiSndf(u"ࠬࡻ࡮࡬ࡰࡲࡻࡳ࠭ல"),RRIHDFjoW9w7bSfVPhC(u"࠭ࡵ࡯࡭ࡱࡳࡼࡴࠧள"),QTUBCcehw6qPd4x(u"ࠧࡖࡰ࡮ࡲࡴࡽ࡮ࠨழ"),b8Qe150xVaJsnDSv,QQdAXWBc2GPw(u"ࠨ࠲ࠪவ")
		try:
			Gbwlrm27Lvj8M6Iukx3eED5Ho = dict[TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠩࡷࡽࡵ࡫ࠧஶ")]
			Gbwlrm27Lvj8M6Iukx3eED5Ho = Gbwlrm27Lvj8M6Iukx3eED5Ho.replace(BmePGjS7FxK6kutUM(u"ࠪ࠯ࠬஷ"),b8Qe150xVaJsnDSv)
			items = YYBlm36zd0Jst18LXwo4.findall(P0qdZI384LKleuo(u"ࠫ࠭࠴ࠪࡀࠫ࠲ࠬ࠳࠰࠿ࠪ࠽࠱࠮ࡄࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ஸ"),Gbwlrm27Lvj8M6Iukx3eED5Ho,YYBlm36zd0Jst18LXwo4.DOTALL)
			jWqKYXlEZzQ,UYat1jqNzCdDlWGuPF60T9i,swh5pH21Cix9flUKcZ = items[LzYQg91SIxDeOGtCKd5]
			ZpRAjU8S9m6cXtFC2 = swh5pH21Cix9flUKcZ.split(Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠬ࠲ࠧஹ"))
			R6Dpxibf4ZYOm = b8Qe150xVaJsnDSv
			for tgoJCpq8KGrdaUSjsLh0FTxDRPfIAB in ZpRAjU8S9m6cXtFC2: R6Dpxibf4ZYOm += tgoJCpq8KGrdaUSjsLh0FTxDRPfIAB.split(Nh0BWuiSndf(u"࠭࠮ࠨ஺"))[LzYQg91SIxDeOGtCKd5]+DYakr9g4PVU(u"ࠧ࠭ࠩ஻")
			R6Dpxibf4ZYOm = R6Dpxibf4ZYOm.strip(VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠨ࠮ࠪ஼"))
			if RRIHDFjoW9w7bSfVPhC(u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ஽") in list(dict.keys()): F8Ef6K7kCy9mbQPx = str(int(dict[QQdAXWBc2GPw(u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫா")])//HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"࠵࠵࠸࠴෽"))+Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠫࡰࡨࡰࡴࠢࠣࠫி")
			else: F8Ef6K7kCy9mbQPx = b8Qe150xVaJsnDSv
			if jWqKYXlEZzQ==TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠬࡺࡥࡹࡶࡷࠫீ"): continue
			elif mQNonhS7CV2BXOv(u"࠭ࠬࠨு") in Gbwlrm27Lvj8M6Iukx3eED5Ho:
				jWqKYXlEZzQ = TYf7Dc06PQgy1vEV9(u"ࠧࡂ࡙࠭ࠫூ")
				NUycq9VuGzi8k6x = UYat1jqNzCdDlWGuPF60T9i+k5bCDErUSmv+F8Ef6K7kCy9mbQPx+dict[SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠨࡵ࡬ࡾࡪ࠭௃")].split(Mmpr0o76iWJvz1kTtfgI8hES(u"ࠩࡻࠫ௄"))[qHYIWnOZLPkrQU]
			elif jWqKYXlEZzQ==vvWwO3Tx2dAgcijrFXq(u"ࠪࡺ࡮ࡪࡥࡰࠩ௅"):
				jWqKYXlEZzQ = shC5qBRV2A0lZ(u"࡛ࠫ࡯ࡤࡦࡱࠪெ")
				NUycq9VuGzi8k6x = F8Ef6K7kCy9mbQPx+dict[QQdAXWBc2GPw(u"ࠬࡹࡩࡻࡧࠪே")].split(RRIHDFjoW9w7bSfVPhC(u"࠭ࡸࠨை"))[qHYIWnOZLPkrQU]+k5bCDErUSmv+dict[BmePGjS7FxK6kutUM(u"ࠧࡧࡲࡶࠫ௉")]+LAQD5wEkr18bUiGaYen3J(u"ࠨࡨࡳࡷࠬொ")+k5bCDErUSmv+UYat1jqNzCdDlWGuPF60T9i
			elif jWqKYXlEZzQ==mQNonhS7CV2BXOv(u"ࠩࡤࡹࡩ࡯࡯ࠨோ"):
				jWqKYXlEZzQ = BmePGjS7FxK6kutUM(u"ࠪࡅࡺࡪࡩࡰࠩௌ")
				NUycq9VuGzi8k6x = F8Ef6K7kCy9mbQPx+str(int(dict[VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠫࡦࡻࡤࡪࡱࡢࡷࡦࡳࡰ࡭ࡧࡢࡶࡦࡺࡥࠨ்")])/BWNPxIG7vqdTy85pjHzUOrK3(u"࠶࠶࠰࠱෾"))+zI3ROAZtiUq42rE9WDST68(u"ࠬࡱࡨࡻࠢࠣࠫ௎")+dict[vvWwO3Tx2dAgcijrFXq(u"࠭ࡡࡶࡦ࡬ࡳࡤࡩࡨࡢࡰࡱࡩࡱࡹࠧ௏")]+yST5AHEfvPmcWpwGuh2BJ(u"ࠧࡤࡪࠪௐ")+k5bCDErUSmv+UYat1jqNzCdDlWGuPF60T9i
		except:
			yABitW02UXORGEJQPsTujcL = n9dSEJTBOWlY6.format_exc()
			if yABitW02UXORGEJQPsTujcL!=VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠨࡐࡲࡲࡪ࡚ࡹࡱࡧ࠽ࠤࡓࡵ࡮ࡦ࡞ࡱࠫ௑"): Pft6y0LvwSh48iYg7b.stderr.write(yABitW02UXORGEJQPsTujcL)
		if DYakr9g4PVU(u"ࠩࡧࡹࡷࡃࠧ௒") in dict[VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠪࡹࡷࡲࠧ௓")]: D5taEr6hnuFCcRMpTq4wSoyQOivx = round(QTUBCcehw6qPd4x(u"࠰࠯࠷฀")+float(dict[Xz3bA2PFENVCUtplu51(u"ࠫࡺࡸ࡬ࠨ௔")].split(zI3ROAZtiUq42rE9WDST68(u"ࠬࡪࡵࡳ࠿ࠪ௕"),UUkIBz1sgQ9WfNeG6trKXvu0(u"࠷෿"))[qHYIWnOZLPkrQU].split(zI3ROAZtiUq42rE9WDST68(u"࠭ࠦࠨ௖"),qHYIWnOZLPkrQU)[LzYQg91SIxDeOGtCKd5]))
		elif S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠧࡢࡲࡳࡶࡴࡾࡄࡶࡴࡤࡸ࡮ࡵ࡮ࡎࡵࠪௗ") in list(dict.keys()): D5taEr6hnuFCcRMpTq4wSoyQOivx = round(Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"࠱࠰࠸ก")+float(dict[TYf7Dc06PQgy1vEV9(u"ࠨࡣࡳࡴࡷࡵࡸࡅࡷࡵࡥࡹ࡯࡯࡯ࡏࡶࠫ௘")])/P0qdZI384LKleuo(u"࠳࠳࠴࠵ข"))
		else: D5taEr6hnuFCcRMpTq4wSoyQOivx = BmePGjS7FxK6kutUM(u"ࠩ࠳ࠫ௙")
		if kke1PDGRBLuY8y(u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ௚") not in list(dict.keys()): F8Ef6K7kCy9mbQPx = dict[BmePGjS7FxK6kutUM(u"ࠫࡸ࡯ࡺࡦࠩ௛")].split(TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠬࡾࠧ௜"))[qHYIWnOZLPkrQU]
		else: F8Ef6K7kCy9mbQPx = str(int(dict[ddo23ZJtgcY(u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ௝")])//mQNonhS7CV2BXOv(u"࠴࠴࠷࠺ฃ"))
		if LAQD5wEkr18bUiGaYen3J(u"ࠧࡪࡰ࡬ࡸࠬ௞") not in list(dict.keys()): dict[BWNPxIG7vqdTy85pjHzUOrK3(u"ࠨ࡫ࡱ࡭ࡹ࠭௟")] = shC5qBRV2A0lZ(u"ࠩ࠳࠱࠵࠭௠")
		dict[RRIHDFjoW9w7bSfVPhC(u"ࠪࡸ࡮ࡺ࡬ࡦࠩ௡")] = jWqKYXlEZzQ+QTUBCcehw6qPd4x(u"ࠫ࠿ࠦࠠࠨ௢")+NUycq9VuGzi8k6x+HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠬࠦࠠࠩࠩ௣")+R6Dpxibf4ZYOm+QTUBCcehw6qPd4x(u"࠭ࠬࠨ௤")+dict[zI3ROAZtiUq42rE9WDST68(u"ࠧࡪࡶࡤ࡫ࠬ௥")]+TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠨࠫࠪ௦")
		dict[mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠩࡴࡹࡦࡲࡩࡵࡻࠪ௧")] = NUycq9VuGzi8k6x.split(k5bCDErUSmv)[LzYQg91SIxDeOGtCKd5].split(mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠪ࡯ࡧࡶࡳࠨ௨"))[LzYQg91SIxDeOGtCKd5]
		dict[QTUBCcehw6qPd4x(u"ࠫࡹࡿࡰࡦ࠴ࠪ௩")] = jWqKYXlEZzQ
		dict[uVQd103XyvUce2EBtzbYaC(u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧ௪")] = UYat1jqNzCdDlWGuPF60T9i
		dict[Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"࠭ࡣࡰࡦࡨࡧࡸ࠭௫")] = swh5pH21Cix9flUKcZ
		dict[shC5qBRV2A0lZ(u"ࠧࡥࡷࡵࡥࡹ࡯࡯࡯ࠩ௬")] = D5taEr6hnuFCcRMpTq4wSoyQOivx
		dict[ddo23ZJtgcY(u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ௭")] = F8Ef6K7kCy9mbQPx
		HoBXvrcyAfWuP2T67.append(dict)
	nn3a2tVrz1w,PkiQuc2dAIOWgRB3alphnJx14GjS,iJevfYEwXx5Qtr,nEZthcMJambPvKy1Fgj7e2OY,lUarDPjqSG3yw9VWFYT4kboN2ue807 = [],[],[],[],[]
	ok0T7HxrVcsRhG5lDv28g9ytCq3mi,OQrbVk4vYlZN,b9zO7gL4QErKvYF,ZZAownKWVruJPsGlpC9D,Jgt5v3ybL2YhpNxHmjzAUekuB086O = [],[],[],[],[]
	for t5ORX2mjc7hQ in Af7ySpsQaZ16:
		if not t5ORX2mjc7hQ: continue
		dict = {}
		dict[mQNonhS7CV2BXOv(u"ࠩࡷࡽࡵ࡫࠲ࠨ௮")] = RRIHDFjoW9w7bSfVPhC(u"ࠪࡅ࠰࡜ࠧ௯")
		dict[ubxGUTt1LraKhVZgpAP(u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭௰")] = Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠬࡳࡰࡥࠩ௱")
		dict[LAQD5wEkr18bUiGaYen3J(u"࠭ࡴࡪࡶ࡯ࡩࠬ௲")] = dict[RRIHDFjoW9w7bSfVPhC(u"ࠧࡵࡻࡳࡩ࠷࠭௳")]+TYf7Dc06PQgy1vEV9(u"ࠨ࠼ࠣࠤࠬ௴")+dict[QQdAXWBc2GPw(u"ࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠫ௵")]+k5bCDErUSmv+IjZbnrBJmM2N(u"ࠪะํีษࠡาๆ๎ฮ࠭௶")
		dict[Nh0BWuiSndf(u"ࠫࡺࡸ࡬ࠨ௷")] = t5ORX2mjc7hQ
		dict[m6hwdgP31a2zjN7lkpX(u"ࠬࡷࡵࡢ࡮࡬ࡸࡾ࠭௸")] = LAQD5wEkr18bUiGaYen3J(u"࠭࠰ࠨ௹")
		dict[BmePGjS7FxK6kutUM(u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ௺")] = UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠨ࠳࠴࠵࠷࠸࠲࠴࠵࠶ࠫ௻")
		HoBXvrcyAfWuP2T67.append(dict)
	for ssl2FNVvpKQdAIEWt4rx7Li in xbmCyiNsz9RBMwhWXLT:
		if not ssl2FNVvpKQdAIEWt4rx7Li: continue
		e1ZYt4vdj9MuD2oBWVhXPNnRrzIpiK,OeHG3j8TyFDJC = TTO3ZpWq9FCzhuMAY0RdaDIfX5kw(QQ8pvXNcBfVkP5rRJ7o,ssl2FNVvpKQdAIEWt4rx7Li)
		hWdUVy4lXevroSn7HFmgN6 = list(zip(e1ZYt4vdj9MuD2oBWVhXPNnRrzIpiK,OeHG3j8TyFDJC))
		for title,pcA1dzy7LXwGfMPg9mTkuh5tine3 in hWdUVy4lXevroSn7HFmgN6:
			dict = {}
			dict[SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠩࡷࡽࡵ࡫࠲ࠨ௼")] = S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠪࡅ࠰࡜ࠧ௽")
			dict[IjZbnrBJmM2N(u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭௾")] = kke1PDGRBLuY8y(u"ࠬࡳ࠳ࡶ࠺ࠪ௿")
			dict[zI3ROAZtiUq42rE9WDST68(u"࠭ࡵࡳ࡮ࠪఀ")] = pcA1dzy7LXwGfMPg9mTkuh5tine3
			if BWNPxIG7vqdTy85pjHzUOrK3(u"ࠧ࡬ࡤࡳࡷࠬఁ") in title: dict[Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩం")] = title.split(TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠩ࡮ࡦࡵࡹࠧః"))[LzYQg91SIxDeOGtCKd5].rsplit(k5bCDErUSmv)[-qHYIWnOZLPkrQU]
			else: dict[yST5AHEfvPmcWpwGuh2BJ(u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫఄ")] = BmePGjS7FxK6kutUM(u"ࠫ࠶࠶ࠧఅ")
			if title.count(k5bCDErUSmv)>qHYIWnOZLPkrQU:
				c1EdszLx3mkb8QYX9 = title.rsplit(k5bCDErUSmv)[-VwApyDY1Jc]
				if c1EdszLx3mkb8QYX9.isdigit(): dict[Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠬࡷࡵࡢ࡮࡬ࡸࡾ࠭ఆ")] = c1EdszLx3mkb8QYX9
				else: dict[uVQd103XyvUce2EBtzbYaC(u"࠭ࡱࡶࡣ࡯࡭ࡹࡿࠧఇ")] = Nh0BWuiSndf(u"ࠧ࠱࠲࠳࠴ࠬఈ")
			if title==Nh0BWuiSndf(u"ࠨ࠯࠴ࠫఉ"): dict[TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠩࡷ࡭ࡹࡲࡥࠨఊ")] = dict[DYakr9g4PVU(u"ࠪࡸࡾࡶࡥ࠳ࠩఋ")]+P0qdZI384LKleuo(u"ࠫ࠿ࠦࠠࠨఌ")+dict[IjZbnrBJmM2N(u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧ఍")]+k5bCDErUSmv+IjZbnrBJmM2N(u"࠭ฬ้ัฬࠤี้๊สࠩఎ")
			else: dict[m6hwdgP31a2zjN7lkpX(u"ࠧࡵ࡫ࡷࡰࡪ࠭ఏ")] = dict[vvWwO3Tx2dAgcijrFXq(u"ࠨࡶࡼࡴࡪ࠸ࠧఐ")]+BmePGjS7FxK6kutUM(u"ࠩ࠽ࠤࠥ࠭఑")+dict[UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠪࡪ࡮ࡲࡥࡵࡻࡳࡩࠬఒ")]+k5bCDErUSmv+dict[LAQD5wEkr18bUiGaYen3J(u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬఓ")]+IjZbnrBJmM2N(u"ࠬࡱࡢࡱࡵࠣࠤࠬఔ")+dict[S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"࠭ࡱࡶࡣ࡯࡭ࡹࡿࠧక")]
			HoBXvrcyAfWuP2T67.append(dict)
	HoBXvrcyAfWuP2T67 = sorted(HoBXvrcyAfWuP2T67,reverse=CCxMXuNUEzolDZTKrBJ,key=lambda key: int(key[yST5AHEfvPmcWpwGuh2BJ(u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨఖ")]))
	if not HoBXvrcyAfWuP2T67:
		if not jLtdbeYiQHnf4SpU2MTly:
			b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(nCUMfrlZvuiLe5x,kke1PDGRBLuY8y(u"ࠨࡉࡈࡘࠬగ"),MUJCtfYVBLODrFbaZn,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,Mmpr0o76iWJvz1kTtfgI8hES(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡟ࡏࡖࡖࡘࡆࡊ࠳࠷ࡵࡪࠪఘ"))
			jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
		FSpIEkeP1D3ai4VZ5oB92zhy = YYBlm36zd0Jst18LXwo4.findall(IjZbnrBJmM2N(u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡱࡪࡹࡳࡢࡩࡨࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ఙ"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		eqURlBsy0m82xwA = YYBlm36zd0Jst18LXwo4.findall(shC5qBRV2A0lZ(u"ࠫࠧࡶ࡬ࡢࡻࡨࡶࡊࡸࡲࡰࡴࡐࡩࡸࡹࡡࡨࡧࡕࡩࡳࡪࡥࡳࡧࡵࠦ࠿ࡢࡻࠣࡵࡸࡦࡷ࡫ࡡࡴࡱࡱࠦ࠿ࡢࡻࠣࡴࡸࡲࡸࠨ࠺࡝࡝࡟ࡿࠧࡺࡥࡹࡶࡷࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭చ"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		zzi8PC6qjXNa5hBw = YYBlm36zd0Jst18LXwo4.findall(BmePGjS7FxK6kutUM(u"ࠬࠨࡰ࡭ࡣࡼࡩࡷࡋࡲࡳࡱࡵࡑࡪࡹࡳࡢࡩࡨࡖࡪࡴࡤࡦࡴࡨࡶࠧࡀ࡜ࡼࠤࡵࡩࡦࡹ࡯࡯ࠤ࠽ࡿࠧࡹࡩ࡮ࡲ࡯ࡩ࡙࡫ࡸࡵࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫఛ"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		xVzSyEukoGicNQs18elLm = YYBlm36zd0Jst18LXwo4.findall(dDYUoKi6JFM23p(u"࠭ࠢࡱ࡮ࡤࡽࡪࡸࡅࡳࡴࡲࡶࡒ࡫ࡳࡴࡣࡪࡩࡗ࡫࡮ࡥࡧࡵࡩࡷࠨ࠺࡝ࡽࠥࡷࡺࡨࡲࡦࡣࡶࡳࡳࠨ࠺ࡼࠤࡶ࡭ࡲࡶ࡬ࡦࡖࡨࡼࡹࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨజ"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		KZSi3W4l8QrDbUHtBFduz6,y7LeYsCOjVoltIN,RwiC8F5Bet4XcGU = b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv
		try: KZSi3W4l8QrDbUHtBFduz6 = ZMNRKClQqtSFpj5A0z1caoInVD[m6hwdgP31a2zjN7lkpX(u"ࠧࡱ࡮ࡤࡽࡦࡨࡩ࡭࡫ࡷࡽࡘࡺࡡࡵࡷࡶࠫఝ")][TYf7Dc06PQgy1vEV9(u"ࠨࡧࡵࡶࡴࡸࡓࡤࡴࡨࡩࡳ࠭ఞ")][DYakr9g4PVU(u"ࠩࡦࡳࡳ࡬ࡩࡳ࡯ࡇ࡭ࡦࡲ࡯ࡨࡔࡨࡲࡩ࡫ࡲࡦࡴࠪట")][Mmpr0o76iWJvz1kTtfgI8hES(u"ࠪࡸ࡮ࡺ࡬ࡦࠩఠ")][Mmpr0o76iWJvz1kTtfgI8hES(u"ࠫࡷࡻ࡮ࡴࠩడ")][LzYQg91SIxDeOGtCKd5][P0qdZI384LKleuo(u"ࠬࡺࡥࡹࡶࡷࠫఢ")]
		except:
			try: KZSi3W4l8QrDbUHtBFduz6 = OQXvFDYNboBAfUKCcpa7I5yHu[BmePGjS7FxK6kutUM(u"࠭ࡰ࡭ࡣࡼࡥࡧ࡯࡬ࡪࡶࡼࡗࡹࡧࡴࡶࡵࠪణ")][Nh0BWuiSndf(u"ࠧࡦࡴࡵࡳࡷ࡙ࡣࡳࡧࡨࡲࠬత")][UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠨࡥࡲࡲ࡫࡯ࡲ࡮ࡆ࡬ࡥࡱࡵࡧࡓࡧࡱࡨࡪࡸࡥࡳࠩథ")][S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠩࡷ࡭ࡹࡲࡥࠨద")][Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠪࡶࡺࡴࡳࠨధ")][LzYQg91SIxDeOGtCKd5][RRIHDFjoW9w7bSfVPhC(u"ࠫࡹ࡫ࡸࡵࡶࠪన")]
			except: pass
		try: y7LeYsCOjVoltIN = ZMNRKClQqtSFpj5A0z1caoInVD[BmePGjS7FxK6kutUM(u"ࠬࡶ࡬ࡢࡻࡤࡦ࡮ࡲࡩࡵࡻࡖࡸࡦࡺࡵࡴࠩ఩")][HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"࠭ࡥࡳࡴࡲࡶࡘࡩࡲࡦࡧࡱࠫప")][BmePGjS7FxK6kutUM(u"ࠧࡤࡱࡱࡪ࡮ࡸ࡭ࡅ࡫ࡤࡰࡴ࡭ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨఫ")][BmePGjS7FxK6kutUM(u"ࠨࡦ࡬ࡥࡱࡵࡧࡎࡧࡶࡷࡦ࡭ࡥࡴࠩబ")][LzYQg91SIxDeOGtCKd5][mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠩࡵࡹࡳࡹࠧభ")][LzYQg91SIxDeOGtCKd5][BmePGjS7FxK6kutUM(u"ࠪࡸࡪࡾࡴࡵࠩమ")]
		except:
			try: y7LeYsCOjVoltIN = OQXvFDYNboBAfUKCcpa7I5yHu[Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠫࡵࡲࡡࡺࡣࡥ࡭ࡱ࡯ࡴࡺࡕࡷࡥࡹࡻࡳࠨయ")][QQdAXWBc2GPw(u"ࠬ࡫ࡲࡳࡱࡵࡗࡨࡸࡥࡦࡰࠪర")][QQdAXWBc2GPw(u"࠭ࡣࡰࡰࡩ࡭ࡷࡳࡄࡪࡣ࡯ࡳ࡬ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧఱ")][ddo23ZJtgcY(u"ࠧࡥ࡫ࡤࡰࡴ࡭ࡍࡦࡵࡶࡥ࡬࡫ࡳࠨల")][LzYQg91SIxDeOGtCKd5][mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠨࡴࡸࡲࡸ࠭ళ")][LzYQg91SIxDeOGtCKd5][m6hwdgP31a2zjN7lkpX(u"ࠩࡷࡩࡽࡺࡴࠨఴ")]
			except: pass
		try: RwiC8F5Bet4XcGU = ZMNRKClQqtSFpj5A0z1caoInVD[vvWwO3Tx2dAgcijrFXq(u"ࠪࡴࡱࡧࡹࡢࡤ࡬ࡰ࡮ࡺࡹࡔࡶࡤࡸࡺࡹࠧవ")][BmePGjS7FxK6kutUM(u"ࠫࡷ࡫ࡡࡴࡱࡱࠫశ")]
		except:
			try: RwiC8F5Bet4XcGU = OQXvFDYNboBAfUKCcpa7I5yHu[Xz3bA2PFENVCUtplu51(u"ࠬࡶ࡬ࡢࡻࡤࡦ࡮ࡲࡩࡵࡻࡖࡸࡦࡺࡵࡴࠩష")][QTUBCcehw6qPd4x(u"࠭ࡲࡦࡣࡶࡳࡳ࠭స")]
			except: pass
		if FSpIEkeP1D3ai4VZ5oB92zhy or eqURlBsy0m82xwA or zzi8PC6qjXNa5hBw or xVzSyEukoGicNQs18elLm or KZSi3W4l8QrDbUHtBFduz6 or y7LeYsCOjVoltIN or RwiC8F5Bet4XcGU:
			if   FSpIEkeP1D3ai4VZ5oB92zhy: A4gdSTQDP2FyBIVuba85RvYqKU = FSpIEkeP1D3ai4VZ5oB92zhy[LzYQg91SIxDeOGtCKd5]
			elif eqURlBsy0m82xwA: A4gdSTQDP2FyBIVuba85RvYqKU = eqURlBsy0m82xwA[LzYQg91SIxDeOGtCKd5]
			elif zzi8PC6qjXNa5hBw: A4gdSTQDP2FyBIVuba85RvYqKU = zzi8PC6qjXNa5hBw[LzYQg91SIxDeOGtCKd5]
			elif xVzSyEukoGicNQs18elLm: A4gdSTQDP2FyBIVuba85RvYqKU = xVzSyEukoGicNQs18elLm[LzYQg91SIxDeOGtCKd5]
			elif KZSi3W4l8QrDbUHtBFduz6: A4gdSTQDP2FyBIVuba85RvYqKU = KZSi3W4l8QrDbUHtBFduz6
			elif y7LeYsCOjVoltIN: A4gdSTQDP2FyBIVuba85RvYqKU = y7LeYsCOjVoltIN
			elif RwiC8F5Bet4XcGU: A4gdSTQDP2FyBIVuba85RvYqKU = RwiC8F5Bet4XcGU
			RGFjLIchVeQbP4DOsWAf = A4gdSTQDP2FyBIVuba85RvYqKU.replace(eeN6dTEnkJxI,b8Qe150xVaJsnDSv).strip(pldxivXC5wbTB2O8q)
			zAYTHphuNXSGQwRBWFlceUm5OJ1Lx = rC3Tlno96KjLDIvBaSWUbR8+S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"่ࠧาสࠤฬ๊แ๋ัํ์ࠥ็ุ๊่่่๊ࠢษࠡ࠰࠱ࠤศ๎ࠠ฻์ิࠤ๊๊วว็่ࠣอ฿ึࠡษ็ุ้ะฮะ็ํ๊ࠥ࠴࠮ࠡล๋ࠤ฿๐ัࠡ็อ์ๆืࠠศๆล๊ࠥ࠴࠮ࠡล๋ࠤ๏๎ส๋๊หࠤ๏ำสศฮุࠣ๏วࠠๆฯาำࠥ࠴࠮ࠡล๋ࠤ๏๎ส๋๊หࠤ฿๐ัࠡไสำึࠦร็ࠢํุ฿๊ࠠศๆไ๎ิ๐่ࠡษ็ฦ๋࠭హ")+hAIp8kmC36T5WFPMSXOwnNbtD
			tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,uVQd103XyvUce2EBtzbYaC(u"ࠨำึห้ฯࠠๆ่ࠣห้๋่ใ฻ࠣ์ฬ๊ๅษำ่ะࠬ఺"),zAYTHphuNXSGQwRBWFlceUm5OJ1Lx+kke1PDGRBLuY8y(u"ࠩ࡟ࡲࡡࡴࠧ఻")+OkuB9nwhD8U1+shC5qBRV2A0lZ(u"ࠪีุอไส่๊ࠢࠥ๐่ห์๋ฬ఼ࠬ")+hAIp8kmC36T5WFPMSXOwnNbtD+eeN6dTEnkJxI+RGFjLIchVeQbP4DOsWAf)
			return shC5qBRV2A0lZ(u"ࠫࡊࡸࡲࡰࡴࠣࠤࠥࠦ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣ࡝ࡔ࡛ࡔࡖࡄࡈࠤࡋࡧࡩ࡭ࡧࡧ࠾ࠥ࠭ఽ")+RGFjLIchVeQbP4DOsWAf,[],[]
		else: return uVQd103XyvUce2EBtzbYaC(u"ࠬࡋࡲࡳࡱࡵࠤࠥࠦࠠ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤ࡞ࡕࡕࡕࡗࡅࡉࠥࡌࡡࡪ࡮ࡨࡨࠬా"),[],[]
	t8I97woPTViq0sSuU = []
	for dict in HoBXvrcyAfWuP2T67:
		if dict[P0qdZI384LKleuo(u"࠭ࡴࡺࡲࡨ࠶ࠬి")]==S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠧࡗ࡫ࡧࡩࡴ࠭ీ"):
			nn3a2tVrz1w.append(dict[ddo23ZJtgcY(u"ࠨࡶ࡬ࡸࡱ࡫ࠧు")])
			ok0T7HxrVcsRhG5lDv28g9ytCq3mi.append(dict)
		elif dict[VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠩࡷࡽࡵ࡫࠲ࠨూ")]==shC5qBRV2A0lZ(u"ࠪࡅࡺࡪࡩࡰࠩృ"):
			PkiQuc2dAIOWgRB3alphnJx14GjS.append(dict[Mmpr0o76iWJvz1kTtfgI8hES(u"ࠫࡹ࡯ࡴ࡭ࡧࠪౄ")])
			OQrbVk4vYlZN.append(dict)
		elif dict[uVQd103XyvUce2EBtzbYaC(u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧ౅")]==DYakr9g4PVU(u"࠭࡭ࡱࡦࠪె"):
			title = dict[RRIHDFjoW9w7bSfVPhC(u"ࠧࡵ࡫ࡷࡰࡪ࠭ే")].replace(VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠨࡃ࠮࡚࠿ࠦࠠࠨై"),b8Qe150xVaJsnDSv)
			if Xz3bA2PFENVCUtplu51(u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ౉") not in list(dict.keys()): F8Ef6K7kCy9mbQPx = RRIHDFjoW9w7bSfVPhC(u"ࠪ࠴ࠬొ")
			else: F8Ef6K7kCy9mbQPx = dict[IjZbnrBJmM2N(u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬో")]
			t8I97woPTViq0sSuU.append([dict,{},title,F8Ef6K7kCy9mbQPx])
		else:
			title = dict[uVQd103XyvUce2EBtzbYaC(u"ࠬࡺࡩࡵ࡮ࡨࠫౌ")].replace(Xz3bA2PFENVCUtplu51(u"࠭ࡁࠬࡘ࠽ࠤ్ࠥ࠭"),b8Qe150xVaJsnDSv)
			if BmePGjS7FxK6kutUM(u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ౎") not in list(dict.keys()): F8Ef6K7kCy9mbQPx = Xz3bA2PFENVCUtplu51(u"ࠨ࠲ࠪ౏")
			else: F8Ef6K7kCy9mbQPx = dict[HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ౐")]
			t8I97woPTViq0sSuU.append([dict,{},title,F8Ef6K7kCy9mbQPx])
			iJevfYEwXx5Qtr.append(title)
			b9zO7gL4QErKvYF.append(dict)
		cDqdP0wzoe95fQUFpN = CCxMXuNUEzolDZTKrBJ
		if Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠪࡧࡴࡪࡥࡤࡵࠪ౑") in list(dict.keys()):
			if Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠫࡦࡼ࠰ࠨ౒") in dict[Nh0BWuiSndf(u"ࠬࡩ࡯ࡥࡧࡦࡷࠬ౓")]: cDqdP0wzoe95fQUFpN = DD5cFIejQa2X4BgAu9GWPyJ3tC7
			elif g1gmkxOtc2oeEZHhBiy<VFjQx6Is28KvzLOmMXtg4GqTwa3(u"࠵࠽ค") and dDYUoKi6JFM23p(u"࠭ࡡࡷࡥࠪ౔") not in dict[Nh0BWuiSndf(u"ࠧࡤࡱࡧࡩࡨࡹౕࠧ")] and RRIHDFjoW9w7bSfVPhC(u"ࠨ࡯ࡳ࠸ࡦౖ࠭") not in dict[LAQD5wEkr18bUiGaYen3J(u"ࠩࡦࡳࡩ࡫ࡣࡴࠩ౗")]: cDqdP0wzoe95fQUFpN = DD5cFIejQa2X4BgAu9GWPyJ3tC7
		if cDqdP0wzoe95fQUFpN and dict[Mmpr0o76iWJvz1kTtfgI8hES(u"ࠪࡸࡾࡶࡥ࠳ࠩౘ")]==TYf7Dc06PQgy1vEV9(u"࡛ࠫ࡯ࡤࡦࡱࠪౙ") and dict[LAQD5wEkr18bUiGaYen3J(u"ࠬ࡯࡮ࡪࡶࠪౚ")]!=Xz3bA2PFENVCUtplu51(u"࠭࠰࠮࠲ࠪ౛"):
			lUarDPjqSG3yw9VWFYT4kboN2ue807.append(dict[ddo23ZJtgcY(u"ࠧࡵ࡫ࡷࡰࡪ࠭౜")])
			Jgt5v3ybL2YhpNxHmjzAUekuB086O.append(dict)
		elif cDqdP0wzoe95fQUFpN and dict[QTUBCcehw6qPd4x(u"ࠨࡶࡼࡴࡪ࠸ࠧౝ")]==SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠩࡄࡹࡩ࡯࡯ࠨ౞") and dict[HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠪ࡭ࡳ࡯ࡴࠨ౟")]!=Xz3bA2PFENVCUtplu51(u"ࠫ࠵࠳࠰ࠨౠ"):
			nEZthcMJambPvKy1Fgj7e2OY.append(dict[uVQd103XyvUce2EBtzbYaC(u"ࠬࡺࡩࡵ࡮ࡨࠫౡ")])
			ZZAownKWVruJPsGlpC9D.append(dict)
	for wwYEcv2MXFSto5W in ZZAownKWVruJPsGlpC9D:
		UysxPzmAI2F = wwYEcv2MXFSto5W[Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧౢ")]
		for RuKk3o8UAVf in Jgt5v3ybL2YhpNxHmjzAUekuB086O:
			FwHixl20keRr9a = RuKk3o8UAVf[mQNonhS7CV2BXOv(u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨౣ")]
			F8Ef6K7kCy9mbQPx = int(FwHixl20keRr9a)+int(UysxPzmAI2F)
			title = RuKk3o8UAVf[Xz3bA2PFENVCUtplu51(u"ࠨࡶ࡬ࡸࡱ࡫ࠧ౤")].replace(TYf7Dc06PQgy1vEV9(u"࡙ࠩ࡭ࡩ࡫࡯࠻ࠢࠣࠫ౥"),mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠪࡱࡵࡪࠠࠡࠩ౦"))
			title = title.replace(RuKk3o8UAVf[BWNPxIG7vqdTy85pjHzUOrK3(u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭౧")]+k5bCDErUSmv,b8Qe150xVaJsnDSv)
			title = title.replace(FwHixl20keRr9a+Nh0BWuiSndf(u"ࠬࡱࡢࡱࡵࠪ౨"),str(F8Ef6K7kCy9mbQPx)+Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"࠭࡫ࡣࡲࡶࠫ౩"))
			title = title+Mmpr0o76iWJvz1kTtfgI8hES(u"ࠧࠩࠩ౪")+wwYEcv2MXFSto5W[yST5AHEfvPmcWpwGuh2BJ(u"ࠨࡶ࡬ࡸࡱ࡫ࠧ౫")].split(Xz3bA2PFENVCUtplu51(u"ࠩࠫࠫ౬"),qHYIWnOZLPkrQU)[qHYIWnOZLPkrQU]
			t8I97woPTViq0sSuU.append([RuKk3o8UAVf,wwYEcv2MXFSto5W,title,F8Ef6K7kCy9mbQPx])
	Pqlk63Vse8RUBr4hMLoI9EmKfNaOp = []
	for stream in t8I97woPTViq0sSuU:
		RuKk3o8UAVf,wwYEcv2MXFSto5W,title,F8Ef6K7kCy9mbQPx = stream
		XjgdBvZ314FVfHixUAo6IyElPMm = title[:VwApyDY1Jc]
		if Nh0BWuiSndf(u"ࠪิ่๐ษࠨ౭") in title: XjgdBvZ314FVfHixUAo6IyElPMm += ddo23ZJtgcY(u"ࠫ࠰࠭౮")
		Pqlk63Vse8RUBr4hMLoI9EmKfNaOp.append([stream,XjgdBvZ314FVfHixUAo6IyElPMm,int(F8Ef6K7kCy9mbQPx)])
	tHAuxmS0frDiV972XYvBj = DD5cFIejQa2X4BgAu9GWPyJ3tC7
	QqBCR7wJfkKiErAhaX = NBzFpYl7jSk(QQ8pvXNcBfVkP5rRJ7o,Pqlk63Vse8RUBr4hMLoI9EmKfNaOp)
	if QqBCR7wJfkKiErAhaX:
		wp65iz1CU2obEh0Nv49GP,M43BelyLOJ8m9PafGsXI7UR6iWg,title,F8Ef6K7kCy9mbQPx = QqBCR7wJfkKiErAhaX[yST5AHEfvPmcWpwGuh2BJ(u"࠵ฅ")][yST5AHEfvPmcWpwGuh2BJ(u"࠵ฅ")]
		v5r8wqFZ2KE9QtdHmp0S = wp65iz1CU2obEh0Nv49GP[m6hwdgP31a2zjN7lkpX(u"ࠬࡻࡲ࡭ࠩ౯")]
		if kke1PDGRBLuY8y(u"࠭࡭ࡱࡦࠪ౰") in title and v5r8wqFZ2KE9QtdHmp0S!=t5ORX2mjc7hQ: tHAuxmS0frDiV972XYvBj = CCxMXuNUEzolDZTKrBJ
		AUes5cIdauyQ = title
	else:
		ZBk9UfqF5VhK = NBzFpYl7jSk(QQ8pvXNcBfVkP5rRJ7o,Pqlk63Vse8RUBr4hMLoI9EmKfNaOp,Xz3bA2PFENVCUtplu51(u"࠷࠵࠱࠲ฆ"))
		ZBk9UfqF5VhK,wzvqmAXSp8WY9KHEJfcRoZ6ax,EERoCcutFWJ8Y613S = zip(*ZBk9UfqF5VhK)
		X8AkflVW10rTaCv4,JR7segUDbIHtPrvKLAiCMxq5pF1YhE,jnz2DgQ8Z4VJdLrcEoux0h9 = [],[],LzYQg91SIxDeOGtCKd5
		t8I97woPTViq0sSuU = sorted(t8I97woPTViq0sSuU, reverse=CCxMXuNUEzolDZTKrBJ, key=lambda key: float(key[VwApyDY1Jc]))
		IW6sw9pPOoLNFYSMxbBrg,WJnU60Q3xtK7DuohqjT,o4dRu8wy3XcWBUpf = b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv
		try: IW6sw9pPOoLNFYSMxbBrg = ZMNRKClQqtSFpj5A0z1caoInVD[TYf7Dc06PQgy1vEV9(u"ࠧࡷ࡫ࡧࡩࡴࡊࡥࡵࡣ࡬ࡰࡸ࠭౱")][TYf7Dc06PQgy1vEV9(u"ࠨࡣࡸࡸ࡭ࡵࡲࠨ౲")]
		except:
			try: IW6sw9pPOoLNFYSMxbBrg = OQXvFDYNboBAfUKCcpa7I5yHu[Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠩࡹ࡭ࡩ࡫࡯ࡅࡧࡷࡥ࡮ࡲࡳࠨ౳")][kke1PDGRBLuY8y(u"ࠪࡥࡺࡺࡨࡰࡴࠪ౴")]
			except: pass
		try: WJnU60Q3xtK7DuohqjT = ZMNRKClQqtSFpj5A0z1caoInVD[LAQD5wEkr18bUiGaYen3J(u"ࠫࡻ࡯ࡤࡦࡱࡇࡩࡹࡧࡩ࡭ࡵࠪ౵")][VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠬࡩࡨࡢࡰࡱࡩࡱࡏࡤࠨ౶")]
		except:
			try: WJnU60Q3xtK7DuohqjT = OQXvFDYNboBAfUKCcpa7I5yHu[QTUBCcehw6qPd4x(u"࠭ࡶࡪࡦࡨࡳࡉ࡫ࡴࡢ࡫࡯ࡷࠬ౷")][P0qdZI384LKleuo(u"ࠧࡤࡪࡤࡲࡳ࡫࡬ࡊࡦࠪ౸")]
			except: pass
		if IW6sw9pPOoLNFYSMxbBrg and WJnU60Q3xtK7DuohqjT:
			jnz2DgQ8Z4VJdLrcEoux0h9 += qHYIWnOZLPkrQU
			title = rC3Tlno96KjLDIvBaSWUbR8+zI3ROAZtiUq42rE9WDST68(u"ࠨࡑ࡚ࡒࡊࡘ࠺ࠡࠢࠪ౹")+IW6sw9pPOoLNFYSMxbBrg+hAIp8kmC36T5WFPMSXOwnNbtD
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = nTHXJIiah2qK[Nh0BWuiSndf(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪ౺")][LzYQg91SIxDeOGtCKd5]+HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠪ࠳ࡨ࡮ࡡ࡯ࡰࡨࡰ࠴࠭౻")+WJnU60Q3xtK7DuohqjT
			X8AkflVW10rTaCv4.append(title)
			JR7segUDbIHtPrvKLAiCMxq5pF1YhE.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
			try: o4dRu8wy3XcWBUpf = ZMNRKClQqtSFpj5A0z1caoInVD[Nh0BWuiSndf(u"ࠫࡻ࡯ࡤࡦࡱࡇࡩࡹࡧࡩ࡭ࡵࠪ౼")][BmePGjS7FxK6kutUM(u"ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࠨ౽")][Xz3bA2PFENVCUtplu51(u"࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡵࠪ౾")][-qHYIWnOZLPkrQU][kke1PDGRBLuY8y(u"ࠧࡶࡴ࡯ࠫ౿")]
			except:
				try: o4dRu8wy3XcWBUpf = OQXvFDYNboBAfUKCcpa7I5yHu[BmePGjS7FxK6kutUM(u"ࠨࡸ࡬ࡨࡪࡵࡄࡦࡶࡤ࡭ࡱࡹࠧಀ")][Mmpr0o76iWJvz1kTtfgI8hES(u"ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࠬಁ")][S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡹࠧಂ")][-qHYIWnOZLPkrQU][HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠫࡺࡸ࡬ࠨಃ")]
				except: pass
		for RuKk3o8UAVf,wwYEcv2MXFSto5W,title,F8Ef6K7kCy9mbQPx in ZBk9UfqF5VhK:
			X8AkflVW10rTaCv4.append(title) ; JR7segUDbIHtPrvKLAiCMxq5pF1YhE.append(QTUBCcehw6qPd4x(u"ࠬ࡮ࡩࡨࡪࡨࡷࡹ࠭಄"))
		if iJevfYEwXx5Qtr: X8AkflVW10rTaCv4.append(uVQd103XyvUce2EBtzbYaC(u"࠭ี้ำฬࠤํ฻่ห่ࠢัิีษࠨಅ")) ; JR7segUDbIHtPrvKLAiCMxq5pF1YhE.append(VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠧ࡮ࡷࡻࡩࡩ࠭ಆ"))
		if t8I97woPTViq0sSuU: X8AkflVW10rTaCv4.append(ddo23ZJtgcY(u"ࠨื๋ีฮ่ࠦึ๊อࠤฬ๊ๅห๊ไีࠬಇ")) ; JR7segUDbIHtPrvKLAiCMxq5pF1YhE.append(ddo23ZJtgcY(u"ࠩࡤࡰࡱ࠭ಈ"))
		if lUarDPjqSG3yw9VWFYT4kboN2ue807: X8AkflVW10rTaCv4.append(dDYUoKi6JFM23p(u"ࠪหำะัࠡษ็ูํืษ๊ࠡสฺ่๎สࠨಉ")) ; JR7segUDbIHtPrvKLAiCMxq5pF1YhE.append(UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠫࡲࡶࡤࠨಊ"))
		if nn3a2tVrz1w: X8AkflVW10rTaCv4.append(m6hwdgP31a2zjN7lkpX(u"ࠬ฻่าหࠣฬิ๎ๆࠡื๋ฮࠬಋ")) ; JR7segUDbIHtPrvKLAiCMxq5pF1YhE.append(Mmpr0o76iWJvz1kTtfgI8hES(u"࠭ࡶࡪࡦࡨࡳࠬಌ"))
		if PkiQuc2dAIOWgRB3alphnJx14GjS: X8AkflVW10rTaCv4.append(Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠧึ๊อࠤอี่็ุࠢ์ึฯࠧ಍")) ; JR7segUDbIHtPrvKLAiCMxq5pF1YhE.append(Nh0BWuiSndf(u"ࠨࡣࡸࡨ࡮ࡵࠧಎ"))
		while CCxMXuNUEzolDZTKrBJ:
			cMZGTsAR2E = XXprCMzuNP2mElUxfdA(hDb03znZRCBs8M, X8AkflVW10rTaCv4)
			if cMZGTsAR2E==-qHYIWnOZLPkrQU: return vvWwO3Tx2dAgcijrFXq(u"ࠩࡈ࡜ࡎ࡚࡟ࡂࡎࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧಏ"),[],[]
			elif cMZGTsAR2E==LzYQg91SIxDeOGtCKd5 and IW6sw9pPOoLNFYSMxbBrg:
				pcA1dzy7LXwGfMPg9mTkuh5tine3 = JR7segUDbIHtPrvKLAiCMxq5pF1YhE[cMZGTsAR2E]
				KcilsSDN8VIo7PF = Pft6y0LvwSh48iYg7b.argv[LzYQg91SIxDeOGtCKd5]+mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠪࡃࡹࡿࡰࡦ࠿ࡩࡳࡱࡪࡥࡳࠨࡰࡳࡩ࡫࠽࠲࠶࠴ࠪࡳࡧ࡭ࡦ࠿ࠪಐ")+HHbaVYqFRy6v0c(IW6sw9pPOoLNFYSMxbBrg)+QQdAXWBc2GPw(u"ࠫࠫࡻࡲ࡭࠿ࠪ಑")+pcA1dzy7LXwGfMPg9mTkuh5tine3
				if o4dRu8wy3XcWBUpf: KcilsSDN8VIo7PF = KcilsSDN8VIo7PF+QQdAXWBc2GPw(u"ࠬࠬࡩ࡮ࡣࡪࡩࡂ࠭ಒ")+HHbaVYqFRy6v0c(o4dRu8wy3XcWBUpf)
				uuxVm0bTwdnCUAL4s6NKHEBF3M.executebuiltin(LAQD5wEkr18bUiGaYen3J(u"ࠨࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡘࡴࡩࡧࡴࡦࠪࠥಓ")+KcilsSDN8VIo7PF+kke1PDGRBLuY8y(u"ࠢࠪࠤಔ"))
				return TYf7Dc06PQgy1vEV9(u"ࠨࡇ࡛ࡍ࡙ࡥࡁࡍࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ಕ"),[],[]
			c9Wbh7raCVlyPKqpL6GwNZz1u = JR7segUDbIHtPrvKLAiCMxq5pF1YhE[cMZGTsAR2E]
			AUes5cIdauyQ = X8AkflVW10rTaCv4[cMZGTsAR2E]
			if c9Wbh7raCVlyPKqpL6GwNZz1u==S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠩࡧࡥࡸ࡮ࠧಖ"):
				v5r8wqFZ2KE9QtdHmp0S = t5ORX2mjc7hQ
				break
			elif c9Wbh7raCVlyPKqpL6GwNZz1u in [kke1PDGRBLuY8y(u"ࠪࡥࡺࡪࡩࡰࠩಗ"),mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠫࡻ࡯ࡤࡦࡱࠪಘ"),yST5AHEfvPmcWpwGuh2BJ(u"ࠬࡳࡵࡹࡧࡧࠫಙ")]:
				if c9Wbh7raCVlyPKqpL6GwNZz1u==ubxGUTt1LraKhVZgpAP(u"࠭࡭ࡶࡺࡨࡨࠬಚ"): uuSKUinvP4EGLxWZYmTsF,byVMDdio5JFRjZS = iJevfYEwXx5Qtr,b9zO7gL4QErKvYF
				elif c9Wbh7raCVlyPKqpL6GwNZz1u==ubxGUTt1LraKhVZgpAP(u"ࠧࡷ࡫ࡧࡩࡴ࠭ಛ"): uuSKUinvP4EGLxWZYmTsF,byVMDdio5JFRjZS = nn3a2tVrz1w,ok0T7HxrVcsRhG5lDv28g9ytCq3mi
				elif c9Wbh7raCVlyPKqpL6GwNZz1u==BWNPxIG7vqdTy85pjHzUOrK3(u"ࠨࡣࡸࡨ࡮ࡵࠧಜ"): uuSKUinvP4EGLxWZYmTsF,byVMDdio5JFRjZS = PkiQuc2dAIOWgRB3alphnJx14GjS,OQrbVk4vYlZN
				cMZGTsAR2E = XXprCMzuNP2mElUxfdA(BWNPxIG7vqdTy85pjHzUOrK3(u"ࠩสาฯืࠠศๆ่่ๆࠦࠨࠨಝ")+str(len(uuSKUinvP4EGLxWZYmTsF))+IjZbnrBJmM2N(u"ࠪࠤ๊๊แࠪࠩಞ"), uuSKUinvP4EGLxWZYmTsF)
				if cMZGTsAR2E!=-qHYIWnOZLPkrQU:
					v5r8wqFZ2KE9QtdHmp0S = byVMDdio5JFRjZS[cMZGTsAR2E][mQNonhS7CV2BXOv(u"ࠫࡺࡸ࡬ࠨಟ")]
					AUes5cIdauyQ = uuSKUinvP4EGLxWZYmTsF[cMZGTsAR2E]
					break
			elif c9Wbh7raCVlyPKqpL6GwNZz1u==kke1PDGRBLuY8y(u"ࠬࡳࡰࡥࠩಠ"):
				cMZGTsAR2E = XXprCMzuNP2mElUxfdA(BWNPxIG7vqdTy85pjHzUOrK3(u"࠭วฯฬิࠤั๎ฯสࠢสฺ่๎ัสࠢࠫࠫಡ")+str(len(lUarDPjqSG3yw9VWFYT4kboN2ue807))+IjZbnrBJmM2N(u"ࠧࠡ็็ๅ࠮࠭ಢ"), lUarDPjqSG3yw9VWFYT4kboN2ue807)
				if cMZGTsAR2E!=-qHYIWnOZLPkrQU:
					AUes5cIdauyQ = lUarDPjqSG3yw9VWFYT4kboN2ue807[cMZGTsAR2E]
					wp65iz1CU2obEh0Nv49GP = Jgt5v3ybL2YhpNxHmjzAUekuB086O[cMZGTsAR2E]
					cMZGTsAR2E = XXprCMzuNP2mElUxfdA(zI3ROAZtiUq42rE9WDST68(u"ࠨษัฮึࠦฬ้ัฬࠤฬ๊ี้ฬࠣࠬࠬಣ")+str(len(nEZthcMJambPvKy1Fgj7e2OY))+QTUBCcehw6qPd4x(u"้้ࠩࠣ็ࠩࠨತ"), nEZthcMJambPvKy1Fgj7e2OY)
					if cMZGTsAR2E!=-qHYIWnOZLPkrQU:
						AUes5cIdauyQ += SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠪࠤ࠰ࠦࠧಥ")+nEZthcMJambPvKy1Fgj7e2OY[cMZGTsAR2E]
						M43BelyLOJ8m9PafGsXI7UR6iWg = ZZAownKWVruJPsGlpC9D[cMZGTsAR2E]
						tHAuxmS0frDiV972XYvBj = CCxMXuNUEzolDZTKrBJ
						break
			elif c9Wbh7raCVlyPKqpL6GwNZz1u==P0qdZI384LKleuo(u"ࠫࡦࡲ࡬ࠨದ"):
				OekxpACWEiRcHzovuU0wKjsn,dkLfO6u75iq,K4XCdNYGz61,XX1TScxQqIaWRVuyDe = list(zip(*t8I97woPTViq0sSuU))
				cMZGTsAR2E = XXprCMzuNP2mElUxfdA(UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠬอฮหำࠣห้๋ไโࠢࠫࠫಧ")+str(len(K4XCdNYGz61))+shC5qBRV2A0lZ(u"࠭ࠠๆๆไ࠭ࠬನ"), K4XCdNYGz61)
				if cMZGTsAR2E!=-qHYIWnOZLPkrQU:
					AUes5cIdauyQ = K4XCdNYGz61[cMZGTsAR2E]
					wp65iz1CU2obEh0Nv49GP = OekxpACWEiRcHzovuU0wKjsn[cMZGTsAR2E]
					if QQdAXWBc2GPw(u"ࠧ࡮ࡲࡧࠫ಩") in K4XCdNYGz61[cMZGTsAR2E] and wp65iz1CU2obEh0Nv49GP[Nh0BWuiSndf(u"ࠨࡷࡵࡰࠬಪ")]!=t5ORX2mjc7hQ:
						M43BelyLOJ8m9PafGsXI7UR6iWg = dkLfO6u75iq[cMZGTsAR2E]
						tHAuxmS0frDiV972XYvBj = CCxMXuNUEzolDZTKrBJ
					else: v5r8wqFZ2KE9QtdHmp0S = wp65iz1CU2obEh0Nv49GP[TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠩࡸࡶࡱ࠭ಫ")]
					break
			elif c9Wbh7raCVlyPKqpL6GwNZz1u==zI3ROAZtiUq42rE9WDST68(u"ࠪ࡬࡮࡭ࡨࡦࡵࡷࠫಬ"):
				OekxpACWEiRcHzovuU0wKjsn,dkLfO6u75iq,K4XCdNYGz61,XX1TScxQqIaWRVuyDe = list(zip(*ZBk9UfqF5VhK))
				wp65iz1CU2obEh0Nv49GP = OekxpACWEiRcHzovuU0wKjsn[cMZGTsAR2E-jnz2DgQ8Z4VJdLrcEoux0h9]
				if kke1PDGRBLuY8y(u"ࠫࡲࡶࡤࠨಭ") in K4XCdNYGz61[cMZGTsAR2E-jnz2DgQ8Z4VJdLrcEoux0h9] and wp65iz1CU2obEh0Nv49GP[Nh0BWuiSndf(u"ࠬࡻࡲ࡭ࠩಮ")]!=t5ORX2mjc7hQ:
					M43BelyLOJ8m9PafGsXI7UR6iWg = dkLfO6u75iq[cMZGTsAR2E-jnz2DgQ8Z4VJdLrcEoux0h9]
					tHAuxmS0frDiV972XYvBj = CCxMXuNUEzolDZTKrBJ
				else: v5r8wqFZ2KE9QtdHmp0S = wp65iz1CU2obEh0Nv49GP[VFjQx6Is28KvzLOmMXtg4GqTwa3(u"࠭ࡵࡳ࡮ࠪಯ")]
				AUes5cIdauyQ = K4XCdNYGz61[cMZGTsAR2E-jnz2DgQ8Z4VJdLrcEoux0h9]
				break
	if tHAuxmS0frDiV972XYvBj:
		FSjVBiIDvbz0ZQtLEa = int(wp65iz1CU2obEh0Nv49GP[IjZbnrBJmM2N(u"ࠧࡥࡷࡵࡥࡹ࡯࡯࡯ࠩರ")])
		PcRQiI218DXVtorU9WNAq = int(M43BelyLOJ8m9PafGsXI7UR6iWg[yST5AHEfvPmcWpwGuh2BJ(u"ࠨࡦࡸࡶࡦࡺࡩࡰࡰࠪಱ")])
		D5taEr6hnuFCcRMpTq4wSoyQOivx = str(max(FSjVBiIDvbz0ZQtLEa,PcRQiI218DXVtorU9WNAq))
		Mo3AxpmOay1jgt0FIXd5 = wp65iz1CU2obEh0Nv49GP[shC5qBRV2A0lZ(u"ࠩࡸࡶࡱ࠭ಲ")].replace(QQdAXWBc2GPw(u"ࠪࠪࠬಳ"),P0qdZI384LKleuo(u"ࠫࠫࡧ࡭ࡱ࠽ࠪ಴"))
		vU06necoSDVGkT8hx = M43BelyLOJ8m9PafGsXI7UR6iWg[QQdAXWBc2GPw(u"ࠬࡻࡲ࡭ࠩವ")].replace(TT8Mxv5Wq7nlC9IscdpPUY6(u"࠭ࠦࠨಶ"),dDYUoKi6JFM23p(u"ࠧࠧࡣࡰࡴࡀ࠭ಷ"))
		mpd = P0qdZI384LKleuo(u"ࠨ࠾ࡐࡔࡉࠦ࡭ࡦࡦ࡬ࡥࡕࡸࡥࡴࡧࡱࡸࡦࡺࡩࡰࡰࡇࡹࡷࡧࡴࡪࡱࡱࡁࠧࡖࡔࠨಸ")+D5taEr6hnuFCcRMpTq4wSoyQOivx+RRIHDFjoW9w7bSfVPhC(u"ࠩࡖࠦࡃࡢ࡮ࠨಹ")
		mpd += vvWwO3Tx2dAgcijrFXq(u"ࠪࡀࡕ࡫ࡲࡪࡱࡧࡂࡡࡴࠧ಺")
		mpd += QTUBCcehw6qPd4x(u"ࠫࡁࡇࡤࡢࡲࡷࡥࡹ࡯࡯࡯ࡕࡨࡸࠥࡳࡩ࡮ࡧࡗࡽࡵ࡫࠽ࠣࡸ࡬ࡨࡪࡵ࠯ࠨ಻")+wp65iz1CU2obEh0Nv49GP[Xz3bA2PFENVCUtplu51(u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫಼ࠧ")]+RRIHDFjoW9w7bSfVPhC(u"࠭ࠢࠡࡥࡲࡨࡪࡩࡳ࠾ࠤࠪಽ")+wp65iz1CU2obEh0Nv49GP[dDYUoKi6JFM23p(u"ࠧࡤࡱࡧࡩࡨࡹࠧಾ")]+SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠨࠤࡁࡠࡳ࠭ಿ")
		mpd += SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠩ࠿ࡖࡪࡶࡲࡦࡵࡨࡲࡹࡧࡴࡪࡱࡱࡂࡡࡴࠧೀ")
		mpd += mQNonhS7CV2BXOv(u"ࠪࡀࡇࡧࡳࡦࡗࡕࡐࡃ࠭ು")+Mo3AxpmOay1jgt0FIXd5+m6hwdgP31a2zjN7lkpX(u"ࠫࡁ࠵ࡂࡢࡵࡨ࡙ࡗࡒ࠾࡝ࡰࠪೂ")
		mpd += TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠬࡂࡓࡦࡩࡰࡩࡳࡺࡂࡢࡵࡨࠤ࡮ࡴࡤࡦࡺࡕࡥࡳ࡭ࡥ࠾ࠤࠪೃ")+wp65iz1CU2obEh0Nv49GP[TYf7Dc06PQgy1vEV9(u"࠭ࡩ࡯ࡦࡨࡼࠬೄ")]+LAQD5wEkr18bUiGaYen3J(u"ࠧࠣࡀ࡟ࡲࠬ೅")
		mpd += P0qdZI384LKleuo(u"ࠨ࠾ࡌࡲ࡮ࡺࡩࡢ࡮࡬ࡾࡦࡺࡩࡰࡰࠣࡶࡦࡴࡧࡦ࠿ࠥࠫೆ")+wp65iz1CU2obEh0Nv49GP[QQdAXWBc2GPw(u"ࠩ࡬ࡲ࡮ࡺࠧೇ")]+Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠪࠦࠥ࠵࠾࡝ࡰࠪೈ")
		mpd += QTUBCcehw6qPd4x(u"ࠫࡁ࠵ࡓࡦࡩࡰࡩࡳࡺࡂࡢࡵࡨࡂࡡࡴࠧ೉")
		mpd += kke1PDGRBLuY8y(u"ࠬࡂ࠯ࡓࡧࡳࡶࡪࡹࡥ࡯ࡶࡤࡸ࡮ࡵ࡮࠿࡞ࡱࠫೊ")
		mpd += IjZbnrBJmM2N(u"࠭࠼࠰ࡃࡧࡥࡵࡺࡡࡵ࡫ࡲࡲࡘ࡫ࡴ࠿࡞ࡱࠫೋ")
		mpd += ddo23ZJtgcY(u"ࠧ࠽ࡃࡧࡥࡵࡺࡡࡵ࡫ࡲࡲࡘ࡫ࡴࠡ࡯࡬ࡱࡪ࡚ࡹࡱࡧࡀࠦࡦࡻࡤࡪࡱ࠲ࠫೌ")+M43BelyLOJ8m9PafGsXI7UR6iWg[vvWwO3Tx2dAgcijrFXq(u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧ್ࠪ")]+RRIHDFjoW9w7bSfVPhC(u"ࠩࠥࠤࡨࡵࡤࡦࡥࡶࡁࠧ࠭೎")+M43BelyLOJ8m9PafGsXI7UR6iWg[TYf7Dc06PQgy1vEV9(u"ࠪࡧࡴࡪࡥࡤࡵࠪ೏")]+shC5qBRV2A0lZ(u"ࠫࠧࡄ࡜࡯ࠩ೐")
		mpd += ddo23ZJtgcY(u"ࠬࡂࡒࡦࡲࡵࡩࡸ࡫࡮ࡵࡣࡷ࡭ࡴࡴ࠾࡝ࡰࠪ೑")
		mpd += vvWwO3Tx2dAgcijrFXq(u"࠭࠼ࡃࡣࡶࡩ࡚ࡘࡌ࠿ࠩ೒")+vU06necoSDVGkT8hx+dDYUoKi6JFM23p(u"ࠧ࠽࠱ࡅࡥࡸ࡫ࡕࡓࡎࡁࡠࡳ࠭೓")
		mpd += mQNonhS7CV2BXOv(u"ࠨ࠾ࡖࡩ࡬ࡳࡥ࡯ࡶࡅࡥࡸ࡫ࠠࡪࡰࡧࡩࡽࡘࡡ࡯ࡩࡨࡁࠧ࠭೔")+M43BelyLOJ8m9PafGsXI7UR6iWg[RRIHDFjoW9w7bSfVPhC(u"ࠩ࡬ࡲࡩ࡫ࡸࠨೕ")]+LAQD5wEkr18bUiGaYen3J(u"ࠪࠦࡃࡢ࡮ࠨೖ")
		mpd += mQNonhS7CV2BXOv(u"ࠫࡁࡏ࡮ࡪࡶ࡬ࡥࡱ࡯ࡺࡢࡶ࡬ࡳࡳࠦࡲࡢࡰࡪࡩࡂࠨࠧ೗")+M43BelyLOJ8m9PafGsXI7UR6iWg[TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠬ࡯࡮ࡪࡶࠪ೘")]+mmcNLrXtzfpyCkZlvK5VwG2gujh(u"࠭ࠢࠡ࠱ࡁࡠࡳ࠭೙")
		mpd += kke1PDGRBLuY8y(u"ࠧ࠽࠱ࡖࡩ࡬ࡳࡥ࡯ࡶࡅࡥࡸ࡫࠾࡝ࡰࠪ೚")
		mpd += TYf7Dc06PQgy1vEV9(u"ࠨ࠾࠲ࡖࡪࡶࡲࡦࡵࡨࡲࡹࡧࡴࡪࡱࡱࡂࡡࡴࠧ೛")
		mpd += m6hwdgP31a2zjN7lkpX(u"ࠩ࠿࠳ࡆࡪࡡࡱࡶࡤࡸ࡮ࡵ࡮ࡔࡧࡷࡂࡡࡴࠧ೜")
		mpd += VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠪࡀ࠴ࡖࡥࡳ࡫ࡲࡨࡃࡢ࡮ࠨೝ")
		mpd += mQNonhS7CV2BXOv(u"ࠫࡁ࠵ࡍࡑࡆࡁࡠࡳ࠭ೞ")
		if i1thmHk7AZquD4cM0fnp62:
			import http.server as wB6F2x9AhKe
			import http.client as qHtmuVfG5rMciQXRFa2gwZkv9O
		else:
			import BaseHTTPServer as wB6F2x9AhKe
			import httplib as qHtmuVfG5rMciQXRFa2gwZkv9O
		class g3L6yjFEnfI(wB6F2x9AhKe.HTTPServer):
			def __init__(IzThYUW305wHSvqZxAKl18L,ip=Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠬࡲ࡯ࡤࡣ࡯࡬ࡴࡹࡴࠨ೟"),port=SbjiWeHLQPoazqwp3cODkd7YxVgn(u"࠵࠶࠲࠸࠹ง"),mpd=QQdAXWBc2GPw(u"࠭࠼࠿ࠩೠ")):
				IzThYUW305wHSvqZxAKl18L.ip = ip
				IzThYUW305wHSvqZxAKl18L.port = port
				IzThYUW305wHSvqZxAKl18L.mpd = mpd
				wB6F2x9AhKe.HTTPServer.__init__(IzThYUW305wHSvqZxAKl18L,(IzThYUW305wHSvqZxAKl18L.ip,IzThYUW305wHSvqZxAKl18L.port),gNITsdS4kPo2pZalFXqQRG)
				IzThYUW305wHSvqZxAKl18L.mpdurl = IjZbnrBJmM2N(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࠨೡ")+ip+ddo23ZJtgcY(u"ࠨ࠼ࠪೢ")+str(port)+DYakr9g4PVU(u"ࠩ࠲ࡽࡴࡻࡴࡶࡤࡨ࠲ࡲࡶࡤࠨೣ")
			def start(IzThYUW305wHSvqZxAKl18L):
				IzThYUW305wHSvqZxAKl18L.threads = mIv7g95PNyqzLZDM8ihkcr1w(DD5cFIejQa2X4BgAu9GWPyJ3tC7)
				IzThYUW305wHSvqZxAKl18L.threads.N4vDb3TKpY0Lr(qHYIWnOZLPkrQU,IzThYUW305wHSvqZxAKl18L.RurhQB0HMJlP4gvsITSE)
			def RurhQB0HMJlP4gvsITSE(IzThYUW305wHSvqZxAKl18L):
				IzThYUW305wHSvqZxAKl18L.keeprunning = CCxMXuNUEzolDZTKrBJ
				while IzThYUW305wHSvqZxAKl18L.keeprunning:
					IzThYUW305wHSvqZxAKl18L.handle_request()
			def stop(IzThYUW305wHSvqZxAKl18L):
				IzThYUW305wHSvqZxAKl18L.keeprunning = DD5cFIejQa2X4BgAu9GWPyJ3tC7
				IzThYUW305wHSvqZxAKl18L.DMIUljtXmBsf5x0YZSWNAFH()
			def ww3CPeNXkGyJMtrpxlcizD8d9(IzThYUW305wHSvqZxAKl18L):
				IzThYUW305wHSvqZxAKl18L.stop()
				IzThYUW305wHSvqZxAKl18L.EvmDR2G3dP7Hbexu1.close()
				IzThYUW305wHSvqZxAKl18L.server_close()
			def VfUhWFaMvw7tEZyc18qRQsGrTdx2p(IzThYUW305wHSvqZxAKl18L,mpd):
				IzThYUW305wHSvqZxAKl18L.mpd = mpd
			def DMIUljtXmBsf5x0YZSWNAFH(IzThYUW305wHSvqZxAKl18L):
				KWfFCYyj7iTlts = qHtmuVfG5rMciQXRFa2gwZkv9O.HTTPConnection(IzThYUW305wHSvqZxAKl18L.ip+SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠪ࠾ࠬ೤")+str(IzThYUW305wHSvqZxAKl18L.port))
				KWfFCYyj7iTlts.request(ddo23ZJtgcY(u"ࠦࡍࡋࡁࡅࠤ೥"), Mmpr0o76iWJvz1kTtfgI8hES(u"ࠧ࠵ࠢ೦"))
		class gNITsdS4kPo2pZalFXqQRG(wB6F2x9AhKe.BaseHTTPRequestHandler):
			def W02ScHFoI38ajMeZO5qtflp(IzThYUW305wHSvqZxAKl18L):
				IzThYUW305wHSvqZxAKl18L.send_response(mQNonhS7CV2BXOv(u"࠳࠲࠳จ"))
				IzThYUW305wHSvqZxAKl18L.send_header(shC5qBRV2A0lZ(u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡵࡻࡳࡩࠬ೧"),DYakr9g4PVU(u"ࠧࡵࡧࡻࡸ࠴ࡶ࡬ࡢ࡫ࡱࠫ೨"))
				IzThYUW305wHSvqZxAKl18L.end_headers()
				IzThYUW305wHSvqZxAKl18L.wfile.write(IzThYUW305wHSvqZxAKl18L.LLOCdZ3sS2enzXx4fVB18YRvbHNwky.mpd.encode(OVauxZzLI10vcXT74K))
				wLQCTr5lqbsVYeAHdzfhZ1F.sleep(qHYIWnOZLPkrQU)
				if IzThYUW305wHSvqZxAKl18L.path==mQNonhS7CV2BXOv(u"ࠨ࠱ࡼࡳࡺࡺࡵࡣࡧ࠱ࡱࡵࡪࠧ೩"): IzThYUW305wHSvqZxAKl18L.LLOCdZ3sS2enzXx4fVB18YRvbHNwky.ww3CPeNXkGyJMtrpxlcizD8d9()
				if IzThYUW305wHSvqZxAKl18L.path==Xz3bA2PFENVCUtplu51(u"ࠩ࠲ࡷ࡭ࡻࡴࡥࡱࡺࡲࠬ೪"): IzThYUW305wHSvqZxAKl18L.LLOCdZ3sS2enzXx4fVB18YRvbHNwky.ww3CPeNXkGyJMtrpxlcizD8d9()
			def UPTSgG3W7nKI(IzThYUW305wHSvqZxAKl18L):
				IzThYUW305wHSvqZxAKl18L.send_response(uVQd103XyvUce2EBtzbYaC(u"࠴࠳࠴ฉ"))
				IzThYUW305wHSvqZxAKl18L.end_headers()
		jj9iZQkEfWMR7wtoNJ8aSHYy6re = g3L6yjFEnfI(TYf7Dc06PQgy1vEV9(u"ࠪ࠵࠷࠽࠮࠱࠰࠳࠲࠶࠭೫"),kke1PDGRBLuY8y(u"࠸࠹࠵࠻࠵ช"),mpd)
		v5r8wqFZ2KE9QtdHmp0S = jj9iZQkEfWMR7wtoNJ8aSHYy6re.mpdurl
		jj9iZQkEfWMR7wtoNJ8aSHYy6re.start()
	else: jj9iZQkEfWMR7wtoNJ8aSHYy6re = b8Qe150xVaJsnDSv
	if i1thmHk7AZquD4cM0fnp62: toGNAnzKlhEBepk3aLUv27RC,VLUhfzw1WQBj6TrsCcoPFgd9D87Y = b8Qe150xVaJsnDSv,zI3ROAZtiUq42rE9WDST68(u"ࠫࡡࡺࠧ೬")
	else: toGNAnzKlhEBepk3aLUv27RC,VLUhfzw1WQBj6TrsCcoPFgd9D87Y = BmePGjS7FxK6kutUM(u"ࠬࡢࡴࠨ೭"),b8Qe150xVaJsnDSv
	kjFEvdfsLSYcD4G = toGNAnzKlhEBepk3aLUv27RC+BWNPxIG7vqdTy85pjHzUOrK3(u"࠭ࡁࡶࡦ࡬ࡳ࠿࡛ࠦࠡࠩ೮")+M43BelyLOJ8m9PafGsXI7UR6iWg[Mmpr0o76iWJvz1kTtfgI8hES(u"ࠧࡶࡴ࡯ࠫ೯")]+TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠨࠢࡠࡠࡳࡢࡴ࡝ࡶࠪ೰")+VLUhfzw1WQBj6TrsCcoPFgd9D87Y+uVQd103XyvUce2EBtzbYaC(u"࡙ࠩ࡭ࡩ࡫࡯࠻ࠢ࡞ࠤࠬೱ")+wp65iz1CU2obEh0Nv49GP[Xz3bA2PFENVCUtplu51(u"ࠪࡹࡷࡲࠧೲ")]+LAQD5wEkr18bUiGaYen3J(u"ࠫࠥࡣࠧೳ") if tHAuxmS0frDiV972XYvBj else toGNAnzKlhEBepk3aLUv27RC+S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠬࡇࠫࡗ࠼ࠣ࡟ࠥ࠭೴")+v5r8wqFZ2KE9QtdHmp0S+Xz3bA2PFENVCUtplu51(u"࠭ࠠ࡞ࠩ೵")
	mwIxD3GBPgLVc2aq9(iebCpLE8fuxTRg,EECz06teoykrNFfq(QQ8pvXNcBfVkP5rRJ7o)+BWNPxIG7vqdTy85pjHzUOrK3(u"ࠧ࡝ࡶࡓࡰࡦࡿࡩ࡯ࡩࠣࡗࡹࡸࡥࡢ࡯࠽ࠤࡠࠦࠧ೶")+AUes5cIdauyQ+uVQd103XyvUce2EBtzbYaC(u"ࠨࠢࡠࠤࠥࠦࠧ೷")+kjFEvdfsLSYcD4G+VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠩࠪ೸"))
	if not v5r8wqFZ2KE9QtdHmp0S: return HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠪࡉࡷࡸ࡯ࡳࠢࠣࠤࠥࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢ࡜ࡓ࡚࡚ࡕࡃࡇࠣࡊࡦ࡯࡬ࡦࡦࠪ೹"),[],[]
	return b8Qe150xVaJsnDSv,[AUes5cIdauyQ],[[v5r8wqFZ2KE9QtdHmp0S,KKN7hlEptWCVZ6IUdAPiQ,jj9iZQkEfWMR7wtoNJ8aSHYy6re]]
def y8atCrb0vVNHkgAIen7fwzG3LYiqJ(url):
	headers = { Mmpr0o76iWJvz1kTtfgI8hES(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ೺") : b8Qe150xVaJsnDSv }
	jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(LtlXH3fvMydAx,url,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,yST5AHEfvPmcWpwGuh2BJ(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡘࡌࡈࡇࡕࡂ࠮࠳ࡶࡸࠬ೻"))
	items = YYBlm36zd0Jst18LXwo4.findall(BWNPxIG7vqdTy85pjHzUOrK3(u"࠭ࡦࡪ࡮ࡨ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠭࠲࡬ࡢࡤࡨࡰ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧࢂࠩ࡝ࡿࠪ೼"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	items = set(items)
	items = sorted(items, reverse=CCxMXuNUEzolDZTKrBJ, key=lambda key: key[IgQimel18t])
	e1ZYt4vdj9MuD2oBWVhXPNnRrzIpiK,uuSKUinvP4EGLxWZYmTsF,OeHG3j8TyFDJC,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = [],[],[],[]
	if not items: return uVQd103XyvUce2EBtzbYaC(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥ࡙ࠢࡍࡉࡈࡏࡃࠩ೽"),[],[]
	for pcA1dzy7LXwGfMPg9mTkuh5tine3,jprAaOYCD6yM8P5VZXK1B2ldNbuR,okYWP4Hxyb in items:
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3.replace(Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠨࡪࡷࡸࡵࡹ࠺ࠨ೾"),Mmpr0o76iWJvz1kTtfgI8hES(u"ࠩ࡫ࡸࡹࡶ࠺ࠨ೿"))
		if mQNonhS7CV2BXOv(u"ࠪ࠲ࡲ࠹ࡵ࠹ࠩഀ") in pcA1dzy7LXwGfMPg9mTkuh5tine3:
			e1ZYt4vdj9MuD2oBWVhXPNnRrzIpiK,OeHG3j8TyFDJC = TTO3ZpWq9FCzhuMAY0RdaDIfX5kw(QQ8pvXNcBfVkP5rRJ7o,pcA1dzy7LXwGfMPg9mTkuh5tine3)
			KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j + OeHG3j8TyFDJC
			if e1ZYt4vdj9MuD2oBWVhXPNnRrzIpiK[LzYQg91SIxDeOGtCKd5]==vvWwO3Tx2dAgcijrFXq(u"ࠫ࠲࠷ࠧഁ"): uuSKUinvP4EGLxWZYmTsF.append(kke1PDGRBLuY8y(u"ู๊ࠬาใิࠤำอีࠨം")+kke1PDGRBLuY8y(u"࠭ࠠࠡࠢࡰ࠷ࡺ࠾ࠧഃ"))
			else:
				for title in e1ZYt4vdj9MuD2oBWVhXPNnRrzIpiK:
					uuSKUinvP4EGLxWZYmTsF.append(IjZbnrBJmM2N(u"ࠧิ์ิๅึࠦฮศืࠪഄ")+R1BKXhzpGH6CoO9jLsPwQWu+title)
		else:
			title = RRIHDFjoW9w7bSfVPhC(u"ࠨีํีๆืࠠฯษุࠫഅ")+QTUBCcehw6qPd4x(u"ࠩࠣࠤࠥࡳࡰ࠵ࠢࠣࠤࠬആ")+okYWP4Hxyb
			KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
			uuSKUinvP4EGLxWZYmTsF.append(title)
	return b8Qe150xVaJsnDSv,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j
def rrejSndG6mQ(url,jLtdbeYiQHnf4SpU2MTly):
	zMaDJPY25fQK96VvUBAgxlROmI8,n92bB0YwDLqyadQRlmGW,uSZFB2Exti0wV,bAZ28SMxhtIWmT314,tzdvaEpMHOCZLXDYg08T = [],[],[],[],[]
	if mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠪࡷࡹࡸࠧഇ") not in str(type(jLtdbeYiQHnf4SpU2MTly)): jLtdbeYiQHnf4SpU2MTly = jLtdbeYiQHnf4SpU2MTly.decode(OVauxZzLI10vcXT74K,LAQD5wEkr18bUiGaYen3J(u"ࠫ࡮࡭࡮ࡰࡴࡨࠫഈ"))
	pcA1dzy7LXwGfMPg9mTkuh5tine3 = YYBlm36zd0Jst18LXwo4.findall(dDYUoKi6JFM23p(u"ࠬࡂࡶࡪࡦࡨࡳࠥࡶࡲࡦ࡮ࡲࡥࡩ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ഉ"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if pcA1dzy7LXwGfMPg9mTkuh5tine3 and not Gz7MH0glBw8Eb(pcA1dzy7LXwGfMPg9mTkuh5tine3[LzYQg91SIxDeOGtCKd5]): pcA1dzy7LXwGfMPg9mTkuh5tine3 = []
	if not pcA1dzy7LXwGfMPg9mTkuh5tine3: pcA1dzy7LXwGfMPg9mTkuh5tine3 = YYBlm36zd0Jst18LXwo4.findall(QTUBCcehw6qPd4x(u"࠭࠼ࡴࡱࡸࡶࡨ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬഊ"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if pcA1dzy7LXwGfMPg9mTkuh5tine3 and not Gz7MH0glBw8Eb(pcA1dzy7LXwGfMPg9mTkuh5tine3[LzYQg91SIxDeOGtCKd5]): pcA1dzy7LXwGfMPg9mTkuh5tine3 = []
	if not pcA1dzy7LXwGfMPg9mTkuh5tine3: pcA1dzy7LXwGfMPg9mTkuh5tine3 = YYBlm36zd0Jst18LXwo4.findall(mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠧࡥ࡫ࡵࡩࡨࡺ࡟࡭࡫ࡱ࡯࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ഋ"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if pcA1dzy7LXwGfMPg9mTkuh5tine3 and not Gz7MH0glBw8Eb(pcA1dzy7LXwGfMPg9mTkuh5tine3[LzYQg91SIxDeOGtCKd5]): pcA1dzy7LXwGfMPg9mTkuh5tine3 = []
	if pcA1dzy7LXwGfMPg9mTkuh5tine3:
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3[LzYQg91SIxDeOGtCKd5]
		title = pcA1dzy7LXwGfMPg9mTkuh5tine3.rsplit(m6hwdgP31a2zjN7lkpX(u"ࠨ࠰ࠪഌ"),HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"࠵ซ"))[qHYIWnOZLPkrQU]
		zMaDJPY25fQK96VvUBAgxlROmI8.append(title)
		n92bB0YwDLqyadQRlmGW.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
	else:
		JQjNkD10xehK8bXUalY3EgZAVmvI = YYBlm36zd0Jst18LXwo4.findall(Nh0BWuiSndf(u"ࠩࡶࡳࡺࡸࡣࡦࡵ࠽ࠤ࠯࠮࡜࡜࠰࠭ࡃࡡࡣࠩࠨ഍"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if not JQjNkD10xehK8bXUalY3EgZAVmvI: JQjNkD10xehK8bXUalY3EgZAVmvI = YYBlm36zd0Jst18LXwo4.findall(shC5qBRV2A0lZ(u"ࠪࡺࡦࡸࠠࡴࡱࡸࡶࡨ࡫ࡳࠡ࠿ࠣࠬࡡࢁ࠮ࠫࡁ࡟ࢁ࠮࠭എ"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if not JQjNkD10xehK8bXUalY3EgZAVmvI: JQjNkD10xehK8bXUalY3EgZAVmvI = YYBlm36zd0Jst18LXwo4.findall(Nh0BWuiSndf(u"ࠫࡻࡧࡲࠡ࡬ࡺࠤࡂࠦࠨ࡝ࡽ࠱࠮ࡄࡢࡽࠪࠩഏ"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if not JQjNkD10xehK8bXUalY3EgZAVmvI: JQjNkD10xehK8bXUalY3EgZAVmvI = YYBlm36zd0Jst18LXwo4.findall(LAQD5wEkr18bUiGaYen3J(u"ࠬࡼࡡࡳࠢࡳࡰࡦࡿࡥࡳࠢࡀࠤ࠳࠰࠿࡝ࠪࠫࡠࢀ࠴ࠪࡀ࡞ࢀ࠭ࡡ࠯ࠧഐ"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if JQjNkD10xehK8bXUalY3EgZAVmvI:
			JQjNkD10xehK8bXUalY3EgZAVmvI = JQjNkD10xehK8bXUalY3EgZAVmvI[LzYQg91SIxDeOGtCKd5]
			JQjNkD10xehK8bXUalY3EgZAVmvI = YYBlm36zd0Jst18LXwo4.sub(LAQD5wEkr18bUiGaYen3J(u"ࡸࠧࠩ࡝࡟ࡿࡡ࠲࡝࡜࡞ࡷࡠࡸࡢ࡮࡝ࡴࡠ࠮࠮࠮࡜ࡸ࠭࡞ࡠࡹࡢࡳ࡞ࠬࠬ࠾ࠬ഑"),Xz3bA2PFENVCUtplu51(u"ࡲࠨ࡞࠴ࠦࡡ࠸ࠢ࠻ࠩഒ"),JQjNkD10xehK8bXUalY3EgZAVmvI)
			JQjNkD10xehK8bXUalY3EgZAVmvI = oJsUwXA0yGOI1mTjxQ(P0qdZI384LKleuo(u"ࠨࡦ࡬ࡧࡹ࠭ഓ"),JQjNkD10xehK8bXUalY3EgZAVmvI)
			if isinstance(JQjNkD10xehK8bXUalY3EgZAVmvI,dict): JQjNkD10xehK8bXUalY3EgZAVmvI = [JQjNkD10xehK8bXUalY3EgZAVmvI]
			for OTKx7aVb2hdS16Wrweky4FXfIN0g9 in JQjNkD10xehK8bXUalY3EgZAVmvI:
				wPDhyVr1LGJXOum,pcA1dzy7LXwGfMPg9mTkuh5tine3 = b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv
				if isinstance(OTKx7aVb2hdS16Wrweky4FXfIN0g9,dict):
					keys = list(OTKx7aVb2hdS16Wrweky4FXfIN0g9.keys())
					if   QTUBCcehw6qPd4x(u"ࠩࡷࡽࡵ࡫ࠧഔ") in keys: wPDhyVr1LGJXOum = str(OTKx7aVb2hdS16Wrweky4FXfIN0g9[BmePGjS7FxK6kutUM(u"ࠪࡸࡾࡶࡥࠨക")])
					if   Xz3bA2PFENVCUtplu51(u"ࠫ࡫࡯࡬ࡦࠩഖ") in keys: pcA1dzy7LXwGfMPg9mTkuh5tine3 = OTKx7aVb2hdS16Wrweky4FXfIN0g9[VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠬ࡬ࡩ࡭ࡧࠪഗ")]
					elif SbjiWeHLQPoazqwp3cODkd7YxVgn(u"࠭ࡨ࡭ࡵࠪഘ") in keys: pcA1dzy7LXwGfMPg9mTkuh5tine3 = OTKx7aVb2hdS16Wrweky4FXfIN0g9[zI3ROAZtiUq42rE9WDST68(u"ࠧࡩ࡮ࡶࠫങ")]
					elif BWNPxIG7vqdTy85pjHzUOrK3(u"ࠨࡵࡵࡧࠬച") in keys: pcA1dzy7LXwGfMPg9mTkuh5tine3 = OTKx7aVb2hdS16Wrweky4FXfIN0g9[shC5qBRV2A0lZ(u"ࠩࡶࡶࡨ࠭ഛ")]
					if   BmePGjS7FxK6kutUM(u"ࠪࡰࡦࡨࡥ࡭ࠩജ") in keys: title = str(OTKx7aVb2hdS16Wrweky4FXfIN0g9[TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠫࡱࡧࡢࡦ࡮ࠪഝ")])
					elif BWNPxIG7vqdTy85pjHzUOrK3(u"ࠬࡼࡩࡥࡧࡲࡣ࡭࡫ࡩࡨࡪࡷࠫഞ") in keys: title = str(OTKx7aVb2hdS16Wrweky4FXfIN0g9[Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"࠭ࡶࡪࡦࡨࡳࡤ࡮ࡥࡪࡩ࡫ࡸࠬട")])
					elif kke1PDGRBLuY8y(u"ࠧ࠯ࠩഠ") in pcA1dzy7LXwGfMPg9mTkuh5tine3: title = pcA1dzy7LXwGfMPg9mTkuh5tine3.rsplit(QTUBCcehw6qPd4x(u"ࠨ࠰ࠪഡ"),Xz3bA2PFENVCUtplu51(u"࠶ฌ"))[qHYIWnOZLPkrQU]
					else: title = pcA1dzy7LXwGfMPg9mTkuh5tine3
				elif isinstance(OTKx7aVb2hdS16Wrweky4FXfIN0g9,str):
					pcA1dzy7LXwGfMPg9mTkuh5tine3 = OTKx7aVb2hdS16Wrweky4FXfIN0g9
					title = pcA1dzy7LXwGfMPg9mTkuh5tine3.rsplit(Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠩ࠱ࠫഢ"),Xz3bA2PFENVCUtplu51(u"࠷ญ"))[qHYIWnOZLPkrQU]
				if qHYIWnOZLPkrQU:
					zMaDJPY25fQK96VvUBAgxlROmI8.append(title+k5bCDErUSmv+wPDhyVr1LGJXOum)
					n92bB0YwDLqyadQRlmGW.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
	for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in zip(n92bB0YwDLqyadQRlmGW,zMaDJPY25fQK96VvUBAgxlROmI8):
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3.replace(ddo23ZJtgcY(u"ࠪࡠࡡ࠵ࠧണ"),P0qdZI384LKleuo(u"ࠫ࠴࠭ത"))
		LLOCdZ3sS2enzXx4fVB18YRvbHNwky = Wl2eu1PavfQ(url,mQNonhS7CV2BXOv(u"ࠬࡻࡲ࡭ࠩഥ"))
		quhyD5749GRVfBUTCHZ3t2lpXvWx = kIMmsSG9NW6BOjlTpnEcuRzgwK()
		if IjZbnrBJmM2N(u"࠭ࡨࡵࡶࡳࠫദ") not in pcA1dzy7LXwGfMPg9mTkuh5tine3: pcA1dzy7LXwGfMPg9mTkuh5tine3 = LLOCdZ3sS2enzXx4fVB18YRvbHNwky+pcA1dzy7LXwGfMPg9mTkuh5tine3
		if Mmpr0o76iWJvz1kTtfgI8hES(u"ࠧ࠯࡯࠶ࡹ࠽࠭ധ") in pcA1dzy7LXwGfMPg9mTkuh5tine3:
			headers = {IjZbnrBJmM2N(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬന"):quhyD5749GRVfBUTCHZ3t2lpXvWx,kke1PDGRBLuY8y(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪഩ"):LLOCdZ3sS2enzXx4fVB18YRvbHNwky}
			wE2AvDHFGiy31,jjeGzd1lkrbKmcH8FwxpIaCvgUy = TTO3ZpWq9FCzhuMAY0RdaDIfX5kw(QQ8pvXNcBfVkP5rRJ7o,pcA1dzy7LXwGfMPg9mTkuh5tine3,headers)
			bAZ28SMxhtIWmT314 += jjeGzd1lkrbKmcH8FwxpIaCvgUy
			uSZFB2Exti0wV += wE2AvDHFGiy31
		else:
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3+zI3ROAZtiUq42rE9WDST68(u"ࠪࢀ࡚ࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴ࠾ࠩപ")+quhyD5749GRVfBUTCHZ3t2lpXvWx+Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠫࠫࡘࡥࡧࡧࡵࡩࡷࡃࠧഫ")+LLOCdZ3sS2enzXx4fVB18YRvbHNwky
			bAZ28SMxhtIWmT314.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
			uSZFB2Exti0wV.append(title)
	bqCG6DEkf705Z9enS4pmN2,zMaDJPY25fQK96VvUBAgxlROmI8,n92bB0YwDLqyadQRlmGW = b8Qe150xVaJsnDSv,[],[]
	if bAZ28SMxhtIWmT314: bqCG6DEkf705Z9enS4pmN2,zMaDJPY25fQK96VvUBAgxlROmI8,n92bB0YwDLqyadQRlmGW = b8Qe150xVaJsnDSv,uSZFB2Exti0wV,bAZ28SMxhtIWmT314
	else:
		if S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠬࡂࠧബ") not in jLtdbeYiQHnf4SpU2MTly and len(jLtdbeYiQHnf4SpU2MTly)<SbjiWeHLQPoazqwp3cODkd7YxVgn(u"࠱࠱࠲ฎ") and jLtdbeYiQHnf4SpU2MTly: bqCG6DEkf705Z9enS4pmN2 = jLtdbeYiQHnf4SpU2MTly
		else:
			msg = YYBlm36zd0Jst18LXwo4.findall(P0qdZI384LKleuo(u"࠭࠼ࡥ࡫ࡹࠤࡸࡺࡹ࡭ࡧࡀࠦ࠳࠰࠿ࠣࡀࠫࡊ࡮ࡲࡥ࠯ࠬࡂ࠭ࡁ࠭ഭ"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
			if not msg: msg = YYBlm36zd0Jst18LXwo4.findall(RRIHDFjoW9w7bSfVPhC(u"ࠧ࠽ࡦ࡬ࡺࠥࡩ࡬ࡢࡵࡶࡁࠧࡼࡰࡠࡸ࡬ࡨࡪࡵ࡟ࡴࡶࡸࡦࡤࡺࡸࡵࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪമ"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
			if not msg: msg = YYBlm36zd0Jst18LXwo4.findall(UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠨ࠾࡫࠶ࡃ࠮ࡓࡰࡴࡵࡽ࠳࠰࠿ࠪ࠾ࠪയ"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
			if msg: bqCG6DEkf705Z9enS4pmN2 = msg[LzYQg91SIxDeOGtCKd5]
	return bqCG6DEkf705Z9enS4pmN2,zMaDJPY25fQK96VvUBAgxlROmI8,n92bB0YwDLqyadQRlmGW
def cWNLFJfl8m7nqdkwOh9(nnkhc2o7PTHxiQZKLdpGuUa,url):
	global NQuzy8iLgRAV9UT2HX7wba
	url = url.strip(BmePGjS7FxK6kutUM(u"ࠩ࠲ࠫര"))
	FFpgZ0heR8aA,lo6biSg2NR3eUB1OpEPxzyXwF8sYWI = b8Qe150xVaJsnDSv,{}
	headers = {Xz3bA2PFENVCUtplu51(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧറ"):kIMmsSG9NW6BOjlTpnEcuRzgwK()}
	headers[IjZbnrBJmM2N(u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬല")] = Wl2eu1PavfQ(url,ddo23ZJtgcY(u"ࠬࡻࡲ࡭ࠩള"))
	headers[P0qdZI384LKleuo(u"࠭ࡁࡤࡥࡨࡴࡹ࠳ࡌࡢࡰࡪࡹࡦ࡭ࡥࠨഴ")] = m6hwdgP31a2zjN7lkpX(u"ࠧࡦࡰ࠰࡙ࡘ࠲ࡥ࡯࠽ࡴࡁ࠵࠴࠹ࠨവ")
	headers[P0qdZI384LKleuo(u"ࠨࡕࡨࡧ࠲ࡌࡥࡵࡥ࡫࠱ࡉ࡫ࡳࡵࠩശ")] = vvWwO3Tx2dAgcijrFXq(u"ࠩ࡬ࡪࡷࡧ࡭ࡦࠩഷ")
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(LtlXH3fvMydAx,ddo23ZJtgcY(u"ࠪࡋࡊ࡚ࠧസ"),url,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,DD5cFIejQa2X4BgAu9GWPyJ3tC7,DYakr9g4PVU(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࡙࠭ࡕࡋࡅࡗࡏࡎࡈ࠯࠴ࡷࡹ࠭ഹ"))
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	aa21SRisAwO3MkrTCd9QthpKgELP = b3HKopTY9zLUyhJmt.code
	if not isinstance(jLtdbeYiQHnf4SpU2MTly,str): jLtdbeYiQHnf4SpU2MTly = jLtdbeYiQHnf4SpU2MTly.decode(OVauxZzLI10vcXT74K,yST5AHEfvPmcWpwGuh2BJ(u"ࠬ࡯ࡧ࡯ࡱࡵࡩࠬഺ"))
	if IjZbnrBJmM2N(u"࠭ࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠩࡲ࠯ࡥ࠱ࡩࠬ࡬࠮ࡨ࠰഻ࠬ") in jLtdbeYiQHnf4SpU2MTly:
		oacnYJr1pe4iC8GdRV9hSmqMk5xg6 = YYBlm36zd0Jst18LXwo4.findall(Mmpr0o76iWJvz1kTtfgI8hES(u"ࠧࠩࡧࡹࡥࡱࡢࠨࡧࡷࡱࡧࡹ࡯࡯࡯࡞ࠫࡴ࠱ࡧࠬࡤ࠮࡮࠰ࡪ࠲࡛ࡥࡴࡠ࠲࠯ࡅࠩ࠽࠱ࡶࡧࡷ࡯ࡰࡵࡀ഼ࠪ"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if oacnYJr1pe4iC8GdRV9hSmqMk5xg6:
			try: FFpgZ0heR8aA = DNnEa1tuSBAzFH57GROwxTmg2M(oacnYJr1pe4iC8GdRV9hSmqMk5xg6[LzYQg91SIxDeOGtCKd5])
			except: FFpgZ0heR8aA = b8Qe150xVaJsnDSv
	if m6hwdgP31a2zjN7lkpX(u"ࠨࡨࡸࡲࡨࡺࡩࡰࡰࠫ࡬࠱ࡻࠬ࡯࠮ࡷ࠰ࡪ࠲ࡲࠪࠩഽ") in jLtdbeYiQHnf4SpU2MTly:
		oacnYJr1pe4iC8GdRV9hSmqMk5xg6 = YYBlm36zd0Jst18LXwo4.findall(shC5qBRV2A0lZ(u"ࠩࠫࡩࡻࡧ࡬࡝ࠪࡩࡹࡳࡩࡴࡪࡱࡱࡠ࠭࡮ࠬࡶ࠮ࡱ࠰ࡹ࠲ࡥ࠭ࡴ࠱࠮ࡄ࠯࠼࠰ࡵࡦࡶ࡮ࡶࡴ࠿ࠩാ"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if oacnYJr1pe4iC8GdRV9hSmqMk5xg6:
			try: FFpgZ0heR8aA = WaSXqRbONY5mQEZ(oacnYJr1pe4iC8GdRV9hSmqMk5xg6[LzYQg91SIxDeOGtCKd5])
			except: FFpgZ0heR8aA = b8Qe150xVaJsnDSv
	vWsMIpk1n6rlLqH52 = jLtdbeYiQHnf4SpU2MTly+FFpgZ0heR8aA
	if Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠪࠦ࡮ࡪ࠲ࠣࠩി") in vWsMIpk1n6rlLqH52 or VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠫࠧ࡯ࡤࠣࠩീ") in vWsMIpk1n6rlLqH52:
		YhHzvW04cnDsGUR = url.split(mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠬ࠵ࠧു"))[VwApyDY1Jc].replace(ubxGUTt1LraKhVZgpAP(u"࠭ࡥ࡮ࡤࡨࡨ࠲࠭ൂ"),b8Qe150xVaJsnDSv).replace(mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠧ࠯ࡪࡷࡱࡱ࠭ൃ"),b8Qe150xVaJsnDSv)
		if mQNonhS7CV2BXOv(u"ࠨࠤ࡬ࡨ࠷ࠨࠧൄ") in vWsMIpk1n6rlLqH52: lo6biSg2NR3eUB1OpEPxzyXwF8sYWI = {Nh0BWuiSndf(u"ࠩ࡬ࡨ࠷࠭൅"):YhHzvW04cnDsGUR,ddo23ZJtgcY(u"ࠪࡳࡵ࠭െ"):kke1PDGRBLuY8y(u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࠸ࠧേ")}
		elif ddo23ZJtgcY(u"ࠬࠨࡩࡥࠤࠪൈ") in vWsMIpk1n6rlLqH52: lo6biSg2NR3eUB1OpEPxzyXwF8sYWI = {m6hwdgP31a2zjN7lkpX(u"࠭ࡩࡥࠩ൉"):YhHzvW04cnDsGUR,LAQD5wEkr18bUiGaYen3J(u"ࠧࡰࡲࠪൊ"):ubxGUTt1LraKhVZgpAP(u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦ࠵ࠫോ")}
		ybF0H85nUohsiRQcpaTfZAKzjMY7wB = headers.copy()
		ybF0H85nUohsiRQcpaTfZAKzjMY7wB[yST5AHEfvPmcWpwGuh2BJ(u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨൌ")] = TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥ്ࠩ")
		Z8VU1cMugRwIjL2fpSyPJFHokYrqa = dcLRAZWFzODax2jf0tHCX81pJveNY(LtlXH3fvMydAx,IjZbnrBJmM2N(u"ࠫࡕࡕࡓࡕࠩൎ"),url,lo6biSg2NR3eUB1OpEPxzyXwF8sYWI,ybF0H85nUohsiRQcpaTfZAKzjMY7wB,b8Qe150xVaJsnDSv,DD5cFIejQa2X4BgAu9GWPyJ3tC7,uVQd103XyvUce2EBtzbYaC(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡚ࡖࡌࡆࡘࡉࡏࡉ࠰࠶ࡳࡪࠧ൏"))
		vWsMIpk1n6rlLqH52 = Z8VU1cMugRwIjL2fpSyPJFHokYrqa.content
	RhrG1sQHaTd,VNIX8Eg0tGakuB3lKAxfv,GGpTe7AdBsNZO3mvI4JixS0KtfM = rrejSndG6mQ(url,vWsMIpk1n6rlLqH52)
	NQuzy8iLgRAV9UT2HX7wba[nnkhc2o7PTHxiQZKLdpGuUa] = RhrG1sQHaTd,VNIX8Eg0tGakuB3lKAxfv,GGpTe7AdBsNZO3mvI4JixS0KtfM,aa21SRisAwO3MkrTCd9QthpKgELP
	return
NQuzy8iLgRAV9UT2HX7wba,mcniXroTg0zYSCuy = {},LzYQg91SIxDeOGtCKd5
def MmjwzIKXpsSvYGRBdaLUi(url):
	global NQuzy8iLgRAV9UT2HX7wba,mcniXroTg0zYSCuy
	tzdvaEpMHOCZLXDYg08T,threads = [],[]
	mcniXroTg0zYSCuy += Nh0BWuiSndf(u"࠲࠲࠳ฏ")
	kaer0bzHFDSmc6N7wXMupZdCLloP = mcniXroTg0zYSCuy
	tzdvaEpMHOCZLXDYg08T.append([qHYIWnOZLPkrQU,url])
	NQuzy8iLgRAV9UT2HX7wba[kaer0bzHFDSmc6N7wXMupZdCLloP+qHYIWnOZLPkrQU] = [None,None,None,None]
	fn6YeIU73XxWgKN = Ay1SMOzkx5CU3aGTL4Zf.Thread(target=cWNLFJfl8m7nqdkwOh9,args=(kaer0bzHFDSmc6N7wXMupZdCLloP+qHYIWnOZLPkrQU,url))
	fn6YeIU73XxWgKN.start()
	fn6YeIU73XxWgKN.join(mQNonhS7CV2BXOv(u"࠳࠳ฐ"))
	if not NQuzy8iLgRAV9UT2HX7wba[kaer0bzHFDSmc6N7wXMupZdCLloP+RRIHDFjoW9w7bSfVPhC(u"࠴ฑ")][IgQimel18t]:
		MUJCtfYVBLODrFbaZn = url.replace(RRIHDFjoW9w7bSfVPhC(u"࠭࠯ࡦ࡯ࡥࡩࡩ࠳ࠧ൐"),HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠧ࠰ࠩ൑"))
		GGYbRJxlHWKpQ2ihCD = YYBlm36zd0Jst18LXwo4.findall(dDYUoKi6JFM23p(u"ࠨࡠࠫ࠲࠯ࡅ࠺࠰࠱࠱࠮ࡄ࠯࠯ࠩ࠰࠭ࡃ࠮࠵ࠨ࠯ࠬࡂ࠭ࠩ࠭൒"),MUJCtfYVBLODrFbaZn+UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠩ࠲ࠫ൓"),YYBlm36zd0Jst18LXwo4.DOTALL)
		start,BtQzDb9SrFv,end = GGYbRJxlHWKpQ2ihCD[LzYQg91SIxDeOGtCKd5]
		end = end.strip(m6hwdgP31a2zjN7lkpX(u"ࠪ࠳ࠬൔ"))
		DDcS8K7uLFyQZdUhopA = len(BtQzDb9SrFv)<NvHugPosYDzRJ or BtQzDb9SrFv in [Xz3bA2PFENVCUtplu51(u"ࠫ࡫࡯࡬ࡦࠩൕ"),Xz3bA2PFENVCUtplu51(u"ࠬࡼࡩࡥࡧࡲࠫൖ"),uVQd103XyvUce2EBtzbYaC(u"࠭ࡶࡪࡦࡨࡳࡪࡳࡢࡦࡦࠪൗ"),S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠧࡢ࡬ࡤࡼࠬ൘"),VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠨ࡫ࡩࡶࡦࡳࡥࠨ൙"),m6hwdgP31a2zjN7lkpX(u"ࠩࡰ࡭ࡷࡸ࡯ࡳࠩ൚")]
		if not DDcS8K7uLFyQZdUhopA: tzdvaEpMHOCZLXDYg08T.append([IgQimel18t,start+shC5qBRV2A0lZ(u"ࠪ࠳ࡪࡳࡢࡦࡦ࠰ࠫ൛")+BtQzDb9SrFv+mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠫ࠴࠭൜")+end])
		if end: tzdvaEpMHOCZLXDYg08T.append([VwApyDY1Jc,start+IjZbnrBJmM2N(u"ࠬ࠵ࠧ൝")+BtQzDb9SrFv+dDYUoKi6JFM23p(u"࠭࠯ࡦ࡯ࡥࡩࡩ࠳ࠧ൞")+end])
		if LAQD5wEkr18bUiGaYen3J(u"ࠧ࠯ࡪࡷࡱࡱ࠭ൟ") in BtQzDb9SrFv:
			QGlXas8VK1u = BtQzDb9SrFv.replace(HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠨ࠰࡫ࡸࡲࡲࠧൠ"),b8Qe150xVaJsnDSv)
			tzdvaEpMHOCZLXDYg08T.append([NvHugPosYDzRJ,start+TYf7Dc06PQgy1vEV9(u"ࠩ࠲ࠫൡ")+QGlXas8VK1u+Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠪ࠳ࠬൢ")+end])
			tzdvaEpMHOCZLXDYg08T.append([yST5AHEfvPmcWpwGuh2BJ(u"࠹ฒ"),start+RRIHDFjoW9w7bSfVPhC(u"ࠫ࠴࡫࡭ࡣࡧࡧ࠱ࠬൣ")+QGlXas8VK1u+Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠬ࠵ࠧ൤")+end])
			if end: tzdvaEpMHOCZLXDYg08T.append([RRIHDFjoW9w7bSfVPhC(u"࠻ณ"),start+IjZbnrBJmM2N(u"࠭࠯ࠨ൥")+QGlXas8VK1u+LAQD5wEkr18bUiGaYen3J(u"ࠧ࠰ࡧࡰࡦࡪࡪ࠭ࠨ൦")+end])
		elif ddo23ZJtgcY(u"ࠨ࠰࡫ࡸࡲࡲࠧ൧") in end:
			zI1ZNvrhcdalysuA = end.replace(BWNPxIG7vqdTy85pjHzUOrK3(u"ࠩ࠱࡬ࡹࡳ࡬ࠨ൨"),b8Qe150xVaJsnDSv)
			tzdvaEpMHOCZLXDYg08T.append([BWNPxIG7vqdTy85pjHzUOrK3(u"࠽ด"),start+Mmpr0o76iWJvz1kTtfgI8hES(u"ࠪ࠳ࠬ൩")+BtQzDb9SrFv+Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠫ࠴࠭൪")+zI1ZNvrhcdalysuA])
			if not DDcS8K7uLFyQZdUhopA: tzdvaEpMHOCZLXDYg08T.append([mmcNLrXtzfpyCkZlvK5VwG2gujh(u"࠸ต"),start+vvWwO3Tx2dAgcijrFXq(u"ࠬ࠵ࡥ࡮ࡤࡨࡨ࠲࠭൫")+BtQzDb9SrFv+yST5AHEfvPmcWpwGuh2BJ(u"࠭࠯ࠨ൬")+zI1ZNvrhcdalysuA])
			tzdvaEpMHOCZLXDYg08T.append([mmcNLrXtzfpyCkZlvK5VwG2gujh(u"࠺ถ"),start+BWNPxIG7vqdTy85pjHzUOrK3(u"ࠧ࠰ࠩ൭")+BtQzDb9SrFv+dDYUoKi6JFM23p(u"ࠨ࠱ࡨࡱࡧ࡫ࡤ࠮ࠩ൮")+zI1ZNvrhcdalysuA])
		else:
			if not DDcS8K7uLFyQZdUhopA: tzdvaEpMHOCZLXDYg08T.append([kke1PDGRBLuY8y(u"࠳࠳ท"),start+dDYUoKi6JFM23p(u"ࠩ࠲ࠫ൯")+BtQzDb9SrFv+QQdAXWBc2GPw(u"ࠪ࠲࡭ࡺ࡭࡭ࠩ൰")])
			if not DDcS8K7uLFyQZdUhopA: tzdvaEpMHOCZLXDYg08T.append([mQNonhS7CV2BXOv(u"࠴࠵ธ"),start+DYakr9g4PVU(u"ࠫ࠴࡫࡭ࡣࡧࡧ࠱ࠬ൱")+BtQzDb9SrFv+RRIHDFjoW9w7bSfVPhC(u"ࠬ࠴ࡨࡵ࡯࡯ࠫ൲")])
			if end: tzdvaEpMHOCZLXDYg08T.append([Nh0BWuiSndf(u"࠵࠷น"),start+Mmpr0o76iWJvz1kTtfgI8hES(u"࠭࠯ࠨ൳")+BtQzDb9SrFv+RRIHDFjoW9w7bSfVPhC(u"ࠧ࠰ࠩ൴")+end+VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠨ࠰࡫ࡸࡲࡲࠧ൵")])
			if end: tzdvaEpMHOCZLXDYg08T.append([TT8Mxv5Wq7nlC9IscdpPUY6(u"࠶࠹บ"),start+kke1PDGRBLuY8y(u"ࠩ࠲ࠫ൶")+BtQzDb9SrFv+TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠪ࠳ࡪࡳࡢࡦࡦ࠰ࠫ൷")+end+m6hwdgP31a2zjN7lkpX(u"ࠫ࠳࡮ࡴ࡮࡮ࠪ൸")])
		if DDcS8K7uLFyQZdUhopA and end:
			end = end.replace(mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠬ࠵ࡥ࡮ࡤࡨࡨ࠲࠭൹"),m6hwdgP31a2zjN7lkpX(u"࠭࠯ࠨൺ"))
			tzdvaEpMHOCZLXDYg08T.append([Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"࠷࠴ป"),start+BmePGjS7FxK6kutUM(u"ࠧ࠰ࠩൻ")+end])
			tzdvaEpMHOCZLXDYg08T.append([m6hwdgP31a2zjN7lkpX(u"࠱࠶ผ"),start+LAQD5wEkr18bUiGaYen3J(u"ࠨ࠱ࡨࡱࡧ࡫ࡤ࠮ࠩർ")+end])
			if shC5qBRV2A0lZ(u"ࠩ࠱࡬ࡹࡳ࡬ࠨൽ") in end:
				zI1ZNvrhcdalysuA = end.replace(DYakr9g4PVU(u"ࠪ࠲࡭ࡺ࡭࡭ࠩൾ"),b8Qe150xVaJsnDSv)
				tzdvaEpMHOCZLXDYg08T.append([TT8Mxv5Wq7nlC9IscdpPUY6(u"࠲࠸ฝ"),start+mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠫ࠴࠭ൿ")+zI1ZNvrhcdalysuA])
				tzdvaEpMHOCZLXDYg08T.append([uVQd103XyvUce2EBtzbYaC(u"࠳࠺พ"),start+LAQD5wEkr18bUiGaYen3J(u"ࠬ࠵ࡥ࡮ࡤࡨࡨ࠲࠭඀")+zI1ZNvrhcdalysuA])
			else:
				tzdvaEpMHOCZLXDYg08T.append([Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"࠴࠼ฟ"),start+RRIHDFjoW9w7bSfVPhC(u"࠭࠯ࠨඁ")+end+kke1PDGRBLuY8y(u"ࠧ࠯ࡪࡷࡱࡱ࠭ං")])
				tzdvaEpMHOCZLXDYg08T.append([ddo23ZJtgcY(u"࠵࠾ภ"),start+P0qdZI384LKleuo(u"ࠨ࠱ࡨࡱࡧ࡫ࡤ࠮ࠩඃ")+end+zI3ROAZtiUq42rE9WDST68(u"ࠩ࠱࡬ࡹࡳ࡬ࠨ඄")])
		RCzoN9tFr2GH8yKavSAO7uc = []
		for MLBDXlxEbU9WJQImfHOnK3zpvdR,pcA1dzy7LXwGfMPg9mTkuh5tine3 in tzdvaEpMHOCZLXDYg08T[qHYIWnOZLPkrQU:]:
			NQuzy8iLgRAV9UT2HX7wba[kaer0bzHFDSmc6N7wXMupZdCLloP+MLBDXlxEbU9WJQImfHOnK3zpvdR] = [None,None,None,None]
			VOHFazZigqGdWX85k1Cb = Ay1SMOzkx5CU3aGTL4Zf.Thread(target=cWNLFJfl8m7nqdkwOh9,args=(kaer0bzHFDSmc6N7wXMupZdCLloP+MLBDXlxEbU9WJQImfHOnK3zpvdR,pcA1dzy7LXwGfMPg9mTkuh5tine3))
			VOHFazZigqGdWX85k1Cb.start()
			RCzoN9tFr2GH8yKavSAO7uc.append(VOHFazZigqGdWX85k1Cb)
			wLQCTr5lqbsVYeAHdzfhZ1F.sleep(ddo23ZJtgcY(u"࠵࠴࠷࠶ม"))
		for VOHFazZigqGdWX85k1Cb in RCzoN9tFr2GH8yKavSAO7uc: VOHFazZigqGdWX85k1Cb.join(HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"࠷࠰ย"))
	bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = b8Qe150xVaJsnDSv,[],[]
	p5vNfaEO7lSojUJzi9DQVMdY82 = []
	for MLBDXlxEbU9WJQImfHOnK3zpvdR,pcA1dzy7LXwGfMPg9mTkuh5tine3 in tzdvaEpMHOCZLXDYg08T:
		dbD1u0oqr9OKSgFlXaL,rD4ueVX6J0L8,xxMOYF9ZGorKwLN1,VVij2duZohm1PQ9FeUc6 = NQuzy8iLgRAV9UT2HX7wba[kaer0bzHFDSmc6N7wXMupZdCLloP+MLBDXlxEbU9WJQImfHOnK3zpvdR]
		if not KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j and xxMOYF9ZGorKwLN1: uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = rD4ueVX6J0L8,xxMOYF9ZGorKwLN1
		if not bqCG6DEkf705Z9enS4pmN2 and dbD1u0oqr9OKSgFlXaL: bqCG6DEkf705Z9enS4pmN2 = dbD1u0oqr9OKSgFlXaL
		if VVij2duZohm1PQ9FeUc6: p5vNfaEO7lSojUJzi9DQVMdY82.append(VVij2duZohm1PQ9FeUc6)
	p5vNfaEO7lSojUJzi9DQVMdY82 = list(set(p5vNfaEO7lSojUJzi9DQVMdY82))
	if not bqCG6DEkf705Z9enS4pmN2 and len(p5vNfaEO7lSojUJzi9DQVMdY82)==mmcNLrXtzfpyCkZlvK5VwG2gujh(u"࠱ร"):
		aa21SRisAwO3MkrTCd9QthpKgELP = p5vNfaEO7lSojUJzi9DQVMdY82[LzYQg91SIxDeOGtCKd5]
		if aa21SRisAwO3MkrTCd9QthpKgELP!=HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"࠳࠲࠳ฤ"):
			if aa21SRisAwO3MkrTCd9QthpKgELP<LzYQg91SIxDeOGtCKd5: bqCG6DEkf705Z9enS4pmN2 = IjZbnrBJmM2N(u"࡚ࠪ࡮ࡪࡥࡰࠢࡳࡥ࡬࡫࠯ࡴࡧࡵࡺࡪࡸࠠࡪࡵࠣࡲࡴࡺࠠࡢࡥࡦࡩࡸࡹࡩࡣ࡮ࡨࠫඅ")
			else:
				bqCG6DEkf705Z9enS4pmN2 = mQNonhS7CV2BXOv(u"ࠫࡍ࡚ࡔࡑࠢࡈࡶࡷࡵࡲ࠻ࠢࠪආ")+str(aa21SRisAwO3MkrTCd9QthpKgELP)
				if i1thmHk7AZquD4cM0fnp62: import http.client as qHtmuVfG5rMciQXRFa2gwZkv9O
				else: import httplib as qHtmuVfG5rMciQXRFa2gwZkv9O
				try: bqCG6DEkf705Z9enS4pmN2 += P0qdZI384LKleuo(u"ࠬࠦࠨࠡࠩඇ")+qHtmuVfG5rMciQXRFa2gwZkv9O.responses[aa21SRisAwO3MkrTCd9QthpKgELP]+BWNPxIG7vqdTy85pjHzUOrK3(u"࠭ࠠࠪࠩඈ")
				except: pass
	wLQCTr5lqbsVYeAHdzfhZ1F.sleep(qHYIWnOZLPkrQU)
	return bqCG6DEkf705Z9enS4pmN2,uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j
class vUrjwOc9HSx83of7(evil9I2DnLJcy8.WindowDialog):
	def __init__(IzThYUW305wHSvqZxAKl18L, *args, **oEpXfMSRcKQJ9qjzk):
		nHN5uIPZ6FhrTK2 = x76PfMyAp1L2WejkU3.path.join(JnlzVBayd7WFKtCOH0, S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠧࡳࡧࡶࡳࡺࡸࡣࡦࡵࠪඉ"), mQNonhS7CV2BXOv(u"ࠨࡴࡨࡧࡦࡶࡴࡤࡪࡤ࠶ࠬඊ"), UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠩࡧ࡭ࡦࡲ࡯ࡨࡤࡪ࠲ࡵࡴࡧࠨඋ"))
		z2jpVbiyZLqOIeCvXnG = x76PfMyAp1L2WejkU3.path.join(JnlzVBayd7WFKtCOH0, Xz3bA2PFENVCUtplu51(u"ࠪࡶࡪࡹ࡯ࡶࡴࡦࡩࡸ࠭ඌ"), UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠫࡷ࡫ࡣࡢࡲࡷࡧ࡭ࡧ࠲ࠨඍ"), QTUBCcehw6qPd4x(u"ࠬࡹࡥ࡭ࡧࡦࡸࡪࡪ࠮ࡱࡰࡪࠫඎ"))
		O6CdptejKfWi0wU2X9GvRx5m8L3s = x76PfMyAp1L2WejkU3.path.join(JnlzVBayd7WFKtCOH0, uVQd103XyvUce2EBtzbYaC(u"࠭ࡲࡦࡵࡲࡹࡷࡩࡥࡴࠩඏ"), Mmpr0o76iWJvz1kTtfgI8hES(u"ࠧࡳࡧࡦࡥࡵࡺࡣࡩࡣ࠵ࠫඐ"), RRIHDFjoW9w7bSfVPhC(u"ࠨࡤࡸࡸࡹࡵ࡮ࡧࡱ࠱ࡴࡳ࡭ࠧඑ"))
		b6IrNzS0oEeGVc2xpOTl5Xj = x76PfMyAp1L2WejkU3.path.join(JnlzVBayd7WFKtCOH0, RRIHDFjoW9w7bSfVPhC(u"ࠩࡵࡩࡸࡵࡵࡳࡥࡨࡷࠬඒ"), Xz3bA2PFENVCUtplu51(u"ࠪࡶࡪࡩࡡࡱࡶࡦ࡬ࡦ࠸ࠧඓ"), RRIHDFjoW9w7bSfVPhC(u"ࠫࡧࡻࡴࡵࡱࡱࡲ࡫࠴ࡰ࡯ࡩࠪඔ"))
		LBDKPM1v23bwWCZIqGRof96UEz = x76PfMyAp1L2WejkU3.path.join(JnlzVBayd7WFKtCOH0, Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠬࡸࡥࡴࡱࡸࡶࡨ࡫ࡳࠨඕ"), BWNPxIG7vqdTy85pjHzUOrK3(u"࠭ࡲࡦࡥࡤࡴࡹࡩࡨࡢ࠴ࠪඖ"), Xz3bA2PFENVCUtplu51(u"ࠧࡣࡷࡷࡸࡴࡴࡢࡨ࠰ࡳࡲ࡬࠭඗"))
		IzThYUW305wHSvqZxAKl18L.cancelled = DD5cFIejQa2X4BgAu9GWPyJ3tC7
		IzThYUW305wHSvqZxAKl18L.chk = [LzYQg91SIxDeOGtCKd5] * shC5qBRV2A0lZ(u"࠻ล")
		IzThYUW305wHSvqZxAKl18L.chkbutton = [LzYQg91SIxDeOGtCKd5] * dDYUoKi6JFM23p(u"࠼ฦ")
		IzThYUW305wHSvqZxAKl18L.chkstate = [DD5cFIejQa2X4BgAu9GWPyJ3tC7] * HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"࠽ว")
		UrDQyglKja1nPm, wJACnNjvVbr3yd, Qjx6Kegdo4B, HQzyAYpTUZdG4L = Nh0BWuiSndf(u"࠷࠻࠰ศ"), LzYQg91SIxDeOGtCKd5, Mmpr0o76iWJvz1kTtfgI8hES(u"࠽࠰࠱ษ"), mmcNLrXtzfpyCkZlvK5VwG2gujh(u"࠷࠷࠲ส")
		Gc5OlBZHX78R4JhfmMVTqgY9Wews0 = UrDQyglKja1nPm+Qjx6Kegdo4B//IgQimel18t
		i2XpdwgAqzcMUkPhr0tbZKeo78LWa, BCMsSth51LYlRm4D7jNgX, qrRjIwhLyJZzWuXD, B80MsE6RdbakS2nZ3H1VPmTuGzpKYN = mQNonhS7CV2BXOv(u"࠵࠸࠹ฬ"), Mmpr0o76iWJvz1kTtfgI8hES(u"࠲࠴࠳ห"), QTUBCcehw6qPd4x(u"࠸࠴࠵อ"), QTUBCcehw6qPd4x(u"࠸࠴࠵อ")
		ABNCV2dQri57Wmub8lg = i2XpdwgAqzcMUkPhr0tbZKeo78LWa+qrRjIwhLyJZzWuXD//IgQimel18t
		Shnd4mCyB3IO5irDaXz6HZxl, Gao1jwNFTZAxciP2f03rv9, rmNVe38Mc9GLwXHJUq, O0XBdj86ECDnQMFGfmtx27brV = P0qdZI384LKleuo(u"࠶࠶࠰ฯ"), S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"࠼࠵࠶ะ"), dDYUoKi6JFM23p(u"࠵࠺࠶ฮ"), P0qdZI384LKleuo(u"࠵࠱ั")
		spkXHiJxgQ7fSlZFwRL2 = Gc5OlBZHX78R4JhfmMVTqgY9Wews0-rmNVe38Mc9GLwXHJUq-Shnd4mCyB3IO5irDaXz6HZxl//IgQimel18t
		yB7C98sNgQwpVu = Gc5OlBZHX78R4JhfmMVTqgY9Wews0+Shnd4mCyB3IO5irDaXz6HZxl//IgQimel18t
		iESfZW20psgwmMI9y8KBkVN, ghtWYrxTf3ARXdQOmKZG02CEb9S, dnrsaHfNCj4RylIJVLhM, KeJA9pfiD4yRvgoI7mYsWtVCkuPh = Nh0BWuiSndf(u"࠴࠷࠸า"), IjZbnrBJmM2N(u"࠵࠳ำ"), DYakr9g4PVU(u"࠹࠵࠶ี"), Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"࠸࠴ิ")
		tGC17z9Bebcr8u6LYdEHxqTM4jsISF, XB03PMnYxtk2J46omWQsL5UT, Cr9e2Ms0tla, uuUXh1ZaH0KrIgCbsSPt = DYakr9g4PVU(u"࠸࠻࠵ึ"), VFjQx6Is28KvzLOmMXtg4GqTwa3(u"࠸࠲ู"), P0qdZI384LKleuo(u"࠵࠱࠲ุ"), UUkIBz1sgQ9WfNeG6trKXvu0(u"࠻࠰ื")
		VlWFSNcYTa4y = Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"࠲࠱࠽ฺ")
		UrDQyglKja1nPm, wJACnNjvVbr3yd, Qjx6Kegdo4B, HQzyAYpTUZdG4L = int(UrDQyglKja1nPm*VlWFSNcYTa4y), int(wJACnNjvVbr3yd*VlWFSNcYTa4y), int(Qjx6Kegdo4B*VlWFSNcYTa4y), int(HQzyAYpTUZdG4L*VlWFSNcYTa4y)
		i2XpdwgAqzcMUkPhr0tbZKeo78LWa, BCMsSth51LYlRm4D7jNgX, qrRjIwhLyJZzWuXD, B80MsE6RdbakS2nZ3H1VPmTuGzpKYN = int(i2XpdwgAqzcMUkPhr0tbZKeo78LWa*VlWFSNcYTa4y), int(BCMsSth51LYlRm4D7jNgX*VlWFSNcYTa4y), int(qrRjIwhLyJZzWuXD*VlWFSNcYTa4y), int(B80MsE6RdbakS2nZ3H1VPmTuGzpKYN*VlWFSNcYTa4y)
		spkXHiJxgQ7fSlZFwRL2, e4YKQZEifPX3zF1ALjchpol, OyowbVNK9qidTQ3AIa51zJP0ZtgD2, EVLcAfPUk0M1u3DjXtIzg8RmG = int(spkXHiJxgQ7fSlZFwRL2*VlWFSNcYTa4y), int(Gao1jwNFTZAxciP2f03rv9*VlWFSNcYTa4y), int(rmNVe38Mc9GLwXHJUq*VlWFSNcYTa4y), int(O0XBdj86ECDnQMFGfmtx27brV*VlWFSNcYTa4y)
		yB7C98sNgQwpVu, HXDIZfrAYlwuFoOJ6, FqXky6g0P91Yordm4eZzt, mmjDMKaULuqA6yxrEOJ9lW5I4 = int(yB7C98sNgQwpVu*VlWFSNcYTa4y), int(Gao1jwNFTZAxciP2f03rv9*VlWFSNcYTa4y), int(rmNVe38Mc9GLwXHJUq*VlWFSNcYTa4y), int(O0XBdj86ECDnQMFGfmtx27brV*VlWFSNcYTa4y)
		iESfZW20psgwmMI9y8KBkVN, ghtWYrxTf3ARXdQOmKZG02CEb9S, dnrsaHfNCj4RylIJVLhM, KeJA9pfiD4yRvgoI7mYsWtVCkuPh = int(iESfZW20psgwmMI9y8KBkVN*VlWFSNcYTa4y), int(ghtWYrxTf3ARXdQOmKZG02CEb9S*VlWFSNcYTa4y), int(dnrsaHfNCj4RylIJVLhM*VlWFSNcYTa4y), int(KeJA9pfiD4yRvgoI7mYsWtVCkuPh*VlWFSNcYTa4y)
		tGC17z9Bebcr8u6LYdEHxqTM4jsISF, XB03PMnYxtk2J46omWQsL5UT, Cr9e2Ms0tla, uuUXh1ZaH0KrIgCbsSPt = int(tGC17z9Bebcr8u6LYdEHxqTM4jsISF*VlWFSNcYTa4y), int(XB03PMnYxtk2J46omWQsL5UT*VlWFSNcYTa4y), int(Cr9e2Ms0tla*VlWFSNcYTa4y), int(uuUXh1ZaH0KrIgCbsSPt*VlWFSNcYTa4y)
		QlSILU1ECN0F8Ghq2axDu = evil9I2DnLJcy8.ControlImage(UrDQyglKja1nPm, wJACnNjvVbr3yd, Qjx6Kegdo4B, HQzyAYpTUZdG4L, nHN5uIPZ6FhrTK2)
		IzThYUW305wHSvqZxAKl18L.addControl(QlSILU1ECN0F8Ghq2axDu)
		IzThYUW305wHSvqZxAKl18L.iteration = oEpXfMSRcKQJ9qjzk.get(vvWwO3Tx2dAgcijrFXq(u"ࠨ࡫ࡷࡩࡷࡧࡴࡪࡱࡱࠫ඘"))
		LL3FOdyj0J = OkuB9nwhD8U1+m6hwdgP31a2zjN7lkpX(u"ࠩไัฺࠦร็ษࠣษู๋ว็ุ๋่ࠢะࠠา๊ห์ฯࠦࠠࠡࠢࠣࠤࠥࠦࠠࠨ඙")+kke1PDGRBLuY8y(u"ࠪห้๋อศ๊็อࠥืโๆࠢࠣࠫක")+str(IzThYUW305wHSvqZxAKl18L.iteration)+hAIp8kmC36T5WFPMSXOwnNbtD
		IzThYUW305wHSvqZxAKl18L.strActionInfo = evil9I2DnLJcy8.ControlLabel(iESfZW20psgwmMI9y8KBkVN, ghtWYrxTf3ARXdQOmKZG02CEb9S, dnrsaHfNCj4RylIJVLhM, KeJA9pfiD4yRvgoI7mYsWtVCkuPh, LL3FOdyj0J, yST5AHEfvPmcWpwGuh2BJ(u"ࠫ࡫ࡵ࡮ࡵ࠳࠶ࠫඛ"))
		IzThYUW305wHSvqZxAKl18L.addControl(IzThYUW305wHSvqZxAKl18L.strActionInfo)
		lvtGpMZHb9 = evil9I2DnLJcy8.ControlImage(i2XpdwgAqzcMUkPhr0tbZKeo78LWa, BCMsSth51LYlRm4D7jNgX, qrRjIwhLyJZzWuXD, B80MsE6RdbakS2nZ3H1VPmTuGzpKYN, oEpXfMSRcKQJ9qjzk.get(yST5AHEfvPmcWpwGuh2BJ(u"ࠬࡩࡡࡱࡶࡦ࡬ࡦ࠭ග")))
		IzThYUW305wHSvqZxAKl18L.addControl(lvtGpMZHb9)
		Q1jeg82lyvpXrLF = OkuB9nwhD8U1+oEpXfMSRcKQJ9qjzk.get(DYakr9g4PVU(u"࠭࡭ࡴࡩࠪඝ"))+hAIp8kmC36T5WFPMSXOwnNbtD
		IzThYUW305wHSvqZxAKl18L.strActionInfo = evil9I2DnLJcy8.ControlLabel(tGC17z9Bebcr8u6LYdEHxqTM4jsISF, XB03PMnYxtk2J46omWQsL5UT, Cr9e2Ms0tla, uuUXh1ZaH0KrIgCbsSPt, Q1jeg82lyvpXrLF, HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠧࡧࡱࡱࡸ࠶࠹ࠧඞ"))
		IzThYUW305wHSvqZxAKl18L.addControl(IzThYUW305wHSvqZxAKl18L.strActionInfo)
		text = OkuB9nwhD8U1+dDYUoKi6JFM23p(u"ࠨะิ์ั࠭ඟ")+hAIp8kmC36T5WFPMSXOwnNbtD
		IzThYUW305wHSvqZxAKl18L.cancelbutton = evil9I2DnLJcy8.ControlButton(spkXHiJxgQ7fSlZFwRL2, e4YKQZEifPX3zF1ALjchpol, OyowbVNK9qidTQ3AIa51zJP0ZtgD2, EVLcAfPUk0M1u3DjXtIzg8RmG, text, focusTexture=LBDKPM1v23bwWCZIqGRof96UEz, noFocusTexture=O6CdptejKfWi0wU2X9GvRx5m8L3s, alignment=QTUBCcehw6qPd4x(u"࠵฻"))
		text = OkuB9nwhD8U1+mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠩสืฯ๋ัศำࠪච")+hAIp8kmC36T5WFPMSXOwnNbtD
		IzThYUW305wHSvqZxAKl18L.okbutton = evil9I2DnLJcy8.ControlButton(yB7C98sNgQwpVu, HXDIZfrAYlwuFoOJ6, FqXky6g0P91Yordm4eZzt, mmjDMKaULuqA6yxrEOJ9lW5I4, text, focusTexture=LBDKPM1v23bwWCZIqGRof96UEz, noFocusTexture=O6CdptejKfWi0wU2X9GvRx5m8L3s, alignment=DYakr9g4PVU(u"࠶฼"))
		IzThYUW305wHSvqZxAKl18L.addControl(IzThYUW305wHSvqZxAKl18L.okbutton)
		IzThYUW305wHSvqZxAKl18L.addControl(IzThYUW305wHSvqZxAKl18L.cancelbutton)
		T1v7mRc52WA4jCptuPYaN, QxrSWDnHY4m5wOtiMbeyquGBfUVI = B80MsE6RdbakS2nZ3H1VPmTuGzpKYN//VwApyDY1Jc, qrRjIwhLyJZzWuXD//VwApyDY1Jc
		for FbcUxvE17ewlWNBHgS8Jn in range(UUkIBz1sgQ9WfNeG6trKXvu0(u"࠾฽")):
			twYTzIrDSLbH1ykx7R = FbcUxvE17ewlWNBHgS8Jn // VwApyDY1Jc
			yy5bS3WBTnGJ2dsPkzHj = FbcUxvE17ewlWNBHgS8Jn % VwApyDY1Jc
			NNfch0XZUazdxnPp4B69sRMA = i2XpdwgAqzcMUkPhr0tbZKeo78LWa + (QxrSWDnHY4m5wOtiMbeyquGBfUVI * yy5bS3WBTnGJ2dsPkzHj)
			AAGgHnmXVlOzNp = BCMsSth51LYlRm4D7jNgX + (T1v7mRc52WA4jCptuPYaN * twYTzIrDSLbH1ykx7R)
			IzThYUW305wHSvqZxAKl18L.chk[FbcUxvE17ewlWNBHgS8Jn] = evil9I2DnLJcy8.ControlImage(NNfch0XZUazdxnPp4B69sRMA, AAGgHnmXVlOzNp, QxrSWDnHY4m5wOtiMbeyquGBfUVI, T1v7mRc52WA4jCptuPYaN, z2jpVbiyZLqOIeCvXnG)
			IzThYUW305wHSvqZxAKl18L.addControl(IzThYUW305wHSvqZxAKl18L.chk[FbcUxvE17ewlWNBHgS8Jn])
			IzThYUW305wHSvqZxAKl18L.chk[FbcUxvE17ewlWNBHgS8Jn].setVisible(DD5cFIejQa2X4BgAu9GWPyJ3tC7)
			IzThYUW305wHSvqZxAKl18L.chkbutton[FbcUxvE17ewlWNBHgS8Jn] = evil9I2DnLJcy8.ControlButton(NNfch0XZUazdxnPp4B69sRMA, AAGgHnmXVlOzNp, QxrSWDnHY4m5wOtiMbeyquGBfUVI, T1v7mRc52WA4jCptuPYaN, str(FbcUxvE17ewlWNBHgS8Jn + qHYIWnOZLPkrQU), font=Xz3bA2PFENVCUtplu51(u"ࠪࡪࡴࡴࡴ࠲࠵ࠪඡ"), focusTexture=O6CdptejKfWi0wU2X9GvRx5m8L3s, noFocusTexture=b6IrNzS0oEeGVc2xpOTl5Xj)
			IzThYUW305wHSvqZxAKl18L.addControl(IzThYUW305wHSvqZxAKl18L.chkbutton[FbcUxvE17ewlWNBHgS8Jn])
		for FbcUxvE17ewlWNBHgS8Jn in range(Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"࠿฾")):
			URCNtui09hsOeXIFfpVa3Q = (FbcUxvE17ewlWNBHgS8Jn // VwApyDY1Jc) * VwApyDY1Jc
			ff8qJobEkRvBQVKOc13i27exySdgh = URCNtui09hsOeXIFfpVa3Q + (FbcUxvE17ewlWNBHgS8Jn + qHYIWnOZLPkrQU) % VwApyDY1Jc
			VgDxjWn8orK7Y9NSG0ywBELp = URCNtui09hsOeXIFfpVa3Q + (FbcUxvE17ewlWNBHgS8Jn - qHYIWnOZLPkrQU) % VwApyDY1Jc
			jMfyspIRD3k4o = (FbcUxvE17ewlWNBHgS8Jn - VwApyDY1Jc) % mQNonhS7CV2BXOv(u"࠹฿")
			ud24nTSfq1LBUt3GXNQPIYs = (FbcUxvE17ewlWNBHgS8Jn + VwApyDY1Jc) % uVQd103XyvUce2EBtzbYaC(u"࠺เ")
			IzThYUW305wHSvqZxAKl18L.chkbutton[FbcUxvE17ewlWNBHgS8Jn].controlRight(IzThYUW305wHSvqZxAKl18L.chkbutton[ff8qJobEkRvBQVKOc13i27exySdgh])
			IzThYUW305wHSvqZxAKl18L.chkbutton[FbcUxvE17ewlWNBHgS8Jn].controlLeft(IzThYUW305wHSvqZxAKl18L.chkbutton[VgDxjWn8orK7Y9NSG0ywBELp])
			if FbcUxvE17ewlWNBHgS8Jn <= IgQimel18t:
				IzThYUW305wHSvqZxAKl18L.chkbutton[FbcUxvE17ewlWNBHgS8Jn].controlUp(IzThYUW305wHSvqZxAKl18L.okbutton)
			else:
				IzThYUW305wHSvqZxAKl18L.chkbutton[FbcUxvE17ewlWNBHgS8Jn].controlUp(IzThYUW305wHSvqZxAKl18L.chkbutton[jMfyspIRD3k4o])
			if FbcUxvE17ewlWNBHgS8Jn >= mQNonhS7CV2BXOv(u"࠸แ"):
				IzThYUW305wHSvqZxAKl18L.chkbutton[FbcUxvE17ewlWNBHgS8Jn].controlDown(IzThYUW305wHSvqZxAKl18L.okbutton)
			else:
				IzThYUW305wHSvqZxAKl18L.chkbutton[FbcUxvE17ewlWNBHgS8Jn].controlDown(IzThYUW305wHSvqZxAKl18L.chkbutton[ud24nTSfq1LBUt3GXNQPIYs])
		IzThYUW305wHSvqZxAKl18L.okbutton.controlLeft(IzThYUW305wHSvqZxAKl18L.cancelbutton)
		IzThYUW305wHSvqZxAKl18L.okbutton.controlRight(IzThYUW305wHSvqZxAKl18L.cancelbutton)
		IzThYUW305wHSvqZxAKl18L.cancelbutton.controlLeft(IzThYUW305wHSvqZxAKl18L.okbutton)
		IzThYUW305wHSvqZxAKl18L.cancelbutton.controlRight(IzThYUW305wHSvqZxAKl18L.okbutton)
		IzThYUW305wHSvqZxAKl18L.okbutton.controlDown(IzThYUW305wHSvqZxAKl18L.chkbutton[IgQimel18t])
		IzThYUW305wHSvqZxAKl18L.okbutton.controlUp(IzThYUW305wHSvqZxAKl18L.chkbutton[yST5AHEfvPmcWpwGuh2BJ(u"࠻โ")])
		IzThYUW305wHSvqZxAKl18L.cancelbutton.controlDown(IzThYUW305wHSvqZxAKl18L.chkbutton[LzYQg91SIxDeOGtCKd5])
		IzThYUW305wHSvqZxAKl18L.cancelbutton.controlUp(IzThYUW305wHSvqZxAKl18L.chkbutton[Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"࠺ใ")])
		IzThYUW305wHSvqZxAKl18L.setFocus(IzThYUW305wHSvqZxAKl18L.okbutton)
	def get(IzThYUW305wHSvqZxAKl18L):
		IzThYUW305wHSvqZxAKl18L.doModal()
		IzThYUW305wHSvqZxAKl18L.close()
		if not IzThYUW305wHSvqZxAKl18L.cancelled:
			return [FbcUxvE17ewlWNBHgS8Jn for FbcUxvE17ewlWNBHgS8Jn in range(DYakr9g4PVU(u"࠾ไ")) if IzThYUW305wHSvqZxAKl18L.chkstate[FbcUxvE17ewlWNBHgS8Jn]]
	def onControl(IzThYUW305wHSvqZxAKl18L, P7vnK69fpOkCI):
		if P7vnK69fpOkCI.getId() == IzThYUW305wHSvqZxAKl18L.okbutton.getId() and any(IzThYUW305wHSvqZxAKl18L.chkstate):
			IzThYUW305wHSvqZxAKl18L.close()
		elif P7vnK69fpOkCI.getId() == IzThYUW305wHSvqZxAKl18L.cancelbutton.getId():
			IzThYUW305wHSvqZxAKl18L.cancelled = CCxMXuNUEzolDZTKrBJ
			IzThYUW305wHSvqZxAKl18L.close()
		else:
			okYWP4Hxyb = P7vnK69fpOkCI.getLabel()
			if okYWP4Hxyb.isnumeric():
				index = int(okYWP4Hxyb) - qHYIWnOZLPkrQU
				IzThYUW305wHSvqZxAKl18L.chkstate[index] = not IzThYUW305wHSvqZxAKl18L.chkstate[index]
				IzThYUW305wHSvqZxAKl18L.chk[index].setVisible(IzThYUW305wHSvqZxAKl18L.chkstate[index])
	def onAction(IzThYUW305wHSvqZxAKl18L, IIYkVq01pleLCZbR):
		if IIYkVq01pleLCZbR == ubxGUTt1LraKhVZgpAP(u"࠷࠰ๅ"):
			IzThYUW305wHSvqZxAKl18L.cancelled = CCxMXuNUEzolDZTKrBJ
			IzThYUW305wHSvqZxAKl18L.close()
def G6RteMu7d5Wo3vZFy1m0hUzcV8xH(key,Z39mxoGwr0QWVKB2chSIqd,url):
	headers = {yST5AHEfvPmcWpwGuh2BJ(u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬජ"):url,Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠬࡇࡣࡤࡧࡳࡸ࠲ࡒࡡ࡯ࡩࡸࡥ࡬࡫ࠧඣ"):Z39mxoGwr0QWVKB2chSIqd}
	Ma2KIUBwxALnCZzq = Nh0BWuiSndf(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱࡫ࡴࡵࡧ࡭ࡧ࠱ࡧࡴࡳ࠯ࡳࡧࡦࡥࡵࡺࡣࡩࡣ࠲ࡥࡵ࡯࠯ࡧࡣ࡯ࡰࡧࡧࡣ࡬ࡁ࡮ࡁࠬඤ")+key
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(Q49IsrlSuYRAVbGKhwdckLDOetF2PZ,BmePGjS7FxK6kutUM(u"ࠧࡈࡇࡗࠫඥ"),Ma2KIUBwxALnCZzq,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,m6hwdgP31a2zjN7lkpX(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡌࡋࡔࡠࡔࡈࡇࡆࡖࡔࡄࡊࡄ࠶ࡤ࡚ࡏࡌࡇࡑ࠱࠶ࡹࡴࠨඦ"))
	ee9oNwUnb1RcGzukmpMOfV,iteration = b8Qe150xVaJsnDSv,LzYQg91SIxDeOGtCKd5
	while CCxMXuNUEzolDZTKrBJ:
		jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
		lo6biSg2NR3eUB1OpEPxzyXwF8sYWI = YYBlm36zd0Jst18LXwo4.findall(m6hwdgP31a2zjN7lkpX(u"ࠩࠥࠬ࠴ࡸࡥࡤࡣࡳࡸࡨ࡮ࡡ࠰ࡣࡳ࡭࠷࠵ࡰࡢࡻ࡯ࡳࡦࡪ࡛࡟ࠤࡠ࠯࠮࠭ට"), jLtdbeYiQHnf4SpU2MTly)
		iteration += qHYIWnOZLPkrQU
		message = YYBlm36zd0Jst18LXwo4.findall(Nh0BWuiSndf(u"ࠪࡀࡱࡧࡢࡦ࡮࡞ࡢࡃࡣࠫࡤ࡮ࡤࡷࡸࡃࠢࡧࡤࡦ࠱࡮ࡳࡡࡨࡧࡶࡩࡱ࡫ࡣࡵ࠯ࡰࡩࡸࡹࡡࡨࡧ࠰ࡸࡪࡾࡴࠣ࡝ࡡࡂࡢ࠰࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯࡭ࡣࡥࡩࡱࡄࠧඨ"), jLtdbeYiQHnf4SpU2MTly)
		if not message: message = YYBlm36zd0Jst18LXwo4.findall(TYf7Dc06PQgy1vEV9(u"ࠫࡁࡪࡩࡷ࡝ࡡࡂࡢ࠱ࡣ࡭ࡣࡶࡷࡂࠨࡦࡣࡥ࠰࡭ࡲࡧࡧࡦࡵࡨࡰࡪࡩࡴ࠮࡯ࡨࡷࡸࡧࡧࡦ࠯ࡨࡶࡷࡵࡲࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧඩ"), jLtdbeYiQHnf4SpU2MTly)
		if not message:
			ee9oNwUnb1RcGzukmpMOfV = YYBlm36zd0Jst18LXwo4.findall(BWNPxIG7vqdTy85pjHzUOrK3(u"ࠬࡸࡥࡢࡦࡲࡲࡱࡿ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧඪ"), jLtdbeYiQHnf4SpU2MTly)[LzYQg91SIxDeOGtCKd5]
			break
		else:
			message = message[LzYQg91SIxDeOGtCKd5]
			lo6biSg2NR3eUB1OpEPxzyXwF8sYWI = lo6biSg2NR3eUB1OpEPxzyXwF8sYWI[LzYQg91SIxDeOGtCKd5]
		EjKLJOiBVTy3W6SHhrds5qGp2zo = YYBlm36zd0Jst18LXwo4.findall(HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࡸࠧ࡯ࡣࡰࡩࡂࠨࡣࠣ࡞ࡶ࠯ࡻࡧ࡬ࡶࡧࡀࠦ࠭ࡡ࡞ࠣ࡟࠮࠭ࠬණ"), jLtdbeYiQHnf4SpU2MTly)[LzYQg91SIxDeOGtCKd5]
		bbMZTLqRj3 = shC5qBRV2A0lZ(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳࡭࡯ࡰࡩ࡯ࡩ࠳ࡩ࡯࡮ࠧࡶࠫඬ") % (lo6biSg2NR3eUB1OpEPxzyXwF8sYWI.replace(dDYUoKi6JFM23p(u"ࠨࠨࡤࡱࡵࡁࠧත"), vvWwO3Tx2dAgcijrFXq(u"ࠩࠩࠫථ")))
		message = YYBlm36zd0Jst18LXwo4.sub(TYf7Dc06PQgy1vEV9(u"ࠪࡀ࠴ࡅࠨࡥ࡫ࡹࢀࡸࡺࡲࡰࡰࡪ࠭ࡠࡤ࠾࡞ࠬࡁࠫද"), b8Qe150xVaJsnDSv, message)
		GGRLDmj6xpdAfvSYrX = vUrjwOc9HSx83of7(captcha=bbMZTLqRj3, msg=message, iteration=iteration)
		P9Psve8706A3Q = GGRLDmj6xpdAfvSYrX.get()
		if not P9Psve8706A3Q: break
		data = {Nh0BWuiSndf(u"ࠫࡨ࠭ධ"): EjKLJOiBVTy3W6SHhrds5qGp2zo, Nh0BWuiSndf(u"ࠬࡸࡥࡴࡲࡲࡲࡸ࡫ࠧන"): P9Psve8706A3Q}
		b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(Q49IsrlSuYRAVbGKhwdckLDOetF2PZ,m6hwdgP31a2zjN7lkpX(u"࠭ࡐࡐࡕࡗࠫ඲"),Ma2KIUBwxALnCZzq,data,headers,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,mQNonhS7CV2BXOv(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡋࡊ࡚࡟ࡓࡇࡆࡅࡕ࡚ࡃࡉࡃ࠵ࡣ࡙ࡕࡋࡆࡐ࠰࠶ࡳࡪࠧඳ"))
	return ee9oNwUnb1RcGzukmpMOfV
def H0Ou7SQqJpdN8o1xDZsKBPtMRc(url):
	jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(LtlXH3fvMydAx,url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,QTUBCcehw6qPd4x(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡘࡁࡃࡎࡒࡅࡉ࡙࠭࠲ࡵࡷࠫප"))
	items = YYBlm36zd0Jst18LXwo4.findall(Nh0BWuiSndf(u"ࠩࡦࡳࡱࡵࡲ࠾ࠤࡵࡩࡩࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧඵ"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if items: return b8Qe150xVaJsnDSv,[b8Qe150xVaJsnDSv],[ items[LzYQg91SIxDeOGtCKd5] ]
	else: return LAQD5wEkr18bUiGaYen3J(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡇࡒࡂࡄࡏࡓࡆࡊࡓࠨබ"),[],[]
def mmGphNT56sUjfBx1doEIa(url):
	return b8Qe150xVaJsnDSv,[b8Qe150xVaJsnDSv],[url]
def tH7Gy6AJTwo5WuM1Pp3qKQ8CIcsa(url):
	LLOCdZ3sS2enzXx4fVB18YRvbHNwky = url.split(RRIHDFjoW9w7bSfVPhC(u"ࠫ࠴࠭භ"))
	AGrtqU8IScR1Wfz = ubxGUTt1LraKhVZgpAP(u"ࠬ࠵ࠧම").join(LLOCdZ3sS2enzXx4fVB18YRvbHNwky[LzYQg91SIxDeOGtCKd5:VwApyDY1Jc])
	jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(LtlXH3fvMydAx,url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,Xz3bA2PFENVCUtplu51(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡝ࡍࡕࡖ࡙ࡔࡊࡄࡖࡊ࠳࠱ࡴࡶࠪඹ"))
	items = YYBlm36zd0Jst18LXwo4.findall(S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠧࡥ࡮ࡥࡹࡹࡺ࡯࡯࡞ࠪࡠ࠮࠴ࡨࡳࡧࡩࠤࡂࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠠ࡝࠭ࠣࡠ࠭࠮࠮ࠫࡁࠬࠤࡡࠫࠠࠩ࠰࠭ࡃ࠮ࠦ࡜ࠬࠢࠫ࠲࠯ࡅࠩࠡ࡞ࠨࠤ࠭࠴ࠪࡀࠫ࡟࠭ࠥࡢࠫࠡࠤࠫ࠲࠯ࡅࠩࠣࠩය"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if items:
		ZQVWXszwbyp2fhiSA9kUGN5dFT7C,HzrMfS9DkQn5jV4xbTOs,FHr0c4sBdgnkNAfyv3,ju5SRq17pr3hUXWI4EnAkD,Z4ucq5QwXTDGHERl01MSOCYb9edh8r,vvgeBnLIcQ47tryOj2fiu = items[LzYQg91SIxDeOGtCKd5]
		VRcGtBaO1xun = int(HzrMfS9DkQn5jV4xbTOs) % int(FHr0c4sBdgnkNAfyv3) + int(ju5SRq17pr3hUXWI4EnAkD) % int(Z4ucq5QwXTDGHERl01MSOCYb9edh8r)
		url = AGrtqU8IScR1Wfz + ZQVWXszwbyp2fhiSA9kUGN5dFT7C + str(VRcGtBaO1xun) + vvgeBnLIcQ47tryOj2fiu
		return b8Qe150xVaJsnDSv,[b8Qe150xVaJsnDSv],[url]
	else: return dDYUoKi6JFM23p(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣ࡞ࡎࡖࡐ࡚ࡕࡋࡅࡗࡋࠧර"),[],[]
def gXu9orKSICHJZ0EjWYhAzplBOq3n(url):
	id = url.split(QQdAXWBc2GPw(u"ࠩ࠲ࠫ඼"))[-qHYIWnOZLPkrQU]
	headers = { QQdAXWBc2GPw(u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩල") : Mmpr0o76iWJvz1kTtfgI8hES(u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦࠪ඾") }
	lo6biSg2NR3eUB1OpEPxzyXwF8sYWI = { VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠧ࡯ࡤࠣ඿"):id , UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠨ࡯ࡱࠤව"):IjZbnrBJmM2N(u"ࠢࡥࡱࡺࡲࡱࡵࡡࡥ࠴ࠥශ") }
	rC39wAIKjUuS = dcLRAZWFzODax2jf0tHCX81pJveNY(LtlXH3fvMydAx,dDYUoKi6JFM23p(u"ࠨࡒࡒࡗ࡙࠭ෂ"), url, lo6biSg2NR3eUB1OpEPxzyXwF8sYWI, headers, b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,DYakr9g4PVU(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡓࡐ࠵ࡗࡓࡐࡔࡇࡄ࠮࠳ࡶࡸࠬස"))
	if LAQD5wEkr18bUiGaYen3J(u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬහ") in list(rC39wAIKjUuS.headers.keys()): pcA1dzy7LXwGfMPg9mTkuh5tine3 = rC39wAIKjUuS.headers[dDYUoKi6JFM23p(u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭ළ")]
	else: pcA1dzy7LXwGfMPg9mTkuh5tine3 = url
	if pcA1dzy7LXwGfMPg9mTkuh5tine3: return b8Qe150xVaJsnDSv,[b8Qe150xVaJsnDSv],[pcA1dzy7LXwGfMPg9mTkuh5tine3]
	else: return uVQd103XyvUce2EBtzbYaC(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡎࡒ࠷࡙ࡕࡒࡏࡂࡆࠪෆ"),[],[]
def Os5zQIpHChR9g(url):
	jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(LtlXH3fvMydAx,url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,QQdAXWBc2GPw(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡚ࡍࡓ࡚ࡖࡍࡋ࡙ࡉ࠲࠷ࡳࡵࠩ෇"))
	items = YYBlm36zd0Jst18LXwo4.findall(SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠧ࡮ࡲ࠷࠾ࠥࡢ࡛࡝ࠩࠫ࠲࠯ࡅࠩ࡝ࠩࠪ෈"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if items: return b8Qe150xVaJsnDSv,[b8Qe150xVaJsnDSv],[ items[LzYQg91SIxDeOGtCKd5] ]
	else: return mQNonhS7CV2BXOv(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦ࡛ࠣࡎࡔࡔࡗࡎࡌ࡚ࡊ࠭෉"),[],[]
def tVI9mWb20Oo5l3xUvehFP1(url):
	jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(LtlXH3fvMydAx,url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,vvWwO3Tx2dAgcijrFXq(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡒࡄࡊࡌ࡚ࡊ࠳࠱ࡴࡶ්ࠪ"))
	items = YYBlm36zd0Jst18LXwo4.findall(LAQD5wEkr18bUiGaYen3J(u"ࠪࡷࡴࡻࡲࡤࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ෋"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if items:
		url = url = LAQD5wEkr18bUiGaYen3J(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡲࡤࡪ࡬ࡺࡪ࠴࡯ࡳࡩࠪ෌") + items[LzYQg91SIxDeOGtCKd5]
		return b8Qe150xVaJsnDSv,[b8Qe150xVaJsnDSv],[ url ]
	else: return HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡂࡔࡆࡌࡎ࡜ࡅࠨ෍"),[],[]
def FiuCP3BpnD6bHAYq9jKT87oVQOJ(url):
	jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(LtlXH3fvMydAx,url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,UUkIBz1sgQ9WfNeG6trKXvu0(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡈࡗ࡙ࡘࡅࡂࡏ࠰࠵ࡸࡺࠧ෎"))
	items = YYBlm36zd0Jst18LXwo4.findall(QTUBCcehw6qPd4x(u"ࠧࡷ࡫ࡧࡩࡴࠦࡰࡳࡧ࡯ࡳࡦࡪ࠮ࠫࡁࡶࡶࡨࡃ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧා"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if items: return b8Qe150xVaJsnDSv,[b8Qe150xVaJsnDSv],[ items[LzYQg91SIxDeOGtCKd5] ]
	else: return Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡉࡘ࡚ࡒࡆࡃࡐࠫැ"),[],[]
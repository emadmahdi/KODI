# -*- coding: utf-8 -*-
from hIVCFnfxSO import *
QQ8pvXNcBfVkP5rRJ7o = 'MOVIZLAND'
headers = { 'User-Agent' : b8Qe150xVaJsnDSv }
WbzmKSZiuOYrBN7oysJ2dUv = '_MVZ_'
wQjs1XZ3AO24g8y9bEeoKMiGIu7 = nTHXJIiah2qK[QQ8pvXNcBfVkP5rRJ7o][0]
RRtlZAxNcPqnOHgzLY7ude5rBXGToK = nTHXJIiah2qK[QQ8pvXNcBfVkP5rRJ7o][1]
def x8IFqMZeJj7suCR4AaGoNXfEHm(mode,url,text):
	if   mode==180: XXxlOLJ9KRjPH382WVCvr6n71 = Y72YmLgw4vqlHxTCkbeKSicasD()
	elif mode==181: XXxlOLJ9KRjPH382WVCvr6n71 = Je4TwC30iOG5DLKWAtbYvhs(url,text)
	elif mode==182: XXxlOLJ9KRjPH382WVCvr6n71 = Hkij627uCDJKyIM(url)
	elif mode==183: XXxlOLJ9KRjPH382WVCvr6n71 = bIpskeGhBlqH(url)
	elif mode==188: XXxlOLJ9KRjPH382WVCvr6n71 = FXn01pzGy7isNWxtOoIZSJM2acCudf()
	elif mode==189: XXxlOLJ9KRjPH382WVCvr6n71 = kstJfK6jHQWrXDSMRIGB7(text)
	else: XXxlOLJ9KRjPH382WVCvr6n71 = False
	return XXxlOLJ9KRjPH382WVCvr6n71
def FXn01pzGy7isNWxtOoIZSJM2acCudf():
	message = 'هذا الموقع تغير بالكامل ... وبحاجة الى اعادة برمجة من الصفر ... والمبرمج حاليا مشغول ويعاني من وعكة صحية ... ولهذا سوف يبقى الموقع مغلق الى ما شاء الله'
	tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'رسالة من المبرمج',message)
	return
def Y72YmLgw4vqlHxTCkbeKSicasD():
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'بحث في الموقع',b8Qe150xVaJsnDSv,189,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'_REMEMBERRESULTS_')
	MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+'بوكس اوفيس موفيز لاند',wQjs1XZ3AO24g8y9bEeoKMiGIu7,181,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'box-office')
	MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+'أحدث الافلام',wQjs1XZ3AO24g8y9bEeoKMiGIu7,181,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'latest-movies')
	MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+'تليفزيون موفيز لاند',wQjs1XZ3AO24g8y9bEeoKMiGIu7,181,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'tv')
	MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+'الاكثر مشاهدة',wQjs1XZ3AO24g8y9bEeoKMiGIu7,181,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'top-views')
	MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+'أقوى الافلام الحالية',wQjs1XZ3AO24g8y9bEeoKMiGIu7,181,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'top-movies')
	jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(Q49IsrlSuYRAVbGKhwdckLDOetF2PZ,wQjs1XZ3AO24g8y9bEeoKMiGIu7,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,'MOVIZLAND-MENU-1st')
	items = YYBlm36zd0Jst18LXwo4.findall('<h2><a href="(.*?)".*?">(.*?)<',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
		MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,181)
	return jLtdbeYiQHnf4SpU2MTly
def Je4TwC30iOG5DLKWAtbYvhs(url,type=b8Qe150xVaJsnDSv):
	jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(GMkNL1RXxKFentp0Zh9d,url,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,'MOVIZLAND-ITEMS-1st')
	if type=='latest-movies': OTKx7aVb2hdS16Wrweky4FXfIN0g9 = YYBlm36zd0Jst18LXwo4.findall('class="titleSection">أحدث الأفلام</h1>(.*?)<h1',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)[0]
	elif type=='box-office': OTKx7aVb2hdS16Wrweky4FXfIN0g9 = YYBlm36zd0Jst18LXwo4.findall('class="titleSection">بوكس اوفيس موفيز لاند</h1>(.*?)<h1',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)[0]
	elif type=='top-movies': OTKx7aVb2hdS16Wrweky4FXfIN0g9 = YYBlm36zd0Jst18LXwo4.findall('btn-2-overlay(.*?)<style>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)[0]
	elif type=='top-views': OTKx7aVb2hdS16Wrweky4FXfIN0g9 = YYBlm36zd0Jst18LXwo4.findall('btn-1 btn-absoly(.*?)btn-2 btn-absoly',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)[0]
	elif type=='tv': OTKx7aVb2hdS16Wrweky4FXfIN0g9 = YYBlm36zd0Jst18LXwo4.findall('class="titleSection">تليفزيون موفيز لاند</h1>(.*?)class="paging"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)[0]
	else: OTKx7aVb2hdS16Wrweky4FXfIN0g9 = jLtdbeYiQHnf4SpU2MTly
	if type in ['top-views','top-movies']:
		items = YYBlm36zd0Jst18LXwo4.findall('style="background-image:url\(\'(.*?)\'.*?href="(.*?)".*?href="(.*?)".*?bottom-title.*?>(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	else: items = YYBlm36zd0Jst18LXwo4.findall('height="3[0-9]+" src="(.*?)".*?bottom-title.*?href=.*?>(.*?)<.*?href="(.*?)".*?href="(.*?)"',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	d3VSIefbHnvqiut = []
	tU9doZbu1l5MOai = ['فيلم','الحلقة','الحلقه','عرض','Raw','SmackDown','اعلان','اجزاء']
	for lvtGpMZHb9,ZQVWXszwbyp2fhiSA9kUGN5dFT7C,HzrMfS9DkQn5jV4xbTOs,FHr0c4sBdgnkNAfyv3 in items:
		if type in ['top-views','top-movies']:
			lvtGpMZHb9,pcA1dzy7LXwGfMPg9mTkuh5tine3,eiFs3pQPyZtjb0W,title = lvtGpMZHb9,ZQVWXszwbyp2fhiSA9kUGN5dFT7C,HzrMfS9DkQn5jV4xbTOs,FHr0c4sBdgnkNAfyv3
		else: lvtGpMZHb9,title,pcA1dzy7LXwGfMPg9mTkuh5tine3,eiFs3pQPyZtjb0W = lvtGpMZHb9,ZQVWXszwbyp2fhiSA9kUGN5dFT7C,HzrMfS9DkQn5jV4xbTOs,FHr0c4sBdgnkNAfyv3
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = SgrGWuAHcLKBQMJetb9(pcA1dzy7LXwGfMPg9mTkuh5tine3)
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3.replace('?view=true',b8Qe150xVaJsnDSv)
		title = pTP49ckGDYrofa2KxenumbH0(title)
		if 'بجودة ' in title or 'بجوده ' in title:
			title = '_MOD_' + title.replace('بجودة ',b8Qe150xVaJsnDSv).replace('بجوده ',b8Qe150xVaJsnDSv)
		title = title.strip(pldxivXC5wbTB2O8q)
		if 'الحلقة' in title or 'الحلقه' in title:
			HHr42WSgBjAeU7TkQcVaL6yEJz8PF = YYBlm36zd0Jst18LXwo4.findall('(.*?) (الحلقة|الحلقه) \d+',title,YYBlm36zd0Jst18LXwo4.DOTALL)
			if HHr42WSgBjAeU7TkQcVaL6yEJz8PF:
				title = '_MOD_' + HHr42WSgBjAeU7TkQcVaL6yEJz8PF[0][0]
				if title not in d3VSIefbHnvqiut:
					MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,183,lvtGpMZHb9)
					d3VSIefbHnvqiut.append(title)
		elif any(Y8aiFZsLKw in title for Y8aiFZsLKw in tU9doZbu1l5MOai):
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3 + '?servers=' + eiFs3pQPyZtjb0W
			MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,182,lvtGpMZHb9)
		else:
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3 + '?servers=' + eiFs3pQPyZtjb0W
			MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,183,lvtGpMZHb9)
	if type==b8Qe150xVaJsnDSv:
		items = YYBlm36zd0Jst18LXwo4.findall('\n<li><a href="(.*?)".*?>(.*?)<',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
			title = pTP49ckGDYrofa2KxenumbH0(title)
			title = title.replace('الصفحة ',b8Qe150xVaJsnDSv)
			if title!=b8Qe150xVaJsnDSv:
				MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'صفحة '+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,181)
	return
def bIpskeGhBlqH(url):
	MUJCtfYVBLODrFbaZn = url.split('?servers=')[0]
	jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(GMkNL1RXxKFentp0Zh9d,MUJCtfYVBLODrFbaZn,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,'MOVIZLAND-EPISODES-1st')
	OTKx7aVb2hdS16Wrweky4FXfIN0g9 = YYBlm36zd0Jst18LXwo4.findall('<title>(.*?)</title>.*?height="([0-9]+)" src="(.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	title,jprAaOYCD6yM8P5VZXK1B2ldNbuR,lvtGpMZHb9 = OTKx7aVb2hdS16Wrweky4FXfIN0g9[0]
	name = YYBlm36zd0Jst18LXwo4.findall('(.*?) (الحلقة|الحلقه) [0-9]+',title,YYBlm36zd0Jst18LXwo4.DOTALL)
	if name: name = '_MOD_' + name[0][0]
	else: name = title
	items = []
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('class="episodesNumbers"(.*?)</div>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)"',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for pcA1dzy7LXwGfMPg9mTkuh5tine3 in items:
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = SgrGWuAHcLKBQMJetb9(pcA1dzy7LXwGfMPg9mTkuh5tine3)
			title = YYBlm36zd0Jst18LXwo4.findall('(الحلقة|الحلقه)-([0-9]+)',pcA1dzy7LXwGfMPg9mTkuh5tine3.split('/')[-2],YYBlm36zd0Jst18LXwo4.DOTALL)
			if not title: title = YYBlm36zd0Jst18LXwo4.findall('()-([0-9]+)',pcA1dzy7LXwGfMPg9mTkuh5tine3.split('/')[-2],YYBlm36zd0Jst18LXwo4.DOTALL)
			if title: title = pldxivXC5wbTB2O8q + title[0][1]
			else: title = b8Qe150xVaJsnDSv
			title = name + ' - ' + 'الحلقة' + title
			title = pTP49ckGDYrofa2KxenumbH0(title)
			MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,182,lvtGpMZHb9)
	if not items:
		title = pTP49ckGDYrofa2KxenumbH0(title)
		if 'بجودة ' in title or 'بجوده ' in title:
			title = '_MOD_' + title.replace('بجودة ',b8Qe150xVaJsnDSv).replace('بجوده ',b8Qe150xVaJsnDSv)
		MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+title,url,182,lvtGpMZHb9)
	return
def Hkij627uCDJKyIM(url):
	OC5ejho8i0pQ1 = url.split('?servers=')
	MUJCtfYVBLODrFbaZn = OC5ejho8i0pQ1[0]
	del OC5ejho8i0pQ1[0]
	jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(Q49IsrlSuYRAVbGKhwdckLDOetF2PZ,MUJCtfYVBLODrFbaZn,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,'MOVIZLAND-PLAY-1st')
	pcA1dzy7LXwGfMPg9mTkuh5tine3 = YYBlm36zd0Jst18LXwo4.findall('font-size: 25px;" href="(.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)[0]
	if pcA1dzy7LXwGfMPg9mTkuh5tine3 not in OC5ejho8i0pQ1: OC5ejho8i0pQ1.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
	KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = []
	for pcA1dzy7LXwGfMPg9mTkuh5tine3 in OC5ejho8i0pQ1:
		if '://moshahda.' in pcA1dzy7LXwGfMPg9mTkuh5tine3:
			FwPvoqmRL6XZb = pcA1dzy7LXwGfMPg9mTkuh5tine3
			KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j.append(FwPvoqmRL6XZb+'?named=Main')
	for pcA1dzy7LXwGfMPg9mTkuh5tine3 in OC5ejho8i0pQ1:
		if '://vb.movizland.' in pcA1dzy7LXwGfMPg9mTkuh5tine3:
			jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(Q49IsrlSuYRAVbGKhwdckLDOetF2PZ,pcA1dzy7LXwGfMPg9mTkuh5tine3,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,'MOVIZLAND-PLAY-2nd')
			jLtdbeYiQHnf4SpU2MTly = jLtdbeYiQHnf4SpU2MTly.decode('windows-1256').encode(OVauxZzLI10vcXT74K)
			jLtdbeYiQHnf4SpU2MTly = jLtdbeYiQHnf4SpU2MTly.replace('src="http://up.movizland.com/uploads/13721411411.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"')
			jLtdbeYiQHnf4SpU2MTly = jLtdbeYiQHnf4SpU2MTly.replace('src="http://up.movizland.online/uploads/13721411411.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"')
			jLtdbeYiQHnf4SpU2MTly = jLtdbeYiQHnf4SpU2MTly.replace('</a></div><br /><div align="center">','src="/uploads/13721411411.png"')
			jLtdbeYiQHnf4SpU2MTly = jLtdbeYiQHnf4SpU2MTly.replace('class="tborder" align="center"','src="/uploads/13721411411.png"')
			ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('(src="/uploads/13721411411.png".*?href="http://moshahda\..*?/\w+.html".*?src="/uploads/13721411411.png")',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
			if ZV5rRvabhxJ:
				vvnQALE5cIPDKXWxUktGwg,BB6xwqVdZC13JQPujR2sUtz = [],[]
				if len(ZV5rRvabhxJ)==1:
					title = b8Qe150xVaJsnDSv
					OTKx7aVb2hdS16Wrweky4FXfIN0g9 = jLtdbeYiQHnf4SpU2MTly
				else:
					for OTKx7aVb2hdS16Wrweky4FXfIN0g9 in ZV5rRvabhxJ:
						CmEkolxes7Q6hB01fGTPZi4 = YYBlm36zd0Jst18LXwo4.findall('src="/uploads/13721411411.png".*?http://up.movizland.(online|com)/uploads/.*?\*\*\*\*\*\*\*+(.*?src="/uploads/13721411411.png")',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
						if CmEkolxes7Q6hB01fGTPZi4: OTKx7aVb2hdS16Wrweky4FXfIN0g9 = 'src="/uploads/13721411411.png"  \n  ' + CmEkolxes7Q6hB01fGTPZi4[0][1]
						CmEkolxes7Q6hB01fGTPZi4 = YYBlm36zd0Jst18LXwo4.findall('src="/uploads/13721411411.png".*?<hr size="1" style="color:'+'#'+'333; background-color:'+'#'+'333" />(.*?href="http://moshahda\..*?/\w+.html".*?src="/uploads/13721411411.png")',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
						if CmEkolxes7Q6hB01fGTPZi4: OTKx7aVb2hdS16Wrweky4FXfIN0g9 = 'src="/uploads/13721411411.png"  \n  ' + CmEkolxes7Q6hB01fGTPZi4[0]
						CmEkolxes7Q6hB01fGTPZi4 = YYBlm36zd0Jst18LXwo4.findall('(src="/uploads/13721411411.png".*?href="http://moshahda\..*?/\w+.html".*?)<hr size="1" style="color:'+'#'+'333; background-color:'+'#'+'333" />.*?src="/uploads/13721411411.png"',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
						if CmEkolxes7Q6hB01fGTPZi4: OTKx7aVb2hdS16Wrweky4FXfIN0g9 = CmEkolxes7Q6hB01fGTPZi4[0] + '  \n  src="/uploads/13721411411.png"'
						D9BTcryuaRg5N63zIEdFmtWPf = YYBlm36zd0Jst18LXwo4.findall('<(.*?)http://up.movizland.(online|com)/uploads/',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
						title = YYBlm36zd0Jst18LXwo4.findall('> *([^<>]+) *<',D9BTcryuaRg5N63zIEdFmtWPf[0][0],YYBlm36zd0Jst18LXwo4.DOTALL)
						title = pldxivXC5wbTB2O8q.join(title)
						title = title.strip(pldxivXC5wbTB2O8q)
						title = title.replace(k5bCDErUSmv,pldxivXC5wbTB2O8q).replace(k5bCDErUSmv,pldxivXC5wbTB2O8q).replace(k5bCDErUSmv,pldxivXC5wbTB2O8q).replace(k5bCDErUSmv,pldxivXC5wbTB2O8q).replace(k5bCDErUSmv,pldxivXC5wbTB2O8q)
						vvnQALE5cIPDKXWxUktGwg.append(title)
					cMZGTsAR2E = XXprCMzuNP2mElUxfdA('أختر الفيديو المطلوب:', vvnQALE5cIPDKXWxUktGwg)
					if cMZGTsAR2E == -1 : return
					title = vvnQALE5cIPDKXWxUktGwg[cMZGTsAR2E]
					OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[cMZGTsAR2E]
				pcA1dzy7LXwGfMPg9mTkuh5tine3 = YYBlm36zd0Jst18LXwo4.findall('href="(http://moshahda\..*?/\w+.html)"',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
				XpSNAODznHs4Z1aUrLFhQv9EMfjgK = pcA1dzy7LXwGfMPg9mTkuh5tine3[0]
				KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j.append(XpSNAODznHs4Z1aUrLFhQv9EMfjgK+'?named=Forum')
				OTKx7aVb2hdS16Wrweky4FXfIN0g9 = OTKx7aVb2hdS16Wrweky4FXfIN0g9.replace('ـ',b8Qe150xVaJsnDSv)
				OTKx7aVb2hdS16Wrweky4FXfIN0g9 = OTKx7aVb2hdS16Wrweky4FXfIN0g9.replace('src="http://up.movizland.online/uploads/1517412175296.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="both"  \n  ')
				OTKx7aVb2hdS16Wrweky4FXfIN0g9 = OTKx7aVb2hdS16Wrweky4FXfIN0g9.replace('src="http://up.movizland.com/uploads/1517412175296.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="both"  \n  ')
				OTKx7aVb2hdS16Wrweky4FXfIN0g9 = OTKx7aVb2hdS16Wrweky4FXfIN0g9.replace('سيرفرات التحميل','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="download"  \n  ')
				OTKx7aVb2hdS16Wrweky4FXfIN0g9 = OTKx7aVb2hdS16Wrweky4FXfIN0g9.replace('روابط التحميل','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="download"  \n  ')
				OTKx7aVb2hdS16Wrweky4FXfIN0g9 = OTKx7aVb2hdS16Wrweky4FXfIN0g9.replace('سيرفرات المشاهد','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="watch"  \n  ')
				OTKx7aVb2hdS16Wrweky4FXfIN0g9 = OTKx7aVb2hdS16Wrweky4FXfIN0g9.replace('روابط المشاهد','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="watch"  \n  ')
				YZhaWpDT8JxPd1Gtn7l9AC = YYBlm36zd0Jst18LXwo4.findall('(src="/uploads/13721411411.png".*?href="http://e5tsar.com/\d+".*?src="/uploads/13721411411.png")',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
				for mBn1d4vV63 in YZhaWpDT8JxPd1Gtn7l9AC:
					type = YYBlm36zd0Jst18LXwo4.findall(' typetype="(.*?)" ',mBn1d4vV63)
					if type:
						if type[0]!='both': type = '__'+type[0]
						else: type = b8Qe150xVaJsnDSv
					items = YYBlm36zd0Jst18LXwo4.findall('(?<!http://e5tsar.com/)(\w+[ \w]*</font>.*?|\w+[ \w]*<br />.*?)href="(http://e5tsar.com/.*?)"',mBn1d4vV63,YYBlm36zd0Jst18LXwo4.DOTALL)
					for H80U7pGOngb2xTf3hDCk5F,pcA1dzy7LXwGfMPg9mTkuh5tine3 in items:
						title = YYBlm36zd0Jst18LXwo4.findall('(\w+[ \w]*)<',H80U7pGOngb2xTf3hDCk5F)
						title = title[-1]
						pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3 + '?named=' + title + type
						KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
	GSh0nJxEXgZjd48u7mBwWOeafyAp5b = MUJCtfYVBLODrFbaZn.replace(wQjs1XZ3AO24g8y9bEeoKMiGIu7,RRtlZAxNcPqnOHgzLY7ude5rBXGToK)
	jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(Q49IsrlSuYRAVbGKhwdckLDOetF2PZ,GSh0nJxEXgZjd48u7mBwWOeafyAp5b,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,'MOVIZLAND-PLAY-3rd')
	items = YYBlm36zd0Jst18LXwo4.findall('" href="(.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if items:
		T0TradzQt93y = items[-1]
		KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j.append(T0TradzQt93y+'?named=Mobile')
	import QNeGEq8sWn
	QNeGEq8sWn.nqu2GCT9gHAbpIPSFZz5(KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j,QQ8pvXNcBfVkP5rRJ7o,'video',url)
	return
def kstJfK6jHQWrXDSMRIGB7(search):
	search,v7Rxw52Z4X0,showDialogs = JimhUH0SEf6w(search)
	if search==b8Qe150xVaJsnDSv: search = FT2oXWtPQpVGuexmLqKN3srdzYn()
	if search==b8Qe150xVaJsnDSv: return
	search = search.replace(pldxivXC5wbTB2O8q,'+')
	jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(GMkNL1RXxKFentp0Zh9d,wQjs1XZ3AO24g8y9bEeoKMiGIu7,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,'MOVIZLAND-SEARCH-1st')
	items = YYBlm36zd0Jst18LXwo4.findall('<option value="(.*?)">(.*?)</option>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	cCDSxdBu2gX9OP8tQUAhIRYnF = [ b8Qe150xVaJsnDSv ]
	FFCwB60gte8d5XGALovOqHmkR4rTU1 = [ 'الكل وبدون فلتر' ]
	for Z8s0Lov2UiWF1qGjO,title in items:
		cCDSxdBu2gX9OP8tQUAhIRYnF.append(Z8s0Lov2UiWF1qGjO)
		FFCwB60gte8d5XGALovOqHmkR4rTU1.append(title)
	if Z8s0Lov2UiWF1qGjO:
		cMZGTsAR2E = XXprCMzuNP2mElUxfdA('اختر الفلتر المناسب:', FFCwB60gte8d5XGALovOqHmkR4rTU1)
		if cMZGTsAR2E == -1 : return
		Z8s0Lov2UiWF1qGjO = cCDSxdBu2gX9OP8tQUAhIRYnF[cMZGTsAR2E]
	else: Z8s0Lov2UiWF1qGjO = b8Qe150xVaJsnDSv
	url = wQjs1XZ3AO24g8y9bEeoKMiGIu7 + '/?s='+search+'&mcat='+Z8s0Lov2UiWF1qGjO
	Je4TwC30iOG5DLKWAtbYvhs(url)
	return
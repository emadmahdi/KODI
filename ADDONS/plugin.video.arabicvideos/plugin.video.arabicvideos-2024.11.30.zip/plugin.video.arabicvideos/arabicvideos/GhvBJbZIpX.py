# -*- coding: utf-8 -*-
from hIVCFnfxSO import *
QQ8pvXNcBfVkP5rRJ7o = 'SHOOFNET'
WbzmKSZiuOYrBN7oysJ2dUv = '_SNT_'
wQjs1XZ3AO24g8y9bEeoKMiGIu7 = nTHXJIiah2qK[QQ8pvXNcBfVkP5rRJ7o][0]
v1vJEhoNQBVPkjG = ['الرئيسية','يلا شوت']
def x8IFqMZeJj7suCR4AaGoNXfEHm(mode,url,text):
	if   mode==840: XXxlOLJ9KRjPH382WVCvr6n71 = Y72YmLgw4vqlHxTCkbeKSicasD()
	elif mode==841: XXxlOLJ9KRjPH382WVCvr6n71 = Je4TwC30iOG5DLKWAtbYvhs(url,text)
	elif mode==842: XXxlOLJ9KRjPH382WVCvr6n71 = Hkij627uCDJKyIM(url)
	elif mode==843: XXxlOLJ9KRjPH382WVCvr6n71 = jQ9zsEX2Hc(url)
	elif mode==849: XXxlOLJ9KRjPH382WVCvr6n71 = kstJfK6jHQWrXDSMRIGB7(text)
	else: XXxlOLJ9KRjPH382WVCvr6n71 = False
	return XXxlOLJ9KRjPH382WVCvr6n71
def Y72YmLgw4vqlHxTCkbeKSicasD():
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',wQjs1XZ3AO24g8y9bEeoKMiGIu7,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'SHOOFNET-MENU-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'بحث في الموقع',b8Qe150xVaJsnDSv,849,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'_REMEMBERRESULTS_')
	MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+' ===== ===== ===== '+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999)
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('"primary-links"(.*?)</u',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)".*?<span>(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
			if title in v1vJEhoNQBVPkjG: continue
			MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,841)
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('"list-categories"(.*?)</u',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)">(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
			if title in v1vJEhoNQBVPkjG: continue
			MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,841)
	return
def Je4TwC30iOG5DLKWAtbYvhs(url,type=b8Qe150xVaJsnDSv):
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'SHOOFNET-TITLES-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('"home-content"(.*?)"footer"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = OTKx7aVb2hdS16Wrweky4FXfIN0g9.replace('"overlay"','"duration"><')
		items = YYBlm36zd0Jst18LXwo4.findall('"thumb".*?data-src="(.*?)".*?"duration">(.*?)<.*?href="(.*?)">(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		d3VSIefbHnvqiut = []
		for lvtGpMZHb9,D5taEr6hnuFCcRMpTq4wSoyQOivx,pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
			title = title.strip(' ')
			title = pTP49ckGDYrofa2KxenumbH0(title)
			HHr42WSgBjAeU7TkQcVaL6yEJz8PF = YYBlm36zd0Jst18LXwo4.findall('(.*?) (الحلقة|حلقة).\d+',title,YYBlm36zd0Jst18LXwo4.DOTALL)
			if 'episodes' not in type and HHr42WSgBjAeU7TkQcVaL6yEJz8PF:
				title = '_MOD_' + HHr42WSgBjAeU7TkQcVaL6yEJz8PF[0][0]
				title = title.replace('اون لاين',b8Qe150xVaJsnDSv)
				if title not in d3VSIefbHnvqiut:
					MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,843,lvtGpMZHb9)
					d3VSIefbHnvqiut.append(title)
			else: MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,842,lvtGpMZHb9,D5taEr6hnuFCcRMpTq4wSoyQOivx)
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('''["']pagination["'](.*?)["']footer["']''',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ:
		type = 'episodes_pages' if 'episodes' in type else 'pages'
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)">(.*?)</a>',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
			title = pTP49ckGDYrofa2KxenumbH0(title)
			MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'صفحة '+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,841,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,type)
	return
def jQ9zsEX2Hc(url):
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'SHOOFNET-SERIES-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	pcA1dzy7LXwGfMPg9mTkuh5tine3 = YYBlm36zd0Jst18LXwo4.findall('"category".*?href="(.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if pcA1dzy7LXwGfMPg9mTkuh5tine3: Je4TwC30iOG5DLKWAtbYvhs(pcA1dzy7LXwGfMPg9mTkuh5tine3[0],'episodes')
	return
def Hkij627uCDJKyIM(url):
	n92bB0YwDLqyadQRlmGW = []
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'SHOOFNET-PLAY-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	DlhJPky307SxBNGUL = YYBlm36zd0Jst18LXwo4.findall("var post_id	= '(.*?)'",jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if DlhJPky307SxBNGUL:
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/wp-admin/admin-ajax.php?action=video_info&post_id='+DlhJPky307SxBNGUL[0]
		b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',pcA1dzy7LXwGfMPg9mTkuh5tine3,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'SHOOFNET-PLAY-2nd')
		jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
		items = YYBlm36zd0Jst18LXwo4.findall('"name":"(.*?)","src":"(.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		for title,pcA1dzy7LXwGfMPg9mTkuh5tine3 in items:
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3.replace('\\/','/')
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3+'?named='+title+'__watch'
			n92bB0YwDLqyadQRlmGW.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
	import QNeGEq8sWn
	QNeGEq8sWn.nqu2GCT9gHAbpIPSFZz5(n92bB0YwDLqyadQRlmGW,QQ8pvXNcBfVkP5rRJ7o,'video',url)
	return
def kstJfK6jHQWrXDSMRIGB7(search):
	search,v7Rxw52Z4X0,showDialogs = JimhUH0SEf6w(search)
	if search==b8Qe150xVaJsnDSv: search = FT2oXWtPQpVGuexmLqKN3srdzYn()
	if search==b8Qe150xVaJsnDSv: return
	search = search.replace(pldxivXC5wbTB2O8q,'+')
	url = wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/?s='+search
	Je4TwC30iOG5DLKWAtbYvhs(url,'search')
	return
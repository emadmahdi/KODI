# -*- coding: utf-8 -*-
from hIVCFnfxSO import *
QQ8pvXNcBfVkP5rRJ7o = 'EGYDEAD'
WbzmKSZiuOYrBN7oysJ2dUv = '_EGD_'
wQjs1XZ3AO24g8y9bEeoKMiGIu7 = nTHXJIiah2qK[QQ8pvXNcBfVkP5rRJ7o][0]
v1vJEhoNQBVPkjG = ['مصارعة','احدث البرامج','احدث الالعاب','الرئيسية','احدث الاغانى']
def x8IFqMZeJj7suCR4AaGoNXfEHm(mode,url,text):
	if   mode==440: XXxlOLJ9KRjPH382WVCvr6n71 = Y72YmLgw4vqlHxTCkbeKSicasD()
	elif mode==441: XXxlOLJ9KRjPH382WVCvr6n71 = Je4TwC30iOG5DLKWAtbYvhs(url,text)
	elif mode==442: XXxlOLJ9KRjPH382WVCvr6n71 = Hkij627uCDJKyIM(url)
	elif mode==443: XXxlOLJ9KRjPH382WVCvr6n71 = bIpskeGhBlqH(url)
	elif mode==449: XXxlOLJ9KRjPH382WVCvr6n71 = kstJfK6jHQWrXDSMRIGB7(text)
	else: XXxlOLJ9KRjPH382WVCvr6n71 = False
	return XXxlOLJ9KRjPH382WVCvr6n71
def Y72YmLgw4vqlHxTCkbeKSicasD():
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',wQjs1XZ3AO24g8y9bEeoKMiGIu7,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'EGYDEAD-MENU-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	OZSA7QNfeE = Wl2eu1PavfQ(wQjs1XZ3AO24g8y9bEeoKMiGIu7,'url')
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'بحث في الموقع',b8Qe150xVaJsnDSv,449,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'_REMEMBERRESULTS_')
	MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+'الرئيسية',wQjs1XZ3AO24g8y9bEeoKMiGIu7,441)
	MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+' ===== ===== ===== '+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999)
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('class="title_menu_right"(.*?)</div>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
	items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)">(.*?)</a>',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
		if title in v1vJEhoNQBVPkjG: continue
		if pcA1dzy7LXwGfMPg9mTkuh5tine3=='#': continue
		MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,441)
	return
def Je4TwC30iOG5DLKWAtbYvhs(url,sWCftVuO3gyXJ1UK4T=b8Qe150xVaJsnDSv):
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'EGYDEAD-TITLES-2nd')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('class="list-related"(.*?)class="pagination"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
	items = YYBlm36zd0Jst18LXwo4.findall('<li>.*?href="(.*?)".*?<h1>(.*?)</h1>.*?src="(.*?)"',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	for pcA1dzy7LXwGfMPg9mTkuh5tine3,title,lvtGpMZHb9 in items:
		if '/url/' in pcA1dzy7LXwGfMPg9mTkuh5tine3: continue
		elif '/season/' in pcA1dzy7LXwGfMPg9mTkuh5tine3: MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,443,lvtGpMZHb9)
		elif '/episode/' in pcA1dzy7LXwGfMPg9mTkuh5tine3: MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,443,lvtGpMZHb9)
		else: MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,442,lvtGpMZHb9)
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('class="pagination"(.*?)</div>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)">(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
			title = pTP49ckGDYrofa2KxenumbH0(title)
			MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'صفحة '+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,441)
	return
def bIpskeGhBlqH(url):
	data = {'View':1}
	headers = {'Content-Type':'application/x-www-form-urlencoded'}
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'POST',url,data,headers,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'EGYDEAD-EPISODES-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	Pmt5K6LAEZBcb = YYBlm36zd0Jst18LXwo4.findall('"seasons-list"(.*?)</div>.</div>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	U8UnzJgXuMIE5GV = YYBlm36zd0Jst18LXwo4.findall('"episodes-list"(.*?)</div>.</div>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if Pmt5K6LAEZBcb:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = Pmt5K6LAEZBcb[0]
		items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,title,lvtGpMZHb9 in items:
			MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,443,lvtGpMZHb9)
	elif U8UnzJgXuMIE5GV:
		lvtGpMZHb9 = YYBlm36zd0Jst18LXwo4.findall('"og:image" content="(.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		lvtGpMZHb9 = lvtGpMZHb9[0]
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = U8UnzJgXuMIE5GV[0]
		items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)".*?>(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
			title = title.replace(eeN6dTEnkJxI,b8Qe150xVaJsnDSv).strip(pldxivXC5wbTB2O8q)
			MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,442,lvtGpMZHb9)
	return
def Hkij627uCDJKyIM(url):
	data = {'View':1}
	headers = {'Content-Type':'application/x-www-form-urlencoded'}
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'POST',url,data,headers,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'EGYDEAD-PLAY-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = []
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('"watchAreaMaster"(.*?)</ul>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		items = YYBlm36zd0Jst18LXwo4.findall('data-link="(.*?)".*?<p>(.*?)</p>',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
			title = title.replace(eeN6dTEnkJxI,b8Qe150xVaJsnDSv).strip(pldxivXC5wbTB2O8q)
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3+'?named='+title+'__watch'
			KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('"donwload-servers-list"(.*?)</ul>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		items = YYBlm36zd0Jst18LXwo4.findall('"ser-name">(.*?)</span>.*?<em>(.*?)</em>.*?href="(.*?)"',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for title,c1EdszLx3mkb8QYX9,pcA1dzy7LXwGfMPg9mTkuh5tine3 in items:
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3.replace(eeN6dTEnkJxI,b8Qe150xVaJsnDSv)
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3+'?named='+title+'__download'+'____'+c1EdszLx3mkb8QYX9
			KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
	import QNeGEq8sWn
	QNeGEq8sWn.nqu2GCT9gHAbpIPSFZz5(KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j,QQ8pvXNcBfVkP5rRJ7o,'video',url)
	return
def kstJfK6jHQWrXDSMRIGB7(search):
	search,v7Rxw52Z4X0,showDialogs = JimhUH0SEf6w(search)
	if search==b8Qe150xVaJsnDSv: search = FT2oXWtPQpVGuexmLqKN3srdzYn()
	if search==b8Qe150xVaJsnDSv: return
	search = search.replace(pldxivXC5wbTB2O8q,'+')
	url = wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/?s='+search
	Je4TwC30iOG5DLKWAtbYvhs(url)
	return
# -*- coding: utf-8 -*-
from hIVCFnfxSO import *
import bs4 as A4bweYZNUO71DjmSoIfqW
QQ8pvXNcBfVkP5rRJ7o = 'ELCINEMA'
WbzmKSZiuOYrBN7oysJ2dUv = '_ELC_'
wQjs1XZ3AO24g8y9bEeoKMiGIu7 = nTHXJIiah2qK[QQ8pvXNcBfVkP5rRJ7o][0]
headers = {'Referer':wQjs1XZ3AO24g8y9bEeoKMiGIu7}
v1vJEhoNQBVPkjG = []
def x8IFqMZeJj7suCR4AaGoNXfEHm(mode,url,text):
	if   mode==510: XXxlOLJ9KRjPH382WVCvr6n71 = Y72YmLgw4vqlHxTCkbeKSicasD()
	elif mode==511: XXxlOLJ9KRjPH382WVCvr6n71 = j2j0VCx9LaFOXq4WBN7UHYy1w5EPIR(url)
	elif mode==512: XXxlOLJ9KRjPH382WVCvr6n71 = T5IfFGVvNL3x4wAtY8HrUs7(url)
	elif mode==513: XXxlOLJ9KRjPH382WVCvr6n71 = A1AzoeBtPk85Ld4JHaK9xG(url)
	elif mode==514: XXxlOLJ9KRjPH382WVCvr6n71 = jhf9lUFR5qQXMJ0kIVtLSnP(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==515: XXxlOLJ9KRjPH382WVCvr6n71 = jhf9lUFR5qQXMJ0kIVtLSnP(url,'SPECIFIED_FILTER___'+text)
	elif mode==516: XXxlOLJ9KRjPH382WVCvr6n71 = IL7uCYcviO(text)
	elif mode==517: XXxlOLJ9KRjPH382WVCvr6n71 = fFcaVy7dJu3AZNvq4CbzLoh(url)
	elif mode==518: XXxlOLJ9KRjPH382WVCvr6n71 = GGOxXED3hopU4qeSl(url)
	elif mode==519: XXxlOLJ9KRjPH382WVCvr6n71 = kstJfK6jHQWrXDSMRIGB7(text)
	elif mode==520: XXxlOLJ9KRjPH382WVCvr6n71 = eOGVaAbh2Id(url)
	elif mode==521: XXxlOLJ9KRjPH382WVCvr6n71 = uHeCtPVDhEMx2J7cNvQdm5(url)
	elif mode==522: XXxlOLJ9KRjPH382WVCvr6n71 = Hkij627uCDJKyIM(url)
	elif mode==523: XXxlOLJ9KRjPH382WVCvr6n71 = HOz7AXoL1Tk(text)
	elif mode==524: XXxlOLJ9KRjPH382WVCvr6n71 = tB9Ix0weHblXhFQGK5JY()
	elif mode==525: XXxlOLJ9KRjPH382WVCvr6n71 = nChAMmDBTrFsVZx1j0eq()
	elif mode==526: XXxlOLJ9KRjPH382WVCvr6n71 = X7XMqsR51u()
	elif mode==527: XXxlOLJ9KRjPH382WVCvr6n71 = hajbNPq4TrIOUCd()
	else: XXxlOLJ9KRjPH382WVCvr6n71 = False
	return XXxlOLJ9KRjPH382WVCvr6n71
def Y72YmLgw4vqlHxTCkbeKSicasD():
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'بحث بموسوعة السينما',b8Qe150xVaJsnDSv,519)
	MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+' ===== ===== ===== '+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999)
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'موسوعة الأعمال',b8Qe150xVaJsnDSv,525)
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'موسوعة الأشخاص',b8Qe150xVaJsnDSv,526)
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'موسوعة المصنفات',b8Qe150xVaJsnDSv,527)
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'موسوعة المنوعات',b8Qe150xVaJsnDSv,524)
	return
def tB9Ix0weHblXhFQGK5JY():
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+' فيديوهات - خاصة',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/video',520)
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'فيديوهات - أحدث',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/video/latest',521)
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'فيديوهات - أقدم',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/video/oldest',521)
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'فيديوهات - أكثر مشاهدة',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/video/views',521)
	return
def nChAMmDBTrFsVZx1j0eq():
	YNGkMI3Bqu80CJwiRrgS64UKyEzZXA = wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/lineup?utf8=%E2%9C%93'
	ABIK0JoVGRLn75XFheywa6 = YNGkMI3Bqu80CJwiRrgS64UKyEzZXA+'&type=2&category=1&foreign=false&tag='
	aaL0YszEbOSrBkGWj = YNGkMI3Bqu80CJwiRrgS64UKyEzZXA+'&type=2&category=3&foreign=false&tag='
	hpr8Xx0KZdmsue3bA6RJI5t = YNGkMI3Bqu80CJwiRrgS64UKyEzZXA+'&type=2&category=1&foreign=true&tag='
	vvDqih6CMRdlK2NfbAFjkae = YNGkMI3Bqu80CJwiRrgS64UKyEzZXA+'&type=2&category=3&foreign=true&tag='
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'مصنفات أفلام عربي',ABIK0JoVGRLn75XFheywa6,511)
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'مصنفات مسلسلات عربي',aaL0YszEbOSrBkGWj,511)
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'مصنفات أفلام اجنبي',hpr8Xx0KZdmsue3bA6RJI5t,511)
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'مصنفات مسلسلات اجنبي',vvDqih6CMRdlK2NfbAFjkae,511)
	MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+' ===== ===== ===== '+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999)
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'فهرس أعمال أبجدي',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/index/work/alphabet',517)
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'فهرس  بلد الإنتاج',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/index/work/country',517)
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'فهرس اللغة',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/index/work/language',517)
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'فهرس مصنفات العمل',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/index/work/genre',517)
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'فهرس سنة الإصدار',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/index/work/release_year',517)
	MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+' ===== ===== ===== '+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999)
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'مواسم - فلتر محدد',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/seasonals',515)
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'مواسم - فلتر كامل',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/seasonals',514)
	MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+' ===== ===== ===== '+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999)
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'مصنفات - فلتر محدد',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/lineup',515)
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'مصنفات - فلتر كامل',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/lineup',514)
	return
def hajbNPq4TrIOUCd():
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(Q49IsrlSuYRAVbGKhwdckLDOetF2PZ,'GET',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/lineup',b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'ELCINEMA-MENU-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	IOW5tBEoVT3rR0l1QncxM = A4bweYZNUO71DjmSoIfqW.BeautifulSoup(jLtdbeYiQHnf4SpU2MTly,'html.parser',multi_valued_attributes=None)
	OTKx7aVb2hdS16Wrweky4FXfIN0g9 = IOW5tBEoVT3rR0l1QncxM.find('select',attrs={'name':'tag'})
	v7Rxw52Z4X0 = OTKx7aVb2hdS16Wrweky4FXfIN0g9.find_all('option')
	for Ny03TjaY7bBxWwm2GI in v7Rxw52Z4X0:
		Y8aiFZsLKw = Ny03TjaY7bBxWwm2GI.get('value')
		if not Y8aiFZsLKw: continue
		title = Ny03TjaY7bBxWwm2GI.text
		if hDTluNxe7tCwrpqXHzdEcYRfbs:
			title = title.encode(OVauxZzLI10vcXT74K)
			Y8aiFZsLKw = Y8aiFZsLKw.encode(OVauxZzLI10vcXT74K)
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/lineup?utf8=%E2%9C%93&type=&category=&foreign=&tag='+Y8aiFZsLKw
		title = title.replace('قائمة ',b8Qe150xVaJsnDSv)
		MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,511)
	return
def X7XMqsR51u():
	YNGkMI3Bqu80CJwiRrgS64UKyEzZXA = wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/lineup?utf8=%E2%9C%93'
	ZR1fdSsBJVeLUm9y7rit2CHTKau = YNGkMI3Bqu80CJwiRrgS64UKyEzZXA+'&type=1&category=&foreign=&tag='
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'مصنفات أشخاص',ZR1fdSsBJVeLUm9y7rit2CHTKau,511)
	MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+' ===== ===== ===== '+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999)
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'فهرس أشخاص أبجدي',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/index/person/alphabet',517)
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'فهرس موطن',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/index/person/nationality',517)
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'فهرس  تاريخ الميلاد',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/index/person/birth_year',517)
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'فهرس  تاريخ الوفاة',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/index/person/death_year',517)
	MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+' ===== ===== ===== '+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999)
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'مصنفات - فلتر محدد',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/lineup',515)
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'مصنفات - فلتر كامل',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/lineup',514)
	return
def j2j0VCx9LaFOXq4WBN7UHYy1w5EPIR(url):
	if '/seasonals' in url: tmaChESsDcO9dxLW4GQb = 0
	elif '/lineup' in url: tmaChESsDcO9dxLW4GQb = 1
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(Q49IsrlSuYRAVbGKhwdckLDOetF2PZ,'GET',url,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'ELCINEMA-LISTS-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	IOW5tBEoVT3rR0l1QncxM = A4bweYZNUO71DjmSoIfqW.BeautifulSoup(jLtdbeYiQHnf4SpU2MTly,'html.parser',multi_valued_attributes=None)
	JQjNkD10xehK8bXUalY3EgZAVmvI = IOW5tBEoVT3rR0l1QncxM.find_all(class_='jumbo-theater clearfix')
	for OTKx7aVb2hdS16Wrweky4FXfIN0g9 in JQjNkD10xehK8bXUalY3EgZAVmvI:
		title = OTKx7aVb2hdS16Wrweky4FXfIN0g9.find_all('a')[tmaChESsDcO9dxLW4GQb].text
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = wQjs1XZ3AO24g8y9bEeoKMiGIu7+OTKx7aVb2hdS16Wrweky4FXfIN0g9.find_all('a')[tmaChESsDcO9dxLW4GQb].get('href')
		if hDTluNxe7tCwrpqXHzdEcYRfbs:
			title = title.encode(OVauxZzLI10vcXT74K)
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3.encode(OVauxZzLI10vcXT74K)
		if not JQjNkD10xehK8bXUalY3EgZAVmvI:
			T5IfFGVvNL3x4wAtY8HrUs7(pcA1dzy7LXwGfMPg9mTkuh5tine3)
			return
		else:
			title = title.replace('قائمة ',b8Qe150xVaJsnDSv)
			MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,512)
	ZCkrKgME82qhdlIzND1oSQH(IOW5tBEoVT3rR0l1QncxM,511)
	return
def ZCkrKgME82qhdlIzND1oSQH(IOW5tBEoVT3rR0l1QncxM,mode):
	OTKx7aVb2hdS16Wrweky4FXfIN0g9 = IOW5tBEoVT3rR0l1QncxM.find(class_='pagination')
	if OTKx7aVb2hdS16Wrweky4FXfIN0g9:
		ZvwBpL5CdUbRoNx9YhlOEWJDSijau = OTKx7aVb2hdS16Wrweky4FXfIN0g9.find_all('a')
		aegVL12P7tUYyKCc = OTKx7aVb2hdS16Wrweky4FXfIN0g9.find_all('li')
		Neu2pGd1Rny6iIJtcmBvT = list(zip(ZvwBpL5CdUbRoNx9YhlOEWJDSijau,aegVL12P7tUYyKCc))
		s9s45taoNBh60XL1zykOmTK3jJCrE = -1
		oV0GR4qirXzE1QnI2xNZmu3M = len(Neu2pGd1Rny6iIJtcmBvT)
		for Mzf60rCGbPoJIlAsYB2LmcZkO,LBzVGs3T4tO9qyYg6vkhdA8FMNPorm in Neu2pGd1Rny6iIJtcmBvT:
			s9s45taoNBh60XL1zykOmTK3jJCrE += 1
			LBzVGs3T4tO9qyYg6vkhdA8FMNPorm = LBzVGs3T4tO9qyYg6vkhdA8FMNPorm['class']
			if 'unavailable' in LBzVGs3T4tO9qyYg6vkhdA8FMNPorm or 'current' in LBzVGs3T4tO9qyYg6vkhdA8FMNPorm: continue
			WUj71fhxld3rqONpBzmEuC = Mzf60rCGbPoJIlAsYB2LmcZkO.text
			eiFs3pQPyZtjb0W = wQjs1XZ3AO24g8y9bEeoKMiGIu7+Mzf60rCGbPoJIlAsYB2LmcZkO.get('href')
			if hDTluNxe7tCwrpqXHzdEcYRfbs:
				WUj71fhxld3rqONpBzmEuC = WUj71fhxld3rqONpBzmEuC.encode(OVauxZzLI10vcXT74K)
				eiFs3pQPyZtjb0W = eiFs3pQPyZtjb0W.encode(OVauxZzLI10vcXT74K)
			if   s9s45taoNBh60XL1zykOmTK3jJCrE==0: WUj71fhxld3rqONpBzmEuC = 'أولى'
			elif s9s45taoNBh60XL1zykOmTK3jJCrE==1: WUj71fhxld3rqONpBzmEuC = 'سابقة'
			elif s9s45taoNBh60XL1zykOmTK3jJCrE==oV0GR4qirXzE1QnI2xNZmu3M-2: WUj71fhxld3rqONpBzmEuC = 'لاحقة'
			elif s9s45taoNBh60XL1zykOmTK3jJCrE==oV0GR4qirXzE1QnI2xNZmu3M-1: WUj71fhxld3rqONpBzmEuC = 'أخيرة'
			MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'صفحة '+WUj71fhxld3rqONpBzmEuC,eiFs3pQPyZtjb0W,mode)
	return
def T5IfFGVvNL3x4wAtY8HrUs7(url):
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(Q49IsrlSuYRAVbGKhwdckLDOetF2PZ,'GET',url,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'ELCINEMA-TITLES1-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	IOW5tBEoVT3rR0l1QncxM = A4bweYZNUO71DjmSoIfqW.BeautifulSoup(jLtdbeYiQHnf4SpU2MTly,'html.parser',multi_valued_attributes=None)
	JQjNkD10xehK8bXUalY3EgZAVmvI = IOW5tBEoVT3rR0l1QncxM.find_all(class_='row')
	items,CGQ914dXgqhLswByzFSKEWkPmv8j = [],True
	for OTKx7aVb2hdS16Wrweky4FXfIN0g9 in JQjNkD10xehK8bXUalY3EgZAVmvI:
		if not OTKx7aVb2hdS16Wrweky4FXfIN0g9.find(class_='thumbnail-wrapper'): continue
		if CGQ914dXgqhLswByzFSKEWkPmv8j: CGQ914dXgqhLswByzFSKEWkPmv8j = False ; continue
		jsLrGDSEglvaUzF2d847cy5eYJH = []
		PkhK3cg1eUNpqrjRdoYw = OTKx7aVb2hdS16Wrweky4FXfIN0g9.find_all(class_=['censorship red','censorship purple'])
		for lIMXhWY57waJZo6i in PkhK3cg1eUNpqrjRdoYw:
			EmQx8sbva1tHfNu79Oe3Ploh0gX = lIMXhWY57waJZo6i.find_all('li')[1].text
			if hDTluNxe7tCwrpqXHzdEcYRfbs:
				EmQx8sbva1tHfNu79Oe3Ploh0gX = EmQx8sbva1tHfNu79Oe3Ploh0gX.encode(OVauxZzLI10vcXT74K)
			jsLrGDSEglvaUzF2d847cy5eYJH.append(EmQx8sbva1tHfNu79Oe3Ploh0gX)
		if not vvIMS2DeraLfJ(QQ8pvXNcBfVkP5rRJ7o,b8Qe150xVaJsnDSv,jsLrGDSEglvaUzF2d847cy5eYJH,False):
			I6YPOSofrpnTwRm8b = OTKx7aVb2hdS16Wrweky4FXfIN0g9.find('img').get('data-src')
			title = OTKx7aVb2hdS16Wrweky4FXfIN0g9.find('h3')
			name = title.find('a').text
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = wQjs1XZ3AO24g8y9bEeoKMiGIu7+title.find('a').get('href')
			yyCWwq7V2s0aBFRKnmXu = OTKx7aVb2hdS16Wrweky4FXfIN0g9.find(class_='no-margin')
			Sex9NRzWk5VZfFYbqagB4UA = OTKx7aVb2hdS16Wrweky4FXfIN0g9.find(class_='legend')
			if yyCWwq7V2s0aBFRKnmXu: yyCWwq7V2s0aBFRKnmXu = yyCWwq7V2s0aBFRKnmXu.text
			if Sex9NRzWk5VZfFYbqagB4UA: Sex9NRzWk5VZfFYbqagB4UA = Sex9NRzWk5VZfFYbqagB4UA.text
			if hDTluNxe7tCwrpqXHzdEcYRfbs:
				I6YPOSofrpnTwRm8b = I6YPOSofrpnTwRm8b.encode(OVauxZzLI10vcXT74K)
				name = name.encode(OVauxZzLI10vcXT74K)
				pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3.encode(OVauxZzLI10vcXT74K)
				if yyCWwq7V2s0aBFRKnmXu: yyCWwq7V2s0aBFRKnmXu = yyCWwq7V2s0aBFRKnmXu.encode(OVauxZzLI10vcXT74K)
			XXra5dzn8tcLOxYZIE7pPof49Hh = {}
			if Sex9NRzWk5VZfFYbqagB4UA: XXra5dzn8tcLOxYZIE7pPof49Hh['stars'] = Sex9NRzWk5VZfFYbqagB4UA
			if yyCWwq7V2s0aBFRKnmXu:
				yyCWwq7V2s0aBFRKnmXu = yyCWwq7V2s0aBFRKnmXu.replace(eeN6dTEnkJxI,' .. ')
				XXra5dzn8tcLOxYZIE7pPof49Hh['plot'] = yyCWwq7V2s0aBFRKnmXu.replace('...اقرأ المزيد',b8Qe150xVaJsnDSv)
			if '/work/' in pcA1dzy7LXwGfMPg9mTkuh5tine3:
				MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+name,pcA1dzy7LXwGfMPg9mTkuh5tine3,516,I6YPOSofrpnTwRm8b,b8Qe150xVaJsnDSv,name,b8Qe150xVaJsnDSv,XXra5dzn8tcLOxYZIE7pPof49Hh)
			elif '/person/' in pcA1dzy7LXwGfMPg9mTkuh5tine3: MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+name,pcA1dzy7LXwGfMPg9mTkuh5tine3,513,I6YPOSofrpnTwRm8b,b8Qe150xVaJsnDSv,name,b8Qe150xVaJsnDSv,XXra5dzn8tcLOxYZIE7pPof49Hh)
	ZCkrKgME82qhdlIzND1oSQH(IOW5tBEoVT3rR0l1QncxM,512)
	return
def A1AzoeBtPk85Ld4JHaK9xG(url):
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(Q49IsrlSuYRAVbGKhwdckLDOetF2PZ,'GET',url,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'ELCINEMA-TITLES2-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	IOW5tBEoVT3rR0l1QncxM = A4bweYZNUO71DjmSoIfqW.BeautifulSoup(jLtdbeYiQHnf4SpU2MTly,'html.parser',multi_valued_attributes=None)
	JQjNkD10xehK8bXUalY3EgZAVmvI = IOW5tBEoVT3rR0l1QncxM.find_all('li')
	SRu8HDoOiwJBFUmVNQbdr2XIKjkf,items = [],[]
	for OTKx7aVb2hdS16Wrweky4FXfIN0g9 in JQjNkD10xehK8bXUalY3EgZAVmvI:
		if not OTKx7aVb2hdS16Wrweky4FXfIN0g9.find(class_='thumbnail-wrapper'): continue
		if not OTKx7aVb2hdS16Wrweky4FXfIN0g9.find(class_=['unstyled','unstyled text-center']): continue
		if OTKx7aVb2hdS16Wrweky4FXfIN0g9.find(class_='hide'): continue
		title = OTKx7aVb2hdS16Wrweky4FXfIN0g9.find(class_=['unstyled','unstyled text-center'])
		name = title.find('a').text
		if name in SRu8HDoOiwJBFUmVNQbdr2XIKjkf: continue
		SRu8HDoOiwJBFUmVNQbdr2XIKjkf.append(name)
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = wQjs1XZ3AO24g8y9bEeoKMiGIu7+title.find('a').get('href')
		if '/search/work/' in url: I6YPOSofrpnTwRm8b = OTKx7aVb2hdS16Wrweky4FXfIN0g9.find('img').get('src')
		elif '/search/person/' in url: I6YPOSofrpnTwRm8b = OTKx7aVb2hdS16Wrweky4FXfIN0g9.find('img').get('data-src')
		elif '/search/video/' in url: I6YPOSofrpnTwRm8b = OTKx7aVb2hdS16Wrweky4FXfIN0g9.find('img').get('data-src')
		else: I6YPOSofrpnTwRm8b = OTKx7aVb2hdS16Wrweky4FXfIN0g9.find('img').get('src')
		if hDTluNxe7tCwrpqXHzdEcYRfbs:
			name = name.encode(OVauxZzLI10vcXT74K)
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3.encode(OVauxZzLI10vcXT74K)
			I6YPOSofrpnTwRm8b = I6YPOSofrpnTwRm8b.encode(OVauxZzLI10vcXT74K)
		name = name.strip(pldxivXC5wbTB2O8q)
		items.append((name,pcA1dzy7LXwGfMPg9mTkuh5tine3,I6YPOSofrpnTwRm8b))
	if '/search/person/' in url: items = sorted(items,reverse=False,key=lambda key: key[0])
	for name,pcA1dzy7LXwGfMPg9mTkuh5tine3,I6YPOSofrpnTwRm8b in items:
		if '/search/video/' in url: MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+name,pcA1dzy7LXwGfMPg9mTkuh5tine3,522,I6YPOSofrpnTwRm8b)
		elif '/search/person/' in url: MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+name,pcA1dzy7LXwGfMPg9mTkuh5tine3,513,I6YPOSofrpnTwRm8b,b8Qe150xVaJsnDSv,name)
		else: MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+name,pcA1dzy7LXwGfMPg9mTkuh5tine3,516,I6YPOSofrpnTwRm8b,b8Qe150xVaJsnDSv,name)
	return
def IL7uCYcviO(text):
	text = text.replace('الإعلان',b8Qe150xVaJsnDSv).replace('لفيلم',b8Qe150xVaJsnDSv).replace('الرسمي',b8Qe150xVaJsnDSv)
	text = text.replace('إعلان',b8Qe150xVaJsnDSv).replace('فيلم',b8Qe150xVaJsnDSv).replace('البرومو',b8Qe150xVaJsnDSv)
	text = text.replace('التشويقي',b8Qe150xVaJsnDSv).replace('لمسلسل',b8Qe150xVaJsnDSv).replace('مسلسل',b8Qe150xVaJsnDSv)
	text = text.replace(':',b8Qe150xVaJsnDSv).replace(')',b8Qe150xVaJsnDSv).replace('(',b8Qe150xVaJsnDSv).replace(',',b8Qe150xVaJsnDSv)
	text = text.replace('_',b8Qe150xVaJsnDSv).replace(';',b8Qe150xVaJsnDSv).replace('-',b8Qe150xVaJsnDSv).replace('.',b8Qe150xVaJsnDSv)
	text = text.replace('\'',b8Qe150xVaJsnDSv).replace('\"',b8Qe150xVaJsnDSv)
	text = text.replace(eiopkn4y9uWDQ5,pldxivXC5wbTB2O8q).replace(R1BKXhzpGH6CoO9jLsPwQWu,pldxivXC5wbTB2O8q).replace(k5bCDErUSmv,pldxivXC5wbTB2O8q)
	text = text.strip(pldxivXC5wbTB2O8q)
	uYECF2K8X4LG9NxW7dbQSzPOeptDl = text.count(pldxivXC5wbTB2O8q)+1
	if uYECF2K8X4LG9NxW7dbQSzPOeptDl==1:
		HOz7AXoL1Tk(text)
		return
	MQtuaShrKTbdZFJ5nsR7D('link',WbzmKSZiuOYrBN7oysJ2dUv+rC3Tlno96KjLDIvBaSWUbR8+'==== كلمات للبحث ===='+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999)
	m5nW2H4EhGws8ROiIj1V = text.split(pldxivXC5wbTB2O8q)
	eoY9miB0KVdqzs = pow(2,uYECF2K8X4LG9NxW7dbQSzPOeptDl)
	jj1Dtlqkzf = []
	def fuhbLvncsKHGw4Pr20(wVGecQ548yNtHM2kxn9h3g,MbzQZD68npFA):
		if wVGecQ548yNtHM2kxn9h3g=='1': return MbzQZD68npFA
		return b8Qe150xVaJsnDSv
	for s9s45taoNBh60XL1zykOmTK3jJCrE in range(eoY9miB0KVdqzs,0,-1):
		XGTscou9zSdBwhO0 = list(uYECF2K8X4LG9NxW7dbQSzPOeptDl*'0'+bin(s9s45taoNBh60XL1zykOmTK3jJCrE)[2:])[-uYECF2K8X4LG9NxW7dbQSzPOeptDl:]
		XGTscou9zSdBwhO0 = reversed(XGTscou9zSdBwhO0)
		wnsCBgrI9EJtPdyYp3T7bocXF = map(fuhbLvncsKHGw4Pr20,XGTscou9zSdBwhO0,m5nW2H4EhGws8ROiIj1V)
		title = pldxivXC5wbTB2O8q.join(filter(None,wnsCBgrI9EJtPdyYp3T7bocXF))
		if hDTluNxe7tCwrpqXHzdEcYRfbs: HoXz65T8ph1CMeZgF = title.decode(OVauxZzLI10vcXT74K)
		else: HoXz65T8ph1CMeZgF = title
		if len(HoXz65T8ph1CMeZgF)>2 and title not in jj1Dtlqkzf:
			jj1Dtlqkzf.append(title)
			MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,b8Qe150xVaJsnDSv,523,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,title)
	return
def HOz7AXoL1Tk(RRk9Ki5nPSfAZqC):
	if hDTluNxe7tCwrpqXHzdEcYRfbs:
		RRk9Ki5nPSfAZqC = RRk9Ki5nPSfAZqC.decode(OVauxZzLI10vcXT74K)
		import arabic_reshaper as PfVYURyiGu,bidi.algorithm as cEQtfYbzRv8Z
		RRk9Ki5nPSfAZqC = PfVYURyiGu.ArabicReshaper().reshape(RRk9Ki5nPSfAZqC)
		RRk9Ki5nPSfAZqC = cEQtfYbzRv8Z.get_display(RRk9Ki5nPSfAZqC)
	import jtKsxUZvgl
	RRk9Ki5nPSfAZqC = FT2oXWtPQpVGuexmLqKN3srdzYn(ffYFzrCS3UOxjkybwQ1cXeB6oIlVp=RRk9Ki5nPSfAZqC)
	jtKsxUZvgl.kstJfK6jHQWrXDSMRIGB7(RRk9Ki5nPSfAZqC)
	return
def fFcaVy7dJu3AZNvq4CbzLoh(url):
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(Q49IsrlSuYRAVbGKhwdckLDOetF2PZ,'GET',url,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'ELCINEMA-INDEXES_LISTS-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	IOW5tBEoVT3rR0l1QncxM = A4bweYZNUO71DjmSoIfqW.BeautifulSoup(jLtdbeYiQHnf4SpU2MTly,'html.parser',multi_valued_attributes=None)
	OTKx7aVb2hdS16Wrweky4FXfIN0g9 = IOW5tBEoVT3rR0l1QncxM.find(class_='list-separator list-title')
	YRtyADTLUrGc = OTKx7aVb2hdS16Wrweky4FXfIN0g9.find_all('a')
	items = []
	for title in YRtyADTLUrGc:
		name = title.text
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = wQjs1XZ3AO24g8y9bEeoKMiGIu7+title.get('href')
		if hDTluNxe7tCwrpqXHzdEcYRfbs:
			name = name.encode(OVauxZzLI10vcXT74K)
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3.encode(OVauxZzLI10vcXT74K)
		if '#' not in pcA1dzy7LXwGfMPg9mTkuh5tine3: items.append((name,pcA1dzy7LXwGfMPg9mTkuh5tine3))
	items = sorted(items,reverse=False,key=lambda key: key[0])
	for tgoJCpq8KGrdaUSjsLh0FTxDRPfIAB in items:
		name,pcA1dzy7LXwGfMPg9mTkuh5tine3 = tgoJCpq8KGrdaUSjsLh0FTxDRPfIAB
		MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+name,pcA1dzy7LXwGfMPg9mTkuh5tine3,518)
	return
def GGOxXED3hopU4qeSl(url):
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(Q49IsrlSuYRAVbGKhwdckLDOetF2PZ,'GET',url,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'ELCINEMA-INDEXES_TITLES-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	IOW5tBEoVT3rR0l1QncxM = A4bweYZNUO71DjmSoIfqW.BeautifulSoup(jLtdbeYiQHnf4SpU2MTly,'html.parser',multi_valued_attributes=None)
	JQjNkD10xehK8bXUalY3EgZAVmvI = IOW5tBEoVT3rR0l1QncxM.find(class_='expand').find_all('tr')
	for OTKx7aVb2hdS16Wrweky4FXfIN0g9 in JQjNkD10xehK8bXUalY3EgZAVmvI:
		ImhBZUA7Rzb3rNS = OTKx7aVb2hdS16Wrweky4FXfIN0g9.find_all('a')
		if not ImhBZUA7Rzb3rNS: continue
		I6YPOSofrpnTwRm8b = OTKx7aVb2hdS16Wrweky4FXfIN0g9.find('img').get('data-src')
		name = ImhBZUA7Rzb3rNS[1].text
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = wQjs1XZ3AO24g8y9bEeoKMiGIu7+ImhBZUA7Rzb3rNS[1].get('href')
		Sex9NRzWk5VZfFYbqagB4UA = OTKx7aVb2hdS16Wrweky4FXfIN0g9.find(class_='legend')
		if Sex9NRzWk5VZfFYbqagB4UA: Sex9NRzWk5VZfFYbqagB4UA = Sex9NRzWk5VZfFYbqagB4UA.text
		if hDTluNxe7tCwrpqXHzdEcYRfbs:
			name = name.encode(OVauxZzLI10vcXT74K)
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3.encode(OVauxZzLI10vcXT74K)
			I6YPOSofrpnTwRm8b = I6YPOSofrpnTwRm8b.encode(OVauxZzLI10vcXT74K)
		XXra5dzn8tcLOxYZIE7pPof49Hh = {}
		if Sex9NRzWk5VZfFYbqagB4UA: XXra5dzn8tcLOxYZIE7pPof49Hh['stars'] = Sex9NRzWk5VZfFYbqagB4UA
		if '/work/' in pcA1dzy7LXwGfMPg9mTkuh5tine3:
			MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+name,pcA1dzy7LXwGfMPg9mTkuh5tine3,516,I6YPOSofrpnTwRm8b,b8Qe150xVaJsnDSv,name,b8Qe150xVaJsnDSv,XXra5dzn8tcLOxYZIE7pPof49Hh)
		elif '/person/' in pcA1dzy7LXwGfMPg9mTkuh5tine3: MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+name,pcA1dzy7LXwGfMPg9mTkuh5tine3,513,I6YPOSofrpnTwRm8b,b8Qe150xVaJsnDSv,name,b8Qe150xVaJsnDSv,XXra5dzn8tcLOxYZIE7pPof49Hh)
	ZCkrKgME82qhdlIzND1oSQH(IOW5tBEoVT3rR0l1QncxM,518)
	return
def eOGVaAbh2Id(url):
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(Q49IsrlSuYRAVbGKhwdckLDOetF2PZ,'GET',url,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'ELCINEMA-VIDEOS_LISTS-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	IOW5tBEoVT3rR0l1QncxM = A4bweYZNUO71DjmSoIfqW.BeautifulSoup(jLtdbeYiQHnf4SpU2MTly,'html.parser',multi_valued_attributes=None)
	YRtyADTLUrGc = IOW5tBEoVT3rR0l1QncxM.find_all(class_='section-title inline')
	tzdvaEpMHOCZLXDYg08T = IOW5tBEoVT3rR0l1QncxM.find_all(class_='button green small right')
	items = zip(YRtyADTLUrGc,tzdvaEpMHOCZLXDYg08T)
	for title,pcA1dzy7LXwGfMPg9mTkuh5tine3 in items:
		title = title.text
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = wQjs1XZ3AO24g8y9bEeoKMiGIu7+pcA1dzy7LXwGfMPg9mTkuh5tine3.get('href')
		if hDTluNxe7tCwrpqXHzdEcYRfbs:
			title = title.encode(OVauxZzLI10vcXT74K)
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3.encode(OVauxZzLI10vcXT74K)
		title = title.replace(eiopkn4y9uWDQ5,pldxivXC5wbTB2O8q).replace(R1BKXhzpGH6CoO9jLsPwQWu,pldxivXC5wbTB2O8q).replace(k5bCDErUSmv,pldxivXC5wbTB2O8q)
		MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,521)
	return
def uHeCtPVDhEMx2J7cNvQdm5(url):
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(Q49IsrlSuYRAVbGKhwdckLDOetF2PZ,'GET',url,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'ELCINEMA-VIDEOS_TITLES-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	IOW5tBEoVT3rR0l1QncxM = A4bweYZNUO71DjmSoIfqW.BeautifulSoup(jLtdbeYiQHnf4SpU2MTly,'html.parser',multi_valued_attributes=None)
	vJEGaODzsnedLcj387hiV0TCw4r = IOW5tBEoVT3rR0l1QncxM.find(class_='large-block-grid-4 medium-block-grid-4 small-block-grid-2')
	JQjNkD10xehK8bXUalY3EgZAVmvI = vJEGaODzsnedLcj387hiV0TCw4r.find_all('li')
	for OTKx7aVb2hdS16Wrweky4FXfIN0g9 in JQjNkD10xehK8bXUalY3EgZAVmvI:
		title = OTKx7aVb2hdS16Wrweky4FXfIN0g9.find(class_='title').text
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = wQjs1XZ3AO24g8y9bEeoKMiGIu7+OTKx7aVb2hdS16Wrweky4FXfIN0g9.find('a').get('href')
		I6YPOSofrpnTwRm8b = OTKx7aVb2hdS16Wrweky4FXfIN0g9.find('img').get('data-src')
		D5taEr6hnuFCcRMpTq4wSoyQOivx = OTKx7aVb2hdS16Wrweky4FXfIN0g9.find(class_='duration').text
		if hDTluNxe7tCwrpqXHzdEcYRfbs:
			title = title.encode(OVauxZzLI10vcXT74K)
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3.encode(OVauxZzLI10vcXT74K)
			I6YPOSofrpnTwRm8b = I6YPOSofrpnTwRm8b.encode(OVauxZzLI10vcXT74K)
			D5taEr6hnuFCcRMpTq4wSoyQOivx = D5taEr6hnuFCcRMpTq4wSoyQOivx.encode(OVauxZzLI10vcXT74K)
		D5taEr6hnuFCcRMpTq4wSoyQOivx = D5taEr6hnuFCcRMpTq4wSoyQOivx.replace(eeN6dTEnkJxI,b8Qe150xVaJsnDSv).strip(pldxivXC5wbTB2O8q)
		MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,522,I6YPOSofrpnTwRm8b,D5taEr6hnuFCcRMpTq4wSoyQOivx)
	ZCkrKgME82qhdlIzND1oSQH(IOW5tBEoVT3rR0l1QncxM,521)
	return
def Hkij627uCDJKyIM(url):
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(Q49IsrlSuYRAVbGKhwdckLDOetF2PZ,'GET',url,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'ELCINEMA-PLAY-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	IOW5tBEoVT3rR0l1QncxM = A4bweYZNUO71DjmSoIfqW.BeautifulSoup(jLtdbeYiQHnf4SpU2MTly,'html.parser',multi_valued_attributes=None)
	pcA1dzy7LXwGfMPg9mTkuh5tine3 = IOW5tBEoVT3rR0l1QncxM.find(class_='flex-video').find('iframe').get('src')
	if hDTluNxe7tCwrpqXHzdEcYRfbs: pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3.encode(OVauxZzLI10vcXT74K)
	import QNeGEq8sWn
	QNeGEq8sWn.nqu2GCT9gHAbpIPSFZz5([pcA1dzy7LXwGfMPg9mTkuh5tine3],QQ8pvXNcBfVkP5rRJ7o,'video',url)
	return
def kstJfK6jHQWrXDSMRIGB7(search):
	search,v7Rxw52Z4X0,showDialogs = JimhUH0SEf6w(search)
	if search==b8Qe150xVaJsnDSv: search = FT2oXWtPQpVGuexmLqKN3srdzYn()
	if search==b8Qe150xVaJsnDSv: return
	search = search.replace(pldxivXC5wbTB2O8q,'%20')
	url = wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/search/?q='+search
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(Q49IsrlSuYRAVbGKhwdckLDOetF2PZ,'GET',url,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'ELCINEMA-SEARCH-1st')
	if not b3HKopTY9zLUyhJmt.succeeded:
		ZR1fdSsBJVeLUm9y7rit2CHTKau = wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/search_entity/?q='+search+'&entity=work'
		eiFs3pQPyZtjb0W = wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/search_entity/?q='+search+'&entity=person'
		XZ8LDH3n70Bpble6 = wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/search_entity/?q='+search+'&entity=video'
		MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'بحث عن أعمال',ZR1fdSsBJVeLUm9y7rit2CHTKau,513,b8Qe150xVaJsnDSv,search)
		MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'بحث عن أشخاص',eiFs3pQPyZtjb0W,513,b8Qe150xVaJsnDSv,search)
		MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'بحث عن فيديوهات',XZ8LDH3n70Bpble6,513,b8Qe150xVaJsnDSv,search)
		return
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	IOW5tBEoVT3rR0l1QncxM = A4bweYZNUO71DjmSoIfqW.BeautifulSoup(jLtdbeYiQHnf4SpU2MTly,'html.parser',multi_valued_attributes=None)
	JQjNkD10xehK8bXUalY3EgZAVmvI = IOW5tBEoVT3rR0l1QncxM.find_all(class_='section-title left')
	for OTKx7aVb2hdS16Wrweky4FXfIN0g9 in JQjNkD10xehK8bXUalY3EgZAVmvI:
		title = OTKx7aVb2hdS16Wrweky4FXfIN0g9.text
		if hDTluNxe7tCwrpqXHzdEcYRfbs:
			title = title.encode(OVauxZzLI10vcXT74K)
		title = title.split('(',1)[0].strip(pldxivXC5wbTB2O8q)
		if   'أعمال' in title: pcA1dzy7LXwGfMPg9mTkuh5tine3 = url.replace('/search/','/search/work/')
		elif 'أشخاص' in title: pcA1dzy7LXwGfMPg9mTkuh5tine3 = url.replace('/search/','/search/person/')
		elif 'فيديوهات' in title: pcA1dzy7LXwGfMPg9mTkuh5tine3 = url.replace('/search/','/search/video/')
		else: continue
		MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,513)
	return
def jhf9lUFR5qQXMJ0kIVtLSnP(url,text):
	global HiGtBb5m673JPE,cEjiOo6IGCD2pAzJ4B9bkmXYT
	if '/seasonals' in url:
		HiGtBb5m673JPE = ['seasonal','year','category']
		cEjiOo6IGCD2pAzJ4B9bkmXYT = ['seasonal','year','category']
	elif '/lineup' in url:
		HiGtBb5m673JPE = ['category','foreign','type']
		cEjiOo6IGCD2pAzJ4B9bkmXYT = ['category','foreign','type']
	eszTQbMvkmRwCAxGDPdYJUi(url,text)
	return
def wwtH4LbAYj2OvQ7DTpdJx(url):
	url = url.split('/smartemadfilter?')[0]
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(Q49IsrlSuYRAVbGKhwdckLDOetF2PZ,'GET',url,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'ELCINEMA-GET_FILTERS_BLOCKS-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('form action="/(.*?)</form>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
	RYqsiFGfj07T2VKXrx3y6Hb = YYBlm36zd0Jst18LXwo4.findall('<select name="(.*?)" id="(.*?)".*?>(.*?)</div>',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	return RYqsiFGfj07T2VKXrx3y6Hb
def DwEj517Ty94KWU8Y2nSZI3C6vgG(OTKx7aVb2hdS16Wrweky4FXfIN0g9):
	items = YYBlm36zd0Jst18LXwo4.findall('<option value="(.*?)">(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	return items
def DahRB3A9gNvuFT1eI6lzO5Z(url):
	e3To7sm0Nzn1CruYWxGh = url.split('/smartemadfilter?')[0]
	cCxjKQGYDfZWpd5 = Wl2eu1PavfQ(url,'url')
	url = url.replace('/smartemadfilter?','/?utf8=%E2%9C%93&')
	return url
def NhMgI14HOutC8yYwqW6cRUA9bK0(XFJqUiePG7aSf0N,url):
	JXAZh9EQjse2qirMa8DRSYvGLO0kgf = W57WXlwPhyrfVu6oij(XFJqUiePG7aSf0N,'all_filters')
	GSh0nJxEXgZjd48u7mBwWOeafyAp5b = url+'/smartemadfilter?'+JXAZh9EQjse2qirMa8DRSYvGLO0kgf
	GSh0nJxEXgZjd48u7mBwWOeafyAp5b = DahRB3A9gNvuFT1eI6lzO5Z(GSh0nJxEXgZjd48u7mBwWOeafyAp5b)
	return GSh0nJxEXgZjd48u7mBwWOeafyAp5b
def eszTQbMvkmRwCAxGDPdYJUi(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==b8Qe150xVaJsnDSv: us8FE67ImlDBS,bxTQdyVe57Bh0P8sG = b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv
	else: us8FE67ImlDBS,bxTQdyVe57Bh0P8sG = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if HiGtBb5m673JPE[0]+'=' not in us8FE67ImlDBS: Z8s0Lov2UiWF1qGjO = HiGtBb5m673JPE[0]
		for FbcUxvE17ewlWNBHgS8Jn in range(len(HiGtBb5m673JPE[0:-1])):
			if HiGtBb5m673JPE[FbcUxvE17ewlWNBHgS8Jn]+'=' in us8FE67ImlDBS: Z8s0Lov2UiWF1qGjO = HiGtBb5m673JPE[FbcUxvE17ewlWNBHgS8Jn+1]
		x5gCnOb9wjSPit6sVclHNZIkFyD0 = us8FE67ImlDBS+'&'+Z8s0Lov2UiWF1qGjO+'=0'
		XFJqUiePG7aSf0N = bxTQdyVe57Bh0P8sG+'&'+Z8s0Lov2UiWF1qGjO+'=0'
		Dnkl4UdcKRILWi6m7TqYJh98vu = x5gCnOb9wjSPit6sVclHNZIkFyD0.strip('&')+'___'+XFJqUiePG7aSf0N.strip('&')
		JXAZh9EQjse2qirMa8DRSYvGLO0kgf = W57WXlwPhyrfVu6oij(bxTQdyVe57Bh0P8sG,'modified_filters')
		MUJCtfYVBLODrFbaZn = url+'/smartemadfilter?'+JXAZh9EQjse2qirMa8DRSYvGLO0kgf
	elif type=='ALL_ITEMS_FILTER':
		pRfP0YvVnLJdukUHstQA8cm = W57WXlwPhyrfVu6oij(us8FE67ImlDBS,'modified_values')
		pRfP0YvVnLJdukUHstQA8cm = SgrGWuAHcLKBQMJetb9(pRfP0YvVnLJdukUHstQA8cm)
		if bxTQdyVe57Bh0P8sG!=b8Qe150xVaJsnDSv: bxTQdyVe57Bh0P8sG = W57WXlwPhyrfVu6oij(bxTQdyVe57Bh0P8sG,'modified_filters')
		if bxTQdyVe57Bh0P8sG==b8Qe150xVaJsnDSv: MUJCtfYVBLODrFbaZn = url
		else: MUJCtfYVBLODrFbaZn = url+'/smartemadfilter?'+bxTQdyVe57Bh0P8sG
		MUJCtfYVBLODrFbaZn = DahRB3A9gNvuFT1eI6lzO5Z(MUJCtfYVBLODrFbaZn)
		MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'أظهار قائمة الفيديو التي تم اختيارها ',MUJCtfYVBLODrFbaZn,511)
		MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+' [[   '+pRfP0YvVnLJdukUHstQA8cm+'   ]]',MUJCtfYVBLODrFbaZn,511)
		MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+' ===== ===== ===== '+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999)
	RYqsiFGfj07T2VKXrx3y6Hb = wwtH4LbAYj2OvQ7DTpdJx(url)
	dict = {}
	for name,BnHr3VSlN5cMhZ7miAfGLovdbQJWa,OTKx7aVb2hdS16Wrweky4FXfIN0g9 in RYqsiFGfj07T2VKXrx3y6Hb:
		name = name.replace('--',b8Qe150xVaJsnDSv)
		items = DwEj517Ty94KWU8Y2nSZI3C6vgG(OTKx7aVb2hdS16Wrweky4FXfIN0g9)
		if '=' not in MUJCtfYVBLODrFbaZn: MUJCtfYVBLODrFbaZn = url
		if type=='SPECIFIED_FILTER':
			if BnHr3VSlN5cMhZ7miAfGLovdbQJWa not in HiGtBb5m673JPE: continue
			if Z8s0Lov2UiWF1qGjO!=BnHr3VSlN5cMhZ7miAfGLovdbQJWa: continue
			elif len(items)<2:
				if BnHr3VSlN5cMhZ7miAfGLovdbQJWa==HiGtBb5m673JPE[-1]:
					url = DahRB3A9gNvuFT1eI6lzO5Z(url)
					T5IfFGVvNL3x4wAtY8HrUs7(url)
				else: eszTQbMvkmRwCAxGDPdYJUi(MUJCtfYVBLODrFbaZn,'SPECIFIED_FILTER___'+Dnkl4UdcKRILWi6m7TqYJh98vu)
				return
			else:
				MUJCtfYVBLODrFbaZn = DahRB3A9gNvuFT1eI6lzO5Z(MUJCtfYVBLODrFbaZn)
				if BnHr3VSlN5cMhZ7miAfGLovdbQJWa==HiGtBb5m673JPE[-1]: MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'الجميع',MUJCtfYVBLODrFbaZn,511)
				else: MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'الجميع',MUJCtfYVBLODrFbaZn,515,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,Dnkl4UdcKRILWi6m7TqYJh98vu)
		elif type=='ALL_ITEMS_FILTER':
			if BnHr3VSlN5cMhZ7miAfGLovdbQJWa not in cEjiOo6IGCD2pAzJ4B9bkmXYT: continue
			x5gCnOb9wjSPit6sVclHNZIkFyD0 = us8FE67ImlDBS+'&'+BnHr3VSlN5cMhZ7miAfGLovdbQJWa+'=0'
			XFJqUiePG7aSf0N = bxTQdyVe57Bh0P8sG+'&'+BnHr3VSlN5cMhZ7miAfGLovdbQJWa+'=0'
			Dnkl4UdcKRILWi6m7TqYJh98vu = x5gCnOb9wjSPit6sVclHNZIkFyD0+'___'+XFJqUiePG7aSf0N
			if   name=='type': name = 'النوع'
			elif name=='category': name = 'العمل'
			elif name=='foreign': name = 'اللغة'
			elif name=='year': name = 'السنة'
			elif name=='seasonal': name = 'الموسم'
			MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'الجميع: '+name,MUJCtfYVBLODrFbaZn,514,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,Dnkl4UdcKRILWi6m7TqYJh98vu)
		dict[BnHr3VSlN5cMhZ7miAfGLovdbQJWa] = {}
		for Y8aiFZsLKw,Ny03TjaY7bBxWwm2GI in items:
			if Ny03TjaY7bBxWwm2GI in v1vJEhoNQBVPkjG: continue
			if 'مصنفات أخرى' in Ny03TjaY7bBxWwm2GI: continue
			if 'الكل' in Ny03TjaY7bBxWwm2GI: continue
			if 'اللغة' in Ny03TjaY7bBxWwm2GI: continue
			Ny03TjaY7bBxWwm2GI = Ny03TjaY7bBxWwm2GI.replace('قائمة ',b8Qe150xVaJsnDSv)
			if   name=='type': name = 'النوع'
			elif name=='category': name = 'العمل'
			elif name=='foreign': name = 'اللغة'
			elif name=='year': name = 'السنة'
			elif name=='seasonal': name = 'الموسم'
			dict[BnHr3VSlN5cMhZ7miAfGLovdbQJWa][Y8aiFZsLKw] = Ny03TjaY7bBxWwm2GI
			x5gCnOb9wjSPit6sVclHNZIkFyD0 = us8FE67ImlDBS+'&'+BnHr3VSlN5cMhZ7miAfGLovdbQJWa+'='+Ny03TjaY7bBxWwm2GI
			XFJqUiePG7aSf0N = bxTQdyVe57Bh0P8sG+'&'+BnHr3VSlN5cMhZ7miAfGLovdbQJWa+'='+Y8aiFZsLKw
			NHEdmMD3qPj4zay2nb5O8xKX = x5gCnOb9wjSPit6sVclHNZIkFyD0+'___'+XFJqUiePG7aSf0N
			if name: title = Ny03TjaY7bBxWwm2GI+' :'+name
			else: title = Ny03TjaY7bBxWwm2GI
			if type=='ALL_ITEMS_FILTER': MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,url,514,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,NHEdmMD3qPj4zay2nb5O8xKX)
			elif type=='SPECIFIED_FILTER' and HiGtBb5m673JPE[-2]+'=' in us8FE67ImlDBS:
				GSh0nJxEXgZjd48u7mBwWOeafyAp5b = NhMgI14HOutC8yYwqW6cRUA9bK0(XFJqUiePG7aSf0N,url)
				MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,GSh0nJxEXgZjd48u7mBwWOeafyAp5b,511)
			else: MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,url,515,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,NHEdmMD3qPj4zay2nb5O8xKX)
	return
def W57WXlwPhyrfVu6oij(J6rINOCGlW5M4SXjgwc9U7,mode):
	J6rINOCGlW5M4SXjgwc9U7 = J6rINOCGlW5M4SXjgwc9U7.replace('=&','=0&')
	J6rINOCGlW5M4SXjgwc9U7 = J6rINOCGlW5M4SXjgwc9U7.strip('&')
	hj1lf3cGzLMURVTKkBZmDoyix28 = {}
	if '=' in J6rINOCGlW5M4SXjgwc9U7:
		items = J6rINOCGlW5M4SXjgwc9U7.split('&')
		for tgoJCpq8KGrdaUSjsLh0FTxDRPfIAB in items:
			VRcGtBaO1xun,Y8aiFZsLKw = tgoJCpq8KGrdaUSjsLh0FTxDRPfIAB.split('=')
			hj1lf3cGzLMURVTKkBZmDoyix28[VRcGtBaO1xun] = Y8aiFZsLKw
	sBF1epSJZbIUAgM4hVLPD50 = b8Qe150xVaJsnDSv
	for key in cEjiOo6IGCD2pAzJ4B9bkmXYT:
		if key in list(hj1lf3cGzLMURVTKkBZmDoyix28.keys()): Y8aiFZsLKw = hj1lf3cGzLMURVTKkBZmDoyix28[key]
		else: Y8aiFZsLKw = '0'
		if '%' not in Y8aiFZsLKw: Y8aiFZsLKw = HHbaVYqFRy6v0c(Y8aiFZsLKw)
		if mode=='modified_values' and Y8aiFZsLKw!='0': sBF1epSJZbIUAgM4hVLPD50 = sBF1epSJZbIUAgM4hVLPD50+' + '+Y8aiFZsLKw
		elif mode=='modified_filters' and Y8aiFZsLKw!='0': sBF1epSJZbIUAgM4hVLPD50 = sBF1epSJZbIUAgM4hVLPD50+'&'+key+'='+Y8aiFZsLKw
		elif mode=='all_filters': sBF1epSJZbIUAgM4hVLPD50 = sBF1epSJZbIUAgM4hVLPD50+'&'+key+'='+Y8aiFZsLKw
	sBF1epSJZbIUAgM4hVLPD50 = sBF1epSJZbIUAgM4hVLPD50.strip(' + ')
	sBF1epSJZbIUAgM4hVLPD50 = sBF1epSJZbIUAgM4hVLPD50.strip('&')
	sBF1epSJZbIUAgM4hVLPD50 = sBF1epSJZbIUAgM4hVLPD50.replace('=0','=')
	return sBF1epSJZbIUAgM4hVLPD50
HiGtBb5m673JPE = []
cEjiOo6IGCD2pAzJ4B9bkmXYT = []
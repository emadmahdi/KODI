# -*- coding: utf-8 -*-
from hIVCFnfxSO import *
ALwGbyiBFzY7H = 'FAVORITES'
def BBC8ziWGv2TLl5sjHm9uZk14b(ZZtDTHnBXMz,nWe3b65Ec0Ru2LahsKwNzZPjm):
	if   ZZtDTHnBXMz==270: kpd8hRM9mn = faCzcxFZWbO9ULQs70Y(nWe3b65Ec0Ru2LahsKwNzZPjm)
	else: kpd8hRM9mn = False
	return kpd8hRM9mn
def L4Uf2PYJbSnDd5NBu(czG0PxAmlw4vtWrH5eL3RubT,nWe3b65Ec0Ru2LahsKwNzZPjm,N54jKc7gqtke6YRlzHvydXbA3hs):
	if not czG0PxAmlw4vtWrH5eL3RubT: return
	if   N54jKc7gqtke6YRlzHvydXbA3hs=='UP1'	: xnJiQ69aNhw5gtRyOjI(nWe3b65Ec0Ru2LahsKwNzZPjm,True,qHYIWnOZLPkrQU)
	elif N54jKc7gqtke6YRlzHvydXbA3hs=='DOWN1'	: xnJiQ69aNhw5gtRyOjI(nWe3b65Ec0Ru2LahsKwNzZPjm,False,qHYIWnOZLPkrQU)
	elif N54jKc7gqtke6YRlzHvydXbA3hs=='UP4'	: xnJiQ69aNhw5gtRyOjI(nWe3b65Ec0Ru2LahsKwNzZPjm,True,NvHugPosYDzRJ)
	elif N54jKc7gqtke6YRlzHvydXbA3hs=='DOWN4'	: xnJiQ69aNhw5gtRyOjI(nWe3b65Ec0Ru2LahsKwNzZPjm,False,NvHugPosYDzRJ)
	elif N54jKc7gqtke6YRlzHvydXbA3hs=='ADD1'	: EEfkjMH04yzRFSaOVo8(nWe3b65Ec0Ru2LahsKwNzZPjm)
	elif N54jKc7gqtke6YRlzHvydXbA3hs=='REMOVE1': c64EM7mSg5kX(nWe3b65Ec0Ru2LahsKwNzZPjm)
	elif N54jKc7gqtke6YRlzHvydXbA3hs=='DELETELIST': iY3dJuRZ1Q5AXo8FUavM7nSIpL4(nWe3b65Ec0Ru2LahsKwNzZPjm)
	return
def faCzcxFZWbO9ULQs70Y(nWe3b65Ec0Ru2LahsKwNzZPjm):
	FCkYuy3RAwg6aMnlxehI5si1 = osUVxR3cueih25tjHwQf()
	if nWe3b65Ec0Ru2LahsKwNzZPjm in list(FCkYuy3RAwg6aMnlxehI5si1.keys()):
		try:
			BBcG1xqm5gHkwo24iLb6XyWrh0Q = FCkYuy3RAwg6aMnlxehI5si1[nWe3b65Ec0Ru2LahsKwNzZPjm]
			if LzYQg91SIxDeOGtCKd5 and nWe3b65Ec0Ru2LahsKwNzZPjm in ['5','11','12','13']:
				for A60AIQZCYRzdhaeWfOtmrSUVoq2nN,c17XeRIH2gVh3px8sw,uuNDjbit4hOpx,ZZtDTHnBXMz,ChvkSxHr6QoKJg,EAlZ2zKn6uagcqtY3yBoMxDmSbOwk,pnmsJqCWIHVk2Y6xPvl9Q0Ez8r,czG0PxAmlw4vtWrH5eL3RubT,ZzHaCLyPtIk1iurbW in BBcG1xqm5gHkwo24iLb6XyWrh0Q:
					if A60AIQZCYRzdhaeWfOtmrSUVoq2nN=='video':
						MQtuaShrKTbdZFJ5nsR7D('video',rC3Tlno96KjLDIvBaSWUbR8+'تشغيل من الأعلى إلى الأسفل'+hAIp8kmC36T5WFPMSXOwnNbtD,uuNDjbit4hOpx,ZZtDTHnBXMz,ChvkSxHr6QoKJg,EAlZ2zKn6uagcqtY3yBoMxDmSbOwk,pnmsJqCWIHVk2Y6xPvl9Q0Ez8r,czG0PxAmlw4vtWrH5eL3RubT)
						MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+' ===== ===== ===== '+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999)
						break
			for A60AIQZCYRzdhaeWfOtmrSUVoq2nN,c17XeRIH2gVh3px8sw,uuNDjbit4hOpx,ZZtDTHnBXMz,ChvkSxHr6QoKJg,EAlZ2zKn6uagcqtY3yBoMxDmSbOwk,pnmsJqCWIHVk2Y6xPvl9Q0Ez8r,czG0PxAmlw4vtWrH5eL3RubT,ZzHaCLyPtIk1iurbW in BBcG1xqm5gHkwo24iLb6XyWrh0Q:
				MQtuaShrKTbdZFJ5nsR7D(A60AIQZCYRzdhaeWfOtmrSUVoq2nN,c17XeRIH2gVh3px8sw,uuNDjbit4hOpx,ZZtDTHnBXMz,ChvkSxHr6QoKJg,EAlZ2zKn6uagcqtY3yBoMxDmSbOwk,pnmsJqCWIHVk2Y6xPvl9Q0Ez8r,czG0PxAmlw4vtWrH5eL3RubT,ZzHaCLyPtIk1iurbW)
		except:
			FCkYuy3RAwg6aMnlxehI5si1 = dyWw4klir2R3uM8DUthJxKP(KNTV1H9Dl32a6yxiUEBdvZ7qgr)
			BBcG1xqm5gHkwo24iLb6XyWrh0Q = FCkYuy3RAwg6aMnlxehI5si1[nWe3b65Ec0Ru2LahsKwNzZPjm]
			for A60AIQZCYRzdhaeWfOtmrSUVoq2nN,c17XeRIH2gVh3px8sw,uuNDjbit4hOpx,ZZtDTHnBXMz,ChvkSxHr6QoKJg,EAlZ2zKn6uagcqtY3yBoMxDmSbOwk,pnmsJqCWIHVk2Y6xPvl9Q0Ez8r,czG0PxAmlw4vtWrH5eL3RubT,ZzHaCLyPtIk1iurbW in BBcG1xqm5gHkwo24iLb6XyWrh0Q:
				MQtuaShrKTbdZFJ5nsR7D(A60AIQZCYRzdhaeWfOtmrSUVoq2nN,c17XeRIH2gVh3px8sw,uuNDjbit4hOpx,ZZtDTHnBXMz,ChvkSxHr6QoKJg,EAlZ2zKn6uagcqtY3yBoMxDmSbOwk,pnmsJqCWIHVk2Y6xPvl9Q0Ez8r,czG0PxAmlw4vtWrH5eL3RubT,ZzHaCLyPtIk1iurbW)
	return
def EEfkjMH04yzRFSaOVo8(nWe3b65Ec0Ru2LahsKwNzZPjm):
	A60AIQZCYRzdhaeWfOtmrSUVoq2nN,c17XeRIH2gVh3px8sw,uuNDjbit4hOpx,ZZtDTHnBXMz,ChvkSxHr6QoKJg,EAlZ2zKn6uagcqtY3yBoMxDmSbOwk,pnmsJqCWIHVk2Y6xPvl9Q0Ez8r,czG0PxAmlw4vtWrH5eL3RubT,ZzHaCLyPtIk1iurbW = rhoGF8ta4UesmTucY6V2O1A(ZqDQCMovyXKFG7ki4BrahuWt1IS8)
	if nWe3b65Ec0Ru2LahsKwNzZPjm in ['5','11','12','13'] and A60AIQZCYRzdhaeWfOtmrSUVoq2nN!='video':
		tuJ9fQgDl8oineCrFPT('','','رسالة من المبرمج','هذا العنصر ليس ملف فيديو .. قوائم التشغيل فائدتها تشغيل الفيديوهات خلف بعضها أوتوماتيكيا .. ولهذا قوائم التشغيل يجب أن تحتوي على فيديوهات فقط')
		return
	KKHsXdETa4uckBQJWlRVPU3mbrh = A60AIQZCYRzdhaeWfOtmrSUVoq2nN,c17XeRIH2gVh3px8sw,uuNDjbit4hOpx,ZZtDTHnBXMz,ChvkSxHr6QoKJg,EAlZ2zKn6uagcqtY3yBoMxDmSbOwk,pnmsJqCWIHVk2Y6xPvl9Q0Ez8r,b8Qe150xVaJsnDSv,ZzHaCLyPtIk1iurbW
	FCkYuy3RAwg6aMnlxehI5si1 = osUVxR3cueih25tjHwQf()
	bbRrGS0ZmHwaN7uUCKJEejTqDz = {}
	for Bc45y0OZuHfMl8hN in list(FCkYuy3RAwg6aMnlxehI5si1.keys()):
		if Bc45y0OZuHfMl8hN!=nWe3b65Ec0Ru2LahsKwNzZPjm: bbRrGS0ZmHwaN7uUCKJEejTqDz[Bc45y0OZuHfMl8hN] = FCkYuy3RAwg6aMnlxehI5si1[Bc45y0OZuHfMl8hN]
		else:
			if c17XeRIH2gVh3px8sw and c17XeRIH2gVh3px8sw!='..':
				zSfbIyP1aWVRMu = FCkYuy3RAwg6aMnlxehI5si1[Bc45y0OZuHfMl8hN]
				if KKHsXdETa4uckBQJWlRVPU3mbrh in zSfbIyP1aWVRMu:
					TrfkXEdQ5D7e3bcAplO6V = zSfbIyP1aWVRMu.index(KKHsXdETa4uckBQJWlRVPU3mbrh)
					del zSfbIyP1aWVRMu[TrfkXEdQ5D7e3bcAplO6V]
				IImubzG4UdHDYsExQJTvgRp = zSfbIyP1aWVRMu+[KKHsXdETa4uckBQJWlRVPU3mbrh]
				bbRrGS0ZmHwaN7uUCKJEejTqDz[Bc45y0OZuHfMl8hN] = IImubzG4UdHDYsExQJTvgRp
			else: bbRrGS0ZmHwaN7uUCKJEejTqDz[Bc45y0OZuHfMl8hN] = FCkYuy3RAwg6aMnlxehI5si1[Bc45y0OZuHfMl8hN]
	if nWe3b65Ec0Ru2LahsKwNzZPjm not in list(bbRrGS0ZmHwaN7uUCKJEejTqDz.keys()): bbRrGS0ZmHwaN7uUCKJEejTqDz[nWe3b65Ec0Ru2LahsKwNzZPjm] = [KKHsXdETa4uckBQJWlRVPU3mbrh]
	s0dAQXV12m9h5bzve = str(bbRrGS0ZmHwaN7uUCKJEejTqDz)
	if i1thmHk7AZquD4cM0fnp62: s0dAQXV12m9h5bzve = s0dAQXV12m9h5bzve.encode(OVauxZzLI10vcXT74K)
	open(KNTV1H9Dl32a6yxiUEBdvZ7qgr,'wb').write(s0dAQXV12m9h5bzve)
	return
def c64EM7mSg5kX(nWe3b65Ec0Ru2LahsKwNzZPjm):
	A60AIQZCYRzdhaeWfOtmrSUVoq2nN,c17XeRIH2gVh3px8sw,uuNDjbit4hOpx,ZZtDTHnBXMz,ChvkSxHr6QoKJg,EAlZ2zKn6uagcqtY3yBoMxDmSbOwk,pnmsJqCWIHVk2Y6xPvl9Q0Ez8r,czG0PxAmlw4vtWrH5eL3RubT,ZzHaCLyPtIk1iurbW = rhoGF8ta4UesmTucY6V2O1A(ZqDQCMovyXKFG7ki4BrahuWt1IS8)
	KKHsXdETa4uckBQJWlRVPU3mbrh = A60AIQZCYRzdhaeWfOtmrSUVoq2nN,c17XeRIH2gVh3px8sw,uuNDjbit4hOpx,ZZtDTHnBXMz,ChvkSxHr6QoKJg,EAlZ2zKn6uagcqtY3yBoMxDmSbOwk,pnmsJqCWIHVk2Y6xPvl9Q0Ez8r,b8Qe150xVaJsnDSv,ZzHaCLyPtIk1iurbW
	FCkYuy3RAwg6aMnlxehI5si1 = osUVxR3cueih25tjHwQf()
	if nWe3b65Ec0Ru2LahsKwNzZPjm in list(FCkYuy3RAwg6aMnlxehI5si1.keys()) and KKHsXdETa4uckBQJWlRVPU3mbrh in FCkYuy3RAwg6aMnlxehI5si1[nWe3b65Ec0Ru2LahsKwNzZPjm]:
		FCkYuy3RAwg6aMnlxehI5si1[nWe3b65Ec0Ru2LahsKwNzZPjm].remove(KKHsXdETa4uckBQJWlRVPU3mbrh)
		if len(FCkYuy3RAwg6aMnlxehI5si1[nWe3b65Ec0Ru2LahsKwNzZPjm])==LzYQg91SIxDeOGtCKd5: del FCkYuy3RAwg6aMnlxehI5si1[nWe3b65Ec0Ru2LahsKwNzZPjm]
		s0dAQXV12m9h5bzve = str(FCkYuy3RAwg6aMnlxehI5si1)
		if i1thmHk7AZquD4cM0fnp62: s0dAQXV12m9h5bzve = s0dAQXV12m9h5bzve.encode(OVauxZzLI10vcXT74K)
		open(KNTV1H9Dl32a6yxiUEBdvZ7qgr,'wb').write(s0dAQXV12m9h5bzve)
	return
def xnJiQ69aNhw5gtRyOjI(nWe3b65Ec0Ru2LahsKwNzZPjm,dAyWsiZSDeR9zNX41,BemtyIEHaPT4Rq0sw9UpSghov3):
	A60AIQZCYRzdhaeWfOtmrSUVoq2nN,c17XeRIH2gVh3px8sw,uuNDjbit4hOpx,ZZtDTHnBXMz,ChvkSxHr6QoKJg,EAlZ2zKn6uagcqtY3yBoMxDmSbOwk,pnmsJqCWIHVk2Y6xPvl9Q0Ez8r,czG0PxAmlw4vtWrH5eL3RubT,ZzHaCLyPtIk1iurbW = rhoGF8ta4UesmTucY6V2O1A(ZqDQCMovyXKFG7ki4BrahuWt1IS8)
	KKHsXdETa4uckBQJWlRVPU3mbrh = A60AIQZCYRzdhaeWfOtmrSUVoq2nN,c17XeRIH2gVh3px8sw,uuNDjbit4hOpx,ZZtDTHnBXMz,ChvkSxHr6QoKJg,EAlZ2zKn6uagcqtY3yBoMxDmSbOwk,pnmsJqCWIHVk2Y6xPvl9Q0Ez8r,b8Qe150xVaJsnDSv,ZzHaCLyPtIk1iurbW
	FCkYuy3RAwg6aMnlxehI5si1 = osUVxR3cueih25tjHwQf()
	if nWe3b65Ec0Ru2LahsKwNzZPjm in list(FCkYuy3RAwg6aMnlxehI5si1.keys()):
		zSfbIyP1aWVRMu = FCkYuy3RAwg6aMnlxehI5si1[nWe3b65Ec0Ru2LahsKwNzZPjm]
		if KKHsXdETa4uckBQJWlRVPU3mbrh not in zSfbIyP1aWVRMu: return
		hvgOo9D3itx8umIB = len(zSfbIyP1aWVRMu)
		for H9JbVKORYEGt3jo2g in range(LzYQg91SIxDeOGtCKd5,BemtyIEHaPT4Rq0sw9UpSghov3):
			AAUVXbkEdOSGhCj2gJH3NzrD7aKT4 = zSfbIyP1aWVRMu.index(KKHsXdETa4uckBQJWlRVPU3mbrh)
			if dAyWsiZSDeR9zNX41: Lx5UlHYM2rsDA9q4pcSm3XbO = AAUVXbkEdOSGhCj2gJH3NzrD7aKT4-qHYIWnOZLPkrQU
			else: Lx5UlHYM2rsDA9q4pcSm3XbO = AAUVXbkEdOSGhCj2gJH3NzrD7aKT4+qHYIWnOZLPkrQU
			if Lx5UlHYM2rsDA9q4pcSm3XbO>=hvgOo9D3itx8umIB: Lx5UlHYM2rsDA9q4pcSm3XbO = Lx5UlHYM2rsDA9q4pcSm3XbO-hvgOo9D3itx8umIB
			if Lx5UlHYM2rsDA9q4pcSm3XbO<LzYQg91SIxDeOGtCKd5: Lx5UlHYM2rsDA9q4pcSm3XbO = Lx5UlHYM2rsDA9q4pcSm3XbO+hvgOo9D3itx8umIB
			zSfbIyP1aWVRMu.insert(Lx5UlHYM2rsDA9q4pcSm3XbO, zSfbIyP1aWVRMu.pop(AAUVXbkEdOSGhCj2gJH3NzrD7aKT4))
		FCkYuy3RAwg6aMnlxehI5si1[nWe3b65Ec0Ru2LahsKwNzZPjm] = zSfbIyP1aWVRMu
		s0dAQXV12m9h5bzve = str(FCkYuy3RAwg6aMnlxehI5si1)
		if i1thmHk7AZquD4cM0fnp62: s0dAQXV12m9h5bzve = s0dAQXV12m9h5bzve.encode(OVauxZzLI10vcXT74K)
		open(KNTV1H9Dl32a6yxiUEBdvZ7qgr,'wb').write(s0dAQXV12m9h5bzve)
	return
def qNDlbMxopW4TrJh(nWe3b65Ec0Ru2LahsKwNzZPjm):
	if nWe3b65Ec0Ru2LahsKwNzZPjm in ['1','2','3','4']: h2WYHItSGadM,ll0hvCkc1J = 'مفضلة',nWe3b65Ec0Ru2LahsKwNzZPjm
	elif nWe3b65Ec0Ru2LahsKwNzZPjm in ['5']: h2WYHItSGadM,ll0hvCkc1J = 'تشغيل','1'
	elif nWe3b65Ec0Ru2LahsKwNzZPjm in ['11']: h2WYHItSGadM,ll0hvCkc1J = 'تشغيل','2'
	else: h2WYHItSGadM,ll0hvCkc1J = b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv
	hyLT78XB6QECYcp0OHJDkNwgsvbt5u = h2WYHItSGadM+pldxivXC5wbTB2O8q+ll0hvCkc1J
	return hyLT78XB6QECYcp0OHJDkNwgsvbt5u
def iY3dJuRZ1Q5AXo8FUavM7nSIpL4(nWe3b65Ec0Ru2LahsKwNzZPjm):
	hyLT78XB6QECYcp0OHJDkNwgsvbt5u = qNDlbMxopW4TrJh(nWe3b65Ec0Ru2LahsKwNzZPjm)
	Dltpz9hNv72iZFQPE158U = BjMmX1vNrnzSAf('center',b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'رسالة من المبرمج','هل تريد فعلا مسح جميع محتويات قائمة '+hyLT78XB6QECYcp0OHJDkNwgsvbt5u+' ؟!')
	if Dltpz9hNv72iZFQPE158U!=1: return
	FCkYuy3RAwg6aMnlxehI5si1 = osUVxR3cueih25tjHwQf()
	if nWe3b65Ec0Ru2LahsKwNzZPjm in list(FCkYuy3RAwg6aMnlxehI5si1.keys()):
		del FCkYuy3RAwg6aMnlxehI5si1[nWe3b65Ec0Ru2LahsKwNzZPjm]
		s0dAQXV12m9h5bzve = str(FCkYuy3RAwg6aMnlxehI5si1)
		if i1thmHk7AZquD4cM0fnp62: s0dAQXV12m9h5bzve = s0dAQXV12m9h5bzve.encode(OVauxZzLI10vcXT74K)
		open(KNTV1H9Dl32a6yxiUEBdvZ7qgr,'wb').write(s0dAQXV12m9h5bzve)
		tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'رسالة من المبرمج','تم مسح جميع محتويات قائمة '+hyLT78XB6QECYcp0OHJDkNwgsvbt5u)
	return
def osUVxR3cueih25tjHwQf():
	FCkYuy3RAwg6aMnlxehI5si1 = {}
	if x76PfMyAp1L2WejkU3.path.exists(KNTV1H9Dl32a6yxiUEBdvZ7qgr):
		mAwys3IRQqTeaVJ01tbP6i9C = open(KNTV1H9Dl32a6yxiUEBdvZ7qgr,'rb').read()
		if i1thmHk7AZquD4cM0fnp62: mAwys3IRQqTeaVJ01tbP6i9C = mAwys3IRQqTeaVJ01tbP6i9C.decode(OVauxZzLI10vcXT74K)
		FCkYuy3RAwg6aMnlxehI5si1 = oJsUwXA0yGOI1mTjxQ('dict',mAwys3IRQqTeaVJ01tbP6i9C)
	return FCkYuy3RAwg6aMnlxehI5si1
def BsO7uWjxMtDA9a23H1(FCkYuy3RAwg6aMnlxehI5si1,KKHsXdETa4uckBQJWlRVPU3mbrh,SWZFhzdckIAENLgxwi9KQTJ4emBjao):
	A60AIQZCYRzdhaeWfOtmrSUVoq2nN,c17XeRIH2gVh3px8sw,uuNDjbit4hOpx,ZZtDTHnBXMz,ChvkSxHr6QoKJg,EAlZ2zKn6uagcqtY3yBoMxDmSbOwk,pnmsJqCWIHVk2Y6xPvl9Q0Ez8r,czG0PxAmlw4vtWrH5eL3RubT,ZzHaCLyPtIk1iurbW = KKHsXdETa4uckBQJWlRVPU3mbrh
	if not ZZtDTHnBXMz: A60AIQZCYRzdhaeWfOtmrSUVoq2nN,ZZtDTHnBXMz = 'folder','260'
	X3BTsRKuLqmVNkFYO,nWe3b65Ec0Ru2LahsKwNzZPjm = [],b8Qe150xVaJsnDSv
	if 'context=' in ZqDQCMovyXKFG7ki4BrahuWt1IS8:
		ZZno0bO9kYscxD4mtFCRJME5uhqLl = YYBlm36zd0Jst18LXwo4.findall('context=(\d+)',ZqDQCMovyXKFG7ki4BrahuWt1IS8,YYBlm36zd0Jst18LXwo4.DOTALL)
		if ZZno0bO9kYscxD4mtFCRJME5uhqLl: nWe3b65Ec0Ru2LahsKwNzZPjm = str(ZZno0bO9kYscxD4mtFCRJME5uhqLl[LzYQg91SIxDeOGtCKd5])
	if ZZtDTHnBXMz=='270':
		nWe3b65Ec0Ru2LahsKwNzZPjm = czG0PxAmlw4vtWrH5eL3RubT
		if nWe3b65Ec0Ru2LahsKwNzZPjm in list(FCkYuy3RAwg6aMnlxehI5si1.keys()):
			hyLT78XB6QECYcp0OHJDkNwgsvbt5u = qNDlbMxopW4TrJh(nWe3b65Ec0Ru2LahsKwNzZPjm)
			X3BTsRKuLqmVNkFYO.append(('مسح قائمة '+hyLT78XB6QECYcp0OHJDkNwgsvbt5u,'RunPlugin('+SWZFhzdckIAENLgxwi9KQTJ4emBjao+'&context='+nWe3b65Ec0Ru2LahsKwNzZPjm+'_DELETELIST'+')'))
	else:
		if nWe3b65Ec0Ru2LahsKwNzZPjm in list(FCkYuy3RAwg6aMnlxehI5si1.keys()):
			count = len(FCkYuy3RAwg6aMnlxehI5si1[nWe3b65Ec0Ru2LahsKwNzZPjm])
			if count>qHYIWnOZLPkrQU: X3BTsRKuLqmVNkFYO.append(('تحريك 1 للأعلى','RunPlugin('+SWZFhzdckIAENLgxwi9KQTJ4emBjao+'&context='+nWe3b65Ec0Ru2LahsKwNzZPjm+'_UP1)'))
			if count>NvHugPosYDzRJ: X3BTsRKuLqmVNkFYO.append(('تحريك 4 للأعلى','RunPlugin('+SWZFhzdckIAENLgxwi9KQTJ4emBjao+'&context='+nWe3b65Ec0Ru2LahsKwNzZPjm+'_UP4)'))
			if count>qHYIWnOZLPkrQU: X3BTsRKuLqmVNkFYO.append(('تحريك 1 للأسفل','RunPlugin('+SWZFhzdckIAENLgxwi9KQTJ4emBjao+'&context='+nWe3b65Ec0Ru2LahsKwNzZPjm+'_DOWN1)'))
			if count>NvHugPosYDzRJ: X3BTsRKuLqmVNkFYO.append(('تحريك 4 للأسفل','RunPlugin('+SWZFhzdckIAENLgxwi9KQTJ4emBjao+'&context='+nWe3b65Ec0Ru2LahsKwNzZPjm+'_DOWN4)'))
		for nWe3b65Ec0Ru2LahsKwNzZPjm in ['1','2','3','4','5','11']:
			hyLT78XB6QECYcp0OHJDkNwgsvbt5u = qNDlbMxopW4TrJh(nWe3b65Ec0Ru2LahsKwNzZPjm)
			if nWe3b65Ec0Ru2LahsKwNzZPjm in list(FCkYuy3RAwg6aMnlxehI5si1.keys()) and KKHsXdETa4uckBQJWlRVPU3mbrh in FCkYuy3RAwg6aMnlxehI5si1[nWe3b65Ec0Ru2LahsKwNzZPjm]:
				X3BTsRKuLqmVNkFYO.append(('مسح من '+hyLT78XB6QECYcp0OHJDkNwgsvbt5u,'RunPlugin('+SWZFhzdckIAENLgxwi9KQTJ4emBjao+'&context='+nWe3b65Ec0Ru2LahsKwNzZPjm+'_REMOVE1)'))
			else: X3BTsRKuLqmVNkFYO.append(('إضافة ل'+hyLT78XB6QECYcp0OHJDkNwgsvbt5u,'RunPlugin('+SWZFhzdckIAENLgxwi9KQTJ4emBjao+'&context='+nWe3b65Ec0Ru2LahsKwNzZPjm+'_ADD1)'))
	dJ5NKEwQt0 = []
	for iYkMWu5aPfO3,BhaE3TfwCVx4p27JsLumb9 in X3BTsRKuLqmVNkFYO:
		iYkMWu5aPfO3 = OkuB9nwhD8U1+iYkMWu5aPfO3+hAIp8kmC36T5WFPMSXOwnNbtD
		dJ5NKEwQt0.append((iYkMWu5aPfO3,BhaE3TfwCVx4p27JsLumb9,))
	return dJ5NKEwQt0
# -*- coding: utf-8 -*-
from hIVCFnfxSO import *
QQ8pvXNcBfVkP5rRJ7o = 'ALKAWTHAR'
WbzmKSZiuOYrBN7oysJ2dUv = '_KWT_'
wQjs1XZ3AO24g8y9bEeoKMiGIu7 = nTHXJIiah2qK[QQ8pvXNcBfVkP5rRJ7o][0]
def x8IFqMZeJj7suCR4AaGoNXfEHm(mode,url,NGQDwOCXx1BZmd9Huc,text):
	if   mode==130: XXxlOLJ9KRjPH382WVCvr6n71 = Y72YmLgw4vqlHxTCkbeKSicasD()
	elif mode==131: XXxlOLJ9KRjPH382WVCvr6n71 = Je4TwC30iOG5DLKWAtbYvhs(url)
	elif mode==132: XXxlOLJ9KRjPH382WVCvr6n71 = N1N9yiOaxhEkd(url)
	elif mode==133: XXxlOLJ9KRjPH382WVCvr6n71 = bIpskeGhBlqH(url,NGQDwOCXx1BZmd9Huc)
	elif mode==134: XXxlOLJ9KRjPH382WVCvr6n71 = Hkij627uCDJKyIM(url)
	elif mode==135: XXxlOLJ9KRjPH382WVCvr6n71 = vtqABUEyi7jeLRWSkV5b8KpMH()
	elif mode==139: XXxlOLJ9KRjPH382WVCvr6n71 = kstJfK6jHQWrXDSMRIGB7(text,url)
	else: XXxlOLJ9KRjPH382WVCvr6n71 = False
	return XXxlOLJ9KRjPH382WVCvr6n71
def Y72YmLgw4vqlHxTCkbeKSicasD():
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'بحث في الموقع',b8Qe150xVaJsnDSv,139,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'_REMEMBERRESULTS_')
	MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+' ===== ===== ===== '+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999)
	jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(GMkNL1RXxKFentp0Zh9d,wQjs1XZ3AO24g8y9bEeoKMiGIu7,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,True,'ALKAWTHAR-MENU-1st')
	ZV5rRvabhxJ=YYBlm36zd0Jst18LXwo4.findall('dropdown-menu(.*?)dropdown-toggle',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[1]
	items=YYBlm36zd0Jst18LXwo4.findall('href="(.*?)">(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
		if '/conductor' in pcA1dzy7LXwGfMPg9mTkuh5tine3: continue
		title = title.strip(pldxivXC5wbTB2O8q)
		url = wQjs1XZ3AO24g8y9bEeoKMiGIu7+pcA1dzy7LXwGfMPg9mTkuh5tine3
		if '/category/' in url: MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,url,132)
		else: MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,url,131)
	MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+' ===== ===== ===== '+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999)
	MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+'المسلسلات',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/category/543',132,b8Qe150xVaJsnDSv,'1')
	MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+'الأفلام',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/category/628',132,b8Qe150xVaJsnDSv,'1')
	MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+'برامج الصغار والشباب',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/category/517',132,b8Qe150xVaJsnDSv,'1')
	MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+'ابرز البرامج',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/category/1763',132,b8Qe150xVaJsnDSv,'1')
	MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+'المحاضرات',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/category/943',132,b8Qe150xVaJsnDSv,'1')
	MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+'عاشوراء',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/category/1353',132,b8Qe150xVaJsnDSv,'1')
	MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+'البرامج الاجتماعية',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/category/501',132,b8Qe150xVaJsnDSv,'1')
	MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+'البرامج الدينية',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/category/509',132,b8Qe150xVaJsnDSv,'1')
	MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+'البرامج الوثائقية',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/category/553',132,b8Qe150xVaJsnDSv,'1')
	MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+'البرامج السياسية',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/category/545',132,b8Qe150xVaJsnDSv,'1')
	MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+'كتب',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/category/291',132,b8Qe150xVaJsnDSv,'1')
	MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+'تعلم الفارسية',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/category/88',132,b8Qe150xVaJsnDSv,'1')
	MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+'أرشيف البرامج',wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/category/1279',132,b8Qe150xVaJsnDSv,'1')
	return
def Je4TwC30iOG5DLKWAtbYvhs(url):
	abyPsAh9Wdnvqe = ['/religious','/social','/political','/films','/series']
	jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(GMkNL1RXxKFentp0Zh9d,url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,True,'ALKAWTHAR-TITLES-1st')
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('titlebar(.*?)titlebar',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
	if any(Y8aiFZsLKw in url for Y8aiFZsLKw in abyPsAh9Wdnvqe):
		items = YYBlm36zd0Jst18LXwo4.findall("src='(.*?)'.*?href='(.*?)'.*?>(.*?)<",OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for lvtGpMZHb9,pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
			title = title.strip(pldxivXC5wbTB2O8q)
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = wQjs1XZ3AO24g8y9bEeoKMiGIu7 + pcA1dzy7LXwGfMPg9mTkuh5tine3
			MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,133,lvtGpMZHb9,'1')
	elif '/docs' in url:
		items = YYBlm36zd0Jst18LXwo4.findall("src='(.*?)'.*?<h2>(.*?)</h2>.*?href='(.*?)'",OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for lvtGpMZHb9,title,pcA1dzy7LXwGfMPg9mTkuh5tine3 in items:
			title = title.strip(pldxivXC5wbTB2O8q)
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = wQjs1XZ3AO24g8y9bEeoKMiGIu7 + pcA1dzy7LXwGfMPg9mTkuh5tine3
			MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,133,lvtGpMZHb9,'1')
	return
def N1N9yiOaxhEkd(url):
	Z8s0Lov2UiWF1qGjO = url.split('/')[-1]
	jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(Q49IsrlSuYRAVbGKhwdckLDOetF2PZ,url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,True,'ALKAWTHAR-CATEGORIES-1st')
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('parentcat(.*?)</div>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if not ZV5rRvabhxJ:
		bIpskeGhBlqH(url,'1')
		return
	OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
	items = YYBlm36zd0Jst18LXwo4.findall("href='(.*?)'.*?>(.*?)<",OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
		title = title.strip(pldxivXC5wbTB2O8q)
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = wQjs1XZ3AO24g8y9bEeoKMiGIu7 + pcA1dzy7LXwGfMPg9mTkuh5tine3
		MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,132,b8Qe150xVaJsnDSv,'1')
	return
def bIpskeGhBlqH(url,NGQDwOCXx1BZmd9Huc):
	jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(GMkNL1RXxKFentp0Zh9d,url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,True,'ALKAWTHAR-EPISODES-1st')
	items = YYBlm36zd0Jst18LXwo4.findall('totalpagecount=[\'"](.*?)[\'"]',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if not items:
		url = YYBlm36zd0Jst18LXwo4.findall('class="news-detail-body".*?href="(.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		url = url[0]
		title = '_MOD_' + 'ملف التشغيل'
		if url: MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+title,url,134)
		else: tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'رسالة من المبرمج','لا يوجد حاليا ملفات فيديو في هذا الفرع')
		return
	zH4Fvhd8Z2 = int(items[0])
	name = YYBlm36zd0Jst18LXwo4.findall('main-title.*?</a> >(.*?)<',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if name: name = name[0].strip(pldxivXC5wbTB2O8q)
	else: name = uuxVm0bTwdnCUAL4s6NKHEBF3M.getInfoLabel('ListItem.Label')
	if '/category/' in url or 'search?q=' in url:
		Z8s0Lov2UiWF1qGjO = url.split('/')[-1]
		if NGQDwOCXx1BZmd9Huc==b8Qe150xVaJsnDSv: MUJCtfYVBLODrFbaZn = url
		else: MUJCtfYVBLODrFbaZn = wQjs1XZ3AO24g8y9bEeoKMiGIu7 + '/category/' + Z8s0Lov2UiWF1qGjO + '/' + NGQDwOCXx1BZmd9Huc
		vWsMIpk1n6rlLqH52 = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(GMkNL1RXxKFentp0Zh9d,MUJCtfYVBLODrFbaZn,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,True,'ALKAWTHAR-EPISODES-2nd')
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('currentpagenumber(.*?)pagination',vWsMIpk1n6rlLqH52,YYBlm36zd0Jst18LXwo4.DOTALL)
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		items = YYBlm36zd0Jst18LXwo4.findall('src="(.*?)".*?full(.*?)>.*?href="(.*?)".*?>(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for lvtGpMZHb9,type,pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
			if 'video' not in type: continue
			if 'مسلسل' in title and 'حلقة' not in title: continue
			title = title.replace('\r\n',b8Qe150xVaJsnDSv)
			title = title.strip(pldxivXC5wbTB2O8q)
			if 'مسلسل' in name and 'حلقة' in title and 'مسلسل' not in title:
				title = '_MOD_' + name + ' - ' + title
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = wQjs1XZ3AO24g8y9bEeoKMiGIu7 + pcA1dzy7LXwGfMPg9mTkuh5tine3
			if Z8s0Lov2UiWF1qGjO=='628': MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,133,lvtGpMZHb9,'1')
			else: MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,134,lvtGpMZHb9)
	elif '/episode/' in url:
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('playlist(.*?)col-md-12',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if ZV5rRvabhxJ:
			OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
			items = YYBlm36zd0Jst18LXwo4.findall("video-track-text.*?loadVideo\('(.*?)','(.*?)'.*?>(.*?)<",OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
			for pcA1dzy7LXwGfMPg9mTkuh5tine3,lvtGpMZHb9,title in items:
				title = title.strip(pldxivXC5wbTB2O8q)
				MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,134,lvtGpMZHb9)
		elif '/category/628' in jLtdbeYiQHnf4SpU2MTly:
				title = '_MOD_' + 'ملف التشغيل'
				MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+title,url,134)
		else:
			items = YYBlm36zd0Jst18LXwo4.findall('id="Categories.*?href=\'(.*?)\'',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
			Z8s0Lov2UiWF1qGjO = items[0].split('/')[-1]
			url = wQjs1XZ3AO24g8y9bEeoKMiGIu7 + '/category/' + Z8s0Lov2UiWF1qGjO
			N1N9yiOaxhEkd(url)
			return
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('pagination(.*?)</div>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		ZvwBpL5CdUbRoNx9YhlOEWJDSijau = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)">(.*?)</a>',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in ZvwBpL5CdUbRoNx9YhlOEWJDSijau:
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = wQjs1XZ3AO24g8y9bEeoKMiGIu7+pcA1dzy7LXwGfMPg9mTkuh5tine3
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3.replace('&amp;','&')
			MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'صفحة '+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,133)
	return
def Hkij627uCDJKyIM(url):
	if '/news/' in url or '/episode/' in url:
		jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(Q49IsrlSuYRAVbGKhwdckLDOetF2PZ,url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,True,'ALKAWTHAR-PLAY-1st')
		items = YYBlm36zd0Jst18LXwo4.findall("mobilevideopath.*?value='(.*?)'",jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if items: url = items[0]
	yulQjIFbzM(url,QQ8pvXNcBfVkP5rRJ7o,'video')
	return
def vtqABUEyi7jeLRWSkV5b8KpMH():
	url = wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/live'
	jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(Q49IsrlSuYRAVbGKhwdckLDOetF2PZ,url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,True,'ALKAWTHAR-LIVE-1st')
	MUJCtfYVBLODrFbaZn = YYBlm36zd0Jst18LXwo4.findall('live-container.*?src="(.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	MUJCtfYVBLODrFbaZn = MUJCtfYVBLODrFbaZn[0]
	ybF0H85nUohsiRQcpaTfZAKzjMY7wB = {'Referer':wQjs1XZ3AO24g8y9bEeoKMiGIu7}
	Z8VU1cMugRwIjL2fpSyPJFHokYrqa = dcLRAZWFzODax2jf0tHCX81pJveNY(nCUMfrlZvuiLe5x,'GET',MUJCtfYVBLODrFbaZn,b8Qe150xVaJsnDSv,ybF0H85nUohsiRQcpaTfZAKzjMY7wB,b8Qe150xVaJsnDSv,True,'ALKAWTHAR-LIVE-2nd')
	vWsMIpk1n6rlLqH52 = Z8VU1cMugRwIjL2fpSyPJFHokYrqa.content
	ee9oNwUnb1RcGzukmpMOfV = YYBlm36zd0Jst18LXwo4.findall('csrf-token" content="(.*?)"',vWsMIpk1n6rlLqH52,YYBlm36zd0Jst18LXwo4.DOTALL)
	ee9oNwUnb1RcGzukmpMOfV = ee9oNwUnb1RcGzukmpMOfV[0]
	NOnMet1fIl3GkTgwQCpH6yvR4aKxj = Wl2eu1PavfQ(MUJCtfYVBLODrFbaZn,'url')
	GSh0nJxEXgZjd48u7mBwWOeafyAp5b = YYBlm36zd0Jst18LXwo4.findall("playUrl = '(.*?)'",vWsMIpk1n6rlLqH52,YYBlm36zd0Jst18LXwo4.DOTALL)
	GSh0nJxEXgZjd48u7mBwWOeafyAp5b = NOnMet1fIl3GkTgwQCpH6yvR4aKxj+GSh0nJxEXgZjd48u7mBwWOeafyAp5b[0]
	PBiZSbtjJUDqhmn72Wf4Cw = {'X-CSRF-TOKEN':ee9oNwUnb1RcGzukmpMOfV}
	tZQNAbT3dv0XP4 = dcLRAZWFzODax2jf0tHCX81pJveNY(nCUMfrlZvuiLe5x,'POST',GSh0nJxEXgZjd48u7mBwWOeafyAp5b,b8Qe150xVaJsnDSv,PBiZSbtjJUDqhmn72Wf4Cw,False,True,'ALKAWTHAR-LIVE-3rd')
	uu1FV8E62biIzGR = tZQNAbT3dv0XP4.content
	ps2ueZoatbCrwq7mIHLiVMPxN9Q = YYBlm36zd0Jst18LXwo4.findall('"(.*?)"',uu1FV8E62biIzGR,YYBlm36zd0Jst18LXwo4.DOTALL)
	ps2ueZoatbCrwq7mIHLiVMPxN9Q = ps2ueZoatbCrwq7mIHLiVMPxN9Q[0].replace('\/','/')
	yulQjIFbzM(ps2ueZoatbCrwq7mIHLiVMPxN9Q,QQ8pvXNcBfVkP5rRJ7o,'live')
	return
def kstJfK6jHQWrXDSMRIGB7(search,url=b8Qe150xVaJsnDSv):
	search,v7Rxw52Z4X0,showDialogs = JimhUH0SEf6w(search)
	if url==b8Qe150xVaJsnDSv:
		if search==b8Qe150xVaJsnDSv: search = FT2oXWtPQpVGuexmLqKN3srdzYn()
		if search==b8Qe150xVaJsnDSv: return
		search = HHbaVYqFRy6v0c(search)
		url = wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/search?q='+search
		bIpskeGhBlqH(url,b8Qe150xVaJsnDSv)
		return
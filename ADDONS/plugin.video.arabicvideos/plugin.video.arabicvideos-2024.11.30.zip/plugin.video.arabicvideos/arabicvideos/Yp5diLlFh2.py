# -*- coding: utf-8 -*-
from hIVCFnfxSO import *
QQ8pvXNcBfVkP5rRJ7o = 'LODYNET'
WbzmKSZiuOYrBN7oysJ2dUv = '_LDN_'
wQjs1XZ3AO24g8y9bEeoKMiGIu7 = nTHXJIiah2qK[QQ8pvXNcBfVkP5rRJ7o][0]
v1vJEhoNQBVPkjG = ['الرئيسية','استفسارتكم و الطلبات']
def x8IFqMZeJj7suCR4AaGoNXfEHm(mode,url,text):
	if   mode==450: XXxlOLJ9KRjPH382WVCvr6n71 = Y72YmLgw4vqlHxTCkbeKSicasD()
	elif mode==451: XXxlOLJ9KRjPH382WVCvr6n71 = Je4TwC30iOG5DLKWAtbYvhs(url,text)
	elif mode==452: XXxlOLJ9KRjPH382WVCvr6n71 = Hkij627uCDJKyIM(url)
	elif mode==453: XXxlOLJ9KRjPH382WVCvr6n71 = u9umIE5RBNelHSkqhArpCnW80(url)
	elif mode==454: XXxlOLJ9KRjPH382WVCvr6n71 = bIpskeGhBlqH(url)
	elif mode==459: XXxlOLJ9KRjPH382WVCvr6n71 = kstJfK6jHQWrXDSMRIGB7(text)
	else: XXxlOLJ9KRjPH382WVCvr6n71 = False
	return XXxlOLJ9KRjPH382WVCvr6n71
def Y72YmLgw4vqlHxTCkbeKSicasD():
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',wQjs1XZ3AO24g8y9bEeoKMiGIu7,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'LODYNET-MENU-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	OZSA7QNfeE = Wl2eu1PavfQ(wQjs1XZ3AO24g8y9bEeoKMiGIu7,'url')
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'بحث في الموقع',b8Qe150xVaJsnDSv,459,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'_REMEMBERRESULTS_')
	MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+'مثبتات لودي نت',OZSA7QNfeE,451,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'featured')
	MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+'المضاف حديثا',OZSA7QNfeE,451,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'latest')
	MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+' ===== ===== ===== '+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999)
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('"MainMenu"(.*?)"SiteSlider"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)">(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
			if pcA1dzy7LXwGfMPg9mTkuh5tine3=='#': continue
			if title in v1vJEhoNQBVPkjG: continue
			MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,451)
	return
def Je4TwC30iOG5DLKWAtbYvhs(url,vI9QYJckeTmfRFV=b8Qe150xVaJsnDSv):
	items = []
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'LODYNET-TITLES-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	if vI9QYJckeTmfRFV=='featured':
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('"SiteSlider"(.*?)"waves"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
	elif vI9QYJckeTmfRFV=='latest':
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('"RecentPosts"(.*?)"pagination"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
	elif '"ActorsList"' in jLtdbeYiQHnf4SpU2MTly:
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('"ActorsList"(.*?)"text/javascript"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)"(.*?)"ActorName">(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	elif vI9QYJckeTmfRFV in ['0','1','2']:
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('"Section"(.*?)</li></ul>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[int(vI9QYJckeTmfRFV)]
	else:
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('"BlocksArea"(.*?)"text/javascript"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
	if not items: items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)".*?src="(.*?)".*?<h2>(.*?)</h2>',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	d3VSIefbHnvqiut = []
	PBFVNlrcUMOSzC04 = ['مشاهدة','فيلم','اغنية','أغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for pcA1dzy7LXwGfMPg9mTkuh5tine3,lvtGpMZHb9,title in items:
		if '"ActorsList"' in jLtdbeYiQHnf4SpU2MTly and 'src=' in lvtGpMZHb9:
			lvtGpMZHb9 = YYBlm36zd0Jst18LXwo4.findall('src="(.*?)"',lvtGpMZHb9,YYBlm36zd0Jst18LXwo4.DOTALL)
			lvtGpMZHb9 = lvtGpMZHb9[0]
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = SgrGWuAHcLKBQMJetb9(pcA1dzy7LXwGfMPg9mTkuh5tine3).strip('/')
		HHr42WSgBjAeU7TkQcVaL6yEJz8PF = YYBlm36zd0Jst18LXwo4.findall('(.*?) حلقة \d+',title,YYBlm36zd0Jst18LXwo4.DOTALL)
		if not HHr42WSgBjAeU7TkQcVaL6yEJz8PF: HHr42WSgBjAeU7TkQcVaL6yEJz8PF = YYBlm36zd0Jst18LXwo4.findall('(.*?) الحلقة \d+',title,YYBlm36zd0Jst18LXwo4.DOTALL)
		if set(title.split()) & set(PBFVNlrcUMOSzC04) and 'مسلسل' not in title:
			MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,452,lvtGpMZHb9)
		elif HHr42WSgBjAeU7TkQcVaL6yEJz8PF and 'حلقة' in title:
			title = '_MOD_' + HHr42WSgBjAeU7TkQcVaL6yEJz8PF[0]
			if title not in d3VSIefbHnvqiut:
				MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,453,lvtGpMZHb9)
				d3VSIefbHnvqiut.append(title)
		else: MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,453,lvtGpMZHb9)
	if vI9QYJckeTmfRFV in [b8Qe150xVaJsnDSv,'latest']:
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('"pagination"(.*?)</ul>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if ZV5rRvabhxJ:
			OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
			items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)".*?>(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
			for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
				title = pTP49ckGDYrofa2KxenumbH0(title)
				MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'صفحة '+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,451)
	return
def u9umIE5RBNelHSkqhArpCnW80(url):
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'LODYNET-SEASONS-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	Pmt5K6LAEZBcb = YYBlm36zd0Jst18LXwo4.findall('"CategorySubLinks"(.*?)</div>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if Pmt5K6LAEZBcb and 'href=' in str(Pmt5K6LAEZBcb):
		title = YYBlm36zd0Jst18LXwo4.findall('<title>(.*?)-',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		title = title[0].strip(pldxivXC5wbTB2O8q)
		MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,url,454)
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = Pmt5K6LAEZBcb[0]
		items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)">(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
			MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,454)
	else: bIpskeGhBlqH(url)
	return
def bIpskeGhBlqH(url):
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'LODYNET-EPISODES-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	U8UnzJgXuMIE5GV = YYBlm36zd0Jst18LXwo4.findall('"BlocksArea"(.*?)"text/javascript"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if U8UnzJgXuMIE5GV:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = U8UnzJgXuMIE5GV[0]
		items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)".*?src="(.*?)".*?<h2>(.*?)</h2>',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,lvtGpMZHb9,title in items:
			MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,452,lvtGpMZHb9)
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('"pagination"(.*?)</ul>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if ZV5rRvabhxJ:
			OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
			items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)".*?>(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
			for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
				title = pTP49ckGDYrofa2KxenumbH0(title)
				MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'صفحة '+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,454)
	return
def Hkij627uCDJKyIM(url):
	n92bB0YwDLqyadQRlmGW,Vw6ELd0ReyubDGkj87FA1Zin = [],[]
	MUJCtfYVBLODrFbaZn = url.replace('/movies/','/watch_movies/')
	MUJCtfYVBLODrFbaZn = MUJCtfYVBLODrFbaZn.replace('/episodes/','/watch_episodes/')
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',MUJCtfYVBLODrFbaZn,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'LODYNET-PLAY-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	pcA1dzy7LXwGfMPg9mTkuh5tine3 = YYBlm36zd0Jst18LXwo4.findall('<iframe src="(.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if pcA1dzy7LXwGfMPg9mTkuh5tine3:
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3[0]
		if pcA1dzy7LXwGfMPg9mTkuh5tine3 not in Vw6ELd0ReyubDGkj87FA1Zin:
			Vw6ELd0ReyubDGkj87FA1Zin.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
			LLOCdZ3sS2enzXx4fVB18YRvbHNwky = Wl2eu1PavfQ(pcA1dzy7LXwGfMPg9mTkuh5tine3,'name')
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3+'?named='+LLOCdZ3sS2enzXx4fVB18YRvbHNwky+'__embed'
			n92bB0YwDLqyadQRlmGW.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('"ServersList"(.*?)</ul>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		items = YYBlm36zd0Jst18LXwo4.findall('data-embed="(.*?)">(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
			if pcA1dzy7LXwGfMPg9mTkuh5tine3 in Vw6ELd0ReyubDGkj87FA1Zin: continue
			Vw6ELd0ReyubDGkj87FA1Zin.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3+'?named='+title+'__watch'
			n92bB0YwDLqyadQRlmGW.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('"TabData"(.*?)</div>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)".*?<span>(.*?)</span>',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,name in items:
			if pcA1dzy7LXwGfMPg9mTkuh5tine3 in Vw6ELd0ReyubDGkj87FA1Zin: continue
			Vw6ELd0ReyubDGkj87FA1Zin.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
			name = pTP49ckGDYrofa2KxenumbH0(name)
			c1EdszLx3mkb8QYX9 = YYBlm36zd0Jst18LXwo4.findall('\d\d\d+',name,YYBlm36zd0Jst18LXwo4.DOTALL)
			if c1EdszLx3mkb8QYX9:
				c1EdszLx3mkb8QYX9 = '____'+c1EdszLx3mkb8QYX9[0]
				name = b8Qe150xVaJsnDSv
			else: c1EdszLx3mkb8QYX9 = b8Qe150xVaJsnDSv
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3+'?named='+name+'__download'+c1EdszLx3mkb8QYX9
			n92bB0YwDLqyadQRlmGW.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
	import QNeGEq8sWn
	QNeGEq8sWn.nqu2GCT9gHAbpIPSFZz5(n92bB0YwDLqyadQRlmGW,QQ8pvXNcBfVkP5rRJ7o,'video',url)
	return
def kstJfK6jHQWrXDSMRIGB7(search):
	search,v7Rxw52Z4X0,showDialogs = JimhUH0SEf6w(search)
	if search==b8Qe150xVaJsnDSv: search = FT2oXWtPQpVGuexmLqKN3srdzYn()
	if search==b8Qe150xVaJsnDSv: return
	search = search.replace(pldxivXC5wbTB2O8q,'+')
	url = wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/search/'+search
	Je4TwC30iOG5DLKWAtbYvhs(url)
	return
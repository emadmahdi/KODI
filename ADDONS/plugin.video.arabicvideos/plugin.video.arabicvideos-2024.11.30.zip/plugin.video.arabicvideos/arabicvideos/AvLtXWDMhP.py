# -*- coding: utf-8 -*-
from hIVCFnfxSO import *
headers = { 'User-Agent' : b8Qe150xVaJsnDSv }
QQ8pvXNcBfVkP5rRJ7o = 'AKOAM'
WbzmKSZiuOYrBN7oysJ2dUv = '_AKO_'
wQjs1XZ3AO24g8y9bEeoKMiGIu7 = nTHXJIiah2qK[QQ8pvXNcBfVkP5rRJ7o][0]
LNZe9t3Kc6l = ['فيلم','كليب','العرض الاسبوعي','مسرحية','مسرحيه','اغنية','اعلان','لقاء']
def x8IFqMZeJj7suCR4AaGoNXfEHm(mode,url,text):
	if   mode==70: XXxlOLJ9KRjPH382WVCvr6n71 = Y72YmLgw4vqlHxTCkbeKSicasD()
	elif mode==71: XXxlOLJ9KRjPH382WVCvr6n71 = N1N9yiOaxhEkd(url)
	elif mode==72: XXxlOLJ9KRjPH382WVCvr6n71 = Je4TwC30iOG5DLKWAtbYvhs(url,text)
	elif mode==73: XXxlOLJ9KRjPH382WVCvr6n71 = tiY6xRF3ap4ZbmJLCVA(url)
	elif mode==74: XXxlOLJ9KRjPH382WVCvr6n71 = Hkij627uCDJKyIM(url)
	elif mode==79: XXxlOLJ9KRjPH382WVCvr6n71 = kstJfK6jHQWrXDSMRIGB7(text)
	else: XXxlOLJ9KRjPH382WVCvr6n71 = False
	return XXxlOLJ9KRjPH382WVCvr6n71
def Y72YmLgw4vqlHxTCkbeKSicasD():
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'بحث في الموقع',b8Qe150xVaJsnDSv,79,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'_REMEMBERRESULTS_')
	MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+'سلسلة افلام',b8Qe150xVaJsnDSv,79,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'سلسلة افلام')
	MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+'سلاسل منوعة',b8Qe150xVaJsnDSv,79,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'سلسلة')
	MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+' ===== ===== ===== '+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999)
	v1vJEhoNQBVPkjG = ['الكتب و الابحاث','الكورسات التعليمية','الألعاب','البرامج','الاجهزة اللوحية','الصور و الخلفيات','المصارعة الحرة']
	jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(Q49IsrlSuYRAVbGKhwdckLDOetF2PZ,wQjs1XZ3AO24g8y9bEeoKMiGIu7,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,'AKOAM-MENU-1st')
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('class="partions"(.*?)</ul>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)">(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
			if title not in v1vJEhoNQBVPkjG:
				MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,71)
	return jLtdbeYiQHnf4SpU2MTly
def N1N9yiOaxhEkd(url):
	jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(Q49IsrlSuYRAVbGKhwdckLDOetF2PZ,url,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,'AKOAM-CATEGORIES-1st')
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('sect_parts(.*?)</div>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)".*?>(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
			title = title.strip(pldxivXC5wbTB2O8q)
			MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,72)
		MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'جميع الفروع',url,72)
	else: Je4TwC30iOG5DLKWAtbYvhs(url,b8Qe150xVaJsnDSv)
	return
def Je4TwC30iOG5DLKWAtbYvhs(url,type):
	jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(GMkNL1RXxKFentp0Zh9d,url,b8Qe150xVaJsnDSv,headers,True,'AKOAM-TITLES-1st')
	items = []
	if type=='featured':
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('section_title featured_title(.*?)subjects-crousel',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)"><div class="subject_box.*?src="(.*?)".*?<h3.*?>(.*?)</h3>',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	elif type=='search':
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('akoam_result(.*?)<script',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)".*?background-image: url\((.*?)\).*?<h1>(.*?)</h1>',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	elif type=='more':
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('section_title more_title(.*?)footer_bottom_services',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	else:
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('navigation(.*?)<script',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if not items and ZV5rRvabhxJ:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		items = YYBlm36zd0Jst18LXwo4.findall('div class="subject_box.*?href="(.*?)".*?src="(.*?)".*?<h3.*?>(.*?)</h3>',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	for pcA1dzy7LXwGfMPg9mTkuh5tine3,lvtGpMZHb9,title in items:
		if 'توضيح هام' in title: continue
		title = title.replace(eeN6dTEnkJxI,b8Qe150xVaJsnDSv).strip(pldxivXC5wbTB2O8q)
		title = pTP49ckGDYrofa2KxenumbH0(title)
		if any(Y8aiFZsLKw in title for Y8aiFZsLKw in LNZe9t3Kc6l): MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,73,lvtGpMZHb9)
		else: MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,73,lvtGpMZHb9)
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('class="pagination"(.*?)</ul>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		items = YYBlm36zd0Jst18LXwo4.findall("</li><li >.*?href='(.*?)'>(.*?)<",OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
			MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'صفحة '+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,72,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,type)
	return
def W8Rfrm92h6MsNi1JZzX(url):
	jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(Q49IsrlSuYRAVbGKhwdckLDOetF2PZ,url,b8Qe150xVaJsnDSv,headers,True,'AKOAM-SECTIONS-2nd')
	MUJCtfYVBLODrFbaZn = YYBlm36zd0Jst18LXwo4.findall('"href","(.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	MUJCtfYVBLODrFbaZn = MUJCtfYVBLODrFbaZn[1]
	return MUJCtfYVBLODrFbaZn
def tiY6xRF3ap4ZbmJLCVA(url):
	jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(GMkNL1RXxKFentp0Zh9d,url,b8Qe150xVaJsnDSv,headers,True,'AKOAM-SECTIONS-1st')
	hStvzB32bak0mIGwAW = YYBlm36zd0Jst18LXwo4.findall('"(https*://akwam.net/\w+.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	zTAMlHX0xmNwcs8 = YYBlm36zd0Jst18LXwo4.findall('"(https*://underurl.com/\w+.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if hStvzB32bak0mIGwAW or zTAMlHX0xmNwcs8:
		if hStvzB32bak0mIGwAW: GSh0nJxEXgZjd48u7mBwWOeafyAp5b = hStvzB32bak0mIGwAW[0]
		elif zTAMlHX0xmNwcs8: GSh0nJxEXgZjd48u7mBwWOeafyAp5b = W8Rfrm92h6MsNi1JZzX(zTAMlHX0xmNwcs8[0])
		GSh0nJxEXgZjd48u7mBwWOeafyAp5b = SgrGWuAHcLKBQMJetb9(GSh0nJxEXgZjd48u7mBwWOeafyAp5b)
		import pn57ui6YOm
		if '/series/' in GSh0nJxEXgZjd48u7mBwWOeafyAp5b or '/shows/' in GSh0nJxEXgZjd48u7mBwWOeafyAp5b: pn57ui6YOm.bIpskeGhBlqH(GSh0nJxEXgZjd48u7mBwWOeafyAp5b)
		else: pn57ui6YOm.Hkij627uCDJKyIM(GSh0nJxEXgZjd48u7mBwWOeafyAp5b)
		return
	EQUkgc3PLy5mhBiZINJ0HO1A6 = YYBlm36zd0Jst18LXwo4.findall('محتوى الفيلم.*?>.*?(\w*?)\W*?<',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if EQUkgc3PLy5mhBiZINJ0HO1A6 and vvIMS2DeraLfJ(QQ8pvXNcBfVkP5rRJ7o,url,EQUkgc3PLy5mhBiZINJ0HO1A6): return
	items = YYBlm36zd0Jst18LXwo4.findall('<br />\n<a href="(.*?)".*?<span style="color:.*?">(.*?)</span>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
		title = pTP49ckGDYrofa2KxenumbH0(title)
		MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,73)
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('class="sub_title".*?<h1.*?>(.*?)</h1>.*?class="main_img".*?src="(.*?)".*?ad-300-250(.*?)ako-feedback',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if not ZV5rRvabhxJ:
		yicQV3gj4q('خطأ خارجي','لا يوجد ملف فيديو')
		return
	name,lvtGpMZHb9,OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
	name = name.strip(pldxivXC5wbTB2O8q)
	if 'sub_epsiode_title' in OTKx7aVb2hdS16Wrweky4FXfIN0g9:
		items = YYBlm36zd0Jst18LXwo4.findall('sub_epsiode_title">(.*?)</h2>.*?sub_file_title.*?>(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	else:
		CBlXowWAfQmkdn6I = YYBlm36zd0Jst18LXwo4.findall('sub_file_title\'>(.*?) - <i>',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		items = []
		for filename in CBlXowWAfQmkdn6I:
			items.append( ('رابط التشغيل',filename) )
	if not items: items = [ ('رابط التشغيل',b8Qe150xVaJsnDSv) ]
	count = 0
	uuSKUinvP4EGLxWZYmTsF,e4MRglD013XViwdJ5Kc = [],[]
	size = len(items)
	for title,filename in items:
		UYat1jqNzCdDlWGuPF60T9i = b8Qe150xVaJsnDSv
		if ' - ' in filename: filename = filename.split(' - ')[0]
		else: filename = 'dummy.zip'
		if '.' in filename: UYat1jqNzCdDlWGuPF60T9i = filename.split('.')[-1]
		title = title.replace(eeN6dTEnkJxI,b8Qe150xVaJsnDSv).strip(pldxivXC5wbTB2O8q)
		uuSKUinvP4EGLxWZYmTsF.append(title)
		e4MRglD013XViwdJ5Kc.append(count)
		count += 1
	if size>0:
		if any(Y8aiFZsLKw in name for Y8aiFZsLKw in LNZe9t3Kc6l):
			if size==1:
				cMZGTsAR2E = 0
			else:
				cMZGTsAR2E = XXprCMzuNP2mElUxfdA('اختر الفيديو المناسب:', uuSKUinvP4EGLxWZYmTsF)
				if cMZGTsAR2E == -1: return
			Hkij627uCDJKyIM(url+'?section='+str(1+e4MRglD013XViwdJ5Kc[size-cMZGTsAR2E-1]))
		else:
			for FbcUxvE17ewlWNBHgS8Jn in reversed(range(size)):
				title = name + ' - ' + uuSKUinvP4EGLxWZYmTsF[FbcUxvE17ewlWNBHgS8Jn]
				title = title.replace(eeN6dTEnkJxI,b8Qe150xVaJsnDSv).strip(pldxivXC5wbTB2O8q)
				pcA1dzy7LXwGfMPg9mTkuh5tine3 = url + '?section='+str(size-FbcUxvE17ewlWNBHgS8Jn)
				MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,74,lvtGpMZHb9)
	else:
		MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+'الرابط ليس فيديو',b8Qe150xVaJsnDSv,9999,lvtGpMZHb9)
	return
def Hkij627uCDJKyIM(url):
	MUJCtfYVBLODrFbaZn,HHr42WSgBjAeU7TkQcVaL6yEJz8PF = url.split('?section=')
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',MUJCtfYVBLODrFbaZn,b8Qe150xVaJsnDSv,headers,True,b8Qe150xVaJsnDSv,'AKOAM-PLAY_AKOAM-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('ad-300-250.*?ad-300-250(.*?)ako-feedback',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	Msj5nW9lTJaKduEF = ZV5rRvabhxJ[0].replace("'direct_link_box",'"direct_link_box epsoide_box')
	Msj5nW9lTJaKduEF = Msj5nW9lTJaKduEF + 'direct_link_box'
	JQjNkD10xehK8bXUalY3EgZAVmvI = YYBlm36zd0Jst18LXwo4.findall('epsoide_box(.*?)direct_link_box',Msj5nW9lTJaKduEF,YYBlm36zd0Jst18LXwo4.DOTALL)
	HHr42WSgBjAeU7TkQcVaL6yEJz8PF = len(JQjNkD10xehK8bXUalY3EgZAVmvI)-int(HHr42WSgBjAeU7TkQcVaL6yEJz8PF)
	OTKx7aVb2hdS16Wrweky4FXfIN0g9 = JQjNkD10xehK8bXUalY3EgZAVmvI[HHr42WSgBjAeU7TkQcVaL6yEJz8PF]
	n92bB0YwDLqyadQRlmGW = []
	MySKTJDoBZXacRO = {'1423075862':'dailymotion','1477487601':'estream','1505328404':'streamango',
		'1423080015':'flashx','1458117295':'openload','1423079306':'vimple','1430052371':'ok.ru',
		'1477488213':'thevid','1558278006':'uqload','1477487990':'vidtodo'}
	items = YYBlm36zd0Jst18LXwo4.findall("class='download_btn.*?href='(.*?)'",OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	for pcA1dzy7LXwGfMPg9mTkuh5tine3 in items:
		n92bB0YwDLqyadQRlmGW.append(pcA1dzy7LXwGfMPg9mTkuh5tine3+'?named=________akoam')
	items = YYBlm36zd0Jst18LXwo4.findall('background-image: url\((.*?)\).*?href=\'(.*?)\'',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	for Z9okDQXSvmryAejMh,pcA1dzy7LXwGfMPg9mTkuh5tine3 in items:
		Z9okDQXSvmryAejMh = Z9okDQXSvmryAejMh.split('/')[-1]
		Z9okDQXSvmryAejMh = Z9okDQXSvmryAejMh.split('.')[0]
		if Z9okDQXSvmryAejMh in MySKTJDoBZXacRO:
			n92bB0YwDLqyadQRlmGW.append(pcA1dzy7LXwGfMPg9mTkuh5tine3+'?named='+MySKTJDoBZXacRO[Z9okDQXSvmryAejMh]+'________akoam')
		else: n92bB0YwDLqyadQRlmGW.append(pcA1dzy7LXwGfMPg9mTkuh5tine3+'?named='+Z9okDQXSvmryAejMh+'________akoam')
	if not n92bB0YwDLqyadQRlmGW:
		message = YYBlm36zd0Jst18LXwo4.findall('sub-no-file.*?\n(.*?)\n',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		if message: tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'رسالة من الموقع الاصلي',message[0])
	else:
		import QNeGEq8sWn
		QNeGEq8sWn.nqu2GCT9gHAbpIPSFZz5(n92bB0YwDLqyadQRlmGW,QQ8pvXNcBfVkP5rRJ7o,'video',url)
	return
def kstJfK6jHQWrXDSMRIGB7(search):
	search,v7Rxw52Z4X0,showDialogs = JimhUH0SEf6w(search)
	if search==b8Qe150xVaJsnDSv: search = FT2oXWtPQpVGuexmLqKN3srdzYn()
	if search==b8Qe150xVaJsnDSv: return
	LgXO1RhbDV7cx6EaeYCNm4zjJdBS = search.replace(pldxivXC5wbTB2O8q,'%20')
	url = wQjs1XZ3AO24g8y9bEeoKMiGIu7 + '/search/'+LgXO1RhbDV7cx6EaeYCNm4zjJdBS
	XXxlOLJ9KRjPH382WVCvr6n71 = Je4TwC30iOG5DLKWAtbYvhs(url,'search')
	return
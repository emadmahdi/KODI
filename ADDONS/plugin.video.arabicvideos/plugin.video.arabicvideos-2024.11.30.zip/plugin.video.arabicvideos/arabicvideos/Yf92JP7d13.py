# -*- coding: utf-8 -*-
import sys as Pft6y0LvwSh48iYg7b
MQBw2uYHcWbpxF8tKAV = Pft6y0LvwSh48iYg7b.version_info [0] == 2
myc93k4htNU67 = 2048
h8lCkw1d3LepDVuvfoicEXj5K6sPz = 7
def JanmRV2MtcH (VwngrDb8fEytv4kMTdQu95cIejsC):
	global oPFYqewitzj
	WBrAFcJPVXdS2UzxLEGM0omkD = ord (VwngrDb8fEytv4kMTdQu95cIejsC [-1])
	V13jmfpwhlcyCKMRLY5TiaG = VwngrDb8fEytv4kMTdQu95cIejsC [:-1]
	gyF4Uq9l1NQKCtT = WBrAFcJPVXdS2UzxLEGM0omkD % len (V13jmfpwhlcyCKMRLY5TiaG)
	BN5pdqozP2v9Ur1Swsia = V13jmfpwhlcyCKMRLY5TiaG [:gyF4Uq9l1NQKCtT] + V13jmfpwhlcyCKMRLY5TiaG [gyF4Uq9l1NQKCtT:]
	if MQBw2uYHcWbpxF8tKAV:
		D3MGYw1ceHQ4UbrNJSq = unicode () .join ([unichr (ord (bb1FgjciZqDzeQTBC2hplaPkmRIyUf) - myc93k4htNU67 - (Ni5bJjhpks6SfCc + WBrAFcJPVXdS2UzxLEGM0omkD) % h8lCkw1d3LepDVuvfoicEXj5K6sPz) for Ni5bJjhpks6SfCc, bb1FgjciZqDzeQTBC2hplaPkmRIyUf in enumerate (BN5pdqozP2v9Ur1Swsia)])
	else:
		D3MGYw1ceHQ4UbrNJSq = str () .join ([chr (ord (bb1FgjciZqDzeQTBC2hplaPkmRIyUf) - myc93k4htNU67 - (Ni5bJjhpks6SfCc + WBrAFcJPVXdS2UzxLEGM0omkD) % h8lCkw1d3LepDVuvfoicEXj5K6sPz) for Ni5bJjhpks6SfCc, bb1FgjciZqDzeQTBC2hplaPkmRIyUf in enumerate (BN5pdqozP2v9Ur1Swsia)])
	return eval (D3MGYw1ceHQ4UbrNJSq)
TYf7Dc06PQgy1vEV9,ubxGUTt1LraKhVZgpAP,Y2t8baH5GWikvOZ7NsCeq3TKrgMV=JanmRV2MtcH,JanmRV2MtcH,JanmRV2MtcH
BWNPxIG7vqdTy85pjHzUOrK3,Mmpr0o76iWJvz1kTtfgI8hES,QTUBCcehw6qPd4x=Y2t8baH5GWikvOZ7NsCeq3TKrgMV,ubxGUTt1LraKhVZgpAP,TYf7Dc06PQgy1vEV9
mQNonhS7CV2BXOv,HwB7ydlWVJeCtPuQ6MDE1RTYOo,uVQd103XyvUce2EBtzbYaC=QTUBCcehw6qPd4x,Mmpr0o76iWJvz1kTtfgI8hES,BWNPxIG7vqdTy85pjHzUOrK3
yST5AHEfvPmcWpwGuh2BJ,BmePGjS7FxK6kutUM,S0IlDPhBN3gMEUvnjRLXsYAc2Zf=uVQd103XyvUce2EBtzbYaC,HwB7ydlWVJeCtPuQ6MDE1RTYOo,mQNonhS7CV2BXOv
Xz3bA2PFENVCUtplu51,LAQD5wEkr18bUiGaYen3J,P0qdZI384LKleuo=S0IlDPhBN3gMEUvnjRLXsYAc2Zf,BmePGjS7FxK6kutUM,yST5AHEfvPmcWpwGuh2BJ
shC5qBRV2A0lZ,mmcNLrXtzfpyCkZlvK5VwG2gujh,m6hwdgP31a2zjN7lkpX=P0qdZI384LKleuo,LAQD5wEkr18bUiGaYen3J,Xz3bA2PFENVCUtplu51
IjZbnrBJmM2N,Nh0BWuiSndf,kke1PDGRBLuY8y=m6hwdgP31a2zjN7lkpX,mmcNLrXtzfpyCkZlvK5VwG2gujh,shC5qBRV2A0lZ
ddo23ZJtgcY,vvWwO3Tx2dAgcijrFXq,DYakr9g4PVU=kke1PDGRBLuY8y,Nh0BWuiSndf,IjZbnrBJmM2N
zI3ROAZtiUq42rE9WDST68,Dzs8qU2gQMcCSyRhiZn4TFbeGk,dDYUoKi6JFM23p=DYakr9g4PVU,vvWwO3Tx2dAgcijrFXq,ddo23ZJtgcY
QQdAXWBc2GPw,VFjQx6Is28KvzLOmMXtg4GqTwa3,TT8Mxv5Wq7nlC9IscdpPUY6=dDYUoKi6JFM23p,Dzs8qU2gQMcCSyRhiZn4TFbeGk,zI3ROAZtiUq42rE9WDST68
SbjiWeHLQPoazqwp3cODkd7YxVgn,UUkIBz1sgQ9WfNeG6trKXvu0,RRIHDFjoW9w7bSfVPhC=TT8Mxv5Wq7nlC9IscdpPUY6,VFjQx6Is28KvzLOmMXtg4GqTwa3,QQdAXWBc2GPw
import xbmc as uuxVm0bTwdnCUAL4s6NKHEBF3M,re as YYBlm36zd0Jst18LXwo4,sys as Pft6y0LvwSh48iYg7b,xbmcaddon as iA97UEDqm2P,random as qHiNBx6PXjKatkWf37AwFClzsp2DmE,os as x76PfMyAp1L2WejkU3,xbmcvfs as AAdgh34SURPET8vfOaCJZX,time as wLQCTr5lqbsVYeAHdzfhZ1F,pickle as HKrlqY4uvyRC,zlib as bk64KT2Z3WylUt,xbmcgui as evil9I2DnLJcy8,xbmcplugin as xMTL52Bgvu1csftCe4bq6VFpXK,sqlite3 as jA69Ts3CqJli7,traceback as n9dSEJTBOWlY6,threading as Ay1SMOzkx5CU3aGTL4Zf,hashlib as dVRkZo9Daz,json as AFIDMBehNx5QH6g21E8kq9JzrLi
import XrloM5pTyK
QQ8pvXNcBfVkP5rRJ7o = VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠬࡒࡉࡃࡕࡒࡒࡊ࠭य़")
b8Qe150xVaJsnDSv = yST5AHEfvPmcWpwGuh2BJ(u"࠭ࠧॠ")
pldxivXC5wbTB2O8q = VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠧࠡࠩॡ")
k5bCDErUSmv = pldxivXC5wbTB2O8q*ubxGUTt1LraKhVZgpAP(u"࠲ଡ")
R1BKXhzpGH6CoO9jLsPwQWu = pldxivXC5wbTB2O8q*zI3ROAZtiUq42rE9WDST68(u"࠴ଢ")
eiopkn4y9uWDQ5 = pldxivXC5wbTB2O8q*HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"࠶ଣ")
CCxMXuNUEzolDZTKrBJ = vvWwO3Tx2dAgcijrFXq(u"ࡔࡳࡷࡨ୮")
DD5cFIejQa2X4BgAu9GWPyJ3tC7 = BmePGjS7FxK6kutUM(u"ࡇࡣ࡯ࡷࡪ୯")
LzYQg91SIxDeOGtCKd5 = TYf7Dc06PQgy1vEV9(u"࠳ତ")
qHYIWnOZLPkrQU = uVQd103XyvUce2EBtzbYaC(u"࠵ଥ")
IgQimel18t = DYakr9g4PVU(u"࠷ଦ")
VwApyDY1Jc = P0qdZI384LKleuo(u"࠹ଧ")
NvHugPosYDzRJ = m6hwdgP31a2zjN7lkpX(u"࠴ନ")
rC3Tlno96KjLDIvBaSWUbR8 = zI3ROAZtiUq42rE9WDST68(u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡈ࠵࠳ࡈࡠࠫॢ")
OkuB9nwhD8U1 = mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬॣ")
Vx5N0eIvPChf6SyXiMz = P0qdZI384LKleuo(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋ࠹࠳ࡆ࠶࠶࠷ࡢ࠭।")
n1a97RTs0wA8EzjVYcXtSP = zI3ROAZtiUq42rE9WDST68(u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌ࠱ࡇ࠷࠴ࡊࡋࡣࠧ॥")
hAIp8kmC36T5WFPMSXOwnNbtD = P0qdZI384LKleuo(u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ०")
OVauxZzLI10vcXT74K = HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"࠭ࡵࡵࡨ࠻ࠫ१")
MtTygrzXFlQ = DYakr9g4PVU(u"ࠧࡏࡑࡗࡍࡈࡋࠧ२")
iebCpLE8fuxTRg = kke1PDGRBLuY8y(u"ࠨࡐࡒࡘࡎࡉࡅࡠࡎࡌࡒࡊ࡙ࠧ३")
MF4fVI6yJhaTkAODK = TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠩࡈࡖࡗࡕࡒࠨ४")
WG2BfeyzMa = shC5qBRV2A0lZ(u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨ५")
eeN6dTEnkJxI = VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠫࡡࡴࠧ६")
d6ekSEojpFUANKJ7r9WTlI3niLBOu = P0qdZI384LKleuo(u"ࠬࡢࡲࠨ७")
JnlzVBayd7WFKtCOH0 = iA97UEDqm2P.Addon().getAddonInfo(Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"࠭ࡰࡢࡶ࡫ࠫ८"))
zQXRI7bti2uckD8aK5BMAY = x76PfMyAp1L2WejkU3.path.join(JnlzVBayd7WFKtCOH0,QQdAXWBc2GPw(u"ࠧࡱࡣࡦ࡯ࡦ࡭ࡥࡴࠩ९"))
Pft6y0LvwSh48iYg7b.path.append(zQXRI7bti2uckD8aK5BMAY)
xsc9o3jWnC5H4 = uuxVm0bTwdnCUAL4s6NKHEBF3M.getInfoLabel(m6hwdgP31a2zjN7lkpX(u"ࠣࡕࡼࡷࡹ࡫࡭࠯ࡄࡸ࡭ࡱࡪࡖࡦࡴࡶ࡭ࡴࡴࠢ॰"))
g1gmkxOtc2oeEZHhBiy = YYBlm36zd0Jst18LXwo4.findall(Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠩࠫࡠࡩࡢࡤ࡝࠰࡟ࡨ࠮࠭ॱ"),xsc9o3jWnC5H4,YYBlm36zd0Jst18LXwo4.DOTALL)
g1gmkxOtc2oeEZHhBiy = float(g1gmkxOtc2oeEZHhBiy[LzYQg91SIxDeOGtCKd5])
kQ4rH0JsKCYlEUP = uuxVm0bTwdnCUAL4s6NKHEBF3M.Player
aSP049nZdvtTGDV8wEi75eIOUb = evil9I2DnLJcy8.WindowXMLDialog
hDTluNxe7tCwrpqXHzdEcYRfbs = g1gmkxOtc2oeEZHhBiy<m6hwdgP31a2zjN7lkpX(u"࠲࠻଩")
i1thmHk7AZquD4cM0fnp62 = g1gmkxOtc2oeEZHhBiy>Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"࠳࠻࠲࠾࠿ପ")
if i1thmHk7AZquD4cM0fnp62:
	o5nca0TPVyiFONMwut98WdSxp = uuxVm0bTwdnCUAL4s6NKHEBF3M.LOGINFO
	W0LQbFfMVG46dKrPzJCmvD,VfHYrPvolqbxLOd = DYakr9g4PVU(u"ࡸࠫࡡࡻ࠲࠱࠴ࡤࠫॲ"),P0qdZI384LKleuo(u"ࡹࠬࡢࡵ࠳࠲࠵ࡦࠬॳ")
	iiqmEcGavKz7bRsfZSxwQ6oOPF = AAdgh34SURPET8vfOaCJZX.translatePath(Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰ࡶࡨࡱࡵ࠭ॴ"))
	from urllib.parse import unquote as _xIXif9OsL32TKE7nNSqzkPFb0crm
else:
	o5nca0TPVyiFONMwut98WdSxp = uuxVm0bTwdnCUAL4s6NKHEBF3M.LOGNOTICE
	W0LQbFfMVG46dKrPzJCmvD,VfHYrPvolqbxLOd = yST5AHEfvPmcWpwGuh2BJ(u"ࡻࠧ࡝ࡷ࠵࠴࠷ࡧࠧॵ").encode(OVauxZzLI10vcXT74K),mQNonhS7CV2BXOv(u"ࡵࠨ࡞ࡸ࠶࠵࠸ࡢࠨॶ").encode(OVauxZzLI10vcXT74K)
	iiqmEcGavKz7bRsfZSxwQ6oOPF = uuxVm0bTwdnCUAL4s6NKHEBF3M.translatePath(HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳ࡹ࡫࡭ࡱࠩॷ"))
	from urllib import unquote as _xIXif9OsL32TKE7nNSqzkPFb0crm
UxyBtuVLnvM4h8bc0iZPOGXrKqHj16 = vvWwO3Tx2dAgcijrFXq(u"࠹࠴ଫ")
n4GUoTyqdKik9VSLE3W5pt8zJlug = QTUBCcehw6qPd4x(u"࠺࠵ବ")*UxyBtuVLnvM4h8bc0iZPOGXrKqHj16
GsNQWtBTywlx40 = HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"࠷࠺ଭ")*n4GUoTyqdKik9VSLE3W5pt8zJlug
LLaRjIbuQWq = dDYUoKi6JFM23p(u"࠹࠰ମ")*GsNQWtBTywlx40
nCUMfrlZvuiLe5x = LzYQg91SIxDeOGtCKd5
IiYS8Jg4da3UuDP0qr6vy = IjZbnrBJmM2N(u"࠳࠱ଯ")*UxyBtuVLnvM4h8bc0iZPOGXrKqHj16
LtlXH3fvMydAx = IgQimel18t*n4GUoTyqdKik9VSLE3W5pt8zJlug
GMkNL1RXxKFentp0Zh9d = zI3ROAZtiUq42rE9WDST68(u"࠲࠸ର")*n4GUoTyqdKik9VSLE3W5pt8zJlug
Q49IsrlSuYRAVbGKhwdckLDOetF2PZ = VwApyDY1Jc*GsNQWtBTywlx40
xkDunX3BfFiYG = Nh0BWuiSndf(u"࠵࠳଱")*GsNQWtBTywlx40
t58tnzAgevxkoIOdMFbE2PsD64q0C9 = mQNonhS7CV2BXOv(u"࠴࠶ଲ")*LLaRjIbuQWq
CulwpQfz75qMK0PIJSDcaNZ4G = n4GUoTyqdKik9VSLE3W5pt8zJlug
DFUIv2KGj9ke = Pft6y0LvwSh48iYg7b.argv[LzYQg91SIxDeOGtCKd5].split(yST5AHEfvPmcWpwGuh2BJ(u"ࠩ࠲ࠫॸ"))[IgQimel18t]
IaCU04ZS1qx = int(Pft6y0LvwSh48iYg7b.argv[qHYIWnOZLPkrQU])
ZqDQCMovyXKFG7ki4BrahuWt1IS8 = Pft6y0LvwSh48iYg7b.argv[IgQimel18t]
iyPYHhe0wOnluEfs3JKkBG = DFUIv2KGj9ke.split(Nh0BWuiSndf(u"ࠪ࠲ࠬॹ"))[IgQimel18t]
cpGrK6qnPi = uuxVm0bTwdnCUAL4s6NKHEBF3M.getInfoLabel(mQNonhS7CV2BXOv(u"ࠫࡘࡿࡳࡵࡧࡰ࠲ࡆࡪࡤࡰࡰ࡙ࡩࡷࡹࡩࡰࡰࠫࠫॺ")+DFUIv2KGj9ke+HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠬ࠯ࠧॻ"))
vIaQF8hqXeiJERYuD = x76PfMyAp1L2WejkU3.path.join(iiqmEcGavKz7bRsfZSxwQ6oOPF,DFUIv2KGj9ke)
mshLJcKH1fv03yRnDOr4ZT = x76PfMyAp1L2WejkU3.path.join(vIaQF8hqXeiJERYuD,ubxGUTt1LraKhVZgpAP(u"࠭࡭ࡢ࡫ࡱࡨࡦࡺࡡ࠯ࡦࡥࠫॼ"))
oYXBd89zTnZPipv56Qf1UxurbC3 = x76PfMyAp1L2WejkU3.path.join(vIaQF8hqXeiJERYuD,Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠧ࡭ࡣࡶࡸࡻ࡯ࡤࡦࡱࡶ࠲ࡩࡧࡴࠨॽ"))
T3Axql94cU0BpO1wudEDtWXsf = int(wLQCTr5lqbsVYeAHdzfhZ1F.time())
hRWC8YSFvsm4JHOMVIne3jquZ = iA97UEDqm2P.Addon(id=DFUIv2KGj9ke)
TcOrDXYbkanu8wS6hUPN9jgx = hRWC8YSFvsm4JHOMVIne3jquZ.getSetting(HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠨࡣࡹ࠲ࡻ࡫ࡲࡴ࡫ࡲࡲࠬॾ"))
l1RsIerQAtbJjMTzGEWP2L = DD5cFIejQa2X4BgAu9GWPyJ3tC7 if TcOrDXYbkanu8wS6hUPN9jgx==cpGrK6qnPi else CCxMXuNUEzolDZTKrBJ
rr6IVXNFsezAw15m = DD5cFIejQa2X4BgAu9GWPyJ3tC7
def FNIhDd4uLfev0q5YHVGx8oWm6CsiJ(YabJfs3q7yjpzvXioO,ZrBtKnWX8I6PLxF=dDYUoKi6JFM23p(u"ࠩࡂࠫॿ")):
	if VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠪࡁࠬঀ") in YabJfs3q7yjpzvXioO:
		if ZrBtKnWX8I6PLxF in YabJfs3q7yjpzvXioO: MUJCtfYVBLODrFbaZn,tzuGYEnOHCK = YabJfs3q7yjpzvXioO.split(ZrBtKnWX8I6PLxF,yST5AHEfvPmcWpwGuh2BJ(u"࠵ଳ"))
		else: MUJCtfYVBLODrFbaZn,tzuGYEnOHCK = b8Qe150xVaJsnDSv,YabJfs3q7yjpzvXioO
		tzuGYEnOHCK = tzuGYEnOHCK.split(vvWwO3Tx2dAgcijrFXq(u"ࠫࠫ࠭ঁ"))
		EEkjQFxOabod08Nr = {}
		for q3qa92IPwmEAOc in tzuGYEnOHCK:
			bb0cYXjevHNo8ZLE7CyrBzWAl9wus,ehwRMsq9br8P72Bj3mnlOCY0JXvWFc = q3qa92IPwmEAOc.split(shC5qBRV2A0lZ(u"ࠬࡃࠧং"),mmcNLrXtzfpyCkZlvK5VwG2gujh(u"࠶଴"))
			EEkjQFxOabod08Nr[bb0cYXjevHNo8ZLE7CyrBzWAl9wus] = ehwRMsq9br8P72Bj3mnlOCY0JXvWFc
	else: MUJCtfYVBLODrFbaZn,EEkjQFxOabod08Nr = YabJfs3q7yjpzvXioO,{}
	return MUJCtfYVBLODrFbaZn,EEkjQFxOabod08Nr
def dIAn5x3eGWtEVMfHQKoN8g(rlqNUcK9vYgkT):
	wLZUyXHr4Gc7DuAxC8l0PsobmqRSQ,TFAmLfwypkzsP1UYCMr8c,GHfpZBtabwXKDdLySzCOIvlc = b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv
	rlqNUcK9vYgkT = rlqNUcK9vYgkT.replace(W0LQbFfMVG46dKrPzJCmvD,b8Qe150xVaJsnDSv).replace(VfHYrPvolqbxLOd,b8Qe150xVaJsnDSv)
	N6gCa1OZ9HnU2 = YYBlm36zd0Jst18LXwo4.findall(DYakr9g4PVU(u"࠭ࠨ࠯ࠫ࡟࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌ࠰࠹ࡅ࠴ࡊࡡࡣࠨ࡝ࡹ࡟ࡻࡡࡽࠩࠡ࠭࡟࡟ࡡ࠵ࡃࡐࡎࡒࡖࡡࡣࠨ࠯ࠬࡂ࠭ࠩ࠭ঃ"),rlqNUcK9vYgkT,YYBlm36zd0Jst18LXwo4.DOTALL)
	if N6gCa1OZ9HnU2: wLZUyXHr4Gc7DuAxC8l0PsobmqRSQ,TFAmLfwypkzsP1UYCMr8c,rlqNUcK9vYgkT = N6gCa1OZ9HnU2[LzYQg91SIxDeOGtCKd5]
	if wLZUyXHr4Gc7DuAxC8l0PsobmqRSQ not in [pldxivXC5wbTB2O8q,Nh0BWuiSndf(u"ࠧ࠭ࠩ঄"),b8Qe150xVaJsnDSv]: GHfpZBtabwXKDdLySzCOIvlc = RRIHDFjoW9w7bSfVPhC(u"ࠨࡡࡐࡓࡉࡥࠧঅ")
	if TFAmLfwypkzsP1UYCMr8c: TFAmLfwypkzsP1UYCMr8c = S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠩࡢࠫআ")+TFAmLfwypkzsP1UYCMr8c+mQNonhS7CV2BXOv(u"ࠪࡣࠬই")
	rlqNUcK9vYgkT = TFAmLfwypkzsP1UYCMr8c+GHfpZBtabwXKDdLySzCOIvlc+rlqNUcK9vYgkT
	return rlqNUcK9vYgkT
def SgrGWuAHcLKBQMJetb9(YabJfs3q7yjpzvXioO):
	return _xIXif9OsL32TKE7nNSqzkPFb0crm(YabJfs3q7yjpzvXioO)
def rhoGF8ta4UesmTucY6V2O1A(JJ1FDd0YKMVQHpuTPgovWZwN4U9R):
	nQ30S9qK2OoP = {m6hwdgP31a2zjN7lkpX(u"ࠫࡹࡿࡰࡦࠩঈ"):b8Qe150xVaJsnDSv,Mmpr0o76iWJvz1kTtfgI8hES(u"ࠬࡳ࡯ࡥࡧࠪউ"):b8Qe150xVaJsnDSv,m6hwdgP31a2zjN7lkpX(u"࠭ࡵࡳ࡮ࠪঊ"):b8Qe150xVaJsnDSv,TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠧࡵࡧࡻࡸࠬঋ"):b8Qe150xVaJsnDSv,BWNPxIG7vqdTy85pjHzUOrK3(u"ࠨࡲࡤ࡫ࡪ࠭ঌ"):b8Qe150xVaJsnDSv,Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠩࡱࡥࡲ࡫ࠧ঍"):b8Qe150xVaJsnDSv,TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠪ࡭ࡲࡧࡧࡦࠩ঎"):b8Qe150xVaJsnDSv,mQNonhS7CV2BXOv(u"ࠫࡨࡵ࡮ࡵࡧࡻࡸࠬএ"):b8Qe150xVaJsnDSv,QTUBCcehw6qPd4x(u"ࠬ࡯࡮ࡧࡱࡧ࡭ࡨࡺࠧঐ"):b8Qe150xVaJsnDSv}
	if HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"࠭࠿ࠨ঑") in JJ1FDd0YKMVQHpuTPgovWZwN4U9R: JJ1FDd0YKMVQHpuTPgovWZwN4U9R = JJ1FDd0YKMVQHpuTPgovWZwN4U9R.split(ddo23ZJtgcY(u"ࠧࡀࠩ঒"),qHYIWnOZLPkrQU)[qHYIWnOZLPkrQU]
	MUJCtfYVBLODrFbaZn,DElaSY1fKNG37sZ5WzQ = FNIhDd4uLfev0q5YHVGx8oWm6CsiJ(JJ1FDd0YKMVQHpuTPgovWZwN4U9R)
	aargs = dict(list(nQ30S9qK2OoP.items())+list(DElaSY1fKNG37sZ5WzQ.items()))
	mmyeAsBgIT3kv1E6 = aargs[vvWwO3Tx2dAgcijrFXq(u"ࠨ࡯ࡲࡨࡪ࠭ও")]
	A1ldva3VPYrTUFm0MRk9LKCx = SgrGWuAHcLKBQMJetb9(aargs[mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠩࡸࡶࡱ࠭ঔ")])
	r73rkOwBtFfNDRTvHA8Sd0em = SgrGWuAHcLKBQMJetb9(aargs[UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠪࡸࡪࡾࡴࠨক")])
	FeUlSM0nYuvdbprEm246cXhACJD3i = SgrGWuAHcLKBQMJetb9(aargs[HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠫࡵࡧࡧࡦࠩখ")])
	yf2jUkehJXZ4zt = SgrGWuAHcLKBQMJetb9(aargs[LAQD5wEkr18bUiGaYen3J(u"ࠬࡺࡹࡱࡧࠪগ")])
	jwcrfC6BhiqmlO098NsR = SgrGWuAHcLKBQMJetb9(aargs[dDYUoKi6JFM23p(u"࠭࡮ࡢ࡯ࡨࠫঘ")])
	YY5kEzQ4B2bcTr0qnxiVd8IXDl = SgrGWuAHcLKBQMJetb9(aargs[LAQD5wEkr18bUiGaYen3J(u"ࠧࡪ࡯ࡤ࡫ࡪ࠭ঙ")])
	Uj49SuMm8dnHkQhorsapbNtf2 = aargs[DYakr9g4PVU(u"ࠨࡥࡲࡲࡹ࡫ࡸࡵࠩচ")]
	BZX58FM9boWL0yx1O7dh4P6aw = SgrGWuAHcLKBQMJetb9(aargs[RRIHDFjoW9w7bSfVPhC(u"ࠩ࡬ࡲ࡫ࡵࡤࡪࡥࡷࠫছ")])
	if BZX58FM9boWL0yx1O7dh4P6aw: BZX58FM9boWL0yx1O7dh4P6aw = eval(BZX58FM9boWL0yx1O7dh4P6aw)
	else: BZX58FM9boWL0yx1O7dh4P6aw = {}
	if not mmyeAsBgIT3kv1E6: yf2jUkehJXZ4zt = BWNPxIG7vqdTy85pjHzUOrK3(u"ࠪࡪࡴࡲࡤࡦࡴࠪজ") ; mmyeAsBgIT3kv1E6 = Nh0BWuiSndf(u"ࠫ࠷࠼࠰ࠨঝ")
	return yf2jUkehJXZ4zt,jwcrfC6BhiqmlO098NsR,A1ldva3VPYrTUFm0MRk9LKCx,mmyeAsBgIT3kv1E6,YY5kEzQ4B2bcTr0qnxiVd8IXDl,FeUlSM0nYuvdbprEm246cXhACJD3i,r73rkOwBtFfNDRTvHA8Sd0em,Uj49SuMm8dnHkQhorsapbNtf2,BZX58FM9boWL0yx1O7dh4P6aw
def EECz06teoykrNFfq(QQ8pvXNcBfVkP5rRJ7o):
	J1o3UcYnaXP4pMFwqLy0xfCsBl7eD = Pft6y0LvwSh48iYg7b._getframe(qHYIWnOZLPkrQU).f_code.co_name
	if not QQ8pvXNcBfVkP5rRJ7o or not J1o3UcYnaXP4pMFwqLy0xfCsBl7eD or J1o3UcYnaXP4pMFwqLy0xfCsBl7eD==BWNPxIG7vqdTy85pjHzUOrK3(u"ࠬࡂ࡭ࡰࡦࡸࡰࡪࡄࠧঞ"):
		return Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"࡛࠭ࠡࠩট")+iyPYHhe0wOnluEfs3JKkBG.upper()+TYf7Dc06PQgy1vEV9(u"ࠧࡠࠩঠ")+cpGrK6qnPi+uVQd103XyvUce2EBtzbYaC(u"ࠨࡡࠪড")+str(g1gmkxOtc2oeEZHhBiy)+TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠩࠣࡡࠬঢ")
	return RRIHDFjoW9w7bSfVPhC(u"ࠪ࠲ࡡࡺࠧণ")+J1o3UcYnaXP4pMFwqLy0xfCsBl7eD
def mwIxD3GBPgLVc2aq9(O1OISqMBUFzu2QHiNjeKksWJAV,Hi18qkVDrA4PCxyX5vnLdBh6fg):
	if hDTluNxe7tCwrpqXHzdEcYRfbs: Hi18qkVDrA4PCxyX5vnLdBh6fg = Hi18qkVDrA4PCxyX5vnLdBh6fg.decode(OVauxZzLI10vcXT74K).encode(OVauxZzLI10vcXT74K)
	eSoRZ7Vgix8B6HA9mN5MKj = o5nca0TPVyiFONMwut98WdSxp
	bCoNUQ3TXW7un = [b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv]
	if O1OISqMBUFzu2QHiNjeKksWJAV: Hi18qkVDrA4PCxyX5vnLdBh6fg = Hi18qkVDrA4PCxyX5vnLdBh6fg.replace(OkuB9nwhD8U1,b8Qe150xVaJsnDSv).replace(rC3Tlno96KjLDIvBaSWUbR8,b8Qe150xVaJsnDSv).replace(hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv)
	else: O1OISqMBUFzu2QHiNjeKksWJAV = MtTygrzXFlQ
	TfOUdAoSNCzryqsgJ76eQcFm4xvD,ZrBtKnWX8I6PLxF = UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠫࡡࡺࠧত"),R1BKXhzpGH6CoO9jLsPwQWu
	jnz2DgQ8Z4VJdLrcEoux0h9 = Nh0BWuiSndf(u"࠴࠳ଶ")*pldxivXC5wbTB2O8q if i1thmHk7AZquD4cM0fnp62 else mmcNLrXtzfpyCkZlvK5VwG2gujh(u"࠹࠱ଵ")*pldxivXC5wbTB2O8q
	GGESqk7fJQMV = NvHugPosYDzRJ*TfOUdAoSNCzryqsgJ76eQcFm4xvD
	if Hi18qkVDrA4PCxyX5vnLdBh6fg.startswith(kke1PDGRBLuY8y(u"ࠬࡕࡐࡆࡐࡘࡖࡑ࠭থ")): Hi18qkVDrA4PCxyX5vnLdBh6fg = UUkIBz1sgQ9WfNeG6trKXvu0(u"࠭࠮࡝ࡶࠪদ")+Hi18qkVDrA4PCxyX5vnLdBh6fg
	if MF4fVI6yJhaTkAODK in O1OISqMBUFzu2QHiNjeKksWJAV: eSoRZ7Vgix8B6HA9mN5MKj = uuxVm0bTwdnCUAL4s6NKHEBF3M.LOGERROR
	if O1OISqMBUFzu2QHiNjeKksWJAV in [MtTygrzXFlQ,MF4fVI6yJhaTkAODK]: bCoNUQ3TXW7un = [Hi18qkVDrA4PCxyX5vnLdBh6fg]
	elif O1OISqMBUFzu2QHiNjeKksWJAV==WG2BfeyzMa: bCoNUQ3TXW7un = Hi18qkVDrA4PCxyX5vnLdBh6fg.split(ZrBtKnWX8I6PLxF)
	elif O1OISqMBUFzu2QHiNjeKksWJAV==iebCpLE8fuxTRg:
		p5FQgfzqT2tI = Hi18qkVDrA4PCxyX5vnLdBh6fg.split(ZrBtKnWX8I6PLxF)
		bCoNUQ3TXW7un = [p5FQgfzqT2tI[LzYQg91SIxDeOGtCKd5]]
		for p8R0YcsOIP4KUMEkbVgABZTtN9w in range(qHYIWnOZLPkrQU,len(p5FQgfzqT2tI),IgQimel18t):
			try: VaEDXt6clIjQWgd8BiqJUsye = p5FQgfzqT2tI[p8R0YcsOIP4KUMEkbVgABZTtN9w]+ZrBtKnWX8I6PLxF+p5FQgfzqT2tI[p8R0YcsOIP4KUMEkbVgABZTtN9w+ddo23ZJtgcY(u"࠲ଷ")]
			except: VaEDXt6clIjQWgd8BiqJUsye = p5FQgfzqT2tI[p8R0YcsOIP4KUMEkbVgABZTtN9w]
			bCoNUQ3TXW7un.append(VaEDXt6clIjQWgd8BiqJUsye)
	s6oN3ncdPHrXy9zk1I = bCoNUQ3TXW7un[LzYQg91SIxDeOGtCKd5]
	for Xfu41hHADW36e5FkU in bCoNUQ3TXW7un[qHYIWnOZLPkrQU:]:
		if O1OISqMBUFzu2QHiNjeKksWJAV in [WG2BfeyzMa,iebCpLE8fuxTRg]: GGESqk7fJQMV += TfOUdAoSNCzryqsgJ76eQcFm4xvD
		s6oN3ncdPHrXy9zk1I += d6ekSEojpFUANKJ7r9WTlI3niLBOu+jnz2DgQ8Z4VJdLrcEoux0h9+GGESqk7fJQMV+Xfu41hHADW36e5FkU
	s6oN3ncdPHrXy9zk1I += RRIHDFjoW9w7bSfVPhC(u"ࠧࠡࡡࠪধ")
	if shC5qBRV2A0lZ(u"ࠨࠧࠪন") in s6oN3ncdPHrXy9zk1I: s6oN3ncdPHrXy9zk1I = SgrGWuAHcLKBQMJetb9(s6oN3ncdPHrXy9zk1I)
	uuxVm0bTwdnCUAL4s6NKHEBF3M.log(s6oN3ncdPHrXy9zk1I,level=eSoRZ7Vgix8B6HA9mN5MKj)
	return
def wFSLj4ktCvJgiPlYzsq5M8x(BqDs7wImSo05JbjR9nLrTzF):
	try: KWfFCYyj7iTlts = jA69Ts3CqJli7.connect(BqDs7wImSo05JbjR9nLrTzF,check_same_thread=QTUBCcehw6qPd4x(u"ࡈࡤࡰࡸ࡫୰"))
	except:
		if not x76PfMyAp1L2WejkU3.path.exists(vIaQF8hqXeiJERYuD):
			x76PfMyAp1L2WejkU3.makedirs(vIaQF8hqXeiJERYuD)
			KWfFCYyj7iTlts = jA69Ts3CqJli7.connect(BqDs7wImSo05JbjR9nLrTzF,check_same_thread=P0qdZI384LKleuo(u"ࡉࡥࡱࡹࡥୱ"))
	KWfFCYyj7iTlts.text_factory = str
	Yn98v3MRdasNfWB2SAG6TOV1m4tq = KWfFCYyj7iTlts.cursor()
	Yn98v3MRdasNfWB2SAG6TOV1m4tq.execute(dDYUoKi6JFM23p(u"ࠩࡓࡖࡆࡍࡍࡂࠢࡤࡹࡹࡵ࡭ࡢࡶ࡬ࡧࡤ࡯࡮ࡥࡧࡻࡁࡳࡵ࠻ࠨ঩"))
	Yn98v3MRdasNfWB2SAG6TOV1m4tq.execute(zI3ROAZtiUq42rE9WDST68(u"ࠪࡔࡗࡇࡇࡎࡃࠣ࡭࡬ࡴ࡯ࡳࡧࡢࡧ࡭࡫ࡣ࡬ࡡࡦࡳࡳࡹࡴࡳࡣ࡬ࡲࡹࡹ࠽ࡺࡧࡶ࠿ࠬপ"))
	Yn98v3MRdasNfWB2SAG6TOV1m4tq.execute(TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠫࡕࡘࡁࡈࡏࡄࠤ࡯ࡵࡵࡳࡰࡤࡰࡤࡳ࡯ࡥࡧࡀࡓࡋࡌ࠻ࠨফ"))
	Yn98v3MRdasNfWB2SAG6TOV1m4tq.execute(mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠬࡖࡒࡂࡉࡐࡅࠥࡹࡹ࡯ࡥ࡫ࡶࡴࡴ࡯ࡶࡵࡀࡓࡋࡌ࠻ࠨব"))
	pie0DRMAtn = ttL0ldrI6Jxhbq2WTN(BqDs7wImSo05JbjR9nLrTzF,KWfFCYyj7iTlts,Yn98v3MRdasNfWB2SAG6TOV1m4tq,DD5cFIejQa2X4BgAu9GWPyJ3tC7,dDYUoKi6JFM23p(u"࠭ࡂࡆࡉࡌࡒࠥࡏࡍࡎࡇࡇࡍࡆ࡚ࡅࠡࡖࡕࡅࡓ࡙ࡁࡄࡖࡌࡓࡓࠦ࠻ࠨভ"))
	if pie0DRMAtn: KWfFCYyj7iTlts.commit()
	else:
		ldtI4ef3qWaKVP5p()
	return KWfFCYyj7iTlts,Yn98v3MRdasNfWB2SAG6TOV1m4tq
def ttL0ldrI6Jxhbq2WTN(BqDs7wImSo05JbjR9nLrTzF,KWfFCYyj7iTlts,Yn98v3MRdasNfWB2SAG6TOV1m4tq,P0LySN4QGnqYRVb6ZcoadCz9k,itV2l1rGkHSydO,DUoFN0mZsMQCa4fHkewxuIvLJ=()):
	try:
		if P0LySN4QGnqYRVb6ZcoadCz9k: Yn98v3MRdasNfWB2SAG6TOV1m4tq.executemany(itV2l1rGkHSydO,DUoFN0mZsMQCa4fHkewxuIvLJ)
		else: Yn98v3MRdasNfWB2SAG6TOV1m4tq.execute(itV2l1rGkHSydO,DUoFN0mZsMQCa4fHkewxuIvLJ)
		KWfFCYyj7iTlts.commit()
		pie0DRMAtn = CCxMXuNUEzolDZTKrBJ
	except:
		pie0DRMAtn,timeout = DD5cFIejQa2X4BgAu9GWPyJ3tC7,ddo23ZJtgcY(u"࠳࠳ସ")
		U8UjsBH1K5mxJ4og3DcL = wLQCTr5lqbsVYeAHdzfhZ1F.time()
		while wLQCTr5lqbsVYeAHdzfhZ1F.time()-U8UjsBH1K5mxJ4og3DcL<timeout and not pie0DRMAtn:
			try:
				if P0LySN4QGnqYRVb6ZcoadCz9k: Yn98v3MRdasNfWB2SAG6TOV1m4tq.executemany(itV2l1rGkHSydO,DUoFN0mZsMQCa4fHkewxuIvLJ)
				else: Yn98v3MRdasNfWB2SAG6TOV1m4tq.execute(itV2l1rGkHSydO,DUoFN0mZsMQCa4fHkewxuIvLJ)
				KWfFCYyj7iTlts.commit()
				pie0DRMAtn = CCxMXuNUEzolDZTKrBJ
			except: wLQCTr5lqbsVYeAHdzfhZ1F.sleep(dDYUoKi6JFM23p(u"࠳࠲࠺ହ"))
		if not pie0DRMAtn:
			mwIxD3GBPgLVc2aq9(WG2BfeyzMa,vvWwO3Tx2dAgcijrFXq(u"ࠧ࠯࡞ࡷ࡙ࡳࡧࡢ࡭ࡧࠣࡸࡴࠦࡷࡳ࡫ࡷࡩࠥࡺ࡯ࠡࡶ࡫ࡩࠥࡪࡡࡵࡣࡥࡥࡸ࡫ࠠࡧ࡫࡯ࡩࠥࠦࠠࠨম")+BqDs7wImSo05JbjR9nLrTzF+RRIHDFjoW9w7bSfVPhC(u"ࠨࠢࠣࠤࡋࡧࡩ࡭ࡧࡧࠤࡼ࡮ࡥ࡯ࠢࡨࡼࡪࡩࡵࡵ࡫ࡱ࡫ࠥࡺࡨࡪࡵࠣࡷࡹࡧࡴࡦ࡯ࡨࡲࡹࠦࠠࠡࠩয")+itV2l1rGkHSydO+eeN6dTEnkJxI)
			import hIVCFnfxSO
			hIVCFnfxSO.yicQV3gj4q(Xz3bA2PFENVCUtplu51(u"ࠩไุ้ࠦแ๋ࠢๅห฾ีษࠡษ็ฬ๏อๆศฬࠪর"),mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠪࡊࡦ࡯࡬ࡶࡴࡨࠫ঱"))
	return pie0DRMAtn
def SS2OK7hjLagvUAm(BqDs7wImSo05JbjR9nLrTzF,suA0cTlxyCN,eTjHodvsyUOgcaizmCf52MWbZI3,eSxcKqI0uFBTkV=None):
	kTSyagGWsFnolYhMO5fCwvpNuPqR = LB3nD2quMYr6p1VP9GF0N587xAeS(suA0cTlxyCN)
	nWxkguOY04XVsEwQJ = hRWC8YSFvsm4JHOMVIne3jquZ.getSetting(mQNonhS7CV2BXOv(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡩࡶࡷࡴࡨࡧࡣࡩࡧࠪল"))
	if eTjHodvsyUOgcaizmCf52MWbZI3 not in [TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨ঳"),RRIHDFjoW9w7bSfVPhC(u"࠭ࡇࡍࡑࡅࡅࡑ࡙ࡅࡂࡔࡆࡌࡤ࡙ࡐࡍࡋࡗࡘࡊࡊ࡟ࡂࡎࡏࠫ঴"),BmePGjS7FxK6kutUM(u"ࠧࡈࡎࡒࡆࡆࡒࡓࡆࡃࡕࡇࡍࡥࡓࡑࡎࡌࡘ࡙ࡋࡄࡠࡉࡒࡓࡌࡒࡅࠨ঵")] and BqDs7wImSo05JbjR9nLrTzF==mshLJcKH1fv03yRnDOr4ZT and eSxcKqI0uFBTkV!=QTUBCcehw6qPd4x(u"ࠨࡏࡈࡗࡘࡇࡇࡆࡕࠪশ"):
		if nWxkguOY04XVsEwQJ==ubxGUTt1LraKhVZgpAP(u"ࠩࡖࡘࡔࡖࠧষ"): return kTSyagGWsFnolYhMO5fCwvpNuPqR
		iPKbSRLnl2HJxFMjwQkGza = hRWC8YSFvsm4JHOMVIne3jquZ.getSetting(Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡲࡦࡨࡵࡩࡸ࡮ࠧস"))
		if iPKbSRLnl2HJxFMjwQkGza==dDYUoKi6JFM23p(u"ࠫࡗࡋࡆࡓࡇࡖࡌࡤࡉࡁࡄࡊࡈࠫহ"):
			zqbhiLmQfC3VK9Arku(BqDs7wImSo05JbjR9nLrTzF,eTjHodvsyUOgcaizmCf52MWbZI3,eSxcKqI0uFBTkV)
			return kTSyagGWsFnolYhMO5fCwvpNuPqR
	ddDV7szA3PtH1IwaB6eZQUNSf = LzYQg91SIxDeOGtCKd5
	if nWxkguOY04XVsEwQJ==QTUBCcehw6qPd4x(u"ࠬࡒࡉࡎࡋࡗࡉࡉ࠭঺"): ddDV7szA3PtH1IwaB6eZQUNSf = CulwpQfz75qMK0PIJSDcaNZ4G
	KWfFCYyj7iTlts,Yn98v3MRdasNfWB2SAG6TOV1m4tq = wFSLj4ktCvJgiPlYzsq5M8x(BqDs7wImSo05JbjR9nLrTzF)
	wyQSVGIib0NUA7 = Yn98v3MRdasNfWB2SAG6TOV1m4tq.execute(dDYUoKi6JFM23p(u"࠭ࡓࡆࡎࡈࡇ࡙ࠦ࡮ࡢ࡯ࡨࠤࡋࡘࡏࡎࠢࡶࡵࡱ࡯ࡴࡦࡡࡰࡥࡸࡺࡥࡳ࡚ࠢࡌࡊࡘࡅࠡࡶࡼࡴࡪࡃࠢࡵࡣࡥࡰࡪࠨࠠࡂࡐࡇࠤࡳࡧ࡭ࡦ࠿ࠥࠫ঻")+eTjHodvsyUOgcaizmCf52MWbZI3+BmePGjS7FxK6kutUM(u"ࠧࠣࠢ࠾়ࠫ")).fetchall()
	if wyQSVGIib0NUA7:
		if ddDV7szA3PtH1IwaB6eZQUNSf: ttL0ldrI6Jxhbq2WTN(BqDs7wImSo05JbjR9nLrTzF,KWfFCYyj7iTlts,Yn98v3MRdasNfWB2SAG6TOV1m4tq,DD5cFIejQa2X4BgAu9GWPyJ3tC7,RRIHDFjoW9w7bSfVPhC(u"ࠨࡆࡈࡐࡊ࡚ࡅࠡࡈࡕࡓࡒࠦࠢࠨঽ")+eTjHodvsyUOgcaizmCf52MWbZI3+dDYUoKi6JFM23p(u"ࠩࠥࠤ࡜ࡎࡅࡓࡇࠣࡩࡽࡶࡩࡳࡻࡁࠫা")+str(T3Axql94cU0BpO1wudEDtWXsf+ddDV7szA3PtH1IwaB6eZQUNSf)+ddo23ZJtgcY(u"ࠪࠤࡀ࠭ি"))
		ttL0ldrI6Jxhbq2WTN(BqDs7wImSo05JbjR9nLrTzF,KWfFCYyj7iTlts,Yn98v3MRdasNfWB2SAG6TOV1m4tq,DD5cFIejQa2X4BgAu9GWPyJ3tC7,TYf7Dc06PQgy1vEV9(u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࠥࠫী")+eTjHodvsyUOgcaizmCf52MWbZI3+Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠬࠨࠠࡘࡊࡈࡖࡊࠦࡥࡹࡲ࡬ࡶࡾࡂࠧু")+str(T3Axql94cU0BpO1wudEDtWXsf)+DYakr9g4PVU(u"࠭ࠠ࠼ࠩূ"))
		if eSxcKqI0uFBTkV:
			OO4FYrRnTaC5I6t9HwXAkKze = (str(eSxcKqI0uFBTkV),)
			Yn98v3MRdasNfWB2SAG6TOV1m4tq.execute(QQdAXWBc2GPw(u"ࠧࡔࡇࡏࡉࡈ࡚ࠠࡥࡣࡷࡥࠥࡌࡒࡐࡏࠣࠦࠬৃ")+eTjHodvsyUOgcaizmCf52MWbZI3+TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠨࠤ࡛ࠣࡍࡋࡒࡆࠢࡦࡳࡱࡻ࡭࡯ࠢࡀࠤࡄࠦ࠻ࠨৄ"),OO4FYrRnTaC5I6t9HwXAkKze)
			tG5TJBEmWonrxFvRdXq76c8febiQVS = Yn98v3MRdasNfWB2SAG6TOV1m4tq.fetchall()
			if tG5TJBEmWonrxFvRdXq76c8febiQVS:
				try:
					vv5M4UfJS9ucKEiNbxtnaOZ = bk64KT2Z3WylUt.decompress(tG5TJBEmWonrxFvRdXq76c8febiQVS[LzYQg91SIxDeOGtCKd5][LzYQg91SIxDeOGtCKd5])
					kTSyagGWsFnolYhMO5fCwvpNuPqR = HKrlqY4uvyRC.loads(vv5M4UfJS9ucKEiNbxtnaOZ)
				except: pass
		else:
			Yn98v3MRdasNfWB2SAG6TOV1m4tq.execute(shC5qBRV2A0lZ(u"ࠩࡖࡉࡑࡋࡃࡕࠢࡦࡳࡱࡻ࡭࡯࠮ࡧࡥࡹࡧࠠࡇࡔࡒࡑࠥࠨࠧ৅")+eTjHodvsyUOgcaizmCf52MWbZI3+uVQd103XyvUce2EBtzbYaC(u"ࠪࠦࠥࡁࠧ৆"))
			tG5TJBEmWonrxFvRdXq76c8febiQVS = Yn98v3MRdasNfWB2SAG6TOV1m4tq.fetchall()
			if tG5TJBEmWonrxFvRdXq76c8febiQVS:
				kTSyagGWsFnolYhMO5fCwvpNuPqR,Z2fsyH1Vdz7X = {},[]
				for gaCNbjkVdeTmLcYy4FpKwWo2,EEkjQFxOabod08Nr in tG5TJBEmWonrxFvRdXq76c8febiQVS:
					NNjD4IlzdF = bk64KT2Z3WylUt.decompress(EEkjQFxOabod08Nr)
					EEkjQFxOabod08Nr = HKrlqY4uvyRC.loads(NNjD4IlzdF)
					kTSyagGWsFnolYhMO5fCwvpNuPqR[gaCNbjkVdeTmLcYy4FpKwWo2] = EEkjQFxOabod08Nr
					Z2fsyH1Vdz7X.append(gaCNbjkVdeTmLcYy4FpKwWo2)
				if Z2fsyH1Vdz7X:
					kTSyagGWsFnolYhMO5fCwvpNuPqR[TYf7Dc06PQgy1vEV9(u"ࠫࡤࡥࡓࡆࡓࡘࡉࡓࡉࡅࡅࡡࡆࡓࡑ࡛ࡍࡏࡕࡢࡣࠬে")] = Z2fsyH1Vdz7X
					if suA0cTlxyCN==P0qdZI384LKleuo(u"ࠬࡲࡩࡴࡶࠪৈ"): kTSyagGWsFnolYhMO5fCwvpNuPqR = Z2fsyH1Vdz7X
	KWfFCYyj7iTlts.close()
	return kTSyagGWsFnolYhMO5fCwvpNuPqR
def PGudrhJF8iDkSq96XVHEQZYf5L(BqDs7wImSo05JbjR9nLrTzF,eTjHodvsyUOgcaizmCf52MWbZI3,eSxcKqI0uFBTkV,kTSyagGWsFnolYhMO5fCwvpNuPqR,YvCpEQWXGal61uT,N6Aq8FjUafvWrsR1kCn7h=DD5cFIejQa2X4BgAu9GWPyJ3tC7):
	nWxkguOY04XVsEwQJ = hRWC8YSFvsm4JHOMVIne3jquZ.getSetting(mQNonhS7CV2BXOv(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰࡫ࡸࡹࡶࡣࡢࡥ࡫ࡩࠬ৉"))
	if nWxkguOY04XVsEwQJ==IjZbnrBJmM2N(u"ࠧࡍࡋࡐࡍ࡙ࡋࡄࠨ৊") and YvCpEQWXGal61uT>CulwpQfz75qMK0PIJSDcaNZ4G: YvCpEQWXGal61uT = CulwpQfz75qMK0PIJSDcaNZ4G
	if N6Aq8FjUafvWrsR1kCn7h:
		xhWaiNzZPjTfLQV9b7H382ovXrEKBe,zRDNtpElrcUmhTkC = [],[]
		for s9s45taoNBh60XL1zykOmTK3jJCrE in range(len(eSxcKqI0uFBTkV)):
			vv5M4UfJS9ucKEiNbxtnaOZ = HKrlqY4uvyRC.dumps(kTSyagGWsFnolYhMO5fCwvpNuPqR[s9s45taoNBh60XL1zykOmTK3jJCrE])
			qR4CdGXSWf2lhgNo = bk64KT2Z3WylUt.compress(vv5M4UfJS9ucKEiNbxtnaOZ)
			xhWaiNzZPjTfLQV9b7H382ovXrEKBe.append((eSxcKqI0uFBTkV[s9s45taoNBh60XL1zykOmTK3jJCrE],))
			zRDNtpElrcUmhTkC.append((YvCpEQWXGal61uT+T3Axql94cU0BpO1wudEDtWXsf,str(eSxcKqI0uFBTkV[s9s45taoNBh60XL1zykOmTK3jJCrE]),qR4CdGXSWf2lhgNo))
	else:
		vv5M4UfJS9ucKEiNbxtnaOZ = HKrlqY4uvyRC.dumps(kTSyagGWsFnolYhMO5fCwvpNuPqR)
		bbYlLXdkFwq2hCPx3 = bk64KT2Z3WylUt.compress(vv5M4UfJS9ucKEiNbxtnaOZ)
	KWfFCYyj7iTlts,Yn98v3MRdasNfWB2SAG6TOV1m4tq = wFSLj4ktCvJgiPlYzsq5M8x(BqDs7wImSo05JbjR9nLrTzF)
	ttL0ldrI6Jxhbq2WTN(BqDs7wImSo05JbjR9nLrTzF,KWfFCYyj7iTlts,Yn98v3MRdasNfWB2SAG6TOV1m4tq,DD5cFIejQa2X4BgAu9GWPyJ3tC7,TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠨࡅࡕࡉࡆ࡚ࡅࠡࡖࡄࡆࡑࡋࠠࡊࡈࠣࡒࡔ࡚ࠠࡆ࡚ࡌࡗ࡙࡙ࠠࠣࠩো")+eTjHodvsyUOgcaizmCf52MWbZI3+Xz3bA2PFENVCUtplu51(u"ࠩࠥࠤ࠭࡫ࡸࡱ࡫ࡵࡽ࠱ࡩ࡯࡭ࡷࡰࡲ࠱ࡪࡡࡵࡣࠬࠤࡀ࠭ৌ"))
	if N6Aq8FjUafvWrsR1kCn7h:
		ttL0ldrI6Jxhbq2WTN(BqDs7wImSo05JbjR9nLrTzF,KWfFCYyj7iTlts,Yn98v3MRdasNfWB2SAG6TOV1m4tq,CCxMXuNUEzolDZTKrBJ,Mmpr0o76iWJvz1kTtfgI8hES(u"ࠪࡈࡊࡒࡅࡕࡇࠣࡊࡗࡕࡍࠡࠤ্ࠪ")+eTjHodvsyUOgcaizmCf52MWbZI3+uVQd103XyvUce2EBtzbYaC(u"ࠫࠧࠦࡗࡉࡇࡕࡉࠥࡩ࡯࡭ࡷࡰࡲࠥࡃࠠࡀࠢ࠾ࠫৎ"),xhWaiNzZPjTfLQV9b7H382ovXrEKBe)
		ttL0ldrI6Jxhbq2WTN(BqDs7wImSo05JbjR9nLrTzF,KWfFCYyj7iTlts,Yn98v3MRdasNfWB2SAG6TOV1m4tq,CCxMXuNUEzolDZTKrBJ,ubxGUTt1LraKhVZgpAP(u"ࠬࡏࡎࡔࡇࡕࡘࠥࡏࡎࡕࡑࠣࠦࠬ৏")+eTjHodvsyUOgcaizmCf52MWbZI3+ubxGUTt1LraKhVZgpAP(u"࠭ࠢࠡࡘࡄࡐ࡚ࡋࡓࠡࠪࡂ࠰ࡄ࠲࠿ࠪࠢ࠾ࠫ৐"),zRDNtpElrcUmhTkC)
	else:
		if YvCpEQWXGal61uT:
			OO4FYrRnTaC5I6t9HwXAkKze = (str(eSxcKqI0uFBTkV),)
			ttL0ldrI6Jxhbq2WTN(BqDs7wImSo05JbjR9nLrTzF,KWfFCYyj7iTlts,Yn98v3MRdasNfWB2SAG6TOV1m4tq,DD5cFIejQa2X4BgAu9GWPyJ3tC7,ubxGUTt1LraKhVZgpAP(u"ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥࠨࠧ৑")+eTjHodvsyUOgcaizmCf52MWbZI3+S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠨࠤ࡛ࠣࡍࡋࡒࡆࠢࡦࡳࡱࡻ࡭࡯ࠢࡀࠤࡄࠦ࠻ࠨ৒"),OO4FYrRnTaC5I6t9HwXAkKze)
			OO4FYrRnTaC5I6t9HwXAkKze = (YvCpEQWXGal61uT+T3Axql94cU0BpO1wudEDtWXsf,str(eSxcKqI0uFBTkV),bbYlLXdkFwq2hCPx3)
			ttL0ldrI6Jxhbq2WTN(BqDs7wImSo05JbjR9nLrTzF,KWfFCYyj7iTlts,Yn98v3MRdasNfWB2SAG6TOV1m4tq,DD5cFIejQa2X4BgAu9GWPyJ3tC7,RRIHDFjoW9w7bSfVPhC(u"ࠩࡌࡒࡘࡋࡒࡕࠢࡌࡒ࡙ࡕࠠࠣࠩ৓")+eTjHodvsyUOgcaizmCf52MWbZI3+BWNPxIG7vqdTy85pjHzUOrK3(u"ࠪࠦࠥ࡜ࡁࡍࡗࡈࡗࠥ࠮࠿࠭ࡁ࠯ࡃ࠮ࠦ࠻ࠨ৔"),OO4FYrRnTaC5I6t9HwXAkKze)
		else:
			OO4FYrRnTaC5I6t9HwXAkKze = (bbYlLXdkFwq2hCPx3,str(eSxcKqI0uFBTkV))
			ttL0ldrI6Jxhbq2WTN(BqDs7wImSo05JbjR9nLrTzF,KWfFCYyj7iTlts,Yn98v3MRdasNfWB2SAG6TOV1m4tq,DD5cFIejQa2X4BgAu9GWPyJ3tC7,HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"࡚ࠫࡖࡄࡂࡖࡈࠤࠧ࠭৕")+eTjHodvsyUOgcaizmCf52MWbZI3+mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠬࠨࠠࡔࡇࡗࠤࡩࡧࡴࡢࠢࡀࠤࡄࠦࡗࡉࡇࡕࡉࠥࡩ࡯࡭ࡷࡰࡲࠥࡃࠠࡀࠢ࠾ࠫ৖"),OO4FYrRnTaC5I6t9HwXAkKze)
	KWfFCYyj7iTlts.close()
	return
def zqbhiLmQfC3VK9Arku(BqDs7wImSo05JbjR9nLrTzF,eTjHodvsyUOgcaizmCf52MWbZI3,eSxcKqI0uFBTkV=None):
	KWfFCYyj7iTlts,Yn98v3MRdasNfWB2SAG6TOV1m4tq = wFSLj4ktCvJgiPlYzsq5M8x(BqDs7wImSo05JbjR9nLrTzF)
	if eSxcKqI0uFBTkV==None: ttL0ldrI6Jxhbq2WTN(BqDs7wImSo05JbjR9nLrTzF,KWfFCYyj7iTlts,Yn98v3MRdasNfWB2SAG6TOV1m4tq,DD5cFIejQa2X4BgAu9GWPyJ3tC7,DYakr9g4PVU(u"࠭ࡄࡓࡑࡓࠤ࡙ࡇࡂࡍࡇࠣࡍࡋࠦࡅ࡙ࡋࡖࡘࡘࠦࠢࠨৗ")+eTjHodvsyUOgcaizmCf52MWbZI3+P0qdZI384LKleuo(u"ࠧࠣࠢ࠾ࠫ৘"))
	else:
		wyQSVGIib0NUA7 = Yn98v3MRdasNfWB2SAG6TOV1m4tq.execute(RRIHDFjoW9w7bSfVPhC(u"ࠨࡕࡈࡐࡊࡉࡔࠡࡰࡤࡱࡪࠦࡆࡓࡑࡐࠤࡸࡷ࡬ࡪࡶࡨࡣࡲࡧࡳࡵࡧࡵࠤ࡜ࡎࡅࡓࡇࠣࡸࡾࡶࡥ࠾ࠤࡷࡥࡧࡲࡥࠣࠢࡄࡒࡉࠦ࡮ࡢ࡯ࡨࡁࠧ࠭৙")+eTjHodvsyUOgcaizmCf52MWbZI3+QTUBCcehw6qPd4x(u"ࠩࠥࠤࡀ࠭৚")).fetchall()
		if wyQSVGIib0NUA7:
			OO4FYrRnTaC5I6t9HwXAkKze = (str(eSxcKqI0uFBTkV),)
			if TYf7Dc06PQgy1vEV9(u"ࠪࠩࠬ৛") in eSxcKqI0uFBTkV: ttL0ldrI6Jxhbq2WTN(BqDs7wImSo05JbjR9nLrTzF,KWfFCYyj7iTlts,Yn98v3MRdasNfWB2SAG6TOV1m4tq,DD5cFIejQa2X4BgAu9GWPyJ3tC7,dDYUoKi6JFM23p(u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࠥࠫড়")+eTjHodvsyUOgcaizmCf52MWbZI3+S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠬࠨࠠࡘࡊࡈࡖࡊࠦࡣࡰ࡮ࡸࡱࡳࠦ࡬ࡪ࡭ࡨࠤࡄࠦ࠻ࠨঢ়"),OO4FYrRnTaC5I6t9HwXAkKze)
			else: ttL0ldrI6Jxhbq2WTN(BqDs7wImSo05JbjR9nLrTzF,KWfFCYyj7iTlts,Yn98v3MRdasNfWB2SAG6TOV1m4tq,DD5cFIejQa2X4BgAu9GWPyJ3tC7,QQdAXWBc2GPw(u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࠧ࠭৞")+eTjHodvsyUOgcaizmCf52MWbZI3+Xz3bA2PFENVCUtplu51(u"࡚ࠧࠣࠢࡌࡊࡘࡅࠡࡥࡲࡰࡺࡳ࡮ࠡ࠿ࠣࡃࠥࡁࠧয়"),OO4FYrRnTaC5I6t9HwXAkKze)
	KWfFCYyj7iTlts.close()
	return
class bAES5Y70WpOjl2hqoGCZtzMN(): pass
class BwV6rAIldfsGyK7oeJT053(bAES5Y70WpOjl2hqoGCZtzMN):
	def __init__(xV8HnYIrUoJ7X):
		xV8HnYIrUoJ7X.url = b8Qe150xVaJsnDSv
		xV8HnYIrUoJ7X.code = -zI3ROAZtiUq42rE9WDST68(u"࠽࠾଺")
		xV8HnYIrUoJ7X.reason = b8Qe150xVaJsnDSv
		xV8HnYIrUoJ7X.content = b8Qe150xVaJsnDSv
		xV8HnYIrUoJ7X.headers = {}
		xV8HnYIrUoJ7X.cookies = {}
		xV8HnYIrUoJ7X.succeeded = DD5cFIejQa2X4BgAu9GWPyJ3tC7
def LB3nD2quMYr6p1VP9GF0N587xAeS(E57WK4m31C8):
	if E57WK4m31C8==UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠨࡦ࡬ࡧࡹ࠭ৠ"): kTSyagGWsFnolYhMO5fCwvpNuPqR = {}
	elif E57WK4m31C8==Mmpr0o76iWJvz1kTtfgI8hES(u"ࠩ࡯࡭ࡸࡺࠧৡ"): kTSyagGWsFnolYhMO5fCwvpNuPqR = []
	elif E57WK4m31C8==Xz3bA2PFENVCUtplu51(u"ࠪࡸࡺࡶ࡬ࡦࠩৢ"): kTSyagGWsFnolYhMO5fCwvpNuPqR = ()
	elif E57WK4m31C8==yST5AHEfvPmcWpwGuh2BJ(u"ࠫࡸࡺࡲࠨৣ"): kTSyagGWsFnolYhMO5fCwvpNuPqR = b8Qe150xVaJsnDSv
	elif E57WK4m31C8==vvWwO3Tx2dAgcijrFXq(u"ࠬ࡯࡮ࡵࠩ৤"): kTSyagGWsFnolYhMO5fCwvpNuPqR = LzYQg91SIxDeOGtCKd5
	elif E57WK4m31C8==IjZbnrBJmM2N(u"࠭ࡲࡦࡵࡳࡳࡳࡹࡥࠨ৥"): kTSyagGWsFnolYhMO5fCwvpNuPqR = BwV6rAIldfsGyK7oeJT053()
	elif not E57WK4m31C8: kTSyagGWsFnolYhMO5fCwvpNuPqR = None
	else: kTSyagGWsFnolYhMO5fCwvpNuPqR = None
	return kTSyagGWsFnolYhMO5fCwvpNuPqR
def YRU71oePGNrDj5AOHapluvtMy(gm1xtCvcXPUr94DR):
	qdFxInjMCh0WbDo = hRWC8YSFvsm4JHOMVIne3jquZ.getSetting(LAQD5wEkr18bUiGaYen3J(u"ࠧࡢࡸ࠱ࡴࡷ࡯ࡶࡴ࠳ࠪ০"))
	bjHNlso3mtVgZUpK8Jda = EtvK0T2LNPcsIrAFlufpM.splitlines()
	ccSfmeaKCGxX3oUO5wLY26qns = LzYQg91SIxDeOGtCKd5
	oV0GR4qirXzE1QnI2xNZmu3M = len(gm1xtCvcXPUr94DR)
	JKb83QFIyswce4a1C6WXLkSG = [DD5cFIejQa2X4BgAu9GWPyJ3tC7]*oV0GR4qirXzE1QnI2xNZmu3M
	for EauhVzO7WQRwxgCDoFqZklX1U in [T3Axql94cU0BpO1wudEDtWXsf,T3Axql94cU0BpO1wudEDtWXsf-LtlXH3fvMydAx]:
		Jh7PO5xwjkF8sod4rAtX19yR = str(EauhVzO7WQRwxgCDoFqZklX1U*P0qdZI384LKleuo(u"࠷࠰࠱࠲࠳࠴࠳࠶଼")/Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"࠹࠹࠲࠱࠲࠳଻"))[LzYQg91SIxDeOGtCKd5:DYakr9g4PVU(u"࠴ଽ")]
		if Jh7PO5xwjkF8sod4rAtX19yR!=ccSfmeaKCGxX3oUO5wLY26qns:
			for p8R0YcsOIP4KUMEkbVgABZTtN9w in range(oV0GR4qirXzE1QnI2xNZmu3M):
				if not JKb83QFIyswce4a1C6WXLkSG[p8R0YcsOIP4KUMEkbVgABZTtN9w]:
					DrCzdglG0ut6YkXp1c5J7BMHwU = DD5cFIejQa2X4BgAu9GWPyJ3tC7
					for SZokKUXTMbv in bjHNlso3mtVgZUpK8Jda:
						sfMtNaBFcq9QUIXLVGo7KRhvP1 = m6hwdgP31a2zjN7lkpX(u"ࠨ࡚࠴࠽ࠬ১")+gm1xtCvcXPUr94DR[p8R0YcsOIP4KUMEkbVgABZTtN9w]+QQdAXWBc2GPw(u"ࠩ࠴࠼ࡂ࠭২")+SZokKUXTMbv[-HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"࠳࠶ା"):]+cpGrK6qnPi+Jh7PO5xwjkF8sod4rAtX19yR
						sfMtNaBFcq9QUIXLVGo7KRhvP1 = dVRkZo9Daz.md5(sfMtNaBFcq9QUIXLVGo7KRhvP1.encode(OVauxZzLI10vcXT74K)).hexdigest()[:Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"࠵࠵ି")]
						if sfMtNaBFcq9QUIXLVGo7KRhvP1 in qdFxInjMCh0WbDo:
							DrCzdglG0ut6YkXp1c5J7BMHwU = CCxMXuNUEzolDZTKrBJ
							break
					JKb83QFIyswce4a1C6WXLkSG[p8R0YcsOIP4KUMEkbVgABZTtN9w] = DrCzdglG0ut6YkXp1c5J7BMHwU
		ccSfmeaKCGxX3oUO5wLY26qns = Jh7PO5xwjkF8sod4rAtX19yR
	return JKb83QFIyswce4a1C6WXLkSG
class uu3PFVGN5jWA(kQ4rH0JsKCYlEUP):
	def __init__(xV8HnYIrUoJ7X): pass
	def zn8a25jkRfSJENI4vy7KO6ie9(xV8HnYIrUoJ7X,XgMrI9aqeVGd7BSEl):
		xV8HnYIrUoJ7X.QhOMexbRWaulX = Nh0BWuiSndf(u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠫ৩") if XrloM5pTyK.r6rSFTpNl5nqd4s9GbEK8zhoXY else b8Qe150xVaJsnDSv
		xV8HnYIrUoJ7X.XgMrI9aqeVGd7BSEl = XgMrI9aqeVGd7BSEl
		if not XrloM5pTyK.xd4VjQuvJDC2ms:
			import hIVCFnfxSO
			hIVCFnfxSO.lp8eUQ9rw25BhRgWNPHT7K(IiYS8Jg4da3UuDP0qr6vy)
	def onPlayBackStopped(xV8HnYIrUoJ7X): xV8HnYIrUoJ7X.QhOMexbRWaulX = dDYUoKi6JFM23p(u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫ৪")
	def onPlayBackError(xV8HnYIrUoJ7X): xV8HnYIrUoJ7X.QhOMexbRWaulX = Nh0BWuiSndf(u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬ৫")
	def onPlayBackEnded(xV8HnYIrUoJ7X): xV8HnYIrUoJ7X.QhOMexbRWaulX = IjZbnrBJmM2N(u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭৬")
	def onPlayBackStarted(xV8HnYIrUoJ7X):
		xV8HnYIrUoJ7X.QhOMexbRWaulX = TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠧࡴࡶࡤࡶࡹ࡫ࡤࠨ৭")
		f4nHwcDpboPtUX = Ay1SMOzkx5CU3aGTL4Zf.Thread(target=xV8HnYIrUoJ7X.DkQsqRfNCJydGan7SXvW4oehu96m,args=())
		f4nHwcDpboPtUX.start()
	def onAVStarted(xV8HnYIrUoJ7X):
		if XrloM5pTyK.xd4VjQuvJDC2ms: xV8HnYIrUoJ7X.QhOMexbRWaulX = TYf7Dc06PQgy1vEV9(u"ࠨࡲ࡯ࡥࡾ࡯࡮ࡨࠩ৮")
		else: xV8HnYIrUoJ7X.QhOMexbRWaulX = VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠩࡷࡩࡸࡺࡩ࡯ࡩࠪ৯")
	def DkQsqRfNCJydGan7SXvW4oehu96m(xV8HnYIrUoJ7X):
		Ljkr2F3IQgNn8v6(LAQD5wEkr18bUiGaYen3J(u"ࠪࡷࡹࡵࡰࠨৰ"))
		ENcK2uWSzh0 = LzYQg91SIxDeOGtCKd5
		while not eval(DYakr9g4PVU(u"ࠫࡽࡨ࡭ࡤ࠰ࡓࡰࡦࡿࡥࡳࠪࠬ࠲࡮ࡹࡐ࡭ࡣࡼ࡭ࡳ࡭ࠨࠪࠩৱ"),{mQNonhS7CV2BXOv(u"ࠬࡾࡢ࡮ࡥࠪ৲"):uuxVm0bTwdnCUAL4s6NKHEBF3M}) and xV8HnYIrUoJ7X.QhOMexbRWaulX==Xz3bA2PFENVCUtplu51(u"࠭ࡳࡵࡣࡵࡸࡪࡪࠧ৳"):
			uuxVm0bTwdnCUAL4s6NKHEBF3M.sleep(UUkIBz1sgQ9WfNeG6trKXvu0(u"࠴࠴࠵࠶ୀ"))
			ENcK2uWSzh0 += qHYIWnOZLPkrQU
			if ENcK2uWSzh0>BWNPxIG7vqdTy85pjHzUOrK3(u"࠺࠵ୁ"): return
		if XrloM5pTyK.r6rSFTpNl5nqd4s9GbEK8zhoXY: xV8HnYIrUoJ7X.QhOMexbRWaulX = TYf7Dc06PQgy1vEV9(u"ࠧࡣ࡮ࡲࡧࡰ࡫ࡤࠨ৴")
		elif XrloM5pTyK.xd4VjQuvJDC2ms: xV8HnYIrUoJ7X.QhOMexbRWaulX = IjZbnrBJmM2N(u"ࠨࡲ࡯ࡥࡾ࡯࡮ࡨࠩ৵")
		elif XrloM5pTyK.jnUMHEBQmux94kPbOZXYaAoheNq3L6:
			import hIVCFnfxSO
			xV8HnYIrUoJ7X.QhOMexbRWaulX = uVQd103XyvUce2EBtzbYaC(u"ࠩࡷࡩࡸࡺࡩ࡯ࡩࠪ৶")
			s4Gq9zKuhydTlOmFDLYaAnNo = Ay1SMOzkx5CU3aGTL4Zf.Thread(target=hIVCFnfxSO.Yvr0IT4L5Q,args=(xV8HnYIrUoJ7X.XgMrI9aqeVGd7BSEl,))
			s4Gq9zKuhydTlOmFDLYaAnNo.start()
			YHDawRQdl04BeXz = Ay1SMOzkx5CU3aGTL4Zf.Thread(target=hIVCFnfxSO.llqyRw7Wkuv2MmLiC1jUa,args=())
			YHDawRQdl04BeXz.start()
		else: xV8HnYIrUoJ7X.QhOMexbRWaulX = mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠫ৷")
def NVlW2pICaOH0ekhRQob():
	DX2AbemCqcB5Yt4MdlGRfS0Q6Jo,aan2sotRLF8klg1bYiyTzj3pIc = b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv
	M5XmZb763oUH = uuxVm0bTwdnCUAL4s6NKHEBF3M.getInfoLabel(Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠫࡘࡿࡳࡵࡧࡰ࠲ࡋࡸࡩࡦࡰࡧࡰࡾࡔࡡ࡮ࡧࠪ৸"))
	try:
		mLaFM65Nt3bgG = open(UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠬ࠵ࡰࡳࡱࡦ࠳ࡨࡶࡵࡪࡰࡩࡳࠬ৹"),UUkIBz1sgQ9WfNeG6trKXvu0(u"࠭ࡲࡣࠩ৺")).read()
		if i1thmHk7AZquD4cM0fnp62: mLaFM65Nt3bgG = mLaFM65Nt3bgG.decode(OVauxZzLI10vcXT74K)
		yyivSDGAYkN3nauzCcT = YYBlm36zd0Jst18LXwo4.findall(QTUBCcehw6qPd4x(u"ࠧࡔࡧࡵ࡭ࡦࡲ࠮ࠫࡁ࠽ࠤ࠭࠴ࠪࡀࠫࠧࠫ৻"),mLaFM65Nt3bgG,YYBlm36zd0Jst18LXwo4.IGNORECASE)
		if yyivSDGAYkN3nauzCcT: DX2AbemCqcB5Yt4MdlGRfS0Q6Jo = yyivSDGAYkN3nauzCcT[LzYQg91SIxDeOGtCKd5]
	except: pass
	try:
		import subprocess as BN0RwpG46vZbYz
		aawZ2Ct9LsQnY3pqfAObm0EW = BN0RwpG46vZbYz.Popen(VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠨࡵࡷࡥࡹࠦ࠭ࡤࠢࠥࠤࠪ࡞ࠠࠣࠢ࠲ࡷࡹࡵࡲࡢࡩࡨ࠳ࡪࡳࡵ࡭ࡣࡷࡩࡩ࠵࠰ࠡ࠽ࠣࡷࡹࡧࡴࠡ࠯ࡦࠤࠧࠦࠥࡘࠢࠥࠤ࠴ࡼࡡࡳ࠱࡯ࡳ࡬࠭ৼ"),shell=CCxMXuNUEzolDZTKrBJ,stdin=BN0RwpG46vZbYz.PIPE,stdout=BN0RwpG46vZbYz.PIPE,stderr=BN0RwpG46vZbYz.PIPE)
		UnEl57s0YR1pPHZBqiu = aawZ2Ct9LsQnY3pqfAObm0EW.stdout.read()
		if UnEl57s0YR1pPHZBqiu:
			if i1thmHk7AZquD4cM0fnp62:
				UnEl57s0YR1pPHZBqiu = UnEl57s0YR1pPHZBqiu.decode(OVauxZzLI10vcXT74K,dDYUoKi6JFM23p(u"ࠩ࡬࡫ࡳࡵࡲࡦࠩ৽"))
			oduaCJ2hPxFTrqtNIkBnR74VzicysM = YYBlm36zd0Jst18LXwo4.findall(mQNonhS7CV2BXOv(u"ࠪࠤ࠭ࡢࡤࡼ࠳࠳ࢁ࠮ࠦࠧ৾"),UnEl57s0YR1pPHZBqiu,YYBlm36zd0Jst18LXwo4.IGNORECASE)
			if oduaCJ2hPxFTrqtNIkBnR74VzicysM: aan2sotRLF8klg1bYiyTzj3pIc = min(oduaCJ2hPxFTrqtNIkBnR74VzicysM)
	except: pass
	return M5XmZb763oUH,DX2AbemCqcB5Yt4MdlGRfS0Q6Jo,aan2sotRLF8klg1bYiyTzj3pIc
def P1u7tUzG9XMxHjSlnk6QvARoNVCO5i(iS9qB4N3mlLdEHkoGtxyZhbYXa2=CCxMXuNUEzolDZTKrBJ,n6TDI30gecEMhLYbtPNJoy=mmcNLrXtzfpyCkZlvK5VwG2gujh(u"࠸࠸ୂ")):
	QhjpfmLWRrNdBOqasGx3ItwyP = CCxMXuNUEzolDZTKrBJ
	if iS9qB4N3mlLdEHkoGtxyZhbYXa2:
		kLqgDbiu9ZMXACpFs5x3ldG07z = SS2OK7hjLagvUAm(mshLJcKH1fv03yRnDOr4ZT,Xz3bA2PFENVCUtplu51(u"ࠫࡱ࡯ࡳࡵࠩ৿"),mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨ਀"),TYf7Dc06PQgy1vEV9(u"࠭ࡓࡊࡖࡈࡗࡤࡉࡈࡆࡅࡎࠫਁ"))
		if kLqgDbiu9ZMXACpFs5x3ldG07z:
			bjHNlso3mtVgZUpK8Jda,cgmRGZIq67kjl0NA,xCon5HqKJzBp6sRWY2ZyaMSDG,owU3nWKc6S5v0kNOA2BzMgaeQG7js = kLqgDbiu9ZMXACpFs5x3ldG07z
			QhjpfmLWRrNdBOqasGx3ItwyP = SS2OK7hjLagvUAm(mshLJcKH1fv03yRnDOr4ZT,uVQd103XyvUce2EBtzbYaC(u"ࠧ࡭࡫ࡶࡸࠬਂ"),P0qdZI384LKleuo(u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫਃ"),TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠩࡖࡍ࡙ࡋࡓࡠࡘࡈࡖࡎࡌ࡙ࠨ਄"))
			if QhjpfmLWRrNdBOqasGx3ItwyP: M5XmZb763oUH,DX2AbemCqcB5Yt4MdlGRfS0Q6Jo,aan2sotRLF8klg1bYiyTzj3pIc = QhjpfmLWRrNdBOqasGx3ItwyP
			else: M5XmZb763oUH,DX2AbemCqcB5Yt4MdlGRfS0Q6Jo,aan2sotRLF8klg1bYiyTzj3pIc = NVlW2pICaOH0ekhRQob()
			if (cgmRGZIq67kjl0NA,xCon5HqKJzBp6sRWY2ZyaMSDG,owU3nWKc6S5v0kNOA2BzMgaeQG7js)==(M5XmZb763oUH,DX2AbemCqcB5Yt4MdlGRfS0Q6Jo,aan2sotRLF8klg1bYiyTzj3pIc): return eeN6dTEnkJxI.join(bjHNlso3mtVgZUpK8Jda)
	if QhjpfmLWRrNdBOqasGx3ItwyP: M5XmZb763oUH,DX2AbemCqcB5Yt4MdlGRfS0Q6Jo,aan2sotRLF8klg1bYiyTzj3pIc = NVlW2pICaOH0ekhRQob()
	global iSKsoNqaAb,P7xq0RKwa2QT
	iSKsoNqaAb,P7xq0RKwa2QT,Jcr4y27d1E8IwHfQDOZnYpVgCSA0i = b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv
	n6TDI30gecEMhLYbtPNJoy = n6TDI30gecEMhLYbtPNJoy//IgQimel18t
	Ay1SMOzkx5CU3aGTL4Zf.Thread(target=AMCseQWwcBTNaDqz8).start()
	Ay1SMOzkx5CU3aGTL4Zf.Thread(target=EuYPmFozbqJQZn6dkR).start()
	for s9s45taoNBh60XL1zykOmTK3jJCrE in range(Mmpr0o76iWJvz1kTtfgI8hES(u"࠷࠰ୃ")):
		wLQCTr5lqbsVYeAHdzfhZ1F.sleep(VFjQx6Is28KvzLOmMXtg4GqTwa3(u"࠰࠯࠷ୄ"))
		if not Jcr4y27d1E8IwHfQDOZnYpVgCSA0i:
			try:
				GuiQVwBcoOAD6CKLRzm = uuxVm0bTwdnCUAL4s6NKHEBF3M.getInfoLabel(vvWwO3Tx2dAgcijrFXq(u"ࠪࡒࡪࡺࡷࡰࡴ࡮࠲ࡒࡧࡣࡂࡦࡧࡶࡪࡹࡳࠨਅ"))
				if GuiQVwBcoOAD6CKLRzm.count(ddo23ZJtgcY(u"ࠫ࠿࠭ਆ"))==P0qdZI384LKleuo(u"࠷୆") and GuiQVwBcoOAD6CKLRzm.count(QTUBCcehw6qPd4x(u"ࠬ࠶ࠧਇ"))<RRIHDFjoW9w7bSfVPhC(u"࠺୅"):
					GuiQVwBcoOAD6CKLRzm = GuiQVwBcoOAD6CKLRzm.lower().replace(Xz3bA2PFENVCUtplu51(u"࠭࠺ࠨਈ"),b8Qe150xVaJsnDSv)
					Jcr4y27d1E8IwHfQDOZnYpVgCSA0i = str(int(GuiQVwBcoOAD6CKLRzm,vvWwO3Tx2dAgcijrFXq(u"࠴࠺େ")))
			except: pass
		if iSKsoNqaAb and P7xq0RKwa2QT and Jcr4y27d1E8IwHfQDOZnYpVgCSA0i: break
	QLdYUM5aBkXT7cKVzEIJGmbseHf9p = [P7xq0RKwa2QT,iSKsoNqaAb,Jcr4y27d1E8IwHfQDOZnYpVgCSA0i,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,TYf7Dc06PQgy1vEV9(u"ࠧ࠱࠲࠴࠵࠷࠸࠳࠴࠶࠷࠹࠺࠼࠶࠸࠹ࠪਉ")]
	if DX2AbemCqcB5Yt4MdlGRfS0Q6Jo or aan2sotRLF8klg1bYiyTzj3pIc:
		AQH9K3RsLN5CaTbcq = [(NvHugPosYDzRJ,DX2AbemCqcB5Yt4MdlGRfS0Q6Jo),(vvWwO3Tx2dAgcijrFXq(u"࠹ୈ"),aan2sotRLF8klg1bYiyTzj3pIc)]
		for bb0cYXjevHNo8ZLE7CyrBzWAl9wus,ehwRMsq9br8P72Bj3mnlOCY0JXvWFc in AQH9K3RsLN5CaTbcq:
			ehwRMsq9br8P72Bj3mnlOCY0JXvWFc = ehwRMsq9br8P72Bj3mnlOCY0JXvWFc.strip(zI3ROAZtiUq42rE9WDST68(u"ࠨ࠲ࠪਊ"))
			if ehwRMsq9br8P72Bj3mnlOCY0JXvWFc:
				if i1thmHk7AZquD4cM0fnp62: ehwRMsq9br8P72Bj3mnlOCY0JXvWFc = ehwRMsq9br8P72Bj3mnlOCY0JXvWFc.encode(OVauxZzLI10vcXT74K)
				ehwRMsq9br8P72Bj3mnlOCY0JXvWFc = str(int(dVRkZo9Daz.md5(ehwRMsq9br8P72Bj3mnlOCY0JXvWFc).hexdigest(),uVQd103XyvUce2EBtzbYaC(u"࠸࠼୉")))
				TitghJX0qD7Ifn5NrcVwW = [int(ehwRMsq9br8P72Bj3mnlOCY0JXvWFc[gOrhCy1tp9IkYxdKoB5UElJu:gOrhCy1tp9IkYxdKoB5UElJu+TYf7Dc06PQgy1vEV9(u"࠱࠶ୋ")]) for gOrhCy1tp9IkYxdKoB5UElJu in range(len(ehwRMsq9br8P72Bj3mnlOCY0JXvWFc)) if gOrhCy1tp9IkYxdKoB5UElJu%TYf7Dc06PQgy1vEV9(u"࠱࠶ୋ")==Mmpr0o76iWJvz1kTtfgI8hES(u"࠶୊")]
				QLdYUM5aBkXT7cKVzEIJGmbseHf9p[bb0cYXjevHNo8ZLE7CyrBzWAl9wus-qHYIWnOZLPkrQU] = str(sum(TitghJX0qD7Ifn5NrcVwW))
	bjHNlso3mtVgZUpK8Jda,trSOoYEs9H3PMJyjDm = [],DD5cFIejQa2X4BgAu9GWPyJ3tC7
	for DaVH7FIU3NhKLpu0dQmvjWR,TitghJX0qD7Ifn5NrcVwW in enumerate(QLdYUM5aBkXT7cKVzEIJGmbseHf9p):
		if not TitghJX0qD7Ifn5NrcVwW: continue
		if trSOoYEs9H3PMJyjDm and TitghJX0qD7Ifn5NrcVwW==QLdYUM5aBkXT7cKVzEIJGmbseHf9p[-qHYIWnOZLPkrQU]: continue
		trSOoYEs9H3PMJyjDm = CCxMXuNUEzolDZTKrBJ
		TitghJX0qD7Ifn5NrcVwW = TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠩ࠳ࠫ਋")*n6TDI30gecEMhLYbtPNJoy+TitghJX0qD7Ifn5NrcVwW
		TitghJX0qD7Ifn5NrcVwW = TitghJX0qD7Ifn5NrcVwW[-n6TDI30gecEMhLYbtPNJoy:]
		S12rQ6bxtIMzpXgRVseDTU3wkCyf,Jgrc6KslIpv3BikOTxPaHzjbtA = b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv
		jdq2po78y3MhBRb9WL = str(int(DYakr9g4PVU(u"ࠪ࠽ࠬ਌")*(n6TDI30gecEMhLYbtPNJoy+qHYIWnOZLPkrQU))-int(TitghJX0qD7Ifn5NrcVwW))[-n6TDI30gecEMhLYbtPNJoy:]
		for p8R0YcsOIP4KUMEkbVgABZTtN9w in list(range(LzYQg91SIxDeOGtCKd5,n6TDI30gecEMhLYbtPNJoy,NvHugPosYDzRJ)):
			S12rQ6bxtIMzpXgRVseDTU3wkCyf += jdq2po78y3MhBRb9WL[p8R0YcsOIP4KUMEkbVgABZTtN9w:p8R0YcsOIP4KUMEkbVgABZTtN9w+NvHugPosYDzRJ]+S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠫ࠲࠭਍")
			Jgrc6KslIpv3BikOTxPaHzjbtA += str(sum(map(int,TitghJX0qD7Ifn5NrcVwW[p8R0YcsOIP4KUMEkbVgABZTtN9w:p8R0YcsOIP4KUMEkbVgABZTtN9w+NvHugPosYDzRJ]))%DYakr9g4PVU(u"࠲࠲ୌ"))
		SZokKUXTMbv = str(DaVH7FIU3NhKLpu0dQmvjWR)+S12rQ6bxtIMzpXgRVseDTU3wkCyf+Jgrc6KslIpv3BikOTxPaHzjbtA
		bjHNlso3mtVgZUpK8Jda.append(SZokKUXTMbv)
	IT2SoXRlUDacnAHYbrikZ,zT3LISYDOecPuxq = [],[]
	for user in bjHNlso3mtVgZUpK8Jda:
		count = str(str(bjHNlso3mtVgZUpK8Jda).count(user[HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"࠳୍"):]))
		IT2SoXRlUDacnAHYbrikZ.append(count+user)
	IT2SoXRlUDacnAHYbrikZ = sorted(IT2SoXRlUDacnAHYbrikZ,reverse=TT8Mxv5Wq7nlC9IscdpPUY6(u"ࡘࡷࡻࡥ୲"),key=lambda key: key[LAQD5wEkr18bUiGaYen3J(u"࠳୎")])
	for user in IT2SoXRlUDacnAHYbrikZ: zT3LISYDOecPuxq.append(user[QTUBCcehw6qPd4x(u"࠵୏"):])
	PGudrhJF8iDkSq96XVHEQZYf5L(mshLJcKH1fv03yRnDOr4ZT,TYf7Dc06PQgy1vEV9(u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨ਎"),uVQd103XyvUce2EBtzbYaC(u"࠭ࡓࡊࡖࡈࡗࡤ࡜ࡅࡓࡋࡉ࡝ࠬਏ"),[M5XmZb763oUH,DX2AbemCqcB5Yt4MdlGRfS0Q6Jo,aan2sotRLF8klg1bYiyTzj3pIc],GMkNL1RXxKFentp0Zh9d)
	PGudrhJF8iDkSq96XVHEQZYf5L(mshLJcKH1fv03yRnDOr4ZT,zI3ROAZtiUq42rE9WDST68(u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪਐ"),LAQD5wEkr18bUiGaYen3J(u"ࠨࡕࡌࡘࡊ࡙࡟ࡄࡊࡈࡇࡐ࠭਑"),[zT3LISYDOecPuxq,M5XmZb763oUH,DX2AbemCqcB5Yt4MdlGRfS0Q6Jo,aan2sotRLF8klg1bYiyTzj3pIc],Q49IsrlSuYRAVbGKhwdckLDOetF2PZ)
	return eeN6dTEnkJxI.join(zT3LISYDOecPuxq)
def AMCseQWwcBTNaDqz8():
	global iSKsoNqaAb
	import getmac82 as O92Hq05t6NTwM37gLlrU
	try:
		CVT0AduYM4XvQ6aLOpoKEnPW = O92Hq05t6NTwM37gLlrU.get_mac_address()
		if CVT0AduYM4XvQ6aLOpoKEnPW.count(BmePGjS7FxK6kutUM(u"ࠩ࠽ࠫ਒"))==Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"࠻୑") and CVT0AduYM4XvQ6aLOpoKEnPW.count(RRIHDFjoW9w7bSfVPhC(u"ࠪ࠴ࠬਓ"))<ubxGUTt1LraKhVZgpAP(u"࠾୐"):
			CVT0AduYM4XvQ6aLOpoKEnPW = CVT0AduYM4XvQ6aLOpoKEnPW.lower().replace(mQNonhS7CV2BXOv(u"ࠫ࠿࠭ਔ"),b8Qe150xVaJsnDSv)
			iSKsoNqaAb = str(int(CVT0AduYM4XvQ6aLOpoKEnPW,HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"࠱࠷୒")))
	except: pass
	return
def EuYPmFozbqJQZn6dkR():
	global P7xq0RKwa2QT
	import getmac94 as Rxt1KLzHigAeBqSJjuC6Z5lN
	try:
		DsgfdnBFPq8coY9UV1R = Rxt1KLzHigAeBqSJjuC6Z5lN.get_mac_address()
		if DsgfdnBFPq8coY9UV1R.count(m6hwdgP31a2zjN7lkpX(u"ࠬࡀࠧਕ"))==zI3ROAZtiUq42rE9WDST68(u"࠷୔") and DsgfdnBFPq8coY9UV1R.count(TYf7Dc06PQgy1vEV9(u"࠭࠰ࠨਖ"))<QQdAXWBc2GPw(u"࠺୓"):
			DsgfdnBFPq8coY9UV1R = DsgfdnBFPq8coY9UV1R.lower().replace(QTUBCcehw6qPd4x(u"ࠧ࠻ࠩਗ"),b8Qe150xVaJsnDSv)
			P7xq0RKwa2QT = str(int(DsgfdnBFPq8coY9UV1R,ddo23ZJtgcY(u"࠴࠺୕")))
	except: pass
	return
def IYuvgrd2fS(E57WK4m31C8,YabJfs3q7yjpzvXioO,kTSyagGWsFnolYhMO5fCwvpNuPqR,Hjb64dTft8SzJ,fOzS45youKYdNDqwm61aEI3A,ufxrtSb9vkTpPhqG8WK):
	ybF0H85nUohsiRQcpaTfZAKzjMY7wB = str(Hjb64dTft8SzJ)[LzYQg91SIxDeOGtCKd5:m6hwdgP31a2zjN7lkpX(u"࠶࠺࠶ୖ")].replace(eeN6dTEnkJxI,ddo23ZJtgcY(u"ࠨ࡞࡟ࡲࠬਘ")).replace(d6ekSEojpFUANKJ7r9WTlI3niLBOu,kke1PDGRBLuY8y(u"ࠩ࡟ࡠࡷ࠭ਙ")).replace(eiopkn4y9uWDQ5,pldxivXC5wbTB2O8q).replace(R1BKXhzpGH6CoO9jLsPwQWu,pldxivXC5wbTB2O8q)
	if len(str(Hjb64dTft8SzJ))>BWNPxIG7vqdTy85pjHzUOrK3(u"࠷࠻࠰ୗ"): ybF0H85nUohsiRQcpaTfZAKzjMY7wB = ybF0H85nUohsiRQcpaTfZAKzjMY7wB+mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠪࠤ࠳࠴࠮ࠨਚ")
	EEkjQFxOabod08Nr = str(kTSyagGWsFnolYhMO5fCwvpNuPqR)[LzYQg91SIxDeOGtCKd5:ubxGUTt1LraKhVZgpAP(u"࠸࠵࠱୘")].replace(eeN6dTEnkJxI,ddo23ZJtgcY(u"ࠫࡡࡢ࡮ࠨਛ")).replace(d6ekSEojpFUANKJ7r9WTlI3niLBOu,kke1PDGRBLuY8y(u"ࠬࡢ࡜ࡳࠩਜ")).replace(eiopkn4y9uWDQ5,pldxivXC5wbTB2O8q).replace(R1BKXhzpGH6CoO9jLsPwQWu,pldxivXC5wbTB2O8q)
	if len(str(kTSyagGWsFnolYhMO5fCwvpNuPqR))>TYf7Dc06PQgy1vEV9(u"࠲࠶࠲୙"): EEkjQFxOabod08Nr = EEkjQFxOabod08Nr+BmePGjS7FxK6kutUM(u"࠭ࠠ࠯࠰࠱ࠫਝ")
	mwIxD3GBPgLVc2aq9(MtTygrzXFlQ,zI3ROAZtiUq42rE9WDST68(u"ࠧࡐࡒࡈࡒ࡚ࡘࡌࡠࠩਞ")+E57WK4m31C8+Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠨ࡙ࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫਟ")+YabJfs3q7yjpzvXioO+dDYUoKi6JFM23p(u"ࠩࠣࡡࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫਠ")+fOzS45youKYdNDqwm61aEI3A+QQdAXWBc2GPw(u"ࠪࠤࡢࠦࠠࠡࡏࡨࡸ࡭ࡵࡤ࠻ࠢ࡞ࠤࠬਡ")+ufxrtSb9vkTpPhqG8WK+HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠫࠥࡣࠠࠡࠢࡋࡩࡦࡪࡥࡳࡵ࠽ࠤࡠࠦࠧਢ")+str(ybF0H85nUohsiRQcpaTfZAKzjMY7wB)+kke1PDGRBLuY8y(u"ࠬࠦ࡝ࠡࠢࠣࡈࡦࡺࡡ࠻ࠢ࡞ࠤࠬਣ")+EEkjQFxOabod08Nr+m6hwdgP31a2zjN7lkpX(u"࠭ࠠ࡞ࠩਤ"))
	return
def s0oSQWhNPM3kBrp5(ufxrtSb9vkTpPhqG8WK,YabJfs3q7yjpzvXioO,kTSyagGWsFnolYhMO5fCwvpNuPqR=b8Qe150xVaJsnDSv,Hjb64dTft8SzJ=b8Qe150xVaJsnDSv,fOzS45youKYdNDqwm61aEI3A=b8Qe150xVaJsnDSv):
	IYuvgrd2fS(LAQD5wEkr18bUiGaYen3J(u"ࠧࡖࡔࡏࡐࡎࡈ࡜ࡵ࡞ࡷࡓࡕࡋࡎࡠࡗࡕࡐࠬਥ"),YabJfs3q7yjpzvXioO,kTSyagGWsFnolYhMO5fCwvpNuPqR,Hjb64dTft8SzJ,fOzS45youKYdNDqwm61aEI3A,ufxrtSb9vkTpPhqG8WK)
	if i1thmHk7AZquD4cM0fnp62: import urllib.request as K3KcQEXo9hnWGbwJuq5ms
	else: import urllib2 as K3KcQEXo9hnWGbwJuq5ms
	if not Hjb64dTft8SzJ: Hjb64dTft8SzJ = {BWNPxIG7vqdTy85pjHzUOrK3(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬਦ"):b8Qe150xVaJsnDSv}
	if not kTSyagGWsFnolYhMO5fCwvpNuPqR: kTSyagGWsFnolYhMO5fCwvpNuPqR = {}
	if ufxrtSb9vkTpPhqG8WK==P0qdZI384LKleuo(u"ࠩࡊࡉ࡙࠭ਧ"):
		YabJfs3q7yjpzvXioO = YabJfs3q7yjpzvXioO+Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠪࡃࠬਨ")+uVsW5TNRM2vDOn(kTSyagGWsFnolYhMO5fCwvpNuPqR)
		kTSyagGWsFnolYhMO5fCwvpNuPqR = None
	elif ufxrtSb9vkTpPhqG8WK==P0qdZI384LKleuo(u"ࠫࡕࡕࡓࡕࠩ਩") and LAQD5wEkr18bUiGaYen3J(u"ࠬࡰࡳࡰࡰࠪਪ") in str(Hjb64dTft8SzJ):
		kTSyagGWsFnolYhMO5fCwvpNuPqR = AFIDMBehNx5QH6g21E8kq9JzrLi.dumps(kTSyagGWsFnolYhMO5fCwvpNuPqR)
		kTSyagGWsFnolYhMO5fCwvpNuPqR = str(kTSyagGWsFnolYhMO5fCwvpNuPqR).encode(OVauxZzLI10vcXT74K)
	elif ufxrtSb9vkTpPhqG8WK==Mmpr0o76iWJvz1kTtfgI8hES(u"࠭ࡐࡐࡕࡗࠫਫ"):
		kTSyagGWsFnolYhMO5fCwvpNuPqR = uVsW5TNRM2vDOn(kTSyagGWsFnolYhMO5fCwvpNuPqR)
		kTSyagGWsFnolYhMO5fCwvpNuPqR = kTSyagGWsFnolYhMO5fCwvpNuPqR.encode(OVauxZzLI10vcXT74K)
	try:
		TP4F3nEHLcDiZpYzw8rhaJ9sS = K3KcQEXo9hnWGbwJuq5ms.Request(YabJfs3q7yjpzvXioO,headers=Hjb64dTft8SzJ,data=kTSyagGWsFnolYhMO5fCwvpNuPqR)
		Ci4rQ0qV915j2AIkHTbcy = K3KcQEXo9hnWGbwJuq5ms.urlopen(TP4F3nEHLcDiZpYzw8rhaJ9sS)
		oH3N1dY9vLpaDJfnTVP5Z7q = Ci4rQ0qV915j2AIkHTbcy.read()
		GXNZCDRs3E1V,UUF24APJXw0DzpoENvys1Zf3kRj = shC5qBRV2A0lZ(u"࠳࠲࠳୚"),uVQd103XyvUce2EBtzbYaC(u"ࠧࡐࡍࠪਬ")
	except:
		oH3N1dY9vLpaDJfnTVP5Z7q = b8Qe150xVaJsnDSv
		GXNZCDRs3E1V,UUF24APJXw0DzpoENvys1Zf3kRj = -qHYIWnOZLPkrQU,uVQd103XyvUce2EBtzbYaC(u"ࠨࡗࡱ࡯ࡳࡵࡷ࡯ࠢࡈࡶࡷࡵࡲࠨਭ")
	mwIxD3GBPgLVc2aq9(MtTygrzXFlQ,BmePGjS7FxK6kutUM(u"ࠩࡒࡔࡊࡔࡕࡓࡎࡢ࡙ࡗࡒࡌࡊࡄ࡟ࡸࡡࡺࡒࡆࡕࡓࡓࡓ࡙ࡅࠡࠢࡆࡳࡩ࡫࠺ࠡ࡝ࠣࠫਮ")+str(GXNZCDRs3E1V)+LAQD5wEkr18bUiGaYen3J(u"ࠪࠤࡢࠦࠠࠡࡔࡨࡥࡸࡵ࡮࠻ࠢ࡞ࠤࠬਯ")+UUF24APJXw0DzpoENvys1Zf3kRj+kke1PDGRBLuY8y(u"ࠫࠥࡣࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭ਰ")+fOzS45youKYdNDqwm61aEI3A+Nh0BWuiSndf(u"ࠬࠦ࡝࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫ਱")+YabJfs3q7yjpzvXioO+HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"࠭ࠠ࡞ࠩਲ"))
	if oH3N1dY9vLpaDJfnTVP5Z7q and i1thmHk7AZquD4cM0fnp62: oH3N1dY9vLpaDJfnTVP5Z7q = oH3N1dY9vLpaDJfnTVP5Z7q.decode(OVauxZzLI10vcXT74K)
	return oH3N1dY9vLpaDJfnTVP5Z7q
def Rc1WyY8UG2HO5(e67roc0BWdQ):
	PLWfTcgkul = {
		QTUBCcehw6qPd4x(u"ࠢࡶࡵࡨࡶࡤ࡯ࡤࠣਲ਼"):ZZPtSiqLbRsVBUGdm,
		vvWwO3Tx2dAgcijrFXq(u"ࠣࡱࡶࡣࡻ࡫ࡲࡴ࡫ࡲࡲࠧ਴"):str(g1gmkxOtc2oeEZHhBiy),
		uVQd103XyvUce2EBtzbYaC(u"ࠤࡤࡴࡵࡥࡶࡦࡴࡶ࡭ࡴࡴࠢਵ"):cpGrK6qnPi,
		Nh0BWuiSndf(u"ࠥࡨࡪࡼࡩࡤࡧࡢࡪࡦࡳࡩ࡭ࡻࠥਸ਼"):cpGrK6qnPi,
		kke1PDGRBLuY8y(u"ࠦࡵࡲࡡࡵࡨࡲࡶࡲࠨ਷"): cpGrK6qnPi,
		VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠧࡩࡡࡳࡴ࡬ࡩࡷࠨਸ"):ddo23ZJtgcY(u"ࠨࡁࡓࡃࡅࡍࡈࡥࡖࡊࡆࡈࡓࡘࠨਹ"),
		ubxGUTt1LraKhVZgpAP(u"ࠢࡪࡲࠥ਺"): uVQd103XyvUce2EBtzbYaC(u"ࠣࠦࡵࡩࡲࡵࡴࡦࠤ਻"),
		TYf7Dc06PQgy1vEV9(u"ࠤࠧࡷࡰ࡯ࡰࡠࡷࡶࡩࡷࡥࡰࡳࡱࡳࡩࡷࡺࡩࡦࡵࡢࡷࡾࡴࡣ਼ࠣ"):DD5cFIejQa2X4BgAu9GWPyJ3tC7
	}
	wO2LCZoiYzMm1K7jWeb5ksXAIQ3 = []
	for IIYkVq01pleLCZbR in e67roc0BWdQ:
		Eqh4xYr9VWQSc2kf0biID = PLWfTcgkul.copy()
		Eqh4xYr9VWQSc2kf0biID[vvWwO3Tx2dAgcijrFXq(u"ࠪࡩࡻ࡫࡮ࡵࡡࡷࡽࡵ࡫ࠧ਽")] = IIYkVq01pleLCZbR
		Eqh4xYr9VWQSc2kf0biID[vvWwO3Tx2dAgcijrFXq(u"ࠫࡪࡼࡥ࡯ࡶࡢࡴࡷࡵࡰࡦࡴࡷ࡭ࡪࡹࠧਾ")] = {Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠧࡋࡶࡦࡰࡷࡣࡓࡧ࡭ࡦࠤਿ"):IIYkVq01pleLCZbR}
		Eqh4xYr9VWQSc2kf0biID[BmePGjS7FxK6kutUM(u"࠭ࡵࡴࡧࡵࡣࡵࡸ࡯ࡱࡧࡵࡸ࡮࡫ࡳࠨੀ")] = {mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠢࡖࡵࡨࡶࡤࡋࡶࡦࡰࡷࡣࡓࡧ࡭ࡦࠤੁ"):IIYkVq01pleLCZbR}
		wO2LCZoiYzMm1K7jWeb5ksXAIQ3.append(Eqh4xYr9VWQSc2kf0biID)
	PejVxgnIFHpu354ErWLfGRUMZ8YJO = str(qHiNBx6PXjKatkWf37AwFClzsp2DmE.randrange(Mmpr0o76iWJvz1kTtfgI8hES(u"࠳࠴࠵࠶࠷࠱࠲࠳࠴࠵࠶࠷୛"),UUkIBz1sgQ9WfNeG6trKXvu0(u"࠼࠽࠾࠿࠹࠺࠻࠼࠽࠾࠿࠹ଡ଼")))
	kTSyagGWsFnolYhMO5fCwvpNuPqR = {
		RRIHDFjoW9w7bSfVPhC(u"ࠣࡣࡳ࡭ࡤࡱࡥࡺࠤੂ"):BmePGjS7FxK6kutUM(u"ࠩ࠵࠹࠹ࡪࡤ࠴ࡣ࠷࠴࠾ࡪ࠸ࡣ࠸࠻࠵ࡩ࠺ࡥ࠲࠳࠺ࡩࡪ࠽࠸ࡤࡧࡥࡪ࠷࠿ࠧ੃"),
		Xz3bA2PFENVCUtplu51(u"ࠥ࡭ࡳࡹࡥࡳࡶࡢ࡭ࡩࠨ੄"):PejVxgnIFHpu354ErWLfGRUMZ8YJO,
		uVQd103XyvUce2EBtzbYaC(u"ࠦࡪࡼࡥ࡯ࡶࡶࠦ੅"): wO2LCZoiYzMm1K7jWeb5ksXAIQ3
	}
	Hjb64dTft8SzJ = {TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ੆"):S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳࡯ࡹ࡯࡯ࠩੇ")}
	YabJfs3q7yjpzvXioO = BWNPxIG7vqdTy85pjHzUOrK3(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡳ࡭࠷࠴ࡡ࡮ࡲ࡯࡭ࡹࡻࡤࡦ࠰ࡦࡳࡲ࠵࠲࠰ࡪࡷࡸࡵࡧࡰࡪࠩੈ")
	oH3N1dY9vLpaDJfnTVP5Z7q = s0oSQWhNPM3kBrp5(VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠨࡒࡒࡗ࡙࠭੉"),YabJfs3q7yjpzvXioO,kTSyagGWsFnolYhMO5fCwvpNuPqR,Hjb64dTft8SzJ,Nh0BWuiSndf(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡗࡊࡔࡄࡠࡃࡑࡅࡑ࡟ࡔࡊࡅࡖࡣࡊ࡜ࡅࡏࡖࡖ࠱࠶ࡹࡴࠨ੊"))
	return oH3N1dY9vLpaDJfnTVP5Z7q
def oJsUwXA0yGOI1mTjxQ(suA0cTlxyCN,vv5M4UfJS9ucKEiNbxtnaOZ):
	vv5M4UfJS9ucKEiNbxtnaOZ = vv5M4UfJS9ucKEiNbxtnaOZ.replace(ddo23ZJtgcY(u"ࠪࡲࡺࡲ࡬ࠨੋ"),RRIHDFjoW9w7bSfVPhC(u"ࠫࡓࡵ࡮ࡦࠩੌ"))
	vv5M4UfJS9ucKEiNbxtnaOZ = vv5M4UfJS9ucKEiNbxtnaOZ.replace(P0qdZI384LKleuo(u"ࠬࡺࡲࡶࡧ੍ࠪ"),Nh0BWuiSndf(u"࠭ࡔࡳࡷࡨࠫ੎"))
	vv5M4UfJS9ucKEiNbxtnaOZ = vv5M4UfJS9ucKEiNbxtnaOZ.replace(kke1PDGRBLuY8y(u"ࠧࡧࡣ࡯ࡷࡪ࠭੏"),Nh0BWuiSndf(u"ࠨࡈࡤࡰࡸ࡫ࠧ੐"))
	vv5M4UfJS9ucKEiNbxtnaOZ = vv5M4UfJS9ucKEiNbxtnaOZ.replace(RRIHDFjoW9w7bSfVPhC(u"ࠩ࡟࠳ࠬੑ"),DYakr9g4PVU(u"ࠪ࠳ࠬ੒"))
	try: NNjD4IlzdF = eval(vv5M4UfJS9ucKEiNbxtnaOZ)
	except: NNjD4IlzdF = LB3nD2quMYr6p1VP9GF0N587xAeS(suA0cTlxyCN)
	return NNjD4IlzdF
def wpXZ2KkvNOS8asuE94qedg7ncUr():
	E57WK4m31C8,rlqNUcK9vYgkT,YabJfs3q7yjpzvXioO,Q8ZnJhRz2mINwrY6VPf,I6YPOSofrpnTwRm8b,NGQDwOCXx1BZmd9Huc,vv5M4UfJS9ucKEiNbxtnaOZ,wc0Z9FAdf2B1J,XXra5dzn8tcLOxYZIE7pPof49Hh = rhoGF8ta4UesmTucY6V2O1A(ZqDQCMovyXKFG7ki4BrahuWt1IS8)
	N6gCa1OZ9HnU2 = YYBlm36zd0Jst18LXwo4.findall(TYf7Dc06PQgy1vEV9(u"ࠫࡡࡪ࡜ࡥ࠼࡟ࡨࡡࡪࠠ࡝࡝࠲ࡇࡔࡒࡏࡓ࡞ࡠࠫ੓"),rlqNUcK9vYgkT,YYBlm36zd0Jst18LXwo4.DOTALL)
	if N6gCa1OZ9HnU2: rlqNUcK9vYgkT = rlqNUcK9vYgkT.split(N6gCa1OZ9HnU2[LzYQg91SIxDeOGtCKd5],Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"࠵ଢ଼"))[qHYIWnOZLPkrQU]
	OJLzFcW1bdij5 = wLQCTr5lqbsVYeAHdzfhZ1F.strftime(BWNPxIG7vqdTy85pjHzUOrK3(u"ࠬࡥࠥ࡮࠰ࠨࡨࡤࠫࡈ࠻ࠧࡐࡣࠬ੔"),wLQCTr5lqbsVYeAHdzfhZ1F.localtime(T3Axql94cU0BpO1wudEDtWXsf))
	rlqNUcK9vYgkT = rlqNUcK9vYgkT+OJLzFcW1bdij5
	aA3sfhwtnGR2Plv8Ou = E57WK4m31C8,rlqNUcK9vYgkT,YabJfs3q7yjpzvXioO,Q8ZnJhRz2mINwrY6VPf,I6YPOSofrpnTwRm8b,NGQDwOCXx1BZmd9Huc,vv5M4UfJS9ucKEiNbxtnaOZ,wc0Z9FAdf2B1J,XXra5dzn8tcLOxYZIE7pPof49Hh
	if x76PfMyAp1L2WejkU3.path.exists(oYXBd89zTnZPipv56Qf1UxurbC3):
		xgjifnIWe3aDs5kK81vu04U7FE = open(oYXBd89zTnZPipv56Qf1UxurbC3,QQdAXWBc2GPw(u"࠭ࡲࡣࠩ੕")).read()
		if i1thmHk7AZquD4cM0fnp62: xgjifnIWe3aDs5kK81vu04U7FE = xgjifnIWe3aDs5kK81vu04U7FE.decode(OVauxZzLI10vcXT74K)
		xgjifnIWe3aDs5kK81vu04U7FE = oJsUwXA0yGOI1mTjxQ(QQdAXWBc2GPw(u"ࠧࡥ࡫ࡦࡸࠬ੖"),xgjifnIWe3aDs5kK81vu04U7FE)
	else: xgjifnIWe3aDs5kK81vu04U7FE = {}
	SacP9lh0WiMUZrGDq = {}
	for TqSRBLteAYNVhxMkbsdFCwg5l410ZD in list(xgjifnIWe3aDs5kK81vu04U7FE.keys()):
		if TqSRBLteAYNVhxMkbsdFCwg5l410ZD!=E57WK4m31C8: SacP9lh0WiMUZrGDq[TqSRBLteAYNVhxMkbsdFCwg5l410ZD] = xgjifnIWe3aDs5kK81vu04U7FE[TqSRBLteAYNVhxMkbsdFCwg5l410ZD]
		else:
			if rlqNUcK9vYgkT and rlqNUcK9vYgkT!=ddo23ZJtgcY(u"ࠨ࠰࠱ࠫ੗"):
				WzMruAIFfqwpxcoXPQJC3ENmdT = xgjifnIWe3aDs5kK81vu04U7FE[TqSRBLteAYNVhxMkbsdFCwg5l410ZD]
				if aA3sfhwtnGR2Plv8Ou in WzMruAIFfqwpxcoXPQJC3ENmdT:
					tmaChESsDcO9dxLW4GQb = WzMruAIFfqwpxcoXPQJC3ENmdT.index(aA3sfhwtnGR2Plv8Ou)
					del WzMruAIFfqwpxcoXPQJC3ENmdT[tmaChESsDcO9dxLW4GQb]
				cLtYxpHVoAgd = [aA3sfhwtnGR2Plv8Ou]+WzMruAIFfqwpxcoXPQJC3ENmdT
				cLtYxpHVoAgd = cLtYxpHVoAgd[:Mmpr0o76iWJvz1kTtfgI8hES(u"࠺࠶୞")]
				SacP9lh0WiMUZrGDq[TqSRBLteAYNVhxMkbsdFCwg5l410ZD] = cLtYxpHVoAgd
			else: SacP9lh0WiMUZrGDq[TqSRBLteAYNVhxMkbsdFCwg5l410ZD] = xgjifnIWe3aDs5kK81vu04U7FE[TqSRBLteAYNVhxMkbsdFCwg5l410ZD]
	if E57WK4m31C8 not in list(SacP9lh0WiMUZrGDq.keys()): SacP9lh0WiMUZrGDq[E57WK4m31C8] = [aA3sfhwtnGR2Plv8Ou]
	SacP9lh0WiMUZrGDq = str(SacP9lh0WiMUZrGDq)
	if i1thmHk7AZquD4cM0fnp62: SacP9lh0WiMUZrGDq = SacP9lh0WiMUZrGDq.encode(OVauxZzLI10vcXT74K)
	open(oYXBd89zTnZPipv56Qf1UxurbC3,SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠩࡺࡦࠬ੘")).write(SacP9lh0WiMUZrGDq)
	return
def uVsW5TNRM2vDOn(kTSyagGWsFnolYhMO5fCwvpNuPqR):
	if i1thmHk7AZquD4cM0fnp62: import urllib.parse as EB0kuFaUd7Gi29RYHy1L3
	else: import urllib as EB0kuFaUd7Gi29RYHy1L3
	M036MkZWJnrmpE9PdNw8SaHCBA = EB0kuFaUd7Gi29RYHy1L3.urlencode(kTSyagGWsFnolYhMO5fCwvpNuPqR)
	return M036MkZWJnrmpE9PdNw8SaHCBA
def yulQjIFbzM(GSh0nJxEXgZjd48u7mBwWOeafyAp5b,EXkDIZP8nlteMQ4oFfLxuJYy03VHr=b8Qe150xVaJsnDSv,yf2jUkehJXZ4zt=b8Qe150xVaJsnDSv):
	h3MtvrdDKV = EXkDIZP8nlteMQ4oFfLxuJYy03VHr not in [QQdAXWBc2GPw(u"ࠪࡑ࠸࡛ࠧਖ਼"),DYakr9g4PVU(u"ࠫࡎࡖࡔࡗࠩਗ਼")]
	if not yf2jUkehJXZ4zt: yf2jUkehJXZ4zt = zI3ROAZtiUq42rE9WDST68(u"ࠬࡼࡩࡥࡧࡲࠫਜ਼")
	bfog7xK6hEWjOJRpIXSy2uZAM,Kd1QjyV82IF4oBAs7tDp6cnOiSuUzW,jj9iZQkEfWMR7wtoNJ8aSHYy6re = BWNPxIG7vqdTy85pjHzUOrK3(u"࠭ࡣࡢࡰࡦࡩࡱ࡫ࡤࠨੜ"),b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv
	if len(GSh0nJxEXgZjd48u7mBwWOeafyAp5b)==VwApyDY1Jc:
		YabJfs3q7yjpzvXioO,Zi5YkL4Wg92DcSE3FJxMvmUopl,jj9iZQkEfWMR7wtoNJ8aSHYy6re = GSh0nJxEXgZjd48u7mBwWOeafyAp5b
		if Zi5YkL4Wg92DcSE3FJxMvmUopl: Kd1QjyV82IF4oBAs7tDp6cnOiSuUzW = Mmpr0o76iWJvz1kTtfgI8hES(u"ࠧࠡࠢࠣࡗࡺࡨࡴࡪࡶ࡯ࡩ࠿࡛ࠦࠡࠩ੝")+Zi5YkL4Wg92DcSE3FJxMvmUopl+ubxGUTt1LraKhVZgpAP(u"ࠨࠢࡠࠫਫ਼")
	else: YabJfs3q7yjpzvXioO,Zi5YkL4Wg92DcSE3FJxMvmUopl,jj9iZQkEfWMR7wtoNJ8aSHYy6re = GSh0nJxEXgZjd48u7mBwWOeafyAp5b,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv
	YabJfs3q7yjpzvXioO = YabJfs3q7yjpzvXioO.replace(HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠩࠨ࠶࠵࠭੟"),pldxivXC5wbTB2O8q)
	xZds9ITEWatF7Kb = Gz7MH0glBw8Eb(YabJfs3q7yjpzvXioO)
	if EXkDIZP8nlteMQ4oFfLxuJYy03VHr not in [Xz3bA2PFENVCUtplu51(u"ࠪࡈࡔ࡝ࡎࡍࡑࡄࡈࠬ੠"),zI3ROAZtiUq42rE9WDST68(u"ࠫࡎࡖࡔࡗࠩ੡")]:
		if EXkDIZP8nlteMQ4oFfLxuJYy03VHr!=DYakr9g4PVU(u"ࠬࡊࡏࡘࡐࡏࡓࡆࡊࠧ੢"): YabJfs3q7yjpzvXioO = YabJfs3q7yjpzvXioO.replace(pldxivXC5wbTB2O8q,Xz3bA2PFENVCUtplu51(u"࠭ࠥ࠳࠲ࠪ੣"))
		mwIxD3GBPgLVc2aq9(MtTygrzXFlQ,EECz06teoykrNFfq(QQ8pvXNcBfVkP5rRJ7o)+UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠧࠡࠢࠣࡔࡷ࡫ࡰࡢࡴ࡬ࡲ࡬ࠦࡴࡰࠢࡳࡰࡦࡿ࠯ࡥࡱࡺࡲࡱࡵࡡࡥࠢࡹ࡭ࡩ࡫࡯࡚ࠡࠢࠣ࡮ࡪࡥࡰ࠼ࠣ࡟ࠥ࠭੤")+YabJfs3q7yjpzvXioO+mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠨࠢࡠࠫ੥")+Kd1QjyV82IF4oBAs7tDp6cnOiSuUzW)
		if xZds9ITEWatF7Kb==Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨ੦") and EXkDIZP8nlteMQ4oFfLxuJYy03VHr not in [RRIHDFjoW9w7bSfVPhC(u"ࠪࡍࡕ࡚ࡖࠨ੧"),QQdAXWBc2GPw(u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬ੨")]:
			import hIVCFnfxSO
			uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = hIVCFnfxSO.TTO3ZpWq9FCzhuMAY0RdaDIfX5kw(EXkDIZP8nlteMQ4oFfLxuJYy03VHr,YabJfs3q7yjpzvXioO)
			MJGQBx4rhWt5N3kd1IeFnT = len(KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j)
			if MJGQBx4rhWt5N3kd1IeFnT>qHYIWnOZLPkrQU:
				cMZGTsAR2E = hIVCFnfxSO.XXprCMzuNP2mElUxfdA(TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠬอฮหำࠣห้๋ไโࠢส่๊์วิส࠽ࠤ࠭࠭੩")+str(MJGQBx4rhWt5N3kd1IeFnT)+Xz3bA2PFENVCUtplu51(u"࠭ࠠๆๆไ࠭ࠬ੪"), uuSKUinvP4EGLxWZYmTsF)
				if cMZGTsAR2E==-qHYIWnOZLPkrQU:
					hIVCFnfxSO.yicQV3gj4q(QQdAXWBc2GPw(u"ࠧฦๆ฽หฦูࠦๆๆํอࠥะิ฻์็ࠤฬ๊แ๋ัํ์ࠬ੫"),Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠨࡅࡤࡲࡨ࡫࡬ࠨ੬"))
					return bfog7xK6hEWjOJRpIXSy2uZAM
			else: cMZGTsAR2E = LzYQg91SIxDeOGtCKd5
			YabJfs3q7yjpzvXioO = KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j[cMZGTsAR2E]
			if uuSKUinvP4EGLxWZYmTsF[LzYQg91SIxDeOGtCKd5]!=RRIHDFjoW9w7bSfVPhC(u"ࠩ࠰࠵ࠬ੭"):
				mwIxD3GBPgLVc2aq9(MtTygrzXFlQ,EECz06teoykrNFfq(QQ8pvXNcBfVkP5rRJ7o)+dDYUoKi6JFM23p(u"ࠪࠤࠥࠦࡖࡪࡦࡨࡳ࡙ࠥࡥ࡭ࡧࡦࡸࡪࡪࠠࠡࠢࡖࡩࡱ࡫ࡣࡵ࡫ࡲࡲ࠿࡛ࠦࠡࠩ੮")+uuSKUinvP4EGLxWZYmTsF[cMZGTsAR2E]+RRIHDFjoW9w7bSfVPhC(u"ࠫࠥࡣ࡙ࠠࠡࠢ࡭ࡩ࡫࡯࠻ࠢ࡞ࠤࠬ੯")+YabJfs3q7yjpzvXioO+HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠬࠦ࡝ࠨੰ"))
		if BmePGjS7FxK6kutUM(u"࠭࠯ࡪࡨ࡬ࡰࡲ࠵ࠧੱ") in YabJfs3q7yjpzvXioO: YabJfs3q7yjpzvXioO = YabJfs3q7yjpzvXioO+uVQd103XyvUce2EBtzbYaC(u"ࠧࡽࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࡂࠬࠧੲ")
		elif TYf7Dc06PQgy1vEV9(u"ࠨࡪࡷࡸࡵ࠭ੳ") in YabJfs3q7yjpzvXioO.lower() and shC5qBRV2A0lZ(u"ࠩ࠲ࡨࡦࡹࡨ࠰ࠩੴ") not in YabJfs3q7yjpzvXioO and dDYUoKi6JFM23p(u"ࠪࡽࡴࡻࡴࡶࡤࡨ࠲ࡲࡶࡤࠨੵ") not in YabJfs3q7yjpzvXioO:
			YabJfs3q7yjpzvXioO = YabJfs3q7yjpzvXioO+BWNPxIG7vqdTy85pjHzUOrK3(u"ࠫࢁ࠭੶") if RRIHDFjoW9w7bSfVPhC(u"ࠬࢂࠧ੷") not in YabJfs3q7yjpzvXioO else YabJfs3q7yjpzvXioO+VFjQx6Is28KvzLOmMXtg4GqTwa3(u"࠭ࠦࠨ੸")
			if LAQD5wEkr18bUiGaYen3J(u"ࠧࡷࡧࡵ࡭࡫ࡿࡰࡦࡧࡵࡁࠬ੹") not in YabJfs3q7yjpzvXioO and Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࠪ੺") in YabJfs3q7yjpzvXioO.lower(): YabJfs3q7yjpzvXioO += dDYUoKi6JFM23p(u"ࠩࡹࡩࡷ࡯ࡦࡺࡲࡨࡩࡷࡃࡦࡢ࡮ࡶࡩࠫ࠭੻")
			if TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠪࡹࡸ࡫ࡲ࠮ࡣࡪࡩࡳࡺ࠽ࠨ੼") not in YabJfs3q7yjpzvXioO.lower() and EXkDIZP8nlteMQ4oFfLxuJYy03VHr not in [kke1PDGRBLuY8y(u"ࠫࡎࡖࡔࡗࠩ੽"),IjZbnrBJmM2N(u"ࠬࡓ࠳ࡖࠩ੾")]: YabJfs3q7yjpzvXioO += UUkIBz1sgQ9WfNeG6trKXvu0(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࡀࠪࠬ੿")
			if S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠧࡳࡧࡩࡩࡷ࡫ࡲ࠾ࠩ઀") not in YabJfs3q7yjpzvXioO.lower(): YabJfs3q7yjpzvXioO += IjZbnrBJmM2N(u"ࠨࡔࡨࡪࡪࡸࡥࡳ࠿࡫ࡸࡹࡶࠦࠨઁ")
	mwIxD3GBPgLVc2aq9(iebCpLE8fuxTRg,EECz06teoykrNFfq(QQ8pvXNcBfVkP5rRJ7o)+mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠩࠣࠤࠥࡍ࡯ࡵࠢࡩ࡭ࡳࡧ࡬ࠡࡷࡵࡰࠥࠦࠠࡗ࡫ࡧࡩࡴࡀࠠ࡜ࠢࠪં")+YabJfs3q7yjpzvXioO+Nh0BWuiSndf(u"ࠪࠤࡢ࠭ઃ"))
	NPVkGKSFrjgh1uwXqD3 = evil9I2DnLJcy8.ListItem()
	yf2jUkehJXZ4zt,jwcrfC6BhiqmlO098NsR,A1ldva3VPYrTUFm0MRk9LKCx,mmyeAsBgIT3kv1E6,YY5kEzQ4B2bcTr0qnxiVd8IXDl,FeUlSM0nYuvdbprEm246cXhACJD3i,r73rkOwBtFfNDRTvHA8Sd0em,Uj49SuMm8dnHkQhorsapbNtf2,BZX58FM9boWL0yx1O7dh4P6aw = rhoGF8ta4UesmTucY6V2O1A(ZqDQCMovyXKFG7ki4BrahuWt1IS8)
	if EXkDIZP8nlteMQ4oFfLxuJYy03VHr not in [UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠫࡉࡕࡗࡏࡎࡒࡅࡉ࠭઄"),kke1PDGRBLuY8y(u"ࠬࡏࡐࡕࡘࠪઅ")]:
		if hDTluNxe7tCwrpqXHzdEcYRfbs: Px9e7iCplMfXSzokj0UgIht5LDuEGY = Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰࡥࡩࡪ࡯࡯ࠩઆ")
		else: Px9e7iCplMfXSzokj0UgIht5LDuEGY = IjZbnrBJmM2N(u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱࠬઇ")
		NPVkGKSFrjgh1uwXqD3.setProperty(Px9e7iCplMfXSzokj0UgIht5LDuEGY, b8Qe150xVaJsnDSv)
		NPVkGKSFrjgh1uwXqD3.setMimeType(DYakr9g4PVU(u"ࠨ࡯࡬ࡱࡪ࠵ࡸ࠮ࡶࡼࡴࡪ࠭ઈ"))
		if g1gmkxOtc2oeEZHhBiy<ubxGUTt1LraKhVZgpAP(u"࠸࠰ୟ"): NPVkGKSFrjgh1uwXqD3.setInfo(QTUBCcehw6qPd4x(u"ࠩࡹ࡭ࡩ࡫࡯ࠨઉ"),{m6hwdgP31a2zjN7lkpX(u"ࠪࡱࡪࡪࡩࡢࡶࡼࡴࡪ࠭ઊ"):QTUBCcehw6qPd4x(u"ࠫࡲࡵࡶࡪࡧࠪઋ")})
		else:
			goMqyLXp5PUGhJsD = NPVkGKSFrjgh1uwXqD3.getVideoInfoTag()
			goMqyLXp5PUGhJsD.setMediaType(RRIHDFjoW9w7bSfVPhC(u"ࠬࡳ࡯ࡷ࡫ࡨࠫઌ"))
		NPVkGKSFrjgh1uwXqD3.setArt({mmcNLrXtzfpyCkZlvK5VwG2gujh(u"࠭ࡴࡩࡷࡰࡦࠬઍ"):YY5kEzQ4B2bcTr0qnxiVd8IXDl,P0qdZI384LKleuo(u"ࠧࡱࡱࡶࡸࡪࡸࠧ઎"):YY5kEzQ4B2bcTr0qnxiVd8IXDl,QTUBCcehw6qPd4x(u"ࠨࡤࡤࡲࡳ࡫ࡲࠨએ"):YY5kEzQ4B2bcTr0qnxiVd8IXDl,LAQD5wEkr18bUiGaYen3J(u"ࠩࡩࡥࡳࡧࡲࡵࠩઐ"):YY5kEzQ4B2bcTr0qnxiVd8IXDl,DYakr9g4PVU(u"ࠪࡧࡱ࡫ࡡࡳࡣࡵࡸࠬઑ"):YY5kEzQ4B2bcTr0qnxiVd8IXDl,Xz3bA2PFENVCUtplu51(u"ࠫࡨࡲࡥࡢࡴ࡯ࡳ࡬ࡵࠧ઒"):YY5kEzQ4B2bcTr0qnxiVd8IXDl,vvWwO3Tx2dAgcijrFXq(u"ࠬࡲࡡ࡯ࡦࡶࡧࡦࡶࡥࠨઓ"):YY5kEzQ4B2bcTr0qnxiVd8IXDl,Xz3bA2PFENVCUtplu51(u"࠭ࡩࡤࡱࡱࠫઔ"):YY5kEzQ4B2bcTr0qnxiVd8IXDl})
		if xZds9ITEWatF7Kb in [SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠧ࠯࡯ࡳࡨࠬક"),shC5qBRV2A0lZ(u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧખ")]: NPVkGKSFrjgh1uwXqD3.setContentLookup(CCxMXuNUEzolDZTKrBJ)
		else: NPVkGKSFrjgh1uwXqD3.setContentLookup(DD5cFIejQa2X4BgAu9GWPyJ3tC7)
		from cTGphBXNeH import iYa4V16rHzIO
		if SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠩࡵࡸࡲࡶࠧગ") in YabJfs3q7yjpzvXioO:
			iYa4V16rHzIO(VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡴࡷࡱࡵ࠭ઘ"),DD5cFIejQa2X4BgAu9GWPyJ3tC7)
		elif xZds9ITEWatF7Kb==VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠫ࠳ࡳࡰࡥࠩઙ") or Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠬ࠵ࡤࡢࡵ࡫࠳ࠬચ") in YabJfs3q7yjpzvXioO:
			iYa4V16rHzIO(SbjiWeHLQPoazqwp3cODkd7YxVgn(u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠭છ"),DD5cFIejQa2X4BgAu9GWPyJ3tC7)
			NPVkGKSFrjgh1uwXqD3.setProperty(Px9e7iCplMfXSzokj0UgIht5LDuEGY,BWNPxIG7vqdTy85pjHzUOrK3(u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡧࡤࡢࡲࡷ࡭ࡻ࡫ࠧજ"))
			NPVkGKSFrjgh1uwXqD3.setProperty(ddo23ZJtgcY(u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡡࡥࡣࡳࡸ࡮ࡼࡥ࠯࡯ࡤࡲ࡮࡬ࡥࡴࡶࡢࡸࡾࡶࡥࠨઝ"),dDYUoKi6JFM23p(u"ࠩࡰࡴࡩ࠭ઞ"))
		if Zi5YkL4Wg92DcSE3FJxMvmUopl:
			NPVkGKSFrjgh1uwXqD3.setSubtitles([Zi5YkL4Wg92DcSE3FJxMvmUopl])
	if yf2jUkehJXZ4zt==HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠪࡺ࡮ࡪࡥࡰࠩટ") and EXkDIZP8nlteMQ4oFfLxuJYy03VHr==QTUBCcehw6qPd4x(u"ࠫࡉࡕࡗࡏࡎࡒࡅࡉ࠭ઠ"):
		bfog7xK6hEWjOJRpIXSy2uZAM = VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠬࡶ࡬ࡢࡻࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬડ")
		EXkDIZP8nlteMQ4oFfLxuJYy03VHr = mQNonhS7CV2BXOv(u"࠭ࡐࡍࡃ࡜ࡣࡉࡒ࡟ࡇࡋࡏࡉࡘ࠭ઢ")
	elif yf2jUkehJXZ4zt==mQNonhS7CV2BXOv(u"ࠧࡷ࡫ࡧࡩࡴ࠭ણ") and Uj49SuMm8dnHkQhorsapbNtf2.startswith(HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠨ࠸ࠪત")):
		bfog7xK6hEWjOJRpIXSy2uZAM = m6hwdgP31a2zjN7lkpX(u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧ࡭ࡳ࡭ࠧથ")
		EXkDIZP8nlteMQ4oFfLxuJYy03VHr = EXkDIZP8nlteMQ4oFfLxuJYy03VHr+TYf7Dc06PQgy1vEV9(u"ࠪࡣࡉࡒࠧદ")
	if bfog7xK6hEWjOJRpIXSy2uZAM!=Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࡯࡮ࡨࠩધ"): wpXZ2KkvNOS8asuE94qedg7ncUr()
	eSxTwPE3zqQk2jWJRcZLMfO5vl9h.zn8a25jkRfSJENI4vy7KO6ie9(EXkDIZP8nlteMQ4oFfLxuJYy03VHr)
	if eSxTwPE3zqQk2jWJRcZLMfO5vl9h.QhOMexbRWaulX: return LAQD5wEkr18bUiGaYen3J(u"ࠬࡨ࡬ࡰࡥ࡮ࡩࡩ࠭ન")
	if yf2jUkehJXZ4zt==ubxGUTt1LraKhVZgpAP(u"࠭ࡶࡪࡦࡨࡳࠬ઩") and not Uj49SuMm8dnHkQhorsapbNtf2.startswith(HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠧ࠷ࠩપ")):
		NPVkGKSFrjgh1uwXqD3.setPath(YabJfs3q7yjpzvXioO)
		mwIxD3GBPgLVc2aq9(MtTygrzXFlQ,EECz06teoykrNFfq(QQ8pvXNcBfVkP5rRJ7o)+Xz3bA2PFENVCUtplu51(u"ࠨࠢࠣࠤ࡛࡯ࡤࡦࡱࠣࡴࡱࡧࡹࠡࡷࡶ࡭ࡳ࡭ࠠࡴࡧࡷࡖࡪࡹ࡯࡭ࡸࡨࡨ࡚ࡸ࡬ࠩࠫࠣࠤࠥ࡜ࡩࡥࡧࡲ࠾ࠥࡡࠠࠨફ")+YabJfs3q7yjpzvXioO+kke1PDGRBLuY8y(u"ࠩࠣࡡࠬબ"))
		xMTL52Bgvu1csftCe4bq6VFpXK.setResolvedUrl(IaCU04ZS1qx,CCxMXuNUEzolDZTKrBJ,NPVkGKSFrjgh1uwXqD3)
	elif yf2jUkehJXZ4zt==P0qdZI384LKleuo(u"ࠪࡰ࡮ࡼࡥࠨભ"):
		mwIxD3GBPgLVc2aq9(MtTygrzXFlQ,EECz06teoykrNFfq(QQ8pvXNcBfVkP5rRJ7o)+mQNonhS7CV2BXOv(u"ࠫࠥࠦࠠࡍ࡫ࡹࡩࠥࡶ࡬ࡢࡻࠣࡹࡸ࡯࡮ࡨࠢࡳࡰࡦࡿࠨࠪࠢࠣࠤ࡛࡯ࡤࡦࡱ࠽ࠤࡠࠦࠧમ")+YabJfs3q7yjpzvXioO+dDYUoKi6JFM23p(u"ࠬࠦ࡝ࠨય"))
		eSxTwPE3zqQk2jWJRcZLMfO5vl9h.play(YabJfs3q7yjpzvXioO,NPVkGKSFrjgh1uwXqD3)
	ip6CohvO5Tya9mFWVf3JdY1qL = DD5cFIejQa2X4BgAu9GWPyJ3tC7
	if bfog7xK6hEWjOJRpIXSy2uZAM==BmePGjS7FxK6kutUM(u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤࡪࡰࡪࠫર"):
		from Yq4oCBNhcw import vXyb5udOTP1gqRjf
		ip6CohvO5Tya9mFWVf3JdY1qL = vXyb5udOTP1gqRjf(YabJfs3q7yjpzvXioO,xZds9ITEWatF7Kb,EXkDIZP8nlteMQ4oFfLxuJYy03VHr)
		if ip6CohvO5Tya9mFWVf3JdY1qL: wpXZ2KkvNOS8asuE94qedg7ncUr()
	else:
		S9WxYCoO3GDw,bfog7xK6hEWjOJRpIXSy2uZAM,ZZ950gFmMJd6iLlTkbUucPQ,WreAQuk9f34cqVZS6TBdLaU5s,l50ExpJ2wfBQuS = LzYQg91SIxDeOGtCKd5,Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠧࡵࡴ࡬ࡩࡩ࠭઱"),DD5cFIejQa2X4BgAu9GWPyJ3tC7,Xz3bA2PFENVCUtplu51(u"࠲࠲࠳࠴ୡ"),VFjQx6Is28KvzLOmMXtg4GqTwa3(u"࠴࠶࠲࠳࠴ୠ")
		if h3MtvrdDKV: import hIVCFnfxSO
		while S9WxYCoO3GDw<l50ExpJ2wfBQuS:
			uuxVm0bTwdnCUAL4s6NKHEBF3M.sleep(WreAQuk9f34cqVZS6TBdLaU5s)
			S9WxYCoO3GDw += WreAQuk9f34cqVZS6TBdLaU5s
			if eSxTwPE3zqQk2jWJRcZLMfO5vl9h.QhOMexbRWaulX==HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠨࡵࡷࡥࡷࡺࡥࡥࠩલ") and not ZZ950gFmMJd6iLlTkbUucPQ:
				if h3MtvrdDKV: hIVCFnfxSO.yicQV3gj4q(IjZbnrBJmM2N(u"้ࠩะาะฺࠠ็็๎ฮࠦล๋ฮสำࠥอไโ์า๎ํ࠭ળ"),TYf7Dc06PQgy1vEV9(u"ࠪࡗࡺࡩࡣࡦࡵࡶࠫ઴"),wLQCTr5lqbsVYeAHdzfhZ1F=zI3ROAZtiUq42rE9WDST68(u"࠹࠸࠴ୢ"))
				mwIxD3GBPgLVc2aq9(iebCpLE8fuxTRg,EECz06teoykrNFfq(QQ8pvXNcBfVkP5rRJ7o)+VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠫࠥࠦࠠࡔࡷࡦࡧࡪࡹࡳ࠻࡚ࠢࠣ࡮ࡪࡥࡰࠢࡶࡸࡦࡸࡴࡦࡦࠣࠤࠥ࡜ࡩࡥࡧࡲ࠾ࠥࡡࠠࠨવ")+YabJfs3q7yjpzvXioO+DYakr9g4PVU(u"ࠬࠦ࡝ࠨશ")+Kd1QjyV82IF4oBAs7tDp6cnOiSuUzW)
				ZZ950gFmMJd6iLlTkbUucPQ = CCxMXuNUEzolDZTKrBJ
			elif eSxTwPE3zqQk2jWJRcZLMfO5vl9h.QhOMexbRWaulX in [uVQd103XyvUce2EBtzbYaC(u"࠭ࡰ࡭ࡣࡼ࡭ࡳ࡭ࠧષ"),QQdAXWBc2GPw(u"ࠧࡵࡧࡶࡸ࡮ࡴࡧࠨસ")]:
				mwIxD3GBPgLVc2aq9(iebCpLE8fuxTRg,EECz06teoykrNFfq(QQ8pvXNcBfVkP5rRJ7o)+ddo23ZJtgcY(u"ࠨࠢࠣࠤࡘࡻࡣࡤࡧࡶࡷ࠿ࠦࠠࡗ࡫ࡧࡩࡴࠦࡰ࡭ࡣࡼ࡭ࡳ࡭࡙ࠠࠡࠢ࡭ࡩ࡫࡯࠻ࠢ࡞ࠤࠬહ")+YabJfs3q7yjpzvXioO+mQNonhS7CV2BXOv(u"ࠩࠣࡡࠬ઺")+Kd1QjyV82IF4oBAs7tDp6cnOiSuUzW)
				break
			elif eSxTwPE3zqQk2jWJRcZLMfO5vl9h.QhOMexbRWaulX==LAQD5wEkr18bUiGaYen3J(u"ࠪࡪࡦ࡯࡬ࡦࡦࠪ઻"):
				mwIxD3GBPgLVc2aq9(WG2BfeyzMa,EECz06teoykrNFfq(QQ8pvXNcBfVkP5rRJ7o)+BmePGjS7FxK6kutUM(u"ࠫࠥࠦࠠࡇࡣ࡬ࡰࡪࡪࠠࡱ࡮ࡤࡽ࡮ࡴࡧࠡࡸ࡬ࡨࡪࡵ࡙ࠠࠡࠢ࡭ࡩ࡫࡯࠻ࠢ࡞ࠤ઼ࠬ")+YabJfs3q7yjpzvXioO+Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠬࠦ࡝ࠨઽ")+Kd1QjyV82IF4oBAs7tDp6cnOiSuUzW)
				if h3MtvrdDKV: hIVCFnfxSO.yicQV3gj4q(TT8Mxv5Wq7nlC9IscdpPUY6(u"࠭แีๆอࠤ฾๋ไ๋หࠣฮูเ๊ๅࠢส่ๆ๐ฯ๋๊ࠪા"),RRIHDFjoW9w7bSfVPhC(u"ࠧࡇࡣ࡬ࡰࡺࡸࡥࠨિ"),wLQCTr5lqbsVYeAHdzfhZ1F=QTUBCcehw6qPd4x(u"࠺࠹࠵ୣ"))
				break
			elif eSxTwPE3zqQk2jWJRcZLMfO5vl9h.QhOMexbRWaulX==ubxGUTt1LraKhVZgpAP(u"ࠨࡤ࡯ࡳࡨࡱࡥࡥࠩી"):
				mwIxD3GBPgLVc2aq9(MF4fVI6yJhaTkAODK,EECz06teoykrNFfq(QQ8pvXNcBfVkP5rRJ7o)+DYakr9g4PVU(u"ࠩࠣࠤࠥࡊࡥࡷ࡫ࡦࡩࠥ࡯ࡳࠡࡤ࡯ࡳࡨࡱࡥࡥࠢࠣࠤ࡛࡯ࡤࡦࡱ࠽ࠤࡠࠦࠧુ")+YabJfs3q7yjpzvXioO+RRIHDFjoW9w7bSfVPhC(u"ࠪࠤࡢ࠭ૂ"))
				break
		else: bfog7xK6hEWjOJRpIXSy2uZAM = QTUBCcehw6qPd4x(u"ࠫࡹ࡯࡭ࡦࡱࡸࡸࠬૃ")
	if bfog7xK6hEWjOJRpIXSy2uZAM in [mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠬࡶ࡬ࡢࡻࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬૄ")] or eSxTwPE3zqQk2jWJRcZLMfO5vl9h.QhOMexbRWaulX in [RRIHDFjoW9w7bSfVPhC(u"࠭ࡰ࡭ࡣࡼ࡭ࡳ࡭ࠧૅ"),mQNonhS7CV2BXOv(u"ࠧࡵࡧࡶࡸ࡮ࡴࡧࠨ૆")] or ip6CohvO5Tya9mFWVf3JdY1qL: chmoCAX8ab7kIirTfJy6YM3zsGq4(EXkDIZP8nlteMQ4oFfLxuJYy03VHr)
	else: exec(m6hwdgP31a2zjN7lkpX(u"ࠨ࡫ࡰࡴࡴࡸࡴࠡࡺࡥࡱࡨࡁࡸࡣ࡯ࡦ࠲ࡕࡲࡡࡺࡧࡵࠬ࠮࠴ࡳࡵࡱࡳࠬ࠮࠭ે"))
	vYfhqkRe7j = uuxVm0bTwdnCUAL4s6NKHEBF3M.Player().isPlaying()
	if not vYfhqkRe7j and bfog7xK6hEWjOJRpIXSy2uZAM not in [SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧ࡭ࡳ࡭ࠧૈ")]:
		msg = Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠪࡘ࡮ࡳࡥࡰࡷࡷࠫૉ") if bfog7xK6hEWjOJRpIXSy2uZAM==BWNPxIG7vqdTy85pjHzUOrK3(u"ࠫࡹ࡯࡭ࡦࡱࡸࡸࠬ૊") else TT8Mxv5Wq7nlC9IscdpPUY6(u"࡛ࠬ࡮࡬ࡰࡲࡻࡳ࠭ો")
		if h3MtvrdDKV: hIVCFnfxSO.yicQV3gj4q(UUkIBz1sgQ9WfNeG6trKXvu0(u"࠭แีๆอࠤ฾๋ไ๋หࠣฮูเ๊ๅࠢส่ๆ๐ฯ๋๊ࠪૌ"),msg,wLQCTr5lqbsVYeAHdzfhZ1F=UUkIBz1sgQ9WfNeG6trKXvu0(u"࠻࠺࠶୤"))
		mwIxD3GBPgLVc2aq9(WG2BfeyzMa,EECz06teoykrNFfq(QQ8pvXNcBfVkP5rRJ7o)+uVQd103XyvUce2EBtzbYaC(u"્ࠧࠡࠢࠣࠫ")+msg+Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠨ࠼ࠣࠤ࡚ࡴ࡫࡯ࡱࡺࡲࠥࡶࡲࡰࡤ࡯ࡩࡲࠦࠠࠡࡘ࡬ࡨࡪࡵ࠺ࠡ࡝ࠣࠫ૎")+YabJfs3q7yjpzvXioO+shC5qBRV2A0lZ(u"ࠩࠣࡡࠬ૏")+Kd1QjyV82IF4oBAs7tDp6cnOiSuUzW)
	return eSxTwPE3zqQk2jWJRcZLMfO5vl9h.QhOMexbRWaulX
def Gz7MH0glBw8Eb(YabJfs3q7yjpzvXioO):
	path = kke1PDGRBLuY8y(u"ࠪ࠳ࠬૐ").join(YabJfs3q7yjpzvXioO.split(VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠫ࠴࠭૑"))[LAQD5wEkr18bUiGaYen3J(u"࠸୥"):]) if TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠬࡀ࠯࠰ࠩ૒") in YabJfs3q7yjpzvXioO else YabJfs3q7yjpzvXioO
	E8bkSaBg3nUQNc2Xq = YYBlm36zd0Jst18LXwo4.findall(RRIHDFjoW9w7bSfVPhC(u"࠭࡜࠯ࠪ࡞ࡥ࠲ࢀ࠰࠮࠻ࡠ࠯࠮࠭૓"),path,YYBlm36zd0Jst18LXwo4.DOTALL)
	CJd3b5nkxWiusaOrTHKG = [VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠧ࡮࠵ࡸ࠼ࠬ૔"),TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠨ࡯ࡳ࠸ࠬ૕"),HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠩࡰࡴࡩ࠭૖"),ddo23ZJtgcY(u"ࠪࡻࡪࡨ࡭ࠨ૗"),ddo23ZJtgcY(u"ࠫࡦࡼࡩࠨ૘"),Xz3bA2PFENVCUtplu51(u"ࠬࡧࡡࡤࠩ૙"),HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"࠭࡭࠴ࡷࠪ૚"),SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠧ࡮࡭ࡹࠫ૛"),P0qdZI384LKleuo(u"ࠨࡨ࡯ࡺࠬ૜"),mQNonhS7CV2BXOv(u"ࠩࡰࡴ࠸࠭૝"),UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠪࡸࡸ࠭૞")]
	for tB4vJmjbcI9WPuMhsrOpG8V3og1e in E8bkSaBg3nUQNc2Xq:
		if tB4vJmjbcI9WPuMhsrOpG8V3og1e in CJd3b5nkxWiusaOrTHKG: return ddo23ZJtgcY(u"ࠫ࠳࠭૟")+tB4vJmjbcI9WPuMhsrOpG8V3og1e
	return b8Qe150xVaJsnDSv
def chmoCAX8ab7kIirTfJy6YM3zsGq4(Eqh4xYr9VWQSc2kf0biID):
	if not XrloM5pTyK.xd4VjQuvJDC2ms: Eqh4xYr9VWQSc2kf0biID += dDYUoKi6JFM23p(u"ࠬࡥࡔࡔࠩૠ")
	ZHIif0JXSYpqh1OKuoR.append(Eqh4xYr9VWQSc2kf0biID)
	return
def ldtI4ef3qWaKVP5p(NNWxcvgrBk49LAf7nFXmYTS0Q=DD5cFIejQa2X4BgAu9GWPyJ3tC7):
	NXpaA3f9eE(NNWxcvgrBk49LAf7nFXmYTS0Q,shC5qBRV2A0lZ(u"࠭࡟ࡠࡡࡉࡓࡗࡉࡅࡠࡇ࡛ࡍ࡙ࡥ࡟ࡠࠩૡ"))
	Pft6y0LvwSh48iYg7b.exit()
def NXpaA3f9eE(NNWxcvgrBk49LAf7nFXmYTS0Q,yABitW02UXORGEJQPsTujcL):
	if yABitW02UXORGEJQPsTujcL:
		if TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠧࡠࡡࡢࡊࡔࡘࡃࡆࡡࡈ࡜ࡎ࡚࡟ࡠࡡࠪૢ") in yABitW02UXORGEJQPsTujcL: mwIxD3GBPgLVc2aq9(b8Qe150xVaJsnDSv,S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠨࡡࡢࡣࡋࡕࡒࡄࡇࡢࡉ࡝ࡏࡔࡠࡡࡢࠫૣ"))
		else:
			z0zWBctmDyOiM4dnFAxHVL = hRWC8YSFvsm4JHOMVIne3jquZ.getSetting(QTUBCcehw6qPd4x(u"ࠩࡤࡺ࠳ࡲࡡ࡯ࡩࡸࡥ࡬࡫࠮ࡵࡴࡤࡲࡸࡲࡡࡵࡧࠪ૤"))
			hRWC8YSFvsm4JHOMVIne3jquZ.setSetting(yST5AHEfvPmcWpwGuh2BJ(u"ࠪࡥࡻ࠴࡬ࡢࡰࡪࡹࡦ࡭ࡥ࠯ࡶࡵࡥࡳࡹ࡬ࡢࡶࡨࠫ૥"),b8Qe150xVaJsnDSv)
			import hIVCFnfxSO
			hIVCFnfxSO.vvcDoAQJ2zCpBM6tfaKb(yABitW02UXORGEJQPsTujcL)
			hRWC8YSFvsm4JHOMVIne3jquZ.setSetting(P0qdZI384LKleuo(u"ࠫࡦࡼ࠮࡭ࡣࡱ࡫ࡺࡧࡧࡦ࠰ࡷࡶࡦࡴࡳ࡭ࡣࡷࡩࠬ૦"),z0zWBctmDyOiM4dnFAxHVL)
	Ljkr2F3IQgNn8v6(LAQD5wEkr18bUiGaYen3J(u"ࠬࡹࡴࡰࡲࠪ૧"))
	iPKbSRLnl2HJxFMjwQkGza = hRWC8YSFvsm4JHOMVIne3jquZ.getSetting(DYakr9g4PVU(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡵࡩ࡫ࡸࡥࡴࡪࠪ૨"))
	if iPKbSRLnl2HJxFMjwQkGza==ddo23ZJtgcY(u"ࠧࡓࡇࡔ࡙ࡊ࡙ࡔࡠࡔࡈࡊࡗࡋࡓࡉࡡࡆࡅࡈࡎࡅࠨ૩"): hRWC8YSFvsm4JHOMVIne3jquZ.setSetting(BmePGjS7FxK6kutUM(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡷ࡫ࡦࡳࡧࡶ࡬ࠬ૪"),LAQD5wEkr18bUiGaYen3J(u"ࠩࡕࡉࡋࡘࡅࡔࡊࡢࡇࡆࡉࡈࡆࠩ૫"))
	elif iPKbSRLnl2HJxFMjwQkGza==uVQd103XyvUce2EBtzbYaC(u"ࠪࡖࡊࡌࡒࡆࡕࡋࡣࡈࡇࡃࡉࡇࠪ૬"): hRWC8YSFvsm4JHOMVIne3jquZ.setSetting(Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡳࡧࡩࡶࡪࡹࡨࠨ૭"),b8Qe150xVaJsnDSv)
	if hRWC8YSFvsm4JHOMVIne3jquZ.getSetting(vvWwO3Tx2dAgcijrFXq(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡷࡶࡩࡩࡴࡳࠨ૮")) not in [kke1PDGRBLuY8y(u"࠭ࡁࡖࡖࡒࠫ૯"),Mmpr0o76iWJvz1kTtfgI8hES(u"ࠧࡔࡖࡒࡔࠬ૰"),shC5qBRV2A0lZ(u"ࠨࡃࡖࡏࠬ૱")]: hRWC8YSFvsm4JHOMVIne3jquZ.setSetting(zI3ROAZtiUq42rE9WDST68(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡦࡱࡷࠬ૲"),TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠪࡅࡘࡑࠧ૳"))
	if hRWC8YSFvsm4JHOMVIne3jquZ.getSetting(Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡵࡨࡴࡷࡵࡸࡺࠩ૴")) not in [vvWwO3Tx2dAgcijrFXq(u"ࠬࡇࡕࡕࡑࠪ૵"),yST5AHEfvPmcWpwGuh2BJ(u"࠭ࡓࡕࡑࡓࠫ૶"),UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠧࡂࡕࡎࠫ૷")]: hRWC8YSFvsm4JHOMVIne3jquZ.setSetting(P0qdZI384LKleuo(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡺࡹࡥࡱࡴࡲࡼࡾ࠭૸"),Nh0BWuiSndf(u"ࠩࡄࡗࡐ࠭ૹ"))
	P39CEXwDGUVl2e65cyS71Bvqu4O = hRWC8YSFvsm4JHOMVIne3jquZ.getSetting(RRIHDFjoW9w7bSfVPhC(u"ࠪࡥࡻ࠴࡭ࡺࡵ࡮࡭ࡳ࠴ࡶࡪࡧࡺࡱࡴࡪࡥࠨૺ"))
	autQ6O2JANPLKyk3Y = uuxVm0bTwdnCUAL4s6NKHEBF3M.executeJSONRPC(BmePGjS7FxK6kutUM(u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡗࡪࡺࡴࡪࡰࡪࡷ࠳ࡍࡥࡵࡕࡨࡸࡹ࡯࡮ࡨࡘࡤࡰࡺ࡫ࠢ࠭ࠤ࡬ࡨࠧࡀ࠱࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡹࡥࡵࡶ࡬ࡲ࡬ࠨ࠺ࠣ࡮ࡲࡳࡰࡧ࡮ࡥࡨࡨࡩࡱ࠴ࡳ࡬࡫ࡱࠦࢂࢃࠧૻ"))
	if Xz3bA2PFENVCUtplu51(u"ࠬࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇࠫૼ") in str(autQ6O2JANPLKyk3Y) and P39CEXwDGUVl2e65cyS71Bvqu4O in [BWNPxIG7vqdTy85pjHzUOrK3(u"࠭ࡅࡎࡃࡇࠤࡑ࡯ࡳࡵࠩ૽"),Mmpr0o76iWJvz1kTtfgI8hES(u"ࠧࡆࡏࡄࡈࠥࡍࡡ࡭࡮ࡨࡶࡾ࠭૾")]:
		wLQCTr5lqbsVYeAHdzfhZ1F.sleep(RRIHDFjoW9w7bSfVPhC(u"࠶࠮࠲࠲࠳୦"))
		uuxVm0bTwdnCUAL4s6NKHEBF3M.executebuiltin(IjZbnrBJmM2N(u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡘ࡫ࡴࡗ࡫ࡨࡻࡒࡵࡤࡦࠪ࠳࠭ࠬ૿"))
	if LzYQg91SIxDeOGtCKd5 and IaCU04ZS1qx>-qHYIWnOZLPkrQU:
		xMTL52Bgvu1csftCe4bq6VFpXK.setResolvedUrl(IaCU04ZS1qx,DD5cFIejQa2X4BgAu9GWPyJ3tC7,evil9I2DnLJcy8.ListItem())
		ip6CohvO5Tya9mFWVf3JdY1qL,NYVaJlWbG1hj52U9LzdKfi,okRX5wzaWp6PcrB = DD5cFIejQa2X4BgAu9GWPyJ3tC7,DD5cFIejQa2X4BgAu9GWPyJ3tC7,DD5cFIejQa2X4BgAu9GWPyJ3tC7
		xMTL52Bgvu1csftCe4bq6VFpXK.endOfDirectory(IaCU04ZS1qx,ip6CohvO5Tya9mFWVf3JdY1qL,NYVaJlWbG1hj52U9LzdKfi,okRX5wzaWp6PcrB)
	if ZHIif0JXSYpqh1OKuoR:
		s4Gq9zKuhydTlOmFDLYaAnNo = Ay1SMOzkx5CU3aGTL4Zf.Thread(target=Rc1WyY8UG2HO5,args=(ZHIif0JXSYpqh1OKuoR,))
		s4Gq9zKuhydTlOmFDLYaAnNo.start()
	gfnPHLSp49BA8RXxCYd5WMriv = pRA1LmxBJN3SzIjPansgt()
	vYfhqkRe7j = uuxVm0bTwdnCUAL4s6NKHEBF3M.Player().isPlaying()
	if gfnPHLSp49BA8RXxCYd5WMriv:
		if not vYfhqkRe7j: pie0DRMAtn = uuxVm0bTwdnCUAL4s6NKHEBF3M.executeJSONRPC(dDYUoKi6JFM23p(u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡒ࡯ࡥࡾࡲࡩࡴࡶ࠱ࡇࡱ࡫ࡡࡳࠤ࠯ࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡱ࡮ࡤࡽࡱ࡯ࡳࡵ࡫ࡧࠦ࠿࠷ࡽࡾࠩ଀"))
		else:
			hUKFmsjM1LwGk7q = d2iaEbQkWUS1nzRJHVmlu()
			if hUKFmsjM1LwGk7q:
				XrloM5pTyK.resolveonly = CCxMXuNUEzolDZTKrBJ
				wLQCTr5lqbsVYeAHdzfhZ1F.sleep(LAQD5wEkr18bUiGaYen3J(u"࠶࠱୧"))
				vYfhqkRe7j = uuxVm0bTwdnCUAL4s6NKHEBF3M.Player().isPlaying()
				if vYfhqkRe7j:
					E57WK4m31C8,rlqNUcK9vYgkT,YabJfs3q7yjpzvXioO,Q8ZnJhRz2mINwrY6VPf,I6YPOSofrpnTwRm8b,NGQDwOCXx1BZmd9Huc,vv5M4UfJS9ucKEiNbxtnaOZ,wc0Z9FAdf2B1J,XXra5dzn8tcLOxYZIE7pPof49Hh = rhoGF8ta4UesmTucY6V2O1A(hUKFmsjM1LwGk7q)
					import hIVCFnfxSO
					if not any(Y8aiFZsLKw in rlqNUcK9vYgkT for Y8aiFZsLKw in hIVCFnfxSO.NOT_TO_TEST_ALL_SERVERS):
						hIVCFnfxSO.yicQV3gj4q(Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠪห้็๊ะ์๋ࠤฬ๊ไศฯๅࠫଁ"),TYf7Dc06PQgy1vEV9(u"ࠫๆำีࠡฮ่๎฾ࠦวๅีํีๆืวหࠩଂ"),wLQCTr5lqbsVYeAHdzfhZ1F=RRIHDFjoW9w7bSfVPhC(u"࠲࠲࠳࠴୨"))
						wLQCTr5lqbsVYeAHdzfhZ1F.sleep(TT8Mxv5Wq7nlC9IscdpPUY6(u"࠴୩"))
						if hDTluNxe7tCwrpqXHzdEcYRfbs:
							YabJfs3q7yjpzvXioO = YabJfs3q7yjpzvXioO.encode(OVauxZzLI10vcXT74K)
						hIVCFnfxSO.PDanwWu4bFAhe3m(DD5cFIejQa2X4BgAu9GWPyJ3tC7,DD5cFIejQa2X4BgAu9GWPyJ3tC7,DD5cFIejQa2X4BgAu9GWPyJ3tC7)
						XXxlOLJ9KRjPH382WVCvr6n71 = hIVCFnfxSO.fPYwhSsFOBLbt7rM902im4oVE(E57WK4m31C8,rlqNUcK9vYgkT,YabJfs3q7yjpzvXioO,Q8ZnJhRz2mINwrY6VPf,I6YPOSofrpnTwRm8b,NGQDwOCXx1BZmd9Huc,vv5M4UfJS9ucKEiNbxtnaOZ,wc0Z9FAdf2B1J,XXra5dzn8tcLOxYZIE7pPof49Hh)
						hIVCFnfxSO.PDanwWu4bFAhe3m(CCxMXuNUEzolDZTKrBJ,CCxMXuNUEzolDZTKrBJ,DD5cFIejQa2X4BgAu9GWPyJ3tC7)
						hIVCFnfxSO.yicQV3gj4q(shC5qBRV2A0lZ(u"ࠬอไโ์า๎ํࠦวๅๆสั็࠭ଃ"),SbjiWeHLQPoazqwp3cODkd7YxVgn(u"࠭ว็ฬ๊ํࠥ็อึࠢสุ่๐ัโำสฮࠬ଄"),wLQCTr5lqbsVYeAHdzfhZ1F=Nh0BWuiSndf(u"࠴࠴࠵࠶୪"))
						NNWxcvgrBk49LAf7nFXmYTS0Q = DD5cFIejQa2X4BgAu9GWPyJ3tC7
	SxJIWAMj86cQms5agzf0 = hRWC8YSFvsm4JHOMVIne3jquZ.getSetting(P0qdZI384LKleuo(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡦ࡮ࡺࡲࡢࡶࡨࠫଅ"))
	if RRIHDFjoW9w7bSfVPhC(u"ࠨ࠯ࠪଆ") in SxJIWAMj86cQms5agzf0:
		SxJIWAMj86cQms5agzf0 = SxJIWAMj86cQms5agzf0.replace(ddo23ZJtgcY(u"ࠩ࠰ࠫଇ"),b8Qe150xVaJsnDSv)
		hRWC8YSFvsm4JHOMVIne3jquZ.setSetting(DYakr9g4PVU(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡢࡪࡶࡵࡥࡹ࡫ࠧଈ"),SxJIWAMj86cQms5agzf0)
	if NNWxcvgrBk49LAf7nFXmYTS0Q: uuxVm0bTwdnCUAL4s6NKHEBF3M.executebuiltin(mQNonhS7CV2BXOv(u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡓࡧࡩࡶࡪࡹࡨࠨଉ"))
	return
def d2iaEbQkWUS1nzRJHVmlu():
	o8Uvl02GSWKDbABqXhdMFs = uuxVm0bTwdnCUAL4s6NKHEBF3M.executeJSONRPC(Xz3bA2PFENVCUtplu51(u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡕࡲࡡࡺ࡮࡬ࡷࡹ࠴ࡇࡦࡶࡌࡸࡪࡳࡳࠣ࠮ࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡪࡦࠥ࠾࠶࠲ࠢࡱࡴࡲࡴࡪࡸࡴࡪࡧࡶࠦ࠿ࡡࠢࡵ࡫ࡷࡰࡪࠨࠬࠣࡨ࡬ࡰࡪࠨࠬࠣࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࠦࡢࢃࠬࠣ࡫ࡧࠦ࠿࠷ࡽࠨଊ"))
	XXxlOLJ9KRjPH382WVCvr6n71 = AFIDMBehNx5QH6g21E8kq9JzrLi.loads(o8Uvl02GSWKDbABqXhdMFs)[Mmpr0o76iWJvz1kTtfgI8hES(u"࠭ࡲࡦࡵࡸࡰࡹ࠭ଋ")]
	hUKFmsjM1LwGk7q = b8Qe150xVaJsnDSv
	try: items = XXxlOLJ9KRjPH382WVCvr6n71[QTUBCcehw6qPd4x(u"ࠧࡪࡶࡨࡱࡸ࠭ଌ")]
	except: return b8Qe150xVaJsnDSv
	if items:
		for JZMvR4mp2rX7Kf6n,file in enumerate(items):
			path = file[zI3ROAZtiUq42rE9WDST68(u"ࠨࡨ࡬ࡰࡪ࠭଍")]
			if DFUIv2KGj9ke not in path: continue
			path = path.split(DFUIv2KGj9ke)[qHYIWnOZLPkrQU][qHYIWnOZLPkrQU:]
			if path==ZqDQCMovyXKFG7ki4BrahuWt1IS8: break
		count = XXxlOLJ9KRjPH382WVCvr6n71[vvWwO3Tx2dAgcijrFXq(u"ࠩ࡯࡭ࡲ࡯ࡴࡴࠩ଎")][QQdAXWBc2GPw(u"ࠪࡸࡴࡺࡡ࡭ࠩଏ")]
		if JZMvR4mp2rX7Kf6n+qHYIWnOZLPkrQU<count: hUKFmsjM1LwGk7q = items[JZMvR4mp2rX7Kf6n+qHYIWnOZLPkrQU][IjZbnrBJmM2N(u"ࠫ࡫࡯࡬ࡦࠩଐ")]
	return hUKFmsjM1LwGk7q
def pRA1LmxBJN3SzIjPansgt():
	pie0DRMAtn = uuxVm0bTwdnCUAL4s6NKHEBF3M.executeJSONRPC(HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠢࠥࡱࡪࡺࡨࡰࡦࠥ࠾࡙ࠧࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡈࡧࡷࡗࡪࡺࡴࡪࡰࡪ࡚ࡦࡲࡵࡦࠤ࠯ࠦ࡮ࡪࠢ࠻࠳࠯ࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡴࡧࡷࡸ࡮ࡴࡧࠣ࠼ࠥࡺ࡮ࡪࡥࡰࡲ࡯ࡥࡾ࡫ࡲ࠯ࡣࡸࡸࡴࡶ࡬ࡢࡻࡱࡩࡽࡺࡩࡵࡧࡰࠦࢂࢃࠧ଑"))
	g8URiqaPVe4chEY = DD5cFIejQa2X4BgAu9GWPyJ3tC7 if ddo23ZJtgcY(u"࡛࠭࡞ࠩ଒") in str(pie0DRMAtn) else CCxMXuNUEzolDZTKrBJ
	return g8URiqaPVe4chEY
def Ljkr2F3IQgNn8v6(ZZaEfUmShY1jwNztcP3W4):
	global rr6IVXNFsezAw15m
	if rr6IVXNFsezAw15m:
		if ZZaEfUmShY1jwNztcP3W4==Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠧࡴࡶࡲࡴࠬଓ"):
			sbIwdOBpfqzu6N = mQNonhS7CV2BXOv(u"ࠨࡤࡸࡷࡾࡪࡩࡢ࡮ࡲ࡫ࡳࡵࡣࡢࡰࡦࡩࡱ࠭ଔ") if g1gmkxOtc2oeEZHhBiy>HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"࠵࠼࠴࠹࠺୫") else RRIHDFjoW9w7bSfVPhC(u"ࠩࡥࡹࡸࡿࡤࡪࡣ࡯ࡳ࡬࠭କ")
			uuxVm0bTwdnCUAL4s6NKHEBF3M.executebuiltin(zI3ROAZtiUq42rE9WDST68(u"ࠪࡈ࡮ࡧ࡬ࡰࡩ࠱ࡇࡱࡵࡳࡦࠪࠪଖ")+sbIwdOBpfqzu6N+P0qdZI384LKleuo(u"ࠫ࠮࠭ଗ"))
			rr6IVXNFsezAw15m = DD5cFIejQa2X4BgAu9GWPyJ3tC7
	else:
		if ZZaEfUmShY1jwNztcP3W4==dDYUoKi6JFM23p(u"ࠬࡹࡴࡢࡴࡷࠫଘ"):
			sbIwdOBpfqzu6N = m6hwdgP31a2zjN7lkpX(u"࠭ࡢࡶࡵࡼࡨ࡮ࡧ࡬ࡰࡩࡱࡳࡨࡧ࡮ࡤࡧ࡯ࠫଙ") if g1gmkxOtc2oeEZHhBiy>BmePGjS7FxK6kutUM(u"࠶࠽࠮࠺࠻୬") else SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠧࡣࡷࡶࡽࡩ࡯ࡡ࡭ࡱࡪࠫଚ")
			uuxVm0bTwdnCUAL4s6NKHEBF3M.executebuiltin(IjZbnrBJmM2N(u"ࠨࡃࡦࡸ࡮ࡼࡡࡵࡧ࡚࡭ࡳࡪ࡯ࡸࠪࠪଛ")+sbIwdOBpfqzu6N+BWNPxIG7vqdTy85pjHzUOrK3(u"ࠩࠬࠫଜ"))
			rr6IVXNFsezAw15m = CCxMXuNUEzolDZTKrBJ
	return
n5G2rA3lwY,eIX7d8Ki4koCfzMmqZPE = None,None
ZHIif0JXSYpqh1OKuoR = []
EtvK0T2LNPcsIrAFlufpM = P1u7tUzG9XMxHjSlnk6QvARoNVCO5i()
ZZPtSiqLbRsVBUGdm = EtvK0T2LNPcsIrAFlufpM.splitlines()[LzYQg91SIxDeOGtCKd5][-TYf7Dc06PQgy1vEV9(u"࠸࠴୭"):]
XrloM5pTyK.r6rSFTpNl5nqd4s9GbEK8zhoXY,XrloM5pTyK.xd4VjQuvJDC2ms,XrloM5pTyK.jnUMHEBQmux94kPbOZXYaAoheNq3L6,XrloM5pTyK.pYMuE6jbdODCPUH = YRU71oePGNrDj5AOHapluvtMy([vvWwO3Tx2dAgcijrFXq(u"ࠪࡇ࡙ࡋ࠹ࡅࡕ࠴࠽࡛࡛࠰ࡗࡕ࡛ࠫଝ"),vvWwO3Tx2dAgcijrFXq(u"ࠫ࡜࡙ࡕࡓࡈࡗ࠵࠾ࡗࡔࡆࡈ࡝࡜ࠬଞ"),TYf7Dc06PQgy1vEV9(u"ࠬࡈࡔࡆࡺࡓ࡚࠶࠿ࡕࡓࡘࡑ࡙ࡘ࡛࠵ࡉ࡚ࠪଟ"),Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"࠭ࡏࡕ࠳࠼ࡎ࡚࠶ࡸࡃࡖࡘࡰࡉ࡞ࠧଠ")])
u26jYNwLID1r3ZtVlJAp87dFkgz = b8Qe150xVaJsnDSv
XrloM5pTyK.resolveonly = DD5cFIejQa2X4BgAu9GWPyJ3tC7
eSxTwPE3zqQk2jWJRcZLMfO5vl9h = uu3PFVGN5jWA()
XrloM5pTyK.showDialogs = CCxMXuNUEzolDZTKrBJ
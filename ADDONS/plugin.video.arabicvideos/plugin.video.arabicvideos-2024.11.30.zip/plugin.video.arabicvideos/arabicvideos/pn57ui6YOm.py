# -*- coding: utf-8 -*-
from hIVCFnfxSO import *
headers = { 'User-Agent' : b8Qe150xVaJsnDSv }
QQ8pvXNcBfVkP5rRJ7o = 'AKWAM'
WbzmKSZiuOYrBN7oysJ2dUv = '_AKW_'
wQjs1XZ3AO24g8y9bEeoKMiGIu7 = nTHXJIiah2qK[QQ8pvXNcBfVkP5rRJ7o][0]
kfdvpKQE7qOCHtuj = b8Qe150xVaJsnDSv
v1vJEhoNQBVPkjG = ['ألعاب','المصارعة الحرة','القران الكريم','الكتب و الابحاث','الصور و الخلفيات','المسلسلات الاذاعية']
def x8IFqMZeJj7suCR4AaGoNXfEHm(mode,url,text):
	if   mode==240: XXxlOLJ9KRjPH382WVCvr6n71 = Y72YmLgw4vqlHxTCkbeKSicasD()
	elif mode==241: XXxlOLJ9KRjPH382WVCvr6n71 = Je4TwC30iOG5DLKWAtbYvhs(url,text)
	elif mode==242: XXxlOLJ9KRjPH382WVCvr6n71 = bIpskeGhBlqH(url)
	elif mode==243: XXxlOLJ9KRjPH382WVCvr6n71 = Hkij627uCDJKyIM(url)
	elif mode==244: XXxlOLJ9KRjPH382WVCvr6n71 = eszTQbMvkmRwCAxGDPdYJUi(url,'FILTERS___'+text)
	elif mode==245: XXxlOLJ9KRjPH382WVCvr6n71 = eszTQbMvkmRwCAxGDPdYJUi(url,'CATEGORIES___'+text)
	elif mode==246: XXxlOLJ9KRjPH382WVCvr6n71 = HTC7pBQerZugU0WdJqi(url)
	elif mode==247: XXxlOLJ9KRjPH382WVCvr6n71 = jZX6xHcf201lW3O(url)
	elif mode==248: XXxlOLJ9KRjPH382WVCvr6n71 = oYjOnUAT124ZgBkFEDv6WpGI3uxz9()
	elif mode==249: XXxlOLJ9KRjPH382WVCvr6n71 = kstJfK6jHQWrXDSMRIGB7(text)
	else: XXxlOLJ9KRjPH382WVCvr6n71 = False
	return XXxlOLJ9KRjPH382WVCvr6n71
def oYjOnUAT124ZgBkFEDv6WpGI3uxz9():
	tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'رسالة من المبرمج','هذا الموقع "أكوام الجديد" في بعض الأحيان فيه نوع من الحجب ضد البرامج . وهذا يسبب مشكلة في تشغيل الفيديوهات . هذه المشكلة سببها من الموقع الأصلي وهي تظهر وتختفي بصورة عشوائية')
	return
def Y72YmLgw4vqlHxTCkbeKSicasD():
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',wQjs1XZ3AO24g8y9bEeoKMiGIu7,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'AKWAM-MENU-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	UUWbqzPgYKHZ3uxm = YYBlm36zd0Jst18LXwo4.findall('home-site-btn-container.*?href="(.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if UUWbqzPgYKHZ3uxm: UUWbqzPgYKHZ3uxm = UUWbqzPgYKHZ3uxm[0]
	else: UUWbqzPgYKHZ3uxm = wQjs1XZ3AO24g8y9bEeoKMiGIu7
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',UUWbqzPgYKHZ3uxm,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'AKWAM-MENU-2nd')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'بحث في الموقع',b8Qe150xVaJsnDSv,249,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'_REMEMBERRESULTS_')
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'فلتر محدد',wQjs1XZ3AO24g8y9bEeoKMiGIu7,246)
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'فلتر كامل',wQjs1XZ3AO24g8y9bEeoKMiGIu7,247)
	MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+' ===== ===== ===== '+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999)
	MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+'المميزة',UUWbqzPgYKHZ3uxm,241,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'featured')
	recent = YYBlm36zd0Jst18LXwo4.findall('recently-container.*?href="(.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	pcA1dzy7LXwGfMPg9mTkuh5tine3 = recent[0]
	MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+'أضيف حديثا',pcA1dzy7LXwGfMPg9mTkuh5tine3,241)
	MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+' ===== ===== ===== '+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999)
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('mb-4 d-flex align-items-center.*?href="(.*?)".*?class="header-link text-white">(.*?)<.*?class="menu"(.*?)</div>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	for pcA1dzy7LXwGfMPg9mTkuh5tine3,name,OTKx7aVb2hdS16Wrweky4FXfIN0g9 in ZV5rRvabhxJ:
		if name in v1vJEhoNQBVPkjG: continue
		MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+name,pcA1dzy7LXwGfMPg9mTkuh5tine3,241)
		items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)">(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
			if title in v1vJEhoNQBVPkjG: continue
			title = name+pldxivXC5wbTB2O8q+title
			MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,241)
	return
def HTC7pBQerZugU0WdJqi(website=b8Qe150xVaJsnDSv):
	jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(Q49IsrlSuYRAVbGKhwdckLDOetF2PZ,wQjs1XZ3AO24g8y9bEeoKMiGIu7,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,'AKWAM-MENU-1st')
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('class="menu(.*?)<nav',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)".*?text">(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
			if title not in v1vJEhoNQBVPkjG:
				title = title+' مصنفة'
				MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,245)
		if website==b8Qe150xVaJsnDSv: MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+' ===== ===== ===== '+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999)
	return jLtdbeYiQHnf4SpU2MTly
def jZX6xHcf201lW3O(website=b8Qe150xVaJsnDSv):
	jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(Q49IsrlSuYRAVbGKhwdckLDOetF2PZ,wQjs1XZ3AO24g8y9bEeoKMiGIu7,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,'AKWAM-MENU-1st')
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('class="menu(.*?)<nav',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)".*?text">(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
			if title not in v1vJEhoNQBVPkjG:
				title = title+' مفلترة'
				MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,244)
		if website==b8Qe150xVaJsnDSv: MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+' ===== ===== ===== '+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999)
	return jLtdbeYiQHnf4SpU2MTly
def Je4TwC30iOG5DLKWAtbYvhs(url,type=b8Qe150xVaJsnDSv):
	jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(GMkNL1RXxKFentp0Zh9d,url,b8Qe150xVaJsnDSv,headers,True,'AKWAM-TITLES-1st')
	if type=='featured': ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('swiper-container(.*?)swiper-button-prev',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	else: ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('class="widget"(.*?)main-footer',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		items = YYBlm36zd0Jst18LXwo4.findall('data-src="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		if not items:
			items = YYBlm36zd0Jst18LXwo4.findall('src="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for lvtGpMZHb9,pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
			if '/series/' in pcA1dzy7LXwGfMPg9mTkuh5tine3 or '/shows/' in pcA1dzy7LXwGfMPg9mTkuh5tine3:
				MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,242,lvtGpMZHb9)
			elif '/movies/' in pcA1dzy7LXwGfMPg9mTkuh5tine3:
				MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,243,lvtGpMZHb9)
			elif '/games/' not in pcA1dzy7LXwGfMPg9mTkuh5tine3:
				MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,243,lvtGpMZHb9)
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('pagination(.*?)</div>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)".*?>(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
			if title=='&lsaquo;': title = 'سابقة'
			if title=='&rsaquo;': title = 'لاحقة'
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = pTP49ckGDYrofa2KxenumbH0(pcA1dzy7LXwGfMPg9mTkuh5tine3)
			MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'صفحة '+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,241)
	return
def kstJfK6jHQWrXDSMRIGB7(search):
	search,v7Rxw52Z4X0,showDialogs = JimhUH0SEf6w(search)
	if search==b8Qe150xVaJsnDSv: search = FT2oXWtPQpVGuexmLqKN3srdzYn()
	if search==b8Qe150xVaJsnDSv: return
	LgXO1RhbDV7cx6EaeYCNm4zjJdBS = search.replace(pldxivXC5wbTB2O8q,'%20')
	url = wQjs1XZ3AO24g8y9bEeoKMiGIu7 + '/search?q='+LgXO1RhbDV7cx6EaeYCNm4zjJdBS
	XXxlOLJ9KRjPH382WVCvr6n71 = Je4TwC30iOG5DLKWAtbYvhs(url)
	return
def bIpskeGhBlqH(url):
	jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(GMkNL1RXxKFentp0Zh9d,url,b8Qe150xVaJsnDSv,headers,True,'AKWAM-EPISODES-1st')
	if '-episodes">' not in jLtdbeYiQHnf4SpU2MTly:
		lvtGpMZHb9 = uuxVm0bTwdnCUAL4s6NKHEBF3M.getInfoLabel('ListItem.Icon')
		MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+'رابط التشغيل',url,243,lvtGpMZHb9)
	else:
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('-episodes">(.*?)<div class="widget-4',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		f0iybKmnzw6vZEd = YYBlm36zd0Jst18LXwo4.findall('href="(http.*?)".*?>(.*?)<.*?src="(.*?)"',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,title,lvtGpMZHb9 in f0iybKmnzw6vZEd:
			title = title.replace(k5bCDErUSmv,pldxivXC5wbTB2O8q)
			if 'الحلقات' in title or 'مواسم اخرى' in title: continue
			if '/series/' in pcA1dzy7LXwGfMPg9mTkuh5tine3: MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,242,lvtGpMZHb9)
			else: MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,243,lvtGpMZHb9)
	return
def Hkij627uCDJKyIM(url):
	jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(Q49IsrlSuYRAVbGKhwdckLDOetF2PZ,url,b8Qe150xVaJsnDSv,headers,True,'AKWAM-PLAY-1st')
	EQUkgc3PLy5mhBiZINJ0HO1A6 = YYBlm36zd0Jst18LXwo4.findall('badge-danger.*?>(.*?)<',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if EQUkgc3PLy5mhBiZINJ0HO1A6 and vvIMS2DeraLfJ(QQ8pvXNcBfVkP5rRJ7o,url,EQUkgc3PLy5mhBiZINJ0HO1A6): return
	fqzp8elOIU1a = YYBlm36zd0Jst18LXwo4.findall('li><a href="#(.*?)".*?>(.*?)<',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j,uuSKUinvP4EGLxWZYmTsF,JQjNkD10xehK8bXUalY3EgZAVmvI,B9IV0PhzRUXa6s1xDTt2g = [],[],[],[]
	if fqzp8elOIU1a:
		UYat1jqNzCdDlWGuPF60T9i = 'mp4'
		for X1jnZDLVfkWdFsIPu4hle92b0,c1EdszLx3mkb8QYX9 in fqzp8elOIU1a:
			ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('tab-content quality" id="'+X1jnZDLVfkWdFsIPu4hle92b0+'".*?</div>.\s*</div>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
			OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
			JQjNkD10xehK8bXUalY3EgZAVmvI.append(OTKx7aVb2hdS16Wrweky4FXfIN0g9)
			B9IV0PhzRUXa6s1xDTt2g.append(c1EdszLx3mkb8QYX9)
	else:
		ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('class="qualities(.*?)<h3.*?>(.*?)<',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if not ZV5rRvabhxJ:
			tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'رسالة من المبرمج','لا يوجد ملف فيديو في هذا الرابط')
			return
		else:
			OTKx7aVb2hdS16Wrweky4FXfIN0g9,filename = ZV5rRvabhxJ[0]
			oVnfUpjMt8YCuzZNce2D = ['zip','rar','txt','pdf','htm','tar','iso','html']
			UYat1jqNzCdDlWGuPF60T9i = filename.rsplit('.',1)[1].strip(pldxivXC5wbTB2O8q)
			if UYat1jqNzCdDlWGuPF60T9i in oVnfUpjMt8YCuzZNce2D:
				tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'رسالة من المبرمج','الملف ليس فيديو ولا صوت')
				return
		JQjNkD10xehK8bXUalY3EgZAVmvI.append(OTKx7aVb2hdS16Wrweky4FXfIN0g9)
		B9IV0PhzRUXa6s1xDTt2g.append(b8Qe150xVaJsnDSv)
	for FbcUxvE17ewlWNBHgS8Jn in range(len(JQjNkD10xehK8bXUalY3EgZAVmvI)):
		tzdvaEpMHOCZLXDYg08T = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)".*?icon-(.*?)"',JQjNkD10xehK8bXUalY3EgZAVmvI[FbcUxvE17ewlWNBHgS8Jn],YYBlm36zd0Jst18LXwo4.DOTALL)
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,fTVkBY2Khrci1A6xmztHNXPgd9Dv in tzdvaEpMHOCZLXDYg08T:
			if 'torrent' in fTVkBY2Khrci1A6xmztHNXPgd9Dv: continue
			elif 'download' in fTVkBY2Khrci1A6xmztHNXPgd9Dv: type = 'download'
			elif 'play' in fTVkBY2Khrci1A6xmztHNXPgd9Dv: type = 'watch'
			else: type = 'unknown'
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3+'?named=__'+type+'____'+B9IV0PhzRUXa6s1xDTt2g[FbcUxvE17ewlWNBHgS8Jn]+'__akwam'
			KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
	import QNeGEq8sWn
	QNeGEq8sWn.nqu2GCT9gHAbpIPSFZz5(KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j,QQ8pvXNcBfVkP5rRJ7o,'video',url)
	return
def eszTQbMvkmRwCAxGDPdYJUi(url,filter):
	HiGtBb5m673JPE = ['section','category','year','rating']
	if '?' in url: url = url.split('?')[0]
	type,filter = filter.split('___',1)
	if filter==b8Qe150xVaJsnDSv: us8FE67ImlDBS,bxTQdyVe57Bh0P8sG = b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv
	else: us8FE67ImlDBS,bxTQdyVe57Bh0P8sG = filter.split('___')
	if type=='CATEGORIES':
		if HiGtBb5m673JPE[0]+'=' not in us8FE67ImlDBS: Z8s0Lov2UiWF1qGjO = HiGtBb5m673JPE[0]
		for FbcUxvE17ewlWNBHgS8Jn in range(len(HiGtBb5m673JPE[0:-1])):
			if HiGtBb5m673JPE[FbcUxvE17ewlWNBHgS8Jn]+'=' in us8FE67ImlDBS: Z8s0Lov2UiWF1qGjO = HiGtBb5m673JPE[FbcUxvE17ewlWNBHgS8Jn+1]
		x5gCnOb9wjSPit6sVclHNZIkFyD0 = us8FE67ImlDBS+'&'+Z8s0Lov2UiWF1qGjO+'=0'
		XFJqUiePG7aSf0N = bxTQdyVe57Bh0P8sG+'&'+Z8s0Lov2UiWF1qGjO+'=0'
		Dnkl4UdcKRILWi6m7TqYJh98vu = x5gCnOb9wjSPit6sVclHNZIkFyD0.strip('&')+'___'+XFJqUiePG7aSf0N.strip('&')
		JXAZh9EQjse2qirMa8DRSYvGLO0kgf = W57WXlwPhyrfVu6oij(bxTQdyVe57Bh0P8sG,'all')
		MUJCtfYVBLODrFbaZn = url+'?'+JXAZh9EQjse2qirMa8DRSYvGLO0kgf
	elif type=='FILTERS':
		pRfP0YvVnLJdukUHstQA8cm = W57WXlwPhyrfVu6oij(us8FE67ImlDBS,'modified_values')
		pRfP0YvVnLJdukUHstQA8cm = SgrGWuAHcLKBQMJetb9(pRfP0YvVnLJdukUHstQA8cm)
		if bxTQdyVe57Bh0P8sG!=b8Qe150xVaJsnDSv: bxTQdyVe57Bh0P8sG = W57WXlwPhyrfVu6oij(bxTQdyVe57Bh0P8sG,'all')
		if bxTQdyVe57Bh0P8sG==b8Qe150xVaJsnDSv: MUJCtfYVBLODrFbaZn = url
		else: MUJCtfYVBLODrFbaZn = url+'?'+bxTQdyVe57Bh0P8sG
		MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'أظهار قائمة الفيديو التي تم اختيارها',MUJCtfYVBLODrFbaZn,241,b8Qe150xVaJsnDSv,'1')
		MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+' [[   '+pRfP0YvVnLJdukUHstQA8cm+'   ]]',MUJCtfYVBLODrFbaZn,241,b8Qe150xVaJsnDSv,'1')
		MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+' ===== ===== ===== '+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999)
	jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(Q49IsrlSuYRAVbGKhwdckLDOetF2PZ,url,b8Qe150xVaJsnDSv,headers,True,'AKWAM-FILTERS_MENU-1st')
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('<form id(.*?)</form>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
	RYqsiFGfj07T2VKXrx3y6Hb = YYBlm36zd0Jst18LXwo4.findall('<select.*?name="(.*?)".*?">(.*?)<(.*?)</select>',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	dict = {}
	for BnHr3VSlN5cMhZ7miAfGLovdbQJWa,name,OTKx7aVb2hdS16Wrweky4FXfIN0g9 in RYqsiFGfj07T2VKXrx3y6Hb:
		items = YYBlm36zd0Jst18LXwo4.findall('<option(.*?)>(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		if '=' not in MUJCtfYVBLODrFbaZn: MUJCtfYVBLODrFbaZn = url
		if type=='CATEGORIES':
			if Z8s0Lov2UiWF1qGjO!=BnHr3VSlN5cMhZ7miAfGLovdbQJWa: continue
			elif len(items)<=1:
				if BnHr3VSlN5cMhZ7miAfGLovdbQJWa==HiGtBb5m673JPE[-1]: Je4TwC30iOG5DLKWAtbYvhs(MUJCtfYVBLODrFbaZn)
				else: eszTQbMvkmRwCAxGDPdYJUi(MUJCtfYVBLODrFbaZn,'CATEGORIES___'+Dnkl4UdcKRILWi6m7TqYJh98vu)
				return
			else:
				if BnHr3VSlN5cMhZ7miAfGLovdbQJWa==HiGtBb5m673JPE[-1]: MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'الجميع',MUJCtfYVBLODrFbaZn,241,b8Qe150xVaJsnDSv,'1')
				else: MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'الجميع',MUJCtfYVBLODrFbaZn,245,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,Dnkl4UdcKRILWi6m7TqYJh98vu)
		elif type=='FILTERS':
			x5gCnOb9wjSPit6sVclHNZIkFyD0 = us8FE67ImlDBS+'&'+BnHr3VSlN5cMhZ7miAfGLovdbQJWa+'=0'
			XFJqUiePG7aSf0N = bxTQdyVe57Bh0P8sG+'&'+BnHr3VSlN5cMhZ7miAfGLovdbQJWa+'=0'
			Dnkl4UdcKRILWi6m7TqYJh98vu = x5gCnOb9wjSPit6sVclHNZIkFyD0+'___'+XFJqUiePG7aSf0N
			MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'الجميع : '+name,MUJCtfYVBLODrFbaZn,244,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,Dnkl4UdcKRILWi6m7TqYJh98vu)
		dict[BnHr3VSlN5cMhZ7miAfGLovdbQJWa] = {}
		for Y8aiFZsLKw,Ny03TjaY7bBxWwm2GI in items:
			if Ny03TjaY7bBxWwm2GI in v1vJEhoNQBVPkjG: continue
			if 'value' not in Y8aiFZsLKw: Y8aiFZsLKw = Ny03TjaY7bBxWwm2GI
			else: Y8aiFZsLKw = YYBlm36zd0Jst18LXwo4.findall('"(.*?)"',Y8aiFZsLKw,YYBlm36zd0Jst18LXwo4.DOTALL)[0]
			dict[BnHr3VSlN5cMhZ7miAfGLovdbQJWa][Y8aiFZsLKw] = Ny03TjaY7bBxWwm2GI
			x5gCnOb9wjSPit6sVclHNZIkFyD0 = us8FE67ImlDBS+'&'+BnHr3VSlN5cMhZ7miAfGLovdbQJWa+'='+Ny03TjaY7bBxWwm2GI
			XFJqUiePG7aSf0N = bxTQdyVe57Bh0P8sG+'&'+BnHr3VSlN5cMhZ7miAfGLovdbQJWa+'='+Y8aiFZsLKw
			NHEdmMD3qPj4zay2nb5O8xKX = x5gCnOb9wjSPit6sVclHNZIkFyD0+'___'+XFJqUiePG7aSf0N
			title = Ny03TjaY7bBxWwm2GI+' : '#+dict[BnHr3VSlN5cMhZ7miAfGLovdbQJWa]['0']
			title = Ny03TjaY7bBxWwm2GI+' : '+name
			if type=='FILTERS': MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,url,244,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,NHEdmMD3qPj4zay2nb5O8xKX)
			elif type=='CATEGORIES' and HiGtBb5m673JPE[-2]+'=' in us8FE67ImlDBS:
				JXAZh9EQjse2qirMa8DRSYvGLO0kgf = W57WXlwPhyrfVu6oij(XFJqUiePG7aSf0N,'all')
				GSh0nJxEXgZjd48u7mBwWOeafyAp5b = url+'?'+JXAZh9EQjse2qirMa8DRSYvGLO0kgf
				MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,GSh0nJxEXgZjd48u7mBwWOeafyAp5b,241,b8Qe150xVaJsnDSv,'1')
			else: MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,url,245,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,NHEdmMD3qPj4zay2nb5O8xKX)
	return
def W57WXlwPhyrfVu6oij(J6rINOCGlW5M4SXjgwc9U7,mode):
	J6rINOCGlW5M4SXjgwc9U7 = J6rINOCGlW5M4SXjgwc9U7.strip('&')
	hj1lf3cGzLMURVTKkBZmDoyix28 = {}
	if '=' in J6rINOCGlW5M4SXjgwc9U7:
		items = J6rINOCGlW5M4SXjgwc9U7.split('&')
		for tgoJCpq8KGrdaUSjsLh0FTxDRPfIAB in items:
			VRcGtBaO1xun,Y8aiFZsLKw = tgoJCpq8KGrdaUSjsLh0FTxDRPfIAB.split('=')
			hj1lf3cGzLMURVTKkBZmDoyix28[VRcGtBaO1xun] = Y8aiFZsLKw
	sBF1epSJZbIUAgM4hVLPD50 = b8Qe150xVaJsnDSv
	cEjiOo6IGCD2pAzJ4B9bkmXYT = ['section','category','rating','year','language','formats','quality']
	for key in cEjiOo6IGCD2pAzJ4B9bkmXYT:
		if key in list(hj1lf3cGzLMURVTKkBZmDoyix28.keys()): Y8aiFZsLKw = hj1lf3cGzLMURVTKkBZmDoyix28[key]
		else: Y8aiFZsLKw = '0'
		if mode=='modified_values' and Y8aiFZsLKw!='0': sBF1epSJZbIUAgM4hVLPD50 = sBF1epSJZbIUAgM4hVLPD50+' + '+Y8aiFZsLKw
		elif mode=='modified_filters' and Y8aiFZsLKw!='0': sBF1epSJZbIUAgM4hVLPD50 = sBF1epSJZbIUAgM4hVLPD50+'&'+key+'='+Y8aiFZsLKw
		elif mode=='all': sBF1epSJZbIUAgM4hVLPD50 = sBF1epSJZbIUAgM4hVLPD50+'&'+key+'='+Y8aiFZsLKw
	sBF1epSJZbIUAgM4hVLPD50 = sBF1epSJZbIUAgM4hVLPD50.strip(' + ')
	sBF1epSJZbIUAgM4hVLPD50 = sBF1epSJZbIUAgM4hVLPD50.strip('&')
	return sBF1epSJZbIUAgM4hVLPD50
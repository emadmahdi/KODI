# -*- coding: utf-8 -*-
from hIVCFnfxSO import *
QQ8pvXNcBfVkP5rRJ7o = 'SERIESTIME'
WbzmKSZiuOYrBN7oysJ2dUv = '_SRT_'
wQjs1XZ3AO24g8y9bEeoKMiGIu7 = nTHXJIiah2qK[QQ8pvXNcBfVkP5rRJ7o][0]
v1vJEhoNQBVPkjG = ['الرئيسية','يلا شوت']
def x8IFqMZeJj7suCR4AaGoNXfEHm(mode,url,text):
	if   mode==890: XXxlOLJ9KRjPH382WVCvr6n71 = Y72YmLgw4vqlHxTCkbeKSicasD()
	elif mode==891: XXxlOLJ9KRjPH382WVCvr6n71 = Je4TwC30iOG5DLKWAtbYvhs(url,text)
	elif mode==892: XXxlOLJ9KRjPH382WVCvr6n71 = Hkij627uCDJKyIM(url)
	elif mode==893: XXxlOLJ9KRjPH382WVCvr6n71 = jQ9zsEX2Hc(url)
	elif mode==899: XXxlOLJ9KRjPH382WVCvr6n71 = kstJfK6jHQWrXDSMRIGB7(text)
	else: XXxlOLJ9KRjPH382WVCvr6n71 = False
	return XXxlOLJ9KRjPH382WVCvr6n71
def Y72YmLgw4vqlHxTCkbeKSicasD():
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',wQjs1XZ3AO24g8y9bEeoKMiGIu7,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'SERIESTIME-MENU-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'بحث في الموقع',b8Qe150xVaJsnDSv,899,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'_REMEMBERRESULTS_')
	MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+' ===== ===== ===== '+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999)
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('"list-categories"(.*?)</u',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)".*?>(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
			if 'http' not in pcA1dzy7LXwGfMPg9mTkuh5tine3: pcA1dzy7LXwGfMPg9mTkuh5tine3 = wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/'+pcA1dzy7LXwGfMPg9mTkuh5tine3.lstrip('/')
			if title in v1vJEhoNQBVPkjG: continue
			MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,891)
	return
def Je4TwC30iOG5DLKWAtbYvhs(url,type=b8Qe150xVaJsnDSv):
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'SERIESTIME-TITLES-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('"home-content"(.*?)"footer"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = OTKx7aVb2hdS16Wrweky4FXfIN0g9.replace('"overlay"','"duration"><')
		items = YYBlm36zd0Jst18LXwo4.findall('"thumb".*?data-src="(.*?)".*?"duration">(.*?)<.*?href="(.*?)">(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		d3VSIefbHnvqiut = []
		for lvtGpMZHb9,D5taEr6hnuFCcRMpTq4wSoyQOivx,pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = HHbaVYqFRy6v0c(pcA1dzy7LXwGfMPg9mTkuh5tine3)
			title = title.strip(' ')
			title = pTP49ckGDYrofa2KxenumbH0(title)
			HHr42WSgBjAeU7TkQcVaL6yEJz8PF = YYBlm36zd0Jst18LXwo4.findall('(.*?) (الحلقة|حلقة).\d+',title,YYBlm36zd0Jst18LXwo4.DOTALL)
			if 'episodes' not in type and HHr42WSgBjAeU7TkQcVaL6yEJz8PF:
				title = '_MOD_' + HHr42WSgBjAeU7TkQcVaL6yEJz8PF[0][0]
				title = title.replace('اون لاين',b8Qe150xVaJsnDSv)
				if title not in d3VSIefbHnvqiut:
					MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,893,lvtGpMZHb9)
					d3VSIefbHnvqiut.append(title)
			else: MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,892,lvtGpMZHb9,D5taEr6hnuFCcRMpTq4wSoyQOivx)
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('''["']pagination["'](.*?)["']footer["']''',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ:
		type = 'episodes_pages' if 'episodes' in type else 'pages'
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)">(.*?)</a>',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
			title = pTP49ckGDYrofa2KxenumbH0(title)
			MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'صفحة '+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,891,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,type)
	else:
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = YYBlm36zd0Jst18LXwo4.findall('load-next-button" href="(.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if pcA1dzy7LXwGfMPg9mTkuh5tine3: MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'صفحة جديدة',pcA1dzy7LXwGfMPg9mTkuh5tine3[0],891,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,type)
	return
def jQ9zsEX2Hc(url):
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'SERIESTIME-SERIES-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('class="eplist"(.*?)</div>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		f0iybKmnzw6vZEd = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)" title="(.*?)"',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in f0iybKmnzw6vZEd:
			MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,892)
	else:
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = YYBlm36zd0Jst18LXwo4.findall('"category".*?href="(.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if pcA1dzy7LXwGfMPg9mTkuh5tine3:
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3[0]
			Je4TwC30iOG5DLKWAtbYvhs(pcA1dzy7LXwGfMPg9mTkuh5tine3,'episodes')
	return
def Hkij627uCDJKyIM(url):
	n92bB0YwDLqyadQRlmGW = []
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'SERIESTIME-PLAY-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	if 'hash=' in jLtdbeYiQHnf4SpU2MTly:
		TuUQ1Be2pEnLbDPJs97zC = YYBlm36zd0Jst18LXwo4.findall('hash=(.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		TuUQ1Be2pEnLbDPJs97zC = list(set(TuUQ1Be2pEnLbDPJs97zC))
		for EEZLmsCMxVl07kRfzAih in TuUQ1Be2pEnLbDPJs97zC:
			i6NFOTe0YVsgGBzXWQPtdEbc8 = []
			GGYbRJxlHWKpQ2ihCD = EEZLmsCMxVl07kRfzAih.split('__')
			for vSQ0ic3zrK9VU in GGYbRJxlHWKpQ2ihCD:
				try:
					vSQ0ic3zrK9VU = lnFeUkiZtQ7E1.b64decode(vSQ0ic3zrK9VU+'=')
					if i1thmHk7AZquD4cM0fnp62: vSQ0ic3zrK9VU = vSQ0ic3zrK9VU.decode(OVauxZzLI10vcXT74K)
					i6NFOTe0YVsgGBzXWQPtdEbc8.append(vSQ0ic3zrK9VU)
				except: pass
			tzdvaEpMHOCZLXDYg08T = '>'.join(i6NFOTe0YVsgGBzXWQPtdEbc8)
			tzdvaEpMHOCZLXDYg08T = tzdvaEpMHOCZLXDYg08T.splitlines()
			for pcA1dzy7LXwGfMPg9mTkuh5tine3 in tzdvaEpMHOCZLXDYg08T:
				if ' => ' in pcA1dzy7LXwGfMPg9mTkuh5tine3:
					title,pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3.split(' => ')
					pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3+'?named='+title+'__watch'
					n92bB0YwDLqyadQRlmGW.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
	elif 'post_id' in jLtdbeYiQHnf4SpU2MTly:
		DlhJPky307SxBNGUL = YYBlm36zd0Jst18LXwo4.findall("post_id = '(.*?)'",jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if DlhJPky307SxBNGUL:
			DlhJPky307SxBNGUL = DlhJPky307SxBNGUL[0]
			headers = {'X-Requested-With':'XMLHttpRequest'}
			ZR1fdSsBJVeLUm9y7rit2CHTKau = wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/wp-admin/admin-ajax.php?action=video_info&post_id='+DlhJPky307SxBNGUL
			b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',ZR1fdSsBJVeLUm9y7rit2CHTKau,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'SERIESTIME-PLAY-2nd')
			VbpwiDIrf2esHxq6jMdomvEXG3z = b3HKopTY9zLUyhJmt.content
			AJeZ8IKH4k5Bj0RfEaFV = YYBlm36zd0Jst18LXwo4.findall('"name":"(.*?)","src":"(.*?)"',VbpwiDIrf2esHxq6jMdomvEXG3z,YYBlm36zd0Jst18LXwo4.DOTALL)
			if not AJeZ8IKH4k5Bj0RfEaFV:
				AJeZ8IKH4k5Bj0RfEaFV = YYBlm36zd0Jst18LXwo4.findall('"src":"(.*?)"',VbpwiDIrf2esHxq6jMdomvEXG3z,YYBlm36zd0Jst18LXwo4.DOTALL)
				if AJeZ8IKH4k5Bj0RfEaFV:
					mywYMLAn2hWCvISgs5V7EqxadPRe = ['']*len(AJeZ8IKH4k5Bj0RfEaFV)
					AJeZ8IKH4k5Bj0RfEaFV = list(zip(mywYMLAn2hWCvISgs5V7EqxadPRe,AJeZ8IKH4k5Bj0RfEaFV))
			for name,pcA1dzy7LXwGfMPg9mTkuh5tine3 in AJeZ8IKH4k5Bj0RfEaFV:
				pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3.replace('\\/','/')
				pcA1dzy7LXwGfMPg9mTkuh5tine3 = HHbaVYqFRy6v0c(pcA1dzy7LXwGfMPg9mTkuh5tine3)
				n92bB0YwDLqyadQRlmGW.append(pcA1dzy7LXwGfMPg9mTkuh5tine3+'?named='+name+'__watch')
	import QNeGEq8sWn
	QNeGEq8sWn.nqu2GCT9gHAbpIPSFZz5(n92bB0YwDLqyadQRlmGW,QQ8pvXNcBfVkP5rRJ7o,'video',url)
	return
def kstJfK6jHQWrXDSMRIGB7(search):
	search,v7Rxw52Z4X0,showDialogs = JimhUH0SEf6w(search)
	if search==b8Qe150xVaJsnDSv: search = FT2oXWtPQpVGuexmLqKN3srdzYn()
	if search==b8Qe150xVaJsnDSv: return
	search = search.replace(pldxivXC5wbTB2O8q,'+')
	url = wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/?s='+search
	Je4TwC30iOG5DLKWAtbYvhs(url,'search')
	return
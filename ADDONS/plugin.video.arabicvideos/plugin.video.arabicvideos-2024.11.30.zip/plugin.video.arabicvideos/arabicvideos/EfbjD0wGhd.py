# -*- coding: utf-8 -*-
import sys as Pft6y0LvwSh48iYg7b
MQBw2uYHcWbpxF8tKAV = Pft6y0LvwSh48iYg7b.version_info [0] == 2
myc93k4htNU67 = 2048
h8lCkw1d3LepDVuvfoicEXj5K6sPz = 7
def JanmRV2MtcH (VwngrDb8fEytv4kMTdQu95cIejsC):
	global oPFYqewitzj
	WBrAFcJPVXdS2UzxLEGM0omkD = ord (VwngrDb8fEytv4kMTdQu95cIejsC [-1])
	V13jmfpwhlcyCKMRLY5TiaG = VwngrDb8fEytv4kMTdQu95cIejsC [:-1]
	gyF4Uq9l1NQKCtT = WBrAFcJPVXdS2UzxLEGM0omkD % len (V13jmfpwhlcyCKMRLY5TiaG)
	BN5pdqozP2v9Ur1Swsia = V13jmfpwhlcyCKMRLY5TiaG [:gyF4Uq9l1NQKCtT] + V13jmfpwhlcyCKMRLY5TiaG [gyF4Uq9l1NQKCtT:]
	if MQBw2uYHcWbpxF8tKAV:
		D3MGYw1ceHQ4UbrNJSq = unicode () .join ([unichr (ord (bb1FgjciZqDzeQTBC2hplaPkmRIyUf) - myc93k4htNU67 - (Ni5bJjhpks6SfCc + WBrAFcJPVXdS2UzxLEGM0omkD) % h8lCkw1d3LepDVuvfoicEXj5K6sPz) for Ni5bJjhpks6SfCc, bb1FgjciZqDzeQTBC2hplaPkmRIyUf in enumerate (BN5pdqozP2v9Ur1Swsia)])
	else:
		D3MGYw1ceHQ4UbrNJSq = str () .join ([chr (ord (bb1FgjciZqDzeQTBC2hplaPkmRIyUf) - myc93k4htNU67 - (Ni5bJjhpks6SfCc + WBrAFcJPVXdS2UzxLEGM0omkD) % h8lCkw1d3LepDVuvfoicEXj5K6sPz) for Ni5bJjhpks6SfCc, bb1FgjciZqDzeQTBC2hplaPkmRIyUf in enumerate (BN5pdqozP2v9Ur1Swsia)])
	return eval (D3MGYw1ceHQ4UbrNJSq)
TYf7Dc06PQgy1vEV9,ubxGUTt1LraKhVZgpAP,Y2t8baH5GWikvOZ7NsCeq3TKrgMV=JanmRV2MtcH,JanmRV2MtcH,JanmRV2MtcH
BWNPxIG7vqdTy85pjHzUOrK3,Mmpr0o76iWJvz1kTtfgI8hES,QTUBCcehw6qPd4x=Y2t8baH5GWikvOZ7NsCeq3TKrgMV,ubxGUTt1LraKhVZgpAP,TYf7Dc06PQgy1vEV9
mQNonhS7CV2BXOv,HwB7ydlWVJeCtPuQ6MDE1RTYOo,uVQd103XyvUce2EBtzbYaC=QTUBCcehw6qPd4x,Mmpr0o76iWJvz1kTtfgI8hES,BWNPxIG7vqdTy85pjHzUOrK3
yST5AHEfvPmcWpwGuh2BJ,BmePGjS7FxK6kutUM,S0IlDPhBN3gMEUvnjRLXsYAc2Zf=uVQd103XyvUce2EBtzbYaC,HwB7ydlWVJeCtPuQ6MDE1RTYOo,mQNonhS7CV2BXOv
Xz3bA2PFENVCUtplu51,LAQD5wEkr18bUiGaYen3J,P0qdZI384LKleuo=S0IlDPhBN3gMEUvnjRLXsYAc2Zf,BmePGjS7FxK6kutUM,yST5AHEfvPmcWpwGuh2BJ
shC5qBRV2A0lZ,mmcNLrXtzfpyCkZlvK5VwG2gujh,m6hwdgP31a2zjN7lkpX=P0qdZI384LKleuo,LAQD5wEkr18bUiGaYen3J,Xz3bA2PFENVCUtplu51
IjZbnrBJmM2N,Nh0BWuiSndf,kke1PDGRBLuY8y=m6hwdgP31a2zjN7lkpX,mmcNLrXtzfpyCkZlvK5VwG2gujh,shC5qBRV2A0lZ
ddo23ZJtgcY,vvWwO3Tx2dAgcijrFXq,DYakr9g4PVU=kke1PDGRBLuY8y,Nh0BWuiSndf,IjZbnrBJmM2N
zI3ROAZtiUq42rE9WDST68,Dzs8qU2gQMcCSyRhiZn4TFbeGk,dDYUoKi6JFM23p=DYakr9g4PVU,vvWwO3Tx2dAgcijrFXq,ddo23ZJtgcY
QQdAXWBc2GPw,VFjQx6Is28KvzLOmMXtg4GqTwa3,TT8Mxv5Wq7nlC9IscdpPUY6=dDYUoKi6JFM23p,Dzs8qU2gQMcCSyRhiZn4TFbeGk,zI3ROAZtiUq42rE9WDST68
SbjiWeHLQPoazqwp3cODkd7YxVgn,UUkIBz1sgQ9WfNeG6trKXvu0,RRIHDFjoW9w7bSfVPhC=TT8Mxv5Wq7nlC9IscdpPUY6,VFjQx6Is28KvzLOmMXtg4GqTwa3,QQdAXWBc2GPw
from hIVCFnfxSO import *
QQ8pvXNcBfVkP5rRJ7o = TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠧࡓࡃࡑࡈࡔࡓࡓࠨᮞ")
WbzmKSZiuOYrBN7oysJ2dUv = uVQd103XyvUce2EBtzbYaC(u"ࠨࡡࡏࡗ࡙ࡥࠧᮟ")
nZHjx0b2qvhI8BVikRNEJD6mlK = NvHugPosYDzRJ
h76t0km4NE2jOSXc = vvWwO3Tx2dAgcijrFXq(u"࠶࠶ḋ")
def x8IFqMZeJj7suCR4AaGoNXfEHm(ZZtDTHnBXMz,url,pnmsJqCWIHVk2Y6xPvl9Q0Ez8r,NGQDwOCXx1BZmd9Huc,XXra5dzn8tcLOxYZIE7pPof49Hh):
	try: Bm6RlzFt7j10nr395yLAoDuiIaq = str(XXra5dzn8tcLOxYZIE7pPof49Hh[TYf7Dc06PQgy1vEV9(u"ࠩࡩࡳࡱࡪࡥࡳࠩᮠ")])
	except: Bm6RlzFt7j10nr395yLAoDuiIaq = b8Qe150xVaJsnDSv
	if   ZZtDTHnBXMz==zI3ROAZtiUq42rE9WDST68(u"࠷࠶࠱Ḍ"): XXxlOLJ9KRjPH382WVCvr6n71 = Y72YmLgw4vqlHxTCkbeKSicasD()
	elif ZZtDTHnBXMz==HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"࠱࠷࠳ḍ"): XXxlOLJ9KRjPH382WVCvr6n71 = rEVJhGQvyk061TPNAYcsIdD(pnmsJqCWIHVk2Y6xPvl9Q0Ez8r)
	elif ZZtDTHnBXMz==SbjiWeHLQPoazqwp3cODkd7YxVgn(u"࠲࠸࠵Ḏ"): XXxlOLJ9KRjPH382WVCvr6n71 = DrSlA2gw8fQB1kmV(pnmsJqCWIHVk2Y6xPvl9Q0Ez8r,SbjiWeHLQPoazqwp3cODkd7YxVgn(u"࠲࠸࠵Ḏ"))
	elif ZZtDTHnBXMz==LAQD5wEkr18bUiGaYen3J(u"࠳࠹࠷ḏ"): XXxlOLJ9KRjPH382WVCvr6n71 = DrSlA2gw8fQB1kmV(pnmsJqCWIHVk2Y6xPvl9Q0Ez8r,LAQD5wEkr18bUiGaYen3J(u"࠳࠹࠷ḏ"))
	elif ZZtDTHnBXMz==HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"࠴࠺࠹Ḑ"): XXxlOLJ9KRjPH382WVCvr6n71 = aP9sO7CMmyXZ3v(pnmsJqCWIHVk2Y6xPvl9Q0Ez8r)
	elif ZZtDTHnBXMz==m6hwdgP31a2zjN7lkpX(u"࠵࠻࠻ḑ"): XXxlOLJ9KRjPH382WVCvr6n71 = HeW7omDltbEghRIu(url,pnmsJqCWIHVk2Y6xPvl9Q0Ez8r)
	elif ZZtDTHnBXMz==S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"࠶࠼࠶Ḓ"): XXxlOLJ9KRjPH382WVCvr6n71 = ee6XVSAhPap2do31mrFZsGWTLY(url,pnmsJqCWIHVk2Y6xPvl9Q0Ez8r)
	elif ZZtDTHnBXMz==BmePGjS7FxK6kutUM(u"࠷࠶࠸ḓ"): XXxlOLJ9KRjPH382WVCvr6n71 = XIo0nOJVGsRrZ2SMNP718xwWkH4hl(url,pnmsJqCWIHVk2Y6xPvl9Q0Ez8r)
	elif ZZtDTHnBXMz==BmePGjS7FxK6kutUM(u"࠱࠷࠺Ḕ"): XXxlOLJ9KRjPH382WVCvr6n71 = SKvnJrtwe4xBoY38VE9lUjX(url,pnmsJqCWIHVk2Y6xPvl9Q0Ez8r)
	elif ZZtDTHnBXMz==IjZbnrBJmM2N(u"࠸࠸࠴ḕ"): XXxlOLJ9KRjPH382WVCvr6n71 = iLNQ9jDFRm4vWy5qCTp0()
	elif ZZtDTHnBXMz==Xz3bA2PFENVCUtplu51(u"࠹࠹࠶Ḗ"): XXxlOLJ9KRjPH382WVCvr6n71 = Hi4royQ6d5YU()
	elif ZZtDTHnBXMz==IjZbnrBJmM2N(u"࠺࠺࠸ḗ"): XXxlOLJ9KRjPH382WVCvr6n71 = qBykIPzlXcL(Bm6RlzFt7j10nr395yLAoDuiIaq,pnmsJqCWIHVk2Y6xPvl9Q0Ez8r,NGQDwOCXx1BZmd9Huc)
	elif ZZtDTHnBXMz==vvWwO3Tx2dAgcijrFXq(u"࠻࠻࠺Ḙ"): XXxlOLJ9KRjPH382WVCvr6n71 = eoJd2Ny3EQpztTF9W8ACHDZijlr(Bm6RlzFt7j10nr395yLAoDuiIaq,pnmsJqCWIHVk2Y6xPvl9Q0Ez8r)
	elif ZZtDTHnBXMz==ubxGUTt1LraKhVZgpAP(u"࠼࠼࠵ḙ"): XXxlOLJ9KRjPH382WVCvr6n71 = ojyd3swIQnm0aHr2DTFgEv(Bm6RlzFt7j10nr395yLAoDuiIaq,pnmsJqCWIHVk2Y6xPvl9Q0Ez8r)
	else: XXxlOLJ9KRjPH382WVCvr6n71 = shC5qBRV2A0lZ(u"ࡉࡥࡱࡹࡥṲ")
	return XXxlOLJ9KRjPH382WVCvr6n71
def Y72YmLgw4vqlHxTCkbeKSicasD():
	MQtuaShrKTbdZFJ5nsR7D(ddo23ZJtgcY(u"ࠪࡪࡴࡲࡤࡦࡴࠪᮡ"),Mmpr0o76iWJvz1kTtfgI8hES(u"ࠫ็์่ศฬࠣฮ้็า๋๊้ࠤ฾ฺ่ศศํอࠬᮢ"),b8Qe150xVaJsnDSv,Mmpr0o76iWJvz1kTtfgI8hES(u"࠷࠶࠲Ḛ"),b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,shC5qBRV2A0lZ(u"ࠬࡥࡌࡊࡘࡈࡘ࡛ࡥ࡟ࡓࡃࡑࡈࡔࡓ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᮣ"))
	MQtuaShrKTbdZFJ5nsR7D(QTUBCcehw6qPd4x(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᮤ"),BmePGjS7FxK6kutUM(u"ࠧใี่ࠤ฾ฺ่ศศํࠫᮥ"),b8Qe150xVaJsnDSv,IjZbnrBJmM2N(u"࠱࠷࠴ḛ"),b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,vvWwO3Tx2dAgcijrFXq(u"ࠨࡡࡖࡍ࡙ࡋࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᮦ"))
	MQtuaShrKTbdZFJ5nsR7D(S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠩࡩࡳࡱࡪࡥࡳࠩᮧ"),P0qdZI384LKleuo(u"ࠪๅ๏ี๊้้สฮࠥ฿ิ้ษษ๎ฮ࠭ᮨ"),b8Qe150xVaJsnDSv,SbjiWeHLQPoazqwp3cODkd7YxVgn(u"࠲࠸࠶Ḝ"),b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠫࡤ࡙ࡉࡕࡇࡖࡣࡤࡘࡁࡏࡆࡒࡑࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᮩ"))
	MQtuaShrKTbdZFJ5nsR7D(Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠬ࡬࡯࡭ࡦࡨࡶ᮪ࠬ"),S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"࠭แ๋ัํ์์อสࠡสะฯࠥ฿ิ้ษษ๎᮫ࠬ"),b8Qe150xVaJsnDSv,Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"࠳࠹࠸ḝ"),b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠧࡠࡕࡌࡘࡊ࡙࡟ࡠࡔࡄࡒࡉࡕࡍࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᮬ"))
	MQtuaShrKTbdZFJ5nsR7D(IjZbnrBJmM2N(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᮭ"),HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠩไ๎ิ๐่่ษอࠤ฾ฺ่ศศํอ๋ࠥๆࠡไึ้ࠬᮮ"),b8Qe150xVaJsnDSv,vvWwO3Tx2dAgcijrFXq(u"࠺࠺࠸Ḟ"),b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,BmePGjS7FxK6kutUM(u"ࠪࡣࡘࡏࡔࡆࡕࡢࡣࡗࡇࡎࡅࡑࡐࡣࠬᮯ"))
	MQtuaShrKTbdZFJ5nsR7D(BmePGjS7FxK6kutUM(u"ࠫࡱ࡯࡮࡬ࠩ᮰"),rC3Tlno96KjLDIvBaSWUbR8+BmePGjS7FxK6kutUM(u"ࠬࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫ᮱")+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,QTUBCcehw6qPd4x(u"࠽࠾࠿࠹ḟ"))
	MQtuaShrKTbdZFJ5nsR7D(IjZbnrBJmM2N(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭᮲"),ubxGUTt1LraKhVZgpAP(u"ࠧใ่๋หฯࠦࡍ࠴ࡗࠣ฽ู๎วว์ฬࠫ᮳"),b8Qe150xVaJsnDSv,m6hwdgP31a2zjN7lkpX(u"࠶࠼࠳Ḡ"),b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,QTUBCcehw6qPd4x(u"ࠨࡡࡐ࠷࡚ࡥ࡟ࡍࡋ࡙ࡉࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ᮴"))
	MQtuaShrKTbdZFJ5nsR7D(Xz3bA2PFENVCUtplu51(u"ࠩࡩࡳࡱࡪࡥࡳࠩ᮵"),shC5qBRV2A0lZ(u"ࠪๅ๏ี๊้้สฮࠥࡓ࠳ࡖࠢ฼ุํอฦ๋หࠪ᮶"),b8Qe150xVaJsnDSv,shC5qBRV2A0lZ(u"࠷࠶࠴ḡ"),b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,TYf7Dc06PQgy1vEV9(u"ࠫࡤࡓ࠳ࡖࡡࡢ࡚ࡔࡊ࡟ࡠࡔࡄࡒࡉࡕࡍࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ᮷"))
	MQtuaShrKTbdZFJ5nsR7D(Mmpr0o76iWJvz1kTtfgI8hES(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ᮸"),IjZbnrBJmM2N(u"࠭โิ็ࠣๆ๋๎วหࠢࡐ࠷ู࡚ࠦี๊สส๏࠭᮹"),b8Qe150xVaJsnDSv,BWNPxIG7vqdTy85pjHzUOrK3(u"࠱࠷࠴Ḣ"),b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠧࡠࡏ࠶࡙ࡤࡥࡌࡊࡘࡈࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᮺ"))
	MQtuaShrKTbdZFJ5nsR7D(RRIHDFjoW9w7bSfVPhC(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᮻ"),Nh0BWuiSndf(u"ࠩๅื๊ࠦแ๋ัํ์ࠥࡓ࠳ࡖࠢ฼ุํอฦ๋ࠩᮼ"),b8Qe150xVaJsnDSv,P0qdZI384LKleuo(u"࠲࠸࠵ḣ"),b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,shC5qBRV2A0lZ(u"ࠪࡣࡒ࠹ࡕࡠࡡ࡙ࡓࡉࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᮽ"))
	MQtuaShrKTbdZFJ5nsR7D(yST5AHEfvPmcWpwGuh2BJ(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᮾ"),Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠬ็๊ะ์๋๋ฬะࠠࡎ࠵ࡘࠤอำหࠡ฻ื์ฬฬ๊ࠨᮿ"),b8Qe150xVaJsnDSv,SbjiWeHLQPoazqwp3cODkd7YxVgn(u"࠳࠹࠸Ḥ"),b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,BWNPxIG7vqdTy85pjHzUOrK3(u"࠭࡟ࡎ࠵ࡘࡣࡤࡘࡁࡏࡆࡒࡑࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᯀ"))
	MQtuaShrKTbdZFJ5nsR7D(mQNonhS7CV2BXOv(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᯁ"),RRIHDFjoW9w7bSfVPhC(u"ࠨใํำ๏๎็ศฬࠣࡑ࠸ฺ࡛ࠠึ๋หห๐ษࠡ็้ࠤ็ูๅࠨᯂ"),b8Qe150xVaJsnDSv,UUkIBz1sgQ9WfNeG6trKXvu0(u"࠺࠺࠺ḥ"),b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,shC5qBRV2A0lZ(u"ࠩࡢࡑ࠸࡛࡟ࡠࡔࡄࡒࡉࡕࡍࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᯃ"))
	MQtuaShrKTbdZFJ5nsR7D(QTUBCcehw6qPd4x(u"ࠪࡰ࡮ࡴ࡫ࠨᯄ"),rC3Tlno96KjLDIvBaSWUbR8+zI3ROAZtiUq42rE9WDST68(u"ࠫࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࠪᯅ")+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"࠽࠾࠿࠹Ḧ"))
	MQtuaShrKTbdZFJ5nsR7D(S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᯆ"),TYf7Dc06PQgy1vEV9(u"࠭โ็๊สฮࠥࡏࡐࡕࡘࠣ฽ู๎วว์ฬࠫᯇ"),b8Qe150xVaJsnDSv,IjZbnrBJmM2N(u"࠶࠼࠳ḧ"),b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,ddo23ZJtgcY(u"ࠧࡠࡋࡓࡘ࡛ࡥ࡟ࡍࡋ࡙ࡉࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᯈ"))
	MQtuaShrKTbdZFJ5nsR7D(kke1PDGRBLuY8y(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᯉ"),dDYUoKi6JFM23p(u"ࠩไ๎ิ๐่่ษอࠤࡎࡖࡔࡗࠢ฼ุํอฦ๋หࠪᯊ"),b8Qe150xVaJsnDSv,IjZbnrBJmM2N(u"࠷࠶࠴Ḩ"),b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠪࡣࡎࡖࡔࡗࡡࡢ࡚ࡔࡊ࡟ࡠࡔࡄࡒࡉࡕࡍࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᯋ"))
	MQtuaShrKTbdZFJ5nsR7D(ddo23ZJtgcY(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᯌ"),Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"่ࠬำๆࠢๅ๊ํอสࠡࡋࡓࡘู࡛ࠦี๊สส๏࠭ᯍ"),b8Qe150xVaJsnDSv,kke1PDGRBLuY8y(u"࠱࠷࠴ḩ"),b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,TYf7Dc06PQgy1vEV9(u"࠭࡟ࡊࡒࡗ࡚ࡤࡥࡌࡊࡘࡈࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᯎ"))
	MQtuaShrKTbdZFJ5nsR7D(RRIHDFjoW9w7bSfVPhC(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᯏ"),Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠨไึ้ࠥ็๊ะ์๋ࠤࡎࡖࡔࡗࠢ฼ุํอฦ๋ࠩᯐ"),b8Qe150xVaJsnDSv,TYf7Dc06PQgy1vEV9(u"࠲࠸࠵Ḫ"),b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,QQdAXWBc2GPw(u"ࠩࡢࡍࡕ࡚ࡖࡠࡡ࡙ࡓࡉࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᯑ"))
	MQtuaShrKTbdZFJ5nsR7D(Nh0BWuiSndf(u"ࠪࡪࡴࡲࡤࡦࡴࠪᯒ"),Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠫๆ๐ฯ๋๊๊หฯࠦࡉࡑࡖ࡙ࠤอำหࠡ฻ื์ฬฬ๊ࠨᯓ"),b8Qe150xVaJsnDSv,VFjQx6Is28KvzLOmMXtg4GqTwa3(u"࠳࠹࠸ḫ"),b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,Xz3bA2PFENVCUtplu51(u"ࠬࡥࡉࡑࡖ࡙ࡣࡤࡘࡁࡏࡆࡒࡑࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᯔ"))
	MQtuaShrKTbdZFJ5nsR7D(IjZbnrBJmM2N(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᯕ"),LAQD5wEkr18bUiGaYen3J(u"ࠧโ์า๎ํํวหࠢࡌࡔ࡙࡜ฺࠠึ๋หห๐ษࠡ็้ࠤ็ูๅࠨᯖ"),b8Qe150xVaJsnDSv,kke1PDGRBLuY8y(u"࠺࠺࠹Ḭ"),b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,RRIHDFjoW9w7bSfVPhC(u"ࠨࡡࡌࡔ࡙࡜࡟ࡠࡔࡄࡒࡉࡕࡍࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᯗ"))
	return
def iLNQ9jDFRm4vWy5qCTp0():
	MQtuaShrKTbdZFJ5nsR7D(SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠩࡩࡳࡱࡪࡥࡳࠩᯘ"),BWNPxIG7vqdTy85pjHzUOrK3(u"ࠪࡣࡎࡖࡔࡠࠩᯙ")+Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠫๆ๐ฯ๋๊๊หฯࠦฬๆ์฼ࠤࡎࡖࡔࡗࠩᯚ"),b8Qe150xVaJsnDSv,Mmpr0o76iWJvz1kTtfgI8hES(u"࠻࠻࠺ḭ"))
	MQtuaShrKTbdZFJ5nsR7D(LAQD5wEkr18bUiGaYen3J(u"ࠬࡲࡩ࡯࡭ࠪᯛ"),rC3Tlno96KjLDIvBaSWUbR8+yST5AHEfvPmcWpwGuh2BJ(u"࠭࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫᯜ")+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,kke1PDGRBLuY8y(u"࠾࠿࠹࠺Ḯ"))
	for Bm6RlzFt7j10nr395yLAoDuiIaq in range(qHYIWnOZLPkrQU,PINQnUL6h3XA9at+qHYIWnOZLPkrQU):
		WbzmKSZiuOYrBN7oysJ2dUv = LAQD5wEkr18bUiGaYen3J(u"ࠧࡠࡋࡓࠫᯝ")+str(Bm6RlzFt7j10nr395yLAoDuiIaq)+SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠨࡡࠪᯞ")
		MQtuaShrKTbdZFJ5nsR7D(SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠩࡩࡳࡱࡪࡥࡳࠩᯟ"),WbzmKSZiuOYrBN7oysJ2dUv+Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠪࠤๆ๐ฯ๋๊๊หฯࠦๅอๆาࠤࠬᯠ")+iP9ZMSrYOJQhB73CN2yj4Kg1p6V5aT[Bm6RlzFt7j10nr395yLAoDuiIaq],b8Qe150xVaJsnDSv,Nh0BWuiSndf(u"࠽࠶࠵ḯ"),b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,{RRIHDFjoW9w7bSfVPhC(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᯡ"):Bm6RlzFt7j10nr395yLAoDuiIaq})
	return
def Hi4royQ6d5YU():
	MQtuaShrKTbdZFJ5nsR7D(ddo23ZJtgcY(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᯢ"),DYakr9g4PVU(u"࠭࡟ࡎ࠵ࡘࡣࠬᯣ")+TYf7Dc06PQgy1vEV9(u"ࠧโ์า๎ํํวหࠢฯ้๏฿ࠠࡎ࠵ࡘࠫᯤ"),b8Qe150xVaJsnDSv,P0qdZI384LKleuo(u"࠷࠷࠷Ḱ"))
	MQtuaShrKTbdZFJ5nsR7D(DYakr9g4PVU(u"ࠨ࡮࡬ࡲࡰ࠭ᯥ"),rC3Tlno96KjLDIvBaSWUbR8+LAQD5wEkr18bUiGaYen3J(u"ࠩࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂ᯦ࠦࠧ")+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,m6hwdgP31a2zjN7lkpX(u"࠺࠻࠼࠽ḱ"))
	for Bm6RlzFt7j10nr395yLAoDuiIaq in range(qHYIWnOZLPkrQU,PINQnUL6h3XA9at+qHYIWnOZLPkrQU):
		WbzmKSZiuOYrBN7oysJ2dUv = BWNPxIG7vqdTy85pjHzUOrK3(u"ࠪࡣࡒ࡛ࠧᯧ")+str(Bm6RlzFt7j10nr395yLAoDuiIaq)+BmePGjS7FxK6kutUM(u"ࠫࡤ࠭ᯨ")
		MQtuaShrKTbdZFJ5nsR7D(kke1PDGRBLuY8y(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᯩ"),WbzmKSZiuOYrBN7oysJ2dUv+kke1PDGRBLuY8y(u"࠭ࠠโ์า๎ํํวห่ࠢะ้ีࠠࠨᯪ")+iP9ZMSrYOJQhB73CN2yj4Kg1p6V5aT[Bm6RlzFt7j10nr395yLAoDuiIaq],b8Qe150xVaJsnDSv,shC5qBRV2A0lZ(u"࠹࠹࠹Ḳ"),b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,{P0qdZI384LKleuo(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᯫ"):Bm6RlzFt7j10nr395yLAoDuiIaq})
	return
def IW5L9glTSf6wuCvQj(TFAmLfwypkzsP1UYCMr8c):
	global TTMjknVWrPgUcvJsmIN3LX4p,PUnDgIBQ3l
	drHgqFcWbNv82tVEhDMT5,Bgb2Tkp6fK0CGvWYUZFtAzr,bhNwipmnY26A83qIEyDt0jQTso = MMUq0NsIxei5bK(TFAmLfwypkzsP1UYCMr8c)
	try:
		if uVQd103XyvUce2EBtzbYaC(u"ࠨࡋࡉࡍࡑࡓࠧᯬ") in TFAmLfwypkzsP1UYCMr8c: drHgqFcWbNv82tVEhDMT5(TFAmLfwypkzsP1UYCMr8c)
		else: drHgqFcWbNv82tVEhDMT5()
		EEPjTRch3bKSOG = shC5qBRV2A0lZ(u"ࡊࡦࡲࡳࡦṳ")
	except:
		vvcDoAQJ2zCpBM6tfaKb()
		EEPjTRch3bKSOG = DYakr9g4PVU(u"࡙ࡸࡵࡦṴ")
	TFAmLfwypkzsP1UYCMr8c = OJ5kiNTSpIdCco0H(TFAmLfwypkzsP1UYCMr8c)
	if EEPjTRch3bKSOG:
		yicQV3gj4q(TFAmLfwypkzsP1UYCMr8c,S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠩไุ้ࠦไๅลึๅࠬᯭ"),wLQCTr5lqbsVYeAHdzfhZ1F=VFjQx6Is28KvzLOmMXtg4GqTwa3(u"࠵࠴࠵࠶ḳ"))
		TTMjknVWrPgUcvJsmIN3LX4p += qHYIWnOZLPkrQU
		PUnDgIBQ3l += pldxivXC5wbTB2O8q+TFAmLfwypkzsP1UYCMr8c
	else: yicQV3gj4q(TFAmLfwypkzsP1UYCMr8c,b8Qe150xVaJsnDSv,wLQCTr5lqbsVYeAHdzfhZ1F=Nh0BWuiSndf(u"࠵࠵࠶࠰Ḵ"))
	return
def tt5JWsFHp82aL(vyxM10tTBmr6POh3C85zJRcWpS=P0qdZI384LKleuo(u"࡚ࡲࡶࡧṵ")):
	global TTMjknVWrPgUcvJsmIN3LX4p,PUnDgIBQ3l,p2MSNUTiP4QaYJ
	if not vyxM10tTBmr6POh3C85zJRcWpS:
		p2MSNUTiP4QaYJ = SS2OK7hjLagvUAm(mshLJcKH1fv03yRnDOr4ZT,ddo23ZJtgcY(u"ࠪࡨ࡮ࡩࡴࠨᯮ"),IjZbnrBJmM2N(u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡓࡊࡖࡈࡗࠬᯯ"),mmcNLrXtzfpyCkZlvK5VwG2gujh(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡔࡋࡗࡉࡘࡥࡁࡍࡎࠪᯰ"))
		if p2MSNUTiP4QaYJ: return
	aVwGA2kFY6u4m = BjMmX1vNrnzSAf(UUkIBz1sgQ9WfNeG6trKXvu0(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ᯱ"),b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,zI3ROAZtiUq42rE9WDST68(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮ᯲ࠪ"),IjZbnrBJmM2N(u"ࠨๆๆ๎ࠥะๅๅศ๋ࠣีํࠠศๆๅหห๋ษࠡ࠰ࠣห้ฮั็ษ่ะࠥ๐อหษฯࠤศ์๋ࠠใะูࠥาๅ๋฻้ࠣํอโฺࠢส่ๆ๐ฯ๋๊ࠣห้ะ๊ࠡใํࠤฬ๊ศา่ส้ัࠦไไ์ࠣ๎ุะฮาฮ้๋ࠣํวࠡใๅ฻ࠥอไฤไึห๊ࠦวๅำษ๎ุ๐ษࠡ࠰ࠣฯ๊๊ࠦใ๊่ࠤฬ๊ศา่ส้ัࠦศฯิ้ࠤ์ึ็ࠡษ็ว็ูวๆࠢะฮ๎ࠦไศࠢอัฯอฬࠡล้ࠤฯ๋ไว้สࠤ๊ืษࠡลัี๎ࠦ࠮ࠡ฻่่๏ฯࠠๆๆษࠤัฺ๋๊ࠢส่ศ่ำศ็ࠣฮาะวอࠢ฼หิฯࠠฤไ็ࠤ๊์ࠠ࠴ࠢาๆฬฬโࠡ࠰๋้ࠣࠦสา์าࠤศ์ࠠหฮ่฽่ࠥวว็ฬࠤฬ๊รใีส้ࠥอไร่ࠣร᯳ࠬ"))
	if aVwGA2kFY6u4m!=qHYIWnOZLPkrQU: return
	PDanwWu4bFAhe3m(dDYUoKi6JFM23p(u"ࡆࡢ࡮ࡶࡩṶ"),dDYUoKi6JFM23p(u"ࡆࡢ࡮ࡶࡩṶ"),dDYUoKi6JFM23p(u"ࡆࡢ࡮ࡶࡩṶ"))
	gJ3QaKPuZ47x = GyjmfosC59Jub
	TTMjknVWrPgUcvJsmIN3LX4p,PUnDgIBQ3l,threads = LzYQg91SIxDeOGtCKd5,b8Qe150xVaJsnDSv,{}
	for TFAmLfwypkzsP1UYCMr8c in m0mjZVkpsdDGKByLtfTi1l4REYqUvM:
		wLQCTr5lqbsVYeAHdzfhZ1F.sleep(qHYIWnOZLPkrQU)
		threads[TFAmLfwypkzsP1UYCMr8c] = Ay1SMOzkx5CU3aGTL4Zf.Thread(target=IW5L9glTSf6wuCvQj,args=(TFAmLfwypkzsP1UYCMr8c,))
		threads[TFAmLfwypkzsP1UYCMr8c].start()
		if TTMjknVWrPgUcvJsmIN3LX4p>=h76t0km4NE2jOSXc: break
	else:
		for TFAmLfwypkzsP1UYCMr8c in list(threads.keys()): threads[TFAmLfwypkzsP1UYCMr8c].join()
	GyjmfosC59Jub[:] = gJ3QaKPuZ47x
	if TTMjknVWrPgUcvJsmIN3LX4p>=h76t0km4NE2jOSXc: tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,shC5qBRV2A0lZ(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ᯴"),LAQD5wEkr18bUiGaYen3J(u"่ࠪิ๐ใࠡ็ื็้ฯࠠโ์ࠣࠫ᯵")+str(TTMjknVWrPgUcvJsmIN3LX4p)+TT8Mxv5Wq7nlC9IscdpPUY6(u"๋่ࠫࠥศไ฼ࠤ๊์ࠠๆ๊สๆ฾ࠦวๅสิ๊ฬ๋ฬࠡ࠰࠱࠲ࠥ๎ำษส๊ห่ࠥฯࠡ์ๆ์ู๋ࠦะ็ࠣ์ั๎ฯࠡว้ฮึ์๊หࠢไ๎ࠥา็ศิๆࠤํํ๊࠻ࠩ᯶")+PUnDgIBQ3l)
	else:
		p2MSNUTiP4QaYJ = {}
		for TFAmLfwypkzsP1UYCMr8c in list(threads.keys()):
			try: mmEXtLheF8nZjKQG7u0 = Jlx4HMPfuYok8zCWwhESdA29F5s[TFAmLfwypkzsP1UYCMr8c]
			except: continue
			TFAmLfwypkzsP1UYCMr8c = TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠬࡥࡌࡔࡖࡢࠫ᯷")+OJ5kiNTSpIdCco0H(TFAmLfwypkzsP1UYCMr8c)
			for A60AIQZCYRzdhaeWfOtmrSUVoq2nN,c17XeRIH2gVh3px8sw,uuNDjbit4hOpx,ZZtDTHnBXMz,ChvkSxHr6QoKJg,EAlZ2zKn6uagcqtY3yBoMxDmSbOwk,pnmsJqCWIHVk2Y6xPvl9Q0Ez8r,czG0PxAmlw4vtWrH5eL3RubT,ZzHaCLyPtIk1iurbW in mmEXtLheF8nZjKQG7u0:
				if not c17XeRIH2gVh3px8sw: c17XeRIH2gVh3px8sw = S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"࠭࠮࠯࠰࠱ࠫ᯸")
				else:
					if c17XeRIH2gVh3px8sw.count(m6hwdgP31a2zjN7lkpX(u"ࠧࡠࠩ᯹"))>qHYIWnOZLPkrQU: c17XeRIH2gVh3px8sw = c17XeRIH2gVh3px8sw.split(RRIHDFjoW9w7bSfVPhC(u"ࠨࡡࠪ᯺"),IgQimel18t)[IgQimel18t]
					c17XeRIH2gVh3px8sw = c17XeRIH2gVh3px8sw.replace(yST5AHEfvPmcWpwGuh2BJ(u"ࠩࢣࠫ᯻"),b8Qe150xVaJsnDSv).replace(vvWwO3Tx2dAgcijrFXq(u"ࠪࠤࡍࡊࠧ᯼"),b8Qe150xVaJsnDSv).replace(uVQd103XyvUce2EBtzbYaC(u"ࠫࡍࡊࠠࠨ᯽"),b8Qe150xVaJsnDSv)
					c17XeRIH2gVh3px8sw = c17XeRIH2gVh3px8sw.replace(QQdAXWBc2GPw(u"ࠬๆࠧ᯾"),b8Qe150xVaJsnDSv).replace(QTUBCcehw6qPd4x(u"࠭ษࠨ᯿"),dDYUoKi6JFM23p(u"่ࠧࠩᰀ")).replace(BWNPxIG7vqdTy85pjHzUOrK3(u"ࠨฦࠪᰁ"),DYakr9g4PVU(u"๋ࠩࠫᰂ"))
					c17XeRIH2gVh3px8sw = c17XeRIH2gVh3px8sw.replace(QTUBCcehw6qPd4x(u"ࠪวࠬᰃ"),vvWwO3Tx2dAgcijrFXq(u"ࠫฬ࠭ᰄ")).replace(shC5qBRV2A0lZ(u"ࠬหࠧᰅ"),QQdAXWBc2GPw(u"࠭วࠨᰆ")).replace(yST5AHEfvPmcWpwGuh2BJ(u"ࠧรࠩᰇ"),LAQD5wEkr18bUiGaYen3J(u"ࠨษࠪᰈ"))
					c17XeRIH2gVh3px8sw = c17XeRIH2gVh3px8sw.replace(mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠩ็วࠬᰉ"),LAQD5wEkr18bUiGaYen3J(u"่ࠪฬ࠭ᰊ")).replace(mmcNLrXtzfpyCkZlvK5VwG2gujh(u"้ࠫหࠧᰋ"),BWNPxIG7vqdTy85pjHzUOrK3(u"๊ࠬวࠨᰌ")).replace(Xz3bA2PFENVCUtplu51(u"࠭ไรࠩᰍ"),QQdAXWBc2GPw(u"ࠧๅษࠪᰎ"))
					c17XeRIH2gVh3px8sw = c17XeRIH2gVh3px8sw.replace(zI3ROAZtiUq42rE9WDST68(u"ࠨ๐ࠪᰏ"),b8Qe150xVaJsnDSv).replace(TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠩ๎ࠫᰐ"),b8Qe150xVaJsnDSv).replace(TYf7Dc06PQgy1vEV9(u"ࠪ๓ࠬᰑ"),b8Qe150xVaJsnDSv).replace(vvWwO3Tx2dAgcijrFXq(u"ࠫ๑࠭ᰒ"),b8Qe150xVaJsnDSv)
					c17XeRIH2gVh3px8sw = c17XeRIH2gVh3px8sw.replace(mQNonhS7CV2BXOv(u"ࠬ๖ࠧᰓ"),b8Qe150xVaJsnDSv).replace(dDYUoKi6JFM23p(u"࠭ํࠨᰔ"),b8Qe150xVaJsnDSv).replace(DYakr9g4PVU(u"ࠧ๓ࠩᰕ"),b8Qe150xVaJsnDSv).replace(m6hwdgP31a2zjN7lkpX(u"ࠨ๓ࠪᰖ"),b8Qe150xVaJsnDSv)
					c17XeRIH2gVh3px8sw = c17XeRIH2gVh3px8sw.replace(ddo23ZJtgcY(u"ࠩࡿࠫᰗ"),b8Qe150xVaJsnDSv).replace(QTUBCcehw6qPd4x(u"ࠪࢂࠬᰘ"),b8Qe150xVaJsnDSv)
					c17XeRIH2gVh3px8sw = c17XeRIH2gVh3px8sw.replace(QQdAXWBc2GPw(u"ࠫฬ๎ๆࠡๆส๎๋࠭ᰙ"),b8Qe150xVaJsnDSv).replace(RRIHDFjoW9w7bSfVPhC(u"ู๊ࠬๆษ่ࠣฬ๐สࠨᰚ"),b8Qe150xVaJsnDSv)
					TkfUGEt2mzyFl8CHwquLo = [QTUBCcehw6qPd4x(u"࠭วๅ฻สฬࠬᰛ"),Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠧฯ์ส่ࠬᰜ"),QTUBCcehw6qPd4x(u"ࠨษ็ฬํ๋ࠧᰝ"),ddo23ZJtgcY(u"ࠩส่ฬ์ࠧᰞ"),zI3ROAZtiUq42rE9WDST68(u"ࠪห฼็วๅࠩᰟ"),ddo23ZJtgcY(u"ࠫาอไ๋้ࠪᰠ"),yST5AHEfvPmcWpwGuh2BJ(u"ࠬอไ฻ษีࠫᰡ"),BmePGjS7FxK6kutUM(u"࠭ีศๆะࠫᰢ"),S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠧศๆา๎๋࠭ᰣ"),m6hwdgP31a2zjN7lkpX(u"ࠨ็๋ห้๐ฯࠨᰤ"),Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠩส่฾อไๆࠩᰥ"),VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠪห฾๋วๅࠩᰦ")]
					if not any(vB1tbwXDzUanu in c17XeRIH2gVh3px8sw for vB1tbwXDzUanu in TkfUGEt2mzyFl8CHwquLo): c17XeRIH2gVh3px8sw = c17XeRIH2gVh3px8sw.replace(shC5qBRV2A0lZ(u"ࠫฬ๊ࠧᰧ"),b8Qe150xVaJsnDSv)
					c17XeRIH2gVh3px8sw = c17XeRIH2gVh3px8sw.replace(mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠬอฮา์ࠪᰨ"),yST5AHEfvPmcWpwGuh2BJ(u"࠭วฯำ์ࠫᰩ")).replace(UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠧศฮ้ฬ๎࠭ᰪ"),shC5qBRV2A0lZ(u"ࠨษฯ๊อ๐ࠧᰫ")).replace(Nh0BWuiSndf(u"ࠩ฼หห๊๊่ࠩᰬ"),TYf7Dc06PQgy1vEV9(u"ࠪ฽ฬฬไ๋ࠩᰭ"))
					c17XeRIH2gVh3px8sw = c17XeRIH2gVh3px8sw.replace(S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠫฬาๆษ์๊ࠫᰮ"),UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠬอฬ็สํࠫᰯ")).replace(SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ู࠭าสํ๋ࠬᰰ"),BmePGjS7FxK6kutUM(u"ฺࠧำห๎ࠬᰱ")).replace(yST5AHEfvPmcWpwGuh2BJ(u"ࠨำ๋้ฬ์ำ๋้ࠪᰲ"),LAQD5wEkr18bUiGaYen3J(u"ࠩิ์๊อๆิ์ࠪᰳ"))
					c17XeRIH2gVh3px8sw = c17XeRIH2gVh3px8sw.replace(RRIHDFjoW9w7bSfVPhC(u"ࠪ฾ึฮ๊่ࠩᰴ"),zI3ROAZtiUq42rE9WDST68(u"ࠫ฿ืศ๋ࠩᰵ")).replace(zI3ROAZtiUq42rE9WDST68(u"ࠬ๎ࠠๆี็ื้อสࠨᰶ"),Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"࠭ๅิๆึ่ฬะ᰷ࠧ")).replace(mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠧศ฼ส๊๎࠭᰸"),kke1PDGRBLuY8y(u"ࠨษ฽ห๋๐ࠧ᰹"))
					c17XeRIH2gVh3px8sw = c17XeRIH2gVh3px8sw.replace(Mmpr0o76iWJvz1kTtfgI8hES(u"ࠩอหึ๐ฮ๋ࠩ᰺"),zI3ROAZtiUq42rE9WDST68(u"ࠪฮฬื๊ฯࠩ᰻")).replace(vvWwO3Tx2dAgcijrFXq(u"ࠫำ๐วๅࠢ฼่๊๐ࠧ᰼"),BmePGjS7FxK6kutUM(u"ࠬิ๊ศๆࠪ᰽")).replace(zI3ROAZtiUq42rE9WDST68(u"࠭ๅ้ีํๆ๏ํࠧ᰾"),S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠧๆ๊ึ๎็๏ࠧ᰿"))
					c17XeRIH2gVh3px8sw = c17XeRIH2gVh3px8sw.replace(ubxGUTt1LraKhVZgpAP(u"ࠨ้้ำ๎࠭᱀"),yST5AHEfvPmcWpwGuh2BJ(u"๊๊ࠩิ๐ࠧ᱁")).replace(P0qdZI384LKleuo(u"๋๋ࠪี๊่ࠩ᱂"),kke1PDGRBLuY8y(u"ࠫ์์ฯ๋ࠩ᱃")).replace(S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠬ๎หศศๅ๎์࠭᱄"),VFjQx6Is28KvzLOmMXtg4GqTwa3(u"่࠭ฬษษๆ๏࠭᱅"))
					c17XeRIH2gVh3px8sw = c17XeRIH2gVh3px8sw.replace(yST5AHEfvPmcWpwGuh2BJ(u"ࠧหๆํๅื๐่็์๊ࠫ᱆"),mQNonhS7CV2BXOv(u"ࠨฬ็ๅื๐่็ࠩ᱇")).replace(SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠩอ่ๆุ๊้่ํ๋ࠬ᱈"),Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠪฮ้็า๋๊้ࠫ᱉")).replace(TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠫํࠦใาฬ๋๊ࠬ᱊"),kke1PDGRBLuY8y(u"ࠬ๎ใาฬ๋๊ࠬ᱋"))
					c17XeRIH2gVh3px8sw = c17XeRIH2gVh3px8sw.replace(TT8Mxv5Wq7nlC9IscdpPUY6(u"࠭วๅฯส่๏ํࠧ᱌"),yST5AHEfvPmcWpwGuh2BJ(u"ࠧฮษ็๎์࠭ᱍ")).replace(Mmpr0o76iWJvz1kTtfgI8hES(u"ࠨ็๋ื໑่๊ࠨᱎ"),QQdAXWBc2GPw(u"่ࠩ์ุ๐โ๊ࠩᱏ")).replace(BWNPxIG7vqdTy85pjHzUOrK3(u"ࠪห้อๆๆ์ࠪ᱐"),LAQD5wEkr18bUiGaYen3J(u"ࠫฬ์ๅ๋ࠩ᱑"))
					c17XeRIH2gVh3px8sw = c17XeRIH2gVh3px8sw.replace(ubxGUTt1LraKhVZgpAP(u"ࠬอไๆี็ื้อสࠨ᱒"),kke1PDGRBLuY8y(u"࠭ๅิๆึ่ฬะࠧ᱓")).replace(kke1PDGRBLuY8y(u"ࠧศๆหีฬ๋ฬࠨ᱔"),VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠨสิห๊าࠧ᱕")).replace(HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠩๆหึะ่็ࠩ᱖"),DYakr9g4PVU(u"ࠪ็ึะ่็ࠩ᱗"))
					c17XeRIH2gVh3px8sw = c17XeRIH2gVh3px8sw.replace(m6hwdgP31a2zjN7lkpX(u"ࠫาื่ษࠩ᱘"),Nh0BWuiSndf(u"ࠬำัษࠩ᱙")).replace(uVQd103XyvUce2EBtzbYaC(u"࠭วๅษ้หู๐ฯࠨᱚ"),TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠧศ่สุ๏ีࠧᱛ")).replace(P0qdZI384LKleuo(u"ࠨษึ๎ํ๐็ࠨᱜ"),S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠩสื๏๎๊ࠨᱝ"))
					c17XeRIH2gVh3px8sw = c17XeRIH2gVh3px8sw.replace(QTUBCcehw6qPd4x(u"ࠪ฽ึฮ้ࠨᱞ"),P0qdZI384LKleuo(u"ࠫ฾ืศ๋ࠩᱟ")).replace(TYf7Dc06PQgy1vEV9(u"ࠬะัไ๋ࠪᱠ"),kke1PDGRBLuY8y(u"࠭สาๅํࠫᱡ")).replace(kke1PDGRBLuY8y(u"ࠧหำๆ๎์࠭ᱢ"),UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠨฬิ็๏࠭ᱣ")).replace(dDYUoKi6JFM23p(u"ࠩส่๊฼วโࠩᱤ"),yST5AHEfvPmcWpwGuh2BJ(u"้ࠪ฻อแࠨᱥ"))
					c17XeRIH2gVh3px8sw = c17XeRIH2gVh3px8sw.replace(kke1PDGRBLuY8y(u"ࠫึ๐วื์ࠪᱦ"),yST5AHEfvPmcWpwGuh2BJ(u"ࠬื๊ศุฬࠫᱧ")).replace(m6hwdgP31a2zjN7lkpX(u"࠭ั๋ษู๋ࠬᱨ"),zI3ROAZtiUq42rE9WDST68(u"ࠧา์สฺฮ࠭ᱩ")).replace(RRIHDFjoW9w7bSfVPhC(u"ࠨษึ๎ํ๐็ࠨᱪ"),Nh0BWuiSndf(u"ࠩสื๏๎๊ࠨᱫ"))
					c17XeRIH2gVh3px8sw = c17XeRIH2gVh3px8sw.replace(mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠪ็ํ๋๊ะ๋ࠪᱬ"),ubxGUTt1LraKhVZgpAP(u"่ࠫ๎ๅ๋ัํࠫᱭ")).replace(S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"้่ࠬๆ์า๎์࠭ᱮ"),kke1PDGRBLuY8y(u"࠭ใ้็ํำ๏࠭ᱯ")).replace(RRIHDFjoW9w7bSfVPhC(u"ࠧศ่ํ้๏࠭ᱰ"),mQNonhS7CV2BXOv(u"ࠨษ้้๏࠭ᱱ"))
					c17XeRIH2gVh3px8sw = c17XeRIH2gVh3px8sw.replace(HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠩส๊๏๋๊ี่ࠪᱲ"),Nh0BWuiSndf(u"ࠪห๋๋๊ี่ࠪᱳ")).replace(UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠫฬ์ๅ๊ࠩᱴ"),DYakr9g4PVU(u"ࠬอๆๆ์ื๊ࠬᱵ")).replace(IjZbnrBJmM2N(u"࠭ว็็ํࠫᱶ"),Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠧศ่่๎ู์ࠧᱷ"))
					c17XeRIH2gVh3px8sw = c17XeRIH2gVh3px8sw.replace(RRIHDFjoW9w7bSfVPhC(u"ࠨษ้้๏ฺๆี่ࠪᱸ"),mQNonhS7CV2BXOv(u"ࠩส๊๊๐ิ็ࠩᱹ")).replace(IjZbnrBJmM2N(u"ࠪห้อๆๆ์ื๊ࠬᱺ"),Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠫฬ์ๅ๋ึ้ࠫᱻ")).replace(mQNonhS7CV2BXOv(u"ࠬอแๅษ่ࠤู๊ไิๆสฮࠬᱼ"),mmcNLrXtzfpyCkZlvK5VwG2gujh(u"࠭วโๆส้ࠥ๎ๅิๆึ่ฬะࠧᱽ"))
					c17XeRIH2gVh3px8sw = c17XeRIH2gVh3px8sw.replace(k5bCDErUSmv,pldxivXC5wbTB2O8q).strip(ubxGUTt1LraKhVZgpAP(u"ࠧ࠮ࠩ᱾")).strip(pldxivXC5wbTB2O8q)
				if c17XeRIH2gVh3px8sw not in list(p2MSNUTiP4QaYJ.keys()): p2MSNUTiP4QaYJ[c17XeRIH2gVh3px8sw] = {}
				p2MSNUTiP4QaYJ[c17XeRIH2gVh3px8sw][TFAmLfwypkzsP1UYCMr8c] = [A60AIQZCYRzdhaeWfOtmrSUVoq2nN,c17XeRIH2gVh3px8sw,uuNDjbit4hOpx,ZZtDTHnBXMz,ChvkSxHr6QoKJg,EAlZ2zKn6uagcqtY3yBoMxDmSbOwk,pnmsJqCWIHVk2Y6xPvl9Q0Ez8r,czG0PxAmlw4vtWrH5eL3RubT,ZzHaCLyPtIk1iurbW]
		PGudrhJF8iDkSq96XVHEQZYf5L(mshLJcKH1fv03yRnDOr4ZT,P0qdZI384LKleuo(u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡗࡎ࡚ࡅࡔࠩ᱿"),mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡘࡏࡔࡆࡕࡢࡅࡑࡒࠧᲀ"),p2MSNUTiP4QaYJ,t58tnzAgevxkoIOdMFbE2PsD64q0C9)
		tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ᲁ"),vvWwO3Tx2dAgcijrFXq(u"ࠫฯ๋ࠠอๆหࠤัฺ๋๊ࠢส่ศ่ำศ็ࠣห้๋ส้ใิอࠥ็๊ࠡษ็ฬึ์วๆฮࠪᲂ"))
	PDanwWu4bFAhe3m(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv)
	AKQaWIc0YCHGVnT()
	return
def mkVxqa8XjHOTID7MthNBl(Bm6RlzFt7j10nr395yLAoDuiIaq,SHk0ThDndgJW):
	XX8FguGmKp5DVB2Twifsc = QQdAXWBc2GPw(u"ࡇࡣ࡯ࡷࡪṷ")
	qqokExPK8XLUhsyl = GyjmfosC59Jub
	GyjmfosC59Jub[:] = []
	if XX8FguGmKp5DVB2Twifsc and VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠬࡥࡃࡓࡇࡄࡘࡊࡔࡅࡘࡡࠪᲃ") not in SHk0ThDndgJW:
		XXxlOLJ9KRjPH382WVCvr6n71 = SS2OK7hjLagvUAm(mshLJcKH1fv03yRnDOr4ZT,UUkIBz1sgQ9WfNeG6trKXvu0(u"࠭࡬ࡪࡵࡷࠫᲄ"),ubxGUTt1LraKhVZgpAP(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡌࡔ࡙࡜ࠧᲅ"),Xz3bA2PFENVCUtplu51(u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡍࡕ࡚ࡖࡠࠩᲆ")+Bm6RlzFt7j10nr395yLAoDuiIaq)
	elif S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠩࡢࡐࡎ࡜ࡅࡠࠩᲇ") not in SHk0ThDndgJW or TYf7Dc06PQgy1vEV9(u"ࠪࡣ࡛ࡕࡄࡠࠩᲈ") not in SHk0ThDndgJW:
		import CC4xSVuWXg
		A4gdSTQDP2FyBIVuba85RvYqKU = SbjiWeHLQPoazqwp3cODkd7YxVgn(u"้๊ࠫริใ่ࠣิ๐ใࠡ็ื็้ฯࠠโ์๋ࠣีอࠠศๆ่์็฿ࠠ࠯๋ࠢีุอไสࠢส่ำ฽รࠡๅส๊ࠥ็๊่ษࠣฮๆอี๋ๆࠣห้๋ิไๆฬࠤ࠳ࠦรัษࠣห้๋ิไๆฬࠤ้๐ำหࠢะะอࠦแอำหࠤสืำศๆ๋ࠣีํࠠศๆุ่่๊ษࠡว็ํࠥอไๆสิ้ัࠦๅ็ࠢๅหห๋ษࠡะา้ฬะࠠศๆหี๋อๅอࠩᲉ")
		if m6hwdgP31a2zjN7lkpX(u"ࠬࡥࡌࡊࡘࡈࡣࠬᲊ") not in SHk0ThDndgJW:
			try: CC4xSVuWXg.YhgBJAG0zwX5i(Bm6RlzFt7j10nr395yLAoDuiIaq,RRIHDFjoW9w7bSfVPhC(u"࠭ࡖࡐࡆࡢ࡙ࡓࡑࡎࡐ࡙ࡑࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬ᲋"),b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,SHk0ThDndgJW+Nh0BWuiSndf(u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ᲌"),Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࡈࡤࡰࡸ࡫Ṹ"))
			except: tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,dDYUoKi6JFM23p(u"ࠨ็๋ๆ฾ࠦเࡊࡒࡗ๊࡚ࠥไโ์า๎ํํวหࠩ᲍"),A4gdSTQDP2FyBIVuba85RvYqKU)
			try: CC4xSVuWXg.YhgBJAG0zwX5i(Bm6RlzFt7j10nr395yLAoDuiIaq,Nh0BWuiSndf(u"࡙ࠩࡓࡉࡥࡍࡐࡘࡌࡉࡘࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧ᲎"),b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,SHk0ThDndgJW+zI3ROAZtiUq42rE9WDST68(u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ᲏"),uVQd103XyvUce2EBtzbYaC(u"ࡉࡥࡱࡹࡥṹ"))
			except: tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,zI3ROAZtiUq42rE9WDST68(u"๊ࠫ๎โฺࠢใࡍࡕ࡚ࡖࠡๆ็ๅ๏ี๊้้สฮࠬᲐ"),A4gdSTQDP2FyBIVuba85RvYqKU)
			try: CC4xSVuWXg.YhgBJAG0zwX5i(Bm6RlzFt7j10nr395yLAoDuiIaq,mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠬ࡜ࡏࡅࡡࡖࡉࡗࡏࡅࡔࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪᲑ"),b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,SHk0ThDndgJW+LAQD5wEkr18bUiGaYen3J(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᲒ"),ddo23ZJtgcY(u"ࡊࡦࡲࡳࡦṺ"))
			except: tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,Xz3bA2PFENVCUtplu51(u"ࠧๆ๊ๅ฽ࠥๆࡉࡑࡖ࡙ࠤ้๊แ๋ัํ์์อสࠨᲓ"),A4gdSTQDP2FyBIVuba85RvYqKU)
		if UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠨࡡ࡙ࡓࡉࡥࠧᲔ") not in SHk0ThDndgJW:
			try: CC4xSVuWXg.YhgBJAG0zwX5i(Bm6RlzFt7j10nr395yLAoDuiIaq,QTUBCcehw6qPd4x(u"ࠩࡏࡍ࡛ࡋ࡟ࡖࡐࡎࡒࡔ࡝ࡎࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩᲕ"),b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,SHk0ThDndgJW+Nh0BWuiSndf(u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᲖ"),BmePGjS7FxK6kutUM(u"ࡋࡧ࡬ࡴࡧṻ"))
			except: tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,ubxGUTt1LraKhVZgpAP(u"๊ࠫ๎โฺࠢใࡍࡕ࡚ࡖࠡๆ็ๆ๋๎วหࠩᲗ"),A4gdSTQDP2FyBIVuba85RvYqKU)
			try: CC4xSVuWXg.YhgBJAG0zwX5i(Bm6RlzFt7j10nr395yLAoDuiIaq,yST5AHEfvPmcWpwGuh2BJ(u"ࠬࡒࡉࡗࡇࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫᲘ"),b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,SHk0ThDndgJW+uVQd103XyvUce2EBtzbYaC(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᲙ"),Mmpr0o76iWJvz1kTtfgI8hES(u"ࡌࡡ࡭ࡵࡨṼ"))
			except: tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠧๆ๊ๅ฽ࠥๆࡉࡑࡖ࡙ࠤ้๊โ็๊สฮࠬᲚ"),A4gdSTQDP2FyBIVuba85RvYqKU)
		XXxlOLJ9KRjPH382WVCvr6n71 = GyjmfosC59Jub
		if XX8FguGmKp5DVB2Twifsc: PGudrhJF8iDkSq96XVHEQZYf5L(mshLJcKH1fv03yRnDOr4ZT,RRIHDFjoW9w7bSfVPhC(u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡍࡕ࡚ࡖࠨᲛ"),VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡎࡖࡔࡗࡡࠪᲜ")+Bm6RlzFt7j10nr395yLAoDuiIaq,XXxlOLJ9KRjPH382WVCvr6n71,t58tnzAgevxkoIOdMFbE2PsD64q0C9)
	GyjmfosC59Jub[:] = qqokExPK8XLUhsyl
	return XXxlOLJ9KRjPH382WVCvr6n71
def Z6nTjPWKV3pwLG7DdEYt(Bm6RlzFt7j10nr395yLAoDuiIaq,SHk0ThDndgJW):
	XX8FguGmKp5DVB2Twifsc = yST5AHEfvPmcWpwGuh2BJ(u"ࡆࡢ࡮ࡶࡩṽ")
	qqokExPK8XLUhsyl = GyjmfosC59Jub
	GyjmfosC59Jub[:] = []
	if XX8FguGmKp5DVB2Twifsc and BWNPxIG7vqdTy85pjHzUOrK3(u"ࠪࡣࡈࡘࡅࡂࡖࡈࡒࡊ࡝࡟ࠨᲝ") not in SHk0ThDndgJW:
		XXxlOLJ9KRjPH382WVCvr6n71 = SS2OK7hjLagvUAm(mshLJcKH1fv03yRnDOr4ZT,zI3ROAZtiUq42rE9WDST68(u"ࠫࡱ࡯ࡳࡵࠩᲞ"),zI3ROAZtiUq42rE9WDST68(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡎ࠵ࡘࠫᲟ"),RRIHDFjoW9w7bSfVPhC(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡏ࠶࡙ࡤ࠭Რ")+Bm6RlzFt7j10nr395yLAoDuiIaq)
	elif shC5qBRV2A0lZ(u"ࠧࡠࡎࡌ࡚ࡊࡥࠧᲡ") not in SHk0ThDndgJW or TYf7Dc06PQgy1vEV9(u"ࠨࡡ࡙ࡓࡉࡥࠧᲢ") not in SHk0ThDndgJW:
		import pxFlVO8bCG
		A4gdSTQDP2FyBIVuba85RvYqKU = kke1PDGRBLuY8y(u"ࠩ็่ศูแࠡๆา๎่ࠦๅีๅ็อࠥ็๊้ࠡำหࠥอไๆ๊ๅ฽ࠥ࠴้ࠠำึห้ฯࠠศๆั฻ศࠦใศ่ࠣๅ๏ํวࠡฬไหฺ๐ไࠡษ็ู้้ไสࠢ࠱ࠤศึวࠡษ็ู้้ไสࠢ็๎ุะࠠฮฮหࠤๆาัษࠢศีุอไ้ࠡำ๋ࠥอไๆึๆ่ฮࠦลๅ๋ࠣห้๋ศา็ฯࠤ๊์ࠠใษษ้ฮࠦฮะ็สฮࠥอไษำ้ห๊าࠧᲣ")
		if UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠪࡣࡑࡏࡖࡆࡡࠪᲤ") not in SHk0ThDndgJW:
			try: pxFlVO8bCG.YhgBJAG0zwX5i(Bm6RlzFt7j10nr395yLAoDuiIaq,P0qdZI384LKleuo(u"࡛ࠫࡕࡄࡠࡗࡑࡏࡓࡕࡗࡏࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪᲥ"),b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,SHk0ThDndgJW+QQdAXWBc2GPw(u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᲦ"),LAQD5wEkr18bUiGaYen3J(u"ࡇࡣ࡯ࡷࡪṾ"))
			except: tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,zI3ROAZtiUq42rE9WDST68(u"࠭ๅ้ไ฼ࠤๅࡓ࠳ࡖࠢ็่ๆ๐ฯ๋๊๊หฯ࠭Ყ"),A4gdSTQDP2FyBIVuba85RvYqKU)
			try: pxFlVO8bCG.YhgBJAG0zwX5i(Bm6RlzFt7j10nr395yLAoDuiIaq,IjZbnrBJmM2N(u"ࠧࡗࡑࡇࡣࡒࡕࡖࡊࡇࡖࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬᲨ"),b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,SHk0ThDndgJW+uVQd103XyvUce2EBtzbYaC(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭Ჩ"),mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࡈࡤࡰࡸ࡫ṿ"))
			except: tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,shC5qBRV2A0lZ(u"่ࠩ์็฿ࠠแࡏ࠶๊࡙ࠥไโ์า๎ํํวหࠩᲪ"),A4gdSTQDP2FyBIVuba85RvYqKU)
			try: pxFlVO8bCG.YhgBJAG0zwX5i(Bm6RlzFt7j10nr395yLAoDuiIaq,ddo23ZJtgcY(u"࡚ࠪࡔࡊ࡟ࡔࡇࡕࡍࡊ࡙࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨᲫ"),b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,SHk0ThDndgJW+Mmpr0o76iWJvz1kTtfgI8hES(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᲬ"),TT8Mxv5Wq7nlC9IscdpPUY6(u"ࡉࡥࡱࡹࡥẀ"))
			except: tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,vvWwO3Tx2dAgcijrFXq(u"๋่ࠬใ฻ࠣไࡒ࠹ࡕࠡๆ็ๅ๏ี๊้้สฮࠬᲭ"),A4gdSTQDP2FyBIVuba85RvYqKU)
		if QQdAXWBc2GPw(u"࠭࡟ࡗࡑࡇࡣࠬᲮ") not in SHk0ThDndgJW:
			try: pxFlVO8bCG.YhgBJAG0zwX5i(Bm6RlzFt7j10nr395yLAoDuiIaq,dDYUoKi6JFM23p(u"ࠧࡍࡋ࡙ࡉࡤ࡛ࡎࡌࡐࡒ࡛ࡓࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧᲯ"),b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,SHk0ThDndgJW+mQNonhS7CV2BXOv(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭Ჰ"),HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࡊࡦࡲࡳࡦẁ"))
			except: tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,IjZbnrBJmM2N(u"่ࠩ์็฿ࠠแࡏ࠶๊࡙ࠥไใ่๋หฯ࠭Ჱ"),A4gdSTQDP2FyBIVuba85RvYqKU)
			try: pxFlVO8bCG.YhgBJAG0zwX5i(Bm6RlzFt7j10nr395yLAoDuiIaq,IjZbnrBJmM2N(u"ࠪࡐࡎ࡜ࡅࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩᲲ"),b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,SHk0ThDndgJW+IjZbnrBJmM2N(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᲳ"),kke1PDGRBLuY8y(u"ࡋࡧ࡬ࡴࡧẂ"))
			except: tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,zI3ROAZtiUq42rE9WDST68(u"๋่ࠬใ฻ࠣไࡒ࠹ࡕࠡๆ็ๆ๋๎วหࠩᲴ"),A4gdSTQDP2FyBIVuba85RvYqKU)
		XXxlOLJ9KRjPH382WVCvr6n71 = GyjmfosC59Jub
		if XX8FguGmKp5DVB2Twifsc: PGudrhJF8iDkSq96XVHEQZYf5L(mshLJcKH1fv03yRnDOr4ZT,VFjQx6Is28KvzLOmMXtg4GqTwa3(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡏ࠶࡙ࠬᲵ"),P0qdZI384LKleuo(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡐ࠷࡚ࡥࠧᲶ")+Bm6RlzFt7j10nr395yLAoDuiIaq,XXxlOLJ9KRjPH382WVCvr6n71,t58tnzAgevxkoIOdMFbE2PsD64q0C9)
	GyjmfosC59Jub[:] = qqokExPK8XLUhsyl
	return XXxlOLJ9KRjPH382WVCvr6n71
def qBykIPzlXcL(Bm6RlzFt7j10nr395yLAoDuiIaq,SHk0ThDndgJW,RJu2ixzAtZmj):
	PDanwWu4bFAhe3m(None,None,SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࡌࡡ࡭ࡵࡨẃ"))
	if RJu2ixzAtZmj: tt5JWsFHp82aL(DD5cFIejQa2X4BgAu9GWPyJ3tC7)
	elif shC5qBRV2A0lZ(u"ࠨࡡࡆࡖࡊࡇࡔࡆࡐࡈ࡛ࡤ࠭Ჷ") in SHk0ThDndgJW and not RJu2ixzAtZmj: tt5JWsFHp82aL(CCxMXuNUEzolDZTKrBJ)
	p0ptl9jOXuH8TsqSMiQCJZa = SHk0ThDndgJW.replace(IjZbnrBJmM2N(u"ࠩࡢࡇࡗࡋࡁࡕࡇࡑࡉ࡜ࡥࠧᲸ"),b8Qe150xVaJsnDSv).replace(HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᲹ"),b8Qe150xVaJsnDSv).replace(TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᲺ"),b8Qe150xVaJsnDSv)
	if not RJu2ixzAtZmj:
		MQtuaShrKTbdZFJ5nsR7D(Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠬࡲࡩ࡯࡭ࠪ᲻"),P0qdZI384LKleuo(u"࠭สฮัํฯ่ࠥวว็ฬࠤฬ๊รใีส้ࠬ᲼"),b8Qe150xVaJsnDSv,Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"࠼࠼࠳ḵ"),b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,BWNPxIG7vqdTy85pjHzUOrK3(u"ࠧࡠࡅࡕࡉࡆ࡚ࡅࡏࡇ࡚ࡣࠬᲽ")+p0ptl9jOXuH8TsqSMiQCJZa,b8Qe150xVaJsnDSv,{ddo23ZJtgcY(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᲾ"):Bm6RlzFt7j10nr395yLAoDuiIaq})
		MQtuaShrKTbdZFJ5nsR7D(TYf7Dc06PQgy1vEV9(u"ࠩ࡯࡭ࡳࡱࠧᲿ"),rC3Tlno96KjLDIvBaSWUbR8+UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠪࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠࠨ᳀")+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,Nh0BWuiSndf(u"࠿࠹࠺࠻Ḷ"))
		UYsh9fbVInMj = [BWNPxIG7vqdTy85pjHzUOrK3(u"ࠫศ็ไศ็ࠪ᳁"),P0qdZI384LKleuo(u"๋ࠬำๅี็หฯ࠭᳂"),Mmpr0o76iWJvz1kTtfgI8hES(u"࠭ๅิำะ๎ฬะࠧ᳃"),QTUBCcehw6qPd4x(u"ࠧษำส้ั࠭᳄"),P0qdZI384LKleuo(u"ࠨลฺๅฬ๊้ࠠๅิฮํ์ࠧ᳅"),TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠩิ้฻อๆࠨ᳆"),HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠪวาีห࠮ลัีࠬ᳇"),dDYUoKi6JFM23p(u"ุ๊ࠫวิๆࠪ᳈"),HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"๋่ࠬิ์ๅํࠬ᳉"),mmcNLrXtzfpyCkZlvK5VwG2gujh(u"࠭รี้ิ࠱ศ้หาࠩ᳊"),kke1PDGRBLuY8y(u"ࠧศๆล๊ࠬ᳋"),m6hwdgP31a2zjN7lkpX(u"ࠨุะ็ࠬ᳌"),HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠩิ๎ฬ฼ษࠨ᳍"),vvWwO3Tx2dAgcijrFXq(u"๊ࠪ๏ะแๅๅึࠫ᳎"),QTUBCcehw6qPd4x(u"๊๋ࠫหๅ์้ࠫ᳏"),SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠬฮหࠡฯํࠫ᳐"),BWNPxIG7vqdTy85pjHzUOrK3(u"࠭ฯ๋่ํอࠬ᳑"),ubxGUTt1LraKhVZgpAP(u"ࠧิ่๋หฯ࠭᳒"),Xz3bA2PFENVCUtplu51(u"ࠨลัี๎࠭᳓")]
		RJu2ixzAtZmj = LzYQg91SIxDeOGtCKd5
		for MtfdsogHF8OIPrkxDcayNplLE0R4Y in UYsh9fbVInMj:
			RJu2ixzAtZmj += qHYIWnOZLPkrQU
			MQtuaShrKTbdZFJ5nsR7D(IjZbnrBJmM2N(u"ࠩࡩࡳࡱࡪࡥࡳ᳔ࠩ"),WbzmKSZiuOYrBN7oysJ2dUv+MtfdsogHF8OIPrkxDcayNplLE0R4Y,b8Qe150xVaJsnDSv,TYf7Dc06PQgy1vEV9(u"࠷࠷࠵ḷ"),b8Qe150xVaJsnDSv,str(RJu2ixzAtZmj),p0ptl9jOXuH8TsqSMiQCJZa,b8Qe150xVaJsnDSv,{shC5qBRV2A0lZ(u"ࠪࡪࡴࡲࡤࡦࡴ᳕ࠪ"):Bm6RlzFt7j10nr395yLAoDuiIaq})
	else:
		DDXvPLs1EmS2Z5W = [ubxGUTt1LraKhVZgpAP(u"ࠫฬ็ไศ็᳖ࠪ"),BmePGjS7FxK6kutUM(u"ࠬࡳ࡯ࡷ࡫ࡨ᳗ࠫ"),yST5AHEfvPmcWpwGuh2BJ(u"࠭แ๋ๆ่᳘ࠫ"),SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠧโๆ่᳙ࠫ")]
		jQ9zsEX2Hc = [QQdAXWBc2GPw(u"ࠨ็ึุ่๊ࠧ᳚"),Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠩࡶࡩࡷ࡯ࡥࡴࠩ᳛")]
		qcFfDCA98SE7OLe = [kke1PDGRBLuY8y(u"ุ้ࠪอัฮ᳜ࠩ"),uVQd103XyvUce2EBtzbYaC(u"ู๊ࠫัฮ์สฮ᳝ࠬ")]
		jdnbCpuRUS4 = [BmePGjS7FxK6kutUM(u"ࠬฮัศ็ฯ᳞ࠫ"),S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"࠭ࡳࡩࡱࡺ᳟ࠫ"),S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠧหๆไึ๏๎ๆࠨ᳠"),zI3ROAZtiUq42rE9WDST68(u"ࠨฬ็๎ๆุ๊้่ࠪ᳡")]
		qqCiAw5IVkfXYMh1xycmdR = [S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠩส๊๊๐᳢ࠧ"),uVQd103XyvUce2EBtzbYaC(u"ࠪ็ึะ่็᳣ࠩ"),mQNonhS7CV2BXOv(u"่ࠫอัห᳤๊้ࠫ"),QTUBCcehw6qPd4x(u"ࠬࡱࡩࡥࡵ᳥ࠪ"),QTUBCcehw6qPd4x(u"࠭ืโๆ᳦ࠪ"),BWNPxIG7vqdTy85pjHzUOrK3(u"ࠧศูไห᳧้࠭")]
		HHLQYNbcur = [mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠨำฺ่ฬ์᳨ࠧ")]
		eewcWksvSlYIXTHG5 = [DYakr9g4PVU(u"ࠩสัิัࠧᳩ"),RRIHDFjoW9w7bSfVPhC(u"ࠪหำืࠧᳪ"),BmePGjS7FxK6kutUM(u"๊ࠫ๎ฮาࠩᳫ"),DYakr9g4PVU(u"ࠬาฯ๋ัࠪᳬ"),Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"࠭ๅืษไ᳭ࠫ"),shC5qBRV2A0lZ(u"ࠧฮัํฯࠬᳮ")]
		pWY37ADhUSny9g8 = [VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠨี็หุ๊ࠧᳯ"),TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠩึุ่๊็ࠨᳰ")]
		t0DCEYpzbQ9mNSlVLMwGndFXR2iW = [RRIHDFjoW9w7bSfVPhC(u"ࠪห฿อๆ๋ࠩᳱ"),HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"๊ࠫ๎ำ๋ไ์ࠫᳲ"),P0qdZI384LKleuo(u"้ࠬไ๋สࠪᳳ"),BmePGjS7FxK6kutUM(u"࠭อโๆࠪ᳴"),m6hwdgP31a2zjN7lkpX(u"ࠧ࡮ࡷࡶ࡭ࡨ࠭ᳵ")]
		E39EPbfvCJ7NFSpnhMs2B4L51wAx = [Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠨษๆฯึ࠭ᳶ"),shC5qBRV2A0lZ(u"ࠩสุ์ืࠧ᳷"),shC5qBRV2A0lZ(u"้๊ࠪ๐า่ࠩ᳸"),zI3ROAZtiUq42rE9WDST68(u"ࠫฬ฿ไ๊ࠩ᳹"),Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"๋ࠬฮหษิ๋ࠬᳺ"),dDYUoKi6JFM23p(u"࠭ๅฯฬสีฬะࠧ᳻"),Xz3bA2PFENVCUtplu51(u"ࠧศไ๋ํࠬ᳼")]
		Yrxbq5MH4jyRVWKcfoi7G = [QQdAXWBc2GPw(u"ࠨษ็ห๋࠭᳽"),ddo23ZJtgcY(u"ࠩะห้๐ࠧ᳾"),HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"้ࠪะฮสࠨ᳿"),UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠫึอฦอࠩᴀ")]
		LtyuI9xKedO0rsfa48U = [TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠬ฼อไࠩᴁ"),shC5qBRV2A0lZ(u"࠭ใ้็ํำ๏࠭ᴂ")]
		raiF8WCGfNX = [m6hwdgP31a2zjN7lkpX(u"ࠧา์สฺ์࠭ᴃ"),Nh0BWuiSndf(u"ࠨๅ๋ี์࠭ᴄ"),HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ู่ࠩฬืู่ࠩᴅ"),Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ุࠪํะࠧᴆ"),Mmpr0o76iWJvz1kTtfgI8hES(u"ࠫึ๐วืหࠪᴇ")]
		TQV4CYRec92 = [QQdAXWBc2GPw(u"ࠬ์๊หใ็็ุ࠭ᴈ"),IjZbnrBJmM2N(u"࠭࡮ࡦࡶࡩࡰ࡮ࡾࠧᴉ"),ubxGUTt1LraKhVZgpAP(u"ࠧ็์อๅ้๐ใิࠩᴊ")]
		Y5tJ8cg0knxl = [QQdAXWBc2GPw(u"ࠨ็่ฯ้๐ๆࠨᴋ"),Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠩสุำอีࠨᴌ"),uVQd103XyvUce2EBtzbYaC(u"๊ࠪั๎ๅࠨᴍ")]
		vtqABUEyi7jeLRWSkV5b8KpMH = [mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠫอัࠠฮ์ࠪᴎ"),SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠬࡲࡩࡷࡧࠪᴏ"),BWNPxIG7vqdTy85pjHzUOrK3(u"࠭โ็ษ๊ࠫᴐ"),ddo23ZJtgcY(u"ࠧใ่๋หฯ࠭ᴑ")]
		RsgjML63o5E9aUf1IuVCYcXxnG8b = [TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠨัํ๊ࠬᴒ"),m6hwdgP31a2zjN7lkpX(u"ࠩสำ฾๐็ࠨᴓ"),IjZbnrBJmM2N(u"ࠪึ๏อัศฬࠪᴔ"),QTUBCcehw6qPd4x(u"้ࠫ฽ๅ๋ษอࠫᴕ"),shC5qBRV2A0lZ(u"ࠬีูศรࠪᴖ"),SbjiWeHLQPoazqwp3cODkd7YxVgn(u"࠭โาษ้ࠫᴗ"),QQdAXWBc2GPw(u"ࠧใืสสิ࠭ᴘ"),RRIHDFjoW9w7bSfVPhC(u"ࠨำฮหฦ࠭ᴙ"),BmePGjS7FxK6kutUM(u"่ࠩีั฿๊่ࠩᴚ"),mQNonhS7CV2BXOv(u"ࠪหีอๆࠨᴛ"),HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠫฬูไศ็ࠪᴜ"),ddo23ZJtgcY(u"ࠬะ่ศึํัࠬᴝ"),ddo23ZJtgcY(u"࠭ฮุสࠪᴞ"),dDYUoKi6JFM23p(u"ࠧฮ๊ี์๏࠭ᴟ"),shC5qBRV2A0lZ(u"ࠨ฻อฬฬะࠧᴠ"),BmePGjS7FxK6kutUM(u"่ࠩ์ฬ๊๊ะࠩᴡ"),TT8Mxv5Wq7nlC9IscdpPUY6(u"๊ࠪํอู๋ࠩᴢ"),QTUBCcehw6qPd4x(u"ࠫ฾่ววัࠪᴣ"),dDYUoKi6JFM23p(u"ࠬอๆศึํำࠬᴤ")]
		SO9hJIKl2wargXDq = [SbjiWeHLQPoazqwp3cODkd7YxVgn(u"࠭࠲࠱࠳࠳ࠫᴥ"),P0qdZI384LKleuo(u"ࠧ࠳࠲࠴࠵ࠬᴦ"),shC5qBRV2A0lZ(u"ࠨ࠴࠳࠵࠷࠭ᴧ"),TYf7Dc06PQgy1vEV9(u"ࠩ࠵࠴࠶࠹ࠧᴨ"),Mmpr0o76iWJvz1kTtfgI8hES(u"ࠪ࠶࠵࠷࠴ࠨᴩ"),yST5AHEfvPmcWpwGuh2BJ(u"ࠫ࠷࠶࠱࠶ࠩᴪ"),ubxGUTt1LraKhVZgpAP(u"ࠬ࠸࠰࠲࠸ࠪᴫ"),mmcNLrXtzfpyCkZlvK5VwG2gujh(u"࠭࠲࠱࠳࠺ࠫᴬ"),kke1PDGRBLuY8y(u"ࠧ࠳࠲࠴࠼ࠬᴭ"),dDYUoKi6JFM23p(u"ࠨ࠴࠳࠵࠾࠭ᴮ"),uVQd103XyvUce2EBtzbYaC(u"ࠩ࠵࠴࠷࠶ࠧᴯ"),shC5qBRV2A0lZ(u"ࠪ࠶࠵࠸࠱ࠨᴰ"),HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠫ࠷࠶࠲࠳ࠩᴱ"),Mmpr0o76iWJvz1kTtfgI8hES(u"ࠬ࠸࠰࠳࠵ࠪᴲ"),dDYUoKi6JFM23p(u"࠭࠲࠱࠴࠷ࠫᴳ"),Mmpr0o76iWJvz1kTtfgI8hES(u"ࠧ࠳࠲࠵࠹ࠬᴴ"),Mmpr0o76iWJvz1kTtfgI8hES(u"ࠨ࠴࠳࠶࠻࠭ᴵ"),SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠩ࠵࠴࠷࠽ࠧᴶ"),dDYUoKi6JFM23p(u"ࠪ࠶࠵࠸࠸ࠨᴷ")]
		for c17XeRIH2gVh3px8sw in sorted(list(p2MSNUTiP4QaYJ.keys())):
			WUj71fhxld3rqONpBzmEuC = c17XeRIH2gVh3px8sw.lower()
			Z8s0Lov2UiWF1qGjO = []
			if any(Y8aiFZsLKw in WUj71fhxld3rqONpBzmEuC for Y8aiFZsLKw in DDXvPLs1EmS2Z5W): Z8s0Lov2UiWF1qGjO.append(qHYIWnOZLPkrQU)
			if any(Y8aiFZsLKw in WUj71fhxld3rqONpBzmEuC for Y8aiFZsLKw in jQ9zsEX2Hc): Z8s0Lov2UiWF1qGjO.append(IgQimel18t)
			if any(Y8aiFZsLKw in WUj71fhxld3rqONpBzmEuC for Y8aiFZsLKw in qcFfDCA98SE7OLe): Z8s0Lov2UiWF1qGjO.append(VwApyDY1Jc)
			if any(Y8aiFZsLKw in WUj71fhxld3rqONpBzmEuC for Y8aiFZsLKw in jdnbCpuRUS4): Z8s0Lov2UiWF1qGjO.append(NvHugPosYDzRJ)
			if any(Y8aiFZsLKw in WUj71fhxld3rqONpBzmEuC for Y8aiFZsLKw in qqCiAw5IVkfXYMh1xycmdR): Z8s0Lov2UiWF1qGjO.append(Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"࠶Ḹ"))
			if any(Y8aiFZsLKw in WUj71fhxld3rqONpBzmEuC for Y8aiFZsLKw in HHLQYNbcur): Z8s0Lov2UiWF1qGjO.append(LAQD5wEkr18bUiGaYen3J(u"࠸ḹ"))
			if any(Y8aiFZsLKw in WUj71fhxld3rqONpBzmEuC for Y8aiFZsLKw in eewcWksvSlYIXTHG5) and WUj71fhxld3rqONpBzmEuC not in [Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠫฬิั๊ࠩᴸ")]: Z8s0Lov2UiWF1qGjO.append(Xz3bA2PFENVCUtplu51(u"࠺Ḻ"))
			if any(Y8aiFZsLKw in WUj71fhxld3rqONpBzmEuC for Y8aiFZsLKw in pWY37ADhUSny9g8): Z8s0Lov2UiWF1qGjO.append(Nh0BWuiSndf(u"࠼ḻ"))
			if any(Y8aiFZsLKw in WUj71fhxld3rqONpBzmEuC for Y8aiFZsLKw in t0DCEYpzbQ9mNSlVLMwGndFXR2iW): Z8s0Lov2UiWF1qGjO.append(VFjQx6Is28KvzLOmMXtg4GqTwa3(u"࠾Ḽ"))
			if any(Y8aiFZsLKw in WUj71fhxld3rqONpBzmEuC for Y8aiFZsLKw in E39EPbfvCJ7NFSpnhMs2B4L51wAx): Z8s0Lov2UiWF1qGjO.append(mmcNLrXtzfpyCkZlvK5VwG2gujh(u"࠷࠰ḽ"))
			if any(Y8aiFZsLKw in WUj71fhxld3rqONpBzmEuC for Y8aiFZsLKw in Yrxbq5MH4jyRVWKcfoi7G): Z8s0Lov2UiWF1qGjO.append(ubxGUTt1LraKhVZgpAP(u"࠱࠲Ḿ"))
			if any(Y8aiFZsLKw in WUj71fhxld3rqONpBzmEuC for Y8aiFZsLKw in LtyuI9xKedO0rsfa48U): Z8s0Lov2UiWF1qGjO.append(mQNonhS7CV2BXOv(u"࠲࠴ḿ"))
			if any(Y8aiFZsLKw in WUj71fhxld3rqONpBzmEuC for Y8aiFZsLKw in raiF8WCGfNX): Z8s0Lov2UiWF1qGjO.append(RRIHDFjoW9w7bSfVPhC(u"࠳࠶Ṁ"))
			if any(Y8aiFZsLKw in WUj71fhxld3rqONpBzmEuC for Y8aiFZsLKw in TQV4CYRec92): Z8s0Lov2UiWF1qGjO.append(QQdAXWBc2GPw(u"࠴࠸ṁ"))
			if any(Y8aiFZsLKw in WUj71fhxld3rqONpBzmEuC for Y8aiFZsLKw in Y5tJ8cg0knxl): Z8s0Lov2UiWF1qGjO.append(VFjQx6Is28KvzLOmMXtg4GqTwa3(u"࠵࠺Ṃ"))
			if any(Y8aiFZsLKw in WUj71fhxld3rqONpBzmEuC for Y8aiFZsLKw in vtqABUEyi7jeLRWSkV5b8KpMH): Z8s0Lov2UiWF1qGjO.append(uVQd103XyvUce2EBtzbYaC(u"࠶࠼ṃ"))
			if any(Y8aiFZsLKw in WUj71fhxld3rqONpBzmEuC for Y8aiFZsLKw in RsgjML63o5E9aUf1IuVCYcXxnG8b): Z8s0Lov2UiWF1qGjO.append(BmePGjS7FxK6kutUM(u"࠷࠷Ṅ"))
			if any(Y8aiFZsLKw in WUj71fhxld3rqONpBzmEuC for Y8aiFZsLKw in SO9hJIKl2wargXDq): Z8s0Lov2UiWF1qGjO.append(kke1PDGRBLuY8y(u"࠱࠹ṅ"))
			if not Z8s0Lov2UiWF1qGjO: Z8s0Lov2UiWF1qGjO = [DYakr9g4PVU(u"࠲࠻Ṇ")]
			for j9uNmf0TqMwYFCzBpyObXQPia1rRA in Z8s0Lov2UiWF1qGjO:
				if str(j9uNmf0TqMwYFCzBpyObXQPia1rRA)==RJu2ixzAtZmj:
					MQtuaShrKTbdZFJ5nsR7D(P0qdZI384LKleuo(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᴹ"),WbzmKSZiuOYrBN7oysJ2dUv+c17XeRIH2gVh3px8sw,c17XeRIH2gVh3px8sw,UUkIBz1sgQ9WfNeG6trKXvu0(u"࠳࠹࠺ṇ"),b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,p0ptl9jOXuH8TsqSMiQCJZa+VFjQx6Is28KvzLOmMXtg4GqTwa3(u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᴺ"))
	PDanwWu4bFAhe3m(None,None,b8Qe150xVaJsnDSv)
	return
def eoJd2Ny3EQpztTF9W8ACHDZijlr(Bm6RlzFt7j10nr395yLAoDuiIaq,SHk0ThDndgJW):
	XX8FguGmKp5DVB2Twifsc = LAQD5wEkr18bUiGaYen3J(u"ࡆࡢ࡮ࡶࡩẄ")
	if XX8FguGmKp5DVB2Twifsc:
		MQtuaShrKTbdZFJ5nsR7D(Mmpr0o76iWJvz1kTtfgI8hES(u"ࠧ࡭࡫ࡱ࡯ࠬᴻ"),dDYUoKi6JFM23p(u"ࠨฬะำ๏ัࠠใษษ้ฮࠦรใีส้ࠥࡏࡐࡕࡘࠪᴼ"),b8Qe150xVaJsnDSv,QTUBCcehw6qPd4x(u"࠺࠺࠹Ṉ"),b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,TYf7Dc06PQgy1vEV9(u"ࠩࡢࡇࡗࡋࡁࡕࡇࡑࡉ࡜ࡥࠧᴽ"),b8Qe150xVaJsnDSv,{Xz3bA2PFENVCUtplu51(u"ࠪࡪࡴࡲࡤࡦࡴࠪᴾ"):Bm6RlzFt7j10nr395yLAoDuiIaq})
		MQtuaShrKTbdZFJ5nsR7D(VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠫࡱ࡯࡮࡬ࠩᴿ"),rC3Tlno96KjLDIvBaSWUbR8+QTUBCcehw6qPd4x(u"ࠬࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࠪᵀ")+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,mQNonhS7CV2BXOv(u"࠽࠾࠿࠹ṉ"))
	qqokExPK8XLUhsyl = GyjmfosC59Jub[:]
	import CC4xSVuWXg
	if Bm6RlzFt7j10nr395yLAoDuiIaq:
		if not CC4xSVuWXg.yyq2ZDzu5wSeCKA84pxf7PRWTOrBtY(Bm6RlzFt7j10nr395yLAoDuiIaq,BmePGjS7FxK6kutUM(u"ࡕࡴࡸࡩẅ")): return
		OQ6vjNzB2rJ40qCHG = mkVxqa8XjHOTID7MthNBl(Bm6RlzFt7j10nr395yLAoDuiIaq,SHk0ThDndgJW)
		cLtYxpHVoAgd = sorted(OQ6vjNzB2rJ40qCHG,reverse=yST5AHEfvPmcWpwGuh2BJ(u"ࡈࡤࡰࡸ࡫Ẇ"),key=lambda key: key[qHYIWnOZLPkrQU].lower())
	else:
		if not CC4xSVuWXg.yyq2ZDzu5wSeCKA84pxf7PRWTOrBtY(b8Qe150xVaJsnDSv,LAQD5wEkr18bUiGaYen3J(u"ࡗࡶࡺ࡫ẇ")): return
		if XX8FguGmKp5DVB2Twifsc and vvWwO3Tx2dAgcijrFXq(u"࠭࡟ࡄࡔࡈࡅ࡙ࡋࡎࡆ࡙ࡢࠫᵁ") not in SHk0ThDndgJW:
			cLtYxpHVoAgd = SS2OK7hjLagvUAm(mshLJcKH1fv03yRnDOr4ZT,ddo23ZJtgcY(u"ࠧ࡭࡫ࡶࡸࠬᵂ"),uVQd103XyvUce2EBtzbYaC(u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡍࡕ࡚ࡖࠨᵃ"),QTUBCcehw6qPd4x(u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡎࡖࡔࡗࡡࡄࡐࡑ࠭ᵄ"))
		else:
			qqi7mbvHKtwd5WN1kOErXCnj8P,cLtYxpHVoAgd,OQ6vjNzB2rJ40qCHG = [],[],[]
			for xwHymGcJbqgSIs7D9Y in range(qHYIWnOZLPkrQU,PINQnUL6h3XA9at+qHYIWnOZLPkrQU):
				cLtYxpHVoAgd += mkVxqa8XjHOTID7MthNBl(str(xwHymGcJbqgSIs7D9Y),SHk0ThDndgJW)
			for type,c17XeRIH2gVh3px8sw,url,ZZtDTHnBXMz,I6YPOSofrpnTwRm8b,NGQDwOCXx1BZmd9Huc,pnmsJqCWIHVk2Y6xPvl9Q0Ez8r,wc0Z9FAdf2B1J,XXra5dzn8tcLOxYZIE7pPof49Hh in cLtYxpHVoAgd:
				if pnmsJqCWIHVk2Y6xPvl9Q0Ez8r not in qqi7mbvHKtwd5WN1kOErXCnj8P:
					qqi7mbvHKtwd5WN1kOErXCnj8P.append(pnmsJqCWIHVk2Y6xPvl9Q0Ez8r)
					HmRnLhescW = type,c17XeRIH2gVh3px8sw,pnmsJqCWIHVk2Y6xPvl9Q0Ez8r,kke1PDGRBLuY8y(u"࠶࠼࠵Ṋ"),I6YPOSofrpnTwRm8b,NGQDwOCXx1BZmd9Huc,SHk0ThDndgJW,wc0Z9FAdf2B1J,XXra5dzn8tcLOxYZIE7pPof49Hh
					OQ6vjNzB2rJ40qCHG.append(HmRnLhescW)
			cLtYxpHVoAgd = sorted(OQ6vjNzB2rJ40qCHG,reverse=DYakr9g4PVU(u"ࡊࡦࡲࡳࡦẈ"),key=lambda key: key[qHYIWnOZLPkrQU].lower())
			if XX8FguGmKp5DVB2Twifsc: PGudrhJF8iDkSq96XVHEQZYf5L(mshLJcKH1fv03yRnDOr4ZT,m6hwdgP31a2zjN7lkpX(u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡏࡐࡕࡘࠪᵅ"),P0qdZI384LKleuo(u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡉࡑࡖ࡙ࡣࡆࡒࡌࠨᵆ"),cLtYxpHVoAgd,t58tnzAgevxkoIOdMFbE2PsD64q0C9)
	GyjmfosC59Jub[:] = qqokExPK8XLUhsyl+cLtYxpHVoAgd
	qMGn9u2ckaXejCgUQhYTDP(SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࡋࡧ࡬ࡴࡧẉ"))
	return
def ojyd3swIQnm0aHr2DTFgEv(Bm6RlzFt7j10nr395yLAoDuiIaq,SHk0ThDndgJW):
	XX8FguGmKp5DVB2Twifsc = IjZbnrBJmM2N(u"ࡌࡡ࡭ࡵࡨẊ")
	if XX8FguGmKp5DVB2Twifsc:
		MQtuaShrKTbdZFJ5nsR7D(Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠬࡲࡩ࡯࡭ࠪᵇ"),mQNonhS7CV2BXOv(u"࠭สฮัํฯ่ࠥวว็ฬࠤศ่ำศ็ࠣࡑ࠸࡛ࠧᵈ"),b8Qe150xVaJsnDSv,QTUBCcehw6qPd4x(u"࠽࠶࠶ṋ"),b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,shC5qBRV2A0lZ(u"ࠧࡠࡅࡕࡉࡆ࡚ࡅࡏࡇ࡚ࡣࠬᵉ"),b8Qe150xVaJsnDSv,{UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᵊ"):Bm6RlzFt7j10nr395yLAoDuiIaq})
		MQtuaShrKTbdZFJ5nsR7D(BWNPxIG7vqdTy85pjHzUOrK3(u"ࠩ࡯࡭ࡳࡱࠧᵋ"),rC3Tlno96KjLDIvBaSWUbR8+mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠪࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠࠨᵌ")+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,QTUBCcehw6qPd4x(u"࠹࠺࠻࠼Ṍ"))
	qqokExPK8XLUhsyl = GyjmfosC59Jub[:]
	import pxFlVO8bCG
	if Bm6RlzFt7j10nr395yLAoDuiIaq:
		if not pxFlVO8bCG.yyq2ZDzu5wSeCKA84pxf7PRWTOrBtY(Bm6RlzFt7j10nr395yLAoDuiIaq,yST5AHEfvPmcWpwGuh2BJ(u"ࡔࡳࡷࡨẋ")): return
		OQ6vjNzB2rJ40qCHG = Z6nTjPWKV3pwLG7DdEYt(Bm6RlzFt7j10nr395yLAoDuiIaq,SHk0ThDndgJW)
		cLtYxpHVoAgd = sorted(OQ6vjNzB2rJ40qCHG,reverse=QQdAXWBc2GPw(u"ࡇࡣ࡯ࡷࡪẌ"),key=lambda key: key[qHYIWnOZLPkrQU].lower())
	else:
		if not pxFlVO8bCG.yyq2ZDzu5wSeCKA84pxf7PRWTOrBtY(b8Qe150xVaJsnDSv,QTUBCcehw6qPd4x(u"ࡖࡵࡹࡪẍ")): return
		if XX8FguGmKp5DVB2Twifsc and UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠫࡤࡉࡒࡆࡃࡗࡉࡓࡋࡗࡠࠩᵍ") not in SHk0ThDndgJW:
			cLtYxpHVoAgd = SS2OK7hjLagvUAm(mshLJcKH1fv03yRnDOr4ZT,BWNPxIG7vqdTy85pjHzUOrK3(u"ࠬࡲࡩࡴࡶࠪᵎ"),Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡏ࠶࡙ࠬᵏ"),Mmpr0o76iWJvz1kTtfgI8hES(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡐ࠷࡚ࡥࡁࡍࡎࠪᵐ"))
		else:
			qqi7mbvHKtwd5WN1kOErXCnj8P,cLtYxpHVoAgd,OQ6vjNzB2rJ40qCHG = [],[],[]
			for xwHymGcJbqgSIs7D9Y in range(qHYIWnOZLPkrQU,PINQnUL6h3XA9at+qHYIWnOZLPkrQU):
				cLtYxpHVoAgd += Z6nTjPWKV3pwLG7DdEYt(str(xwHymGcJbqgSIs7D9Y),SHk0ThDndgJW)
			for type,c17XeRIH2gVh3px8sw,url,ZZtDTHnBXMz,I6YPOSofrpnTwRm8b,NGQDwOCXx1BZmd9Huc,pnmsJqCWIHVk2Y6xPvl9Q0Ez8r,wc0Z9FAdf2B1J,XXra5dzn8tcLOxYZIE7pPof49Hh in cLtYxpHVoAgd:
				if pnmsJqCWIHVk2Y6xPvl9Q0Ez8r not in qqi7mbvHKtwd5WN1kOErXCnj8P:
					qqi7mbvHKtwd5WN1kOErXCnj8P.append(pnmsJqCWIHVk2Y6xPvl9Q0Ez8r)
					HmRnLhescW = type,c17XeRIH2gVh3px8sw,pnmsJqCWIHVk2Y6xPvl9Q0Ez8r,QQdAXWBc2GPw(u"࠲࠸࠸ṍ"),I6YPOSofrpnTwRm8b,NGQDwOCXx1BZmd9Huc,SHk0ThDndgJW,wc0Z9FAdf2B1J,XXra5dzn8tcLOxYZIE7pPof49Hh
					OQ6vjNzB2rJ40qCHG.append(HmRnLhescW)
			cLtYxpHVoAgd = sorted(OQ6vjNzB2rJ40qCHG,reverse=m6hwdgP31a2zjN7lkpX(u"ࡉࡥࡱࡹࡥẎ"),key=lambda key: key[qHYIWnOZLPkrQU].lower())
			if XX8FguGmKp5DVB2Twifsc: PGudrhJF8iDkSq96XVHEQZYf5L(mshLJcKH1fv03yRnDOr4ZT,Mmpr0o76iWJvz1kTtfgI8hES(u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡑ࠸࡛ࠧᵑ"),mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡒ࠹ࡕࡠࡃࡏࡐࠬᵒ"),cLtYxpHVoAgd,t58tnzAgevxkoIOdMFbE2PsD64q0C9)
	GyjmfosC59Jub[:] = qqokExPK8XLUhsyl+cLtYxpHVoAgd
	qMGn9u2ckaXejCgUQhYTDP(TYf7Dc06PQgy1vEV9(u"ࡊࡦࡲࡳࡦẏ"))
	return
def HeW7omDltbEghRIu(group,SHk0ThDndgJW):
	XX8FguGmKp5DVB2Twifsc = UUkIBz1sgQ9WfNeG6trKXvu0(u"ࡋࡧ࡬ࡴࡧẐ")
	XXxlOLJ9KRjPH382WVCvr6n71 = []
	e6aUA48hu3LR = QQdAXWBc2GPw(u"ࠪࡣࡎࡖࡔࡗࡡࠪᵓ") if m6hwdgP31a2zjN7lkpX(u"ࠫࡎࡖࡔࡗࠩᵔ") in SHk0ThDndgJW else SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠬࡥࡍ࠴ࡗࡢࠫᵕ")
	if XX8FguGmKp5DVB2Twifsc: XXxlOLJ9KRjPH382WVCvr6n71 = SS2OK7hjLagvUAm(mshLJcKH1fv03yRnDOr4ZT,Xz3bA2PFENVCUtplu51(u"࠭࡬ࡪࡵࡷࠫᵖ"),P0qdZI384LKleuo(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࠩᵗ")+e6aUA48hu3LR[:-DYakr9g4PVU(u"࠳Ṏ")],group)
	if not XXxlOLJ9KRjPH382WVCvr6n71:
		for Bm6RlzFt7j10nr395yLAoDuiIaq in range(qHYIWnOZLPkrQU,PINQnUL6h3XA9at+qHYIWnOZLPkrQU):
			if XX8FguGmKp5DVB2Twifsc: XXxlOLJ9KRjPH382WVCvr6n71 += SS2OK7hjLagvUAm(mshLJcKH1fv03yRnDOr4ZT,Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠨ࡮࡬ࡷࡹ࠭ᵘ"),BWNPxIG7vqdTy85pjHzUOrK3(u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࠫᵙ")+e6aUA48hu3LR[:-qHYIWnOZLPkrQU],ubxGUTt1LraKhVZgpAP(u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࠬᵚ")+e6aUA48hu3LR+str(Bm6RlzFt7j10nr395yLAoDuiIaq))
			elif e6aUA48hu3LR==ubxGUTt1LraKhVZgpAP(u"ࠫࡤࡏࡐࡕࡘࡢࠫᵛ"): XXxlOLJ9KRjPH382WVCvr6n71 += mkVxqa8XjHOTID7MthNBl(str(Bm6RlzFt7j10nr395yLAoDuiIaq),yST5AHEfvPmcWpwGuh2BJ(u"ࠬࡥࡃࡓࡇࡄࡘࡊࡔࡅࡘࡡࠪᵜ"))
			elif e6aUA48hu3LR==VFjQx6Is28KvzLOmMXtg4GqTwa3(u"࠭࡟ࡎ࠵ࡘࡣࠬᵝ"): XXxlOLJ9KRjPH382WVCvr6n71 += Z6nTjPWKV3pwLG7DdEYt(str(Bm6RlzFt7j10nr395yLAoDuiIaq),mQNonhS7CV2BXOv(u"ࠧࡠࡅࡕࡉࡆ࡚ࡅࡏࡇ࡚ࡣࠬᵞ"))
		for type,c17XeRIH2gVh3px8sw,url,ZZtDTHnBXMz,I6YPOSofrpnTwRm8b,NGQDwOCXx1BZmd9Huc,pnmsJqCWIHVk2Y6xPvl9Q0Ez8r,wc0Z9FAdf2B1J,XXra5dzn8tcLOxYZIE7pPof49Hh in XXxlOLJ9KRjPH382WVCvr6n71:
			if pnmsJqCWIHVk2Y6xPvl9Q0Ez8r==group: fPYwhSsFOBLbt7rM902im4oVE(type,c17XeRIH2gVh3px8sw,url,ZZtDTHnBXMz,I6YPOSofrpnTwRm8b,NGQDwOCXx1BZmd9Huc,pnmsJqCWIHVk2Y6xPvl9Q0Ez8r,wc0Z9FAdf2B1J,XXra5dzn8tcLOxYZIE7pPof49Hh)
		items,xxnATEUzH6Djmq0NrBveh = [],[]
		for type,c17XeRIH2gVh3px8sw,url,ZZtDTHnBXMz,I6YPOSofrpnTwRm8b,NGQDwOCXx1BZmd9Huc,pnmsJqCWIHVk2Y6xPvl9Q0Ez8r,wc0Z9FAdf2B1J,XXra5dzn8tcLOxYZIE7pPof49Hh in GyjmfosC59Jub:
			trSHo9T2ulqOd8gLfeU6hCys1nPG = type,c17XeRIH2gVh3px8sw[NvHugPosYDzRJ:],url,ZZtDTHnBXMz,I6YPOSofrpnTwRm8b,NGQDwOCXx1BZmd9Huc,pnmsJqCWIHVk2Y6xPvl9Q0Ez8r,wc0Z9FAdf2B1J,b8Qe150xVaJsnDSv
			if trSHo9T2ulqOd8gLfeU6hCys1nPG not in xxnATEUzH6Djmq0NrBveh:
				xxnATEUzH6Djmq0NrBveh.append(trSHo9T2ulqOd8gLfeU6hCys1nPG)
				tgoJCpq8KGrdaUSjsLh0FTxDRPfIAB = type,c17XeRIH2gVh3px8sw,url,ZZtDTHnBXMz,I6YPOSofrpnTwRm8b,NGQDwOCXx1BZmd9Huc,pnmsJqCWIHVk2Y6xPvl9Q0Ez8r,wc0Z9FAdf2B1J,XXra5dzn8tcLOxYZIE7pPof49Hh
				items.append(tgoJCpq8KGrdaUSjsLh0FTxDRPfIAB)
		XXxlOLJ9KRjPH382WVCvr6n71 = sorted(items,reverse=HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࡌࡡ࡭ࡵࡨẑ"),key=lambda key: key[qHYIWnOZLPkrQU].lower()[LAQD5wEkr18bUiGaYen3J(u"࠸ṏ"):])
		if XX8FguGmKp5DVB2Twifsc: PGudrhJF8iDkSq96XVHEQZYf5L(mshLJcKH1fv03yRnDOr4ZT,uVQd103XyvUce2EBtzbYaC(u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࠪᵟ")+e6aUA48hu3LR[:-qHYIWnOZLPkrQU],group,XXxlOLJ9KRjPH382WVCvr6n71,t58tnzAgevxkoIOdMFbE2PsD64q0C9)
	if vvWwO3Tx2dAgcijrFXq(u"ࠩࡢࡖࡆࡔࡄࡐࡏࡢࠫᵠ") in SHk0ThDndgJW and len(XXxlOLJ9KRjPH382WVCvr6n71)>nZHjx0b2qvhI8BVikRNEJD6mlK:
		GyjmfosC59Jub[:] = []
		MQtuaShrKTbdZFJ5nsR7D(QQdAXWBc2GPw(u"ࠪࡪࡴࡲࡤࡦࡴࠪᵡ"),QQdAXWBc2GPw(u"ࠫࡠ࠭ᵢ")+rC3Tlno96KjLDIvBaSWUbR8+group+hAIp8kmC36T5WFPMSXOwnNbtD+Mmpr0o76iWJvz1kTtfgI8hES(u"ࠬࠦ࠺ศๆๅื๊ࡣࠧᵣ"),group,Xz3bA2PFENVCUtplu51(u"࠵࠻࠻Ṑ"),b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,e6aUA48hu3LR+DYakr9g4PVU(u"࠭࡟ࡓࡃࡑࡈࡔࡓ࡟ࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᵤ"))
		MQtuaShrKTbdZFJ5nsR7D(uVQd103XyvUce2EBtzbYaC(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᵥ"),shC5qBRV2A0lZ(u"ࠨว฼หิฯࠠศๆฺ่อࠦวๅ฻ื์ฬฬ๊ࠡ็้ࠤ๋็ำࠡษ็ๆุ๋ࠧᵦ"),group,HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"࠶࠼࠵ṑ"),b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,e6aUA48hu3LR+P0qdZI384LKleuo(u"ࠩࡢࡖࡆࡔࡄࡐࡏࡢࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᵧ"))
		MQtuaShrKTbdZFJ5nsR7D(yST5AHEfvPmcWpwGuh2BJ(u"ࠪࡰ࡮ࡴ࡫ࠨᵨ"),rC3Tlno96KjLDIvBaSWUbR8+ubxGUTt1LraKhVZgpAP(u"ࠫࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡࠩᵩ")+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"࠿࠹࠺࠻Ṓ"))
		XXxlOLJ9KRjPH382WVCvr6n71 = GyjmfosC59Jub+qHiNBx6PXjKatkWf37AwFClzsp2DmE.sample(XXxlOLJ9KRjPH382WVCvr6n71,nZHjx0b2qvhI8BVikRNEJD6mlK)
	GyjmfosC59Jub[:] = XXxlOLJ9KRjPH382WVCvr6n71
	qMGn9u2ckaXejCgUQhYTDP(HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࡆࡢ࡮ࡶࡩẒ"))
	return
def rEVJhGQvyk061TPNAYcsIdD(SHk0ThDndgJW):
	MQtuaShrKTbdZFJ5nsR7D(kke1PDGRBLuY8y(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᵪ"),Mmpr0o76iWJvz1kTtfgI8hES(u"࠭ลฺษาอࠥ฽ไษࠢๅ๊ํอสࠡ฻ื์ฬฬ๊สࠩᵫ"),b8Qe150xVaJsnDSv,RRIHDFjoW9w7bSfVPhC(u"࠱࠷࠳ṓ"),b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡒࡉࡗࡇࡗ࡚ࡤࡥࡒࡂࡐࡇࡓࡒࡥࠧᵬ"))
	MQtuaShrKTbdZFJ5nsR7D(Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠨ࡮࡬ࡲࡰ࠭ᵭ"),rC3Tlno96KjLDIvBaSWUbR8+RRIHDFjoW9w7bSfVPhC(u"ࠩࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦࠧᵮ")+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,VFjQx6Is28KvzLOmMXtg4GqTwa3(u"࠺࠻࠼࠽Ṕ"))
	fZtAMSduHjqsoklbJ = GyjmfosC59Jub[:]
	GyjmfosC59Jub[:] = []
	import NuMiSoKYQF
	NuMiSoKYQF.iyZpId2R5sL7F0kDb3AKH9xS(mQNonhS7CV2BXOv(u"ࠪ࠴ࠬᵯ"),Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࡇࡣ࡯ࡷࡪẓ"))
	NuMiSoKYQF.iyZpId2R5sL7F0kDb3AKH9xS(QQdAXWBc2GPw(u"ࠫ࠶࠭ᵰ"),TT8Mxv5Wq7nlC9IscdpPUY6(u"ࡈࡤࡰࡸ࡫Ẕ"))
	NuMiSoKYQF.iyZpId2R5sL7F0kDb3AKH9xS(UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠬ࠸ࠧᵱ"),QQdAXWBc2GPw(u"ࡉࡥࡱࡹࡥẕ"))
	if IjZbnrBJmM2N(u"࠭࡟ࡓࡃࡑࡈࡔࡓ࡟ࠨᵲ") in SHk0ThDndgJW:
		GyjmfosC59Jub[:] = cLNZiAESGJd(GyjmfosC59Jub)
		if len(GyjmfosC59Jub)>nZHjx0b2qvhI8BVikRNEJD6mlK: GyjmfosC59Jub[:] = qHiNBx6PXjKatkWf37AwFClzsp2DmE.sample(GyjmfosC59Jub,nZHjx0b2qvhI8BVikRNEJD6mlK)
	GyjmfosC59Jub[:] = fZtAMSduHjqsoklbJ+GyjmfosC59Jub
	return
def aP9sO7CMmyXZ3v(SHk0ThDndgJW):
	SHk0ThDndgJW = SHk0ThDndgJW.replace(TYf7Dc06PQgy1vEV9(u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᵳ"),b8Qe150xVaJsnDSv).replace(UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᵴ"),b8Qe150xVaJsnDSv)
	headers = { Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ᵵ") : b8Qe150xVaJsnDSv }
	url = Nh0BWuiSndf(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡤࡨࡷࡹࡸࡡ࡯ࡦࡲࡱࡸ࠴ࡣࡰ࡯࠲ࡶࡦࡴࡤࡰ࡯࠰ࡥࡷࡧࡢࡪࡥ࠰ࡻࡴࡸࡤࡴࠩᵶ")
	data = {TYf7Dc06PQgy1vEV9(u"ࠫࡶࡻࡡ࡯ࡶ࡬ࡸࡾ࠭ᵷ"):mQNonhS7CV2BXOv(u"ࠬ࠻࠰ࠨᵸ")}
	data = uVsW5TNRM2vDOn(data)
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(IiYS8Jg4da3UuDP0qr6vy,Mmpr0o76iWJvz1kTtfgI8hES(u"࠭ࡇࡆࡖࠪᵹ"),url,data,headers,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,P0qdZI384LKleuo(u"ࠧࡓࡃࡑࡈࡔࡓࡓ࠮ࡔࡄࡒࡉࡕࡍࡠࡘࡌࡈࡊࡕࡓࡠࡈࡕࡓࡒࡥࡗࡐࡔࡇࡗ࠲࠷ࡳࡵࠩᵺ"))
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall(Xz3bA2PFENVCUtplu51(u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡥࡲࡲࡹ࡫࡮ࡵࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡤ࡮ࡨࡥࡷ࡬ࡩࡹࠤࠪᵻ"),jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[LzYQg91SIxDeOGtCKd5]
	items = YYBlm36zd0Jst18LXwo4.findall(zI3ROAZtiUq42rE9WDST68(u"ࠩ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄ࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄࠧᵼ"),OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	rrsRyBWIDmwnTx10,c7b5xkrKOzW = list(zip(*items))
	SgDZKEOfulXG4wJYBj17 = []
	vZfrwCnVuDePxzYLoQym2tlM = [pldxivXC5wbTB2O8q,IjZbnrBJmM2N(u"ࠪࠦࠬᵽ"),QTUBCcehw6qPd4x(u"ࠫࡥ࠭ᵾ"),QQdAXWBc2GPw(u"ࠬ࠲ࠧᵿ"),shC5qBRV2A0lZ(u"࠭࠮ࠨᶀ"),Mmpr0o76iWJvz1kTtfgI8hES(u"ࠧ࠻ࠩᶁ"),LAQD5wEkr18bUiGaYen3J(u"ࠨ࠽ࠪᶂ"),zI3ROAZtiUq42rE9WDST68(u"ࠤࠪࠦᶃ"),uVQd103XyvUce2EBtzbYaC(u"ࠪ࠱ࠬᶄ")]
	Uuy4hv0XBZlDS1FY3GCR = c7b5xkrKOzW+rrsRyBWIDmwnTx10
	for fJIhxFzQlSnT9H in Uuy4hv0XBZlDS1FY3GCR:
		if fJIhxFzQlSnT9H in c7b5xkrKOzW: z0zle3YSqBQCGkF1bNHgcOTPs = IgQimel18t
		if fJIhxFzQlSnT9H in rrsRyBWIDmwnTx10: z0zle3YSqBQCGkF1bNHgcOTPs = NvHugPosYDzRJ
		hQvkyxzrPD4JXwLKg3iIS9nuB1CT2 = [FbcUxvE17ewlWNBHgS8Jn in fJIhxFzQlSnT9H for FbcUxvE17ewlWNBHgS8Jn in vZfrwCnVuDePxzYLoQym2tlM]
		if any(hQvkyxzrPD4JXwLKg3iIS9nuB1CT2):
			tmaChESsDcO9dxLW4GQb = hQvkyxzrPD4JXwLKg3iIS9nuB1CT2.index(QTUBCcehw6qPd4x(u"ࡘࡷࡻࡥẖ"))
			Yp6IkeiVWJzcoUtTHOyBAEF = vZfrwCnVuDePxzYLoQym2tlM[tmaChESsDcO9dxLW4GQb]
			ov0GLRdOyuUelW3XPs = b8Qe150xVaJsnDSv
			if fJIhxFzQlSnT9H.count(Yp6IkeiVWJzcoUtTHOyBAEF)>qHYIWnOZLPkrQU: xHjfs7bnC9YUNXlO,mp1FB7c9hIfwYy0x,ov0GLRdOyuUelW3XPs = fJIhxFzQlSnT9H.split(Yp6IkeiVWJzcoUtTHOyBAEF,IgQimel18t)
			else: xHjfs7bnC9YUNXlO,mp1FB7c9hIfwYy0x = fJIhxFzQlSnT9H.split(Yp6IkeiVWJzcoUtTHOyBAEF,qHYIWnOZLPkrQU)
			if len(xHjfs7bnC9YUNXlO)>z0zle3YSqBQCGkF1bNHgcOTPs: SgDZKEOfulXG4wJYBj17.append(xHjfs7bnC9YUNXlO.lower())
			if len(mp1FB7c9hIfwYy0x)>z0zle3YSqBQCGkF1bNHgcOTPs: SgDZKEOfulXG4wJYBj17.append(mp1FB7c9hIfwYy0x.lower())
			if len(ov0GLRdOyuUelW3XPs)>z0zle3YSqBQCGkF1bNHgcOTPs: SgDZKEOfulXG4wJYBj17.append(ov0GLRdOyuUelW3XPs.lower())
		elif len(fJIhxFzQlSnT9H)>z0zle3YSqBQCGkF1bNHgcOTPs: SgDZKEOfulXG4wJYBj17.append(fJIhxFzQlSnT9H.lower())
	for FbcUxvE17ewlWNBHgS8Jn in range(mmcNLrXtzfpyCkZlvK5VwG2gujh(u"࠻ṕ")): qHiNBx6PXjKatkWf37AwFClzsp2DmE.shuffle(SgDZKEOfulXG4wJYBj17)
	if Nh0BWuiSndf(u"ࠫࡤ࡙ࡉࡕࡇࡖࡣࠬᶅ") in SHk0ThDndgJW:
		S3VYgtJK8ohcAeZyvI2L1Ea4Nfmq6 = WOXHyD1V5jBlvRSQzYtp87
	elif m6hwdgP31a2zjN7lkpX(u"ࠬࡥࡉࡑࡖ࡙ࡣࠬᶆ") in SHk0ThDndgJW:
		S3VYgtJK8ohcAeZyvI2L1Ea4Nfmq6 = [UUkIBz1sgQ9WfNeG6trKXvu0(u"࠭ࡉࡑࡖ࡙ࠫᶇ")]
		import CC4xSVuWXg
		if not CC4xSVuWXg.yyq2ZDzu5wSeCKA84pxf7PRWTOrBtY(b8Qe150xVaJsnDSv,LAQD5wEkr18bUiGaYen3J(u"࡙ࡸࡵࡦẗ")): return
	elif zI3ROAZtiUq42rE9WDST68(u"ࠧࡠࡏ࠶࡙ࡤ࠭ᶈ") in SHk0ThDndgJW:
		S3VYgtJK8ohcAeZyvI2L1Ea4Nfmq6 = [Xz3bA2PFENVCUtplu51(u"ࠨࡏ࠶࡙ࠬᶉ")]
		import pxFlVO8bCG
		if not pxFlVO8bCG.yyq2ZDzu5wSeCKA84pxf7PRWTOrBtY(b8Qe150xVaJsnDSv,mmcNLrXtzfpyCkZlvK5VwG2gujh(u"࡚ࡲࡶࡧẘ")): return
	count,n8lispZovO5A9aw7VeQNf36 = LzYQg91SIxDeOGtCKd5,LzYQg91SIxDeOGtCKd5
	MQtuaShrKTbdZFJ5nsR7D(BmePGjS7FxK6kutUM(u"ࠩࡩࡳࡱࡪࡥࡳࠩᶊ"),mQNonhS7CV2BXOv(u"ࠪ࡟ࠥࠦ࡝ࠡ࠼ส่อำหࠡ฻้ࠫᶋ"),b8Qe150xVaJsnDSv,S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"࠴࠺࠹Ṗ"),b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,LAQD5wEkr18bUiGaYen3J(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᶌ")+SHk0ThDndgJW)
	MQtuaShrKTbdZFJ5nsR7D(RRIHDFjoW9w7bSfVPhC(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᶍ"),Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"࠭ลฺษาอࠥอไษฯฮࠤฬู๊ี๊สส๏࠭ᶎ"),b8Qe150xVaJsnDSv,VFjQx6Is28KvzLOmMXtg4GqTwa3(u"࠵࠻࠺ṗ"),b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᶏ")+SHk0ThDndgJW)
	MQtuaShrKTbdZFJ5nsR7D(Nh0BWuiSndf(u"ࠨ࡮࡬ࡲࡰ࠭ᶐ"),rC3Tlno96KjLDIvBaSWUbR8+Mmpr0o76iWJvz1kTtfgI8hES(u"ࠩࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦࠧᶑ")+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"࠾࠿࠹࠺Ṙ"))
	Up5Xd86cnaZVl9Bm23gAyxNJT1 = GyjmfosC59Jub[:]
	GyjmfosC59Jub[:] = []
	gBehm96XWFVkJa0UryYHq1v3 = []
	for fJIhxFzQlSnT9H in SgDZKEOfulXG4wJYBj17:
		mp1FB7c9hIfwYy0x = YYBlm36zd0Jst18LXwo4.findall(dDYUoKi6JFM23p(u"ࠪ࡟ࠥࡢࠬ࡝࠽࡟࠾ࡡ࠳࡜ࠬ࡞ࡀࡠࠧࡢࠧ࡝࡝࡟ࡡࡡ࠮࡜ࠪ࡞ࡾࡠࢂࡢࠡ࡝ࡂࠪᶒ")+ddo23ZJtgcY(u"ࠫࠨ࠭ᶓ")+HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠬࡢࠤ࡝ࠧ࡟ࡢࡡࠬ࡜ࠫ࡞ࡢࡠࡁࡢ࠾࡞ࠩᶔ"),fJIhxFzQlSnT9H,YYBlm36zd0Jst18LXwo4.DOTALL)
		if mp1FB7c9hIfwYy0x: fJIhxFzQlSnT9H = fJIhxFzQlSnT9H.split(mp1FB7c9hIfwYy0x[LzYQg91SIxDeOGtCKd5],qHYIWnOZLPkrQU)[LzYQg91SIxDeOGtCKd5]
		aBNWJUPIo28LlAYvyqbp = fJIhxFzQlSnT9H.replace(ubxGUTt1LraKhVZgpAP(u"࠭๑ࠨᶕ"),b8Qe150xVaJsnDSv).replace(shC5qBRV2A0lZ(u"ࠧ๏ࠩᶖ"),b8Qe150xVaJsnDSv).replace(HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠨํࠪᶗ"),b8Qe150xVaJsnDSv).replace(mQNonhS7CV2BXOv(u"ࠩ๒ࠫᶘ"),b8Qe150xVaJsnDSv).replace(ddo23ZJtgcY(u"ࠪ๐ࠬᶙ"),b8Qe150xVaJsnDSv)
		aBNWJUPIo28LlAYvyqbp = aBNWJUPIo28LlAYvyqbp.replace(ubxGUTt1LraKhVZgpAP(u"ࠫ๕࠭ᶚ"),b8Qe150xVaJsnDSv).replace(Mmpr0o76iWJvz1kTtfgI8hES(u"ࠬ๓ࠧᶛ"),b8Qe150xVaJsnDSv).replace(QQdAXWBc2GPw(u"࠭๒ࠨᶜ"),b8Qe150xVaJsnDSv).replace(QTUBCcehw6qPd4x(u"ࠧญࠩᶝ"),b8Qe150xVaJsnDSv).replace(dDYUoKi6JFM23p(u"ࠨโࠪᶞ"),b8Qe150xVaJsnDSv)
		if aBNWJUPIo28LlAYvyqbp: gBehm96XWFVkJa0UryYHq1v3.append(aBNWJUPIo28LlAYvyqbp)
	RgbEG4NxAOnaiFzPQdYBuCUI5cX8mK = []
	for s9s45taoNBh60XL1zykOmTK3jJCrE in range(LzYQg91SIxDeOGtCKd5,ddo23ZJtgcY(u"࠸࠰ṙ")):
		search = qHiNBx6PXjKatkWf37AwFClzsp2DmE.sample(gBehm96XWFVkJa0UryYHq1v3,qHYIWnOZLPkrQU)[LzYQg91SIxDeOGtCKd5]
		if search in RgbEG4NxAOnaiFzPQdYBuCUI5cX8mK: continue
		RgbEG4NxAOnaiFzPQdYBuCUI5cX8mK.append(search)
		TFAmLfwypkzsP1UYCMr8c = qHiNBx6PXjKatkWf37AwFClzsp2DmE.sample(S3VYgtJK8ohcAeZyvI2L1Ea4Nfmq6,qHYIWnOZLPkrQU)[LzYQg91SIxDeOGtCKd5]
		mwIxD3GBPgLVc2aq9(MtTygrzXFlQ,EECz06teoykrNFfq(QQ8pvXNcBfVkP5rRJ7o)+zI3ROAZtiUq42rE9WDST68(u"ࠩࠣࠤࠥࡘࡡ࡯ࡦࡲࡱࠥ࡜ࡩࡥࡧࡲࠤࡘ࡫ࡡࡳࡥ࡫ࠤࠥࠦࡳࡪࡶࡨ࠾ࠬᶟ")+str(TFAmLfwypkzsP1UYCMr8c)+BWNPxIG7vqdTy85pjHzUOrK3(u"ࠪࠤࠥࡹࡥࡢࡴࡦ࡬࠿࠭ᶠ")+search)
		drHgqFcWbNv82tVEhDMT5,Bgb2Tkp6fK0CGvWYUZFtAzr,bhNwipmnY26A83qIEyDt0jQTso = MMUq0NsIxei5bK(TFAmLfwypkzsP1UYCMr8c)
		Bgb2Tkp6fK0CGvWYUZFtAzr(search+zI3ROAZtiUq42rE9WDST68(u"ࠫࡤࡔࡏࡅࡋࡄࡐࡔࡍࡓࡠࠩᶡ"))
		if len(GyjmfosC59Jub)>LzYQg91SIxDeOGtCKd5: break
	search = search.replace(shC5qBRV2A0lZ(u"ࠬࡥࡍࡐࡆࡢࠫᶢ"),b8Qe150xVaJsnDSv)
	Up5Xd86cnaZVl9Bm23gAyxNJT1[LzYQg91SIxDeOGtCKd5][qHYIWnOZLPkrQU] = m6hwdgP31a2zjN7lkpX(u"࡛࠭ࠨᶣ")+rC3Tlno96KjLDIvBaSWUbR8+search+hAIp8kmC36T5WFPMSXOwnNbtD+TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠧࠡ࠼หัะูࠦ็࡟ࠪᶤ")
	GyjmfosC59Jub[:] = cLNZiAESGJd(GyjmfosC59Jub)
	if len(GyjmfosC59Jub)>nZHjx0b2qvhI8BVikRNEJD6mlK: GyjmfosC59Jub[:] = qHiNBx6PXjKatkWf37AwFClzsp2DmE.sample(GyjmfosC59Jub,nZHjx0b2qvhI8BVikRNEJD6mlK)
	GyjmfosC59Jub[:] = Up5Xd86cnaZVl9Bm23gAyxNJT1+GyjmfosC59Jub
	return
def ee6XVSAhPap2do31mrFZsGWTLY(x2y78AKLwO9,SHk0ThDndgJW):
	x2y78AKLwO9 = x2y78AKLwO9.replace(mQNonhS7CV2BXOv(u"ࠨࡡࡐࡓࡉࡥࠧᶥ"),b8Qe150xVaJsnDSv)
	SHk0ThDndgJW = SHk0ThDndgJW.replace(Nh0BWuiSndf(u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᶦ"),b8Qe150xVaJsnDSv).replace(S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧᶧ"),b8Qe150xVaJsnDSv)
	tt5JWsFHp82aL(ubxGUTt1LraKhVZgpAP(u"ࡆࡢ࡮ࡶࡩẙ"))
	if not p2MSNUTiP4QaYJ: return
	if shC5qBRV2A0lZ(u"ࠫࡤࡘࡁࡏࡆࡒࡑࡤ࠭ᶨ") in SHk0ThDndgJW:
		MQtuaShrKTbdZFJ5nsR7D(TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᶩ"),ubxGUTt1LraKhVZgpAP(u"࡛࠭ࠨᶪ")+rC3Tlno96KjLDIvBaSWUbR8+x2y78AKLwO9+hAIp8kmC36T5WFPMSXOwnNbtD+mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠧࠡ࠼ส่็ูๅ࡞ࠩᶫ"),x2y78AKLwO9,yST5AHEfvPmcWpwGuh2BJ(u"࠱࠷࠸Ṛ"),b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,BmePGjS7FxK6kutUM(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᶬ")+SHk0ThDndgJW)
		MQtuaShrKTbdZFJ5nsR7D(Xz3bA2PFENVCUtplu51(u"ࠩࡩࡳࡱࡪࡥࡳࠩᶭ"),ddo23ZJtgcY(u"ࠪษ฾อฯสࠢส่฼๊ศࠡษ็฽ู๎วว์้๋ࠣࠦๆโีࠣห้่ำๆࠩᶮ"),x2y78AKLwO9,mQNonhS7CV2BXOv(u"࠲࠸࠹ṛ"),b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,Nh0BWuiSndf(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᶯ")+SHk0ThDndgJW)
		MQtuaShrKTbdZFJ5nsR7D(BWNPxIG7vqdTy85pjHzUOrK3(u"ࠬࡲࡩ࡯࡭ࠪᶰ"),rC3Tlno96KjLDIvBaSWUbR8+ubxGUTt1LraKhVZgpAP(u"࠭࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫᶱ")+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,RRIHDFjoW9w7bSfVPhC(u"࠻࠼࠽࠾Ṝ"))
	for website in sorted(list(p2MSNUTiP4QaYJ[x2y78AKLwO9].keys())):
		type,c17XeRIH2gVh3px8sw,url,nYUxlDOpbX32Qtw,I6YPOSofrpnTwRm8b,NGQDwOCXx1BZmd9Huc,pnmsJqCWIHVk2Y6xPvl9Q0Ez8r,wc0Z9FAdf2B1J,XXra5dzn8tcLOxYZIE7pPof49Hh = p2MSNUTiP4QaYJ[x2y78AKLwO9][website]
		if VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠧࡠࡔࡄࡒࡉࡕࡍࡠࠩᶲ") in SHk0ThDndgJW or len(p2MSNUTiP4QaYJ[x2y78AKLwO9])==qHYIWnOZLPkrQU:
			fPYwhSsFOBLbt7rM902im4oVE(type,b8Qe150xVaJsnDSv,url,nYUxlDOpbX32Qtw,b8Qe150xVaJsnDSv,NGQDwOCXx1BZmd9Huc,pnmsJqCWIHVk2Y6xPvl9Q0Ez8r,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv)
			GyjmfosC59Jub[:] = cLNZiAESGJd(GyjmfosC59Jub)
			qqokExPK8XLUhsyl,cLtYxpHVoAgd = GyjmfosC59Jub[:VwApyDY1Jc],GyjmfosC59Jub[VwApyDY1Jc:]
			if DYakr9g4PVU(u"ࠨࡡࡕࡅࡓࡊࡏࡎࡡࠪᶳ") in SHk0ThDndgJW:
				for FbcUxvE17ewlWNBHgS8Jn in range(m6hwdgP31a2zjN7lkpX(u"࠼ṝ")): qHiNBx6PXjKatkWf37AwFClzsp2DmE.shuffle(cLtYxpHVoAgd)
				GyjmfosC59Jub[:] = qqokExPK8XLUhsyl+cLtYxpHVoAgd[:nZHjx0b2qvhI8BVikRNEJD6mlK]
			else: GyjmfosC59Jub[:] = qqokExPK8XLUhsyl+cLtYxpHVoAgd
		elif RRIHDFjoW9w7bSfVPhC(u"ࠩࡢࡗࡎ࡚ࡅࡔࡡࠪᶴ") in SHk0ThDndgJW: MQtuaShrKTbdZFJ5nsR7D(Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠪࡪࡴࡲࡤࡦࡴࠪᶵ"),website,url,nYUxlDOpbX32Qtw,I6YPOSofrpnTwRm8b,NGQDwOCXx1BZmd9Huc,pnmsJqCWIHVk2Y6xPvl9Q0Ez8r,wc0Z9FAdf2B1J,XXra5dzn8tcLOxYZIE7pPof49Hh)
	return
def DrSlA2gw8fQB1kmV(SHk0ThDndgJW,ZZtDTHnBXMz):
	SHk0ThDndgJW = SHk0ThDndgJW.replace(UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᶶ"),b8Qe150xVaJsnDSv).replace(IjZbnrBJmM2N(u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᶷ"),b8Qe150xVaJsnDSv)
	c17XeRIH2gVh3px8sw,cLtYxpHVoAgd = b8Qe150xVaJsnDSv,[]
	MQtuaShrKTbdZFJ5nsR7D(SbjiWeHLQPoazqwp3cODkd7YxVgn(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᶸ"),LAQD5wEkr18bUiGaYen3J(u"ࠧ࡜ࠩᶹ")+rC3Tlno96KjLDIvBaSWUbR8+c17XeRIH2gVh3px8sw+hAIp8kmC36T5WFPMSXOwnNbtD+QTUBCcehw6qPd4x(u"ࠨࠢ࠽ห้่ำๆ࡟ࠪᶺ"),b8Qe150xVaJsnDSv,ZZtDTHnBXMz,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,IjZbnrBJmM2N(u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧᶻ")+SHk0ThDndgJW)
	MQtuaShrKTbdZFJ5nsR7D(RRIHDFjoW9w7bSfVPhC(u"ࠪࡪࡴࡲࡤࡦࡴࠪᶼ"),Xz3bA2PFENVCUtplu51(u"ࠫส฿วะหࠣ฻้ฮࠠใี่ࠤ฾ฺ่ศศํࠫᶽ"),b8Qe150xVaJsnDSv,ZZtDTHnBXMz,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,QTUBCcehw6qPd4x(u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᶾ")+SHk0ThDndgJW)
	MQtuaShrKTbdZFJ5nsR7D(Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"࠭࡬ࡪࡰ࡮ࠫᶿ"),rC3Tlno96KjLDIvBaSWUbR8+ubxGUTt1LraKhVZgpAP(u"ࠧ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࠬ᷀")+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,mmcNLrXtzfpyCkZlvK5VwG2gujh(u"࠽࠾࠿࠹Ṟ"))
	qqokExPK8XLUhsyl = GyjmfosC59Jub[:]
	GyjmfosC59Jub[:] = []
	XXxlOLJ9KRjPH382WVCvr6n71 = []
	if SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠨࡡࡖࡍ࡙ࡋࡓࡠࠩ᷁") in SHk0ThDndgJW:
		tt5JWsFHp82aL(RRIHDFjoW9w7bSfVPhC(u"ࡇࡣ࡯ࡷࡪẚ"))
		if not p2MSNUTiP4QaYJ: return
		ZZUl0IWvS8XkHj12BpA = list(p2MSNUTiP4QaYJ.keys())
		x2y78AKLwO9 = qHiNBx6PXjKatkWf37AwFClzsp2DmE.sample(ZZUl0IWvS8XkHj12BpA,qHYIWnOZLPkrQU)[LzYQg91SIxDeOGtCKd5]
		SgDZKEOfulXG4wJYBj17 = list(p2MSNUTiP4QaYJ[x2y78AKLwO9].keys())
		website = qHiNBx6PXjKatkWf37AwFClzsp2DmE.sample(SgDZKEOfulXG4wJYBj17,qHYIWnOZLPkrQU)[LzYQg91SIxDeOGtCKd5]
		type,c17XeRIH2gVh3px8sw,url,nYUxlDOpbX32Qtw,I6YPOSofrpnTwRm8b,NGQDwOCXx1BZmd9Huc,pnmsJqCWIHVk2Y6xPvl9Q0Ez8r,wc0Z9FAdf2B1J,XXra5dzn8tcLOxYZIE7pPof49Hh = p2MSNUTiP4QaYJ[x2y78AKLwO9][website]
		mwIxD3GBPgLVc2aq9(MtTygrzXFlQ,EECz06teoykrNFfq(QQ8pvXNcBfVkP5rRJ7o)+HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠩࠣࠤࠥࡘࡡ࡯ࡦࡲࡱࠥࡉࡡࡵࡧࡪࡳࡷࡿࠠࠡࠢࡺࡩࡧࡹࡩࡵࡧ࠽ࠤ᷂ࠬ")+website+mQNonhS7CV2BXOv(u"ࠪࠤࠥࠦ࡮ࡢ࡯ࡨ࠾ࠥ࠭᷃")+c17XeRIH2gVh3px8sw+BmePGjS7FxK6kutUM(u"ࠫࠥࠦࠠࡶࡴ࡯࠾ࠥ࠭᷄")+url+mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠬࠦࠠࠡ࡯ࡲࡨࡪࡀࠠࠨ᷅")+str(nYUxlDOpbX32Qtw))
	elif mmcNLrXtzfpyCkZlvK5VwG2gujh(u"࠭࡟ࡊࡒࡗ࡚ࡤ࠭᷆") in SHk0ThDndgJW:
		import CC4xSVuWXg
		if not CC4xSVuWXg.yyq2ZDzu5wSeCKA84pxf7PRWTOrBtY(b8Qe150xVaJsnDSv,yST5AHEfvPmcWpwGuh2BJ(u"ࡖࡵࡹࡪẛ")): return
		for Bm6RlzFt7j10nr395yLAoDuiIaq in range(qHYIWnOZLPkrQU,PINQnUL6h3XA9at+qHYIWnOZLPkrQU):
			XXxlOLJ9KRjPH382WVCvr6n71 += mkVxqa8XjHOTID7MthNBl(str(Bm6RlzFt7j10nr395yLAoDuiIaq),SHk0ThDndgJW)
		if not XXxlOLJ9KRjPH382WVCvr6n71: return
		type,c17XeRIH2gVh3px8sw,url,nYUxlDOpbX32Qtw,I6YPOSofrpnTwRm8b,NGQDwOCXx1BZmd9Huc,pnmsJqCWIHVk2Y6xPvl9Q0Ez8r,wc0Z9FAdf2B1J,XXra5dzn8tcLOxYZIE7pPof49Hh = qHiNBx6PXjKatkWf37AwFClzsp2DmE.sample(XXxlOLJ9KRjPH382WVCvr6n71,qHYIWnOZLPkrQU)[LzYQg91SIxDeOGtCKd5]
		mwIxD3GBPgLVc2aq9(MtTygrzXFlQ,EECz06teoykrNFfq(QQ8pvXNcBfVkP5rRJ7o)+mQNonhS7CV2BXOv(u"ࠧࠡࠢࠣࡖࡦࡴࡤࡰ࡯ࠣࡇࡦࡺࡥࡨࡱࡵࡽࠥࠦࠠ࡯ࡣࡰࡩ࠿ࠦࠧ᷇")+c17XeRIH2gVh3px8sw+dDYUoKi6JFM23p(u"ࠨࠢࠣࠤࡺࡸ࡬࠻ࠢࠪ᷈")+url+uVQd103XyvUce2EBtzbYaC(u"ࠩࠣࠤࠥࡳ࡯ࡥࡧ࠽ࠤࠬ᷉")+str(nYUxlDOpbX32Qtw))
	elif VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠪࡣࡒ࠹ࡕࡠ᷊ࠩ") in SHk0ThDndgJW:
		import pxFlVO8bCG
		if not pxFlVO8bCG.yyq2ZDzu5wSeCKA84pxf7PRWTOrBtY(b8Qe150xVaJsnDSv,kke1PDGRBLuY8y(u"ࡗࡶࡺ࡫ẜ")): return
		for Bm6RlzFt7j10nr395yLAoDuiIaq in range(qHYIWnOZLPkrQU,PINQnUL6h3XA9at+qHYIWnOZLPkrQU):
			XXxlOLJ9KRjPH382WVCvr6n71 += Z6nTjPWKV3pwLG7DdEYt(str(Bm6RlzFt7j10nr395yLAoDuiIaq),SHk0ThDndgJW)
		if not XXxlOLJ9KRjPH382WVCvr6n71: return
		type,c17XeRIH2gVh3px8sw,url,nYUxlDOpbX32Qtw,I6YPOSofrpnTwRm8b,NGQDwOCXx1BZmd9Huc,pnmsJqCWIHVk2Y6xPvl9Q0Ez8r,wc0Z9FAdf2B1J,XXra5dzn8tcLOxYZIE7pPof49Hh = qHiNBx6PXjKatkWf37AwFClzsp2DmE.sample(XXxlOLJ9KRjPH382WVCvr6n71,qHYIWnOZLPkrQU)[LzYQg91SIxDeOGtCKd5]
		mwIxD3GBPgLVc2aq9(MtTygrzXFlQ,EECz06teoykrNFfq(QQ8pvXNcBfVkP5rRJ7o)+zI3ROAZtiUq42rE9WDST68(u"ࠫࠥࠦࠠࡓࡣࡱࡨࡴࡳࠠࡄࡣࡷࡩ࡬ࡵࡲࡺࠢࠣࠤࡳࡧ࡭ࡦ࠼ࠣࠫ᷋")+c17XeRIH2gVh3px8sw+TYf7Dc06PQgy1vEV9(u"ࠬࠦࠠࠡࡷࡵࡰ࠿ࠦࠧ᷌")+url+Mmpr0o76iWJvz1kTtfgI8hES(u"࠭ࠠࠡࠢࡰࡳࡩ࡫࠺ࠡࠩ᷍")+str(nYUxlDOpbX32Qtw))
	HSDdX1RCKv7oQhWwzBZcVO = c17XeRIH2gVh3px8sw
	TUO3MF9d4fEo6Re = []
	for FbcUxvE17ewlWNBHgS8Jn in range(LzYQg91SIxDeOGtCKd5,HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"࠶࠶ṟ")):
		if FbcUxvE17ewlWNBHgS8Jn>LzYQg91SIxDeOGtCKd5: mwIxD3GBPgLVc2aq9(MtTygrzXFlQ,EECz06teoykrNFfq(QQ8pvXNcBfVkP5rRJ7o)+Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠧࠡࠢࠣࡖࡦࡴࡤࡰ࡯ࠣࡇࡦࡺࡥࡨࡱࡵࡽࠥࠦࠠ࡯ࡣࡰࡩ࠿᷎ࠦࠧ")+c17XeRIH2gVh3px8sw+mQNonhS7CV2BXOv(u"ࠨࠢࠣࠤࡺࡸ࡬࠻᷏ࠢࠪ")+url+BmePGjS7FxK6kutUM(u"ࠩࠣࠤࠥࡳ࡯ࡥࡧ࠽ࠤ᷐ࠬ")+str(nYUxlDOpbX32Qtw))
		GyjmfosC59Jub[:] = []
		if nYUxlDOpbX32Qtw==ddo23ZJtgcY(u"࠸࠳࠵Ṡ") and ubxGUTt1LraKhVZgpAP(u"ࠪࡣࡤࡏࡐࡕࡘࡖࡩࡷ࡯ࡥࡴࡡࡢࠫ᷑") in pnmsJqCWIHVk2Y6xPvl9Q0Ez8r: nYUxlDOpbX32Qtw = mmcNLrXtzfpyCkZlvK5VwG2gujh(u"࠲࠴࠵ṡ")
		if nYUxlDOpbX32Qtw==Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"࠸࠳࠷Ṣ") and uVQd103XyvUce2EBtzbYaC(u"ࠫࡤࡥࡍ࠴ࡗࡖࡩࡷ࡯ࡥࡴࡡࡢࠫ᷒") in pnmsJqCWIHVk2Y6xPvl9Q0Ez8r: nYUxlDOpbX32Qtw = HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"࠹࠴࠷ṣ")
		if nYUxlDOpbX32Qtw==LAQD5wEkr18bUiGaYen3J(u"࠴࠸࠹Ṥ"): nYUxlDOpbX32Qtw = QQdAXWBc2GPw(u"࠶࠾࠷ṥ")
		jprAaOYCD6yM8P5VZXK1B2ldNbuR = fPYwhSsFOBLbt7rM902im4oVE(type,c17XeRIH2gVh3px8sw,url,nYUxlDOpbX32Qtw,I6YPOSofrpnTwRm8b,NGQDwOCXx1BZmd9Huc,pnmsJqCWIHVk2Y6xPvl9Q0Ez8r,wc0Z9FAdf2B1J,XXra5dzn8tcLOxYZIE7pPof49Hh)
		if mQNonhS7CV2BXOv(u"ࠬࡥࡉࡑࡖ࡙ࡣࠬᷓ") in SHk0ThDndgJW and nYUxlDOpbX32Qtw==SbjiWeHLQPoazqwp3cODkd7YxVgn(u"࠶࠼࠷Ṧ"): del GyjmfosC59Jub[:VwApyDY1Jc]
		if BmePGjS7FxK6kutUM(u"࠭࡟ࡎ࠵ࡘࡣࠬᷔ") in SHk0ThDndgJW and nYUxlDOpbX32Qtw==m6hwdgP31a2zjN7lkpX(u"࠷࠶࠹ṧ"): del GyjmfosC59Jub[:VwApyDY1Jc]
		cLtYxpHVoAgd[:] = cLNZiAESGJd(GyjmfosC59Jub)
		if TUO3MF9d4fEo6Re and rfoi91Gyj64WCYJsvc(QQdAXWBc2GPw(u"ࡵࠨฯ็ๆฮ࠭ᷕ")) in str(cLtYxpHVoAgd) or rfoi91Gyj64WCYJsvc(m6hwdgP31a2zjN7lkpX(u"ࡶࠩะ่็ํࠧᷖ")) in str(cLtYxpHVoAgd):
			c17XeRIH2gVh3px8sw = HSDdX1RCKv7oQhWwzBZcVO
			cLtYxpHVoAgd[:] = TUO3MF9d4fEo6Re
			break
		HSDdX1RCKv7oQhWwzBZcVO = c17XeRIH2gVh3px8sw
		TUO3MF9d4fEo6Re = cLtYxpHVoAgd
		if str(cLtYxpHVoAgd).count(Xz3bA2PFENVCUtplu51(u"ࠩࡹ࡭ࡩ࡫࡯ࠨᷗ"))>LzYQg91SIxDeOGtCKd5: break
		if str(cLtYxpHVoAgd).count(DYakr9g4PVU(u"ࠪࡰ࡮ࡼࡥࠨᷘ"))>LzYQg91SIxDeOGtCKd5: break
		if nYUxlDOpbX32Qtw==yST5AHEfvPmcWpwGuh2BJ(u"࠲࠴࠵Ṩ"): break
		if nYUxlDOpbX32Qtw==QTUBCcehw6qPd4x(u"࠸࠳࠶ṩ"): break
		if nYUxlDOpbX32Qtw==vvWwO3Tx2dAgcijrFXq(u"࠴࠼࠵Ṫ"): break
		if ubxGUTt1LraKhVZgpAP(u"ࠫࡤࡘࡁࡏࡆࡒࡑࡤ࠭ᷙ") in SHk0ThDndgJW and cLtYxpHVoAgd: type,c17XeRIH2gVh3px8sw,url,nYUxlDOpbX32Qtw,I6YPOSofrpnTwRm8b,NGQDwOCXx1BZmd9Huc,pnmsJqCWIHVk2Y6xPvl9Q0Ez8r,wc0Z9FAdf2B1J,XXra5dzn8tcLOxYZIE7pPof49Hh = qHiNBx6PXjKatkWf37AwFClzsp2DmE.sample(cLtYxpHVoAgd,qHYIWnOZLPkrQU)[LzYQg91SIxDeOGtCKd5]
	if not c17XeRIH2gVh3px8sw: c17XeRIH2gVh3px8sw = SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠬ࠴࠮࠯࠰ࠪᷚ")
	elif c17XeRIH2gVh3px8sw.count(yST5AHEfvPmcWpwGuh2BJ(u"࠭࡟ࠨᷛ"))>qHYIWnOZLPkrQU: c17XeRIH2gVh3px8sw = c17XeRIH2gVh3px8sw.split(dDYUoKi6JFM23p(u"ࠧࡠࠩᷜ"),IgQimel18t)[IgQimel18t]
	c17XeRIH2gVh3px8sw = c17XeRIH2gVh3px8sw.replace(BmePGjS7FxK6kutUM(u"ࠨࡗࡑࡏࡓࡕࡗࡏ࠼ࠣࠫᷝ"),b8Qe150xVaJsnDSv)
	c17XeRIH2gVh3px8sw = c17XeRIH2gVh3px8sw.replace(yST5AHEfvPmcWpwGuh2BJ(u"ࠩࡢࡑࡔࡊ࡟ࠨᷞ"),b8Qe150xVaJsnDSv)
	qqokExPK8XLUhsyl[LzYQg91SIxDeOGtCKd5][qHYIWnOZLPkrQU] = Mmpr0o76iWJvz1kTtfgI8hES(u"ࠪ࡟ࠬᷟ")+rC3Tlno96KjLDIvBaSWUbR8+c17XeRIH2gVh3px8sw+hAIp8kmC36T5WFPMSXOwnNbtD+LAQD5wEkr18bUiGaYen3J(u"ࠫࠥࡀวๅไึ้ࡢ࠭ᷠ")
	if Nh0BWuiSndf(u"ࠬࡥࡒࡂࡐࡇࡓࡒࡥࠧᷡ") in SHk0ThDndgJW:
		for FbcUxvE17ewlWNBHgS8Jn in range(Xz3bA2PFENVCUtplu51(u"࠼ṫ")): qHiNBx6PXjKatkWf37AwFClzsp2DmE.shuffle(cLtYxpHVoAgd)
		GyjmfosC59Jub[:] = qqokExPK8XLUhsyl+cLtYxpHVoAgd[:nZHjx0b2qvhI8BVikRNEJD6mlK]
	else: GyjmfosC59Jub[:] = qqokExPK8XLUhsyl+cLtYxpHVoAgd
	return
def XIo0nOJVGsRrZ2SMNP718xwWkH4hl(HXlfkR0FWtwJMITzcp7jQd,AAksS4wnRZHLfGcI):
	AAksS4wnRZHLfGcI = AAksS4wnRZHLfGcI.replace(VFjQx6Is28KvzLOmMXtg4GqTwa3(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᷢ"),b8Qe150xVaJsnDSv).replace(SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᷣ"),b8Qe150xVaJsnDSv)
	PzetpISRnA = AAksS4wnRZHLfGcI
	if P0qdZI384LKleuo(u"ࠨࡡࡢࡍࡕ࡚ࡖࡔࡧࡵ࡭ࡪࡹ࡟ࡠࠩᷤ") in AAksS4wnRZHLfGcI:
		PzetpISRnA = AAksS4wnRZHLfGcI.split(kke1PDGRBLuY8y(u"ࠩࡢࡣࡎࡖࡔࡗࡕࡨࡶ࡮࡫ࡳࡠࡡࠪᷥ"))[LzYQg91SIxDeOGtCKd5]
		type = mQNonhS7CV2BXOv(u"ࠪ࠰ࡘࡋࡒࡊࡇࡖ࠾ࠥ࠭ᷦ")
	elif Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"࡛ࠫࡕࡄࠨᷧ") in HXlfkR0FWtwJMITzcp7jQd: type = HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠬ࠲ࡖࡊࡆࡈࡓࡘࡀࠠࠨᷨ")
	elif TYf7Dc06PQgy1vEV9(u"࠭ࡌࡊࡘࡈࠫᷩ") in HXlfkR0FWtwJMITzcp7jQd: type = m6hwdgP31a2zjN7lkpX(u"ࠧ࠭ࡎࡌ࡚ࡊࡀࠠࠨᷪ")
	MQtuaShrKTbdZFJ5nsR7D(HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᷫ"),mQNonhS7CV2BXOv(u"ࠩ࡞ࠫᷬ")+rC3Tlno96KjLDIvBaSWUbR8+type+PzetpISRnA+hAIp8kmC36T5WFPMSXOwnNbtD+dDYUoKi6JFM23p(u"ࠪࠤ࠿อไใี่ࡡࠬᷭ"),HXlfkR0FWtwJMITzcp7jQd,shC5qBRV2A0lZ(u"࠵࠻࠽Ṭ"),b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,yST5AHEfvPmcWpwGuh2BJ(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᷮ")+AAksS4wnRZHLfGcI)
	MQtuaShrKTbdZFJ5nsR7D(shC5qBRV2A0lZ(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᷯ"),mmcNLrXtzfpyCkZlvK5VwG2gujh(u"࠭ลฺษาอࠥอไุๆหࠤฬู๊ี๊สส๏ࠦๅ็้ࠢๅุࠦวๅไึ้ࠬᷰ"),HXlfkR0FWtwJMITzcp7jQd,zI3ROAZtiUq42rE9WDST68(u"࠶࠼࠷ṭ"),b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᷱ")+AAksS4wnRZHLfGcI)
	MQtuaShrKTbdZFJ5nsR7D(P0qdZI384LKleuo(u"ࠨ࡮࡬ࡲࡰ࠭ᷲ"),rC3Tlno96KjLDIvBaSWUbR8+S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠩࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦࠧᷳ")+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,dDYUoKi6JFM23p(u"࠿࠹࠺࠻Ṯ"))
	import CC4xSVuWXg
	for Bm6RlzFt7j10nr395yLAoDuiIaq in range(qHYIWnOZLPkrQU,PINQnUL6h3XA9at+qHYIWnOZLPkrQU):
		if ubxGUTt1LraKhVZgpAP(u"ࠪࡣࡤࡏࡐࡕࡘࡖࡩࡷ࡯ࡥࡴࡡࡢࠫᷴ") in AAksS4wnRZHLfGcI: CC4xSVuWXg.YhgBJAG0zwX5i(str(Bm6RlzFt7j10nr395yLAoDuiIaq),HXlfkR0FWtwJMITzcp7jQd,AAksS4wnRZHLfGcI,b8Qe150xVaJsnDSv,QQdAXWBc2GPw(u"ࡊࡦࡲࡳࡦẝ"))
		else: CC4xSVuWXg.iyZpId2R5sL7F0kDb3AKH9xS(str(Bm6RlzFt7j10nr395yLAoDuiIaq),HXlfkR0FWtwJMITzcp7jQd,AAksS4wnRZHLfGcI,b8Qe150xVaJsnDSv,QTUBCcehw6qPd4x(u"ࡋࡧ࡬ࡴࡧẞ"))
	GyjmfosC59Jub[:] = cLNZiAESGJd(GyjmfosC59Jub)
	if len(GyjmfosC59Jub)>(nZHjx0b2qvhI8BVikRNEJD6mlK+VwApyDY1Jc): GyjmfosC59Jub[:] = GyjmfosC59Jub[:VwApyDY1Jc]+qHiNBx6PXjKatkWf37AwFClzsp2DmE.sample(GyjmfosC59Jub[VwApyDY1Jc:],nZHjx0b2qvhI8BVikRNEJD6mlK)
	return
def SKvnJrtwe4xBoY38VE9lUjX(HXlfkR0FWtwJMITzcp7jQd,AAksS4wnRZHLfGcI):
	AAksS4wnRZHLfGcI = AAksS4wnRZHLfGcI.replace(dDYUoKi6JFM23p(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭᷵"),b8Qe150xVaJsnDSv).replace(LAQD5wEkr18bUiGaYen3J(u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ᷶"),b8Qe150xVaJsnDSv)
	PzetpISRnA = AAksS4wnRZHLfGcI
	if LAQD5wEkr18bUiGaYen3J(u"࠭࡟ࡠࡏ࠶࡙ࡘ࡫ࡲࡪࡧࡶࡣࡤ᷷࠭") in AAksS4wnRZHLfGcI:
		PzetpISRnA = AAksS4wnRZHLfGcI.split(Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠧࡠࡡࡐ࠷࡚࡙ࡥࡳ࡫ࡨࡷࡤࡥ᷸ࠧ"))[LzYQg91SIxDeOGtCKd5]
		type = Nh0BWuiSndf(u"ࠨ࠮ࡖࡉࡗࡏࡅࡔ࠼᷹ࠣࠫ")
	elif UUkIBz1sgQ9WfNeG6trKXvu0(u"࡙ࠩࡓࡉ᷺࠭") in HXlfkR0FWtwJMITzcp7jQd: type = TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠪ࠰࡛ࡏࡄࡆࡑࡖ࠾ࠥ࠭᷻")
	elif IjZbnrBJmM2N(u"ࠫࡑࡏࡖࡆࠩ᷼") in HXlfkR0FWtwJMITzcp7jQd: type = m6hwdgP31a2zjN7lkpX(u"ࠬ࠲ࡌࡊࡘࡈ࠾᷽ࠥ࠭")
	MQtuaShrKTbdZFJ5nsR7D(Nh0BWuiSndf(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭᷾"),BmePGjS7FxK6kutUM(u"ࠧ࡜᷿ࠩ")+rC3Tlno96KjLDIvBaSWUbR8+type+PzetpISRnA+hAIp8kmC36T5WFPMSXOwnNbtD+S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠨࠢ࠽ห้่ำๆ࡟ࠪḀ"),HXlfkR0FWtwJMITzcp7jQd,ubxGUTt1LraKhVZgpAP(u"࠱࠷࠺ṯ"),b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧḁ")+AAksS4wnRZHLfGcI)
	MQtuaShrKTbdZFJ5nsR7D(Mmpr0o76iWJvz1kTtfgI8hES(u"ࠪࡪࡴࡲࡤࡦࡴࠪḂ"),Xz3bA2PFENVCUtplu51(u"ࠫส฿วะหࠣห้฽ไษࠢส่฾ฺ่ศศํࠤ๊์ࠠ็ใึࠤฬ๊โิ็ࠪḃ"),HXlfkR0FWtwJMITzcp7jQd,IjZbnrBJmM2N(u"࠲࠸࠻Ṱ"),b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,QQdAXWBc2GPw(u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪḄ")+AAksS4wnRZHLfGcI)
	MQtuaShrKTbdZFJ5nsR7D(QTUBCcehw6qPd4x(u"࠭࡬ࡪࡰ࡮ࠫḅ"),rC3Tlno96KjLDIvBaSWUbR8+TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠧ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࠬḆ")+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,LAQD5wEkr18bUiGaYen3J(u"࠻࠼࠽࠾ṱ"))
	import pxFlVO8bCG
	for Bm6RlzFt7j10nr395yLAoDuiIaq in range(qHYIWnOZLPkrQU,PINQnUL6h3XA9at+qHYIWnOZLPkrQU):
		if Xz3bA2PFENVCUtplu51(u"ࠨࡡࡢࡑ࠸࡛ࡓࡦࡴ࡬ࡩࡸࡥ࡟ࠨḇ") in AAksS4wnRZHLfGcI: pxFlVO8bCG.YhgBJAG0zwX5i(str(Bm6RlzFt7j10nr395yLAoDuiIaq),HXlfkR0FWtwJMITzcp7jQd,AAksS4wnRZHLfGcI,b8Qe150xVaJsnDSv,SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࡌࡡ࡭ࡵࡨẟ"))
		else: pxFlVO8bCG.iyZpId2R5sL7F0kDb3AKH9xS(str(Bm6RlzFt7j10nr395yLAoDuiIaq),HXlfkR0FWtwJMITzcp7jQd,AAksS4wnRZHLfGcI,b8Qe150xVaJsnDSv,SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࡆࡢ࡮ࡶࡩẠ"))
	GyjmfosC59Jub[:] = cLNZiAESGJd(GyjmfosC59Jub)
	if len(GyjmfosC59Jub)>(nZHjx0b2qvhI8BVikRNEJD6mlK+VwApyDY1Jc): GyjmfosC59Jub[:] = GyjmfosC59Jub[:VwApyDY1Jc]+qHiNBx6PXjKatkWf37AwFClzsp2DmE.sample(GyjmfosC59Jub[VwApyDY1Jc:],nZHjx0b2qvhI8BVikRNEJD6mlK)
	return
def cLNZiAESGJd(GyjmfosC59Jub):
	QdHR4GsCq8 = []
	for type,c17XeRIH2gVh3px8sw,url,ZZtDTHnBXMz,I6YPOSofrpnTwRm8b,NGQDwOCXx1BZmd9Huc,pnmsJqCWIHVk2Y6xPvl9Q0Ez8r,wc0Z9FAdf2B1J,XXra5dzn8tcLOxYZIE7pPof49Hh in GyjmfosC59Jub:
		if yST5AHEfvPmcWpwGuh2BJ(u"ุࠩๅาฯࠧḈ") in c17XeRIH2gVh3px8sw or Nh0BWuiSndf(u"ูࠪๆำ็ࠨḉ") in c17XeRIH2gVh3px8sw or Mmpr0o76iWJvz1kTtfgI8hES(u"ࠫࡵࡧࡧࡦࠩḊ") in c17XeRIH2gVh3px8sw.lower(): continue
		QdHR4GsCq8.append([type,c17XeRIH2gVh3px8sw,url,ZZtDTHnBXMz,I6YPOSofrpnTwRm8b,NGQDwOCXx1BZmd9Huc,pnmsJqCWIHVk2Y6xPvl9Q0Ez8r,wc0Z9FAdf2B1J,XXra5dzn8tcLOxYZIE7pPof49Hh])
	return QdHR4GsCq8
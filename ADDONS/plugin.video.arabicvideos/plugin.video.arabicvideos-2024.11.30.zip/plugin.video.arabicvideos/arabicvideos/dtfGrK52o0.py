# -*- coding: utf-8 -*-
from hIVCFnfxSO import *
QQ8pvXNcBfVkP5rRJ7o = 'ALFATIMI'
WbzmKSZiuOYrBN7oysJ2dUv = '_FTM_'
wQjs1XZ3AO24g8y9bEeoKMiGIu7 = nTHXJIiah2qK[QQ8pvXNcBfVkP5rRJ7o][0]
sfcHjMK1uLG5eUQbON0CTn = ['1239','1250','1245','20','1259','218','485','1238','1258','292']
kI2gVpuJGq6EBr1FQ0boSDtcxNZdY = ['3030','628']
def x8IFqMZeJj7suCR4AaGoNXfEHm(mode,url,text):
	if   mode==60: XXxlOLJ9KRjPH382WVCvr6n71 = Y72YmLgw4vqlHxTCkbeKSicasD()
	elif mode==61: XXxlOLJ9KRjPH382WVCvr6n71 = Je4TwC30iOG5DLKWAtbYvhs(url,text)
	elif mode==62: XXxlOLJ9KRjPH382WVCvr6n71 = bIpskeGhBlqH(url)
	elif mode==63: XXxlOLJ9KRjPH382WVCvr6n71 = Hkij627uCDJKyIM(url)
	elif mode==64: XXxlOLJ9KRjPH382WVCvr6n71 = QPVI5LC2nEsUyFwOth4beg(text)
	elif mode==69: XXxlOLJ9KRjPH382WVCvr6n71 = kstJfK6jHQWrXDSMRIGB7(text)
	else: XXxlOLJ9KRjPH382WVCvr6n71 = False
	return XXxlOLJ9KRjPH382WVCvr6n71
def Y72YmLgw4vqlHxTCkbeKSicasD():
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'بحث في الموقع',b8Qe150xVaJsnDSv,69,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'_REMEMBERRESULTS_')
	MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+'ما يتم مشاهدته الان',wQjs1XZ3AO24g8y9bEeoKMiGIu7,64,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'recent_viewed_vids')
	MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+'الاكثر مشاهدة',wQjs1XZ3AO24g8y9bEeoKMiGIu7,64,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'most_viewed_vids')
	MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+'اضيفت مؤخرا',wQjs1XZ3AO24g8y9bEeoKMiGIu7,64,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'recently_added_vids')
	MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+'فيديو عشوائي',wQjs1XZ3AO24g8y9bEeoKMiGIu7,64,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'random_vids')
	MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+'افلام ومسلسلات',wQjs1XZ3AO24g8y9bEeoKMiGIu7,61,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'-1')
	MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+'البرامج الدينية',wQjs1XZ3AO24g8y9bEeoKMiGIu7,61,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'-2')
	MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+'English Videos',wQjs1XZ3AO24g8y9bEeoKMiGIu7,61,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'-3')
	return b8Qe150xVaJsnDSv
def Je4TwC30iOG5DLKWAtbYvhs(url,Z8s0Lov2UiWF1qGjO):
	j9uNmf0TqMwYFCzBpyObXQPia1rRA = b8Qe150xVaJsnDSv
	if Z8s0Lov2UiWF1qGjO not in ['-1','-2','-3']: j9uNmf0TqMwYFCzBpyObXQPia1rRA = '?cat='+Z8s0Lov2UiWF1qGjO
	MUJCtfYVBLODrFbaZn = wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/menu_level.php'+j9uNmf0TqMwYFCzBpyObXQPia1rRA
	jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(GMkNL1RXxKFentp0Zh9d,MUJCtfYVBLODrFbaZn,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'ALFATIMI-TITLES-1st')
	items = YYBlm36zd0Jst18LXwo4.findall('href=\'(.*?)\'.*?>(.*?)<.*?>(.*?)</span>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	fe4ZQ6kdYJHcLSyW8GCU2PNzq,ap7kVRWP42Dvj0zml6GwC9nu = False,False
	for pcA1dzy7LXwGfMPg9mTkuh5tine3,title,count in items:
		title = pTP49ckGDYrofa2KxenumbH0(title)
		title = title.strip(pldxivXC5wbTB2O8q)
		if 'http' not in pcA1dzy7LXwGfMPg9mTkuh5tine3: pcA1dzy7LXwGfMPg9mTkuh5tine3 = 'http:'+pcA1dzy7LXwGfMPg9mTkuh5tine3
		j9uNmf0TqMwYFCzBpyObXQPia1rRA = YYBlm36zd0Jst18LXwo4.findall('cat=(.*?)&',pcA1dzy7LXwGfMPg9mTkuh5tine3,YYBlm36zd0Jst18LXwo4.DOTALL)[0]
		if Z8s0Lov2UiWF1qGjO==j9uNmf0TqMwYFCzBpyObXQPia1rRA: fe4ZQ6kdYJHcLSyW8GCU2PNzq = True
		elif fe4ZQ6kdYJHcLSyW8GCU2PNzq 	or (Z8s0Lov2UiWF1qGjO=='-1' and j9uNmf0TqMwYFCzBpyObXQPia1rRA in sfcHjMK1uLG5eUQbON0CTn)  						or (Z8s0Lov2UiWF1qGjO=='-2' and j9uNmf0TqMwYFCzBpyObXQPia1rRA not in kI2gVpuJGq6EBr1FQ0boSDtcxNZdY and j9uNmf0TqMwYFCzBpyObXQPia1rRA not in sfcHjMK1uLG5eUQbON0CTn)  						or (Z8s0Lov2UiWF1qGjO=='-3' and j9uNmf0TqMwYFCzBpyObXQPia1rRA in kI2gVpuJGq6EBr1FQ0boSDtcxNZdY):
							if count=='1': MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,63)
							else: MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,61,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,j9uNmf0TqMwYFCzBpyObXQPia1rRA)
							ap7kVRWP42Dvj0zml6GwC9nu = True
	if not ap7kVRWP42Dvj0zml6GwC9nu: bIpskeGhBlqH(url)
	return
def bIpskeGhBlqH(url):
	jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(GMkNL1RXxKFentp0Zh9d,url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,True,'ALFATIMI-EPISODES-1st')
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('pagination(.*?)id="footer',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
	items = YYBlm36zd0Jst18LXwo4.findall('grid_view.*?src="(.*?)".*?title="(.*?)".*?<h2.*?href="(.*?)"',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	pcA1dzy7LXwGfMPg9mTkuh5tine3 = b8Qe150xVaJsnDSv
	for lvtGpMZHb9,title,pcA1dzy7LXwGfMPg9mTkuh5tine3 in items:
		title = title.replace('Add',b8Qe150xVaJsnDSv).replace('to Quicklist',b8Qe150xVaJsnDSv).strip(pldxivXC5wbTB2O8q)
		if 'http' not in pcA1dzy7LXwGfMPg9mTkuh5tine3: pcA1dzy7LXwGfMPg9mTkuh5tine3 = 'http:'+pcA1dzy7LXwGfMPg9mTkuh5tine3
		MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,63,lvtGpMZHb9)
	ZV5rRvabhxJ=YYBlm36zd0Jst18LXwo4.findall('(.*?)div',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	OTKx7aVb2hdS16Wrweky4FXfIN0g9=ZV5rRvabhxJ[0]
	OTKx7aVb2hdS16Wrweky4FXfIN0g9=YYBlm36zd0Jst18LXwo4.findall('pagination(.*?)</div>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)[0]
	items=YYBlm36zd0Jst18LXwo4.findall('href="(.*?)".*?>(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	MUJCtfYVBLODrFbaZn = url.split('?')[0]
	for pcA1dzy7LXwGfMPg9mTkuh5tine3,Mzf60rCGbPoJIlAsYB2LmcZkO in items:
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = MUJCtfYVBLODrFbaZn + pcA1dzy7LXwGfMPg9mTkuh5tine3
		title = pTP49ckGDYrofa2KxenumbH0(Mzf60rCGbPoJIlAsYB2LmcZkO)
		title = 'صفحة ' + title
		MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,62)
	return pcA1dzy7LXwGfMPg9mTkuh5tine3
def Hkij627uCDJKyIM(url):
	if 'videos.php' in url: url = bIpskeGhBlqH(url)
	jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(Q49IsrlSuYRAVbGKhwdckLDOetF2PZ,url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,True,'ALFATIMI-PLAY-1st')
	items = YYBlm36zd0Jst18LXwo4.findall('playlistfile:"(.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	url = items[0]
	if 'http' not in url: url = 'http:'+url
	yulQjIFbzM(url,QQ8pvXNcBfVkP5rRJ7o,'video')
	return
def QPVI5LC2nEsUyFwOth4beg(Z8s0Lov2UiWF1qGjO):
	lo6biSg2NR3eUB1OpEPxzyXwF8sYWI = { 'mode' : Z8s0Lov2UiWF1qGjO }
	url = 'http://alfatimi.tv/ajax.php'
	headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
	data = uVsW5TNRM2vDOn(lo6biSg2NR3eUB1OpEPxzyXwF8sYWI)
	jLtdbeYiQHnf4SpU2MTly = MTr3igGe26HOs9ptAJF7Y1ux4vZaf(LtlXH3fvMydAx,url,data,headers,True,'ALFATIMI-MOSTS-1st')
	items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)".*?title="(.*?)".*?src="(.*?)".*?href',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	for pcA1dzy7LXwGfMPg9mTkuh5tine3,title,lvtGpMZHb9 in items:
		title = title.strip(pldxivXC5wbTB2O8q)
		if 'http' not in pcA1dzy7LXwGfMPg9mTkuh5tine3: pcA1dzy7LXwGfMPg9mTkuh5tine3 = 'http:'+pcA1dzy7LXwGfMPg9mTkuh5tine3
		MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,63,lvtGpMZHb9)
	return
def kstJfK6jHQWrXDSMRIGB7(search):
	search,v7Rxw52Z4X0,showDialogs = JimhUH0SEf6w(search)
	if search==b8Qe150xVaJsnDSv: search = FT2oXWtPQpVGuexmLqKN3srdzYn()
	if search==b8Qe150xVaJsnDSv: return
	LgXO1RhbDV7cx6EaeYCNm4zjJdBS = search.replace(pldxivXC5wbTB2O8q,'+')
	url = wQjs1XZ3AO24g8y9bEeoKMiGIu7 + '/search_result.php?query=' + LgXO1RhbDV7cx6EaeYCNm4zjJdBS
	bIpskeGhBlqH(url)
	return
# -*- coding: utf-8 -*-
import sys as Pft6y0LvwSh48iYg7b
MQBw2uYHcWbpxF8tKAV = Pft6y0LvwSh48iYg7b.version_info [0] == 2
myc93k4htNU67 = 2048
h8lCkw1d3LepDVuvfoicEXj5K6sPz = 7
def JanmRV2MtcH (VwngrDb8fEytv4kMTdQu95cIejsC):
	global oPFYqewitzj
	WBrAFcJPVXdS2UzxLEGM0omkD = ord (VwngrDb8fEytv4kMTdQu95cIejsC [-1])
	V13jmfpwhlcyCKMRLY5TiaG = VwngrDb8fEytv4kMTdQu95cIejsC [:-1]
	gyF4Uq9l1NQKCtT = WBrAFcJPVXdS2UzxLEGM0omkD % len (V13jmfpwhlcyCKMRLY5TiaG)
	BN5pdqozP2v9Ur1Swsia = V13jmfpwhlcyCKMRLY5TiaG [:gyF4Uq9l1NQKCtT] + V13jmfpwhlcyCKMRLY5TiaG [gyF4Uq9l1NQKCtT:]
	if MQBw2uYHcWbpxF8tKAV:
		D3MGYw1ceHQ4UbrNJSq = unicode () .join ([unichr (ord (bb1FgjciZqDzeQTBC2hplaPkmRIyUf) - myc93k4htNU67 - (Ni5bJjhpks6SfCc + WBrAFcJPVXdS2UzxLEGM0omkD) % h8lCkw1d3LepDVuvfoicEXj5K6sPz) for Ni5bJjhpks6SfCc, bb1FgjciZqDzeQTBC2hplaPkmRIyUf in enumerate (BN5pdqozP2v9Ur1Swsia)])
	else:
		D3MGYw1ceHQ4UbrNJSq = str () .join ([chr (ord (bb1FgjciZqDzeQTBC2hplaPkmRIyUf) - myc93k4htNU67 - (Ni5bJjhpks6SfCc + WBrAFcJPVXdS2UzxLEGM0omkD) % h8lCkw1d3LepDVuvfoicEXj5K6sPz) for Ni5bJjhpks6SfCc, bb1FgjciZqDzeQTBC2hplaPkmRIyUf in enumerate (BN5pdqozP2v9Ur1Swsia)])
	return eval (D3MGYw1ceHQ4UbrNJSq)
TYf7Dc06PQgy1vEV9,ubxGUTt1LraKhVZgpAP,Y2t8baH5GWikvOZ7NsCeq3TKrgMV=JanmRV2MtcH,JanmRV2MtcH,JanmRV2MtcH
BWNPxIG7vqdTy85pjHzUOrK3,Mmpr0o76iWJvz1kTtfgI8hES,QTUBCcehw6qPd4x=Y2t8baH5GWikvOZ7NsCeq3TKrgMV,ubxGUTt1LraKhVZgpAP,TYf7Dc06PQgy1vEV9
mQNonhS7CV2BXOv,HwB7ydlWVJeCtPuQ6MDE1RTYOo,uVQd103XyvUce2EBtzbYaC=QTUBCcehw6qPd4x,Mmpr0o76iWJvz1kTtfgI8hES,BWNPxIG7vqdTy85pjHzUOrK3
yST5AHEfvPmcWpwGuh2BJ,BmePGjS7FxK6kutUM,S0IlDPhBN3gMEUvnjRLXsYAc2Zf=uVQd103XyvUce2EBtzbYaC,HwB7ydlWVJeCtPuQ6MDE1RTYOo,mQNonhS7CV2BXOv
Xz3bA2PFENVCUtplu51,LAQD5wEkr18bUiGaYen3J,P0qdZI384LKleuo=S0IlDPhBN3gMEUvnjRLXsYAc2Zf,BmePGjS7FxK6kutUM,yST5AHEfvPmcWpwGuh2BJ
shC5qBRV2A0lZ,mmcNLrXtzfpyCkZlvK5VwG2gujh,m6hwdgP31a2zjN7lkpX=P0qdZI384LKleuo,LAQD5wEkr18bUiGaYen3J,Xz3bA2PFENVCUtplu51
IjZbnrBJmM2N,Nh0BWuiSndf,kke1PDGRBLuY8y=m6hwdgP31a2zjN7lkpX,mmcNLrXtzfpyCkZlvK5VwG2gujh,shC5qBRV2A0lZ
ddo23ZJtgcY,vvWwO3Tx2dAgcijrFXq,DYakr9g4PVU=kke1PDGRBLuY8y,Nh0BWuiSndf,IjZbnrBJmM2N
zI3ROAZtiUq42rE9WDST68,Dzs8qU2gQMcCSyRhiZn4TFbeGk,dDYUoKi6JFM23p=DYakr9g4PVU,vvWwO3Tx2dAgcijrFXq,ddo23ZJtgcY
QQdAXWBc2GPw,VFjQx6Is28KvzLOmMXtg4GqTwa3,TT8Mxv5Wq7nlC9IscdpPUY6=dDYUoKi6JFM23p,Dzs8qU2gQMcCSyRhiZn4TFbeGk,zI3ROAZtiUq42rE9WDST68
SbjiWeHLQPoazqwp3cODkd7YxVgn,UUkIBz1sgQ9WfNeG6trKXvu0,RRIHDFjoW9w7bSfVPhC=TT8Mxv5Wq7nlC9IscdpPUY6,VFjQx6Is28KvzLOmMXtg4GqTwa3,QQdAXWBc2GPw
from Yf92JP7d13 import *
import base64 as lnFeUkiZtQ7E1
QQ8pvXNcBfVkP5rRJ7o = Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠬࡒࡉࡃࡕࡗ࡛ࡔ࠭୳")
GyjmfosC59Jub,Jlx4HMPfuYok8zCWwhESdA29F5s,p2MSNUTiP4QaYJ = [],{},{}
TTVZUc0N8S9dpGLagCMbfvwh,Iclar5FxeNwHtTvXCEozK4kG,Tfo3HwyzGk = b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv
GrYC8nRD4ZpzWiO1NE6Vg = {}
qqEBN1GzvSmf,NEW_BADSCRAPERS = [LzYQg91SIxDeOGtCKd5],[LzYQg91SIxDeOGtCKd5]
NEW_BADWEBSITES = {}
uqTvH9CQaSkmBM1Dth = DD5cFIejQa2X4BgAu9GWPyJ3tC7
if i1thmHk7AZquD4cM0fnp62:
	XqsJV0hizL8eFDPAd5U1cBRg = AAdgh34SURPET8vfOaCJZX.translatePath(SbjiWeHLQPoazqwp3cODkd7YxVgn(u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱ࡻࡦࡲࡩࠧ୴"))
	BdO6FDlYv4naqZf1gCGbS7V = AAdgh34SURPET8vfOaCJZX.translatePath(DYakr9g4PVU(u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲࡬ࡴࡳࡥࠨ୵"))
	fLsn0J6aAZQoPNjqhyvubUDOWECdY = AAdgh34SURPET8vfOaCJZX.translatePath(zI3ROAZtiUq42rE9WDST68(u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳ࡱࡵࡧࡱࡣࡷ࡬ࠬ୶"))
	YakNVvKg8rqWUPTxef = x76PfMyAp1L2WejkU3.path.join(BdO6FDlYv4naqZf1gCGbS7V,Nh0BWuiSndf(u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫ୷"),yST5AHEfvPmcWpwGuh2BJ(u"ࠪࡈࡦࡺࡡࡣࡣࡶࡩࠬ୸"),Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠫࡆࡪࡤࡰࡰࡶ࠷࠸࠴ࡤࡣࠩ୹"))
	SgaNtcGHRZIzvWFCm5shXUb = x76PfMyAp1L2WejkU3.path.join(BdO6FDlYv4naqZf1gCGbS7V,DYakr9g4PVU(u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧ୺"),VFjQx6Is28KvzLOmMXtg4GqTwa3(u"࠭ࡄࡢࡶࡤࡦࡦࡹࡥࠨ୻"),TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠧࡗ࡫ࡨࡻࡒࡵࡤࡦࡵ࠹࠲ࡩࡨࠧ୼"))
	KmYxP4q3zoXjrU0JReM = x76PfMyAp1L2WejkU3.path.join(BdO6FDlYv4naqZf1gCGbS7V,ddo23ZJtgcY(u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪ୽"),yST5AHEfvPmcWpwGuh2BJ(u"ࠩࡇࡥࡹࡧࡢࡢࡵࡨࠫ୾"),m6hwdgP31a2zjN7lkpX(u"ࠪࡘࡪࡾࡴࡶࡴࡨࡷ࠶࠹࠮ࡥࡤࠪ୿"))
	Iceb2XPnm6a3Tqx = Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࡹࠬࡢࡵ࠱࠴ࡧ࠵ࠬ஀")
	from urllib.parse import quote as _8wLoOXBHY52mTSAzlNJ
else:
	XqsJV0hizL8eFDPAd5U1cBRg = uuxVm0bTwdnCUAL4s6NKHEBF3M.translatePath(HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰ࡺࡥࡱࡨ࠭஁"))
	BdO6FDlYv4naqZf1gCGbS7V = uuxVm0bTwdnCUAL4s6NKHEBF3M.translatePath(BmePGjS7FxK6kutUM(u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱࡫ࡳࡲ࡫ࠧஂ"))
	fLsn0J6aAZQoPNjqhyvubUDOWECdY = uuxVm0bTwdnCUAL4s6NKHEBF3M.translatePath(yST5AHEfvPmcWpwGuh2BJ(u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲ࡰࡴ࡭ࡰࡢࡶ࡫ࠫஃ"))
	YakNVvKg8rqWUPTxef = x76PfMyAp1L2WejkU3.path.join(BdO6FDlYv4naqZf1gCGbS7V,Xz3bA2PFENVCUtplu51(u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪ஄"),Mmpr0o76iWJvz1kTtfgI8hES(u"ࠩࡇࡥࡹࡧࡢࡢࡵࡨࠫஅ"),TYf7Dc06PQgy1vEV9(u"ࠪࡅࡩࡪ࡯࡯ࡵ࠵࠻࠳ࡪࡢࠨஆ"))
	SgaNtcGHRZIzvWFCm5shXUb = x76PfMyAp1L2WejkU3.path.join(BdO6FDlYv4naqZf1gCGbS7V,kke1PDGRBLuY8y(u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭இ"),shC5qBRV2A0lZ(u"ࠬࡊࡡࡵࡣࡥࡥࡸ࡫ࠧஈ"),QQdAXWBc2GPw(u"࠭ࡖࡪࡧࡺࡑࡴࡪࡥࡴ࠸࠱ࡨࡧ࠭உ"))
	KmYxP4q3zoXjrU0JReM = x76PfMyAp1L2WejkU3.path.join(BdO6FDlYv4naqZf1gCGbS7V,TYf7Dc06PQgy1vEV9(u"ࠧࡶࡵࡨࡶࡩࡧࡴࡢࠩஊ"),mQNonhS7CV2BXOv(u"ࠨࡆࡤࡸࡦࡨࡡࡴࡧࠪ஋"),mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠩࡗࡩࡽࡺࡵࡳࡧࡶ࠵࠸࠴ࡤࡣࠩ஌"))
	Iceb2XPnm6a3Tqx = TYf7Dc06PQgy1vEV9(u"ࡸࠫࡡࡻ࠰࠳ࡦ࠴ࠫ஍").encode(OVauxZzLI10vcXT74K)
	from urllib import quote as _8wLoOXBHY52mTSAzlNJ
v3Sd26atO0oRKA5ig = x76PfMyAp1L2WejkU3.path.join(fLsn0J6aAZQoPNjqhyvubUDOWECdY,m6hwdgP31a2zjN7lkpX(u"ࠫࡰࡵࡤࡪ࠰࡯ࡳ࡬࠭எ"))
o8hpvj4GIc53mBFkH6OSzYu0W = x76PfMyAp1L2WejkU3.path.join(fLsn0J6aAZQoPNjqhyvubUDOWECdY,VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠬࡱ࡯ࡥ࡫࠱ࡳࡱࡪ࠮࡭ࡱࡪࠫஏ"))
ZFGVfCnKR8wujyr3qN5tSIMPLe6 = x76PfMyAp1L2WejkU3.path.join(vIaQF8hqXeiJERYuD,TYf7Dc06PQgy1vEV9(u"࠭ࡩࡱࡶࡹ࠵ࡩࡧࡴࡢࡡࡢࡣ࠳ࡪࡢࠨஐ"))
GGrKZltkL59nDA = x76PfMyAp1L2WejkU3.path.join(vIaQF8hqXeiJERYuD,Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠧࡪࡲࡷࡺ࠷ࡪࡡࡵࡣࡢࡣࡤ࠴ࡤࡣࠩ஑"))
OQ4oLMtwZN7vch = x76PfMyAp1L2WejkU3.path.join(vIaQF8hqXeiJERYuD,yST5AHEfvPmcWpwGuh2BJ(u"ࠨ࡯࠶ࡹࡩࡧࡴࡢࡡࡢࡣ࠳ࡪࡢࠨஒ"))
KNTV1H9Dl32a6yxiUEBdvZ7qgr = x76PfMyAp1L2WejkU3.path.join(vIaQF8hqXeiJERYuD,UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠩࡩࡥࡻࡵࡵࡳ࡫ࡷࡩࡸ࠴ࡤࡢࡶࠪஓ"))
EPNsrZtDp3cXAFl0oqm4wg7OWMk = x76PfMyAp1L2WejkU3.path.join(vIaQF8hqXeiJERYuD,LAQD5wEkr18bUiGaYen3J(u"ࠪ࡭ࡵࡺࡶࡧ࡫࡯ࡩࡤࡥ࡟࠯ࡦࡤࡸࠬஔ"))
c5wOJ98CasX3VYykR1dKSN7qx = x76PfMyAp1L2WejkU3.path.join(vIaQF8hqXeiJERYuD,Nh0BWuiSndf(u"ࠫࡲ࠹ࡵࡧ࡫࡯ࡩࡤࡥ࡟࠯ࡦࡤࡸࠬக"))
fH3Ie4SrRCsFMVo98hpN = x76PfMyAp1L2WejkU3.path.join(vIaQF8hqXeiJERYuD,HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠬ࡯࡭ࡢࡩࡨࡷࠬ஖"))
FEKbY3jcTpNLfl48m7vOVDioWH2B1 = x76PfMyAp1L2WejkU3.path.join(fH3Ie4SrRCsFMVo98hpN,BmePGjS7FxK6kutUM(u"࠭ࡤࡪࡣ࡯ࡳ࡬ࡹࠧ஗"))
zzVXSsoMienKFN0JfEGZq = x76PfMyAp1L2WejkU3.path.join(fH3Ie4SrRCsFMVo98hpN,dDYUoKi6JFM23p(u"ࠧ࡯ࡱࡷ࡭࡫࡯ࡣࡢࡶ࡬ࡳࡳࡹࠧ஘"))
PYGjDSCw4zKNef9QZ3By0xn = x76PfMyAp1L2WejkU3.path.join(FEKbY3jcTpNLfl48m7vOVDioWH2B1,uVQd103XyvUce2EBtzbYaC(u"ࠨࡦ࡬ࡥࡱࡵࡧࡠ࠲࠳࠴࠵ࡥ࠮ࡱࡰࡪࠫங"))
JnlzVBayd7WFKtCOH0 = iA97UEDqm2P.Addon().getAddonInfo(DYakr9g4PVU(u"ࠩࡳࡥࡹ࡮ࠧச"))
yRbwVc1NUHOpg = x76PfMyAp1L2WejkU3.path.join(JnlzVBayd7WFKtCOH0,vvWwO3Tx2dAgcijrFXq(u"ࠪ࡭ࡨࡵ࡮࠯ࡲࡱ࡫ࠬ஛"))
iW7AtzgImn4opXCsjlVk8DRQbOc = x76PfMyAp1L2WejkU3.path.join(JnlzVBayd7WFKtCOH0,QTUBCcehw6qPd4x(u"ࠫࡹ࡮ࡵ࡮ࡤ࠱ࡴࡳ࡭ࠧஜ"))
Dfj9dpwMXCoIJyO5 = x76PfMyAp1L2WejkU3.path.join(JnlzVBayd7WFKtCOH0,QTUBCcehw6qPd4x(u"ࠬ࡬ࡡ࡯ࡣࡵࡸ࠳ࡶ࡮ࡨࠩ஝"))
pycgkiRAFNDsCI2O4PUZYlLVb8v7Q = x76PfMyAp1L2WejkU3.path.join(JnlzVBayd7WFKtCOH0,Mmpr0o76iWJvz1kTtfgI8hES(u"࠭ࡢࡢࡰࡱࡩࡷ࠴ࡰ࡯ࡩࠪஞ"))
UrBJ6g84EbzLXuIPGH = x76PfMyAp1L2WejkU3.path.join(JnlzVBayd7WFKtCOH0,Nh0BWuiSndf(u"ࠧ࡭ࡣࡱࡨࡸࡩࡡࡱࡧ࠱ࡴࡳ࡭ࠧட"))
a2npgI8ZCfb4F6VwAXYDx1 = x76PfMyAp1L2WejkU3.path.join(JnlzVBayd7WFKtCOH0,ubxGUTt1LraKhVZgpAP(u"ࠨࡲࡲࡷࡹ࡫ࡲ࠯ࡲࡱ࡫ࠬ஠"))
FdTqMKP3fjsn8g6zEyOLCNIVA7X = x76PfMyAp1L2WejkU3.path.join(JnlzVBayd7WFKtCOH0,S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠩࡦࡰࡪࡧࡲ࡭ࡱࡪࡳ࠳ࡶ࡮ࡨࠩ஡"))
aCqGkINDe78ym1UThd = x76PfMyAp1L2WejkU3.path.join(JnlzVBayd7WFKtCOH0,SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠪࡧࡱ࡫ࡡࡳࡣࡵࡸ࠳ࡶ࡮ࡨࠩ஢"))
vqLz13dHTx7IaibSmfQUNeh = x76PfMyAp1L2WejkU3.path.join(JnlzVBayd7WFKtCOH0,LAQD5wEkr18bUiGaYen3J(u"ࠫࡲ࡫࡮ࡶࡡࡵࡩࡩࡥ࠲࠱࠲ࡻ࠶࠺࠶࠮ࡱࡰࡪࠫண"))
MdhHKoP7yn8eCk6JsY9ZfBgG5bXLrj = x76PfMyAp1L2WejkU3.path.join(JnlzVBayd7WFKtCOH0,QQdAXWBc2GPw(u"ࠬࡩࡨࡢࡰࡪࡩࡱࡵࡧ࠯ࡶࡻࡸࠬத"))
ph6VQImjWsE4BT5KUnAN = x76PfMyAp1L2WejkU3.path.join(BdO6FDlYv4naqZf1gCGbS7V,QQdAXWBc2GPw(u"࠭ࡡࡥࡦࡲࡲࡸ࠭஥"))
JFdIziR9upbBfls0ZL468V = x76PfMyAp1L2WejkU3.path.join(BdO6FDlYv4naqZf1gCGbS7V,BmePGjS7FxK6kutUM(u"ࠧࡶࡵࡨࡶࡩࡧࡴࡢࠩ஦"),RRIHDFjoW9w7bSfVPhC(u"ࠨࡣࡧࡨࡴࡴ࡟ࡥࡣࡷࡥࠬ஧"),DFUIv2KGj9ke,dDYUoKi6JFM23p(u"ࠩࡶࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡽࡳ࡬ࠨந"))
qumpT0Qr1ZhUWnHO7 = x76PfMyAp1L2WejkU3.path.join(XqsJV0hizL8eFDPAd5U1cBRg,IjZbnrBJmM2N(u"ࠪࡱࡪࡪࡩࡢࠩன"),vvWwO3Tx2dAgcijrFXq(u"ࠫࡋࡵ࡮ࡵࡵࠪப"),QQdAXWBc2GPw(u"ࠬࡧࡲࡪࡣ࡯࠲ࡹࡺࡦࠨ஫"))
PINQnUL6h3XA9at = P0qdZI384LKleuo(u"࠻፾")
iP9ZMSrYOJQhB73CN2yj4Kg1p6V5aT = [UUkIBz1sgQ9WfNeG6trKXvu0(u"࠭ีโำࠪ஬"),mQNonhS7CV2BXOv(u"ࠧฤ๊็ࠫ஭"),Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠨอส๊๏࠭ம"),SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠩฮห้ัࠧய"),TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠪีฬฮูࠨர"),zI3ROAZtiUq42rE9WDST68(u"ࠫำอๅิࠩற"),UUkIBz1sgQ9WfNeG6trKXvu0(u"ูࠬวะีࠪல"),LAQD5wEkr18bUiGaYen3J(u"࠭ำศส฼ࠫள"),TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠧฬษ่๊ࠬழ"),Nh0BWuiSndf(u"ࠨฬสื฾࠭வ"),mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠩ฼หูืࠧஶ")]
HFwCdX9UYzjp = HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠪ⸿ࠥ⼣ࠠ⸫ࠢ⸾ࠫஷ")
np5lbPOG9fIher0iAqDS4 = [BmePGjS7FxK6kutUM(u"ࠫࡇࡕࡋࡓࡃࠪஸ"),UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠬࡖࡁࡏࡇࡗࠫஹ"),Mmpr0o76iWJvz1kTtfgI8hES(u"࠭ࡁࡓࡃࡅࡍࡈ࡚ࡏࡐࡐࡖࠫ஺"),yST5AHEfvPmcWpwGuh2BJ(u"ࠧࡌࡃࡕࡆࡆࡒࡁࡕࡘࠪ஻"),dDYUoKi6JFM23p(u"ࠨࡋࡉࡍࡑࡓࠧ஼"),Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠩࡌࡊࡎࡒࡍ࠮ࡃࡕࡅࡇࡏࡃࠨ஽"),kke1PDGRBLuY8y(u"ࠪࡍࡋࡏࡌࡎ࠯ࡈࡒࡌࡒࡉࡔࡊࠪா")]
np5lbPOG9fIher0iAqDS4 += [zI3ROAZtiUq42rE9WDST68(u"ࠫ࡞࡚ࡂࡠࡅࡋࡅࡓࡔࡅࡍࡕࠪி"),Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠬࡌࡁࡔࡇࡏࡌࡉ࠸ࠧீ"),uVQd103XyvUce2EBtzbYaC(u"࠭ࡁࡌࡑࡄࡑࠬு"),QTUBCcehw6qPd4x(u"ࠧࡂࡍ࡚ࡅࡒ࠭ூ"),uVQd103XyvUce2EBtzbYaC(u"ࠨࡃࡏࡑࡆࡇࡒࡆࡈࠪ௃"),LAQD5wEkr18bUiGaYen3J(u"ࠩࡖࡌࡔࡕࡆࡎࡃ࡛ࠫ௄")]
FSyeLvB1xVuYJf5 = [P0qdZI384LKleuo(u"ࠪࡐࡆࡘࡏ࡛ࡃࠪ௅"),kke1PDGRBLuY8y(u"ࠫࡋࡇࡊࡆࡔࡖࡌࡔ࡝ࠧெ"),HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"࡚ࠬࡖࡇࡗࡑࠫே"),RRIHDFjoW9w7bSfVPhC(u"࠭ࡌࡐࡆ࡜ࡒࡊ࡚ࠧை"),Mmpr0o76iWJvz1kTtfgI8hES(u"ࠧࡄࡋࡐࡅࡓࡕࡗࠨ௉"),UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠨࡕࡋࡅࡍࡏࡄࡏࡇ࡚ࡗࠬொ"),Xz3bA2PFENVCUtplu51(u"ࠩࡄࡖࡆࡈࡓࡆࡇࡇࠫோ")]
FSyeLvB1xVuYJf5 += [Xz3bA2PFENVCUtplu51(u"ࠪࡇࡎࡓࡁࡄࡎࡘࡆࠬௌ"),TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠫࡘࡎࡁࡉࡋࡇ࠸்࡚࠭"),S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"࡙ࠬࡈࡐࡈࡋࡅࠬ௎"),shC5qBRV2A0lZ(u"࠭ࡗࡆࡅࡌࡑࡆ࠷ࠧ௏"),IjZbnrBJmM2N(u"ࠧࡘࡇࡆࡍࡒࡇ࠲ࠨௐ")]
mxlEzHtB60r2n83FMY94bAcei5 = [SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠨࡖࡌࡏࡆࡇࡔࠨ௑"),vvWwO3Tx2dAgcijrFXq(u"ࠩࡄ࡝ࡑࡕࡌࠨ௒"),shC5qBRV2A0lZ(u"ࠪࡊࡔ࡙ࡔࡂࠩ௓"),mQNonhS7CV2BXOv(u"ࠫࡋࡇࡂࡓࡃࡎࡅࠬ௔"),IjZbnrBJmM2N(u"ࠬ࡟ࡁࡒࡑࡗࠫ௕"),mQNonhS7CV2BXOv(u"࠭ࡓࡉࡃࡅࡅࡐࡇࡔ࡚ࠩ௖"),TYf7Dc06PQgy1vEV9(u"ࠧࡗࡃࡕࡆࡔࡔࠧௗ"),ddo23ZJtgcY(u"ࠨࡄࡕࡗ࡙ࡋࡊࠨ௘")]
mxlEzHtB60r2n83FMY94bAcei5 += [P0qdZI384LKleuo(u"ࠩࡎࡍࡗࡓࡁࡍࡍࠪ௙"),BmePGjS7FxK6kutUM(u"ࠪࡅࡓࡏࡍࡆ࡜ࡌࡈࠬ௚"),Mmpr0o76iWJvz1kTtfgI8hES(u"ࠫࡋࡇࡒࡆࡕࡎࡓࠬ௛"),shC5qBRV2A0lZ(u"ࠬࡎࡁࡍࡃࡆࡍࡒࡇࠧ௜"),zI3ROAZtiUq42rE9WDST68(u"࠭ࡁࡍࡏࡖࡘࡇࡇࠧ௝"),QTUBCcehw6qPd4x(u"ࠧࡔࡊࡒࡓࡋࡔࡅࡕࠩ௞"),BmePGjS7FxK6kutUM(u"ࠨࡆࡕࡅࡒࡇࡓ࠸ࠩ௟")]
mxlEzHtB60r2n83FMY94bAcei5 += [Xz3bA2PFENVCUtplu51(u"ࠩࡆࡍࡒࡇࡆࡓࡇࡈࠫ௠"),mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠪࡇࡎࡓࡁࡇࡃࡑࡗࠬ௡"),dDYUoKi6JFM23p(u"ࠫࡊࡒࡉࡇࡘࡌࡈࡊࡕࠧ௢"),uVQd103XyvUce2EBtzbYaC(u"ࠬࡌࡕࡏࡑࡑࡘ࡛࠭௣"),shC5qBRV2A0lZ(u"࠭ࡃࡊࡏࡄࡐࡎࡍࡈࡕࠩ௤"),uVQd103XyvUce2EBtzbYaC(u"ࠧࡄࡋࡐࡅ࠹࠶࠰ࠨ௥"),P0qdZI384LKleuo(u"ࠨࡅࡌࡑࡆࡇࡂࡅࡑࠪ௦")]
mxlEzHtB60r2n83FMY94bAcei5 += [Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠩࡄࡏ࡜ࡇࡍࡕࡗࡅࡉࠬ௧"),Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠪࡑࡆ࡙ࡁࡗࡋࡇࡉࡔ࠭௨"),Xz3bA2PFENVCUtplu51(u"ࠫࡉࡘࡁࡎࡃࡆࡅࡋࡋࠧ௩"),Xz3bA2PFENVCUtplu51(u"ࠬࡌࡕࡔࡊࡄࡖ࡙࡜ࠧ௪"),IjZbnrBJmM2N(u"࠭ࡃࡊࡏࡄ࡛ࡇࡇࡓࠨ௫"),BWNPxIG7vqdTy85pjHzUOrK3(u"ࠧࡂࡊ࡚ࡅࡐ࠭௬"),S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠨࡘࡌࡈࡊࡕࡎࡔࡃࡈࡑࠬ௭")]
mxlEzHtB60r2n83FMY94bAcei5 += [DYakr9g4PVU(u"ࠩࡎࡅ࡙ࡑࡏࡕࡖ࡙ࠫ௮"),QQdAXWBc2GPw(u"ࠪࡗࡊࡘࡉࡆࡕࡗࡍࡒࡋࠧ௯"),shC5qBRV2A0lZ(u"ࠫࡋ࡛ࡓࡉࡃࡕ࡚ࡎࡊࡅࡐࠩ௰"),uVQd103XyvUce2EBtzbYaC(u"ࠬࡉࡉࡎࡃ࠷ࡔࠬ௱"),LAQD5wEkr18bUiGaYen3J(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠱ࠨ௲"),SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠳ࠩ௳"),P0qdZI384LKleuo(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠶ࠪ௴")]
zcsZ9kQCPD5HqgreY7iROuUW0 = [ddo23ZJtgcY(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪ௵"),TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱࡛ࡏࡄࡆࡑࡖࠫ௶"),VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡖࡌࡂ࡛ࡏࡍࡘ࡚ࡓࠨ௷"),SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡃࡉࡃࡑࡒࡊࡒࡓࠨ௸")]
zcsZ9kQCPD5HqgreY7iROuUW0 += [TYf7Dc06PQgy1vEV9(u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑࠫ௹"),Nh0BWuiSndf(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲࡜ࡉࡅࡇࡒࡗࠬ௺"),ddo23ZJtgcY(u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡐࡍࡃ࡜ࡐࡎ࡙ࡔࡔࠩ௻"),TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡄࡊࡄࡒࡓࡋࡌࡔࠩ௼"),kke1PDGRBLuY8y(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡎࡌ࡚ࡊ࡙ࠧ௽"),SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯ࡋࡅࡘࡎࡔࡂࡉࡖࠫ௾")]
zcsZ9kQCPD5HqgreY7iROuUW0 += [shC5qBRV2A0lZ(u"ࠬࡏࡐࡕࡘࠪ௿"),m6hwdgP31a2zjN7lkpX(u"࠭ࡉࡑࡖ࡙࠱ࡑࡏࡖࡆࠩఀ"),SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠧࡊࡒࡗ࡚࠲ࡓࡏࡗࡋࡈࡗࠬఁ"),Mmpr0o76iWJvz1kTtfgI8hES(u"ࠨࡋࡓࡘ࡛࠳ࡓࡆࡔࡌࡉࡘ࠭ం")]
zcsZ9kQCPD5HqgreY7iROuUW0 += [ddo23ZJtgcY(u"ࠩࡐ࠷࡚࠭ః"),IjZbnrBJmM2N(u"ࠪࡑ࠸࡛࠭ࡍࡋ࡙ࡉࠬఄ"),m6hwdgP31a2zjN7lkpX(u"ࠫࡒ࠹ࡕ࠮ࡏࡒ࡚ࡎࡋࡓࠨఅ"),UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠬࡓ࠳ࡖ࠯ࡖࡉࡗࡏࡅࡔࠩఆ")]
kT4dIMNtgJXAxUWfFBHQLlPoK2qb6 = [TYf7Dc06PQgy1vEV9(u"࠭ࡆࡖࡕࡋࡅࡗ࡚ࡖࠨఇ"),mQNonhS7CV2BXOv(u"ࠧࡅࡔࡄࡑࡆࡉࡁࡇࡇࠪఈ"),Xz3bA2PFENVCUtplu51(u"ࠨࡅࡌࡑࡆ࠺࠰࠱ࠩఉ"),zI3ROAZtiUq42rE9WDST68(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠷ࠫఊ"),DYakr9g4PVU(u"ࠪࡐࡆࡘࡏ࡛ࡃࠪఋ")]
E43MVUOlPeYvHQ8uNI2ysJzx95kKBr = [TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠫ࡞࡚ࡂࡠࡅࡋࡅࡓࡔࡅࡍࡕࠪఌ")]
XYmrMhzn2gk  = [Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠬࡇࡋࡘࡃࡐࠫ఍"),dDYUoKi6JFM23p(u"࠭ࡁࡓࡃࡅࡗࡊࡋࡄࠨఎ"),P0qdZI384LKleuo(u"ࠧࡃࡑࡎࡖࡆ࠭ఏ"),vvWwO3Tx2dAgcijrFXq(u"ࠨࡃࡎࡓࡆࡓࠧఐ"),RRIHDFjoW9w7bSfVPhC(u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅࠫ఑"),vvWwO3Tx2dAgcijrFXq(u"ࠪࡊࡆࡈࡒࡂࡍࡄࠫఒ"),IjZbnrBJmM2N(u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠷࠭ఓ"),DYakr9g4PVU(u"ࠬࡉࡉࡎࡃࡉࡖࡊࡋࠧఔ"),vvWwO3Tx2dAgcijrFXq(u"࠭ࡃࡊࡏࡄ࠸ࡕ࠭క")]
XYmrMhzn2gk += [DYakr9g4PVU(u"ࠧࡄࡋࡐࡅࡋࡇࡎࡔࠩఖ"),zI3ROAZtiUq42rE9WDST68(u"ࠨࡅࡌࡑࡆࡒࡉࡈࡊࡗࠫగ"),Mmpr0o76iWJvz1kTtfgI8hES(u"ࠩࡆࡍࡒࡇࡎࡐ࡙ࠪఘ"),RRIHDFjoW9w7bSfVPhC(u"࡛ࠪࡊࡉࡉࡎࡃ࠴ࠫఙ"),vvWwO3Tx2dAgcijrFXq(u"ࠫ࡜ࡋࡃࡊࡏࡄ࠶ࠬచ"),QTUBCcehw6qPd4x(u"࡙ࠬࡈࡂࡊࡌࡈࡓࡋࡗࡔࠩఛ"),Mmpr0o76iWJvz1kTtfgI8hES(u"࠭ࡆࡐࡕࡗࡅࠬజ"),TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠧࡂࡊ࡚ࡅࡐ࠭ఝ"),P0qdZI384LKleuo(u"ࠨࡕࡋࡓࡔࡌࡎࡆࡖࠪఞ")]
XYmrMhzn2gk += [vvWwO3Tx2dAgcijrFXq(u"ࠩࡖࡉࡗࡏࡅࡔࡖࡌࡑࡊ࠭ట"),ddo23ZJtgcY(u"ࠪࡊࡆࡐࡅࡓࡕࡋࡓ࡜࠭ఠ"),kke1PDGRBLuY8y(u"ࠫࡐࡇࡒࡃࡃࡏࡅ࡙࡜ࠧడ"),Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠷ࠧఢ"),HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠲ࠨణ"),TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠵ࠩత"),ddo23ZJtgcY(u"ࠨࡊࡄࡐࡆࡉࡉࡎࡃࠪథ"),kke1PDGRBLuY8y(u"ࠩࡄࡏ࡜ࡇࡍࡕࡗࡅࡉࠬద")]
XYmrMhzn2gk += [kke1PDGRBLuY8y(u"ࠪࡐࡔࡊ࡙ࡏࡇࡗࠫధ"),Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠫࡘࡎࡁࡉࡋࡇ࠸࡚࠭న"),BmePGjS7FxK6kutUM(u"࡙ࠬࡈࡐࡑࡉࡑࡆ࡞ࠧ఩"),S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"࠭ࡔࡗࡈࡘࡒࠬప"),uVQd103XyvUce2EBtzbYaC(u"ࠧࡄࡋࡐࡅࡆࡈࡄࡐࠩఫ"),VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠨࡕࡋࡓࡋࡎࡁࠨబ"),dDYUoKi6JFM23p(u"࡙ࠩࡅࡗࡈࡏࡏࠩభ"),VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠪࡅࡑࡓࡓࡕࡄࡄࠫమ"),RRIHDFjoW9w7bSfVPhC(u"ࠫࡋࡇࡒࡆࡕࡎࡓࠬయ")]
XYmrMhzn2gk += [zI3ROAZtiUq42rE9WDST68(u"ࠬࡈࡒࡔࡖࡈࡎࠬర"),Mmpr0o76iWJvz1kTtfgI8hES(u"࡙࠭ࡂࡓࡒࡘࠬఱ"),Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠧࡅࡔࡄࡑࡆ࡙࠷ࠨల"),Xz3bA2PFENVCUtplu51(u"ࠨࡅࡌࡑࡆ࠺࠰࠱ࠩళ"),S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠩࡄࡖࡆࡈࡉࡄࡖࡒࡓࡓ࡙ࠧఴ"),BmePGjS7FxK6kutUM(u"ࠪࡅࡑࡓࡁࡂࡔࡈࡊࠬవ"),ddo23ZJtgcY(u"ࠫࡐࡇࡔࡌࡑࡗࡘ࡛࠭శ"),P0qdZI384LKleuo(u"ࠬࡒࡁࡓࡑ࡝ࡅࠬష"),S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"࠭ࡃࡊࡏࡄ࡛ࡇࡇࡓࠨస")]
XYmrMhzn2gk += [DYakr9g4PVU(u"ࠧࡇࡗࡖࡌࡆࡘࡖࡊࡆࡈࡓࠬహ"),P0qdZI384LKleuo(u"ࠨࡈࡘࡗࡍࡇࡒࡕࡘࠪ఺"),Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠩࡎࡍࡗࡓࡁࡍࡍࠪ఻"),mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠪࡈࡗࡇࡍࡂࡅࡄࡊࡊ఼࠭"),QTUBCcehw6qPd4x(u"࡙ࠫࡏࡋࡂࡃࡗࠫఽ"),P0qdZI384LKleuo(u"࡙ࠬࡈࡂࡄࡄࡏࡆ࡚࡙ࠨా"),Mmpr0o76iWJvz1kTtfgI8hES(u"࠭ࡁࡏࡋࡐࡉ࡟ࡏࡄࠨి")]
G5sWqwIctHa8YJdpfNl  = [Xz3bA2PFENVCUtplu51(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲࡜ࡉࡅࡇࡒࡗࠬీ"),m6hwdgP31a2zjN7lkpX(u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡐࡍࡃ࡜ࡐࡎ࡙ࡔࡔࠩు"),TYf7Dc06PQgy1vEV9(u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡄࡊࡄࡒࡓࡋࡌࡔࠩూ"),Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡎࡌ࡚ࡊ࡙ࠧృ"),P0qdZI384LKleuo(u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯ࡋࡅࡘࡎࡔࡂࡉࡖࠫౄ")]
G5sWqwIctHa8YJdpfNl += [zI3ROAZtiUq42rE9WDST68(u"ࠬࡏࡆࡊࡎࡐ࠱ࡆࡘࡁࡃࡋࡆࠫ౅"),BWNPxIG7vqdTy85pjHzUOrK3(u"࠭ࡉࡇࡋࡏࡑ࠲ࡋࡎࡈࡎࡌࡗࡍ࠭ె")]
G5sWqwIctHa8YJdpfNl += [TYf7Dc06PQgy1vEV9(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡘࡌࡈࡊࡕࡓࠨే"),SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡓࡐࡆ࡟ࡌࡊࡕࡗࡗࠬై"),ddo23ZJtgcY(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡇࡍࡇࡎࡏࡇࡏࡗࠬ౉")]
G5sWqwIctHa8YJdpfNl += [kke1PDGRBLuY8y(u"ࠪࡍࡕ࡚ࡖ࠮ࡎࡌ࡚ࡊ࠭ొ"),Mmpr0o76iWJvz1kTtfgI8hES(u"ࠫࡎࡖࡔࡗ࠯ࡐࡓ࡛ࡏࡅࡔࠩో"),mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠬࡏࡐࡕࡘ࠰ࡗࡊࡘࡉࡆࡕࠪౌ")]
G5sWqwIctHa8YJdpfNl += [SbjiWeHLQPoazqwp3cODkd7YxVgn(u"࠭ࡍ࠴ࡗ࠰ࡐࡎ࡜ࡅࠨ్"),QQdAXWBc2GPw(u"ࠧࡎ࠵ࡘ࠱ࡒࡕࡖࡊࡇࡖࠫ౎"),IjZbnrBJmM2N(u"ࠨࡏ࠶࡙࠲࡙ࡅࡓࡋࡈࡗࠬ౏")]
caMUPkfwdVXCO60IqGH75WYe2hZvzn = [vvWwO3Tx2dAgcijrFXq(u"ࠩࡐ࠷࡚࠭౐"),RRIHDFjoW9w7bSfVPhC(u"ࠪࡍࡕ࡚ࡖࠨ౑"),DYakr9g4PVU(u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏࠩ౒"),QQdAXWBc2GPw(u"ࠬࡏࡆࡊࡎࡐࠫ౓"),shC5qBRV2A0lZ(u"࡙࠭ࡐࡗࡗ࡙ࡇࡋࠧ౔")]
WOXHyD1V5jBlvRSQzYtp87 = XYmrMhzn2gk+caMUPkfwdVXCO60IqGH75WYe2hZvzn
djEh4qtWn9H = XYmrMhzn2gk+G5sWqwIctHa8YJdpfNl
m0mjZVkpsdDGKByLtfTi1l4REYqUvM = djEh4qtWn9H+E43MVUOlPeYvHQ8uNI2ysJzx95kKBr
bT46adeyIWDBiArPH3V5027 = [LAQD5wEkr18bUiGaYen3J(u"ࠧࡑࡔࡌ࡚ࡆ࡚ࡅࠨౕ")]+np5lbPOG9fIher0iAqDS4+[m6hwdgP31a2zjN7lkpX(u"ࠨࡏࡌ࡜ࡊࡊౖࠧ")]+FSyeLvB1xVuYJf5+[mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠩࡓ࡙ࡇࡒࡉࡄࠩ౗")]+mxlEzHtB60r2n83FMY94bAcei5+[mQNonhS7CV2BXOv(u"ࠪࡔࡗࡏࡖࡂࡖࡈࠫౘ")]+zcsZ9kQCPD5HqgreY7iROuUW0
S8Czlw0Fthk = [HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠫࡆࡑࡏࡂࡏࠪౙ"),yST5AHEfvPmcWpwGuh2BJ(u"ࠬࡇࡋࡘࡃࡐࠫౚ"),Xz3bA2PFENVCUtplu51(u"࠭ࡉࡇࡋࡏࡑࠬ౛"),Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠧࡌࡃࡕࡆࡆࡒࡁࡕࡘࠪ౜"),mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠨࡃࡏࡑࡆࡇࡒࡆࡈࠪౝ"),ubxGUTt1LraKhVZgpAP(u"ࠩࡖࡌࡔࡕࡆࡎࡃ࡛ࠫ౞"),QQdAXWBc2GPw(u"ࠪࡗࡍࡏࡁࡗࡑࡌࡇࡊ࠭౟"),HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬౠ"),VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐࠪౡ"),kke1PDGRBLuY8y(u"࠭ࡍ࠴ࡗࠪౢ"),UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠧࡊࡒࡗ࡚ࠬౣ"),dDYUoKi6JFM23p(u"ࠨࡄࡒࡏࡗࡇࠧ౤"),dDYUoKi6JFM23p(u"ࠩࡈࡐࡈࡏࡎࡆࡏࡄࠫ౥"),ubxGUTt1LraKhVZgpAP(u"ࠪࡅࡗࡇࡂࡊࡅࡗࡓࡔࡔࡓࠨ౦")]
NOT_TO_TEST_ALL_SERVERS = [QQdAXWBc2GPw(u"ࠫࡤࡇࡋࡐࡡࠪ౧"),BWNPxIG7vqdTy85pjHzUOrK3(u"ࠬࡥࡁࡌ࡙ࡢࠫ౨"),mmcNLrXtzfpyCkZlvK5VwG2gujh(u"࠭࡟ࡊࡈࡏࡣࠬ౩"),mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠧࡠࡍࡕࡆࡤ࠭౪"),VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠨࡡࡐࡖࡋࡥࠧ౫"),SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠩࡢࡗࡍࡓ࡟ࠨ౬"),m6hwdgP31a2zjN7lkpX(u"ࠪࡣࡘࡎࡖࡠࠩ౭"),QQdAXWBc2GPw(u"ࠫࡤ࡟ࡕࡕࡡࠪ౮"),dDYUoKi6JFM23p(u"ࠬࡥࡄࡍࡏࡢࠫ౯"),Nh0BWuiSndf(u"࠭࡟ࡎࡗࠪ౰"),Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠧࡠࡋࡓࠫ౱"),UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠨࡡࡅࡏࡗࡥࠧ౲"),kke1PDGRBLuY8y(u"ࠩࡢࡉࡑࡉ࡟ࠨ౳"),Nh0BWuiSndf(u"ࠪࡣࡆࡘࡔࡠࠩ౴")]
UhVAT46l59JBLO2rKI0zZ = [kke1PDGRBLuY8y(u"ࠫࡒࡋࡎࡖࡡࡕࡉ࡛ࡋࡒࡔࡇࡇࡣࡕࡋࡒࡎࠩ౵"),LAQD5wEkr18bUiGaYen3J(u"ࠬࡓࡅࡏࡗࡢࡅࡘࡉࡅࡏࡆࡈࡈࡤࡖࡅࡓࡏࠪ౶"),uVQd103XyvUce2EBtzbYaC(u"࠭ࡍࡆࡐࡘࡣࡉࡋࡓࡄࡇࡑࡈࡊࡊ࡟ࡑࡇࡕࡑࠬ౷"),m6hwdgP31a2zjN7lkpX(u"ࠧࡎࡇࡑ࡙ࡤࡘࡁࡏࡆࡒࡑࡎࡠࡅࡅࡡࡓࡉࡗࡓࠧ౸"),Mmpr0o76iWJvz1kTtfgI8hES(u"ࠨࡏࡈࡒ࡚ࡥࡒࡆࡘࡈࡖࡘࡋࡄࡠࡖࡈࡑࡕ࠭౹"),Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠩࡐࡉࡓ࡛࡟ࡂࡕࡆࡉࡓࡊࡅࡅࡡࡗࡉࡒࡖࠧ౺"),m6hwdgP31a2zjN7lkpX(u"ࠪࡑࡊࡔࡕࡠࡆࡈࡗࡈࡋࡎࡅࡇࡇࡣ࡙ࡋࡍࡑࠩ౻"),mQNonhS7CV2BXOv(u"ࠫࡒࡋࡎࡖࡡࡕࡅࡓࡊࡏࡎࡋ࡝ࡉࡉࡥࡔࡆࡏࡓࠫ౼")]
KV4XpEahzG5 = [
						 QQdAXWBc2GPw(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡚ࡖࡌࡆࡘࡉࡏࡉ࠰࠵ࡸࡺࠧ౽")
						,UUkIBz1sgQ9WfNeG6trKXvu0(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡛ࡗࡍࡇࡒࡊࡐࡊ࠱࠷ࡴࡤࠨ౾")
						,HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡑ࡚ࡒࡔࡊࡡ࡛ࡗࡍࡇࡒࡊࡐࡊ࠱࠶ࡹࡴࠨ౿")
						]
FFrjbtTlpU59o0LhkWBAcs1RvfeX7u = [
						 shC5qBRV2A0lZ(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡖࡉࡓࡊ࡟ࡂࡐࡄࡐ࡞࡚ࡉࡄࡕࡢࡉ࡛ࡋࡎࡕࡕ࠰࠵ࡸࡺࠧಀ")
						,HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡉ࡝࡚ࡒࡂࡅࡗࡣࡒ࠹ࡕ࠹࠯࠴ࡷࡹ࠭ಁ")
						,shC5qBRV2A0lZ(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡗࡇࡎࡅࡑࡐࡣ࡚࡙ࡅࡓࡃࡊࡉࡓ࡚࠭࠲ࡵࡷࠫಂ")
						,ubxGUTt1LraKhVZgpAP(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡅࡕࡡࡓࡖࡔ࡞ࡉࡆࡕࡢࡐࡎ࡙ࡔ࠮࠳ࡶࡸࠬಃ")
						,TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠬࡏࡐࡕࡘ࠰ࡇࡍࡋࡃࡌࡡࡄࡇࡈࡕࡕࡏࡖ࠰࠵ࡸࡺࠧ಄")
						,dDYUoKi6JFM23p(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡇࡒࡐࡔࡉࡁࡕࡋࡒࡒ࠲࠷ࡳࡵࠩಅ")
						,kke1PDGRBLuY8y(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡉࡒࡓࡌࡒࡅࡠࡐࡈ࡛ࡤࡎࡏࡔࡖࡑࡅࡒࡋ࠭࠲ࡵࡷࠫಆ")
						,SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡓࡔࡍࡌࡆࡡࡑࡉ࡜ࡥࡈࡐࡕࡗࡒࡆࡓࡅ࠮࠵ࡵࡨࠬಇ")
						,yST5AHEfvPmcWpwGuh2BJ(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡖࡊࡇࡄࡠࡃࡏࡐࡤࡇࡄࡅࡑࡑࡗࡤ࡞ࡍࡍ࠯࠴ࡷࡹ࠭ಈ")
						,IjZbnrBJmM2N(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡇࡐࡑࡊࡐࡊ࡛ࡓࡆࡔࡆࡓࡓ࡚ࡅࡏࡖ࠰࠵ࡸࡺࠧಉ")
						,RRIHDFjoW9w7bSfVPhC(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡃ࡛ࡓࡅࡘ࡙࡟ࡂࡍ࡚ࡅࡒࡥࡃࡂࡒࡗࡇࡍࡇ࠭࠴ࡴࡧࠫಊ")
						,dDYUoKi6JFM23p(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡄ࡜ࡔࡆ࡙ࡓࡠࡃࡎ࡛ࡆࡓ࡟ࡄࡃࡓࡘࡈࡎࡁ࠮࠷ࡷ࡬ࠬಋ")
						,LAQD5wEkr18bUiGaYen3J(u"࠭ࡅࡍࡅࡌࡒࡊࡓࡁ࠮ࡕࡈࡅࡗࡉࡈ࠮࠳ࡶࡸࠬಌ")
						,zI3ROAZtiUq42rE9WDST68(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡜ࡘࡎࡁࡓࡋࡑࡋ࠲࠷ࡳࡵࠩ಍")
						,VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡝࡙ࡈࡂࡔࡌࡒࡌ࠳࠲࡯ࡦࠪಎ")
						]
ntcLuhZPEDsUxoqTG1iK74XFO = FFrjbtTlpU59o0LhkWBAcs1RvfeX7u+[
				 VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡔࡗࡕࡘ࡚ࡡࡗࡉࡘ࡚࠭࠲ࡵࡷࠫಏ")
				,Xz3bA2PFENVCUtplu51(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤࡎࡔࡕࡒࡖࡔࡗࡕࡘࡊࡇࡖ࠱࠶ࡹࡴࠨಐ")
				,VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡕࡐࡆࡐࡘࡖࡑࡥࡗࡆࡄࡓࡖࡔ࡞ࡉࡆࡕ࠰࠵ࡸࡺࠧ಑")
				,VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡘࡇࡅࡔࡗࡕࡘࡊࡇࡖ࠱࠷ࡴࡤࠨಒ")
				,IjZbnrBJmM2N(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠ࡙ࡈࡆࡕࡘࡏ࡙࡛ࡗࡓ࠲࠷ࡳࡵࠩಓ")
				,BWNPxIG7vqdTy85pjHzUOrK3(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡑࡓࡉࡓ࡛ࡒࡍࡡ࡚ࡉࡇࡖࡒࡐ࡚࡜ࡘࡔ࠳࠲࡯ࡦࠪಔ")
				,IjZbnrBJmM2N(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢࡏࡕࡘࡏ࡙࡛ࡆࡓࡒ࠳࠱ࡴࡶࠪಕ")
				,LAQD5wEkr18bUiGaYen3J(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡓࡕࡋࡎࡖࡔࡏࡣࡐࡖࡒࡐ࡚࡜ࡇࡔࡓ࠭࠳ࡰࡧࠫಖ")
				,UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤࡑࡐࡓࡑ࡛࡝ࡈࡕࡍ࠮࠵ࡵࡨࠬಗ")
				,S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡉࡈࡆࡅࡎࡣࡍ࡚ࡔࡑࡕࡢࡔࡗࡕࡘࡊࡇࡖ࠱࠶ࡹࡴࠨಘ")
				,ubxGUTt1LraKhVZgpAP(u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙࠭ࡉࡖࡗࡔࡘࡥࡔࡆࡕࡗ࠱࠶ࡹࡴࠨಙ")
				,RRIHDFjoW9w7bSfVPhC(u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓ࠮ࡖࡈࡗ࡙ࡥࡁࡍࡎࡢ࡛ࡊࡈࡓࡊࡖࡈࡗ࠲࠷ࡳࡵࠩಚ")
				,UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࡗࡉࡘ࡚࡟ࡂࡎࡏࡣ࡜ࡋࡂࡔࡋࡗࡉࡘ࠳࠲࡯ࡦࠪಛ")
				,IjZbnrBJmM2N(u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕ࠰࡙ࡘࡇࡇࡆࡡࡕࡉࡕࡕࡒࡕ࠯࠴ࡷࡹ࠭ಜ")
				,Mmpr0o76iWJvz1kTtfgI8hES(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡔࡕࡇࡍࡇࡢࡘࡗࡇࡎࡔࡎࡄࡘࡊ࠳࠱ࡴࡶࠪಝ")
				,mQNonhS7CV2BXOv(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡗࡋࡖࡆࡔࡖࡓࡤ࡚ࡒࡂࡐࡖࡐࡆ࡚ࡅ࠮࠳ࡶࡸࠬಞ")
				]
aZN3l1t6JE4oPmpkzLQSW5 = [TYf7Dc06PQgy1vEV9(u"ࠫ࠽࠴࠸࠯࠺࠱࠼ࠬಟ"),SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠬ࠷࠮࠲࠰࠴࠲࠶࠭ಠ"),kke1PDGRBLuY8y(u"࠭࠱࠯࠲࠱࠴࠳࠷ࠧಡ"),yST5AHEfvPmcWpwGuh2BJ(u"ࠧ࠹࠰࠻࠲࠹࠴࠴ࠨಢ"),shC5qBRV2A0lZ(u"ࠨ࠴࠳࠼࠳࠼࠷࠯࠴࠵࠶࠳࠸࠲࠳ࠩಣ"),Xz3bA2PFENVCUtplu51(u"ࠩ࠵࠴࠽࠴࠶࠸࠰࠵࠶࠵࠴࠲࠳࠲ࠪತ")]
nTHXJIiah2qK = {
			 VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠪࡅࡍ࡝ࡁࡌࠩಥ")		:[mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡳ࠯ࡣ࡫ࡻࡦࡱࡴࡷ࠰ࡱࡩࡹ࠭ದ")]
			,IjZbnrBJmM2N(u"ࠬࡇࡋࡐࡃࡐࠫಧ")		:[DYakr9g4PVU(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢ࡭࠱ࡷࡻ࠵࡯࡭ࡦࠪನ")]
			,RRIHDFjoW9w7bSfVPhC(u"ࠧࡂࡍ࡚ࡅࡒ࠭಩")		:[kke1PDGRBLuY8y(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤ࡯࠳ࡹࡶࠨಪ")]
			,yST5AHEfvPmcWpwGuh2BJ(u"ࠩࡄࡏ࡜ࡇࡍࡕࡗࡅࡉࠬಫ")	:[Nh0BWuiSndf(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡮࠴ࡡ࡬ࡹࡤࡱ࠳ࡺࡵࡣࡧࠪಬ")]
			,Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠫࡆࡒࡍࡂࡃࡕࡉࡋ࠭ಭ")		:[QTUBCcehw6qPd4x(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡ࡭࡯ࡤࡥࡷ࡫ࡦ࠯ࡥ࡫ࠫಮ")]
			,BmePGjS7FxK6kutUM(u"࠭ࡁࡍࡏࡖࡘࡇࡇࠧಯ")		:[Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡸࡲࡨ࠳ࡧ࡬࡮ࡵࡷࡦࡦ࠴ࡴࡷࠩರ")]
			,QQdAXWBc2GPw(u"ࠨࡃࡑࡍࡒࡋ࡚ࡊࡆࠪಱ")		:[Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡳ࡯࡭ࡦࡼ࡬ࡨ࠳ࡹࡨࡰࡹࠪಲ")]
			,mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠪࡅࡗࡇࡂࡊࡅࡗࡓࡔࡔࡓࠨಳ")	:[vvWwO3Tx2dAgcijrFXq(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡣࡵࡥࡧ࡯ࡣ࠮ࡶࡲࡳࡳࡹ࠮ࡤࡱࡰࠫ಴")]
			,IjZbnrBJmM2N(u"ࠬࡇࡒࡂࡄࡖࡉࡊࡊࠧವ")		:[ubxGUTt1LraKhVZgpAP(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡴࡤࡦࡸ࡫ࡥࡥ࠰ࡱࡩࡹ࠭ಶ")]
			,SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠧࡂ࡛ࡏࡓࡑ࠭ಷ")		:[zI3ROAZtiUq42rE9WDST68(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡩ࠳ࡧࡹ࡭ࡱ࡯࠲ࡳ࡫ࡴࠨಸ")]
			,LAQD5wEkr18bUiGaYen3J(u"ࠩࡅࡓࡐࡘࡁࠨಹ")		:[kke1PDGRBLuY8y(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡷ࡭ࡵ࡯ࡧࡸࡲࡨ࠳ࡩ࡯࡮ࠩ಺")]
			,TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠫࡇࡘࡓࡕࡇࡍࠫ಻")		:[SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡢࡳࡵࡷࡩ࡯࠴ࡣࡰ࡯಼ࠪ")]
			,shC5qBRV2A0lZ(u"࠭ࡃࡊࡏࡄ࠸࠵࠶ࠧಽ")		:[mQNonhS7CV2BXOv(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡥ࡬ࡱࡦ࠺࠰࠱࠰ࡦࡳࡲ࠭ಾ")]
			,Nh0BWuiSndf(u"ࠨࡅࡌࡑࡆ࠺ࡐࠨಿ")		:[vvWwO3Tx2dAgcijrFXq(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡧ࡮ࡳࡡ࠵ࡲ࠱ࡧࡴࡳࠧೀ")]
			,TYf7Dc06PQgy1vEV9(u"ࠪࡇࡎࡓࡁ࠵ࡗࠪು")		:[BWNPxIG7vqdTy85pjHzUOrK3(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࠷ࡣࡪ࡯ࡤ࠸ࡺ࠴ࡣࡰ࡯ࠪೂ")]
			,vvWwO3Tx2dAgcijrFXq(u"ࠬࡉࡉࡎࡃࡄࡆࡉࡕࠧೃ")		:[ddo23ZJtgcY(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡤ࡫ࡰࡥ࠸ࡨࡤࡰ࠰ࡦࡳࡲ࠭ೄ")]
			,kke1PDGRBLuY8y(u"ࠧࡄࡋࡐࡅࡈࡒࡕࡃࠩ೅")		:[Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡦ࡭ࡲࡧࡣ࡭ࡷࡥ࠲ࡼࡧࡴࡤࡪࠪೆ")]
			,BWNPxIG7vqdTy85pjHzUOrK3(u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅ࡛ࡔࡘࡋࠨೇ")	:[mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡹࡼࡶ࠯ࡥ࡬ࡱࡦࡩ࡬ࡶࡤ࠱ࡷ࡭ࡵࡰࠨೈ")]
			,Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠫࡈࡏࡍࡂࡈࡄࡒࡘ࠭೉")		:[yST5AHEfvPmcWpwGuh2BJ(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡧ࡮ࡳࡡࡧࡣࡱࡷ࠳ࡩ࡯࡮ࠩೊ")]
			,HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"࠭ࡃࡊࡏࡄࡊࡗࡋࡅࠨೋ")		:[TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡥ࡬ࡱࡦ࡬ࡲࡦࡧ࠱ࡺ࡮ࡶࠧೌ")]
			,TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠨࡅࡌࡑࡆࡒࡉࡈࡊࡗ್ࠫ")	:[UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻ࠷࠽࠮࡮ࡻ࠰ࡧ࡮ࡳࡡ࠯ࡰࡨࡸ࠴ࡳࡹࡤ࠳ࠪ೎")]
			,QTUBCcehw6qPd4x(u"ࠪࡇࡎࡓࡁࡏࡑ࡚ࠫ೏")		:[DYakr9g4PVU(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡩࡩ࡮ࡣࡱࡳࡼ࠴ࡣࡤࠩ೐")]
			,Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠬࡉࡉࡎࡃ࡚ࡆࡆ࡙ࠧ೑")		:[BWNPxIG7vqdTy85pjHzUOrK3(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡤ࡫ࡰࡥࡼࡨࡡࡴ࠰ࡰࡽࡨ࡯࡭ࡢ࠰ࡦࡧࠬ೒")]
			,BmePGjS7FxK6kutUM(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒࠬ೓")	:[Xz3bA2PFENVCUtplu51(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱ࠲ࡨࡵ࡭ࠨ೔"),S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡫ࡷࡧࡰࡩࡳ࡯࠲ࡦࡶࡩ࠯ࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠴ࡣࡰ࡯ࠪೕ")]
			,SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠪࡈࡗࡇࡍࡂࡅࡄࡊࡊ࠭ೖ")	:[UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽ࠲࠶࠰ࡧࡶࡦࡳࡡࡤࡣࡩࡩ࠲ࡺࡶ࠯ࡥࡲࡱࠬ೗")]
			,P0qdZI384LKleuo(u"ࠬࡊࡒࡂࡏࡄࡗ࠼࠭೘")		:[VFjQx6Is28KvzLOmMXtg4GqTwa3(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡥࡴࡤࡱࡦࡹ࠷࠯ࡰࡨࡸࠬ೙")]
			,HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠲ࠩ೚")		:[BWNPxIG7vqdTy85pjHzUOrK3(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨ࡫ࡾࡨࡥࡴࡶ࠱ࡪࡺࡴࠧ೛")]
			,Mmpr0o76iWJvz1kTtfgI8hES(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠵ࠫ೜")		:[QTUBCcehw6qPd4x(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪ࡭ࡹࡣࡧࡶࡸ࠳ࡽࡥࡣࡥࡤࡱࠬೝ")]
			,BWNPxIG7vqdTy85pjHzUOrK3(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠸࠭ೞ")		:[QTUBCcehw6qPd4x(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡩࡦࡩࡼࡦࡪࡹࡴ࠯ࡤ࡬ࡨࠬ೟")]
			,TYf7Dc06PQgy1vEV9(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠴ࠨೠ")		:[yST5AHEfvPmcWpwGuh2BJ(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡪࡽ࠲ࡨࡥࡴࡶ࠱ࡲࡪࡺࠧೡ")]
			,Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠨࡇࡊ࡝ࡉࡋࡁࡅࠩೢ")		:[Nh0BWuiSndf(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩ࡬ࡿࡤࡦࡣࡧ࠲ࡱ࡯ࡶࡦࠩೣ")]
			,QQdAXWBc2GPw(u"ࠪࡉࡑࡉࡉࡏࡇࡐࡅࠬ೤")		:[IjZbnrBJmM2N(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫࡬ࡤ࡫ࡱࡩࡲࡧ࠮ࡤࡱࡰࠫ೥")]
			,mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠬࡋࡌࡊࡈ࡙ࡍࡉࡋࡏࠨ೦")	:[TYf7Dc06PQgy1vEV9(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴࡪࡤ࡬࡮ࡪ࠮ࡦ࡮࡬ࡪ࠳ࡴࡥࡸࡵࠪ೧")]
			,P0qdZI384LKleuo(u"ࠧࡇࡃࡅࡖࡆࡑࡁࠨ೨")		:[Nh0BWuiSndf(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡩࡥࡧࡸ࡫ࡢ࠰ࡦࡳࡲ࠭೩")]
			,QTUBCcehw6qPd4x(u"ࠩࡉࡅࡏࡋࡒࡔࡊࡒ࡛ࠬ೪")	:[Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡫ࡧࡪࡦࡴ࠱ࡷ࡭ࡵࡷࠨ೫")]
			,SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠫࡋࡇࡒࡆࡕࡎࡓࠬ೬")		:[kke1PDGRBLuY8y(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡶࡪࡲ࠱ࡪࡦࡸࡥࡴ࡭ࡲ࠲ࡳ࡫ࡴࠨ೭")]
			,Xz3bA2PFENVCUtplu51(u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠲ࠨ೮")		:[BWNPxIG7vqdTy85pjHzUOrK3(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡶࡰࡦ࠴ࡦࡢࡵࡨࡰ࡭ࡪ࠮ࡤ࡮ࡲࡹࡩ࠭೯")]
			,ddo23ZJtgcY(u"ࠨࡈࡒࡗ࡙ࡇࠧ೰")		:[zI3ROAZtiUq42rE9WDST68(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡰ࠮ࡧࡱࡶࡸࡦ࠳ࡴࡷ࠰ࡱࡩࡹ࠭ೱ")]
			,P0qdZI384LKleuo(u"ࠪࡊ࡚ࡔࡏࡏࡖ࡙ࠫೲ")		:[dDYUoKi6JFM23p(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡭࠮ࡢ࡮ࡰࡩࡸ࡮࡫ࡢࡪ࠱ࡲࡪࡺࠧೳ")]
			,UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠬࡌࡕࡔࡊࡄࡖ࡙࡜ࠧ೴")		:[dDYUoKi6JFM23p(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡣ࠰ࡩࡹࡸ࡮ࡡࡳ࠯ࡷࡺ࠳ࡩ࡯࡮ࠩ೵")]
			,QTUBCcehw6qPd4x(u"ࠧࡇࡗࡖࡌࡆࡘࡖࡊࡆࡈࡓࠬ೶")	:[RRIHDFjoW9w7bSfVPhC(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡶ࠲࡫ࡻࡳࡩࡣࡵ࠲ࡻ࡯ࡤࡦࡱࠪ೷")]
			,BWNPxIG7vqdTy85pjHzUOrK3(u"ࠩࡋࡅࡑࡇࡃࡊࡏࡄࠫ೸")		:[TYf7Dc06PQgy1vEV9(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡭ࡧ࡬ࡢࡥ࡬ࡱࡦ࠴࡭ࡦࡦ࡬ࡥࠬ೹")]
			,Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠫࡎࡌࡉࡍࡏࠪ೺")		:[Mmpr0o76iWJvz1kTtfgI8hES(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡࡳ࠰࡬ࡪ࡮ࡲ࡭ࡵࡸ࠱࡭ࡷ࠭೻"),HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦࡰ࠱࡭࡫࡯࡬࡮ࡶࡹ࠲࡮ࡸࠧ೼"),P0qdZI384LKleuo(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡨࡤ࠲࡮࡬ࡩ࡭࡯ࡷࡺ࠳࡯ࡲࠨ೽"),ubxGUTt1LraKhVZgpAP(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡩࡥ࠷࠴ࡩࡧ࡫࡯ࡱࡹࡼ࠮ࡪࡴࠪ೾"),S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠼࠷࠳࠷࠹࠱࠰࠵࠸࠳࠷࠲࠳ࠩ೿")]
			,QQdAXWBc2GPw(u"ࠪࡏࡆࡘࡂࡂࡎࡄࡘ࡛࠭ഀ")	:[Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱࡡࡳࡤࡤࡰࡦ࠳ࡴࡷ࠰࡬ࡵࠬഁ")]
			,BmePGjS7FxK6kutUM(u"ࠬࡑࡁࡕࡍࡒࡘ࡙࡜ࠧം")		:[IjZbnrBJmM2N(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬࡫ࡷ࡯ࡴࡺ࠮ࡤࡣࡰࠫഃ")]
			,dDYUoKi6JFM23p(u"ࠧࡌࡋࡕࡑࡆࡒࡋࠨഄ")		:[RRIHDFjoW9w7bSfVPhC(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡹ࠳ࡱࡩࡳ࡯ࡤࡰࡰ࠴ࡣࡰ࡯ࠪഅ")]
			,SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠩࡎࡓࡉࡏࡅࡎࡃࡇࡣࡆࡖࡐࠨആ")	:[Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡹ࡯࡮ࡺ࠰ࡦࡧ࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪࠧഇ"),DYakr9g4PVU(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵ࠵࠴࠶࠾࠮ࡧࡹࡶ࠲ࡸࡺ࡯ࡳࡧࠪഈ")]
			,RRIHDFjoW9w7bSfVPhC(u"ࠬࡒࡁࡓࡑ࡝ࡅࠬഉ")		:[Xz3bA2PFENVCUtplu51(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡭ࡣࡵࡳࡿࡧ࠮ࡪࡰ࡮ࠫഊ")]
			,QTUBCcehw6qPd4x(u"ࠧࡍࡑࡇ࡝ࡓࡋࡔࠨഋ")		:[Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡯ࡳࡩࡿ࡮ࡦࡶ࠱ࡰ࡮ࡴ࡫ࠨഌ")]
			,LAQD5wEkr18bUiGaYen3J(u"ࠩࡐࡅࡘࡇࡖࡊࡆࡈࡓࠬ഍")	:[shC5qBRV2A0lZ(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯࡯ࡤࡷࡦࡼࡩࡥࡧࡲ࠲ࡳ࡫ࡷࡴࠩഎ")]
			,Mmpr0o76iWJvz1kTtfgI8hES(u"ࠫࡕࡇࡎࡆࡖࠪഏ")		:[dDYUoKi6JFM23p(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰ࡳࡥࡳ࡫ࡴ࠯ࡥࡲ࠲࡮ࡲࠧഐ")]
			,dDYUoKi6JFM23p(u"࠭ࡒࡆࡎࡈࡅࡘࡋࡓࠨ഑")		:[Nh0BWuiSndf(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡷࡺࡸࡧࡦ࠰ࡶ࡬࠴ࡱ࡯ࡥ࡫࠲ࡩࡲࡧࡤࡠࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹ࠯ࡰ࡮ࡧ࠳࡮ࡴࡤࡦࡺ࠱࡬ࡹࡳ࡬ࠨഒ")]
			,Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠨࡕࡈࡖࡎࡋࡓࡕࡋࡐࡉࠬഓ")	:[mQNonhS7CV2BXOv(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡦࡦ࠴ࡳࡦࡴ࡬ࡩࡸࡺࡩ࡮ࡧ࠱ࡧࡦࡳࠧഔ")]
			,Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠪࡗࡍࡇࡂࡂࡍࡄࡘ࡞࠭ക")	:[DYakr9g4PVU(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡩࡩ࡮ࡣ࡫ࡨ࠳ࡼࡩࡱࠩഖ")]
			,Xz3bA2PFENVCUtplu51(u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛ࠧഗ")		:[UUkIBz1sgQ9WfNeG6trKXvu0(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴࡪ࡬࡭ࡩ࠺ࡵ࠯ࡥࡲࡱࠬഘ")]
			,VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠧࡔࡊࡄࡌࡎࡊࡎࡆ࡙ࡖࠫങ")	:[shC5qBRV2A0lZ(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨ࠲ࡸ࡮࠴ࡶ࠰ࡱࡩࡼࡹࠧച")]
			,QQdAXWBc2GPw(u"ࠩࡖࡌࡔࡌࡈࡂࠩഛ")		:[Mmpr0o76iWJvz1kTtfgI8hES(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸ࡮࡯ࡧࡪࡤ࠲ࡹࡼࠧജ")]
			,S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠫࡘࡎࡏࡐࡈࡐࡅ࡝࠭ഝ")		:[m6hwdgP31a2zjN7lkpX(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡩࡱࡲࡪࡲࡧࡸ࠯ࡥࡲࡱࠬഞ"),m6hwdgP31a2zjN7lkpX(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴࡶࡤࡸ࡮ࡩ࠮ࡴࡪࡲࡳ࡫ࡳࡡࡹ࠰ࡦࡳࡲ࠭ട"),DYakr9g4PVU(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡵ࡫ࡳࡴ࡬࡭ࡢࡺ࠱ࡥࡿࡻࡲࡦࡧࡧ࡫ࡪ࠴࡮ࡦࡶࠪഠ")]
			,ubxGUTt1LraKhVZgpAP(u"ࠨࡕࡋࡓࡔࡌࡎࡆࡖࠪഡ")		:[m6hwdgP31a2zjN7lkpX(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡸ࠴ࡡ࡬ࡹࡤࡱ࠳ࡺࡵࡣࡧࠪഢ")]
			,S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠪࡘࡎࡑࡁࡂࡖࠪണ")		:[QTUBCcehw6qPd4x(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡺࡩ࡬ࡣࡤࡸ࠳ࡴࡥࡵࠩത")]
			,HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"࡚ࠬࡖࡇࡗࡑࠫഥ")		:[Xz3bA2PFENVCUtplu51(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴ࠰ࡷࡺ࡫ࡻ࡮࠯࡯ࡨࠫദ")]
			,Mmpr0o76iWJvz1kTtfgI8hES(u"ࠧࡗࡃࡕࡆࡔࡔࠧധ")		:[ddo23ZJtgcY(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡰ࠲ࡻࡧࡲࡣࡱࡱ࠲ࡨࡧ࡭ࠨന")]
			,yST5AHEfvPmcWpwGuh2BJ(u"࡙ࠩࡍࡉࡋࡏࡏࡕࡄࡉࡒ࠭ഩ")	:[Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡻ࡯ࡤࡦࡱ࠱ࡲࡸࡧࡥ࡮࠰ࡱࡩࡹ࠭പ")]
			,BWNPxIG7vqdTy85pjHzUOrK3(u"ࠫ࡜ࡋࡃࡊࡏࡄ࠵ࠬഫ")		:[Xz3bA2PFENVCUtplu51(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡦࡥ࡬ࡱࡦ࠴ࡳࡩࡱࡺࠫബ")]
			,VFjQx6Is28KvzLOmMXtg4GqTwa3(u"࠭ࡗࡆࡅࡌࡑࡆ࠸ࠧഭ")		:[Xz3bA2PFENVCUtplu51(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡨࡧ࡮ࡳࡡ࠯ࡥ࡯࡭ࡨࡱࠧമ")]
			,SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠨ࡛ࡄࡕࡔ࡚ࠧയ")		:[dDYUoKi6JFM23p(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡽ࠳ࡿࡡࡲࡱࡷ࠲ࡹࡼࠧര")]
			,LAQD5wEkr18bUiGaYen3J(u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫറ")		:[TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡧࡴࡳࠧല")]
			,kke1PDGRBLuY8y(u"ࠬ࡟ࡔࡃࡡࡆࡌࡆࡔࡎࡆࡎࡖࠫള")	:[SbjiWeHLQPoazqwp3cODkd7YxVgn(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡩ࡯࡮ࠩഴ")]
			,Mmpr0o76iWJvz1kTtfgI8hES(u"ࠧࡊࡒࡗ࡚ࠬവ")			:[VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠨࠩശ")]
			,VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠩࡐ࠷࡚࠭ഷ")			:[DYakr9g4PVU(u"ࠪࠫസ")]
			,ubxGUTt1LraKhVZgpAP(u"ࠫࡗࡋࡐࡐࡕࠪഹ")		:[P0qdZI384LKleuo(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡰࡨࡸࡱ࡯ࡦࡺ࠰ࡤࡴࡵ࠵ࡋࡐࡆࡌࡖࡊࡖࡏ࠰ࡃࡇࡈࡔࡔࡓ࠰ࡣࡧࡨࡴࡴࡳ࠯ࡺࡰࡰࠬഺ"),QTUBCcehw6qPd4x(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡱࡩࡹࡲࡩࡧࡻ࠱ࡥࡵࡶ࠯ࡌࡑࡇࡍࡗࡋࡐࡐ࠱ࡄࡈࡉࡕࡎࡔ࠳࠻࠳ࡦࡪࡤࡰࡰࡶ࠵࠽࠴ࡸ࡮࡮഻ࠪ"),BmePGjS7FxK6kutUM(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡲࡪࡺ࡬ࡪࡨࡼ࠲ࡦࡶࡰ࠰ࡍࡒࡈࡎࡘࡅࡑࡑ࠲ࡅࡉࡊࡏࡏࡕ࠴࠽࠴ࡧࡤࡥࡱࡱࡷ࠶࠿࠮ࡹ࡯࡯഼ࠫ")]
			,Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠨࡔࡈࡔࡔ࡙࡟ࡃࡍࡓࠫഽ")	:[TYf7Dc06PQgy1vEV9(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡲࡦࡲࡲ࠲ࡺࡱ࠮ࡵࡱ࠲ࡅࡉࡊࡏࡏࡕ࠲ࡥࡩࡪ࡯࡯ࡵ࠱ࡼࡲࡲࠧാ"),uVQd103XyvUce2EBtzbYaC(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡳࡧࡳࡳ࠳ࡻ࡫࠯ࡶࡲ࠳ࡆࡊࡄࡐࡐࡖ࠵࠽࠵ࡡࡥࡦࡲࡲࡸ࠷࠸࠯ࡺࡰࡰࠬി"),UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡴࡨࡴࡴ࠴ࡵ࡬࠰ࡷࡳ࠴ࡇࡄࡅࡑࡑࡗ࠶࠿࠯ࡢࡦࡧࡳࡳࡹ࠱࠺࠰ࡻࡱࡱ࠭ീ")]
			,HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"࡙ࠬࡏࡖࡔࡆࡉࡘ࠭ു")		:[SbjiWeHLQPoazqwp3cODkd7YxVgn(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠱ࡴࡾࡺࡨࡰࡰࡤࡲࡾࡽࡨࡦࡴࡨ࠲ࡨࡵ࡭࠰࡭ࡲࡨ࡮࠭ൂ"),Xz3bA2PFENVCUtplu51(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡷࡺࡸࡧࡦ࠰ࡶ࡬ࠬൃ"),vvWwO3Tx2dAgcijrFXq(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡳ࡫ࡴ࡭࡫ࡩࡽ࠳ࡧࡰࡱ࠱ࡎࡓࡉࡏࡒࡆࡒࡒࠫൄ")]
			}
if qHYIWnOZLPkrQU:
	nTHXJIiah2qK[zI3ROAZtiUq42rE9WDST68(u"ࠩࡓ࡝࡙ࡎࡏࡏࠩ൅")] = [S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲ࡰ࡮ࡹࡴࡱ࡮ࡤࡽࠬെ"),SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡷࡧࡵࡧࡪࡲ࠮ࡢࡲࡳ࠳ࡺࡹࡡࡨࡧࡵࡩࡵࡵࡲࡵࠩേ"),Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡸࡨࡶࡨ࡫࡬࠯ࡣࡳࡴ࠴ࡹࡥ࡯ࡦࡨࡱࡦ࡯࡬ࠨൈ"),BWNPxIG7vqdTy85pjHzUOrK3(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵ࡧࡦࡶࡰࡩࡸࡹࡡࡨࡧࡶࠫ൉"),yST5AHEfvPmcWpwGuh2BJ(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡺࡪࡸࡣࡦ࡮࠱ࡥࡵࡶ࠯ࡨࡧࡷ࡭ࡸࡲࡡ࡮࡫ࡦࠫൊ"),DYakr9g4PVU(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡻ࡫ࡲࡤࡧ࡯࠲ࡦࡶࡰ࠰ࡩࡨࡸࡶࡻࡥࡴࡶ࡬ࡳࡳࡹࠧോ"),zI3ROAZtiUq42rE9WDST68(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡼࡥࡳࡥࡨࡰ࠳ࡧࡰࡱ࠱ࡪࡩࡹࡱ࡮ࡰࡹࡱࡩࡷࡸ࡯ࡳࡵࠪൌ"),ubxGUTt1LraKhVZgpAP(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲ࡧࡦࡶࡴࡤࡪࡤ്ࠫ"),TYf7Dc06PQgy1vEV9(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡷࡧࡵࡧࡪࡲ࠮ࡢࡲࡳ࠳ࡹ࡫ࡳࡵ࡫ࡱ࡫ࠬൎ"),shC5qBRV2A0lZ(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡸࡨࡶࡨ࡫࡬࠯ࡣࡳࡴ࠴࡭ࡥࡵࡧࡻࡸࡷࡧࡰࡺࡶ࡫ࡳࡳࡩ࡯ࡥࡧࠪ൏")]
	nTHXJIiah2qK[IjZbnrBJmM2N(u"࠭ࡐ࡚ࡖࡋࡓࡓࡥࡂࡌࡒࠪ൐")] = [shC5qBRV2A0lZ(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡸ࡯࠳ࡺ࡯࠰࡮࡬ࡷࡹࡶ࡬ࡢࡻࠪ൑"),dDYUoKi6JFM23p(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡹࡰ࠴ࡴࡰ࠱ࡸࡷࡦ࡭ࡥࡳࡧࡳࡳࡷࡺࠧ൒"),shC5qBRV2A0lZ(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡺࡱ࠮ࡵࡱ࠲ࡷࡪࡴࡤࡦ࡯ࡤ࡭ࡱ࠭൓"),HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡻ࡫࠯ࡶࡲ࠳࡬࡫ࡴ࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩൔ"),QTUBCcehw6qPd4x(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡵ࡬࠰ࡷࡳ࠴࡭ࡥࡵ࡫ࡶࡰࡦࡳࡩࡤࠩൕ"),QQdAXWBc2GPw(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡶ࡭࠱ࡸࡴ࠵ࡧࡦࡶࡴࡹࡪࡹࡴࡪࡱࡱࡷࠬൖ"),kke1PDGRBLuY8y(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡷ࡮࠲ࡹࡵ࠯ࡨࡧࡷ࡯ࡳࡵࡷ࡯ࡧࡵࡶࡴࡸࡳࠨൗ"),DYakr9g4PVU(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡸ࡯࠳ࡺ࡯࠰ࡥࡤࡴࡹࡩࡨࡢࠩ൘"),Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡹࡰ࠴ࡴࡰ࠱ࡷࡩࡸࡺࡩ࡯ࡩࠪ൙"),dDYUoKi6JFM23p(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡺࡱ࠮ࡵࡱ࠲࡫ࡪࡺࡥࡹࡶࡵࡥࡵࡿࡴࡩࡱࡱࡧࡴࡪࡥࠨ൚")]
else:
	nTHXJIiah2qK[zI3ROAZtiUq42rE9WDST68(u"ࠪࡔ࡞࡚ࡈࡐࡐࠪ൛")] = [DYakr9g4PVU(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡲࡩࡴࡶࡳࡰࡦࡿࠧ൜"),ubxGUTt1LraKhVZgpAP(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡵࡴࡣࡪࡩࡷ࡫ࡰࡰࡴࡷࠫ൝"),HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡴࡧࡱࡨࡪࡳࡡࡪ࡮ࠪ൞"),P0qdZI384LKleuo(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸࡲ࡫ࡳࡴࡣࡪࡩࡸ࠭ൟ"),kke1PDGRBLuY8y(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹ࡯ࡳ࡭ࡣࡰ࡭ࡨ࠭ൠ"),dDYUoKi6JFM23p(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺࡱࡶࡧࡶࡸ࡮ࡵ࡮ࡴࠩൡ"),P0qdZI384LKleuo(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴ࡬ࡰࡲࡻࡳ࡫ࡲࡳࡱࡵࡷࠬൢ"),vvWwO3Tx2dAgcijrFXq(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡩࡡࡱࡶࡦ࡬ࡦ࠭ൣ"),Nh0BWuiSndf(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡴࡦࡵࡷ࡭ࡳ࡭ࠧ൤"),mQNonhS7CV2BXOv(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷࡩࡽࡺࡲࡢࡲࡼࡸ࡭ࡵ࡮ࡤࡱࡧࡩࠬ൥")]
	nTHXJIiah2qK[Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠧࡑ࡛ࡗࡌࡔࡔ࡟ࡃࡍࡓࠫ൦")] = [DYakr9g4PVU(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱࡯࡭ࡸࡺࡰ࡭ࡣࡼࠫ൧"),BWNPxIG7vqdTy85pjHzUOrK3(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡹࡸࡧࡧࡦࡴࡨࡴࡴࡸࡴࠨ൨"),m6hwdgP31a2zjN7lkpX(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡸ࡫࡮ࡥࡧࡰࡥ࡮ࡲࠧ൩"),uVQd103XyvUce2EBtzbYaC(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵ࡯ࡨࡷࡸࡧࡧࡦࡵࠪ൪"),yST5AHEfvPmcWpwGuh2BJ(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶ࡬ࡷࡱࡧ࡭ࡪࡥࠪ൫"),P0qdZI384LKleuo(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ࠭൬"),UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸࡰࡴ࡯ࡸࡰࡨࡶࡷࡵࡲࡴࠩ൭"),LAQD5wEkr18bUiGaYen3J(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡦࡥࡵࡺࡣࡩࡣࠪ൮"),VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡸࡪࡹࡴࡪࡰࡪࠫ൯"),Xz3bA2PFENVCUtplu51(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴࡦࡺࡷࡶࡦࡶࡹࡵࡪࡲࡲࡨࡵࡤࡦࠩ൰")]
Fk2qc5asKtOQUSIo9 = [Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠫࡑࡏࡓࡕࡒࡏࡅ࡞࠭൱"),QQdAXWBc2GPw(u"ࠬࡘࡅࡑࡑࡕࡘࡘ࠭൲"),mQNonhS7CV2BXOv(u"࠭ࡅࡎࡃࡌࡐࡘ࠭൳"),m6hwdgP31a2zjN7lkpX(u"ࠧࡎࡇࡖࡗࡆࡍࡅࡔࠩ൴"),zI3ROAZtiUq42rE9WDST68(u"ࠨࡋࡖࡐࡆࡓࡉࡄࡕࠪ൵"),Xz3bA2PFENVCUtplu51(u"ࠩࡔ࡙ࡊ࡙ࡔࡊࡑࡑࡗࠬ൶"),IjZbnrBJmM2N(u"ࠪࡏࡓࡕࡗࡏࡇࡕࡖࡔࡘࡓࠨ൷"),mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠫࡈࡇࡐࡕࡅࡋࡅࠬ൸"),LAQD5wEkr18bUiGaYen3J(u"࡚ࠬࡅࡔࡖࡌࡒࡌ࠭൹"),QQdAXWBc2GPw(u"࠭ࡅ࡙ࡖࡕࡅࡕ࡟ࡔࡉࡑࡑࡇࡔࡊࡅࠨൺ")]
SmnwfjDprzZhuY = [ddo23ZJtgcY(u"ࠧࡂࡆࡇࡓࡓ࡙ࠧൻ"),Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠨࡃࡇࡈࡔࡔࡓ࠲࠺ࠪർ"),ubxGUTt1LraKhVZgpAP(u"ࠩࡄࡈࡉࡕࡎࡔ࠳࠼ࠫൽ")]
class yyNADL9mFOpU1uo(aSP049nZdvtTGDV8wEi75eIOUb):
	def __init__(xV8HnYIrUoJ7X,*aargs,**kkwargs):
		xV8HnYIrUoJ7X.choiceID = -qHYIWnOZLPkrQU
	def onClick(xV8HnYIrUoJ7X,WNvoaXi37e1A0wOKmI):
		if WNvoaXi37e1A0wOKmI>=m6hwdgP31a2zjN7lkpX(u"࠹࠱࠳࠳፿"): xV8HnYIrUoJ7X.choiceID = WNvoaXi37e1A0wOKmI-m6hwdgP31a2zjN7lkpX(u"࠹࠱࠳࠳፿")
		xV8HnYIrUoJ7X.biDrQcnPtdRKlBxLMefW1CaGjOJm()
	def L6lBSU8emu3FtysgaWh2o0CV5nIA(xV8HnYIrUoJ7X,*aargs):
		xV8HnYIrUoJ7X.button0,xV8HnYIrUoJ7X.button1,xV8HnYIrUoJ7X.button2 = aargs[LzYQg91SIxDeOGtCKd5],aargs[qHYIWnOZLPkrQU],aargs[IgQimel18t]
		xV8HnYIrUoJ7X.header,xV8HnYIrUoJ7X.text = aargs[VwApyDY1Jc],aargs[NvHugPosYDzRJ]
		xV8HnYIrUoJ7X.profile,xV8HnYIrUoJ7X.direction = aargs[VFjQx6Is28KvzLOmMXtg4GqTwa3(u"࠶ᎀ")],aargs[UUkIBz1sgQ9WfNeG6trKXvu0(u"࠸ᎁ")]
		xV8HnYIrUoJ7X.buttonstimeout,xV8HnYIrUoJ7X.closetimeout = aargs[m6hwdgP31a2zjN7lkpX(u"࠻ᎃ")],aargs[ubxGUTt1LraKhVZgpAP(u"࠻ᎂ")]
		if xV8HnYIrUoJ7X.buttonstimeout>LzYQg91SIxDeOGtCKd5 or xV8HnYIrUoJ7X.closetimeout>Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"࠵ᎄ"): xV8HnYIrUoJ7X.enable_progressbar = CCxMXuNUEzolDZTKrBJ
		else: xV8HnYIrUoJ7X.enable_progressbar = DD5cFIejQa2X4BgAu9GWPyJ3tC7
		xV8HnYIrUoJ7X.image_filename = PYGjDSCw4zKNef9QZ3By0xn.replace(vvWwO3Tx2dAgcijrFXq(u"ࠪࡣ࠵࠶࠰࠱ࡡࠪൾ"),yST5AHEfvPmcWpwGuh2BJ(u"ࠫࡤ࠭ൿ")+str(wLQCTr5lqbsVYeAHdzfhZ1F.time())+QQdAXWBc2GPw(u"ࠬࡥࠧ඀"))
		xV8HnYIrUoJ7X.image_filename = xV8HnYIrUoJ7X.image_filename.replace(RRIHDFjoW9w7bSfVPhC(u"࠭࡜࡝ࠩඁ"),P0qdZI384LKleuo(u"ࠧ࡝࡞࡟ࡠࠬං")).replace(UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠨ࠱࠲ࠫඃ"),DYakr9g4PVU(u"ࠩ࠲࠳࠴࠵ࠧ඄"))
		xV8HnYIrUoJ7X.image_height = uTSaCs2f9dtPJ3RqGZYhywc(xV8HnYIrUoJ7X.button0,xV8HnYIrUoJ7X.button1,xV8HnYIrUoJ7X.button2,xV8HnYIrUoJ7X.header,xV8HnYIrUoJ7X.text,xV8HnYIrUoJ7X.profile,xV8HnYIrUoJ7X.direction,xV8HnYIrUoJ7X.enable_progressbar,xV8HnYIrUoJ7X.image_filename)
		xV8HnYIrUoJ7X.show()
		xV8HnYIrUoJ7X.getControl(zI3ROAZtiUq42rE9WDST68(u"࠿࠰࠶࠲ᎅ")).setImage(xV8HnYIrUoJ7X.image_filename)
		xV8HnYIrUoJ7X.getControl(BWNPxIG7vqdTy85pjHzUOrK3(u"࠹࠱࠷࠳ᎆ")).setHeight(xV8HnYIrUoJ7X.image_height)
		if not xV8HnYIrUoJ7X.button1 and xV8HnYIrUoJ7X.button0 and xV8HnYIrUoJ7X.button2: xV8HnYIrUoJ7X.getControl(UUkIBz1sgQ9WfNeG6trKXvu0(u"࠻࠳࠵࠷ᎈ")).setPosition(-QQdAXWBc2GPw(u"࠵࠶࠵ᎉ"),Mmpr0o76iWJvz1kTtfgI8hES(u"࠱ᎇ"))
		return xV8HnYIrUoJ7X.image_filename,xV8HnYIrUoJ7X.image_height
	def iJCrUGFgHksNbV13(xV8HnYIrUoJ7X):
		if xV8HnYIrUoJ7X.buttonstimeout:
			xV8HnYIrUoJ7X.th1 = Ay1SMOzkx5CU3aGTL4Zf.Thread(target=xV8HnYIrUoJ7X.emURr0hi1qMxK,args=())
			xV8HnYIrUoJ7X.th1.start()
		else: xV8HnYIrUoJ7X.jjg4G3RCv1L()
	def emURr0hi1qMxK(xV8HnYIrUoJ7X):
		xV8HnYIrUoJ7X.getControl(ubxGUTt1LraKhVZgpAP(u"࠽࠵࠸࠰ᎊ")).setEnabled(CCxMXuNUEzolDZTKrBJ)
		for s9s45taoNBh60XL1zykOmTK3jJCrE in range(qHYIWnOZLPkrQU,xV8HnYIrUoJ7X.buttonstimeout+qHYIWnOZLPkrQU):
			wLQCTr5lqbsVYeAHdzfhZ1F.sleep(qHYIWnOZLPkrQU)
			m0jxDFWwiCYgJ = int(yST5AHEfvPmcWpwGuh2BJ(u"࠶࠶࠰ᎋ")*s9s45taoNBh60XL1zykOmTK3jJCrE/xV8HnYIrUoJ7X.buttonstimeout)
			xV8HnYIrUoJ7X.Ifid0QPF9wG5AkCD2gVEe7W(m0jxDFWwiCYgJ)
			if xV8HnYIrUoJ7X.choiceID>P0qdZI384LKleuo(u"࠶ᎌ"): break
		xV8HnYIrUoJ7X.jjg4G3RCv1L()
	def K4AD9RjdZ5FCvsMh(xV8HnYIrUoJ7X):
		if xV8HnYIrUoJ7X.closetimeout:
			xV8HnYIrUoJ7X.th2 = Ay1SMOzkx5CU3aGTL4Zf.Thread(target=xV8HnYIrUoJ7X.nGjHhm1z8lgZMTc3JELSi4AswWa20O,args=())
			xV8HnYIrUoJ7X.th2.start()
		else: xV8HnYIrUoJ7X.jjg4G3RCv1L()
	def nGjHhm1z8lgZMTc3JELSi4AswWa20O(xV8HnYIrUoJ7X):
		xV8HnYIrUoJ7X.getControl(VFjQx6Is28KvzLOmMXtg4GqTwa3(u"࠹࠱࠴࠳ᎍ")).setEnabled(CCxMXuNUEzolDZTKrBJ)
		wLQCTr5lqbsVYeAHdzfhZ1F.sleep(xV8HnYIrUoJ7X.buttonstimeout)
		for s9s45taoNBh60XL1zykOmTK3jJCrE in range(xV8HnYIrUoJ7X.closetimeout-qHYIWnOZLPkrQU,-qHYIWnOZLPkrQU,-qHYIWnOZLPkrQU):
			wLQCTr5lqbsVYeAHdzfhZ1F.sleep(qHYIWnOZLPkrQU)
			m0jxDFWwiCYgJ = int(Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"࠲࠲࠳ᎎ")*s9s45taoNBh60XL1zykOmTK3jJCrE/xV8HnYIrUoJ7X.closetimeout)
			xV8HnYIrUoJ7X.Ifid0QPF9wG5AkCD2gVEe7W(m0jxDFWwiCYgJ)
			if xV8HnYIrUoJ7X.choiceID>LzYQg91SIxDeOGtCKd5: break
		if xV8HnYIrUoJ7X.closetimeout>LzYQg91SIxDeOGtCKd5: xV8HnYIrUoJ7X.choiceID = VFjQx6Is28KvzLOmMXtg4GqTwa3(u"࠳࠳ᎏ")
		xV8HnYIrUoJ7X.biDrQcnPtdRKlBxLMefW1CaGjOJm()
	def Ifid0QPF9wG5AkCD2gVEe7W(xV8HnYIrUoJ7X,m0jxDFWwiCYgJ):
		xV8HnYIrUoJ7X.precent = m0jxDFWwiCYgJ
		xV8HnYIrUoJ7X.getControl(mmcNLrXtzfpyCkZlvK5VwG2gujh(u"࠼࠴࠷࠶᎐")).setPercent(xV8HnYIrUoJ7X.precent)
	def jjg4G3RCv1L(xV8HnYIrUoJ7X):
		if xV8HnYIrUoJ7X.button0: xV8HnYIrUoJ7X.getControl(QQdAXWBc2GPw(u"࠽࠵࠷࠰᎑")).setEnabled(CCxMXuNUEzolDZTKrBJ)
		if xV8HnYIrUoJ7X.button1: xV8HnYIrUoJ7X.getControl(kke1PDGRBLuY8y(u"࠾࠶࠱࠲᎒")).setEnabled(CCxMXuNUEzolDZTKrBJ)
		if xV8HnYIrUoJ7X.button2: xV8HnYIrUoJ7X.getControl(BWNPxIG7vqdTy85pjHzUOrK3(u"࠿࠰࠲࠴᎓")).setEnabled(CCxMXuNUEzolDZTKrBJ)
	def biDrQcnPtdRKlBxLMefW1CaGjOJm(xV8HnYIrUoJ7X):
		xV8HnYIrUoJ7X.close()
		try: x76PfMyAp1L2WejkU3.remove(xV8HnYIrUoJ7X.image_filename)
		except: pass
class mIv7g95PNyqzLZDM8ihkcr1w():
	def __init__(xV8HnYIrUoJ7X,showDialogs=DD5cFIejQa2X4BgAu9GWPyJ3tC7,logErrors=CCxMXuNUEzolDZTKrBJ):
		xV8HnYIrUoJ7X.showDialogs = showDialogs
		xV8HnYIrUoJ7X.logErrors = logErrors
		xV8HnYIrUoJ7X.finishedLIST,xV8HnYIrUoJ7X.failedLIST = [],[]
		xV8HnYIrUoJ7X.statusDICT,xV8HnYIrUoJ7X.resultsDICT = {},{}
		xV8HnYIrUoJ7X.processesLIST = []
		xV8HnYIrUoJ7X.starttimeDICT,xV8HnYIrUoJ7X.finishtimeDICT,xV8HnYIrUoJ7X.elpasedtimeDICT = {},{},{}
	def B2pHMo1xcYrylP6fDbku4VeEqtWIGS(xV8HnYIrUoJ7X,od4AIsBzi3Ga2bLXNlZKME,XX3k8EUPWOIGrp,*aargs):
		od4AIsBzi3Ga2bLXNlZKME = str(od4AIsBzi3Ga2bLXNlZKME)
		xV8HnYIrUoJ7X.statusDICT[od4AIsBzi3Ga2bLXNlZKME] = m6hwdgP31a2zjN7lkpX(u"ࠪࡶࡺࡴ࡮ࡪࡰࡪࠫඅ")
		if xV8HnYIrUoJ7X.showDialogs: yicQV3gj4q(b8Qe150xVaJsnDSv,od4AIsBzi3Ga2bLXNlZKME)
		hU4X97LmIKOsHVkvpJxw = Ay1SMOzkx5CU3aGTL4Zf.Thread(target=xV8HnYIrUoJ7X.gFdwVcXSNfCzIWkU5jR1ypveq,args=(od4AIsBzi3Ga2bLXNlZKME,XX3k8EUPWOIGrp,aargs))
		xV8HnYIrUoJ7X.processesLIST.append(hU4X97LmIKOsHVkvpJxw)
		return hU4X97LmIKOsHVkvpJxw
	def N4vDb3TKpY0Lr(xV8HnYIrUoJ7X,od4AIsBzi3Ga2bLXNlZKME,XX3k8EUPWOIGrp,*aargs):
		hU4X97LmIKOsHVkvpJxw = xV8HnYIrUoJ7X.B2pHMo1xcYrylP6fDbku4VeEqtWIGS(od4AIsBzi3Ga2bLXNlZKME,XX3k8EUPWOIGrp,*aargs)
		hU4X97LmIKOsHVkvpJxw.start()
	def gFdwVcXSNfCzIWkU5jR1ypveq(xV8HnYIrUoJ7X,od4AIsBzi3Ga2bLXNlZKME,XX3k8EUPWOIGrp,aargs):
		od4AIsBzi3Ga2bLXNlZKME = str(od4AIsBzi3Ga2bLXNlZKME)
		xV8HnYIrUoJ7X.starttimeDICT[od4AIsBzi3Ga2bLXNlZKME] = wLQCTr5lqbsVYeAHdzfhZ1F.time()
		try:
			xV8HnYIrUoJ7X.resultsDICT[od4AIsBzi3Ga2bLXNlZKME] = XX3k8EUPWOIGrp(*aargs)
			if mQNonhS7CV2BXOv(u"ࠫࡔࡖࡅࡏࡗࡕࡐࠬආ") in str(XX3k8EUPWOIGrp) and not xV8HnYIrUoJ7X.resultsDICT[od4AIsBzi3Ga2bLXNlZKME].succeeded: AKQaWIc0YCHGVnT()
			xV8HnYIrUoJ7X.finishedLIST.append(od4AIsBzi3Ga2bLXNlZKME)
			xV8HnYIrUoJ7X.statusDICT[od4AIsBzi3Ga2bLXNlZKME] = ubxGUTt1LraKhVZgpAP(u"ࠬ࡬ࡩ࡯࡫ࡶ࡬ࡪࡪࠧඇ")
		except Exception as uXp8Hv2nDt:
			if xV8HnYIrUoJ7X.logErrors:
				yABitW02UXORGEJQPsTujcL = n9dSEJTBOWlY6.format_exc()
				if yABitW02UXORGEJQPsTujcL!=IjZbnrBJmM2N(u"࠭ࡎࡰࡰࡨࡘࡾࡶࡥ࠻ࠢࡑࡳࡳ࡫࡜࡯ࠩඈ"): Pft6y0LvwSh48iYg7b.stderr.write(yABitW02UXORGEJQPsTujcL)
			xV8HnYIrUoJ7X.failedLIST.append(od4AIsBzi3Ga2bLXNlZKME)
			xV8HnYIrUoJ7X.statusDICT[od4AIsBzi3Ga2bLXNlZKME] = uVQd103XyvUce2EBtzbYaC(u"ࠧࡧࡣ࡬ࡰࡪࡪࠧඉ")
		xV8HnYIrUoJ7X.finishtimeDICT[od4AIsBzi3Ga2bLXNlZKME] = wLQCTr5lqbsVYeAHdzfhZ1F.time()
		xV8HnYIrUoJ7X.elpasedtimeDICT[od4AIsBzi3Ga2bLXNlZKME] = xV8HnYIrUoJ7X.finishtimeDICT[od4AIsBzi3Ga2bLXNlZKME] - xV8HnYIrUoJ7X.starttimeDICT[od4AIsBzi3Ga2bLXNlZKME]
	def G3WuIvkoyTEHSgprqVwJm5x(xV8HnYIrUoJ7X):
		for aawZ2Ct9LsQnY3pqfAObm0EW in xV8HnYIrUoJ7X.processesLIST:
			aawZ2Ct9LsQnY3pqfAObm0EW.start()
	def O3fLNF8G1Sh(xV8HnYIrUoJ7X):
		while vvWwO3Tx2dAgcijrFXq(u"ࠨࡴࡸࡲࡳ࡯࡮ࡨࠩඊ") in list(xV8HnYIrUoJ7X.statusDICT.values()): wLQCTr5lqbsVYeAHdzfhZ1F.sleep(Nh0BWuiSndf(u"࠱᎔"))
def FhcSKzxwv0JTXV9RLdb3Y6ps():
	if not l1RsIerQAtbJjMTzGEWP2L: return QQdAXWBc2GPw(u"ࠩࡑࡓࡤ࡛ࡐࡅࡃࡗࡉࠬඋ")
	iiDVcpj52xu3RvO9qA1wJ40XaZCPIs = RRIHDFjoW9w7bSfVPhC(u"ࠪࡊ࡚ࡒࡌࡠࡗࡓࡈࡆ࡚ࡅࠨඌ")
	t1tCHUZdS6T4k3AKDa = [shC5qBRV2A0lZ(u"ࠫ࠽࠴࠵࠯࠲ࠪඍ"),shC5qBRV2A0lZ(u"ࠬ࠸࠰࠳࠳࠱࠵࠵࠴࠱࠺ࠩඎ"),m6hwdgP31a2zjN7lkpX(u"࠭࠲࠱࠴࠴࠲࠶࠷࠮࠳࠶ࡤࠫඏ"),ddo23ZJtgcY(u"ࠧ࠳࠲࠵࠵࠳࠷࠲࠯࠵࠳ࠫඐ"),dDYUoKi6JFM23p(u"ࠨ࠴࠳࠶࠷࠴࠰࠳࠰࠳࠶ࠬඑ"),BWNPxIG7vqdTy85pjHzUOrK3(u"ࠩ࠵࠴࠷࠸࠮࠲࠲࠱࠶࠷࠭ඒ"),Nh0BWuiSndf(u"ࠪ࠶࠵࠸࠳࠯࠲࠶࠲࠵࠼ࠧඓ"),TYf7Dc06PQgy1vEV9(u"ࠫ࠷࠶࠲࠴࠰࠳࠹࠳࠷࠶ࠨඔ"),shC5qBRV2A0lZ(u"ࠬ࠸࠰࠳࠵࠱࠴࠻࠴࠰࠷ࠩඕ"),zI3ROAZtiUq42rE9WDST68(u"࠭࠲࠱࠴࠶࠲࠶࠶࠮࠳࠺ࠪඖ"),shC5qBRV2A0lZ(u"ࠧ࠳࠲࠵࠸࠳࠶࠱࠯࠳࠷ࠫ඗"),kke1PDGRBLuY8y(u"ࠨ࠴࠳࠶࠹࠴࠰࠸࠰࠵࠴ࠬ඘")]
	JaLGgrxCSHqU3Qdn0o6yXm78DVNlsP = t1tCHUZdS6T4k3AKDa[-qHYIWnOZLPkrQU]
	MjYsgA3Orq = qowTBnzym3(JaLGgrxCSHqU3Qdn0o6yXm78DVNlsP)
	Gi3TFlr8KmbXf = qowTBnzym3(cpGrK6qnPi)
	if Gi3TFlr8KmbXf>MjYsgA3Orq:
		iiDVcpj52xu3RvO9qA1wJ40XaZCPIs = TYf7Dc06PQgy1vEV9(u"ࠩࡖࡍࡒࡖࡌࡆࡡࡘࡔࡉࡇࡔࡆࠩ඙")
	return iiDVcpj52xu3RvO9qA1wJ40XaZCPIs
def Z42sIuN3mc1():
	for McGhkSLOlX5HAJtKPZr,JxsbNOUt1lHT4Rr8uainPKv5,G4upaV8ed9NfPAc in x76PfMyAp1L2WejkU3.walk(fH3Ie4SrRCsFMVo98hpN,topdown=DD5cFIejQa2X4BgAu9GWPyJ3tC7):
		if len(G4upaV8ed9NfPAc)>VFjQx6Is28KvzLOmMXtg4GqTwa3(u"࠶࠲࠳᎕"): p3pjrEcdKBfsDZw4qSJ(McGhkSLOlX5HAJtKPZr,DD5cFIejQa2X4BgAu9GWPyJ3tC7,DD5cFIejQa2X4BgAu9GWPyJ3tC7)
	return
def KKt5zJyFWQAuhpecY(XX8FguGmKp5DVB2Twifsc):
	if shC5qBRV2A0lZ(u"ࠪࡉ࡝࡚ࡒࡂࡒ࡜ࡘࡍࡕࡎࡄࡑࡇࡉࠬක") in str(ZHIif0JXSYpqh1OKuoR): return
	global nTHXJIiah2qK,qqEBN1GzvSmf,kT4dIMNtgJXAxUWfFBHQLlPoK2qb6,bT46adeyIWDBiArPH3V5027,djEh4qtWn9H,m0mjZVkpsdDGKByLtfTi1l4REYqUvM
	br0Ws3MoaLuTC9j = b8Qe150xVaJsnDSv
	if XX8FguGmKp5DVB2Twifsc: br0Ws3MoaLuTC9j = SS2OK7hjLagvUAm(mshLJcKH1fv03yRnDOr4ZT,zI3ROAZtiUq42rE9WDST68(u"ࠫࡸࡺࡲࠨඛ"),mQNonhS7CV2BXOv(u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࠨග"),TT8Mxv5Wq7nlC9IscdpPUY6(u"࠭ࡅ࡙ࡖࡕࡅࡕ࡟ࡔࡉࡑࡑࡇࡔࡊࡅࠨඝ"))
	if not br0Ws3MoaLuTC9j:
		YabJfs3q7yjpzvXioO = nTHXJIiah2qK[uVQd103XyvUce2EBtzbYaC(u"ࠧࡑ࡛ࡗࡌࡔࡔࠧඞ")][Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"࠻᎖")]
		j01czpBZWA4hU87dHaryJ5Cu = {Mmpr0o76iWJvz1kTtfgI8hES(u"ࠨࡷࡶࡩࡷ࠭ඟ"):EtvK0T2LNPcsIrAFlufpM,TYf7Dc06PQgy1vEV9(u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪච"):cpGrK6qnPi}
		Ci4rQ0qV915j2AIkHTbcy = dcLRAZWFzODax2jf0tHCX81pJveNY(nCUMfrlZvuiLe5x,mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠪࡔࡔ࡙ࡔࠨඡ"),YabJfs3q7yjpzvXioO,j01czpBZWA4hU87dHaryJ5Cu,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡋࡘࡕࡔࡄࡣࡕ࡟ࡔࡉࡑࡑࡣࡈࡕࡄࡆ࠯࠴ࡷࡹ࠭ජ"))
		if Ci4rQ0qV915j2AIkHTbcy.succeeded:
			br0Ws3MoaLuTC9j = Ci4rQ0qV915j2AIkHTbcy.content
			PGudrhJF8iDkSq96XVHEQZYf5L(mshLJcKH1fv03yRnDOr4ZT,Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࠨඣ"),Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"࠭ࡅ࡙ࡖࡕࡅࡕ࡟ࡔࡉࡑࡑࡇࡔࡊࡅࠨඤ"),br0Ws3MoaLuTC9j,t58tnzAgevxkoIOdMFbE2PsD64q0C9)
	if br0Ws3MoaLuTC9j:
		global NEW_SITESURLS,NEW_BADSCRAPERS,NEW_BADWEBSITES
		exec(br0Ws3MoaLuTC9j,globals(),locals())
		nTHXJIiah2qK.update(NEW_SITESURLS)
		qqEBN1GzvSmf = NEW_BADSCRAPERS
		if cpGrK6qnPi in list(NEW_BADWEBSITES.keys()): kT4dIMNtgJXAxUWfFBHQLlPoK2qb6 += NEW_BADWEBSITES[cpGrK6qnPi]
		for TFAmLfwypkzsP1UYCMr8c in kT4dIMNtgJXAxUWfFBHQLlPoK2qb6:
			if TFAmLfwypkzsP1UYCMr8c in bT46adeyIWDBiArPH3V5027: bT46adeyIWDBiArPH3V5027.remove(TFAmLfwypkzsP1UYCMr8c)
			if TFAmLfwypkzsP1UYCMr8c in djEh4qtWn9H: djEh4qtWn9H.remove(TFAmLfwypkzsP1UYCMr8c)
			if TFAmLfwypkzsP1UYCMr8c in m0mjZVkpsdDGKByLtfTi1l4REYqUvM: m0mjZVkpsdDGKByLtfTi1l4REYqUvM.remove(TFAmLfwypkzsP1UYCMr8c)
	return
def rdZILqz9Y4ef():
	try: x76PfMyAp1L2WejkU3.makedirs(vIaQF8hqXeiJERYuD)
	except: pass
	aBpAlEv4k5nwmSOXRVbDzuT3Ujr0Zq = FhcSKzxwv0JTXV9RLdb3Y6ps()
	if aBpAlEv4k5nwmSOXRVbDzuT3Ujr0Zq==IjZbnrBJmM2N(u"ࠧࡔࡋࡐࡔࡑࡋ࡟ࡖࡒࡇࡅ࡙ࡋࠧඥ"): mwIxD3GBPgLVc2aq9(MtTygrzXFlQ,TYf7Dc06PQgy1vEV9(u"ࠨ࠰࡟ࡸࡆࡸࡡࡣ࡫ࡦ࡚࡮ࡪࡥࡰࡵ࡙ࠣࡵࡪࡡࡵࡧࠣࡘࡾࡶࡥ࠻ࠢࠣࡗࡎࡓࡐࡍࡇ࡙ࠣࡕࡊࡁࡕࡇࠣࠤࠥࡖࡡࡵࡪ࠽ࠤࡠࠦࠧඦ")+ZqDQCMovyXKFG7ki4BrahuWt1IS8+LAQD5wEkr18bUiGaYen3J(u"ࠩࠣࡡࠬට"))
	else: mwIxD3GBPgLVc2aq9(MtTygrzXFlQ,TYf7Dc06PQgy1vEV9(u"ࠪ࠲ࡡࡺࡁࡳࡣࡥ࡭ࡨ࡜ࡩࡥࡧࡲࡷ࡛ࠥࡰࡥࡣࡷࡩ࡚ࠥࡹࡱࡧ࠽ࠤࠥࡌࡕࡍࡎ࡙ࠣࡕࡊࡁࡕࡇࠣࠤࠥࡖࡡࡵࡪ࠽ࠤࡠࠦࠧඨ")+ZqDQCMovyXKFG7ki4BrahuWt1IS8+QTUBCcehw6qPd4x(u"ࠫࠥࡣࠧඩ"))
	tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨඪ"),HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"࠭สๆࠢอัิ๐หࠡษ็ฬึ์วๆฮࠣๅ๏ࠦฬ่ษี็ࡡࡴลๅ๋ࠣห้หีะษิࠤึ่ๅ࠻࡞ࡱࡠࡳ࠭ණ")+cpGrK6qnPi)
	tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,QTUBCcehw6qPd4x(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪඬ"),DYakr9g4PVU(u"ࠨฬ่ࠤฯัศ๋ฬࠣวํࠦสฮัํฯࠥอไฦืาหึࠦวๅฮา๎ิࠦไษำ้ห๊าࠠศๆไ๎ิ๐่่ษอࠤฬู๊าสํอࠥ࠴ࠠฤ๊ࠣฮ๊ࠦๅิฯࠣ็ฬฺࠠศๆหี๋อๅอࠢ࡟ࡲࡡࡴࠠิ์ๅ์๊ࠦวๅฤ้ࠤฬ๊ศา่ส้ัࠦศษ฻ูࠤฬ๊แฮุ๊หฯࠦไื็ส๊ࠥ฿ๅๅࠢส่อืๆศ็ฯࠤอ฻่าหูࠣา๐อส๋้ࠢฯ้วๆๆฬࠫත"))
	zqbhiLmQfC3VK9Arku(mshLJcKH1fv03yRnDOr4ZT,SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬථ"),UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠪࡕ࡚ࡋࡓࡕࡋࡒࡒࡘ࠭ද"))
	zqbhiLmQfC3VK9Arku(mshLJcKH1fv03yRnDOr4ZT,VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧධ"),QQdAXWBc2GPw(u"ࠬࡇࡌࡍࡡࡄࡈࡉࡕࡎࡔࡡ࡛ࡑࡑ࠭න"))
	zqbhiLmQfC3VK9Arku(mshLJcKH1fv03yRnDOr4ZT,Mmpr0o76iWJvz1kTtfgI8hES(u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩ඲"),kke1PDGRBLuY8y(u"ࠧࡇࡑࡕ࡛ࡆࡘࡄࡔࠩඳ"))
	zqbhiLmQfC3VK9Arku(mshLJcKH1fv03yRnDOr4ZT,mQNonhS7CV2BXOv(u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫප"),uVQd103XyvUce2EBtzbYaC(u"ࠩࡖࡍ࡙ࡋࡓࡠࡐࡄࡑࡊ࡙ࠧඵ"))
	zqbhiLmQfC3VK9Arku(mshLJcKH1fv03yRnDOr4ZT,P0qdZI384LKleuo(u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭බ"),mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠫࡘࡏࡔࡆࡕࡢࡇࡍࡋࡃࡌࠩභ"))
	zqbhiLmQfC3VK9Arku(mshLJcKH1fv03yRnDOr4ZT,mQNonhS7CV2BXOv(u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨම"),Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"࠭ࡓࡊࡖࡈࡗࡤ࡜ࡅࡓࡋࡉ࡝ࠬඹ"))
	hRWC8YSFvsm4JHOMVIne3jquZ.setSetting(ubxGUTt1LraKhVZgpAP(u"ࠧࡢࡸ࠱࡬ࡴࡹࡴ࠯ࡨࡲࡷࡹࡧࠧය"),b8Qe150xVaJsnDSv)
	hRWC8YSFvsm4JHOMVIne3jquZ.setSetting(IjZbnrBJmM2N(u"ࠨࡣࡹ࠲࡭ࡵࡳࡵ࠰ࡩࡥࡧࡸࡡ࡬ࡣࠪර"),b8Qe150xVaJsnDSv)
	hRWC8YSFvsm4JHOMVIne3jquZ.setSetting(ubxGUTt1LraKhVZgpAP(u"ࠩࡤࡺ࠳࡮࡯ࡴࡶ࠱ࡷ࡭ࡧࡨࡪࡦ࠷ࡹࠬ඼"),b8Qe150xVaJsnDSv)
	hRWC8YSFvsm4JHOMVIne3jquZ.setSetting(QTUBCcehw6qPd4x(u"ࠪࡥࡻ࠴ࡨࡰࡵࡷ࠲࡫ࡧࡳࡦ࡮࡫ࡨ࠶࠭ල"),b8Qe150xVaJsnDSv)
	hRWC8YSFvsm4JHOMVIne3jquZ.setSetting(UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠫࡦࡼ࠮ࡱࡴ࡬ࡺࡸ࠷ࠧ඾"),b8Qe150xVaJsnDSv)
	hRWC8YSFvsm4JHOMVIne3jquZ.setSetting(TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠬࡧࡶ࠯ࡲࡵ࡭ࡻࡹ࠲ࠨ඿"),b8Qe150xVaJsnDSv)
	hRWC8YSFvsm4JHOMVIne3jquZ.setSetting(DYakr9g4PVU(u"࠭ࡡࡷ࠰ࡳࡩࡷ࡯࡯ࡥ࠰࡬ࡲ࡫ࡵࡳࠨව"),b8Qe150xVaJsnDSv)
	hRWC8YSFvsm4JHOMVIne3jquZ.setSetting(S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴ࡳࡩࡱࡵࡸࠬශ"),b8Qe150xVaJsnDSv)
	hRWC8YSFvsm4JHOMVIne3jquZ.setSetting(kke1PDGRBLuY8y(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮ࡳࡧࡪࡹࡱࡧࡲࠨෂ"),b8Qe150xVaJsnDSv)
	hRWC8YSFvsm4JHOMVIne3jquZ.setSetting(P0qdZI384LKleuo(u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯࡮ࡲࡲ࡬࠭ස"),b8Qe150xVaJsnDSv)
	hRWC8YSFvsm4JHOMVIne3jquZ.setSetting(m6hwdgP31a2zjN7lkpX(u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰ࡰࡩࡸࡹࡡࡨࡧࡶࠫහ"),b8Qe150xVaJsnDSv)
	hRWC8YSFvsm4JHOMVIne3jquZ.setSetting(uVQd103XyvUce2EBtzbYaC(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ࠭ළ"),b8Qe150xVaJsnDSv)
	zqbhiLmQfC3VK9Arku(mshLJcKH1fv03yRnDOr4ZT,S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡔࡋࡗࡉࡘ࠭ෆ"))
	zqbhiLmQfC3VK9Arku(mshLJcKH1fv03yRnDOr4ZT,zI3ROAZtiUq42rE9WDST68(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡋࡓࡘ࡛࠭෇"))
	zqbhiLmQfC3VK9Arku(mshLJcKH1fv03yRnDOr4ZT,UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡐ࠷࡚࠭෈"))
	zqbhiLmQfC3VK9Arku(mshLJcKH1fv03yRnDOr4ZT,vvWwO3Tx2dAgcijrFXq(u"ࠨࡕࡆࡖࡆࡖࡅࡓࡕࡢࡗ࡙ࡇࡔࡖࡕࠪ෉"))
	bb80Orl1IgxV6(DD5cFIejQa2X4BgAu9GWPyJ3tC7)
	lp8eUQ9rw25BhRgWNPHT7K(nCUMfrlZvuiLe5x)
	import cTGphBXNeH
	cTGphBXNeH.OsdWDnBA5bgqZlXPhmeuK60cCU7(CCxMXuNUEzolDZTKrBJ)
	if aBpAlEv4k5nwmSOXRVbDzuT3Ujr0Zq==BWNPxIG7vqdTy85pjHzUOrK3(u"ࠩࡖࡍࡒࡖࡌࡆࡡࡘࡔࡉࡇࡔࡆ්ࠩ"):
		thjSw2b6gur9s(CCxMXuNUEzolDZTKrBJ,[mshLJcKH1fv03yRnDOr4ZT])
	else:
		thjSw2b6gur9s(DD5cFIejQa2X4BgAu9GWPyJ3tC7,[])
		cTGphBXNeH.KMHWjelkc5I()
		cTGphBXNeH.iYa4V16rHzIO(uVQd103XyvUce2EBtzbYaC(u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡣࡧࡥࡵࡺࡩࡷࡧࠪ෋"),DD5cFIejQa2X4BgAu9GWPyJ3tC7)
		cTGphBXNeH.iYa4V16rHzIO(RRIHDFjoW9w7bSfVPhC(u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡵࡸࡲࡶࠧ෌"),DD5cFIejQa2X4BgAu9GWPyJ3tC7)
		try:
			eziy2qrbWDxo = x76PfMyAp1L2WejkU3.path.join(BdO6FDlYv4naqZf1gCGbS7V,ddo23ZJtgcY(u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧ෍"),ddo23ZJtgcY(u"࠭ࡡࡥࡦࡲࡲࡤࡪࡡࡵࡣࠪ෎"),DYakr9g4PVU(u"ࠧࡴࡥࡵ࡭ࡵࡺ࠮࡮ࡱࡧࡹࡱ࡫࠮ࡳࡧࡶࡳࡱࡼࡥࡶࡴ࡯ࠫා"),shC5qBRV2A0lZ(u"ࠨࡵࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡼࡲࡲࠧැ"))
			Hp67LtlMUdq1iNC9BvGwnJrFA = iA97UEDqm2P.Addon(id=P0qdZI384LKleuo(u"ࠩࡶࡧࡷ࡯ࡰࡵ࠰ࡰࡳࡩࡻ࡬ࡦ࠰ࡵࡩࡸࡵ࡬ࡷࡧࡸࡶࡱ࠭ෑ"))
			Hp67LtlMUdq1iNC9BvGwnJrFA.setSetting(ubxGUTt1LraKhVZgpAP(u"ࠪࡥࡻ࠴ࡡࡶࡶࡲࡣࡵ࡯ࡣ࡬ࠩි"),BmePGjS7FxK6kutUM(u"ࠫࡋࡧ࡬ࡴࡧࠪී"))
		except: pass
		try:
			eziy2qrbWDxo = x76PfMyAp1L2WejkU3.path.join(BdO6FDlYv4naqZf1gCGbS7V,mQNonhS7CV2BXOv(u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧු"),Mmpr0o76iWJvz1kTtfgI8hES(u"࠭ࡡࡥࡦࡲࡲࡤࡪࡡࡵࡣࠪ෕"),S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠧࡴࡥࡵ࡭ࡵࡺ࠮࡮ࡱࡧࡹࡱ࡫࠮ࡺࡶ࠰ࡨࡱࡶࠧූ"),zI3ROAZtiUq42rE9WDST68(u"ࠨࡵࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡼࡲࡲࠧ෗"))
			Hp67LtlMUdq1iNC9BvGwnJrFA = iA97UEDqm2P.Addon(id=TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠩࡶࡧࡷ࡯ࡰࡵ࠰ࡰࡳࡩࡻ࡬ࡦ࠰ࡼࡸ࠲ࡪ࡬ࡱࠩෘ"))
			Hp67LtlMUdq1iNC9BvGwnJrFA.setSetting(HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠪࡥࡻ࠴ࡶࡪࡦࡨࡳࡤࡷࡵࡢ࡮࡬ࡸࡾ࠭ෙ"),kke1PDGRBLuY8y(u"ࠫ࠸࠭ේ"))
		except: pass
		try:
			eziy2qrbWDxo = x76PfMyAp1L2WejkU3.path.join(BdO6FDlYv4naqZf1gCGbS7V,RRIHDFjoW9w7bSfVPhC(u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧෛ"),BmePGjS7FxK6kutUM(u"࠭ࡡࡥࡦࡲࡲࡤࡪࡡࡵࡣࠪො"),uVQd103XyvUce2EBtzbYaC(u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡧࡤࡢࡲࡷ࡭ࡻ࡫ࠧෝ"),BWNPxIG7vqdTy85pjHzUOrK3(u"ࠨࡵࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡼࡲࡲࠧෞ"))
			Hp67LtlMUdq1iNC9BvGwnJrFA = iA97UEDqm2P.Addon(id=RRIHDFjoW9w7bSfVPhC(u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡢࡦࡤࡴࡹ࡯ࡶࡦࠩෟ"))
			Hp67LtlMUdq1iNC9BvGwnJrFA.setSetting(LAQD5wEkr18bUiGaYen3J(u"ࠪࡥࡻ࠴ࡓࡕࡔࡈࡅࡒ࡙ࡅࡍࡇࡆࡘࡎࡕࡎࠨ෠"),QQdAXWBc2GPw(u"ࠫ࠷࠭෡"))
		except: pass
	kTSyagGWsFnolYhMO5fCwvpNuPqR = dyWw4klir2R3uM8DUthJxKP(oYXBd89zTnZPipv56Qf1UxurbC3)
	kTSyagGWsFnolYhMO5fCwvpNuPqR = dyWw4klir2R3uM8DUthJxKP(KNTV1H9Dl32a6yxiUEBdvZ7qgr)
	cTGphBXNeH.UWBjmvw5CIz3Dt8i(DD5cFIejQa2X4BgAu9GWPyJ3tC7)
	hRWC8YSFvsm4JHOMVIne3jquZ.setSetting(Mmpr0o76iWJvz1kTtfgI8hES(u"ࠬࡧࡶ࠯ࡸࡨࡶࡸ࡯࡯࡯ࠩ෢"),cpGrK6qnPi)
	qMGn9u2ckaXejCgUQhYTDP(DD5cFIejQa2X4BgAu9GWPyJ3tC7)
	return
def Sh3CL7ic9k6nXOz():
	bQxG9ZIYRW1OqL = vdkzUJEgiO2Poj0Ih3pL(hRWC8YSFvsm4JHOMVIne3jquZ.getSetting(kke1PDGRBLuY8y(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡹࡨࡰࡴࡷࠫ෣")))
	bQxG9ZIYRW1OqL = LzYQg91SIxDeOGtCKd5 if not bQxG9ZIYRW1OqL else int(bQxG9ZIYRW1OqL)
	if not bQxG9ZIYRW1OqL or not LzYQg91SIxDeOGtCKd5<=T3Axql94cU0BpO1wudEDtWXsf-bQxG9ZIYRW1OqL<=LtlXH3fvMydAx:
		hRWC8YSFvsm4JHOMVIne3jquZ.setSetting(Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴ࡳࡩࡱࡵࡸࠬ෤"),hk9Mxv3LzSHl42AUdfs0ejF7qcVw(T3Axql94cU0BpO1wudEDtWXsf))
		lp8eUQ9rw25BhRgWNPHT7K(nCUMfrlZvuiLe5x)
		d7E46SWkHAgGN3x = vdkzUJEgiO2Poj0Ih3pL(hRWC8YSFvsm4JHOMVIne3jquZ.getSetting(UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮ࡳࡧࡪࡹࡱࡧࡲࠨ෥")))
		d7E46SWkHAgGN3x = LzYQg91SIxDeOGtCKd5 if not d7E46SWkHAgGN3x else int(d7E46SWkHAgGN3x)
		if not d7E46SWkHAgGN3x or not LzYQg91SIxDeOGtCKd5<=T3Axql94cU0BpO1wudEDtWXsf-d7E46SWkHAgGN3x<=GMkNL1RXxKFentp0Zh9d:
			hRWC8YSFvsm4JHOMVIne3jquZ.setSetting(LAQD5wEkr18bUiGaYen3J(u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯ࡴࡨ࡫ࡺࡲࡡࡳࠩ෦"),hk9Mxv3LzSHl42AUdfs0ejF7qcVw(T3Axql94cU0BpO1wudEDtWXsf))
			KKt5zJyFWQAuhpecY(DD5cFIejQa2X4BgAu9GWPyJ3tC7)
		aasl7f6Q0vdzgy = vdkzUJEgiO2Poj0Ih3pL(hRWC8YSFvsm4JHOMVIne3jquZ.getSetting(BWNPxIG7vqdTy85pjHzUOrK3(u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰࡯ࡳࡳ࡭ࠧ෧")))
		aasl7f6Q0vdzgy = LzYQg91SIxDeOGtCKd5 if not aasl7f6Q0vdzgy else int(aasl7f6Q0vdzgy)
		if not aasl7f6Q0vdzgy or not LzYQg91SIxDeOGtCKd5<=T3Axql94cU0BpO1wudEDtWXsf-aasl7f6Q0vdzgy<=Q49IsrlSuYRAVbGKhwdckLDOetF2PZ:
			hRWC8YSFvsm4JHOMVIne3jquZ.setSetting(Xz3bA2PFENVCUtplu51(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡰࡴࡴࡧࠨ෨"),hk9Mxv3LzSHl42AUdfs0ejF7qcVw(T3Axql94cU0BpO1wudEDtWXsf))
			hU4X97LmIKOsHVkvpJxw = Ay1SMOzkx5CU3aGTL4Zf.Thread(target=Z42sIuN3mc1)
			hU4X97LmIKOsHVkvpJxw.start()
	wkg1U8LZ45f739xTX0Qdjsbnz = vdkzUJEgiO2Poj0Ih3pL(hRWC8YSFvsm4JHOMVIne3jquZ.getSetting(BmePGjS7FxK6kutUM(u"ࠬࡧࡶ࠯ࡲࡨࡶ࡮ࡵࡤ࠯࡫ࡱࡪࡴࡹࠧ෩")))
	wkg1U8LZ45f739xTX0Qdjsbnz = LzYQg91SIxDeOGtCKd5 if not wkg1U8LZ45f739xTX0Qdjsbnz else int(wkg1U8LZ45f739xTX0Qdjsbnz)
	FspcjWLfPMr5I = vdkzUJEgiO2Poj0Ih3pL(hRWC8YSFvsm4JHOMVIne3jquZ.getSetting(vvWwO3Tx2dAgcijrFXq(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡷࡵࡦࡵࡷ࡭ࡴࡴࡳࠨ෪")))
	FspcjWLfPMr5I = LzYQg91SIxDeOGtCKd5 if not FspcjWLfPMr5I else int(FspcjWLfPMr5I)
	if not wkg1U8LZ45f739xTX0Qdjsbnz or not FspcjWLfPMr5I or not LzYQg91SIxDeOGtCKd5<=T3Axql94cU0BpO1wudEDtWXsf-FspcjWLfPMr5I<=wkg1U8LZ45f739xTX0Qdjsbnz: oFBclmuZOt5InK1xaCXL0()
	return
def oFBclmuZOt5InK1xaCXL0():
	Q4QvO7PftYr1bgExZn3aoAqB9j0 = qHYIWnOZLPkrQU
	PheFRL2S69Xa1dKb4IqEng5spyCH7Z = DD5cFIejQa2X4BgAu9GWPyJ3tC7 if XrloM5pTyK.pYMuE6jbdODCPUH else CCxMXuNUEzolDZTKrBJ
	if PheFRL2S69Xa1dKb4IqEng5spyCH7Z:
		I6EPVkCug24fet = Lv5gTyYmiskeUS(CCxMXuNUEzolDZTKrBJ)
		if len(I6EPVkCug24fet)>qHYIWnOZLPkrQU:
			mwIxD3GBPgLVc2aq9(MtTygrzXFlQ,IjZbnrBJmM2N(u"ࠧ࠯࡞ࡷࡗ࡭ࡵࡷࡪࡰࡪࠤࡖࡻࡥࡴࡶ࡬ࡳࡳࠦࠠࠡࡒࡤࡸ࡭ࡀࠠ࡜ࠢࠪ෫")+ZqDQCMovyXKFG7ki4BrahuWt1IS8+shC5qBRV2A0lZ(u"ࠨࠢࡠࠫ෬"))
			od4AIsBzi3Ga2bLXNlZKME,y9i63b5jQSGqUsfguZxPkTK,wqxUVjrJvLpasn2YyGh0zuAi9E7,PPTURnwu345Xji,uua931OmCgEBHP8pDMdsjzXVRSGc4,UUF24APJXw0DzpoENvys1Zf3kRj = I6EPVkCug24fet[LzYQg91SIxDeOGtCKd5]
			iCdDq1Lwx9AtIeUBcp8HFZgKf,PPcnGAwkyrhOSC5fdtNIso8U = PPTURnwu345Xji.split(Xz3bA2PFENVCUtplu51(u"ࠩ࡟ࡲࡀࡁࠧ෭"))
			del I6EPVkCug24fet[LzYQg91SIxDeOGtCKd5]
			AQE3lZqO9GdJU = qHiNBx6PXjKatkWf37AwFClzsp2DmE.sample(I6EPVkCug24fet,qHYIWnOZLPkrQU)
			od4AIsBzi3Ga2bLXNlZKME,y9i63b5jQSGqUsfguZxPkTK,wqxUVjrJvLpasn2YyGh0zuAi9E7,PPTURnwu345Xji,uua931OmCgEBHP8pDMdsjzXVRSGc4,UUF24APJXw0DzpoENvys1Zf3kRj = AQE3lZqO9GdJU[LzYQg91SIxDeOGtCKd5]
			wqxUVjrJvLpasn2YyGh0zuAi9E7 = IjZbnrBJmM2N(u"ࠪ࡟ࡗ࡚ࡌ࡞ࠩ෮")+OkuB9nwhD8U1+SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠫࠥࡀࠠࠨ෯")+od4AIsBzi3Ga2bLXNlZKME+hAIp8kmC36T5WFPMSXOwnNbtD+wqxUVjrJvLpasn2YyGh0zuAi9E7
			uua931OmCgEBHP8pDMdsjzXVRSGc4 = SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠬหัิษ็ࠤึูวๅห่้๋ࠣศา็ฯࠫ෰")
			HFwCdX9UYzjp = RRIHDFjoW9w7bSfVPhC(u"࠭วๅฬหี฾อสࠨ෱")
			button0,button1 = PPTURnwu345Xji,uua931OmCgEBHP8pDMdsjzXVRSGc4
			fqzp8elOIU1a = [button0,button1,HFwCdX9UYzjp]
			tMlKQGjoXD71VkLpdfPFC = qHYIWnOZLPkrQU if XrloM5pTyK.xd4VjQuvJDC2ms else vvWwO3Tx2dAgcijrFXq(u"࠴࠴᎗")
			juILqxAVNHQrPUi4 = -Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"࠽᎘")
			while juILqxAVNHQrPUi4<LzYQg91SIxDeOGtCKd5:
				Opc2tTUX8HrPvjls9h4YbiG3J = qHiNBx6PXjKatkWf37AwFClzsp2DmE.sample(fqzp8elOIU1a,VwApyDY1Jc)
				juILqxAVNHQrPUi4 = QlaM6yHe0bgh58Vx3BAZD(b8Qe150xVaJsnDSv,Opc2tTUX8HrPvjls9h4YbiG3J[LzYQg91SIxDeOGtCKd5],Opc2tTUX8HrPvjls9h4YbiG3J[qHYIWnOZLPkrQU],Opc2tTUX8HrPvjls9h4YbiG3J[IgQimel18t],iCdDq1Lwx9AtIeUBcp8HFZgKf,wqxUVjrJvLpasn2YyGh0zuAi9E7,mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠧࡤࡱࡱࡪ࡮ࡸ࡭ࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩෲ"),tMlKQGjoXD71VkLpdfPFC,RRIHDFjoW9w7bSfVPhC(u"࠻࠶᎙"))
				if juILqxAVNHQrPUi4==ddo23ZJtgcY(u"࠷࠰᎚"): break
				import cTGphBXNeH
				if juILqxAVNHQrPUi4>=LzYQg91SIxDeOGtCKd5 and Opc2tTUX8HrPvjls9h4YbiG3J[juILqxAVNHQrPUi4]==fqzp8elOIU1a[qHYIWnOZLPkrQU]:
					cTGphBXNeH.lcA0mHzo1TQUIwMKZa8()
					if juILqxAVNHQrPUi4>=LzYQg91SIxDeOGtCKd5: juILqxAVNHQrPUi4 = -P0qdZI384LKleuo(u"࠹᎛")
				elif juILqxAVNHQrPUi4>=LzYQg91SIxDeOGtCKd5 and Opc2tTUX8HrPvjls9h4YbiG3J[juILqxAVNHQrPUi4]==fqzp8elOIU1a[IgQimel18t]:
					cTGphBXNeH.X5Q6PnJcimdhwT7H(DD5cFIejQa2X4BgAu9GWPyJ3tC7)
				if juILqxAVNHQrPUi4==-qHYIWnOZLPkrQU: tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,TYf7Dc06PQgy1vEV9(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫෳ"),OkuB9nwhD8U1+Xz3bA2PFENVCUtplu51(u"ࠩัีําࠠฯูฦࠫ෴")+hAIp8kmC36T5WFPMSXOwnNbtD+P0qdZI384LKleuo(u"ࠪࡠࡳࠦไๅะิ์ัࠦวๅืะ๎าࠦรฯฬิࠤํออะ่๊ࠢࠥอไฤฮ๋ฬฮࠦวๅ็อ์ๆืษࠨ෵"))
			Q4QvO7PftYr1bgExZn3aoAqB9j0 = qHYIWnOZLPkrQU
		else: Q4QvO7PftYr1bgExZn3aoAqB9j0 = LzYQg91SIxDeOGtCKd5
	hRWC8YSFvsm4JHOMVIne3jquZ.setSetting(uVQd103XyvUce2EBtzbYaC(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ࠭෶"),hk9Mxv3LzSHl42AUdfs0ejF7qcVw(T3Axql94cU0BpO1wudEDtWXsf))
	PGudrhJF8iDkSq96XVHEQZYf5L(mshLJcKH1fv03yRnDOr4ZT,Nh0BWuiSndf(u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨ෷"),yST5AHEfvPmcWpwGuh2BJ(u"࠭ࡓࡊࡖࡈࡗࡤࡔࡁࡎࡇࡖࠫ෸"),Q4QvO7PftYr1bgExZn3aoAqB9j0,t58tnzAgevxkoIOdMFbE2PsD64q0C9)
	return
def j3nsoLX8NDyB4SHqpTWRk(E57WK4m31C8,rlqNUcK9vYgkT,YabJfs3q7yjpzvXioO,Q8ZnJhRz2mINwrY6VPf,I6YPOSofrpnTwRm8b,NGQDwOCXx1BZmd9Huc,vv5M4UfJS9ucKEiNbxtnaOZ,wc0Z9FAdf2B1J,XXra5dzn8tcLOxYZIE7pPof49Hh,zombcuDBIxEeSdOlZq1tsUH4f,okYWP4Hxyb,ip6CohvO5Tya9mFWVf3JdY1qL,NYVaJlWbG1hj52U9LzdKfi,okRX5wzaWp6PcrB):
	NNAFVsczZb = int(zombcuDBIxEeSdOlZq1tsUH4f%dDYUoKi6JFM23p(u"࠲࠲᎜"))
	nYUxlDOpbX32Qtw = int(zombcuDBIxEeSdOlZq1tsUH4f/LAQD5wEkr18bUiGaYen3J(u"࠳࠳᎝"))
	PPFYGkKdjEeUTNomSuvlB = E57WK4m31C8,rlqNUcK9vYgkT,YabJfs3q7yjpzvXioO,Q8ZnJhRz2mINwrY6VPf,I6YPOSofrpnTwRm8b,NGQDwOCXx1BZmd9Huc,vv5M4UfJS9ucKEiNbxtnaOZ,b8Qe150xVaJsnDSv,XXra5dzn8tcLOxYZIE7pPof49Hh
	y12ytelkWaGNARq3B0 = hRWC8YSFvsm4JHOMVIne3jquZ.getSetting(QTUBCcehw6qPd4x(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡱࡪࡴࡵࡴࡥࡤࡧ࡭࡫ࠧ෹"))
	if not y12ytelkWaGNARq3B0: hRWC8YSFvsm4JHOMVIne3jquZ.setSetting(HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡲ࡫࡮ࡶࡵࡦࡥࡨ࡮ࡥࠨ෺"),yST5AHEfvPmcWpwGuh2BJ(u"ࠩࡄ࡙࡙ࡕࠧ෻"))
	iPKbSRLnl2HJxFMjwQkGza = hRWC8YSFvsm4JHOMVIne3jquZ.getSetting(ubxGUTt1LraKhVZgpAP(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡲࡦࡨࡵࡩࡸ࡮ࠧ෼"))
	ZbGDcPgUyw7S0 = dIAn5x3eGWtEVMfHQKoN8g(okYWP4Hxyb)
	ODwNbxvodBla1RgVj = [LzYQg91SIxDeOGtCKd5,QTUBCcehw6qPd4x(u"࠵࠺᎟"),mQNonhS7CV2BXOv(u"࠶࠽Ꭰ"),m6hwdgP31a2zjN7lkpX(u"࠷࠹Ꭱ"),ddo23ZJtgcY(u"࠵࠺᎞"),BWNPxIG7vqdTy85pjHzUOrK3(u"࠵࠷Ꭴ"),QTUBCcehw6qPd4x(u"࠵࠱Ꭲ"),UUkIBz1sgQ9WfNeG6trKXvu0(u"࠶࠵Ꭳ")]
	vcR0ruzqWVN = nYUxlDOpbX32Qtw not in ODwNbxvodBla1RgVj
	YpVMQOeugC0v8ZJ7jmDiRN = nYUxlDOpbX32Qtw in [DYakr9g4PVU(u"࠸࠳Ꭸ"),dDYUoKi6JFM23p(u"࠵࠼Ꭵ"),kke1PDGRBLuY8y(u"࠼࠷Ꭷ"),HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"࠻࠷Ꭶ")]
	RGOch6yxqeoD9S = zombcuDBIxEeSdOlZq1tsUH4f in [DYakr9g4PVU(u"࠳࠸࠸Ꭺ"),BWNPxIG7vqdTy85pjHzUOrK3(u"࠲࠸࠲Ꭹ")]
	w2b9uGkzJptRE1xFD54eid8A = (vcR0ruzqWVN or YpVMQOeugC0v8ZJ7jmDiRN) and not RGOch6yxqeoD9S
	YUjpiAzL3xNs = (iPKbSRLnl2HJxFMjwQkGza or not wc0Z9FAdf2B1J) and iPKbSRLnl2HJxFMjwQkGza not in [BmePGjS7FxK6kutUM(u"ࠫࡗࡋࡆࡓࡇࡖࡌࡤࡉࡁࡄࡊࡈࠫ෽")]+UhVAT46l59JBLO2rKI0zZ
	cCynOUKjRk4GbLTJEWhBIowZP = P0qdZI384LKleuo(u"ࠬࡺࡹࡱࡧࡀࠫ෾") in iPKbSRLnl2HJxFMjwQkGza
	EfbjD0wGhd = zombcuDBIxEeSdOlZq1tsUH4f in [Xz3bA2PFENVCUtplu51(u"࠶࠼࠱Ꮅ"),VFjQx6Is28KvzLOmMXtg4GqTwa3(u"࠷࠶࠳Ꮆ"),dDYUoKi6JFM23p(u"࠱࠷࠵Ꮇ"),HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"࠲࠸࠷Ꮁ"),shC5qBRV2A0lZ(u"࠳࠹࠹Ꮂ"),QTUBCcehw6qPd4x(u"࠴࠺࠻Ꮃ"),vvWwO3Tx2dAgcijrFXq(u"࠵࠻࠽Ꮄ"),TYf7Dc06PQgy1vEV9(u"࠱࠷࠺Ꮀ"),mmcNLrXtzfpyCkZlvK5VwG2gujh(u"࠻࠻࠷Ꭽ"),Nh0BWuiSndf(u"࠹࠹࠶Ꭻ"),Nh0BWuiSndf(u"࠺࠺࠸Ꭼ"),Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"࠼࠼࠴Ꭾ"),mQNonhS7CV2BXOv(u"࠽࠶࠶Ꭿ")]
	kstJfK6jHQWrXDSMRIGB7 = NNAFVsczZb==IjZbnrBJmM2N(u"࠺Ꮈ") or zombcuDBIxEeSdOlZq1tsUH4f in [BmePGjS7FxK6kutUM(u"࠴࠸࠺Ꮊ"),TYf7Dc06PQgy1vEV9(u"࠺࠷࠶Ꮌ"),ubxGUTt1LraKhVZgpAP(u"࠹࠷࠹Ꮋ"),DYakr9g4PVU(u"࠶࠸Ꮉ")]
	xq4VebLFZ7 = not EfbjD0wGhd
	qtI1Wd8BHXpDJvYiZz = not kstJfK6jHQWrXDSMRIGB7
	v1ieUkRuW0y = ZbGDcPgUyw7S0 in [b8Qe150xVaJsnDSv,Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"࠭࠮࠯ࠩ෿")]
	hN1Bad6kWl = v1ieUkRuW0y or xq4VebLFZ7
	ZZWh6Dpzkn = v1ieUkRuW0y or qtI1Wd8BHXpDJvYiZz or cCynOUKjRk4GbLTJEWhBIowZP
	E1Hgkcxoa5fDAOISNCRV = zombcuDBIxEeSdOlZq1tsUH4f not in [TT8Mxv5Wq7nlC9IscdpPUY6(u"࠵࠺࠵Ꮑ"),Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"࠸࠶࠲Ꮍ"),BWNPxIG7vqdTy85pjHzUOrK3(u"࠶࠻࠻Ꮒ"),DYakr9g4PVU(u"࠳࠹࠳Ꮏ"),kke1PDGRBLuY8y(u"࠳࠴࠲Ꮎ"),DYakr9g4PVU(u"࠷࠷࠴Ꮐ"),ddo23ZJtgcY(u"࠶࠶࠱࠱Ꮓ")]
	if y12ytelkWaGNARq3B0==HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠧࡔࡖࡒࡔࠬ฀"): R2YcQpS8ldHqZi3Vkyo = kstJfK6jHQWrXDSMRIGB7 or EfbjD0wGhd
	else: R2YcQpS8ldHqZi3Vkyo = CCxMXuNUEzolDZTKrBJ
	aaGeVJwNonD24MsXIkpBfSUA = nYUxlDOpbX32Qtw in [TYf7Dc06PQgy1vEV9(u"࠷࠵Ꮕ"),IjZbnrBJmM2N(u"࠽࠵Ꮔ")]
	jLGQBxtysirTZ = zombcuDBIxEeSdOlZq1tsUH4f in [DYakr9g4PVU(u"࠳࠺࠳Ꮖ"),LAQD5wEkr18bUiGaYen3J(u"࠹࠵࠴Ꮗ")]
	vdsIt6V1e9 = not aaGeVJwNonD24MsXIkpBfSUA and not jLGQBxtysirTZ
	gZ2RbYp9Oq0 = hN1Bad6kWl and ZZWh6Dpzkn and E1Hgkcxoa5fDAOISNCRV and R2YcQpS8ldHqZi3Vkyo and vdsIt6V1e9
	ANn51E4cSfaqmGvQ2j6LpKX = E1Hgkcxoa5fDAOISNCRV and R2YcQpS8ldHqZi3Vkyo and vdsIt6V1e9
	zfTSd9VQlitrRhFMOnJ30 = ANn51E4cSfaqmGvQ2j6LpKX
	a2Ty3tzI4nEXYKMmZ6k7 = hRWC8YSFvsm4JHOMVIne3jquZ.getSetting(HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠨࡣࡹ࠲ࡱࡧ࡮ࡨࡷࡤ࡫ࡪ࠴ࡰࡳࡱࡹ࡭ࡩ࡫ࡲࠨก"))
	xzUVeRHl6ApWE2QDT9BSICXKtJkdF7 = hRWC8YSFvsm4JHOMVIne3jquZ.getSetting(Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠩࡤࡺ࠳ࡲࡡ࡯ࡩࡸࡥ࡬࡫࠮ࡤࡱࡧࡩࠬข"))
	nDRImvVYhXSc75buTM1ilLastogJFK = DD5cFIejQa2X4BgAu9GWPyJ3tC7
	if YUjpiAzL3xNs and gZ2RbYp9Oq0:
		FYkZLgAtByRc9jIGqx34msUaevHd = SS2OK7hjLagvUAm(mshLJcKH1fv03yRnDOr4ZT,ubxGUTt1LraKhVZgpAP(u"ࠪࡰ࡮ࡹࡴࠨฃ"),TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠫࡒࡋࡎࡖࡕࡢࡇࡆࡉࡈࡆࡡࠪค")+a2Ty3tzI4nEXYKMmZ6k7+LAQD5wEkr18bUiGaYen3J(u"ࠬࡥࠧฅ")+xzUVeRHl6ApWE2QDT9BSICXKtJkdF7,PPFYGkKdjEeUTNomSuvlB)
		if FYkZLgAtByRc9jIGqx34msUaevHd:
			mwIxD3GBPgLVc2aq9(b8Qe150xVaJsnDSv,RRIHDFjoW9w7bSfVPhC(u"࠭࠮࡝ࡶࡐࡉࡓ࡛ࡓࡠࡅࡄࡇࡍࡋ࡟ࠨฆ")+a2Ty3tzI4nEXYKMmZ6k7+TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠧࡠࠩง")+xzUVeRHl6ApWE2QDT9BSICXKtJkdF7+ubxGUTt1LraKhVZgpAP(u"ࠨࠢࠣࠤࡑࡵࡡࡥ࡫ࡱ࡫ࠥࡳࡥ࡯ࡷࠣࡪࡷࡵ࡭ࠡࡥࡤࡧ࡭࡫ࠧจ"))
			if cCynOUKjRk4GbLTJEWhBIowZP:
				uERAW9DYL4nOZf2J07csqp = []
				from Dv8qscELw9 import KKm7cyf50MAI4OPkDltXi6dwZaj
				from pxDVAc9OnY import osUVxR3cueih25tjHwQf,BsO7uWjxMtDA9a23H1
				NzL5RSrgI9K6yFiTjZnCGlO3 = KKm7cyf50MAI4OPkDltXi6dwZaj
				Smz7idG8TYEoupBlDJv = osUVxR3cueih25tjHwQf()
				GlExUTejmdi = iPKbSRLnl2HJxFMjwQkGza
				aWCAxHh8kiZrQsn2zfpE49GcNwMyD,W3k0gj2P75ealrZM,BY8R0iAcZKT,QXCPZw1NRHE3zk7V8qBFnjIJaYgMtK,RQ4KYb2Hg71f6XMAu,WGBMawo8CAYH,dLD98BqSehv,fnMY9RFNb6,CZplM93Idv = rhoGF8ta4UesmTucY6V2O1A(GlExUTejmdi)
				B5FOV1pIoHm9i = aWCAxHh8kiZrQsn2zfpE49GcNwMyD,W3k0gj2P75ealrZM,BY8R0iAcZKT,QXCPZw1NRHE3zk7V8qBFnjIJaYgMtK,RQ4KYb2Hg71f6XMAu,WGBMawo8CAYH,dLD98BqSehv,b8Qe150xVaJsnDSv,CZplM93Idv
				for UoE49FeuyD1 in FYkZLgAtByRc9jIGqx34msUaevHd:
					WDAS0YvGsBhn47rw8O1 = UoE49FeuyD1[Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠩࡰࡩࡳࡻࡉࡵࡧࡰࠫฉ")]
					if WDAS0YvGsBhn47rw8O1==B5FOV1pIoHm9i or UoE49FeuyD1[TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠪࡱࡴࡪࡥࠨช")] in [TYf7Dc06PQgy1vEV9(u"࠶࠻࠻Ꮙ"),m6hwdgP31a2zjN7lkpX(u"࠵࠻࠵Ꮘ")]:
						UoE49FeuyD1 = jjvaJcbTrUMf7XVBFNZEtCqHmwhP(WDAS0YvGsBhn47rw8O1,NzL5RSrgI9K6yFiTjZnCGlO3,Smz7idG8TYEoupBlDJv)
						if UoE49FeuyD1[ddo23ZJtgcY(u"ࠫ࡫ࡧࡶࡰࡴ࡬ࡸࡪࡹࠧซ")]:
							d6uSY28Ir1F3aRJXiycH = BsO7uWjxMtDA9a23H1(Smz7idG8TYEoupBlDJv,WDAS0YvGsBhn47rw8O1,UoE49FeuyD1[S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠬࡴࡥࡸࡲࡤࡸ࡭࠭ฌ")])
							UoE49FeuyD1[ddo23ZJtgcY(u"࠭ࡣࡰࡰࡷࡩࡽࡺ࡟࡮ࡧࡱࡹࠬญ")] = d6uSY28Ir1F3aRJXiycH+UoE49FeuyD1[VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠧࡤࡱࡱࡸࡪࡾࡴࡠ࡯ࡨࡲࡺ࠭ฎ")]
					uERAW9DYL4nOZf2J07csqp.append(UoE49FeuyD1)
				hRWC8YSFvsm4JHOMVIne3jquZ.setSetting(DYakr9g4PVU(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡷ࡫ࡦࡳࡧࡶ࡬ࠬฏ"),b8Qe150xVaJsnDSv)
				if E57WK4m31C8==m6hwdgP31a2zjN7lkpX(u"ࠩࡩࡳࡱࡪࡥࡳࠩฐ"): PGudrhJF8iDkSq96XVHEQZYf5L(mshLJcKH1fv03yRnDOr4ZT,TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠪࡑࡊࡔࡕࡔࡡࡆࡅࡈࡎࡅࡠࠩฑ")+a2Ty3tzI4nEXYKMmZ6k7+kke1PDGRBLuY8y(u"ࠫࡤ࠭ฒ")+xzUVeRHl6ApWE2QDT9BSICXKtJkdF7,PPFYGkKdjEeUTNomSuvlB,uERAW9DYL4nOZf2J07csqp,GMkNL1RXxKFentp0Zh9d)
			else: uERAW9DYL4nOZf2J07csqp = FYkZLgAtByRc9jIGqx34msUaevHd
			if E57WK4m31C8==BWNPxIG7vqdTy85pjHzUOrK3(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬณ") and ZbGDcPgUyw7S0!=dDYUoKi6JFM23p(u"࠭࠮࠯ࠩด") and w2b9uGkzJptRE1xFD54eid8A: wpXZ2KkvNOS8asuE94qedg7ncUr()
			nDRImvVYhXSc75buTM1ilLastogJFK = IDZHg5QJ9YdOBCbwxSy(PPFYGkKdjEeUTNomSuvlB,uERAW9DYL4nOZf2J07csqp,ip6CohvO5Tya9mFWVf3JdY1qL,NYVaJlWbG1hj52U9LzdKfi,okRX5wzaWp6PcrB)
	elif E57WK4m31C8==UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧต") and iPKbSRLnl2HJxFMjwQkGza not in [UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠨࡔࡈࡊࡗࡋࡓࡉࡡࡆࡅࡈࡎࡅࠨถ")]+UhVAT46l59JBLO2rKI0zZ and ANn51E4cSfaqmGvQ2j6LpKX:
		zqbhiLmQfC3VK9Arku(mshLJcKH1fv03yRnDOr4ZT,LAQD5wEkr18bUiGaYen3J(u"ࠩࡐࡉࡓ࡛ࡓࡠࡅࡄࡇࡍࡋ࡟ࠨท")+a2Ty3tzI4nEXYKMmZ6k7+QQdAXWBc2GPw(u"ࠪࡣࠬธ")+xzUVeRHl6ApWE2QDT9BSICXKtJkdF7,PPFYGkKdjEeUTNomSuvlB)
	return nDRImvVYhXSc75buTM1ilLastogJFK,iPKbSRLnl2HJxFMjwQkGza,PPFYGkKdjEeUTNomSuvlB,ZbGDcPgUyw7S0,w2b9uGkzJptRE1xFD54eid8A,zfTSd9VQlitrRhFMOnJ30,a2Ty3tzI4nEXYKMmZ6k7,xzUVeRHl6ApWE2QDT9BSICXKtJkdF7
def ZZFApYEcTUt28gy(E57WK4m31C8,rlqNUcK9vYgkT,YabJfs3q7yjpzvXioO,Q8ZnJhRz2mINwrY6VPf,I6YPOSofrpnTwRm8b,NGQDwOCXx1BZmd9Huc,vv5M4UfJS9ucKEiNbxtnaOZ,wc0Z9FAdf2B1J,XXra5dzn8tcLOxYZIE7pPof49Hh,zombcuDBIxEeSdOlZq1tsUH4f,QJ0qZc2WYEBRu894kiSvT3aUAMtf6,qbzaH87okmFhuPxgJVRDB29):
	if QJ0qZc2WYEBRu894kiSvT3aUAMtf6 in [BmePGjS7FxK6kutUM(u"ࠫ࠶࠭น"),dDYUoKi6JFM23p(u"ࠬ࠸ࠧบ"),HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"࠭࠳ࠨป"),ubxGUTt1LraKhVZgpAP(u"ࠧ࠵ࠩผ"),HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠨ࠷ࠪฝ"),zI3ROAZtiUq42rE9WDST68(u"ࠩ࠴࠵ࠬพ"),HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠪ࠵࠷࠭ฟ"),HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠫ࠶࠹ࠧภ")] and qbzaH87okmFhuPxgJVRDB29:
		import pxDVAc9OnY
		pxDVAc9OnY.L4Uf2PYJbSnDd5NBu(wc0Z9FAdf2B1J,QJ0qZc2WYEBRu894kiSvT3aUAMtf6,qbzaH87okmFhuPxgJVRDB29)
		qMGn9u2ckaXejCgUQhYTDP(DD5cFIejQa2X4BgAu9GWPyJ3tC7,ZqDQCMovyXKFG7ki4BrahuWt1IS8)
	elif QJ0qZc2WYEBRu894kiSvT3aUAMtf6==zI3ROAZtiUq42rE9WDST68(u"ࠬ࠼ࠧม"):
		import hIVCFnfxSO
		if qbzaH87okmFhuPxgJVRDB29==uVQd103XyvUce2EBtzbYaC(u"࠭ࡄࡐ࡙ࡑࡐࡔࡇࡄࠨย"): hIVCFnfxSO.yicQV3gj4q(Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"๋ࠧำฯํࠥอไศ่อ฼ฬืࠧร"),UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠨฮสี๏ࠦแฮื้้ࠣ็ࠠศๆอั๊๐ไࠨฤ"),wLQCTr5lqbsVYeAHdzfhZ1F=m6hwdgP31a2zjN7lkpX(u"࠷࠶࠰࠱Ꮚ"))
		elif qbzaH87okmFhuPxgJVRDB29==QQdAXWBc2GPw(u"ࠩࡇࡉࡑࡋࡔࡆࠩล"): d9IVrTfkDxj(uuNDjbit4hOpx,DD5cFIejQa2X4BgAu9GWPyJ3tC7)
		XXxlOLJ9KRjPH382WVCvr6n71 = hIVCFnfxSO.fPYwhSsFOBLbt7rM902im4oVE(E57WK4m31C8,rlqNUcK9vYgkT,YabJfs3q7yjpzvXioO,zombcuDBIxEeSdOlZq1tsUH4f,I6YPOSofrpnTwRm8b,NGQDwOCXx1BZmd9Huc,vv5M4UfJS9ucKEiNbxtnaOZ,wc0Z9FAdf2B1J,XXra5dzn8tcLOxYZIE7pPof49Hh)
		if qbzaH87okmFhuPxgJVRDB29==zI3ROAZtiUq42rE9WDST68(u"ࠪࡈࡔ࡝ࡎࡍࡑࡄࡈࠬฦ"): AKQaWIc0YCHGVnT()
	elif wc0Z9FAdf2B1J==S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠫ࠼࠭ว"):
		import jtKsxUZvgl
		jtKsxUZvgl.ideYhTS9Kxw6njU3kW(dDYUoKi6JFM23p(u"ࠬࡥࡁࡍࡎࠪศ"))
		qMGn9u2ckaXejCgUQhYTDP(DD5cFIejQa2X4BgAu9GWPyJ3tC7)
	elif wc0Z9FAdf2B1J==P0qdZI384LKleuo(u"࠭࠸ࠨษ"): uuxVm0bTwdnCUAL4s6NKHEBF3M.executebuiltin(S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱࡙ࡵࡪࡡࡵࡧࠫࡴࡱࡻࡧࡪࡰ࠽࠳࠴࠭ส")+DFUIv2KGj9ke+RRIHDFjoW9w7bSfVPhC(u"ࠨࡁࡰࡳࡩ࡫࠽ࠨห")+str(Q8ZnJhRz2mINwrY6VPf)+Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠩࠩࡸࡾࡶࡥ࠾ࡨࡲࡰࡩ࡫ࡲࠪࠩฬ"))
	elif wc0Z9FAdf2B1J==yST5AHEfvPmcWpwGuh2BJ(u"ࠪ࠽ࠬอ"):
		qMGn9u2ckaXejCgUQhYTDP(CCxMXuNUEzolDZTKrBJ)
	elif wc0Z9FAdf2B1J==mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠫ࠶࠶ࠧฮ"):
		import jtKsxUZvgl
		jtKsxUZvgl.ideYhTS9Kxw6njU3kW(DYakr9g4PVU(u"ࠬࡥࡇࡐࡑࡊࡐࡊ࠭ฯ"))
		qMGn9u2ckaXejCgUQhYTDP(DD5cFIejQa2X4BgAu9GWPyJ3tC7)
	elif wc0Z9FAdf2B1J==zI3ROAZtiUq42rE9WDST68(u"࠭࠱࠵ࠩะ"): qMGn9u2ckaXejCgUQhYTDP(CCxMXuNUEzolDZTKrBJ,LAQD5wEkr18bUiGaYen3J(u"ࠧࡎࡇࡑ࡙ࡤࡘࡅࡗࡇࡕࡗࡊࡊ࡟ࡕࡇࡐࡔࠬั"))
	elif wc0Z9FAdf2B1J==QTUBCcehw6qPd4x(u"ࠨ࠳࠸ࠫา"): qMGn9u2ckaXejCgUQhYTDP(CCxMXuNUEzolDZTKrBJ,Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠩࡐࡉࡓ࡛࡟ࡂࡕࡆࡉࡓࡊࡅࡅࡡࡗࡉࡒࡖࠧำ"))
	elif wc0Z9FAdf2B1J==yST5AHEfvPmcWpwGuh2BJ(u"ࠪ࠵࠻࠭ิ"): qMGn9u2ckaXejCgUQhYTDP(CCxMXuNUEzolDZTKrBJ,Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠫࡒࡋࡎࡖࡡࡇࡉࡘࡉࡅࡏࡆࡈࡈࡤ࡚ࡅࡎࡒࠪี"))
	elif wc0Z9FAdf2B1J==BmePGjS7FxK6kutUM(u"ࠬ࠷࠷ࠨึ"): qMGn9u2ckaXejCgUQhYTDP(CCxMXuNUEzolDZTKrBJ,Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"࠭ࡍࡆࡐࡘࡣࡗࡇࡎࡅࡑࡐࡍ࡟ࡋࡄࡠࡖࡈࡑࡕ࠭ื"))
	elif wc0Z9FAdf2B1J==uVQd103XyvUce2EBtzbYaC(u"ࠧ࠲࠺ุࠪ"):
		F8Ef6K7kCy9mbQPx = hRWC8YSFvsm4JHOMVIne3jquZ.getSetting(dDYUoKi6JFM23p(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡧ࡯ࡴࡳࡣࡷࡩูࠬ"))
		if F8Ef6K7kCy9mbQPx: hRWC8YSFvsm4JHOMVIne3jquZ.setSetting(VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡨࡩࡵࡴࡤࡸࡪฺ࠭"),S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠪ࠱ࠬ฻")+F8Ef6K7kCy9mbQPx)
	if wc0Z9FAdf2B1J in [LAQD5wEkr18bUiGaYen3J(u"ࠫ࠾࠭฼"),m6hwdgP31a2zjN7lkpX(u"ࠬ࠷࠴ࠨ฽"),RRIHDFjoW9w7bSfVPhC(u"࠭࠱࠶ࠩ฾"),VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠧ࠲࠸ࠪ฿"),m6hwdgP31a2zjN7lkpX(u"ࠨ࠳࠺ࠫเ")]: AKQaWIc0YCHGVnT()
	return
def wXetdoVAq0ZByn7ukLPONr3U(E57WK4m31C8,rlqNUcK9vYgkT,YabJfs3q7yjpzvXioO,Q8ZnJhRz2mINwrY6VPf,I6YPOSofrpnTwRm8b,NGQDwOCXx1BZmd9Huc,vv5M4UfJS9ucKEiNbxtnaOZ,wc0Z9FAdf2B1J,XXra5dzn8tcLOxYZIE7pPof49Hh,zombcuDBIxEeSdOlZq1tsUH4f,QJ0qZc2WYEBRu894kiSvT3aUAMtf6,qbzaH87okmFhuPxgJVRDB29,okYWP4Hxyb):
	if l1RsIerQAtbJjMTzGEWP2L: rdZILqz9Y4ef()
	if wc0Z9FAdf2B1J: ZZFApYEcTUt28gy(E57WK4m31C8,rlqNUcK9vYgkT,YabJfs3q7yjpzvXioO,Q8ZnJhRz2mINwrY6VPf,I6YPOSofrpnTwRm8b,NGQDwOCXx1BZmd9Huc,vv5M4UfJS9ucKEiNbxtnaOZ,wc0Z9FAdf2B1J,XXra5dzn8tcLOxYZIE7pPof49Hh,zombcuDBIxEeSdOlZq1tsUH4f,QJ0qZc2WYEBRu894kiSvT3aUAMtf6,qbzaH87okmFhuPxgJVRDB29)
	Sh3CL7ic9k6nXOz()
	KKt5zJyFWQAuhpecY(CCxMXuNUEzolDZTKrBJ)
	ip6CohvO5Tya9mFWVf3JdY1qL,NYVaJlWbG1hj52U9LzdKfi,okRX5wzaWp6PcrB = CCxMXuNUEzolDZTKrBJ,DD5cFIejQa2X4BgAu9GWPyJ3tC7,DD5cFIejQa2X4BgAu9GWPyJ3tC7
	tNfVGgj90v7co5 = j3nsoLX8NDyB4SHqpTWRk(E57WK4m31C8,rlqNUcK9vYgkT,YabJfs3q7yjpzvXioO,Q8ZnJhRz2mINwrY6VPf,I6YPOSofrpnTwRm8b,NGQDwOCXx1BZmd9Huc,vv5M4UfJS9ucKEiNbxtnaOZ,wc0Z9FAdf2B1J,XXra5dzn8tcLOxYZIE7pPof49Hh,zombcuDBIxEeSdOlZq1tsUH4f,okYWP4Hxyb,ip6CohvO5Tya9mFWVf3JdY1qL,NYVaJlWbG1hj52U9LzdKfi,okRX5wzaWp6PcrB)
	nDRImvVYhXSc75buTM1ilLastogJFK,iPKbSRLnl2HJxFMjwQkGza,PPFYGkKdjEeUTNomSuvlB,ZbGDcPgUyw7S0,w2b9uGkzJptRE1xFD54eid8A,zfTSd9VQlitrRhFMOnJ30,a2Ty3tzI4nEXYKMmZ6k7,xzUVeRHl6ApWE2QDT9BSICXKtJkdF7 = tNfVGgj90v7co5
	if nDRImvVYhXSc75buTM1ilLastogJFK: return
	if iPKbSRLnl2HJxFMjwQkGza==DYakr9g4PVU(u"ࠩࡕࡉࡋࡘࡅࡔࡊࡢࡇࡆࡉࡈࡆࠩแ"): lp8eUQ9rw25BhRgWNPHT7K(nCUMfrlZvuiLe5x)
	Ljkr2F3IQgNn8v6(zI3ROAZtiUq42rE9WDST68(u"ࠪࡷࡹࡧࡲࡵࠩโ"))
	if hRWC8YSFvsm4JHOMVIne3jquZ.getSetting(BmePGjS7FxK6kutUM(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡩࡶࡷࡴࡨࡧࡣࡩࡧࠪใ")) not in [Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠬࡇࡕࡕࡑࠪไ"),SbjiWeHLQPoazqwp3cODkd7YxVgn(u"࠭ࡓࡕࡑࡓࠫๅ"),SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠧࡍࡋࡐࡍ࡙ࡋࡄࠨๆ")]:
		hRWC8YSFvsm4JHOMVIne3jquZ.setSetting(HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲࡭ࡺࡴࡱࡥࡤࡧ࡭࡫ࠧ็"),ddo23ZJtgcY(u"ࠩࡄ࡙࡙ࡕ่ࠧ"))
	if not hRWC8YSFvsm4JHOMVIne3jquZ.getSetting(IjZbnrBJmM2N(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡤ࡯ࡵ้ࠪ")): hRWC8YSFvsm4JHOMVIne3jquZ.setSetting(vvWwO3Tx2dAgcijrFXq(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡥࡰࡶ๊ࠫ"),aZN3l1t6JE4oPmpkzLQSW5[LzYQg91SIxDeOGtCKd5])
	XXxlOLJ9KRjPH382WVCvr6n71 = fPYwhSsFOBLbt7rM902im4oVE(E57WK4m31C8,rlqNUcK9vYgkT,YabJfs3q7yjpzvXioO,Q8ZnJhRz2mINwrY6VPf,I6YPOSofrpnTwRm8b,NGQDwOCXx1BZmd9Huc,vv5M4UfJS9ucKEiNbxtnaOZ,wc0Z9FAdf2B1J,XXra5dzn8tcLOxYZIE7pPof49Hh)
	if vvWwO3Tx2dAgcijrFXq(u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ๋ࠧ") in vv5M4UfJS9ucKEiNbxtnaOZ: NYVaJlWbG1hj52U9LzdKfi = CCxMXuNUEzolDZTKrBJ
	if E57WK4m31C8==LAQD5wEkr18bUiGaYen3J(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭์"):
		if ZbGDcPgUyw7S0!=BmePGjS7FxK6kutUM(u"ࠧ࠯࠰ࠪํ") and w2b9uGkzJptRE1xFD54eid8A: wpXZ2KkvNOS8asuE94qedg7ncUr()
		if IaCU04ZS1qx>-qHYIWnOZLPkrQU:
			CCWDjbvcRxI = [LzYQg91SIxDeOGtCKd5,LAQD5wEkr18bUiGaYen3J(u"࠱࠶Ꮜ"),DYakr9g4PVU(u"࠲࠹Ꮝ"),mQNonhS7CV2BXOv(u"࠳࠼Ꮞ"),shC5qBRV2A0lZ(u"࠸࠶Ꮛ"),dDYUoKi6JFM23p(u"࠸࠺Ꮡ"),vvWwO3Tx2dAgcijrFXq(u"࠸࠴Ꮟ"),QQdAXWBc2GPw(u"࠹࠸Ꮠ")]
			if (SS2OK7hjLagvUAm(mshLJcKH1fv03yRnDOr4ZT,mQNonhS7CV2BXOv(u"ࠨ࡫ࡱࡸࠬ๎"),IjZbnrBJmM2N(u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬ๏"),mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠪࡗࡎ࡚ࡅࡔࡡࡑࡅࡒࡋࡓࠨ๐")) or zombcuDBIxEeSdOlZq1tsUH4f not in CCWDjbvcRxI) and not XrloM5pTyK.r6rSFTpNl5nqd4s9GbEK8zhoXY:
				from Dv8qscELw9 import KKm7cyf50MAI4OPkDltXi6dwZaj
				FYkZLgAtByRc9jIGqx34msUaevHd = UNdoh3qEzIe2g(KKm7cyf50MAI4OPkDltXi6dwZaj)
				nDRImvVYhXSc75buTM1ilLastogJFK = IDZHg5QJ9YdOBCbwxSy(PPFYGkKdjEeUTNomSuvlB,FYkZLgAtByRc9jIGqx34msUaevHd,ip6CohvO5Tya9mFWVf3JdY1qL,NYVaJlWbG1hj52U9LzdKfi,okRX5wzaWp6PcrB)
				if FYkZLgAtByRc9jIGqx34msUaevHd and zfTSd9VQlitrRhFMOnJ30:
					PGudrhJF8iDkSq96XVHEQZYf5L(mshLJcKH1fv03yRnDOr4ZT,ubxGUTt1LraKhVZgpAP(u"ࠫࡒࡋࡎࡖࡕࡢࡇࡆࡉࡈࡆࡡࠪ๑")+a2Ty3tzI4nEXYKMmZ6k7+QQdAXWBc2GPw(u"ࠬࡥࠧ๒")+xzUVeRHl6ApWE2QDT9BSICXKtJkdF7,PPFYGkKdjEeUTNomSuvlB,FYkZLgAtByRc9jIGqx34msUaevHd,GMkNL1RXxKFentp0Zh9d)
			else:
				xMTL52Bgvu1csftCe4bq6VFpXK.addDirectoryItem(IaCU04ZS1qx,zI3ROAZtiUq42rE9WDST68(u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠩ๓")+DFUIv2KGj9ke+TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠧ࠰ࡁࡷࡽࡵ࡫࠽࡭࡫ࡱ࡯ࠫࡳ࡯ࡥࡧࡀ࠹࠵࠶ࠧ๔"),evil9I2DnLJcy8.ListItem(P0qdZI384LKleuo(u"ࠨๆา๎่ࠦๅีๅ็อ๋ࠥๆࠡฮ๊หื้ࠧ๕")))
				xMTL52Bgvu1csftCe4bq6VFpXK.addDirectoryItem(IaCU04ZS1qx,TYf7Dc06PQgy1vEV9(u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠬ๖")+DFUIv2KGj9ke+dDYUoKi6JFM23p(u"ࠪ࠳ࡄࡺࡹࡱࡧࡀࡰ࡮ࡴ࡫ࠧ࡯ࡲࡨࡪࡃ࠵࠱࠲ࠪ๗"),evil9I2DnLJcy8.ListItem(Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠫศ็สฮࠢ็ฮ็ืรࠡษ็ฮๆอี๋ๆࠪ๘")))
			xMTL52Bgvu1csftCe4bq6VFpXK.endOfDirectory(IaCU04ZS1qx,ip6CohvO5Tya9mFWVf3JdY1qL,NYVaJlWbG1hj52U9LzdKfi,okRX5wzaWp6PcrB)
	return
def lp8eUQ9rw25BhRgWNPHT7K(XHvGn0VxWSuCYgBoMlq2m):
	if Nh0BWuiSndf(u"ࠬࡓࡅࡔࡕࡄࡋࡊ࡙ࠧ๙") in ZHIif0JXSYpqh1OKuoR or zI3ROAZtiUq42rE9WDST68(u"࠭ࡍࡆࡕࡖࡅࡌࡋࡓࡠࡖࡖࠫ๚") in ZHIif0JXSYpqh1OKuoR: return
	MY5Ufz13jLudeSp0xt2KB7hNcHE = DD5cFIejQa2X4BgAu9GWPyJ3tC7 if XHvGn0VxWSuCYgBoMlq2m else CCxMXuNUEzolDZTKrBJ
	if not MY5Ufz13jLudeSp0xt2KB7hNcHE:
		ZZWvnEeKqVjHTBQLp0cX3dGmA = vdkzUJEgiO2Poj0Ih3pL(hRWC8YSFvsm4JHOMVIne3jquZ.getSetting(dDYUoKi6JFM23p(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴࡭ࡦࡵࡶࡥ࡬࡫ࡳࠨ๛")))
		ZZWvnEeKqVjHTBQLp0cX3dGmA = LzYQg91SIxDeOGtCKd5 if not ZZWvnEeKqVjHTBQLp0cX3dGmA else int(ZZWvnEeKqVjHTBQLp0cX3dGmA)
		if not ZZWvnEeKqVjHTBQLp0cX3dGmA or not LzYQg91SIxDeOGtCKd5<=T3Axql94cU0BpO1wudEDtWXsf-ZZWvnEeKqVjHTBQLp0cX3dGmA<=XHvGn0VxWSuCYgBoMlq2m: MY5Ufz13jLudeSp0xt2KB7hNcHE = CCxMXuNUEzolDZTKrBJ
	if not MY5Ufz13jLudeSp0xt2KB7hNcHE:
		vuaMx6PwIhHsf18Gm = hRWC8YSFvsm4JHOMVIne3jquZ.getSetting(Nh0BWuiSndf(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡲ࡫ࡳࡴࡣࡪࡩࡸ࠭๜"))
		if vuaMx6PwIhHsf18Gm in [b8Qe150xVaJsnDSv,TYf7Dc06PQgy1vEV9(u"ࠩࡒࡐࡉࡥࡔࡐࡡࡈࡖࡗࡕࡒࠨ๝"),Xz3bA2PFENVCUtplu51(u"ࠪࡒࡊ࡝࡟ࡕࡑࡢࡉࡗࡘࡏࡓࠩ๞")]: MY5Ufz13jLudeSp0xt2KB7hNcHE = CCxMXuNUEzolDZTKrBJ
	if not MY5Ufz13jLudeSp0xt2KB7hNcHE:
		BnLKTScAyvoXqdZWhMEQUgOejk3R1 = hRWC8YSFvsm4JHOMVIne3jquZ.getSetting(mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠫࡦࡼ࠮ࡱࡴ࡬ࡺࡸ࠷ࠧ๟"))
		o7rG9Oj5SeZ0CdJP142VzkXpgYLBR = hRWC8YSFvsm4JHOMVIne3jquZ.getSetting(RRIHDFjoW9w7bSfVPhC(u"ࠬࡧࡶ࠯ࡲࡵ࡭ࡻࡹ࠲ࠨ๠"))
		ezoKr8LmnGaVS3Nv = dVRkZo9Daz.md5(BWNPxIG7vqdTy85pjHzUOrK3(u"࠻Ꮢ")*BnLKTScAyvoXqdZWhMEQUgOejk3R1.encode(OVauxZzLI10vcXT74K)).hexdigest()
		ezoKr8LmnGaVS3Nv = dVRkZo9Daz.md5(zI3ROAZtiUq42rE9WDST68(u"࠱࠵Ꮣ")*ezoKr8LmnGaVS3Nv.encode(OVauxZzLI10vcXT74K)).hexdigest()
		ezoKr8LmnGaVS3Nv = dVRkZo9Daz.md5(Nh0BWuiSndf(u"࠲࠻Ꮤ")*ezoKr8LmnGaVS3Nv.encode(OVauxZzLI10vcXT74K)).hexdigest()
		if ezoKr8LmnGaVS3Nv!=o7rG9Oj5SeZ0CdJP142VzkXpgYLBR: MY5Ufz13jLudeSp0xt2KB7hNcHE = CCxMXuNUEzolDZTKrBJ
	if MY5Ufz13jLudeSp0xt2KB7hNcHE: HKcQPmMpjLU6RbwxhX(DD5cFIejQa2X4BgAu9GWPyJ3tC7)
	return
def fPYwhSsFOBLbt7rM902im4oVE(E57WK4m31C8,rlqNUcK9vYgkT,YabJfs3q7yjpzvXioO,Q8ZnJhRz2mINwrY6VPf,I6YPOSofrpnTwRm8b,NGQDwOCXx1BZmd9Huc,vv5M4UfJS9ucKEiNbxtnaOZ,wc0Z9FAdf2B1J,XXra5dzn8tcLOxYZIE7pPof49Hh):
	zombcuDBIxEeSdOlZq1tsUH4f = int(Q8ZnJhRz2mINwrY6VPf)
	nYUxlDOpbX32Qtw = int(zombcuDBIxEeSdOlZq1tsUH4f//ddo23ZJtgcY(u"࠳࠳Ꮥ"))
	if   nYUxlDOpbX32Qtw==LzYQg91SIxDeOGtCKd5:  from cTGphBXNeH 		import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==qHYIWnOZLPkrQU:  from SSAx3ubGHY 		import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==IgQimel18t:  from zb9VgidsAx 		import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,NGQDwOCXx1BZmd9Huc,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==VwApyDY1Jc:  from U4Tpcq7NsB 		import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,NGQDwOCXx1BZmd9Huc,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==NvHugPosYDzRJ:  from WWw1kMIGUd 		import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ,NGQDwOCXx1BZmd9Huc)
	elif nYUxlDOpbX32Qtw==HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"࠸Ꮦ"):  from ZwecJ5FMHd 		import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==ddo23ZJtgcY(u"࠺Ꮧ"):  from dtfGrK52o0 		import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==VFjQx6Is28KvzLOmMXtg4GqTwa3(u"࠼Ꮨ"):  from AvLtXWDMhP 			import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==TYf7Dc06PQgy1vEV9(u"࠾Ꮩ"):  from mQAFeP4aYr 		import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==ubxGUTt1LraKhVZgpAP(u"࠹Ꮪ"):  from UZhqkX2yzg		import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==DYakr9g4PVU(u"࠲࠲Ꮫ"): from NuMiSoKYQF 		import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO)
	elif nYUxlDOpbX32Qtw==RRIHDFjoW9w7bSfVPhC(u"࠳࠴Ꮬ"): from LLXhstl7gG 		import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==IjZbnrBJmM2N(u"࠴࠶Ꮭ"): from yozpfunWgq 		import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,NGQDwOCXx1BZmd9Huc,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"࠵࠸Ꮮ"): from BFQibafsGj		import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,NGQDwOCXx1BZmd9Huc,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==SbjiWeHLQPoazqwp3cODkd7YxVgn(u"࠶࠺Ꮯ"): from x4nAtRpgFS 		import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ,E57WK4m31C8,NGQDwOCXx1BZmd9Huc,rlqNUcK9vYgkT,I6YPOSofrpnTwRm8b)
	elif nYUxlDOpbX32Qtw==vvWwO3Tx2dAgcijrFXq(u"࠷࠵Ꮰ"): from cTGphBXNeH 		import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==LAQD5wEkr18bUiGaYen3J(u"࠱࠷Ꮱ"): from EfbjD0wGhd		import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ,NGQDwOCXx1BZmd9Huc,XXra5dzn8tcLOxYZIE7pPof49Hh)
	elif nYUxlDOpbX32Qtw==shC5qBRV2A0lZ(u"࠲࠹Ꮲ"): from cTGphBXNeH 		import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==ubxGUTt1LraKhVZgpAP(u"࠳࠻Ꮳ"): from W8LVAjxyar		import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==dDYUoKi6JFM23p(u"࠴࠽Ꮴ"): from cTGphBXNeH 		import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==QQdAXWBc2GPw(u"࠶࠵Ꮵ"): from twBo6ILYAy		import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==uVQd103XyvUce2EBtzbYaC(u"࠷࠷Ꮶ"): from cjM8eNGR7n	import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==kke1PDGRBLuY8y(u"࠸࠲Ꮷ"): from ypCUdqKcZg		import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,NGQDwOCXx1BZmd9Huc,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==UUkIBz1sgQ9WfNeG6trKXvu0(u"࠲࠴Ꮸ"): from CC4xSVuWXg			import BBC8ziWGv2TLl5sjHm9uZk14b; XXxlOLJ9KRjPH382WVCvr6n71 = BBC8ziWGv2TLl5sjHm9uZk14b(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ,E57WK4m31C8,NGQDwOCXx1BZmd9Huc,XXra5dzn8tcLOxYZIE7pPof49Hh)
	elif nYUxlDOpbX32Qtw==yST5AHEfvPmcWpwGuh2BJ(u"࠳࠶Ꮹ"): from pn57ui6YOm 			import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"࠴࠸Ꮺ"): from CZJ7QPaeh2 		import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==DYakr9g4PVU(u"࠵࠺Ꮻ"): from Dv8qscELw9 			import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==TT8Mxv5Wq7nlC9IscdpPUY6(u"࠶࠼Ꮼ"): from pxDVAc9OnY		import BBC8ziWGv2TLl5sjHm9uZk14b; XXxlOLJ9KRjPH382WVCvr6n71 = BBC8ziWGv2TLl5sjHm9uZk14b(zombcuDBIxEeSdOlZq1tsUH4f,wc0Z9FAdf2B1J)
	elif nYUxlDOpbX32Qtw==m6hwdgP31a2zjN7lkpX(u"࠷࠾Ꮽ"): from CC4xSVuWXg			import BBC8ziWGv2TLl5sjHm9uZk14b; XXxlOLJ9KRjPH382WVCvr6n71 = BBC8ziWGv2TLl5sjHm9uZk14b(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ,E57WK4m31C8,NGQDwOCXx1BZmd9Huc,XXra5dzn8tcLOxYZIE7pPof49Hh)
	elif nYUxlDOpbX32Qtw==TT8Mxv5Wq7nlC9IscdpPUY6(u"࠸࠹Ꮾ"): from LFDByAkCjo	import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,NGQDwOCXx1BZmd9Huc,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==uVQd103XyvUce2EBtzbYaC(u"࠳࠱Ꮿ"): from jeADxZEL0I		import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==RRIHDFjoW9w7bSfVPhC(u"࠴࠳Ᏸ"): from pMKOBAWwbi		import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==Nh0BWuiSndf(u"࠵࠵Ᏹ"): from hrmU92paOZ		import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"࠶࠷Ᏺ"): from Yq4oCBNhcw		import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO)
	elif nYUxlDOpbX32Qtw==SbjiWeHLQPoazqwp3cODkd7YxVgn(u"࠷࠹Ᏻ"): from cTGphBXNeH 		import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==BWNPxIG7vqdTy85pjHzUOrK3(u"࠸࠻Ᏼ"): from MxkbhgKr40		import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==TYf7Dc06PQgy1vEV9(u"࠹࠶Ᏽ"): from quCJpzXv4r			import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==BmePGjS7FxK6kutUM(u"࠳࠸᏶"): from q7STAvBNhV			import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==TT8Mxv5Wq7nlC9IscdpPUY6(u"࠴࠺᏷"): from hetvLJfylE 		import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==Nh0BWuiSndf(u"࠵࠼ᏸ"): from WO3GF0r9ls		import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==Nh0BWuiSndf(u"࠷࠴ᏹ"): from PWzLngkZar	import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ,E57WK4m31C8,NGQDwOCXx1BZmd9Huc)
	elif nYUxlDOpbX32Qtw==DYakr9g4PVU(u"࠸࠶ᏺ"): from PWzLngkZar	import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ,E57WK4m31C8,NGQDwOCXx1BZmd9Huc)
	elif nYUxlDOpbX32Qtw==uVQd103XyvUce2EBtzbYaC(u"࠹࠸ᏻ"): from dzqHvb2nFt			import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==dDYUoKi6JFM23p(u"࠺࠳ᏼ"): from P98kZm1TK7			import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==yST5AHEfvPmcWpwGuh2BJ(u"࠴࠵ᏽ"): from uAkoiUHZ2e		import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"࠵࠷᏾"): from Yp5diLlFh2		import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==UUkIBz1sgQ9WfNeG6trKXvu0(u"࠶࠹᏿"): from X3cLRkjer9			import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"࠷࠻᐀"): from qfcDtmraLC		import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"࠸࠽ᐁ"): from AXH64EOWgQ		import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==kke1PDGRBLuY8y(u"࠹࠿ᐂ"): from Ye1lI5r7E3		import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==zI3ROAZtiUq42rE9WDST68(u"࠻࠰ᐃ"): from cTGphBXNeH 		import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==DYakr9g4PVU(u"࠵࠲ᐄ"): from qq8j1zF6m2 		import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==ddo23ZJtgcY(u"࠶࠴ᐅ"): from qq8j1zF6m2 		import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==mQNonhS7CV2BXOv(u"࠷࠶ᐆ"): from Dv8qscELw9 			import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"࠸࠸ᐇ"): from jtKsxUZvgl	import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ,NGQDwOCXx1BZmd9Huc)
	elif nYUxlDOpbX32Qtw==ddo23ZJtgcY(u"࠹࠺ᐈ"): from movfiGTFn2 		import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==yST5AHEfvPmcWpwGuh2BJ(u"࠺࠼ᐉ"): from CCLjfNHAD2		import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==DYakr9g4PVU(u"࠻࠷ᐊ"): from zzypDIMWSQ		import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==RRIHDFjoW9w7bSfVPhC(u"࠵࠹ᐋ"): from Ok1PMtrjdl		import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==VFjQx6Is28KvzLOmMXtg4GqTwa3(u"࠶࠻ᐌ"): from QoahFuteqU		import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==uVQd103XyvUce2EBtzbYaC(u"࠸࠳ᐍ"): from e30XGNEHlq			import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"࠹࠵ᐎ"): from KUM9ocB3HT			import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==shC5qBRV2A0lZ(u"࠺࠷ᐏ"): from ODNBEnqV7Q		import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==P0qdZI384LKleuo(u"࠻࠹ᐐ"): from SGFOAiU75K	import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==shC5qBRV2A0lZ(u"࠼࠴ᐑ"): from d4dNXL87qj			import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==VFjQx6Is28KvzLOmMXtg4GqTwa3(u"࠶࠶ᐒ"): from cnEib6j3WM			import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==m6hwdgP31a2zjN7lkpX(u"࠷࠸ᐓ"): from WizeJwBnTK			import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==TT8Mxv5Wq7nlC9IscdpPUY6(u"࠸࠺ᐔ"): from F97FYjQaNH		import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==Nh0BWuiSndf(u"࠹࠼ᐕ"): from h5wnytzoQG		import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==Mmpr0o76iWJvz1kTtfgI8hES(u"࠺࠾ᐖ"): from xekS2QGmuD		import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==ddo23ZJtgcY(u"࠼࠶ᐗ"): from D5SKEimOC4			import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"࠽࠱ᐘ"): from pxFlVO8bCG			import BBC8ziWGv2TLl5sjHm9uZk14b; XXxlOLJ9KRjPH382WVCvr6n71 = BBC8ziWGv2TLl5sjHm9uZk14b(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ,E57WK4m31C8,NGQDwOCXx1BZmd9Huc,XXra5dzn8tcLOxYZIE7pPof49Hh)
	elif nYUxlDOpbX32Qtw==mQNonhS7CV2BXOv(u"࠷࠳ᐙ"): from pxFlVO8bCG			import BBC8ziWGv2TLl5sjHm9uZk14b; XXxlOLJ9KRjPH382WVCvr6n71 = BBC8ziWGv2TLl5sjHm9uZk14b(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ,E57WK4m31C8,NGQDwOCXx1BZmd9Huc,XXra5dzn8tcLOxYZIE7pPof49Hh)
	elif nYUxlDOpbX32Qtw==ubxGUTt1LraKhVZgpAP(u"࠸࠵ᐚ"): from ttqOGsENb7	import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==shC5qBRV2A0lZ(u"࠹࠷ᐛ"): from H897MdrOAI		import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f)
	elif nYUxlDOpbX32Qtw==IjZbnrBJmM2N(u"࠺࠹ᐜ"): from H897MdrOAI		import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f)
	elif nYUxlDOpbX32Qtw==DYakr9g4PVU(u"࠻࠻ᐝ"): from EfbjD0wGhd		import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ,NGQDwOCXx1BZmd9Huc,XXra5dzn8tcLOxYZIE7pPof49Hh)
	elif nYUxlDOpbX32Qtw==ddo23ZJtgcY(u"࠼࠽ᐞ"): from c7rXmiApNg 		import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,NGQDwOCXx1BZmd9Huc,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==Nh0BWuiSndf(u"࠽࠸ᐟ"): from ZcOdVNMvYU 		import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,NGQDwOCXx1BZmd9Huc,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==mmcNLrXtzfpyCkZlvK5VwG2gujh(u"࠷࠺ᐠ"): from KTWbR9QiUY 		import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,NGQDwOCXx1BZmd9Huc,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==VFjQx6Is28KvzLOmMXtg4GqTwa3(u"࠹࠲ᐡ"): from rcz6XESfRt 		import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,NGQDwOCXx1BZmd9Huc,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==P0qdZI384LKleuo(u"࠺࠴ᐢ"): from Lfbsz0IxHa 		import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"࠻࠶ᐣ"): from QBl6HJObqY		import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,NGQDwOCXx1BZmd9Huc,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==shC5qBRV2A0lZ(u"࠼࠸ᐤ"): from CCKRgvfWTs		import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==Mmpr0o76iWJvz1kTtfgI8hES(u"࠽࠺ᐥ"): from GhvBJbZIpX		import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==LAQD5wEkr18bUiGaYen3J(u"࠾࠵ᐦ"): from QFwfH3Dxpy		import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==mQNonhS7CV2BXOv(u"࠸࠷ᐧ"): from k01kT78jBs		import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==BWNPxIG7vqdTy85pjHzUOrK3(u"࠹࠹ᐨ"): from jVTygHD9l1			import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==RRIHDFjoW9w7bSfVPhC(u"࠺࠻ᐩ"): from d65Z2a3Arf			import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==QTUBCcehw6qPd4x(u"࠻࠽ᐪ"): from sPWUanR2Jy		import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==IjZbnrBJmM2N(u"࠽࠵ᐫ"): from cxVDJXldni	import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==m6hwdgP31a2zjN7lkpX(u"࠾࠷ᐬ"): from ddx8UboLY7		import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==TT8Mxv5Wq7nlC9IscdpPUY6(u"࠿࠲ᐭ"): from I7kXxKWg5V		import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==ddo23ZJtgcY(u"࠹࠴ᐮ"): from uS8i1ynxWr		import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==VFjQx6Is28KvzLOmMXtg4GqTwa3(u"࠺࠶ᐯ"): from ypYUCsOKc5			import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"࠻࠸ᐰ"): from xxGQlzyA29			import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==yST5AHEfvPmcWpwGuh2BJ(u"࠼࠺ᐱ"): from GVowr1nlcb		import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==RRIHDFjoW9w7bSfVPhC(u"࠽࠼ᐲ"): from a0QPJHw1q4		import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"࠾࠾ᐳ"): from kAt5n08um6		import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==Xz3bA2PFENVCUtplu51(u"࠿࠹ᐴ"): from x32NUS6Tlr		import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==UUkIBz1sgQ9WfNeG6trKXvu0(u"࠱࠱࠲ᐵ"): from ig8IlBb9uH		import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==BmePGjS7FxK6kutUM(u"࠲࠲࠴ᐶ"): from rhRb5mEJBi	import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==mmcNLrXtzfpyCkZlvK5VwG2gujh(u"࠳࠳࠶ᐷ"): from cTGphBXNeH 		import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==TT8Mxv5Wq7nlC9IscdpPUY6(u"࠴࠴࠸ᐸ"): from M97Mn6VQc0	import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==mmcNLrXtzfpyCkZlvK5VwG2gujh(u"࠵࠵࠺ᐹ"): from MNbutIxi3y		import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==ubxGUTt1LraKhVZgpAP(u"࠶࠶࠵ᐺ"): from IkfcaO1w9y			import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==UUkIBz1sgQ9WfNeG6trKXvu0(u"࠷࠰࠷ᐻ"): from oW3JXkvGCM		import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ)
	elif nYUxlDOpbX32Qtw==BWNPxIG7vqdTy85pjHzUOrK3(u"࠱࠱࠹ᐼ"): from FejhUM1r8B		import x8IFqMZeJj7suCR4AaGoNXfEHm	; XXxlOLJ9KRjPH382WVCvr6n71 = x8IFqMZeJj7suCR4AaGoNXfEHm(zombcuDBIxEeSdOlZq1tsUH4f,YabJfs3q7yjpzvXioO,vv5M4UfJS9ucKEiNbxtnaOZ)
	else: XXxlOLJ9KRjPH382WVCvr6n71 = None
	return XXxlOLJ9KRjPH382WVCvr6n71
def YdsxuIoEqU(GXNZCDRs3E1V,UUF24APJXw0DzpoENvys1Zf3kRj,fOzS45youKYdNDqwm61aEI3A,showDialogs):
	TFAmLfwypkzsP1UYCMr8c = fOzS45youKYdNDqwm61aEI3A.split(RRIHDFjoW9w7bSfVPhC(u"࠭࠭ࠨ๡"),qHYIWnOZLPkrQU)[LzYQg91SIxDeOGtCKd5] if mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠧ࠮ࠩ๢") in fOzS45youKYdNDqwm61aEI3A else fOzS45youKYdNDqwm61aEI3A
	if not showDialogs or fOzS45youKYdNDqwm61aEI3A in FFrjbtTlpU59o0LhkWBAcs1RvfeX7u: return DD5cFIejQa2X4BgAu9GWPyJ3tC7
	z0zWBctmDyOiM4dnFAxHVL = hRWC8YSFvsm4JHOMVIne3jquZ.getSetting(ddo23ZJtgcY(u"ࠨࡣࡹ࠲ࡱࡧ࡮ࡨࡷࡤ࡫ࡪ࠴ࡴࡳࡣࡱࡷࡱࡧࡴࡦࠩ๣"))
	hRWC8YSFvsm4JHOMVIne3jquZ.setSetting(QTUBCcehw6qPd4x(u"ࠩࡤࡺ࠳ࡲࡡ࡯ࡩࡸࡥ࡬࡫࠮ࡵࡴࡤࡲࡸࡲࡡࡵࡧࠪ๤"),b8Qe150xVaJsnDSv)
	YGKiWoZXrBd = GXNZCDRs3E1V in [Xz3bA2PFENVCUtplu51(u"࠻ᑀ"),zI3ROAZtiUq42rE9WDST68(u"࠳࠴࠴࠵࠷ᐾ"),mmcNLrXtzfpyCkZlvK5VwG2gujh(u"࠲࠳࠳࠴࠷ᐽ"),HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"࠴࠴࠵࠻࠴ᐿ")]
	YHweuSgR4bn = UUF24APJXw0DzpoENvys1Zf3kRj.lower()
	DCxRwB0FIK = GXNZCDRs3E1V in [LzYQg91SIxDeOGtCKd5,RRIHDFjoW9w7bSfVPhC(u"࠱࠱࠶ᑃ"),VFjQx6Is28KvzLOmMXtg4GqTwa3(u"࠶࠶࠰࠷࠳ᑁ"),m6hwdgP31a2zjN7lkpX(u"࠷࠱࠲ᑂ")]
	cMdtDQ4XG1UAZzO2aSRhFLmbnB = Nh0BWuiSndf(u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠤࡧࡿࠠࡤ࡮ࡲࡹࡩ࡬࡬ࡢࡴࡨࠫ๥") in YHweuSgR4bn
	vBTVHQrK5J0gzt8fpSh2lqjUsen = Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠫࡧࡲ࡯ࡤ࡭ࡨࡨࠥࡨࡹࠡ࠷ࠣࡷࡪࡩ࡯࡯ࡦࡶࠤࡧࡸ࡯ࡸࡵࡨࡶࠥࡩࡨࡦࡥ࡮ࠫ๦") in YHweuSgR4bn
	i0qebSxXnuO = mQNonhS7CV2BXOv(u"ࠬࡨ࡬ࡰࡥ࡮ࡩࡩࠦࡢࡺࠢࡵࡩࡨࡧࡰࡵࡥ࡫ࡥࠬ๧") in YHweuSgR4bn
	dbiPkBTs3yYM = Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"࠭ࡢ࡭ࡱࡦ࡯ࡪࡪࠠࡣࡻࠣࡧࡱࡵࡵࡥࡨ࡯ࡥࡷ࡫ࠠࡴࡧࡦࡹࡷ࡯ࡴࡺࠢࡦ࡬ࡪࡩ࡫ࠨ๨") in YHweuSgR4bn
	XXS4e7n5chbPYxNkit = hRWC8YSFvsm4JHOMVIne3jquZ.getSetting(ubxGUTt1LraKhVZgpAP(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡹࡸ࡫ࡰࡳࡱࡻࡽࠬ๩"))
	ddks654iAjgKNp1hOJluQyWHR = hRWC8YSFvsm4JHOMVIne3jquZ.getSetting(S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡺࡹࡥࡥࡰࡶࠫ๪"))
	iI3HUkgV7c0P4uJohRCL1xn = RRIHDFjoW9w7bSfVPhC(u"ࠩไุ้ࠦแ๋ࠢึัอࠦวๅืไัฮࠦๅ็ࠢส่ส์สา่อࠫ๫")
	s60snAIgVWOHizFbfEtr2 = zI3ROAZtiUq42rE9WDST68(u"ࠪࡉࡷࡸ࡯ࡳࠢࠪ๬")+str(GXNZCDRs3E1V)+zI3ROAZtiUq42rE9WDST68(u"ࠫ࠿ࠦࠧ๭")+UUF24APJXw0DzpoENvys1Zf3kRj
	s60snAIgVWOHizFbfEtr2 = SgrGWuAHcLKBQMJetb9(s60snAIgVWOHizFbfEtr2)
	if DCxRwB0FIK or cMdtDQ4XG1UAZzO2aSRhFLmbnB or vBTVHQrK5J0gzt8fpSh2lqjUsen or i0qebSxXnuO or dbiPkBTs3yYM: iI3HUkgV7c0P4uJohRCL1xn += SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠬࠦ࠮ࠡษ็้ํู่ࠡใํ๋ࠥำฬษูࠢำ้่ࠥะ์ฺ้ࠣีั่ࠢส่ส์สา่อࠤฬ๊ฮศืࠣฬ่ࠦร้ࠢหห้๋่ใ฻࡟ࡲࠬ๮")
	if YGKiWoZXrBd: iI3HUkgV7c0P4uJohRCL1xn += ubxGUTt1LraKhVZgpAP(u"࠭ࠠ࠯ࠢ็ำ๏้ࠠฯูฦࠤࡉࡔࡓ๊่ࠡ฽๋อ็ࠡฬ฼ิึࠦสาฮ่อࠥอำๆࠢส่๊๎โฺࠢศ่๎ࠦัใ็๊ࡠࡳ࠭๯")
	s60snAIgVWOHizFbfEtr2 = eeN6dTEnkJxI+rC3Tlno96KjLDIvBaSWUbR8+s60snAIgVWOHizFbfEtr2+hAIp8kmC36T5WFPMSXOwnNbtD
	if XXS4e7n5chbPYxNkit==LAQD5wEkr18bUiGaYen3J(u"ࠧࡂࡕࡎࠫ๰") or ddks654iAjgKNp1hOJluQyWHR==vvWwO3Tx2dAgcijrFXq(u"ࠨࡃࡖࡏࠬ๱"):
		iI3HUkgV7c0P4uJohRCL1xn += eeN6dTEnkJxI+OkuB9nwhD8U1+Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"๊่ࠩࠥะั๋ัࠣว๋๊ࠦฮษ๋่ࠥอไษำ้ห๊าࠠฦื็หาࠦวๅ็ื็้ฯࠠ࠯࠰ࠣว๊ࠦสา์าࠤสืำศๆࠣีุอไสࠢฦ์ࠥิืฤࠢศ่๎ࠦวๅ็หี๊าࠠภࠣࠤࠫ๲")+hAIp8kmC36T5WFPMSXOwnNbtD
	XtjoB0NqWClE4Kdcwy8ZhsGubI = DD5cFIejQa2X4BgAu9GWPyJ3tC7
	if XXS4e7n5chbPYxNkit==mQNonhS7CV2BXOv(u"ࠪࡅࡘࡑࠧ๳") or ddks654iAjgKNp1hOJluQyWHR==VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠫࡆ࡙ࡋࠨ๴"):
		juILqxAVNHQrPUi4 = QlaM6yHe0bgh58Vx3BAZD(HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ๵"),Nh0BWuiSndf(u"࠭ฮา๊ฯࠫ๶"),Nh0BWuiSndf(u"ࠧฦำึห้ࠦไๅ็หี๊าࠧ๷"),mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠨฬุ่๏ำࠠศๆุ่่๊ษࠨ๸"),TFAmLfwypkzsP1UYCMr8c+R1BKXhzpGH6CoO9jLsPwQWu+OJ5kiNTSpIdCco0H(TFAmLfwypkzsP1UYCMr8c),iI3HUkgV7c0P4uJohRCL1xn+eeN6dTEnkJxI+s60snAIgVWOHizFbfEtr2)
		if juILqxAVNHQrPUi4==qHYIWnOZLPkrQU:
			from cTGphBXNeH import lcA0mHzo1TQUIwMKZa8
			lcA0mHzo1TQUIwMKZa8()
		elif juILqxAVNHQrPUi4==IgQimel18t: XtjoB0NqWClE4Kdcwy8ZhsGubI = CCxMXuNUEzolDZTKrBJ
	else: tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,TFAmLfwypkzsP1UYCMr8c+R1BKXhzpGH6CoO9jLsPwQWu+OJ5kiNTSpIdCco0H(TFAmLfwypkzsP1UYCMr8c),iI3HUkgV7c0P4uJohRCL1xn,s60snAIgVWOHizFbfEtr2)
	hRWC8YSFvsm4JHOMVIne3jquZ.setSetting(ddo23ZJtgcY(u"ࠩࡤࡺ࠳ࡲࡡ࡯ࡩࡸࡥ࡬࡫࠮ࡵࡴࡤࡲࡸࡲࡡࡵࡧࠪ๹"),z0zWBctmDyOiM4dnFAxHVL)
	return XtjoB0NqWClE4Kdcwy8ZhsGubI
def thjSw2b6gur9s(jYgaBpzxVf30E6mbeTv9DQwLOdtnq=DD5cFIejQa2X4BgAu9GWPyJ3tC7,fSnP3AJEbta6Izqj1Y8G4TBw=[]):
	tfTpaEHB9jR0lZbw8Mxk6 = [oYXBd89zTnZPipv56Qf1UxurbC3,KNTV1H9Dl32a6yxiUEBdvZ7qgr]+fSnP3AJEbta6Izqj1Y8G4TBw
	for lHXFzMgVqsNRnY0TKmESd in x76PfMyAp1L2WejkU3.listdir(vIaQF8hqXeiJERYuD):
		if jYgaBpzxVf30E6mbeTv9DQwLOdtnq and (lHXFzMgVqsNRnY0TKmESd.startswith(SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠪ࡭ࡵࡺࡶࠨ๺")) or lHXFzMgVqsNRnY0TKmESd.startswith(UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠫࡲ࠹ࡵࠨ๻"))): continue
		if lHXFzMgVqsNRnY0TKmESd.startswith(BWNPxIG7vqdTy85pjHzUOrK3(u"ࠬ࡬ࡩ࡭ࡧࡢࠫ๼")): continue
		tCGYBTaUxz1XNJlDMgfAe = x76PfMyAp1L2WejkU3.path.join(vIaQF8hqXeiJERYuD,lHXFzMgVqsNRnY0TKmESd)
		if tCGYBTaUxz1XNJlDMgfAe in tfTpaEHB9jR0lZbw8Mxk6: continue
		try: x76PfMyAp1L2WejkU3.remove(tCGYBTaUxz1XNJlDMgfAe)
		except: pass
	if fH3Ie4SrRCsFMVo98hpN not in tfTpaEHB9jR0lZbw8Mxk6: p3pjrEcdKBfsDZw4qSJ(fH3Ie4SrRCsFMVo98hpN,CCxMXuNUEzolDZTKrBJ,DD5cFIejQa2X4BgAu9GWPyJ3tC7)
	wLQCTr5lqbsVYeAHdzfhZ1F.sleep(TYf7Dc06PQgy1vEV9(u"࠲ᑄ"))
	return
def x91iT3fDQths7q2KpCvy586VORAzX(zhBM6C5sKiWF2,ufxrtSb9vkTpPhqG8WK,YabJfs3q7yjpzvXioO,kTSyagGWsFnolYhMO5fCwvpNuPqR,Hjb64dTft8SzJ,gPpvwzQVkYrG58uD2j,showDialogs,fOzS45youKYdNDqwm61aEI3A,aLwqTHENGm2Q=CCxMXuNUEzolDZTKrBJ,ecs4ouJGNY6TSH=CCxMXuNUEzolDZTKrBJ):
	YabJfs3q7yjpzvXioO = YabJfs3q7yjpzvXioO+yST5AHEfvPmcWpwGuh2BJ(u"࠭ࡼࡽࡏࡼࡔࡷࡵࡸࡺࡗࡵࡰࡂ࠭๽")+zhBM6C5sKiWF2
	Ci4rQ0qV915j2AIkHTbcy = dcLRAZWFzODax2jf0tHCX81pJveNY(Q49IsrlSuYRAVbGKhwdckLDOetF2PZ,ufxrtSb9vkTpPhqG8WK,YabJfs3q7yjpzvXioO,kTSyagGWsFnolYhMO5fCwvpNuPqR,Hjb64dTft8SzJ,gPpvwzQVkYrG58uD2j,showDialogs,fOzS45youKYdNDqwm61aEI3A,aLwqTHENGm2Q,ecs4ouJGNY6TSH)
	if YabJfs3q7yjpzvXioO in Ci4rQ0qV915j2AIkHTbcy.content: Ci4rQ0qV915j2AIkHTbcy.succeeded = DD5cFIejQa2X4BgAu9GWPyJ3tC7
	if not Ci4rQ0qV915j2AIkHTbcy.succeeded:
		AKQaWIc0YCHGVnT()
	return Ci4rQ0qV915j2AIkHTbcy
def v3buFcRmEaijpzo2y15O(YabJfs3q7yjpzvXioO):
	Ci4rQ0qV915j2AIkHTbcy = dcLRAZWFzODax2jf0tHCX81pJveNY(LtlXH3fvMydAx,ubxGUTt1LraKhVZgpAP(u"ࠧࡈࡇࡗࠫ๾"),YabJfs3q7yjpzvXioO,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,CCxMXuNUEzolDZTKrBJ,b8Qe150xVaJsnDSv,TYf7Dc06PQgy1vEV9(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡉ࡙ࡥࡐࡓࡑ࡛ࡍࡊ࡙࡟ࡍࡋࡖࡘ࠲࠷ࡳࡵࠩ๿"),CCxMXuNUEzolDZTKrBJ,DD5cFIejQa2X4BgAu9GWPyJ3tC7)
	zlSp5dtPrHUnuXVJLyC = []
	if Ci4rQ0qV915j2AIkHTbcy.succeeded:
		oH3N1dY9vLpaDJfnTVP5Z7q = Ci4rQ0qV915j2AIkHTbcy.content
		TQ2XIAhefPdWrsmFlYyt = YYBlm36zd0Jst18LXwo4.findall(Nh0BWuiSndf(u"ࠩࠣࠬ࠳࠰࠿ࠪࠢ࡟ࡨࢀ࠷ࠬ࠴ࡿࡰࡷࠬ຀"),oH3N1dY9vLpaDJfnTVP5Z7q)
		if TQ2XIAhefPdWrsmFlYyt: oH3N1dY9vLpaDJfnTVP5Z7q = eeN6dTEnkJxI.join(TQ2XIAhefPdWrsmFlYyt)
		GYl6AScxQKmB4aEet3vrhXVjp = oH3N1dY9vLpaDJfnTVP5Z7q.replace(d6ekSEojpFUANKJ7r9WTlI3niLBOu,b8Qe150xVaJsnDSv).strip(eeN6dTEnkJxI).split(eeN6dTEnkJxI)
		zlSp5dtPrHUnuXVJLyC = []
		for zhBM6C5sKiWF2 in GYl6AScxQKmB4aEet3vrhXVjp:
			if zhBM6C5sKiWF2.count(P0qdZI384LKleuo(u"ࠪ࠲ࠬກ"))==VwApyDY1Jc: zlSp5dtPrHUnuXVJLyC.append(zhBM6C5sKiWF2)
	return zlSp5dtPrHUnuXVJLyC
def YDoWTu980xpgLIrMJ7l1tGm(*aargs):
	cfVNlawUr6CXQvGZxdWu3ioIE8Dn = uVQd103XyvUce2EBtzbYaC(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡰࡪ࠰ࡳࡶࡴࡾࡹࡴࡥࡵࡥࡵ࡫࠮ࡤࡱࡰ࠳ࡻ࠸࠯ࡀࡴࡨࡵࡺ࡫ࡳࡵ࠿ࡧ࡭ࡸࡶ࡬ࡢࡻࡳࡶࡴࡾࡩࡦࡵࠩࡴࡷࡵࡸࡺࡶࡼࡴࡪࡃࡨࡵࡶࡳࠪࡹ࡯࡭ࡦࡱࡸࡸࡂ࠷࠰࠱࠲࠳ࠪࡸࡹ࡬࠾ࡻࡨࡷࠫࡲࡩ࡮࡫ࡷࡁ࠶࠶ࠦࡤࡱࡸࡲࡹࡸࡹ࠾ࡐࡏ࠰ࡇࡋࠬࡅࡇ࠯ࡊࡗ࠲ࡇࡃ࠮ࡗࡖࠬຂ")
	D7MbiAuvVdoqg5RUGFhecHBYTLC = QTUBCcehw6qPd4x(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡲࡢࡹ࠱࡫࡮ࡺࡨࡶࡤࡸࡷࡪࡸࡣࡰࡰࡷࡩࡳࡺ࠮ࡤࡱࡰ࠳ࡷࡵ࡯ࡴࡶࡨࡶࡰ࡯ࡤ࠰ࡱࡳࡩࡳࡶࡲࡰࡺࡼࡰ࡮ࡹࡴ࠰࡯ࡤ࡭ࡳ࠵ࡈࡕࡖࡓࡗ࠳ࡺࡸࡵࠩ຃")
	azQAvckhIugPBF15xMjye6GilbrSR9 = v3buFcRmEaijpzo2y15O(D7MbiAuvVdoqg5RUGFhecHBYTLC)
	zlSp5dtPrHUnuXVJLyC = v3buFcRmEaijpzo2y15O(cfVNlawUr6CXQvGZxdWu3ioIE8Dn)
	WtUgTLqu3z0PkyfcComJ = azQAvckhIugPBF15xMjye6GilbrSR9+zlSp5dtPrHUnuXVJLyC
	mwIxD3GBPgLVc2aq9(iebCpLE8fuxTRg,EECz06teoykrNFfq(QQ8pvXNcBfVkP5rRJ7o)+VFjQx6Is28KvzLOmMXtg4GqTwa3(u"࠭ࠠࠡࠢࡊࡳࡹࠦࡰࡳࡱࡻ࡭ࡪࡹࠠ࡭࡫ࡶࡸࠥࠦࠠ࠲ࡵࡷ࠯࠷ࡴࡤ࠻ࠢ࡞ࠤࠬຄ")+str(len(azQAvckhIugPBF15xMjye6GilbrSR9))+Mmpr0o76iWJvz1kTtfgI8hES(u"ࠧࠬࠩ຅")+str(len(zlSp5dtPrHUnuXVJLyC))+Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠨࠢࡠࠫຆ"))
	zhBM6C5sKiWF2 = hRWC8YSFvsm4JHOMVIne3jquZ.getSetting(Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠩࡤࡺ࠳ࡶࡲࡰࡺࡼ࠲ࡱࡧࡳࡵࠩງ"))
	Ci4rQ0qV915j2AIkHTbcy = BwV6rAIldfsGyK7oeJT053()
	hRWC8YSFvsm4JHOMVIne3jquZ.setSetting(DYakr9g4PVU(u"ࠪࡥࡻ࠴ࡰࡳࡱࡻࡽ࠳ࡲࡡࡴࡶࠪຈ"),b8Qe150xVaJsnDSv)
	if zhBM6C5sKiWF2 or WtUgTLqu3z0PkyfcComJ:
		od4AIsBzi3Ga2bLXNlZKME,S9WxYCoO3GDw = LzYQg91SIxDeOGtCKd5,uVQd103XyvUce2EBtzbYaC(u"࠳࠳ᑅ")
		CryqmZ05YgVwPlGJR7MXAik4QI3UnK = len(WtUgTLqu3z0PkyfcComJ)
		rQKTpbRBo19dhNFfZYU6G7OVs = S9WxYCoO3GDw
		if CryqmZ05YgVwPlGJR7MXAik4QI3UnK>rQKTpbRBo19dhNFfZYU6G7OVs: r4YdsnqT5HoNiL6yQea1t7F = rQKTpbRBo19dhNFfZYU6G7OVs
		else: r4YdsnqT5HoNiL6yQea1t7F = CryqmZ05YgVwPlGJR7MXAik4QI3UnK
		oFdKCgQLvjqfyNuUwB7l46D9n3XA = qHiNBx6PXjKatkWf37AwFClzsp2DmE.sample(WtUgTLqu3z0PkyfcComJ,r4YdsnqT5HoNiL6yQea1t7F)
		if zhBM6C5sKiWF2: oFdKCgQLvjqfyNuUwB7l46D9n3XA = [zhBM6C5sKiWF2]+oFdKCgQLvjqfyNuUwB7l46D9n3XA
		HJAgTDzP2esU6Rtl = mIv7g95PNyqzLZDM8ihkcr1w(DD5cFIejQa2X4BgAu9GWPyJ3tC7,DD5cFIejQa2X4BgAu9GWPyJ3tC7)
		xhWaiNzZPjTfLQV9b7H382ovXrEKBe = wLQCTr5lqbsVYeAHdzfhZ1F.time()
		while wLQCTr5lqbsVYeAHdzfhZ1F.time()-xhWaiNzZPjTfLQV9b7H382ovXrEKBe<=S9WxYCoO3GDw and not HJAgTDzP2esU6Rtl.finishedLIST:
			if od4AIsBzi3Ga2bLXNlZKME<r4YdsnqT5HoNiL6yQea1t7F:
				zhBM6C5sKiWF2 = oFdKCgQLvjqfyNuUwB7l46D9n3XA[od4AIsBzi3Ga2bLXNlZKME]
				HJAgTDzP2esU6Rtl.N4vDb3TKpY0Lr(od4AIsBzi3Ga2bLXNlZKME,x91iT3fDQths7q2KpCvy586VORAzX,zhBM6C5sKiWF2,*aargs)
			wLQCTr5lqbsVYeAHdzfhZ1F.sleep(yST5AHEfvPmcWpwGuh2BJ(u"࠳࠲࠼࠻ᑆ"))
			od4AIsBzi3Ga2bLXNlZKME += qHYIWnOZLPkrQU
			mwIxD3GBPgLVc2aq9(MtTygrzXFlQ,EECz06teoykrNFfq(QQ8pvXNcBfVkP5rRJ7o)+TYf7Dc06PQgy1vEV9(u"ࠫࠥࠦࠠࡕࡴࡼ࡭ࡳ࡭࠺ࠡࠢࠣࡔࡷࡵࡸࡺ࠼ࠣ࡟ࠥ࠭ຉ")+zhBM6C5sKiWF2+vvWwO3Tx2dAgcijrFXq(u"ࠬࠦ࡝ࠨຊ"))
		finishedLIST = HJAgTDzP2esU6Rtl.finishedLIST
		if finishedLIST:
			resultsDICT = HJAgTDzP2esU6Rtl.resultsDICT
			PvX5xbhKtQcgfIlqWzZ7djUk8eArEF = finishedLIST[LzYQg91SIxDeOGtCKd5]
			Ci4rQ0qV915j2AIkHTbcy = resultsDICT[PvX5xbhKtQcgfIlqWzZ7djUk8eArEF]
			zhBM6C5sKiWF2 = oFdKCgQLvjqfyNuUwB7l46D9n3XA[int(PvX5xbhKtQcgfIlqWzZ7djUk8eArEF)]
			hRWC8YSFvsm4JHOMVIne3jquZ.setSetting(mQNonhS7CV2BXOv(u"࠭ࡡࡷ࠰ࡳࡶࡴࡾࡹ࠯࡮ࡤࡷࡹ࠭຋"),zhBM6C5sKiWF2)
			if PvX5xbhKtQcgfIlqWzZ7djUk8eArEF!=LzYQg91SIxDeOGtCKd5: mwIxD3GBPgLVc2aq9(iebCpLE8fuxTRg,EECz06teoykrNFfq(QQ8pvXNcBfVkP5rRJ7o)+mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠧࠡࠢࠣࡗࡺࡩࡣࡦࡵࡶ࠾ࠥࠦࠠࡑࡴࡲࡼࡾࡀࠠ࡜ࠢࠪຌ")+zhBM6C5sKiWF2+TYf7Dc06PQgy1vEV9(u"ࠨࠢࡠࠫຍ"))
			else: mwIxD3GBPgLVc2aq9(iebCpLE8fuxTRg,EECz06teoykrNFfq(QQ8pvXNcBfVkP5rRJ7o)+Nh0BWuiSndf(u"ࠩࠣࠤ࡙ࠥࡵࡤࡥࡨࡷࡸࡀࠠࠡࠢࡖࡥࡻ࡫ࡤࠡࡲࡵࡳࡽࡿ࠺ࠡ࡝ࠣࠫຎ")+zhBM6C5sKiWF2+mQNonhS7CV2BXOv(u"ࠪࠤࡢ࠭ຏ"))
	return Ci4rQ0qV915j2AIkHTbcy
def Iyi1anzf2uqjJKM5(wmnclRQJTp9EH32OU5xjy0qDfVr,ahDrn9Jebl7mgKQB8vxVGOqPTk):
	ozJd6QCKGkXjOPMmaNq = wmnclRQJTp9EH32OU5xjy0qDfVr.create_connection
	def bTlPuYXcIrkahJwA(BHWxhCdeKg49sy6ui7mDlU,*aargs,**kkwargs):
		UdnYNWKeIaopPXDl2ArM3VkyR49S1,DBLTbU4RhJ = BHWxhCdeKg49sy6ui7mDlU
		ip = ppyKRhnr3doQ9P5HlMTSCveNu1(UdnYNWKeIaopPXDl2ArM3VkyR49S1,ahDrn9Jebl7mgKQB8vxVGOqPTk)
		if ip: UdnYNWKeIaopPXDl2ArM3VkyR49S1 = ip[LzYQg91SIxDeOGtCKd5]
		else:
			if ahDrn9Jebl7mgKQB8vxVGOqPTk in aZN3l1t6JE4oPmpkzLQSW5: aZN3l1t6JE4oPmpkzLQSW5.remove(ahDrn9Jebl7mgKQB8vxVGOqPTk)
			if aZN3l1t6JE4oPmpkzLQSW5:
				ZQyl1dF4zuD7SbU3pc0 = aZN3l1t6JE4oPmpkzLQSW5[LzYQg91SIxDeOGtCKd5]
				ip = ppyKRhnr3doQ9P5HlMTSCveNu1(UdnYNWKeIaopPXDl2ArM3VkyR49S1,ZQyl1dF4zuD7SbU3pc0)
				if ip: UdnYNWKeIaopPXDl2ArM3VkyR49S1 = ip[LzYQg91SIxDeOGtCKd5]
		BHWxhCdeKg49sy6ui7mDlU = (UdnYNWKeIaopPXDl2ArM3VkyR49S1,DBLTbU4RhJ)
		return ozJd6QCKGkXjOPMmaNq(BHWxhCdeKg49sy6ui7mDlU,*aargs,**kkwargs)
	wmnclRQJTp9EH32OU5xjy0qDfVr.create_connection = bTlPuYXcIrkahJwA
	return ozJd6QCKGkXjOPMmaNq
def px6EDHfbSJuqYe5Nlc21RG9OdtI(YabJfs3q7yjpzvXioO):
	h9aP48wKJ3EvStcLF5DXxV,v8sJLlOktmICK6SXNTePWzw5 = YabJfs3q7yjpzvXioO.split(Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠫ࠴࠭ຐ"))[IgQimel18t],zI3ROAZtiUq42rE9WDST68(u"࠼࠵ᑇ")
	if mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠬࡀࠧຑ") in h9aP48wKJ3EvStcLF5DXxV: h9aP48wKJ3EvStcLF5DXxV,v8sJLlOktmICK6SXNTePWzw5 = h9aP48wKJ3EvStcLF5DXxV.split(QQdAXWBc2GPw(u"࠭࠺ࠨຒ"))
	OzZ13fQFq6L92lNbWctmHuPM5J = uVQd103XyvUce2EBtzbYaC(u"ࠧ࠰ࠩຓ")+zI3ROAZtiUq42rE9WDST68(u"ࠨ࠱ࠪດ").join(YabJfs3q7yjpzvXioO.split(shC5qBRV2A0lZ(u"ࠩ࠲ࠫຕ"))[DYakr9g4PVU(u"࠸ᑈ"):])
	rC39wAIKjUuS = Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠪࡋࡊ࡚ࠠࠨຖ")+OzZ13fQFq6L92lNbWctmHuPM5J+dDYUoKi6JFM23p(u"ࠫࠥࡎࡔࡕࡒ࠲࠵࠳࠷࡜ࡳ࡞ࡱࠫທ")
	rC39wAIKjUuS += IjZbnrBJmM2N(u"ࠬࡎ࡯ࡴࡶ࠽ࠤࠬຘ")+h9aP48wKJ3EvStcLF5DXxV+shC5qBRV2A0lZ(u"࠭࡜ࡳ࡞ࡱࠫນ")
	rC39wAIKjUuS += DYakr9g4PVU(u"ࠧ࡝ࡴ࡟ࡲࠬບ")
	from socket import socket as EvmDR2G3dP7Hbexu1,AF_INET as S4TFcnYvxCGyBa1ZReLUD6srzI,SOCK_STREAM as gIpbXNR8rzLOKDdv57Z0twCEiF
	try:
		wWeTdEkiucavVXY9glMpzZ76HyA = EvmDR2G3dP7Hbexu1(S4TFcnYvxCGyBa1ZReLUD6srzI,gIpbXNR8rzLOKDdv57Z0twCEiF)
		wWeTdEkiucavVXY9glMpzZ76HyA.connect((h9aP48wKJ3EvStcLF5DXxV,v8sJLlOktmICK6SXNTePWzw5))
		wWeTdEkiucavVXY9glMpzZ76HyA.send(rC39wAIKjUuS.encode(OVauxZzLI10vcXT74K))
		CAwFKSxrvRP8TkpXi = wWeTdEkiucavVXY9glMpzZ76HyA.recv(m6hwdgP31a2zjN7lkpX(u"࠴࠱࠻࠹ᑊ")*IjZbnrBJmM2N(u"࠷࠰࠳࠶ᑉ"))
		oH3N1dY9vLpaDJfnTVP5Z7q = repr(CAwFKSxrvRP8TkpXi)
	except: oH3N1dY9vLpaDJfnTVP5Z7q = b8Qe150xVaJsnDSv
	return oH3N1dY9vLpaDJfnTVP5Z7q
def Wl2eu1PavfQ(rM6EVzvpbh3HUPu,E57WK4m31C8):
	if LAQD5wEkr18bUiGaYen3J(u"ࠨ࠰ࠪປ") not in rM6EVzvpbh3HUPu: return rM6EVzvpbh3HUPu
	rM6EVzvpbh3HUPu = rM6EVzvpbh3HUPu+shC5qBRV2A0lZ(u"ࠩ࠲ࠫຜ")
	XzOASo38K0spR6tmj9lvdYyLJiwnG,V7VavTkrSM = rM6EVzvpbh3HUPu.split(S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠪ࠲ࠬຝ"),yST5AHEfvPmcWpwGuh2BJ(u"࠲ᑋ"))
	TTZJwhtqCDAnL5b3u8UVSmPei01jx9,wweXonCgBEi2QAO0tWvd5R3jfkrabI = V7VavTkrSM.split(IjZbnrBJmM2N(u"ࠫ࠴࠭ພ"),Mmpr0o76iWJvz1kTtfgI8hES(u"࠳ᑌ"))
	ZzKk9N840boIO3VGgDMn2Y = XzOASo38K0spR6tmj9lvdYyLJiwnG+ddo23ZJtgcY(u"ࠬ࠴ࠧຟ")+TTZJwhtqCDAnL5b3u8UVSmPei01jx9
	if E57WK4m31C8 in [mQNonhS7CV2BXOv(u"࠭ࡨࡰࡵࡷࠫຠ"),VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠧ࡯ࡣࡰࡩࠬມ")] and TYf7Dc06PQgy1vEV9(u"ࠨ࠱ࠪຢ") in ZzKk9N840boIO3VGgDMn2Y: ZzKk9N840boIO3VGgDMn2Y = ZzKk9N840boIO3VGgDMn2Y.rsplit(Nh0BWuiSndf(u"ࠩ࠲ࠫຣ"),VFjQx6Is28KvzLOmMXtg4GqTwa3(u"࠴ᑍ"))[qHYIWnOZLPkrQU]
	if E57WK4m31C8==ubxGUTt1LraKhVZgpAP(u"ࠪࡲࡦࡳࡥࠨ຤") and TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠫ࠳࠭ລ") in ZzKk9N840boIO3VGgDMn2Y:
		nDzY5OxkvPUq3aBdjW7gl = ZzKk9N840boIO3VGgDMn2Y.split(Xz3bA2PFENVCUtplu51(u"ࠬ࠴ࠧ຦"))
		n6TDI30gecEMhLYbtPNJoy = len(nDzY5OxkvPUq3aBdjW7gl)
		if m6hwdgP31a2zjN7lkpX(u"࠭ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱࠫວ") in ZzKk9N840boIO3VGgDMn2Y: nDzY5OxkvPUq3aBdjW7gl = TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠧࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲࠬຨ")
		elif n6TDI30gecEMhLYbtPNJoy<=IgQimel18t: nDzY5OxkvPUq3aBdjW7gl = nDzY5OxkvPUq3aBdjW7gl[LzYQg91SIxDeOGtCKd5]
		elif n6TDI30gecEMhLYbtPNJoy>=VwApyDY1Jc: nDzY5OxkvPUq3aBdjW7gl = nDzY5OxkvPUq3aBdjW7gl[qHYIWnOZLPkrQU]
		if len(nDzY5OxkvPUq3aBdjW7gl)>qHYIWnOZLPkrQU: ZzKk9N840boIO3VGgDMn2Y = nDzY5OxkvPUq3aBdjW7gl
	return ZzKk9N840boIO3VGgDMn2Y
def rfoi91Gyj64WCYJsvc(BJY0uVXCjPtIlLcwk3):
	NN8zxVFlX36Sw9yKdOEYAuQtTbo = repr(BJY0uVXCjPtIlLcwk3.encode(OVauxZzLI10vcXT74K)).replace(P0qdZI384LKleuo(u"ࠣࠩࠥຩ"),b8Qe150xVaJsnDSv)
	return NN8zxVFlX36Sw9yKdOEYAuQtTbo
def ZZN9Mjkl4wWy0OV5axfqz(Ye1AwJ9HngZ):
	oozdvH6erA1UpZTqDi3kmtMlsB = b8Qe150xVaJsnDSv
	if hDTluNxe7tCwrpqXHzdEcYRfbs: Ye1AwJ9HngZ = Ye1AwJ9HngZ.decode(OVauxZzLI10vcXT74K)
	from unicodedata import decomposition as XhvOTF0nH63MiUYz
	for l5l4GIwaxpiTsPE6nJkctNZXvAoRr in Ye1AwJ9HngZ:
		if   l5l4GIwaxpiTsPE6nJkctNZXvAoRr==BWNPxIG7vqdTy85pjHzUOrK3(u"ࡷࠪฦࠬສ"): iYMz6LboeJA7lPstu8HU2Vnf = Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠪࡠࡡࡻ࠰࠷࠴࠵ࠫຫ")
		elif l5l4GIwaxpiTsPE6nJkctNZXvAoRr==IjZbnrBJmM2N(u"ࡹࠬษࠧຬ"): iYMz6LboeJA7lPstu8HU2Vnf = TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠬࡢ࡜ࡶ࠲࠹࠶࠸࠭ອ")
		elif l5l4GIwaxpiTsPE6nJkctNZXvAoRr==Mmpr0o76iWJvz1kTtfgI8hES(u"ࡻࠧลࠩຮ"): iYMz6LboeJA7lPstu8HU2Vnf = QQdAXWBc2GPw(u"ࠧ࡝࡞ࡸ࠴࠻࠸࠴ࠨຯ")
		elif l5l4GIwaxpiTsPE6nJkctNZXvAoRr==zI3ROAZtiUq42rE9WDST68(u"ࡶࠩศࠫະ"): iYMz6LboeJA7lPstu8HU2Vnf = UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠩ࡟ࡠࡺ࠶࠶࠳࠷ࠪັ")
		elif l5l4GIwaxpiTsPE6nJkctNZXvAoRr==TYf7Dc06PQgy1vEV9(u"ࡸࠫห࠭າ"): iYMz6LboeJA7lPstu8HU2Vnf = LAQD5wEkr18bUiGaYen3J(u"ࠫࡡࡢࡵ࠱࠸࠵࠺ࠬຳ")
		else:
			VlSHUIMyLp0ra4fJZwtb7ERCABijx = XhvOTF0nH63MiUYz(l5l4GIwaxpiTsPE6nJkctNZXvAoRr)
			if pldxivXC5wbTB2O8q in VlSHUIMyLp0ra4fJZwtb7ERCABijx: iYMz6LboeJA7lPstu8HU2Vnf = P0qdZI384LKleuo(u"ࠬࡢ࡜ࡶࠩິ")+VlSHUIMyLp0ra4fJZwtb7ERCABijx.split(pldxivXC5wbTB2O8q,qHYIWnOZLPkrQU)[qHYIWnOZLPkrQU]
			else:
				iYMz6LboeJA7lPstu8HU2Vnf = Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"࠭࠰࠱࠲࠳ࠫີ")+hex(ord(l5l4GIwaxpiTsPE6nJkctNZXvAoRr)).replace(ddo23ZJtgcY(u"ࠧ࠱ࡺࠪຶ"),b8Qe150xVaJsnDSv)
				iYMz6LboeJA7lPstu8HU2Vnf = DYakr9g4PVU(u"ࠨ࡞࡟ࡹࠬື")+iYMz6LboeJA7lPstu8HU2Vnf[-NvHugPosYDzRJ:]
		oozdvH6erA1UpZTqDi3kmtMlsB += iYMz6LboeJA7lPstu8HU2Vnf
	oozdvH6erA1UpZTqDi3kmtMlsB = oozdvH6erA1UpZTqDi3kmtMlsB.replace(DYakr9g4PVU(u"ࠩ࡟ࡠࡺ࠶࠶ࡄࡅຸࠪ"),VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠪࡠࡡࡻ࠰࠷࠶࠼ູࠫ"))
	if hDTluNxe7tCwrpqXHzdEcYRfbs: oozdvH6erA1UpZTqDi3kmtMlsB = oozdvH6erA1UpZTqDi3kmtMlsB.decode(uVQd103XyvUce2EBtzbYaC(u"ࠫࡺࡴࡩࡤࡱࡧࡩࡤ࡫ࡳࡤࡣࡳࡩ຺ࠬ")).encode(OVauxZzLI10vcXT74K)
	else: oozdvH6erA1UpZTqDi3kmtMlsB = oozdvH6erA1UpZTqDi3kmtMlsB.encode(OVauxZzLI10vcXT74K).decode(ubxGUTt1LraKhVZgpAP(u"ࠬࡻ࡮ࡪࡥࡲࡨࡪࡥࡥࡴࡥࡤࡴࡪ࠭ົ"))
	return oozdvH6erA1UpZTqDi3kmtMlsB
def FT2oXWtPQpVGuexmLqKN3srdzYn(header=QTUBCcehw6qPd4x(u"࠭ไ้ฯฬࠤฬ๊ๅโษอ๎า࠭ຼ"),ffYFzrCS3UOxjkybwQ1cXeB6oIlVp=b8Qe150xVaJsnDSv,asiWfp7bSPXJkdrZw=DD5cFIejQa2X4BgAu9GWPyJ3tC7,source=b8Qe150xVaJsnDSv):
	vv5M4UfJS9ucKEiNbxtnaOZ = hyG0olqQfw(header,ffYFzrCS3UOxjkybwQ1cXeB6oIlVp,type=evil9I2DnLJcy8.INPUT_ALPHANUM)
	vv5M4UfJS9ucKEiNbxtnaOZ = vv5M4UfJS9ucKEiNbxtnaOZ.strip(pldxivXC5wbTB2O8q).replace(eiopkn4y9uWDQ5,pldxivXC5wbTB2O8q).replace(R1BKXhzpGH6CoO9jLsPwQWu,pldxivXC5wbTB2O8q).replace(k5bCDErUSmv,pldxivXC5wbTB2O8q)
	if not vv5M4UfJS9ucKEiNbxtnaOZ and not asiWfp7bSPXJkdrZw:
		mwIxD3GBPgLVc2aq9(MtTygrzXFlQ,Nh0BWuiSndf(u"ࠧ࠯࡞ࡷࡏࡪࡿࡢࡰࡣࡵࡨࠥ࡫࡮ࡵࡴࡼࠤࡨࡧ࡮ࡤࡧ࡯ࡩࡩࡀࠠࠡࠢࠥࠫຽ")+vv5M4UfJS9ucKEiNbxtnaOZ+QTUBCcehw6qPd4x(u"ࠨࠤࠪ຾"))
		tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,BmePGjS7FxK6kutUM(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ຿"),SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠪฮ๊ࠦลๅ฼สลࠥอไฦััห้࠭ເ"))
		return b8Qe150xVaJsnDSv
	if vv5M4UfJS9ucKEiNbxtnaOZ not in [b8Qe150xVaJsnDSv,pldxivXC5wbTB2O8q]:
		vv5M4UfJS9ucKEiNbxtnaOZ = vv5M4UfJS9ucKEiNbxtnaOZ.strip(pldxivXC5wbTB2O8q)
		vv5M4UfJS9ucKEiNbxtnaOZ = ZZN9Mjkl4wWy0OV5axfqz(vv5M4UfJS9ucKEiNbxtnaOZ)
	if source!=ubxGUTt1LraKhVZgpAP(u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠭ແ") and vvIMS2DeraLfJ(VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠬࡑࡅ࡚ࡄࡒࡅࡗࡊࠧໂ"),b8Qe150xVaJsnDSv,[vv5M4UfJS9ucKEiNbxtnaOZ],DD5cFIejQa2X4BgAu9GWPyJ3tC7):
		mwIxD3GBPgLVc2aq9(MtTygrzXFlQ,LAQD5wEkr18bUiGaYen3J(u"࠭࠮࡝ࡶࡎࡩࡾࡨ࡯ࡢࡴࡧࠤࡪࡴࡴࡳࡻࠣࡦࡱࡵࡣ࡬ࡧࡧ࠾ࠥࠦࠠࠣࠩໃ")+vv5M4UfJS9ucKEiNbxtnaOZ+BWNPxIG7vqdTy85pjHzUOrK3(u"ࠧࠣࠩໄ"))
		tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,QQdAXWBc2GPw(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ໅"),DYakr9g4PVU(u"ࠩส๊ฯࠦใหสอࠤ่๊ๅสࠢฦ์ࠥืโๆࠢ็๋ࠥ฿ไศไฬࠤอษแๅษ่ࠤ้๊ใษษิࠤๆ่ืࠡ࠰࠱ࠤํํะศࠢส่อืๆศ็ฯࠤ้อ๋ࠠี่ัࠥฮวิฬัำฬ๋่ࠠๅำห้ࠥไๆษอࠫໆ"))
		return b8Qe150xVaJsnDSv
	mwIxD3GBPgLVc2aq9(MtTygrzXFlQ,TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠪ࠲ࡡࡺࡋࡦࡻࡥࡳࡦࡸࡤࠡࡧࡱࡸࡷࡿࠠࡢ࡮࡯ࡳࡼ࡫ࡤ࠻ࠢࠣࠤࠧ࠭໇")+vv5M4UfJS9ucKEiNbxtnaOZ+RRIHDFjoW9w7bSfVPhC(u"່ࠫࠧ࠭"))
	return vv5M4UfJS9ucKEiNbxtnaOZ
def TTO3ZpWq9FCzhuMAY0RdaDIfX5kw(QQ8pvXNcBfVkP5rRJ7o,MUJCtfYVBLODrFbaZn,ybF0H85nUohsiRQcpaTfZAKzjMY7wB={}):
	YabJfs3q7yjpzvXioO,AcE0eVRrXbsL1W2go4upkYCHimK,PBiZSbtjJUDqhmn72Wf4Cw,qdIxtyvYoc7V = MUJCtfYVBLODrFbaZn,{},{},b8Qe150xVaJsnDSv
	if BmePGjS7FxK6kutUM(u"ࠬࢂ້ࠧ") in MUJCtfYVBLODrFbaZn: YabJfs3q7yjpzvXioO,AcE0eVRrXbsL1W2go4upkYCHimK = FNIhDd4uLfev0q5YHVGx8oWm6CsiJ(MUJCtfYVBLODrFbaZn,QTUBCcehw6qPd4x(u"࠭ࡼࠨ໊"))
	rrDFsRmShziH4LJXWg7bxoG = list(set(list(ybF0H85nUohsiRQcpaTfZAKzjMY7wB.keys())+list(AcE0eVRrXbsL1W2go4upkYCHimK.keys())))
	for bb0cYXjevHNo8ZLE7CyrBzWAl9wus in rrDFsRmShziH4LJXWg7bxoG:
		if bb0cYXjevHNo8ZLE7CyrBzWAl9wus in list(AcE0eVRrXbsL1W2go4upkYCHimK.keys()): PBiZSbtjJUDqhmn72Wf4Cw[bb0cYXjevHNo8ZLE7CyrBzWAl9wus] = AcE0eVRrXbsL1W2go4upkYCHimK[bb0cYXjevHNo8ZLE7CyrBzWAl9wus]
		else: PBiZSbtjJUDqhmn72Wf4Cw[bb0cYXjevHNo8ZLE7CyrBzWAl9wus] = ybF0H85nUohsiRQcpaTfZAKzjMY7wB[bb0cYXjevHNo8ZLE7CyrBzWAl9wus]
	if dDYUoKi6JFM23p(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷ໋ࠫ") not in rrDFsRmShziH4LJXWg7bxoG: PBiZSbtjJUDqhmn72Wf4Cw[mQNonhS7CV2BXOv(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ໌")] = kIMmsSG9NW6BOjlTpnEcuRzgwK()
	if yST5AHEfvPmcWpwGuh2BJ(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪໍ") not in rrDFsRmShziH4LJXWg7bxoG: PBiZSbtjJUDqhmn72Wf4Cw[TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ໎")] = Wl2eu1PavfQ(YabJfs3q7yjpzvXioO,IjZbnrBJmM2N(u"ࠫࡺࡸ࡬ࠨ໏"))
	if BmePGjS7FxK6kutUM(u"ࠬࡇࡣࡤࡧࡳࡸ࠲ࡒࡡ࡯ࡩࡸࡥ࡬࡫ࠧ໐") not in rrDFsRmShziH4LJXWg7bxoG: PBiZSbtjJUDqhmn72Wf4Cw[UUkIBz1sgQ9WfNeG6trKXvu0(u"࠭ࡁࡤࡥࡨࡴࡹ࠳ࡌࡢࡰࡪࡹࡦ࡭ࡥࠨ໑")] = m6hwdgP31a2zjN7lkpX(u"ࠧࡦࡰ࠰࡙ࡘ࠲ࡥ࡯࠽ࡴࡁ࠵࠴࠹ࠨ໒")
	for bb0cYXjevHNo8ZLE7CyrBzWAl9wus in list(PBiZSbtjJUDqhmn72Wf4Cw.keys()): qdIxtyvYoc7V += S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠨࠨࠪ໓")+bb0cYXjevHNo8ZLE7CyrBzWAl9wus+Mmpr0o76iWJvz1kTtfgI8hES(u"ࠩࡀࠫ໔")+PBiZSbtjJUDqhmn72Wf4Cw[bb0cYXjevHNo8ZLE7CyrBzWAl9wus]
	if qdIxtyvYoc7V: qdIxtyvYoc7V = DYakr9g4PVU(u"ࠪࢀࠬ໕")+qdIxtyvYoc7V[qHYIWnOZLPkrQU:]
	Ci4rQ0qV915j2AIkHTbcy = dcLRAZWFzODax2jf0tHCX81pJveNY(IiYS8Jg4da3UuDP0qr6vy,zI3ROAZtiUq42rE9WDST68(u"ࠫࡌࡋࡔࠨ໖"),YabJfs3q7yjpzvXioO,b8Qe150xVaJsnDSv,PBiZSbtjJUDqhmn72Wf4Cw,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,zI3ROAZtiUq42rE9WDST68(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡅ࡙ࡖࡕࡅࡈ࡚࡟ࡎ࠵ࡘ࠼࠲࠷ࡳࡵࠩ໗"),DD5cFIejQa2X4BgAu9GWPyJ3tC7,DD5cFIejQa2X4BgAu9GWPyJ3tC7)
	oH3N1dY9vLpaDJfnTVP5Z7q = Ci4rQ0qV915j2AIkHTbcy.content
	if Nh0BWuiSndf(u"࠭ࡓࡕࡔࡈࡅࡒ࠳ࡉࡏࡈࠪ໘") not in oH3N1dY9vLpaDJfnTVP5Z7q: return [vvWwO3Tx2dAgcijrFXq(u"ࠧ࠮࠳ࠪ໙")],[YabJfs3q7yjpzvXioO+qdIxtyvYoc7V]
	if UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠨࡖ࡜ࡔࡊࡃࡁࡖࡆࡌࡓࠬ໚") in oH3N1dY9vLpaDJfnTVP5Z7q: return [VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠩ࠰࠵ࠬ໛")],[YabJfs3q7yjpzvXioO+qdIxtyvYoc7V]
	if P0qdZI384LKleuo(u"ࠪࡘ࡞ࡖࡅ࠾ࡘࡌࡈࡊࡕࠧໜ") in oH3N1dY9vLpaDJfnTVP5Z7q: return [Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠫ࠲࠷ࠧໝ")],[YabJfs3q7yjpzvXioO+qdIxtyvYoc7V]
	uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j,YX5UFLKNn62cfRIs3PrlgTuj0Oqb81,PUCfw3Gcs1Y = [],[],[],[]
	bCoNUQ3TXW7un = YYBlm36zd0Jst18LXwo4.findall(shC5qBRV2A0lZ(u"ࠬࠩࡅ࡙ࡖ࠰࡜࠲࡙ࡔࡓࡇࡄࡑ࠲ࡏࡎࡇ࠼ࠫ࠲࠯ࡅࠩ࡜࡞ࡵࡠࡳࡣࠫࠩ࠰࠭ࡃ࠮ࡡ࡜ࡳ࡞ࡱࡡ࠰࠭ໞ"),oH3N1dY9vLpaDJfnTVP5Z7q+eeN6dTEnkJxI,YYBlm36zd0Jst18LXwo4.DOTALL)
	if not bCoNUQ3TXW7un: return [shC5qBRV2A0lZ(u"࠭࠭࠲ࠩໟ")],[YabJfs3q7yjpzvXioO+qdIxtyvYoc7V]
	for Xfu41hHADW36e5FkU,rM6EVzvpbh3HUPu in bCoNUQ3TXW7un:
		VnK8YZAlUJimoRQOsqtW7w4GcC3Xve,F8Ef6K7kCy9mbQPx,c1EdszLx3mkb8QYX9 = {},-HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"࠵ᑎ"),-HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"࠵ᑎ")
		BlWNeEaRX41k = b8Qe150xVaJsnDSv
		HRtPG93S8F10idLOAas4q5jnVxf = Xfu41hHADW36e5FkU.split(vvWwO3Tx2dAgcijrFXq(u"ࠧ࠭ࠩ໠"))
		for QpHl0Efc7yvn2V in HRtPG93S8F10idLOAas4q5jnVxf:
			if HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠨ࠿ࠪ໡") in QpHl0Efc7yvn2V:
				bb0cYXjevHNo8ZLE7CyrBzWAl9wus,ehwRMsq9br8P72Bj3mnlOCY0JXvWFc = QpHl0Efc7yvn2V.split(Mmpr0o76iWJvz1kTtfgI8hES(u"ࠩࡀࠫ໢"),mQNonhS7CV2BXOv(u"࠶ᑏ"))
				VnK8YZAlUJimoRQOsqtW7w4GcC3Xve[bb0cYXjevHNo8ZLE7CyrBzWAl9wus.lower()] = ehwRMsq9br8P72Bj3mnlOCY0JXvWFc
		if QTUBCcehw6qPd4x(u"ࠪࡥࡻ࡫ࡲࡢࡩࡨ࠱ࡧࡧ࡮ࡥࡹ࡬ࡨࡹ࡮ࠧ໣") in Xfu41hHADW36e5FkU.lower():
			F8Ef6K7kCy9mbQPx = int(VnK8YZAlUJimoRQOsqtW7w4GcC3Xve[RRIHDFjoW9w7bSfVPhC(u"ࠫࡦࡼࡥࡳࡣࡪࡩ࠲ࡨࡡ࡯ࡦࡺ࡭ࡩࡺࡨࠨ໤")])//kke1PDGRBLuY8y(u"࠷࠰࠳࠶ᑐ")
			BlWNeEaRX41k += str(F8Ef6K7kCy9mbQPx)+BmePGjS7FxK6kutUM(u"ࠬࡱࡢࡱࡵࠣࠤࠬ໥")
		elif ddo23ZJtgcY(u"࠭ࡢࡢࡰࡧࡻ࡮ࡪࡴࡩࠩ໦") in Xfu41hHADW36e5FkU.lower():
			F8Ef6K7kCy9mbQPx = int(VnK8YZAlUJimoRQOsqtW7w4GcC3Xve[shC5qBRV2A0lZ(u"ࠧࡣࡣࡱࡨࡼ࡯ࡤࡵࡪࠪ໧")])//QTUBCcehw6qPd4x(u"࠱࠱࠴࠷ᑑ")
			BlWNeEaRX41k += str(F8Ef6K7kCy9mbQPx)+VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠨ࡭ࡥࡴࡸࠦࠠࠨ໨")
		if Mmpr0o76iWJvz1kTtfgI8hES(u"ࠩࡵࡩࡸࡵ࡬ࡶࡶ࡬ࡳࡳ࠭໩") in Xfu41hHADW36e5FkU.lower():
			c1EdszLx3mkb8QYX9 = int(VnK8YZAlUJimoRQOsqtW7w4GcC3Xve[ddo23ZJtgcY(u"ࠪࡶࡪࡹ࡯࡭ࡷࡷ࡭ࡴࡴࠧ໪")].split(dDYUoKi6JFM23p(u"ࠫࡽ࠭໫"))[qHYIWnOZLPkrQU])
			BlWNeEaRX41k += str(c1EdszLx3mkb8QYX9)+k5bCDErUSmv
		BlWNeEaRX41k = BlWNeEaRX41k.strip(k5bCDErUSmv)
		if not BlWNeEaRX41k: BlWNeEaRX41k = kke1PDGRBLuY8y(u"࡛ࠬ࡮࡬ࡰࡲࡻࡳ࠭໬")
		if not rM6EVzvpbh3HUPu.startswith(P0qdZI384LKleuo(u"࠭ࡨࡵࡶࡳࠫ໭")):
			if rM6EVzvpbh3HUPu.startswith(DYakr9g4PVU(u"ࠧ࠰࠱ࠪ໮")): rM6EVzvpbh3HUPu = YabJfs3q7yjpzvXioO.split(zI3ROAZtiUq42rE9WDST68(u"ࠨ࠼ࠪ໯"),qHYIWnOZLPkrQU)[LzYQg91SIxDeOGtCKd5]+mQNonhS7CV2BXOv(u"ࠩ࠽ࠫ໰")+rM6EVzvpbh3HUPu
			elif rM6EVzvpbh3HUPu.startswith(Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠪ࠳ࠬ໱")): rM6EVzvpbh3HUPu = Wl2eu1PavfQ(YabJfs3q7yjpzvXioO,vvWwO3Tx2dAgcijrFXq(u"ࠫࡺࡸ࡬ࠨ໲"))+rM6EVzvpbh3HUPu
			else: rM6EVzvpbh3HUPu = YabJfs3q7yjpzvXioO.rsplit(yST5AHEfvPmcWpwGuh2BJ(u"ࠬ࠵ࠧ໳"),qHYIWnOZLPkrQU)[LzYQg91SIxDeOGtCKd5]+Xz3bA2PFENVCUtplu51(u"࠭࠯ࠨ໴")+rM6EVzvpbh3HUPu
		if mQNonhS7CV2BXOv(u"ࠧࡱࡴࡲ࡫ࡷ࡫ࡳࡴ࡫ࡹࡩ࠲ࡻࡲࡪࠩ໵") in list(VnK8YZAlUJimoRQOsqtW7w4GcC3Xve.keys()):
			eiFs3pQPyZtjb0W = VnK8YZAlUJimoRQOsqtW7w4GcC3Xve[TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠨࡲࡵࡳ࡬ࡸࡥࡴࡵ࡬ࡺࡪ࠳ࡵࡳ࡫ࠪ໶")]
			eiFs3pQPyZtjb0W = eiFs3pQPyZtjb0W.replace(P0qdZI384LKleuo(u"ࠩࠥࠫ໷"),b8Qe150xVaJsnDSv).replace(dDYUoKi6JFM23p(u"ࠥࠫࠧ໸"),b8Qe150xVaJsnDSv).split(SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠫࠨ࠭໹"),qHYIWnOZLPkrQU)[LzYQg91SIxDeOGtCKd5]
			xZds9ITEWatF7Kb = Gz7MH0glBw8Eb(eiFs3pQPyZtjb0W)
			if xZds9ITEWatF7Kb: HoXz65T8ph1CMeZgF = BlWNeEaRX41k+k5bCDErUSmv+xZds9ITEWatF7Kb
			else: HoXz65T8ph1CMeZgF = BlWNeEaRX41k
			HoXz65T8ph1CMeZgF = HoXz65T8ph1CMeZgF+kke1PDGRBLuY8y(u"ࠬࠦࠠࡑࡴࡲ࡫ࡷ࡫ࡳࡴ࡫ࡹࡩࠬ໺")
			HoXz65T8ph1CMeZgF = HoXz65T8ph1CMeZgF+k5bCDErUSmv+Wl2eu1PavfQ(eiFs3pQPyZtjb0W,HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"࠭࡮ࡢ࡯ࡨࠫ໻"))
			uuSKUinvP4EGLxWZYmTsF.append(HoXz65T8ph1CMeZgF)
			KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j.append(eiFs3pQPyZtjb0W)
			YX5UFLKNn62cfRIs3PrlgTuj0Oqb81.append(c1EdszLx3mkb8QYX9)
			PUCfw3Gcs1Y.append(F8Ef6K7kCy9mbQPx)
		rM6EVzvpbh3HUPu = rM6EVzvpbh3HUPu.split(VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠧࠤࠩ໼"),qHYIWnOZLPkrQU)[LzYQg91SIxDeOGtCKd5]
		xZds9ITEWatF7Kb = Gz7MH0glBw8Eb(rM6EVzvpbh3HUPu)
		if xZds9ITEWatF7Kb: BlWNeEaRX41k = BlWNeEaRX41k+k5bCDErUSmv+xZds9ITEWatF7Kb
		BlWNeEaRX41k = BlWNeEaRX41k+k5bCDErUSmv+Wl2eu1PavfQ(rM6EVzvpbh3HUPu,DYakr9g4PVU(u"ࠨࡰࡤࡱࡪ࠭໽"))
		uuSKUinvP4EGLxWZYmTsF.append(BlWNeEaRX41k)
		KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j.append(rM6EVzvpbh3HUPu)
		YX5UFLKNn62cfRIs3PrlgTuj0Oqb81.append(c1EdszLx3mkb8QYX9)
		PUCfw3Gcs1Y.append(F8Ef6K7kCy9mbQPx)
	TJuDfURKbI6MynChiEXqAYQS4d58j = list(zip(uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j,YX5UFLKNn62cfRIs3PrlgTuj0Oqb81,PUCfw3Gcs1Y))
	TJuDfURKbI6MynChiEXqAYQS4d58j = sorted(TJuDfURKbI6MynChiEXqAYQS4d58j, reverse=CCxMXuNUEzolDZTKrBJ, key=lambda key: key[VwApyDY1Jc])
	uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j,YX5UFLKNn62cfRIs3PrlgTuj0Oqb81,PUCfw3Gcs1Y = list(zip(*TJuDfURKbI6MynChiEXqAYQS4d58j))
	uuSKUinvP4EGLxWZYmTsF,KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = list(uuSKUinvP4EGLxWZYmTsF),list(KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j)
	BB6xwqVdZC13JQPujR2sUtz = []
	for rM6EVzvpbh3HUPu in KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j: BB6xwqVdZC13JQPujR2sUtz.append(rM6EVzvpbh3HUPu+qdIxtyvYoc7V)
	Pqlk63Vse8RUBr4hMLoI9EmKfNaOp = list(zip(BB6xwqVdZC13JQPujR2sUtz,[mQNonhS7CV2BXOv(u"ࠩࡧࡹࡲࡳࡹࠨ໾")]*len(BB6xwqVdZC13JQPujR2sUtz),PUCfw3Gcs1Y))
	clTRovD5CnKjMBa7e92 = NBzFpYl7jSk(QQ8pvXNcBfVkP5rRJ7o,Pqlk63Vse8RUBr4hMLoI9EmKfNaOp)
	if clTRovD5CnKjMBa7e92:
		pcA1dzy7LXwGfMPg9mTkuh5tine3,jprAaOYCD6yM8P5VZXK1B2ldNbuR,F8Ef6K7kCy9mbQPx = clTRovD5CnKjMBa7e92[QTUBCcehw6qPd4x(u"࠱ᑒ")]
		index = BB6xwqVdZC13JQPujR2sUtz.index(pcA1dzy7LXwGfMPg9mTkuh5tine3)
		title = uuSKUinvP4EGLxWZYmTsF[index]
		uuSKUinvP4EGLxWZYmTsF,BB6xwqVdZC13JQPujR2sUtz = [title],[pcA1dzy7LXwGfMPg9mTkuh5tine3]
	return uuSKUinvP4EGLxWZYmTsF,BB6xwqVdZC13JQPujR2sUtz
def ppyKRhnr3doQ9P5HlMTSCveNu1(UdnYNWKeIaopPXDl2ArM3VkyR49S1,ahDrn9Jebl7mgKQB8vxVGOqPTk=b8Qe150xVaJsnDSv):
	if not ahDrn9Jebl7mgKQB8vxVGOqPTk: ahDrn9Jebl7mgKQB8vxVGOqPTk = aZN3l1t6JE4oPmpkzLQSW5[LzYQg91SIxDeOGtCKd5]
	if UdnYNWKeIaopPXDl2ArM3VkyR49S1.replace(vvWwO3Tx2dAgcijrFXq(u"ࠪ࠲ࠬ໿"),b8Qe150xVaJsnDSv).isdigit(): return [UdnYNWKeIaopPXDl2ArM3VkyR49S1]
	from struct import pack as CIgP8ZvyWFDULb,unpack_from as N7jpRsT20KeM48uw
	from socket import socket as EvmDR2G3dP7Hbexu1,AF_INET as S4TFcnYvxCGyBa1ZReLUD6srzI,SOCK_DGRAM as LfNjUXDeH9IT0wC1aq6lr4YpbmB2c
	try:
		B1dcUIqhR7yaC82XHPozbsu = CIgP8ZvyWFDULb(Mmpr0o76iWJvz1kTtfgI8hES(u"ࠦࡃࡎࠢༀ"), zI3ROAZtiUq42rE9WDST68(u"࠳࠵࠴࠹࠿ᑓ"))
		B1dcUIqhR7yaC82XHPozbsu += CIgP8ZvyWFDULb(S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠧࡄࡈࠣ༁"), Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"࠵࠹࠻ᑔ"))
		B1dcUIqhR7yaC82XHPozbsu += CIgP8ZvyWFDULb(TYf7Dc06PQgy1vEV9(u"ࠨ࠾ࡉࠤ༂"), qHYIWnOZLPkrQU)
		B1dcUIqhR7yaC82XHPozbsu += CIgP8ZvyWFDULb(P0qdZI384LKleuo(u"ࠢ࠿ࡊࠥ༃"), LzYQg91SIxDeOGtCKd5)
		B1dcUIqhR7yaC82XHPozbsu += CIgP8ZvyWFDULb(TYf7Dc06PQgy1vEV9(u"ࠣࡀࡋࠦ༄"), LzYQg91SIxDeOGtCKd5)
		B1dcUIqhR7yaC82XHPozbsu += CIgP8ZvyWFDULb(QQdAXWBc2GPw(u"ࠤࡁࡌࠧ༅"), LzYQg91SIxDeOGtCKd5)
		if i1thmHk7AZquD4cM0fnp62: aXK419CtBoSO58vq0rE6pDxGkzi = UdnYNWKeIaopPXDl2ArM3VkyR49S1.split(Mmpr0o76iWJvz1kTtfgI8hES(u"ࠪ࠲ࠬ༆"))
		else: aXK419CtBoSO58vq0rE6pDxGkzi = UdnYNWKeIaopPXDl2ArM3VkyR49S1.decode(OVauxZzLI10vcXT74K).split(mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠫ࠳࠭༇"))
		for fjKi8zxBwRmM7ElcCQUA in aXK419CtBoSO58vq0rE6pDxGkzi:
			O6zhET172b8nKmsjVBLcRwZXkoUpD = fjKi8zxBwRmM7ElcCQUA.encode(OVauxZzLI10vcXT74K)
			B1dcUIqhR7yaC82XHPozbsu += CIgP8ZvyWFDULb(zI3ROAZtiUq42rE9WDST68(u"ࠧࡈࠢ༈"), len(fjKi8zxBwRmM7ElcCQUA))
			for uORV0Bt2ZwvMreo4yxl3jPGQY57CaJ in fjKi8zxBwRmM7ElcCQUA:
				B1dcUIqhR7yaC82XHPozbsu += CIgP8ZvyWFDULb(UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠨࡣࠣ༉"), uORV0Bt2ZwvMreo4yxl3jPGQY57CaJ.encode(OVauxZzLI10vcXT74K))
		B1dcUIqhR7yaC82XHPozbsu += CIgP8ZvyWFDULb(Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠢࡃࠤ༊"), LzYQg91SIxDeOGtCKd5)
		B1dcUIqhR7yaC82XHPozbsu += CIgP8ZvyWFDULb(TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠣࡀࡋࠦ་"), qHYIWnOZLPkrQU)
		B1dcUIqhR7yaC82XHPozbsu += CIgP8ZvyWFDULb(ubxGUTt1LraKhVZgpAP(u"ࠤࡁࡌࠧ༌"), qHYIWnOZLPkrQU)
		Ug2Q9mh48vTHRyLSXzEeKVb135klq = EvmDR2G3dP7Hbexu1(S4TFcnYvxCGyBa1ZReLUD6srzI,LfNjUXDeH9IT0wC1aq6lr4YpbmB2c)
		Ug2Q9mh48vTHRyLSXzEeKVb135klq.sendto(bytes(B1dcUIqhR7yaC82XHPozbsu), (ahDrn9Jebl7mgKQB8vxVGOqPTk, LAQD5wEkr18bUiGaYen3J(u"࠹࠸ᑕ")))
		Ug2Q9mh48vTHRyLSXzEeKVb135klq.settimeout(Xz3bA2PFENVCUtplu51(u"࠻ᑖ"))
		kTSyagGWsFnolYhMO5fCwvpNuPqR, Ca32GX1lJ8 = Ug2Q9mh48vTHRyLSXzEeKVb135klq.recvfrom(kke1PDGRBLuY8y(u"࠷࠰࠳࠶ᑗ"))
		Ug2Q9mh48vTHRyLSXzEeKVb135klq.close()
		bWioH4M1jdl2UgBq9XIzfeKku = N7jpRsT20KeM48uw(mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠥࡂࡍࡎࡈࡉࡊࡋࠦ།"), kTSyagGWsFnolYhMO5fCwvpNuPqR, LzYQg91SIxDeOGtCKd5)
		tn9hq0ScF75jm8YikUI6PC = bWioH4M1jdl2UgBq9XIzfeKku[VwApyDY1Jc]
		UQ2BHA0kupJ1ElnTvD4iF = len(UdnYNWKeIaopPXDl2ArM3VkyR49S1)+yST5AHEfvPmcWpwGuh2BJ(u"࠱࠹ᑘ")
		PPTURnwu345Xji = []
		for _zjsVfEJdkQP in range(tn9hq0ScF75jm8YikUI6PC):
			F9twoRLeYuSBzNakndjKcpql = UQ2BHA0kupJ1ElnTvD4iF
			P9BqgS2b4ivCoDTtNkcR = qHYIWnOZLPkrQU
			Et3uGDpfr2P = DD5cFIejQa2X4BgAu9GWPyJ3tC7
			while CCxMXuNUEzolDZTKrBJ:
				uORV0Bt2ZwvMreo4yxl3jPGQY57CaJ = N7jpRsT20KeM48uw(LAQD5wEkr18bUiGaYen3J(u"ࠦࡃࡈࠢ༎"), kTSyagGWsFnolYhMO5fCwvpNuPqR, F9twoRLeYuSBzNakndjKcpql)[LzYQg91SIxDeOGtCKd5]
				if uORV0Bt2ZwvMreo4yxl3jPGQY57CaJ == LzYQg91SIxDeOGtCKd5:
					F9twoRLeYuSBzNakndjKcpql += qHYIWnOZLPkrQU
					break
				if uORV0Bt2ZwvMreo4yxl3jPGQY57CaJ >= m6hwdgP31a2zjN7lkpX(u"࠲࠻࠵ᑙ"):
					TJ3CYzQIypM6 = N7jpRsT20KeM48uw(TYf7Dc06PQgy1vEV9(u"ࠧࡄࡂࠣ༏"), kTSyagGWsFnolYhMO5fCwvpNuPqR, F9twoRLeYuSBzNakndjKcpql + qHYIWnOZLPkrQU)[LzYQg91SIxDeOGtCKd5]
					F9twoRLeYuSBzNakndjKcpql = ((uORV0Bt2ZwvMreo4yxl3jPGQY57CaJ << RRIHDFjoW9w7bSfVPhC(u"࠺ᑚ")) + TJ3CYzQIypM6 - 0xc000) - qHYIWnOZLPkrQU
					Et3uGDpfr2P = CCxMXuNUEzolDZTKrBJ
				F9twoRLeYuSBzNakndjKcpql += qHYIWnOZLPkrQU
				if Et3uGDpfr2P == DD5cFIejQa2X4BgAu9GWPyJ3tC7: P9BqgS2b4ivCoDTtNkcR += qHYIWnOZLPkrQU
			if Et3uGDpfr2P == CCxMXuNUEzolDZTKrBJ: P9BqgS2b4ivCoDTtNkcR += qHYIWnOZLPkrQU
			UQ2BHA0kupJ1ElnTvD4iF = UQ2BHA0kupJ1ElnTvD4iF + P9BqgS2b4ivCoDTtNkcR
			CZ4KH9v1x0EgJ7k3RiOw8udQ = N7jpRsT20KeM48uw(mQNonhS7CV2BXOv(u"ࠨ࠾ࡉࡊࡌࡌࠧ༐"), kTSyagGWsFnolYhMO5fCwvpNuPqR, UQ2BHA0kupJ1ElnTvD4iF)
			UQ2BHA0kupJ1ElnTvD4iF = UQ2BHA0kupJ1ElnTvD4iF + ddo23ZJtgcY(u"࠴࠴ᑛ")
			efi4ZKmrcS7NEQXgMJ = CZ4KH9v1x0EgJ7k3RiOw8udQ[LzYQg91SIxDeOGtCKd5]
			riU4ZaPz0y6JYs7c = CZ4KH9v1x0EgJ7k3RiOw8udQ[VwApyDY1Jc]
			if efi4ZKmrcS7NEQXgMJ == qHYIWnOZLPkrQU:
				K2IbDWjJpNVzu = N7jpRsT20KeM48uw(QTUBCcehw6qPd4x(u"ࠢ࠿ࠤ༑")+S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠣࡄࠥ༒")*riU4ZaPz0y6JYs7c, kTSyagGWsFnolYhMO5fCwvpNuPqR, UQ2BHA0kupJ1ElnTvD4iF)
				ip = b8Qe150xVaJsnDSv
				for uORV0Bt2ZwvMreo4yxl3jPGQY57CaJ in K2IbDWjJpNVzu: ip += str(uORV0Bt2ZwvMreo4yxl3jPGQY57CaJ) + m6hwdgP31a2zjN7lkpX(u"ࠩ࠱ࠫ༓")
				ip = ip[LzYQg91SIxDeOGtCKd5:-qHYIWnOZLPkrQU]
				PPTURnwu345Xji.append(ip)
			if efi4ZKmrcS7NEQXgMJ in [qHYIWnOZLPkrQU,IgQimel18t,S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"࠻ᑞ"),S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"࠶ᑟ"),kke1PDGRBLuY8y(u"࠶࠻ᑝ"),m6hwdgP31a2zjN7lkpX(u"࠶࠽ᑜ")]: UQ2BHA0kupJ1ElnTvD4iF = UQ2BHA0kupJ1ElnTvD4iF + riU4ZaPz0y6JYs7c
	except: PPTURnwu345Xji = []
	if not PPTURnwu345Xji: mwIxD3GBPgLVc2aq9(WG2BfeyzMa,EECz06teoykrNFfq(QQ8pvXNcBfVkP5rRJ7o)+uVQd103XyvUce2EBtzbYaC(u"ࠪࠤࠥࠦࡄࡏࡕࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࠥ࡬ࡡࡪ࡮ࡨࡨࠥࠦࠠࡉࡱࡶࡸ࠿࡛ࠦࠡࠩ༔")+UdnYNWKeIaopPXDl2ArM3VkyR49S1+TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠫࠥࡣࠧ༕"))
	return PPTURnwu345Xji
def vvIMS2DeraLfJ(QQ8pvXNcBfVkP5rRJ7o,YabJfs3q7yjpzvXioO,EQUkgc3PLy5mhBiZINJ0HO1A6,showDialogs=CCxMXuNUEzolDZTKrBJ):
	if EQUkgc3PLy5mhBiZINJ0HO1A6:
		rrzbL5xgHsokD2N3 = [IjZbnrBJmM2N(u"้ࠬศศำࠪ༖"),DYakr9g4PVU(u"࠭ศศๆ฽ࠫ༗"),RRIHDFjoW9w7bSfVPhC(u"ࠧࡢࡦࡸࡰࡹ༘࠭"),SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠨࡺࡻ༙ࠫ"),HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠩࡶࡩࡽ࠭༚")]
		if QQ8pvXNcBfVkP5rRJ7o!=IjZbnrBJmM2N(u"ࠪࡆࡔࡑࡒࡂࠩ༛"):
			rrzbL5xgHsokD2N3 += [LAQD5wEkr18bUiGaYen3J(u"ࠫࡷࡀࠧ༜"),P0qdZI384LKleuo(u"ࠬࡸ࠭ࠨ༝"),S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"࠭࠭࡮ࡣࠪ༞")]
			rrzbL5xgHsokD2N3 += [m6hwdgP31a2zjN7lkpX(u"ࠧ࠻ࡴࠪ༟"),Mmpr0o76iWJvz1kTtfgI8hES(u"ࠨ࠯ࡵࠫ༠"),shC5qBRV2A0lZ(u"ࠩࡰࡥ࠲࠭༡")]
		for EmQx8sbva1tHfNu79Oe3Ploh0gX in EQUkgc3PLy5mhBiZINJ0HO1A6:
			if ddo23ZJtgcY(u"ࠪ࡫ࡪࡺ࠮ࡱࡪࡳࡃࠬ༢") in EmQx8sbva1tHfNu79Oe3Ploh0gX: continue
			if BmePGjS7FxK6kutUM(u"ࠫา๊โสࠩ༣") in EmQx8sbva1tHfNu79Oe3Ploh0gX: continue
			EmQx8sbva1tHfNu79Oe3Ploh0gX = EmQx8sbva1tHfNu79Oe3Ploh0gX.lower()
			if hDTluNxe7tCwrpqXHzdEcYRfbs: EmQx8sbva1tHfNu79Oe3Ploh0gX = EmQx8sbva1tHfNu79Oe3Ploh0gX.decode(OVauxZzLI10vcXT74K).encode(OVauxZzLI10vcXT74K)
			EmQx8sbva1tHfNu79Oe3Ploh0gX = EmQx8sbva1tHfNu79Oe3Ploh0gX.replace(mQNonhS7CV2BXOv(u"ࠬࡀࠧ༤"),b8Qe150xVaJsnDSv)
			KnClvL5AZ7z4rGtMVj2yg = YYBlm36zd0Jst18LXwo4.findall(zI3ROAZtiUq42rE9WDST68(u"࠭ࠨ࠲࡝࠸࠱࠾ࡣࠫࡽ࠴࡞࠴࠲࠹࡝ࠬࠫࠪ༥"),EmQx8sbva1tHfNu79Oe3Ploh0gX,YYBlm36zd0Jst18LXwo4.DOTALL)
			CCraukVcTEBtsdONXm3eDzQqn58y = DD5cFIejQa2X4BgAu9GWPyJ3tC7
			for jn4zODMlIcBWY9 in KnClvL5AZ7z4rGtMVj2yg:
				if len(jn4zODMlIcBWY9)==IgQimel18t:
					CCraukVcTEBtsdONXm3eDzQqn58y = CCxMXuNUEzolDZTKrBJ
					break
			if kke1PDGRBLuY8y(u"ࠧ࡯ࡱࡷࠤࡷࡧࡴࡦࡦࠪ༦") in EmQx8sbva1tHfNu79Oe3Ploh0gX: continue
			elif mQNonhS7CV2BXOv(u"ࠨࡷࡱࡶࡦࡺࡥࡥࠩ༧") in EmQx8sbva1tHfNu79Oe3Ploh0gX: continue
			elif Nh0BWuiSndf(u"ࠩ฽๎ึࠦๅึ่ไࠫ༨") in EmQx8sbva1tHfNu79Oe3Ploh0gX: continue
			elif YRU71oePGNrDj5AOHapluvtMy([ubxGUTt1LraKhVZgpAP(u"ࠪࡆ࡙ࡋࡸࡑࡘ࠴࠽ࡘࡘࡖࡏࡗࡘࡰ࡛ࡊࡖࡆࡘࡈ࡜ࠬ༩")])[LzYQg91SIxDeOGtCKd5]: continue
			elif EmQx8sbva1tHfNu79Oe3Ploh0gX in [UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠫࡷ࠭༪")] or CCraukVcTEBtsdONXm3eDzQqn58y or any(Y8aiFZsLKw in EmQx8sbva1tHfNu79Oe3Ploh0gX for Y8aiFZsLKw in rrzbL5xgHsokD2N3):
				mwIxD3GBPgLVc2aq9(WG2BfeyzMa,EECz06teoykrNFfq(QQ8pvXNcBfVkP5rRJ7o)+Nh0BWuiSndf(u"ࠬࠦࠠࠡࡄ࡯ࡳࡨࡱࡥࡥࠢࡤࡨࡺࡲࡴࡴࠢࡹ࡭ࡩ࡫࡯࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫ༫")+YabJfs3q7yjpzvXioO+kke1PDGRBLuY8y(u"࠭ࠠ࡞ࠩ༬"))
				if showDialogs: yicQV3gj4q(HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ༭"),Mmpr0o76iWJvz1kTtfgI8hES(u"ࠨษ็ๅ๏ี๊้ࠢ็่่ฮวาࠢไๆ฼่ࠦฤ่สࠤ๊์ูห้ࠪ༮"))
				return CCxMXuNUEzolDZTKrBJ
	return DD5cFIejQa2X4BgAu9GWPyJ3tC7
def tuJ9fQgDl8oineCrFPT(*aargs,**kkwargs):
	if aargs:
		direction = aargs[LzYQg91SIxDeOGtCKd5]
		X1jnZDLVfkWdFsIPu4hle92b0 = aargs[qHYIWnOZLPkrQU]
		if not direction: direction = yST5AHEfvPmcWpwGuh2BJ(u"ࠩࡦࡩࡳࡺࡥࡳࠩ༯")
		if not X1jnZDLVfkWdFsIPu4hle92b0: X1jnZDLVfkWdFsIPu4hle92b0 = kke1PDGRBLuY8y(u"ࠪหุะๅาษิࠫ༰")
		fBMvVsEtU6jd = aargs[IgQimel18t]
		vv5M4UfJS9ucKEiNbxtnaOZ = eeN6dTEnkJxI.join(aargs[zI3ROAZtiUq42rE9WDST68(u"࠴ᑠ"):])
	else: direction,X1jnZDLVfkWdFsIPu4hle92b0,fBMvVsEtU6jd,vv5M4UfJS9ucKEiNbxtnaOZ = b8Qe150xVaJsnDSv,uVQd103XyvUce2EBtzbYaC(u"ࠫࡔࡑࠧ༱"),b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv
	QlaM6yHe0bgh58Vx3BAZD(direction,b8Qe150xVaJsnDSv,X1jnZDLVfkWdFsIPu4hle92b0,b8Qe150xVaJsnDSv,fBMvVsEtU6jd,vv5M4UfJS9ucKEiNbxtnaOZ,**kkwargs)
	return
def BjMmX1vNrnzSAf(*aargs,**kkwargs):
	direction = aargs[LzYQg91SIxDeOGtCKd5]
	ooWiLuS7egMf0X = aargs[qHYIWnOZLPkrQU]
	xTAId5v4POzufjHqibEnltWsXSCJ1 = aargs[IgQimel18t]
	if xTAId5v4POzufjHqibEnltWsXSCJ1 or ooWiLuS7egMf0X: p9MEF7c3kq6Vmf8ChO1 = CCxMXuNUEzolDZTKrBJ
	else: p9MEF7c3kq6Vmf8ChO1 = DD5cFIejQa2X4BgAu9GWPyJ3tC7
	fBMvVsEtU6jd = aargs[VwApyDY1Jc]
	vv5M4UfJS9ucKEiNbxtnaOZ = aargs[NvHugPosYDzRJ]
	if not direction: direction = Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ༲")
	if not ooWiLuS7egMf0X: ooWiLuS7egMf0X = kke1PDGRBLuY8y(u"࠭ใๅษࠣࠤࡓࡵࠧ༳")
	if not xTAId5v4POzufjHqibEnltWsXSCJ1: xTAId5v4POzufjHqibEnltWsXSCJ1 = m6hwdgP31a2zjN7lkpX(u"ࠧ็฻่ࠤࠥ࡟ࡥࡴࠩ༴")
	if len(aargs)>=HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"࠹ᑢ"): vv5M4UfJS9ucKEiNbxtnaOZ += eeN6dTEnkJxI+aargs[QQdAXWBc2GPw(u"࠷ᑡ")]
	if len(aargs)>=DYakr9g4PVU(u"࠻ᑣ"): vv5M4UfJS9ucKEiNbxtnaOZ += eeN6dTEnkJxI+aargs[shC5qBRV2A0lZ(u"࠻ᑤ")]
	juILqxAVNHQrPUi4 = QlaM6yHe0bgh58Vx3BAZD(direction,ooWiLuS7egMf0X,b8Qe150xVaJsnDSv,xTAId5v4POzufjHqibEnltWsXSCJ1,fBMvVsEtU6jd,vv5M4UfJS9ucKEiNbxtnaOZ,**kkwargs)
	if juILqxAVNHQrPUi4==-Xz3bA2PFENVCUtplu51(u"࠷ᑥ") and p9MEF7c3kq6Vmf8ChO1: juILqxAVNHQrPUi4 = -qHYIWnOZLPkrQU
	elif juILqxAVNHQrPUi4==-qHYIWnOZLPkrQU and not p9MEF7c3kq6Vmf8ChO1: juILqxAVNHQrPUi4 = DD5cFIejQa2X4BgAu9GWPyJ3tC7
	elif juILqxAVNHQrPUi4==LzYQg91SIxDeOGtCKd5: juILqxAVNHQrPUi4 = DD5cFIejQa2X4BgAu9GWPyJ3tC7
	elif juILqxAVNHQrPUi4==IgQimel18t: juILqxAVNHQrPUi4 = CCxMXuNUEzolDZTKrBJ
	return juILqxAVNHQrPUi4
def XXprCMzuNP2mElUxfdA(*aargs,**kkwargs):
	return evil9I2DnLJcy8.Dialog().select(*aargs,**kkwargs)
def yicQV3gj4q(*aargs,**kkwargs):
	fBMvVsEtU6jd = aargs[LzYQg91SIxDeOGtCKd5]
	vv5M4UfJS9ucKEiNbxtnaOZ = aargs[qHYIWnOZLPkrQU]
	iSGdKDo3LEnxPIJUywl6a = kkwargs[uVQd103XyvUce2EBtzbYaC(u"ࠨࡶ࡬ࡱࡪ༵࠭")] if TYf7Dc06PQgy1vEV9(u"ࠩࡷ࡭ࡲ࡫ࠧ༶") in list(kkwargs.keys()) else shC5qBRV2A0lZ(u"࠱࠱࠲࠳ᑦ")
	ZZnN4mgYCsfMIxl = aargs[IgQimel18t] if len(aargs)>IgQimel18t and Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠪࡸ࡮ࡳࡥࠨ༷") not in aargs[IgQimel18t] else LAQD5wEkr18bUiGaYen3J(u"ࠫࡳࡵࡴࡪࡨ࡬ࡧࡦࡺࡩࡰࡰࡢࡶࡪ࡭ࡵ࡭ࡣࡵࠫ༸")
	hU4X97LmIKOsHVkvpJxw = Ay1SMOzkx5CU3aGTL4Zf.Thread(target=m0wHOR39Gv4fiV,args=(fBMvVsEtU6jd,vv5M4UfJS9ucKEiNbxtnaOZ,ZZnN4mgYCsfMIxl,iSGdKDo3LEnxPIJUywl6a))
	hU4X97LmIKOsHVkvpJxw.start()
	return
def m0wHOR39Gv4fiV(fBMvVsEtU6jd,vv5M4UfJS9ucKEiNbxtnaOZ,ZZnN4mgYCsfMIxl,iSGdKDo3LEnxPIJUywl6a):
	GTokj816zaHVU9uq = ZZnN4mgYCsfMIxl.replace(LAQD5wEkr18bUiGaYen3J(u"ࠬࡴ࡯ࡵ࡫ࡩ࡭ࡨࡧࡴࡪࡱࡱࡣ༹ࠬ"),b8Qe150xVaJsnDSv)
	name = RkNASsitM7eYvhqL62FVlfDuZW4x(CCxMXuNUEzolDZTKrBJ,GTokj816zaHVU9uq+VFjQx6Is28KvzLOmMXtg4GqTwa3(u"࠭ࠠ࠮ࠢࠪ༺")+fBMvVsEtU6jd+mQNonhS7CV2BXOv(u"ࠧࠡ࠯ࠣࠫ༻")+vv5M4UfJS9ucKEiNbxtnaOZ)
	name = LL1ZqB5WQHbd38JXhNRF(name)
	image_filename = x76PfMyAp1L2WejkU3.path.join(zzVXSsoMienKFN0JfEGZq,name+ddo23ZJtgcY(u"ࠨ࠰ࡳࡲ࡬࠭༼"))
	if x76PfMyAp1L2WejkU3.path.exists(image_filename):
		if ZZnN4mgYCsfMIxl==kke1PDGRBLuY8y(u"ࠩࡱࡳࡹ࡯ࡦࡪࡥࡤࡸ࡮ࡵ࡮ࡠࡴࡨ࡫ࡺࡲࡡࡳࠩ༽"): image_height = QQdAXWBc2GPw(u"࠲࠳࠺ᑧ")
		elif ZZnN4mgYCsfMIxl==Nh0BWuiSndf(u"ࠪࡲࡴࡺࡩࡧ࡫ࡦࡥࡹ࡯࡯࡯ࡡࡤࡹࡹࡵࠧ༾"): image_height = QTUBCcehw6qPd4x(u"࠴࠴࠴ᑨ")
	else: image_height = uTSaCs2f9dtPJ3RqGZYhywc(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,fBMvVsEtU6jd,vv5M4UfJS9ucKEiNbxtnaOZ,ZZnN4mgYCsfMIxl,Mmpr0o76iWJvz1kTtfgI8hES(u"ࠫࡱ࡫ࡦࡵࠩ༿"),DD5cFIejQa2X4BgAu9GWPyJ3tC7,image_filename)
	sbIwdOBpfqzu6N = aSP049nZdvtTGDV8wEi75eIOUb(mQNonhS7CV2BXOv(u"ࠬࡊࡩࡢ࡮ࡲ࡫ࡓࡵࡴࡪࡨ࡬ࡧࡦࡺࡩࡰࡰࡌࡱࡦ࡭ࡥ࠯ࡺࡰࡰࠬཀ"),JnlzVBayd7WFKtCOH0,TYf7Dc06PQgy1vEV9(u"࠭ࡄࡦࡨࡤࡹࡱࡺࠧཁ"),Xz3bA2PFENVCUtplu51(u"ࠧ࠸࠴࠳ࡴࠬག"))
	sbIwdOBpfqzu6N.show()
	if ZZnN4mgYCsfMIxl==VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠨࡰࡲࡸ࡮࡬ࡩࡤࡣࡷ࡭ࡴࡴ࡟ࡢࡷࡷࡳࠬགྷ"):
		sbIwdOBpfqzu6N.getControl(VFjQx6Is28KvzLOmMXtg4GqTwa3(u"࠽࠵࠺࠰ᑪ")).setHeight(Xz3bA2PFENVCUtplu51(u"࠵࠵࠺ᑩ"))
		sbIwdOBpfqzu6N.getControl(Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"࠹࠱࠶࠳ᑭ")).setPosition(IjZbnrBJmM2N(u"࠺࠻ᑫ"),-TT8Mxv5Wq7nlC9IscdpPUY6(u"࠾࠰ᑬ"))
		sbIwdOBpfqzu6N.getControl(P0qdZI384LKleuo(u"࠺࠲࠸࠴ᑮ")).setPosition(IjZbnrBJmM2N(u"࠳࠵࠴ᑯ"),-TYf7Dc06PQgy1vEV9(u"࠹࠴ᑰ"))
		sbIwdOBpfqzu6N.getControl(IjZbnrBJmM2N(u"࠺࠰࠱ᑳ")).setPosition(mmcNLrXtzfpyCkZlvK5VwG2gujh(u"࠽࠵ᑱ"),-BWNPxIG7vqdTy85pjHzUOrK3(u"࠸࠻ᑲ"))
	sbIwdOBpfqzu6N.getControl(vvWwO3Tx2dAgcijrFXq(u"࠴࠱࠳ᑴ")).setVisible(DD5cFIejQa2X4BgAu9GWPyJ3tC7)
	sbIwdOBpfqzu6N.getControl(Xz3bA2PFENVCUtplu51(u"࠵࠲࠵ᑵ")).setVisible(DD5cFIejQa2X4BgAu9GWPyJ3tC7)
	sbIwdOBpfqzu6N.getControl(IjZbnrBJmM2N(u"࠻࠳࠹࠵ᑶ")).setImage(image_filename)
	sbIwdOBpfqzu6N.getControl(Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"࠼࠴࠺࠶ᑷ")).setHeight(image_height)
	wLQCTr5lqbsVYeAHdzfhZ1F.sleep(iSGdKDo3LEnxPIJUywl6a//SbjiWeHLQPoazqwp3cODkd7YxVgn(u"࠵࠵࠶࠰࠯࠲ᑸ"))
	return
def ryTNDEf2xWFCdi60AMKBomSVRpP5(*aargs,**kkwargs):
	fBMvVsEtU6jd,vv5M4UfJS9ucKEiNbxtnaOZ,profile,direction = b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,ubxGUTt1LraKhVZgpAP(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࡤࡲ࡯࡯ࡩࠪང"),Mmpr0o76iWJvz1kTtfgI8hES(u"ࠪࡰࡪ࡬ࡴࠨཅ")
	if len(aargs)>=qHYIWnOZLPkrQU: fBMvVsEtU6jd = aargs[LzYQg91SIxDeOGtCKd5]
	if len(aargs)>=IgQimel18t: vv5M4UfJS9ucKEiNbxtnaOZ = aargs[qHYIWnOZLPkrQU]
	if len(aargs)>=VwApyDY1Jc: profile = aargs[IgQimel18t]
	if len(aargs)>=NvHugPosYDzRJ: direction = aargs[VwApyDY1Jc]
	return bJvWMFh8G3eas(direction,fBMvVsEtU6jd,vv5M4UfJS9ucKEiNbxtnaOZ,profile)
def m1pyo0fC2w8jr7xY5LcgV(*aargs,**kkwargs):
	return evil9I2DnLJcy8.Dialog().contextmenu(*aargs,**kkwargs)
def o37f6ZQNakWxw4Lg8c9r1BAtm(*aargs,**kkwargs):
	return evil9I2DnLJcy8.Dialog().browseSingle(*aargs,**kkwargs)
def hyG0olqQfw(*aargs,**kkwargs):
	return evil9I2DnLJcy8.Dialog().input(*aargs,**kkwargs)
def F6kGteqcvBXWCKdASUZmnjP(*aargs,**kkwargs):
	return evil9I2DnLJcy8.DialogProgress(*aargs,**kkwargs)
def QlaM6yHe0bgh58Vx3BAZD(direction,button0=b8Qe150xVaJsnDSv,button1=b8Qe150xVaJsnDSv,button2=b8Qe150xVaJsnDSv,fBMvVsEtU6jd=b8Qe150xVaJsnDSv,vv5M4UfJS9ucKEiNbxtnaOZ=b8Qe150xVaJsnDSv,profile=Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠫࡨࡵ࡮ࡧ࡫ࡵࡱࡤࡨࡩࡨࡨࡲࡲࡹ࠭ཆ"),ggICRFJ3D5kMjcfSY1wA2K=LzYQg91SIxDeOGtCKd5,sDt0Vw3A6qR7IucLx1Te=LzYQg91SIxDeOGtCKd5):
	if not direction: direction = shC5qBRV2A0lZ(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬཇ")
	sbIwdOBpfqzu6N = yyNADL9mFOpU1uo(SbjiWeHLQPoazqwp3cODkd7YxVgn(u"࠭ࡄࡪࡣ࡯ࡳ࡬ࡉ࡯࡯ࡨ࡬ࡶࡲ࡚ࡨࡳࡧࡨࡆࡺࡺࡴࡰࡰࡶ࠲ࡽࡳ࡬ࠨ཈"),JnlzVBayd7WFKtCOH0,UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠧࡅࡧࡩࡥࡺࡲࡴࠨཉ"),DYakr9g4PVU(u"ࠨ࠹࠵࠴ࡵ࠭ཊ"))
	sbIwdOBpfqzu6N.L6lBSU8emu3FtysgaWh2o0CV5nIA(button0,button1,button2,fBMvVsEtU6jd,vv5M4UfJS9ucKEiNbxtnaOZ,profile,direction,ggICRFJ3D5kMjcfSY1wA2K,sDt0Vw3A6qR7IucLx1Te)
	if ggICRFJ3D5kMjcfSY1wA2K>LzYQg91SIxDeOGtCKd5: sbIwdOBpfqzu6N.iJCrUGFgHksNbV13()
	if sDt0Vw3A6qR7IucLx1Te>LzYQg91SIxDeOGtCKd5: sbIwdOBpfqzu6N.K4AD9RjdZ5FCvsMh()
	if ggICRFJ3D5kMjcfSY1wA2K==LzYQg91SIxDeOGtCKd5 and sDt0Vw3A6qR7IucLx1Te==LzYQg91SIxDeOGtCKd5: sbIwdOBpfqzu6N.jjg4G3RCv1L()
	sbIwdOBpfqzu6N.doModal()
	juILqxAVNHQrPUi4 = sbIwdOBpfqzu6N.choiceID
	return juILqxAVNHQrPUi4
def bJvWMFh8G3eas(direction,fBMvVsEtU6jd,vv5M4UfJS9ucKEiNbxtnaOZ,profile=SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࡤࡲ࡯࡯ࡩࠪཋ")):
	if not direction: direction = Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠪࡰࡪ࡬ࡴࠨཌ")
	sbIwdOBpfqzu6N = aSP049nZdvtTGDV8wEi75eIOUb(mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠫࡉ࡯ࡡ࡭ࡱࡪࡘࡪࡾࡴࡗ࡫ࡨࡻࡪࡸࡆࡶ࡮࡯ࡗࡨࡸࡥࡦࡰ࠱ࡼࡲࡲࠧཌྷ"),JnlzVBayd7WFKtCOH0,BmePGjS7FxK6kutUM(u"ࠬࡊࡥࡧࡣࡸࡰࡹ࠭ཎ"),BWNPxIG7vqdTy85pjHzUOrK3(u"࠭࠷࠳࠲ࡳࠫཏ"))
	image_filename = PYGjDSCw4zKNef9QZ3By0xn.replace(ubxGUTt1LraKhVZgpAP(u"ࠧࡠ࠲࠳࠴࠵ࡥࠧཐ"),BWNPxIG7vqdTy85pjHzUOrK3(u"ࠨࡡࠪད")+str(wLQCTr5lqbsVYeAHdzfhZ1F.time())+mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠩࡢࠫདྷ"))
	image_filename = image_filename.replace(BmePGjS7FxK6kutUM(u"ࠪࡠࡡ࠭ན"),P0qdZI384LKleuo(u"ࠫࡡࡢ࡜࡝ࠩཔ")).replace(QTUBCcehw6qPd4x(u"ࠬ࠵࠯ࠨཕ"),IjZbnrBJmM2N(u"࠭࠯࠰࠱࠲ࠫབ"))
	image_height = uTSaCs2f9dtPJ3RqGZYhywc(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,fBMvVsEtU6jd,vv5M4UfJS9ucKEiNbxtnaOZ,profile,direction,DD5cFIejQa2X4BgAu9GWPyJ3tC7,image_filename)
	sbIwdOBpfqzu6N.show()
	sbIwdOBpfqzu6N.getControl(Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"࠾࠶࠵࠱ᑹ")).setHeight(image_height)
	sbIwdOBpfqzu6N.getControl(Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"࠿࠰࠶࠲ᑺ")).setImage(image_filename)
	rAY3l2eqI1FvO8X69 = sbIwdOBpfqzu6N.doModal()
	try: x76PfMyAp1L2WejkU3.remove(image_filename)
	except: pass
	return rAY3l2eqI1FvO8X69
def kIMmsSG9NW6BOjlTpnEcuRzgwK(Vghk0SoHOqnyr6l8A5I9dNszWvLYf=CCxMXuNUEzolDZTKrBJ):
	if Vghk0SoHOqnyr6l8A5I9dNszWvLYf:
		quhyD5749GRVfBUTCHZ3t2lpXvWx = SS2OK7hjLagvUAm(mshLJcKH1fv03yRnDOr4ZT,Mmpr0o76iWJvz1kTtfgI8hES(u"ࠧࡴࡶࡵࠫབྷ"),Xz3bA2PFENVCUtplu51(u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫམ"),zI3ROAZtiUq42rE9WDST68(u"ࠩࡘࡗࡊࡘࡁࡈࡇࡑࡘࠬཙ"))
		if quhyD5749GRVfBUTCHZ3t2lpXvWx: return quhyD5749GRVfBUTCHZ3t2lpXvWx
	vv5M4UfJS9ucKEiNbxtnaOZ = b8Qe150xVaJsnDSv
	if LzYQg91SIxDeOGtCKd5 and Ci4rQ0qV915j2AIkHTbcy.succeeded:
		oH3N1dY9vLpaDJfnTVP5Z7q = Ci4rQ0qV915j2AIkHTbcy.content
		MJGQBx4rhWt5N3kd1IeFnT = oH3N1dY9vLpaDJfnTVP5Z7q.count(vvWwO3Tx2dAgcijrFXq(u"ࠪࡑࡴࢀࡩ࡭࡮ࡤࠫཚ"))
		if MJGQBx4rhWt5N3kd1IeFnT>shC5qBRV2A0lZ(u"࠸࠱ᑻ"):
			vv5M4UfJS9ucKEiNbxtnaOZ = YYBlm36zd0Jst18LXwo4.findall(TYf7Dc06PQgy1vEV9(u"ࠫ࡬࡫ࡴ࠮ࡶ࡫ࡩ࠲ࡲࡩࡴࡶ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ཛ"),oH3N1dY9vLpaDJfnTVP5Z7q,YYBlm36zd0Jst18LXwo4.DOTALL)
			vv5M4UfJS9ucKEiNbxtnaOZ = vv5M4UfJS9ucKEiNbxtnaOZ[LzYQg91SIxDeOGtCKd5]
	if not vv5M4UfJS9ucKEiNbxtnaOZ:
		Hq1x8yAj0iY9J = x76PfMyAp1L2WejkU3.path.join(JnlzVBayd7WFKtCOH0,Mmpr0o76iWJvz1kTtfgI8hES(u"ࠬࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫཛྷ"),Mmpr0o76iWJvz1kTtfgI8hES(u"࠭ࡵࡴࡧࡵࡥ࡬࡫࡮ࡵࡵ࠱ࡸࡽࡺࠧཝ"))
		vv5M4UfJS9ucKEiNbxtnaOZ = open(Hq1x8yAj0iY9J,mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠧࡳࡤࠪཞ")).read()
		if i1thmHk7AZquD4cM0fnp62: vv5M4UfJS9ucKEiNbxtnaOZ = vv5M4UfJS9ucKEiNbxtnaOZ.decode(OVauxZzLI10vcXT74K)
		vv5M4UfJS9ucKEiNbxtnaOZ = vv5M4UfJS9ucKEiNbxtnaOZ.replace(d6ekSEojpFUANKJ7r9WTlI3niLBOu,b8Qe150xVaJsnDSv)
	UM8WtmFpsoZnqEPdL = YYBlm36zd0Jst18LXwo4.findall(HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠨࠪࡐࡳࡿ࡯࡬࡭ࡣ࠱࠮ࡄ࠯࡜࡯ࠩཟ"),vv5M4UfJS9ucKEiNbxtnaOZ,YYBlm36zd0Jst18LXwo4.DOTALL)
	hHiFPq1JXY3oQ4Ds05mLgbxBRyM = []
	for Xfu41hHADW36e5FkU in UM8WtmFpsoZnqEPdL:
		YYNqw1VRIWucDlsM5n = Xfu41hHADW36e5FkU.lower()
		if yST5AHEfvPmcWpwGuh2BJ(u"ࠩࡤࡲࡩࡸ࡯ࡪࡦࠪའ") in YYNqw1VRIWucDlsM5n: continue
		if Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠪࡹࡧࡻ࡮ࡵࡷࠪཡ") in YYNqw1VRIWucDlsM5n: continue
		if IjZbnrBJmM2N(u"ࠫ࡮ࡶࡨࡰࡰࡨࠫར") in YYNqw1VRIWucDlsM5n: continue
		if yST5AHEfvPmcWpwGuh2BJ(u"ࠬࡩࡲࡰࡵࠪལ") in YYNqw1VRIWucDlsM5n: continue
		hHiFPq1JXY3oQ4Ds05mLgbxBRyM.append(Xfu41hHADW36e5FkU)
	quhyD5749GRVfBUTCHZ3t2lpXvWx = qHiNBx6PXjKatkWf37AwFClzsp2DmE.sample(hHiFPq1JXY3oQ4Ds05mLgbxBRyM,qHYIWnOZLPkrQU)
	quhyD5749GRVfBUTCHZ3t2lpXvWx = quhyD5749GRVfBUTCHZ3t2lpXvWx[LzYQg91SIxDeOGtCKd5]
	PGudrhJF8iDkSq96XVHEQZYf5L(mshLJcKH1fv03yRnDOr4ZT,Nh0BWuiSndf(u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩཤ"),mQNonhS7CV2BXOv(u"ࠧࡖࡕࡈࡖࡆࡍࡅࡏࡖࠪཥ"),quhyD5749GRVfBUTCHZ3t2lpXvWx,GMkNL1RXxKFentp0Zh9d)
	return quhyD5749GRVfBUTCHZ3t2lpXvWx
def vvcDoAQJ2zCpBM6tfaKb(yABitW02UXORGEJQPsTujcL=b8Qe150xVaJsnDSv):
	showDialogs = CCxMXuNUEzolDZTKrBJ if Tfo3HwyzGk==b8Qe150xVaJsnDSv else Tfo3HwyzGk
	if not showDialogs: return
	if not yABitW02UXORGEJQPsTujcL: yABitW02UXORGEJQPsTujcL = n9dSEJTBOWlY6.format_exc()
	if IjZbnrBJmM2N(u"ࠨࡕࡼࡷࡹ࡫࡭ࡆࡺ࡬ࡸࠬས") in yABitW02UXORGEJQPsTujcL or kke1PDGRBLuY8y(u"ࠩࡢࡣࡤࡌࡏࡓࡅࡈࡣࡊ࡞ࡉࡕࡡࡢࡣࠬཧ") in yABitW02UXORGEJQPsTujcL: return
	if yABitW02UXORGEJQPsTujcL!=BmePGjS7FxK6kutUM(u"ࠪࡒࡴࡴࡥࡕࡻࡳࡩ࠿ࠦࡎࡰࡰࡨࡠࡳ࠭ཨ"): Pft6y0LvwSh48iYg7b.stderr.write(yABitW02UXORGEJQPsTujcL)
	bCoNUQ3TXW7un = yABitW02UXORGEJQPsTujcL.splitlines()
	DXh6Ta4KnjN = bCoNUQ3TXW7un[-SbjiWeHLQPoazqwp3cODkd7YxVgn(u"࠲ᑼ")]
	V4oN8CZAK9uW7R6bTip3 = open(v3Sd26atO0oRKA5ig,S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠫࡷࡨࠧཀྵ")).read()
	if i1thmHk7AZquD4cM0fnp62: V4oN8CZAK9uW7R6bTip3 = V4oN8CZAK9uW7R6bTip3.decode(OVauxZzLI10vcXT74K)
	V4oN8CZAK9uW7R6bTip3 = V4oN8CZAK9uW7R6bTip3[-TT8Mxv5Wq7nlC9IscdpPUY6(u"࠺࠳࠴࠵ᑽ"):]
	ZrBtKnWX8I6PLxF = yST5AHEfvPmcWpwGuh2BJ(u"ࠬࡃࠧཪ")*ddo23ZJtgcY(u"࠴࠴࠵ᑾ")
	if ZrBtKnWX8I6PLxF in V4oN8CZAK9uW7R6bTip3: V4oN8CZAK9uW7R6bTip3 = V4oN8CZAK9uW7R6bTip3.rsplit(ZrBtKnWX8I6PLxF,qHYIWnOZLPkrQU)[qHYIWnOZLPkrQU]
	if DXh6Ta4KnjN in V4oN8CZAK9uW7R6bTip3: V4oN8CZAK9uW7R6bTip3 = V4oN8CZAK9uW7R6bTip3.rsplit(DXh6Ta4KnjN,qHYIWnOZLPkrQU)[LzYQg91SIxDeOGtCKd5]
	bKQLYJ2zqvCOARBkZlaITjxVXdiu6 = YYBlm36zd0Jst18LXwo4.findall(SbjiWeHLQPoazqwp3cODkd7YxVgn(u"࠭ࠨࡔࡱࡸࡶࡨ࡫ࡼࡎࡱࡧࡩ࠮ࡀࠠ࡝࡝ࠣࠬ࠳࠰࠿ࠪࠢ࡟ࡡࠬཫ"),V4oN8CZAK9uW7R6bTip3,YYBlm36zd0Jst18LXwo4.DOTALL)
	for FcasOEUCg0HL9hqBJjf52TZKbkwlD,fOzS45youKYdNDqwm61aEI3A in reversed(bKQLYJ2zqvCOARBkZlaITjxVXdiu6):
		if fOzS45youKYdNDqwm61aEI3A: break
	else: fOzS45youKYdNDqwm61aEI3A = RRIHDFjoW9w7bSfVPhC(u"ࠧࡏࡑࡗࠤࡘࡖࡅࡄࡋࡉࡍࡊࡊࠧཬ")
	IrtJbkGzf0wNZUgvuYC7,Xfu41hHADW36e5FkU,XX3k8EUPWOIGrp = b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv
	kd9rmEnV8zvyFWw = RRIHDFjoW9w7bSfVPhC(u"ࠨ࡝ࡕࡘࡑࡣࠧ཭")+OkuB9nwhD8U1+kke1PDGRBLuY8y(u"ࠩส่ำ฽ร࠻ࠢࠣࠫ཮")+hAIp8kmC36T5WFPMSXOwnNbtD+DXh6Ta4KnjN
	dM73wSoBq80FpIXY6Pb1mTAZyue = Nh0BWuiSndf(u"ࠪ࡟ࡗ࡚ࡌ࡞ࠩ཯")+OkuB9nwhD8U1+P0qdZI384LKleuo(u"ࠫฬ๊ๅึัิ࠾ࠥࠦࠧ཰")+hAIp8kmC36T5WFPMSXOwnNbtD+fOzS45youKYdNDqwm61aEI3A
	for BcZGyQ7rszoduDeFtgk in reversed(bCoNUQ3TXW7un):
		if Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠬࡌࡩ࡭ࡧཱࠣࠦࠬ") in BcZGyQ7rszoduDeFtgk and BWNPxIG7vqdTy85pjHzUOrK3(u"࠭ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷིࠬ") in BcZGyQ7rszoduDeFtgk: break
	BcZGyQ7rszoduDeFtgk = YYBlm36zd0Jst18LXwo4.findall(mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠧࡇ࡫࡯ࡩࠥࠨࠨ࠯ࠬࡂ࠭ࠧࡢࠬࠡ࡮࡬ࡲࡪࠦࠨ࠯ࠬࡂ࠭ࡡ࠲ࠠࡪࡰࠣࠬ࠳࠰࠿ཱིࠪࠦࠪ"),BcZGyQ7rszoduDeFtgk,YYBlm36zd0Jst18LXwo4.DOTALL)
	if BcZGyQ7rszoduDeFtgk:
		IrtJbkGzf0wNZUgvuYC7,Xfu41hHADW36e5FkU,XX3k8EUPWOIGrp = BcZGyQ7rszoduDeFtgk[LzYQg91SIxDeOGtCKd5]
		if RRIHDFjoW9w7bSfVPhC(u"ࠨ࠱ུࠪ") in IrtJbkGzf0wNZUgvuYC7: IrtJbkGzf0wNZUgvuYC7 = IrtJbkGzf0wNZUgvuYC7.rsplit(VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠩ࠲ཱུࠫ"),qHYIWnOZLPkrQU)[qHYIWnOZLPkrQU]
		else: IrtJbkGzf0wNZUgvuYC7 = IrtJbkGzf0wNZUgvuYC7.rsplit(VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠪࡠࡡ࠭ྲྀ"),qHYIWnOZLPkrQU)[qHYIWnOZLPkrQU]
		CjUH5iLpEtNOSAI = mQNonhS7CV2BXOv(u"ࠫࡠࡘࡔࡍ࡟ࠪཷ")+OkuB9nwhD8U1+Mmpr0o76iWJvz1kTtfgI8hES(u"ࠬอไๆๆไ࠾ࠥࠦࠧླྀ")+hAIp8kmC36T5WFPMSXOwnNbtD+IrtJbkGzf0wNZUgvuYC7
		ruoqJp9SEmk = RRIHDFjoW9w7bSfVPhC(u"࡛࠭ࡓࡖࡏࡡࠬཹ")+OkuB9nwhD8U1+RRIHDFjoW9w7bSfVPhC(u"ࠧศๆึ฻ึࡀེࠠࠡࠩ")+hAIp8kmC36T5WFPMSXOwnNbtD+Xfu41hHADW36e5FkU
		s2mug7Rv5Fr8UcipxJnh0zlyojK9w = TYf7Dc06PQgy1vEV9(u"ࠨ࡝ࡕࡘࡑࡣཻࠧ")+OkuB9nwhD8U1+SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠩส่๊้ว็࠼ࠣࠤོࠬ")+hAIp8kmC36T5WFPMSXOwnNbtD+XX3k8EUPWOIGrp
		O1UIjcpJFlbi0fYt2uAer56S = CjUH5iLpEtNOSAI+eeN6dTEnkJxI+ruoqJp9SEmk+eeN6dTEnkJxI+s2mug7Rv5Fr8UcipxJnh0zlyojK9w+eeN6dTEnkJxI+dM73wSoBq80FpIXY6Pb1mTAZyue+eeN6dTEnkJxI+kd9rmEnV8zvyFWw
		cxgzFf2qa6htWiZuMCRv3D = ruoqJp9SEmk+eeN6dTEnkJxI+dM73wSoBq80FpIXY6Pb1mTAZyue+eeN6dTEnkJxI+kd9rmEnV8zvyFWw+eeN6dTEnkJxI+CjUH5iLpEtNOSAI+eeN6dTEnkJxI+s2mug7Rv5Fr8UcipxJnh0zlyojK9w
		IIaAXR7KGyxBnTqS0r9V = ruoqJp9SEmk+eeN6dTEnkJxI+kd9rmEnV8zvyFWw+eeN6dTEnkJxI+CjUH5iLpEtNOSAI+eeN6dTEnkJxI+s2mug7Rv5Fr8UcipxJnh0zlyojK9w
	else:
		CjUH5iLpEtNOSAI,ruoqJp9SEmk,s2mug7Rv5Fr8UcipxJnh0zlyojK9w = b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv
		O1UIjcpJFlbi0fYt2uAer56S = dM73wSoBq80FpIXY6Pb1mTAZyue+Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠪࡠࡳࡢ࡮ࠨཽ")+kd9rmEnV8zvyFWw
		cxgzFf2qa6htWiZuMCRv3D = dM73wSoBq80FpIXY6Pb1mTAZyue+uVQd103XyvUce2EBtzbYaC(u"ࠫࡡࡴ࡜࡯ࠩཾ")+kd9rmEnV8zvyFWw
		IIaAXR7KGyxBnTqS0r9V = kd9rmEnV8zvyFWw
	BaAXzTqcFI8VjLSUo4W = IjZbnrBJmM2N(u"ࠬำฯฬࠢั฻ศฺ๋ࠦำ้ࠣ็฻่ะࠩཿ")+eeN6dTEnkJxI
	BbkLs5NmEpXdnQch8O7JA1 = Iob681D27YqidjpnuaMPlmX3gEOFw()
	ssm5LcAi0UpSvkETuBfRKoCxMW = []
	XXxlOLJ9KRjPH382WVCvr6n71 = BbkLs5NmEpXdnQch8O7JA1[DYakr9g4PVU(u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶྀࠫ")]
	Gi3TFlr8KmbXf = qowTBnzym3(cpGrK6qnPi)
	if m6hwdgP31a2zjN7lkpX(u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷཱྀࠬ") in list(BbkLs5NmEpXdnQch8O7JA1.keys()):
		for TcOrDXYbkanu8wS6hUPN9jgx,IIXfZ3Eol4aTPY7ehis,R8Bu32PJCDtzoLOscTbZVnwIxE in XXxlOLJ9KRjPH382WVCvr6n71:
			ssm5LcAi0UpSvkETuBfRKoCxMW = max(ssm5LcAi0UpSvkETuBfRKoCxMW,IIXfZ3Eol4aTPY7ehis)
		if Gi3TFlr8KmbXf<ssm5LcAi0UpSvkETuBfRKoCxMW:
			fBMvVsEtU6jd = RRIHDFjoW9w7bSfVPhC(u"ࠨไ่ࠤอะอะ์ฮࠤฬ๊ศา่ส้ัࠦโษๆࠣษึูวๅࠢส่ศิืศร่้๋ࠣศา็ฯࠫྂ")
			juILqxAVNHQrPUi4 = QlaM6yHe0bgh58Vx3BAZD(Mmpr0o76iWJvz1kTtfgI8hES(u"ࠩࡵ࡭࡬࡮ࡴࠨྃ"),uVQd103XyvUce2EBtzbYaC(u"ࠪษึูวๅࠢศ่๎ࠦวๅ็หี๊า྄ࠧ"),mQNonhS7CV2BXOv(u"ࠫฯำฯ๋อࠪ྅"),Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠬิั้ฮࠪ྆"),BaAXzTqcFI8VjLSUo4W+fBMvVsEtU6jd,O1UIjcpJFlbi0fYt2uAer56S)
			if juILqxAVNHQrPUi4==qHYIWnOZLPkrQU:
				import cTGphBXNeH
				cTGphBXNeH.OsdWDnBA5bgqZlXPhmeuK60cCU7(CCxMXuNUEzolDZTKrBJ)
				AKQaWIc0YCHGVnT()
			elif juILqxAVNHQrPUi4==IgQimel18t: AKQaWIc0YCHGVnT()
	bsuDr3TQLw = SS2OK7hjLagvUAm(mshLJcKH1fv03yRnDOr4ZT,BmePGjS7FxK6kutUM(u"࠭࡬ࡪࡵࡷࠫ྇"),BWNPxIG7vqdTy85pjHzUOrK3(u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪྈ"),QTUBCcehw6qPd4x(u"ࠨࡃࡏࡐࡤ࡙ࡅࡏࡖࡢࡉࡗࡘࡏࡓࡕࠪྉ"))
	if not bsuDr3TQLw: bsuDr3TQLw = []
	cxgzFf2qa6htWiZuMCRv3D = cxgzFf2qa6htWiZuMCRv3D.replace(eeN6dTEnkJxI,m6hwdgP31a2zjN7lkpX(u"ࠩ࡟ࡠࡳ࠭ྊ")).replace(QTUBCcehw6qPd4x(u"ࠪ࡟ࡗ࡚ࡌ࡞ࠩྋ"),b8Qe150xVaJsnDSv).replace(OkuB9nwhD8U1,b8Qe150xVaJsnDSv).replace(hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv)
	IIaAXR7KGyxBnTqS0r9V = IIaAXR7KGyxBnTqS0r9V.replace(eeN6dTEnkJxI,shC5qBRV2A0lZ(u"ࠫࡡࡢ࡮ࠨྌ")).replace(P0qdZI384LKleuo(u"ࠬࡡࡒࡕࡎࡠࠫྍ"),b8Qe150xVaJsnDSv).replace(OkuB9nwhD8U1,b8Qe150xVaJsnDSv).replace(hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv)
	rUqzsxbMH2kZ0WDVCg3Q = cpGrK6qnPi+QQdAXWBc2GPw(u"࠭࠺࠻ࠩྎ")+IIaAXR7KGyxBnTqS0r9V
	if rUqzsxbMH2kZ0WDVCg3Q in bsuDr3TQLw:
		fBMvVsEtU6jd = P0qdZI384LKleuo(u"ࠧๅไาࠤ็๋สࠡษ้ฮูࠥวษไสࠤอหัิษ็ࠤ์ึวࠡษ็า฼ษࠠฦๆ์ࠤฬ๊ๅษำ่ะࠬྏ")
		tuJ9fQgDl8oineCrFPT(BWNPxIG7vqdTy85pjHzUOrK3(u"ࠨࡴ࡬࡫࡭ࡺࠧྐ"),b8Qe150xVaJsnDSv,BaAXzTqcFI8VjLSUo4W+fBMvVsEtU6jd,O1UIjcpJFlbi0fYt2uAer56S)
		return
	bxE4LStzKBqv5ocpl3wCdOHFu0WT7k = str(g1gmkxOtc2oeEZHhBiy).split(LAQD5wEkr18bUiGaYen3J(u"ࠩ࠱ࠫྑ"))[LzYQg91SIxDeOGtCKd5]
	YabJfs3q7yjpzvXioO = nTHXJIiah2qK[mQNonhS7CV2BXOv(u"ࠪࡔ࡞࡚ࡈࡐࡐࠪྒ")][UUkIBz1sgQ9WfNeG6trKXvu0(u"࠺ᑿ")]
	Ci4rQ0qV915j2AIkHTbcy = dcLRAZWFzODax2jf0tHCX81pJveNY(LtlXH3fvMydAx,uVQd103XyvUce2EBtzbYaC(u"ࠫࡕࡕࡓࡕࠩྒྷ"),YabJfs3q7yjpzvXioO,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,RRIHDFjoW9w7bSfVPhC(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡓࡉࡑ࡚ࡣࡊ࡞ࡉࡕࡡࡈࡖࡗࡕࡒࡔ࠯࠴ࡷࡹ࠭ྔ"),DD5cFIejQa2X4BgAu9GWPyJ3tC7,DD5cFIejQa2X4BgAu9GWPyJ3tC7)
	oH3N1dY9vLpaDJfnTVP5Z7q = Ci4rQ0qV915j2AIkHTbcy.content
	UY7EOfeJQaWZ5I9cszS6 = YYBlm36zd0Jst18LXwo4.findall(P0qdZI384LKleuo(u"࠭ࡓࡕࡃࡕࡘ࠿ࡀࡓࡕࡃࡕࡘࡠࡢࡲ࡝ࡰࡠ࠯࠿ࡀࠨ࠯ࠬࡂ࠭ࡠࡢࡲ࡝ࡰࡠ࠯࠿ࡀࠨ࠯ࠬࡂ࠭ࡠࡢࡲ࡝ࡰࡠ࠯࠿ࡀࠨ࠯ࠬࡂ࠭ࡠࡢࡲ࡝ࡰࡠ࠯࠿ࡀࠨ࠯ࠬࡂ࠭ࡠࡢࡲ࡝ࡰࡠ࠯ࡊࡔࡄ࠻࠼ࡈࡒࡉ࠭ྕ"),oH3N1dY9vLpaDJfnTVP5Z7q,YYBlm36zd0Jst18LXwo4.DOTALL)
	for JqjvcupbtBkTm,R2w8f7EqCtemb,EmtoHa6S1GNejk5cd7FBKYJXn,XedaxYKsGAgy1hoj9OmBq in UY7EOfeJQaWZ5I9cszS6:
		JqjvcupbtBkTm = JqjvcupbtBkTm.split(VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠧࠬࠩྖ"))
		EmtoHa6S1GNejk5cd7FBKYJXn = EmtoHa6S1GNejk5cd7FBKYJXn.split(P0qdZI384LKleuo(u"ࠨ࠭ࠪྗ"))
		XedaxYKsGAgy1hoj9OmBq = XedaxYKsGAgy1hoj9OmBq.split(LAQD5wEkr18bUiGaYen3J(u"ࠩ࠮ࠫ྘"))
		if Xfu41hHADW36e5FkU in JqjvcupbtBkTm and DXh6Ta4KnjN==R2w8f7EqCtemb and cpGrK6qnPi in EmtoHa6S1GNejk5cd7FBKYJXn and bxE4LStzKBqv5ocpl3wCdOHFu0WT7k in XedaxYKsGAgy1hoj9OmBq:
			fBMvVsEtU6jd = ddo23ZJtgcY(u"๋ࠪีอࠠศๆั฻ศࠦๅฺำ๋ๅࠥ๎ำ๋฻ส่ัࠦศศๆศูิอัࠡษ็ๆฬีๅࠨྙ")
			aVwGA2kFY6u4m = BjMmX1vNrnzSAf(uVQd103XyvUce2EBtzbYaC(u"ࠫࡷ࡯ࡧࡩࡶࠪྚ"),RRIHDFjoW9w7bSfVPhC(u"ࠬิั้ฮࠪྛ"),mmcNLrXtzfpyCkZlvK5VwG2gujh(u"࠭ลาีส่ࠥหไ๊ࠢส่๊ฮัๆฮࠪྜ"),BaAXzTqcFI8VjLSUo4W+fBMvVsEtU6jd,O1UIjcpJFlbi0fYt2uAer56S)
			if aVwGA2kFY6u4m==qHYIWnOZLPkrQU: tuJ9fQgDl8oineCrFPT(uVQd103XyvUce2EBtzbYaC(u"ࠧࡤࡧࡱࡸࡪࡸࠧྜྷ"),b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,fBMvVsEtU6jd)
			return
	fBMvVsEtU6jd = zI3ROAZtiUq42rE9WDST68(u"ࠨษ็ีัอมࠡวิืฬ๊่ࠠาสࠤฬ๊ฮุลࠣษ้๏ࠠศๆ่ฬึ๋ฬࠨྞ")
	cv8AjayQbdztxmB9V2YpshwU = QlaM6yHe0bgh58Vx3BAZD(dDYUoKi6JFM23p(u"ࠩࡵ࡭࡬࡮ࡴࠨྟ"),Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠪษึูวๅࠢศ่๎ࠦวๅ็หี๊าࠧྠ"),ubxGUTt1LraKhVZgpAP(u"ࠫฯำฯ๋อࠣะืฬ๊ࠨྡ"),zI3ROAZtiUq42rE9WDST68(u"ࠬะอะ์ฮࠤฬ๊ศา่ส้ั࠭ྡྷ"),BaAXzTqcFI8VjLSUo4W+fBMvVsEtU6jd,O1UIjcpJFlbi0fYt2uAer56S)
	if cv8AjayQbdztxmB9V2YpshwU==qHYIWnOZLPkrQU:
		KKt5zJyFWQAuhpecY(DD5cFIejQa2X4BgAu9GWPyJ3tC7)
		yicQV3gj4q(VFjQx6Is28KvzLOmMXtg4GqTwa3(u"࠭ๆอฯอࠤ฾๋ไ๋หࠣห้ะอะ์ฮࠤฬ๊ฬำศํࠫྣ"),Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠧ๎ࡕࡸࡧࡨ࡫ࡳࡴࠩྤ"),wLQCTr5lqbsVYeAHdzfhZ1F=LAQD5wEkr18bUiGaYen3J(u"࠼࠻࠰ᒀ"))
		AKQaWIc0YCHGVnT()
	elif cv8AjayQbdztxmB9V2YpshwU==IgQimel18t:
		import cTGphBXNeH
		cTGphBXNeH.OsdWDnBA5bgqZlXPhmeuK60cCU7(CCxMXuNUEzolDZTKrBJ)
		AKQaWIc0YCHGVnT()
	aVwGA2kFY6u4m = BjMmX1vNrnzSAf(RRIHDFjoW9w7bSfVPhC(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨྥ"),b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,ddo23ZJtgcY(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬྦ"),SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠪืํ็๋ࠠฬ่ࠤสืำศๆࠣืั๊ࠠศๆฦา฼อม๊ࠡส่ฬูสฯัส้ࠥหไ๊ࠢส่๊ฮัๆฮ่่ࠣ๐๋ࠠ฻ิๅࠥอไๆสิ้ัࠦร๋่ࠣ์๊ะ้๊ࠡๆ๎ๆ่ࠦๅ็สิฬࠦอึๆอࠤ์ึ็ࠡษ็ู้้ไสࠢ็ว๋ࠦวๅ็หี๊าࠠๅษࠣ๎฾๊ๅࠡษ็฾๏ฮ้ࠠๆสࠤ๏ูสุ์฼ࠤฬ฻ไศฯู้้ࠣไส๋๋ࠢํࠦไศࠢํ฽ึ็ࠠไ์ไࠤ฽ํัห๋่๊ࠢอะศࠢ฻๋ึะ้ࠠ็อํࠥ฾็าฬ๋ࠣีํࠠศๆุ่่๊ษࠡ࠰๋้ࠣࠦสา์าࠤศืำศๆࠣหู้ฬๅࠢยࠫྦྷ"))
	if aVwGA2kFY6u4m==qHYIWnOZLPkrQU: AuPNC4MLr9E = vvWwO3Tx2dAgcijrFXq(u"ࠫࡤࡖࡒࡐࡄࡏࡉࡒࡥࠧྨ")
	else:
		tuJ9fQgDl8oineCrFPT(QQdAXWBc2GPw(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬྩ"),b8Qe150xVaJsnDSv,uVQd103XyvUce2EBtzbYaC(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩྪ"),OkuB9nwhD8U1+QQdAXWBc2GPw(u"ࠧห็ࠣษ้เวยࠢศีุอไࠡษ็า฼ษࠧྫ")+hAIp8kmC36T5WFPMSXOwnNbtD+VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠨ࡞ࡱ่ศ์ࠠศๆ่ฬึ๋ฬࠡๆสࠤ๏฿ไๆࠢส่฿๐ศ๊ࠡ็หࠥ๐ำหูํ฽ࠥหีๅษะࠤฬ๊ฮุลࠣฬิ๎ๆࠡีฯ่ࠥอไฤะฺหฦࠦวๅาํࠤ๊้ส้สࠣๅ๏ํࠠอ็ํ฽ࠥะแศืํ่ࠥํะศࠢส่ำ฽ร๊ࠡ฽๎ึํࠠๆ่ࠣห้ษฮุษฤࠫྫྷ"))
		return
	Hi18qkVDrA4PCxyX5vnLdBh6fg = cxgzFf2qa6htWiZuMCRv3D
	import cTGphBXNeH
	ip6CohvO5Tya9mFWVf3JdY1qL = cTGphBXNeH.a53FKP79mzt(zI3ROAZtiUq42rE9WDST68(u"ࠩࡈࡶࡷࡵࡲࡴࠩྭ"),Hi18qkVDrA4PCxyX5vnLdBh6fg,CCxMXuNUEzolDZTKrBJ,b8Qe150xVaJsnDSv,UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠪࡉࡒࡇࡉࡍ࠯ࡉࡖࡔࡓ࠭ࡔࡊࡒ࡛ࡤࡋࡘࡊࡖࡢࡉࡗࡘࡏࡓࡕࠪྮ"),AuPNC4MLr9E)
	if ip6CohvO5Tya9mFWVf3JdY1qL and AuPNC4MLr9E:
		bsuDr3TQLw.append(rUqzsxbMH2kZ0WDVCg3Q)
		PGudrhJF8iDkSq96XVHEQZYf5L(mshLJcKH1fv03yRnDOr4ZT,Nh0BWuiSndf(u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧྯ"),m6hwdgP31a2zjN7lkpX(u"ࠬࡇࡌࡍࡡࡖࡉࡓ࡚࡟ࡆࡔࡕࡓࡗ࡙ࠧྰ"),bsuDr3TQLw,t58tnzAgevxkoIOdMFbE2PsD64q0C9)
	return
def HHNXnxMqauW8dFPQESypoY4e1fiU(kTSyagGWsFnolYhMO5fCwvpNuPqR,filename=None):
	if i1thmHk7AZquD4cM0fnp62: kTSyagGWsFnolYhMO5fCwvpNuPqR = kTSyagGWsFnolYhMO5fCwvpNuPqR.encode(OVauxZzLI10vcXT74K)
	if not filename: lHXFzMgVqsNRnY0TKmESd = ubxGUTt1LraKhVZgpAP(u"࠭ࡳ࠻࡞࡟࠴࠵࠶࠰ࡦ࡯ࡤࡨࡤ࠭ྱ")+str(wLQCTr5lqbsVYeAHdzfhZ1F.time())+TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠧ࠯ࡦࡤࡸࠬྲ")
	else: lHXFzMgVqsNRnY0TKmESd = uVQd103XyvUce2EBtzbYaC(u"ࠨࡵ࠽ࡠࡡ࠶࠰࠱࠲ࡨࡱࡦࡪ࡟ࠨླ")+filename+SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠩ࠱ࡨࡦࡺࠧྴ")
	open(lHXFzMgVqsNRnY0TKmESd,Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠪࡻࡧ࠭ྵ")).write(kTSyagGWsFnolYhMO5fCwvpNuPqR)
	return
def Lv5gTyYmiskeUS(XX8FguGmKp5DVB2Twifsc):
	if XX8FguGmKp5DVB2Twifsc:
		I6EPVkCug24fet = SS2OK7hjLagvUAm(mshLJcKH1fv03yRnDOr4ZT,QTUBCcehw6qPd4x(u"ࠫࡱ࡯ࡳࡵࠩྶ"),vvWwO3Tx2dAgcijrFXq(u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࠨྷ"),Xz3bA2PFENVCUtplu51(u"࠭ࡑࡖࡇࡖࡘࡎࡕࡎࡔࠩྸ"))
		if I6EPVkCug24fet: return I6EPVkCug24fet
	YabJfs3q7yjpzvXioO = nTHXJIiah2qK[mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠧࡑ࡛ࡗࡌࡔࡔࠧྐྵ")][LAQD5wEkr18bUiGaYen3J(u"࠻ᒁ")]
	y9i63b5jQSGqUsfguZxPkTK = P1u7tUzG9XMxHjSlnk6QvARoNVCO5i(DD5cFIejQa2X4BgAu9GWPyJ3tC7) if not XX8FguGmKp5DVB2Twifsc else EtvK0T2LNPcsIrAFlufpM
	sT3ueLokq1riU5FBMWaQA = CGb8nOoSct2xEhyf0WzUmY()
	dHf3gSt5yWFKhPjZRN16iqeoc7O = sT3ueLokq1riU5FBMWaQA.split(uVQd103XyvUce2EBtzbYaC(u"ࠨ࠮ࠪྺ"))[IgQimel18t]
	ObL4Rdx1i9K5W = x76PfMyAp1L2WejkU3.path.join(JnlzVBayd7WFKtCOH0,ddo23ZJtgcY(u"ࠩࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨྻ"))
	UqDaXE9y8rmpJxLIPAoFnbKfucON = Nl4fJq21uTDvGRIE8iZgaQth6WdF()
	j01czpBZWA4hU87dHaryJ5Cu = {vvWwO3Tx2dAgcijrFXq(u"ࠪࡹࡸ࡫ࡲࠨྼ"):y9i63b5jQSGqUsfguZxPkTK,SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲࠬ྽"):cpGrK6qnPi,kke1PDGRBLuY8y(u"ࠬࡩ࡯ࡶࡰࡷࡶࡾ࠭྾"):dHf3gSt5yWFKhPjZRN16iqeoc7O,zI3ROAZtiUq42rE9WDST68(u"࠭ࡩࡥࡵࠪ྿"):hk9Mxv3LzSHl42AUdfs0ejF7qcVw(UqDaXE9y8rmpJxLIPAoFnbKfucON)}
	Ci4rQ0qV915j2AIkHTbcy = dcLRAZWFzODax2jf0tHCX81pJveNY(nCUMfrlZvuiLe5x,zI3ROAZtiUq42rE9WDST68(u"ࠧࡑࡑࡖࡘࠬ࿀"),YabJfs3q7yjpzvXioO,j01czpBZWA4hU87dHaryJ5Cu,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,P0qdZI384LKleuo(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡉ࡙ࡥࡑࡖࡇࡖࡘࡎࡕࡎࡔ࠯࠴ࡷࡹ࠭࿁"))
	I6EPVkCug24fet = []
	if Ci4rQ0qV915j2AIkHTbcy.succeeded:
		oH3N1dY9vLpaDJfnTVP5Z7q = Ci4rQ0qV915j2AIkHTbcy.content
		I6EPVkCug24fet = oH3N1dY9vLpaDJfnTVP5Z7q.replace(Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠩ࡟ࡠࡷ࠭࿂"),eeN6dTEnkJxI).replace(IjZbnrBJmM2N(u"ࠪࡠࡡࡴࠧ࿃"),eeN6dTEnkJxI).replace(mQNonhS7CV2BXOv(u"ࠫࡡࡸ࡜࡯ࠩ࿄"),eeN6dTEnkJxI).replace(d6ekSEojpFUANKJ7r9WTlI3niLBOu,eeN6dTEnkJxI)
		I6EPVkCug24fet = YYBlm36zd0Jst18LXwo4.findall(HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"࡙ࠬࡔࡂࡔࡗ࠾࠿࡙ࡔࡂࡔࡗ࠾࠿࠮࡜ࡥ࠭ࠬ࠾࠿࠮࠮ࠫࡁࠬࡠࡳࡀ࠺ࠩ࠰࠭ࡃ࠮ࡢ࡮࠻࠼ࠫ࠲࠯ࡅࠩ࡝ࡰ࠽࠾࠭࠴ࠪࡀࠫ࡟ࡲ࠿ࡀࠨ࠯ࠬࡂ࠭ࡡࡴࡅࡏࡆ࠽࠾ࡊࡔࡄࠨ࿅"),I6EPVkCug24fet,YYBlm36zd0Jst18LXwo4.DOTALL)
		if I6EPVkCug24fet:
			I6EPVkCug24fet = sorted(I6EPVkCug24fet,reverse=DD5cFIejQa2X4BgAu9GWPyJ3tC7,key=lambda key: int(key[LzYQg91SIxDeOGtCKd5]))
			od4AIsBzi3Ga2bLXNlZKME,y9i63b5jQSGqUsfguZxPkTK,wqxUVjrJvLpasn2YyGh0zuAi9E7,PPTURnwu345Xji,uua931OmCgEBHP8pDMdsjzXVRSGc4,UUF24APJXw0DzpoENvys1Zf3kRj = I6EPVkCug24fet[LzYQg91SIxDeOGtCKd5]
			chvi4fIQJTYmPt8klu01 = UUF24APJXw0DzpoENvys1Zf3kRj if YRU71oePGNrDj5AOHapluvtMy([TT8Mxv5Wq7nlC9IscdpPUY6(u"࠭ࡍࡕ࠲࠸ࡌ࡝࠶࡬ࡕࡖࡈࡊࡓ࡙ࡕࡏࡨࡘࡉ࡛࡙ࡓࡖ࠻ࡈ࡜࿆ࠬ")])[LzYQg91SIxDeOGtCKd5] else wqxUVjrJvLpasn2YyGh0zuAi9E7
			hRWC8YSFvsm4JHOMVIne3jquZ.setSetting(mQNonhS7CV2BXOv(u"ࠧࡢࡸ࠱ࡴࡪࡸࡩࡰࡦ࠱࡭ࡳ࡬࡯ࡴࠩ࿇"),chvi4fIQJTYmPt8klu01)
			PGudrhJF8iDkSq96XVHEQZYf5L(mshLJcKH1fv03yRnDOr4ZT,S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫ࿈"),shC5qBRV2A0lZ(u"ࠩࡔ࡙ࡊ࡙ࡔࡊࡑࡑࡗࠬ࿉"),I6EPVkCug24fet,GMkNL1RXxKFentp0Zh9d)
			hRWC8YSFvsm4JHOMVIne3jquZ.setSetting(SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰ࡴࡹࡪࡹࡴࡪࡱࡱࡷࠬ࿊"),hk9Mxv3LzSHl42AUdfs0ejF7qcVw(T3Axql94cU0BpO1wudEDtWXsf))
	return I6EPVkCug24fet
def rhltO6QX0U4nq(HRtPG93S8F10idLOAas4q5jnVxf,U9aOA2vXRBeCYQVit7df=LzYQg91SIxDeOGtCKd5,qgkwvM6YFLZ7K=LzYQg91SIxDeOGtCKd5):
	if U9aOA2vXRBeCYQVit7df and not qgkwvM6YFLZ7K: qgkwvM6YFLZ7K = len(HRtPG93S8F10idLOAas4q5jnVxf)//U9aOA2vXRBeCYQVit7df
	SodUcMhRuwZItCL5Tvpzkg2nEeDH,s9s45taoNBh60XL1zykOmTK3jJCrE,GKCQkRuhe5q1IbLNY6xSJfjr3m = [],-qHYIWnOZLPkrQU,LzYQg91SIxDeOGtCKd5
	for QpHl0Efc7yvn2V in HRtPG93S8F10idLOAas4q5jnVxf:
		if GKCQkRuhe5q1IbLNY6xSJfjr3m%qgkwvM6YFLZ7K==LzYQg91SIxDeOGtCKd5:
			s9s45taoNBh60XL1zykOmTK3jJCrE += qHYIWnOZLPkrQU
			SodUcMhRuwZItCL5Tvpzkg2nEeDH.append([])
		SodUcMhRuwZItCL5Tvpzkg2nEeDH[s9s45taoNBh60XL1zykOmTK3jJCrE].append(QpHl0Efc7yvn2V)
		GKCQkRuhe5q1IbLNY6xSJfjr3m += qHYIWnOZLPkrQU
	return SodUcMhRuwZItCL5Tvpzkg2nEeDH
def apPc8iJeETY5drwuVbg(lHXFzMgVqsNRnY0TKmESd,kTSyagGWsFnolYhMO5fCwvpNuPqR):
	Wzs6RwZcql15C3HrXfo = x76PfMyAp1L2WejkU3.path.join(vIaQF8hqXeiJERYuD,lHXFzMgVqsNRnY0TKmESd)
	if qHYIWnOZLPkrQU or Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠫࡎࡖࡔࡗࡡࠪ࿋") not in lHXFzMgVqsNRnY0TKmESd or Nh0BWuiSndf(u"ࠬࡓ࠳ࡖࡡࠪ࿌") not in lHXFzMgVqsNRnY0TKmESd: vv5M4UfJS9ucKEiNbxtnaOZ = str(kTSyagGWsFnolYhMO5fCwvpNuPqR)
	else:
		SodUcMhRuwZItCL5Tvpzkg2nEeDH = rhltO6QX0U4nq(kTSyagGWsFnolYhMO5fCwvpNuPqR,TYf7Dc06PQgy1vEV9(u"࠸ᒂ"))
		vv5M4UfJS9ucKEiNbxtnaOZ = b8Qe150xVaJsnDSv
		for OicuJELXsmDWby3 in SodUcMhRuwZItCL5Tvpzkg2nEeDH:
			vv5M4UfJS9ucKEiNbxtnaOZ += str(OicuJELXsmDWby3)+kke1PDGRBLuY8y(u"࠭࡜࡯࡞ࡱࡁࡂࡃ࠽࡝ࡰ࡟ࡲࠬ࿍")
		vv5M4UfJS9ucKEiNbxtnaOZ = vv5M4UfJS9ucKEiNbxtnaOZ.strip(P0qdZI384LKleuo(u"ࠧ࡝ࡰ࡟ࡲࡂࡃ࠽࠾࡞ࡱࡠࡳ࠭࿎"))
	bbYlLXdkFwq2hCPx3 = bk64KT2Z3WylUt.compress(vv5M4UfJS9ucKEiNbxtnaOZ)
	open(Wzs6RwZcql15C3HrXfo,DYakr9g4PVU(u"ࠨࡹࡥࠫ࿏")).write(bbYlLXdkFwq2hCPx3)
	return
def IHPaBVv9tWwesRQ4zFALdOlYqxmgy1(suA0cTlxyCN,lHXFzMgVqsNRnY0TKmESd):
	if suA0cTlxyCN==RRIHDFjoW9w7bSfVPhC(u"ࠩࡧ࡭ࡨࡺࠧ࿐"): kTSyagGWsFnolYhMO5fCwvpNuPqR = {}
	elif suA0cTlxyCN==BmePGjS7FxK6kutUM(u"ࠪࡰ࡮ࡹࡴࠨ࿑"): kTSyagGWsFnolYhMO5fCwvpNuPqR = []
	elif suA0cTlxyCN==vvWwO3Tx2dAgcijrFXq(u"ࠫࡸࡺࡲࠨ࿒"): kTSyagGWsFnolYhMO5fCwvpNuPqR = b8Qe150xVaJsnDSv
	elif suA0cTlxyCN==QTUBCcehw6qPd4x(u"ࠬ࡯࡮ࡵࠩ࿓"): kTSyagGWsFnolYhMO5fCwvpNuPqR = LzYQg91SIxDeOGtCKd5
	else: kTSyagGWsFnolYhMO5fCwvpNuPqR = None
	Wzs6RwZcql15C3HrXfo = x76PfMyAp1L2WejkU3.path.join(vIaQF8hqXeiJERYuD,lHXFzMgVqsNRnY0TKmESd)
	bbYlLXdkFwq2hCPx3 = open(Wzs6RwZcql15C3HrXfo,RRIHDFjoW9w7bSfVPhC(u"࠭ࡲࡣࠩ࿔")).read()
	vv5M4UfJS9ucKEiNbxtnaOZ = bk64KT2Z3WylUt.decompress(bbYlLXdkFwq2hCPx3)
	if dDYUoKi6JFM23p(u"ࠧ࡝ࡰ࡟ࡲࡂࡃ࠽࠾࡞ࡱࡠࡳ࠭࿕") not in vv5M4UfJS9ucKEiNbxtnaOZ: kTSyagGWsFnolYhMO5fCwvpNuPqR = eval(vv5M4UfJS9ucKEiNbxtnaOZ)
	else:
		SodUcMhRuwZItCL5Tvpzkg2nEeDH = vv5M4UfJS9ucKEiNbxtnaOZ.split(zI3ROAZtiUq42rE9WDST68(u"ࠨ࡞ࡱࡠࡳࡃ࠽࠾࠿࡟ࡲࡡࡴࠧ࿖"))
		del vv5M4UfJS9ucKEiNbxtnaOZ
		kTSyagGWsFnolYhMO5fCwvpNuPqR = []
		eEiNYp3j0cn7sJOMUT85xwbmDur = mIv7g95PNyqzLZDM8ihkcr1w()
		od4AIsBzi3Ga2bLXNlZKME = LzYQg91SIxDeOGtCKd5
		for OicuJELXsmDWby3 in SodUcMhRuwZItCL5Tvpzkg2nEeDH:
			eEiNYp3j0cn7sJOMUT85xwbmDur.B2pHMo1xcYrylP6fDbku4VeEqtWIGS(str(od4AIsBzi3Ga2bLXNlZKME),eval,OicuJELXsmDWby3)
			od4AIsBzi3Ga2bLXNlZKME += qHYIWnOZLPkrQU
		del SodUcMhRuwZItCL5Tvpzkg2nEeDH
		eEiNYp3j0cn7sJOMUT85xwbmDur.G3WuIvkoyTEHSgprqVwJm5x()
		eEiNYp3j0cn7sJOMUT85xwbmDur.O3fLNF8G1Sh()
		AiyUaMOzX1 = list(eEiNYp3j0cn7sJOMUT85xwbmDur.resultsDICT.keys())
		Eoq8Dxlk6MXeyLUwGNCOSfInAjV0 = sorted(AiyUaMOzX1,reverse=DD5cFIejQa2X4BgAu9GWPyJ3tC7,key=lambda key: int(key))
		for od4AIsBzi3Ga2bLXNlZKME in Eoq8Dxlk6MXeyLUwGNCOSfInAjV0:
			kTSyagGWsFnolYhMO5fCwvpNuPqR += eEiNYp3j0cn7sJOMUT85xwbmDur.resultsDICT[od4AIsBzi3Ga2bLXNlZKME]
	return kTSyagGWsFnolYhMO5fCwvpNuPqR
def W7iMdgkSpm0XbA2(DFUIv2KGj9ke):
	WPAc6m1Dhoj = x76PfMyAp1L2WejkU3.path.join(BdO6FDlYv4naqZf1gCGbS7V,UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠩࡤࡨࡩࡵ࡮ࡴࠩ࿗"),DFUIv2KGj9ke,SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠪࡥࡩࡪ࡯࡯࠰ࡻࡱࡱ࠭࿘"))
	try: XXB7nPT0pRewQGY = open(WPAc6m1Dhoj,Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠫࡷࡨࠧ࿙")).read()
	except:
		LMJPaE9VrnzBQ4i = x76PfMyAp1L2WejkU3.path.join(XqsJV0hizL8eFDPAd5U1cBRg,kke1PDGRBLuY8y(u"ࠬࡧࡤࡥࡱࡱࡷࠬ࿚"),DFUIv2KGj9ke,dDYUoKi6JFM23p(u"࠭ࡡࡥࡦࡲࡲ࠳ࡾ࡭࡭ࠩ࿛"))
		try: XXB7nPT0pRewQGY = open(LMJPaE9VrnzBQ4i,BWNPxIG7vqdTy85pjHzUOrK3(u"ࠧࡳࡤࠪ࿜")).read()
		except: return b8Qe150xVaJsnDSv,[]
	if i1thmHk7AZquD4cM0fnp62: XXB7nPT0pRewQGY = XXB7nPT0pRewQGY.decode(OVauxZzLI10vcXT74K)
	BKFfNUheLJicblVwky37 = YYBlm36zd0Jst18LXwo4.findall(zI3ROAZtiUq42rE9WDST68(u"ࠨ࡫ࡧࡁ࠳࠰࠿ࡷࡧࡵࡷ࡮ࡵ࡮࠾࡝࡟ࠦࡡ࠭࡝ࠩ࠰࠭ࡃ࠮ࡡ࡜ࠣ࡞ࠪࡡࠬ࿝"),XXB7nPT0pRewQGY,YYBlm36zd0Jst18LXwo4.DOTALL|YYBlm36zd0Jst18LXwo4.IGNORECASE)
	if not BKFfNUheLJicblVwky37: return b8Qe150xVaJsnDSv,[]
	XQRKiWSy0hdGgP2cnfCA5ej,ojEYkvba50ryhMV4fWqXTR6zKGlH = BKFfNUheLJicblVwky37[LzYQg91SIxDeOGtCKd5],qowTBnzym3(BKFfNUheLJicblVwky37[LzYQg91SIxDeOGtCKd5])
	return XQRKiWSy0hdGgP2cnfCA5ej,ojEYkvba50ryhMV4fWqXTR6zKGlH
def Iob681D27YqidjpnuaMPlmX3gEOFw():
	epZiXwGxQUa7WrO39syjYkgzL5Hb = SS2OK7hjLagvUAm(mshLJcKH1fv03yRnDOr4ZT,QQdAXWBc2GPw(u"ࠩࡧ࡭ࡨࡺࠧ࿞"),P0qdZI384LKleuo(u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭࿟"),vvWwO3Tx2dAgcijrFXq(u"ࠫࡆࡒࡌࡠࡃࡇࡈࡔࡔࡓࡠ࡚ࡐࡐࠬ࿠"))
	if epZiXwGxQUa7WrO39syjYkgzL5Hb: return epZiXwGxQUa7WrO39syjYkgzL5Hb
	BbkLs5NmEpXdnQch8O7JA1,epZiXwGxQUa7WrO39syjYkgzL5Hb = {},{}
	bKQLYJ2zqvCOARBkZlaITjxVXdiu6 = [nTHXJIiah2qK[dDYUoKi6JFM23p(u"ࠬࡘࡅࡑࡑࡖࠫ࿡")][LzYQg91SIxDeOGtCKd5]]
	if g1gmkxOtc2oeEZHhBiy>m6hwdgP31a2zjN7lkpX(u"࠲࠹࠱࠽࠾ᒃ"): bKQLYJ2zqvCOARBkZlaITjxVXdiu6.append(nTHXJIiah2qK[IjZbnrBJmM2N(u"࠭ࡒࡆࡒࡒࡗࠬ࿢")][qHYIWnOZLPkrQU])
	if i1thmHk7AZquD4cM0fnp62: bKQLYJ2zqvCOARBkZlaITjxVXdiu6.append(nTHXJIiah2qK[shC5qBRV2A0lZ(u"ࠧࡓࡇࡓࡓࡘ࠭࿣")][IgQimel18t])
	for pmbVnokKRir in bKQLYJ2zqvCOARBkZlaITjxVXdiu6:
		Ci4rQ0qV915j2AIkHTbcy = dcLRAZWFzODax2jf0tHCX81pJveNY(nCUMfrlZvuiLe5x,Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠨࡉࡈࡘࠬ࿤"),pmbVnokKRir,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,BmePGjS7FxK6kutUM(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡖࡊࡇࡄࡠࡃࡏࡐࡤࡇࡄࡅࡑࡑࡗࡤ࡞ࡍࡍ࠯࠴ࡷࡹ࠭࿥"))
		if Ci4rQ0qV915j2AIkHTbcy.succeeded:
			oH3N1dY9vLpaDJfnTVP5Z7q = Ci4rQ0qV915j2AIkHTbcy.content
			AlD1PEQYwOydUCHgG462ju = pmbVnokKRir.rsplit(zI3ROAZtiUq42rE9WDST68(u"ࠪ࠳ࠬ࿦"),ddo23ZJtgcY(u"࠳ᒄ"))[LzYQg91SIxDeOGtCKd5]
			gwSnitdDPW4VxkLK5 = YYBlm36zd0Jst18LXwo4.findall(UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠫ࡮ࡪ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡺࡪࡸࡳࡪࡱࡱࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ࿧"),oH3N1dY9vLpaDJfnTVP5Z7q,YYBlm36zd0Jst18LXwo4.DOTALL|YYBlm36zd0Jst18LXwo4.IGNORECASE)
			for DFUIv2KGj9ke,bbi9zrBjAh8tnOVU in gwSnitdDPW4VxkLK5:
				tkjNqgDRv1G9OMAWzVuymcJU = AlD1PEQYwOydUCHgG462ju+UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠬ࠵ࠧ࿨")+DFUIv2KGj9ke+vvWwO3Tx2dAgcijrFXq(u"࠭࠯ࠨ࿩")+DFUIv2KGj9ke+S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠧ࠮ࠩ࿪")+bbi9zrBjAh8tnOVU+VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠨ࠰ࡽ࡭ࡵ࠭࿫")
				if DFUIv2KGj9ke not in list(BbkLs5NmEpXdnQch8O7JA1.keys()):
					BbkLs5NmEpXdnQch8O7JA1[DFUIv2KGj9ke] = []
					epZiXwGxQUa7WrO39syjYkgzL5Hb[DFUIv2KGj9ke] = []
				SAeoCOD3tawuhP8TLJYKMX5n9 = qowTBnzym3(bbi9zrBjAh8tnOVU)
				BbkLs5NmEpXdnQch8O7JA1[DFUIv2KGj9ke].append((bbi9zrBjAh8tnOVU,SAeoCOD3tawuhP8TLJYKMX5n9,tkjNqgDRv1G9OMAWzVuymcJU))
	for DFUIv2KGj9ke in list(BbkLs5NmEpXdnQch8O7JA1.keys()):
		epZiXwGxQUa7WrO39syjYkgzL5Hb[DFUIv2KGj9ke] = sorted(BbkLs5NmEpXdnQch8O7JA1[DFUIv2KGj9ke],reverse=CCxMXuNUEzolDZTKrBJ,key=lambda key: key[qHYIWnOZLPkrQU])
	PGudrhJF8iDkSq96XVHEQZYf5L(mshLJcKH1fv03yRnDOr4ZT,ddo23ZJtgcY(u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬ࿬"),TYf7Dc06PQgy1vEV9(u"ࠪࡅࡑࡒ࡟ࡂࡆࡇࡓࡓ࡙࡟࡙ࡏࡏࠫ࿭"),epZiXwGxQUa7WrO39syjYkgzL5Hb,GMkNL1RXxKFentp0Zh9d)
	return epZiXwGxQUa7WrO39syjYkgzL5Hb
def qowTBnzym3(bbi9zrBjAh8tnOVU):
	SAeoCOD3tawuhP8TLJYKMX5n9 = []
	UCYKgOE8uiFTBHGP52xQ7 = bbi9zrBjAh8tnOVU.split(LAQD5wEkr18bUiGaYen3J(u"ࠫ࠳࠭࿮"))
	for OOLdc9triTa1EGBg in UCYKgOE8uiFTBHGP52xQ7:
		O6zhET172b8nKmsjVBLcRwZXkoUpD = YYBlm36zd0Jst18LXwo4.findall(TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠬࡢࡤࠬࡾ࡞ࡠ࠰ࡢ࠭ࡢ࠯ࡽࡅ࠲ࡠ࡝ࠬࠩ࿯"),OOLdc9triTa1EGBg,YYBlm36zd0Jst18LXwo4.DOTALL)
		i6NFOTe0YVsgGBzXWQPtdEbc8 = []
		for fjKi8zxBwRmM7ElcCQUA in O6zhET172b8nKmsjVBLcRwZXkoUpD:
			if fjKi8zxBwRmM7ElcCQUA.isdigit(): fjKi8zxBwRmM7ElcCQUA = int(fjKi8zxBwRmM7ElcCQUA)
			i6NFOTe0YVsgGBzXWQPtdEbc8.append(fjKi8zxBwRmM7ElcCQUA)
		SAeoCOD3tawuhP8TLJYKMX5n9.append(i6NFOTe0YVsgGBzXWQPtdEbc8)
	return SAeoCOD3tawuhP8TLJYKMX5n9
def WWv46TQhGqKc(SAeoCOD3tawuhP8TLJYKMX5n9):
	bbi9zrBjAh8tnOVU = b8Qe150xVaJsnDSv
	for OOLdc9triTa1EGBg in SAeoCOD3tawuhP8TLJYKMX5n9:
		for fjKi8zxBwRmM7ElcCQUA in OOLdc9triTa1EGBg: bbi9zrBjAh8tnOVU += str(fjKi8zxBwRmM7ElcCQUA)
		bbi9zrBjAh8tnOVU += m6hwdgP31a2zjN7lkpX(u"࠭࠮ࠨ࿰")
	bbi9zrBjAh8tnOVU = bbi9zrBjAh8tnOVU.strip(S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠧ࠯ࠩ࿱"))
	return bbi9zrBjAh8tnOVU
def YqPryjvitICmH(kBjDnsUC8y4):
	EJcfC7seYxiG = {}
	BbkLs5NmEpXdnQch8O7JA1 = Iob681D27YqidjpnuaMPlmX3gEOFw()
	WbN5HnlUGLO6EBM1vK9cej = ccBOVxQkTgGR5z1(kBjDnsUC8y4)
	for DFUIv2KGj9ke in kBjDnsUC8y4:
		if DFUIv2KGj9ke not in list(BbkLs5NmEpXdnQch8O7JA1.keys()): continue
		epZiXwGxQUa7WrO39syjYkgzL5Hb = BbkLs5NmEpXdnQch8O7JA1[DFUIv2KGj9ke]
		p7zHTPBakINxtG3ylXjAwvKfEDS,l75ag8db26Iy04u1LmYRxfWH,kPfXiCJtG3HZympedv1N0LA = epZiXwGxQUa7WrO39syjYkgzL5Hb[LzYQg91SIxDeOGtCKd5]
		ww5RBJWz8japXAlCYqSxgEf0NFVK7G,FNqXBKMYgCPe6itk59AwTnOr1 = W7iMdgkSpm0XbA2(DFUIv2KGj9ke)
		XKYls8p3Tz4HfrJWQyN67m,ky713umSnL4Rsclrf9 = WbN5HnlUGLO6EBM1vK9cej[DFUIv2KGj9ke]
		pt4DMl2jFZsC89 = l75ag8db26Iy04u1LmYRxfWH>FNqXBKMYgCPe6itk59AwTnOr1 and XKYls8p3Tz4HfrJWQyN67m
		mEvj8WVaX6fNFD4eCdgtn5 = CCxMXuNUEzolDZTKrBJ
		if not XKYls8p3Tz4HfrJWQyN67m: hB8mlaNIKzs6PVAktdOFDujLy1xcJW = ddo23ZJtgcY(u"ࠨ࡯࡬ࡷࡸ࡯࡮ࡨࠩ࿲")
		elif not ky713umSnL4Rsclrf9: hB8mlaNIKzs6PVAktdOFDujLy1xcJW = LAQD5wEkr18bUiGaYen3J(u"ࠩࡧ࡭ࡸࡧࡢ࡭ࡧࡧࠫ࿳")
		elif pt4DMl2jFZsC89: hB8mlaNIKzs6PVAktdOFDujLy1xcJW = P0qdZI384LKleuo(u"ࠪࡳࡱࡪࠧ࿴")
		else:
			hB8mlaNIKzs6PVAktdOFDujLy1xcJW = dDYUoKi6JFM23p(u"ࠫ࡬ࡵ࡯ࡥࠩ࿵")
			mEvj8WVaX6fNFD4eCdgtn5 = DD5cFIejQa2X4BgAu9GWPyJ3tC7
		EJcfC7seYxiG[DFUIv2KGj9ke] = mEvj8WVaX6fNFD4eCdgtn5,ww5RBJWz8japXAlCYqSxgEf0NFVK7G,FNqXBKMYgCPe6itk59AwTnOr1,p7zHTPBakINxtG3ylXjAwvKfEDS,l75ag8db26Iy04u1LmYRxfWH,hB8mlaNIKzs6PVAktdOFDujLy1xcJW,kPfXiCJtG3HZympedv1N0LA
	return EJcfC7seYxiG
def NrM3XJ8sD2pEHz(vN2KjutDaTCsUY5x,bbhPijrecW5IazZRBM1sGpLTX,x5xBUWTjGQO=b8Qe150xVaJsnDSv,ruoqJp9SEmk=b8Qe150xVaJsnDSv,JqjvcupbtBkTm=b8Qe150xVaJsnDSv):
	if hDTluNxe7tCwrpqXHzdEcYRfbs: vN2KjutDaTCsUY5x.update(bbhPijrecW5IazZRBM1sGpLTX,x5xBUWTjGQO,ruoqJp9SEmk,JqjvcupbtBkTm)
	else: vN2KjutDaTCsUY5x.update(bbhPijrecW5IazZRBM1sGpLTX,x5xBUWTjGQO+eeN6dTEnkJxI+ruoqJp9SEmk+eeN6dTEnkJxI+JqjvcupbtBkTm)
	return
def DNnEa1tuSBAzFH57GROwxTmg2M(oacnYJr1pe4iC8GdRV9hSmqMk5xg6):
	def rvZhsbN5G9cHFtEVPugqmR(xgIdtzGCDWeX8iA4Zropc7SVj,MbzQZD68npFA,QkhscYJgnEDxyCoOqGt0=LAQD5wEkr18bUiGaYen3J(u"ࠧ࠶࠱࠳࠵࠷࠹࠻࠽࠸࠺ࡣࡥࡧࡩ࡫ࡦࡨࡪ࡬࡮ࡰࡲ࡭࡯ࡱࡳࡵࡷࡹࡴࡶࡸࡺࡼࡾࢀࡁࡃࡅࡇࡉࡋࡍࡈࡊࡌࡎࡐࡒࡔࡏࡑࡓࡕࡗ࡙࡛ࡖࡘ࡚࡜࡞ࠧ࿶")):
		return ((xgIdtzGCDWeX8iA4Zropc7SVj == LzYQg91SIxDeOGtCKd5) and QkhscYJgnEDxyCoOqGt0[LzYQg91SIxDeOGtCKd5]) or (rvZhsbN5G9cHFtEVPugqmR(xgIdtzGCDWeX8iA4Zropc7SVj // MbzQZD68npFA, MbzQZD68npFA, QkhscYJgnEDxyCoOqGt0).lstrip(QkhscYJgnEDxyCoOqGt0[LzYQg91SIxDeOGtCKd5]) + QkhscYJgnEDxyCoOqGt0[xgIdtzGCDWeX8iA4Zropc7SVj % MbzQZD68npFA])
	def ggAOcn7uBNlk(rueKxMOCWU0ohaBY8mIw3VS, wVGecQ548yNtHM2kxn9h3g, L7dow8QMgCz, L0u2XdthxF93HeJUYaAQzDO, rrI5luYt4bHmS1Jn=None, u6FlkReJy0ZqTSXx28DcnfHKGigb7N=None, JJ5MbAOSlIt2pLu7oV08h=None):
		while (L7dow8QMgCz):
			L7dow8QMgCz-=Nh0BWuiSndf(u"࠴ᒅ")
			if (L0u2XdthxF93HeJUYaAQzDO[L7dow8QMgCz]): rueKxMOCWU0ohaBY8mIw3VS = YYBlm36zd0Jst18LXwo4.sub(yST5AHEfvPmcWpwGuh2BJ(u"ࠨ࡜࡝ࡤࠥ࿷") + rvZhsbN5G9cHFtEVPugqmR(L7dow8QMgCz, wVGecQ548yNtHM2kxn9h3g) + P0qdZI384LKleuo(u"ࠢ࡝࡞ࡥࠦ࿸"),  L0u2XdthxF93HeJUYaAQzDO[L7dow8QMgCz], rueKxMOCWU0ohaBY8mIw3VS)
		return rueKxMOCWU0ohaBY8mIw3VS
	oacnYJr1pe4iC8GdRV9hSmqMk5xg6 = oacnYJr1pe4iC8GdRV9hSmqMk5xg6.split(IjZbnrBJmM2N(u"ࠨࡿࠫࠫ࿹"))[qHYIWnOZLPkrQU]
	oacnYJr1pe4iC8GdRV9hSmqMk5xg6 = oacnYJr1pe4iC8GdRV9hSmqMk5xg6.rsplit(uVQd103XyvUce2EBtzbYaC(u"ࠩࡶࡴࡱ࡯ࡴࠨ࿺"))[LzYQg91SIxDeOGtCKd5]+zI3ROAZtiUq42rE9WDST68(u"ࠥࡷࡵࡲࡩࡵࠪࠪࢀࠬ࠯ࠩࠣ࿻")
	FFpgZ0heR8aA = eval(yST5AHEfvPmcWpwGuh2BJ(u"ࠫࡺࡴࡰࡢࡥ࡮ࠬࠬ࿼")+oacnYJr1pe4iC8GdRV9hSmqMk5xg6,{TYf7Dc06PQgy1vEV9(u"ࠬࡨࡡࡴࡧࡑࠫ࿽"):rvZhsbN5G9cHFtEVPugqmR,UUkIBz1sgQ9WfNeG6trKXvu0(u"࠭ࡵ࡯ࡲࡤࡧࡰ࠭࿾"):ggAOcn7uBNlk})
	return FFpgZ0heR8aA
def WaSXqRbONY5mQEZ(code):
	_GrDXAZNfvQpix0=RRIHDFjoW9w7bSfVPhC(u"ࠢ࠱࠳࠵࠷࠹࠻࠶࠸࠺࠼ࡥࡧࡩࡤࡦࡨࡪ࡬࡮ࡰ࡫࡭࡯ࡱࡳࡵࡷࡲࡴࡶࡸࡺࡼࡾࡹࡻࡃࡅࡇࡉࡋࡆࡈࡊࡌࡎࡐࡒࡍࡏࡑࡓࡕࡗ࡙ࡔࡖࡘ࡚࡜࡞ࡠࠫ࠰ࠤ࿿")
	def iinWQAI8qBLSHUKxJsYhebkTg(u6FlkReJy0ZqTSXx28DcnfHKGigb7N,rrI5luYt4bHmS1Jn,IIxZMWbedSjEwXzR0guPDQa7CKmqih):
		xBAcoqvFZTVpX = list(_GrDXAZNfvQpix0)
		OJb9lWBs24VCumvrXSyZeqi7zG = xBAcoqvFZTVpX[TT8Mxv5Wq7nlC9IscdpPUY6(u"࠴ᒆ"):rrI5luYt4bHmS1Jn]
		FbcUxvE17ewlWNBHgS8Jn = xBAcoqvFZTVpX[zI3ROAZtiUq42rE9WDST68(u"࠵ᒇ"):IIxZMWbedSjEwXzR0guPDQa7CKmqih]
		u6FlkReJy0ZqTSXx28DcnfHKGigb7N = list(u6FlkReJy0ZqTSXx28DcnfHKGigb7N)[::-BmePGjS7FxK6kutUM(u"࠷ᒈ")]
		NNkdsEvW9ZBnrP1DgieIUKpSJVq = HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"࠰ᒉ")
		for L7dow8QMgCz,MbzQZD68npFA in enumerate(u6FlkReJy0ZqTSXx28DcnfHKGigb7N):
			if MbzQZD68npFA in OJb9lWBs24VCumvrXSyZeqi7zG: NNkdsEvW9ZBnrP1DgieIUKpSJVq = NNkdsEvW9ZBnrP1DgieIUKpSJVq + OJb9lWBs24VCumvrXSyZeqi7zG.index(MbzQZD68npFA)*rrI5luYt4bHmS1Jn**L7dow8QMgCz
		L0u2XdthxF93HeJUYaAQzDO = Xz3bA2PFENVCUtplu51(u"ࠣࠤက")
		while NNkdsEvW9ZBnrP1DgieIUKpSJVq > yST5AHEfvPmcWpwGuh2BJ(u"࠱ᒊ"):
			L0u2XdthxF93HeJUYaAQzDO = FbcUxvE17ewlWNBHgS8Jn[NNkdsEvW9ZBnrP1DgieIUKpSJVq%IIxZMWbedSjEwXzR0guPDQa7CKmqih] + L0u2XdthxF93HeJUYaAQzDO
			NNkdsEvW9ZBnrP1DgieIUKpSJVq = (NNkdsEvW9ZBnrP1DgieIUKpSJVq - (NNkdsEvW9ZBnrP1DgieIUKpSJVq%IIxZMWbedSjEwXzR0guPDQa7CKmqih))//IIxZMWbedSjEwXzR0guPDQa7CKmqih
		return int(L0u2XdthxF93HeJUYaAQzDO) or BWNPxIG7vqdTy85pjHzUOrK3(u"࠲ᒋ")
	def HZclNyJqLiWX6U1VpgxR7jezO8(OJb9lWBs24VCumvrXSyZeqi7zG,u,nuqcx7edXZvaKQPshSCmDUoAF,i0IrDG6z3JTxSE8OancFC,rrI5luYt4bHmS1Jn,JJ5MbAOSlIt2pLu7oV08h):
		JJ5MbAOSlIt2pLu7oV08h = IjZbnrBJmM2N(u"ࠤࠥခ");
		FbcUxvE17ewlWNBHgS8Jn = zI3ROAZtiUq42rE9WDST68(u"࠳ᒌ")
		while FbcUxvE17ewlWNBHgS8Jn < len(OJb9lWBs24VCumvrXSyZeqi7zG):
			NNkdsEvW9ZBnrP1DgieIUKpSJVq = RRIHDFjoW9w7bSfVPhC(u"࠴ᒍ")
			n2LUbtz5GmywOQi9uDT = Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠥࠦဂ")
			while OJb9lWBs24VCumvrXSyZeqi7zG[FbcUxvE17ewlWNBHgS8Jn] is not nuqcx7edXZvaKQPshSCmDUoAF[rrI5luYt4bHmS1Jn]:
				n2LUbtz5GmywOQi9uDT = zI3ROAZtiUq42rE9WDST68(u"ࠫࠬဃ").join([n2LUbtz5GmywOQi9uDT,OJb9lWBs24VCumvrXSyZeqi7zG[FbcUxvE17ewlWNBHgS8Jn]])
				FbcUxvE17ewlWNBHgS8Jn = FbcUxvE17ewlWNBHgS8Jn + vvWwO3Tx2dAgcijrFXq(u"࠶ᒎ")
			while NNkdsEvW9ZBnrP1DgieIUKpSJVq < len(nuqcx7edXZvaKQPshSCmDUoAF):
				n2LUbtz5GmywOQi9uDT = n2LUbtz5GmywOQi9uDT.replace(nuqcx7edXZvaKQPshSCmDUoAF[NNkdsEvW9ZBnrP1DgieIUKpSJVq],str(NNkdsEvW9ZBnrP1DgieIUKpSJVq))
				NNkdsEvW9ZBnrP1DgieIUKpSJVq = NNkdsEvW9ZBnrP1DgieIUKpSJVq + Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"࠷ᒏ")
			JJ5MbAOSlIt2pLu7oV08h = LAQD5wEkr18bUiGaYen3J(u"ࠬ࠭င").join([JJ5MbAOSlIt2pLu7oV08h,Mmpr0o76iWJvz1kTtfgI8hES(u"࠭ࠧစ").join(map(chr, [iinWQAI8qBLSHUKxJsYhebkTg(n2LUbtz5GmywOQi9uDT,rrI5luYt4bHmS1Jn,ubxGUTt1LraKhVZgpAP(u"࠱࠱ᒐ")) - i0IrDG6z3JTxSE8OancFC]))])
			FbcUxvE17ewlWNBHgS8Jn = FbcUxvE17ewlWNBHgS8Jn + RRIHDFjoW9w7bSfVPhC(u"࠲ᒑ")
		return JJ5MbAOSlIt2pLu7oV08h
	code = code.replace(Nh0BWuiSndf(u"ࠧ࡝ࡰࠪဆ"),DYakr9g4PVU(u"ࠨࠩဇ")).replace(Xz3bA2PFENVCUtplu51(u"ࠩ࡟ࡶࠬဈ"),TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠪࠫဉ"))
	uwQ8G3EKPrdlDVOWUNsT4FmCn = YYBlm36zd0Jst18LXwo4.findall(BWNPxIG7vqdTy85pjHzUOrK3(u"ࠫࡡࢃ࡜ࠩࠤࠫࡠࡼ࠱ࠩࠣ࠮ࠫࡠࡩ࠱ࠩ࠭ࠤࠫࡠࡼ࠱ࠩࠣ࠮ࠫࡠࡩ࠱ࠩ࠭ࠪ࡟ࡨ࠰࠯ࠬࠩ࡞ࡧ࠯࠮ࡢࠩ࡝ࠫࠪည"),code,YYBlm36zd0Jst18LXwo4.DOTALL)
	if uwQ8G3EKPrdlDVOWUNsT4FmCn:
		uwQ8G3EKPrdlDVOWUNsT4FmCn = list(uwQ8G3EKPrdlDVOWUNsT4FmCn[HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"࠲ᒒ")])
		for rTbJ3PF5vIUjaMhuAoe,code in enumerate(uwQ8G3EKPrdlDVOWUNsT4FmCn):
			if code.isdigit(): uwQ8G3EKPrdlDVOWUNsT4FmCn[rTbJ3PF5vIUjaMhuAoe] = int(code)
			else: uwQ8G3EKPrdlDVOWUNsT4FmCn[rTbJ3PF5vIUjaMhuAoe] = code.replace(QTUBCcehw6qPd4x(u"ࠬࡢࠢࠨဋ"),RRIHDFjoW9w7bSfVPhC(u"࠭ࠧဌ"))
		mAW2eIRHTcwr8pxNt1G7ijO0LJBFZ = HZclNyJqLiWX6U1VpgxR7jezO8(*uwQ8G3EKPrdlDVOWUNsT4FmCn)
		return mAW2eIRHTcwr8pxNt1G7ijO0LJBFZ
	return ddo23ZJtgcY(u"ࠧࠨဍ")
def Ae7lvYGQo4E5MwrRn9Xj(YabJfs3q7yjpzvXioO,lsvE0ZYTfKQAzSMWyPBDd2V=b8Qe150xVaJsnDSv):
	if lsvE0ZYTfKQAzSMWyPBDd2V==Mmpr0o76iWJvz1kTtfgI8hES(u"ࠨ࡮ࡲࡻࡪࡸࠧဎ"): YabJfs3q7yjpzvXioO = YYBlm36zd0Jst18LXwo4.sub(LAQD5wEkr18bUiGaYen3J(u"ࡴࠪࠩࡠ࠶࠭࠺ࡃ࠰࡞ࡢࢁ࠲ࡾࠩဏ"),lambda ZmeN7OyXLPCaiAD: ZmeN7OyXLPCaiAD.group(LzYQg91SIxDeOGtCKd5).lower(),YabJfs3q7yjpzvXioO)
	elif lsvE0ZYTfKQAzSMWyPBDd2V==vvWwO3Tx2dAgcijrFXq(u"ࠪࡹࡵࡶࡥࡳࠩတ"): YabJfs3q7yjpzvXioO = YYBlm36zd0Jst18LXwo4.sub(TYf7Dc06PQgy1vEV9(u"ࡶ࡛ࠬࠫ࠱࠯࠼ࡥ࠲ࢀ࡝ࡼ࠴ࢀࠫထ"),lambda ZmeN7OyXLPCaiAD: ZmeN7OyXLPCaiAD.group(LzYQg91SIxDeOGtCKd5).upper(),YabJfs3q7yjpzvXioO)
	return YabJfs3q7yjpzvXioO
def ccBOVxQkTgGR5z1(kBjDnsUC8y4):
	JJzYwMxNTBoIuqGfrQ4OtyC5Hkbji,g8URiqaPVe4chEY = DD5cFIejQa2X4BgAu9GWPyJ3tC7,DD5cFIejQa2X4BgAu9GWPyJ3tC7
	KWfFCYyj7iTlts = jA69Ts3CqJli7.connect(YakNVvKg8rqWUPTxef)
	KWfFCYyj7iTlts.text_factory = str
	Yn98v3MRdasNfWB2SAG6TOV1m4tq = KWfFCYyj7iTlts.cursor()
	if len(kBjDnsUC8y4)==qHYIWnOZLPkrQU: gnkq6szab94A3 = S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠬ࠮ࠢࠨဒ")+kBjDnsUC8y4[LzYQg91SIxDeOGtCKd5]+HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"࠭ࠢࠪࠩဓ")
	else: gnkq6szab94A3 = str(tuple(kBjDnsUC8y4))
	Yn98v3MRdasNfWB2SAG6TOV1m4tq.execute(DYakr9g4PVU(u"ࠧࡔࡇࡏࡉࡈ࡚ࠠࡢࡦࡧࡳࡳࡏࡄ࠭ࡧࡱࡥࡧࡲࡥࡥࠢࡉࡖࡔࡓࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࡛ࠣࡍࡋࡒࡆࠢࡤࡨࡩࡵ࡮ࡊࡆࠣࡍࡓࠦࠧန")+gnkq6szab94A3+yST5AHEfvPmcWpwGuh2BJ(u"ࠨࠢ࠾ࠫပ"))
	tG5TJBEmWonrxFvRdXq76c8febiQVS = Yn98v3MRdasNfWB2SAG6TOV1m4tq.fetchall()
	WbN5HnlUGLO6EBM1vK9cej = {}
	for DFUIv2KGj9ke in kBjDnsUC8y4: WbN5HnlUGLO6EBM1vK9cej[DFUIv2KGj9ke] = (DD5cFIejQa2X4BgAu9GWPyJ3tC7,DD5cFIejQa2X4BgAu9GWPyJ3tC7)
	for DFUIv2KGj9ke,g8URiqaPVe4chEY in tG5TJBEmWonrxFvRdXq76c8febiQVS:
		JJzYwMxNTBoIuqGfrQ4OtyC5Hkbji = CCxMXuNUEzolDZTKrBJ
		g8URiqaPVe4chEY = g8URiqaPVe4chEY==qHYIWnOZLPkrQU
		WbN5HnlUGLO6EBM1vK9cej[DFUIv2KGj9ke] = (JJzYwMxNTBoIuqGfrQ4OtyC5Hkbji,g8URiqaPVe4chEY)
	KWfFCYyj7iTlts.close()
	return WbN5HnlUGLO6EBM1vK9cej
def dyWw4klir2R3uM8DUthJxKP(IrtJbkGzf0wNZUgvuYC7):
	XXxlOLJ9KRjPH382WVCvr6n71 = b8Qe150xVaJsnDSv
	if x76PfMyAp1L2WejkU3.path.exists(IrtJbkGzf0wNZUgvuYC7):
		xgjifnIWe3aDs5kK81vu04U7FE = open(IrtJbkGzf0wNZUgvuYC7,HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠩࡵࡦࠬဖ")).read()
		if i1thmHk7AZquD4cM0fnp62: xgjifnIWe3aDs5kK81vu04U7FE = xgjifnIWe3aDs5kK81vu04U7FE.decode(OVauxZzLI10vcXT74K)
		nkPmNUV9uGH = oJsUwXA0yGOI1mTjxQ(Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠪࡨ࡮ࡩࡴࠨဗ"),xgjifnIWe3aDs5kK81vu04U7FE)
		if nkPmNUV9uGH:
			XXxlOLJ9KRjPH382WVCvr6n71 = {}
			for bb0cYXjevHNo8ZLE7CyrBzWAl9wus in nkPmNUV9uGH.keys():
				XXxlOLJ9KRjPH382WVCvr6n71[bb0cYXjevHNo8ZLE7CyrBzWAl9wus] = []
				for kVfNdbaGtmD72Q in nkPmNUV9uGH[bb0cYXjevHNo8ZLE7CyrBzWAl9wus]:
					E57WK4m31C8,rlqNUcK9vYgkT,YabJfs3q7yjpzvXioO,Q8ZnJhRz2mINwrY6VPf,I6YPOSofrpnTwRm8b,NGQDwOCXx1BZmd9Huc,vv5M4UfJS9ucKEiNbxtnaOZ,wc0Z9FAdf2B1J,XXra5dzn8tcLOxYZIE7pPof49Hh = b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv
					E57WK4m31C8 = kVfNdbaGtmD72Q[LzYQg91SIxDeOGtCKd5]
					rlqNUcK9vYgkT = kVfNdbaGtmD72Q[qHYIWnOZLPkrQU]
					rlqNUcK9vYgkT = dIAn5x3eGWtEVMfHQKoN8g(rlqNUcK9vYgkT)
					YabJfs3q7yjpzvXioO = kVfNdbaGtmD72Q[IgQimel18t]
					Q8ZnJhRz2mINwrY6VPf = kVfNdbaGtmD72Q[VwApyDY1Jc]
					I6YPOSofrpnTwRm8b = kVfNdbaGtmD72Q[NvHugPosYDzRJ]
					NGQDwOCXx1BZmd9Huc = kVfNdbaGtmD72Q[uVQd103XyvUce2EBtzbYaC(u"࠸ᒓ")]
					if len(kVfNdbaGtmD72Q)>BmePGjS7FxK6kutUM(u"࠺ᒔ"): vv5M4UfJS9ucKEiNbxtnaOZ = kVfNdbaGtmD72Q[BmePGjS7FxK6kutUM(u"࠺ᒔ")]
					if len(kVfNdbaGtmD72Q)>TT8Mxv5Wq7nlC9IscdpPUY6(u"࠼ᒕ"): wc0Z9FAdf2B1J = kVfNdbaGtmD72Q[TT8Mxv5Wq7nlC9IscdpPUY6(u"࠼ᒕ")]
					if len(kVfNdbaGtmD72Q)>BWNPxIG7vqdTy85pjHzUOrK3(u"࠾ᒖ"): XXra5dzn8tcLOxYZIE7pPof49Hh = kVfNdbaGtmD72Q[BWNPxIG7vqdTy85pjHzUOrK3(u"࠾ᒖ")]
					if IrtJbkGzf0wNZUgvuYC7==KNTV1H9Dl32a6yxiUEBdvZ7qgr: gLPdo0r2AVEyO1SXB = E57WK4m31C8,rlqNUcK9vYgkT,YabJfs3q7yjpzvXioO,Q8ZnJhRz2mINwrY6VPf,I6YPOSofrpnTwRm8b,NGQDwOCXx1BZmd9Huc,vv5M4UfJS9ucKEiNbxtnaOZ,b8Qe150xVaJsnDSv,XXra5dzn8tcLOxYZIE7pPof49Hh
					else: gLPdo0r2AVEyO1SXB = E57WK4m31C8,rlqNUcK9vYgkT,YabJfs3q7yjpzvXioO,Q8ZnJhRz2mINwrY6VPf,I6YPOSofrpnTwRm8b,NGQDwOCXx1BZmd9Huc,vv5M4UfJS9ucKEiNbxtnaOZ,wc0Z9FAdf2B1J,XXra5dzn8tcLOxYZIE7pPof49Hh
					XXxlOLJ9KRjPH382WVCvr6n71[bb0cYXjevHNo8ZLE7CyrBzWAl9wus].append(gLPdo0r2AVEyO1SXB)
		SacP9lh0WiMUZrGDq = str(XXxlOLJ9KRjPH382WVCvr6n71)
		if i1thmHk7AZquD4cM0fnp62: SacP9lh0WiMUZrGDq = SacP9lh0WiMUZrGDq.encode(OVauxZzLI10vcXT74K)
		open(IrtJbkGzf0wNZUgvuYC7,Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠫࡼࡨࠧဘ")).write(SacP9lh0WiMUZrGDq)
	return XXxlOLJ9KRjPH382WVCvr6n71
def MMUq0NsIxei5bK(TFAmLfwypkzsP1UYCMr8c):
	qQzo6714R2ciNX90U = TFAmLfwypkzsP1UYCMr8c.split(TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠬ࠳ࠧမ"),qHYIWnOZLPkrQU)[LzYQg91SIxDeOGtCKd5]
	drHgqFcWbNv82tVEhDMT5,Bgb2Tkp6fK0CGvWYUZFtAzr,bhNwipmnY26A83qIEyDt0jQTso = b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv
	if   qQzo6714R2ciNX90U==m6hwdgP31a2zjN7lkpX(u"࠭ࡁࡉ࡙ࡄࡏࠬယ")		:	from KUM9ocB3HT			import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==TYf7Dc06PQgy1vEV9(u"ࠧࡂࡍࡒࡅࡒ࠭ရ")		:	from AvLtXWDMhP			import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==Xz3bA2PFENVCUtplu51(u"ࠨࡃࡎࡓࡆࡓࡃࡂࡏࠪလ")	:	from MxkbhgKr40		import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠩࡄࡏ࡜ࡇࡍࠨဝ")		:	from pn57ui6YOm			import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==Mmpr0o76iWJvz1kTtfgI8hES(u"ࠪࡅࡐ࡝ࡁࡎࡖࡘࡆࡊ࠭သ")	:	from QFwfH3Dxpy		import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠫࡆࡒࡁࡓࡃࡅࠫဟ")	:	from SSAx3ubGHY			import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==QQdAXWBc2GPw(u"ࠬࡇࡌࡇࡃࡗࡍࡒࡏࠧဠ")	:	from dtfGrK52o0		import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==ubxGUTt1LraKhVZgpAP(u"࠭ࡁࡍࡍࡄ࡛࡙ࡎࡁࡓࠩအ")	: 	from BFQibafsGj		import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==mQNonhS7CV2BXOv(u"ࠧࡂࡎࡐࡅࡆࡘࡅࡇࠩဢ")	:	from WWw1kMIGUd		import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==Xz3bA2PFENVCUtplu51(u"ࠨࡃࡏࡑࡘ࡚ࡂࡂࠩဣ")	:	from k01kT78jBs		import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==IjZbnrBJmM2N(u"ࠩࡄࡒࡎࡓࡅ࡛ࡋࡇࠫဤ")	:	from a0QPJHw1q4		import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==ubxGUTt1LraKhVZgpAP(u"ࠪࡅࡗࡇࡂࡊࡅࡗࡓࡔࡔࡓࠨဥ"):	from ttqOGsENb7	import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==Xz3bA2PFENVCUtplu51(u"ࠫࡆࡘࡁࡃࡕࡈࡉࡉ࠭ဦ")	:	from CZJ7QPaeh2		import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==vvWwO3Tx2dAgcijrFXq(u"ࠬࡇ࡙ࡍࡑࡏࠫဧ")		:	from IkfcaO1w9y			import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==UUkIBz1sgQ9WfNeG6trKXvu0(u"࠭ࡂࡐࡍࡕࡅࠬဨ")		:	from q7STAvBNhV			import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==uVQd103XyvUce2EBtzbYaC(u"ࠧࡃࡔࡖࡘࡊࡐࠧဩ")	:	from cnEib6j3WM			import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==zI3ROAZtiUq42rE9WDST68(u"ࠨࡅࡌࡑࡆ࠺࠰࠱ࠩဪ")	:	from xekS2QGmuD		import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==ddo23ZJtgcY(u"ࠩࡆࡍࡒࡇ࠴ࡑࠩါ")	:	from d65Z2a3Arf			import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==BWNPxIG7vqdTy85pjHzUOrK3(u"ࠪࡇࡎࡓࡁ࠵ࡗࠪာ")	:	from dzqHvb2nFt			import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠫࡈࡏࡍࡂࡃࡅࡈࡔ࠭ိ")	:	from movfiGTFn2		import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==zI3ROAZtiUq42rE9WDST68(u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡈࠧီ")	:	from QBl6HJObqY		import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==LAQD5wEkr18bUiGaYen3J(u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡂࡘࡑࡕࡏࠬု"):	from SGFOAiU75K	import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==BmePGjS7FxK6kutUM(u"ࠧࡄࡋࡐࡅࡈࡒࡕࡑࠩူ")	:	from Ye1lI5r7E3		import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==BWNPxIG7vqdTy85pjHzUOrK3(u"ࠨࡅࡌࡑࡆࡌࡁࡏࡕࠪေ")	:	from UZhqkX2yzg		import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==Nh0BWuiSndf(u"ࠩࡆࡍࡒࡇࡆࡓࡇࡈࠫဲ")	:	from CCKRgvfWTs		import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==ubxGUTt1LraKhVZgpAP(u"ࠪࡇࡎࡓࡁࡍࡋࡊࡌ࡙࠭ဳ")	:	from qfcDtmraLC		import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==Nh0BWuiSndf(u"ࠫࡈࡏࡍࡂࡐࡒ࡛ࠬဴ")	:	from jeADxZEL0I		import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==mQNonhS7CV2BXOv(u"ࠬࡉࡉࡎࡃ࡚ࡆࡆ࡙ࠧဵ")	:	from kAt5n08um6		import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==shC5qBRV2A0lZ(u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑࠫံ"):	from PWzLngkZar	import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==Nh0BWuiSndf(u"ࠧࡅࡔࡄࡑࡆࡉࡁࡇࡇ့ࠪ")	:	from uS8i1ynxWr		import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==ddo23ZJtgcY(u"ࠨࡆࡕࡅࡒࡇࡓ࠸ࠩး")	:	from h5wnytzoQG		import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==QTUBCcehw6qPd4x(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ္ࠪ")	:	from yozpfunWgq		import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠵်ࠬ")	:	from c7rXmiApNg		import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==DYakr9g4PVU(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠷࠭ျ")	:	from ZcOdVNMvYU		import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==QQdAXWBc2GPw(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠹ࠧြ")	:	from KTWbR9QiUY		import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==QTUBCcehw6qPd4x(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠴ࠨွ")	:	from rcz6XESfRt		import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==Xz3bA2PFENVCUtplu51(u"ࠧࡆࡉ࡜ࡈࡊࡇࡄࠨှ")	:	from uAkoiUHZ2e		import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==Mmpr0o76iWJvz1kTtfgI8hES(u"ࠨࡇࡊ࡝ࡓࡕࡗࠨဿ")	:	from P98kZm1TK7			import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==ddo23ZJtgcY(u"ࠩࡈࡐࡈࡏࡎࡆࡏࡄࠫ၀")	:	from qq8j1zF6m2		import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠪࡉࡑࡏࡆࡗࡋࡇࡉࡔ࠭၁")	:	from oW3JXkvGCM		import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠫࡋࡇࡂࡓࡃࡎࡅࠬ၂")	:	from ODNBEnqV7Q		import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==Xz3bA2PFENVCUtplu51(u"ࠬࡌࡁࡋࡇࡕࡗࡍࡕࡗࠨ၃")	:	from WO3GF0r9ls		import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==BWNPxIG7vqdTy85pjHzUOrK3(u"࠭ࡆࡂࡔࡈࡗࡐࡕࠧ၄")	:	from x32NUS6Tlr		import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==BmePGjS7FxK6kutUM(u"ࠧࡇࡃࡖࡉࡑࡎࡄ࠲ࠩ၅")	:	from zzypDIMWSQ		import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠨࡈࡄࡗࡊࡒࡈࡅ࠴ࠪ၆")	:	from QoahFuteqU		import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==uVQd103XyvUce2EBtzbYaC(u"ࠩࡉࡓࡘ࡚ࡁࠨ၇")		:	from e30XGNEHlq			import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠪࡊ࡚ࡔࡏࡏࡖ࡙ࠫ၈")	:	from FejhUM1r8B		import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==ubxGUTt1LraKhVZgpAP(u"ࠫࡋ࡛ࡓࡉࡃࡕࡘ࡛࠭၉")	:	from ddx8UboLY7		import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==vvWwO3Tx2dAgcijrFXq(u"ࠬࡌࡕࡔࡊࡄࡖ࡛ࡏࡄࡆࡑࠪ၊"):	from cxVDJXldni	import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==ubxGUTt1LraKhVZgpAP(u"࠭ࡇࡐࡑࡊࡐࡊ࡙ࡅࡂࡔࡆࡌࠬ။"):	from rhRb5mEJBi	import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==TYf7Dc06PQgy1vEV9(u"ࠧࡉࡃࡏࡅࡈࡏࡍࡂࠩ၌")	:	from mQAFeP4aYr		import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==ddo23ZJtgcY(u"ࠨࡋࡉࡍࡑࡓࠧ၍")		:	from zb9VgidsAx			import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==TYf7Dc06PQgy1vEV9(u"ࠩࡌࡔ࡙࡜ࠧ၎")		:	from CC4xSVuWXg			import faCzcxFZWbO9ULQs70Y as drHgqFcWbNv82tVEhDMT5,YZtbF9MC8LiySHKjmD4gkxwnsT3dRv as Bgb2Tkp6fK0CGvWYUZFtAzr,i4lR3ISvhqJFGBwcrNtCY2mAZu9 as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠪࡏࡆࡘࡂࡂࡎࡄࡘ࡛࠭၏")	:	from hrmU92paOZ		import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==ddo23ZJtgcY(u"ࠫࡐࡇࡔࡌࡑࡗࡘ࡛࠭ၐ")	:	from Lfbsz0IxHa		import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==IjZbnrBJmM2N(u"ࠬࡑࡁࡕࡍࡒ࡙࡙ࡋࠧၑ")	:	from F97FYjQaNH		import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==dDYUoKi6JFM23p(u"࠭ࡋࡊࡔࡐࡅࡑࡑࠧၒ")	:	from I7kXxKWg5V		import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==vvWwO3Tx2dAgcijrFXq(u"ࠧࡍࡃࡕࡓ࡟ࡇࠧၓ")	:	from D5SKEimOC4			import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==BWNPxIG7vqdTy85pjHzUOrK3(u"ࠨࡎࡒࡈ࡞ࡔࡅࡕࠩၔ")	:	from Yp5diLlFh2		import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==ubxGUTt1LraKhVZgpAP(u"ࠩࡐ࠷࡚࠭ၕ")		:	from pxFlVO8bCG			import faCzcxFZWbO9ULQs70Y as drHgqFcWbNv82tVEhDMT5,YZtbF9MC8LiySHKjmD4gkxwnsT3dRv as Bgb2Tkp6fK0CGvWYUZFtAzr,i4lR3ISvhqJFGBwcrNtCY2mAZu9 as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==TYf7Dc06PQgy1vEV9(u"ࠪࡑࡆ࡙ࡁࡗࡋࡇࡉࡔ࠭ၖ")	:	from MNbutIxi3y		import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==QQdAXWBc2GPw(u"ࠫࡒࡕࡖࡔ࠶ࡘࠫၗ")	:	from hetvLJfylE			import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==LAQD5wEkr18bUiGaYen3J(u"ࠬࡓ࡙ࡄࡋࡐࡅࠬၘ")	:	from quCJpzXv4r			import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==ubxGUTt1LraKhVZgpAP(u"࠭ࡐࡂࡐࡈࡘࠬၙ")		:	from U4Tpcq7NsB			import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==ddo23ZJtgcY(u"ࠧࡒࡈࡌࡐࡒ࠭ၚ")		:	from xxGQlzyA29			import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==BWNPxIG7vqdTy85pjHzUOrK3(u"ࠨࡕࡈࡖࡎࡋࡓࡕࡋࡐࡉࠬၛ"):	from sPWUanR2Jy		import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠩࡖࡌࡆࡈࡁࡌࡃࡗ࡝ࠬၜ")	:	from GVowr1nlcb		import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙ࠬၝ")	:	from LLXhstl7gG		import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠫࡘࡎࡁࡉࡋࡇࡒࡊ࡝ࡓࠨၞ"):	from Ok1PMtrjdl		import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"࡙ࠬࡈࡊࡃ࡙ࡓࡎࡉࡅࠨၟ")	:	from pMKOBAWwbi		import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==RRIHDFjoW9w7bSfVPhC(u"࠭ࡓࡉࡑࡉࡌࡆ࠭ၠ")	:	from d4dNXL87qj			import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠧࡔࡊࡒࡓࡋࡓࡁ࡙ࠩၡ")	:	from ZwecJ5FMHd		import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠨࡕࡋࡓࡔࡌࡎࡆࡖࠪၢ")	:	from GhvBJbZIpX		import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==LAQD5wEkr18bUiGaYen3J(u"ࠩࡖࡌࡔࡕࡆࡑࡔࡒࠫၣ")	:	from AXH64EOWgQ		import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==ubxGUTt1LraKhVZgpAP(u"ࠪࡘࡎࡑࡁࡂࡖࠪၤ")	:	from ypYUCsOKc5			import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==QQdAXWBc2GPw(u"࡙ࠫ࡜ࡆࡖࡐࠪၥ")		:	from X3cLRkjer9			import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠬ࡜ࡁࡓࡄࡒࡒࠬၦ")	:	from jVTygHD9l1			import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"࠭ࡖࡊࡆࡈࡓࡓ࡙ࡁࡆࡏࠪၧ"):	from M97Mn6VQc0		import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠧࡘࡇࡆࡍࡒࡇ࠱ࠨၨ")	:	from CCLjfNHAD2		import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠨ࡙ࡈࡇࡎࡓࡁ࠳ࠩၩ")	:	from ig8IlBb9uH		import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==Mmpr0o76iWJvz1kTtfgI8hES(u"ࠩ࡜ࡅࡖࡕࡔࠨၪ")		:	from WizeJwBnTK			import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==RRIHDFjoW9w7bSfVPhC(u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫၫ")	:	from x4nAtRpgFS		import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	elif qQzo6714R2ciNX90U==ubxGUTt1LraKhVZgpAP(u"ࠫ࡞࡚ࡂࡠࡅࡋࡅࡓࡔࡅࡍࡕࠪၬ"):	from LFDByAkCjo	import Y72YmLgw4vqlHxTCkbeKSicasD as drHgqFcWbNv82tVEhDMT5,kstJfK6jHQWrXDSMRIGB7 as Bgb2Tkp6fK0CGvWYUZFtAzr,WbzmKSZiuOYrBN7oysJ2dUv as bhNwipmnY26A83qIEyDt0jQTso
	return drHgqFcWbNv82tVEhDMT5,Bgb2Tkp6fK0CGvWYUZFtAzr,bhNwipmnY26A83qIEyDt0jQTso
def d0dDAEXWNf(iXRADl2M5E,Hjb64dTft8SzJ,showDialogs):
	mwIxD3GBPgLVc2aq9(MtTygrzXFlQ,dDYUoKi6JFM23p(u"ࠬ࠴࡜ࡵࡆࡲࡻࡳࡲ࡯ࡢࡦ࡬ࡲ࡬ࡀࠠ࡜ࠢࠪၭ")+iXRADl2M5E+TYf7Dc06PQgy1vEV9(u"࠭ࠠ࡞ࠢࠣࠤࡍ࡫ࡡࡥࡧࡵࡷ࠿࡛ࠦࠡࠩၮ")+str(Hjb64dTft8SzJ)+BmePGjS7FxK6kutUM(u"ࠧࠡ࡟ࠪၯ"))
	vN2KjutDaTCsUY5x = F6kGteqcvBXWCKdASUZmnjP()
	vN2KjutDaTCsUY5x.create(TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫၰ"),HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠩํะึ๐ࠠศๆล๊ࠥ็อึࠢส่๊๊แࠡษ็้฼๊่ษࠢอั๊๐ไ่๋ࠢฬ฾ี็ศࠢึ์ๆࠦสษัฦࠤ฾๋ไ๋หࠣะ้ฮࠠศๆ่่ๆࠦๅ็ࠢส่ส์สา่อࠫၱ"))
	aD3XhMLIHycqN = Mmpr0o76iWJvz1kTtfgI8hES(u"࠱࠱࠴࠷ᒗ")*Mmpr0o76iWJvz1kTtfgI8hES(u"࠱࠱࠴࠷ᒗ")
	g2X6BQIp4wCFG1zYf = Nh0BWuiSndf(u"࠲ᒘ")*aD3XhMLIHycqN
	import requests as gehRtQT6u2cZIrB5m3
	Ci4rQ0qV915j2AIkHTbcy = gehRtQT6u2cZIrB5m3.get(iXRADl2M5E,stream=CCxMXuNUEzolDZTKrBJ,headers=Hjb64dTft8SzJ)
	Dmfl1B0yEiQ5F7JCXd = Ci4rQ0qV915j2AIkHTbcy.headers
	Ci4rQ0qV915j2AIkHTbcy.close()
	sXQZafWoKMk14bYydg8 = bytes()
	if not Dmfl1B0yEiQ5F7JCXd:
		if showDialogs: tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ၲ"),LAQD5wEkr18bUiGaYen3J(u"ࠫฬ๊ศา่ส้ัࠦไๆࠢํฮ๊้ๆࠡ็้ࠤฯำๅ๋ๆࠣห้๋ไโࠢส่๊฽ไ้สࠣ์ฬ๊ำษสࠣๆิ๊ࠦไ๊้ࠤ฾์ฯไุ่่๊ࠢษࠡใํࠤฬ๊ล็ฬิ๊ฯࠦวๅะสูࠥฮใࠡ࠰ࠣะึฮࠠหฯ่๎้ࠦวๅ็็ๅ๋ࠥัสࠢฦาึ๏ࠧၳ"))
		vN2KjutDaTCsUY5x.close()
	else:
		if uVQd103XyvUce2EBtzbYaC(u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡌࡦࡰࡪࡸ࡭࠭ၴ") not in list(Dmfl1B0yEiQ5F7JCXd.keys()): GxrpIXlVgNc = LzYQg91SIxDeOGtCKd5
		else: GxrpIXlVgNc = int(Dmfl1B0yEiQ5F7JCXd[Nh0BWuiSndf(u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡍࡧࡱ࡫ࡹ࡮ࠧၵ")])
		mkZPXKTJ6dVB0EqlYjNWzx = str(int(IjZbnrBJmM2N(u"࠴࠴࠵࠶ᒚ")*GxrpIXlVgNc/aD3XhMLIHycqN)/VFjQx6Is28KvzLOmMXtg4GqTwa3(u"࠳࠳࠴࠵࠴࠰ᒙ"))
		NeMyKLqFzsAQ9E7rV = int(GxrpIXlVgNc/g2X6BQIp4wCFG1zYf)+qHYIWnOZLPkrQU
		if P0qdZI384LKleuo(u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡔࡤࡲ࡬࡫ࠧၶ") in list(Dmfl1B0yEiQ5F7JCXd.keys()) and GxrpIXlVgNc>aD3XhMLIHycqN:
			ygYApUTBR7WrF9 = CCxMXuNUEzolDZTKrBJ
			ddL9VXkaKlPnhgi4yMu2pG5UN8 = []
			SDBWVjYQbef1PXy = BmePGjS7FxK6kutUM(u"࠵࠵ᒛ")
			ddL9VXkaKlPnhgi4yMu2pG5UN8.append(str(LzYQg91SIxDeOGtCKd5*GxrpIXlVgNc//SDBWVjYQbef1PXy)+P0qdZI384LKleuo(u"ࠨ࠯ࠪၷ")+str(qHYIWnOZLPkrQU*GxrpIXlVgNc//SDBWVjYQbef1PXy-qHYIWnOZLPkrQU))
			ddL9VXkaKlPnhgi4yMu2pG5UN8.append(str(qHYIWnOZLPkrQU*GxrpIXlVgNc//SDBWVjYQbef1PXy)+IjZbnrBJmM2N(u"ࠩ࠰ࠫၸ")+str(IgQimel18t*GxrpIXlVgNc//SDBWVjYQbef1PXy-qHYIWnOZLPkrQU))
			ddL9VXkaKlPnhgi4yMu2pG5UN8.append(str(IgQimel18t*GxrpIXlVgNc//SDBWVjYQbef1PXy)+QQdAXWBc2GPw(u"ࠪ࠱ࠬၹ")+str(VwApyDY1Jc*GxrpIXlVgNc//SDBWVjYQbef1PXy-qHYIWnOZLPkrQU))
			ddL9VXkaKlPnhgi4yMu2pG5UN8.append(str(VwApyDY1Jc*GxrpIXlVgNc//SDBWVjYQbef1PXy)+Nh0BWuiSndf(u"ࠫ࠲࠭ၺ")+str(NvHugPosYDzRJ*GxrpIXlVgNc//SDBWVjYQbef1PXy-qHYIWnOZLPkrQU))
			ddL9VXkaKlPnhgi4yMu2pG5UN8.append(str(NvHugPosYDzRJ*GxrpIXlVgNc//SDBWVjYQbef1PXy)+UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠬ࠳ࠧၻ")+str(yST5AHEfvPmcWpwGuh2BJ(u"࠺ᒜ")*GxrpIXlVgNc//SDBWVjYQbef1PXy-qHYIWnOZLPkrQU))
			ddL9VXkaKlPnhgi4yMu2pG5UN8.append(str(kke1PDGRBLuY8y(u"࠻ᒝ")*GxrpIXlVgNc//SDBWVjYQbef1PXy)+ddo23ZJtgcY(u"࠭࠭ࠨၼ")+str(yST5AHEfvPmcWpwGuh2BJ(u"࠶ᒞ")*GxrpIXlVgNc//SDBWVjYQbef1PXy-qHYIWnOZLPkrQU))
			ddL9VXkaKlPnhgi4yMu2pG5UN8.append(str(Xz3bA2PFENVCUtplu51(u"࠸ᒠ")*GxrpIXlVgNc//SDBWVjYQbef1PXy)+TYf7Dc06PQgy1vEV9(u"ࠧ࠮ࠩၽ")+str(P0qdZI384LKleuo(u"࠸ᒟ")*GxrpIXlVgNc//SDBWVjYQbef1PXy-qHYIWnOZLPkrQU))
			ddL9VXkaKlPnhgi4yMu2pG5UN8.append(str(QTUBCcehw6qPd4x(u"࠻ᒢ")*GxrpIXlVgNc//SDBWVjYQbef1PXy)+ubxGUTt1LraKhVZgpAP(u"ࠨ࠯ࠪၾ")+str(VFjQx6Is28KvzLOmMXtg4GqTwa3(u"࠻ᒡ")*GxrpIXlVgNc//SDBWVjYQbef1PXy-qHYIWnOZLPkrQU))
			ddL9VXkaKlPnhgi4yMu2pG5UN8.append(str(m6hwdgP31a2zjN7lkpX(u"࠾ᒤ")*GxrpIXlVgNc//SDBWVjYQbef1PXy)+kke1PDGRBLuY8y(u"ࠩ࠰ࠫၿ")+str(BWNPxIG7vqdTy85pjHzUOrK3(u"࠾ᒣ")*GxrpIXlVgNc//SDBWVjYQbef1PXy-qHYIWnOZLPkrQU))
			ddL9VXkaKlPnhgi4yMu2pG5UN8.append(str(zI3ROAZtiUq42rE9WDST68(u"࠹ᒥ")*GxrpIXlVgNc//SDBWVjYQbef1PXy)+HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠪ࠱ࠬႀ"))
			uRfXF6c21vodUHi4syn = float(NeMyKLqFzsAQ9E7rV)/SDBWVjYQbef1PXy
			j6DwGpmL3iF = uRfXF6c21vodUHi4syn/int(qHYIWnOZLPkrQU+uRfXF6c21vodUHi4syn)
		else:
			ygYApUTBR7WrF9 = DD5cFIejQa2X4BgAu9GWPyJ3tC7
			SDBWVjYQbef1PXy = qHYIWnOZLPkrQU
			j6DwGpmL3iF = qHYIWnOZLPkrQU
		mwIxD3GBPgLVc2aq9(MtTygrzXFlQ,IjZbnrBJmM2N(u"ࠫ࠳ࡢࡴࡅࡱࡺࡲࡱࡵࡡࡥࠢࡸࡷ࡮ࡴࡧࠡࡴࡤࡲ࡬࡫ࡳ࠻ࠢ࡞ࠤࠬႁ")+str(ygYApUTBR7WrF9)+DYakr9g4PVU(u"ࠬࠦ࡝ࠡࠢࠣࡈࡴࡽ࡮࡭ࡱࡤࡨࠥࡹࡩࡻࡧ࠽ࠤࡠࠦࠧႂ")+str(GxrpIXlVgNc)+UUkIBz1sgQ9WfNeG6trKXvu0(u"࠭ࠠ࡞ࠩႃ"))
		s9s45taoNBh60XL1zykOmTK3jJCrE,wlcCQq2U06KX3DRI = LzYQg91SIxDeOGtCKd5,LzYQg91SIxDeOGtCKd5
		for GKCQkRuhe5q1IbLNY6xSJfjr3m in range(SDBWVjYQbef1PXy):
			ybF0H85nUohsiRQcpaTfZAKzjMY7wB = Hjb64dTft8SzJ.copy()
			if ygYApUTBR7WrF9: ybF0H85nUohsiRQcpaTfZAKzjMY7wB[Nh0BWuiSndf(u"ࠧࡓࡣࡱ࡫ࡪ࠭ႄ")] = RRIHDFjoW9w7bSfVPhC(u"ࠨࡤࡼࡸࡪࡹ࠽ࠨႅ")+ddL9VXkaKlPnhgi4yMu2pG5UN8[GKCQkRuhe5q1IbLNY6xSJfjr3m]
			Ci4rQ0qV915j2AIkHTbcy = gehRtQT6u2cZIrB5m3.get(iXRADl2M5E,stream=CCxMXuNUEzolDZTKrBJ,headers=ybF0H85nUohsiRQcpaTfZAKzjMY7wB,timeout=ubxGUTt1LraKhVZgpAP(u"࠴࠲࠳ᒦ"))
			for CC1TKGhMY5kni in Ci4rQ0qV915j2AIkHTbcy.iter_content(chunk_size=g2X6BQIp4wCFG1zYf):
				if vN2KjutDaTCsUY5x.iscanceled():
					mwIxD3GBPgLVc2aq9(MtTygrzXFlQ,S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠩ࠱ࡠࡹࡊ࡯ࡸࡰ࡯ࡳࡦࡪࠠࡄࡣࡱࡧࡪࡲࡥࡥࠩႆ"))
					break
				s9s45taoNBh60XL1zykOmTK3jJCrE += j6DwGpmL3iF
				sXQZafWoKMk14bYydg8 += CC1TKGhMY5kni
				if not wlcCQq2U06KX3DRI: wlcCQq2U06KX3DRI = len(CC1TKGhMY5kni)
				if GxrpIXlVgNc: NrM3XJ8sD2pEHz(vN2KjutDaTCsUY5x,Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"࠳࠳࠴ᒧ")*s9s45taoNBh60XL1zykOmTK3jJCrE//NeMyKLqFzsAQ9E7rV,kke1PDGRBLuY8y(u"ࠪะ้ฮࠠศๆ่่ๆࡀ࠭ࠡษ็ะืวࠠาไ่ࠫႇ"),str(S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"࠴࠴࠵࠴࠰ᒨ")*wlcCQq2U06KX3DRI*s9s45taoNBh60XL1zykOmTK3jJCrE//g2X6BQIp4wCFG1zYf//S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"࠴࠴࠵࠴࠰ᒨ"))+P0qdZI384LKleuo(u"ࠫࠥ࠵ࠠࠨႈ")+mkZPXKTJ6dVB0EqlYjNWzx+dDYUoKi6JFM23p(u"ࠬࠦࡍࡃࠩႉ"))
				else: NrM3XJ8sD2pEHz(vN2KjutDaTCsUY5x,wlcCQq2U06KX3DRI*s9s45taoNBh60XL1zykOmTK3jJCrE//g2X6BQIp4wCFG1zYf,uVQd103XyvUce2EBtzbYaC(u"࠭ฬๅสࠣห้๋ไโ࠼࠰ࠫႊ"),str(uVQd103XyvUce2EBtzbYaC(u"࠵࠵࠶࠮࠱ᒩ")*wlcCQq2U06KX3DRI*s9s45taoNBh60XL1zykOmTK3jJCrE//g2X6BQIp4wCFG1zYf//uVQd103XyvUce2EBtzbYaC(u"࠵࠵࠶࠮࠱ᒩ"))+IjZbnrBJmM2N(u"ࠧࠡࡏࡅࠫႋ"))
			Ci4rQ0qV915j2AIkHTbcy.close()
		vN2KjutDaTCsUY5x.close()
		if len(sXQZafWoKMk14bYydg8)<GxrpIXlVgNc and GxrpIXlVgNc>LzYQg91SIxDeOGtCKd5:
			mwIxD3GBPgLVc2aq9(MtTygrzXFlQ,QQdAXWBc2GPw(u"ࠨ࠰࡟ࡸࡉࡵࡷ࡯࡮ࡲࡥࡩࠦࡦࡢ࡫࡯ࡩࡩࠦ࡯ࡳࠢࡦࡥࡳࡩࡥ࡭ࡧࡧࠤࡦࡺ࠺ࠡ࡝ࠣࠫႌ")+str(len(sXQZafWoKMk14bYydg8)//aD3XhMLIHycqN)+P0qdZI384LKleuo(u"ࠩࠣࡑࡇࠦ࡝ࠡࠢࠣࡊࡷࡵ࡭ࠡࡶࡲࡸࡦࡲࠠࡰࡨ࠽ࠤࡠႍࠦࠧ")+mkZPXKTJ6dVB0EqlYjNWzx+Mmpr0o76iWJvz1kTtfgI8hES(u"ࠪࠤࡒࡈࠠ࡞ࠩႎ"))
			juILqxAVNHQrPUi4 = QlaM6yHe0bgh58Vx3BAZD(b8Qe150xVaJsnDSv,kke1PDGRBLuY8y(u"ࠫสฺ๊ศรࠣ์ำื่อࠩႏ"),Nh0BWuiSndf(u"ࠬอำหะาห๊ࠦวๅ็็ๅࠥอไ็ษๅูࠬ႐"),shC5qBRV2A0lZ(u"࠭ลฺษาอࠥาไษࠢส่๊๊แࠨ႑"),dDYUoKi6JFM23p(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ႒"),ddo23ZJtgcY(u"ࠨใื่ࠥ็๊ࠡฮ็ฬࠥอไๆๆไࠤࡡࡴࠠๅๆฦืๆࠦอะอࠣา฼ษࠠโ์ࠣฮา๋๊ๅࠢส่๊๊แࠡ࡞ࡱࠤฯ๋ࠠอๆหࠤࠬ႓")+str(len(sXQZafWoKMk14bYydg8)//aD3XhMLIHycqN)+Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"้ࠩࠣ๏เวษษํฮ๋ࠥๆࠡ็ฯ้ํ฿ࠠࠨ႔")+mkZPXKTJ6dVB0EqlYjNWzx+Mmpr0o76iWJvz1kTtfgI8hES(u"ࠪࠤ๊๐ฺศสส๎ฯࠦ࡜࡯ࠢฯีอࠦฬๅสࠣห้๋ไโ่ࠢีฮࠦรฯำ์ࠤࡡࡴ่ࠠๆࠣฮึ๐ฯࠡษึฮำีวๆࠢส่๊๊แࠡษ็๊ฬ่ีࠡมࠤࠥࠬ႕"))
			if juILqxAVNHQrPUi4==IgQimel18t: sXQZafWoKMk14bYydg8 = d0dDAEXWNf(iXRADl2M5E,Hjb64dTft8SzJ,showDialogs)
			elif juILqxAVNHQrPUi4==qHYIWnOZLPkrQU: mwIxD3GBPgLVc2aq9(MtTygrzXFlQ,VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠫ࠳ࡢࡴࡏࡱࡷࠤࡨࡵ࡭ࡱ࡮ࡨࡸࡪࡪࠠࡥࡱࡺࡲࡱࡵࡡࡥࡧࡧࠤ࡫࡯࡬ࡦࠢ࡬ࡷࠥࡧࡣࡤࡧࡳࡸࡪࡪࠠࡢࡰࡧࠤࡼ࡯࡬࡭ࠢࡥࡩࠥࡻࡳࡦࡦࠪ႖"))
			else: return b8Qe150xVaJsnDSv
			if not sXQZafWoKMk14bYydg8: return b8Qe150xVaJsnDSv
		else: mwIxD3GBPgLVc2aq9(MtTygrzXFlQ,vvWwO3Tx2dAgcijrFXq(u"ࠬ࠴࡜ࡵࡆࡲࡻࡳࡲ࡯ࡢࡦࠣࡗࡺࡩࡣࡦࡧࡧࡩࡩ࠴ࠠࠡࠢࡉ࡭ࡱ࡫ࠠࡔ࡫ࡽࡩ࠿࡛ࠦࠡࠩ႗")+mkZPXKTJ6dVB0EqlYjNWzx+Xz3bA2PFENVCUtplu51(u"࠭ࠠࡎࡄࠣࡡࠬ႘"))
	return sXQZafWoKMk14bYydg8
def zAEf4K3hDsF(QQ8pvXNcBfVkP5rRJ7o):
	return Ci4rQ0qV915j2AIkHTbcy
def CGb8nOoSct2xEhyf0WzUmY(ip=b8Qe150xVaJsnDSv):
	global u26jYNwLID1r3ZtVlJAp87dFkgz
	if u26jYNwLID1r3ZtVlJAp87dFkgz: return u26jYNwLID1r3ZtVlJAp87dFkgz
	MqUOHVZf8JapgwvReP,dHf3gSt5yWFKhPjZRN16iqeoc7O,GGJC7alPKL6MzB8EcnTFuRb4ktrj,sUzapyn0EwSRVvdujG3ADY6hF,SuMo2PeCrq37UhsGWkiwdLX,KKXTfynDsr0izjVN6uSZRP8wJQlo = b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv
	YabJfs3q7yjpzvXioO = mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡪࡲࡺ࡬ࡴ࠴ࡩࡴ࠱ࠪ႙")+ip+VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠨࡁࡲࡹࡹࡶࡵࡵ࠿࡭ࡷࡴࡴࠦࡧ࡫ࡨࡰࡩࡹ࠽ࡪࡲ࠯ࡧࡴࡴࡴࡪࡰࡨࡲࡹ࠲ࡣࡰࡷࡱࡸࡷࡿࠬࡤࡱࡸࡲࡹࡸࡹࡠࡥࡲࡨࡪ࠲ࡲࡦࡩ࡬ࡳࡳ࠲ࡣࡪࡶࡼ࠰ࡹ࡯࡭ࡦࡼࡲࡲࡪ࠭ႚ")
	Hjb64dTft8SzJ = {RRIHDFjoW9w7bSfVPhC(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ႛ"):b8Qe150xVaJsnDSv}
	Ci4rQ0qV915j2AIkHTbcy = dcLRAZWFzODax2jf0tHCX81pJveNY(LtlXH3fvMydAx,ubxGUTt1LraKhVZgpAP(u"ࠪࡋࡊ࡚ࠧႜ"),YabJfs3q7yjpzvXioO,b8Qe150xVaJsnDSv,Hjb64dTft8SzJ,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,dDYUoKi6JFM23p(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡅࡐࡎࡒࡇࡆ࡚ࡉࡐࡐ࠰࠵ࡸࡺࠧႝ"))
	if not Ci4rQ0qV915j2AIkHTbcy.succeeded:
		YabJfs3q7yjpzvXioO = mQNonhS7CV2BXOv(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࡯ࡰ࠮ࡣࡳ࡭࠳ࡩ࡯࡮࠱࡭ࡷࡴࡴ࠯ࠨ႞")+ip+uVQd103XyvUce2EBtzbYaC(u"࠭࠿ࡧ࡫ࡨࡰࡩࡹ࠽ࡲࡷࡨࡶࡾ࠲ࡣࡰࡰࡷ࡭ࡳ࡫࡮ࡵ࠮ࡦࡳࡺࡴࡴࡳࡻ࠯ࡧࡴࡻ࡮ࡵࡴࡼࡇࡴࡪࡥ࠭ࡴࡨ࡫࡮ࡵ࡮ࡏࡣࡰࡩ࠱ࡩࡩࡵࡻ࠯ࡳ࡫࡬ࡳࡦࡶࠪ႟")
		Ci4rQ0qV915j2AIkHTbcy = dcLRAZWFzODax2jf0tHCX81pJveNY(LtlXH3fvMydAx,RRIHDFjoW9w7bSfVPhC(u"ࠧࡈࡇࡗࠫႠ"),YabJfs3q7yjpzvXioO,b8Qe150xVaJsnDSv,Hjb64dTft8SzJ,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,yST5AHEfvPmcWpwGuh2BJ(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡉࡔࡒࡏࡄࡃࡗࡍࡔࡔ࠭࠳ࡰࡧࠫႡ"))
	if Ci4rQ0qV915j2AIkHTbcy.succeeded:
		jLtdbeYiQHnf4SpU2MTly = Ci4rQ0qV915j2AIkHTbcy.content
		YYVMmc86yjhstI = AFIDMBehNx5QH6g21E8kq9JzrLi.loads(jLtdbeYiQHnf4SpU2MTly)
		LDSvblI7BMFrysazfkPc9C2q8OxRp = list(YYVMmc86yjhstI.keys())
		if Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠩ࡬ࡴࠬႢ") in LDSvblI7BMFrysazfkPc9C2q8OxRp: ip = YYVMmc86yjhstI[VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠪ࡭ࡵ࠭Ⴃ")]
		if uVQd103XyvUce2EBtzbYaC(u"ࠫࡨࡵ࡮ࡵ࡫ࡱࡩࡳࡺࠧႤ") in LDSvblI7BMFrysazfkPc9C2q8OxRp: MqUOHVZf8JapgwvReP = YYVMmc86yjhstI[vvWwO3Tx2dAgcijrFXq(u"ࠬࡩ࡯࡯ࡶ࡬ࡲࡪࡴࡴࠨႥ")]
		if QQdAXWBc2GPw(u"࠭ࡣࡰࡷࡱࡸࡷࡿࠧႦ") in LDSvblI7BMFrysazfkPc9C2q8OxRp: dHf3gSt5yWFKhPjZRN16iqeoc7O = YYVMmc86yjhstI[ubxGUTt1LraKhVZgpAP(u"ࠧࡤࡱࡸࡲࡹࡸࡹࠨႧ")]
		if SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠨࡥࡲࡹࡳࡺࡲࡺࡡࡦࡳࡩ࡫ࠧႨ") in LDSvblI7BMFrysazfkPc9C2q8OxRp: GGJC7alPKL6MzB8EcnTFuRb4ktrj = YYVMmc86yjhstI[BmePGjS7FxK6kutUM(u"ࠩࡦࡳࡺࡴࡴࡳࡻࡢࡧࡴࡪࡥࠨႩ")]
		if TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠪࡶࡪ࡭ࡩࡰࡰࠪႪ") in LDSvblI7BMFrysazfkPc9C2q8OxRp: sUzapyn0EwSRVvdujG3ADY6hF = YYVMmc86yjhstI[LAQD5wEkr18bUiGaYen3J(u"ࠫࡷ࡫ࡧࡪࡱࡱࠫႫ")]
		if P0qdZI384LKleuo(u"ࠬࡩࡩࡵࡻࠪႬ") in LDSvblI7BMFrysazfkPc9C2q8OxRp: SuMo2PeCrq37UhsGWkiwdLX = YYVMmc86yjhstI[Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"࠭ࡣࡪࡶࡼࠫႭ")]
		if ddo23ZJtgcY(u"ࠧࡲࡷࡨࡶࡾ࠭Ⴎ") in LDSvblI7BMFrysazfkPc9C2q8OxRp: ip = YYVMmc86yjhstI[vvWwO3Tx2dAgcijrFXq(u"ࠨࡳࡸࡩࡷࡿࠧႯ")]
		if Nh0BWuiSndf(u"ࠩࡦࡳࡺࡴࡴࡳࡻࡆࡳࡩ࡫ࠧႰ") in LDSvblI7BMFrysazfkPc9C2q8OxRp: GGJC7alPKL6MzB8EcnTFuRb4ktrj = YYVMmc86yjhstI[IjZbnrBJmM2N(u"ࠪࡧࡴࡻ࡮ࡵࡴࡼࡇࡴࡪࡥࠨႱ")]
		if ubxGUTt1LraKhVZgpAP(u"ࠫࡷ࡫ࡧࡪࡱࡱࡒࡦࡳࡥࠨႲ") in LDSvblI7BMFrysazfkPc9C2q8OxRp: sUzapyn0EwSRVvdujG3ADY6hF = YYVMmc86yjhstI[kke1PDGRBLuY8y(u"ࠬࡸࡥࡨ࡫ࡲࡲࡓࡧ࡭ࡦࠩႳ")]
		if ddo23ZJtgcY(u"࠭ࡴࡪ࡯ࡨࡾࡴࡴࡥࠨႴ") in LDSvblI7BMFrysazfkPc9C2q8OxRp:
			KKXTfynDsr0izjVN6uSZRP8wJQlo = YYVMmc86yjhstI[uVQd103XyvUce2EBtzbYaC(u"ࠧࡵ࡫ࡰࡩࡿࡵ࡮ࡦࠩႵ")][LAQD5wEkr18bUiGaYen3J(u"ࠨࡷࡷࡧࠬႶ")]
			if KKXTfynDsr0izjVN6uSZRP8wJQlo[LzYQg91SIxDeOGtCKd5] not in [QTUBCcehw6qPd4x(u"ࠩ࠰ࠫႷ"),TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠪ࠯ࠬႸ")]: KKXTfynDsr0izjVN6uSZRP8wJQlo = dDYUoKi6JFM23p(u"ࠫ࠰࠭Ⴙ")+KKXTfynDsr0izjVN6uSZRP8wJQlo
		if VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠬࡵࡦࡧࡵࡨࡸࠬႺ") in LDSvblI7BMFrysazfkPc9C2q8OxRp:
			KKXTfynDsr0izjVN6uSZRP8wJQlo = YYVMmc86yjhstI[Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"࠭࡯ࡧࡨࡶࡩࡹ࠭Ⴛ")]
			if KKXTfynDsr0izjVN6uSZRP8wJQlo>=BmePGjS7FxK6kutUM(u"࠵ᒪ"): KKXTfynDsr0izjVN6uSZRP8wJQlo = QTUBCcehw6qPd4x(u"ࠧࠬࠩႼ")+wLQCTr5lqbsVYeAHdzfhZ1F.strftime(QQdAXWBc2GPw(u"ࠣࠧࡋ࠾ࠪࡓࠢႽ"),wLQCTr5lqbsVYeAHdzfhZ1F.gmtime(KKXTfynDsr0izjVN6uSZRP8wJQlo))
			else: KKXTfynDsr0izjVN6uSZRP8wJQlo = vvWwO3Tx2dAgcijrFXq(u"ࠩ࠰ࠫႾ")+wLQCTr5lqbsVYeAHdzfhZ1F.strftime(VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠥࠩࡍࡀࠥࡎࠤႿ"),wLQCTr5lqbsVYeAHdzfhZ1F.gmtime(-KKXTfynDsr0izjVN6uSZRP8wJQlo))
	u26jYNwLID1r3ZtVlJAp87dFkgz = ip+Xz3bA2PFENVCUtplu51(u"ࠫ࠱࠭Ⴠ")+MqUOHVZf8JapgwvReP+QQdAXWBc2GPw(u"ࠬ࠲ࠧჁ")+dHf3gSt5yWFKhPjZRN16iqeoc7O+Xz3bA2PFENVCUtplu51(u"࠭ࠬࠨჂ")+sUzapyn0EwSRVvdujG3ADY6hF+shC5qBRV2A0lZ(u"ࠧ࠭ࠩჃ")+SuMo2PeCrq37UhsGWkiwdLX+Nh0BWuiSndf(u"ࠨ࠮ࠪჄ")+KKXTfynDsr0izjVN6uSZRP8wJQlo
	u26jYNwLID1r3ZtVlJAp87dFkgz = u26jYNwLID1r3ZtVlJAp87dFkgz.encode(OVauxZzLI10vcXT74K)
	if i1thmHk7AZquD4cM0fnp62: u26jYNwLID1r3ZtVlJAp87dFkgz = u26jYNwLID1r3ZtVlJAp87dFkgz.decode(Nh0BWuiSndf(u"ࠩࡸࡲ࡮ࡩ࡯ࡥࡧࡢࡩࡸࡩࡡࡱࡧࠪჅ"))
	u26jYNwLID1r3ZtVlJAp87dFkgz = ggtn0PzV7aMe(u26jYNwLID1r3ZtVlJAp87dFkgz)
	return u26jYNwLID1r3ZtVlJAp87dFkgz
def JimhUH0SEf6w(FZ0da3otze):
	uGcwKVmjQkL5D,showDialogs = b8Qe150xVaJsnDSv,CCxMXuNUEzolDZTKrBJ
	if FZ0da3otze.count(BmePGjS7FxK6kutUM(u"ࠪࡣࠬ჆"))>=IgQimel18t:
		FZ0da3otze,uGcwKVmjQkL5D = FZ0da3otze.split(VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠫࡤ࠭Ⴧ"),qHYIWnOZLPkrQU)
		uGcwKVmjQkL5D = IjZbnrBJmM2N(u"ࠬࡥࠧ჈")+uGcwKVmjQkL5D
		if TT8Mxv5Wq7nlC9IscdpPUY6(u"࠭࡟ࡏࡑࡇࡍࡆࡒࡏࡈࡕࡢࠫ჉") in uGcwKVmjQkL5D: showDialogs = DD5cFIejQa2X4BgAu9GWPyJ3tC7
		else: showDialogs = CCxMXuNUEzolDZTKrBJ
	return FZ0da3otze,uGcwKVmjQkL5D,showDialogs
def Nl4fJq21uTDvGRIE8iZgaQth6WdF():
	ObL4Rdx1i9K5W = x76PfMyAp1L2WejkU3.path.join(JnlzVBayd7WFKtCOH0,DYakr9g4PVU(u"ࠧࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭჊"))
	UqDaXE9y8rmpJxLIPAoFnbKfucON = LzYQg91SIxDeOGtCKd5
	if x76PfMyAp1L2WejkU3.path.exists(ObL4Rdx1i9K5W):
		for lHXFzMgVqsNRnY0TKmESd in x76PfMyAp1L2WejkU3.listdir(ObL4Rdx1i9K5W):
			if Xz3bA2PFENVCUtplu51(u"ࠨ࠰ࡳࡽࡴ࠭჋") in lHXFzMgVqsNRnY0TKmESd: continue
			if ddo23ZJtgcY(u"ࠩࡢࡣࡵࡿࡣࡢࡥ࡫ࡩࡤࡥࠧ჌") in lHXFzMgVqsNRnY0TKmESd: continue
			xYV8a72btiCTfXgdlk5u1S6pMWy = x76PfMyAp1L2WejkU3.path.join(ObL4Rdx1i9K5W,lHXFzMgVqsNRnY0TKmESd)
			zudAYSMEwx1f4D8pZU3v0sQGkW7F,MJGQBx4rhWt5N3kd1IeFnT = HTuoYBfsP0GE(xYV8a72btiCTfXgdlk5u1S6pMWy)
			UqDaXE9y8rmpJxLIPAoFnbKfucON += zudAYSMEwx1f4D8pZU3v0sQGkW7F
	return UqDaXE9y8rmpJxLIPAoFnbKfucON
def HKcQPmMpjLU6RbwxhX(showDialogs):
	PVdfk4Bstnw2bmN7FQjD = hRWC8YSFvsm4JHOMVIne3jquZ.getSetting(BmePGjS7FxK6kutUM(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴࡭ࡦࡵࡶࡥ࡬࡫ࡳࠨჍ"))
	eCxUgv6j43mfiz = SS2OK7hjLagvUAm(mshLJcKH1fv03yRnDOr4ZT,BmePGjS7FxK6kutUM(u"ࠫࡸࡺࡲࠨ჎"),LAQD5wEkr18bUiGaYen3J(u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࠨ჏"),SbjiWeHLQPoazqwp3cODkd7YxVgn(u"࠭ࡍࡆࡕࡖࡅࡌࡋࡓࠨა"))
	gPGjr07a5z,e1Qav7uXCPkDLJFZn = PVdfk4Bstnw2bmN7FQjD,eCxUgv6j43mfiz
	DD42TSGl7qu6FAeZodsEQWOKw,JKb83QFIyswce4a1C6WXLkSG = b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv
	if qHYIWnOZLPkrQU:
		YabJfs3q7yjpzvXioO = nTHXJIiah2qK[HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠧࡑ࡛ࡗࡌࡔࡔࠧბ")][VwApyDY1Jc]
		sT3ueLokq1riU5FBMWaQA = CGb8nOoSct2xEhyf0WzUmY()
		dHf3gSt5yWFKhPjZRN16iqeoc7O = sT3ueLokq1riU5FBMWaQA.split(P0qdZI384LKleuo(u"ࠨ࠮ࠪგ"))[IgQimel18t]
		UqDaXE9y8rmpJxLIPAoFnbKfucON = Nl4fJq21uTDvGRIE8iZgaQth6WdF()
		j01czpBZWA4hU87dHaryJ5Cu = {VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠩࡸࡷࡪࡸࠧდ"):EtvK0T2LNPcsIrAFlufpM,yST5AHEfvPmcWpwGuh2BJ(u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫე"):cpGrK6qnPi,vvWwO3Tx2dAgcijrFXq(u"ࠫࡨࡵࡵ࡯ࡶࡵࡽࠬვ"):dHf3gSt5yWFKhPjZRN16iqeoc7O,uVQd103XyvUce2EBtzbYaC(u"ࠬ࡯ࡤࡴࠩზ"):hk9Mxv3LzSHl42AUdfs0ejF7qcVw(UqDaXE9y8rmpJxLIPAoFnbKfucON)}
		Ci4rQ0qV915j2AIkHTbcy = dcLRAZWFzODax2jf0tHCX81pJveNY(nCUMfrlZvuiLe5x,Xz3bA2PFENVCUtplu51(u"࠭ࡐࡐࡕࡗࠫთ"),YabJfs3q7yjpzvXioO,j01czpBZWA4hU87dHaryJ5Cu,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡉࡈࡘࡤࡓࡅࡔࡕࡄࡋࡊ࡙࠭࠲ࡵࡷࠫი"))
		if not Ci4rQ0qV915j2AIkHTbcy.succeeded:
			if PVdfk4Bstnw2bmN7FQjD in [b8Qe150xVaJsnDSv,S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠨࡐࡈ࡛ࠬკ")]: gPGjr07a5z = RRIHDFjoW9w7bSfVPhC(u"ࠩࡑࡉ࡜ࡥࡔࡐࡡࡈࡖࡗࡕࡒࠨლ")
			elif PVdfk4Bstnw2bmN7FQjD==uVQd103XyvUce2EBtzbYaC(u"ࠪࡓࡑࡊࠧმ"): gPGjr07a5z = DYakr9g4PVU(u"ࠫࡔࡒࡄࡠࡖࡒࡣࡊࡘࡒࡐࡔࠪნ")
		else:
			KKpERakWdGfgQ5UB0u3cxXqS7oMN = Ci4rQ0qV915j2AIkHTbcy.content
			KKpERakWdGfgQ5UB0u3cxXqS7oMN = oJsUwXA0yGOI1mTjxQ(LAQD5wEkr18bUiGaYen3J(u"ࠬࡲࡩࡴࡶࠪო"),KKpERakWdGfgQ5UB0u3cxXqS7oMN)
			KKpERakWdGfgQ5UB0u3cxXqS7oMN = sorted(KKpERakWdGfgQ5UB0u3cxXqS7oMN,reverse=CCxMXuNUEzolDZTKrBJ,key=lambda key: int(key[LzYQg91SIxDeOGtCKd5]))
			JKb83QFIyswce4a1C6WXLkSG,e1Qav7uXCPkDLJFZn = b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv
			for mXgbP4c0WfqM5EtdT,DDJ1S6usNrfjnozGaQ2Bkl,Hi18qkVDrA4PCxyX5vnLdBh6fg in KKpERakWdGfgQ5UB0u3cxXqS7oMN:
				if mXgbP4c0WfqM5EtdT==ubxGUTt1LraKhVZgpAP(u"࠭࠰ࠨპ"):
					JKb83QFIyswce4a1C6WXLkSG += Hi18qkVDrA4PCxyX5vnLdBh6fg+mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠧ࠻࠼ࠪჟ")
					continue
				if e1Qav7uXCPkDLJFZn: e1Qav7uXCPkDLJFZn += eeN6dTEnkJxI+rC3Tlno96KjLDIvBaSWUbR8+Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠨࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦࠧრ")+hAIp8kmC36T5WFPMSXOwnNbtD+DYakr9g4PVU(u"ࠩ࡟ࡲࡡࡴࠧს")
				ZDzuLdU46Q2wTtRMF = Hi18qkVDrA4PCxyX5vnLdBh6fg.split(eeN6dTEnkJxI)[LzYQg91SIxDeOGtCKd5]
				fXPHo5vUMiEeAzcsyV3ObSw = Xz3bA2PFENVCUtplu51(u"ࠪีุอไสࠢัหฺฯࠠๅๅࠣๅ็฽ࠧტ") if DDJ1S6usNrfjnozGaQ2Bkl else b8Qe150xVaJsnDSv
				e1Qav7uXCPkDLJFZn += Hi18qkVDrA4PCxyX5vnLdBh6fg.replace(ZDzuLdU46Q2wTtRMF,OkuB9nwhD8U1+ZDzuLdU46Q2wTtRMF+fXPHo5vUMiEeAzcsyV3ObSw+hAIp8kmC36T5WFPMSXOwnNbtD)+eeN6dTEnkJxI
			e1Qav7uXCPkDLJFZn = eeN6dTEnkJxI+e1Qav7uXCPkDLJFZn+SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠫࡡࡴ࡜࡯ࠩუ")
			JKb83QFIyswce4a1C6WXLkSG = JKb83QFIyswce4a1C6WXLkSG.strip(UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠬࡀ࠺ࠨფ"))
			DD42TSGl7qu6FAeZodsEQWOKw = hRWC8YSFvsm4JHOMVIne3jquZ.getSetting(RRIHDFjoW9w7bSfVPhC(u"࠭ࡡࡷ࠰ࡳࡶ࡮ࡼࡳ࠲ࠩქ"))
			if e1Qav7uXCPkDLJFZn==eCxUgv6j43mfiz and PVdfk4Bstnw2bmN7FQjD in [m6hwdgP31a2zjN7lkpX(u"ࠧࡐࡎࡇࠫღ"),Nh0BWuiSndf(u"ࠨࡑࡏࡈࡤ࡚ࡏࡠࡇࡕࡖࡔࡘࠧყ")]: gPGjr07a5z = shC5qBRV2A0lZ(u"ࠩࡒࡐࡉ࠭შ")
			else: gPGjr07a5z = SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠪࡒࡊ࡝ࠧჩ")
			PGudrhJF8iDkSq96XVHEQZYf5L(mshLJcKH1fv03yRnDOr4ZT,mQNonhS7CV2BXOv(u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧც"),SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠬࡓࡅࡔࡕࡄࡋࡊ࡙ࠧძ"),e1Qav7uXCPkDLJFZn,t58tnzAgevxkoIOdMFbE2PsD64q0C9)
			hRWC8YSFvsm4JHOMVIne3jquZ.setSetting(uVQd103XyvUce2EBtzbYaC(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡳࡥࡴࡵࡤ࡫ࡪࡹࠧწ"),hk9Mxv3LzSHl42AUdfs0ejF7qcVw(T3Axql94cU0BpO1wudEDtWXsf))
			hRWC8YSFvsm4JHOMVIne3jquZ.setSetting(Mmpr0o76iWJvz1kTtfgI8hES(u"ࠧࡢࡸ࠱ࡴࡷ࡯ࡶࡴ࠳ࠪჭ"),JKb83QFIyswce4a1C6WXLkSG)
			ezoKr8LmnGaVS3Nv = dVRkZo9Daz.md5(SbjiWeHLQPoazqwp3cODkd7YxVgn(u"࠻ᒫ")*JKb83QFIyswce4a1C6WXLkSG.encode(OVauxZzLI10vcXT74K)).hexdigest()
			ezoKr8LmnGaVS3Nv = dVRkZo9Daz.md5(VFjQx6Is28KvzLOmMXtg4GqTwa3(u"࠱࠵ᒬ")*ezoKr8LmnGaVS3Nv.encode(OVauxZzLI10vcXT74K)).hexdigest()
			ezoKr8LmnGaVS3Nv = dVRkZo9Daz.md5(Nh0BWuiSndf(u"࠲࠻ᒭ")*ezoKr8LmnGaVS3Nv.encode(OVauxZzLI10vcXT74K)).hexdigest()
			hRWC8YSFvsm4JHOMVIne3jquZ.setSetting(kke1PDGRBLuY8y(u"ࠨࡣࡹ࠲ࡵࡸࡩࡷࡵ࠵ࠫხ"),ezoKr8LmnGaVS3Nv)
	if showDialogs:
		if gPGjr07a5z in [zI3ROAZtiUq42rE9WDST68(u"ࠩࡒࡐࡉࡥࡔࡐࡡࡈࡖࡗࡕࡒࠨჯ"),Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠪࡒࡊ࡝࡟ࡕࡑࡢࡉࡗࡘࡏࡓࠩჰ")]:
			tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,dDYUoKi6JFM23p(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧჱ"),UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠬํๆศๅู้้ࠣไสࠢไ๎ࠥา็ศิๆࠤํํ๊ࠡๆํืฯࠦๅ็ࠢส่อืๆศ็ฯࠤ࠳࠴่ࠠา๊ࠤฬ๊ๅีๅ็อ่ࠥฯࠡ์ๆ์๋ࠦำษส๊หࠥอไฦ่อี๋ะࠠศๆัหฺࠦศไࠢฦ์ࠥอไาษ๋ฮึࠦวๅะสูࠥฮใࠡล๋ࠤฺ๊ใๅหࠣๅ๏ࠦวๅลึ่ฬฺ้่ࠠา็ࠬჲ"))
		else:
			bJvWMFh8G3eas(BmePGjS7FxK6kutUM(u"࠭ࡲࡪࡩ࡫ࡸࠬჳ"),RRIHDFjoW9w7bSfVPhC(u"ࠧาีสส้ࠦๅ็ࠢส่๊ฮัๆฮࠣษ้๏ࠠๆีอาิ๋๊ࠡษ็ฬึ์วๆฮࠪჴ"),e1Qav7uXCPkDLJFZn,zI3ROAZtiUq42rE9WDST68(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࡣࡱࡵ࡮ࡨࠩჵ"))
			gPGjr07a5z = VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠩࡒࡐࡉ࠭ჶ")
	if gPGjr07a5z!=PVdfk4Bstnw2bmN7FQjD:
		hRWC8YSFvsm4JHOMVIne3jquZ.setSetting(DYakr9g4PVU(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴࡭ࡦࡵࡶࡥ࡬࡫ࡳࠨჷ"),gPGjr07a5z)
		qMGn9u2ckaXejCgUQhYTDP(DD5cFIejQa2X4BgAu9GWPyJ3tC7)
	MOzLidnAcpEobV0ylFwIrs = CCxMXuNUEzolDZTKrBJ if JKb83QFIyswce4a1C6WXLkSG!=DD42TSGl7qu6FAeZodsEQWOKw else DD5cFIejQa2X4BgAu9GWPyJ3tC7
	if MOzLidnAcpEobV0ylFwIrs:
		FNdH0Zq1fD6KtgjLh7xaTPrs = XrloM5pTyK.xd4VjQuvJDC2ms
		XrloM5pTyK.r6rSFTpNl5nqd4s9GbEK8zhoXY,XrloM5pTyK.xd4VjQuvJDC2ms,XrloM5pTyK.jnUMHEBQmux94kPbOZXYaAoheNq3L6,XrloM5pTyK.pYMuE6jbdODCPUH = YRU71oePGNrDj5AOHapluvtMy([QTUBCcehw6qPd4x(u"ࠫࡈ࡚ࡅ࠺ࡆࡖ࠵࠾࡜ࡕ࠱ࡘࡖ࡜ࠬჸ"),ubxGUTt1LraKhVZgpAP(u"ࠬ࡝ࡓࡖࡔࡉࡘ࠶࠿ࡑࡕࡇࡉ࡞࡝࠭ჹ"),vvWwO3Tx2dAgcijrFXq(u"࠭ࡂࡕࡇࡻࡔ࡛࠷࠹ࡖࡔ࡙ࡒ࡚࡙ࡕ࠶ࡊ࡛ࠫჺ"),Xz3bA2PFENVCUtplu51(u"ࠧࡐࡖ࠴࠽ࡏ࡛࠰ࡹࡄࡗ࡙ࡱࡊࡘࠨ჻")])
		EEDRCrobfKFviegnXyJz219U = XrloM5pTyK.xd4VjQuvJDC2ms
		if not FNdH0Zq1fD6KtgjLh7xaTPrs and EEDRCrobfKFviegnXyJz219U and Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠨࡏࡈࡗࡘࡇࡇࡆࡕࡢࡘࡘ࠭ჼ") in ZHIif0JXSYpqh1OKuoR:
			ZHIif0JXSYpqh1OKuoR.remove(dDYUoKi6JFM23p(u"ࠩࡐࡉࡘ࡙ࡁࡈࡇࡖࡣ࡙࡙ࠧჽ"))
			ZHIif0JXSYpqh1OKuoR.append(RRIHDFjoW9w7bSfVPhC(u"ࠪࡑࡊ࡙ࡓࡂࡉࡈࡗࠬჾ"))
		elif FNdH0Zq1fD6KtgjLh7xaTPrs and not EEDRCrobfKFviegnXyJz219U and uVQd103XyvUce2EBtzbYaC(u"ࠫࡒࡋࡓࡔࡃࡊࡉࡘ࠭ჿ") in ZHIif0JXSYpqh1OKuoR:
			ZHIif0JXSYpqh1OKuoR.remove(m6hwdgP31a2zjN7lkpX(u"ࠬࡓࡅࡔࡕࡄࡋࡊ࡙ࠧᄀ"))
			ZHIif0JXSYpqh1OKuoR.append(Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"࠭ࡍࡆࡕࡖࡅࡌࡋࡓࡠࡖࡖࠫᄁ"))
		qMGn9u2ckaXejCgUQhYTDP(DD5cFIejQa2X4BgAu9GWPyJ3tC7)
	return
def LZQYdBUN2FKbj5cgP9zJfx0VE(UdnYNWKeIaopPXDl2ArM3VkyR49S1,DBLTbU4RhJ):
	from socket import socket as EvmDR2G3dP7Hbexu1,AF_INET as S4TFcnYvxCGyBa1ZReLUD6srzI,SOCK_STREAM as gIpbXNR8rzLOKDdv57Z0twCEiF
	Ug2Q9mh48vTHRyLSXzEeKVb135klq = EvmDR2G3dP7Hbexu1(S4TFcnYvxCGyBa1ZReLUD6srzI,gIpbXNR8rzLOKDdv57Z0twCEiF)
	Ug2Q9mh48vTHRyLSXzEeKVb135klq.settimeout(qHYIWnOZLPkrQU)
	DrCzdglG0ut6YkXp1c5J7BMHwU,AAakmzxqR7ZBVWlg = CCxMXuNUEzolDZTKrBJ,LzYQg91SIxDeOGtCKd5
	xhWaiNzZPjTfLQV9b7H382ovXrEKBe = wLQCTr5lqbsVYeAHdzfhZ1F.time()
	try: Ug2Q9mh48vTHRyLSXzEeKVb135klq.connect((UdnYNWKeIaopPXDl2ArM3VkyR49S1,DBLTbU4RhJ))
	except: DrCzdglG0ut6YkXp1c5J7BMHwU = DD5cFIejQa2X4BgAu9GWPyJ3tC7
	reZcQSj7ybTR = wLQCTr5lqbsVYeAHdzfhZ1F.time()
	if DrCzdglG0ut6YkXp1c5J7BMHwU: AAakmzxqR7ZBVWlg = reZcQSj7ybTR-xhWaiNzZPjTfLQV9b7H382ovXrEKBe
	return AAakmzxqR7ZBVWlg
def bb80Orl1IgxV6(showDialogs):
	if showDialogs:
		aVwGA2kFY6u4m = BjMmX1vNrnzSAf(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,QQdAXWBc2GPw(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᄂ"),yST5AHEfvPmcWpwGuh2BJ(u"ࠨี๋ๅࠥ๐โ้็ࠣห้ฮั็ษ่ะࠥอไร่ࠣฬส฻ไศฯࠣ์ฯ์ุ๋ใࠣะ๊๐ูࠡไ๋ห฾ีࠠศๆห๎ฬ์วห๋ࠢห้้วีࠢสู่๊สฯั่อࠥ็๊ࠡษ็ฬึ์วๆฮࠣ࠲࠳ࠦ็ๅࠢอี๏ีࠠหึ฽๎ู้ࠦๆๆํอࠥอไห่฻๎ๆࠦวๅฤ้ࠤฤࠧࠧᄃ"))
	else: aVwGA2kFY6u4m = CCxMXuNUEzolDZTKrBJ
	if aVwGA2kFY6u4m==qHYIWnOZLPkrQU:
		for lHXFzMgVqsNRnY0TKmESd in x76PfMyAp1L2WejkU3.listdir(vIaQF8hqXeiJERYuD):
			if lHXFzMgVqsNRnY0TKmESd.endswith(IjZbnrBJmM2N(u"ࠩ࠱ࡨࡧ࠭ᄄ")) and ubxGUTt1LraKhVZgpAP(u"ࠪࡨࡦࡺࡡࠨᄅ") in lHXFzMgVqsNRnY0TKmESd:
				BqDs7wImSo05JbjR9nLrTzF = x76PfMyAp1L2WejkU3.path.join(vIaQF8hqXeiJERYuD,lHXFzMgVqsNRnY0TKmESd)
				KWfFCYyj7iTlts,Yn98v3MRdasNfWB2SAG6TOV1m4tq = wFSLj4ktCvJgiPlYzsq5M8x(BqDs7wImSo05JbjR9nLrTzF)
				Yn98v3MRdasNfWB2SAG6TOV1m4tq.execute(P0qdZI384LKleuo(u"ࠫࡕࡘࡁࡈࡏࡄࠤ࡫ࡵࡲࡦ࡫ࡪࡲࡤࡱࡥࡺࡵࡀࡲࡴࡁࠧᄆ"))
				Yn98v3MRdasNfWB2SAG6TOV1m4tq.execute(Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠬࡖࡒࡂࡉࡐࡅࠥࡺࡥ࡮ࡲࡢࡷࡹࡵࡲࡦ࠿ࡐࡉࡒࡕࡒ࡚࠽ࠪᄇ"))
				Yn98v3MRdasNfWB2SAG6TOV1m4tq.execute(mQNonhS7CV2BXOv(u"࠭ࡐࡓࡃࡊࡑࡆࠦࡩ࡯ࡶࡨ࡫ࡷ࡯ࡴࡺࡡࡦ࡬ࡪࡩ࡫࠼ࠩᄈ"))
				Yn98v3MRdasNfWB2SAG6TOV1m4tq.execute(TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠧࡑࡔࡄࡋࡒࡇࠠࡰࡲࡷ࡭ࡲ࡯ࡺࡦ࠽ࠪᄉ"))
				Yn98v3MRdasNfWB2SAG6TOV1m4tq.execute(Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠨࡘࡄࡇ࡚࡛ࡍ࠼ࠩᄊ"))
				KWfFCYyj7iTlts.commit()
				KWfFCYyj7iTlts.close()
		if showDialogs: tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬᄋ"),DYakr9g4PVU(u"ࠪฮ๊ะࠠษ่ฯหาูࠦๆๆํอࠥหีๅษะࠤํะๆู์ไࠤัฺ๋๊ࠢๅ์ฬ฿ฯࠡษ็ฬ๏อๆศฬࠣ์ฬ๊ใศึࠣห้๋ำหะา้ฮࠦแ๋ࠢส่อืๆศ็ฯࠫᄌ"))
	return
def PDanwWu4bFAhe3m(b5vd6pFO8YxVu2WCqoiyKIJB,erAiTqfyMQgx9nSPldp0OCWwV7Jab,showDialogs):
	if b5vd6pFO8YxVu2WCqoiyKIJB!=None:
		global TTVZUc0N8S9dpGLagCMbfvwh
		TTVZUc0N8S9dpGLagCMbfvwh = b5vd6pFO8YxVu2WCqoiyKIJB
	if erAiTqfyMQgx9nSPldp0OCWwV7Jab!=None:
		global Iclar5FxeNwHtTvXCEozK4kG
		Iclar5FxeNwHtTvXCEozK4kG = erAiTqfyMQgx9nSPldp0OCWwV7Jab
	if showDialogs!=None:
		global Tfo3HwyzGk
		Tfo3HwyzGk = showDialogs
	return
def WFHszD1iArjGwVRhlM8QIc(ufxrtSb9vkTpPhqG8WK,YabJfs3q7yjpzvXioO,data,headers,allow_redirects,showDialogs,fOzS45youKYdNDqwm61aEI3A,aLwqTHENGm2Q,ecs4ouJGNY6TSH):
	if showDialogs==b8Qe150xVaJsnDSv: ddVrvmbZNlMO7j5uaSw9DxKkWg8R = CCxMXuNUEzolDZTKrBJ if Tfo3HwyzGk==b8Qe150xVaJsnDSv else Tfo3HwyzGk
	else: ddVrvmbZNlMO7j5uaSw9DxKkWg8R = CCxMXuNUEzolDZTKrBJ if showDialogs else DD5cFIejQa2X4BgAu9GWPyJ3tC7
	if ecs4ouJGNY6TSH==b8Qe150xVaJsnDSv: NYgczM85oHZE = CCxMXuNUEzolDZTKrBJ if Iclar5FxeNwHtTvXCEozK4kG==b8Qe150xVaJsnDSv else Iclar5FxeNwHtTvXCEozK4kG
	else: NYgczM85oHZE = CCxMXuNUEzolDZTKrBJ if ecs4ouJGNY6TSH else DD5cFIejQa2X4BgAu9GWPyJ3tC7
	if aLwqTHENGm2Q==b8Qe150xVaJsnDSv: HBJD9fKiTupFgjdw2o = CCxMXuNUEzolDZTKrBJ if TTVZUc0N8S9dpGLagCMbfvwh==b8Qe150xVaJsnDSv else TTVZUc0N8S9dpGLagCMbfvwh
	else: HBJD9fKiTupFgjdw2o = CCxMXuNUEzolDZTKrBJ if aLwqTHENGm2Q else DD5cFIejQa2X4BgAu9GWPyJ3tC7
	if allow_redirects==b8Qe150xVaJsnDSv: bbzSa6ZOsRBgtVpQ4uYGFkc7LAf = CCxMXuNUEzolDZTKrBJ
	else: bbzSa6ZOsRBgtVpQ4uYGFkc7LAf = CCxMXuNUEzolDZTKrBJ if allow_redirects else DD5cFIejQa2X4BgAu9GWPyJ3tC7
	ybF0H85nUohsiRQcpaTfZAKzjMY7wB = {} if headers==b8Qe150xVaJsnDSv else headers
	EEkjQFxOabod08Nr = {} if data==b8Qe150xVaJsnDSv else data
	if fOzS45youKYdNDqwm61aEI3A==yST5AHEfvPmcWpwGuh2BJ(u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠳ࡉࡏࡕࡗࡅࡑࡒ࡟ࡐࡎࡇࡣࡗࡋࡌࡆࡃࡖࡉ࠲࠷ࡳࡵࠩᄍ"): ybF0H85nUohsiRQcpaTfZAKzjMY7wB = {}
	else:
		e81RgrcG2onBw = list(ybF0H85nUohsiRQcpaTfZAKzjMY7wB.keys())
		if QQdAXWBc2GPw(u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭ᄎ") not in e81RgrcG2onBw: ybF0H85nUohsiRQcpaTfZAKzjMY7wB[dDYUoKi6JFM23p(u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧᄏ")] = Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠧࡩࡶࡷࡴࠬᄐ")
		if kke1PDGRBLuY8y(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬᄑ") not in e81RgrcG2onBw: ybF0H85nUohsiRQcpaTfZAKzjMY7wB[dDYUoKi6JFM23p(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ᄒ")] = kIMmsSG9NW6BOjlTpnEcuRzgwK(CCxMXuNUEzolDZTKrBJ)
	return ufxrtSb9vkTpPhqG8WK,YabJfs3q7yjpzvXioO,EEkjQFxOabod08Nr,ybF0H85nUohsiRQcpaTfZAKzjMY7wB,bbzSa6ZOsRBgtVpQ4uYGFkc7LAf,ddVrvmbZNlMO7j5uaSw9DxKkWg8R,fOzS45youKYdNDqwm61aEI3A,HBJD9fKiTupFgjdw2o,NYgczM85oHZE
def Ndw0b1s4ayCoqxtkES3i2(ufxrtSb9vkTpPhqG8WK,YabJfs3q7yjpzvXioO,kTSyagGWsFnolYhMO5fCwvpNuPqR,Hjb64dTft8SzJ,gPpvwzQVkYrG58uD2j,showDialogs,fOzS45youKYdNDqwm61aEI3A,aLwqTHENGm2Q=b8Qe150xVaJsnDSv,ecs4ouJGNY6TSH=b8Qe150xVaJsnDSv):
	ZNXAYzgFWyiJPGt = WFHszD1iArjGwVRhlM8QIc(ufxrtSb9vkTpPhqG8WK,YabJfs3q7yjpzvXioO,kTSyagGWsFnolYhMO5fCwvpNuPqR,Hjb64dTft8SzJ,gPpvwzQVkYrG58uD2j,showDialogs,fOzS45youKYdNDqwm61aEI3A,aLwqTHENGm2Q,ecs4ouJGNY6TSH)
	ufxrtSb9vkTpPhqG8WK,YabJfs3q7yjpzvXioO,EEkjQFxOabod08Nr,ybF0H85nUohsiRQcpaTfZAKzjMY7wB,bbzSa6ZOsRBgtVpQ4uYGFkc7LAf,ddVrvmbZNlMO7j5uaSw9DxKkWg8R,fOzS45youKYdNDqwm61aEI3A,HBJD9fKiTupFgjdw2o,NYgczM85oHZE = ZNXAYzgFWyiJPGt
	MUJCtfYVBLODrFbaZn,wrVWChaBPjl3XLucdoxIEM72t6,uKNTqB5FAPjao2Xg4GEcUzltOksdx,yMAcL5oOp31 = KKRSdoITymChfstN3l6jvOnJMPU(YabJfs3q7yjpzvXioO)
	ahDrn9Jebl7mgKQB8vxVGOqPTk = hRWC8YSFvsm4JHOMVIne3jquZ.getSetting(dDYUoKi6JFM23p(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡤ࡯ࡵࠪᄓ"))
	ddks654iAjgKNp1hOJluQyWHR = hRWC8YSFvsm4JHOMVIne3jquZ.getSetting(kke1PDGRBLuY8y(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡵࡨࡨࡳࡹࠧᄔ"))
	XXS4e7n5chbPYxNkit = hRWC8YSFvsm4JHOMVIne3jquZ.getSetting(dDYUoKi6JFM23p(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡷࡶࡩࡵࡸ࡯ࡹࡻࠪᄕ"))
	VPB1JFvcEbziuRq4M = [Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"࠭ࡳࡤࡴࡤࡴࡪࡵࡰࡴࠩᄖ"),yST5AHEfvPmcWpwGuh2BJ(u"ࠧࡴࡥࡵࡥࡵ࡫ࡲࡢࡲ࡬ࠫᄗ"),TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠨࡵࡦࡶࡦࡶࡩ࡯ࡩࡤࡲࡹ࠭ᄘ"),HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠩࡶࡧࡷࡧࡰࡪࡰࡪࡶࡴࡨ࡯ࡵࠩᄙ"),shC5qBRV2A0lZ(u"ࠪࡷࡨࡸࡡࡱࡧࡸࡴࠬᄚ"),Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠫࡸࡩࡲࡢࡲࡨ࠲ࡩࡵࠧᄛ")]
	P0vORuLS1defAwshTt6H = CCxMXuNUEzolDZTKrBJ if any(Y8aiFZsLKw in YabJfs3q7yjpzvXioO for Y8aiFZsLKw in VPB1JFvcEbziuRq4M) else DD5cFIejQa2X4BgAu9GWPyJ3tC7
	if Mmpr0o76iWJvz1kTtfgI8hES(u"ࠬࠬࡵࡳ࡮ࡀࠫᄜ") in MUJCtfYVBLODrFbaZn and P0vORuLS1defAwshTt6H: xMXdYVHhevyrljQuomI8GNzADJp = MUJCtfYVBLODrFbaZn.rsplit(BmePGjS7FxK6kutUM(u"࠭ࠦࡶࡴ࡯ࡁࠬᄝ"),mmcNLrXtzfpyCkZlvK5VwG2gujh(u"࠳ᒮ"))[qHYIWnOZLPkrQU]
	else: xMXdYVHhevyrljQuomI8GNzADJp = b8Qe150xVaJsnDSv
	dAMh9CGvfcotrV = nTHXJIiah2qK[UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠧࡑ࡛ࡗࡌࡔࡔࠧᄞ")]
	oEskVq6FZexuQnPSalt53 = MUJCtfYVBLODrFbaZn in dAMh9CGvfcotrV or xMXdYVHhevyrljQuomI8GNzADJp in dAMh9CGvfcotrV
	WWhiTPORGeEFA5I0 = nTHXJIiah2qK[vvWwO3Tx2dAgcijrFXq(u"ࠨࡔࡈࡔࡔ࡙ࠧᄟ")]
	r0jYWVhNt4J2RE9L8BDMz1p = MUJCtfYVBLODrFbaZn in WWhiTPORGeEFA5I0 or xMXdYVHhevyrljQuomI8GNzADJp in WWhiTPORGeEFA5I0
	FaoePmAR20Ql9 = oEskVq6FZexuQnPSalt53 or r0jYWVhNt4J2RE9L8BDMz1p
	l4RWjH78NnzPSKGEFdMLOeo = DD5cFIejQa2X4BgAu9GWPyJ3tC7
	QrKJzWNAp7 = CCxMXuNUEzolDZTKrBJ
	U9GEyAJbkrZYdqxSievo8wM4C5K = wrVWChaBPjl3XLucdoxIEM72t6==None and uKNTqB5FAPjao2Xg4GEcUzltOksdx==None and not P0vORuLS1defAwshTt6H
	if U9GEyAJbkrZYdqxSievo8wM4C5K and FaoePmAR20Ql9:
		if oEskVq6FZexuQnPSalt53:
			NgQK75Yd1m0T = dAMh9CGvfcotrV.index(MUJCtfYVBLODrFbaZn)
			qtVNpZybY8wOxaKsnL9joRCId5imz = nTHXJIiah2qK[HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠩࡓ࡝࡙ࡎࡏࡏࡡࡅࡏࡕ࠭ᄠ")][NgQK75Yd1m0T]
			IIYkVq01pleLCZbR = Fk2qc5asKtOQUSIo9[NgQK75Yd1m0T]
			if IIYkVq01pleLCZbR==kke1PDGRBLuY8y(u"ࠪࡐࡎ࡙ࡔࡑࡎࡄ࡝ࠬᄡ"): HBJD9fKiTupFgjdw2o,NYgczM85oHZE,QrKJzWNAp7 = DD5cFIejQa2X4BgAu9GWPyJ3tC7,DD5cFIejQa2X4BgAu9GWPyJ3tC7,DD5cFIejQa2X4BgAu9GWPyJ3tC7
			elif IIYkVq01pleLCZbR==VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠫࡈࡇࡐࡕࡅࡋࡅࠬᄢ"): l4RWjH78NnzPSKGEFdMLOeo = CCxMXuNUEzolDZTKrBJ
		elif r0jYWVhNt4J2RE9L8BDMz1p:
			NgQK75Yd1m0T = WWhiTPORGeEFA5I0.index(MUJCtfYVBLODrFbaZn)
			qtVNpZybY8wOxaKsnL9joRCId5imz = nTHXJIiah2qK[TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠬࡘࡅࡑࡑࡖࡣࡇࡑࡐࠨᄣ")][NgQK75Yd1m0T]
			IIYkVq01pleLCZbR = SmnwfjDprzZhuY[NgQK75Yd1m0T]
	if uKNTqB5FAPjao2Xg4GEcUzltOksdx==b8Qe150xVaJsnDSv: uKNTqB5FAPjao2Xg4GEcUzltOksdx = ahDrn9Jebl7mgKQB8vxVGOqPTk
	elif uKNTqB5FAPjao2Xg4GEcUzltOksdx==None and ddks654iAjgKNp1hOJluQyWHR in [zI3ROAZtiUq42rE9WDST68(u"࠭ࡁࡖࡖࡒࠫᄤ"),UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠧࡂࡅࡆࡉࡕ࡚ࡅࡅࠩᄥ")] and HBJD9fKiTupFgjdw2o: uKNTqB5FAPjao2Xg4GEcUzltOksdx = ahDrn9Jebl7mgKQB8vxVGOqPTk
	if oEskVq6FZexuQnPSalt53 or r0jYWVhNt4J2RE9L8BDMz1p: S9WxYCoO3GDw = zI3ROAZtiUq42rE9WDST68(u"࠴࠹ᒯ")
	elif P0vORuLS1defAwshTt6H: S9WxYCoO3GDw = Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"࠺࠵ᒰ")
	elif fOzS45youKYdNDqwm61aEI3A in FFrjbtTlpU59o0LhkWBAcs1RvfeX7u: S9WxYCoO3GDw = zI3ROAZtiUq42rE9WDST68(u"࠶࠶ᒱ")
	elif fOzS45youKYdNDqwm61aEI3A==zI3ROAZtiUq42rE9WDST68(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡕࡉ࡛ࡋࡒࡔࡑࡢࡘࡗࡇࡎࡔࡎࡄࡘࡊ࠳࠱ࡴࡶࠪᄦ"): S9WxYCoO3GDw = mQNonhS7CV2BXOv(u"࠸࠰ᒲ")
	elif fOzS45youKYdNDqwm61aEI3A==ddo23ZJtgcY(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡔࡕࡇࡍࡇࡢࡘࡗࡇࡎࡔࡎࡄࡘࡊ࠳࠱ࡴࡶࠪᄧ"): S9WxYCoO3GDw = Xz3bA2PFENVCUtplu51(u"࠲࠱ᒳ")
	elif LAQD5wEkr18bUiGaYen3J(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡌ࡙ࡄࡑࠬᄨ") in fOzS45youKYdNDqwm61aEI3A: S9WxYCoO3GDw = Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"࠸࠲ᒴ")
	elif kke1PDGRBLuY8y(u"ࠫࡘࡎࡏࡇࡊࡄࠫᄩ") in fOzS45youKYdNDqwm61aEI3A: S9WxYCoO3GDw = Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"࠹࠸ᒵ")
	elif Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠬࡉࡉࡎࡃ࠷࡙ࠬᄪ") in fOzS45youKYdNDqwm61aEI3A: S9WxYCoO3GDw = mmcNLrXtzfpyCkZlvK5VwG2gujh(u"࠵࠹ᒶ")
	elif Mmpr0o76iWJvz1kTtfgI8hES(u"࠭ࡁࡉ࡙ࡄࡏࠬᄫ") in fOzS45youKYdNDqwm61aEI3A: S9WxYCoO3GDw = ddo23ZJtgcY(u"࠶࠵ᒷ")
	elif TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠧࡄࡋࡐࡅࡑࡏࡇࡉࡖࠪᄬ") in fOzS45youKYdNDqwm61aEI3A: S9WxYCoO3GDw = ddo23ZJtgcY(u"࠷࠶ᒸ")
	elif DYakr9g4PVU(u"ࠨࡅࡌࡑࡆࡉࡌࡖࡄ࡚ࡓࡗࡑࠧᄭ") in fOzS45youKYdNDqwm61aEI3A: S9WxYCoO3GDw = IjZbnrBJmM2N(u"࠹࠰ᒹ")
	elif vvWwO3Tx2dAgcijrFXq(u"ࠩࡄࡏࡔࡇࡍࠨᄮ") in fOzS45youKYdNDqwm61aEI3A: S9WxYCoO3GDw = kke1PDGRBLuY8y(u"࠲࠶ᒺ")
	elif DYakr9g4PVU(u"ࠪࡅࡐ࡝ࡁࡎࠩᄯ") in fOzS45youKYdNDqwm61aEI3A: S9WxYCoO3GDw = VFjQx6Is28KvzLOmMXtg4GqTwa3(u"࠴࠲ᒻ")
	elif TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠶࠭ᄰ") in fOzS45youKYdNDqwm61aEI3A: S9WxYCoO3GDw = vvWwO3Tx2dAgcijrFXq(u"࠴࠳ᒼ")
	elif P0qdZI384LKleuo(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠹ࠧᄱ") in fOzS45youKYdNDqwm61aEI3A: S9WxYCoO3GDw = SbjiWeHLQPoazqwp3cODkd7YxVgn(u"࠹࠴ᒽ")
	elif BmePGjS7FxK6kutUM(u"࠭ࡈࡂࡎࡄࡇࡎࡓࡁࠨᄲ") in fOzS45youKYdNDqwm61aEI3A: S9WxYCoO3GDw = dDYUoKi6JFM23p(u"࠸࠵ᒾ")
	else: S9WxYCoO3GDw = LAQD5wEkr18bUiGaYen3J(u"࠶࠻ᒿ")
	tqizermI4BoQp1DGbYRLxFgKlNy9 = (wrVWChaBPjl3XLucdoxIEM72t6!=None)
	i1iydfOXlCYkVqbZ0 = (uKNTqB5FAPjao2Xg4GEcUzltOksdx!=None and ddks654iAjgKNp1hOJluQyWHR!=dDYUoKi6JFM23p(u"ࠧࡔࡖࡒࡔࠬᄳ"))
	if tqizermI4BoQp1DGbYRLxFgKlNy9 and not P0vORuLS1defAwshTt6H: yicQV3gj4q(dDYUoKi6JFM23p(u"ࠨฬไ฽๏๊ࠠษำ๋็ุ๐ࠠาไ่ࠫᄴ"),wrVWChaBPjl3XLucdoxIEM72t6)
	elif i1iydfOXlCYkVqbZ0: yicQV3gj4q(dDYUoKi6JFM23p(u"ࠩอๅ฾๐ไࠡࡆࡑࡗࠥืโๆࠩᄵ"),uKNTqB5FAPjao2Xg4GEcUzltOksdx)
	if tqizermI4BoQp1DGbYRLxFgKlNy9:
		GYl6AScxQKmB4aEet3vrhXVjp = {LAQD5wEkr18bUiGaYen3J(u"ࠥ࡬ࡹࡺࡰࠣᄶ"):wrVWChaBPjl3XLucdoxIEM72t6,UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠦ࡭ࡺࡴࡱࡵࠥᄷ"):wrVWChaBPjl3XLucdoxIEM72t6}
		JQYFItpiS0GKWTn1HLOC7uDkN = wrVWChaBPjl3XLucdoxIEM72t6
	else: GYl6AScxQKmB4aEet3vrhXVjp,JQYFItpiS0GKWTn1HLOC7uDkN = {},b8Qe150xVaJsnDSv
	if i1iydfOXlCYkVqbZ0:
		import urllib3.util.connection as wmnclRQJTp9EH32OU5xjy0qDfVr
		ozJd6QCKGkXjOPMmaNq = Iyi1anzf2uqjJKM5(wmnclRQJTp9EH32OU5xjy0qDfVr,ahDrn9Jebl7mgKQB8vxVGOqPTk)
	pFHeJBv2WAPSD,dM73wSoBq80FpIXY6Pb1mTAZyue,Ede3nm9tcg2,zeDnBAolhFNMQxVY0WpL,CD7Q290dWhOiRw,verify = bbzSa6ZOsRBgtVpQ4uYGFkc7LAf,fOzS45youKYdNDqwm61aEI3A,ufxrtSb9vkTpPhqG8WK,DD5cFIejQa2X4BgAu9GWPyJ3tC7,DD5cFIejQa2X4BgAu9GWPyJ3tC7,yMAcL5oOp31
	if l4RWjH78NnzPSKGEFdMLOeo: CD7Q290dWhOiRw = CCxMXuNUEzolDZTKrBJ
	if FaoePmAR20Ql9 or bbzSa6ZOsRBgtVpQ4uYGFkc7LAf: pFHeJBv2WAPSD = DD5cFIejQa2X4BgAu9GWPyJ3tC7
	if oEskVq6FZexuQnPSalt53: Ede3nm9tcg2 = TYf7Dc06PQgy1vEV9(u"ࠬࡖࡏࡔࡖࠪᄸ")
	GXNZCDRs3E1V,UUF24APJXw0DzpoENvys1Zf3kRj = -qHYIWnOZLPkrQU,UUkIBz1sgQ9WfNeG6trKXvu0(u"࠭ࡕ࡯࡭ࡱࡳࡼࡴࠠࡆࡴࡵࡳࡷ࠭ᄹ")
	ixzpUWVsH03eN87 = DD5cFIejQa2X4BgAu9GWPyJ3tC7
	global GrYC8nRD4ZpzWiO1NE6Vg
	if not GrYC8nRD4ZpzWiO1NE6Vg: GrYC8nRD4ZpzWiO1NE6Vg = SS2OK7hjLagvUAm(mshLJcKH1fv03yRnDOr4ZT,Xz3bA2PFENVCUtplu51(u"ࠧࡥ࡫ࡦࡸࠬᄺ"),SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫᄻ"),ddo23ZJtgcY(u"ࠩࡉࡓࡗ࡝ࡁࡓࡆࡖࠫᄼ"))
	yyEBqH25zMFxZVgeAoS4vUNc0kIsf = []
	while MUJCtfYVBLODrFbaZn not in yyEBqH25zMFxZVgeAoS4vUNc0kIsf and MUJCtfYVBLODrFbaZn in list(GrYC8nRD4ZpzWiO1NE6Vg.keys()):
		yyEBqH25zMFxZVgeAoS4vUNc0kIsf.append(MUJCtfYVBLODrFbaZn)
		MUJCtfYVBLODrFbaZn = GrYC8nRD4ZpzWiO1NE6Vg[MUJCtfYVBLODrFbaZn]
	import requests as gehRtQT6u2cZIrB5m3
	for s9s45taoNBh60XL1zykOmTK3jJCrE in range(TT8Mxv5Wq7nlC9IscdpPUY6(u"࠿ᓀ")):
		oaBw59UTVYgG = CCxMXuNUEzolDZTKrBJ
		ip6CohvO5Tya9mFWVf3JdY1qL = DD5cFIejQa2X4BgAu9GWPyJ3tC7
		try:
			if s9s45taoNBh60XL1zykOmTK3jJCrE: dM73wSoBq80FpIXY6Pb1mTAZyue = LAQD5wEkr18bUiGaYen3J(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤࡘࡅࡒࡗࡈࡗ࡙࡙࠭࠲ࡵࡷࠫᄽ")
			if P0vORuLS1defAwshTt6H or not tqizermI4BoQp1DGbYRLxFgKlNy9: IYuvgrd2fS(QQdAXWBc2GPw(u"ࠫࡗࡋࡑࡖࡇࡖࡘࡘࡢࡴࡐࡒࡈࡒࡤ࡛ࡒࡍࠩᄾ"),MUJCtfYVBLODrFbaZn,EEkjQFxOabod08Nr,ybF0H85nUohsiRQcpaTfZAKzjMY7wB,dM73wSoBq80FpIXY6Pb1mTAZyue,Ede3nm9tcg2)
			try: Ci4rQ0qV915j2AIkHTbcy.close()
			except: pass
			GSh0nJxEXgZjd48u7mBwWOeafyAp5b = MUJCtfYVBLODrFbaZn
			Ci4rQ0qV915j2AIkHTbcy = gehRtQT6u2cZIrB5m3.request(Ede3nm9tcg2,MUJCtfYVBLODrFbaZn,data=EEkjQFxOabod08Nr,headers=ybF0H85nUohsiRQcpaTfZAKzjMY7wB,verify=verify,allow_redirects=pFHeJBv2WAPSD,timeout=S9WxYCoO3GDw,proxies=GYl6AScxQKmB4aEet3vrhXVjp)
			if RRIHDFjoW9w7bSfVPhC(u"࠳࠱࠲ᓁ")<=Ci4rQ0qV915j2AIkHTbcy.status_code<=shC5qBRV2A0lZ(u"࠴࠻࠼ᓂ"):
				if not zeDnBAolhFNMQxVY0WpL:
					EKmYPk8CHqpo = list(Ci4rQ0qV915j2AIkHTbcy.headers.keys())
					if HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧᄿ") in EKmYPk8CHqpo: MUJCtfYVBLODrFbaZn = Ci4rQ0qV915j2AIkHTbcy.headers[TYf7Dc06PQgy1vEV9(u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨᅀ")]
					elif shC5qBRV2A0lZ(u"ࠧ࡭ࡱࡦࡥࡹ࡯࡯࡯ࠩᅁ") in EKmYPk8CHqpo: MUJCtfYVBLODrFbaZn = Ci4rQ0qV915j2AIkHTbcy.headers[Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠨ࡮ࡲࡧࡦࡺࡩࡰࡰࠪᅂ")]
					else: zeDnBAolhFNMQxVY0WpL = CCxMXuNUEzolDZTKrBJ
					if not zeDnBAolhFNMQxVY0WpL: MUJCtfYVBLODrFbaZn = MUJCtfYVBLODrFbaZn.encode(HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠩ࡯ࡥࡹ࡯࡮࠮࠳ࠪᅃ"),Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠪ࡭࡬ࡴ࡯ࡳࡧࠪᅄ")).decode(OVauxZzLI10vcXT74K,QTUBCcehw6qPd4x(u"ࠫ࡮࡭࡮ࡰࡴࡨࠫᅅ"))
					if FaoePmAR20Ql9 and Ci4rQ0qV915j2AIkHTbcy.status_code==Xz3bA2PFENVCUtplu51(u"࠵࠳࠻ᓃ"):
						pFHeJBv2WAPSD = bbzSa6ZOsRBgtVpQ4uYGFkc7LAf
						Ede3nm9tcg2 = ufxrtSb9vkTpPhqG8WK
						zeDnBAolhFNMQxVY0WpL = CCxMXuNUEzolDZTKrBJ
						IPNQAS3HEFO10
				if not zeDnBAolhFNMQxVY0WpL or bbzSa6ZOsRBgtVpQ4uYGFkc7LAf:
					if UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠬ࡮ࡴࡵࡲࠪᅆ") not in MUJCtfYVBLODrFbaZn:
						ZzKk9N840boIO3VGgDMn2Y = Wl2eu1PavfQ(GSh0nJxEXgZjd48u7mBwWOeafyAp5b,BWNPxIG7vqdTy85pjHzUOrK3(u"࠭ࡵࡳ࡮ࠪᅇ"))
						MUJCtfYVBLODrFbaZn = ZzKk9N840boIO3VGgDMn2Y+RRIHDFjoW9w7bSfVPhC(u"ࠧ࠰ࠩᅈ")+MUJCtfYVBLODrFbaZn.lstrip(BmePGjS7FxK6kutUM(u"ࠨ࠱ࠪᅉ"))
				if MUJCtfYVBLODrFbaZn!=GSh0nJxEXgZjd48u7mBwWOeafyAp5b:
					GrYC8nRD4ZpzWiO1NE6Vg[GSh0nJxEXgZjd48u7mBwWOeafyAp5b] = MUJCtfYVBLODrFbaZn
					ixzpUWVsH03eN87 = CCxMXuNUEzolDZTKrBJ
				if not zeDnBAolhFNMQxVY0WpL and bbzSa6ZOsRBgtVpQ4uYGFkc7LAf and not Gz7MH0glBw8Eb(MUJCtfYVBLODrFbaZn): IPNQAS3HEFO10
			elif Xz3bA2PFENVCUtplu51(u"࠹࠺࠶ᓅ")<=Ci4rQ0qV915j2AIkHTbcy.status_code<=TT8Mxv5Wq7nlC9IscdpPUY6(u"࠸࠽࠾ᓄ"):
				Ci4rQ0qV915j2AIkHTbcy.reason = Ci4rQ0qV915j2AIkHTbcy.content
				CD7Q290dWhOiRw = CCxMXuNUEzolDZTKrBJ
			GSh0nJxEXgZjd48u7mBwWOeafyAp5b = Ci4rQ0qV915j2AIkHTbcy.url
			GXNZCDRs3E1V = Ci4rQ0qV915j2AIkHTbcy.status_code
			UUF24APJXw0DzpoENvys1Zf3kRj = Ci4rQ0qV915j2AIkHTbcy.reason
			Ci4rQ0qV915j2AIkHTbcy.raise_for_status()
			ip6CohvO5Tya9mFWVf3JdY1qL = CCxMXuNUEzolDZTKrBJ
		except gehRtQT6u2cZIrB5m3.exceptions.HTTPError as uXp8Hv2nDt:
			pass
		except gehRtQT6u2cZIrB5m3.exceptions.Timeout as uXp8Hv2nDt:
			if hDTluNxe7tCwrpqXHzdEcYRfbs: UUF24APJXw0DzpoENvys1Zf3kRj = str(uXp8Hv2nDt.message).split(dDYUoKi6JFM23p(u"ࠩ࠽ࠤࠬᅊ"))[qHYIWnOZLPkrQU]
			else: UUF24APJXw0DzpoENvys1Zf3kRj = str(uXp8Hv2nDt).split(yST5AHEfvPmcWpwGuh2BJ(u"ࠪ࠾ࠥ࠭ᅋ"))[qHYIWnOZLPkrQU]
		except gehRtQT6u2cZIrB5m3.exceptions.ConnectionError as uXp8Hv2nDt:
			try: DXh6Ta4KnjN = uXp8Hv2nDt.message[LzYQg91SIxDeOGtCKd5]
			except: DXh6Ta4KnjN = str(uXp8Hv2nDt)
			dUwOenuDhB35cGRakoy4 = YYBlm36zd0Jst18LXwo4.findall(DYakr9g4PVU(u"ࠦࡡࡡࡅࡳࡴࡱࡳࠥ࠮࡜ࡥ࠭ࠬࡠࡢࠦࠨ࠯ࠬࡂ࠭ࠬࠨᅌ"),DXh6Ta4KnjN)
			if not dUwOenuDhB35cGRakoy4: dUwOenuDhB35cGRakoy4 = YYBlm36zd0Jst18LXwo4.findall(ddo23ZJtgcY(u"ࠧ࠲ࠠࡦࡴࡵࡳࡷࡢࠨࠩ࡞ࡧ࠯࠮࠲ࠠࠨࠪ࠱࠮ࡄ࠯ࠧࠣᅍ"),DXh6Ta4KnjN)
			if not dUwOenuDhB35cGRakoy4:
				n7aARWi2jDouFcCtLgEvHhdV4XPGZ5 = YYBlm36zd0Jst18LXwo4.findall(QQdAXWBc2GPw(u"ࠨ࠺ࠡࠪ࠱࠮ࡄ࠯࠺࠯ࠬࡂࠬࡡࡪࠫࠪ࠼ࠥᅎ"),DXh6Ta4KnjN)
				if n7aARWi2jDouFcCtLgEvHhdV4XPGZ5: dUwOenuDhB35cGRakoy4 = [n7aARWi2jDouFcCtLgEvHhdV4XPGZ5[LzYQg91SIxDeOGtCKd5][qHYIWnOZLPkrQU],n7aARWi2jDouFcCtLgEvHhdV4XPGZ5[LzYQg91SIxDeOGtCKd5][LzYQg91SIxDeOGtCKd5]]
			if not dUwOenuDhB35cGRakoy4: dUwOenuDhB35cGRakoy4 = YYBlm36zd0Jst18LXwo4.findall(Mmpr0o76iWJvz1kTtfgI8hES(u"ࠢ࠻ࠪ࡟ࡨ࠰࠯࠺ࠡࠪ࠱࠮ࡄ࠯ࠧࠣᅏ"),DXh6Ta4KnjN)
			if not dUwOenuDhB35cGRakoy4: dUwOenuDhB35cGRakoy4 = YYBlm36zd0Jst18LXwo4.findall(VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠣࠢࠫࡠࡩ࠱ࠩ࡞ࠢࠫ࠲࠯ࡅࠩࠨࠤᅐ"),DXh6Ta4KnjN)
			try: GXNZCDRs3E1V,UUF24APJXw0DzpoENvys1Zf3kRj = dUwOenuDhB35cGRakoy4[LzYQg91SIxDeOGtCKd5]
			except: GXNZCDRs3E1V,UUF24APJXw0DzpoENvys1Zf3kRj = -shC5qBRV2A0lZ(u"࠷ᓆ"),DXh6Ta4KnjN
		except gehRtQT6u2cZIrB5m3.exceptions.RequestException as uXp8Hv2nDt:
			if hDTluNxe7tCwrpqXHzdEcYRfbs: UUF24APJXw0DzpoENvys1Zf3kRj = uXp8Hv2nDt.message
			else: UUF24APJXw0DzpoENvys1Zf3kRj = str(uXp8Hv2nDt)
		except:
			oaBw59UTVYgG = DD5cFIejQa2X4BgAu9GWPyJ3tC7
			try: GXNZCDRs3E1V = Ci4rQ0qV915j2AIkHTbcy.status_code
			except: pass
			try: UUF24APJXw0DzpoENvys1Zf3kRj = Ci4rQ0qV915j2AIkHTbcy.reason
			except: pass
		UUF24APJXw0DzpoENvys1Zf3kRj = str(UUF24APJXw0DzpoENvys1Zf3kRj)
		mwIxD3GBPgLVc2aq9(MtTygrzXFlQ,S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠩࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗࡡࡺࡒࡆࡕࡓࡓࡓ࡙ࡅࠡࠢࡆࡳࡩ࡫࠺ࠡ࡝ࠣࠫᅑ")+str(GXNZCDRs3E1V)+Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠪࠤࡢࠦࠠࠡࡔࡨࡥࡸࡵ࡮࠻ࠢ࡞ࠤࠬᅒ")+UUF24APJXw0DzpoENvys1Zf3kRj+Mmpr0o76iWJvz1kTtfgI8hES(u"ࠫࠥࡣࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭ᅓ")+fOzS45youKYdNDqwm61aEI3A+TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠬࠦ࡝࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫᅔ")+YabJfs3q7yjpzvXioO+RRIHDFjoW9w7bSfVPhC(u"࠭ࠠ࡞ࠩᅕ"))
		if U9GEyAJbkrZYdqxSievo8wM4C5K and FaoePmAR20Ql9 and oaBw59UTVYgG and not CD7Q290dWhOiRw and GXNZCDRs3E1V!=zI3ROAZtiUq42rE9WDST68(u"࠸࠰࠱ᓇ"):
			MUJCtfYVBLODrFbaZn = qtVNpZybY8wOxaKsnL9joRCId5imz
			CD7Q290dWhOiRw = CCxMXuNUEzolDZTKrBJ
			continue
		if oaBw59UTVYgG: break
	if not ip6CohvO5Tya9mFWVf3JdY1qL and yyEBqH25zMFxZVgeAoS4vUNc0kIsf:
		for url in yyEBqH25zMFxZVgeAoS4vUNc0kIsf: del GrYC8nRD4ZpzWiO1NE6Vg[url]
		ixzpUWVsH03eN87 = CCxMXuNUEzolDZTKrBJ
	if ixzpUWVsH03eN87:
		PGudrhJF8iDkSq96XVHEQZYf5L(mshLJcKH1fv03yRnDOr4ZT,HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪᅖ"),DYakr9g4PVU(u"ࠨࡈࡒࡖ࡜ࡇࡒࡅࡕࠪᅗ"),GrYC8nRD4ZpzWiO1NE6Vg,Q49IsrlSuYRAVbGKhwdckLDOetF2PZ)
		GrYC8nRD4ZpzWiO1NE6Vg = {}
	if uKNTqB5FAPjao2Xg4GEcUzltOksdx!=None and ddks654iAjgKNp1hOJluQyWHR!=Mmpr0o76iWJvz1kTtfgI8hES(u"ࠩࡖࡘࡔࡖࠧᅘ"): wmnclRQJTp9EH32OU5xjy0qDfVr.create_connection = ozJd6QCKGkXjOPMmaNq
	if ddks654iAjgKNp1hOJluQyWHR==TYf7Dc06PQgy1vEV9(u"ࠪࡅࡑ࡝ࡁ࡚ࡕࠪᅙ") and HBJD9fKiTupFgjdw2o: uKNTqB5FAPjao2Xg4GEcUzltOksdx = None
	if not ip6CohvO5Tya9mFWVf3JdY1qL and wrVWChaBPjl3XLucdoxIEM72t6==None and fOzS45youKYdNDqwm61aEI3A not in FFrjbtTlpU59o0LhkWBAcs1RvfeX7u:
		yABitW02UXORGEJQPsTujcL = n9dSEJTBOWlY6.format_exc()
		if yABitW02UXORGEJQPsTujcL!=LAQD5wEkr18bUiGaYen3J(u"ࠫࡓࡵ࡮ࡦࡖࡼࡴࡪࡀࠠࡏࡱࡱࡩࡡࡴࠧᅚ"): Pft6y0LvwSh48iYg7b.stderr.write(yABitW02UXORGEJQPsTujcL)
	Z8VU1cMugRwIjL2fpSyPJFHokYrqa = BwV6rAIldfsGyK7oeJT053()
	if P0vORuLS1defAwshTt6H: GSh0nJxEXgZjd48u7mBwWOeafyAp5b = xMXdYVHhevyrljQuomI8GNzADJp
	if not GSh0nJxEXgZjd48u7mBwWOeafyAp5b: GSh0nJxEXgZjd48u7mBwWOeafyAp5b = MUJCtfYVBLODrFbaZn
	Z8VU1cMugRwIjL2fpSyPJFHokYrqa.url = GSh0nJxEXgZjd48u7mBwWOeafyAp5b
	Z8VU1cMugRwIjL2fpSyPJFHokYrqa.scrape = P0vORuLS1defAwshTt6H
	try: FDTNW3Iv2rM7u8nKlhEQpxiqOzLXRY = Ci4rQ0qV915j2AIkHTbcy.content
	except: FDTNW3Iv2rM7u8nKlhEQpxiqOzLXRY = b8Qe150xVaJsnDSv
	try: PBiZSbtjJUDqhmn72Wf4Cw = Ci4rQ0qV915j2AIkHTbcy.headers
	except: PBiZSbtjJUDqhmn72Wf4Cw = {}
	try: WWRPD1EMSen4aTgBl3U5jd0QIf = Ci4rQ0qV915j2AIkHTbcy.cookies.get_dict()
	except: WWRPD1EMSen4aTgBl3U5jd0QIf = {}
	try: Ci4rQ0qV915j2AIkHTbcy.close()
	except: pass
	if i1thmHk7AZquD4cM0fnp62:
		try: FDTNW3Iv2rM7u8nKlhEQpxiqOzLXRY = FDTNW3Iv2rM7u8nKlhEQpxiqOzLXRY.decode(OVauxZzLI10vcXT74K)
		except: pass
	GXNZCDRs3E1V = int(GXNZCDRs3E1V)
	Z8VU1cMugRwIjL2fpSyPJFHokYrqa.code = GXNZCDRs3E1V
	Z8VU1cMugRwIjL2fpSyPJFHokYrqa.reason = UUF24APJXw0DzpoENvys1Zf3kRj
	Z8VU1cMugRwIjL2fpSyPJFHokYrqa.content = FDTNW3Iv2rM7u8nKlhEQpxiqOzLXRY
	Z8VU1cMugRwIjL2fpSyPJFHokYrqa.headers = PBiZSbtjJUDqhmn72Wf4Cw
	Z8VU1cMugRwIjL2fpSyPJFHokYrqa.cookies = WWRPD1EMSen4aTgBl3U5jd0QIf
	Z8VU1cMugRwIjL2fpSyPJFHokYrqa.succeeded = ip6CohvO5Tya9mFWVf3JdY1qL
	Z8VU1cMugRwIjL2fpSyPJFHokYrqa.scrapernumber = b8Qe150xVaJsnDSv
	Z8VU1cMugRwIjL2fpSyPJFHokYrqa.scraperserver = b8Qe150xVaJsnDSv
	Z8VU1cMugRwIjL2fpSyPJFHokYrqa.scraperurl = b8Qe150xVaJsnDSv
	if hDTluNxe7tCwrpqXHzdEcYRfbs or isinstance(Z8VU1cMugRwIjL2fpSyPJFHokYrqa.content,str): R5wg9cqKmQuSkh6v = Z8VU1cMugRwIjL2fpSyPJFHokYrqa.content.lower()
	else: R5wg9cqKmQuSkh6v = b8Qe150xVaJsnDSv
	xMLBRWcjiauQdHK9t23YsUrz = (Mmpr0o76iWJvz1kTtfgI8hES(u"ࠬࡩ࡬ࡰࡷࡧࡪࡱࡧࡲࡦࠩᅛ") in R5wg9cqKmQuSkh6v or yST5AHEfvPmcWpwGuh2BJ(u"࠭ࡧࡰࡱࡪࡰࡪ࠭ᅜ") in R5wg9cqKmQuSkh6v) and R5wg9cqKmQuSkh6v.count(SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠧࡳࡧࡦࡥࡵࡺࡣࡩࡣࠪᅝ"))>LAQD5wEkr18bUiGaYen3J(u"࠲ᓈ") and QQdAXWBc2GPw(u"ࠨࡈࡄࡗࡊࡒࡈࡅ࠳ࠪᅞ") not in fOzS45youKYdNDqwm61aEI3A and Mmpr0o76iWJvz1kTtfgI8hES(u"ࠩࡵࡩࡨࡧࡰࡵࡥ࡫ࡥ࠲ࡺ࡯࡬ࡧࡱࠫᅟ") not in R5wg9cqKmQuSkh6v and not P0vORuLS1defAwshTt6H
	if GXNZCDRs3E1V==LAQD5wEkr18bUiGaYen3J(u"࠳࠲࠳ᓉ") and xMLBRWcjiauQdHK9t23YsUrz: Z8VU1cMugRwIjL2fpSyPJFHokYrqa.succeeded = DD5cFIejQa2X4BgAu9GWPyJ3tC7
	if Z8VU1cMugRwIjL2fpSyPJFHokYrqa.succeeded and U9GEyAJbkrZYdqxSievo8wM4C5K and FaoePmAR20Ql9:
		Eqh4xYr9VWQSc2kf0biID = kke1PDGRBLuY8y(u"ࠪࡇࡆࡖࡔࡄࡊࡄࠫᅠ")+EEkjQFxOabod08Nr[mQNonhS7CV2BXOv(u"ࠫ࡯ࡵࡢࠨᅡ")].upper().replace(TYf7Dc06PQgy1vEV9(u"ࠬࡍࡅࡕࠩᅢ"),b8Qe150xVaJsnDSv) if l4RWjH78NnzPSKGEFdMLOeo else IIYkVq01pleLCZbR
		chmoCAX8ab7kIirTfJy6YM3zsGq4(Eqh4xYr9VWQSc2kf0biID)
	if not Z8VU1cMugRwIjL2fpSyPJFHokYrqa.succeeded and U9GEyAJbkrZYdqxSievo8wM4C5K:
		fu2taQeqLwhr6SCZ7pKJPB8vHNsGic = (P0qdZI384LKleuo(u"࠭ࡣ࡭ࡱࡸࡨ࡫ࡲࡡࡳࡧࠪᅣ") in R5wg9cqKmQuSkh6v and m6hwdgP31a2zjN7lkpX(u"ࠧࡳࡣࡼࠤ࡮ࡪ࠺ࠡࠩᅤ") in R5wg9cqKmQuSkh6v)
		cFK7451XEPSsOvRLabyCdhHqm3IZU = (BmePGjS7FxK6kutUM(u"ࠨ࠷ࠣࡷࡪࡩࠧᅥ") in R5wg9cqKmQuSkh6v and DYakr9g4PVU(u"ࠩࡥࡶࡴࡽࡳࡦࡴࠪᅦ") in R5wg9cqKmQuSkh6v)
		k5thYxC3oX8VcAGw1FfDLpeJ70uK = (GXNZCDRs3E1V in [uVQd103XyvUce2EBtzbYaC(u"࠶࠳࠷ᓊ")] and QQdAXWBc2GPw(u"ࠪࡩࡷࡸ࡯ࡳࠢࡦࡳࡩ࡫࠺ࠡ࠳࠳࠶࠵࠭ᅧ") in R5wg9cqKmQuSkh6v)
		JkLoaINQyD2GRuEOHZ4 = (ubxGUTt1LraKhVZgpAP(u"ࠫࡤࡩࡦࡠࡥ࡫ࡰࡤ࠭ᅨ") in R5wg9cqKmQuSkh6v and zI3ROAZtiUq42rE9WDST68(u"ࠬࡩࡨࡢ࡮࡯ࡩࡳ࡭ࡥ࠮ࠩᅩ") in R5wg9cqKmQuSkh6v)
		if   xMLBRWcjiauQdHK9t23YsUrz: UUF24APJXw0DzpoENvys1Zf3kRj = kke1PDGRBLuY8y(u"࠭ࡂ࡭ࡱࡦ࡯ࡪࡪࠠࡣࡻࠣࡶࡪࡩࡡࡱࡶࡦ࡬ࡦ࠭ᅪ")
		elif fu2taQeqLwhr6SCZ7pKJPB8vHNsGic: UUF24APJXw0DzpoENvys1Zf3kRj = S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠧࡃ࡮ࡲࡧࡰ࡫ࡤࠡࡤࡼࠤࡨࡲ࡯ࡶࡦࡩࡰࡦࡸࡥࠨᅫ")
		elif cFK7451XEPSsOvRLabyCdhHqm3IZU: UUF24APJXw0DzpoENvys1Zf3kRj = mQNonhS7CV2BXOv(u"ࠨࡄ࡯ࡳࡨࡱࡥࡥࠢࡥࡽࠥ࠻ࠠࡴࡧࡦࡳࡳࡪࡳࠡࡤࡵࡳࡼࡹࡥࡳࠢࡦ࡬ࡪࡩ࡫ࠨᅬ")
		elif k5thYxC3oX8VcAGw1FfDLpeJ70uK: UUF24APJXw0DzpoENvys1Zf3kRj = BmePGjS7FxK6kutUM(u"ࠩࡅࡰࡴࡩ࡫ࡦࡦࠣࡦࡾࠦࡣ࡭ࡱࡸࡨ࡫ࡲࡡࡳࡧࠣࡥࡨࡩࡥࡴࡵࠣࡨࡪࡴࡩࡦࡦࠪᅭ")
		elif JkLoaINQyD2GRuEOHZ4: UUF24APJXw0DzpoENvys1Zf3kRj = VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠪࡆࡱࡵࡣ࡬ࡧࡧࠤࡧࡿࠠࡤ࡮ࡲࡹࡩ࡬࡬ࡢࡴࡨࠤࡸ࡫ࡣࡶࡴ࡬ࡸࡾࠦࡣࡩࡧࡦ࡯ࠬᅮ")
		else: UUF24APJXw0DzpoENvys1Zf3kRj = str(UUF24APJXw0DzpoENvys1Zf3kRj)
		if fOzS45youKYdNDqwm61aEI3A in KV4XpEahzG5: pass
		elif fOzS45youKYdNDqwm61aEI3A in FFrjbtTlpU59o0LhkWBAcs1RvfeX7u:
			mwIxD3GBPgLVc2aq9(WG2BfeyzMa,EECz06teoykrNFfq(QQ8pvXNcBfVkP5rRJ7o)+S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠫࠥࠦࡄࡪࡴࡨࡧࡹࠦࡣࡰࡰࡱࡩࡨࡺࡩࡰࡰࠣࡪࡦ࡯࡬ࡦࡦࠣࠤࠥࡉ࡯ࡥࡧ࠽ࠤࡠࠦࠧᅯ")+str(GXNZCDRs3E1V)+BmePGjS7FxK6kutUM(u"ࠬࠦ࡝ࠡࠢࠣࡖࡪࡧࡳࡰࡰ࠽ࠤࡠࠦࠧᅰ")+UUF24APJXw0DzpoENvys1Zf3kRj+QTUBCcehw6qPd4x(u"࠭ࠠ࡞ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨᅱ")+fOzS45youKYdNDqwm61aEI3A+shC5qBRV2A0lZ(u"ࠧࠡ࡟ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭ᅲ")+MUJCtfYVBLODrFbaZn+ubxGUTt1LraKhVZgpAP(u"ࠨࠢࡠࠫᅳ"))
		else: mwIxD3GBPgLVc2aq9(WG2BfeyzMa,EECz06teoykrNFfq(QQ8pvXNcBfVkP5rRJ7o)+P0qdZI384LKleuo(u"ࠩࠣࠤࠥࡊࡩࡳࡧࡦࡸࠥࡩ࡯࡯ࡰࡨࡧࡹ࡯࡯࡯ࠢࡩࡥ࡮ࡲࡥࡥࠢࠣࠤࡈࡵࡤࡦ࠼ࠣ࡟ࠥ࠭ᅴ")+str(GXNZCDRs3E1V)+mQNonhS7CV2BXOv(u"ࠪࠤࡢࠦࠠࠡࡔࡨࡥࡸࡵ࡮࠻ࠢ࡞ࠤࠬᅵ")+UUF24APJXw0DzpoENvys1Zf3kRj+Mmpr0o76iWJvz1kTtfgI8hES(u"ࠫࠥࡣࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭ᅶ")+fOzS45youKYdNDqwm61aEI3A+DYakr9g4PVU(u"ࠬࠦ࡝࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫᅷ")+MUJCtfYVBLODrFbaZn+BmePGjS7FxK6kutUM(u"࠭ࠠ࡞ࠩᅸ"))
		poUi8L3stav0jGwVfFHXAbNd = xMXdYVHhevyrljQuomI8GNzADJp if P0vORuLS1defAwshTt6H else SgrGWuAHcLKBQMJetb9(MUJCtfYVBLODrFbaZn)
		if hDTluNxe7tCwrpqXHzdEcYRfbs and isinstance(poUi8L3stav0jGwVfFHXAbNd,unicode): poUi8L3stav0jGwVfFHXAbNd = poUi8L3stav0jGwVfFHXAbNd.encode(OVauxZzLI10vcXT74K)
		if FaoePmAR20Ql9: poUi8L3stav0jGwVfFHXAbNd = poUi8L3stav0jGwVfFHXAbNd.split(uVQd103XyvUce2EBtzbYaC(u"ࠧ࠰ࠩᅹ"))[-qHYIWnOZLPkrQU]
		Na2orbSjcLY0R1Zl = str(UUF24APJXw0DzpoENvys1Zf3kRj)+kke1PDGRBLuY8y(u"ࠨ࡞ࡱࠬࠥ࠭ᅺ")+poUi8L3stav0jGwVfFHXAbNd+VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠩࠣ࠭ࠬᅻ")
		if GXNZCDRs3E1V in [-qHYIWnOZLPkrQU,-IgQimel18t] or xMLBRWcjiauQdHK9t23YsUrz or fu2taQeqLwhr6SCZ7pKJPB8vHNsGic or cFK7451XEPSsOvRLabyCdhHqm3IZU or k5thYxC3oX8VcAGw1FfDLpeJ70uK or JkLoaINQyD2GRuEOHZ4:
			Z8VU1cMugRwIjL2fpSyPJFHokYrqa.code = -VwApyDY1Jc
			Z8VU1cMugRwIjL2fpSyPJFHokYrqa.reason = UUF24APJXw0DzpoENvys1Zf3kRj
			if NYgczM85oHZE:
				yexF0nl2OtBv3 = HnKshijkpEbLC4lVyN(ufxrtSb9vkTpPhqG8WK,MUJCtfYVBLODrFbaZn,EEkjQFxOabod08Nr,ybF0H85nUohsiRQcpaTfZAKzjMY7wB,bbzSa6ZOsRBgtVpQ4uYGFkc7LAf,ddVrvmbZNlMO7j5uaSw9DxKkWg8R,fOzS45youKYdNDqwm61aEI3A,GXNZCDRs3E1V,UUF24APJXw0DzpoENvys1Zf3kRj)
				if yexF0nl2OtBv3.succeeded: return yexF0nl2OtBv3
		aVwGA2kFY6u4m = CCxMXuNUEzolDZTKrBJ
		if (ddks654iAjgKNp1hOJluQyWHR==LAQD5wEkr18bUiGaYen3J(u"ࠪࡅࡘࡑࠧᅼ") or XXS4e7n5chbPYxNkit==ddo23ZJtgcY(u"ࠫࡆ࡙ࡋࠨᅽ")) and (HBJD9fKiTupFgjdw2o or NYgczM85oHZE):
			aVwGA2kFY6u4m = YdsxuIoEqU(GXNZCDRs3E1V,Na2orbSjcLY0R1Zl,fOzS45youKYdNDqwm61aEI3A,ddVrvmbZNlMO7j5uaSw9DxKkWg8R)
			if aVwGA2kFY6u4m and ddks654iAjgKNp1hOJluQyWHR==kke1PDGRBLuY8y(u"ࠬࡇࡓࡌࠩᅾ"): ddks654iAjgKNp1hOJluQyWHR = dDYUoKi6JFM23p(u"࠭ࡁࡄࡅࡈࡔ࡙ࡋࡄࠨᅿ")
			else: ddks654iAjgKNp1hOJluQyWHR = BmePGjS7FxK6kutUM(u"ࠧࡓࡇࡍࡉࡈ࡚ࡅࡅࠩᆀ")
			if aVwGA2kFY6u4m and XXS4e7n5chbPYxNkit==ubxGUTt1LraKhVZgpAP(u"ࠨࡃࡖࡏࠬᆁ"): XXS4e7n5chbPYxNkit = TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠩࡄࡇࡈࡋࡐࡕࡇࡇࠫᆂ")
			else: XXS4e7n5chbPYxNkit = P0qdZI384LKleuo(u"ࠪࡖࡊࡐࡅࡄࡖࡈࡈࠬᆃ")
			hRWC8YSFvsm4JHOMVIne3jquZ.setSetting(mQNonhS7CV2BXOv(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡵࡨࡨࡳࡹࠧᆄ"),ddks654iAjgKNp1hOJluQyWHR)
			hRWC8YSFvsm4JHOMVIne3jquZ.setSetting(mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡷࡶࡩࡵࡸ࡯ࡹࡻࠪᆅ"),XXS4e7n5chbPYxNkit)
		if aVwGA2kFY6u4m:
			if GXNZCDRs3E1V==UUkIBz1sgQ9WfNeG6trKXvu0(u"࠻ᓋ") and Mmpr0o76iWJvz1kTtfgI8hES(u"࠭ࡨࡵࡶࡳࡷࠬᆆ") in MUJCtfYVBLODrFbaZn and QrKJzWNAp7:
				if ddVrvmbZNlMO7j5uaSw9DxKkWg8R: yicQV3gj4q(VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠧหใ฼๎้ࠦแฮืุࠣ์อฯสࠢส่ฯฺแ๋ำࠣࡗࡘࡒࠧᆇ"),VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠨๆศู้ออࠡ็ื็้ฯࠠศๆศ๊ฯืๆ๋ฬࠪᆈ"),wLQCTr5lqbsVYeAHdzfhZ1F=S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"࠶࠵࠶࠰ᓌ"))
				GSh0nJxEXgZjd48u7mBwWOeafyAp5b = MUJCtfYVBLODrFbaZn+ddo23ZJtgcY(u"ࠩࡿࢀࡓࡵࡖࡦࡴ࡬ࡪࡾ࡙ࡓࡍࠩᆉ")
				tZQNAbT3dv0XP4 = Ndw0b1s4ayCoqxtkES3i2(ufxrtSb9vkTpPhqG8WK,GSh0nJxEXgZjd48u7mBwWOeafyAp5b,kTSyagGWsFnolYhMO5fCwvpNuPqR,Hjb64dTft8SzJ,gPpvwzQVkYrG58uD2j,ddVrvmbZNlMO7j5uaSw9DxKkWg8R,RRIHDFjoW9w7bSfVPhC(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤࡘࡅࡒࡗࡈࡗ࡙࡙࠭࠳ࡰࡧࠫᆊ"))
				if tZQNAbT3dv0XP4.succeeded:
					Z8VU1cMugRwIjL2fpSyPJFHokYrqa = tZQNAbT3dv0XP4
					mwIxD3GBPgLVc2aq9(iebCpLE8fuxTRg,EECz06teoykrNFfq(QQ8pvXNcBfVkP5rRJ7o)+DYakr9g4PVU(u"ࠫࠥࠦࠠࡔࡷࡦࡧࡪ࡫ࡤࡦࡦࠣࡹࡸ࡯࡮ࡨࠢࡖࡗࡑࡀࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭ᆋ")+fOzS45youKYdNDqwm61aEI3A+SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠬࠦ࡝࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫᆌ")+YabJfs3q7yjpzvXioO+zI3ROAZtiUq42rE9WDST68(u"࠭ࠠ࡞ࠩᆍ"))
					if ddVrvmbZNlMO7j5uaSw9DxKkWg8R: yicQV3gj4q(TYf7Dc06PQgy1vEV9(u"ࠧ็ฮสัࠥฮวิฬัำฬ๋ࠠࡔࡕࡏࠫᆎ"),mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠨๆศู้ออࠡ็ื็้ฯࠠศๆศ๊ฯืๆ๋ฬࠪᆏ"),wLQCTr5lqbsVYeAHdzfhZ1F=kke1PDGRBLuY8y(u"࠷࠶࠰࠱ᓍ"))
				else:
					mwIxD3GBPgLVc2aq9(WG2BfeyzMa,EECz06teoykrNFfq(QQ8pvXNcBfVkP5rRJ7o)+uVQd103XyvUce2EBtzbYaC(u"ࠩࠣࠤࠥࡌࡡࡪ࡮ࡨࡨࠥࡻࡳࡪࡰࡪࠤࡘ࡙ࡌ࠻ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨᆐ")+fOzS45youKYdNDqwm61aEI3A+mQNonhS7CV2BXOv(u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩᆑ")+YabJfs3q7yjpzvXioO+Mmpr0o76iWJvz1kTtfgI8hES(u"ࠫࠥࡣࠧᆒ"))
					if ddVrvmbZNlMO7j5uaSw9DxKkWg8R: yicQV3gj4q(HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠬ็ิๅࠢหหุะฮะษ่ࠤࡘ࡙ࡌࠨᆓ"),TT8Mxv5Wq7nlC9IscdpPUY6(u"࠭ไฦื็หาࠦๅีๅ็อࠥอไฦ่อี๋๐สࠨᆔ"),wLQCTr5lqbsVYeAHdzfhZ1F=uVQd103XyvUce2EBtzbYaC(u"࠸࠰࠱࠲ᓎ"))
			if not Z8VU1cMugRwIjL2fpSyPJFHokYrqa.succeeded and XXS4e7n5chbPYxNkit in [UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠧࡂࡗࡗࡓࠬᆕ"),Nh0BWuiSndf(u"ࠨࡃࡆࡇࡊࡖࡔࡆࡆࠪᆖ")] and NYgczM85oHZE:
				if ddVrvmbZNlMO7j5uaSw9DxKkWg8R: yicQV3gj4q(SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠩอๅ฾๐ไࠡีํีๆืวหࠢหีํ้ำ๋ࠩᆗ"),BWNPxIG7vqdTy85pjHzUOrK3(u"่ࠪส฻ไศฯู้้ࠣไสࠢส่ส์สา่ํฮࠬᆘ"),wLQCTr5lqbsVYeAHdzfhZ1F=BmePGjS7FxK6kutUM(u"࠲࠱࠲࠳ᓏ"))
				tZQNAbT3dv0XP4 = YDoWTu980xpgLIrMJ7l1tGm(ufxrtSb9vkTpPhqG8WK,MUJCtfYVBLODrFbaZn,kTSyagGWsFnolYhMO5fCwvpNuPqR,Hjb64dTft8SzJ,gPpvwzQVkYrG58uD2j,ddVrvmbZNlMO7j5uaSw9DxKkWg8R,fOzS45youKYdNDqwm61aEI3A)
				if tZQNAbT3dv0XP4.succeeded:
					Z8VU1cMugRwIjL2fpSyPJFHokYrqa = tZQNAbT3dv0XP4
					mwIxD3GBPgLVc2aq9(iebCpLE8fuxTRg,EECz06teoykrNFfq(QQ8pvXNcBfVkP5rRJ7o)+QQdAXWBc2GPw(u"ࠫࠥࠦࠠࡑࡴࡲࡼ࡮࡫ࡳࠡࡵࡸࡧࡨ࡫ࡥࡥࡧࡧ࠾ࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫᆙ")+fOzS45youKYdNDqwm61aEI3A+DYakr9g4PVU(u"ࠬࠦ࡝࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫᆚ")+YabJfs3q7yjpzvXioO+S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"࠭ࠠ࡞ࠩᆛ"))
					if ddVrvmbZNlMO7j5uaSw9DxKkWg8R: yicQV3gj4q(VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠧ็ฮสัู๊ࠥาใิหฯࠦศา๊ๆื๏࠭ᆜ"),mQNonhS7CV2BXOv(u"ࠨๆศู้ออࠡ็ื็้ฯࠠศๆศ๊ฯืๆ๋ฬࠪᆝ"),wLQCTr5lqbsVYeAHdzfhZ1F=mQNonhS7CV2BXOv(u"࠳࠲࠳࠴ᓐ"))
				else:
					mwIxD3GBPgLVc2aq9(WG2BfeyzMa,EECz06teoykrNFfq(QQ8pvXNcBfVkP5rRJ7o)+HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠩࠣࠤࠥࡖࡲࡰࡺ࡬ࡩࡸࠦࡦࡢ࡫࡯ࡩࡩࡀࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭ᆞ")+fOzS45youKYdNDqwm61aEI3A+m6hwdgP31a2zjN7lkpX(u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩᆟ")+YabJfs3q7yjpzvXioO+S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠫࠥࡣࠧᆠ"))
					if ddVrvmbZNlMO7j5uaSw9DxKkWg8R: yicQV3gj4q(TYf7Dc06PQgy1vEV9(u"ࠬ็ิๅࠢึ๎ึ็ัศฬࠣฬึ๎ใิ์ࠪᆡ"),DYakr9g4PVU(u"࠭ไฦื็หาࠦๅีๅ็อࠥอไฦ่อี๋๐สࠨᆢ"),wLQCTr5lqbsVYeAHdzfhZ1F=S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"࠴࠳࠴࠵ᓑ"))
			if not Z8VU1cMugRwIjL2fpSyPJFHokYrqa.succeeded and ddks654iAjgKNp1hOJluQyWHR in [SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠧࡂࡗࡗࡓࠬᆣ"),IjZbnrBJmM2N(u"ࠨࡃࡆࡇࡊࡖࡔࡆࡆࠪᆤ")] and HBJD9fKiTupFgjdw2o:
				if ddVrvmbZNlMO7j5uaSw9DxKkWg8R: yicQV3gj4q(VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠩอๅ฾๐ไࠡีํีๆืࠠࡅࡐࡖࠫᆥ"),S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"่ࠪส฻ไศฯู้้ࠣไสࠢส่ส์สา่ํฮࠬᆦ"),wLQCTr5lqbsVYeAHdzfhZ1F=Nh0BWuiSndf(u"࠵࠴࠵࠶ᓒ"))
				GSh0nJxEXgZjd48u7mBwWOeafyAp5b = MUJCtfYVBLODrFbaZn+Xz3bA2PFENVCUtplu51(u"ࠫࢁࢂࡍࡺࡆࡑࡗ࡚ࡸ࡬࠾ࠩᆧ")
				tZQNAbT3dv0XP4 = Ndw0b1s4ayCoqxtkES3i2(ufxrtSb9vkTpPhqG8WK,GSh0nJxEXgZjd48u7mBwWOeafyAp5b,kTSyagGWsFnolYhMO5fCwvpNuPqR,Hjb64dTft8SzJ,gPpvwzQVkYrG58uD2j,ddVrvmbZNlMO7j5uaSw9DxKkWg8R,DYakr9g4PVU(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔ࠯࠷ࡸ࡭࠭ᆨ"))
				if tZQNAbT3dv0XP4.succeeded:
					Z8VU1cMugRwIjL2fpSyPJFHokYrqa = tZQNAbT3dv0XP4
					mwIxD3GBPgLVc2aq9(iebCpLE8fuxTRg,EECz06teoykrNFfq(QQ8pvXNcBfVkP5rRJ7o)+m6hwdgP31a2zjN7lkpX(u"࠭ࠠࠡࠢࡇࡒࡘࠦࡳࡶࡥࡦࡩࡪࡪࡥࡥ࠼ࠣࠤࠥࡊࡎࡔ࠼ࠣ࡟ࠥ࠭ᆩ")+ahDrn9Jebl7mgKQB8vxVGOqPTk+IjZbnrBJmM2N(u"ࠧࠡ࡟ࠣࠤ࡙ࠥ࡯ࡶࡴࡦࡩ࠿࡛ࠦࠡࠩᆪ")+fOzS45youKYdNDqwm61aEI3A+P0qdZI384LKleuo(u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧᆫ")+YabJfs3q7yjpzvXioO+S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠩࠣࡡࠬᆬ"))
					if ddVrvmbZNlMO7j5uaSw9DxKkWg8R: yicQV3gj4q(UUkIBz1sgQ9WfNeG6trKXvu0(u"๊ࠪัออࠡีํีๆืࠠࡅࡐࡖࠫᆭ"),Nh0BWuiSndf(u"้ࠫหีๅษะࠤฺ๊ใๅหࠣห้หๆหำ้๎ฯ࠭ᆮ"),wLQCTr5lqbsVYeAHdzfhZ1F=mmcNLrXtzfpyCkZlvK5VwG2gujh(u"࠶࠵࠶࠰ᓓ"))
				else:
					mwIxD3GBPgLVc2aq9(WG2BfeyzMa,EECz06teoykrNFfq(QQ8pvXNcBfVkP5rRJ7o)+Nh0BWuiSndf(u"ࠬࠦࠠࠡࡆࡑࡗࠥ࡬ࡡࡪ࡮ࡨࡨ࠿ࠦࠠࠡࡆࡑࡗ࠿࡛ࠦࠡࠩᆯ")+ahDrn9Jebl7mgKQB8vxVGOqPTk+mmcNLrXtzfpyCkZlvK5VwG2gujh(u"࠭ࠠ࡞ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨᆰ")+fOzS45youKYdNDqwm61aEI3A+P0qdZI384LKleuo(u"ࠧࠡ࡟ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭ᆱ")+YabJfs3q7yjpzvXioO+ddo23ZJtgcY(u"ࠨࠢࡠࠫᆲ"))
					if ddVrvmbZNlMO7j5uaSw9DxKkWg8R: yicQV3gj4q(Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠩไุ้ࠦำ๋ำไีࠥࡊࡎࡔࠩᆳ"),vvWwO3Tx2dAgcijrFXq(u"่ࠪส฻ไศฯู้้ࠣไสࠢส่ส์สา่ํฮࠬᆴ"),wLQCTr5lqbsVYeAHdzfhZ1F=QTUBCcehw6qPd4x(u"࠷࠶࠰࠱ᓔ"))
		if XXS4e7n5chbPYxNkit==mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠫࡗࡋࡊࡆࡅࡗࡉࡉ࠭ᆵ") or ddks654iAjgKNp1hOJluQyWHR==S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠬࡘࡅࡋࡇࡆࡘࡊࡊࠧᆶ"): ddVrvmbZNlMO7j5uaSw9DxKkWg8R = DD5cFIejQa2X4BgAu9GWPyJ3tC7
		if not Z8VU1cMugRwIjL2fpSyPJFHokYrqa.succeeded:
			if ddVrvmbZNlMO7j5uaSw9DxKkWg8R: XtjoB0NqWClE4Kdcwy8ZhsGubI = YdsxuIoEqU(GXNZCDRs3E1V,Na2orbSjcLY0R1Zl,fOzS45youKYdNDqwm61aEI3A,ddVrvmbZNlMO7j5uaSw9DxKkWg8R)
			if GXNZCDRs3E1V!=SbjiWeHLQPoazqwp3cODkd7YxVgn(u"࠸࠰࠱ᓕ") and fOzS45youKYdNDqwm61aEI3A not in ntcLuhZPEDsUxoqTG1iK74XFO and IjZbnrBJmM2N(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࠪᆷ") not in fOzS45youKYdNDqwm61aEI3A: ldtI4ef3qWaKVP5p()
	if hRWC8YSFvsm4JHOMVIne3jquZ.getSetting(P0qdZI384LKleuo(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡹࡸ࡫ࡤ࡯ࡵࠪᆸ")) not in [Mmpr0o76iWJvz1kTtfgI8hES(u"ࠨࡃࡘࡘࡔ࠭ᆹ"),Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠩࡖࡘࡔࡖࠧᆺ"),UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠪࡅࡘࡑࠧᆻ")]: hRWC8YSFvsm4JHOMVIne3jquZ.setSetting(S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡵࡨࡨࡳࡹࠧᆼ"),Nh0BWuiSndf(u"ࠬࡇࡓࡌࠩᆽ"))
	if hRWC8YSFvsm4JHOMVIne3jquZ.getSetting(mmcNLrXtzfpyCkZlvK5VwG2gujh(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡸࡷࡪࡶࡲࡰࡺࡼࠫᆾ")) not in [kke1PDGRBLuY8y(u"ࠧࡂࡗࡗࡓࠬᆿ"),yST5AHEfvPmcWpwGuh2BJ(u"ࠨࡕࡗࡓࡕ࠭ᇀ"),m6hwdgP31a2zjN7lkpX(u"ࠩࡄࡗࡐ࠭ᇁ")]: hRWC8YSFvsm4JHOMVIne3jquZ.setSetting(VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡵࡴࡧࡳࡶࡴࡾࡹࠨᇂ"),Nh0BWuiSndf(u"ࠫࡆ࡙ࡋࠨᇃ"))
	return Z8VU1cMugRwIjL2fpSyPJFHokYrqa
def zImYWNH5ROuDdhrJXFASvPn1b4fkls(website,WiBfcZvakVobNrEGx,IPt7S8O1yJg0Ns5Kvd=None):
	NNYWvobd8GSlD7gO0L = shC5qBRV2A0lZ(u"࠱࠱ᓖ")
	llQ3E8BqXig7 = [Xz3bA2PFENVCUtplu51(u"࠲ᓗ"),Xz3bA2PFENVCUtplu51(u"࠲ᓗ"),Xz3bA2PFENVCUtplu51(u"࠲ᓗ"),LAQD5wEkr18bUiGaYen3J(u"࠳࠳ᓘ"),TYf7Dc06PQgy1vEV9(u"࠸ᓙ"),LAQD5wEkr18bUiGaYen3J(u"࠳࠳ᓘ"),Xz3bA2PFENVCUtplu51(u"࠲ᓗ"),Xz3bA2PFENVCUtplu51(u"࠲ᓗ"),Xz3bA2PFENVCUtplu51(u"࠲ᓗ"),TYf7Dc06PQgy1vEV9(u"࠸ᓙ")]
	jozAH5a6iKJ0Bsb = qqEBN1GzvSmf
	CCvaIw0Gx5KMAuBiD1O9U = []
	POSCkwn2xKyc8U = [mQNonhS7CV2BXOv(u"࠴ᓚ")]*NNYWvobd8GSlD7gO0L
	MMikHS5yDB = SS2OK7hjLagvUAm(mshLJcKH1fv03yRnDOr4ZT,uVQd103XyvUce2EBtzbYaC(u"ࠬࡪࡩࡤࡶࠪᇄ"),ddo23ZJtgcY(u"࠭ࡓࡄࡔࡄࡔࡊࡘࡓࡠࡕࡗࡅ࡙࡛ࡓࠨᇅ"))
	for UNWlb9KARzv4ZLamH in list(MMikHS5yDB.keys()):
		if website not in UNWlb9KARzv4ZLamH: continue
		TFAmLfwypkzsP1UYCMr8c,T376Rgy1VIwFHq = UNWlb9KARzv4ZLamH.split(TYf7Dc06PQgy1vEV9(u"ࠧࡠࡡࠪᇆ"))
		POSCkwn2xKyc8U[int(T376Rgy1VIwFHq)] = MMikHS5yDB[UNWlb9KARzv4ZLamH]
	for p8R0YcsOIP4KUMEkbVgABZTtN9w in range(NNYWvobd8GSlD7gO0L):
		if p8R0YcsOIP4KUMEkbVgABZTtN9w in jozAH5a6iKJ0Bsb+WiBfcZvakVobNrEGx: continue
		if p8R0YcsOIP4KUMEkbVgABZTtN9w==IPt7S8O1yJg0Ns5Kvd: POSCkwn2xKyc8U[p8R0YcsOIP4KUMEkbVgABZTtN9w] = POSCkwn2xKyc8U[p8R0YcsOIP4KUMEkbVgABZTtN9w]+ddo23ZJtgcY(u"࠶ᓛ")
		if POSCkwn2xKyc8U[p8R0YcsOIP4KUMEkbVgABZTtN9w]<Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"࠹ᓜ"): CCvaIw0Gx5KMAuBiD1O9U += [p8R0YcsOIP4KUMEkbVgABZTtN9w]*llQ3E8BqXig7[p8R0YcsOIP4KUMEkbVgABZTtN9w]
	if not CCvaIw0Gx5KMAuBiD1O9U:
		for p8R0YcsOIP4KUMEkbVgABZTtN9w in range(NNYWvobd8GSlD7gO0L):
			POSCkwn2xKyc8U[p8R0YcsOIP4KUMEkbVgABZTtN9w] = S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"࠰ᓝ")
			if p8R0YcsOIP4KUMEkbVgABZTtN9w in jozAH5a6iKJ0Bsb+WiBfcZvakVobNrEGx: continue
			CCvaIw0Gx5KMAuBiD1O9U += [p8R0YcsOIP4KUMEkbVgABZTtN9w]*llQ3E8BqXig7[p8R0YcsOIP4KUMEkbVgABZTtN9w]
	for p8R0YcsOIP4KUMEkbVgABZTtN9w in jozAH5a6iKJ0Bsb: POSCkwn2xKyc8U[p8R0YcsOIP4KUMEkbVgABZTtN9w] = RRIHDFjoW9w7bSfVPhC(u"࠺࠻࠼࠽ᓞ")
	djqK9lmLO8p6srhQ5PVeo = []
	for p8R0YcsOIP4KUMEkbVgABZTtN9w in range(NNYWvobd8GSlD7gO0L): djqK9lmLO8p6srhQ5PVeo.append(website+uVQd103XyvUce2EBtzbYaC(u"ࠨࡡࡢࠫᇇ")+str(p8R0YcsOIP4KUMEkbVgABZTtN9w))
	PGudrhJF8iDkSq96XVHEQZYf5L(mshLJcKH1fv03yRnDOr4ZT,QQdAXWBc2GPw(u"ࠩࡖࡇࡗࡇࡐࡆࡔࡖࡣࡘ࡚ࡁࡕࡗࡖࠫᇈ"),djqK9lmLO8p6srhQ5PVeo,POSCkwn2xKyc8U,GsNQWtBTywlx40*DYakr9g4PVU(u"࠷ᓟ"),CCxMXuNUEzolDZTKrBJ)
	return CCvaIw0Gx5KMAuBiD1O9U
def HnKshijkpEbLC4lVyN(ufxrtSb9vkTpPhqG8WK,MUJCtfYVBLODrFbaZn,EEkjQFxOabod08Nr,ybF0H85nUohsiRQcpaTfZAKzjMY7wB,bbzSa6ZOsRBgtVpQ4uYGFkc7LAf,ddVrvmbZNlMO7j5uaSw9DxKkWg8R,fOzS45youKYdNDqwm61aEI3A,GXNZCDRs3E1V,UUF24APJXw0DzpoENvys1Zf3kRj,WiBfcZvakVobNrEGx=[]):
	yicQV3gj4q(S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠪฬิษสࠡ฻่่๏ฯࠠหฮส์ืࠦวๅฯฯฬࠬᇉ"),b8Qe150xVaJsnDSv,wLQCTr5lqbsVYeAHdzfhZ1F=Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"࠺࠹࠵ᓠ"))
	mwIxD3GBPgLVc2aq9(iebCpLE8fuxTRg,EECz06teoykrNFfq(QQ8pvXNcBfVkP5rRJ7o)+ubxGUTt1LraKhVZgpAP(u"ࠫࠥࠦࠠࡕࡴࡼ࡭ࡳ࡭ࠠࡣࡻࡳࡥࡸࡹࠠࡣ࡮ࡲࡧࡰ࡯࡮ࡨࠢࠣࠤࡈࡵࡤࡦ࠼ࠣ࡟ࠥ࠭ᇊ")+str(GXNZCDRs3E1V)+LAQD5wEkr18bUiGaYen3J(u"ࠬࠦ࡝ࠡࠢࡕࡩࡦࡹ࡯࡯࠼ࠣ࡟ࠥ࠭ᇋ")+UUF24APJXw0DzpoENvys1Zf3kRj+VFjQx6Is28KvzLOmMXtg4GqTwa3(u"࠭ࠠ࡞ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨᇌ")+fOzS45youKYdNDqwm61aEI3A+BmePGjS7FxK6kutUM(u"ࠧࠡ࡟ࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬᇍ")+MUJCtfYVBLODrFbaZn+TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠨࠢࡠࠫᇎ"))
	website = fOzS45youKYdNDqwm61aEI3A.split(Xz3bA2PFENVCUtplu51(u"ࠩ࠰ࠫᇏ"))[LzYQg91SIxDeOGtCKd5]
	VPB1JFvcEbziuRq4M = zImYWNH5ROuDdhrJXFASvPn1b4fkls(website,WiBfcZvakVobNrEGx)
	p5FQgfzqT2tI = []
	if website==BmePGjS7FxK6kutUM(u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠵ࠬᇐ"):
		if LzYQg91SIxDeOGtCKd5 in VPB1JFvcEbziuRq4M: p5FQgfzqT2tI += [LzYQg91SIxDeOGtCKd5]
		if qHYIWnOZLPkrQU in VPB1JFvcEbziuRq4M: p5FQgfzqT2tI += [qHYIWnOZLPkrQU]
		if IgQimel18t in VPB1JFvcEbziuRq4M: p5FQgfzqT2tI += [IgQimel18t]
		if VwApyDY1Jc in VPB1JFvcEbziuRq4M: p5FQgfzqT2tI += [VwApyDY1Jc]*LAQD5wEkr18bUiGaYen3J(u"࠵࠵ᓡ")
		if NvHugPosYDzRJ in VPB1JFvcEbziuRq4M: p5FQgfzqT2tI += [NvHugPosYDzRJ]*m6hwdgP31a2zjN7lkpX(u"࠺ᓢ")
		if ddo23ZJtgcY(u"࠵ᓤ") in VPB1JFvcEbziuRq4M: p5FQgfzqT2tI += [ddo23ZJtgcY(u"࠵ᓤ")]*DYakr9g4PVU(u"࠷࠰ᓣ")
		if BmePGjS7FxK6kutUM(u"࠷ᓥ") in VPB1JFvcEbziuRq4M: p5FQgfzqT2tI += [BmePGjS7FxK6kutUM(u"࠷ᓥ")]
		if ddo23ZJtgcY(u"࠹ᓦ") in VPB1JFvcEbziuRq4M: p5FQgfzqT2tI += [ddo23ZJtgcY(u"࠹ᓦ")]
	elif website==TYf7Dc06PQgy1vEV9(u"ࠫࡘࡎࡁࡉࡋࡇ࠸࡚࠭ᇑ"):
		if VwApyDY1Jc in VPB1JFvcEbziuRq4M: p5FQgfzqT2tI += [VwApyDY1Jc]*S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"࠴࠴ᓧ")
	elif website==shC5qBRV2A0lZ(u"ࠬࡉࡉࡎࡃ࡚ࡆࡆ࡙ࠧᇒ"):
		if qHYIWnOZLPkrQU in VPB1JFvcEbziuRq4M: p5FQgfzqT2tI += [qHYIWnOZLPkrQU]
		if NvHugPosYDzRJ in VPB1JFvcEbziuRq4M: p5FQgfzqT2tI += [NvHugPosYDzRJ]*LAQD5wEkr18bUiGaYen3J(u"࠹ᓨ")
		if SbjiWeHLQPoazqwp3cODkd7YxVgn(u"࠻ᓪ") in VPB1JFvcEbziuRq4M: p5FQgfzqT2tI += [SbjiWeHLQPoazqwp3cODkd7YxVgn(u"࠻ᓪ")]*QTUBCcehw6qPd4x(u"࠶࠶ᓩ")
		if IjZbnrBJmM2N(u"࠶ᓫ") in VPB1JFvcEbziuRq4M: p5FQgfzqT2tI += [IjZbnrBJmM2N(u"࠶ᓫ")]
		if Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"࠸ᓬ") in VPB1JFvcEbziuRq4M: p5FQgfzqT2tI += [Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"࠸ᓬ")]
	elif website==DYakr9g4PVU(u"࠭ࡃࡊࡏࡄࡐࡎࡍࡈࡕࠩᇓ"):
		if NvHugPosYDzRJ in VPB1JFvcEbziuRq4M: p5FQgfzqT2tI += [NvHugPosYDzRJ]*Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"࠷ᓭ")
		if ubxGUTt1LraKhVZgpAP(u"࠹ᓯ") in VPB1JFvcEbziuRq4M: p5FQgfzqT2tI += [ubxGUTt1LraKhVZgpAP(u"࠹ᓯ")]*VFjQx6Is28KvzLOmMXtg4GqTwa3(u"࠴࠴ᓮ")
	elif website==Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠧࡘࡇࡆࡍࡒࡇ࠱ࠨᇔ"):
		if mQNonhS7CV2BXOv(u"࠾ᓰ") in VPB1JFvcEbziuRq4M: p5FQgfzqT2tI += [mQNonhS7CV2BXOv(u"࠾ᓰ")]*uVQd103XyvUce2EBtzbYaC(u"࠻ᓱ")
	if p5FQgfzqT2tI: VPB1JFvcEbziuRq4M = p5FQgfzqT2tI
	if VPB1JFvcEbziuRq4M:
		QQ3DArciURM2Pk = qHiNBx6PXjKatkWf37AwFClzsp2DmE.sample(VPB1JFvcEbziuRq4M,qHYIWnOZLPkrQU)[LzYQg91SIxDeOGtCKd5]
	else: QQ3DArciURM2Pk = -qHYIWnOZLPkrQU
	update = CCxMXuNUEzolDZTKrBJ
	if QQ3DArciURM2Pk==LzYQg91SIxDeOGtCKd5:
		scraperserver = VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠨࡵࡦࡶࡦࡶࡥࡰࡲࡶ࠵ࠬᇕ")
		wPp6dmAY504Dcl8agyNHineZIbLFTU = vvWwO3Tx2dAgcijrFXq(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡶࡧࡷࡧࡰࡦࡱࡳࡷ࠳ࡱࡥࡦࡲࡢ࡬ࡪࡧࡤࡦࡴࡶࡁ࡙ࡸࡵࡦ࠰ࡦࡳࡺࡴࡴࡳࡻࡀ࡭ࡱࡀ࠱࠶࠲ࡧ࠶࠷࡬࠱࠮ࡥ࠸࠼ࡦ࠳࠴࠱࠴࠴࠱ࡦࡧ࠸࠵࠯ࡨ࠽࠷࠹ࡣࡢࡨ࠻࠹࠽࠹࠴ࡁࡲࡵࡳࡽࡿ࠮ࡴࡥࡵࡥࡵ࡫࡯ࡱࡵ࠱࡭ࡴࡀ࠵࠴࠷࠶ࠫᇖ")
		ps2ueZoatbCrwq7mIHLiVMPxN9Q = MUJCtfYVBLODrFbaZn+ubxGUTt1LraKhVZgpAP(u"ࠪࢀࢁࡓࡹࡑࡴࡲࡼࡾ࡛ࡲ࡭࠿ࠪᇗ")+wPp6dmAY504Dcl8agyNHineZIbLFTU+dDYUoKi6JFM23p(u"ࠫࢁࢂࡎࡰࡘࡨࡶ࡮࡬ࡹࡔࡕࡏࠫᇘ")
		yexF0nl2OtBv3 = Ndw0b1s4ayCoqxtkES3i2(ufxrtSb9vkTpPhqG8WK,ps2ueZoatbCrwq7mIHLiVMPxN9Q,EEkjQFxOabod08Nr,ybF0H85nUohsiRQcpaTfZAKzjMY7wB,bbzSa6ZOsRBgtVpQ4uYGFkc7LAf,ddVrvmbZNlMO7j5uaSw9DxKkWg8R,fOzS45youKYdNDqwm61aEI3A,DD5cFIejQa2X4BgAu9GWPyJ3tC7,DD5cFIejQa2X4BgAu9GWPyJ3tC7)
	elif QQ3DArciURM2Pk==qHYIWnOZLPkrQU:
		scraperserver = SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠬࡹࡣࡳࡣࡳࡩࡴࡶࡳ࠳ࠩᇙ")
		wPp6dmAY504Dcl8agyNHineZIbLFTU = HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡳࡤࡴࡤࡴࡪࡵࡰࡴ࠰࡮ࡩࡪࡶ࡟ࡩࡧࡤࡨࡪࡸࡳ࠾ࡖࡵࡹࡪ࠴ࡣࡰࡷࡱࡸࡷࡿ࠽ࡪ࡮࠽࠷࠾࠿࠱ࡦ࠻ࡦ࠹࠲࠽ࡥࡦ࠵࠰࠸ࡪ࡫࠲࠮࠺࠷ࡧ࠵࠳ࡦࡥ࠹࠼࠶ࡧࡧࡤࡥ࠵ࡧ࠹ࡅࡶࡲࡰࡺࡼ࠲ࡸࡩࡲࡢࡲࡨࡳࡵࡹ࠮ࡪࡱ࠽࠹࠸࠻࠳ࠨᇚ")
		ps2ueZoatbCrwq7mIHLiVMPxN9Q = MUJCtfYVBLODrFbaZn+vvWwO3Tx2dAgcijrFXq(u"ࠧࡽࡾࡐࡽࡕࡸ࡯ࡹࡻࡘࡶࡱࡃࠧᇛ")+wPp6dmAY504Dcl8agyNHineZIbLFTU+ubxGUTt1LraKhVZgpAP(u"ࠨࡾࡿࡒࡴ࡜ࡥࡳ࡫ࡩࡽࡘ࡙ࡌࠨᇜ")
		yexF0nl2OtBv3 = Ndw0b1s4ayCoqxtkES3i2(ufxrtSb9vkTpPhqG8WK,ps2ueZoatbCrwq7mIHLiVMPxN9Q,EEkjQFxOabod08Nr,ybF0H85nUohsiRQcpaTfZAKzjMY7wB,bbzSa6ZOsRBgtVpQ4uYGFkc7LAf,ddVrvmbZNlMO7j5uaSw9DxKkWg8R,fOzS45youKYdNDqwm61aEI3A,DD5cFIejQa2X4BgAu9GWPyJ3tC7,DD5cFIejQa2X4BgAu9GWPyJ3tC7)
	elif QQ3DArciURM2Pk==IgQimel18t:
		scraperserver = Mmpr0o76iWJvz1kTtfgI8hES(u"ࠩࡶࡧࡷࡧࡰࡦࡴࡤࡴ࡮࠭ᇝ")
		wPp6dmAY504Dcl8agyNHineZIbLFTU = uVQd103XyvUce2EBtzbYaC(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡷࡨࡸࡡࡱࡧࡵࡥࡵ࡯࠮࡬ࡧࡨࡴࡤ࡮ࡥࡢࡦࡨࡶࡸࡃࡔࡳࡷࡨ࠲ࡨࡵࡵ࡯ࡶࡵࡽࡤࡩ࡯ࡥࡧࡀ࡭ࡱࡀ࠷࠷ࡤ࠷ࡪࡨ࠹࠴ࡧࡥࡧ࠵࠾ࡪ࠹ࡤ࠷࠸ࡥ࠶࠻ࡦ࠴࠸࠳࠸ࡨࡪ࠹࠲࠶ࡦࡄࡵࡸ࡯ࡹࡻ࠰ࡷࡪࡸࡶࡦࡴ࠱ࡷࡨࡸࡡࡱࡧࡵࡥࡵ࡯࠮ࡤࡱࡰ࠾࠽࠶࠰࠲ࠩᇞ")
		ps2ueZoatbCrwq7mIHLiVMPxN9Q = MUJCtfYVBLODrFbaZn+yST5AHEfvPmcWpwGuh2BJ(u"ࠫࢁࢂࡍࡺࡒࡵࡳࡽࡿࡕࡳ࡮ࡀࠫᇟ")+wPp6dmAY504Dcl8agyNHineZIbLFTU+TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠬࢂࡼࡏࡱ࡙ࡩࡷ࡯ࡦࡺࡕࡖࡐࠬᇠ")
		yexF0nl2OtBv3 = Ndw0b1s4ayCoqxtkES3i2(ufxrtSb9vkTpPhqG8WK,ps2ueZoatbCrwq7mIHLiVMPxN9Q,EEkjQFxOabod08Nr,ybF0H85nUohsiRQcpaTfZAKzjMY7wB,bbzSa6ZOsRBgtVpQ4uYGFkc7LAf,ddVrvmbZNlMO7j5uaSw9DxKkWg8R,fOzS45youKYdNDqwm61aEI3A,DD5cFIejQa2X4BgAu9GWPyJ3tC7,DD5cFIejQa2X4BgAu9GWPyJ3tC7)
	elif QQ3DArciURM2Pk==VwApyDY1Jc:
		scraperserver = UUkIBz1sgQ9WfNeG6trKXvu0(u"࠭ࡳࡤࡴࡤࡴࡪࡻࡰࠨᇡ")
		GSh0nJxEXgZjd48u7mBwWOeafyAp5b = MUJCtfYVBLODrFbaZn.replace(QQdAXWBc2GPw(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࠩᇢ"),DYakr9g4PVU(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࠩᇣ"))
		ps2ueZoatbCrwq7mIHLiVMPxN9Q = S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡤࡴ࡮࠴ࡳࡤࡴࡤࡴࡪࡻࡰ࠯ࡥࡲࡱ࠴ࡅࡡࡱ࡫ࡢ࡯ࡪࡿ࠽࠲ࡘࡑࡷࡒࡺࡌ࠲ࡱࡅࡖ࡝ࡱࡓࡏࡅࡥࡇࡒࡐ࠱ࡌ࡚࡜ࡎ࡯ࡰ࠰ࡥ࡬࡝ࡻࠫࡱࡥࡦࡲࡢ࡬ࡪࡧࡤࡦࡴࡶࡁࡋࡧ࡬ࡴࡧࠩࡧࡴࡻ࡮ࡵࡴࡼࡣࡨࡵࡤࡦ࠿࡬ࡰࠫࡻࡲ࡭࠿ࠪᇤ")+HHbaVYqFRy6v0c(GSh0nJxEXgZjd48u7mBwWOeafyAp5b)
		yexF0nl2OtBv3 = Ndw0b1s4ayCoqxtkES3i2(shC5qBRV2A0lZ(u"ࠪࡋࡊ࡚ࠧᇥ"),ps2ueZoatbCrwq7mIHLiVMPxN9Q,EEkjQFxOabod08Nr,ybF0H85nUohsiRQcpaTfZAKzjMY7wB,bbzSa6ZOsRBgtVpQ4uYGFkc7LAf,ddVrvmbZNlMO7j5uaSw9DxKkWg8R,fOzS45youKYdNDqwm61aEI3A,DD5cFIejQa2X4BgAu9GWPyJ3tC7,DD5cFIejQa2X4BgAu9GWPyJ3tC7)
	elif QQ3DArciURM2Pk==NvHugPosYDzRJ:
		scraperserver = mQNonhS7CV2BXOv(u"ࠫࡸࡩࡲࡢࡲ࡬ࡲ࡬ࡸ࡯ࡣࡱࡷࠫᇦ")
		ps2ueZoatbCrwq7mIHLiVMPxN9Q = QQdAXWBc2GPw(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡧࡰࡪ࠰ࡶࡧࡷࡧࡰࡪࡰࡪࡶࡴࡨ࡯ࡵ࠰ࡦࡳࡲ࠵࠿ࡵࡱ࡮ࡩࡳࡃࡡ࠵ࡨ࠺ࡪࡧ࠷࠴࠮࠴ࡧࡩ࡫࠳࠴࠱࠹࠴࠱࠽࠼࠴ࡣ࠯࠵࠶ࡪ࠹࠲࠷࠶ࡧ࠸ࡩࡪࡣࠧࡲࡵࡳࡽࡿࡃࡰࡷࡱࡸࡷࡿ࠽ࡊࡎࠩࡹࡷࡲ࠽ࠨᇧ")+HHbaVYqFRy6v0c(MUJCtfYVBLODrFbaZn)
		yexF0nl2OtBv3 = Ndw0b1s4ayCoqxtkES3i2(vvWwO3Tx2dAgcijrFXq(u"࠭ࡇࡆࡖࠪᇨ"),ps2ueZoatbCrwq7mIHLiVMPxN9Q,EEkjQFxOabod08Nr,ybF0H85nUohsiRQcpaTfZAKzjMY7wB,bbzSa6ZOsRBgtVpQ4uYGFkc7LAf,ddVrvmbZNlMO7j5uaSw9DxKkWg8R,fOzS45youKYdNDqwm61aEI3A,DD5cFIejQa2X4BgAu9GWPyJ3tC7,DD5cFIejQa2X4BgAu9GWPyJ3tC7)
		try:
			yexF0nl2OtBv3.content = oJsUwXA0yGOI1mTjxQ(TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠧࡥ࡫ࡦࡸࠬᇩ"),yexF0nl2OtBv3.content)
			yexF0nl2OtBv3.content = yexF0nl2OtBv3.content[P0qdZI384LKleuo(u"ࠨࡴࡨࡷࡺࡲࡴࠨᇪ")]
		except: pass
	elif QQ3DArciURM2Pk==BmePGjS7FxK6kutUM(u"࠵ᓲ"):
		scraperserver = BmePGjS7FxK6kutUM(u"ࠩࡶࡧࡷࡧࡰࡪࡰࡪࡥࡳࡺ࠱ࠨᇫ")
		wPp6dmAY504Dcl8agyNHineZIbLFTU = QQdAXWBc2GPw(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡷࡨࡸࡡࡱ࡫ࡱ࡫ࡦࡴࡴࠧࡲࡵࡳࡽࡿ࡟ࡤࡱࡸࡲࡹࡸࡹ࠾ࡋࡏࠪࡧࡸ࡯ࡸࡵࡨࡶࡂࡌࡡ࡭ࡵࡨࠪ࡫ࡵࡲࡸࡣࡵࡨࡤ࡮ࡥࡢࡦࡨࡶࡸࡃࡔࡳࡷࡨ࠾࠷ࡨ࠳࠵࠲ࡤ࠺࠽࠿࠰ࡢ࠷࠷࠴࠶ࡪࡢࡤ࠵࠺࠶ࡨ࠷࠱࠵࠷ࡧ࠽࠻࠸ࡥ࠹ࡂࡳࡶࡴࡾࡹ࠯ࡵࡦࡶࡦࡶࡩ࡯ࡩࡤࡲࡹ࠴ࡣࡰ࡯࠽࠼࠵࠾࠰ࠨᇬ")
		ps2ueZoatbCrwq7mIHLiVMPxN9Q = MUJCtfYVBLODrFbaZn+Nh0BWuiSndf(u"ࠫࢁࢂࡍࡺࡒࡵࡳࡽࡿࡕࡳ࡮ࡀࠫᇭ")+wPp6dmAY504Dcl8agyNHineZIbLFTU+S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠬࢂࡼࡏࡱ࡙ࡩࡷ࡯ࡦࡺࡕࡖࡐࠬᇮ")
		yexF0nl2OtBv3 = Ndw0b1s4ayCoqxtkES3i2(ufxrtSb9vkTpPhqG8WK,ps2ueZoatbCrwq7mIHLiVMPxN9Q,EEkjQFxOabod08Nr,ybF0H85nUohsiRQcpaTfZAKzjMY7wB,bbzSa6ZOsRBgtVpQ4uYGFkc7LAf,ddVrvmbZNlMO7j5uaSw9DxKkWg8R,fOzS45youKYdNDqwm61aEI3A,DD5cFIejQa2X4BgAu9GWPyJ3tC7,DD5cFIejQa2X4BgAu9GWPyJ3tC7)
	elif QQ3DArciURM2Pk==zI3ROAZtiUq42rE9WDST68(u"࠷ᓳ"):
		scraperserver = Mmpr0o76iWJvz1kTtfgI8hES(u"࠭ࡳࡤࡴࡤࡴࡪ࠴ࡤࡰ࠳ࠪᇯ")
		wPp6dmAY504Dcl8agyNHineZIbLFTU = TYf7Dc06PQgy1vEV9(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡤࡥ࠵࠺࠸ࡧࡢ࠲ࡧ࠸࠴࠹࠺ࡤ࠳ࡥࡤ࠹ࡩ࠻ࡤ࠴ࡨ࠼ࡩ࠸ࡩ࠳࠹࠸ࡨࡧࡦ࠷࠱࠱࠺࠶࠼࠾ࡧ࠷࠴࠼ࡦࡹࡸࡺ࡯࡮ࡊࡨࡥࡩ࡫ࡲࡴ࠿ࡗࡶࡺ࡫ࠦࡨࡧࡲࡇࡴࡪࡥ࠾࡫࡯ࡄࡵࡸ࡯ࡹࡻ࠱ࡷࡨࡸࡡࡱࡧ࠱ࡨࡴࡀ࠸࠱࠺࠳ࠫᇰ")
		ps2ueZoatbCrwq7mIHLiVMPxN9Q = MUJCtfYVBLODrFbaZn+BmePGjS7FxK6kutUM(u"ࠨࡾࡿࡑࡾࡖࡲࡰࡺࡼ࡙ࡷࡲ࠽ࠨᇱ")+wPp6dmAY504Dcl8agyNHineZIbLFTU+S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠩࡿࢀࡓࡵࡖࡦࡴ࡬ࡪࡾ࡙ࡓࡍࠩᇲ")
		yexF0nl2OtBv3 = Ndw0b1s4ayCoqxtkES3i2(ufxrtSb9vkTpPhqG8WK,ps2ueZoatbCrwq7mIHLiVMPxN9Q,EEkjQFxOabod08Nr,ybF0H85nUohsiRQcpaTfZAKzjMY7wB,bbzSa6ZOsRBgtVpQ4uYGFkc7LAf,ddVrvmbZNlMO7j5uaSw9DxKkWg8R,fOzS45youKYdNDqwm61aEI3A,DD5cFIejQa2X4BgAu9GWPyJ3tC7,DD5cFIejQa2X4BgAu9GWPyJ3tC7)
	elif QQ3DArciURM2Pk==RRIHDFjoW9w7bSfVPhC(u"࠹ᓴ"):
		scraperserver = shC5qBRV2A0lZ(u"ࠪࡷࡨࡸࡡࡱࡧ࠱ࡨࡴ࠸ࠧᇳ")
		wPp6dmAY504Dcl8agyNHineZIbLFTU = BmePGjS7FxK6kutUM(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶ࡩ࠳ࡥ࠵ࡤࡩ࠶࠾࠵ࡥࡨ࠷ࡦ࡫࠼ࡡࡧ࠷࠶࠷ࡨ࠽࠰࠵࠲ࡥ࠷࠹࠽ࡣ࠺ࡧ࠼࠽ࡧ࡫࠴࠷࠸ࡤࡩ࠾ࡀࡣࡶࡵࡷࡳࡲࡎࡥࡢࡦࡨࡶࡸࡃࡔࡳࡷࡨࠪ࡬࡫࡯ࡄࡱࡧࡩࡂ࡯࡬ࡁࡲࡵࡳࡽࡿ࠮ࡴࡥࡵࡥࡵ࡫࠮ࡥࡱ࠽࠼࠵࠾࠰ࠨᇴ")
		ps2ueZoatbCrwq7mIHLiVMPxN9Q = MUJCtfYVBLODrFbaZn+RRIHDFjoW9w7bSfVPhC(u"ࠬࢂࡼࡎࡻࡓࡶࡴࡾࡹࡖࡴ࡯ࡁࠬᇵ")+wPp6dmAY504Dcl8agyNHineZIbLFTU+Xz3bA2PFENVCUtplu51(u"࠭ࡼࡽࡐࡲ࡚ࡪࡸࡩࡧࡻࡖࡗࡑ࠭ᇶ")
		yexF0nl2OtBv3 = Ndw0b1s4ayCoqxtkES3i2(ufxrtSb9vkTpPhqG8WK,ps2ueZoatbCrwq7mIHLiVMPxN9Q,EEkjQFxOabod08Nr,ybF0H85nUohsiRQcpaTfZAKzjMY7wB,bbzSa6ZOsRBgtVpQ4uYGFkc7LAf,ddVrvmbZNlMO7j5uaSw9DxKkWg8R,fOzS45youKYdNDqwm61aEI3A,DD5cFIejQa2X4BgAu9GWPyJ3tC7,DD5cFIejQa2X4BgAu9GWPyJ3tC7)
	elif QQ3DArciURM2Pk==vvWwO3Tx2dAgcijrFXq(u"࠻ᓵ"):
		scraperserver = zI3ROAZtiUq42rE9WDST68(u"ࠧࡴࡥࡵࡥࡵ࡫࡯ࡱࡵ࠶ࠫᇷ")
		ps2ueZoatbCrwq7mIHLiVMPxN9Q = BWNPxIG7vqdTy85pjHzUOrK3(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡳࡶࡴࡾࡹ࠯ࡵࡦࡶࡦࡶࡥࡰࡲࡶ࠲࡮ࡵ࠯ࡷ࠳࠲ࡃࡦࡶࡩࡠ࡭ࡨࡽࡂ࠹࠹࠺࠳ࡨ࠽ࡨ࠻࠭࠸ࡧࡨ࠷࠲࠺ࡥࡦ࠴࠰࠼࠹ࡩ࠰࠮ࡨࡧ࠻࠾࠸ࡢࡢࡦࡧ࠷ࡩ࠻ࠦࡤࡱࡸࡲࡹࡸࡹ࠾࡫࡯ࠪࡺࡸ࡬࠾ࠩᇸ")+HHbaVYqFRy6v0c(MUJCtfYVBLODrFbaZn)
		yexF0nl2OtBv3 = Ndw0b1s4ayCoqxtkES3i2(P0qdZI384LKleuo(u"ࠩࡊࡉ࡙࠭ᇹ"),ps2ueZoatbCrwq7mIHLiVMPxN9Q,EEkjQFxOabod08Nr,ybF0H85nUohsiRQcpaTfZAKzjMY7wB,bbzSa6ZOsRBgtVpQ4uYGFkc7LAf,ddVrvmbZNlMO7j5uaSw9DxKkWg8R,fOzS45youKYdNDqwm61aEI3A,DD5cFIejQa2X4BgAu9GWPyJ3tC7,DD5cFIejQa2X4BgAu9GWPyJ3tC7)
	elif QQ3DArciURM2Pk==Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"࠽ᓶ"):
		scraperserver = kke1PDGRBLuY8y(u"ࠪࡷࡨࡸࡡࡱ࡫ࡱ࡫ࡦࡴࡴ࠳ࠩᇺ")
		wPp6dmAY504Dcl8agyNHineZIbLFTU = vvWwO3Tx2dAgcijrFXq(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡸࡩࡲࡢࡲ࡬ࡲ࡬ࡧ࡮ࡵࠨࡳࡶࡴࡾࡹࡠࡥࡲࡹࡳࡺࡲࡺ࠿ࡄࡉࠫࡸࡥࡵࡷࡵࡲࡤࡶࡡࡨࡧࡢࡷࡴࡻࡲࡤࡧࡀࡸࡷࡻࡥࠧࡨࡲࡶࡼࡧࡲࡥࡡ࡫ࡩࡦࡪࡥࡳࡵࡀࡸࡷࡻࡥ࠻࠴ࡥ࠷࠹࠶ࡡ࠷࠺࠼࠴ࡦ࠻࠴࠱࠳ࡧࡦࡨ࠹࠷࠳ࡥ࠴࠵࠹࠻ࡤ࠺࠸࠵ࡩ࠽ࡆࡰࡳࡱࡻࡽ࠳ࡹࡣࡳࡣࡳ࡭ࡳ࡭ࡡ࡯ࡶ࠱ࡧࡴࡳ࠺࠹࠲࠻࠴ࠬᇻ")
		ps2ueZoatbCrwq7mIHLiVMPxN9Q = MUJCtfYVBLODrFbaZn+yST5AHEfvPmcWpwGuh2BJ(u"ࠬࢂࡼࡎࡻࡓࡶࡴࡾࡹࡖࡴ࡯ࡁࠬᇼ")+wPp6dmAY504Dcl8agyNHineZIbLFTU+mQNonhS7CV2BXOv(u"࠭ࡼࡽࡐࡲ࡚ࡪࡸࡩࡧࡻࡖࡗࡑ࠭ᇽ")
		yexF0nl2OtBv3 = Ndw0b1s4ayCoqxtkES3i2(ufxrtSb9vkTpPhqG8WK,ps2ueZoatbCrwq7mIHLiVMPxN9Q,EEkjQFxOabod08Nr,ybF0H85nUohsiRQcpaTfZAKzjMY7wB,bbzSa6ZOsRBgtVpQ4uYGFkc7LAf,ddVrvmbZNlMO7j5uaSw9DxKkWg8R,fOzS45youKYdNDqwm61aEI3A,DD5cFIejQa2X4BgAu9GWPyJ3tC7,DD5cFIejQa2X4BgAu9GWPyJ3tC7)
	else:
		scraperserver,ps2ueZoatbCrwq7mIHLiVMPxN9Q = b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv
		yexF0nl2OtBv3 = BwV6rAIldfsGyK7oeJT053()
		update = DD5cFIejQa2X4BgAu9GWPyJ3tC7
	if update and not yexF0nl2OtBv3.succeeded:
		zImYWNH5ROuDdhrJXFASvPn1b4fkls(website,[],QQ3DArciURM2Pk)
		if len(list(set(VPB1JFvcEbziuRq4M)))>qHYIWnOZLPkrQU:
			aVwGA2kFY6u4m = BjMmX1vNrnzSAf(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᇾ"),P0qdZI384LKleuo(u"ࠨๆ็วุ็ࠠิ์ิๅึࠦๅฺษ็ะฮࠦวๅฯฯฬࠥืโๆࠢࠪᇿ")+str(QQ3DArciURM2Pk)+QTUBCcehw6qPd4x(u"ࠩࠣๅู๊ࠠโ์ࠣ฽๊๊๊สࠢอะฬ๎าࠡษ็ััฮࠠ࠯࠰๋้ࠣࠦสา์าࠤ๊ำว้ๆฬࠤฯาว้ิࠣห้ำฬษ่ࠢีฮࠦรฯำ์ࠤออำหะาห๊ࠦำ๋ำไี๋ࠥฮหๆไࠤฤࠧࠧሀ"))
			if aVwGA2kFY6u4m==qHYIWnOZLPkrQU:
				WiBfcZvakVobNrEGx.append(QQ3DArciURM2Pk)
				yexF0nl2OtBv3 = HnKshijkpEbLC4lVyN(ufxrtSb9vkTpPhqG8WK,MUJCtfYVBLODrFbaZn,EEkjQFxOabod08Nr,ybF0H85nUohsiRQcpaTfZAKzjMY7wB,bbzSa6ZOsRBgtVpQ4uYGFkc7LAf,ddVrvmbZNlMO7j5uaSw9DxKkWg8R,fOzS45youKYdNDqwm61aEI3A,GXNZCDRs3E1V,UUF24APJXw0DzpoENvys1Zf3kRj,WiBfcZvakVobNrEGx)
				return yexF0nl2OtBv3
	yexF0nl2OtBv3.scrapernumber = str(QQ3DArciURM2Pk)
	yexF0nl2OtBv3.scraperserver = scraperserver
	yexF0nl2OtBv3.scraperurl = ps2ueZoatbCrwq7mIHLiVMPxN9Q
	eqlY85tLc9pK = QTUBCcehw6qPd4x(u"ࠪื๏ืแาࠢิๆ๊ࠦࠧሁ")+yexF0nl2OtBv3.scrapernumber
	if yexF0nl2OtBv3.succeeded:
		mwIxD3GBPgLVc2aq9(iebCpLE8fuxTRg,EECz06teoykrNFfq(QQ8pvXNcBfVkP5rRJ7o)+m6hwdgP31a2zjN7lkpX(u"ࠫࠥࠦࠠࡔࡷࡦࡧࡪ࡫ࡤࡦࡦࠣࡦࡾࡶࡡࡴࡵࠣࡦࡱࡵࡣ࡬࡫ࡱ࡫ࠥࠦࠠࡔࡧࡵࡺࡪࡸ࠺ࠡ࡝ࠣࠫሂ")+scraperserver+QTUBCcehw6qPd4x(u"ࠬࠦ࡝ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧሃ")+fOzS45youKYdNDqwm61aEI3A+shC5qBRV2A0lZ(u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬሄ")+MUJCtfYVBLODrFbaZn+LAQD5wEkr18bUiGaYen3J(u"ࠧࠡ࡟ࠪህ"))
		yicQV3gj4q(DYakr9g4PVU(u"ࠨ่ฯัฯูࠦๆๆํอࠥะฬศ๊ีࠤฬ๊ออสࠪሆ"),eqlY85tLc9pK,wLQCTr5lqbsVYeAHdzfhZ1F=ddo23ZJtgcY(u"࠼࠻࠰ᓷ"))
	else:
		mwIxD3GBPgLVc2aq9(WG2BfeyzMa,EECz06teoykrNFfq(QQ8pvXNcBfVkP5rRJ7o)+zI3ROAZtiUq42rE9WDST68(u"ࠩࠣࠤࠥࡌࡡࡪ࡮ࡨࡨࠥࡨࡹࡱࡣࡶࡷࠥࡨ࡬ࡰࡥ࡮࡭ࡳ࡭ࠠࠡࠢࡖࡩࡷࡼࡥࡳ࠼ࠣ࡟ࠥ࠭ሇ")+scraperserver+uVQd103XyvUce2EBtzbYaC(u"ࠪࠤࡢࠦࠠࠡࡅࡲࡨࡪࡀࠠ࡜ࠢࠪለ")+str(yexF0nl2OtBv3.code)+UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠫࠥࡣࠠࠡࠢࡕࡩࡦࡹ࡯࡯࠼ࠣ࡟ࠥ࠭ሉ")+yexF0nl2OtBv3.reason+Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠬࠦ࡝ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧሊ")+fOzS45youKYdNDqwm61aEI3A+yST5AHEfvPmcWpwGuh2BJ(u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬላ")+MUJCtfYVBLODrFbaZn+kke1PDGRBLuY8y(u"ࠧࠡ࡟ࠪሌ"))
		yicQV3gj4q(Mmpr0o76iWJvz1kTtfgI8hES(u"ࠨใื่ฯูࠦๆๆํอࠥะฬศ๊ีࠤฬ๊ออสࠪል"),eqlY85tLc9pK,wLQCTr5lqbsVYeAHdzfhZ1F=BmePGjS7FxK6kutUM(u"࠽࠵࠱ᓸ"))
	return yexF0nl2OtBv3
def dcLRAZWFzODax2jf0tHCX81pJveNY(nWxkguOY04XVsEwQJ,ufxrtSb9vkTpPhqG8WK,YabJfs3q7yjpzvXioO,kTSyagGWsFnolYhMO5fCwvpNuPqR,Hjb64dTft8SzJ,gPpvwzQVkYrG58uD2j,showDialogs,fOzS45youKYdNDqwm61aEI3A,aLwqTHENGm2Q=b8Qe150xVaJsnDSv,ecs4ouJGNY6TSH=b8Qe150xVaJsnDSv):
	MUJCtfYVBLODrFbaZn,wrVWChaBPjl3XLucdoxIEM72t6,uKNTqB5FAPjao2Xg4GEcUzltOksdx,yMAcL5oOp31 = KKRSdoITymChfstN3l6jvOnJMPU(YabJfs3q7yjpzvXioO)
	try: k6UxcHFme4NoyPt2gMuEVaWXlRp8 = Hjb64dTft8SzJ.copy()
	except: k6UxcHFme4NoyPt2gMuEVaWXlRp8 = Hjb64dTft8SzJ
	QpHl0Efc7yvn2V = ufxrtSb9vkTpPhqG8WK,MUJCtfYVBLODrFbaZn,kTSyagGWsFnolYhMO5fCwvpNuPqR,k6UxcHFme4NoyPt2gMuEVaWXlRp8,gPpvwzQVkYrG58uD2j
	if nWxkguOY04XVsEwQJ<m6hwdgP31a2zjN7lkpX(u"࠰ᓹ"):
		zqbhiLmQfC3VK9Arku(mshLJcKH1fv03yRnDOr4ZT,UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠩࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗࠬሎ"),QpHl0Efc7yvn2V)
		nWxkguOY04XVsEwQJ = -nWxkguOY04XVsEwQJ
	if nWxkguOY04XVsEwQJ>Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"࠱ᓺ"):
		Ci4rQ0qV915j2AIkHTbcy = SS2OK7hjLagvUAm(mshLJcKH1fv03yRnDOr4ZT,zI3ROAZtiUq42rE9WDST68(u"ࠪࡶࡪࡹࡰࡰࡰࡶࡩࠬሏ"),QTUBCcehw6qPd4x(u"ࠫࡔࡖࡅࡏࡗࡕࡐࡤࡘࡅࡒࡗࡈࡗ࡙࡙ࠧሐ"),QpHl0Efc7yvn2V)
		if Ci4rQ0qV915j2AIkHTbcy.succeeded:
			IYuvgrd2fS(vvWwO3Tx2dAgcijrFXq(u"ࠬࡘࡅࡒࡗࡈࡗ࡙࡙ࠠࠡࡔࡈࡅࡉࡥࡃࡂࡅࡋࡉࠬሑ"),MUJCtfYVBLODrFbaZn,kTSyagGWsFnolYhMO5fCwvpNuPqR,Hjb64dTft8SzJ,fOzS45youKYdNDqwm61aEI3A,ufxrtSb9vkTpPhqG8WK)
			return Ci4rQ0qV915j2AIkHTbcy
	Ci4rQ0qV915j2AIkHTbcy = Ndw0b1s4ayCoqxtkES3i2(ufxrtSb9vkTpPhqG8WK,YabJfs3q7yjpzvXioO,kTSyagGWsFnolYhMO5fCwvpNuPqR,Hjb64dTft8SzJ,gPpvwzQVkYrG58uD2j,showDialogs,fOzS45youKYdNDqwm61aEI3A,aLwqTHENGm2Q,ecs4ouJGNY6TSH)
	if Ci4rQ0qV915j2AIkHTbcy.succeeded:
		if mmcNLrXtzfpyCkZlvK5VwG2gujh(u"࠭ࡃࡊࡏࡄࡒࡔ࡝ࠧሒ") in fOzS45youKYdNDqwm61aEI3A: Ci4rQ0qV915j2AIkHTbcy.content = KvkLRyF6ahWxpPGX4cn(Ci4rQ0qV915j2AIkHTbcy.content)
		if Ci4rQ0qV915j2AIkHTbcy.scrape: nWxkguOY04XVsEwQJ = Q49IsrlSuYRAVbGKhwdckLDOetF2PZ
		if nWxkguOY04XVsEwQJ and Ci4rQ0qV915j2AIkHTbcy.content: PGudrhJF8iDkSq96XVHEQZYf5L(mshLJcKH1fv03yRnDOr4ZT,ddo23ZJtgcY(u"ࠧࡐࡒࡈࡒ࡚ࡘࡌࡠࡔࡈࡕ࡚ࡋࡓࡕࡕࠪሓ"),QpHl0Efc7yvn2V,Ci4rQ0qV915j2AIkHTbcy,nWxkguOY04XVsEwQJ)
	return Ci4rQ0qV915j2AIkHTbcy
def MTr3igGe26HOs9ptAJF7Y1ux4vZaf(nWxkguOY04XVsEwQJ,YabJfs3q7yjpzvXioO,kTSyagGWsFnolYhMO5fCwvpNuPqR,Hjb64dTft8SzJ,showDialogs,fOzS45youKYdNDqwm61aEI3A):
	if not kTSyagGWsFnolYhMO5fCwvpNuPqR or isinstance(kTSyagGWsFnolYhMO5fCwvpNuPqR,dict): ufxrtSb9vkTpPhqG8WK = mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠨࡉࡈࡘࠬሔ")
	else:
		ufxrtSb9vkTpPhqG8WK = LAQD5wEkr18bUiGaYen3J(u"ࠩࡓࡓࡘ࡚ࠧሕ")
		kTSyagGWsFnolYhMO5fCwvpNuPqR = SgrGWuAHcLKBQMJetb9(kTSyagGWsFnolYhMO5fCwvpNuPqR)
		ASMKTzmbvULg,kTSyagGWsFnolYhMO5fCwvpNuPqR = FNIhDd4uLfev0q5YHVGx8oWm6CsiJ(kTSyagGWsFnolYhMO5fCwvpNuPqR)
	Ci4rQ0qV915j2AIkHTbcy = dcLRAZWFzODax2jf0tHCX81pJveNY(nWxkguOY04XVsEwQJ,ufxrtSb9vkTpPhqG8WK,YabJfs3q7yjpzvXioO,kTSyagGWsFnolYhMO5fCwvpNuPqR,Hjb64dTft8SzJ,CCxMXuNUEzolDZTKrBJ,showDialogs,fOzS45youKYdNDqwm61aEI3A)
	oH3N1dY9vLpaDJfnTVP5Z7q = Ci4rQ0qV915j2AIkHTbcy.content
	oH3N1dY9vLpaDJfnTVP5Z7q = str(oH3N1dY9vLpaDJfnTVP5Z7q)
	return oH3N1dY9vLpaDJfnTVP5Z7q
def KKRSdoITymChfstN3l6jvOnJMPU(YabJfs3q7yjpzvXioO):
	LrtkjdUPJ04oSumWOGaQE6YD9x = YabJfs3q7yjpzvXioO.split(TYf7Dc06PQgy1vEV9(u"ࠪࢀࢁ࠭ሖ"))
	MUJCtfYVBLODrFbaZn,wrVWChaBPjl3XLucdoxIEM72t6,uKNTqB5FAPjao2Xg4GEcUzltOksdx,yMAcL5oOp31 = LrtkjdUPJ04oSumWOGaQE6YD9x[LzYQg91SIxDeOGtCKd5],None,None,CCxMXuNUEzolDZTKrBJ
	for QpHl0Efc7yvn2V in LrtkjdUPJ04oSumWOGaQE6YD9x:
		if kke1PDGRBLuY8y(u"ࠫࡒࡿࡐࡳࡱࡻࡽ࡚ࡸ࡬࠾ࠩሗ") in QpHl0Efc7yvn2V: wrVWChaBPjl3XLucdoxIEM72t6 = QpHl0Efc7yvn2V[UUkIBz1sgQ9WfNeG6trKXvu0(u"࠳࠴ᓻ"):]
		elif Mmpr0o76iWJvz1kTtfgI8hES(u"ࠬࡓࡹࡅࡐࡖ࡙ࡷࡲ࠽ࠨመ") in QpHl0Efc7yvn2V: uKNTqB5FAPjao2Xg4GEcUzltOksdx = QpHl0Efc7yvn2V[QQdAXWBc2GPw(u"࠼ᓼ"):]
		elif yST5AHEfvPmcWpwGuh2BJ(u"࠭ࡎࡰࡘࡨࡶ࡮࡬ࡹࡔࡕࡏࠫሙ") in QpHl0Efc7yvn2V: yMAcL5oOp31 = DD5cFIejQa2X4BgAu9GWPyJ3tC7
	return MUJCtfYVBLODrFbaZn,wrVWChaBPjl3XLucdoxIEM72t6,uKNTqB5FAPjao2Xg4GEcUzltOksdx,yMAcL5oOp31
def WKcgXoMCUHSpB6rs5LDlzGnik(nWxkguOY04XVsEwQJ,ufxrtSb9vkTpPhqG8WK,YabJfs3q7yjpzvXioO,gV0vXwKeuU9zimQ6oMS,uupSAFQxlNwVZMBhI,XYuCjVPDid,Hjb64dTft8SzJ=b8Qe150xVaJsnDSv):
	JJxEA3nWIjNr9gQ = Wl2eu1PavfQ(YabJfs3q7yjpzvXioO,S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠧࡶࡴ࡯ࠫሚ"))
	qnaioW9cTuU = hRWC8YSFvsm4JHOMVIne3jquZ.getSetting(Xz3bA2PFENVCUtplu51(u"ࠨࡣࡹ࠲࡭ࡵࡳࡵ࠰ࠪማ")+gV0vXwKeuU9zimQ6oMS)
	if JJxEA3nWIjNr9gQ==qnaioW9cTuU: hRWC8YSFvsm4JHOMVIne3jquZ.setSetting(BmePGjS7FxK6kutUM(u"ࠩࡤࡺ࠳࡮࡯ࡴࡶ࠱ࠫሜ")+gV0vXwKeuU9zimQ6oMS,b8Qe150xVaJsnDSv)
	if qnaioW9cTuU: GSh0nJxEXgZjd48u7mBwWOeafyAp5b = YabJfs3q7yjpzvXioO.replace(JJxEA3nWIjNr9gQ,qnaioW9cTuU)
	else:
		GSh0nJxEXgZjd48u7mBwWOeafyAp5b = YabJfs3q7yjpzvXioO
		qnaioW9cTuU = JJxEA3nWIjNr9gQ
	tZQNAbT3dv0XP4 = dcLRAZWFzODax2jf0tHCX81pJveNY(nWxkguOY04XVsEwQJ,ufxrtSb9vkTpPhqG8WK,GSh0nJxEXgZjd48u7mBwWOeafyAp5b,b8Qe150xVaJsnDSv,Hjb64dTft8SzJ,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,Nh0BWuiSndf(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡕࡏࡈࡎࡈࡣࡓࡋࡗࡠࡊࡒࡗ࡙ࡔࡁࡎࡇ࠰࠵ࡸࡺࠧም"))
	oH3N1dY9vLpaDJfnTVP5Z7q = tZQNAbT3dv0XP4.content
	if i1thmHk7AZquD4cM0fnp62:
		try: oH3N1dY9vLpaDJfnTVP5Z7q = oH3N1dY9vLpaDJfnTVP5Z7q.decode(OVauxZzLI10vcXT74K,BWNPxIG7vqdTy85pjHzUOrK3(u"ࠫ࡮࡭࡮ࡰࡴࡨࠫሞ"))
		except: pass
	if not tZQNAbT3dv0XP4.succeeded or XYuCjVPDid not in oH3N1dY9vLpaDJfnTVP5Z7q:
		uupSAFQxlNwVZMBhI = uupSAFQxlNwVZMBhI.replace(pldxivXC5wbTB2O8q,TYf7Dc06PQgy1vEV9(u"ࠬ࠱ࠧሟ"))
		MUJCtfYVBLODrFbaZn = TYf7Dc06PQgy1vEV9(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲࡬ࡵ࡯ࡨ࡮ࡨ࠲ࡨࡵ࡭࠰ࡵࡨࡥࡷࡩࡨࡀࡳࡀࠫሠ")+uupSAFQxlNwVZMBhI
		ybF0H85nUohsiRQcpaTfZAKzjMY7wB = {yST5AHEfvPmcWpwGuh2BJ(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫሡ"):b8Qe150xVaJsnDSv}
		Z8VU1cMugRwIjL2fpSyPJFHokYrqa = dcLRAZWFzODax2jf0tHCX81pJveNY(nWxkguOY04XVsEwQJ,ufxrtSb9vkTpPhqG8WK,MUJCtfYVBLODrFbaZn,b8Qe150xVaJsnDSv,ybF0H85nUohsiRQcpaTfZAKzjMY7wB,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,DYakr9g4PVU(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡓࡔࡍࡌࡆࡡࡑࡉ࡜ࡥࡈࡐࡕࡗࡒࡆࡓࡅ࠮࠴ࡱࡨࠬሢ"))
		if Z8VU1cMugRwIjL2fpSyPJFHokYrqa.succeeded:
			oH3N1dY9vLpaDJfnTVP5Z7q = Z8VU1cMugRwIjL2fpSyPJFHokYrqa.content
			if i1thmHk7AZquD4cM0fnp62:
				try: oH3N1dY9vLpaDJfnTVP5Z7q = oH3N1dY9vLpaDJfnTVP5Z7q.decode(OVauxZzLI10vcXT74K,m6hwdgP31a2zjN7lkpX(u"ࠩ࡬࡫ࡳࡵࡲࡦࠩሣ"))
				except: pass
			tzdvaEpMHOCZLXDYg08T = YYBlm36zd0Jst18LXwo4.findall(BWNPxIG7vqdTy85pjHzUOrK3(u"ࠪࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠵࡜ࡸࠬ࡟ࡃ࠳࠰࠿ࠩࡪࡷࡸࡵ࠴ࠪࡀࠫࠥࠫሤ"),oH3N1dY9vLpaDJfnTVP5Z7q,YYBlm36zd0Jst18LXwo4.DOTALL)
			yCWlco08P4DV5ME9ZsuxzkrbgfTFh1 = [qnaioW9cTuU]
			HU72alYLwpdVbSWt = [TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠫࡦࡶ࡫ࠨሥ"),yST5AHEfvPmcWpwGuh2BJ(u"ࠬ࡭࡯ࡰࡩ࡯ࡩࠬሦ"),IjZbnrBJmM2N(u"࠭ࡴࡸ࡫ࡷࡸࡪࡸࠧሧ"),shC5qBRV2A0lZ(u"ࠧࡺࡱࡸࡸࡺࡨࡥࠨረ"),BmePGjS7FxK6kutUM(u"ࠨࡨࡤࡧࡪࡨ࡯ࡰ࡭ࠪሩ"),QTUBCcehw6qPd4x(u"ࠩࡳ࡬ࡵ࠭ሪ"),ubxGUTt1LraKhVZgpAP(u"ࠪࡥࡹࡲࡡࡲࠩራ"),SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠫࡸ࡯ࡴࡦ࡫ࡱࡨ࡮ࡩࡥࡴࠩሬ"),HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠬࡹࡵࡳ࠰࡯ࡽࠬር"),DYakr9g4PVU(u"࠭ࡢ࡭ࡱࡪࡷࡵࡵࡴࠨሮ"),Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠧࡪࡰࡩࡳࡷࡳࡥࡳࠩሯ"),ubxGUTt1LraKhVZgpAP(u"ࠨࡵ࡬ࡸࡪࡲࡩ࡬ࡧࠪሰ"),SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠩ࡬ࡲࡸࡺࡡࡨࡴࡤࡱࠬሱ"),vvWwO3Tx2dAgcijrFXq(u"ࠪࡷࡳࡧࡰࡤࡪࡤࡸࠬሲ"),uVQd103XyvUce2EBtzbYaC(u"ࠫ࡭ࡺࡴࡱ࠯ࡨࡵࡺ࡯ࡶࠨሳ"),BWNPxIG7vqdTy85pjHzUOrK3(u"ࠬ࡬ࡡࡴࡧ࡯ࡴࡱࡻࡳࠨሴ")]
			for rM6EVzvpbh3HUPu in tzdvaEpMHOCZLXDYg08T:
				if any(Y8aiFZsLKw in rM6EVzvpbh3HUPu for Y8aiFZsLKw in HU72alYLwpdVbSWt): continue
				qnaioW9cTuU = Wl2eu1PavfQ(rM6EVzvpbh3HUPu,TT8Mxv5Wq7nlC9IscdpPUY6(u"࠭ࡵࡳ࡮ࠪስ"))
				if qnaioW9cTuU in yCWlco08P4DV5ME9ZsuxzkrbgfTFh1: continue
				if len(yCWlco08P4DV5ME9ZsuxzkrbgfTFh1)==yST5AHEfvPmcWpwGuh2BJ(u"࠽ᓽ"):
					mwIxD3GBPgLVc2aq9(WG2BfeyzMa,EECz06teoykrNFfq(QQ8pvXNcBfVkP5rRJ7o)+DYakr9g4PVU(u"ࠧࠡࠢࠣࡋࡴࡵࡧ࡭ࡧࠣࡨ࡮ࡪࠠ࡯ࡱࡷࠤ࡫࡯࡮ࡥࠢࡤࠤࡳ࡫ࡷࠡࡪࡲࡷࡹࡴࡡ࡮ࡧࠣࠤ࡙ࠥࡩࡵࡧ࠽ࠤࡠࠦࠧሶ")+gV0vXwKeuU9zimQ6oMS+ddo23ZJtgcY(u"ࠨࠢࡠࠤࠥࡕ࡬ࡥ࠼ࠣ࡟ࠥ࠭ሷ")+JJxEA3nWIjNr9gQ+zI3ROAZtiUq42rE9WDST68(u"ࠩࠣࡡࠬሸ"))
					hRWC8YSFvsm4JHOMVIne3jquZ.setSetting(BWNPxIG7vqdTy85pjHzUOrK3(u"ࠪࡥࡻ࠴ࡨࡰࡵࡷ࠲ࠬሹ")+gV0vXwKeuU9zimQ6oMS,b8Qe150xVaJsnDSv)
					break
				yCWlco08P4DV5ME9ZsuxzkrbgfTFh1.append(qnaioW9cTuU)
				GSh0nJxEXgZjd48u7mBwWOeafyAp5b = YabJfs3q7yjpzvXioO.replace(JJxEA3nWIjNr9gQ,qnaioW9cTuU)
				tZQNAbT3dv0XP4 = dcLRAZWFzODax2jf0tHCX81pJveNY(nWxkguOY04XVsEwQJ,ufxrtSb9vkTpPhqG8WK,GSh0nJxEXgZjd48u7mBwWOeafyAp5b,b8Qe150xVaJsnDSv,Hjb64dTft8SzJ,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,zI3ROAZtiUq42rE9WDST68(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡏࡐࡉࡏࡉࡤࡔࡅࡘࡡࡋࡓࡘ࡚ࡎࡂࡏࡈ࠱࠸ࡸࡤࠨሺ"))
				oH3N1dY9vLpaDJfnTVP5Z7q = tZQNAbT3dv0XP4.content
				if tZQNAbT3dv0XP4.succeeded and XYuCjVPDid in oH3N1dY9vLpaDJfnTVP5Z7q:
					mwIxD3GBPgLVc2aq9(iebCpLE8fuxTRg,EECz06teoykrNFfq(QQ8pvXNcBfVkP5rRJ7o)+vvWwO3Tx2dAgcijrFXq(u"ࠬࠦࠠࠡࡉࡲࡳ࡬ࡲࡥࠡࡨࡲࡹࡳࡪࠠࡢࠢࡱࡩࡼࠦࡨࡰࡵࡷࡲࡦࡳࡥࠡࠢࠣࡗ࡮ࡺࡥ࠻ࠢ࡞ࠤࠬሻ")+gV0vXwKeuU9zimQ6oMS+Nh0BWuiSndf(u"࠭ࠠ࡞ࠢࠣࠤࡓ࡫ࡷ࠻ࠢ࡞ࠤࠬሼ")+qnaioW9cTuU+Nh0BWuiSndf(u"ࠧࠡ࡟ࠣࠤࡔࡲࡤ࠻ࠢ࡞ࠤࠬሽ")+JJxEA3nWIjNr9gQ+m6hwdgP31a2zjN7lkpX(u"ࠨࠢࡠࠫሾ"))
					hRWC8YSFvsm4JHOMVIne3jquZ.setSetting(QTUBCcehw6qPd4x(u"ࠩࡤࡺ࠳࡮࡯ࡴࡶ࠱ࠫሿ")+gV0vXwKeuU9zimQ6oMS,qnaioW9cTuU)
					break
	return qnaioW9cTuU,GSh0nJxEXgZjd48u7mBwWOeafyAp5b,tZQNAbT3dv0XP4
def OJ5kiNTSpIdCco0H(vv5M4UfJS9ucKEiNbxtnaOZ):
	XXBpSNgTIPfmvtubMO14HhVis = {
	 ubxGUTt1LraKhVZgpAP(u"ࠪࡥ࡭ࡽࡡ࡬ࠩቀ")				:shC5qBRV2A0lZ(u"๊ࠫ๎โฺࠢฦ๋ํอใࠡฬํๅ๏࠭ቁ")
	,Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠬࡧ࡫ࡰࡣࡰࠫቂ")				:BmePGjS7FxK6kutUM(u"࠭ๅ้ไ฼ࠤศ้่ศ็ࠣห้่ฯ๋็ࠪቃ")
	,yST5AHEfvPmcWpwGuh2BJ(u"ࠧࡢ࡭ࡲࡥࡲࡩࡡ࡮ࠩቄ")				:TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠨ็๋ๆ฾ࠦรไ๊ส้้ࠥวๆࠩቅ")
	,VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠩࡤ࡯ࡼࡧ࡭ࠨቆ")				:Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"้ࠪํู่ࠡลๆ์ฬ๋ࠠศๆฯำ๏ีࠧቇ")
	,UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠫࡦࡱࡷࡢ࡯ࡷࡹࡧ࡫ࠧቈ")			:vvWwO3Tx2dAgcijrFXq(u"๋่ࠬใ฻ࠣห่๎วๆࠢอ๎ํฮࠧ቉")
	,S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"࠭ࡡ࡭ࡣࡵࡥࡧ࠭ቊ")				:vvWwO3Tx2dAgcijrFXq(u"ࠧๆ๊ๅ฽้ࠥไࠡษ็฽ึฮࠧቋ")
	,Mmpr0o76iWJvz1kTtfgI8hES(u"ࠨࡣ࡯ࡪࡦࡺࡩ࡮࡫ࠪቌ")				:kke1PDGRBLuY8y(u"่ࠩ์็฿ࠠศๆ่๊อืࠠศๆไห฼๋๊ࠨቍ")
	,QTUBCcehw6qPd4x(u"ࠪࡥࡱࡱࡡࡸࡶ࡫ࡥࡷ࠭቎")			:BWNPxIG7vqdTy85pjHzUOrK3(u"๊ࠫ๎โฺࠢๅ๊ฬฯࠠศๆๆ์ะืࠧ቏")
	,HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠬࡧ࡬࡮ࡣࡤࡶࡪ࡬ࠧቐ")				:QTUBCcehw6qPd4x(u"࠭ๅ้ไ฼ࠤ็์วสࠢส่๊฿วาใࠪቑ")
	,TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠧࡢ࡮ࡰࡷࡹࡨࡡࠨቒ")				:Nh0BWuiSndf(u"ࠨ็๋ๆ฾ࠦวๅ็ุ฻อฯࠧቓ")
	,ubxGUTt1LraKhVZgpAP(u"ࠩࡤࡲ࡮ࡳࡥࡻ࡫ࡧࠫቔ")				:Nh0BWuiSndf(u"้ࠪํู่ࠡษ้้๏ࠦาะࠩቕ")
	,IjZbnrBJmM2N(u"ࠫࡦࡸࡡࡣ࡫ࡦࡸࡴࡵ࡮ࡴࠩቖ")			:Nh0BWuiSndf(u"๋่ࠬใ฻ࠣฮํ์าࠡ฻ิฬ๏ฯࠧ቗")
	,Nh0BWuiSndf(u"࠭ࡡࡳࡣࡥࡷࡪ࡫ࡤࠨቘ")				:uVQd103XyvUce2EBtzbYaC(u"ࠧๆ๊ๅ฽ࠥ฿ัษࠢึ๎๏ีࠧ቙")
	,TYf7Dc06PQgy1vEV9(u"ࠨࡣࡵࡦࡱ࡯࡯࡯ࡼࠪቚ")				:QQdAXWBc2GPw(u"่ࠩ์็฿ฺࠠำหࠤ้๐่็ิࠪቛ")
	,shC5qBRV2A0lZ(u"ࠪࡥࡾࡲ࡯࡭ࠩቜ")				:BWNPxIG7vqdTy85pjHzUOrK3(u"๊ࠫ๎โฺࠢฦ๎้๎ไࠨቝ")
	,QQdAXWBc2GPw(u"ࠬࡨ࡯࡬ࡴࡤࠫ቞")				:mQNonhS7CV2BXOv(u"࠭ๅ้ไ฼ࠤอ้ัศࠩ቟")
	,UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠧࡣࡴࡶࡸࡪࡰࠧበ")				:P0qdZI384LKleuo(u"ࠨ็๋ๆ฾ࠦศาีอ๎ั࠭ቡ")
	,RRIHDFjoW9w7bSfVPhC(u"ࠩࡦ࡭ࡲࡧ࠴࠱࠲ࠪቢ")				:QQdAXWBc2GPw(u"้ࠪํู่ࠡีํ้ฬࠦ࠴࠱࠲ࠪባ")
	,kke1PDGRBLuY8y(u"ࠫࡨ࡯࡭ࡢ࠶ࡳࠫቤ")				:dDYUoKi6JFM23p(u"๋่ࠬใ฻ࠣื๏๋วࠡใ๋ีࠥฮ๊ࠨብ")
	,UUkIBz1sgQ9WfNeG6trKXvu0(u"࠭ࡣࡪ࡯ࡤ࠸ࡺ࠭ቦ")				:DYakr9g4PVU(u"ࠧๆ๊ๅ฽ู๊ࠥๆษࠣๅํื๊้ࠩቧ")
	,QTUBCcehw6qPd4x(u"ࠨࡥ࡬ࡱࡦࡧࡢࡥࡱࠪቨ")				:Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"่ࠩ์็฿ࠠิ์่หࠥ฿ศะ๊ࠪቩ")
	,mQNonhS7CV2BXOv(u"ࠪࡧ࡮ࡳࡡࡤ࡮ࡸࡦࠬቪ")				:shC5qBRV2A0lZ(u"๊ࠫ๎โฺࠢึ๎๊อࠠไๆ๋ฬࠬቫ")
	,ddo23ZJtgcY(u"ࠬࡩࡩ࡮ࡣࡦࡰࡺࡨࡷࡰࡴ࡮ࠫቬ")			:IjZbnrBJmM2N(u"࠭ๅ้ไ฼ࠤุ๐ๅศࠢๆ่ํฮฺࠠ็็ࠫቭ")
	,RRIHDFjoW9w7bSfVPhC(u"ࠧࡤ࡫ࡰࡥࡨࡲࡵࡱࠩቮ")				:BmePGjS7FxK6kutUM(u"ࠨ็๋ๆ฾ࠦำ๋็สࠤ่๊่ษࠩቯ")
	,IjZbnrBJmM2N(u"ࠩࡦ࡭ࡲࡧࡦࡢࡰࡶࠫተ")				:vvWwO3Tx2dAgcijrFXq(u"้ࠪํู่ࠡีํ้ฬࠦแศ่ีࠫቱ")
	,BWNPxIG7vqdTy85pjHzUOrK3(u"ࠫࡨ࡯࡭ࡢࡨࡵࡩࡪ࠭ቲ")				:kke1PDGRBLuY8y(u"๋่ࠬใ฻ࠣื๏๋วࠡใิ๎ࠬታ")
	,m6hwdgP31a2zjN7lkpX(u"࠭ࡣࡪ࡯ࡤࡰ࡮࡭ࡨࡵࠩቴ")			:DYakr9g4PVU(u"ࠧๆ๊ๅ฽ู๊ࠥๆษ่ࠣฬ๐สࠨት")
	,QTUBCcehw6qPd4x(u"ࠨࡥ࡬ࡱࡦࡴ࡯ࡸࠩቶ")				:Nh0BWuiSndf(u"่ࠩ์็฿ࠠิ์่หࠥ์ว้ࠩቷ")
	,Nh0BWuiSndf(u"ࠪࡧ࡮ࡳࡡࡸࡤࡤࡷࠬቸ")				:Nh0BWuiSndf(u"๊ࠫ๎โฺࠢึ๎๊อ้ࠠสึࠫቹ")
	,Mmpr0o76iWJvz1kTtfgI8hES(u"ࠬࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰࠪቺ")			:SbjiWeHLQPoazqwp3cODkd7YxVgn(u"࠭ๅ้ไ฼ࠤิอ๊ๅ์้ࠣํฺๆࠨቻ")
	,IjZbnrBJmM2N(u"ࠧࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲ࠲ࡩࡨࡢࡰࡱࡩࡱࡹࠧቼ")	:mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠨ็๋ๆ฾ࠦฯศ์็๎๋่ࠥีุ่้ࠣะฮะ็ํ๊ࠬች")
	,Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠩࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴ࠭ࡩࡣࡶ࡬ࡹࡧࡧࡴࠩቾ")	:zI3ROAZtiUq42rE9WDST68(u"้ࠪํู่ࠡัส๎้๐ࠠๆ๊ื๊ࠥํวีฬส็ࠬቿ")
	,mQNonhS7CV2BXOv(u"ࠫࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯࠯࡯࡭ࡻ࡫ࡳࠨኀ")	:Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"๋่ࠬใ฻ࠣำฬ๐ไ๋่ࠢ์ู์ࠠๆสสุึ࠭ኁ")
	,UUkIBz1sgQ9WfNeG6trKXvu0(u"࠭ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱ࠱ࡵࡲࡡࡺ࡮࡬ࡷࡹࡹࠧኂ"):TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠧๆ๊ๅ฽ࠥีว๋ๆํࠤ๊๎ิ็ࠢๅ์ฬฬๅࠨኃ")
	,HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠨࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠳ࡴࡰࡲ࡬ࡧࡸ࠭ኄ")	:RRIHDFjoW9w7bSfVPhC(u"่ࠩ์็฿ࠠะษํ่๏ࠦๅ้ึ้ࠤ๊๎วื์฼ࠫኅ")
	,Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠪࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮࠮ࡸ࡬ࡨࡪࡵࡳࠨኆ")	:BWNPxIG7vqdTy85pjHzUOrK3(u"๊ࠫ๎โฺࠢาห๏๊๊ࠡ็ุ๋๋ࠦแ๋ัํ์์อสࠨኇ")
	,UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠬࡪࡩࡴࡣࡥࡰࡪࡪࠧኈ")				:IjZbnrBJmM2N(u"࠭ๅห๊ๅๅࠬ኉")
	,dDYUoKi6JFM23p(u"ࠧࡥࡴࡤࡱࡦࡩࡡࡧࡧࠪኊ")			:mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠨ็๋ๆ฾ࠦฯาษ่ห้ࠥวโ์๊ࠫኋ")
	,BmePGjS7FxK6kutUM(u"ࠩࡧࡶࡦࡳࡡࡴ࠹ࠪኌ")				:P0qdZI384LKleuo(u"้ࠪํู่ࠡัิห๊อࠠึฯࠪኍ")
	,TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠫࡪ࡭ࡹࡣࡧࡶࡸࠬ኎")				:m6hwdgP31a2zjN7lkpX(u"๋่ࠬใ฻ࠣห๏า๊ࠡสํืฯ࠭኏")
	,m6hwdgP31a2zjN7lkpX(u"࠭ࡥࡨࡻࡥࡩࡸࡺ࠱ࠨነ")				:ddo23ZJtgcY(u"ࠧๆ๊ๅ฽ࠥอ๊อ์ࠣฬ๏ูสࠡ࠳ࠪኑ")
	,IjZbnrBJmM2N(u"ࠨࡧࡪࡽࡧ࡫ࡳࡵ࠴ࠪኒ")				:BmePGjS7FxK6kutUM(u"่ࠩ์็฿ࠠศ์ฯ๎ࠥฮ๊ิฬࠣ࠶ࠬና")
	,SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠪࡩ࡬ࡿࡢࡦࡵࡷ࠷ࠬኔ")				:QQdAXWBc2GPw(u"๊ࠫ๎โฺࠢส๎ั๐ࠠษ์ึฮࠥ࠹ࠧን")
	,Mmpr0o76iWJvz1kTtfgI8hES(u"ࠬ࡫ࡧࡺࡤࡨࡷࡹ࠺ࠧኖ")				:zI3ROAZtiUq42rE9WDST68(u"࠭ๅ้ไ฼ࠤฬ๐ฬ๋ࠢห๎ุะࠠ࠵ࠩኗ")
	,vvWwO3Tx2dAgcijrFXq(u"ࠧࡦࡩࡼࡦࡪࡹࡴࡷ࡫ࡳࠫኘ")			:Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠨ็๋ๆ฾ࠦว๋ฮํࠤอ๐ำหࠢࡹ࡭ࡵ࠭ኙ")
	,LAQD5wEkr18bUiGaYen3J(u"ࠩࡨ࡫ࡾࡪࡥࡢࡦࠪኚ")				:Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"้ࠪํู่ࠡวํะ๏ࠦฯ๋ัࠪኛ")
	,QTUBCcehw6qPd4x(u"ࠫࡪ࡭ࡹ࡯ࡱࡺࠫኜ")				:ubxGUTt1LraKhVZgpAP(u"๋่ࠬใ฻ࠣษ๏า๊่ࠡส์ࠬኝ")
	,TYf7Dc06PQgy1vEV9(u"࠭ࡥ࡭ࡥ࡬ࡲࡪࡳࡡࠨኞ")				:QTUBCcehw6qPd4x(u"ࠧๆ๊ๅ฽๋่ࠥิ๊฼อࠥอไิ์้้ฬ࠭ኟ")
	,shC5qBRV2A0lZ(u"ࠨࡧ࡯࡭࡫ࡼࡩࡥࡧࡲࠫአ")			:QQdAXWBc2GPw(u"่ࠩ์็฿ࠠฤๆํๅࠥ็๊ะ์๋ࠫኡ")
	,Xz3bA2PFENVCUtplu51(u"ࠪࡪࡦࡨࡲࡢ࡭ࡤࠫኢ")				:zI3ROAZtiUq42rE9WDST68(u"๊ࠫ๎โฺࠢไฬึ้ษࠨኣ")
	,Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬኤ")				:Mmpr0o76iWJvz1kTtfgI8hES(u"࠭แีๆࠪእ")
	,zI3ROAZtiUq42rE9WDST68(u"ࠧࡧࡣ࡭ࡩࡷࡹࡨࡰࡹࠪኦ")			:ubxGUTt1LraKhVZgpAP(u"ࠨ็๋ๆ฾ࠦแอำุࠣํ࠭ኧ")
	,shC5qBRV2A0lZ(u"ࠩࡩࡥࡷ࡫ࡳ࡬ࡱࠪከ")				:kke1PDGRBLuY8y(u"้ࠪํู่ࠡใสี๏ูใ้ࠩኩ")
	,ddo23ZJtgcY(u"ࠫ࡫ࡧࡳࡦ࡮࡫ࡨ࠶࠭ኪ")				:QQdAXWBc2GPw(u"๋่ࠬใ฻ࠣๅฬ฻ไࠡษ็วํ๊ࠧካ")
	,uVQd103XyvUce2EBtzbYaC(u"࠭ࡦࡢࡵࡨࡰ࡭ࡪ࠲ࠨኬ")				:S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠧๆ๊ๅ฽ࠥ็วึๆࠣห้ัว็์ࠪክ")
	,m6hwdgP31a2zjN7lkpX(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨኮ")				:TYf7Dc06PQgy1vEV9(u"่ࠩะ้ีࠧኯ")
	,QTUBCcehw6qPd4x(u"ࠪࡪࡴࡹࡴࡢࠩኰ")				:TYf7Dc06PQgy1vEV9(u"๊ࠫ๎โฺࠢไ์ุะวࠨ኱")
	,zI3ROAZtiUq42rE9WDST68(u"ࠬ࡬ࡵ࡯ࡱࡱࡸࡻ࠭ኲ")				:yST5AHEfvPmcWpwGuh2BJ(u"࠭ๅ้ไ฼ࠤๆ์่็ࠢอ๎ๆ๐ࠧኳ")
	,mQNonhS7CV2BXOv(u"ࠧࡧࡷࡶ࡬ࡦࡸࡴࡷࠩኴ")				:vvWwO3Tx2dAgcijrFXq(u"ࠨ็๋ๆ฾ࠦแ้ึสีࠥะ๊โ์ࠪኵ")
	,UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠩࡩࡹࡸ࡮ࡡࡳࡸ࡬ࡨࡪࡵࠧ኶")			:vvWwO3Tx2dAgcijrFXq(u"้ࠪํู่ࠡใุ๋ฬืࠠโ์า๎ํ࠭኷")
	,mQNonhS7CV2BXOv(u"ࠫ࡬ࡵ࡯ࡥࠩኸ")					:vvWwO3Tx2dAgcijrFXq(u"ࠬา๊ะࠩኹ")
	,dDYUoKi6JFM23p(u"࠭ࡨࡢ࡮ࡤࡧ࡮ࡳࡡࠨኺ")				:dDYUoKi6JFM23p(u"ࠧๆ๊ๅ฽ࠥํไศࠢึ๎๊อࠧኻ")
	,yST5AHEfvPmcWpwGuh2BJ(u"ࠨࡪࡨࡰࡦࡲࠧኼ")				:dDYUoKi6JFM23p(u"่ࠩ์็฿่ࠠๆส่ࠥ๐่ห์๋ฬࠬኽ")
	,LAQD5wEkr18bUiGaYen3J(u"ࠪ࡭࡫࡯࡬࡮ࠩኾ")				:m6hwdgP31a2zjN7lkpX(u"๊ࠫ๎โฺࠢๅ๊ฬฯࠠร์ࠣๅ๏๊ๅࠨ኿")
	,vvWwO3Tx2dAgcijrFXq(u"ࠬ࡯ࡦࡪ࡮ࡰ࠱ࡦࡸࡡࡣ࡫ࡦࠫዀ")			:mmcNLrXtzfpyCkZlvK5VwG2gujh(u"࠭ๅ้ไ฼ࠤ็์วสࠢล๎ࠥ็๊ๅ็ࠣ฽ึฮ๊ࠨ዁")
	,dDYUoKi6JFM23p(u"ࠧࡪࡨ࡬ࡰࡲ࠳ࡥ࡯ࡩ࡯࡭ࡸ࡮ࠧዂ")		:shC5qBRV2A0lZ(u"ࠨ็๋ๆ฾ࠦโ็ษฬࠤว๐ࠠโ์็้ࠥอๆอๆํึ๏࠭ዃ")
	,Nh0BWuiSndf(u"ࠩ࡬ࡴࡹࡼࠧዄ")					:m6hwdgP31a2zjN7lkpX(u"ࠪࡍࡕ࡚ࡖࠨዅ")
	,SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠫ࡮ࡶࡴࡷ࠯࡯࡭ࡻ࡫ࠧ዆")			:DYakr9g4PVU(u"ࠬࡏࡐࡕࡘࠣๆ๋๎วหࠩ዇")
	,UUkIBz1sgQ9WfNeG6trKXvu0(u"࠭ࡩࡱࡶࡹ࠱ࡲࡵࡶࡪࡧࡶࠫወ")			:ddo23ZJtgcY(u"ࠧࡊࡒࡗ࡚ࠥษแๅษ่ࠫዉ")
	,BmePGjS7FxK6kutUM(u"ࠨ࡫ࡳࡸࡻ࠳ࡳࡦࡴ࡬ࡩࡸ࠭ዊ")			:vvWwO3Tx2dAgcijrFXq(u"ࠩࡌࡔ࡙࡜ࠠๆี็ื้อสࠨዋ")
	,HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠪ࡯ࡦࡸࡢࡢ࡮ࡤࡸࡻ࠭ዌ")			:Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"๊ࠫ๎โฺࠢๅ๊ฬฯࠠไำห่ฬวࠧው")
	,m6hwdgP31a2zjN7lkpX(u"ࠬࡱࡡࡵ࡭ࡲࡸࡹࡼࠧዎ")				:RRIHDFjoW9w7bSfVPhC(u"࠭ๅ้ไ฼ࠤ่ะใ้ฬࠣฮ๏็๊ࠨዏ")
	,S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠧ࡬ࡣࡷ࡯ࡴࡻࡴࡦࠩዐ")				:SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠨ็๋ๆ฾ࠦใหๅ๋ฮࠬዑ")
	,dDYUoKi6JFM23p(u"ࠩ࡮࡭ࡷࡳࡡ࡭࡭ࠪዒ")				:kke1PDGRBLuY8y(u"้ࠪํู่ࠡๅิ้ฬ๊ใࠨዓ")
	,mQNonhS7CV2BXOv(u"ࠫࡱࡧࡲࡰࡼࡤࠫዔ")				:Xz3bA2PFENVCUtplu51(u"๋่ࠬใ฻่ࠣฬื่ำษࠪዕ")
	,Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"࠭࡬ࡪࡤࡵࡥࡷࡿࠧዖ")				:LAQD5wEkr18bUiGaYen3J(u"ࠧๆๆไࠫ዗")
	,vvWwO3Tx2dAgcijrFXq(u"ࠨ࡮࡬ࡺࡪ࠭ዘ")					:HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"ࠩๅ๊ฬฯࠧዙ")
	,uVQd103XyvUce2EBtzbYaC(u"ࠪࡰ࡮ࡼࡥࡵࡸࠪዚ")				:ddo23ZJtgcY(u"๊๊ࠫแࠨዛ")
	,mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠬࡲ࡯ࡥࡻࡱࡩࡹ࠭ዜ")				:QQdAXWBc2GPw(u"࠭ๅ้ไ฼ࠤ้๎ฯ๋้ࠢฮࠬዝ")
	,QTUBCcehw6qPd4x(u"ࠧ࡮࠵ࡸࠫዞ")					:Mmpr0o76iWJvz1kTtfgI8hES(u"ࠨࡏ࠶࡙ࠬዟ")
	,dDYUoKi6JFM23p(u"ࠩࡰ࠷ࡺ࠳࡬ࡪࡸࡨࠫዠ")				:ubxGUTt1LraKhVZgpAP(u"ࠪࡑ࠸࡛ࠠใ่๋หฯ࠭ዡ")
	,kke1PDGRBLuY8y(u"ࠫࡲ࠹ࡵ࠮࡯ࡲࡺ࡮࡫ࡳࠨዢ")			:dDYUoKi6JFM23p(u"ࠬࡓ࠳ࡖࠢฦๅ้อๅࠨዣ")
	,HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"࠭࡭࠴ࡷ࠰ࡷࡪࡸࡩࡦࡵࠪዤ")			:S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠧࡎ࠵ࡘࠤู๊ไิๆสฮࠬዥ")
	,LAQD5wEkr18bUiGaYen3J(u"ࠨ࡯ࡤࡷࡦࡼࡩࡥࡧࡲࠫዦ")			:HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"่ࠩ์็฿ࠠๆษึหࠥ็๊ะ์๋ࠫዧ")
	,QQdAXWBc2GPw(u"ࠪࡱ࡮ࡹࡳࡪࡰࡪࠫየ")				:dDYUoKi6JFM23p(u"๊ࠫ็โ้ัࠪዩ")
	,P0qdZI384LKleuo(u"ࠬࡳ࡯ࡷࡵ࠷ࡹࠬዪ")				:S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"࠭ๅ้ไ฼ࠤ๊๎แำࠢไ์ึ๐่ࠨያ")
	,mQNonhS7CV2BXOv(u"ࠧ࡮ࡻࡦ࡭ࡲࡧࠧዬ")				:DYakr9g4PVU(u"ࠨ็๋ๆ฾ࠦๅศ์ࠣื๏๋วࠨይ")
	,zI3ROAZtiUq42rE9WDST68(u"ࠩࡲࡰࡩ࠭ዮ")					:VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠪๆิ๐ๅࠨዯ")
	,QTUBCcehw6qPd4x(u"ࠫࡵࡧ࡮ࡦࡶࠪደ")				:P0qdZI384LKleuo(u"๋่ࠬใ฻ࠣฬฬ์๊หࠩዱ")
	,IjZbnrBJmM2N(u"࠭ࡰࡢࡰࡨࡸ࠲ࡳ࡯ࡷ࡫ࡨࡷࠬዲ")			:Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠧๆ๊ๅ฽ࠥฮว็์อࠤฬ็ไศ็ࠪዳ")
	,SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠨࡲࡤࡲࡪࡺ࠭ࡴࡧࡵ࡭ࡪࡹࠧዴ")			:mmcNLrXtzfpyCkZlvK5VwG2gujh(u"่ࠩ์็฿ࠠษษ้๎ฯࠦๅิๆึ่ฬะࠧድ")
	,UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠪࡵ࡫࡯࡬࡮ࠩዶ")				:uVQd103XyvUce2EBtzbYaC(u"๊ࠫ๎โฺࠢๆ๎ํࠦแ๋ๆ่ࠫዷ")
	,SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠬࡹࡥࡳ࡫ࡨࡷࡹ࡯࡭ࡦࠩዸ")			:LAQD5wEkr18bUiGaYen3J(u"࠭ๅ้ไ฼ࠤุ๐ั๋ีࠣฮฬ๐ๅࠨዹ")
	,TYf7Dc06PQgy1vEV9(u"ࠧࡴࡪࡤࡦࡦࡱࡡࡵࡻࠪዺ")			:UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠨ็๋ๆ฾ࠦิษๅอ๎ࠬዻ")
	,QQdAXWBc2GPw(u"ࠩࡶ࡬ࡦ࡮ࡩࡥ࠶ࡸࠫዼ")				:BWNPxIG7vqdTy85pjHzUOrK3(u"้ࠪํู่ࠡึส๋ิࠦแ้ำํ์ࠬዽ")
	,UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠫࡸ࡮ࡡࡩ࡫ࡧࡲࡪࡽࡳࠨዾ")			:DYakr9g4PVU(u"๋่ࠬใ฻ุࠣฬํฯ่ࠡํ์ื࠭ዿ")
	,IjZbnrBJmM2N(u"࠭ࡳࡩ࡫ࡤࡺࡴ࡯ࡣࡦࠩጀ")			:LAQD5wEkr18bUiGaYen3J(u"ࠧๆ๊ๅ฽ࠥ฻่หࠢสู่๐ูสࠩጁ")
	,dDYUoKi6JFM23p(u"ࠨࡵ࡫࡭ࡦࡼ࡯ࡪࡥࡨ࠱ࡦࡲࡢࡶ࡯ࡶࠫጂ")		:BmePGjS7FxK6kutUM(u"่ࠩ์็฿ࠠึ๊อࠤฬ๊ิ๋฻ฬࠤฬ๊ศ้็ࠪጃ")
	,SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠪࡷ࡭࡯ࡡࡷࡱ࡬ࡧࡪ࠳ࡡࡶࡦ࡬ࡳࡸ࠭ጄ")		:Nh0BWuiSndf(u"๊ࠫ๎โฺุࠢ์ฯࠦวๅึํ฽ฮࠦี้ฬํหฯ࠭ጅ")
	,ddo23ZJtgcY(u"ࠬࡹࡨࡪࡣࡹࡳ࡮ࡩࡥ࠮ࡲࡨࡶࡸࡵ࡮ࡴࠩጆ")	:TYf7Dc06PQgy1vEV9(u"࠭ๅ้ไ฼ࠤฺ๎สࠡษ็ุ๏฿ษࠡไสีห࠭ጇ")
	,TYf7Dc06PQgy1vEV9(u"ࠧࡴࡪࡲࡪ࡭ࡧࠧገ")				:BWNPxIG7vqdTy85pjHzUOrK3(u"ࠨ็๋ๆ฾ࠦิ้ใ๊หࠥะ๊โ์ࠪጉ")
	,dDYUoKi6JFM23p(u"ࠩࡶ࡬ࡴࡵࡦ࡮ࡣࡻࠫጊ")				:IjZbnrBJmM2N(u"้ࠪํู่ࠡึ๋ๅ๋ࠥวไีࠪጋ")
	,VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠫࡸ࡮࡯ࡰࡨࡱࡩࡹ࠭ጌ")				:LAQD5wEkr18bUiGaYen3J(u"๋่ࠬใ฻ุࠣํ็ࠠ็ฬࠪግ")
	,zI3ROAZtiUq42rE9WDST68(u"࠭ࡳࡩࡱࡲࡪࡵࡸ࡯ࠨጎ")				:shC5qBRV2A0lZ(u"ࠧๆ๊ๅ฽ฺ่ࠥโࠢหีํ࠭ጏ")
	,vvWwO3Tx2dAgcijrFXq(u"ࠨࡶ࡬࡯ࡦࡧࡴࠨጐ")				:Xz3bA2PFENVCUtplu51(u"่ࠩ์็฿ࠠหๅสฮࠬ጑")
	,zI3ROAZtiUq42rE9WDST68(u"ࠪࡸࡻ࡬ࡵ࡯ࠩጒ")				:Xz3bA2PFENVCUtplu51(u"๊ࠫ๎โฺࠢอ๎ๆ๐ࠠโษ้ࠫጓ")
	,kke1PDGRBLuY8y(u"ࠬࡼࡡࡳࡤࡲࡲࠬጔ")				:BWNPxIG7vqdTy85pjHzUOrK3(u"࠭ๅ้ไ฼ࠤๆอัษ๊้ࠫጕ")
	,uVQd103XyvUce2EBtzbYaC(u"ࠧࡷ࡫ࡧࡩࡴ࠭጖")				:UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠨใํำ๏๎ࠧ጗")
	,S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"ࠩࡹ࡭ࡩ࡫࡯࡯ࡵࡤࡩࡲ࠭ጘ")			:mQNonhS7CV2BXOv(u"้ࠪํู่ࠡใํำ๏๎ࠠ็ีสส๊࠭ጙ")
	,zI3ROAZtiUq42rE9WDST68(u"ࠫࡼ࡫ࡣࡪ࡯ࡤ࠵ࠬጚ")				:Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"๋่ࠬใ฻ࠣ์๏ࠦำ๋็สࠤ࠶࠭ጛ")
	,VFjQx6Is28KvzLOmMXtg4GqTwa3(u"࠭ࡷࡦࡥ࡬ࡱࡦ࠸ࠧጜ")				:UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠧๆ๊ๅ฽ࠥ๎๊ࠡีํ้ฬࠦ࠲ࠨጝ")
	,kke1PDGRBLuY8y(u"ࠨࡻࡤࡵࡴࡺࠧጞ")				:P0qdZI384LKleuo(u"่ࠩ์็฿๋ࠠษๅ์ฯ࠭ጟ")
	,kke1PDGRBLuY8y(u"ࠪࡽࡴࡻࡴࡶࡤࡨࠫጠ")				:DYakr9g4PVU(u"๊ࠫ๎โฺࠢํ์ฯ๐่ษࠩጡ")
	,Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠬࡿ࡯ࡶࡶࡸࡦࡪ࠳ࡣࡩࡣࡱࡲࡪࡲࡳࠨጢ")		:Nh0BWuiSndf(u"࠭ๅ้ไ฼ࠤ๏๎ส๋๊หࠤ็์่ศฬࠪጣ")
	,shC5qBRV2A0lZ(u"ࠧࡺࡱࡸࡸࡺࡨࡥ࠮ࡲ࡯ࡥࡾࡲࡩࡴࡶࡶࠫጤ")	:RRIHDFjoW9w7bSfVPhC(u"ࠨ็๋ๆ฾๊้ࠦฬํ์อࠦโ้ษษ้ࠬጥ")
	,SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠩࡼࡳࡺࡺࡵࡣࡧ࠰ࡺ࡮ࡪࡥࡰࡵࠪጦ")		:dDYUoKi6JFM23p(u"้ࠪํู่ࠡ์๋ฮ๏๎ศࠡใํำ๏๎็ศฬࠪጧ")
	,UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠫࡾࡺࡢࡠࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠪጨ")			:Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"๋่ࠬศไ฼ࠤ๊์๋๊ࠠอ๎ํฮࠧጩ")
	}
	r5u4RaLbk3e7NG = vv5M4UfJS9ucKEiNbxtnaOZ.lower()
	for key in list(XXBpSNgTIPfmvtubMO14HhVis.keys()):
		b5dHRaQuJF9YUIG3wxMp6 = key.lower()
		if r5u4RaLbk3e7NG==b5dHRaQuJF9YUIG3wxMp6:
			vv5M4UfJS9ucKEiNbxtnaOZ = XXBpSNgTIPfmvtubMO14HhVis[key]
			break
	return vv5M4UfJS9ucKEiNbxtnaOZ
def AKQaWIc0YCHGVnT():
	pie0DRMAtn = uuxVm0bTwdnCUAL4s6NKHEBF3M.executeJSONRPC(Xz3bA2PFENVCUtplu51(u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥ࡭ࡩࠨ࠺࠲࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡖ࡬ࡢࡻ࡯࡭ࡸࡺ࠮ࡄ࡮ࡨࡥࡷࠨࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡵࡲࡡࡺ࡮࡬ࡷࡹ࡯ࡤࠣ࠼࠴ࢁࢂ࠭ጪ"))
	raise ValueError(Mmpr0o76iWJvz1kTtfgI8hES(u"ࠧࡠࡡࡢࡊࡔࡘࡃࡆࡡࡈ࡜ࡎ࡚࡟ࡠࡡࠪጫ"))
def qMGn9u2ckaXejCgUQhYTDP(FebMLrR4hCnsEZ5Nd,Y3Knv5Gt1JC92izgsLSAyd4=b8Qe150xVaJsnDSv):
	global uqTvH9CQaSkmBM1Dth
	uqTvH9CQaSkmBM1Dth = CCxMXuNUEzolDZTKrBJ
	if not Y3Knv5Gt1JC92izgsLSAyd4 and FebMLrR4hCnsEZ5Nd: Y3Knv5Gt1JC92izgsLSAyd4 = RRIHDFjoW9w7bSfVPhC(u"ࠨࡔࡈࡕ࡚ࡋࡓࡕࡡࡕࡉࡋࡘࡅࡔࡊࡢࡇࡆࡉࡈࡆࠩጬ")
	hRWC8YSFvsm4JHOMVIne3jquZ.setSetting(ubxGUTt1LraKhVZgpAP(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡸࡥࡧࡴࡨࡷ࡭࠭ጭ"),Y3Knv5Gt1JC92izgsLSAyd4)
	return
def HHbaVYqFRy6v0c(YabJfs3q7yjpzvXioO,Y2aF3tRvBKEUmHOe=IjZbnrBJmM2N(u"ࠪ࠾࠴࠭ጮ")):
	return _8wLoOXBHY52mTSAzlNJ(YabJfs3q7yjpzvXioO,Y2aF3tRvBKEUmHOe)
def e0IjES4nFb(RWNcfMIT6sv9):
	if RWNcfMIT6sv9 in [b8Qe150xVaJsnDSv,Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠫ࠵࠭ጯ"),LzYQg91SIxDeOGtCKd5]: return b8Qe150xVaJsnDSv
	RWNcfMIT6sv9 = int(RWNcfMIT6sv9)
	TFYZklfBIy8KwE92pbotn = RWNcfMIT6sv9^Q49IsrlSuYRAVbGKhwdckLDOetF2PZ
	PP35yDL10ln = RWNcfMIT6sv9^GMkNL1RXxKFentp0Zh9d
	CYiz7nXBF5V8tLmghs4KyM96bl = RWNcfMIT6sv9^LtlXH3fvMydAx
	rAY3l2eqI1FvO8X69 = str(TFYZklfBIy8KwE92pbotn)+str(PP35yDL10ln)+str(CYiz7nXBF5V8tLmghs4KyM96bl)
	return rAY3l2eqI1FvO8X69
def yrMgQPDUKjz41TLlo(RWNcfMIT6sv9):
	if RWNcfMIT6sv9 in [b8Qe150xVaJsnDSv,P0qdZI384LKleuo(u"ࠬ࠶ࠧጰ"),LzYQg91SIxDeOGtCKd5]: return b8Qe150xVaJsnDSv
	RWNcfMIT6sv9 = str(RWNcfMIT6sv9)
	rAY3l2eqI1FvO8X69 = b8Qe150xVaJsnDSv
	if len(RWNcfMIT6sv9)==m6hwdgP31a2zjN7lkpX(u"࠶࠻ᓾ"):
		TFYZklfBIy8KwE92pbotn,PP35yDL10ln,CYiz7nXBF5V8tLmghs4KyM96bl = RWNcfMIT6sv9[LzYQg91SIxDeOGtCKd5:NvHugPosYDzRJ],RWNcfMIT6sv9[NvHugPosYDzRJ:dDYUoKi6JFM23p(u"࠿ᓿ")],RWNcfMIT6sv9[dDYUoKi6JFM23p(u"࠿ᓿ"):]
		TFYZklfBIy8KwE92pbotn = int(TFYZklfBIy8KwE92pbotn)^LtlXH3fvMydAx
		PP35yDL10ln = int(PP35yDL10ln)^GMkNL1RXxKFentp0Zh9d
		CYiz7nXBF5V8tLmghs4KyM96bl = int(CYiz7nXBF5V8tLmghs4KyM96bl)^Q49IsrlSuYRAVbGKhwdckLDOetF2PZ
		if TFYZklfBIy8KwE92pbotn==PP35yDL10ln==CYiz7nXBF5V8tLmghs4KyM96bl: rAY3l2eqI1FvO8X69 = str(TFYZklfBIy8KwE92pbotn*Xz3bA2PFENVCUtplu51(u"࠶࠱ᔀ"))
	return rAY3l2eqI1FvO8X69
def hk9Mxv3LzSHl42AUdfs0ejF7qcVw(RWNcfMIT6sv9,gwfVnrmKJEH3Sx=LAQD5wEkr18bUiGaYen3J(u"࠭࠶࠴࠺࠷࠵࠽࠸࠳ࠨጱ")):
	if RWNcfMIT6sv9==b8Qe150xVaJsnDSv: return b8Qe150xVaJsnDSv
	RWNcfMIT6sv9 = int(RWNcfMIT6sv9)+int(gwfVnrmKJEH3Sx)
	TFYZklfBIy8KwE92pbotn = RWNcfMIT6sv9^Q49IsrlSuYRAVbGKhwdckLDOetF2PZ
	PP35yDL10ln = RWNcfMIT6sv9^GMkNL1RXxKFentp0Zh9d
	CYiz7nXBF5V8tLmghs4KyM96bl = RWNcfMIT6sv9^LtlXH3fvMydAx
	rAY3l2eqI1FvO8X69 = str(TFYZklfBIy8KwE92pbotn)+str(PP35yDL10ln)+str(CYiz7nXBF5V8tLmghs4KyM96bl)
	return rAY3l2eqI1FvO8X69
def vdkzUJEgiO2Poj0Ih3pL(RWNcfMIT6sv9,gwfVnrmKJEH3Sx=QQdAXWBc2GPw(u"ࠧ࠷࠵࠻࠸࠶࠾࠲࠴ࠩጲ")):
	if RWNcfMIT6sv9==b8Qe150xVaJsnDSv: return b8Qe150xVaJsnDSv
	RWNcfMIT6sv9 = str(RWNcfMIT6sv9)
	n6TDI30gecEMhLYbtPNJoy = int(len(RWNcfMIT6sv9)/VwApyDY1Jc)
	TFYZklfBIy8KwE92pbotn = int(RWNcfMIT6sv9[LzYQg91SIxDeOGtCKd5:n6TDI30gecEMhLYbtPNJoy])^Q49IsrlSuYRAVbGKhwdckLDOetF2PZ
	PP35yDL10ln = int(RWNcfMIT6sv9[n6TDI30gecEMhLYbtPNJoy:IgQimel18t*n6TDI30gecEMhLYbtPNJoy])^GMkNL1RXxKFentp0Zh9d
	CYiz7nXBF5V8tLmghs4KyM96bl = int(RWNcfMIT6sv9[IgQimel18t*n6TDI30gecEMhLYbtPNJoy:VwApyDY1Jc*n6TDI30gecEMhLYbtPNJoy])^LtlXH3fvMydAx
	rAY3l2eqI1FvO8X69 = b8Qe150xVaJsnDSv
	if TFYZklfBIy8KwE92pbotn==PP35yDL10ln==CYiz7nXBF5V8tLmghs4KyM96bl: rAY3l2eqI1FvO8X69 = str(int(TFYZklfBIy8KwE92pbotn)-int(gwfVnrmKJEH3Sx))
	return rAY3l2eqI1FvO8X69
def Yvr0IT4L5Q(XgMrI9aqeVGd7BSEl):
	Cz5q41Soh0rytExDKF9P = nTHXJIiah2qK[kke1PDGRBLuY8y(u"ࠨࡒ࡜ࡘࡍࡕࡎࠨጳ")][RRIHDFjoW9w7bSfVPhC(u"࠹ᔁ")]
	D8DQ1IYejnzRmx4ZHgusMbdF = x76PfMyAp1L2WejkU3.path.join(JnlzVBayd7WFKtCOH0,uVQd103XyvUce2EBtzbYaC(u"ࠩࡵࡩࡸࡵࡵࡳࡥࡨࡷࠬጴ"),SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠪࡷࡰ࡯࡮ࡴࠩጵ"),m6hwdgP31a2zjN7lkpX(u"ࠫࡉ࡫ࡦࡢࡷ࡯ࡸࠬጶ"),BmePGjS7FxK6kutUM(u"ࠬ࠽࠲࠱ࡲࠪጷ"),Mmpr0o76iWJvz1kTtfgI8hES(u"࠭ࡄࡪࡣ࡯ࡳ࡬ࡉ࡯࡯ࡨ࡬ࡶࡲ࡚ࡨࡳࡧࡨࡆࡺࡺࡴࡰࡰࡶ࠲ࡽࡳ࡬ࠨጸ"))
	rpxubIMvQqD,o1FEdaUfIGehp3 = HTuoYBfsP0GE(D8DQ1IYejnzRmx4ZHgusMbdF)
	rpxubIMvQqD = hk9Mxv3LzSHl42AUdfs0ejF7qcVw(rpxubIMvQqD,P0qdZI384LKleuo(u"ࠧ࠲࠴࠴࠼࠸࠷࠸࠶࠵ࠪጹ"))
	BO7Mgqi3Aa = {Xz3bA2PFENVCUtplu51(u"ࠨ࡫ࡧࡷࠬጺ"):ddo23ZJtgcY(u"ࠩࡇࡍࡆࡒࡏࡈࠩጻ"),zI3ROAZtiUq42rE9WDST68(u"ࠪࡹࡸࡸࠧጼ"):EtvK0T2LNPcsIrAFlufpM,mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠫࡻ࡫ࡲࠨጽ"):cpGrK6qnPi,shC5qBRV2A0lZ(u"ࠬࡹࡣࡳࠩጾ"):XgMrI9aqeVGd7BSEl,Nh0BWuiSndf(u"࠭ࡳࡪࡼࠪጿ"):rpxubIMvQqD}
	p1TDEQaX3wPkhtH8 = {mmcNLrXtzfpyCkZlvK5VwG2gujh(u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭ፀ"):BmePGjS7FxK6kutUM(u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪࠧፁ")}
	fh8gyDR6JTU = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,Nh0BWuiSndf(u"ࠩࡓࡓࡘ࡚ࠧፂ"),Cz5q41Soh0rytExDKF9P,BO7Mgqi3Aa,p1TDEQaX3wPkhtH8,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,Mmpr0o76iWJvz1kTtfgI8hES(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡘࡎࡏࡘࡡࡓࡐࡆ࡟࡟ࡅࡋࡄࡐࡔࡍ࠭࠲ࡵࡷࠫፃ"))
	vw924XlsGPihk0jafVyIp = fh8gyDR6JTU.content
	try:
		if not vw924XlsGPihk0jafVyIp: KwGHvyVP48A5j9nQa0dBIuFo2xm7s3
		T8HhimSYeUk51MICX = oJsUwXA0yGOI1mTjxQ(P0qdZI384LKleuo(u"ࠫࡩ࡯ࡣࡵࠩፄ"),vw924XlsGPihk0jafVyIp)
		woElzkZgyVq8IbJdrXTx = T8HhimSYeUk51MICX[mQNonhS7CV2BXOv(u"ࠬࡳࡳࡨࠩፅ")]
		Fwr6KiQm8guzNjf1S = T8HhimSYeUk51MICX[S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"࠭ࡳࡦࡥࠪፆ")]
		dw1NhTW3ZAqmrt2skn67a8Cgyzifp = T8HhimSYeUk51MICX[RRIHDFjoW9w7bSfVPhC(u"ࠧࡴࡶࡳࠫፇ")]
		Fwr6KiQm8guzNjf1S = int(vdkzUJEgiO2Poj0Ih3pL(Fwr6KiQm8guzNjf1S,vvWwO3Tx2dAgcijrFXq(u"ࠨ࠳࠵࠵࠽࠹࠱࠹࠷࠶ࠫፈ")))
		dw1NhTW3ZAqmrt2skn67a8Cgyzifp = int(vdkzUJEgiO2Poj0Ih3pL(dw1NhTW3ZAqmrt2skn67a8Cgyzifp,Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠩ࠴࠶࠶࠾࠳࠲࠺࠸࠷ࠬፉ")))
		for wwfyPtb2dJgUQ7E05pI9rAj in range(Fwr6KiQm8guzNjf1S,LzYQg91SIxDeOGtCKd5,-dw1NhTW3ZAqmrt2skn67a8Cgyzifp):
			if not eval(TYf7Dc06PQgy1vEV9(u"ࠪࡼࡧࡳࡣ࠯ࡒ࡯ࡥࡾ࡫ࡲࠩࠫ࠱࡭ࡸࡖ࡬ࡢࡻ࡬ࡲ࡬࠮ࠩࠨፊ"),{m6hwdgP31a2zjN7lkpX(u"ࠫࡽࡨ࡭ࡤࠩፋ"):uuxVm0bTwdnCUAL4s6NKHEBF3M}): KwGHvyVP48A5j9nQa0dBIuFo2xm7s3
			yicQV3gj4q(vvWwO3Tx2dAgcijrFXq(u"ࠬฮวใ์่้ࠣะฬาสฬࠤํอไโฯุࠫፌ"),str(wwfyPtb2dJgUQ7E05pI9rAj)+BWNPxIG7vqdTy85pjHzUOrK3(u"࠭ࠠࠡอส๊๏ฯࠧፍ"),wLQCTr5lqbsVYeAHdzfhZ1F=TYf7Dc06PQgy1vEV9(u"࠵࠳࠴ᔂ")*dw1NhTW3ZAqmrt2skn67a8Cgyzifp)
			uuxVm0bTwdnCUAL4s6NKHEBF3M.sleep(mmcNLrXtzfpyCkZlvK5VwG2gujh(u"࠴࠴࠵࠶ᔃ")*dw1NhTW3ZAqmrt2skn67a8Cgyzifp)
		if eval(mQNonhS7CV2BXOv(u"ࠧࡹࡤࡰࡧ࠳ࡖ࡬ࡢࡻࡨࡶ࠭࠯࠮ࡪࡵࡓࡰࡦࡿࡩ࡯ࡩࠫ࠭ࠬፎ"),{DYakr9g4PVU(u"ࠨࡺࡥࡱࡨ࠭ፏ"):uuxVm0bTwdnCUAL4s6NKHEBF3M}):
			woElzkZgyVq8IbJdrXTx = woElzkZgyVq8IbJdrXTx.replace(eeN6dTEnkJxI,yST5AHEfvPmcWpwGuh2BJ(u"ࠩ࡟ࡠࡳ࠭ፐ")).replace(d6ekSEojpFUANKJ7r9WTlI3niLBOu,Mmpr0o76iWJvz1kTtfgI8hES(u"ࠪࡠࡡࡸࠧፑ"))
			tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,ubxGUTt1LraKhVZgpAP(u"ࠫำื่อࠩፒ"),DYakr9g4PVU(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨፓ"),woElzkZgyVq8IbJdrXTx)
		KwGHvyVP48A5j9nQa0dBIuFo2xm7s3
	except: exec(Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"࠭ࡸࡣ࡯ࡦ࠲ࡕࡲࡡࡺࡧࡵࠬ࠮࠴ࡳࡵࡱࡳࠬ࠮࠭ፔ"),{IjZbnrBJmM2N(u"ࠧࡹࡤࡰࡧࠬፕ"):uuxVm0bTwdnCUAL4s6NKHEBF3M})
	return
def llqyRw7Wkuv2MmLiC1jUa():
	exec(TYf7Dc06PQgy1vEV9(u"ࠨࠩࠪࠑࠏࡺࡲࡺ࠼ࠐࠎࠎࡽࡩ࡯ࡦࡲࡻ࠶࠸࠳ࠡ࠿ࠣࡼࡧࡳࡣࡨࡷ࡬࠲࡜࡯࡮ࡥࡱࡺࠬ࠶࠶࠰࠳࠷ࠬࠑࠏࠏࡷࡩ࡫࡯ࡩ࡚ࠥࡲࡶࡧ࠽ࠑࠏࠏࠉࡹࡤࡰࡧ࠳ࡹ࡬ࡦࡧࡳࠬ࠶࠶࠰࠱ࠫࠐࠎࠎࠏࡴࡳࡻ࠽ࠤࡼ࡯࡮ࡥࡱࡺ࠵࠷࠹࠮ࡨࡧࡷࡊࡴࡩࡵࡴࠪ࠴࠴࠵࠸࠵ࠪࠏࠍࠍࠎ࡫ࡸࡤࡧࡳࡸ࠿ࠦࡢࡳࡧࡤ࡯ࠒࠐࠉࡻࡥࡵࡩࡦࡺࡥࡠࡧࡵࡳࡷࡸࠍࠋࡧࡻࡧࡪࡶࡴ࠻ࠢࡻࡦࡲࡩ࠮ࡑ࡮ࡤࡽࡪࡸࠨࠪ࠰ࡶࡸࡴࡶࠨࠪࠏࠍࠫࠬ࠭ፖ"),{TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠩࡻࡦࡲࡩࡧࡶ࡫ࠪፗ"):evil9I2DnLJcy8,P0qdZI384LKleuo(u"ࠪࡼࡧࡳࡣࠨፘ"):uuxVm0bTwdnCUAL4s6NKHEBF3M})
	return
def HTuoYBfsP0GE(IrtJbkGzf0wNZUgvuYC7):
	zudAYSMEwx1f4D8pZU3v0sQGkW7F,MJGQBx4rhWt5N3kd1IeFnT = LzYQg91SIxDeOGtCKd5,LzYQg91SIxDeOGtCKd5
	if x76PfMyAp1L2WejkU3.path.exists(IrtJbkGzf0wNZUgvuYC7):
		try: zudAYSMEwx1f4D8pZU3v0sQGkW7F = x76PfMyAp1L2WejkU3.path.getsize(IrtJbkGzf0wNZUgvuYC7)
		except: pass
		if not zudAYSMEwx1f4D8pZU3v0sQGkW7F:
			try: zudAYSMEwx1f4D8pZU3v0sQGkW7F = x76PfMyAp1L2WejkU3.stat(IrtJbkGzf0wNZUgvuYC7).st_size
			except: pass
		if not zudAYSMEwx1f4D8pZU3v0sQGkW7F:
			try:
				from pathlib import Path as pp7GvSgDF6TVcW
				zudAYSMEwx1f4D8pZU3v0sQGkW7F = pp7GvSgDF6TVcW(IrtJbkGzf0wNZUgvuYC7).stat().st_size
			except: pass
		if zudAYSMEwx1f4D8pZU3v0sQGkW7F: MJGQBx4rhWt5N3kd1IeFnT = qHYIWnOZLPkrQU
	return zudAYSMEwx1f4D8pZU3v0sQGkW7F,MJGQBx4rhWt5N3kd1IeFnT
def d9IVrTfkDxj(Gx9o1T3t8i4INgPc06k2BLUyOZw5fX,showDialogs):
	if showDialogs:
		aVwGA2kFY6u4m = BjMmX1vNrnzSAf(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,Nh0BWuiSndf(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧፙ"),Gx9o1T3t8i4INgPc06k2BLUyOZw5fX+QTUBCcehw6qPd4x(u"ࠬࡢ࡮࡝ࡰࠪፚ")+rC3Tlno96KjLDIvBaSWUbR8+S0IlDPhBN3gMEUvnjRLXsYAc2Zf(u"࠭็ๅࠢอี๏ีࠠๆีะࠤ์ึวࠡษ็้้็ࠠภࠣࠪ፛")+hAIp8kmC36T5WFPMSXOwnNbtD)
		if aVwGA2kFY6u4m!=shC5qBRV2A0lZ(u"࠵ᔄ"): return
	c0sLTrUSbG1eqjYDdzoptAuh = DD5cFIejQa2X4BgAu9GWPyJ3tC7
	if x76PfMyAp1L2WejkU3.path.exists(Gx9o1T3t8i4INgPc06k2BLUyOZw5fX):
		try: x76PfMyAp1L2WejkU3.remove(Gx9o1T3t8i4INgPc06k2BLUyOZw5fX.decode(OVauxZzLI10vcXT74K))
		except:
			try: x76PfMyAp1L2WejkU3.remove(Vncxw2DQd03j)
			except Exception as ccTS9i8vbawOYyKfUe3E6rh0:
				if showDialogs: tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,dDYUoKi6JFM23p(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ፜"),str(ccTS9i8vbawOYyKfUe3E6rh0))
				c0sLTrUSbG1eqjYDdzoptAuh = CCxMXuNUEzolDZTKrBJ
	if showDialogs:
		if c0sLTrUSbG1eqjYDdzoptAuh: tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,TYf7Dc06PQgy1vEV9(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ፝"),QTUBCcehw6qPd4x(u"ࠩไุ้ะฺࠠ็็๎ฮࠦๅิฯࠣห้๋ไโࠩ፞"))
		else:
			tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,LAQD5wEkr18bUiGaYen3J(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭፟"),LAQD5wEkr18bUiGaYen3J(u"ࠫฯ๋ࠠศๆ่ืาࠦศ็ฮสัࠬ፠"))
			qMGn9u2ckaXejCgUQhYTDP(DD5cFIejQa2X4BgAu9GWPyJ3tC7)
	return
def p3pjrEcdKBfsDZw4qSJ(mdD5Ep6gB4rfUA2zLKHIX0CQoO,x0xRdf61o9mv5NZ,showDialogs):
	if showDialogs:
		aVwGA2kFY6u4m = BjMmX1vNrnzSAf(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,m6hwdgP31a2zjN7lkpX(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ፡"),mdD5Ep6gB4rfUA2zLKHIX0CQoO+kke1PDGRBLuY8y(u"࠭࡜࡯࡞ࡱࠫ።")+rC3Tlno96KjLDIvBaSWUbR8+Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"่ࠧๆࠣฮึ๐ฯࠡ็ึัࠥํะศࠢส่๊าไะࠢยࠥࠬ፣")+hAIp8kmC36T5WFPMSXOwnNbtD)
		if aVwGA2kFY6u4m!=qHYIWnOZLPkrQU: return
	DXh6Ta4KnjN = DD5cFIejQa2X4BgAu9GWPyJ3tC7
	if x76PfMyAp1L2WejkU3.path.exists(mdD5Ep6gB4rfUA2zLKHIX0CQoO):
		for McGhkSLOlX5HAJtKPZr,JxsbNOUt1lHT4Rr8uainPKv5,G4upaV8ed9NfPAc in x76PfMyAp1L2WejkU3.walk(mdD5Ep6gB4rfUA2zLKHIX0CQoO,topdown=DD5cFIejQa2X4BgAu9GWPyJ3tC7):
			for IrtJbkGzf0wNZUgvuYC7 in G4upaV8ed9NfPAc:
				Wzs6RwZcql15C3HrXfo = x76PfMyAp1L2WejkU3.path.join(McGhkSLOlX5HAJtKPZr,IrtJbkGzf0wNZUgvuYC7)
				try: x76PfMyAp1L2WejkU3.remove(Wzs6RwZcql15C3HrXfo)
				except Exception as uXp8Hv2nDt:
					if showDialogs and not DXh6Ta4KnjN: tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,kke1PDGRBLuY8y(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ፤"),str(uXp8Hv2nDt))
					DXh6Ta4KnjN = CCxMXuNUEzolDZTKrBJ
			if x0xRdf61o9mv5NZ:
				for dir in JxsbNOUt1lHT4Rr8uainPKv5:
					EW57j4lF6RwZzCeOuG = x76PfMyAp1L2WejkU3.path.join(McGhkSLOlX5HAJtKPZr,dir)
					try: x76PfMyAp1L2WejkU3.rmdir(EW57j4lF6RwZzCeOuG)
					except: pass
		if x0xRdf61o9mv5NZ:
			try: x76PfMyAp1L2WejkU3.rmdir(McGhkSLOlX5HAJtKPZr)
			except: pass
	if showDialogs and not DXh6Ta4KnjN:
		tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,ddo23ZJtgcY(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ፥"),SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠪฮ๊ࠦวๅ็ึัࠥฮๆอษะࠫ፦"))
		qMGn9u2ckaXejCgUQhYTDP(DD5cFIejQa2X4BgAu9GWPyJ3tC7)
	return
def iPw18YvqUjlGMoL2N(nWxkguOY04XVsEwQJ,ufxrtSb9vkTpPhqG8WK,YabJfs3q7yjpzvXioO,kTSyagGWsFnolYhMO5fCwvpNuPqR,Hjb64dTft8SzJ,fOzS45youKYdNDqwm61aEI3A):
	MUJCtfYVBLODrFbaZn,wrVWChaBPjl3XLucdoxIEM72t6,uKNTqB5FAPjao2Xg4GEcUzltOksdx,yMAcL5oOp31 = KKRSdoITymChfstN3l6jvOnJMPU(YabJfs3q7yjpzvXioO)
	QpHl0Efc7yvn2V = ufxrtSb9vkTpPhqG8WK,MUJCtfYVBLODrFbaZn,kTSyagGWsFnolYhMO5fCwvpNuPqR,Hjb64dTft8SzJ
	if nWxkguOY04XVsEwQJ<ddo23ZJtgcY(u"࠵ᔅ"):
		zqbhiLmQfC3VK9Arku(mshLJcKH1fv03yRnDOr4ZT,m6hwdgP31a2zjN7lkpX(u"ࠫࡔࡖࡅࡏࡗࡕࡐࡤ࡛ࡒࡍࡎࡌࡆࠬ፧"),QpHl0Efc7yvn2V)
		nWxkguOY04XVsEwQJ = -nWxkguOY04XVsEwQJ
	if nWxkguOY04XVsEwQJ>ddo23ZJtgcY(u"࠶ᔆ"):
		oH3N1dY9vLpaDJfnTVP5Z7q = SS2OK7hjLagvUAm(mshLJcKH1fv03yRnDOr4ZT,Dzs8qU2gQMcCSyRhiZn4TFbeGk(u"ࠬࡹࡴࡳࠩ፨"),dDYUoKi6JFM23p(u"࠭ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡖࡔࡏࡐࡎࡈࠧ፩"),QpHl0Efc7yvn2V)
		if oH3N1dY9vLpaDJfnTVP5Z7q:
			IYuvgrd2fS(QQdAXWBc2GPw(u"ࠧࡖࡔࡏࡐࡎࡈࠠࠡࡔࡈࡅࡉࡥࡃࡂࡅࡋࡉࠬ፪"),YabJfs3q7yjpzvXioO,kTSyagGWsFnolYhMO5fCwvpNuPqR,Hjb64dTft8SzJ,fOzS45youKYdNDqwm61aEI3A,ufxrtSb9vkTpPhqG8WK)
			return oH3N1dY9vLpaDJfnTVP5Z7q
	oH3N1dY9vLpaDJfnTVP5Z7q = s0oSQWhNPM3kBrp5(ufxrtSb9vkTpPhqG8WK,YabJfs3q7yjpzvXioO,kTSyagGWsFnolYhMO5fCwvpNuPqR,Hjb64dTft8SzJ,fOzS45youKYdNDqwm61aEI3A)
	if oH3N1dY9vLpaDJfnTVP5Z7q and nWxkguOY04XVsEwQJ: PGudrhJF8iDkSq96XVHEQZYf5L(mshLJcKH1fv03yRnDOr4ZT,m6hwdgP31a2zjN7lkpX(u"ࠨࡑࡓࡉࡓ࡛ࡒࡍࡡࡘࡖࡑࡒࡉࡃࠩ፫"),QpHl0Efc7yvn2V,oH3N1dY9vLpaDJfnTVP5Z7q,nWxkguOY04XVsEwQJ)
	return oH3N1dY9vLpaDJfnTVP5Z7q
def NBzFpYl7jSk(QQ8pvXNcBfVkP5rRJ7o,t8I97woPTViq0sSuU,RD2FKsbZHp9USmijLG1wuoeMk78A3=LzYQg91SIxDeOGtCKd5):
	HqtyW7PeSXARZ = hRWC8YSFvsm4JHOMVIne3jquZ.getSetting(mQNonhS7CV2BXOv(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡨࡩࡵࡴࡤࡸࡪ࠭፬"))
	if HqtyW7PeSXARZ and TYf7Dc06PQgy1vEV9(u"ࠪ࠱ࠬ፭") not in HqtyW7PeSXARZ: SxJIWAMj86cQms5agzf0,pNKCu4yjvHxGae0LwTclQI2Dmn = int(HqtyW7PeSXARZ),CCxMXuNUEzolDZTKrBJ
	elif RD2FKsbZHp9USmijLG1wuoeMk78A3: SxJIWAMj86cQms5agzf0,pNKCu4yjvHxGae0LwTclQI2Dmn = RD2FKsbZHp9USmijLG1wuoeMk78A3,DD5cFIejQa2X4BgAu9GWPyJ3tC7
	else: return []
	ZBk9UfqF5VhK,JHb0Y2geWCOhjtyTxQzMV = [],b8Qe150xVaJsnDSv
	ZzdoUxaMI0CjEGgnrl,LtYTrIOmpCz4M7Kv,ELChmvJ6DS8iYrbF0fuH9,LLkme0Cxf2ptywX3 = b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,LzYQg91SIxDeOGtCKd5,LzYQg91SIxDeOGtCKd5
	t8I97woPTViq0sSuU = sorted(t8I97woPTViq0sSuU,reverse=CCxMXuNUEzolDZTKrBJ,key=lambda key: (key[qHYIWnOZLPkrQU],key[IgQimel18t]))
	for stream,XjgdBvZ314FVfHixUAo6IyElPMm,F8Ef6K7kCy9mbQPx in t8I97woPTViq0sSuU+[[b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,LzYQg91SIxDeOGtCKd5]]:
		if XjgdBvZ314FVfHixUAo6IyElPMm==JHb0Y2geWCOhjtyTxQzMV:
			if F8Ef6K7kCy9mbQPx>SxJIWAMj86cQms5agzf0: LtYTrIOmpCz4M7Kv,LLkme0Cxf2ptywX3 = stream,F8Ef6K7kCy9mbQPx
			elif not ZzdoUxaMI0CjEGgnrl: ZzdoUxaMI0CjEGgnrl,ELChmvJ6DS8iYrbF0fuH9 = stream,F8Ef6K7kCy9mbQPx
		else:
			if LtYTrIOmpCz4M7Kv or ZzdoUxaMI0CjEGgnrl:
				if ZzdoUxaMI0CjEGgnrl: ZBk9UfqF5VhK.append([ZzdoUxaMI0CjEGgnrl,JHb0Y2geWCOhjtyTxQzMV,ELChmvJ6DS8iYrbF0fuH9])
				elif LtYTrIOmpCz4M7Kv: ZBk9UfqF5VhK.append([LtYTrIOmpCz4M7Kv,JHb0Y2geWCOhjtyTxQzMV,LLkme0Cxf2ptywX3])
			if F8Ef6K7kCy9mbQPx>SxJIWAMj86cQms5agzf0:
				LtYTrIOmpCz4M7Kv,LLkme0Cxf2ptywX3 = stream,F8Ef6K7kCy9mbQPx
				ZzdoUxaMI0CjEGgnrl,ELChmvJ6DS8iYrbF0fuH9 = b8Qe150xVaJsnDSv,LzYQg91SIxDeOGtCKd5
			else:
				LtYTrIOmpCz4M7Kv,LLkme0Cxf2ptywX3 = b8Qe150xVaJsnDSv,LzYQg91SIxDeOGtCKd5
				ZzdoUxaMI0CjEGgnrl,ELChmvJ6DS8iYrbF0fuH9 = stream,F8Ef6K7kCy9mbQPx
		JHb0Y2geWCOhjtyTxQzMV = XjgdBvZ314FVfHixUAo6IyElPMm
	if pNKCu4yjvHxGae0LwTclQI2Dmn:
		xx9Jvpo2yuCtK,wzvqmAXSp8WY9KHEJfcRoZ6ax,EERoCcutFWJ8Y613S = zip(*ZBk9UfqF5VhK)
		KxJi6QFwrSGzR8M37bLW9C4mp21Yy = [TT8Mxv5Wq7nlC9IscdpPUY6(u"ࠫࡲࡶ࠴ࠨ፮"),Y2t8baH5GWikvOZ7NsCeq3TKrgMV(u"ࠬࡳࡰࡥࠩ፯"),IjZbnrBJmM2N(u"࠭ࡴࡴࠩ፰"),shC5qBRV2A0lZ(u"ࠧ࡮࠵ࡸࠫ፱")]
		for XjgdBvZ314FVfHixUAo6IyElPMm in KxJi6QFwrSGzR8M37bLW9C4mp21Yy:
			if XjgdBvZ314FVfHixUAo6IyElPMm in wzvqmAXSp8WY9KHEJfcRoZ6ax:
				index = wzvqmAXSp8WY9KHEJfcRoZ6ax.index(XjgdBvZ314FVfHixUAo6IyElPMm)
				ZBk9UfqF5VhK = [[xx9Jvpo2yuCtK[index],wzvqmAXSp8WY9KHEJfcRoZ6ax[index],EERoCcutFWJ8Y613S[index]]]
				break
	return ZBk9UfqF5VhK
def aOAE24IDufWJlKUyrFsYz(M6VfOXgtvuFd2UGr):
	uaOf3Ajwiv,D0X6QWl1gMFIypOUZCqd4 = [],None
	for TFAmLfwypkzsP1UYCMr8c in bT46adeyIWDBiArPH3V5027:
		if TFAmLfwypkzsP1UYCMr8c==ddo23ZJtgcY(u"ࠨࡒࡕࡍ࡛ࡇࡔࡆࠩ፲"): D0X6QWl1gMFIypOUZCqd4 = (Mmpr0o76iWJvz1kTtfgI8hES(u"ࠩ࡯࡭ࡳࡱࠧ፳"),rC3Tlno96KjLDIvBaSWUbR8+yST5AHEfvPmcWpwGuh2BJ(u"้ࠪํอโฺࠢึ๎ึ็ัศฬࠣาฬ฻ษࠡ࠯ࠣๆ้๐ไสࠢสฺ่๊วไๆࠪ፴")+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,m6hwdgP31a2zjN7lkpX(u"࠱࠶࠹ᔇ"),b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv)
		elif TFAmLfwypkzsP1UYCMr8c==Mmpr0o76iWJvz1kTtfgI8hES(u"ࠫࡒࡏࡘࡆࡆࠪ፵"): D0X6QWl1gMFIypOUZCqd4 = (DYakr9g4PVU(u"ࠬࡲࡩ࡯࡭ࠪ፶"),rC3Tlno96KjLDIvBaSWUbR8+mmcNLrXtzfpyCkZlvK5VwG2gujh(u"࠭ๅ้ษๅ฽ู๊ࠥาใิหฯࠦฮศืฬࠤํ฿วๆหࠣ࠱้ࠥห๋ำฬࠤฬ๊ๅีษๆ่ࠬ፷")+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,HwB7ydlWVJeCtPuQ6MDE1RTYOo(u"࠲࠷࠺ᔈ"),b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv)
		elif TFAmLfwypkzsP1UYCMr8c==UUkIBz1sgQ9WfNeG6trKXvu0(u"ࠧࡑࡗࡅࡐࡎࡉࠧ፸"): D0X6QWl1gMFIypOUZCqd4 = (VFjQx6Is28KvzLOmMXtg4GqTwa3(u"ࠨ࡮࡬ࡲࡰ࠭፹"),rC3Tlno96KjLDIvBaSWUbR8+IjZbnrBJmM2N(u"่ࠩ์ฬู่ࠡีํีๆืวหࠢ฼ห๊ฯࠠ࠮ࠢๆฯ๏ืษࠡษ็ู้อใๅࠩ፺")+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,RRIHDFjoW9w7bSfVPhC(u"࠳࠸࠻ᔉ"),b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv)
		if TFAmLfwypkzsP1UYCMr8c not in M6VfOXgtvuFd2UGr: continue
		if D0X6QWl1gMFIypOUZCqd4:
			uaOf3Ajwiv.append(D0X6QWl1gMFIypOUZCqd4)
			D0X6QWl1gMFIypOUZCqd4 = None
		if TFAmLfwypkzsP1UYCMr8c not in [IjZbnrBJmM2N(u"ࠪࡔࡗࡏࡖࡂࡖࡈࠫ፻"),zI3ROAZtiUq42rE9WDST68(u"ࠫࡒࡏࡘࡆࡆࠪ፼"),SbjiWeHLQPoazqwp3cODkd7YxVgn(u"ࠬࡖࡕࡃࡎࡌࡇࠬ፽")]: uaOf3Ajwiv.append(TFAmLfwypkzsP1UYCMr8c)
	return uaOf3Ajwiv
from mmWBhYKlaj import *
# -*- coding: utf-8 -*-
from hIVCFnfxSO import *
QQ8pvXNcBfVkP5rRJ7o = 'SHAHID4U'
WbzmKSZiuOYrBN7oysJ2dUv = '_SH4_'
wQjs1XZ3AO24g8y9bEeoKMiGIu7 = nTHXJIiah2qK[QQ8pvXNcBfVkP5rRJ7o][0]
headers = {'User-Agent':kIMmsSG9NW6BOjlTpnEcuRzgwK(True)}
v1vJEhoNQBVPkjG = ['عروض مصارعة','الكل','افلام','javascript','مصارعة حرة']
def x8IFqMZeJj7suCR4AaGoNXfEHm(mode,url,text):
	if   mode==110: XXxlOLJ9KRjPH382WVCvr6n71 = Y72YmLgw4vqlHxTCkbeKSicasD()
	elif mode==111: XXxlOLJ9KRjPH382WVCvr6n71 = Je4TwC30iOG5DLKWAtbYvhs(url,text)
	elif mode==112: XXxlOLJ9KRjPH382WVCvr6n71 = Hkij627uCDJKyIM(url)
	elif mode==113: XXxlOLJ9KRjPH382WVCvr6n71 = bIpskeGhBlqH(url,True)
	elif mode==114: XXxlOLJ9KRjPH382WVCvr6n71 = eszTQbMvkmRwCAxGDPdYJUi(url,'FULL_FILTER___'+text)
	elif mode==115: XXxlOLJ9KRjPH382WVCvr6n71 = eszTQbMvkmRwCAxGDPdYJUi(url,'DEFINED_FILTER___'+text)
	elif mode==116: XXxlOLJ9KRjPH382WVCvr6n71 = bIpskeGhBlqH(url,False)
	elif mode==119: XXxlOLJ9KRjPH382WVCvr6n71 = kstJfK6jHQWrXDSMRIGB7(text)
	else: XXxlOLJ9KRjPH382WVCvr6n71 = False
	return XXxlOLJ9KRjPH382WVCvr6n71
def Y72YmLgw4vqlHxTCkbeKSicasD():
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',wQjs1XZ3AO24g8y9bEeoKMiGIu7,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'SHAHID4U-MENU-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	OZSA7QNfeE = Wl2eu1PavfQ(b3HKopTY9zLUyhJmt.url,'url')
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'بحث في الموقع',b8Qe150xVaJsnDSv,119,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'_REMEMBERRESULTS_')
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'فلتر محدد',OZSA7QNfeE,115)
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'فلتر كامل',OZSA7QNfeE,114)
	MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+' ===== ===== ===== '+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999)
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'المميزة',OZSA7QNfeE,111,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'featured')
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('simple-filter(.*?)adv-filter',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if not ZV5rRvabhxJ:
		tuJ9fQgDl8oineCrFPT(b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'موقع شاهد فوريو','البرنامج لم يستطيع إيجاد عنوان الموقع أو تصميم الموقع تغير')
		return
	else:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		items = YYBlm36zd0Jst18LXwo4.findall('location = \'(.*?)\'.*?src="(.*?)".*?<h3>(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for filter,lvtGpMZHb9,title in items:
			url = OZSA7QNfeE+filter
			MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+title,url,111,lvtGpMZHb9,b8Qe150xVaJsnDSv,filter)
		MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+' ===== ===== ===== '+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999)
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('class="dropdown"(.*?)<script>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)".*?>(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
			title = title.replace(eeN6dTEnkJxI,b8Qe150xVaJsnDSv).replace(d6ekSEojpFUANKJ7r9WTlI3niLBOu,b8Qe150xVaJsnDSv).strip(pldxivXC5wbTB2O8q)
			if title in v1vJEhoNQBVPkjG: continue
			if 'http' not in pcA1dzy7LXwGfMPg9mTkuh5tine3: pcA1dzy7LXwGfMPg9mTkuh5tine3 = OZSA7QNfeE+pcA1dzy7LXwGfMPg9mTkuh5tine3
			if 'netflix' in pcA1dzy7LXwGfMPg9mTkuh5tine3: title = 'نيتفلكس'
			MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,111)
	return jLtdbeYiQHnf4SpU2MTly
def Je4TwC30iOG5DLKWAtbYvhs(url,vI9QYJckeTmfRFV=b8Qe150xVaJsnDSv,b3HKopTY9zLUyhJmt=b8Qe150xVaJsnDSv):
	if not b3HKopTY9zLUyhJmt: b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',url,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'SHAHID4U-TITLES-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	ZV5rRvabhxJ,items,d3VSIefbHnvqiut = [],[],[]
	if vI9QYJckeTmfRFV=='featured': ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('glide__slides(.*?)</ul>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	else: ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('shows-container(.*?)pagination',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if not ZV5rRvabhxJ: return
	OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
	if not items: items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)".*?url\((.*?)\).*?"title">(.*?)</h4>',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	PBFVNlrcUMOSzC04 = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for pcA1dzy7LXwGfMPg9mTkuh5tine3,lvtGpMZHb9,title in items:
		if 'WWE' in title: continue
		if 'javascript' in pcA1dzy7LXwGfMPg9mTkuh5tine3: continue
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = SgrGWuAHcLKBQMJetb9(pcA1dzy7LXwGfMPg9mTkuh5tine3).strip('/')
		title = pTP49ckGDYrofa2KxenumbH0(title)
		title = title.strip(pldxivXC5wbTB2O8q)
		HHr42WSgBjAeU7TkQcVaL6yEJz8PF = YYBlm36zd0Jst18LXwo4.findall('(.*?) الحلقة \d+',title,YYBlm36zd0Jst18LXwo4.DOTALL)
		if '/film/' in pcA1dzy7LXwGfMPg9mTkuh5tine3 or 'فيلم' in pcA1dzy7LXwGfMPg9mTkuh5tine3 or any(Y8aiFZsLKw in title for Y8aiFZsLKw in PBFVNlrcUMOSzC04):
			MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,112,lvtGpMZHb9)
		elif HHr42WSgBjAeU7TkQcVaL6yEJz8PF and 'الحلقة' in title and '/list' not in url:
			title = '_MOD_' + HHr42WSgBjAeU7TkQcVaL6yEJz8PF[0]
			if title not in d3VSIefbHnvqiut:
				MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,113,lvtGpMZHb9)
				d3VSIefbHnvqiut.append(title)
		elif '/actor/' in pcA1dzy7LXwGfMPg9mTkuh5tine3:
			MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,111,lvtGpMZHb9)
		elif '/series/' in pcA1dzy7LXwGfMPg9mTkuh5tine3 and '/list' not in url:
			pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3+'/list'
			MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,111,lvtGpMZHb9)
		elif '/list' in url and 'حلقة' in title:
			MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,112,lvtGpMZHb9)
		else: MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,113,lvtGpMZHb9)
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('"pagination"(.*?)</ul>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		if vI9QYJckeTmfRFV!='search': items = YYBlm36zd0Jst18LXwo4.findall('(updateQuery).*?>(.+?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		else: items = YYBlm36zd0Jst18LXwo4.findall('<li>.*?href="(.*?)">(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		if 'page=' in url: url = url.split('page=',1)[0][:-1]
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
			title = title.replace(eeN6dTEnkJxI,b8Qe150xVaJsnDSv).replace(d6ekSEojpFUANKJ7r9WTlI3niLBOu,b8Qe150xVaJsnDSv)
			title = title.strip(pldxivXC5wbTB2O8q)
			if vI9QYJckeTmfRFV!='search':
				if '?' in url: pcA1dzy7LXwGfMPg9mTkuh5tine3 = url+'&page='+title
				else: pcA1dzy7LXwGfMPg9mTkuh5tine3 = url+'?page='+title
			title = pTP49ckGDYrofa2KxenumbH0(title)
			if title: MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'صفحة '+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,111,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,vI9QYJckeTmfRFV)
	return
def bIpskeGhBlqH(url,gIWdxYXy9RL4HQ):
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',url,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'SHAHID4U-EPISODES-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('items d-flex(.*?)</div>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if len(ZV5rRvabhxJ)>1:
		if '/season/' in ZV5rRvabhxJ[0]: FYIl2eqyG1afdLbuOA6s,f0iybKmnzw6vZEd = ZV5rRvabhxJ[0],ZV5rRvabhxJ[1]
		else: FYIl2eqyG1afdLbuOA6s,f0iybKmnzw6vZEd = ZV5rRvabhxJ[1],ZV5rRvabhxJ[0]
	else: FYIl2eqyG1afdLbuOA6s,f0iybKmnzw6vZEd = ZV5rRvabhxJ[0],ZV5rRvabhxJ[0]
	for s9s45taoNBh60XL1zykOmTK3jJCrE in range(2):
		if gIWdxYXy9RL4HQ: mode,type,OTKx7aVb2hdS16Wrweky4FXfIN0g9 = 116,'folder',FYIl2eqyG1afdLbuOA6s
		else: mode,type,OTKx7aVb2hdS16Wrweky4FXfIN0g9 = 112,'video',f0iybKmnzw6vZEd
		items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)".*?span.*?">(.*?)<.*?span.*?">(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		if gIWdxYXy9RL4HQ and len(items)<2:
			gIWdxYXy9RL4HQ = False
			continue
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,t0TJBoN2dZzE4xKSQw1FfV7scC9,HoXz65T8ph1CMeZgF in items:
			title = t0TJBoN2dZzE4xKSQw1FfV7scC9+pldxivXC5wbTB2O8q+HoXz65T8ph1CMeZgF
			MQtuaShrKTbdZFJ5nsR7D(type,WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,mode)
		break
	if not items and '/episodes' in jLtdbeYiQHnf4SpU2MTly:
		CVR80cUXuqyWZakMh75tF3vTpJE1w = YYBlm36zd0Jst18LXwo4.findall('class="breadcrumb"(.*?)</div>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if CVR80cUXuqyWZakMh75tF3vTpJE1w:
			OTKx7aVb2hdS16Wrweky4FXfIN0g9 = CVR80cUXuqyWZakMh75tF3vTpJE1w[0]
			tzdvaEpMHOCZLXDYg08T = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)"',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
			if len(tzdvaEpMHOCZLXDYg08T)>2:
				pcA1dzy7LXwGfMPg9mTkuh5tine3 = tzdvaEpMHOCZLXDYg08T[2]+'list'
				Je4TwC30iOG5DLKWAtbYvhs(pcA1dzy7LXwGfMPg9mTkuh5tine3)
	return
def Hkij627uCDJKyIM(url):
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(Q49IsrlSuYRAVbGKhwdckLDOetF2PZ,'GET',url,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'SHAHID4U-PLAY-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('class="actions(.*?)</div>',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if not ZV5rRvabhxJ: return
	OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
	tzdvaEpMHOCZLXDYg08T = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)"',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	T1UohMYw9qg804Sevy2dliVjXrD7cp = '/watch/' in OTKx7aVb2hdS16Wrweky4FXfIN0g9
	download = '/download/' in OTKx7aVb2hdS16Wrweky4FXfIN0g9
	if   T1UohMYw9qg804Sevy2dliVjXrD7cp and not download: fBqzerRTM5YO,NNIAuc0LzpXvOYglt7o = tzdvaEpMHOCZLXDYg08T[0],b8Qe150xVaJsnDSv
	elif not T1UohMYw9qg804Sevy2dliVjXrD7cp and download: fBqzerRTM5YO,NNIAuc0LzpXvOYglt7o = b8Qe150xVaJsnDSv,tzdvaEpMHOCZLXDYg08T[0]
	elif T1UohMYw9qg804Sevy2dliVjXrD7cp and download: fBqzerRTM5YO,NNIAuc0LzpXvOYglt7o = tzdvaEpMHOCZLXDYg08T[0],tzdvaEpMHOCZLXDYg08T[1]
	else: fBqzerRTM5YO,NNIAuc0LzpXvOYglt7o = b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv
	KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j = []
	if T1UohMYw9qg804Sevy2dliVjXrD7cp:
		b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(Q49IsrlSuYRAVbGKhwdckLDOetF2PZ,'GET',fBqzerRTM5YO,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'SHAHID4U-PLAY-2nd')
		vWsMIpk1n6rlLqH52 = b3HKopTY9zLUyhJmt.content
		U8UnzJgXuMIE5GV = YYBlm36zd0Jst18LXwo4.findall('let servers(.*?)player',vWsMIpk1n6rlLqH52,YYBlm36zd0Jst18LXwo4.DOTALL|YYBlm36zd0Jst18LXwo4.IGNORECASE)
		if U8UnzJgXuMIE5GV:
			CmEkolxes7Q6hB01fGTPZi4 = U8UnzJgXuMIE5GV[0]
			xxnATEUzH6Djmq0NrBveh = YYBlm36zd0Jst18LXwo4.findall('"name":"(.*?)".*?"url":"(.*?)"',CmEkolxes7Q6hB01fGTPZi4,YYBlm36zd0Jst18LXwo4.DOTALL)
			for title,pcA1dzy7LXwGfMPg9mTkuh5tine3 in xxnATEUzH6Djmq0NrBveh:
				pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3.replace('\\/','/')
				pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3+'?named='+title+'__watch'
				KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
	if download:
		b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(Q49IsrlSuYRAVbGKhwdckLDOetF2PZ,'GET',NNIAuc0LzpXvOYglt7o,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'SHAHID4U-PLAY-3rd')
		vWsMIpk1n6rlLqH52 = b3HKopTY9zLUyhJmt.content
		U8UnzJgXuMIE5GV = YYBlm36zd0Jst18LXwo4.findall('"servers"(.*?)info-container',vWsMIpk1n6rlLqH52,YYBlm36zd0Jst18LXwo4.DOTALL)
		if U8UnzJgXuMIE5GV:
			CmEkolxes7Q6hB01fGTPZi4 = U8UnzJgXuMIE5GV[0]
			xxnATEUzH6Djmq0NrBveh = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)".*?<span>(.*?)<.*?</i>.*?<span>(.*?)<',CmEkolxes7Q6hB01fGTPZi4,YYBlm36zd0Jst18LXwo4.DOTALL)
			for pcA1dzy7LXwGfMPg9mTkuh5tine3,title,c1EdszLx3mkb8QYX9 in xxnATEUzH6Djmq0NrBveh:
				pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3+'?named='+title+'__download'+'____'+c1EdszLx3mkb8QYX9
				KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
	import QNeGEq8sWn
	QNeGEq8sWn.nqu2GCT9gHAbpIPSFZz5(KYtmvpJfOqA02rPoGDNH1WTkzeUZ6j,QQ8pvXNcBfVkP5rRJ7o,'video',url)
	return
def kstJfK6jHQWrXDSMRIGB7(search):
	search,v7Rxw52Z4X0,showDialogs = JimhUH0SEf6w(search)
	if not search:
		search = FT2oXWtPQpVGuexmLqKN3srdzYn()
		if not search: return
	search = search.replace(pldxivXC5wbTB2O8q,'+')
	url = wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/search?s='+search
	Je4TwC30iOG5DLKWAtbYvhs(url,'search')
	return
def wwtH4LbAYj2OvQ7DTpdJx(url):
	url = url.split('/smartemadfilter?')[0]
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(Q49IsrlSuYRAVbGKhwdckLDOetF2PZ,'GET',url,b8Qe150xVaJsnDSv,headers,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'SHAHID4U-GET_FILTERS_BLOCKS-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	RYqsiFGfj07T2VKXrx3y6Hb = []
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('adv-filter(.*?)shows-container',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		RYqsiFGfj07T2VKXrx3y6Hb = YYBlm36zd0Jst18LXwo4.findall('''updateQuery\('(.*?)'.*?value.*?>(.*?)<(.*?)</select''',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		PSFKgbcHMzfmOW6IQZ7dB2T4oi05R,SRu8HDoOiwJBFUmVNQbdr2XIKjkf,JQjNkD10xehK8bXUalY3EgZAVmvI = zip(*RYqsiFGfj07T2VKXrx3y6Hb)
		RYqsiFGfj07T2VKXrx3y6Hb = zip(SRu8HDoOiwJBFUmVNQbdr2XIKjkf,PSFKgbcHMzfmOW6IQZ7dB2T4oi05R,JQjNkD10xehK8bXUalY3EgZAVmvI)
	return RYqsiFGfj07T2VKXrx3y6Hb
def DwEj517Ty94KWU8Y2nSZI3C6vgG(OTKx7aVb2hdS16Wrweky4FXfIN0g9):
	items = YYBlm36zd0Jst18LXwo4.findall('value="(.*?)".*?>\s*(.*?)\s*<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	return items
def zzW5a9VDymF6(url):
	if '/smartemadfilter?' not in url: url = url+'/smartemadfilter?'
	e3To7sm0Nzn1CruYWxGh = url.split('/smartemadfilter?')[0]
	cCxjKQGYDfZWpd5 = Wl2eu1PavfQ(url,'url')
	url = url.replace(e3To7sm0Nzn1CruYWxGh,cCxjKQGYDfZWpd5)
	url = url.replace('/smartemadfilter?','/?')
	return url
PAZjh4efyMLKW5 = ['quality','year','genre','category']
qbOpQg0dxDKEMr4WU8c5S391JA7LuF = ['category','genre','year']
def eszTQbMvkmRwCAxGDPdYJUi(url,filter):
	url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==b8Qe150xVaJsnDSv: us8FE67ImlDBS,bxTQdyVe57Bh0P8sG = b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv
	else: us8FE67ImlDBS,bxTQdyVe57Bh0P8sG = filter.split('___')
	if type=='DEFINED_FILTER':
		if qbOpQg0dxDKEMr4WU8c5S391JA7LuF[0]+'=' not in us8FE67ImlDBS: Z8s0Lov2UiWF1qGjO = qbOpQg0dxDKEMr4WU8c5S391JA7LuF[0]
		for FbcUxvE17ewlWNBHgS8Jn in range(len(qbOpQg0dxDKEMr4WU8c5S391JA7LuF[0:-1])):
			if qbOpQg0dxDKEMr4WU8c5S391JA7LuF[FbcUxvE17ewlWNBHgS8Jn]+'=' in us8FE67ImlDBS: Z8s0Lov2UiWF1qGjO = qbOpQg0dxDKEMr4WU8c5S391JA7LuF[FbcUxvE17ewlWNBHgS8Jn+1]
		x5gCnOb9wjSPit6sVclHNZIkFyD0 = us8FE67ImlDBS+'&'+Z8s0Lov2UiWF1qGjO+'=0'
		XFJqUiePG7aSf0N = bxTQdyVe57Bh0P8sG+'&'+Z8s0Lov2UiWF1qGjO+'=0'
		Dnkl4UdcKRILWi6m7TqYJh98vu = x5gCnOb9wjSPit6sVclHNZIkFyD0.strip('&')+'___'+XFJqUiePG7aSf0N.strip('&')
		JXAZh9EQjse2qirMa8DRSYvGLO0kgf = W57WXlwPhyrfVu6oij(bxTQdyVe57Bh0P8sG,'modified_filters')
		MUJCtfYVBLODrFbaZn = url+'/smartemadfilter?'+JXAZh9EQjse2qirMa8DRSYvGLO0kgf
	elif type=='FULL_FILTER':
		pRfP0YvVnLJdukUHstQA8cm = W57WXlwPhyrfVu6oij(us8FE67ImlDBS,'modified_values')
		pRfP0YvVnLJdukUHstQA8cm = SgrGWuAHcLKBQMJetb9(pRfP0YvVnLJdukUHstQA8cm)
		if bxTQdyVe57Bh0P8sG!=b8Qe150xVaJsnDSv: bxTQdyVe57Bh0P8sG = W57WXlwPhyrfVu6oij(bxTQdyVe57Bh0P8sG,'modified_filters')
		if bxTQdyVe57Bh0P8sG==b8Qe150xVaJsnDSv: MUJCtfYVBLODrFbaZn = url
		else: MUJCtfYVBLODrFbaZn = url+'/smartemadfilter?'+bxTQdyVe57Bh0P8sG
		GSh0nJxEXgZjd48u7mBwWOeafyAp5b = zzW5a9VDymF6(MUJCtfYVBLODrFbaZn)
		MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'أظهار قائمة الفيديو التي تم اختيارها ',GSh0nJxEXgZjd48u7mBwWOeafyAp5b,111)
		MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+' [[   '+pRfP0YvVnLJdukUHstQA8cm+'   ]]',GSh0nJxEXgZjd48u7mBwWOeafyAp5b,111)
		MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+' ===== ===== ===== '+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999)
	RYqsiFGfj07T2VKXrx3y6Hb = wwtH4LbAYj2OvQ7DTpdJx(url)
	dict = {}
	for name,BnHr3VSlN5cMhZ7miAfGLovdbQJWa,OTKx7aVb2hdS16Wrweky4FXfIN0g9 in RYqsiFGfj07T2VKXrx3y6Hb:
		name = name.replace('كل ',b8Qe150xVaJsnDSv)
		items = DwEj517Ty94KWU8Y2nSZI3C6vgG(OTKx7aVb2hdS16Wrweky4FXfIN0g9)
		if '=' not in MUJCtfYVBLODrFbaZn: MUJCtfYVBLODrFbaZn = url
		if type=='DEFINED_FILTER':
			if Z8s0Lov2UiWF1qGjO!=BnHr3VSlN5cMhZ7miAfGLovdbQJWa: continue
			elif len(items)<2:
				if BnHr3VSlN5cMhZ7miAfGLovdbQJWa==qbOpQg0dxDKEMr4WU8c5S391JA7LuF[-1]:
					GSh0nJxEXgZjd48u7mBwWOeafyAp5b = zzW5a9VDymF6(MUJCtfYVBLODrFbaZn)
					Je4TwC30iOG5DLKWAtbYvhs(GSh0nJxEXgZjd48u7mBwWOeafyAp5b)
				else: eszTQbMvkmRwCAxGDPdYJUi(MUJCtfYVBLODrFbaZn,'DEFINED_FILTER___'+Dnkl4UdcKRILWi6m7TqYJh98vu)
				return
			else:
				if BnHr3VSlN5cMhZ7miAfGLovdbQJWa==qbOpQg0dxDKEMr4WU8c5S391JA7LuF[-1]:
					GSh0nJxEXgZjd48u7mBwWOeafyAp5b = zzW5a9VDymF6(MUJCtfYVBLODrFbaZn)
					MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'الجميع',GSh0nJxEXgZjd48u7mBwWOeafyAp5b,111)
				else: MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'الجميع',MUJCtfYVBLODrFbaZn,115,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,Dnkl4UdcKRILWi6m7TqYJh98vu)
		elif type=='FULL_FILTER':
			x5gCnOb9wjSPit6sVclHNZIkFyD0 = us8FE67ImlDBS+'&'+BnHr3VSlN5cMhZ7miAfGLovdbQJWa+'=0'
			XFJqUiePG7aSf0N = bxTQdyVe57Bh0P8sG+'&'+BnHr3VSlN5cMhZ7miAfGLovdbQJWa+'=0'
			Dnkl4UdcKRILWi6m7TqYJh98vu = x5gCnOb9wjSPit6sVclHNZIkFyD0+'___'+XFJqUiePG7aSf0N
			MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'الجميع :'+name,MUJCtfYVBLODrFbaZn,114,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,Dnkl4UdcKRILWi6m7TqYJh98vu)
		dict[BnHr3VSlN5cMhZ7miAfGLovdbQJWa] = {}
		for Y8aiFZsLKw,Ny03TjaY7bBxWwm2GI in items:
			if Y8aiFZsLKw=='196533': Ny03TjaY7bBxWwm2GI = 'أفلام نيتفلكس'
			elif Y8aiFZsLKw=='196531': Ny03TjaY7bBxWwm2GI = 'مسلسلات نيتفلكس'
			if Ny03TjaY7bBxWwm2GI in v1vJEhoNQBVPkjG: continue
			dict[BnHr3VSlN5cMhZ7miAfGLovdbQJWa][Y8aiFZsLKw] = Ny03TjaY7bBxWwm2GI
			x5gCnOb9wjSPit6sVclHNZIkFyD0 = us8FE67ImlDBS+'&'+BnHr3VSlN5cMhZ7miAfGLovdbQJWa+'='+Ny03TjaY7bBxWwm2GI
			XFJqUiePG7aSf0N = bxTQdyVe57Bh0P8sG+'&'+BnHr3VSlN5cMhZ7miAfGLovdbQJWa+'='+Y8aiFZsLKw
			NHEdmMD3qPj4zay2nb5O8xKX = x5gCnOb9wjSPit6sVclHNZIkFyD0+'___'+XFJqUiePG7aSf0N
			title = Ny03TjaY7bBxWwm2GI+' :'#+dict[BnHr3VSlN5cMhZ7miAfGLovdbQJWa]['0']
			title = Ny03TjaY7bBxWwm2GI+' :'+name
			if type=='FULL_FILTER': MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,url,114,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,NHEdmMD3qPj4zay2nb5O8xKX)
			elif type=='DEFINED_FILTER' and qbOpQg0dxDKEMr4WU8c5S391JA7LuF[-2]+'=' in us8FE67ImlDBS:
				JXAZh9EQjse2qirMa8DRSYvGLO0kgf = W57WXlwPhyrfVu6oij(XFJqUiePG7aSf0N,'modified_filters')
				MUJCtfYVBLODrFbaZn = url+'/smartemadfilter?'+JXAZh9EQjse2qirMa8DRSYvGLO0kgf
				GSh0nJxEXgZjd48u7mBwWOeafyAp5b = zzW5a9VDymF6(MUJCtfYVBLODrFbaZn)
				MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,GSh0nJxEXgZjd48u7mBwWOeafyAp5b,111)
			else: MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,url,115,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,NHEdmMD3qPj4zay2nb5O8xKX)
	return
def W57WXlwPhyrfVu6oij(J6rINOCGlW5M4SXjgwc9U7,mode):
	J6rINOCGlW5M4SXjgwc9U7 = J6rINOCGlW5M4SXjgwc9U7.replace('=&','=0&')
	J6rINOCGlW5M4SXjgwc9U7 = J6rINOCGlW5M4SXjgwc9U7.strip('&')
	hj1lf3cGzLMURVTKkBZmDoyix28 = {}
	if '=' in J6rINOCGlW5M4SXjgwc9U7:
		items = J6rINOCGlW5M4SXjgwc9U7.split('&')
		for tgoJCpq8KGrdaUSjsLh0FTxDRPfIAB in items:
			VRcGtBaO1xun,Y8aiFZsLKw = tgoJCpq8KGrdaUSjsLh0FTxDRPfIAB.split('=')
			hj1lf3cGzLMURVTKkBZmDoyix28[VRcGtBaO1xun] = Y8aiFZsLKw
	sBF1epSJZbIUAgM4hVLPD50 = b8Qe150xVaJsnDSv
	for key in PAZjh4efyMLKW5:
		if key in list(hj1lf3cGzLMURVTKkBZmDoyix28.keys()): Y8aiFZsLKw = hj1lf3cGzLMURVTKkBZmDoyix28[key]
		else: Y8aiFZsLKw = '0'
		if '%' not in Y8aiFZsLKw: Y8aiFZsLKw = HHbaVYqFRy6v0c(Y8aiFZsLKw)
		if mode=='modified_values' and Y8aiFZsLKw!='0': sBF1epSJZbIUAgM4hVLPD50 = sBF1epSJZbIUAgM4hVLPD50+' + '+Y8aiFZsLKw
		elif mode=='modified_filters' and Y8aiFZsLKw!='0': sBF1epSJZbIUAgM4hVLPD50 = sBF1epSJZbIUAgM4hVLPD50+'&'+key+'='+Y8aiFZsLKw
		elif mode=='all': sBF1epSJZbIUAgM4hVLPD50 = sBF1epSJZbIUAgM4hVLPD50+'&'+key+'='+Y8aiFZsLKw
	sBF1epSJZbIUAgM4hVLPD50 = sBF1epSJZbIUAgM4hVLPD50.strip(' + ')
	sBF1epSJZbIUAgM4hVLPD50 = sBF1epSJZbIUAgM4hVLPD50.strip('&')
	sBF1epSJZbIUAgM4hVLPD50 = sBF1epSJZbIUAgM4hVLPD50.replace('=0','=')
	return sBF1epSJZbIUAgM4hVLPD50
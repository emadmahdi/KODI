# -*- coding: utf-8 -*-
from hIVCFnfxSO import *
QQ8pvXNcBfVkP5rRJ7o = 'KATKOTTV'
WbzmKSZiuOYrBN7oysJ2dUv = '_KTV_'
wQjs1XZ3AO24g8y9bEeoKMiGIu7 = nTHXJIiah2qK[QQ8pvXNcBfVkP5rRJ7o][0]
v1vJEhoNQBVPkjG = []
def x8IFqMZeJj7suCR4AaGoNXfEHm(mode,url,text):
	if   mode==810: XXxlOLJ9KRjPH382WVCvr6n71 = Y72YmLgw4vqlHxTCkbeKSicasD()
	elif mode==811: XXxlOLJ9KRjPH382WVCvr6n71 = Je4TwC30iOG5DLKWAtbYvhs(url,text)
	elif mode==812: XXxlOLJ9KRjPH382WVCvr6n71 = Hkij627uCDJKyIM(url)
	elif mode==813: XXxlOLJ9KRjPH382WVCvr6n71 = jQ9zsEX2Hc(url)
	elif mode==819: XXxlOLJ9KRjPH382WVCvr6n71 = kstJfK6jHQWrXDSMRIGB7(text)
	else: XXxlOLJ9KRjPH382WVCvr6n71 = False
	return XXxlOLJ9KRjPH382WVCvr6n71
def Y72YmLgw4vqlHxTCkbeKSicasD():
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',wQjs1XZ3AO24g8y9bEeoKMiGIu7,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'KATKOTTV-MENU-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'بحث في الموقع',b8Qe150xVaJsnDSv,819,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'_REMEMBERRESULTS_')
	MQtuaShrKTbdZFJ5nsR7D('link',rC3Tlno96KjLDIvBaSWUbR8+' ===== ===== ===== '+hAIp8kmC36T5WFPMSXOwnNbtD,b8Qe150xVaJsnDSv,9999)
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('"primary-links"(.*?)"most-viewed"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
	items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)".*?<span>(.*?)<',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
	for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
		if title in v1vJEhoNQBVPkjG: continue
		MQtuaShrKTbdZFJ5nsR7D('folder',QQ8pvXNcBfVkP5rRJ7o+'_SCRIPT_'+WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,811)
	return
def Je4TwC30iOG5DLKWAtbYvhs(url,type=b8Qe150xVaJsnDSv):
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'KATKOTTV-TITLES-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall('"home-content"(.*?)"footer"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ:
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		items = YYBlm36zd0Jst18LXwo4.findall('"thumb".*?data-src="(.*?)".*?href="(.*?)".*?title="(.*?)"',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		d3VSIefbHnvqiut = []
		for lvtGpMZHb9,pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
			title = pTP49ckGDYrofa2KxenumbH0(title)
			HHr42WSgBjAeU7TkQcVaL6yEJz8PF = YYBlm36zd0Jst18LXwo4.findall('(.*?) (الحلقة|حلقة).\d+',title,YYBlm36zd0Jst18LXwo4.DOTALL)
			if 'episodes' not in type and HHr42WSgBjAeU7TkQcVaL6yEJz8PF:
				title = '_MOD_' + HHr42WSgBjAeU7TkQcVaL6yEJz8PF[0][0]
				title = title.replace('اون لاين',b8Qe150xVaJsnDSv)
				if title not in d3VSIefbHnvqiut:
					MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,813,lvtGpMZHb9)
					d3VSIefbHnvqiut.append(title)
			else: MQtuaShrKTbdZFJ5nsR7D('video',WbzmKSZiuOYrBN7oysJ2dUv+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,812,lvtGpMZHb9)
	ZV5rRvabhxJ = YYBlm36zd0Jst18LXwo4.findall("'pagination'(.*?)footer",jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if ZV5rRvabhxJ:
		type = 'episodes_pages' if 'episodes' in type else 'pages'
		OTKx7aVb2hdS16Wrweky4FXfIN0g9 = ZV5rRvabhxJ[0]
		items = YYBlm36zd0Jst18LXwo4.findall('href="(.*?)">(.*?)</a>',OTKx7aVb2hdS16Wrweky4FXfIN0g9,YYBlm36zd0Jst18LXwo4.DOTALL)
		for pcA1dzy7LXwGfMPg9mTkuh5tine3,title in items:
			title = pTP49ckGDYrofa2KxenumbH0(title)
			MQtuaShrKTbdZFJ5nsR7D('folder',WbzmKSZiuOYrBN7oysJ2dUv+'صفحة '+title,pcA1dzy7LXwGfMPg9mTkuh5tine3,811,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,type)
	return
def jQ9zsEX2Hc(url):
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'KATKOTTV-SERIES-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	pcA1dzy7LXwGfMPg9mTkuh5tine3 = YYBlm36zd0Jst18LXwo4.findall('"category".*?href="(.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if pcA1dzy7LXwGfMPg9mTkuh5tine3: Je4TwC30iOG5DLKWAtbYvhs(pcA1dzy7LXwGfMPg9mTkuh5tine3[0],'episodes')
	return
def Hkij627uCDJKyIM(url):
	n92bB0YwDLqyadQRlmGW = []
	MUJCtfYVBLODrFbaZn = url+'?do=watch'
	b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',MUJCtfYVBLODrFbaZn,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'KATKOTTV-PLAY-1st')
	jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
	pcA1dzy7LXwGfMPg9mTkuh5tine3 = YYBlm36zd0Jst18LXwo4.findall('" src="(.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
	if pcA1dzy7LXwGfMPg9mTkuh5tine3:
		pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3[0]
		n92bB0YwDLqyadQRlmGW.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
	else:
		b3HKopTY9zLUyhJmt = dcLRAZWFzODax2jf0tHCX81pJveNY(GMkNL1RXxKFentp0Zh9d,'GET',url,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,b8Qe150xVaJsnDSv,'KATKOTTV-PLAY-2nd')
		jLtdbeYiQHnf4SpU2MTly = b3HKopTY9zLUyhJmt.content
		EEZLmsCMxVl07kRfzAih = YYBlm36zd0Jst18LXwo4.findall('post=(.*?)"',jLtdbeYiQHnf4SpU2MTly,YYBlm36zd0Jst18LXwo4.DOTALL)
		if EEZLmsCMxVl07kRfzAih:
			EEZLmsCMxVl07kRfzAih = lnFeUkiZtQ7E1.b64decode(EEZLmsCMxVl07kRfzAih[0])
			if i1thmHk7AZquD4cM0fnp62: EEZLmsCMxVl07kRfzAih = EEZLmsCMxVl07kRfzAih.decode(OVauxZzLI10vcXT74K)
			EEZLmsCMxVl07kRfzAih = oJsUwXA0yGOI1mTjxQ('dict',EEZLmsCMxVl07kRfzAih)
			tzdvaEpMHOCZLXDYg08T = EEZLmsCMxVl07kRfzAih['servers']
			YRtyADTLUrGc = list(tzdvaEpMHOCZLXDYg08T.keys())
			tzdvaEpMHOCZLXDYg08T = list(tzdvaEpMHOCZLXDYg08T.values())
			TJuDfURKbI6MynChiEXqAYQS4d58j = zip(YRtyADTLUrGc,tzdvaEpMHOCZLXDYg08T)
			for title,pcA1dzy7LXwGfMPg9mTkuh5tine3 in TJuDfURKbI6MynChiEXqAYQS4d58j:
				pcA1dzy7LXwGfMPg9mTkuh5tine3 = pcA1dzy7LXwGfMPg9mTkuh5tine3+'?named='+title+'__watch'
				n92bB0YwDLqyadQRlmGW.append(pcA1dzy7LXwGfMPg9mTkuh5tine3)
	import QNeGEq8sWn
	QNeGEq8sWn.nqu2GCT9gHAbpIPSFZz5(n92bB0YwDLqyadQRlmGW,QQ8pvXNcBfVkP5rRJ7o,'video',url)
	return
def kstJfK6jHQWrXDSMRIGB7(search):
	search,v7Rxw52Z4X0,showDialogs = JimhUH0SEf6w(search)
	if search==b8Qe150xVaJsnDSv: search = FT2oXWtPQpVGuexmLqKN3srdzYn()
	if search==b8Qe150xVaJsnDSv: return
	search = search.replace(pldxivXC5wbTB2O8q,'+')
	url = wQjs1XZ3AO24g8y9bEeoKMiGIu7+'/?s='+search
	Je4TwC30iOG5DLKWAtbYvhs(url,'search')
	return
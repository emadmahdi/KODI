# -*- coding: utf-8 -*-
import sys as Igx6pfyZGaDBEF1hoNVPw
don0aQxfJkHqX9YCyLDzs = Igx6pfyZGaDBEF1hoNVPw.version_info [0] == 2
sP4qfHTKjul2zLVREOrIgv5c = 2048
JaQAshokeZOUymbTzLH94x2V8EC1w = 7
def npIlTeU8D0OJfWr5 (uFSphLqQgRA4scfiI6):
	global RQyVv8CFrk9TBtf3M
	qhDGr7mVy8j6Wwn = ord (uFSphLqQgRA4scfiI6 [-1])
	JmDn8ZGOLb = uFSphLqQgRA4scfiI6 [:-1]
	oonJiy0LCNI4u6DSMvrRUQZTKb = qhDGr7mVy8j6Wwn % len (JmDn8ZGOLb)
	tt1pSla3H2IrsWihECPjRuDKXFB = JmDn8ZGOLb [:oonJiy0LCNI4u6DSMvrRUQZTKb] + JmDn8ZGOLb [oonJiy0LCNI4u6DSMvrRUQZTKb:]
	if don0aQxfJkHqX9YCyLDzs:
		Pa3DECd216ghWpnxwXyijfJtmV = unicode () .join ([unichr (ord (M4pNmAs01RDaVzrwxk) - sP4qfHTKjul2zLVREOrIgv5c - (Zi1N5d2qe7mnLJl + qhDGr7mVy8j6Wwn) % JaQAshokeZOUymbTzLH94x2V8EC1w) for Zi1N5d2qe7mnLJl, M4pNmAs01RDaVzrwxk in enumerate (tt1pSla3H2IrsWihECPjRuDKXFB)])
	else:
		Pa3DECd216ghWpnxwXyijfJtmV = str () .join ([chr (ord (M4pNmAs01RDaVzrwxk) - sP4qfHTKjul2zLVREOrIgv5c - (Zi1N5d2qe7mnLJl + qhDGr7mVy8j6Wwn) % JaQAshokeZOUymbTzLH94x2V8EC1w) for Zi1N5d2qe7mnLJl, M4pNmAs01RDaVzrwxk in enumerate (tt1pSla3H2IrsWihECPjRuDKXFB)])
	return eval (Pa3DECd216ghWpnxwXyijfJtmV)
xb30nIwXEuh2peOWZV8BQyi7qG,pWLFeVZ7gTPykt3xKiMfvNX06z2u5,OiEvY7pGS2zJW8ltAXwZVkRafoMTD=npIlTeU8D0OJfWr5,npIlTeU8D0OJfWr5,npIlTeU8D0OJfWr5
eaRtLKlTMEmIGVWbuX,WrzxMRT1DS5hgiHy8QfP,NInUYTpmk7xFPWb=OiEvY7pGS2zJW8ltAXwZVkRafoMTD,pWLFeVZ7gTPykt3xKiMfvNX06z2u5,xb30nIwXEuh2peOWZV8BQyi7qG
k23LtrJoWDx6C0BON,UX0WPRZ6BvEaseMN4tJOkCcGVK,NB4UPp0qhSuRIYVyb6=NInUYTpmk7xFPWb,WrzxMRT1DS5hgiHy8QfP,eaRtLKlTMEmIGVWbuX
n4W8qFMdEyl1,Qrm3Tov6k7YVeW,UT25V9B63GKfFHrlRp=NB4UPp0qhSuRIYVyb6,UX0WPRZ6BvEaseMN4tJOkCcGVK,k23LtrJoWDx6C0BON
Paond9gWS2b4kz,ZNoQUamu2FlikIXwELpPb8zG36JC,hhcIpCX07SJxAduDfQn2tPsl4jVab=UT25V9B63GKfFHrlRp,Qrm3Tov6k7YVeW,n4W8qFMdEyl1
iPrTIdcQgVObkW0x5pm7HEsD64KL,BdIP6HG3zMR7XCEa98Lgpn,eyR7Wr1g3KGxc=hhcIpCX07SJxAduDfQn2tPsl4jVab,ZNoQUamu2FlikIXwELpPb8zG36JC,Paond9gWS2b4kz
z1lNZ9OExoJ,DxNdRrHcF9Wy5nlKJS7,roAFNWJCeLQUZcVP04z9aR=eyR7Wr1g3KGxc,BdIP6HG3zMR7XCEa98Lgpn,iPrTIdcQgVObkW0x5pm7HEsD64KL
gozhN7V4yXrTjZcLMeGnd3BKJaO,fY4DIXRZluJwBaMr872OkCLT1FVjE,QRhraluyTW5pd6=roAFNWJCeLQUZcVP04z9aR,DxNdRrHcF9Wy5nlKJS7,z1lNZ9OExoJ
jbZzrvqlIVyM2FaO4Km0B9G75Lk81S,m1mxHYPpi9o,k1dcEyVlqKovBMLDiw6p2CutjOgR=QRhraluyTW5pd6,fY4DIXRZluJwBaMr872OkCLT1FVjE,gozhN7V4yXrTjZcLMeGnd3BKJaO
eMFoClgyILOQKavisfk4,SN1WBMxij70ln4yVpD5d6AFEH,jkJW5D0zbRX9YB4Q8GxPU=k1dcEyVlqKovBMLDiw6p2CutjOgR,m1mxHYPpi9o,jbZzrvqlIVyM2FaO4Km0B9G75Lk81S
mxJnWkZ4FzGBu6qbhOt7Il,cQokr8asyfdDKIuHWGw1AJE,kx4pSqTKmn2lQWzIga8BFH=jkJW5D0zbRX9YB4Q8GxPU,SN1WBMxij70ln4yVpD5d6AFEH,eMFoClgyILOQKavisfk4
import xbmc as VDSh4fU8PleCJxFmW1A,xbmcgui as khvBtyMawX9ZoFI,sys as Igx6pfyZGaDBEF1hoNVPw,os as qrEMpnHWOYcfsv1i0tTFg2,requests as NMK7r9ngp4EWSBb5AXljGeHC1F,re as guTkn9rz3LYS2Pq,xbmcvfs as VC9Ka7pQ3bEvoL8XTmS,base64 as G12GUQsIRXhBEgL5mSpAi9w,time as JvCkyLb1K85uoTUIDfnX6WwhqAzGe
ddYkuvQz9Nqiy = SN1WBMxij70ln4yVpD5d6AFEH(u"ࠫࠬࠀ")
def enOiIWQtmsDb3JxvfCZyBwjrhTXlK2(request):
	TjDa4huBFrRN1it = k23LtrJoWDx6C0BON(u"ࠬࡨࡵࡴࡻࡧ࡭ࡦࡲ࡯ࡨࡰࡲࡧࡦࡴࡣࡦ࡮ࠪࠁ")
	if request==hhcIpCX07SJxAduDfQn2tPsl4jVab(u"࠭ࡳࡵࡣࡵࡸࠬࠂ"): VDSh4fU8PleCJxFmW1A.executebuiltin(hhcIpCX07SJxAduDfQn2tPsl4jVab(u"ࠧࡂࡥࡷ࡭ࡻࡧࡴࡦ࡙࡬ࡲࡩࡵࡷࠩࠩࠃ")+TjDa4huBFrRN1it+NB4UPp0qhSuRIYVyb6(u"ࠨࠫࠪࠄ"))
	elif request==eyR7Wr1g3KGxc(u"ࠩࡶࡸࡴࡶࠧࠅ"): VDSh4fU8PleCJxFmW1A.executebuiltin(NInUYTpmk7xFPWb(u"ࠪࡈ࡮ࡧ࡬ࡰࡩ࠱ࡇࡱࡵࡳࡦࠪࠪࠆ")+TjDa4huBFrRN1it+QRhraluyTW5pd6(u"ࠫ࠮࠭ࠇ"))
	return
def K2qufsHp6US(LAv5SN6EUkODlJXgiPMmaq7y,F1irWPpS3VON2sfGRZHM5C9qbTlIc,pgoU4bRFtnN1YLkSGiVQ,uFXq6RQrybJoUd7LKeVp,text):
	if not F1irWPpS3VON2sfGRZHM5C9qbTlIc: F1irWPpS3VON2sfGRZHM5C9qbTlIc = roAFNWJCeLQUZcVP04z9aR(u"้ࠬไศࠩࠈ")
	if not pgoU4bRFtnN1YLkSGiVQ: pgoU4bRFtnN1YLkSGiVQ = k23LtrJoWDx6C0BON(u"࠭ๆฺ็ࠪࠉ")
	if not uFXq6RQrybJoUd7LKeVp: uFXq6RQrybJoUd7LKeVp = WrzxMRT1DS5hgiHy8QfP(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪࠊ")
	if KepAUNa3jPdc: ccsup9XAOn5ZFh = khvBtyMawX9ZoFI.Dialog().yesno(uFXq6RQrybJoUd7LKeVp,text,ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,F1irWPpS3VON2sfGRZHM5C9qbTlIc,pgoU4bRFtnN1YLkSGiVQ)
	else: ccsup9XAOn5ZFh = khvBtyMawX9ZoFI.Dialog().yesno(uFXq6RQrybJoUd7LKeVp,text,F1irWPpS3VON2sfGRZHM5C9qbTlIc,pgoU4bRFtnN1YLkSGiVQ)
	return ccsup9XAOn5ZFh
def U3Ue5N2pjLlVnWM6ox(LAv5SN6EUkODlJXgiPMmaq7y,MkGCLEn2RSFQ,uFXq6RQrybJoUd7LKeVp,text):
	if not uFXq6RQrybJoUd7LKeVp: uFXq6RQrybJoUd7LKeVp = BdIP6HG3zMR7XCEa98Lgpn(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫࠋ")
	return khvBtyMawX9ZoFI.Dialog().ok(uFXq6RQrybJoUd7LKeVp,text)
def SWDNvYiEp08Qmqw1gZ6u(uFXq6RQrybJoUd7LKeVp=pWLFeVZ7gTPykt3xKiMfvNX06z2u5(u"ࠩ็์าฯࠠศๆ่ๅฬะ๊ฮࠩࠌ"),T8ktSNsDUgv7mKP3y2w1rzhRQ5OFGo=ddYkuvQz9Nqiy):
	D6hY2TteivlfcbWd1pV = khvBtyMawX9ZoFI.Dialog().input(uFXq6RQrybJoUd7LKeVp,T8ktSNsDUgv7mKP3y2w1rzhRQ5OFGo,type=khvBtyMawX9ZoFI.INPUT_ALPHANUM)
	D6hY2TteivlfcbWd1pV = D6hY2TteivlfcbWd1pV.strip(xb30nIwXEuh2peOWZV8BQyi7qG(u"ࠪࠤࠬࠍ")).replace(mxJnWkZ4FzGBu6qbhOt7Il(u"ࠫࠥࠦࠠࠡࠩࠎ"),Qrm3Tov6k7YVeW(u"ࠬࠦࠧࠏ")).replace(UT25V9B63GKfFHrlRp(u"࠭ࠠࠡࠢࠪࠐ"),UT25V9B63GKfFHrlRp(u"ࠧࠡࠩࠑ")).replace(cQokr8asyfdDKIuHWGw1AJE(u"ࠨࠢࠣࠫࠒ"),BdIP6HG3zMR7XCEa98Lgpn(u"ࠩࠣࠫࠓ"))
	return D6hY2TteivlfcbWd1pV
def TF5EGLWicS(QjtaPo8TYRNfsx):
	ccsup9XAOn5ZFh = K2qufsHp6US(ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,jkJW5D0zbRX9YB4Q8GxPU(u"ࠪๆอ๊ࠠฦำึห้ࠦำอๆࠣห้ษฮุษฤࠤ๏าศࠡล้ࠤฯฺฺๅࠢหี๋อๅอࠢ฼้ฬี้ࠠฬ้ฮ฽ืࠠฮฬ์ࠤฯ฾็าࠢ็็ࠥอไๆึส็้่ࠦศๆฦา฼อมࠡ࠰࠱ࠤ฾์ฯ่ษࠣื๏่่ๆࠢๆ์ิ๐ࠠษฬึะ๏๊่ࠠา๊ࠤฬ๊ๅีษๆ่ࠥ๎วๅลั฻ฬวࠠโ์ࠣืั๊ࠠศๆฦา฼อมࠡ࠰࠱ࠤํฮูะ้สࠤ็๋ࠠษวิืฬ๊ࠠิฮ็ࠤฬ๊รฯูสล๊ࠥไๆสิ้ัࠦ࠮࠯๊่ࠢࠥะั๋ัࠣห้ศๆࠡวิืฬ๊ࠠิฮ็ࠤฬ๊รฯูสลࠥหไ๊ࠢส่๊ฮัๆฮࠣรࠦ࠭ࠔ"))
	if ccsup9XAOn5ZFh!=NInUYTpmk7xFPWb(u"࠱ࢫ"): return
	if not qrEMpnHWOYcfsv1i0tTFg2.path.exists(QjtaPo8TYRNfsx):
		U3Ue5N2pjLlVnWM6ox(ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,WrzxMRT1DS5hgiHy8QfP(u"้๊ࠫริใࠣ࠲࠳ࠦำอๆࠣห้ษฮุษฤࠤ฿๐ัࠡ็๋ะํีࠠฤู๊้๊่ࠣฮࠩࠕ"))
		return
	message = SWDNvYiEp08Qmqw1gZ6u(SN1WBMxij70ln4yVpD5d6AFEH(u"ࠬษใหสࠣีุอไหๅࠣห้ะ๊ࠡฬิ๎ิࠦลาีส่์อࠠๆ฻ࠣืั๊ࠠศๆฦา฼อมࠨࠖ"))
	SNPU2ubC7HiIBOcmZE = VDSh4fU8PleCJxFmW1A.getInfoLabel(eaRtLKlTMEmIGVWbuX(u"࠭ࡓࡺࡵࡷࡩࡲ࠴ࡁࡥࡦࡲࡲ࡛࡫ࡲࡴ࡫ࡲࡲ࠭࠭ࠗ")+xkilUeA0ajBfCoQEtNHcX4I8h+Qrm3Tov6k7YVeW(u"ࠧࠪࠩ࠘"))
	file = open(QjtaPo8TYRNfsx,mxJnWkZ4FzGBu6qbhOt7Il(u"ࠨࡴࡥࠫ࠙"))
	Taik7A0SVLZjt2YKMJrd5W6CDgzEH = qrEMpnHWOYcfsv1i0tTFg2.path.getsize(QjtaPo8TYRNfsx)
	if Taik7A0SVLZjt2YKMJrd5W6CDgzEH>cQokr8asyfdDKIuHWGw1AJE(u"࠴࠲࠴࠴࠵࠶ࢬ"): file.seek(-cQokr8asyfdDKIuHWGw1AJE(u"࠴࠲࠴࠴࠵࠶ࢬ"),qrEMpnHWOYcfsv1i0tTFg2.SEEK_END)
	data = file.read()
	file.close()
	data = data.decode(gozhN7V4yXrTjZcLMeGnd3BKJaO(u"ࠩࡸࡸ࡫࠾ࠧࠚ"))
	D1BtuJF5QHyTLb = guTkn9rz3LYS2Pq.findall(gozhN7V4yXrTjZcLMeGnd3BKJaO(u"ࠥࠫࡺࡹࡥࡳࡡ࡬ࡨࠬࡀࠠࠨࠪ࠱࠮ࡄ࠯ࠧࠣࠛ"),data,guTkn9rz3LYS2Pq.DOTALL)
	if not D1BtuJF5QHyTLb: D1BtuJF5QHyTLb = guTkn9rz3LYS2Pq.findall(SN1WBMxij70ln4yVpD5d6AFEH(u"ࠦࠬࡻࡳࡦࡴࠪ࠾ࠥ࠭ࠨ࠯ࠬࡂ࠭ࠬࠨࠜ"),data,guTkn9rz3LYS2Pq.DOTALL)
	if not D1BtuJF5QHyTLb: D1BtuJF5QHyTLb = guTkn9rz3LYS2Pq.findall(k23LtrJoWDx6C0BON(u"ࠬࡢࡤࡼ࠶ࢀ࠱ࡡࡪࡻ࠵ࡿ࠰ࡠࡩࢁ࠴ࡾ࠯࡟ࡨࢀ࠺ࡽ࠮࡞ࡧࡿ࠹ࢃࠧࠝ"),data,guTkn9rz3LYS2Pq.DOTALL)
	D1BtuJF5QHyTLb = D1BtuJF5QHyTLb[eaRtLKlTMEmIGVWbuX(u"࠲ࢭ")] if D1BtuJF5QHyTLb else WrzxMRT1DS5hgiHy8QfP(u"࠭࠰࠱࠲࠳ࠫࠞ")
	D1BtuJF5QHyTLb = D1BtuJF5QHyTLb.split(jkJW5D0zbRX9YB4Q8GxPU(u"ࠧ࡝ࡰࠪࠟ"),SN1WBMxij70ln4yVpD5d6AFEH(u"࠴ࢮ"))[Qrm3Tov6k7YVeW(u"࠴ࢯ")]
	if KepAUNa3jPdc: D1BtuJF5QHyTLb = D1BtuJF5QHyTLb.encode(UT25V9B63GKfFHrlRp(u"ࠨࡷࡷࡪ࠽࠭ࠠ"))
	GfIlwncjkigSyOq3Yt0s = DxNdRrHcF9Wy5nlKJS7(u"ࠩࡄ࡚࠿ࠦࠧࠡ")+D1BtuJF5QHyTLb+UT25V9B63GKfFHrlRp(u"ࠪ࠱ࡊࡳࡥࡳࡩࡨࡲࡨࡿࠧࠢ")
	message += eyR7Wr1g3KGxc(u"ࠫࡡࡴ࡜࡯࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࡞ࡱࡉࡲࡧࡩ࡭ࠢࡖࡩࡳࡪࡥࡳ࠼ࠣࠫࠣ")+D1BtuJF5QHyTLb+z1lNZ9OExoJ(u"ࠬࠦ࠺ࠨࠤ")+eMFoClgyILOQKavisfk4(u"࠭࡜࡯ࠩࠥ")+eaRtLKlTMEmIGVWbuX(u"ࠧࡂࡦࡧࡳࡳࠦࡖࡦࡴࡶ࡭ࡴࡴ࠺ࠡࠩࠦ")+SNPU2ubC7HiIBOcmZE+z1lNZ9OExoJ(u"ࠨࠢ࠽ࡠࡳ࠭ࠧ")
	data = data.encode(kx4pSqTKmn2lQWzIga8BFH(u"ࠩࡸࡸ࡫࠾ࠧࠨ"))
	xTivLDj986NmY2Cqn7WOPH4c = G12GUQsIRXhBEgL5mSpAi9w.b64encode(data)
	JWDxGy3ZKo8 = {eMFoClgyILOQKavisfk4(u"ࠪࡷࡺࡨࡪࡦࡥࡷࠫࠩ"):GfIlwncjkigSyOq3Yt0s,eaRtLKlTMEmIGVWbuX(u"ࠫࡲ࡫ࡳࡴࡣࡪࡩࠬࠪ"):message,Paond9gWS2b4kz(u"ࠬࡲ࡯ࡨࡨ࡬ࡰࡪ࠭ࠫ"):xTivLDj986NmY2Cqn7WOPH4c}
	nck5MtWAwDj3JCKGZeP7TlqN = hhcIpCX07SJxAduDfQn2tPsl4jVab(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵ࡳࡦࡰࡧࡩࡲࡧࡩ࡭ࠩࠬ")
	JC8fotysmeVcL4up3gPdvQ = NMK7r9ngp4EWSBb5AXljGeHC1F.request(fY4DIXRZluJwBaMr872OkCLT1FVjE(u"ࠧࡑࡑࡖࡘࠬ࠭"),nck5MtWAwDj3JCKGZeP7TlqN,data=JWDxGy3ZKo8)
	if JC8fotysmeVcL4up3gPdvQ.status_code==k23LtrJoWDx6C0BON(u"࠷࠶࠰ࢰ"): U3Ue5N2pjLlVnWM6ox(ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,k1dcEyVlqKovBMLDiw6p2CutjOgR(u"ࠨฮํำࠥ࠴࠮่ࠡฯัฯูࠦๆๆํอࠥหัิษ็ࠤุาไࠡษ็วำ฽วยࠩ࠮"))
	else: U3Ue5N2pjLlVnWM6ox(ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,ZNoQUamu2FlikIXwELpPb8zG36JC(u"ࠩ็่ศูแࠡ࠰࠱ࠤๆฺไหࠢ฼้้๐ษࠡวิืฬ๊ࠠิฮ็ࠤฬ๊รฯูสลࠬ࠯"))
	return
def ddgD3AvtInOpVlXBm69cyjbWTSFwf():
	ccsup9XAOn5ZFh = K2qufsHp6US(ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,k23LtrJoWDx6C0BON(u"้้ࠪ็ࠠฦ฻าหิอสࠡษ็ฬึ์วๆฮࠣ๎าะ่๋ࠢ฼่๎ࠦๅฺๆ๋้ฬะࠠหะุࠤฯำฯ๋อࠣห้ฮั็ษ่ะࠥ๎ส็ฺํ้ࠥ฿ๅๅࠢส่อืๆศ็ฯࠤ࠳࠴ฺ่ࠠาࠤู๊อ้ࠡำหࠥอไๆๆไࠤุ๐โ้็ࠣห้ฮั็ษ่ะࠥฮฮๅไ้้ࠣ็ࠠอัํำࠥ็วา฼ࠣ࠲࠳ࠦ็ๅࠢอี๏ีࠠศๆล๊๋ࠥำฮ่่ࠢๆࠦลฺัสำฬะࠠศๆหี๋อๅอࠢยࠥࠬ࠰"))
	if ccsup9XAOn5ZFh!=k23LtrJoWDx6C0BON(u"࠷ࢱ"): return
	bpItXhAG0HikSCmlacwJqO5T8 = XSGqORK6azBkLd7ivfsUIuD0(K0Ghi21YAXBT7gba5o9VIRn3UD6,Paond9gWS2b4kz(u"ࡌࡡ࡭ࡵࡨࣆ"))
	if bpItXhAG0HikSCmlacwJqO5T8: U3Ue5N2pjLlVnWM6ox(ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,OiEvY7pGS2zJW8ltAXwZVkRafoMTD(u"ࠫั๐ฯࠡ࠰࠱ࠤ๋าอหࠢ฼้้๐ษࠡ็ึั๋ࠥไโࠢศ฽ิอฯศฬࠣฬึ์วๆฮࠣ฽๊อฯࠡๆ็ๅ๏ี๊้้สฮࠥอไฺำห๎ฮ࠭࠱"))
	else: U3Ue5N2pjLlVnWM6ox(ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,hhcIpCX07SJxAduDfQn2tPsl4jVab(u"๊ࠬไฤีไࠤ࠳࠴ࠠโึ็ฮࠥ฿ๅๅ์ฬࠤู๊อࠡ็็ๅࠥหูะษาหฯࠦศา่ส้ัูࠦๆษาࠤ้๊แ๋ัํ์์อสࠡษ็฽ึฮ๊สࠩ࠲"))
	return
def y7BMepv8hPY4tHT5nNlJ():
	ccsup9XAOn5ZFh = K2qufsHp6US(ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,hhcIpCX07SJxAduDfQn2tPsl4jVab(u"࠭ๅอๆาࠤ่อิࠡษ็ฬึ์วๆฮࠣ๎าะ่๋ࠢ฼่๎ࠦๅๅใสฮࠥะฮึࠢอ๊฽๐ๅࠡ฻่่ࠥอไษำ้ห๊าࠠๆอ็ࠤ๊๊แศฬࠣห้๋แืๆฬࠤํ๋ไโษอࠤࡎࡖࡔࡗ๋ࠢࠤࡒ࠹ࡕุ๊ࠡ์ึࠦวๅไ๋หห๋ࠠ࠯࠰ࠣ฽๋ีࠠๆีะࠤ์ึวࠡษ็้ั๊ฯࠡีํๆํ๋ࠠศๆหี๋อๅอࠢหา้่ࠠๆฮ็ำࠥาฯ๋ัࠣๅฬืฺࠡ࠰࠱ࠤ์๊ࠠหำํำࠥอไรุ่้ࠣำࠠๆฮ็ำ้ࠥวีࠢส่อืๆศ็ฯࠤฤࠧࠧ࠳"))
	if ccsup9XAOn5ZFh!=OiEvY7pGS2zJW8ltAXwZVkRafoMTD(u"࠱ࢲ"): return
	bpItXhAG0HikSCmlacwJqO5T8 = yjtvb7lhDRq2SJuMI(R9jzfn2Xkyw3Cs0l4OaIpFLxt61,n4W8qFMdEyl1(u"ࡕࡴࡸࡩࣈ"),n4W8qFMdEyl1(u"ࡕࡴࡸࡩࣈ"),NB4UPp0qhSuRIYVyb6(u"ࡆࡢ࡮ࡶࡩࣇ"))
	if bpItXhAG0HikSCmlacwJqO5T8: U3Ue5N2pjLlVnWM6ox(ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,n4W8qFMdEyl1(u"ࠧอ์าࠤ࠳࠴ࠠ็ฮะฮࠥ฿ๅๅ์ฬࠤู๊อࠡ็ฯ่ิࠦใศึࠣห้ฮั็ษ่ะࠬ࠴"))
	else: U3Ue5N2pjLlVnWM6ox(ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,NInUYTpmk7xFPWb(u"ࠨๆ็วุ็ࠠ࠯࠰ࠣๅู๊สࠡ฻่่๏ฯࠠๆีะࠤ๊าไะࠢๆหูࠦวๅสิ๊ฬ๋ฬࠨ࠵"))
	return
def XSGqORK6azBkLd7ivfsUIuD0(ohn5squw0fQjyVMdZXPcTLJ,MrEY1qmkjnNS964lDOHRvW):
	bpItXhAG0HikSCmlacwJqO5T8 = k23LtrJoWDx6C0BON(u"ࡖࡵࡹࡪࣉ")
	if MrEY1qmkjnNS964lDOHRvW:
		ccsup9XAOn5ZFh = K2qufsHp6US(ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,cQokr8asyfdDKIuHWGw1AJE(u"่่ࠩๆࠦลฺัสำฬะࠠศๆหี๋อๅอࠢํัฯ๎๊ࠡ฻็ํู๋ࠥๅ๊่หฯࠦสฯืࠣฮาี๊ฬࠢส่อืๆศ็ฯࠤํะๆู์่ࠤ฾๋ไࠡษ็ฬึ์วๆฮࠣ࠲࠳ูࠦ็ัุ้ࠣำ่ࠠาสࠤฬ๊ๅๅใࠣื๏่่ๆࠢส่อืๆศ็ฯࠤอิไใ่่ࠢๆࠦฬะ์าࠤๆอั฻ࠢ࠱࠲ࠥํไࠡฬิ๎ิࠦวๅฤ้ࠤู๊อࠡ็็ๅࠥหูะษาหฯࠦวๅสิ๊ฬ๋ฬࠡมࠤࠫ࠶"))
		if ccsup9XAOn5ZFh!=z1lNZ9OExoJ(u"࠲ࢳ"): return
	if qrEMpnHWOYcfsv1i0tTFg2.path.exists(ohn5squw0fQjyVMdZXPcTLJ):
		try: qrEMpnHWOYcfsv1i0tTFg2.remove(ohn5squw0fQjyVMdZXPcTLJ)
		except Exception as ZeLnf6Kcsir7CbG45pzdIy2DTYhv8M:
			bpItXhAG0HikSCmlacwJqO5T8 = hhcIpCX07SJxAduDfQn2tPsl4jVab(u"ࡉࡥࡱࡹࡥ࣊")
			if MrEY1qmkjnNS964lDOHRvW: U3Ue5N2pjLlVnWM6ox(ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,str(ZeLnf6Kcsir7CbG45pzdIy2DTYhv8M))
	if MrEY1qmkjnNS964lDOHRvW:
		if bpItXhAG0HikSCmlacwJqO5T8: U3Ue5N2pjLlVnWM6ox(ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,gozhN7V4yXrTjZcLMeGnd3BKJaO(u"ࠪะ๏ีࠠ࠯࠰๊ࠣัำสࠡ฻่่๏ฯࠠศๆ่ืา࠭࠷"))
		else: U3Ue5N2pjLlVnWM6ox(ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,pWLFeVZ7gTPykt3xKiMfvNX06z2u5(u"้๊ࠫริใࠣ࠲࠳ࠦแีๆอࠤ฾๋ไ๋หࠣห้๋ำฮࠩ࠸"))
	return bpItXhAG0HikSCmlacwJqO5T8
def yjtvb7lhDRq2SJuMI(YvQJVPmny0lBgfH5AONaFw,vKQMYe6Rny9Du,FoNu23iBYURfOCr49GMALqj,MrEY1qmkjnNS964lDOHRvW):
	bpItXhAG0HikSCmlacwJqO5T8 = UX0WPRZ6BvEaseMN4tJOkCcGVK(u"ࡘࡷࡻࡥ࣋")
	if MrEY1qmkjnNS964lDOHRvW:
		ccsup9XAOn5ZFh = K2qufsHp6US(ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,YvQJVPmny0lBgfH5AONaFw+mxJnWkZ4FzGBu6qbhOt7Il(u"ࠬࡢ࡮࡝ࡰ๊่ࠥะั๋ัุ้ࠣำ่ࠠาสࠤฬ๊ๅอๆาࠤฤࠧࠧ࠹"))
		if ccsup9XAOn5ZFh!=n4W8qFMdEyl1(u"࠳ࢴ"): return
	if qrEMpnHWOYcfsv1i0tTFg2.path.exists(YvQJVPmny0lBgfH5AONaFw):
		for NNz9Q3HUCPgBSW0Jsiod,GIHZU0P5zASkno4mDKOrCMflJ,Y81m7MWuPb in qrEMpnHWOYcfsv1i0tTFg2.walk(YvQJVPmny0lBgfH5AONaFw,topdown=OiEvY7pGS2zJW8ltAXwZVkRafoMTD(u"ࡋࡧ࡬ࡴࡧ࣌")):
			for IEjhU6rLzOA9c in Y81m7MWuPb:
				ZcSfUVTPpbEAB = qrEMpnHWOYcfsv1i0tTFg2.path.join(NNz9Q3HUCPgBSW0Jsiod,IEjhU6rLzOA9c)
				try: qrEMpnHWOYcfsv1i0tTFg2.remove(ZcSfUVTPpbEAB)
				except Exception as ZeLnf6Kcsir7CbG45pzdIy2DTYhv8M:
					bpItXhAG0HikSCmlacwJqO5T8 = fY4DIXRZluJwBaMr872OkCLT1FVjE(u"ࡌࡡ࡭ࡵࡨ࣍")
					if MrEY1qmkjnNS964lDOHRvW: U3Ue5N2pjLlVnWM6ox(ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,str(ZeLnf6Kcsir7CbG45pzdIy2DTYhv8M))
			if vKQMYe6Rny9Du:
				for iqYETlBxN0rgJ89Iw4uvL1ZaUGc in GIHZU0P5zASkno4mDKOrCMflJ:
					fkPutnjcZrqLm7eEipydCxXRgG = qrEMpnHWOYcfsv1i0tTFg2.path.join(NNz9Q3HUCPgBSW0Jsiod,iqYETlBxN0rgJ89Iw4uvL1ZaUGc)
					try: qrEMpnHWOYcfsv1i0tTFg2.rmdir(fkPutnjcZrqLm7eEipydCxXRgG)
					except: pass
		if FoNu23iBYURfOCr49GMALqj:
			try: qrEMpnHWOYcfsv1i0tTFg2.rmdir(NNz9Q3HUCPgBSW0Jsiod)
			except: pass
	if MrEY1qmkjnNS964lDOHRvW:
		if bpItXhAG0HikSCmlacwJqO5T8: U3Ue5N2pjLlVnWM6ox(ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,iPrTIdcQgVObkW0x5pm7HEsD64KL(u"࠭ฬ๋ัࠣ࠲࠳ࠦๆอฯอࠤ฾๋ไ๋หࠣห้๋ำฮࠩ࠺"))
		else: U3Ue5N2pjLlVnWM6ox(ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,hhcIpCX07SJxAduDfQn2tPsl4jVab(u"ࠧๅๆฦืๆࠦ࠮࠯ࠢไุ้ะฺࠠ็็๎ฮࠦวๅ็ึัࠬ࠻"))
	return bpItXhAG0HikSCmlacwJqO5T8
def gBOzJDdSjeVw():
	ccsup9XAOn5ZFh = K2qufsHp6US(ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,SN1WBMxij70ln4yVpD5d6AFEH(u"ࠨ็ฯ่ิࠦี้ำࠣ็ฯอศสࠢส่็๎วว็ࠣ࠲࠳ࠦ็ัษࠣห้๋ฬๅัࠣๅ๏ํࠠษ฻ูࠤ็๎วว็ࠣห้ฮั็ษ่ะ๋ࠥฮำ่ฬࠤอฺใๅุࠢ์ึࠦศะๆสࠤ๊์ࠠศๆๆฮฬฮษࠡ࠰࠱ࠤ฾์ฯࠡ็ึัࠥอไๆฮ็ำู๊ࠥใ๊่ࠤฬ๊ศา่ส้ัࠦศฯๆๅࠤ๊าไะࠢฯำ๏ี้ࠠ์หำศࠦๅาหࠣวำื้ࠡส่่หํࠠษษ็ูํืฺ่ࠠาࠤๆะอࠡษ็ๆํอฦๆࠢ࠱࠲ࠥํไࠡฬิ๎ิࠦวๅฤ้ࠤู๊อࠡ็ฯ่ิࠦี้ำࠣ็ฯอศสࠢๅ์ฬฬๅࠡษ็ฬึ์วๆฮࠣรࠦ࠭࠼"))
	if ccsup9XAOn5ZFh!=OiEvY7pGS2zJW8ltAXwZVkRafoMTD(u"࠴ࢵ"): return
	bpItXhAG0HikSCmlacwJqO5T8 = yjtvb7lhDRq2SJuMI(XEWenfUMjYDrqJFklbBIsG,NB4UPp0qhSuRIYVyb6(u"ࡕࡴࡸࡩ࣏"),kx4pSqTKmn2lQWzIga8BFH(u"ࡆࡢ࡮ࡶࡩ࣎"),NB4UPp0qhSuRIYVyb6(u"ࡕࡴࡸࡩ࣏"))
	if bpItXhAG0HikSCmlacwJqO5T8: U3Ue5N2pjLlVnWM6ox(ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,OiEvY7pGS2zJW8ltAXwZVkRafoMTD(u"ࠩฯ๎ิࠦ࠮࠯้ࠢะาะฺࠠ็็๎ฮࠦๅิฯ้ࠣั๊ฯࠡื๋ี้ࠥสศสฬࠤฬ๊โ้ษษ้ࠬ࠽"))
	else: U3Ue5N2pjLlVnWM6ox(ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,UX0WPRZ6BvEaseMN4tJOkCcGVK(u"่้ࠪษำโࠢ࠱࠲ࠥ็ิๅฬࠣ฽๊๊๊ส่ࠢืาࠦๅอๆาࠤฺ๎ัࠡๅอหอฯࠠศๆๅ์ฬฬๅࠨ࠾"))
	return
def zj17xm9uv8Tk():
	nck5MtWAwDj3JCKGZeP7TlqN = gozhN7V4yXrTjZcLMeGnd3BKJaO(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡴࡷࡵ࡫ࡪ࠴ࡳࡩ࠱࡮ࡳࡩ࡯࠯ࡦ࡯ࡤࡨࡤࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶ࠳ࡴࡲࡤ࠰࡫ࡱࡨࡪࡾ࠮ࡩࡶࡰࡰࠬ࠿")
	JC8fotysmeVcL4up3gPdvQ = NMK7r9ngp4EWSBb5AXljGeHC1F.request(jkJW5D0zbRX9YB4Q8GxPU(u"ࠬࡍࡅࡕࠩࡀ"),nck5MtWAwDj3JCKGZeP7TlqN)
	GxwMgKDupnirUjTs8cZCNfXqHe23IQ = JC8fotysmeVcL4up3gPdvQ.content
	GxwMgKDupnirUjTs8cZCNfXqHe23IQ = GxwMgKDupnirUjTs8cZCNfXqHe23IQ.decode(eyR7Wr1g3KGxc(u"࠭ࡵࡵࡨ࠻ࠫࡁ"))
	Y81m7MWuPb = guTkn9rz3LYS2Pq.findall(pWLFeVZ7gTPykt3xKiMfvNX06z2u5(u"ࠧࡩࡴࡨࡪࡂࠨࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳࠮࠮ࠫࡁࠬ࠲ࡿ࡯ࡰࠣࠩࡂ"),GxwMgKDupnirUjTs8cZCNfXqHe23IQ,guTkn9rz3LYS2Pq.DOTALL)
	Y81m7MWuPb = sorted(Y81m7MWuPb,reverse=eMFoClgyILOQKavisfk4(u"ࡖࡵࡹࡪ࣐"))
	rr2qKavAn3VOCs = khvBtyMawX9ZoFI.Dialog().select(kx4pSqTKmn2lQWzIga8BFH(u"ࠨษัฮึࠦวๅวุำฬืࠠศๆำ๎ࠥะั๋ัࠣฮะฮ๊ห้ࠪࡃ"),Y81m7MWuPb)
	if rr2qKavAn3VOCs==-UX0WPRZ6BvEaseMN4tJOkCcGVK(u"࠵ࢶ"): return
	filename = Y81m7MWuPb[rr2qKavAn3VOCs]
	if KepAUNa3jPdc: filename = filename.encode(Paond9gWS2b4kz(u"ࠩࡸࡸ࡫࠾ࠧࡄ"))
	O4KisNmAlaCoJYHEjp = nck5MtWAwDj3JCKGZeP7TlqN.rsplit(gozhN7V4yXrTjZcLMeGnd3BKJaO(u"ࠪ࠳ࠬࡅ"),z1lNZ9OExoJ(u"࠶ࢷ"))[cQokr8asyfdDKIuHWGw1AJE(u"࠶ࢸ")]+WrzxMRT1DS5hgiHy8QfP(u"ࠫ࠴࠭ࡆ")+n4W8qFMdEyl1(u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࠬࡇ")+filename+UX0WPRZ6BvEaseMN4tJOkCcGVK(u"࠭࠮ࡻ࡫ࡳࠫࡈ")
	bpItXhAG0HikSCmlacwJqO5T8 = fY4DIXRZluJwBaMr872OkCLT1FVjE(u"ࡉࡥࡱࡹࡥ࣑")
	JC8fotysmeVcL4up3gPdvQ = NMK7r9ngp4EWSBb5AXljGeHC1F.request(SN1WBMxij70ln4yVpD5d6AFEH(u"ࠧࡈࡇࡗࠫࡉ"),O4KisNmAlaCoJYHEjp)
	if JC8fotysmeVcL4up3gPdvQ.status_code==n4W8qFMdEyl1(u"࠲࠱࠲ࢹ"):
		UPSbQhD84Ekwj2aixetXq96 = JC8fotysmeVcL4up3gPdvQ.content
		import zipfile as jjECNZ40xWaklUVIhTeitfpR,io as oDq8hYp4mxdjM0Hc3BOU972iAklW
		UAv9hyRxGaT2ujlpHBCLbXKdsZSr = oDq8hYp4mxdjM0Hc3BOU972iAklW.BytesIO(UPSbQhD84Ekwj2aixetXq96)
		yjtvb7lhDRq2SJuMI(hu3PEy1r5YJCoF0jb9LVD,Qrm3Tov6k7YVeW(u"࡙ࡸࡵࡦ࣓"),Qrm3Tov6k7YVeW(u"࡙ࡸࡵࡦ࣓"),hhcIpCX07SJxAduDfQn2tPsl4jVab(u"ࡊࡦࡲࡳࡦ࣒"))
		qbi2zoL3UEuN7aR85n4AHYIT = jjECNZ40xWaklUVIhTeitfpR.ZipFile(UAv9hyRxGaT2ujlpHBCLbXKdsZSr)
		qbi2zoL3UEuN7aR85n4AHYIT.extractall(JJUlbE2QIpjFGc9gCd)
		JvCkyLb1K85uoTUIDfnX6WwhqAzGe.sleep(k1dcEyVlqKovBMLDiw6p2CutjOgR(u"࠲ࢺ"))
		VDSh4fU8PleCJxFmW1A.executebuiltin(mxJnWkZ4FzGBu6qbhOt7Il(u"ࠨࡗࡳࡨࡦࡺࡥࡍࡱࡦࡥࡱࡇࡤࡥࡱࡱࡷࠬࡊ"))
		JvCkyLb1K85uoTUIDfnX6WwhqAzGe.sleep(Paond9gWS2b4kz(u"࠳ࢻ"))
		uh9JNxesSBfPnAH3k87YIQRET = VDSh4fU8PleCJxFmW1A.executeJSONRPC(WrzxMRT1DS5hgiHy8QfP(u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡃࡧࡨࡴࡴࡳ࠯ࡕࡨࡸࡆࡪࡤࡰࡰࡈࡲࡦࡨ࡬ࡦࡦࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡣࡧࡨࡴࡴࡩࡥࠤ࠽ࠦࠬࡋ")+xkilUeA0ajBfCoQEtNHcX4I8h+QRhraluyTW5pd6(u"ࠪࠦ࠱ࠨࡥ࡯ࡣࡥࡰࡪࡪࠢ࠻ࡶࡵࡹࡪࢃࡽࠨࡌ"))
		if Qrm3Tov6k7YVeW(u"ࠫࡔࡑࠧࡍ") in uh9JNxesSBfPnAH3k87YIQRET: bpItXhAG0HikSCmlacwJqO5T8 = roAFNWJCeLQUZcVP04z9aR(u"࡚ࡲࡶࡧࣔ")
	if bpItXhAG0HikSCmlacwJqO5T8:
		U3Ue5N2pjLlVnWM6ox(ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,OiEvY7pGS2zJW8ltAXwZVkRafoMTD(u"ࠬา๊ะࠢ࠱࠲ࠥ์ฬฮฬࠣ฽๊๊๊สࠢอฯอ๐สࠡษ็ษฺีวาࠢส่็ี๊ๆࠢ࡟ࡲࡡࡴࠠࠨࡎ")+filename)
		msg = SN1WBMxij70ln4yVpD5d6AFEH(u"࠭อห๋ࠣ๎อ่้ࠡษ็ษฺีวาࠢส่็ี๊ๆࠢไ๎ࠥา็ศิๆࠤํ๊วࠡ์อ้ࠥะอะ์ฮ๋ࠥษ่ห๊่หฯ๐ใ๋ษࠣ࠲࠳๊ࠦอสࠣว๋ࠦสใ๊่ࠤอห๊ใษไࠤฬ๊สฮัํฯࠥอไฤ๊อ์๊อส๋ๅํࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡษ็ฦ๋ࠦล๋ไสๅࠥอไหฯา๎ะࠦวๅล๋ฮํ๋วห์ๆ๎๊ࠥไษำ้ห๊าࠠภࠣࠪࡏ")
		DD3LoKpIWyV9lMbJYQ56U(msg)
	else: U3Ue5N2pjLlVnWM6ox(ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,mxJnWkZ4FzGBu6qbhOt7Il(u"ࠧๅๆฦืๆࠦ࠮࠯ࠢไุ้ะฺࠠ็็๎ฮࠦสฬสํฮࠥอไฦืาหึࠦวๅไา๎๊ࠦ࡜࡯࡞ࡱࠤࠬࡐ")+filename)
	return
def DD3LoKpIWyV9lMbJYQ56U(msg=pWLFeVZ7gTPykt3xKiMfvNX06z2u5(u"ࠨ้็ࠤฯื๊ะࠢอุ฿๐ไࠡล๋ࠤส๐โศใࠣห้ะอะ์ฮࠤฬ๊ร้ฬ๋้ฬะ๊ไ์่้ࠣฮั็ษ่ะࠥลࠡࠨࡑ")):
	ccsup9XAOn5ZFh = K2qufsHp6US(ddYkuvQz9Nqiy,QRhraluyTW5pd6(u"ࠩศ๎็อแࠡษ็ฮาี๊ฬࠩࡒ"),kx4pSqTKmn2lQWzIga8BFH(u"ࠪฮาี๊ฬࠢฦ์ฯ๎ๅศฬํ็๏࠭ࡓ"),ddYkuvQz9Nqiy,msg)
	if ccsup9XAOn5ZFh==-eaRtLKlTMEmIGVWbuX(u"࠴ࢼ"): return
	i0J9Td3qBmgk8IlDZL7jWxYC1u = eyR7Wr1g3KGxc(u"ࠫࡪࡴࡡࡣ࡮ࡨࠫࡔ") if ccsup9XAOn5ZFh else kx4pSqTKmn2lQWzIga8BFH(u"ࠬࡪࡩࡴࡣࡥࡰࡪ࠭ࡕ")
	bpItXhAG0HikSCmlacwJqO5T8 = hhcIpCX07SJxAduDfQn2tPsl4jVab(u"ࡆࡢ࡮ࡶࡩࣕ")
	yo0uDNEAxIi2kjWJRHsZ = xb30nIwXEuh2peOWZV8BQyi7qG(u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤࠨࡖ")
	rPo1V4pEWBeyMsGuXL9c5ZSqkw = pWLFeVZ7gTPykt3xKiMfvNX06z2u5(u"ࠧࡣ࡮ࡤࡧࡰࡲࡩࡴࡶࠪࡗ") if KepAUNa3jPdc else m1mxHYPpi9o(u"ࠨࡷࡳࡨࡦࡺࡥࡠࡴࡸࡰࡪࡹࠧࡘ")
	try:
		import sqlite3 as mLho4DFRNl2VUp7r35kI0qXHz
		CpOa0nteZxkNHjufvyTmDI9WX3Ps = mLho4DFRNl2VUp7r35kI0qXHz.connect(hALyaSM5YwejPBObv9)
		CpOa0nteZxkNHjufvyTmDI9WX3Ps.text_factory = str
		jbtwPROZL3YsVNHCQ = CpOa0nteZxkNHjufvyTmDI9WX3Ps.cursor()
		jbtwPROZL3YsVNHCQ.execute(cQokr8asyfdDKIuHWGw1AJE(u"ࠩࡖࡉࡑࡋࡃࡕࠢࡲࡶ࡮࡭ࡩ࡯ࠢࡉࡖࡔࡓࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࡛ࠣࡍࡋࡒࡆࠢࡤࡨࡩࡵ࡮ࡊࡆࠣࡁࠥࠨ࡙ࠧ")+xkilUeA0ajBfCoQEtNHcX4I8h+gozhN7V4yXrTjZcLMeGnd3BKJaO(u"ࠪࠦࠥࡁ࡚ࠧ"))
		QQIGksglXwhnjiEWZMv3UNcAqfa = jbtwPROZL3YsVNHCQ.fetchall()
		if QQIGksglXwhnjiEWZMv3UNcAqfa and yo0uDNEAxIi2kjWJRHsZ not in str(QQIGksglXwhnjiEWZMv3UNcAqfa): jbtwPROZL3YsVNHCQ.execute(Paond9gWS2b4kz(u"࡚ࠫࡖࡄࡂࡖࡈࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪࠠࡔࡇࡗࠤࡴࡸࡩࡨ࡫ࡱࠤࡂࠦࠢࠨ࡛")+yo0uDNEAxIi2kjWJRHsZ+gozhN7V4yXrTjZcLMeGnd3BKJaO(u"ࠬࠨࠠࡘࡊࡈࡖࡊࠦࡡࡥࡦࡲࡲࡎࡊࠠ࠾ࠢࠥࠫ࡜")+xkilUeA0ajBfCoQEtNHcX4I8h+Qrm3Tov6k7YVeW(u"࠭ࠢࠡ࠽ࠪ࡝"))
		jbtwPROZL3YsVNHCQ.execute(eMFoClgyILOQKavisfk4(u"ࠧࡔࡇࡏࡉࡈ࡚ࠠࠫࠢࡉࡖࡔࡓࠠࠨ࡞")+rPo1V4pEWBeyMsGuXL9c5ZSqkw+hhcIpCX07SJxAduDfQn2tPsl4jVab(u"ࠨ࡚ࠢࡌࡊࡘࡅࠡࡣࡧࡨࡴࡴࡉࡅࠢࡀࠤࠧ࠭࡟")+xkilUeA0ajBfCoQEtNHcX4I8h+NB4UPp0qhSuRIYVyb6(u"ࠩࠥࠤࡀ࠭ࡠ"))
		QQIGksglXwhnjiEWZMv3UNcAqfa = jbtwPROZL3YsVNHCQ.fetchall()
		V4taDR2jf50Hko7mMT = xb30nIwXEuh2peOWZV8BQyi7qG(u"ࡈࡤࡰࡸ࡫ࣗ") if QQIGksglXwhnjiEWZMv3UNcAqfa else UT25V9B63GKfFHrlRp(u"ࡕࡴࡸࡩࣖ")
		if not V4taDR2jf50Hko7mMT and DxNdRrHcF9Wy5nlKJS7(u"ࠪࡩࡳࡧࡢ࡭ࡧࠪࡡ") in i0J9Td3qBmgk8IlDZL7jWxYC1u: jbtwPROZL3YsVNHCQ.execute(iPrTIdcQgVObkW0x5pm7HEsD64KL(u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࠪࡢ")+rPo1V4pEWBeyMsGuXL9c5ZSqkw+SN1WBMxij70ln4yVpD5d6AFEH(u"ࠬࠦࡗࡉࡇࡕࡉࠥࡧࡤࡥࡱࡱࡍࡉࠦ࠽ࠡࠤࠪࡣ")+xkilUeA0ajBfCoQEtNHcX4I8h+eMFoClgyILOQKavisfk4(u"࠭ࠢࠡ࠽ࠪࡤ"))
		elif V4taDR2jf50Hko7mMT and fY4DIXRZluJwBaMr872OkCLT1FVjE(u"ࠧࡥ࡫ࡶࡥࡧࡲࡥࠨࡥ") in i0J9Td3qBmgk8IlDZL7jWxYC1u:
			if KepAUNa3jPdc: jbtwPROZL3YsVNHCQ.execute(n4W8qFMdEyl1(u"ࠨࡋࡑࡗࡊࡘࡔࠡࡋࡑࡘࡔࠦࠧࡦ")+rPo1V4pEWBeyMsGuXL9c5ZSqkw+kx4pSqTKmn2lQWzIga8BFH(u"ࠩࠣࠬࡦࡪࡤࡰࡰࡌࡈ࠮ࠦࡖࡂࡎࡘࡉࡘࠦࠨࠣࠩࡧ")+xkilUeA0ajBfCoQEtNHcX4I8h+jkJW5D0zbRX9YB4Q8GxPU(u"ࠪࠦ࠮ࠦ࠻ࠨࡨ"))
			else: jbtwPROZL3YsVNHCQ.execute(WrzxMRT1DS5hgiHy8QfP(u"ࠫࡎࡔࡓࡆࡔࡗࠤࡎࡔࡔࡐࠢࠪࡩ")+rPo1V4pEWBeyMsGuXL9c5ZSqkw+Paond9gWS2b4kz(u"ࠬࠦࠨࡢࡦࡧࡳࡳࡏࡄ࠭ࡷࡳࡨࡦࡺࡥࡓࡷ࡯ࡩ࠮ࠦࡖࡂࡎࡘࡉࡘࠦࠨࠣࠩࡪ")+xkilUeA0ajBfCoQEtNHcX4I8h+eyR7Wr1g3KGxc(u"࠭ࠢ࠭࠳ࠬࠤࡀ࠭࡫"))
		CpOa0nteZxkNHjufvyTmDI9WX3Ps.commit()
		CpOa0nteZxkNHjufvyTmDI9WX3Ps.close()
		bpItXhAG0HikSCmlacwJqO5T8 = k1dcEyVlqKovBMLDiw6p2CutjOgR(u"ࡗࡶࡺ࡫ࣘ")
	except: pass
	if bpItXhAG0HikSCmlacwJqO5T8:
		JvCkyLb1K85uoTUIDfnX6WwhqAzGe.sleep(k23LtrJoWDx6C0BON(u"࠵ࢽ"))
		VDSh4fU8PleCJxFmW1A.executebuiltin(Paond9gWS2b4kz(u"ࠧࡖࡲࡧࡥࡹ࡫ࡌࡰࡥࡤࡰࡆࡪࡤࡰࡰࡶࠫ࡬"))
		JvCkyLb1K85uoTUIDfnX6WwhqAzGe.sleep(QRhraluyTW5pd6(u"࠶ࢾ"))
		U3Ue5N2pjLlVnWM6ox(ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,BdIP6HG3zMR7XCEa98Lgpn(u"ࠨฮํำࠥ࠴࠮่ࠡฯัฯࠦวๅ฻่่๏ฯࠧ࡭"))
	else: U3Ue5N2pjLlVnWM6ox(ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,ZNoQUamu2FlikIXwELpPb8zG36JC(u"ࠩ็่ศูแࠡ࠰࠱ࠤๆฺไหࠢส่฾๋ไ๋หࠪ࡮"))
	return
def sT7gjPQ5aAxXvq8rNMe():
	ccsup9XAOn5ZFh = K2qufsHp6US(ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,jkJW5D0zbRX9YB4Q8GxPU(u"ࠪ฽๊๊๊สࠢอ๊฽๐แࠡๅ๋ำ๏ࠦสห็ࠣฬู๊อࠡษ็้้็วหࠢส่็ี๊ๆหࠣห้๋ฤใฬฬࠤฬ๊ส๋่ࠢฮัู๋สࠢไ๎๋ࠥฬๅัสฮࠥ๎ๅๅใสฮ้่ࠥะ์ࠣ࠲࠳ࠦ็ๅࠢอี๏ีࠠห่฻๎ๆࠦใ้ัํࠤฬ๊ย็ࠢยࠥࠬ࡯"))
	if ccsup9XAOn5ZFh!=OiEvY7pGS2zJW8ltAXwZVkRafoMTD(u"࠷ࢿ"): return
	rMa2qoZOEI1QU5b0FXu = yjtvb7lhDRq2SJuMI(TXoYO8tDzFKpj0dabnM,Paond9gWS2b4kz(u"࡙ࡸࡵࡦࣚ"),hhcIpCX07SJxAduDfQn2tPsl4jVab(u"ࡊࡦࡲࡳࡦࣙ"),hhcIpCX07SJxAduDfQn2tPsl4jVab(u"ࡊࡦࡲࡳࡦࣙ"))
	EqQxmsXecCSydKLZNIGuon = yjtvb7lhDRq2SJuMI(WWIamGyZfF1wN7pSBjO8vTUkD0VKt,iPrTIdcQgVObkW0x5pm7HEsD64KL(u"ࡔࡳࡷࡨࣜ"),WrzxMRT1DS5hgiHy8QfP(u"ࡌࡡ࡭ࡵࡨࣛ"),WrzxMRT1DS5hgiHy8QfP(u"ࡌࡡ࡭ࡵࡨࣛ"))
	t2YOIz7wviPndCefgloBu = yjtvb7lhDRq2SJuMI(rzJRLiohwuXHSsq0G2l5tCmBd1yAp9,k1dcEyVlqKovBMLDiw6p2CutjOgR(u"ࡖࡵࡹࡪࣞ"),UT25V9B63GKfFHrlRp(u"ࡇࡣ࡯ࡷࡪࣝ"),UT25V9B63GKfFHrlRp(u"ࡇࡣ࡯ࡷࡪࣝ"))
	S1AU5hjYtBsQx8CzEcR = OV3y64Ltrq5HvKSsYXbDlB(cQokr8asyfdDKIuHWGw1AJE(u"ࡗࡶࡺ࡫ࣟ"))
	XhA1Hz5kQyT = YjtXhAOiIf()
	bpItXhAG0HikSCmlacwJqO5T8 = all([rMa2qoZOEI1QU5b0FXu,EqQxmsXecCSydKLZNIGuon,t2YOIz7wviPndCefgloBu,S1AU5hjYtBsQx8CzEcR,XhA1Hz5kQyT])
	if bpItXhAG0HikSCmlacwJqO5T8: U3Ue5N2pjLlVnWM6ox(ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,iPrTIdcQgVObkW0x5pm7HEsD64KL(u"ࠫั๐ฯࠡ࠰࠱ࠤ๋าอหࠢ฼้้๐ษࠡฬ้฼๏็ࠠไ๊า๎ࠬࡰ"))
	else: U3Ue5N2pjLlVnWM6ox(ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,SN1WBMxij70ln4yVpD5d6AFEH(u"๊ࠬไฤีไࠤ࠳࠴ࠠโึ็ฮࠥ฿ๅๅ์ฬࠤฯ์ุ๋ใࠣ็ํี๊ࠨࡱ"))
	return
def tRrYE1kjwM2Pm9o48p():
	ccsup9XAOn5ZFh = K2qufsHp6US(ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,iPrTIdcQgVObkW0x5pm7HEsD64KL(u"ู࠭ๆๆํอࠥะๆู์ไࠤฬ๊ฬ่ษีࠤฯะๅࠡส่ืาࠦวๅ็็ๅฬะࠠศๆๅำ๏๋ษࠡษ็้ษ่สสࠢส่ฯ๐ࠠๆฬฯ้฾ฯࠠโ์๊ࠣ฽อๅࠡฬื฾๏๊ࠠศๆฯ๋ฬุࠠ࠯࠰๋้ࠣࠦสา์าࠤฯ์ุ๋ใࠣห้า็ศิࠣห้ศๆࠡมࠤࠫࡲ"))
	if ccsup9XAOn5ZFh!=ZNoQUamu2FlikIXwELpPb8zG36JC(u"࠱ࣀ"): return
	q85VGekClAJ3nhKa27MmUz = WrzxMRT1DS5hgiHy8QfP(u"ࠧ࠰ࡦࡤࡸࡦ࠵ࡳࡺࡵࡷࡩࡲ࠵ࡵࡴࡣࡪࡩࡸࡺࡡࡵࡵࠪࡳ")
	pq1xzmJM6UB = xb30nIwXEuh2peOWZV8BQyi7qG(u"ࠨ࠱ࡧࡥࡹࡧ࠯ࡴࡻࡶࡸࡪࡳ࠯ࡥࡴࡲࡴࡧࡵࡸࠨࡴ")
	r2SPXjJdaUwTCm = n4W8qFMdEyl1(u"ࠩ࠲ࡨࡦࡺࡡ࠰ࡶࡲࡱࡧࡹࡴࡰࡰࡨࡷࠬࡵ")
	bLsKtgXEd1mB3 = k23LtrJoWDx6C0BON(u"ࠪ࠳ࡩࡧࡴࡢ࠱࡯ࡳ࡬࡭ࡥࡳࠩࡶ")
	HZBio7pGmXN5Q1x3OMhlUwcj = xb30nIwXEuh2peOWZV8BQyi7qG(u"ࠫ࠴ࡪࡡࡵࡣ࠲ࡰࡴ࡭ࠧࡷ")
	Y1F8k7doRQDKLcIUZV = mxJnWkZ4FzGBu6qbhOt7Il(u"ࠬ࠵ࡤࡢࡶࡤ࠳ࡦࡴࡲࠨࡸ")
	rMa2qoZOEI1QU5b0FXu = yjtvb7lhDRq2SJuMI(q85VGekClAJ3nhKa27MmUz,WrzxMRT1DS5hgiHy8QfP(u"࡙ࡸࡵࡦ࣡"),hhcIpCX07SJxAduDfQn2tPsl4jVab(u"ࡊࡦࡲࡳࡦ࣠"),hhcIpCX07SJxAduDfQn2tPsl4jVab(u"ࡊࡦࡲࡳࡦ࣠"))
	EqQxmsXecCSydKLZNIGuon = yjtvb7lhDRq2SJuMI(pq1xzmJM6UB,gozhN7V4yXrTjZcLMeGnd3BKJaO(u"ࡔࡳࡷࡨࣣ"),QRhraluyTW5pd6(u"ࡌࡡ࡭ࡵࡨ࣢"),QRhraluyTW5pd6(u"ࡌࡡ࡭ࡵࡨ࣢"))
	t2YOIz7wviPndCefgloBu = yjtvb7lhDRq2SJuMI(r2SPXjJdaUwTCm,roAFNWJCeLQUZcVP04z9aR(u"ࡖࡵࡹࡪࣥ"),UX0WPRZ6BvEaseMN4tJOkCcGVK(u"ࡇࡣ࡯ࡷࡪࣤ"),UX0WPRZ6BvEaseMN4tJOkCcGVK(u"ࡇࡣ࡯ࡷࡪࣤ"))
	S1AU5hjYtBsQx8CzEcR = yjtvb7lhDRq2SJuMI(bLsKtgXEd1mB3,fY4DIXRZluJwBaMr872OkCLT1FVjE(u"ࡘࡷࡻࡥࣧ"),ZNoQUamu2FlikIXwELpPb8zG36JC(u"ࡉࡥࡱࡹࡥࣦ"),ZNoQUamu2FlikIXwELpPb8zG36JC(u"ࡉࡥࡱࡹࡥࣦ"))
	XhA1Hz5kQyT = yjtvb7lhDRq2SJuMI(HZBio7pGmXN5Q1x3OMhlUwcj,roAFNWJCeLQUZcVP04z9aR(u"࡚ࡲࡶࡧࣩ"),jbZzrvqlIVyM2FaO4Km0B9G75Lk81S(u"ࡋࡧ࡬ࡴࡧࣨ"),jbZzrvqlIVyM2FaO4Km0B9G75Lk81S(u"ࡋࡧ࡬ࡴࡧࣨ"))
	bAh1seWGuUH = yjtvb7lhDRq2SJuMI(Y1F8k7doRQDKLcIUZV,jbZzrvqlIVyM2FaO4Km0B9G75Lk81S(u"ࡕࡴࡸࡩ࣫"),jbZzrvqlIVyM2FaO4Km0B9G75Lk81S(u"ࡆࡢ࡮ࡶࡩ࣪"),jbZzrvqlIVyM2FaO4Km0B9G75Lk81S(u"ࡆࡢ࡮ࡶࡩ࣪"))
	bpItXhAG0HikSCmlacwJqO5T8 = all([rMa2qoZOEI1QU5b0FXu,EqQxmsXecCSydKLZNIGuon,t2YOIz7wviPndCefgloBu,S1AU5hjYtBsQx8CzEcR,XhA1Hz5kQyT,bAh1seWGuUH])
	if bpItXhAG0HikSCmlacwJqO5T8: U3Ue5N2pjLlVnWM6ox(ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,eaRtLKlTMEmIGVWbuX(u"࠭ฬ๋ัࠣ࠲࠳ࠦๆอฯอࠤ฾๋ไ๋หࠣฮ๋฾๊โࠢส่ัํวำࠩࡹ"))
	else: U3Ue5N2pjLlVnWM6ox(ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,Paond9gWS2b4kz(u"ࠧๅๆฦืๆࠦ࠮࠯ࠢไุ้ะฺࠠ็็๎ฮࠦส็ฺํๅࠥอไอ้สึࠬࡺ"))
	return
def OV3y64Ltrq5HvKSsYXbDlB(MrEY1qmkjnNS964lDOHRvW):
	bpItXhAG0HikSCmlacwJqO5T8 = eMFoClgyILOQKavisfk4(u"ࡖࡵࡹࡪ࣬")
	if MrEY1qmkjnNS964lDOHRvW:
		ccsup9XAOn5ZFh = K2qufsHp6US(ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,QRhraluyTW5pd6(u"ࠨ้็ࠤฯื๊ะ่ࠢืาࠦๅฮฬ๋๎ฬะࠠๆๆไࠤฺ๎ัࠡษ็ะ้ีࠠภࠣࠤࠫࡻ"))
		if ccsup9XAOn5ZFh!=UT25V9B63GKfFHrlRp(u"࠲ࣁ"): return
	try:
		import sqlite3 as mLho4DFRNl2VUp7r35kI0qXHz
		pNRAaTrWt7wx9 = mLho4DFRNl2VUp7r35kI0qXHz.connect(L2Ze4ntgahoz6mBNylV0931XO8UYf)
		pNRAaTrWt7wx9.text_factory = str
		jbtwPROZL3YsVNHCQ = pNRAaTrWt7wx9.cursor()
		jbtwPROZL3YsVNHCQ.execute(UX0WPRZ6BvEaseMN4tJOkCcGVK(u"ࠩࡇࡉࡑࡋࡔࡆࠢࡉࡖࡔࡓࠠࡱࡣࡷ࡬ࡀ࠭ࡼ"))
		jbtwPROZL3YsVNHCQ.execute(eyR7Wr1g3KGxc(u"ࠪࡈࡊࡒࡅࡕࡇࠣࡊࡗࡕࡍࠡࡵ࡬ࡾࡪࡹ࠻ࠨࡽ"))
		jbtwPROZL3YsVNHCQ.execute(cQokr8asyfdDKIuHWGw1AJE(u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࡷࡩࡽࡺࡵࡳࡧ࠾ࠫࡾ"))
		pNRAaTrWt7wx9.commit()
		jbtwPROZL3YsVNHCQ.execute(OiEvY7pGS2zJW8ltAXwZVkRafoMTD(u"ࠬ࡜ࡁࡄࡗࡘࡑࡀ࠭ࡿ"))
		pNRAaTrWt7wx9.close()
	except: bpItXhAG0HikSCmlacwJqO5T8 = QRhraluyTW5pd6(u"ࡉࡥࡱࡹࡥ࣭")
	if MrEY1qmkjnNS964lDOHRvW and bpItXhAG0HikSCmlacwJqO5T8: U3Ue5N2pjLlVnWM6ox(ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,gozhN7V4yXrTjZcLMeGnd3BKJaO(u"࠭สๆࠢสู่๊อࠡส้ะฬำࠧࢀ"))
	return bpItXhAG0HikSCmlacwJqO5T8
def YjtXhAOiIf():
	bpItXhAG0HikSCmlacwJqO5T8 = jkJW5D0zbRX9YB4Q8GxPU(u"ࡘࡷࡻࡥ࣮")
	for file in qrEMpnHWOYcfsv1i0tTFg2.listdir(rqWMsAzJfEl6SIBXi4Ogj30DZhRQ):
		if QRhraluyTW5pd6(u"ࠧ࡬ࡱࡧ࡭ࡤࡹࡴࡢࡥ࡮ࡸࡷࡧࡣࡦࠩࢁ") not in file or roAFNWJCeLQUZcVP04z9aR(u"ࠨ࡭ࡲࡨ࡮ࡥࡣࡳࡣࡶ࡬ࡱࡵࡧࠨࢂ") not in file: continue
		ZcSfUVTPpbEAB = qrEMpnHWOYcfsv1i0tTFg2.path.join(rqWMsAzJfEl6SIBXi4Ogj30DZhRQ,file)
		try:
			qrEMpnHWOYcfsv1i0tTFg2.remove(ZcSfUVTPpbEAB)
		except Exception as ZeLnf6Kcsir7CbG45pzdIy2DTYhv8M:
			bpItXhAG0HikSCmlacwJqO5T8 = gozhN7V4yXrTjZcLMeGnd3BKJaO(u"ࡋࡧ࡬ࡴࡧ࣯")
			if MrEY1qmkjnNS964lDOHRvW and bpItXhAG0HikSCmlacwJqO5T8: U3Ue5N2pjLlVnWM6ox(ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,ddYkuvQz9Nqiy,str(ZeLnf6Kcsir7CbG45pzdIy2DTYhv8M))
	return bpItXhAG0HikSCmlacwJqO5T8
enOiIWQtmsDb3JxvfCZyBwjrhTXlK2(mxJnWkZ4FzGBu6qbhOt7Il(u"ࠩࡶࡸࡦࡸࡴࠨࢃ"))
YYTqyBc0w3Mfbo = Igx6pfyZGaDBEF1hoNVPw.argv[m1mxHYPpi9o(u"࠳ࣂ")]
xkilUeA0ajBfCoQEtNHcX4I8h = UT25V9B63GKfFHrlRp(u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨࢄ")
llwHzWG47ALJy = VDSh4fU8PleCJxFmW1A.getInfoLabel(xb30nIwXEuh2peOWZV8BQyi7qG(u"ࠦࡘࡿࡳࡵࡧࡰ࠲ࡇࡻࡩ࡭ࡦ࡙ࡩࡷࡹࡩࡰࡰࠥࢅ"))
RRTxwP0eC9uSO7 = guTkn9rz3LYS2Pq.findall(QRhraluyTW5pd6(u"ࠬ࠮࡜ࡥ࡞ࡧࡠ࠳ࡢࡤࠪࠩࢆ"),llwHzWG47ALJy,guTkn9rz3LYS2Pq.DOTALL)
RRTxwP0eC9uSO7 = float(RRTxwP0eC9uSO7[iPrTIdcQgVObkW0x5pm7HEsD64KL(u"࠳ࣃ")])
KepAUNa3jPdc = RRTxwP0eC9uSO7<iPrTIdcQgVObkW0x5pm7HEsD64KL(u"࠵࠾ࣄ")
dxDymj1vPuRTYN0AhbKkt = RRTxwP0eC9uSO7>ZNoQUamu2FlikIXwELpPb8zG36JC(u"࠶࠾࠮࠺࠻ࣅ")
if dxDymj1vPuRTYN0AhbKkt:
	rqWMsAzJfEl6SIBXi4Ogj30DZhRQ = VC9Ka7pQ3bEvoL8XTmS.translatePath(mxJnWkZ4FzGBu6qbhOt7Il(u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱࡯ࡳ࡬ࡶࡡࡵࡪࠪࢇ"))
	pWzgT0ZManNLQ = VC9Ka7pQ3bEvoL8XTmS.translatePath(z1lNZ9OExoJ(u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲࡬ࡴࡳࡥࠨ࢈"))
	SFqzLZOx3a5y = VC9Ka7pQ3bEvoL8XTmS.translatePath(ZNoQUamu2FlikIXwELpPb8zG36JC(u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳ࡹ࡫࡭ࡱࠩࢉ"))
	hALyaSM5YwejPBObv9 = qrEMpnHWOYcfsv1i0tTFg2.path.join(pWzgT0ZManNLQ,hhcIpCX07SJxAduDfQn2tPsl4jVab(u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫࢊ"),fY4DIXRZluJwBaMr872OkCLT1FVjE(u"ࠪࡈࡦࡺࡡࡣࡣࡶࡩࠬࢋ"),iPrTIdcQgVObkW0x5pm7HEsD64KL(u"ࠫࡆࡪࡤࡰࡰࡶ࠷࠸࠴ࡤࡣࠩࢌ"))
else:
	rqWMsAzJfEl6SIBXi4Ogj30DZhRQ = VDSh4fU8PleCJxFmW1A.translatePath(DxNdRrHcF9Wy5nlKJS7(u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰࡮ࡲ࡫ࡵࡧࡴࡩࠩࢍ"))
	pWzgT0ZManNLQ = VDSh4fU8PleCJxFmW1A.translatePath(eyR7Wr1g3KGxc(u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱࡫ࡳࡲ࡫ࠧࢎ"))
	SFqzLZOx3a5y = VDSh4fU8PleCJxFmW1A.translatePath(hhcIpCX07SJxAduDfQn2tPsl4jVab(u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲ࡸࡪࡳࡰࠨ࢏"))
	hALyaSM5YwejPBObv9 = qrEMpnHWOYcfsv1i0tTFg2.path.join(pWzgT0ZManNLQ,m1mxHYPpi9o(u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪ࢐"),eyR7Wr1g3KGxc(u"ࠩࡇࡥࡹࡧࡢࡢࡵࡨࠫ࢑"),roAFNWJCeLQUZcVP04z9aR(u"ࠪࡅࡩࡪ࡯࡯ࡵ࠵࠻࠳ࡪࡢࠨ࢒"))
dn1TL2WJMAEZfhxkS80XPYVU7yt = qrEMpnHWOYcfsv1i0tTFg2.path.join(pWzgT0ZManNLQ,SN1WBMxij70ln4yVpD5d6AFEH(u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭࢓"),cQokr8asyfdDKIuHWGw1AJE(u"ࠬࡧࡤࡥࡱࡱࡣࡩࡧࡴࡢࠩ࢔"),xkilUeA0ajBfCoQEtNHcX4I8h)
K0Ghi21YAXBT7gba5o9VIRn3UD6 = qrEMpnHWOYcfsv1i0tTFg2.path.join(dn1TL2WJMAEZfhxkS80XPYVU7yt,DxNdRrHcF9Wy5nlKJS7(u"࠭ࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡺࡰࡰࠬ࢕"))
R9jzfn2Xkyw3Cs0l4OaIpFLxt61 = qrEMpnHWOYcfsv1i0tTFg2.path.join(SFqzLZOx3a5y,xkilUeA0ajBfCoQEtNHcX4I8h)
rzJRLiohwuXHSsq0G2l5tCmBd1yAp9 = qrEMpnHWOYcfsv1i0tTFg2.path.join(pWzgT0ZManNLQ,QRhraluyTW5pd6(u"ࠧࡶࡵࡨࡶࡩࡧࡴࡢࠩ࢖"),UX0WPRZ6BvEaseMN4tJOkCcGVK(u"ࠨࡖ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡷࠬࢗ"))
JJUlbE2QIpjFGc9gCd = qrEMpnHWOYcfsv1i0tTFg2.path.join(pWzgT0ZManNLQ,NB4UPp0qhSuRIYVyb6(u"ࠩࡤࡨࡩࡵ࡮ࡴࠩ࢘"))
hu3PEy1r5YJCoF0jb9LVD = qrEMpnHWOYcfsv1i0tTFg2.path.join(JJUlbE2QIpjFGc9gCd,xkilUeA0ajBfCoQEtNHcX4I8h)
TXoYO8tDzFKpj0dabnM = qrEMpnHWOYcfsv1i0tTFg2.path.join(JJUlbE2QIpjFGc9gCd,k23LtrJoWDx6C0BON(u"ࠪࡸࡪࡳࡰࠨ࢙"))
WWIamGyZfF1wN7pSBjO8vTUkD0VKt = qrEMpnHWOYcfsv1i0tTFg2.path.join(JJUlbE2QIpjFGc9gCd,k23LtrJoWDx6C0BON(u"ࠫࡵࡧࡣ࡬ࡣࡪࡩࡸ࢚࠭"))
L2Ze4ntgahoz6mBNylV0931XO8UYf = qrEMpnHWOYcfsv1i0tTFg2.path.join(pWzgT0ZManNLQ,z1lNZ9OExoJ(u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧ࢛ࠧ"),roAFNWJCeLQUZcVP04z9aR(u"࠭ࡄࡢࡶࡤࡦࡦࡹࡥࠨ࢜"),ZNoQUamu2FlikIXwELpPb8zG36JC(u"ࠧࡕࡧࡻࡸࡺࡸࡥࡴ࠳࠶࠲ࡩࡨࠧ࢝"))
XEWenfUMjYDrqJFklbBIsG = qrEMpnHWOYcfsv1i0tTFg2.path.join(R9jzfn2Xkyw3Cs0l4OaIpFLxt61,DxNdRrHcF9Wy5nlKJS7(u"ࠨ࡫ࡰࡥ࡬࡫ࡳࠨ࢞"))
ylfWM3EBNq = qrEMpnHWOYcfsv1i0tTFg2.path.join(rqWMsAzJfEl6SIBXi4Ogj30DZhRQ,fY4DIXRZluJwBaMr872OkCLT1FVjE(u"ࠩ࡮ࡳࡩ࡯࠮࡭ࡱࡪࠫ࢟"))
WWul8XUIdZ = qrEMpnHWOYcfsv1i0tTFg2.path.join(rqWMsAzJfEl6SIBXi4Ogj30DZhRQ,m1mxHYPpi9o(u"ࠪ࡯ࡴࡪࡩ࠯ࡱ࡯ࡨ࠳ࡲ࡯ࡨࠩࢠ"))
if   YYTqyBc0w3Mfbo==BdIP6HG3zMR7XCEa98Lgpn(u"ࠫࡸ࡫࡮ࡥࡡ࡯ࡳ࡬࡬ࡩ࡭ࡧࠪࢡ")		: TF5EGLWicS(ylfWM3EBNq)
elif YYTqyBc0w3Mfbo==jkJW5D0zbRX9YB4Q8GxPU(u"ࠬࡹࡥ࡯ࡦࡢࡳࡱࡪ࡟࡭ࡱࡪࡪ࡮ࡲࡥࠨࢢ")	: TF5EGLWicS(WWul8XUIdZ)
elif YYTqyBc0w3Mfbo==eyR7Wr1g3KGxc(u"࠭ࡤࡦ࡮ࡨࡸࡪࡥࡳࡦࡶࡷ࡭ࡳ࡭ࡳࠨࢣ")		: ddgD3AvtInOpVlXBm69cyjbWTSFwf()
elif YYTqyBc0w3Mfbo==NB4UPp0qhSuRIYVyb6(u"ࠧࡥࡧ࡯ࡩࡹ࡫࡟ࡤࡣࡦ࡬ࡪ࠭ࢤ")		: y7BMepv8hPY4tHT5nNlJ()
elif YYTqyBc0w3Mfbo==fY4DIXRZluJwBaMr872OkCLT1FVjE(u"ࠨࡥ࡯ࡩࡦࡴ࡟࡬ࡱࡧ࡭ࠬࢥ")			: sT7gjPQ5aAxXvq8rNMe()
elif YYTqyBc0w3Mfbo==kx4pSqTKmn2lQWzIga8BFH(u"ࠩࡦࡰࡪࡧ࡮ࡠࡦࡨࡺ࡮ࡩࡥࡠࡱࡶࠫࢦ")		: tRrYE1kjwM2Pm9o48p()
elif YYTqyBc0w3Mfbo==NInUYTpmk7xFPWb(u"ࠪ࡭ࡳࡹࡴࡢ࡮࡯ࡣࡴࡲࡤࡠࡸࡨࡶࡸ࡯࡯࡯ࠩࢧ")	: zj17xm9uv8Tk()
elif YYTqyBc0w3Mfbo==iPrTIdcQgVObkW0x5pm7HEsD64KL(u"ࠫࡲࡵࡤࡪࡨࡼࡣࡦࡻࡴࡰࡷࡳࡨࡦࡺࡥࠨࢨ")	: DD3LoKpIWyV9lMbJYQ56U()
elif YYTqyBc0w3Mfbo==eaRtLKlTMEmIGVWbuX(u"ࠬࡪࡥ࡭ࡧࡷࡩࡤࡳࡥ࡯ࡷࡶࡣ࡮ࡳࡡࡨࡧࡶࠫࢩ")	: gBOzJDdSjeVw()
enOiIWQtmsDb3JxvfCZyBwjrhTXlK2(xb30nIwXEuh2peOWZV8BQyi7qG(u"࠭ࡳࡵࡱࡳࠫࢪ"))
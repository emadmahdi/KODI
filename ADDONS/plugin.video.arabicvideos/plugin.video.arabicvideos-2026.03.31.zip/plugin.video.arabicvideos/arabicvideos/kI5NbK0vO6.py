# -*- coding: utf-8 -*-
import sys as sjVE6XGymcf09qbiKODZdAC
LVpmDXhWH5wGKy1eqMB = sjVE6XGymcf09qbiKODZdAC.version_info [0] == 2
RGEuTe9PD7o45d2v = 2048
r3HIioGW0Nl = 7
def Brz09AF6apy52OuEq1s (ccr3g6sWvxSOqDiLJuF1Vf2KUtG):
	global YzIBLo1J4ZOCEPtjq
	SSzr8EskcFRLobZqtC2QeTyPg4Y = ord (ccr3g6sWvxSOqDiLJuF1Vf2KUtG [-1])
	JIf7wGht4BqbQ5Xik1mYTA3DeLvaPO = ccr3g6sWvxSOqDiLJuF1Vf2KUtG [:-1]
	ZYd0PzhKWmvFN5TfcQI = SSzr8EskcFRLobZqtC2QeTyPg4Y % len (JIf7wGht4BqbQ5Xik1mYTA3DeLvaPO)
	itRzfVamqWwLIynhGpDM4ZUe = JIf7wGht4BqbQ5Xik1mYTA3DeLvaPO [:ZYd0PzhKWmvFN5TfcQI] + JIf7wGht4BqbQ5Xik1mYTA3DeLvaPO [ZYd0PzhKWmvFN5TfcQI:]
	if LVpmDXhWH5wGKy1eqMB:
		MHSngXbpVZde6NiQc9IrCxt78 = unicode () .join ([unichr (ord (Ep0JIWsLABieR) - RGEuTe9PD7o45d2v - (D2bEPIlOQJy4dYntR3MCiKLusT + SSzr8EskcFRLobZqtC2QeTyPg4Y) % r3HIioGW0Nl) for D2bEPIlOQJy4dYntR3MCiKLusT, Ep0JIWsLABieR in enumerate (itRzfVamqWwLIynhGpDM4ZUe)])
	else:
		MHSngXbpVZde6NiQc9IrCxt78 = str () .join ([chr (ord (Ep0JIWsLABieR) - RGEuTe9PD7o45d2v - (D2bEPIlOQJy4dYntR3MCiKLusT + SSzr8EskcFRLobZqtC2QeTyPg4Y) % r3HIioGW0Nl) for D2bEPIlOQJy4dYntR3MCiKLusT, Ep0JIWsLABieR in enumerate (itRzfVamqWwLIynhGpDM4ZUe)])
	return eval (MHSngXbpVZde6NiQc9IrCxt78)
ObuCsdoDtKmhPLSMH8YGan,vbYokBuWlxeLDcdVNM60,J6jL2d7CKE0WA4lBXFPghR5eoxHb=Brz09AF6apy52OuEq1s,Brz09AF6apy52OuEq1s,Brz09AF6apy52OuEq1s
aNdix5gq7yeFHTMWhnzm8pX0Y16,dwiIAcPl04ey7Zv38Mz,zBGPHsxIiQmd7oTSORl9bAynr5kNq=J6jL2d7CKE0WA4lBXFPghR5eoxHb,vbYokBuWlxeLDcdVNM60,ObuCsdoDtKmhPLSMH8YGan
rbUkdYi32PJaRtnxhDvQs,TtyzcuW45VKA,LungQF89BqemOb32jJsZlW=zBGPHsxIiQmd7oTSORl9bAynr5kNq,dwiIAcPl04ey7Zv38Mz,aNdix5gq7yeFHTMWhnzm8pX0Y16
iRfoNckJs7Ibxzh5j92w8DSWF,NV3enkyQ7Rmp2LYAUagsCJz0ZP,HC9xWUMpBQJEuTteAqjd=LungQF89BqemOb32jJsZlW,TtyzcuW45VKA,rbUkdYi32PJaRtnxhDvQs
s8fcjBCSMxzAIkZQbJPga,AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu,liyzjA4RkEb1cT6fr5pGKdWNHOxM=HC9xWUMpBQJEuTteAqjd,NV3enkyQ7Rmp2LYAUagsCJz0ZP,iRfoNckJs7Ibxzh5j92w8DSWF
nfg30bHwd4aNV12SR7UjFck,Rsdai9xIEPcpuBMKOUwkTA05q,KNomgGw1kdMCBH=liyzjA4RkEb1cT6fr5pGKdWNHOxM,AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu,s8fcjBCSMxzAIkZQbJPga
SGazRxP3yBKZ15ILuch,YnHG75e2QWwo,S5fhsRT8JV=KNomgGw1kdMCBH,Rsdai9xIEPcpuBMKOUwkTA05q,nfg30bHwd4aNV12SR7UjFck
WupgNDhcjK1SiYsF5VLGb9w3loJqX,f8Ja1q5eO02B,xN4fKmsnyM3Y2=S5fhsRT8JV,YnHG75e2QWwo,SGazRxP3yBKZ15ILuch
uxE8MyoTRglrcaiQf,aar0zhDnJsOTP7EdgR16HIS29,opyTNwHgfqbZREWKU=xN4fKmsnyM3Y2,f8Ja1q5eO02B,WupgNDhcjK1SiYsF5VLGb9w3loJqX
On1WZJc6dtksqVNgSQ5GBAjuipe,AiCor1fIVTDxQUWwHe9vPR7,tRnTydV03Xfi7rbQ=opyTNwHgfqbZREWKU,aar0zhDnJsOTP7EdgR16HIS29,uxE8MyoTRglrcaiQf
LJPOQNK1mcG,k5oIaYyp2mnrLK49qhzS,zDek1IW37rq6UoKdwyRiAVpF=tRnTydV03Xfi7rbQ,AiCor1fIVTDxQUWwHe9vPR7,On1WZJc6dtksqVNgSQ5GBAjuipe
import xbmc as bu6LzUQF7K,re as ffUFBJQ57j2XgoGeOLn9uwpC,sys as sjVE6XGymcf09qbiKODZdAC,xbmcaddon as Ig8GNUwBHn72lT6,random as EduRM2WTj7xz1,os as YRESXadfbIy3khwqmL8WC,xbmcvfs as H15ZDhnyQCgS4RNGBaEA,time as bD7kJZhMCdaqF68P45KlNIgO1,pickle as HVnx1jUWs7KeqN256oG3QOct,zlib as Zh9o1Rjn0kBsmiCM4cEIa,xbmcgui as r8rEvwjH91KlNMhIZoAVdpRyWeDfcs,xbmcplugin as wOL0lMr7GN2XhT4sdzWSJxoEY,sqlite3 as IDjorYsAdihx7QK,traceback as tBFq6lJxpriTH8XsOEQA,threading as WKXryzPwpU1H354EJdCfZ6cBt,hashlib as Tzg4GiYf75ZCK6h1pVu,json as sJB3aL8gGVrRU
from dUqF7rBe81 import *
import USuRxnPlV5
UkXlAzsMcamKJrEIgnxi6bWh = ObuCsdoDtKmhPLSMH8YGan(u"ࠨࡎࡌࡆࡘࡕࡎࡆࠩ໓")
UMFLP95VOlxHTE = Ig8GNUwBHn72lT6.Addon().getAddonInfo(KNomgGw1kdMCBH(u"ࠩࡳࡥࡹ࡮ࠧ໔"))
Xvntl6cSi2NUDpOB = YRESXadfbIy3khwqmL8WC.path.join(UMFLP95VOlxHTE,SGazRxP3yBKZ15ILuch(u"ࠪࡴࡦࡩ࡫ࡢࡩࡨࡷࠬ໕"))
sjVE6XGymcf09qbiKODZdAC.path.append(Xvntl6cSi2NUDpOB)
Zcl1ozMwTy0DUB7VjvENKA9W8xGXH2 = bu6LzUQF7K.getInfoLabel(On1WZJc6dtksqVNgSQ5GBAjuipe(u"ࠦࡘࡿࡳࡵࡧࡰ࠲ࡇࡻࡩ࡭ࡦ࡙ࡩࡷࡹࡩࡰࡰࠥ໖"))
m4PjYkEqLcJh = ffUFBJQ57j2XgoGeOLn9uwpC.findall(liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠬ࠮࡜ࡥ࡞ࡧࡠ࠳ࡢࡤࠪࠩ໗"),Zcl1ozMwTy0DUB7VjvENKA9W8xGXH2,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
m4PjYkEqLcJh = float(m4PjYkEqLcJh[nnsBpJv6XL3OzHoe4Vuhr])
zDsmTbwF7f = bu6LzUQF7K.Player
zz6bHTRC0W8DLnMsJ = r8rEvwjH91KlNMhIZoAVdpRyWeDfcs.WindowXMLDialog
xicJPb0AW1nsRfH3kCv7 = m4PjYkEqLcJh<rbUkdYi32PJaRtnxhDvQs(u"࠳࠼ᄙ")
W5domCu6XrQUFkiPpa3bNLtHglG = m4PjYkEqLcJh>AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"࠴࠼࠳࠿࠹ᄚ")
if W5domCu6XrQUFkiPpa3bNLtHglG:
	Guv20aFQAmLeSWXINPgKYf = H15ZDhnyQCgS4RNGBaEA.translatePath(nfg30bHwd4aNV12SR7UjFck(u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱ࡻࡦࡲࡩࠧ໘"))
	fgKMGTAVH7FP63cRlUoqC = bu6LzUQF7K.LOGINFO
	AJNSwOflIdq,vuUhZiIkAo7CRpjaEr = WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࡵࠨ࡞ࡸ࠶࠵࠸ࡡࠨ໙"),zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"ࡶࠩ࡟ࡹ࠷࠶࠲ࡣࠩ໚")
	xxVoM7bOsX5KHE2FTcheLlDYP6rU = H15ZDhnyQCgS4RNGBaEA.translatePath(opyTNwHgfqbZREWKU(u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴ࡺࡥ࡮ࡲࠪ໛"))
	from urllib.parse import unquote as _tk9TQu8dMGia0qo257yUK
	LOHk1qjzprdhSBMYx7WAfaP = iRfoNckJs7Ibxzh5j92w8DSWF(u"ࡸࠫࡡࡻ࠰࠳ࡦ࠴ࠫໜ")
else:
	Guv20aFQAmLeSWXINPgKYf = bu6LzUQF7K.translatePath(tRnTydV03Xfi7rbQ(u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯ࡹࡤࡰࡧࠬໝ"))
	fgKMGTAVH7FP63cRlUoqC = bu6LzUQF7K.LOGNOTICE
	AJNSwOflIdq,vuUhZiIkAo7CRpjaEr = AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"ࡺ࠭࡜ࡶ࠴࠳࠶ࡦ࠭ໞ").encode(vczMIlkCAh2u10B3),NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࡻࠧ࡝ࡷ࠵࠴࠷ࡨࠧໟ").encode(vczMIlkCAh2u10B3)
	xxVoM7bOsX5KHE2FTcheLlDYP6rU = bu6LzUQF7K.translatePath(zDek1IW37rq6UoKdwyRiAVpF(u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲ࡸࡪࡳࡰࠨ໠"))
	from urllib import unquote as _tk9TQu8dMGia0qo257yUK
	LOHk1qjzprdhSBMYx7WAfaP = KNomgGw1kdMCBH(u"ࡶࠩ࡟ࡹ࠵࠸ࡤ࠲ࠩ໡").encode(vczMIlkCAh2u10B3)
pzPE1fgqrkbQOXBmc = sjVE6XGymcf09qbiKODZdAC.argv[nnsBpJv6XL3OzHoe4Vuhr].split(KCQExdbYFqM)[bVX3ev1spE]
p4TcbiqOXVAyILxQJa1Ks8f5 = int(sjVE6XGymcf09qbiKODZdAC.argv[hiuZa0PIsErm6UC7])
I4sncq6lxyDa03Gr5B = sjVE6XGymcf09qbiKODZdAC.argv[bVX3ev1spE]
VUcr0IxWl2aD6OmB14dPqgYRZbnk = pzPE1fgqrkbQOXBmc.split(On1WZJc6dtksqVNgSQ5GBAjuipe(u"ࠩ࠱ࠫ໢"))[bVX3ev1spE]
cWEA5yRl3VqGKk = bu6LzUQF7K.getInfoLabel(vbYokBuWlxeLDcdVNM60(u"ࠪࡗࡾࡹࡴࡦ࡯࠱ࡅࡩࡪ࡯࡯ࡘࡨࡶࡸ࡯࡯࡯ࠪࠪ໣")+pzPE1fgqrkbQOXBmc+LungQF89BqemOb32jJsZlW(u"ࠫ࠮࠭໤"))
qq9xw1jKIVH5kuNGMsPLiCO6Rp0Zv = YRESXadfbIy3khwqmL8WC.path.join(xxVoM7bOsX5KHE2FTcheLlDYP6rU,pzPE1fgqrkbQOXBmc)
K5pmHUNSMri7k = YRESXadfbIy3khwqmL8WC.path.join(qq9xw1jKIVH5kuNGMsPLiCO6Rp0Zv,vbYokBuWlxeLDcdVNM60(u"ࠬ࡯࡭ࡢࡩࡨࡷࠬ໥"))
rr6bRWx70ZNIz = YRESXadfbIy3khwqmL8WC.path.join(K5pmHUNSMri7k,AiCor1fIVTDxQUWwHe9vPR7(u"࠭࡮ࡰࡶ࡬ࡪ࡮ࡩࡡࡵ࡫ࡲࡲࡸ࠭໦"))
puT2ekRWZ0 = YRESXadfbIy3khwqmL8WC.path.join(K5pmHUNSMri7k,liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠧࡥ࡫ࡤࡰࡴ࡭ࡳࠨ໧"))
IEYRiWjro7qxBZcyOdku8 = YRESXadfbIy3khwqmL8WC.path.join(puT2ekRWZ0,xN4fKmsnyM3Y2(u"ࠨࡦ࡬ࡥࡱࡵࡧࡠ࠲࠳࠴࠵ࡥ࠮ࡱࡰࡪࠫ໨"))
q3HOmNndw1KJ5MepkaLfYj0XVZzuxQ = YRESXadfbIy3khwqmL8WC.path.join(Guv20aFQAmLeSWXINPgKYf,uxE8MyoTRglrcaiQf(u"ࠩࡰࡩࡩ࡯ࡡࠨ໩"),f8Ja1q5eO02B(u"ࠪࡊࡴࡴࡴࡴࠩ໪"),AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"ࠫࡦࡸࡩࡢ࡮࠱ࡸࡹ࡬ࠧ໫"))
TV08xYHA2ok = YRESXadfbIy3khwqmL8WC.path.join(qq9xw1jKIVH5kuNGMsPLiCO6Rp0Zv,aar0zhDnJsOTP7EdgR16HIS29(u"ࠬࡳࡡࡪࡰࡧࡥࡹࡧ࠮ࡥࡤࠪ໬"))
S93PERpNHcQlu1gKyAFr = YRESXadfbIy3khwqmL8WC.path.join(qq9xw1jKIVH5kuNGMsPLiCO6Rp0Zv,ObuCsdoDtKmhPLSMH8YGan(u"࠭࡬ࡢࡵࡷࡺ࡮ࡪࡥࡰࡵ࠱ࡨࡦࡺࠧ໭"))
UMFLP95VOlxHTE = Ig8GNUwBHn72lT6.Addon().getAddonInfo(NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠧࡱࡣࡷ࡬ࠬ໮"))
OOAXyCbfeiEMKDPvmn1wrQWUGkcV = YRESXadfbIy3khwqmL8WC.path.join(UMFLP95VOlxHTE,KNomgGw1kdMCBH(u"ࠨ࡯ࡨࡲࡺࡥࡲࡦࡦࡢ࠶࠵࠶ࡸ࠳࠷࠳࠲ࡵࡴࡧࠨ໯"))
BbIVuS4KecnqNvZz5GptR = int(bD7kJZhMCdaqF68P45KlNIgO1.time())
Hgmcv0pjTFoGRLXdiP4rKSzs2Ab = Ig8GNUwBHn72lT6.Addon(id=pzPE1fgqrkbQOXBmc)
T6aPJAChywzn0L81VsoD3Om = Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.getSetting(LJPOQNK1mcG(u"ࠩࡤࡺ࠳ࡼࡥࡳࡵ࡬ࡳࡳ࠭໰"))
qqYeaz369sxbmjwviyhrQTC1 = ksTLSoVGg0ht if T6aPJAChywzn0L81VsoD3Om==cWEA5yRl3VqGKk else IZQbmFzLHDtXfc
def sRAznbuQ5jiN09o4V8tpEYSlG7fe(mrcsT4vGxI6o7PMayUkHdtEZXB,YlVJ4IRmk3vWf9S0rP7dMpK=vbYokBuWlxeLDcdVNM60(u"ࠪࡃࠬ໱")):
	if liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠫࡂ࠭໲") in mrcsT4vGxI6o7PMayUkHdtEZXB:
		if YlVJ4IRmk3vWf9S0rP7dMpK in mrcsT4vGxI6o7PMayUkHdtEZXB: HOCWKhxITtulVGX,xxpZCFqbR508EVmQaIjtuWKh = mrcsT4vGxI6o7PMayUkHdtEZXB.split(YlVJ4IRmk3vWf9S0rP7dMpK,s8fcjBCSMxzAIkZQbJPga(u"࠵ᄛ"))
		else: HOCWKhxITtulVGX,xxpZCFqbR508EVmQaIjtuWKh = cdZKMn68Pzg4,mrcsT4vGxI6o7PMayUkHdtEZXB
		xxpZCFqbR508EVmQaIjtuWKh = xxpZCFqbR508EVmQaIjtuWKh.split(AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"ࠬࠬࠧ໳"))
		H3F607d1jsXEnMvor2 = {}
		for InxA5F4eoY in xxpZCFqbR508EVmQaIjtuWKh:
			oOsyIY7xpniWZ62HXQgPrw10V,sLhEnc4bqKSNCYwHAxFPQUZiW = InxA5F4eoY.split(liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"࠭࠽ࠨ໴"),NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"࠶ᄜ"))
			H3F607d1jsXEnMvor2[oOsyIY7xpniWZ62HXQgPrw10V] = sLhEnc4bqKSNCYwHAxFPQUZiW
	else: HOCWKhxITtulVGX,H3F607d1jsXEnMvor2 = mrcsT4vGxI6o7PMayUkHdtEZXB,{}
	return HOCWKhxITtulVGX,H3F607d1jsXEnMvor2
def khTjKWeG8r7nyuS1Dwdq2g06l5soi(YkqWMTnVUjh1rQaXpG8LR7xo):
	iOfP6eYgXJjLFImR5wN8,xgPSaoLzTlFtQD37M6HIEsWY,QZLNPEgHc39SBIXGq1FbKmyuoi7Rx = cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4
	YkqWMTnVUjh1rQaXpG8LR7xo = YkqWMTnVUjh1rQaXpG8LR7xo.replace(AJNSwOflIdq,cdZKMn68Pzg4).replace(vuUhZiIkAo7CRpjaEr,cdZKMn68Pzg4)
	a6ihlXO2CxHKrTuoknwzQ3cPBNGULj = ffUFBJQ57j2XgoGeOLn9uwpC.findall(AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"ࠧࠩ࠰ࠬࡠࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆ࠱࠺ࡆ࠵ࡋࡢ࡝ࠩ࡞ࡺࡠࡼࡢࡷࠪࠢ࠮ࡠࡠࡢ࠯ࡄࡑࡏࡓࡗࡢ࡝ࠩ࠰࠭ࡃ࠮ࠪࠧ໵"),YkqWMTnVUjh1rQaXpG8LR7xo,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if a6ihlXO2CxHKrTuoknwzQ3cPBNGULj: iOfP6eYgXJjLFImR5wN8,xgPSaoLzTlFtQD37M6HIEsWY,YkqWMTnVUjh1rQaXpG8LR7xo = a6ihlXO2CxHKrTuoknwzQ3cPBNGULj[nnsBpJv6XL3OzHoe4Vuhr]
	if iOfP6eYgXJjLFImR5wN8 not in [VBpIH2QSmvDGlA6TO3e,AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"ࠨ࠮ࠪ໶"),cdZKMn68Pzg4]: QZLNPEgHc39SBIXGq1FbKmyuoi7Rx = liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠩࡢࡑࡔࡊ࡟ࠨ໷")
	if xgPSaoLzTlFtQD37M6HIEsWY: xgPSaoLzTlFtQD37M6HIEsWY = dwiIAcPl04ey7Zv38Mz(u"ࠪࡣࠬ໸")+xgPSaoLzTlFtQD37M6HIEsWY+xN4fKmsnyM3Y2(u"ࠫࡤ࠭໹")
	YkqWMTnVUjh1rQaXpG8LR7xo = xgPSaoLzTlFtQD37M6HIEsWY+QZLNPEgHc39SBIXGq1FbKmyuoi7Rx+YkqWMTnVUjh1rQaXpG8LR7xo
	return YkqWMTnVUjh1rQaXpG8LR7xo
def NLqxoZ37dYf0awrsIE(mrcsT4vGxI6o7PMayUkHdtEZXB):
	return _tk9TQu8dMGia0qo257yUK(mrcsT4vGxI6o7PMayUkHdtEZXB)
def AanhLX36W9emBvK(GVTFLUQSl047tf625K8Hmb):
	Mwq4Li3zrua2t7TfA1PpR = {TtyzcuW45VKA(u"ࠬࡺࡹࡱࡧࠪ໺"):cdZKMn68Pzg4,HC9xWUMpBQJEuTteAqjd(u"࠭࡭ࡰࡦࡨࠫ໻"):cdZKMn68Pzg4,s8fcjBCSMxzAIkZQbJPga(u"ࠧࡶࡴ࡯ࠫ໼"):cdZKMn68Pzg4,AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"ࠨࡶࡨࡼࡹ࠭໽"):cdZKMn68Pzg4,k5oIaYyp2mnrLK49qhzS(u"ࠩࡳࡥ࡬࡫ࠧ໾"):cdZKMn68Pzg4,vbYokBuWlxeLDcdVNM60(u"ࠪࡲࡦࡳࡥࠨ໿"):cdZKMn68Pzg4,S5fhsRT8JV(u"ࠫ࡮ࡳࡡࡨࡧࠪༀ"):cdZKMn68Pzg4,tRnTydV03Xfi7rbQ(u"ࠬࡩ࡯࡯ࡶࡨࡼࡹ࠭༁"):cdZKMn68Pzg4,SGazRxP3yBKZ15ILuch(u"࠭ࡩ࡯ࡨࡲࡨ࡮ࡩࡴࠨ༂"):cdZKMn68Pzg4}
	if LungQF89BqemOb32jJsZlW(u"ࠧࡀࠩ༃") in GVTFLUQSl047tf625K8Hmb: GVTFLUQSl047tf625K8Hmb = GVTFLUQSl047tf625K8Hmb.split(LJPOQNK1mcG(u"ࠨࡁࠪ༄"),hiuZa0PIsErm6UC7)[hiuZa0PIsErm6UC7]
	HOCWKhxITtulVGX,AgnjU7X3pHWv = sRAznbuQ5jiN09o4V8tpEYSlG7fe(GVTFLUQSl047tf625K8Hmb)
	aargs = dict(list(Mwq4Li3zrua2t7TfA1PpR.items())+list(AgnjU7X3pHWv.items()))
	f9DvgICeo3cRUm = aargs[LJPOQNK1mcG(u"ࠩࡰࡳࡩ࡫ࠧ༅")]
	cLywUFSIArgjp829GJTo4nYa13CMB = NLqxoZ37dYf0awrsIE(aargs[xN4fKmsnyM3Y2(u"ࠪࡹࡷࡲࠧ༆")])
	CgFsni9VKJW8 = NLqxoZ37dYf0awrsIE(aargs[s8fcjBCSMxzAIkZQbJPga(u"ࠫࡹ࡫ࡸࡵࠩ༇")])
	WVis1E80CcAGxM = NLqxoZ37dYf0awrsIE(aargs[TtyzcuW45VKA(u"ࠬࡶࡡࡨࡧࠪ༈")])
	Lg45ZyFwYWMQHN7pon82cIz = NLqxoZ37dYf0awrsIE(aargs[iRfoNckJs7Ibxzh5j92w8DSWF(u"࠭ࡴࡺࡲࡨࠫ༉")])
	OkYLqZdu90NAfWbwKB = NLqxoZ37dYf0awrsIE(aargs[KNomgGw1kdMCBH(u"ࠧ࡯ࡣࡰࡩࠬ༊")])
	uuB4WbfiKoQrN3xzjZMO = NLqxoZ37dYf0awrsIE(aargs[NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠨ࡫ࡰࡥ࡬࡫ࠧ་")])
	tFQjLDJuVIAh52dk7v = aargs[NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠩࡦࡳࡳࡺࡥࡹࡶࠪ༌")]
	tE73rIUmbG = NLqxoZ37dYf0awrsIE(aargs[Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠪ࡭ࡳ࡬࡯ࡥ࡫ࡦࡸࠬ།")])
	if tE73rIUmbG: tE73rIUmbG = eval(tE73rIUmbG)
	else: tE73rIUmbG = {}
	if not f9DvgICeo3cRUm: Lg45ZyFwYWMQHN7pon82cIz = iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ༎") ; f9DvgICeo3cRUm = S5fhsRT8JV(u"ࠬ࠸࠶࠱ࠩ༏")
	return wrcgBRto5yMTdbhZLfzKe1UOpVSmYH(Lg45ZyFwYWMQHN7pon82cIz,OkYLqZdu90NAfWbwKB,cLywUFSIArgjp829GJTo4nYa13CMB,f9DvgICeo3cRUm,uuB4WbfiKoQrN3xzjZMO,WVis1E80CcAGxM,CgFsni9VKJW8,tFQjLDJuVIAh52dk7v,tE73rIUmbG)
def xxd7Xp5lvem(UkXlAzsMcamKJrEIgnxi6bWh):
	fdslxK1LMhIuXaYA7 = sjVE6XGymcf09qbiKODZdAC._getframe(hiuZa0PIsErm6UC7).f_code.co_name
	if not UkXlAzsMcamKJrEIgnxi6bWh or not fdslxK1LMhIuXaYA7 or fdslxK1LMhIuXaYA7==opyTNwHgfqbZREWKU(u"࠭࠼࡮ࡱࡧࡹࡱ࡫࠾ࠨ༐"):
		return tRnTydV03Xfi7rbQ(u"ࠧ࡜ࠢࠪ༑")+VUcr0IxWl2aD6OmB14dPqgYRZbnk.upper()+zDek1IW37rq6UoKdwyRiAVpF(u"ࠨࡡࠪ༒")+cWEA5yRl3VqGKk+J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠩࡢࠫ༓")+str(m4PjYkEqLcJh)+zDek1IW37rq6UoKdwyRiAVpF(u"ࠪࠤࡢ࠭༔")
	return HC9xWUMpBQJEuTteAqjd(u"ࠫ࠳ࡢࡴࠨ༕")+fdslxK1LMhIuXaYA7
def SsziMZd5UbeL2NRxVpwjO(Y6Vsty3Mv2fRSFT5aKiCwE,o5ozZilpaquwTYdWS3H1XmcJDG=cdZKMn68Pzg4):
	if not o5ozZilpaquwTYdWS3H1XmcJDG: Y6Vsty3Mv2fRSFT5aKiCwE,o5ozZilpaquwTYdWS3H1XmcJDG = cdZKMn68Pzg4,Y6Vsty3Mv2fRSFT5aKiCwE
	for DQ3SK1NdV8fCP in hyVgRdxpOwil:
		if DQ3SK1NdV8fCP in o5ozZilpaquwTYdWS3H1XmcJDG: o5ozZilpaquwTYdWS3H1XmcJDG = o5ozZilpaquwTYdWS3H1XmcJDG.replace(DQ3SK1NdV8fCP,cdZKMn68Pzg4)
	o5ozZilpaquwTYdWS3H1XmcJDG = o5ozZilpaquwTYdWS3H1XmcJDG.replace(TtyzcuW45VKA(u"ࠬࡢࡸ࠱࠲ࠪ༖"),cdZKMn68Pzg4)
	if xicJPb0AW1nsRfH3kCv7:
		try: o5ozZilpaquwTYdWS3H1XmcJDG = o5ozZilpaquwTYdWS3H1XmcJDG.decode(vczMIlkCAh2u10B3,Rsdai9xIEPcpuBMKOUwkTA05q(u"࠭ࡩࡨࡰࡲࡶࡪ࠭༗")).encode(vczMIlkCAh2u10B3,iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠧࡪࡩࡱࡳࡷ࡫༘ࠧ"))
		except: o5ozZilpaquwTYdWS3H1XmcJDG = o5ozZilpaquwTYdWS3H1XmcJDG.encode(vczMIlkCAh2u10B3,ObuCsdoDtKmhPLSMH8YGan(u"ࠨ࡫ࡪࡲࡴࡸࡥࠨ༙"))
	gNbtrvKAnP = fgKMGTAVH7FP63cRlUoqC
	LrPZs7iUEO9AkKV4gfIcoxQqn2 = [cdZKMn68Pzg4,cdZKMn68Pzg4]
	if Y6Vsty3Mv2fRSFT5aKiCwE: o5ozZilpaquwTYdWS3H1XmcJDG = o5ozZilpaquwTYdWS3H1XmcJDG.replace(bxf7gZvNK29cEoiAIJlMq0dP,cdZKMn68Pzg4).replace(Gzygq01Kcb9U3,cdZKMn68Pzg4).replace(kH8E2zqNyims6KJfI,cdZKMn68Pzg4)
	else: Y6Vsty3Mv2fRSFT5aKiCwE = F0FeocLXmbJhdBwQnS18PCHZIU
	GDKjYhWBNRseImO9lfrcAwVxJZ,YlVJ4IRmk3vWf9S0rP7dMpK = xN4fKmsnyM3Y2(u"ࠩ࡟ࡸࠬ༚"),U4ImogGksPlcBVfAb
	fSi9LEm3yVXoeaNUrvp5Y1DCkW = zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"࠴࠳ᄞ")*VBpIH2QSmvDGlA6TO3e if W5domCu6XrQUFkiPpa3bNLtHglG else iRfoNckJs7Ibxzh5j92w8DSWF(u"࠹࠱ᄝ")*VBpIH2QSmvDGlA6TO3e
	FvTLDBMiwGtQNg8J9O70Cy = iwQJREcVTSe1G2gCvlfhbHWLjqopa*GDKjYhWBNRseImO9lfrcAwVxJZ
	if o5ozZilpaquwTYdWS3H1XmcJDG.startswith(YnHG75e2QWwo(u"ࠪࡓࡕࡋࡎࡖࡔࡏࠫ༛")): o5ozZilpaquwTYdWS3H1XmcJDG = J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠫ࠳ࡢࡴࠨ༜")+o5ozZilpaquwTYdWS3H1XmcJDG
	if z0KNn8M5AxaD in Y6Vsty3Mv2fRSFT5aKiCwE: gNbtrvKAnP = bu6LzUQF7K.LOGERROR
	if Y6Vsty3Mv2fRSFT5aKiCwE in [F0FeocLXmbJhdBwQnS18PCHZIU,z0KNn8M5AxaD]: LrPZs7iUEO9AkKV4gfIcoxQqn2 = [o5ozZilpaquwTYdWS3H1XmcJDG]
	elif Y6Vsty3Mv2fRSFT5aKiCwE==E7lrS9VXJF58d2NUAfkvxwjmHM: LrPZs7iUEO9AkKV4gfIcoxQqn2 = o5ozZilpaquwTYdWS3H1XmcJDG.split(YlVJ4IRmk3vWf9S0rP7dMpK)
	elif Y6Vsty3Mv2fRSFT5aKiCwE==Q2QMvk3bx0CGJWSUwD:
		yYh4LlNT0HxR = o5ozZilpaquwTYdWS3H1XmcJDG.split(YlVJ4IRmk3vWf9S0rP7dMpK)
		LrPZs7iUEO9AkKV4gfIcoxQqn2 = [yYh4LlNT0HxR[nnsBpJv6XL3OzHoe4Vuhr]]
		for PC2J91Vyhn0GomBjp6K5clftAiYg in range(hiuZa0PIsErm6UC7,len(yYh4LlNT0HxR),bVX3ev1spE):
			try: kc1o6tS8F9iby05eKxNHf = yYh4LlNT0HxR[PC2J91Vyhn0GomBjp6K5clftAiYg]+YlVJ4IRmk3vWf9S0rP7dMpK+yYh4LlNT0HxR[PC2J91Vyhn0GomBjp6K5clftAiYg+iRfoNckJs7Ibxzh5j92w8DSWF(u"࠲ᄟ")]
			except: kc1o6tS8F9iby05eKxNHf = yYh4LlNT0HxR[PC2J91Vyhn0GomBjp6K5clftAiYg]
			LrPZs7iUEO9AkKV4gfIcoxQqn2.append(kc1o6tS8F9iby05eKxNHf)
	WQ9xyruwNvSmobYZJdezjPFa4AOXB = LrPZs7iUEO9AkKV4gfIcoxQqn2[nnsBpJv6XL3OzHoe4Vuhr]
	for B7BCZd9b65Ro3OTWhgSJD in LrPZs7iUEO9AkKV4gfIcoxQqn2[hiuZa0PIsErm6UC7:]:
		if Y6Vsty3Mv2fRSFT5aKiCwE in [E7lrS9VXJF58d2NUAfkvxwjmHM,Q2QMvk3bx0CGJWSUwD]: FvTLDBMiwGtQNg8J9O70Cy += GDKjYhWBNRseImO9lfrcAwVxJZ
		WQ9xyruwNvSmobYZJdezjPFa4AOXB += CPjOZMmw8sfGg2B9LthIdXa1iKQUF+fSi9LEm3yVXoeaNUrvp5Y1DCkW+FvTLDBMiwGtQNg8J9O70Cy+B7BCZd9b65Ro3OTWhgSJD
	if Y6Vsty3Mv2fRSFT5aKiCwE in [z0KNn8M5AxaD,E7lrS9VXJF58d2NUAfkvxwjmHM]: WQ9xyruwNvSmobYZJdezjPFa4AOXB += ssELJkeScrtni2
	WQ9xyruwNvSmobYZJdezjPFa4AOXB += k5oIaYyp2mnrLK49qhzS(u"ࠬࠦ࡟ࠨ༝")
	if On1WZJc6dtksqVNgSQ5GBAjuipe(u"࠭ࠥࠨ༞") in WQ9xyruwNvSmobYZJdezjPFa4AOXB: WQ9xyruwNvSmobYZJdezjPFa4AOXB = NLqxoZ37dYf0awrsIE(WQ9xyruwNvSmobYZJdezjPFa4AOXB)
	bu6LzUQF7K.log(WQ9xyruwNvSmobYZJdezjPFa4AOXB,level=gNbtrvKAnP)
	return
def ehTmLt7VvnGuMZcDNQi5YOBoIaqj(s45iIBkQuHKTpcOoGCFYwNW):
	try: ZZ9aGOKsMrV0nto8v5LNwCcHR = IDjorYsAdihx7QK.connect(s45iIBkQuHKTpcOoGCFYwNW,check_same_thread=ksTLSoVGg0ht)
	except:
		if not YRESXadfbIy3khwqmL8WC.path.exists(qq9xw1jKIVH5kuNGMsPLiCO6Rp0Zv):
			YRESXadfbIy3khwqmL8WC.makedirs(qq9xw1jKIVH5kuNGMsPLiCO6Rp0Zv)
			ZZ9aGOKsMrV0nto8v5LNwCcHR = IDjorYsAdihx7QK.connect(s45iIBkQuHKTpcOoGCFYwNW,check_same_thread=ksTLSoVGg0ht)
	ZZ9aGOKsMrV0nto8v5LNwCcHR.text_factory = str
	yjNYCMFrPXpAoZHGe7iUJ25g = ZZ9aGOKsMrV0nto8v5LNwCcHR.cursor()
	yjNYCMFrPXpAoZHGe7iUJ25g.execute(f8Ja1q5eO02B(u"ࠧࡑࡔࡄࡋࡒࡇࠠࡢࡷࡷࡳࡲࡧࡴࡪࡥࡢ࡭ࡳࡪࡥࡹ࠿ࡱࡳࠥࡁࠧ༟"))
	yjNYCMFrPXpAoZHGe7iUJ25g.execute(LungQF89BqemOb32jJsZlW(u"ࠨࡒࡕࡅࡌࡓࡁࠡ࡫ࡪࡲࡴࡸࡥࡠࡥ࡫ࡩࡨࡱ࡟ࡤࡱࡱࡷࡹࡸࡡࡪࡰࡷࡷࡂࡿࡥࡴࠢ࠾ࠫ༠"))
	yjNYCMFrPXpAoZHGe7iUJ25g.execute(uxE8MyoTRglrcaiQf(u"ࠩࡓࡖࡆࡍࡍࡂࠢ࡭ࡳࡺࡸ࡮ࡢ࡮ࡢࡱࡴࡪࡥ࠾ࡑࡉࡊࠥࡁࠧ༡"))
	yjNYCMFrPXpAoZHGe7iUJ25g.execute(f8Ja1q5eO02B(u"ࠪࡔࡗࡇࡇࡎࡃࠣࡷࡾࡴࡣࡩࡴࡲࡲࡴࡻࡳ࠾ࡑࡉࡊࠥࡁࠧ༢"))
	ZZ9aGOKsMrV0nto8v5LNwCcHR.commit()
	return ZZ9aGOKsMrV0nto8v5LNwCcHR,yjNYCMFrPXpAoZHGe7iUJ25g
def MMPNsJSHhcbFTukwK2UOv1Bexig(s45iIBkQuHKTpcOoGCFYwNW,ZZ9aGOKsMrV0nto8v5LNwCcHR,yjNYCMFrPXpAoZHGe7iUJ25g,ED4CuseaJq0UMvLxjB,i0vyQgGXS9c2UfRoOHm4,zEDnLXu9epYUdJtsO=()):
	BbsTmRndZaLY69 = RRAmELdrBNQGixkaTlC8ozVFe
	timeout = TtyzcuW45VKA(u"࠳࠳ᄠ")
	wjtpPgdThJvk8SLumnKeZEQGiAOzVs = bD7kJZhMCdaqF68P45KlNIgO1.time()
	import WgvHc7lhSL
	while bD7kJZhMCdaqF68P45KlNIgO1.time()-wjtpPgdThJvk8SLumnKeZEQGiAOzVs<timeout:
		try:
			if ED4CuseaJq0UMvLxjB: BbsTmRndZaLY69 = yjNYCMFrPXpAoZHGe7iUJ25g.executemany(i0vyQgGXS9c2UfRoOHm4,zEDnLXu9epYUdJtsO).fetchall()
			else: BbsTmRndZaLY69 = yjNYCMFrPXpAoZHGe7iUJ25g.execute(i0vyQgGXS9c2UfRoOHm4,zEDnLXu9epYUdJtsO).fetchall()
			break
		except Exception as BJYR6A1DrHTcvLjsEi:
			if nfg30bHwd4aNV12SR7UjFck(u"ࠫࡩࡧࡴࡢࡤࡤࡷࡪࠦࡩࡴࠢ࡯ࡳࡨࡱࡥࡥࠩ༣") not in str(BJYR6A1DrHTcvLjsEi): break
		SsziMZd5UbeL2NRxVpwjO(E7lrS9VXJF58d2NUAfkvxwjmHM,aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠬ࠴࡜ࡵࡆࡤࡸࡦࡨࡡࡴࡧࠣࡪ࡮ࡲࡥࠡ࡫ࡶࠤࡱࡵࡣ࡬ࡧࡧࠤࠥࠦࠧ༤")+s45iIBkQuHKTpcOoGCFYwNW+zDek1IW37rq6UoKdwyRiAVpF(u"࠭ࠠࠡࠢࡉࡥ࡮ࡲࡥࡥࠢࡺ࡬ࡪࡴࠠࡦࡺࡨࡧࡺࡺࡩ࡯ࡩࠣࡸ࡭࡯ࡳࠡࡵࡷࡥࡹ࡫࡭ࡦࡰࡷࠤࠥࠦࠧ༥")+i0vyQgGXS9c2UfRoOHm4)
		ZZ9aGOKsMrV0nto8v5LNwCcHR.commit()
		bD7kJZhMCdaqF68P45KlNIgO1.sleep(liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"࠳࠲࠷࠻ᄡ"))
	ZZ9aGOKsMrV0nto8v5LNwCcHR.commit()
	return BbsTmRndZaLY69
def HLsnzXl78kB6(s45iIBkQuHKTpcOoGCFYwNW,vuqDWMFGiskPfR63oT1,AmD0xYsJtIk):
	return sZHYrLPog4wmuW0ECdc(s45iIBkQuHKTpcOoGCFYwNW,vuqDWMFGiskPfR63oT1,AmD0xYsJtIk)
def lvixjcs4fRrU(s45iIBkQuHKTpcOoGCFYwNW,AmD0xYsJtIk,MEPG5qxAezuhrZ4KB7jS0Jy9FQLHC,QQXRbAf4a3G69UoZKBgp2djzP,URYriT0y4bI37pDG62lo):
	return uAkLQ7gEZaIBv6Fyn(s45iIBkQuHKTpcOoGCFYwNW,AmD0xYsJtIk,MEPG5qxAezuhrZ4KB7jS0Jy9FQLHC,QQXRbAf4a3G69UoZKBgp2djzP,URYriT0y4bI37pDG62lo,IZQbmFzLHDtXfc)
def sZHYrLPog4wmuW0ECdc(s45iIBkQuHKTpcOoGCFYwNW,vuqDWMFGiskPfR63oT1,AmD0xYsJtIk,aaVB0MUdD9fb=RRAmELdrBNQGixkaTlC8ozVFe):
	oGBLR5vmhyqPrKaECQSi67wTF2Z1uM = HMxzS0Jf69trLk(vuqDWMFGiskPfR63oT1)
	y0p7QGRembk5O1iIZt = Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.getSetting(WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡧࡦࡩࡨࡦࠩ༦"))
	if AmD0xYsJtIk not in [TtyzcuW45VKA(u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫ༧"),AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"ࠩࡊࡐࡔࡈࡁࡍࡕࡈࡅࡗࡉࡈࡠࡕࡓࡐࡎ࡚ࡔࡆࡆࡢࡅࡑࡒࠧ༨"),J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠪࡋࡑࡕࡂࡂࡎࡖࡉࡆࡘࡃࡉࡡࡖࡔࡑࡏࡔࡕࡇࡇࡣࡌࡕࡏࡈࡎࡈࠫ༩")] and s45iIBkQuHKTpcOoGCFYwNW==TV08xYHA2ok and aaVB0MUdD9fb!=zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"ࠫࡒࡋࡓࡔࡃࡊࡉࡘ࠭༪"):
		if y0p7QGRembk5O1iIZt==SGazRxP3yBKZ15ILuch(u"࡙ࠬࡔࡐࡒࠪ༫"): return oGBLR5vmhyqPrKaECQSi67wTF2Z1uM
		HOPNDidJLzCxeK7IXS = Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.getSetting(aar0zhDnJsOTP7EdgR16HIS29(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡵࡩ࡫ࡸࡥࡴࡪࠪ༬"))
		if HOPNDidJLzCxeK7IXS==Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠧࡓࡇࡉࡖࡊ࡙ࡈࡠࡅࡄࡇࡍࡋࠧ༭"):
			uVOoSHfqe4WtiF(s45iIBkQuHKTpcOoGCFYwNW,AmD0xYsJtIk,aaVB0MUdD9fb)
			return oGBLR5vmhyqPrKaECQSi67wTF2Z1uM
	tArkG4VWBTixzndNE = nnsBpJv6XL3OzHoe4Vuhr
	if y0p7QGRembk5O1iIZt==vbYokBuWlxeLDcdVNM60(u"ࠨࡎࡌࡑࡎ࡚ࡅࡅࠩ༮"): tArkG4VWBTixzndNE = kZK9jh5ufsoVAmxreYPbyUaR7I0LO
	ZZ9aGOKsMrV0nto8v5LNwCcHR,yjNYCMFrPXpAoZHGe7iUJ25g = ehTmLt7VvnGuMZcDNQi5YOBoIaqj(s45iIBkQuHKTpcOoGCFYwNW)
	if tArkG4VWBTixzndNE: BbsTmRndZaLY69 = MMPNsJSHhcbFTukwK2UOv1Bexig(s45iIBkQuHKTpcOoGCFYwNW,ZZ9aGOKsMrV0nto8v5LNwCcHR,yjNYCMFrPXpAoZHGe7iUJ25g,ksTLSoVGg0ht,vbYokBuWlxeLDcdVNM60(u"ࠩࡇࡉࡑࡋࡔࡆࠢࡉࡖࡔࡓࠠࠣࠩ༯")+AmD0xYsJtIk+xN4fKmsnyM3Y2(u"ࠪࠦࠥ࡝ࡈࡆࡔࡈࠤࡪࡾࡰࡪࡴࡼࡂࠬ༰")+str(BbIVuS4KecnqNvZz5GptR+tArkG4VWBTixzndNE)+zDek1IW37rq6UoKdwyRiAVpF(u"ࠫࠥࡁࠧ༱"))
	BbsTmRndZaLY69 = MMPNsJSHhcbFTukwK2UOv1Bexig(s45iIBkQuHKTpcOoGCFYwNW,ZZ9aGOKsMrV0nto8v5LNwCcHR,yjNYCMFrPXpAoZHGe7iUJ25g,ksTLSoVGg0ht,liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࠦࠬ༲")+AmD0xYsJtIk+NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"࡙࠭ࠢࠡࡋࡉࡗࡋࠠࡦࡺࡳ࡭ࡷࡿ࠼ࠨ༳")+str(BbIVuS4KecnqNvZz5GptR)+aar0zhDnJsOTP7EdgR16HIS29(u"ࠧࠡ࠽ࠪ༴"))
	if aaVB0MUdD9fb:
		BbsTmRndZaLY69 = MMPNsJSHhcbFTukwK2UOv1Bexig(s45iIBkQuHKTpcOoGCFYwNW,ZZ9aGOKsMrV0nto8v5LNwCcHR,yjNYCMFrPXpAoZHGe7iUJ25g,ksTLSoVGg0ht,KNomgGw1kdMCBH(u"ࠨࡕࡈࡐࡊࡉࡔࠡࡦࡤࡸࡦࠦࡆࡓࡑࡐࠤ༵ࠧ࠭")+AmD0xYsJtIk+f8Ja1q5eO02B(u"ࠩࠥࠤ࡜ࡎࡅࡓࡇࠣࡧࡴࡲࡵ࡮ࡰࠣࡁࠥࡅࠠ࠼ࠩ༶"),(str(aaVB0MUdD9fb),))
		if BbsTmRndZaLY69:
			try:
				ttFj9PmIcsuGpzib3aS = Zh9o1Rjn0kBsmiCM4cEIa.decompress(BbsTmRndZaLY69[nnsBpJv6XL3OzHoe4Vuhr][nnsBpJv6XL3OzHoe4Vuhr])
				oGBLR5vmhyqPrKaECQSi67wTF2Z1uM = HVnx1jUWs7KeqN256oG3QOct.loads(ttFj9PmIcsuGpzib3aS)
			except: pass
	else:
		BbsTmRndZaLY69 = MMPNsJSHhcbFTukwK2UOv1Bexig(s45iIBkQuHKTpcOoGCFYwNW,ZZ9aGOKsMrV0nto8v5LNwCcHR,yjNYCMFrPXpAoZHGe7iUJ25g,ksTLSoVGg0ht,liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠪࡗࡊࡒࡅࡄࡖࠣࡧࡴࡲࡵ࡮ࡰ࠯ࡨࡦࡺࡡࠡࡈࡕࡓࡒࠦࠢࠨ༷")+AmD0xYsJtIk+SGazRxP3yBKZ15ILuch(u"ࠫࠧࠦ࠻ࠨ༸"))
		if BbsTmRndZaLY69:
			oGBLR5vmhyqPrKaECQSi67wTF2Z1uM,zIhGN067FyKQO5ite = {},[]
			for idMJeh3jSZ8v1NxGXmcQClA,H3F607d1jsXEnMvor2 in BbsTmRndZaLY69:
				Xs12JCWGlgmSoHTjAqrFZafE = Zh9o1Rjn0kBsmiCM4cEIa.decompress(H3F607d1jsXEnMvor2)
				H3F607d1jsXEnMvor2 = HVnx1jUWs7KeqN256oG3QOct.loads(Xs12JCWGlgmSoHTjAqrFZafE)
				oGBLR5vmhyqPrKaECQSi67wTF2Z1uM[idMJeh3jSZ8v1NxGXmcQClA] = H3F607d1jsXEnMvor2
				zIhGN067FyKQO5ite.append(idMJeh3jSZ8v1NxGXmcQClA)
			if zIhGN067FyKQO5ite:
				oGBLR5vmhyqPrKaECQSi67wTF2Z1uM[opyTNwHgfqbZREWKU(u"ࠬࡥ࡟ࡔࡇࡔ࡙ࡊࡔࡃࡆࡆࡢࡇࡔࡒࡕࡎࡐࡖࡣࡤ༹࠭")] = zIhGN067FyKQO5ite
				if vuqDWMFGiskPfR63oT1==AiCor1fIVTDxQUWwHe9vPR7(u"࠭࡬ࡪࡵࡷࠫ༺"): oGBLR5vmhyqPrKaECQSi67wTF2Z1uM = zIhGN067FyKQO5ite
	ZZ9aGOKsMrV0nto8v5LNwCcHR.close()
	return oGBLR5vmhyqPrKaECQSi67wTF2Z1uM
def uAkLQ7gEZaIBv6Fyn(s45iIBkQuHKTpcOoGCFYwNW,AmD0xYsJtIk,aaVB0MUdD9fb,oGBLR5vmhyqPrKaECQSi67wTF2Z1uM,URYriT0y4bI37pDG62lo,dHo2pZ436Ke=ksTLSoVGg0ht):
	y0p7QGRembk5O1iIZt = Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.getSetting(SGazRxP3yBKZ15ILuch(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡧࡦࡩࡨࡦࠩ༻"))
	if y0p7QGRembk5O1iIZt==WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠨࡎࡌࡑࡎ࡚ࡅࡅࠩ༼") and URYriT0y4bI37pDG62lo>kZK9jh5ufsoVAmxreYPbyUaR7I0LO: URYriT0y4bI37pDG62lo = kZK9jh5ufsoVAmxreYPbyUaR7I0LO
	if dHo2pZ436Ke:
		O0Ftx1MjvKl,NJdmDUfLgXRY4Iti = [],[]
		for DXAlBvH2ITZoyunMU0Rq3pw7sx,FHVhY6utWxwjv7g0Dz in enumerate(aaVB0MUdD9fb):
			ttFj9PmIcsuGpzib3aS = HVnx1jUWs7KeqN256oG3QOct.dumps(oGBLR5vmhyqPrKaECQSi67wTF2Z1uM[DXAlBvH2ITZoyunMU0Rq3pw7sx])
			BsSmWPNilOf4h = Zh9o1Rjn0kBsmiCM4cEIa.compress(ttFj9PmIcsuGpzib3aS)
			O0Ftx1MjvKl.append((FHVhY6utWxwjv7g0Dz,))
			NJdmDUfLgXRY4Iti.append((URYriT0y4bI37pDG62lo+BbIVuS4KecnqNvZz5GptR,str(FHVhY6utWxwjv7g0Dz),BsSmWPNilOf4h))
	else:
		ttFj9PmIcsuGpzib3aS = HVnx1jUWs7KeqN256oG3QOct.dumps(oGBLR5vmhyqPrKaECQSi67wTF2Z1uM)
		r81r5gfHVkbeaTN = Zh9o1Rjn0kBsmiCM4cEIa.compress(ttFj9PmIcsuGpzib3aS)
	ZZ9aGOKsMrV0nto8v5LNwCcHR,yjNYCMFrPXpAoZHGe7iUJ25g = ehTmLt7VvnGuMZcDNQi5YOBoIaqj(s45iIBkQuHKTpcOoGCFYwNW)
	BbsTmRndZaLY69 = MMPNsJSHhcbFTukwK2UOv1Bexig(s45iIBkQuHKTpcOoGCFYwNW,ZZ9aGOKsMrV0nto8v5LNwCcHR,yjNYCMFrPXpAoZHGe7iUJ25g,ksTLSoVGg0ht,iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠩࡆࡖࡊࡇࡔࡆࠢࡗࡅࡇࡒࡅࠡࡋࡉࠤࡓࡕࡔࠡࡇ࡛ࡍࡘ࡚ࡓࠡࠤࠪ༽")+AmD0xYsJtIk+On1WZJc6dtksqVNgSQ5GBAjuipe(u"ࠪࠦࠥ࠮ࡥࡹࡲ࡬ࡶࡾ࠲ࡣࡰ࡮ࡸࡱࡳ࠲ࡤࡢࡶࡤ࠭ࠥࡁࠧ༾"))
	if dHo2pZ436Ke:
		BbsTmRndZaLY69 = MMPNsJSHhcbFTukwK2UOv1Bexig(s45iIBkQuHKTpcOoGCFYwNW,ZZ9aGOKsMrV0nto8v5LNwCcHR,yjNYCMFrPXpAoZHGe7iUJ25g,IZQbmFzLHDtXfc,k5oIaYyp2mnrLK49qhzS(u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࠥࠫ༿")+AmD0xYsJtIk+aar0zhDnJsOTP7EdgR16HIS29(u"ࠬࠨࠠࡘࡊࡈࡖࡊࠦࡣࡰ࡮ࡸࡱࡳࠦ࠽ࠡࡁࠣ࠿ࠬཀ"),O0Ftx1MjvKl)
		BbsTmRndZaLY69 = MMPNsJSHhcbFTukwK2UOv1Bexig(s45iIBkQuHKTpcOoGCFYwNW,ZZ9aGOKsMrV0nto8v5LNwCcHR,yjNYCMFrPXpAoZHGe7iUJ25g,IZQbmFzLHDtXfc,k5oIaYyp2mnrLK49qhzS(u"࠭ࡉࡏࡕࡈࡖ࡙ࠦࡉࡏࡖࡒࠤࠧ࠭ཁ")+AmD0xYsJtIk+rbUkdYi32PJaRtnxhDvQs(u"࡙ࠧࠣࠢࡅࡑ࡛ࡅࡔࠢࠫࡃ࠱ࡅࠬࡀࠫࠣ࠿ࠬག"),NJdmDUfLgXRY4Iti)
	else:
		if URYriT0y4bI37pDG62lo:
			BbsTmRndZaLY69 = MMPNsJSHhcbFTukwK2UOv1Bexig(s45iIBkQuHKTpcOoGCFYwNW,ZZ9aGOKsMrV0nto8v5LNwCcHR,yjNYCMFrPXpAoZHGe7iUJ25g,ksTLSoVGg0ht,iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠨࡆࡈࡐࡊ࡚ࡅࠡࡈࡕࡓࡒࠦࠢࠨགྷ")+AmD0xYsJtIk+s8fcjBCSMxzAIkZQbJPga(u"ࠩࠥࠤ࡜ࡎࡅࡓࡇࠣࡧࡴࡲࡵ࡮ࡰࠣࡁࠥࡅࠠ࠼ࠩང"),(str(aaVB0MUdD9fb),))
			BbsTmRndZaLY69 = MMPNsJSHhcbFTukwK2UOv1Bexig(s45iIBkQuHKTpcOoGCFYwNW,ZZ9aGOKsMrV0nto8v5LNwCcHR,yjNYCMFrPXpAoZHGe7iUJ25g,ksTLSoVGg0ht,WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠪࡍࡓ࡙ࡅࡓࡖࠣࡍࡓ࡚ࡏࠡࠤࠪཅ")+AmD0xYsJtIk+nfg30bHwd4aNV12SR7UjFck(u"ࠫࠧࠦࡖࡂࡎࡘࡉࡘࠦࠨࡀ࠮ࡂ࠰ࡄ࠯ࠠ࠼ࠩཆ"),(URYriT0y4bI37pDG62lo+BbIVuS4KecnqNvZz5GptR,str(aaVB0MUdD9fb),r81r5gfHVkbeaTN))
		else:
			BbsTmRndZaLY69 = MMPNsJSHhcbFTukwK2UOv1Bexig(s45iIBkQuHKTpcOoGCFYwNW,ZZ9aGOKsMrV0nto8v5LNwCcHR,yjNYCMFrPXpAoZHGe7iUJ25g,ksTLSoVGg0ht,s8fcjBCSMxzAIkZQbJPga(u"࡛ࠬࡐࡅࡃࡗࡉࠥࠨࠧཇ")+AmD0xYsJtIk+On1WZJc6dtksqVNgSQ5GBAjuipe(u"࠭ࠢࠡࡕࡈࡘࠥࡪࡡࡵࡣࠣࡁࠥࡅࠠࡘࡊࡈࡖࡊࠦࡣࡰ࡮ࡸࡱࡳࠦ࠽ࠡࡁࠣ࠿ࠬ཈"),(r81r5gfHVkbeaTN,str(aaVB0MUdD9fb)))
	ZZ9aGOKsMrV0nto8v5LNwCcHR.close()
	return
def uVOoSHfqe4WtiF(s45iIBkQuHKTpcOoGCFYwNW,AmD0xYsJtIk,aaVB0MUdD9fb=RRAmELdrBNQGixkaTlC8ozVFe):
	ZZ9aGOKsMrV0nto8v5LNwCcHR,yjNYCMFrPXpAoZHGe7iUJ25g = ehTmLt7VvnGuMZcDNQi5YOBoIaqj(s45iIBkQuHKTpcOoGCFYwNW)
	if aaVB0MUdD9fb==RRAmELdrBNQGixkaTlC8ozVFe: BbsTmRndZaLY69 = MMPNsJSHhcbFTukwK2UOv1Bexig(s45iIBkQuHKTpcOoGCFYwNW,ZZ9aGOKsMrV0nto8v5LNwCcHR,yjNYCMFrPXpAoZHGe7iUJ25g,ksTLSoVGg0ht,TtyzcuW45VKA(u"ࠧࡅࡔࡒࡔ࡚ࠥࡁࡃࡎࡈࠤࡎࡌࠠࡆ࡚ࡌࡗ࡙࡙ࠠࠣࠩཉ")+AmD0xYsJtIk+aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠨࠤࠣ࠿ࠬཊ"))
	else:
		X39if6zuhFWy1rHJx = (str(aaVB0MUdD9fb),)
		if WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠩࠨࠫཋ") in aaVB0MUdD9fb: BbsTmRndZaLY69 = MMPNsJSHhcbFTukwK2UOv1Bexig(s45iIBkQuHKTpcOoGCFYwNW,ZZ9aGOKsMrV0nto8v5LNwCcHR,yjNYCMFrPXpAoZHGe7iUJ25g,ksTLSoVGg0ht,iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠪࡈࡊࡒࡅࡕࡇࠣࡊࡗࡕࡍࠡࠤࠪཌ")+AmD0xYsJtIk+LJPOQNK1mcG(u"ࠫࠧࠦࡗࡉࡇࡕࡉࠥࡩ࡯࡭ࡷࡰࡲࠥࡲࡩ࡬ࡧࠣࡃࠥࡁࠧཌྷ"),X39if6zuhFWy1rHJx)
		else: BbsTmRndZaLY69 = MMPNsJSHhcbFTukwK2UOv1Bexig(s45iIBkQuHKTpcOoGCFYwNW,ZZ9aGOKsMrV0nto8v5LNwCcHR,yjNYCMFrPXpAoZHGe7iUJ25g,ksTLSoVGg0ht,LungQF89BqemOb32jJsZlW(u"ࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࠦࠬཎ")+AmD0xYsJtIk+aNdix5gq7yeFHTMWhnzm8pX0Y16(u"࡙࠭ࠢࠡࡋࡉࡗࡋࠠࡤࡱ࡯ࡹࡲࡴࠠ࠾ࠢࡂࠤࡀ࠭ཏ"),X39if6zuhFWy1rHJx)
	ZZ9aGOKsMrV0nto8v5LNwCcHR.close()
	return
class ll9mBXx0kOFA2u8C61itQgJew(): pass
class wsJ0K4Skqd8(ll9mBXx0kOFA2u8C61itQgJew):
	def __init__(NQ27ID3mjHigVEAky6O9YWPbn):
		NQ27ID3mjHigVEAky6O9YWPbn.url = cdZKMn68Pzg4
		NQ27ID3mjHigVEAky6O9YWPbn.code = -zDek1IW37rq6UoKdwyRiAVpF(u"࠽࠾ᄢ")
		NQ27ID3mjHigVEAky6O9YWPbn.reason = cdZKMn68Pzg4
		NQ27ID3mjHigVEAky6O9YWPbn.content = cdZKMn68Pzg4
		NQ27ID3mjHigVEAky6O9YWPbn.headers = {}
		NQ27ID3mjHigVEAky6O9YWPbn.cookies = {}
		NQ27ID3mjHigVEAky6O9YWPbn.succeeded = ksTLSoVGg0ht
def HMxzS0Jf69trLk(ppWtKTjVzdQwmoqNi7E):
	if ppWtKTjVzdQwmoqNi7E==uxE8MyoTRglrcaiQf(u"ࠧࡥ࡫ࡦࡸࠬཐ"): oGBLR5vmhyqPrKaECQSi67wTF2Z1uM = {}
	elif ppWtKTjVzdQwmoqNi7E==vbYokBuWlxeLDcdVNM60(u"ࠨ࡮࡬ࡷࡹ࠭ད"): oGBLR5vmhyqPrKaECQSi67wTF2Z1uM = []
	elif ppWtKTjVzdQwmoqNi7E==LungQF89BqemOb32jJsZlW(u"ࠩࡷࡹࡵࡲࡥࠨདྷ"): oGBLR5vmhyqPrKaECQSi67wTF2Z1uM = ()
	elif ppWtKTjVzdQwmoqNi7E==LJPOQNK1mcG(u"ࠪࡷࡹࡸࠧན"): oGBLR5vmhyqPrKaECQSi67wTF2Z1uM = cdZKMn68Pzg4
	elif ppWtKTjVzdQwmoqNi7E==AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"ࠫ࡮ࡴࡴࠨཔ"): oGBLR5vmhyqPrKaECQSi67wTF2Z1uM = nnsBpJv6XL3OzHoe4Vuhr
	elif ppWtKTjVzdQwmoqNi7E==SGazRxP3yBKZ15ILuch(u"ࠬࡨ࡯ࡰ࡮ࠪཕ"): oGBLR5vmhyqPrKaECQSi67wTF2Z1uM = RRAmELdrBNQGixkaTlC8ozVFe
	elif ppWtKTjVzdQwmoqNi7E==liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"࠭ࡲࡦࡵࡳࡳࡳࡹࡥࠨབ"): oGBLR5vmhyqPrKaECQSi67wTF2Z1uM = wsJ0K4Skqd8()
	elif not ppWtKTjVzdQwmoqNi7E: oGBLR5vmhyqPrKaECQSi67wTF2Z1uM = RRAmELdrBNQGixkaTlC8ozVFe
	else: oGBLR5vmhyqPrKaECQSi67wTF2Z1uM = RRAmELdrBNQGixkaTlC8ozVFe
	return oGBLR5vmhyqPrKaECQSi67wTF2Z1uM
def a8UdZSmAMkIGH3p12lh0Xz5js(uuc2k7EsNhGj6QoX):
	cLMyZ4QagKnVwIp = Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.getSetting(opyTNwHgfqbZREWKU(u"ࠧࡢࡸ࠱ࡴࡷ࡯ࡶࡴ࠳ࠪབྷ"))
	fcS2zTXh5JqG8iPmR = USuRxnPlV5.AV_CLIENT_IDS.splitlines()
	lroY3y9SLd6GAv5HmPfNBgR = nnsBpJv6XL3OzHoe4Vuhr
	uUzd5cGjb64M9hLlVpSKtRrxgHX = len(uuc2k7EsNhGj6QoX)
	ZgpAtTEGox = [ksTLSoVGg0ht]*uUzd5cGjb64M9hLlVpSKtRrxgHX
	for Rkzfrgi5AB1I3CF8ywT in [BbIVuS4KecnqNvZz5GptR,BbIVuS4KecnqNvZz5GptR-AlfMBJhUD65to2WrQcb]:
		coxz7amChg6pITrWO1HB = str(Rkzfrgi5AB1I3CF8ywT*liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"࠷࠰࠱࠲࠳࠴࠳࠶ᄤ")/HC9xWUMpBQJEuTteAqjd(u"࠹࠹࠲࠱࠲࠳ᄣ"))[nnsBpJv6XL3OzHoe4Vuhr:S5fhsRT8JV(u"࠴ᄥ")]
		if coxz7amChg6pITrWO1HB!=lroY3y9SLd6GAv5HmPfNBgR:
			for PC2J91Vyhn0GomBjp6K5clftAiYg in range(uUzd5cGjb64M9hLlVpSKtRrxgHX):
				if not ZgpAtTEGox[PC2J91Vyhn0GomBjp6K5clftAiYg]:
					HHeEVvc1f8GdySwYqml = ksTLSoVGg0ht
					for YYmL0FWPxcfK8r5wVujeRSdZ in fcS2zTXh5JqG8iPmR:
						NA7WLdoul9JvEfPOTzMXHbi = dwiIAcPl04ey7Zv38Mz(u"ࠨ࡚࠴࠽ࠬམ")+uuc2k7EsNhGj6QoX[PC2J91Vyhn0GomBjp6K5clftAiYg]+J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠩ࠴࠼ࡂ࠭ཙ")+YYmL0FWPxcfK8r5wVujeRSdZ[-ObuCsdoDtKmhPLSMH8YGan(u"࠳࠶ᄦ"):]+cWEA5yRl3VqGKk+coxz7amChg6pITrWO1HB
						NA7WLdoul9JvEfPOTzMXHbi = Tzg4GiYf75ZCK6h1pVu.md5(NA7WLdoul9JvEfPOTzMXHbi.encode(vczMIlkCAh2u10B3)).hexdigest()[:iRfoNckJs7Ibxzh5j92w8DSWF(u"࠵࠵ᄧ")]
						if NA7WLdoul9JvEfPOTzMXHbi in cLMyZ4QagKnVwIp:
							HHeEVvc1f8GdySwYqml = IZQbmFzLHDtXfc
							break
					ZgpAtTEGox[PC2J91Vyhn0GomBjp6K5clftAiYg] = HHeEVvc1f8GdySwYqml
		lroY3y9SLd6GAv5HmPfNBgR = coxz7amChg6pITrWO1HB
	return ZgpAtTEGox
class D8xY9QifCrncjPWU3JySm1H4OqkAZ(zDsmTbwF7f):
	def __init__(NQ27ID3mjHigVEAky6O9YWPbn): pass
	def Y9edlbQgVnSPFMyBI4wq(NQ27ID3mjHigVEAky6O9YWPbn,ZxQ3TO4j5e8GyauMnrSb9):
		NQ27ID3mjHigVEAky6O9YWPbn.uU893JOSZ7fRo1drA = KNomgGw1kdMCBH(u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠫཚ") if USuRxnPlV5.UZOwXToGvJnEqB4tgczAS2hHu else cdZKMn68Pzg4
		NQ27ID3mjHigVEAky6O9YWPbn.ZxQ3TO4j5e8GyauMnrSb9 = ZxQ3TO4j5e8GyauMnrSb9
		if not USuRxnPlV5.tbo8MkxlHv9qwdP6gI1rJzOV3Na:
			import RgJNGc7YMP
			RgJNGc7YMP.qJCuGHUaeOv(qIOfxknj8DiBYboGtQN4v)
	def onPlayBackStopped(NQ27ID3mjHigVEAky6O9YWPbn): NQ27ID3mjHigVEAky6O9YWPbn.uU893JOSZ7fRo1drA = vbYokBuWlxeLDcdVNM60(u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫཛ")
	def onPlayBackError(NQ27ID3mjHigVEAky6O9YWPbn): NQ27ID3mjHigVEAky6O9YWPbn.uU893JOSZ7fRo1drA = dwiIAcPl04ey7Zv38Mz(u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬཛྷ")
	def onPlayBackEnded(NQ27ID3mjHigVEAky6O9YWPbn): NQ27ID3mjHigVEAky6O9YWPbn.uU893JOSZ7fRo1drA = tRnTydV03Xfi7rbQ(u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭ཝ")
	def onPlayBackStarted(NQ27ID3mjHigVEAky6O9YWPbn):
		NQ27ID3mjHigVEAky6O9YWPbn.uU893JOSZ7fRo1drA = WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠧࡴࡶࡤࡶࡹ࡫ࡤࠨཞ")
		UICs3AdjoceQa9b = qMrpRl8enOuvS6hV2XcZgT(daemon=IZQbmFzLHDtXfc,target=NQ27ID3mjHigVEAky6O9YWPbn.TqcCKfrp94IRW5)
		UICs3AdjoceQa9b.start()
	def onAVStarted(NQ27ID3mjHigVEAky6O9YWPbn):
		if USuRxnPlV5.tbo8MkxlHv9qwdP6gI1rJzOV3Na: NQ27ID3mjHigVEAky6O9YWPbn.uU893JOSZ7fRo1drA = HC9xWUMpBQJEuTteAqjd(u"ࠨࡲ࡯ࡥࡾ࡯࡮ࡨࠩཟ")
		else: NQ27ID3mjHigVEAky6O9YWPbn.uU893JOSZ7fRo1drA = k5oIaYyp2mnrLK49qhzS(u"ࠩࡷࡩࡸࡺࡩ࡯ࡩࠪའ")
	def TqcCKfrp94IRW5(NQ27ID3mjHigVEAky6O9YWPbn):
		LuxnZYbRE6dBXteSIAv = nnsBpJv6XL3OzHoe4Vuhr
		while not eval(xN4fKmsnyM3Y2(u"ࠪࡼࡧࡳࡣ࠯ࡒ࡯ࡥࡾ࡫ࡲࠩࠫ࠱࡭ࡸࡖ࡬ࡢࡻ࡬ࡲ࡬࠮ࠩࠨཡ"),{NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠫࡽࡨ࡭ࡤࠩར"):bu6LzUQF7K}) and NQ27ID3mjHigVEAky6O9YWPbn.uU893JOSZ7fRo1drA==s8fcjBCSMxzAIkZQbJPga(u"ࠬࡹࡴࡢࡴࡷࡩࡩ࠭ལ"):
			bu6LzUQF7K.sleep(vbYokBuWlxeLDcdVNM60(u"࠴࠴࠵࠶ᄨ"))
			LuxnZYbRE6dBXteSIAv += hiuZa0PIsErm6UC7
			if LuxnZYbRE6dBXteSIAv>zDek1IW37rq6UoKdwyRiAVpF(u"࠺࠵ᄩ"): return
		if USuRxnPlV5.UZOwXToGvJnEqB4tgczAS2hHu: NQ27ID3mjHigVEAky6O9YWPbn.uU893JOSZ7fRo1drA = xN4fKmsnyM3Y2(u"࠭ࡢ࡭ࡱࡦ࡯ࡪࡪࠧཤ")
		elif USuRxnPlV5.tbo8MkxlHv9qwdP6gI1rJzOV3Na: NQ27ID3mjHigVEAky6O9YWPbn.uU893JOSZ7fRo1drA = ObuCsdoDtKmhPLSMH8YGan(u"ࠧࡱ࡮ࡤࡽ࡮ࡴࡧࠨཥ")
		elif USuRxnPlV5.EXB156kCy3JW7U8gfqhGiwlov:
			import RgJNGc7YMP
			NQ27ID3mjHigVEAky6O9YWPbn.uU893JOSZ7fRo1drA = aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠨࡶࡨࡷࡹ࡯࡮ࡨࠩས")
			dNosE0aMjWHXP4(LungQF89BqemOb32jJsZlW(u"ࠩࡶࡸࡴࡶࠧཧ"),IZQbmFzLHDtXfc)
			uF4R9kv8bmhQUoCIBjL7z = qMrpRl8enOuvS6hV2XcZgT(daemon=IZQbmFzLHDtXfc,target=RgJNGc7YMP.Y5Jum4ziwaW6KlpbHIR1gen,args=(NQ27ID3mjHigVEAky6O9YWPbn.ZxQ3TO4j5e8GyauMnrSb9,)).start()
			ZZ6U4OLvqzWnpQ0uhEsJ9caVK = qMrpRl8enOuvS6hV2XcZgT(daemon=IZQbmFzLHDtXfc,target=RgJNGc7YMP.vhKzO4R6ouep13xVMQbiHZX).start()
		else: NQ27ID3mjHigVEAky6O9YWPbn.uU893JOSZ7fRo1drA = Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠫཨ")
def dKmtuhVg5ZzEo3Nl():
	rLscynM87PkEgJUN5qeamATwjv9F,VHgKhAcl537nBT1xmtMvG = cdZKMn68Pzg4,cdZKMn68Pzg4
	Tzf9jx5RKmvP2bpBou3U6 = bu6LzUQF7K.getInfoLabel(LungQF89BqemOb32jJsZlW(u"ࠫࡘࡿࡳࡵࡧࡰ࠲ࡋࡸࡩࡦࡰࡧࡰࡾࡔࡡ࡮ࡧࠪཀྵ"))
	try:
		HHFkmrtqQBz = open(f8Ja1q5eO02B(u"ࠬ࠵ࡰࡳࡱࡦ࠳ࡨࡶࡵࡪࡰࡩࡳࠬཪ"),nfg30bHwd4aNV12SR7UjFck(u"࠭ࡲࡣࠩཫ")).read()
		if W5domCu6XrQUFkiPpa3bNLtHglG: HHFkmrtqQBz = HHFkmrtqQBz.decode(vczMIlkCAh2u10B3)
		ZAB5dLJH6q7 = ffUFBJQ57j2XgoGeOLn9uwpC.findall(AiCor1fIVTDxQUWwHe9vPR7(u"ࠧࡔࡧࡵ࡭ࡦࡲ࠮ࠫࡁ࠽ࠤ࠭࠴ࠪࡀࠫࠧࠫཬ"),HHFkmrtqQBz,ffUFBJQ57j2XgoGeOLn9uwpC.IGNORECASE)
		if ZAB5dLJH6q7: rLscynM87PkEgJUN5qeamATwjv9F = ZAB5dLJH6q7[nnsBpJv6XL3OzHoe4Vuhr]
	except: pass
	try:
		import subprocess as VI8XxtKqZMUvNPGHr3zTYcF91yWe
		Z5EGwL9QYm2yp = VI8XxtKqZMUvNPGHr3zTYcF91yWe.Popen(SGazRxP3yBKZ15ILuch(u"ࠨࡵࡷࡥࡹࠦ࠭ࡤࠢࠥࠤࠪ࡞ࠠࠣࠢ࠲ࡷࡹࡵࡲࡢࡩࡨ࠳ࡪࡳࡵ࡭ࡣࡷࡩࡩ࠵࠰ࠡ࠽ࠣࡷࡹࡧࡴࠡ࠯ࡦࠤࠧࠦࠥࡘࠢࠥࠤ࠴ࡼࡡࡳ࠱࡯ࡳ࡬࠭཭"),shell=IZQbmFzLHDtXfc,stdin=VI8XxtKqZMUvNPGHr3zTYcF91yWe.PIPE,stdout=VI8XxtKqZMUvNPGHr3zTYcF91yWe.PIPE,stderr=VI8XxtKqZMUvNPGHr3zTYcF91yWe.PIPE)
		AjDbyet5YLhQFPH2fUK = Z5EGwL9QYm2yp.stdout.read()
		if AjDbyet5YLhQFPH2fUK:
			if W5domCu6XrQUFkiPpa3bNLtHglG:
				AjDbyet5YLhQFPH2fUK = AjDbyet5YLhQFPH2fUK.decode(vczMIlkCAh2u10B3,k5oIaYyp2mnrLK49qhzS(u"ࠩ࡬࡫ࡳࡵࡲࡦࠩ཮"))
			ssTR3SzFgprwHa1AXbWjm8MLtY = ffUFBJQ57j2XgoGeOLn9uwpC.findall(S5fhsRT8JV(u"ࠪࠤ࠭ࡢࡤࡼ࠳࠳ࢁ࠮ࠦࠧ཯"),AjDbyet5YLhQFPH2fUK,ffUFBJQ57j2XgoGeOLn9uwpC.IGNORECASE)
			if ssTR3SzFgprwHa1AXbWjm8MLtY: VHgKhAcl537nBT1xmtMvG = min(ssTR3SzFgprwHa1AXbWjm8MLtY)
	except: pass
	return Tzf9jx5RKmvP2bpBou3U6,rLscynM87PkEgJUN5qeamATwjv9F,VHgKhAcl537nBT1xmtMvG
def NO3BIgUPeMwjCp(eysLw8zO6pMbBaIRrqYXTgtunNQ=IZQbmFzLHDtXfc,xv0hqpmHSVI2Ql1Z5i39gNe=uxE8MyoTRglrcaiQf(u"࠸࠸ᄪ")):
	yyX42Kn1FseaLWZItAlD9gj0mV7zNR = IZQbmFzLHDtXfc
	if eysLw8zO6pMbBaIRrqYXTgtunNQ:
		VzoAgGSrJiLj = sZHYrLPog4wmuW0ECdc(TV08xYHA2ok,nfg30bHwd4aNV12SR7UjFck(u"ࠫࡱ࡯ࡳࡵࠩ཰"),f8Ja1q5eO02B(u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨཱ"),xN4fKmsnyM3Y2(u"࠭ࡓࡊࡖࡈࡗࡤࡉࡈࡆࡅࡎིࠫ"))
		if VzoAgGSrJiLj:
			jDFeZ3PuoSNHs7WLlm09YhGrba81I,OmPAFvdsLRoqG3l1,Q0Yc8C3J5ABdWZ,tts1YBRxq06AMES = VzoAgGSrJiLj
			yyX42Kn1FseaLWZItAlD9gj0mV7zNR = sZHYrLPog4wmuW0ECdc(TV08xYHA2ok,opyTNwHgfqbZREWKU(u"ࠧ࡭࡫ࡶࡸཱིࠬ"),TtyzcuW45VKA(u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐུࠫ"),TtyzcuW45VKA(u"ࠩࡖࡍ࡙ࡋࡓࡠࡘࡈࡖࡎࡌ࡙ࠨཱུ"))
			if yyX42Kn1FseaLWZItAlD9gj0mV7zNR: Tzf9jx5RKmvP2bpBou3U6,rLscynM87PkEgJUN5qeamATwjv9F,VHgKhAcl537nBT1xmtMvG = yyX42Kn1FseaLWZItAlD9gj0mV7zNR
			else: Tzf9jx5RKmvP2bpBou3U6,rLscynM87PkEgJUN5qeamATwjv9F,VHgKhAcl537nBT1xmtMvG = dKmtuhVg5ZzEo3Nl()
			if (OmPAFvdsLRoqG3l1,Q0Yc8C3J5ABdWZ,tts1YBRxq06AMES)==(Tzf9jx5RKmvP2bpBou3U6,rLscynM87PkEgJUN5qeamATwjv9F,VHgKhAcl537nBT1xmtMvG):
				Zjngl09zQ8LK6 = ssELJkeScrtni2.join(jDFeZ3PuoSNHs7WLlm09YhGrba81I)
				return Zjngl09zQ8LK6
	if yyX42Kn1FseaLWZItAlD9gj0mV7zNR: Tzf9jx5RKmvP2bpBou3U6,rLscynM87PkEgJUN5qeamATwjv9F,VHgKhAcl537nBT1xmtMvG = dKmtuhVg5ZzEo3Nl()
	global Q2QCEYsu05hI,e8eKnTvifhNGFsYMljc
	Q2QCEYsu05hI,e8eKnTvifhNGFsYMljc,MPtHXKTDFmRB8kjY9pagvUIfzsbWo = cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4
	xv0hqpmHSVI2Ql1Z5i39gNe = xv0hqpmHSVI2Ql1Z5i39gNe//bVX3ev1spE
	qMrpRl8enOuvS6hV2XcZgT(daemon=IZQbmFzLHDtXfc,target=gi6Q9wF7uKvB0bGSkd).start()
	qMrpRl8enOuvS6hV2XcZgT(daemon=IZQbmFzLHDtXfc,target=lliTexSkWv).start()
	for DXAlBvH2ITZoyunMU0Rq3pw7sx in range(iRfoNckJs7Ibxzh5j92w8DSWF(u"࠷࠰ᄫ")):
		bD7kJZhMCdaqF68P45KlNIgO1.sleep(k5oIaYyp2mnrLK49qhzS(u"࠰࠯࠷ᄬ"))
		if not MPtHXKTDFmRB8kjY9pagvUIfzsbWo:
			try:
				as8k7hBbyn69j = bu6LzUQF7K.getInfoLabel(iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠪࡒࡪࡺࡷࡰࡴ࡮࠲ࡒࡧࡣࡂࡦࡧࡶࡪࡹࡳࠨྲྀ"))
				if as8k7hBbyn69j.count(ObuCsdoDtKmhPLSMH8YGan(u"ࠫ࠿࠭ཷ"))==ffXqoLey4TixFJBw and as8k7hBbyn69j.count(J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠬ࠶ࠧླྀ"))<ObuCsdoDtKmhPLSMH8YGan(u"࠺ᄭ"):
					as8k7hBbyn69j = as8k7hBbyn69j.lower().replace(LJPOQNK1mcG(u"࠭࠺ࠨཹ"),cdZKMn68Pzg4)
					MPtHXKTDFmRB8kjY9pagvUIfzsbWo = str(int(as8k7hBbyn69j,AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"࠳࠹ᄮ")))
			except: pass
		if Q2QCEYsu05hI and e8eKnTvifhNGFsYMljc and MPtHXKTDFmRB8kjY9pagvUIfzsbWo: break
	iUpNj9wdCoF62Pu5l1 = [e8eKnTvifhNGFsYMljc,Q2QCEYsu05hI,MPtHXKTDFmRB8kjY9pagvUIfzsbWo,cdZKMn68Pzg4,cdZKMn68Pzg4,NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠧ࠱࠲࠴࠵࠷࠸࠳࠴࠶࠷࠹࠺࠼࠶࠸࠹ེࠪ")]
	if rLscynM87PkEgJUN5qeamATwjv9F or VHgKhAcl537nBT1xmtMvG:
		PLBrVK3kDGq8Nw9CuvYjs47gRFe2d = [(iwQJREcVTSe1G2gCvlfhbHWLjqopa,rLscynM87PkEgJUN5qeamATwjv9F),(ffXqoLey4TixFJBw,VHgKhAcl537nBT1xmtMvG)]
		for oOsyIY7xpniWZ62HXQgPrw10V,sLhEnc4bqKSNCYwHAxFPQUZiW in PLBrVK3kDGq8Nw9CuvYjs47gRFe2d:
			sLhEnc4bqKSNCYwHAxFPQUZiW = sLhEnc4bqKSNCYwHAxFPQUZiW.strip(k5oIaYyp2mnrLK49qhzS(u"ࠨ࠲ཻࠪ"))
			if sLhEnc4bqKSNCYwHAxFPQUZiW:
				if W5domCu6XrQUFkiPpa3bNLtHglG: sLhEnc4bqKSNCYwHAxFPQUZiW = sLhEnc4bqKSNCYwHAxFPQUZiW.encode(vczMIlkCAh2u10B3)
				sLhEnc4bqKSNCYwHAxFPQUZiW = str(int(Tzg4GiYf75ZCK6h1pVu.md5(sLhEnc4bqKSNCYwHAxFPQUZiW).hexdigest(),KNomgGw1kdMCBH(u"࠶࠺ᄯ")))
				FFUyb6a2XvhDEp = [int(sLhEnc4bqKSNCYwHAxFPQUZiW[BmcC3UvT2qn8yl1dHjVAJ5Z:BmcC3UvT2qn8yl1dHjVAJ5Z+f8Ja1q5eO02B(u"࠵࠺ᄰ")]) for BmcC3UvT2qn8yl1dHjVAJ5Z in range(len(sLhEnc4bqKSNCYwHAxFPQUZiW)) if BmcC3UvT2qn8yl1dHjVAJ5Z%f8Ja1q5eO02B(u"࠵࠺ᄰ")==nnsBpJv6XL3OzHoe4Vuhr]
				iUpNj9wdCoF62Pu5l1[oOsyIY7xpniWZ62HXQgPrw10V-hiuZa0PIsErm6UC7] = str(sum(FFUyb6a2XvhDEp))
	fcS2zTXh5JqG8iPmR,qquwK6PkDlXLsoSCN9VByfzht = [],ksTLSoVGg0ht
	for KRTCzZF1SE8Xj7Gabuq,FFUyb6a2XvhDEp in enumerate(iUpNj9wdCoF62Pu5l1):
		if not FFUyb6a2XvhDEp: continue
		if qquwK6PkDlXLsoSCN9VByfzht and FFUyb6a2XvhDEp==iUpNj9wdCoF62Pu5l1[-hiuZa0PIsErm6UC7]: continue
		qquwK6PkDlXLsoSCN9VByfzht = IZQbmFzLHDtXfc
		FFUyb6a2XvhDEp = SGazRxP3yBKZ15ILuch(u"ࠩ࠳ོࠫ")*xv0hqpmHSVI2Ql1Z5i39gNe+FFUyb6a2XvhDEp
		FFUyb6a2XvhDEp = FFUyb6a2XvhDEp[-xv0hqpmHSVI2Ql1Z5i39gNe:]
		Ikit5On7UalYm1,CsS0x6D1VgEkoKub3Z = cdZKMn68Pzg4,cdZKMn68Pzg4
		GNQ7TbiuHD4A5hvwrMqS = str(int(Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠪ࠽ཽࠬ")*(xv0hqpmHSVI2Ql1Z5i39gNe+hiuZa0PIsErm6UC7))-int(FFUyb6a2XvhDEp))[-xv0hqpmHSVI2Ql1Z5i39gNe:]
		for PC2J91Vyhn0GomBjp6K5clftAiYg in list(range(nnsBpJv6XL3OzHoe4Vuhr,xv0hqpmHSVI2Ql1Z5i39gNe,iwQJREcVTSe1G2gCvlfhbHWLjqopa)):
			Ikit5On7UalYm1 += GNQ7TbiuHD4A5hvwrMqS[PC2J91Vyhn0GomBjp6K5clftAiYg:PC2J91Vyhn0GomBjp6K5clftAiYg+iwQJREcVTSe1G2gCvlfhbHWLjqopa]+J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠫ࠲࠭ཾ")
			CsS0x6D1VgEkoKub3Z += str(sum(map(int,FFUyb6a2XvhDEp[PC2J91Vyhn0GomBjp6K5clftAiYg:PC2J91Vyhn0GomBjp6K5clftAiYg+iwQJREcVTSe1G2gCvlfhbHWLjqopa]))%LJPOQNK1mcG(u"࠶࠶ᄱ"))
		YYmL0FWPxcfK8r5wVujeRSdZ = str(KRTCzZF1SE8Xj7Gabuq)+Ikit5On7UalYm1+CsS0x6D1VgEkoKub3Z
		fcS2zTXh5JqG8iPmR.append(YYmL0FWPxcfK8r5wVujeRSdZ)
	Im8gBAQsrh5NyJT,jDFeZ3PuoSNHs7WLlm09YhGrba81I = [],[]
	for user in fcS2zTXh5JqG8iPmR:
		count = str(str(fcS2zTXh5JqG8iPmR).count(user[KNomgGw1kdMCBH(u"࠷ᄲ"):]))
		Im8gBAQsrh5NyJT.append(count+user)
	Im8gBAQsrh5NyJT = sorted(Im8gBAQsrh5NyJT,reverse=IZQbmFzLHDtXfc,key=lambda key: key[nnsBpJv6XL3OzHoe4Vuhr])
	for user in Im8gBAQsrh5NyJT: jDFeZ3PuoSNHs7WLlm09YhGrba81I.append(user[hiuZa0PIsErm6UC7:])
	uAkLQ7gEZaIBv6Fyn(TV08xYHA2ok,vbYokBuWlxeLDcdVNM60(u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨཿ"),J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"࠭ࡓࡊࡖࡈࡗࡤ࡜ࡅࡓࡋࡉ࡝ྀࠬ"),[Tzf9jx5RKmvP2bpBou3U6,rLscynM87PkEgJUN5qeamATwjv9F,VHgKhAcl537nBT1xmtMvG],K8DZxE74Afz52gBYbOMtpvql0RJma)
	uAkLQ7gEZaIBv6Fyn(TV08xYHA2ok,LungQF89BqemOb32jJsZlW(u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏཱྀࠪ"),zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"ࠨࡕࡌࡘࡊ࡙࡟ࡄࡊࡈࡇࡐ࠭ྂ"),[jDFeZ3PuoSNHs7WLlm09YhGrba81I,Tzf9jx5RKmvP2bpBou3U6,rLscynM87PkEgJUN5qeamATwjv9F,VHgKhAcl537nBT1xmtMvG],K8DZxE74Afz52gBYbOMtpvql0RJma)
	for user in USuRxnPlV5.BADCOMMONIDS:
		if user in jDFeZ3PuoSNHs7WLlm09YhGrba81I: jDFeZ3PuoSNHs7WLlm09YhGrba81I.remove(user)
	Zjngl09zQ8LK6 = ssELJkeScrtni2.join(jDFeZ3PuoSNHs7WLlm09YhGrba81I)
	return Zjngl09zQ8LK6
def gi6Q9wF7uKvB0bGSkd():
	global Q2QCEYsu05hI
	try:
		import getmac82 as nuOvGaEPiX15KQps
		H7i5zAeG3JdqBMcm = nuOvGaEPiX15KQps.get_mac_address()
		if H7i5zAeG3JdqBMcm.count(iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠩ࠽ࠫྃ"))==ffXqoLey4TixFJBw and H7i5zAeG3JdqBMcm.count(vbYokBuWlxeLDcdVNM60(u"ࠪ࠴྄ࠬ"))<YnHG75e2QWwo(u"࠹ᄳ"):
			H7i5zAeG3JdqBMcm = H7i5zAeG3JdqBMcm.lower().replace(uxE8MyoTRglrcaiQf(u"ࠫ࠿࠭྅"),cdZKMn68Pzg4)
			Q2QCEYsu05hI = str(int(H7i5zAeG3JdqBMcm,ObuCsdoDtKmhPLSMH8YGan(u"࠲࠸ᄴ")))
	except: pass
	return
def lliTexSkWv():
	global e8eKnTvifhNGFsYMljc
	try:
		import getmac95 as S3SLt9480a
		MYJeLxhqkId0mVo = S3SLt9480a.get_mac_address()
		if MYJeLxhqkId0mVo.count(k5oIaYyp2mnrLK49qhzS(u"ࠬࡀࠧ྆"))==ffXqoLey4TixFJBw and MYJeLxhqkId0mVo.count(YnHG75e2QWwo(u"࠭࠰ࠨ྇"))<LungQF89BqemOb32jJsZlW(u"࠻ᄵ"):
			MYJeLxhqkId0mVo = MYJeLxhqkId0mVo.lower().replace(On1WZJc6dtksqVNgSQ5GBAjuipe(u"ࠧ࠻ࠩྈ"),cdZKMn68Pzg4)
			e8eKnTvifhNGFsYMljc = str(int(MYJeLxhqkId0mVo,On1WZJc6dtksqVNgSQ5GBAjuipe(u"࠴࠺ᄶ")))
	except: pass
	return
def llsbaLdXicK1GCnEjvD5pgfP3yRUx(ppWtKTjVzdQwmoqNi7E,mrcsT4vGxI6o7PMayUkHdtEZXB,oGBLR5vmhyqPrKaECQSi67wTF2Z1uM,RR0LtrMn1qPF,MqpxmkbFcNAvGjVKoHzaw,nyJ8vPhb7TaC6wg0VX3xi):
	npaJqziQ13tIH0hLjDdB2cWX7uUMPR = str(RR0LtrMn1qPF)[nnsBpJv6XL3OzHoe4Vuhr:xN4fKmsnyM3Y2(u"࠶࠺࠶ᄷ")].replace(ssELJkeScrtni2,s8fcjBCSMxzAIkZQbJPga(u"ࠨ࡞࡟ࡲࠬྉ")).replace(CPjOZMmw8sfGg2B9LthIdXa1iKQUF,Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠩ࡟ࡠࡷ࠭ྊ")).replace(KATUbrqnhgW2GkBJzMDsREmtdo78,VBpIH2QSmvDGlA6TO3e).replace(U4ImogGksPlcBVfAb,VBpIH2QSmvDGlA6TO3e)
	if len(str(RR0LtrMn1qPF))>LungQF89BqemOb32jJsZlW(u"࠷࠻࠰ᄸ"): npaJqziQ13tIH0hLjDdB2cWX7uUMPR = npaJqziQ13tIH0hLjDdB2cWX7uUMPR+LJPOQNK1mcG(u"ࠪࠤ࠳࠴࠮ࠨྋ")
	H3F607d1jsXEnMvor2 = f8Ja1q5eO02B(u"ࠫ࠳࠴࠮ࠨྌ")
	SsziMZd5UbeL2NRxVpwjO(F0FeocLXmbJhdBwQnS18PCHZIU,TtyzcuW45VKA(u"ࠬࡕࡐࡆࡐࡘࡖࡑࡥࠧྍ")+ppWtKTjVzdQwmoqNi7E+NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"࠭ࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩྎ")+FOkLsAqwop0x3mciC62dRZag8VEGY(mrcsT4vGxI6o7PMayUkHdtEZXB,MqpxmkbFcNAvGjVKoHzaw)+nfg30bHwd4aNV12SR7UjFck(u"ࠧࠡ࡟ࠣࠤ࡙ࠥ࡯ࡶࡴࡦࡩ࠿࡛ࠦࠡࠩྏ")+MqpxmkbFcNAvGjVKoHzaw+J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠨࠢࡠࠤࠥࠦࡍࡦࡶ࡫ࡳࡩࡀࠠ࡜ࠢࠪྐ")+nyJ8vPhb7TaC6wg0VX3xi+aar0zhDnJsOTP7EdgR16HIS29(u"ࠩࠣࡡࠥࠦࠠࡉࡧࡤࡨࡪࡸࡳ࠻ࠢ࡞ࠤࠬྑ")+str(npaJqziQ13tIH0hLjDdB2cWX7uUMPR)+LungQF89BqemOb32jJsZlW(u"ࠪࠤࡢࠦࠠࠡࡆࡤࡸࡦࡀࠠ࡜ࠢࠪྒ")+H3F607d1jsXEnMvor2+NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠫࠥࡣࠧྒྷ"))
	return
def ejdgsCZmQ3DPLEBtx8(nyJ8vPhb7TaC6wg0VX3xi,sl89FQxXUwVPd,oGBLR5vmhyqPrKaECQSi67wTF2Z1uM=cdZKMn68Pzg4,RR0LtrMn1qPF=cdZKMn68Pzg4,MqpxmkbFcNAvGjVKoHzaw=cdZKMn68Pzg4):
	if W5domCu6XrQUFkiPpa3bNLtHglG: import urllib.request as ttd8uTy0RbaWcmoXk
	else: import urllib2 as ttd8uTy0RbaWcmoXk
	if not RR0LtrMn1qPF: RR0LtrMn1qPF = {AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩྔ"):cdZKMn68Pzg4}
	if not oGBLR5vmhyqPrKaECQSi67wTF2Z1uM: oGBLR5vmhyqPrKaECQSi67wTF2Z1uM = {}
	xYbFJODgq3fLBZr5T86yXVeWS = oGBLR5vmhyqPrKaECQSi67wTF2Z1uM
	uOtdw7xSvbMYrZc0mlqzVQkB9CePNo = sl89FQxXUwVPd in USuRxnPlV5.SITESURLS[opyTNwHgfqbZREWKU(u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭ྕ")]
	if uOtdw7xSvbMYrZc0mlqzVQkB9CePNo:
		nyJ8vPhb7TaC6wg0VX3xi = NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠧࡑࡑࡖࡘࠬྖ")
		RR0LtrMn1qPF[LungQF89BqemOb32jJsZlW(u"ࠨࡃ࡙࠱ࡊࡴࡣࡳࡻࡳࡸ࡮ࡵ࡮ࠨྗ")] = KNomgGw1kdMCBH(u"࡙ࠩࡩࡷࡹࡩࡰࡰࠣ࠵࠳࠶ࠧ྘")
		iouyEXnBQ4KJvNgDPA6xW0I = sJB3aL8gGVrRU.dumps(oGBLR5vmhyqPrKaECQSi67wTF2Z1uM)
		import RgJNGc7YMP
		xYbFJODgq3fLBZr5T86yXVeWS = RgJNGc7YMP.LV5vcn6IGXWC(iouyEXnBQ4KJvNgDPA6xW0I,vbYokBuWlxeLDcdVNM60(u"࠾࠱࠳࠹࠷࠽࠸࠻࠶ᄹ"))
		sl89FQxXUwVPd = sl89FQxXUwVPd+aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠪࡃࡺࡹࡥࡳ࠿ࠪྙ")+lBoFGiJ6DLj72XhueYRms
	elif nyJ8vPhb7TaC6wg0VX3xi==J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠫࡌࡋࡔࠨྚ"):
		sl89FQxXUwVPd = sl89FQxXUwVPd+opyTNwHgfqbZREWKU(u"ࠬࡅࠧྛ")+RV59cpi6BbrlJQuzwCTa(oGBLR5vmhyqPrKaECQSi67wTF2Z1uM)
		xYbFJODgq3fLBZr5T86yXVeWS = RRAmELdrBNQGixkaTlC8ozVFe
	elif nyJ8vPhb7TaC6wg0VX3xi==zDek1IW37rq6UoKdwyRiAVpF(u"࠭ࡐࡐࡕࡗࠫྜ") and WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠧ࡫ࡵࡲࡲࠬྜྷ") in str(RR0LtrMn1qPF):
		oGBLR5vmhyqPrKaECQSi67wTF2Z1uM = sJB3aL8gGVrRU.dumps(oGBLR5vmhyqPrKaECQSi67wTF2Z1uM)
		xYbFJODgq3fLBZr5T86yXVeWS = str(oGBLR5vmhyqPrKaECQSi67wTF2Z1uM).encode(vczMIlkCAh2u10B3)
	elif nyJ8vPhb7TaC6wg0VX3xi==Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠨࡒࡒࡗ࡙࠭ྞ"):
		oGBLR5vmhyqPrKaECQSi67wTF2Z1uM = RV59cpi6BbrlJQuzwCTa(oGBLR5vmhyqPrKaECQSi67wTF2Z1uM)
		xYbFJODgq3fLBZr5T86yXVeWS = oGBLR5vmhyqPrKaECQSi67wTF2Z1uM.encode(vczMIlkCAh2u10B3)
	llsbaLdXicK1GCnEjvD5pgfP3yRUx(tRnTydV03Xfi7rbQ(u"ࠩࡘࡖࡑࡒࡉࡃ࡞ࡷࡠࡹࡕࡐࡆࡐࡢ࡙ࡗࡒࠧྟ"),sl89FQxXUwVPd,oGBLR5vmhyqPrKaECQSi67wTF2Z1uM,RR0LtrMn1qPF,MqpxmkbFcNAvGjVKoHzaw,nyJ8vPhb7TaC6wg0VX3xi)
	try:
		O9Z0ERXqwTi2ob = ttd8uTy0RbaWcmoXk.Request(sl89FQxXUwVPd,headers=RR0LtrMn1qPF,data=xYbFJODgq3fLBZr5T86yXVeWS)
		cUCLtEeGw3TsqHMzjI = ttd8uTy0RbaWcmoXk.urlopen(O9Z0ERXqwTi2ob)
		EoY9Q6eBhyxgndjKUiMrHV = cUCLtEeGw3TsqHMzjI.read()
		CUSmz9MtDq,eefJ52Dq97M = LungQF89BqemOb32jJsZlW(u"࠲࠱࠲ᄺ"),rbUkdYi32PJaRtnxhDvQs(u"ࠪࡓࡐ࠭ྠ")
	except:
		EoY9Q6eBhyxgndjKUiMrHV = cdZKMn68Pzg4
		CUSmz9MtDq,eefJ52Dq97M = -hiuZa0PIsErm6UC7,iRfoNckJs7Ibxzh5j92w8DSWF(u"࡚ࠫࡴ࡫࡯ࡱࡺࡲࠥࡋࡲࡳࡱࡵࠫྡ")
	try:
		if uOtdw7xSvbMYrZc0mlqzVQkB9CePNo and EoY9Q6eBhyxgndjKUiMrHV:
			RT9YofheG5tIEJKsVdDkWcZx3 = {KHds51cS80Y6FgbCGIZ4QMv.lower(): q8SlveJuX4jfRBaVyTmiL7CNt for KHds51cS80Y6FgbCGIZ4QMv, q8SlveJuX4jfRBaVyTmiL7CNt in cUCLtEeGw3TsqHMzjI.headers.items()}
			if RT9YofheG5tIEJKsVdDkWcZx3.get(ObuCsdoDtKmhPLSMH8YGan(u"ࠬࡧࡶ࠮ࡧࡱࡧࡷࡿࡰࡵ࡫ࡲࡲࠬྡྷ"))==dwiIAcPl04ey7Zv38Mz(u"࠭ࡖࡦࡴࡶ࡭ࡴࡴࠠ࠲࠰࠳ࠫྣ"):
				EoY9Q6eBhyxgndjKUiMrHV,m8m5aGbr4YPuVWOL = RgJNGc7YMP.Bi9yvugkEShDIxN(EoY9Q6eBhyxgndjKUiMrHV,J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"࠹࠳࠵࠻࠹࠿࠳࠶࠸ᄻ"))
				if m8m5aGbr4YPuVWOL==HC9xWUMpBQJEuTteAqjd(u"ࠧࡊࡐ࡙ࡅࡑࡏࡄࡠࡖࡌࡑࡊ࡙ࡔࡂࡏࡓࠫྤ"):
					eefJ52Dq97M,CUSmz9MtDq = AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"ࠨࡋࡱࡺࡦࡲࡩࡥࠢࡄࡔࡎࠦࡲࡦࡵࡳࡳࡳࡹࡥ࠯ࠩྥ"),-ffXqoLey4TixFJBw
					EoY9Q6eBhyxgndjKUiMrHV = eefJ52Dq97M
	except: EoY9Q6eBhyxgndjKUiMrHV = cdZKMn68Pzg4
	if W5domCu6XrQUFkiPpa3bNLtHglG and isinstance(EoY9Q6eBhyxgndjKUiMrHV,bytes): EoY9Q6eBhyxgndjKUiMrHV = EoY9Q6eBhyxgndjKUiMrHV.decode(vczMIlkCAh2u10B3)
	SsziMZd5UbeL2NRxVpwjO(F0FeocLXmbJhdBwQnS18PCHZIU,dwiIAcPl04ey7Zv38Mz(u"ࠩࡒࡔࡊࡔࡕࡓࡎࡢ࡙ࡗࡒࡌࡊࡄ࡟ࡸࡡࡺࡒࡆࡕࡓࡓࡓ࡙ࡅࠡࠢࡆࡳࡩ࡫࠺ࠡ࡝ࠣࠫྦ")+str(CUSmz9MtDq)+zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"ࠪࠤࡢࠦࠠࠡࡔࡨࡥࡸࡵ࡮࠻ࠢ࡞ࠤࠬྦྷ")+eefJ52Dq97M+aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠫࠥࡣࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭ྨ")+MqpxmkbFcNAvGjVKoHzaw+On1WZJc6dtksqVNgSQ5GBAjuipe(u"ࠬࠦ࡝࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫྩ")+FOkLsAqwop0x3mciC62dRZag8VEGY(sl89FQxXUwVPd,MqpxmkbFcNAvGjVKoHzaw)+zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"࠭ࠠ࡞ࠩྪ"))
	return EoY9Q6eBhyxgndjKUiMrHV
def TEy0KGVDUIZh(VEudZ9gC0ITFc4KhM8Jjw):
	CuXhg2VcIQmwJpPG3SET9A0 = str(EduRM2WTj7xz1.randrange(vbYokBuWlxeLDcdVNM60(u"࠳࠴࠵࠶࠷࠱࠲࠳࠴࠵࠶࠷ᄼ"),WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"࠼࠽࠾࠿࠹࠺࠻࠼࠽࠾࠿࠹ᄽ")))
	mLQyDli741fvgPqcONHba3XrJu09F = {
		uxE8MyoTRglrcaiQf(u"ࠢࡶࡵࡨࡶࡤ࡯ࡤࠣྫ"):lBoFGiJ6DLj72XhueYRms,
		opyTNwHgfqbZREWKU(u"ࠣࡱࡶࡣࡻ࡫ࡲࡴ࡫ࡲࡲࠧྫྷ"):str(m4PjYkEqLcJh),
		ObuCsdoDtKmhPLSMH8YGan(u"ࠤࡤࡴࡵࡥࡶࡦࡴࡶ࡭ࡴࡴࠢྭ"):cWEA5yRl3VqGKk,
		rbUkdYi32PJaRtnxhDvQs(u"ࠥࡨࡪࡼࡩࡤࡧࡢࡪࡦࡳࡩ࡭ࡻࠥྮ"):cWEA5yRl3VqGKk,
		vbYokBuWlxeLDcdVNM60(u"ࠦࡵࡲࡡࡵࡨࡲࡶࡲࠨྯ"): cWEA5yRl3VqGKk,
		f8Ja1q5eO02B(u"ࠧࡩࡡࡳࡴ࡬ࡩࡷࠨྰ"):YnHG75e2QWwo(u"ࠨࡁࡓࡃࡅࡍࡈࡥࡖࡊࡆࡈࡓࡘࠨྱ"),
		LungQF89BqemOb32jJsZlW(u"ࠢࡪࡲࠥྲ"): KNomgGw1kdMCBH(u"ࠣࠦࡵࡩࡲࡵࡴࡦࠤླ"),
		aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠤࠧࡷࡰ࡯ࡰࡠࡷࡶࡩࡷࡥࡰࡳࡱࡳࡩࡷࡺࡩࡦࡵࡢࡷࡾࡴࡣࠣྴ"):ksTLSoVGg0ht
	}
	pPJUHDEModQzR1ArOswXt84FBW9Kj = []
	for pxJ5fy4tNOXYv7kRHL1A in VEudZ9gC0ITFc4KhM8Jjw:
		PoYcBIQdtagh = mLQyDli741fvgPqcONHba3XrJu09F.copy()
		PoYcBIQdtagh[AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"ࠪࡩࡻ࡫࡮ࡵࡡࡷࡽࡵ࡫ࠧྵ")] = pxJ5fy4tNOXYv7kRHL1A
		PoYcBIQdtagh[zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"ࠫࡪࡼࡥ࡯ࡶࡢࡴࡷࡵࡰࡦࡴࡷ࡭ࡪࡹࠧྶ")] = {WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠧࡋࡶࡦࡰࡷࡣࡓࡧ࡭ࡦࠤྷ"):pxJ5fy4tNOXYv7kRHL1A}
		PoYcBIQdtagh[Rsdai9xIEPcpuBMKOUwkTA05q(u"࠭ࡵࡴࡧࡵࡣࡵࡸ࡯ࡱࡧࡵࡸ࡮࡫ࡳࠨྸ")] = {SGazRxP3yBKZ15ILuch(u"ࠢࡖࡵࡨࡶࡤࡋࡶࡦࡰࡷࡣࡓࡧ࡭ࡦࠤྐྵ"):pxJ5fy4tNOXYv7kRHL1A}
		pPJUHDEModQzR1ArOswXt84FBW9Kj.append(PoYcBIQdtagh)
	oGBLR5vmhyqPrKaECQSi67wTF2Z1uM = {
		KNomgGw1kdMCBH(u"ࠣࡣࡳ࡭ࡤࡱࡥࡺࠤྺ"):LJPOQNK1mcG(u"ࠩ࠵࠹࠹ࡪࡤ࠴ࡣ࠷࠴࠾ࡪ࠸ࡣ࠸࠻࠵ࡩ࠺ࡥ࠲࠳࠺ࡩࡪ࠽࠸ࡤࡧࡥࡪ࠷࠿ࠧྻ"),
		dwiIAcPl04ey7Zv38Mz(u"ࠥ࡭ࡳࡹࡥࡳࡶࡢ࡭ࡩࠨྼ"):CuXhg2VcIQmwJpPG3SET9A0,
		LungQF89BqemOb32jJsZlW(u"ࠦࡪࡼࡥ࡯ࡶࡶࠦ྽"): pPJUHDEModQzR1ArOswXt84FBW9Kj
	}
	RR0LtrMn1qPF = {YnHG75e2QWwo(u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ྾"):dwiIAcPl04ey7Zv38Mz(u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳࡯ࡹ࡯࡯ࠩ྿")}
	mrcsT4vGxI6o7PMayUkHdtEZXB = LJPOQNK1mcG(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡳ࡭࠷࠴ࡡ࡮ࡲ࡯࡭ࡹࡻࡤࡦ࠰ࡦࡳࡲ࠵࠲࠰ࡪࡷࡸࡵࡧࡰࡪࠩ࿀")
	j0vTEXldqw = ejdgsCZmQ3DPLEBtx8(zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"ࠨࡒࡒࡗ࡙࠭࿁"),mrcsT4vGxI6o7PMayUkHdtEZXB,oGBLR5vmhyqPrKaECQSi67wTF2Z1uM,RR0LtrMn1qPF,S5fhsRT8JV(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡗࡊࡔࡄࡠࡃࡑࡅࡑ࡟ࡔࡊࡅࡖࡣࡊ࡜ࡅࡏࡖࡖ࠱࠶ࡹࡴࠨ࿂"))
	return j0vTEXldqw
def NMAB08i9gIuUxVCjoEcrm3e6F(GPQMxB3doa9fA6HF7Ene):
	rFCvwoO7AtMp = ffUFBJQ57j2XgoGeOLn9uwpC.sub(YnHG75e2QWwo(u"ࡵࠫ࠭ࡢࡳࠪࠤࠫࡠࡼ࠯ࠧ࿃"), AiCor1fIVTDxQUWwHe9vPR7(u"ࡶࠬࡢ࠱࡝࡞ࠥࡠ࠷࠭࿄"), GPQMxB3doa9fA6HF7Ene)
	rFCvwoO7AtMp = ffUFBJQ57j2XgoGeOLn9uwpC.sub(uxE8MyoTRglrcaiQf(u"ࡷ࠭ࠨ࡝ࡹࠬࠦ࠭ࡢࡳࠪࠩ࿅"), LungQF89BqemOb32jJsZlW(u"ࡸࠧ࡝࠳࡟ࡠࠧࡢ࠲ࠨ࿆"), rFCvwoO7AtMp)
	rFCvwoO7AtMp = ffUFBJQ57j2XgoGeOLn9uwpC.sub(Rsdai9xIEPcpuBMKOUwkTA05q(u"ࡲࠨࠪ࡟ࡻ࠮ࠨࠨ࡝ࡹࠬࠫ࿇"), SGazRxP3yBKZ15ILuch(u"ࡳࠩ࡟࠵ࡡࡢࠢ࡝࠴ࠪ࿈"), rFCvwoO7AtMp)
	rFCvwoO7AtMp = ffUFBJQ57j2XgoGeOLn9uwpC.sub(vbYokBuWlxeLDcdVNM60(u"ࡴࠪࠬࡡࡹࠩࠣࠪ࡟ࡷ࠮࠭࿉"), YnHG75e2QWwo(u"ࡵࠫࡡ࠷࡜࡝ࠤ࡟࠶ࠬ࿊"), rFCvwoO7AtMp)
	rFCvwoO7AtMp = ffUFBJQ57j2XgoGeOLn9uwpC.sub(iRfoNckJs7Ibxzh5j92w8DSWF(u"ࡶࠧ࠮࡜ࡴࠫࠪࠬࡡࡽࠩࠣ࿋"), On1WZJc6dtksqVNgSQ5GBAjuipe(u"ࡷࠨ࡜࠲࡞࡟ࠫࡡ࠸ࠢ࿌"), rFCvwoO7AtMp)
	rFCvwoO7AtMp = ffUFBJQ57j2XgoGeOLn9uwpC.sub(vbYokBuWlxeLDcdVNM60(u"ࡸࠢࠩ࡞ࡺ࠭ࠬ࠮࡜ࡴࠫࠥ࿍"), vbYokBuWlxeLDcdVNM60(u"ࡲࠣ࡞࠴ࡠࡡ࠭࡜࠳ࠤ࿎"), rFCvwoO7AtMp)
	rFCvwoO7AtMp = ffUFBJQ57j2XgoGeOLn9uwpC.sub(TtyzcuW45VKA(u"ࡳࠤࠫࡠࡼ࠯ࠧࠩ࡞ࡺ࠭ࠧ࿏"), f8Ja1q5eO02B(u"ࡴࠥࡠ࠶ࡢ࡜ࠨ࡞࠵ࠦ࿐"), rFCvwoO7AtMp)
	rFCvwoO7AtMp = ffUFBJQ57j2XgoGeOLn9uwpC.sub(rbUkdYi32PJaRtnxhDvQs(u"ࡵࠦ࠭ࡢࡳࠪࠩࠫࡠࡸ࠯ࠢ࿑"), YnHG75e2QWwo(u"ࡶࠧࡢ࠱࡝࡞ࠪࡠ࠷ࠨ࿒"), rFCvwoO7AtMp)
	u8pajlIr5MOtXYhqVzwcfsRA = vbYokBuWlxeLDcdVNM60(u"ࡷ࡛࠭࡝࡝࡟ࡡࢀࢃࠨࠪ࠼࠯ࡡࠬ࿓")
	rFCvwoO7AtMp = ffUFBJQ57j2XgoGeOLn9uwpC.sub(KNomgGw1kdMCBH(u"ࡸࠧࠩ࡞ࡺ࠭࠭࠭࿔") + u8pajlIr5MOtXYhqVzwcfsRA + S5fhsRT8JV(u"ࡲࠨࠫࠫࡠࡼ࠯ࠧ࿕"), SGazRxP3yBKZ15ILuch(u"ࡳࠩ࡟࠵ࡡࡢ࡜࠳࡞࠶ࠫ࿖"), rFCvwoO7AtMp)
	rFCvwoO7AtMp = ffUFBJQ57j2XgoGeOLn9uwpC.sub(KNomgGw1kdMCBH(u"ࡴࠪࠬࡡࡹࠩࠩࠩ࿗") + u8pajlIr5MOtXYhqVzwcfsRA + aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࡵࠫ࠮࠮࡜ࡸࠫࠪ࿘"), Rsdai9xIEPcpuBMKOUwkTA05q(u"ࡶࠬࡢ࠱࡝࡞࡟࠶ࡡ࠹ࠧ࿙"), rFCvwoO7AtMp)
	rFCvwoO7AtMp = ffUFBJQ57j2XgoGeOLn9uwpC.sub(AiCor1fIVTDxQUWwHe9vPR7(u"ࡷ࠭ࠨ࡝ࡹࠬࠬࠬ࿚") + u8pajlIr5MOtXYhqVzwcfsRA + rbUkdYi32PJaRtnxhDvQs(u"ࡸࠧࠪࠪ࡟ࡷ࠮࠭࿛"), Rsdai9xIEPcpuBMKOUwkTA05q(u"ࡲࠨ࡞࠴ࡠࡡࡢ࠲࡝࠵ࠪ࿜"), rFCvwoO7AtMp)
	rFCvwoO7AtMp = ffUFBJQ57j2XgoGeOLn9uwpC.sub(xN4fKmsnyM3Y2(u"ࡳࠩࠫࡠࡸ࠯ࠨࠨ࿝") + u8pajlIr5MOtXYhqVzwcfsRA + LJPOQNK1mcG(u"ࡴࠪ࠭࠭ࡢࡳࠪࠩ࿞"), LJPOQNK1mcG(u"ࡵࠫࡡ࠷࡜࡝࡞࠵ࡠ࠸࠭࿟"), rFCvwoO7AtMp)
	rFCvwoO7AtMp = ffUFBJQ57j2XgoGeOLn9uwpC.sub(AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"ࡶࠬ࠮࡜ࡸࠫ࡟ࡠ࠭ࡢࡷࠪࠩ࿠"), uxE8MyoTRglrcaiQf(u"ࡷ࠭࡜࠲࡞࡟ࡠࡡࡢ࠲ࠨ࿡"), rFCvwoO7AtMp)
	return rFCvwoO7AtMp
def lMeKd3hC6cmS(vuqDWMFGiskPfR63oT1,Nie3gG9w5JbZst204UpjTr):
	Nie3gG9w5JbZst204UpjTr = Nie3gG9w5JbZst204UpjTr.replace(LungQF89BqemOb32jJsZlW(u"࠭࡮ࡶ࡮࡯ࠫ࿢"),s8fcjBCSMxzAIkZQbJPga(u"ࠧࡏࡱࡱࡩࠬ࿣"))
	Nie3gG9w5JbZst204UpjTr = Nie3gG9w5JbZst204UpjTr.replace(zDek1IW37rq6UoKdwyRiAVpF(u"ࠨࡶࡵࡹࡪ࠭࿤"),AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"ࠩࡗࡶࡺ࡫ࠧ࿥"))
	Nie3gG9w5JbZst204UpjTr = Nie3gG9w5JbZst204UpjTr.replace(opyTNwHgfqbZREWKU(u"ࠪࡪࡦࡲࡳࡦࠩ࿦"),k5oIaYyp2mnrLK49qhzS(u"ࠫࡋࡧ࡬ࡴࡧࠪ࿧"))
	Nie3gG9w5JbZst204UpjTr = Nie3gG9w5JbZst204UpjTr.replace(NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠬࡢ࠯ࠨ࿨"),KCQExdbYFqM)
	Nie3gG9w5JbZst204UpjTr = Nie3gG9w5JbZst204UpjTr.replace(tRnTydV03Xfi7rbQ(u"࠭࡜ࡳࠩ࿩"),tRnTydV03Xfi7rbQ(u"ࠧ࡝࡞ࡵࠫ࿪")).replace(SGazRxP3yBKZ15ILuch(u"ࠨ࡞ࡱࠫ࿫"),nfg30bHwd4aNV12SR7UjFck(u"ࠩ࡟ࡠࡳ࠭࿬"))
	IqyuT209eZswbLOklaQiSz,ChlTZv7fx35BLjUAuI8X0yrW2gzYPJ = [],[]
	import ast as QaNtnvm48u32bzGW6odfS7EhUL
	try: IqyuT209eZswbLOklaQiSz = QaNtnvm48u32bzGW6odfS7EhUL.literal_eval(Nie3gG9w5JbZst204UpjTr)
	except:
		try:
			Nie3gG9w5JbZst204UpjTr = NMAB08i9gIuUxVCjoEcrm3e6F(Nie3gG9w5JbZst204UpjTr)
			IqyuT209eZswbLOklaQiSz = QaNtnvm48u32bzGW6odfS7EhUL.literal_eval(Nie3gG9w5JbZst204UpjTr)
		except:
			items = ffUFBJQ57j2XgoGeOLn9uwpC.findall(opyTNwHgfqbZREWKU(u"ࡵࠫࡡࡡ࡛࡟࡞ࡠࡡ࠯ࡢ࡝ࡽ࡞ࡾ࡟ࡣࢃ࡝ࠫ࡞ࢀࢀࡡ࠮࡛࡟ࠫࡠ࠮ࡡ࠯ࡼ࡜ࡠ࠯ࡠࡠࡢ࡝࡞࠭ࠪ࿭"),Nie3gG9w5JbZst204UpjTr.strip(TtyzcuW45VKA(u"ࠫࡠࡣࠧ࿮")))
			if items:
				for HYBN2AQsjimSMgT8OvE3ynX67tJwR in items:
					try: IqyuT209eZswbLOklaQiSz.append(QaNtnvm48u32bzGW6odfS7EhUL.literal_eval(HYBN2AQsjimSMgT8OvE3ynX67tJwR))
					except: ChlTZv7fx35BLjUAuI8X0yrW2gzYPJ.append(HYBN2AQsjimSMgT8OvE3ynX67tJwR)
			else: IqyuT209eZswbLOklaQiSz = HMxzS0Jf69trLk(vuqDWMFGiskPfR63oT1)
	return IqyuT209eZswbLOklaQiSz
def MDhidRHra87PO3I1():
	ppWtKTjVzdQwmoqNi7E,YkqWMTnVUjh1rQaXpG8LR7xo,mrcsT4vGxI6o7PMayUkHdtEZXB,VvpotnYyg78jbBiuHZADl0mcRE,fh6qmOxoiv1UPXZanLprDeMI8,aOZ3yVnsNlB974pR,ttFj9PmIcsuGpzib3aS,x8FkISpTrmqPJe2nvZOWU7zuNcj,g8tTFcBGwdKlo42LUkW = AanhLX36W9emBvK(I4sncq6lxyDa03Gr5B)
	a6ihlXO2CxHKrTuoknwzQ3cPBNGULj = ffUFBJQ57j2XgoGeOLn9uwpC.findall(AiCor1fIVTDxQUWwHe9vPR7(u"ࠬࡢࡤ࡝ࡦ࠽ࡠࡩࡢࡤࠡ࡞࡞࠳ࡈࡕࡌࡐࡔ࡟ࡡࠬ࿯"),YkqWMTnVUjh1rQaXpG8LR7xo,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if a6ihlXO2CxHKrTuoknwzQ3cPBNGULj: YkqWMTnVUjh1rQaXpG8LR7xo = YkqWMTnVUjh1rQaXpG8LR7xo.split(a6ihlXO2CxHKrTuoknwzQ3cPBNGULj[nnsBpJv6XL3OzHoe4Vuhr],hiuZa0PIsErm6UC7)[hiuZa0PIsErm6UC7]
	nj23Bb8VLKX = bD7kJZhMCdaqF68P45KlNIgO1.strftime(tRnTydV03Xfi7rbQ(u"࠭࡟ࠦ࡯࠱ࠩࡩࡥࠥࡉ࠼ࠨࡑࡤ࠭࿰"),bD7kJZhMCdaqF68P45KlNIgO1.localtime(BbIVuS4KecnqNvZz5GptR))
	YkqWMTnVUjh1rQaXpG8LR7xo = YkqWMTnVUjh1rQaXpG8LR7xo+nj23Bb8VLKX
	CQpgO980c57WrijoU6tb = ppWtKTjVzdQwmoqNi7E,YkqWMTnVUjh1rQaXpG8LR7xo,mrcsT4vGxI6o7PMayUkHdtEZXB,VvpotnYyg78jbBiuHZADl0mcRE,fh6qmOxoiv1UPXZanLprDeMI8,aOZ3yVnsNlB974pR,ttFj9PmIcsuGpzib3aS,x8FkISpTrmqPJe2nvZOWU7zuNcj,g8tTFcBGwdKlo42LUkW
	YLv6zoPid2Tj = {}
	try:
		if YRESXadfbIy3khwqmL8WC.path.exists(S93PERpNHcQlu1gKyAFr):
			x8GSilV5efz = open(S93PERpNHcQlu1gKyAFr,AiCor1fIVTDxQUWwHe9vPR7(u"ࠧࡳࡤࠪ࿱")).read()
			if x8GSilV5efz:
				if W5domCu6XrQUFkiPpa3bNLtHglG: x8GSilV5efz = x8GSilV5efz.decode(vczMIlkCAh2u10B3)
				YLv6zoPid2Tj = lMeKd3hC6cmS(YnHG75e2QWwo(u"ࠨࡦ࡬ࡧࡹ࠭࿲"),x8GSilV5efz)
		fbcMqO63BUlQRNIPjzdKgJaCLiwD9 = {}
		for kkWsxE9ZNQlu in YLv6zoPid2Tj:
			if kkWsxE9ZNQlu!=ppWtKTjVzdQwmoqNi7E: fbcMqO63BUlQRNIPjzdKgJaCLiwD9[kkWsxE9ZNQlu] = YLv6zoPid2Tj[kkWsxE9ZNQlu]
			else:
				if YkqWMTnVUjh1rQaXpG8LR7xo and YkqWMTnVUjh1rQaXpG8LR7xo!=tRnTydV03Xfi7rbQ(u"ࠩ࠱࠲ࠬ࿳"):
					o2UQwqmWN4M5hIjSBce61DOCVg = YLv6zoPid2Tj[kkWsxE9ZNQlu]
					if CQpgO980c57WrijoU6tb in o2UQwqmWN4M5hIjSBce61DOCVg:
						OMQouSr6t7xL = o2UQwqmWN4M5hIjSBce61DOCVg.index(CQpgO980c57WrijoU6tb)
						del o2UQwqmWN4M5hIjSBce61DOCVg[OMQouSr6t7xL]
					zzXM2q1ErD = [CQpgO980c57WrijoU6tb]+o2UQwqmWN4M5hIjSBce61DOCVg
					zzXM2q1ErD = zzXM2q1ErD[:NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"࠹࠵ᄾ")]
					fbcMqO63BUlQRNIPjzdKgJaCLiwD9[kkWsxE9ZNQlu] = zzXM2q1ErD
				else: fbcMqO63BUlQRNIPjzdKgJaCLiwD9[kkWsxE9ZNQlu] = YLv6zoPid2Tj[kkWsxE9ZNQlu]
		if ppWtKTjVzdQwmoqNi7E not in list(fbcMqO63BUlQRNIPjzdKgJaCLiwD9.keys()): fbcMqO63BUlQRNIPjzdKgJaCLiwD9[ppWtKTjVzdQwmoqNi7E] = [CQpgO980c57WrijoU6tb]
		fbcMqO63BUlQRNIPjzdKgJaCLiwD9 = str(fbcMqO63BUlQRNIPjzdKgJaCLiwD9)
		if W5domCu6XrQUFkiPpa3bNLtHglG: fbcMqO63BUlQRNIPjzdKgJaCLiwD9 = fbcMqO63BUlQRNIPjzdKgJaCLiwD9.encode(vczMIlkCAh2u10B3)
		open(S93PERpNHcQlu1gKyAFr,k5oIaYyp2mnrLK49qhzS(u"ࠪࡻࡧ࠭࿴")).write(fbcMqO63BUlQRNIPjzdKgJaCLiwD9)
	except:
		import WgvHc7lhSL,u4uJhElogI
		WgvHc7lhSL.NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,zDek1IW37rq6UoKdwyRiAVpF(u"ฺ๊ࠫใๅหࠪ࿵"),zDek1IW37rq6UoKdwyRiAVpF(u"ࠬอไษำ้ห๊า้ࠠฮาࠤฺ๊ใๅหࠣ฽๋ีใࠡใํࠤ๊๊แࠡฤัีࠥอไโ์า๎ํํวหࠢ࠱࠲ࠥฮูะ๊ࠢิ์ࠦวๅำึห้ฯࠠิ๊ไࠤฯ฾็าࠢ็็ࠥืำศๆฬࠤศิั๊๋ࠢๅ๏ํวࠡฬึฮ฼๐ูࠡล้ࠤฯำไ้ࠡำ๋ࠥอไๆึๆ่ฮࠦ࠮࠯ࠢะ๎ะ๊ࠦอสࠣว๋ࠦสฯฬสีࠥหๅศࠢศู้ออࠡษ็้้็ࠠฤุ๊้ࠣำ็ࠡฬ่ห๊อࠧ࿶"))
		u4uJhElogI.XKxZDV2zi6m(S93PERpNHcQlu1gKyAFr)
	return
def RV59cpi6BbrlJQuzwCTa(oGBLR5vmhyqPrKaECQSi67wTF2Z1uM):
	if W5domCu6XrQUFkiPpa3bNLtHglG: import urllib.parse as x0EoUQbfrKvu3nJDqHpY4hBTPFiSN
	else: import urllib as x0EoUQbfrKvu3nJDqHpY4hBTPFiSN
	C5G1WeVx98sU40itFJoZEOrwaHbK = x0EoUQbfrKvu3nJDqHpY4hBTPFiSN.urlencode(oGBLR5vmhyqPrKaECQSi67wTF2Z1uM)
	return C5G1WeVx98sU40itFJoZEOrwaHbK
def bmgwWLk3er(N8jUpQxY0rhtDAzbG4kOs9X,source=cdZKMn68Pzg4,ppWtKTjVzdQwmoqNi7E=cdZKMn68Pzg4):
	Hmq6vzsocj8wWg = Aty25FEGpLUbfwKT19vzVm3IsYk(N8jUpQxY0rhtDAzbG4kOs9X)
	if ppWtKTjVzdQwmoqNi7E!=opyTNwHgfqbZREWKU(u"࠭ࡶࡪࡦࡨࡳࠬ࿷") or not Hmq6vzsocj8wWg: return a8wPxrmq1VJyQA(N8jUpQxY0rhtDAzbG4kOs9X,source,ppWtKTjVzdQwmoqNi7E,nnsBpJv6XL3OzHoe4Vuhr)
	status_code,errors = nnsBpJv6XL3OzHoe4Vuhr,cdZKMn68Pzg4
	wwYcmKvo8iHZy3G5tjM = bu6LzUQF7K.Monitor()
	if wwYcmKvo8iHZy3G5tjM.abortRequested(): return dwiIAcPl04ey7Zv38Mz(u"ࠧࡢࡤࡲࡶࡹ࡫ࡤࠨ࿸")
	WUxw4QIBgNlcEL5 = FOkLsAqwop0x3mciC62dRZag8VEGY(N8jUpQxY0rhtDAzbG4kOs9X)
	SsziMZd5UbeL2NRxVpwjO(Q2QMvk3bx0CGJWSUwD,xxd7Xp5lvem(UkXlAzsMcamKJrEIgnxi6bWh)+dwiIAcPl04ey7Zv38Mz(u"ࠨࠢࠣࠤ࡙࡫ࡳࡵ࡫ࡱ࡫ࠥࡼࡩࡥࡧࡲࠤࡱ࡯࡮࡬ࠢࡥࡩ࡫ࡵࡲࡦࠢࡳࡰࡦࡿࡩ࡯ࡩࠣࠤ࡚ࠥࡹࡱࡧ࠽ࠤࡠࠦࠧ࿹")+Hmq6vzsocj8wWg+vbYokBuWlxeLDcdVNM60(u"ࠩࠣࡡࠥࠦࠠࡗ࡫ࡧࡩࡴࡀࠠ࡜ࠢࠪ࿺")+WUxw4QIBgNlcEL5+rbUkdYi32PJaRtnxhDvQs(u"ࠪࠤࡢ࠭࿻"))
	if s8fcjBCSMxzAIkZQbJPga(u"ࠫࢁ࠭࿼") in N8jUpQxY0rhtDAzbG4kOs9X:
		gNrBZD4qnvidHOteUwzA8sk0J, uWNRj18zpiv4baUSqtM = sRAznbuQ5jiN09o4V8tpEYSlG7fe(N8jUpQxY0rhtDAzbG4kOs9X,Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠬࢂࠧ࿽"))
		uWNRj18zpiv4baUSqtM.update({opyTNwHgfqbZREWKU(u"࠭ࡒࡢࡰࡪࡩࠬ࿾"): aar0zhDnJsOTP7EdgR16HIS29(u"ࠧࡣࡻࡷࡩࡸࡃ࠰࠮࠳࠳࠶࠹࠭࿿")})
	else: gNrBZD4qnvidHOteUwzA8sk0J, uWNRj18zpiv4baUSqtM = N8jUpQxY0rhtDAzbG4kOs9X,cdZKMn68Pzg4
	import requests as JVaKHgG2Fy8AIWz
	try:
		xFXEZshQ7qOmN4VPGvnLW6JzHaTpu = JVaKHgG2Fy8AIWz.get(gNrBZD4qnvidHOteUwzA8sk0J, headers=uWNRj18zpiv4baUSqtM, stream=zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"࡙ࡸࡵࡦᅢ"), timeout=vbYokBuWlxeLDcdVNM60(u"࠺ᄿ"))
		status_code = xFXEZshQ7qOmN4VPGvnLW6JzHaTpu.status_code
		xFXEZshQ7qOmN4VPGvnLW6JzHaTpu.close()
	except Exception as BJYR6A1DrHTcvLjsEi: errors = iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠨࠢࠣࠤࠬက")+str(BJYR6A1DrHTcvLjsEi)
	if status_code in [S5fhsRT8JV(u"࠸࠰࠱ᅀ"), s8fcjBCSMxzAIkZQbJPga(u"࠲࠱࠸ᅁ")] and not wwYcmKvo8iHZy3G5tjM.abortRequested():
		SsziMZd5UbeL2NRxVpwjO(Q2QMvk3bx0CGJWSUwD,xxd7Xp5lvem(UkXlAzsMcamKJrEIgnxi6bWh)+AiCor1fIVTDxQUWwHe9vPR7(u"ࠩࠣࠤ࡙ࠥࡵࡤࡥࡨࡩࡩ࡫ࡤࠡࡸࡨࡶ࡮࡬ࡹࡪࡰࡪࠤࡵࡲࡡࡺࠢࡹ࡭ࡩ࡫࡯ࠡ࡮࡬ࡲࡰࠦࠠࠡࡖࡼࡴࡪࡀࠠ࡜ࠢࠪခ")+Hmq6vzsocj8wWg+J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠪࠤࡢࠦࠠࠡࡘ࡬ࡨࡪࡵ࠺ࠡ࡝ࠣࠫဂ")+WUxw4QIBgNlcEL5+HC9xWUMpBQJEuTteAqjd(u"ࠫࠥࡣࠧဃ"))
		RwdymSt2EzHkW3 = nnsBpJv6XL3OzHoe4Vuhr
		return a8wPxrmq1VJyQA(N8jUpQxY0rhtDAzbG4kOs9X,source,ppWtKTjVzdQwmoqNi7E,RwdymSt2EzHkW3)
	SsziMZd5UbeL2NRxVpwjO(E7lrS9VXJF58d2NUAfkvxwjmHM,xxd7Xp5lvem(UkXlAzsMcamKJrEIgnxi6bWh)+ObuCsdoDtKmhPLSMH8YGan(u"ࠬࠦࠠࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡸࡨࡶ࡮࡬ࡹࡪࡰࡪࠤࡵࡲࡡࡺࠢࡹ࡭ࡩ࡫࡯ࠡ࡮࡬ࡲࡰࠦࠠࠡࡖࡼࡴࡪࡀࠠ࡜ࠢࠪင")+Hmq6vzsocj8wWg+HC9xWUMpBQJEuTteAqjd(u"࠭ࠠ࡞ࠢࠣࠤ࡛࡯ࡤࡦࡱ࠽ࠤࡠࠦࠧစ")+WUxw4QIBgNlcEL5+SGazRxP3yBKZ15ILuch(u"ࠧࠡ࡟ࠪဆ")+errors)
	return AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨဇ")
def a8wPxrmq1VJyQA(N8jUpQxY0rhtDAzbG4kOs9X,source=cdZKMn68Pzg4,ppWtKTjVzdQwmoqNi7E=cdZKMn68Pzg4,RwdymSt2EzHkW3=nnsBpJv6XL3OzHoe4Vuhr):
	JrcFwUZ0yQqHzD1vIlS2TR = source not in [S5fhsRT8JV(u"ࠩࡐ࠷࡚࠭ဈ"),NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠪࡍࡕ࡚ࡖࠨဉ")]
	if not ppWtKTjVzdQwmoqNi7E: ppWtKTjVzdQwmoqNi7E = aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠫࡻ࡯ࡤࡦࡱࠪည")
	Jf57ShMIBz8i0XODR,yCYHRmFs0i5cO2vaj7QS = s8fcjBCSMxzAIkZQbJPga(u"ࠬࡩࡡ࡯ࡥࡨࡰࡪࡪࠧဋ"),cdZKMn68Pzg4
	if len(N8jUpQxY0rhtDAzbG4kOs9X)==kzoASbNraPcfgvWJmY9Qu:
		mrcsT4vGxI6o7PMayUkHdtEZXB,BA2vWoqJaIONhHV0GKE,EumZa7AjHeoNMxlUhb0tJXzk = N8jUpQxY0rhtDAzbG4kOs9X
		if BA2vWoqJaIONhHV0GKE: yCYHRmFs0i5cO2vaj7QS = aar0zhDnJsOTP7EdgR16HIS29(u"࠭ࠠࠡࠢࡖࡹࡧࡺࡩࡵ࡮ࡨ࠾ࠥࡡࠠࠨဌ")+BA2vWoqJaIONhHV0GKE+LJPOQNK1mcG(u"ࠧࠡ࡟ࠪဍ")
	else: mrcsT4vGxI6o7PMayUkHdtEZXB,BA2vWoqJaIONhHV0GKE,EumZa7AjHeoNMxlUhb0tJXzk = N8jUpQxY0rhtDAzbG4kOs9X,cdZKMn68Pzg4,cdZKMn68Pzg4
	mrcsT4vGxI6o7PMayUkHdtEZXB = mrcsT4vGxI6o7PMayUkHdtEZXB.replace(Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠨࠧ࠵࠴ࠬဎ"),VBpIH2QSmvDGlA6TO3e)
	Hmq6vzsocj8wWg = Aty25FEGpLUbfwKT19vzVm3IsYk(mrcsT4vGxI6o7PMayUkHdtEZXB)
	WUxw4QIBgNlcEL5 = FOkLsAqwop0x3mciC62dRZag8VEGY(mrcsT4vGxI6o7PMayUkHdtEZXB)
	if source not in [aar0zhDnJsOTP7EdgR16HIS29(u"ࠩࡇࡓ࡜ࡔࡌࡐࡃࡇࠫဏ"),rbUkdYi32PJaRtnxhDvQs(u"ࠪࡍࡕ࡚ࡖࠨတ")]:
		if source!=LungQF89BqemOb32jJsZlW(u"ࠫࡉࡕࡗࡏࡎࡒࡅࡉ࠭ထ"): mrcsT4vGxI6o7PMayUkHdtEZXB = mrcsT4vGxI6o7PMayUkHdtEZXB.replace(VBpIH2QSmvDGlA6TO3e,S5fhsRT8JV(u"ࠬࠫ࠲࠱ࠩဒ"))
		SsziMZd5UbeL2NRxVpwjO(F0FeocLXmbJhdBwQnS18PCHZIU,xxd7Xp5lvem(UkXlAzsMcamKJrEIgnxi6bWh)+NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"࠭ࠠࠡࠢࡓࡶࡪࡶࡡࡳ࡫ࡱ࡫ࠥࡺ࡯ࠡࡲ࡯ࡥࡾ࠵ࡤࡰࡹࡱࡰࡴࡧࡤࠡࡸ࡬ࡨࡪࡵ࡙ࠠࠡࠢ࡭ࡩ࡫࡯࠻ࠢ࡞ࠤࠬဓ")+WUxw4QIBgNlcEL5+LJPOQNK1mcG(u"ࠧࠡ࡟ࠪန")+yCYHRmFs0i5cO2vaj7QS)
		if Hmq6vzsocj8wWg==nfg30bHwd4aNV12SR7UjFck(u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧပ") and source not in [NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠩࡌࡔ࡙࡜ࠧဖ"),ObuCsdoDtKmhPLSMH8YGan(u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫဗ")]:
			import RgJNGc7YMP,WgvHc7lhSL
			lycT0JB1noerD5YANK2PbHa8QVM,pcX7zxFRmsADwUr = RgJNGc7YMP.ek1pl9vDTX8HnjwUCJ6PQBsmfg4ZMq(source,mrcsT4vGxI6o7PMayUkHdtEZXB)
			XXrQ8Py5ALS4YugjVsi9e = len(pcX7zxFRmsADwUr)
			if XXrQ8Py5ALS4YugjVsi9e>hiuZa0PIsErm6UC7:
				AS6jLpMwW5Ql3kUFNfT = WgvHc7lhSL.NAfHLMC8Ip64FmT7l5oJWXaq3hK(opyTNwHgfqbZREWKU(u"ࠫฬิสาࠢส่๊๊แࠡษ็้๋อำษ࠼ࠣࠬࠬဘ")+str(XXrQ8Py5ALS4YugjVsi9e)+On1WZJc6dtksqVNgSQ5GBAjuipe(u"ࠬࠦๅๅใࠬࠫမ"), lycT0JB1noerD5YANK2PbHa8QVM)
				if AS6jLpMwW5Ql3kUFNfT==-hiuZa0PIsErm6UC7:
					WgvHc7lhSL.bJqPkYBXsenxTRwKu(liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"࠭ลๅ฼สลࠥ฿ๅๅ์ฬࠤฯฺฺ๋ๆࠣห้็๊ะ์๋ࠫယ"),S5fhsRT8JV(u"ࠧࡄࡣࡱࡧࡪࡲࠧရ"))
					return Jf57ShMIBz8i0XODR
			else: AS6jLpMwW5Ql3kUFNfT = nnsBpJv6XL3OzHoe4Vuhr
			mrcsT4vGxI6o7PMayUkHdtEZXB = pcX7zxFRmsADwUr[AS6jLpMwW5Ql3kUFNfT]
			if lycT0JB1noerD5YANK2PbHa8QVM[nnsBpJv6XL3OzHoe4Vuhr]!=xN4fKmsnyM3Y2(u"ࠨ࠯࠴ࠫလ"):
				SsziMZd5UbeL2NRxVpwjO(F0FeocLXmbJhdBwQnS18PCHZIU,xxd7Xp5lvem(UkXlAzsMcamKJrEIgnxi6bWh)+KNomgGw1kdMCBH(u"ࠩࠣࠤࠥ࡜ࡩࡥࡧࡲࠤࡘ࡫࡬ࡦࡥࡷࡩࡩࠦࠠࠡࡕࡨࡰࡪࡩࡴࡪࡱࡱ࠾ࠥࡡࠠࠨဝ")+lycT0JB1noerD5YANK2PbHa8QVM[AS6jLpMwW5Ql3kUFNfT]+J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠪࠤࡢࠦࠠࠡࡘ࡬ࡨࡪࡵ࠺ࠡ࡝ࠣࠫသ")+WUxw4QIBgNlcEL5+zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"ࠫࠥࡣࠧဟ"))
		if nfg30bHwd4aNV12SR7UjFck(u"ࠬ࠵ࡩࡧ࡫࡯ࡱ࠴࠭ဠ") in mrcsT4vGxI6o7PMayUkHdtEZXB: mrcsT4vGxI6o7PMayUkHdtEZXB = mrcsT4vGxI6o7PMayUkHdtEZXB+LJPOQNK1mcG(u"࠭ࡼࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࡁࠫ࠭အ")
		elif f8Ja1q5eO02B(u"ࠧࡩࡶࡷࡴࠬဢ") in mrcsT4vGxI6o7PMayUkHdtEZXB.lower() and NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠨ࠱ࡧࡥࡸ࡮࠯ࠨဣ") not in mrcsT4vGxI6o7PMayUkHdtEZXB and vbYokBuWlxeLDcdVNM60(u"ࠩ࠴࠶࠼࠴࠰࠯࠲࠱࠵ࠬဤ") not in mrcsT4vGxI6o7PMayUkHdtEZXB:
			mrcsT4vGxI6o7PMayUkHdtEZXB = mrcsT4vGxI6o7PMayUkHdtEZXB+SGazRxP3yBKZ15ILuch(u"ࠪࢀࠬဥ") if KNomgGw1kdMCBH(u"ࠫࢁ࠭ဦ") not in mrcsT4vGxI6o7PMayUkHdtEZXB else mrcsT4vGxI6o7PMayUkHdtEZXB+S5fhsRT8JV(u"ࠬࠬࠧဧ")
			if vbYokBuWlxeLDcdVNM60(u"࠭ࡶࡦࡴ࡬ࡪࡾࡶࡥࡦࡴࡀࠫဨ") not in mrcsT4vGxI6o7PMayUkHdtEZXB and ObuCsdoDtKmhPLSMH8YGan(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࠩဩ") in mrcsT4vGxI6o7PMayUkHdtEZXB.lower(): mrcsT4vGxI6o7PMayUkHdtEZXB += YnHG75e2QWwo(u"ࠨࡸࡨࡶ࡮࡬ࡹࡱࡧࡨࡶࡂ࡬ࡡ࡭ࡵࡨࠪࠬဪ")
			if HC9xWUMpBQJEuTteAqjd(u"ࠩࡸࡷࡪࡸ࠭ࡢࡩࡨࡲࡹࡃࠧါ") not in mrcsT4vGxI6o7PMayUkHdtEZXB.lower() and source not in [iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠪࡍࡕ࡚ࡖࠨာ"),ObuCsdoDtKmhPLSMH8YGan(u"ࠫࡒ࠹ࡕࠨိ")]: mrcsT4vGxI6o7PMayUkHdtEZXB += YnHG75e2QWwo(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ࠿ࡐࡳࡿ࡯࡬࡭ࡣ࠲࠹࠳࠶࡙ࠠࠩ࡬ࡲࡩࡵࡷࡴࠢࡑࡘࠥ࠷࠰࠯࠲࠾ࠤ࡜࡯࡮࠷࠶࠾ࠤࡽ࠼࠴࠼ࠢࡵࡺ࠿࠷࠲࠷࠰࠳࠭ࠫ࠭ီ")
			if KNomgGw1kdMCBH(u"࠭ࡲࡦࡨࡨࡶࡪࡸ࠽ࠨု") not in mrcsT4vGxI6o7PMayUkHdtEZXB.lower(): mrcsT4vGxI6o7PMayUkHdtEZXB += k5oIaYyp2mnrLK49qhzS(u"ࠧࡓࡧࡩࡩࡷ࡫ࡲ࠾ࡪࡷࡸࡵࠬࠧူ")
			if zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"ࠨࡣࡦࡧࡪࡶࡴ࠮࡮ࡤࡲ࡬ࡻࡡࡨࡧࡀࠫေ") not in mrcsT4vGxI6o7PMayUkHdtEZXB.lower(): mrcsT4vGxI6o7PMayUkHdtEZXB += TtyzcuW45VKA(u"ࠩࡄࡧࡨ࡫ࡰࡵ࠯ࡏࡥࡳ࡭ࡵࡢࡩࡨࡁࡪࡴࠬࡢࡴ࠾ࡵࡂ࠶࠮࠺ࠨࠪဲ")
	SsziMZd5UbeL2NRxVpwjO(Q2QMvk3bx0CGJWSUwD,xxd7Xp5lvem(UkXlAzsMcamKJrEIgnxi6bWh)+rbUkdYi32PJaRtnxhDvQs(u"ࠪࠤࠥࠦࡇࡰࡶࠣࡪ࡮ࡴࡡ࡭ࠢࡸࡶࡱࠦࠠࠡࡘ࡬ࡨࡪࡵ࠺ࠡ࡝ࠣࠫဳ")+WUxw4QIBgNlcEL5+AiCor1fIVTDxQUWwHe9vPR7(u"ࠫࠥࡣࠧဴ"))
	if dwiIAcPl04ey7Zv38Mz(u"ࠬࢂࠧဵ") in mrcsT4vGxI6o7PMayUkHdtEZXB: IFyK05CDtjGNdE1YOrb,r8Yd61s2ZoTHv7XxJIyuih0cQVfjRw = mrcsT4vGxI6o7PMayUkHdtEZXB.split(J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"࠭ࡼࠨံ"))
	else: IFyK05CDtjGNdE1YOrb,r8Yd61s2ZoTHv7XxJIyuih0cQVfjRw = mrcsT4vGxI6o7PMayUkHdtEZXB,cdZKMn68Pzg4
	if EumZa7AjHeoNMxlUhb0tJXzk: u1P73L0UmkA4eaIBbCgZfrvRtJ, edWmVNQEYKUvl43JqkD = ggVJv2FK9cPtmU1W3RE(AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"ࠧࡱ࡮ࡤࡽࡱ࡯ࡳࡵ့ࠩ")+Hmq6vzsocj8wWg,EumZa7AjHeoNMxlUhb0tJXzk,ObuCsdoDtKmhPLSMH8YGan(u"࠲࠲ᅂ"))
	else: u1P73L0UmkA4eaIBbCgZfrvRtJ, edWmVNQEYKUvl43JqkD = ggVJv2FK9cPtmU1W3RE(J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠨࡲ࡯ࡥࡾࡲࡩࡴࡶࠪး")+Hmq6vzsocj8wWg,IFyK05CDtjGNdE1YOrb,LJPOQNK1mcG(u"࠳࠳ᅃ"))
	mrcsT4vGxI6o7PMayUkHdtEZXB = edWmVNQEYKUvl43JqkD+s8fcjBCSMxzAIkZQbJPga(u"ࠩࡿ္ࠫ")+r8Yd61s2ZoTHv7XxJIyuih0cQVfjRw
	j2I7OUlug6z0GVBo = r8rEvwjH91KlNMhIZoAVdpRyWeDfcs.ListItem(path=mrcsT4vGxI6o7PMayUkHdtEZXB)
	Lg45ZyFwYWMQHN7pon82cIz,OkYLqZdu90NAfWbwKB,cLywUFSIArgjp829GJTo4nYa13CMB,f9DvgICeo3cRUm,uuB4WbfiKoQrN3xzjZMO,WVis1E80CcAGxM,CgFsni9VKJW8,tFQjLDJuVIAh52dk7v,tE73rIUmbG = AanhLX36W9emBvK(I4sncq6lxyDa03Gr5B)
	if source not in [NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠪࡈࡔ࡝ࡎࡍࡑࡄࡈ်ࠬ"),HC9xWUMpBQJEuTteAqjd(u"ࠫࡎࡖࡔࡗࠩျ")]:
		xfHEK2LsoeihXGq1Utz6vV = WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯ࡤࡨࡩࡵ࡮ࠨြ") if xicJPb0AW1nsRfH3kCv7 else f8Ja1q5eO02B(u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰࠫွ")
		j2I7OUlug6z0GVBo.setProperty(xfHEK2LsoeihXGq1Utz6vV, cdZKMn68Pzg4)
		j2I7OUlug6z0GVBo.setMimeType(zDek1IW37rq6UoKdwyRiAVpF(u"ࠧ࡮࡫ࡰࡩ࠴ࡾ࠭ࡵࡻࡳࡩࠬှ"))
		if m4PjYkEqLcJh<zDek1IW37rq6UoKdwyRiAVpF(u"࠵࠴ᅄ"): j2I7OUlug6z0GVBo.setInfo(AiCor1fIVTDxQUWwHe9vPR7(u"ࠨࡸ࡬ࡨࡪࡵࠧဿ"),{aar0zhDnJsOTP7EdgR16HIS29(u"ࠩࡰࡩࡩ࡯ࡡࡵࡻࡳࡩࠬ၀"):liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠪࡱࡴࡼࡩࡦࠩ၁")})
		else:
			UixhX3lspfjty = j2I7OUlug6z0GVBo.getVideoInfoTag()
			UixhX3lspfjty.setMediaType(iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠫࡲࡵࡶࡪࡧࠪ၂"))
		j2I7OUlug6z0GVBo.setArt({AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"ࠬࡺࡨࡶ࡯ࡥࠫ၃"):uuB4WbfiKoQrN3xzjZMO,KNomgGw1kdMCBH(u"࠭ࡰࡰࡵࡷࡩࡷ࠭၄"):uuB4WbfiKoQrN3xzjZMO,KNomgGw1kdMCBH(u"ࠧࡣࡣࡱࡲࡪࡸࠧ၅"):uuB4WbfiKoQrN3xzjZMO,WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠨࡨࡤࡲࡦࡸࡴࠨ၆"):uuB4WbfiKoQrN3xzjZMO,zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"ࠩࡦࡰࡪࡧࡲࡢࡴࡷࠫ၇"):uuB4WbfiKoQrN3xzjZMO,Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠪࡧࡱ࡫ࡡࡳ࡮ࡲ࡫ࡴ࠭၈"):uuB4WbfiKoQrN3xzjZMO,opyTNwHgfqbZREWKU(u"ࠫࡱࡧ࡮ࡥࡵࡦࡥࡵ࡫ࠧ၉"):uuB4WbfiKoQrN3xzjZMO,uxE8MyoTRglrcaiQf(u"ࠬ࡯ࡣࡰࡰࠪ၊"):uuB4WbfiKoQrN3xzjZMO})
		if Hmq6vzsocj8wWg in [AiCor1fIVTDxQUWwHe9vPR7(u"࠭࠮࡮ࡲࡧࠫ။"),WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠧ࠯࡯࠶ࡹ࠽࠭၌"),WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠨ࠰ࡰ࠷ࡺ࠭၍")]:
			j2I7OUlug6z0GVBo.setContentLookup(IZQbmFzLHDtXfc)
		else: j2I7OUlug6z0GVBo.setContentLookup(ksTLSoVGg0ht)
		from u4uJhElogI import bMoCAVnTStgik0
		if LJPOQNK1mcG(u"ࠩࡵࡸࡲࡶࠧ၎") in mrcsT4vGxI6o7PMayUkHdtEZXB:
			bMoCAVnTStgik0(nfg30bHwd4aNV12SR7UjFck(u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡴࡷࡱࡵ࠭၏"),ksTLSoVGg0ht)
		elif Hmq6vzsocj8wWg==aar0zhDnJsOTP7EdgR16HIS29(u"ࠫ࠳ࡳࡰࡥࠩၐ") or WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠬ࠵ࡤࡢࡵ࡫࠳ࠬၑ") in mrcsT4vGxI6o7PMayUkHdtEZXB:
			bMoCAVnTStgik0(vbYokBuWlxeLDcdVNM60(u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠭ၒ"),ksTLSoVGg0ht)
			j2I7OUlug6z0GVBo.setProperty(xfHEK2LsoeihXGq1Utz6vV,f8Ja1q5eO02B(u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡧࡤࡢࡲࡷ࡭ࡻ࡫ࠧၓ"))
			j2I7OUlug6z0GVBo.setProperty(YnHG75e2QWwo(u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡡࡥࡣࡳࡸ࡮ࡼࡥ࠯࡯ࡤࡲ࡮࡬ࡥࡴࡶࡢࡸࡾࡶࡥࠨၔ"),nfg30bHwd4aNV12SR7UjFck(u"ࠩࡰࡴࡩ࠭ၕ"))
		if BA2vWoqJaIONhHV0GKE:
			j2I7OUlug6z0GVBo.setSubtitles([BA2vWoqJaIONhHV0GKE])
		if RwdymSt2EzHkW3:
			j2I7OUlug6z0GVBo.setProperty(zDek1IW37rq6UoKdwyRiAVpF(u"ࠪࡖࡪࡹࡵ࡮ࡧࡗ࡭ࡲ࡫ࠧၖ"), str(RwdymSt2EzHkW3))
			j2I7OUlug6z0GVBo.setProperty(liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"࡙ࠫࡵࡴࡢ࡮ࡗ࡭ࡲ࡫ࠧၗ"), dwiIAcPl04ey7Zv38Mz(u"ࠬ࠹࠶࠱࠲ࠪၘ"))
	if ppWtKTjVzdQwmoqNi7E==WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"࠭ࡶࡪࡦࡨࡳࠬၙ") and source==zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"ࠧࡅࡑ࡚ࡒࡑࡕࡁࡅࠩၚ"):
		Jf57ShMIBz8i0XODR = iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠨࡲ࡯ࡥࡾࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨၛ")
		source = HC9xWUMpBQJEuTteAqjd(u"ࠩࡓࡐࡆ࡟࡟ࡅࡎࡢࡊࡎࡒࡅࡔࠩၜ")
	elif ppWtKTjVzdQwmoqNi7E==WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠪࡺ࡮ࡪࡥࡰࠩၝ") and tFQjLDJuVIAh52dk7v.startswith(f8Ja1q5eO02B(u"ࠫ࠻࠭ၞ")):
		Jf57ShMIBz8i0XODR = vbYokBuWlxeLDcdVNM60(u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪࡩ࡯ࡩࠪၟ")
		source = source+NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"࠭࡟ࡅࡎࠪၠ")
	if Jf57ShMIBz8i0XODR!=aar0zhDnJsOTP7EdgR16HIS29(u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥ࡫ࡱ࡫ࠬၡ"): MDhidRHra87PO3I1()
	upxgjER7K9zJOshwbfPyrD8Sovam.Y9edlbQgVnSPFMyBI4wq(source)
	if upxgjER7K9zJOshwbfPyrD8Sovam.uU893JOSZ7fRo1drA: return uxE8MyoTRglrcaiQf(u"ࠨࡤ࡯ࡳࡨࡱࡥࡥࠩၢ")
	u1P73L0UmkA4eaIBbCgZfrvRtJ.start()
	if ppWtKTjVzdQwmoqNi7E==Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠩࡹ࡭ࡩ࡫࡯ࠨၣ") and not tFQjLDJuVIAh52dk7v.startswith(aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠪ࠺ࠬၤ")):
		SsziMZd5UbeL2NRxVpwjO(F0FeocLXmbJhdBwQnS18PCHZIU,xxd7Xp5lvem(UkXlAzsMcamKJrEIgnxi6bWh)+KNomgGw1kdMCBH(u"ࠫࠥࠦࠠࡗ࡫ࡧࡩࡴࠦࡰ࡭ࡣࡼࠤࡺࡹࡩ࡯ࡩࠣࡷࡪࡺࡒࡦࡵࡲࡰࡻ࡫ࡤࡖࡴ࡯ࠬ࠮ࠦࠠࠡࡘ࡬ࡨࡪࡵ࠺ࠡ࡝ࠣࠫၥ")+WUxw4QIBgNlcEL5+KNomgGw1kdMCBH(u"ࠬࠦ࡝ࠨၦ"))
		wOL0lMr7GN2XhT4sdzWSJxoEY.setResolvedUrl(p4TcbiqOXVAyILxQJa1Ks8f5,IZQbmFzLHDtXfc,j2I7OUlug6z0GVBo)
	elif ppWtKTjVzdQwmoqNi7E==Rsdai9xIEPcpuBMKOUwkTA05q(u"࠭࡬ࡪࡸࡨࠫၧ"):
		SsziMZd5UbeL2NRxVpwjO(F0FeocLXmbJhdBwQnS18PCHZIU,xxd7Xp5lvem(UkXlAzsMcamKJrEIgnxi6bWh)+xN4fKmsnyM3Y2(u"ࠧࠡࠢࠣࡐ࡮ࡼࡥࠡࡲ࡯ࡥࡾࠦࡵࡴ࡫ࡱ࡫ࠥࡶ࡬ࡢࡻࠫ࠭ࠥࠦࠠࡗ࡫ࡧࡩࡴࡀࠠ࡜ࠢࠪၨ")+WUxw4QIBgNlcEL5+f8Ja1q5eO02B(u"ࠨࠢࡠࠫၩ"))
		upxgjER7K9zJOshwbfPyrD8Sovam.play(mrcsT4vGxI6o7PMayUkHdtEZXB,j2I7OUlug6z0GVBo)
	Q0AOX4cEgius9e = ksTLSoVGg0ht
	if Jf57ShMIBz8i0XODR==aar0zhDnJsOTP7EdgR16HIS29(u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧ࡭ࡳ࡭ࠧၪ"):
		from p7T2LsjY5f import lLUNFT524ix
		Q0AOX4cEgius9e = lLUNFT524ix(mrcsT4vGxI6o7PMayUkHdtEZXB,Hmq6vzsocj8wWg,source)
		if Q0AOX4cEgius9e: MDhidRHra87PO3I1()
	else:
		PuI26Z0Kthbxze8g1qJOXaMLR7mrQ,Jf57ShMIBz8i0XODR,w9kBFlAp1I8mS3VEGRCWKPgZJ,PjEOUz24pafiHFrX1lcW7JQwLhMI = nnsBpJv6XL3OzHoe4Vuhr,nfg30bHwd4aNV12SR7UjFck(u"ࠪࡸࡷ࡯ࡥࡥࠩၫ"),ksTLSoVGg0ht,f8Ja1q5eO02B(u"࠶ᅅ")
		if JrcFwUZ0yQqHzD1vIlS2TR: import WgvHc7lhSL
		d94zVat1ioyLnmqJ8Z2 = cdZKMn68Pzg4
		while PuI26Z0Kthbxze8g1qJOXaMLR7mrQ<CXwBHcf58s064NoZSvnWk7RMm:
			bu6LzUQF7K.sleep(PjEOUz24pafiHFrX1lcW7JQwLhMI*On1WZJc6dtksqVNgSQ5GBAjuipe(u"࠶࠶࠰࠱ᅆ"))
			PuI26Z0Kthbxze8g1qJOXaMLR7mrQ += PjEOUz24pafiHFrX1lcW7JQwLhMI
			if upxgjER7K9zJOshwbfPyrD8Sovam.uU893JOSZ7fRo1drA==S5fhsRT8JV(u"ࠫࡸࡺࡡࡳࡶࡨࡨࠬၬ") and not w9kBFlAp1I8mS3VEGRCWKPgZJ:
				if JrcFwUZ0yQqHzD1vIlS2TR: WgvHc7lhSL.bJqPkYBXsenxTRwKu(f8Ja1q5eO02B(u"ࠬ์ฬฮฬࠣ฽๊๊๊สࠢศ๎ัอฯࠡษ็ๅ๏ี๊้ࠩၭ"),On1WZJc6dtksqVNgSQ5GBAjuipe(u"࠭ࡓࡶࡥࡦࡩࡸࡹࠧၮ"),bD7kJZhMCdaqF68P45KlNIgO1=xN4fKmsnyM3Y2(u"࠽࠵࠱ᅇ"))
				SsziMZd5UbeL2NRxVpwjO(Q2QMvk3bx0CGJWSUwD,xxd7Xp5lvem(UkXlAzsMcamKJrEIgnxi6bWh)+SGazRxP3yBKZ15ILuch(u"ࠧࠡࠢࠣࡗࡺࡩࡣࡦࡵࡶ࠾ࠥࠦࡖࡪࡦࡨࡳࠥࡹࡴࡢࡴࡷࡩࡩࠦࠠࠡࡘ࡬ࡨࡪࡵ࠺ࠡ࡝ࠣࠫၯ")+WUxw4QIBgNlcEL5+TtyzcuW45VKA(u"ࠨࠢࡠࠫၰ")+yCYHRmFs0i5cO2vaj7QS)
				w9kBFlAp1I8mS3VEGRCWKPgZJ = IZQbmFzLHDtXfc
			elif upxgjER7K9zJOshwbfPyrD8Sovam.uU893JOSZ7fRo1drA in [zDek1IW37rq6UoKdwyRiAVpF(u"ࠩࡳࡰࡦࡿࡩ࡯ࡩࠪၱ"),YnHG75e2QWwo(u"ࠪࡸࡪࡹࡴࡪࡰࡪࠫၲ")]:
				SsziMZd5UbeL2NRxVpwjO(Q2QMvk3bx0CGJWSUwD,xxd7Xp5lvem(UkXlAzsMcamKJrEIgnxi6bWh)+xN4fKmsnyM3Y2(u"ࠫࠥࠦࠠࡔࡷࡦࡧࡪࡹࡳ࠻࡚ࠢࠣ࡮ࡪࡥࡰࠢࡳࡰࡦࡿࡩ࡯ࡩࠣࠤࠥ࡜ࡩࡥࡧࡲ࠾ࠥࡡࠠࠨၳ")+WUxw4QIBgNlcEL5+zDek1IW37rq6UoKdwyRiAVpF(u"ࠬࠦ࡝ࠨၴ")+yCYHRmFs0i5cO2vaj7QS)
				break
			elif upxgjER7K9zJOshwbfPyrD8Sovam.uU893JOSZ7fRo1drA==YnHG75e2QWwo(u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭ၵ"):
				SsziMZd5UbeL2NRxVpwjO(E7lrS9VXJF58d2NUAfkvxwjmHM,xxd7Xp5lvem(UkXlAzsMcamKJrEIgnxi6bWh)+ObuCsdoDtKmhPLSMH8YGan(u"ࠧࠡࠢࠣࡊࡦ࡯࡬ࡦࡦࠣࡴࡱࡧࡹࡪࡰࡪࠤࡻ࡯ࡤࡦࡱࠣࠤࠥ࡜ࡩࡥࡧࡲ࠾ࠥࡡࠠࠨၶ")+WUxw4QIBgNlcEL5+ObuCsdoDtKmhPLSMH8YGan(u"ࠨࠢࡠࠫၷ")+yCYHRmFs0i5cO2vaj7QS)
				if JrcFwUZ0yQqHzD1vIlS2TR: WgvHc7lhSL.bJqPkYBXsenxTRwKu(k5oIaYyp2mnrLK49qhzS(u"ࠩไุ้ะฺࠠ็็๎ฮࠦสี฼ํ่ࠥอไโ์า๎ํ࠭ၸ"),nfg30bHwd4aNV12SR7UjFck(u"ࠪࡊࡦ࡯࡬ࡶࡴࡨࠫၹ"),bD7kJZhMCdaqF68P45KlNIgO1=nfg30bHwd4aNV12SR7UjFck(u"࠷࠶࠲ᅈ"))
				break
			elif upxgjER7K9zJOshwbfPyrD8Sovam.uU893JOSZ7fRo1drA==aar0zhDnJsOTP7EdgR16HIS29(u"ࠫࡧࡲ࡯ࡤ࡭ࡨࡨࠬၺ"):
				SsziMZd5UbeL2NRxVpwjO(z0KNn8M5AxaD,xxd7Xp5lvem(UkXlAzsMcamKJrEIgnxi6bWh)+aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠬࠦࠠࠡࡆࡨࡺ࡮ࡩࡥࠡ࡫ࡶࠤࡧࡲ࡯ࡤ࡭ࡨࡨࠥࠦࠠࡗ࡫ࡧࡩࡴࡀࠠ࡜ࠢࠪၻ")+WUxw4QIBgNlcEL5+liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"࠭ࠠ࡞ࠩၼ"))
				break
			if d94zVat1ioyLnmqJ8Z2!=upxgjER7K9zJOshwbfPyrD8Sovam.uU893JOSZ7fRo1drA:
				Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.setSetting(WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡴࡱࡧࡹࠨၽ"),upxgjER7K9zJOshwbfPyrD8Sovam.uU893JOSZ7fRo1drA)
				d94zVat1ioyLnmqJ8Z2 = upxgjER7K9zJOshwbfPyrD8Sovam.uU893JOSZ7fRo1drA
		else: Jf57ShMIBz8i0XODR = KNomgGw1kdMCBH(u"ࠨࡶ࡬ࡱࡪࡵࡵࡵࠩၾ")
		Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.setSetting(nfg30bHwd4aNV12SR7UjFck(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡶ࡬ࡢࡻࠪၿ"),upxgjER7K9zJOshwbfPyrD8Sovam.uU893JOSZ7fRo1drA)
	if Jf57ShMIBz8i0XODR in [Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠪࡴࡱࡧࡹࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪႀ")] or upxgjER7K9zJOshwbfPyrD8Sovam.uU893JOSZ7fRo1drA in [KNomgGw1kdMCBH(u"ࠫࡵࡲࡡࡺ࡫ࡱ࡫ࠬႁ"),S5fhsRT8JV(u"ࠬࡺࡥࡴࡶ࡬ࡲ࡬࠭ႂ")] or Q0AOX4cEgius9e: yV1hpK79g30lRw(source)
	else: exec(NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"࠭ࡩ࡮ࡲࡲࡶࡹࠦࡸࡣ࡯ࡦ࠿ࡽࡨ࡭ࡤ࠰ࡓࡰࡦࡿࡥࡳࠪࠬ࠲ࡸࡺ࡯ࡱࠪࠬࠫႃ"))
	mf6JUuZVwQNItzMR9CFrOvygepqA = bu6LzUQF7K.Player().isPlaying()
	if not mf6JUuZVwQNItzMR9CFrOvygepqA and Jf57ShMIBz8i0XODR not in [LJPOQNK1mcG(u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥ࡫ࡱ࡫ࠬႄ")]:
		msg = zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"ࠨࡖ࡬ࡱࡪࡵࡵࡵࠩႅ") if Jf57ShMIBz8i0XODR==opyTNwHgfqbZREWKU(u"ࠩࡷ࡭ࡲ࡫࡯ࡶࡶࠪႆ") else ObuCsdoDtKmhPLSMH8YGan(u"࡙ࠪࡳࡱ࡮ࡰࡹࡱࠫႇ")
		if JrcFwUZ0yQqHzD1vIlS2TR: WgvHc7lhSL.bJqPkYBXsenxTRwKu(f8Ja1q5eO02B(u"ࠫๆฺไหࠢ฼้้๐ษࠡฬื฾๏๊ࠠศๆไ๎ิ๐่ࠨႈ"),msg,bD7kJZhMCdaqF68P45KlNIgO1=KNomgGw1kdMCBH(u"࠸࠷࠳ᅉ"))
		SsziMZd5UbeL2NRxVpwjO(E7lrS9VXJF58d2NUAfkvxwjmHM,xxd7Xp5lvem(UkXlAzsMcamKJrEIgnxi6bWh)+s8fcjBCSMxzAIkZQbJPga(u"ࠬࠦࠠࠡࠩႉ")+msg+LJPOQNK1mcG(u"࠭࠺ࠡࠢࡘࡲࡰࡴ࡯ࡸࡰࠣࡴࡷࡵࡢ࡭ࡧࡰࠤࠥࠦࡖࡪࡦࡨࡳ࠿࡛ࠦࠡࠩႊ")+WUxw4QIBgNlcEL5+k5oIaYyp2mnrLK49qhzS(u"ࠧࠡ࡟ࠪႋ")+yCYHRmFs0i5cO2vaj7QS)
	return upxgjER7K9zJOshwbfPyrD8Sovam.uU893JOSZ7fRo1drA
def Aty25FEGpLUbfwKT19vzVm3IsYk(mrcsT4vGxI6o7PMayUkHdtEZXB):
	if KNomgGw1kdMCBH(u"ࠨࡁࠪႌ") in mrcsT4vGxI6o7PMayUkHdtEZXB: mrcsT4vGxI6o7PMayUkHdtEZXB = mrcsT4vGxI6o7PMayUkHdtEZXB.split(tRnTydV03Xfi7rbQ(u"ࠩࡂႍࠫ"))[nnsBpJv6XL3OzHoe4Vuhr]
	if LungQF89BqemOb32jJsZlW(u"ࠪࢀࠬႎ") in mrcsT4vGxI6o7PMayUkHdtEZXB: mrcsT4vGxI6o7PMayUkHdtEZXB = mrcsT4vGxI6o7PMayUkHdtEZXB.split(opyTNwHgfqbZREWKU(u"ࠫࢁ࠭ႏ"))[nnsBpJv6XL3OzHoe4Vuhr]
	path = KCQExdbYFqM.join(mrcsT4vGxI6o7PMayUkHdtEZXB.split(KCQExdbYFqM)[vbYokBuWlxeLDcdVNM60(u"࠵ᅊ"):]) if KNomgGw1kdMCBH(u"ࠬࡀ࠯࠰ࠩ႐") in mrcsT4vGxI6o7PMayUkHdtEZXB else mrcsT4vGxI6o7PMayUkHdtEZXB
	btFMGmJZOzNiYpoH = ffUFBJQ57j2XgoGeOLn9uwpC.findall(k5oIaYyp2mnrLK49qhzS(u"࠭࡜࠯ࠪ࡞ࡥ࠲ࢀ࠰࠮࠻ࡠࡿ࠷࠲࠴ࡾࠫࠪ႑"),path,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if btFMGmJZOzNiYpoH:
		btFMGmJZOzNiYpoH = btFMGmJZOzNiYpoH[-hiuZa0PIsErm6UC7]
		EK2nzP495o3ZaXtIwlOhA = [S5fhsRT8JV(u"ࠧ࡮࠵ࡸ࠼ࠬ႒"),xN4fKmsnyM3Y2(u"ࠨ࡯ࡳ࠸ࠬ႓"),iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠩࡰࡴࡩ࠭႔"),iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠪࡻࡪࡨ࡭ࠨ႕"),J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠫࡦࡼࡩࠨ႖"),vbYokBuWlxeLDcdVNM60(u"ࠬࡧࡡࡤࠩ႗"),aNdix5gq7yeFHTMWhnzm8pX0Y16(u"࠭࡭࠴ࡷࠪ႘"),AiCor1fIVTDxQUWwHe9vPR7(u"ࠧ࡮࡭ࡹࠫ႙"),J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠨࡨ࡯ࡺࠬႚ"),zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"ࠩࡰࡴ࠸࠭ႛ"),rbUkdYi32PJaRtnxhDvQs(u"ࠪࡸࡸ࠭ႜ")]
		if btFMGmJZOzNiYpoH in EK2nzP495o3ZaXtIwlOhA: return s8fcjBCSMxzAIkZQbJPga(u"ࠫ࠳࠭ႝ")+btFMGmJZOzNiYpoH
	return cdZKMn68Pzg4
def yV1hpK79g30lRw(PoYcBIQdtagh):
	if not USuRxnPlV5.tbo8MkxlHv9qwdP6gI1rJzOV3Na: PoYcBIQdtagh += xN4fKmsnyM3Y2(u"ࠬࡥࡔࡔࠩ႞")
	USuRxnPlV5.SEND_THESE_EVENTS.append(PoYcBIQdtagh)
	return
def MF2hUj6YZ9rCcEOqXkBL0f8Pz(xthyMJA94p=ksTLSoVGg0ht):
	df6QHU3Ej8hx17RwJZ5aIz = bu6LzUQF7K.executeJSONRPC(LJPOQNK1mcG(u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥ࡭ࡩࠨ࠺࠲࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡖ࡬ࡢࡻ࡯࡭ࡸࡺ࠮ࡄ࡮ࡨࡥࡷࠨࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡵࡲࡡࡺ࡮࡬ࡷࡹ࡯ࡤࠣ࠼࠴ࢁࢂ࠭႟"))
	FFMEqG9Pbe5uKy680lHIQDhx2Ta(xthyMJA94p,J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠧࡠࡡࡢࡊࡔࡘࡃࡆࡡࡈ࡜ࡎ࡚࡟ࡠࡡࠪႠ"),IZQbmFzLHDtXfc)
	sjVE6XGymcf09qbiKODZdAC.exit()
def FFMEqG9Pbe5uKy680lHIQDhx2Ta(xthyMJA94p,PPrzL3OaoQHM,JuvIbFsth7DQg6Y5MP8xG):
	if PPrzL3OaoQHM:
		if uxE8MyoTRglrcaiQf(u"ࠨࡡࡢࡣࡋࡕࡒࡄࡇࡢࡉ࡝ࡏࡔࡠࡡࡢࠫႡ") in PPrzL3OaoQHM: SsziMZd5UbeL2NRxVpwjO(cdZKMn68Pzg4,f8Ja1q5eO02B(u"ࠩࡢࡣࡤࡌࡏࡓࡅࡈࡣࡊ࡞ࡉࡕࡡࡢࡣࠬႢ"))
		else:
			ucbEmM4SBzRIs = Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.getSetting(LungQF89BqemOb32jJsZlW(u"ࠪࡥࡻ࠴࡬ࡢࡰࡪࡹࡦ࡭ࡥ࠯ࡶࡵࡥࡳࡹ࡬ࡢࡶࡨࠫႣ"))
			Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.setSetting(opyTNwHgfqbZREWKU(u"ࠫࡦࡼ࠮࡭ࡣࡱ࡫ࡺࡧࡧࡦ࠰ࡷࡶࡦࡴࡳ࡭ࡣࡷࡩࠬႤ"),cdZKMn68Pzg4)
			import RgJNGc7YMP
			RgJNGc7YMP.CzSKmItBXnVrORuN1c9Wap(PPrzL3OaoQHM)
			Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.setSetting(zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"ࠬࡧࡶ࠯࡮ࡤࡲ࡬ࡻࡡࡨࡧ࠱ࡸࡷࡧ࡮ࡴ࡮ࡤࡸࡪ࠭Ⴅ"),ucbEmM4SBzRIs)
	HOPNDidJLzCxeK7IXS = Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.getSetting(k5oIaYyp2mnrLK49qhzS(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡵࡩ࡫ࡸࡥࡴࡪࠪႦ"))
	if HOPNDidJLzCxeK7IXS==WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠧࡓࡇࡔ࡙ࡊ࡙ࡔࡠࡔࡈࡊࡗࡋࡓࡉࡡࡆࡅࡈࡎࡅࠨႧ"): Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.setSetting(NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡷ࡫ࡦࡳࡧࡶ࡬ࠬႨ"),HC9xWUMpBQJEuTteAqjd(u"ࠩࡕࡉࡋࡘࡅࡔࡊࡢࡇࡆࡉࡈࡆࠩႩ"))
	elif HOPNDidJLzCxeK7IXS==tRnTydV03Xfi7rbQ(u"ࠪࡖࡊࡌࡒࡆࡕࡋࡣࡈࡇࡃࡉࡇࠪႪ"): Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.setSetting(LJPOQNK1mcG(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡳࡧࡩࡶࡪࡹࡨࠨႫ"),cdZKMn68Pzg4)
	if Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.getSetting(LungQF89BqemOb32jJsZlW(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡷࡶࡩࡩࡴࡳࠨႬ")) not in [AiCor1fIVTDxQUWwHe9vPR7(u"࠭ࡁࡖࡖࡒࠫႭ"),Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠧࡔࡖࡒࡔࠬႮ"),SGazRxP3yBKZ15ILuch(u"ࠨࡃࡖࡏࠬႯ")]: Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.setSetting(TtyzcuW45VKA(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡦࡱࡷࠬႰ"),J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠪࡅࡘࡑࠧႱ"))
	if Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.getSetting(On1WZJc6dtksqVNgSQ5GBAjuipe(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡵࡨࡴࡷࡵࡸࡺࠩႲ")) not in [xN4fKmsnyM3Y2(u"ࠬࡇࡕࡕࡑࠪႳ"),aNdix5gq7yeFHTMWhnzm8pX0Y16(u"࠭ࡓࡕࡑࡓࠫႴ"),LungQF89BqemOb32jJsZlW(u"ࠧࡂࡕࡎࠫႵ")]: Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.setSetting(f8Ja1q5eO02B(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡺࡹࡥࡱࡴࡲࡼࡾ࠭Ⴖ"),liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠩࡄࡗࡐ࠭Ⴗ"))
	NNdq1bS3isAWUj4 = Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.getSetting(uxE8MyoTRglrcaiQf(u"ࠪࡥࡻ࠴࡭ࡺࡵ࡮࡭ࡳ࠴ࡶࡪࡧࡺࡱࡴࡪࡥࠨႸ"))
	cEdehCpqROmNkiKTt2Hu5XQ3 = bu6LzUQF7K.executeJSONRPC(ObuCsdoDtKmhPLSMH8YGan(u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡗࡪࡺࡴࡪࡰࡪࡷ࠳ࡍࡥࡵࡕࡨࡸࡹ࡯࡮ࡨࡘࡤࡰࡺ࡫ࠢ࠭ࠤ࡬ࡨࠧࡀ࠱࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡹࡥࡵࡶ࡬ࡲ࡬ࠨ࠺ࠣ࡮ࡲࡳࡰࡧ࡮ࡥࡨࡨࡩࡱ࠴ࡳ࡬࡫ࡱࠦࢂࢃࠧႹ"))
	if uxE8MyoTRglrcaiQf(u"ࠬࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇࠫႺ") in str(cEdehCpqROmNkiKTt2Hu5XQ3) and NNdq1bS3isAWUj4 in [LungQF89BqemOb32jJsZlW(u"࠭ࡅࡎࡃࡇࠤࡑ࡯ࡳࡵࠩႻ"),Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠧࡆࡏࡄࡈࠥࡍࡡ࡭࡮ࡨࡶࡾ࠭Ⴜ")]:
		bD7kJZhMCdaqF68P45KlNIgO1.sleep(zDek1IW37rq6UoKdwyRiAVpF(u"࠳࠲࠶࠶࠰ᅋ"))
		bu6LzUQF7K.executebuiltin(J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡘ࡫ࡴࡗ࡫ࡨࡻࡒࡵࡤࡦࠪ࠳࠭ࠬႽ"))
	if nnsBpJv6XL3OzHoe4Vuhr and p4TcbiqOXVAyILxQJa1Ks8f5>-hiuZa0PIsErm6UC7:
		wOL0lMr7GN2XhT4sdzWSJxoEY.setResolvedUrl(p4TcbiqOXVAyILxQJa1Ks8f5,ksTLSoVGg0ht,r8rEvwjH91KlNMhIZoAVdpRyWeDfcs.ListItem())
		Q0AOX4cEgius9e,lL5OuN4iCTj,ThatxXpCKGP3jsNeUw = ksTLSoVGg0ht,ksTLSoVGg0ht,ksTLSoVGg0ht
		wOL0lMr7GN2XhT4sdzWSJxoEY.endOfDirectory(p4TcbiqOXVAyILxQJa1Ks8f5,Q0AOX4cEgius9e,lL5OuN4iCTj,ThatxXpCKGP3jsNeUw)
	if USuRxnPlV5.SEND_THESE_EVENTS: TEy0KGVDUIZh(USuRxnPlV5.SEND_THESE_EVENTS)
	gseLWGk7iEnvS2po = MexD9yTpd8UugjOcIkz()
	dNosE0aMjWHXP4(LungQF89BqemOb32jJsZlW(u"ࠩࡶࡸࡴࡶࠧႾ"),JuvIbFsth7DQg6Y5MP8xG)
	if gseLWGk7iEnvS2po and not USuRxnPlV5.resolveonly:
		USuRxnPlV5.resolveonly = IZQbmFzLHDtXfc
		mf6JUuZVwQNItzMR9CFrOvygepqA = bu6LzUQF7K.Player().isPlaying()
		if not mf6JUuZVwQNItzMR9CFrOvygepqA: df6QHU3Ej8hx17RwJZ5aIz = bu6LzUQF7K.executeJSONRPC(AiCor1fIVTDxQUWwHe9vPR7(u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢࡪࡦࠥ࠾࠶࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡓࡰࡦࡿ࡬ࡪࡵࡷ࠲ࡈࡲࡥࡢࡴࠥ࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡲ࡯ࡥࡾࡲࡩࡴࡶ࡬ࡨࠧࡀ࠱ࡾࡿࠪႿ"))
		else:
			uWmIpCxB9rt0QYheXvPc = SS74GByUrNct8unsM15E()
			if uWmIpCxB9rt0QYheXvPc:
				import RgJNGc7YMP,WgvHc7lhSL
				for PC2J91Vyhn0GomBjp6K5clftAiYg in range(nnsBpJv6XL3OzHoe4Vuhr,aJ7EUN4tGwuilRyzvkj6OpCr3PoZK,kzoASbNraPcfgvWJmY9Qu):
					bD7kJZhMCdaqF68P45KlNIgO1.sleep(kzoASbNraPcfgvWJmY9Qu)
					mf6JUuZVwQNItzMR9CFrOvygepqA = bu6LzUQF7K.Player().isPlaying()
					if not mf6JUuZVwQNItzMR9CFrOvygepqA:
						WgvHc7lhSL.bJqPkYBXsenxTRwKu(LungQF89BqemOb32jJsZlW(u"ࠫฬ๊แ๋ัํ์ࠥอไๅษะๆࠬჀ"),iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠬหไ฻ษฤࠤๆำีࠡษ็ื๏ืแาษอࠫჁ"),bD7kJZhMCdaqF68P45KlNIgO1=iRfoNckJs7Ibxzh5j92w8DSWF(u"࠹࠵࠶ᅌ"))
						break
				else:
					ppWtKTjVzdQwmoqNi7E,YkqWMTnVUjh1rQaXpG8LR7xo,mrcsT4vGxI6o7PMayUkHdtEZXB,VvpotnYyg78jbBiuHZADl0mcRE,fh6qmOxoiv1UPXZanLprDeMI8,aOZ3yVnsNlB974pR,ttFj9PmIcsuGpzib3aS,x8FkISpTrmqPJe2nvZOWU7zuNcj,g8tTFcBGwdKlo42LUkW = AanhLX36W9emBvK(uWmIpCxB9rt0QYheXvPc)
					if not any(value in YkqWMTnVUjh1rQaXpG8LR7xo for value in RgJNGc7YMP.NOT_TO_TEST_ALL_SERVERS):
						WgvHc7lhSL.bJqPkYBXsenxTRwKu(S5fhsRT8JV(u"࠭วๅใํำ๏๎ࠠศๆ็หา่ࠧჂ"),SGazRxP3yBKZ15ILuch(u"ࠧโฯุࠤัฺ๋๊ࠢสุ่๐ัโำสฮࠬჃ"),bD7kJZhMCdaqF68P45KlNIgO1=iRfoNckJs7Ibxzh5j92w8DSWF(u"࠼࠻࠰ᅍ"))
						bD7kJZhMCdaqF68P45KlNIgO1.sleep(bVX3ev1spE)
						RgJNGc7YMP.tHOfW4iaMLm8VuZegxobrlnj5A0yB(c5oDzdPaOE8,c5oDzdPaOE8,c5oDzdPaOE8)
						xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = RgJNGc7YMP.dH3YIkvnm6NW0oRMO41ybpC(ppWtKTjVzdQwmoqNi7E,YkqWMTnVUjh1rQaXpG8LR7xo,mrcsT4vGxI6o7PMayUkHdtEZXB,VvpotnYyg78jbBiuHZADl0mcRE,fh6qmOxoiv1UPXZanLprDeMI8,aOZ3yVnsNlB974pR,ttFj9PmIcsuGpzib3aS,x8FkISpTrmqPJe2nvZOWU7zuNcj,g8tTFcBGwdKlo42LUkW)
						RgJNGc7YMP.tHOfW4iaMLm8VuZegxobrlnj5A0yB(rrVbXS3ncE,rrVbXS3ncE,rrVbXS3ncE)
						WgvHc7lhSL.bJqPkYBXsenxTRwKu(AiCor1fIVTDxQUWwHe9vPR7(u"ࠨษ็ๅ๏ี๊้ࠢส่้ออใࠩჄ"),iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠩส๊ฯํ้ࠡใะูࠥอไิ์ิๅึอสࠨჅ"),bD7kJZhMCdaqF68P45KlNIgO1=k5oIaYyp2mnrLK49qhzS(u"࠽࠵࠱ᅎ"))
						xthyMJA94p = ksTLSoVGg0ht
	ZfUjy7h2N3tkuJMViw16 = Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.getSetting(YnHG75e2QWwo(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡢࡪࡶࡵࡥࡹ࡫ࠧ჆"))
	if xN4fKmsnyM3Y2(u"ࠫ࠲࠭Ⴧ") in ZfUjy7h2N3tkuJMViw16:
		ZfUjy7h2N3tkuJMViw16 = ZfUjy7h2N3tkuJMViw16.replace(On1WZJc6dtksqVNgSQ5GBAjuipe(u"ࠬ࠳ࠧ჈"),cdZKMn68Pzg4)
		Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.setSetting(tRnTydV03Xfi7rbQ(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡥ࡭ࡹࡸࡡࡵࡧࠪ჉"),ZfUjy7h2N3tkuJMViw16)
	if xthyMJA94p: bu6LzUQF7K.executebuiltin(rbUkdYi32PJaRtnxhDvQs(u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠫ჊"))
	return
def SS74GByUrNct8unsM15E():
	lJfuziHIGdrysSbPpCATa4BgZXE = bu6LzUQF7K.executeJSONRPC(rbUkdYi32PJaRtnxhDvQs(u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡑ࡮ࡤࡽࡱ࡯ࡳࡵ࠰ࡊࡩࡹࡏࡴࡦ࡯ࡶࠦ࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡳࡰࡦࡿ࡬ࡪࡵࡷ࡭ࡩࠨ࠺࠲࠮ࠥࡴࡷࡵࡰࡦࡴࡷ࡭ࡪࡹࠢ࠻࡝ࠥࡸ࡮ࡺ࡬ࡦࠤ࠯ࠦ࡫࡯࡬ࡦࠤ࠯ࠦࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࠢ࡞ࡿ࠯ࠦ࡮ࡪࠢ࠻࠳ࢀࠫ჋"))
	xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = sJB3aL8gGVrRU.loads(lJfuziHIGdrysSbPpCATa4BgZXE)[AiCor1fIVTDxQUWwHe9vPR7(u"ࠩࡵࡩࡸࡻ࡬ࡵࠩ჌")]
	uWmIpCxB9rt0QYheXvPc = cdZKMn68Pzg4
	try: items = xsGUcR3ef6glKY5hQwpFXEaSt2mrIz[aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠪ࡭ࡹ࡫࡭ࡴࠩჍ")]
	except: return cdZKMn68Pzg4
	if items:
		for udsnZkQyF3Air1Jfa,file in enumerate(items):
			path = file[YnHG75e2QWwo(u"ࠫ࡫࡯࡬ࡦࠩ჎")]
			if pzPE1fgqrkbQOXBmc not in path: continue
			path = path.split(pzPE1fgqrkbQOXBmc)[hiuZa0PIsErm6UC7][hiuZa0PIsErm6UC7:]
			if path==I4sncq6lxyDa03Gr5B: break
		count = xsGUcR3ef6glKY5hQwpFXEaSt2mrIz[iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠬࡲࡩ࡮࡫ࡷࡷࠬ჏")][HC9xWUMpBQJEuTteAqjd(u"࠭ࡴࡰࡶࡤࡰࠬა")]
		if udsnZkQyF3Air1Jfa+hiuZa0PIsErm6UC7<count: uWmIpCxB9rt0QYheXvPc = items[udsnZkQyF3Air1Jfa+hiuZa0PIsErm6UC7][NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠧࡧ࡫࡯ࡩࠬბ")]
	return uWmIpCxB9rt0QYheXvPc
def MexD9yTpd8UugjOcIkz():
	df6QHU3Ej8hx17RwJZ5aIz = bu6LzUQF7K.executeJSONRPC(tRnTydV03Xfi7rbQ(u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠥࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡕࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡋࡪࡺࡓࡦࡶࡷ࡭ࡳ࡭ࡖࡢ࡮ࡸࡩࠧ࠲ࠢࡪࡦࠥ࠾࠶࠲ࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡷࡪࡺࡴࡪࡰࡪࠦ࠿ࠨࡶࡪࡦࡨࡳࡵࡲࡡࡺࡧࡵ࠲ࡦࡻࡴࡰࡲ࡯ࡥࡾࡴࡥࡹࡶ࡬ࡸࡪࡳࠢࡾࡿࠪგ"))
	F5JqLX7coT8MA9fQkCOxvBtgWIS = ksTLSoVGg0ht if KNomgGw1kdMCBH(u"ࠩ࡞ࡡࠬდ") in str(df6QHU3Ej8hx17RwJZ5aIz) else IZQbmFzLHDtXfc
	return F5JqLX7coT8MA9fQkCOxvBtgWIS
def dNosE0aMjWHXP4(YtH5mMRLfsBqaTGPNOySU,hTeVzcsyWj4Xafxn2uUHLND=ksTLSoVGg0ht):
	if YtH5mMRLfsBqaTGPNOySU==k5oIaYyp2mnrLK49qhzS(u"ࠪࡷࡹࡵࡰࠨე") and (hTeVzcsyWj4Xafxn2uUHLND or USuRxnPlV5.busydialog_active):
		if hTeVzcsyWj4Xafxn2uUHLND:
			bu6LzUQF7K.executebuiltin(aar0zhDnJsOTP7EdgR16HIS29(u"ࠫࡉ࡯ࡡ࡭ࡱࡪ࠲ࡈࡲ࡯ࡴࡧࠫࡦࡺࡹࡹࡥ࡫ࡤࡰࡴ࡭ࠩࠨვ"))
		bu6LzUQF7K.executebuiltin(AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"ࠬࡊࡩࡢ࡮ࡲ࡫࠳ࡉ࡬ࡰࡵࡨࠬࡧࡻࡳࡺࡦ࡬ࡥࡱࡵࡧ࡯ࡱࡦࡥࡳࡩࡥ࡭ࠫࠪზ"))
		USuRxnPlV5.busydialog_active = ksTLSoVGg0ht
	if YtH5mMRLfsBqaTGPNOySU==WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"࠭ࡳࡵࡣࡵࡸࠬთ") and (hTeVzcsyWj4Xafxn2uUHLND or not USuRxnPlV5.busydialog_active):
		eDBSO5AhWtgrPRK = k5oIaYyp2mnrLK49qhzS(u"ࠧࡣࡷࡶࡽࡩ࡯ࡡ࡭ࡱࡪࡲࡴࡩࡡ࡯ࡥࡨࡰࠬი") if m4PjYkEqLcJh>TtyzcuW45VKA(u"࠱࠸࠰࠼࠽ᅏ") else TtyzcuW45VKA(u"ࠨࡤࡸࡷࡾࡪࡩࡢ࡮ࡲ࡫ࠬკ")
		bu6LzUQF7K.executebuiltin(WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠩࡄࡧࡹ࡯ࡶࡢࡶࡨ࡛࡮ࡴࡤࡰࡹࠫࠫლ")+eDBSO5AhWtgrPRK+aar0zhDnJsOTP7EdgR16HIS29(u"ࠪ࠭ࠬმ"))
		USuRxnPlV5.busydialog_active = IZQbmFzLHDtXfc
	return
def qMrpRl8enOuvS6hV2XcZgT(*args,**kwargs):
	daemon = kwargs.pop(J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠫࡩࡧࡥ࡮ࡱࡱࠫნ"),ksTLSoVGg0ht)
	QQJOvg9ZY86GpWK2Cr = WKXryzPwpU1H354EJdCfZ6cBt.Thread(*args,**kwargs)
	try: QQJOvg9ZY86GpWK2Cr.setDaemon(daemon)
	except: pass
	try: QQJOvg9ZY86GpWK2Cr.daemon = daemon
	except: pass
	return QQJOvg9ZY86GpWK2Cr
def CxlbPZwGTcH87e1sWhfSIz29uRUEpV(BLDtKUxE10ivr,ppWtKTjVzdQwmoqNi7E):
	if vbYokBuWlxeLDcdVNM60(u"ࠬ࠴ࠧო") not in BLDtKUxE10ivr: return BLDtKUxE10ivr
	BLDtKUxE10ivr = BLDtKUxE10ivr+KCQExdbYFqM
	PA74WuFSxy1HphCeDKftdMknBJG,sVcqveTOArht23xQCiJGj = BLDtKUxE10ivr.split(HC9xWUMpBQJEuTteAqjd(u"࠭࠮ࠨპ"),opyTNwHgfqbZREWKU(u"࠲ᅐ"))
	HHCRp7E3LXV8eyaGi4,W6N8kvKPRaE5neyGxXrTotQSzYV = sVcqveTOArht23xQCiJGj.split(KCQExdbYFqM,On1WZJc6dtksqVNgSQ5GBAjuipe(u"࠳ᅑ"))
	vpmKxYzL8k3sygwaGOHoWtEV06 = PA74WuFSxy1HphCeDKftdMknBJG+xN4fKmsnyM3Y2(u"ࠧ࠯ࠩჟ")+HHCRp7E3LXV8eyaGi4
	if ppWtKTjVzdQwmoqNi7E in [TtyzcuW45VKA(u"ࠨࡪࡲࡷࡹ࠭რ"),aar0zhDnJsOTP7EdgR16HIS29(u"ࠩࡱࡥࡲ࡫ࠧს")] and KCQExdbYFqM in vpmKxYzL8k3sygwaGOHoWtEV06: vpmKxYzL8k3sygwaGOHoWtEV06 = vpmKxYzL8k3sygwaGOHoWtEV06.rsplit(KCQExdbYFqM,f8Ja1q5eO02B(u"࠴ᅒ"))[hiuZa0PIsErm6UC7]
	if ppWtKTjVzdQwmoqNi7E==Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠪࡲࡦࡳࡥࠨტ") and tRnTydV03Xfi7rbQ(u"ࠫ࠳࠭უ") in vpmKxYzL8k3sygwaGOHoWtEV06:
		zzyk64FJh2VBtAHYZ8PgifaROuNlMI = vpmKxYzL8k3sygwaGOHoWtEV06.split(YnHG75e2QWwo(u"ࠬ࠴ࠧფ"))
		xv0hqpmHSVI2Ql1Z5i39gNe = len(zzyk64FJh2VBtAHYZ8PgifaROuNlMI)
		if LJPOQNK1mcG(u"࠭ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱࠫქ") in vpmKxYzL8k3sygwaGOHoWtEV06: zzyk64FJh2VBtAHYZ8PgifaROuNlMI = tRnTydV03Xfi7rbQ(u"ࠧࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲࠬღ")
		elif xv0hqpmHSVI2Ql1Z5i39gNe<=bVX3ev1spE: zzyk64FJh2VBtAHYZ8PgifaROuNlMI = zzyk64FJh2VBtAHYZ8PgifaROuNlMI[nnsBpJv6XL3OzHoe4Vuhr]
		elif xv0hqpmHSVI2Ql1Z5i39gNe>=kzoASbNraPcfgvWJmY9Qu: zzyk64FJh2VBtAHYZ8PgifaROuNlMI = zzyk64FJh2VBtAHYZ8PgifaROuNlMI[hiuZa0PIsErm6UC7]
		if len(zzyk64FJh2VBtAHYZ8PgifaROuNlMI)>hiuZa0PIsErm6UC7: vpmKxYzL8k3sygwaGOHoWtEV06 = zzyk64FJh2VBtAHYZ8PgifaROuNlMI
	return vpmKxYzL8k3sygwaGOHoWtEV06
def ggVJv2FK9cPtmU1W3RE(filename=NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠨࡲ࡯ࡥࡾࡲࡩࡴࡶ࠱ࡱ࠸ࡻ࠸ࠨყ"), content=None, O2OEkLfaDHhGVdZM61v4np7zmbPNt=S5fhsRT8JV(u"࠵࠵ᅓ"), UlOVJvgE2T54W=None):
	qLOvE5Tg1p8PMF4RsI, host_ip, BGrMLSsEfQON0qPvzj9K146l5miuY, d3HIpTe68sAuvL0 = iRfoNckJs7Ibxzh5j92w8DSWF(u"࠹࠰ᅕ"), uxE8MyoTRglrcaiQf(u"ࠩ࠴࠶࠼࠴࠰࠯࠲࠱࠵ࠬშ"), J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"࠵࠶࠲࠳࠴ᅖ"), SGazRxP3yBKZ15ILuch(u"࠺࠻࠹࠺࠻ᅔ")
	import socket as rqHBLtE6UDwCcJGeFhO0nTguQAXi1l
	if W5domCu6XrQUFkiPpa3bNLtHglG:
		import http.server as ajgXy8srHB
		import http.client as PFL8otjYzSqIgsivfGKuml
		from urllib.parse import urlparse as DV3npi4XIt7gRKq6buedHlEhyA
	else:
		import BaseHTTPServer as ajgXy8srHB
		import httplib as PFL8otjYzSqIgsivfGKuml
		from urlparse import urlparse as DV3npi4XIt7gRKq6buedHlEhyA
	if UlOVJvgE2T54W is None: UlOVJvgE2T54W = []
	class hjqnUC9t8R2f0kB7eYoTvJZzAX5NQF(ajgXy8srHB.BaseHTTPRequestHandler):
		def _AlQRGxUsVk4(aWUyzl8udA9VwsR6Lmr1boS2EQChXD):
			LgbpcFvxSR5NUO0TBfwAPKVjIh = aWUyzl8udA9VwsR6Lmr1boS2EQChXD.server
			path = DV3npi4XIt7gRKq6buedHlEhyA(aWUyzl8udA9VwsR6Lmr1boS2EQChXD.path).path
			qyDIVl7oSCJQeXN3FkfTr2BYmAjdE = ObuCsdoDtKmhPLSMH8YGan(u"ࠥ࠳ࠧჩ") + LgbpcFvxSR5NUO0TBfwAPKVjIh.filename
			return path == qyDIVl7oSCJQeXN3FkfTr2BYmAjdE or (path.startswith(qyDIVl7oSCJQeXN3FkfTr2BYmAjdE) and path[len(qyDIVl7oSCJQeXN3FkfTr2BYmAjdE):len(qyDIVl7oSCJQeXN3FkfTr2BYmAjdE)+SGazRxP3yBKZ15ILuch(u"࠲ᅗ")] in (uxE8MyoTRglrcaiQf(u"ࠦࠧც"), YnHG75e2QWwo(u"ࠧࡅࠢძ"), aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠨࠦࠣწ"), ObuCsdoDtKmhPLSMH8YGan(u"ࠢࡽࠤჭ")))
		def do_HEAD(aWUyzl8udA9VwsR6Lmr1boS2EQChXD):
			aWUyzl8udA9VwsR6Lmr1boS2EQChXD.send_response(k5oIaYyp2mnrLK49qhzS(u"࠴࠳࠴ᅘ") if aWUyzl8udA9VwsR6Lmr1boS2EQChXD._AlQRGxUsVk4() else vbYokBuWlxeLDcdVNM60(u"࠷࠴࠹ᅙ"))
			aWUyzl8udA9VwsR6Lmr1boS2EQChXD.end_headers()
		def do_GET(aWUyzl8udA9VwsR6Lmr1boS2EQChXD):
			LgbpcFvxSR5NUO0TBfwAPKVjIh = aWUyzl8udA9VwsR6Lmr1boS2EQChXD.server
			if not aWUyzl8udA9VwsR6Lmr1boS2EQChXD._AlQRGxUsVk4():
				aWUyzl8udA9VwsR6Lmr1boS2EQChXD.send_response(rbUkdYi32PJaRtnxhDvQs(u"࠸࠵࠺ᅚ"))
				aWUyzl8udA9VwsR6Lmr1boS2EQChXD.end_headers()
				return
			if LgbpcFvxSR5NUO0TBfwAPKVjIh.redirect:
				aWUyzl8udA9VwsR6Lmr1boS2EQChXD.send_response(tRnTydV03Xfi7rbQ(u"࠸࠶࠲ᅛ"))
				aWUyzl8udA9VwsR6Lmr1boS2EQChXD.send_header(LJPOQNK1mcG(u"ࠣࡎࡲࡧࡦࡺࡩࡰࡰࠥხ"), LgbpcFvxSR5NUO0TBfwAPKVjIh.content)
				aWUyzl8udA9VwsR6Lmr1boS2EQChXD.end_headers()
			else:
				aWUyzl8udA9VwsR6Lmr1boS2EQChXD.send_response(s8fcjBCSMxzAIkZQbJPga(u"࠸࠰࠱ᅜ"))
				eAbnqlfDFHjkQh2wB3vW0JR = LgbpcFvxSR5NUO0TBfwAPKVjIh.filename.lower()
				L7A159vHp0PuGsKDNqEiSmklQ = (aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠤࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡷࡰࡧ࠲ࡦࡶࡰ࡭ࡧ࠱ࡱࡵ࡫ࡧࡶࡴ࡯ࠦჯ") if eAbnqlfDFHjkQh2wB3vW0JR.endswith((AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"ࠥࡱ࠸ࡻࠢჰ"),WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠦࡲ࠹ࡵ࠹ࠤჱ")))
						else LJPOQNK1mcG(u"ࠧࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡨࡦࡹࡨࠬࡺࡰࡰࠧჲ") if eAbnqlfDFHjkQh2wB3vW0JR.endswith(J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠨ࡭ࡱࡦࠥჳ"))
						else KNomgGw1kdMCBH(u"ࠢࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡵࡣࡵࡧࡷ࠱ࡸࡺࡲࡦࡣࡰࠦჴ"))
				aWUyzl8udA9VwsR6Lmr1boS2EQChXD.send_header(SGazRxP3yBKZ15ILuch(u"ࠣࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠢჵ"), L7A159vHp0PuGsKDNqEiSmklQ)
				aWUyzl8udA9VwsR6Lmr1boS2EQChXD.end_headers()
				data = LgbpcFvxSR5NUO0TBfwAPKVjIh.content
				if isinstance(data, str):
					try: data = data.encode(s8fcjBCSMxzAIkZQbJPga(u"ࠤࡸࡸ࡫࠳࠸ࠣჶ"))
					except: pass
				aWUyzl8udA9VwsR6Lmr1boS2EQChXD.wfile.write(data)
			if O2OEkLfaDHhGVdZM61v4np7zmbPNt:
				def yySRXJKpeamMEdvUgis9w4h():
					bD7kJZhMCdaqF68P45KlNIgO1.sleep(O2OEkLfaDHhGVdZM61v4np7zmbPNt)
					LgbpcFvxSR5NUO0TBfwAPKVjIh.stop()
				qMrpRl8enOuvS6hV2XcZgT(target=yySRXJKpeamMEdvUgis9w4h, daemon=s8fcjBCSMxzAIkZQbJPga(u"࡚ࡲࡶࡧᅣ")).start()
	class UJ7GOToNzl2r(ajgXy8srHB.HTTPServer):
		TpISMkcyf8UqnsXJxEOu4LBPZ5 = nfg30bHwd4aNV12SR7UjFck(u"ࡔࡳࡷࡨᅤ")
		def __init__(aWUyzl8udA9VwsR6Lmr1boS2EQChXD):
			F8XWkzw9dar6Mj5ncLIQZOCsHE = set(UlOVJvgE2T54W)
			kRhEvPaIWt = set(range(BGrMLSsEfQON0qPvzj9K146l5miuY, d3HIpTe68sAuvL0 + AiCor1fIVTDxQUWwHe9vPR7(u"࠱ᅝ"))) - F8XWkzw9dar6Mj5ncLIQZOCsHE
			if not kRhEvPaIWt: raise RuntimeError(ObuCsdoDtKmhPLSMH8YGan(u"ࠥࡒࡴࠦࡡࡷࡣ࡬ࡰࡦࡨ࡬ࡦࠢࡳࡳࡷࡺࡳࠡ࡫ࡱࠤࡹ࡮ࡥࠡࡴࡤࡲ࡬࡫ࠠࡼࡿ࠰ࡿࢂࠨჷ").format(BGrMLSsEfQON0qPvzj9K146l5miuY, d3HIpTe68sAuvL0))
			while KNomgGw1kdMCBH(u"ࡕࡴࡸࡩᅥ"):
				host_port = EduRM2WTj7xz1.choice(list(kRhEvPaIWt))
				CPrHotLYqEbnj2FhzaZ04f = rqHBLtE6UDwCcJGeFhO0nTguQAXi1l.socket(rqHBLtE6UDwCcJGeFhO0nTguQAXi1l.AF_INET, rqHBLtE6UDwCcJGeFhO0nTguQAXi1l.SOCK_STREAM)
				try:
					CPrHotLYqEbnj2FhzaZ04f.bind((host_ip, host_port))
					CPrHotLYqEbnj2FhzaZ04f.close()
					break
				except:
					CPrHotLYqEbnj2FhzaZ04f.close()
					kRhEvPaIWt.remove(host_port)
					if not kRhEvPaIWt: raise RuntimeError(tRnTydV03Xfi7rbQ(u"ࠦࡆࡲ࡬ࠡࡲࡲࡶࡹࡹࠠࡪࡰࠣࡸ࡭࡫ࠠࡳࡣࡱ࡫ࡪࠦࡻࡾ࠯ࡾࢁࠥࡧࡲࡦࠢࡥࡹࡸࡿࠢჸ").format(BGrMLSsEfQON0qPvzj9K146l5miuY, d3HIpTe68sAuvL0))
			ajgXy8srHB.HTTPServer.__init__(aWUyzl8udA9VwsR6Lmr1boS2EQChXD, (host_ip, host_port), hjqnUC9t8R2f0kB7eYoTvJZzAX5NQF)
			aWUyzl8udA9VwsR6Lmr1boS2EQChXD.host_ip = host_ip
			aWUyzl8udA9VwsR6Lmr1boS2EQChXD.host_port = host_port
			aWUyzl8udA9VwsR6Lmr1boS2EQChXD.filename = filename
			aWUyzl8udA9VwsR6Lmr1boS2EQChXD.content = content
			aWUyzl8udA9VwsR6Lmr1boS2EQChXD.redirect = isinstance(content, str) and content.startswith((NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠧ࡮ࡴࡵࡲ࠽࠳࠴ࠨჹ"),iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠨࡨࡵࡶࡳࡷ࠿࠵࠯ࠣჺ")))
			aWUyzl8udA9VwsR6Lmr1boS2EQChXD.running = KNomgGw1kdMCBH(u"ࡈࡤࡰࡸ࡫ᅦ")
			aWUyzl8udA9VwsR6Lmr1boS2EQChXD.fileurl = HC9xWUMpBQJEuTteAqjd(u"ࠢࡩࡶࡷࡴ࠿࠵࠯ࡼࡿ࠽ࡿࢂ࠵ࡻࡾࠤ჻").format(host_ip, host_port, filename)
		def start(aWUyzl8udA9VwsR6Lmr1boS2EQChXD):
			if aWUyzl8udA9VwsR6Lmr1boS2EQChXD.running: return
			aWUyzl8udA9VwsR6Lmr1boS2EQChXD.running = rbUkdYi32PJaRtnxhDvQs(u"ࡗࡶࡺ࡫ᅧ")
			qMrpRl8enOuvS6hV2XcZgT(target=aWUyzl8udA9VwsR6Lmr1boS2EQChXD.serve_forever, kwargs={liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠣࡲࡲࡰࡱࡥࡩ࡯ࡶࡨࡶࡻࡧ࡬ࠣჼ"): KNomgGw1kdMCBH(u"࠱࠰࠸ᅞ")}, daemon=opyTNwHgfqbZREWKU(u"ࡘࡷࡻࡥᅨ")).start()
			if qLOvE5Tg1p8PMF4RsI:
				def yySRXJKpeamMEdvUgis9w4h():
					bD7kJZhMCdaqF68P45KlNIgO1.sleep(qLOvE5Tg1p8PMF4RsI)
					aWUyzl8udA9VwsR6Lmr1boS2EQChXD.stop()
				qMrpRl8enOuvS6hV2XcZgT(target=yySRXJKpeamMEdvUgis9w4h, daemon=ObuCsdoDtKmhPLSMH8YGan(u"࡙ࡸࡵࡦᅩ")).start()
		def stop(aWUyzl8udA9VwsR6Lmr1boS2EQChXD):
			if not aWUyzl8udA9VwsR6Lmr1boS2EQChXD.running: return
			aWUyzl8udA9VwsR6Lmr1boS2EQChXD.running = LungQF89BqemOb32jJsZlW(u"ࡌࡡ࡭ࡵࡨᅪ")
			try:
				aWUyzl8udA9VwsR6Lmr1boS2EQChXD.shutdown()
				aWUyzl8udA9VwsR6Lmr1boS2EQChXD.server_close()
			except: pass
	u1P73L0UmkA4eaIBbCgZfrvRtJ = UJ7GOToNzl2r()
	UlOVJvgE2T54W.append(u1P73L0UmkA4eaIBbCgZfrvRtJ.host_port)
	return u1P73L0UmkA4eaIBbCgZfrvRtJ, u1P73L0UmkA4eaIBbCgZfrvRtJ.fileurl
def FOkLsAqwop0x3mciC62dRZag8VEGY(mrcsT4vGxI6o7PMayUkHdtEZXB,MqpxmkbFcNAvGjVKoHzaw=cdZKMn68Pzg4):
	BywhTIvVNRfzLk = [ObuCsdoDtKmhPLSMH8YGan(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬჽ"),KNomgGw1kdMCBH(u"ࠪࡐࡎࡈࡒࡂࡔ࡜ࠫჾ"),tRnTydV03Xfi7rbQ(u"ࠫࡑࡏࡂࡔࡑࡑࡉࠬჿ"),tRnTydV03Xfi7rbQ(u"ࠬࡒࡉࡃࡕࡗ࡛ࡔ࠭ᄀ"),Rsdai9xIEPcpuBMKOUwkTA05q(u"࠭ࡄࡐ࡙ࡑࡐࡔࡇࡄࠨᄁ"),LungQF89BqemOb32jJsZlW(u"ࠧࡆ࡚ࡆࡐ࡚ࡊࡅࡔࠩᄂ"),nfg30bHwd4aNV12SR7UjFck(u"ࠨࡈࡄ࡚ࡔࡘࡉࡕࡇࡖࠫᄃ"),opyTNwHgfqbZREWKU(u"ࠩࡊࡐࡔࡈࡁࡍࡕࡈࡅࡗࡉࡈࠨᄄ"),J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠪࡑࡊࡔࡕࡔࠩᄅ"),iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠫࡉࡏࡁࡍࡑࡊࡗࠬᄆ"),On1WZJc6dtksqVNgSQ5GBAjuipe(u"ࠬࡋࡌࡄࡋࡑࡉࡒࡇࠧᄇ"),S5fhsRT8JV(u"࠭ࡉࡑࡖ࡙ࠫᄈ"),J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠧࡎ࠵ࡘࠫᄉ"),S5fhsRT8JV(u"ࠨࡎࡌ࡚ࡊ࡚ࡖࠨᄊ"),HC9xWUMpBQJEuTteAqjd(u"ࠩࡕࡅࡓࡊࡏࡎࡕࠪᄋ"),LJPOQNK1mcG(u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗࠬᄌ")]
	EMHfyvq59AjJDrYNgSekFnwO42 = Aty25FEGpLUbfwKT19vzVm3IsYk(mrcsT4vGxI6o7PMayUkHdtEZXB)
	vinyH598duZc = mrcsT4vGxI6o7PMayUkHdtEZXB
	if EMHfyvq59AjJDrYNgSekFnwO42 or NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠫ࡬ࡵ࡯ࡨ࡮ࡨࡺ࡮ࡪࡥࡰࠩᄍ") in mrcsT4vGxI6o7PMayUkHdtEZXB or not MqpxmkbFcNAvGjVKoHzaw or any(JSszL8yhVHc2WiAakOmYTNKbEotCD in MqpxmkbFcNAvGjVKoHzaw for JSszL8yhVHc2WiAakOmYTNKbEotCD in BywhTIvVNRfzLk): vinyH598duZc = CxlbPZwGTcH87e1sWhfSIz29uRUEpV(mrcsT4vGxI6o7PMayUkHdtEZXB,aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠬࡻࡲ࡭ࠩᄎ"))+HC9xWUMpBQJEuTteAqjd(u"࠭࠯࠯࠰࠱࠲࠳࠭ᄏ")
	return vinyH598duZc
def wrcgBRto5yMTdbhZLfzKe1UOpVSmYH(*args):
    def gHG7Ojycs8w2(msUGqorM4udfBSpXt5TaOZ):
        if isinstance(msUGqorM4udfBSpXt5TaOZ, list): return [gHG7Ojycs8w2(DXAlBvH2ITZoyunMU0Rq3pw7sx) for DXAlBvH2ITZoyunMU0Rq3pw7sx in msUGqorM4udfBSpXt5TaOZ]
        if isinstance(msUGqorM4udfBSpXt5TaOZ, tuple): return tuple(gHG7Ojycs8w2(DXAlBvH2ITZoyunMU0Rq3pw7sx) for DXAlBvH2ITZoyunMU0Rq3pw7sx in msUGqorM4udfBSpXt5TaOZ)
        if xicJPb0AW1nsRfH3kCv7 and isinstance(msUGqorM4udfBSpXt5TaOZ, unicode): return msUGqorM4udfBSpXt5TaOZ.encode(vczMIlkCAh2u10B3)
        if W5domCu6XrQUFkiPpa3bNLtHglG and isinstance(msUGqorM4udfBSpXt5TaOZ, bytes): return msUGqorM4udfBSpXt5TaOZ.decode(vczMIlkCAh2u10B3)
        return msUGqorM4udfBSpXt5TaOZ
    LvIn1VmEGQb0Z6NCM2g7J = tuple(gHG7Ojycs8w2(ppn8MtexmGralPTCQNJY4cR2BLoSdh) for ppn8MtexmGralPTCQNJY4cR2BLoSdh in args)
    return LvIn1VmEGQb0Z6NCM2g7J[KNomgGw1kdMCBH(u"࠳ᅠ")] if len(LvIn1VmEGQb0Z6NCM2g7J) == iRfoNckJs7Ibxzh5j92w8DSWF(u"࠳ᅟ") else LvIn1VmEGQb0Z6NCM2g7J
fcS2zTXh5JqG8iPmR = sZHYrLPog4wmuW0ECdc(TV08xYHA2ok,zDek1IW37rq6UoKdwyRiAVpF(u"ࠧ࡭࡫ࡶࡸࠬᄐ"),uxE8MyoTRglrcaiQf(u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫᄑ"),dwiIAcPl04ey7Zv38Mz(u"ࠩࡖࡍ࡙ࡋࡓࡠࡅࡋࡉࡈࡑࠧᄒ"))
if fcS2zTXh5JqG8iPmR:
	jDFeZ3PuoSNHs7WLlm09YhGrba81I,OmPAFvdsLRoqG3l1,Q0Yc8C3J5ABdWZ,tts1YBRxq06AMES = fcS2zTXh5JqG8iPmR
	USuRxnPlV5.AV_CLIENT_IDS = ssELJkeScrtni2.join(jDFeZ3PuoSNHs7WLlm09YhGrba81I)
if not USuRxnPlV5.AV_CLIENT_IDS: USuRxnPlV5.AV_CLIENT_IDS = NO3BIgUPeMwjCp()
upxgjER7K9zJOshwbfPyrD8Sovam = D8xY9QifCrncjPWU3JySm1H4OqkAZ()
USuRxnPlV5.UZOwXToGvJnEqB4tgczAS2hHu,USuRxnPlV5.tbo8MkxlHv9qwdP6gI1rJzOV3Na,USuRxnPlV5.EXB156kCy3JW7U8gfqhGiwlov,USuRxnPlV5.RlZN1M72iH9vU3C8,USuRxnPlV5.avprivsnorestrict,USuRxnPlV5.avprivslongperiod = a8UdZSmAMkIGH3p12lh0Xz5js([rbUkdYi32PJaRtnxhDvQs(u"ࠪࡇ࡙ࡋ࠹ࡅࡕ࠴࠽࡛࡛࠰ࡗࡕ࡛ࠫᄓ"),k5oIaYyp2mnrLK49qhzS(u"ࠫ࡜࡙ࡕࡓࡈࡗ࠵࠾ࡗࡔࡆࡈ࡝࡜ࠬᄔ"),J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠬࡈࡔࡆࡺࡓ࡚࠶࠿ࡕࡓࡘࡑ࡙ࡘ࡛࠵ࡉ࡚ࠪᄕ"),iRfoNckJs7Ibxzh5j92w8DSWF(u"࠭ࡏࡕ࠳࠼ࡎ࡚࠶ࡸࡃࡖࡘࡰࡉ࡞ࠧᄖ"),rbUkdYi32PJaRtnxhDvQs(u"ࠧࡃࡖࡈࡼࡕ࡜࠱࠺ࡕࡕ࡚ࡓ࡛ࡕ࡬࡮ࡇ࡚ࡊ࡜ࡅ࡙ࠩᄗ"),k5oIaYyp2mnrLK49qhzS(u"ࠨࡏࡗ࠴࠺ࡎࡘ࠱࡮ࡗࡘࡊࡌࡎࡔࡗࡑࡪ࡚ࡋࡖࡔࡕࡘ࠽ࡊ࡞ࠧᄘ")])
lBoFGiJ6DLj72XhueYRms = USuRxnPlV5.AV_CLIENT_IDS.splitlines()[nnsBpJv6XL3OzHoe4Vuhr][-iRfoNckJs7Ibxzh5j92w8DSWF(u"࠶࠹ᅡ"):]
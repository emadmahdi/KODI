# -*- coding: utf-8 -*-
from RgJNGc7YMP import *
LMihk2Vzl4DesIQ65TGmvxqcKdHp = 'M3U'
XQgovGj6VkUFxH4a2 = '_M3U_'
zzSXPqifhs8rYnUvbMkuR26B7 = [
		 'IGNORED'
		,'LIVE_UNKNOWN_GROUPED','LIVE_UNKNOWN_GROUPED_SORTED'
		,'VOD_UNKNOWN_GROUPED','VOD_UNKNOWN_GROUPED_SORTED'
		,'LIVE_GROUPED','LIVE_GROUPED_SORTED'
		,'LIVE_ORIGINAL_GROUPED','LIVE_FROM_GROUP_SORTED','LIVE_FROM_NAME_SORTED'
		,'VOD_MOVIES_GROUPED','VOD_MOVIES_GROUPED_SORTED'
		,'VOD_SERIES_GROUPED','VOD_SERIES_GROUPED_SORTED'
		,'VOD_ORIGINAL_GROUPED','VOD_FROM_GROUP_SORTED','VOD_FROM_NAME_SORTED'
		]
ZVmIhR9YHACFNrGk546El1wdMB = 4
def ZZFUSgsGOhwdnX37V1TvatJomBMPW2(HHrpyfWjGC,kxY4EfTKobmQJ8OathHI53,JAYWBoz54tGw7O,kuMXTLrvIZGfjCDtA9YNJ5SxQK,iQBgv5oEbM6ZFH4U8qtC,RqmGlEdhA8z7M):
	global XQgovGj6VkUFxH4a2
	try:
		Vea0sXycdJ8LFSMzhB5Zt73u2rD = str(RqmGlEdhA8z7M['folder'])
		XQgovGj6VkUFxH4a2 = '_MU'+Vea0sXycdJ8LFSMzhB5Zt73u2rD+'_'
	except: Vea0sXycdJ8LFSMzhB5Zt73u2rD = cdZKMn68Pzg4
	try: T60FHByirslQk8f = str(RqmGlEdhA8z7M['sequence'])
	except: T60FHByirslQk8f = cdZKMn68Pzg4
	if   HHrpyfWjGC==710: iiAOHkqYIRW7Bs46CEj3Layefb2hSP = WNcPHoazEr0h()
	elif HHrpyfWjGC==711: iiAOHkqYIRW7Bs46CEj3Layefb2hSP = S4msZ0wigOJREj3rolfqQGch(Vea0sXycdJ8LFSMzhB5Zt73u2rD,T60FHByirslQk8f)
	elif HHrpyfWjGC==712: iiAOHkqYIRW7Bs46CEj3Layefb2hSP = zzKXxsiWfIU1E3l0BumDcnYS7(Vea0sXycdJ8LFSMzhB5Zt73u2rD)
	elif HHrpyfWjGC==713: iiAOHkqYIRW7Bs46CEj3Layefb2hSP = iBT7IHNAlEYDgsRthp3x9ynd(Vea0sXycdJ8LFSMzhB5Zt73u2rD,kxY4EfTKobmQJ8OathHI53,JAYWBoz54tGw7O,iQBgv5oEbM6ZFH4U8qtC)
	elif HHrpyfWjGC==714: iiAOHkqYIRW7Bs46CEj3Layefb2hSP = yKvktsG9BnHTge4fVuREIpm83(Vea0sXycdJ8LFSMzhB5Zt73u2rD,kxY4EfTKobmQJ8OathHI53,JAYWBoz54tGw7O,iQBgv5oEbM6ZFH4U8qtC)
	elif HHrpyfWjGC==715: iiAOHkqYIRW7Bs46CEj3Layefb2hSP = RPZbqous7rtdy56LeI18Cv04AKHW(Vea0sXycdJ8LFSMzhB5Zt73u2rD,kxY4EfTKobmQJ8OathHI53,kuMXTLrvIZGfjCDtA9YNJ5SxQK)
	elif HHrpyfWjGC==716: iiAOHkqYIRW7Bs46CEj3Layefb2hSP = hX7rFmcGbqlaER2xL(Vea0sXycdJ8LFSMzhB5Zt73u2rD,True)
	elif HHrpyfWjGC==717: iiAOHkqYIRW7Bs46CEj3Layefb2hSP = PMLNctzmY3ThUWw(Vea0sXycdJ8LFSMzhB5Zt73u2rD,True)
	elif HHrpyfWjGC==718: iiAOHkqYIRW7Bs46CEj3Layefb2hSP = H5YObrSN4ZomGWidXpVtPKJ(Vea0sXycdJ8LFSMzhB5Zt73u2rD,kxY4EfTKobmQJ8OathHI53,JAYWBoz54tGw7O)
	elif HHrpyfWjGC==719: iiAOHkqYIRW7Bs46CEj3Layefb2hSP = pi7dszu648(JAYWBoz54tGw7O,Vea0sXycdJ8LFSMzhB5Zt73u2rD,kxY4EfTKobmQJ8OathHI53,iQBgv5oEbM6ZFH4U8qtC)
	elif HHrpyfWjGC==720: iiAOHkqYIRW7Bs46CEj3Layefb2hSP = U05YOSpxzrvlK6W8jPgce7qHbwysB(Vea0sXycdJ8LFSMzhB5Zt73u2rD,True)
	elif HHrpyfWjGC==721: iiAOHkqYIRW7Bs46CEj3Layefb2hSP = zuoCGEY4fpaVetA1(Vea0sXycdJ8LFSMzhB5Zt73u2rD)
	elif HHrpyfWjGC==722: iiAOHkqYIRW7Bs46CEj3Layefb2hSP = jyripTCwLE0(Vea0sXycdJ8LFSMzhB5Zt73u2rD)
	elif HHrpyfWjGC==723: iiAOHkqYIRW7Bs46CEj3Layefb2hSP = BzSKH15l2PN8dgraGXxMj3tQ7Um(Vea0sXycdJ8LFSMzhB5Zt73u2rD)
	elif HHrpyfWjGC==726: iiAOHkqYIRW7Bs46CEj3Layefb2hSP = Y2fWsBKEyhaNv7Pl9Xwej(Vea0sXycdJ8LFSMzhB5Zt73u2rD)
	elif HHrpyfWjGC==729: iiAOHkqYIRW7Bs46CEj3Layefb2hSP = LMejKcGP5p9QUkrFgqWAVivnNt6yoT(JAYWBoz54tGw7O,Vea0sXycdJ8LFSMzhB5Zt73u2rD,kxY4EfTKobmQJ8OathHI53,iQBgv5oEbM6ZFH4U8qtC)
	else: iiAOHkqYIRW7Bs46CEj3Layefb2hSP = False
	return iiAOHkqYIRW7Bs46CEj3Layefb2hSP
def WNcPHoazEr0h():
	for Vea0sXycdJ8LFSMzhB5Zt73u2rD in range(1,d37Zoe1YJgWbMq+1):
		XQgovGj6VkUFxH4a2 = '_MU'+str(Vea0sXycdJ8LFSMzhB5Zt73u2rD)+'_'
		zJLApFBcIhnSj('folder',XQgovGj6VkUFxH4a2+'قائمة مجلد '+G9Gz76P41qQAW2viUsjEymXYOVuBSc[Vea0sXycdJ8LFSMzhB5Zt73u2rD],cdZKMn68Pzg4,720,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,{'folder':Vea0sXycdJ8LFSMzhB5Zt73u2rD})
	return
def U05YOSpxzrvlK6W8jPgce7qHbwysB(Vea0sXycdJ8LFSMzhB5Zt73u2rD=cdZKMn68Pzg4,bUHVjvzwnyi=cdZKMn68Pzg4):
	if Vea0sXycdJ8LFSMzhB5Zt73u2rD:
		hWuidNS1px7vRMTao = {'folder':Vea0sXycdJ8LFSMzhB5Zt73u2rD}
		ZLQ8R02Aq7U1gKE = cdZKMn68Pzg4
	else:
		hWuidNS1px7vRMTao = cdZKMn68Pzg4
		ZLQ8R02Aq7U1gKE = cdZKMn68Pzg4
	SUJxjgp4ZDYT1fd0wz6RvEB8KiaAhm = Im36vznMobP7WCNfFY2lJZ(Vea0sXycdJ8LFSMzhB5Zt73u2rD,bUHVjvzwnyi)
	if not SUJxjgp4ZDYT1fd0wz6RvEB8KiaAhm:
		zJLApFBcIhnSj('link',XQgovGj6VkUFxH4a2+bxf7gZvNK29cEoiAIJlMq0dP+' إضافة وتغيير رابط'+ZLQ8R02Aq7U1gKE+VBpIH2QSmvDGlA6TO3e+G9Gz76P41qQAW2viUsjEymXYOVuBSc[1]+' '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,711,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,{'folder':Vea0sXycdJ8LFSMzhB5Zt73u2rD,'sequence':1})
		zJLApFBcIhnSj('link',XQgovGj6VkUFxH4a2+bxf7gZvNK29cEoiAIJlMq0dP+' جلب ملفات'+ZLQ8R02Aq7U1gKE+' '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,712,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,hWuidNS1px7vRMTao)
		zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	else:
		zJLApFBcIhnSj('folder',XQgovGj6VkUFxH4a2+'بحث في الملفات'+ZLQ8R02Aq7U1gKE,cdZKMn68Pzg4,729,cdZKMn68Pzg4,cdZKMn68Pzg4,'_REMEMBERRESULTS_',cdZKMn68Pzg4,hWuidNS1px7vRMTao)
		zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
		zJLApFBcIhnSj('folder',XQgovGj6VkUFxH4a2+'قنوات مصنفة مرتبة'+ZLQ8R02Aq7U1gKE,'LIVE_GROUPED_SORTED',713,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,hWuidNS1px7vRMTao)
		zJLApFBcIhnSj('folder',XQgovGj6VkUFxH4a2+'قنوات مصنفة من القسم'+ZLQ8R02Aq7U1gKE,'LIVE_FROM_GROUP_SORTED',713,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,hWuidNS1px7vRMTao)
		zJLApFBcIhnSj('folder',XQgovGj6VkUFxH4a2+'قنوات مصنفة من الاسم'+ZLQ8R02Aq7U1gKE,'LIVE_FROM_NAME_SORTED',713,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,hWuidNS1px7vRMTao)
		zJLApFBcIhnSj('folder',XQgovGj6VkUFxH4a2+'قنوات مصنفة بلا ترتيب'+ZLQ8R02Aq7U1gKE,'LIVE_GROUPED',713,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,hWuidNS1px7vRMTao)
		zJLApFBcIhnSj('folder',XQgovGj6VkUFxH4a2+'قنوات بلا ترتيب'+ZLQ8R02Aq7U1gKE,'LIVE_ORIGINAL_GROUPED',713,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,hWuidNS1px7vRMTao)
		zJLApFBcIhnSj('folder',XQgovGj6VkUFxH4a2+'قنوات مجهولة مرتبة'+ZLQ8R02Aq7U1gKE,'LIVE_UNKNOWN_GROUPED_SORTED',713,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,hWuidNS1px7vRMTao)
		zJLApFBcIhnSj('folder',XQgovGj6VkUFxH4a2+'قنوات مجهولة بلا ترتيب'+ZLQ8R02Aq7U1gKE,'LIVE_UNKNOWN_GROUPED',713,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,hWuidNS1px7vRMTao)
		zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
		zJLApFBcIhnSj('folder',XQgovGj6VkUFxH4a2+'فيديوهات بلا ترتيب'+ZLQ8R02Aq7U1gKE,'VOD_ORIGINAL_GROUPED',713,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,hWuidNS1px7vRMTao)
		zJLApFBcIhnSj('folder',XQgovGj6VkUFxH4a2+'فيديوهات مصنفة القسم'+ZLQ8R02Aq7U1gKE,'VOD_FROM_GROUP_SORTED',713,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,hWuidNS1px7vRMTao)
		zJLApFBcIhnSj('folder',XQgovGj6VkUFxH4a2+'فيديوهات مصنفة من الاسم'+ZLQ8R02Aq7U1gKE,'VOD_FROM_NAME_SORTED',713,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,hWuidNS1px7vRMTao)
		zJLApFBcIhnSj('folder',XQgovGj6VkUFxH4a2+'فيديوهات مجهولة بلا ترتيب'+ZLQ8R02Aq7U1gKE,'VOD_UNKNOWN_GROUPED',713,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,hWuidNS1px7vRMTao)
		zJLApFBcIhnSj('folder',XQgovGj6VkUFxH4a2+'فيديوهات مجهولة مرتبة'+ZLQ8R02Aq7U1gKE,'VOD_UNKNOWN_GROUPED_SORTED',713,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,hWuidNS1px7vRMTao)
		zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	for B6Br4FlxoIEkAnjKgu3qd in range(1,ZVmIhR9YHACFNrGk546El1wdMB+1):
		zJLApFBcIhnSj('link',XQgovGj6VkUFxH4a2+'إضافة وتغيير رابط'+ZLQ8R02Aq7U1gKE+VBpIH2QSmvDGlA6TO3e+G9Gz76P41qQAW2viUsjEymXYOVuBSc[B6Br4FlxoIEkAnjKgu3qd],cdZKMn68Pzg4,711,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,{'folder':Vea0sXycdJ8LFSMzhB5Zt73u2rD,'sequence':B6Br4FlxoIEkAnjKgu3qd})
	zJLApFBcIhnSj('link',XQgovGj6VkUFxH4a2+'جلب ملفات'+ZLQ8R02Aq7U1gKE,cdZKMn68Pzg4,712,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,hWuidNS1px7vRMTao)
	zJLApFBcIhnSj('link',XQgovGj6VkUFxH4a2+'مسح ملفات'+ZLQ8R02Aq7U1gKE,cdZKMn68Pzg4,717,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,hWuidNS1px7vRMTao)
	zJLApFBcIhnSj('link',XQgovGj6VkUFxH4a2+'عدد فيديوهات'+ZLQ8R02Aq7U1gKE,cdZKMn68Pzg4,721,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,hWuidNS1px7vRMTao)
	zJLApFBcIhnSj('link',XQgovGj6VkUFxH4a2+'Referer تغيير'+ZLQ8R02Aq7U1gKE,cdZKMn68Pzg4,726,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,hWuidNS1px7vRMTao)
	zJLApFBcIhnSj('link',XQgovGj6VkUFxH4a2+'User-Agent تغيير'+ZLQ8R02Aq7U1gKE,cdZKMn68Pzg4,723,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,hWuidNS1px7vRMTao)
	return
def hX7rFmcGbqlaER2xL(Vea0sXycdJ8LFSMzhB5Zt73u2rD,bUHVjvzwnyi=True):
	N4NMhSyT5mkwKZRY,r0VNJTaX5vOsme4 = False,cdZKMn68Pzg4
	XOSVmnLg957jiID0Q1RPlvpbkw,beE5JlkVDgdzro4y = cdZKMn68Pzg4,cdZKMn68Pzg4
	jcidYWSngJx2lphkZN7f5AqRu,AZnTKcDC0twiN2l6Fzxr3f,Szg3qvldoOyU,YsyfvFHASN,ww2AC3SkbFQXc6Pj = EEJjV7pU0Cy9RScBXefYh(Vea0sXycdJ8LFSMzhB5Zt73u2rD)
	if YsyfvFHASN==cdZKMn68Pzg4: return False,cdZKMn68Pzg4,cdZKMn68Pzg4
	pj3iPglDkueR29AH6U = lr845giTQzJ01vqZP(Vea0sXycdJ8LFSMzhB5Zt73u2rD)
	if jcidYWSngJx2lphkZN7f5AqRu:
		oyufnwWte9Im4cFA6hSLODiGRMsJx8 = e4qbrCQPyuMjpK(fS25N8gAZxpbnLi3srX7PJ,'GET',jcidYWSngJx2lphkZN7f5AqRu,cdZKMn68Pzg4,pj3iPglDkueR29AH6U,False,cdZKMn68Pzg4,'M3U-CHECK_ACCOUNT-1st')
		ajEFui1BI6z8RJor = oyufnwWte9Im4cFA6hSLODiGRMsJx8.content
		if oyufnwWte9Im4cFA6hSLODiGRMsJx8.succeeded:
			P4OVJ8jvKxU,vbArRLplfGVWP6y3OU7ojI08YCm,N08BQ17ZlzrhHbjxEpFiYk,z2OrhTom1CB3t,fcJjuLIAyEgz7BRSFNpG = 0,0,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4
			try:
				ZUSphruPxENelqv0LY = lMeKd3hC6cmS('dict',ajEFui1BI6z8RJor)
				r0VNJTaX5vOsme4 = ZUSphruPxENelqv0LY['user_info']['status']
				N4NMhSyT5mkwKZRY = True
				N08BQ17ZlzrhHbjxEpFiYk = ZUSphruPxENelqv0LY['server_info']['time_now']
			except: pass
			if N08BQ17ZlzrhHbjxEpFiYk:
				try:
					C4wF1LSOhfRW6XqxajoyY3MGv2E = bD7kJZhMCdaqF68P45KlNIgO1.strptime(N08BQ17ZlzrhHbjxEpFiYk,'%Y.%m.%d %H:%M:%S')
					P4OVJ8jvKxU = int(bD7kJZhMCdaqF68P45KlNIgO1.mktime(C4wF1LSOhfRW6XqxajoyY3MGv2E))
					vbArRLplfGVWP6y3OU7ojI08YCm = int(BbIVuS4KecnqNvZz5GptR-P4OVJ8jvKxU)
					vbArRLplfGVWP6y3OU7ojI08YCm = int((vbArRLplfGVWP6y3OU7ojI08YCm+900)/1800)*1800
				except: pass
				try:
					C4wF1LSOhfRW6XqxajoyY3MGv2E = bD7kJZhMCdaqF68P45KlNIgO1.localtime(int(ZUSphruPxENelqv0LY['user_info']['created_at']))
					z2OrhTom1CB3t = bD7kJZhMCdaqF68P45KlNIgO1.strftime('%Y.%m.%d %H:%M:%S',C4wF1LSOhfRW6XqxajoyY3MGv2E)
				except: pass
				try:
					C4wF1LSOhfRW6XqxajoyY3MGv2E = bD7kJZhMCdaqF68P45KlNIgO1.localtime(int(ZUSphruPxENelqv0LY['user_info']['exp_date']))
					fcJjuLIAyEgz7BRSFNpG = bD7kJZhMCdaqF68P45KlNIgO1.strftime('%Y.%m.%d %H:%M:%S',C4wF1LSOhfRW6XqxajoyY3MGv2E)
				except: pass
			Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.setSetting('av.m3u.timestamp_'+Vea0sXycdJ8LFSMzhB5Zt73u2rD,str(BbIVuS4KecnqNvZz5GptR))
			Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.setSetting('av.m3u.timediff_'+Vea0sXycdJ8LFSMzhB5Zt73u2rD,str(vbArRLplfGVWP6y3OU7ojI08YCm))
			try:
				LobaZ0SMVqIPdjh = '"server_info":'+ajEFui1BI6z8RJor.split('"server_info":')[1]
				LobaZ0SMVqIPdjh = LobaZ0SMVqIPdjh.replace(':',': ').replace(',',', ').replace('}}','}')
				ObAlU5uZ8q3mCdfe = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"url": "(.*?)", "port": "(.*?)"',LobaZ0SMVqIPdjh,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
				XOSVmnLg957jiID0Q1RPlvpbkw,beE5JlkVDgdzro4y = ObAlU5uZ8q3mCdfe[0]
			except: N4NMhSyT5mkwKZRY = False
			if N4NMhSyT5mkwKZRY and bUHVjvzwnyi:
				max = ZUSphruPxENelqv0LY['user_info']['max_connections']
				QfiSpKj1MEAo0m6YTVHuFe5CzLhIJ = ZUSphruPxENelqv0LY['user_info']['active_cons']
				QUL43RiVeS2sJMoWAa0Ffc = ZUSphruPxENelqv0LY['user_info']['is_trial']
				vvJwlPDanH5FACTehcG1f = jcidYWSngJx2lphkZN7f5AqRu.split('?',1)
				KZ4oqDz5xgA2tkGcTaeQ1Lh3dp = 'URL:  '+Gzygq01Kcb9U3+jcidYWSngJx2lphkZN7f5AqRu+kH8E2zqNyims6KJfI
				KZ4oqDz5xgA2tkGcTaeQ1Lh3dp += '\n\nStatus:  '+Gzygq01Kcb9U3+r0VNJTaX5vOsme4+kH8E2zqNyims6KJfI
				KZ4oqDz5xgA2tkGcTaeQ1Lh3dp += '\nTrial:    '+Gzygq01Kcb9U3+str(QUL43RiVeS2sJMoWAa0Ffc=='1')+kH8E2zqNyims6KJfI
				KZ4oqDz5xgA2tkGcTaeQ1Lh3dp += '\nCreated  At:  '+Gzygq01Kcb9U3+z2OrhTom1CB3t+kH8E2zqNyims6KJfI
				KZ4oqDz5xgA2tkGcTaeQ1Lh3dp += '\nExpiry Date:  '+Gzygq01Kcb9U3+fcJjuLIAyEgz7BRSFNpG+kH8E2zqNyims6KJfI
				KZ4oqDz5xgA2tkGcTaeQ1Lh3dp += '\nConnections   ( Active / Maximum ) :  '+Gzygq01Kcb9U3+QfiSpKj1MEAo0m6YTVHuFe5CzLhIJ+' / '+max+kH8E2zqNyims6KJfI
				KZ4oqDz5xgA2tkGcTaeQ1Lh3dp += '\nAllowed Outputs:   '+Gzygq01Kcb9U3+" , ".join(ZUSphruPxENelqv0LY['user_info']['allowed_output_formats'])+kH8E2zqNyims6KJfI
				KZ4oqDz5xgA2tkGcTaeQ1Lh3dp += '\n\n'+LobaZ0SMVqIPdjh
				if r0VNJTaX5vOsme4=='Active': RMDqaKOvQCXghu81Gc('الاشتراك يعمل بدون مشاكل',KZ4oqDz5xgA2tkGcTaeQ1Lh3dp)
				else: RMDqaKOvQCXghu81Gc('يبدو أن هناك مشكلة في الاشتراك',KZ4oqDz5xgA2tkGcTaeQ1Lh3dp)
	if jcidYWSngJx2lphkZN7f5AqRu and N4NMhSyT5mkwKZRY and r0VNJTaX5vOsme4=='Active':
		SsziMZd5UbeL2NRxVpwjO(F0FeocLXmbJhdBwQnS18PCHZIU,'.\tChecking M3U URL   [ M3U account is OK ]   [ '+jcidYWSngJx2lphkZN7f5AqRu+' ]')
		RepGgckNqE = True
	else:
		SsziMZd5UbeL2NRxVpwjO(E7lrS9VXJF58d2NUAfkvxwjmHM,'Checking M3U URL   [ Does not work ]   [ '+jcidYWSngJx2lphkZN7f5AqRu+' ]')
		if bUHVjvzwnyi: NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,'فحص اشتراك ـM3U','رابط اشتراك ـM3U الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـM3U وقم بإضافة رابط ـM3U جديد أو قم بإصلاح الرابط القديم')
		RepGgckNqE = False
	return RepGgckNqE,XOSVmnLg957jiID0Q1RPlvpbkw,beE5JlkVDgdzro4y
def yKvktsG9BnHTge4fVuREIpm83(Vea0sXycdJ8LFSMzhB5Zt73u2rD,MBHEOqmtX3SPb2whAFr6ul,k9U0ol3zPOiDyQ,SwDfU9qkrKo6QW2y,bUHVjvzwnyi=True):
	if not SwDfU9qkrKo6QW2y: SwDfU9qkrKo6QW2y = '1'
	if not Im36vznMobP7WCNfFY2lJZ(Vea0sXycdJ8LFSMzhB5Zt73u2rD,bUHVjvzwnyi): return
	RTr92nPJkjuBoDMbELV8Oa = wwATViQ0xDaoNMEK4v3PIeC8UzZ5(Vea0sXycdJ8LFSMzhB5Zt73u2rD,MBHEOqmtX3SPb2whAFr6ul)
	a2a0mpV49WBD5sIFYzU = sZHYrLPog4wmuW0ECdc(RTr92nPJkjuBoDMbELV8Oa,'list',MBHEOqmtX3SPb2whAFr6ul,k9U0ol3zPOiDyQ)
	ayzNrCUegfFI57jLp94K1ocED = int(SwDfU9qkrKo6QW2y)*100
	BpNo34OSb8fYgxJIA5c1sRvZ = ayzNrCUegfFI57jLp94K1ocED-100
	for SUkst0aLFhj,FghljxYu6ZiV7nCmtSUrywKDek,kxY4EfTKobmQJ8OathHI53,qsSTC3ZfW1NthKUbHQEnlpP9GY5 in a2a0mpV49WBD5sIFYzU[BpNo34OSb8fYgxJIA5c1sRvZ:ayzNrCUegfFI57jLp94K1ocED]:
		GXvW7eaHFjyiI6QUJ8brY9pKAs = ('GROUPED' in MBHEOqmtX3SPb2whAFr6ul or MBHEOqmtX3SPb2whAFr6ul=='ALL')
		esqA6aNSBjd5J = ('GROUPED' not in MBHEOqmtX3SPb2whAFr6ul and MBHEOqmtX3SPb2whAFr6ul!='ALL')
		if GXvW7eaHFjyiI6QUJ8brY9pKAs or esqA6aNSBjd5J:
			if   'ARCHIVED'  in MBHEOqmtX3SPb2whAFr6ul: USuRxnPlV5.menuItemsLIST.append(['folder',XQgovGj6VkUFxH4a2+FghljxYu6ZiV7nCmtSUrywKDek,kxY4EfTKobmQJ8OathHI53,718,qsSTC3ZfW1NthKUbHQEnlpP9GY5,cdZKMn68Pzg4,'ARCHIVED',cdZKMn68Pzg4,{'folder':Vea0sXycdJ8LFSMzhB5Zt73u2rD}])
			elif 'EPG' 		 in MBHEOqmtX3SPb2whAFr6ul: USuRxnPlV5.menuItemsLIST.append(['folder',XQgovGj6VkUFxH4a2+FghljxYu6ZiV7nCmtSUrywKDek,kxY4EfTKobmQJ8OathHI53,718,qsSTC3ZfW1NthKUbHQEnlpP9GY5,cdZKMn68Pzg4,'FULL_EPG',cdZKMn68Pzg4,{'folder':Vea0sXycdJ8LFSMzhB5Zt73u2rD}])
			elif 'TIMESHIFT' in MBHEOqmtX3SPb2whAFr6ul: USuRxnPlV5.menuItemsLIST.append(['folder',XQgovGj6VkUFxH4a2+FghljxYu6ZiV7nCmtSUrywKDek,kxY4EfTKobmQJ8OathHI53,718,qsSTC3ZfW1NthKUbHQEnlpP9GY5,cdZKMn68Pzg4,'TIMESHIFT',cdZKMn68Pzg4,{'folder':Vea0sXycdJ8LFSMzhB5Zt73u2rD}])
			elif 'LIVE' 	 in MBHEOqmtX3SPb2whAFr6ul: USuRxnPlV5.menuItemsLIST.append(['live',XQgovGj6VkUFxH4a2+FghljxYu6ZiV7nCmtSUrywKDek,kxY4EfTKobmQJ8OathHI53,715,qsSTC3ZfW1NthKUbHQEnlpP9GY5,cdZKMn68Pzg4,cdZKMn68Pzg4,SUkst0aLFhj,{'folder':Vea0sXycdJ8LFSMzhB5Zt73u2rD}])
			else: USuRxnPlV5.menuItemsLIST.append(['video',XQgovGj6VkUFxH4a2+FghljxYu6ZiV7nCmtSUrywKDek,kxY4EfTKobmQJ8OathHI53,715,qsSTC3ZfW1NthKUbHQEnlpP9GY5,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,{'folder':Vea0sXycdJ8LFSMzhB5Zt73u2rD}])
	om3XlN9aWpCnAEuYO = len(a2a0mpV49WBD5sIFYzU)
	BsewTaqSNkcuHhtf8pZvGVD7L(Vea0sXycdJ8LFSMzhB5Zt73u2rD,SwDfU9qkrKo6QW2y,MBHEOqmtX3SPb2whAFr6ul,714,om3XlN9aWpCnAEuYO,k9U0ol3zPOiDyQ)
	return
def Ky5oFjzA2ide4hJ1bk(H1oNZDLCh8gf9XeUlR3nwBS):
	zJLApFBcIhnSj('link',H1oNZDLCh8gf9XeUlR3nwBS+'هذه القائمة إما فارغة أو غير موجودة',cdZKMn68Pzg4,9999)
	zJLApFBcIhnSj('link',H1oNZDLCh8gf9XeUlR3nwBS+'أو الخدمة غير موجودة في اشتراكك',cdZKMn68Pzg4,9999)
	zJLApFBcIhnSj('link',H1oNZDLCh8gf9XeUlR3nwBS+'أو رابط M3U الذي أنت أضفته غير صحيح',cdZKMn68Pzg4,9999)
	return
def iBT7IHNAlEYDgsRthp3x9ynd(Vea0sXycdJ8LFSMzhB5Zt73u2rD,MBHEOqmtX3SPb2whAFr6ul,k9U0ol3zPOiDyQ,SwDfU9qkrKo6QW2y,weTCh5tEVZQqy4D=cdZKMn68Pzg4,bUHVjvzwnyi=True):
	if not SwDfU9qkrKo6QW2y: SwDfU9qkrKo6QW2y = '1'
	H1oNZDLCh8gf9XeUlR3nwBS = XQgovGj6VkUFxH4a2
	if not Im36vznMobP7WCNfFY2lJZ(Vea0sXycdJ8LFSMzhB5Zt73u2rD,bUHVjvzwnyi): return False
	if '__SERIES__' in k9U0ol3zPOiDyQ: vn6PNIOb9XE0ycTVMlS,UJV1e2PfIrN0AGi = k9U0ol3zPOiDyQ.split('__SERIES__')
	else: vn6PNIOb9XE0ycTVMlS,UJV1e2PfIrN0AGi = k9U0ol3zPOiDyQ,cdZKMn68Pzg4
	RTr92nPJkjuBoDMbELV8Oa = wwATViQ0xDaoNMEK4v3PIeC8UzZ5(Vea0sXycdJ8LFSMzhB5Zt73u2rD,MBHEOqmtX3SPb2whAFr6ul)
	vq672jbXdaYK4CZxEFgu = sZHYrLPog4wmuW0ECdc(RTr92nPJkjuBoDMbELV8Oa,'list',MBHEOqmtX3SPb2whAFr6ul,'__GROUPS__')
	if not vq672jbXdaYK4CZxEFgu: return False
	iN21XgetQf5caGsFRwhCqWP = []
	for RRSaoMVs1BJdWNEpAP,qsSTC3ZfW1NthKUbHQEnlpP9GY5 in vq672jbXdaYK4CZxEFgu:
		if '===== ===== =====' in RRSaoMVs1BJdWNEpAP:
			zJLApFBcIhnSj('link',H1oNZDLCh8gf9XeUlR3nwBS+RRSaoMVs1BJdWNEpAP,cdZKMn68Pzg4,9999)
			zJLApFBcIhnSj('link',H1oNZDLCh8gf9XeUlR3nwBS+RRSaoMVs1BJdWNEpAP,cdZKMn68Pzg4,9999)
			continue
		if weTCh5tEVZQqy4D:
			if '__SERIES__' in RRSaoMVs1BJdWNEpAP: H1oNZDLCh8gf9XeUlR3nwBS = 'SERIES'
			elif '!!__UNKNOWN__!!' in RRSaoMVs1BJdWNEpAP: H1oNZDLCh8gf9XeUlR3nwBS = 'UNKNOWN'
			elif 'LIVE' in MBHEOqmtX3SPb2whAFr6ul: H1oNZDLCh8gf9XeUlR3nwBS = 'LIVE'
			else: H1oNZDLCh8gf9XeUlR3nwBS = 'VIDEOS'
			H1oNZDLCh8gf9XeUlR3nwBS = ','+Gzygq01Kcb9U3+H1oNZDLCh8gf9XeUlR3nwBS+': '+kH8E2zqNyims6KJfI
		if '__SERIES__' in RRSaoMVs1BJdWNEpAP: hewJPMkX2xfSCAgFlo5b,fHb7iXcpWT1U2sGCJY = RRSaoMVs1BJdWNEpAP.split('__SERIES__')
		else: hewJPMkX2xfSCAgFlo5b,fHb7iXcpWT1U2sGCJY = RRSaoMVs1BJdWNEpAP,cdZKMn68Pzg4
		if not k9U0ol3zPOiDyQ:
			if hewJPMkX2xfSCAgFlo5b in iN21XgetQf5caGsFRwhCqWP: continue
			iN21XgetQf5caGsFRwhCqWP.append(hewJPMkX2xfSCAgFlo5b)
			if 'RANDOM' in weTCh5tEVZQqy4D: zJLApFBcIhnSj('folder',H1oNZDLCh8gf9XeUlR3nwBS+hewJPMkX2xfSCAgFlo5b,MBHEOqmtX3SPb2whAFr6ul,168,cdZKMn68Pzg4,'1',RRSaoMVs1BJdWNEpAP,cdZKMn68Pzg4,{'folder':Vea0sXycdJ8LFSMzhB5Zt73u2rD})
			elif '__SERIES__' in RRSaoMVs1BJdWNEpAP: zJLApFBcIhnSj('folder',H1oNZDLCh8gf9XeUlR3nwBS+hewJPMkX2xfSCAgFlo5b,MBHEOqmtX3SPb2whAFr6ul,713,cdZKMn68Pzg4,'1',RRSaoMVs1BJdWNEpAP,cdZKMn68Pzg4,{'folder':Vea0sXycdJ8LFSMzhB5Zt73u2rD})
			else: zJLApFBcIhnSj('folder',H1oNZDLCh8gf9XeUlR3nwBS+hewJPMkX2xfSCAgFlo5b,MBHEOqmtX3SPb2whAFr6ul,714,cdZKMn68Pzg4,'1',RRSaoMVs1BJdWNEpAP,cdZKMn68Pzg4,{'folder':Vea0sXycdJ8LFSMzhB5Zt73u2rD})
		elif '__SERIES__' in RRSaoMVs1BJdWNEpAP and hewJPMkX2xfSCAgFlo5b==vn6PNIOb9XE0ycTVMlS:
			if fHb7iXcpWT1U2sGCJY in iN21XgetQf5caGsFRwhCqWP: continue
			iN21XgetQf5caGsFRwhCqWP.append(fHb7iXcpWT1U2sGCJY)
			if 'RANDOM' in weTCh5tEVZQqy4D: zJLApFBcIhnSj('folder',H1oNZDLCh8gf9XeUlR3nwBS+fHb7iXcpWT1U2sGCJY,MBHEOqmtX3SPb2whAFr6ul,168,cdZKMn68Pzg4,'1',RRSaoMVs1BJdWNEpAP,cdZKMn68Pzg4,{'folder':Vea0sXycdJ8LFSMzhB5Zt73u2rD})
			else: zJLApFBcIhnSj('folder',H1oNZDLCh8gf9XeUlR3nwBS+fHb7iXcpWT1U2sGCJY,MBHEOqmtX3SPb2whAFr6ul,714,qsSTC3ZfW1NthKUbHQEnlpP9GY5,'1',RRSaoMVs1BJdWNEpAP,cdZKMn68Pzg4,{'folder':Vea0sXycdJ8LFSMzhB5Zt73u2rD})
	USuRxnPlV5.menuItemsLIST[:] = sorted(USuRxnPlV5.menuItemsLIST,reverse=False,key=lambda D8QslnRP0KIkdYcbviAGTSEo7U69z: D8QslnRP0KIkdYcbviAGTSEo7U69z[1].lower())
	if not weTCh5tEVZQqy4D:
		ayzNrCUegfFI57jLp94K1ocED = int(SwDfU9qkrKo6QW2y)*100
		BpNo34OSb8fYgxJIA5c1sRvZ = ayzNrCUegfFI57jLp94K1ocED-100
		om3XlN9aWpCnAEuYO = len(USuRxnPlV5.menuItemsLIST)
		USuRxnPlV5.menuItemsLIST[:] = USuRxnPlV5.menuItemsLIST[BpNo34OSb8fYgxJIA5c1sRvZ:ayzNrCUegfFI57jLp94K1ocED]
		BsewTaqSNkcuHhtf8pZvGVD7L(Vea0sXycdJ8LFSMzhB5Zt73u2rD,SwDfU9qkrKo6QW2y,MBHEOqmtX3SPb2whAFr6ul,713,om3XlN9aWpCnAEuYO,k9U0ol3zPOiDyQ)
	return True
def H5YObrSN4ZomGWidXpVtPKJ(Vea0sXycdJ8LFSMzhB5Zt73u2rD,kxY4EfTKobmQJ8OathHI53,eeBfNX6GEZlyU5MLdCub1nAYrjv):
	if not Im36vznMobP7WCNfFY2lJZ(Vea0sXycdJ8LFSMzhB5Zt73u2rD,True): return
	pj3iPglDkueR29AH6U = lr845giTQzJ01vqZP(Vea0sXycdJ8LFSMzhB5Zt73u2rD)
	P4OVJ8jvKxU = Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.getSetting('av.m3u.timestamp_'+Vea0sXycdJ8LFSMzhB5Zt73u2rD)
	if not P4OVJ8jvKxU or BbIVuS4KecnqNvZz5GptR-int(P4OVJ8jvKxU)>24*lgZ9dofsL1JV5vQHTDS:
		RepGgckNqE,XOSVmnLg957jiID0Q1RPlvpbkw,beE5JlkVDgdzro4y = hX7rFmcGbqlaER2xL(Vea0sXycdJ8LFSMzhB5Zt73u2rD,False)
		if not RepGgckNqE: return
	vbArRLplfGVWP6y3OU7ojI08YCm = int(Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.getSetting('av.m3u.timediff_'+Vea0sXycdJ8LFSMzhB5Zt73u2rD))
	Szg3qvldoOyU = Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.getSetting('av.m3u.server_'+Vea0sXycdJ8LFSMzhB5Zt73u2rD)
	YsyfvFHASN = Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.getSetting('av.m3u.username_'+Vea0sXycdJ8LFSMzhB5Zt73u2rD)
	ww2AC3SkbFQXc6Pj = Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.getSetting('av.m3u.password_'+Vea0sXycdJ8LFSMzhB5Zt73u2rD)
	CESTGisrcgVOl = kxY4EfTKobmQJ8OathHI53.split(KCQExdbYFqM)
	vUjB2fqo7IJm1YyMhP4S0 = CESTGisrcgVOl[-1].replace('.ts',cdZKMn68Pzg4).replace('.m3u8',cdZKMn68Pzg4)
	if eeBfNX6GEZlyU5MLdCub1nAYrjv=='SHORT_EPG': VX6dUojJM9b4Il7 = 'get_short_epg'
	else: VX6dUojJM9b4Il7 = 'get_simple_data_table'
	jcidYWSngJx2lphkZN7f5AqRu,AZnTKcDC0twiN2l6Fzxr3f,Szg3qvldoOyU,YsyfvFHASN,ww2AC3SkbFQXc6Pj = EEJjV7pU0Cy9RScBXefYh(Vea0sXycdJ8LFSMzhB5Zt73u2rD)
	if not YsyfvFHASN: return
	sF4E5y9qwdB8pKveI0TVMn = jcidYWSngJx2lphkZN7f5AqRu+'&action='+VX6dUojJM9b4Il7+'&stream_id='+vUjB2fqo7IJm1YyMhP4S0
	ajEFui1BI6z8RJor = p1Y6cxNUTHaXlsh8(fS25N8gAZxpbnLi3srX7PJ,sF4E5y9qwdB8pKveI0TVMn,cdZKMn68Pzg4,pj3iPglDkueR29AH6U,cdZKMn68Pzg4,'M3U-EPG_ITEMS-2nd')
	yyPXg6sSd3nOMqzkwGIZaVjD1NpBQ = lMeKd3hC6cmS('dict',ajEFui1BI6z8RJor)
	lv4UPKVMI1OiXy36 = yyPXg6sSd3nOMqzkwGIZaVjD1NpBQ['epg_listings']
	eo948RaukQNt7r = []
	if eeBfNX6GEZlyU5MLdCub1nAYrjv in ['ARCHIVED','TIMESHIFT']:
		for ZUSphruPxENelqv0LY in lv4UPKVMI1OiXy36:
			if ZUSphruPxENelqv0LY['has_archive']==1:
				eo948RaukQNt7r.append(ZUSphruPxENelqv0LY)
				if eeBfNX6GEZlyU5MLdCub1nAYrjv in ['TIMESHIFT']: break
		if not eo948RaukQNt7r: return
		zJLApFBcIhnSj('link',XQgovGj6VkUFxH4a2+Gzygq01Kcb9U3+'الملفات الأولي بهذه القائمة قد لا تعمل'+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
		if eeBfNX6GEZlyU5MLdCub1nAYrjv in ['TIMESHIFT']:
			M578Enu0x4UzdORyf = 2
			fdqGsHhbJn = M578Enu0x4UzdORyf*lgZ9dofsL1JV5vQHTDS
			eo948RaukQNt7r = []
			YJQ0LT7uyUI = int(int(ZUSphruPxENelqv0LY['start_timestamp'])/fdqGsHhbJn)*fdqGsHhbJn
			iLM6WcNQfKZ4 = BbIVuS4KecnqNvZz5GptR+fdqGsHhbJn
			OOH7JBcfUMz4CX = int((iLM6WcNQfKZ4-YJQ0LT7uyUI)/lgZ9dofsL1JV5vQHTDS)
			for ATg1dc5byeWvr6pVzBPF in range(OOH7JBcfUMz4CX):
				if ATg1dc5byeWvr6pVzBPF>=6:
					if ATg1dc5byeWvr6pVzBPF%M578Enu0x4UzdORyf!=0: continue
					TT4qsM7VWD8aIN9CnLhylF = fdqGsHhbJn
				else: TT4qsM7VWD8aIN9CnLhylF = fdqGsHhbJn//2
				OwfRnUWLKXmIN3BF = YJQ0LT7uyUI+ATg1dc5byeWvr6pVzBPF*lgZ9dofsL1JV5vQHTDS
				ZUSphruPxENelqv0LY = {}
				ZUSphruPxENelqv0LY['title'] = cdZKMn68Pzg4
				C4wF1LSOhfRW6XqxajoyY3MGv2E = bD7kJZhMCdaqF68P45KlNIgO1.localtime(OwfRnUWLKXmIN3BF-vbArRLplfGVWP6y3OU7ojI08YCm-lgZ9dofsL1JV5vQHTDS)
				ZUSphruPxENelqv0LY['start'] = bD7kJZhMCdaqF68P45KlNIgO1.strftime('%Y.%m.%d %H:%M:%S',C4wF1LSOhfRW6XqxajoyY3MGv2E)
				ZUSphruPxENelqv0LY['start_timestamp'] = str(OwfRnUWLKXmIN3BF)
				ZUSphruPxENelqv0LY['stop_timestamp'] = str(OwfRnUWLKXmIN3BF+TT4qsM7VWD8aIN9CnLhylF)
				eo948RaukQNt7r.append(ZUSphruPxENelqv0LY)
	elif eeBfNX6GEZlyU5MLdCub1nAYrjv in ['SHORT_EPG','FULL_EPG']: eo948RaukQNt7r = lv4UPKVMI1OiXy36
	if eeBfNX6GEZlyU5MLdCub1nAYrjv=='FULL_EPG' and len(eo948RaukQNt7r)>0:
		zJLApFBcIhnSj('link',XQgovGj6VkUFxH4a2+Gzygq01Kcb9U3+'هذه قائمة برامج القنوات (جدول فقط)ـ'+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	CqKjfNdvGBtQE5y = []
	qsSTC3ZfW1NthKUbHQEnlpP9GY5 = bu6LzUQF7K.getInfoLabel('ListItem.Icon')
	for ZUSphruPxENelqv0LY in eo948RaukQNt7r:
		FghljxYu6ZiV7nCmtSUrywKDek = abn2REWAS3FwTN0rlQmgOk.b64decode(ZUSphruPxENelqv0LY['title'])
		if W5domCu6XrQUFkiPpa3bNLtHglG: FghljxYu6ZiV7nCmtSUrywKDek = FghljxYu6ZiV7nCmtSUrywKDek.decode(vczMIlkCAh2u10B3)
		OwfRnUWLKXmIN3BF = int(ZUSphruPxENelqv0LY['start_timestamp'])
		ss8N32pCxIUekBM = int(ZUSphruPxENelqv0LY['stop_timestamp'])
		dvCwYeAugFhrV = str(int((ss8N32pCxIUekBM-OwfRnUWLKXmIN3BF+59)/60))
		Q1zM0pnwLTfl3sHA49RbtUahgmY8 = ZUSphruPxENelqv0LY['start'].replace(VBpIH2QSmvDGlA6TO3e,':')
		C4wF1LSOhfRW6XqxajoyY3MGv2E = bD7kJZhMCdaqF68P45KlNIgO1.localtime(OwfRnUWLKXmIN3BF-lgZ9dofsL1JV5vQHTDS)
		HmXAekGphtICY17gfKv0nib = bD7kJZhMCdaqF68P45KlNIgO1.strftime('%H:%M',C4wF1LSOhfRW6XqxajoyY3MGv2E)
		vAKTP51JReHz4Yf = bD7kJZhMCdaqF68P45KlNIgO1.strftime('%a',C4wF1LSOhfRW6XqxajoyY3MGv2E)
		if eeBfNX6GEZlyU5MLdCub1nAYrjv=='SHORT_EPG': FghljxYu6ZiV7nCmtSUrywKDek = bxf7gZvNK29cEoiAIJlMq0dP+HmXAekGphtICY17gfKv0nib+' ـ '+FghljxYu6ZiV7nCmtSUrywKDek+kH8E2zqNyims6KJfI
		elif eeBfNX6GEZlyU5MLdCub1nAYrjv=='TIMESHIFT': FghljxYu6ZiV7nCmtSUrywKDek = vAKTP51JReHz4Yf+VBpIH2QSmvDGlA6TO3e+HmXAekGphtICY17gfKv0nib+' ('+dvCwYeAugFhrV+'min)'
		else: FghljxYu6ZiV7nCmtSUrywKDek = vAKTP51JReHz4Yf+VBpIH2QSmvDGlA6TO3e+HmXAekGphtICY17gfKv0nib+' ('+dvCwYeAugFhrV+'min)   '+FghljxYu6ZiV7nCmtSUrywKDek+' ـ'
		if eeBfNX6GEZlyU5MLdCub1nAYrjv in ['ARCHIVED','FULL_EPG','TIMESHIFT']:
			MX8D1fxdbnFa = Szg3qvldoOyU+'/timeshift/'+YsyfvFHASN+KCQExdbYFqM+ww2AC3SkbFQXc6Pj+KCQExdbYFqM+dvCwYeAugFhrV+KCQExdbYFqM+Q1zM0pnwLTfl3sHA49RbtUahgmY8+KCQExdbYFqM+vUjB2fqo7IJm1YyMhP4S0+'.m3u8'
			if eeBfNX6GEZlyU5MLdCub1nAYrjv=='FULL_EPG': zJLApFBcIhnSj('link',XQgovGj6VkUFxH4a2+FghljxYu6ZiV7nCmtSUrywKDek,MX8D1fxdbnFa,9999,qsSTC3ZfW1NthKUbHQEnlpP9GY5,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,{'folder':Vea0sXycdJ8LFSMzhB5Zt73u2rD})
			else: zJLApFBcIhnSj('video',XQgovGj6VkUFxH4a2+FghljxYu6ZiV7nCmtSUrywKDek,MX8D1fxdbnFa,715,qsSTC3ZfW1NthKUbHQEnlpP9GY5,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,{'folder':Vea0sXycdJ8LFSMzhB5Zt73u2rD})
		CqKjfNdvGBtQE5y.append(FghljxYu6ZiV7nCmtSUrywKDek)
	if eeBfNX6GEZlyU5MLdCub1nAYrjv=='SHORT_EPG' and CqKjfNdvGBtQE5y: IQ0dKViyGxE = NcRbram3fy(CqKjfNdvGBtQE5y)
	return CqKjfNdvGBtQE5y
def jyripTCwLE0(Vea0sXycdJ8LFSMzhB5Zt73u2rD):
	if not Im36vznMobP7WCNfFY2lJZ(Vea0sXycdJ8LFSMzhB5Zt73u2rD,True): return
	Szg3qvldoOyU,zNWbDhltCB9SxE5KkYTyuaA,qCFMVt46f0lap3wgn = cdZKMn68Pzg4,0,0
	RepGgckNqE,XOSVmnLg957jiID0Q1RPlvpbkw,beE5JlkVDgdzro4y = hX7rFmcGbqlaER2xL(Vea0sXycdJ8LFSMzhB5Zt73u2rD,False)
	if RepGgckNqE:
		sRyMGxwU9HgDo7Pc = coTKUpHL9yaPF3b1S(XOSVmnLg957jiID0Q1RPlvpbkw)
		zNWbDhltCB9SxE5KkYTyuaA = zzb5DtLHap736(sRyMGxwU9HgDo7Pc[0],int(beE5JlkVDgdzro4y))
		RTr92nPJkjuBoDMbELV8Oa = wwATViQ0xDaoNMEK4v3PIeC8UzZ5(Vea0sXycdJ8LFSMzhB5Zt73u2rD,'LIVE_GROUPED')
		cY1DzUC9nxHgQM4BjIts = sZHYrLPog4wmuW0ECdc(RTr92nPJkjuBoDMbELV8Oa,'list','LIVE_GROUPED')
		a2a0mpV49WBD5sIFYzU = sZHYrLPog4wmuW0ECdc(RTr92nPJkjuBoDMbELV8Oa,'list','LIVE_GROUPED',cY1DzUC9nxHgQM4BjIts[1])
		kxY4EfTKobmQJ8OathHI53 = a2a0mpV49WBD5sIFYzU[0][2]
		Bg7U4Ptj5Aw = ffUFBJQ57j2XgoGeOLn9uwpC.findall('://(.*?)/',kxY4EfTKobmQJ8OathHI53,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		Bg7U4Ptj5Aw = Bg7U4Ptj5Aw[0]
		if ':' in Bg7U4Ptj5Aw: MnmU9NpO6eTzZW,fJ9R5nchWE = Bg7U4Ptj5Aw.split(':')
		else: MnmU9NpO6eTzZW,fJ9R5nchWE = Bg7U4Ptj5Aw,'80'
		DkUaLwqye4Qhd8TfV7nNuvEM = coTKUpHL9yaPF3b1S(MnmU9NpO6eTzZW)
		qCFMVt46f0lap3wgn = zzb5DtLHap736(DkUaLwqye4Qhd8TfV7nNuvEM[0],int(fJ9R5nchWE))
	if zNWbDhltCB9SxE5KkYTyuaA and qCFMVt46f0lap3wgn:
		KZ4oqDz5xgA2tkGcTaeQ1Lh3dp = 'هل تريد استخدام السيرفر الأصلي أم السيرفر الأسرع ؟!!'
		KZ4oqDz5xgA2tkGcTaeQ1Lh3dp += '\n\n'+'وقت ضائع في السيرفر الأصلي'+ssELJkeScrtni2+str(int(qCFMVt46f0lap3wgn*1000))+' ملي ثانية'
		KZ4oqDz5xgA2tkGcTaeQ1Lh3dp += '\n\n'+'وقت ضائع في السيرفر البديل'+ssELJkeScrtni2+str(int(zNWbDhltCB9SxE5KkYTyuaA*1000))+' ملي ثانية'
		GPQCWezyxpbjhHNXMVEaI4FR = JyLdvftP3CU('center','السيرفر الأصلي','السيرفر الأسرع',OPEJxmUqr9wAX1i,KZ4oqDz5xgA2tkGcTaeQ1Lh3dp)
		if GPQCWezyxpbjhHNXMVEaI4FR==1 and zNWbDhltCB9SxE5KkYTyuaA<qCFMVt46f0lap3wgn: Szg3qvldoOyU = XOSVmnLg957jiID0Q1RPlvpbkw+':'+beE5JlkVDgdzro4y
	else: NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,'البرنامج لم يجد السيرفر البديل')
	Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.setSetting('av.m3u.server_'+Vea0sXycdJ8LFSMzhB5Zt73u2rD,Szg3qvldoOyU)
	return
def RPZbqous7rtdy56LeI18Cv04AKHW(Vea0sXycdJ8LFSMzhB5Zt73u2rD,kxY4EfTKobmQJ8OathHI53,kuMXTLrvIZGfjCDtA9YNJ5SxQK):
	J8wUvxLd7kNoGf4pY1XCn = Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.getSetting('av.m3u.useragent_'+Vea0sXycdJ8LFSMzhB5Zt73u2rD)
	ITXKP0wLvFMQ9Niq6ctH8 = Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.getSetting('av.m3u.referer_'+Vea0sXycdJ8LFSMzhB5Zt73u2rD)
	if J8wUvxLd7kNoGf4pY1XCn or ITXKP0wLvFMQ9Niq6ctH8:
		kxY4EfTKobmQJ8OathHI53 += '|'
		if J8wUvxLd7kNoGf4pY1XCn: kxY4EfTKobmQJ8OathHI53 += '&User-Agent='+J8wUvxLd7kNoGf4pY1XCn
		if ITXKP0wLvFMQ9Niq6ctH8: kxY4EfTKobmQJ8OathHI53 += '&Referer='+ITXKP0wLvFMQ9Niq6ctH8
		kxY4EfTKobmQJ8OathHI53 = kxY4EfTKobmQJ8OathHI53.replace('|&','|')
	bmgwWLk3er(kxY4EfTKobmQJ8OathHI53,LMihk2Vzl4DesIQ65TGmvxqcKdHp,kuMXTLrvIZGfjCDtA9YNJ5SxQK)
	return
def BzSKH15l2PN8dgraGXxMj3tQ7Um(Vea0sXycdJ8LFSMzhB5Zt73u2rD):
	NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,'تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـM3U أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـM3U تحتاج ـUser-Agent خاص')
	J8wUvxLd7kNoGf4pY1XCn = Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.getSetting('av.m3u.useragent_'+Vea0sXycdJ8LFSMzhB5Zt73u2rD)
	i2Q8cvOzsg9wkVDUYNyo5ZplA1 = JyLdvftP3CU('center','استخدام الأصلي','تعديل القديم',J8wUvxLd7kNoGf4pY1XCn,'هذا هو ـUser-Agent المستخدم حاليا مع ـM3U الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـM3U ؟!')
	if i2Q8cvOzsg9wkVDUYNyo5ZplA1==1: J8wUvxLd7kNoGf4pY1XCn = BzkmLuvJD9n25Pg('أكتب ـM3U User-Agent جديد',J8wUvxLd7kNoGf4pY1XCn,True)
	else: J8wUvxLd7kNoGf4pY1XCn = 'Unknown'
	if J8wUvxLd7kNoGf4pY1XCn==VBpIH2QSmvDGlA6TO3e:
		NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,'غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	i2Q8cvOzsg9wkVDUYNyo5ZplA1 = JyLdvftP3CU('center',cdZKMn68Pzg4,cdZKMn68Pzg4,J8wUvxLd7kNoGf4pY1XCn,'هل تريد استخدام هذا ـUser-Agent بدلا من  القديم ؟')
	if i2Q8cvOzsg9wkVDUYNyo5ZplA1!=1:
		NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,'تم الإلغاء')
		return
	Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.setSetting('av.m3u.useragent_'+Vea0sXycdJ8LFSMzhB5Zt73u2rD,J8wUvxLd7kNoGf4pY1XCn)
	SYaTv4t7q0cy96(Vea0sXycdJ8LFSMzhB5Zt73u2rD)
	return
def Y2fWsBKEyhaNv7Pl9Xwej(Vea0sXycdJ8LFSMzhB5Zt73u2rD):
	NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,'تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـM3U أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـM3U تحتاج ـReferer خاص')
	ITXKP0wLvFMQ9Niq6ctH8 = Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.getSetting('av.m3u.referer_'+Vea0sXycdJ8LFSMzhB5Zt73u2rD)
	i2Q8cvOzsg9wkVDUYNyo5ZplA1 = JyLdvftP3CU('center','استخدام الأصلي','تعديل القديم',ITXKP0wLvFMQ9Niq6ctH8,'هذا هو ـReferer المستخدم حاليا مع ـM3U الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـM3U ؟!')
	if i2Q8cvOzsg9wkVDUYNyo5ZplA1==1: ITXKP0wLvFMQ9Niq6ctH8 = BzkmLuvJD9n25Pg('أكتب ـM3U Referer جديد',ITXKP0wLvFMQ9Niq6ctH8,True)
	else: ITXKP0wLvFMQ9Niq6ctH8 = cdZKMn68Pzg4
	if ITXKP0wLvFMQ9Niq6ctH8==VBpIH2QSmvDGlA6TO3e:
		NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,'غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	i2Q8cvOzsg9wkVDUYNyo5ZplA1 = JyLdvftP3CU('center',cdZKMn68Pzg4,cdZKMn68Pzg4,ITXKP0wLvFMQ9Niq6ctH8,'هل تريد استخدام هذا ـReferer بدلا من  القديم ؟')
	if i2Q8cvOzsg9wkVDUYNyo5ZplA1!=1:
		NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,'تم الإلغاء')
		return
	Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.setSetting('av.m3u.referer_'+Vea0sXycdJ8LFSMzhB5Zt73u2rD,ITXKP0wLvFMQ9Niq6ctH8)
	SYaTv4t7q0cy96(Vea0sXycdJ8LFSMzhB5Zt73u2rD)
	return
def EEJjV7pU0Cy9RScBXefYh(Vea0sXycdJ8LFSMzhB5Zt73u2rD,jnaLZc0VY4ztlEPeIkM9=cdZKMn68Pzg4):
	if not ccRhE7iW5rUDAZGBzmoYl: ccRhE7iW5rUDAZGBzmoYl = Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.getSetting('av.m3u.url_'+Vea0sXycdJ8LFSMzhB5Zt73u2rD)
	Szg3qvldoOyU = CxlbPZwGTcH87e1sWhfSIz29uRUEpV(ccRhE7iW5rUDAZGBzmoYl,'url')
	YsyfvFHASN = ffUFBJQ57j2XgoGeOLn9uwpC.findall('username=(.*?)&',ccRhE7iW5rUDAZGBzmoYl+'&',ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	ww2AC3SkbFQXc6Pj = ffUFBJQ57j2XgoGeOLn9uwpC.findall('password=(.*?)&',ccRhE7iW5rUDAZGBzmoYl+'&',ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if not YsyfvFHASN or not ww2AC3SkbFQXc6Pj:
		NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,'فحص اشتراك M3U','رابط اشتراك ـM3U الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـM3U وقم بإضافة رابط ـM3U جديد أو قم بإصلاح الرابط القديم')
		return cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4
	YsyfvFHASN = YsyfvFHASN[0]
	ww2AC3SkbFQXc6Pj = ww2AC3SkbFQXc6Pj[0]
	jcidYWSngJx2lphkZN7f5AqRu = Szg3qvldoOyU+'/player_api.php?username='+YsyfvFHASN+'&password='+ww2AC3SkbFQXc6Pj
	AZnTKcDC0twiN2l6Fzxr3f = Szg3qvldoOyU+'/get.php?username='+YsyfvFHASN+'&password='+ww2AC3SkbFQXc6Pj+'&type=m3u_plus'
	return jcidYWSngJx2lphkZN7f5AqRu,AZnTKcDC0twiN2l6Fzxr3f,Szg3qvldoOyU,YsyfvFHASN,ww2AC3SkbFQXc6Pj
def sC6JUuF3LSOy8(Vea0sXycdJ8LFSMzhB5Zt73u2rD,KZV2X1pyHqe9Yjtcr8QCxi=cdZKMn68Pzg4):
	A2vi5PFs9t7OU = KZV2X1pyHqe9Yjtcr8QCxi.replace(KCQExdbYFqM,'_').replace(':','_').replace('.','_')
	A2vi5PFs9t7OU = A2vi5PFs9t7OU.replace('?','_').replace('=','_').replace('&','_')
	A2vi5PFs9t7OU = YRESXadfbIy3khwqmL8WC.path.join(qq9xw1jKIVH5kuNGMsPLiCO6Rp0Zv,A2vi5PFs9t7OU).strip('.m3u')+'.m3u'
	return A2vi5PFs9t7OU
def S4msZ0wigOJREj3rolfqQGch(Vea0sXycdJ8LFSMzhB5Zt73u2rD,T60FHByirslQk8f):
	I4u3Rmh0Bd5j9GHNDQnsXt2 = Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.getSetting('av.m3u.url_'+Vea0sXycdJ8LFSMzhB5Zt73u2rD+'_'+T60FHByirslQk8f)
	HGCwXOKctZBSqzV9a614 = True
	if I4u3Rmh0Bd5j9GHNDQnsXt2:
		i2Q8cvOzsg9wkVDUYNyo5ZplA1 = UN8rA03xkWLCGzebyEoF9YDRKBwSMO('center','كتابة جديد','تعديل القديم','مسح القديم','الرابط الحالي هو:',Gzygq01Kcb9U3+I4u3Rmh0Bd5j9GHNDQnsXt2+kH8E2zqNyims6KJfI+'\n\n هذا هو رابط M3U المسجل في البرنامج .. هل تريد تعديله أم تريد كتابة رابط جديد ؟!')
		if i2Q8cvOzsg9wkVDUYNyo5ZplA1==-1: return
		elif i2Q8cvOzsg9wkVDUYNyo5ZplA1==0: I4u3Rmh0Bd5j9GHNDQnsXt2 = cdZKMn68Pzg4
		elif i2Q8cvOzsg9wkVDUYNyo5ZplA1==2:
			i2Q8cvOzsg9wkVDUYNyo5ZplA1 = JyLdvftP3CU('center',cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,'هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if i2Q8cvOzsg9wkVDUYNyo5ZplA1 in [-1,0]: return
			NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,'تم مسح الرابط')
			HGCwXOKctZBSqzV9a614 = False
			eu9I0Al8sXOwQPWaMJ4dog7Tjz2ZKi = cdZKMn68Pzg4
	if HGCwXOKctZBSqzV9a614:
		eu9I0Al8sXOwQPWaMJ4dog7Tjz2ZKi = BzkmLuvJD9n25Pg('اكتب رابط M3U كاملا',I4u3Rmh0Bd5j9GHNDQnsXt2)
		eu9I0Al8sXOwQPWaMJ4dog7Tjz2ZKi = eu9I0Al8sXOwQPWaMJ4dog7Tjz2ZKi.strip(VBpIH2QSmvDGlA6TO3e)
		if not eu9I0Al8sXOwQPWaMJ4dog7Tjz2ZKi:
			i2Q8cvOzsg9wkVDUYNyo5ZplA1 = JyLdvftP3CU('center',cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,'لقد قمت بإدخال رابط فارغ .. هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if i2Q8cvOzsg9wkVDUYNyo5ZplA1 in [-1,0]: return
			NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,'تم مسح الرابط')
		else:
			KZ4oqDz5xgA2tkGcTaeQ1Lh3dp = 'هذه المعلومات تم أخذها من رابط ـM3U الذي انت كتبته . هل تريد استخدامها ؟!\n'
			i2Q8cvOzsg9wkVDUYNyo5ZplA1 = JyLdvftP3CU(cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'الرابط الجديد هو:',Gzygq01Kcb9U3+eu9I0Al8sXOwQPWaMJ4dog7Tjz2ZKi+kH8E2zqNyims6KJfI+'\n\n'+KZ4oqDz5xgA2tkGcTaeQ1Lh3dp)
			if i2Q8cvOzsg9wkVDUYNyo5ZplA1!=1:
				NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,'تم الإلغاء')
				return
	Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.setSetting('av.m3u.url_'+Vea0sXycdJ8LFSMzhB5Zt73u2rD+'_'+T60FHByirslQk8f,eu9I0Al8sXOwQPWaMJ4dog7Tjz2ZKi)
	J8wUvxLd7kNoGf4pY1XCn = Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.getSetting('av.m3u.useragent_'+Vea0sXycdJ8LFSMzhB5Zt73u2rD)
	if not J8wUvxLd7kNoGf4pY1XCn: Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.setSetting('av.m3u.useragent_'+Vea0sXycdJ8LFSMzhB5Zt73u2rD,'Unknown')
	SYaTv4t7q0cy96(Vea0sXycdJ8LFSMzhB5Zt73u2rD)
	return
def KJEI4tXxRaAzPWojcQuLB9k(oPs342UIN6ieO9BVJWZpfXE,DVEcs2ShJgRT,ZpPvIGFq91fzMk64Q7OyNdD5wbL,KGdsq9fgW31RcXomzCxrea,eB76azgblwARsQINn,zqj2ltB4agIQVifTWcxX7nC,AZnTKcDC0twiN2l6Fzxr3f):
	a2a0mpV49WBD5sIFYzU,r0YlJFfeCZaokWS51 = [],[]
	nnALmwq9OGxj20UJd = ['.avi','.mp4','.mkv','.mp3','.webm','.aac']
	for uvjQ0YydJMPkbGeg8I3FUslAW in oPs342UIN6ieO9BVJWZpfXE:
		if zqj2ltB4agIQVifTWcxX7nC%473==0:
			x3G0I9vUCjg(KGdsq9fgW31RcXomzCxrea,40+int(10*zqj2ltB4agIQVifTWcxX7nC/eB76azgblwARsQINn),'قراءة الفيديوهات','الفيديو رقم:-',str(zqj2ltB4agIQVifTWcxX7nC)+' / '+str(eB76azgblwARsQINn))
			if KGdsq9fgW31RcXomzCxrea.iscanceled():
				KGdsq9fgW31RcXomzCxrea.close()
				return None,None,None
		kxY4EfTKobmQJ8OathHI53 = ffUFBJQ57j2XgoGeOLn9uwpC.findall('^(.*?)\n+((http|https|rtmp).*?)$',uvjQ0YydJMPkbGeg8I3FUslAW,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if kxY4EfTKobmQJ8OathHI53:
			uvjQ0YydJMPkbGeg8I3FUslAW,kxY4EfTKobmQJ8OathHI53,ZsOUtP3XGW0Mgexzofd9YkFb56S4rE = kxY4EfTKobmQJ8OathHI53[0]
			kxY4EfTKobmQJ8OathHI53 = kxY4EfTKobmQJ8OathHI53.replace(ssELJkeScrtni2,cdZKMn68Pzg4)
			uvjQ0YydJMPkbGeg8I3FUslAW = uvjQ0YydJMPkbGeg8I3FUslAW.replace(ssELJkeScrtni2,cdZKMn68Pzg4)
		else:
			r0YlJFfeCZaokWS51.append({'line':uvjQ0YydJMPkbGeg8I3FUslAW})
			continue
		Oyc53409UnEIwbB,SUkst0aLFhj,RRSaoMVs1BJdWNEpAP,FghljxYu6ZiV7nCmtSUrywKDek,kuMXTLrvIZGfjCDtA9YNJ5SxQK,bSEjHFX1aun5kox = {},cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,False
		try:
			uvjQ0YydJMPkbGeg8I3FUslAW,FghljxYu6ZiV7nCmtSUrywKDek = uvjQ0YydJMPkbGeg8I3FUslAW.rsplit('",',1)
			uvjQ0YydJMPkbGeg8I3FUslAW = uvjQ0YydJMPkbGeg8I3FUslAW+'"'
		except:
			try: uvjQ0YydJMPkbGeg8I3FUslAW,FghljxYu6ZiV7nCmtSUrywKDek = uvjQ0YydJMPkbGeg8I3FUslAW.rsplit('1,',1)
			except: FghljxYu6ZiV7nCmtSUrywKDek = cdZKMn68Pzg4
		Oyc53409UnEIwbB['url'] = kxY4EfTKobmQJ8OathHI53
		pIm3onk0V6GE4H5QzTrD = ffUFBJQ57j2XgoGeOLn9uwpC.findall(' (.*?)="(.*?)"',uvjQ0YydJMPkbGeg8I3FUslAW,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for D8QslnRP0KIkdYcbviAGTSEo7U69z,bK9NATPpaXoZB6MC in pIm3onk0V6GE4H5QzTrD:
			D8QslnRP0KIkdYcbviAGTSEo7U69z = D8QslnRP0KIkdYcbviAGTSEo7U69z.replace('"',cdZKMn68Pzg4).strip(VBpIH2QSmvDGlA6TO3e)
			Oyc53409UnEIwbB[D8QslnRP0KIkdYcbviAGTSEo7U69z] = bK9NATPpaXoZB6MC.strip(VBpIH2QSmvDGlA6TO3e)
		KnyNSkJH0OzQ = list(Oyc53409UnEIwbB.keys())
		if not FghljxYu6ZiV7nCmtSUrywKDek:
			if 'name' in KnyNSkJH0OzQ and Oyc53409UnEIwbB['name']: FghljxYu6ZiV7nCmtSUrywKDek = Oyc53409UnEIwbB['name']
		Oyc53409UnEIwbB['title'] = FghljxYu6ZiV7nCmtSUrywKDek.strip(VBpIH2QSmvDGlA6TO3e).replace(wr0HaqRdJ2D9LT7nSO1KMe38ly,VBpIH2QSmvDGlA6TO3e).replace(wr0HaqRdJ2D9LT7nSO1KMe38ly,VBpIH2QSmvDGlA6TO3e)
		if 'logo' in KnyNSkJH0OzQ:
			Oyc53409UnEIwbB['img'] = Oyc53409UnEIwbB['logo']
			del Oyc53409UnEIwbB['logo']
		else: Oyc53409UnEIwbB['img'] = cdZKMn68Pzg4
		if 'group' in KnyNSkJH0OzQ and Oyc53409UnEIwbB['group']: RRSaoMVs1BJdWNEpAP = Oyc53409UnEIwbB['group']
		if any(value in kxY4EfTKobmQJ8OathHI53.lower() for value in nnALmwq9OGxj20UJd):
			bSEjHFX1aun5kox = True if 'm3u' not in kxY4EfTKobmQJ8OathHI53 else False
		if bSEjHFX1aun5kox or '__SERIES__' in RRSaoMVs1BJdWNEpAP or '__MOVIES__' in RRSaoMVs1BJdWNEpAP:
			kuMXTLrvIZGfjCDtA9YNJ5SxQK = 'VOD'
			if '__SERIES__' in RRSaoMVs1BJdWNEpAP: kuMXTLrvIZGfjCDtA9YNJ5SxQK = kuMXTLrvIZGfjCDtA9YNJ5SxQK+'_SERIES'
			elif '__MOVIES__' in RRSaoMVs1BJdWNEpAP: kuMXTLrvIZGfjCDtA9YNJ5SxQK = kuMXTLrvIZGfjCDtA9YNJ5SxQK+'_MOVIES'
			else: kuMXTLrvIZGfjCDtA9YNJ5SxQK = kuMXTLrvIZGfjCDtA9YNJ5SxQK+'_UNKNOWN'
			RRSaoMVs1BJdWNEpAP = RRSaoMVs1BJdWNEpAP.replace('__SERIES__',cdZKMn68Pzg4).replace('__MOVIES__',cdZKMn68Pzg4)
		else:
			kuMXTLrvIZGfjCDtA9YNJ5SxQK = 'LIVE'
			if FghljxYu6ZiV7nCmtSUrywKDek in DVEcs2ShJgRT: SUkst0aLFhj = SUkst0aLFhj+'_EPG'
			if FghljxYu6ZiV7nCmtSUrywKDek in ZpPvIGFq91fzMk64Q7OyNdD5wbL: SUkst0aLFhj = SUkst0aLFhj+'_ARCHIVED'
			if not RRSaoMVs1BJdWNEpAP: kuMXTLrvIZGfjCDtA9YNJ5SxQK = kuMXTLrvIZGfjCDtA9YNJ5SxQK+'_UNKNOWN'
			else: kuMXTLrvIZGfjCDtA9YNJ5SxQK = kuMXTLrvIZGfjCDtA9YNJ5SxQK+SUkst0aLFhj
		RRSaoMVs1BJdWNEpAP = RRSaoMVs1BJdWNEpAP.strip(VBpIH2QSmvDGlA6TO3e).replace(wr0HaqRdJ2D9LT7nSO1KMe38ly,VBpIH2QSmvDGlA6TO3e).replace(wr0HaqRdJ2D9LT7nSO1KMe38ly,VBpIH2QSmvDGlA6TO3e)
		if 'LIVE_UNKNOWN' in kuMXTLrvIZGfjCDtA9YNJ5SxQK: RRSaoMVs1BJdWNEpAP = '!!__UNKNOWN_LIVE__!!'
		elif 'VOD_UNKNOWN' in kuMXTLrvIZGfjCDtA9YNJ5SxQK: RRSaoMVs1BJdWNEpAP = '!!__UNKNOWN_VOD__!!'
		elif 'VOD_SERIES' in kuMXTLrvIZGfjCDtA9YNJ5SxQK:
			y0QLtvfZWKV8zghSPF4eDpuRl6 = ffUFBJQ57j2XgoGeOLn9uwpC.findall('(.*?) [Ss]\d+ +[Ee]\d+',Oyc53409UnEIwbB['title'],ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			if y0QLtvfZWKV8zghSPF4eDpuRl6: y0QLtvfZWKV8zghSPF4eDpuRl6 = y0QLtvfZWKV8zghSPF4eDpuRl6[0]
			else: y0QLtvfZWKV8zghSPF4eDpuRl6 = '!!__UNKNOWN_SERIES__!!'
			RRSaoMVs1BJdWNEpAP = RRSaoMVs1BJdWNEpAP+'__SERIES__'+y0QLtvfZWKV8zghSPF4eDpuRl6
		if 'id' in KnyNSkJH0OzQ: del Oyc53409UnEIwbB['id']
		if 'ID' in KnyNSkJH0OzQ: del Oyc53409UnEIwbB['ID']
		if 'name' in KnyNSkJH0OzQ: del Oyc53409UnEIwbB['name']
		FghljxYu6ZiV7nCmtSUrywKDek = Oyc53409UnEIwbB['title']
		FghljxYu6ZiV7nCmtSUrywKDek = XTL0AWmwbDJfGRNi(FghljxYu6ZiV7nCmtSUrywKDek)
		FghljxYu6ZiV7nCmtSUrywKDek = gP1wn5hsKSfVuOHDaz(FghljxYu6ZiV7nCmtSUrywKDek)
		me0pgIcO1rq82JTtVXiLYwlj,RRSaoMVs1BJdWNEpAP = UGqRJKkWISv3PVDjsgBz9uw4f(RRSaoMVs1BJdWNEpAP)
		VjUWbd6POr0eAo,FghljxYu6ZiV7nCmtSUrywKDek = UGqRJKkWISv3PVDjsgBz9uw4f(FghljxYu6ZiV7nCmtSUrywKDek)
		Oyc53409UnEIwbB['type'] = kuMXTLrvIZGfjCDtA9YNJ5SxQK
		Oyc53409UnEIwbB['context'] = SUkst0aLFhj
		Oyc53409UnEIwbB['group'] = RRSaoMVs1BJdWNEpAP.upper()
		Oyc53409UnEIwbB['title'] = FghljxYu6ZiV7nCmtSUrywKDek.upper()
		Oyc53409UnEIwbB['country'] = VjUWbd6POr0eAo.upper()
		Oyc53409UnEIwbB['language'] = me0pgIcO1rq82JTtVXiLYwlj.upper()
		a2a0mpV49WBD5sIFYzU.append(Oyc53409UnEIwbB)
		zqj2ltB4agIQVifTWcxX7nC += 1
	return a2a0mpV49WBD5sIFYzU,zqj2ltB4agIQVifTWcxX7nC,r0YlJFfeCZaokWS51
def gP1wn5hsKSfVuOHDaz(FghljxYu6ZiV7nCmtSUrywKDek):
	FghljxYu6ZiV7nCmtSUrywKDek = FghljxYu6ZiV7nCmtSUrywKDek.replace(wr0HaqRdJ2D9LT7nSO1KMe38ly,VBpIH2QSmvDGlA6TO3e).replace(wr0HaqRdJ2D9LT7nSO1KMe38ly,VBpIH2QSmvDGlA6TO3e).replace(wr0HaqRdJ2D9LT7nSO1KMe38ly,VBpIH2QSmvDGlA6TO3e)
	FghljxYu6ZiV7nCmtSUrywKDek = FghljxYu6ZiV7nCmtSUrywKDek.replace('||','|').replace('___',':').replace('--','-')
	FghljxYu6ZiV7nCmtSUrywKDek = FghljxYu6ZiV7nCmtSUrywKDek.replace('[[','[').replace(']]',']')
	FghljxYu6ZiV7nCmtSUrywKDek = FghljxYu6ZiV7nCmtSUrywKDek.replace('((','(').replace('))',')')
	FghljxYu6ZiV7nCmtSUrywKDek = FghljxYu6ZiV7nCmtSUrywKDek.replace('<<','<').replace('>>','>')
	FghljxYu6ZiV7nCmtSUrywKDek = FghljxYu6ZiV7nCmtSUrywKDek.strip(VBpIH2QSmvDGlA6TO3e)
	return FghljxYu6ZiV7nCmtSUrywKDek
def XBpQbhTqNvYK0Usjn(zQrTywG64KYZIn2jXa,KGdsq9fgW31RcXomzCxrea,T60FHByirslQk8f):
	IvUahiecdM8DmJZ5 = {}
	for bvfP6pcm4enTAQZEUgxoV in zzSXPqifhs8rYnUvbMkuR26B7: IvUahiecdM8DmJZ5[bvfP6pcm4enTAQZEUgxoV+'_'+T60FHByirslQk8f] = []
	eB76azgblwARsQINn = len(zQrTywG64KYZIn2jXa)
	Qp1UTWbC8Aa3oDc = str(eB76azgblwARsQINn)
	zqj2ltB4agIQVifTWcxX7nC = 0
	r0YlJFfeCZaokWS51 = []
	for Oyc53409UnEIwbB in zQrTywG64KYZIn2jXa:
		if zqj2ltB4agIQVifTWcxX7nC%873==0:
			x3G0I9vUCjg(KGdsq9fgW31RcXomzCxrea,50+int(5*zqj2ltB4agIQVifTWcxX7nC/eB76azgblwARsQINn),'تصنيف الفيديوهات الغير مرتبة','الفيديو رقم:-',str(zqj2ltB4agIQVifTWcxX7nC)+' / '+Qp1UTWbC8Aa3oDc)
			if KGdsq9fgW31RcXomzCxrea.iscanceled():
				KGdsq9fgW31RcXomzCxrea.close()
				return None,None
		RRSaoMVs1BJdWNEpAP,SUkst0aLFhj,FghljxYu6ZiV7nCmtSUrywKDek,kxY4EfTKobmQJ8OathHI53,qsSTC3ZfW1NthKUbHQEnlpP9GY5 = Oyc53409UnEIwbB['group'],Oyc53409UnEIwbB['context'],Oyc53409UnEIwbB['title'],Oyc53409UnEIwbB['url'],Oyc53409UnEIwbB['img']
		VjUWbd6POr0eAo,me0pgIcO1rq82JTtVXiLYwlj,bvfP6pcm4enTAQZEUgxoV = Oyc53409UnEIwbB['country'],Oyc53409UnEIwbB['language'],Oyc53409UnEIwbB['type']
		V2RytdCl5ekaxMXpnf0 = (RRSaoMVs1BJdWNEpAP,SUkst0aLFhj,FghljxYu6ZiV7nCmtSUrywKDek,kxY4EfTKobmQJ8OathHI53,qsSTC3ZfW1NthKUbHQEnlpP9GY5)
		lM9TuRvJnLXgsBtx8U = False
		if 'LIVE' in bvfP6pcm4enTAQZEUgxoV:
			if 'UNKNOWN' in bvfP6pcm4enTAQZEUgxoV: IvUahiecdM8DmJZ5['LIVE_UNKNOWN_GROUPED_'+T60FHByirslQk8f].append(V2RytdCl5ekaxMXpnf0)
			elif 'LIVE' in bvfP6pcm4enTAQZEUgxoV: IvUahiecdM8DmJZ5['LIVE_GROUPED_'+T60FHByirslQk8f].append(V2RytdCl5ekaxMXpnf0)
			else: lM9TuRvJnLXgsBtx8U = True
			IvUahiecdM8DmJZ5['LIVE_ORIGINAL_GROUPED_'+T60FHByirslQk8f].append(V2RytdCl5ekaxMXpnf0)
		elif 'VOD' in bvfP6pcm4enTAQZEUgxoV:
			if 'UNKNOWN' in bvfP6pcm4enTAQZEUgxoV: IvUahiecdM8DmJZ5['VOD_UNKNOWN_GROUPED_'+T60FHByirslQk8f].append(V2RytdCl5ekaxMXpnf0)
			elif 'MOVIES' in bvfP6pcm4enTAQZEUgxoV: IvUahiecdM8DmJZ5['VOD_MOVIES_GROUPED_'+T60FHByirslQk8f].append(V2RytdCl5ekaxMXpnf0)
			elif 'SERIES' in bvfP6pcm4enTAQZEUgxoV: IvUahiecdM8DmJZ5['VOD_SERIES_GROUPED_'+T60FHByirslQk8f].append(V2RytdCl5ekaxMXpnf0)
			else: lM9TuRvJnLXgsBtx8U = True
			IvUahiecdM8DmJZ5['VOD_ORIGINAL_GROUPED_'+T60FHByirslQk8f].append(V2RytdCl5ekaxMXpnf0)
		else: lM9TuRvJnLXgsBtx8U = True
		if lM9TuRvJnLXgsBtx8U: r0YlJFfeCZaokWS51.append(Oyc53409UnEIwbB)
		zqj2ltB4agIQVifTWcxX7nC += 1
	CfRFxvwsGgDlVNJHUbMQi9jYZ58cI6 = sorted(zQrTywG64KYZIn2jXa,reverse=False,key=lambda D8QslnRP0KIkdYcbviAGTSEo7U69z: D8QslnRP0KIkdYcbviAGTSEo7U69z['title'].lower())
	del zQrTywG64KYZIn2jXa
	Qp1UTWbC8Aa3oDc = str(eB76azgblwARsQINn)
	zqj2ltB4agIQVifTWcxX7nC = 0
	for Oyc53409UnEIwbB in CfRFxvwsGgDlVNJHUbMQi9jYZ58cI6:
		zqj2ltB4agIQVifTWcxX7nC += 1
		if zqj2ltB4agIQVifTWcxX7nC%873==0:
			x3G0I9vUCjg(KGdsq9fgW31RcXomzCxrea,55+int(5*zqj2ltB4agIQVifTWcxX7nC/eB76azgblwARsQINn),'تصنيف الفيديوهات المرتبة','الفيديو رقم:-',str(zqj2ltB4agIQVifTWcxX7nC)+' / '+Qp1UTWbC8Aa3oDc)
			if KGdsq9fgW31RcXomzCxrea.iscanceled():
				KGdsq9fgW31RcXomzCxrea.close()
				return None,None
		bvfP6pcm4enTAQZEUgxoV = Oyc53409UnEIwbB['type']
		RRSaoMVs1BJdWNEpAP,SUkst0aLFhj,FghljxYu6ZiV7nCmtSUrywKDek,kxY4EfTKobmQJ8OathHI53,qsSTC3ZfW1NthKUbHQEnlpP9GY5 = Oyc53409UnEIwbB['group'],Oyc53409UnEIwbB['context'],Oyc53409UnEIwbB['title'],Oyc53409UnEIwbB['url'],Oyc53409UnEIwbB['img']
		VjUWbd6POr0eAo,me0pgIcO1rq82JTtVXiLYwlj = Oyc53409UnEIwbB['country'],Oyc53409UnEIwbB['language']
		Chzk8epJXg90ou37NjcOUDyZ4b = (RRSaoMVs1BJdWNEpAP,SUkst0aLFhj+'_TIMESHIFT',FghljxYu6ZiV7nCmtSUrywKDek,kxY4EfTKobmQJ8OathHI53,qsSTC3ZfW1NthKUbHQEnlpP9GY5)
		V2RytdCl5ekaxMXpnf0 = (RRSaoMVs1BJdWNEpAP,SUkst0aLFhj,FghljxYu6ZiV7nCmtSUrywKDek,kxY4EfTKobmQJ8OathHI53,qsSTC3ZfW1NthKUbHQEnlpP9GY5)
		ZJTA83RaMCFVK56Elkm = (VjUWbd6POr0eAo,SUkst0aLFhj,FghljxYu6ZiV7nCmtSUrywKDek,kxY4EfTKobmQJ8OathHI53,qsSTC3ZfW1NthKUbHQEnlpP9GY5)
		v4pbFPcJk2zo1 = (me0pgIcO1rq82JTtVXiLYwlj,SUkst0aLFhj,FghljxYu6ZiV7nCmtSUrywKDek,kxY4EfTKobmQJ8OathHI53,qsSTC3ZfW1NthKUbHQEnlpP9GY5)
		if 'LIVE' in bvfP6pcm4enTAQZEUgxoV:
			if 'UNKNOWN' in bvfP6pcm4enTAQZEUgxoV: IvUahiecdM8DmJZ5['LIVE_UNKNOWN_GROUPED_SORTED_'+T60FHByirslQk8f].append(V2RytdCl5ekaxMXpnf0)
			else: IvUahiecdM8DmJZ5['LIVE_GROUPED_SORTED_'+T60FHByirslQk8f].append(V2RytdCl5ekaxMXpnf0)
			if 'EPG'		in bvfP6pcm4enTAQZEUgxoV: IvUahiecdM8DmJZ5['LIVE_EPG_GROUPED_SORTED_'+T60FHByirslQk8f].append(V2RytdCl5ekaxMXpnf0)
			if 'ARCHIVED'	in bvfP6pcm4enTAQZEUgxoV: IvUahiecdM8DmJZ5['LIVE_ARCHIVED_GROUPED_SORTED_'+T60FHByirslQk8f].append(V2RytdCl5ekaxMXpnf0)
			if 'ARCHIVED'	in bvfP6pcm4enTAQZEUgxoV: IvUahiecdM8DmJZ5['LIVE_TIMESHIFT_GROUPED_SORTED_'+T60FHByirslQk8f].append(Chzk8epJXg90ou37NjcOUDyZ4b)
			IvUahiecdM8DmJZ5['LIVE_FROM_NAME_SORTED_'+T60FHByirslQk8f].append(ZJTA83RaMCFVK56Elkm)
			IvUahiecdM8DmJZ5['LIVE_FROM_GROUP_SORTED_'+T60FHByirslQk8f].append(v4pbFPcJk2zo1)
		elif 'VOD' in bvfP6pcm4enTAQZEUgxoV:
			if   'UNKNOWN'	in bvfP6pcm4enTAQZEUgxoV: IvUahiecdM8DmJZ5['VOD_UNKNOWN_GROUPED_SORTED_'+T60FHByirslQk8f].append(V2RytdCl5ekaxMXpnf0)
			elif 'MOVIES'	in bvfP6pcm4enTAQZEUgxoV: IvUahiecdM8DmJZ5['VOD_MOVIES_GROUPED_SORTED_'+T60FHByirslQk8f].append(V2RytdCl5ekaxMXpnf0)
			elif 'SERIES'	in bvfP6pcm4enTAQZEUgxoV: IvUahiecdM8DmJZ5['VOD_SERIES_GROUPED_SORTED_'+T60FHByirslQk8f].append(V2RytdCl5ekaxMXpnf0)
			IvUahiecdM8DmJZ5['VOD_FROM_NAME_SORTED_'+T60FHByirslQk8f].append(ZJTA83RaMCFVK56Elkm)
			IvUahiecdM8DmJZ5['VOD_FROM_GROUP_SORTED_'+T60FHByirslQk8f].append(v4pbFPcJk2zo1)
	return IvUahiecdM8DmJZ5,r0YlJFfeCZaokWS51
def UGqRJKkWISv3PVDjsgBz9uw4f(FghljxYu6ZiV7nCmtSUrywKDek):
	if len(FghljxYu6ZiV7nCmtSUrywKDek)<3: return FghljxYu6ZiV7nCmtSUrywKDek,FghljxYu6ZiV7nCmtSUrywKDek
	lGaZCfebRnAdBvgQ4ToJhq2I6x7,F87ZVIhcX4OJyMkLN5 = cdZKMn68Pzg4,cdZKMn68Pzg4
	s8V0d4IDnRZyXB3qOfSEkvbjph5 = FghljxYu6ZiV7nCmtSUrywKDek
	CzB8GjXODyxPHRMJhAQdUr2wq = FghljxYu6ZiV7nCmtSUrywKDek[:1]
	PPlkNc21DbXsgnu6A8 = FghljxYu6ZiV7nCmtSUrywKDek[1:]
	if   CzB8GjXODyxPHRMJhAQdUr2wq=='(': F87ZVIhcX4OJyMkLN5 = ')'
	elif CzB8GjXODyxPHRMJhAQdUr2wq=='[': F87ZVIhcX4OJyMkLN5 = ']'
	elif CzB8GjXODyxPHRMJhAQdUr2wq=='<': F87ZVIhcX4OJyMkLN5 = '>'
	elif CzB8GjXODyxPHRMJhAQdUr2wq=='|': F87ZVIhcX4OJyMkLN5 = '|'
	if F87ZVIhcX4OJyMkLN5 and (F87ZVIhcX4OJyMkLN5 in PPlkNc21DbXsgnu6A8):
		sCLpx2rb49YyGhN35eVF,LHkdz7VDJo80GFtBhqyc9wv = PPlkNc21DbXsgnu6A8.split(F87ZVIhcX4OJyMkLN5,1)
		lGaZCfebRnAdBvgQ4ToJhq2I6x7 = sCLpx2rb49YyGhN35eVF
		s8V0d4IDnRZyXB3qOfSEkvbjph5 = CzB8GjXODyxPHRMJhAQdUr2wq+sCLpx2rb49YyGhN35eVF+F87ZVIhcX4OJyMkLN5+VBpIH2QSmvDGlA6TO3e+LHkdz7VDJo80GFtBhqyc9wv
	elif FghljxYu6ZiV7nCmtSUrywKDek.count('|')>=2:
		sCLpx2rb49YyGhN35eVF,LHkdz7VDJo80GFtBhqyc9wv = FghljxYu6ZiV7nCmtSUrywKDek.split('|',1)
		lGaZCfebRnAdBvgQ4ToJhq2I6x7 = sCLpx2rb49YyGhN35eVF
		s8V0d4IDnRZyXB3qOfSEkvbjph5 = sCLpx2rb49YyGhN35eVF+' |'+LHkdz7VDJo80GFtBhqyc9wv
	else:
		F87ZVIhcX4OJyMkLN5 = ffUFBJQ57j2XgoGeOLn9uwpC.findall('^\w{2}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',FghljxYu6ZiV7nCmtSUrywKDek,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if not F87ZVIhcX4OJyMkLN5: F87ZVIhcX4OJyMkLN5 = ffUFBJQ57j2XgoGeOLn9uwpC.findall('^\w{3}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',FghljxYu6ZiV7nCmtSUrywKDek,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if not F87ZVIhcX4OJyMkLN5: F87ZVIhcX4OJyMkLN5 = ffUFBJQ57j2XgoGeOLn9uwpC.findall('^\w{4}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',FghljxYu6ZiV7nCmtSUrywKDek,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if F87ZVIhcX4OJyMkLN5:
			sCLpx2rb49YyGhN35eVF,LHkdz7VDJo80GFtBhqyc9wv = FghljxYu6ZiV7nCmtSUrywKDek.split(F87ZVIhcX4OJyMkLN5[0],1)
			lGaZCfebRnAdBvgQ4ToJhq2I6x7 = sCLpx2rb49YyGhN35eVF
			s8V0d4IDnRZyXB3qOfSEkvbjph5 = sCLpx2rb49YyGhN35eVF+VBpIH2QSmvDGlA6TO3e+F87ZVIhcX4OJyMkLN5[0]+VBpIH2QSmvDGlA6TO3e+LHkdz7VDJo80GFtBhqyc9wv
	s8V0d4IDnRZyXB3qOfSEkvbjph5 = s8V0d4IDnRZyXB3qOfSEkvbjph5.replace(U4ImogGksPlcBVfAb,VBpIH2QSmvDGlA6TO3e).replace(wr0HaqRdJ2D9LT7nSO1KMe38ly,VBpIH2QSmvDGlA6TO3e)
	lGaZCfebRnAdBvgQ4ToJhq2I6x7 = lGaZCfebRnAdBvgQ4ToJhq2I6x7.replace(wr0HaqRdJ2D9LT7nSO1KMe38ly,VBpIH2QSmvDGlA6TO3e)
	if not lGaZCfebRnAdBvgQ4ToJhq2I6x7: lGaZCfebRnAdBvgQ4ToJhq2I6x7 = '!!__UNKNOWN__!!'
	lGaZCfebRnAdBvgQ4ToJhq2I6x7 = lGaZCfebRnAdBvgQ4ToJhq2I6x7.strip(VBpIH2QSmvDGlA6TO3e)
	s8V0d4IDnRZyXB3qOfSEkvbjph5 = s8V0d4IDnRZyXB3qOfSEkvbjph5.strip(VBpIH2QSmvDGlA6TO3e)
	return lGaZCfebRnAdBvgQ4ToJhq2I6x7,s8V0d4IDnRZyXB3qOfSEkvbjph5
def lr845giTQzJ01vqZP(Vea0sXycdJ8LFSMzhB5Zt73u2rD):
	pj3iPglDkueR29AH6U = {}
	J8wUvxLd7kNoGf4pY1XCn = Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.getSetting('av.m3u.useragent_'+Vea0sXycdJ8LFSMzhB5Zt73u2rD)
	if J8wUvxLd7kNoGf4pY1XCn: pj3iPglDkueR29AH6U['User-Agent'] = J8wUvxLd7kNoGf4pY1XCn
	ITXKP0wLvFMQ9Niq6ctH8 = Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.getSetting('av.m3u.referer_'+Vea0sXycdJ8LFSMzhB5Zt73u2rD)
	if ITXKP0wLvFMQ9Niq6ctH8: pj3iPglDkueR29AH6U['Referer'] = ITXKP0wLvFMQ9Niq6ctH8
	return pj3iPglDkueR29AH6U
def VEFIiuClxN6GjWzmpUsbTr4ekt(Vea0sXycdJ8LFSMzhB5Zt73u2rD,T60FHByirslQk8f):
	global KGdsq9fgW31RcXomzCxrea,IvUahiecdM8DmJZ5,ssnMlW9pZ2,bJj3qg4XCfGd0,HPJoQA6URLk18nhXva7cbVDKMO,cY1DzUC9nxHgQM4BjIts,bsXtEzrKQ1f,BrCgRhzJ2KXakVq608w9,AXLJu7i8khn951BsFOyZNIEWT2R
	AZnTKcDC0twiN2l6Fzxr3f = Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.getSetting('av.m3u.url_'+Vea0sXycdJ8LFSMzhB5Zt73u2rD+'_'+T60FHByirslQk8f)
	J8wUvxLd7kNoGf4pY1XCn = Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.getSetting('av.m3u.useragent_'+Vea0sXycdJ8LFSMzhB5Zt73u2rD)
	pj3iPglDkueR29AH6U = {'User-Agent':J8wUvxLd7kNoGf4pY1XCn}
	A2vi5PFs9t7OU = Y75iNHQZIJbhG6.replace('___','_'+Vea0sXycdJ8LFSMzhB5Zt73u2rD+'_'+T60FHByirslQk8f)
	if 1:
		RepGgckNqE,XOSVmnLg957jiID0Q1RPlvpbkw,beE5JlkVDgdzro4y = True,cdZKMn68Pzg4,cdZKMn68Pzg4
		if not RepGgckNqE:
			NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,'فشل بسحب ملفات ـM3U . أحتمال رابط ـM3U غير صحيح أو قديم أو لا يعمل .. علما أن هذه الخدمة تحتاج اشتراك مدفوع وصحيح ويجب أن تضيف رابط الاشتراك بنفسك للبرنامج باستخدام قائمة ـM3U الموجودة بهذا البرنامج')
			if not AZnTKcDC0twiN2l6Fzxr3f: SsziMZd5UbeL2NRxVpwjO(E7lrS9VXJF58d2NUAfkvxwjmHM,xxd7Xp5lvem(UkXlAzsMcamKJrEIgnxi6bWh)+'   No M3U URL found to download M3U files')
			else: SsziMZd5UbeL2NRxVpwjO(E7lrS9VXJF58d2NUAfkvxwjmHM,xxd7Xp5lvem(LMihk2Vzl4DesIQ65TGmvxqcKdHp)+'   Failed to download M3U files')
			return
		bmCIrFtRfk = ImLjWxYH1p3rRF2VhCOvz8(AZnTKcDC0twiN2l6Fzxr3f,pj3iPglDkueR29AH6U,True)
		if not bmCIrFtRfk: return
		open(A2vi5PFs9t7OU,'wb').write(bmCIrFtRfk)
	else: bmCIrFtRfk = open(A2vi5PFs9t7OU,'rb').read()
	if W5domCu6XrQUFkiPpa3bNLtHglG and bmCIrFtRfk: bmCIrFtRfk = bmCIrFtRfk.decode(vczMIlkCAh2u10B3)
	KGdsq9fgW31RcXomzCxrea = g6UkpOE3s5XLiFH()
	KGdsq9fgW31RcXomzCxrea.create('جلب ملفات M3U جديدة',cdZKMn68Pzg4)
	x3G0I9vUCjg(KGdsq9fgW31RcXomzCxrea,15,'تنظيف الملف الرئيسي',cdZKMn68Pzg4)
	bmCIrFtRfk = bmCIrFtRfk.replace('"tvg-','" tvg-')
	bmCIrFtRfk = bmCIrFtRfk.replace('َ',cdZKMn68Pzg4).replace('ً',cdZKMn68Pzg4).replace('ُ',cdZKMn68Pzg4).replace('ٌ',cdZKMn68Pzg4)
	bmCIrFtRfk = bmCIrFtRfk.replace('ّ',cdZKMn68Pzg4).replace('ِ',cdZKMn68Pzg4).replace('ٍ',cdZKMn68Pzg4).replace('ْ',cdZKMn68Pzg4)
	bmCIrFtRfk = bmCIrFtRfk.replace('group-title=','group=').replace('tvg-',cdZKMn68Pzg4)
	ZpPvIGFq91fzMk64Q7OyNdD5wbL,DVEcs2ShJgRT = [],[]
	bmCIrFtRfk = bmCIrFtRfk.replace(CPjOZMmw8sfGg2B9LthIdXa1iKQUF,ssELJkeScrtni2)
	oPs342UIN6ieO9BVJWZpfXE = ffUFBJQ57j2XgoGeOLn9uwpC.findall('NF:(.+?)'+'#'+'EXTI',bmCIrFtRfk+'\n+'+'#'+'EXTINF:',ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if not oPs342UIN6ieO9BVJWZpfXE:
		SsziMZd5UbeL2NRxVpwjO(E7lrS9VXJF58d2NUAfkvxwjmHM,xxd7Xp5lvem(LMihk2Vzl4DesIQ65TGmvxqcKdHp)+'   Folder:'+Vea0sXycdJ8LFSMzhB5Zt73u2rD+'  Sequence:'+T60FHByirslQk8f+'   No video links found in M3U file')
		NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,'رابط ـM3U الذي أنت أضفته لا توجد فيه فيديوهات .. احتمال رابط ـM3U غير صحيح'+ssELJkeScrtni2+bxf7gZvNK29cEoiAIJlMq0dP+'مجلد رقم '+Vea0sXycdJ8LFSMzhB5Zt73u2rD+'      رابط رقم '+T60FHByirslQk8f+kH8E2zqNyims6KJfI)
		KGdsq9fgW31RcXomzCxrea.close()
		return
	OJMBZjGwdq = []
	for uvjQ0YydJMPkbGeg8I3FUslAW in oPs342UIN6ieO9BVJWZpfXE:
		HW9VuF5JZAI1zYSrc = uvjQ0YydJMPkbGeg8I3FUslAW.lower()
		if 'adult' in HW9VuF5JZAI1zYSrc: continue
		if 'xxx' in HW9VuF5JZAI1zYSrc: continue
		OJMBZjGwdq.append(uvjQ0YydJMPkbGeg8I3FUslAW)
	oPs342UIN6ieO9BVJWZpfXE = OJMBZjGwdq
	del OJMBZjGwdq
	if 'iptv-org' in AZnTKcDC0twiN2l6Fzxr3f:
		OJMBZjGwdq,y5FswDzoEC1mqr3dxafcb2gpjvOuk = [],[]
		for uvjQ0YydJMPkbGeg8I3FUslAW in oPs342UIN6ieO9BVJWZpfXE:
			cY1DzUC9nxHgQM4BjIts = ffUFBJQ57j2XgoGeOLn9uwpC.findall('group="(.*?)"',uvjQ0YydJMPkbGeg8I3FUslAW,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			if cY1DzUC9nxHgQM4BjIts:
				cY1DzUC9nxHgQM4BjIts = cY1DzUC9nxHgQM4BjIts[0]
				XrHLAPxJqmckTSU = cY1DzUC9nxHgQM4BjIts.split(';')
				if 'region' in AZnTKcDC0twiN2l6Fzxr3f: PPrQsHGAMxlBeTKRvpnEgyJ8WFa0N = '1_'
				elif 'category' in AZnTKcDC0twiN2l6Fzxr3f: PPrQsHGAMxlBeTKRvpnEgyJ8WFa0N = '2_'
				elif 'language' in AZnTKcDC0twiN2l6Fzxr3f: PPrQsHGAMxlBeTKRvpnEgyJ8WFa0N = '3_'
				elif 'country' in AZnTKcDC0twiN2l6Fzxr3f: PPrQsHGAMxlBeTKRvpnEgyJ8WFa0N = '4_'
				else: PPrQsHGAMxlBeTKRvpnEgyJ8WFa0N = '5_'
				GnjJc1hqYyozRL05Iiwukb74gA6 = uvjQ0YydJMPkbGeg8I3FUslAW.replace('group="'+cY1DzUC9nxHgQM4BjIts+'"','group="'+PPrQsHGAMxlBeTKRvpnEgyJ8WFa0N+'~'+Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI+'"')
				OJMBZjGwdq.append(GnjJc1hqYyozRL05Iiwukb74gA6)
				for RRSaoMVs1BJdWNEpAP in XrHLAPxJqmckTSU:
					GnjJc1hqYyozRL05Iiwukb74gA6 = uvjQ0YydJMPkbGeg8I3FUslAW.replace('group="'+cY1DzUC9nxHgQM4BjIts+'"','group="'+PPrQsHGAMxlBeTKRvpnEgyJ8WFa0N+RRSaoMVs1BJdWNEpAP+'"')
					OJMBZjGwdq.append(GnjJc1hqYyozRL05Iiwukb74gA6)
			else: OJMBZjGwdq.append(uvjQ0YydJMPkbGeg8I3FUslAW)
		oPs342UIN6ieO9BVJWZpfXE = OJMBZjGwdq
		del OJMBZjGwdq,y5FswDzoEC1mqr3dxafcb2gpjvOuk
	dIZNi2xEHT69Y8czWv = 1024*1024
	jj4paidWFcfM9oO12eEVC6 = 1+len(bmCIrFtRfk)//dIZNi2xEHT69Y8czWv//10
	del bmCIrFtRfk
	M6cnTwgRzuH = len(oPs342UIN6ieO9BVJWZpfXE)
	y5FswDzoEC1mqr3dxafcb2gpjvOuk = WjO0oaTH4cZg8BDuJkMymizfS(oPs342UIN6ieO9BVJWZpfXE,jj4paidWFcfM9oO12eEVC6)
	del oPs342UIN6ieO9BVJWZpfXE
	for ZoQJArX6xtaIG0MfLnvqEmD in range(jj4paidWFcfM9oO12eEVC6):
		x3G0I9vUCjg(KGdsq9fgW31RcXomzCxrea,35+int(5*ZoQJArX6xtaIG0MfLnvqEmD/jj4paidWFcfM9oO12eEVC6),'تقطيع الملف الرئيسي','الجزء رقم:-',str(ZoQJArX6xtaIG0MfLnvqEmD+1)+' / '+str(jj4paidWFcfM9oO12eEVC6))
		if KGdsq9fgW31RcXomzCxrea.iscanceled():
			KGdsq9fgW31RcXomzCxrea.close()
			return
		qPlfgxceavQ = str(y5FswDzoEC1mqr3dxafcb2gpjvOuk[ZoQJArX6xtaIG0MfLnvqEmD])
		if W5domCu6XrQUFkiPpa3bNLtHglG: qPlfgxceavQ = qPlfgxceavQ.encode(vczMIlkCAh2u10B3)
		open(A2vi5PFs9t7OU+'.00'+str(ZoQJArX6xtaIG0MfLnvqEmD),'wb').write(qPlfgxceavQ)
	del y5FswDzoEC1mqr3dxafcb2gpjvOuk,qPlfgxceavQ
	V5K6oJqfgs09vtdiO8,zQrTywG64KYZIn2jXa,zqj2ltB4agIQVifTWcxX7nC = [],[],0
	for ZoQJArX6xtaIG0MfLnvqEmD in range(jj4paidWFcfM9oO12eEVC6):
		if KGdsq9fgW31RcXomzCxrea.iscanceled():
			KGdsq9fgW31RcXomzCxrea.close()
			return
		qPlfgxceavQ = open(A2vi5PFs9t7OU+'.00'+str(ZoQJArX6xtaIG0MfLnvqEmD),'rb').read()
		bD7kJZhMCdaqF68P45KlNIgO1.sleep(1)
		try: YRESXadfbIy3khwqmL8WC.remove(A2vi5PFs9t7OU+'.00'+str(ZoQJArX6xtaIG0MfLnvqEmD))
		except: pass
		if W5domCu6XrQUFkiPpa3bNLtHglG: qPlfgxceavQ = qPlfgxceavQ.decode(vczMIlkCAh2u10B3)
		zPnvoYJyLrUQu0HCmk1w7OsSFl = lMeKd3hC6cmS('list',qPlfgxceavQ)
		del qPlfgxceavQ
		a2a0mpV49WBD5sIFYzU,zqj2ltB4agIQVifTWcxX7nC,r0YlJFfeCZaokWS51 = KJEI4tXxRaAzPWojcQuLB9k(zPnvoYJyLrUQu0HCmk1w7OsSFl,DVEcs2ShJgRT,ZpPvIGFq91fzMk64Q7OyNdD5wbL,KGdsq9fgW31RcXomzCxrea,M6cnTwgRzuH,zqj2ltB4agIQVifTWcxX7nC,AZnTKcDC0twiN2l6Fzxr3f)
		if KGdsq9fgW31RcXomzCxrea.iscanceled():
			KGdsq9fgW31RcXomzCxrea.close()
			return
		if not a2a0mpV49WBD5sIFYzU:
			KGdsq9fgW31RcXomzCxrea.close()
			return
		zQrTywG64KYZIn2jXa += a2a0mpV49WBD5sIFYzU
		V5K6oJqfgs09vtdiO8 += r0YlJFfeCZaokWS51
	del zPnvoYJyLrUQu0HCmk1w7OsSFl,a2a0mpV49WBD5sIFYzU
	IvUahiecdM8DmJZ5,r0YlJFfeCZaokWS51 = XBpQbhTqNvYK0Usjn(zQrTywG64KYZIn2jXa,KGdsq9fgW31RcXomzCxrea,T60FHByirslQk8f)
	if KGdsq9fgW31RcXomzCxrea.iscanceled():
		KGdsq9fgW31RcXomzCxrea.close()
		return
	V5K6oJqfgs09vtdiO8 += r0YlJFfeCZaokWS51
	del zQrTywG64KYZIn2jXa,r0YlJFfeCZaokWS51
	bJj3qg4XCfGd0,HPJoQA6URLk18nhXva7cbVDKMO,cY1DzUC9nxHgQM4BjIts,bsXtEzrKQ1f,BrCgRhzJ2KXakVq608w9 = {},{},{},0,0
	wLOjSMzVeZ8I0C3stWakYTUyc7 = list(IvUahiecdM8DmJZ5.keys())
	AXLJu7i8khn951BsFOyZNIEWT2R = len(wLOjSMzVeZ8I0C3stWakYTUyc7)*3
	if 1:
		R9IcLVCtrSOD = {}
		for MBHEOqmtX3SPb2whAFr6ul in wLOjSMzVeZ8I0C3stWakYTUyc7:
			R9IcLVCtrSOD[MBHEOqmtX3SPb2whAFr6ul] = qMrpRl8enOuvS6hV2XcZgT(daemon=IZQbmFzLHDtXfc,target=MrDlUQdItzgcnE0pZY82,args=(MBHEOqmtX3SPb2whAFr6ul,))
			R9IcLVCtrSOD[MBHEOqmtX3SPb2whAFr6ul].start()
		for MBHEOqmtX3SPb2whAFr6ul in wLOjSMzVeZ8I0C3stWakYTUyc7:
			R9IcLVCtrSOD[MBHEOqmtX3SPb2whAFr6ul].join()
		if KGdsq9fgW31RcXomzCxrea.iscanceled():
			KGdsq9fgW31RcXomzCxrea.close()
			return
	else:
		for MBHEOqmtX3SPb2whAFr6ul in wLOjSMzVeZ8I0C3stWakYTUyc7:
			MrDlUQdItzgcnE0pZY82(MBHEOqmtX3SPb2whAFr6ul)
			if KGdsq9fgW31RcXomzCxrea.iscanceled():
				KGdsq9fgW31RcXomzCxrea.close()
				return
	tdZKPlwh9JuEs1V7SXbRF(Vea0sXycdJ8LFSMzhB5Zt73u2rD,T60FHByirslQk8f,False)
	wLOjSMzVeZ8I0C3stWakYTUyc7 = list(bJj3qg4XCfGd0.keys())
	ssnMlW9pZ2 = 0
	if 1:
		R9IcLVCtrSOD = {}
		for MBHEOqmtX3SPb2whAFr6ul in wLOjSMzVeZ8I0C3stWakYTUyc7:
			R9IcLVCtrSOD[MBHEOqmtX3SPb2whAFr6ul] = qMrpRl8enOuvS6hV2XcZgT(daemon=IZQbmFzLHDtXfc,target=oSpCPgODjwKRkyTtx,args=(Vea0sXycdJ8LFSMzhB5Zt73u2rD,MBHEOqmtX3SPb2whAFr6ul))
			R9IcLVCtrSOD[MBHEOqmtX3SPb2whAFr6ul].start()
		for MBHEOqmtX3SPb2whAFr6ul in wLOjSMzVeZ8I0C3stWakYTUyc7:
			R9IcLVCtrSOD[MBHEOqmtX3SPb2whAFr6ul].join()
		if KGdsq9fgW31RcXomzCxrea.iscanceled():
			KGdsq9fgW31RcXomzCxrea.close()
			return
	else:
		for MBHEOqmtX3SPb2whAFr6ul in wLOjSMzVeZ8I0C3stWakYTUyc7:
			oSpCPgODjwKRkyTtx(Vea0sXycdJ8LFSMzhB5Zt73u2rD,MBHEOqmtX3SPb2whAFr6ul)
			if KGdsq9fgW31RcXomzCxrea.iscanceled():
				KGdsq9fgW31RcXomzCxrea.close()
				return
	ZoQJArX6xtaIG0MfLnvqEmD = 0
	fMG40az7RTuNHc6tJji5 = len(V5K6oJqfgs09vtdiO8)
	RTr92nPJkjuBoDMbELV8Oa = wwATViQ0xDaoNMEK4v3PIeC8UzZ5(Vea0sXycdJ8LFSMzhB5Zt73u2rD,'IGNORED')
	for c0nXbOZWKUj7h1fR5rT in V5K6oJqfgs09vtdiO8:
		if ZoQJArX6xtaIG0MfLnvqEmD%27==0:
			x3G0I9vUCjg(KGdsq9fgW31RcXomzCxrea,95+int(5*ZoQJArX6xtaIG0MfLnvqEmD//fMG40az7RTuNHc6tJji5),'تخزين المهملة','الفيديو رقم:-',str(ZoQJArX6xtaIG0MfLnvqEmD)+' / '+str(fMG40az7RTuNHc6tJji5))
			if KGdsq9fgW31RcXomzCxrea.iscanceled():
				KGdsq9fgW31RcXomzCxrea.close()
				return
		uAkLQ7gEZaIBv6Fyn(RTr92nPJkjuBoDMbELV8Oa,'IGNORED_'+T60FHByirslQk8f,str(c0nXbOZWKUj7h1fR5rT),cdZKMn68Pzg4,jCmv4M3HNPdyaLS)
		ZoQJArX6xtaIG0MfLnvqEmD += 1
	uAkLQ7gEZaIBv6Fyn(RTr92nPJkjuBoDMbELV8Oa,'IGNORED_'+T60FHByirslQk8f,'__COUNT__',str(fMG40az7RTuNHc6tJji5),jCmv4M3HNPdyaLS)
	KGdsq9fgW31RcXomzCxrea.close()
	bD7kJZhMCdaqF68P45KlNIgO1.sleep(1)
	SYaTv4t7q0cy96(Vea0sXycdJ8LFSMzhB5Zt73u2rD)
	return
def MrDlUQdItzgcnE0pZY82(MBHEOqmtX3SPb2whAFr6ul):
	global KGdsq9fgW31RcXomzCxrea,IvUahiecdM8DmJZ5,ssnMlW9pZ2,bJj3qg4XCfGd0,HPJoQA6URLk18nhXva7cbVDKMO,cY1DzUC9nxHgQM4BjIts,bsXtEzrKQ1f,BrCgRhzJ2KXakVq608w9,AXLJu7i8khn951BsFOyZNIEWT2R
	bJj3qg4XCfGd0[MBHEOqmtX3SPb2whAFr6ul] = {}
	IxVL4f8sCoMUnG,oMR23rWOz6ClIkKyZGnTcX1ge = {},[]
	vsGQhBFW3Y5NdT6Se = len(IvUahiecdM8DmJZ5[MBHEOqmtX3SPb2whAFr6ul])
	bJj3qg4XCfGd0[MBHEOqmtX3SPb2whAFr6ul]['__COUNT__'] = vsGQhBFW3Y5NdT6Se
	if vsGQhBFW3Y5NdT6Se>0:
		GGhBXJAnQ6vPY7L,HGau6FAynjiwM,EOjM5gWYtZSlnuaeRs3hBDv6,egc2LvFlYh8UMV3,EaP3xnWRG6ivq87zkp1oBwTIVLXY = zip(*IvUahiecdM8DmJZ5[MBHEOqmtX3SPb2whAFr6ul])
		del HGau6FAynjiwM,EOjM5gWYtZSlnuaeRs3hBDv6,egc2LvFlYh8UMV3
		XrHLAPxJqmckTSU = list(set(GGhBXJAnQ6vPY7L))
		for RRSaoMVs1BJdWNEpAP in XrHLAPxJqmckTSU:
			IxVL4f8sCoMUnG[RRSaoMVs1BJdWNEpAP] = cdZKMn68Pzg4
			bJj3qg4XCfGd0[MBHEOqmtX3SPb2whAFr6ul][RRSaoMVs1BJdWNEpAP] = []
		x3G0I9vUCjg(KGdsq9fgW31RcXomzCxrea,60+int(15*BrCgRhzJ2KXakVq608w9//AXLJu7i8khn951BsFOyZNIEWT2R),'تصنيع القوائم','الجزء رقم:-',str(BrCgRhzJ2KXakVq608w9)+' / '+str(AXLJu7i8khn951BsFOyZNIEWT2R))
		if KGdsq9fgW31RcXomzCxrea.iscanceled(): return
		BrCgRhzJ2KXakVq608w9 += 1
		Lz5ovMJKWgQBs4nTExqtGDjAIY = len(XrHLAPxJqmckTSU)
		del XrHLAPxJqmckTSU
		oMR23rWOz6ClIkKyZGnTcX1ge = list(set(zip(GGhBXJAnQ6vPY7L,EaP3xnWRG6ivq87zkp1oBwTIVLXY)))
		del GGhBXJAnQ6vPY7L,EaP3xnWRG6ivq87zkp1oBwTIVLXY
		for RRSaoMVs1BJdWNEpAP,cxokMEeWJnSdZGt53qYhI in oMR23rWOz6ClIkKyZGnTcX1ge:
			if not IxVL4f8sCoMUnG[RRSaoMVs1BJdWNEpAP] and cxokMEeWJnSdZGt53qYhI: IxVL4f8sCoMUnG[RRSaoMVs1BJdWNEpAP] = cxokMEeWJnSdZGt53qYhI
		x3G0I9vUCjg(KGdsq9fgW31RcXomzCxrea,60+int(15*BrCgRhzJ2KXakVq608w9//AXLJu7i8khn951BsFOyZNIEWT2R),'تصنيع القوائم','الجزء رقم:-',str(BrCgRhzJ2KXakVq608w9)+' / '+str(AXLJu7i8khn951BsFOyZNIEWT2R))
		if KGdsq9fgW31RcXomzCxrea.iscanceled(): return
		BrCgRhzJ2KXakVq608w9 += 1
		HruweSoBRk47LFC0ZINi9YqPU6a = list(IxVL4f8sCoMUnG.keys())
		WWaDiPEM1GbHVOwhfqC = list(IxVL4f8sCoMUnG.values())
		del IxVL4f8sCoMUnG
		oMR23rWOz6ClIkKyZGnTcX1ge = list(zip(HruweSoBRk47LFC0ZINi9YqPU6a,WWaDiPEM1GbHVOwhfqC))
		del HruweSoBRk47LFC0ZINi9YqPU6a,WWaDiPEM1GbHVOwhfqC
		oMR23rWOz6ClIkKyZGnTcX1ge = sorted(oMR23rWOz6ClIkKyZGnTcX1ge)
	else: BrCgRhzJ2KXakVq608w9 += 2
	bJj3qg4XCfGd0[MBHEOqmtX3SPb2whAFr6ul]['__GROUPS__'] = oMR23rWOz6ClIkKyZGnTcX1ge
	del oMR23rWOz6ClIkKyZGnTcX1ge
	for RRSaoMVs1BJdWNEpAP,SUkst0aLFhj,FghljxYu6ZiV7nCmtSUrywKDek,kxY4EfTKobmQJ8OathHI53,qsSTC3ZfW1NthKUbHQEnlpP9GY5 in IvUahiecdM8DmJZ5[MBHEOqmtX3SPb2whAFr6ul]:
		bJj3qg4XCfGd0[MBHEOqmtX3SPb2whAFr6ul][RRSaoMVs1BJdWNEpAP].append((SUkst0aLFhj,FghljxYu6ZiV7nCmtSUrywKDek,kxY4EfTKobmQJ8OathHI53,qsSTC3ZfW1NthKUbHQEnlpP9GY5))
	x3G0I9vUCjg(KGdsq9fgW31RcXomzCxrea,60+int(15*BrCgRhzJ2KXakVq608w9//AXLJu7i8khn951BsFOyZNIEWT2R),'تصنيع القوائم','الجزء رقم:-',str(BrCgRhzJ2KXakVq608w9)+' / '+str(AXLJu7i8khn951BsFOyZNIEWT2R))
	if KGdsq9fgW31RcXomzCxrea.iscanceled(): return
	BrCgRhzJ2KXakVq608w9 += 1
	del IvUahiecdM8DmJZ5[MBHEOqmtX3SPb2whAFr6ul]
	cY1DzUC9nxHgQM4BjIts[MBHEOqmtX3SPb2whAFr6ul] = list(bJj3qg4XCfGd0[MBHEOqmtX3SPb2whAFr6ul].keys())
	HPJoQA6URLk18nhXva7cbVDKMO[MBHEOqmtX3SPb2whAFr6ul] = len(cY1DzUC9nxHgQM4BjIts[MBHEOqmtX3SPb2whAFr6ul])
	bsXtEzrKQ1f += HPJoQA6URLk18nhXva7cbVDKMO[MBHEOqmtX3SPb2whAFr6ul]
	return
def oSpCPgODjwKRkyTtx(Vea0sXycdJ8LFSMzhB5Zt73u2rD,MBHEOqmtX3SPb2whAFr6ul):
	global KGdsq9fgW31RcXomzCxrea,IvUahiecdM8DmJZ5,ssnMlW9pZ2,bJj3qg4XCfGd0,HPJoQA6URLk18nhXva7cbVDKMO,cY1DzUC9nxHgQM4BjIts,bsXtEzrKQ1f,BrCgRhzJ2KXakVq608w9,AXLJu7i8khn951BsFOyZNIEWT2R
	RTr92nPJkjuBoDMbELV8Oa = wwATViQ0xDaoNMEK4v3PIeC8UzZ5(Vea0sXycdJ8LFSMzhB5Zt73u2rD,MBHEOqmtX3SPb2whAFr6ul)
	for zqj2ltB4agIQVifTWcxX7nC in range(1+HPJoQA6URLk18nhXva7cbVDKMO[MBHEOqmtX3SPb2whAFr6ul]//273):
		Q50egF8EqH7mbYWaPpuhJrwcM = []
		rVJj3DRWkaAfqzw5od = cY1DzUC9nxHgQM4BjIts[MBHEOqmtX3SPb2whAFr6ul][0:273]
		for RRSaoMVs1BJdWNEpAP in rVJj3DRWkaAfqzw5od:
			Q50egF8EqH7mbYWaPpuhJrwcM.append(bJj3qg4XCfGd0[MBHEOqmtX3SPb2whAFr6ul][RRSaoMVs1BJdWNEpAP])
		uAkLQ7gEZaIBv6Fyn(RTr92nPJkjuBoDMbELV8Oa,MBHEOqmtX3SPb2whAFr6ul,rVJj3DRWkaAfqzw5od,Q50egF8EqH7mbYWaPpuhJrwcM,jCmv4M3HNPdyaLS,True)
		ssnMlW9pZ2 += len(rVJj3DRWkaAfqzw5od)
		x3G0I9vUCjg(KGdsq9fgW31RcXomzCxrea,75+int(20*ssnMlW9pZ2//bsXtEzrKQ1f),'تخزين القوائم','القائمة رقم:-',str(ssnMlW9pZ2)+' / '+str(bsXtEzrKQ1f))
		if KGdsq9fgW31RcXomzCxrea.iscanceled(): return
		del cY1DzUC9nxHgQM4BjIts[MBHEOqmtX3SPb2whAFr6ul][0:273]
	del bJj3qg4XCfGd0[MBHEOqmtX3SPb2whAFr6ul],cY1DzUC9nxHgQM4BjIts[MBHEOqmtX3SPb2whAFr6ul],HPJoQA6URLk18nhXva7cbVDKMO[MBHEOqmtX3SPb2whAFr6ul]
	return
def U2i5lhIGe8EmckoLY(Vea0sXycdJ8LFSMzhB5Zt73u2rD,T60FHByirslQk8f,bUHVjvzwnyi=True):
	BwSH9qje6tpNEMJyWCz87T = 'عدد فيديوهات جميع الروابط'
	U0HdARtn2fcGJjv7aMKg9epBDTlos = wwATViQ0xDaoNMEK4v3PIeC8UzZ5(Vea0sXycdJ8LFSMzhB5Zt73u2rD,'LIVE_ORIGINAL_GROUPED')
	dRbFgAhq7GljwHfJXWuVOi2NrB = wwATViQ0xDaoNMEK4v3PIeC8UzZ5(Vea0sXycdJ8LFSMzhB5Zt73u2rD,'VOD_ORIGINAL_GROUPED')
	if T60FHByirslQk8f:
		BwSH9qje6tpNEMJyWCz87T = 'عدد فيديوهات رابط '+G9Gz76P41qQAW2viUsjEymXYOVuBSc[int(T60FHByirslQk8f)]
		T60FHByirslQk8f = '_'+T60FHByirslQk8f
	fMG40az7RTuNHc6tJji5 = sZHYrLPog4wmuW0ECdc(U0HdARtn2fcGJjv7aMKg9epBDTlos,'int','IGNORED'+T60FHByirslQk8f,'__COUNT__')
	Jqb5zogxLXOifaeTWwmNCDQ4vYBF = sZHYrLPog4wmuW0ECdc(U0HdARtn2fcGJjv7aMKg9epBDTlos,'int','LIVE_ORIGINAL_GROUPED'+T60FHByirslQk8f,'__COUNT__')
	IEaCymoO9dVGjZ7Nw = sZHYrLPog4wmuW0ECdc(dRbFgAhq7GljwHfJXWuVOi2NrB,'int','VOD_ORIGINAL_GROUPED'+T60FHByirslQk8f,'__COUNT__')
	NLoVHtl9jparnA = sZHYrLPog4wmuW0ECdc(U0HdARtn2fcGJjv7aMKg9epBDTlos,'int','LIVE_GROUPED'+T60FHByirslQk8f,'__COUNT__')
	u4fdoZwiHKyM0Qp2LCWcsgxYSFUJzV = sZHYrLPog4wmuW0ECdc(U0HdARtn2fcGJjv7aMKg9epBDTlos,'int','LIVE_UNKNOWN_GROUPED'+T60FHByirslQk8f,'__COUNT__')
	FhAwtSKg3bzpXIWGc29TqMkL = sZHYrLPog4wmuW0ECdc(U0HdARtn2fcGJjv7aMKg9epBDTlos,'int','VOD_MOVIES_GROUPED'+T60FHByirslQk8f,'__COUNT__')
	x0lFhJ5dUjvfEs = sZHYrLPog4wmuW0ECdc(dRbFgAhq7GljwHfJXWuVOi2NrB,'int','VOD_SERIES_GROUPED'+T60FHByirslQk8f,'__COUNT__')
	A7fOi1rdYbpVySNQ6HmDa5B = sZHYrLPog4wmuW0ECdc(U0HdARtn2fcGJjv7aMKg9epBDTlos,'int','VOD_UNKNOWN_GROUPED'+T60FHByirslQk8f,'__COUNT__')
	cY1DzUC9nxHgQM4BjIts = sZHYrLPog4wmuW0ECdc(dRbFgAhq7GljwHfJXWuVOi2NrB,'list','VOD_SERIES_GROUPED'+T60FHByirslQk8f,'__GROUPS__')
	jFVn1GDzgUQbvfa4JpWThBm2Si = []
	for RRSaoMVs1BJdWNEpAP,qsSTC3ZfW1NthKUbHQEnlpP9GY5 in cY1DzUC9nxHgQM4BjIts:
		M0Sn3syBLpqWzhoX9OTYal2u71xV4 = RRSaoMVs1BJdWNEpAP.split('__SERIES__')[1]
		jFVn1GDzgUQbvfa4JpWThBm2Si.append(M0Sn3syBLpqWzhoX9OTYal2u71xV4)
	qGygYXdwVzkcm9HQIF4B = len(jFVn1GDzgUQbvfa4JpWThBm2Si)
	om3XlN9aWpCnAEuYO = int(FhAwtSKg3bzpXIWGc29TqMkL)+int(x0lFhJ5dUjvfEs)+int(A7fOi1rdYbpVySNQ6HmDa5B)+int(u4fdoZwiHKyM0Qp2LCWcsgxYSFUJzV)+int(NLoVHtl9jparnA)
	RuDBlzZQK8ihkY36tf7FjGHvoAST = cdZKMn68Pzg4
	RuDBlzZQK8ihkY36tf7FjGHvoAST += 'قنوات: '+str(NLoVHtl9jparnA)
	RuDBlzZQK8ihkY36tf7FjGHvoAST += '   .   أفلام: '+str(FhAwtSKg3bzpXIWGc29TqMkL)
	RuDBlzZQK8ihkY36tf7FjGHvoAST += '\nمسلسلات: '+str(qGygYXdwVzkcm9HQIF4B)
	RuDBlzZQK8ihkY36tf7FjGHvoAST += '   .   حلقات: '+str(x0lFhJ5dUjvfEs)
	RuDBlzZQK8ihkY36tf7FjGHvoAST += '\nقنوات مجهولة: '+str(u4fdoZwiHKyM0Qp2LCWcsgxYSFUJzV)
	RuDBlzZQK8ihkY36tf7FjGHvoAST += '   .   فيدوهات مجهولة: '+str(A7fOi1rdYbpVySNQ6HmDa5B)
	RuDBlzZQK8ihkY36tf7FjGHvoAST += '\nمجموع القنوات: '+str(Jqb5zogxLXOifaeTWwmNCDQ4vYBF)
	RuDBlzZQK8ihkY36tf7FjGHvoAST += '   .   مجموع الفيديوهات: '+str(IEaCymoO9dVGjZ7Nw)
	RuDBlzZQK8ihkY36tf7FjGHvoAST += '\n\nمجموع المضافة: '+str(om3XlN9aWpCnAEuYO)
	RuDBlzZQK8ihkY36tf7FjGHvoAST += '   .   مجموع المهملة: '+str(fMG40az7RTuNHc6tJji5)
	if bUHVjvzwnyi: NiWSoAmhdkQPlTpneyVzDO8tw9aL('center',cdZKMn68Pzg4,BwSH9qje6tpNEMJyWCz87T,RuDBlzZQK8ihkY36tf7FjGHvoAST)
	I8bqu2jHQXRTf3S = RuDBlzZQK8ihkY36tf7FjGHvoAST.replace('\n\n',ssELJkeScrtni2)
	if not T60FHByirslQk8f: T60FHByirslQk8f = 'All'
	else: T60FHByirslQk8f = T60FHByirslQk8f[1]
	SsziMZd5UbeL2NRxVpwjO(F0FeocLXmbJhdBwQnS18PCHZIU,'.\tCounts of M3U videos   Folder: '+Vea0sXycdJ8LFSMzhB5Zt73u2rD+'   Sequence: '+T60FHByirslQk8f+ssELJkeScrtni2+I8bqu2jHQXRTf3S)
	return RuDBlzZQK8ihkY36tf7FjGHvoAST
def tdZKPlwh9JuEs1V7SXbRF(Vea0sXycdJ8LFSMzhB5Zt73u2rD,T60FHByirslQk8f,bUHVjvzwnyi=True):
	if bUHVjvzwnyi:
		GPQCWezyxpbjhHNXMVEaI4FR = JyLdvftP3CU('center',cdZKMn68Pzg4,cdZKMn68Pzg4,'مسح ملفات M3U','هل تريد مسح الملفات القديمة المخزنة في البرنامج ؟! \n\n علما انك تستطيع في أي وقت الدخول إلى قائمة M3U وجلب ملفات M3U جديدة')
		if GPQCWezyxpbjhHNXMVEaI4FR!=1: return
		EEQgChOkLxAr3Z0FitTWlu58jMsd = Y75iNHQZIJbhG6.replace('___','_'+Vea0sXycdJ8LFSMzhB5Zt73u2rD+'_'+T60FHByirslQk8f)
		try: YRESXadfbIy3khwqmL8WC.remove(EEQgChOkLxAr3Z0FitTWlu58jMsd)
		except: pass
	RTr92nPJkjuBoDMbELV8Oa = wwATViQ0xDaoNMEK4v3PIeC8UzZ5(Vea0sXycdJ8LFSMzhB5Zt73u2rD,cdZKMn68Pzg4)
	if T60FHByirslQk8f:
		dt4pJZBwP3yYWsSigM7CfG = []
		for II8JeSMC31rx2jF7 in zzSXPqifhs8rYnUvbMkuR26B7:
			dt4pJZBwP3yYWsSigM7CfG.append(II8JeSMC31rx2jF7+'_'+T60FHByirslQk8f)
		uVOoSHfqe4WtiF(RTr92nPJkjuBoDMbELV8Oa,'LINK_'+T60FHByirslQk8f)
	else:
		dt4pJZBwP3yYWsSigM7CfG = zzSXPqifhs8rYnUvbMkuR26B7
		uVOoSHfqe4WtiF(RTr92nPJkjuBoDMbELV8Oa,'DUMMY')
		uVOoSHfqe4WtiF(RTr92nPJkjuBoDMbELV8Oa,'GROUPS')
		uVOoSHfqe4WtiF(RTr92nPJkjuBoDMbELV8Oa,'ITEMS')
		uVOoSHfqe4WtiF(RTr92nPJkjuBoDMbELV8Oa,'SEARCH')
	uVOoSHfqe4WtiF(TV08xYHA2ok,'SECTIONS_M3U','SECTIONS_M3U_'+Vea0sXycdJ8LFSMzhB5Zt73u2rD)
	uVOoSHfqe4WtiF(TV08xYHA2ok,'SECTIONS_M3U','SECTIONS_M3U_ALL')
	for MBHEOqmtX3SPb2whAFr6ul in dt4pJZBwP3yYWsSigM7CfG:
		uVOoSHfqe4WtiF(RTr92nPJkjuBoDMbELV8Oa,MBHEOqmtX3SPb2whAFr6ul)
	tiuZ61v2BRxSKgJWfpbL0Yq(False)
	SYaTv4t7q0cy96(Vea0sXycdJ8LFSMzhB5Zt73u2rD)
	if bUHVjvzwnyi: NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,'تم مسح جميع ملفات ـM3U')
	return
def Im36vznMobP7WCNfFY2lJZ(Vea0sXycdJ8LFSMzhB5Zt73u2rD=cdZKMn68Pzg4,bUHVjvzwnyi=True):
	if Vea0sXycdJ8LFSMzhB5Zt73u2rD:
		RTr92nPJkjuBoDMbELV8Oa = wwATViQ0xDaoNMEK4v3PIeC8UzZ5(str(Vea0sXycdJ8LFSMzhB5Zt73u2rD),'DUMMY')
		ZsOUtP3XGW0Mgexzofd9YkFb56S4rE = sZHYrLPog4wmuW0ECdc(RTr92nPJkjuBoDMbELV8Oa,'str','DUMMY','__DUMMY__')
		if ZsOUtP3XGW0Mgexzofd9YkFb56S4rE: return True
	else:
		Vea0sXycdJ8LFSMzhB5Zt73u2rD = '1'
		for ZLQ8R02Aq7U1gKE in range(1,d37Zoe1YJgWbMq+1):
			RTr92nPJkjuBoDMbELV8Oa = wwATViQ0xDaoNMEK4v3PIeC8UzZ5(str(ZLQ8R02Aq7U1gKE),'DUMMY')
			ZsOUtP3XGW0Mgexzofd9YkFb56S4rE = sZHYrLPog4wmuW0ECdc(RTr92nPJkjuBoDMbELV8Oa,'str','DUMMY','__DUMMY__')
			if ZsOUtP3XGW0Mgexzofd9YkFb56S4rE: return True
	if bUHVjvzwnyi:
		f8gnoiCKQJzsvA = 'https://iptv-org.github.io/iptv/index.category.m3u'
		c1cqNBUmuMy28V5Znjiflo4xIO = 'https://iptv-org.github.io/iptv/index.language.m3u'
		kPW8JITsnup7hjb = 'https://iptv-org.github.io/iptv/index.country.m3u'
		cSxz065bwkHY4TraIdf = f8gnoiCKQJzsvA+ssELJkeScrtni2+c1cqNBUmuMy28V5Znjiflo4xIO+ssELJkeScrtni2+kPW8JITsnup7hjb
		GPQCWezyxpbjhHNXMVEaI4FR = JyLdvftP3CU(cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,'هذه القوائم تحتاج رابط فيديوهات نوعه M3U . وهو متوفر في الإنترنت مجانا . وأيضا تبيعه الشركات المختصة . الموقع أدناه فيه روابط مجانية وهي ليست ملك المبرمج (صاحب هذا البرنامج) . ولا علاقة للمبرمج بمحتوياتها . والمبرمج لا يتحمل أي مسؤولية بسبب استخدام روابط مجانية أو غير مجانية\n'+Gzygq01Kcb9U3+'http://github.com/iptv-org/iptv'+kH8E2zqNyims6KJfI+'\nالروابط أدناه مجانية ومأخوذة من الموقع أعلاه هل تريد استخدامها\n '+Gzygq01Kcb9U3+cSxz065bwkHY4TraIdf+kH8E2zqNyims6KJfI,profile='confirm_smallfont')
		if GPQCWezyxpbjhHNXMVEaI4FR==1:
			Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.setSetting('av.m3u.url_'+str(Vea0sXycdJ8LFSMzhB5Zt73u2rD)+'_1',f8gnoiCKQJzsvA)
			Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.setSetting('av.m3u.url_'+str(Vea0sXycdJ8LFSMzhB5Zt73u2rD)+'_2',c1cqNBUmuMy28V5Znjiflo4xIO)
			Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.setSetting('av.m3u.url_'+str(Vea0sXycdJ8LFSMzhB5Zt73u2rD)+'_3',kPW8JITsnup7hjb)
			GPQCWezyxpbjhHNXMVEaI4FR = JyLdvftP3CU(cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,'للاستفادة من روابط M3U التي أنت أضفتها للبرنامج .. أنت بحاجة إلى جلب ملفات هذه الروابط الجديدة .. هل تريد الآن جلب ملفات روابط M3U التي أنت أضفتها للبرنامج ؟!')
			if GPQCWezyxpbjhHNXMVEaI4FR==1:
				exTdHtlfmX2WUQr = zzKXxsiWfIU1E3l0BumDcnYS7(Vea0sXycdJ8LFSMzhB5Zt73u2rD)
				return exTdHtlfmX2WUQr
		else:
			BwSH9qje6tpNEMJyWCz87T = 'إضافة وتغيير رابط '+G9Gz76P41qQAW2viUsjEymXYOVuBSc[1]+' (مجلد '+G9Gz76P41qQAW2viUsjEymXYOVuBSc[int(Vea0sXycdJ8LFSMzhB5Zt73u2rD)]+')'
			GPQCWezyxpbjhHNXMVEaI4FR = JyLdvftP3CU(cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,BwSH9qje6tpNEMJyWCz87T,'لإضافة رابط M3U .. أولا أفتح قائمة M3U .. ثانيا أنقر على إضافة رابط أو اشتراك M3U .. ثالثا أنقر على جلب ملفات ـM3U \n\n هل تريد إضافة أو تغيير رابط M3U الآن ؟!')
			if GPQCWezyxpbjhHNXMVEaI4FR==1: S4msZ0wigOJREj3rolfqQGch(Vea0sXycdJ8LFSMzhB5Zt73u2rD,'1')
	return False
def pi7dszu648(AGlajBRVeDYSUwd5qg,Vea0sXycdJ8LFSMzhB5Zt73u2rD=cdZKMn68Pzg4,MBHEOqmtX3SPb2whAFr6ul=cdZKMn68Pzg4,SwDfU9qkrKo6QW2y=cdZKMn68Pzg4):
	if not SwDfU9qkrKo6QW2y: SwDfU9qkrKo6QW2y = '1'
	ohGe84MLmzaQXICbNvcVUkW,X9XExg7ect62uBzjfqhPCyb18,bUHVjvzwnyi = qbIcHCMdkFKn21e(AGlajBRVeDYSUwd5qg)
	if not Im36vznMobP7WCNfFY2lJZ(Vea0sXycdJ8LFSMzhB5Zt73u2rD,bUHVjvzwnyi): return
	if not ohGe84MLmzaQXICbNvcVUkW:
		ohGe84MLmzaQXICbNvcVUkW = BzkmLuvJD9n25Pg()
		if not ohGe84MLmzaQXICbNvcVUkW: return
	QpdACXI5Da34h = [cdZKMn68Pzg4,'LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not MBHEOqmtX3SPb2whAFr6ul:
		if not bUHVjvzwnyi:
			if   '_M3U-LIVE_' in X9XExg7ect62uBzjfqhPCyb18: MBHEOqmtX3SPb2whAFr6ul = QpdACXI5Da34h[1]
			elif '_M3U-MOVIES' in X9XExg7ect62uBzjfqhPCyb18: MBHEOqmtX3SPb2whAFr6ul = QpdACXI5Da34h[2]
			elif '_M3U-SERIES' in X9XExg7ect62uBzjfqhPCyb18: MBHEOqmtX3SPb2whAFr6ul = QpdACXI5Da34h[3]
			else: MBHEOqmtX3SPb2whAFr6ul = QpdACXI5Da34h[0]
		else:
			e0emHnNKBv5 = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			tcxhXCe0Z6EaAyPu = NAfHLMC8Ip64FmT7l5oJWXaq3hK('أختر البحث المناسب', e0emHnNKBv5)
			if tcxhXCe0Z6EaAyPu==-1: return
			MBHEOqmtX3SPb2whAFr6ul = QpdACXI5Da34h[tcxhXCe0Z6EaAyPu]
	ohGe84MLmzaQXICbNvcVUkW = ohGe84MLmzaQXICbNvcVUkW+'_NODIALOGS_'
	if Vea0sXycdJ8LFSMzhB5Zt73u2rD: LMejKcGP5p9QUkrFgqWAVivnNt6yoT(ohGe84MLmzaQXICbNvcVUkW,Vea0sXycdJ8LFSMzhB5Zt73u2rD,MBHEOqmtX3SPb2whAFr6ul,SwDfU9qkrKo6QW2y)
	else:
		for Vea0sXycdJ8LFSMzhB5Zt73u2rD in range(1,d37Zoe1YJgWbMq+1):
			LMejKcGP5p9QUkrFgqWAVivnNt6yoT(ohGe84MLmzaQXICbNvcVUkW,str(Vea0sXycdJ8LFSMzhB5Zt73u2rD),MBHEOqmtX3SPb2whAFr6ul,SwDfU9qkrKo6QW2y)
		USuRxnPlV5.menuItemsLIST[:] = sorted(USuRxnPlV5.menuItemsLIST,reverse=False,key=lambda D8QslnRP0KIkdYcbviAGTSEo7U69z: D8QslnRP0KIkdYcbviAGTSEo7U69z[1].lower())
	return
def LMejKcGP5p9QUkrFgqWAVivnNt6yoT(AGlajBRVeDYSUwd5qg,Vea0sXycdJ8LFSMzhB5Zt73u2rD,MBHEOqmtX3SPb2whAFr6ul=cdZKMn68Pzg4,SwDfU9qkrKo6QW2y=cdZKMn68Pzg4):
	if not SwDfU9qkrKo6QW2y: SwDfU9qkrKo6QW2y = '1'
	ohGe84MLmzaQXICbNvcVUkW,X9XExg7ect62uBzjfqhPCyb18,bUHVjvzwnyi = qbIcHCMdkFKn21e(AGlajBRVeDYSUwd5qg)
	if not Vea0sXycdJ8LFSMzhB5Zt73u2rD: return
	if not Im36vznMobP7WCNfFY2lJZ(Vea0sXycdJ8LFSMzhB5Zt73u2rD,bUHVjvzwnyi): return
	if not ohGe84MLmzaQXICbNvcVUkW:
		ohGe84MLmzaQXICbNvcVUkW = BzkmLuvJD9n25Pg()
		if not ohGe84MLmzaQXICbNvcVUkW: return
	QpdACXI5Da34h = [cdZKMn68Pzg4,'LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not MBHEOqmtX3SPb2whAFr6ul:
		if not bUHVjvzwnyi:
			if   '_M3U-LIVE_' in X9XExg7ect62uBzjfqhPCyb18: MBHEOqmtX3SPb2whAFr6ul = QpdACXI5Da34h[1]
			elif '_M3U-MOVIES' in X9XExg7ect62uBzjfqhPCyb18: MBHEOqmtX3SPb2whAFr6ul = QpdACXI5Da34h[2]
			elif '_M3U-SERIES' in X9XExg7ect62uBzjfqhPCyb18: MBHEOqmtX3SPb2whAFr6ul = QpdACXI5Da34h[3]
			else: MBHEOqmtX3SPb2whAFr6ul = QpdACXI5Da34h[0]
		else:
			e0emHnNKBv5 = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			tcxhXCe0Z6EaAyPu = NAfHLMC8Ip64FmT7l5oJWXaq3hK('أختر البحث المناسب', e0emHnNKBv5)
			if tcxhXCe0Z6EaAyPu==-1: return
			MBHEOqmtX3SPb2whAFr6ul = QpdACXI5Da34h[tcxhXCe0Z6EaAyPu]
	EPIa0wcWlkB3YmRD7MXG1sKiuAy = ohGe84MLmzaQXICbNvcVUkW.lower()
	RTr92nPJkjuBoDMbELV8Oa = wwATViQ0xDaoNMEK4v3PIeC8UzZ5(Vea0sXycdJ8LFSMzhB5Zt73u2rD,'SEARCH')
	iiAOHkqYIRW7Bs46CEj3Layefb2hSP = sZHYrLPog4wmuW0ECdc(RTr92nPJkjuBoDMbELV8Oa,'list','SEARCH',(MBHEOqmtX3SPb2whAFr6ul,EPIa0wcWlkB3YmRD7MXG1sKiuAy))
	if not iiAOHkqYIRW7Bs46CEj3Layefb2hSP:
		cclF9OSIRgsikfwXZn,n9SfaWL451JGCHVmURhueKr8 = [],[]
		if not MBHEOqmtX3SPb2whAFr6ul: tprNzkQVObJZnoLiu = [1,2,3,4,5]
		else: tprNzkQVObJZnoLiu = [QpdACXI5Da34h.index(MBHEOqmtX3SPb2whAFr6ul)]
		for ZoQJArX6xtaIG0MfLnvqEmD in tprNzkQVObJZnoLiu:
			if ZoQJArX6xtaIG0MfLnvqEmD!=3:
				a2a0mpV49WBD5sIFYzU = sZHYrLPog4wmuW0ECdc(RTr92nPJkjuBoDMbELV8Oa,'dict',QpdACXI5Da34h[ZoQJArX6xtaIG0MfLnvqEmD])
				del a2a0mpV49WBD5sIFYzU['__COUNT__']
				del a2a0mpV49WBD5sIFYzU['__GROUPS__']
				del a2a0mpV49WBD5sIFYzU['__SEQUENCED_COLUMNS__']
				cY1DzUC9nxHgQM4BjIts = list(a2a0mpV49WBD5sIFYzU.keys())
				for RRSaoMVs1BJdWNEpAP in cY1DzUC9nxHgQM4BjIts:
					for SUkst0aLFhj,FghljxYu6ZiV7nCmtSUrywKDek,kxY4EfTKobmQJ8OathHI53,qsSTC3ZfW1NthKUbHQEnlpP9GY5 in a2a0mpV49WBD5sIFYzU[RRSaoMVs1BJdWNEpAP]:
						if EPIa0wcWlkB3YmRD7MXG1sKiuAy in FghljxYu6ZiV7nCmtSUrywKDek.lower(): n9SfaWL451JGCHVmURhueKr8.append((FghljxYu6ZiV7nCmtSUrywKDek,kxY4EfTKobmQJ8OathHI53,qsSTC3ZfW1NthKUbHQEnlpP9GY5))
					del a2a0mpV49WBD5sIFYzU[RRSaoMVs1BJdWNEpAP]
				del a2a0mpV49WBD5sIFYzU
			else: cY1DzUC9nxHgQM4BjIts = sZHYrLPog4wmuW0ECdc(RTr92nPJkjuBoDMbELV8Oa,'list',QpdACXI5Da34h[ZoQJArX6xtaIG0MfLnvqEmD],'__GROUPS__')
			for RRSaoMVs1BJdWNEpAP in cY1DzUC9nxHgQM4BjIts:
				try: RRSaoMVs1BJdWNEpAP,qsSTC3ZfW1NthKUbHQEnlpP9GY5 = RRSaoMVs1BJdWNEpAP
				except: qsSTC3ZfW1NthKUbHQEnlpP9GY5 = cdZKMn68Pzg4
				if EPIa0wcWlkB3YmRD7MXG1sKiuAy in RRSaoMVs1BJdWNEpAP.lower():
					if ZoQJArX6xtaIG0MfLnvqEmD!=3: H3rokbwzj5daEcu = RRSaoMVs1BJdWNEpAP
					else:
						hewJPMkX2xfSCAgFlo5b,fHb7iXcpWT1U2sGCJY = RRSaoMVs1BJdWNEpAP.split('__SERIES__')
						if EPIa0wcWlkB3YmRD7MXG1sKiuAy in hewJPMkX2xfSCAgFlo5b.lower(): H3rokbwzj5daEcu = hewJPMkX2xfSCAgFlo5b
						else: H3rokbwzj5daEcu = fHb7iXcpWT1U2sGCJY
					cclF9OSIRgsikfwXZn.append((RRSaoMVs1BJdWNEpAP,H3rokbwzj5daEcu,QpdACXI5Da34h[ZoQJArX6xtaIG0MfLnvqEmD],qsSTC3ZfW1NthKUbHQEnlpP9GY5))
			del cY1DzUC9nxHgQM4BjIts
		cclF9OSIRgsikfwXZn = set(cclF9OSIRgsikfwXZn)
		n9SfaWL451JGCHVmURhueKr8 = set(n9SfaWL451JGCHVmURhueKr8)
		cclF9OSIRgsikfwXZn = sorted(cclF9OSIRgsikfwXZn,reverse=False,key=lambda D8QslnRP0KIkdYcbviAGTSEo7U69z: D8QslnRP0KIkdYcbviAGTSEo7U69z[1])
		n9SfaWL451JGCHVmURhueKr8 = sorted(n9SfaWL451JGCHVmURhueKr8,reverse=False,key=lambda D8QslnRP0KIkdYcbviAGTSEo7U69z: D8QslnRP0KIkdYcbviAGTSEo7U69z[0])
		uAkLQ7gEZaIBv6Fyn(RTr92nPJkjuBoDMbELV8Oa,'SEARCH',(MBHEOqmtX3SPb2whAFr6ul,EPIa0wcWlkB3YmRD7MXG1sKiuAy),(cclF9OSIRgsikfwXZn,n9SfaWL451JGCHVmURhueKr8),jCmv4M3HNPdyaLS)
	else: cclF9OSIRgsikfwXZn,n9SfaWL451JGCHVmURhueKr8 = iiAOHkqYIRW7Bs46CEj3Layefb2hSP
	cY1DzUC9nxHgQM4BjIts = len(cclF9OSIRgsikfwXZn)
	FypbJ0WMOZI = len(n9SfaWL451JGCHVmURhueKr8)
	iQBgv5oEbM6ZFH4U8qtC = int(SwDfU9qkrKo6QW2y)
	q6ki83rAIZtL7Dh0RF = max(0,(iQBgv5oEbM6ZFH4U8qtC-1)*100)
	fNUem0ay4SPOt = max(0,iQBgv5oEbM6ZFH4U8qtC*100)
	JCzj2V0nGX6RwA4 = max(0,q6ki83rAIZtL7Dh0RF-cY1DzUC9nxHgQM4BjIts)
	AecEHsCRSomFUpwWrzM = max(0,fNUem0ay4SPOt-cY1DzUC9nxHgQM4BjIts)
	for RRSaoMVs1BJdWNEpAP,H3rokbwzj5daEcu,s8hDWSzkMKf5730dlFJjYaxprb,qsSTC3ZfW1NthKUbHQEnlpP9GY5 in cclF9OSIRgsikfwXZn[q6ki83rAIZtL7Dh0RF:fNUem0ay4SPOt]:
		zJLApFBcIhnSj('folder',XQgovGj6VkUFxH4a2+H3rokbwzj5daEcu,s8hDWSzkMKf5730dlFJjYaxprb,714,qsSTC3ZfW1NthKUbHQEnlpP9GY5,'1',RRSaoMVs1BJdWNEpAP,cdZKMn68Pzg4,{'folder':Vea0sXycdJ8LFSMzhB5Zt73u2rD})
	del cclF9OSIRgsikfwXZn
	for FghljxYu6ZiV7nCmtSUrywKDek,kxY4EfTKobmQJ8OathHI53,qsSTC3ZfW1NthKUbHQEnlpP9GY5 in n9SfaWL451JGCHVmURhueKr8[JCzj2V0nGX6RwA4:AecEHsCRSomFUpwWrzM]:
		AAeR1YfaTpksgG3Lt6UlKcZMPnV = Aty25FEGpLUbfwKT19vzVm3IsYk(kxY4EfTKobmQJ8OathHI53)
		kuMXTLrvIZGfjCDtA9YNJ5SxQK = 'live'
		if '.mkv' in AAeR1YfaTpksgG3Lt6UlKcZMPnV or 'VOD' in MBHEOqmtX3SPb2whAFr6ul: kuMXTLrvIZGfjCDtA9YNJ5SxQK = 'video'
		zJLApFBcIhnSj(kuMXTLrvIZGfjCDtA9YNJ5SxQK,XQgovGj6VkUFxH4a2+FghljxYu6ZiV7nCmtSUrywKDek,kxY4EfTKobmQJ8OathHI53,715,qsSTC3ZfW1NthKUbHQEnlpP9GY5,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,{'folder':Vea0sXycdJ8LFSMzhB5Zt73u2rD})
	del n9SfaWL451JGCHVmURhueKr8
	BsewTaqSNkcuHhtf8pZvGVD7L(Vea0sXycdJ8LFSMzhB5Zt73u2rD,SwDfU9qkrKo6QW2y,MBHEOqmtX3SPb2whAFr6ul,719,cY1DzUC9nxHgQM4BjIts+FypbJ0WMOZI,ohGe84MLmzaQXICbNvcVUkW+'_NODIALOGS_')
	return
def BsewTaqSNkcuHhtf8pZvGVD7L(Vea0sXycdJ8LFSMzhB5Zt73u2rD,SwDfU9qkrKo6QW2y,MBHEOqmtX3SPb2whAFr6ul,HHrpyfWjGC,om3XlN9aWpCnAEuYO,JAYWBoz54tGw7O):
	if not SwDfU9qkrKo6QW2y: SwDfU9qkrKo6QW2y = '1'
	if SwDfU9qkrKo6QW2y!='1': zJLApFBcIhnSj('folder',XQgovGj6VkUFxH4a2+'صفحة '+str(1),MBHEOqmtX3SPb2whAFr6ul,HHrpyfWjGC,cdZKMn68Pzg4,str(1),JAYWBoz54tGw7O,cdZKMn68Pzg4,{'folder':Vea0sXycdJ8LFSMzhB5Zt73u2rD})
	if not om3XlN9aWpCnAEuYO: om3XlN9aWpCnAEuYO = 0
	WQMiE9Lpzj34wGbk = int(om3XlN9aWpCnAEuYO/100)+1
	for iQBgv5oEbM6ZFH4U8qtC in range(2,WQMiE9Lpzj34wGbk):
		GXvW7eaHFjyiI6QUJ8brY9pKAs = (iQBgv5oEbM6ZFH4U8qtC%10==0 or int(SwDfU9qkrKo6QW2y)-4<iQBgv5oEbM6ZFH4U8qtC<int(SwDfU9qkrKo6QW2y)+4)
		esqA6aNSBjd5J = (GXvW7eaHFjyiI6QUJ8brY9pKAs and int(SwDfU9qkrKo6QW2y)-40<iQBgv5oEbM6ZFH4U8qtC<int(SwDfU9qkrKo6QW2y)+40)
		if str(iQBgv5oEbM6ZFH4U8qtC)!=SwDfU9qkrKo6QW2y and (iQBgv5oEbM6ZFH4U8qtC%100==0 or esqA6aNSBjd5J):
			zJLApFBcIhnSj('folder',XQgovGj6VkUFxH4a2+'صفحة '+str(iQBgv5oEbM6ZFH4U8qtC),MBHEOqmtX3SPb2whAFr6ul,HHrpyfWjGC,cdZKMn68Pzg4,str(iQBgv5oEbM6ZFH4U8qtC),JAYWBoz54tGw7O,cdZKMn68Pzg4,{'folder':Vea0sXycdJ8LFSMzhB5Zt73u2rD})
	if str(WQMiE9Lpzj34wGbk)!=SwDfU9qkrKo6QW2y: zJLApFBcIhnSj('folder',XQgovGj6VkUFxH4a2+'أخر صفحة '+str(WQMiE9Lpzj34wGbk),MBHEOqmtX3SPb2whAFr6ul,HHrpyfWjGC,cdZKMn68Pzg4,str(WQMiE9Lpzj34wGbk),JAYWBoz54tGw7O,cdZKMn68Pzg4,{'folder':Vea0sXycdJ8LFSMzhB5Zt73u2rD})
	return
def wwATViQ0xDaoNMEK4v3PIeC8UzZ5(Vea0sXycdJ8LFSMzhB5Zt73u2rD,MBHEOqmtX3SPb2whAFr6ul):
	RTr92nPJkjuBoDMbELV8Oa = FniuTws4b8L6Xr1ySlCKpVzckNqPgQ.replace('___','_'+Vea0sXycdJ8LFSMzhB5Zt73u2rD)
	return RTr92nPJkjuBoDMbELV8Oa
def zzKXxsiWfIU1E3l0BumDcnYS7(Vea0sXycdJ8LFSMzhB5Zt73u2rD):
	RTr92nPJkjuBoDMbELV8Oa = wwATViQ0xDaoNMEK4v3PIeC8UzZ5(Vea0sXycdJ8LFSMzhB5Zt73u2rD,cdZKMn68Pzg4)
	GPQCWezyxpbjhHNXMVEaI4FR = JyLdvftP3CU('center',cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,'جلب ملفات M3U جديدة قد تحتاج عدة دقائق .. هل تريد أن تجلب الملفات الآن ؟!')
	if GPQCWezyxpbjhHNXMVEaI4FR!=1: return False
	PMLNctzmY3ThUWw(Vea0sXycdJ8LFSMzhB5Zt73u2rD,False)
	O4tS8ByAdVmqXU0sP5uLQTh6bDNoz3 = [0]
	for B6Br4FlxoIEkAnjKgu3qd in range(1,ZVmIhR9YHACFNrGk546El1wdMB+1):
		KZV2X1pyHqe9Yjtcr8QCxi = Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.getSetting('av.m3u.url_'+Vea0sXycdJ8LFSMzhB5Zt73u2rD+'_'+str(B6Br4FlxoIEkAnjKgu3qd))
		if KZV2X1pyHqe9Yjtcr8QCxi: VEFIiuClxN6GjWzmpUsbTr4ekt(Vea0sXycdJ8LFSMzhB5Zt73u2rD,str(B6Br4FlxoIEkAnjKgu3qd))
		O4tS8ByAdVmqXU0sP5uLQTh6bDNoz3.append(0)
	for MBHEOqmtX3SPb2whAFr6ul in zzSXPqifhs8rYnUvbMkuR26B7:
		TjLbVGOe3pAn107cgtRu,fUtebsymvz9J5HIjX3Q2Z,btkApNa1mohn3O9ZFuBePJxCU,LcOkRH7sQeoX,IxVL4f8sCoMUnG = 0,{},[],[],[]
		for B6Br4FlxoIEkAnjKgu3qd in range(1,ZVmIhR9YHACFNrGk546El1wdMB+1):
			s8hDWSzkMKf5730dlFJjYaxprb = MBHEOqmtX3SPb2whAFr6ul+'_'+str(B6Br4FlxoIEkAnjKgu3qd)
			IvUahiecdM8DmJZ5 = sZHYrLPog4wmuW0ECdc(RTr92nPJkjuBoDMbELV8Oa,'dict',s8hDWSzkMKf5730dlFJjYaxprb)
			try:
				DDQJfw3PVNvgHpWO = IvUahiecdM8DmJZ5['__GROUPS__']
				ATg1dc5byeWvr6pVzBPF = IvUahiecdM8DmJZ5['__COUNT__']
			except: DDQJfw3PVNvgHpWO,ATg1dc5byeWvr6pVzBPF = [],'0'
			for wdZKPv0aFz2IcBYi1oAO8xkmG in DDQJfw3PVNvgHpWO:
				RRSaoMVs1BJdWNEpAP,cxokMEeWJnSdZGt53qYhI = wdZKPv0aFz2IcBYi1oAO8xkmG
				a2a0mpV49WBD5sIFYzU = IvUahiecdM8DmJZ5[RRSaoMVs1BJdWNEpAP]
				if RRSaoMVs1BJdWNEpAP not in LcOkRH7sQeoX:
					LcOkRH7sQeoX.append(RRSaoMVs1BJdWNEpAP)
					IxVL4f8sCoMUnG.append(wdZKPv0aFz2IcBYi1oAO8xkmG)
					fUtebsymvz9J5HIjX3Q2Z[RRSaoMVs1BJdWNEpAP] = []
				fUtebsymvz9J5HIjX3Q2Z[RRSaoMVs1BJdWNEpAP] += a2a0mpV49WBD5sIFYzU
			uVOoSHfqe4WtiF(RTr92nPJkjuBoDMbELV8Oa,s8hDWSzkMKf5730dlFJjYaxprb)
			uAkLQ7gEZaIBv6Fyn(RTr92nPJkjuBoDMbELV8Oa,s8hDWSzkMKf5730dlFJjYaxprb,'__COUNT__',ATg1dc5byeWvr6pVzBPF,jCmv4M3HNPdyaLS)
			O4tS8ByAdVmqXU0sP5uLQTh6bDNoz3[B6Br4FlxoIEkAnjKgu3qd] += int(ATg1dc5byeWvr6pVzBPF)
		for RRSaoMVs1BJdWNEpAP in LcOkRH7sQeoX:
			a2a0mpV49WBD5sIFYzU = list(set(fUtebsymvz9J5HIjX3Q2Z[RRSaoMVs1BJdWNEpAP]))
			if 'SORTED' in MBHEOqmtX3SPb2whAFr6ul: a2a0mpV49WBD5sIFYzU = sorted(a2a0mpV49WBD5sIFYzU,reverse=False,key=lambda key: key[1].lower())
			TjLbVGOe3pAn107cgtRu += len(a2a0mpV49WBD5sIFYzU)
			btkApNa1mohn3O9ZFuBePJxCU.append(a2a0mpV49WBD5sIFYzU)
		uAkLQ7gEZaIBv6Fyn(RTr92nPJkjuBoDMbELV8Oa,MBHEOqmtX3SPb2whAFr6ul,'__COUNT__',str(TjLbVGOe3pAn107cgtRu),jCmv4M3HNPdyaLS)
		uAkLQ7gEZaIBv6Fyn(RTr92nPJkjuBoDMbELV8Oa,MBHEOqmtX3SPb2whAFr6ul,'__GROUPS__',IxVL4f8sCoMUnG,jCmv4M3HNPdyaLS)
		uAkLQ7gEZaIBv6Fyn(RTr92nPJkjuBoDMbELV8Oa,MBHEOqmtX3SPb2whAFr6ul,LcOkRH7sQeoX,btkApNa1mohn3O9ZFuBePJxCU,jCmv4M3HNPdyaLS,True)
	II0z4hJmSEtlRqZuN8WcOib1sG = False
	for B6Br4FlxoIEkAnjKgu3qd in range(1,ZVmIhR9YHACFNrGk546El1wdMB+1):
		if int(O4tS8ByAdVmqXU0sP5uLQTh6bDNoz3[B6Br4FlxoIEkAnjKgu3qd])>0:
			KZV2X1pyHqe9Yjtcr8QCxi = Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.getSetting('av.m3u.url_'+Vea0sXycdJ8LFSMzhB5Zt73u2rD+'_'+str(B6Br4FlxoIEkAnjKgu3qd))
			uAkLQ7gEZaIBv6Fyn(RTr92nPJkjuBoDMbELV8Oa,'LINK_'+str(B6Br4FlxoIEkAnjKgu3qd),'__LINK__',KZV2X1pyHqe9Yjtcr8QCxi,jCmv4M3HNPdyaLS)
			II0z4hJmSEtlRqZuN8WcOib1sG = True
	uAkLQ7gEZaIBv6Fyn(RTr92nPJkjuBoDMbELV8Oa,'DUMMY','__DUMMY__','DUMMY',jCmv4M3HNPdyaLS)
	if not II0z4hJmSEtlRqZuN8WcOib1sG:
		NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,'فشل بسحب ملفات M3U .. أحتمال روابط M3U التي أنت أضفتها للبرنامج غير صحيحة .. علما أن هذه الخدمة تحتاج منك أن تضيف الرابط بنفسك للبرنامج باستخدام قائمة M3U الموجودة في هذا البرنامج')
		return False
	NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,'تم جلب ملفات M3U جديدة')
	zuoCGEY4fpaVetA1(Vea0sXycdJ8LFSMzhB5Zt73u2rD)
	tiuZ61v2BRxSKgJWfpbL0Yq(False)
	XfABsbKWoLhI(False)
	return True
def zuoCGEY4fpaVetA1(Vea0sXycdJ8LFSMzhB5Zt73u2rD):
	RTr92nPJkjuBoDMbELV8Oa = wwATViQ0xDaoNMEK4v3PIeC8UzZ5(Vea0sXycdJ8LFSMzhB5Zt73u2rD,cdZKMn68Pzg4)
	if not Im36vznMobP7WCNfFY2lJZ(Vea0sXycdJ8LFSMzhB5Zt73u2rD,True): return
	for B6Br4FlxoIEkAnjKgu3qd in range(1,ZVmIhR9YHACFNrGk546El1wdMB+1):
		KZV2X1pyHqe9Yjtcr8QCxi = sZHYrLPog4wmuW0ECdc(RTr92nPJkjuBoDMbELV8Oa,'str','LINK_'+str(B6Br4FlxoIEkAnjKgu3qd),'__LINK__')
		if KZV2X1pyHqe9Yjtcr8QCxi: RuDBlzZQK8ihkY36tf7FjGHvoAST = U2i5lhIGe8EmckoLY(Vea0sXycdJ8LFSMzhB5Zt73u2rD,str(B6Br4FlxoIEkAnjKgu3qd))
	U2i5lhIGe8EmckoLY(Vea0sXycdJ8LFSMzhB5Zt73u2rD,cdZKMn68Pzg4)
	return
def PMLNctzmY3ThUWw(Vea0sXycdJ8LFSMzhB5Zt73u2rD,bUHVjvzwnyi):
	if bUHVjvzwnyi:
		GPQCWezyxpbjhHNXMVEaI4FR = JyLdvftP3CU('center',cdZKMn68Pzg4,cdZKMn68Pzg4,'مسح ملفات ـM3U','هل تريد مسح الملفات القديمة المخزنة في البرنامج ؟! \n\n علما انك تستطيع في أي وقت الدخول إلى قائمة M3U وجلب ملفات M3U جديدة')
		if GPQCWezyxpbjhHNXMVEaI4FR!=1: return
	RTr92nPJkjuBoDMbELV8Oa = wwATViQ0xDaoNMEK4v3PIeC8UzZ5(Vea0sXycdJ8LFSMzhB5Zt73u2rD,cdZKMn68Pzg4)
	try: YRESXadfbIy3khwqmL8WC.remove(RTr92nPJkjuBoDMbELV8Oa)
	except: pass
	for B6Br4FlxoIEkAnjKgu3qd in range(1,ZVmIhR9YHACFNrGk546El1wdMB+1):
		egcKB4Phb2Fn15JfX0IApVd7mWz = Y75iNHQZIJbhG6.replace('___','_'+Vea0sXycdJ8LFSMzhB5Zt73u2rD+'_'+str(B6Br4FlxoIEkAnjKgu3qd))
		W4fhK9UpZBM6Q5Eqz8Jjv = YRESXadfbIy3khwqmL8WC.path.join(qq9xw1jKIVH5kuNGMsPLiCO6Rp0Zv,egcKB4Phb2Fn15JfX0IApVd7mWz)
		try: YRESXadfbIy3khwqmL8WC.remove(W4fhK9UpZBM6Q5Eqz8Jjv)
		except: pass
	uVOoSHfqe4WtiF(TV08xYHA2ok,'SECTIONS_M3U','SECTIONS_M3U_'+Vea0sXycdJ8LFSMzhB5Zt73u2rD)
	uVOoSHfqe4WtiF(TV08xYHA2ok,'SECTIONS_M3U','SECTIONS_M3U_ALL')
	if bUHVjvzwnyi:
		NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,'تم مسح جميع ملفات ـM3U')
		XfABsbKWoLhI(False)
	return
def SYaTv4t7q0cy96(Vea0sXycdJ8LFSMzhB5Zt73u2rD):
	NNqDuAfp4amdkLPovXrc02ZYl81 = Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.getSetting('av.language.provider')
	D7fpJ0XmCQTLoMxr6uHZcUPh = Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.getSetting('av.language.code')
	uVOoSHfqe4WtiF(TV08xYHA2ok,'MENUS_CACHE_'+NNqDuAfp4amdkLPovXrc02ZYl81+'_'+D7fpJ0XmCQTLoMxr6uHZcUPh,'%_MU'+Vea0sXycdJ8LFSMzhB5Zt73u2rD+'_%')
	return
LcUuODjqpP5Al69 = {
		 'AF':'Afghanistan'
		,'AL':'Albania'
		,'DZ':'Algeria'
		,'AS':'American Samoa'
		,'AD':'Andorra'
		,'AO':'Angola'
		,'AI':'Anguilla'
		,'AQ':'Antarctica'
		,'AG':'Antigua and Barbuda'
		,'AR':'Argentina'
		,'AM':'Armenia'
		,'AW':'Aruba'
		,'AU':'Australia'
		,'AT':'Austria'
		,'AZ':'Azerbaijan'
		,'BS':'Bahamas'
		,'BH':'Bahrain'
		,'BD':'Bangladesh'
		,'BB':'Barbados'
		,'BY':'Belarus'
		,'BE':'Belgium'
		,'BZ':'Belize'
		,'BJ':'Benin'
		,'BM':'Bermuda'
		,'BT':'Bhutan'
		,'BO':'Bolivia'
		,'BQ':'Bonaire'
		,'BA':'Bosnia and Herzegovina'
		,'BW':'Botswana'
		,'BV':'Bouvet Island'
		,'BR':'Brazil'
		,'IO':'British Indian Ocean Territory'
		,'VG':'British Virgin Islands'
		,'BN':'Brunei'
		,'BG':'Bulgaria'
		,'BF':'Burkina Faso'
		,'BI':'Burundi'
		,'KH':'Cambodia'
		,'CM':'Cameroon'
		,'CA':'Canada'
		,'CV':'Cape Verde'
		,'KY':'Cayman Islands'
		,'CF':'Central African Republic'
		,'TD':'Chad'
		,'CL':'Chile'
		,'CN':'China'
		,'CX':'Christmas Island'
		,'CC':'Cocos (Keeling) Islands'
		,'CO':'Colombia'
		,'KM':'Comoros'
		,'CK':'Cook Islands'
		,'CR':'Costa Rica'
		,'HR':'Croatia'
		,'CU':'Cuba'
		,'CW':'Curacao'
		,'CY':'Cyprus'
		,'CZ':'Czech Republic'
		,'CD':'Democratic Republic of the Congo'
		,'DK':'Denmark'
		,'DJ':'Djibouti'
		,'DM':'Dominica'
		,'DO':'Dominican Republic'
		,'TL':'East Timor'
		,'EC':'Ecuador'
		,'EG':'Egypt'
		,'SV':'El Salvador'
		,'GQ':'Equatorial Guinea'
		,'ER':'Eritrea'
		,'EE':'Estonia'
		,'ET':'Ethiopia'
		,'FK':'Falkland Islands'
		,'FO':'Faroe Islands'
		,'FJ':'Fiji'
		,'FI':'Finland'
		,'FR':'France'
		,'GF':'French Guiana'
		,'PF':'French Polynesia'
		,'TF':'French Southern Territories'
		,'GA':'Gabon'
		,'GM':'Gambia'
		,'GE':'Georgia'
		,'DE':'Germany'
		,'GH':'Ghana'
		,'GI':'Gibraltar'
		,'GR':'Greece'
		,'GL':'Greenland'
		,'GD':'Grenada'
		,'GP':'Guadeloupe'
		,'GU':'Guam'
		,'GT':'Guatemala'
		,'GG':'Guernsey'
		,'GN':'Guinea'
		,'GW':'Guinea-Bissau'
		,'GY':'Guyana'
		,'HT':'Haiti'
		,'HM':'Heard Island and McDonald Islands'
		,'HN':'Honduras'
		,'HK':'Hong Kong'
		,'HU':'Hungary'
		,'IS':'Iceland'
		,'IN':'India'
		,'ID':'Indonesia'
		,'IR':'Iran'
		,'IQ':'Iraq'
		,'IE':'Ireland'
		,'IM':'Isle of Man'
		,'IL':'Israel'
		,'IT':'Italy'
		,'CI':'Ivory Coast'
		,'JM':'Jamaica'
		,'JP':'Japan'
		,'JE':'Jersey'
		,'JO':'Jordan'
		,'KZ':'Kazakhstan'
		,'KE':'Kenya'
		,'KI':'Kiribati'
		,'XK':'Kosovo'
		,'KW':'Kuwait'
		,'KG':'Kyrgyzstan'
		,'LA':'Laos'
		,'LV':'Latvia'
		,'LB':'Lebanon'
		,'LS':'Lesotho'
		,'LR':'Liberia'
		,'LY':'Libya'
		,'LI':'Liechtenstein'
		,'LT':'Lithuania'
		,'LU':'Luxembourg'
		,'MO':'Macao'
		,'MG':'Madagascar'
		,'MW':'Malawi'
		,'MY':'Malaysia'
		,'MV':'Maldives'
		,'ML':'Mali'
		,'MT':'Malta'
		,'MH':'Marshall Islands'
		,'MQ':'Martinique'
		,'MR':'Mauritania'
		,'MU':'Mauritius'
		,'YT':'Mayotte'
		,'MX':'Mexico'
		,'FM':'Micronesia'
		,'MD':'Moldova'
		,'MC':'Monaco'
		,'MN':'Mongolia'
		,'ME':'Montenegro'
		,'MS':'Montserrat'
		,'MA':'Morocco'
		,'MZ':'Mozambique'
		,'MM':'Myanmar (Burma)'
		,'NA':'Namibia'
		,'NR':'Nauru'
		,'NP':'Nepal'
		,'NL':'Netherlands'
		,'NC':'New Caledonia'
		,'NZ':'New Zealand'
		,'NI':'Nicaragua'
		,'NE':'Niger'
		,'NG':'Nigeria'
		,'NU':'Niue'
		,'NF':'Norfolk Island'
		,'KP':'North Korea'
		,'MK':'North Macedonia'
		,'MP':'Northern Mariana Islands'
		,'NO':'Norway'
		,'OM':'Oman'
		,'PK':'Pakistan'
		,'PW':'Palau'
		,'PS':'Palestine'
		,'PA':'Panama'
		,'PG':'Papua New Guinea'
		,'PY':'Paraguay'
		,'PE':'Peru'
		,'PH':'Philippines'
		,'PN':'Pitcairn Islands'
		,'PL':'Poland'
		,'PT':'Portugal'
		,'PR':'Puerto Rico'
		,'QA':'Qatar'
		,'CG':'Republic of the Congo'
		,'RO':'Romania'
		,'RU':'Russia'
		,'RW':'Rwanda'
		,'RE':'Réunion'
		,'BL':'Saint Barthélemy'
		,'SH':'Saint Helena'
		,'KN':'Saint Kitts and Nevis'
		,'LC':'Saint Lucia'
		,'MF':'Saint Martin'
		,'PM':'Saint Pierre and Miquelon'
		,'VC':'Saint Vincent and the Grenadines'
		,'WS':'Samoa'
		,'SM':'San Marino'
		,'SA':'Saudi Arabia'
		,'SN':'Senegal'
		,'RS':'Serbia'
		,'SC':'Seychelles'
		,'SL':'Sierra Leone'
		,'SG':'Singapore'
		,'SX':'Sint Maarten'
		,'SK':'Slovakia'
		,'SI':'Slovenia'
		,'SB':'Solomon Islands'
		,'SO':'Somalia'
		,'ZA':'South Africa'
		,'GS':'South Georgia and the South Sandwich Islands'
		,'KR':'South Korea'
		,'SS':'South Sudan'
		,'ES':'Spain'
		,'LK':'Sri Lanka'
		,'SD':'Sudan'
		,'SR':'Suriname'
		,'SJ':'Svalbard and Jan Mayen'
		,'SZ':'Swaziland'
		,'SE':'Sweden'
		,'CH':'Switzerland'
		,'SY':'Syria'
		,'ST':'São Tomé and Príncipe'
		,'TW':'Taiwan'
		,'TJ':'Tajikistan'
		,'TZ':'Tanzania'
		,'TH':'Thailand'
		,'TG':'Togo'
		,'TK':'Tokelau'
		,'TO':'Tonga'
		,'TT':'Trinidad and Tobago'
		,'TN':'Tunisia'
		,'TR':'Turkey'
		,'TM':'Turkmenistan'
		,'TC':'Turks and Caicos Islands'
		,'TV':'Tuvalu'
		,'UM':'U.S. Minor Outlying Islands'
		,'VI':'U.S. Virgin Islands'
		,'UG':'Uganda'
		,'UA':'Ukraine'
		,'AE':'United Arab Emirates'
		,'UK':'United Kingdom'
		,'US':'United States'
		,'UY':'Uruguay'
		,'UZ':'Uzbekistan'
		,'VU':'Vanuatu'
		,'VA':'Vatican City'
		,'VE':'Venezuela'
		,'VN':'Vietnam'
		,'WF':'Wallis and Futuna'
		,'EH':'Western Sahara'
		,'YE':'Yemen'
		,'ZM':'Zambia'
		,'ZW':'Zimbabwe'
		,'AX':'Åland'
		}
# -*- coding: utf-8 -*-
from RgJNGc7YMP import *
UkXlAzsMcamKJrEIgnxi6bWh = 'CIMA400'
nc3GLkA65oxOd = '_C4H_'
cDTdfqVAF0BLGiX364IEwaZbr = USuRxnPlV5.SITESURLS[UkXlAzsMcamKJrEIgnxi6bWh][0]
cJWUPuDGM0Yybv5a9KnIrVzhH78 = ['الصفحة الرئيسية','Sign in','الاقسام','عرض المزيد','Categories',cdZKMn68Pzg4]
def HHN5EpbszV3iA2m89hGSQjaPgUZy(mode,url,text):
	if   mode==690: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = kUq58vC7x9hWma164JejMKQ()
	elif mode==691: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = GDQUH4fN02sIt81mAcY(url,text)
	elif mode==692: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = RPZbqous7rtdy56LeI18Cv04AKHW(url)
	elif mode==693: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = m3uV0rQSzFgqE6lIh4Y5bXxjiANDP(url,text)
	elif mode==694: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = oQF2hgjusp8Ne(url)
	elif mode==699: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = z4hetAJw3NaT9ROjG6xbZ5CHlW81(text)
	else: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = False
	return xsGUcR3ef6glKY5hQwpFXEaSt2mrIz
def kUq58vC7x9hWma164JejMKQ():
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',cDTdfqVAF0BLGiX364IEwaZbr,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'CIMA400-MENU-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'بحث في الموقع',cdZKMn68Pzg4,699,cdZKMn68Pzg4,cdZKMn68Pzg4,'_REMEMBERRESULTS_')
	zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"navslide-divider"(.*?)"navslide-divider"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
	items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?>(.*?)</',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	for c0cDhidBlOn7,title in items:
		if title in cJWUPuDGM0Yybv5a9KnIrVzhH78: continue
		title = title.replace('<b>',cdZKMn68Pzg4).strip(VBpIH2QSmvDGlA6TO3e)
		zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+title,c0cDhidBlOn7,694)
	return
def oQF2hgjusp8Ne(url):
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'CIMA400-SUBMENU-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	ptXc2zV0RhTb = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"caret"(.*?)</ul>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ptXc2zV0RhTb:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ptXc2zV0RhTb[0]
		KdWauEhgN6OQzjRVm1ro8tkB3 = KdWauEhgN6OQzjRVm1ro8tkB3.replace('"presentation"','</ul>')
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if not ppvsMqCHf8SEzxQg: ppvsMqCHf8SEzxQg = [(cdZKMn68Pzg4,KdWauEhgN6OQzjRVm1ro8tkB3)]
		zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' فرز أو فلتر أو ترتيب '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
		for t6mhUyqP0KW9VQsFOX8EG1IwraN,KdWauEhgN6OQzjRVm1ro8tkB3 in ppvsMqCHf8SEzxQg:
			items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?>(.*?)</a>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			if t6mhUyqP0KW9VQsFOX8EG1IwraN: t6mhUyqP0KW9VQsFOX8EG1IwraN = t6mhUyqP0KW9VQsFOX8EG1IwraN+': '
			for c0cDhidBlOn7,title in items:
				title = t6mhUyqP0KW9VQsFOX8EG1IwraN+title
				zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,691)
	ll9vYSyie5kwbR16U0a2K = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"pm-category-subcats"(.*?)</ul>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ll9vYSyie5kwbR16U0a2K:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ll9vYSyie5kwbR16U0a2K[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)">(.*?)</a>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if len(items)<30:
			zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
			for c0cDhidBlOn7,title in items:
				zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,691)
	if not ptXc2zV0RhTb and not ll9vYSyie5kwbR16U0a2K: GDQUH4fN02sIt81mAcY(url)
	return
def GDQUH4fN02sIt81mAcY(url,CvSX7Etpz80eGlT1brgWZkJ=cdZKMn68Pzg4):
	if CvSX7Etpz80eGlT1brgWZkJ=='ajax-search':
		url,search = url.split('?',1)
		data = 'queryString='+search
		headers = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'POST',url,data,headers,cdZKMn68Pzg4,cdZKMn68Pzg4,'CIMA400-TITLES-1st')
	else:
		Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'CIMA400-TITLES-2nd')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	KdWauEhgN6OQzjRVm1ro8tkB3,items = cdZKMn68Pzg4,[]
	u1P73L0UmkA4eaIBbCgZfrvRtJ = CxlbPZwGTcH87e1sWhfSIz29uRUEpV(url,'url')
	if CvSX7Etpz80eGlT1brgWZkJ=='ajax-search':
		KdWauEhgN6OQzjRVm1ro8tkB3 = OO1cj2REUZHJ8x5V
		zaUqdBJDmY = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)">(.*?)</a>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,title in zaUqdBJDmY: items.append((cdZKMn68Pzg4,c0cDhidBlOn7,title))
	elif CvSX7Etpz80eGlT1brgWZkJ=='featured':
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"pm-video-watch-featured"(.*?)</ul>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if ppvsMqCHf8SEzxQg: KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
	elif CvSX7Etpz80eGlT1brgWZkJ=='new_episodes':
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"row pm-ul-browse-videos(.*?)</ul>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if ppvsMqCHf8SEzxQg: KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
	elif CvSX7Etpz80eGlT1brgWZkJ=='new_movies':
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"row pm-ul-browse-videos(.*?)</ul>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if len(ppvsMqCHf8SEzxQg)>1: KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[1]
	elif CvSX7Etpz80eGlT1brgWZkJ=='featured_series':
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"ba mgb table full"(.*?)"clearfix"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if ppvsMqCHf8SEzxQg: KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		zaUqdBJDmY = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="([^"]*)" title="([^"]*)"',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,title in zaUqdBJDmY: items.append((cdZKMn68Pzg4,c0cDhidBlOn7,title))
	else:
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('(data-echo=".*?)</ul>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if ppvsMqCHf8SEzxQg: KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
	if KdWauEhgN6OQzjRVm1ro8tkB3 and not items: items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if not items: return
	KRmzvoWYyxfXw37SEh1Q = []
	rgWUvoaJnZARc375bjQ = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for y90BoFz8MA1ZThaSC2ILXHiK3OY6w,c0cDhidBlOn7,title in items:
		E0w56WHxZPYGVvnTQ4O2t1C8DAjq = ffUFBJQ57j2XgoGeOLn9uwpC.findall('(.*?) (الحلقة|حلقة).\d+',title,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if any(value in title for value in rgWUvoaJnZARc375bjQ):
			zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,692,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
		elif CvSX7Etpz80eGlT1brgWZkJ=='new_episodes':
			zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,692,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
		elif E0w56WHxZPYGVvnTQ4O2t1C8DAjq:
			title = '_MOD_' + E0w56WHxZPYGVvnTQ4O2t1C8DAjq[0][0]
			if title not in KRmzvoWYyxfXw37SEh1Q:
				zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,693,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
				KRmzvoWYyxfXw37SEh1Q.append(title)
		else: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,693,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
	if 1:
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"pagination(.*?)</ul>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if ppvsMqCHf8SEzxQg:
			KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
			items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?>(.*?)</a>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			for c0cDhidBlOn7,title in items:
				if c0cDhidBlOn7=='#': continue
				c0cDhidBlOn7 = u1P73L0UmkA4eaIBbCgZfrvRtJ+KCQExdbYFqM+c0cDhidBlOn7.strip(KCQExdbYFqM)
				title = gbd90SjF2mZqf81IRDaTwJkWu(title)
				zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'صفحة '+title,c0cDhidBlOn7,691)
	return
def m3uV0rQSzFgqE6lIh4Y5bXxjiANDP(url,v7BFbdjHVQwcOZ1Il86huxJs9ge):
	u1P73L0UmkA4eaIBbCgZfrvRtJ = CxlbPZwGTcH87e1sWhfSIz29uRUEpV(url,'url')
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'CIMA400-EPISODES-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	ptXc2zV0RhTb = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"SeasonsBox"(.*?)"SeasonsEpisodesMain',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	fh6qmOxoiv1UPXZanLprDeMI8 = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"series-header".*?src="(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if fh6qmOxoiv1UPXZanLprDeMI8: y90BoFz8MA1ZThaSC2ILXHiK3OY6w = fh6qmOxoiv1UPXZanLprDeMI8[0]
	else: y90BoFz8MA1ZThaSC2ILXHiK3OY6w = cdZKMn68Pzg4
	items = []
	T1xXys30LuBZQqt9bhgEmKpvGCcHle = False
	if ptXc2zV0RhTb and not v7BFbdjHVQwcOZ1Il86huxJs9ge:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ptXc2zV0RhTb[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('''openCity\(event, '(.*?)'\).*?">(.*?)</button>''',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if not items: items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('data-serie="(.*?)".*?">(.*?)</',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for v7BFbdjHVQwcOZ1Il86huxJs9ge,title in items:
			v7BFbdjHVQwcOZ1Il86huxJs9ge = v7BFbdjHVQwcOZ1Il86huxJs9ge.strip('#')
			if len(items)>1: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,url,693,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,cdZKMn68Pzg4,v7BFbdjHVQwcOZ1Il86huxJs9ge)
			else: T1xXys30LuBZQqt9bhgEmKpvGCcHle = True
	else: T1xXys30LuBZQqt9bhgEmKpvGCcHle = True
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"SeasonsEpisodesMain(.*?</div>).</div>.</div>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		ll9vYSyie5kwbR16U0a2K = ffUFBJQ57j2XgoGeOLn9uwpC.findall('id="'+v7BFbdjHVQwcOZ1Il86huxJs9ge+'"(.*?)</ul>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if not ll9vYSyie5kwbR16U0a2K: ll9vYSyie5kwbR16U0a2K = ffUFBJQ57j2XgoGeOLn9uwpC.findall('data-serie="'+v7BFbdjHVQwcOZ1Il86huxJs9ge+'"(.*?)</div>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if not ll9vYSyie5kwbR16U0a2K: ll9vYSyie5kwbR16U0a2K = ffUFBJQ57j2XgoGeOLn9uwpC.findall('id="Season'+v7BFbdjHVQwcOZ1Il86huxJs9ge+'"(.*?)</ul>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if ll9vYSyie5kwbR16U0a2K and T1xXys30LuBZQqt9bhgEmKpvGCcHle:
			KdWauEhgN6OQzjRVm1ro8tkB3 = ll9vYSyie5kwbR16U0a2K[0]
			zaUqdBJDmY = ffUFBJQ57j2XgoGeOLn9uwpC.findall("href='(.*?)'><li><em>(.*?)</span>",KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			if not zaUqdBJDmY: zaUqdBJDmY = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?<em>(.*?)</span>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			items = []
			for c0cDhidBlOn7,title in zaUqdBJDmY: items.append((c0cDhidBlOn7,title,y90BoFz8MA1ZThaSC2ILXHiK3OY6w))
			if not items: items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"thumbnail".*?href="([^"]*)" title="([^"]*)".*?src="(.*?)"',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			for c0cDhidBlOn7,title,y90BoFz8MA1ZThaSC2ILXHiK3OY6w in items:
				c0cDhidBlOn7 = c0cDhidBlOn7.strip('./')
				c0cDhidBlOn7 = u1P73L0UmkA4eaIBbCgZfrvRtJ+KCQExdbYFqM+c0cDhidBlOn7.strip(KCQExdbYFqM)
				title = title.replace('</em><span>',VBpIH2QSmvDGlA6TO3e)
				zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,692,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
	return
def RPZbqous7rtdy56LeI18Cv04AKHW(url):
	pcX7zxFRmsADwUr,Dh86vEgI1n,XFj0lV5yMtS67EwbCJ9oO = [],[],[]
	HOCWKhxITtulVGX = url.replace('/watch.php','/see.php')
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',HOCWKhxITtulVGX,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'CIMA400-PLAY-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"WatchList"(.*?)</div>.</div>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		c0cDhidBlOn7 = ffUFBJQ57j2XgoGeOLn9uwpC.findall('<iframe src="(.*?)"',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if c0cDhidBlOn7:
			c0cDhidBlOn7 = c0cDhidBlOn7[0]
			Dh86vEgI1n.append('?named=__embed')
			pcX7zxFRmsADwUr.append(c0cDhidBlOn7)
		zz4ZPovUbyk5GEhNMs8JDnaVXftS = ffUFBJQ57j2XgoGeOLn9uwpC.findall('data-embed-url="(.*?)".*?onclick.*?">(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,title in zz4ZPovUbyk5GEhNMs8JDnaVXftS:
			title = title.strip(VBpIH2QSmvDGlA6TO3e)
			if c0cDhidBlOn7 not in pcX7zxFRmsADwUr:
				Dh86vEgI1n.append('?named='+title+'__watch')
				pcX7zxFRmsADwUr.append(c0cDhidBlOn7)
		zz4ZPovUbyk5GEhNMs8JDnaVXftS = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(http.*?)".*?</i>(.*?)</a>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,title in zz4ZPovUbyk5GEhNMs8JDnaVXftS:
			if c0cDhidBlOn7 not in pcX7zxFRmsADwUr:
				title = title.strip(ssELJkeScrtni2)
				Dh86vEgI1n.append('?named='+title+'__download')
				pcX7zxFRmsADwUr.append(c0cDhidBlOn7)
	JJA9R5FEWOzQbDd8eowj3cv4 = zip(pcX7zxFRmsADwUr,Dh86vEgI1n)
	for c0cDhidBlOn7,name in JJA9R5FEWOzQbDd8eowj3cv4: XFj0lV5yMtS67EwbCJ9oO.append(c0cDhidBlOn7+name)
	import r0y4XTKznF
	r0y4XTKznF.noHliPXkcg3pJTdSauCvm5sU(XFj0lV5yMtS67EwbCJ9oO,UkXlAzsMcamKJrEIgnxi6bWh,'video',url)
	return
def z4hetAJw3NaT9ROjG6xbZ5CHlW81(search):
	search,EL8zUgbXheot,showDialogs = qbIcHCMdkFKn21e(search)
	if search==cdZKMn68Pzg4: search = BzkmLuvJD9n25Pg()
	if search==cdZKMn68Pzg4: return
	search = search.replace(VBpIH2QSmvDGlA6TO3e,'+')
	url = cDTdfqVAF0BLGiX364IEwaZbr+'/search.php?keywords='+search
	GDQUH4fN02sIt81mAcY(url,'search')
	return
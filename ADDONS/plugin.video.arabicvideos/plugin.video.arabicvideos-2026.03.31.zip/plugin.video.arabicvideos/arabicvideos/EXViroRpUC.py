# -*- coding: utf-8 -*-
from RgJNGc7YMP import *
UkXlAzsMcamKJrEIgnxi6bWh = 'ARABICTOONS'
nc3GLkA65oxOd = '_ART_'
cDTdfqVAF0BLGiX364IEwaZbr = USuRxnPlV5.SITESURLS[UkXlAzsMcamKJrEIgnxi6bWh][0]
def HHN5EpbszV3iA2m89hGSQjaPgUZy(mode,url,text):
	if   mode==730: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = kUq58vC7x9hWma164JejMKQ()
	elif mode==731: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = GDQUH4fN02sIt81mAcY(url,text)
	elif mode==732: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = RPZbqous7rtdy56LeI18Cv04AKHW(url)
	elif mode==733: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = yIZWSuMpvs3(url)
	elif mode==734: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = RBP8V3OFMyCj4aQ2K5(url)
	elif mode==735: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = sdwfx8SbYMWrectBPXH(url)
	elif mode==739: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = z4hetAJw3NaT9ROjG6xbZ5CHlW81(text)
	else: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = False
	return xsGUcR3ef6glKY5hQwpFXEaSt2mrIz
def kUq58vC7x9hWma164JejMKQ():
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'بحث في الموقع',cdZKMn68Pzg4,739,cdZKMn68Pzg4,cdZKMn68Pzg4,'_REMEMBERRESULTS_')
	zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+'افلام',cDTdfqVAF0BLGiX364IEwaZbr+'/movies.php',731)
	zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+'مسلسلات',cDTdfqVAF0BLGiX364IEwaZbr+'/cartoon.php',734)
	zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+'الحلقات الجديدة',cDTdfqVAF0BLGiX364IEwaZbr,731,'','','latest_episodes')
	zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+'مسلسلات جديدة',cDTdfqVAF0BLGiX364IEwaZbr,731,'','','latest_series')
	zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+'أفلام جديدة',cDTdfqVAF0BLGiX364IEwaZbr,731,'','','latest_movies')
	return
def RBP8V3OFMyCj4aQ2K5(url):
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'ARABICTOONS-SERIES_SUBMENU-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"series-fullpage"(.*?)</div>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?>(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,title in items:
			c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr+KCQExdbYFqM+c0cDhidBlOn7
			title = 'الكل' if 'الكل' in title else 'حرف '+title
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,731)
	return
def sdwfx8SbYMWrectBPXH(url):
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'ARABICTOONS-SERIES_FEATURED-2nd')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="slider"(.*?)</ul>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('title="(.*?)" href="(.*?)".*?src="(.*?)"',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for title,c0cDhidBlOn7,y90BoFz8MA1ZThaSC2ILXHiK3OY6w in items:
			c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr+KCQExdbYFqM+c0cDhidBlOn7
			y90BoFz8MA1ZThaSC2ILXHiK3OY6w = cDTdfqVAF0BLGiX364IEwaZbr+KCQExdbYFqM+y90BoFz8MA1ZThaSC2ILXHiK3OY6w
			title = title.strip(VBpIH2QSmvDGlA6TO3e)
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,733,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
	return
def GDQUH4fN02sIt81mAcY(url,CvSX7Etpz80eGlT1brgWZkJ):
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'ARABICTOONS-TITLES-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	if CvSX7Etpz80eGlT1brgWZkJ=='search':
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"section-header">(.*?)pagination',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?src="(.*?)".*?title">(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	elif 'latest' in CvSX7Etpz80eGlT1brgWZkJ:
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"section-header">(.*?)"swiper-pagination"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if CvSX7Etpz80eGlT1brgWZkJ=='latest_movies': KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[2]
		elif CvSX7Etpz80eGlT1brgWZkJ=='latest_series': KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[1]
		else: KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?src="(.*?)" alt="(.*?)"',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	else:
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"series-grid-swiper"(.*?)pagination',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="([^"]*)" title="([^"]*)".*?src="(.*?)"',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		zz4ZPovUbyk5GEhNMs8JDnaVXftS,Snu3TYPhdqbc,SSBuJX4Z5QDCyA3eRGwWF9vqUaTl = zip(*items)
		items = zip(zz4ZPovUbyk5GEhNMs8JDnaVXftS,SSBuJX4Z5QDCyA3eRGwWF9vqUaTl,Snu3TYPhdqbc)
	for c0cDhidBlOn7,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,title in items:
		if 'books' in c0cDhidBlOn7: continue
		c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr+KCQExdbYFqM+c0cDhidBlOn7
		if 'http' not in y90BoFz8MA1ZThaSC2ILXHiK3OY6w: y90BoFz8MA1ZThaSC2ILXHiK3OY6w = cDTdfqVAF0BLGiX364IEwaZbr+KCQExdbYFqM+y90BoFz8MA1ZThaSC2ILXHiK3OY6w
		title = title.strip()
		if 'movies.php' in url or CvSX7Etpz80eGlT1brgWZkJ=='latest_movies': zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,732,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
		else: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,733,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('pagination(.*?)"series-grid-swiper"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?"page-number">(.*?)</a>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,title in items:
			if '>' in title: continue
			c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr+KCQExdbYFqM+c0cDhidBlOn7 if '.php' in c0cDhidBlOn7 else url+c0cDhidBlOn7
			title = title.strip()
			title = gbd90SjF2mZqf81IRDaTwJkWu(title)
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'صفحة '+title,c0cDhidBlOn7,731)
	return
def yIZWSuMpvs3(url):
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'ARABICTOONS-EPISODES-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"episodes-section"(.*?)<script>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="([^"]*)" title="([^"]*)".*?src="(.*?)"',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,title,y90BoFz8MA1ZThaSC2ILXHiK3OY6w in items:
			c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr+KCQExdbYFqM+c0cDhidBlOn7
			y90BoFz8MA1ZThaSC2ILXHiK3OY6w = cDTdfqVAF0BLGiX364IEwaZbr+KCQExdbYFqM+y90BoFz8MA1ZThaSC2ILXHiK3OY6w
			title = title.strip()
			zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,732,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
	return
def RPZbqous7rtdy56LeI18Cv04AKHW(url):
	XFj0lV5yMtS67EwbCJ9oO = []
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'ARABICTOONS-PLAY-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	c0cDhidBlOn7 = ffUFBJQ57j2XgoGeOLn9uwpC.findall('videoSrc = "(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if c0cDhidBlOn7:
		c0cDhidBlOn7 = c0cDhidBlOn7[0]
		c0cDhidBlOn7 = c0cDhidBlOn7+'|Sec-Fetch-Dest=video'
		XFj0lV5yMtS67EwbCJ9oO.append(c0cDhidBlOn7+'?named=__embed')
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"player-switcher-form"(.*?)</form>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('value="(.*?)".*?"btn-text">(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for choice,title in items:
			c0cDhidBlOn7 = url+'?player_choice='+choice+'&form_submitted=1'
			XFj0lV5yMtS67EwbCJ9oO.append(c0cDhidBlOn7+'?named='+title+'__watch')
	DTO3SWCaZEr = ffUFBJQ57j2XgoGeOLn9uwpC.findall(r'dynamique.*?}\);', OO1cj2REUZHJ8x5V, ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if not DTO3SWCaZEr: DTO3SWCaZEr = ffUFBJQ57j2XgoGeOLn9uwpC.findall(r'dynamique.*?}\)', OO1cj2REUZHJ8x5V, ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if DTO3SWCaZEr:
		QVhBOwLHsIF41R3Ao8ECc7D5qYnW = DTO3SWCaZEr[0]
		vqc9IEVZpRXtfTlMe57BbC36QkzxoY = dict(ffUFBJQ57j2XgoGeOLn9uwpC.findall(r'(\w+):\s*"([^"]+)"', QVhBOwLHsIF41R3Ao8ECc7D5qYnW))
		zzZItMdJqw6R = ffUFBJQ57j2XgoGeOLn9uwpC.search(r'const\s+(\w+)', QVhBOwLHsIF41R3Ao8ECc7D5qYnW)
		IN0jyfe1PRdDz6YX3CoJkHthw = zzZItMdJqw6R.group(1) if zzZItMdJqw6R else ""
		keys = ffUFBJQ57j2XgoGeOLn9uwpC.findall(r'\$\{' + IN0jyfe1PRdDz6YX3CoJkHthw + r'\.(\w+)\}', QVhBOwLHsIF41R3Ao8ECc7D5qYnW)
		if vqc9IEVZpRXtfTlMe57BbC36QkzxoY and keys:
			c0cDhidBlOn7 = "%s://%s/%s?%s" % (vqc9IEVZpRXtfTlMe57BbC36QkzxoY[keys[0]], vqc9IEVZpRXtfTlMe57BbC36QkzxoY[keys[1]], vqc9IEVZpRXtfTlMe57BbC36QkzxoY[keys[2]], vqc9IEVZpRXtfTlMe57BbC36QkzxoY[keys[3]])
			XFj0lV5yMtS67EwbCJ9oO.append(c0cDhidBlOn7+'?named=__embed')
	c0cDhidBlOn7 = ffUFBJQ57j2XgoGeOLn9uwpC.findall('source src="http(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if c0cDhidBlOn7:
		c0cDhidBlOn7 = c0cDhidBlOn7[0]
		if 'Referer=' not in c0cDhidBlOn7: c0cDhidBlOn7 = c0cDhidBlOn7+'|Referer=https://www.arabic-toons.com'
		XFj0lV5yMtS67EwbCJ9oO.append(c0cDhidBlOn7+'?named=__embed')
	import r0y4XTKznF
	r0y4XTKznF.noHliPXkcg3pJTdSauCvm5sU(XFj0lV5yMtS67EwbCJ9oO,UkXlAzsMcamKJrEIgnxi6bWh,'video',url)
	return
def z4hetAJw3NaT9ROjG6xbZ5CHlW81(search):
	search,EL8zUgbXheot,showDialogs = qbIcHCMdkFKn21e(search)
	if search==cdZKMn68Pzg4: search = BzkmLuvJD9n25Pg()
	if search==cdZKMn68Pzg4: return
	search = search.replace(VBpIH2QSmvDGlA6TO3e,'%20')
	url = cDTdfqVAF0BLGiX364IEwaZbr+'/search_results.php?q='+search
	GDQUH4fN02sIt81mAcY(url,'search')
	return
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'ARABICTOONS-SEARCH-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)">(.*?)<',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	for c0cDhidBlOn7,title in items:
		c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr+KCQExdbYFqM+c0cDhidBlOn7
		title = title.strip(VBpIH2QSmvDGlA6TO3e)
		if type=='m': zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,732)
		else: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,733)
	return
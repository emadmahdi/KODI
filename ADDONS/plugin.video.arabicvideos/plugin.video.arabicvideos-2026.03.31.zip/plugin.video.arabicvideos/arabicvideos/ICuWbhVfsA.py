# -*- coding: utf-8 -*-
from RgJNGc7YMP import *
UkXlAzsMcamKJrEIgnxi6bWh = 'SHIAVOICE'
nc3GLkA65oxOd = '_SHV_'
cDTdfqVAF0BLGiX364IEwaZbr = USuRxnPlV5.SITESURLS[UkXlAzsMcamKJrEIgnxi6bWh][0]
headers = {'User-Agent':None}
def HHN5EpbszV3iA2m89hGSQjaPgUZy(mode,url,text):
	if   mode==310: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = kUq58vC7x9hWma164JejMKQ()
	elif mode==311: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = GDQUH4fN02sIt81mAcY(url)
	elif mode==312: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = RPZbqous7rtdy56LeI18Cv04AKHW(url)
	elif mode==313: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = iiHq3hbw1oZ8(url)
	elif mode==314: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = rDMwBgVzEW(text)
	elif mode==319: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = z4hetAJw3NaT9ROjG6xbZ5CHlW81(text)
	else: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = False
	return xsGUcR3ef6glKY5hQwpFXEaSt2mrIz
def kUq58vC7x9hWma164JejMKQ():
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'بحث في الموقع',cdZKMn68Pzg4,319,cdZKMn68Pzg4,cdZKMn68Pzg4,'_REMEMBERRESULTS_')
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(r43t1YI9deXA5N,'GET',cDTdfqVAF0BLGiX364IEwaZbr,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'SHIAVOICE-MENU-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('id="menulinks"(.*?)</ul>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
	zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('<h5>(.*?)</h5>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL|ffUFBJQ57j2XgoGeOLn9uwpC.IGNORECASE)
	for udsnZkQyF3Air1Jfa in range(len(items)):
		title = items[udsnZkQyF3Air1Jfa].strip(VBpIH2QSmvDGlA6TO3e)
		zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+title,cDTdfqVAF0BLGiX364IEwaZbr,314,cdZKMn68Pzg4,cdZKMn68Pzg4,str(udsnZkQyF3Air1Jfa+1))
	zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+'مقاطع شهر',cDTdfqVAF0BLGiX364IEwaZbr,314,cdZKMn68Pzg4,cdZKMn68Pzg4,'0')
	zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?<B>(.*?)</B>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	for c0cDhidBlOn7,title in items:
		c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr+KCQExdbYFqM+c0cDhidBlOn7
		zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+title,c0cDhidBlOn7,311)
	return OO1cj2REUZHJ8x5V
def rDMwBgVzEW(udsnZkQyF3Air1Jfa):
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(AlfMBJhUD65to2WrQcb,'GET',cDTdfqVAF0BLGiX364IEwaZbr,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'SHIAVOICE-LATEST-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	if udsnZkQyF3Air1Jfa=='0':
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="tab-content"(.*?)</table>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?title="(.*?)".*?</i>(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,name,title in items:
			c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr+KCQExdbYFqM+c0cDhidBlOn7
			title = title.strip(VBpIH2QSmvDGlA6TO3e)
			name = name.strip(VBpIH2QSmvDGlA6TO3e)
			title = title+' ('+name+')'
			zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,312)
	elif udsnZkQyF3Air1Jfa in ['1','2','3']:
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('(<h5>.*?)<div class="col-lg',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		veaXrOohS3UZupI09bHgx7mG2Y5d = int(udsnZkQyF3Air1Jfa)-1
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[veaXrOohS3UZupI09bHgx7mG2Y5d]
		if udsnZkQyF3Air1Jfa=='1': items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?src="(.*?)".*?<strong>(.*?)<.*?</i>(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		else: items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?src="(.*?)".*?<strong>(.*?)<.*?href=".*?">(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,title,name in items:
			y90BoFz8MA1ZThaSC2ILXHiK3OY6w = cDTdfqVAF0BLGiX364IEwaZbr+KCQExdbYFqM+y90BoFz8MA1ZThaSC2ILXHiK3OY6w
			c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr+KCQExdbYFqM+c0cDhidBlOn7
			title = title.strip(VBpIH2QSmvDGlA6TO3e)
			name = name.strip(VBpIH2QSmvDGlA6TO3e)
			title = title+' ('+name+')'
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,311,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
	elif udsnZkQyF3Air1Jfa in ['4','5','6']:
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('(<h5>.*?)</table>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		udsnZkQyF3Air1Jfa = int(udsnZkQyF3Air1Jfa)-4
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[udsnZkQyF3Air1Jfa]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('src="(.*?)".*?href="(.*?)".*?title="(.*?)".*?<strong.*?>(.*?)</strong>.*?-cell">(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for y90BoFz8MA1ZThaSC2ILXHiK3OY6w,c0cDhidBlOn7,ARoy9XWOZtYka6Busejr,title,wRbgsDELJBq9odiKFIu6 in items:
			y90BoFz8MA1ZThaSC2ILXHiK3OY6w = cDTdfqVAF0BLGiX364IEwaZbr+KCQExdbYFqM+y90BoFz8MA1ZThaSC2ILXHiK3OY6w
			c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr+KCQExdbYFqM+c0cDhidBlOn7
			title = title.strip(VBpIH2QSmvDGlA6TO3e)
			ARoy9XWOZtYka6Busejr = ARoy9XWOZtYka6Busejr.strip(VBpIH2QSmvDGlA6TO3e)
			wRbgsDELJBq9odiKFIu6 = wRbgsDELJBq9odiKFIu6.strip(VBpIH2QSmvDGlA6TO3e)
			if ARoy9XWOZtYka6Busejr: name = ARoy9XWOZtYka6Busejr
			else: name = wRbgsDELJBq9odiKFIu6
			title = title+' ('+name+')'
			zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,312,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
	return
def GDQUH4fN02sIt81mAcY(url):
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'SHIAVOICE-TITLES-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('ibox-heading"(.*?)class="float-right',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
	if 'catsum-mobile' in KdWauEhgN6OQzjRVm1ro8tkB3:
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('src="(.*?)".*?href="(.*?)".*?<strong>(.*?)</strong>.*?catsum-mobile">(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if items:
			for y90BoFz8MA1ZThaSC2ILXHiK3OY6w,c0cDhidBlOn7,title,count in items:
				y90BoFz8MA1ZThaSC2ILXHiK3OY6w = cDTdfqVAF0BLGiX364IEwaZbr+KCQExdbYFqM+y90BoFz8MA1ZThaSC2ILXHiK3OY6w
				c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr+KCQExdbYFqM+c0cDhidBlOn7
				count = count.replace(' الصوتية: ',':')
				title = title.strip(VBpIH2QSmvDGlA6TO3e)
				title = title+' ('+count+')'
				zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,311,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
	else:
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('" href="(.*?)".*?</i>(.*?)</a>.*?">(.*?)<.*?<span.*?<span.*?<span.*?">(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,title,Ug3QFyTrK2SGpHajeh6kNlwsI87bx,Kr1n9xq5TY4gohlVdNEu0b in items:
			if title==cdZKMn68Pzg4 or Ug3QFyTrK2SGpHajeh6kNlwsI87bx==cdZKMn68Pzg4: continue
			c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr+KCQExdbYFqM+c0cDhidBlOn7
			title = title+' ('+Kr1n9xq5TY4gohlVdNEu0b+')'
			zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,312)
	if not items: yIZWSuMpvs3(OO1cj2REUZHJ8x5V)
	return
def yIZWSuMpvs3(OO1cj2REUZHJ8x5V):
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="ibox-content"(.*?)class="pagination',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
	items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(http.*?)".*?</i>(.*?)<.*?cell">(.*?)<.*?cell">(.*?)<.*?cell">(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	for c0cDhidBlOn7,title,name,count,Kr1n9xq5TY4gohlVdNEu0b in items:
		c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr+KCQExdbYFqM+c0cDhidBlOn7
		title = title.strip(VBpIH2QSmvDGlA6TO3e)
		name = name.strip(VBpIH2QSmvDGlA6TO3e)
		title = title+' ('+name+')'
		zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,312,cdZKMn68Pzg4,Kr1n9xq5TY4gohlVdNEu0b)
	return
def iiHq3hbw1oZ8(url):
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'SHIAVOICE-SEARCH_ITEMS-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="ibox-content p-1"(.*?)class="ibox-content"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if not ppvsMqCHf8SEzxQg:
		GDQUH4fN02sIt81mAcY(url)
		return
	KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
	items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?<strong>(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	for c0cDhidBlOn7,title in items:
		c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr+KCQExdbYFqM+c0cDhidBlOn7
		title = title.strip(VBpIH2QSmvDGlA6TO3e)
		if '/play-' in c0cDhidBlOn7: zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,312)
		else: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,311)
	return
def RPZbqous7rtdy56LeI18Cv04AKHW(url):
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(AlfMBJhUD65to2WrQcb,'GET',url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'SHIAVOICE-PLAY-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	c0cDhidBlOn7 = ffUFBJQ57j2XgoGeOLn9uwpC.findall('<audio.*?src="(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if not c0cDhidBlOn7: c0cDhidBlOn7 = ffUFBJQ57j2XgoGeOLn9uwpC.findall('<video.*?src="(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr+c0cDhidBlOn7[0]
	bmgwWLk3er(c0cDhidBlOn7,UkXlAzsMcamKJrEIgnxi6bWh,'video')
	return
def z4hetAJw3NaT9ROjG6xbZ5CHlW81(search):
	search,EL8zUgbXheot,showDialogs = qbIcHCMdkFKn21e(search)
	if search==cdZKMn68Pzg4: search = BzkmLuvJD9n25Pg()
	if search==cdZKMn68Pzg4: return
	search = search.replace(VBpIH2QSmvDGlA6TO3e,'+')
	IoWXuJK3h8M6 = ['&t=a','&t=c','&t=s']
	if showDialogs:
		pzEu5yaMfHkwJRNLUnW = ['قارئ','إصدار / مجلد','مقطع الصوتي']
		AS6jLpMwW5Ql3kUFNfT = NAfHLMC8Ip64FmT7l5oJWXaq3hK('موقع صوت الشيعة - أختر البحث', pzEu5yaMfHkwJRNLUnW)
		if AS6jLpMwW5Ql3kUFNfT == -1: return
	elif '_SHIAVOICE-PERSONS_' in EL8zUgbXheot: AS6jLpMwW5Ql3kUFNfT = 0
	elif '_SHIAVOICE-ALBUMS_' in EL8zUgbXheot: AS6jLpMwW5Ql3kUFNfT = 1
	elif '_SHIAVOICE-AUDIOS_' in EL8zUgbXheot: AS6jLpMwW5Ql3kUFNfT = 2
	else: return
	type = IoWXuJK3h8M6[AS6jLpMwW5Ql3kUFNfT]
	url = cDTdfqVAF0BLGiX364IEwaZbr+'/search.php?q='+search+type
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'SHIAVOICE-SEARCH-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="ibox-content"(.*?)class="ibox-content"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		if AS6jLpMwW5Ql3kUFNfT in [0,1]:
			items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?src="(.*?)".*?href=".*?">(.*?)<.*?">(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			for c0cDhidBlOn7,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,title,name in items:
				title = title.strip(VBpIH2QSmvDGlA6TO3e)
				name = name.strip(VBpIH2QSmvDGlA6TO3e)
				title = title+' ('+name+')'
				zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,313,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
		elif AS6jLpMwW5Ql3kUFNfT==2:
			items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(http.*?)".*?</i>(.*?)</a></td><td>(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			for c0cDhidBlOn7,title,name in items:
				title = title.strip(VBpIH2QSmvDGlA6TO3e)
				name = name.strip(VBpIH2QSmvDGlA6TO3e)
				title = title+' ('+name+')'
				zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,312)
	return
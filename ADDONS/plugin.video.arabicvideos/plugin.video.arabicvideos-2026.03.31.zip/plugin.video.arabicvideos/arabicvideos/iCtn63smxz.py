# -*- coding: utf-8 -*-
from RgJNGc7YMP import *
UkXlAzsMcamKJrEIgnxi6bWh = 'FAJERSHOW'
nc3GLkA65oxOd = '_FJS_'
cDTdfqVAF0BLGiX364IEwaZbr = USuRxnPlV5.SITESURLS[UkXlAzsMcamKJrEIgnxi6bWh][0]
cJWUPuDGM0Yybv5a9KnIrVzhH78 = ['التصنيفات','انشاء حساب','طلبات الزوّار']
def HHN5EpbszV3iA2m89hGSQjaPgUZy(mode,url,text):
	if   mode==390: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = kUq58vC7x9hWma164JejMKQ()
	elif mode==391: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = GDQUH4fN02sIt81mAcY(url,text)
	elif mode==392: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = RPZbqous7rtdy56LeI18Cv04AKHW(url)
	elif mode==393: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = yIZWSuMpvs3(url)
	elif mode==399: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = z4hetAJw3NaT9ROjG6xbZ5CHlW81(text)
	else: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = False
	return xsGUcR3ef6glKY5hQwpFXEaSt2mrIz
def kUq58vC7x9hWma164JejMKQ():
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'بحث في الموقع',cdZKMn68Pzg4,399,cdZKMn68Pzg4,cdZKMn68Pzg4,'_REMEMBERRESULTS_')
	zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(r43t1YI9deXA5N,'GET',cDTdfqVAF0BLGiX364IEwaZbr,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'FAJERSHOW-MENU-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('<header>.*?<h2>(.*?)<',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	for udsnZkQyF3Air1Jfa in range(len(items)):
		title = items[udsnZkQyF3Air1Jfa]
		zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+title,cDTdfqVAF0BLGiX364IEwaZbr,391,cdZKMn68Pzg4,cdZKMn68Pzg4,'latest'+str(udsnZkQyF3Air1Jfa))
	KdWauEhgN6OQzjRVm1ro8tkB3 = cdZKMn68Pzg4
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="menu"(.*?)id="contenedor"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg: KdWauEhgN6OQzjRVm1ro8tkB3 += ppvsMqCHf8SEzxQg[0]
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"header-container"(.*?)</div>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg: KdWauEhgN6OQzjRVm1ro8tkB3 += ppvsMqCHf8SEzxQg[0]
	items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="([^"]*)">(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	XMkp5KNroQDVvUx73j9qus = True
	for c0cDhidBlOn7,title in items:
		title = gbd90SjF2mZqf81IRDaTwJkWu(title)
		if title not in cJWUPuDGM0Yybv5a9KnIrVzhH78:
			zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+title,c0cDhidBlOn7,391)
	return OO1cj2REUZHJ8x5V
def GDQUH4fN02sIt81mAcY(url,CvSX7Etpz80eGlT1brgWZkJ):
	KdWauEhgN6OQzjRVm1ro8tkB3,items = [],[]
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'FAJERSHOW-TITLES-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	if CvSX7Etpz80eGlT1brgWZkJ=='search':
		KdWauEhgN6OQzjRVm1ro8tkB3 = OO1cj2REUZHJ8x5V
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?src="(.*?)".*?<h4>(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	elif CvSX7Etpz80eGlT1brgWZkJ in ['featured_movies','featured_tvshows']:
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="content"(.*?)id="archive-content"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if ppvsMqCHf8SEzxQg: KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
	elif CvSX7Etpz80eGlT1brgWZkJ=='top_imdb_movies':
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall("class='top-imdb-list tleft(.*?)class='top-imdb-list tright",OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if ppvsMqCHf8SEzxQg:
			KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
			items = ffUFBJQ57j2XgoGeOLn9uwpC.findall("src='(.*?)'.*?href='(.*?)'>(.*?)<",KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	elif CvSX7Etpz80eGlT1brgWZkJ=='top_imdb_series':
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall("class='top-imdb-list tright(.*?)footer",OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if ppvsMqCHf8SEzxQg:
			KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
			items = ffUFBJQ57j2XgoGeOLn9uwpC.findall("src='(.*?)'.*?href='(.*?)'>(.*?)<",KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	elif CvSX7Etpz80eGlT1brgWZkJ=='sider':
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="widget(.*?)class="widget',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		JJA9R5FEWOzQbDd8eowj3cv4 = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?src="(.*?)".*?<h3>(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		pcX7zxFRmsADwUr,R5G4cMtH1s7yLifBl,lycT0JB1noerD5YANK2PbHa8QVM = zip(*JJA9R5FEWOzQbDd8eowj3cv4)
		items = zip(R5G4cMtH1s7yLifBl,pcX7zxFRmsADwUr,lycT0JB1noerD5YANK2PbHa8QVM)
	elif CvSX7Etpz80eGlT1brgWZkJ=='randoms':
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('id="slider-movies-tvshows"(.*?)<header>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	elif 'latest' in CvSX7Etpz80eGlT1brgWZkJ:
		udsnZkQyF3Air1Jfa = int(CvSX7Etpz80eGlT1brgWZkJ[-1:])
		OO1cj2REUZHJ8x5V = OO1cj2REUZHJ8x5V.replace('<header>','<end><start>')
		OO1cj2REUZHJ8x5V = OO1cj2REUZHJ8x5V.replace('</div></div></div>','</div></div></div><end>')
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('<start>(.*?)<end>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[udsnZkQyF3Air1Jfa]
		if udsnZkQyF3Air1Jfa==6:
			JJA9R5FEWOzQbDd8eowj3cv4 = ffUFBJQ57j2XgoGeOLn9uwpC.findall('src="(.*?)" alt="(.*?)".*?href="(.*?)"',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			R5G4cMtH1s7yLifBl,lycT0JB1noerD5YANK2PbHa8QVM,pcX7zxFRmsADwUr = zip(*JJA9R5FEWOzQbDd8eowj3cv4)
			items = zip(R5G4cMtH1s7yLifBl,pcX7zxFRmsADwUr,lycT0JB1noerD5YANK2PbHa8QVM)
	else:
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"archive-grid"(.*?)</main>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if ppvsMqCHf8SEzxQg:
			KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
	if not items: items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?src="(.*?)".*?<h3>(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	KRmzvoWYyxfXw37SEh1Q = []
	for c0cDhidBlOn7,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,title in items:
		if 'src=' in title: continue
		if 'serie' in title:
			title = ffUFBJQ57j2XgoGeOLn9uwpC.findall('^(.*?)<.*?serie">(.*?)<',title,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			title = title[0][1]
			if title in KRmzvoWYyxfXw37SEh1Q: continue
			KRmzvoWYyxfXw37SEh1Q.append(title)
			title = '_MOD_'+title
		UHXfFEWmlxMAnzju4 = ffUFBJQ57j2XgoGeOLn9uwpC.findall('^(.*?)<',title,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if UHXfFEWmlxMAnzju4: title = UHXfFEWmlxMAnzju4[0]
		title = gbd90SjF2mZqf81IRDaTwJkWu(title)
		if '/tvshows/' in c0cDhidBlOn7: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,393,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
		elif '/episodes/' in c0cDhidBlOn7: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,393,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
		elif '/seasons/' in c0cDhidBlOn7: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,393,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
		elif '/collection/' in c0cDhidBlOn7: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,391,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
		else: zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,392,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
	if CvSX7Etpz80eGlT1brgWZkJ not in ['featured_movies','featured_tvshows']:
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"archive-pagination"(.*?)</div>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if ppvsMqCHf8SEzxQg:
			KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
			items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="([^"]*)">(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			for c0cDhidBlOn7,title in items:
				zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'صفحة '+title,c0cDhidBlOn7,391,cdZKMn68Pzg4,cdZKMn68Pzg4,CvSX7Etpz80eGlT1brgWZkJ)
	return
def yIZWSuMpvs3(url):
	wRlW4txQshKmeXdO7zABrLPT1GbZ0 = CxlbPZwGTcH87e1sWhfSIz29uRUEpV(url,'url')
	url = url.replace(wRlW4txQshKmeXdO7zABrLPT1GbZ0,cDTdfqVAF0BLGiX364IEwaZbr)
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'FAJERSHOW-EPISODES-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	eVdYQAPy2Dm = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="C rated".*?>(.*?)<',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if eVdYQAPy2Dm and bMOpKuUkQ5J2(UkXlAzsMcamKJrEIgnxi6bWh,url,eVdYQAPy2Dm): return
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"season-episodes"(.*?)</section>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="([^"]*)".*?src="([^"]*)".*?<h4>(.*?)</h4>''',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,title in items:
			zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,392,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
	return
def RPZbqous7rtdy56LeI18Cv04AKHW(url):
	url = url.replace('//show.alfajertv.com/','//fajer.show/')
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'FAJERSHOW-PLAY-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	if W5domCu6XrQUFkiPpa3bNLtHglG:
		try: OO1cj2REUZHJ8x5V = OO1cj2REUZHJ8x5V.decode(vczMIlkCAh2u10B3,'ignore')
		except: pass
	eVdYQAPy2Dm = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="C rated".*?>(.*?)<',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if eVdYQAPy2Dm and bMOpKuUkQ5J2(UkXlAzsMcamKJrEIgnxi6bWh,url,eVdYQAPy2Dm): return
	pcX7zxFRmsADwUr = []
	PTsY9XSpQFhGuxtvJk74oV3fwdWeaE = ffUFBJQ57j2XgoGeOLn9uwpC.findall("postId = (\d+);var postType = '(\a+)';",OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if PTsY9XSpQFhGuxtvJk74oV3fwdWeaE: w6ImbV0vxLgs9NoMXJ42cO8alAd,jPOL1Ui6k5QoadbrNIlSDfcs = PTsY9XSpQFhGuxtvJk74oV3fwdWeaE[0]
	else: w6ImbV0vxLgs9NoMXJ42cO8alAd,jPOL1Ui6k5QoadbrNIlSDfcs = cdZKMn68Pzg4,cdZKMn68Pzg4
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"servers-list"(.*?)</div>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('data-server="(.*?)".*?"server-name">(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for oGWbQKmTdD5OE7nlS,title in items:
			c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr+'/wp-admin/admin-ajax.php?action=doo_player_ajax&post='+w6ImbV0vxLgs9NoMXJ42cO8alAd+'&nume='+oGWbQKmTdD5OE7nlS+'&type='+jPOL1Ui6k5QoadbrNIlSDfcs
			c0cDhidBlOn7 = c0cDhidBlOn7+'?named='+title+'__watch'
			pcX7zxFRmsADwUr.append(c0cDhidBlOn7)
	if 0 and ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('''img src=["'](.*?)["'].*?href=["'](.*?)["'].*?["']quality["']>(.*?)<.*?<td>(.*?)<''',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for y90BoFz8MA1ZThaSC2ILXHiK3OY6w,c0cDhidBlOn7,l1MCIuwhAELbO2eJ96kNta7rp0B,GFskvRIgwN5OSx in items:
			if '=' in y90BoFz8MA1ZThaSC2ILXHiK3OY6w:
				IXftuDQ1RVyoJS2aHOwsc96k = y90BoFz8MA1ZThaSC2ILXHiK3OY6w.split('=')[1]
				title = CxlbPZwGTcH87e1sWhfSIz29uRUEpV(IXftuDQ1RVyoJS2aHOwsc96k,'host')
			else: title = cdZKMn68Pzg4
			title = GFskvRIgwN5OSx+VBpIH2QSmvDGlA6TO3e+title
			c0cDhidBlOn7 = c0cDhidBlOn7+'?named='+title+'__download____'+l1MCIuwhAELbO2eJ96kNta7rp0B
			pcX7zxFRmsADwUr.append(c0cDhidBlOn7)
	import r0y4XTKznF
	r0y4XTKznF.noHliPXkcg3pJTdSauCvm5sU(pcX7zxFRmsADwUr,UkXlAzsMcamKJrEIgnxi6bWh,'video',url)
	return
def z4hetAJw3NaT9ROjG6xbZ5CHlW81(search):
	search,EL8zUgbXheot,showDialogs = qbIcHCMdkFKn21e(search)
	if search==cdZKMn68Pzg4: search = BzkmLuvJD9n25Pg()
	if search==cdZKMn68Pzg4: return
	search = search.replace(VBpIH2QSmvDGlA6TO3e,'+')
	url = cDTdfqVAF0BLGiX364IEwaZbr+'/wp-admin/admin-ajax.php?action=fshow_live_search&s='+search
	GDQUH4fN02sIt81mAcY(url,'search')
	return
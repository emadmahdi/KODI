# -*- coding: utf-8 -*-
from RgJNGc7YMP import *
UkXlAzsMcamKJrEIgnxi6bWh = 'CIMAABDO'
nc3GLkA65oxOd = '_ABD_'
cDTdfqVAF0BLGiX364IEwaZbr = USuRxnPlV5.SITESURLS[UkXlAzsMcamKJrEIgnxi6bWh][0]
cJWUPuDGM0Yybv5a9KnIrVzhH78 = ['الرئيسية','افلام للكبار فقط +18']
def HHN5EpbszV3iA2m89hGSQjaPgUZy(mode,url,text):
	if   mode==550: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = kUq58vC7x9hWma164JejMKQ()
	elif mode==551: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = GDQUH4fN02sIt81mAcY(url,text)
	elif mode==552: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = RPZbqous7rtdy56LeI18Cv04AKHW(url)
	elif mode==553: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = yIZWSuMpvs3(url)
	elif mode==559: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = z4hetAJw3NaT9ROjG6xbZ5CHlW81(text)
	else: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = False
	return xsGUcR3ef6glKY5hQwpFXEaSt2mrIz
def kUq58vC7x9hWma164JejMKQ():
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',cDTdfqVAF0BLGiX364IEwaZbr+'/home',cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'CIMAABDO-MENU-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	u1P73L0UmkA4eaIBbCgZfrvRtJ = CxlbPZwGTcH87e1sWhfSIz29uRUEpV(cDTdfqVAF0BLGiX364IEwaZbr,'url')
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'بحث في الموقع',cdZKMn68Pzg4,559,cdZKMn68Pzg4,cdZKMn68Pzg4,'_REMEMBERRESULTS_')
	zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'اخترنا لك',u1P73L0UmkA4eaIBbCgZfrvRtJ+'/home',551,cdZKMn68Pzg4,cdZKMn68Pzg4,'featured')
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('main-content(.*?)</ul>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
	items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('data-name="(.*?)".*?</i>(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	for w3wLtqKIc0,title in items:
		c0cDhidBlOn7 = u1P73L0UmkA4eaIBbCgZfrvRtJ+'/ajax/getItem?item='+w3wLtqKIc0+'&Ajax=1'
		zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+title,c0cDhidBlOn7,551)
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"nav-main"(.*?)</nav>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
	items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)">(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	for c0cDhidBlOn7,title in items:
		if c0cDhidBlOn7=='#': continue
		if title in cJWUPuDGM0Yybv5a9KnIrVzhH78: continue
		if 'مسلسل ' in title: continue
		if 'أحدث' in title: zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+title,c0cDhidBlOn7,551)
	zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	for c0cDhidBlOn7,title in items:
		if c0cDhidBlOn7=='#': continue
		if title in cJWUPuDGM0Yybv5a9KnIrVzhH78: continue
		if 'مسلسل ' in title: continue
		if 'أحدث' not in title: zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+title,c0cDhidBlOn7,551)
	return
def GDQUH4fN02sIt81mAcY(url,w3wLtqKIc0=cdZKMn68Pzg4):
	items = []
	if '/ajax/getItem' in url or '/ajax/loadMore' in url:
		HOCWKhxITtulVGX,H3F607d1jsXEnMvor2 = sRAznbuQ5jiN09o4V8tpEYSlG7fe(url)
		npaJqziQ13tIH0hLjDdB2cWX7uUMPR = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'POST',HOCWKhxITtulVGX,H3F607d1jsXEnMvor2,npaJqziQ13tIH0hLjDdB2cWX7uUMPR,cdZKMn68Pzg4,cdZKMn68Pzg4,'CIMAABDO-TITLES-1st')
		OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
		ppvsMqCHf8SEzxQg = [OO1cj2REUZHJ8x5V]
	else:
		Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'CIMAABDO-TITLES-2nd')
		OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
		if w3wLtqKIc0=='featured':
			ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"container"(.*?)"container"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
			items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="([^"]*)" title="([^"]*)".*?src="(.*?)"',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		elif '"section-post mb-10"' in OO1cj2REUZHJ8x5V:
			ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"section-post mb-10"(.*?)"container"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		else:
			ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('<article(.*?)"pagination"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if not ppvsMqCHf8SEzxQg: return
	KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
	if not items:
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="([^"]*)" title="([^"]*)".*?data-original="(.*?)"',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if not items: items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="([^"]*)" title="([^"]*)".*?src="(.*?)"',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	KRmzvoWYyxfXw37SEh1Q = []
	rgWUvoaJnZARc375bjQ = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for c0cDhidBlOn7,title,y90BoFz8MA1ZThaSC2ILXHiK3OY6w in items:
		c0cDhidBlOn7 = NLqxoZ37dYf0awrsIE(c0cDhidBlOn7).strip(KCQExdbYFqM)
		E0w56WHxZPYGVvnTQ4O2t1C8DAjq = ffUFBJQ57j2XgoGeOLn9uwpC.findall('(.*?) الحلقة \d+',title,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if 'سلاسل' not in url and any(value in title for value in rgWUvoaJnZARc375bjQ):
			zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,552,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
		elif E0w56WHxZPYGVvnTQ4O2t1C8DAjq and 'الحلقة' in title:
			title = '_MOD_' + E0w56WHxZPYGVvnTQ4O2t1C8DAjq[0]
			if title not in KRmzvoWYyxfXw37SEh1Q:
				zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,553,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
				KRmzvoWYyxfXw37SEh1Q.append(title)
		elif '/movies/' in c0cDhidBlOn7:
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,551,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
		else: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,553,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
	if w3wLtqKIc0==cdZKMn68Pzg4:
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"pagination"(.*?)<footer',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if ppvsMqCHf8SEzxQg:
			KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
			items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?>(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			for c0cDhidBlOn7,title in items:
				if c0cDhidBlOn7=="": continue
				if title!=cdZKMn68Pzg4: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'صفحة '+title,c0cDhidBlOn7,551)
	if '/ajax/getItem' in url or '/ajax/loadMore' in url:
		if '/ajax/getItem' in url:
			url = url.replace('/ajax/getItem','/ajax/loadMore')+'&offset=20'
		elif '/ajax/loadMore' in url:
			url,offset = url.split('&offset=')
			offset = int(offset)+20
			url = url+'&offset='+str(offset)
		zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'هناك المزيد',url,551)
	return
def yIZWSuMpvs3(url):
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'CIMAABDO-EPISODES-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	ptXc2zV0RhTb = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"getSeasonsBySeries(.*?)"container"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	ll9vYSyie5kwbR16U0a2K = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"list-episodes"(.*?)"container"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ptXc2zV0RhTb and '/series/' not in url:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ptXc2zV0RhTb[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="([^"]*)" title="([^"]*)".*?src="(.*?)"',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,title,y90BoFz8MA1ZThaSC2ILXHiK3OY6w in items:
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,553,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
	elif ll9vYSyie5kwbR16U0a2K:
		y90BoFz8MA1ZThaSC2ILXHiK3OY6w = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"image" src="(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		y90BoFz8MA1ZThaSC2ILXHiK3OY6w = y90BoFz8MA1ZThaSC2ILXHiK3OY6w[0]
		KdWauEhgN6OQzjRVm1ro8tkB3 = ll9vYSyie5kwbR16U0a2K[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="([^"]*)" title="([^"]*)"',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,title in items:
			zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,552,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
	return
def RPZbqous7rtdy56LeI18Cv04AKHW(url):
	N8jUpQxY0rhtDAzbG4kOs9X = url.replace('/movies/','/watch_movies/')
	N8jUpQxY0rhtDAzbG4kOs9X = N8jUpQxY0rhtDAzbG4kOs9X.replace('/episodes/','/watch_episodes/')
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',N8jUpQxY0rhtDAzbG4kOs9X,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'CIMAABDO-PLAY-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	u1P73L0UmkA4eaIBbCgZfrvRtJ = CxlbPZwGTcH87e1sWhfSIz29uRUEpV(N8jUpQxY0rhtDAzbG4kOs9X,'url')
	XFj0lV5yMtS67EwbCJ9oO = []
	c0cDhidBlOn7 = ffUFBJQ57j2XgoGeOLn9uwpC.findall('''<iframe.*?src=["'](.*?)["']''',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if c0cDhidBlOn7:
		c0cDhidBlOn7 = c0cDhidBlOn7[0]
		wRlW4txQshKmeXdO7zABrLPT1GbZ0 = CxlbPZwGTcH87e1sWhfSIz29uRUEpV(c0cDhidBlOn7,'url')
		XFj0lV5yMtS67EwbCJ9oO.append(c0cDhidBlOn7+'?named='+wRlW4txQshKmeXdO7zABrLPT1GbZ0+'__embed')
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"servers"(.*?)</ul>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		eaZTIfi39lq7WXOEYvS10VyJUGpnKc = ffUFBJQ57j2XgoGeOLn9uwpC.findall('postID = "(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		eaZTIfi39lq7WXOEYvS10VyJUGpnKc = eaZTIfi39lq7WXOEYvS10VyJUGpnKc[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall("getPlayer\('(.*?)'.*?</i>(.*?)</a>",KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if items:
			for wRlW4txQshKmeXdO7zABrLPT1GbZ0,title in items:
				title = title.replace(ssELJkeScrtni2,cdZKMn68Pzg4).strip(VBpIH2QSmvDGlA6TO3e)
				c0cDhidBlOn7 = u1P73L0UmkA4eaIBbCgZfrvRtJ+'/ajax/getPlayer?server='+wRlW4txQshKmeXdO7zABrLPT1GbZ0+'&postID='+eaZTIfi39lq7WXOEYvS10VyJUGpnKc+'&Ajax=1'
				c0cDhidBlOn7 = c0cDhidBlOn7+'?named='+title+'__watch'
				XFj0lV5yMtS67EwbCJ9oO.append(c0cDhidBlOn7)
		else:
			items = ffUFBJQ57j2XgoGeOLn9uwpC.findall("getPlayerByName\('(.*?)','(.*?)'.*?\"server\">(.*?)</a>",KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			if items:
				wRlW4txQshKmeXdO7zABrLPT1GbZ0,V2jxCNF1aLmtZbTMcdS3zpE4s5,title = items[0]
				c0cDhidBlOn7 = u1P73L0UmkA4eaIBbCgZfrvRtJ+'/ajax/getPlayerByName?server='+wRlW4txQshKmeXdO7zABrLPT1GbZ0+'&multipleServers='+V2jxCNF1aLmtZbTMcdS3zpE4s5+'&postID='+eaZTIfi39lq7WXOEYvS10VyJUGpnKc+'&Ajax=1'
				HOCWKhxITtulVGX,H3F607d1jsXEnMvor2 = sRAznbuQ5jiN09o4V8tpEYSlG7fe(c0cDhidBlOn7)
				npaJqziQ13tIH0hLjDdB2cWX7uUMPR = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
				Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'POST',HOCWKhxITtulVGX,H3F607d1jsXEnMvor2,npaJqziQ13tIH0hLjDdB2cWX7uUMPR,cdZKMn68Pzg4,cdZKMn68Pzg4,'CIMAABDO-PLAY-2nd')
				OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
				yYh4LlNT0HxR = ffUFBJQ57j2XgoGeOLn9uwpC.findall('''<iframe src=["'](.*?)["']''',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL|ffUFBJQ57j2XgoGeOLn9uwpC.IGNORECASE)
				cz5qCJd6O3g4ISxVa1EtQpysvGHPk = yYh4LlNT0HxR[0] if yYh4LlNT0HxR else cdZKMn68Pzg4
				if '/iframe/' in cz5qCJd6O3g4ISxVa1EtQpysvGHPk:
					Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',cz5qCJd6O3g4ISxVa1EtQpysvGHPk,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'CIMAABDO-PLAY-3rd')
					OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
					kkInC8uzOhXt5yAscRlrNLeBP = ffUFBJQ57j2XgoGeOLn9uwpC.findall('version&quot;:&quot;(.*?)&',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
					kkInC8uzOhXt5yAscRlrNLeBP = kkInC8uzOhXt5yAscRlrNLeBP[0]
					npaJqziQ13tIH0hLjDdB2cWX7uUMPR = {}
					npaJqziQ13tIH0hLjDdB2cWX7uUMPR['X-Inertia-Partial-Component'] = 'files/mirror/video'
					npaJqziQ13tIH0hLjDdB2cWX7uUMPR['X-Inertia'] = 'true'
					npaJqziQ13tIH0hLjDdB2cWX7uUMPR['X-Inertia-Partial-Data'] = 'streams'
					npaJqziQ13tIH0hLjDdB2cWX7uUMPR['X-Inertia-Version'] = kkInC8uzOhXt5yAscRlrNLeBP
					Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',cz5qCJd6O3g4ISxVa1EtQpysvGHPk,cdZKMn68Pzg4,npaJqziQ13tIH0hLjDdB2cWX7uUMPR,cdZKMn68Pzg4,cdZKMn68Pzg4,'CIMAABDO-PLAY-4th')
					OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
					zR1ohGZDkIY9iUFfPxy3 = lMeKd3hC6cmS('dict',OO1cj2REUZHJ8x5V)
					groups = zR1ohGZDkIY9iUFfPxy3['props']['streams']['data']
					for group in groups:
						l1MCIuwhAELbO2eJ96kNta7rp0B = group['label'].replace(' (source)',cdZKMn68Pzg4)
						V3VjdBakHCxZpSEgnF2QIUtm = group['mirrors']
						for jjh5GAJTkZm4We9UMl in V3VjdBakHCxZpSEgnF2QIUtm:
							wRlW4txQshKmeXdO7zABrLPT1GbZ0 = jjh5GAJTkZm4We9UMl['driver']
							c0cDhidBlOn7 = 'http:'+jjh5GAJTkZm4We9UMl['link']+'?named='+wRlW4txQshKmeXdO7zABrLPT1GbZ0+'__watch____'+l1MCIuwhAELbO2eJ96kNta7rp0B
							XFj0lV5yMtS67EwbCJ9oO.append(c0cDhidBlOn7)
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"downs"(.*?)</ul>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="([^"]*)" title="([^"]*)"',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,name in items:
			c0cDhidBlOn7 = c0cDhidBlOn7+'?named='+name+'__download'
			if 'http' not in c0cDhidBlOn7: c0cDhidBlOn7 = 'http:'+c0cDhidBlOn7
			XFj0lV5yMtS67EwbCJ9oO.append(c0cDhidBlOn7)
	import r0y4XTKznF
	r0y4XTKznF.noHliPXkcg3pJTdSauCvm5sU(XFj0lV5yMtS67EwbCJ9oO,UkXlAzsMcamKJrEIgnxi6bWh,'video',url)
	return
def z4hetAJw3NaT9ROjG6xbZ5CHlW81(search):
	search,EL8zUgbXheot,showDialogs = qbIcHCMdkFKn21e(search)
	if search==cdZKMn68Pzg4: search = BzkmLuvJD9n25Pg()
	if search==cdZKMn68Pzg4: return
	search = search.replace(VBpIH2QSmvDGlA6TO3e,'-')
	url = cDTdfqVAF0BLGiX364IEwaZbr+'/search/'+search+'.html'
	GDQUH4fN02sIt81mAcY(url)
	return
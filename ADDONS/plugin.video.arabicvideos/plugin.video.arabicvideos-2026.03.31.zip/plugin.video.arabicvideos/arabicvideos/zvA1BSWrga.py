# -*- coding: utf-8 -*-
from RgJNGc7YMP import *
UkXlAzsMcamKJrEIgnxi6bWh = 'GOOGLESEARCH'
nc3GLkA65oxOd = '_GOS_'
def HHN5EpbszV3iA2m89hGSQjaPgUZy(HHrpyfWjGC,kxY4EfTKobmQJ8OathHI53,JAYWBoz54tGw7O):
	if   HHrpyfWjGC==1010: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = kUq58vC7x9hWma164JejMKQ()
	elif HHrpyfWjGC==1011: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = fqaAoESGsPV(JAYWBoz54tGw7O)
	elif HHrpyfWjGC==1012: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = Nfqw62o4EOk(kxY4EfTKobmQJ8OathHI53,JAYWBoz54tGw7O)
	elif HHrpyfWjGC==1013: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = dyFxfXn4IO6USkT()
	elif HHrpyfWjGC==1014: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = KZY6gIARLMiWodVt4UOlEfH7a1Jk(kxY4EfTKobmQJ8OathHI53,JAYWBoz54tGw7O)
	elif HHrpyfWjGC==1015: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = Yv3KlEaZrcw1eT76Lyd4iXGbRC(JAYWBoz54tGw7O)
	elif HHrpyfWjGC==1016: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = dGIKc5mDW7UBFH(JAYWBoz54tGw7O)
	elif HHrpyfWjGC==1018: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = QmYldnu02bgeKTS8AhGNMXws4v(JAYWBoz54tGw7O)
	elif HHrpyfWjGC==1019: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = z4hetAJw3NaT9ROjG6xbZ5CHlW81(JAYWBoz54tGw7O,False)
	else: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = False
	return xsGUcR3ef6glKY5hQwpFXEaSt2mrIz
def kUq58vC7x9hWma164JejMKQ():
	zJLApFBcIhnSj('folder','بحث جوجل جديد',cdZKMn68Pzg4,1019)
	zJLApFBcIhnSj('link','كيف يعمل بحث جوجل','',1013)
	zJLApFBcIhnSj('link',Gzygq01Kcb9U3+'==== كلمات البحث المخزنة ===='+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	E7hMbtIzwl5DPsCQ60roqfGm = sZHYrLPog4wmuW0ECdc(TV08xYHA2ok,'dict','GLOBALSEARCH_SPLITTED_GOOGLE')
	if E7hMbtIzwl5DPsCQ60roqfGm:
		E7hMbtIzwl5DPsCQ60roqfGm = E7hMbtIzwl5DPsCQ60roqfGm['__SEQUENCED_COLUMNS__']
		for ohGe84MLmzaQXICbNvcVUkW in reversed(E7hMbtIzwl5DPsCQ60roqfGm):
			zJLApFBcIhnSj('folder',ohGe84MLmzaQXICbNvcVUkW,cdZKMn68Pzg4,1019,cdZKMn68Pzg4,cdZKMn68Pzg4,ohGe84MLmzaQXICbNvcVUkW)
	return
def QmYldnu02bgeKTS8AhGNMXws4v(search):
	z4hetAJw3NaT9ROjG6xbZ5CHlW81(search,True)
	XfABsbKWoLhI(ksTLSoVGg0ht)
	return
def z4hetAJw3NaT9ROjG6xbZ5CHlW81(search,hh245Ws8npGLlw=False):
	if search==cdZKMn68Pzg4: search = BzkmLuvJD9n25Pg()
	if search==cdZKMn68Pzg4: return
	OHkUL3XJYCcvux60qez4rp7h8dnty = search.replace(nc3GLkA65oxOd,cdZKMn68Pzg4).lower()
	Y012HUpOxCg3iMo8lnZWaE,idJ7xW8ImS,aqXRGIAu91v402tTBVixsN3Hj = [],[],[]
	if not hh245Ws8npGLlw:
		Y012HUpOxCg3iMo8lnZWaE = sZHYrLPog4wmuW0ECdc(TV08xYHA2ok,'list','GOOGLESEARCH_RESULTS',OHkUL3XJYCcvux60qez4rp7h8dnty)
		if Y012HUpOxCg3iMo8lnZWaE: idJ7xW8ImS,aqXRGIAu91v402tTBVixsN3Hj = Y012HUpOxCg3iMo8lnZWaE
	if hh245Ws8npGLlw or not Y012HUpOxCg3iMo8lnZWaE:
		import zBKTlNEfOC
		zBKTlNEfOC.BWmyO1TLnp7UXgh9b(OHkUL3XJYCcvux60qez4rp7h8dnty,'_GOOGLE',True)
		FFEDfor6qBp = itBLzjfYr7W15qUCnVIvocN9E36d(OHkUL3XJYCcvux60qez4rp7h8dnty)
		for HYBN2AQsjimSMgT8OvE3ynX67tJwR in FFEDfor6qBp:
			name,c0cDhidBlOn7,title,text,kPId2vNQ5a4i1ExgHUjqV,xgPSaoLzTlFtQD37M6HIEsWY = HYBN2AQsjimSMgT8OvE3ynX67tJwR
			if xgPSaoLzTlFtQD37M6HIEsWY in TZxtrcmqkHX5LpKwNvQ: idJ7xW8ImS.append(HYBN2AQsjimSMgT8OvE3ynX67tJwR)
			else: aqXRGIAu91v402tTBVixsN3Hj.append(HYBN2AQsjimSMgT8OvE3ynX67tJwR)
		idJ7xW8ImS = sorted(idJ7xW8ImS,reverse=ksTLSoVGg0ht,key=lambda key: key[nnsBpJv6XL3OzHoe4Vuhr])
		aqXRGIAu91v402tTBVixsN3Hj = sorted(aqXRGIAu91v402tTBVixsN3Hj,reverse=ksTLSoVGg0ht,key=lambda key: key[nnsBpJv6XL3OzHoe4Vuhr])
		uAkLQ7gEZaIBv6Fyn(TV08xYHA2ok,'GOOGLESEARCH_RESULTS',OHkUL3XJYCcvux60qez4rp7h8dnty,[idJ7xW8ImS,aqXRGIAu91v402tTBVixsN3Hj],tvpq3ilsT1ZYAenaVj09BC2d)
		uVOoSHfqe4WtiF(TV08xYHA2ok,'GLOBALSEARCH_DETAILED_GOOGLE',OHkUL3XJYCcvux60qez4rp7h8dnty)
		zBKTlNEfOC.BWmyO1TLnp7UXgh9b(OHkUL3XJYCcvux60qez4rp7h8dnty,'_GOOGLE',False)
		uVOoSHfqe4WtiF(TV08xYHA2ok,'GLOBALSEARCH_DIVIDED_GOOGLE',"%, '"+OHkUL3XJYCcvux60qez4rp7h8dnty+"')")
		if idJ7xW8ImS: NiWSoAmhdkQPlTpneyVzDO8tw9aL('','',OPEJxmUqr9wAX1i,'تم عمل بحث جوجل جديد وتم إيجاد\n\n'+str(len(idJ7xW8ImS))+'  مواقع')
		else: idJ7xW8ImS,aqXRGIAu91v402tTBVixsN3Hj = Tr6DepyM4GhLo1zKYBZ7(OHkUL3XJYCcvux60qez4rp7h8dnty,ksTLSoVGg0ht)
	zJLApFBcIhnSj('link','بحث جماعي لمواقع جوجل','search_sites_google',1012,cdZKMn68Pzg4,cdZKMn68Pzg4,OHkUL3XJYCcvux60qez4rp7h8dnty)
	zJLApFBcIhnSj('folder','بحث منفرد لمواقع جوجل',cdZKMn68Pzg4,1011,cdZKMn68Pzg4,cdZKMn68Pzg4,OHkUL3XJYCcvux60qez4rp7h8dnty)
	zJLApFBcIhnSj('link',Gzygq01Kcb9U3+'===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	zJLApFBcIhnSj('folder','نتائج البحث مفصلة - '+OHkUL3XJYCcvux60qez4rp7h8dnty,'opened_sites_google',1012,cdZKMn68Pzg4,cdZKMn68Pzg4,OHkUL3XJYCcvux60qez4rp7h8dnty)
	zJLApFBcIhnSj('folder','نتائج البحث مقسمة - '+OHkUL3XJYCcvux60qez4rp7h8dnty,'listed_sites_google',1012,cdZKMn68Pzg4,cdZKMn68Pzg4,OHkUL3XJYCcvux60qez4rp7h8dnty)
	zJLApFBcIhnSj('link',Gzygq01Kcb9U3+'===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	zJLApFBcIhnSj('folder','مواقع جوجل ('+str(len(idJ7xW8ImS))+') - '+OHkUL3XJYCcvux60qez4rp7h8dnty,'',1016,cdZKMn68Pzg4,cdZKMn68Pzg4,OHkUL3XJYCcvux60qez4rp7h8dnty)
	zJLApFBcIhnSj('link','إعادة بحث جوجل - '+OHkUL3XJYCcvux60qez4rp7h8dnty,'',1018,cdZKMn68Pzg4,cdZKMn68Pzg4,search)
	return
def dGIKc5mDW7UBFH(OHkUL3XJYCcvux60qez4rp7h8dnty):
	idJ7xW8ImS,aqXRGIAu91v402tTBVixsN3Hj = Tr6DepyM4GhLo1zKYBZ7(OHkUL3XJYCcvux60qez4rp7h8dnty)
	if not idJ7xW8ImS and not aqXRGIAu91v402tTBVixsN3Hj: return
	ggDUV5mrQL4nWtohPEA18suM2 = {}
	for name,c0cDhidBlOn7,title,text,kPId2vNQ5a4i1ExgHUjqV,xgPSaoLzTlFtQD37M6HIEsWY in idJ7xW8ImS: ggDUV5mrQL4nWtohPEA18suM2[xgPSaoLzTlFtQD37M6HIEsWY] = name,c0cDhidBlOn7,title,text,kPId2vNQ5a4i1ExgHUjqV,xgPSaoLzTlFtQD37M6HIEsWY
	bNRdCW4JEwY7T = list(ggDUV5mrQL4nWtohPEA18suM2.keys())
	import zBKTlNEfOC
	IvBkQW84Axbr2nC5FNKEcLRg = zBKTlNEfOC.RBbaFi3ZLnIgrfNOy0jU7kPQYp(bNRdCW4JEwY7T)
	for xgPSaoLzTlFtQD37M6HIEsWY in IvBkQW84Axbr2nC5FNKEcLRg:
		if isinstance(xgPSaoLzTlFtQD37M6HIEsWY,tuple):
			USuRxnPlV5.menuItemsLIST.append(xgPSaoLzTlFtQD37M6HIEsWY)
			continue
		name,c0cDhidBlOn7,title,text,kPId2vNQ5a4i1ExgHUjqV,xgPSaoLzTlFtQD37M6HIEsWY = ggDUV5mrQL4nWtohPEA18suM2[xgPSaoLzTlFtQD37M6HIEsWY]
		EsoNPCTO6a243HIqXh0R,KIOap9Wsnru,tcDxzmPhwuVGE9ls0n6g = hhHQ695ZrMo2bFnIJqt(xgPSaoLzTlFtQD37M6HIEsWY)
		zJLApFBcIhnSj('folder',tcDxzmPhwuVGE9ls0n6g+name,c0cDhidBlOn7,1014,kPId2vNQ5a4i1ExgHUjqV,'',xgPSaoLzTlFtQD37M6HIEsWY)
	zJLApFBcIhnSj('link',Gzygq01Kcb9U3+'===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	zJLApFBcIhnSj('link',Gzygq01Kcb9U3+'مواقع بجوجل غير موجودة بالبرنامج'+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,1015)
	aqXRGIAu91v402tTBVixsN3Hj = sorted(aqXRGIAu91v402tTBVixsN3Hj,reverse=ksTLSoVGg0ht,key=lambda key: key[nnsBpJv6XL3OzHoe4Vuhr])
	for name,c0cDhidBlOn7,title,text,kPId2vNQ5a4i1ExgHUjqV,xgPSaoLzTlFtQD37M6HIEsWY in aqXRGIAu91v402tTBVixsN3Hj:
		zJLApFBcIhnSj('link','_GOS_'+name,c0cDhidBlOn7,1015,kPId2vNQ5a4i1ExgHUjqV,'',xgPSaoLzTlFtQD37M6HIEsWY)
	return
def Tr6DepyM4GhLo1zKYBZ7(OHkUL3XJYCcvux60qez4rp7h8dnty,hhKD7GBPLWAlXvoeH2xRU0nFQ=IZQbmFzLHDtXfc):
	idJ7xW8ImS,aqXRGIAu91v402tTBVixsN3Hj = [],[]
	if hhKD7GBPLWAlXvoeH2xRU0nFQ:
		Y012HUpOxCg3iMo8lnZWaE = sZHYrLPog4wmuW0ECdc(TV08xYHA2ok,'list','GOOGLESEARCH_RESULTS',OHkUL3XJYCcvux60qez4rp7h8dnty)
		if Y012HUpOxCg3iMo8lnZWaE: idJ7xW8ImS,aqXRGIAu91v402tTBVixsN3Hj = Y012HUpOxCg3iMo8lnZWaE
	if not idJ7xW8ImS and not aqXRGIAu91v402tTBVixsN3Hj: NiWSoAmhdkQPlTpneyVzDO8tw9aL('','',OPEJxmUqr9wAX1i,'للأسف جوجل لم يجد مواقع فيها طلبك')
	return idJ7xW8ImS,aqXRGIAu91v402tTBVixsN3Hj
def Nfqw62o4EOk(ZZ7vkMQKEHSICXWdTgbj,OHkUL3XJYCcvux60qez4rp7h8dnty):
	idJ7xW8ImS,aqXRGIAu91v402tTBVixsN3Hj = Tr6DepyM4GhLo1zKYBZ7(OHkUL3XJYCcvux60qez4rp7h8dnty)
	if not idJ7xW8ImS and not aqXRGIAu91v402tTBVixsN3Hj: return
	tDh4SHzqau3Rk,F2WVblkoThJOPuZ = [],{}
	for name,c0cDhidBlOn7,title,text,kPId2vNQ5a4i1ExgHUjqV,xgPSaoLzTlFtQD37M6HIEsWY in idJ7xW8ImS:
		tDh4SHzqau3Rk.append(xgPSaoLzTlFtQD37M6HIEsWY)
		F2WVblkoThJOPuZ[xgPSaoLzTlFtQD37M6HIEsWY] = GyakToXN5Lf(text)
	import zBKTlNEfOC
	zBKTlNEfOC.VlDem3X2qRLW9EcxwFSa0(OHkUL3XJYCcvux60qez4rp7h8dnty,ZZ7vkMQKEHSICXWdTgbj,cdZKMn68Pzg4,tDh4SHzqau3Rk,F2WVblkoThJOPuZ)
	return
def fqaAoESGsPV(OHkUL3XJYCcvux60qez4rp7h8dnty):
	idJ7xW8ImS,aqXRGIAu91v402tTBVixsN3Hj = Tr6DepyM4GhLo1zKYBZ7(OHkUL3XJYCcvux60qez4rp7h8dnty)
	if not idJ7xW8ImS and not aqXRGIAu91v402tTBVixsN3Hj: return
	ggDUV5mrQL4nWtohPEA18suM2 = {}
	for name,c0cDhidBlOn7,title,text,kPId2vNQ5a4i1ExgHUjqV,xgPSaoLzTlFtQD37M6HIEsWY in idJ7xW8ImS:
		ggDUV5mrQL4nWtohPEA18suM2[xgPSaoLzTlFtQD37M6HIEsWY] = name,c0cDhidBlOn7,title,text,kPId2vNQ5a4i1ExgHUjqV,xgPSaoLzTlFtQD37M6HIEsWY
	bNRdCW4JEwY7T = list(ggDUV5mrQL4nWtohPEA18suM2.keys())
	import zBKTlNEfOC
	IvBkQW84Axbr2nC5FNKEcLRg = zBKTlNEfOC.RBbaFi3ZLnIgrfNOy0jU7kPQYp(bNRdCW4JEwY7T)
	for xgPSaoLzTlFtQD37M6HIEsWY in IvBkQW84Axbr2nC5FNKEcLRg:
		if isinstance(xgPSaoLzTlFtQD37M6HIEsWY,tuple):
			USuRxnPlV5.menuItemsLIST.append(xgPSaoLzTlFtQD37M6HIEsWY)
			continue
		name,c0cDhidBlOn7,title,text,kPId2vNQ5a4i1ExgHUjqV,xgPSaoLzTlFtQD37M6HIEsWY = ggDUV5mrQL4nWtohPEA18suM2[xgPSaoLzTlFtQD37M6HIEsWY]
		EsoNPCTO6a243HIqXh0R,KIOap9Wsnru,tcDxzmPhwuVGE9ls0n6g = hhHQ695ZrMo2bFnIJqt(xgPSaoLzTlFtQD37M6HIEsWY)
		text = GyakToXN5Lf(text)
		name = name+' - '+OHkUL3XJYCcvux60qez4rp7h8dnty
		zJLApFBcIhnSj('folder',tcDxzmPhwuVGE9ls0n6g+name,xgPSaoLzTlFtQD37M6HIEsWY,548,kPId2vNQ5a4i1ExgHUjqV,'',text)
	return
def GyakToXN5Lf(title):
	E0w56WHxZPYGVvnTQ4O2t1C8DAjq = ffUFBJQ57j2XgoGeOLn9uwpC.findall('(.*?) (الحلقة|حلقة)',title,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	UHXfFEWmlxMAnzju4 = E0w56WHxZPYGVvnTQ4O2t1C8DAjq[0][0] if E0w56WHxZPYGVvnTQ4O2t1C8DAjq else title
	UHXfFEWmlxMAnzju4 = UHXfFEWmlxMAnzju4.replace('مشاهدة اونلاين، فيديو، الإعلان، صور - السينما.كوم','').replace('- ‎عرب سيد - Arabseed','')
	UHXfFEWmlxMAnzju4 = UHXfFEWmlxMAnzju4.replace('- وى سيما wecima ماى سيما mycima - وي سيما','').replace('- فيديو Dailymotion','')
	UHXfFEWmlxMAnzju4 = UHXfFEWmlxMAnzju4.replace('الموسم','').replace('الموقع','').replace('- شوف نت','').replace('موسم','').replace('HD','')
	UHXfFEWmlxMAnzju4 = UHXfFEWmlxMAnzju4.replace('مشاهدة','').replace('نتائج البحث:','').replace('اونلاين','').replace('- سيما فور بي','')
	UHXfFEWmlxMAnzju4 = UHXfFEWmlxMAnzju4.replace('موقع','').replace('| اكوام','').replace('','').replace('','').replace('','').replace('','')
	UHXfFEWmlxMAnzju4 = UHXfFEWmlxMAnzju4.strip(' ').replace('    ',' ').replace('   ',' ').replace('  ',' ').replace('  ',' ')
	return UHXfFEWmlxMAnzju4
def itBLzjfYr7W15qUCnVIvocN9E36d(search):
	search = search.replace(VBpIH2QSmvDGlA6TO3e,'+')
	headers = {'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36 Edg/128.0.0.0'}
	url = 'https://www.google.com/search?hl=en&filter=1&imgSize=small&safe=active&q=-youtube+-instagram+-facebook+-tiktok+-elcinema+'+search
	HOCWKhxITtulVGX = url+'&start=0&num=100&tbm=vid&udm=7'
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(fS25N8gAZxpbnLi3srX7PJ,'GET',HOCWKhxITtulVGX,cdZKMn68Pzg4,headers,cdZKMn68Pzg4,cdZKMn68Pzg4,'GOOGLESEARCH-SEARCH-1st')
	if not Zty0AsgQ5jpkTh91OW.succeeded: return []
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	cRIytvuTnjrbZ2KiSEAgzoUXVl = YRESXadfbIy3khwqmL8WC.path.join(K5pmHUNSMri7k,'googlesearch')
	if not YRESXadfbIy3khwqmL8WC.path.exists(cRIytvuTnjrbZ2KiSEAgzoUXVl):
		try: YRESXadfbIy3khwqmL8WC.makedirs(cRIytvuTnjrbZ2KiSEAgzoUXVl)
		except: pass
	items = []
	akIvSitzr0mKe = ffUFBJQ57j2XgoGeOLn9uwpC.findall('jsname="UWckNb" href="(.*?)".*?<span.*?>(.*?).*?aria-label="(.*?)".*?src="(.*?)".*?class="cuFRh">(.*?)<',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if akIvSitzr0mKe:
		for KdWauEhgN6OQzjRVm1ro8tkB3 in akIvSitzr0mKe:
			c0cDhidBlOn7,title,text,fh6qmOxoiv1UPXZanLprDeMI8,name = KdWauEhgN6OQzjRVm1ro8tkB3
			fh6qmOxoiv1UPXZanLprDeMI8 = ''
			items.append([c0cDhidBlOn7,title,text,name,fh6qmOxoiv1UPXZanLprDeMI8])
	else:
		HOCWKhxITtulVGX = url+'&start=0&num=200'
		Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(fS25N8gAZxpbnLi3srX7PJ,'GET:SCRAPERS',HOCWKhxITtulVGX,cdZKMn68Pzg4,headers,cdZKMn68Pzg4,cdZKMn68Pzg4,'GOOGLESEARCH-SEARCH-2nd')
		if not Zty0AsgQ5jpkTh91OW.succeeded: return []
		OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
		akIvSitzr0mKe = ffUFBJQ57j2XgoGeOLn9uwpC.findall('(\[null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,".*?\]\])',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if not akIvSitzr0mKe: akIvSitzr0mKe = ffUFBJQ57j2XgoGeOLn9uwpC.findall('(\[None,None,None,None,None,None,None,None,None,None,None,None,None,None,None,None,None,".*?\]\])',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for KdWauEhgN6OQzjRVm1ro8tkB3 in akIvSitzr0mKe:
			KdWauEhgN6OQzjRVm1ro8tkB3 = lMeKd3hC6cmS('list',KdWauEhgN6OQzjRVm1ro8tkB3)
			if len(KdWauEhgN6OQzjRVm1ro8tkB3)>17:
				c0cDhidBlOn7 = KdWauEhgN6OQzjRVm1ro8tkB3[17]
				title,text,name,fh6qmOxoiv1UPXZanLprDeMI8 = KdWauEhgN6OQzjRVm1ro8tkB3[31][0:4]
				items.append([c0cDhidBlOn7,title,text,name,fh6qmOxoiv1UPXZanLprDeMI8])
	VjN95C7uYXSbGImWf,hgUHAlMnVoFue5f = [],[]
	for HYBN2AQsjimSMgT8OvE3ynX67tJwR in items:
		c0cDhidBlOn7,title,text,name,fh6qmOxoiv1UPXZanLprDeMI8 = HYBN2AQsjimSMgT8OvE3ynX67tJwR
		name = name.strip(' ')
		if not name: name = CxlbPZwGTcH87e1sWhfSIz29uRUEpV(c0cDhidBlOn7,'name')
		name = RQfVumjSLa16XNAp2d(name)
		if 'http://' in fh6qmOxoiv1UPXZanLprDeMI8 or 'https://' in fh6qmOxoiv1UPXZanLprDeMI8: kPId2vNQ5a4i1ExgHUjqV = fh6qmOxoiv1UPXZanLprDeMI8
		elif 'data:image/' in fh6qmOxoiv1UPXZanLprDeMI8 and ';base64,' in fh6qmOxoiv1UPXZanLprDeMI8:
			X8i7OYvbJj06TWp4M2lP5kC = ffUFBJQ57j2XgoGeOLn9uwpC.findall('data:image/(\w+);base64,',fh6qmOxoiv1UPXZanLprDeMI8)
			X8i7OYvbJj06TWp4M2lP5kC = X8i7OYvbJj06TWp4M2lP5kC[0]
			kPId2vNQ5a4i1ExgHUjqV = YRESXadfbIy3khwqmL8WC.path.join(cRIytvuTnjrbZ2KiSEAgzoUXVl,name+'.'+X8i7OYvbJj06TWp4M2lP5kC)
			if not YRESXadfbIy3khwqmL8WC.path.exists(kPId2vNQ5a4i1ExgHUjqV):
				fh6qmOxoiv1UPXZanLprDeMI8 = fh6qmOxoiv1UPXZanLprDeMI8.replace('\\u003d','=')
				fh6qmOxoiv1UPXZanLprDeMI8 = fh6qmOxoiv1UPXZanLprDeMI8.replace('data:image/'+X8i7OYvbJj06TWp4M2lP5kC+';base64,','')
				JEpYd5LVCAXa0F = abn2REWAS3FwTN0rlQmgOk.b64decode(fh6qmOxoiv1UPXZanLprDeMI8)
				open(kPId2vNQ5a4i1ExgHUjqV,'wb').write(JEpYd5LVCAXa0F)
		else: kPId2vNQ5a4i1ExgHUjqV = ''
		xgPSaoLzTlFtQD37M6HIEsWY = GzRqE6Q42AgXhNFneMP059I(name,c0cDhidBlOn7)
		if xgPSaoLzTlFtQD37M6HIEsWY not in hgUHAlMnVoFue5f:
			hgUHAlMnVoFue5f.append(xgPSaoLzTlFtQD37M6HIEsWY)
			name = N6EjMQZJwbdDLla0C24Opifg(xgPSaoLzTlFtQD37M6HIEsWY)
			VjN95C7uYXSbGImWf.append([name,c0cDhidBlOn7,title,text,kPId2vNQ5a4i1ExgHUjqV,xgPSaoLzTlFtQD37M6HIEsWY])
	return VjN95C7uYXSbGImWf
def KZY6gIARLMiWodVt4UOlEfH7a1Jk(c0cDhidBlOn7,xgPSaoLzTlFtQD37M6HIEsWY):
	EsoNPCTO6a243HIqXh0R,KIOap9Wsnru,tcDxzmPhwuVGE9ls0n6g = hhHQ695ZrMo2bFnIJqt(xgPSaoLzTlFtQD37M6HIEsWY)
	if tcDxzmPhwuVGE9ls0n6g: EsoNPCTO6a243HIqXh0R()
	else: Yv3KlEaZrcw1eT76Lyd4iXGbRC()
	return
def dyFxfXn4IO6USkT():
	NiWSoAmhdkQPlTpneyVzDO8tw9aL('','',OPEJxmUqr9wAX1i,'هذا البحث يستخدم ذكاء وشمولية وسرعة محرك بحث جوجل .. ونتائج هذا البحث هي أسماء مواقع الإنترنت التي موجودة في هذا البرنامج والتي فيها الفيديوهات المطلوبة\n\nهذا البحث يحتاج كلمات بحث عادية جدا بدون أي مراعاة لدقة الكلمات أو تفاصيل الفيديوهات أو حتى إملاء الكلمات\n\nهذا البحث يستطيع أيضا أن يفحص محتويات المواقع التي وجدها جوجل إذا كانت هذه المواقع موجودة بهذا البرنامج')
	return
def Yv3KlEaZrcw1eT76Lyd4iXGbRC(xgPSaoLzTlFtQD37M6HIEsWY=''):
	NiWSoAmhdkQPlTpneyVzDO8tw9aL('','',xgPSaoLzTlFtQD37M6HIEsWY,'هذا الموقع غير موجود في البرنامج .. أو أسم الموقع مختلف وغير مطابق للاسم المستخدم في البرنامج')
	return
def GzRqE6Q42AgXhNFneMP059I(name,c0cDhidBlOn7):
	RkE8G6qsTA7LMhYOc1HI = {
	 'فشار فيديو مشاهدة افلام ومسلسلات اون لاين'	:'FUSHARVIDEO'
	,'وى سيما wecima ماى سيما mycima'			:'WECIMA1'
	,'شبكتي تي في - SHABAKATY TV'				:'SHABAKATY'
	,'اكوام  شبكة اكوام AKWAM'					:'AKWAM'
	,'سيما كلوب  CIMACLUB'						:'CIMACLUB'
	,'سيما فري CIMAFREE':'CIMAFREE'
	,'هلا سيما'			:'HALACIMA'
	,'لاروزا'			:'LAROZA'
	,'برستيج'			:'BRSTEJ'
	,'كرمالك TV'		:'KIRMALK'
	,'سيما فور بي'		:'CIMA4P'
	,'اهواك تي في'		:'AHWAK'
	,'CIMA CLUB'		:'CIMACLUB'
	,'اكوام'			:'AKWAM'
	,'وي سيما'			:'WECIMA1'
	,'سيما ناو'			:'CIMANOW'
	,'سيما لايت'			:'CIMALIGHT'
	,'موقع ماي سيما'	:'CIMALIGHT'
	,'عرب سيد'			:'ARABSEED'
	,'فيديو ياقوت'		:'YAQOT'
	,'المصطبة TV'		:'ALMSTBA'
	,'دراما كافيه'		:'DRAMACAFE'
	,'سيما 400'			:'CIMA400'
	,'فيديو تكات'		:'TIKAAT'
	,'السينما.كوم'		:'ELCINEMA'
	,'فوستا'			:'FOSTA'
	,'سيما عبدو'		:'CIMAABDO'
	,'فاصل إعلاني'		:'FASELHD1'
	,'مسلسلات تايم'		:'SERIESTIME'
	,'شوف نت'			:'SHOOFNET'
	}
	wRbgsDELJBq9odiKFIu6 = name.lower()
	bXWSJeh38Onkra02 = ''
	for key in list(RkE8G6qsTA7LMhYOc1HI.keys()):
		if key.lower() in wRbgsDELJBq9odiKFIu6: bXWSJeh38Onkra02 = RkE8G6qsTA7LMhYOc1HI[key]
	if not bXWSJeh38Onkra02:
		cz5qCJd6O3g4ISxVa1EtQpysvGHPk = CxlbPZwGTcH87e1sWhfSIz29uRUEpV(c0cDhidBlOn7,'url')
		for xgPSaoLzTlFtQD37M6HIEsWY in list(USuRxnPlV5.SITESURLS.keys()):
			LLkBo51TpPlsJ = CxlbPZwGTcH87e1sWhfSIz29uRUEpV(USuRxnPlV5.SITESURLS[xgPSaoLzTlFtQD37M6HIEsWY][0],'url')
			if cz5qCJd6O3g4ISxVa1EtQpysvGHPk==LLkBo51TpPlsJ: bXWSJeh38Onkra02 = xgPSaoLzTlFtQD37M6HIEsWY
	if not bXWSJeh38Onkra02:
		wRbgsDELJBq9odiKFIu6 = CxlbPZwGTcH87e1sWhfSIz29uRUEpV(c0cDhidBlOn7,'name')
		for xgPSaoLzTlFtQD37M6HIEsWY in list(USuRxnPlV5.SITESURLS.keys()):
			QCrBfpwSzaiGFq = CxlbPZwGTcH87e1sWhfSIz29uRUEpV(USuRxnPlV5.SITESURLS[xgPSaoLzTlFtQD37M6HIEsWY][0],'name')
			if wRbgsDELJBq9odiKFIu6==QCrBfpwSzaiGFq: bXWSJeh38Onkra02 = xgPSaoLzTlFtQD37M6HIEsWY
	if not bXWSJeh38Onkra02: bXWSJeh38Onkra02 = name
	bXWSJeh38Onkra02 = bXWSJeh38Onkra02.upper()
	return bXWSJeh38Onkra02
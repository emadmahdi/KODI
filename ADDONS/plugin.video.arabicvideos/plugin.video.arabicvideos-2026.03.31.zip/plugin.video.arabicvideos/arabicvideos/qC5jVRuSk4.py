# -*- coding: utf-8 -*-
from RgJNGc7YMP import *
UkXlAzsMcamKJrEIgnxi6bWh = 'MYCIMA'
headers = {'User-Agent':cdZKMn68Pzg4}
nc3GLkA65oxOd = '_MCM_'
cDTdfqVAF0BLGiX364IEwaZbr = USuRxnPlV5.SITESURLS[UkXlAzsMcamKJrEIgnxi6bWh][0]
cJWUPuDGM0Yybv5a9KnIrVzhH78 = ['مصارعة حرة','wwe']
def HHN5EpbszV3iA2m89hGSQjaPgUZy(mode,url,text):
	if   mode==360: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = kUq58vC7x9hWma164JejMKQ()
	elif mode==361: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = GDQUH4fN02sIt81mAcY(url,text)
	elif mode==362: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = RPZbqous7rtdy56LeI18Cv04AKHW(url)
	elif mode==363: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = yIZWSuMpvs3(url,text)
	elif mode==364: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = XxcpMKIUzr0sVDngR(url,'CATEGORIES___'+text)
	elif mode==365: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = XxcpMKIUzr0sVDngR(url,'FILTERS___'+text)
	elif mode==366: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = oQF2hgjusp8Ne(url)
	elif mode==369: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = z4hetAJw3NaT9ROjG6xbZ5CHlW81(text,url)
	else: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = False
	return xsGUcR3ef6glKY5hQwpFXEaSt2mrIz
def kUq58vC7x9hWma164JejMKQ():
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'بحث في الموقع',cDTdfqVAF0BLGiX364IEwaZbr,369,cdZKMn68Pzg4,cdZKMn68Pzg4,'_REMEMBERRESULTS_')
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'فلتر محدد',cDTdfqVAF0BLGiX364IEwaZbr+'/AjaxCenter/RightBar',364)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'فلتر كامل',cDTdfqVAF0BLGiX364IEwaZbr+'/AjaxCenter/RightBar',365)
	zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(r43t1YI9deXA5N,'GET',cDTdfqVAF0BLGiX364IEwaZbr,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'MYCIMA-MENU-2nd')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="NavigationMenu"(.*?)class="ProductionsListButton"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="menu-item.*?href="(.*?)">(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,title in items:
			if title==cdZKMn68Pzg4: continue
			if any(value in title.lower() for value in cJWUPuDGM0Yybv5a9KnIrVzhH78): continue
			zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+title,c0cDhidBlOn7,366)
		zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('hoverable activable(.*?)hoverable activable',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?url\((.*?)\).*?span>(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,title in items:
			zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+title,c0cDhidBlOn7,366,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
	return OO1cj2REUZHJ8x5V
def oQF2hgjusp8Ne(url):
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(r43t1YI9deXA5N,'GET',url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'MYCIMA-SUBMENU-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	if 'class="Slider--Grid"' in OO1cj2REUZHJ8x5V:
		zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'المميزة',url,361,cdZKMn68Pzg4,cdZKMn68Pzg4,'featured')
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="list--Tabsui"(.*?)div',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?i>(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,title in items:
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,361)
	return
def GDQUH4fN02sIt81mAcY(qLsU0ZVlbBrRhJQ5O4fnM,type=cdZKMn68Pzg4):
	if '::' in qLsU0ZVlbBrRhJQ5O4fnM:
		N8jUpQxY0rhtDAzbG4kOs9X,url = qLsU0ZVlbBrRhJQ5O4fnM.split('::')
		wRlW4txQshKmeXdO7zABrLPT1GbZ0 = CxlbPZwGTcH87e1sWhfSIz29uRUEpV(N8jUpQxY0rhtDAzbG4kOs9X,'url')
		url = wRlW4txQshKmeXdO7zABrLPT1GbZ0+url
	else: url,N8jUpQxY0rhtDAzbG4kOs9X = qLsU0ZVlbBrRhJQ5O4fnM,qLsU0ZVlbBrRhJQ5O4fnM
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'MYCIMA-TITLES-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	if type=='featured':
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="Slider--Grid"(.*?)class="list--Tabsui"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	elif type=='filters':
		ppvsMqCHf8SEzxQg = [OO1cj2REUZHJ8x5V.replace('\\/',KCQExdbYFqM).replace('\\"','"')]
	else:
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="Grid--MycimaPosts"(.*?)</li></ul></div></div>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	KRmzvoWYyxfXw37SEh1Q = []
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('GridItem"><a href="([^"]*)" title="([^"]*)".*?url\((.*?)\)',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,title,y90BoFz8MA1ZThaSC2ILXHiK3OY6w in items:
			if any(value in title.lower() for value in cJWUPuDGM0Yybv5a9KnIrVzhH78): continue
			y90BoFz8MA1ZThaSC2ILXHiK3OY6w = XTL0AWmwbDJfGRNi(y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
			title = gbd90SjF2mZqf81IRDaTwJkWu(title)
			title = XTL0AWmwbDJfGRNi(title)
			title = title.replace('مشاهدة ',cdZKMn68Pzg4)
			if '/series/' in c0cDhidBlOn7: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,363,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
			elif 'حلقة' in title:
				E0w56WHxZPYGVvnTQ4O2t1C8DAjq = ffUFBJQ57j2XgoGeOLn9uwpC.findall('(.*?) +حلقة +\d+',title,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
				if E0w56WHxZPYGVvnTQ4O2t1C8DAjq: title = '_MOD_' + E0w56WHxZPYGVvnTQ4O2t1C8DAjq[0]
				if title not in KRmzvoWYyxfXw37SEh1Q:
					KRmzvoWYyxfXw37SEh1Q.append(title)
					zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,363,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
			else:
				zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,362,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
		if type=='filters':
			TTHMO0LXA8IVRgukFC6d4B3rG7U = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"more_button_page":(.*?),',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			if TTHMO0LXA8IVRgukFC6d4B3rG7U:
				count = TTHMO0LXA8IVRgukFC6d4B3rG7U[0]
				c0cDhidBlOn7 = url+'/offset/'+count
				zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'صفحة أخرى',c0cDhidBlOn7,361,cdZKMn68Pzg4,cdZKMn68Pzg4,'filters')
		elif type==cdZKMn68Pzg4:
			ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="pagination(.*?)</div>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			if ppvsMqCHf8SEzxQg:
				KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
				items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)">(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
				for c0cDhidBlOn7,title in items:
					title = 'صفحة '+gbd90SjF2mZqf81IRDaTwJkWu(title)
					zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,361)
	return
def yIZWSuMpvs3(url,type=cdZKMn68Pzg4):
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'MYCIMA-EPISODES-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	OO1cj2REUZHJ8x5V = NLqxoZ37dYf0awrsIE(OO1cj2REUZHJ8x5V)
	name = ffUFBJQ57j2XgoGeOLn9uwpC.findall('itemprop="item" href=".*?/series/(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if name: name = name[-1].replace('-',VBpIH2QSmvDGlA6TO3e).strip(KCQExdbYFqM)
	if 'موسم' in name and type==cdZKMn68Pzg4:
		name = name.split('موسم')[0]
		name = name.replace('مشاهدة',cdZKMn68Pzg4).strip(VBpIH2QSmvDGlA6TO3e)
	elif 'حلقة' in name:
		name = name.split('حلقة')[0]
		name = name.replace('مشاهدة',cdZKMn68Pzg4).strip(VBpIH2QSmvDGlA6TO3e)
	else: name = name
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="Seasons--Episodes"(.*?)</singlesection',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		if type==cdZKMn68Pzg4:
			items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)">(.*?)</a>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			for c0cDhidBlOn7,title in items:
				if 'class' in title: continue
				if 'episode' in title: continue
				title = name+' - '+title
				zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,363,cdZKMn68Pzg4,cdZKMn68Pzg4,'episodes')
		if len(USuRxnPlV5.menuItemsLIST)==0:
			PfGSURJ9jeNtx7FX = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="Episodes--Seasons--Episodes"(.*?)&&',KdWauEhgN6OQzjRVm1ro8tkB3+'&&',ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			if PfGSURJ9jeNtx7FX: KdWauEhgN6OQzjRVm1ro8tkB3 = PfGSURJ9jeNtx7FX[0]
			items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?<episodeTitle>(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			for c0cDhidBlOn7,title in items:
				title = title.strip(VBpIH2QSmvDGlA6TO3e)
				title = name+' - '+title
				zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,362)
	if len(USuRxnPlV5.menuItemsLIST)==0:
		title = ffUFBJQ57j2XgoGeOLn9uwpC.findall('<title>(.*?)<',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if title: title = title[0].replace(' - ماي سيما',cdZKMn68Pzg4).replace('مشاهدة ',cdZKMn68Pzg4)
		else: title = 'ملف التشغيل'
		zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,url,362)
	return
def RPZbqous7rtdy56LeI18Cv04AKHW(url):
	pcX7zxFRmsADwUr = []
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(AlfMBJhUD65to2WrQcb,'GET',url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'MYCIMA-PLAY-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	eVdYQAPy2Dm = ffUFBJQ57j2XgoGeOLn9uwpC.findall('<span>التصنيف<.*?<a.*?">(.*?)<.*?">(.*?)<',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if eVdYQAPy2Dm:
		eVdYQAPy2Dm = [eVdYQAPy2Dm[0][0],eVdYQAPy2Dm[0][1]]
		if eVdYQAPy2Dm and bMOpKuUkQ5J2(UkXlAzsMcamKJrEIgnxi6bWh,url,eVdYQAPy2Dm): return
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="WatchServersList"(.*?)class="WatchServersEmbed"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('data-url="(.*?)".*?strong>(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,name in items:
			if 'http' not in c0cDhidBlOn7: c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr+c0cDhidBlOn7
			if name=='سيرفر ماي سيما': name = 'mycima'
			c0cDhidBlOn7 = c0cDhidBlOn7+'?named='+name+'__watch'
			pcX7zxFRmsADwUr.append(c0cDhidBlOn7)
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="List--Download(.*?)</div>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?</i>(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,l1MCIuwhAELbO2eJ96kNta7rp0B in items:
			if 'http' not in c0cDhidBlOn7: c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr+c0cDhidBlOn7
			l1MCIuwhAELbO2eJ96kNta7rp0B = ffUFBJQ57j2XgoGeOLn9uwpC.findall('\d\d\d+',l1MCIuwhAELbO2eJ96kNta7rp0B,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			if l1MCIuwhAELbO2eJ96kNta7rp0B: l1MCIuwhAELbO2eJ96kNta7rp0B = '____'+l1MCIuwhAELbO2eJ96kNta7rp0B[0]
			else: l1MCIuwhAELbO2eJ96kNta7rp0B = cdZKMn68Pzg4
			c0cDhidBlOn7 = c0cDhidBlOn7+'?named=mycima'+'__download'+l1MCIuwhAELbO2eJ96kNta7rp0B
			pcX7zxFRmsADwUr.append(c0cDhidBlOn7)
	import r0y4XTKznF
	r0y4XTKznF.noHliPXkcg3pJTdSauCvm5sU(pcX7zxFRmsADwUr,UkXlAzsMcamKJrEIgnxi6bWh,'video',url)
	return
def z4hetAJw3NaT9ROjG6xbZ5CHlW81(search,wmC6WuGr9E5Aq1YR=cdZKMn68Pzg4):
	search,EL8zUgbXheot,showDialogs = qbIcHCMdkFKn21e(search)
	if search==cdZKMn68Pzg4: search = BzkmLuvJD9n25Pg()
	if search==cdZKMn68Pzg4: return
	search = search.replace(VBpIH2QSmvDGlA6TO3e,'+')
	pcX7zxFRmsADwUr = ['/list',KCQExdbYFqM,'/list/series','/list/anime','/list/tv']
	Dh86vEgI1n = ['الكل','الأفلام','المسلسلات','الانيمي و الكرتون','البرامج تليفزيونية']
	if showDialogs:
		AS6jLpMwW5Ql3kUFNfT = NAfHLMC8Ip64FmT7l5oJWXaq3hK('اختر النوع المطلوب:', Dh86vEgI1n)
		if AS6jLpMwW5Ql3kUFNfT==-1: return
	else: AS6jLpMwW5Ql3kUFNfT = 0
	if wmC6WuGr9E5Aq1YR==cdZKMn68Pzg4:
		Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(AlfMBJhUD65to2WrQcb,'GET',cDTdfqVAF0BLGiX364IEwaZbr,cdZKMn68Pzg4,cdZKMn68Pzg4,False,cdZKMn68Pzg4,'MYCIMA-SEARCH-1st')
		wmC6WuGr9E5Aq1YR = Zty0AsgQ5jpkTh91OW.headers['Location']
		wmC6WuGr9E5Aq1YR = wmC6WuGr9E5Aq1YR.strip(KCQExdbYFqM)
	HOCWKhxITtulVGX = wmC6WuGr9E5Aq1YR+'/search/'+search+pcX7zxFRmsADwUr[AS6jLpMwW5Ql3kUFNfT]
	GDQUH4fN02sIt81mAcY(HOCWKhxITtulVGX)
	return
def XxcpMKIUzr0sVDngR(qLsU0ZVlbBrRhJQ5O4fnM,filter):
	if '??' in qLsU0ZVlbBrRhJQ5O4fnM: url = qLsU0ZVlbBrRhJQ5O4fnM.split('//getposts??')[0]
	else: url = qLsU0ZVlbBrRhJQ5O4fnM
	filter = filter.replace('_FORGETRESULTS_',cdZKMn68Pzg4)
	type,filter = filter.split('___',1)
	if filter==cdZKMn68Pzg4: KFGqxsBnZYLb3NvMU,ejQ8ZCtBaV7 = cdZKMn68Pzg4,cdZKMn68Pzg4
	else: KFGqxsBnZYLb3NvMU,ejQ8ZCtBaV7 = filter.split('___')
	if type=='CATEGORIES':
		if TUBoFrl6IHzu8Pq[0]+'==' not in KFGqxsBnZYLb3NvMU: rrb0SF6otehufCYOX4 = TUBoFrl6IHzu8Pq[0]
		for WCqkctAYD2O3Hz7Fl8fKRS5 in range(len(TUBoFrl6IHzu8Pq[0:-1])):
			if TUBoFrl6IHzu8Pq[WCqkctAYD2O3Hz7Fl8fKRS5]+'==' in KFGqxsBnZYLb3NvMU: rrb0SF6otehufCYOX4 = TUBoFrl6IHzu8Pq[WCqkctAYD2O3Hz7Fl8fKRS5+1]
		gmjZQuBFv8RzlNtDVEOc = KFGqxsBnZYLb3NvMU+'&&'+rrb0SF6otehufCYOX4+'==0'
		qwmxUpZfQj8EAV3Tc = ejQ8ZCtBaV7+'&&'+rrb0SF6otehufCYOX4+'==0'
		vMp6jZbo3UkEsSxRFQndyA = gmjZQuBFv8RzlNtDVEOc.strip('&&')+'___'+qwmxUpZfQj8EAV3Tc.strip('&&')
		YqrzmSVb3R9MgUnX2auEHlpBhZD = XFoM2xPKIt3u51hLj(ejQ8ZCtBaV7,'modified_filters')
		HOCWKhxITtulVGX = url+'//getposts??'+YqrzmSVb3R9MgUnX2auEHlpBhZD
	elif type=='FILTERS':
		zM2ZBJ4IYN8osGTtwgRheLu6dU = XFoM2xPKIt3u51hLj(KFGqxsBnZYLb3NvMU,'modified_values')
		zM2ZBJ4IYN8osGTtwgRheLu6dU = NLqxoZ37dYf0awrsIE(zM2ZBJ4IYN8osGTtwgRheLu6dU)
		if ejQ8ZCtBaV7!=cdZKMn68Pzg4: ejQ8ZCtBaV7 = XFoM2xPKIt3u51hLj(ejQ8ZCtBaV7,'modified_filters')
		if ejQ8ZCtBaV7==cdZKMn68Pzg4: HOCWKhxITtulVGX = url
		else: HOCWKhxITtulVGX = url+'//getposts??'+ejQ8ZCtBaV7
		GMmu2UjLcIOxW0wHaB1KoRyDs856 = c4WGnhHrZFl2iyOxoEUNYLVvQ6PD0(HOCWKhxITtulVGX,qLsU0ZVlbBrRhJQ5O4fnM)
		zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'أظهار قائمة الفيديو التي تم اختيارها ',GMmu2UjLcIOxW0wHaB1KoRyDs856,361,cdZKMn68Pzg4,cdZKMn68Pzg4,'filters')
		zJLApFBcIhnSj('folder',nc3GLkA65oxOd+' [[   '+zM2ZBJ4IYN8osGTtwgRheLu6dU+'   ]]',GMmu2UjLcIOxW0wHaB1KoRyDs856,361,cdZKMn68Pzg4,cdZKMn68Pzg4,'filters')
		zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(r43t1YI9deXA5N,'GET',url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'MYCIMA-FILTERS_MENU-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	OO1cj2REUZHJ8x5V = OO1cj2REUZHJ8x5V.replace('\\"','"').replace('\\/',KCQExdbYFqM)
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('<mycima--filter(.*?)</mycima--filter>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if not ppvsMqCHf8SEzxQg: return
	KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
	hQ9ADnZlSxI1m8ui = ffUFBJQ57j2XgoGeOLn9uwpC.findall('taxonomy="(.*?)".*?<span>(.*?)<(.*?)<filterbox',KdWauEhgN6OQzjRVm1ro8tkB3+'<filterbox',ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	dict = {}
	for rfJG62Vo0pTEljwPN1WahD7sx4t3QR,name,KdWauEhgN6OQzjRVm1ro8tkB3 in hQ9ADnZlSxI1m8ui:
		name = XTL0AWmwbDJfGRNi(name)
		if 'interest' in rfJG62Vo0pTEljwPN1WahD7sx4t3QR: continue
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('data-term="(.*?)".*?<txt>(.*?)</txt>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if '==' not in HOCWKhxITtulVGX: HOCWKhxITtulVGX = url
		if type=='CATEGORIES':
			if rrb0SF6otehufCYOX4!=rfJG62Vo0pTEljwPN1WahD7sx4t3QR: continue
			elif len(items)<=1:
				if rfJG62Vo0pTEljwPN1WahD7sx4t3QR==TUBoFrl6IHzu8Pq[-1]: GDQUH4fN02sIt81mAcY(HOCWKhxITtulVGX)
				else: XxcpMKIUzr0sVDngR(HOCWKhxITtulVGX,'CATEGORIES___'+vMp6jZbo3UkEsSxRFQndyA)
				return
			else:
				GMmu2UjLcIOxW0wHaB1KoRyDs856 = c4WGnhHrZFl2iyOxoEUNYLVvQ6PD0(HOCWKhxITtulVGX,qLsU0ZVlbBrRhJQ5O4fnM)
				if rfJG62Vo0pTEljwPN1WahD7sx4t3QR==TUBoFrl6IHzu8Pq[-1]:
					zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'الجميع',GMmu2UjLcIOxW0wHaB1KoRyDs856,361,cdZKMn68Pzg4,cdZKMn68Pzg4,'filters')
				else: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'الجميع',HOCWKhxITtulVGX,364,cdZKMn68Pzg4,cdZKMn68Pzg4,vMp6jZbo3UkEsSxRFQndyA)
		elif type=='FILTERS':
			gmjZQuBFv8RzlNtDVEOc = KFGqxsBnZYLb3NvMU+'&&'+rfJG62Vo0pTEljwPN1WahD7sx4t3QR+'==0'
			qwmxUpZfQj8EAV3Tc = ejQ8ZCtBaV7+'&&'+rfJG62Vo0pTEljwPN1WahD7sx4t3QR+'==0'
			vMp6jZbo3UkEsSxRFQndyA = gmjZQuBFv8RzlNtDVEOc+'___'+qwmxUpZfQj8EAV3Tc
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+name+': الجميع',HOCWKhxITtulVGX,365,cdZKMn68Pzg4,cdZKMn68Pzg4,vMp6jZbo3UkEsSxRFQndyA+'_FORGETRESULTS_')
		dict[rfJG62Vo0pTEljwPN1WahD7sx4t3QR] = {}
		for value,zj6FI51Rypka0e8xiECfc7g in items:
			name = XTL0AWmwbDJfGRNi(name)
			zj6FI51Rypka0e8xiECfc7g = XTL0AWmwbDJfGRNi(zj6FI51Rypka0e8xiECfc7g)
			if value=='r' or value=='nc-17': continue
			if any(value in zj6FI51Rypka0e8xiECfc7g.lower() for value in cJWUPuDGM0Yybv5a9KnIrVzhH78): continue
			if 'http' in zj6FI51Rypka0e8xiECfc7g: continue
			if 'الكل' in zj6FI51Rypka0e8xiECfc7g: continue
			if 'n-a' in value: continue
			if zj6FI51Rypka0e8xiECfc7g==cdZKMn68Pzg4: zj6FI51Rypka0e8xiECfc7g = value
			CCpDMVI0dq2 = zj6FI51Rypka0e8xiECfc7g
			ARoy9XWOZtYka6Busejr = ffUFBJQ57j2XgoGeOLn9uwpC.findall('<name>(.*?)</name>',zj6FI51Rypka0e8xiECfc7g,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			if ARoy9XWOZtYka6Busejr: CCpDMVI0dq2 = ARoy9XWOZtYka6Busejr[0]
			UHXfFEWmlxMAnzju4 = name+': '+CCpDMVI0dq2
			dict[rfJG62Vo0pTEljwPN1WahD7sx4t3QR][value] = UHXfFEWmlxMAnzju4
			gmjZQuBFv8RzlNtDVEOc = KFGqxsBnZYLb3NvMU+'&&'+rfJG62Vo0pTEljwPN1WahD7sx4t3QR+'=='+CCpDMVI0dq2
			qwmxUpZfQj8EAV3Tc = ejQ8ZCtBaV7+'&&'+rfJG62Vo0pTEljwPN1WahD7sx4t3QR+'=='+value
			AL8gJZ0NtE91Bexjin4 = gmjZQuBFv8RzlNtDVEOc+'___'+qwmxUpZfQj8EAV3Tc
			if type=='FILTERS':
				zJLApFBcIhnSj('folder',nc3GLkA65oxOd+UHXfFEWmlxMAnzju4,url,365,cdZKMn68Pzg4,cdZKMn68Pzg4,AL8gJZ0NtE91Bexjin4+'_FORGETRESULTS_')
			elif type=='CATEGORIES' and TUBoFrl6IHzu8Pq[-2]+'==' in KFGqxsBnZYLb3NvMU:
				YqrzmSVb3R9MgUnX2auEHlpBhZD = XFoM2xPKIt3u51hLj(qwmxUpZfQj8EAV3Tc,'modified_filters')
				N8jUpQxY0rhtDAzbG4kOs9X = url+'//getposts??'+YqrzmSVb3R9MgUnX2auEHlpBhZD
				GMmu2UjLcIOxW0wHaB1KoRyDs856 = c4WGnhHrZFl2iyOxoEUNYLVvQ6PD0(N8jUpQxY0rhtDAzbG4kOs9X,qLsU0ZVlbBrRhJQ5O4fnM)
				zJLApFBcIhnSj('folder',nc3GLkA65oxOd+UHXfFEWmlxMAnzju4,GMmu2UjLcIOxW0wHaB1KoRyDs856,361,cdZKMn68Pzg4,cdZKMn68Pzg4,'filters')
			else: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+UHXfFEWmlxMAnzju4,url,364,cdZKMn68Pzg4,cdZKMn68Pzg4,AL8gJZ0NtE91Bexjin4)
	return
TUBoFrl6IHzu8Pq = ['genre','release-year','nation']
U4c89YoCKaXy = ['mpaa','genre','release-year','category','Quality','interest','nation','language']
def c4WGnhHrZFl2iyOxoEUNYLVvQ6PD0(HOCWKhxITtulVGX,N8jUpQxY0rhtDAzbG4kOs9X):
	if '/AjaxCenter/RightBar' in HOCWKhxITtulVGX: HOCWKhxITtulVGX = HOCWKhxITtulVGX.replace('/AjaxCenter/RightBar','/AjaxCenter/Filtering')
	HOCWKhxITtulVGX = HOCWKhxITtulVGX.replace('//getposts??','::/AjaxCenter/Filtering/')
	HOCWKhxITtulVGX = HOCWKhxITtulVGX.replace('==',KCQExdbYFqM)
	HOCWKhxITtulVGX = HOCWKhxITtulVGX.replace('&&',KCQExdbYFqM)
	return HOCWKhxITtulVGX
def XFoM2xPKIt3u51hLj(o3JURfrMDgp76,mode):
	o3JURfrMDgp76 = o3JURfrMDgp76.strip('&&')
	bLxfgF7nlO1uZiY9e5T0HDdIw3kpy,n7VBe6ZgDI14lizTfHOmk = {},cdZKMn68Pzg4
	if '==' in o3JURfrMDgp76:
		items = o3JURfrMDgp76.split('&&')
		for HYBN2AQsjimSMgT8OvE3ynX67tJwR in items:
			IN0jyfe1PRdDz6YX3CoJkHthw,value = HYBN2AQsjimSMgT8OvE3ynX67tJwR.split('==')
			bLxfgF7nlO1uZiY9e5T0HDdIw3kpy[IN0jyfe1PRdDz6YX3CoJkHthw] = value
	for key in U4c89YoCKaXy:
		if key in list(bLxfgF7nlO1uZiY9e5T0HDdIw3kpy.keys()): value = bLxfgF7nlO1uZiY9e5T0HDdIw3kpy[key]
		else: value = '0'
		if '%' not in value: value = YQlEOShHM7RLak2t0yA4NXqv(value)
		if mode=='modified_values' and value!='0': n7VBe6ZgDI14lizTfHOmk = n7VBe6ZgDI14lizTfHOmk+' + '+value
		elif mode=='modified_filters' and value!='0': n7VBe6ZgDI14lizTfHOmk = n7VBe6ZgDI14lizTfHOmk+'&&'+key+'=='+value
		elif mode=='all': n7VBe6ZgDI14lizTfHOmk = n7VBe6ZgDI14lizTfHOmk+'&&'+key+'=='+value
	n7VBe6ZgDI14lizTfHOmk = n7VBe6ZgDI14lizTfHOmk.strip(' + ')
	n7VBe6ZgDI14lizTfHOmk = n7VBe6ZgDI14lizTfHOmk.strip('&&')
	return n7VBe6ZgDI14lizTfHOmk
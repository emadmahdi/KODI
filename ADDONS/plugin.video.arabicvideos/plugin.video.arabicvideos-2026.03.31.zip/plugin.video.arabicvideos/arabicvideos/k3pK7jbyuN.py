# -*- coding: utf-8 -*-
from RgJNGc7YMP import *
UkXlAzsMcamKJrEIgnxi6bWh = 'EGYBEST3'
nc3GLkA65oxOd = '_EB3_'
cDTdfqVAF0BLGiX364IEwaZbr = USuRxnPlV5.SITESURLS[UkXlAzsMcamKJrEIgnxi6bWh][0]
cJWUPuDGM0Yybv5a9KnIrVzhH78 = ['المصارعة الحرة','ايجي بست','التصميم الجديد','عروض المصارعة','مكتبتي','ايجي بست الجديد','ايجي بست البديل','egybest','موقع ايجي بست','موقع نتفليكس']
def HHN5EpbszV3iA2m89hGSQjaPgUZy(mode,url,aOZ3yVnsNlB974pR,text):
	if   mode==790: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = kUq58vC7x9hWma164JejMKQ()
	elif mode==791: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = GDQUH4fN02sIt81mAcY(url,aOZ3yVnsNlB974pR)
	elif mode==792: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = oQF2hgjusp8Ne(url)
	elif mode==793: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = RPZbqous7rtdy56LeI18Cv04AKHW(url)
	elif mode==796: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = RRDJdY2uVAykMUN9Fr4v7E0nZKX(url,aOZ3yVnsNlB974pR)
	elif mode==799: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = z4hetAJw3NaT9ROjG6xbZ5CHlW81(text)
	else: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = False
	return xsGUcR3ef6glKY5hQwpFXEaSt2mrIz
def kUq58vC7x9hWma164JejMKQ():
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(r43t1YI9deXA5N,'GET',cDTdfqVAF0BLGiX364IEwaZbr,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'EGYBEST3-MENU-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('list-pages(.*?)fa-folder',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?<span>(.*?)</span>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,title in items:
			title = title.strip(VBpIH2QSmvDGlA6TO3e)
			if any(value in title for value in cJWUPuDGM0Yybv5a9KnIrVzhH78): continue
			if 'http' not in c0cDhidBlOn7: c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr+c0cDhidBlOn7
			zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+title,c0cDhidBlOn7,791)
		zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('main-article(.*?)social-box',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('main-title.*?">(.*?)<.*?href="(.*?)"',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for title,c0cDhidBlOn7 in items:
			title = title.strip(VBpIH2QSmvDGlA6TO3e)
			if any(value in title for value in cJWUPuDGM0Yybv5a9KnIrVzhH78): continue
			if 'http' not in c0cDhidBlOn7: c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr+c0cDhidBlOn7
			zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+title,c0cDhidBlOn7,791,cdZKMn68Pzg4,'mainmenu')
		zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('main-menu(.*?)</ul>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)">(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,title in items:
			title = title.strip(VBpIH2QSmvDGlA6TO3e)
			if any(value in title for value in cJWUPuDGM0Yybv5a9KnIrVzhH78): continue
			if 'http' not in c0cDhidBlOn7: c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr+c0cDhidBlOn7
			zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+title,c0cDhidBlOn7,791)
	return OO1cj2REUZHJ8x5V
def RRDJdY2uVAykMUN9Fr4v7E0nZKX(url,type=cdZKMn68Pzg4):
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'EGYBEST3-SEASONS_EPISODES-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('main-article".*?">(.*?)<(.*?)article',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		DFNaireZ7Akmt3syhvJfCRwdE5z,PCktNV4H3DEOSpeh,items = cdZKMn68Pzg4,cdZKMn68Pzg4,[]
		for name,KdWauEhgN6OQzjRVm1ro8tkB3 in ppvsMqCHf8SEzxQg:
			if 'حلقات' in name: PCktNV4H3DEOSpeh = KdWauEhgN6OQzjRVm1ro8tkB3
			if 'مواسم' in name: DFNaireZ7Akmt3syhvJfCRwdE5z = KdWauEhgN6OQzjRVm1ro8tkB3
		if DFNaireZ7Akmt3syhvJfCRwdE5z and not type:
			items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?data-src="(.*?)".*?"title">(.*?)<',DFNaireZ7Akmt3syhvJfCRwdE5z,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			if len(items)>1:
				for c0cDhidBlOn7,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,title in items:
					zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,796,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,'season')
		if PCktNV4H3DEOSpeh and len(items)<2:
			items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?data-src="(.*?)".*?class="title">(.*?)<',PCktNV4H3DEOSpeh,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			if items:
				for c0cDhidBlOn7,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,title in items:
					zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,793,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
			else:
				items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)">(.*?)<',PCktNV4H3DEOSpeh,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
				for c0cDhidBlOn7,title in items:
					zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,793)
	return
def GDQUH4fN02sIt81mAcY(url,type=cdZKMn68Pzg4):
	ZfUjy7h2N3tkuJMViw16,start,VS3jbIxtKQ,select,U6ts0Wiw9MDK = 0,0,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4
	if 'pagination' in type:
		OxFVcYDluy03GdSU9EswH18NBM6jm,data = sRAznbuQ5jiN09o4V8tpEYSlG7fe(url)
		ZfUjy7h2N3tkuJMViw16 = int(data['limit'])
		start = int(data['start'])
		VS3jbIxtKQ = data['type']
		select = data['select']
		H3F607d1jsXEnMvor2 = 'limit='+str(ZfUjy7h2N3tkuJMViw16)+'&start='+str(start)+'&type='+VS3jbIxtKQ+'&select='+select
		npaJqziQ13tIH0hLjDdB2cWX7uUMPR = {'Content-Type':'application/x-www-form-urlencoded'}
		Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'POST',OxFVcYDluy03GdSU9EswH18NBM6jm,H3F607d1jsXEnMvor2,npaJqziQ13tIH0hLjDdB2cWX7uUMPR,cdZKMn68Pzg4,cdZKMn68Pzg4,'EGYBEST3-TITLES-1st')
		OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
		JJPEReUDbt0QoWHkL21TA = 'blocks'+OO1cj2REUZHJ8x5V+'article'
	else:
		Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'EGYBEST3-TITLES-2nd')
		OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
		JJPEReUDbt0QoWHkL21TA = OO1cj2REUZHJ8x5V
		code = ffUFBJQ57j2XgoGeOLn9uwpC.findall("<script>(var.*?=.*?;var.*?=.*?;var.*?=.*?;var.*?=.*?;var.*?=.*?);</script>",OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if code:
			code = code[0].replace('var',cdZKMn68Pzg4).replace(VBpIH2QSmvDGlA6TO3e,cdZKMn68Pzg4).replace("'",cdZKMn68Pzg4).replace(';','&')
			tYPfm3ISxD,data = sRAznbuQ5jiN09o4V8tpEYSlG7fe('?'+code)
			ZfUjy7h2N3tkuJMViw16 = int(data['limit'])
			start = int(data['start'])
			VS3jbIxtKQ = data['type']
			select = data['select']
			U6ts0Wiw9MDK = data['ajaxurl']
			H3F607d1jsXEnMvor2 = 'limit='+str(ZfUjy7h2N3tkuJMViw16)+'&start='+str(start)+'&type='+VS3jbIxtKQ+'&select='+select
			OxFVcYDluy03GdSU9EswH18NBM6jm = cDTdfqVAF0BLGiX364IEwaZbr+U6ts0Wiw9MDK
			npaJqziQ13tIH0hLjDdB2cWX7uUMPR = {'Content-Type':'application/x-www-form-urlencoded'}
			Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'POST',OxFVcYDluy03GdSU9EswH18NBM6jm,H3F607d1jsXEnMvor2,npaJqziQ13tIH0hLjDdB2cWX7uUMPR,cdZKMn68Pzg4,cdZKMn68Pzg4,'EGYBEST3-TITLES-3rd')
			JJPEReUDbt0QoWHkL21TA = Zty0AsgQ5jpkTh91OW.content
			JJPEReUDbt0QoWHkL21TA = 'blocks'+JJPEReUDbt0QoWHkL21TA+'article'
	items,A3DOb07vMfqazFU6t,o3JURfrMDgp76 = [],False,False
	if not type:
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('main-content(.*?)</div>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if ppvsMqCHf8SEzxQg:
			KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
			items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?</i>(.*?)</a>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			for c0cDhidBlOn7,title in items:
				title = title.strip(VBpIH2QSmvDGlA6TO3e)
				zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,791,cdZKMn68Pzg4,'submenu')
				A3DOb07vMfqazFU6t = True
	if not type:
		o3JURfrMDgp76 = UD3BusZHCQpzAawykn9EqL0lOrjV1f(OO1cj2REUZHJ8x5V)
	if not A3DOb07vMfqazFU6t and not o3JURfrMDgp76:
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('blocks(.*?)article',JJPEReUDbt0QoWHkL21TA,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if ppvsMqCHf8SEzxQg:
			KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
			items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?src="(.*?)".*?class="title">(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			for c0cDhidBlOn7,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,title in items:
				y90BoFz8MA1ZThaSC2ILXHiK3OY6w = y90BoFz8MA1ZThaSC2ILXHiK3OY6w.strip(ssELJkeScrtni2)
				c0cDhidBlOn7 = NLqxoZ37dYf0awrsIE(c0cDhidBlOn7)
				if '/selary/' in c0cDhidBlOn7: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,791,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
				elif 'مسلسل' in c0cDhidBlOn7 and 'حلقة' not in c0cDhidBlOn7: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,796,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
				elif 'موسم' in c0cDhidBlOn7 and 'حلقة' not in c0cDhidBlOn7: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,796,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
				else: zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,793,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
		uUzd5cGjb64M9hLlVpSKtRrxgHX = 12
		data = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="(load-more.*?)<',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if len(items)==uUzd5cGjb64M9hLlVpSKtRrxgHX and (data or 'pagination' in type):
			H3F607d1jsXEnMvor2 = 'limit='+str(uUzd5cGjb64M9hLlVpSKtRrxgHX)+'&start='+str(start+uUzd5cGjb64M9hLlVpSKtRrxgHX)+'&type='+VS3jbIxtKQ+'&select='+select
			HOCWKhxITtulVGX = OxFVcYDluy03GdSU9EswH18NBM6jm+'?next=page&'+H3F607d1jsXEnMvor2
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'المزيد',HOCWKhxITtulVGX,791,cdZKMn68Pzg4,'pagination_'+type)
	return
def UD3BusZHCQpzAawykn9EqL0lOrjV1f(OO1cj2REUZHJ8x5V):
	o3JURfrMDgp76 = False
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('main-article(.*?)article',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		akIvSitzr0mKe = ffUFBJQ57j2XgoGeOLn9uwpC.findall('data-tax="(.*?)".*?<span>(.*?)<(.*?)</ul>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if akIvSitzr0mKe: zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
		for rrb0SF6otehufCYOX4,name,KdWauEhgN6OQzjRVm1ro8tkB3 in akIvSitzr0mKe:
			name = name.strip(VBpIH2QSmvDGlA6TO3e)
			items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)">(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			for c0cDhidBlOn7,value in items:
				title = name+':  '+value
				zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,791,cdZKMn68Pzg4,'filter')
				o3JURfrMDgp76 = True
	return o3JURfrMDgp76
def RPZbqous7rtdy56LeI18Cv04AKHW(url):
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(fS25N8gAZxpbnLi3srX7PJ,'GET',url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'EGYBEST3-PLAY-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	XFj0lV5yMtS67EwbCJ9oO,t0m67ZgxBv4Xb = [],[]
	items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('server-item.*?data-code="(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	for ggUbxXSKeLwtMafkdZ6Quqo in items:
		dmCOFZk4Dqwzb3WlSfyKx = abn2REWAS3FwTN0rlQmgOk.b64decode(ggUbxXSKeLwtMafkdZ6Quqo)
		if W5domCu6XrQUFkiPpa3bNLtHglG: dmCOFZk4Dqwzb3WlSfyKx = dmCOFZk4Dqwzb3WlSfyKx.decode(vczMIlkCAh2u10B3)
		c0cDhidBlOn7 = ffUFBJQ57j2XgoGeOLn9uwpC.findall('src="(.*?)"',dmCOFZk4Dqwzb3WlSfyKx,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if c0cDhidBlOn7:
			c0cDhidBlOn7 = c0cDhidBlOn7[0]
			if c0cDhidBlOn7 not in t0m67ZgxBv4Xb:
				t0m67ZgxBv4Xb.append(c0cDhidBlOn7)
				wRlW4txQshKmeXdO7zABrLPT1GbZ0 = CxlbPZwGTcH87e1sWhfSIz29uRUEpV(c0cDhidBlOn7,'name')
				XFj0lV5yMtS67EwbCJ9oO.append(c0cDhidBlOn7+'?named='+wRlW4txQshKmeXdO7zABrLPT1GbZ0+'__watch')
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="downloads(.*?)</section>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"tr flex-start".*?<div>[ a-zA-Z]*(\d{3,4})[ a-zA-Z]*</div>.*?href="(.*?)"',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for l1MCIuwhAELbO2eJ96kNta7rp0B,c0cDhidBlOn7 in items:
			if c0cDhidBlOn7 not in t0m67ZgxBv4Xb:
				if '/?url=' in c0cDhidBlOn7: c0cDhidBlOn7 = c0cDhidBlOn7.split('/?url=')[1]
				t0m67ZgxBv4Xb.append(c0cDhidBlOn7)
				wRlW4txQshKmeXdO7zABrLPT1GbZ0 = CxlbPZwGTcH87e1sWhfSIz29uRUEpV(c0cDhidBlOn7,'name')
				XFj0lV5yMtS67EwbCJ9oO.append(c0cDhidBlOn7+'?named='+wRlW4txQshKmeXdO7zABrLPT1GbZ0+'__download____'+l1MCIuwhAELbO2eJ96kNta7rp0B)
	import r0y4XTKznF
	r0y4XTKznF.noHliPXkcg3pJTdSauCvm5sU(XFj0lV5yMtS67EwbCJ9oO,UkXlAzsMcamKJrEIgnxi6bWh,'video',url)
	return
def z4hetAJw3NaT9ROjG6xbZ5CHlW81(text):
	return
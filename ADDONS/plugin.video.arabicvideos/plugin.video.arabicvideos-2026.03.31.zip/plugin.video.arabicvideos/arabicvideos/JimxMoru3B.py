# -*- coding: utf-8 -*-
from RgJNGc7YMP import *
UkXlAzsMcamKJrEIgnxi6bWh = 'YOUTUBE'
nc3GLkA65oxOd = '_YUT_'
cDTdfqVAF0BLGiX364IEwaZbr = USuRxnPlV5.SITESURLS[UkXlAzsMcamKJrEIgnxi6bWh][0]
YC5dK3cj8o6ksLeXUwRFHmx4u = 0
def HHN5EpbszV3iA2m89hGSQjaPgUZy(mode,url,text,type,aOZ3yVnsNlB974pR,name,fh6qmOxoiv1UPXZanLprDeMI8):
	if	 mode==140: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = kUq58vC7x9hWma164JejMKQ()
	elif mode==141: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = CYMn5eSw7WOXThkgi(url,name,fh6qmOxoiv1UPXZanLprDeMI8)
	elif mode==143: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = RPZbqous7rtdy56LeI18Cv04AKHW(url,type)
	elif mode==144: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = GDQUH4fN02sIt81mAcY(url,aOZ3yVnsNlB974pR,text)
	elif mode==145: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = HUxysSd9FjLZ702P3YQ(url,aOZ3yVnsNlB974pR)
	elif mode==147: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = WW7pfmdIa60E5rRA3Yk9NUH()
	elif mode==148: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = NatZHiJX6Q4eBP9DMk()
	elif mode==149: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = z4hetAJw3NaT9ROjG6xbZ5CHlW81(text)
	else: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = False
	return xsGUcR3ef6glKY5hQwpFXEaSt2mrIz
def kUq58vC7x9hWma164JejMKQ():
	if 0:
		zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'قائمة 1',cDTdfqVAF0BLGiX364IEwaZbr+'/playlist?list=PLDJPKWWTSFaaGNjpDcPUsWZJVePmAYk_E&pp=iAQB',144)
		zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'قائمة 2',cDTdfqVAF0BLGiX364IEwaZbr+'/playlist?list=PLAj5Gs8FH8ZnUbF0RV-7G3BoqIyZA4uSA',144)
		zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'شخص',cDTdfqVAF0BLGiX364IEwaZbr+'/user/TCNofficial',144)
		zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'موقع',cDTdfqVAF0BLGiX364IEwaZbr+'/channel/UCq59aGNsq9bbhwVTq1Utvgw',144)
		zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'حساب',cDTdfqVAF0BLGiX364IEwaZbr+'/@TheSocialCTV',144)
		zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'العاب',cDTdfqVAF0BLGiX364IEwaZbr+'/gaming',144)
		zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'افلام',cDTdfqVAF0BLGiX364IEwaZbr+'/feed/storefront',144)
		zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'مختارات',cDTdfqVAF0BLGiX364IEwaZbr+'/feed/guide_builder',144)
		zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'قصيرة',cDTdfqVAF0BLGiX364IEwaZbr+'/shorts',144,cdZKMn68Pzg4,cdZKMn68Pzg4,'_REMEMBERRESULTS_')
		zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'تصفح',cDTdfqVAF0BLGiX364IEwaZbr+'/youtubei/v1/guide?key=',144)
		zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'رئيسية',cDTdfqVAF0BLGiX364IEwaZbr+cdZKMn68Pzg4,144)
		zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'رائج',cDTdfqVAF0BLGiX364IEwaZbr+'/feed/trending?bp=',144)
		zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'بحث في الموقع',cdZKMn68Pzg4,149,cdZKMn68Pzg4,cdZKMn68Pzg4,'_REMEMBERRESULTS_')
	zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'الرائجة',cDTdfqVAF0BLGiX364IEwaZbr+'/feed/trending',144)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'التصفح',cDTdfqVAF0BLGiX364IEwaZbr+'/youtubei/v1/guide?key=',144)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'القصيرة',cDTdfqVAF0BLGiX364IEwaZbr+'/shorts',144,cdZKMn68Pzg4,cdZKMn68Pzg4,'_REMEMBERRESULTS_')
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'مختارات يوتيوب',cDTdfqVAF0BLGiX364IEwaZbr+'/feed/guide_builder',144)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'مختارات البرنامج',cdZKMn68Pzg4,290)
	zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'بحث: قنوات عربية',cdZKMn68Pzg4,147)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'بحث: قنوات أجنبية',cdZKMn68Pzg4,148)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'بحث: افلام عربية',cDTdfqVAF0BLGiX364IEwaZbr+'/results?search_query=فيلم',144)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'بحث: افلام اجنبية',cDTdfqVAF0BLGiX364IEwaZbr+'/results?search_query=movie',144)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'بحث: مسرحيات عربية',cDTdfqVAF0BLGiX364IEwaZbr+'/results?search_query=مسرحية',144)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'بحث: مسلسلات عربية',cDTdfqVAF0BLGiX364IEwaZbr+'/results?search_query=مسلسل&sp=EgIQAw==',144)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'بحث: مسلسلات اجنبية',cDTdfqVAF0BLGiX364IEwaZbr+'/results?search_query=series&sp=EgIQAw==',144)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'بحث: مسلسلات كارتون',cDTdfqVAF0BLGiX364IEwaZbr+'/results?search_query=كارتون&sp=EgIQAw==',144)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'بحث: خطبة المرجعية',cDTdfqVAF0BLGiX364IEwaZbr+'/results?search_query=قناة+كربلاء+الفضائية+خطبة+الجمعة&sp=CAISAhAB',144)
	return
def CYMn5eSw7WOXThkgi(url,name,fh6qmOxoiv1UPXZanLprDeMI8):
	name = khTjKWeG8r7nyuS1Dwdq2g06l5soi(name)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'CHNL:  '+name,url,144,fh6qmOxoiv1UPXZanLprDeMI8)
	return
def WW7pfmdIa60E5rRA3Yk9NUH():
	GDQUH4fN02sIt81mAcY(cDTdfqVAF0BLGiX364IEwaZbr+'/results?search_query=قناة+بث&sp=EgJAAQ==')
	return
def NatZHiJX6Q4eBP9DMk():
	GDQUH4fN02sIt81mAcY(cDTdfqVAF0BLGiX364IEwaZbr+'/results?search_query=tv&sp=EgJAAQ==')
	return
def RPZbqous7rtdy56LeI18Cv04AKHW(url,type):
	url = url.split('&',1)[0]
	import r0y4XTKznF
	r0y4XTKznF.noHliPXkcg3pJTdSauCvm5sU([url],UkXlAzsMcamKJrEIgnxi6bWh,type,url)
	return
def fmglziW0GMVpCtJQNYqb3THR6hd(Ski9a56vnyhVbgLwXxRtQ0uND,url,OMQouSr6t7xL):
	level,KE36DpL20Xi8TktP,tZ5LgR42Q1o8vIdwV,gACd2yaRvNeOktoZlLq5Y8hGP97iKF = OMQouSr6t7xL.split('::')
	vz9pUROS35bwt,xMlO6FhEeZn = [],[]
	if '/youtubei/v1/browse' in url: vz9pUROS35bwt.append("yccc['onResponseReceivedActions']")
	if '/youtubei/v1/search' in url: vz9pUROS35bwt.append("yccc['onResponseReceivedCommands']")
	vz9pUROS35bwt.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs'][0]['tabRenderer']['content']['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['playlistVideoListRenderer']['contents']")
	if level=='1': vz9pUROS35bwt.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs'][0]['tabRenderer']['content']['richGridRenderer']['header']['feedFilterChipBarRenderer']['contents']")
	vz9pUROS35bwt.append("yccc['contents']['twoColumnWatchNextResults']['playlist']['playlist']['contents']")
	vz9pUROS35bwt.append("yccc['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['contents']")
	vz9pUROS35bwt.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs']")
	vz9pUROS35bwt.append("yccc['entries']")
	vz9pUROS35bwt.append("yccc['items'][3]['guideSectionRenderer']['items']")
	V6RhBkOq7LuF52C8pUxWDcMoJQSP,e2QuYCawbm8A5iq,uu5ozjMPqNB1XLJ = Zd9jHDMv0WFeObChBfK(Ski9a56vnyhVbgLwXxRtQ0uND,cdZKMn68Pzg4,vz9pUROS35bwt)
	if level=='1' and V6RhBkOq7LuF52C8pUxWDcMoJQSP:
		if len(e2QuYCawbm8A5iq)>1 and 'search_query' not in url:
			for CcQ521yGRrKbBkUVnENeiSpWx4al in range(len(e2QuYCawbm8A5iq)):
				KE36DpL20Xi8TktP = str(CcQ521yGRrKbBkUVnENeiSpWx4al)
				vz9pUROS35bwt = []
				vz9pUROS35bwt.append("yddd["+KE36DpL20Xi8TktP+"]['reloadContinuationItemsCommand']['continuationItems']")
				vz9pUROS35bwt.append("yddd["+KE36DpL20Xi8TktP+"]['command']")
				vz9pUROS35bwt.append("yddd["+KE36DpL20Xi8TktP+"]")
				Q0AOX4cEgius9e,HYBN2AQsjimSMgT8OvE3ynX67tJwR,o0oyFGTp3nZdCrAEzlf8XbjJ6 = Zd9jHDMv0WFeObChBfK(e2QuYCawbm8A5iq,cdZKMn68Pzg4,vz9pUROS35bwt)
				if Q0AOX4cEgius9e: xMlO6FhEeZn.append([HYBN2AQsjimSMgT8OvE3ynX67tJwR,url,'2::'+KE36DpL20Xi8TktP+'::0::0'])
			vz9pUROS35bwt.append("yccc['continuationEndpoint']")
			Q0AOX4cEgius9e,HYBN2AQsjimSMgT8OvE3ynX67tJwR,o0oyFGTp3nZdCrAEzlf8XbjJ6 = Zd9jHDMv0WFeObChBfK(Ski9a56vnyhVbgLwXxRtQ0uND,cdZKMn68Pzg4,vz9pUROS35bwt)
			if Q0AOX4cEgius9e and xMlO6FhEeZn and 'continuationCommand' in list(HYBN2AQsjimSMgT8OvE3ynX67tJwR.keys()):
				c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr+'/my_main_page_shorts_link'
				xMlO6FhEeZn.append([HYBN2AQsjimSMgT8OvE3ynX67tJwR,c0cDhidBlOn7,'1::0::0::0'])
	return e2QuYCawbm8A5iq,V6RhBkOq7LuF52C8pUxWDcMoJQSP,xMlO6FhEeZn,uu5ozjMPqNB1XLJ
def lvmQFbsBe4(Ski9a56vnyhVbgLwXxRtQ0uND,e2QuYCawbm8A5iq,url,OMQouSr6t7xL):
	level,KE36DpL20Xi8TktP,tZ5LgR42Q1o8vIdwV,gACd2yaRvNeOktoZlLq5Y8hGP97iKF = OMQouSr6t7xL.split('::')
	vz9pUROS35bwt,kvVa4FgXp81o657rsycxNd0JwEW = [],[]
	vz9pUROS35bwt.append("yddd[0]['itemSectionRenderer']['contents']")
	vz9pUROS35bwt.append("yddd["+KE36DpL20Xi8TktP+"]['reloadContinuationItemsCommand']['continuationItems']")
	vz9pUROS35bwt.append("yddd[1]['reloadContinuationItemsCommand']['continuationItems']")
	if '/youtubei/v1/browse' in url: vz9pUROS35bwt.append("yddd[0]['appendContinuationItemsAction']['continuationItems']")
	elif '/youtubei/v1/search' in url: vz9pUROS35bwt.append("yddd[0]['appendContinuationItemsAction']['continuationItems'][0]['itemSectionRenderer']['contents']")
	vz9pUROS35bwt.append("yddd["+KE36DpL20Xi8TktP+"]['tabRenderer']['content']['sectionListRenderer']['contents']")
	if '/videos' in url or ('/shorts' in url and '/shorts/' not in url):
		vz9pUROS35bwt.append("yddd["+KE36DpL20Xi8TktP+"]['tabRenderer']['content']['richGridRenderer']['header']['feedFilterChipBarRenderer']['contents']")
	vz9pUROS35bwt.append("yddd["+KE36DpL20Xi8TktP+"]['tabRenderer']['content']['richGridRenderer']['contents']")
	vz9pUROS35bwt.append("yddd["+KE36DpL20Xi8TktP+"]['expandableTabRenderer']['content']['sectionListRenderer']['contents']")
	vz9pUROS35bwt.append("yddd["+KE36DpL20Xi8TktP+"]['richSectionRenderer']['content']['richShelfRenderer']['contents']")
	vz9pUROS35bwt.append("yddd["+KE36DpL20Xi8TktP+"]")
	fg4oQ9KiMvkwjztLnI6,QWU8VtEzbh39N1xvLoiy6kK,x1T7kacBVAbM9XLdqU0g = Zd9jHDMv0WFeObChBfK(e2QuYCawbm8A5iq,cdZKMn68Pzg4,vz9pUROS35bwt)
	if level=='2' and fg4oQ9KiMvkwjztLnI6:
		if len(QWU8VtEzbh39N1xvLoiy6kK)>1:
			for CcQ521yGRrKbBkUVnENeiSpWx4al in range(len(QWU8VtEzbh39N1xvLoiy6kK)):
				tZ5LgR42Q1o8vIdwV = str(CcQ521yGRrKbBkUVnENeiSpWx4al)
				vz9pUROS35bwt = []
				vz9pUROS35bwt.append("yeee["+tZ5LgR42Q1o8vIdwV+"]['richSectionRenderer']['content']")
				vz9pUROS35bwt.append("yeee["+tZ5LgR42Q1o8vIdwV+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['header']")
				vz9pUROS35bwt.append("yeee["+tZ5LgR42Q1o8vIdwV+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
				vz9pUROS35bwt.append("yeee["+tZ5LgR42Q1o8vIdwV+"]['itemSectionRenderer']['contents'][0]")
				vz9pUROS35bwt.append("yeee["+tZ5LgR42Q1o8vIdwV+"]['richItemRenderer']['content']")
				vz9pUROS35bwt.append("yeee["+tZ5LgR42Q1o8vIdwV+"]")
				Q0AOX4cEgius9e,HYBN2AQsjimSMgT8OvE3ynX67tJwR,o0oyFGTp3nZdCrAEzlf8XbjJ6 = Zd9jHDMv0WFeObChBfK(QWU8VtEzbh39N1xvLoiy6kK,cdZKMn68Pzg4,vz9pUROS35bwt)
				if Q0AOX4cEgius9e: kvVa4FgXp81o657rsycxNd0JwEW.append([HYBN2AQsjimSMgT8OvE3ynX67tJwR,url,'3::'+KE36DpL20Xi8TktP+'::'+tZ5LgR42Q1o8vIdwV+'::0'])
			vz9pUROS35bwt.append("yddd[0]['appendContinuationItemsAction']['continuationItems'][1]")
			vz9pUROS35bwt.append("yddd[1]")
			Q0AOX4cEgius9e,HYBN2AQsjimSMgT8OvE3ynX67tJwR,o0oyFGTp3nZdCrAEzlf8XbjJ6 = Zd9jHDMv0WFeObChBfK(e2QuYCawbm8A5iq,cdZKMn68Pzg4,vz9pUROS35bwt)
			if Q0AOX4cEgius9e and kvVa4FgXp81o657rsycxNd0JwEW and 'continuationItemRenderer' in list(HYBN2AQsjimSMgT8OvE3ynX67tJwR.keys()):
				kvVa4FgXp81o657rsycxNd0JwEW.append([HYBN2AQsjimSMgT8OvE3ynX67tJwR,url,'3::0::0::0'])
	return QWU8VtEzbh39N1xvLoiy6kK,fg4oQ9KiMvkwjztLnI6,kvVa4FgXp81o657rsycxNd0JwEW,x1T7kacBVAbM9XLdqU0g
def wx1X6qJnMRoHBUaTdGZV8(Ski9a56vnyhVbgLwXxRtQ0uND,QWU8VtEzbh39N1xvLoiy6kK,url,OMQouSr6t7xL):
	level,KE36DpL20Xi8TktP,tZ5LgR42Q1o8vIdwV,gACd2yaRvNeOktoZlLq5Y8hGP97iKF = OMQouSr6t7xL.split('::')
	vz9pUROS35bwt,yHRQaGK6V4SAg8NdE = [],[]
	vz9pUROS35bwt.append("yeee["+tZ5LgR42Q1o8vIdwV+"]['shelfRenderer']['content']['verticalListRenderer']['items']")
	vz9pUROS35bwt.append("yeee["+tZ5LgR42Q1o8vIdwV+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalMovieListRenderer']['items']")
	vz9pUROS35bwt.append("yeee["+tZ5LgR42Q1o8vIdwV+"]['itemSectionRenderer']['contents'][0]['reelShelfRenderer']['items']")
	vz9pUROS35bwt.append("yeee["+tZ5LgR42Q1o8vIdwV+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	vz9pUROS35bwt.append("yeee["+tZ5LgR42Q1o8vIdwV+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalListRenderer']['items']")
	vz9pUROS35bwt.append("yeee["+tZ5LgR42Q1o8vIdwV+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['expandedShelfContentsRenderer']['items']")
	vz9pUROS35bwt.append("yeee["+tZ5LgR42Q1o8vIdwV+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
	vz9pUROS35bwt.append("yeee["+tZ5LgR42Q1o8vIdwV+"]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	vz9pUROS35bwt.append("yeee[0]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	vz9pUROS35bwt.append("yeee[0]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	vz9pUROS35bwt.append("yeee[0]['itemSectionRenderer']['contents'][0]['playlistVideoListRenderer']['contents']")
	vz9pUROS35bwt.append("yeee["+tZ5LgR42Q1o8vIdwV+"]['reelShelfRenderer']['items']")
	vz9pUROS35bwt.append("yeee["+tZ5LgR42Q1o8vIdwV+"]['richSectionRenderer']['content']['richShelfRenderer']['contents']")
	vz9pUROS35bwt.append("yeee")
	QQrybWa4DAcYV0n2ki,NxPQ3BU21jHRfJlXTDE,zkNFMUtr2snDYvVb59Xx4OcjCl6gB = Zd9jHDMv0WFeObChBfK(QWU8VtEzbh39N1xvLoiy6kK,cdZKMn68Pzg4,vz9pUROS35bwt)
	if level=='3' and QQrybWa4DAcYV0n2ki:
		if len(NxPQ3BU21jHRfJlXTDE)>0:
			for CcQ521yGRrKbBkUVnENeiSpWx4al in range(len(NxPQ3BU21jHRfJlXTDE)):
				gACd2yaRvNeOktoZlLq5Y8hGP97iKF = str(CcQ521yGRrKbBkUVnENeiSpWx4al)
				vz9pUROS35bwt = []
				vz9pUROS35bwt.append("yfff["+gACd2yaRvNeOktoZlLq5Y8hGP97iKF+"]['richItemRenderer']['content']")
				vz9pUROS35bwt.append("yfff["+gACd2yaRvNeOktoZlLq5Y8hGP97iKF+"]['gameCardRenderer']['game']")
				vz9pUROS35bwt.append("yfff["+gACd2yaRvNeOktoZlLq5Y8hGP97iKF+"]['itemSectionRenderer']['contents'][0]")
				vz9pUROS35bwt.append("yfff["+gACd2yaRvNeOktoZlLq5Y8hGP97iKF+"]")
				vz9pUROS35bwt.append("yfff")
				Q0AOX4cEgius9e,HYBN2AQsjimSMgT8OvE3ynX67tJwR,o0oyFGTp3nZdCrAEzlf8XbjJ6 = Zd9jHDMv0WFeObChBfK(NxPQ3BU21jHRfJlXTDE,cdZKMn68Pzg4,vz9pUROS35bwt)
				if Q0AOX4cEgius9e: yHRQaGK6V4SAg8NdE.append([HYBN2AQsjimSMgT8OvE3ynX67tJwR,url,'4::'+KE36DpL20Xi8TktP+'::'+tZ5LgR42Q1o8vIdwV+'::'+gACd2yaRvNeOktoZlLq5Y8hGP97iKF])
	return NxPQ3BU21jHRfJlXTDE,QQrybWa4DAcYV0n2ki,yHRQaGK6V4SAg8NdE,zkNFMUtr2snDYvVb59Xx4OcjCl6gB
def Zd9jHDMv0WFeObChBfK(aSW5tHiJKrCu,b63dnmLtQNqzk,CaX1qtviQRfwNyjB):
	Ski9a56vnyhVbgLwXxRtQ0uND,b63dnmLtQNqzk = aSW5tHiJKrCu,b63dnmLtQNqzk
	e2QuYCawbm8A5iq,b63dnmLtQNqzk = aSW5tHiJKrCu,b63dnmLtQNqzk
	QWU8VtEzbh39N1xvLoiy6kK,b63dnmLtQNqzk = aSW5tHiJKrCu,b63dnmLtQNqzk
	NxPQ3BU21jHRfJlXTDE,b63dnmLtQNqzk = aSW5tHiJKrCu,b63dnmLtQNqzk
	HYBN2AQsjimSMgT8OvE3ynX67tJwR,Jf2UQPNYmjiL = aSW5tHiJKrCu,b63dnmLtQNqzk
	count = len(CaX1qtviQRfwNyjB)
	for DXAlBvH2ITZoyunMU0Rq3pw7sx in range(count):
		try:
			LvIn1VmEGQb0Z6NCM2g7J = eval(CaX1qtviQRfwNyjB[DXAlBvH2ITZoyunMU0Rq3pw7sx])
			return True,LvIn1VmEGQb0Z6NCM2g7J,DXAlBvH2ITZoyunMU0Rq3pw7sx+1
		except: pass
	return False,cdZKMn68Pzg4,0
def GDQUH4fN02sIt81mAcY(url,OMQouSr6t7xL=cdZKMn68Pzg4,data=cdZKMn68Pzg4):
	xMlO6FhEeZn,kvVa4FgXp81o657rsycxNd0JwEW,yHRQaGK6V4SAg8NdE = [],[],[]
	if '::' not in OMQouSr6t7xL: OMQouSr6t7xL = '1::0::0::0'
	level,KE36DpL20Xi8TktP,tZ5LgR42Q1o8vIdwV,gACd2yaRvNeOktoZlLq5Y8hGP97iKF = OMQouSr6t7xL.split('::')
	if level=='4': level,KE36DpL20Xi8TktP,tZ5LgR42Q1o8vIdwV,gACd2yaRvNeOktoZlLq5Y8hGP97iKF = '1',KE36DpL20Xi8TktP,tZ5LgR42Q1o8vIdwV,gACd2yaRvNeOktoZlLq5Y8hGP97iKF
	data = data.replace('_REMEMBERRESULTS_',cdZKMn68Pzg4)
	OO1cj2REUZHJ8x5V,Ski9a56vnyhVbgLwXxRtQ0uND,H3F607d1jsXEnMvor2 = Sd1fLsextwJEq3IvCVaA(url,data)
	OMQouSr6t7xL = level+'::'+KE36DpL20Xi8TktP+'::'+tZ5LgR42Q1o8vIdwV+'::'+gACd2yaRvNeOktoZlLq5Y8hGP97iKF
	if level in ['1','2','3']:
		e2QuYCawbm8A5iq,V6RhBkOq7LuF52C8pUxWDcMoJQSP,xMlO6FhEeZn,uu5ozjMPqNB1XLJ = fmglziW0GMVpCtJQNYqb3THR6hd(Ski9a56vnyhVbgLwXxRtQ0uND,url,OMQouSr6t7xL)
		if not V6RhBkOq7LuF52C8pUxWDcMoJQSP: return
		VMi3Iu64LEt7eUDmC5yWawJ = len(xMlO6FhEeZn)
		if VMi3Iu64LEt7eUDmC5yWawJ<2:
			if level=='1': level = '2'
			xMlO6FhEeZn = []
	OMQouSr6t7xL = level+'::'+KE36DpL20Xi8TktP+'::'+tZ5LgR42Q1o8vIdwV+'::'+gACd2yaRvNeOktoZlLq5Y8hGP97iKF
	if level in ['2','3']:
		QWU8VtEzbh39N1xvLoiy6kK,fg4oQ9KiMvkwjztLnI6,kvVa4FgXp81o657rsycxNd0JwEW,x1T7kacBVAbM9XLdqU0g = lvmQFbsBe4(Ski9a56vnyhVbgLwXxRtQ0uND,e2QuYCawbm8A5iq,url,OMQouSr6t7xL)
		if not fg4oQ9KiMvkwjztLnI6: return
		C0TyB9oGzLkAQ2a5EegZSh1lUY = len(kvVa4FgXp81o657rsycxNd0JwEW)
		if C0TyB9oGzLkAQ2a5EegZSh1lUY<2:
			if level=='2': level = '3'
			kvVa4FgXp81o657rsycxNd0JwEW = []
	OMQouSr6t7xL = level+'::'+KE36DpL20Xi8TktP+'::'+tZ5LgR42Q1o8vIdwV+'::'+gACd2yaRvNeOktoZlLq5Y8hGP97iKF
	if level in ['3']:
		NxPQ3BU21jHRfJlXTDE,QQrybWa4DAcYV0n2ki,yHRQaGK6V4SAg8NdE,zkNFMUtr2snDYvVb59Xx4OcjCl6gB = wx1X6qJnMRoHBUaTdGZV8(Ski9a56vnyhVbgLwXxRtQ0uND,QWU8VtEzbh39N1xvLoiy6kK,url,OMQouSr6t7xL)
		if not QQrybWa4DAcYV0n2ki: return
		ra7bxSJwoVWHyi = len(yHRQaGK6V4SAg8NdE)
	for HYBN2AQsjimSMgT8OvE3ynX67tJwR,url,OMQouSr6t7xL in xMlO6FhEeZn+kvVa4FgXp81o657rsycxNd0JwEW+yHRQaGK6V4SAg8NdE:
		HHeEVvc1f8GdySwYqml = xFownLMdfse4AbquT(HYBN2AQsjimSMgT8OvE3ynX67tJwR,url,OMQouSr6t7xL)
	return
def xFownLMdfse4AbquT(HYBN2AQsjimSMgT8OvE3ynX67tJwR,url=cdZKMn68Pzg4,OMQouSr6t7xL=cdZKMn68Pzg4):
	if '::' in OMQouSr6t7xL: level,KE36DpL20Xi8TktP,tZ5LgR42Q1o8vIdwV,gACd2yaRvNeOktoZlLq5Y8hGP97iKF = OMQouSr6t7xL.split('::')
	else: level,KE36DpL20Xi8TktP,tZ5LgR42Q1o8vIdwV,gACd2yaRvNeOktoZlLq5Y8hGP97iKF = '1','0','0','0'
	Q0AOX4cEgius9e,title,c0cDhidBlOn7,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,count,Kr1n9xq5TY4gohlVdNEu0b,TKVMzvywFqotED,ElDMAUpqmw8aGrCF,wbO0eAqFscPJSN7Lk = Zpfn1VSIe67gYQ0KLlt93COTxUN(HYBN2AQsjimSMgT8OvE3ynX67tJwR)
	JRNfjgmDsv = '/videos?' in c0cDhidBlOn7 or '/streams?' in c0cDhidBlOn7 or '/playlists?' in c0cDhidBlOn7
	Zv0dMVXFlwLYS9EI = '/channels?' in c0cDhidBlOn7 or '/shorts?' in c0cDhidBlOn7
	if JRNfjgmDsv or Zv0dMVXFlwLYS9EI: c0cDhidBlOn7 = url
	JRNfjgmDsv = 'watch?v=' not in c0cDhidBlOn7 and '/playlist?list=' not in c0cDhidBlOn7
	Zv0dMVXFlwLYS9EI = '/gaming' not in c0cDhidBlOn7  and '/feed/storefront' not in c0cDhidBlOn7
	if OMQouSr6t7xL[0:5]=='3::0::' and JRNfjgmDsv and Zv0dMVXFlwLYS9EI: c0cDhidBlOn7 = url
	if '/youtubei/v1/guide?key=' in url or '/gaming' in c0cDhidBlOn7:
		level,KE36DpL20Xi8TktP,tZ5LgR42Q1o8vIdwV,gACd2yaRvNeOktoZlLq5Y8hGP97iKF = '1','0','0','0'
		OMQouSr6t7xL = cdZKMn68Pzg4
	H3F607d1jsXEnMvor2 = cdZKMn68Pzg4
	if '/youtubei/v1/browse' in c0cDhidBlOn7 or '/youtubei/v1/search' in c0cDhidBlOn7 or '/my_main_page_shorts_link' in url:
		data = Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.getSetting('av.youtube.data')
		if data.count(':::')==4:
			edN3KcXUt7,key,TTMndws7xWPUuBb9zkcXYpJqZ,PP1y642BFeSVagtJORbU0NTDLWY,ZkrlcUwCsK0XGpDSBjW = data.split(':::')
			H3F607d1jsXEnMvor2 = edN3KcXUt7+':::'+key+':::'+TTMndws7xWPUuBb9zkcXYpJqZ+':::'+PP1y642BFeSVagtJORbU0NTDLWY+':::'+wbO0eAqFscPJSN7Lk
			if '/my_main_page_shorts_link' in url and not c0cDhidBlOn7: c0cDhidBlOn7 = url
			else: c0cDhidBlOn7 = c0cDhidBlOn7+'?key='+key
	if not title:
		global YC5dK3cj8o6ksLeXUwRFHmx4u
		YC5dK3cj8o6ksLeXUwRFHmx4u += 1
		title = 'فيديوهات '+str(YC5dK3cj8o6ksLeXUwRFHmx4u)
		OMQouSr6t7xL = '3'+'::'+KE36DpL20Xi8TktP+'::'+tZ5LgR42Q1o8vIdwV+'::'+gACd2yaRvNeOktoZlLq5Y8hGP97iKF
	if not Q0AOX4cEgius9e: return False
	elif 'searchPyvRenderer' in str(HYBN2AQsjimSMgT8OvE3ynX67tJwR): return False
	elif '/about' in c0cDhidBlOn7: return False
	elif '/community' in c0cDhidBlOn7: return False
	elif 'continuationItemRenderer' in list(HYBN2AQsjimSMgT8OvE3ynX67tJwR.keys()) or 'continuationCommand' in list(HYBN2AQsjimSMgT8OvE3ynX67tJwR.keys()):
		if int(level)>1: level = str(int(level)-1)
		OMQouSr6t7xL = level+'::'+KE36DpL20Xi8TktP+'::'+tZ5LgR42Q1o8vIdwV+'::'+gACd2yaRvNeOktoZlLq5Y8hGP97iKF
		zJLApFBcIhnSj('folder',nc3GLkA65oxOd+':: '+'صفحة أخرى',c0cDhidBlOn7,144,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,OMQouSr6t7xL,H3F607d1jsXEnMvor2)
	elif '/search' in c0cDhidBlOn7:
		title = ':: '+title
		OMQouSr6t7xL = '3'+'::'+KE36DpL20Xi8TktP+'::'+tZ5LgR42Q1o8vIdwV+'::'+gACd2yaRvNeOktoZlLq5Y8hGP97iKF
		url = url.replace('/search',cdZKMn68Pzg4)
		zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,url,145,cdZKMn68Pzg4,OMQouSr6t7xL,'_REMEMBERRESULTS_')
	elif 'search_query' in url and not c0cDhidBlOn7:
		OMQouSr6t7xL = '3'+'::'+KE36DpL20Xi8TktP+'::'+tZ5LgR42Q1o8vIdwV+'::'+gACd2yaRvNeOktoZlLq5Y8hGP97iKF
		title = ':: '+title
		zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,url,144,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,OMQouSr6t7xL,H3F607d1jsXEnMvor2)
	elif '/browse' in c0cDhidBlOn7 and url==cDTdfqVAF0BLGiX364IEwaZbr:
		title = ':: '+title
		OMQouSr6t7xL = '2::0::0::0'
		zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,144,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,OMQouSr6t7xL,H3F607d1jsXEnMvor2)
	elif not c0cDhidBlOn7 and 'horizontalMovieListRenderer' in str(HYBN2AQsjimSMgT8OvE3ynX67tJwR):
		title = ':: '+title
		OMQouSr6t7xL = '3::0::0::0'
		zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,url,144,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,OMQouSr6t7xL)
	elif 'messageRenderer' in str(HYBN2AQsjimSMgT8OvE3ynX67tJwR):
		zJLApFBcIhnSj('link',nc3GLkA65oxOd+title,cdZKMn68Pzg4,9999)
	elif TKVMzvywFqotED:
		zJLApFBcIhnSj('live',nc3GLkA65oxOd+TKVMzvywFqotED+title,c0cDhidBlOn7,143,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
	elif '/playlist?list=' in c0cDhidBlOn7:
		c0cDhidBlOn7 = c0cDhidBlOn7.replace('&playnext=1',cdZKMn68Pzg4)
		zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'LIST'+count+':  '+title,c0cDhidBlOn7,144,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,OMQouSr6t7xL)
	elif '/shorts/' in c0cDhidBlOn7:
		c0cDhidBlOn7 = c0cDhidBlOn7.split('&list=',1)[0]
		zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,143,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,Kr1n9xq5TY4gohlVdNEu0b)
	elif '/watch?v=' in c0cDhidBlOn7:
		if '&list=' in c0cDhidBlOn7 and count:
			wWvcKnx61UyFT = c0cDhidBlOn7.split('&list=',1)[1]
			c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr+'/playlist?list='+wWvcKnx61UyFT
			OMQouSr6t7xL = '1::0::0::0'
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'LIST'+count+':  '+title,c0cDhidBlOn7,144,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,OMQouSr6t7xL)
		else:
			c0cDhidBlOn7 = c0cDhidBlOn7.split('&list=',1)[0]
			zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,143,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,Kr1n9xq5TY4gohlVdNEu0b)
	elif '/channel/' in c0cDhidBlOn7 or '/c/' in c0cDhidBlOn7 or ('/@' in c0cDhidBlOn7 and c0cDhidBlOn7.count(KCQExdbYFqM)==3):
		if xicJPb0AW1nsRfH3kCv7:
			title = title.decode(vczMIlkCAh2u10B3).encode('raw_unicode_escape')
			title = XTL0AWmwbDJfGRNi(title)
		zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'CHNL'+count+':  '+title,c0cDhidBlOn7,144,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,OMQouSr6t7xL)
	elif '/user/' in c0cDhidBlOn7:
		zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'USER'+count+':  '+title,c0cDhidBlOn7,144,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,OMQouSr6t7xL)
	else:
		if not c0cDhidBlOn7: c0cDhidBlOn7 = url
		title = ':: '+title
		zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,144,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,OMQouSr6t7xL,H3F607d1jsXEnMvor2)
	return True
def Zpfn1VSIe67gYQ0KLlt93COTxUN(HYBN2AQsjimSMgT8OvE3ynX67tJwR):
	Q0AOX4cEgius9e,title,c0cDhidBlOn7,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,count,Kr1n9xq5TY4gohlVdNEu0b,TKVMzvywFqotED,ElDMAUpqmw8aGrCF,ZkrlcUwCsK0XGpDSBjW = False,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4
	if not isinstance(HYBN2AQsjimSMgT8OvE3ynX67tJwR,dict): return Q0AOX4cEgius9e,title,c0cDhidBlOn7,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,count,Kr1n9xq5TY4gohlVdNEu0b,TKVMzvywFqotED,ElDMAUpqmw8aGrCF,ZkrlcUwCsK0XGpDSBjW
	for tRno3721yKv9sBD8CfLJHIjVuM4G in list(HYBN2AQsjimSMgT8OvE3ynX67tJwR.keys()):
		Jf2UQPNYmjiL = HYBN2AQsjimSMgT8OvE3ynX67tJwR[tRno3721yKv9sBD8CfLJHIjVuM4G]
		if isinstance(Jf2UQPNYmjiL,dict): break
	vz9pUROS35bwt = []
	vz9pUROS35bwt.append("yrender['header']['playlistHeaderRenderer']['title']['simpleText']")
	vz9pUROS35bwt.append("yrender['header']['richListHeaderRenderer']['title']['simpleText']")
	vz9pUROS35bwt.append("yrender['header']['richListHeaderRenderer']['title']")
	vz9pUROS35bwt.append("yrender['headline']['simpleText']")
	vz9pUROS35bwt.append("yrender['unplayableText']['simpleText']")
	vz9pUROS35bwt.append("yrender['formattedTitle']['simpleText']")
	vz9pUROS35bwt.append("yrender['title']['simpleText']")
	vz9pUROS35bwt.append("yrender['title']['runs'][0]['text']")
	vz9pUROS35bwt.append("yrender['text']['simpleText']")
	vz9pUROS35bwt.append("yrender['text']['runs'][0]['text']")
	vz9pUROS35bwt.append("yrender['title']['content']")
	vz9pUROS35bwt.append("yrender['title']")
	vz9pUROS35bwt.append("item['title']")
	vz9pUROS35bwt.append("item['reelWatchEndpoint']['videoId']")
	Q0AOX4cEgius9e,title,o0oyFGTp3nZdCrAEzlf8XbjJ6 = Zd9jHDMv0WFeObChBfK(HYBN2AQsjimSMgT8OvE3ynX67tJwR,Jf2UQPNYmjiL,vz9pUROS35bwt)
	vz9pUROS35bwt = []
	vz9pUROS35bwt.append("yrender['title']['runs'][0]['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	vz9pUROS35bwt.append("yrender['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	vz9pUROS35bwt.append("yrender['continuationEndpoint']['commandMetadata']['webCommandMetadata']['apiUrl']")
	vz9pUROS35bwt.append("yrender['navigationEndpoint']['commandMetadata']['webCommandMetadata']['apiUrl']")
	vz9pUROS35bwt.append("yrender['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	vz9pUROS35bwt.append("item['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	vz9pUROS35bwt.append("item['commandMetadata']['webCommandMetadata']['url']")
	Q0AOX4cEgius9e,c0cDhidBlOn7,o0oyFGTp3nZdCrAEzlf8XbjJ6 = Zd9jHDMv0WFeObChBfK(HYBN2AQsjimSMgT8OvE3ynX67tJwR,Jf2UQPNYmjiL,vz9pUROS35bwt)
	vz9pUROS35bwt = []
	vz9pUROS35bwt.append("yrender['thumbnail']['thumbnails'][0]['url']")
	vz9pUROS35bwt.append("yrender['thumbnails'][0]['thumbnails'][0]['url']")
	vz9pUROS35bwt.append("item['reelWatchEndpoint']['thumbnail']['thumbnails'][0]['url']")
	Q0AOX4cEgius9e,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,o0oyFGTp3nZdCrAEzlf8XbjJ6 = Zd9jHDMv0WFeObChBfK(HYBN2AQsjimSMgT8OvE3ynX67tJwR,Jf2UQPNYmjiL,vz9pUROS35bwt)
	vz9pUROS35bwt = []
	vz9pUROS35bwt.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayBottomPanelRenderer']['text']['runs'][0]['text']")
	vz9pUROS35bwt.append("yrender['videoCountShortText']['simpleText']")
	vz9pUROS35bwt.append("yrender['videoCountText']['runs'][0]['text']")
	vz9pUROS35bwt.append("yrender['videoCount']")
	Q0AOX4cEgius9e,count,o0oyFGTp3nZdCrAEzlf8XbjJ6 = Zd9jHDMv0WFeObChBfK(HYBN2AQsjimSMgT8OvE3ynX67tJwR,Jf2UQPNYmjiL,vz9pUROS35bwt)
	vz9pUROS35bwt = []
	vz9pUROS35bwt.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['runs'][0]['text']")
	vz9pUROS35bwt.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['simpleText']")
	vz9pUROS35bwt.append("yrender['lengthText']['simpleText']")
	vz9pUROS35bwt.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['icon']['iconType']")
	vz9pUROS35bwt.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['style']")
	Q0AOX4cEgius9e,Kr1n9xq5TY4gohlVdNEu0b,o0oyFGTp3nZdCrAEzlf8XbjJ6 = Zd9jHDMv0WFeObChBfK(HYBN2AQsjimSMgT8OvE3ynX67tJwR,Jf2UQPNYmjiL,vz9pUROS35bwt)
	vz9pUROS35bwt = []
	vz9pUROS35bwt.append("yrender['navigationEndpoint']['continuationCommand']['token']")
	vz9pUROS35bwt.append("yrender['continuationEndpoint']['continuationCommand']['token']")
	Q0AOX4cEgius9e,ZkrlcUwCsK0XGpDSBjW,o0oyFGTp3nZdCrAEzlf8XbjJ6 = Zd9jHDMv0WFeObChBfK(HYBN2AQsjimSMgT8OvE3ynX67tJwR,Jf2UQPNYmjiL,vz9pUROS35bwt)
	if 'LIVE' in Kr1n9xq5TY4gohlVdNEu0b: Kr1n9xq5TY4gohlVdNEu0b,TKVMzvywFqotED = cdZKMn68Pzg4,'LIVE:  '
	if 'مباشر' in Kr1n9xq5TY4gohlVdNEu0b: Kr1n9xq5TY4gohlVdNEu0b,TKVMzvywFqotED = cdZKMn68Pzg4,'LIVE:  '
	if 'badges' in list(Jf2UQPNYmjiL.keys()):
		bbT1ex3o0YyzkSlVB = str(Jf2UQPNYmjiL['badges'])
		if 'Free with Ads' in bbT1ex3o0YyzkSlVB: ElDMAUpqmw8aGrCF = '$:  '
		if 'LIVE' in bbT1ex3o0YyzkSlVB: TKVMzvywFqotED = 'LIVE:  '
		if 'Buy' in bbT1ex3o0YyzkSlVB or 'Rent' in bbT1ex3o0YyzkSlVB: ElDMAUpqmw8aGrCF = '$$:  '
		if VWC0FPRg21pTjI5K3ZEtcXxlA(u'مباشر') in bbT1ex3o0YyzkSlVB: TKVMzvywFqotED = 'LIVE:  '
		if VWC0FPRg21pTjI5K3ZEtcXxlA(u'شراء') in bbT1ex3o0YyzkSlVB: ElDMAUpqmw8aGrCF = '$$:  '
		if VWC0FPRg21pTjI5K3ZEtcXxlA(u'استئجار') in bbT1ex3o0YyzkSlVB: ElDMAUpqmw8aGrCF = '$$:  '
		if VWC0FPRg21pTjI5K3ZEtcXxlA(u'إعلانات') in bbT1ex3o0YyzkSlVB: ElDMAUpqmw8aGrCF = '$:  '
	c0cDhidBlOn7 = XTL0AWmwbDJfGRNi(c0cDhidBlOn7)
	if c0cDhidBlOn7 and 'http' not in c0cDhidBlOn7: c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr+c0cDhidBlOn7
	y90BoFz8MA1ZThaSC2ILXHiK3OY6w = y90BoFz8MA1ZThaSC2ILXHiK3OY6w.split('?')[0]
	if  y90BoFz8MA1ZThaSC2ILXHiK3OY6w and 'http' not in y90BoFz8MA1ZThaSC2ILXHiK3OY6w: y90BoFz8MA1ZThaSC2ILXHiK3OY6w = 'https:'+y90BoFz8MA1ZThaSC2ILXHiK3OY6w
	title = XTL0AWmwbDJfGRNi(title)
	if ElDMAUpqmw8aGrCF: title = ElDMAUpqmw8aGrCF+title
	Kr1n9xq5TY4gohlVdNEu0b = Kr1n9xq5TY4gohlVdNEu0b.replace(',',cdZKMn68Pzg4)
	count = count.replace(',',cdZKMn68Pzg4)
	count = ffUFBJQ57j2XgoGeOLn9uwpC.findall('\d+',count)
	if count: count = count[0]
	else: count = cdZKMn68Pzg4
	return True,title,c0cDhidBlOn7,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,count,Kr1n9xq5TY4gohlVdNEu0b,TKVMzvywFqotED,ElDMAUpqmw8aGrCF,ZkrlcUwCsK0XGpDSBjW
def Sd1fLsextwJEq3IvCVaA(url,data=cdZKMn68Pzg4,CvSX7Etpz80eGlT1brgWZkJ=cdZKMn68Pzg4):
	if CvSX7Etpz80eGlT1brgWZkJ==cdZKMn68Pzg4: CvSX7Etpz80eGlT1brgWZkJ = 'ytInitialData'
	wbIl8gEPfoLVHAjGX = knzwM2WCl7jAex9H4YFva()
	npaJqziQ13tIH0hLjDdB2cWX7uUMPR = {'User-Agent':wbIl8gEPfoLVHAjGX,'Cookie':'PREF=hl=ar'}
	global Hgmcv0pjTFoGRLXdiP4rKSzs2Ab
	if not data: data = Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.getSetting('av.youtube.data')
	if data.count(':::')==4: edN3KcXUt7,key,TTMndws7xWPUuBb9zkcXYpJqZ,PP1y642BFeSVagtJORbU0NTDLWY,ZkrlcUwCsK0XGpDSBjW = data.split(':::')
	else: edN3KcXUt7,key,TTMndws7xWPUuBb9zkcXYpJqZ,PP1y642BFeSVagtJORbU0NTDLWY,ZkrlcUwCsK0XGpDSBjW = cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4
	H3F607d1jsXEnMvor2 = {"context":{"client":{"hl":"ar","clientName":"WEB","clientVersion":TTMndws7xWPUuBb9zkcXYpJqZ}}}
	if url==cDTdfqVAF0BLGiX364IEwaZbr+'/shorts' or '/my_main_page_shorts_link' in url:
		url = cDTdfqVAF0BLGiX364IEwaZbr+'/youtubei/v1/reel/reel_watch_sequence'+'?key='+key
		H3F607d1jsXEnMvor2['sequenceParams'] = edN3KcXUt7
		H3F607d1jsXEnMvor2 = str(H3F607d1jsXEnMvor2)
		Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(AlfMBJhUD65to2WrQcb,'POST',url,H3F607d1jsXEnMvor2,npaJqziQ13tIH0hLjDdB2cWX7uUMPR,True,True,'YOUTUBE-GET_PAGE_DATA-1st')
	elif '/guide?key=' in url:
		url = cDTdfqVAF0BLGiX364IEwaZbr+'/youtubei/v1/guide?key='+key
		H3F607d1jsXEnMvor2 = str(H3F607d1jsXEnMvor2)
		Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(AlfMBJhUD65to2WrQcb,'POST',url,H3F607d1jsXEnMvor2,npaJqziQ13tIH0hLjDdB2cWX7uUMPR,True,True,'YOUTUBE-GET_PAGE_DATA-3rd')
	elif 'key=' in url and edN3KcXUt7:
		H3F607d1jsXEnMvor2['continuation'] = ZkrlcUwCsK0XGpDSBjW
		H3F607d1jsXEnMvor2['context']['client']['visitorData'] = edN3KcXUt7
		H3F607d1jsXEnMvor2 = str(H3F607d1jsXEnMvor2)
		Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(AlfMBJhUD65to2WrQcb,'POST',url,H3F607d1jsXEnMvor2,npaJqziQ13tIH0hLjDdB2cWX7uUMPR,True,True,'YOUTUBE-GET_PAGE_DATA-4th')
	elif 'ctoken=' in url and PP1y642BFeSVagtJORbU0NTDLWY:
		npaJqziQ13tIH0hLjDdB2cWX7uUMPR.update({'X-YouTube-Client-Name':'1','X-YouTube-Client-Version':TTMndws7xWPUuBb9zkcXYpJqZ})
		npaJqziQ13tIH0hLjDdB2cWX7uUMPR.update({'Cookie':'VISITOR_INFO1_LIVE='+PP1y642BFeSVagtJORbU0NTDLWY})
		Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(AlfMBJhUD65to2WrQcb,'GET',url,cdZKMn68Pzg4,npaJqziQ13tIH0hLjDdB2cWX7uUMPR,cdZKMn68Pzg4,cdZKMn68Pzg4,'YOUTUBE-GET_PAGE_DATA-5th')
	else:
		Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(AlfMBJhUD65to2WrQcb,'GET',url,cdZKMn68Pzg4,npaJqziQ13tIH0hLjDdB2cWX7uUMPR,cdZKMn68Pzg4,cdZKMn68Pzg4,'YOUTUBE-GET_PAGE_DATA-6th')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	a6ihlXO2CxHKrTuoknwzQ3cPBNGULj = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"innertubeApiKey".*?"(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL|ffUFBJQ57j2XgoGeOLn9uwpC.I)
	if a6ihlXO2CxHKrTuoknwzQ3cPBNGULj: key = a6ihlXO2CxHKrTuoknwzQ3cPBNGULj[0]
	a6ihlXO2CxHKrTuoknwzQ3cPBNGULj = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"cver".*?"value".*?"(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL|ffUFBJQ57j2XgoGeOLn9uwpC.I)
	if a6ihlXO2CxHKrTuoknwzQ3cPBNGULj: TTMndws7xWPUuBb9zkcXYpJqZ = a6ihlXO2CxHKrTuoknwzQ3cPBNGULj[0]
	a6ihlXO2CxHKrTuoknwzQ3cPBNGULj = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"visitorData".*?"(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL|ffUFBJQ57j2XgoGeOLn9uwpC.I)
	if a6ihlXO2CxHKrTuoknwzQ3cPBNGULj: edN3KcXUt7 = a6ihlXO2CxHKrTuoknwzQ3cPBNGULj[0]
	cookies = Zty0AsgQ5jpkTh91OW.cookies
	if 'VISITOR_INFO1_LIVE' in list(cookies.keys()): PP1y642BFeSVagtJORbU0NTDLWY = cookies['VISITOR_INFO1_LIVE']
	hXu08Aat2cymHMVSIJ = edN3KcXUt7+':::'+key+':::'+TTMndws7xWPUuBb9zkcXYpJqZ+':::'+PP1y642BFeSVagtJORbU0NTDLWY+':::'+ZkrlcUwCsK0XGpDSBjW
	if CvSX7Etpz80eGlT1brgWZkJ=='ytInitialData' and 'ytInitialData' in OO1cj2REUZHJ8x5V:
		ppn8MtexmGralPTCQNJY4cR2BLoSdh = ffUFBJQ57j2XgoGeOLn9uwpC.findall('window\["ytInitialData"\] = ({.*?});',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if not ppn8MtexmGralPTCQNJY4cR2BLoSdh: ppn8MtexmGralPTCQNJY4cR2BLoSdh = ffUFBJQ57j2XgoGeOLn9uwpC.findall('var ytInitialData = ({.*?});',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		ckghGE58bdvo = lMeKd3hC6cmS('str',ppn8MtexmGralPTCQNJY4cR2BLoSdh[0])
	elif CvSX7Etpz80eGlT1brgWZkJ=='ytInitialGuideData' and 'ytInitialGuideData' in OO1cj2REUZHJ8x5V:
		ppn8MtexmGralPTCQNJY4cR2BLoSdh = ffUFBJQ57j2XgoGeOLn9uwpC.findall('var ytInitialGuideData = ({.*?});',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		ckghGE58bdvo = lMeKd3hC6cmS('str',ppn8MtexmGralPTCQNJY4cR2BLoSdh[0])
	elif '</script>' not in OO1cj2REUZHJ8x5V: ckghGE58bdvo = lMeKd3hC6cmS('str',OO1cj2REUZHJ8x5V)
	else: ckghGE58bdvo = cdZKMn68Pzg4
	if 0:
		Ski9a56vnyhVbgLwXxRtQ0uND = str(ckghGE58bdvo)
		if W5domCu6XrQUFkiPpa3bNLtHglG: Ski9a56vnyhVbgLwXxRtQ0uND = Ski9a56vnyhVbgLwXxRtQ0uND.encode(vczMIlkCAh2u10B3)
		open('S:\\0000emad.dat','wb').write(Ski9a56vnyhVbgLwXxRtQ0uND)
	Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.setSetting('av.youtube.data',hXu08Aat2cymHMVSIJ)
	return OO1cj2REUZHJ8x5V,ckghGE58bdvo,hXu08Aat2cymHMVSIJ
def HUxysSd9FjLZ702P3YQ(url,OMQouSr6t7xL):
	search = BzkmLuvJD9n25Pg()
	if not search: return
	search = search.replace(VBpIH2QSmvDGlA6TO3e,'+')
	HOCWKhxITtulVGX = url+'/search?query='+search
	GDQUH4fN02sIt81mAcY(HOCWKhxITtulVGX,OMQouSr6t7xL)
	return
def z4hetAJw3NaT9ROjG6xbZ5CHlW81(search):
	search,EL8zUgbXheot,showDialogs = qbIcHCMdkFKn21e(search)
	if not search:
		search = BzkmLuvJD9n25Pg()
		if not search: return
	search = search.replace(VBpIH2QSmvDGlA6TO3e,'+')
	HOCWKhxITtulVGX = cDTdfqVAF0BLGiX364IEwaZbr+'/results?search_query='+search
	if not showDialogs:
		if '_YOUTUBE-VIDEOS_' in EL8zUgbXheot: ikIJdpO54XW7lKrznUyo2SFE6 = '&sp=EgIQAQ%253D%253D'
		elif '_YOUTUBE-PLAYLISTS_' in EL8zUgbXheot: ikIJdpO54XW7lKrznUyo2SFE6 = '&sp=EgIQAw%253D%253D'
		elif '_YOUTUBE-CHANNELS_' in EL8zUgbXheot: ikIJdpO54XW7lKrznUyo2SFE6 = '&sp=EgIQAg%253D%253D'
		else: ikIJdpO54XW7lKrznUyo2SFE6 = cdZKMn68Pzg4
		N8jUpQxY0rhtDAzbG4kOs9X = HOCWKhxITtulVGX+ikIJdpO54XW7lKrznUyo2SFE6
	else:
		Ibi13PvhFOTV4ZRYo2U9l7sWN,ZnAhSodtux43eBIG0HEc,UHXfFEWmlxMAnzju4 = [],[],cdZKMn68Pzg4
		nfJb7yqimwxsNXY08ZdOGv = ['فيديوهات مرتبة بالصلة','فيديوهات مرتبة بالتاريخ','فيديوهات مرتبة بعدد المشاهدات','فيديوهات مرتبة بالتقييم','(جيد للمسلسلات) قوائم تشغيل','قنوات','بث حي']
		GZMwN9Y35Af = ['&sp=CAASAhAB','&sp=CAISAhAB','&sp=CAMSAhAB','&sp=CAESAhAB','&sp=EgIQAw==','&sp=EgIQAg==','&sp=EgJAAQ==']
		IIbylPxmhBaLS8QMHe3qU = NAfHLMC8Ip64FmT7l5oJWXaq3hK('اختر البحث المناسب',nfJb7yqimwxsNXY08ZdOGv)
		if IIbylPxmhBaLS8QMHe3qU == -1: return
		Xnkz7uCaJOSe6cE89MqUH4YZVD = GZMwN9Y35Af[IIbylPxmhBaLS8QMHe3qU]
		OO1cj2REUZHJ8x5V,T6xmbeXSupQD3oygd8,data = Sd1fLsextwJEq3IvCVaA(HOCWKhxITtulVGX+Xnkz7uCaJOSe6cE89MqUH4YZVD)
		if T6xmbeXSupQD3oygd8:
			try:
				Ma4lm18kJACPbNZG = T6xmbeXSupQD3oygd8['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['subMenu']['searchSubMenuRenderer']['groups']
				for EeMRXABOYn4SC7xolK02 in range(len(Ma4lm18kJACPbNZG)):
					group = Ma4lm18kJACPbNZG[EeMRXABOYn4SC7xolK02]['searchFilterGroupRenderer']['filters']
					for GGafr1TZvIHEnix in range(len(group)):
						Jf2UQPNYmjiL = group[GGafr1TZvIHEnix]['searchFilterRenderer']
						if 'navigationEndpoint' in list(Jf2UQPNYmjiL.keys()):
							c0cDhidBlOn7 = Jf2UQPNYmjiL['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']
							c0cDhidBlOn7 = c0cDhidBlOn7.replace('\u0026','&')
							title = Jf2UQPNYmjiL['tooltip']
							title = title.replace('البحث عن ',cdZKMn68Pzg4)
							if 'إزالة الفلتر' in title: continue
							if 'قائمة تشغيل' in title:
								title = 'جيد للمسلسلات '+title
								UHXfFEWmlxMAnzju4 = title
								cz5qCJd6O3g4ISxVa1EtQpysvGHPk = c0cDhidBlOn7
							if 'ترتيب حسب' in title: continue
							title = title.replace('Search for ',cdZKMn68Pzg4)
							if 'Remove' in title: continue
							if 'Playlist' in title:
								title = 'جيد للمسلسلات '+title
								UHXfFEWmlxMAnzju4 = title
								cz5qCJd6O3g4ISxVa1EtQpysvGHPk = c0cDhidBlOn7
							if 'Sort by' in title: continue
							Ibi13PvhFOTV4ZRYo2U9l7sWN.append(XTL0AWmwbDJfGRNi(title))
							ZnAhSodtux43eBIG0HEc.append(c0cDhidBlOn7)
			except: pass
		if not UHXfFEWmlxMAnzju4: XIoQ06pSa3shcv89WP1lKeMqOA = cdZKMn68Pzg4
		else:
			Ibi13PvhFOTV4ZRYo2U9l7sWN = ['بدون فلتر',UHXfFEWmlxMAnzju4]+Ibi13PvhFOTV4ZRYo2U9l7sWN
			ZnAhSodtux43eBIG0HEc = [cdZKMn68Pzg4,cz5qCJd6O3g4ISxVa1EtQpysvGHPk]+ZnAhSodtux43eBIG0HEc
			X5INo4Pg8K36pE9cyS = NAfHLMC8Ip64FmT7l5oJWXaq3hK('موقع يوتيوب - اختر الفلتر',Ibi13PvhFOTV4ZRYo2U9l7sWN)
			if X5INo4Pg8K36pE9cyS == -1: return
			XIoQ06pSa3shcv89WP1lKeMqOA = ZnAhSodtux43eBIG0HEc[X5INo4Pg8K36pE9cyS]
		if XIoQ06pSa3shcv89WP1lKeMqOA: N8jUpQxY0rhtDAzbG4kOs9X = cDTdfqVAF0BLGiX364IEwaZbr+XIoQ06pSa3shcv89WP1lKeMqOA
		elif Xnkz7uCaJOSe6cE89MqUH4YZVD: N8jUpQxY0rhtDAzbG4kOs9X = HOCWKhxITtulVGX+Xnkz7uCaJOSe6cE89MqUH4YZVD
		else: N8jUpQxY0rhtDAzbG4kOs9X = HOCWKhxITtulVGX
	GDQUH4fN02sIt81mAcY(N8jUpQxY0rhtDAzbG4kOs9X)
	return
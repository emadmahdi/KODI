# -*- coding: utf-8 -*-
from RgJNGc7YMP import *
UkXlAzsMcamKJrEIgnxi6bWh = 'ALFATIMI'
nc3GLkA65oxOd = '_FTM_'
cDTdfqVAF0BLGiX364IEwaZbr = USuRxnPlV5.SITESURLS[UkXlAzsMcamKJrEIgnxi6bWh][0]
E83DlUBjcYwqtevJ = ['1239','1250','1245','20','1259','218','485','1238','1258','292']
e9fhbQjAm6gZvdpq47YCGzoxK = ['3030','628']
def HHN5EpbszV3iA2m89hGSQjaPgUZy(mode,url,text):
	if   mode==60: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = kUq58vC7x9hWma164JejMKQ()
	elif mode==61: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = GDQUH4fN02sIt81mAcY(url,text)
	elif mode==62: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = yIZWSuMpvs3(url)
	elif mode==63: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = RPZbqous7rtdy56LeI18Cv04AKHW(url)
	elif mode==64: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = lRrhGH9sjyCFP(text)
	elif mode==69: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = z4hetAJw3NaT9ROjG6xbZ5CHlW81(text)
	else: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = False
	return xsGUcR3ef6glKY5hQwpFXEaSt2mrIz
def kUq58vC7x9hWma164JejMKQ():
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'بحث في الموقع',cdZKMn68Pzg4,69,cdZKMn68Pzg4,cdZKMn68Pzg4,'_REMEMBERRESULTS_')
	zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+'ما يتم مشاهدته الان',cDTdfqVAF0BLGiX364IEwaZbr,64,cdZKMn68Pzg4,cdZKMn68Pzg4,'recent_viewed_vids')
	zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+'الاكثر مشاهدة',cDTdfqVAF0BLGiX364IEwaZbr,64,cdZKMn68Pzg4,cdZKMn68Pzg4,'most_viewed_vids')
	zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+'اضيفت مؤخرا',cDTdfqVAF0BLGiX364IEwaZbr,64,cdZKMn68Pzg4,cdZKMn68Pzg4,'recently_added_vids')
	zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+'فيديو عشوائي',cDTdfqVAF0BLGiX364IEwaZbr,64,cdZKMn68Pzg4,cdZKMn68Pzg4,'random_vids')
	zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+'افلام ومسلسلات',cDTdfqVAF0BLGiX364IEwaZbr,61,cdZKMn68Pzg4,cdZKMn68Pzg4,'-1')
	zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+'البرامج الدينية',cDTdfqVAF0BLGiX364IEwaZbr,61,cdZKMn68Pzg4,cdZKMn68Pzg4,'-2')
	zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+'English Videos',cDTdfqVAF0BLGiX364IEwaZbr,61,cdZKMn68Pzg4,cdZKMn68Pzg4,'-3')
	return cdZKMn68Pzg4
def GDQUH4fN02sIt81mAcY(url,rrb0SF6otehufCYOX4):
	HoO9J2jYcCe8W = cdZKMn68Pzg4
	if rrb0SF6otehufCYOX4 not in ['-1','-2','-3']: HoO9J2jYcCe8W = '?cat='+rrb0SF6otehufCYOX4
	HOCWKhxITtulVGX = cDTdfqVAF0BLGiX364IEwaZbr+'/menu_level.php'+HoO9J2jYcCe8W
	OO1cj2REUZHJ8x5V = Gc05Efm73C8s(K8DZxE74Afz52gBYbOMtpvql0RJma,HOCWKhxITtulVGX,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'ALFATIMI-TITLES-1st')
	items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href=\'(.*?)\'.*?>(.*?)<.*?>(.*?)</span>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	l1lzUpYd5OMoBEWPk,JJuQo1gq9vAtVe8k74HKsjUL2FcfZ = False,False
	for c0cDhidBlOn7,title,count in items:
		title = gbd90SjF2mZqf81IRDaTwJkWu(title)
		title = title.strip(VBpIH2QSmvDGlA6TO3e)
		if 'http' not in c0cDhidBlOn7: c0cDhidBlOn7 = 'http:'+c0cDhidBlOn7
		HoO9J2jYcCe8W = ffUFBJQ57j2XgoGeOLn9uwpC.findall('cat=(.*?)&',c0cDhidBlOn7,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)[0]
		if rrb0SF6otehufCYOX4==HoO9J2jYcCe8W: l1lzUpYd5OMoBEWPk = True
		elif l1lzUpYd5OMoBEWPk 	or (rrb0SF6otehufCYOX4=='-1' and HoO9J2jYcCe8W in E83DlUBjcYwqtevJ)  						or (rrb0SF6otehufCYOX4=='-2' and HoO9J2jYcCe8W not in e9fhbQjAm6gZvdpq47YCGzoxK and HoO9J2jYcCe8W not in E83DlUBjcYwqtevJ)  						or (rrb0SF6otehufCYOX4=='-3' and HoO9J2jYcCe8W in e9fhbQjAm6gZvdpq47YCGzoxK):
							if count=='1': zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,63)
							else: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,61,cdZKMn68Pzg4,cdZKMn68Pzg4,HoO9J2jYcCe8W)
							JJuQo1gq9vAtVe8k74HKsjUL2FcfZ = True
	if not JJuQo1gq9vAtVe8k74HKsjUL2FcfZ: yIZWSuMpvs3(url)
	return
def yIZWSuMpvs3(url):
	OO1cj2REUZHJ8x5V = Gc05Efm73C8s(K8DZxE74Afz52gBYbOMtpvql0RJma,url,cdZKMn68Pzg4,cdZKMn68Pzg4,True,'ALFATIMI-EPISODES-1st')
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('pagination(.*?)id="footer',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
	items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('grid_view.*?src="(.*?)".*?title="(.*?)".*?<h2.*?href="(.*?)"',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	c0cDhidBlOn7 = cdZKMn68Pzg4
	for y90BoFz8MA1ZThaSC2ILXHiK3OY6w,title,c0cDhidBlOn7 in items:
		title = title.replace('Add',cdZKMn68Pzg4).replace('to Quicklist',cdZKMn68Pzg4).strip(VBpIH2QSmvDGlA6TO3e)
		if 'http' not in c0cDhidBlOn7: c0cDhidBlOn7 = 'http:'+c0cDhidBlOn7
		zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,63,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
	ppvsMqCHf8SEzxQg=ffUFBJQ57j2XgoGeOLn9uwpC.findall('(.*?)div',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	KdWauEhgN6OQzjRVm1ro8tkB3=ppvsMqCHf8SEzxQg[0]
	KdWauEhgN6OQzjRVm1ro8tkB3=ffUFBJQ57j2XgoGeOLn9uwpC.findall('pagination(.*?)</div>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)[0]
	items=ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?>(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	HOCWKhxITtulVGX = url.split('?')[0]
	for c0cDhidBlOn7,HsYhVo5Jud in items:
		c0cDhidBlOn7 = HOCWKhxITtulVGX + c0cDhidBlOn7
		title = gbd90SjF2mZqf81IRDaTwJkWu(HsYhVo5Jud)
		title = 'صفحة ' + title
		zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,62)
	return c0cDhidBlOn7
def RPZbqous7rtdy56LeI18Cv04AKHW(url):
	if 'videos.php' in url: url = yIZWSuMpvs3(url)
	OO1cj2REUZHJ8x5V = Gc05Efm73C8s(r43t1YI9deXA5N,url,cdZKMn68Pzg4,cdZKMn68Pzg4,True,'ALFATIMI-PLAY-1st')
	items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('playlistfile:"(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	url = items[0]
	if 'http' not in url: url = 'http:'+url
	bmgwWLk3er(url,UkXlAzsMcamKJrEIgnxi6bWh,'video')
	return
def lRrhGH9sjyCFP(rrb0SF6otehufCYOX4):
	jYazNf8LMbPRh09gt5 = { 'mode' : rrb0SF6otehufCYOX4 }
	url = 'http://alfatimi.tv/ajax.php'
	headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
	data = RV59cpi6BbrlJQuzwCTa(jYazNf8LMbPRh09gt5)
	OO1cj2REUZHJ8x5V = Gc05Efm73C8s(AlfMBJhUD65to2WrQcb,url,data,headers,True,'ALFATIMI-MOSTS-1st')
	items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?title="(.*?)".*?src="(.*?)".*?href',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	for c0cDhidBlOn7,title,y90BoFz8MA1ZThaSC2ILXHiK3OY6w in items:
		title = title.strip(VBpIH2QSmvDGlA6TO3e)
		if 'http' not in c0cDhidBlOn7: c0cDhidBlOn7 = 'http:'+c0cDhidBlOn7
		zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,63,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
	return
def z4hetAJw3NaT9ROjG6xbZ5CHlW81(search):
	search,EL8zUgbXheot,showDialogs = qbIcHCMdkFKn21e(search)
	if search==cdZKMn68Pzg4: search = BzkmLuvJD9n25Pg()
	if search==cdZKMn68Pzg4: return
	nuKdVC6ePlg = search.replace(VBpIH2QSmvDGlA6TO3e,'+')
	url = cDTdfqVAF0BLGiX364IEwaZbr + '/search_result.php?query=' + nuKdVC6ePlg
	yIZWSuMpvs3(url)
	return
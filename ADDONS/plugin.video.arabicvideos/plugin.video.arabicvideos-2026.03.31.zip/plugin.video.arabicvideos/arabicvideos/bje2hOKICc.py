# -*- coding: utf-8 -*-
from RgJNGc7YMP import *
UkXlAzsMcamKJrEIgnxi6bWh = 'ALARAB'
headers = {'User-Agent':cdZKMn68Pzg4}
nc3GLkA65oxOd = '_KLA_'
cDTdfqVAF0BLGiX364IEwaZbr = USuRxnPlV5.SITESURLS[UkXlAzsMcamKJrEIgnxi6bWh][0]
def HHN5EpbszV3iA2m89hGSQjaPgUZy(mode,url,text):
	if   mode==10: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = kUq58vC7x9hWma164JejMKQ()
	elif mode==11: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = GDQUH4fN02sIt81mAcY(url)
	elif mode==12: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = RPZbqous7rtdy56LeI18Cv04AKHW(url)
	elif mode==13: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = yIZWSuMpvs3(url)
	elif mode==14: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = rDMwBgVzEW()
	elif mode==15: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = plnFLv6IHDMKekCT()
	elif mode==16: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = PfS7ciTjYdMg6L8()
	elif mode==19: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = z4hetAJw3NaT9ROjG6xbZ5CHlW81(text)
	else: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = False
	return xsGUcR3ef6glKY5hQwpFXEaSt2mrIz
def kUq58vC7x9hWma164JejMKQ():
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'بحث في الموقع',cdZKMn68Pzg4,19,cdZKMn68Pzg4,cdZKMn68Pzg4,'_REMEMBERRESULTS_')
	zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+'آخر الإضافات',cdZKMn68Pzg4,14)
	zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+'مسلسلات رمضان',cdZKMn68Pzg4,15)
	OO1cj2REUZHJ8x5V = Gc05Efm73C8s(r43t1YI9deXA5N,cDTdfqVAF0BLGiX364IEwaZbr,cdZKMn68Pzg4,headers,cdZKMn68Pzg4,'ALARAB-MENU-1st')
	ppvsMqCHf8SEzxQg=ffUFBJQ57j2XgoGeOLn9uwpC.findall('id="nav-slider"(.*?)</div>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	LhZDMG0skv = ppvsMqCHf8SEzxQg[0]
	items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?>(.*?)<',LhZDMG0skv,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	for c0cDhidBlOn7,title in items:
		c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr+c0cDhidBlOn7
		title = title.strip(VBpIH2QSmvDGlA6TO3e)
		zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+title,c0cDhidBlOn7,11)
	zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('id="navbar"(.*?)</div>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	PfGSURJ9jeNtx7FX = ppvsMqCHf8SEzxQg[0]
	items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?>(.*?)<',PfGSURJ9jeNtx7FX,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	for c0cDhidBlOn7,title in items:
		c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr+c0cDhidBlOn7
		zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+title,c0cDhidBlOn7,11)
	return OO1cj2REUZHJ8x5V
def plnFLv6IHDMKekCT():
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'جميع المسلسلات العربية',cDTdfqVAF0BLGiX364IEwaZbr+'/view-8/مسلسلات-عربية',11)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'مسلسلات السنة الأخيرة',cdZKMn68Pzg4,16)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'مسلسلات رمضان الأخيرة 1',cDTdfqVAF0BLGiX364IEwaZbr+'/view-8/مسلسلات-رمضان-2022',11)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'مسلسلات رمضان الأخيرة 2',cDTdfqVAF0BLGiX364IEwaZbr+'/view-8/مسلسلات-رمضان-2023',11)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'مسلسلات رمضان 2023',cDTdfqVAF0BLGiX364IEwaZbr+'/ramadan2023/مصرية',11)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'مسلسلات رمضان 2022',cDTdfqVAF0BLGiX364IEwaZbr+'/ramadan2022/مصرية',11)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'مسلسلات رمضان 2021',cDTdfqVAF0BLGiX364IEwaZbr+'/ramadan2021/مصرية',11)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'مسلسلات رمضان 2020',cDTdfqVAF0BLGiX364IEwaZbr+'/ramadan2020/مصرية',11)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'مسلسلات رمضان 2019',cDTdfqVAF0BLGiX364IEwaZbr+'/ramadan2019/مصرية',11)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'مسلسلات رمضان 2018',cDTdfqVAF0BLGiX364IEwaZbr+'/ramadan2018/مصرية',11)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'مسلسلات رمضان 2017',cDTdfqVAF0BLGiX364IEwaZbr+'/ramadan2017/مصرية',11)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'مسلسلات رمضان 2016',cDTdfqVAF0BLGiX364IEwaZbr+'/ramadan2016/مصرية',11)
	return
def rDMwBgVzEW():
	OO1cj2REUZHJ8x5V = Gc05Efm73C8s(K8DZxE74Afz52gBYbOMtpvql0RJma,cDTdfqVAF0BLGiX364IEwaZbr,cdZKMn68Pzg4,headers,True,'ALARAB-LATEST-1st')
	ppvsMqCHf8SEzxQg=ffUFBJQ57j2XgoGeOLn9uwpC.findall('heading-top(.*?)div class=',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]+ppvsMqCHf8SEzxQg[1]
	items=ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?data-src="(.*?)" alt="(.*?)"',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	for c0cDhidBlOn7,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,title in items:
		url = cDTdfqVAF0BLGiX364IEwaZbr + c0cDhidBlOn7
		if 'series' in url: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,url,11,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
		else: zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,url,12,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
	return
def GDQUH4fN02sIt81mAcY(url):
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',url,cdZKMn68Pzg4,headers,True,True,'ALARAB-TITLES-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('video-category(.*?)right_content',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if not ppvsMqCHf8SEzxQg: return
	KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
	JJuQo1gq9vAtVe8k74HKsjUL2FcfZ = False
	items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('video-box.*?href="(.*?)".*?src="(http.*?)" alt="(.*?)"',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	KRmzvoWYyxfXw37SEh1Q,YYrBisapSDJuyg6hoC7bHtUv29 = [],[]
	for c0cDhidBlOn7,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,title in items:
		if title==cdZKMn68Pzg4: title = c0cDhidBlOn7.split(KCQExdbYFqM)[-1].replace('-',VBpIH2QSmvDGlA6TO3e)
		o0oyFGTp3nZdCrAEzlf8XbjJ6 = ffUFBJQ57j2XgoGeOLn9uwpC.findall('(\d+)',title,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if o0oyFGTp3nZdCrAEzlf8XbjJ6: o0oyFGTp3nZdCrAEzlf8XbjJ6 = int(o0oyFGTp3nZdCrAEzlf8XbjJ6[0])
		else: o0oyFGTp3nZdCrAEzlf8XbjJ6 = 0
		YYrBisapSDJuyg6hoC7bHtUv29.append([y90BoFz8MA1ZThaSC2ILXHiK3OY6w,c0cDhidBlOn7,title,o0oyFGTp3nZdCrAEzlf8XbjJ6])
	YYrBisapSDJuyg6hoC7bHtUv29 = sorted(YYrBisapSDJuyg6hoC7bHtUv29, reverse=True, key=lambda key: key[3])
	for y90BoFz8MA1ZThaSC2ILXHiK3OY6w,c0cDhidBlOn7,title,o0oyFGTp3nZdCrAEzlf8XbjJ6 in YYrBisapSDJuyg6hoC7bHtUv29:
		c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr + c0cDhidBlOn7
		title = title.replace('مشاهدة مسلسل','مسلسل')
		title = title.replace('مشاهدة المسلسل','المسلسل')
		title = title.replace('مشاهدة فيلم','فيلم')
		title = title.replace('مشاهدة الفيلم','الفيلم')
		title = title.replace('مباشرة كواليتي',cdZKMn68Pzg4)
		title = title.replace('عالية على العرب',cdZKMn68Pzg4)
		title = title.replace('مشاهدة مباشرة',cdZKMn68Pzg4)
		title = title.replace('اون لاين',cdZKMn68Pzg4)
		title = title.replace('اونلاين',cdZKMn68Pzg4)
		title = title.replace('بجودة عالية',cdZKMn68Pzg4)
		title = title.replace('جودة عالية',cdZKMn68Pzg4)
		title = title.replace('بدون تحميل',cdZKMn68Pzg4)
		title = title.replace('على العرب',cdZKMn68Pzg4)
		title = title.replace('مباشرة',cdZKMn68Pzg4)
		title = title.strip(VBpIH2QSmvDGlA6TO3e).replace(wr0HaqRdJ2D9LT7nSO1KMe38ly,VBpIH2QSmvDGlA6TO3e).replace(wr0HaqRdJ2D9LT7nSO1KMe38ly,VBpIH2QSmvDGlA6TO3e)
		title = '_MOD_'+title
		UHXfFEWmlxMAnzju4 = title
		if '/q/' in url and ('الحلقة' in title or 'الحلقه' in title):
			E0w56WHxZPYGVvnTQ4O2t1C8DAjq = ffUFBJQ57j2XgoGeOLn9uwpC.findall('(.*?) الحلقة \d+',title,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			if E0w56WHxZPYGVvnTQ4O2t1C8DAjq: UHXfFEWmlxMAnzju4 = E0w56WHxZPYGVvnTQ4O2t1C8DAjq[0]
		if UHXfFEWmlxMAnzju4 not in KRmzvoWYyxfXw37SEh1Q:
			KRmzvoWYyxfXw37SEh1Q.append(UHXfFEWmlxMAnzju4)
			if '/q/' in url and ('الحلقة' in title or 'الحلقه' in title):
				zJLApFBcIhnSj('folder',nc3GLkA65oxOd+UHXfFEWmlxMAnzju4,c0cDhidBlOn7,13,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
				JJuQo1gq9vAtVe8k74HKsjUL2FcfZ = True
			elif 'series' in c0cDhidBlOn7:
				zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,11,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
				JJuQo1gq9vAtVe8k74HKsjUL2FcfZ = True
			else:
				zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,12,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
				JJuQo1gq9vAtVe8k74HKsjUL2FcfZ = True
	if JJuQo1gq9vAtVe8k74HKsjUL2FcfZ:
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('tsc_3d_button red.*?href="([^"]*)" title="([^"]*)"',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,aOZ3yVnsNlB974pR in items:
			url = cDTdfqVAF0BLGiX364IEwaZbr + c0cDhidBlOn7
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+aOZ3yVnsNlB974pR,url,11)
	return
def yIZWSuMpvs3(url):
	OO1cj2REUZHJ8x5V = Gc05Efm73C8s(K8DZxE74Afz52gBYbOMtpvql0RJma,url,cdZKMn68Pzg4,headers,True,'ALARAB-EPISODES-1st')
	uUlpK8jRfLE9tT17mVwZv5 = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(/series.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	HOCWKhxITtulVGX = cDTdfqVAF0BLGiX364IEwaZbr+uUlpK8jRfLE9tT17mVwZv5[0]
	xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = GDQUH4fN02sIt81mAcY(HOCWKhxITtulVGX)
	return
def RPZbqous7rtdy56LeI18Cv04AKHW(url):
	pcX7zxFRmsADwUr = []
	OO1cj2REUZHJ8x5V = Gc05Efm73C8s(AlfMBJhUD65to2WrQcb,url,cdZKMn68Pzg4,headers,True,'ALARAB-PLAY-1st')
	HOCWKhxITtulVGX = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="resp-iframe" src="(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if HOCWKhxITtulVGX:
		HOCWKhxITtulVGX = HOCWKhxITtulVGX[0]
		zz4ZPovUbyk5GEhNMs8JDnaVXftS = ffUFBJQ57j2XgoGeOLn9uwpC.findall('^(http.*?)(http.*?)$',HOCWKhxITtulVGX,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if zz4ZPovUbyk5GEhNMs8JDnaVXftS:
			XMkp5KNroQDVvUx73j9qus = zz4ZPovUbyk5GEhNMs8JDnaVXftS[0][0]
			a73XTdkw4MgYIzN2mt,YYeBuGpOIq = zz4ZPovUbyk5GEhNMs8JDnaVXftS[0][1].rsplit(KCQExdbYFqM,1)
			N8jUpQxY0rhtDAzbG4kOs9X = a73XTdkw4MgYIzN2mt+'?named=__watch'
			pcX7zxFRmsADwUr.append(N8jUpQxY0rhtDAzbG4kOs9X)
			GMmu2UjLcIOxW0wHaB1KoRyDs856 = XMkp5KNroQDVvUx73j9qus+YYeBuGpOIq
		else:
			JJPEReUDbt0QoWHkL21TA = Gc05Efm73C8s(r43t1YI9deXA5N,HOCWKhxITtulVGX,cdZKMn68Pzg4,headers,False,'ALARAB-PLAY-2nd')
			HOCWKhxITtulVGX = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"src": "(.*?)"',JJPEReUDbt0QoWHkL21TA,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			if HOCWKhxITtulVGX:
				HOCWKhxITtulVGX = HOCWKhxITtulVGX[0]+'?named=__watch__m3u8'
				pcX7zxFRmsADwUr.append(HOCWKhxITtulVGX)
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('searchBox(.*?)<style>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		HOCWKhxITtulVGX = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)"',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if HOCWKhxITtulVGX:
			HOCWKhxITtulVGX = HOCWKhxITtulVGX[0]+'?named=__watch'
			pcX7zxFRmsADwUr.append(HOCWKhxITtulVGX)
	import r0y4XTKznF
	r0y4XTKznF.noHliPXkcg3pJTdSauCvm5sU(pcX7zxFRmsADwUr,UkXlAzsMcamKJrEIgnxi6bWh,'video',url)
	return
def PfS7ciTjYdMg6L8():
	OO1cj2REUZHJ8x5V = Gc05Efm73C8s(r43t1YI9deXA5N,cDTdfqVAF0BLGiX364IEwaZbr,cdZKMn68Pzg4,headers,True,'ALARAB-RAMADAN-1st')
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('id="content_sec"(.*?)id="left_content"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
	items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?>(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	Olnc9FaTkGQRMVSfrhPbL82Wt = ffUFBJQ57j2XgoGeOLn9uwpC.findall('/ramadan([0-9]+)/',str(items),ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	Olnc9FaTkGQRMVSfrhPbL82Wt = Olnc9FaTkGQRMVSfrhPbL82Wt[0]
	for c0cDhidBlOn7,title in items:
		url = cDTdfqVAF0BLGiX364IEwaZbr+c0cDhidBlOn7
		title = title.strip(VBpIH2QSmvDGlA6TO3e)+VBpIH2QSmvDGlA6TO3e+Olnc9FaTkGQRMVSfrhPbL82Wt
		zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,url,11)
	return
def z4hetAJw3NaT9ROjG6xbZ5CHlW81(search):
	search,EL8zUgbXheot,showDialogs = qbIcHCMdkFKn21e(search)
	if search==cdZKMn68Pzg4: search = BzkmLuvJD9n25Pg()
	if search==cdZKMn68Pzg4: return
	nuKdVC6ePlg = search.replace(VBpIH2QSmvDGlA6TO3e,'+')
	url = cDTdfqVAF0BLGiX364IEwaZbr + "/q/" + nuKdVC6ePlg
	xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = GDQUH4fN02sIt81mAcY(url)
	return
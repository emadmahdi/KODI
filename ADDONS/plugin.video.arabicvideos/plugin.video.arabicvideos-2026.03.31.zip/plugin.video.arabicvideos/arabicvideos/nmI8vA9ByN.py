# -*- coding: utf-8 -*-
from RgJNGc7YMP import *
UkXlAzsMcamKJrEIgnxi6bWh = 'BOKRA'
nc3GLkA65oxOd = '_BKR_'
cDTdfqVAF0BLGiX364IEwaZbr = USuRxnPlV5.SITESURLS[UkXlAzsMcamKJrEIgnxi6bWh][0]
headers = {'User-Agent':cdZKMn68Pzg4}
cJWUPuDGM0Yybv5a9KnIrVzhH78 = ['افلام للكبار','بكرا TV']
def HHN5EpbszV3iA2m89hGSQjaPgUZy(mode,url,text):
	if   mode==370: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = kUq58vC7x9hWma164JejMKQ()
	elif mode==371: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = GDQUH4fN02sIt81mAcY(url,text)
	elif mode==372: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = RPZbqous7rtdy56LeI18Cv04AKHW(url)
	elif mode==374: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = rxJzPR1ApYK(url)
	elif mode==375: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = j1I2lbMUPf4GyTKRsuh(url)
	elif mode==376: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = Y98Kxwk71zbUGaXsgDSuLjfyE(0,url)
	elif mode==377: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = Y98Kxwk71zbUGaXsgDSuLjfyE(1,url)
	elif mode==379: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = z4hetAJw3NaT9ROjG6xbZ5CHlW81(text)
	else: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = False
	return xsGUcR3ef6glKY5hQwpFXEaSt2mrIz
def kUq58vC7x9hWma164JejMKQ():
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(r43t1YI9deXA5N,'GET',cDTdfqVAF0BLGiX364IEwaZbr,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'BOKRA-MENU-1st')
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'بحث في الموقع',cdZKMn68Pzg4,379,cdZKMn68Pzg4,cdZKMn68Pzg4,'_REMEMBERRESULTS_')
	zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('right-side(.*?)</ul>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)">(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,title in items:
			c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr+c0cDhidBlOn7
			if not any(value in title for value in cJWUPuDGM0Yybv5a9KnIrVzhH78):
				zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+title,c0cDhidBlOn7,371)
	zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+'المميزة',cDTdfqVAF0BLGiX364IEwaZbr,375)
	zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+'الأحدث',cDTdfqVAF0BLGiX364IEwaZbr,376)
	zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+'قائمة الممثلين',cDTdfqVAF0BLGiX364IEwaZbr,374)
	zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="container"(.*?)top-menu',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)">(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,title in items[7:]:
			title = title.strip(VBpIH2QSmvDGlA6TO3e)
			c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr+c0cDhidBlOn7
			if not any(value in title for value in cJWUPuDGM0Yybv5a9KnIrVzhH78):
				zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+title,c0cDhidBlOn7,371)
		for c0cDhidBlOn7,title in items[0:7]:
			title = title.strip(VBpIH2QSmvDGlA6TO3e)
			c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr+c0cDhidBlOn7
			if not any(value in title for value in cJWUPuDGM0Yybv5a9KnIrVzhH78):
				zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+title,c0cDhidBlOn7,371)
	return
def rxJzPR1ApYK(website=cdZKMn68Pzg4):
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(r43t1YI9deXA5N,'GET',cDTdfqVAF0BLGiX364IEwaZbr,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'BOKRA-ACTORSMENU-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="row cat Tags"(.*?)</div>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="([^"]*)" title="([^"]*)"',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,title in items:
			if 'http' in c0cDhidBlOn7: continue
			else: c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr+c0cDhidBlOn7
			if not any(value in title for value in cJWUPuDGM0Yybv5a9KnIrVzhH78):
				zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+title,c0cDhidBlOn7,371)
	return
def j1I2lbMUPf4GyTKRsuh(website=cdZKMn68Pzg4):
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(AlfMBJhUD65to2WrQcb,'GET',cDTdfqVAF0BLGiX364IEwaZbr,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'BOKRA-FEATURED-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"MainContent"(.*?)main-title2',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(/vidpage_.*?)".*? src="(.*?)".*?<h3>(.*?)</h3>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,title in items:
			c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr+c0cDhidBlOn7
			if not any(value in title for value in cJWUPuDGM0Yybv5a9KnIrVzhH78):
				y90BoFz8MA1ZThaSC2ILXHiK3OY6w = y90BoFz8MA1ZThaSC2ILXHiK3OY6w.replace('://',':///').replace(Tf2ZPslXS84Yw15aNkjQ7oOzqMc,KCQExdbYFqM).replace(VBpIH2QSmvDGlA6TO3e,'%20')
				zJLApFBcIhnSj('video',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+title,c0cDhidBlOn7,372,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
	return
def Y98Kxwk71zbUGaXsgDSuLjfyE(id,website=cdZKMn68Pzg4):
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(AlfMBJhUD65to2WrQcb,'GET',cDTdfqVAF0BLGiX364IEwaZbr,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'BOKRA-WATCHINGNOW-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('main-title2(.*?)class="row',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[id]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*? src="(.*?)".*?<h4>(.*?)</h4>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,title in items:
			c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr+c0cDhidBlOn7
			if not any(value in title for value in cJWUPuDGM0Yybv5a9KnIrVzhH78):
				y90BoFz8MA1ZThaSC2ILXHiK3OY6w = y90BoFz8MA1ZThaSC2ILXHiK3OY6w.replace('://',':///').replace(Tf2ZPslXS84Yw15aNkjQ7oOzqMc,KCQExdbYFqM).replace(VBpIH2QSmvDGlA6TO3e,'%20')
				zJLApFBcIhnSj('video',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+title,c0cDhidBlOn7,372,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
	return
def GDQUH4fN02sIt81mAcY(url,BWZvnMf70Pwma=cdZKMn68Pzg4):
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'BOKRA-TITLES-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	if 'vidpage_' in url:
		c0cDhidBlOn7 = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(/Album-.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if c0cDhidBlOn7:
			c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr+c0cDhidBlOn7[0]
			GDQUH4fN02sIt81mAcY(c0cDhidBlOn7)
			return
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class=" subcats"(.*?)class="col-md-3',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if BWZvnMf70Pwma==cdZKMn68Pzg4 and ppvsMqCHf8SEzxQg and ppvsMqCHf8SEzxQg[0].count('href')>1:
		zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'الجميع',url,371,cdZKMn68Pzg4,cdZKMn68Pzg4,'titles')
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="([^"]*)" title="([^"]*)"',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,title in items:
			c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr+KCQExdbYFqM+c0cDhidBlOn7
			title = title.strip(VBpIH2QSmvDGlA6TO3e)
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,371)
	else:
		KRmzvoWYyxfXw37SEh1Q = []
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="col-md-3(.*?)col-xs-12',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if not ppvsMqCHf8SEzxQg: ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="col-sm-8"(.*?)col-xs-12',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if ppvsMqCHf8SEzxQg:
			KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
			items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?src="(.*?)".*?<h4>(.*?)</h4>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			for c0cDhidBlOn7,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,title in items:
				c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr+c0cDhidBlOn7
				title = title.strip(VBpIH2QSmvDGlA6TO3e)
				y90BoFz8MA1ZThaSC2ILXHiK3OY6w = y90BoFz8MA1ZThaSC2ILXHiK3OY6w.replace('://',':///').replace(Tf2ZPslXS84Yw15aNkjQ7oOzqMc,KCQExdbYFqM).replace(VBpIH2QSmvDGlA6TO3e,'%20')
				if '/al_' in c0cDhidBlOn7:
					zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,371,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
				elif 'الحلقة' in title and ('/Cat-' in url or '/Search/' in url):
					E0w56WHxZPYGVvnTQ4O2t1C8DAjq = ffUFBJQ57j2XgoGeOLn9uwpC.findall('(.*?) - +الحلقة +\d+',title,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
					if E0w56WHxZPYGVvnTQ4O2t1C8DAjq: title = '_MOD_مسلسل '+E0w56WHxZPYGVvnTQ4O2t1C8DAjq[0]
					if title not in KRmzvoWYyxfXw37SEh1Q:
						KRmzvoWYyxfXw37SEh1Q.append(title)
						zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,371,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
				else: zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,372,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="pagination(.*?)</div>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if ppvsMqCHf8SEzxQg:
			KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
			items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="".*?href="(.*?)">(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			for c0cDhidBlOn7,title in items:
				c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr+c0cDhidBlOn7
				title = 'صفحة '+gbd90SjF2mZqf81IRDaTwJkWu(title)
				zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,371,cdZKMn68Pzg4,cdZKMn68Pzg4,'titles')
	return
def RPZbqous7rtdy56LeI18Cv04AKHW(url):
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(AlfMBJhUD65to2WrQcb,'GET',url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'BOKRA-PLAY-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	eVdYQAPy2Dm = ffUFBJQ57j2XgoGeOLn9uwpC.findall('label-success mrg-btm-5 ">(.*?)<',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if eVdYQAPy2Dm and bMOpKuUkQ5J2(UkXlAzsMcamKJrEIgnxi6bWh,url,eVdYQAPy2Dm): return
	N8jUpQxY0rhtDAzbG4kOs9X = cdZKMn68Pzg4
	HOCWKhxITtulVGX = ffUFBJQ57j2XgoGeOLn9uwpC.findall('var url = "(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if HOCWKhxITtulVGX: HOCWKhxITtulVGX = HOCWKhxITtulVGX[0]
	else: HOCWKhxITtulVGX = url.replace('/vidpage_','/Play/')
	if 'http' not in HOCWKhxITtulVGX: HOCWKhxITtulVGX = cDTdfqVAF0BLGiX364IEwaZbr+HOCWKhxITtulVGX
	HOCWKhxITtulVGX = HOCWKhxITtulVGX.strip('-')
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(qIOfxknj8DiBYboGtQN4v,'GET',HOCWKhxITtulVGX,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'BOKRA-PLAY-2nd')
	JJPEReUDbt0QoWHkL21TA = Zty0AsgQ5jpkTh91OW.content
	N8jUpQxY0rhtDAzbG4kOs9X = ffUFBJQ57j2XgoGeOLn9uwpC.findall('src="(.*?)"',JJPEReUDbt0QoWHkL21TA,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if N8jUpQxY0rhtDAzbG4kOs9X:
		N8jUpQxY0rhtDAzbG4kOs9X = N8jUpQxY0rhtDAzbG4kOs9X[-1]
		if 'http' not in N8jUpQxY0rhtDAzbG4kOs9X: N8jUpQxY0rhtDAzbG4kOs9X = 'http:'+N8jUpQxY0rhtDAzbG4kOs9X
		if '/PLAY/' not in HOCWKhxITtulVGX:
			if 'embed.min.js' in N8jUpQxY0rhtDAzbG4kOs9X:
				BBzpe7NgVnxtHJ59 = ffUFBJQ57j2XgoGeOLn9uwpC.findall('data-publisher-id="(.*?)" data-video-id="(.*?)"',JJPEReUDbt0QoWHkL21TA,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
				if BBzpe7NgVnxtHJ59:
					t6td3YbXDcrn5, kVEPw2XC9ov5UjA0zs = BBzpe7NgVnxtHJ59[0]
					N8jUpQxY0rhtDAzbG4kOs9X = CxlbPZwGTcH87e1sWhfSIz29uRUEpV(N8jUpQxY0rhtDAzbG4kOs9X,'url')+'/v2/'+t6td3YbXDcrn5+'/config/'+kVEPw2XC9ov5UjA0zs+'.json'
		import r0y4XTKznF
		r0y4XTKznF.noHliPXkcg3pJTdSauCvm5sU([N8jUpQxY0rhtDAzbG4kOs9X],UkXlAzsMcamKJrEIgnxi6bWh,'video',url)
	return
def z4hetAJw3NaT9ROjG6xbZ5CHlW81(search):
	search,EL8zUgbXheot,showDialogs = qbIcHCMdkFKn21e(search)
	if search==cdZKMn68Pzg4: search = BzkmLuvJD9n25Pg()
	if search==cdZKMn68Pzg4: return
	search = search.replace(VBpIH2QSmvDGlA6TO3e,'+')
	url = cDTdfqVAF0BLGiX364IEwaZbr+'/Search/'+search
	GDQUH4fN02sIt81mAcY(url)
	return
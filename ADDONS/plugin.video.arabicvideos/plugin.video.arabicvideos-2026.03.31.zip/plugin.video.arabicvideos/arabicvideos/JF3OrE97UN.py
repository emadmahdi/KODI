# -*- coding: utf-8 -*-
from RgJNGc7YMP import *
UkXlAzsMcamKJrEIgnxi6bWh = 'FASELHD1'
headers = {'User-Agent':cdZKMn68Pzg4}
nc3GLkA65oxOd = '_FH1_'
cDTdfqVAF0BLGiX364IEwaZbr = USuRxnPlV5.SITESURLS[UkXlAzsMcamKJrEIgnxi6bWh][0]
cJWUPuDGM0Yybv5a9KnIrVzhH78 = ['جوائز الأوسكار','المراجعات','wwe']
def HHN5EpbszV3iA2m89hGSQjaPgUZy(mode,url,text):
	if   mode==570: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = kUq58vC7x9hWma164JejMKQ()
	elif mode==571: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = GDQUH4fN02sIt81mAcY(url,text)
	elif mode==572: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = RPZbqous7rtdy56LeI18Cv04AKHW(url)
	elif mode==573: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = RRDJdY2uVAykMUN9Fr4v7E0nZKX(url,text)
	elif mode==576: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = wbR96iuFa7sg2E1ndcLxm()
	elif mode==579: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = z4hetAJw3NaT9ROjG6xbZ5CHlW81(text)
	else: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = False
	return xsGUcR3ef6glKY5hQwpFXEaSt2mrIz
def kUq58vC7x9hWma164JejMKQ():
	zJLApFBcIhnSj('link',nc3GLkA65oxOd+'لماذا الموقع بطيء',cdZKMn68Pzg4,576)
	u1P73L0UmkA4eaIBbCgZfrvRtJ,url = cDTdfqVAF0BLGiX364IEwaZbr,cDTdfqVAF0BLGiX364IEwaZbr
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'FASELHD1-MENU-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'بحث في الموقع',u1P73L0UmkA4eaIBbCgZfrvRtJ,579,cdZKMn68Pzg4,cdZKMn68Pzg4,'_REMEMBERRESULTS_')
	zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'المميزة',u1P73L0UmkA4eaIBbCgZfrvRtJ,571,cdZKMn68Pzg4,cdZKMn68Pzg4,'featured1')
	items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="h3">(.*?)<.*?href="(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	for title,c0cDhidBlOn7 in items:
		zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+title,c0cDhidBlOn7,571,cdZKMn68Pzg4,cdZKMn68Pzg4,'details1')
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"menu-primary"(.*?)</ul>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		BxyImC5vLNnH3Ro8 = ffUFBJQ57j2XgoGeOLn9uwpC.findall('<li (.*?)</li>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		jbenJ7lHqIFAzhidx93VsYtPNRSU = [cdZKMn68Pzg4,'أفلام: ','مسلسلات: ','برامج: ','آسيوي: ','أنمي: ']
		DXAlBvH2ITZoyunMU0Rq3pw7sx = 0
		for doSG8hTOgfkb0z7cn in BxyImC5vLNnH3Ro8:
			if DXAlBvH2ITZoyunMU0Rq3pw7sx>0: zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
			items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?>(.*?)<',doSG8hTOgfkb0z7cn,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			for c0cDhidBlOn7,title in items:
				if c0cDhidBlOn7=='#': continue
				if 'http' not in c0cDhidBlOn7: c0cDhidBlOn7 = u1P73L0UmkA4eaIBbCgZfrvRtJ+c0cDhidBlOn7
				if title==cdZKMn68Pzg4: continue
				if any(value in title.lower() for value in cJWUPuDGM0Yybv5a9KnIrVzhH78): continue
				title = jbenJ7lHqIFAzhidx93VsYtPNRSU[DXAlBvH2ITZoyunMU0Rq3pw7sx]+title
				zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+title,c0cDhidBlOn7,571,cdZKMn68Pzg4,cdZKMn68Pzg4,'details2')
			DXAlBvH2ITZoyunMU0Rq3pw7sx += 1
	return
def wbR96iuFa7sg2E1ndcLxm():
	NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,'موقع فاصل الأول بطيء من المصدر .. بسبب قيام أصحاب الموقع بإضافة فحص وتحقق أمني ضد هجوم البرامج وهجوم القراصنة على صفحات الموقع .. والوقت الضائع يذهب في محاولة تجاوز هذا الفحص واثبات أن هذا البرنامج هو مجرد متصفح للمواقع ولا يقوم بالهجوم على المواقع')
	return
def GDQUH4fN02sIt81mAcY(url,type=cdZKMn68Pzg4):
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'FASELHD1-TITLES-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	ll9vYSyie5kwbR16U0a2K = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="h4">(.*?)</div>(.*?)"container"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if not ll9vYSyie5kwbR16U0a2K: return
	if type=='filters':
		ppvsMqCHf8SEzxQg = [OO1cj2REUZHJ8x5V.replace('\\/',KCQExdbYFqM).replace('\\"','"')]
	elif type=='featured1':
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"homeSlide"(.*?)"container"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall(' src="(.*?)".*? href="(.*?)">(.*?)</a>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		SSBuJX4Z5QDCyA3eRGwWF9vqUaTl,zz4ZPovUbyk5GEhNMs8JDnaVXftS,Snu3TYPhdqbc = zip(*items)
		items = zip(zz4ZPovUbyk5GEhNMs8JDnaVXftS,SSBuJX4Z5QDCyA3eRGwWF9vqUaTl,Snu3TYPhdqbc)
	elif type=='featured2':
		title,KdWauEhgN6OQzjRVm1ro8tkB3 = ll9vYSyie5kwbR16U0a2K[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*? data-src="(.*?)".*? alt="(.*?)"',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	elif type=='details2' and len(ll9vYSyie5kwbR16U0a2K)>1:
		title = ll9vYSyie5kwbR16U0a2K[0][0]
		zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,url,571,cdZKMn68Pzg4,cdZKMn68Pzg4,'featured2')
		title = ll9vYSyie5kwbR16U0a2K[1][0]
		zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,url,571,cdZKMn68Pzg4,cdZKMn68Pzg4,'details3')
		return
	else:
		title,KdWauEhgN6OQzjRVm1ro8tkB3 = ll9vYSyie5kwbR16U0a2K[-1]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*? data-src="(.*?)".*?"h1">(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	KRmzvoWYyxfXw37SEh1Q = []
	for c0cDhidBlOn7,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,title in items:
		if any(value in title.lower() for value in cJWUPuDGM0Yybv5a9KnIrVzhH78): continue
		y90BoFz8MA1ZThaSC2ILXHiK3OY6w = XTL0AWmwbDJfGRNi(y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
		y90BoFz8MA1ZThaSC2ILXHiK3OY6w = y90BoFz8MA1ZThaSC2ILXHiK3OY6w.split('?resize=')[0]
		title = gbd90SjF2mZqf81IRDaTwJkWu(title)
		E0w56WHxZPYGVvnTQ4O2t1C8DAjq = ffUFBJQ57j2XgoGeOLn9uwpC.findall('(.*?) (الحلقة|حلقة).\d+',title,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if '/collections/' in c0cDhidBlOn7:
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,571,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
		elif E0w56WHxZPYGVvnTQ4O2t1C8DAjq and type==cdZKMn68Pzg4:
			title = '_MOD_'+E0w56WHxZPYGVvnTQ4O2t1C8DAjq[0][0]
			title = title.strip(' –')
			if title not in KRmzvoWYyxfXw37SEh1Q:
				zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,573,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
				KRmzvoWYyxfXw37SEh1Q.append(title)
		elif 'episodes/' in c0cDhidBlOn7 or 'movies/' in c0cDhidBlOn7 or 'hindi/' in c0cDhidBlOn7:
			zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,572,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
		else: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,573,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
	if type=='filters':
		TTHMO0LXA8IVRgukFC6d4B3rG7U = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"more_button_page":(.*?),',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if TTHMO0LXA8IVRgukFC6d4B3rG7U:
			count = TTHMO0LXA8IVRgukFC6d4B3rG7U[0]
			c0cDhidBlOn7 = url+'/offset/'+count
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'صفحة أخرى',c0cDhidBlOn7,571,cdZKMn68Pzg4,cdZKMn68Pzg4,'filters')
	elif 'details' in type:
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall("class='pagination(.*?)</div>",OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if ppvsMqCHf8SEzxQg:
			KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
			items = ffUFBJQ57j2XgoGeOLn9uwpC.findall("href='(.*?)'.*?>(.*?)<",KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			for c0cDhidBlOn7,title in items:
				title = 'صفحة '+gbd90SjF2mZqf81IRDaTwJkWu(title)
				zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,571,cdZKMn68Pzg4,cdZKMn68Pzg4,'details4')
	return
def RRDJdY2uVAykMUN9Fr4v7E0nZKX(url,type=cdZKMn68Pzg4):
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'FASELHD1-SEASONS_EPISODES-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	DFNaireZ7Akmt3syhvJfCRwdE5z = False
	if not type:
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"seasonList"(.*?)"container"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if ppvsMqCHf8SEzxQg:
			KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
			items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href = \'(.*?)\'.*? data-src="(.*?)".*?alt="(.*?)".*?"title">(.*?)</div>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			if len(items)>1:
				u1P73L0UmkA4eaIBbCgZfrvRtJ = CxlbPZwGTcH87e1sWhfSIz29uRUEpV(url,'url')
				DFNaireZ7Akmt3syhvJfCRwdE5z = True
				for c0cDhidBlOn7,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,name,title in items:
					name = gbd90SjF2mZqf81IRDaTwJkWu(name)
					if 'http' not in c0cDhidBlOn7: c0cDhidBlOn7 = u1P73L0UmkA4eaIBbCgZfrvRtJ+c0cDhidBlOn7
					title = name+' - '+title
					zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,573,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,cdZKMn68Pzg4,'episodes')
	if type=='episodes' or not DFNaireZ7Akmt3syhvJfCRwdE5z:
		fh6qmOxoiv1UPXZanLprDeMI8 = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"posterImg".*?src="(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if fh6qmOxoiv1UPXZanLprDeMI8: y90BoFz8MA1ZThaSC2ILXHiK3OY6w = fh6qmOxoiv1UPXZanLprDeMI8[0]
		else: y90BoFz8MA1ZThaSC2ILXHiK3OY6w = cdZKMn68Pzg4
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"epAll"(.*?)</div>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if ppvsMqCHf8SEzxQg:
			KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
			items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?>(.*?)</a>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			for c0cDhidBlOn7,title in items:
				title = title.strip(VBpIH2QSmvDGlA6TO3e)
				title = gbd90SjF2mZqf81IRDaTwJkWu(title)
				zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,572,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
	return
def RPZbqous7rtdy56LeI18Cv04AKHW(url):
	XFj0lV5yMtS67EwbCJ9oO,ivH6wA3K87bMu4CFDWZ,ZZnPUQW4BjTMhwc21o5JGVOLf = [],[],[]
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(AlfMBJhUD65to2WrQcb,'GET',url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'FASELHD1-PLAY-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	Vxmvwdp53LetBqA6ycNDGO = ffUFBJQ57j2XgoGeOLn9uwpC.findall('مستوى المشاهدة.*?">(.*?)</span>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if Vxmvwdp53LetBqA6ycNDGO:
		eVdYQAPy2Dm = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"tag">(.*?)</a>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if eVdYQAPy2Dm and bMOpKuUkQ5J2(UkXlAzsMcamKJrEIgnxi6bWh,url,eVdYQAPy2Dm): return
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"videoRow"(.*?)</div>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('src="(.*?)"',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7 in items:
			c0cDhidBlOn7 = c0cDhidBlOn7.split('&img=')[0]
			XFj0lV5yMtS67EwbCJ9oO.append(c0cDhidBlOn7+'?named=__embed')
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="streamHeader(.*?)</ul>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall("href = '(.*?)'.*?</i>(.*?)</a>",KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,name in items:
			c0cDhidBlOn7 = c0cDhidBlOn7.split('&img=')[0]
			name = name.strip(VBpIH2QSmvDGlA6TO3e)
			XFj0lV5yMtS67EwbCJ9oO.append(c0cDhidBlOn7+'?named='+name+'__watch')
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="downloadLinks(.*?)blackwindow',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?</span>(.*?)</a>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,name in items:
			c0cDhidBlOn7 = c0cDhidBlOn7.split('&img=')[0]
			XFj0lV5yMtS67EwbCJ9oO.append(c0cDhidBlOn7+'?named='+name+'__download')
	for we1gUShrJEsnv7Aq in XFj0lV5yMtS67EwbCJ9oO:
		c0cDhidBlOn7,name = we1gUShrJEsnv7Aq.split('?named')
		if c0cDhidBlOn7 not in ivH6wA3K87bMu4CFDWZ:
			ivH6wA3K87bMu4CFDWZ.append(c0cDhidBlOn7)
			ZZnPUQW4BjTMhwc21o5JGVOLf.append(we1gUShrJEsnv7Aq)
	import r0y4XTKznF
	r0y4XTKznF.noHliPXkcg3pJTdSauCvm5sU(ZZnPUQW4BjTMhwc21o5JGVOLf,UkXlAzsMcamKJrEIgnxi6bWh,'video',url)
	return
def z4hetAJw3NaT9ROjG6xbZ5CHlW81(search):
	search,EL8zUgbXheot,showDialogs = qbIcHCMdkFKn21e(search)
	if search==cdZKMn68Pzg4: search = BzkmLuvJD9n25Pg()
	if search==cdZKMn68Pzg4: return
	search = search.replace(VBpIH2QSmvDGlA6TO3e,'+')
	HOCWKhxITtulVGX = cDTdfqVAF0BLGiX364IEwaZbr+'/?s='+search
	GDQUH4fN02sIt81mAcY(HOCWKhxITtulVGX,'details5')
	return
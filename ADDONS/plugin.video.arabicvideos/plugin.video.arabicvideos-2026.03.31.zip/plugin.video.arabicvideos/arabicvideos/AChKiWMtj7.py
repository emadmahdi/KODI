﻿# -*- coding: utf-8 -*-
from RgJNGc7YMP import *
def HHN5EpbszV3iA2m89hGSQjaPgUZy(HHrpyfWjGC,OoU12hVxacz5Hb):
	if OoU12hVxacz5Hb==cdZKMn68Pzg4: return
	if HHrpyfWjGC==1:
		cNmJQf8sa9khHCglzLK0RSy5BVou = r8rEvwjH91KlNMhIZoAVdpRyWeDfcs.getCurrentWindowDialogId()
		WFBizY5NXgnq61 = r8rEvwjH91KlNMhIZoAVdpRyWeDfcs.Window(cNmJQf8sa9khHCglzLK0RSy5BVou)
		OoU12hVxacz5Hb = SN0Eo5O1njRg3WiQq26luk8d(OoU12hVxacz5Hb)
		WFBizY5NXgnq61.getControl(311).setLabel(OoU12hVxacz5Hb)
	if HHrpyfWjGC==0:
		ppWtKTjVzdQwmoqNi7E='X'
		if W5domCu6XrQUFkiPpa3bNLtHglG: tqrJuGd2jDNzKBRl715P9AI = isinstance(OoU12hVxacz5Hb,str)
		else: tqrJuGd2jDNzKBRl715P9AI = isinstance(OoU12hVxacz5Hb,unicode)
		if tqrJuGd2jDNzKBRl715P9AI==True: ppWtKTjVzdQwmoqNi7E='U'
		BYt7xGvacsR6TwUz=str(type(OoU12hVxacz5Hb))+VBpIH2QSmvDGlA6TO3e+OoU12hVxacz5Hb+VBpIH2QSmvDGlA6TO3e+ppWtKTjVzdQwmoqNi7E+VBpIH2QSmvDGlA6TO3e
		for WCqkctAYD2O3Hz7Fl8fKRS5 in range(0,len(OoU12hVxacz5Hb),1):
			BYt7xGvacsR6TwUz += hex(ord(OoU12hVxacz5Hb[WCqkctAYD2O3Hz7Fl8fKRS5])).replace('0x',cdZKMn68Pzg4)+VBpIH2QSmvDGlA6TO3e
		OoU12hVxacz5Hb = SN0Eo5O1njRg3WiQq26luk8d(OoU12hVxacz5Hb)
		ppWtKTjVzdQwmoqNi7E='X'
		if W5domCu6XrQUFkiPpa3bNLtHglG: tqrJuGd2jDNzKBRl715P9AI = isinstance(OoU12hVxacz5Hb, str)
		else: tqrJuGd2jDNzKBRl715P9AI = isinstance(OoU12hVxacz5Hb, unicode)
		if tqrJuGd2jDNzKBRl715P9AI==True: ppWtKTjVzdQwmoqNi7E='U'
		Qsjx01fPNCrdXqJM=str(type(OoU12hVxacz5Hb))+VBpIH2QSmvDGlA6TO3e+OoU12hVxacz5Hb+VBpIH2QSmvDGlA6TO3e+ppWtKTjVzdQwmoqNi7E+VBpIH2QSmvDGlA6TO3e
		for WCqkctAYD2O3Hz7Fl8fKRS5 in range(0,len(OoU12hVxacz5Hb),1):
			Qsjx01fPNCrdXqJM += hex(ord(OoU12hVxacz5Hb[WCqkctAYD2O3Hz7Fl8fKRS5])).replace('0x',cdZKMn68Pzg4)+VBpIH2QSmvDGlA6TO3e
	return
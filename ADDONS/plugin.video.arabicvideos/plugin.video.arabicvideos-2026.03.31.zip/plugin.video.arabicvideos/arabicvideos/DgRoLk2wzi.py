# -*- coding: utf-8 -*-
import sys as sjVE6XGymcf09qbiKODZdAC
LVpmDXhWH5wGKy1eqMB = sjVE6XGymcf09qbiKODZdAC.version_info [0] == 2
RGEuTe9PD7o45d2v = 2048
r3HIioGW0Nl = 7
def Brz09AF6apy52OuEq1s (ccr3g6sWvxSOqDiLJuF1Vf2KUtG):
	global YzIBLo1J4ZOCEPtjq
	SSzr8EskcFRLobZqtC2QeTyPg4Y = ord (ccr3g6sWvxSOqDiLJuF1Vf2KUtG [-1])
	JIf7wGht4BqbQ5Xik1mYTA3DeLvaPO = ccr3g6sWvxSOqDiLJuF1Vf2KUtG [:-1]
	ZYd0PzhKWmvFN5TfcQI = SSzr8EskcFRLobZqtC2QeTyPg4Y % len (JIf7wGht4BqbQ5Xik1mYTA3DeLvaPO)
	itRzfVamqWwLIynhGpDM4ZUe = JIf7wGht4BqbQ5Xik1mYTA3DeLvaPO [:ZYd0PzhKWmvFN5TfcQI] + JIf7wGht4BqbQ5Xik1mYTA3DeLvaPO [ZYd0PzhKWmvFN5TfcQI:]
	if LVpmDXhWH5wGKy1eqMB:
		MHSngXbpVZde6NiQc9IrCxt78 = unicode () .join ([unichr (ord (Ep0JIWsLABieR) - RGEuTe9PD7o45d2v - (D2bEPIlOQJy4dYntR3MCiKLusT + SSzr8EskcFRLobZqtC2QeTyPg4Y) % r3HIioGW0Nl) for D2bEPIlOQJy4dYntR3MCiKLusT, Ep0JIWsLABieR in enumerate (itRzfVamqWwLIynhGpDM4ZUe)])
	else:
		MHSngXbpVZde6NiQc9IrCxt78 = str () .join ([chr (ord (Ep0JIWsLABieR) - RGEuTe9PD7o45d2v - (D2bEPIlOQJy4dYntR3MCiKLusT + SSzr8EskcFRLobZqtC2QeTyPg4Y) % r3HIioGW0Nl) for D2bEPIlOQJy4dYntR3MCiKLusT, Ep0JIWsLABieR in enumerate (itRzfVamqWwLIynhGpDM4ZUe)])
	return eval (MHSngXbpVZde6NiQc9IrCxt78)
ObuCsdoDtKmhPLSMH8YGan,vbYokBuWlxeLDcdVNM60,J6jL2d7CKE0WA4lBXFPghR5eoxHb=Brz09AF6apy52OuEq1s,Brz09AF6apy52OuEq1s,Brz09AF6apy52OuEq1s
aNdix5gq7yeFHTMWhnzm8pX0Y16,dwiIAcPl04ey7Zv38Mz,zBGPHsxIiQmd7oTSORl9bAynr5kNq=J6jL2d7CKE0WA4lBXFPghR5eoxHb,vbYokBuWlxeLDcdVNM60,ObuCsdoDtKmhPLSMH8YGan
rbUkdYi32PJaRtnxhDvQs,TtyzcuW45VKA,LungQF89BqemOb32jJsZlW=zBGPHsxIiQmd7oTSORl9bAynr5kNq,dwiIAcPl04ey7Zv38Mz,aNdix5gq7yeFHTMWhnzm8pX0Y16
iRfoNckJs7Ibxzh5j92w8DSWF,NV3enkyQ7Rmp2LYAUagsCJz0ZP,HC9xWUMpBQJEuTteAqjd=LungQF89BqemOb32jJsZlW,TtyzcuW45VKA,rbUkdYi32PJaRtnxhDvQs
s8fcjBCSMxzAIkZQbJPga,AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu,liyzjA4RkEb1cT6fr5pGKdWNHOxM=HC9xWUMpBQJEuTteAqjd,NV3enkyQ7Rmp2LYAUagsCJz0ZP,iRfoNckJs7Ibxzh5j92w8DSWF
nfg30bHwd4aNV12SR7UjFck,Rsdai9xIEPcpuBMKOUwkTA05q,KNomgGw1kdMCBH=liyzjA4RkEb1cT6fr5pGKdWNHOxM,AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu,s8fcjBCSMxzAIkZQbJPga
SGazRxP3yBKZ15ILuch,YnHG75e2QWwo,S5fhsRT8JV=KNomgGw1kdMCBH,Rsdai9xIEPcpuBMKOUwkTA05q,nfg30bHwd4aNV12SR7UjFck
WupgNDhcjK1SiYsF5VLGb9w3loJqX,f8Ja1q5eO02B,xN4fKmsnyM3Y2=S5fhsRT8JV,YnHG75e2QWwo,SGazRxP3yBKZ15ILuch
uxE8MyoTRglrcaiQf,aar0zhDnJsOTP7EdgR16HIS29,opyTNwHgfqbZREWKU=xN4fKmsnyM3Y2,f8Ja1q5eO02B,WupgNDhcjK1SiYsF5VLGb9w3loJqX
On1WZJc6dtksqVNgSQ5GBAjuipe,AiCor1fIVTDxQUWwHe9vPR7,tRnTydV03Xfi7rbQ=opyTNwHgfqbZREWKU,aar0zhDnJsOTP7EdgR16HIS29,uxE8MyoTRglrcaiQf
LJPOQNK1mcG,k5oIaYyp2mnrLK49qhzS,zDek1IW37rq6UoKdwyRiAVpF=tRnTydV03Xfi7rbQ,AiCor1fIVTDxQUWwHe9vPR7,On1WZJc6dtksqVNgSQ5GBAjuipe
from RgJNGc7YMP import *
UkXlAzsMcamKJrEIgnxi6bWh = zDek1IW37rq6UoKdwyRiAVpF(u"ࠫࡈࡒࡅࡂࡐࡈࡖࠬࠀ")
nc3GLkA65oxOd = zDek1IW37rq6UoKdwyRiAVpF(u"ࠬࡥࡃࡍࡐࡢࠫࠁ")
eMd3kC6vszpWy4bTgKNB8OSHq5rF = YRESXadfbIy3khwqmL8WC.path.join(fEe9HrM7nOh6swT0a3WvFgq,aar0zhDnJsOTP7EdgR16HIS29(u"࠭ࡴࡦ࡯ࡳࠫࠂ"))
rWtfYlN1ABqb9QkEhivK = YRESXadfbIy3khwqmL8WC.path.join(fEe9HrM7nOh6swT0a3WvFgq,aar0zhDnJsOTP7EdgR16HIS29(u"ࠧࡱࡣࡦ࡯ࡦ࡭ࡥࡴࠩࠃ"))
z7yYGEl91653o = YRESXadfbIy3khwqmL8WC.path.join(vloHbRquyEe23snXIT9Y4SU6,J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪࠄ"),f8Ja1q5eO02B(u"ࠩࡗ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡸ࠭ࠅ"))
WUhp4iQxfcJI0t8DCELH = s8fcjBCSMxzAIkZQbJPga(u"ࠪ࠳ࡩࡧࡴࡢ࠱ࡶࡽࡸࡺࡥ࡮࠱ࡸࡷࡦ࡭ࡥࡴࡶࡤࡸࡸ࠭ࠆ")
ITsMViS25fZHqRL6ekwGujODP = vbYokBuWlxeLDcdVNM60(u"ࠫ࠴ࡪࡡࡵࡣ࠲ࡷࡾࡹࡴࡦ࡯࠲ࡨࡷࡵࡰࡣࡱࡻࠫࠇ")
vHdS06GzkTBZeXDwYWt = AiCor1fIVTDxQUWwHe9vPR7(u"ࠬ࠵ࡤࡢࡶࡤ࠳ࡹࡵ࡭ࡣࡵࡷࡳࡳ࡫ࡳࠨࠈ")
OdYyg46tiHkmjpWV = KNomgGw1kdMCBH(u"࠭࠯ࡥࡣࡷࡥ࠴ࡲ࡯ࡨࡩࡨࡶࠬࠉ")
B1Ba6L45DrJTn9qfkMU3S = On1WZJc6dtksqVNgSQ5GBAjuipe(u"ࠧ࠰ࡦࡤࡸࡦ࠵࡬ࡰࡩࠪࠊ")
KLWT9tesvn5wMBiFYjq7Oh = zDek1IW37rq6UoKdwyRiAVpF(u"ࠨ࠱ࡧࡥࡹࡧ࠯ࡢࡰࡵࠫࠋ")
qoJpwV21BCiYn3TuXGDhPldAOUWt9f = K5pmHUNSMri7k
LDi41sFaYrwWVnvJ = qq9xw1jKIVH5kuNGMsPLiCO6Rp0Zv
Jh6myGMOC4ujPdz5NsXHf = F9MkTV7CzlaIKDWZO8mujqE
def HHN5EpbszV3iA2m89hGSQjaPgUZy(HHrpyfWjGC):
	if   HHrpyfWjGC==tRnTydV03Xfi7rbQ(u"࠸࠶࠳ࣈ"): xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = HHcKXthSV2()
	elif HHrpyfWjGC==zDek1IW37rq6UoKdwyRiAVpF(u"࠹࠷࠵ࣉ"): xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = rVyWBlI4fZNiTcAz20O7(eMd3kC6vszpWy4bTgKNB8OSHq5rF,IZQbmFzLHDtXfc,IZQbmFzLHDtXfc);PMrUslANqw2fxGk3o(xsGUcR3ef6glKY5hQwpFXEaSt2mrIz)
	elif HHrpyfWjGC==opyTNwHgfqbZREWKU(u"࠺࠸࠷࣊"): xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = rVyWBlI4fZNiTcAz20O7(rWtfYlN1ABqb9QkEhivK,IZQbmFzLHDtXfc,IZQbmFzLHDtXfc);PMrUslANqw2fxGk3o(xsGUcR3ef6glKY5hQwpFXEaSt2mrIz)
	elif HHrpyfWjGC==vbYokBuWlxeLDcdVNM60(u"࠻࠹࠹࣋"): xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = rVyWBlI4fZNiTcAz20O7(z7yYGEl91653o,ksTLSoVGg0ht,IZQbmFzLHDtXfc);PMrUslANqw2fxGk3o(xsGUcR3ef6glKY5hQwpFXEaSt2mrIz)
	elif HHrpyfWjGC==tRnTydV03Xfi7rbQ(u"࠼࠺࠴࣌"): xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = HS87ZmzDFnd5E(IZQbmFzLHDtXfc);PMrUslANqw2fxGk3o(xsGUcR3ef6glKY5hQwpFXEaSt2mrIz)
	elif HHrpyfWjGC==vbYokBuWlxeLDcdVNM60(u"࠽࠴࠶࣍"): xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = jbVXdZwyStGLI0PpE49FqeAU(IZQbmFzLHDtXfc);PMrUslANqw2fxGk3o(xsGUcR3ef6glKY5hQwpFXEaSt2mrIz)
	elif HHrpyfWjGC==opyTNwHgfqbZREWKU(u"࠷࠵࠸࣎"): xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = k5HbpfqwZ4(IZQbmFzLHDtXfc);PMrUslANqw2fxGk3o(xsGUcR3ef6glKY5hQwpFXEaSt2mrIz)
	elif HHrpyfWjGC==liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"࠸࠷࠳࣏"): xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = gs7OVfCYhaGZmdEQTLr56S34b9kRo()
	elif HHrpyfWjGC==AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"࠹࠸࠵࣐"): xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = rVyWBlI4fZNiTcAz20O7(WUhp4iQxfcJI0t8DCELH,ksTLSoVGg0ht,IZQbmFzLHDtXfc);PMrUslANqw2fxGk3o(xsGUcR3ef6glKY5hQwpFXEaSt2mrIz)
	elif HHrpyfWjGC==dwiIAcPl04ey7Zv38Mz(u"࠺࠹࠷࣑"): xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = rVyWBlI4fZNiTcAz20O7(ITsMViS25fZHqRL6ekwGujODP,ksTLSoVGg0ht,IZQbmFzLHDtXfc);PMrUslANqw2fxGk3o(xsGUcR3ef6glKY5hQwpFXEaSt2mrIz)
	elif HHrpyfWjGC==liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"࠻࠺࠹࣒"): xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = rVyWBlI4fZNiTcAz20O7(vHdS06GzkTBZeXDwYWt,ksTLSoVGg0ht,IZQbmFzLHDtXfc);PMrUslANqw2fxGk3o(xsGUcR3ef6glKY5hQwpFXEaSt2mrIz)
	elif HHrpyfWjGC==Rsdai9xIEPcpuBMKOUwkTA05q(u"࠼࠻࠴࣓"): xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = rVyWBlI4fZNiTcAz20O7(OdYyg46tiHkmjpWV,ksTLSoVGg0ht,IZQbmFzLHDtXfc);PMrUslANqw2fxGk3o(xsGUcR3ef6glKY5hQwpFXEaSt2mrIz)
	elif HHrpyfWjGC==AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"࠽࠵࠶ࣔ"): xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = rVyWBlI4fZNiTcAz20O7(B1Ba6L45DrJTn9qfkMU3S,ksTLSoVGg0ht,IZQbmFzLHDtXfc);PMrUslANqw2fxGk3o(xsGUcR3ef6glKY5hQwpFXEaSt2mrIz)
	elif HHrpyfWjGC==On1WZJc6dtksqVNgSQ5GBAjuipe(u"࠷࠶࠸ࣕ"): xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = rVyWBlI4fZNiTcAz20O7(KLWT9tesvn5wMBiFYjq7Oh,ksTLSoVGg0ht,IZQbmFzLHDtXfc);PMrUslANqw2fxGk3o(xsGUcR3ef6glKY5hQwpFXEaSt2mrIz)
	elif HHrpyfWjGC==vbYokBuWlxeLDcdVNM60(u"࠸࠷࠺ࣖ"): xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = wBDJP3UACqYkm(IZQbmFzLHDtXfc);PMrUslANqw2fxGk3o(xsGUcR3ef6glKY5hQwpFXEaSt2mrIz)
	elif HHrpyfWjGC==s8fcjBCSMxzAIkZQbJPga(u"࠹࠸࠼ࣗ"): xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = DXPhNQ50C1ZA8FswrOJnfmo2LdT();PMrUslANqw2fxGk3o(xsGUcR3ef6glKY5hQwpFXEaSt2mrIz)
	elif HHrpyfWjGC==NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"࠴࠴࠽࠶ࣘ"): xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = L8VKNTfk1aA7Yntw0Fb()
	elif HHrpyfWjGC==ObuCsdoDtKmhPLSMH8YGan(u"࠵࠵࠾࠱ࣙ"): xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = kbHeaNcylqruYmTigwF36ZM284(IZQbmFzLHDtXfc);PMrUslANqw2fxGk3o(xsGUcR3ef6glKY5hQwpFXEaSt2mrIz)
	elif HHrpyfWjGC==vbYokBuWlxeLDcdVNM60(u"࠶࠶࠸࠳ࣚ"): xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = MV7fUc3rXRlqznWxT();PMrUslANqw2fxGk3o(xsGUcR3ef6glKY5hQwpFXEaSt2mrIz)
	elif HHrpyfWjGC==YnHG75e2QWwo(u"࠷࠰࠹࠵ࣛ"): xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = TTofdnrZij0Fq();PMrUslANqw2fxGk3o(xsGUcR3ef6glKY5hQwpFXEaSt2mrIz)
	elif HHrpyfWjGC==LungQF89BqemOb32jJsZlW(u"࠱࠱࠺࠷ࣜ"): xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = MjFqBwelI93f0mVR2k();PMrUslANqw2fxGk3o(xsGUcR3ef6glKY5hQwpFXEaSt2mrIz)
	elif HHrpyfWjGC==opyTNwHgfqbZREWKU(u"࠲࠲࠻࠹ࣝ"): xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = kUq58vC7x9hWma164JejMKQ()
	elif HHrpyfWjGC==nfg30bHwd4aNV12SR7UjFck(u"࠳࠳࠼࠻ࣞ"): xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = a416YVBxbsSyA0eMjZiFzop9c()
	else: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = ksTLSoVGg0ht
	return xsGUcR3ef6glKY5hQwpFXEaSt2mrIz
def a416YVBxbsSyA0eMjZiFzop9c():
	xlj2AYD4RmQg = HC9xWUMpBQJEuTteAqjd(u"࠴࠴࠷࠺ࣟ")*HC9xWUMpBQJEuTteAqjd(u"࠴࠴࠷࠺ࣟ")
	cXifm7wjTnyk2CN53OoLlJp1WZBg6 = DDIHrSF2Ue65Tasq8E1mPQZVbiw()//xlj2AYD4RmQg
	YSKuGky28Vcgi4 = cXifm7wjTnyk2CN53OoLlJp1WZBg6<ObuCsdoDtKmhPLSMH8YGan(u"࠹࠵࣠")
	size = Gzygq01Kcb9U3+f8Ja1q5eO02B(u"ࠩ็ำ๏้ࠠๆีสัฮࠦแศำ฽อࠥࠦࠧࠌ")+str(cXifm7wjTnyk2CN53OoLlJp1WZBg6)+YnHG75e2QWwo(u"ࠪࠤ๋๊ࠥอษหห๏ะࠧࠍ")+kH8E2zqNyims6KJfI
	if YSKuGky28Vcgi4:
		SsziMZd5UbeL2NRxVpwjO(E7lrS9VXJF58d2NUAfkvxwjmHM,YnHG75e2QWwo(u"ࠫࡈࡎࡅࡄࡍࡢࡈࡎ࡙ࡋࡠࡕࡓࡅࡈࡋࠠࠡࠢࡖࡘࡔࡘࡁࡈࡇࠣࡍࡘࠦࡆࡖࡎࡏࠤࠥࠦࠧࠎ")+str(cXifm7wjTnyk2CN53OoLlJp1WZBg6)+SGazRxP3yBKZ15ILuch(u"ࠬࠦࡍࡃࠢࠤࠥࠬࠏ"))
		NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"࠭ๅิษะอࠥอไหะี๎๋ࠦแ๋ࠢฯ๋ฬุใࠡลุฬาะࠠๆ็อ่หฯࠠ࠯࠰ࠣ์์ึวࠡ์ึฬอࠦๅีษๆ่้ࠥห๋ำฬࠤๆ๐ࠠหึ฽๎้ࠦวๅฮ๊หื่ࠦหึ฽๎้ࠦใ้ัํࠤํะิ฻์็ࠤอืๆศ็ฯࠤ฾๋วะࠢ࠱࠲ࠥอๆหࠢหัฬาษࠡว็ํࠥะๆู์ไࠤัํวำๅࠣ์ฯ์ื๋ใࠣ็ํี๊๊ࠡอ๊฽๐แ้ࠡำหࠥอไษำ้ห๊า࡜࡯࡞ࡱࠫࠐ")+size)
	else: NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,YnHG75e2QWwo(u"ࠧๆีสัฮࠦวๅฬัึ๏์ࠠโ์ࠣะ์อาไࠢฯ๎ิฯ࡜࡯࡞ࡱࠫࠑ")+size)
	return YSKuGky28Vcgi4
def PMrUslANqw2fxGk3o(HHeEVvc1f8GdySwYqml):
	if HHeEVvc1f8GdySwYqml: XfABsbKWoLhI(IZQbmFzLHDtXfc)
	return
def kUq58vC7x9hWma164JejMKQ():
	zJLApFBcIhnSj(liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠨ࡮࡬ࡲࡰ࠭ࠒ"),NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠩไัฺࠦๅิษะอࠥอไหะี๎๋࠭ࠓ"),cdZKMn68Pzg4,SGazRxP3yBKZ15ILuch(u"࠶࠶࠸࠷࣡"))
	zJLApFBcIhnSj(YnHG75e2QWwo(u"ࠪࡪࡴࡲࡤࡦࡴࠪࠔ"),LungQF89BqemOb32jJsZlW(u"ࠫฯ์ุ๋ใࠣห้า็ศิࠪࠕ"),cdZKMn68Pzg4,rbUkdYi32PJaRtnxhDvQs(u"࠽࠵࠱࣢"))
	zJLApFBcIhnSj(On1WZJc6dtksqVNgSQ5GBAjuipe(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬࠖ"),nfg30bHwd4aNV12SR7UjFck(u"࠭สแ่฻๎ๆࠦใแ๊า๎ࠬࠗ"),cdZKMn68Pzg4,WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"࠷࠵࠲ࣣ"))
	zJLApFBcIhnSj(rbUkdYi32PJaRtnxhDvQs(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ࠘"),LJPOQNK1mcG(u"ࠨฬ้฼๏็ࠠศๆหี๋อๅอࠩ࠙"),cdZKMn68Pzg4,rbUkdYi32PJaRtnxhDvQs(u"࠲࠲࠻࠴ࣤ"))
	return
def L8VKNTfk1aA7Yntw0Fb():
	h2Kiv4gyLX,VMi3Iu64LEt7eUDmC5yWawJ = Bng6ey4pPxvab1HAmTc0GYDX(qoJpwV21BCiYn3TuXGDhPldAOUWt9f)
	P4y0w7oiZuR9TAkVfSpGjH,C0TyB9oGzLkAQ2a5EegZSh1lUY = Bng6ey4pPxvab1HAmTc0GYDX(LDi41sFaYrwWVnvJ)
	E80dqRhw2QUgCapnWj4FkIXOlvDi7G,ra7bxSJwoVWHyi = s98szN34g6bnYvpl(Jh6myGMOC4ujPdz5NsXHf)
	h9j3FGRdIYfnzEiCxMgJa02ut,DhlcabOfxCXFqrUys4iWIwZJGBH6S = h2Kiv4gyLX+P4y0w7oiZuR9TAkVfSpGjH+E80dqRhw2QUgCapnWj4FkIXOlvDi7G,VMi3Iu64LEt7eUDmC5yWawJ+C0TyB9oGzLkAQ2a5EegZSh1lUY+ra7bxSJwoVWHyi
	HFQMr5LnAugP7OXjxlDZyK8a6 = aar0zhDnJsOTP7EdgR16HIS29(u"ࠩࠣࠬࠬࠚ")+h6hcI8umP4XSfvOqHkiDbZECoeG(h2Kiv4gyLX)+k5oIaYyp2mnrLK49qhzS(u"ࠪࠤ࠲ࠦࠧࠛ")+str(VMi3Iu64LEt7eUDmC5yWawJ)+ObuCsdoDtKmhPLSMH8YGan(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬࠜ")
	Xs12JCWGlgmSoHTjAqrFZafE = s8fcjBCSMxzAIkZQbJPga(u"ࠬࠦࠨࠨࠝ")+h6hcI8umP4XSfvOqHkiDbZECoeG(P4y0w7oiZuR9TAkVfSpGjH)+opyTNwHgfqbZREWKU(u"࠭ࠠ࠮ࠢࠪࠞ")+str(C0TyB9oGzLkAQ2a5EegZSh1lUY)+xN4fKmsnyM3Y2(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨࠟ")
	FPe3p2mDIBucVrxb7zaiMj1SEKfO = zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"ࠨࠢࠫࠫࠠ")+h6hcI8umP4XSfvOqHkiDbZECoeG(E80dqRhw2QUgCapnWj4FkIXOlvDi7G)+On1WZJc6dtksqVNgSQ5GBAjuipe(u"ࠩࠣ࠱ࠥ࠭ࠡ")+str(ra7bxSJwoVWHyi)+LungQF89BqemOb32jJsZlW(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࠢ")
	kNaDQVAMRI2pPECTFwotxb = vbYokBuWlxeLDcdVNM60(u"ࠫࠥ࠮ࠧࠣ")+h6hcI8umP4XSfvOqHkiDbZECoeG(h9j3FGRdIYfnzEiCxMgJa02ut)+TtyzcuW45VKA(u"ࠬࠦ࠭ࠡࠩࠤ")+str(DhlcabOfxCXFqrUys4iWIwZJGBH6S)+S5fhsRT8JV(u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧࠥ")
	zJLApFBcIhnSj(Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠧ࡭࡫ࡱ࡯ࠬࠦ"),nc3GLkA65oxOd+On1WZJc6dtksqVNgSQ5GBAjuipe(u"ࠨ็ึัࠥอไอ็ํ฽ࠬࠧ")+kNaDQVAMRI2pPECTFwotxb,cdZKMn68Pzg4,On1WZJc6dtksqVNgSQ5GBAjuipe(u"࠳࠳࠼࠹ࣥ"))
	zJLApFBcIhnSj(tRnTydV03Xfi7rbQ(u"ࠩ࡯࡭ࡳࡱࠧࠨ"),Gzygq01Kcb9U3+f8Ja1q5eO02B(u"ࠪࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡࠩࠩ")+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,HC9xWUMpBQJEuTteAqjd(u"࠼࠽࠾࠿ࣦ"))
	zJLApFBcIhnSj(ObuCsdoDtKmhPLSMH8YGan(u"ࠫࡱ࡯࡮࡬ࠩࠪ"),nc3GLkA65oxOd+NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"๋ࠬำฮุࠢ์ึࠦวๅๅอหอฯࠧࠫ")+HFQMr5LnAugP7OXjxlDZyK8a6,cdZKMn68Pzg4,NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"࠵࠵࠾࠱ࣧ"))
	zJLApFBcIhnSj(k5oIaYyp2mnrLK49qhzS(u"࠭࡬ࡪࡰ࡮ࠫࠬ"),nc3GLkA65oxOd+k5oIaYyp2mnrLK49qhzS(u"ࠧๆีะࠤ่อิࠡษ็ฬึ์วๆฮࠪ࠭")+Xs12JCWGlgmSoHTjAqrFZafE,cdZKMn68Pzg4,KNomgGw1kdMCBH(u"࠶࠶࠸࠳ࣨ"))
	zJLApFBcIhnSj(liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠨ࡮࡬ࡲࡰ࠭࠮"),nc3GLkA65oxOd+uxE8MyoTRglrcaiQf(u"่ࠩืาࠦลฺัสำฬะࠠศๆหี๋อๅอࠩ࠯")+FPe3p2mDIBucVrxb7zaiMj1SEKfO,cdZKMn68Pzg4,nfg30bHwd4aNV12SR7UjFck(u"࠷࠰࠹࠵ࣩ"))
	zJLApFBcIhnSj(KNomgGw1kdMCBH(u"ࠪࡰ࡮ࡴ࡫ࠨ࠰"),nc3GLkA65oxOd+LungQF89BqemOb32jJsZlW(u"ࠫฯ฻แ๋ำࠣห้ฮั็ษ่ะࠬ࠱")+kNaDQVAMRI2pPECTFwotxb,cdZKMn68Pzg4,LJPOQNK1mcG(u"࠱࠱࠺࠷࣪"))
	return
def MjFqBwelI93f0mVR2k():
	HHeEVvc1f8GdySwYqml = ksTLSoVGg0ht
	BoyIUWYSNR0jhDxQwvJriO4PkL = JyLdvftP3CU(cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,SGazRxP3yBKZ15ILuch(u"ࠬํไࠡฬิ๎ิࠦแฺๆสࠤู๊อࠡฮ่๎฾ࠦลฺัสำฬะࠠศๆหี๋อๅอࠢ࠱࠲ࠥ๎ๅิฯࠣะ๊๐ูࠡ็็ๅฬะࠠศๆหี๋อๅอࠢส่็ี๊ๆหࠣ࠲࠳ࠦอห๋ࠣ๎฾๎ฯࠡษ็ฬึ์วๆฮࠣษ้๏ࠠฮษ็อࠥอไึใิࠤ࠳࠴๋ࠠ฻้๎ࠥำวๅหࠣ์฻฿๊สูࠢฬ฼ࠦวๅ็ุ๊฾ࠦ࠮࠯ࠢํ฽๋๐ࠠศๆะห้ฯࠠศๆอ๎ࠥ๎ึฺ้สࠤฬ๊ๅษำ่ะ๊ࠥไษำ้ห๊าࠠ࠯࠰๋ࠣีํࠠศๆ฼้้๐ษࠡฬอ้ࠥฮๅิฯ้ࠣั๊ฯࠡๅสุࠥอไษำ้ห๊า้ࠠ็ึั๋ࠥไโࠢศ฽ิอฯศฬࠣห้ฮั็ษ่ะࠥลࠡࠨ࠲"))
	if BoyIUWYSNR0jhDxQwvJriO4PkL:
		SsYq7jANyx0uvECgOaFWorXmbkl = TTofdnrZij0Fq()
		kNusMe15zCJwaGlIRjyLDTirdxO72 = rVyWBlI4fZNiTcAz20O7(qq9xw1jKIVH5kuNGMsPLiCO6Rp0Zv,IZQbmFzLHDtXfc,ksTLSoVGg0ht)
		HHeEVvc1f8GdySwYqml = SsYq7jANyx0uvECgOaFWorXmbkl and kNusMe15zCJwaGlIRjyLDTirdxO72
		if HHeEVvc1f8GdySwYqml: NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,uxE8MyoTRglrcaiQf(u"࠭ฬ๋ัࠣ࠲࠳ࠦๆอฯอࠤ฾๋ไ๋หุ้ࠣำࠠศๆ่่ๆอสࠡษ็ๆิ๐ๅสࠢ็่อืๆศ็ฯࠤ࠳࠴้ࠠ฻สำࠥอไษำ้ห๊าࠠฦๆ์ࠤํ฼ู๋หࠣห้฻แาࠢ࠱࠲ࠥ๎ึฺ์ฬࠤ฻ฮืࠡษ็ฺ้์ูࠨ࠳"))
		else: NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,TtyzcuW45VKA(u"ࠧๅๆฦืๆࠦ࠮࠯ࠢไุ้ะฺࠠ็็๎ฮࠦสึใํีࠥอไษำ้ห๊า้ࠠว฼หิะ็ࠡว็ํࠥ๎ึฺ์ฬࠤ฻ฮืࠡษ็ฺ้์ูࠨ࠴"))
	return HHeEVvc1f8GdySwYqml
def MV7fUc3rXRlqznWxT():
	import u4uJhElogI
	u4uJhElogI.gfnlUZx9iFVL()
	Q0AOX4cEgius9e = ksTLSoVGg0ht
	BoyIUWYSNR0jhDxQwvJriO4PkL = JyLdvftP3CU(SGazRxP3yBKZ15ILuch(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ࠵"),cdZKMn68Pzg4,cdZKMn68Pzg4,SGazRxP3yBKZ15ILuch(u"๊่ࠩࠥะั๋ัุ้ࠣำࠠอ็ํ฽ࠥอไไษืࠤฤ࠭࠶"),J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠪห้้วีࠢํืึ฿ฺࠠ็็ࠤฬ๊ศา่ส้ั่ࠦๆีะ๋ࠥ๐ู๋ัࠣืาฮࠠศๆุๅาอสࠡ็้ࠤฬ๊ล็ฬิ๊ฯูࠦ็ัࠣห้ำวอหࠣษ้๐็ศࠢ࠱࠲ࠥ฿ไๆษࠣว๋ࠦวๅ็ึัࠥ๐สๆࠢอ่็อฦ๋ษࠣ฽๋ีࠠศ่อ๋ฬวฺࠠ็ิࠤฬ๊ีโฯสฮࠥ࠴࠮๊ࠡฦ๎฻อࠠศๆ่ืาࠦไศࠢํฺึ่ࠦๆ็ๆ๊ࠥ๐อๅࠢห฽฻ࠦวๅ็ืห่๊ࠧ࠷"))
	if BoyIUWYSNR0jhDxQwvJriO4PkL==hiuZa0PIsErm6UC7:
		Q0AOX4cEgius9e = rVyWBlI4fZNiTcAz20O7(qq9xw1jKIVH5kuNGMsPLiCO6Rp0Zv,IZQbmFzLHDtXfc,ksTLSoVGg0ht)
		if Q0AOX4cEgius9e: NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,nfg30bHwd4aNV12SR7UjFck(u"ࠫา๐ฯࠡ࠰࠱ࠤ๋าอหࠢ฼้้๐ษࠡ็ึั๋ࠥฬๅัࠣ็ฬฺࠠศๆหี๋อๅอࠩ࠸"))
		else: NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,SGazRxP3yBKZ15ILuch(u"๊ࠬไฤีไࠤ࠳࠴ࠠโึ็ฮࠥ฿ๅๅ์ฬࠤู๊อࠡ็ฯ่ิࠦใศึࠣห้ฮั็ษ่ะࠬ࠹"))
	return Q0AOX4cEgius9e
def TTofdnrZij0Fq():
	Q0AOX4cEgius9e = ksTLSoVGg0ht
	BoyIUWYSNR0jhDxQwvJriO4PkL = JyLdvftP3CU(AiCor1fIVTDxQUWwHe9vPR7(u"࠭ࡣࡦࡰࡷࡩࡷ࠭࠺"),cdZKMn68Pzg4,cdZKMn68Pzg4,f8Ja1q5eO02B(u"ࠧิฦส่ࠬ࠻"),dwiIAcPl04ey7Zv38Mz(u"ࠨ้็ࠤศ์สࠡ็อว่ี้ࠠฬิ๎ิࠦๅิฯࠣ์ฯ฻แ๋ำࠣะ๊๐ูࠡว฼ำฬีวหࠢหี๋อๅอࠢ฼้ฬีࠠๅๆไ๎ิ๐่่ษอࠤฬู๊าสํอࠥ࠴ࠠฮ์ฮࠤฯ฿่ะࠢฯ้๏฿ࠠศๆศ฽ิอฯศฬࠣษ้๏ุ้ࠠ฼๎ฮࠦสฬสํฮࠥอไษำ้ห๊าࠠภࠩ࠼"))
	if BoyIUWYSNR0jhDxQwvJriO4PkL==hiuZa0PIsErm6UC7:
		try:
			YRESXadfbIy3khwqmL8WC.remove(F9MkTV7CzlaIKDWZO8mujqE)
			Q0AOX4cEgius9e = IZQbmFzLHDtXfc
		except: pass
		if Q0AOX4cEgius9e: NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,SGazRxP3yBKZ15ILuch(u"ࠩอ้ࠥฮๆอษะࠤู๊อ๊ࠡอูๆ๐ัࠡ็็ๅࠥหูะษาหฯࠦศา่ส้ัูࠦๆษาࠤ้๊แ๋ัํ์์อสࠡษ็฽ึฮ๊สࠩ࠽"))
		else: NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,vbYokBuWlxeLDcdVNM60(u"่้ࠪษำโࠢไุ้ะฺࠠ็็๎ฮࠦๅิฯ้้ࠣ็ࠠศๆศ฽ิอฯศฬࠪ࠾"))
	return Q0AOX4cEgius9e
def L8VKNTfk1aA7Yntw0Fb():
	h2Kiv4gyLX,VMi3Iu64LEt7eUDmC5yWawJ = Bng6ey4pPxvab1HAmTc0GYDX(qoJpwV21BCiYn3TuXGDhPldAOUWt9f)
	P4y0w7oiZuR9TAkVfSpGjH,C0TyB9oGzLkAQ2a5EegZSh1lUY = Bng6ey4pPxvab1HAmTc0GYDX(LDi41sFaYrwWVnvJ)
	E80dqRhw2QUgCapnWj4FkIXOlvDi7G,ra7bxSJwoVWHyi = s98szN34g6bnYvpl(Jh6myGMOC4ujPdz5NsXHf)
	h9j3FGRdIYfnzEiCxMgJa02ut,DhlcabOfxCXFqrUys4iWIwZJGBH6S = h2Kiv4gyLX+P4y0w7oiZuR9TAkVfSpGjH+E80dqRhw2QUgCapnWj4FkIXOlvDi7G,VMi3Iu64LEt7eUDmC5yWawJ+C0TyB9oGzLkAQ2a5EegZSh1lUY+ra7bxSJwoVWHyi
	HFQMr5LnAugP7OXjxlDZyK8a6 = dwiIAcPl04ey7Zv38Mz(u"ࠫࠥ࠮ࠧ࠿")+h6hcI8umP4XSfvOqHkiDbZECoeG(h2Kiv4gyLX)+SGazRxP3yBKZ15ILuch(u"ࠬࠦ࠭ࠡࠩࡀ")+str(VMi3Iu64LEt7eUDmC5yWawJ)+tRnTydV03Xfi7rbQ(u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧࡁ")
	Xs12JCWGlgmSoHTjAqrFZafE = TtyzcuW45VKA(u"ࠧࠡࠪࠪࡂ")+h6hcI8umP4XSfvOqHkiDbZECoeG(P4y0w7oiZuR9TAkVfSpGjH)+liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠨࠢ࠰ࠤࠬࡃ")+str(C0TyB9oGzLkAQ2a5EegZSh1lUY)+HC9xWUMpBQJEuTteAqjd(u"ࠩࠣࡪ࡮ࡲࡥࡴࠫࠪࡄ")
	FPe3p2mDIBucVrxb7zaiMj1SEKfO = aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠪࠤ࠭࠭ࡅ")+h6hcI8umP4XSfvOqHkiDbZECoeG(E80dqRhw2QUgCapnWj4FkIXOlvDi7G)+Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠫࠥ࠳ࠠࠨࡆ")+str(ra7bxSJwoVWHyi)+rbUkdYi32PJaRtnxhDvQs(u"ࠬࠦࡦࡪ࡮ࡨࡷ࠮࠭ࡇ")
	kNaDQVAMRI2pPECTFwotxb = zDek1IW37rq6UoKdwyRiAVpF(u"࠭ࠠࠩࠩࡈ")+h6hcI8umP4XSfvOqHkiDbZECoeG(h9j3FGRdIYfnzEiCxMgJa02ut)+Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠧࠡ࠯ࠣࠫࡉ")+str(DhlcabOfxCXFqrUys4iWIwZJGBH6S)+TtyzcuW45VKA(u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩࡊ")
	zJLApFBcIhnSj(dwiIAcPl04ey7Zv38Mz(u"ࠩ࡯࡭ࡳࡱࠧࡋ"),nc3GLkA65oxOd+YnHG75e2QWwo(u"ุ้ࠪำࠠศๆฯ้๏฿ࠧࡌ")+kNaDQVAMRI2pPECTFwotxb,cdZKMn68Pzg4,TtyzcuW45VKA(u"࠲࠲࠻࠸࣫"))
	zJLApFBcIhnSj(nfg30bHwd4aNV12SR7UjFck(u"ࠫࡱ࡯࡮࡬ࠩࡍ"),Gzygq01Kcb9U3+NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠬࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫࡎ")+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,f8Ja1q5eO02B(u"࠻࠼࠽࠾࣬"))
	zJLApFBcIhnSj(liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"࠭࡬ࡪࡰ࡮ࠫࡏ"),nc3GLkA65oxOd+vbYokBuWlxeLDcdVNM60(u"ࠧๆีะࠤฺ๎ัࠡษ็็ฯอศสࠩࡐ")+HFQMr5LnAugP7OXjxlDZyK8a6,cdZKMn68Pzg4,k5oIaYyp2mnrLK49qhzS(u"࠴࠴࠽࠷࣭"))
	zJLApFBcIhnSj(ObuCsdoDtKmhPLSMH8YGan(u"ࠨ࡮࡬ࡲࡰ࠭ࡑ"),nc3GLkA65oxOd+ObuCsdoDtKmhPLSMH8YGan(u"่ࠩืาࠦใศึࠣห้ฮั็ษ่ะࠬࡒ")+Xs12JCWGlgmSoHTjAqrFZafE,cdZKMn68Pzg4,liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"࠵࠵࠾࠲࣮"))
	zJLApFBcIhnSj(HC9xWUMpBQJEuTteAqjd(u"ࠪࡰ࡮ࡴ࡫ࠨࡓ"),nc3GLkA65oxOd+nfg30bHwd4aNV12SR7UjFck(u"ู๊ࠫอࠡว฼ำฬีวหࠢส่อืๆศ็ฯࠫࡔ")+FPe3p2mDIBucVrxb7zaiMj1SEKfO,cdZKMn68Pzg4,xN4fKmsnyM3Y2(u"࠶࠶࠸࠴࣯"))
	zJLApFBcIhnSj(ObuCsdoDtKmhPLSMH8YGan(u"ࠬࡲࡩ࡯࡭ࠪࡕ"),nc3GLkA65oxOd+J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"࠭สึใํีࠥอไษำ้ห๊าࠧࡖ")+kNaDQVAMRI2pPECTFwotxb,cdZKMn68Pzg4,uxE8MyoTRglrcaiQf(u"࠷࠰࠹࠶ࣰ"))
	return
def HHcKXthSV2():
	h2Kiv4gyLX,VMi3Iu64LEt7eUDmC5yWawJ = Bng6ey4pPxvab1HAmTc0GYDX(eMd3kC6vszpWy4bTgKNB8OSHq5rF)
	P4y0w7oiZuR9TAkVfSpGjH,C0TyB9oGzLkAQ2a5EegZSh1lUY = Bng6ey4pPxvab1HAmTc0GYDX(rWtfYlN1ABqb9QkEhivK)
	E80dqRhw2QUgCapnWj4FkIXOlvDi7G,ra7bxSJwoVWHyi = Bng6ey4pPxvab1HAmTc0GYDX(z7yYGEl91653o)
	h9j3FGRdIYfnzEiCxMgJa02ut,DhlcabOfxCXFqrUys4iWIwZJGBH6S = s98szN34g6bnYvpl(nTGfL65XPoavs)
	h9j3FGRdIYfnzEiCxMgJa02ut -= s8fcjBCSMxzAIkZQbJPga(u"࠳࠷࠺࠹࠸ࣱ")
	DhlcabOfxCXFqrUys4iWIwZJGBH6S -= hiuZa0PIsErm6UC7
	O0ekN3yvUMwVlcqo17SsGut = str(YRESXadfbIy3khwqmL8WC.listdir(R0RUo3teYS8hPfOwcB4iJDKyIr))
	G7si02JAbgU38p = O0ekN3yvUMwVlcqo17SsGut.count(AiCor1fIVTDxQUWwHe9vPR7(u"ࠧ࡬ࡱࡧ࡭ࡤࡹࡴࡢࡥ࡮ࡸࡷࡧࡣࡦࠩࡗ"))+O0ekN3yvUMwVlcqo17SsGut.count(opyTNwHgfqbZREWKU(u"ࠨ࡭ࡲࡨ࡮ࡥࡣࡳࡣࡶ࡬ࡱࡵࡧࠨࡘ"))
	HFQMr5LnAugP7OXjxlDZyK8a6 = J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"࡙ࠩࠣࠬࠬ")+h6hcI8umP4XSfvOqHkiDbZECoeG(h2Kiv4gyLX)+aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠪࠤ࠲࡚ࠦࠧ")+str(VMi3Iu64LEt7eUDmC5yWawJ)+f8Ja1q5eO02B(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࡛࠭ࠬ")
	Xs12JCWGlgmSoHTjAqrFZafE = rbUkdYi32PJaRtnxhDvQs(u"ࠬࠦࠨࠨ࡜")+h6hcI8umP4XSfvOqHkiDbZECoeG(P4y0w7oiZuR9TAkVfSpGjH)+s8fcjBCSMxzAIkZQbJPga(u"࠭ࠠ࠮ࠢࠪ࡝")+str(C0TyB9oGzLkAQ2a5EegZSh1lUY)+aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨ࡞")
	FPe3p2mDIBucVrxb7zaiMj1SEKfO = AiCor1fIVTDxQUWwHe9vPR7(u"ࠨࠢࠫࠫ࡟")+h6hcI8umP4XSfvOqHkiDbZECoeG(E80dqRhw2QUgCapnWj4FkIXOlvDi7G)+aar0zhDnJsOTP7EdgR16HIS29(u"ࠩࠣ࠱ࠥ࠭ࡠ")+str(ra7bxSJwoVWHyi)+J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࡡ")
	kNaDQVAMRI2pPECTFwotxb = tRnTydV03Xfi7rbQ(u"ࠫࠥ࠮ࠧࡢ")+h6hcI8umP4XSfvOqHkiDbZECoeG(h9j3FGRdIYfnzEiCxMgJa02ut)+nfg30bHwd4aNV12SR7UjFck(u"ࠬ࠯ࠧࡣ")
	rSdj9YfRe5oiDzB6PKMuQvOF = YnHG75e2QWwo(u"࠭ࠠࠩࠩࡤ")+str(G7si02JAbgU38p)+nfg30bHwd4aNV12SR7UjFck(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨࡥ")
	pp4XO1uC9v = h2Kiv4gyLX+P4y0w7oiZuR9TAkVfSpGjH+E80dqRhw2QUgCapnWj4FkIXOlvDi7G+h9j3FGRdIYfnzEiCxMgJa02ut
	ATg1dc5byeWvr6pVzBPF = VMi3Iu64LEt7eUDmC5yWawJ+C0TyB9oGzLkAQ2a5EegZSh1lUY+ra7bxSJwoVWHyi+DhlcabOfxCXFqrUys4iWIwZJGBH6S+G7si02JAbgU38p
	JAYWBoz54tGw7O = f8Ja1q5eO02B(u"ࠨࠢࠫࠫࡦ")+h6hcI8umP4XSfvOqHkiDbZECoeG(pp4XO1uC9v)+LJPOQNK1mcG(u"ࠩࠣ࠱ࠥ࠭ࡧ")+str(ATg1dc5byeWvr6pVzBPF)+AiCor1fIVTDxQUWwHe9vPR7(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࡨ")
	zJLApFBcIhnSj(TtyzcuW45VKA(u"ࠫࡱ࡯࡮࡬ࠩࡩ"),nc3GLkA65oxOd+HC9xWUMpBQJEuTteAqjd(u"๋ࠬำฮࠢส่ัฺ๋๊ࠩࡪ")+JAYWBoz54tGw7O,cdZKMn68Pzg4,opyTNwHgfqbZREWKU(u"࠸࠶࠸ࣲ"))
	zJLApFBcIhnSj(opyTNwHgfqbZREWKU(u"࠭࡬ࡪࡰ࡮ࠫ࡫"),Gzygq01Kcb9U3+ObuCsdoDtKmhPLSMH8YGan(u"ࠧࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥ࠭࡬")+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,s8fcjBCSMxzAIkZQbJPga(u"࠻࠼࠽࠾ࣳ"))
	zJLApFBcIhnSj(LJPOQNK1mcG(u"ࠨ࡮࡬ࡲࡰ࠭࡭"),nc3GLkA65oxOd+zDek1IW37rq6UoKdwyRiAVpF(u"่ࠩืาࠦวๅ็็ๅฬะࠠศๆ่ศ็ะษࠨ࡮")+HFQMr5LnAugP7OXjxlDZyK8a6,cdZKMn68Pzg4,nfg30bHwd4aNV12SR7UjFck(u"࠺࠸࠶ࣴ"))
	zJLApFBcIhnSj(J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠪࡰ࡮ࡴ࡫ࠨ࡯"),nc3GLkA65oxOd+tRnTydV03Xfi7rbQ(u"ู๊ࠫอࠡษ็้้็วหࠢส่๊฼ฺู้ฬࠫࡰ")+Xs12JCWGlgmSoHTjAqrFZafE,cdZKMn68Pzg4,SGazRxP3yBKZ15ILuch(u"࠻࠹࠸ࣵ"))
	zJLApFBcIhnSj(aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠬࡲࡩ࡯࡭ࠪࡱ"),nc3GLkA65oxOd+f8Ja1q5eO02B(u"࠭ๅิฯࠣห้฻่าࠢส่็ี๊ๆหࠪࡲ")+FPe3p2mDIBucVrxb7zaiMj1SEKfO,cdZKMn68Pzg4,iRfoNckJs7Ibxzh5j92w8DSWF(u"࠼࠺࠳ࣶ"))
	zJLApFBcIhnSj(vbYokBuWlxeLDcdVNM60(u"ࠧ࡭࡫ࡱ࡯ࠬࡳ"),nc3GLkA65oxOd+J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠨฬไี๏เࠠๆๆไࠤฺ๎ัࠡษ็ษ฻อแศฬࠪࡴ")+kNaDQVAMRI2pPECTFwotxb,cdZKMn68Pzg4,WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"࠽࠴࠵ࣷ"))
	zJLApFBcIhnSj(aar0zhDnJsOTP7EdgR16HIS29(u"ࠩ࡯࡭ࡳࡱࠧࡵ"),nc3GLkA65oxOd+NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ุ้ࠪำࠠๆๆไหฯࠦวๅๅิหูࠦวๅ็วๆฯฯࠧࡶ")+rSdj9YfRe5oiDzB6PKMuQvOF,cdZKMn68Pzg4,YnHG75e2QWwo(u"࠷࠵࠸ࣸ"))
	return
def gs7OVfCYhaGZmdEQTLr56S34b9kRo():
	nnvsoPKL2JT83lAVZNchXQW0f = IZQbmFzLHDtXfc if KCQExdbYFqM in vloHbRquyEe23snXIT9Y4SU6 else ksTLSoVGg0ht
	if not nnvsoPKL2JT83lAVZNchXQW0f:
		NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,f8Ja1q5eO02B(u"ࠫ฾๋ไ๋หࠣฮ๋฾๊โࠢส่ัํวำ่ࠢฮํ็ัสࠢไๆ฼ࠦไฤฮ๊ึฮ๊้่ࠦๆืࠥ࠴࠮ࠡ็ฮ่ࠥษฬ่ิฬࠤศฮไ๊ࠡฦ๊ิื่๋ัࠣ์้๐่็ๅึࠤ࠳࠴้ࠠฮ๊หื้ࠠๅ์ึࠤ๊์่ࠠาสࠤฬ๊ๆ้฻ࠪࡷ"))
		return
	HOPNDidJLzCxeK7IXS = Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.getSetting(J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡴࡨࡪࡷ࡫ࡳࡩࠩࡸ"))
	if not HOPNDidJLzCxeK7IXS: DXPhNQ50C1ZA8FswrOJnfmo2LdT()
	h2Kiv4gyLX,VMi3Iu64LEt7eUDmC5yWawJ = Bng6ey4pPxvab1HAmTc0GYDX(WUhp4iQxfcJI0t8DCELH)
	P4y0w7oiZuR9TAkVfSpGjH,C0TyB9oGzLkAQ2a5EegZSh1lUY = Bng6ey4pPxvab1HAmTc0GYDX(ITsMViS25fZHqRL6ekwGujODP)
	E80dqRhw2QUgCapnWj4FkIXOlvDi7G,ra7bxSJwoVWHyi = Bng6ey4pPxvab1HAmTc0GYDX(vHdS06GzkTBZeXDwYWt)
	h9j3FGRdIYfnzEiCxMgJa02ut,DhlcabOfxCXFqrUys4iWIwZJGBH6S = Bng6ey4pPxvab1HAmTc0GYDX(OdYyg46tiHkmjpWV)
	RgYroSskyJ0wBVM8A2,G7si02JAbgU38p = Bng6ey4pPxvab1HAmTc0GYDX(B1Ba6L45DrJTn9qfkMU3S)
	EEi4pXlMCo6J3,d86PHBEWkels3TG0cz = Bng6ey4pPxvab1HAmTc0GYDX(KLWT9tesvn5wMBiFYjq7Oh)
	HFQMr5LnAugP7OXjxlDZyK8a6 = ObuCsdoDtKmhPLSMH8YGan(u"࠭ࠠࠩࠩࡹ")+h6hcI8umP4XSfvOqHkiDbZECoeG(h2Kiv4gyLX)+rbUkdYi32PJaRtnxhDvQs(u"ࠧࠡ࠯ࠣࠫࡺ")+str(VMi3Iu64LEt7eUDmC5yWawJ)+Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩࡻ")
	Xs12JCWGlgmSoHTjAqrFZafE = s8fcjBCSMxzAIkZQbJPga(u"ࠩࠣࠬࠬࡼ")+h6hcI8umP4XSfvOqHkiDbZECoeG(P4y0w7oiZuR9TAkVfSpGjH)+nfg30bHwd4aNV12SR7UjFck(u"ࠪࠤ࠲ࠦࠧࡽ")+str(C0TyB9oGzLkAQ2a5EegZSh1lUY)+WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬࡾ")
	FPe3p2mDIBucVrxb7zaiMj1SEKfO = J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠬࠦࠨࠨࡿ")+h6hcI8umP4XSfvOqHkiDbZECoeG(E80dqRhw2QUgCapnWj4FkIXOlvDi7G)+opyTNwHgfqbZREWKU(u"࠭ࠠ࠮ࠢࠪࢀ")+str(ra7bxSJwoVWHyi)+LJPOQNK1mcG(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨࢁ")
	kNaDQVAMRI2pPECTFwotxb = zDek1IW37rq6UoKdwyRiAVpF(u"ࠨࠢࠫࠫࢂ")+h6hcI8umP4XSfvOqHkiDbZECoeG(h9j3FGRdIYfnzEiCxMgJa02ut)+J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠩࠣ࠱ࠥ࠭ࢃ")+str(DhlcabOfxCXFqrUys4iWIwZJGBH6S)+TtyzcuW45VKA(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࢄ")
	rSdj9YfRe5oiDzB6PKMuQvOF = SGazRxP3yBKZ15ILuch(u"ࠫࠥ࠮ࠧࢅ")+h6hcI8umP4XSfvOqHkiDbZECoeG(RgYroSskyJ0wBVM8A2)+iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠬࠦ࠭ࠡࠩࢆ")+str(G7si02JAbgU38p)+NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧࢇ")
	OuxVkIZMalHQY51SiJmWvtLj = k5oIaYyp2mnrLK49qhzS(u"ࠧࠡࠪࠪ࢈")+h6hcI8umP4XSfvOqHkiDbZECoeG(EEi4pXlMCo6J3)+s8fcjBCSMxzAIkZQbJPga(u"ࠨࠢ࠰ࠤࠬࢉ")+str(d86PHBEWkels3TG0cz)+LungQF89BqemOb32jJsZlW(u"ࠩࠣࡪ࡮ࡲࡥࡴࠫࠪࢊ")
	pp4XO1uC9v = h2Kiv4gyLX+P4y0w7oiZuR9TAkVfSpGjH+E80dqRhw2QUgCapnWj4FkIXOlvDi7G+h9j3FGRdIYfnzEiCxMgJa02ut+RgYroSskyJ0wBVM8A2+EEi4pXlMCo6J3
	ATg1dc5byeWvr6pVzBPF = VMi3Iu64LEt7eUDmC5yWawJ+C0TyB9oGzLkAQ2a5EegZSh1lUY+ra7bxSJwoVWHyi+DhlcabOfxCXFqrUys4iWIwZJGBH6S+G7si02JAbgU38p+d86PHBEWkels3TG0cz
	JAYWBoz54tGw7O = aar0zhDnJsOTP7EdgR16HIS29(u"ࠪࠤ࠭࠭ࢋ")+h6hcI8umP4XSfvOqHkiDbZECoeG(pp4XO1uC9v)+aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠫࠥ࠳ࠠࠨࢌ")+str(ATg1dc5byeWvr6pVzBPF)+aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠬࠦࡦࡪ࡮ࡨࡷ࠮࠭ࢍ")
	zJLApFBcIhnSj(dwiIAcPl04ey7Zv38Mz(u"࠭࡬ࡪࡰ࡮ࠫࢎ"),nc3GLkA65oxOd+J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠧฦ฻ฺหฦࠦัฯืฬࠤ็ืวยหࠣ์่ะวษหࠪ࢏"),cdZKMn68Pzg4,NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"࠸࠷࠻ࣹ"))
	zJLApFBcIhnSj(YnHG75e2QWwo(u"ࠨ࡮࡬ࡲࡰ࠭࢐"),nc3GLkA65oxOd+NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"่ࠩืาࠦวๅฮ่๎฾࠭࢑")+JAYWBoz54tGw7O,cdZKMn68Pzg4,On1WZJc6dtksqVNgSQ5GBAjuipe(u"࠹࠸࠻ࣺ"))
	zJLApFBcIhnSj(SGazRxP3yBKZ15ILuch(u"ࠪࡰ࡮ࡴ࡫ࠨ࢒"),Gzygq01Kcb9U3+k5oIaYyp2mnrLK49qhzS(u"ࠫࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࠪ࢓")+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,ObuCsdoDtKmhPLSMH8YGan(u"࠼࠽࠾࠿ࣻ"))
	zJLApFBcIhnSj(zDek1IW37rq6UoKdwyRiAVpF(u"ࠬࡲࡩ࡯࡭ࠪ࢔"),nc3GLkA65oxOd+rbUkdYi32PJaRtnxhDvQs(u"࠭ๅิฯ้้ࠣ็วหࠢࡸࡷࡦ࡭ࡥࡴࡶࡤࡸࡸ࠭࢕")+HFQMr5LnAugP7OXjxlDZyK8a6,cdZKMn68Pzg4,NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"࠻࠺࠷ࣼ"))
	zJLApFBcIhnSj(NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠧ࡭࡫ࡱ࡯ࠬ࢖"),nc3GLkA65oxOd+opyTNwHgfqbZREWKU(u"ࠨ็ึั๋ࠥไโษอࠤࡩࡸ࡯ࡱࡤࡲࡼࠬࢗ")+Xs12JCWGlgmSoHTjAqrFZafE,cdZKMn68Pzg4,zDek1IW37rq6UoKdwyRiAVpF(u"࠼࠻࠲ࣽ"))
	zJLApFBcIhnSj(nfg30bHwd4aNV12SR7UjFck(u"ࠩ࡯࡭ࡳࡱࠧ࢘"),nc3GLkA65oxOd+uxE8MyoTRglrcaiQf(u"ุ้ࠪำࠠๆๆไหฯࠦࡴࡰ࡯ࡥࡷࡹࡵ࡮ࡦࡵ࢙ࠪ")+FPe3p2mDIBucVrxb7zaiMj1SEKfO,cdZKMn68Pzg4,WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"࠽࠵࠴ࣾ"))
	zJLApFBcIhnSj(aar0zhDnJsOTP7EdgR16HIS29(u"ࠫࡱ࡯࡮࡬࢚ࠩ"),nc3GLkA65oxOd+xN4fKmsnyM3Y2(u"๋ࠬำฮ่่ࠢๆอสࠡ࡮ࡲ࡫࡬࡫ࡲࠨ࢛")+kNaDQVAMRI2pPECTFwotxb,cdZKMn68Pzg4,WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"࠷࠶࠶ࣿ"))
	zJLApFBcIhnSj(SGazRxP3yBKZ15ILuch(u"࠭࡬ࡪࡰ࡮ࠫ࢜"),nc3GLkA65oxOd+f8Ja1q5eO02B(u"ࠧๆีะࠤ๊๊แศฬࠣࡰࡴ࡭ࠧ࢝")+rSdj9YfRe5oiDzB6PKMuQvOF,cdZKMn68Pzg4,aNdix5gq7yeFHTMWhnzm8pX0Y16(u"࠸࠷࠸ऀ"))
	zJLApFBcIhnSj(zDek1IW37rq6UoKdwyRiAVpF(u"ࠨ࡮࡬ࡲࡰ࠭࢞"),nc3GLkA65oxOd+aar0zhDnJsOTP7EdgR16HIS29(u"่ࠩืาࠦๅๅใสฮࠥࡧ࡮ࡳࠩ࢟")+OuxVkIZMalHQY51SiJmWvtLj,cdZKMn68Pzg4,YnHG75e2QWwo(u"࠹࠸࠺ँ"))
	return
def kbHeaNcylqruYmTigwF36ZM284(showDialogs):
	if showDialogs: NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,vbYokBuWlxeLDcdVNM60(u"้ࠪั๊ฯࠡื๋ี้ࠥสศสฬࠤฬ๊โ้ษษ้ࠥ࠴࠮้ࠡำหࠥอไๆฮ็ำࠥ็๊่ࠢห฽฻ࠦโ้ษษ้ࠥอไษำ้ห๊าࠠๆะี๊ฮࠦศีๅ็ࠤฺ๎ัࠡสา่ฬࠦๅ็ࠢส่่ะวษหࠣ࠲࠳ูࠦ็ัุ้ࠣำࠠศๆ่ะ้ีࠠิ์ๅ์๊ࠦวๅสิ๊ฬ๋ฬࠡสั่็ࠦๅอๆาࠤัี๊ะ๋ࠢ๎อีรࠡ็ิอࠥษฮา๋ࠣฬ๊๊ฦ่ࠢหห้฻่าࠢ฼๊ิࠦแหฯࠣห้่่ศศ่ࠫࢠ"))
	crb5kHUnvqIwm,iij0mPMd37bA4qpwftEal2Ogr = [],nnsBpJv6XL3OzHoe4Vuhr
	for vF3EtnKrUj,D02LEnqMXR1zbWrS,YYlJvhFn4CuIRdQAK789 in YRESXadfbIy3khwqmL8WC.walk(K5pmHUNSMri7k,topdown=ksTLSoVGg0ht):
		ccO7DreaFkIiUmBLXR8T = len(YYlJvhFn4CuIRdQAK789)
		if ccO7DreaFkIiUmBLXR8T>S5fhsRT8JV(u"࠸࠴࠵ं"): crb5kHUnvqIwm.append(D02LEnqMXR1zbWrS)
		iij0mPMd37bA4qpwftEal2Ogr += ccO7DreaFkIiUmBLXR8T
	AA7vBM6IV3X = iij0mPMd37bA4qpwftEal2Ogr>KNomgGw1kdMCBH(u"࠹࠵࠶࠰ः")
	if showDialogs:
		count = Gzygq01Kcb9U3+s8fcjBCSMxzAIkZQbJPga(u"้ࠫี๊ไࠢࠣࠫࢡ")+str(iij0mPMd37bA4qpwftEal2Ogr)+vbYokBuWlxeLDcdVNM60(u"ࠬࠦࠠึ๊ิอࠬࢢ")+kH8E2zqNyims6KJfI
		if not crb5kHUnvqIwm and not AA7vBM6IV3X: BoyIUWYSNR0jhDxQwvJriO4PkL = JyLdvftP3CU(cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,zDek1IW37rq6UoKdwyRiAVpF(u"࠭ไศࠢํ์ัีฺ่ࠠา็ࠥ฻่าࠢๆฮฬฮษࠡๅฮ๎ึฯࠠ࠯࠰ࠣ์้ํะศࠢ็หࠥะอหษฯࠤศ์ࠠห็ึัࠥ฻่าࠢส่่ะวษหࠣ࠲࠳ࠦ็ๅࠢอี๏ีࠠๆีะࠤฺ๎ัࠡษ็็ฯอศสࠢส่ว์ࠠภࠣࠣࡠࡳࡢ࡮ࠨࢣ")+count)
		else: BoyIUWYSNR0jhDxQwvJriO4PkL = JyLdvftP3CU(cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"ࠧๅัํ็ࠥ฻่าࠢๆฮฬฮษࠡๅฮ๎ึฯࠠ࠯࠰ࠣ์์ึวࠡไาࠤ๏ูศษุ่ࠢฬ้ไࠡใํࠤฯฺฺ๋ๆࠣห้า็ศิࠣ์ฯฺฺ๋ๆࠣฬึ์วๆฮࠣ฽๊อฯࠡ࠰࠱ࠤศ์สࠡสะหัฯࠠฦๆ์ࠤู๊อ้ࠡำ๋ࠥอไึ๊ิࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡ็ึัࠥ฻่าࠢส่่ะวษหࠣห้ศๆࠡมࠤࠤࡡࡴ࡜࡯ࠩࢤ")+count)
	else: BoyIUWYSNR0jhDxQwvJriO4PkL = hiuZa0PIsErm6UC7
	if BoyIUWYSNR0jhDxQwvJriO4PkL==hiuZa0PIsErm6UC7:
		if AA7vBM6IV3X: rVyWBlI4fZNiTcAz20O7(vF3EtnKrUj,ksTLSoVGg0ht,ksTLSoVGg0ht)
		elif crb5kHUnvqIwm:
			for D02LEnqMXR1zbWrS in crb5kHUnvqIwm: rVyWBlI4fZNiTcAz20O7(D02LEnqMXR1zbWrS,ksTLSoVGg0ht,ksTLSoVGg0ht)
	return
def DXPhNQ50C1ZA8FswrOJnfmo2LdT():
	HHeEVvc1f8GdySwYqml = ksTLSoVGg0ht
	BoyIUWYSNR0jhDxQwvJriO4PkL = JyLdvftP3CU(cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,rbUkdYi32PJaRtnxhDvQs(u"ࠨๆๆ๎ࠥ๐ูๆๆࠣห้ะๆู์ไࠤ฾์ฯไࠢ࠱࠲ࠥฮั็ษ่ะࠥ฿ๅศัࠣฬาอฬสࠢศ่๎ࠦลฺูสลࠥืฮึหࠣห้่ัศรฬࠤํอไไฬสฬฮࠦไๅ็็ๅฬะ้ࠠษ็้ั๊ฯศฬࠣห้ะ๊ࠡี๋ๅࠥ๐ๅิฯ๊หࠥอไษำ้ห๊าࠠ࠯࠰๋้ࠣࠦสา์าࠤส฿ืศร๋ࠣีํࠠศๆิาฺฯࠠศๆล๊ࠥลࠡࠨࢥ"))
	if BoyIUWYSNR0jhDxQwvJriO4PkL==-uxE8MyoTRglrcaiQf(u"࠶ऄ"): return
	if BoyIUWYSNR0jhDxQwvJriO4PkL:
		import subprocess as VI8XxtKqZMUvNPGHr3zTYcF91yWe
		try:
			VI8XxtKqZMUvNPGHr3zTYcF91yWe.Popen(LJPOQNK1mcG(u"ࠩࡶࡹࠬࢦ"))
			HHeEVvc1f8GdySwYqml = IZQbmFzLHDtXfc
		except: pass
		if HHeEVvc1f8GdySwYqml:
			ABaNR4bDHPlz7kJLI1ni5pKU62VZYu = WUhp4iQxfcJI0t8DCELH+VBpIH2QSmvDGlA6TO3e+ITsMViS25fZHqRL6ekwGujODP+VBpIH2QSmvDGlA6TO3e+vHdS06GzkTBZeXDwYWt+VBpIH2QSmvDGlA6TO3e+OdYyg46tiHkmjpWV+VBpIH2QSmvDGlA6TO3e+B1Ba6L45DrJTn9qfkMU3S+VBpIH2QSmvDGlA6TO3e+KLWT9tesvn5wMBiFYjq7Oh
			eIv9OLdPxN1hyfgZ = VI8XxtKqZMUvNPGHr3zTYcF91yWe.Popen(iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠪࡷࡺࠦ࠭ࡤࠢࠥࡧ࡭ࡳ࡯ࡥࠢ࠰ࡖࠥ࠶࠷࠸࠹ࠣࠫࢧ")+ABaNR4bDHPlz7kJLI1ni5pKU62VZYu+tRnTydV03Xfi7rbQ(u"ࠫࠧ࠭ࢨ"),shell=IZQbmFzLHDtXfc,stdin=VI8XxtKqZMUvNPGHr3zTYcF91yWe.PIPE,stdout=VI8XxtKqZMUvNPGHr3zTYcF91yWe.PIPE,stderr=VI8XxtKqZMUvNPGHr3zTYcF91yWe.PIPE)
			NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠬ์ฬฮฬࠣ฽๊๊๊สࠢศ฽฼อมࠡษ็ีำ฻ษࠨࢩ"))
		else: NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"ู࠭ๆๆํอࠥหูุษฤࠤึิีสࠢส่็ืวยหࠣ์ฬ๊ใหษหอࠥะอหษฯࠤอืๆศ็ฯࠤࠥࡸ࡯ࡰࡶࠣࠤศ๎ࠠࠡࡵࡸࡴࡪࡸࡵࡴࡧࡵࠤࠥษ่ࠡࠢࡶࡹ่ࠥࠦอ้สึ่ࠦไศࠢํ์ัีࠠโ์๊ࠤ์ึวࠡษ็ฬึ์วๆฮࠣ࠲࠳ࠦร้ࠢๆ์ิ๐ࠠ฻์ิࠤ็อฯาࠢ฼่๎ࠦวิฬัำฬ๋่ࠠาสࠤฬ๊ศา่ส้ั࠭ࢪ"))
	return HHeEVvc1f8GdySwYqml
def h6hcI8umP4XSfvOqHkiDbZECoeG(pp4XO1uC9v):
	for Qeawx7nAh5RyHpv8Y4c6r9LSgE0X in [opyTNwHgfqbZREWKU(u"ࠧࡃࠩࢫ"),WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠨࡍࡅࠫࢬ"),nfg30bHwd4aNV12SR7UjFck(u"ࠩࡐࡆࠬࢭ"),AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"ࠪࡋࡇ࠭ࢮ"),liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"࡙ࠫࡈࠧࢯ")]:
		if pp4XO1uC9v<tRnTydV03Xfi7rbQ(u"࠷࠰࠳࠶अ"): break
		else: pp4XO1uC9v /= dwiIAcPl04ey7Zv38Mz(u"࠱࠱࠴࠷࠲࠵आ")
	JAYWBoz54tGw7O = LJPOQNK1mcG(u"ࠧࠫ࠳࠯࠳ࡩࠤࠪࡹࠢࢰ")%(pp4XO1uC9v,Qeawx7nAh5RyHpv8Y4c6r9LSgE0X)
	return JAYWBoz54tGw7O
def Bng6ey4pPxvab1HAmTc0GYDX(hMlpHBzZDnUiJf2dLXIT=LungQF89BqemOb32jJsZlW(u"࠭࠮ࠨࢱ")):
	global OIsAJc5KSi1BkxPD4oFWMC9,GGMxsRuyJ4qzpkiUFYZO3bQCavKD
	OIsAJc5KSi1BkxPD4oFWMC9,GGMxsRuyJ4qzpkiUFYZO3bQCavKD = nnsBpJv6XL3OzHoe4Vuhr,nnsBpJv6XL3OzHoe4Vuhr
	def T3pEnZgca5Cx0hSODoNj(hMlpHBzZDnUiJf2dLXIT):
		global OIsAJc5KSi1BkxPD4oFWMC9,GGMxsRuyJ4qzpkiUFYZO3bQCavKD
		if YRESXadfbIy3khwqmL8WC.path.exists(hMlpHBzZDnUiJf2dLXIT):
			if nnsBpJv6XL3OzHoe4Vuhr and TtyzcuW45VKA(u"ࠧࡴࡥࡤࡲࡩ࡯ࡲࠨࢲ") in dir(YRESXadfbIy3khwqmL8WC):
				for cT3eECpH5wkf96mRFjtaWzx in YRESXadfbIy3khwqmL8WC.scandir(hMlpHBzZDnUiJf2dLXIT):
					if cT3eECpH5wkf96mRFjtaWzx.is_dir(follow_symlinks=ksTLSoVGg0ht):
						T3pEnZgca5Cx0hSODoNj(cT3eECpH5wkf96mRFjtaWzx.path)
					elif cT3eECpH5wkf96mRFjtaWzx.is_file(follow_symlinks=ksTLSoVGg0ht):
						OIsAJc5KSi1BkxPD4oFWMC9 += cT3eECpH5wkf96mRFjtaWzx.stat().st_size
						GGMxsRuyJ4qzpkiUFYZO3bQCavKD += hiuZa0PIsErm6UC7
			else:
				for cT3eECpH5wkf96mRFjtaWzx in YRESXadfbIy3khwqmL8WC.listdir(hMlpHBzZDnUiJf2dLXIT):
					WCvBMm5PwUcyDobn1kRp8Aqt = YRESXadfbIy3khwqmL8WC.path.abspath(YRESXadfbIy3khwqmL8WC.path.join(hMlpHBzZDnUiJf2dLXIT,cT3eECpH5wkf96mRFjtaWzx))
					if YRESXadfbIy3khwqmL8WC.path.isdir(WCvBMm5PwUcyDobn1kRp8Aqt):
						T3pEnZgca5Cx0hSODoNj(WCvBMm5PwUcyDobn1kRp8Aqt)
					elif YRESXadfbIy3khwqmL8WC.path.isfile(WCvBMm5PwUcyDobn1kRp8Aqt):
						pp4XO1uC9v,ATg1dc5byeWvr6pVzBPF = s98szN34g6bnYvpl(WCvBMm5PwUcyDobn1kRp8Aqt)
						OIsAJc5KSi1BkxPD4oFWMC9 += pp4XO1uC9v
						GGMxsRuyJ4qzpkiUFYZO3bQCavKD += ATg1dc5byeWvr6pVzBPF
		return
	try: T3pEnZgca5Cx0hSODoNj(hMlpHBzZDnUiJf2dLXIT)
	except: pass
	return OIsAJc5KSi1BkxPD4oFWMC9,GGMxsRuyJ4qzpkiUFYZO3bQCavKD
def jbVXdZwyStGLI0PpE49FqeAU(showDialogs):
	if showDialogs:
		BoyIUWYSNR0jhDxQwvJriO4PkL = JyLdvftP3CU(cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,Gzygq01Kcb9U3+tRnTydV03Xfi7rbQ(u"ࠨ้็ࠤฯื๊ะ่ࠢืา࠭ࢳ")+ssELJkeScrtni2+opyTNwHgfqbZREWKU(u"่ࠩะ้ีࠠศๆ่่ๆอสࠡษ็้ษ่สสࠢ࠱࠲ࠥ๎ๅอๆาࠤฬ๊ๅๅใสฮࠥอไๆุ฽์฼ฯࠠ࠯࠰ࠣ์๊าไะࠢสฺ่๎ัࠡษ็ๆิ๐ๅสࠢ࠱࠲ࠥ๎สโำํ฾๋ࠥไโุࠢ์ึࠦวๅวูหๆอสࠡ࠰࠱ࠤํ๋ไโษอࠤฬ๊ใาษืࠫࢴ")+ssELJkeScrtni2+f8Ja1q5eO02B(u"ࠪรࠦࠧࠧࢵ")+kH8E2zqNyims6KJfI)
		if BoyIUWYSNR0jhDxQwvJriO4PkL!=hiuZa0PIsErm6UC7: return
	V6RhBkOq7LuF52C8pUxWDcMoJQSP = rVyWBlI4fZNiTcAz20O7(eMd3kC6vszpWy4bTgKNB8OSHq5rF,IZQbmFzLHDtXfc,ksTLSoVGg0ht)
	fg4oQ9KiMvkwjztLnI6 = rVyWBlI4fZNiTcAz20O7(rWtfYlN1ABqb9QkEhivK,IZQbmFzLHDtXfc,ksTLSoVGg0ht)
	QQrybWa4DAcYV0n2ki = rVyWBlI4fZNiTcAz20O7(z7yYGEl91653o,ksTLSoVGg0ht,ksTLSoVGg0ht)
	UTS7D0cMjOaQCEn = HS87ZmzDFnd5E(ksTLSoVGg0ht)
	sbq3y0SH5uk8tPKQWV = k5HbpfqwZ4(ksTLSoVGg0ht)
	succeeded = all([V6RhBkOq7LuF52C8pUxWDcMoJQSP,fg4oQ9KiMvkwjztLnI6,QQrybWa4DAcYV0n2ki,UTS7D0cMjOaQCEn,sbq3y0SH5uk8tPKQWV])
	if showDialogs:
		if succeeded: NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠫฯ๋ࠠศๆ่ืาࠦศ็ฮสัࠬࢶ"))
		else: NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,aar0zhDnJsOTP7EdgR16HIS29(u"๊ࠬไฤีไࠤๆฺไหࠢ฼้้๐ษࠡษ็ุ้ำࠧࢷ"))
	return succeeded
def wBDJP3UACqYkm(showDialogs):
	if showDialogs:
		ABaNR4bDHPlz7kJLI1ni5pKU62VZYu = WUhp4iQxfcJI0t8DCELH+ssELJkeScrtni2+ITsMViS25fZHqRL6ekwGujODP+ssELJkeScrtni2+vHdS06GzkTBZeXDwYWt+ssELJkeScrtni2+OdYyg46tiHkmjpWV+ssELJkeScrtni2+B1Ba6L45DrJTn9qfkMU3S+ssELJkeScrtni2+KLWT9tesvn5wMBiFYjq7Oh
		BoyIUWYSNR0jhDxQwvJriO4PkL = JyLdvftP3CU(cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,Gzygq01Kcb9U3+ObuCsdoDtKmhPLSMH8YGan(u"࠭็ๅࠢอี๏ีࠠๆีะࠤฬ๊ๅๅใสฮࠥอไๆฦๅฮฮࠦวๅฬํࠤๆ๐่ࠠา๊ࠤฬ๊ๅอๆาหฯࡢ࡮࡝ࡰࠪࢸ")+ABaNR4bDHPlz7kJLI1ni5pKU62VZYu+kH8E2zqNyims6KJfI)
		if BoyIUWYSNR0jhDxQwvJriO4PkL!=hiuZa0PIsErm6UC7: return
	V6RhBkOq7LuF52C8pUxWDcMoJQSP = rVyWBlI4fZNiTcAz20O7(WUhp4iQxfcJI0t8DCELH,ksTLSoVGg0ht,ksTLSoVGg0ht)
	fg4oQ9KiMvkwjztLnI6 = rVyWBlI4fZNiTcAz20O7(ITsMViS25fZHqRL6ekwGujODP,ksTLSoVGg0ht,ksTLSoVGg0ht)
	QQrybWa4DAcYV0n2ki = rVyWBlI4fZNiTcAz20O7(vHdS06GzkTBZeXDwYWt,ksTLSoVGg0ht,ksTLSoVGg0ht)
	UTS7D0cMjOaQCEn = rVyWBlI4fZNiTcAz20O7(OdYyg46tiHkmjpWV,ksTLSoVGg0ht,ksTLSoVGg0ht)
	sbq3y0SH5uk8tPKQWV = rVyWBlI4fZNiTcAz20O7(B1Ba6L45DrJTn9qfkMU3S,ksTLSoVGg0ht,ksTLSoVGg0ht)
	g4x0Y2fvzLjsBu7iDZnah8kdFIyUH = rVyWBlI4fZNiTcAz20O7(KLWT9tesvn5wMBiFYjq7Oh,ksTLSoVGg0ht,ksTLSoVGg0ht)
	succeeded = all([V6RhBkOq7LuF52C8pUxWDcMoJQSP,fg4oQ9KiMvkwjztLnI6,QQrybWa4DAcYV0n2ki,UTS7D0cMjOaQCEn,sbq3y0SH5uk8tPKQWV,g4x0Y2fvzLjsBu7iDZnah8kdFIyUH])
	if showDialogs:
		if succeeded: NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,On1WZJc6dtksqVNgSQ5GBAjuipe(u"ࠧห็ࠣห้๋ำฮࠢห๊ัออࠨࢹ"))
		else: NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,ObuCsdoDtKmhPLSMH8YGan(u"ࠨๆ็วุ็ࠠโึ็ฮࠥ฿ๅๅ์ฬࠤฬ๊ๅิฯࠪࢺ"))
	return succeeded
def HS87ZmzDFnd5E(showDialogs):
	if showDialogs:
		BoyIUWYSNR0jhDxQwvJriO4PkL = JyLdvftP3CU(cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,Gzygq01Kcb9U3+nfg30bHwd4aNV12SR7UjFck(u"๊่ࠩࠥะั๋ัุ้ࠣำࠠๆฯอ์๏อสࠡ็็ๅࠥ฻่าࠢส่ั๊ฯࠡมࠤࠥࠬࢻ")+kH8E2zqNyims6KJfI)
		if BoyIUWYSNR0jhDxQwvJriO4PkL!=tRnTydV03Xfi7rbQ(u"࠲इ"): return rbUkdYi32PJaRtnxhDvQs(u"ࡈࡤࡰࡸ࡫ई")
	try:
		succeeded = YnHG75e2QWwo(u"ࡗࡶࡺ࡫उ")
		ZZ9aGOKsMrV0nto8v5LNwCcHR = IDjorYsAdihx7QK.connect(nTGfL65XPoavs)
		ZZ9aGOKsMrV0nto8v5LNwCcHR.text_factory = str
		yjNYCMFrPXpAoZHGe7iUJ25g = ZZ9aGOKsMrV0nto8v5LNwCcHR.cursor()
		yjNYCMFrPXpAoZHGe7iUJ25g.execute(SGazRxP3yBKZ15ILuch(u"ࠪࡈࡊࡒࡅࡕࡇࠣࡊࡗࡕࡍࠡࡲࡤࡸ࡭ࡁࠧࢼ"))
		yjNYCMFrPXpAoZHGe7iUJ25g.execute(NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࡶ࡭ࡿ࡫ࡳ࠼ࠩࢽ"))
		yjNYCMFrPXpAoZHGe7iUJ25g.execute(liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࡸࡪࡾࡴࡶࡴࡨ࠿ࠬࢾ"))
		ZZ9aGOKsMrV0nto8v5LNwCcHR.commit()
		yjNYCMFrPXpAoZHGe7iUJ25g.execute(zDek1IW37rq6UoKdwyRiAVpF(u"࠭ࡖࡂࡅࡘ࡙ࡒࡁࠧࢿ"))
		ZZ9aGOKsMrV0nto8v5LNwCcHR.close()
	except: succeeded = nfg30bHwd4aNV12SR7UjFck(u"ࡊࡦࡲࡳࡦऊ")
	if showDialogs:
		if succeeded: NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,zDek1IW37rq6UoKdwyRiAVpF(u"ࠧห็ࠣห้๋ำฮࠢห๊ัออࠨࣀ"))
		else: NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,LungQF89BqemOb32jJsZlW(u"ࠨๆ็วุ็ࠠโึ็ฮࠥ฿ๅๅ์ฬࠤฬ๊ๅิฯࠪࣁ"))
	return succeeded
def k5HbpfqwZ4(showDialogs):
	if showDialogs:
		BoyIUWYSNR0jhDxQwvJriO4PkL = JyLdvftP3CU(cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"่่ࠩๆอสࠡษ็็ึอิ้ࠡํࠤ๊๊แศฬࠣ๎ฺ์ู่ษࠣ็ํี๊ࠡ฻้ำ๊อ๋ࠠ฼็ๆࠥ์แิ้ࠣฬฺ๎ัส่ࠢๅฬารสࠢ࠱࠲ࠥํะ่ࠢส่๊๊แศฬࠣ๎าะวอ้สࠤ๊ฮัๆฮํࠤ่๎ฯ๋ࠢะฮ๎ฺ๊ࠦำไ์๋ࠦๅ็้สࠤ่๐แࠡฯาฯฯࠦวๅ็ื็้ฯࠧࣂ")+ssELJkeScrtni2+ssELJkeScrtni2+Gzygq01Kcb9U3+KNomgGw1kdMCBH(u"๋้ࠪࠦสา์าࠤู๊อࠡ็็ๅฬะࠠศๆๆีฬฺࠠศๆ่ศ็ะษࠡมࠤࠥࠬࣃ")+kH8E2zqNyims6KJfI)
		if BoyIUWYSNR0jhDxQwvJriO4PkL!=hiuZa0PIsErm6UC7: return Rsdai9xIEPcpuBMKOUwkTA05q(u"ࡋࡧ࡬ࡴࡧऋ")
	succeeded = AiCor1fIVTDxQUWwHe9vPR7(u"࡚ࡲࡶࡧऌ")
	for file in YRESXadfbIy3khwqmL8WC.listdir(R0RUo3teYS8hPfOwcB4iJDKyIr):
		if On1WZJc6dtksqVNgSQ5GBAjuipe(u"ࠫࡰࡵࡤࡪࡡࡶࡸࡦࡩ࡫ࡵࡴࡤࡧࡪ࠭ࣄ") not in file and xN4fKmsnyM3Y2(u"ࠬࡱ࡯ࡥ࡫ࡢࡧࡷࡧࡳࡩ࡮ࡲ࡫ࠬࣅ") not in file: continue
		N0HoQAD7svJhVy = YRESXadfbIy3khwqmL8WC.path.join(R0RUo3teYS8hPfOwcB4iJDKyIr,file)
		try: YRESXadfbIy3khwqmL8WC.remove(N0HoQAD7svJhVy)
		except Exception as qe3QrYhHNZjlt481scSxJ:
			succeeded = s8fcjBCSMxzAIkZQbJPga(u"ࡆࡢ࡮ࡶࡩऍ")
			if showDialogs: NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,str(qe3QrYhHNZjlt481scSxJ))
	if showDialogs:
		if succeeded: NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,tRnTydV03Xfi7rbQ(u"࠭สๆࠢสู่๊อࠡส้ะฬำࠧࣆ"))
		else: NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠧๅๆฦืๆࠦแีๆอࠤ฾๋ไ๋หࠣห้๋ำฮࠩࣇ"))
	return succeeded
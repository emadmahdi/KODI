# -*- coding: utf-8 -*-
import sys as sjVE6XGymcf09qbiKODZdAC
LVpmDXhWH5wGKy1eqMB = sjVE6XGymcf09qbiKODZdAC.version_info [0] == 2
RGEuTe9PD7o45d2v = 2048
r3HIioGW0Nl = 7
def Brz09AF6apy52OuEq1s (ccr3g6sWvxSOqDiLJuF1Vf2KUtG):
	global YzIBLo1J4ZOCEPtjq
	SSzr8EskcFRLobZqtC2QeTyPg4Y = ord (ccr3g6sWvxSOqDiLJuF1Vf2KUtG [-1])
	JIf7wGht4BqbQ5Xik1mYTA3DeLvaPO = ccr3g6sWvxSOqDiLJuF1Vf2KUtG [:-1]
	ZYd0PzhKWmvFN5TfcQI = SSzr8EskcFRLobZqtC2QeTyPg4Y % len (JIf7wGht4BqbQ5Xik1mYTA3DeLvaPO)
	itRzfVamqWwLIynhGpDM4ZUe = JIf7wGht4BqbQ5Xik1mYTA3DeLvaPO [:ZYd0PzhKWmvFN5TfcQI] + JIf7wGht4BqbQ5Xik1mYTA3DeLvaPO [ZYd0PzhKWmvFN5TfcQI:]
	if LVpmDXhWH5wGKy1eqMB:
		MHSngXbpVZde6NiQc9IrCxt78 = unicode () .join ([unichr (ord (Ep0JIWsLABieR) - RGEuTe9PD7o45d2v - (D2bEPIlOQJy4dYntR3MCiKLusT + SSzr8EskcFRLobZqtC2QeTyPg4Y) % r3HIioGW0Nl) for D2bEPIlOQJy4dYntR3MCiKLusT, Ep0JIWsLABieR in enumerate (itRzfVamqWwLIynhGpDM4ZUe)])
	else:
		MHSngXbpVZde6NiQc9IrCxt78 = str () .join ([chr (ord (Ep0JIWsLABieR) - RGEuTe9PD7o45d2v - (D2bEPIlOQJy4dYntR3MCiKLusT + SSzr8EskcFRLobZqtC2QeTyPg4Y) % r3HIioGW0Nl) for D2bEPIlOQJy4dYntR3MCiKLusT, Ep0JIWsLABieR in enumerate (itRzfVamqWwLIynhGpDM4ZUe)])
	return eval (MHSngXbpVZde6NiQc9IrCxt78)
ObuCsdoDtKmhPLSMH8YGan,vbYokBuWlxeLDcdVNM60,J6jL2d7CKE0WA4lBXFPghR5eoxHb=Brz09AF6apy52OuEq1s,Brz09AF6apy52OuEq1s,Brz09AF6apy52OuEq1s
aNdix5gq7yeFHTMWhnzm8pX0Y16,dwiIAcPl04ey7Zv38Mz,zBGPHsxIiQmd7oTSORl9bAynr5kNq=J6jL2d7CKE0WA4lBXFPghR5eoxHb,vbYokBuWlxeLDcdVNM60,ObuCsdoDtKmhPLSMH8YGan
rbUkdYi32PJaRtnxhDvQs,TtyzcuW45VKA,LungQF89BqemOb32jJsZlW=zBGPHsxIiQmd7oTSORl9bAynr5kNq,dwiIAcPl04ey7Zv38Mz,aNdix5gq7yeFHTMWhnzm8pX0Y16
iRfoNckJs7Ibxzh5j92w8DSWF,NV3enkyQ7Rmp2LYAUagsCJz0ZP,HC9xWUMpBQJEuTteAqjd=LungQF89BqemOb32jJsZlW,TtyzcuW45VKA,rbUkdYi32PJaRtnxhDvQs
s8fcjBCSMxzAIkZQbJPga,AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu,liyzjA4RkEb1cT6fr5pGKdWNHOxM=HC9xWUMpBQJEuTteAqjd,NV3enkyQ7Rmp2LYAUagsCJz0ZP,iRfoNckJs7Ibxzh5j92w8DSWF
nfg30bHwd4aNV12SR7UjFck,Rsdai9xIEPcpuBMKOUwkTA05q,KNomgGw1kdMCBH=liyzjA4RkEb1cT6fr5pGKdWNHOxM,AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu,s8fcjBCSMxzAIkZQbJPga
SGazRxP3yBKZ15ILuch,YnHG75e2QWwo,S5fhsRT8JV=KNomgGw1kdMCBH,Rsdai9xIEPcpuBMKOUwkTA05q,nfg30bHwd4aNV12SR7UjFck
WupgNDhcjK1SiYsF5VLGb9w3loJqX,f8Ja1q5eO02B,xN4fKmsnyM3Y2=S5fhsRT8JV,YnHG75e2QWwo,SGazRxP3yBKZ15ILuch
uxE8MyoTRglrcaiQf,aar0zhDnJsOTP7EdgR16HIS29,opyTNwHgfqbZREWKU=xN4fKmsnyM3Y2,f8Ja1q5eO02B,WupgNDhcjK1SiYsF5VLGb9w3loJqX
On1WZJc6dtksqVNgSQ5GBAjuipe,AiCor1fIVTDxQUWwHe9vPR7,tRnTydV03Xfi7rbQ=opyTNwHgfqbZREWKU,aar0zhDnJsOTP7EdgR16HIS29,uxE8MyoTRglrcaiQf
LJPOQNK1mcG,k5oIaYyp2mnrLK49qhzS,zDek1IW37rq6UoKdwyRiAVpF=tRnTydV03Xfi7rbQ,AiCor1fIVTDxQUWwHe9vPR7,On1WZJc6dtksqVNgSQ5GBAjuipe
from kI5NbK0vO6 import *
class Za2BRWrGNboC(zz6bHTRC0W8DLnMsJ):
	def __init__(NQ27ID3mjHigVEAky6O9YWPbn,*aargs,**kkwargs):
		NQ27ID3mjHigVEAky6O9YWPbn.choiceID = -hiuZa0PIsErm6UC7
	def onClick(NQ27ID3mjHigVEAky6O9YWPbn,eeLToHBw4yvKhPV):
		if eeLToHBw4yvKhPV>=J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"࠹࠱࠳࠳౱"): NQ27ID3mjHigVEAky6O9YWPbn.choiceID = eeLToHBw4yvKhPV-J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"࠹࠱࠳࠳౱")
		NQ27ID3mjHigVEAky6O9YWPbn.ThtOMkNZeEDB5Jw()
	def SzHps5cgoryf9Ke2mbh4NO(NQ27ID3mjHigVEAky6O9YWPbn,*aargs):
		NQ27ID3mjHigVEAky6O9YWPbn.button0,NQ27ID3mjHigVEAky6O9YWPbn.button1,NQ27ID3mjHigVEAky6O9YWPbn.button2 = aargs[nnsBpJv6XL3OzHoe4Vuhr],aargs[hiuZa0PIsErm6UC7],aargs[bVX3ev1spE]
		NQ27ID3mjHigVEAky6O9YWPbn.header,NQ27ID3mjHigVEAky6O9YWPbn.text = aargs[kzoASbNraPcfgvWJmY9Qu],aargs[iwQJREcVTSe1G2gCvlfhbHWLjqopa]
		NQ27ID3mjHigVEAky6O9YWPbn.profile,NQ27ID3mjHigVEAky6O9YWPbn.direction = aargs[LJPOQNK1mcG(u"࠶౲")],aargs[aNdix5gq7yeFHTMWhnzm8pX0Y16(u"࠸౳")]
		NQ27ID3mjHigVEAky6O9YWPbn.buttonstimeout,NQ27ID3mjHigVEAky6O9YWPbn.closetimeout = aargs[k5oIaYyp2mnrLK49qhzS(u"࠻౵")],aargs[YnHG75e2QWwo(u"࠻౴")]
		if NQ27ID3mjHigVEAky6O9YWPbn.buttonstimeout>nnsBpJv6XL3OzHoe4Vuhr or NQ27ID3mjHigVEAky6O9YWPbn.closetimeout>TtyzcuW45VKA(u"࠵౶"): NQ27ID3mjHigVEAky6O9YWPbn.enable_progressbar = IZQbmFzLHDtXfc
		else: NQ27ID3mjHigVEAky6O9YWPbn.enable_progressbar = ksTLSoVGg0ht
		NQ27ID3mjHigVEAky6O9YWPbn.image_filename = IEYRiWjro7qxBZcyOdku8.replace(opyTNwHgfqbZREWKU(u"ࠨࡡ࠳࠴࠵࠶࡟ࠨ௟"),S5fhsRT8JV(u"ࠩࡢࠫ௠")+str(bD7kJZhMCdaqF68P45KlNIgO1.time())+NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠪࡣࠬ௡"))
		NQ27ID3mjHigVEAky6O9YWPbn.image_filename = NQ27ID3mjHigVEAky6O9YWPbn.image_filename.replace(nfg30bHwd4aNV12SR7UjFck(u"ࠫࡡࡢࠧ௢"),LungQF89BqemOb32jJsZlW(u"ࠬࡢ࡜࡝࡞ࠪ௣")).replace(Tf2ZPslXS84Yw15aNkjQ7oOzqMc,aNdix5gq7yeFHTMWhnzm8pX0Y16(u"࠭࠯࠰࠱࠲ࠫ௤"))
		NQ27ID3mjHigVEAky6O9YWPbn.image_height = yBKQPzOWu7we(NQ27ID3mjHigVEAky6O9YWPbn.button0,NQ27ID3mjHigVEAky6O9YWPbn.button1,NQ27ID3mjHigVEAky6O9YWPbn.button2,NQ27ID3mjHigVEAky6O9YWPbn.header,NQ27ID3mjHigVEAky6O9YWPbn.text,NQ27ID3mjHigVEAky6O9YWPbn.profile,NQ27ID3mjHigVEAky6O9YWPbn.direction,NQ27ID3mjHigVEAky6O9YWPbn.enable_progressbar,NQ27ID3mjHigVEAky6O9YWPbn.image_filename)
		NQ27ID3mjHigVEAky6O9YWPbn.show()
		NQ27ID3mjHigVEAky6O9YWPbn.getControl(Rsdai9xIEPcpuBMKOUwkTA05q(u"࠿࠰࠶࠲౷")).setImage(NQ27ID3mjHigVEAky6O9YWPbn.image_filename)
		NQ27ID3mjHigVEAky6O9YWPbn.getControl(KNomgGw1kdMCBH(u"࠹࠱࠷࠳౸")).setHeight(NQ27ID3mjHigVEAky6O9YWPbn.image_height)
		if not NQ27ID3mjHigVEAky6O9YWPbn.button1 and NQ27ID3mjHigVEAky6O9YWPbn.button0 and NQ27ID3mjHigVEAky6O9YWPbn.button2: NQ27ID3mjHigVEAky6O9YWPbn.getControl(KNomgGw1kdMCBH(u"࠻࠳࠵࠷౺")).setPosition(-opyTNwHgfqbZREWKU(u"࠵࠶࠵౻"),NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"࠱౹"))
		return NQ27ID3mjHigVEAky6O9YWPbn.image_filename,NQ27ID3mjHigVEAky6O9YWPbn.image_height
	def dw7NCBKsWiAQFS(NQ27ID3mjHigVEAky6O9YWPbn):
		if NQ27ID3mjHigVEAky6O9YWPbn.buttonstimeout:
			NQ27ID3mjHigVEAky6O9YWPbn.th1 = qMrpRl8enOuvS6hV2XcZgT(daemon=IZQbmFzLHDtXfc,target=NQ27ID3mjHigVEAky6O9YWPbn.kR8sGitJ3Nj5YTIKmEQ1eoval)
			NQ27ID3mjHigVEAky6O9YWPbn.th1.start()
		else: NQ27ID3mjHigVEAky6O9YWPbn.Sliz8I5XVTnyj1LFOfubotPG9()
	def kR8sGitJ3Nj5YTIKmEQ1eoval(NQ27ID3mjHigVEAky6O9YWPbn):
		NQ27ID3mjHigVEAky6O9YWPbn.getControl(f8Ja1q5eO02B(u"࠽࠵࠸࠰౼")).setEnabled(IZQbmFzLHDtXfc)
		for DXAlBvH2ITZoyunMU0Rq3pw7sx in range(hiuZa0PIsErm6UC7,NQ27ID3mjHigVEAky6O9YWPbn.buttonstimeout+hiuZa0PIsErm6UC7):
			bD7kJZhMCdaqF68P45KlNIgO1.sleep(hiuZa0PIsErm6UC7)
			SWMfxGbYRnXmP = int(TtyzcuW45VKA(u"࠶࠶࠰౽")*DXAlBvH2ITZoyunMU0Rq3pw7sx/NQ27ID3mjHigVEAky6O9YWPbn.buttonstimeout)
			NQ27ID3mjHigVEAky6O9YWPbn.MqCl1HQO8VjEFnBxTdP(SWMfxGbYRnXmP)
			if NQ27ID3mjHigVEAky6O9YWPbn.choiceID>aNdix5gq7yeFHTMWhnzm8pX0Y16(u"࠶౾"): break
		NQ27ID3mjHigVEAky6O9YWPbn.Sliz8I5XVTnyj1LFOfubotPG9()
	def Dt1YATXCb3yMdUFc(NQ27ID3mjHigVEAky6O9YWPbn):
		if NQ27ID3mjHigVEAky6O9YWPbn.closetimeout:
			NQ27ID3mjHigVEAky6O9YWPbn.th2 = qMrpRl8enOuvS6hV2XcZgT(daemon=IZQbmFzLHDtXfc,target=NQ27ID3mjHigVEAky6O9YWPbn.ddCvXniD8tlpb0hWGgaMNK5T6JQAS)
			NQ27ID3mjHigVEAky6O9YWPbn.th2.start()
		else: NQ27ID3mjHigVEAky6O9YWPbn.Sliz8I5XVTnyj1LFOfubotPG9()
	def ddCvXniD8tlpb0hWGgaMNK5T6JQAS(NQ27ID3mjHigVEAky6O9YWPbn):
		NQ27ID3mjHigVEAky6O9YWPbn.getControl(vbYokBuWlxeLDcdVNM60(u"࠹࠱࠴࠳౿")).setEnabled(IZQbmFzLHDtXfc)
		bD7kJZhMCdaqF68P45KlNIgO1.sleep(NQ27ID3mjHigVEAky6O9YWPbn.buttonstimeout)
		for DXAlBvH2ITZoyunMU0Rq3pw7sx in range(NQ27ID3mjHigVEAky6O9YWPbn.closetimeout-hiuZa0PIsErm6UC7,-hiuZa0PIsErm6UC7,-hiuZa0PIsErm6UC7):
			bD7kJZhMCdaqF68P45KlNIgO1.sleep(hiuZa0PIsErm6UC7)
			SWMfxGbYRnXmP = int(xN4fKmsnyM3Y2(u"࠲࠲࠳ಀ")*DXAlBvH2ITZoyunMU0Rq3pw7sx/NQ27ID3mjHigVEAky6O9YWPbn.closetimeout)
			NQ27ID3mjHigVEAky6O9YWPbn.MqCl1HQO8VjEFnBxTdP(SWMfxGbYRnXmP)
			if NQ27ID3mjHigVEAky6O9YWPbn.choiceID>nnsBpJv6XL3OzHoe4Vuhr: break
		if NQ27ID3mjHigVEAky6O9YWPbn.closetimeout>nnsBpJv6XL3OzHoe4Vuhr: NQ27ID3mjHigVEAky6O9YWPbn.choiceID = S5fhsRT8JV(u"࠳࠳ಁ")
		NQ27ID3mjHigVEAky6O9YWPbn.ThtOMkNZeEDB5Jw()
	def MqCl1HQO8VjEFnBxTdP(NQ27ID3mjHigVEAky6O9YWPbn,SWMfxGbYRnXmP):
		NQ27ID3mjHigVEAky6O9YWPbn.precent = SWMfxGbYRnXmP
		NQ27ID3mjHigVEAky6O9YWPbn.getControl(rbUkdYi32PJaRtnxhDvQs(u"࠼࠴࠷࠶ಂ")).setPercent(NQ27ID3mjHigVEAky6O9YWPbn.precent)
	def Sliz8I5XVTnyj1LFOfubotPG9(NQ27ID3mjHigVEAky6O9YWPbn):
		if NQ27ID3mjHigVEAky6O9YWPbn.button0: NQ27ID3mjHigVEAky6O9YWPbn.getControl(KNomgGw1kdMCBH(u"࠽࠵࠷࠰ಃ")).setEnabled(IZQbmFzLHDtXfc)
		if NQ27ID3mjHigVEAky6O9YWPbn.button1: NQ27ID3mjHigVEAky6O9YWPbn.getControl(f8Ja1q5eO02B(u"࠾࠶࠱࠲಄")).setEnabled(IZQbmFzLHDtXfc)
		if NQ27ID3mjHigVEAky6O9YWPbn.button2: NQ27ID3mjHigVEAky6O9YWPbn.getControl(On1WZJc6dtksqVNgSQ5GBAjuipe(u"࠿࠰࠲࠴ಅ")).setEnabled(IZQbmFzLHDtXfc)
	def ThtOMkNZeEDB5Jw(NQ27ID3mjHigVEAky6O9YWPbn):
		NQ27ID3mjHigVEAky6O9YWPbn.close()
		try: YRESXadfbIy3khwqmL8WC.remove(NQ27ID3mjHigVEAky6O9YWPbn.image_filename)
		except: pass
def NiWSoAmhdkQPlTpneyVzDO8tw9aL(*aargs,**kkwargs):
	if aargs:
		direction = aargs[nnsBpJv6XL3OzHoe4Vuhr]
		LZ0yPKTn4UwcgsS = aargs[hiuZa0PIsErm6UC7]
		if not direction: direction = ObuCsdoDtKmhPLSMH8YGan(u"ࠧࡤࡧࡱࡸࡪࡸࠧ௥")
		if not LZ0yPKTn4UwcgsS: LZ0yPKTn4UwcgsS = AiCor1fIVTDxQUWwHe9vPR7(u"ࠨษึฮ๊ืวาࠩ௦")
		ewaXJ4xchoDNIVqQy3Rp60Bz = aargs[bVX3ev1spE]
		ttFj9PmIcsuGpzib3aS = ssELJkeScrtni2.join(aargs[J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"࠳ಆ"):])
	else: direction,LZ0yPKTn4UwcgsS,ewaXJ4xchoDNIVqQy3Rp60Bz,ttFj9PmIcsuGpzib3aS = cdZKMn68Pzg4,WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠩࡒࡏࠬ௧"),cdZKMn68Pzg4,cdZKMn68Pzg4
	UN8rA03xkWLCGzebyEoF9YDRKBwSMO(direction,cdZKMn68Pzg4,LZ0yPKTn4UwcgsS,cdZKMn68Pzg4,ewaXJ4xchoDNIVqQy3Rp60Bz,ttFj9PmIcsuGpzib3aS,**kkwargs)
	return
def JyLdvftP3CU(*aargs,**kkwargs):
	direction = aargs[nnsBpJv6XL3OzHoe4Vuhr]
	RogV8my9xFUqzav = aargs[hiuZa0PIsErm6UC7]
	lAEb5nJytaDXcqw8HeC = aargs[bVX3ev1spE]
	if lAEb5nJytaDXcqw8HeC or RogV8my9xFUqzav: f6NUGhE8rmVZqgKSdkB = IZQbmFzLHDtXfc
	else: f6NUGhE8rmVZqgKSdkB = ksTLSoVGg0ht
	ewaXJ4xchoDNIVqQy3Rp60Bz = aargs[kzoASbNraPcfgvWJmY9Qu]
	ttFj9PmIcsuGpzib3aS = aargs[iwQJREcVTSe1G2gCvlfhbHWLjqopa]
	if not direction: direction = zDek1IW37rq6UoKdwyRiAVpF(u"ࠪࡧࡪࡴࡴࡦࡴࠪ௨")
	if not RogV8my9xFUqzav: RogV8my9xFUqzav = SGazRxP3yBKZ15ILuch(u"่๊ࠫวࠡࠢࡑࡳࠬ௩")
	if not lAEb5nJytaDXcqw8HeC: lAEb5nJytaDXcqw8HeC = YnHG75e2QWwo(u"ࠬ์ูๆࠢࠣ࡝ࡪࡹࠧ௪")
	if len(aargs)>=LungQF89BqemOb32jJsZlW(u"࠸ಈ"): ttFj9PmIcsuGpzib3aS += ssELJkeScrtni2+aargs[zDek1IW37rq6UoKdwyRiAVpF(u"࠶ಇ")]
	if len(aargs)>=aNdix5gq7yeFHTMWhnzm8pX0Y16(u"࠺ಉ"): ttFj9PmIcsuGpzib3aS += ssELJkeScrtni2+aargs[HC9xWUMpBQJEuTteAqjd(u"࠺ಊ")]
	T3TmXl7awhOuPM4Wy5vDUVSIKz = UN8rA03xkWLCGzebyEoF9YDRKBwSMO(direction,RogV8my9xFUqzav,cdZKMn68Pzg4,lAEb5nJytaDXcqw8HeC,ewaXJ4xchoDNIVqQy3Rp60Bz,ttFj9PmIcsuGpzib3aS,**kkwargs)
	if T3TmXl7awhOuPM4Wy5vDUVSIKz==-On1WZJc6dtksqVNgSQ5GBAjuipe(u"࠶ಋ") and f6NUGhE8rmVZqgKSdkB: T3TmXl7awhOuPM4Wy5vDUVSIKz = -hiuZa0PIsErm6UC7
	elif T3TmXl7awhOuPM4Wy5vDUVSIKz==-hiuZa0PIsErm6UC7 and not f6NUGhE8rmVZqgKSdkB: T3TmXl7awhOuPM4Wy5vDUVSIKz = ksTLSoVGg0ht
	elif T3TmXl7awhOuPM4Wy5vDUVSIKz==nnsBpJv6XL3OzHoe4Vuhr: T3TmXl7awhOuPM4Wy5vDUVSIKz = ksTLSoVGg0ht
	elif T3TmXl7awhOuPM4Wy5vDUVSIKz==bVX3ev1spE: T3TmXl7awhOuPM4Wy5vDUVSIKz = IZQbmFzLHDtXfc
	return T3TmXl7awhOuPM4Wy5vDUVSIKz
def NAfHLMC8Ip64FmT7l5oJWXaq3hK(*aargs,**kkwargs):
	return r8rEvwjH91KlNMhIZoAVdpRyWeDfcs.Dialog().select(*aargs,**kkwargs)
def bJqPkYBXsenxTRwKu(*args,**kwargs):
	ewaXJ4xchoDNIVqQy3Rp60Bz = args[nnsBpJv6XL3OzHoe4Vuhr]
	ttFj9PmIcsuGpzib3aS = args[hiuZa0PIsErm6UC7]
	if len(args) > bVX3ev1spE and NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"࠭ࡴࡪ࡯ࡨࠫ௫") not in str(args[WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"࠸ಌ")]):
		RlAHzS4b0ovnek6x7Ewj = args[bVX3ev1spE]
		RTlVbYA4QE3OdLZF8yHe = kwargs.get(NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠧࡵ࡫ࡰࡩࠬ௬"), aar0zhDnJsOTP7EdgR16HIS29(u"࠱࠱࠲࠳಍"))
	else:
		RlAHzS4b0ovnek6x7Ewj = AiCor1fIVTDxQUWwHe9vPR7(u"ࠨࡰࡲࡸ࡮࡬ࡩࡤࡣࡷ࡭ࡴࡴ࡟ࡳࡧࡪࡹࡱࡧࡲࠨ௭")
		RTlVbYA4QE3OdLZF8yHe = args[bVX3ev1spE] if len(args) > bVX3ev1spE else kwargs.get(liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠩࡷ࡭ࡲ࡫ࠧ௮"), Rsdai9xIEPcpuBMKOUwkTA05q(u"࠲࠲࠳࠴ಎ"))
	kJGI2LOic41u8htH3QNF = qMrpRl8enOuvS6hV2XcZgT(daemon=IZQbmFzLHDtXfc,target=DYSR0NL4mE9,args=(ewaXJ4xchoDNIVqQy3Rp60Bz,ttFj9PmIcsuGpzib3aS,RlAHzS4b0ovnek6x7Ewj,RTlVbYA4QE3OdLZF8yHe))
	kJGI2LOic41u8htH3QNF.start()
	return
def DYSR0NL4mE9(ewaXJ4xchoDNIVqQy3Rp60Bz,ttFj9PmIcsuGpzib3aS,RlAHzS4b0ovnek6x7Ewj,RTlVbYA4QE3OdLZF8yHe):
	GaMDebxvJhri0d3zPVO8F1fwW = RlAHzS4b0ovnek6x7Ewj.replace(uxE8MyoTRglrcaiQf(u"ࠪࡲࡴࡺࡩࡧ࡫ࡦࡥࡹ࡯࡯࡯ࡡࠪ௯"),cdZKMn68Pzg4)
	import RYQDcI9Uz8
	name = RYQDcI9Uz8.DFr1WoZABRnSM79gObypfq(IZQbmFzLHDtXfc,GaMDebxvJhri0d3zPVO8F1fwW+ObuCsdoDtKmhPLSMH8YGan(u"ࠫࠥ࠳ࠠࠨ௰")+ewaXJ4xchoDNIVqQy3Rp60Bz+On1WZJc6dtksqVNgSQ5GBAjuipe(u"ࠬࠦ࠭ࠡࠩ௱")+ttFj9PmIcsuGpzib3aS)
	name = RYQDcI9Uz8.RQfVumjSLa16XNAp2d(name)
	image_filename = YRESXadfbIy3khwqmL8WC.path.join(rr6bRWx70ZNIz,name+opyTNwHgfqbZREWKU(u"࠭࠮ࡱࡰࡪࠫ௲"))
	if YRESXadfbIy3khwqmL8WC.path.exists(image_filename):
		if RlAHzS4b0ovnek6x7Ewj==S5fhsRT8JV(u"ࠧ࡯ࡱࡷ࡭࡫࡯ࡣࡢࡶ࡬ࡳࡳࡥࡲࡦࡩࡸࡰࡦࡸࠧ௳"): image_height = HC9xWUMpBQJEuTteAqjd(u"࠳࠴࠻ಏ")
		elif RlAHzS4b0ovnek6x7Ewj==vbYokBuWlxeLDcdVNM60(u"ࠨࡰࡲࡸ࡮࡬ࡩࡤࡣࡷ࡭ࡴࡴ࡟ࡢࡷࡷࡳࠬ௴"): image_height = WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"࠵࠵࠵ಐ")
	else: image_height = yBKQPzOWu7we(cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,ewaXJ4xchoDNIVqQy3Rp60Bz,ttFj9PmIcsuGpzib3aS,RlAHzS4b0ovnek6x7Ewj,k5oIaYyp2mnrLK49qhzS(u"ࠩ࡯ࡩ࡫ࡺࠧ௵"),ksTLSoVGg0ht,image_filename)
	eDBSO5AhWtgrPRK = zz6bHTRC0W8DLnMsJ(S5fhsRT8JV(u"ࠪࡈ࡮ࡧ࡬ࡰࡩࡑࡳࡹ࡯ࡦࡪࡥࡤࡸ࡮ࡵ࡮ࡊ࡯ࡤ࡫ࡪ࠴ࡸ࡮࡮ࠪ௶"),UMFLP95VOlxHTE,LJPOQNK1mcG(u"ࠫࡉ࡫ࡦࡢࡷ࡯ࡸࠬ௷"),opyTNwHgfqbZREWKU(u"ࠬ࠽࠲࠱ࡲࠪ௸"))
	eDBSO5AhWtgrPRK.show()
	if RlAHzS4b0ovnek6x7Ewj==xN4fKmsnyM3Y2(u"࠭࡮ࡰࡶ࡬ࡪ࡮ࡩࡡࡵ࡫ࡲࡲࡤࡧࡵࡵࡱࠪ௹"):
		eDBSO5AhWtgrPRK.getControl(NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"࠾࠶࠴࠱ಒ")).setHeight(LungQF89BqemOb32jJsZlW(u"࠶࠶࠻಑"))
		eDBSO5AhWtgrPRK.getControl(HC9xWUMpBQJEuTteAqjd(u"࠺࠲࠷࠴ಕ")).setPosition(uxE8MyoTRglrcaiQf(u"࠻࠵ಓ"),-xN4fKmsnyM3Y2(u"࠸࠱ಔ"))
		eDBSO5AhWtgrPRK.getControl(AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"࠻࠳࠹࠵ಖ")).setPosition(NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"࠴࠶࠵ಗ"),-SGazRxP3yBKZ15ILuch(u"࠺࠵ಘ"))
		eDBSO5AhWtgrPRK.getControl(ObuCsdoDtKmhPLSMH8YGan(u"࠴࠱࠲ಛ")).setPosition(zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"࠾࠶ಙ"),-J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"࠹࠵ಚ"))
	eDBSO5AhWtgrPRK.getControl(AiCor1fIVTDxQUWwHe9vPR7(u"࠵࠲࠴ಜ")).setVisible(ksTLSoVGg0ht)
	eDBSO5AhWtgrPRK.getControl(LungQF89BqemOb32jJsZlW(u"࠶࠳࠶ಝ")).setVisible(ksTLSoVGg0ht)
	eDBSO5AhWtgrPRK.getControl(AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"࠼࠴࠺࠶ಞ")).setImage(image_filename)
	eDBSO5AhWtgrPRK.getControl(NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"࠽࠵࠻࠰ಟ")).setHeight(image_height)
	bD7kJZhMCdaqF68P45KlNIgO1.sleep(RTlVbYA4QE3OdLZF8yHe/nfg30bHwd4aNV12SR7UjFck(u"࠶࠶࠰࠱࠰࠳ಠ"))
	return
def RMDqaKOvQCXghu81Gc(*aargs,**kkwargs):
	ewaXJ4xchoDNIVqQy3Rp60Bz,ttFj9PmIcsuGpzib3aS,profile,direction = cdZKMn68Pzg4,cdZKMn68Pzg4,rbUkdYi32PJaRtnxhDvQs(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࡢࡰࡴࡴࡧࠨ௺"),SGazRxP3yBKZ15ILuch(u"ࠨ࡮ࡨࡪࡹ࠭௻")
	if len(aargs)>=hiuZa0PIsErm6UC7: ewaXJ4xchoDNIVqQy3Rp60Bz = aargs[nnsBpJv6XL3OzHoe4Vuhr]
	if len(aargs)>=bVX3ev1spE: ttFj9PmIcsuGpzib3aS = aargs[hiuZa0PIsErm6UC7]
	if len(aargs)>=kzoASbNraPcfgvWJmY9Qu: profile = aargs[bVX3ev1spE]
	if len(aargs)>=iwQJREcVTSe1G2gCvlfhbHWLjqopa: direction = aargs[kzoASbNraPcfgvWJmY9Qu]
	return E3WHU2OdFfmX459c(direction,ewaXJ4xchoDNIVqQy3Rp60Bz,ttFj9PmIcsuGpzib3aS,profile)
def NcRbram3fy(*aargs,**kkwargs):
	return r8rEvwjH91KlNMhIZoAVdpRyWeDfcs.Dialog().contextmenu(*aargs,**kkwargs)
def ZDudO4KVpTzJF0m(*aargs,**kkwargs):
	return r8rEvwjH91KlNMhIZoAVdpRyWeDfcs.Dialog().browseSingle(*aargs,**kkwargs)
def VnAvpcR23KmZJSM(*aargs,**kkwargs):
	return r8rEvwjH91KlNMhIZoAVdpRyWeDfcs.Dialog().input(*aargs,**kkwargs)
def g6UkpOE3s5XLiFH(*aargs,**kkwargs):
	return r8rEvwjH91KlNMhIZoAVdpRyWeDfcs.DialogProgress(*aargs,**kkwargs)
def UN8rA03xkWLCGzebyEoF9YDRKBwSMO(direction,button0=cdZKMn68Pzg4,button1=cdZKMn68Pzg4,button2=cdZKMn68Pzg4,ewaXJ4xchoDNIVqQy3Rp60Bz=cdZKMn68Pzg4,ttFj9PmIcsuGpzib3aS=cdZKMn68Pzg4,profile=YnHG75e2QWwo(u"ࠩࡦࡳࡳ࡬ࡩࡳ࡯ࡢࡦ࡮࡭ࡦࡰࡰࡷࠫ௼"),rjW6VxPdsloLYqD4nUB7MF=nnsBpJv6XL3OzHoe4Vuhr,DDeRhG1E2y7dSU5xjbgnQHPYL6NK4f=nnsBpJv6XL3OzHoe4Vuhr):
	if not direction: direction = zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"ࠪࡧࡪࡴࡴࡦࡴࠪ௽")
	eDBSO5AhWtgrPRK = Za2BRWrGNboC(liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠫࡉ࡯ࡡ࡭ࡱࡪࡇࡴࡴࡦࡪࡴࡰࡘ࡭ࡸࡥࡦࡄࡸࡸࡹࡵ࡮ࡴ࠰ࡻࡱࡱ࠭௾"),UMFLP95VOlxHTE,f8Ja1q5eO02B(u"ࠬࡊࡥࡧࡣࡸࡰࡹ࠭௿"),opyTNwHgfqbZREWKU(u"࠭࠷࠳࠲ࡳࠫఀ"))
	eDBSO5AhWtgrPRK.SzHps5cgoryf9Ke2mbh4NO(button0,button1,button2,ewaXJ4xchoDNIVqQy3Rp60Bz,ttFj9PmIcsuGpzib3aS,profile,direction,rjW6VxPdsloLYqD4nUB7MF,DDeRhG1E2y7dSU5xjbgnQHPYL6NK4f)
	if rjW6VxPdsloLYqD4nUB7MF>nnsBpJv6XL3OzHoe4Vuhr: eDBSO5AhWtgrPRK.dw7NCBKsWiAQFS()
	if DDeRhG1E2y7dSU5xjbgnQHPYL6NK4f>nnsBpJv6XL3OzHoe4Vuhr: eDBSO5AhWtgrPRK.Dt1YATXCb3yMdUFc()
	if rjW6VxPdsloLYqD4nUB7MF==nnsBpJv6XL3OzHoe4Vuhr and DDeRhG1E2y7dSU5xjbgnQHPYL6NK4f==nnsBpJv6XL3OzHoe4Vuhr: eDBSO5AhWtgrPRK.Sliz8I5XVTnyj1LFOfubotPG9()
	eDBSO5AhWtgrPRK.doModal()
	T3TmXl7awhOuPM4Wy5vDUVSIKz = eDBSO5AhWtgrPRK.choiceID
	return T3TmXl7awhOuPM4Wy5vDUVSIKz
def E3WHU2OdFfmX459c(direction,ewaXJ4xchoDNIVqQy3Rp60Bz,ttFj9PmIcsuGpzib3aS,profile=iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࡢࡰࡴࡴࡧࠨఁ")):
	if not direction: direction = opyTNwHgfqbZREWKU(u"ࠨ࡮ࡨࡪࡹ࠭ం")
	eDBSO5AhWtgrPRK = zz6bHTRC0W8DLnMsJ(xN4fKmsnyM3Y2(u"ࠩࡇ࡭ࡦࡲ࡯ࡨࡖࡨࡼࡹ࡜ࡩࡦࡹࡨࡶࡋࡻ࡬࡭ࡕࡦࡶࡪ࡫࡮࠯ࡺࡰࡰࠬః"),UMFLP95VOlxHTE,s8fcjBCSMxzAIkZQbJPga(u"ࠪࡈࡪ࡬ࡡࡶ࡮ࡷࠫఄ"),aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠫ࠼࠸࠰ࡱࠩఅ"))
	image_filename = IEYRiWjro7qxBZcyOdku8.replace(AiCor1fIVTDxQUWwHe9vPR7(u"ࠬࡥ࠰࠱࠲࠳ࡣࠬఆ"),zDek1IW37rq6UoKdwyRiAVpF(u"࠭࡟ࠨఇ")+str(bD7kJZhMCdaqF68P45KlNIgO1.time())+AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"ࠧࡠࠩఈ"))
	image_filename = image_filename.replace(zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"ࠨ࡞࡟ࠫఉ"),NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠩ࡟ࡠࡡࡢࠧఊ")).replace(Tf2ZPslXS84Yw15aNkjQ7oOzqMc,vbYokBuWlxeLDcdVNM60(u"ࠪ࠳࠴࠵࠯ࠨఋ"))
	image_height = yBKQPzOWu7we(cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,ewaXJ4xchoDNIVqQy3Rp60Bz,ttFj9PmIcsuGpzib3aS,profile,direction,ksTLSoVGg0ht,image_filename)
	eDBSO5AhWtgrPRK.show()
	eDBSO5AhWtgrPRK.getControl(k5oIaYyp2mnrLK49qhzS(u"࠿࠰࠶࠲ಡ")).setHeight(image_height)
	eDBSO5AhWtgrPRK.getControl(YnHG75e2QWwo(u"࠹࠱࠷࠳ಢ")).setImage(image_filename)
	Jtu0lWm3vPhcHI2fFDkECTUnG4sbAX = eDBSO5AhWtgrPRK.doModal()
	try: YRESXadfbIy3khwqmL8WC.remove(image_filename)
	except: pass
	return Jtu0lWm3vPhcHI2fFDkECTUnG4sbAX
def yBKQPzOWu7we(CtFdnT63cj,ynudfqwcmvj3DbFLMYZ7BC,OeRfVxSw51gvsJIHo84X9,nG4aYCUKzmZN,JAYWBoz54tGw7O,zTv29nJgMidktb1GmUO5ShIWC0jZ,n52GI1hMv4HzJb,WYHrghdGnu82p0lBs7aTSv5AX,KLJu3k4l7heRZSnpXEs):
	TTUVQNov2wZhaILi6Hlp10Pxrm = YRESXadfbIy3khwqmL8WC.path.dirname(KLJu3k4l7heRZSnpXEs)
	if not YRESXadfbIy3khwqmL8WC.path.exists(TTUVQNov2wZhaILi6Hlp10Pxrm):
		try: YRESXadfbIy3khwqmL8WC.makedirs(TTUVQNov2wZhaILi6Hlp10Pxrm)
		except: pass
	qQzyitXlNMuv3URZDPC = UUrOodGmp4At6MSEZq(zTv29nJgMidktb1GmUO5ShIWC0jZ)
	zzNySgubK6wIZsR9vWeqG4iFL8Vx = bvTMDXJxNPwAoC(qQzyitXlNMuv3URZDPC,CtFdnT63cj,ynudfqwcmvj3DbFLMYZ7BC,OeRfVxSw51gvsJIHo84X9,nG4aYCUKzmZN,JAYWBoz54tGw7O,zTv29nJgMidktb1GmUO5ShIWC0jZ,n52GI1hMv4HzJb,WYHrghdGnu82p0lBs7aTSv5AX,KLJu3k4l7heRZSnpXEs)
	return zzNySgubK6wIZsR9vWeqG4iFL8Vx
def UUrOodGmp4At6MSEZq(zTv29nJgMidktb1GmUO5ShIWC0jZ):
	H3H4NLuXdyY7sJxBvIe = ffXqoLey4TixFJBw
	bG85WlQImE7HiR = vbYokBuWlxeLDcdVNM60(u"࠳࠲ಣ")
	q7CxJAGidjFl6oB8PU1rOEMLNce = aNdix5gq7yeFHTMWhnzm8pX0Y16(u"࠴࠳ತ")
	wiJ7T32ftC01eNqclM = nnsBpJv6XL3OzHoe4Vuhr
	WSrbs0tNYa = vbYokBuWlxeLDcdVNM60(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫఌ")
	c4A8LbQty3qn6ZdzTgv = nnsBpJv6XL3OzHoe4Vuhr
	mWQJlHBTSIzgX40rZYk61udLbAqvC = LJPOQNK1mcG(u"࠴࠽ಥ")
	gmD4HCPzu5f0WERs8wQ23ITNqZY = HC9xWUMpBQJEuTteAqjd(u"࠷࠵ದ")
	TnxAIHWgUe53M = NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"࠽ಧ")
	O1OEYlMtG2mL = IZQbmFzLHDtXfc
	GGr8ZQmXATWUEwi2YhV0ozJBsvCqgf = ObuCsdoDtKmhPLSMH8YGan(u"࠹࠷࠶ನ")
	KK9MhCIe27LbOk = HC9xWUMpBQJEuTteAqjd(u"࠴࠲࠲಩")
	D8kceszFadWt9I = xN4fKmsnyM3Y2(u"࠶࠲ಪ")
	QDjURfxoeWBalM4cG = NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"࠴࠻࠴ಫ")
	XzWD8Jkd4KmnslhZLeEtAx = uxE8MyoTRglrcaiQf(u"࠵࠼ಬ")
	RMCNjnxwmdbf2yHErXQaF = ffXqoLey4TixFJBw
	TthuqGvBm3afdZC = nnsBpJv6XL3OzHoe4Vuhr
	nmwSUe0YoTcd1AQkvPVbIRtEg = SGazRxP3yBKZ15ILuch(u"࠷࠶ಭ")
	nTsyQIuGZ813EtkJBNcwpM = [WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"࠳࠷ರ"),uxE8MyoTRglrcaiQf(u"࠸࠸ಮ"),On1WZJc6dtksqVNgSQ5GBAjuipe(u"࠸࠸ಯ")]
	from PIL import ImageDraw as uTkGqlvB241FDhg,ImageFont as varHACoGqiyVteT1zBlJY5,Image as EIkMYyBat4mqQ
	if WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠬࡴ࡯ࡵ࡫ࡩ࡭ࡨࡧࡴࡪࡱࡱࠫ఍") in zTv29nJgMidktb1GmUO5ShIWC0jZ:
		if zTv29nJgMidktb1GmUO5ShIWC0jZ==zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"࠭࡮ࡰࡶ࡬ࡪ࡮ࡩࡡࡵ࡫ࡲࡲࡤࡸࡥࡨࡷ࡯ࡥࡷ࠭ఎ"):
			K0KDWv51B74Sotxw = f8Ja1q5eO02B(u"࠲࠳࠺ಱ")
			WSrbs0tNYa = NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠧ࡭ࡧࡩࡸࠬఏ")
			O1OEYlMtG2mL = ksTLSoVGg0ht
		elif zTv29nJgMidktb1GmUO5ShIWC0jZ==HC9xWUMpBQJEuTteAqjd(u"ࠨࡰࡲࡸ࡮࡬ࡩࡤࡣࡷ࡭ࡴࡴ࡟ࡢࡷࡷࡳࠬఐ"):
			K0KDWv51B74Sotxw = AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"ࠩࡘࡔࡕࡋࡒࠨ఑")
			WSrbs0tNYa = Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠪࡶ࡮࡭ࡨࡵࠩఒ")
			wiJ7T32ftC01eNqclM = J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"࠳࠳ಲ")
		xxIJtWbQwrksDO483PumzHY = dwiIAcPl04ey7Zv38Mz(u"࠺࠶࠵ಳ")
		nTsyQIuGZ813EtkJBNcwpM = [tRnTydV03Xfi7rbQ(u"࠷࠸಴"),tRnTydV03Xfi7rbQ(u"࠷࠸಴"),tRnTydV03Xfi7rbQ(u"࠷࠸಴")]
		q7CxJAGidjFl6oB8PU1rOEMLNce = vbYokBuWlxeLDcdVNM60(u"࠷࠶ವ")
		bG85WlQImE7HiR = nnsBpJv6XL3OzHoe4Vuhr
		gmD4HCPzu5f0WERs8wQ23ITNqZY = J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"࠸࠰ಶ")
		mWQJlHBTSIzgX40rZYk61udLbAqvC = ObuCsdoDtKmhPLSMH8YGan(u"࠳࠶ಷ")
	elif zTv29nJgMidktb1GmUO5ShIWC0jZ==f8Ja1q5eO02B(u"ࠫࡲ࡫࡮ࡶࡡ࡬ࡸࡪࡳࠧఓ"):
		nTsyQIuGZ813EtkJBNcwpM,xxIJtWbQwrksDO483PumzHY,K0KDWv51B74Sotxw = [HC9xWUMpBQJEuTteAqjd(u"࠵࠼಺"),HC9xWUMpBQJEuTteAqjd(u"࠵࠼಺"),HC9xWUMpBQJEuTteAqjd(u"࠵࠼಺")],AiCor1fIVTDxQUWwHe9vPR7(u"࠳࠲࠳ಸ"),xN4fKmsnyM3Y2(u"࠴࠸࠴ಹ")
		c4A8LbQty3qn6ZdzTgv,gmD4HCPzu5f0WERs8wQ23ITNqZY,mWQJlHBTSIzgX40rZYk61udLbAqvC, = nnsBpJv6XL3OzHoe4Vuhr,-LungQF89BqemOb32jJsZlW(u"࠵࠷಻"),-TtyzcuW45VKA(u"࠸࠶಼")
		bG85WlQImE7HiR = nnsBpJv6XL3OzHoe4Vuhr
		iZnvbBjMWU53C6GLdt04TRO8c1Kwx = EIkMYyBat4mqQ.open(OOAXyCbfeiEMKDPvmn1wrQWUGkcV)
		yGZRtuXbTlKkw9Yg = EIkMYyBat4mqQ.new(NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠬࡘࡇࡃࡃࠪఔ"),(xxIJtWbQwrksDO483PumzHY,K0KDWv51B74Sotxw),(HC9xWUMpBQJEuTteAqjd(u"࠸࠵࠶ಽ"),nnsBpJv6XL3OzHoe4Vuhr,nnsBpJv6XL3OzHoe4Vuhr,HC9xWUMpBQJEuTteAqjd(u"࠸࠵࠶ಽ")))
	elif zTv29nJgMidktb1GmUO5ShIWC0jZ==f8Ja1q5eO02B(u"࠭ࡣࡰࡰࡩ࡭ࡷࡳ࡟ࡴ࡯ࡤࡰࡱ࡬࡯࡯ࡶࠪక"): nTsyQIuGZ813EtkJBNcwpM,K0KDWv51B74Sotxw,xxIJtWbQwrksDO483PumzHY = [Rsdai9xIEPcpuBMKOUwkTA05q(u"࠵࠼ು"),LJPOQNK1mcG(u"࠲࠵ಾ"),xN4fKmsnyM3Y2(u"࠳࠲ಿ")],uxE8MyoTRglrcaiQf(u"࠹࠵࠶ೂ"),dwiIAcPl04ey7Zv38Mz(u"࠻࠳࠴ೀ")
	elif zTv29nJgMidktb1GmUO5ShIWC0jZ==opyTNwHgfqbZREWKU(u"ࠧࡤࡱࡱࡪ࡮ࡸ࡭ࡠ࡯ࡨࡨ࡮ࡻ࡭ࡧࡱࡱࡸࠬఖ"): nTsyQIuGZ813EtkJBNcwpM,K0KDWv51B74Sotxw,xxIJtWbQwrksDO483PumzHY = [nfg30bHwd4aNV12SR7UjFck(u"࠹࠲ೄ"),On1WZJc6dtksqVNgSQ5GBAjuipe(u"࠳࠺ೆ"),rbUkdYi32PJaRtnxhDvQs(u"࠷࠺ೃ")],NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"࠷࠳࠴ೇ"),zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"࠹࠱࠲೅")
	elif zTv29nJgMidktb1GmUO5ShIWC0jZ==zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"ࠨࡥࡲࡲ࡫࡯ࡲ࡮ࡡࡥ࡭࡬࡬࡯࡯ࡶࠪగ"): nTsyQIuGZ813EtkJBNcwpM,K0KDWv51B74Sotxw,xxIJtWbQwrksDO483PumzHY = [f8Ja1q5eO02B(u"࠹࠶ೋ"),LJPOQNK1mcG(u"࠶࠶ೈ"),TtyzcuW45VKA(u"࠷࠾ೊ")],opyTNwHgfqbZREWKU(u"࠵࠱࠲ೌ"),nfg30bHwd4aNV12SR7UjFck(u"࠽࠵࠶೉")
	elif zTv29nJgMidktb1GmUO5ShIWC0jZ==HC9xWUMpBQJEuTteAqjd(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬఘ"): K0KDWv51B74Sotxw,xxIJtWbQwrksDO483PumzHY = vbYokBuWlxeLDcdVNM60(u"࠸࠶࠳್"),liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"࠳࠵࠻࠵೎")
	elif zTv29nJgMidktb1GmUO5ShIWC0jZ==iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹࡥ࡬ࡰࡰࡪࠫఙ"): K0KDWv51B74Sotxw,xxIJtWbQwrksDO483PumzHY = SGazRxP3yBKZ15ILuch(u"࡚ࠫࡖࡐࡆࡔࠪచ"),On1WZJc6dtksqVNgSQ5GBAjuipe(u"࠴࠶࠼࠶೏")
	elif zTv29nJgMidktb1GmUO5ShIWC0jZ==s8fcjBCSMxzAIkZQbJPga(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡴ࡯ࡤࡰࡱ࡬࡯࡯ࡶࠪఛ"): nTsyQIuGZ813EtkJBNcwpM,K0KDWv51B74Sotxw,xxIJtWbQwrksDO483PumzHY = [ObuCsdoDtKmhPLSMH8YGan(u"࠲࠹೓"),f8Ja1q5eO02B(u"࠳࠵೔"),S5fhsRT8JV(u"࠶࠾೑")],zDek1IW37rq6UoKdwyRiAVpF(u"࠻࠹࠶೐"),dwiIAcPl04ey7Zv38Mz(u"࠷࠲࠸࠲೒")
	elif zTv29nJgMidktb1GmUO5ShIWC0jZ==TtyzcuW45VKA(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡵࡰࡥࡱࡲࡦࡰࡰࡷࡣࡱࡵ࡮ࡨࠩజ"): nTsyQIuGZ813EtkJBNcwpM,K0KDWv51B74Sotxw,xxIJtWbQwrksDO483PumzHY = [AiCor1fIVTDxQUWwHe9vPR7(u"࠶࠽೗"),HC9xWUMpBQJEuTteAqjd(u"࠷࠹೘"),LungQF89BqemOb32jJsZlW(u"࠴࠼ೖ")],TtyzcuW45VKA(u"ࠧࡖࡒࡓࡉࡗ࠭ఝ"),zDek1IW37rq6UoKdwyRiAVpF(u"࠳࠵࠻࠵ೕ")
	aMspEDBC7xKmk34GVhZYU8,EUIloAzfJndH,H61ZERkViYX8AQe0t9q7TPvuKls = nTsyQIuGZ813EtkJBNcwpM
	CSuOXaAklxDs = varHACoGqiyVteT1zBlJY5.truetype(q3HOmNndw1KJ5MepkaLfYj0XVZzuxQ,size=aMspEDBC7xKmk34GVhZYU8)
	AOVW4GofHY2w1b9 = varHACoGqiyVteT1zBlJY5.truetype(q3HOmNndw1KJ5MepkaLfYj0XVZzuxQ,size=EUIloAzfJndH)
	g3OSaedypYMNBR0x2XHAk7imsqb = varHACoGqiyVteT1zBlJY5.truetype(q3HOmNndw1KJ5MepkaLfYj0XVZzuxQ,size=H61ZERkViYX8AQe0t9q7TPvuKls)
	dbPcolZi2n = xxIJtWbQwrksDO483PumzHY-gmD4HCPzu5f0WERs8wQ23ITNqZY*bVX3ev1spE
	kkGUb6ZSLNoFfsTt5KBzWvhgCQ = EIkMYyBat4mqQ.new(J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠨࡔࡊࡆࡆ࠭ఞ"),(dbPcolZi2n,TtyzcuW45VKA(u"࠷࠰࠱೙")),(zDek1IW37rq6UoKdwyRiAVpF(u"࠲࠶࠷೚"),zDek1IW37rq6UoKdwyRiAVpF(u"࠲࠶࠷೚"),zDek1IW37rq6UoKdwyRiAVpF(u"࠲࠶࠷೚"),nnsBpJv6XL3OzHoe4Vuhr))
	sFS7CyaogPixj = uTkGqlvB241FDhg.Draw(kkGUb6ZSLNoFfsTt5KBzWvhgCQ)
	G4EXLn9Q2Mfc3bFxeljygiNT,nqHjc6gA0RzPX8da4li = sFS7CyaogPixj.textsize(HC9xWUMpBQJEuTteAqjd(u"ࠩࡋࡌࡍࠦࡂࡃࡄࠣ࠼࠽࠾ࠠ࠱࠲࠳ࠫట"),font=CSuOXaAklxDs)
	yYkUvmMZuXsIopJNflAQh,M9MbeYOchAz8CIaNg30H = sFS7CyaogPixj.textsize(f8Ja1q5eO02B(u"ࠪࡌࡍࡎࠠࡃࡄࡅࠤ࠽࠾࠸ࠡ࠲࠳࠴ࠬఠ"),font=AOVW4GofHY2w1b9)
	UsNFEGXme7863xbgLrRzco = {iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠫࡩ࡫࡬ࡦࡶࡨࡣ࡭ࡧࡲࡢ࡭ࡤࡸࠬడ"):ksTLSoVGg0ht,AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"ࠬࡹࡵࡱࡲࡲࡶࡹࡥ࡬ࡪࡩࡤࡸࡺࡸࡥࡴࠩఢ"):IZQbmFzLHDtXfc,tRnTydV03Xfi7rbQ(u"࠭ࡁࡓࡃࡅࡍࡈࠦࡌࡊࡉࡄࡘ࡚ࡘࡅࠡࡃࡏࡐࡆࡎࠧణ"):ksTLSoVGg0ht}
	from arabic_reshaper import ArabicReshaper as Jfb37l0CG6Rw4zFDLxryVuUqt5gndp
	ycn2GYMwj8hJ43O = Jfb37l0CG6Rw4zFDLxryVuUqt5gndp(configuration=UsNFEGXme7863xbgLrRzco)
	qQzyitXlNMuv3URZDPC = {}
	p7dVRGZ0vKhzlNfm = locals()
	for D8QslnRP0KIkdYcbviAGTSEo7U69z in p7dVRGZ0vKhzlNfm: qQzyitXlNMuv3URZDPC[D8QslnRP0KIkdYcbviAGTSEo7U69z] = p7dVRGZ0vKhzlNfm[D8QslnRP0KIkdYcbviAGTSEo7U69z]
	return qQzyitXlNMuv3URZDPC
def bvTMDXJxNPwAoC(qQzyitXlNMuv3URZDPC,CtFdnT63cj,ynudfqwcmvj3DbFLMYZ7BC,OeRfVxSw51gvsJIHo84X9,nG4aYCUKzmZN,JAYWBoz54tGw7O,zTv29nJgMidktb1GmUO5ShIWC0jZ,n52GI1hMv4HzJb,WYHrghdGnu82p0lBs7aTSv5AX,KLJu3k4l7heRZSnpXEs):
	for D8QslnRP0KIkdYcbviAGTSEo7U69z in qQzyitXlNMuv3URZDPC: globals()[D8QslnRP0KIkdYcbviAGTSEo7U69z] = qQzyitXlNMuv3URZDPC[D8QslnRP0KIkdYcbviAGTSEo7U69z]
	global XzWD8Jkd4KmnslhZLeEtAx,RMCNjnxwmdbf2yHErXQaF
	if zTv29nJgMidktb1GmUO5ShIWC0jZ!=tRnTydV03Xfi7rbQ(u"ࠧ࡮ࡧࡱࡹࡤ࡯ࡴࡦ࡯ࠪత"):
		LqfKnT8geEwWSRPd0zvFs2oQ = Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.getSetting(rbUkdYi32PJaRtnxhDvQs(u"ࠨࡣࡹ࠲ࡱࡧ࡮ࡨࡷࡤ࡫ࡪ࠴ࡴࡳࡣࡱࡷࡱࡧࡴࡦࠩథ"))
		if LqfKnT8geEwWSRPd0zvFs2oQ:
			if CtFdnT63cj==TtyzcuW45VKA(u"้ࠩ฽๊࡚ࠦࠠࡧࡶࠫద"): CtFdnT63cj = KNomgGw1kdMCBH(u"ࠪ࡝ࡪࡹࠧధ")
			elif CtFdnT63cj==zDek1IW37rq6UoKdwyRiAVpF(u"่๊ࠫวࠡࠢࡑࡳࠬన"): CtFdnT63cj = xN4fKmsnyM3Y2(u"ࠬࡔ࡯ࠨ఩")
			if ynudfqwcmvj3DbFLMYZ7BC==liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"࠭ๆฺ็ࠣࠤ࡞࡫ࡳࠨప"): ynudfqwcmvj3DbFLMYZ7BC = nfg30bHwd4aNV12SR7UjFck(u"࡚ࠧࡧࡶࠫఫ")
			elif ynudfqwcmvj3DbFLMYZ7BC==zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"ࠨๅ็หࠥࠦࡎࡰࠩబ"): ynudfqwcmvj3DbFLMYZ7BC = rbUkdYi32PJaRtnxhDvQs(u"ࠩࡑࡳࠬభ")
			if OeRfVxSw51gvsJIHo84X9==nfg30bHwd4aNV12SR7UjFck(u"๊ࠪ฾๋࡛ࠠࠡࡨࡷࠬమ"): OeRfVxSw51gvsJIHo84X9 = WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠫ࡞࡫ࡳࠨయ")
			elif OeRfVxSw51gvsJIHo84X9==aar0zhDnJsOTP7EdgR16HIS29(u"้ࠬไศࠢࠣࡒࡴ࠭ర"): OeRfVxSw51gvsJIHo84X9 = AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"࠭ࡎࡰࠩఱ")
			import RYQDcI9Uz8
			iiAOHkqYIRW7Bs46CEj3Layefb2hSP = RYQDcI9Uz8.J1iFaQB68GCIyUjw5DnsfY([CtFdnT63cj,ynudfqwcmvj3DbFLMYZ7BC,OeRfVxSw51gvsJIHo84X9,nG4aYCUKzmZN,JAYWBoz54tGw7O])
			if iiAOHkqYIRW7Bs46CEj3Layefb2hSP: CtFdnT63cj,ynudfqwcmvj3DbFLMYZ7BC,OeRfVxSw51gvsJIHo84X9,nG4aYCUKzmZN,JAYWBoz54tGw7O = iiAOHkqYIRW7Bs46CEj3Layefb2hSP
	if xicJPb0AW1nsRfH3kCv7:
		JAYWBoz54tGw7O = JAYWBoz54tGw7O.decode(vczMIlkCAh2u10B3)
		nG4aYCUKzmZN = nG4aYCUKzmZN.decode(vczMIlkCAh2u10B3)
		CtFdnT63cj = CtFdnT63cj.decode(vczMIlkCAh2u10B3)
		ynudfqwcmvj3DbFLMYZ7BC = ynudfqwcmvj3DbFLMYZ7BC.decode(vczMIlkCAh2u10B3)
		OeRfVxSw51gvsJIHo84X9 = OeRfVxSw51gvsJIHo84X9.decode(vczMIlkCAh2u10B3)
	ZAEhUVy0Jq9D8 = nG4aYCUKzmZN.count(ssELJkeScrtni2)+hiuZa0PIsErm6UC7
	eNkyB2QKAoR46YlJMuDw = bG85WlQImE7HiR+ZAEhUVy0Jq9D8*(nqHjc6gA0RzPX8da4li+wiJ7T32ftC01eNqclM)-wiJ7T32ftC01eNqclM
	if JAYWBoz54tGw7O:
		PZ7XxBVKT0AEpHOhr = M9MbeYOchAz8CIaNg30H+TnxAIHWgUe53M
		VV2tbuY4ycaGFwDWE8eSLQPMrTno7l = ycn2GYMwj8hJ43O.reshape(JAYWBoz54tGw7O)
		if O1OEYlMtG2mL:
			jjNHfi4nl7bR6VQv0xYEKAoXpqT = KwJuBYmAQPeoLCHdlDhs4q9f(sFS7CyaogPixj,AOVW4GofHY2w1b9,VV2tbuY4ycaGFwDWE8eSLQPMrTno7l,EUIloAzfJndH,dbPcolZi2n,PZ7XxBVKT0AEpHOhr)
			AVOTfmPZErb97dJI = BVYa7Mp6rqOnSKPJoQfjHk1lG(jjNHfi4nl7bR6VQv0xYEKAoXpqT)
			NNyOkDPQMSH4iVWcKgFXUmZ0 = AVOTfmPZErb97dJI.count(ssELJkeScrtni2)+hiuZa0PIsErm6UC7
			OOsZaAv1Ep4z53uRC0bjMtJgTm = mWQJlHBTSIzgX40rZYk61udLbAqvC+NNyOkDPQMSH4iVWcKgFXUmZ0*PZ7XxBVKT0AEpHOhr-TnxAIHWgUe53M
		else:
			OOsZaAv1Ep4z53uRC0bjMtJgTm = mWQJlHBTSIzgX40rZYk61udLbAqvC+M9MbeYOchAz8CIaNg30H
			AVOTfmPZErb97dJI = VV2tbuY4ycaGFwDWE8eSLQPMrTno7l.split(ssELJkeScrtni2)[nnsBpJv6XL3OzHoe4Vuhr]
			jjNHfi4nl7bR6VQv0xYEKAoXpqT = VV2tbuY4ycaGFwDWE8eSLQPMrTno7l.split(ssELJkeScrtni2)[nnsBpJv6XL3OzHoe4Vuhr]
	else: OOsZaAv1Ep4z53uRC0bjMtJgTm = mWQJlHBTSIzgX40rZYk61udLbAqvC
	oDbPchQaESpCmj7fut = TthuqGvBm3afdZC+nmwSUe0YoTcd1AQkvPVbIRtEg
	if WYHrghdGnu82p0lBs7aTSv5AX:
		NO0dCJtHQvAGz = KK9MhCIe27LbOk-GGr8ZQmXATWUEwi2YhV0ozJBsvCqgf
		oDbPchQaESpCmj7fut += NO0dCJtHQvAGz
	else: NO0dCJtHQvAGz = nnsBpJv6XL3OzHoe4Vuhr
	if CtFdnT63cj or ynudfqwcmvj3DbFLMYZ7BC or OeRfVxSw51gvsJIHo84X9: oDbPchQaESpCmj7fut += D8kceszFadWt9I
	zzNySgubK6wIZsR9vWeqG4iFL8Vx = K0KDWv51B74Sotxw if K0KDWv51B74Sotxw!=SGazRxP3yBKZ15ILuch(u"ࠧࡖࡒࡓࡉࡗ࠭ల") else eNkyB2QKAoR46YlJMuDw+OOsZaAv1Ep4z53uRC0bjMtJgTm+oDbPchQaESpCmj7fut
	kkGUb6ZSLNoFfsTt5KBzWvhgCQ = EIkMYyBat4mqQ.new(NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠨࡔࡊࡆࡆ࠭ళ"),(xxIJtWbQwrksDO483PumzHY,zzNySgubK6wIZsR9vWeqG4iFL8Vx),(WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"࠳࠷࠸೛"),WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"࠳࠷࠸೛"),WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"࠳࠷࠸೛"),nnsBpJv6XL3OzHoe4Vuhr))
	M0aJhlKWQS5zjrLN3 = uTkGqlvB241FDhg.Draw(kkGUb6ZSLNoFfsTt5KBzWvhgCQ)
	qMRylOHEFTCQ9S6ZB7DzPr2wA = zzNySgubK6wIZsR9vWeqG4iFL8Vx-eNkyB2QKAoR46YlJMuDw-oDbPchQaESpCmj7fut-mWQJlHBTSIzgX40rZYk61udLbAqvC
	if not ynudfqwcmvj3DbFLMYZ7BC and CtFdnT63cj and OeRfVxSw51gvsJIHo84X9:
		XzWD8Jkd4KmnslhZLeEtAx += tRnTydV03Xfi7rbQ(u"࠳࠳࠹೜")
		RMCNjnxwmdbf2yHErXQaF -= HC9xWUMpBQJEuTteAqjd(u"࠴࠵࠵ೝ")
	import bidi.algorithm as Fx1YX359sET
	if nG4aYCUKzmZN:
		mIWBJ7EYkT0VFogN = bG85WlQImE7HiR
		nG4aYCUKzmZN = Fx1YX359sET.get_display(ycn2GYMwj8hJ43O.reshape(nG4aYCUKzmZN))
		oPs342UIN6ieO9BVJWZpfXE = nG4aYCUKzmZN.splitlines()
		for uvjQ0YydJMPkbGeg8I3FUslAW in oPs342UIN6ieO9BVJWZpfXE:
			if uvjQ0YydJMPkbGeg8I3FUslAW:
				LoyAGrpeCSTUW6caln,TQf7cFZkAVsBWjCH = M0aJhlKWQS5zjrLN3.textsize(uvjQ0YydJMPkbGeg8I3FUslAW,font=CSuOXaAklxDs)
				if WSrbs0tNYa==LJPOQNK1mcG(u"ࠩࡦࡩࡳࡺࡥࡳࠩఴ"): kEwLvCOJemcgzhQtsVf7j4yr = H3H4NLuXdyY7sJxBvIe+(xxIJtWbQwrksDO483PumzHY-LoyAGrpeCSTUW6caln)/bVX3ev1spE
				elif WSrbs0tNYa==tRnTydV03Xfi7rbQ(u"ࠪࡶ࡮࡭ࡨࡵࠩవ"): kEwLvCOJemcgzhQtsVf7j4yr = H3H4NLuXdyY7sJxBvIe+xxIJtWbQwrksDO483PumzHY-LoyAGrpeCSTUW6caln-q7CxJAGidjFl6oB8PU1rOEMLNce
				elif WSrbs0tNYa==rbUkdYi32PJaRtnxhDvQs(u"ࠫࡱ࡫ࡦࡵࠩశ"): kEwLvCOJemcgzhQtsVf7j4yr = H3H4NLuXdyY7sJxBvIe+q7CxJAGidjFl6oB8PU1rOEMLNce
				M0aJhlKWQS5zjrLN3.text((kEwLvCOJemcgzhQtsVf7j4yr,mIWBJ7EYkT0VFogN),uvjQ0YydJMPkbGeg8I3FUslAW,font=CSuOXaAklxDs,fill=S5fhsRT8JV(u"ࠬࡿࡥ࡭࡮ࡲࡻࠬష"))
			mIWBJ7EYkT0VFogN += aMspEDBC7xKmk34GVhZYU8+wiJ7T32ftC01eNqclM
	if CtFdnT63cj or ynudfqwcmvj3DbFLMYZ7BC or OeRfVxSw51gvsJIHo84X9:
		k4aL26jNg5UPSAXo3YxlR = eNkyB2QKAoR46YlJMuDw+qMRylOHEFTCQ9S6ZB7DzPr2wA+mWQJlHBTSIzgX40rZYk61udLbAqvC+NO0dCJtHQvAGz+TthuqGvBm3afdZC
		if CtFdnT63cj:
			CtFdnT63cj = Fx1YX359sET.get_display(ycn2GYMwj8hJ43O.reshape(CtFdnT63cj))
			AQxL9vStyH1nE,OiSaDPgnWzdx4FrwtIJvM = M0aJhlKWQS5zjrLN3.textsize(CtFdnT63cj,font=g3OSaedypYMNBR0x2XHAk7imsqb)
			Yb9wOUFHetQ = XzWD8Jkd4KmnslhZLeEtAx+nnsBpJv6XL3OzHoe4Vuhr*(RMCNjnxwmdbf2yHErXQaF+QDjURfxoeWBalM4cG)+(QDjURfxoeWBalM4cG-AQxL9vStyH1nE)/bVX3ev1spE
			M0aJhlKWQS5zjrLN3.text((Yb9wOUFHetQ,k4aL26jNg5UPSAXo3YxlR),CtFdnT63cj,font=g3OSaedypYMNBR0x2XHAk7imsqb,fill=vbYokBuWlxeLDcdVNM60(u"࠭ࡹࡦ࡮࡯ࡳࡼ࠭స"))
		if ynudfqwcmvj3DbFLMYZ7BC:
			ynudfqwcmvj3DbFLMYZ7BC = Fx1YX359sET.get_display(ycn2GYMwj8hJ43O.reshape(ynudfqwcmvj3DbFLMYZ7BC))
			GZfdXBNqUm8bMDsut15,shjHgl1dAQ7xWFEbTtJKBr = M0aJhlKWQS5zjrLN3.textsize(ynudfqwcmvj3DbFLMYZ7BC,font=g3OSaedypYMNBR0x2XHAk7imsqb)
			ZkY4omJcu8nlzvBX7WO = XzWD8Jkd4KmnslhZLeEtAx+hiuZa0PIsErm6UC7*(RMCNjnxwmdbf2yHErXQaF+QDjURfxoeWBalM4cG)+(QDjURfxoeWBalM4cG-GZfdXBNqUm8bMDsut15)/bVX3ev1spE
			M0aJhlKWQS5zjrLN3.text((ZkY4omJcu8nlzvBX7WO,k4aL26jNg5UPSAXo3YxlR),ynudfqwcmvj3DbFLMYZ7BC,font=g3OSaedypYMNBR0x2XHAk7imsqb,fill=aar0zhDnJsOTP7EdgR16HIS29(u"ࠧࡺࡧ࡯ࡰࡴࡽࠧహ"))
		if OeRfVxSw51gvsJIHo84X9:
			OeRfVxSw51gvsJIHo84X9 = Fx1YX359sET.get_display(ycn2GYMwj8hJ43O.reshape(OeRfVxSw51gvsJIHo84X9))
			ggm9Dtv6EkpfLSU0od2nFXHc5a1YAu,t8AjfXlTQaZ05BJFempsy = M0aJhlKWQS5zjrLN3.textsize(OeRfVxSw51gvsJIHo84X9,font=g3OSaedypYMNBR0x2XHAk7imsqb)
			sQB9dg6Y1fwL40pe8tFXMhjx = XzWD8Jkd4KmnslhZLeEtAx+bVX3ev1spE*(RMCNjnxwmdbf2yHErXQaF+QDjURfxoeWBalM4cG)+(QDjURfxoeWBalM4cG-ggm9Dtv6EkpfLSU0od2nFXHc5a1YAu)/bVX3ev1spE
			M0aJhlKWQS5zjrLN3.text((sQB9dg6Y1fwL40pe8tFXMhjx,k4aL26jNg5UPSAXo3YxlR),OeRfVxSw51gvsJIHo84X9,font=g3OSaedypYMNBR0x2XHAk7imsqb,fill=zDek1IW37rq6UoKdwyRiAVpF(u"ࠨࡻࡨࡰࡱࡵࡷࠨ఺"))
	if JAYWBoz54tGw7O:
		gGRFYvQwtWlzU9L,knFCHiyTEQ9xolmsVpXP8v = [],[]
		jjNHfi4nl7bR6VQv0xYEKAoXpqT = r6rxWgbw9NJqdHSTFfPYBsMjEkU0l(jjNHfi4nl7bR6VQv0xYEKAoXpqT)
		iiK846yTcZFVJdvQWOR1e = jjNHfi4nl7bR6VQv0xYEKAoXpqT.split(nfg30bHwd4aNV12SR7UjFck(u"ࠩࡢࡷࡸࡹ࡟ࡠࡰࡨࡻࡱ࡯࡮ࡦࡡࠪ఻"))
		for o9KTeksUEpOlv7 in iiK846yTcZFVJdvQWOR1e:
			P1UjsToLCvyZ9Gpku0 = n52GI1hMv4HzJb
			if   zDek1IW37rq6UoKdwyRiAVpF(u"ࠪࡣࡸࡹࡳࡠࡡ࡯࡭ࡳ࡫࡬ࡦࡨࡷࡣ఼ࠬ") in o9KTeksUEpOlv7: P1UjsToLCvyZ9Gpku0 = dwiIAcPl04ey7Zv38Mz(u"ࠫࡱ࡫ࡦࡵࠩఽ")
			elif KNomgGw1kdMCBH(u"ࠬࡥࡳࡴࡵࡢࡣࡱ࡯࡮ࡦࡴ࡬࡫࡭ࡺ࡟ࠨా") in o9KTeksUEpOlv7: P1UjsToLCvyZ9Gpku0 = opyTNwHgfqbZREWKU(u"࠭ࡲࡪࡩ࡫ࡸࠬి")
			elif NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠧࡠࡵࡶࡷࡤࡥ࡬ࡪࡰࡨࡧࡪࡴࡴࡦࡴࡢࠫీ") in o9KTeksUEpOlv7: P1UjsToLCvyZ9Gpku0 = AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨు")
			eaDLdCQGyFVv3ZM8qzUH5icp0uB9hx = o9KTeksUEpOlv7
			u4wYLZBMdV6RmUArCbEl = ffUFBJQ57j2XgoGeOLn9uwpC.findall(LungQF89BqemOb32jJsZlW(u"ࠩࡢࡷࡸࡹ࡟ࡠ࠰࠭ࡃࡤ࠭ూ"),o9KTeksUEpOlv7,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			for InZi3vMBU1KQGWLm6wDbo0 in u4wYLZBMdV6RmUArCbEl: eaDLdCQGyFVv3ZM8qzUH5icp0uB9hx = eaDLdCQGyFVv3ZM8qzUH5icp0uB9hx.replace(InZi3vMBU1KQGWLm6wDbo0,cdZKMn68Pzg4)
			if eaDLdCQGyFVv3ZM8qzUH5icp0uB9hx==cdZKMn68Pzg4: LoyAGrpeCSTUW6caln,TQf7cFZkAVsBWjCH = nnsBpJv6XL3OzHoe4Vuhr,PZ7XxBVKT0AEpHOhr
			else: LoyAGrpeCSTUW6caln,TQf7cFZkAVsBWjCH = M0aJhlKWQS5zjrLN3.textsize(eaDLdCQGyFVv3ZM8qzUH5icp0uB9hx,font=AOVW4GofHY2w1b9)
			if   P1UjsToLCvyZ9Gpku0==AiCor1fIVTDxQUWwHe9vPR7(u"ࠪࡰࡪ࡬ࡴࠨృ"): kTGDFSmcQeiEfBthW5voruj8LNyM7w = c4A8LbQty3qn6ZdzTgv+gmD4HCPzu5f0WERs8wQ23ITNqZY
			elif P1UjsToLCvyZ9Gpku0==vbYokBuWlxeLDcdVNM60(u"ࠫࡷ࡯ࡧࡩࡶࠪౄ"): kTGDFSmcQeiEfBthW5voruj8LNyM7w = c4A8LbQty3qn6ZdzTgv+gmD4HCPzu5f0WERs8wQ23ITNqZY+dbPcolZi2n-LoyAGrpeCSTUW6caln
			elif P1UjsToLCvyZ9Gpku0==HC9xWUMpBQJEuTteAqjd(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ౅"): kTGDFSmcQeiEfBthW5voruj8LNyM7w = c4A8LbQty3qn6ZdzTgv+gmD4HCPzu5f0WERs8wQ23ITNqZY+(dbPcolZi2n-LoyAGrpeCSTUW6caln)/bVX3ev1spE
			if kTGDFSmcQeiEfBthW5voruj8LNyM7w<gmD4HCPzu5f0WERs8wQ23ITNqZY: kTGDFSmcQeiEfBthW5voruj8LNyM7w = c4A8LbQty3qn6ZdzTgv+gmD4HCPzu5f0WERs8wQ23ITNqZY
			gGRFYvQwtWlzU9L.append(kTGDFSmcQeiEfBthW5voruj8LNyM7w)
			knFCHiyTEQ9xolmsVpXP8v.append(LoyAGrpeCSTUW6caln)
		kTGDFSmcQeiEfBthW5voruj8LNyM7w = gGRFYvQwtWlzU9L[nnsBpJv6XL3OzHoe4Vuhr]
		flCsbyzjnthQRk10H7gF2IxJc8Po = jjNHfi4nl7bR6VQv0xYEKAoXpqT.split(k5oIaYyp2mnrLK49qhzS(u"࠭࡟ࡴࡵࡶࡣࠬె"))
		Ti5DOlGkwrYfA9W = (aNdix5gq7yeFHTMWhnzm8pX0Y16(u"࠶࠺࠻ೞ"),aNdix5gq7yeFHTMWhnzm8pX0Y16(u"࠶࠺࠻ೞ"),aNdix5gq7yeFHTMWhnzm8pX0Y16(u"࠶࠺࠻ೞ"),aNdix5gq7yeFHTMWhnzm8pX0Y16(u"࠶࠺࠻ೞ"))
		yDFQo1mwRpTBHWGIcS3hMJrl8O0q = Ti5DOlGkwrYfA9W
		Hgadz4S0IoB6iquATZ5K,i8iNtbwnOU1XT7Ysx25aSl6ukK = nnsBpJv6XL3OzHoe4Vuhr,nnsBpJv6XL3OzHoe4Vuhr
		ONYoQCJy8HBd = ksTLSoVGg0ht
		xzX4BmowcsM = nnsBpJv6XL3OzHoe4Vuhr
		lHfIz0ASde98bTOFmWvNMDKoJ6a = eNkyB2QKAoR46YlJMuDw+mWQJlHBTSIzgX40rZYk61udLbAqvC/bVX3ev1spE
		if OOsZaAv1Ep4z53uRC0bjMtJgTm<(qMRylOHEFTCQ9S6ZB7DzPr2wA+mWQJlHBTSIzgX40rZYk61udLbAqvC):
			gLenHYJ9svqkhjZUK6fFoP = (qMRylOHEFTCQ9S6ZB7DzPr2wA+mWQJlHBTSIzgX40rZYk61udLbAqvC-OOsZaAv1Ep4z53uRC0bjMtJgTm)/bVX3ev1spE
			lHfIz0ASde98bTOFmWvNMDKoJ6a = eNkyB2QKAoR46YlJMuDw+mWQJlHBTSIzgX40rZYk61udLbAqvC+gLenHYJ9svqkhjZUK6fFoP-M9MbeYOchAz8CIaNg30H/bVX3ev1spE
		for uvjQ0YydJMPkbGeg8I3FUslAW in flCsbyzjnthQRk10H7gF2IxJc8Po:
			if not uvjQ0YydJMPkbGeg8I3FUslAW or (uvjQ0YydJMPkbGeg8I3FUslAW and ord(uvjQ0YydJMPkbGeg8I3FUslAW[nnsBpJv6XL3OzHoe4Vuhr])==vbYokBuWlxeLDcdVNM60(u"࠻࠻࠲࠸࠻೟")): continue
			azFNIWrsUBZvYy3Mm84Jbu6HlXTL = uvjQ0YydJMPkbGeg8I3FUslAW.split(xN4fKmsnyM3Y2(u"ࠧࡠࡰࡨࡻࡱ࡯࡮ࡦࡡࠪే"),hiuZa0PIsErm6UC7)
			Wo6Ib3dAm1EzRx5hQU2pLBOkj = uvjQ0YydJMPkbGeg8I3FUslAW.split(KNomgGw1kdMCBH(u"ࠨࡡࡱࡩࡼࡩ࡯࡭ࡱࡵࠫై"),hiuZa0PIsErm6UC7)
			ccWQuG3sxiIP = uvjQ0YydJMPkbGeg8I3FUslAW.split(opyTNwHgfqbZREWKU(u"ࠩࡢࡩࡳࡪࡣࡰ࡮ࡲࡶࡤ࠭౉"),hiuZa0PIsErm6UC7)
			IIYyA51PkGFuUrNhQtjEH4m8OvgoLz = uvjQ0YydJMPkbGeg8I3FUslAW.split(LungQF89BqemOb32jJsZlW(u"ࠪࡣࡱ࡯࡮ࡦࡴࡷࡰࡤ࠭ొ"),hiuZa0PIsErm6UC7)
			mXtjRqyVJK5hLkTp743iNOHz = uvjQ0YydJMPkbGeg8I3FUslAW.split(dwiIAcPl04ey7Zv38Mz(u"ࠫࡤࡲࡩ࡯ࡧ࡯ࡩ࡫ࡺ࡟ࠨో"),hiuZa0PIsErm6UC7)
			HwuFR8epVmclQdzioxX25 = uvjQ0YydJMPkbGeg8I3FUslAW.split(Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠬࡥ࡬ࡪࡰࡨࡶ࡮࡭ࡨࡵࡡࠪౌ"),hiuZa0PIsErm6UC7)
			w8Pt6vxoC3OZiV = uvjQ0YydJMPkbGeg8I3FUslAW.split(zDek1IW37rq6UoKdwyRiAVpF(u"࠭࡟࡭࡫ࡱࡩࡨ࡫࡮ࡵࡧࡵࡣ్ࠬ"),hiuZa0PIsErm6UC7)
			if len(azFNIWrsUBZvYy3Mm84Jbu6HlXTL)>hiuZa0PIsErm6UC7:
				xzX4BmowcsM += hiuZa0PIsErm6UC7
				uvjQ0YydJMPkbGeg8I3FUslAW = azFNIWrsUBZvYy3Mm84Jbu6HlXTL[hiuZa0PIsErm6UC7]
				Hgadz4S0IoB6iquATZ5K = nnsBpJv6XL3OzHoe4Vuhr
				kTGDFSmcQeiEfBthW5voruj8LNyM7w = gGRFYvQwtWlzU9L[xzX4BmowcsM]
				i8iNtbwnOU1XT7Ysx25aSl6ukK += PZ7XxBVKT0AEpHOhr
				ONYoQCJy8HBd = ksTLSoVGg0ht
			elif len(Wo6Ib3dAm1EzRx5hQU2pLBOkj)>hiuZa0PIsErm6UC7:
				uvjQ0YydJMPkbGeg8I3FUslAW = Wo6Ib3dAm1EzRx5hQU2pLBOkj[hiuZa0PIsErm6UC7]
				yDFQo1mwRpTBHWGIcS3hMJrl8O0q = uvjQ0YydJMPkbGeg8I3FUslAW[nnsBpJv6XL3OzHoe4Vuhr:J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"࠾ೠ")]
				yDFQo1mwRpTBHWGIcS3hMJrl8O0q = HC9xWUMpBQJEuTteAqjd(u"ࠧࠤࠩ౎")+yDFQo1mwRpTBHWGIcS3hMJrl8O0q[bVX3ev1spE:]
				uvjQ0YydJMPkbGeg8I3FUslAW = uvjQ0YydJMPkbGeg8I3FUslAW[On1WZJc6dtksqVNgSQ5GBAjuipe(u"࠹ೡ"):]
			elif len(ccWQuG3sxiIP)>hiuZa0PIsErm6UC7:
				uvjQ0YydJMPkbGeg8I3FUslAW = ccWQuG3sxiIP[hiuZa0PIsErm6UC7]
				yDFQo1mwRpTBHWGIcS3hMJrl8O0q = Ti5DOlGkwrYfA9W
			elif len(IIYyA51PkGFuUrNhQtjEH4m8OvgoLz)>hiuZa0PIsErm6UC7:
				uvjQ0YydJMPkbGeg8I3FUslAW = IIYyA51PkGFuUrNhQtjEH4m8OvgoLz[hiuZa0PIsErm6UC7]
				ONYoQCJy8HBd = IZQbmFzLHDtXfc
				Hgadz4S0IoB6iquATZ5K = knFCHiyTEQ9xolmsVpXP8v[xzX4BmowcsM]
			elif len(mXtjRqyVJK5hLkTp743iNOHz)>aNdix5gq7yeFHTMWhnzm8pX0Y16(u"࠲ೢ"): uvjQ0YydJMPkbGeg8I3FUslAW = mXtjRqyVJK5hLkTp743iNOHz[hiuZa0PIsErm6UC7]
			elif len(HwuFR8epVmclQdzioxX25)>rbUkdYi32PJaRtnxhDvQs(u"࠳ೣ"): uvjQ0YydJMPkbGeg8I3FUslAW = HwuFR8epVmclQdzioxX25[hiuZa0PIsErm6UC7]
			elif len(w8Pt6vxoC3OZiV)>Rsdai9xIEPcpuBMKOUwkTA05q(u"࠴೤"): uvjQ0YydJMPkbGeg8I3FUslAW = w8Pt6vxoC3OZiV[hiuZa0PIsErm6UC7]
			if uvjQ0YydJMPkbGeg8I3FUslAW:
				QQjoELeCVURkmar = lHfIz0ASde98bTOFmWvNMDKoJ6a+i8iNtbwnOU1XT7Ysx25aSl6ukK
				uvjQ0YydJMPkbGeg8I3FUslAW = Fx1YX359sET.get_display(uvjQ0YydJMPkbGeg8I3FUslAW)
				LoyAGrpeCSTUW6caln,TQf7cFZkAVsBWjCH = M0aJhlKWQS5zjrLN3.textsize(uvjQ0YydJMPkbGeg8I3FUslAW,font=AOVW4GofHY2w1b9)
				if ONYoQCJy8HBd: Hgadz4S0IoB6iquATZ5K -= LoyAGrpeCSTUW6caln
				irQ5DHfe2MmkK8X7ycNGJRhV9Zj = kTGDFSmcQeiEfBthW5voruj8LNyM7w+Hgadz4S0IoB6iquATZ5K
				M0aJhlKWQS5zjrLN3.text((irQ5DHfe2MmkK8X7ycNGJRhV9Zj,QQjoELeCVURkmar),uvjQ0YydJMPkbGeg8I3FUslAW,font=AOVW4GofHY2w1b9,fill=yDFQo1mwRpTBHWGIcS3hMJrl8O0q)
				if zTv29nJgMidktb1GmUO5ShIWC0jZ==HC9xWUMpBQJEuTteAqjd(u"ࠨ࡯ࡨࡲࡺࡥࡩࡵࡧࡰࠫ౏"): M0aJhlKWQS5zjrLN3.text((irQ5DHfe2MmkK8X7ycNGJRhV9Zj+hiuZa0PIsErm6UC7,QQjoELeCVURkmar+hiuZa0PIsErm6UC7),uvjQ0YydJMPkbGeg8I3FUslAW,font=AOVW4GofHY2w1b9,fill=yDFQo1mwRpTBHWGIcS3hMJrl8O0q)
				if not ONYoQCJy8HBd: Hgadz4S0IoB6iquATZ5K += LoyAGrpeCSTUW6caln
				if QQjoELeCVURkmar>qMRylOHEFTCQ9S6ZB7DzPr2wA+PZ7XxBVKT0AEpHOhr: break
	if zTv29nJgMidktb1GmUO5ShIWC0jZ==tRnTydV03Xfi7rbQ(u"ࠩࡰࡩࡳࡻ࡟ࡪࡶࡨࡱࠬ౐"):
		jVJ7GgclZT16mhL38aS9EdFxvzi5N = iZnvbBjMWU53C6GLdt04TRO8c1Kwx.copy()
		bD7kJZhMCdaqF68P45KlNIgO1.sleep(xN4fKmsnyM3Y2(u"࠴࠳࠶࠵೥"))
		jVJ7GgclZT16mhL38aS9EdFxvzi5N.paste(yGZRtuXbTlKkw9Yg,(nnsBpJv6XL3OzHoe4Vuhr,nnsBpJv6XL3OzHoe4Vuhr),mask=kkGUb6ZSLNoFfsTt5KBzWvhgCQ)
	else: jVJ7GgclZT16mhL38aS9EdFxvzi5N = kkGUb6ZSLNoFfsTt5KBzWvhgCQ
	if xicJPb0AW1nsRfH3kCv7: KLJu3k4l7heRZSnpXEs = KLJu3k4l7heRZSnpXEs.decode(vczMIlkCAh2u10B3)
	try: jVJ7GgclZT16mhL38aS9EdFxvzi5N.save(KLJu3k4l7heRZSnpXEs)
	except UnicodeError:
		if xicJPb0AW1nsRfH3kCv7:
			KLJu3k4l7heRZSnpXEs = KLJu3k4l7heRZSnpXEs.encode(vczMIlkCAh2u10B3)
			jVJ7GgclZT16mhL38aS9EdFxvzi5N.save(KLJu3k4l7heRZSnpXEs)
	return zzNySgubK6wIZsR9vWeqG4iFL8Vx
def KwJuBYmAQPeoLCHdlDhs4q9f(sFS7CyaogPixj,AOVW4GofHY2w1b9,I1INO6vHkEwp3eyX,CBuNTYWElL90rtGOszUIHi,dbPcolZi2n,DdIxnvkYA2l):
	nAV6sFydmpZ2OC8j,ssOipPKFLZR,thWzNxXoOdU2kIBR7 = cdZKMn68Pzg4,nnsBpJv6XL3OzHoe4Vuhr,LungQF89BqemOb32jJsZlW(u"࠶࠻࠰࠱࠲೦")
	I1INO6vHkEwp3eyX = I1INO6vHkEwp3eyX.replace(AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࠫ౑"),dwiIAcPl04ey7Zv38Mz(u"ࠫࡠࡉࡏࡍࡑࡕ࠾࠿ࡀࠧ౒"))
	B4JyZbFlvWHVt6z = dbPcolZi2n-CBuNTYWElL90rtGOszUIHi*bVX3ev1spE
	for Y79vW0TRAQdS26OcNJtKshCo85x in I1INO6vHkEwp3eyX.splitlines():
		ssOipPKFLZR += DdIxnvkYA2l
		urZTU4eE0g1AzpG,asueLX2AMdctIGFz6rkElRQ = nnsBpJv6XL3OzHoe4Vuhr,cdZKMn68Pzg4
		for yq4pWZHRreDUC8T7VL2 in Y79vW0TRAQdS26OcNJtKshCo85x.split(VBpIH2QSmvDGlA6TO3e):
			JJmrnVRIPX86WYS7M4Llzebo = BVYa7Mp6rqOnSKPJoQfjHk1lG(VBpIH2QSmvDGlA6TO3e+yq4pWZHRreDUC8T7VL2)
			rZ2PKnA47RpDNd,zJtk4fm8WFaiH2LRvcnqeuwjE5yoGQ = sFS7CyaogPixj.textsize(JJmrnVRIPX86WYS7M4Llzebo,font=AOVW4GofHY2w1b9)
			if urZTU4eE0g1AzpG+rZ2PKnA47RpDNd<B4JyZbFlvWHVt6z:
				if not asueLX2AMdctIGFz6rkElRQ: asueLX2AMdctIGFz6rkElRQ += yq4pWZHRreDUC8T7VL2
				else: asueLX2AMdctIGFz6rkElRQ += VBpIH2QSmvDGlA6TO3e+yq4pWZHRreDUC8T7VL2
				urZTU4eE0g1AzpG += rZ2PKnA47RpDNd
			else:
				if rZ2PKnA47RpDNd<B4JyZbFlvWHVt6z:
					asueLX2AMdctIGFz6rkElRQ += ObuCsdoDtKmhPLSMH8YGan(u"ࠬࡢ࡮ࠡࠩ౓")+yq4pWZHRreDUC8T7VL2
					ssOipPKFLZR += DdIxnvkYA2l
					urZTU4eE0g1AzpG = rZ2PKnA47RpDNd
				else:
					while rZ2PKnA47RpDNd>B4JyZbFlvWHVt6z:
						for ZoQJArX6xtaIG0MfLnvqEmD in range(hiuZa0PIsErm6UC7,len(VBpIH2QSmvDGlA6TO3e+yq4pWZHRreDUC8T7VL2),hiuZa0PIsErm6UC7):
							oomtPAsXSp3gLOcqHd = VBpIH2QSmvDGlA6TO3e+yq4pWZHRreDUC8T7VL2[:ZoQJArX6xtaIG0MfLnvqEmD]
							ssa0jnMif7XS4reAFlDTZ = yq4pWZHRreDUC8T7VL2[ZoQJArX6xtaIG0MfLnvqEmD:]
							niFrkvZXo7Uj = BVYa7Mp6rqOnSKPJoQfjHk1lG(oomtPAsXSp3gLOcqHd)
							aXInVKokFgGMqe07CH8459OrxuS,uwzGflvdAOesigL = sFS7CyaogPixj.textsize(niFrkvZXo7Uj,font=AOVW4GofHY2w1b9)
							if urZTU4eE0g1AzpG+aXInVKokFgGMqe07CH8459OrxuS>B4JyZbFlvWHVt6z:
								s583sbcJrKkFWUtpNY1Qq = rZ2PKnA47RpDNd-aXInVKokFgGMqe07CH8459OrxuS
								asueLX2AMdctIGFz6rkElRQ += oomtPAsXSp3gLOcqHd+ssELJkeScrtni2
								ssOipPKFLZR += DdIxnvkYA2l
								rZ2PKnA47RpDNd = s583sbcJrKkFWUtpNY1Qq
								if s583sbcJrKkFWUtpNY1Qq>B4JyZbFlvWHVt6z:
									urZTU4eE0g1AzpG = nnsBpJv6XL3OzHoe4Vuhr
									yq4pWZHRreDUC8T7VL2 = ssa0jnMif7XS4reAFlDTZ
								else:
									urZTU4eE0g1AzpG = s583sbcJrKkFWUtpNY1Qq
									asueLX2AMdctIGFz6rkElRQ += ssa0jnMif7XS4reAFlDTZ
								break
				if ssOipPKFLZR>thWzNxXoOdU2kIBR7: break
		nAV6sFydmpZ2OC8j += ssELJkeScrtni2+asueLX2AMdctIGFz6rkElRQ
		if ssOipPKFLZR>thWzNxXoOdU2kIBR7: break
	nAV6sFydmpZ2OC8j = nAV6sFydmpZ2OC8j[hiuZa0PIsErm6UC7:]
	nAV6sFydmpZ2OC8j = nAV6sFydmpZ2OC8j.replace(rbUkdYi32PJaRtnxhDvQs(u"࡛࠭ࡄࡑࡏࡓࡗࡀ࠺࠻ࠩ౔"),On1WZJc6dtksqVNgSQ5GBAjuipe(u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࠨౕ"))
	return nAV6sFydmpZ2OC8j
def BVYa7Mp6rqOnSKPJoQfjHk1lG(yq4pWZHRreDUC8T7VL2):
	if SGazRxP3yBKZ15ILuch(u"ࠨ࡝ౖࠪ") in yq4pWZHRreDUC8T7VL2 and zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"ࠩࡠࠫ౗") in yq4pWZHRreDUC8T7VL2:
		u4wYLZBMdV6RmUArCbEl = [kH8E2zqNyims6KJfI,aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠪ࡟࠴ࡘࡔࡍ࡟ࠪౘ"),LJPOQNK1mcG(u"ࠫࡠ࠵ࡌࡆࡈࡗࡡࠬౙ"),f8Ja1q5eO02B(u"ࠬࡡ࠯ࡓࡋࡊࡌ࡙ࡣࠧౚ"),vbYokBuWlxeLDcdVNM60(u"࡛࠭࠰ࡅࡈࡒ࡙ࡋࡒ࡞ࠩ౛"),WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠧ࡜ࡔࡗࡐࡢ࠭౜"),On1WZJc6dtksqVNgSQ5GBAjuipe(u"ࠨ࡝ࡏࡉࡋ࡚࡝ࠨౝ"),LungQF89BqemOb32jJsZlW(u"ࠩ࡞ࡖࡎࡍࡈࡕ࡟ࠪ౞"),vbYokBuWlxeLDcdVNM60(u"ࠪ࡟ࡈࡋࡎࡕࡇࡕࡡࠬ౟")]
		AANqYh1JT36uaDRPOpvKsUdxIy2nf = ffUFBJQ57j2XgoGeOLn9uwpC.findall(ObuCsdoDtKmhPLSMH8YGan(u"ࠫࡡࡡࡃࡐࡎࡒࡖࠥ࠴ࠪࡀ࡞ࡠࠫౠ"),yq4pWZHRreDUC8T7VL2,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		YcgHw38GndbqmzADEpN5yC = ffUFBJQ57j2XgoGeOLn9uwpC.findall(zDek1IW37rq6UoKdwyRiAVpF(u"ࠬࡢ࡛ࡄࡑࡏࡓࡗࡀ࠺࠻࠰࠭ࡃࡡࡣࠧౡ"),yq4pWZHRreDUC8T7VL2,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		en2wEZFiLPlp8K73tyuoICRAh = u4wYLZBMdV6RmUArCbEl+AANqYh1JT36uaDRPOpvKsUdxIy2nf+YcgHw38GndbqmzADEpN5yC
		for InZi3vMBU1KQGWLm6wDbo0 in en2wEZFiLPlp8K73tyuoICRAh: yq4pWZHRreDUC8T7VL2 = yq4pWZHRreDUC8T7VL2.replace(InZi3vMBU1KQGWLm6wDbo0,cdZKMn68Pzg4)
	return yq4pWZHRreDUC8T7VL2
def r6rxWgbw9NJqdHSTFfPYBsMjEkU0l(JAYWBoz54tGw7O):
	JAYWBoz54tGw7O = JAYWBoz54tGw7O.replace(ssELJkeScrtni2,aNdix5gq7yeFHTMWhnzm8pX0Y16(u"࠭࡟ࡴࡵࡶࡣࡤࡴࡥࡸ࡮࡬ࡲࡪࡥࠧౢ"))
	JAYWBoz54tGw7O = JAYWBoz54tGw7O.replace(vbYokBuWlxeLDcdVNM60(u"ࠧ࡜ࡔࡗࡐࡢ࠭ౣ"),iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠨࡡࡶࡷࡸࡥ࡟࡭࡫ࡱࡩࡷࡺ࡬ࡠࠩ౤"))
	JAYWBoz54tGw7O = JAYWBoz54tGw7O.replace(dwiIAcPl04ey7Zv38Mz(u"ࠩ࡞ࡐࡊࡌࡔ࡞ࠩ౥"),HC9xWUMpBQJEuTteAqjd(u"ࠪࡣࡸࡹࡳࡠࡡ࡯࡭ࡳ࡫࡬ࡦࡨࡷࡣࠬ౦"))
	JAYWBoz54tGw7O = JAYWBoz54tGw7O.replace(ObuCsdoDtKmhPLSMH8YGan(u"ࠫࡠࡘࡉࡈࡊࡗࡡࠬ౧"),KNomgGw1kdMCBH(u"ࠬࡥࡳࡴࡵࡢࡣࡱ࡯࡮ࡦࡴ࡬࡫࡭ࡺ࡟ࠨ౨"))
	JAYWBoz54tGw7O = JAYWBoz54tGw7O.replace(AiCor1fIVTDxQUWwHe9vPR7(u"࡛࠭ࡄࡇࡑࡘࡊࡘ࡝ࠨ౩"),nfg30bHwd4aNV12SR7UjFck(u"ࠧࡠࡵࡶࡷࡤࡥ࡬ࡪࡰࡨࡧࡪࡴࡴࡦࡴࡢࠫ౪"))
	JAYWBoz54tGw7O = JAYWBoz54tGw7O.replace(kH8E2zqNyims6KJfI,ObuCsdoDtKmhPLSMH8YGan(u"ࠨࡡࡶࡷࡸࡥ࡟ࡦࡰࡧࡧࡴࡲ࡯ࡳࡡࠪ౫"))
	ubPRO27w59 = ffUFBJQ57j2XgoGeOLn9uwpC.findall(opyTNwHgfqbZREWKU(u"ࠩ࡟࡟ࡈࡕࡌࡐࡔࠣࠬ࠳࠰࠿ࠪ࡞ࡠࠫ౬"),JAYWBoz54tGw7O,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	for Xj2UrS8vpyEsYCz in ubPRO27w59: JAYWBoz54tGw7O = JAYWBoz54tGw7O.replace(opyTNwHgfqbZREWKU(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࠫ౭")+Xj2UrS8vpyEsYCz+On1WZJc6dtksqVNgSQ5GBAjuipe(u"ࠫࡢ࠭౮"),S5fhsRT8JV(u"ࠬࡥࡳࡴࡵࡢࡣࡳ࡫ࡷࡤࡱ࡯ࡳࡷ࠭౯")+Xj2UrS8vpyEsYCz+opyTNwHgfqbZREWKU(u"࠭࡟ࠨ౰"))
	return JAYWBoz54tGw7O
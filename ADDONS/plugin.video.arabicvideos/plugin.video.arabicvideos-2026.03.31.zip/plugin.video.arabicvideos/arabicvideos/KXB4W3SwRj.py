# -*- coding: utf-8 -*-
from RgJNGc7YMP import *
UkXlAzsMcamKJrEIgnxi6bWh = 'CIMA4U'
headers = {'User-Agent':cdZKMn68Pzg4}
nc3GLkA65oxOd = '_C4U_'
cDTdfqVAF0BLGiX364IEwaZbr = USuRxnPlV5.SITESURLS[UkXlAzsMcamKJrEIgnxi6bWh][0]
cJWUPuDGM0Yybv5a9KnIrVzhH78 = ['مصارعة حرة','اخري','اخرى','الرئيسية','بدون إختيار','افلام','مسلسلات']
def HHN5EpbszV3iA2m89hGSQjaPgUZy(mode,url,text):
	if   mode==420: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = kUq58vC7x9hWma164JejMKQ()
	elif mode==421: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = GDQUH4fN02sIt81mAcY(url,text)
	elif mode==422: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = B7G46YUWzH0D1XRKO(url)
	elif mode==423: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = yIZWSuMpvs3(url)
	elif mode==424: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = XxcpMKIUzr0sVDngR(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==425: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = XxcpMKIUzr0sVDngR(url,'SPECIFIED_FILTER___'+text)
	elif mode==426: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = RPZbqous7rtdy56LeI18Cv04AKHW(url)
	elif mode==427: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = OOWry1B4vRJFVqPGn8mtKcgMI2h(url)
	elif mode==429: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = z4hetAJw3NaT9ROjG6xbZ5CHlW81(text)
	else: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = False
	return xsGUcR3ef6glKY5hQwpFXEaSt2mrIz
def kUq58vC7x9hWma164JejMKQ():
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',cDTdfqVAF0BLGiX364IEwaZbr,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'CIMA4U-MENU-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	u1P73L0UmkA4eaIBbCgZfrvRtJ = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	u1P73L0UmkA4eaIBbCgZfrvRtJ = u1P73L0UmkA4eaIBbCgZfrvRtJ[0].strip(KCQExdbYFqM)
	u1P73L0UmkA4eaIBbCgZfrvRtJ = CxlbPZwGTcH87e1sWhfSIz29uRUEpV(u1P73L0UmkA4eaIBbCgZfrvRtJ,'url')
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'بحث في الموقع',cdZKMn68Pzg4,429,cdZKMn68Pzg4,cdZKMn68Pzg4,'_REMEMBERRESULTS_')
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'فلتر محدد',u1P73L0UmkA4eaIBbCgZfrvRtJ,425)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'فلتر كامل',u1P73L0UmkA4eaIBbCgZfrvRtJ,424)
	zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+'الرئيسية',u1P73L0UmkA4eaIBbCgZfrvRtJ,421)
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('NavigationMenu(.*?)</div>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
	items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="*(.*?)"*>(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	for c0cDhidBlOn7,title in items:
		if title in cJWUPuDGM0Yybv5a9KnIrVzhH78: continue
		if '/actors' in c0cDhidBlOn7: title = 'أفلام النجوم'
		elif '/netflix' in c0cDhidBlOn7: title = 'أفلام ومسلسلات نيتفلكس'
		zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+title,c0cDhidBlOn7,421)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'قائمة تفصيلية',u1P73L0UmkA4eaIBbCgZfrvRtJ,427)
	return
def OOWry1B4vRJFVqPGn8mtKcgMI2h(website=cdZKMn68Pzg4):
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',cDTdfqVAF0BLGiX364IEwaZbr,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'CIMA4U-MENU-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('FilteringTitle(.*?)PageTitle',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
	items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('data-tax="*(.*?)"* data-id="*(.*?)[">]*<a href="*(.*?)[">]+.*?</div>(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	for rrb0SF6otehufCYOX4,id,c0cDhidBlOn7,title in items:
		if title in cJWUPuDGM0Yybv5a9KnIrVzhH78: continue
		if 'netflix-movies' in c0cDhidBlOn7: title = 'أفلام نيتفلكس'
		elif 'series-netflix' in c0cDhidBlOn7: title = 'مسلسلات نيتفلكس'
		zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+title,c0cDhidBlOn7,421,cdZKMn68Pzg4,cdZKMn68Pzg4,rrb0SF6otehufCYOX4+'|'+id)
	return
def GDQUH4fN02sIt81mAcY(url,w3wLtqKIc0=cdZKMn68Pzg4):
	if '/HomepageLoader/' in url: url = url.strip(KCQExdbYFqM)+'/mpaa/family/'
	items = []
	u1P73L0UmkA4eaIBbCgZfrvRtJ = CxlbPZwGTcH87e1sWhfSIz29uRUEpV(url,'url')
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',url,cdZKMn68Pzg4,headers,cdZKMn68Pzg4,cdZKMn68Pzg4,'CIMA4U-TITLES-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	if not w3wLtqKIc0 or '|' in w3wLtqKIc0:
		if '|' not in w3wLtqKIc0: MczA9EjoJbNSuCKPO7wrB42ksR = cdZKMn68Pzg4
		else: MczA9EjoJbNSuCKPO7wrB42ksR = '/archive/'+w3wLtqKIc0
		YlVJ4IRmk3vWf9S0rP7dMpK = False
		if 'PinSlider' in OO1cj2REUZHJ8x5V:
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'المميزة',url,421,cdZKMn68Pzg4,cdZKMn68Pzg4,'featured')
			YlVJ4IRmk3vWf9S0rP7dMpK = True
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('PageTitle(.*?)PageContent',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if ppvsMqCHf8SEzxQg:
			PfGSURJ9jeNtx7FX = ppvsMqCHf8SEzxQg[0]
			zaUqdBJDmY = ffUFBJQ57j2XgoGeOLn9uwpC.findall('data-tab="(.*?)".*?<span>(.*?)<',PfGSURJ9jeNtx7FX,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			for H0zqugk54xZU6,UHXfFEWmlxMAnzju4 in zaUqdBJDmY:
				cz5qCJd6O3g4ISxVa1EtQpysvGHPk = u1P73L0UmkA4eaIBbCgZfrvRtJ+'/ajaxcenter/action/HomepageLoader/tab/'+H0zqugk54xZU6+MczA9EjoJbNSuCKPO7wrB42ksR+KCQExdbYFqM
				zJLApFBcIhnSj('folder',nc3GLkA65oxOd+UHXfFEWmlxMAnzju4,cz5qCJd6O3g4ISxVa1EtQpysvGHPk,421)
				YlVJ4IRmk3vWf9S0rP7dMpK = True
		if YlVJ4IRmk3vWf9S0rP7dMpK: zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	if w3wLtqKIc0=='featured':
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('PinSlider(.*?)MultiFilter',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if not ppvsMqCHf8SEzxQg: ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('PinSlider(.*?)PageTitle',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if ppvsMqCHf8SEzxQg: KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		else: KdWauEhgN6OQzjRVm1ro8tkB3 = cdZKMn68Pzg4
	elif '/HomepageLoader/' in url or '/searchcenter/' in url:
		KdWauEhgN6OQzjRVm1ro8tkB3 = OO1cj2REUZHJ8x5V
	elif '/filter/' in url:
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('PageContent(.*?)class="*pagination"*',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
	elif '/actors' in url:
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('PageContent(.*?)class="*pagination"*',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="*(.*?)[">]+.*?image:url\((.*?)\).*?ActorName">(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	else:
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('Cima4uBlocks(.*?)</li></ul>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if ppvsMqCHf8SEzxQg: KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		else: KdWauEhgN6OQzjRVm1ro8tkB3 = cdZKMn68Pzg4
	if not items: items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="*MovieBlock"*.*?href="*(.*?)[">]+.*?image:url\((.*?)\).*?image.*?BoxTitleInfo.*?</div></div>(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if not items: items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="MovieBlock".*?href="(.*?)".*?data-image="(.*?)".*?alt="(.*?)"',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	KRmzvoWYyxfXw37SEh1Q = []
	for c0cDhidBlOn7,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,title in items:
		if not title: continue
		if '?news=' in c0cDhidBlOn7: continue
		title = title.replace('مشاهدة ',cdZKMn68Pzg4)
		title = gbd90SjF2mZqf81IRDaTwJkWu(title)
		E0w56WHxZPYGVvnTQ4O2t1C8DAjq = ffUFBJQ57j2XgoGeOLn9uwpC.findall('(.*?) حلقة \d+',title,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if E0w56WHxZPYGVvnTQ4O2t1C8DAjq and 'حلقة' in title:
			title = '_MOD_' + E0w56WHxZPYGVvnTQ4O2t1C8DAjq[0]
			if title not in KRmzvoWYyxfXw37SEh1Q:
				zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,422,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
				KRmzvoWYyxfXw37SEh1Q.append(title)
		elif '/actor/' in c0cDhidBlOn7: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,421,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
		else: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,422,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('pagination(.*?)</ul>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg and w3wLtqKIc0!='featured':
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href=[\'\"](.*?)[\'\"]>(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,title in items:
			title = gbd90SjF2mZqf81IRDaTwJkWu(title)
			title = title.replace('الصفحة ',cdZKMn68Pzg4)
			if title!=cdZKMn68Pzg4: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'صفحة '+title,c0cDhidBlOn7,421)
	UrOQ4PapMvq1kRiLeWSGYg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('</li><a href="(.*?)".*?>(.*?)<',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if UrOQ4PapMvq1kRiLeWSGYg:
		c0cDhidBlOn7,title = UrOQ4PapMvq1kRiLeWSGYg[0]
		zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,421)
	return
def B7G46YUWzH0D1XRKO(url):
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'CIMA4U-SEASONS-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="WatchNow".*?href="(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		url = ppvsMqCHf8SEzxQg[0]
		Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'CIMA4U-SEASONS-2nd')
		OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('SeasonsSections(.*?)</div></div></div>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if '/tag/' in url or '/actor' in url:
		GDQUH4fN02sIt81mAcY(url)
	elif ppvsMqCHf8SEzxQg:
		y90BoFz8MA1ZThaSC2ILXHiK3OY6w = bu6LzUQF7K.getInfoLabel('ListItem.Thumb')
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall("href='(.*?)'>(.*?)<",KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		pGXyYFvLVUZC = ['مسلسل','موسم','برنامج','حلقة']
		for c0cDhidBlOn7,title in items:
			if any(value in title for value in pGXyYFvLVUZC):
				zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,423,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
			else: zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,426,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
	else: yIZWSuMpvs3(url)
	return
def yIZWSuMpvs3(url):
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'CIMA4U-EPISODES-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	y90BoFz8MA1ZThaSC2ILXHiK3OY6w = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"background-image:url\((.*?)\)',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if y90BoFz8MA1ZThaSC2ILXHiK3OY6w: y90BoFz8MA1ZThaSC2ILXHiK3OY6w = y90BoFz8MA1ZThaSC2ILXHiK3OY6w[0]
	else: y90BoFz8MA1ZThaSC2ILXHiK3OY6w = cdZKMn68Pzg4
	dd4lCYjmc65feZy = ffUFBJQ57j2XgoGeOLn9uwpC.findall('EpisodesSection(.*?)</ul>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if dd4lCYjmc65feZy:
		KdWauEhgN6OQzjRVm1ro8tkB3 = dd4lCYjmc65feZy[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)"><em>(.*?)<.*?<span>(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,title,E0w56WHxZPYGVvnTQ4O2t1C8DAjq in items:
			title = title+VBpIH2QSmvDGlA6TO3e+E0w56WHxZPYGVvnTQ4O2t1C8DAjq
			zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,426,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
	else: zJLApFBcIhnSj('video',nc3GLkA65oxOd+'رابط التشغيل',url,426,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
	return
def RPZbqous7rtdy56LeI18Cv04AKHW(url):
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',url,cdZKMn68Pzg4,headers,cdZKMn68Pzg4,cdZKMn68Pzg4,'CIMA4U-PLAY-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	zdrY6v4usX9iSJLMwZ2VG = Zty0AsgQ5jpkTh91OW.url
	if xicJPb0AW1nsRfH3kCv7: zdrY6v4usX9iSJLMwZ2VG = zdrY6v4usX9iSJLMwZ2VG.encode(vczMIlkCAh2u10B3)
	u1P73L0UmkA4eaIBbCgZfrvRtJ = CxlbPZwGTcH87e1sWhfSIz29uRUEpV(zdrY6v4usX9iSJLMwZ2VG,'url')
	pcX7zxFRmsADwUr = []
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('WatchSection(.*?)</div></div>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('data-link="(.*?)".*? />(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for C5nqNRT6tDkg,title in items:
			title = title.strip(VBpIH2QSmvDGlA6TO3e)
			if 'myvid' in title.lower(): title = 'خاص '+title
			c0cDhidBlOn7 = u1P73L0UmkA4eaIBbCgZfrvRtJ+'/structure/server.php?id='+C5nqNRT6tDkg+'?named='+title+'__watch'
			c0cDhidBlOn7 = c0cDhidBlOn7.replace(CPjOZMmw8sfGg2B9LthIdXa1iKQUF,cdZKMn68Pzg4)
			pcX7zxFRmsADwUr.append(c0cDhidBlOn7)
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('DownloadServers(.*?)</div></div>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*? />(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,title in items:
			title = title.strip(VBpIH2QSmvDGlA6TO3e)
			if 'myvid' in title.lower(): UHXfFEWmlxMAnzju4 = '__خاص'
			else: UHXfFEWmlxMAnzju4 = cdZKMn68Pzg4
			c0cDhidBlOn7 = c0cDhidBlOn7+'?named='+title+'__download'+UHXfFEWmlxMAnzju4
			c0cDhidBlOn7 = c0cDhidBlOn7.replace(CPjOZMmw8sfGg2B9LthIdXa1iKQUF,cdZKMn68Pzg4)
			pcX7zxFRmsADwUr.append(c0cDhidBlOn7)
	import r0y4XTKznF
	r0y4XTKznF.noHliPXkcg3pJTdSauCvm5sU(pcX7zxFRmsADwUr,UkXlAzsMcamKJrEIgnxi6bWh,'video',url)
	return
def z4hetAJw3NaT9ROjG6xbZ5CHlW81(search):
	search,EL8zUgbXheot,showDialogs = qbIcHCMdkFKn21e(search)
	if search==cdZKMn68Pzg4: search = BzkmLuvJD9n25Pg()
	if search==cdZKMn68Pzg4: return
	search = search.replace(VBpIH2QSmvDGlA6TO3e,'+')
	url = cDTdfqVAF0BLGiX364IEwaZbr+'/Search?q='+search
	GDQUH4fN02sIt81mAcY(url,'search')
	return
def J1BMh3gS6EbcwT284RdnKzkitfUqW(url):
	if 'smartemadfilter' not in url: url = CxlbPZwGTcH87e1sWhfSIz29uRUEpV(url,'url')
	else: url = url.split('/smartemadfilter?')[0]
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'CIMA4U-GET_FILTERS_BLOCKS-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('MultiFilter(.*?)PageTitle',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
	hQ9ADnZlSxI1m8ui = ffUFBJQ57j2XgoGeOLn9uwpC.findall('Hoverable.*?<span>(.*?)</span>.*?"all".*?(data-tax="(.*?)".*?)</ul>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	return hQ9ADnZlSxI1m8ui
def ycYdX9u6W0oOnbMaDlf4KiPz(KdWauEhgN6OQzjRVm1ro8tkB3):
	items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('data-id="(.*?)".*?</div>(.*?)</a>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	return items
def PVO4RmQY92jycoli0GtrusH(url):
	NLpSEUdj5H081igYnC4TbA2QtoVclF = url.split('/smartemadfilter?')[0]
	YYpjB2CuTidaMgcGrlJOswovm = CxlbPZwGTcH87e1sWhfSIz29uRUEpV(url,'url')
	url = url.replace(NLpSEUdj5H081igYnC4TbA2QtoVclF,YYpjB2CuTidaMgcGrlJOswovm)
	url = url.replace('/smartemadfilter?','/ajaxcenter/action/HomepageLoader/')
	url = url.replace('=',KCQExdbYFqM).replace('&',KCQExdbYFqM)
	url = url+KCQExdbYFqM
	return url
fCAW9dmInLiV = ['category','types','release-year']
w6wuL59PgeE = ['Quality','release-year','types','category']
def XxcpMKIUzr0sVDngR(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==cdZKMn68Pzg4: KFGqxsBnZYLb3NvMU,ejQ8ZCtBaV7 = cdZKMn68Pzg4,cdZKMn68Pzg4
	else: KFGqxsBnZYLb3NvMU,ejQ8ZCtBaV7 = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if '/category/' in url:
			global fCAW9dmInLiV
			fCAW9dmInLiV = fCAW9dmInLiV[1:]
		if fCAW9dmInLiV[0]+'=' not in KFGqxsBnZYLb3NvMU: rrb0SF6otehufCYOX4 = fCAW9dmInLiV[0]
		for WCqkctAYD2O3Hz7Fl8fKRS5 in range(len(fCAW9dmInLiV[0:-1])):
			if fCAW9dmInLiV[WCqkctAYD2O3Hz7Fl8fKRS5]+'=' in KFGqxsBnZYLb3NvMU: rrb0SF6otehufCYOX4 = fCAW9dmInLiV[WCqkctAYD2O3Hz7Fl8fKRS5+1]
		gmjZQuBFv8RzlNtDVEOc = KFGqxsBnZYLb3NvMU+'&'+rrb0SF6otehufCYOX4+'=0'
		qwmxUpZfQj8EAV3Tc = ejQ8ZCtBaV7+'&'+rrb0SF6otehufCYOX4+'=0'
		vMp6jZbo3UkEsSxRFQndyA = gmjZQuBFv8RzlNtDVEOc.strip('&')+'___'+qwmxUpZfQj8EAV3Tc.strip('&')
		YqrzmSVb3R9MgUnX2auEHlpBhZD = XFoM2xPKIt3u51hLj(ejQ8ZCtBaV7,'modified_filters')
		HOCWKhxITtulVGX = url+'/smartemadfilter?'+YqrzmSVb3R9MgUnX2auEHlpBhZD
	elif type=='ALL_ITEMS_FILTER':
		zM2ZBJ4IYN8osGTtwgRheLu6dU = XFoM2xPKIt3u51hLj(KFGqxsBnZYLb3NvMU,'modified_values')
		zM2ZBJ4IYN8osGTtwgRheLu6dU = NLqxoZ37dYf0awrsIE(zM2ZBJ4IYN8osGTtwgRheLu6dU)
		if ejQ8ZCtBaV7!=cdZKMn68Pzg4: ejQ8ZCtBaV7 = XFoM2xPKIt3u51hLj(ejQ8ZCtBaV7,'modified_filters')
		if ejQ8ZCtBaV7==cdZKMn68Pzg4: HOCWKhxITtulVGX = url
		else: HOCWKhxITtulVGX = url+'/smartemadfilter?'+ejQ8ZCtBaV7
		HOCWKhxITtulVGX = PVO4RmQY92jycoli0GtrusH(HOCWKhxITtulVGX)
		zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'أظهار قائمة الفيديو التي تم اختيارها ',HOCWKhxITtulVGX,421,cdZKMn68Pzg4,cdZKMn68Pzg4,'filter')
		zJLApFBcIhnSj('folder',nc3GLkA65oxOd+' [[   '+zM2ZBJ4IYN8osGTtwgRheLu6dU+'   ]]',HOCWKhxITtulVGX,421,cdZKMn68Pzg4,cdZKMn68Pzg4,'filter')
		zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	hQ9ADnZlSxI1m8ui = J1BMh3gS6EbcwT284RdnKzkitfUqW(url)
	dict = {}
	for name,KdWauEhgN6OQzjRVm1ro8tkB3,rfJG62Vo0pTEljwPN1WahD7sx4t3QR in hQ9ADnZlSxI1m8ui:
		if '/category/' in url and rfJG62Vo0pTEljwPN1WahD7sx4t3QR=='category': continue
		name = name.replace('--',cdZKMn68Pzg4)
		items = ycYdX9u6W0oOnbMaDlf4KiPz(KdWauEhgN6OQzjRVm1ro8tkB3)
		if '=' not in HOCWKhxITtulVGX: HOCWKhxITtulVGX = url
		if type=='SPECIFIED_FILTER':
			if rrb0SF6otehufCYOX4!=rfJG62Vo0pTEljwPN1WahD7sx4t3QR: continue
			elif len(items)<2:
				if rfJG62Vo0pTEljwPN1WahD7sx4t3QR==fCAW9dmInLiV[-1]:
					url = PVO4RmQY92jycoli0GtrusH(url)
					GDQUH4fN02sIt81mAcY(url)
				else: XxcpMKIUzr0sVDngR(HOCWKhxITtulVGX,'SPECIFIED_FILTER___'+vMp6jZbo3UkEsSxRFQndyA)
				return
			else:
				HOCWKhxITtulVGX = PVO4RmQY92jycoli0GtrusH(HOCWKhxITtulVGX)
				if rfJG62Vo0pTEljwPN1WahD7sx4t3QR==fCAW9dmInLiV[-1]: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'الجميع',HOCWKhxITtulVGX,421,cdZKMn68Pzg4,cdZKMn68Pzg4,'filter')
				else: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'الجميع',HOCWKhxITtulVGX,425,cdZKMn68Pzg4,cdZKMn68Pzg4,vMp6jZbo3UkEsSxRFQndyA)
		elif type=='ALL_ITEMS_FILTER':
			gmjZQuBFv8RzlNtDVEOc = KFGqxsBnZYLb3NvMU+'&'+rfJG62Vo0pTEljwPN1WahD7sx4t3QR+'=0'
			qwmxUpZfQj8EAV3Tc = ejQ8ZCtBaV7+'&'+rfJG62Vo0pTEljwPN1WahD7sx4t3QR+'=0'
			vMp6jZbo3UkEsSxRFQndyA = gmjZQuBFv8RzlNtDVEOc+'___'+qwmxUpZfQj8EAV3Tc
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'الجميع :'+name,HOCWKhxITtulVGX,424,cdZKMn68Pzg4,cdZKMn68Pzg4,vMp6jZbo3UkEsSxRFQndyA)
		dict[rfJG62Vo0pTEljwPN1WahD7sx4t3QR] = {}
		for value,zj6FI51Rypka0e8xiECfc7g in items:
			if value=='196533': zj6FI51Rypka0e8xiECfc7g = 'أفلام نيتفلكس'
			elif value=='196531': zj6FI51Rypka0e8xiECfc7g = 'مسلسلات نيتفلكس'
			if zj6FI51Rypka0e8xiECfc7g in cJWUPuDGM0Yybv5a9KnIrVzhH78: continue
			dict[rfJG62Vo0pTEljwPN1WahD7sx4t3QR][value] = zj6FI51Rypka0e8xiECfc7g
			gmjZQuBFv8RzlNtDVEOc = KFGqxsBnZYLb3NvMU+'&'+rfJG62Vo0pTEljwPN1WahD7sx4t3QR+'='+zj6FI51Rypka0e8xiECfc7g
			qwmxUpZfQj8EAV3Tc = ejQ8ZCtBaV7+'&'+rfJG62Vo0pTEljwPN1WahD7sx4t3QR+'='+value
			AL8gJZ0NtE91Bexjin4 = gmjZQuBFv8RzlNtDVEOc+'___'+qwmxUpZfQj8EAV3Tc
			title = zj6FI51Rypka0e8xiECfc7g+' :'#+dict[rfJG62Vo0pTEljwPN1WahD7sx4t3QR]['0']
			title = zj6FI51Rypka0e8xiECfc7g+' :'+name
			if type=='ALL_ITEMS_FILTER': zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,url,424,cdZKMn68Pzg4,cdZKMn68Pzg4,AL8gJZ0NtE91Bexjin4)
			elif type=='SPECIFIED_FILTER' and fCAW9dmInLiV[-2]+'=' in KFGqxsBnZYLb3NvMU:
				YqrzmSVb3R9MgUnX2auEHlpBhZD = XFoM2xPKIt3u51hLj(qwmxUpZfQj8EAV3Tc,'modified_filters')
				N8jUpQxY0rhtDAzbG4kOs9X = url+'/smartemadfilter?'+YqrzmSVb3R9MgUnX2auEHlpBhZD
				N8jUpQxY0rhtDAzbG4kOs9X = PVO4RmQY92jycoli0GtrusH(N8jUpQxY0rhtDAzbG4kOs9X)
				zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,N8jUpQxY0rhtDAzbG4kOs9X,421,cdZKMn68Pzg4,cdZKMn68Pzg4,'filter')
			else: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,url,425,cdZKMn68Pzg4,cdZKMn68Pzg4,AL8gJZ0NtE91Bexjin4)
	return
def XFoM2xPKIt3u51hLj(o3JURfrMDgp76,mode):
	o3JURfrMDgp76 = o3JURfrMDgp76.replace('=&','=0&')
	o3JURfrMDgp76 = o3JURfrMDgp76.strip('&')
	bLxfgF7nlO1uZiY9e5T0HDdIw3kpy = {}
	if '=' in o3JURfrMDgp76:
		items = o3JURfrMDgp76.split('&')
		for HYBN2AQsjimSMgT8OvE3ynX67tJwR in items:
			IN0jyfe1PRdDz6YX3CoJkHthw,value = HYBN2AQsjimSMgT8OvE3ynX67tJwR.split('=')
			bLxfgF7nlO1uZiY9e5T0HDdIw3kpy[IN0jyfe1PRdDz6YX3CoJkHthw] = value
	n7VBe6ZgDI14lizTfHOmk = cdZKMn68Pzg4
	for key in w6wuL59PgeE:
		if key in list(bLxfgF7nlO1uZiY9e5T0HDdIw3kpy.keys()): value = bLxfgF7nlO1uZiY9e5T0HDdIw3kpy[key]
		else: value = '0'
		if '%' not in value: value = YQlEOShHM7RLak2t0yA4NXqv(value)
		if mode=='modified_values' and value!='0': n7VBe6ZgDI14lizTfHOmk = n7VBe6ZgDI14lizTfHOmk+' + '+value
		elif mode=='modified_filters' and value!='0': n7VBe6ZgDI14lizTfHOmk = n7VBe6ZgDI14lizTfHOmk+'&'+key+'='+value
		elif mode=='all': n7VBe6ZgDI14lizTfHOmk = n7VBe6ZgDI14lizTfHOmk+'&'+key+'='+value
	n7VBe6ZgDI14lizTfHOmk = n7VBe6ZgDI14lizTfHOmk.strip(' + ')
	n7VBe6ZgDI14lizTfHOmk = n7VBe6ZgDI14lizTfHOmk.strip('&')
	n7VBe6ZgDI14lizTfHOmk = n7VBe6ZgDI14lizTfHOmk.replace('=0','=')
	return n7VBe6ZgDI14lizTfHOmk
# -*- coding: utf-8 -*-
import sys as sjVE6XGymcf09qbiKODZdAC
LVpmDXhWH5wGKy1eqMB = sjVE6XGymcf09qbiKODZdAC.version_info [0] == 2
RGEuTe9PD7o45d2v = 2048
r3HIioGW0Nl = 7
def Brz09AF6apy52OuEq1s (ccr3g6sWvxSOqDiLJuF1Vf2KUtG):
	global YzIBLo1J4ZOCEPtjq
	SSzr8EskcFRLobZqtC2QeTyPg4Y = ord (ccr3g6sWvxSOqDiLJuF1Vf2KUtG [-1])
	JIf7wGht4BqbQ5Xik1mYTA3DeLvaPO = ccr3g6sWvxSOqDiLJuF1Vf2KUtG [:-1]
	ZYd0PzhKWmvFN5TfcQI = SSzr8EskcFRLobZqtC2QeTyPg4Y % len (JIf7wGht4BqbQ5Xik1mYTA3DeLvaPO)
	itRzfVamqWwLIynhGpDM4ZUe = JIf7wGht4BqbQ5Xik1mYTA3DeLvaPO [:ZYd0PzhKWmvFN5TfcQI] + JIf7wGht4BqbQ5Xik1mYTA3DeLvaPO [ZYd0PzhKWmvFN5TfcQI:]
	if LVpmDXhWH5wGKy1eqMB:
		MHSngXbpVZde6NiQc9IrCxt78 = unicode () .join ([unichr (ord (Ep0JIWsLABieR) - RGEuTe9PD7o45d2v - (D2bEPIlOQJy4dYntR3MCiKLusT + SSzr8EskcFRLobZqtC2QeTyPg4Y) % r3HIioGW0Nl) for D2bEPIlOQJy4dYntR3MCiKLusT, Ep0JIWsLABieR in enumerate (itRzfVamqWwLIynhGpDM4ZUe)])
	else:
		MHSngXbpVZde6NiQc9IrCxt78 = str () .join ([chr (ord (Ep0JIWsLABieR) - RGEuTe9PD7o45d2v - (D2bEPIlOQJy4dYntR3MCiKLusT + SSzr8EskcFRLobZqtC2QeTyPg4Y) % r3HIioGW0Nl) for D2bEPIlOQJy4dYntR3MCiKLusT, Ep0JIWsLABieR in enumerate (itRzfVamqWwLIynhGpDM4ZUe)])
	return eval (MHSngXbpVZde6NiQc9IrCxt78)
ObuCsdoDtKmhPLSMH8YGan,vbYokBuWlxeLDcdVNM60,J6jL2d7CKE0WA4lBXFPghR5eoxHb=Brz09AF6apy52OuEq1s,Brz09AF6apy52OuEq1s,Brz09AF6apy52OuEq1s
aNdix5gq7yeFHTMWhnzm8pX0Y16,dwiIAcPl04ey7Zv38Mz,zBGPHsxIiQmd7oTSORl9bAynr5kNq=J6jL2d7CKE0WA4lBXFPghR5eoxHb,vbYokBuWlxeLDcdVNM60,ObuCsdoDtKmhPLSMH8YGan
rbUkdYi32PJaRtnxhDvQs,TtyzcuW45VKA,LungQF89BqemOb32jJsZlW=zBGPHsxIiQmd7oTSORl9bAynr5kNq,dwiIAcPl04ey7Zv38Mz,aNdix5gq7yeFHTMWhnzm8pX0Y16
iRfoNckJs7Ibxzh5j92w8DSWF,NV3enkyQ7Rmp2LYAUagsCJz0ZP,HC9xWUMpBQJEuTteAqjd=LungQF89BqemOb32jJsZlW,TtyzcuW45VKA,rbUkdYi32PJaRtnxhDvQs
s8fcjBCSMxzAIkZQbJPga,AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu,liyzjA4RkEb1cT6fr5pGKdWNHOxM=HC9xWUMpBQJEuTteAqjd,NV3enkyQ7Rmp2LYAUagsCJz0ZP,iRfoNckJs7Ibxzh5j92w8DSWF
nfg30bHwd4aNV12SR7UjFck,Rsdai9xIEPcpuBMKOUwkTA05q,KNomgGw1kdMCBH=liyzjA4RkEb1cT6fr5pGKdWNHOxM,AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu,s8fcjBCSMxzAIkZQbJPga
SGazRxP3yBKZ15ILuch,YnHG75e2QWwo,S5fhsRT8JV=KNomgGw1kdMCBH,Rsdai9xIEPcpuBMKOUwkTA05q,nfg30bHwd4aNV12SR7UjFck
WupgNDhcjK1SiYsF5VLGb9w3loJqX,f8Ja1q5eO02B,xN4fKmsnyM3Y2=S5fhsRT8JV,YnHG75e2QWwo,SGazRxP3yBKZ15ILuch
uxE8MyoTRglrcaiQf,aar0zhDnJsOTP7EdgR16HIS29,opyTNwHgfqbZREWKU=xN4fKmsnyM3Y2,f8Ja1q5eO02B,WupgNDhcjK1SiYsF5VLGb9w3loJqX
On1WZJc6dtksqVNgSQ5GBAjuipe,AiCor1fIVTDxQUWwHe9vPR7,tRnTydV03Xfi7rbQ=opyTNwHgfqbZREWKU,aar0zhDnJsOTP7EdgR16HIS29,uxE8MyoTRglrcaiQf
LJPOQNK1mcG,k5oIaYyp2mnrLK49qhzS,zDek1IW37rq6UoKdwyRiAVpF=tRnTydV03Xfi7rbQ,AiCor1fIVTDxQUWwHe9vPR7,On1WZJc6dtksqVNgSQ5GBAjuipe
from RgJNGc7YMP import *
UkXlAzsMcamKJrEIgnxi6bWh = S5fhsRT8JV(u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔࠩၶ")
def HHN5EpbszV3iA2m89hGSQjaPgUZy(HHrpyfWjGC,JAYWBoz54tGw7O=cdZKMn68Pzg4):
	if   HHrpyfWjGC==opyTNwHgfqbZREWKU(u"࠶፩"): ppGA7Ra6InVC8WJPLYgoDwHUF19hb(JAYWBoz54tGw7O)
	elif HHrpyfWjGC==rbUkdYi32PJaRtnxhDvQs(u"࠱፪"): pass
	elif HHrpyfWjGC==KNomgGw1kdMCBH(u"࠳፫"): CB0jufwiVLMhAodO(JAYWBoz54tGw7O)
	elif HHrpyfWjGC==f8Ja1q5eO02B(u"࠵፬"): aqX2hzYcnWeVjIT9UABk0s()
	elif HHrpyfWjGC==nfg30bHwd4aNV12SR7UjFck(u"࠷፭"): DSvs0xBKOY7wRP4Cz19o35(JAYWBoz54tGw7O)
	elif HHrpyfWjGC==s8fcjBCSMxzAIkZQbJPga(u"࠹፮"): nkHA2xw5pV84e9GMjO()
	elif HHrpyfWjGC==liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"࠻፯"): QaTY0hLgiBKvjSuz5tM()
	elif HHrpyfWjGC==J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"࠽፰"): TrhS6DBuFtfX()
	elif HHrpyfWjGC==S5fhsRT8JV(u"࠸፱"): KE19xWNge5UY7r2BlO0kPn4Qd()
	elif HHrpyfWjGC==SGazRxP3yBKZ15ILuch(u"࠲࠷࠳፲"): dd4o57hHAa9gtRkUmb1()
	elif HHrpyfWjGC==S5fhsRT8JV(u"࠳࠸࠵፳"): TTGituX2MFBgK8rpVJlZQ()
	elif HHrpyfWjGC==TtyzcuW45VKA(u"࠴࠹࠷፴"): Rw01d2JuyE56Uf73gkMKpnVxN8sv()
	elif HHrpyfWjGC==aar0zhDnJsOTP7EdgR16HIS29(u"࠵࠺࠹፵"): HfjQK5N6osxkU1Pr7()
	elif HHrpyfWjGC==J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"࠶࠻࠴፶"): aBGVuMD5P26sZxTNnvjYFA()
	elif HHrpyfWjGC==AiCor1fIVTDxQUWwHe9vPR7(u"࠷࠵࠶፷"): jPsBOcUapi4M9WmKq2J()
	elif HHrpyfWjGC==S5fhsRT8JV(u"࠱࠶࠸፸"): qicPOGE1hlnA2WjMCvYsDR()
	elif HHrpyfWjGC==WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"࠲࠷࠺፹"): cfZTLm6droAauNBjCe8tkE()
	elif HHrpyfWjGC==vbYokBuWlxeLDcdVNM60(u"࠳࠸࠼፺"): XOyuUvch7S()
	elif HHrpyfWjGC==TtyzcuW45VKA(u"࠴࠹࠾፻"): lqnjuhIkEzrOCLa0RdZ8esvXcFKf(IZQbmFzLHDtXfc)
	elif HHrpyfWjGC==AiCor1fIVTDxQUWwHe9vPR7(u"࠵࠼࠶፼"): sstxuy7NoaAwKPmQ6SJGzXZE()
	elif HHrpyfWjGC==ObuCsdoDtKmhPLSMH8YGan(u"࠶࠽࠱፽"): mtITFcNvSXoj()
	elif HHrpyfWjGC==nfg30bHwd4aNV12SR7UjFck(u"࠷࠷࠳፾"): gjNVceSkUyC72BlTpz([JAYWBoz54tGw7O],IZQbmFzLHDtXfc,IZQbmFzLHDtXfc,ksTLSoVGg0ht)
	elif HHrpyfWjGC==zDek1IW37rq6UoKdwyRiAVpF(u"࠱࠸࠵፿"): bMoCAVnTStgik0(ObuCsdoDtKmhPLSMH8YGan(u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡡࡥࡣࡳࡸ࡮ࡼࡥࠨၷ"),IZQbmFzLHDtXfc)
	elif HHrpyfWjGC==uxE8MyoTRglrcaiQf(u"࠲࠹࠷ᎀ"): bMoCAVnTStgik0(dwiIAcPl04ey7Zv38Mz(u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡳࡶࡰࡴࠬၸ"),IZQbmFzLHDtXfc)
	elif HHrpyfWjGC==LJPOQNK1mcG(u"࠳࠺࠹ᎁ"): Toq7NZX2Wnu4VMCUzQw6fytDld9()
	elif HHrpyfWjGC==On1WZJc6dtksqVNgSQ5GBAjuipe(u"࠴࠻࠻ᎂ"): XMOwzsNGlir9KADPqYuCefSvEB3Qx()
	elif HHrpyfWjGC==On1WZJc6dtksqVNgSQ5GBAjuipe(u"࠵࠼࠽ᎃ"): GpWwn7TQh0KIN2zCxE4jt8aPybe(liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠪࡷࡨࡸࡩࡱࡶ࠱ࡱࡴࡪࡵ࡭ࡧ࠱ࡶࡪࡹ࡯࡭ࡸࡨࡹࡷࡲࠧၹ"))
	elif HHrpyfWjGC==s8fcjBCSMxzAIkZQbJPga(u"࠶࠽࠹ᎄ"): GpWwn7TQh0KIN2zCxE4jt8aPybe(zDek1IW37rq6UoKdwyRiAVpF(u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡽࡴࡻࡴࡶࡤࡨࠫၺ"))
	elif HHrpyfWjGC==rbUkdYi32PJaRtnxhDvQs(u"࠷࠹࠱ᎅ"): gfnlUZx9iFVL()
	elif HHrpyfWjGC==SGazRxP3yBKZ15ILuch(u"࠱࠺࠳ᎆ"): AZC2YaMr6U4nEXIVRQ0KF7PdwJt()
	elif HHrpyfWjGC==iRfoNckJs7Ibxzh5j92w8DSWF(u"࠲࠻࠵ᎇ"): EE347mhCvzWFp8()
	elif HHrpyfWjGC==xN4fKmsnyM3Y2(u"࠳࠼࠷ᎈ"): g6iStVY1JjKexqQdayUTcO7XrE()
	elif HHrpyfWjGC==YnHG75e2QWwo(u"࠴࠽࠹ᎉ"): KnSgfAVLEzsOcF61uqo()
	elif HHrpyfWjGC==iRfoNckJs7Ibxzh5j92w8DSWF(u"࠵࠾࠻ᎊ"): x91DtoU6qZLEnN3lwGvab8py()
	elif HHrpyfWjGC==LJPOQNK1mcG(u"࠶࠿࠶ᎋ"): M1dhkqzX92uv7()
	elif HHrpyfWjGC==xN4fKmsnyM3Y2(u"࠷࠹࠸ᎌ"): ETFCM1HDOkwapjNQWA()
	elif HHrpyfWjGC==NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"࠱࠺࠺ᎍ"): EdHhIeG2VNjOWzQ3M()
	elif HHrpyfWjGC==LungQF89BqemOb32jJsZlW(u"࠲࠻࠼ᎎ"): SHyFUij1rMLOTKuZ2()
	elif HHrpyfWjGC==ObuCsdoDtKmhPLSMH8YGan(u"࠵࠷࠴ᎏ"): NaMG2CHgDv4X1OJW9hR3UynKrzIp5F(JAYWBoz54tGw7O)
	elif HHrpyfWjGC==S5fhsRT8JV(u"࠶࠸࠶᎐"): KRoBLbHzmIuPnqw()
	elif HHrpyfWjGC==s8fcjBCSMxzAIkZQbJPga(u"࠷࠹࠸᎑"): csS0zTtJGhKMUja3mDBOC()
	elif HHrpyfWjGC==WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"࠸࠺࠳᎒"): Y1TxI8DokvRzHm6fMV()
	elif HHrpyfWjGC==rbUkdYi32PJaRtnxhDvQs(u"࠹࠴࠶᎓"): ttUVbJRKp2LFgwB4Xj()
	elif HHrpyfWjGC==YnHG75e2QWwo(u"࠳࠵࠸᎔"): F1ogqlnDRAGkb42YX9SVh(ksTLSoVGg0ht)
	elif HHrpyfWjGC==uxE8MyoTRglrcaiQf(u"࠴࠶࠺᎕"): p1mcA6LasBxC7YKGPV0kJRFMfS(IZQbmFzLHDtXfc)
	elif HHrpyfWjGC==SGazRxP3yBKZ15ILuch(u"࠵࠷࠼᎖"): rme3QqWS67iBZv()
	elif HHrpyfWjGC==AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"࠶࠸࠾᎗"): NOgUfGTJty8DjbFWIL5iAzxBZ7E3V(KNomgGw1kdMCBH(u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪၻ"),IZQbmFzLHDtXfc,IZQbmFzLHDtXfc)
	elif HHrpyfWjGC==zDek1IW37rq6UoKdwyRiAVpF(u"࠹࠵࠶᎘"): hSfIs3oZPFtMgaTv9Yn4i()
	elif HHrpyfWjGC==nfg30bHwd4aNV12SR7UjFck(u"࠺࠶࠱᎙"): L6hgjQY87qMnyrbaimkS4Nxz1wp()
	elif HHrpyfWjGC==J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"࠻࠰࠳᎚"): GSWdnriNYbUHlJh1pVFj2moLPq()
	elif HHrpyfWjGC==TtyzcuW45VKA(u"࠵࠱࠵᎛"): XKxZDV2zi6m(S93PERpNHcQlu1gKyAFr)
	elif HHrpyfWjGC==AiCor1fIVTDxQUWwHe9vPR7(u"࠶࠲࠷᎜"): XKxZDV2zi6m(Fav9sQqHIX83Gw6RmcJng70itAruhU)
	elif HHrpyfWjGC==On1WZJc6dtksqVNgSQ5GBAjuipe(u"࠷࠳࠹᎝"): bF4TKpioLcflNX2D6OJ0SjxGqW()
	elif HHrpyfWjGC==aar0zhDnJsOTP7EdgR16HIS29(u"࠸࠴࠻᎞"): tiuZ61v2BRxSKgJWfpbL0Yq(IZQbmFzLHDtXfc)
	elif HHrpyfWjGC==On1WZJc6dtksqVNgSQ5GBAjuipe(u"࠹࠵࠽᎟"): M5PqZFNSo17()
	elif HHrpyfWjGC==LJPOQNK1mcG(u"࠺࠶࠸Ꭰ"): NwEdfayOXkWhs0LzS()
	elif HHrpyfWjGC==rbUkdYi32PJaRtnxhDvQs(u"࠷࠰࠳࠲Ꭱ"): klKNwQGs2aJ7WiU9Ie6qXgpR()
	elif HHrpyfWjGC==vbYokBuWlxeLDcdVNM60(u"࠱࠱࠴࠴Ꭲ"): ssxZIbXkWGMue8()
	elif HHrpyfWjGC==nfg30bHwd4aNV12SR7UjFck(u"࠲࠲࠵࠶Ꭳ"): GpWwn7TQh0KIN2zCxE4jt8aPybe(On1WZJc6dtksqVNgSQ5GBAjuipe(u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫၼ"))
	elif HHrpyfWjGC==zDek1IW37rq6UoKdwyRiAVpF(u"࠳࠳࠶࠸Ꭴ"): UUmSZjdXEiJWlKk1qNaBG9gPfc()
	elif HHrpyfWjGC==iRfoNckJs7Ibxzh5j92w8DSWF(u"࠴࠴࠷࠺Ꭵ"): colKtU7vqP4sF92AX6RbNf83(IZQbmFzLHDtXfc)
	elif HHrpyfWjGC==S5fhsRT8JV(u"࠵࠵࠸࠵Ꭶ"): YQxDlcTFvPNrtZh6bW081RG()
	elif HHrpyfWjGC==dwiIAcPl04ey7Zv38Mz(u"࠶࠶࠲࠷Ꭷ"): PPkK8VuQ0ZUxOcXsYAnqo1wy()
	return
def colKtU7vqP4sF92AX6RbNf83(showDialogs=ksTLSoVGg0ht):
	AgD4RehxOi2E1dY = bu6LzUQF7K.executeJSONRPC(iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡓࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡉࡨࡸࡘ࡫ࡴࡵ࡫ࡱ࡫࡛ࡧ࡬ࡶࡧࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡵࡨࡸࡹ࡯࡮ࡨࠤ࠽ࠦࡱࡵࡣࡢ࡮ࡨ࠲ࡰ࡫ࡹࡣࡱࡤࡶࡩࡲࡡࡺࡱࡸࡸࡸࠨࡽࡾࠩၽ"))
	AgD4RehxOi2E1dY = sJB3aL8gGVrRU.loads(AgD4RehxOi2E1dY)[LungQF89BqemOb32jJsZlW(u"ࠨࡴࡨࡷࡺࡲࡴࠨၾ")][Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠩࡹࡥࡱࡻࡥࠨၿ")]
	choice,lln3DBMy8Y0ic5rVxq = bVX3ev1spE,AgD4RehxOi2E1dY[:]
	if showDialogs:
		owOHWAknpZ9N7BGTQV = YnHG75e2QWwo(u"่ࠪํำษࠡษ็้ๆอส๋ฯࠣห้฿ัษ์ฬࠤ๊็ูๅหࠣ์ฯ฿ๅๅࠩႀ") if f8Ja1q5eO02B(u"ࠫࡆࡸࡡࡣ࡫ࡦࠤࡖ࡝ࡅࡓࡖ࡜ࠫႁ") in AgD4RehxOi2E1dY else LungQF89BqemOb32jJsZlW(u"๊่ࠬฮหࠣห้๋แศฬํัࠥอไฺำห๎ฮࠦๅห๊ๅๅฮ࠭ႂ")
		choice = UN8rA03xkWLCGzebyEoF9YDRKBwSMO(opyTNwHgfqbZREWKU(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ႃ"),dwiIAcPl04ey7Zv38Mz(u"ࠧฯำ๋ะࠬႄ"),liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠨวํๆฬ็ࠧႅ"),aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠩอุ฿๐ไࠨႆ"),OPEJxmUqr9wAX1i,Gzygq01Kcb9U3+owOHWAknpZ9N7BGTQV+kH8E2zqNyims6KJfI+ssELJkeScrtni2+ssELJkeScrtni2+zDek1IW37rq6UoKdwyRiAVpF(u"๋ࠪีํࠠศๆ๋฼๏็ษࠡฬึ้าࠦศศีอาิอๅࠡๆ๋ัฮࠦวๅ็ไหฯ๐อࠡษ็฽ึฮ๊สࠢส่๊๎ฬ้ัฬࠤๆ๐ࠠไ๊า๎ࠥ࠴࠮๊๊ࠡิฬࠦๅฺ่ส๋ࠥอๆหࠢอืฯ฽ฺ๊ࠢฦ๊ࠥะูๆๆࠣฬาัࠠโ์้ࠣํอโฺࠢส่อืๆศ็ฯࠤออำหะาห๊ࠦวๅๆ฽อࠥอไฺำห๎ฮࠦ࠮࠯ࠢฦ์ࠥะำหูํ฽ࠥษๆࠡฬๆฮอࠦัิษ็อ๊ࠥไๆสิ้ัࠦศศๆ็฾ฮࠦวๅ฻ิฬ๏ฯࠠ࠯࠰๋้ࠣࠦสา์าࠤฬ๊ย็ࠢอุ฿๐ไࠡๆ๋ัฮࠦวๅ็ไหฯ๐อࠡษ็฽ึฮ๊สࠢฦ้ࠥห๊ใษไ๋ฬࠦฟࠢࠣࠪႇ"))
	if choice==bVX3ev1spE and xN4fKmsnyM3Y2(u"ࠫࡆࡸࡡࡣ࡫ࡦࠤࡖ࡝ࡅࡓࡖ࡜ࠫႈ") not in AgD4RehxOi2E1dY: lln3DBMy8Y0ic5rVxq = [TtyzcuW45VKA(u"ࠬࡇࡲࡢࡤ࡬ࡧࠥࡗࡗࡆࡔࡗ࡝ࠬႉ")]+AgD4RehxOi2E1dY
	elif choice==hiuZa0PIsErm6UC7 and SGazRxP3yBKZ15ILuch(u"࠭ࡁࡳࡣࡥ࡭ࡨࠦࡑࡘࡇࡕࡘ࡞࠭ႊ") in AgD4RehxOi2E1dY:
		lln3DBMy8Y0ic5rVxq = AgD4RehxOi2E1dY[:]
		lln3DBMy8Y0ic5rVxq.remove(On1WZJc6dtksqVNgSQ5GBAjuipe(u"ࠧࡂࡴࡤࡦ࡮ࡩࠠࡒ࡙ࡈࡖ࡙࡟ࠧႋ"))
	if lln3DBMy8Y0ic5rVxq!=AgD4RehxOi2E1dY:
		lln3DBMy8Y0ic5rVxq = str(lln3DBMy8Y0ic5rVxq).replace(ObuCsdoDtKmhPLSMH8YGan(u"ࠣࠩࠥႌ"),ObuCsdoDtKmhPLSMH8YGan(u"ႍࠩࠥࠫ"))
		xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = bu6LzUQF7K.executeJSONRPC(rbUkdYi32PJaRtnxhDvQs(u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡖࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡘ࡫ࡴࡔࡧࡷࡸ࡮ࡴࡧࡗࡣ࡯ࡹࡪࠨࠬࠣ࡫ࡧࠦ࠿࠷ࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡸ࡫ࡴࡵ࡫ࡱ࡫ࠧࡀࠢ࡭ࡱࡦࡥࡱ࡫࠮࡬ࡧࡼࡦࡴࡧࡲࡥ࡮ࡤࡽࡴࡻࡴࡴࠤ࠯ࠦࡻࡧ࡬ࡶࡧࠥ࠾ࠬႎ")+lln3DBMy8Y0ic5rVxq+k5oIaYyp2mnrLK49qhzS(u"ࠫࢂࢃࠧႏ"))
		if showDialogs:
			if YnHG75e2QWwo(u"ࠬࡺࡲࡶࡧࠪ႐") in str(xsGUcR3ef6glKY5hQwpFXEaSt2mrIz): NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,uxE8MyoTRglrcaiQf(u"࠭สๆฬࠣห้฿ๅๅ์ฬࠤอ์ฬศฯࠪ႑"))
			else: NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,vbYokBuWlxeLDcdVNM60(u"ࠧๅๆฦืๆࠦวๅ฻่่๏ฯࠠโึ็ฮࠬ႒"))
	return
def UUmSZjdXEiJWlKk1qNaBG9gPfc():
	HukTeCrA4V85 = Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.getSetting(WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡧ࡯ࡴࡳࡣࡷࡩࠬ႓"))
	message = J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠩส่ึ่ๅࠡษ็้าีฯࠡฯส่๏อ่๊ࠠࠣ࠾ࠥࠦࠠࠨ႔")+str(HukTeCrA4V85)+On1WZJc6dtksqVNgSQ5GBAjuipe(u"ࠪࠤࡰࡨࡰࡴࠩ႕") if HukTeCrA4V85 else aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠫฬ๊ฬ้ัฬࠤฬ๊ร้ฬ๋้ฬะ๊ไ์ฬࠤ๊ะ่ใใฬࠤาอไ๋ษࠪ႖")
	message = Gzygq01Kcb9U3+message+WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠬࡢ࡮่ๆࠣฮึ๐ฯࠡษ็ฦ๋ࠦสี฼ํ่ࠥษ่ࠡฬ฽๎๏ืࠠาไ่ࠤฬ๊ฬ้ัฬࠤฬ๊ร้ฬ๋้ฬะ๊ไ์ฬࠫ႗")+kH8E2zqNyims6KJfI
	tcxhXCe0Z6EaAyPu = UN8rA03xkWLCGzebyEoF9YDRKBwSMO(nfg30bHwd4aNV12SR7UjFck(u"࠭ࡣࡦࡰࡷࡩࡷ࠭႘"),liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠧฯำ๋ะࠬ႙"),KNomgGw1kdMCBH(u"ࠨวํๆฬ็ࠧႚ"),AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"ࠩอุ฿๐ไࠨႛ"),OPEJxmUqr9wAX1i,message+SGazRxP3yBKZ15ILuch(u"ࠪࡠࡳࡢ࡮ศๆฯ์ิฯࠠศๆฦ์ฯ๎ๅศฬํ็๏ฯ่ࠠ์ࠣ฽๊๊๊สࠢํๆํ๋ࠠษ้สࠤฬ๊ศา่ส้ัࠦศศะอ๎ฬืࠠฤ฻็ํࠥา่ะห้ࠣฯ๎แาห่ࠣึ่ๅࠡษ็ะํีษࠡษ็ิ๏ࠦว็ฬࠣฮาีฯ่ࠢไ๎ࠥํะ่ࠢสู่อิสࠢ࠱࠲ࠥ๎็ัษ้ࠣ฾์ว่ࠢ฼๊ิ๋วࠡฬๅ์๊ࠦว็ฬࠣฬฯฺฺ๋ๆࠣๅ๏ี๊้ࠢไห๋ࠦวๅสิ๊ฬ๋ฬࠡๆ้ࠤ๏ูรๅๅࠣ฽๋ࠦวๅฮ๋ำฮࠦวๅฬํࠤฯื๊ะ้สࠤ้ษๆࠡษ็ฬึ์วๆฮࠣืํ็๋ࠠะอหึࠦวๅฮ๋ำฮࠦร้ฬ๋้ฬะ๊ไ์สࠤ࠳࠴ฺࠠๆ่หࠥอๆ่ࠢํะอࠦวฯฬํหึࠦัใ็ࠣะํีษࠡื฽๎ึࠦลัษࠣ็ฬ์สࠡษ็ษ๋ะั็ฬࠣ฽๋ีใࠡสฺ๎หฯࠠฤ๊ࠣๆ้๐ไสࠩႜ"))
	if tcxhXCe0Z6EaAyPu in [-Rsdai9xIEPcpuBMKOUwkTA05q(u"࠷Ꭸ"),NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"࠰Ꭹ")]: return
	if tcxhXCe0Z6EaAyPu==nfg30bHwd4aNV12SR7UjFck(u"࠲Ꭺ"):
		HukTeCrA4V85 = cdZKMn68Pzg4
		NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,uxE8MyoTRglrcaiQf(u"๋ࠫาอหࠢ฼้้๐ษࠡวํๆฬ็ࠠศๆฯ์ิฯࠠศๆฦ์ฯ๎ๅศฬํ็๏ฯࠧႝ"))
	else:
		items = [LungQF89BqemOb32jJsZlW(u"ࠬ࠸࠵࠱ࠢ࡮ࡦࡵࡹࠧ႞"),S5fhsRT8JV(u"࠭࠵࠱࠲ࠣ࡯ࡧࡶࡳࠨ႟"),HC9xWUMpBQJEuTteAqjd(u"ࠧ࠸࠷࠳ࠤࡰࡨࡰࡴࠩႠ"),tRnTydV03Xfi7rbQ(u"ࠨ࠳࠳࠴࠵ࠦ࡫ࡣࡲࡶࠫႡ"),dwiIAcPl04ey7Zv38Mz(u"ࠩ࠴࠶࠺࠶ࠠ࡬ࡤࡳࡷࠬႢ"),vbYokBuWlxeLDcdVNM60(u"ࠪ࠵࠺࠶࠰ࠡ࡭ࡥࡴࡸ࠭Ⴃ"),WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠫ࠶࠽࠵࠱ࠢ࡮ࡦࡵࡹࠧႤ"),xN4fKmsnyM3Y2(u"ࠬ࠸࠰࠱࠲ࠣ࡯ࡧࡶࡳࠨႥ"),ObuCsdoDtKmhPLSMH8YGan(u"࠭࠲࠶࠲࠳ࠤࡰࡨࡰࡴࠩႦ"),TtyzcuW45VKA(u"ࠧ࠴࠲࠳࠴ࠥࡱࡢࡱࡵࠪႧ"),LungQF89BqemOb32jJsZlW(u"ࠨ࠵࠸࠴࠵ࠦ࡫ࡣࡲࡶࠫႨ"),iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠩ࠷࠴࠵࠶ࠠ࡬ࡤࡳࡷࠬႩ"),opyTNwHgfqbZREWKU(u"ࠪ࠸࠺࠶࠰ࠡ࡭ࡥࡴࡸ࠭Ⴊ"),zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"ࠫ࠺࠶࠰࠱ࠢ࡮ࡦࡵࡹࠧႫ"),LungQF89BqemOb32jJsZlW(u"ࠬ࠼࠰࠱࠲ࠣ࡯ࡧࡶࡳࠨႬ"),aNdix5gq7yeFHTMWhnzm8pX0Y16(u"࠭࠷࠱࠲࠳ࠤࡰࡨࡰࡴࠩႭ"),On1WZJc6dtksqVNgSQ5GBAjuipe(u"ࠧ࠹࠲࠳࠴ࠥࡱࡢࡱࡵࠪႮ"),WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠨ࠻࠳࠴࠵ࠦ࡫ࡣࡲࡶࠫႯ"),ObuCsdoDtKmhPLSMH8YGan(u"ࠩ࠴࠴࠵࠶࠰ࠡ࡭ࡥࡴࡸ࠭Ⴐ"),iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠪ࠵࠶࠶࠰࠱ࠢ࡮ࡦࡵࡹࠧႱ"),k5oIaYyp2mnrLK49qhzS(u"ࠫ࠶࠸࠰࠱࠲ࠣ࡯ࡧࡶࡳࠨႲ"),YnHG75e2QWwo(u"ࠬ࠿࠹࠺࠻࠼ࠤࡰࡨࡰࡴࠩႳ")]
		AS6jLpMwW5Ql3kUFNfT = NAfHLMC8Ip64FmT7l5oJWXaq3hK(AiCor1fIVTDxQUWwHe9vPR7(u"࠭วฯฬิࠤฬ๊ฬ้ัฬࠤฬ๊ร้ฬ๋้ฬะ๊ไ์ฬࠤฬ๊ๅ็ษึฬฮ࠭Ⴔ"),items)
		if AS6jLpMwW5Ql3kUFNfT==-aar0zhDnJsOTP7EdgR16HIS29(u"࠳Ꭻ"): return
		HukTeCrA4V85 = str(items[AS6jLpMwW5Ql3kUFNfT][:-iRfoNckJs7Ibxzh5j92w8DSWF(u"࠸Ꭼ")])
		NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,YnHG75e2QWwo(u"ࠧ็ฮะฮࠥ฿ๅๅ์ฬࠤฯฺฺ๋ๆࠣ์ฯำฯ๋ัࠣี็๋ࠠศๆฯ์ิฯࠠศๆฦ์ฯ๎ๅศฬํ็๏ฯ࡜࡯࡞ࡱࠫႵ")+Gzygq01Kcb9U3+HukTeCrA4V85+aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠨࠢ࡮ࡦࡵࡹࠧႶ")+kH8E2zqNyims6KJfI)
	Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.setSetting(aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡨࡩࡵࡴࡤࡸࡪ࠭Ⴗ"),HukTeCrA4V85)
	return
def ssxZIbXkWGMue8(hhKD7GBPLWAlXvoeH2xRU0nFQ=ksTLSoVGg0ht):
	F5JqLX7coT8MA9fQkCOxvBtgWIS = MexD9yTpd8UugjOcIkz()
	owOHWAknpZ9N7BGTQV = On1WZJc6dtksqVNgSQ5GBAjuipe(u"ࠪห้ะิ฻์็ࠤฬ๊ไศฯๅࠤ๏฿ๅๅࠩႸ") if F5JqLX7coT8MA9fQkCOxvBtgWIS else dwiIAcPl04ey7Zv38Mz(u"ࠫฬ๊สี฼ํ่ࠥอไๅษะๆ๋ࠥส้ไไࠫႹ")
	tcxhXCe0Z6EaAyPu = UN8rA03xkWLCGzebyEoF9YDRKBwSMO(rbUkdYi32PJaRtnxhDvQs(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬႺ"),vbYokBuWlxeLDcdVNM60(u"࠭ฮา๊ฯࠫႻ"),dwiIAcPl04ey7Zv38Mz(u"ࠧฦ์ๅหๆ࠭Ⴜ"),iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠨฬื฾๏๊ࠧႽ"),OPEJxmUqr9wAX1i,Gzygq01Kcb9U3+owOHWAknpZ9N7BGTQV+kH8E2zqNyims6KJfI+ssELJkeScrtni2+aar0zhDnJsOTP7EdgR16HIS29(u"๊ࠩิ์ࠦวๅ๊฻๎ๆฯࠠหฮ฼่้่ࠥะ์ࠣวํะ่ๆษอ๎่๐วࠡ์ๅ์๊ࠦศหึ฽๎้ࠦวๅใํำ๏๎ࠠศๆ็หา่ࠠ࠯࠰ࠣษ๊อࠠษ฻าࠤฬ์ส่ษฤࠤฬ๊แ๋ัํ์ࠥอไฮษ็๎ࠥฮรไ็็๋ࠥ࠴࠮ࠡล๋ࠤอ฿ฯࠡษ็๊็ืฺࠠๆ์ࠤืืࠠࠣฬฯหํุࠠฦๆ์ࠤฬ๊ไศฯๅࠦࠥ࠴࠮๊ࠡฦ๎฻อࠠๆ็ๆ๊ࠥหไ฻ษฤࠤฬ๊สี฼ํ่ࠥอไๅษะๆࠥฮวๅ่ๅีࠥ฿ไ๊ࠢีีࠥࠨล๋ไสๅࠥอไโ์า๎ํࠨࠠ࠯࠰ࠣ์ศ๐ึศ่้่ࠢ์ࠠศๆสืฯ็วะห้๋ࠣࠦส฻์ํีࠥะัห์หࠤ๊ำส้์สฮࠥอไใ๊สส๊ࠦ࠮࠯๋ࠢาฬ฻ษࠡฬิฮ๏ฮࠠฮๆๅหฯࠦวๅ็ึุ่๊วหࠢ࠱࠲ࠥํไࠡฬิ๎ิࠦวๅฤ้ࠤฯฺฺ๋ๆ๋ࠣีํࠠศๆ๋฼๏็ษࠡล่ࠤส๐โศใ๊หࠥลࠡࠢࠩႾ"))
	if tcxhXCe0Z6EaAyPu==hiuZa0PIsErm6UC7: df6QHU3Ej8hx17RwJZ5aIz = bu6LzUQF7K.executeJSONRPC(iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡖࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡘ࡫ࡴࡔࡧࡷࡸ࡮ࡴࡧࡗࡣ࡯ࡹࡪࠨࠬࠣ࡫ࡧࠦ࠿࠷ࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡸ࡫ࡴࡵ࡫ࡱ࡫ࠧࡀࠢࡷ࡫ࡧࡩࡴࡶ࡬ࡢࡻࡨࡶ࠳ࡧࡵࡵࡱࡳࡰࡦࡿ࡮ࡦࡺࡷ࡭ࡹ࡫࡭ࠣ࠮ࠥࡺࡦࡲࡵࡦࠤ࠽࡟ࡢࢃࡽࠨႿ"))
	elif tcxhXCe0Z6EaAyPu==bVX3ev1spE: df6QHU3Ej8hx17RwJZ5aIz = bu6LzUQF7K.executeJSONRPC(AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡗࡪࡺࡴࡪࡰࡪࡷ࠳࡙ࡥࡵࡕࡨࡸࡹ࡯࡮ࡨࡘࡤࡰࡺ࡫ࠢ࠭ࠤ࡬ࡨࠧࡀ࠱࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡹࡥࡵࡶ࡬ࡲ࡬ࠨ࠺ࠣࡸ࡬ࡨࡪࡵࡰ࡭ࡣࡼࡩࡷ࠴ࡡࡶࡶࡲࡴࡱࡧࡹ࡯ࡧࡻࡸ࡮ࡺࡥ࡮ࠤ࠯ࠦࡻࡧ࡬ࡶࡧࠥ࠾ࡠ࠷࡝ࡾࡿࠪჀ"))
	if tcxhXCe0Z6EaAyPu in [hiuZa0PIsErm6UC7,bVX3ev1spE]:
		if LJPOQNK1mcG(u"ࠬࡺࡲࡶࡧࠪჁ") in str(df6QHU3Ej8hx17RwJZ5aIz): NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,k5oIaYyp2mnrLK49qhzS(u"࠭สๆฬࠣห้฿ๅๅ์ฬࠤอ์ฬศฯࠪჂ"))
		else: NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠧๅๆฦืๆࠦวๅ฻่่๏ฯࠠโึ็ฮࠬჃ"))
	return
def klKNwQGs2aJ7WiU9Ie6qXgpR():
	url = USuRxnPlV5.SITESURLS[Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠨࡔࡈࡐࡊࡇࡓࡆࡕࠪჄ")][J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"࠴Ꭽ")]
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(fS25N8gAZxpbnLi3srX7PJ,YnHG75e2QWwo(u"ࠩࡊࡉ࡙࠭Ⴥ"),url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,SGazRxP3yBKZ15ILuch(u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗ࠲ࡏࡎࡔࡖࡄࡐࡑࡥࡏࡍࡆࡢࡖࡊࡒࡅࡂࡕࡈ࠱࠶ࡹࡴࠨ჆"))
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	O0ekN3yvUMwVlcqo17SsGut = ffUFBJQ57j2XgoGeOLn9uwpC.findall(On1WZJc6dtksqVNgSQ5GBAjuipe(u"ࠫ࡭ࡸࡥࡧ࠿ࠥࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࠫࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴ࠰࠭ࡃ࠮࠴ࡺࡪࡲࠥࠫჇ"),OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	O0ekN3yvUMwVlcqo17SsGut = sorted(O0ekN3yvUMwVlcqo17SsGut,reverse=IZQbmFzLHDtXfc)
	AS6jLpMwW5Ql3kUFNfT = NAfHLMC8Ip64FmT7l5oJWXaq3hK(xN4fKmsnyM3Y2(u"ࠬอฮหำࠣห้หีะษิࠤฬ๊ะ๋ࠢอี๏ีࠠหอห๎ฯํࠧ჈"),O0ekN3yvUMwVlcqo17SsGut)
	if AS6jLpMwW5Ql3kUFNfT>=vbYokBuWlxeLDcdVNM60(u"࠵Ꭾ"):
		v5D7lPj4xAiqsEaXOzQR = url.rsplit(KCQExdbYFqM,AiCor1fIVTDxQUWwHe9vPR7(u"࠷Ꭿ"))[opyTNwHgfqbZREWKU(u"࠰Ꮀ")]+liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"࠭࠯ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࠧ჉")+O0ekN3yvUMwVlcqo17SsGut[AS6jLpMwW5Ql3kUFNfT]+KNomgGw1kdMCBH(u"ࠧ࠯ࡼ࡬ࡴࠬ჊")
		succeeded = GUM97x06XtLYhr(NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭჋"),v5D7lPj4xAiqsEaXOzQR,IZQbmFzLHDtXfc)
		if succeeded:
			Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.setSetting(iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠩࡤࡺ࠳ࡼࡥࡳࡵ࡬ࡳࡳ࠭჌"),cdZKMn68Pzg4)
			BoyIUWYSNR0jhDxQwvJriO4PkL = JyLdvftP3CU(cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,uxE8MyoTRglrcaiQf(u"ࠪฮ๊ࠦสฬสํฮࠥหีะษิࠤ็ี๊ๆࠢ็่อืๆศ็ฯࠤ࠳࠴ࠠๅๅ้ࠤอืๆศ็ฯࠤ่๎ฯ๋ࠢํๆํ๋ࠠฤ๊อ์๊อส๋ๅํหࠥฮสฮัํฯࠥาๅ๋฻ࠣห้ฮัศ็ฯࠤออำหะาห๊ࠦยฯำࠣษฺีวา่ࠢฮํ็ัࠡ࠰࠱ࠤ์๊ࠠหำํำࠥอไร่ࠣษ๏่วโࠢส่ฯำฯ๋อࠣห้ษ่ห๊่หฯ๐ใ๋ࠢ็๋ีอࠠศๆหี๋อๅอࠢยࠥࠦ࠭Ⴭ"))
			if BoyIUWYSNR0jhDxQwvJriO4PkL: NOgUfGTJty8DjbFWIL5iAzxBZ7E3V(S5fhsRT8JV(u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩ჎"),IZQbmFzLHDtXfc,IZQbmFzLHDtXfc)
	return
def M5PqZFNSo17():
	BoyIUWYSNR0jhDxQwvJriO4PkL = JyLdvftP3CU(cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,YnHG75e2QWwo(u"ࠬํไࠡฬิ๎ิࠦแฺๆสࠤู๊อࠡว฼ำฬีวหࠢส่อืๆศ็ฯࠤฬ๊ฮศืฬࠤอ๎โหࠢฯ่อࠦวๅฬะำ๏ัวหࠢ࠱࠲ࠥํะศࠢสู่๊อࠡี๋ๅࠥ๐ำษสࠣฮาี๊ฬࠢไ์ึ๐ࠠๅฮ่๎฾ู่ࠦษษๅࠥอไษำ้ห๊าࠠศๆอ๎ࠥะูห็าࠤ฾๊้ࠡ็ิ์ึ่ࠦใฬ้ࠣ฾๐ๆࠨ჏"))
	if BoyIUWYSNR0jhDxQwvJriO4PkL:
		Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.setSetting(aar0zhDnJsOTP7EdgR16HIS29(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡹࡨࡰࡴࡷࠫა"),cdZKMn68Pzg4)
		Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.setSetting(AiCor1fIVTDxQUWwHe9vPR7(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴ࡲࡦࡩࡸࡰࡦࡸࠧბ"),cdZKMn68Pzg4)
		Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.setSetting(liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮࡭ࡱࡱ࡫ࠬგ"),cdZKMn68Pzg4)
		Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.setSetting(iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯࡯ࡨࡷࡸࡧࡧࡦࡵࠪდ"),cdZKMn68Pzg4)
		Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.setSetting(rbUkdYi32PJaRtnxhDvQs(u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰ࡴࡹࡪࡹࡴࡪࡱࡱࡷࠬე"),cdZKMn68Pzg4)
		NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠫฯ๋ࠠๆีะࠤส฿ฯศัสฮࠥอไษำ้ห๊าࠠศๆัหฺฯࠠษ๊ๅฮࠥาไษࠢส่ฯำฯ๋อสฮࠥ࠴࠮๊ࠡึ์ๆ๊ࠦใ๊่ࠤฬ๊ศา่ส้ัࠦวๅฤ้ࠤอะอะ์ฮࠤ์ึ็ࠡษ็ษ฾ีวะษอࠤ࠳࠴้ࠠลํฺฬࠦสฮัํฯࠥ๎ุศศไࠤฬ๊ศา่ส้ัࠦวๅฬํࠤฯ฿สๆัࠣ฽้๏ࠠศๆ๋ๆฯ࠭ვ"))
		XfABsbKWoLhI(ksTLSoVGg0ht)
	return
def bF4TKpioLcflNX2D6OJ0SjxGqW():
	uVOoSHfqe4WtiF(TV08xYHA2ok,nfg30bHwd4aNV12SR7UjFck(u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࡠ࠳ࠪზ"),HC9xWUMpBQJEuTteAqjd(u"࠭ࡑࡖࡇࡖࡘࡎࡕࡎࡔࠩთ"))
	jjo29gbhfq = IcFg58SuXynv3JHfBDQ2aOMNmZbCUw(ksTLSoVGg0ht)
	dQacFKpXtfAP4er2UzoGignwq6OS = ssELJkeScrtni2
	f1elTQGxpdqrziwcR7J6tLujMmK0B = bxf7gZvNK29cEoiAIJlMq0dP+dwiIAcPl04ey7Zv38Mz(u"ࠧࠡ࠯࠰࠱࠲࠳ࠠ࠮࠯࠰࠱࠲ࠦ࠭࠮࠯࠰࠱ࠥ࠳࠭࠮࠯࠰ࠤ࠲࠳࠭࠮࠯ࠣࠫი")+kH8E2zqNyims6KJfI
	BspvbNl82JjRGUPwDfCO1yQYnA = ssELJkeScrtni2+Gzygq01Kcb9U3+AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"ࠨࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࠬკ")+kH8E2zqNyims6KJfI+rbUkdYi32PJaRtnxhDvQs(u"ࠩ࡟ࡲࡡࡴࠧლ")
	for id,l5Q1RUnycofqBeJCTYLpD9iV7aghwb,rcgP6YoLtT8lyuMa,TGKDixtNnaczZBfmLVpb,CCGh0EWMzyRr4,reason in reversed(jjo29gbhfq):
		if id==iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠪ࠴ࠬმ"):
			Nx4zjvUXEm9Z0ftCnwrQAdsyM,HUmozgRf0lOKMiIPBv8GX36CZ = TGKDixtNnaczZBfmLVpb.split(opyTNwHgfqbZREWKU(u"ࠫࡡࡴ࠻࠼ࠩნ"))
			continue
		if dQacFKpXtfAP4er2UzoGignwq6OS!=ssELJkeScrtni2: dQacFKpXtfAP4er2UzoGignwq6OS += BspvbNl82JjRGUPwDfCO1yQYnA
		rejRY592MzwLXCqP6kNISHByim = TtyzcuW45VKA(u"ࠬࡡࡒࡕࡎࡠࠫო")+bxf7gZvNK29cEoiAIJlMq0dP+id+vbYokBuWlxeLDcdVNM60(u"࠭ࠠ࠻ࠢࠪპ")+LJPOQNK1mcG(u"ࠧศๆึศฬ๊ࠠ࠻ࠢࠪჟ")+kH8E2zqNyims6KJfI+rcgP6YoLtT8lyuMa
		li3O6w58Lr1AhRbzvXjeDU7MdH = liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠨ࡞ࡱ࡟ࡗ࡚ࡌ࡞ࠩრ")+bxf7gZvNK29cEoiAIJlMq0dP+S5fhsRT8JV(u"ࠩส่ั๎วษࠢ࠽ࠤࠬს")+kH8E2zqNyims6KJfI+TGKDixtNnaczZBfmLVpb
		a3tzxkPUoO = LJPOQNK1mcG(u"ࠪ࡟ࡗ࡚ࡌ࡞ࠩტ")+bxf7gZvNK29cEoiAIJlMq0dP+SGazRxP3yBKZ15ILuch(u"ࠫฬ๊ฮุลࠣ࠾ࠥ࠭უ")+kH8E2zqNyims6KJfI+CCGh0EWMzyRr4
		gvzWimTak9Se5B6A3UF = zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"ࠬࡢ࡮࡜ࡔࡗࡐࡢ࠭ფ")+bxf7gZvNK29cEoiAIJlMq0dP+AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"࠭วๅีหฬࠥࡀࠠࠨქ")+kH8E2zqNyims6KJfI+reason
		dQacFKpXtfAP4er2UzoGignwq6OS += rejRY592MzwLXCqP6kNISHByim+li3O6w58Lr1AhRbzvXjeDU7MdH+ssELJkeScrtni2+f1elTQGxpdqrziwcR7J6tLujMmK0B+ssELJkeScrtni2+a3tzxkPUoO+gvzWimTak9Se5B6A3UF+ssELJkeScrtni2
	E3WHU2OdFfmX459c(rbUkdYi32PJaRtnxhDvQs(u"ࠧࡳ࡫ࡪ࡬ࡹ࠭ღ"),HUmozgRf0lOKMiIPBv8GX36CZ,dQacFKpXtfAP4er2UzoGignwq6OS,uxE8MyoTRglrcaiQf(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࡣࡱࡵ࡮ࡨࠩყ"))
	return
def XKxZDV2zi6m(file):
	if file==Fav9sQqHIX83Gw6RmcJng70itAruhU: OKcLR2ljCng6qW3Tkwb = LJPOQNK1mcG(u"ࠩๅ์ฬฬๅࠡษ็้ๆ฼ไสࠩშ")
	elif file==S93PERpNHcQlu1gKyAFr: OKcLR2ljCng6qW3Tkwb = opyTNwHgfqbZREWKU(u"ࠪๆํอฦๆࠢลาึࠦวๅใํำ๏๎็ศฬࠪჩ")
	tcxhXCe0Z6EaAyPu = UN8rA03xkWLCGzebyEoF9YDRKBwSMO(zDek1IW37rq6UoKdwyRiAVpF(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫც"),HC9xWUMpBQJEuTteAqjd(u"๋ࠬำฮࠩძ"),k5oIaYyp2mnrLK49qhzS(u"࠭ลึๆสัࠬწ"),aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠧฯำ๋ะࠬჭ"),OPEJxmUqr9wAX1i,tRnTydV03Xfi7rbQ(u"ࠨ้็ࠤฯื๊ะࠢศู้ออࠡ็็ๅࠥ࠭ხ")+OKcLR2ljCng6qW3Tkwb+ObuCsdoDtKmhPLSMH8YGan(u"ࠩࠣว๊ࠦสา์าࠤู๊อࠡษ็้้็ࠠภࠩჯ"))
	if tcxhXCe0Z6EaAyPu==TtyzcuW45VKA(u"࠱Ꮁ"):
		if YRESXadfbIy3khwqmL8WC.path.exists(file):
			try: YRESXadfbIy3khwqmL8WC.remove(file)
			except: pass
		NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠪฮ๊ࠦๅิฯ้้ࠣ็ࠠࠨჰ")+OKcLR2ljCng6qW3Tkwb)
	elif tcxhXCe0Z6EaAyPu==LungQF89BqemOb32jJsZlW(u"࠳Ꮂ"):
		data = DUwpLP7sOJ8dj9HFTrnE4Y3y(file)
		NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,TtyzcuW45VKA(u"ࠫฯ๋ࠠฦื็หาࠦๅๅใࠣࠫჱ")+OKcLR2ljCng6qW3Tkwb)
	return
def L6hgjQY87qMnyrbaimkS4Nxz1wp():
	if m4PjYkEqLcJh<dwiIAcPl04ey7Zv38Mz(u"࠴࠼Ꮃ"):
		KZ4oqDz5xgA2tkGcTaeQ1Lh3dp = LungQF89BqemOb32jJsZlW(u"๊ࠬไฤีไࠤศ์สࠡฬึฮำีๅࠡวุำฬืࠠไ๊า๎่ࠥฯ๋็ࠣี็๋ࠠࠨჲ")+str(m4PjYkEqLcJh)+WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"้࠭ࠠๆ๊ิฬࠦวๅไ๋หห๋ࠠศๆู่ํืษࠡๆสࠤฯ฿ๅๅࠢ฼๊ิ้ࠠ࠯๊ࠢิ์ࠦวๅ็ํึฮࠦสๆๅ้็๋ࠥๆࠡำว๎ฮࠦโ้ษษ้ࠥอไโ์า๎ํํวหࠢไ๎ࠥฮั็ษ่ะࠥ฿ๅศัࠣฬู้ไࠡื๋ีࠥฮฯๅษ้๋ࠣࠦวๅๅอหอฯࠠ࠯ࠢ็ษฺ๊วฮࠢสฺ่๊ใๅหࠣๆ๊ࠦศหฯา๎ะࠦศา่ส้ัࠦใ้ัํࠤส๊้ࠡวํࠤส฻ฯศำࠣี็๋็ࠡล฼่๎ࠦๅ็ࠢ࠴࠼࠳࠶ࠧჳ")
		NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,KZ4oqDz5xgA2tkGcTaeQ1Lh3dp)
		return
	cEdehCpqROmNkiKTt2Hu5XQ3 = bu6LzUQF7K.executeJSONRPC(aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡓࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡉࡨࡸࡘ࡫ࡴࡵ࡫ࡱ࡫࡛ࡧ࡬ࡶࡧࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡵࡨࡸࡹ࡯࡮ࡨࠤ࠽ࠦࡱࡵ࡯࡬ࡣࡱࡨ࡫࡫ࡥ࡭࠰ࡶ࡯࡮ࡴࠢࡾࡿࠪჴ"))
	Hgd2k9RXymZVqcw = sMmGpryoLIThV1KYO3xA05v9dgFXD([KNomgGw1kdMCBH(u"ࠨࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊࠧჵ")])
	V3wKRrD0PWvS,jtLvRf5p23JhEmB06O,KQfoMW7Tvr4t,nz9bYi0M48,SwavZuBiyUMTGpXRfgdKA4W,ZwMIH7adBAV3Pef,h4XNDCH7BJyjsmbqKzrSpdAL5V = Hgd2k9RXymZVqcw[zDek1IW37rq6UoKdwyRiAVpF(u"ࠩࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄࠨჶ")]
	if V3wKRrD0PWvS or On1WZJc6dtksqVNgSQ5GBAjuipe(u"ࠪࡷࡰ࡯࡮࠯࡯ࡨࡸࡷࡵࡰࡰ࡮࡬ࡷࡊࡓࡁࡅࠩჷ") not in str(cEdehCpqROmNkiKTt2Hu5XQ3):
		NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,uxE8MyoTRglrcaiQf(u"ࠫฬ๊โ้ษษ้ࠥอไๆื๋ีฮࠦสฺ็็ࠤๆ่ืࠡ็฼ࠤั๊ฯࠡ็อีํฮ่ๅีࠣ฽๊อฯࠡ࠰๋ࠣีํࠠศๆๅ์ฬฬๅࠡฬ่็๋้ࠠๆ่ࠣีษ๐ษࠡไ๋หห๋ࠠษำ้ห๊าฺࠠ็สำࠥฮิไๆูࠣํืࠠษั็ห๋ࠥๆࠡษ็็ฯอศสࠩჸ"))
		Q0AOX4cEgius9e = GSWdnriNYbUHlJh1pVFj2moLPq()
		if not Q0AOX4cEgius9e: return
	RLYeEFlpfyvtMa652IBi1703JuU(IZQbmFzLHDtXfc)
	return
def RLYeEFlpfyvtMa652IBi1703JuU(showDialogs=IZQbmFzLHDtXfc):
	cEdehCpqROmNkiKTt2Hu5XQ3 = bu6LzUQF7K.executeJSONRPC(zDek1IW37rq6UoKdwyRiAVpF(u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡇࡦࡶࡖࡩࡹࡺࡩ࡯ࡩ࡙ࡥࡱࡻࡥࠣ࠮ࠥ࡭ࡩࠨ࠺࠲࠮ࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡳࡦࡶࡷ࡭ࡳ࡭ࠢ࠻ࠤ࡯ࡳࡴࡱࡡ࡯ࡦࡩࡩࡪࡲ࠮ࡴ࡭࡬ࡲࠧࢃࡽࠨჹ"))
	if k5oIaYyp2mnrLK49qhzS(u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈࠬჺ") not in str(cEdehCpqROmNkiKTt2Hu5XQ3):
		if showDialogs:
			NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"ࠧๅๆฦืๆࠦฬ่ษี็๊ࠥวࠡ์ึฮำีๅࠡฮ็ำ๋ࠥสา๊ห์ฺู้ࠠ็สำࠥ࠴ࠠศๆๅ์ฬฬๅࠡษ็ฺ้๎ัสࠢอ฽๊๊ࠠโไฺࠤ๊฿ࠠอๆาࠤ๊ะั้สุู๋่ࠦๆษาࠤ࠳ࠦ็ั้ࠣห้่่ศศ่ࠤฯ๋ใ็ๅ้๋ࠣࠦัล์ฬࠤ็๎วว็ࠣฬึ์วๆฮࠣ฽๊อฯࠡสื็้ࠦี้ำࠣฬิ๊วࠡ็้ࠤฬ๊ใหษหอࠬ჻"))
		return
	jwh6o5O2AME = YRESXadfbIy3khwqmL8WC.path.join(vloHbRquyEe23snXIT9Y4SU6,dwiIAcPl04ey7Zv38Mz(u"ࠨࡣࡧࡨࡴࡴࡳࠨჼ"),LJPOQNK1mcG(u"ࠩࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄࠨჽ"),HC9xWUMpBQJEuTteAqjd(u"ࠪ࠻࠷࠶ࡰࠨჾ"),dwiIAcPl04ey7Zv38Mz(u"ࠫࡒࡿࡖࡪࡦࡨࡳࡓࡧࡶ࠯ࡺࡰࡰࠬჿ"))
	if not YRESXadfbIy3khwqmL8WC.path.exists(jwh6o5O2AME): return
	YLv6zoPid2Tj = open(jwh6o5O2AME,vbYokBuWlxeLDcdVNM60(u"ࠬࡸࡢࠨᄀ")).read()
	if W5domCu6XrQUFkiPpa3bNLtHglG: YLv6zoPid2Tj = YLv6zoPid2Tj.decode(vczMIlkCAh2u10B3)
	bFXN1DeZjuVLGYxnB9JlwQ625hH = ffUFBJQ57j2XgoGeOLn9uwpC.findall(nfg30bHwd4aNV12SR7UjFck(u"࠭࠼ࡷ࡫ࡨࡻࡸࡄࠨ࡝ࡦ࠮࠰ࡡࡪࠫ࠭࡞ࡧ࠯࠮࠲ࠨ࠯ࠬࡂ࠭ࡁ࠵ࡶࡪࡧࡺࡷࡃ࠭ᄁ"),YLv6zoPid2Tj,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	m5bXjDFNhZpxJQ,KCvgXGx38mAIuy = bFXN1DeZjuVLGYxnB9JlwQ625hH[nnsBpJv6XL3OzHoe4Vuhr]
	xeckL2GArTWPFt = Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠧ࠽ࡸ࡬ࡩࡼࡹ࠾ࠨᄂ")+m5bXjDFNhZpxJQ+tRnTydV03Xfi7rbQ(u"ࠨ࠮ࠪᄃ")+KCvgXGx38mAIuy+rbUkdYi32PJaRtnxhDvQs(u"ࠩ࠿࠳ࡻ࡯ࡥࡸࡵࡁࠫᄄ")
	if showDialogs:
		GlwTfH9pFZSy2eRvWauqnrYD6oBA = bu6LzUQF7K.getInfoLabel(k5oIaYyp2mnrLK49qhzS(u"ࠪࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡖࡪࡧࡺࡱࡴࡪࡥࠨᄅ"))
		if GlwTfH9pFZSy2eRvWauqnrYD6oBA==HC9xWUMpBQJEuTteAqjd(u"ࠫࡊࡓࡁࡅࠢࡏ࡭ࡸࡺࠧᄆ"): NNdq1bS3isAWUj4 = opyTNwHgfqbZREWKU(u"่่ࠬศศ่ࠤฬ๊ใหษหอࠬᄇ")
		elif GlwTfH9pFZSy2eRvWauqnrYD6oBA==LJPOQNK1mcG(u"࠭ࡅࡎࡃࡇࠤࡌࡧ࡬࡭ࡧࡵࡽࠬᄈ"): NNdq1bS3isAWUj4 = On1WZJc6dtksqVNgSQ5GBAjuipe(u"ࠧใ๊สส๊ࠦวๅื๋ีࠬᄉ")
		else: NNdq1bS3isAWUj4 = ObuCsdoDtKmhPLSMH8YGan(u"ࠨไ๋หห๋ࠠฤะิํࠬᄊ")
		tcxhXCe0Z6EaAyPu = UN8rA03xkWLCGzebyEoF9YDRKBwSMO(s8fcjBCSMxzAIkZQbJPga(u"ࠩࡦࡩࡳࡺࡥࡳࠩᄋ"),Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠪๆํอฦๆࠢฦาึ๏ࠧᄌ"),On1WZJc6dtksqVNgSQ5GBAjuipe(u"ࠫ็๎วว็ࠣห้้สศสฬࠫᄍ"),LJPOQNK1mcG(u"่่ࠬศศ่ࠤฬ๊ี้ำࠪᄎ"),s8fcjBCSMxzAIkZQbJPga(u"࠭ว็ฬࠣัฬ๊๊ศࠢอืฯิฯๆࠢࠪᄏ")+NNdq1bS3isAWUj4,s8fcjBCSMxzAIkZQbJPga(u"ࠧศ่อࠤฬ๊ย็ࠢอืฯิฯๆࠢส่ส฻ฯศำࠣห้ษฮ๋ำ่ࠣั๊ฯࠡ็อีํฮ่ๅีࠣ฽๊อฯࠡ࠰ࠣ์์ึวࠡ็฼๊ฬํࠠศ่ๆࠤฯูสุ์฼ࠤฬูสฯัส้ࠥอไใ๊สส๊ࠦวๅ็ุ์ึฯࠠษั็ห๋ࠥๆࠡไ๋หห๋ࠠศๆๆฮฬฮษࠡ࠰ࠣ์ศ๐ึศࠢอืฯ฽ฺ๊ࠢศ๎็อแ่ษࠣๅ๏ࠦร๋๋ࠢๆฯࠦสีษฤࠤࡡࡴ࡜࡯ࠢࠪᄐ")+bxf7gZvNK29cEoiAIJlMq0dP+zDek1IW37rq6UoKdwyRiAVpF(u"ࠨࠢฦาฯืࠠศๆล๊ࠥ์ฺ่ࠢส่็๎วว็ࠣห้ะ๊ࠡฬิ๎ิࠦริฬัำฬ๋็ศࠢยࠥࠬᄑ")+kH8E2zqNyims6KJfI)
		if tcxhXCe0Z6EaAyPu==aar0zhDnJsOTP7EdgR16HIS29(u"࠵Ꮄ"): VV37v0uHLAo6Bfer8OKk = LJPOQNK1mcG(u"ࠩࡈࡑࡆࡊࠠࡍ࡫ࡶࡸࠬᄒ")
		elif tcxhXCe0Z6EaAyPu==vbYokBuWlxeLDcdVNM60(u"࠷Ꮅ"): VV37v0uHLAo6Bfer8OKk = dwiIAcPl04ey7Zv38Mz(u"ࠪࡉࡒࡇࡄࠡࡉࡤࡰࡱ࡫ࡲࡺࠩᄓ")
		else: VV37v0uHLAo6Bfer8OKk = cdZKMn68Pzg4
	else:
		GlwTfH9pFZSy2eRvWauqnrYD6oBA = Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.getSetting(aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠫࡦࡼ࠮࡮ࡻࡶ࡯࡮ࡴ࠮ࡷ࡫ࡨࡻࡲࡵࡤࡦࠩᄔ"))
		if   GlwTfH9pFZSy2eRvWauqnrYD6oBA==cdZKMn68Pzg4: tcxhXCe0Z6EaAyPu = rbUkdYi32PJaRtnxhDvQs(u"࠶Ꮆ")
		elif GlwTfH9pFZSy2eRvWauqnrYD6oBA==vbYokBuWlxeLDcdVNM60(u"ࠬࡋࡍࡂࡆࠣࡐ࡮ࡹࡴࠨᄕ"): tcxhXCe0Z6EaAyPu = uxE8MyoTRglrcaiQf(u"࠱Ꮇ")
		elif GlwTfH9pFZSy2eRvWauqnrYD6oBA==aNdix5gq7yeFHTMWhnzm8pX0Y16(u"࠭ࡅࡎࡃࡇࠤࡌࡧ࡬࡭ࡧࡵࡽࠬᄖ"): tcxhXCe0Z6EaAyPu = xN4fKmsnyM3Y2(u"࠳Ꮈ")
		VV37v0uHLAo6Bfer8OKk = GlwTfH9pFZSy2eRvWauqnrYD6oBA
	if   tcxhXCe0Z6EaAyPu==dwiIAcPl04ey7Zv38Mz(u"࠲Ꮉ"): whqYvPA7Z2s = SGazRxP3yBKZ15ILuch(u"ࠧ࠶࠷࠯࠹࠹࠺ࠬ࠶࠷࠸ࠫᄗ")
	elif tcxhXCe0Z6EaAyPu==xN4fKmsnyM3Y2(u"࠴Ꮊ"): whqYvPA7Z2s = LungQF89BqemOb32jJsZlW(u"ࠨ࠷࠷࠸࠱࠻࠵࠶࠮࠸࠹ࠬᄘ")
	elif tcxhXCe0Z6EaAyPu==KNomgGw1kdMCBH(u"࠶Ꮋ"): whqYvPA7Z2s = TtyzcuW45VKA(u"ࠩ࠸࠹࠺࠲࠵࠶࠮࠸࠸࠹࠭ᄙ")
	else: return
	Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.setSetting(AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"ࠪࡥࡻ࠴࡭ࡺࡵ࡮࡭ࡳ࠴ࡶࡪࡧࡺࡱࡴࡪࡥࠨᄚ"),VV37v0uHLAo6Bfer8OKk)
	yYqHkJQuDdf9hUCA62TxVr = SGazRxP3yBKZ15ILuch(u"ࠫࡁࡼࡩࡦࡹࡶࡂࠬᄛ")+whqYvPA7Z2s+HC9xWUMpBQJEuTteAqjd(u"ࠬ࠲ࠧᄜ")+KCvgXGx38mAIuy+rbUkdYi32PJaRtnxhDvQs(u"࠭࠼࠰ࡸ࡬ࡩࡼࡹ࠾ࠨᄝ")
	fbcMqO63BUlQRNIPjzdKgJaCLiwD9 = YLv6zoPid2Tj.replace(xeckL2GArTWPFt,yYqHkJQuDdf9hUCA62TxVr)
	if W5domCu6XrQUFkiPpa3bNLtHglG: fbcMqO63BUlQRNIPjzdKgJaCLiwD9 = fbcMqO63BUlQRNIPjzdKgJaCLiwD9.encode(vczMIlkCAh2u10B3)
	open(jwh6o5O2AME,LungQF89BqemOb32jJsZlW(u"ࠧࡸࡤࠪᄞ")).write(fbcMqO63BUlQRNIPjzdKgJaCLiwD9)
	SsziMZd5UbeL2NRxVpwjO(F0FeocLXmbJhdBwQnS18PCHZIU,KNomgGw1kdMCBH(u"ࠨ࠰࡟ࡸࡘࡱࡩ࡯ࠢࡇࡩ࡫ࡧࡵ࡭ࡶ࡚ࠣ࡮࡫ࡷࡴ࠼ࠣ࡟ࠥ࠭ᄟ")+whqYvPA7Z2s+k5oIaYyp2mnrLK49qhzS(u"ࠩࠣࡡࠬᄠ"))
	if showDialogs: bu6LzUQF7K.executebuiltin(nfg30bHwd4aNV12SR7UjFck(u"ࠪࡖࡪࡲ࡯ࡢࡦࡖ࡯࡮ࡴࠨࠪࠩᄡ"))
	return
def hSfIs3oZPFtMgaTv9Yn4i():
	BoyIUWYSNR0jhDxQwvJriO4PkL = JyLdvftP3CU(cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠫอืๆศ็ฯࠤ฾๋วะࠢไ๎์ࠦๅีๅ็อࠥ฿ๆะๅࠣ࠲࠳࠴ࠠฦ็สࠤศ๊ลึัสี่ࠥฯ๋็ࠣ࠲࠳࠴ࠠฤ๊ࠣห๋ะࠠๆ็้์฾ࠦๅ็ࠢสืฯิฯศ็ࠣห้ฮั็ษ่ะࠥ࠴࠮࠯ࠢฦ์๊ࠥฯ๋ๅู้้ࠣไสࠢฦาึ๏ࠠหะุࠤัํวำๅࠣว๋ะ้ࠠๆสࠤฯิีࠡสๅ๎ฮࠦฮๅไࠣห้๊็ࠡ࡞ࡱࡠࡳࠦอศ๊็ࠤฯำฯ๋อࠣห้ฮั็ษ่ะࠥษ่ࠡษอู้ࠦศศๆ่ฬึ๋ฬࠡๆ่฽ึ็ษࠡีหฬࠥอไๆึๆ่ฮูࠦ็ัๆࠤ࠳࠴࠮้ࠡ็ࠤฯื๊ะࠢไัฺࠦวๅฬะำ๏ัวหࠢส่ว์ࠠภࠩᄢ"))
	if BoyIUWYSNR0jhDxQwvJriO4PkL==J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"࠶Ꮌ"): TrhS6DBuFtfX()
	return
def KE19xWNge5UY7r2BlO0kPn4Qd():
	NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,opyTNwHgfqbZREWKU(u"ࠬํะศࠢส่๊๎โฺ่ࠢ฾้่ࠠๆ่ࠣห้๋ีะำࠣ์฿๐ัࠡ็฼ีํ็ࠠๆฬํࠤ๏ืฬฺࠢ็่฾๋ไࠨᄣ"))
	return
def rme3QqWS67iBZv():
	rejRY592MzwLXCqP6kNISHByim = bxf7gZvNK29cEoiAIJlMq0dP+AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"࠭สฺัสำฺฺ๊ࠥหࠣฦ้ࠦๅฮ็าࠤู้ๆสࠢ࠵࠴࠷࠷ࠠ࠻ࠢࠪᄤ")+kH8E2zqNyims6KJfI
	rejRY592MzwLXCqP6kNISHByim += aar0zhDnJsOTP7EdgR16HIS29(u"ࠧศๆ่์็฿ࠠฤั้ห์ࠦแ๋้ࠣษา฻วว์ฬࠤ้฿ฯะࠢสู่๐ูสࠢไ๎ࠥอไฺษ็้ࠥะๅࠡฮ่฽์อࠠๆ่ࠣะ๊๐ูࠡษ็ฺ้อฯาࠢส่๊ะ่โำฬࠤๆ๐ࠠศๆศ๊ฯืๆหࠢส่็ี๊ๆหࠣ์ฬ๊ฬะ์าอࠥอไฮๅ๋้๏ฯ้ࠠษ็฾๏ืࠠฮๅ๋้๏ฯ้ࠠ็้ࠤัฺ๋๊ࠢา์้ࠦวๅ฻ส่๊ࠦหๆࠢอ้ࠥะ่ฮ์า๋ฬ่ࠦฮีสฬࠥอไๆ฻า่ࠥำำษࠢึ็ฬ์ࠠะ๊็ࠤฬู๊ศๆ่ࠤู้ๆสࠢ࠵࠴࠷࠷้้ࠠํࠤฬ๊ลฮืสส๏ฯࠠศๆฦัิั้ࠠษ็วู๋ไࠡษ็ฮ๏ࠦสๆࠢ฼้้ํวࠡใํࠤฬ๊ำ็๊สฮࠥอไฺึิอࠥอไๆษู๎ฮ࠭ᄥ")
	rejRY592MzwLXCqP6kNISHByim += ssELJkeScrtni2+bxf7gZvNK29cEoiAIJlMq0dP+aar0zhDnJsOTP7EdgR16HIS29(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡷ࡭ࡳࡿ࠮ࡤࡥ࠲ࡷ࡭࡯ࡡࡤࡱࡸࡲࡹ࠭ᄦ")+kH8E2zqNyims6KJfI
	li3O6w58Lr1AhRbzvXjeDU7MdH = bxf7gZvNK29cEoiAIJlMq0dP+dwiIAcPl04ey7Zv38Mz(u"ࠩหี๋อๅอࠢืี๏฽ࠠศๆ่ื้๋ࠠ࠻ࠢࠪᄧ")+kH8E2zqNyims6KJfI
	li3O6w58Lr1AhRbzvXjeDU7MdH += s8fcjBCSMxzAIkZQbJPga(u"๋ࠪํูࠦษษิอࠥ฿ๆࠡสิ๊ฬ๋ฬࠡ์๋ๅึࠦๅฺๆ๋้ฬะࠠฮีสฬ๏ฯࠠไอํีฮࠦส่็ࠣะ๊๐ูࠡษ็ุ้๊ๅ๋่้ࠣะ๊ࠠฤ๊ๅหฯࠦวๅื็หฮ่ࠦฤ๊ๅหฯࠦวๅๅึ์ๆ่ࠦศๆัืํ็้ࠠึๆ่ࠥอไใ็ิࠤํษ่ใษอࠤฬ๊โๆำࠣ์ศ๐ึศࠢํ์ๆืࠠาฦํอࠥอไ่ๆส่ࠥ็๊ࠡฮ่๎฾ࠦฯ้ๆࠣห้฿วๅ็ࠣ์ศ๐ึศࠢไ๎์ࠦสใ๊ํ้๋๊ࠥๅษา๎ࠥ๎็อำํࠤํ็๊่ࠢฦ๎฻อࠠษฯฮࠤํ่ัศรฬࠤฬ๊โาฤ้ࠤํษ๊ืษࠣๅ๏ํࠠศีอาฬืษ๊ࠡอๅฬสไ๊ࠡไ๎์ࠦรใ๊ส่๋ࠥๆิ๊หอ๊ࠥไฤ็ส้ࠥ฿ไ๋๋ࠢว๊๎ัࠡลัี๎ࠦส่็ࠣ็้ࠦๅิๆ่ࠤ࠳ࠦวๅสิ๊ฬ๋ฬࠡ็ๆฮํฮࠠษๆ฽อࠥาวโษࠣื่ืศห๋ࠢ๎ุะฮะ็๊ࠣ฽อๅ๊ࠡํ๊ิ๎าࠡฬะฮࠥฮ๊วหࠣ์๏์ฯ้ิࠣ็ฬา๊ห๋้ࠢำ฻ีࠡใๅ฻๊ࠥรอ้ีอࠥอไ้์้ำํุࠠ࠯ࠢส่๊๎โฺࠢส่ึูๅ๋ࠢ็่อืๆศ็ฯࠤ์๎ࠧᄨ")
	li3O6w58Lr1AhRbzvXjeDU7MdH += ssELJkeScrtni2+bxf7gZvNK29cEoiAIJlMq0dP+s8fcjBCSMxzAIkZQbJPga(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡺࡩ࡯ࡻ࠱ࡧࡨ࠵࡭ࡶࡵ࡯࡭ࡲࡸࡵ࡭ࡧࡵࠫᄩ")+kH8E2zqNyims6KJfI
	KZ4oqDz5xgA2tkGcTaeQ1Lh3dp = zDek1IW37rq6UoKdwyRiAVpF(u"ࠬࡡࡒࡕࡎࡠࠫᄪ")+rejRY592MzwLXCqP6kNISHByim+NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"࠭࡜࡯࡞ࡱࡠࡳࡡࡒࡕࡎࡠࠫᄫ")+li3O6w58Lr1AhRbzvXjeDU7MdH
	E3WHU2OdFfmX459c(nfg30bHwd4aNV12SR7UjFck(u"ࠧࡳ࡫ࡪ࡬ࡹ࠭ᄬ"),cdZKMn68Pzg4,KZ4oqDz5xgA2tkGcTaeQ1Lh3dp)
	return
def F1ogqlnDRAGkb42YX9SVh(nB3YKPXmCteR5c4FqMphN2izG):
	qJCuGHUaeOv(fS25N8gAZxpbnLi3srX7PJ)
	jjo29gbhfq = IcFg58SuXynv3JHfBDQ2aOMNmZbCUw(nB3YKPXmCteR5c4FqMphN2izG)
	for PoYcBIQdtagh in [WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠨࡏࡈࡗࡘࡇࡇࡆࡕࠪᄭ"),KNomgGw1kdMCBH(u"ࠩࡔ࡙ࡊ࡙ࡔࡊࡑࡑࡗࠬᄮ"),f8Ja1q5eO02B(u"ࠪࡑࡊ࡙ࡓࡂࡉࡈࡗࡤ࡚ࡓࠨᄯ"),LungQF89BqemOb32jJsZlW(u"ࠫࡖ࡛ࡅࡔࡖࡌࡓࡓ࡙࡟ࡕࡕࠪᄰ")]:
		if PoYcBIQdtagh in USuRxnPlV5.SEND_THESE_EVENTS: USuRxnPlV5.SEND_THESE_EVENTS.remove(PoYcBIQdtagh)
	yV1hpK79g30lRw(opyTNwHgfqbZREWKU(u"ࠬࡊࡏࡏࡃࡗࡍࡔࡔࡓࠨᄱ"))
	id,l5Q1RUnycofqBeJCTYLpD9iV7aghwb,rcgP6YoLtT8lyuMa,TGKDixtNnaczZBfmLVpb,CCGh0EWMzyRr4,reason = jjo29gbhfq[nnsBpJv6XL3OzHoe4Vuhr]
	Nx4zjvUXEm9Z0ftCnwrQAdsyM,HUmozgRf0lOKMiIPBv8GX36CZ = TGKDixtNnaczZBfmLVpb.split(iRfoNckJs7Ibxzh5j92w8DSWF(u"࠭࡜࡯࠽࠾ࠫᄲ"))
	li3O6w58Lr1AhRbzvXjeDU7MdH,a3tzxkPUoO,gvzWimTak9Se5B6A3UF = CCGh0EWMzyRr4.split(iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠧ࡝ࡰ࠾࠿ࠬᄳ"))
	EqKfajBnZHSUpzx9i6vr482leGTy3V = IZQbmFzLHDtXfc
	while EqKfajBnZHSUpzx9i6vr482leGTy3V:
		wLvatZI32KDnRQYWsfr1jTNOCh = UN8rA03xkWLCGzebyEoF9YDRKBwSMO(cdZKMn68Pzg4,k5oIaYyp2mnrLK49qhzS(u"ࠨะิ์ั࠭ᄴ"),liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠩศีุอไࠡำึห้ฯࠠๅๆ่ฬึ๋ฬࠨᄵ"),tRnTydV03Xfi7rbQ(u"ࠪๆฬฬๅสࠢส่ฯฮัฺษอࠫᄶ"),TtyzcuW45VKA(u"้ࠫห๊ใษไࠤฬ๊ลฺๆส๊ฬะࠠ࠻ࠢࠣฮอืูࠡล๋ࠤฬ๋ำฮࠢส่อืๆศ็ฯࠫᄷ"),li3O6w58Lr1AhRbzvXjeDU7MdH)
		if wLvatZI32KDnRQYWsfr1jTNOCh==zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"࠸Ꮍ"): wwnZsRNdYJy = UN8rA03xkWLCGzebyEoF9YDRKBwSMO(cdZKMn68Pzg4,cdZKMn68Pzg4,uxE8MyoTRglrcaiQf(u"ࠬ฿่ะหࠪᄸ"),cdZKMn68Pzg4,zDek1IW37rq6UoKdwyRiAVpF(u"࠭ๅษัฦࠤฬ๊สษำ฼ࠤ฿๐ัࠡไสฬ้ࠦไๅ่ๅหู࠭ᄹ"),a3tzxkPUoO,rbUkdYi32PJaRtnxhDvQs(u"ࠧࡤࡱࡱࡪ࡮ࡸ࡭ࡠࡵࡰࡥࡱࡲࡦࡰࡰࡷࠫᄺ"))
		elif wLvatZI32KDnRQYWsfr1jTNOCh==zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"࠱Ꮎ"): CB0jufwiVLMhAodO()
		else: EqKfajBnZHSUpzx9i6vr482leGTy3V = ksTLSoVGg0ht
	if nB3YKPXmCteR5c4FqMphN2izG: XfABsbKWoLhI(ksTLSoVGg0ht)
	return
def ttUVbJRKp2LFgwB4Xj():
	gfnlUZx9iFVL()
	FybmuBRxh7jqvNnrG3pceXlK5fdz = Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.getSetting(zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡨࡧࡣࡩࡧࠪᄻ"))
	KZ4oqDz5xgA2tkGcTaeQ1Lh3dp = {}
	KZ4oqDz5xgA2tkGcTaeQ1Lh3dp[iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠩࡄ࡙࡙ࡕࠧᄼ")] = Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠪห้้วีࠢส่ฯ๊โศศํࠤ๏฿ๅๅࠩᄽ")
	KZ4oqDz5xgA2tkGcTaeQ1Lh3dp[s8fcjBCSMxzAIkZQbJPga(u"ࠫࡘ࡚ࡏࡑࠩᄾ")] = tRnTydV03Xfi7rbQ(u"ࠬอไไษืࠤ๊ะ่ใใࠣฮ๊อๅศ๋ࠢฬฬ๊ใศ็็ࠫᄿ")
	KZ4oqDz5xgA2tkGcTaeQ1Lh3dp[tRnTydV03Xfi7rbQ(u"࠭ࡌࡊࡏࡌࡘࡊࡊࠧᅀ")] = LungQF89BqemOb32jJsZlW(u"ࠧไษืࠤัีวࠡไุ๎ึࠦวๅ็าํࠥ࠴ࠠࠨᅁ")+str(kZK9jh5ufsoVAmxreYPbyUaR7I0LO/uxE8MyoTRglrcaiQf(u"࠷࠲Ꮏ"))+KNomgGw1kdMCBH(u"ࠨࠢาๆ๏่ษࠡใๅ฻ࠬᅂ")
	nZJjk2tl47TehL36E = KZ4oqDz5xgA2tkGcTaeQ1Lh3dp[FybmuBRxh7jqvNnrG3pceXlK5fdz]
	tcxhXCe0Z6EaAyPu = UN8rA03xkWLCGzebyEoF9YDRKBwSMO(cdZKMn68Pzg4,xN4fKmsnyM3Y2(u"ࠩๆหูࠦࠧᅃ")+str(kZK9jh5ufsoVAmxreYPbyUaR7I0LO/AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"࠸࠳Ꮐ"))+WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠪࠤิ่๊ใหࠪᅄ"),uxE8MyoTRglrcaiQf(u"ࠫฯฺฺ๋ๆࠣฮ้่วว์ࠪᅅ"),dwiIAcPl04ey7Zv38Mz(u"ࠬห๊ใษไࠤ่อๅๅࠩᅆ"),nZJjk2tl47TehL36E,LungQF89BqemOb32jJsZlW(u"࠭็ๅࠢอี๏ีࠠศีอาิอๅࠡษ็็ฬฺࠠศๆำ็๏ࠦวๅฬ็ๆฬฬ๊ࠡล่ࠤฯื๊ะࠢศ๎็อแࠡษ็็ฬฺࠠษษ็็ฬ๋ไࠡล่ࠤฯื๊ะࠢๆหููࠦๆำ๊ࠤ็฻๊าࠢฯำฬࠦฟࠢࠩᅇ"))
	if tcxhXCe0Z6EaAyPu==k5oIaYyp2mnrLK49qhzS(u"࠳Ꮑ"): vynVpuPXgiQm2rqcWRBsF7LhNbk3K = opyTNwHgfqbZREWKU(u"ࠧࡍࡋࡐࡍ࡙ࡋࡄࠨᅈ")
	elif tcxhXCe0Z6EaAyPu==TtyzcuW45VKA(u"࠵Ꮒ"): vynVpuPXgiQm2rqcWRBsF7LhNbk3K = J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠨࡃࡘࡘࡔ࠭ᅉ")
	elif tcxhXCe0Z6EaAyPu==iRfoNckJs7Ibxzh5j92w8DSWF(u"࠷Ꮓ"): vynVpuPXgiQm2rqcWRBsF7LhNbk3K = nfg30bHwd4aNV12SR7UjFck(u"ࠩࡖࡘࡔࡖࠧᅊ")
	else: vynVpuPXgiQm2rqcWRBsF7LhNbk3K = cdZKMn68Pzg4
	if vynVpuPXgiQm2rqcWRBsF7LhNbk3K:
		Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.setSetting(LungQF89BqemOb32jJsZlW(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡣࡢࡥ࡫ࡩࠬᅋ"),vynVpuPXgiQm2rqcWRBsF7LhNbk3K)
		HCkVnwvTKp64ld5e7zJf3u2xYGjB = KZ4oqDz5xgA2tkGcTaeQ1Lh3dp[vynVpuPXgiQm2rqcWRBsF7LhNbk3K]
		NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,HCkVnwvTKp64ld5e7zJf3u2xYGjB)
	return
def Y1TxI8DokvRzHm6fMV():
	KZ4oqDz5xgA2tkGcTaeQ1Lh3dp = {}
	KZ4oqDz5xgA2tkGcTaeQ1Lh3dp[opyTNwHgfqbZREWKU(u"ࠫࡆ࡛ࡔࡐࠩᅌ")] = nfg30bHwd4aNV12SR7UjFck(u"ู๊ࠬาใิࠤࡉࡔࡓࠡษ็ฮ้่วว์ࠣ๎฾๋ไ࠻ࠢࠪᅍ")
	KZ4oqDz5xgA2tkGcTaeQ1Lh3dp[TtyzcuW45VKA(u"࠭ࡁࡔࡍࠪᅎ")] = AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"ࠧิ์ิๅึࠦࡄࡏࡕࠣื๏฿ๅๅࠢห฽ิࠦวๅี่หาࠦไ่࠼ࠣࠫᅏ")
	KZ4oqDz5xgA2tkGcTaeQ1Lh3dp[WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠨࡕࡗࡓࡕ࠭ᅐ")] = S5fhsRT8JV(u"ࠩึ๎ึ็ัࠡࡆࡑࡗ๋ࠥส้ไไࠤฯ๋วๆษࠣ์ออไไษ่่ࠬᅑ")
	ccWhVBkDF1dZYenMRp4EXfJ79QbGLq = Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.getSetting(KNomgGw1kdMCBH(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡤ࡯ࡵࠪᅒ"))
	FybmuBRxh7jqvNnrG3pceXlK5fdz = Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.getSetting(tRnTydV03Xfi7rbQ(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡵࡨࡨࡳࡹࠧᅓ"))
	nZJjk2tl47TehL36E = KZ4oqDz5xgA2tkGcTaeQ1Lh3dp[FybmuBRxh7jqvNnrG3pceXlK5fdz]+ccWhVBkDF1dZYenMRp4EXfJ79QbGLq
	tcxhXCe0Z6EaAyPu = UN8rA03xkWLCGzebyEoF9YDRKBwSMO(cdZKMn68Pzg4,Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠬะิ฻์็ࠤ฾์ฯࠡษ็้ํอแใหࠪᅔ"),KNomgGw1kdMCBH(u"࠭สี฼ํ่ࠥะไใษษ๎ࠬᅕ"),tRnTydV03Xfi7rbQ(u"ࠧฦ์ๅหๆࠦใศ็็ࠫᅖ"),nZJjk2tl47TehL36E,k5oIaYyp2mnrLK49qhzS(u"ࠨีํีๆืࠠࡅࡐࡖࠤ์๎ࠠอ้สึࠥ็๊ࠡษ็ษ๋ะั็์อࠤ๏่่ๆࠢหฮา๎๊ๅࠢฦื๊อมࠡษ็้ํอโฺ๋ࠢหู้๊าใิหฯࠦลๅ๋ࠣวึ่วๆ๋ࠢ฽๋ีࠠษ฻ูࠤฬ๊ๆศีࠣ๎็๎ๅࠡสะะอ่ࠦๆ่฼ࠤํำึาࠢห฽฻ࠦวๅ็๋ห็฿ࠠ࠯ࠢ็ฮูเ๊ๅࠢึ๎ึ็ัࠡࡆࡑࡗ่ࠥๅࠡสสาฯ๐วาࠢสุ่๐ัโำࠣห้๋ๆศีหࠤศ๎ࠠใ็ࠣฬส๐โศใ๊ࠤออไไษ่่ࠬᅗ"))
	if tcxhXCe0Z6EaAyPu==dwiIAcPl04ey7Zv38Mz(u"࠶Ꮔ"): vynVpuPXgiQm2rqcWRBsF7LhNbk3K = dwiIAcPl04ey7Zv38Mz(u"ࠩࡄࡗࡐ࠭ᅘ")
	elif tcxhXCe0Z6EaAyPu==zDek1IW37rq6UoKdwyRiAVpF(u"࠱Ꮕ"): vynVpuPXgiQm2rqcWRBsF7LhNbk3K = aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠪࡅ࡚࡚ࡏࠨᅙ")
	elif tcxhXCe0Z6EaAyPu==TtyzcuW45VKA(u"࠳Ꮖ"): vynVpuPXgiQm2rqcWRBsF7LhNbk3K = AiCor1fIVTDxQUWwHe9vPR7(u"ࠫࡘ࡚ࡏࡑࠩᅚ")
	if tcxhXCe0Z6EaAyPu in [Rsdai9xIEPcpuBMKOUwkTA05q(u"࠳Ꮘ"),HC9xWUMpBQJEuTteAqjd(u"࠳Ꮗ")]:
		BoyIUWYSNR0jhDxQwvJriO4PkL = JyLdvftP3CU(nfg30bHwd4aNV12SR7UjFck(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬᅛ"),S5fhsRT8JV(u"࠭ำ๋ำไี࠿ࠦࠧᅜ")+USuRxnPlV5.DNS_SERVERS[hiuZa0PIsErm6UC7],iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠧิ์ิๅึࡀࠠࠨᅝ")+USuRxnPlV5.DNS_SERVERS[nnsBpJv6XL3OzHoe4Vuhr],cdZKMn68Pzg4,KNomgGw1kdMCBH(u"ࠨลัฮฬืࠠิ์ิๅึࠦࡄࡏࡕࠣห้๋ๆศีหࠤ้้ࠧᅞ"))
		if BoyIUWYSNR0jhDxQwvJriO4PkL==uxE8MyoTRglrcaiQf(u"࠵Ꮙ"): jWMSa4tz3bE = USuRxnPlV5.DNS_SERVERS[nnsBpJv6XL3OzHoe4Vuhr]
		else: jWMSa4tz3bE = USuRxnPlV5.DNS_SERVERS[hiuZa0PIsErm6UC7]
	elif tcxhXCe0Z6EaAyPu==aar0zhDnJsOTP7EdgR16HIS29(u"࠷Ꮚ"): jWMSa4tz3bE = cdZKMn68Pzg4
	else: vynVpuPXgiQm2rqcWRBsF7LhNbk3K = cdZKMn68Pzg4
	if vynVpuPXgiQm2rqcWRBsF7LhNbk3K:
		Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.setSetting(LJPOQNK1mcG(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡦࡱࡷࠬᅟ"),vynVpuPXgiQm2rqcWRBsF7LhNbk3K)
		Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.setSetting(f8Ja1q5eO02B(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡤ࡯ࡵࠪᅠ"),jWMSa4tz3bE)
		HCkVnwvTKp64ld5e7zJf3u2xYGjB = KZ4oqDz5xgA2tkGcTaeQ1Lh3dp[vynVpuPXgiQm2rqcWRBsF7LhNbk3K]+jWMSa4tz3bE
		NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,HCkVnwvTKp64ld5e7zJf3u2xYGjB)
	return
def csS0zTtJGhKMUja3mDBOC():
	FybmuBRxh7jqvNnrG3pceXlK5fdz = Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.getSetting(J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡵࡨࡴࡷࡵࡸࡺࠩᅡ"))
	KZ4oqDz5xgA2tkGcTaeQ1Lh3dp = {}
	KZ4oqDz5xgA2tkGcTaeQ1Lh3dp[AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"ࠬࡇࡕࡕࡑࠪᅢ")] = J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"࠭วๅสิ์ู่๊ࠡษ็ฮ้่วว์ࠣะฬําࠡๆ็฽๊๊ࠧᅣ")
	KZ4oqDz5xgA2tkGcTaeQ1Lh3dp[zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"ࠧࡂࡕࡎࠫᅤ")] = On1WZJc6dtksqVNgSQ5GBAjuipe(u"ࠨษ็ฬึ๎ใิ์ࠣื๏฿ๅๅࠢห฽ิࠦวๅี่หาࠦไ่ࠩᅥ")
	KZ4oqDz5xgA2tkGcTaeQ1Lh3dp[AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"ࠩࡖࡘࡔࡖࠧᅦ")] = SGazRxP3yBKZ15ILuch(u"ࠪห้ฮั้ๅึ๎๋ࠥส้ไไࠤฯ๋วๆษࠣ์ออไไษ่่ࠬᅧ")
	nZJjk2tl47TehL36E = KZ4oqDz5xgA2tkGcTaeQ1Lh3dp[FybmuBRxh7jqvNnrG3pceXlK5fdz]
	tcxhXCe0Z6EaAyPu = UN8rA03xkWLCGzebyEoF9YDRKBwSMO(cdZKMn68Pzg4,zDek1IW37rq6UoKdwyRiAVpF(u"ࠫฯฺฺ๋ๆࠣ฽๋ีࠠศๆ่์ฬ็โสࠩᅨ"),vbYokBuWlxeLDcdVNM60(u"ࠬะิ฻์็ࠤฯ๊โศศํࠫᅩ"),S5fhsRT8JV(u"࠭ล๋ไสๅ้ࠥวๆๆࠪᅪ"),nZJjk2tl47TehL36E,WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠧศๆหีํ้ำ๋๊ࠢ์ࠥา็ศิࠣๅ๏ࠦวๅว้ฮึ์๊หࠢํ฽๊๊้ࠠีํ฻ࠥฮ๊็ࠢฯ๋ฬุใ๊ࠡส่ส์สา่ํฮࠥ࠴่๊ࠠࠣ๎ุะไๆฺ่ࠢออสไ๋ࠢ๎็๎ๅࠡสึัอํวࠡสา่ฬࠦๅ็ๅࠣฯ๊๊ࠦษ฻ฮ๋ฬࠦไไࠢ࠱ࠤ์๊ࠠหำํำࠥะิ฻์็ࠤศ๋ࠠฦ์ๅหๆࠦวๅสิ์ู่๊ࠡมࠪᅫ"))
	if tcxhXCe0Z6EaAyPu==On1WZJc6dtksqVNgSQ5GBAjuipe(u"࠶Ꮛ"): vynVpuPXgiQm2rqcWRBsF7LhNbk3K = tRnTydV03Xfi7rbQ(u"ࠨࡃࡖࡏࠬᅬ")
	elif tcxhXCe0Z6EaAyPu==aar0zhDnJsOTP7EdgR16HIS29(u"࠱Ꮜ"): vynVpuPXgiQm2rqcWRBsF7LhNbk3K = TtyzcuW45VKA(u"ࠩࡄ࡙࡙ࡕࠧᅭ")
	elif tcxhXCe0Z6EaAyPu==TtyzcuW45VKA(u"࠳Ꮝ"): vynVpuPXgiQm2rqcWRBsF7LhNbk3K = nfg30bHwd4aNV12SR7UjFck(u"ࠪࡗ࡙ࡕࡐࠨᅮ")
	else: vynVpuPXgiQm2rqcWRBsF7LhNbk3K = cdZKMn68Pzg4
	if vynVpuPXgiQm2rqcWRBsF7LhNbk3K:
		Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.setSetting(AiCor1fIVTDxQUWwHe9vPR7(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡵࡨࡴࡷࡵࡸࡺࠩᅯ"),vynVpuPXgiQm2rqcWRBsF7LhNbk3K)
		HCkVnwvTKp64ld5e7zJf3u2xYGjB = KZ4oqDz5xgA2tkGcTaeQ1Lh3dp[vynVpuPXgiQm2rqcWRBsF7LhNbk3K]
		NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,HCkVnwvTKp64ld5e7zJf3u2xYGjB)
	return
def PPkK8VuQ0ZUxOcXsYAnqo1wy():
	E9rFzU0RlCLbOq31iVs = Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.getSetting(tRnTydV03Xfi7rbQ(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡣࡸࡸࡴࡹࡣࡳࡣࡳࡩࡷࡹࠧᅰ"))
	if E9rFzU0RlCLbOq31iVs==HC9xWUMpBQJEuTteAqjd(u"࠭ࡓࡕࡑࡓࠫᅱ"): header = f8Ja1q5eO02B(u"ࠧหฮส์ืࠦวๅฯฯฬࠥอไฤ๊อ์๊อส๋ๅํࠤ๊ะ่ใใࠪᅲ")
	else: header = k5oIaYyp2mnrLK49qhzS(u"ࠨฬฯหํุࠠศๆะะอࠦวๅล๋ฮํ๋วห์ๆ๎๋ࠥแฺๆࠪᅳ")
	BoyIUWYSNR0jhDxQwvJriO4PkL = JyLdvftP3CU(cdZKMn68Pzg4,nfg30bHwd4aNV12SR7UjFck(u"ࠩศ๎็อแࠨᅴ"),KNomgGw1kdMCBH(u"ࠪฮๆ฿๊ๅࠩᅵ"),header,SGazRxP3yBKZ15ILuch(u"ࠫอ฿ึࠡษ็้ํอโฺࠢอ฽ฬ์๊ࠡ็้ࠤฺ๊ใๅหࠣห้ำฬษࠢ࠱࠲ࠥํะศࠢส่าาศࠡ์่๊฾ࠦวๅสิ๊ฬ๋ฬࠡ็้ࠤๆะอࠡษ็ูๆำวห๋ࠢๆึอมห้สࠤ࠳࠴่่ࠠสࠤฯูสุ์฼ࠤศ์ࠠหี่ั๊ࠥไษำ้ห๊าࠠฤ่ࠣ๎็๎ๅࠡล๋ฮํ๋วห์ๆ๎ฬࠦศๆฯส์้ฯࠠหฮส์ืࠦ็ัษࠣห้ำฬษࠢ࡟ࡲࡡࡴ่ࠠๆࠣฮึ๐ฯࠡฬไ฽๏๊ࠠฤ็ࠣษ๏่วโࠢอะฬ๎าࠡษ็ััฮࠠศๆฦ์ฯ๎ๅศฬํ็๏ࠦฟࠢࠣࠪᅶ"))
	if BoyIUWYSNR0jhDxQwvJriO4PkL==-LungQF89BqemOb32jJsZlW(u"࠳Ꮞ"): return
	elif BoyIUWYSNR0jhDxQwvJriO4PkL:
		Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.setSetting(zDek1IW37rq6UoKdwyRiAVpF(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡣࡸࡸࡴࡹࡣࡳࡣࡳࡩࡷࡹࠧᅷ"),s8fcjBCSMxzAIkZQbJPga(u"࠭ࡁࡖࡖࡒࠫᅸ"))
		NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,SGazRxP3yBKZ15ILuch(u"ࠧห็ࠣฮๆ฿๊ๅࠢอะฬ๎าࠡษ็ััฮࠠศๆฦ์ฯ๎ๅศฬํ็๏࠭ᅹ"))
	else:
		Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.setSetting(NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡦࡻࡴࡰࡵࡦࡶࡦࡶࡥࡳࡵࠪᅺ"),SGazRxP3yBKZ15ILuch(u"ࠩࡖࡘࡔࡖࠧᅻ"))
		NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠪฮ๊ࠦล๋ไสๅࠥะฬศ๊ีࠤฬ๊ออสࠣห้ษ่ห๊่หฯ๐ใ๋ࠩᅼ"))
	return
def NwEdfayOXkWhs0LzS():
	E9rFzU0RlCLbOq31iVs = Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.getSetting(S5fhsRT8JV(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮࡮ࡧࡱࡹࡸࡩࡡࡤࡪࡨࠫᅽ"))
	if E9rFzU0RlCLbOq31iVs==xN4fKmsnyM3Y2(u"࡙ࠬࡔࡐࡒࠪᅾ"): header = AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"࠭สฯิํ๊ࠥอไใ๊สส๊ࠦๅห๊ๅๅࠬᅿ")
	else: header = S5fhsRT8JV(u"ࠧหะี๎๋ࠦวๅไ๋หห๋ࠠๆใ฼่ࠬᆀ")
	BoyIUWYSNR0jhDxQwvJriO4PkL = JyLdvftP3CU(cdZKMn68Pzg4,zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"ࠨวํๆฬ็ࠧᆁ"),rbUkdYi32PJaRtnxhDvQs(u"ࠩอๅ฾๐ไࠨᆂ"),header,xN4fKmsnyM3Y2(u"ࠪๆํอฦๆࠢส่อืๆศ็ฯࠤ๏ะๅࠡฬะำ๏ั็ศࠢฦ์ฯ๎ๅศฬํ็๏อࠠษ฻าࠤ࠶࠼ࠠิษ฼อ๋ࠥๆࠡล๋่ࠥษำหะาห๊ࠦ࠮࠯๋ࠢษ๏่วโࠢอาื๐ๆࠡษ็ๆํอฦๆࠢํศิ๐ࠠฦๆ์ࠤฯำฯ๋อ๊หࠥ็๊ࠡๅ็ࠤ๊ืษࠡ์อ้ࠥอำหะาห๊ࠦวๅไ๋หห๋ࠠ࠯࠰ࠣ์์ึวࠡ์ึฬอࠦศุศࠣๅ๏ࠦแหฯࠣๆํอฦๆࠢส่อืๆศ็ฯࡠࡳࡢ࡮้ࠡ็ࠤฯื๊ะࠢอๅ฾๐ไࠡล่ࠤส๐โศใࠣฮำุ๊็ࠢส่็๎วว็ࠣรࠦࠧࠧᆃ"))
	if BoyIUWYSNR0jhDxQwvJriO4PkL==-AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"࠴Ꮟ"): return
	elif BoyIUWYSNR0jhDxQwvJriO4PkL:
		Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.setSetting(Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮࡮ࡧࡱࡹࡸࡩࡡࡤࡪࡨࠫᆄ"),LJPOQNK1mcG(u"ࠬࡇࡕࡕࡑࠪᆅ"))
		NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"࠭สๆࠢอๅ฾๐ไࠡฬัึ๏์ࠠศๆๅ์ฬฬๅࠨᆆ"))
	else:
		Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.setSetting(AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡱࡪࡴࡵࡴࡥࡤࡧ࡭࡫ࠧᆇ"),xN4fKmsnyM3Y2(u"ࠨࡕࡗࡓࡕ࠭ᆈ"))
		NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,ObuCsdoDtKmhPLSMH8YGan(u"ࠩอ้ࠥห๊ใษไࠤฯิา๋่ࠣห้่่ศศ่ࠫᆉ"))
	return
def YQxDlcTFvPNrtZh6bW081RG():
	RZA2WBSLJd = Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.getSetting(tRnTydV03Xfi7rbQ(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴࡭ࡦࡰࡸࡷࡼ࡫ࡢࡤࡣࡦ࡬ࡪ࠭ᆊ"))
	if RZA2WBSLJd==zDek1IW37rq6UoKdwyRiAVpF(u"ࠫࡘ࡚ࡏࡑࠩᆋ"): header = opyTNwHgfqbZREWKU(u"ࠬาไษࠢส่็๎วว็้๋ࠣࠦวๅว้ฮึ์สࠡ็อ์็็ࠧᆌ")
	else: header = uxE8MyoTRglrcaiQf(u"࠭ฬๅสࠣห้่่ศศ่ࠤ๊์ࠠศๆศ๊ฯืๆห่ࠢๅ฾๊ࠧᆍ")
	BoyIUWYSNR0jhDxQwvJriO4PkL = JyLdvftP3CU(cdZKMn68Pzg4,LJPOQNK1mcG(u"ࠧฦ์ๅหๆ࠭ᆎ"),NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠨฬไ฽๏๊ࠧᆏ"),header,ObuCsdoDtKmhPLSMH8YGan(u"ࠩๅ์ฬฬๅࠡส฼ฺࠥอไๆ๊สๆ฾่ࠦฯษุอࠥอไๆฯฯ์อฯࠠๆ็ๆ๊ࠥะฮำ์้๋ฬࠦแ๋ࠢส่ส์สา่อࠤๆ๐ࠠิ์ิๅึอสࠡๆสࠤ๏๎ฬะࠢไ๎์อࠠๆึๆ่ฮࠦออสࠣ࠲࠳ࠦ็ั้ࠣห้฽ั๋ไฬࠤฯูวฺัࠣๅ๏ࠦโาษฤอࠥ๎วิฬัำฬ๋ࠠศๆ่์ฬู่ࠡษ็้าา่ษห่่ࠣ์ࠠๆ่้ࠣํู่ࠡสา๎้ࠦๅห๊ไีࠥ๎ฺ๋ำ้ࠣาา่ษࠢ࡟ࡲࡡࡴ࡜࡯๊่ࠢࠥะั๋ัࠣฮๆ฿๊ๅࠢฦ้ࠥห๊ใษไࠤั๊ศࠡษ็ๆํอฦๆ่๊ࠢࠥอไฦ่อี๋ะࠠภࠣࠤࠫᆐ"))
	if BoyIUWYSNR0jhDxQwvJriO4PkL==-k5oIaYyp2mnrLK49qhzS(u"࠵Ꮠ"): return
	elif BoyIUWYSNR0jhDxQwvJriO4PkL:
		Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.setSetting(KNomgGw1kdMCBH(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴࡭ࡦࡰࡸࡷࡼ࡫ࡢࡤࡣࡦ࡬ࡪ࠭ᆑ"),s8fcjBCSMxzAIkZQbJPga(u"ࠫࡆ࡛ࡔࡐࠩᆒ"))
		NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"ࠬะๅࠡฬไ฽๏๊ࠠอๆหࠤฬ๊โ้ษษ้๋ࠥๆࠡษ็์๏ฮࠧᆓ"))
	else:
		Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.setSetting(xN4fKmsnyM3Y2(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡰࡩࡳࡻࡳࡸࡧࡥࡧࡦࡩࡨࡦࠩᆔ"),nfg30bHwd4aNV12SR7UjFck(u"ࠧࡔࡖࡒࡔࠬᆕ"))
		NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"ࠨฬ่ࠤส๐โศใࠣะ้ฮࠠศๆๅ์ฬฬๅࠡ็้ࠤฬ๊่๋สࠪᆖ"))
	return
def ppGA7Ra6InVC8WJPLYgoDwHUF19hb(JAYWBoz54tGw7O):
	if JAYWBoz54tGw7O!=cdZKMn68Pzg4:
		JAYWBoz54tGw7O = SN0Eo5O1njRg3WiQq26luk8d(JAYWBoz54tGw7O)
		JAYWBoz54tGw7O = JAYWBoz54tGw7O.decode(vczMIlkCAh2u10B3).encode(vczMIlkCAh2u10B3)
		cNmJQf8sa9khHCglzLK0RSy5BVou = s8fcjBCSMxzAIkZQbJPga(u"࠶࠶࠱࠱࠵Ꮡ")
		WFBizY5NXgnq61 = r8rEvwjH91KlNMhIZoAVdpRyWeDfcs.Window(cNmJQf8sa9khHCglzLK0RSy5BVou)
		WFBizY5NXgnq61.getControl(KNomgGw1kdMCBH(u"࠹࠱࠲Ꮢ")).setLabel(JAYWBoz54tGw7O)
	return
ga7GkqLeZO2STmF5z = [
			 LJPOQNK1mcG(u"ࠤࡨࡼࡹ࡫࡮ࡴ࡫ࡲࡲࠥࡧࡶࡴࡲࡤࡧࡪࡹ࠰ࠡ࡫ࡶࠤࡳࡵࡴࠡࡥࡸࡶࡷ࡫࡮ࡵ࡮ࡼࠤࡸࡻࡰࡱࡱࡵࡸࡪࡪࠢᆗ")
			,nfg30bHwd4aNV12SR7UjFck(u"ࠪࡇ࡭࡫ࡣ࡬࡫ࡱ࡫ࠥ࡬࡯ࡳࠢࡐࡥࡱ࡯ࡣࡪࡱࡸࡷࠥࡹࡣࡳ࡫ࡳࡸࡸ࠭ᆘ")
			,uxE8MyoTRglrcaiQf(u"ࠫࡕ࡜ࡒࠡࡋࡓࡘ࡛ࠦࡓࡪ࡯ࡳࡰࡪࠦࡃ࡭࡫ࡨࡲࡹ࠭ᆙ")
			,xN4fKmsnyM3Y2(u"࡛ࠬ࡮࡬ࡰࡲࡻࡳࠦࡖࡪࡦࡨࡳࠥࡏ࡮ࡧࡱࠣࡏࡪࡿࠧᆚ")
			,LungQF89BqemOb32jJsZlW(u"࠭ࡴࡩ࡫ࡶࠤ࡭ࡧࡳࡩࠢࡩࡹࡳࡩࡴࡪࡱࡱࠤ࡮ࡹࠠࡣࡴࡲ࡯ࡪࡴࠧᆛ")
			,nfg30bHwd4aNV12SR7UjFck(u"ࠧࡶࡵࡨࡷࠥࡶ࡬ࡢ࡫ࡱࠤࡍ࡚ࡔࡑࠢࡩࡳࡷࠦࡡࡥࡦ࠰ࡳࡳࠦࡤࡰࡹࡱࡰࡴࡧࡤࡴࠩᆜ")
			,zDek1IW37rq6UoKdwyRiAVpF(u"ࠨࡣࡧࡺࡦࡴࡣࡦࡦ࠰ࡹࡸࡧࡧࡦ࠰࡫ࡸࡲࡲࠧᆝ")+S5fhsRT8JV(u"ࠩࠦࠫᆞ")+uxE8MyoTRglrcaiQf(u"ࠪࡷࡸࡲ࠭ࡸࡣࡵࡲ࡮ࡴࡧࡴࠩᆟ")
			,LungQF89BqemOb32jJsZlW(u"ࠫࡎࡴࡳࡦࡥࡸࡶࡪࡘࡥࡲࡷࡨࡷࡹ࡝ࡡࡳࡰ࡬ࡲ࡬࠲ࠧᆠ")
			,ObuCsdoDtKmhPLSMH8YGan(u"ࠬࡋࡲࡳࡱࡵࠤ࡬࡫ࡴࡵ࡫ࡱ࡫ࠥࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠵࠿࡮ࡱࡧࡩࡪࡃ࠰ࠧࡶࡨࡼࡹࡺ࠽ࠨᆡ")
			,LJPOQNK1mcG(u"࠭ࡷࡢࡴࡱ࡭ࡳ࡭ࡳ࠯ࡹࡤࡶࡳ࠮ࠧᆢ")
			,aar0zhDnJsOTP7EdgR16HIS29(u"ࠧ࡟ࡠࡡࡢࡣ࠭ᆣ")
			,YnHG75e2QWwo(u"ࠨࡎࡲࡥࡩ࡯࡮ࡨࠢࡶ࡯࡮ࡴࠠࡧ࡫࡯ࡩ࠿࠭ᆤ")
			,aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠩ࡯ࡥࡷ࡭ࡥࠡࡣࡸࡨ࡮ࡵࠠࡴࡻࡱࡧࠥ࡫ࡲࡳࡱࡵ࠾ࠬᆥ")
			,rbUkdYi32PJaRtnxhDvQs(u"ࠪ࡭ࡳ࡬࡯࠻ࠢࡐࡩࡩ࡯ࡡࡤࡱࡧࡩࡨࠦࡤࡦࡥࡲࡨࡪࡸ࠺ࠨᆦ")
			]
def IYN0vGSoXkejnOAwtBg8qhL4Z5D(FTYWLlCaGDuxyzZpS3B):
	if xN4fKmsnyM3Y2(u"ࠫࡑࡵࡡࡥ࡫ࡱ࡫ࠥࡹ࡫ࡪࡰࠣࡪ࡮ࡲࡥ࠻ࠩᆧ") in FTYWLlCaGDuxyzZpS3B and J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪᆨ") in FTYWLlCaGDuxyzZpS3B: return IZQbmFzLHDtXfc
	for JAYWBoz54tGw7O in ga7GkqLeZO2STmF5z:
		if JAYWBoz54tGw7O in FTYWLlCaGDuxyzZpS3B: return IZQbmFzLHDtXfc
	return ksTLSoVGg0ht
def UDPeOXHzGMqw70ch5d(data):
	SSEcgFRnOiX3Z6a5sfzkYU = rbUkdYi32PJaRtnxhDvQs(u"࠸Ꮤ") if W5domCu6XrQUFkiPpa3bNLtHglG else f8Ja1q5eO02B(u"࠱࠶Ꮣ")
	data = data.replace(tRnTydV03Xfi7rbQ(u"࠵࠳Ꮥ")*VBpIH2QSmvDGlA6TO3e,SSEcgFRnOiX3Z6a5sfzkYU*VBpIH2QSmvDGlA6TO3e)
	data = data.replace(On1WZJc6dtksqVNgSQ5GBAjuipe(u"࠭ࠠ࠽ࡩࡨࡲࡪࡸࡡ࡭ࡀ࠽ࠤࠬᆩ"),AiCor1fIVTDxQUWwHe9vPR7(u"ࠧ࠻ࠢࠪᆪ"))
	H3F607d1jsXEnMvor2 = cdZKMn68Pzg4
	for FTYWLlCaGDuxyzZpS3B in data.splitlines():
		ThtOMkNZeEDB5Jw = ffUFBJQ57j2XgoGeOLn9uwpC.findall(WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠨࠢࠣࠤࠥࠦࡆࡪ࡮ࡨࠤࠧ࠮࠮ࠫࡁࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹ࠮ࠪࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧᆫ"),FTYWLlCaGDuxyzZpS3B,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if ThtOMkNZeEDB5Jw: FTYWLlCaGDuxyzZpS3B = FTYWLlCaGDuxyzZpS3B.replace(ThtOMkNZeEDB5Jw[nnsBpJv6XL3OzHoe4Vuhr],cdZKMn68Pzg4)
		H3F607d1jsXEnMvor2 += ssELJkeScrtni2+FTYWLlCaGDuxyzZpS3B
	return H3F607d1jsXEnMvor2
def NaMG2CHgDv4X1OJW9hR3UynKrzIp5F(uuBZxWCDt75):
	if KNomgGw1kdMCBH(u"ࠩࡒࡐࡉ࠭ᆬ") in uuBZxWCDt75:
		tGLKuOb4qspnomdzi6EJyB = MRgC7k3P0elziZT1t6E9rbq
		header = TtyzcuW45VKA(u"ࠪๆึอมสࠢสุ่าไࠡษ็ๆิ๐ๅࠡมࠪᆭ")
	else:
		tGLKuOb4qspnomdzi6EJyB = wFeXhTvd4MBjnyJRVYubzfCI0lW2O
		header = k5oIaYyp2mnrLK49qhzS(u"ࠫ็ืวยหࠣหู้ฬๅࠢส่าอไ๋ࠢยࠫᆮ")
	BoyIUWYSNR0jhDxQwvJriO4PkL = JyLdvftP3CU(cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,header,S5fhsRT8JV(u"ูࠬฬๅࠢส่ศิืศรࠣ๎าะ่๋ࠢฦ๎฻อฺࠠๆ์ࠤุาไࠡษ็หุะฮะษ่ࠤ࠳่ࠦศๆสฯ๋๐ๆุࠡิ์ึ๐ษࠡๆ่฽ึ็ษࠡๅํๅࠥำฯฬฬࠣห้๋ิไๆฬࠤํ๋ว้๋ࠡࠤฬ๊ๅไษ้ࠤฬ๊ะ๋ࠢึฬอࠦอะ๊ฮࠤฬ๊ๅีๅ็อࠥ࠴ࠠไ๊า๎ࠥ๐อหใ฻ࠤอูฬๅ์้ࠤ࠳ࠦวๅล๋่ࠥํ่ࠡษ็ืั๊ࠠศๆะห้๐้ࠠใํู๋๋ࠥๅ๊่หฯࠦสษัฦࠤ๊์ะࠡสาห๏ฯࠠศๆอุ฿๐ไࠡษ็ัฬ๊๊ࠡๆหี๋อๅอࠢๆ์ิ๐้ࠠษ็ํࠥอไร่ࠣ࠲ࠥษๅศࠢสุ่าไࠡษ็ๆิ๐ๅࠡใ๊์ࠥอไิฮ็ࠤฬ๊ำศสๅࠤฬ๊ะ๋ࠢอ้ࠥาๅฺ้้๋ࠣࠦศา่ส้ัࠦใ้ัํࠤ็ฮไࠡฤัีࠥหืโษฤࠤ้ํࠠ࠯๊่ࠢࠥะั๋ัࠣห้อำห็ิหึࠦฟࠨᆯ"))
	if BoyIUWYSNR0jhDxQwvJriO4PkL!=SGazRxP3yBKZ15ILuch(u"࠴Ꮦ"): return
	p6Sq3NvKWulAfLPake,vDM613VAFznJXw90L4CW5abjiSZlI = [],LungQF89BqemOb32jJsZlW(u"࠴Ꮧ")
	size,count = s98szN34g6bnYvpl(tGLKuOb4qspnomdzi6EJyB)
	file = open(tGLKuOb4qspnomdzi6EJyB,uxE8MyoTRglrcaiQf(u"࠭ࡲࡣࠩᆰ"))
	if size>aNdix5gq7yeFHTMWhnzm8pX0Y16(u"࠷࠰࠱࠴࠳࠴Ꮩ"): file.seek(-rbUkdYi32PJaRtnxhDvQs(u"࠶࠶࠰࠲࠲࠳Ꮨ"),YRESXadfbIy3khwqmL8WC.SEEK_END)
	data = file.read()
	file.close()
	if W5domCu6XrQUFkiPpa3bNLtHglG: data = data.decode(vczMIlkCAh2u10B3)
	data = UDPeOXHzGMqw70ch5d(data)
	LrPZs7iUEO9AkKV4gfIcoxQqn2 = data.split(ssELJkeScrtni2)
	for FTYWLlCaGDuxyzZpS3B in reversed(LrPZs7iUEO9AkKV4gfIcoxQqn2):
		oO7CG2P5QdxDMZ = IYN0vGSoXkejnOAwtBg8qhL4Z5D(FTYWLlCaGDuxyzZpS3B)
		if oO7CG2P5QdxDMZ: continue
		FTYWLlCaGDuxyzZpS3B = FTYWLlCaGDuxyzZpS3B.replace(vbYokBuWlxeLDcdVNM60(u"ࠧ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠࡠࠩᆱ"),bxf7gZvNK29cEoiAIJlMq0dP+aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠨࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫᆲ")+kH8E2zqNyims6KJfI)
		FTYWLlCaGDuxyzZpS3B = FTYWLlCaGDuxyzZpS3B.replace(AiCor1fIVTDxQUWwHe9vPR7(u"ࠩࡈࡖࡗࡕࡒ࠻ࠩᆳ"),opyTNwHgfqbZREWKU(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆ࠱࠲࠳࠴ࡢ࠭ᆴ")+SGazRxP3yBKZ15ILuch(u"ࠫࡊࡘࡒࡐࡔ࠽ࠫᆵ")+kH8E2zqNyims6KJfI)
		clqNhVLzrp4HRgd3vTXS0Itb = cdZKMn68Pzg4
		IIMCP5UsQwGO8gVcumDTe9NjbpJ = ffUFBJQ57j2XgoGeOLn9uwpC.findall(tRnTydV03Xfi7rbQ(u"ࠬࡤࠨ࡝ࡦ࠮࠱࠭ࡢࡤࠬ࠯࡟ࡨ࠰ࠦ࡜ࡥ࠭࠽ࡠࡩ࠱࠺࡝ࡦ࠮ࡠ࠳ࡢࡤ࡚ࠬࠫࠬࠬࠥ࠺࡝ࡦ࠮࠭ࠬᆶ"),FTYWLlCaGDuxyzZpS3B,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if IIMCP5UsQwGO8gVcumDTe9NjbpJ:
			FTYWLlCaGDuxyzZpS3B = FTYWLlCaGDuxyzZpS3B.replace(IIMCP5UsQwGO8gVcumDTe9NjbpJ[nnsBpJv6XL3OzHoe4Vuhr][nnsBpJv6XL3OzHoe4Vuhr],IIMCP5UsQwGO8gVcumDTe9NjbpJ[nnsBpJv6XL3OzHoe4Vuhr][hiuZa0PIsErm6UC7]).replace(IIMCP5UsQwGO8gVcumDTe9NjbpJ[nnsBpJv6XL3OzHoe4Vuhr][bVX3ev1spE],cdZKMn68Pzg4)
			clqNhVLzrp4HRgd3vTXS0Itb = IIMCP5UsQwGO8gVcumDTe9NjbpJ[nnsBpJv6XL3OzHoe4Vuhr][hiuZa0PIsErm6UC7]
		else:
			IIMCP5UsQwGO8gVcumDTe9NjbpJ = ffUFBJQ57j2XgoGeOLn9uwpC.findall(dwiIAcPl04ey7Zv38Mz(u"࠭࡞ࠩ࡞ࡧ࠯࠿ࡢࡤࠬ࠼࡟ࡨ࠰ࡢ࠮࡝ࡦ࠮࠭࠭ࠦࡔ࠻࡞ࡧ࠯࠮࠭ᆷ"),FTYWLlCaGDuxyzZpS3B,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			if IIMCP5UsQwGO8gVcumDTe9NjbpJ:
				FTYWLlCaGDuxyzZpS3B = FTYWLlCaGDuxyzZpS3B.replace(IIMCP5UsQwGO8gVcumDTe9NjbpJ[nnsBpJv6XL3OzHoe4Vuhr][hiuZa0PIsErm6UC7],cdZKMn68Pzg4)
				clqNhVLzrp4HRgd3vTXS0Itb = IIMCP5UsQwGO8gVcumDTe9NjbpJ[nnsBpJv6XL3OzHoe4Vuhr][nnsBpJv6XL3OzHoe4Vuhr]
		if clqNhVLzrp4HRgd3vTXS0Itb: FTYWLlCaGDuxyzZpS3B = FTYWLlCaGDuxyzZpS3B.replace(clqNhVLzrp4HRgd3vTXS0Itb,Gzygq01Kcb9U3+clqNhVLzrp4HRgd3vTXS0Itb+kH8E2zqNyims6KJfI)
		p6Sq3NvKWulAfLPake.append(FTYWLlCaGDuxyzZpS3B)
		if len(str(p6Sq3NvKWulAfLPake))>LungQF89BqemOb32jJsZlW(u"࠵࠱࠳࠳࠴Ꮪ"): break
	p6Sq3NvKWulAfLPake = reversed(p6Sq3NvKWulAfLPake)
	ssi3F5umlv = ssELJkeScrtni2.join(p6Sq3NvKWulAfLPake)
	E3WHU2OdFfmX459c(S5fhsRT8JV(u"ࠧ࡭ࡧࡩࡸࠬᆸ"),KNomgGw1kdMCBH(u"ࠨฤัีࠥษำุำࠣืั๊ࠠศๆฦา฼อม๊ࠡส่ฬูสฯัส้ࠬᆹ"),ssi3F5umlv,YnHG75e2QWwo(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡸࡳࡡ࡭࡮ࡩࡳࡳࡺ࡟࡭ࡱࡱ࡫ࠬᆺ"))
	return
def SHyFUij1rMLOTKuZ2():
	Ocex34RhVut5Fk2JaKnmMs = open(qObmgKxSvj,zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"ࠪࡶࡧ࠭ᆻ")).read()
	if W5domCu6XrQUFkiPpa3bNLtHglG: Ocex34RhVut5Fk2JaKnmMs = Ocex34RhVut5Fk2JaKnmMs.decode(vczMIlkCAh2u10B3)
	Ocex34RhVut5Fk2JaKnmMs = Ocex34RhVut5Fk2JaKnmMs.replace(HC9xWUMpBQJEuTteAqjd(u"ࠫࡡࡺࠧᆼ"),liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠬࠦࠠࠡࠢࠣࠤࠥࠦࠧᆽ"))
	Hgd2k9RXymZVqcw = ffUFBJQ57j2XgoGeOLn9uwpC.findall(liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"࠭ࠨࡷ࡞ࡧ࠲࠯ࡅࠩ࡜࡞ࡱࡠࡷࡣࠧᆾ"),Ocex34RhVut5Fk2JaKnmMs,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	for FTYWLlCaGDuxyzZpS3B in Hgd2k9RXymZVqcw:
		Ocex34RhVut5Fk2JaKnmMs = Ocex34RhVut5Fk2JaKnmMs.replace(FTYWLlCaGDuxyzZpS3B,bxf7gZvNK29cEoiAIJlMq0dP+FTYWLlCaGDuxyzZpS3B+kH8E2zqNyims6KJfI)
	RMDqaKOvQCXghu81Gc(AiCor1fIVTDxQUWwHe9vPR7(u"ࠧศๆอ฾๏๐ัศฬࠣห้ษฮ๋ำฬࠤๆ๐ࠠศๆหีฬ๋ฬࠨᆿ"),Ocex34RhVut5Fk2JaKnmMs)
	return
def EdHhIeG2VNjOWzQ3M():
	rejRY592MzwLXCqP6kNISHByim = LJPOQNK1mcG(u"ࠨส฼ฺࠥอไฤิิหึูࠦๅ๋ࠣห้ื๊ๆ๊อࠤ่๎ๆหำ๋่ࠥะ่โำࠣษ๊้ว็์ฬࠤฯ่ฯ๋็ࠣ์ฯษฮ๋ำࠣห้็๊ะ์๋ࠤํํะ่ࠢส่ศุัศำ๋ࠣ๏ࠦวๅลึ๋๊่ࠦศๆฦี็อๅࠡ็฼ࠤอ฿ึ๊ࠡๆห้ะวๅ์ࠪᇀ")
	li3O6w58Lr1AhRbzvXjeDU7MdH = liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠩ็ฮ็ี๊ๆࠢส่ๆ๐ฯ๋๊ࠣหุะฮะ็ࠣหู้็ๆࠢส่๏๋๊็๋่ࠢฯษฮ๋ำ๊ࠤฬูสฯั่ࠤฬ๊ำ่็ࠣห้๐ำศำࠣ࠲ࠥษๅศࠢ฼ำฮࠦวิ้่ࠤ๊ะสศๆํอࠥ็็ั้ࠣฮ็๎ๅࠡสอัึ๐ใࠡษ็ๅ๏ี๊้ࠢห์็ะࠠศๅหี๋ࠥๆ๊ࠡๅฮࠥอไิ้่ࠤฬ๊่ศฯาࠤ࠳ࠦรๆษࠣหู้็ๆࠢส่ศ฿ไ๊๋ࠢห้ษำโๆࠣๅ์๎๋ࠠฯิ็ࠥอไโ์า๎ํࠦลๅ๋ࠣห้ษๅศ็ࠣวํࠦลๅ๋ࠣห้๎ัศรࠣ์้้ๆࠡสๅๅืฯࠠไสํีฮ࠭ᇁ")
	a3tzxkPUoO = HC9xWUMpBQJEuTteAqjd(u"ࠪว๊อࠠศๆฦี็อๅࠡใ๊๎ࠥะำหะา้๊ࠥไหไา๎๊่ࠦศๆอวำ๐ั๊ࠡ็็๋ࠦศๆไาหึูࠦะัࠣห้ั่ศ่ํࠤํอไะไสส็ࠦ࠮ࠡ็ฮ่ฬࠦัใ็ࠣ࠹࠹࠺ࠠห฻้๎ࠥ࠻ࠠะไสส็่ࠦࠡ࠶࠷ࠤะอๆ๋หࠣษ้๏ࠠศๆฦ้ฬ๋ࠠฤ๊ࠣษ้๏ࠠศๆ๋ีฬวࠠษฯึฬࠥอำหะาห๊้ࠠๅๆึ๋๊ࠦวๅ์่๎๋ࠦร้ࠢึ๋๊ࠦวๅ์ึหึ࠭ᇂ")
	KZ4oqDz5xgA2tkGcTaeQ1Lh3dp = rejRY592MzwLXCqP6kNISHByim+xN4fKmsnyM3Y2(u"ࠫ࠿ࠦࠧᇃ")+li3O6w58Lr1AhRbzvXjeDU7MdH+YnHG75e2QWwo(u"ࠬࠦ࠮ࠡࠩᇄ")+a3tzxkPUoO
	E3WHU2OdFfmX459c(NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ᇅ"),OPEJxmUqr9wAX1i,KZ4oqDz5xgA2tkGcTaeQ1Lh3dp,LungQF89BqemOb32jJsZlW(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪᇆ"))
	return
def Kvtg8yxpJYBAlo(type,KZ4oqDz5xgA2tkGcTaeQ1Lh3dp,showDialogs=IZQbmFzLHDtXfc,url=cdZKMn68Pzg4,MqpxmkbFcNAvGjVKoHzaw=cdZKMn68Pzg4,JAYWBoz54tGw7O=cdZKMn68Pzg4,jjQHcXJtVwWdigqEazN2xpuYZ6BhG=cdZKMn68Pzg4):
	MCKGYPV6N8inO127BLUXhjg = IZQbmFzLHDtXfc
	if not USuRxnPlV5.UZOwXToGvJnEqB4tgczAS2hHu:
		if showDialogs:
			KJEbeaH9Zyh0QkqdNBz = (xN4fKmsnyM3Y2(u"ࠨษ็ื฼ื࠺ࠨᇇ") in KZ4oqDz5xgA2tkGcTaeQ1Lh3dp and xN4fKmsnyM3Y2(u"ࠩส่๊้ว็࠼ࠪᇈ") in KZ4oqDz5xgA2tkGcTaeQ1Lh3dp and SGazRxP3yBKZ15ILuch(u"ࠪห้๋ไโ࠼ࠪᇉ") in KZ4oqDz5xgA2tkGcTaeQ1Lh3dp and NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠫฬ๊ฮุลࠪᇊ") in KZ4oqDz5xgA2tkGcTaeQ1Lh3dp and SGazRxP3yBKZ15ILuch(u"ࠬอไๆืาี࠿࠭ᇋ") in KZ4oqDz5xgA2tkGcTaeQ1Lh3dp)
			if not KJEbeaH9Zyh0QkqdNBz: MCKGYPV6N8inO127BLUXhjg = JyLdvftP3CU(ObuCsdoDtKmhPLSMH8YGan(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ᇌ"),cdZKMn68Pzg4,cdZKMn68Pzg4,YnHG75e2QWwo(u"่ࠧๆࠣฮึูไ้ࠡำ๋ࠥอไาีส่ฮࠦลๅ๋ࠣห้๋ศา็ฯࠫᇍ"),KZ4oqDz5xgA2tkGcTaeQ1Lh3dp.replace(zDek1IW37rq6UoKdwyRiAVpF(u"ࠨ࡞࡟ࡲࠬᇎ"),ssELJkeScrtni2))
	elif showDialogs:
		KZ4oqDz5xgA2tkGcTaeQ1Lh3dp = ObuCsdoDtKmhPLSMH8YGan(u"ࠩ࡟ࡠࡳะๅࠡ็ึัࠥอไาีส่ฮࡢ࡜࡯ฬ่ࠤู๊อࠡำึห้ฯ࡜࡝ࡰอ้๋ࠥำฮࠢส่ึูวๅห࡟ࡠࡳะๅࠡ็ึัࠥอไาีส่ฮࡢ࡜࡯ฬ่ࠤู๊อࠡษ็ีุอไสࠩᇏ")
		xuDFVcGORStmyKeE5r = JyLdvftP3CU(J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠪࡧࡪࡴࡴࡦࡴࠪᇐ"),cdZKMn68Pzg4,cdZKMn68Pzg4,s8fcjBCSMxzAIkZQbJPga(u"ࠫฯ๋ࠠๆีะࠤึูวๅฬๆࠫᇑ")+WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠬࠦࠠ࠲࠱࠸ࠫᇒ"),zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"࠭็ๅࠢอี๏ีࠠฦำึห้ࠦัิษ็อࠥ็วา฼ฬࠫᇓ"))
		CdZ05WiBu4bnN3qlI = JyLdvftP3CU(rbUkdYi32PJaRtnxhDvQs(u"ࠧࡤࡧࡱࡸࡪࡸࠧᇔ"),cdZKMn68Pzg4,cdZKMn68Pzg4,uxE8MyoTRglrcaiQf(u"ࠨฬ่ࠤู๊อࠡำึห้ะใࠨᇕ")+f8Ja1q5eO02B(u"ࠩࠣࠤ࠷࠵࠵ࠨᇖ"),liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"๋้ࠪࠦสา์าࠤสืำศๆࠣีุอไสࠢไหึเษࠨᇗ"))
		e7Gpz1Cy3r2UBb0sO = JyLdvftP3CU(tRnTydV03Xfi7rbQ(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫᇘ"),cdZKMn68Pzg4,cdZKMn68Pzg4,liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠬะๅࠡ็ึัࠥืำศๆอ็ࠬᇙ")+opyTNwHgfqbZREWKU(u"࠭ࠠࠡ࠵࠲࠹ࠬᇚ"),aar0zhDnJsOTP7EdgR16HIS29(u"่ࠧๆࠣฮึ๐ฯࠡวิืฬ๊ࠠาีส่ฮࠦแศำ฽อࠬᇛ"))
		VIB6SDpyMLCO0E7 = JyLdvftP3CU(YnHG75e2QWwo(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨᇜ"),cdZKMn68Pzg4,cdZKMn68Pzg4,AiCor1fIVTDxQUWwHe9vPR7(u"ࠩอ้๋ࠥำฮࠢิืฬ๊สไࠩᇝ")+NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠪࠤࠥ࠺࠯࠶ࠩᇞ"),xN4fKmsnyM3Y2(u"ࠫ์๊ࠠหำํำࠥหัิษ็ࠤึูวๅหࠣๅฬืฺสࠩᇟ"))
		MCKGYPV6N8inO127BLUXhjg = JyLdvftP3CU(HC9xWUMpBQJEuTteAqjd(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬᇠ"),cdZKMn68Pzg4,cdZKMn68Pzg4,liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"࠭สๆ่ࠢืาࠦัิษ็ฮ่࠭ᇡ")+YnHG75e2QWwo(u"ࠧࠡࠢ࠸࠳࠺࠭ᇢ"),NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠨ้็ࠤฯื๊ะࠢศีุอไࠡำึห้ฯࠠโษิ฾ฮ࠭ᇣ"))
	l5Q1RUnycofqBeJCTYLpD9iV7aghwb = NO3BIgUPeMwjCp(ksTLSoVGg0ht)
	XlKBEs6PHqTG2LA3odcbpaQ = NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠩࡄ࡚࠿ࠦࠧᇤ")+l5Q1RUnycofqBeJCTYLpD9iV7aghwb+xN4fKmsnyM3Y2(u"ࠪ࠱ࠬᇥ")+type
	Yp6InTPViClk39UuNz = IZQbmFzLHDtXfc if tRnTydV03Xfi7rbQ(u"ࠫࡤࡖࡒࡐࡄࡏࡉࡒࡥࠧᇦ") in JAYWBoz54tGw7O else ksTLSoVGg0ht
	if not MCKGYPV6N8inO127BLUXhjg:
		if showDialogs: NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠬะๅࠡว็฾ฬวࠠศๆศีุอไࠡส้หฦูࠦๅ๋ࠣ฻้ฮใࠨᇧ"))
		return ksTLSoVGg0ht
	HNBXPuUTxoSAyRwG = bu6LzUQF7K.getInfoLabel(AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"࠭ࡓࡺࡵࡷࡩࡲ࠴ࡆࡳ࡫ࡨࡲࡩࡲࡹࡏࡣࡰࡩࠬᇨ"))
	KZ4oqDz5xgA2tkGcTaeQ1Lh3dp += zDek1IW37rq6UoKdwyRiAVpF(u"ࠧࠡ࡞࡟ࡲࡡࡢ࡮࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽ࠡ࡞࡟ࡲࡆࡪࡤࡰࡰ࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ࠥ࠭ᇩ")+cWEA5yRl3VqGKk+NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠨࠢ࠽ࡠࡡࡴࠧᇪ")
	KZ4oqDz5xgA2tkGcTaeQ1Lh3dp += xN4fKmsnyM3Y2(u"ࠩࡈࡱࡦ࡯࡬ࠡࡕࡨࡲࡩ࡫ࡲ࠻ࠢࠪᇫ")+l5Q1RUnycofqBeJCTYLpD9iV7aghwb+KNomgGw1kdMCBH(u"ࠪࠤ࠿ࡢ࡜࡯ࡍࡲࡨ࡮ࠦࡖࡦࡴࡶ࡭ࡴࡴ࠺ࠡࠩᇬ")+Zcl1ozMwTy0DUB7VjvENKA9W8xGXH2+SGazRxP3yBKZ15ILuch(u"ࠫࠥࡀ࡜࡝ࡰࠪᇭ")
	KZ4oqDz5xgA2tkGcTaeQ1Lh3dp += vbYokBuWlxeLDcdVNM60(u"ࠬࡑ࡯ࡥ࡫ࠣࡒࡦࡳࡥ࠻ࠢࠪᇮ")+HNBXPuUTxoSAyRwG
	j6p7bZDotXA2U = CCOAq4fQyHuB0XNDESn5U3pKMr2v()
	j6p7bZDotXA2U = j6p7bZDotXA2U.replace(aNdix5gq7yeFHTMWhnzm8pX0Y16(u"࠭ࠬ࠭ࠩᇯ"),uxE8MyoTRglrcaiQf(u"ࠧ࠭ࠩᇰ"))
	j6p7bZDotXA2U = YQlEOShHM7RLak2t0yA4NXqv(j6p7bZDotXA2U)
	if j6p7bZDotXA2U: KZ4oqDz5xgA2tkGcTaeQ1Lh3dp += Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠨࠢ࠽ࡠࡡࡴࡌࡰࡥࡤࡸ࡮ࡵ࡮࠻ࠢࠪᇱ")+j6p7bZDotXA2U
	if url: KZ4oqDz5xgA2tkGcTaeQ1Lh3dp += zDek1IW37rq6UoKdwyRiAVpF(u"ࠩࠣ࠾ࡡࡢ࡮ࡖࡔࡏ࠾ࠥ࠭ᇲ")+url
	if MqpxmkbFcNAvGjVKoHzaw: KZ4oqDz5xgA2tkGcTaeQ1Lh3dp += LJPOQNK1mcG(u"ࠪࠤ࠿ࡢ࡜࡯ࡕࡲࡹࡷࡩࡥ࠻ࠢࠪᇳ")+MqpxmkbFcNAvGjVKoHzaw
	KZ4oqDz5xgA2tkGcTaeQ1Lh3dp += WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠫࠥࡀ࡜࡝ࡰࠪᇴ")
	if showDialogs: bJqPkYBXsenxTRwKu(J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠬาวา์ࠣห้หัิษ็ࠫᇵ"),nfg30bHwd4aNV12SR7UjFck(u"࠭วๅำฯหฦࠦวๅษ้ฮ฽อัࠨᇶ"))
	if Yp6InTPViClk39UuNz:
		if LungQF89BqemOb32jJsZlW(u"ࠧࡠࡒࡕࡓࡇࡒࡅࡎࡡࡒࡐࡉࡥࠧᇷ") in JAYWBoz54tGw7O: TnZBfhHvm9kS = MRgC7k3P0elziZT1t6E9rbq
		else: TnZBfhHvm9kS = wFeXhTvd4MBjnyJRVYubzfCI0lW2O
		if not YRESXadfbIy3khwqmL8WC.path.exists(TnZBfhHvm9kS):
			NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"ࠨีฯ่ࠥอไฤะฺหฦ่ࠦศๆสืฯิฯศ็ࠣ฾๏ืࠠๆ๊ฯ์ิ࠭ᇸ"))
			return ksTLSoVGg0ht
		SsziMZd5UbeL2NRxVpwjO(F0FeocLXmbJhdBwQnS18PCHZIU,vbYokBuWlxeLDcdVNM60(u"ࠩ࠱ࡠࡹࡖࡲࡦࡲࡤࡶ࡮ࡴࡧࠡࡶࡲࠤࡸ࡫࡮ࡥࠢࡷ࡬ࡪࠦ࡬ࡰࡩࡩ࡭ࡱ࡫ࠧᇹ"))
		p6Sq3NvKWulAfLPake,vDM613VAFznJXw90L4CW5abjiSZlI = [],opyTNwHgfqbZREWKU(u"࠱Ꮫ")
		file = open(TnZBfhHvm9kS,AiCor1fIVTDxQUWwHe9vPR7(u"ࠪࡶࡧ࠭ᇺ"))
		size,count = s98szN34g6bnYvpl(TnZBfhHvm9kS)
		if size>On1WZJc6dtksqVNgSQ5GBAjuipe(u"࠵࠳࠵࠵࠶࠰Ꮬ"): file.seek(-On1WZJc6dtksqVNgSQ5GBAjuipe(u"࠵࠳࠵࠵࠶࠰Ꮬ"),YRESXadfbIy3khwqmL8WC.SEEK_END)
		data = file.read()
		file.close()
		data = data.decode(vczMIlkCAh2u10B3)
		data = UDPeOXHzGMqw70ch5d(data)
		LrPZs7iUEO9AkKV4gfIcoxQqn2 = data.splitlines()
		for FTYWLlCaGDuxyzZpS3B in reversed(LrPZs7iUEO9AkKV4gfIcoxQqn2):
			oO7CG2P5QdxDMZ = IYN0vGSoXkejnOAwtBg8qhL4Z5D(FTYWLlCaGDuxyzZpS3B)
			if oO7CG2P5QdxDMZ: continue
			IIMCP5UsQwGO8gVcumDTe9NjbpJ = ffUFBJQ57j2XgoGeOLn9uwpC.findall(aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠫࡣ࠮࡜ࡥ࠭࠰ࠬࡡࡪࠫ࠮࡞ࡧ࠯ࠥࡢࡤࠬ࠼࡟ࡨ࠰ࡀ࡜ࡥ࠭࡟࠲ࡡࡪࠫࠪࠫࠫࠤ࡙ࡀ࡜ࡥ࠭ࠬࠫᇻ"),FTYWLlCaGDuxyzZpS3B,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			if IIMCP5UsQwGO8gVcumDTe9NjbpJ:
				FTYWLlCaGDuxyzZpS3B = FTYWLlCaGDuxyzZpS3B.replace(IIMCP5UsQwGO8gVcumDTe9NjbpJ[nnsBpJv6XL3OzHoe4Vuhr][nnsBpJv6XL3OzHoe4Vuhr],IIMCP5UsQwGO8gVcumDTe9NjbpJ[nnsBpJv6XL3OzHoe4Vuhr][hiuZa0PIsErm6UC7]).replace(IIMCP5UsQwGO8gVcumDTe9NjbpJ[nnsBpJv6XL3OzHoe4Vuhr][bVX3ev1spE],cdZKMn68Pzg4)
			else:
				IIMCP5UsQwGO8gVcumDTe9NjbpJ = ffUFBJQ57j2XgoGeOLn9uwpC.findall(nfg30bHwd4aNV12SR7UjFck(u"ࠬࡤࠨ࡝ࡦ࠮࠾ࡡࡪࠫ࠻࡞ࡧ࠯ࡡ࠴࡜ࡥ࡚࠭ࠬࠬࠥ࠺࡝ࡦ࠮࠭ࠬᇼ"),FTYWLlCaGDuxyzZpS3B,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
				if IIMCP5UsQwGO8gVcumDTe9NjbpJ: FTYWLlCaGDuxyzZpS3B = FTYWLlCaGDuxyzZpS3B.replace(IIMCP5UsQwGO8gVcumDTe9NjbpJ[nnsBpJv6XL3OzHoe4Vuhr][hiuZa0PIsErm6UC7],cdZKMn68Pzg4)
			p6Sq3NvKWulAfLPake.append(FTYWLlCaGDuxyzZpS3B)
			if len(str(p6Sq3NvKWulAfLPake))>f8Ja1q5eO02B(u"࠵࠹࠶࠶࠰࠱Ꮭ"): break
		p6Sq3NvKWulAfLPake = reversed(p6Sq3NvKWulAfLPake)
		ssi3F5umlv = zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"࠭࡜ࡳ࡞ࡱࠫᇽ").join(p6Sq3NvKWulAfLPake)
	elif jjQHcXJtVwWdigqEazN2xpuYZ6BhG: ssi3F5umlv = jjQHcXJtVwWdigqEazN2xpuYZ6BhG
	else: ssi3F5umlv = cdZKMn68Pzg4
	url = USuRxnPlV5.SITESURLS[YnHG75e2QWwo(u"ࠧࡑ࡛ࡗࡌࡔࡔࠧᇾ")][bVX3ev1spE]
	jYazNf8LMbPRh09gt5 = {rbUkdYi32PJaRtnxhDvQs(u"ࠨࡵࡸࡦ࡯࡫ࡣࡵࠩᇿ"):XlKBEs6PHqTG2LA3odcbpaQ,nfg30bHwd4aNV12SR7UjFck(u"ࠩࡰࡩࡸࡹࡡࡨࡧࠪሀ"):KZ4oqDz5xgA2tkGcTaeQ1Lh3dp,vbYokBuWlxeLDcdVNM60(u"ࠪࡰࡴ࡭ࡦࡪ࡮ࡨࠫሁ"):ssi3F5umlv}
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(fS25N8gAZxpbnLi3srX7PJ,ObuCsdoDtKmhPLSMH8YGan(u"ࠫࡕࡕࡓࡕࠩሂ"),url,jYazNf8LMbPRh09gt5,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,TtyzcuW45VKA(u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙࠭ࡔࡇࡑࡈࡤࡋࡍࡂࡋࡏ࠱࠶ࡹࡴࠨሃ"))
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	if J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"࠭ࡳࡦࡰࡧࡣࡸࡻࡣࡤࡧࡨࡨࡪࡪࠧሄ") in OO1cj2REUZHJ8x5V: Q0AOX4cEgius9e = IZQbmFzLHDtXfc
	else: Q0AOX4cEgius9e = ksTLSoVGg0ht
	if showDialogs:
		if Q0AOX4cEgius9e:
			bJqPkYBXsenxTRwKu(vbYokBuWlxeLDcdVNM60(u"ࠧห็ࠣห้หัิษ็ࠤอ์ฬศฯࠪህ"),f8Ja1q5eO02B(u"ࠨࡕࡸࡧࡨ࡫ࡳࡴࠩሆ"))
			NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,zDek1IW37rq6UoKdwyRiAVpF(u"ࠩࡐࡩࡸࡹࡡࡨࡧࠣࡷࡪࡴࡴࠨሇ"),vbYokBuWlxeLDcdVNM60(u"ࠪฮ๊ࠦลาีส่ࠥอไาีส่ฮࠦศ็ฮสัࠬለ"))
		else:
			bJqPkYBXsenxTRwKu(ObuCsdoDtKmhPLSMH8YGan(u"้๊ࠫริใࠣๅู๊ࠠศๆศีุอไࠨሉ"),LJPOQNK1mcG(u"ࠬࡌࡡࡪ࡮ࡸࡶࡪ࠭ሊ"))
			NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"࠭ฮุลࠣ์ๆฺไࠡใํࠤสืำศๆࠣห้ืำศๆฬࠫላ"))
	return Q0AOX4cEgius9e
def TTGituX2MFBgK8rpVJlZQ():
	rejRY592MzwLXCqP6kNISHByim = aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠧࡅࡱࠣࡽࡴࡻࠠࡸࡣࡱࡸࠥࡺ࡯ࠡࡶࡵࡥࡳࡹ࡬ࡢࡶࡨࠤࡲ࡫࡮ࡶࠢ࡬ࡸࡪࡳࡳࠡࡶࡲࠤࡦࠦ࡬ࡢࡰࡪࡹࡦ࡭ࡥࠡࡱࡷ࡬ࡪࡸࠠࡵࡪࡤࡲࠥࡇࡲࡢࡤ࡬ࡧࠥ࠴࠮ࠡࡑࡵࠤࡾࡵࡵࠡࡹࡤࡲࡹࠦࡴࡰࠢࡶ࡬ࡴࡽࠠࡂࡴࡤࡦ࡮ࡩࠠ࡭ࡧࡷࡸࡪࡸࡳࠡࡣࡱࡨࠥࡺࡥࡹࡶࠣࡃࠦ࠭ሌ")
	li3O6w58Lr1AhRbzvXjeDU7MdH = On1WZJc6dtksqVNgSQ5GBAjuipe(u"ࠨ้็ࠤฯื๊ะࠢอีั๋ษࠡไ๋หห๋ࠠศๆหี๋อๅอࠢศ่๎ࠦไ฻หࠣวำื้ࠡ฼ํีࠥอไฺำห๎ฮࠦ࠮࠯ࠢฦ้ࠥะั๋ัࠣษ฽ํวาࠢส่ศำัโ๋ࠢห้้สศสฬࠤฬู๊าสํอࠥลࠡࠨል")
	choice = UN8rA03xkWLCGzebyEoF9YDRKBwSMO(LungQF89BqemOb32jJsZlW(u"ࠩࡦࡩࡳࡺࡥࡳࠩሎ"),f8Ja1q5eO02B(u"ࠪาึ๎ฬࠡࡇࡻ࡭ࡹ࠭ሏ"),dwiIAcPl04ey7Zv38Mz(u"࡙ࠫࡸࡡ࡯ࡵ࡯ࡥࡹ࡫ࠠหำฯ้ฮ࠭ሐ"),xN4fKmsnyM3Y2(u"ࠬ฿ัษ์ࠣࡅࡷࡧࡢࡪࡥࠪሑ"),OPEJxmUqr9wAX1i,rejRY592MzwLXCqP6kNISHByim+J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"࠭࡜࡯࡞ࡱࠫሒ")+li3O6w58Lr1AhRbzvXjeDU7MdH)
	if choice in [-LungQF89BqemOb32jJsZlW(u"࠵Ꮮ"),tRnTydV03Xfi7rbQ(u"࠵Ꮯ")]: return
	elif choice==AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"࠷Ꮰ"):
		import hhjfYLM6BP
		hhjfYLM6BP.P0dcoKng8EC5FlB9DtkW76()
		return
	pz3i5fjsvF6BgxwSeN9RIauZ = IZQbmFzLHDtXfc
	while pz3i5fjsvF6BgxwSeN9RIauZ:
		pz3i5fjsvF6BgxwSeN9RIauZ = ksTLSoVGg0ht
		message = AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"ࠧฦาสࠤ฾์ฯไุ่่๊ࠢษࠡใํࠤฬ๊รฮำไࠤฬู๊าสํอࠥ็วั้หࠤส๊้ࠡࠤศ฽ิอฯศฬࠣ์ฬา็สࠢๆ์ิ๐ࠢࠡอ่ࠤ฿๐ัࠡษ็า฼ࠦลๅ๋ࠣࠦࡆࡸࡩࡢ࡮ࠥࠤ࠳࠴ࠠฦาสࠤ้๋ࠠหฮาࠤฬ๊ฮุࠢࠥࡅࡷ࡯ࡡ࡭ࠤࠣๅ฿๐ัࠡษ็ะ้ีࠠฦๆ์ࠤศ๐ࠠอๆาࠤะอๆ๋ࠢไ๎์ࠦวๅะฺࠤࠧࡇࡲࡪࡣ࡯ࠦࠥ࠴࠮ࠡอ่ࠤอ฿ฯ่ษࠣ฾๏ืࠠศๆั฻ࠥหไ๊ࠢࠥࡅࡷ࡯ࡡ࡭ࠤࠣࡠࡳࠦลัษ่ࠣํำษࠡษ็้ๆอส๋ฯࠣห้฿ัษ์ฬࠤ้อࠠหฺ๊ี๊ࠥใࠡ࠰࠱ࠤฬึ็ษࠢศ่๎ࠦࠢฦ฻าหิอส๊ࠡสะ์ฯࠠไ๊า๎ࠧࠦ࠮࠯ࠢฮ้ࠥเ๊าࠢศ฽ิอฯศฬࠣห้๋่ใ฻ࠣห้าฺาษไ๎ࠥࡢ࡮࡝ࡰ๋้ࠣࠦสา์าࠤฬ๊ย็ࠢไฮาࠦࠢฦ฻าหิอส๊ࠡสะ์ฯࠠไ๊า๎ࠧࠦฟࠢࠩሓ")
		choice = UN8rA03xkWLCGzebyEoF9YDRKBwSMO(ObuCsdoDtKmhPLSMH8YGan(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨሔ"),WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠩࡈࡼ࡮ࡺࠠฯำ๋ะࠬሕ"),J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠪ࡝ࡪࡹࠠ็฻่ࠫሖ"),NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠫࡊࡴࡧ࡭࡫ࡶ࡬ࠥหๆอๆํึ๏࠭ሗ"),S5fhsRT8JV(u"ࠬ฿ฯๆࠢ฻๋ํืࠠศๆฦัึ็้ࠠษ็็ฯอศสࠢส่฾ืศ๋หࠪመ"),message,profile=tRnTydV03Xfi7rbQ(u"࠭ࡣࡰࡰࡩ࡭ࡷࡳ࡟࡮ࡧࡧ࡭ࡺࡳࡦࡰࡰࡷࠫሙ"))
		if choice==uxE8MyoTRglrcaiQf(u"࠲Ꮱ"):
			message = uxE8MyoTRglrcaiQf(u"ࠧࡊࡨࠣࡽࡴࡻࠠࡩࡣࡹࡩࠥࡶࡲࡰࡤ࡯ࡩࡲࠦࡷࡪࡶ࡫ࠤࡆࡸࡡࡣ࡫ࡦࠤࡱ࡫ࡴࡵࡧࡵࡷࠥࡺࡨࡦࡰࠣࡳࡵ࡫࡮ࠡࠤࡎࡳࡩ࡯ࠠࡊࡰࡷࡩࡷ࡬ࡡࡤࡧࠣࡗࡪࡺࡴࡪࡰࡪࡷࠧࠦࡡ࡯ࡦࠣࡧ࡭ࡧ࡮ࡨࡧࠣࡸ࡭࡫ࠠࡧࡱࡱࡸࠥࡺ࡯ࠡࠤࡄࡶ࡮ࡧ࡬ࠣࠢ࠱࠲ࠥࡏࡦࠡࡻࡲࡹࠥࡩࡡ࡯࡞ࠪࡸࠥ࡬ࡩ࡯ࡦࠣࠦࡆࡸࡩࡢ࡮ࠥࠤ࡫ࡵ࡮ࡵࠢࡷ࡬ࡪࡴࠠࡤࡪࡤࡲ࡬࡫ࠠࡵࡪࡨࠤࡸࡱࡩ࡯ࠢࡷࡳࠥࡧ࡮ࡺࠢࡲࡸ࡭࡫ࡲࠡࡵ࡮࡭ࡳࠦࡴࡩࡣࡷࠤ࡭ࡧࡶࡦࠢ࡟ࠦࡆࡸࡩࡢ࡮࡟ࠦࠥ࡬࡯࡯ࡶࠣ࠲࠳ࠦࡁ࡯ࡦࠣࡸ࡭࡫࡮ࠡࡥ࡫ࡥࡳ࡭ࡥࠡࡶ࡫ࡩࠥ࡬࡯࡯ࡶࠣࡸࡴࠦࠢࡂࡴ࡬ࡥࡱࠨࠠ࡝ࡰࠣࡍ࡫ࠦࡁࡳࡣࡥ࡭ࡨࠦࡋࡦࡻࡥࡳࡦࡸࡤࠡ࡫ࡶࠤࡳࡵࡴࠡࡣࡹࡥ࡮ࡲࡡࡣ࡮ࡨࠤ࠳࠴ࠠࡕࡪࡨࡲࠥࡵࡰࡦࡰࠣࠦࡐࡵࡤࡪࠢࡌࡲࡹ࡫ࡲࡧࡣࡦࡩ࡙ࠥࡥࡵࡶ࡬ࡲ࡬ࡹࠢࠡࡣࡱࡨࠥࡩࡨࡢࡰࡪࡩࠥࡺࡨࡦࠢࡵࡩ࡬࡯࡯࡯ࡣ࡯ࠤࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸࠦ࡜࡯࡞ࡱࠤࡉࡵࠠࡺࡱࡸࠤࡼࡧ࡮ࡵࠢࡱࡳࡼࠦࡴࡰࠢࡲࡴࡪࡴࠠࡵࡪࡨࠤࠧࡑ࡯ࡥ࡫ࠣࡍࡳࡺࡥࡳࡨࡤࡧࡪࠦࡓࡦࡶࡷ࡭ࡳ࡭ࡳࠣࠢࡂࠥࠬሚ")
			choice = UN8rA03xkWLCGzebyEoF9YDRKBwSMO(zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨማ"),iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠩࡈࡼ࡮ࡺࠠฯำ๋ะࠬሜ"),xN4fKmsnyM3Y2(u"ࠪ࡝ࡪࡹࠠ็฻่ࠫም"),On1WZJc6dtksqVNgSQ5GBAjuipe(u"ࠫࡆࡸࡡࡣ࡫ࡦࠤ฾ืศ๋ࠩሞ"),AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"ࠬࡓࡩࡴࡵ࡬ࡲ࡬ࠦࡁࡳࡣࡥ࡭ࡨࠦࡆࡰࡰࡷࠤࠫࠦࡔࡦࡺࡷࠫሟ"),message,profile=WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"࠭ࡣࡰࡰࡩ࡭ࡷࡳ࡟࡮ࡧࡧ࡭ࡺࡳࡦࡰࡰࡷࠫሠ"))
			if choice==NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"࠳Ꮲ"): pz3i5fjsvF6BgxwSeN9RIauZ = IZQbmFzLHDtXfc
		if choice==AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"࠳Ꮳ"): QaTY0hLgiBKvjSuz5tM()
	return
def HfjQK5N6osxkU1Pr7():
	NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠧ฻ษ็ฬฬࠦวๅีหฬࠥํ่ࠡ็้ࠤฬ๊ๅ้ไ฼ࠤฬ๊รึๆํࠤฬ๊ๅ฻าํࠤ้๊ศา่ส้ั่ࠦๅๆอว่ีࠠใ็ࠣฬฯฺฺ๋ๆࠣห้ืวษูࠣห้ึ๊ࠡๆสࠤ๏฿ๅๅࠢฮ้่ࠥๅࠡสศีุอไࠡ็ื็้ฯࠠฦๆ์ࠤฬ๊ๅษำ่ะ๋ࠥๆࠡษ็ๆฬฬๅสࠢส่ึฬ๊ิ์ฬࠤ้๊ศา่ส้ั࠭ሡ"))
	return
def aBGVuMD5P26sZxTNnvjYFA():
	KZ4oqDz5xgA2tkGcTaeQ1Lh3dp = aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠨ้ำหࠥอไษำ้ห๊าࠠๆะุูࠥ็โุࠢ็่฿ฯࠠศๆ฼ีอ๐ษ๊ࠡ็็๋ࠦ็ัษ่ࠣฬ๊ࠦๆ่฼ࠤํา่ะ่ࠢ์ฬู่ࠡใํ๋ฬࠦรโๆส้ࠥ๎ๅิๆึ่ฬะࠠๆฬิะ๊ฯࠠฤ๊้ࠣิฮไอหࠣษ้๏ࠠศๆ็฾ฮࠦวๅ฻ิฬ๏ฯ้ࠠษ็ํฺ๊ࠥศฬࠣหำื้๊ࠡ็หࠥ๐่อัࠣือฮࠠๅๆอ็ึอัࠨሢ")
	NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,KZ4oqDz5xgA2tkGcTaeQ1Lh3dp)
	return
def jPsBOcUapi4M9WmKq2J():
	KZ4oqDz5xgA2tkGcTaeQ1Lh3dp = Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠩส่ึ๎วษูࠣห้ฮื๋ศฬࠤ้อฺࠠๆสๆฮࠦไ่ษࠣฬฬ๊ศา่ส้ั่ࠦ฻ษ็ฬฬࠦวๅีหฬࠥํ่ࠡ็้ࠤฬ๊ๅ้ไ฼ࠤฬ๊รึๆํࠤฬ๊ๅ฻าํࠤ้๊ศา่ส้ั࠭ሣ")
	NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,KZ4oqDz5xgA2tkGcTaeQ1Lh3dp)
	return
def qicPOGE1hlnA2WjMCvYsDR():
	KZ4oqDz5xgA2tkGcTaeQ1Lh3dp = YnHG75e2QWwo(u"๋ࠪ๏ࠦำ๋ำไีฬะࠠๅษࠣ๎ุะื๋฻ࠣห้ฮั็ษ่ะࠥอำหะาห๊ํวࠡสึฬอࠦใ้่๊ห๋ࠥอๆ์ฬࠤ๊์ࠠศๆู่ิืࠠฤ๊ࠣฬาอฬสࠢศ่๎ࠦวีฬิห่ࠦัิ็ํࠤศ๎ࠠอัํำฮࠦร้ࠢ็หࠥ๐ูาใ๊หࠥอไษำ้ห๊าࠧሤ")
	NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,AiCor1fIVTDxQUWwHe9vPR7(u"ุࠫ๐ัโำสฮู๊ࠥวหࠣวํࠦๅอ้๋่ฮ࠭ሥ"),KZ4oqDz5xgA2tkGcTaeQ1Lh3dp)
	return
def cfZTLm6droAauNBjCe8tkE():
	KZ4oqDz5xgA2tkGcTaeQ1Lh3dp = YnHG75e2QWwo(u"ࠬอไิ์ิๅึอสࠡษ็฽ฬ๋ษ้ࠡํࠤุ๐ัโำสฮࠥิวาฮํอࠥ๎ฺ๋ำࠣฮฬฮูสࠢ็่๊๎โฺࠢส่ศ฻ไ๋๋ࠢะ๊๐ูࠡษ็้ํอโฺࠢอืฯิฯๆ้สࠤํ฿วะหࠣฮ่๎ๆࠡ็ฯห๋๐ษุ๊่ࠡฬ้ไ่ษࠣ็ะ๐ัสࠢ็ห๋ࠦวๅใํำ๏๎็ศฬࠣๅ๏ํวࠡว่หࠥฮื๋ศฬࠤศ๎ࠠๆ็้์฾ฯࠠฤ๊้ࠣาึ่โหࠣวํࠦแ๋้สࠤฺ๊ใๅหࠣั็๎โࠡษ็้้้๊ส࡞ࡱࡠࡳࡢ࡮ศๆึ๎ึ็ัศฬࠣห้ิวึห๋ࠣ๏ࠦำ๋ำไีฬะࠠหษห฽ฮࠦไๅ็๋ๆ฾ࠦวๅลุ่๏่ࠦๆีอาิ๋ษࠡใํࠤ๊๎วใ฻ࠣๆ้๐ไสࠢฯำฬฺ่ࠦษาอࠥะใ้่้ࠣิ็ฺ่หࠣห้ษฬาࠢฦ์ࠥ๐ๅๅๅ๊หࠥอไๆ๊ๅ฽ࠥอไฤื็๎ࠥ๎ไ่าสࠤๆํ๊ࠡฮํำฮࠦๆิสํหࠥ๎ำา์฼อࠥ๎ๅีษๆ่์อࠠใๆํ่ฮࠦฬะษࠪሦ")
	E3WHU2OdFfmX459c(vbYokBuWlxeLDcdVNM60(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ሧ"),OPEJxmUqr9wAX1i,KZ4oqDz5xgA2tkGcTaeQ1Lh3dp,S5fhsRT8JV(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪረ"))
	return
def XOyuUvch7S():
	rejRY592MzwLXCqP6kNISHByim = k5oIaYyp2mnrLK49qhzS(u"ࠨษหฮ฾ีฺ่้้ࠠࠣ็วหࠢส่ิ่ษࠡษ็฽ฬ๊๊สࠩሩ")
	li3O6w58Lr1AhRbzvXjeDU7MdH = HC9xWUMpBQJEuTteAqjd(u"ࠩสฬฯ฿ฯࠡ฻้ࠤ๊๊แศฬࠣว้ࠦ࡭࠴ࡷ࠻ࠫሪ")
	a3tzxkPUoO = ObuCsdoDtKmhPLSMH8YGan(u"ࠪหอะูะࠢ฼๊๋ࠥไโษอࠤฬ๊สฮ็ํ่ࠥ๎วๅัส์๋๊่ะࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠫራ")
	NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,rejRY592MzwLXCqP6kNISHByim,li3O6w58Lr1AhRbzvXjeDU7MdH,a3tzxkPUoO)
	return
def gfnlUZx9iFVL():
	li3O6w58Lr1AhRbzvXjeDU7MdH = AiCor1fIVTDxQUWwHe9vPR7(u"ࠫฬ๊ใศึ๋ࠣํࠦๅฯิ้ࠤ๊สโหࠢ็่๊฿ไ้็สฮࠥ๐ำหะา้์ࠦวๅสิ๊ฬ๋ฬࠡๆัึ๋ࠦีโฯสฮࠥอไฦ่อี๋๐ส๊ࠡิ์ฬฮืࠡษ็ๅ๏ี๊้้สฮ๊ࠥไ้ื๋่ࠥหไ๋้สࠤอูัฺหࠣ์อี่็ࠢศ๊ฯืๆ๋ฬࠣ์ฬ๊ศา่ส้ั๊ࠦๆีะ๋ฬࠦสๅไสส๏อࠠษ฻าࠤฬ์ส่ษฤࠤ฾๋ั่ษࠣ์ศ๐ึศࠢ฼๊ิࠦสฮัํฯࠥอไษำ้ห๊าࠠ࠯๋๋ࠢีอࠠศๆหี๋อๅอࠢํืฯิฯๆࠢึฬ฾ฯࠠฤ่๋ห฾ࠦไฺ็ิࠤฬ๊ใศึࠣ࠾ࠬሬ")
	li3O6w58Lr1AhRbzvXjeDU7MdH += zDek1IW37rq6UoKdwyRiAVpF(u"ࠬࡢ࡮࡝ࡰࠪር") + On1WZJc6dtksqVNgSQ5GBAjuipe(u"࠭࠱࠯ࠢฮหอะࠠๅๆุๅาอสࠡษ็ฮ๏ࠦๅฺำ๋ๅࠥษๆ่ษ่ࠣฬࠦสห฼ํีࠥ์็ศศํหࠥ๎ๅะฬ๊ࠤࠬሮ") + str(jCmv4M3HNPdyaLS/aar0zhDnJsOTP7EdgR16HIS29(u"࠹࠴Ꮴ")/aar0zhDnJsOTP7EdgR16HIS29(u"࠹࠴Ꮴ")/KNomgGw1kdMCBH(u"࠶࠹Ꮵ")/YnHG75e2QWwo(u"࠸࠶Ꮶ")) + TtyzcuW45VKA(u"ࠧࠡึ๊ีࠬሯ")
	li3O6w58Lr1AhRbzvXjeDU7MdH += ssELJkeScrtni2 + S5fhsRT8JV(u"ࠨ࠴࠱ࠤัีวู๋ࠡ๎้ࠦวๅ็าํ๊ࠥไึใะหฯࠦวๅ็ไีํ฼ࠠฤ่๊ห๊ࠥวࠡฬอ฾๏ื้ࠠ็าฮ์ࠦࠧሰ") + str(tvpq3ilsT1ZYAenaVj09BC2d/opyTNwHgfqbZREWKU(u"࠼࠰Ꮷ")/opyTNwHgfqbZREWKU(u"࠼࠰Ꮷ")/tRnTydV03Xfi7rbQ(u"࠲࠵Ꮸ")) + LJPOQNK1mcG(u"ࠩࠣ๎ํ๋ࠧሱ")
	li3O6w58Lr1AhRbzvXjeDU7MdH += ssELJkeScrtni2 + YnHG75e2QWwo(u"ࠪ࠷࠳ࠦื้์็ࠤฬ๊ๅะ๋่้ࠣ฻แฮษอࠤฬ๊ส๋้ࠢหิืวࠡฬอ฾๏ื้ࠠ็าฮ์ࠦࠧሲ") + str(r43t1YI9deXA5N/iRfoNckJs7Ibxzh5j92w8DSWF(u"࠷࠲Ꮹ")/iRfoNckJs7Ibxzh5j92w8DSWF(u"࠷࠲Ꮹ")/WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"࠴࠷Ꮺ")) + zDek1IW37rq6UoKdwyRiAVpF(u"ࠫࠥ๐่ๆࠩሳ")
	li3O6w58Lr1AhRbzvXjeDU7MdH += ssELJkeScrtni2 + dwiIAcPl04ey7Zv38Mz(u"ࠬ࠺࠮ࠡ็อ์ุ฽ࠠศๆ่ำ๎ࠦไๅืไัฬะࠠศๆอ๎่ࠥฯࠡฬอ฾๏ื้ࠠ็าฮ์ࠦࠧሴ") + str(K8DZxE74Afz52gBYbOMtpvql0RJma/SGazRxP3yBKZ15ILuch(u"࠹࠴Ꮻ")/SGazRxP3yBKZ15ILuch(u"࠹࠴Ꮻ")) + iRfoNckJs7Ibxzh5j92w8DSWF(u"࠭ࠠิษ฼อࠬስ")
	li3O6w58Lr1AhRbzvXjeDU7MdH += ssELJkeScrtni2 + AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"ࠧ࠶࠰ࠣๆฺ๐ัࠡษ็้ิ๏ࠠๅๆุๅาอสࠡษ็ฮ๏ࠦสห฼ํีࠥีวว็สࠤํ๋ฯห้ࠣࠫሶ") + str(AlfMBJhUD65to2WrQcb/aar0zhDnJsOTP7EdgR16HIS29(u"࠺࠵Ꮼ")/aar0zhDnJsOTP7EdgR16HIS29(u"࠺࠵Ꮼ")) + opyTNwHgfqbZREWKU(u"ࠨࠢึห฾ฯࠧሷ")
	li3O6w58Lr1AhRbzvXjeDU7MdH += ssELJkeScrtni2 + k5oIaYyp2mnrLK49qhzS(u"ࠩ࠹࠲ࠥาฯศࠢๅู๏ืࠠศๆ่ำ๎ࠦไๅืไัฬะࠠศๆอ๎ࠥะส฻์ิࠤ่ั๊าษࠣ์๊ีส่ࠢࠪሸ") + str(qIOfxknj8DiBYboGtQN4v/liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"࠻࠶Ꮽ")) + LJPOQNK1mcG(u"ࠪࠤิ่๊ใหࠪሹ")
	li3O6w58Lr1AhRbzvXjeDU7MdH += ssELJkeScrtni2 + J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠫ࠼࠴ࠠษั๋๊้ࠥวีࠢ็ฺ่็อศฬࠣห้ะ๊ࠡฬอ฾๏ืࠠษีิ฽ฮ่ࠦๆัอ๋ࠥ࠭ሺ") + str(fS25N8gAZxpbnLi3srX7PJ) + S5fhsRT8JV(u"ࠬࠦฯใ์ๅอࠬሻ")
	li3O6w58Lr1AhRbzvXjeDU7MdH += uxE8MyoTRglrcaiQf(u"࠭࡜࡯࡞ࡱࠫሼ") + rbUkdYi32PJaRtnxhDvQs(u"ࠧๆอ็ห࠿ࠦีโฯสฮ่่ࠥศศ่ࠤฬ๊รโๆส้ࠥ๎วๅ็ึุ่๊วห๋ࠢห้ำไใษอࠤ฾๋ั่ษࠣࠫሽ") + str(K8DZxE74Afz52gBYbOMtpvql0RJma/LJPOQNK1mcG(u"࠼࠰Ꮾ")/LJPOQNK1mcG(u"࠼࠰Ꮾ")) + NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠨࠢึห฾ฯࠠ࠯ࠢฦ้ฬࠦโ้ษษ้ࠥษๆ้ษ฼ࠤฬ๊แ๋ัํ์์อสࠡใ฼้ึํวࠡࠩሾ") + str(r43t1YI9deXA5N/LJPOQNK1mcG(u"࠼࠰Ꮾ")/LJPOQNK1mcG(u"࠼࠰Ꮾ")/WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"࠲࠵Ꮿ")) + aar0zhDnJsOTP7EdgR16HIS29(u"ࠩࠣว๏อๅࠡ࠰ࠣว๊อࠠๆๆไหฯࠦวๅใํำ๏๎ࠠโ฻่ี์อࠠࠨሿ") + str(AlfMBJhUD65to2WrQcb/LJPOQNK1mcG(u"࠼࠰Ꮾ")/LJPOQNK1mcG(u"࠼࠰Ꮾ")) + xN4fKmsnyM3Y2(u"ࠪࠤุอูสࠢไๆ฼ࠦ࠮ࠡล่หࠥ็อึࠢิๆ๊ࠦวๅวุำฬืࠠโ฻่ี์ࠦࠧቀ") + str(qIOfxknj8DiBYboGtQN4v/LJPOQNK1mcG(u"࠼࠰Ꮾ")) + k5oIaYyp2mnrLK49qhzS(u"ࠫࠥีโ๋ไฬࠤ࠳ࠦรๆษࠣๅา฻ࠠศึอีฬ้ࠠแࡋࡓࡘ࡛ࠦแฺ็ิ๋ࠥ࠭ቁ") + str(fS25N8gAZxpbnLi3srX7PJ) + AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"ࠬࠦฯใ์ๅอࠬቂ")
	E3WHU2OdFfmX459c(rbUkdYi32PJaRtnxhDvQs(u"࠭ࡲࡪࡩ࡫ࡸࠬቃ"),J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠧๆษ๋ࠣํࠦวๅๅสุࠥอไๆีอาิ๋ࠠโ์ࠣห้ฮั็ษ่ะࠬቄ"),li3O6w58Lr1AhRbzvXjeDU7MdH,Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫቅ"))
	return
def AZC2YaMr6U4nEXIVRQ0KF7PdwJt():
	KZ4oqDz5xgA2tkGcTaeQ1Lh3dp = nfg30bHwd4aNV12SR7UjFck(u"ࠩส่ๆอีๅหࠣฮ฾์๊ࠡ็ฯ่ิࠦศ็ใึࠤฬูๅ่ࠢส่ศ฻ไ๋๋ࠢห้์โุหࠣฮ฾์๊ࠡล้ࠤฬ๊วิ็ࠣห้ษีๅ์ࠣฮ๊ࠦสฺัํ่์่ࠦโษุ่ฮ่ࠦ็ไฺอࠥะู็๋้ࠣั๊ฯ๊ࠡอ้ࠥะูะ์็ࠤฬูๅ่๋ࠢฬิ๎ๆࠡ฻็ห๊ฯࠠห฻้๎๋ࠥไโࠢห๊ๆูࠠศี่๋ࠥอไฤื็๎ࠬቆ")
	NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,KZ4oqDz5xgA2tkGcTaeQ1Lh3dp)
	return
def EE347mhCvzWFp8():
	KZ4oqDz5xgA2tkGcTaeQ1Lh3dp = rbUkdYi32PJaRtnxhDvQs(u"ࠪษีอ้ࠠษฯ๋ฯ้ࠠๆึๆ่ฮࠦแ๋ࠢสู่ฮใส๋ࠢฮ๊ࠦอๅ้สࠤ࠳࠴࠮ࠡล๋ࠤฬ์ใࠡฬ฻๊ࠥษๆࠡษ็้ํู่ࠡษ็วฺ๊๊ࠡๅส๊ࠥ็ุ๊่่่๊ࠢษࠡ็วๆฯํ้ࠠฬ่ࠤา๊็ศࠢ࠱࠲࠳ࠦแฦา้ࠤัืศࠡ็ึั้ࠥวีࠢส่อืๆศ็ฯࠤ้้๊ࠡ์ๅ์๊ࠦวๅสิ๊ฬ๋ฬࠡสฺ่อࠦวๅืไัฮࠦวๅืะ๎าฯ้ࠠฬัึ๏์็ศࠢหำ้อࠠๆ่ࠣห้฻แฮหࠣห้่ฯ๋็ฬࠫቇ")
	NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,KZ4oqDz5xgA2tkGcTaeQ1Lh3dp)
	return
def g6iStVY1JjKexqQdayUTcO7XrE():
	KZ4oqDz5xgA2tkGcTaeQ1Lh3dp = vbYokBuWlxeLDcdVNM60(u"ࠫฬฺ๊าุ้๋ࠣࠦิ่ษาอࠥอไหึไ๎ึࠦ็ู้้ࠢฬ์ࠠึฯฬࠤํูั๋หࠣหู้๋ๅ๊่หฯࠦวๅ็อฬฬีไสࠢห๎๋ࠦวๅสิ๊ฬ๋ฬ๊ࠡส่๊๎โฺࠢสฺ่๊แา๋๋ࠢีอࠠศๆู้ฬ์ࠠ฻์ิࠤ๊฽ไ้สࠣ์้อࠠฮษฯอ๊ࠥ็ࠡ฻้ำࠥอไศฬุห้ࠦว้ࠢส่ึฮืࠡ็฼ࠤ๊๎วใ฻ࠣห้็๊ะ์๋๋ฬะࠠศๆุ่ๆืษࠨቈ")
	NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,KZ4oqDz5xgA2tkGcTaeQ1Lh3dp)
	return
def KnSgfAVLEzsOcF61uqo():
	NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,dwiIAcPl04ey7Zv38Mz(u"๊ࠬใ๋ࠢํ฽๊๊่ࠠาสࠤฬ๊ๆ้฻้๋ࠣࠦวๅใํำ๏๎็ศฬࠣࡠࡳ๊ࠦอสࠣฮๆ฿๊ๅࠢศฺฬ็ษࠡษึ้์อࠠ࡝ࡰࠣ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡣࡧࡥࡵࡺࡩࡷࡧࠪ቉"))
	bMoCAVnTStgik0(nfg30bHwd4aNV12SR7UjFck(u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠭ቊ"),IZQbmFzLHDtXfc)
	return
def x91DtoU6qZLEnN3lwGvab8py():
	KZ4oqDz5xgA2tkGcTaeQ1Lh3dp  = k5oIaYyp2mnrLK49qhzS(u"ࠧๆฦัีฬࠦโศ็อࠤอ฿ึࠡึิ็ฬะࠠศๆศ๊ฯืๆหࠢส่ิ๎ไ๋ࠢห์฻฿ฺࠠษษๆࠥ฼ฯࠡษ็ฬึอๅอ่ࠢฯ้ࠦใ้ัํࠤ้ะำๆฯࠣๅ็฽ࠠๅส฼ฺ๋ࠥำหะา้๏ࠦวๅ็อูๆำࠠษษ็ำำ๎ไࠡๆ่์ฬู่ࠡษ็ๅ๏ี๊้ࠩቋ")
	KZ4oqDz5xgA2tkGcTaeQ1Lh3dp += HC9xWUMpBQJEuTteAqjd(u"ࠨ๋๊ࠢฯ๐ฬสࠢ็๋ีอࠠศๆ฼หห่ࠠโษ้๋ࠥะโา์หหࠥาๅ๋฻ุ้ࠣะฮะ็ํࠤอืๆศ็ฯࠤ่๎ฯ๋ࠢ็หࠥ๐ำหูํ฽ํ์ࠠศๆาาํ๊ࠠๅฮ่๎฾ࠦๅ้ษๅ฽ࠥอไษำ้ห๊าࠠฮฬ์ࠤ๊฿ࠠศีอาิอๅࠨቌ")
	KZ4oqDz5xgA2tkGcTaeQ1Lh3dp += ssELJkeScrtni2+Gzygq01Kcb9U3+TtyzcuW45VKA(u"ࠩใࠤࠥ࡜ࡐࡏࠢࠣวํࠦࠠࡑࡴࡲࡼࡾࠦࠠฤ๊ࠣࠤࡉࡔࡓࠡࠢฦ์ࠥษ๊ࠡฯ็ࠤอูุ๊ࠢลาึ࠭ቍ")+kH8E2zqNyims6KJfI+ssELJkeScrtni2
	KZ4oqDz5xgA2tkGcTaeQ1Lh3dp += AiCor1fIVTDxQUWwHe9vPR7(u"ࠪࡠࡳ๊ว็๊ࠢิฬࠦไ็ࠢํั้ࠦวๅ็ื็้ฯ้ࠠว้้ฬࠦแใูࠣื๏่่ๆࠢหษฺ๊วฮࠢห฽฻ࠦวๅ็๋ห็฿้ࠠว฼ห็ฯࠠๆ๊สๆ฾ࠦวฯำ์ࠤ่อๆหࠢอ฽๊๊ࠠิษหๆฬࠦศะ๊้ࠤฺ๊วไๆࠪ቎")
	E3WHU2OdFfmX459c(nfg30bHwd4aNV12SR7UjFck(u"ࠫࡷ࡯ࡧࡩࡶࠪ቏"),OPEJxmUqr9wAX1i,KZ4oqDz5xgA2tkGcTaeQ1Lh3dp,dwiIAcPl04ey7Zv38Mz(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨቐ"))
	KZ4oqDz5xgA2tkGcTaeQ1Lh3dp = xN4fKmsnyM3Y2(u"࠭วๅ็๋ห็฿ࠠศๆอ๎ࠥะรฬำอࠤออไฺษษๆࠥ฿ๆะࠢห฽฻ࠦวๅ่สืࠥํ๊࠻ࠩቑ")
	KZ4oqDz5xgA2tkGcTaeQ1Lh3dp += ssELJkeScrtni2+Gzygq01Kcb9U3+S5fhsRT8JV(u"ࠧࡢ࡭ࡲࡥࡲࠦࠠࡦࡩࡼࡦࡪࡹࡴࠡࠢࡨ࡫ࡾࡨࡥࡴࡶࡹ࡭ࡵࠦࠠ࡮ࡱࡹ࡭ࡿࡲࡡ࡯ࡦࠣࠤࡸ࡫ࡲࡪࡧࡶ࠸ࡼࡧࡴࡤࡪࠣࠤࡸ࡮ࡡࡩ࡫ࡧ࠸ࡺ࠭ቒ")+kH8E2zqNyims6KJfI
	KZ4oqDz5xgA2tkGcTaeQ1Lh3dp += YnHG75e2QWwo(u"ࠨ࡞ࡱࡠࡳ࠭ቓ")+NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠩส่ิ๎ไࠡษ็ฮ๏ࠦสฤอิฮࠥฮวๅ฻สส็ูࠦ็ัࠣฬ฾฼ࠠศๆ้หุࠦ็๋࠼ࠪቔ")
	KZ4oqDz5xgA2tkGcTaeQ1Lh3dp += ssELJkeScrtni2+Gzygq01Kcb9U3+J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ฺ้ࠪืࠠࠡษ็็ํ๐สࠡࠢฦ้๏ืใศࠢࠣ็๋ีวࠡࠢไีู๋วࠡࠢส่๏๎ๆศ่ࠣࠤอืุ๊ษ้๎ฬࠦวๅว่หึอสࠡล็้ฬ์๊ศࠢิ์ุ๐วࠡษ็๎ฬฮว็ࠢสุ่฿่ะ์ฬࠤึ๎ๅศ่ํหࠥํ่ๅ่าหࠬቕ")+kH8E2zqNyims6KJfI
	KZ4oqDz5xgA2tkGcTaeQ1Lh3dp += NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠫࡡࡴ࡜࡯ࠩቖ")+TtyzcuW45VKA(u"ࠬอไๆสิ้ั่ࠦอัࠣ฻ึ๐โสࠢ็ฮัอ่ำࠢส่฾อฦใ๋่่ࠢ์็ศࠢอัฯอฬࠡฮ๊ำ้ࠥศ๋ำࠣ์ฬ๊ๅษำ่ะࠥ๐ุ็ࠢสฺ่๊ใๅหูࠣ฿๐ัส๋่ࠢฬࠦสิฬะๆࠥอไห฻หࠤๆหะศࠢ็ำ๏้ࠠๆึๆ่ฮࠦศศๆาาํ๊ࠠๅส฼ฺࠥอไๆ๊สๆ฾่ࠦฤ์ูห๊ࠥใ๋ࠢํฮ฻ำࠠฮฮ่ࠤฬ๊ๅีๅ็อࠥ࠭቗")
	KZ4oqDz5xgA2tkGcTaeQ1Lh3dp += Gzygq01Kcb9U3+tRnTydV03Xfi7rbQ(u"࠭วาี็ࠤึูวๅห้ࠣษีศสࠢศ่๎ࠦวๅ็หี๊า้ࠠษๆฮอࠦแ๋้สࠤฬูๅࠡส็ำ่่ࠦฤี่หฦࠦวๅ็๋ห็฿ࠠศๆอ๎๊ࠥวࠡฬึฮ฼๐ูࠡัั์้ํวࠨቘ")+kH8E2zqNyims6KJfI
	E3WHU2OdFfmX459c(On1WZJc6dtksqVNgSQ5GBAjuipe(u"ࠧࡳ࡫ࡪ࡬ࡹ࠭቙"),OPEJxmUqr9wAX1i,KZ4oqDz5xgA2tkGcTaeQ1Lh3dp,LungQF89BqemOb32jJsZlW(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫቚ"))
	return
def M1dhkqzX92uv7():
	NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,ObuCsdoDtKmhPLSMH8YGan(u"ࠩฮ่ฬัุࠠำๅࠤ้๊ส้ษุู่๋ࠥࠡษ็้อืๅอࠩቛ"),vbYokBuWlxeLDcdVNM60(u"ࠪวึูไࠡำึห้ฯࠠฤู๊้้ࠣไส่๊่ࠢࠥวว็ฬࠤึูววๆ๋ࠣีอࠠศๆหี๋อๅอ࡞ࡱࡠࡳษ่ࠡสสืฯิฯศ็ࠣห้็๊ิส๋็ࠥษฯ็ษ๊ࡠࡳ࠭ቜ")+Gzygq01Kcb9U3+WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࡫ࡧࡣࡦࡤࡲࡳࡰ࠴ࡣࡰ࡯࠲ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴ࠴࠳࠵࠽࠭ቝ")+kH8E2zqNyims6KJfI+LungQF89BqemOb32jJsZlW(u"ࠬࡢ࡮࡝ࡰฦ์ࠥฮวาีส่ࠥอ๊ๆ์็ࠤฬ๊้ࠡลา๊ฬํࠠࠡ࡞ࡱࠤࠬ቞")+Gzygq01Kcb9U3+f8Ja1q5eO02B(u"࠭ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷ࠷࠶࠱࠹ࡂࡪࡱࡦ࡯࡬࠯ࡥࡲࡱࠬ቟")+kH8E2zqNyims6KJfI)
	return
def DSvs0xBKOY7wRP4Cz19o35(showDialogs=IZQbmFzLHDtXfc):
	if not showDialogs: showDialogs = IZQbmFzLHDtXfc
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(fS25N8gAZxpbnLi3srX7PJ,LungQF89BqemOb32jJsZlW(u"ࠧࡈࡇࡗࠫበ"),k5oIaYyp2mnrLK49qhzS(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨࡼࡦࡳࡰ࡭ࡧ࠱ࡧࡴࡳࠧቡ"),cdZKMn68Pzg4,cdZKMn68Pzg4,ksTLSoVGg0ht,cdZKMn68Pzg4,zDek1IW37rq6UoKdwyRiAVpF(u"ࠩࡖࡉࡗ࡜ࡉࡄࡇࡖ࠱ࡍ࡚ࡔࡑࡕࡢࡘࡊ࡙ࡔ࠮࠳ࡶࡸࠬቢ"))
	if not Zty0AsgQ5jpkTh91OW.succeeded:
		ndEZ42G0lwDfY1TNyp = ksTLSoVGg0ht
		OO1KS902kyCdIta3RnLouAVxqPJW = DFr1WoZABRnSM79gObypfq(ksTLSoVGg0ht)
		SsziMZd5UbeL2NRxVpwjO(E7lrS9VXJF58d2NUAfkvxwjmHM,xxd7Xp5lvem(UkXlAzsMcamKJrEIgnxi6bWh)+xN4fKmsnyM3Y2(u"ࠪࠤࠥࠦࡈࡕࡖࡓࡗࠥࡌࡡࡪ࡮ࡨࡨࠥࠦࠠࡍࡣࡥࡩࡱࡀ࡛ࠨባ")+OO1KS902kyCdIta3RnLouAVxqPJW+YnHG75e2QWwo(u"ࠫࡢ࠭ቤ"))
		if showDialogs: NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠬ็อึࠢส่ฬะีศๆࠣห้๋ิโำࠣ࠲࠳࠴ࠠๆึๆ่ฮࠦ࠮࠯࠰ࠣห้อสึษ็ࠤฬ๊ๅีใิࠤ࠭อไาสฺࠤฬ๊ๅีใิ๊࠭ࠥวࠡ์฼ู้้ࠦ็ัๆࠤ฾๊้ࠡๅ๋ำ๏ࠦ࠮࠯࠰ࠣ์฾์ฯไࠢๆ์ิ๐ࠠ฻์ิࠤ็อฯาࠢ฼่๎ࠦวิฬัำฬ๋ࠠศๆ่์ฬู่ࠡษ็ู้็ัสࠩብ"))
	else:
		ndEZ42G0lwDfY1TNyp = IZQbmFzLHDtXfc
		if showDialogs: NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"࠭ฬ๋ัࠣะิอࠠ࠯࠰࠱ࠤฬ๊วหืส่ࠥอไๆึไีࠥ࠮วๅำห฻ࠥอไๆึไี࠮ฺ๊ࠦ็็ࠤ฾์ฯไ๋ࠢห้ฮั็ษ่ะ่ࠥวะำࠣ฽้๏ࠠศีอาิอๅࠡษ็้ํอโฺࠢสฺ่๊แาหࠪቦ"))
	if not ndEZ42G0lwDfY1TNyp and showDialogs: Rw01d2JuyE56Uf73gkMKpnVxN8sv()
	return ndEZ42G0lwDfY1TNyp
def Rw01d2JuyE56Uf73gkMKpnVxN8sv():
	NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,k5oIaYyp2mnrLK49qhzS(u"ࠧษ฻ูࠤฬ๊ๅ้ษๅ฽ࠥะอหษฯࠤึฮืࠡ็ืๅึ่ࠦใัࠣ๎่๎ๆࠡฮ๊หื้ࠠ฻์ิࠤ็อฯาࠢ฼่๎ࠦวๅำห฻ࠥอไๆึไีࠥษ่้้ࠡห่ࠦๅีๅ็อࠥ็๊ࠡึ๊หิฯࠠศๆอุๆ๐ัࠡษ็าฬ฻ษࠡสๆ์ิ๐ฺ่ࠠา็ࠥ฿ไๆษࠣห๋ํࠠห็ࠣๅา฻ࠠศๆหี๋อๅอࠢ฼่๎ࠦใ้ัํࠤฬ๊ลึัสีฬะࠠ࡝ࡰࠣ࠵࠼࠴࠶ࠡࠢࠩࠤࠥ࠷࠸࠯࡝࠳࠱࠾ࡣࠠࠡࠨࠣࠤ࠶࠿࠮࡜࠲࠰࠷ࡢ࠭ቧ"))
	qopESgGvKPIU6()
	return
def CB0jufwiVLMhAodO(JAYWBoz54tGw7O=cdZKMn68Pzg4):
	Yp6InTPViClk39UuNz = IZQbmFzLHDtXfc
	if k5oIaYyp2mnrLK49qhzS(u"ࠨࡡࡓࡖࡔࡈࡌࡆࡏࡢࠫቨ") not in JAYWBoz54tGw7O:
		Yp6InTPViClk39UuNz = ksTLSoVGg0ht
		tcxhXCe0Z6EaAyPu = UN8rA03xkWLCGzebyEoF9YDRKBwSMO(YnHG75e2QWwo(u"ࠩࡦࡩࡳࡺࡥࡳࠩቩ"),ObuCsdoDtKmhPLSMH8YGan(u"ࠪาึ๎ฬࠨቪ"),tRnTydV03Xfi7rbQ(u"ࠫสืำศๆู้้ࠣไสࠩቫ"),S5fhsRT8JV(u"ࠬหัิษ็ࠤึูวๅหࠪቬ"),OPEJxmUqr9wAX1i,uxE8MyoTRglrcaiQf(u"࠭็ๅࠢอี๏ีࠠฤ่ࠣฮึูไࠡำึห้ฯࠠฦๆ์ࠤฬ๊ๅษำ่ะࠥ࠴࠮ࠡล่ࠤฯื๊ะࠢฦ๊ࠥะัิๆู้้ࠣไส่ࠢ์ั๎ฯสࠢไ๎ࠥอไษำ้ห๊าࠠภࠩቭ"))
		if tcxhXCe0Z6EaAyPu in [-zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"࠲Ᏸ"),TtyzcuW45VKA(u"࠲Ᏹ")]: return
		elif tcxhXCe0Z6EaAyPu==opyTNwHgfqbZREWKU(u"࠴Ᏺ"):
			Yp6InTPViClk39UuNz = IZQbmFzLHDtXfc
			JAYWBoz54tGw7O = LungQF89BqemOb32jJsZlW(u"ࠧࡠࡒࡕࡓࡇࡒࡅࡎࡡࠪቮ")
	if Yp6InTPViClk39UuNz:
		if WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠨࡡࡓࡖࡔࡈࡌࡆࡏࡢࡓࡑࡊ࡟ࠨቯ") not in JAYWBoz54tGw7O:
			BoyIUWYSNR0jhDxQwvJriO4PkL = JyLdvftP3CU(aar0zhDnJsOTP7EdgR16HIS29(u"ࠩࡦࡩࡳࡺࡥࡳࠩተ"),cdZKMn68Pzg4,cdZKMn68Pzg4,opyTNwHgfqbZREWKU(u"ࠪ์฻฿ࠠศๆุ่่๊ษࠡใํࠤฬ๊ำอๆࠪቱ"),LJPOQNK1mcG(u"ࠫ็ฮไࠡวิืฬ๊ࠠศๆึะู้ࠦๅ์ๆࠤศ์ࠠหๅิีࠥࠦๆโีࠣห้็ูๅࠢส่ี๐ࠠฤ฻ฺห่ࠦวๅ็ื็้ฯࠠ࠯ࠢ็็๏๊ࠦห็ࠣฮุา๊ๅ๊ࠢิ์ࠦวๅ็ื็้ฯࠠโ์ࠣืั๊ࠠศๆฦา฼อม๊ࠡส่ฬูสฯัส้ࠥ࠴้ࠠสา์๋ࠦ็ัษࠣห้ะำอ์็ࠤุ๎แࠡฬิื้ࠦๅๅใ่ࠣฬࠦแศศาอ๋ࠥๆ่ࠢ็ษ๋ํࠠๅษࠣ๎าะ่๋ࠢ฼่๎ࠦวๅ็ื็้ฯࠠศๆอ๎ࠥะั๋ัࠣห๋ะࠠศๆศฬ้อฺࠡ฻้๋ฬࠦ࠮้ࠡ็ࠤ็๋สࠡสอ็ึอัࠡษ็ู้้ไสࠢยࠫቲ"))
			if BoyIUWYSNR0jhDxQwvJriO4PkL!=ObuCsdoDtKmhPLSMH8YGan(u"࠵Ᏻ"):
				NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,LJPOQNK1mcG(u"ࠬะๅࠡว็฾ฬวࠠศๆศีุอไࠨታ"),ObuCsdoDtKmhPLSMH8YGan(u"࠭ไๅลึๅࠥฮฯ้่ࠣฮุา๊ๅࠢสฺ่๊ใๅหࠣๅ๏ࠦำอๆࠣห้ษฮุษฤࠤํอไศีอาิอๅࠡใส๊ࠥอไๆสิ้ัࠦไศࠢํืฯ฽ฺ๊่ࠢ฽ึ็ษࠡษ็ู้้ไส๋่ࠢฬࠦอๅ้สࠤ้อๆࠡษ็้อืๅอࠢ็หࠥ๐ูๅ็ࠣห้เ๊ษࠩቴ"))
				return
	NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠧโ์ࠣหฺ้วีหࠣห้่วะ็ฬࠤาอ่ๅࠢฦ๊ࠥะใหสࠣีุอไสࠢศ่๎ࠦวๅ็หี๊า้ࠠษืีาࠦแ๋้สࠤฬ๊ๅีๅ็อࠥษ่ࠡษ็้ํ฼ฺ่๋ࠢษีอࠠฤำาฮࠥา่ศส้๋ࠣࠦวๅ็หี๊าࠠโวำ๊ࠥษใหสࠣ฽๋๎ว็ࠢหี๏ีใࠡล็ษ้้สา๊้๎ࠥอไฦ์่๎้่ࠦหาๆีࠥ๎ไศࠢอุ๊๏ࠠฤ่ࠣห้๋ศา็ฯࠤ้อ๋ࠠ฻็้ࠥอไ฻์หࠫት"))
	KZ4oqDz5xgA2tkGcTaeQ1Lh3dp = BzkmLuvJD9n25Pg(header=liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠨ࡙ࡵ࡭ࡹ࡫ࠠࡢࠢࡰࡩࡸࡹࡡࡨࡧࠣࠤࠥอใหสࠣีุอไสࠩቶ"),source=UkXlAzsMcamKJrEIgnxi6bWh)
	if not KZ4oqDz5xgA2tkGcTaeQ1Lh3dp: return
	if Yp6InTPViClk39UuNz: type = nfg30bHwd4aNV12SR7UjFck(u"ࠩࡓࡶࡴࡨ࡬ࡦ࡯ࠪቷ")
	else: type = nfg30bHwd4aNV12SR7UjFck(u"ࠪࡑࡪࡹࡳࡢࡩࡨࠫቸ")
	Q0AOX4cEgius9e = Kvtg8yxpJYBAlo(type,KZ4oqDz5xgA2tkGcTaeQ1Lh3dp,IZQbmFzLHDtXfc,cdZKMn68Pzg4,k5oIaYyp2mnrLK49qhzS(u"ࠫࡊࡓࡁࡊࡎ࠰ࡊࡗࡕࡍ࠮ࡗࡖࡉࡗ࡙ࠧቹ"),JAYWBoz54tGw7O)
	return
def aqX2hzYcnWeVjIT9UABk0s():
	JAYWBoz54tGw7O = NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠬํะศࠢส่อืๆศ็ฯࠤ้อ๋๊ࠠฯำ๊ࠥ็ࠡลํࠤุ๐ัโำࠣ๎ุะึ๋ใࠣว๏ࠦๅฮฬ๋๎ฬะ࠮ࠡษ็ฬึ์วๆฮࠣ๎ุะฮะ็ࠣีํอศุ๋ࠢฮ฻๋๊็ࠢ็้าะ่๋ษอࠤ๊ืแ้฻ฬࠤ฾๊้ࠡีํีๆืวหࠢัหึา๊ส࠰ࠣห้ฮั็ษ่ะࠥเ๊า่ࠢืษ๎ไࠡ฻้ࠤศ๐ࠠๆฯอ์๏อสࠡฬ่ࠤฯำๅ๋ๆ๊หࠥ฿ไ๊ࠢึ๎ึ็ัศฬࠣ์๊๎วใ฻ࠣาฬืฬ๋ห๊ࠣࠦ๎วใ฻ࠣ฻ึ็ࠠฬษ็ฯࠧ࠴ࠠอ็ํ฽ࠥอไฤี่หฦ่ࠦศๆ่หึ้วห๋ࠢห้฻่า๋ࠢห้๋ๆี๊ิหฯࠦ็๋ࠢัหฺฯࠠษษุัฬฮ็ศ࠰ࠣห้ฮั็ษ่ะ๊ࠥวࠡ์้ฮ์้ࠠฮไ๋ๆࠥอไุส฼ࠤํอไ็ึิࠤํ่ว็๊้ࠤฬ๊รๅใํอ๊ࠥไๆๆๆ๎ฮࠦวๅำๅ้๏ฯࠠࡅࡏࡆࡅࠥหะศࠢๆห๋ࠦไะ์ๆࠤู้่๊ࠢัหฺฯࠠษษ็ีํอศุ๋ࠢห้ะึศ็ํ๊ࠥอไฯษิะ๏ฯࠠโษ็ีัอมࠡษ็ฮํอีๅ่ࠢ฽ࠥหฯศำฬࠤ์ึ็ࠡษ็ื๏ืแาษอࠤํอไๆ๊สๆ฾ࠦวๅะสีั๐ษ࠯๊ࠢิฬࠦวๅสิ๊ฬ๋ฬ้๋ࠡࠤอฮำศูฬࠤ๊ะีโฯ่๊ࠣ๎วใ฻ࠣห้๎๊ษࠩቺ")
	E3WHU2OdFfmX459c(HC9xWUMpBQJEuTteAqjd(u"࠭ࡲࡪࡩ࡫ࡸࠬቻ"),liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠧฮไ๋ๆࠥอไุส฼ࠤํอไ็ึิࠤํ่ว็๊้ࠤฬ๊รๅใํอ๊ࠥไๆๆๆ๎ฮࠦวๅำๅ้๏ฯࠧቼ"),JAYWBoz54tGw7O,f8Ja1q5eO02B(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫች"))
	JAYWBoz54tGw7O = Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠩࡗ࡬࡮ࡹࠠࡱࡴࡲ࡫ࡷࡧ࡭ࠡࡦࡲࡩࡸࠦ࡮ࡰࡶࠣ࡬ࡴࡹࡴࠡࡣࡱࡽࠥࡩ࡯࡯ࡶࡨࡲࡹࠦ࡯࡯ࠢࡤࡲࡾࠦࡳࡦࡴࡹࡩࡷ࠴ࠠࡊࡶࠣࡳࡳࡲࡹࠡࡷࡶࡩࡸࠦ࡬ࡪࡰ࡮ࡷࠥࡺ࡯ࠡࡧࡰࡦࡪࡪࡤࡦࡦࠣࡧࡴࡴࡴࡦࡰࡷࠤࡹ࡮ࡡࡵࠢࡺࡥࡸࠦࡵࡱ࡮ࡲࡥࡩ࡫ࡤࠡࡶࡲࠤࡵࡵࡰࡶ࡮ࡤࡶࠥࡵ࡮࡭࡫ࡱࡩࠥࡼࡩࡥࡧࡲࠤ࡭ࡵࡳࡵ࡫ࡱ࡫ࠥࡹࡩࡵࡧࡶ࠲ࠥࡇ࡬࡭ࠢࡷࡶࡦࡪࡥ࡮ࡣࡵ࡯ࡸ࠲ࠠࡷ࡫ࡧࡩࡴࡹࠬࠡࡶࡵࡥࡩ࡫ࠠ࡯ࡣࡰࡩࡸ࠲ࠠࡴࡧࡵࡺ࡮ࡩࡥࠡ࡯ࡤࡶࡰࡹࠬࠡࡥࡲࡴࡾࡸࡩࡨࡪࡷࡩࡩࠦࡷࡰࡴ࡮࠰ࠥࡲ࡯ࡨࡱࡶࠤࡷ࡫ࡦࡦࡴࡨࡲࡨ࡫ࡤࠡࡪࡨࡶࡪ࡯࡮ࠡࡤࡨࡰࡴࡴࡧࠡࡶࡲࠤࡹ࡮ࡥࡪࡴࠣࡶࡪࡹࡰࡦࡥࡷ࡭ࡻ࡫ࠠࡰࡹࡱࡩࡷࡹࠠ࠰ࠢࡦࡳࡲࡶࡡ࡯࡫ࡨࡷ࠳ࠦࡔࡩࡧࠣࡴࡷࡵࡧࡳࡣࡰࠤ࡮ࡹࠠ࡯ࡱࡷࠤࡷ࡫ࡳࡱࡱࡱࡷ࡮ࡨ࡬ࡦࠢࡩࡳࡷࠦࡷࡩࡣࡷࠤࡴࡺࡨࡦࡴࠣࡴࡪࡵࡰ࡭ࡧࠣࡹࡵࡲ࡯ࡢࡦࠣࡸࡴࠦ࠳ࡳࡦࠣࡴࡦࡸࡴࡺࠢࡶ࡭ࡹ࡫ࡳ࠯࡚ࠢࡩࠥࡻࡲࡨࡧࠣࡥࡱࡲࠠࡤࡱࡳࡽࡷ࡯ࡧࡩࡶࠣࡳࡼࡴࡥࡳࡵ࠯ࠤࡹࡵࠠࡳࡧࡦࡳ࡬ࡴࡩࡻࡧࠣࡸ࡭ࡧࡴࠡࡶ࡫ࡩࠥࡲࡩ࡯࡭ࡶࠤࡨࡵ࡮ࡵࡣ࡬ࡲࡪࡪࠠࡸ࡫ࡷ࡬࡮ࡴࠠࡵࡪ࡬ࡷࠥࡶࡲࡰࡩࡵࡥࡲࠦࡡࡳࡧࠣࡰࡴࡩࡡࡵࡧࡧࠤࡸࡵ࡭ࡦࡹ࡫ࡩࡷ࡫ࠠࡦ࡮ࡶࡩࠥࡵ࡮ࠡࡶ࡫ࡩࠥࡽࡥࡣࠢࡲࡶࠥࡼࡩࡥࡧࡲࠤࡪࡳࡢࡦࡦࡧࡩࡩࠦࡡࡳࡧࠣࡪࡷࡵ࡭ࠡࡱࡷ࡬ࡪࡸࠠࡷࡣࡵ࡭ࡴࡻࡳࠡࡵ࡬ࡸࡪࡹ࠮ࠡࡋࡩࠤࡾࡵࡵࠡࡪࡤࡺࡪࠦࡡ࡯ࡻࠣࡰࡪ࡭ࡡ࡭ࠢ࡬ࡷࡸࡻࡥࡴࠢࡳࡰࡪࡧࡳࡦࠢࡦࡳࡳࡺࡡࡤࡶࠣࡥࡵࡶࡲࡰࡲࡵ࡭ࡦࡺࡥࠡ࡯ࡨࡨ࡮ࡧࠠࡧ࡫࡯ࡩࠥࡵࡷ࡯ࡧࡵࡷࠥ࠵ࠠࡩࡱࡶࡸࡪࡸࡳ࠯ࠢࡗ࡬࡮ࡹࠠࡱࡴࡲ࡫ࡷࡧ࡭ࠡ࡫ࡶࠤࡸ࡯࡭ࡱ࡮ࡼࠤࡦࠦࡷࡦࡤࠣࡦࡷࡵࡷࡴࡧࡵ࠲ࠬቾ")
	E3WHU2OdFfmX459c(vbYokBuWlxeLDcdVNM60(u"ࠪࡰࡪ࡬ࡴࠨቿ"),nfg30bHwd4aNV12SR7UjFck(u"ࠫࡉ࡯ࡧࡪࡶࡤࡰࠥࡓࡩ࡭࡮ࡨࡲࡳ࡯ࡵ࡮ࠢࡆࡳࡵࡿࡲࡪࡩ࡫ࡸࠥࡇࡣࡵࠢࠫࡈࡒࡉࡁࠪࠩኀ"),JAYWBoz54tGw7O,HC9xWUMpBQJEuTteAqjd(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨኁ"))
	return
def mtITFcNvSXoj():
	NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,Rsdai9xIEPcpuBMKOUwkTA05q(u"࠭วๅสิ๊ฬ๋ฬࠡๆสࠤ๏็อึࠢื๋ฬีษࠡษ็ฮู็๊าࠢ฼๊ิࠦวๅษอูฬ๊ࠠษษ็้ํอโฺࠢสฺ่๊แาหࠣ์้ํะศࠢไ๎ࠥำวๅ๋ࠢะํีࠠี้สำฮฺ๋ࠦำูࠣา๐อสࠢฦ์๋ࠥๆห้ํอࠥอไึๆสั๏ฯࠠฤ๊้ࠣื๐แสࠢไห๋ࠦ็ัษ่๋๊้ࠣࠦไไࠤฬ๊ัษูࠣห้๋ิโำࠣ์้์๋๊ࠠๅๅࠥ฿ๅๅࠢส่อืๆศ็ฯࠫኂ"))
	g6iStVY1JjKexqQdayUTcO7XrE()
	return
def XMOwzsNGlir9KADPqYuCefSvEB3Qx():
	WW4rwMqQPz7bcSd2GepfKEoFVBZL51 = {}
	eC6kOTUqF5bf,ppJL76Zuia5B,D8QGo9jUHse7RyEIdB = Pomx9JnfYbz1KEMlXgB(ksTLSoVGg0ht)
	rejRY592MzwLXCqP6kNISHByim,li3O6w58Lr1AhRbzvXjeDU7MdH,a3tzxkPUoO,gvzWimTak9Se5B6A3UF,xGwgfnohP8Bm13XFiTZvtKS,a19aLIydTPw0g58JOFNGuUk,iJbM7xNrB9oQvY = cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4
	rejRY592MzwLXCqP6kNISHByim = wr0HaqRdJ2D9LT7nSO1KMe38ly.join(ppJL76Zuia5B)
	li3O6w58Lr1AhRbzvXjeDU7MdH = wr0HaqRdJ2D9LT7nSO1KMe38ly.join(D8QGo9jUHse7RyEIdB)
	mhvudWp0tjBK2XE,Fg4SRQobvPVOtwhzjlsTr6uLJ1B8q,iU0uWGQIeDqm = eC6kOTUqF5bf
	for xgPSaoLzTlFtQD37M6HIEsWY,YkFpN1S270QERtviwnxKZ,yazncltHvZmX in Fg4SRQobvPVOtwhzjlsTr6uLJ1B8q:
		yazncltHvZmX = XTL0AWmwbDJfGRNi(yazncltHvZmX)
		yazncltHvZmX = yazncltHvZmX.strip(VBpIH2QSmvDGlA6TO3e).strip(s8fcjBCSMxzAIkZQbJPga(u"ࠧࠡ࠰ࠪኃ"))
		BWzYxop3Min = xgPSaoLzTlFtQD37M6HIEsWY.replace(SGazRxP3yBKZ15ILuch(u"ࠨࡒ࡜ࡘࡍࡕࡎࠨኄ"),YnHG75e2QWwo(u"ࠩࡄࡔࡎ࠭ኅ"))
		gvzWimTak9Se5B6A3UF += ssELJkeScrtni2+bxf7gZvNK29cEoiAIJlMq0dP+BWzYxop3Min+LungQF89BqemOb32jJsZlW(u"ࠪ࠾ࠥ࠭ኆ")+kH8E2zqNyims6KJfI+yazncltHvZmX+ssELJkeScrtni2
		if YkFpN1S270QERtviwnxKZ.isdigit(): WW4rwMqQPz7bcSd2GepfKEoFVBZL51[xgPSaoLzTlFtQD37M6HIEsWY] = int(YkFpN1S270QERtviwnxKZ)
	AACVESLfNMItWcGKRr3aeDsU5kid,QbOxKTUyNw,ttUBI4yQlmOn5VwFMxosHi8c7gXTD2 = list(zip(*Fg4SRQobvPVOtwhzjlsTr6uLJ1B8q))
	for xgPSaoLzTlFtQD37M6HIEsWY in sorted(LHJiIyoDNMjvUXzx):
		if xgPSaoLzTlFtQD37M6HIEsWY not in AACVESLfNMItWcGKRr3aeDsU5kid:
			gvzWimTak9Se5B6A3UF += ssELJkeScrtni2+bxf7gZvNK29cEoiAIJlMq0dP+xgPSaoLzTlFtQD37M6HIEsWY+k5oIaYyp2mnrLK49qhzS(u"ࠫ࠿ࠦࠧኇ")+kH8E2zqNyims6KJfI+liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"๊ࠬวࠡ์๋ะิ࠭ኈ")+ssELJkeScrtni2
			if xgPSaoLzTlFtQD37M6HIEsWY not in USuRxnPlV5.non_videos_actions: a3tzxkPUoO += wr0HaqRdJ2D9LT7nSO1KMe38ly+xgPSaoLzTlFtQD37M6HIEsWY
	for yazncltHvZmX,vDM613VAFznJXw90L4CW5abjiSZlI in mhvudWp0tjBK2XE:
		yazncltHvZmX = XTL0AWmwbDJfGRNi(yazncltHvZmX)
		xGwgfnohP8Bm13XFiTZvtKS += yazncltHvZmX+nfg30bHwd4aNV12SR7UjFck(u"࠭࠺ࠡࠩ኉")+Gzygq01Kcb9U3+str(vDM613VAFznJXw90L4CW5abjiSZlI)+kH8E2zqNyims6KJfI+U4ImogGksPlcBVfAb
	rejRY592MzwLXCqP6kNISHByim = rejRY592MzwLXCqP6kNISHByim.strip(VBpIH2QSmvDGlA6TO3e)
	li3O6w58Lr1AhRbzvXjeDU7MdH = li3O6w58Lr1AhRbzvXjeDU7MdH.strip(VBpIH2QSmvDGlA6TO3e)
	a3tzxkPUoO = a3tzxkPUoO.strip(VBpIH2QSmvDGlA6TO3e)
	BTPLQHzZNW = rejRY592MzwLXCqP6kNISHByim+uxE8MyoTRglrcaiQf(u"ࠧࠡࠢ࠱࠲ࠥࠦࠧኊ")+li3O6w58Lr1AhRbzvXjeDU7MdH
	v1TKQ5bVgmRyc  = aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠨ็๋ห็฿ࠠอ์าอฺฺࠥๅࠢส่อืๆศ็ฯࠤ๊์็ศࠢไ๎ิ๐่่ษอࠤๆ๐ࠠ࠴ࠢฦ๎ฬ๋ࠠศๆ่ห฻๐ษ่๊ࠡࠪࠥอไฤๅฮีࠥหไ๊ࠢส่ศ่ไࠪࠩኋ")+ssELJkeScrtni2+uxE8MyoTRglrcaiQf(u"๋๋ࠩีอࠠๆ฻้ห์ࠦลัษ่ࠣิ๐ใࠡ็ื็้ฯࠠโ์๊้ࠥ็็๋่๊ࠢࠥ฿ๆะๅࠣ์้๐ำห่๊ࠢࠥอไษำ้ห๊า้ࠠๆสࠤ๊์ࠠศๆ่์็฿ࠧኌ")+ssELJkeScrtni2
	v1TKQ5bVgmRyc += Gzygq01Kcb9U3+BTPLQHzZNW+kH8E2zqNyims6KJfI+J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠪࡠࡳࡢ࡮ࠨኍ")
	v1TKQ5bVgmRyc += HC9xWUMpBQJEuTteAqjd(u"๊ࠫ๎วใ฻่๊๊ࠣࠦี฼็ࠤ๊์็ศࠢส่อืๆศ็ฯࠤๆ๐ฯ๋๊๊หฯࠦแ๋ࠢ࠶ࠤศ๐วๆࠢส่๊อึ๋ห๊ࠣࠬืสษหࠣวอาฯ๋ࠫࠪ኎")+ssELJkeScrtni2+KNomgGw1kdMCBH(u"ࠬ๎็ัษ้ࠣ฾์ว่ࠢสัฯ๋วๅ๋ࠢะํีࠠๆึๆ่ฮูࠦ็ัๆࠤศ๎ࠠโ์ࠣห้๋่ใ฻ࠣวํࠦแ๋ࠢส่อืๆศ็ฯࠫ኏")+ssELJkeScrtni2
	a3tzxkPUoO = wr0HaqRdJ2D9LT7nSO1KMe38ly.join(sorted(a3tzxkPUoO.split(wr0HaqRdJ2D9LT7nSO1KMe38ly)))
	v1TKQ5bVgmRyc += Gzygq01Kcb9U3+a3tzxkPUoO+kH8E2zqNyims6KJfI
	KEP8MZbYylBAm0r2u9SxRQzO16Inf,t5jU8lzyED12VgMhqxi0,bbJ6QeIi2YZ85,yvIr2bEY5L6RxzUB = tRnTydV03Xfi7rbQ(u"࠵Ᏼ"),tRnTydV03Xfi7rbQ(u"࠵Ᏼ"),tRnTydV03Xfi7rbQ(u"࠵Ᏼ"),tRnTydV03Xfi7rbQ(u"࠵Ᏼ")
	all = WW4rwMqQPz7bcSd2GepfKEoFVBZL51[SGazRxP3yBKZ15ILuch(u"࠭ࡁࡍࡎࠪነ")]
	if YnHG75e2QWwo(u"ࠧࡑ࡛ࡗࡌࡔࡔࠧኑ") in list(WW4rwMqQPz7bcSd2GepfKEoFVBZL51.keys()): KEP8MZbYylBAm0r2u9SxRQzO16Inf = WW4rwMqQPz7bcSd2GepfKEoFVBZL51[rbUkdYi32PJaRtnxhDvQs(u"ࠨࡒ࡜ࡘࡍࡕࡎࠨኒ")]
	if On1WZJc6dtksqVNgSQ5GBAjuipe(u"ࠩࡌࡒࡘ࡚ࡁࡍࡎࠪና") in list(WW4rwMqQPz7bcSd2GepfKEoFVBZL51.keys()): t5jU8lzyED12VgMhqxi0 = WW4rwMqQPz7bcSd2GepfKEoFVBZL51[vbYokBuWlxeLDcdVNM60(u"ࠪࡍࡓ࡙ࡔࡂࡎࡏࠫኔ")]
	if nfg30bHwd4aNV12SR7UjFck(u"ࠫࡒࡋࡔࡓࡑࡓࡓࡑࡏࡓࠨን") in list(WW4rwMqQPz7bcSd2GepfKEoFVBZL51.keys()): bbJ6QeIi2YZ85 = WW4rwMqQPz7bcSd2GepfKEoFVBZL51[xN4fKmsnyM3Y2(u"ࠬࡓࡅࡕࡔࡒࡔࡔࡒࡉࡔࠩኖ")]
	if f8Ja1q5eO02B(u"࠭ࡒࡆࡒࡒࡗࠬኗ") in list(WW4rwMqQPz7bcSd2GepfKEoFVBZL51.keys()): yvIr2bEY5L6RxzUB = WW4rwMqQPz7bcSd2GepfKEoFVBZL51[S5fhsRT8JV(u"ࠧࡓࡇࡓࡓࡘ࠭ኘ")]
	QQEfSHPq6Fhzo = all-KEP8MZbYylBAm0r2u9SxRQzO16Inf-t5jU8lzyED12VgMhqxi0-bbJ6QeIi2YZ85-yvIr2bEY5L6RxzUB
	tYPfm3ISxD,BkfCKgt1TIX = iU0uWGQIeDqm[nnsBpJv6XL3OzHoe4Vuhr]
	tYPfm3ISxD,MuId2iPxTOk6 = iU0uWGQIeDqm[hiuZa0PIsErm6UC7]
	tZ5RXwDBd9yNbj6LQkPA18qHmK4 = BkfCKgt1TIX-MuId2iPxTOk6
	iJbM7xNrB9oQvY += bxf7gZvNK29cEoiAIJlMq0dP+str(MuId2iPxTOk6)+kH8E2zqNyims6KJfI+zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"ࠨษ็฽ิีࠠศๆะๆ๏่๊ࠡๆ็วัําสࠢ࠽ࠤࠬኙ")
	iJbM7xNrB9oQvY += ssELJkeScrtni2+bxf7gZvNK29cEoiAIJlMq0dP+str(tZ5RXwDBd9yNbj6LQkPA18qHmK4)+kH8E2zqNyims6KJfI+SGazRxP3yBKZ15ILuch(u"ࠩหหุะฮะษ่ࠤࡵࡸ࡯ࡹࡻࠣวํࠦࡶࡱࡰࠣ࠾ࠥ࠭ኚ")
	iJbM7xNrB9oQvY += ssELJkeScrtni2+bxf7gZvNK29cEoiAIJlMq0dP+str(BkfCKgt1TIX)+kH8E2zqNyims6KJfI+aar0zhDnJsOTP7EdgR16HIS29(u"ࠪห้฿ฯะࠢส่่๊๊ࠡๆฯ้๏฿ࠠศๆฦะ์ุษࠡ࠼ࠣࠫኛ")
	iJbM7xNrB9oQvY += ssELJkeScrtni2+bxf7gZvNK29cEoiAIJlMq0dP+str(len(iU0uWGQIeDqm[uxE8MyoTRglrcaiQf(u"࠸Ᏽ"):]))+kH8E2zqNyims6KJfI+liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠫ฾ีฯࠡษ็ำํ๊ࠠศๆอ๎ࠥ็๊่ษࠣวัําสࠢ࠽ࠤࡡࡴ࡜࡯ࠩኜ")
	for bQ6ElSoGTsM4CgPBF3hUXNWdyZHO,l5Q1RUnycofqBeJCTYLpD9iV7aghwb in iU0uWGQIeDqm[KNomgGw1kdMCBH(u"࠲᏶"):]:
		bQ6ElSoGTsM4CgPBF3hUXNWdyZHO = XTL0AWmwbDJfGRNi(bQ6ElSoGTsM4CgPBF3hUXNWdyZHO)
		bQ6ElSoGTsM4CgPBF3hUXNWdyZHO = bQ6ElSoGTsM4CgPBF3hUXNWdyZHO.strip(VBpIH2QSmvDGlA6TO3e).strip(vbYokBuWlxeLDcdVNM60(u"ࠬࠦ࠮ࠨኝ"))
		iJbM7xNrB9oQvY += bQ6ElSoGTsM4CgPBF3hUXNWdyZHO+vbYokBuWlxeLDcdVNM60(u"࠭࠺ࠡࠩኞ")+Gzygq01Kcb9U3+str(l5Q1RUnycofqBeJCTYLpD9iV7aghwb)+kH8E2zqNyims6KJfI+dwiIAcPl04ey7Zv38Mz(u"ࠧࠡࠢࠣࠫኟ")
	a19aLIydTPw0g58JOFNGuUk += bxf7gZvNK29cEoiAIJlMq0dP+str(QQEfSHPq6Fhzo)+kH8E2zqNyims6KJfI+opyTNwHgfqbZREWKU(u"ࠨใํำ๏๎็ศฬࠣหูะฺๅฬࠣ࠾ࠥ࠭አ")
	a19aLIydTPw0g58JOFNGuUk += ssELJkeScrtni2+bxf7gZvNK29cEoiAIJlMq0dP+str(KEP8MZbYylBAm0r2u9SxRQzO16Inf)+kH8E2zqNyims6KJfI+NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ฺ่ࠩออสࠡีํีๆืࠠࡂࡒࡌࠤ࠿ࠦࠧኡ")
	a19aLIydTPw0g58JOFNGuUk += ssELJkeScrtni2+bxf7gZvNK29cEoiAIJlMq0dP+str(yvIr2bEY5L6RxzUB)+kH8E2zqNyims6KJfI+AiCor1fIVTDxQUWwHe9vPR7(u"ࠪ฻้ฮวหࠢึ๎ึ็ัࠡษ็ุ้ะ่ะ฻ࠣ࠾ࠥ࠭ኢ")
	a19aLIydTPw0g58JOFNGuUk += ssELJkeScrtni2+bxf7gZvNK29cEoiAIJlMq0dP+str(t5jU8lzyED12VgMhqxi0)+kH8E2zqNyims6KJfI+aar0zhDnJsOTP7EdgR16HIS29(u"ࠫฯัศ๋ฬࠣฮ฼ฮ๊ใࠢๆ์ิ๐ฺࠠ็สำࠥࡀࠠࠨኣ")
	a19aLIydTPw0g58JOFNGuUk += ssELJkeScrtni2+bxf7gZvNK29cEoiAIJlMq0dP+str(bbJ6QeIi2YZ85)+kH8E2zqNyims6KJfI+k5oIaYyp2mnrLK49qhzS(u"ࠬะหษ์อࠤั๊ฯࠡ็อีํฮ่ๅีࠣ฽๊อฯࠡ࠼ࠣࠫኤ")
	a19aLIydTPw0g58JOFNGuUk += ssELJkeScrtni2+bxf7gZvNK29cEoiAIJlMq0dP+str(len(mhvudWp0tjBK2XE))+kH8E2zqNyims6KJfI+HC9xWUMpBQJEuTteAqjd(u"࠭ฯ้ๆุࠣ฿๊สࠡใํำ๏๎็ศฬࠣ࠾ࠥ࠭እ")
	a19aLIydTPw0g58JOFNGuUk += opyTNwHgfqbZREWKU(u"ࠧ࡝ࡰ࡟ࡲࠬኦ")+xGwgfnohP8Bm13XFiTZvtKS
	E3WHU2OdFfmX459c(KNomgGw1kdMCBH(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨኧ"),NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠩ฼ำิࠦวๅใํำ๏๎็ศฬࠣห้ะ๊ࠡึ฽่์อ่ࠠาสࠤฬ๊ศา่ส้ัࠦแ๋ࠢ࠶ࠤศ๐วๆࠢส่๊อึ๋หࠣๅ๏ࠦวๅ฻ส่๊ࠦใๅ้ࠪከ"),a19aLIydTPw0g58JOFNGuUk,Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭ኩ"))
	E3WHU2OdFfmX459c(NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫኪ"),SGazRxP3yBKZ15ILuch(u"๋่ࠬศไ฼ࠤฬฺส฻ๆอࠤๆ๐ࠠ࠴ࠢฦ๎ฬ๋ࠠศๆ่ห฻๐ษࠡใํࠤฬู๊ศๆ่ࠤ่๊็ࠨካ"),v1TKQ5bVgmRyc,S5fhsRT8JV(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩኬ"))
	E3WHU2OdFfmX459c(Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠧ࡭ࡧࡩࡸࠬክ"),S5fhsRT8JV(u"ࠨล฼่๎ࠦวๅั๋่ࠥอไห์ࠣหุะฮะ็อࠤฬ๊ศา่ส้ัࠦแ๋ࠢ࠶ࠤศ๐วๆࠢส่๊อึ๋หࠪኮ"),gvzWimTak9Se5B6A3UF,zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࡤࡲ࡯࡯ࡩࠪኯ"))
	XfABsbKWoLhI(IZQbmFzLHDtXfc)
	return
def ETFCM1HDOkwapjNQWA():
	KZ4oqDz5xgA2tkGcTaeQ1Lh3dp = nfg30bHwd4aNV12SR7UjFck(u"๋ࠪีอࠠศๆหี๋อๅอࠢํ฽๊๊ࠠศใู่ࠥฮวิฬัำฬ๋ࠠอๆาࠤ่๎ฯ๋ࠢࠫࡏࡴࡪࡩࠡࡕ࡮࡭ࡳ࠯ࠠศๆำ๎ࠥอำๆ้࡟ࡲࠬኰ")+bxf7gZvNK29cEoiAIJlMq0dP+KNomgGw1kdMCBH(u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪ኱")+kH8E2zqNyims6KJfI+NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠬࡢ࡮࡝ࡰ࡟ࡲࠥ๎ๅๆๅ้ࠤฯัศ๋ฬ๊ࠤออำหะาห๊ࠦๅิฬ๋ำ฾ูࠦๆษาࠤࡊࡓࡁࡅࠢࡕࡩࡵࡵࡳࡪࡶࡲࡶࡾࠦร้ࠢอั๊๐ไ่่๊ࠢࡡࡴࠧኲ")+bxf7gZvNK29cEoiAIJlMq0dP+KNomgGw1kdMCBH(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡶࡪࡶ࡯࠯ࡷ࡮࠲ࡹࡵࠧኳ")+kH8E2zqNyims6KJfI+liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠧ࡝ࡰ࡟ࡲࡡࡴ่ࠠา๊ࠤฬ๊ัิษ็อࠥ๎ฺ๋ำ๊ห้ࠥห๋ำ้ࠣํา่ะหࠣๅ๏ࠦโศศ่อࠥ฻๊ศ่ฬࠤฬ๊ศา่ส้ั่ࠦศๆ่ึ๏ีࠠฤ์ูห๋่ࠥอ๊าࠤๆ๐ࠠใษษ้ฮࠦๅฺๆ๋้ฬะࠠศๆหี๋อๅอࠩኴ")
	E3WHU2OdFfmX459c(tRnTydV03Xfi7rbQ(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨኵ"),OPEJxmUqr9wAX1i,KZ4oqDz5xgA2tkGcTaeQ1Lh3dp,aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬ኶"))
	return
def KRoBLbHzmIuPnqw():
	KZ4oqDz5xgA2tkGcTaeQ1Lh3dp = aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠪห้ืวษูํ๊ࠥษฯ็ษ๊ࠤๆ๐็ๆษࠣฮ฼ฮ๊ใࠢๆ์ิ๐ฺࠠ็สำࠥ๎็้ࠢ฼ฬฬืษࠡ฻้ࠤฯัศ๋ฬࠣ็ฬ๋ไࠡษ๋ฮํ๋วห์ๆ๎๊ࠥศา่ส้ัࠦใ้ัํࠤํู๋่ࠢสฺฬ็ษࠡ฻่หิࠦไๅใํำ๏๎็ศฬࠣห้฿ัษ์ฬࠤํู๋่ࠢสฺฬ็ษࠡฮ็ำ๋ࠥสา๊ห์ฺู้ࠠ็สำࠥ๎ๅฺ้ࠣห฻อแส่ࠢืฯ๎ฯฺࠢ฼้ฬี้ࠠใํ๋ࠥษ๊ืษࠣะ๊๐ูࠡษ฼ำฬีสࠡๅ๋ำ๏ࠦวๅ็ฺ่ํฮษࠡๆ฼้้ࠦศา่ส้ัูࠦๆษาࠤํ้ไ่ษࠣฮฯ๋ࠠศ๊อ์๊อส๋ๅํหࠥ๎ไศࠢอัฯอฬࠡลํࠤ๋๎ูࠡ็้ࠤฬ๊ฮษำฬࠤๆ๐ࠠไ๊า๎ࠥษ่ࠡษ็าอืษࠡใํࠤฯัศ๋ฬࠣว฻อแศฬࠣ็ํี๊ࠨ኷")+ssELJkeScrtni2+Gzygq01Kcb9U3+USuRxnPlV5.SITESURLS[tRnTydV03Xfi7rbQ(u"ࠫࡐࡕࡄࡊࡇࡐࡅࡉࡥࡁࡑࡒࠪኸ")][nnsBpJv6XL3OzHoe4Vuhr]+kH8E2zqNyims6KJfI+s8fcjBCSMxzAIkZQbJPga(u"ࠬࠦࠠࠡࠢฦ์ࠥࠦࠠࠡࠩኹ")+Gzygq01Kcb9U3+USuRxnPlV5.SITESURLS[aar0zhDnJsOTP7EdgR16HIS29(u"࠭ࡋࡐࡆࡌࡉࡒࡇࡄࡠࡃࡓࡔࠬኺ")][hiuZa0PIsErm6UC7]+kH8E2zqNyims6KJfI
	KZ4oqDz5xgA2tkGcTaeQ1Lh3dp += opyTNwHgfqbZREWKU(u"ࠧ࡝ࡰ࡟ࡲࡡࡴวๅำสฬ฼ࠦระ่ส๋ࠥํ่ࠡษ็ืํืำࠡษ็ิ๏๊ࠦฮฬสะ์ࠦๅะ์ิࠤ๊๊แศฬࠣ็ํี๊ࠡๆอฯอ๐สࠡสิ๊ฬ๋ฬࠡ฻่หิࠦศศๆฺี๏่ษࠡษ็ฮ็๊๊ะ์ฬࠤฬ๊โะ์่อࡡࡴࠧኻ")+Gzygq01Kcb9U3+USuRxnPlV5.SITESURLS[KNomgGw1kdMCBH(u"ࠨࡍࡒࡈࡎࡥࡓࡐࡗࡕࡇࡊ࡙ࠧኼ")][nnsBpJv6XL3OzHoe4Vuhr]+kH8E2zqNyims6KJfI+k5oIaYyp2mnrLK49qhzS(u"ࠩࠣࠤࠥࠦร้ࠢࠣࠤࠥ࠭ኽ")+Gzygq01Kcb9U3+USuRxnPlV5.SITESURLS[LungQF89BqemOb32jJsZlW(u"ࠪࡏࡔࡊࡉࡠࡕࡒ࡙ࡗࡉࡅࡔࠩኾ")][hiuZa0PIsErm6UC7]+kH8E2zqNyims6KJfI
	KZ4oqDz5xgA2tkGcTaeQ1Lh3dp += iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠫࡡࡴ࡜࡯࡞ࡱะ๊๐ูࠡ็็ๅฬะฺࠠ็สำ๋่ࠥอ๊าอࠥ็๊ࠡษ็้ํู่ࠡลา๊ฬํࠧ኿")+ssELJkeScrtni2+Gzygq01Kcb9U3+USuRxnPlV5.SITESURLS[xN4fKmsnyM3Y2(u"ࠬࡌࡉࡍࡇࡖࡣࡘࡕࡕࡓࡅࡈࡗࠬዀ")][nnsBpJv6XL3OzHoe4Vuhr]+kH8E2zqNyims6KJfI
	E3WHU2OdFfmX459c(J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"࠭ࡣࡦࡰࡷࡩࡷ࠭዁"),On1WZJc6dtksqVNgSQ5GBAjuipe(u"ࠧศๆ่์ฬู่ࠡษ็ีุ๋๊สࠢ็ฬึ์วๆฮࠣ฽๊อฯࠡๆ็ๅ๏ี๊้้สฮࠥอไฺำห๎ฮ࠭ዂ"),KZ4oqDz5xgA2tkGcTaeQ1Lh3dp,HC9xWUMpBQJEuTteAqjd(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫዃ"))
	return
def GpWwn7TQh0KIN2zCxE4jt8aPybe(C3aoWsk19ZLFJUfEypzrhQ8udvDi):
	bu6LzUQF7K.executebuiltin(dwiIAcPl04ey7Zv38Mz(u"ࠩࡄࡨࡩࡵ࡮࠯ࡑࡳࡩࡳ࡙ࡥࡵࡶ࡬ࡲ࡬ࡹࠨࠨዄ")+C3aoWsk19ZLFJUfEypzrhQ8udvDi+liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠪ࠭ࠬዅ"), IZQbmFzLHDtXfc)
	return
def QaTY0hLgiBKvjSuz5tM():
	dNosE0aMjWHXP4(On1WZJc6dtksqVNgSQ5GBAjuipe(u"ࠫࡸࡺ࡯ࡱࠩ዆"))
	bu6LzUQF7K.executebuiltin(SGazRxP3yBKZ15ILuch(u"ࠧࡇࡣࡵ࡫ࡹࡥࡹ࡫ࡗࡪࡰࡧࡳࡼ࠮ࡉ࡯ࡶࡨࡶ࡫ࡧࡣࡦࡕࡨࡸࡹ࡯࡮ࡨࡵࠬࠦ዇"))
	return
def nkHA2xw5pV84e9GMjO():
	bu6LzUQF7K.executebuiltin(tRnTydV03Xfi7rbQ(u"࠭ࡁࡥࡦࡲࡲ࠳ࡕࡰࡦࡰࡖࡩࡹࡺࡩ࡯ࡩࡶࠬ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡤࡨࡦࡶࡴࡪࡸࡨ࠭ࠬወ"), IZQbmFzLHDtXfc)
	return
def sstxuy7NoaAwKPmQ6SJGzXZE():
	NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,rbUkdYi32PJaRtnxhDvQs(u"ࠧๅ็ึั๋ࠥอห๊ํหฯࠦโศศ่อࠥ࠴ࠠศา๊ฬࠥหไ๊ࠢส่็อฦๆหࠣห้ะ๊ࠡฬิ๎ิࠦๅิฯ๊หࠥ๎ไศࠢอำำ๊ࠠฦๆํ๋ฬ่ࠦๅๅ้ࠤออำหะาห๊ࠦࠢศๆ่หํูࠢࠡล๋ࠤࠧอไา์่์ฯࠨࠠศุ฽฻ࠥ฿ไ๊ࠢส่ืืࠠอ้ฬࠤฬ๊๊ๆ์้ࠤศ๎ࠠศีอาิ๋ࠠࠣษ็็๏ฮ่าัࠥࠤํอึ฻ูࠣ฽้๏ࠠฮำไࠤࠧࡉࠢࠡล๋ࠤ฾๊้ࠡษู฾฼ูࠦๅ๋ࠣึึࠦࠢศๆๅหห๋ษࠣࠢส่ี๐ࠠโ์ࠣะ์ฯࠠศๆํ้๏์ࠧዉ"))
	return
def dd4o57hHAa9gtRkUmb1():
	NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,TtyzcuW45VKA(u"ࠨๆ็ฮ฾อๅๅ่ࠢ฽ࠥอไๆใู่ฮࠦ࠮ࠡษำ๋อࠦลๅ๋ࠣห้ืวษูࠣห้ึ๊ࠡฬิ๎ิࠦลืษไฮ์ࠦร้่ࠢืาํࠠๆ่ࠣࠤ็อฦๆหࠣห้๋แืๆฬࠤํ๊ใ็ࠢ็หࠥะๆใำࠣ฽้๐็๊ࠡ็หࠥะิ฻ๆ๊ࠤ࠳่ࠦษษึฮำีวๆࠢࠥห้๋ว้ีࠥࠤศ๎ࠠࠣษ็ี๏๋่หࠤࠣห฻เืࠡ฻็ํࠥอไำำࠣะ์ฯࠠศๆํ้๏์ࠠ࠯๋ࠢว๊อࠠษษึฮำีวๆࠢࠥห้้๊ษ๊ิำࠧࠦแศุ฽฻ࠥ฿ไ๊ࠢะีๆࠦࠢࡄࠤࠣวํูࠦๅ๋ࠣึึࠦࠢศๆๅหห๋ษࠣࠢส่ี๐ࠠโ์ࠣะ์ฯࠠศๆํ้๏์ࠠ࠯๋๊ࠢๆูࠠศๆๆ่ฬ๋้ࠠษ็฻ึ๐โสࠢ฼๊ิࠦวๅฬ฼ห๊๊ࠠๆ฻้ࠣาะ่๋ษอࠤ็๎วว็ࠣห้๋แืๆฬࠫዊ"))
	return
def GSWdnriNYbUHlJh1pVFj2moLPq(bloycijTZrtE=YnHG75e2QWwo(u"ࠩࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄࠨዋ"),showDialogs=IZQbmFzLHDtXfc):
	cEdehCpqROmNkiKTt2Hu5XQ3 = bu6LzUQF7K.executeJSONRPC(ObuCsdoDtKmhPLSMH8YGan(u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡖࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡌ࡫ࡴࡔࡧࡷࡸ࡮ࡴࡧࡗࡣ࡯ࡹࡪࠨࠬࠣ࡫ࡧࠦ࠿࠷ࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡸ࡫ࡴࡵ࡫ࡱ࡫ࠧࡀࠢ࡭ࡱࡲ࡯ࡦࡴࡤࡧࡧࡨࡰ࠳ࡹ࡫ࡪࡰࠥࢁࢂ࠭ዌ"))
	data = sJB3aL8gGVrRU.loads(cEdehCpqROmNkiKTt2Hu5XQ3)
	AVn6SlE0FcpaJybTidGO8ueCW = data[aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠫࡷ࡫ࡳࡶ࡮ࡷࠫው")][LungQF89BqemOb32jJsZlW(u"ࠬࡼࡡ࡭ࡷࡨࠫዎ")]
	if xicJPb0AW1nsRfH3kCv7: AVn6SlE0FcpaJybTidGO8ueCW = AVn6SlE0FcpaJybTidGO8ueCW.encode(vczMIlkCAh2u10B3)
	if showDialogs:
		BoyIUWYSNR0jhDxQwvJriO4PkL = JyLdvftP3CU(cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,YnHG75e2QWwo(u"࠭็ๅࠢอี๏ีࠠห฼ํ๎ึࠦฬๅัࠣࠫዏ")+AVn6SlE0FcpaJybTidGO8ueCW+zDek1IW37rq6UoKdwyRiAVpF(u"ࠧࠡษ็ิ๏ࠦๅิฬัำ๊ࠦวๅฤ้ࠤๆ๐ࠠไ๊า๎ࠥหไ๊ࠢส่ส฻ฯศำࠣห้ษฮ๋ำ่ࠣั๊ฯࠡࠩዐ")+bloycijTZrtE+tRnTydV03Xfi7rbQ(u"ࠨࠢยࠥࠬዑ"))
		if BoyIUWYSNR0jhDxQwvJriO4PkL!=vbYokBuWlxeLDcdVNM60(u"࠲᏷"): return ksTLSoVGg0ht
	Q0AOX4cEgius9e,aOoLTMtGmxAVin80FXlsQwvIedE,zQFv1b9GeBNfrmi8OA5L = OnpfSh5RvPUTjdD7BI4uJeo(bloycijTZrtE,ksTLSoVGg0ht,ksTLSoVGg0ht)
	if Q0AOX4cEgius9e:
		if showDialogs: NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,zDek1IW37rq6UoKdwyRiAVpF(u"ࠩอ้ฯูࠦๆๆํอࠥะหษ์อࠤฬ๊ฬๅัࠣห้าฯ๋ัࠣ์์๎ࠠอษ๊ึ๊ࠥไศีอาิอๅࠡ࠰ࠣืํ็๋ࠠฬ่ࠤฬ๊ย็ࠢอ฾๏๐ัࠡว฼ำฬีวหࠢๆ์ิ๐ࠠๅๅํࠤ๏ูสฺ็็ࠤฬ๊ฬๅัࠣห้าฯ๋ัࠣฬิ๊วࠡ็้ࠤฬ๊โะ์่ࠫዒ"))
		bXWSJeh38Onkra02 = bu6LzUQF7K.executeJSONRPC(liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡖࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡘ࡫ࡴࡔࡧࡷࡸ࡮ࡴࡧࡗࡣ࡯ࡹࡪࠨࠬࠣ࡫ࡧࠦ࠿࠷ࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡸ࡫ࡴࡵ࡫ࡱ࡫ࠧࡀࠢ࡭ࡱࡲ࡯ࡦࡴࡤࡧࡧࡨࡰ࠳ࡹ࡫ࡪࡰࠥ࠰ࠧࡼࡡ࡭ࡷࡨࠦ࠿ࠨࠧዓ")+bloycijTZrtE+iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠫࠧࢃࡽࠨዔ"))
		Q0AOX4cEgius9e = IZQbmFzLHDtXfc if S5fhsRT8JV(u"ࠬࡕࡋࠨዕ") in bXWSJeh38Onkra02 else ksTLSoVGg0ht
		bD7kJZhMCdaqF68P45KlNIgO1.sleep(WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"࠳ᏸ"))
		bu6LzUQF7K.executebuiltin(zDek1IW37rq6UoKdwyRiAVpF(u"࠭ࡓࡦࡰࡧࡇࡱ࡯ࡣ࡬ࠪ࠴࠵࠮࠭ዖ"))
	elif showDialogs: NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,nfg30bHwd4aNV12SR7UjFck(u"ࠧๅๆฦืๆࠦแีๆอࠤ฾๋ไ๋หࠣฮะฮ๊ห๋ࠢฮๆ฿๊ๅࠢส่ั๊ฯࠡษ็้฼๊่ษࠩ዗"))
	return Q0AOX4cEgius9e
def qopESgGvKPIU6():
	url = liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡯࡬ࡶࡷࡵࡲࡴ࠰࡮ࡳࡩ࡯࠮ࡵࡸ࠲ࡶࡪࡲࡥࡢࡵࡨࡷ࠴ࡽࡩ࡯ࡦࡲࡻࡸ࠵ࡷࡪࡰ࠹࠸࠴࠭ዘ")
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,f8Ja1q5eO02B(u"ࠩࡊࡉ࡙࠭ዙ"),url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,rbUkdYi32PJaRtnxhDvQs(u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗ࠲࡙ࡈࡐ࡙ࡢࡐࡆ࡚ࡅࡔࡖࡢࡏࡔࡊࡉࡠࡘࡈࡖࡘࡏࡏࡏ࠯࠴ࡷࡹ࠭ዚ"))
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	u1VBKIMDn6ji8plkLo50xE9t = ffUFBJQ57j2XgoGeOLn9uwpC.findall(WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠫࡹ࡯ࡴ࡭ࡧࡀࠦࡰࡵࡤࡪ࠯ࠫࡠࡩ࠱࡜࠯࡞ࡧ࠯࠲ࡡࡡ࠮ࡼࡄ࠱࡟ࡣࠫࠪ࠯ࠪዛ"),OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	u1VBKIMDn6ji8plkLo50xE9t = u1VBKIMDn6ji8plkLo50xE9t[nnsBpJv6XL3OzHoe4Vuhr].split(AiCor1fIVTDxQUWwHe9vPR7(u"ࠬ࠳ࠧዜ"))[nnsBpJv6XL3OzHoe4Vuhr]
	CQPwdLGybJ36fc0OR1U8Mi95jTz = str(m4PjYkEqLcJh)
	gvzWimTak9Se5B6A3UF = On1WZJc6dtksqVNgSQ5GBAjuipe(u"࡛࠭ࡓࡖࡏࡡส฻ฯศำࠣ็ํี๊ࠡษ็วำ๐ัࠡษ็้ฯ๎แาࠢส่ว์่๊ࠠࠣ࠾ࠥࠦࠠࠨዝ")+bxf7gZvNK29cEoiAIJlMq0dP+u1VBKIMDn6ji8plkLo50xE9t+kH8E2zqNyims6KJfI
	gvzWimTak9Se5B6A3UF += s8fcjBCSMxzAIkZQbJPga(u"ࠧ࡝ࡰ࡟ࡲࠬዞ")+ObuCsdoDtKmhPLSMH8YGan(u"ࠨ࡝ࡕࡘࡑࡣลึัสี้่ࠥะ์ࠣห้ึ๊ࠡษ้ฮࠥะำหะา้์ࠦ็้ࠢ࠽ࠤࠥࠦࠧዟ")+bxf7gZvNK29cEoiAIJlMq0dP+CQPwdLGybJ36fc0OR1U8Mi95jTz+kH8E2zqNyims6KJfI
	NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,gvzWimTak9Se5B6A3UF)
	return
def XYjRLUN6x5b4oAJn():
	NfC5VBqa4AF2QM,E9VklycmAMdiFHNZhToQCqIg,lNyqMb8SQx7OKrJTfHZ = ksTLSoVGg0ht,cdZKMn68Pzg4,cdZKMn68Pzg4
	It1DuN3PTGFL9fUlqyx0AQw,TqGDaOvFZ2,BBYUVFJZ12sgW8Nau6GHbML7RdvDf = ksTLSoVGg0ht,cdZKMn68Pzg4,cdZKMn68Pzg4
	HBP0ivFbdy2ZgIq15XJWCl4Yf9 = [vbYokBuWlxeLDcdVNM60(u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧዠ"),AiCor1fIVTDxQUWwHe9vPR7(u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨࠬዡ"),Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪዢ")]
	Hgd2k9RXymZVqcw = sMmGpryoLIThV1KYO3xA05v9dgFXD(HBP0ivFbdy2ZgIq15XJWCl4Yf9)
	for pzPE1fgqrkbQOXBmc in HBP0ivFbdy2ZgIq15XJWCl4Yf9:
		if pzPE1fgqrkbQOXBmc not in list(Hgd2k9RXymZVqcw.keys()): continue
		V3wKRrD0PWvS,qgtRKQI20sJ3ixD9TNF6bBrhwmvof,oYikS1NDzxeOmX2wdj,ZzY3tT9PegxoNl,TptirC9DHo8GjcXRueY0JzVb,hEBbHxFgved9,uYWgjLCJE3RnVd21GQsM = Hgd2k9RXymZVqcw[pzPE1fgqrkbQOXBmc]
		if pzPE1fgqrkbQOXBmc==LJPOQNK1mcG(u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪዣ"):
			It1DuN3PTGFL9fUlqyx0AQw = V3wKRrD0PWvS
			TqGDaOvFZ2 = qgtRKQI20sJ3ixD9TNF6bBrhwmvof+f8Ja1q5eO02B(u"࠭ࠠࠡࠢࠣࠬࠥ࠭ዤ")+N6EjMQZJwbdDLla0C24Opifg(hEBbHxFgved9)+tRnTydV03Xfi7rbQ(u"ࠧࠡࠫࠪዥ")
			BBYUVFJZ12sgW8Nau6GHbML7RdvDf = ZzY3tT9PegxoNl
		elif pzPE1fgqrkbQOXBmc==J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦࠪዦ"):
			NfC5VBqa4AF2QM = NfC5VBqa4AF2QM or V3wKRrD0PWvS
			E9VklycmAMdiFHNZhToQCqIg += LJPOQNK1mcG(u"ࠩࠣࠤ࠱ࠦࠠࠨዧ")+qgtRKQI20sJ3ixD9TNF6bBrhwmvof+KNomgGw1kdMCBH(u"ࠪࠤࠥࠦࠠࠩࠢࠪየ")+N6EjMQZJwbdDLla0C24Opifg(hEBbHxFgved9)+HC9xWUMpBQJEuTteAqjd(u"ࠫࠥ࠯ࠧዩ")
			lNyqMb8SQx7OKrJTfHZ += S5fhsRT8JV(u"ࠬࠦࠠ࠭ࠢࠣࠫዪ")+ZzY3tT9PegxoNl
		elif pzPE1fgqrkbQOXBmc==f8Ja1q5eO02B(u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈࠬያ"):
			z9S6MU7mknDlZJobdRvfwtpF0hIGr = V3wKRrD0PWvS
			dm83brze4JNRstMZlqwFSiPI7T = qgtRKQI20sJ3ixD9TNF6bBrhwmvof+S5fhsRT8JV(u"ࠧࠡࠢࠣࠤ࠭ࠦࠧዬ")+N6EjMQZJwbdDLla0C24Opifg(hEBbHxFgved9)+k5oIaYyp2mnrLK49qhzS(u"ࠨࠢࠬࠫይ")
			sdTZwPj85R2kSnCrNavf7p = ZzY3tT9PegxoNl
	E9VklycmAMdiFHNZhToQCqIg = E9VklycmAMdiFHNZhToQCqIg.strip(HC9xWUMpBQJEuTteAqjd(u"ࠩࠣࠤ࠱ࠦࠠࠨዮ"))
	lNyqMb8SQx7OKrJTfHZ = lNyqMb8SQx7OKrJTfHZ.strip(LJPOQNK1mcG(u"ࠪࠤࠥ࠲ࠠࠡࠩዯ"))
	HFQMr5LnAugP7OXjxlDZyK8a6  = f8Ja1q5eO02B(u"ࠫࡠࡘࡔࡍ࡟ส่ส฻ฯศำࠣห้ษฮ๋ำ่ࠣอืๆศ็ฯࠤ฾๋วะࠢส่๊ะ่โำࠣห้ศๆ้๋ࠡࠤ࠿ࠦࠠࠡࠩደ")+bxf7gZvNK29cEoiAIJlMq0dP+BBYUVFJZ12sgW8Nau6GHbML7RdvDf+kH8E2zqNyims6KJfI
	HFQMr5LnAugP7OXjxlDZyK8a6 += ssELJkeScrtni2+s8fcjBCSMxzAIkZQbJPga(u"ࠬࡡࡒࡕࡎࡠห้หีะษิࠤฬ๊ะ๋ࠢส๊ฯࠦสิฬัำ๊ํࠠๅสิ๊ฬ๋ฬࠡ฻่หิࠦ็้ࠢ࠽ࠤࠥࠦࠧዱ")+bxf7gZvNK29cEoiAIJlMq0dP+TqGDaOvFZ2+kH8E2zqNyims6KJfI
	HFQMr5LnAugP7OXjxlDZyK8a6 += zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"࠭࡜࡯࡞ࡱࠫዲ")+tRnTydV03Xfi7rbQ(u"ࠧ࡜ࡔࡗࡐࡢอไฦืาหึࠦวๅลั๎ึࠦไๆีอ์ิ฿ฺࠠ็สำࠥอไๆฬ๋ๅึࠦวๅฤ้ࠤ์๎ࠠ࠻ࠢࠣࠤࠬዳ")+bxf7gZvNK29cEoiAIJlMq0dP+lNyqMb8SQx7OKrJTfHZ+kH8E2zqNyims6KJfI
	HFQMr5LnAugP7OXjxlDZyK8a6 += ssELJkeScrtni2+vbYokBuWlxeLDcdVNM60(u"ࠨ࡝ࡕࡘࡑࡣวๅวุำฬืࠠศๆำ๎ࠥอๆหࠢอืฯิฯๆู้่๊ࠣส้ั฼ࠤ฾๋วะ๊ࠢ์ࠥࡀࠠࠡࠢࠪዴ")+bxf7gZvNK29cEoiAIJlMq0dP+E9VklycmAMdiFHNZhToQCqIg+kH8E2zqNyims6KJfI
	HFQMr5LnAugP7OXjxlDZyK8a6 += LungQF89BqemOb32jJsZlW(u"ࠩ࡟ࡲࡡࡴࠧድ")+tRnTydV03Xfi7rbQ(u"ࠪ࡟ࡗ࡚ࡌ࡞ษ็ษฺีวาࠢส่ศิ๊าࠢ็ะ้ีࠠๆฬิ์อ๎ไิࠢ฼้ฬีࠠศๆ่ฮํ็ัࠡษ็ฦ๋ࠦ็้ࠢ࠽ࠤࠥࠦࠧዶ")+bxf7gZvNK29cEoiAIJlMq0dP+sdTZwPj85R2kSnCrNavf7p+kH8E2zqNyims6KJfI
	HFQMr5LnAugP7OXjxlDZyK8a6 += ssELJkeScrtni2+xN4fKmsnyM3Y2(u"ࠫࡠࡘࡔࡍ࡟ส่ส฻ฯศำࠣห้ึ๊ࠡษ้ฮࠥะำหะา้์ࠦไอๆาࠤ๊ะั้สุู๋่ࠦๆษาࠤ์๎ࠠ࠻ࠢࠣࠤࠬዷ")+bxf7gZvNK29cEoiAIJlMq0dP+dm83brze4JNRstMZlqwFSiPI7T+kH8E2zqNyims6KJfI
	V3wKRrD0PWvS = It1DuN3PTGFL9fUlqyx0AQw or NfC5VBqa4AF2QM
	if V3wKRrD0PWvS:
		header = f8Ja1q5eO02B(u"ࠬอไาฮสลࠥะอะ์ฮࠤส฼วโษอࠤ่๎ฯ๋ࠢ็ั้ࠦวๅ็ืห่๊ࠧዸ")
		Xs12JCWGlgmSoHTjAqrFZafE = dwiIAcPl04ey7Zv38Mz(u"࠭ว็ฬࠣฬาอฬสࠢ็ฮาี๊ฬࠢหี๋อๅอࠢ฼้ฬีࠠฤ๊ࠣฮาี๊ฬ่ࠢืฯ๎ฯฺࠢ฼้ฬีࠧዹ")
	else:
		header = LJPOQNK1mcG(u"ࠧฮษ็๎ฬࠦไศࠢํ์ัีࠠหฯา๎ะอสࠡๆหี๋อๅอࠢ฼้ฬีࠠฤุ๊้ࠣะ่ะ฻ࠣ฽๊อฯࠨዺ")
		Xs12JCWGlgmSoHTjAqrFZafE = opyTNwHgfqbZREWKU(u"ࠨษ็ีัอมࠡวห่ฬเࠠศๆ่ฬึ๋ฬࠡ฻้ࠤฬ๊ๅีๅ็อࠥอไห์ࠣฮํอฬ่ๅࠪዻ")
	FPe3p2mDIBucVrxb7zaiMj1SEKfO = aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠩ็็๏ฺ๊ࠦ็็ࠤ฾์ฯไࠢส่ฯำฯ๋อࠣห้ะไใษษ๎ࠥ๐ฬษࠢฦ๊ࠥ๐ใ้่่ࠣิ๐ใࠡใํࠤ่๎ฯ๋࡞ࡱุ้ะ่ะ฻ࠣ฽๊อฯࠡࡇࡐࡅࡉࠦࡒࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻࠪዼ")
	kNaDQVAMRI2pPECTFwotxb = HFQMr5LnAugP7OXjxlDZyK8a6+S5fhsRT8JV(u"ࠪࡠࡳࡢ࡮ࠨዽ")+Xs12JCWGlgmSoHTjAqrFZafE+TtyzcuW45VKA(u"ࠫࡡࡴ࡜࡯ࠩዾ")+FPe3p2mDIBucVrxb7zaiMj1SEKfO
	E3WHU2OdFfmX459c(HC9xWUMpBQJEuTteAqjd(u"ࠬࡸࡩࡨࡪࡷࠫዿ"),header,kNaDQVAMRI2pPECTFwotxb,HC9xWUMpBQJEuTteAqjd(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩጀ"))
	return V3wKRrD0PWvS
def GUM97x06XtLYhr(pzPE1fgqrkbQOXBmc,uYWgjLCJE3RnVd21GQsM,showDialogs):
	Q0AOX4cEgius9e = ksTLSoVGg0ht
	if showDialogs:
		BoyIUWYSNR0jhDxQwvJriO4PkL = JyLdvftP3CU(cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠧิ๊ไࠤ๏ะๅࠡษ็ฦ๋ࠦฬๅสࠣห้๋ไโࠢส่๊฼ฺู้่้ࠣหึศใฬࠤฬ๊ๅุๆ๋ฬฮࠦไไ์ࠣ๎ฯ๋ࠠหอห๎ฯํฺࠠๆ์ࠤ่๎ฯ๋ࠢ࠱ࠤฬ๊ๅๅใࠣๆิ๊ࠦไ๊้ࠤ่ฮ๊า๋ࠢๆิ๊ࠦฮฬสะࠥฮูืࠢส่ํ่สࠡ࠰๋้ࠣࠦสา์าࠤฯำๅ๋ๆࠣห้๋ไโࠢส่ว์ࠠภࠣࠪጁ"))
		if BoyIUWYSNR0jhDxQwvJriO4PkL!=hiuZa0PIsErm6UC7: return ksTLSoVGg0ht
	TMBSi4Y6OQ = ImLjWxYH1p3rRF2VhCOvz8(uYWgjLCJE3RnVd21GQsM,{},showDialogs)
	if TMBSi4Y6OQ:
		UX0s17OHhBnVkxbe5ID6oAz4mRTyCZ = YRESXadfbIy3khwqmL8WC.path.join(fEe9HrM7nOh6swT0a3WvFgq,pzPE1fgqrkbQOXBmc)
		rVyWBlI4fZNiTcAz20O7(UX0s17OHhBnVkxbe5ID6oAz4mRTyCZ,IZQbmFzLHDtXfc,ksTLSoVGg0ht)
		import zipfile as Ch2KQJksXgdBit68auypO30eRU,io as Q9uYFC5N4B
		neKSb7jzw14sMANk9ZyOGmtPVgJo = Q9uYFC5N4B.BytesIO(TMBSi4Y6OQ)
		try:
			zw5nOYWSlH3NPAdeg2vBpDto6 = Ch2KQJksXgdBit68auypO30eRU.ZipFile(neKSb7jzw14sMANk9ZyOGmtPVgJo)
			zw5nOYWSlH3NPAdeg2vBpDto6.extractall(fEe9HrM7nOh6swT0a3WvFgq)
			bD7kJZhMCdaqF68P45KlNIgO1.sleep(hiuZa0PIsErm6UC7)
			bu6LzUQF7K.executebuiltin(opyTNwHgfqbZREWKU(u"ࠨࡗࡳࡨࡦࡺࡥࡍࡱࡦࡥࡱࡇࡤࡥࡱࡱࡷࠬጂ"))
			bD7kJZhMCdaqF68P45KlNIgO1.sleep(hiuZa0PIsErm6UC7)
			Q0AOX4cEgius9e = YUG4k2A0dlL3rv9nwHu(pzPE1fgqrkbQOXBmc)
		except: Q0AOX4cEgius9e = ksTLSoVGg0ht
	if showDialogs:
		if Q0AOX4cEgius9e: NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,k5oIaYyp2mnrLK49qhzS(u"ࠩอ้ࠥฮๆอษะࠤฯัศ๋ฬࠣห้หึศใฬࠤฬ๊ๅุๆ๋ฬฮ࠭ጃ"))
		else: NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,SGazRxP3yBKZ15ILuch(u"่้ࠪษำโࠢไุ้ะฺࠠ็็๎ฮࠦสฬสํฮࠥอไฦุสๅฮࠦวๅ็ฺ่ํฮษࠨጄ"))
	return Q0AOX4cEgius9e
def bMoCAVnTStgik0(pzPE1fgqrkbQOXBmc,showDialogs=IZQbmFzLHDtXfc):
	if showDialogs==cdZKMn68Pzg4: showDialogs = IZQbmFzLHDtXfc
	W1WcEAbv2wsnTYxmozN3QuX0BjK6L = WNfRtpcBzlyG([pzPE1fgqrkbQOXBmc])
	lteX9ML8fJN0jgnIr,RN19MiQDngr2F0Is8wLcHzf6ySxu53 = W1WcEAbv2wsnTYxmozN3QuX0BjK6L[pzPE1fgqrkbQOXBmc]
	if RN19MiQDngr2F0Is8wLcHzf6ySxu53:
		Q0AOX4cEgius9e = IZQbmFzLHDtXfc
		if showDialogs: NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,ObuCsdoDtKmhPLSMH8YGan(u"ࠫๆำีࠡษ็ษ฻อแสࠢ࡟ࡲࠥ࠭ጅ")+pzPE1fgqrkbQOXBmc+LJPOQNK1mcG(u"ࠬࠦ࡜࡯๊ࠢิ์ࠦรๅวูหๆฯฺ่ࠠา็๋่ࠥอ๊าอࠥ๎ๅโ฻็อࠥ๎ฬศ้ีอ๊ࠥไศีอาิอๅࠨጆ"))
	else:
		Q0AOX4cEgius9e = ksTLSoVGg0ht
		BoyIUWYSNR0jhDxQwvJriO4PkL = JyLdvftP3CU(xN4fKmsnyM3Y2(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ጇ"),cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,cdZKMn68Pzg4+pzPE1fgqrkbQOXBmc+dwiIAcPl04ey7Zv38Mz(u"ࠧࠡ࡞ࡱࡠࡳࠦ็ั้ࠣว้หึศใฬࠤ฾์ฯไࠢ฽๎ึࠦๅโ฻็อࠥษ่ࠡ฼ํี๋่ࠥอ๊าอࠥ๎วๅสิ๊ฬ๋ฬࠡสะหัฯࠠๅ้สࠤ࠳ࠦ็ๅࠢอี๏ีࠠหอห๎ฯ่ࠦหใ฼๎้ࠦ็ั้ࠣห้หึศใฬࠤฬ๊ย็ࠢยࠫገ"))
		if BoyIUWYSNR0jhDxQwvJriO4PkL==liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"࠴ᏹ"):
			bu6LzUQF7K.executebuiltin(LJPOQNK1mcG(u"ࠨࡋࡱࡷࡹࡧ࡬࡭ࡃࡧࡨࡴࡴࠨࠨጉ")+pzPE1fgqrkbQOXBmc+TtyzcuW45VKA(u"ࠩࠬࠫጊ"))
			bD7kJZhMCdaqF68P45KlNIgO1.sleep(HC9xWUMpBQJEuTteAqjd(u"࠵ᏺ"))
			bu6LzUQF7K.executebuiltin(f8Ja1q5eO02B(u"ࠪࡗࡪࡴࡤࡄ࡮࡬ࡧࡰ࠮࠱࠲ࠫࠪጋ"))
			bD7kJZhMCdaqF68P45KlNIgO1.sleep(AiCor1fIVTDxQUWwHe9vPR7(u"࠶ᏻ"))
			while bu6LzUQF7K.getCondVisibility(f8Ja1q5eO02B(u"ࠫ࡜࡯࡮ࡥࡱࡺ࠲ࡎࡹࡁࡤࡶ࡬ࡺࡪ࠮ࡰࡳࡱࡪࡶࡪࡹࡳࡥ࡫ࡤࡰࡴ࡭ࠩࠨጌ")): bD7kJZhMCdaqF68P45KlNIgO1.sleep(s8fcjBCSMxzAIkZQbJPga(u"࠷ᏼ"))
			Q0AOX4cEgius9e = YUG4k2A0dlL3rv9nwHu(pzPE1fgqrkbQOXBmc)
			if showDialogs and Q0AOX4cEgius9e: NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠬะๅࠡใะูࠥอไฦุสๅฮࠦวๅ็ฺ่ํฮษ๊๊ࠡ๎ࠥอไร่ࠣะฬําสࠢ็่ฬูสฯัส้ࠬግ"))
			elif showDialogs: NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,YnHG75e2QWwo(u"࠭แีๆࠣๅ๏ࠦสฬสํฮࠥษ่ࠡฬไ฽๏๊ࠠฤ๊ࠣฮาี๊ฬࠢส่ส฼วโหࠣห้๋ืๅ๊หอࠥ࠴้ࠠษ็ั้ࠦ็้ࠢอฯอ๐ส่ษࠣ์ฯ็ู๋ๆ๊ห๋ࠥๆࠡะสีัࠦวๅสิ๊ฬ๋ฬࠨጎ"))
	return Q0AOX4cEgius9e
def lqnjuhIkEzrOCLa0RdZ8esvXcFKf(showDialogs):
	if not showDialogs: BoyIUWYSNR0jhDxQwvJriO4PkL = IZQbmFzLHDtXfc
	else: BoyIUWYSNR0jhDxQwvJriO4PkL = JyLdvftP3CU(iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠧࡤࡧࡱࡸࡪࡸࠧጏ"),cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,KNomgGw1kdMCBH(u"ࠨสิ๊ฬ๋ฬࠡๅ๋ำ๏๊ࠦใ๊่ࠤอ฿ๅๅ์ฬࠤฯำฯ๋อࠣะ๊๐ูࠡษ็ษ฻อแศฬࠣฮ้่วว์สࠤ่๊ࠠ࠳࠶ࠣืฬ฿ษ๊ࠡ็็๋ࠦๅๆๅ้ࠤสาัศร๊หࠥอไร่ࠣ࠲ࠥํไࠡฬิ๎ิࠦวๅฤ้ࠤศ์ࠠหู็ฬ๋ࠥๆࠡๅ๋ำ๏ࠦแฮืࠣ์ฯำฯ๋อࠣะ๊๐ูࠡษ็ษ฻อแศฬࠣรࠬጐ"))
	if BoyIUWYSNR0jhDxQwvJriO4PkL==aar0zhDnJsOTP7EdgR16HIS29(u"࠱ᏽ"):
		bu6LzUQF7K.executebuiltin(aar0zhDnJsOTP7EdgR16HIS29(u"ࠩࡘࡴࡩࡧࡴࡦࡃࡧࡨࡴࡴࡒࡦࡲࡲࡷࠬ጑"))
		if showDialogs:
			NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,aar0zhDnJsOTP7EdgR16HIS29(u"ࠪฮ๊ࠦลาีส่ࠥ฽ไษࠢศ่๎ࠦศา่ส้ัࠦใ้ัํࠤฬ๊ะ๋ࠢไ๎ࠥา็ศิๆࠤ้้๊ࠡ์ๅ์๊ࠦศหฯา๎ะࠦฬๆ์฼ࠤส฼วโษอࠤ่๎ฯ๋ࠢ࠱ࠤอ๋วࠡใํ๋ฬࠦสฮัํฯࠥํะศࠢส่อืๆศ็ฯࠤํะอะ์ฮࠤู๊ส้ั฼ࠤ฾๋วะࠢ࠱ࠤ๏ืฬ๊ࠢศ฽฼อมࠡๅ๋ำ๏ࠦ࠵ࠡัๅหห่ࠠฤ๊ࠣว่ััࠡๆๆ๎ࠥ๐ๆ่์ࠣ฽๊๊๊สࠢส่ฯำฯ๋อࠪጒ"))
	return
def TrhS6DBuFtfX():
	uVOoSHfqe4WtiF(TV08xYHA2ok,nfg30bHwd4aNV12SR7UjFck(u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖ࡟࠲ࠩጓ"),NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠬࡇࡌࡍࡡࡄࡈࡉࡕࡎࡔࡡ࡛ࡑࡑ࠭ጔ"))
	qopESgGvKPIU6()
	V3wKRrD0PWvS = XYjRLUN6x5b4oAJn()
	if V3wKRrD0PWvS:
		p1mcA6LasBxC7YKGPV0kJRFMfS(IZQbmFzLHDtXfc)
		lqnjuhIkEzrOCLa0RdZ8esvXcFKf(IZQbmFzLHDtXfc)
		XfABsbKWoLhI(ksTLSoVGg0ht)
	return
def YUG4k2A0dlL3rv9nwHu(pzPE1fgqrkbQOXBmc):
	xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = bu6LzUQF7K.executeJSONRPC(SGazRxP3yBKZ15ILuch(u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡇࡤࡥࡱࡱࡷ࠳࡙ࡥࡵࡃࡧࡨࡴࡴࡅ࡯ࡣࡥࡰࡪࡪࠢ࠭ࠤ࡬ࡨࠧࡀ࠱࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡧࡤࡥࡱࡱ࡭ࡩࠨ࠺ࠣࠩጕ")+pzPE1fgqrkbQOXBmc+HC9xWUMpBQJEuTteAqjd(u"ࠧࠣ࠮ࠥࡩࡳࡧࡢ࡭ࡧࡧࠦ࠿ࡺࡲࡶࡧࢀࢁࠬ጖"))
	succeeded = IZQbmFzLHDtXfc if rbUkdYi32PJaRtnxhDvQs(u"ࠨࡑࡎࠫ጗") in xsGUcR3ef6glKY5hQwpFXEaSt2mrIz else ksTLSoVGg0ht
	return succeeded
def aUW1tsJOhEK5H(pzPE1fgqrkbQOXBmc):
	xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = bu6LzUQF7K.executeJSONRPC(opyTNwHgfqbZREWKU(u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡃࡧࡨࡴࡴࡳ࠯ࡕࡨࡸࡆࡪࡤࡰࡰࡈࡲࡦࡨ࡬ࡦࡦࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡣࡧࡨࡴࡴࡩࡥࠤ࠽ࠦࠬጘ")+pzPE1fgqrkbQOXBmc+AiCor1fIVTDxQUWwHe9vPR7(u"ࠪࠦ࠱ࠨࡥ࡯ࡣࡥࡰࡪࡪࠢ࠻ࡨࡤࡰࡸ࡫ࡽࡾࠩጙ"))
	succeeded = IZQbmFzLHDtXfc if dwiIAcPl04ey7Zv38Mz(u"ࠫࡔࡑࠧጚ") in xsGUcR3ef6glKY5hQwpFXEaSt2mrIz else ksTLSoVGg0ht
	return succeeded
def OnpfSh5RvPUTjdD7BI4uJeo(pzPE1fgqrkbQOXBmc,showDialogs,hEj2imuGSCYBLJnX1pIg,Hgd2k9RXymZVqcw=None):
	BoyIUWYSNR0jhDxQwvJriO4PkL,succeeded,aOoLTMtGmxAVin80FXlsQwvIedE,qgtRKQI20sJ3ixD9TNF6bBrhwmvof = IZQbmFzLHDtXfc,ksTLSoVGg0ht,liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬጛ"),cdZKMn68Pzg4
	if not Hgd2k9RXymZVqcw: Hgd2k9RXymZVqcw = sMmGpryoLIThV1KYO3xA05v9dgFXD([pzPE1fgqrkbQOXBmc])
	if pzPE1fgqrkbQOXBmc in list(Hgd2k9RXymZVqcw.keys()):
		V3wKRrD0PWvS,qgtRKQI20sJ3ixD9TNF6bBrhwmvof,oYikS1NDzxeOmX2wdj,ZzY3tT9PegxoNl,TptirC9DHo8GjcXRueY0JzVb,hEBbHxFgved9,uYWgjLCJE3RnVd21GQsM = Hgd2k9RXymZVqcw[pzPE1fgqrkbQOXBmc]
		if hEBbHxFgved9==xN4fKmsnyM3Y2(u"࠭ࡧࡰࡱࡧࠫጜ"):
			succeeded,aOoLTMtGmxAVin80FXlsQwvIedE = IZQbmFzLHDtXfc,tRnTydV03Xfi7rbQ(u"ࠧ࡯ࡱࡷ࡬࡮ࡴࡧࠨጝ")
			if hEj2imuGSCYBLJnX1pIg and showDialogs:
				BoyIUWYSNR0jhDxQwvJriO4PkL = JyLdvftP3CU(cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,On1WZJc6dtksqVNgSQ5GBAjuipe(u"ࠨฮํำࠥาฯศࠢ࠱࠲้่ࠥะ์ࠣ๎ุะฮะ็ࠣวำืࠠฦืาหึࠦๅห๊ไีࠥ็๊ࠡ็๋ห็฿ࠠๆีอ์ิ฿ฺࠠ็สำ๊ࠥ็ั้ࠣห้หึศใฬࡠࡳࡢ࡮ࠨጞ")+pzPE1fgqrkbQOXBmc+On1WZJc6dtksqVNgSQ5GBAjuipe(u"ࠩ࡟ࡲࡡࡴ็ๅࠢอี๏ีࠠฦ฻สำฮࠦสฬสํฮࠥํะ่ࠢส่ส฼วโห้ࠣึฯࠠฤะิํࠬጟ"))
				if BoyIUWYSNR0jhDxQwvJriO4PkL:
					succeeded = GUM97x06XtLYhr(pzPE1fgqrkbQOXBmc,uYWgjLCJE3RnVd21GQsM,ksTLSoVGg0ht)
					if succeeded:
						aOoLTMtGmxAVin80FXlsQwvIedE = WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠪࡶࡪ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤࠨጠ")
						if showDialogs: NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,TtyzcuW45VKA(u"ࠫั๐ฯࠡฮาหࠥ࠴࠮ࠡษ็ษ฻อแสࠢๆห๋ะࠠๆ๊ฯ์ิฯࠠ࠯࠰ࠣ์็อๅࠡษ็ฬึ์วๆฮࠣฬส฿วะหࠣฮะฮ๊ห้สࡠࡳࡢ࡮ࠨጡ")+pzPE1fgqrkbQOXBmc)
					else:
						aOoLTMtGmxAVin80FXlsQwvIedE = aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬጢ")
						NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,ObuCsdoDtKmhPLSMH8YGan(u"࠭ไๅลึๅࠥ࠴࠮ࠡษ็ฬึ์วๆฮ่๊๊ࠣࠦิฬฺ๎฾ࠦลฺษาอࠥะหษ์อࠤ์ึ็ࠡษ็ษ฻อแส࡞ࡱࡠࡳ࠭ጣ")+pzPE1fgqrkbQOXBmc)
		else:
			if showDialogs:
				if hEBbHxFgved9==YnHG75e2QWwo(u"ࠧࡥ࡫ࡶࡥࡧࡲࡥࡥࠩጤ"): KZ4oqDz5xgA2tkGcTaeQ1Lh3dp = zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"ࠨ็อ์็็ษࠨጥ")
				elif hEBbHxFgved9==S5fhsRT8JV(u"ࠩࡲࡰࡩ࠭ጦ"): KZ4oqDz5xgA2tkGcTaeQ1Lh3dp = tRnTydV03Xfi7rbQ(u"ࠪๆิ๐ๅสࠩጧ")
				elif hEBbHxFgved9==iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠫࡲ࡯ࡳࡴ࡫ࡱ࡫ࠬጨ"): KZ4oqDz5xgA2tkGcTaeQ1Lh3dp = AiCor1fIVTDxQUWwHe9vPR7(u"ࠬเ๊า่ࠢฯอะษࠨጩ")
				BoyIUWYSNR0jhDxQwvJriO4PkL = JyLdvftP3CU(cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,KNomgGw1kdMCBH(u"࠭็ั้ࠣห้หึศใฬࠤࠬጪ")+KZ4oqDz5xgA2tkGcTaeQ1Lh3dp+S5fhsRT8JV(u"ࠧࠡ࠰࠱ࠤ์๊ࠠหำํำࠥหีๅษะࠤ์ึ็ࠡษ็ู้้ไสࠢยࠥࡡࡴ࡜࡯ࠩጫ")+pzPE1fgqrkbQOXBmc)
			if not BoyIUWYSNR0jhDxQwvJriO4PkL: aOoLTMtGmxAVin80FXlsQwvIedE = YnHG75e2QWwo(u"ࠨࡥࡤࡲࡨ࡫࡬ࡦࡦࠪጬ")
			else:
				if hEBbHxFgved9==YnHG75e2QWwo(u"ࠩࡧ࡭ࡸࡧࡢ࡭ࡧࡧࠫጭ"):
					succeeded = YUG4k2A0dlL3rv9nwHu(pzPE1fgqrkbQOXBmc)
					if succeeded:
						aOoLTMtGmxAVin80FXlsQwvIedE = AiCor1fIVTDxQUWwHe9vPR7(u"ࠪࡩࡳࡧࡢ࡭ࡧࡧࠫጮ")
						if showDialogs: NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,uxE8MyoTRglrcaiQf(u"ࠫั๐ฯࠡฮาหࠥ࠴࠮ࠡษ็ษ฻อแสࠢๆห๋ะࠠๆฬ๋ๆๆฯࠠ࠯࠰ࠣ์็อๅࠡษ็ฬึ์วๆฮࠣฬฯฺฺ๋ๆ๊หࡡࡴ࡜࡯ࠩጯ")+pzPE1fgqrkbQOXBmc)
					elif showDialogs: NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,k5oIaYyp2mnrLK49qhzS(u"๊ࠬไฤีไࠤ࠳࠴ࠠศๆศฺฬ็ษࠡ็อ์็็ษࠡ࠰࠱ࠤํ๊ๅࠡ์ึฮ฼๐ูࠡษ็ฬึ์วๆฮࠣฮูเ๊ๅ้สࡠࡳࡢ࡮ࠨጰ")+pzPE1fgqrkbQOXBmc)
				elif hEBbHxFgved9 in [s8fcjBCSMxzAIkZQbJPga(u"࠭࡯࡭ࡦࠪጱ"),aar0zhDnJsOTP7EdgR16HIS29(u"ࠧ࡮࡫ࡶࡷ࡮ࡴࡧࠨጲ")]:
					succeeded = GUM97x06XtLYhr(pzPE1fgqrkbQOXBmc,uYWgjLCJE3RnVd21GQsM,ksTLSoVGg0ht)
					if succeeded:
						if hEBbHxFgved9==s8fcjBCSMxzAIkZQbJPga(u"ࠨࡱ࡯ࡨࠬጳ"): aOoLTMtGmxAVin80FXlsQwvIedE = On1WZJc6dtksqVNgSQ5GBAjuipe(u"ࠩࡸࡴࡩࡧࡴࡦࡦࠪጴ")
						elif hEBbHxFgved9==LungQF89BqemOb32jJsZlW(u"ࠪࡱ࡮ࡹࡳࡪࡰࡪࠫጵ"): aOoLTMtGmxAVin80FXlsQwvIedE = NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠫ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪࠧጶ")
						qgtRKQI20sJ3ixD9TNF6bBrhwmvof = ZzY3tT9PegxoNl
						if showDialogs:
							if aOoLTMtGmxAVin80FXlsQwvIedE==TtyzcuW45VKA(u"ࠬࡻࡰࡥࡣࡷࡩࡩ࠭ጷ"): NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,k5oIaYyp2mnrLK49qhzS(u"࠭ฬ๋ัࠣะิอࠠ࠯࠰ࠣห้หึศใฬࠤ่อๆหࠢๅำ๏๋ษࠡ࠰࠱ࠤํอไษำ้ห๊าࠠใษ่ࠤอะอะ์ฮ๋ฬࡢ࡮࡝ࡰࠪጸ")+pzPE1fgqrkbQOXBmc)
							elif aOoLTMtGmxAVin80FXlsQwvIedE==nfg30bHwd4aNV12SR7UjFck(u"ࠧࡪࡰࡶࡸࡦࡲ࡬ࡦࡦࠪጹ"): NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,LungQF89BqemOb32jJsZlW(u"ࠨฮํำࠥาฯศࠢ࠱࠲ࠥอไฦุสๅฮࠦไๆࠢอ็๋ࠦๅ้ฮ๋ำฮࠦแ๋ࠢๆ์ิ๐ࠠ࠯࠰ࠣ์ฬ๊ศา่ส้ัࠦโศ็ࠣฬฯัศ๋ฬ๊หࡡࡴ࡜࡯ࠩጺ")+pzPE1fgqrkbQOXBmc)
					elif showDialogs: NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"ࠩ็่ศูแࠡ࠰࠱ࠤฬ๊ศา่ส้ัࠦไๆࠢํืฯ฽ฺ๊ࠢอัิ๐หࠡล๋ࠤฯัศ๋ฬ๋ࠣีํࠠศๆศฺฬ็ษ࡝ࡰ࡟ࡲࠬጻ")+pzPE1fgqrkbQOXBmc)
	elif showDialogs: NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,S5fhsRT8JV(u"่้ࠪษำโࠢ࠱࠲ࠥํะ่ࠢส่ส฼วโหࠣ฾๏ืࠠๆ๊ฯ์ิฯࠠโ์ุ้ࠣะ่ะ฻ࠣ฽๊อฯࠡ࠰࠱ࠤํ๊็ัษ่ࠣฬ๊ࠦิฬฺ๎฾ࠦวๅสิ๊ฬ๋ฬࠡล้ࠤ๏่่ๆࠢหฮะฮ๊ห๊ࠢิ์ࠦวๅวูหๆฯࠠฤ๊ࠣฮาี๊ฬ้สࡠࡳࡢ࡮ࠨጼ")+pzPE1fgqrkbQOXBmc)
	return succeeded,aOoLTMtGmxAVin80FXlsQwvIedE,qgtRKQI20sJ3ixD9TNF6bBrhwmvof
def NOgUfGTJty8DjbFWIL5iAzxBZ7E3V(pzPE1fgqrkbQOXBmc,showDialogs,AV9P4nfxNjSWUrihtzplM2GCJdDgQ):
	DeQmLbJv6YKcgSOTNz = IDjorYsAdihx7QK.connect(pHc2J8YxdanW)
	DeQmLbJv6YKcgSOTNz.text_factory = str
	yjNYCMFrPXpAoZHGe7iUJ25g = DeQmLbJv6YKcgSOTNz.cursor()
	succeeded,M96Up8uv53tdBT = IZQbmFzLHDtXfc,ksTLSoVGg0ht
	try:
		iQjV4rPSZyU9zNO6 = k5oIaYyp2mnrLK49qhzS(u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠭ጽ")
		yjNYCMFrPXpAoZHGe7iUJ25g.execute(AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"࡙ࠬࡅࡍࡇࡆࡘࠥࡵࡲࡪࡩ࡬ࡲࠥࡌࡒࡐࡏࠣ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩࠦࡗࡉࡇࡕࡉࠥࡧࡤࡥࡱࡱࡍࡉࠦ࠽ࠡࠤࠪጾ")+pzPE1fgqrkbQOXBmc+On1WZJc6dtksqVNgSQ5GBAjuipe(u"࠭ࠢࠡ࠽ࠪጿ"))
		BbsTmRndZaLY69 = yjNYCMFrPXpAoZHGe7iUJ25g.fetchall()
		if BbsTmRndZaLY69 and iQjV4rPSZyU9zNO6 not in str(BbsTmRndZaLY69): yjNYCMFrPXpAoZHGe7iUJ25g.execute(k5oIaYyp2mnrLK49qhzS(u"ࠧࡖࡒࡇࡅ࡙ࡋࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦࠣࡗࡊ࡚ࠠࡰࡴ࡬࡫࡮ࡴࠠ࠾ࠢࠥࠫፀ")+iQjV4rPSZyU9zNO6+AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"ࠨࠤ࡛ࠣࡍࡋࡒࡆࠢࡤࡨࡩࡵ࡮ࡊࡆࠣࡁࠥࠨࠧፁ")+pzPE1fgqrkbQOXBmc+ObuCsdoDtKmhPLSMH8YGan(u"ࠩࠥࠤࡀ࠭ፂ"))
		KsH3k8CacoJ02IpVA = S5fhsRT8JV(u"ࠪࡦࡱࡧࡣ࡬࡮࡬ࡷࡹ࠭ፃ") if xicJPb0AW1nsRfH3kCv7 else SGazRxP3yBKZ15ILuch(u"ࠫࡺࡶࡤࡢࡶࡨࡣࡷࡻ࡬ࡦࡵࠪፄ")
		yjNYCMFrPXpAoZHGe7iUJ25g.execute(TtyzcuW45VKA(u"࡙ࠬࡅࡍࡇࡆࡘࠥ࠰ࠠࡇࡔࡒࡑࠥ࠭ፅ")+KsH3k8CacoJ02IpVA+tRnTydV03Xfi7rbQ(u"࠭ࠠࡘࡊࡈࡖࡊࠦࡡࡥࡦࡲࡲࡎࡊࠠ࠾ࠢࠥࠫፆ")+pzPE1fgqrkbQOXBmc+aar0zhDnJsOTP7EdgR16HIS29(u"ࠧࠣࠢ࠾ࠫፇ"))
		BbsTmRndZaLY69 = yjNYCMFrPXpAoZHGe7iUJ25g.fetchall()
		if BbsTmRndZaLY69:
			if showDialogs: BoyIUWYSNR0jhDxQwvJriO4PkL = JyLdvftP3CU(cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠨษ็ฮาี๊ฬࠢส่ศ๎ส้็สฮ๏้๊ࠡๆศฺฬ็ษࠡ࡞ࡱࠤࠬፈ")+pzPE1fgqrkbQOXBmc+rbUkdYi32PJaRtnxhDvQs(u"ࠩࠣࡠࡳࡢ࡮ࠡࠩፉ")+Gzygq01Kcb9U3+HC9xWUMpBQJEuTteAqjd(u"ࠪࠤ๊ะ่ใใࠣ์้อ๋ࠠ฻่่ࠥ࠴࠮้ࠡ็ࠤฯื๊ะࠢอๅ฾๐ไ่ࠢส่ว์ࠠภࠣࠤࠤࠬፊ")+kH8E2zqNyims6KJfI+LJPOQNK1mcG(u"ࠫࠥࡢ࡮࡝ࡰࠣฮุะื๋฻ࠣษ๏่วโ้ࠣฬุํ่ๅหࠣ฽๋ีࠠศๆ฼์ิฯࠠฦๆ์ࠤ์ึ็ࠡษ็ุฬฺษࠡษ็้ํา่ะหࠣๅ๏ࠦโศศ่อࠥ฻๊ศ่ฬࠤอืๆศ็ฯࠤ฾๋วะࠩፋ"))
			else: BoyIUWYSNR0jhDxQwvJriO4PkL = hiuZa0PIsErm6UC7
			if BoyIUWYSNR0jhDxQwvJriO4PkL==hiuZa0PIsErm6UC7:
				M96Up8uv53tdBT = IZQbmFzLHDtXfc
				yjNYCMFrPXpAoZHGe7iUJ25g.execute(vbYokBuWlxeLDcdVNM60(u"ࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࠫፌ")+KsH3k8CacoJ02IpVA+zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"࠭ࠠࡘࡊࡈࡖࡊࠦࡡࡥࡦࡲࡲࡎࡊࠠ࠾ࠢࠥࠫፍ")+pzPE1fgqrkbQOXBmc+f8Ja1q5eO02B(u"ࠧࠣࠢ࠾ࠫፎ"))
		elif AV9P4nfxNjSWUrihtzplM2GCJdDgQ:
			if showDialogs: BoyIUWYSNR0jhDxQwvJriO4PkL = JyLdvftP3CU(cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,xN4fKmsnyM3Y2(u"ࠨษ็ฮาี๊ฬࠢส่ศ๎ส้็สฮ๏้๊ࠡๆศฺฬ็ษࠡ࡞ࡱࠤࠬፏ")+pzPE1fgqrkbQOXBmc+WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠩࠣࡠࡳࡢ࡮ࠡࠩፐ")+Gzygq01Kcb9U3+iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠪࠤ๊็ูๅ๋ࠢ๎฾๋ไࠡ࠰࠱ࠤ์๊ࠠหำํำࠥห๊ใษไ๋ࠥอไร่ࠣรࠦࠧࠠࠨፑ")+kH8E2zqNyims6KJfI+k5oIaYyp2mnrLK49qhzS(u"ࠫࠥࡢ࡮࡝ࡰࠣฮุะื๋฻ࠣฮๆ฿๊ๅ้ࠣฬุํ่ๅหࠣ฽๋ีࠠศๆ฼์ิฯࠠฦๆ์ࠤ์ึ็ࠡษ็ุฬฺษࠡษ็้ํา่ะหࠣๅ๏ࠦโศศ่อࠥ฻๊ศ่ฬࠤอืๆศ็ฯࠤ฾๋วะࠩፒ"))
			else: BoyIUWYSNR0jhDxQwvJriO4PkL = hiuZa0PIsErm6UC7
			if BoyIUWYSNR0jhDxQwvJriO4PkL==hiuZa0PIsErm6UC7:
				M96Up8uv53tdBT = IZQbmFzLHDtXfc
				if xicJPb0AW1nsRfH3kCv7: yjNYCMFrPXpAoZHGe7iUJ25g.execute(tRnTydV03Xfi7rbQ(u"ࠬࡏࡎࡔࡇࡕࡘࠥࡏࡎࡕࡑࠣࠫፓ")+KsH3k8CacoJ02IpVA+LJPOQNK1mcG(u"࠭ࠠࠩࡣࡧࡨࡴࡴࡉࡅ࡚ࠫࠣࡆࡒࡕࡆࡕࠣࠬࠧ࠭ፔ")+pzPE1fgqrkbQOXBmc+vbYokBuWlxeLDcdVNM60(u"ࠧࠣࠫࠣ࠿ࠬፕ"))
				else: yjNYCMFrPXpAoZHGe7iUJ25g.execute(aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠨࡋࡑࡗࡊࡘࡔࠡࡋࡑࡘࡔࠦࠧፖ")+KsH3k8CacoJ02IpVA+AiCor1fIVTDxQUWwHe9vPR7(u"ࠩࠣࠬࡦࡪࡤࡰࡰࡌࡈ࠱ࡻࡰࡥࡣࡷࡩࡗࡻ࡬ࡦ࡚ࠫࠣࡆࡒࡕࡆࡕࠣࠬࠧ࠭ፗ")+pzPE1fgqrkbQOXBmc+YnHG75e2QWwo(u"ࠪࠦ࠱࠷ࠩࠡ࠽ࠪፘ"))
	except: succeeded = ksTLSoVGg0ht
	DeQmLbJv6YKcgSOTNz.commit()
	DeQmLbJv6YKcgSOTNz.close()
	if M96Up8uv53tdBT:
		bD7kJZhMCdaqF68P45KlNIgO1.sleep(LungQF89BqemOb32jJsZlW(u"࠲᏾"))
		bu6LzUQF7K.executebuiltin(On1WZJc6dtksqVNgSQ5GBAjuipe(u"࡚ࠫࡶࡤࡢࡶࡨࡐࡴࡩࡡ࡭ࡃࡧࡨࡴࡴࡳࠨፙ"))
		bD7kJZhMCdaqF68P45KlNIgO1.sleep(zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"࠳᏿"))
		if showDialogs:
			if succeeded: NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,S5fhsRT8JV(u"ࠬ์ฬฮฬࠣ฽๊๊๊สࠢศู้ออࠡฬะำ๏ัࠠศๆศฺฬ็ษࠡ࡞ࡱࡠࡳ࠭ፚ")+pzPE1fgqrkbQOXBmc)
			else: NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,TtyzcuW45VKA(u"࠭แีๆอࠤ฾๋ไ๋หࠣษฺ๊วฮࠢอัิ๐หࠡษ็ษ฻อแสࠢ࡟ࡲࡡࡴࠧ፛")+pzPE1fgqrkbQOXBmc)
	return M96Up8uv53tdBT
def gjNVceSkUyC72BlTpz(HBP0ivFbdy2ZgIq15XJWCl4Yf9,showDialogs,hEj2imuGSCYBLJnX1pIg,AV9P4nfxNjSWUrihtzplM2GCJdDgQ):
	Hgd2k9RXymZVqcw = sMmGpryoLIThV1KYO3xA05v9dgFXD(HBP0ivFbdy2ZgIq15XJWCl4Yf9)
	vjtHg7VpYd46 = ksTLSoVGg0ht
	for pzPE1fgqrkbQOXBmc in HBP0ivFbdy2ZgIq15XJWCl4Yf9:
		succeeded,aOoLTMtGmxAVin80FXlsQwvIedE,qgtRKQI20sJ3ixD9TNF6bBrhwmvof = OnpfSh5RvPUTjdD7BI4uJeo(pzPE1fgqrkbQOXBmc,showDialogs,hEj2imuGSCYBLJnX1pIg,Hgd2k9RXymZVqcw)
		M96Up8uv53tdBT = NOgUfGTJty8DjbFWIL5iAzxBZ7E3V(pzPE1fgqrkbQOXBmc,showDialogs,AV9P4nfxNjSWUrihtzplM2GCJdDgQ)
		if M96Up8uv53tdBT: vjtHg7VpYd46 = IZQbmFzLHDtXfc
	if vjtHg7VpYd46:
		bD7kJZhMCdaqF68P45KlNIgO1.sleep(S5fhsRT8JV(u"࠴᐀"))
		bu6LzUQF7K.executebuiltin(aar0zhDnJsOTP7EdgR16HIS29(u"ࠧࡖࡲࡧࡥࡹ࡫ࡌࡰࡥࡤࡰࡆࡪࡤࡰࡰࡶࠫ፜"))
		bD7kJZhMCdaqF68P45KlNIgO1.sleep(tRnTydV03Xfi7rbQ(u"࠵ᐁ"))
	if showDialogs:
		if len(HBP0ivFbdy2ZgIq15XJWCl4Yf9)>YnHG75e2QWwo(u"࠶ᐂ"): NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,s8fcjBCSMxzAIkZQbJPga(u"ࠨฬ่ࠤอ์ฬศฯࠣๅา฻ࠠอ็ํ฽ࠥอไฦุสๅฬะࠧ፝"))
		else: NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,LungQF89BqemOb32jJsZlW(u"ࠩอ้ࠥฮๆอษะࠤๆำีࠡษ็ษ฻อแส࡞ࡱࡠࡳ࠭፞")+HBP0ivFbdy2ZgIq15XJWCl4Yf9[LJPOQNK1mcG(u"࠶ᐃ")])
	return
def p1mcA6LasBxC7YKGPV0kJRFMfS(showDialogs):
	Q1BIwu9dhnVNo6OzJPMrc2e = [s8fcjBCSMxzAIkZQbJPga(u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨ፟"),NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠭፠"),xN4fKmsnyM3Y2(u"ࠬࡹࡣࡳ࡫ࡳࡸ࠳ࡳ࡯ࡥࡷ࡯ࡩ࠳ࡸࡥࡴࡱ࡯ࡺࡪࡻࡲ࡭ࠩ፡"),SGazRxP3yBKZ15ILuch(u"࠭ࡳࡤࡴ࡬ࡴࡹ࠴࡭ࡰࡦࡸࡰࡪ࠴ࡹࡵ࠯ࡧࡰࡵ࠭።")]
	q1tK6bdB9laiYo = [iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥ࠰ࡲࡸ࡭࡫ࡲࡴࠩ፣"),f8Ja1q5eO02B(u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦ࠱࡫࡮ࡺࡥࡦࠩ፤"),YnHG75e2QWwo(u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧ࠲ࡵࡿࡴࡩࡱࡱࡥࡳࡿࡷࡩࡧࡵࡩࠬ፥"),aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨ࠳࡭ࡩࡵࡪࡸࡦࠬ፦"),vbYokBuWlxeLDcdVNM60(u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠴ࡧࡪࡶࡨࡥࠬ፧"),tRnTydV03Xfi7rbQ(u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪ࠮ࡤࡱࡧࡩࡧ࡫ࡲࡨࠩ፨")]
	for pzPE1fgqrkbQOXBmc in q1tK6bdB9laiYo: aUW1tsJOhEK5H(pzPE1fgqrkbQOXBmc)
	gjNVceSkUyC72BlTpz(Q1BIwu9dhnVNo6OzJPMrc2e,showDialogs,ksTLSoVGg0ht,ksTLSoVGg0ht)
	return
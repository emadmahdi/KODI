# -*- coding: utf-8 -*-
from RgJNGc7YMP import *
headers = { 'User-Agent' : cdZKMn68Pzg4 }
UkXlAzsMcamKJrEIgnxi6bWh = 'AKWAM'
nc3GLkA65oxOd = '_AKW_'
cDTdfqVAF0BLGiX364IEwaZbr = USuRxnPlV5.SITESURLS[UkXlAzsMcamKJrEIgnxi6bWh][0]
watxrZHms34F7gXUOAWoTlu1NqCf = cdZKMn68Pzg4
cJWUPuDGM0Yybv5a9KnIrVzhH78 = ['ألعاب','المصارعة الحرة','القران الكريم','الكتب و الابحاث','الصور و الخلفيات','المسلسلات الاذاعية']
def HHN5EpbszV3iA2m89hGSQjaPgUZy(mode,url,text):
	if   mode==240: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = kUq58vC7x9hWma164JejMKQ()
	elif mode==241: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = GDQUH4fN02sIt81mAcY(url,text)
	elif mode==242: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = yIZWSuMpvs3(url)
	elif mode==243: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = RPZbqous7rtdy56LeI18Cv04AKHW(url)
	elif mode==244: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = XxcpMKIUzr0sVDngR(url,'FILTERS___'+text)
	elif mode==245: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = XxcpMKIUzr0sVDngR(url,'CATEGORIES___'+text)
	elif mode==246: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = puWVoBFSQjqI7hMXzOgK59Usbxkda(url)
	elif mode==247: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = I6hlmRPSW04(url)
	elif mode==248: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = DGXL3QRbnHyv5ofxNkm09csJSVrqgF()
	elif mode==249: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = z4hetAJw3NaT9ROjG6xbZ5CHlW81(text)
	else: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = False
	return xsGUcR3ef6glKY5hQwpFXEaSt2mrIz
def DGXL3QRbnHyv5ofxNkm09csJSVrqgF():
	NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,'هذا الموقع "أكوام الجديد" في بعض الأحيان فيه نوع من الحجب ضد البرامج . وهذا يسبب مشكلة في تشغيل الفيديوهات . هذه المشكلة سببها من الموقع الأصلي وهي تظهر وتختفي بصورة عشوائية')
	return
def kUq58vC7x9hWma164JejMKQ():
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',cDTdfqVAF0BLGiX364IEwaZbr,cdZKMn68Pzg4,headers,cdZKMn68Pzg4,cdZKMn68Pzg4,'AKWAM-MENU-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	aqWQ6yRmMHr7Bt8NCkgpVP2hs = ffUFBJQ57j2XgoGeOLn9uwpC.findall('home-site-btn-container.*?href="(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if aqWQ6yRmMHr7Bt8NCkgpVP2hs: aqWQ6yRmMHr7Bt8NCkgpVP2hs = aqWQ6yRmMHr7Bt8NCkgpVP2hs[0]
	else: aqWQ6yRmMHr7Bt8NCkgpVP2hs = cDTdfqVAF0BLGiX364IEwaZbr
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',aqWQ6yRmMHr7Bt8NCkgpVP2hs,cdZKMn68Pzg4,headers,cdZKMn68Pzg4,cdZKMn68Pzg4,'AKWAM-MENU-2nd')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'بحث في الموقع',cdZKMn68Pzg4,249,cdZKMn68Pzg4,cdZKMn68Pzg4,'_REMEMBERRESULTS_')
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'فلتر محدد',cDTdfqVAF0BLGiX364IEwaZbr,246)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'فلتر كامل',cDTdfqVAF0BLGiX364IEwaZbr,247)
	zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+'المميزة',aqWQ6yRmMHr7Bt8NCkgpVP2hs,241,cdZKMn68Pzg4,cdZKMn68Pzg4,'featured')
	pE6jR53J0WNIZ2v = ffUFBJQ57j2XgoGeOLn9uwpC.findall('recently-container.*?href="(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	c0cDhidBlOn7 = pE6jR53J0WNIZ2v[0]
	zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+'أضيف حديثا',c0cDhidBlOn7,241)
	zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('mb-4 d-flex align-items-center.*?href="(.*?)".*?class="header-link text-white">(.*?)<.*?class="menu"(.*?)</div>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	for c0cDhidBlOn7,name,KdWauEhgN6OQzjRVm1ro8tkB3 in ppvsMqCHf8SEzxQg:
		if name in cJWUPuDGM0Yybv5a9KnIrVzhH78: continue
		zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+name,c0cDhidBlOn7,241)
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)">(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,title in items:
			if title in cJWUPuDGM0Yybv5a9KnIrVzhH78: continue
			title = name+VBpIH2QSmvDGlA6TO3e+title
			zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+title,c0cDhidBlOn7,241)
	return
def puWVoBFSQjqI7hMXzOgK59Usbxkda(website=cdZKMn68Pzg4):
	OO1cj2REUZHJ8x5V = Gc05Efm73C8s(r43t1YI9deXA5N,cDTdfqVAF0BLGiX364IEwaZbr,cdZKMn68Pzg4,headers,cdZKMn68Pzg4,'AKWAM-MENU-1st')
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="menu(.*?)<nav',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?text">(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,title in items:
			if title not in cJWUPuDGM0Yybv5a9KnIrVzhH78:
				title = title+' مصنفة'
				zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,245)
		if website==cdZKMn68Pzg4: zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	return OO1cj2REUZHJ8x5V
def I6hlmRPSW04(website=cdZKMn68Pzg4):
	OO1cj2REUZHJ8x5V = Gc05Efm73C8s(r43t1YI9deXA5N,cDTdfqVAF0BLGiX364IEwaZbr,cdZKMn68Pzg4,headers,cdZKMn68Pzg4,'AKWAM-MENU-1st')
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="menu(.*?)<nav',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?text">(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,title in items:
			if title not in cJWUPuDGM0Yybv5a9KnIrVzhH78:
				title = title+' مفلترة'
				zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,244)
		if website==cdZKMn68Pzg4: zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	return OO1cj2REUZHJ8x5V
def GDQUH4fN02sIt81mAcY(url,type=cdZKMn68Pzg4):
	OO1cj2REUZHJ8x5V = Gc05Efm73C8s(K8DZxE74Afz52gBYbOMtpvql0RJma,url,cdZKMn68Pzg4,headers,True,'AKWAM-TITLES-1st')
	if type=='featured': ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('swiper-container(.*?)swiper-button-prev',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	else: ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="widget"(.*?)main-footer',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('data-src="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if not items:
			items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('src="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for y90BoFz8MA1ZThaSC2ILXHiK3OY6w,c0cDhidBlOn7,title in items:
			if '/series/' in c0cDhidBlOn7 or '/shows/' in c0cDhidBlOn7:
				zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,242,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
			elif '/movies/' in c0cDhidBlOn7:
				zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,243,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
			elif '/games/' not in c0cDhidBlOn7:
				zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,243,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('pagination(.*?)</div>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?>(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,title in items:
			if title=='&lsaquo;': title = 'سابقة'
			if title=='&rsaquo;': title = 'لاحقة'
			c0cDhidBlOn7 = gbd90SjF2mZqf81IRDaTwJkWu(c0cDhidBlOn7)
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'صفحة '+title,c0cDhidBlOn7,241)
	return
def z4hetAJw3NaT9ROjG6xbZ5CHlW81(search):
	search,EL8zUgbXheot,showDialogs = qbIcHCMdkFKn21e(search)
	if search==cdZKMn68Pzg4: search = BzkmLuvJD9n25Pg()
	if search==cdZKMn68Pzg4: return
	nuKdVC6ePlg = search.replace(VBpIH2QSmvDGlA6TO3e,'%20')
	url = cDTdfqVAF0BLGiX364IEwaZbr + '/search?q='+nuKdVC6ePlg
	xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = GDQUH4fN02sIt81mAcY(url)
	return
def yIZWSuMpvs3(url):
	OO1cj2REUZHJ8x5V = Gc05Efm73C8s(K8DZxE74Afz52gBYbOMtpvql0RJma,url,cdZKMn68Pzg4,headers,True,'AKWAM-EPISODES-1st')
	if '-episodes">' not in OO1cj2REUZHJ8x5V:
		y90BoFz8MA1ZThaSC2ILXHiK3OY6w = bu6LzUQF7K.getInfoLabel('ListItem.Icon')
		zJLApFBcIhnSj('video',nc3GLkA65oxOd+'رابط التشغيل',url,243,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
	else:
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('-episodes">(.*?)<div class="widget-4',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		PCktNV4H3DEOSpeh = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(http.*?)".*?>(.*?)<.*?src="(.*?)"',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,title,y90BoFz8MA1ZThaSC2ILXHiK3OY6w in PCktNV4H3DEOSpeh:
			title = title.replace(wr0HaqRdJ2D9LT7nSO1KMe38ly,VBpIH2QSmvDGlA6TO3e)
			if 'الحلقات' in title or 'مواسم اخرى' in title: continue
			if '/series/' in c0cDhidBlOn7: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,242,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
			else: zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,243,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
	return
def RPZbqous7rtdy56LeI18Cv04AKHW(url):
	OO1cj2REUZHJ8x5V = Gc05Efm73C8s(r43t1YI9deXA5N,url,cdZKMn68Pzg4,headers,True,'AKWAM-PLAY-1st')
	eVdYQAPy2Dm = ffUFBJQ57j2XgoGeOLn9uwpC.findall('badge-danger.*?>(.*?)<',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if eVdYQAPy2Dm and bMOpKuUkQ5J2(UkXlAzsMcamKJrEIgnxi6bWh,url,eVdYQAPy2Dm): return
	sLjO6pgBJwuAF4IqZMU7N2EG = ffUFBJQ57j2XgoGeOLn9uwpC.findall('li><a href="#(.*?)".*?>(.*?)<',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	pcX7zxFRmsADwUr,lycT0JB1noerD5YANK2PbHa8QVM,akIvSitzr0mKe,hKbEIezisQknlgofH8aVO1t = [],[],[],[]
	if sLjO6pgBJwuAF4IqZMU7N2EG:
		eAbnqlfDFHjkQh2wB3vW0JR = 'mp4'
		for LZ0yPKTn4UwcgsS,l1MCIuwhAELbO2eJ96kNta7rp0B in sLjO6pgBJwuAF4IqZMU7N2EG:
			ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('tab-content quality" id="'+LZ0yPKTn4UwcgsS+'".*?</div>.\s*</div>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
			akIvSitzr0mKe.append(KdWauEhgN6OQzjRVm1ro8tkB3)
			hKbEIezisQknlgofH8aVO1t.append(l1MCIuwhAELbO2eJ96kNta7rp0B)
	else:
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="qualities(.*?)<h3.*?>(.*?)<',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if not ppvsMqCHf8SEzxQg:
			NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,'لا يوجد ملف فيديو في هذا الرابط')
			return
		else:
			KdWauEhgN6OQzjRVm1ro8tkB3,filename = ppvsMqCHf8SEzxQg[0]
			Q4MzfNTaSYmJBe8FInOqGldjtv7D = ['zip','rar','txt','pdf','htm','tar','iso','html']
			eAbnqlfDFHjkQh2wB3vW0JR = filename.rsplit('.',1)[1].strip(VBpIH2QSmvDGlA6TO3e)
			if eAbnqlfDFHjkQh2wB3vW0JR in Q4MzfNTaSYmJBe8FInOqGldjtv7D:
				NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,'الملف ليس فيديو ولا صوت')
				return
		akIvSitzr0mKe.append(KdWauEhgN6OQzjRVm1ro8tkB3)
		hKbEIezisQknlgofH8aVO1t.append(cdZKMn68Pzg4)
	for WCqkctAYD2O3Hz7Fl8fKRS5 in range(len(akIvSitzr0mKe)):
		zz4ZPovUbyk5GEhNMs8JDnaVXftS = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?icon-(.*?)"',akIvSitzr0mKe[WCqkctAYD2O3Hz7Fl8fKRS5],ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,DvHAG1yr8fg7T in zz4ZPovUbyk5GEhNMs8JDnaVXftS:
			if 'torrent' in DvHAG1yr8fg7T: continue
			elif 'download' in DvHAG1yr8fg7T: type = 'download'
			elif 'play' in DvHAG1yr8fg7T: type = 'watch'
			else: type = 'unknown'
			c0cDhidBlOn7 = c0cDhidBlOn7+'?named=__'+type+'____'+hKbEIezisQknlgofH8aVO1t[WCqkctAYD2O3Hz7Fl8fKRS5]+'__akwam'
			pcX7zxFRmsADwUr.append(c0cDhidBlOn7)
	import r0y4XTKznF
	r0y4XTKznF.noHliPXkcg3pJTdSauCvm5sU(pcX7zxFRmsADwUr,UkXlAzsMcamKJrEIgnxi6bWh,'video',url)
	return
def XxcpMKIUzr0sVDngR(url,filter):
	fCAW9dmInLiV = ['section','category','year','rating']
	if '?' in url: url = url.split('?')[0]
	type,filter = filter.split('___',1)
	if filter==cdZKMn68Pzg4: KFGqxsBnZYLb3NvMU,ejQ8ZCtBaV7 = cdZKMn68Pzg4,cdZKMn68Pzg4
	else: KFGqxsBnZYLb3NvMU,ejQ8ZCtBaV7 = filter.split('___')
	if type=='CATEGORIES':
		if fCAW9dmInLiV[0]+'=' not in KFGqxsBnZYLb3NvMU: rrb0SF6otehufCYOX4 = fCAW9dmInLiV[0]
		for WCqkctAYD2O3Hz7Fl8fKRS5 in range(len(fCAW9dmInLiV[0:-1])):
			if fCAW9dmInLiV[WCqkctAYD2O3Hz7Fl8fKRS5]+'=' in KFGqxsBnZYLb3NvMU: rrb0SF6otehufCYOX4 = fCAW9dmInLiV[WCqkctAYD2O3Hz7Fl8fKRS5+1]
		gmjZQuBFv8RzlNtDVEOc = KFGqxsBnZYLb3NvMU+'&'+rrb0SF6otehufCYOX4+'=0'
		qwmxUpZfQj8EAV3Tc = ejQ8ZCtBaV7+'&'+rrb0SF6otehufCYOX4+'=0'
		vMp6jZbo3UkEsSxRFQndyA = gmjZQuBFv8RzlNtDVEOc.strip('&')+'___'+qwmxUpZfQj8EAV3Tc.strip('&')
		YqrzmSVb3R9MgUnX2auEHlpBhZD = XFoM2xPKIt3u51hLj(ejQ8ZCtBaV7,'all')
		HOCWKhxITtulVGX = url+'?'+YqrzmSVb3R9MgUnX2auEHlpBhZD
	elif type=='FILTERS':
		zM2ZBJ4IYN8osGTtwgRheLu6dU = XFoM2xPKIt3u51hLj(KFGqxsBnZYLb3NvMU,'modified_values')
		zM2ZBJ4IYN8osGTtwgRheLu6dU = NLqxoZ37dYf0awrsIE(zM2ZBJ4IYN8osGTtwgRheLu6dU)
		if ejQ8ZCtBaV7!=cdZKMn68Pzg4: ejQ8ZCtBaV7 = XFoM2xPKIt3u51hLj(ejQ8ZCtBaV7,'all')
		if ejQ8ZCtBaV7==cdZKMn68Pzg4: HOCWKhxITtulVGX = url
		else: HOCWKhxITtulVGX = url+'?'+ejQ8ZCtBaV7
		zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'أظهار قائمة الفيديو التي تم اختيارها',HOCWKhxITtulVGX,241,cdZKMn68Pzg4,'1')
		zJLApFBcIhnSj('folder',nc3GLkA65oxOd+' [[   '+zM2ZBJ4IYN8osGTtwgRheLu6dU+'   ]]',HOCWKhxITtulVGX,241,cdZKMn68Pzg4,'1')
		zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	OO1cj2REUZHJ8x5V = Gc05Efm73C8s(r43t1YI9deXA5N,url,cdZKMn68Pzg4,headers,True,'AKWAM-FILTERS_MENU-1st')
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('<form id(.*?)</form>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
	hQ9ADnZlSxI1m8ui = ffUFBJQ57j2XgoGeOLn9uwpC.findall('<select.*?name="(.*?)".*?">(.*?)<(.*?)</select>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	dict = {}
	for rfJG62Vo0pTEljwPN1WahD7sx4t3QR,name,KdWauEhgN6OQzjRVm1ro8tkB3 in hQ9ADnZlSxI1m8ui:
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('<option(.*?)>(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if '=' not in HOCWKhxITtulVGX: HOCWKhxITtulVGX = url
		if type=='CATEGORIES':
			if rrb0SF6otehufCYOX4!=rfJG62Vo0pTEljwPN1WahD7sx4t3QR: continue
			elif len(items)<=1:
				if rfJG62Vo0pTEljwPN1WahD7sx4t3QR==fCAW9dmInLiV[-1]: GDQUH4fN02sIt81mAcY(HOCWKhxITtulVGX)
				else: XxcpMKIUzr0sVDngR(HOCWKhxITtulVGX,'CATEGORIES___'+vMp6jZbo3UkEsSxRFQndyA)
				return
			else:
				if rfJG62Vo0pTEljwPN1WahD7sx4t3QR==fCAW9dmInLiV[-1]: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'الجميع',HOCWKhxITtulVGX,241,cdZKMn68Pzg4,'1')
				else: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'الجميع',HOCWKhxITtulVGX,245,cdZKMn68Pzg4,cdZKMn68Pzg4,vMp6jZbo3UkEsSxRFQndyA)
		elif type=='FILTERS':
			gmjZQuBFv8RzlNtDVEOc = KFGqxsBnZYLb3NvMU+'&'+rfJG62Vo0pTEljwPN1WahD7sx4t3QR+'=0'
			qwmxUpZfQj8EAV3Tc = ejQ8ZCtBaV7+'&'+rfJG62Vo0pTEljwPN1WahD7sx4t3QR+'=0'
			vMp6jZbo3UkEsSxRFQndyA = gmjZQuBFv8RzlNtDVEOc+'___'+qwmxUpZfQj8EAV3Tc
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'الجميع : '+name,HOCWKhxITtulVGX,244,cdZKMn68Pzg4,cdZKMn68Pzg4,vMp6jZbo3UkEsSxRFQndyA)
		dict[rfJG62Vo0pTEljwPN1WahD7sx4t3QR] = {}
		for value,zj6FI51Rypka0e8xiECfc7g in items:
			if zj6FI51Rypka0e8xiECfc7g in cJWUPuDGM0Yybv5a9KnIrVzhH78: continue
			if 'value' not in value: value = zj6FI51Rypka0e8xiECfc7g
			else: value = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"(.*?)"',value,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)[0]
			dict[rfJG62Vo0pTEljwPN1WahD7sx4t3QR][value] = zj6FI51Rypka0e8xiECfc7g
			gmjZQuBFv8RzlNtDVEOc = KFGqxsBnZYLb3NvMU+'&'+rfJG62Vo0pTEljwPN1WahD7sx4t3QR+'='+zj6FI51Rypka0e8xiECfc7g
			qwmxUpZfQj8EAV3Tc = ejQ8ZCtBaV7+'&'+rfJG62Vo0pTEljwPN1WahD7sx4t3QR+'='+value
			AL8gJZ0NtE91Bexjin4 = gmjZQuBFv8RzlNtDVEOc+'___'+qwmxUpZfQj8EAV3Tc
			title = zj6FI51Rypka0e8xiECfc7g+' : '#+dict[rfJG62Vo0pTEljwPN1WahD7sx4t3QR]['0']
			title = zj6FI51Rypka0e8xiECfc7g+' : '+name
			if type=='FILTERS': zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,url,244,cdZKMn68Pzg4,cdZKMn68Pzg4,AL8gJZ0NtE91Bexjin4)
			elif type=='CATEGORIES' and fCAW9dmInLiV[-2]+'=' in KFGqxsBnZYLb3NvMU:
				YqrzmSVb3R9MgUnX2auEHlpBhZD = XFoM2xPKIt3u51hLj(qwmxUpZfQj8EAV3Tc,'all')
				N8jUpQxY0rhtDAzbG4kOs9X = url+'?'+YqrzmSVb3R9MgUnX2auEHlpBhZD
				zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,N8jUpQxY0rhtDAzbG4kOs9X,241,cdZKMn68Pzg4,'1')
			else: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,url,245,cdZKMn68Pzg4,cdZKMn68Pzg4,AL8gJZ0NtE91Bexjin4)
	return
def XFoM2xPKIt3u51hLj(o3JURfrMDgp76,mode):
	o3JURfrMDgp76 = o3JURfrMDgp76.strip('&')
	bLxfgF7nlO1uZiY9e5T0HDdIw3kpy = {}
	if '=' in o3JURfrMDgp76:
		items = o3JURfrMDgp76.split('&')
		for HYBN2AQsjimSMgT8OvE3ynX67tJwR in items:
			IN0jyfe1PRdDz6YX3CoJkHthw,value = HYBN2AQsjimSMgT8OvE3ynX67tJwR.split('=')
			bLxfgF7nlO1uZiY9e5T0HDdIw3kpy[IN0jyfe1PRdDz6YX3CoJkHthw] = value
	n7VBe6ZgDI14lizTfHOmk = cdZKMn68Pzg4
	w6wuL59PgeE = ['section','category','rating','year','language','formats','quality']
	for key in w6wuL59PgeE:
		if key in list(bLxfgF7nlO1uZiY9e5T0HDdIw3kpy.keys()): value = bLxfgF7nlO1uZiY9e5T0HDdIw3kpy[key]
		else: value = '0'
		if mode=='modified_values' and value!='0': n7VBe6ZgDI14lizTfHOmk = n7VBe6ZgDI14lizTfHOmk+' + '+value
		elif mode=='modified_filters' and value!='0': n7VBe6ZgDI14lizTfHOmk = n7VBe6ZgDI14lizTfHOmk+'&'+key+'='+value
		elif mode=='all': n7VBe6ZgDI14lizTfHOmk = n7VBe6ZgDI14lizTfHOmk+'&'+key+'='+value
	n7VBe6ZgDI14lizTfHOmk = n7VBe6ZgDI14lizTfHOmk.strip(' + ')
	n7VBe6ZgDI14lizTfHOmk = n7VBe6ZgDI14lizTfHOmk.strip('&')
	return n7VBe6ZgDI14lizTfHOmk
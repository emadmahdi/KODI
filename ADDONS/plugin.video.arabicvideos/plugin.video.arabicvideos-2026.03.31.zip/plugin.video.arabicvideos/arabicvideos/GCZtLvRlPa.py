# -*- coding: utf-8 -*-
from RgJNGc7YMP import *
UkXlAzsMcamKJrEIgnxi6bWh = 'SERIES4WATCH'
headers = { 'User-Agent' : cdZKMn68Pzg4 }
nc3GLkA65oxOd = '_SFW_'
cDTdfqVAF0BLGiX364IEwaZbr = USuRxnPlV5.SITESURLS[UkXlAzsMcamKJrEIgnxi6bWh][0]
def HHN5EpbszV3iA2m89hGSQjaPgUZy(mode,url,text):
	if   mode==210: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = kUq58vC7x9hWma164JejMKQ()
	elif mode==211: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = GDQUH4fN02sIt81mAcY(url)
	elif mode==212: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = RPZbqous7rtdy56LeI18Cv04AKHW(url)
	elif mode==213: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = yIZWSuMpvs3(url)
	elif mode==214: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = OUP6xTvzhj(url)
	elif mode==215: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = YaXIvdknSMpAoL6jRw(url)
	elif mode==218: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = T1vxDYruf2cbRd7lz5S6o8G0()
	elif mode==219: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = z4hetAJw3NaT9ROjG6xbZ5CHlW81(text)
	else: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = False
	return xsGUcR3ef6glKY5hQwpFXEaSt2mrIz
def T1vxDYruf2cbRd7lz5S6o8G0():
	message = 'هذا الموقع تغير بالكامل ... وبحاجة الى اعادة برمجة من الصفر ... والمبرمج حاليا مشغول ويعاني من وعكة صحية ... ولهذا سوف يبقى الموقع مغلق الى ما شاء الله'
	NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,'الموقع تغير بالكامل',message)
	return
def kUq58vC7x9hWma164JejMKQ():
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'بحث في الموقع',cdZKMn68Pzg4,219,cdZKMn68Pzg4,cdZKMn68Pzg4,'_REMEMBERRESULTS_')
	url = cDTdfqVAF0BLGiX364IEwaZbr+'/getpostsPin?type=one&data=pin&limit=25'
	zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+'المميزة',url,211)
	OO1cj2REUZHJ8x5V = Gc05Efm73C8s(r43t1YI9deXA5N,cDTdfqVAF0BLGiX364IEwaZbr,cdZKMn68Pzg4,headers,cdZKMn68Pzg4,'SERIES4WATCH-MENU-1st')
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('FiltersButtons(.*?)</div>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
	items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('data-get="(.*?)".*?</i>(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	for c0cDhidBlOn7,title in items:
		url = cDTdfqVAF0BLGiX364IEwaZbr+'/getposts?type=one&data='+c0cDhidBlOn7
		zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+title,url,211)
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('navigation-menu(.*?)</div>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
	items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(http.*?)">(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	cJWUPuDGM0Yybv5a9KnIrVzhH78 = ['مسلسلات انمي','الرئيسية']
	for c0cDhidBlOn7,title in items:
		title = title.strip(VBpIH2QSmvDGlA6TO3e)
		if not any(value in title for value in cJWUPuDGM0Yybv5a9KnIrVzhH78):
			zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+title,c0cDhidBlOn7,211)
	return OO1cj2REUZHJ8x5V
def GDQUH4fN02sIt81mAcY(url):
	OO1cj2REUZHJ8x5V = Gc05Efm73C8s(K8DZxE74Afz52gBYbOMtpvql0RJma,url,cdZKMn68Pzg4,headers,cdZKMn68Pzg4,'SERIES4WATCH-TITLES-1st')
	if 'getposts' in url or '/search?s=' in url: KdWauEhgN6OQzjRVm1ro8tkB3 = OO1cj2REUZHJ8x5V
	else:
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('MediaGrid"(.*?)class="pagination"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if ppvsMqCHf8SEzxQg: KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		else: return
	items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('src="(.*?)".*?href="(.*?)".*?<h3>(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	KRmzvoWYyxfXw37SEh1Q = []
	xxqCJF6pGQna8Nl2SIEM = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for y90BoFz8MA1ZThaSC2ILXHiK3OY6w,c0cDhidBlOn7,title in items:
		if '/series/' in c0cDhidBlOn7: continue
		c0cDhidBlOn7 = NLqxoZ37dYf0awrsIE(c0cDhidBlOn7).strip(KCQExdbYFqM)
		title = gbd90SjF2mZqf81IRDaTwJkWu(title)
		title = title.strip(VBpIH2QSmvDGlA6TO3e)
		if '/film/' in c0cDhidBlOn7 or any(value in title for value in xxqCJF6pGQna8Nl2SIEM):
			zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,212,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
		elif '/episode/' in c0cDhidBlOn7 and 'الحلقة' in title:
			E0w56WHxZPYGVvnTQ4O2t1C8DAjq = ffUFBJQ57j2XgoGeOLn9uwpC.findall('(.*?) الحلقة \d+',title,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			if E0w56WHxZPYGVvnTQ4O2t1C8DAjq:
				title = '_MOD_' + E0w56WHxZPYGVvnTQ4O2t1C8DAjq[0]
				if title not in KRmzvoWYyxfXw37SEh1Q:
					zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,213,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
					KRmzvoWYyxfXw37SEh1Q.append(title)
		else: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,213,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="pagination(.*?)</div>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('<a href=["\'](http.*?)["\'].*?>(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,title in items:
			c0cDhidBlOn7 = gbd90SjF2mZqf81IRDaTwJkWu(c0cDhidBlOn7)
			title = gbd90SjF2mZqf81IRDaTwJkWu(title)
			title = title.replace('الصفحة ',cdZKMn68Pzg4)
			if title!=cdZKMn68Pzg4: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'صفحة '+title,c0cDhidBlOn7,211)
	return
def yIZWSuMpvs3(url):
	ZgceXVUORPtAh96q,items,YYrBisapSDJuyg6hoC7bHtUv29 = -1,[],[]
	OO1cj2REUZHJ8x5V = Gc05Efm73C8s(K8DZxE74Afz52gBYbOMtpvql0RJma,url,cdZKMn68Pzg4,headers,cdZKMn68Pzg4,'SERIES4WATCH-EPISODES-1st')
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('ti-list-numbered(.*?)</div>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		akIvSitzr0mKe = cdZKMn68Pzg4.join(ppvsMqCHf8SEzxQg)
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)"',akIvSitzr0mKe,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	items.append(url)
	items = set(items)
	for c0cDhidBlOn7 in items:
		c0cDhidBlOn7 = c0cDhidBlOn7.strip(KCQExdbYFqM)
		title = '_MOD_' + c0cDhidBlOn7.split(KCQExdbYFqM)[-1].replace('-',VBpIH2QSmvDGlA6TO3e)
		o0oyFGTp3nZdCrAEzlf8XbjJ6 = ffUFBJQ57j2XgoGeOLn9uwpC.findall('الحلقة-(\d+)',c0cDhidBlOn7.split(KCQExdbYFqM)[-1],ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if o0oyFGTp3nZdCrAEzlf8XbjJ6: o0oyFGTp3nZdCrAEzlf8XbjJ6 = o0oyFGTp3nZdCrAEzlf8XbjJ6[0]
		else: o0oyFGTp3nZdCrAEzlf8XbjJ6 = '0'
		YYrBisapSDJuyg6hoC7bHtUv29.append([c0cDhidBlOn7,title,o0oyFGTp3nZdCrAEzlf8XbjJ6])
	items = sorted(YYrBisapSDJuyg6hoC7bHtUv29, reverse=False, key=lambda key: int(key[2]))
	AAb3ShlvsTGu8wgZ = str(items).count('/season/')
	ZgceXVUORPtAh96q = str(items).count('/episode/')
	if AAb3ShlvsTGu8wgZ>1 and ZgceXVUORPtAh96q>0 and '/season/' not in url:
		for c0cDhidBlOn7,title,o0oyFGTp3nZdCrAEzlf8XbjJ6 in items:
			if '/season/' in c0cDhidBlOn7: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,213)
	else:
		for c0cDhidBlOn7,title,o0oyFGTp3nZdCrAEzlf8XbjJ6 in items:
			if '/season/' not in c0cDhidBlOn7: zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,212)
	return
def RPZbqous7rtdy56LeI18Cv04AKHW(url):
	pcX7zxFRmsADwUr = []
	FxVBtGij82cmkq = url.split(KCQExdbYFqM)
	OO1cj2REUZHJ8x5V = Gc05Efm73C8s(r43t1YI9deXA5N,url,cdZKMn68Pzg4,headers,cdZKMn68Pzg4,'SERIES4WATCH-PLAY-1st')
	if '/watch/' in OO1cj2REUZHJ8x5V:
		HOCWKhxITtulVGX = url.replace(FxVBtGij82cmkq[3],'watch')
		JJPEReUDbt0QoWHkL21TA = Gc05Efm73C8s(r43t1YI9deXA5N,HOCWKhxITtulVGX,cdZKMn68Pzg4,headers,cdZKMn68Pzg4,'SERIES4WATCH-PLAY-2nd')
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="servers-list(.*?)</div>',JJPEReUDbt0QoWHkL21TA,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if ppvsMqCHf8SEzxQg:
			KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
			items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('data-embedd="(.*?)".*?server_image">\n(.*?)\n',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			if items:
				id = ffUFBJQ57j2XgoGeOLn9uwpC.findall('post_id=(.*?)"',JJPEReUDbt0QoWHkL21TA,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
				if id:
					gIK4kes9HnLF8p0itS = id[0]
					for c0cDhidBlOn7,title in items:
						c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr+'/?postid='+gIK4kes9HnLF8p0itS+'&serverid='+c0cDhidBlOn7+'?named='+title+'__watch'
						pcX7zxFRmsADwUr.append(c0cDhidBlOn7)
			else:
				items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('data-embedd=".*?(http.*?)("|&quot;)',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
				for c0cDhidBlOn7,tYPfm3ISxD in items:
					pcX7zxFRmsADwUr.append(c0cDhidBlOn7)
	if '/download/' in OO1cj2REUZHJ8x5V:
		HOCWKhxITtulVGX = url.replace(FxVBtGij82cmkq[3],'download')
		JJPEReUDbt0QoWHkL21TA = Gc05Efm73C8s(r43t1YI9deXA5N,HOCWKhxITtulVGX,cdZKMn68Pzg4,headers,cdZKMn68Pzg4,'SERIES4WATCH-PLAY-3rd')
		id = ffUFBJQ57j2XgoGeOLn9uwpC.findall('postId:"(.*?)"',JJPEReUDbt0QoWHkL21TA,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if id:
			gIK4kes9HnLF8p0itS = id[0]
			npaJqziQ13tIH0hLjDdB2cWX7uUMPR = { 'User-Agent':cdZKMn68Pzg4 , 'X-Requested-With':'XMLHttpRequest' }
			HOCWKhxITtulVGX = cDTdfqVAF0BLGiX364IEwaZbr + '/ajaxCenter?_action=getdownloadlinks&postId='+gIK4kes9HnLF8p0itS
			JJPEReUDbt0QoWHkL21TA = Gc05Efm73C8s(r43t1YI9deXA5N,HOCWKhxITtulVGX,cdZKMn68Pzg4,npaJqziQ13tIH0hLjDdB2cWX7uUMPR,cdZKMn68Pzg4,'SERIES4WATCH-PLAY-4th')
			ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('<h3.*?(\d+)(.*?)</div>',JJPEReUDbt0QoWHkL21TA,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			if ppvsMqCHf8SEzxQg:
				for aJk6r45iMBOsjRwNDYXL0u,KdWauEhgN6OQzjRVm1ro8tkB3 in ppvsMqCHf8SEzxQg:
					items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('<td>(.*?)<.*?href="(.*?)"',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
					for name,c0cDhidBlOn7 in items:
						pcX7zxFRmsADwUr.append(c0cDhidBlOn7+'?named='+name+'__download'+'____'+aJk6r45iMBOsjRwNDYXL0u)
			else:
				ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('<h6(.*?)</table>',JJPEReUDbt0QoWHkL21TA,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
				if not ppvsMqCHf8SEzxQg: ppvsMqCHf8SEzxQg = [JJPEReUDbt0QoWHkL21TA]
				for KdWauEhgN6OQzjRVm1ro8tkB3 in ppvsMqCHf8SEzxQg:
					name = cdZKMn68Pzg4
					items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(http.*?)"',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
					for c0cDhidBlOn7 in items:
						wRlW4txQshKmeXdO7zABrLPT1GbZ0 = '&&' + c0cDhidBlOn7.split(KCQExdbYFqM)[2].lower() + '&&'
						wRlW4txQshKmeXdO7zABrLPT1GbZ0 = wRlW4txQshKmeXdO7zABrLPT1GbZ0.replace('.com&&',cdZKMn68Pzg4).replace('.co&&',cdZKMn68Pzg4)
						wRlW4txQshKmeXdO7zABrLPT1GbZ0 = wRlW4txQshKmeXdO7zABrLPT1GbZ0.replace('.net&&',cdZKMn68Pzg4).replace('.org&&',cdZKMn68Pzg4)
						wRlW4txQshKmeXdO7zABrLPT1GbZ0 = wRlW4txQshKmeXdO7zABrLPT1GbZ0.replace('.live&&',cdZKMn68Pzg4).replace('.online&&',cdZKMn68Pzg4)
						wRlW4txQshKmeXdO7zABrLPT1GbZ0 = wRlW4txQshKmeXdO7zABrLPT1GbZ0.replace('&&hd.',cdZKMn68Pzg4).replace('&&www.',cdZKMn68Pzg4)
						wRlW4txQshKmeXdO7zABrLPT1GbZ0 = wRlW4txQshKmeXdO7zABrLPT1GbZ0.replace('&&',cdZKMn68Pzg4)
						c0cDhidBlOn7 = c0cDhidBlOn7 + '?named=' + name + wRlW4txQshKmeXdO7zABrLPT1GbZ0 + '__download'
						pcX7zxFRmsADwUr.append(c0cDhidBlOn7)
	import r0y4XTKznF
	r0y4XTKznF.noHliPXkcg3pJTdSauCvm5sU(pcX7zxFRmsADwUr,UkXlAzsMcamKJrEIgnxi6bWh,'video',url)
	return
def z4hetAJw3NaT9ROjG6xbZ5CHlW81(search):
	search,EL8zUgbXheot,showDialogs = qbIcHCMdkFKn21e(search)
	if search==cdZKMn68Pzg4: search = BzkmLuvJD9n25Pg()
	if search==cdZKMn68Pzg4: return
	search = search.replace(VBpIH2QSmvDGlA6TO3e,'+')
	url = cDTdfqVAF0BLGiX364IEwaZbr + '/search?s='+search
	GDQUH4fN02sIt81mAcY(url)
	return
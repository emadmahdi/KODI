# -*- coding: utf-8 -*-
from RgJNGc7YMP import *
import bs4 as KyTztqIWwQJCeg0f
UkXlAzsMcamKJrEIgnxi6bWh = 'ELCINEMA'
nc3GLkA65oxOd = '_ELC_'
cDTdfqVAF0BLGiX364IEwaZbr = USuRxnPlV5.SITESURLS[UkXlAzsMcamKJrEIgnxi6bWh][0]
headers = {'Referer':cDTdfqVAF0BLGiX364IEwaZbr}
cJWUPuDGM0Yybv5a9KnIrVzhH78 = []
def HHN5EpbszV3iA2m89hGSQjaPgUZy(mode,url,text):
	if   mode==510: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = kUq58vC7x9hWma164JejMKQ()
	elif mode==511: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = ZkXVE856hpqgtGAeQONouT1czxYfKl(url)
	elif mode==512: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = OOVrZEwIj5bKYWqe0(url)
	elif mode==513: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = UvaXxMQZOmzRfqSyt6F1ITbVlrGh(url)
	elif mode==514: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = tnvaCibjJfKY7O1(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==515: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = tnvaCibjJfKY7O1(url,'SPECIFIED_FILTER___'+text)
	elif mode==516: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = LL9kY0GA6Jyb5KEr8du(text)
	elif mode==517: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = yxKm1Mu3QdPYCNIaGqUft4OWLb(url)
	elif mode==518: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = A07eYLET4m(url)
	elif mode==519: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = z4hetAJw3NaT9ROjG6xbZ5CHlW81(text)
	elif mode==520: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = dGMiw5fajLPIrCcAbO9tZzH1DU0xm(url)
	elif mode==521: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = MMCFISBuG5QkWhDXcH(url)
	elif mode==522: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = RPZbqous7rtdy56LeI18Cv04AKHW(url)
	elif mode==523: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = sbmFVfMZUJuR96hrq2e(text)
	elif mode==524: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = KKZxLFq05IVt()
	elif mode==525: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = uN6OCTAG3pgZJ0kYBiIMsQf2haUd()
	elif mode==526: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = huG7CtANP6ELSl0wBfZV2qJIx4cjK()
	elif mode==527: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = wkH2nTtVuRoeDbQ()
	else: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = False
	return xsGUcR3ef6glKY5hQwpFXEaSt2mrIz
def kUq58vC7x9hWma164JejMKQ():
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'بحث بموسوعة السينما',cdZKMn68Pzg4,519)
	zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'موسوعة الأعمال',cdZKMn68Pzg4,525)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'موسوعة الأشخاص',cdZKMn68Pzg4,526)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'موسوعة المصنفات',cdZKMn68Pzg4,527)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'موسوعة المنوعات',cdZKMn68Pzg4,524)
	return
def KKZxLFq05IVt():
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+' فيديوهات - خاصة',cDTdfqVAF0BLGiX364IEwaZbr+'/video',520)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'فيديوهات - أحدث',cDTdfqVAF0BLGiX364IEwaZbr+'/video/latest',521)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'فيديوهات - أقدم',cDTdfqVAF0BLGiX364IEwaZbr+'/video/oldest',521)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'فيديوهات - أكثر مشاهدة',cDTdfqVAF0BLGiX364IEwaZbr+'/video/views',521)
	return
def uN6OCTAG3pgZJ0kYBiIMsQf2haUd():
	bhuMxjmTEpIAfs1 = cDTdfqVAF0BLGiX364IEwaZbr+'/lineup?utf8=%E2%9C%93'
	xxqSUhBksrFa7v3wlg = bhuMxjmTEpIAfs1+'&type=2&category=1&foreign=false&tag='
	XI3gyinb0WU8 = bhuMxjmTEpIAfs1+'&type=2&category=3&foreign=false&tag='
	xrFue8YhMj2vLZ30dW = bhuMxjmTEpIAfs1+'&type=2&category=1&foreign=true&tag='
	zzDjotIwC8bYKOcAykuplgTSEWP = bhuMxjmTEpIAfs1+'&type=2&category=3&foreign=true&tag='
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'مصنفات أفلام عربي',xxqSUhBksrFa7v3wlg,511)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'مصنفات مسلسلات عربي',XI3gyinb0WU8,511)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'مصنفات أفلام اجنبي',xrFue8YhMj2vLZ30dW,511)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'مصنفات مسلسلات اجنبي',zzDjotIwC8bYKOcAykuplgTSEWP,511)
	zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'فهرس أعمال أبجدي',cDTdfqVAF0BLGiX364IEwaZbr+'/index/work/alphabet',517)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'فهرس  بلد الإنتاج',cDTdfqVAF0BLGiX364IEwaZbr+'/index/work/country',517)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'فهرس اللغة',cDTdfqVAF0BLGiX364IEwaZbr+'/index/work/language',517)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'فهرس مصنفات العمل',cDTdfqVAF0BLGiX364IEwaZbr+'/index/work/genre',517)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'فهرس سنة الإصدار',cDTdfqVAF0BLGiX364IEwaZbr+'/index/work/release_year',517)
	zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'مواسم - فلتر محدد',cDTdfqVAF0BLGiX364IEwaZbr+'/seasonals',515)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'مواسم - فلتر كامل',cDTdfqVAF0BLGiX364IEwaZbr+'/seasonals',514)
	zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'مصنفات - فلتر محدد',cDTdfqVAF0BLGiX364IEwaZbr+'/lineup',515)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'مصنفات - فلتر كامل',cDTdfqVAF0BLGiX364IEwaZbr+'/lineup',514)
	return
def wkH2nTtVuRoeDbQ():
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(r43t1YI9deXA5N,'GET',cDTdfqVAF0BLGiX364IEwaZbr+'/lineup',cdZKMn68Pzg4,headers,cdZKMn68Pzg4,cdZKMn68Pzg4,'ELCINEMA-MENU-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	ZL9eus7rRYApnEx8o5 = KyTztqIWwQJCeg0f.BeautifulSoup(OO1cj2REUZHJ8x5V,'html.parser',multi_valued_attributes=None)
	KdWauEhgN6OQzjRVm1ro8tkB3 = ZL9eus7rRYApnEx8o5.find('select',attrs={'name':'tag'})
	EL8zUgbXheot = KdWauEhgN6OQzjRVm1ro8tkB3.find_all('option')
	for zj6FI51Rypka0e8xiECfc7g in EL8zUgbXheot:
		value = zj6FI51Rypka0e8xiECfc7g.get('value')
		if not value: continue
		title = zj6FI51Rypka0e8xiECfc7g.text
		if xicJPb0AW1nsRfH3kCv7:
			title = title.encode(vczMIlkCAh2u10B3)
			value = value.encode(vczMIlkCAh2u10B3)
		c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr+'/lineup?utf8=%E2%9C%93&type=&category=&foreign=&tag='+value
		title = title.replace('قائمة ',cdZKMn68Pzg4)
		zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,511)
	return
def huG7CtANP6ELSl0wBfZV2qJIx4cjK():
	bhuMxjmTEpIAfs1 = cDTdfqVAF0BLGiX364IEwaZbr+'/lineup?utf8=%E2%9C%93'
	M8AVzgUQlwOJcj1KanI3RbDtiPo = bhuMxjmTEpIAfs1+'&type=1&category=&foreign=&tag='
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'مصنفات أشخاص',M8AVzgUQlwOJcj1KanI3RbDtiPo,511)
	zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'فهرس أشخاص أبجدي',cDTdfqVAF0BLGiX364IEwaZbr+'/index/person/alphabet',517)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'فهرس موطن',cDTdfqVAF0BLGiX364IEwaZbr+'/index/person/nationality',517)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'فهرس  تاريخ الميلاد',cDTdfqVAF0BLGiX364IEwaZbr+'/index/person/birth_year',517)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'فهرس  تاريخ الوفاة',cDTdfqVAF0BLGiX364IEwaZbr+'/index/person/death_year',517)
	zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'مصنفات - فلتر محدد',cDTdfqVAF0BLGiX364IEwaZbr+'/lineup',515)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'مصنفات - فلتر كامل',cDTdfqVAF0BLGiX364IEwaZbr+'/lineup',514)
	return
def ZkXVE856hpqgtGAeQONouT1czxYfKl(url):
	if '/seasonals' in url: OMQouSr6t7xL = 0
	elif '/lineup' in url: OMQouSr6t7xL = 1
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(r43t1YI9deXA5N,'GET',url,cdZKMn68Pzg4,headers,cdZKMn68Pzg4,cdZKMn68Pzg4,'ELCINEMA-LISTS-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	ZL9eus7rRYApnEx8o5 = KyTztqIWwQJCeg0f.BeautifulSoup(OO1cj2REUZHJ8x5V,'html.parser',multi_valued_attributes=None)
	akIvSitzr0mKe = ZL9eus7rRYApnEx8o5.find_all(class_='jumbo-theater clearfix')
	for KdWauEhgN6OQzjRVm1ro8tkB3 in akIvSitzr0mKe:
		title = KdWauEhgN6OQzjRVm1ro8tkB3.find_all('a')[OMQouSr6t7xL].text
		c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr+KdWauEhgN6OQzjRVm1ro8tkB3.find_all('a')[OMQouSr6t7xL].get('href')
		if xicJPb0AW1nsRfH3kCv7:
			title = title.encode(vczMIlkCAh2u10B3)
			c0cDhidBlOn7 = c0cDhidBlOn7.encode(vczMIlkCAh2u10B3)
		if not akIvSitzr0mKe:
			OOVrZEwIj5bKYWqe0(c0cDhidBlOn7)
			return
		else:
			title = title.replace('قائمة ',cdZKMn68Pzg4)
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,512)
	BsewTaqSNkcuHhtf8pZvGVD7L(ZL9eus7rRYApnEx8o5,511)
	return
def BsewTaqSNkcuHhtf8pZvGVD7L(ZL9eus7rRYApnEx8o5,mode):
	KdWauEhgN6OQzjRVm1ro8tkB3 = ZL9eus7rRYApnEx8o5.find(class_='pagination')
	if KdWauEhgN6OQzjRVm1ro8tkB3:
		ccNiGxT3tzSyUO4omsVe8PrRYKu = KdWauEhgN6OQzjRVm1ro8tkB3.find_all('a')
		iQDf25j3yCkxB9OZlA8Fm0UR7NdV = KdWauEhgN6OQzjRVm1ro8tkB3.find_all('li')
		G5rF6bSoILlpW1s0gNq4TQYtecXJA = list(zip(ccNiGxT3tzSyUO4omsVe8PrRYKu,iQDf25j3yCkxB9OZlA8Fm0UR7NdV))
		DXAlBvH2ITZoyunMU0Rq3pw7sx = -1
		uUzd5cGjb64M9hLlVpSKtRrxgHX = len(G5rF6bSoILlpW1s0gNq4TQYtecXJA)
		for HsYhVo5Jud,vvGzPy3bwcrCxTYAQ in G5rF6bSoILlpW1s0gNq4TQYtecXJA:
			DXAlBvH2ITZoyunMU0Rq3pw7sx += 1
			vvGzPy3bwcrCxTYAQ = vvGzPy3bwcrCxTYAQ['class']
			if 'unavailable' in vvGzPy3bwcrCxTYAQ or 'current' in vvGzPy3bwcrCxTYAQ: continue
			wRbgsDELJBq9odiKFIu6 = HsYhVo5Jud.text
			cz5qCJd6O3g4ISxVa1EtQpysvGHPk = cDTdfqVAF0BLGiX364IEwaZbr+HsYhVo5Jud.get('href')
			if xicJPb0AW1nsRfH3kCv7:
				wRbgsDELJBq9odiKFIu6 = wRbgsDELJBq9odiKFIu6.encode(vczMIlkCAh2u10B3)
				cz5qCJd6O3g4ISxVa1EtQpysvGHPk = cz5qCJd6O3g4ISxVa1EtQpysvGHPk.encode(vczMIlkCAh2u10B3)
			if   DXAlBvH2ITZoyunMU0Rq3pw7sx==0: wRbgsDELJBq9odiKFIu6 = 'أولى'
			elif DXAlBvH2ITZoyunMU0Rq3pw7sx==1: wRbgsDELJBq9odiKFIu6 = 'سابقة'
			elif DXAlBvH2ITZoyunMU0Rq3pw7sx==uUzd5cGjb64M9hLlVpSKtRrxgHX-2: wRbgsDELJBq9odiKFIu6 = 'لاحقة'
			elif DXAlBvH2ITZoyunMU0Rq3pw7sx==uUzd5cGjb64M9hLlVpSKtRrxgHX-1: wRbgsDELJBq9odiKFIu6 = 'أخيرة'
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'صفحة '+wRbgsDELJBq9odiKFIu6,cz5qCJd6O3g4ISxVa1EtQpysvGHPk,mode)
	return
def OOVrZEwIj5bKYWqe0(url):
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(r43t1YI9deXA5N,'GET',url,cdZKMn68Pzg4,headers,cdZKMn68Pzg4,cdZKMn68Pzg4,'ELCINEMA-TITLES1-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	ZL9eus7rRYApnEx8o5 = KyTztqIWwQJCeg0f.BeautifulSoup(OO1cj2REUZHJ8x5V,'html.parser',multi_valued_attributes=None)
	akIvSitzr0mKe = ZL9eus7rRYApnEx8o5.find_all(class_='row')
	items,XMkp5KNroQDVvUx73j9qus = [],True
	for KdWauEhgN6OQzjRVm1ro8tkB3 in akIvSitzr0mKe:
		if not KdWauEhgN6OQzjRVm1ro8tkB3.find(class_='thumbnail-wrapper'): continue
		if XMkp5KNroQDVvUx73j9qus: XMkp5KNroQDVvUx73j9qus = False ; continue
		KVqfRrGAJjeCNPnD9 = []
		XY7Ucp8e3KTfDoOrWtNjzlEqVAB = KdWauEhgN6OQzjRVm1ro8tkB3.find_all(class_=['censorship red','censorship purple'])
		for ToBX5Qfjarmn in XY7Ucp8e3KTfDoOrWtNjzlEqVAB:
			BSnsk3cydqgVPFxuMvKYUGTANwr0WE = ToBX5Qfjarmn.find_all('li')[1].text
			if xicJPb0AW1nsRfH3kCv7:
				BSnsk3cydqgVPFxuMvKYUGTANwr0WE = BSnsk3cydqgVPFxuMvKYUGTANwr0WE.encode(vczMIlkCAh2u10B3)
			KVqfRrGAJjeCNPnD9.append(BSnsk3cydqgVPFxuMvKYUGTANwr0WE)
		if not bMOpKuUkQ5J2(UkXlAzsMcamKJrEIgnxi6bWh,cdZKMn68Pzg4,KVqfRrGAJjeCNPnD9,False):
			fh6qmOxoiv1UPXZanLprDeMI8 = KdWauEhgN6OQzjRVm1ro8tkB3.find('img').get('data-src')
			title = KdWauEhgN6OQzjRVm1ro8tkB3.find('h3')
			name = title.find('a').text
			c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr+title.find('a').get('href')
			svmeL3HG1jtJ67Ybu0wy5igR2QxT = KdWauEhgN6OQzjRVm1ro8tkB3.find(class_='no-margin')
			w95yxEYeRTMqh = KdWauEhgN6OQzjRVm1ro8tkB3.find(class_='legend')
			if svmeL3HG1jtJ67Ybu0wy5igR2QxT: svmeL3HG1jtJ67Ybu0wy5igR2QxT = svmeL3HG1jtJ67Ybu0wy5igR2QxT.text
			if w95yxEYeRTMqh: w95yxEYeRTMqh = w95yxEYeRTMqh.text
			if xicJPb0AW1nsRfH3kCv7:
				fh6qmOxoiv1UPXZanLprDeMI8 = fh6qmOxoiv1UPXZanLprDeMI8.encode(vczMIlkCAh2u10B3)
				name = name.encode(vczMIlkCAh2u10B3)
				c0cDhidBlOn7 = c0cDhidBlOn7.encode(vczMIlkCAh2u10B3)
				if svmeL3HG1jtJ67Ybu0wy5igR2QxT: svmeL3HG1jtJ67Ybu0wy5igR2QxT = svmeL3HG1jtJ67Ybu0wy5igR2QxT.encode(vczMIlkCAh2u10B3)
			g8tTFcBGwdKlo42LUkW = {}
			if w95yxEYeRTMqh: g8tTFcBGwdKlo42LUkW['stars'] = w95yxEYeRTMqh
			if svmeL3HG1jtJ67Ybu0wy5igR2QxT:
				svmeL3HG1jtJ67Ybu0wy5igR2QxT = svmeL3HG1jtJ67Ybu0wy5igR2QxT.replace(ssELJkeScrtni2,' .. ')
				g8tTFcBGwdKlo42LUkW['plot'] = svmeL3HG1jtJ67Ybu0wy5igR2QxT.replace('...اقرأ المزيد',cdZKMn68Pzg4)
			if '/work/' in c0cDhidBlOn7:
				zJLApFBcIhnSj('folder',nc3GLkA65oxOd+name,c0cDhidBlOn7,516,fh6qmOxoiv1UPXZanLprDeMI8,cdZKMn68Pzg4,name,cdZKMn68Pzg4,g8tTFcBGwdKlo42LUkW)
			elif '/person/' in c0cDhidBlOn7: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+name,c0cDhidBlOn7,513,fh6qmOxoiv1UPXZanLprDeMI8,cdZKMn68Pzg4,name,cdZKMn68Pzg4,g8tTFcBGwdKlo42LUkW)
	BsewTaqSNkcuHhtf8pZvGVD7L(ZL9eus7rRYApnEx8o5,512)
	return
def UvaXxMQZOmzRfqSyt6F1ITbVlrGh(url):
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(r43t1YI9deXA5N,'GET',url,cdZKMn68Pzg4,headers,cdZKMn68Pzg4,cdZKMn68Pzg4,'ELCINEMA-TITLES2-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	ZL9eus7rRYApnEx8o5 = KyTztqIWwQJCeg0f.BeautifulSoup(OO1cj2REUZHJ8x5V,'html.parser',multi_valued_attributes=None)
	akIvSitzr0mKe = ZL9eus7rRYApnEx8o5.find_all('li')
	OTVQcUsEmXhfdL38,items = [],[]
	for KdWauEhgN6OQzjRVm1ro8tkB3 in akIvSitzr0mKe:
		if not KdWauEhgN6OQzjRVm1ro8tkB3.find(class_='thumbnail-wrapper'): continue
		if not KdWauEhgN6OQzjRVm1ro8tkB3.find(class_=['unstyled','unstyled text-center']): continue
		if KdWauEhgN6OQzjRVm1ro8tkB3.find(class_='hide'): continue
		title = KdWauEhgN6OQzjRVm1ro8tkB3.find(class_=['unstyled','unstyled text-center'])
		name = title.find('a').text
		if name in OTVQcUsEmXhfdL38: continue
		OTVQcUsEmXhfdL38.append(name)
		c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr+title.find('a').get('href')
		if '/search/work/' in url: fh6qmOxoiv1UPXZanLprDeMI8 = KdWauEhgN6OQzjRVm1ro8tkB3.find('img').get('src')
		elif '/search/person/' in url: fh6qmOxoiv1UPXZanLprDeMI8 = KdWauEhgN6OQzjRVm1ro8tkB3.find('img').get('data-src')
		elif '/search/video/' in url: fh6qmOxoiv1UPXZanLprDeMI8 = KdWauEhgN6OQzjRVm1ro8tkB3.find('img').get('data-src')
		else: fh6qmOxoiv1UPXZanLprDeMI8 = KdWauEhgN6OQzjRVm1ro8tkB3.find('img').get('src')
		if xicJPb0AW1nsRfH3kCv7:
			name = name.encode(vczMIlkCAh2u10B3)
			c0cDhidBlOn7 = c0cDhidBlOn7.encode(vczMIlkCAh2u10B3)
			fh6qmOxoiv1UPXZanLprDeMI8 = fh6qmOxoiv1UPXZanLprDeMI8.encode(vczMIlkCAh2u10B3)
		name = name.strip(VBpIH2QSmvDGlA6TO3e)
		items.append((name,c0cDhidBlOn7,fh6qmOxoiv1UPXZanLprDeMI8))
	if '/search/person/' in url: items = sorted(items,reverse=False,key=lambda key: key[0])
	for name,c0cDhidBlOn7,fh6qmOxoiv1UPXZanLprDeMI8 in items:
		if '/search/video/' in url: zJLApFBcIhnSj('video',nc3GLkA65oxOd+name,c0cDhidBlOn7,522,fh6qmOxoiv1UPXZanLprDeMI8)
		elif '/search/person/' in url: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+name,c0cDhidBlOn7,513,fh6qmOxoiv1UPXZanLprDeMI8,cdZKMn68Pzg4,name)
		else: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+name,c0cDhidBlOn7,516,fh6qmOxoiv1UPXZanLprDeMI8,cdZKMn68Pzg4,name)
	return
def LL9kY0GA6Jyb5KEr8du(text):
	text = text.replace('الإعلان',cdZKMn68Pzg4).replace('لفيلم',cdZKMn68Pzg4).replace('الرسمي',cdZKMn68Pzg4)
	text = text.replace('إعلان',cdZKMn68Pzg4).replace('فيلم',cdZKMn68Pzg4).replace('البرومو',cdZKMn68Pzg4)
	text = text.replace('التشويقي',cdZKMn68Pzg4).replace('لمسلسل',cdZKMn68Pzg4).replace('مسلسل',cdZKMn68Pzg4)
	text = text.replace(':',cdZKMn68Pzg4).replace(')',cdZKMn68Pzg4).replace('(',cdZKMn68Pzg4).replace(',',cdZKMn68Pzg4)
	text = text.replace('_',cdZKMn68Pzg4).replace(';',cdZKMn68Pzg4).replace('-',cdZKMn68Pzg4).replace('.',cdZKMn68Pzg4)
	text = text.replace('\'',cdZKMn68Pzg4).replace('\"',cdZKMn68Pzg4)
	text = text.replace(KATUbrqnhgW2GkBJzMDsREmtdo78,VBpIH2QSmvDGlA6TO3e).replace(U4ImogGksPlcBVfAb,VBpIH2QSmvDGlA6TO3e).replace(wr0HaqRdJ2D9LT7nSO1KMe38ly,VBpIH2QSmvDGlA6TO3e)
	text = text.strip(VBpIH2QSmvDGlA6TO3e)
	tcWjMa4NRl7s1uB = text.count(VBpIH2QSmvDGlA6TO3e)+1
	if tcWjMa4NRl7s1uB==1:
		sbmFVfMZUJuR96hrq2e(text)
		return
	zJLApFBcIhnSj('link',nc3GLkA65oxOd+Gzygq01Kcb9U3+'==== كلمات للبحث ===='+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	cuI0aZDfVjJ9YntT7m = text.split(VBpIH2QSmvDGlA6TO3e)
	j5F0q2PM3IkodrxATw4nyUDJL = pow(2,tcWjMa4NRl7s1uB)
	Mcnw2qs5UjL1EdyY9rVZHIWo0T = []
	def p6ovPrmISDxEw5etc(T1xZIRzQheDbl5BaG8OgSw,Aj1l38G6VwCPeDfscWyLOg5):
		if T1xZIRzQheDbl5BaG8OgSw=='1': return Aj1l38G6VwCPeDfscWyLOg5
		return cdZKMn68Pzg4
	for DXAlBvH2ITZoyunMU0Rq3pw7sx in range(j5F0q2PM3IkodrxATw4nyUDJL,0,-1):
		Z4ZngwiBuVkI1ldKfbv93qcFa = list(tcWjMa4NRl7s1uB*'0'+bin(DXAlBvH2ITZoyunMU0Rq3pw7sx)[2:])[-tcWjMa4NRl7s1uB:]
		Z4ZngwiBuVkI1ldKfbv93qcFa = reversed(Z4ZngwiBuVkI1ldKfbv93qcFa)
		bXWSJeh38Onkra02 = map(p6ovPrmISDxEw5etc,Z4ZngwiBuVkI1ldKfbv93qcFa,cuI0aZDfVjJ9YntT7m)
		title = VBpIH2QSmvDGlA6TO3e.join(filter(None,bXWSJeh38Onkra02))
		if xicJPb0AW1nsRfH3kCv7: UHXfFEWmlxMAnzju4 = title.decode(vczMIlkCAh2u10B3)
		else: UHXfFEWmlxMAnzju4 = title
		if len(UHXfFEWmlxMAnzju4)>2 and title not in Mcnw2qs5UjL1EdyY9rVZHIWo0T:
			Mcnw2qs5UjL1EdyY9rVZHIWo0T.append(title)
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,cdZKMn68Pzg4,523,cdZKMn68Pzg4,cdZKMn68Pzg4,title)
	return
def sbmFVfMZUJuR96hrq2e(OHkUL3XJYCcvux60qez4rp7h8dnty):
	if xicJPb0AW1nsRfH3kCv7:
		OHkUL3XJYCcvux60qez4rp7h8dnty = OHkUL3XJYCcvux60qez4rp7h8dnty.decode(vczMIlkCAh2u10B3)
		import arabic_reshaper as xGRW4JLfhjaYu,bidi.algorithm as Fx1YX359sET
		OHkUL3XJYCcvux60qez4rp7h8dnty = xGRW4JLfhjaYu.ArabicReshaper().reshape(OHkUL3XJYCcvux60qez4rp7h8dnty)
		OHkUL3XJYCcvux60qez4rp7h8dnty = Fx1YX359sET.get_display(OHkUL3XJYCcvux60qez4rp7h8dnty)
	import zBKTlNEfOC
	OHkUL3XJYCcvux60qez4rp7h8dnty = BzkmLuvJD9n25Pg(nzJMgW6tQqT3lA4cojNZLIV9au7d=OHkUL3XJYCcvux60qez4rp7h8dnty)
	zBKTlNEfOC.z4hetAJw3NaT9ROjG6xbZ5CHlW81(OHkUL3XJYCcvux60qez4rp7h8dnty)
	return
def yxKm1Mu3QdPYCNIaGqUft4OWLb(url):
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(r43t1YI9deXA5N,'GET',url,cdZKMn68Pzg4,headers,cdZKMn68Pzg4,cdZKMn68Pzg4,'ELCINEMA-INDEXES_LISTS-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	ZL9eus7rRYApnEx8o5 = KyTztqIWwQJCeg0f.BeautifulSoup(OO1cj2REUZHJ8x5V,'html.parser',multi_valued_attributes=None)
	KdWauEhgN6OQzjRVm1ro8tkB3 = ZL9eus7rRYApnEx8o5.find(class_='list-separator list-title')
	Snu3TYPhdqbc = KdWauEhgN6OQzjRVm1ro8tkB3.find_all('a')
	items = []
	for title in Snu3TYPhdqbc:
		name = title.text
		c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr+title.get('href')
		if xicJPb0AW1nsRfH3kCv7:
			name = name.encode(vczMIlkCAh2u10B3)
			c0cDhidBlOn7 = c0cDhidBlOn7.encode(vczMIlkCAh2u10B3)
		if '#' not in c0cDhidBlOn7: items.append((name,c0cDhidBlOn7))
	items = sorted(items,reverse=False,key=lambda key: key[0])
	for HYBN2AQsjimSMgT8OvE3ynX67tJwR in items:
		name,c0cDhidBlOn7 = HYBN2AQsjimSMgT8OvE3ynX67tJwR
		zJLApFBcIhnSj('folder',nc3GLkA65oxOd+name,c0cDhidBlOn7,518)
	return
def A07eYLET4m(url):
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(r43t1YI9deXA5N,'GET',url,cdZKMn68Pzg4,headers,cdZKMn68Pzg4,cdZKMn68Pzg4,'ELCINEMA-INDEXES_TITLES-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	ZL9eus7rRYApnEx8o5 = KyTztqIWwQJCeg0f.BeautifulSoup(OO1cj2REUZHJ8x5V,'html.parser',multi_valued_attributes=None)
	akIvSitzr0mKe = ZL9eus7rRYApnEx8o5.find(class_='expand').find_all('tr')
	for KdWauEhgN6OQzjRVm1ro8tkB3 in akIvSitzr0mKe:
		QXnmENGDFrWH = KdWauEhgN6OQzjRVm1ro8tkB3.find_all('a')
		if not QXnmENGDFrWH: continue
		fh6qmOxoiv1UPXZanLprDeMI8 = KdWauEhgN6OQzjRVm1ro8tkB3.find('img').get('data-src')
		name = QXnmENGDFrWH[1].text
		c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr+QXnmENGDFrWH[1].get('href')
		w95yxEYeRTMqh = KdWauEhgN6OQzjRVm1ro8tkB3.find(class_='legend')
		if w95yxEYeRTMqh: w95yxEYeRTMqh = w95yxEYeRTMqh.text
		if xicJPb0AW1nsRfH3kCv7:
			name = name.encode(vczMIlkCAh2u10B3)
			c0cDhidBlOn7 = c0cDhidBlOn7.encode(vczMIlkCAh2u10B3)
			fh6qmOxoiv1UPXZanLprDeMI8 = fh6qmOxoiv1UPXZanLprDeMI8.encode(vczMIlkCAh2u10B3)
		g8tTFcBGwdKlo42LUkW = {}
		if w95yxEYeRTMqh: g8tTFcBGwdKlo42LUkW['stars'] = w95yxEYeRTMqh
		if '/work/' in c0cDhidBlOn7:
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+name,c0cDhidBlOn7,516,fh6qmOxoiv1UPXZanLprDeMI8,cdZKMn68Pzg4,name,cdZKMn68Pzg4,g8tTFcBGwdKlo42LUkW)
		elif '/person/' in c0cDhidBlOn7: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+name,c0cDhidBlOn7,513,fh6qmOxoiv1UPXZanLprDeMI8,cdZKMn68Pzg4,name,cdZKMn68Pzg4,g8tTFcBGwdKlo42LUkW)
	BsewTaqSNkcuHhtf8pZvGVD7L(ZL9eus7rRYApnEx8o5,518)
	return
def dGMiw5fajLPIrCcAbO9tZzH1DU0xm(url):
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(r43t1YI9deXA5N,'GET',url,cdZKMn68Pzg4,headers,cdZKMn68Pzg4,cdZKMn68Pzg4,'ELCINEMA-VIDEOS_LISTS-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	ZL9eus7rRYApnEx8o5 = KyTztqIWwQJCeg0f.BeautifulSoup(OO1cj2REUZHJ8x5V,'html.parser',multi_valued_attributes=None)
	Snu3TYPhdqbc = ZL9eus7rRYApnEx8o5.find_all(class_='section-title inline')
	zz4ZPovUbyk5GEhNMs8JDnaVXftS = ZL9eus7rRYApnEx8o5.find_all(class_='button green small right')
	items = zip(Snu3TYPhdqbc,zz4ZPovUbyk5GEhNMs8JDnaVXftS)
	for title,c0cDhidBlOn7 in items:
		title = title.text
		c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr+c0cDhidBlOn7.get('href')
		if xicJPb0AW1nsRfH3kCv7:
			title = title.encode(vczMIlkCAh2u10B3)
			c0cDhidBlOn7 = c0cDhidBlOn7.encode(vczMIlkCAh2u10B3)
		title = title.replace(KATUbrqnhgW2GkBJzMDsREmtdo78,VBpIH2QSmvDGlA6TO3e).replace(U4ImogGksPlcBVfAb,VBpIH2QSmvDGlA6TO3e).replace(wr0HaqRdJ2D9LT7nSO1KMe38ly,VBpIH2QSmvDGlA6TO3e)
		zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,521)
	return
def MMCFISBuG5QkWhDXcH(url):
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(r43t1YI9deXA5N,'GET',url,cdZKMn68Pzg4,headers,cdZKMn68Pzg4,cdZKMn68Pzg4,'ELCINEMA-VIDEOS_TITLES-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	ZL9eus7rRYApnEx8o5 = KyTztqIWwQJCeg0f.BeautifulSoup(OO1cj2REUZHJ8x5V,'html.parser',multi_valued_attributes=None)
	OMkPh9lcBI5HayirV7YeKu0dgwp = ZL9eus7rRYApnEx8o5.find(class_='large-block-grid-4 medium-block-grid-4 small-block-grid-2')
	akIvSitzr0mKe = OMkPh9lcBI5HayirV7YeKu0dgwp.find_all('li')
	for KdWauEhgN6OQzjRVm1ro8tkB3 in akIvSitzr0mKe:
		title = KdWauEhgN6OQzjRVm1ro8tkB3.find(class_='title').text
		c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr+KdWauEhgN6OQzjRVm1ro8tkB3.find('a').get('href')
		fh6qmOxoiv1UPXZanLprDeMI8 = KdWauEhgN6OQzjRVm1ro8tkB3.find('img').get('data-src')
		Kr1n9xq5TY4gohlVdNEu0b = KdWauEhgN6OQzjRVm1ro8tkB3.find(class_='duration').text
		if xicJPb0AW1nsRfH3kCv7:
			title = title.encode(vczMIlkCAh2u10B3)
			c0cDhidBlOn7 = c0cDhidBlOn7.encode(vczMIlkCAh2u10B3)
			fh6qmOxoiv1UPXZanLprDeMI8 = fh6qmOxoiv1UPXZanLprDeMI8.encode(vczMIlkCAh2u10B3)
			Kr1n9xq5TY4gohlVdNEu0b = Kr1n9xq5TY4gohlVdNEu0b.encode(vczMIlkCAh2u10B3)
		Kr1n9xq5TY4gohlVdNEu0b = Kr1n9xq5TY4gohlVdNEu0b.replace(ssELJkeScrtni2,cdZKMn68Pzg4).strip(VBpIH2QSmvDGlA6TO3e)
		zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,522,fh6qmOxoiv1UPXZanLprDeMI8,Kr1n9xq5TY4gohlVdNEu0b)
	BsewTaqSNkcuHhtf8pZvGVD7L(ZL9eus7rRYApnEx8o5,521)
	return
def RPZbqous7rtdy56LeI18Cv04AKHW(url):
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(r43t1YI9deXA5N,'GET',url,cdZKMn68Pzg4,headers,cdZKMn68Pzg4,cdZKMn68Pzg4,'ELCINEMA-PLAY-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	ZL9eus7rRYApnEx8o5 = KyTztqIWwQJCeg0f.BeautifulSoup(OO1cj2REUZHJ8x5V,'html.parser',multi_valued_attributes=None)
	c0cDhidBlOn7 = ZL9eus7rRYApnEx8o5.find(class_='flex-video').find('iframe').get('src')
	if xicJPb0AW1nsRfH3kCv7: c0cDhidBlOn7 = c0cDhidBlOn7.encode(vczMIlkCAh2u10B3)
	import r0y4XTKznF
	r0y4XTKznF.noHliPXkcg3pJTdSauCvm5sU([c0cDhidBlOn7],UkXlAzsMcamKJrEIgnxi6bWh,'video',url)
	return
def z4hetAJw3NaT9ROjG6xbZ5CHlW81(search):
	search,EL8zUgbXheot,showDialogs = qbIcHCMdkFKn21e(search)
	if search==cdZKMn68Pzg4: search = BzkmLuvJD9n25Pg()
	if search==cdZKMn68Pzg4: return
	search = search.replace(VBpIH2QSmvDGlA6TO3e,'%20')
	url = cDTdfqVAF0BLGiX364IEwaZbr+'/search/?q='+search
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(r43t1YI9deXA5N,'GET',url,cdZKMn68Pzg4,headers,cdZKMn68Pzg4,cdZKMn68Pzg4,'ELCINEMA-SEARCH-1st')
	if not Zty0AsgQ5jpkTh91OW.succeeded:
		M8AVzgUQlwOJcj1KanI3RbDtiPo = cDTdfqVAF0BLGiX364IEwaZbr+'/search_entity/?q='+search+'&entity=work'
		cz5qCJd6O3g4ISxVa1EtQpysvGHPk = cDTdfqVAF0BLGiX364IEwaZbr+'/search_entity/?q='+search+'&entity=person'
		LLkBo51TpPlsJ = cDTdfqVAF0BLGiX364IEwaZbr+'/search_entity/?q='+search+'&entity=video'
		zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'بحث عن أعمال',M8AVzgUQlwOJcj1KanI3RbDtiPo,513,cdZKMn68Pzg4,search)
		zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'بحث عن أشخاص',cz5qCJd6O3g4ISxVa1EtQpysvGHPk,513,cdZKMn68Pzg4,search)
		zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'بحث عن فيديوهات',LLkBo51TpPlsJ,513,cdZKMn68Pzg4,search)
		return
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	ZL9eus7rRYApnEx8o5 = KyTztqIWwQJCeg0f.BeautifulSoup(OO1cj2REUZHJ8x5V,'html.parser',multi_valued_attributes=None)
	akIvSitzr0mKe = ZL9eus7rRYApnEx8o5.find_all(class_='section-title left')
	for KdWauEhgN6OQzjRVm1ro8tkB3 in akIvSitzr0mKe:
		title = KdWauEhgN6OQzjRVm1ro8tkB3.text
		if xicJPb0AW1nsRfH3kCv7:
			title = title.encode(vczMIlkCAh2u10B3)
		title = title.split('(',1)[0].strip(VBpIH2QSmvDGlA6TO3e)
		if   'أعمال' in title: c0cDhidBlOn7 = url.replace('/search/','/search/work/')
		elif 'أشخاص' in title: c0cDhidBlOn7 = url.replace('/search/','/search/person/')
		elif 'فيديوهات' in title: c0cDhidBlOn7 = url.replace('/search/','/search/video/')
		else: continue
		zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,513)
	return
def tnvaCibjJfKY7O1(url,text):
	global fCAW9dmInLiV,w6wuL59PgeE
	if '/seasonals' in url:
		fCAW9dmInLiV = ['seasonal','year','category']
		w6wuL59PgeE = ['seasonal','year','category']
	elif '/lineup' in url:
		fCAW9dmInLiV = ['category','foreign','type']
		w6wuL59PgeE = ['category','foreign','type']
	XxcpMKIUzr0sVDngR(url,text)
	return
def J1BMh3gS6EbcwT284RdnKzkitfUqW(url):
	url = url.split('/smartemadfilter?')[0]
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(r43t1YI9deXA5N,'GET',url,cdZKMn68Pzg4,headers,cdZKMn68Pzg4,cdZKMn68Pzg4,'ELCINEMA-GET_FILTERS_BLOCKS-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('form action="/(.*?)</form>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
	hQ9ADnZlSxI1m8ui = ffUFBJQ57j2XgoGeOLn9uwpC.findall('<select name="(.*?)" id="(.*?)".*?>(.*?)</div>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	return hQ9ADnZlSxI1m8ui
def ycYdX9u6W0oOnbMaDlf4KiPz(KdWauEhgN6OQzjRVm1ro8tkB3):
	items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('<option value="(.*?)">(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	return items
def PVO4RmQY92jycoli0GtrusH(url):
	NLpSEUdj5H081igYnC4TbA2QtoVclF = url.split('/smartemadfilter?')[0]
	YYpjB2CuTidaMgcGrlJOswovm = CxlbPZwGTcH87e1sWhfSIz29uRUEpV(url,'url')
	url = url.replace('/smartemadfilter?','/?utf8=%E2%9C%93&')
	return url
def VyEHqwXn7B9xFRidWhNoIkJP(qwmxUpZfQj8EAV3Tc,url):
	YqrzmSVb3R9MgUnX2auEHlpBhZD = XFoM2xPKIt3u51hLj(qwmxUpZfQj8EAV3Tc,'all_filters')
	N8jUpQxY0rhtDAzbG4kOs9X = url+'/smartemadfilter?'+YqrzmSVb3R9MgUnX2auEHlpBhZD
	N8jUpQxY0rhtDAzbG4kOs9X = PVO4RmQY92jycoli0GtrusH(N8jUpQxY0rhtDAzbG4kOs9X)
	return N8jUpQxY0rhtDAzbG4kOs9X
def XxcpMKIUzr0sVDngR(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==cdZKMn68Pzg4: KFGqxsBnZYLb3NvMU,ejQ8ZCtBaV7 = cdZKMn68Pzg4,cdZKMn68Pzg4
	else: KFGqxsBnZYLb3NvMU,ejQ8ZCtBaV7 = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if fCAW9dmInLiV[0]+'=' not in KFGqxsBnZYLb3NvMU: rrb0SF6otehufCYOX4 = fCAW9dmInLiV[0]
		for WCqkctAYD2O3Hz7Fl8fKRS5 in range(len(fCAW9dmInLiV[0:-1])):
			if fCAW9dmInLiV[WCqkctAYD2O3Hz7Fl8fKRS5]+'=' in KFGqxsBnZYLb3NvMU: rrb0SF6otehufCYOX4 = fCAW9dmInLiV[WCqkctAYD2O3Hz7Fl8fKRS5+1]
		gmjZQuBFv8RzlNtDVEOc = KFGqxsBnZYLb3NvMU+'&'+rrb0SF6otehufCYOX4+'=0'
		qwmxUpZfQj8EAV3Tc = ejQ8ZCtBaV7+'&'+rrb0SF6otehufCYOX4+'=0'
		vMp6jZbo3UkEsSxRFQndyA = gmjZQuBFv8RzlNtDVEOc.strip('&')+'___'+qwmxUpZfQj8EAV3Tc.strip('&')
		YqrzmSVb3R9MgUnX2auEHlpBhZD = XFoM2xPKIt3u51hLj(ejQ8ZCtBaV7,'modified_filters')
		HOCWKhxITtulVGX = url+'/smartemadfilter?'+YqrzmSVb3R9MgUnX2auEHlpBhZD
	elif type=='ALL_ITEMS_FILTER':
		zM2ZBJ4IYN8osGTtwgRheLu6dU = XFoM2xPKIt3u51hLj(KFGqxsBnZYLb3NvMU,'modified_values')
		zM2ZBJ4IYN8osGTtwgRheLu6dU = NLqxoZ37dYf0awrsIE(zM2ZBJ4IYN8osGTtwgRheLu6dU)
		if ejQ8ZCtBaV7!=cdZKMn68Pzg4: ejQ8ZCtBaV7 = XFoM2xPKIt3u51hLj(ejQ8ZCtBaV7,'modified_filters')
		if ejQ8ZCtBaV7==cdZKMn68Pzg4: HOCWKhxITtulVGX = url
		else: HOCWKhxITtulVGX = url+'/smartemadfilter?'+ejQ8ZCtBaV7
		HOCWKhxITtulVGX = PVO4RmQY92jycoli0GtrusH(HOCWKhxITtulVGX)
		zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'أظهار قائمة الفيديو التي تم اختيارها ',HOCWKhxITtulVGX,511)
		zJLApFBcIhnSj('folder',nc3GLkA65oxOd+' [[   '+zM2ZBJ4IYN8osGTtwgRheLu6dU+'   ]]',HOCWKhxITtulVGX,511)
		zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	hQ9ADnZlSxI1m8ui = J1BMh3gS6EbcwT284RdnKzkitfUqW(url)
	dict = {}
	for name,rfJG62Vo0pTEljwPN1WahD7sx4t3QR,KdWauEhgN6OQzjRVm1ro8tkB3 in hQ9ADnZlSxI1m8ui:
		name = name.replace('--',cdZKMn68Pzg4)
		items = ycYdX9u6W0oOnbMaDlf4KiPz(KdWauEhgN6OQzjRVm1ro8tkB3)
		if '=' not in HOCWKhxITtulVGX: HOCWKhxITtulVGX = url
		if type=='SPECIFIED_FILTER':
			if rfJG62Vo0pTEljwPN1WahD7sx4t3QR not in fCAW9dmInLiV: continue
			if rrb0SF6otehufCYOX4!=rfJG62Vo0pTEljwPN1WahD7sx4t3QR: continue
			elif len(items)<2:
				if rfJG62Vo0pTEljwPN1WahD7sx4t3QR==fCAW9dmInLiV[-1]:
					url = PVO4RmQY92jycoli0GtrusH(url)
					OOVrZEwIj5bKYWqe0(url)
				else: XxcpMKIUzr0sVDngR(HOCWKhxITtulVGX,'SPECIFIED_FILTER___'+vMp6jZbo3UkEsSxRFQndyA)
				return
			else:
				HOCWKhxITtulVGX = PVO4RmQY92jycoli0GtrusH(HOCWKhxITtulVGX)
				if rfJG62Vo0pTEljwPN1WahD7sx4t3QR==fCAW9dmInLiV[-1]: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'الجميع',HOCWKhxITtulVGX,511)
				else: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'الجميع',HOCWKhxITtulVGX,515,cdZKMn68Pzg4,cdZKMn68Pzg4,vMp6jZbo3UkEsSxRFQndyA)
		elif type=='ALL_ITEMS_FILTER':
			if rfJG62Vo0pTEljwPN1WahD7sx4t3QR not in w6wuL59PgeE: continue
			gmjZQuBFv8RzlNtDVEOc = KFGqxsBnZYLb3NvMU+'&'+rfJG62Vo0pTEljwPN1WahD7sx4t3QR+'=0'
			qwmxUpZfQj8EAV3Tc = ejQ8ZCtBaV7+'&'+rfJG62Vo0pTEljwPN1WahD7sx4t3QR+'=0'
			vMp6jZbo3UkEsSxRFQndyA = gmjZQuBFv8RzlNtDVEOc+'___'+qwmxUpZfQj8EAV3Tc
			if   name=='type': name = 'النوع'
			elif name=='category': name = 'العمل'
			elif name=='foreign': name = 'اللغة'
			elif name=='year': name = 'السنة'
			elif name=='seasonal': name = 'الموسم'
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'الجميع: '+name,HOCWKhxITtulVGX,514,cdZKMn68Pzg4,cdZKMn68Pzg4,vMp6jZbo3UkEsSxRFQndyA)
		dict[rfJG62Vo0pTEljwPN1WahD7sx4t3QR] = {}
		for value,zj6FI51Rypka0e8xiECfc7g in items:
			if zj6FI51Rypka0e8xiECfc7g in cJWUPuDGM0Yybv5a9KnIrVzhH78: continue
			if 'مصنفات أخرى' in zj6FI51Rypka0e8xiECfc7g: continue
			if 'الكل' in zj6FI51Rypka0e8xiECfc7g: continue
			if 'اللغة' in zj6FI51Rypka0e8xiECfc7g: continue
			zj6FI51Rypka0e8xiECfc7g = zj6FI51Rypka0e8xiECfc7g.replace('قائمة ',cdZKMn68Pzg4)
			if   name=='type': name = 'النوع'
			elif name=='category': name = 'العمل'
			elif name=='foreign': name = 'اللغة'
			elif name=='year': name = 'السنة'
			elif name=='seasonal': name = 'الموسم'
			dict[rfJG62Vo0pTEljwPN1WahD7sx4t3QR][value] = zj6FI51Rypka0e8xiECfc7g
			gmjZQuBFv8RzlNtDVEOc = KFGqxsBnZYLb3NvMU+'&'+rfJG62Vo0pTEljwPN1WahD7sx4t3QR+'='+zj6FI51Rypka0e8xiECfc7g
			qwmxUpZfQj8EAV3Tc = ejQ8ZCtBaV7+'&'+rfJG62Vo0pTEljwPN1WahD7sx4t3QR+'='+value
			AL8gJZ0NtE91Bexjin4 = gmjZQuBFv8RzlNtDVEOc+'___'+qwmxUpZfQj8EAV3Tc
			if name: title = zj6FI51Rypka0e8xiECfc7g+' :'+name
			else: title = zj6FI51Rypka0e8xiECfc7g
			if type=='ALL_ITEMS_FILTER': zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,url,514,cdZKMn68Pzg4,cdZKMn68Pzg4,AL8gJZ0NtE91Bexjin4)
			elif type=='SPECIFIED_FILTER' and fCAW9dmInLiV[-2]+'=' in KFGqxsBnZYLb3NvMU:
				N8jUpQxY0rhtDAzbG4kOs9X = VyEHqwXn7B9xFRidWhNoIkJP(qwmxUpZfQj8EAV3Tc,url)
				zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,N8jUpQxY0rhtDAzbG4kOs9X,511)
			else: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,url,515,cdZKMn68Pzg4,cdZKMn68Pzg4,AL8gJZ0NtE91Bexjin4)
	return
def XFoM2xPKIt3u51hLj(o3JURfrMDgp76,mode):
	o3JURfrMDgp76 = o3JURfrMDgp76.replace('=&','=0&')
	o3JURfrMDgp76 = o3JURfrMDgp76.strip('&')
	bLxfgF7nlO1uZiY9e5T0HDdIw3kpy = {}
	if '=' in o3JURfrMDgp76:
		items = o3JURfrMDgp76.split('&')
		for HYBN2AQsjimSMgT8OvE3ynX67tJwR in items:
			IN0jyfe1PRdDz6YX3CoJkHthw,value = HYBN2AQsjimSMgT8OvE3ynX67tJwR.split('=')
			bLxfgF7nlO1uZiY9e5T0HDdIw3kpy[IN0jyfe1PRdDz6YX3CoJkHthw] = value
	n7VBe6ZgDI14lizTfHOmk = cdZKMn68Pzg4
	for key in w6wuL59PgeE:
		if key in list(bLxfgF7nlO1uZiY9e5T0HDdIw3kpy.keys()): value = bLxfgF7nlO1uZiY9e5T0HDdIw3kpy[key]
		else: value = '0'
		if '%' not in value: value = YQlEOShHM7RLak2t0yA4NXqv(value)
		if mode=='modified_values' and value!='0': n7VBe6ZgDI14lizTfHOmk = n7VBe6ZgDI14lizTfHOmk+' + '+value
		elif mode=='modified_filters' and value!='0': n7VBe6ZgDI14lizTfHOmk = n7VBe6ZgDI14lizTfHOmk+'&'+key+'='+value
		elif mode=='all_filters': n7VBe6ZgDI14lizTfHOmk = n7VBe6ZgDI14lizTfHOmk+'&'+key+'='+value
	n7VBe6ZgDI14lizTfHOmk = n7VBe6ZgDI14lizTfHOmk.strip(' + ')
	n7VBe6ZgDI14lizTfHOmk = n7VBe6ZgDI14lizTfHOmk.strip('&')
	n7VBe6ZgDI14lizTfHOmk = n7VBe6ZgDI14lizTfHOmk.replace('=0','=')
	return n7VBe6ZgDI14lizTfHOmk
fCAW9dmInLiV = []
w6wuL59PgeE = []
# -*- coding: utf-8 -*-
from RgJNGc7YMP import *
UkXlAzsMcamKJrEIgnxi6bWh = 'MOVS4U'
nc3GLkA65oxOd = '_M4U_'
cDTdfqVAF0BLGiX364IEwaZbr = USuRxnPlV5.SITESURLS[UkXlAzsMcamKJrEIgnxi6bWh][0]
cJWUPuDGM0Yybv5a9KnIrVzhH78 = ['انواع افلام','جودات افلام']
def HHN5EpbszV3iA2m89hGSQjaPgUZy(mode,url,text):
	if   mode==380: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = kUq58vC7x9hWma164JejMKQ()
	elif mode==381: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = GDQUH4fN02sIt81mAcY(url,text)
	elif mode==382: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = RPZbqous7rtdy56LeI18Cv04AKHW(url)
	elif mode==383: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = yIZWSuMpvs3(url)
	elif mode==389: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = z4hetAJw3NaT9ROjG6xbZ5CHlW81(text)
	else: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = False
	return xsGUcR3ef6glKY5hQwpFXEaSt2mrIz
def kUq58vC7x9hWma164JejMKQ():
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'بحث في الموقع',cdZKMn68Pzg4,389,cdZKMn68Pzg4,cdZKMn68Pzg4,'_REMEMBERRESULTS_')
	zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+'المميزة',cDTdfqVAF0BLGiX364IEwaZbr,381,cdZKMn68Pzg4,cdZKMn68Pzg4,'featured')
	zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+'الجانبية',cDTdfqVAF0BLGiX364IEwaZbr,381,cdZKMn68Pzg4,cdZKMn68Pzg4,'sider')
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(r43t1YI9deXA5N,'GET',cDTdfqVAF0BLGiX364IEwaZbr,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'MOVS4U-MENU-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('<header>.*?<h2>(.*?)<',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	for udsnZkQyF3Air1Jfa in range(len(items)):
		title = items[udsnZkQyF3Air1Jfa]
		zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+title,cDTdfqVAF0BLGiX364IEwaZbr,381,cdZKMn68Pzg4,cdZKMn68Pzg4,'latest'+str(udsnZkQyF3Air1Jfa))
	KdWauEhgN6OQzjRVm1ro8tkB3 = cdZKMn68Pzg4
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="menu"(.*?)id="contenedor"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg: KdWauEhgN6OQzjRVm1ro8tkB3 += ppvsMqCHf8SEzxQg[0]
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="sidebar(.*?)aside',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg: KdWauEhgN6OQzjRVm1ro8tkB3 += ppvsMqCHf8SEzxQg[0]
	items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)">(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	XMkp5KNroQDVvUx73j9qus = True
	for c0cDhidBlOn7,title in items:
		title = gbd90SjF2mZqf81IRDaTwJkWu(title)
		if title=='الأعلى مشاهدة':
			if XMkp5KNroQDVvUx73j9qus:
				title = 'الافلام '+title
				XMkp5KNroQDVvUx73j9qus = False
			else: title = 'المسلسلات '+title
		if title not in cJWUPuDGM0Yybv5a9KnIrVzhH78:
			zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+title,c0cDhidBlOn7,381)
	return OO1cj2REUZHJ8x5V
def GDQUH4fN02sIt81mAcY(url,type):
	KdWauEhgN6OQzjRVm1ro8tkB3,items = [],[]
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'MOVS4U-TITLES-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	if type=='search':
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="search-page"(.*?)class="sidebar',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if ppvsMqCHf8SEzxQg:
			KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
			items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	elif type=='sider':
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="widget(.*?)class="widget',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		cJlvymaUHYeNWoCLXFkpB4 = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?img src="(.*?)".*?<h3>(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		pcX7zxFRmsADwUr,R5G4cMtH1s7yLifBl,lycT0JB1noerD5YANK2PbHa8QVM = zip(*cJlvymaUHYeNWoCLXFkpB4)
		items = zip(R5G4cMtH1s7yLifBl,pcX7zxFRmsADwUr,lycT0JB1noerD5YANK2PbHa8QVM)
	elif type=='featured':
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('id="slider-movies-tvshows"(.*?)<header>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	elif 'latest' in type:
		udsnZkQyF3Air1Jfa = int(type[-1:])
		OO1cj2REUZHJ8x5V = OO1cj2REUZHJ8x5V.replace('<header>','<end><start>')
		OO1cj2REUZHJ8x5V = OO1cj2REUZHJ8x5V.replace('<div class="sidebar','<end><div class="sidebar')
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('<start>(.*?)<end>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[udsnZkQyF3Air1Jfa]
		if udsnZkQyF3Air1Jfa==2: items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	else:
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="content"(.*?)class="(pagination|sidebar)',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if ppvsMqCHf8SEzxQg:
			KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0][0]
			if '/collection/' in url:
				items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			elif '/quality/' in url:
				items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if not items and KdWauEhgN6OQzjRVm1ro8tkB3:
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('img src="(.*?)".*?href=.*?href="(.*?)">(.*?)</div>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	KRmzvoWYyxfXw37SEh1Q = []
	for y90BoFz8MA1ZThaSC2ILXHiK3OY6w,c0cDhidBlOn7,title in items:
		if 'serie' in title:
			title = ffUFBJQ57j2XgoGeOLn9uwpC.findall('^(.*?)<.*?serie">(.*?)<',title,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			title = title[0][1]
			if title in KRmzvoWYyxfXw37SEh1Q: continue
			KRmzvoWYyxfXw37SEh1Q.append(title)
			title = '_MOD_'+title
		UHXfFEWmlxMAnzju4 = ffUFBJQ57j2XgoGeOLn9uwpC.findall('^(.*?)<',title,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if UHXfFEWmlxMAnzju4: title = UHXfFEWmlxMAnzju4[0]
		title = gbd90SjF2mZqf81IRDaTwJkWu(title)
		if '/tvshows/' in c0cDhidBlOn7: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,383,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
		elif '/episodes/' in c0cDhidBlOn7: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,383,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
		elif '/seasons/' in c0cDhidBlOn7: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,383,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
		elif '/collection/' in c0cDhidBlOn7: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,381,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
		else: zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,382,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="pagination".*?Page (.*?) of (.*?)<(.*?)</div>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		VXxybARMk9IFTOlE652Wvns30c = ppvsMqCHf8SEzxQg[0][0]
		fRI5FEbq01nS8m3rKUlJBguZ6j9PNW = ppvsMqCHf8SEzxQg[0][1]
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0][2]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall("href='(.*?)'.*?>(.*?)<",KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,title in items:
			if title==cdZKMn68Pzg4 or title==fRI5FEbq01nS8m3rKUlJBguZ6j9PNW: continue
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'صفحة '+title,c0cDhidBlOn7,381,cdZKMn68Pzg4,cdZKMn68Pzg4,type)
		c0cDhidBlOn7 = c0cDhidBlOn7.replace('/page/'+title+KCQExdbYFqM,'/page/'+fRI5FEbq01nS8m3rKUlJBguZ6j9PNW+KCQExdbYFqM)
		zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'اخر صفحة '+fRI5FEbq01nS8m3rKUlJBguZ6j9PNW,c0cDhidBlOn7,381,cdZKMn68Pzg4,cdZKMn68Pzg4,type)
	return
def yIZWSuMpvs3(url):
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'MOVS4U-EPISODES-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	eVdYQAPy2Dm = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="C rated".*?>(.*?)<',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if eVdYQAPy2Dm and bMOpKuUkQ5J2(UkXlAzsMcamKJrEIgnxi6bWh,url,eVdYQAPy2Dm,False):
		zJLApFBcIhnSj('link',nc3GLkA65oxOd+'المسلسل للكبار والمبرمج منعه',cdZKMn68Pzg4,9999)
		return
	if '/episodes/' in url or '/tvshows/' in url:
		HOCWKhxITtulVGX = ffUFBJQ57j2XgoGeOLn9uwpC.findall('''class='item'><a href="(.*?)"''',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if HOCWKhxITtulVGX:
			HOCWKhxITtulVGX = HOCWKhxITtulVGX[1]
			yIZWSuMpvs3(HOCWKhxITtulVGX)
			return
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('''class='episodios'(.*?)id="cast"''',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('''src='(.*?)'.*?class='numerando'>(.*?)<.*?href='(.*?)'>(.*?)<''',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for y90BoFz8MA1ZThaSC2ILXHiK3OY6w,E0w56WHxZPYGVvnTQ4O2t1C8DAjq,c0cDhidBlOn7,name in items:
			title = E0w56WHxZPYGVvnTQ4O2t1C8DAjq+' : '+name+' الحلقة'
			zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,382)
	return
def RPZbqous7rtdy56LeI18Cv04AKHW(url):
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'MOVS4U-PLAY-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	eVdYQAPy2Dm = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="C rated".*?>(.*?)<',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if eVdYQAPy2Dm and bMOpKuUkQ5J2(UkXlAzsMcamKJrEIgnxi6bWh,url,eVdYQAPy2Dm): return
	pcX7zxFRmsADwUr = []
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('''id='player-option-1'(.*?)class=("sheader"|'pag_episodes')''',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0][0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall("data-url='(.*?)'.*?class='server'>(.*?)<",KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,title in items:
			c0cDhidBlOn7 = c0cDhidBlOn7+'?named='+title+'__watch'
			pcX7zxFRmsADwUr.append(c0cDhidBlOn7)
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="remodal"(.*?)class="remodal-close"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="___dl_gdrive.*?href="(.*?)".*?">(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,title in items:
			c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr+c0cDhidBlOn7
			c0cDhidBlOn7 = c0cDhidBlOn7+'?named='+title+'__download'
			pcX7zxFRmsADwUr.append(c0cDhidBlOn7)
	import r0y4XTKznF
	r0y4XTKznF.noHliPXkcg3pJTdSauCvm5sU(pcX7zxFRmsADwUr,UkXlAzsMcamKJrEIgnxi6bWh,'video',url)
	return
def z4hetAJw3NaT9ROjG6xbZ5CHlW81(search):
	search,EL8zUgbXheot,showDialogs = qbIcHCMdkFKn21e(search)
	if search==cdZKMn68Pzg4: search = BzkmLuvJD9n25Pg()
	if search==cdZKMn68Pzg4: return
	search = search.replace(VBpIH2QSmvDGlA6TO3e,'+')
	url = cDTdfqVAF0BLGiX364IEwaZbr+'/?s='+search
	GDQUH4fN02sIt81mAcY(url,'search')
	return
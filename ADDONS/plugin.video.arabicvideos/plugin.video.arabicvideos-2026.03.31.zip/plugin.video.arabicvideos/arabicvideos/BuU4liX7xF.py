# -*- coding: utf-8 -*-
from RgJNGc7YMP import *
UkXlAzsMcamKJrEIgnxi6bWh = 'EGYDEAD'
nc3GLkA65oxOd = '_EGD_'
cDTdfqVAF0BLGiX364IEwaZbr = USuRxnPlV5.SITESURLS[UkXlAzsMcamKJrEIgnxi6bWh][0]
cJWUPuDGM0Yybv5a9KnIrVzhH78 = ['مصارعة','احدث البرامج','احدث الالعاب','الرئيسية','احدث الاغانى']
def HHN5EpbszV3iA2m89hGSQjaPgUZy(mode,url,text):
	if   mode==440: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = kUq58vC7x9hWma164JejMKQ()
	elif mode==441: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = GDQUH4fN02sIt81mAcY(url,text)
	elif mode==442: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = RPZbqous7rtdy56LeI18Cv04AKHW(url)
	elif mode==443: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = yIZWSuMpvs3(url)
	elif mode==449: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = z4hetAJw3NaT9ROjG6xbZ5CHlW81(text)
	else: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = False
	return xsGUcR3ef6glKY5hQwpFXEaSt2mrIz
def kUq58vC7x9hWma164JejMKQ():
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',cDTdfqVAF0BLGiX364IEwaZbr,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'EGYDEAD-MENU-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	u1P73L0UmkA4eaIBbCgZfrvRtJ = CxlbPZwGTcH87e1sWhfSIz29uRUEpV(cDTdfqVAF0BLGiX364IEwaZbr,'url')
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'بحث في الموقع',cdZKMn68Pzg4,449,cdZKMn68Pzg4,cdZKMn68Pzg4,'_REMEMBERRESULTS_')
	zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+'الرئيسية',cDTdfqVAF0BLGiX364IEwaZbr,441)
	zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="title_menu_right"(.*?)</div>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
	items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)">(.*?)</a>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	for c0cDhidBlOn7,title in items:
		if title in cJWUPuDGM0Yybv5a9KnIrVzhH78: continue
		if c0cDhidBlOn7=='#': continue
		zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+title,c0cDhidBlOn7,441)
	return
def GDQUH4fN02sIt81mAcY(url,o0oyFGTp3nZdCrAEzlf8XbjJ6=cdZKMn68Pzg4):
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'EGYDEAD-TITLES-2nd')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="list-related"(.*?)class="pagination"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
	items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('<li>.*?href="(.*?)".*?<h1>(.*?)</h1>.*?src="(.*?)"',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	for c0cDhidBlOn7,title,y90BoFz8MA1ZThaSC2ILXHiK3OY6w in items:
		if '/url/' in c0cDhidBlOn7: continue
		elif '/season/' in c0cDhidBlOn7: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,443,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
		elif '/episode/' in c0cDhidBlOn7: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,443,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
		else: zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,442,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="pagination"(.*?)</div>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)">(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,title in items:
			title = gbd90SjF2mZqf81IRDaTwJkWu(title)
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'صفحة '+title,c0cDhidBlOn7,441)
	return
def yIZWSuMpvs3(url):
	data = {'View':1}
	headers = {'Content-Type':'application/x-www-form-urlencoded'}
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'POST',url,data,headers,cdZKMn68Pzg4,cdZKMn68Pzg4,'EGYDEAD-EPISODES-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	ptXc2zV0RhTb = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"seasons-list"(.*?)</div>.</div>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	ll9vYSyie5kwbR16U0a2K = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"episodes-list"(.*?)</div>.</div>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ptXc2zV0RhTb:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ptXc2zV0RhTb[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="([^"]*)" title="([^"]*)".*?src="(.*?)"',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,title,y90BoFz8MA1ZThaSC2ILXHiK3OY6w in items:
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,443,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
	elif ll9vYSyie5kwbR16U0a2K:
		y90BoFz8MA1ZThaSC2ILXHiK3OY6w = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"og:image" content="(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		y90BoFz8MA1ZThaSC2ILXHiK3OY6w = y90BoFz8MA1ZThaSC2ILXHiK3OY6w[0]
		KdWauEhgN6OQzjRVm1ro8tkB3 = ll9vYSyie5kwbR16U0a2K[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?>(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,title in items:
			title = title.replace(ssELJkeScrtni2,cdZKMn68Pzg4).strip(VBpIH2QSmvDGlA6TO3e)
			zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,442,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
	return
def RPZbqous7rtdy56LeI18Cv04AKHW(url):
	data = {'View':1}
	headers = {'Content-Type':'application/x-www-form-urlencoded'}
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'POST',url,data,headers,cdZKMn68Pzg4,cdZKMn68Pzg4,'EGYDEAD-PLAY-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	pcX7zxFRmsADwUr = []
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"watchAreaMaster"(.*?)</ul>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('data-link="(.*?)".*?<p>(.*?)</p>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,title in items:
			title = title.replace(ssELJkeScrtni2,cdZKMn68Pzg4).strip(VBpIH2QSmvDGlA6TO3e)
			c0cDhidBlOn7 = c0cDhidBlOn7+'?named='+title+'__watch'
			pcX7zxFRmsADwUr.append(c0cDhidBlOn7)
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"donwload-servers-list"(.*?)</ul>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"ser-name">(.*?)</span>.*?<em>(.*?)</em>.*?href="(.*?)"',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for title,l1MCIuwhAELbO2eJ96kNta7rp0B,c0cDhidBlOn7 in items:
			c0cDhidBlOn7 = c0cDhidBlOn7.replace(ssELJkeScrtni2,cdZKMn68Pzg4)
			c0cDhidBlOn7 = c0cDhidBlOn7+'?named='+title+'__download'+'____'+l1MCIuwhAELbO2eJ96kNta7rp0B
			pcX7zxFRmsADwUr.append(c0cDhidBlOn7)
	import r0y4XTKznF
	r0y4XTKznF.noHliPXkcg3pJTdSauCvm5sU(pcX7zxFRmsADwUr,UkXlAzsMcamKJrEIgnxi6bWh,'video',url)
	return
def z4hetAJw3NaT9ROjG6xbZ5CHlW81(search):
	search,EL8zUgbXheot,showDialogs = qbIcHCMdkFKn21e(search)
	if search==cdZKMn68Pzg4: search = BzkmLuvJD9n25Pg()
	if search==cdZKMn68Pzg4: return
	search = search.replace(VBpIH2QSmvDGlA6TO3e,'+')
	url = cDTdfqVAF0BLGiX364IEwaZbr+'/?s='+search
	GDQUH4fN02sIt81mAcY(url)
	return
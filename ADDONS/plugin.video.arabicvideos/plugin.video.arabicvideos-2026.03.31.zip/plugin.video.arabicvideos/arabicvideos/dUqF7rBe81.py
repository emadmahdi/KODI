# -*- coding: utf-8 -*-
import sys as sjVE6XGymcf09qbiKODZdAC
LVpmDXhWH5wGKy1eqMB = sjVE6XGymcf09qbiKODZdAC.version_info [0] == 2
RGEuTe9PD7o45d2v = 2048
r3HIioGW0Nl = 7
def Brz09AF6apy52OuEq1s (ccr3g6sWvxSOqDiLJuF1Vf2KUtG):
	global YzIBLo1J4ZOCEPtjq
	SSzr8EskcFRLobZqtC2QeTyPg4Y = ord (ccr3g6sWvxSOqDiLJuF1Vf2KUtG [-1])
	JIf7wGht4BqbQ5Xik1mYTA3DeLvaPO = ccr3g6sWvxSOqDiLJuF1Vf2KUtG [:-1]
	ZYd0PzhKWmvFN5TfcQI = SSzr8EskcFRLobZqtC2QeTyPg4Y % len (JIf7wGht4BqbQ5Xik1mYTA3DeLvaPO)
	itRzfVamqWwLIynhGpDM4ZUe = JIf7wGht4BqbQ5Xik1mYTA3DeLvaPO [:ZYd0PzhKWmvFN5TfcQI] + JIf7wGht4BqbQ5Xik1mYTA3DeLvaPO [ZYd0PzhKWmvFN5TfcQI:]
	if LVpmDXhWH5wGKy1eqMB:
		MHSngXbpVZde6NiQc9IrCxt78 = unicode () .join ([unichr (ord (Ep0JIWsLABieR) - RGEuTe9PD7o45d2v - (D2bEPIlOQJy4dYntR3MCiKLusT + SSzr8EskcFRLobZqtC2QeTyPg4Y) % r3HIioGW0Nl) for D2bEPIlOQJy4dYntR3MCiKLusT, Ep0JIWsLABieR in enumerate (itRzfVamqWwLIynhGpDM4ZUe)])
	else:
		MHSngXbpVZde6NiQc9IrCxt78 = str () .join ([chr (ord (Ep0JIWsLABieR) - RGEuTe9PD7o45d2v - (D2bEPIlOQJy4dYntR3MCiKLusT + SSzr8EskcFRLobZqtC2QeTyPg4Y) % r3HIioGW0Nl) for D2bEPIlOQJy4dYntR3MCiKLusT, Ep0JIWsLABieR in enumerate (itRzfVamqWwLIynhGpDM4ZUe)])
	return eval (MHSngXbpVZde6NiQc9IrCxt78)
ObuCsdoDtKmhPLSMH8YGan,vbYokBuWlxeLDcdVNM60,J6jL2d7CKE0WA4lBXFPghR5eoxHb=Brz09AF6apy52OuEq1s,Brz09AF6apy52OuEq1s,Brz09AF6apy52OuEq1s
aNdix5gq7yeFHTMWhnzm8pX0Y16,dwiIAcPl04ey7Zv38Mz,zBGPHsxIiQmd7oTSORl9bAynr5kNq=J6jL2d7CKE0WA4lBXFPghR5eoxHb,vbYokBuWlxeLDcdVNM60,ObuCsdoDtKmhPLSMH8YGan
rbUkdYi32PJaRtnxhDvQs,TtyzcuW45VKA,LungQF89BqemOb32jJsZlW=zBGPHsxIiQmd7oTSORl9bAynr5kNq,dwiIAcPl04ey7Zv38Mz,aNdix5gq7yeFHTMWhnzm8pX0Y16
iRfoNckJs7Ibxzh5j92w8DSWF,NV3enkyQ7Rmp2LYAUagsCJz0ZP,HC9xWUMpBQJEuTteAqjd=LungQF89BqemOb32jJsZlW,TtyzcuW45VKA,rbUkdYi32PJaRtnxhDvQs
s8fcjBCSMxzAIkZQbJPga,AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu,liyzjA4RkEb1cT6fr5pGKdWNHOxM=HC9xWUMpBQJEuTteAqjd,NV3enkyQ7Rmp2LYAUagsCJz0ZP,iRfoNckJs7Ibxzh5j92w8DSWF
nfg30bHwd4aNV12SR7UjFck,Rsdai9xIEPcpuBMKOUwkTA05q,KNomgGw1kdMCBH=liyzjA4RkEb1cT6fr5pGKdWNHOxM,AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu,s8fcjBCSMxzAIkZQbJPga
SGazRxP3yBKZ15ILuch,YnHG75e2QWwo,S5fhsRT8JV=KNomgGw1kdMCBH,Rsdai9xIEPcpuBMKOUwkTA05q,nfg30bHwd4aNV12SR7UjFck
WupgNDhcjK1SiYsF5VLGb9w3loJqX,f8Ja1q5eO02B,xN4fKmsnyM3Y2=S5fhsRT8JV,YnHG75e2QWwo,SGazRxP3yBKZ15ILuch
uxE8MyoTRglrcaiQf,aar0zhDnJsOTP7EdgR16HIS29,opyTNwHgfqbZREWKU=xN4fKmsnyM3Y2,f8Ja1q5eO02B,WupgNDhcjK1SiYsF5VLGb9w3loJqX
On1WZJc6dtksqVNgSQ5GBAjuipe,AiCor1fIVTDxQUWwHe9vPR7,tRnTydV03Xfi7rbQ=opyTNwHgfqbZREWKU,aar0zhDnJsOTP7EdgR16HIS29,uxE8MyoTRglrcaiQf
LJPOQNK1mcG,k5oIaYyp2mnrLK49qhzS,zDek1IW37rq6UoKdwyRiAVpF=tRnTydV03Xfi7rbQ,AiCor1fIVTDxQUWwHe9vPR7,On1WZJc6dtksqVNgSQ5GBAjuipe
nnsBpJv6XL3OzHoe4Vuhr = WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"࠱ୌ")
hiuZa0PIsErm6UC7 = uxE8MyoTRglrcaiQf(u"࠳୍")
bVX3ev1spE = hiuZa0PIsErm6UC7+hiuZa0PIsErm6UC7
kzoASbNraPcfgvWJmY9Qu = bVX3ev1spE+hiuZa0PIsErm6UC7
iwQJREcVTSe1G2gCvlfhbHWLjqopa = kzoASbNraPcfgvWJmY9Qu+hiuZa0PIsErm6UC7
ffXqoLey4TixFJBw = iwQJREcVTSe1G2gCvlfhbHWLjqopa+hiuZa0PIsErm6UC7
cdZKMn68Pzg4 = opyTNwHgfqbZREWKU(u"ࠨࠩऎ")
VBpIH2QSmvDGlA6TO3e = uxE8MyoTRglrcaiQf(u"ࠩࠣࠫए")
wr0HaqRdJ2D9LT7nSO1KMe38ly = VBpIH2QSmvDGlA6TO3e*bVX3ev1spE
U4ImogGksPlcBVfAb = VBpIH2QSmvDGlA6TO3e*kzoASbNraPcfgvWJmY9Qu
KATUbrqnhgW2GkBJzMDsREmtdo78 = VBpIH2QSmvDGlA6TO3e*iwQJREcVTSe1G2gCvlfhbHWLjqopa
KCQExdbYFqM = tRnTydV03Xfi7rbQ(u"ࠪ࠳ࠬऐ")
Tf2ZPslXS84Yw15aNkjQ7oOzqMc = Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠫ࠴࠵ࠧऑ")
RRAmELdrBNQGixkaTlC8ozVFe = None
IZQbmFzLHDtXfc = J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"࡚ࡲࡶࡧ௝")
ksTLSoVGg0ht = zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"ࡆࡢ࡮ࡶࡩ௞")
oUr1mT5EvIdqsGk2L4lzN0bQWF = zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"ࠬࡺࡲࡶࡧࠪऒ")
c5oDzdPaOE8 = liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"࠭ࡦࡢ࡮ࡶࡩࠬओ")
Il4q1Ex7r0Y6wy2URk = rbUkdYi32PJaRtnxhDvQs(u"ࠧࡪࡩࡱࡳࡷ࡫ࠧऔ")
rrVbXS3ncE = opyTNwHgfqbZREWKU(u"ࠨࡦࡨࡪࡦࡻ࡬ࡵࠩक")
Gzygq01Kcb9U3 = NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡂ࠶࠴ࡉࡡࠬख")
bxf7gZvNK29cEoiAIJlMq0dP = dwiIAcPl04ey7Zv38Mz(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭ग")
CiT8064NnsVFjXPEeulg = nfg30bHwd4aNV12SR7UjFck(u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌ࠳࠴ࡇ࠷࠷࠸ࡣࠧघ")
UYh8R2GJEfrXjVHCvNKsmn5qi7Plb1 = iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆ࠲ࡈ࠸࠵ࡋࡌ࡝ࠨङ")
t6HKdS7oBje = zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋࡌࡆ࡞ࠩच")
kH8E2zqNyims6KJfI = SGazRxP3yBKZ15ILuch(u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩछ")
vczMIlkCAh2u10B3 = Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠨࡷࡷࡪ࠽࠭ज")
OtSgpZ7UjmKc3byDVQeWaEs890Xi = vbYokBuWlxeLDcdVNM60(u"ࠩ࡯ࡥࡹ࡯࡮࠮࠳ࠪझ")
wJCp6Gzbj8MseURla0mA = iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠪࡻ࡮ࡴࡤࡰࡹࡶ࠱࠶࠸࠵࠷ࠩञ")
F0FeocLXmbJhdBwQnS18PCHZIU = liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠫࡓࡕࡔࡊࡅࡈࠫट")
z0KNn8M5AxaD = k5oIaYyp2mnrLK49qhzS(u"ࠬࡋࡒࡓࡑࡕࠫठ")
Q2QMvk3bx0CGJWSUwD = LungQF89BqemOb32jJsZlW(u"࠭ࡎࡐࡖࡌࡇࡊࡥࡌࡊࡐࡈࡗࠬड")
E7lrS9VXJF58d2NUAfkvxwjmHM = k5oIaYyp2mnrLK49qhzS(u"ࠧࡆࡔࡕࡓࡗࡥࡌࡊࡐࡈࡗࠬढ")
ssELJkeScrtni2 = On1WZJc6dtksqVNgSQ5GBAjuipe(u"ࠨ࡞ࡱࠫण")
CPjOZMmw8sfGg2B9LthIdXa1iKQUF = liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠩ࡟ࡶࠬत")
OPEJxmUqr9wAX1i = xN4fKmsnyM3Y2(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭थ")
ngqTJ78iecsjdCm5oHura4y296z = AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"࠴୎")
TuarUEP9zs0McA578H = AiCor1fIVTDxQUWwHe9vPR7(u"࠴࠳࠻୏")
VyzRWqDrhcN5GIKEwvsn7SFedpJ0 = KNomgGw1kdMCBH(u"࠶࠻୐")
f16kp9FnD8hu4jE0PKYHAWrbz73Z = SGazRxP3yBKZ15ILuch(u"࠹࠰୑")
cneX6ol3AGWza = ObuCsdoDtKmhPLSMH8YGan(u"࠱࠱୒")
aJ7EUN4tGwuilRyzvkj6OpCr3PoZK = NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"࠲࠴࠳୓")
CXwBHcf58s064NoZSvnWk7RMm = TtyzcuW45VKA(u"࠶࠸୔")
d37Zoe1YJgWbMq = ffXqoLey4TixFJBw
YDRXFsreOpQqg3vTBUiGEP9hmf = YnHG75e2QWwo(u"࠹࠴୕")
lgZ9dofsL1JV5vQHTDS = S5fhsRT8JV(u"࠺࠵ୖ")*YDRXFsreOpQqg3vTBUiGEP9hmf
xDMBVFezZ6QH = On1WZJc6dtksqVNgSQ5GBAjuipe(u"࠷࠺ୗ")*lgZ9dofsL1JV5vQHTDS
Kn3dwIyPYiuSBgkt = aar0zhDnJsOTP7EdgR16HIS29(u"࠹࠰୘")*xDMBVFezZ6QH
fS25N8gAZxpbnLi3srX7PJ = nnsBpJv6XL3OzHoe4Vuhr
qIOfxknj8DiBYboGtQN4v = nfg30bHwd4aNV12SR7UjFck(u"࠳࠱୙")*YDRXFsreOpQqg3vTBUiGEP9hmf
AlfMBJhUD65to2WrQcb = bVX3ev1spE*lgZ9dofsL1JV5vQHTDS
K8DZxE74Afz52gBYbOMtpvql0RJma = uxE8MyoTRglrcaiQf(u"࠲࠸୚")*lgZ9dofsL1JV5vQHTDS
r43t1YI9deXA5N = kzoASbNraPcfgvWJmY9Qu*xDMBVFezZ6QH
tvpq3ilsT1ZYAenaVj09BC2d = aar0zhDnJsOTP7EdgR16HIS29(u"࠵࠳୛")*xDMBVFezZ6QH
jCmv4M3HNPdyaLS = vbYokBuWlxeLDcdVNM60(u"࠴࠶ଡ଼")*Kn3dwIyPYiuSBgkt
kZK9jh5ufsoVAmxreYPbyUaR7I0LO = lgZ9dofsL1JV5vQHTDS
G9Gz76P41qQAW2viUsjEymXYOVuBSc = [aar0zhDnJsOTP7EdgR16HIS29(u"ฺࠫ็ัࠨद"),xN4fKmsnyM3Y2(u"ࠬษ่ๅࠩध"),f8Ja1q5eO02B(u"࠭หศ่ํࠫन"),uxE8MyoTRglrcaiQf(u"ࠧฬษ็ฯࠬऩ"),nfg30bHwd4aNV12SR7UjFck(u"ࠨำสฬ฾࠭प"),uxE8MyoTRglrcaiQf(u"ࠩัหู๊ࠧफ"),AiCor1fIVTDxQUWwHe9vPR7(u"ࠪืฬีำࠨब"),aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ุࠫอศฺࠩभ"),s8fcjBCSMxzAIkZQbJPga(u"ࠬัวๆ่ࠪम"),aar0zhDnJsOTP7EdgR16HIS29(u"࠭สศี฼ࠫय"),s8fcjBCSMxzAIkZQbJPga(u"ฺࠧษืีࠬर")]
vcRx8yJAizIX6Uo4suNKkHjObMEt = [
						 J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡖࡉࡓࡊ࡟ࡂࡐࡄࡐ࡞࡚ࡉࡄࡕࡢࡉ࡛ࡋࡎࡕࡕ࠰࠵ࡸࡺࠧऱ")
						,LJPOQNK1mcG(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡉ࡝࡚ࡒࡂࡅࡗࡣࡒ࠹ࡕ࠹࠯࠴ࡷࡹ࠭ल")
						,AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡗࡇࡎࡅࡑࡐࡣ࡚࡙ࡅࡓࡃࡊࡉࡓ࡚࠭࠲ࡵࡷࠫळ")
						,opyTNwHgfqbZREWKU(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡅࡕࡡࡓࡖࡔ࡞ࡉࡆࡕࡢࡐࡎ࡙ࡔ࠮࠳ࡶࡸࠬऴ")
						,k5oIaYyp2mnrLK49qhzS(u"ࠬࡏࡐࡕࡘ࠰ࡇࡍࡋࡃࡌࡡࡄࡇࡈࡕࡕࡏࡖ࠰࠵ࡸࡺࠧव")
						,J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡇࡒࡐࡔࡉࡁࡕࡋࡒࡒ࠲࠷ࡳࡵࠩश")
						,xN4fKmsnyM3Y2(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡉࡒࡓࡌࡒࡅࡠࡐࡈ࡛ࡤࡎࡏࡔࡖࡑࡅࡒࡋ࠭࠲ࡵࡷࠫष")
						,liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡓࡔࡍࡌࡆࡡࡑࡉ࡜ࡥࡈࡐࡕࡗࡒࡆࡓࡅ࠮࠵ࡵࡨࠬस")
						,zDek1IW37rq6UoKdwyRiAVpF(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡖࡊࡇࡄࡠࡃࡏࡐࡤࡇࡄࡅࡑࡑࡗࡤ࡞ࡍࡍ࠯࠴ࡷࡹ࠭ह")
						,KNomgGw1kdMCBH(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡇࡐࡑࡊࡐࡊ࡛ࡓࡆࡔࡆࡓࡓ࡚ࡅࡏࡖ࠰࠵ࡸࡺࠧऺ")
						,S5fhsRT8JV(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡃ࡛ࡓࡅࡘ࡙࡟ࡂࡍ࡚ࡅࡒࡥࡃࡂࡒࡗࡇࡍࡇ࠭࠴ࡴࡧࠫऻ")
						,ObuCsdoDtKmhPLSMH8YGan(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡄ࡜ࡔࡆ࡙ࡓࡠࡃࡎ࡛ࡆࡓ࡟ࡄࡃࡓࡘࡈࡎࡁ࠮࠷ࡷ࡬़ࠬ")
						,KNomgGw1kdMCBH(u"࠭ࡅࡍࡅࡌࡒࡊࡓࡁ࠮ࡕࡈࡅࡗࡉࡈ࠮࠳ࡶࡸࠬऽ")
						,dwiIAcPl04ey7Zv38Mz(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡜ࡘࡎࡁࡓࡋࡑࡋ࠲࠷ࡳࡵࠩा")
						,LungQF89BqemOb32jJsZlW(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡝࡙ࡈࡂࡔࡌࡒࡌ࠳࠲࡯ࡦࠪि")
						]
kHDGhLdZK2jg4oFJ9567xAN = vcRx8yJAizIX6Uo4suNKkHjObMEt+[
				 WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡔࡗࡕࡘ࡚ࡡࡗࡉࡘ࡚࠭࠲ࡵࡷࠫी")
				,xN4fKmsnyM3Y2(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤࡎࡔࡕࡒࡖࡔࡗࡕࡘࡊࡇࡖ࠱࠶ࡹࡴࠨु")
				,KNomgGw1kdMCBH(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡕࡐࡆࡐࡘࡖࡑࡥࡗࡆࡄࡓࡖࡔ࡞ࡉࡆࡕ࠰࠵ࡸࡺࠧू")
				,opyTNwHgfqbZREWKU(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡘࡇࡅࡔࡗࡕࡘࡊࡇࡖ࠱࠷ࡴࡤࠨृ")
				,AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠ࡙ࡈࡆࡕࡘࡏ࡙࡛ࡗࡓ࠲࠷ࡳࡵࠩॄ")
				,zDek1IW37rq6UoKdwyRiAVpF(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡑࡓࡉࡓ࡛ࡒࡍࡡ࡚ࡉࡇࡖࡒࡐ࡚࡜ࡘࡔ࠳࠲࡯ࡦࠪॅ")
				,tRnTydV03Xfi7rbQ(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢࡏࡕࡘࡏ࡙࡛ࡆࡓࡒ࠳࠱ࡴࡶࠪॆ")
				,tRnTydV03Xfi7rbQ(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡓࡕࡋࡎࡖࡔࡏࡣࡐࡖࡒࡐ࡚࡜ࡇࡔࡓ࠭࠳ࡰࡧࠫे")
				,xN4fKmsnyM3Y2(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤࡑࡐࡓࡑ࡛࡝ࡈࡕࡍ࠮࠵ࡵࡨࠬै")
				,opyTNwHgfqbZREWKU(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡉࡈࡆࡅࡎࡣࡍ࡚ࡔࡑࡕࡢࡔࡗࡕࡘࡊࡇࡖ࠱࠶ࡹࡴࠨॉ")
				,opyTNwHgfqbZREWKU(u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙࠭ࡉࡖࡗࡔࡘࡥࡔࡆࡕࡗ࠱࠶ࡹࡴࠨॊ")
				,vbYokBuWlxeLDcdVNM60(u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓ࠮ࡖࡈࡗ࡙ࡥࡁࡍࡎࡢ࡛ࡊࡈࡓࡊࡖࡈࡗ࠲࠷ࡳࡵࠩो")
				,rbUkdYi32PJaRtnxhDvQs(u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࡗࡉࡘ࡚࡟ࡂࡎࡏࡣ࡜ࡋࡂࡔࡋࡗࡉࡘ࠳࠲࡯ࡦࠪौ")
				,TtyzcuW45VKA(u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕ࠰࡙ࡘࡇࡇࡆࡡࡕࡉࡕࡕࡒࡕ࠯࠴ࡷࡹ्࠭")
				,zDek1IW37rq6UoKdwyRiAVpF(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡔࡕࡇࡍࡇࡢࡘࡗࡇࡎࡔࡎࡄࡘࡊ࠳࠱ࡴࡶࠪॎ")
				,k5oIaYyp2mnrLK49qhzS(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡗࡋࡖࡆࡔࡖࡓࡤ࡚ࡒࡂࡐࡖࡐࡆ࡚ࡅ࠮࠳ࡶࡸࠬॏ")
				]
D5hGC7XAFyzWLkd9V6cKIEotNfBjp = [
						 Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࡙࠭ࡕࡋࡅࡗࡏࡎࡈ࠯࠴ࡷࡹ࠭ॐ")
						,SGazRxP3yBKZ15ILuch(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡚ࡖࡌࡆࡘࡉࡏࡉ࠰࠶ࡳࡪࠧ॑")
						,k5oIaYyp2mnrLK49qhzS(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡐ࡙ࡑ࡚ࡉࡠ࡚ࡖࡌࡆࡘࡉࡏࡉ࠰࠵ࡸࡺ॒ࠧ")
						]
xDWTUKG8ZJMrLV3aO6QFhoPe4yXIm0 = [s8fcjBCSMxzAIkZQbJPga(u"ࠧࡃࡑࡎࡖࡆ࠭॓"),AiCor1fIVTDxQUWwHe9vPR7(u"ࠨࡒࡄࡒࡊ࡚ࠧ॔"),SGazRxP3yBKZ15ILuch(u"ࠩࡄࡖࡆࡈࡉࡄࡖࡒࡓࡓ࡙ࠧॕ"),s8fcjBCSMxzAIkZQbJPga(u"ࠪࡏࡆࡘࡂࡂࡎࡄࡘ࡛࠭ॖ"),LJPOQNK1mcG(u"ࠫࡎࡌࡉࡍࡏࠪॗ"),AiCor1fIVTDxQUWwHe9vPR7(u"ࠬࡏࡆࡊࡎࡐ࠱ࡆࡘࡁࡃࡋࡆࠫक़"),iRfoNckJs7Ibxzh5j92w8DSWF(u"࠭ࡉࡇࡋࡏࡑ࠲ࡋࡎࡈࡎࡌࡗࡍ࠭ख़")]
xDWTUKG8ZJMrLV3aO6QFhoPe4yXIm0 += [ObuCsdoDtKmhPLSMH8YGan(u"࡚ࠧࡖࡅࡣࡈࡎࡁࡏࡐࡈࡐࡘ࠭ग़"),AiCor1fIVTDxQUWwHe9vPR7(u"ࠨࡃࡎࡓࡆࡓࠧज़"),vbYokBuWlxeLDcdVNM60(u"ࠩࡄࡏ࡜ࡇࡍࠨड़"),KNomgGw1kdMCBH(u"ࠪࡅࡑࡓࡁࡂࡔࡈࡊࠬढ़"),AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"ࠫࡘࡎࡏࡐࡈࡐࡅ࡝࠭फ़")]
AqDuaUtFi2z0S = [liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠬࡒࡁࡓࡑ࡝ࡅࠬय़"),LungQF89BqemOb32jJsZlW(u"࠭ࡆࡂࡌࡈࡖࡘࡎࡏࡘࠩॠ"),vbYokBuWlxeLDcdVNM60(u"ࠧࡕࡘࡉ࡙ࡓ࠭ॡ"),S5fhsRT8JV(u"ࠨࡎࡒࡈ࡞ࡔࡅࡕࠩॢ"),KNomgGw1kdMCBH(u"ࠩࡆࡍࡒࡇࡎࡐ࡙ࠪॣ"),k5oIaYyp2mnrLK49qhzS(u"ࠪࡗࡍࡇࡈࡊࡆࡑࡉ࡜࡙ࠧ।"),aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠫࡆࡘࡁࡃࡕࡈࡉࡉ࠭॥")]
AqDuaUtFi2z0S += [vbYokBuWlxeLDcdVNM60(u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡈࠧ०"),dwiIAcPl04ey7Zv38Mz(u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕࠨ१"),KNomgGw1kdMCBH(u"ࠧࡔࡊࡒࡊࡍࡇࠧ२"),ObuCsdoDtKmhPLSMH8YGan(u"ࠨ࡙ࡈࡇࡎࡓࡁ࠲ࠩ३"),SGazRxP3yBKZ15ILuch(u"࡚ࠩࡉࡈࡏࡍࡂ࠴ࠪ४")]
KF09IsQijZel6B8 = [AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"ࠪࡘࡎࡑࡁࡂࡖࠪ५"),dwiIAcPl04ey7Zv38Mz(u"ࠫࡆ࡟ࡌࡐࡎࠪ६"),opyTNwHgfqbZREWKU(u"ࠬࡌࡏࡔࡖࡄࠫ७"),zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"࠭ࡆࡂࡄࡕࡅࡐࡇࠧ८"),s8fcjBCSMxzAIkZQbJPga(u"࡚ࠧࡃࡔࡓ࡙࠭९"),s8fcjBCSMxzAIkZQbJPga(u"ࠨࡕࡋࡅࡇࡇࡋࡂࡖ࡜ࠫ॰"),ObuCsdoDtKmhPLSMH8YGan(u"࡙ࠩࡅࡗࡈࡏࡏࠩॱ"),Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠪࡆࡗ࡙ࡔࡆࡌࠪॲ")]
KF09IsQijZel6B8 += [WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠫࡐࡏࡒࡎࡃࡏࡏࠬॳ"),opyTNwHgfqbZREWKU(u"ࠬࡇࡎࡊࡏࡈ࡞ࡎࡊࠧॴ"),vbYokBuWlxeLDcdVNM60(u"࠭ࡆࡂࡔࡈࡗࡐࡕࠧॵ"),AiCor1fIVTDxQUWwHe9vPR7(u"ࠧࡉࡃࡏࡅࡈࡏࡍࡂࠩॶ"),On1WZJc6dtksqVNgSQ5GBAjuipe(u"ࠨࡃࡏࡑࡘ࡚ࡂࡂࠩॷ"),AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"ࠩࡖࡌࡔࡕࡆࡏࡇࡗࠫॸ"),opyTNwHgfqbZREWKU(u"ࠪࡈࡗࡇࡍࡂࡕ࠺ࠫॹ")]
KF09IsQijZel6B8 += [S5fhsRT8JV(u"ࠫࡈࡏࡍࡂࡈࡕࡉࡊ࠭ॺ"),iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠬࡉࡉࡎࡃࡉࡅࡓ࡙ࠧॻ"),LJPOQNK1mcG(u"࠭ࡅࡍࡋࡉ࡚ࡎࡊࡅࡐࠩॼ"),KNomgGw1kdMCBH(u"ࠧࡇࡗࡑࡓࡓ࡚ࡖࠨॽ"),TtyzcuW45VKA(u"ࠨࡅࡌࡑࡆࡒࡉࡈࡊࡗࠫॾ"),opyTNwHgfqbZREWKU(u"ࠩࡆࡍࡒࡇ࠴࠱࠲ࠪॿ"),LJPOQNK1mcG(u"ࠪࡇࡎࡓࡁࡂࡄࡇࡓࠬঀ")]
KF09IsQijZel6B8 += [Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠫࡆࡑࡗࡂࡏࡗ࡙ࡇࡋࠧঁ"),f8Ja1q5eO02B(u"ࠬࡓࡁࡔࡃ࡙ࡍࡉࡋࡏࠨং"),J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"࠭ࡄࡓࡃࡐࡅࡈࡇࡆࡆࠩঃ"),zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"ࠧࡇࡗࡖࡌࡆࡘࡔࡗࠩ঄"),nfg30bHwd4aNV12SR7UjFck(u"ࠨࡅࡌࡑࡆ࡝ࡂࡂࡕࠪঅ"),WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠩࡄࡌ࡜ࡇࡋࠨআ"),uxE8MyoTRglrcaiQf(u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠶ࠬই"),NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"࡛ࠫࡏࡄࡆࡑࡑࡗࡆࡋࡍࠨঈ")]
KF09IsQijZel6B8 += [f8Ja1q5eO02B(u"ࠬࡑࡁࡕࡍࡒࡘ࡙࡜ࠧউ"),aNdix5gq7yeFHTMWhnzm8pX0Y16(u"࠭ࡓࡆࡔࡌࡉࡘ࡚ࡉࡎࡇࠪঊ"),Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠧࡇࡗࡖࡌࡆࡘࡖࡊࡆࡈࡓࠬঋ"),aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠨࡅࡌࡑࡆ࠺ࡐࠨঌ"),LJPOQNK1mcG(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠴ࠫ঍"),ObuCsdoDtKmhPLSMH8YGan(u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙࠷࠭঎"),ObuCsdoDtKmhPLSMH8YGan(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠷࠭এ"),zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠺ࠧঐ")]
R5oKmn8zDkX0s4LUYjH1tyf = [aar0zhDnJsOTP7EdgR16HIS29(u"࡙࠭ࡐࡗࡗ࡙ࡇࡋࠧ঑"),J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡘࡌࡈࡊࡕࡓࠨ঒"),vbYokBuWlxeLDcdVNM60(u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡓࡐࡆ࡟ࡌࡊࡕࡗࡗࠬও"),zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡇࡍࡇࡎࡏࡇࡏࡗࠬঔ")]
R5oKmn8zDkX0s4LUYjH1tyf += [aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎࠨক"),On1WZJc6dtksqVNgSQ5GBAjuipe(u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯࡙ࡍࡉࡋࡏࡔࠩখ"),aar0zhDnJsOTP7EdgR16HIS29(u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰ࡔࡑࡇ࡙ࡍࡋࡖࡘࡘ࠭গ"),zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱ࡈࡎࡁࡏࡐࡈࡐࡘ࠭ঘ"),TtyzcuW45VKA(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲ࡒࡉࡗࡇࡖࠫঙ"),LungQF89BqemOb32jJsZlW(u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡈࡂࡕࡋࡘࡆࡍࡓࠨচ")]
TZxtrcmqkHX5LpKwNvQ = [opyTNwHgfqbZREWKU(u"ࠩࡓࡖࡎ࡜ࡁࡕࡇࠪছ")]+xDWTUKG8ZJMrLV3aO6QFhoPe4yXIm0+[s8fcjBCSMxzAIkZQbJPga(u"ࠪࡑࡎ࡞ࡅࡅࠩজ")]+AqDuaUtFi2z0S+[AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"ࠫࡕ࡛ࡂࡍࡋࡆࠫঝ")]+KF09IsQijZel6B8+[J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠬࡖࡒࡊࡘࡄࡘࡊ࠭ঞ")]+R5oKmn8zDkX0s4LUYjH1tyf
yiXoAKGInWCvS4abdrzQ9kts8 = [KNomgGw1kdMCBH(u"࡙࠭ࡕࡄࡢࡇࡍࡇࡎࡏࡇࡏࡗࠬট")]
a5lMo2tB9OP6TbI78KW = [aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠧࡑࡔࡌ࡚ࡆ࡚ࡅࠨঠ"),rbUkdYi32PJaRtnxhDvQs(u"ࠨࡏࡌ࡜ࡊࡊࠧড"),uxE8MyoTRglrcaiQf(u"ࠩࡓ࡙ࡇࡒࡉࡄࠩঢ")]
OOVpBhCE1YNkvbtIzDoxT5fewQqi = [AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"ࠪࡑ࠸࡛ࠧণ"),SGazRxP3yBKZ15ILuch(u"ࠫࡎࡖࡔࡗࠩত"),LJPOQNK1mcG(u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐࠪথ"),iRfoNckJs7Ibxzh5j92w8DSWF(u"࠭ࡉࡇࡋࡏࡑࠬদ"),aNdix5gq7yeFHTMWhnzm8pX0Y16(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨধ")]
FeTta3gS4J1q  = [aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡖࡊࡆࡈࡓࡘ࠭ন"),s8fcjBCSMxzAIkZQbJPga(u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡑࡎࡄ࡝ࡑࡏࡓࡕࡕࠪ঩"),s8fcjBCSMxzAIkZQbJPga(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡅࡋࡅࡓࡔࡅࡍࡕࠪপ"),LungQF89BqemOb32jJsZlW(u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯ࡏࡍ࡛ࡋࡓࠨফ"),f8Ja1q5eO02B(u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰ࡌࡆ࡙ࡈࡕࡃࡊࡗࠬব")]
FeTta3gS4J1q += [opyTNwHgfqbZREWKU(u"࠭ࡉࡇࡋࡏࡑ࠲ࡇࡒࡂࡄࡌࡇࠬভ"),rbUkdYi32PJaRtnxhDvQs(u"ࠧࡊࡈࡌࡐࡒ࠳ࡅࡏࡉࡏࡍࡘࡎࠧম")]
FeTta3gS4J1q += [HC9xWUMpBQJEuTteAqjd(u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯࡙ࡍࡉࡋࡏࡔࠩয"),iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡔࡑࡇ࡙ࡍࡋࡖࡘࡘ࠭র"),xN4fKmsnyM3Y2(u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱ࡈࡎࡁࡏࡐࡈࡐࡘ࠭঱")]
FeTta3gS4J1q += [LJPOQNK1mcG(u"ࠫࡎࡖࡔࡗ࠯ࡏࡍ࡛ࡋࠧল"),AiCor1fIVTDxQUWwHe9vPR7(u"ࠬࡏࡐࡕࡘ࠰ࡑࡔ࡜ࡉࡆࡕࠪ঳"),WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"࠭ࡉࡑࡖ࡙࠱ࡘࡋࡒࡊࡇࡖࠫ঴")]
FeTta3gS4J1q += [SGazRxP3yBKZ15ILuch(u"ࠧࡎ࠵ࡘ࠱ࡑࡏࡖࡆࠩ঵"),aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠨࡏ࠶࡙࠲ࡓࡏࡗࡋࡈࡗࠬশ"),zDek1IW37rq6UoKdwyRiAVpF(u"ࠩࡐ࠷࡚࠳ࡓࡆࡔࡌࡉࡘ࠭ষ")]
iOa0Ytw52I1d7 = list(filter(lambda Qeawx7nAh5RyHpv8Y4c6r9LSgE0X: Qeawx7nAh5RyHpv8Y4c6r9LSgE0X not in FeTta3gS4J1q+yiXoAKGInWCvS4abdrzQ9kts8+a5lMo2tB9OP6TbI78KW+OOVpBhCE1YNkvbtIzDoxT5fewQqi,TZxtrcmqkHX5LpKwNvQ))
RgmY38c0XdHUK1CVwqQ7orZ = iOa0Ytw52I1d7+OOVpBhCE1YNkvbtIzDoxT5fewQqi
wrAD3j7pXC4KmfvTHy5QbxBe0SgM = iOa0Ytw52I1d7+FeTta3gS4J1q
JjQWY0xnmlrqD = wrAD3j7pXC4KmfvTHy5QbxBe0SgM+yiXoAKGInWCvS4abdrzQ9kts8
LHJiIyoDNMjvUXzx = RgmY38c0XdHUK1CVwqQ7orZ+yiXoAKGInWCvS4abdrzQ9kts8
I6RP2hlfdEvxW9GVmpnja = [aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠪࡅࡐࡕࡁࡎࠩস"),YnHG75e2QWwo(u"ࠫࡆࡑࡗࡂࡏࠪহ"),xN4fKmsnyM3Y2(u"ࠬࡏࡆࡊࡎࡐࠫ঺"),HC9xWUMpBQJEuTteAqjd(u"࠭ࡋࡂࡔࡅࡅࡑࡇࡔࡗࠩ঻"),f8Ja1q5eO02B(u"ࠧࡂࡎࡐࡅࡆࡘࡅࡇ়ࠩ"),opyTNwHgfqbZREWKU(u"ࠨࡕࡋࡓࡔࡌࡍࡂ࡚ࠪঽ"),NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠩࡖࡌࡎࡇࡖࡐࡋࡆࡉࠬা"),WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫি"),Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏࠩী"),iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠬࡓ࠳ࡖࠩু"),k5oIaYyp2mnrLK49qhzS(u"࠭ࡉࡑࡖ࡙ࠫূ"),LJPOQNK1mcG(u"ࠧࡃࡑࡎࡖࡆ࠭ৃ"),rbUkdYi32PJaRtnxhDvQs(u"ࠨࡇࡏࡇࡎࡔࡅࡎࡃࠪৄ"),tRnTydV03Xfi7rbQ(u"ࠩࡄࡖࡆࡈࡉࡄࡖࡒࡓࡓ࡙ࠧ৅")]
NOT_TO_TEST_ALL_SERVERS = [dwiIAcPl04ey7Zv38Mz(u"ࠪࡣࡆࡑࡏࡠࠩ৆"),rbUkdYi32PJaRtnxhDvQs(u"ࠫࡤࡇࡋࡘࡡࠪে"),AiCor1fIVTDxQUWwHe9vPR7(u"ࠬࡥࡉࡇࡎࡢࠫৈ"),aar0zhDnJsOTP7EdgR16HIS29(u"࠭࡟ࡌࡔࡅࡣࠬ৉"),AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"ࠧࡠࡏࡕࡊࡤ࠭৊"),k5oIaYyp2mnrLK49qhzS(u"ࠨࡡࡖࡌࡒࡥࠧো"),xN4fKmsnyM3Y2(u"ࠩࡢࡗࡍ࡜࡟ࠨৌ"),aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠪࡣ࡞࡛ࡔࡠ্ࠩ"),vbYokBuWlxeLDcdVNM60(u"ࠫࡤࡊࡌࡎࡡࠪৎ"),uxE8MyoTRglrcaiQf(u"ࠬࡥࡍࡖࠩ৏"),aNdix5gq7yeFHTMWhnzm8pX0Y16(u"࠭࡟ࡊࡒࠪ৐"),f8Ja1q5eO02B(u"ࠧࡠࡄࡎࡖࡤ࠭৑"),YnHG75e2QWwo(u"ࠨࡡࡈࡐࡈࡥࠧ৒"),tRnTydV03Xfi7rbQ(u"ࠩࡢࡅࡗ࡚࡟ࠨ৓")]
E20stJKzNIdSFUakyM5ju = [aar0zhDnJsOTP7EdgR16HIS29(u"ࠪࡑࡊࡔࡕࡠࡔࡈ࡚ࡊࡘࡓࡆࡆࡢࡔࡊࡘࡍࠨ৔"),On1WZJc6dtksqVNgSQ5GBAjuipe(u"ࠫࡒࡋࡎࡖࡡࡄࡗࡈࡋࡎࡅࡇࡇࡣࡕࡋࡒࡎࠩ৕"),uxE8MyoTRglrcaiQf(u"ࠬࡓࡅࡏࡗࡢࡈࡊ࡙ࡃࡆࡐࡇࡉࡉࡥࡐࡆࡔࡐࠫ৖"),LungQF89BqemOb32jJsZlW(u"࠭ࡍࡆࡐࡘࡣࡗࡇࡎࡅࡑࡐࡍ࡟ࡋࡄࡠࡒࡈࡖࡒ࠭ৗ"),HC9xWUMpBQJEuTteAqjd(u"ࠧࡎࡇࡑ࡙ࡤࡘࡅࡗࡇࡕࡗࡊࡊ࡟ࡕࡇࡐࡔࠬ৘"),k5oIaYyp2mnrLK49qhzS(u"ࠨࡏࡈࡒ࡚ࡥࡁࡔࡅࡈࡒࡉࡋࡄࡠࡖࡈࡑࡕ࠭৙"),aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠩࡐࡉࡓ࡛࡟ࡅࡇࡖࡇࡊࡔࡄࡆࡆࡢࡘࡊࡓࡐࠨ৚"),KNomgGw1kdMCBH(u"ࠪࡑࡊࡔࡕࡠࡔࡄࡒࡉࡕࡍࡊ࡜ࡈࡈࡤ࡚ࡅࡎࡒࠪ৛")]
uuetdKFTp7liZB9SM = [nnsBpJv6XL3OzHoe4Vuhr,AiCor1fIVTDxQUWwHe9vPR7(u"࠵࠺࠶ଢ଼"),aar0zhDnJsOTP7EdgR16HIS29(u"࠶࠼࠰୬"),NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"࠲࠹࠳୯"),f8Ja1q5eO02B(u"࠵࠾࠶୤"),nfg30bHwd4aNV12SR7UjFck(u"࠲࠷࠲୧"),LJPOQNK1mcG(u"࠶࠽࠶୫"),zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"࠸࠹࠰୥"),iRfoNckJs7Ibxzh5j92w8DSWF(u"࠴࠶࠳୨"),liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"࠹࠷࠰୞"),aar0zhDnJsOTP7EdgR16HIS29(u"࠵࠱࠲୮"),zDek1IW37rq6UoKdwyRiAVpF(u"࠸࠶࠵ୣ"),zDek1IW37rq6UoKdwyRiAVpF(u"࠸࠷࠵୪"),uxE8MyoTRglrcaiQf(u"࠻࠴࠱୦"),k5oIaYyp2mnrLK49qhzS(u"࠽࠶࠱୭"),J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"࠳࠳࠵࠵ୢ"),aar0zhDnJsOTP7EdgR16HIS29(u"࠺࠻࠼࠴ୡ"),uxE8MyoTRglrcaiQf(u"࠷࠰࠳࠲ୟ"),k5oIaYyp2mnrLK49qhzS(u"࠱࠱࠺࠳ୠ"),vbYokBuWlxeLDcdVNM60(u"࠳࠴࠴࠵୩")]
hyVgRdxpOwil = [dwiIAcPl04ey7Zv38Mz(u"ࠫ࠷࠻࠴ࡥࡦ࠶ࡥ࠹࠶࠹ࡥ࠺ࡥ࠺࠽࠷ࡤ࠵ࡧ࠴࠵࠼࡫ࡥ࠸࠺ࡦࡩࡧ࡬࠲࠺ࠩড়"),AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"ࠬ࠷࠵࠱ࡦ࠵࠶࡫࠷࠭ࡤ࠷࠻ࡥ࠲࠺࠰࠳࠳࠰ࡥࡦ࠾࠴࠮ࡧ࠼࠶࠸ࡩࡡࡧ࠺࠸࠼࠸࠺ࠧঢ়"),NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"࠭࠳࠺࠻࠴ࡩ࠾ࡩ࠵࠮࠹ࡨࡩ࠸࠳࠴ࡦࡧ࠵࠱࠽࠺ࡣ࠱࠯ࡩࡨ࠼࠿࠲ࡣࡣࡧࡨ࠸ࡪ࠵ࠨ৞"),J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠧ࠸࠸ࡥ࠸࡫ࡩ࠳࠵ࡨࡦࡨ࠶࠿ࡤ࠺ࡥ࠸࠹ࡦ࠷࠵ࡧ࠵࠹࠴࠹ࡩࡤ࠺࠳࠷ࡧࠬয়"),rbUkdYi32PJaRtnxhDvQs(u"ࠨ࠳࡙ࡒࡸࡓࡴࡍ࠳ࡲࡆࡗ࡞࡫ࡔࡐࡆࡦࡈࡓࡊ࠲ࡍ࡛࡝ࡏࡰࡪ࠱ࡦ࡭࡞ࡼ࠭ৠ"),aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠩࡤ࠸࡫࠽ࡦࡣ࠳࠷࠱࠷ࡪࡥࡧ࠯࠷࠴࠼࠷࠭࠹࠸࠷ࡦ࠲࠸࠲ࡦ࠵࠵࠺࠹ࡪ࠴ࡥࡦࡦࠫৡ"),HC9xWUMpBQJEuTteAqjd(u"ࠪ࠶ࡧ࠹࠴࠱ࡣ࠹࠼࠾࠶ࡡ࠶࠶࠳࠵ࡩࡨࡣ࠴࠹࠵ࡧ࠶࠷࠴࠶ࡦ࠼࠺࠷࡫࠸ࠨৢ"),HC9xWUMpBQJEuTteAqjd(u"ࠫࡨࡩ࠲࠷࠵ࡤࡦ࠶࡫࠵࠱࠶࠷ࡨ࠷ࡩࡡ࠶ࡦ࠸ࡨ࠸࡬࠹ࡦ࠵ࡦ࠷࠽࠼ࡥࡤࡣ࠴࠵࠵࠾࠳࠹࠻ࡤ࠻࠸࠭ৣ"),AiCor1fIVTDxQUWwHe9vPR7(u"ࠬ࠷ࡣ࠴ࡦ࠶ࡥࡪ࠷࠸࠶ࡦࡩ࠸ࡧ࡬࠶ࡢࡨ࠸࠷࠸ࡩ࠷࠱࠶࠳ࡦ࠸࠺࠷ࡤ࠻ࡨ࠽࠾ࡨࡥ࠵࠸࠹ࡥࡪ࠿ࠧ৤"),J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"࠭࠴࠵ࡨ࠷࠴࠽ࡪ࠴ࡢ࠴ࡰࡷ࡭࠷ࡢ࠴ࡤࡧ࠸࠾ࡧ࠶࠵࠺࠴࠻࡫࠻ࡰ࠲࠲࠴࠴࠸࡬ࡪࡴࡰ࠷ࡥ࠹࠷࠷ࡧࡥ࠸࠷࠵࠺࠲ࠨ৥"),LJPOQNK1mcG(u"ࠧࡣࡤ࠸࠷࠽࠷࠸࠱࠯࠸ࡨ࠶ࡧ࠭࠵ࡥ࠵࠺࠲ࡧࡢ࠷ࡤ࠰࠵࠻ࡨࡢ࠳࠶ࡥ࠺࠾ࡩ࠸ࡢ࠯࠳࠴࠲࠷ࡶ࠶࠻ࡤ࡬࠷࠻ࡱ࠲ࡣ࠹࠴ࠬ০"),tRnTydV03Xfi7rbQ(u"ࠨࡨ࠼ࡪ࠽࠷࠷࠸࠶࠰ࡥࡧ࠿࠸࠮࠶࠴ࡨ࠷࠳࠸࠸࠲ࡧ࠱࠻࠸࠵ࡣ࠺࠷࠺࠺࠸࠵࠴࠳࠰࠴࠵࠳࠱࡮࡫ࡦ࠸ࡩ࡫࡬࡭ࡩࡦࡦࡷ࠭১")]
NNDYUWJbzMOCn3R = [aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠩࡶࡧࡷࡧࡰࡦࡱࡳࡷࠬ২"),aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠪࡷࡨࡸࡡࡱࡧࡵࡥࡵ࡯ࠧ৩"),tRnTydV03Xfi7rbQ(u"ࠫࡸࡩࡲࡢࡲ࡬ࡲ࡬ࡧ࡮ࡵࠩ৪"),vbYokBuWlxeLDcdVNM60(u"ࠬࡹࡣࡳࡣࡳ࡭ࡳ࡭ࡲࡰࡤࡲࡸࠬ৫"),dwiIAcPl04ey7Zv38Mz(u"࠭ࡳࡤࡴࡤࡴࡪࡻࡰࠨ৬"),uxE8MyoTRglrcaiQf(u"ࠧࡴࡥࡵࡥࡵ࡫࠮ࡥࡱࠪ৭"),HC9xWUMpBQJEuTteAqjd(u"ࠨࡴࡤࡴ࡮ࡪࡡࡱ࡫࠱ࡧࡴࡳࠧ৮"),AiCor1fIVTDxQUWwHe9vPR7(u"ࠩࡵࡩࡵࡲࡩࡵ࠰ࡧࡩࡻ࠭৯"),aar0zhDnJsOTP7EdgR16HIS29(u"ࠪ࠵࠷࠽࠮࠱࠰࠳࠲࠶࠭ৰ"),dwiIAcPl04ey7Zv38Mz(u"ࠫࡸ࡫ࡲࡷࡧࡵ࠶࠳ࡱ࡯ࡥ࡫ࡨࡱࡦࡪࠧৱ")]
uI2Uai9YJo38jsN4ltSHEBvOM = {
	 On1WZJc6dtksqVNgSQ5GBAjuipe(u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙࡟࠱ࠩ৲")	: nnsBpJv6XL3OzHoe4Vuhr
	,ObuCsdoDtKmhPLSMH8YGan(u"࠭ࡁࡍࡃࡕࡅࡇ࠭৳")		: NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"࠳࠳୰")
	,KNomgGw1kdMCBH(u"ࠧࡊࡈࡌࡐࡒ࠭৴")		: KNomgGw1kdMCBH(u"࠵࠴ୱ")
	,tRnTydV03Xfi7rbQ(u"ࠨࡒࡄࡒࡊ࡚ࠧ৵")		: SGazRxP3yBKZ15ILuch(u"࠷࠵୲")
	,SGazRxP3yBKZ15ILuch(u"ࠩࡄࡐࡒࡇࡁࡓࡇࡉࠫ৶")		: TtyzcuW45VKA(u"࠹࠶୳")
	,nfg30bHwd4aNV12SR7UjFck(u"ࠪࡗࡍࡕࡏࡇࡏࡄ࡜ࠬ৷")		: LungQF89BqemOb32jJsZlW(u"࠻࠰୴")
	,vbYokBuWlxeLDcdVNM60(u"ࠫࡆࡒࡆࡂࡖࡌࡑࡎ࠭৸")		: zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"࠶࠱୵")
	,nfg30bHwd4aNV12SR7UjFck(u"ࠬࡇࡋࡐࡃࡐࠫ৹")		: SGazRxP3yBKZ15ILuch(u"࠸࠲୶")
	,s8fcjBCSMxzAIkZQbJPga(u"࠭ࡈࡂࡎࡄࡇࡎࡓࡁࠨ৺")		: aar0zhDnJsOTP7EdgR16HIS29(u"࠺࠳୷")
	,k5oIaYyp2mnrLK49qhzS(u"ࠧࡄࡋࡐࡅࡋࡇࡎࡔࠩ৻")		: zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"࠼࠴୸")
	,liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠨࡎࡌ࡚ࡊ࡚ࡖࠨৼ")		: nfg30bHwd4aNV12SR7UjFck(u"࠵࠵࠶୹")
	,Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘࠫ৽")		: SGazRxP3yBKZ15ILuch(u"࠶࠷࠰୺")
	,S5fhsRT8JV(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗࠫ৾")		: liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"࠷࠲࠱୻")
	,f8Ja1q5eO02B(u"ࠫࡆࡒࡋࡂ࡙ࡗࡌࡆࡘࠧ৿")	: NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"࠱࠴࠲୼")
	,nfg30bHwd4aNV12SR7UjFck(u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭਀")		: k5oIaYyp2mnrLK49qhzS(u"࠲࠶࠳୽")
	,ObuCsdoDtKmhPLSMH8YGan(u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓࡠ࠳ࠪਁ")	: Rsdai9xIEPcpuBMKOUwkTA05q(u"࠳࠸࠴୾")
	,dwiIAcPl04ey7Zv38Mz(u"ࠧࡓࡃࡑࡈࡔࡓࡓࡠ࠲ࠪਂ")	: aNdix5gq7yeFHTMWhnzm8pX0Y16(u"࠴࠺࠵୿")
	,LungQF89BqemOb32jJsZlW(u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕࡢ࠶ࠬਃ")	: LungQF89BqemOb32jJsZlW(u"࠵࠼࠶஀")
	,xN4fKmsnyM3Y2(u"ࠩࡐࡓ࡛ࡏ࡚ࡍࡃࡑࡈࠬ਄")	: On1WZJc6dtksqVNgSQ5GBAjuipe(u"࠶࠾࠰஁")
	,aar0zhDnJsOTP7EdgR16HIS29(u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗࡤ࠹ࠧਅ")	: HC9xWUMpBQJEuTteAqjd(u"࠷࠹࠱ஂ")
	,f8Ja1q5eO02B(u"ࠫࡆࡘࡂࡍࡋࡒࡒ࡟࠭ਆ")		: nfg30bHwd4aNV12SR7UjFck(u"࠲࠱࠲ஃ")
	,dwiIAcPl04ey7Zv38Mz(u"࡙ࠬࡅࡓࡋࡈࡗ࠹࡝ࡁࡕࡅࡋࠫਇ")	: aar0zhDnJsOTP7EdgR16HIS29(u"࠳࠳࠳஄")
	,SGazRxP3yBKZ15ILuch(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚ࡖࡊࡒࠪਈ")	: YnHG75e2QWwo(u"࠴࠵࠴அ")
	,NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠧࡊࡒࡗ࡚ࡤ࠶ࠧਉ")		: AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"࠵࠷࠵ஆ")
	,On1WZJc6dtksqVNgSQ5GBAjuipe(u"ࠨࡃࡎ࡛ࡆࡓࠧਊ")		: J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"࠶࠹࠶இ")
	,AiCor1fIVTDxQUWwHe9vPR7(u"ࠩࡄࡖࡆࡈࡓࡆࡇࡇࠫ਋")		: S5fhsRT8JV(u"࠷࠻࠰ஈ")
	,Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠪࡑࡊࡔࡕࡔࡡ࠳ࠫ਌")		: zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"࠸࠶࠱உ")
	,dwiIAcPl04ey7Zv38Mz(u"ࠫࡋࡇࡖࡐࡔࡌࡘࡊ࡙ࠧ਍")	: f8Ja1q5eO02B(u"࠲࠸࠲ஊ")
	,YnHG75e2QWwo(u"ࠬࡏࡐࡕࡘࡢ࠵ࠬ਎")		: SGazRxP3yBKZ15ILuch(u"࠳࠺࠳஋")
	,vbYokBuWlxeLDcdVNM60(u"࡙࠭ࡕࡄࡢࡇࡍࡇࡎࡏࡇࡏࡗࠬਏ")	: J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"࠴࠼࠴஌")
	,LungQF89BqemOb32jJsZlW(u"ࠧࡄࡋࡐࡅࡓࡕࡗࠨਐ")		: TtyzcuW45VKA(u"࠶࠴࠵஍")
	,nfg30bHwd4aNV12SR7UjFck(u"ࠨࡕࡋࡍࡆ࡜ࡏࡊࡅࡈࠫ਑")	: On1WZJc6dtksqVNgSQ5GBAjuipe(u"࠷࠶࠶எ")
	,vbYokBuWlxeLDcdVNM60(u"ࠩࡎࡅࡗࡈࡁࡍࡃࡗ࡚ࠬ਒")	: NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"࠸࠸࠰ஏ")
	,AiCor1fIVTDxQUWwHe9vPR7(u"ࠪࡈࡔ࡝ࡎࡍࡑࡄࡈࠬਓ")		: HC9xWUMpBQJEuTteAqjd(u"࠹࠳࠱ஐ")
	,tRnTydV03Xfi7rbQ(u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘࡥ࠴ࠨਔ")	: uxE8MyoTRglrcaiQf(u"࠳࠵࠲஑")
	,f8Ja1q5eO02B(u"ࠬࡇࡋࡐࡃࡐࡇࡆࡓࠧਕ")		: KNomgGw1kdMCBH(u"࠴࠷࠳ஒ")
	,WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"࠭ࡍ࡚ࡅࡌࡑࡆ࠭ਖ")		: nfg30bHwd4aNV12SR7UjFck(u"࠵࠹࠴ஓ")
	,zDek1IW37rq6UoKdwyRiAVpF(u"ࠧࡃࡑࡎࡖࡆ࠭ਗ")		: aNdix5gq7yeFHTMWhnzm8pX0Y16(u"࠶࠻࠵ஔ")
	,k5oIaYyp2mnrLK49qhzS(u"ࠨࡏࡒ࡚ࡘ࠺ࡕࠨਘ")		: AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"࠷࠽࠶க")
	,HC9xWUMpBQJEuTteAqjd(u"ࠩࡉࡅࡏࡋࡒࡔࡊࡒ࡛ࠬਙ")	: liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"࠸࠿࠰஖")
	,ObuCsdoDtKmhPLSMH8YGan(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎࡠ࠲ࠪਚ"): s8fcjBCSMxzAIkZQbJPga(u"࠺࠰࠱஗")
	,liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏࡡ࠴ࠫਛ"): KNomgGw1kdMCBH(u"࠴࠲࠲஘")
	,aar0zhDnJsOTP7EdgR16HIS29(u"ࠬࡉࡉࡎࡃ࠷࡙ࠬਜ")		: HC9xWUMpBQJEuTteAqjd(u"࠵࠴࠳ங")
	,s8fcjBCSMxzAIkZQbJPga(u"࠭ࡅࡈ࡛ࡑࡓ࡜࠭ਝ")		: J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"࠶࠶࠴ச")
	,liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠧࡆࡉ࡜ࡈࡊࡇࡄࠨਞ")		: Rsdai9xIEPcpuBMKOUwkTA05q(u"࠷࠸࠵஛")
	,SGazRxP3yBKZ15ILuch(u"ࠨࡎࡒࡈ࡞ࡔࡅࡕࠩਟ")		: KNomgGw1kdMCBH(u"࠸࠺࠶ஜ")
	,AiCor1fIVTDxQUWwHe9vPR7(u"ࠩࡗ࡚ࡋ࡛ࡎࠨਠ")		: HC9xWUMpBQJEuTteAqjd(u"࠹࠼࠰஝")
	,liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠪࡇࡎࡓࡁࡍࡋࡊࡌ࡙࠭ਡ")	: ObuCsdoDtKmhPLSMH8YGan(u"࠺࠷࠱ஞ")
	,f8Ja1q5eO02B(u"ࠫࡘࡎࡏࡐࡈࡓࡖࡔ࠭ਢ")		: HC9xWUMpBQJEuTteAqjd(u"࠴࠹࠲ட")
	,opyTNwHgfqbZREWKU(u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡖࠧਣ")		: AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"࠵࠻࠳஠")
	,YnHG75e2QWwo(u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓࡠ࠷ࠪਤ")	: f8Ja1q5eO02B(u"࠷࠳࠴஡")
	,HC9xWUMpBQJEuTteAqjd(u"ࠧࡆࡎࡆࡍࡓࡋࡍࡂࡡ࠳ࠫਥ")	: f8Ja1q5eO02B(u"࠸࠵࠵஢")
	,nfg30bHwd4aNV12SR7UjFck(u"ࠨࡇࡏࡇࡎࡔࡅࡎࡃࡢ࠵ࠬਦ")	: opyTNwHgfqbZREWKU(u"࠹࠷࠶ண")
	,HC9xWUMpBQJEuTteAqjd(u"ࠩࡐࡉࡓ࡛ࡓࡠ࠳ࠪਧ")		: k5oIaYyp2mnrLK49qhzS(u"࠺࠹࠰த")
	,k5oIaYyp2mnrLK49qhzS(u"ࠪࡋࡑࡕࡂࡂࡎࡖࡉࡆࡘࡃࡉࠩਨ")	: SGazRxP3yBKZ15ILuch(u"࠻࠴࠱஥")
	,HC9xWUMpBQJEuTteAqjd(u"ࠫࡈࡏࡍࡂࡃࡅࡈࡔ࠭਩")		: AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"࠵࠶࠲஦")
	,NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠬ࡝ࡅࡄࡋࡐࡅ࠶࠭ਪ")		: On1WZJc6dtksqVNgSQ5GBAjuipe(u"࠶࠸࠳஧")
	,nfg30bHwd4aNV12SR7UjFck(u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠱ࠨਫ")		: xN4fKmsnyM3Y2(u"࠷࠺࠴ந")
	,vbYokBuWlxeLDcdVNM60(u"ࠧࡔࡊࡄࡌࡎࡊࡎࡆ࡙ࡖࠫਬ")	: xN4fKmsnyM3Y2(u"࠸࠼࠵ன")
	,LungQF89BqemOb32jJsZlW(u"ࠨࡈࡄࡗࡊࡒࡈࡅ࠴ࠪਭ")		: S5fhsRT8JV(u"࠹࠾࠶ப")
	,k5oIaYyp2mnrLK49qhzS(u"ࠩࡉࡓࡘ࡚ࡁࠨਮ")		: aar0zhDnJsOTP7EdgR16HIS29(u"࠻࠶࠰஫")
	,TtyzcuW45VKA(u"ࠪࡅࡍ࡝ࡁࡌࠩਯ")		: iRfoNckJs7Ibxzh5j92w8DSWF(u"࠼࠱࠱஬")
	,s8fcjBCSMxzAIkZQbJPga(u"ࠫࡋࡇࡂࡓࡃࡎࡅࠬਰ")		: S5fhsRT8JV(u"࠶࠳࠲஭")
	,LungQF89BqemOb32jJsZlW(u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡈࡗࡐࡔࡎࠫ਱")	: rbUkdYi32PJaRtnxhDvQs(u"࠷࠵࠳ம")
	,xN4fKmsnyM3Y2(u"࠭ࡓࡉࡑࡉࡌࡆ࠭ਲ")		: iRfoNckJs7Ibxzh5j92w8DSWF(u"࠸࠷࠴ய")
	,LJPOQNK1mcG(u"ࠧࡃࡔࡖࡘࡊࡐࠧਲ਼")		: On1WZJc6dtksqVNgSQ5GBAjuipe(u"࠹࠹࠵ர")
	,LungQF89BqemOb32jJsZlW(u"ࠨ࡛ࡄࡕࡔ࡚ࠧ਴")		: nfg30bHwd4aNV12SR7UjFck(u"࠺࠻࠶ற")
	,uxE8MyoTRglrcaiQf(u"ࠩࡎࡅ࡙ࡑࡏࡖࡖࡈࠫਵ")		: k5oIaYyp2mnrLK49qhzS(u"࠻࠽࠰ல")
	,uxE8MyoTRglrcaiQf(u"ࠪࡈࡗࡇࡍࡂࡕ࠺ࠫਸ਼")		: SGazRxP3yBKZ15ILuch(u"࠼࠸࠱ள")
	,S5fhsRT8JV(u"ࠫࡈࡏࡍࡂ࠶࠳࠴ࠬ਷")		: Rsdai9xIEPcpuBMKOUwkTA05q(u"࠶࠺࠲ழ")
	,rbUkdYi32PJaRtnxhDvQs(u"ࠬࡒࡁࡓࡑ࡝ࡅࠬਸ")		: S5fhsRT8JV(u"࠸࠲࠳வ")
	,SGazRxP3yBKZ15ILuch(u"࠭ࡍ࠴ࡗࡢ࠴ࠬਹ")		: LungQF89BqemOb32jJsZlW(u"࠹࠴࠴ஶ")
	,nfg30bHwd4aNV12SR7UjFck(u"ࠧࡎ࠵ࡘࡣ࠶࠭਺")		: TtyzcuW45VKA(u"࠺࠶࠵ஷ")
	,LungQF89BqemOb32jJsZlW(u"ࠨࡃࡕࡅࡇࡏࡃࡕࡑࡒࡒࡘ࠭਻")	: aar0zhDnJsOTP7EdgR16HIS29(u"࠻࠸࠶ஸ")
	,k5oIaYyp2mnrLK49qhzS(u"ࠩࡆࡐࡊࡇࡎࡆࡔࡢ࠴਼ࠬ")	: vbYokBuWlxeLDcdVNM60(u"࠼࠺࠰ஹ")
	,ObuCsdoDtKmhPLSMH8YGan(u"ࠪࡇࡑࡋࡁࡏࡇࡕࡣ࠶࠭਽")	: AiCor1fIVTDxQUWwHe9vPR7(u"࠽࠵࠱஺")
	,opyTNwHgfqbZREWKU(u"ࠫࡗࡇࡎࡅࡑࡐࡗࡤ࠷ࠧਾ")	: YnHG75e2QWwo(u"࠷࠷࠲஻")
	,ObuCsdoDtKmhPLSMH8YGan(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠷ࠧਿ")		: dwiIAcPl04ey7Zv38Mz(u"࠸࠹࠳஼")
	,AiCor1fIVTDxQUWwHe9vPR7(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠲ࠨੀ")		: HC9xWUMpBQJEuTteAqjd(u"࠹࠻࠴஽")
	,liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠴ࠩੁ")		: s8fcjBCSMxzAIkZQbJPga(u"࠺࠽࠵ா")
	,aar0zhDnJsOTP7EdgR16HIS29(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠶ࠪੂ")		: S5fhsRT8JV(u"࠼࠵࠶ி")
	,xN4fKmsnyM3Y2(u"ࠩࡎࡅ࡙ࡑࡏࡕࡖ࡙ࠫ੃")		: AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"࠽࠷࠰ீ")
	,zDek1IW37rq6UoKdwyRiAVpF(u"ࠪࡇࡎࡓࡁࡄࡎࡘࡆࠬ੄")		: uxE8MyoTRglrcaiQf(u"࠾࠲࠱ு")
	,KNomgGw1kdMCBH(u"ࠫࡈࡏࡍࡂࡈࡕࡉࡊ࠭੅")		: S5fhsRT8JV(u"࠸࠴࠲ூ")
	,uxE8MyoTRglrcaiQf(u"࡙ࠬࡈࡐࡑࡉࡒࡊ࡚ࠧ੆")		: aNdix5gq7yeFHTMWhnzm8pX0Y16(u"࠹࠶࠳௃")
	,vbYokBuWlxeLDcdVNM60(u"࠭ࡁࡌ࡙ࡄࡑ࡙࡛ࡂࡆࠩੇ")	: LJPOQNK1mcG(u"࠺࠸࠴௄")
	,HC9xWUMpBQJEuTteAqjd(u"ࠧࡂࡎࡐࡗ࡙ࡈࡁࠨੈ")		: WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"࠻࠺࠵௅")
	,HC9xWUMpBQJEuTteAqjd(u"ࠨࡘࡄࡖࡇࡕࡎࠨ੉")		: tRnTydV03Xfi7rbQ(u"࠼࠼࠶ெ")
	,HC9xWUMpBQJEuTteAqjd(u"ࠩࡆࡍࡒࡇ࠴ࡑࠩ੊")		: On1WZJc6dtksqVNgSQ5GBAjuipe(u"࠽࠾࠰ே")
	,opyTNwHgfqbZREWKU(u"ࠪࡗࡊࡘࡉࡆࡕࡗࡍࡒࡋࠧੋ")	: f8Ja1q5eO02B(u"࠾࠹࠱ை")
	,aar0zhDnJsOTP7EdgR16HIS29(u"ࠫࡋ࡛ࡓࡉࡃࡕ࡚ࡎࡊࡅࡐࠩੌ")	: HC9xWUMpBQJEuTteAqjd(u"࠹࠱࠲௉")
	,HC9xWUMpBQJEuTteAqjd(u"ࠬࡌࡕࡔࡊࡄࡖ࡙࡜੍ࠧ")		: On1WZJc6dtksqVNgSQ5GBAjuipe(u"࠺࠳࠳ொ")
	,J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"࠭ࡋࡊࡔࡐࡅࡑࡑࠧ੎")		: WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"࠻࠵࠴ோ")
	,f8Ja1q5eO02B(u"ࠧࡅࡔࡄࡑࡆࡉࡁࡇࡇࠪ੏")	: SGazRxP3yBKZ15ILuch(u"࠼࠷࠵ௌ")
	,aar0zhDnJsOTP7EdgR16HIS29(u"ࠨࡖࡌࡏࡆࡇࡔࠨ੐")		: HC9xWUMpBQJEuTteAqjd(u"࠽࠹࠶்")
	,Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠩࡔࡊࡎࡒࡍࠨੑ")		: iRfoNckJs7Ibxzh5j92w8DSWF(u"࠾࠻࠰௎")
	,WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠪࡗࡍࡇࡂࡂࡍࡄࡘ࡞࠭੒")	: S5fhsRT8JV(u"࠿࠶࠱௏")
	,TtyzcuW45VKA(u"ࠫࡆࡔࡉࡎࡇ࡝ࡍࡉ࠭੓")		: iRfoNckJs7Ibxzh5j92w8DSWF(u"࠹࠸࠲ௐ")
	,uxE8MyoTRglrcaiQf(u"ࠬࡉࡉࡎࡃ࡚ࡆࡆ࡙ࠧ੔")		: J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"࠺࠺࠳௑")
	,k5oIaYyp2mnrLK49qhzS(u"࠭ࡆࡂࡔࡈࡗࡐࡕࠧ੕")		: SGazRxP3yBKZ15ILuch(u"࠻࠼࠴௒")
	,ObuCsdoDtKmhPLSMH8YGan(u"ࠧࡘࡇࡆࡍࡒࡇ࠲ࠨ੖")		: AiCor1fIVTDxQUWwHe9vPR7(u"࠴࠴࠵࠶௓")
	,liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠨࡉࡒࡓࡌࡒࡅࡔࡇࡄࡖࡈࡎࠧ੗")	: opyTNwHgfqbZREWKU(u"࠵࠵࠷࠰௔")
	,ObuCsdoDtKmhPLSMH8YGan(u"ࠩࡖࡉࡗ࡜ࡉࡄࡇࡖࡣ࠻࠭੘")	: rbUkdYi32PJaRtnxhDvQs(u"࠶࠶࠲࠱௕")
	,SGazRxP3yBKZ15ILuch(u"࡚ࠪࡎࡊࡅࡐࡐࡖࡅࡊࡓࠧਖ਼")	: zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"࠷࠰࠴࠲௖")
	,nfg30bHwd4aNV12SR7UjFck(u"ࠫࡒࡇࡓࡂࡘࡌࡈࡊࡕࠧਗ਼")	: vbYokBuWlxeLDcdVNM60(u"࠱࠱࠶࠳ௗ")
	,iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠬࡇ࡙ࡍࡑࡏࠫਜ਼")		: LJPOQNK1mcG(u"࠲࠲࠸࠴௘")
	,NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"࠭ࡅࡍࡋࡉ࡚ࡎࡊࡅࡐࠩੜ")	: dwiIAcPl04ey7Zv38Mz(u"࠳࠳࠺࠵௙")
	,rbUkdYi32PJaRtnxhDvQs(u"ࠧࡇࡗࡑࡓࡓ࡚ࡖࠨ੝")		: On1WZJc6dtksqVNgSQ5GBAjuipe(u"࠴࠴࠼࠶௚")
	,On1WZJc6dtksqVNgSQ5GBAjuipe(u"ࠨࡅࡏࡉࡆࡔࡅࡓࡡ࠵ࠫਫ਼")	: opyTNwHgfqbZREWKU(u"࠵࠵࠾࠰௛")
	,k5oIaYyp2mnrLK49qhzS(u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘ࠶ࠬ੟")	: KNomgGw1kdMCBH(u"࠶࠶࠹࠱௜")
}
xW1LphyaGM5ijDzZKlmkS = {
	rbUkdYi32PJaRtnxhDvQs(u"ࠪࡥ࡭ࡽࡡ࡬ࠩ੠")				:ObuCsdoDtKmhPLSMH8YGan(u"๊ࠫ๎โฺࠢฦ๋ํอใࠡฬํๅ๏࠭੡")
	,LJPOQNK1mcG(u"ࠬࡧ࡫ࡰࡣࡰࠫ੢")				:s8fcjBCSMxzAIkZQbJPga(u"࠭ๅ้ไ฼ࠤศ้่ศ็ࠣห้่ฯ๋็ࠪ੣")
	,f8Ja1q5eO02B(u"ࠧࡢ࡭ࡲࡥࡲࡩࡡ࡮ࠩ੤")				:Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠨ็๋ๆ฾ࠦรไ๊ส้้ࠥวๆࠩ੥")
	,KNomgGw1kdMCBH(u"ࠩࡤ࡯ࡼࡧ࡭ࠨ੦")				:f8Ja1q5eO02B(u"้ࠪํู่ࠡลๆ์ฬ๋ࠠศๆฯำ๏ีࠧ੧")
	,YnHG75e2QWwo(u"ࠫࡦࡱࡷࡢ࡯ࡷࡹࡧ࡫ࠧ੨")			:dwiIAcPl04ey7Zv38Mz(u"๋่ࠬใ฻ࠣห่๎วๆࠢอ๎ํฮࠧ੩")
	,TtyzcuW45VKA(u"࠭ࡡ࡭ࡣࡵࡥࡧ࠭੪")				:s8fcjBCSMxzAIkZQbJPga(u"ࠧๆ๊ๅ฽้ࠥไࠡษ็฽ึฮࠧ੫")
	,AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"ࠨࡣ࡯ࡪࡦࡺࡩ࡮࡫ࠪ੬")				:YnHG75e2QWwo(u"่ࠩ์็฿ࠠศๆ่๊อืࠠศๆไห฼๋๊ࠨ੭")
	,s8fcjBCSMxzAIkZQbJPga(u"ࠪࡥࡱࡱࡡࡸࡶ࡫ࡥࡷ࠭੮")			:AiCor1fIVTDxQUWwHe9vPR7(u"๊ࠫ๎โฺࠢๅ๊ฬฯࠠศๆๆ์ะืࠧ੯")
	,nfg30bHwd4aNV12SR7UjFck(u"ࠬࡧ࡬࡮ࡣࡤࡶࡪ࡬ࠧੰ")				:AiCor1fIVTDxQUWwHe9vPR7(u"࠭ๅ้ไ฼ࠤ็์วสࠢส่๊฿วาใࠪੱ")
	,f8Ja1q5eO02B(u"ࠧࡢ࡮ࡰࡷࡹࡨࡡࠨੲ")				:zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"ࠨ็๋ๆ฾ࠦวๅ็ุ฻อฯࠧੳ")
	,vbYokBuWlxeLDcdVNM60(u"ࠩࡤࡲ࡮ࡳࡥࡻ࡫ࡧࠫੴ")				:WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"้ࠪํู่ࠡษ้้๏ࠦาะࠩੵ")
	,s8fcjBCSMxzAIkZQbJPga(u"ࠫࡦࡸࡡࡣ࡫ࡦࡸࡴࡵ࡮ࡴࠩ੶")			:k5oIaYyp2mnrLK49qhzS(u"๋่ࠬใ฻ࠣวึอศ๋ๅࠣฮํ์าࠨ੷")
	,f8Ja1q5eO02B(u"࠭ࡡࡳࡣࡥࡷࡪ࡫ࡤࠨ੸")				:On1WZJc6dtksqVNgSQ5GBAjuipe(u"ࠧๆ๊ๅ฽ࠥ฿ัษࠢึ๎๏ีࠧ੹")
	,AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"ࠨࡣࡵࡦࡱ࡯࡯࡯ࡼࠪ੺")				:On1WZJc6dtksqVNgSQ5GBAjuipe(u"่ࠩ์็฿ฺࠠำหࠤ้๐่็ิࠪ੻")
	,iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠪࡥࡾࡲ࡯࡭ࠩ੼")				:TtyzcuW45VKA(u"๊ࠫ๎โฺࠢฦ๎้๎ไࠨ੽")
	,YnHG75e2QWwo(u"ࠬࡨ࡯࡬ࡴࡤࠫ੾")				:ObuCsdoDtKmhPLSMH8YGan(u"࠭ๅ้ไ฼ࠤอ้ัศࠩ੿")
	,LJPOQNK1mcG(u"ࠧࡣࡴࡶࡸࡪࡰࠧ઀")				:tRnTydV03Xfi7rbQ(u"ࠨ็๋ๆ฾ࠦศาีอ๎ั࠭ઁ")
	,LungQF89BqemOb32jJsZlW(u"ࠩࡦ࡭ࡲࡧ࠴࠱࠲ࠪં")				:dwiIAcPl04ey7Zv38Mz(u"้ࠪํู่ࠡีํ้ฬࠦ࠴࠱࠲ࠪઃ")
	,s8fcjBCSMxzAIkZQbJPga(u"ࠫࡨ࡯࡭ࡢ࠶ࡳࠫ઄")				:iRfoNckJs7Ibxzh5j92w8DSWF(u"๋่ࠬใ฻ࠣื๏๋วࠡใ๋ีࠥฮ๊ࠨઅ")
	,rbUkdYi32PJaRtnxhDvQs(u"࠭ࡣࡪ࡯ࡤ࠸ࡺ࠭આ")				:dwiIAcPl04ey7Zv38Mz(u"ࠧๆ๊ๅ฽ู๊ࠥๆษࠣๅํื๊้ࠩઇ")
	,HC9xWUMpBQJEuTteAqjd(u"ࠨࡥ࡬ࡱࡦࡧࡢࡥࡱࠪઈ")				:LJPOQNK1mcG(u"่ࠩ์็฿ࠠิ์่หࠥ฿ศะ๊ࠪઉ")
	,nfg30bHwd4aNV12SR7UjFck(u"ࠪࡧ࡮ࡳࡡࡤ࡮ࡸࡦࠬઊ")				:xN4fKmsnyM3Y2(u"๊ࠫ๎โฺࠢึ๎๊อࠠไๆ๋ฬࠬઋ")
	,tRnTydV03Xfi7rbQ(u"ࠬࡩࡩ࡮ࡣࡦࡰࡺࡨࡷࡰࡴ࡮ࠫઌ")			:NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"࠭ๅ้ไ฼ࠤุ๐ๅศࠢๆ่ํฮฺࠠ็็ࠫઍ")
	,KNomgGw1kdMCBH(u"ࠧࡤ࡫ࡰࡥࡨࡲࡵࡱࠩ઎")				:YnHG75e2QWwo(u"ࠨ็๋ๆ฾ࠦำ๋็สࠤ่๊่ษࠩએ")
	,LJPOQNK1mcG(u"ࠩࡦ࡭ࡲࡧࡦࡢࡰࡶࠫઐ")				:xN4fKmsnyM3Y2(u"้ࠪํู่ࠡีํ้ฬࠦแศ่ีࠫઑ")
	,HC9xWUMpBQJEuTteAqjd(u"ࠫࡨ࡯࡭ࡢࡨࡵࡩࡪ࠭઒")				:f8Ja1q5eO02B(u"๋่ࠬใ฻ࠣื๏๋วࠡใิ๎ࠬઓ")
	,ObuCsdoDtKmhPLSMH8YGan(u"࠭ࡣࡪ࡯ࡤࡰ࡮࡭ࡨࡵࠩઔ")			:HC9xWUMpBQJEuTteAqjd(u"ࠧๆ๊ๅ฽ู๊ࠥๆษ่ࠣฬ๐สࠨક")
	,J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠨࡥ࡬ࡱࡦࡴ࡯ࡸࠩખ")				:uxE8MyoTRglrcaiQf(u"่ࠩ์็฿ࠠิ์่หࠥ์ว้ࠩગ")
	,nfg30bHwd4aNV12SR7UjFck(u"ࠪࡧ࡮ࡳࡡࡸࡤࡤࡷࠬઘ")				:HC9xWUMpBQJEuTteAqjd(u"๊ࠫ๎โฺࠢึ๎๊อ้ࠠสึࠫઙ")
	,dwiIAcPl04ey7Zv38Mz(u"ࠬࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰࠪચ")			:TtyzcuW45VKA(u"࠭ๅ้ไ฼ࠤิอ๊ๅ์้ࠣํฺๆࠨછ")
	,AiCor1fIVTDxQUWwHe9vPR7(u"ࠧࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲ࠲ࡩࡨࡢࡰࡱࡩࡱࡹࠧજ")	:HC9xWUMpBQJEuTteAqjd(u"ࠨ็๋ๆ฾ࠦฯศ์็๎๋่ࠥีุ่้ࠣะฮะ็ํ๊ࠬઝ")
	,S5fhsRT8JV(u"ࠩࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴ࠭ࡩࡣࡶ࡬ࡹࡧࡧࡴࠩઞ")	:HC9xWUMpBQJEuTteAqjd(u"้ࠪํู่ࠡัส๎้๐ࠠๆ๊ื๊ࠥํวีฬส็ࠬટ")
	,AiCor1fIVTDxQUWwHe9vPR7(u"ࠫࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯࠯࡯࡭ࡻ࡫ࡳࠨઠ")	:J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"๋่ࠬใ฻ࠣำฬ๐ไ๋่ࠢ์ู์ࠠๆสสุึ࠭ડ")
	,tRnTydV03Xfi7rbQ(u"࠭ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱ࠱ࡵࡲࡡࡺ࡮࡬ࡷࡹࡹࠧઢ"):Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠧๆ๊ๅ฽ࠥีว๋ๆํࠤ๊๎ิ็ࠢๅ์ฬฬๅࠨણ")
	,AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"ࠨࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠳ࡴࡰࡲ࡬ࡧࡸ࠭ત")	:liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"่ࠩ์็฿ࠠะษํ่๏ࠦๅ้ึ้ࠤ๊๎วื์฼ࠫથ")
	,AiCor1fIVTDxQUWwHe9vPR7(u"ࠪࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮࠮ࡸ࡬ࡨࡪࡵࡳࠨદ")	:s8fcjBCSMxzAIkZQbJPga(u"๊ࠫ๎โฺࠢาห๏๊๊ࠡ็ุ๋๋ࠦแ๋ัํ์์อสࠨધ")
	,tRnTydV03Xfi7rbQ(u"ࠬࡪࡩࡴࡣࡥࡰࡪࡪࠧન")				:AiCor1fIVTDxQUWwHe9vPR7(u"࠭ๅห๊ๅๅࠬ઩")
	,dwiIAcPl04ey7Zv38Mz(u"ࠧࡥࡴࡤࡱࡦࡩࡡࡧࡧࠪપ")			:aar0zhDnJsOTP7EdgR16HIS29(u"ࠨ็๋ๆ฾ࠦฯาษ่ห้ࠥวโ์๊ࠫફ")
	,xN4fKmsnyM3Y2(u"ࠩࡧࡶࡦࡳࡡࡴ࠹ࠪબ")				:liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"้ࠪํู่ࠡัิห๊อࠠึฯࠪભ")
	,iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠫࡪ࡭ࡹࡣࡧࡶࡸࠬમ")				:S5fhsRT8JV(u"๋่ࠬใ฻ࠣห๏า๊ࠡสํืฯ࠭ય")
	,SGazRxP3yBKZ15ILuch(u"࠭ࡥࡨࡻࡥࡩࡸࡺ࠱ࠨર")				:aar0zhDnJsOTP7EdgR16HIS29(u"ࠧๆ๊ๅ฽ࠥอ๊อ์ࠣฬ๏ูสࠡ࠳ࠪ઱")
	,zDek1IW37rq6UoKdwyRiAVpF(u"ࠨࡧࡪࡽࡧ࡫ࡳࡵ࠴ࠪલ")				:YnHG75e2QWwo(u"่ࠩ์็฿ࠠศ์ฯ๎ࠥฮ๊ิฬࠣ࠶ࠬળ")
	,ObuCsdoDtKmhPLSMH8YGan(u"ࠪࡩ࡬ࡿࡢࡦࡵࡷ࠷ࠬ઴")				:NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"๊ࠫ๎โฺࠢส๎ั๐ࠠษ์ึฮࠥ࠹ࠧવ")
	,J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠬ࡫ࡧࡺࡤࡨࡷࡹ࠺ࠧશ")				:k5oIaYyp2mnrLK49qhzS(u"࠭ๅ้ไ฼ࠤฬ๐ฬ๋ࠢห๎ุะࠠ࠵ࠩષ")
	,tRnTydV03Xfi7rbQ(u"ࠧࡦࡩࡼࡦࡪࡹࡴࡷ࡫ࡳࠫસ")			:NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠨ็๋ๆ฾ࠦว๋ฮํࠤอ๐ำหࠢࡹ࡭ࡵ࠭હ")
	,s8fcjBCSMxzAIkZQbJPga(u"ࠩࡨ࡫ࡾࡪࡥࡢࡦࠪ઺")				:TtyzcuW45VKA(u"้ࠪํู่ࠡวํะ๏ࠦฯ๋ัࠪ઻")
	,J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠫࡪ࡭ࡹ࡯ࡱࡺ઼ࠫ")				:tRnTydV03Xfi7rbQ(u"๋่ࠬใ฻ࠣษ๏า๊่ࠡส์ࠬઽ")
	,aNdix5gq7yeFHTMWhnzm8pX0Y16(u"࠭ࡥ࡭ࡥ࡬ࡲࡪࡳࡡࠨા")				:zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"ࠧๆ๊ๅ฽๋่ࠥิ๊฼อࠥอไิ์้้ฬ࠭િ")
	,dwiIAcPl04ey7Zv38Mz(u"ࠨࡧ࡯࡭࡫ࡼࡩࡥࡧࡲࠫી")			:vbYokBuWlxeLDcdVNM60(u"่ࠩ์็฿ࠠฤๆํๅࠥ็๊ะ์๋ࠫુ")
	,LJPOQNK1mcG(u"ࠪࡪࡦࡨࡲࡢ࡭ࡤࠫૂ")				:zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"๊ࠫ๎โฺࠢไฬึ้ษࠨૃ")
	,zDek1IW37rq6UoKdwyRiAVpF(u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬૄ")				:liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"࠭แีๆࠪૅ")
	,HC9xWUMpBQJEuTteAqjd(u"ࠧࡧࡣ࡭ࡩࡷࡹࡨࡰࡹࠪ૆")			:k5oIaYyp2mnrLK49qhzS(u"ࠨ็๋ๆ฾ࠦแอำุࠣํ࠭ે")
	,vbYokBuWlxeLDcdVNM60(u"ࠩࡩࡥࡷ࡫ࡳ࡬ࡱࠪૈ")				:HC9xWUMpBQJEuTteAqjd(u"้ࠪํู่ࠡใสีุ้่ࠨૉ")
	,S5fhsRT8JV(u"ࠫ࡫ࡧࡳࡦ࡮࡫ࡨ࠶࠭૊")				:vbYokBuWlxeLDcdVNM60(u"๋่ࠬใ฻ࠣๅฬ฻ไࠡษ็วํ๊ࠧો")
	,nfg30bHwd4aNV12SR7UjFck(u"࠭ࡦࡢࡵࡨࡰ࡭ࡪ࠲ࠨૌ")				:liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠧๆ๊ๅ฽ࠥ็วึๆࠣห้ัว็์્ࠪ")
	,TtyzcuW45VKA(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ૎")				:S5fhsRT8JV(u"่ࠩะ้ีࠧ૏")
	,WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠪࡪࡴࡹࡴࡢࠩૐ")				:s8fcjBCSMxzAIkZQbJPga(u"๊ࠫ๎โฺࠢไ์ุะวࠨ૑")
	,nfg30bHwd4aNV12SR7UjFck(u"ࠬ࡬ࡵ࡯ࡱࡱࡸࡻ࠭૒")				:S5fhsRT8JV(u"࠭ๅ้ไ฼ࠤๆ์่็ࠢอ๎ๆ๐ࠧ૓")
	,iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠧࡧࡷࡶ࡬ࡦࡸࡴࡷࠩ૔")				:On1WZJc6dtksqVNgSQ5GBAjuipe(u"ࠨ็๋ๆ฾ࠦแ้ึสีࠥะ๊โ์ࠪ૕")
	,On1WZJc6dtksqVNgSQ5GBAjuipe(u"ࠩࡩࡹࡸ࡮ࡡࡳࡸ࡬ࡨࡪࡵࠧ૖")			:ObuCsdoDtKmhPLSMH8YGan(u"้ࠪํู่ࠡใุ๋ฬืࠠโ์า๎ํ࠭૗")
	,AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"ࠫ࡬ࡵ࡯ࡥࠩ૘")					:zDek1IW37rq6UoKdwyRiAVpF(u"ࠬา๊ะࠩ૙")
	,opyTNwHgfqbZREWKU(u"࠭ࡨࡢ࡮ࡤࡧ࡮ࡳࡡࠨ૚")				:f8Ja1q5eO02B(u"ࠧๆ๊ๅ฽ࠥํไศࠢึ๎๊อࠧ૛")
	,nfg30bHwd4aNV12SR7UjFck(u"ࠨࡪࡨࡰࡦࡲࠧ૜")				:dwiIAcPl04ey7Zv38Mz(u"่ࠩ์็฿่ࠠๆส่ࠥ๐่ห์๋ฬࠬ૝")
	,f8Ja1q5eO02B(u"ࠪ࡭࡫࡯࡬࡮ࠩ૞")				:uxE8MyoTRglrcaiQf(u"๊ࠫ๎โฺࠢๅ๊ฬฯࠠร์ࠣๅ๏๊ๅࠨ૟")
	,WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠬ࡯ࡦࡪ࡮ࡰ࠱ࡦࡸࡡࡣ࡫ࡦࠫૠ")			:uxE8MyoTRglrcaiQf(u"࠭ๅ้ไ฼ࠤ็์วสࠢล๎ࠥ็๊ๅ็ࠣ฽ึฮ๊ࠨૡ")
	,AiCor1fIVTDxQUWwHe9vPR7(u"ࠧࡪࡨ࡬ࡰࡲ࠳ࡥ࡯ࡩ࡯࡭ࡸ࡮ࠧૢ")		:iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠨ็๋ๆ฾ࠦโ็ษฬࠤว๐ࠠโ์็้ࠥอๆอๆํึ๏࠭ૣ")
	,J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠩ࡬ࡴࡹࡼࠧ૤")					:KNomgGw1kdMCBH(u"ࠪࡍࡕ࡚ࡖࠨ૥")
	,zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"ࠫ࡮ࡶࡴࡷ࠯࡯࡭ࡻ࡫ࠧ૦")			:WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠬࡏࡐࡕࡘࠣๆ๋๎วหࠩ૧")
	,YnHG75e2QWwo(u"࠭ࡩࡱࡶࡹ࠱ࡲࡵࡶࡪࡧࡶࠫ૨")			:k5oIaYyp2mnrLK49qhzS(u"ࠧࡊࡒࡗ࡚ࠥษแๅษ่ࠫ૩")
	,zDek1IW37rq6UoKdwyRiAVpF(u"ࠨ࡫ࡳࡸࡻ࠳ࡳࡦࡴ࡬ࡩࡸ࠭૪")			:opyTNwHgfqbZREWKU(u"ࠩࡌࡔ࡙࡜ࠠๆี็ื้อสࠨ૫")
	,opyTNwHgfqbZREWKU(u"ࠪ࡯ࡦࡸࡢࡢ࡮ࡤࡸࡻ࠭૬")			:SGazRxP3yBKZ15ILuch(u"๊ࠫ๎โฺࠢๅ๊ฬฯࠠไำห่ฬวࠧ૭")
	,KNomgGw1kdMCBH(u"ࠬࡱࡡࡵ࡭ࡲࡸࡹࡼࠧ૮")				:dwiIAcPl04ey7Zv38Mz(u"࠭ๅ้ไ฼ࠤ่ะใ้ฬࠣฮ๏็๊ࠨ૯")
	,NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠧ࡬ࡣࡷ࡯ࡴࡻࡴࡦࠩ૰")				:nfg30bHwd4aNV12SR7UjFck(u"ࠨ็๋ๆ฾ࠦใหๅ๋ฮࠬ૱")
	,LungQF89BqemOb32jJsZlW(u"ࠩ࡮࡭ࡷࡳࡡ࡭࡭ࠪ૲")				:NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"้ࠪํู่ࠡๅิ้ฬ๊ใࠨ૳")
	,AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"ࠫࡱࡧࡲࡰࡼࡤࠫ૴")				:TtyzcuW45VKA(u"๋่ࠬใ฻่ࠣฬื่ำษࠪ૵")
	,On1WZJc6dtksqVNgSQ5GBAjuipe(u"࠭࡬ࡪࡤࡵࡥࡷࡿࠧ૶")				:dwiIAcPl04ey7Zv38Mz(u"ࠧๆๆไࠫ૷")
	,LungQF89BqemOb32jJsZlW(u"ࠨ࡮࡬ࡺࡪ࠭૸")					:NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠩๅ๊ฬฯࠧૹ")
	,Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠪࡰ࡮ࡼࡥࡵࡸࠪૺ")				:f8Ja1q5eO02B(u"๊๊ࠫแࠨૻ")
	,S5fhsRT8JV(u"ࠬࡲ࡯ࡥࡻࡱࡩࡹ࠭ૼ")				:iRfoNckJs7Ibxzh5j92w8DSWF(u"࠭ๅ้ไ฼ࠤ้๎ฯ๋้ࠢฮࠬ૽")
	,f8Ja1q5eO02B(u"ࠧ࡮࠵ࡸࠫ૾")					:opyTNwHgfqbZREWKU(u"ࠨࡏ࠶࡙ࠬ૿")
	,SGazRxP3yBKZ15ILuch(u"ࠩࡰ࠷ࡺ࠳࡬ࡪࡸࡨࠫ଀")				:k5oIaYyp2mnrLK49qhzS(u"ࠪࡑ࠸࡛ࠠใ่๋หฯ࠭ଁ")
	,tRnTydV03Xfi7rbQ(u"ࠫࡲ࠹ࡵ࠮࡯ࡲࡺ࡮࡫ࡳࠨଂ")			:TtyzcuW45VKA(u"ࠬࡓ࠳ࡖࠢฦๅ้อๅࠨଃ")
	,aNdix5gq7yeFHTMWhnzm8pX0Y16(u"࠭࡭࠴ࡷ࠰ࡷࡪࡸࡩࡦࡵࠪ଄")			:uxE8MyoTRglrcaiQf(u"ࠧࡎ࠵ࡘࠤู๊ไิๆสฮࠬଅ")
	,WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠨ࡯ࡤࡷࡦࡼࡩࡥࡧࡲࠫଆ")			:AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"่ࠩ์็฿ࠠๆษึหࠥ็๊ะ์๋ࠫଇ")
	,AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"ࠪࡱ࡮ࡹࡳࡪࡰࡪࠫଈ")				:TtyzcuW45VKA(u"๊ࠫ็โ้ัࠪଉ")
	,zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"ࠬࡳ࡯ࡷࡵ࠷ࡹࠬଊ")				:ObuCsdoDtKmhPLSMH8YGan(u"࠭ๅ้ไ฼ࠤ๊๎แำࠢไ์ึ๐่ࠨଋ")
	,J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠧ࡮ࡻࡦ࡭ࡲࡧࠧଌ")				:On1WZJc6dtksqVNgSQ5GBAjuipe(u"ࠨ็๋ๆ฾ࠦๅศ์ࠣื๏๋วࠨ଍")
	,ObuCsdoDtKmhPLSMH8YGan(u"ࠩࡲࡰࡩ࠭଎")					:Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠪๆิ๐ๅࠨଏ")
	,k5oIaYyp2mnrLK49qhzS(u"ࠫࡵࡧ࡮ࡦࡶࠪଐ")				:uxE8MyoTRglrcaiQf(u"๋่ࠬใ฻ࠣฬฬ์๊หࠩ଑")
	,ObuCsdoDtKmhPLSMH8YGan(u"࠭ࡰࡢࡰࡨࡸ࠲ࡳ࡯ࡷ࡫ࡨࡷࠬ଒")			:k5oIaYyp2mnrLK49qhzS(u"ࠧๆ๊ๅ฽ࠥฮว็์อࠤฬ็ไศ็ࠪଓ")
	,TtyzcuW45VKA(u"ࠨࡲࡤࡲࡪࡺ࠭ࡴࡧࡵ࡭ࡪࡹࠧଔ")			:rbUkdYi32PJaRtnxhDvQs(u"่ࠩ์็฿ࠠษษ้๎ฯࠦๅิๆึ่ฬะࠧକ")
	,J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠪࡵ࡫࡯࡬࡮ࠩଖ")				:SGazRxP3yBKZ15ILuch(u"๊ࠫ๎โฺࠢๆ๎ํࠦแ๋ๆ่ࠫଗ")
	,ObuCsdoDtKmhPLSMH8YGan(u"ࠬࡹࡥࡳ࡫ࡨࡷࡹ࡯࡭ࡦࠩଘ")			:NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"࠭ๅ้ไ฼ࠤุ๐ั๋ีࠣฮฬ๐ๅࠨଙ")
	,rbUkdYi32PJaRtnxhDvQs(u"ࠧࡴࡪࡤࡦࡦࡱࡡࡵࡻࠪଚ")			:WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠨ็๋ๆ฾ࠦิษๅอ๎ࠬଛ")
	,aar0zhDnJsOTP7EdgR16HIS29(u"ࠩࡶ࡬ࡦ࡮ࡩࡥ࠶ࡸࠫଜ")				:On1WZJc6dtksqVNgSQ5GBAjuipe(u"้ࠪํู่ࠡึส๋ิࠦแ้ำํ์ࠬଝ")
	,NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠫࡸ࡮ࡡࡩ࡫ࡧ࠸ࡺ࠸ࠧଞ")			:zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"๋่ࠬใ฻ุࠣฬํฯࠡใ๋ี๏๎ࠠ࠳ࠩଟ")
	,opyTNwHgfqbZREWKU(u"࠭ࡳࡩࡣ࡫࡭ࡩࡴࡥࡸࡵࠪଠ")			:liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠧๆ๊ๅ฽ฺࠥว่ั๊ࠣ๏๎าࠨଡ")
	,zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"ࠨࡵ࡫࡭ࡦࡼ࡯ࡪࡥࡨࠫଢ")			:AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"่ࠩ์็฿ࠠึ๊อࠤฬ๊ิ๋฻ฬࠫଣ")
	,KNomgGw1kdMCBH(u"ࠪࡷ࡭࡯ࡡࡷࡱ࡬ࡧࡪ࠳ࡡ࡭ࡤࡸࡱࡸ࠭ତ")		:zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"๊ࠫ๎โฺุࠢ์ฯࠦวๅึํ฽ฮࠦวๅส๋้ࠬଥ")
	,NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠬࡹࡨࡪࡣࡹࡳ࡮ࡩࡥ࠮ࡣࡸࡨ࡮ࡵࡳࠨଦ")		:vbYokBuWlxeLDcdVNM60(u"࠭ๅ้ไ฼ࠤฺ๎สࠡษ็ุ๏฿ษࠡื๋ฮ๏อสࠨଧ")
	,aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠧࡴࡪ࡬ࡥࡻࡵࡩࡤࡧ࠰ࡴࡪࡸࡳࡰࡰࡶࠫନ")	:aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠨ็๋ๆ฾ࠦี้ฬࠣหฺฺ้๊หࠣๆฬืฦࠨ଩")
	,KNomgGw1kdMCBH(u"ࠩࡶ࡬ࡴ࡬ࡨࡢࠩପ")				:tRnTydV03Xfi7rbQ(u"้ࠪํู่ࠡึ๋ๅ์อࠠห์ไ๎ࠬଫ")
	,liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠫࡸ࡮࡯ࡰࡨࡰࡥࡽ࠭ବ")				:WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"๋่ࠬใ฻ุࠣํ็ࠠๆษๆืࠬଭ")
	,tRnTydV03Xfi7rbQ(u"࠭ࡳࡩࡱࡲࡪࡳ࡫ࡴࠨମ")				:J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠧๆ๊ๅ฽ฺ่ࠥโ้ࠢฮࠬଯ")
	,LungQF89BqemOb32jJsZlW(u"ࠨࡵ࡫ࡳࡴ࡬ࡰࡳࡱࠪର")				:On1WZJc6dtksqVNgSQ5GBAjuipe(u"่ࠩ์็฿ࠠี๊ไࠤอื่ࠨ଱")
	,f8Ja1q5eO02B(u"ࠪࡸ࡮ࡱࡡࡢࡶࠪଲ")				:k5oIaYyp2mnrLK49qhzS(u"๊ࠫ๎โฺࠢอ็ฬะࠧଳ")
	,AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"ࠬࡺࡶࡧࡷࡱࠫ଴")				:Rsdai9xIEPcpuBMKOUwkTA05q(u"࠭ๅ้ไ฼ࠤฯ๐แ๋ࠢไห๋࠭ଵ")
	,zDek1IW37rq6UoKdwyRiAVpF(u"ࠧࡷࡣࡵࡦࡴࡴࠧଶ")				:opyTNwHgfqbZREWKU(u"ࠨ็๋ๆ฾ࠦแศำห์๋࠭ଷ")
	,TtyzcuW45VKA(u"ࠩࡹ࡭ࡩ࡫࡯ࠨସ")				:zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"ࠪๅ๏ี๊้ࠩହ")
	,S5fhsRT8JV(u"ࠫࡻ࡯ࡤࡦࡱࡱࡷࡦ࡫࡭ࠨ଺")			:NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"๋่ࠬใ฻ࠣๅ๏ี๊้้ࠢืฬฬๅࠨ଻")
	,zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"࠭ࡷࡦࡥ࡬ࡱࡦ࠷଼ࠧ")				:On1WZJc6dtksqVNgSQ5GBAjuipe(u"ࠧๆ๊ๅ฽ࠥ๎๊ࠡีํ้ฬࠦ࠱ࠨଽ")
	,dwiIAcPl04ey7Zv38Mz(u"ࠨࡹࡨࡧ࡮ࡳࡡ࠳ࠩା")				:AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"่ࠩ์็฿้ࠠ์ࠣื๏๋วࠡ࠴ࠪି")
	,xN4fKmsnyM3Y2(u"ࠪࡽࡦࡷ࡯ࡵࠩୀ")				:aNdix5gq7yeFHTMWhnzm8pX0Y16(u"๊ࠫ๎โฺࠢํห็๎สࠨୁ")
	,Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠬࡿ࡯ࡶࡶࡸࡦࡪ࠭ୂ")				:HC9xWUMpBQJEuTteAqjd(u"࠭ๅ้ไ฼ࠤ๏๎ส๋๊หࠫୃ")
	,uxE8MyoTRglrcaiQf(u"ࠧࡺࡱࡸࡸࡺࡨࡥ࠮ࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠪୄ")		:NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠨ็๋ๆ฾๊้ࠦฬํ์อࠦโ็๊สฮࠬ୅")
	,LungQF89BqemOb32jJsZlW(u"ࠩࡼࡳࡺࡺࡵࡣࡧ࠰ࡴࡱࡧࡹ࡭࡫ࡶࡸࡸ࠭୆")	:zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"้ࠪํู่ࠡ์๋ฮ๏๎ศࠡไ๋หห๋ࠧେ")
	,AiCor1fIVTDxQUWwHe9vPR7(u"ࠫࡾࡵࡵࡵࡷࡥࡩ࠲ࡼࡩࡥࡧࡲࡷࠬୈ")		:k5oIaYyp2mnrLK49qhzS(u"๋่ࠬใ฻ࠣ๎ํะ๊้สࠣๅ๏ี๊้้สฮࠬ୉")
	,NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"࠭ࡹࡵࡤࡢࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬ୊")			:nfg30bHwd4aNV12SR7UjFck(u"ࠧๆ๊สๆ฾ࠦๅ็ࠢํ์ฯ๐่ษࠩୋ")
}
# -*- coding: utf-8 -*-
from RgJNGc7YMP import *
UkXlAzsMcamKJrEIgnxi6bWh = 'AKWAMTUBE'
nc3GLkA65oxOd = '_AKT_'
cDTdfqVAF0BLGiX364IEwaZbr = USuRxnPlV5.SITESURLS[UkXlAzsMcamKJrEIgnxi6bWh][0]
cJWUPuDGM0Yybv5a9KnIrVzhH78 = ['الرئيسية','يلا شوت','افلام بحسب النوع']
def HHN5EpbszV3iA2m89hGSQjaPgUZy(mode,url,text):
	if   mode==850: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = kUq58vC7x9hWma164JejMKQ()
	elif mode==851: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = GDQUH4fN02sIt81mAcY(url,text)
	elif mode==852: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = RPZbqous7rtdy56LeI18Cv04AKHW(url)
	elif mode==853: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = UA1q3m0veRxyn8(url)
	elif mode==859: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = z4hetAJw3NaT9ROjG6xbZ5CHlW81(text)
	else: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = False
	return xsGUcR3ef6glKY5hQwpFXEaSt2mrIz
def kUq58vC7x9hWma164JejMKQ():
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',cDTdfqVAF0BLGiX364IEwaZbr,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'AKWAMTUBE-MENU-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'بحث في الموقع',cdZKMn68Pzg4,859,cdZKMn68Pzg4,cdZKMn68Pzg4,'_REMEMBERRESULTS_')
	zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"primary-links"(.*?)</u',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?<span>(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,title in items:
			if title in cJWUPuDGM0Yybv5a9KnIrVzhH78: continue
			zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+title,c0cDhidBlOn7,851)
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"list-categories"(.*?)</u',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?>(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,title in items:
			if 'http' not in c0cDhidBlOn7: c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr+KCQExdbYFqM+c0cDhidBlOn7.lstrip(KCQExdbYFqM)
			if title in cJWUPuDGM0Yybv5a9KnIrVzhH78: continue
			zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+title,c0cDhidBlOn7,851)
	return
def GDQUH4fN02sIt81mAcY(url,type=cdZKMn68Pzg4):
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'AKWAMTUBE-TITLES-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"home-content"(.*?)"footer"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		KdWauEhgN6OQzjRVm1ro8tkB3 = KdWauEhgN6OQzjRVm1ro8tkB3.replace('"overlay"','"duration"><')
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"thumb".*?data-src="(.*?)".*?"duration">(.*?)<.*?href="(.*?)">(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		KRmzvoWYyxfXw37SEh1Q = []
		for y90BoFz8MA1ZThaSC2ILXHiK3OY6w,Kr1n9xq5TY4gohlVdNEu0b,c0cDhidBlOn7,title in items:
			title = title.strip(' ')
			title = gbd90SjF2mZqf81IRDaTwJkWu(title)
			E0w56WHxZPYGVvnTQ4O2t1C8DAjq = ffUFBJQ57j2XgoGeOLn9uwpC.findall('(.*?) (الحلقة|حلقة).\d+',title,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			if 0 and 'episodes' not in ppWtKTjVzdQwmoqNi7E and E0w56WHxZPYGVvnTQ4O2t1C8DAjq:
				title = '_MOD_' + E0w56WHxZPYGVvnTQ4O2t1C8DAjq[0][0]
				title = title.replace('اون لاين',cdZKMn68Pzg4)
				if title not in KRmzvoWYyxfXw37SEh1Q:
					zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,853,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
					KRmzvoWYyxfXw37SEh1Q.append(title)
			else: zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,852,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,Kr1n9xq5TY4gohlVdNEu0b)
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('''["']pagination["'](.*?)["']footer["']''',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		type = 'episodes_pages' if 'episodes' in type else 'pages'
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)">(.*?)</a>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,title in items:
			title = gbd90SjF2mZqf81IRDaTwJkWu(title)
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'صفحة '+title,c0cDhidBlOn7,851,cdZKMn68Pzg4,cdZKMn68Pzg4,type)
	return
def UA1q3m0veRxyn8(url):
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'AKWAMTUBE-SERIES-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="eplist"(.*?)</div>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		PCktNV4H3DEOSpeh = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="([^"]*)" title="([^"]*)"',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,title in PCktNV4H3DEOSpeh:
			zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,872)
	else:
		c0cDhidBlOn7 = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"category".*?href="(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if c0cDhidBlOn7:
			c0cDhidBlOn7 = YQlEOShHM7RLak2t0yA4NXqv(c0cDhidBlOn7[0])
			GDQUH4fN02sIt81mAcY(c0cDhidBlOn7,'episodes')
	return
def RPZbqous7rtdy56LeI18Cv04AKHW(url):
	XFj0lV5yMtS67EwbCJ9oO = []
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'AKWAMTUBE-PLAY-2nd')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	if 'hash=' in OO1cj2REUZHJ8x5V:
		v69TYeXdDAoI4lk5EzsptMmFqR8Gy = ffUFBJQ57j2XgoGeOLn9uwpC.findall('hash=(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		v69TYeXdDAoI4lk5EzsptMmFqR8Gy = list(set(v69TYeXdDAoI4lk5EzsptMmFqR8Gy))
		for PTsY9XSpQFhGuxtvJk74oV3fwdWeaE in v69TYeXdDAoI4lk5EzsptMmFqR8Gy:
			b6tXejPoTv = []
			FxVBtGij82cmkq = PTsY9XSpQFhGuxtvJk74oV3fwdWeaE.split('__')
			for xxWP1ywRGXHO87YIkToesbCU09v in FxVBtGij82cmkq:
				try:
					xxWP1ywRGXHO87YIkToesbCU09v = abn2REWAS3FwTN0rlQmgOk.b64decode(xxWP1ywRGXHO87YIkToesbCU09v+'=')
					if W5domCu6XrQUFkiPpa3bNLtHglG: xxWP1ywRGXHO87YIkToesbCU09v = xxWP1ywRGXHO87YIkToesbCU09v.decode(vczMIlkCAh2u10B3)
					b6tXejPoTv.append(xxWP1ywRGXHO87YIkToesbCU09v)
				except: pass
			zz4ZPovUbyk5GEhNMs8JDnaVXftS = '>'.join(b6tXejPoTv)
			zz4ZPovUbyk5GEhNMs8JDnaVXftS = zz4ZPovUbyk5GEhNMs8JDnaVXftS.splitlines()
			for c0cDhidBlOn7 in zz4ZPovUbyk5GEhNMs8JDnaVXftS:
				if ' => ' in c0cDhidBlOn7:
					title,c0cDhidBlOn7 = c0cDhidBlOn7.split(' => ')
					c0cDhidBlOn7 = c0cDhidBlOn7+'?named='+title+'__watch'
					XFj0lV5yMtS67EwbCJ9oO.append(c0cDhidBlOn7)
	elif 'post_id' in OO1cj2REUZHJ8x5V:
		eaZTIfi39lq7WXOEYvS10VyJUGpnKc = ffUFBJQ57j2XgoGeOLn9uwpC.findall("post_id = '(.*?)'",OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if eaZTIfi39lq7WXOEYvS10VyJUGpnKc:
			eaZTIfi39lq7WXOEYvS10VyJUGpnKc = eaZTIfi39lq7WXOEYvS10VyJUGpnKc[0]
			headers = {'Referer':url}
			c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr+'/wp-admin/admin-ajax.php?action=video_info&post_id='+eaZTIfi39lq7WXOEYvS10VyJUGpnKc
			Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',c0cDhidBlOn7,cdZKMn68Pzg4,headers,cdZKMn68Pzg4,cdZKMn68Pzg4,'ALMSTBA-PLAY-2nd')
			OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
			zz4ZPovUbyk5GEhNMs8JDnaVXftS = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"name":"(.*?)","src":"(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			if not zz4ZPovUbyk5GEhNMs8JDnaVXftS: zz4ZPovUbyk5GEhNMs8JDnaVXftS = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"(src)":"(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			for name,c0cDhidBlOn7 in zz4ZPovUbyk5GEhNMs8JDnaVXftS:
				c0cDhidBlOn7 = c0cDhidBlOn7.replace('\\/',KCQExdbYFqM)
				c0cDhidBlOn7 = YQlEOShHM7RLak2t0yA4NXqv(c0cDhidBlOn7)
				if name=='src': name = ''
				XFj0lV5yMtS67EwbCJ9oO.append(c0cDhidBlOn7+'?named='+name+'__watch')
	import r0y4XTKznF
	r0y4XTKznF.noHliPXkcg3pJTdSauCvm5sU(XFj0lV5yMtS67EwbCJ9oO,UkXlAzsMcamKJrEIgnxi6bWh,'video',url)
	return
def z4hetAJw3NaT9ROjG6xbZ5CHlW81(search):
	search,EL8zUgbXheot,showDialogs = qbIcHCMdkFKn21e(search)
	if search==cdZKMn68Pzg4: search = BzkmLuvJD9n25Pg()
	if search==cdZKMn68Pzg4: return
	search = search.replace(VBpIH2QSmvDGlA6TO3e,'+')
	url = cDTdfqVAF0BLGiX364IEwaZbr+'/?s='+search
	GDQUH4fN02sIt81mAcY(url,'search')
	return
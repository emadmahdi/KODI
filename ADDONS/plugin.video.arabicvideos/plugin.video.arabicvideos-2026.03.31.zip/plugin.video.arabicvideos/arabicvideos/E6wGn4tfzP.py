# -*- coding: utf-8 -*-
from RgJNGc7YMP import *
UkXlAzsMcamKJrEIgnxi6bWh = 'CIMACLUP'
nc3GLkA65oxOd = '_CMC_'
cDTdfqVAF0BLGiX364IEwaZbr = USuRxnPlV5.SITESURLS[UkXlAzsMcamKJrEIgnxi6bWh][0]
cJWUPuDGM0Yybv5a9KnIrVzhH78 = ['موقع نتفليكس']
def HHN5EpbszV3iA2m89hGSQjaPgUZy(mode,url,text):
	if   mode==490: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = kUq58vC7x9hWma164JejMKQ()
	elif mode==491: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = GDQUH4fN02sIt81mAcY(url,text)
	elif mode==492: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = RPZbqous7rtdy56LeI18Cv04AKHW(url)
	elif mode==493: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = yIZWSuMpvs3(url)
	elif mode==494: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = oQF2hgjusp8Ne(url)
	elif mode==499: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = z4hetAJw3NaT9ROjG6xbZ5CHlW81(text,url)
	else: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = False
	return xsGUcR3ef6glKY5hQwpFXEaSt2mrIz
def kUq58vC7x9hWma164JejMKQ():
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',cDTdfqVAF0BLGiX364IEwaZbr,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'CIMACLUP-MENU-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	u1P73L0UmkA4eaIBbCgZfrvRtJ = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	u1P73L0UmkA4eaIBbCgZfrvRtJ = u1P73L0UmkA4eaIBbCgZfrvRtJ[0].strip(KCQExdbYFqM)
	u1P73L0UmkA4eaIBbCgZfrvRtJ = CxlbPZwGTcH87e1sWhfSIz29uRUEpV(u1P73L0UmkA4eaIBbCgZfrvRtJ,'url')
	ll9vYSyie5kwbR16U0a2K = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"filter AjaxifyFilter"(.*?)</div>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ll9vYSyie5kwbR16U0a2K:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ll9vYSyie5kwbR16U0a2K[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('data-filter="(.*?)".*?>(.*?)</a>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,title in items:
			if title in cJWUPuDGM0Yybv5a9KnIrVzhH78: continue
			c0cDhidBlOn7 = u1P73L0UmkA4eaIBbCgZfrvRtJ+'/wp-content/themes/old/filter/'+c0cDhidBlOn7+'.php'
			zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+title,c0cDhidBlOn7,491)
	zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+'أفلام',u1P73L0UmkA4eaIBbCgZfrvRtJ+'/category/افلام-movies-filme/foreign-hd-افلام-اجنبى-2',494,cdZKMn68Pzg4,cdZKMn68Pzg4,'_REMEMBERRESULTS_')
	zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+'مسلسلات',u1P73L0UmkA4eaIBbCgZfrvRtJ+'/category/مسلسلات/مسلسلات-اجنبى',494,cdZKMn68Pzg4,cdZKMn68Pzg4,'_REMEMBERRESULTS_')
	zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="navigation-menu"(.*?)</ul>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
	items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?>(.*?)</a>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	for c0cDhidBlOn7,title in items:
		if c0cDhidBlOn7==KCQExdbYFqM: continue
		if 'http' not in c0cDhidBlOn7: c0cDhidBlOn7 = u1P73L0UmkA4eaIBbCgZfrvRtJ+c0cDhidBlOn7
		if title in cJWUPuDGM0Yybv5a9KnIrVzhH78: continue
		zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+title,c0cDhidBlOn7,491)
	return OO1cj2REUZHJ8x5V
def oQF2hgjusp8Ne(url):
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'CIMACLUP-SUBMENU-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	ptXc2zV0RhTb = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"filter"(.*?)</div>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ptXc2zV0RhTb:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ptXc2zV0RhTb[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?>(.*?)</a>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,title in items:
			if title in cJWUPuDGM0Yybv5a9KnIrVzhH78: continue
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,491)
	return
def GDQUH4fN02sIt81mAcY(url,w3wLtqKIc0=cdZKMn68Pzg4):
	items = []
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'CIMACLUP-TITLES-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	KdWauEhgN6OQzjRVm1ro8tkB3 = cdZKMn68Pzg4
	if '.php' in url: KdWauEhgN6OQzjRVm1ro8tkB3 = OO1cj2REUZHJ8x5V
	elif '?s=' in url:
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"blocks(.*?)"manifest"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if ppvsMqCHf8SEzxQg:
			KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
			items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?src="(.*?)".*?alt="(.*?)"',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	else:
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"Blocks(.*?)"manifest"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if ppvsMqCHf8SEzxQg:
			KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
	if not KdWauEhgN6OQzjRVm1ro8tkB3: return
	KRmzvoWYyxfXw37SEh1Q = []
	rgWUvoaJnZARc375bjQ = ['مشاهدة','فيلم','اغنية','أغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for c0cDhidBlOn7,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,title in items:
		title = gbd90SjF2mZqf81IRDaTwJkWu(title)
		E0w56WHxZPYGVvnTQ4O2t1C8DAjq = ffUFBJQ57j2XgoGeOLn9uwpC.findall('(.*?) حلقة \d+',title,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if not E0w56WHxZPYGVvnTQ4O2t1C8DAjq: E0w56WHxZPYGVvnTQ4O2t1C8DAjq = ffUFBJQ57j2XgoGeOLn9uwpC.findall('(.*?) الحلقة \d+',title,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if not E0w56WHxZPYGVvnTQ4O2t1C8DAjq or any(value in title for value in rgWUvoaJnZARc375bjQ):
			zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,492,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
		elif E0w56WHxZPYGVvnTQ4O2t1C8DAjq and 'حلقة' in title:
			title = '_MOD_' + E0w56WHxZPYGVvnTQ4O2t1C8DAjq[0]
			if title not in KRmzvoWYyxfXw37SEh1Q:
				zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,493,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
				KRmzvoWYyxfXw37SEh1Q.append(title)
		else: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,493,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"pagination"(.*?)</ul>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('<li><a href="(.*?)".*?>(.*?)</a>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,title in items:
			title = gbd90SjF2mZqf81IRDaTwJkWu(title)
			title = title.replace('الصفحة ',cdZKMn68Pzg4)
			if title!=cdZKMn68Pzg4: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'صفحة '+title,c0cDhidBlOn7,491)
	return
def yIZWSuMpvs3(url):
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'CIMACLUP-EPISODES-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	HOCWKhxITtulVGX = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"ButtonsBarCo".*?href="(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if HOCWKhxITtulVGX:
		HOCWKhxITtulVGX = HOCWKhxITtulVGX[0]
		Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',HOCWKhxITtulVGX,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'CIMACLUP-EPISODES-2nd')
		OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	y90BoFz8MA1ZThaSC2ILXHiK3OY6w = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"img-responsive" src="(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if y90BoFz8MA1ZThaSC2ILXHiK3OY6w: y90BoFz8MA1ZThaSC2ILXHiK3OY6w = y90BoFz8MA1ZThaSC2ILXHiK3OY6w[0]
	else: y90BoFz8MA1ZThaSC2ILXHiK3OY6w = bu6LzUQF7K.getInfoLabel('ListItem.Thumb')
	ptXc2zV0RhTb = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"filter"(.*?)</div>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	ll9vYSyie5kwbR16U0a2K = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"Blocks(.*?)class="pagination"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ptXc2zV0RhTb and '/series/' not in url:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ptXc2zV0RhTb[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?>(.*?)</a>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,title in items:
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,493,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
	elif ll9vYSyie5kwbR16U0a2K:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ll9vYSyie5kwbR16U0a2K[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?image\:url\((.*?)\).*?"boxtitle">(.*?)</div>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if items:
			for c0cDhidBlOn7,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,title in items:
				title = title.strip(VBpIH2QSmvDGlA6TO3e)
				zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,492,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"pagination"(.*?)</div>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if ppvsMqCHf8SEzxQg:
			KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
			items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?>(.*?)</a>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			for c0cDhidBlOn7,title in items:
				title = gbd90SjF2mZqf81IRDaTwJkWu(title)
				title = title.replace('الصفحة ',cdZKMn68Pzg4)
				if title!=cdZKMn68Pzg4: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'صفحة '+title,c0cDhidBlOn7,491)
	return
def RPZbqous7rtdy56LeI18Cv04AKHW(url):
	HOCWKhxITtulVGX = url.strip(KCQExdbYFqM)+'/?view=1'
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',HOCWKhxITtulVGX,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'CIMACLUP-PLAY-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	pcX7zxFRmsADwUr = []
	u1P73L0UmkA4eaIBbCgZfrvRtJ = CxlbPZwGTcH87e1sWhfSIz29uRUEpV(url,'url')
	w6ImbV0vxLgs9NoMXJ42cO8alAd = ffUFBJQ57j2XgoGeOLn9uwpC.findall("data: 'q=(.*?)&",OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	w6ImbV0vxLgs9NoMXJ42cO8alAd = w6ImbV0vxLgs9NoMXJ42cO8alAd[0]
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"serversList"(.*?)</ul>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('data-server="(.*?)">(.*?)</li>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for zTWvBbKS9Q1LFO7tUu4Jo3E6,title in items:
			title = title.strip(VBpIH2QSmvDGlA6TO3e)
			c0cDhidBlOn7 = u1P73L0UmkA4eaIBbCgZfrvRtJ+'/wp-content/themes/old/servers/server.php?q='+w6ImbV0vxLgs9NoMXJ42cO8alAd+'&i='+zTWvBbKS9Q1LFO7tUu4Jo3E6+'?named='+title+'__watch'
			pcX7zxFRmsADwUr.append(c0cDhidBlOn7)
	c0cDhidBlOn7 = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"embedServer".*?SRC="(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if c0cDhidBlOn7:
		title = 'مفضل'
		c0cDhidBlOn7 = c0cDhidBlOn7[0]+'?named=__embed__'+title
		pcX7zxFRmsADwUr.append(c0cDhidBlOn7)
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"downloadsList"(.*?)</div>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('<td>(.*?)</td>.*?href="(.*?)"',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for title,c0cDhidBlOn7 in items:
			title = title.strip(VBpIH2QSmvDGlA6TO3e)
			if 'anavidz' in c0cDhidBlOn7: UHXfFEWmlxMAnzju4 = '__خاص'
			else: UHXfFEWmlxMAnzju4 = cdZKMn68Pzg4
			c0cDhidBlOn7 = c0cDhidBlOn7+'?named='+title+'__download'+UHXfFEWmlxMAnzju4
			pcX7zxFRmsADwUr.append(c0cDhidBlOn7)
	import r0y4XTKznF
	r0y4XTKznF.noHliPXkcg3pJTdSauCvm5sU(pcX7zxFRmsADwUr,UkXlAzsMcamKJrEIgnxi6bWh,'video',url)
	return
def z4hetAJw3NaT9ROjG6xbZ5CHlW81(search,u1P73L0UmkA4eaIBbCgZfrvRtJ=cdZKMn68Pzg4):
	if not u1P73L0UmkA4eaIBbCgZfrvRtJ: u1P73L0UmkA4eaIBbCgZfrvRtJ = cDTdfqVAF0BLGiX364IEwaZbr
	search,EL8zUgbXheot,showDialogs = qbIcHCMdkFKn21e(search)
	if not search:
		search = BzkmLuvJD9n25Pg()
		if not search: return
	search = search.replace(VBpIH2QSmvDGlA6TO3e,'+')
	url = u1P73L0UmkA4eaIBbCgZfrvRtJ+'/index.php?s='+search
	GDQUH4fN02sIt81mAcY(url)
	return
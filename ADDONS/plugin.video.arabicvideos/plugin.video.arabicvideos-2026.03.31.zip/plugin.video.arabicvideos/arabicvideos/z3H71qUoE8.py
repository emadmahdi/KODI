# -*- coding: utf-8 -*-
from RgJNGc7YMP import *
UkXlAzsMcamKJrEIgnxi6bWh = 'ALKAWTHAR'
nc3GLkA65oxOd = '_KWT_'
cDTdfqVAF0BLGiX364IEwaZbr = USuRxnPlV5.SITESURLS[UkXlAzsMcamKJrEIgnxi6bWh][0]
def HHN5EpbszV3iA2m89hGSQjaPgUZy(mode,url,aOZ3yVnsNlB974pR,text):
	if   mode==130: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = kUq58vC7x9hWma164JejMKQ()
	elif mode==131: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = GDQUH4fN02sIt81mAcY(url)
	elif mode==132: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = WH7waGAlyphZe3(url)
	elif mode==133: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = yIZWSuMpvs3(url,aOZ3yVnsNlB974pR)
	elif mode==134: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = RPZbqous7rtdy56LeI18Cv04AKHW(url)
	elif mode==135: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = CGOjMRlNnBafrtz()
	elif mode==139: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = z4hetAJw3NaT9ROjG6xbZ5CHlW81(text,url)
	else: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = False
	return xsGUcR3ef6glKY5hQwpFXEaSt2mrIz
def kUq58vC7x9hWma164JejMKQ():
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'بحث في الموقع',cdZKMn68Pzg4,139,cdZKMn68Pzg4,cdZKMn68Pzg4,'_REMEMBERRESULTS_')
	zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	OO1cj2REUZHJ8x5V = Gc05Efm73C8s(K8DZxE74Afz52gBYbOMtpvql0RJma,cDTdfqVAF0BLGiX364IEwaZbr,cdZKMn68Pzg4,cdZKMn68Pzg4,True,'ALKAWTHAR-MENU-1st')
	ppvsMqCHf8SEzxQg=ffUFBJQ57j2XgoGeOLn9uwpC.findall('dropdown-menu(.*?)dropdown-toggle',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[1]
	items=ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)">(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	for c0cDhidBlOn7,title in items:
		if '/conductor' in c0cDhidBlOn7: continue
		title = title.strip(VBpIH2QSmvDGlA6TO3e)
		url = cDTdfqVAF0BLGiX364IEwaZbr+c0cDhidBlOn7
		if '/category/' in url: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,url,132)
		else: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,url,131)
	zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+'المسلسلات',cDTdfqVAF0BLGiX364IEwaZbr+'/category/543',132,cdZKMn68Pzg4,'1')
	zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+'الأفلام',cDTdfqVAF0BLGiX364IEwaZbr+'/category/628',132,cdZKMn68Pzg4,'1')
	zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+'برامج الصغار والشباب',cDTdfqVAF0BLGiX364IEwaZbr+'/category/517',132,cdZKMn68Pzg4,'1')
	zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+'ابرز البرامج',cDTdfqVAF0BLGiX364IEwaZbr+'/category/1763',132,cdZKMn68Pzg4,'1')
	zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+'المحاضرات',cDTdfqVAF0BLGiX364IEwaZbr+'/category/943',132,cdZKMn68Pzg4,'1')
	zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+'عاشوراء',cDTdfqVAF0BLGiX364IEwaZbr+'/category/1353',132,cdZKMn68Pzg4,'1')
	zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+'البرامج الاجتماعية',cDTdfqVAF0BLGiX364IEwaZbr+'/category/501',132,cdZKMn68Pzg4,'1')
	zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+'البرامج الدينية',cDTdfqVAF0BLGiX364IEwaZbr+'/category/509',132,cdZKMn68Pzg4,'1')
	zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+'البرامج الوثائقية',cDTdfqVAF0BLGiX364IEwaZbr+'/category/553',132,cdZKMn68Pzg4,'1')
	zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+'البرامج السياسية',cDTdfqVAF0BLGiX364IEwaZbr+'/category/545',132,cdZKMn68Pzg4,'1')
	zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+'كتب',cDTdfqVAF0BLGiX364IEwaZbr+'/category/291',132,cdZKMn68Pzg4,'1')
	zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+'تعلم الفارسية',cDTdfqVAF0BLGiX364IEwaZbr+'/category/88',132,cdZKMn68Pzg4,'1')
	zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+'أرشيف البرامج',cDTdfqVAF0BLGiX364IEwaZbr+'/category/1279',132,cdZKMn68Pzg4,'1')
	return
def GDQUH4fN02sIt81mAcY(url):
	dzuiDUgSXrNcIPmO53qV = ['/religious','/social','/political','/films','/series']
	OO1cj2REUZHJ8x5V = Gc05Efm73C8s(K8DZxE74Afz52gBYbOMtpvql0RJma,url,cdZKMn68Pzg4,cdZKMn68Pzg4,True,'ALKAWTHAR-TITLES-1st')
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('titlebar(.*?)titlebar',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
	if any(value in url for value in dzuiDUgSXrNcIPmO53qV):
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall("src='(.*?)'.*?href='(.*?)'.*?>(.*?)<",KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for y90BoFz8MA1ZThaSC2ILXHiK3OY6w,c0cDhidBlOn7,title in items:
			title = title.strip(VBpIH2QSmvDGlA6TO3e)
			c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr + c0cDhidBlOn7
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,133,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,'1')
	elif '/docs' in url:
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall("src='(.*?)'.*?<h2>(.*?)</h2>.*?href='(.*?)'",KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for y90BoFz8MA1ZThaSC2ILXHiK3OY6w,title,c0cDhidBlOn7 in items:
			title = title.strip(VBpIH2QSmvDGlA6TO3e)
			c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr + c0cDhidBlOn7
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,133,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,'1')
	return
def WH7waGAlyphZe3(url):
	rrb0SF6otehufCYOX4 = url.split(KCQExdbYFqM)[-1]
	OO1cj2REUZHJ8x5V = Gc05Efm73C8s(r43t1YI9deXA5N,url,cdZKMn68Pzg4,cdZKMn68Pzg4,True,'ALKAWTHAR-CATEGORIES-1st')
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('parentcat(.*?)</div>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if not ppvsMqCHf8SEzxQg:
		yIZWSuMpvs3(url,'1')
		return
	KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
	items = ffUFBJQ57j2XgoGeOLn9uwpC.findall("href='(.*?)'.*?>(.*?)<",KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	for c0cDhidBlOn7,title in items:
		title = title.strip(VBpIH2QSmvDGlA6TO3e)
		c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr + c0cDhidBlOn7
		zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,132,cdZKMn68Pzg4,'1')
	return
def yIZWSuMpvs3(url,aOZ3yVnsNlB974pR):
	OO1cj2REUZHJ8x5V = Gc05Efm73C8s(K8DZxE74Afz52gBYbOMtpvql0RJma,url,cdZKMn68Pzg4,cdZKMn68Pzg4,True,'ALKAWTHAR-EPISODES-1st')
	items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('totalpagecount=[\'"](.*?)[\'"]',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if not items:
		url = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="news-detail-body".*?href="(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		url = url[0]
		title = '_MOD_' + 'ملف التشغيل'
		if url: zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,url,134)
		else: NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,'لا يوجد حاليا ملفات فيديو في هذا الفرع')
		return
	NSsjOPBvckzMgldyALrFe3VxWt = int(items[0])
	name = ffUFBJQ57j2XgoGeOLn9uwpC.findall('main-title.*?</a> >(.*?)<',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if name: name = name[0].strip(VBpIH2QSmvDGlA6TO3e)
	else: name = bu6LzUQF7K.getInfoLabel('ListItem.Label')
	if '/category/' in url or 'search?q=' in url:
		rrb0SF6otehufCYOX4 = url.split(KCQExdbYFqM)[-1]
		if aOZ3yVnsNlB974pR==cdZKMn68Pzg4: HOCWKhxITtulVGX = url
		else: HOCWKhxITtulVGX = cDTdfqVAF0BLGiX364IEwaZbr + '/category/' + rrb0SF6otehufCYOX4 + KCQExdbYFqM + aOZ3yVnsNlB974pR
		JJPEReUDbt0QoWHkL21TA = Gc05Efm73C8s(K8DZxE74Afz52gBYbOMtpvql0RJma,HOCWKhxITtulVGX,cdZKMn68Pzg4,cdZKMn68Pzg4,True,'ALKAWTHAR-EPISODES-2nd')
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('currentpagenumber(.*?)pagination',JJPEReUDbt0QoWHkL21TA,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('src="(.*?)".*?full(.*?)>.*?href="(.*?)".*?>(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for y90BoFz8MA1ZThaSC2ILXHiK3OY6w,type,c0cDhidBlOn7,title in items:
			if 'video' not in type: continue
			if 'مسلسل' in title and 'حلقة' not in title: continue
			title = title.replace('\r\n',cdZKMn68Pzg4)
			title = title.strip(VBpIH2QSmvDGlA6TO3e)
			if 'مسلسل' in name and 'حلقة' in title and 'مسلسل' not in title:
				title = '_MOD_' + name + ' - ' + title
			c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr + c0cDhidBlOn7
			if rrb0SF6otehufCYOX4=='628': zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,133,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,'1')
			else: zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,134,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
	elif '/episode/' in url:
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('playlist(.*?)col-md-12',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if ppvsMqCHf8SEzxQg:
			KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
			items = ffUFBJQ57j2XgoGeOLn9uwpC.findall("video-track-text.*?loadVideo\('(.*?)','(.*?)'.*?>(.*?)<",KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			for c0cDhidBlOn7,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,title in items:
				title = title.strip(VBpIH2QSmvDGlA6TO3e)
				zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,134,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
		elif '/category/628' in OO1cj2REUZHJ8x5V:
				title = '_MOD_' + 'ملف التشغيل'
				zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,url,134)
		else:
			items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('id="Categories.*?href=\'(.*?)\'',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			rrb0SF6otehufCYOX4 = items[0].split(KCQExdbYFqM)[-1]
			url = cDTdfqVAF0BLGiX364IEwaZbr + '/category/' + rrb0SF6otehufCYOX4
			WH7waGAlyphZe3(url)
			return
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('pagination(.*?)</div>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		ccNiGxT3tzSyUO4omsVe8PrRYKu = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)">(.*?)</a>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,title in ccNiGxT3tzSyUO4omsVe8PrRYKu:
			c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr+c0cDhidBlOn7
			c0cDhidBlOn7 = c0cDhidBlOn7.replace('&amp;','&')
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'صفحة '+title,c0cDhidBlOn7,133)
	return
def RPZbqous7rtdy56LeI18Cv04AKHW(url):
	if '/news/' in url or '/episode/' in url:
		OO1cj2REUZHJ8x5V = Gc05Efm73C8s(r43t1YI9deXA5N,url,cdZKMn68Pzg4,cdZKMn68Pzg4,True,'ALKAWTHAR-PLAY-1st')
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall("mobilevideopath.*?value='(.*?)'",OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if items: url = items[0]
	bmgwWLk3er(url,UkXlAzsMcamKJrEIgnxi6bWh,'video')
	return
def CGOjMRlNnBafrtz():
	url = cDTdfqVAF0BLGiX364IEwaZbr+'/live'
	OO1cj2REUZHJ8x5V = Gc05Efm73C8s(r43t1YI9deXA5N,url,cdZKMn68Pzg4,cdZKMn68Pzg4,True,'ALKAWTHAR-LIVE-1st')
	HOCWKhxITtulVGX = ffUFBJQ57j2XgoGeOLn9uwpC.findall('live-container.*?src="(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	HOCWKhxITtulVGX = HOCWKhxITtulVGX[0]
	npaJqziQ13tIH0hLjDdB2cWX7uUMPR = {'Referer':cDTdfqVAF0BLGiX364IEwaZbr}
	a0mldvy3ZxPh = e4qbrCQPyuMjpK(fS25N8gAZxpbnLi3srX7PJ,'GET',HOCWKhxITtulVGX,cdZKMn68Pzg4,npaJqziQ13tIH0hLjDdB2cWX7uUMPR,cdZKMn68Pzg4,True,'ALKAWTHAR-LIVE-2nd')
	JJPEReUDbt0QoWHkL21TA = a0mldvy3ZxPh.content
	ZkrlcUwCsK0XGpDSBjW = ffUFBJQ57j2XgoGeOLn9uwpC.findall('csrf-token" content="(.*?)"',JJPEReUDbt0QoWHkL21TA,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	ZkrlcUwCsK0XGpDSBjW = ZkrlcUwCsK0XGpDSBjW[0]
	b4C9rmMJSnNlozuG7dVU5 = CxlbPZwGTcH87e1sWhfSIz29uRUEpV(HOCWKhxITtulVGX,'url')
	N8jUpQxY0rhtDAzbG4kOs9X = ffUFBJQ57j2XgoGeOLn9uwpC.findall("playUrl = '(.*?)'",JJPEReUDbt0QoWHkL21TA,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	N8jUpQxY0rhtDAzbG4kOs9X = b4C9rmMJSnNlozuG7dVU5+N8jUpQxY0rhtDAzbG4kOs9X[0]
	ZZpvkYMlzgK = {'X-CSRF-TOKEN':ZkrlcUwCsK0XGpDSBjW}
	HitRs4bk6VFmK9vxEMfe = e4qbrCQPyuMjpK(fS25N8gAZxpbnLi3srX7PJ,'POST',N8jUpQxY0rhtDAzbG4kOs9X,cdZKMn68Pzg4,ZZpvkYMlzgK,False,True,'ALKAWTHAR-LIVE-3rd')
	ayv01Qtx7nb3pNDROArwlPeWfj4 = HitRs4bk6VFmK9vxEMfe.content
	GMmu2UjLcIOxW0wHaB1KoRyDs856 = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"(.*?)"',ayv01Qtx7nb3pNDROArwlPeWfj4,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	GMmu2UjLcIOxW0wHaB1KoRyDs856 = GMmu2UjLcIOxW0wHaB1KoRyDs856[0].replace('\/',KCQExdbYFqM)
	bmgwWLk3er(GMmu2UjLcIOxW0wHaB1KoRyDs856,UkXlAzsMcamKJrEIgnxi6bWh,'live')
	return
def z4hetAJw3NaT9ROjG6xbZ5CHlW81(search,url=cdZKMn68Pzg4):
	search,EL8zUgbXheot,showDialogs = qbIcHCMdkFKn21e(search)
	if url==cdZKMn68Pzg4:
		if search==cdZKMn68Pzg4: search = BzkmLuvJD9n25Pg()
		if search==cdZKMn68Pzg4: return
		search = YQlEOShHM7RLak2t0yA4NXqv(search)
		url = cDTdfqVAF0BLGiX364IEwaZbr+'/search?q='+search
		yIZWSuMpvs3(url,cdZKMn68Pzg4)
		return
# -*- coding: utf-8 -*-
from RgJNGc7YMP import *
UkXlAzsMcamKJrEIgnxi6bWh = 'SHOOFNET'
nc3GLkA65oxOd = '_SNT_'
cDTdfqVAF0BLGiX364IEwaZbr = USuRxnPlV5.SITESURLS[UkXlAzsMcamKJrEIgnxi6bWh][0]
cJWUPuDGM0Yybv5a9KnIrVzhH78 = ['الرئيسية','يلا شوت','دكتنا','فيديو نسائم']
def HHN5EpbszV3iA2m89hGSQjaPgUZy(mode,url,text):
	if   mode==840: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = kUq58vC7x9hWma164JejMKQ()
	elif mode==841: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = GDQUH4fN02sIt81mAcY(url,text)
	elif mode==842: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = RPZbqous7rtdy56LeI18Cv04AKHW(url)
	elif mode==843: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = UA1q3m0veRxyn8(url)
	elif mode==849: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = z4hetAJw3NaT9ROjG6xbZ5CHlW81(text)
	else: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = False
	return xsGUcR3ef6glKY5hQwpFXEaSt2mrIz
def kUq58vC7x9hWma164JejMKQ():
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',cDTdfqVAF0BLGiX364IEwaZbr,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'SHOOFNET-MENU-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'بحث في الموقع',cdZKMn68Pzg4,849,cdZKMn68Pzg4,cdZKMn68Pzg4,'_REMEMBERRESULTS_')
	zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"primary-links"(.*?)</u',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?<span>(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,title in items:
			if title in cJWUPuDGM0Yybv5a9KnIrVzhH78: continue
			zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+title,c0cDhidBlOn7,841)
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"list-categories"(.*?)</u',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?>(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,title in items:
			if title in cJWUPuDGM0Yybv5a9KnIrVzhH78: continue
			zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+title,c0cDhidBlOn7,841)
	return
def GDQUH4fN02sIt81mAcY(url,ppWtKTjVzdQwmoqNi7E=cdZKMn68Pzg4):
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'SHOOFNET-TITLES-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"home-content"(.*?)"footer"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		KdWauEhgN6OQzjRVm1ro8tkB3 = KdWauEhgN6OQzjRVm1ro8tkB3.replace('"overlay"','"duration"><')
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"thumb".*?data-src="(.*?)".*?"duration">(.*?)<.*?href="(.*?)">(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		KRmzvoWYyxfXw37SEh1Q = []
		for y90BoFz8MA1ZThaSC2ILXHiK3OY6w,Kr1n9xq5TY4gohlVdNEu0b,c0cDhidBlOn7,title in items:
			title = title.strip(' ')
			title = gbd90SjF2mZqf81IRDaTwJkWu(title)
			E0w56WHxZPYGVvnTQ4O2t1C8DAjq = ffUFBJQ57j2XgoGeOLn9uwpC.findall('(.*?) (الحلقة|حلقة).\d+',title,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			if 'episodes' not in ppWtKTjVzdQwmoqNi7E and E0w56WHxZPYGVvnTQ4O2t1C8DAjq:
				title = '_MOD_' + E0w56WHxZPYGVvnTQ4O2t1C8DAjq[0][0]
				title = title.replace('اون لاين',cdZKMn68Pzg4)
				if title not in KRmzvoWYyxfXw37SEh1Q:
					zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,843,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
					KRmzvoWYyxfXw37SEh1Q.append(title)
			else: zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,842,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,Kr1n9xq5TY4gohlVdNEu0b)
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('''["']pagination["'](.*?)["']footer["']''',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		ppWtKTjVzdQwmoqNi7E = 'episodes_pages' if 'episodes' in ppWtKTjVzdQwmoqNi7E else 'pages'
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)">(.*?)</a>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,title in items:
			title = gbd90SjF2mZqf81IRDaTwJkWu(title)
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'صفحة '+title,c0cDhidBlOn7,841,cdZKMn68Pzg4,cdZKMn68Pzg4,ppWtKTjVzdQwmoqNi7E)
	return
def UA1q3m0veRxyn8(url):
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'SHOOFNET-SERIES-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	c0cDhidBlOn7 = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"category".*?href="(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if c0cDhidBlOn7: GDQUH4fN02sIt81mAcY(c0cDhidBlOn7[0],'episodes')
	return
def RPZbqous7rtdy56LeI18Cv04AKHW(url):
	XFj0lV5yMtS67EwbCJ9oO = []
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'SHOOFNET-PLAY-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	eaZTIfi39lq7WXOEYvS10VyJUGpnKc = ffUFBJQ57j2XgoGeOLn9uwpC.findall("var post_id	= '(.*?)'",OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if eaZTIfi39lq7WXOEYvS10VyJUGpnKc:
		c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr+'/wp-admin/admin-ajax.php?action=video_info&post_id='+eaZTIfi39lq7WXOEYvS10VyJUGpnKc[0]
		headers = {'Referer':url}
		Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',c0cDhidBlOn7,cdZKMn68Pzg4,headers,cdZKMn68Pzg4,cdZKMn68Pzg4,'SHOOFNET-PLAY-2nd')
		OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"name":"(.*?)","src":"(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for title,c0cDhidBlOn7 in items:
			title = XTL0AWmwbDJfGRNi(title)
			c0cDhidBlOn7 = c0cDhidBlOn7.replace('\\/',KCQExdbYFqM)
			c0cDhidBlOn7 = c0cDhidBlOn7+'?named='+title+'__watch'
			XFj0lV5yMtS67EwbCJ9oO.append(c0cDhidBlOn7)
	import r0y4XTKznF
	r0y4XTKznF.noHliPXkcg3pJTdSauCvm5sU(XFj0lV5yMtS67EwbCJ9oO,UkXlAzsMcamKJrEIgnxi6bWh,'video',url)
	return
def z4hetAJw3NaT9ROjG6xbZ5CHlW81(search):
	search,EL8zUgbXheot,showDialogs = qbIcHCMdkFKn21e(search)
	if search==cdZKMn68Pzg4: search = BzkmLuvJD9n25Pg()
	if search==cdZKMn68Pzg4: return
	search = search.replace(VBpIH2QSmvDGlA6TO3e,'+')
	url = cDTdfqVAF0BLGiX364IEwaZbr+'/?s='+search
	GDQUH4fN02sIt81mAcY(url,'search')
	return
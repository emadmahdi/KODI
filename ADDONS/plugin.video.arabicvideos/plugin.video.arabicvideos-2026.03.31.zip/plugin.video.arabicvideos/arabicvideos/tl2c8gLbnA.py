# -*- coding: utf-8 -*-
from RgJNGc7YMP import *
LMihk2Vzl4DesIQ65TGmvxqcKdHp = 'FAVORITES'
def ZZFUSgsGOhwdnX37V1TvatJomBMPW2(HHrpyfWjGC,kk3jGiMECcV):
	if   HHrpyfWjGC==270: iiAOHkqYIRW7Bs46CEj3Layefb2hSP = U05YOSpxzrvlK6W8jPgce7qHbwysB(kk3jGiMECcV)
	else: iiAOHkqYIRW7Bs46CEj3Layefb2hSP = False
	return iiAOHkqYIRW7Bs46CEj3Layefb2hSP
def nCgwEFhXp1z9jSokQqBLYW(SUkst0aLFhj,kk3jGiMECcV,D5dElvtILNgTOjPQbBoMmiX):
	if not SUkst0aLFhj: return
	if   D5dElvtILNgTOjPQbBoMmiX=='UP1'	: ggb2ioYSv3zXJ1pZqe46HImrA7(kk3jGiMECcV,True,hiuZa0PIsErm6UC7)
	elif D5dElvtILNgTOjPQbBoMmiX=='DOWN1'	: ggb2ioYSv3zXJ1pZqe46HImrA7(kk3jGiMECcV,False,hiuZa0PIsErm6UC7)
	elif D5dElvtILNgTOjPQbBoMmiX=='UP4'	: ggb2ioYSv3zXJ1pZqe46HImrA7(kk3jGiMECcV,True,iwQJREcVTSe1G2gCvlfhbHWLjqopa)
	elif D5dElvtILNgTOjPQbBoMmiX=='DOWN4'	: ggb2ioYSv3zXJ1pZqe46HImrA7(kk3jGiMECcV,False,iwQJREcVTSe1G2gCvlfhbHWLjqopa)
	elif D5dElvtILNgTOjPQbBoMmiX=='ADD1'	: I5IfBO1RxrPMEoSsHwqtVF(kk3jGiMECcV)
	elif D5dElvtILNgTOjPQbBoMmiX=='REMOVE1': MLYNt67v1WaIhroTpeGEjC39gKyq(kk3jGiMECcV)
	elif D5dElvtILNgTOjPQbBoMmiX=='DELETELIST': ZnWpwzjQGk67(kk3jGiMECcV)
	return
def U05YOSpxzrvlK6W8jPgce7qHbwysB(kk3jGiMECcV):
	H5gnd836TqDG = PPRKmWMO3CuhjrcgFpYx()
	if kk3jGiMECcV in list(H5gnd836TqDG.keys()):
		try:
			zkwYoJg2lqypUtK5dMEn = H5gnd836TqDG[kk3jGiMECcV]
			if nnsBpJv6XL3OzHoe4Vuhr and kk3jGiMECcV in ['5','11','12','13']:
				for kuMXTLrvIZGfjCDtA9YNJ5SxQK,yy0cNBFOGVZh8rIeQ4,kxY4EfTKobmQJ8OathHI53,HHrpyfWjGC,cxokMEeWJnSdZGt53qYhI,iQBgv5oEbM6ZFH4U8qtC,JAYWBoz54tGw7O,SUkst0aLFhj,RqmGlEdhA8z7M in zkwYoJg2lqypUtK5dMEn:
					if kuMXTLrvIZGfjCDtA9YNJ5SxQK=='video':
						zJLApFBcIhnSj('video',Gzygq01Kcb9U3+'تشغيل من الأعلى إلى الأسفل'+kH8E2zqNyims6KJfI,kxY4EfTKobmQJ8OathHI53,HHrpyfWjGC,cxokMEeWJnSdZGt53qYhI,iQBgv5oEbM6ZFH4U8qtC,JAYWBoz54tGw7O,SUkst0aLFhj)
						zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
						break
			for kuMXTLrvIZGfjCDtA9YNJ5SxQK,yy0cNBFOGVZh8rIeQ4,kxY4EfTKobmQJ8OathHI53,HHrpyfWjGC,cxokMEeWJnSdZGt53qYhI,iQBgv5oEbM6ZFH4U8qtC,JAYWBoz54tGw7O,SUkst0aLFhj,RqmGlEdhA8z7M in zkwYoJg2lqypUtK5dMEn:
				zJLApFBcIhnSj(kuMXTLrvIZGfjCDtA9YNJ5SxQK,yy0cNBFOGVZh8rIeQ4,kxY4EfTKobmQJ8OathHI53,HHrpyfWjGC,cxokMEeWJnSdZGt53qYhI,iQBgv5oEbM6ZFH4U8qtC,JAYWBoz54tGw7O,SUkst0aLFhj,RqmGlEdhA8z7M)
		except:
			H5gnd836TqDG = DUwpLP7sOJ8dj9HFTrnE4Y3y(Fav9sQqHIX83Gw6RmcJng70itAruhU)
			zkwYoJg2lqypUtK5dMEn = H5gnd836TqDG[kk3jGiMECcV]
			for kuMXTLrvIZGfjCDtA9YNJ5SxQK,yy0cNBFOGVZh8rIeQ4,kxY4EfTKobmQJ8OathHI53,HHrpyfWjGC,cxokMEeWJnSdZGt53qYhI,iQBgv5oEbM6ZFH4U8qtC,JAYWBoz54tGw7O,SUkst0aLFhj,RqmGlEdhA8z7M in zkwYoJg2lqypUtK5dMEn:
				zJLApFBcIhnSj(kuMXTLrvIZGfjCDtA9YNJ5SxQK,yy0cNBFOGVZh8rIeQ4,kxY4EfTKobmQJ8OathHI53,HHrpyfWjGC,cxokMEeWJnSdZGt53qYhI,iQBgv5oEbM6ZFH4U8qtC,JAYWBoz54tGw7O,SUkst0aLFhj,RqmGlEdhA8z7M)
	return
def I5IfBO1RxrPMEoSsHwqtVF(kk3jGiMECcV):
	kuMXTLrvIZGfjCDtA9YNJ5SxQK,yy0cNBFOGVZh8rIeQ4,kxY4EfTKobmQJ8OathHI53,HHrpyfWjGC,cxokMEeWJnSdZGt53qYhI,iQBgv5oEbM6ZFH4U8qtC,JAYWBoz54tGw7O,SUkst0aLFhj,RqmGlEdhA8z7M = AanhLX36W9emBvK(I4sncq6lxyDa03Gr5B)
	if kk3jGiMECcV in ['5','11','12','13'] and kuMXTLrvIZGfjCDtA9YNJ5SxQK!='video':
		NiWSoAmhdkQPlTpneyVzDO8tw9aL('','',OPEJxmUqr9wAX1i,'هذا العنصر ليس ملف فيديو .. قوائم التشغيل فائدتها تشغيل الفيديوهات خلف بعضها أوتوماتيكيا .. ولهذا قوائم التشغيل يجب أن تحتوي على فيديوهات فقط')
		return
	wgREUQD35vOFn74Zh0J8LVW = kuMXTLrvIZGfjCDtA9YNJ5SxQK,yy0cNBFOGVZh8rIeQ4,kxY4EfTKobmQJ8OathHI53,HHrpyfWjGC,cxokMEeWJnSdZGt53qYhI,iQBgv5oEbM6ZFH4U8qtC,JAYWBoz54tGw7O,cdZKMn68Pzg4,RqmGlEdhA8z7M
	H5gnd836TqDG = PPRKmWMO3CuhjrcgFpYx()
	zcUrTYFl20bLofv4eXkiZ = {}
	for YUidcjrZ6ToLszV0 in list(H5gnd836TqDG.keys()):
		if YUidcjrZ6ToLszV0!=kk3jGiMECcV: zcUrTYFl20bLofv4eXkiZ[YUidcjrZ6ToLszV0] = H5gnd836TqDG[YUidcjrZ6ToLszV0]
		else:
			if yy0cNBFOGVZh8rIeQ4 and yy0cNBFOGVZh8rIeQ4!='..':
				m70JIOv859Hlxq2Fok1rwi = H5gnd836TqDG[YUidcjrZ6ToLszV0]
				if wgREUQD35vOFn74Zh0J8LVW in m70JIOv859Hlxq2Fok1rwi:
					VXa4Oer9fYct = m70JIOv859Hlxq2Fok1rwi.index(wgREUQD35vOFn74Zh0J8LVW)
					del m70JIOv859Hlxq2Fok1rwi[VXa4Oer9fYct]
				YcwNZe8ozFRsrM = m70JIOv859Hlxq2Fok1rwi+[wgREUQD35vOFn74Zh0J8LVW]
				zcUrTYFl20bLofv4eXkiZ[YUidcjrZ6ToLszV0] = YcwNZe8ozFRsrM
			else: zcUrTYFl20bLofv4eXkiZ[YUidcjrZ6ToLszV0] = H5gnd836TqDG[YUidcjrZ6ToLszV0]
	if kk3jGiMECcV not in list(zcUrTYFl20bLofv4eXkiZ.keys()): zcUrTYFl20bLofv4eXkiZ[kk3jGiMECcV] = [wgREUQD35vOFn74Zh0J8LVW]
	fEGDv4eumhRBW2 = str(zcUrTYFl20bLofv4eXkiZ)
	if W5domCu6XrQUFkiPpa3bNLtHglG: fEGDv4eumhRBW2 = fEGDv4eumhRBW2.encode(vczMIlkCAh2u10B3)
	open(Fav9sQqHIX83Gw6RmcJng70itAruhU,'wb').write(fEGDv4eumhRBW2)
	return
def MLYNt67v1WaIhroTpeGEjC39gKyq(kk3jGiMECcV):
	kuMXTLrvIZGfjCDtA9YNJ5SxQK,yy0cNBFOGVZh8rIeQ4,kxY4EfTKobmQJ8OathHI53,HHrpyfWjGC,cxokMEeWJnSdZGt53qYhI,iQBgv5oEbM6ZFH4U8qtC,JAYWBoz54tGw7O,SUkst0aLFhj,RqmGlEdhA8z7M = AanhLX36W9emBvK(I4sncq6lxyDa03Gr5B)
	wgREUQD35vOFn74Zh0J8LVW = kuMXTLrvIZGfjCDtA9YNJ5SxQK,yy0cNBFOGVZh8rIeQ4,kxY4EfTKobmQJ8OathHI53,HHrpyfWjGC,cxokMEeWJnSdZGt53qYhI,iQBgv5oEbM6ZFH4U8qtC,JAYWBoz54tGw7O,cdZKMn68Pzg4,RqmGlEdhA8z7M
	H5gnd836TqDG = PPRKmWMO3CuhjrcgFpYx()
	if kk3jGiMECcV in list(H5gnd836TqDG.keys()) and wgREUQD35vOFn74Zh0J8LVW in H5gnd836TqDG[kk3jGiMECcV]:
		H5gnd836TqDG[kk3jGiMECcV].remove(wgREUQD35vOFn74Zh0J8LVW)
		if len(H5gnd836TqDG[kk3jGiMECcV])==nnsBpJv6XL3OzHoe4Vuhr: del H5gnd836TqDG[kk3jGiMECcV]
		fEGDv4eumhRBW2 = str(H5gnd836TqDG)
		if W5domCu6XrQUFkiPpa3bNLtHglG: fEGDv4eumhRBW2 = fEGDv4eumhRBW2.encode(vczMIlkCAh2u10B3)
		open(Fav9sQqHIX83Gw6RmcJng70itAruhU,'wb').write(fEGDv4eumhRBW2)
	return
def ggb2ioYSv3zXJ1pZqe46HImrA7(kk3jGiMECcV,VqwpBF7TRe4i6hv3,NjqzLacAwfIRg2VKUHrnO31d):
	kuMXTLrvIZGfjCDtA9YNJ5SxQK,yy0cNBFOGVZh8rIeQ4,kxY4EfTKobmQJ8OathHI53,HHrpyfWjGC,cxokMEeWJnSdZGt53qYhI,iQBgv5oEbM6ZFH4U8qtC,JAYWBoz54tGw7O,SUkst0aLFhj,RqmGlEdhA8z7M = AanhLX36W9emBvK(I4sncq6lxyDa03Gr5B)
	wgREUQD35vOFn74Zh0J8LVW = kuMXTLrvIZGfjCDtA9YNJ5SxQK,yy0cNBFOGVZh8rIeQ4,kxY4EfTKobmQJ8OathHI53,HHrpyfWjGC,cxokMEeWJnSdZGt53qYhI,iQBgv5oEbM6ZFH4U8qtC,JAYWBoz54tGw7O,cdZKMn68Pzg4,RqmGlEdhA8z7M
	H5gnd836TqDG = PPRKmWMO3CuhjrcgFpYx()
	if kk3jGiMECcV in list(H5gnd836TqDG.keys()):
		m70JIOv859Hlxq2Fok1rwi = H5gnd836TqDG[kk3jGiMECcV]
		if wgREUQD35vOFn74Zh0J8LVW not in m70JIOv859Hlxq2Fok1rwi: return
		pp4XO1uC9v = len(m70JIOv859Hlxq2Fok1rwi)
		for ZoQJArX6xtaIG0MfLnvqEmD in range(nnsBpJv6XL3OzHoe4Vuhr,NjqzLacAwfIRg2VKUHrnO31d):
			alyqzd6xXi51SNp = m70JIOv859Hlxq2Fok1rwi.index(wgREUQD35vOFn74Zh0J8LVW)
			if VqwpBF7TRe4i6hv3: ttOc3u2gCDUM0spQRPn = alyqzd6xXi51SNp-hiuZa0PIsErm6UC7
			else: ttOc3u2gCDUM0spQRPn = alyqzd6xXi51SNp+hiuZa0PIsErm6UC7
			if ttOc3u2gCDUM0spQRPn>=pp4XO1uC9v: ttOc3u2gCDUM0spQRPn = ttOc3u2gCDUM0spQRPn-pp4XO1uC9v
			if ttOc3u2gCDUM0spQRPn<nnsBpJv6XL3OzHoe4Vuhr: ttOc3u2gCDUM0spQRPn = ttOc3u2gCDUM0spQRPn+pp4XO1uC9v
			m70JIOv859Hlxq2Fok1rwi.insert(ttOc3u2gCDUM0spQRPn, m70JIOv859Hlxq2Fok1rwi.pop(alyqzd6xXi51SNp))
		H5gnd836TqDG[kk3jGiMECcV] = m70JIOv859Hlxq2Fok1rwi
		fEGDv4eumhRBW2 = str(H5gnd836TqDG)
		if W5domCu6XrQUFkiPpa3bNLtHglG: fEGDv4eumhRBW2 = fEGDv4eumhRBW2.encode(vczMIlkCAh2u10B3)
		open(Fav9sQqHIX83Gw6RmcJng70itAruhU,'wb').write(fEGDv4eumhRBW2)
	return
def IknRFOD3yH79ifJxT6PLZMV2(kk3jGiMECcV):
	if kk3jGiMECcV in ['1','2','3','4']: Y1kxpSZdGVyMRcLfbaI6Plg08NeKF,MuN2HoRbLKyqi9mJscVZh = 'مفضلة',kk3jGiMECcV
	elif kk3jGiMECcV in ['5']: Y1kxpSZdGVyMRcLfbaI6Plg08NeKF,MuN2HoRbLKyqi9mJscVZh = 'تشغيل','1'
	elif kk3jGiMECcV in ['11']: Y1kxpSZdGVyMRcLfbaI6Plg08NeKF,MuN2HoRbLKyqi9mJscVZh = 'تشغيل','2'
	else: Y1kxpSZdGVyMRcLfbaI6Plg08NeKF,MuN2HoRbLKyqi9mJscVZh = cdZKMn68Pzg4,cdZKMn68Pzg4
	QcpyjsvqJEB6zt1I0 = Y1kxpSZdGVyMRcLfbaI6Plg08NeKF+VBpIH2QSmvDGlA6TO3e+MuN2HoRbLKyqi9mJscVZh
	return QcpyjsvqJEB6zt1I0
def ZnWpwzjQGk67(kk3jGiMECcV):
	QcpyjsvqJEB6zt1I0 = IknRFOD3yH79ifJxT6PLZMV2(kk3jGiMECcV)
	GPQCWezyxpbjhHNXMVEaI4FR = JyLdvftP3CU('center',cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,'هل تريد فعلا مسح جميع محتويات قائمة '+QcpyjsvqJEB6zt1I0+' ؟!')
	if GPQCWezyxpbjhHNXMVEaI4FR!=1: return
	H5gnd836TqDG = PPRKmWMO3CuhjrcgFpYx()
	if kk3jGiMECcV in list(H5gnd836TqDG.keys()):
		del H5gnd836TqDG[kk3jGiMECcV]
		fEGDv4eumhRBW2 = str(H5gnd836TqDG)
		if W5domCu6XrQUFkiPpa3bNLtHglG: fEGDv4eumhRBW2 = fEGDv4eumhRBW2.encode(vczMIlkCAh2u10B3)
		open(Fav9sQqHIX83Gw6RmcJng70itAruhU,'wb').write(fEGDv4eumhRBW2)
		NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,'تم مسح جميع محتويات قائمة '+QcpyjsvqJEB6zt1I0)
	return
def PPRKmWMO3CuhjrcgFpYx():
	H5gnd836TqDG = {}
	if YRESXadfbIy3khwqmL8WC.path.exists(Fav9sQqHIX83Gw6RmcJng70itAruhU):
		yyCzorcb52PZq3gBF = open(Fav9sQqHIX83Gw6RmcJng70itAruhU,'rb').read()
		if W5domCu6XrQUFkiPpa3bNLtHglG: yyCzorcb52PZq3gBF = yyCzorcb52PZq3gBF.decode(vczMIlkCAh2u10B3)
		H5gnd836TqDG = lMeKd3hC6cmS('dict',yyCzorcb52PZq3gBF)
	return H5gnd836TqDG
def vvd6oYBEDIebu2G1mh(H5gnd836TqDG,wgREUQD35vOFn74Zh0J8LVW,k3Xf2xY9c74wNgKb80vhP):
	kuMXTLrvIZGfjCDtA9YNJ5SxQK,yy0cNBFOGVZh8rIeQ4,kxY4EfTKobmQJ8OathHI53,HHrpyfWjGC,cxokMEeWJnSdZGt53qYhI,iQBgv5oEbM6ZFH4U8qtC,JAYWBoz54tGw7O,SUkst0aLFhj,RqmGlEdhA8z7M = wgREUQD35vOFn74Zh0J8LVW
	if not HHrpyfWjGC: kuMXTLrvIZGfjCDtA9YNJ5SxQK,HHrpyfWjGC = 'folder','260'
	XXbZkM0hJo2OHjqnPScNm15DC,kk3jGiMECcV = [],cdZKMn68Pzg4
	if 'context=' in I4sncq6lxyDa03Gr5B:
		tpN3aQdyikTzrXY8RVjuq = ffUFBJQ57j2XgoGeOLn9uwpC.findall('context=(\d+)',I4sncq6lxyDa03Gr5B,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if tpN3aQdyikTzrXY8RVjuq: kk3jGiMECcV = str(tpN3aQdyikTzrXY8RVjuq[nnsBpJv6XL3OzHoe4Vuhr])
	if HHrpyfWjGC=='270':
		kk3jGiMECcV = SUkst0aLFhj
		if kk3jGiMECcV in list(H5gnd836TqDG.keys()):
			QcpyjsvqJEB6zt1I0 = IknRFOD3yH79ifJxT6PLZMV2(kk3jGiMECcV)
			XXbZkM0hJo2OHjqnPScNm15DC.append(('مسح قائمة '+QcpyjsvqJEB6zt1I0,'RunPlugin('+k3Xf2xY9c74wNgKb80vhP+'&context='+kk3jGiMECcV+'_DELETELIST'+')'))
	else:
		if kk3jGiMECcV in list(H5gnd836TqDG.keys()):
			count = len(H5gnd836TqDG[kk3jGiMECcV])
			if count>hiuZa0PIsErm6UC7: XXbZkM0hJo2OHjqnPScNm15DC.append(('تحريك 1 للأعلى','RunPlugin('+k3Xf2xY9c74wNgKb80vhP+'&context='+kk3jGiMECcV+'_UP1)'))
			if count>iwQJREcVTSe1G2gCvlfhbHWLjqopa: XXbZkM0hJo2OHjqnPScNm15DC.append(('تحريك 4 للأعلى','RunPlugin('+k3Xf2xY9c74wNgKb80vhP+'&context='+kk3jGiMECcV+'_UP4)'))
			if count>hiuZa0PIsErm6UC7: XXbZkM0hJo2OHjqnPScNm15DC.append(('تحريك 1 للأسفل','RunPlugin('+k3Xf2xY9c74wNgKb80vhP+'&context='+kk3jGiMECcV+'_DOWN1)'))
			if count>iwQJREcVTSe1G2gCvlfhbHWLjqopa: XXbZkM0hJo2OHjqnPScNm15DC.append(('تحريك 4 للأسفل','RunPlugin('+k3Xf2xY9c74wNgKb80vhP+'&context='+kk3jGiMECcV+'_DOWN4)'))
		for kk3jGiMECcV in ['1','2','3','4','5','11']:
			QcpyjsvqJEB6zt1I0 = IknRFOD3yH79ifJxT6PLZMV2(kk3jGiMECcV)
			if kk3jGiMECcV in list(H5gnd836TqDG.keys()) and wgREUQD35vOFn74Zh0J8LVW in H5gnd836TqDG[kk3jGiMECcV]:
				XXbZkM0hJo2OHjqnPScNm15DC.append(('مسح من '+QcpyjsvqJEB6zt1I0,'RunPlugin('+k3Xf2xY9c74wNgKb80vhP+'&context='+kk3jGiMECcV+'_REMOVE1)'))
			else: XXbZkM0hJo2OHjqnPScNm15DC.append(('إضافة ل'+QcpyjsvqJEB6zt1I0,'RunPlugin('+k3Xf2xY9c74wNgKb80vhP+'&context='+kk3jGiMECcV+'_ADD1)'))
	A2x7LZsICcmYlVOpyBjhDg5Q6vJ4SG = []
	for QVtwaTGYORBlf32HZD9eIUkogAmEhd,meuL8lTnvdo70UV1CKFGHNfPzDiWw in XXbZkM0hJo2OHjqnPScNm15DC:
		QVtwaTGYORBlf32HZD9eIUkogAmEhd = bxf7gZvNK29cEoiAIJlMq0dP+QVtwaTGYORBlf32HZD9eIUkogAmEhd+kH8E2zqNyims6KJfI
		A2x7LZsICcmYlVOpyBjhDg5Q6vJ4SG.append((QVtwaTGYORBlf32HZD9eIUkogAmEhd,meuL8lTnvdo70UV1CKFGHNfPzDiWw,))
	return A2x7LZsICcmYlVOpyBjhDg5Q6vJ4SG
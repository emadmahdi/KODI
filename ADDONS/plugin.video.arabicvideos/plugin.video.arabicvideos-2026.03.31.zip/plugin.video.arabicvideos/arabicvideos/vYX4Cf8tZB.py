# -*- coding: utf-8 -*-
from RgJNGc7YMP import *
UkXlAzsMcamKJrEIgnxi6bWh = 'KATKOTTV'
nc3GLkA65oxOd = '_KTV_'
cDTdfqVAF0BLGiX364IEwaZbr = USuRxnPlV5.SITESURLS[UkXlAzsMcamKJrEIgnxi6bWh][0]
cJWUPuDGM0Yybv5a9KnIrVzhH78 = []
def HHN5EpbszV3iA2m89hGSQjaPgUZy(mode,url,text):
	if   mode==810: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = kUq58vC7x9hWma164JejMKQ()
	elif mode==811: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = GDQUH4fN02sIt81mAcY(url,text)
	elif mode==812: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = RPZbqous7rtdy56LeI18Cv04AKHW(url)
	elif mode==813: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = UA1q3m0veRxyn8(url)
	elif mode==819: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = z4hetAJw3NaT9ROjG6xbZ5CHlW81(text)
	else: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = False
	return xsGUcR3ef6glKY5hQwpFXEaSt2mrIz
def kUq58vC7x9hWma164JejMKQ():
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',cDTdfqVAF0BLGiX364IEwaZbr,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'KATKOTTV-MENU-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'بحث في الموقع',cdZKMn68Pzg4,819,cdZKMn68Pzg4,cdZKMn68Pzg4,'_REMEMBERRESULTS_')
	zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"primary-links"(.*?)"most-viewed"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
	items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?<span>(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	for c0cDhidBlOn7,title in items:
		if title in cJWUPuDGM0Yybv5a9KnIrVzhH78: continue
		zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+title,c0cDhidBlOn7,811)
	return
def GDQUH4fN02sIt81mAcY(url,type=cdZKMn68Pzg4):
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'KATKOTTV-TITLES-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"home-content"(.*?)"footer"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"thumb".*?data-src="(.*?)".*?href="(.*?)".*?title="(.*?)"',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		KRmzvoWYyxfXw37SEh1Q = []
		for y90BoFz8MA1ZThaSC2ILXHiK3OY6w,c0cDhidBlOn7,title in items:
			title = gbd90SjF2mZqf81IRDaTwJkWu(title)
			E0w56WHxZPYGVvnTQ4O2t1C8DAjq = ffUFBJQ57j2XgoGeOLn9uwpC.findall('(.*?) (الحلقة|حلقة).\d+',title,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			if 'episodes' not in type and E0w56WHxZPYGVvnTQ4O2t1C8DAjq:
				title = '_MOD_' + E0w56WHxZPYGVvnTQ4O2t1C8DAjq[0][0]
				title = title.replace('اون لاين',cdZKMn68Pzg4)
				if title not in KRmzvoWYyxfXw37SEh1Q:
					zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,813,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
					KRmzvoWYyxfXw37SEh1Q.append(title)
			else: zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,812,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall("'pagination'(.*?)footer",OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		type = 'episodes_pages' if 'episodes' in type else 'pages'
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)">(.*?)</a>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,title in items:
			title = gbd90SjF2mZqf81IRDaTwJkWu(title)
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'صفحة '+title,c0cDhidBlOn7,811,cdZKMn68Pzg4,cdZKMn68Pzg4,type)
	return
def UA1q3m0veRxyn8(url):
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'KATKOTTV-SERIES-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	c0cDhidBlOn7 = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"category".*?href="(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if c0cDhidBlOn7: GDQUH4fN02sIt81mAcY(c0cDhidBlOn7[0],'episodes')
	return
def RPZbqous7rtdy56LeI18Cv04AKHW(url):
	XFj0lV5yMtS67EwbCJ9oO = []
	HOCWKhxITtulVGX = url+'?do=watch'
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',HOCWKhxITtulVGX,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'KATKOTTV-PLAY-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	c0cDhidBlOn7 = ffUFBJQ57j2XgoGeOLn9uwpC.findall('" src="(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if c0cDhidBlOn7:
		c0cDhidBlOn7 = c0cDhidBlOn7[0]
		XFj0lV5yMtS67EwbCJ9oO.append(c0cDhidBlOn7)
	else:
		Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'KATKOTTV-PLAY-2nd')
		OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
		PTsY9XSpQFhGuxtvJk74oV3fwdWeaE = ffUFBJQ57j2XgoGeOLn9uwpC.findall('post=(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if PTsY9XSpQFhGuxtvJk74oV3fwdWeaE:
			PTsY9XSpQFhGuxtvJk74oV3fwdWeaE = abn2REWAS3FwTN0rlQmgOk.b64decode(PTsY9XSpQFhGuxtvJk74oV3fwdWeaE[0])
			if W5domCu6XrQUFkiPpa3bNLtHglG: PTsY9XSpQFhGuxtvJk74oV3fwdWeaE = PTsY9XSpQFhGuxtvJk74oV3fwdWeaE.decode(vczMIlkCAh2u10B3)
			PTsY9XSpQFhGuxtvJk74oV3fwdWeaE = lMeKd3hC6cmS('dict',PTsY9XSpQFhGuxtvJk74oV3fwdWeaE)
			zz4ZPovUbyk5GEhNMs8JDnaVXftS = PTsY9XSpQFhGuxtvJk74oV3fwdWeaE['servers']
			Snu3TYPhdqbc = list(zz4ZPovUbyk5GEhNMs8JDnaVXftS.keys())
			zz4ZPovUbyk5GEhNMs8JDnaVXftS = list(zz4ZPovUbyk5GEhNMs8JDnaVXftS.values())
			JJA9R5FEWOzQbDd8eowj3cv4 = zip(Snu3TYPhdqbc,zz4ZPovUbyk5GEhNMs8JDnaVXftS)
			for title,c0cDhidBlOn7 in JJA9R5FEWOzQbDd8eowj3cv4:
				c0cDhidBlOn7 = c0cDhidBlOn7+'?named='+title+'__watch'
				XFj0lV5yMtS67EwbCJ9oO.append(c0cDhidBlOn7)
	import r0y4XTKznF
	r0y4XTKznF.noHliPXkcg3pJTdSauCvm5sU(XFj0lV5yMtS67EwbCJ9oO,UkXlAzsMcamKJrEIgnxi6bWh,'video',url)
	return
def z4hetAJw3NaT9ROjG6xbZ5CHlW81(search):
	search,EL8zUgbXheot,showDialogs = qbIcHCMdkFKn21e(search)
	if search==cdZKMn68Pzg4: search = BzkmLuvJD9n25Pg()
	if search==cdZKMn68Pzg4: return
	search = search.replace(VBpIH2QSmvDGlA6TO3e,'+')
	url = cDTdfqVAF0BLGiX364IEwaZbr+'/?s='+search
	GDQUH4fN02sIt81mAcY(url,'search')
	return
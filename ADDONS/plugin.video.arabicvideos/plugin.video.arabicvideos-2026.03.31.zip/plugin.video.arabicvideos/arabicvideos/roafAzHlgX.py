# -*- coding: utf-8 -*-
from RgJNGc7YMP import *
UkXlAzsMcamKJrEIgnxi6bWh = 'MOVIZLAND'
headers = { 'User-Agent' : cdZKMn68Pzg4 }
nc3GLkA65oxOd = '_MVZ_'
cDTdfqVAF0BLGiX364IEwaZbr = USuRxnPlV5.SITESURLS[UkXlAzsMcamKJrEIgnxi6bWh][0]
Nl3Tz5nOPvLKqH7jJAVs1mF2r = USuRxnPlV5.SITESURLS[UkXlAzsMcamKJrEIgnxi6bWh][1]
def HHN5EpbszV3iA2m89hGSQjaPgUZy(mode,url,text):
	if   mode==180: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = kUq58vC7x9hWma164JejMKQ()
	elif mode==181: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = GDQUH4fN02sIt81mAcY(url,text)
	elif mode==182: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = RPZbqous7rtdy56LeI18Cv04AKHW(url)
	elif mode==183: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = yIZWSuMpvs3(url)
	elif mode==188: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = T1vxDYruf2cbRd7lz5S6o8G0()
	elif mode==189: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = z4hetAJw3NaT9ROjG6xbZ5CHlW81(text)
	else: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = False
	return xsGUcR3ef6glKY5hQwpFXEaSt2mrIz
def T1vxDYruf2cbRd7lz5S6o8G0():
	message = 'هذا الموقع تغير بالكامل ... وبحاجة الى اعادة برمجة من الصفر ... والمبرمج حاليا مشغول ويعاني من وعكة صحية ... ولهذا سوف يبقى الموقع مغلق الى ما شاء الله'
	NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,message)
	return
def kUq58vC7x9hWma164JejMKQ():
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'بحث في الموقع',cdZKMn68Pzg4,189,cdZKMn68Pzg4,cdZKMn68Pzg4,'_REMEMBERRESULTS_')
	zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+'بوكس اوفيس موفيز لاند',cDTdfqVAF0BLGiX364IEwaZbr,181,cdZKMn68Pzg4,cdZKMn68Pzg4,'box-office')
	zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+'أحدث الافلام',cDTdfqVAF0BLGiX364IEwaZbr,181,cdZKMn68Pzg4,cdZKMn68Pzg4,'latest-movies')
	zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+'تليفزيون موفيز لاند',cDTdfqVAF0BLGiX364IEwaZbr,181,cdZKMn68Pzg4,cdZKMn68Pzg4,'tv')
	zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+'الاكثر مشاهدة',cDTdfqVAF0BLGiX364IEwaZbr,181,cdZKMn68Pzg4,cdZKMn68Pzg4,'top-views')
	zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+'أقوى الافلام الحالية',cDTdfqVAF0BLGiX364IEwaZbr,181,cdZKMn68Pzg4,cdZKMn68Pzg4,'top-movies')
	OO1cj2REUZHJ8x5V = Gc05Efm73C8s(r43t1YI9deXA5N,cDTdfqVAF0BLGiX364IEwaZbr,cdZKMn68Pzg4,headers,cdZKMn68Pzg4,'MOVIZLAND-MENU-1st')
	items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('<h2><a href="(.*?)".*?">(.*?)<',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	for c0cDhidBlOn7,title in items:
		zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+title,c0cDhidBlOn7,181)
	return OO1cj2REUZHJ8x5V
def GDQUH4fN02sIt81mAcY(url,type=cdZKMn68Pzg4):
	OO1cj2REUZHJ8x5V = Gc05Efm73C8s(K8DZxE74Afz52gBYbOMtpvql0RJma,url,cdZKMn68Pzg4,headers,cdZKMn68Pzg4,'MOVIZLAND-ITEMS-1st')
	if type=='latest-movies': KdWauEhgN6OQzjRVm1ro8tkB3 = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="titleSection">أحدث الأفلام</h1>(.*?)<h1',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)[0]
	elif type=='box-office': KdWauEhgN6OQzjRVm1ro8tkB3 = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="titleSection">بوكس اوفيس موفيز لاند</h1>(.*?)<h1',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)[0]
	elif type=='top-movies': KdWauEhgN6OQzjRVm1ro8tkB3 = ffUFBJQ57j2XgoGeOLn9uwpC.findall('btn-2-overlay(.*?)<style>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)[0]
	elif type=='top-views': KdWauEhgN6OQzjRVm1ro8tkB3 = ffUFBJQ57j2XgoGeOLn9uwpC.findall('btn-1 btn-absoly(.*?)btn-2 btn-absoly',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)[0]
	elif type=='tv': KdWauEhgN6OQzjRVm1ro8tkB3 = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="titleSection">تليفزيون موفيز لاند</h1>(.*?)class="paging"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)[0]
	else: KdWauEhgN6OQzjRVm1ro8tkB3 = OO1cj2REUZHJ8x5V
	if type in ['top-views','top-movies']:
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('style="background-image:url\(\'(.*?)\'.*?href="(.*?)".*?href="(.*?)".*?bottom-title.*?>(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	else: items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('height="3[0-9]+" src="(.*?)".*?bottom-title.*?href=.*?>(.*?)<.*?href="(.*?)".*?href="(.*?)"',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	KRmzvoWYyxfXw37SEh1Q = []
	xxqCJF6pGQna8Nl2SIEM = ['فيلم','الحلقة','الحلقه','عرض','Raw','SmackDown','اعلان','اجزاء']
	for y90BoFz8MA1ZThaSC2ILXHiK3OY6w,aSW5tHiJKrCu,b63dnmLtQNqzk,axABQbqcRzOEwLf2kMWZH in items:
		if type in ['top-views','top-movies']:
			y90BoFz8MA1ZThaSC2ILXHiK3OY6w,c0cDhidBlOn7,cz5qCJd6O3g4ISxVa1EtQpysvGHPk,title = y90BoFz8MA1ZThaSC2ILXHiK3OY6w,aSW5tHiJKrCu,b63dnmLtQNqzk,axABQbqcRzOEwLf2kMWZH
		else: y90BoFz8MA1ZThaSC2ILXHiK3OY6w,title,c0cDhidBlOn7,cz5qCJd6O3g4ISxVa1EtQpysvGHPk = y90BoFz8MA1ZThaSC2ILXHiK3OY6w,aSW5tHiJKrCu,b63dnmLtQNqzk,axABQbqcRzOEwLf2kMWZH
		c0cDhidBlOn7 = NLqxoZ37dYf0awrsIE(c0cDhidBlOn7)
		c0cDhidBlOn7 = c0cDhidBlOn7.replace('?view=true',cdZKMn68Pzg4)
		title = gbd90SjF2mZqf81IRDaTwJkWu(title)
		if 'بجودة ' in title or 'بجوده ' in title:
			title = '_MOD_' + title.replace('بجودة ',cdZKMn68Pzg4).replace('بجوده ',cdZKMn68Pzg4)
		title = title.strip(VBpIH2QSmvDGlA6TO3e)
		if 'الحلقة' in title or 'الحلقه' in title:
			E0w56WHxZPYGVvnTQ4O2t1C8DAjq = ffUFBJQ57j2XgoGeOLn9uwpC.findall('(.*?) (الحلقة|الحلقه) \d+',title,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			if E0w56WHxZPYGVvnTQ4O2t1C8DAjq:
				title = '_MOD_' + E0w56WHxZPYGVvnTQ4O2t1C8DAjq[0][0]
				if title not in KRmzvoWYyxfXw37SEh1Q:
					zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,183,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
					KRmzvoWYyxfXw37SEh1Q.append(title)
		elif any(value in title for value in xxqCJF6pGQna8Nl2SIEM):
			c0cDhidBlOn7 = c0cDhidBlOn7 + '?servers=' + cz5qCJd6O3g4ISxVa1EtQpysvGHPk
			zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,182,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
		else:
			c0cDhidBlOn7 = c0cDhidBlOn7 + '?servers=' + cz5qCJd6O3g4ISxVa1EtQpysvGHPk
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,183,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
	if type==cdZKMn68Pzg4:
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('\n<li><a href="(.*?)".*?>(.*?)<',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,title in items:
			title = gbd90SjF2mZqf81IRDaTwJkWu(title)
			title = title.replace('الصفحة ',cdZKMn68Pzg4)
			if title!=cdZKMn68Pzg4:
				zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'صفحة '+title,c0cDhidBlOn7,181)
	return
def yIZWSuMpvs3(url):
	HOCWKhxITtulVGX = url.split('?servers=')[0]
	OO1cj2REUZHJ8x5V = Gc05Efm73C8s(K8DZxE74Afz52gBYbOMtpvql0RJma,HOCWKhxITtulVGX,cdZKMn68Pzg4,headers,cdZKMn68Pzg4,'MOVIZLAND-EPISODES-1st')
	KdWauEhgN6OQzjRVm1ro8tkB3 = ffUFBJQ57j2XgoGeOLn9uwpC.findall('<title>(.*?)</title>.*?height="([0-9]+)" src="(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	title,tYPfm3ISxD,y90BoFz8MA1ZThaSC2ILXHiK3OY6w = KdWauEhgN6OQzjRVm1ro8tkB3[0]
	name = ffUFBJQ57j2XgoGeOLn9uwpC.findall('(.*?) (الحلقة|الحلقه) [0-9]+',title,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if name: name = '_MOD_' + name[0][0]
	else: name = title
	items = []
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="episodesNumbers"(.*?)</div>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)"',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7 in items:
			c0cDhidBlOn7 = NLqxoZ37dYf0awrsIE(c0cDhidBlOn7)
			title = ffUFBJQ57j2XgoGeOLn9uwpC.findall('(الحلقة|الحلقه)-([0-9]+)',c0cDhidBlOn7.split(KCQExdbYFqM)[-2],ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			if not title: title = ffUFBJQ57j2XgoGeOLn9uwpC.findall('()-([0-9]+)',c0cDhidBlOn7.split(KCQExdbYFqM)[-2],ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			if title: title = VBpIH2QSmvDGlA6TO3e + title[0][1]
			else: title = cdZKMn68Pzg4
			title = name + ' - ' + 'الحلقة' + title
			title = gbd90SjF2mZqf81IRDaTwJkWu(title)
			zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,182,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
	if not items:
		title = gbd90SjF2mZqf81IRDaTwJkWu(title)
		if 'بجودة ' in title or 'بجوده ' in title:
			title = '_MOD_' + title.replace('بجودة ',cdZKMn68Pzg4).replace('بجوده ',cdZKMn68Pzg4)
		zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,url,182,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
	return
def RPZbqous7rtdy56LeI18Cv04AKHW(url):
	cjlG6M7pFSOb43fd = url.split('?servers=')
	HOCWKhxITtulVGX = cjlG6M7pFSOb43fd[0]
	del cjlG6M7pFSOb43fd[0]
	OO1cj2REUZHJ8x5V = Gc05Efm73C8s(r43t1YI9deXA5N,HOCWKhxITtulVGX,cdZKMn68Pzg4,headers,cdZKMn68Pzg4,'MOVIZLAND-PLAY-1st')
	c0cDhidBlOn7 = ffUFBJQ57j2XgoGeOLn9uwpC.findall('font-size: 25px;" href="(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)[0]
	if c0cDhidBlOn7 not in cjlG6M7pFSOb43fd: cjlG6M7pFSOb43fd.append(c0cDhidBlOn7)
	pcX7zxFRmsADwUr = []
	for c0cDhidBlOn7 in cjlG6M7pFSOb43fd:
		if '://moshahda.' in c0cDhidBlOn7:
			nxNpqBvz1eKJacsMIrm = c0cDhidBlOn7
			pcX7zxFRmsADwUr.append(nxNpqBvz1eKJacsMIrm+'?named=Main')
	for c0cDhidBlOn7 in cjlG6M7pFSOb43fd:
		if '://vb.movizland.' in c0cDhidBlOn7:
			OO1cj2REUZHJ8x5V = Gc05Efm73C8s(r43t1YI9deXA5N,c0cDhidBlOn7,cdZKMn68Pzg4,headers,cdZKMn68Pzg4,'MOVIZLAND-PLAY-2nd')
			OO1cj2REUZHJ8x5V = OO1cj2REUZHJ8x5V.decode(wJCp6Gzbj8MseURla0mA).encode(vczMIlkCAh2u10B3)
			OO1cj2REUZHJ8x5V = OO1cj2REUZHJ8x5V.replace('src="http://up.movizland.com/uploads/13721411411.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"')
			OO1cj2REUZHJ8x5V = OO1cj2REUZHJ8x5V.replace('src="http://up.movizland.online/uploads/13721411411.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"')
			OO1cj2REUZHJ8x5V = OO1cj2REUZHJ8x5V.replace('</a></div><br /><div align="center">','src="/uploads/13721411411.png"')
			OO1cj2REUZHJ8x5V = OO1cj2REUZHJ8x5V.replace('class="tborder" align="center"','src="/uploads/13721411411.png"')
			ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('(src="/uploads/13721411411.png".*?href="http://moshahda\..*?/\w+.html".*?src="/uploads/13721411411.png")',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			if ppvsMqCHf8SEzxQg:
				ligKtjHbwBapq5n4oA9FUJESTfI8,phM4ETtXYnCe = [],[]
				if len(ppvsMqCHf8SEzxQg)==1:
					title = cdZKMn68Pzg4
					KdWauEhgN6OQzjRVm1ro8tkB3 = OO1cj2REUZHJ8x5V
				else:
					for KdWauEhgN6OQzjRVm1ro8tkB3 in ppvsMqCHf8SEzxQg:
						PfGSURJ9jeNtx7FX = ffUFBJQ57j2XgoGeOLn9uwpC.findall('src="/uploads/13721411411.png".*?http://up.movizland.(online|com)/uploads/.*?\*\*\*\*\*\*\*+(.*?src="/uploads/13721411411.png")',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
						if PfGSURJ9jeNtx7FX: KdWauEhgN6OQzjRVm1ro8tkB3 = 'src="/uploads/13721411411.png"  \n  ' + PfGSURJ9jeNtx7FX[0][1]
						PfGSURJ9jeNtx7FX = ffUFBJQ57j2XgoGeOLn9uwpC.findall('src="/uploads/13721411411.png".*?<hr size="1" style="color:'+'#'+'333; background-color:'+'#'+'333" />(.*?href="http://moshahda\..*?/\w+.html".*?src="/uploads/13721411411.png")',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
						if PfGSURJ9jeNtx7FX: KdWauEhgN6OQzjRVm1ro8tkB3 = 'src="/uploads/13721411411.png"  \n  ' + PfGSURJ9jeNtx7FX[0]
						PfGSURJ9jeNtx7FX = ffUFBJQ57j2XgoGeOLn9uwpC.findall('(src="/uploads/13721411411.png".*?href="http://moshahda\..*?/\w+.html".*?)<hr size="1" style="color:'+'#'+'333; background-color:'+'#'+'333" />.*?src="/uploads/13721411411.png"',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
						if PfGSURJ9jeNtx7FX: KdWauEhgN6OQzjRVm1ro8tkB3 = PfGSURJ9jeNtx7FX[0] + '  \n  src="/uploads/13721411411.png"'
						YVWgXSBnGbPdO = ffUFBJQ57j2XgoGeOLn9uwpC.findall('<(.*?)http://up.movizland.(online|com)/uploads/',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
						title = ffUFBJQ57j2XgoGeOLn9uwpC.findall('> *([^<>]+) *<',YVWgXSBnGbPdO[0][0],ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
						title = VBpIH2QSmvDGlA6TO3e.join(title)
						title = title.strip(VBpIH2QSmvDGlA6TO3e)
						title = title.replace(wr0HaqRdJ2D9LT7nSO1KMe38ly,VBpIH2QSmvDGlA6TO3e).replace(wr0HaqRdJ2D9LT7nSO1KMe38ly,VBpIH2QSmvDGlA6TO3e).replace(wr0HaqRdJ2D9LT7nSO1KMe38ly,VBpIH2QSmvDGlA6TO3e).replace(wr0HaqRdJ2D9LT7nSO1KMe38ly,VBpIH2QSmvDGlA6TO3e).replace(wr0HaqRdJ2D9LT7nSO1KMe38ly,VBpIH2QSmvDGlA6TO3e)
						ligKtjHbwBapq5n4oA9FUJESTfI8.append(title)
					AS6jLpMwW5Ql3kUFNfT = NAfHLMC8Ip64FmT7l5oJWXaq3hK('أختر الفيديو المطلوب:', ligKtjHbwBapq5n4oA9FUJESTfI8)
					if AS6jLpMwW5Ql3kUFNfT == -1 : return
					title = ligKtjHbwBapq5n4oA9FUJESTfI8[AS6jLpMwW5Ql3kUFNfT]
					KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[AS6jLpMwW5Ql3kUFNfT]
				c0cDhidBlOn7 = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(http://moshahda\..*?/\w+.html)"',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
				DDa5wg81BG = c0cDhidBlOn7[0]
				pcX7zxFRmsADwUr.append(DDa5wg81BG+'?named=Forum')
				KdWauEhgN6OQzjRVm1ro8tkB3 = KdWauEhgN6OQzjRVm1ro8tkB3.replace('ـ',cdZKMn68Pzg4)
				KdWauEhgN6OQzjRVm1ro8tkB3 = KdWauEhgN6OQzjRVm1ro8tkB3.replace('src="http://up.movizland.online/uploads/1517412175296.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="both"  \n  ')
				KdWauEhgN6OQzjRVm1ro8tkB3 = KdWauEhgN6OQzjRVm1ro8tkB3.replace('src="http://up.movizland.com/uploads/1517412175296.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="both"  \n  ')
				KdWauEhgN6OQzjRVm1ro8tkB3 = KdWauEhgN6OQzjRVm1ro8tkB3.replace('سيرفرات التحميل','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="download"  \n  ')
				KdWauEhgN6OQzjRVm1ro8tkB3 = KdWauEhgN6OQzjRVm1ro8tkB3.replace('روابط التحميل','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="download"  \n  ')
				KdWauEhgN6OQzjRVm1ro8tkB3 = KdWauEhgN6OQzjRVm1ro8tkB3.replace('سيرفرات المشاهد','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="watch"  \n  ')
				KdWauEhgN6OQzjRVm1ro8tkB3 = KdWauEhgN6OQzjRVm1ro8tkB3.replace('روابط المشاهد','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="watch"  \n  ')
				DD8021GpfJYvokWlBsF4nKqdth = ffUFBJQ57j2XgoGeOLn9uwpC.findall('(src="/uploads/13721411411.png".*?href="http://e5tsar.com/\d+".*?src="/uploads/13721411411.png")',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
				for hKuyJ3iaFto2ebs6Bx in DD8021GpfJYvokWlBsF4nKqdth:
					type = ffUFBJQ57j2XgoGeOLn9uwpC.findall(' typetype="(.*?)" ',hKuyJ3iaFto2ebs6Bx)
					if type:
						if type[0]!='both': type = '__'+type[0]
						else: type = cdZKMn68Pzg4
					items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('(?<!http://e5tsar.com/)(\w+[ \w]*</font>.*?|\w+[ \w]*<br />.*?)href="(http://e5tsar.com/.*?)"',hKuyJ3iaFto2ebs6Bx,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
					for KmC5IT0t7vx4kZSrRl,c0cDhidBlOn7 in items:
						title = ffUFBJQ57j2XgoGeOLn9uwpC.findall('(\w+[ \w]*)<',KmC5IT0t7vx4kZSrRl)
						title = title[-1]
						c0cDhidBlOn7 = c0cDhidBlOn7 + '?named=' + title + type
						pcX7zxFRmsADwUr.append(c0cDhidBlOn7)
	N8jUpQxY0rhtDAzbG4kOs9X = HOCWKhxITtulVGX.replace(cDTdfqVAF0BLGiX364IEwaZbr,Nl3Tz5nOPvLKqH7jJAVs1mF2r)
	OO1cj2REUZHJ8x5V = Gc05Efm73C8s(r43t1YI9deXA5N,N8jUpQxY0rhtDAzbG4kOs9X,cdZKMn68Pzg4,headers,cdZKMn68Pzg4,'MOVIZLAND-PLAY-3rd')
	items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('" href="(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if items:
		z4dZ2M1CjlvJaoH = items[-1]
		pcX7zxFRmsADwUr.append(z4dZ2M1CjlvJaoH+'?named=Mobile')
	import r0y4XTKznF
	r0y4XTKznF.noHliPXkcg3pJTdSauCvm5sU(pcX7zxFRmsADwUr,UkXlAzsMcamKJrEIgnxi6bWh,'video',url)
	return
def z4hetAJw3NaT9ROjG6xbZ5CHlW81(search):
	search,EL8zUgbXheot,showDialogs = qbIcHCMdkFKn21e(search)
	if search==cdZKMn68Pzg4: search = BzkmLuvJD9n25Pg()
	if search==cdZKMn68Pzg4: return
	search = search.replace(VBpIH2QSmvDGlA6TO3e,'+')
	OO1cj2REUZHJ8x5V = Gc05Efm73C8s(K8DZxE74Afz52gBYbOMtpvql0RJma,cDTdfqVAF0BLGiX364IEwaZbr,cdZKMn68Pzg4,headers,cdZKMn68Pzg4,'MOVIZLAND-SEARCH-1st')
	items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('<option value="(.*?)">(.*?)</option>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	lGC8g4caE0kOmiDoW6HQ = [ cdZKMn68Pzg4 ]
	zO2JkAuSjhP = [ 'الكل وبدون فلتر' ]
	for rrb0SF6otehufCYOX4,title in items:
		lGC8g4caE0kOmiDoW6HQ.append(rrb0SF6otehufCYOX4)
		zO2JkAuSjhP.append(title)
	if rrb0SF6otehufCYOX4:
		AS6jLpMwW5Ql3kUFNfT = NAfHLMC8Ip64FmT7l5oJWXaq3hK('اختر الفلتر المناسب:', zO2JkAuSjhP)
		if AS6jLpMwW5Ql3kUFNfT == -1 : return
		rrb0SF6otehufCYOX4 = lGC8g4caE0kOmiDoW6HQ[AS6jLpMwW5Ql3kUFNfT]
	else: rrb0SF6otehufCYOX4 = cdZKMn68Pzg4
	url = cDTdfqVAF0BLGiX364IEwaZbr + '/?s='+search+'&mcat='+rrb0SF6otehufCYOX4
	GDQUH4fN02sIt81mAcY(url)
	return
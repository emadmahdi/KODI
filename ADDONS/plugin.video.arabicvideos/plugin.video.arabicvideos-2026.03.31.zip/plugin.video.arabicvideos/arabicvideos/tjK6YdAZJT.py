# -*- coding: utf-8 -*-
from RgJNGc7YMP import *
LMihk2Vzl4DesIQ65TGmvxqcKdHp = 'IPTV'
XQgovGj6VkUFxH4a2 = '_IPT_'
zzSXPqifhs8rYnUvbMkuR26B7 = [
		 'IGNORED'
		,'LIVE_UNKNOWN_GROUPED','LIVE_UNKNOWN_GROUPED_SORTED'
		,'VOD_UNKNOWN_GROUPED','VOD_UNKNOWN_GROUPED_SORTED'
		,'LIVE_ARCHIVED_GROUPED_SORTED','LIVE_EPG_GROUPED_SORTED','LIVE_TIMESHIFT_GROUPED_SORTED'
		,'LIVE_GROUPED','LIVE_GROUPED_SORTED'
		,'LIVE_ORIGINAL_GROUPED','LIVE_FROM_GROUP_SORTED','LIVE_FROM_NAME_SORTED'
		,'VOD_MOVIES_GROUPED','VOD_MOVIES_GROUPED_SORTED'
		,'VOD_SERIES_GROUPED','VOD_SERIES_GROUPED_SORTED'
		,'VOD_ORIGINAL_GROUPED','VOD_FROM_GROUP_SORTED','VOD_FROM_NAME_SORTED'
		]
def ZZFUSgsGOhwdnX37V1TvatJomBMPW2(HHrpyfWjGC,kxY4EfTKobmQJ8OathHI53,JAYWBoz54tGw7O,kuMXTLrvIZGfjCDtA9YNJ5SxQK,iQBgv5oEbM6ZFH4U8qtC,RqmGlEdhA8z7M):
	global XQgovGj6VkUFxH4a2
	try:
		Vea0sXycdJ8LFSMzhB5Zt73u2rD = str(RqmGlEdhA8z7M['folder'])
		XQgovGj6VkUFxH4a2 = '_IP'+Vea0sXycdJ8LFSMzhB5Zt73u2rD+'_'
	except: Vea0sXycdJ8LFSMzhB5Zt73u2rD = cdZKMn68Pzg4
	if   HHrpyfWjGC==230: iiAOHkqYIRW7Bs46CEj3Layefb2hSP = WNcPHoazEr0h()
	elif HHrpyfWjGC==231: iiAOHkqYIRW7Bs46CEj3Layefb2hSP = S4msZ0wigOJREj3rolfqQGch(Vea0sXycdJ8LFSMzhB5Zt73u2rD)
	elif HHrpyfWjGC==232: iiAOHkqYIRW7Bs46CEj3Layefb2hSP = VEFIiuClxN6GjWzmpUsbTr4ekt(Vea0sXycdJ8LFSMzhB5Zt73u2rD)
	elif HHrpyfWjGC==233: iiAOHkqYIRW7Bs46CEj3Layefb2hSP = iBT7IHNAlEYDgsRthp3x9ynd(Vea0sXycdJ8LFSMzhB5Zt73u2rD,kxY4EfTKobmQJ8OathHI53,JAYWBoz54tGw7O,iQBgv5oEbM6ZFH4U8qtC)
	elif HHrpyfWjGC==234: iiAOHkqYIRW7Bs46CEj3Layefb2hSP = yKvktsG9BnHTge4fVuREIpm83(Vea0sXycdJ8LFSMzhB5Zt73u2rD,kxY4EfTKobmQJ8OathHI53,JAYWBoz54tGw7O,iQBgv5oEbM6ZFH4U8qtC)
	elif HHrpyfWjGC==235: iiAOHkqYIRW7Bs46CEj3Layefb2hSP = RPZbqous7rtdy56LeI18Cv04AKHW(Vea0sXycdJ8LFSMzhB5Zt73u2rD,kxY4EfTKobmQJ8OathHI53,kuMXTLrvIZGfjCDtA9YNJ5SxQK)
	elif HHrpyfWjGC==236: iiAOHkqYIRW7Bs46CEj3Layefb2hSP = hX7rFmcGbqlaER2xL(Vea0sXycdJ8LFSMzhB5Zt73u2rD,True)
	elif HHrpyfWjGC==237: iiAOHkqYIRW7Bs46CEj3Layefb2hSP = m4cprS5FuYxjRH3yiMVKhAqIU8(Vea0sXycdJ8LFSMzhB5Zt73u2rD,True)
	elif HHrpyfWjGC==238: iiAOHkqYIRW7Bs46CEj3Layefb2hSP = H5YObrSN4ZomGWidXpVtPKJ(Vea0sXycdJ8LFSMzhB5Zt73u2rD,kxY4EfTKobmQJ8OathHI53,JAYWBoz54tGw7O)
	elif HHrpyfWjGC==239: iiAOHkqYIRW7Bs46CEj3Layefb2hSP = pi7dszu648(JAYWBoz54tGw7O,Vea0sXycdJ8LFSMzhB5Zt73u2rD,kxY4EfTKobmQJ8OathHI53,iQBgv5oEbM6ZFH4U8qtC)
	elif HHrpyfWjGC==280: iiAOHkqYIRW7Bs46CEj3Layefb2hSP = U05YOSpxzrvlK6W8jPgce7qHbwysB(Vea0sXycdJ8LFSMzhB5Zt73u2rD,True)
	elif HHrpyfWjGC==281: iiAOHkqYIRW7Bs46CEj3Layefb2hSP = U2i5lhIGe8EmckoLY(Vea0sXycdJ8LFSMzhB5Zt73u2rD)
	elif HHrpyfWjGC==282: iiAOHkqYIRW7Bs46CEj3Layefb2hSP = jyripTCwLE0(Vea0sXycdJ8LFSMzhB5Zt73u2rD)
	elif HHrpyfWjGC==283: iiAOHkqYIRW7Bs46CEj3Layefb2hSP = BzSKH15l2PN8dgraGXxMj3tQ7Um(Vea0sXycdJ8LFSMzhB5Zt73u2rD)
	elif HHrpyfWjGC==285: iiAOHkqYIRW7Bs46CEj3Layefb2hSP = AAvHQpkS3dtIbaWxhioMc5mgKFwUE(Vea0sXycdJ8LFSMzhB5Zt73u2rD,kxY4EfTKobmQJ8OathHI53,JAYWBoz54tGw7O)
	elif HHrpyfWjGC==286: iiAOHkqYIRW7Bs46CEj3Layefb2hSP = Y2fWsBKEyhaNv7Pl9Xwej(Vea0sXycdJ8LFSMzhB5Zt73u2rD)
	elif HHrpyfWjGC==289: iiAOHkqYIRW7Bs46CEj3Layefb2hSP = LMejKcGP5p9QUkrFgqWAVivnNt6yoT(JAYWBoz54tGw7O,Vea0sXycdJ8LFSMzhB5Zt73u2rD,kxY4EfTKobmQJ8OathHI53,iQBgv5oEbM6ZFH4U8qtC)
	else: iiAOHkqYIRW7Bs46CEj3Layefb2hSP = False
	return iiAOHkqYIRW7Bs46CEj3Layefb2hSP
def WNcPHoazEr0h():
	for Vea0sXycdJ8LFSMzhB5Zt73u2rD in range(1,d37Zoe1YJgWbMq+1):
		XQgovGj6VkUFxH4a2 = '_IP'+str(Vea0sXycdJ8LFSMzhB5Zt73u2rD)+'_'
		zJLApFBcIhnSj('folder',XQgovGj6VkUFxH4a2+'قائمة مجلد '+G9Gz76P41qQAW2viUsjEymXYOVuBSc[Vea0sXycdJ8LFSMzhB5Zt73u2rD],cdZKMn68Pzg4,280,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,{'folder':Vea0sXycdJ8LFSMzhB5Zt73u2rD})
	return
def U05YOSpxzrvlK6W8jPgce7qHbwysB(Vea0sXycdJ8LFSMzhB5Zt73u2rD=cdZKMn68Pzg4,bUHVjvzwnyi=cdZKMn68Pzg4):
	if Vea0sXycdJ8LFSMzhB5Zt73u2rD:
		hWuidNS1px7vRMTao = {'folder':Vea0sXycdJ8LFSMzhB5Zt73u2rD}
		ZLQ8R02Aq7U1gKE = cdZKMn68Pzg4
	else:
		hWuidNS1px7vRMTao = cdZKMn68Pzg4
		ZLQ8R02Aq7U1gKE = cdZKMn68Pzg4
	SUJxjgp4ZDYT1fd0wz6RvEB8KiaAhm = Im36vznMobP7WCNfFY2lJZ(Vea0sXycdJ8LFSMzhB5Zt73u2rD,bUHVjvzwnyi)
	if not SUJxjgp4ZDYT1fd0wz6RvEB8KiaAhm:
		zJLApFBcIhnSj('link',XQgovGj6VkUFxH4a2+bxf7gZvNK29cEoiAIJlMq0dP+' إضافة أو تغيير اشتراك'+ZLQ8R02Aq7U1gKE+' '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,231,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,hWuidNS1px7vRMTao)
		zJLApFBcIhnSj('link',XQgovGj6VkUFxH4a2+bxf7gZvNK29cEoiAIJlMq0dP+' جلب ملفات'+ZLQ8R02Aq7U1gKE+' '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,232,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,hWuidNS1px7vRMTao)
		zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	else:
		zJLApFBcIhnSj('folder',XQgovGj6VkUFxH4a2+'بحث في الملفات'+ZLQ8R02Aq7U1gKE,cdZKMn68Pzg4,289,cdZKMn68Pzg4,cdZKMn68Pzg4,'_REMEMBERRESULTS_',cdZKMn68Pzg4,hWuidNS1px7vRMTao)
		zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
		zJLApFBcIhnSj('folder',XQgovGj6VkUFxH4a2+'قنوات بدون جلب ملفات','XTREAM_LIVE_GROUPS',285,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,hWuidNS1px7vRMTao)
		zJLApFBcIhnSj('folder',XQgovGj6VkUFxH4a2+'قنوات مصنفة مرتبة'+ZLQ8R02Aq7U1gKE,'LIVE_GROUPED_SORTED',233,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,hWuidNS1px7vRMTao)
		zJLApFBcIhnSj('folder',XQgovGj6VkUFxH4a2+'قنوات مصنفة من القسم'+ZLQ8R02Aq7U1gKE,'LIVE_FROM_GROUP_SORTED',233,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,hWuidNS1px7vRMTao)
		zJLApFBcIhnSj('folder',XQgovGj6VkUFxH4a2+'قنوات مصنفة من الاسم'+ZLQ8R02Aq7U1gKE,'LIVE_FROM_NAME_SORTED',233,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,hWuidNS1px7vRMTao)
		zJLApFBcIhnSj('folder',XQgovGj6VkUFxH4a2+'قنوات مصنفة بلا ترتيب'+ZLQ8R02Aq7U1gKE,'LIVE_GROUPED',233,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,hWuidNS1px7vRMTao)
		zJLApFBcIhnSj('folder',XQgovGj6VkUFxH4a2+'قنوات بلا ترتيب'+ZLQ8R02Aq7U1gKE,'LIVE_ORIGINAL_GROUPED',233,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,hWuidNS1px7vRMTao)
		zJLApFBcIhnSj('folder',XQgovGj6VkUFxH4a2+'قنوات مجهولة مرتبة'+ZLQ8R02Aq7U1gKE,'LIVE_UNKNOWN_GROUPED_SORTED',233,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,hWuidNS1px7vRMTao)
		zJLApFBcIhnSj('folder',XQgovGj6VkUFxH4a2+'قنوات مجهولة بلا ترتيب'+ZLQ8R02Aq7U1gKE,'LIVE_UNKNOWN_GROUPED',233,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,hWuidNS1px7vRMTao)
		zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
		zJLApFBcIhnSj('folder',XQgovGj6VkUFxH4a2+'أفلام بدون جلب ملفات','XTREAM_VOD_GROUPS',285,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,hWuidNS1px7vRMTao)
		zJLApFBcIhnSj('folder',XQgovGj6VkUFxH4a2+'أفلام مصنفة بلا ترتيب'+ZLQ8R02Aq7U1gKE,'VOD_MOVIES_GROUPED',233,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,hWuidNS1px7vRMTao)
		zJLApFBcIhnSj('folder',XQgovGj6VkUFxH4a2+'أفلام مصنفة مرتبة'+ZLQ8R02Aq7U1gKE,'VOD_MOVIES_GROUPED_SORTED',233,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,hWuidNS1px7vRMTao)
		zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
		zJLApFBcIhnSj('folder',XQgovGj6VkUFxH4a2+'مسلسلات بدون جلب ملفات','XTREAM_SERIES_GROUPS',285,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,hWuidNS1px7vRMTao)
		zJLApFBcIhnSj('folder',XQgovGj6VkUFxH4a2+'مسلسلات مصنفة بلا ترتيب'+ZLQ8R02Aq7U1gKE,'VOD_SERIES_GROUPED',233,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,hWuidNS1px7vRMTao)
		zJLApFBcIhnSj('folder',XQgovGj6VkUFxH4a2+'مسلسلات مصنفة مرتبة'+ZLQ8R02Aq7U1gKE,'VOD_SERIES_GROUPED_SORTED',233,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,hWuidNS1px7vRMTao)
		zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
		zJLApFBcIhnSj('folder',XQgovGj6VkUFxH4a2+'فيديوهات بلا ترتيب'+ZLQ8R02Aq7U1gKE,'VOD_ORIGINAL_GROUPED',233,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,hWuidNS1px7vRMTao)
		zJLApFBcIhnSj('folder',XQgovGj6VkUFxH4a2+'فيديوهات مصنفة من القسم'+ZLQ8R02Aq7U1gKE,'VOD_FROM_GROUP_SORTED',233,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,hWuidNS1px7vRMTao)
		zJLApFBcIhnSj('folder',XQgovGj6VkUFxH4a2+'فيديوهات مصنفة من الاسم'+ZLQ8R02Aq7U1gKE,'VOD_FROM_NAME_SORTED',233,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,hWuidNS1px7vRMTao)
		zJLApFBcIhnSj('folder',XQgovGj6VkUFxH4a2+'فيديوهات مجهولة بلا ترتيب'+ZLQ8R02Aq7U1gKE,'VOD_UNKNOWN_GROUPED',233,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,hWuidNS1px7vRMTao)
		zJLApFBcIhnSj('folder',XQgovGj6VkUFxH4a2+'فيديوهات مجهولة مرتبة'+ZLQ8R02Aq7U1gKE,'VOD_UNKNOWN_GROUPED_SORTED',233,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,hWuidNS1px7vRMTao)
		zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
		zJLApFBcIhnSj('folder',XQgovGj6VkUFxH4a2+'برامج القنوات (جدول فقط)'+ZLQ8R02Aq7U1gKE,'LIVE_EPG_GROUPED_SORTED',233,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,hWuidNS1px7vRMTao)
		zJLApFBcIhnSj('folder',XQgovGj6VkUFxH4a2+'أرشيف القنوات للأيام الماضية'+ZLQ8R02Aq7U1gKE,'LIVE_TIMESHIFT_GROUPED_SORTED',233,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,hWuidNS1px7vRMTao)
		zJLApFBcIhnSj('folder',XQgovGj6VkUFxH4a2+'أرشيف برامج القنوات للأيام الماضية'+ZLQ8R02Aq7U1gKE,'LIVE_ARCHIVED_GROUPED_SORTED',233,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,hWuidNS1px7vRMTao)
		zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	zJLApFBcIhnSj('link',XQgovGj6VkUFxH4a2+'إضافة أو تغيير اشتراك'+ZLQ8R02Aq7U1gKE,cdZKMn68Pzg4,231,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,hWuidNS1px7vRMTao)
	zJLApFBcIhnSj('link',XQgovGj6VkUFxH4a2+'جلب ملفات'+ZLQ8R02Aq7U1gKE,cdZKMn68Pzg4,232,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,hWuidNS1px7vRMTao)
	zJLApFBcIhnSj('link',XQgovGj6VkUFxH4a2+'مسح ملفات'+ZLQ8R02Aq7U1gKE,cdZKMn68Pzg4,237,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,hWuidNS1px7vRMTao)
	zJLApFBcIhnSj('link',XQgovGj6VkUFxH4a2+'فحص اشتراك'+ZLQ8R02Aq7U1gKE,cdZKMn68Pzg4,236,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,hWuidNS1px7vRMTao)
	zJLApFBcIhnSj('link',XQgovGj6VkUFxH4a2+'عدد فيديوهات'+ZLQ8R02Aq7U1gKE,cdZKMn68Pzg4,281,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,hWuidNS1px7vRMTao)
	zJLApFBcIhnSj('link',XQgovGj6VkUFxH4a2+'Referer تغيير'+ZLQ8R02Aq7U1gKE,cdZKMn68Pzg4,286,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,hWuidNS1px7vRMTao)
	zJLApFBcIhnSj('link',XQgovGj6VkUFxH4a2+'User-Agent تغيير'+ZLQ8R02Aq7U1gKE,cdZKMn68Pzg4,283,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,hWuidNS1px7vRMTao)
	zJLApFBcIhnSj('link',XQgovGj6VkUFxH4a2+'استخدم السيرفر الأسرع'+ZLQ8R02Aq7U1gKE,cdZKMn68Pzg4,282,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,hWuidNS1px7vRMTao)
	return
def hX7rFmcGbqlaER2xL(Vea0sXycdJ8LFSMzhB5Zt73u2rD,bUHVjvzwnyi=True):
	N4NMhSyT5mkwKZRY,r0VNJTaX5vOsme4 = False,cdZKMn68Pzg4
	XOSVmnLg957jiID0Q1RPlvpbkw,beE5JlkVDgdzro4y = cdZKMn68Pzg4,cdZKMn68Pzg4
	jcidYWSngJx2lphkZN7f5AqRu,AZnTKcDC0twiN2l6Fzxr3f,Szg3qvldoOyU,YsyfvFHASN,ww2AC3SkbFQXc6Pj = EEJjV7pU0Cy9RScBXefYh(Vea0sXycdJ8LFSMzhB5Zt73u2rD)
	if YsyfvFHASN==cdZKMn68Pzg4: return False,cdZKMn68Pzg4,cdZKMn68Pzg4
	pj3iPglDkueR29AH6U = lr845giTQzJ01vqZP(Vea0sXycdJ8LFSMzhB5Zt73u2rD)
	if jcidYWSngJx2lphkZN7f5AqRu:
		oyufnwWte9Im4cFA6hSLODiGRMsJx8 = e4qbrCQPyuMjpK(fS25N8gAZxpbnLi3srX7PJ,'GET',jcidYWSngJx2lphkZN7f5AqRu,cdZKMn68Pzg4,pj3iPglDkueR29AH6U,False,cdZKMn68Pzg4,'IPTV-CHECK_ACCOUNT-1st')
		ajEFui1BI6z8RJor = oyufnwWte9Im4cFA6hSLODiGRMsJx8.content
		if oyufnwWte9Im4cFA6hSLODiGRMsJx8.succeeded:
			P4OVJ8jvKxU,vbArRLplfGVWP6y3OU7ojI08YCm,N08BQ17ZlzrhHbjxEpFiYk,z2OrhTom1CB3t,fcJjuLIAyEgz7BRSFNpG = 0,0,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4
			try:
				ZUSphruPxENelqv0LY = lMeKd3hC6cmS('dict',ajEFui1BI6z8RJor)
				r0VNJTaX5vOsme4 = ZUSphruPxENelqv0LY['user_info']['status']
				N4NMhSyT5mkwKZRY = True
				N08BQ17ZlzrhHbjxEpFiYk = ZUSphruPxENelqv0LY['server_info']['time_now']
			except: pass
			if N08BQ17ZlzrhHbjxEpFiYk:
				try:
					C4wF1LSOhfRW6XqxajoyY3MGv2E = bD7kJZhMCdaqF68P45KlNIgO1.strptime(N08BQ17ZlzrhHbjxEpFiYk,'%Y.%m.%d %H:%M:%S')
					P4OVJ8jvKxU = int(bD7kJZhMCdaqF68P45KlNIgO1.mktime(C4wF1LSOhfRW6XqxajoyY3MGv2E))
					vbArRLplfGVWP6y3OU7ojI08YCm = int(BbIVuS4KecnqNvZz5GptR-P4OVJ8jvKxU)
					vbArRLplfGVWP6y3OU7ojI08YCm = int((vbArRLplfGVWP6y3OU7ojI08YCm+900)/1800)*1800
				except: pass
				try:
					C4wF1LSOhfRW6XqxajoyY3MGv2E = bD7kJZhMCdaqF68P45KlNIgO1.localtime(int(ZUSphruPxENelqv0LY['user_info']['created_at']))
					z2OrhTom1CB3t = bD7kJZhMCdaqF68P45KlNIgO1.strftime('%Y.%m.%d %H:%M:%S',C4wF1LSOhfRW6XqxajoyY3MGv2E)
				except: pass
				try:
					C4wF1LSOhfRW6XqxajoyY3MGv2E = bD7kJZhMCdaqF68P45KlNIgO1.localtime(int(ZUSphruPxENelqv0LY['user_info']['exp_date']))
					fcJjuLIAyEgz7BRSFNpG = bD7kJZhMCdaqF68P45KlNIgO1.strftime('%Y.%m.%d %H:%M:%S',C4wF1LSOhfRW6XqxajoyY3MGv2E)
				except: pass
			Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.setSetting('av.iptv.timestamp_'+Vea0sXycdJ8LFSMzhB5Zt73u2rD,str(BbIVuS4KecnqNvZz5GptR))
			Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.setSetting('av.iptv.timediff_'+Vea0sXycdJ8LFSMzhB5Zt73u2rD,str(vbArRLplfGVWP6y3OU7ojI08YCm))
			try:
				LobaZ0SMVqIPdjh = '"server_info":'+ajEFui1BI6z8RJor.split('"server_info":')[1]
				LobaZ0SMVqIPdjh = LobaZ0SMVqIPdjh.replace(':',': ').replace(',',', ').replace('}}','}')
				ObAlU5uZ8q3mCdfe = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"url": "(.*?)", "port": "(.*?)"',LobaZ0SMVqIPdjh,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
				XOSVmnLg957jiID0Q1RPlvpbkw,beE5JlkVDgdzro4y = ObAlU5uZ8q3mCdfe[0]
			except: N4NMhSyT5mkwKZRY = False
			if N4NMhSyT5mkwKZRY and bUHVjvzwnyi:
				max = ZUSphruPxENelqv0LY['user_info']['max_connections']
				QfiSpKj1MEAo0m6YTVHuFe5CzLhIJ = ZUSphruPxENelqv0LY['user_info']['active_cons']
				QUL43RiVeS2sJMoWAa0Ffc = ZUSphruPxENelqv0LY['user_info']['is_trial']
				vvJwlPDanH5FACTehcG1f = jcidYWSngJx2lphkZN7f5AqRu.split('?',1)
				KZ4oqDz5xgA2tkGcTaeQ1Lh3dp = 'URL:  '+Gzygq01Kcb9U3+jcidYWSngJx2lphkZN7f5AqRu+kH8E2zqNyims6KJfI
				KZ4oqDz5xgA2tkGcTaeQ1Lh3dp += '\n\nStatus:  '+Gzygq01Kcb9U3+r0VNJTaX5vOsme4+kH8E2zqNyims6KJfI
				KZ4oqDz5xgA2tkGcTaeQ1Lh3dp += '\nTrial:    '+Gzygq01Kcb9U3+str(QUL43RiVeS2sJMoWAa0Ffc=='1')+kH8E2zqNyims6KJfI
				KZ4oqDz5xgA2tkGcTaeQ1Lh3dp += '\nCreated  At:  '+Gzygq01Kcb9U3+z2OrhTom1CB3t+kH8E2zqNyims6KJfI
				KZ4oqDz5xgA2tkGcTaeQ1Lh3dp += '\nExpiry Date:  '+Gzygq01Kcb9U3+fcJjuLIAyEgz7BRSFNpG+kH8E2zqNyims6KJfI
				KZ4oqDz5xgA2tkGcTaeQ1Lh3dp += '\nConnections   ( Active / Maximum ) :  '+Gzygq01Kcb9U3+QfiSpKj1MEAo0m6YTVHuFe5CzLhIJ+' / '+max+kH8E2zqNyims6KJfI
				KZ4oqDz5xgA2tkGcTaeQ1Lh3dp += '\nAllowed Outputs:   '+Gzygq01Kcb9U3+" , ".join(ZUSphruPxENelqv0LY['user_info']['allowed_output_formats'])+kH8E2zqNyims6KJfI
				KZ4oqDz5xgA2tkGcTaeQ1Lh3dp += '\n\n'+LobaZ0SMVqIPdjh
				if r0VNJTaX5vOsme4=='Active': RMDqaKOvQCXghu81Gc('الاشتراك يعمل بدون مشاكل',KZ4oqDz5xgA2tkGcTaeQ1Lh3dp)
				else: RMDqaKOvQCXghu81Gc('يبدو أن هناك مشكلة في الاشتراك',KZ4oqDz5xgA2tkGcTaeQ1Lh3dp)
	if jcidYWSngJx2lphkZN7f5AqRu and N4NMhSyT5mkwKZRY and r0VNJTaX5vOsme4=='Active':
		SsziMZd5UbeL2NRxVpwjO(F0FeocLXmbJhdBwQnS18PCHZIU,'.\tChecking IPTV URL   [ IPTV account is OK ]   [ '+jcidYWSngJx2lphkZN7f5AqRu+' ]')
		RepGgckNqE = True
	else:
		SsziMZd5UbeL2NRxVpwjO(E7lrS9VXJF58d2NUAfkvxwjmHM,'Checking IPTV URL   [ Does not work ]   [ '+jcidYWSngJx2lphkZN7f5AqRu+' ]')
		if bUHVjvzwnyi: NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,'فحص اشتراك ـIPTV','رابط اشتراك ـIPTV الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـIPTV وقم بإضافة رابط ـIPTV جديد أو قم بإصلاح الرابط القديم')
		RepGgckNqE = False
	return RepGgckNqE,XOSVmnLg957jiID0Q1RPlvpbkw,beE5JlkVDgdzro4y
def yKvktsG9BnHTge4fVuREIpm83(Vea0sXycdJ8LFSMzhB5Zt73u2rD,MBHEOqmtX3SPb2whAFr6ul,k9U0ol3zPOiDyQ,SwDfU9qkrKo6QW2y,bUHVjvzwnyi=True):
	if not SwDfU9qkrKo6QW2y: SwDfU9qkrKo6QW2y = '1'
	if not Im36vznMobP7WCNfFY2lJZ(Vea0sXycdJ8LFSMzhB5Zt73u2rD,bUHVjvzwnyi): return
	RTr92nPJkjuBoDMbELV8Oa = wwATViQ0xDaoNMEK4v3PIeC8UzZ5(Vea0sXycdJ8LFSMzhB5Zt73u2rD,MBHEOqmtX3SPb2whAFr6ul)
	a2a0mpV49WBD5sIFYzU = sZHYrLPog4wmuW0ECdc(RTr92nPJkjuBoDMbELV8Oa,'list',MBHEOqmtX3SPb2whAFr6ul,k9U0ol3zPOiDyQ)
	ayzNrCUegfFI57jLp94K1ocED = int(SwDfU9qkrKo6QW2y)*100
	BpNo34OSb8fYgxJIA5c1sRvZ = ayzNrCUegfFI57jLp94K1ocED-100
	for SUkst0aLFhj,FghljxYu6ZiV7nCmtSUrywKDek,kxY4EfTKobmQJ8OathHI53,qsSTC3ZfW1NthKUbHQEnlpP9GY5 in a2a0mpV49WBD5sIFYzU[BpNo34OSb8fYgxJIA5c1sRvZ:ayzNrCUegfFI57jLp94K1ocED]:
		GXvW7eaHFjyiI6QUJ8brY9pKAs = ('GROUPED' in MBHEOqmtX3SPb2whAFr6ul or MBHEOqmtX3SPb2whAFr6ul=='ALL')
		esqA6aNSBjd5J = ('GROUPED' not in MBHEOqmtX3SPb2whAFr6ul and MBHEOqmtX3SPb2whAFr6ul!='ALL')
		if GXvW7eaHFjyiI6QUJ8brY9pKAs or esqA6aNSBjd5J:
			if   'ARCHIVED'  in MBHEOqmtX3SPb2whAFr6ul: USuRxnPlV5.menuItemsLIST.append(['folder',XQgovGj6VkUFxH4a2+FghljxYu6ZiV7nCmtSUrywKDek,kxY4EfTKobmQJ8OathHI53,238,qsSTC3ZfW1NthKUbHQEnlpP9GY5,cdZKMn68Pzg4,'ARCHIVED',cdZKMn68Pzg4,{'folder':Vea0sXycdJ8LFSMzhB5Zt73u2rD}])
			elif 'EPG' 		 in MBHEOqmtX3SPb2whAFr6ul: USuRxnPlV5.menuItemsLIST.append(['folder',XQgovGj6VkUFxH4a2+FghljxYu6ZiV7nCmtSUrywKDek,kxY4EfTKobmQJ8OathHI53,238,qsSTC3ZfW1NthKUbHQEnlpP9GY5,cdZKMn68Pzg4,'FULL_EPG',cdZKMn68Pzg4,{'folder':Vea0sXycdJ8LFSMzhB5Zt73u2rD}])
			elif 'TIMESHIFT' in MBHEOqmtX3SPb2whAFr6ul: USuRxnPlV5.menuItemsLIST.append(['folder',XQgovGj6VkUFxH4a2+FghljxYu6ZiV7nCmtSUrywKDek,kxY4EfTKobmQJ8OathHI53,238,qsSTC3ZfW1NthKUbHQEnlpP9GY5,cdZKMn68Pzg4,'TIMESHIFT',cdZKMn68Pzg4,{'folder':Vea0sXycdJ8LFSMzhB5Zt73u2rD}])
			elif 'LIVE' 	 in MBHEOqmtX3SPb2whAFr6ul: USuRxnPlV5.menuItemsLIST.append(['live',XQgovGj6VkUFxH4a2+FghljxYu6ZiV7nCmtSUrywKDek,kxY4EfTKobmQJ8OathHI53,235,qsSTC3ZfW1NthKUbHQEnlpP9GY5,cdZKMn68Pzg4,cdZKMn68Pzg4,SUkst0aLFhj,{'folder':Vea0sXycdJ8LFSMzhB5Zt73u2rD}])
			else: USuRxnPlV5.menuItemsLIST.append(['video',XQgovGj6VkUFxH4a2+FghljxYu6ZiV7nCmtSUrywKDek,kxY4EfTKobmQJ8OathHI53,235,qsSTC3ZfW1NthKUbHQEnlpP9GY5,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,{'folder':Vea0sXycdJ8LFSMzhB5Zt73u2rD}])
	om3XlN9aWpCnAEuYO = len(a2a0mpV49WBD5sIFYzU)
	BsewTaqSNkcuHhtf8pZvGVD7L(Vea0sXycdJ8LFSMzhB5Zt73u2rD,SwDfU9qkrKo6QW2y,MBHEOqmtX3SPb2whAFr6ul,234,om3XlN9aWpCnAEuYO,k9U0ol3zPOiDyQ)
	return
def Ky5oFjzA2ide4hJ1bk(H1oNZDLCh8gf9XeUlR3nwBS):
	zJLApFBcIhnSj('link',H1oNZDLCh8gf9XeUlR3nwBS+'هذه القائمة إما فارغة أو غير موجودة',cdZKMn68Pzg4,9999)
	zJLApFBcIhnSj('link',H1oNZDLCh8gf9XeUlR3nwBS+'أو الخدمة غير موجودة في اشتراكك',cdZKMn68Pzg4,9999)
	zJLApFBcIhnSj('link',H1oNZDLCh8gf9XeUlR3nwBS+'أو رابط IPTVـ الذي أنت أضفته غير صحيح',cdZKMn68Pzg4,9999)
	return
def iBT7IHNAlEYDgsRthp3x9ynd(Vea0sXycdJ8LFSMzhB5Zt73u2rD,MBHEOqmtX3SPb2whAFr6ul,k9U0ol3zPOiDyQ,SwDfU9qkrKo6QW2y,weTCh5tEVZQqy4D=cdZKMn68Pzg4,bUHVjvzwnyi=True):
	if not SwDfU9qkrKo6QW2y: SwDfU9qkrKo6QW2y = '1'
	H1oNZDLCh8gf9XeUlR3nwBS = XQgovGj6VkUFxH4a2
	if not Im36vznMobP7WCNfFY2lJZ(Vea0sXycdJ8LFSMzhB5Zt73u2rD,bUHVjvzwnyi): return False
	if '__SERIES__' in k9U0ol3zPOiDyQ: vn6PNIOb9XE0ycTVMlS,UJV1e2PfIrN0AGi = k9U0ol3zPOiDyQ.split('__SERIES__')
	else: vn6PNIOb9XE0ycTVMlS,UJV1e2PfIrN0AGi = k9U0ol3zPOiDyQ,cdZKMn68Pzg4
	RTr92nPJkjuBoDMbELV8Oa = wwATViQ0xDaoNMEK4v3PIeC8UzZ5(Vea0sXycdJ8LFSMzhB5Zt73u2rD,MBHEOqmtX3SPb2whAFr6ul)
	vq672jbXdaYK4CZxEFgu = sZHYrLPog4wmuW0ECdc(RTr92nPJkjuBoDMbELV8Oa,'list',MBHEOqmtX3SPb2whAFr6ul,'__GROUPS__')
	if not vq672jbXdaYK4CZxEFgu: return False
	iN21XgetQf5caGsFRwhCqWP = []
	for RRSaoMVs1BJdWNEpAP,qsSTC3ZfW1NthKUbHQEnlpP9GY5 in vq672jbXdaYK4CZxEFgu:
		if weTCh5tEVZQqy4D:
			if '__SERIES__' in RRSaoMVs1BJdWNEpAP: H1oNZDLCh8gf9XeUlR3nwBS = 'SERIES'
			elif '!!__UNKNOWN__!!' in RRSaoMVs1BJdWNEpAP: H1oNZDLCh8gf9XeUlR3nwBS = 'UNKNOWN'
			elif 'LIVE' in MBHEOqmtX3SPb2whAFr6ul: H1oNZDLCh8gf9XeUlR3nwBS = 'LIVE'
			else: H1oNZDLCh8gf9XeUlR3nwBS = 'VIDEOS'
			H1oNZDLCh8gf9XeUlR3nwBS = ','+Gzygq01Kcb9U3+H1oNZDLCh8gf9XeUlR3nwBS+': '+kH8E2zqNyims6KJfI
		if '__SERIES__' in RRSaoMVs1BJdWNEpAP: hewJPMkX2xfSCAgFlo5b,fHb7iXcpWT1U2sGCJY = RRSaoMVs1BJdWNEpAP.split('__SERIES__')
		else: hewJPMkX2xfSCAgFlo5b,fHb7iXcpWT1U2sGCJY = RRSaoMVs1BJdWNEpAP,cdZKMn68Pzg4
		if not k9U0ol3zPOiDyQ:
			if hewJPMkX2xfSCAgFlo5b in iN21XgetQf5caGsFRwhCqWP: continue
			iN21XgetQf5caGsFRwhCqWP.append(hewJPMkX2xfSCAgFlo5b)
			if 'RANDOM' in weTCh5tEVZQqy4D: zJLApFBcIhnSj('folder',H1oNZDLCh8gf9XeUlR3nwBS+hewJPMkX2xfSCAgFlo5b,MBHEOqmtX3SPb2whAFr6ul,167,cdZKMn68Pzg4,'1',RRSaoMVs1BJdWNEpAP,cdZKMn68Pzg4,{'folder':Vea0sXycdJ8LFSMzhB5Zt73u2rD})
			elif '__SERIES__' in RRSaoMVs1BJdWNEpAP: zJLApFBcIhnSj('folder',H1oNZDLCh8gf9XeUlR3nwBS+hewJPMkX2xfSCAgFlo5b,MBHEOqmtX3SPb2whAFr6ul,233,cdZKMn68Pzg4,'1',RRSaoMVs1BJdWNEpAP,cdZKMn68Pzg4,{'folder':Vea0sXycdJ8LFSMzhB5Zt73u2rD})
			else: zJLApFBcIhnSj('folder',H1oNZDLCh8gf9XeUlR3nwBS+hewJPMkX2xfSCAgFlo5b,MBHEOqmtX3SPb2whAFr6ul,234,cdZKMn68Pzg4,'1',RRSaoMVs1BJdWNEpAP,cdZKMn68Pzg4,{'folder':Vea0sXycdJ8LFSMzhB5Zt73u2rD})
		elif '__SERIES__' in RRSaoMVs1BJdWNEpAP and hewJPMkX2xfSCAgFlo5b==vn6PNIOb9XE0ycTVMlS:
			if fHb7iXcpWT1U2sGCJY in iN21XgetQf5caGsFRwhCqWP: continue
			iN21XgetQf5caGsFRwhCqWP.append(fHb7iXcpWT1U2sGCJY)
			if 'RANDOM' in weTCh5tEVZQqy4D: zJLApFBcIhnSj('folder',H1oNZDLCh8gf9XeUlR3nwBS+fHb7iXcpWT1U2sGCJY,MBHEOqmtX3SPb2whAFr6ul,167,cdZKMn68Pzg4,'1',RRSaoMVs1BJdWNEpAP,cdZKMn68Pzg4,{'folder':Vea0sXycdJ8LFSMzhB5Zt73u2rD})
			else: zJLApFBcIhnSj('folder',H1oNZDLCh8gf9XeUlR3nwBS+fHb7iXcpWT1U2sGCJY,MBHEOqmtX3SPb2whAFr6ul,234,qsSTC3ZfW1NthKUbHQEnlpP9GY5,'1',RRSaoMVs1BJdWNEpAP,cdZKMn68Pzg4,{'folder':Vea0sXycdJ8LFSMzhB5Zt73u2rD})
	USuRxnPlV5.menuItemsLIST[:] = sorted(USuRxnPlV5.menuItemsLIST,reverse=False,key=lambda D8QslnRP0KIkdYcbviAGTSEo7U69z: D8QslnRP0KIkdYcbviAGTSEo7U69z[1].lower())
	if not weTCh5tEVZQqy4D:
		ayzNrCUegfFI57jLp94K1ocED = int(SwDfU9qkrKo6QW2y)*100
		BpNo34OSb8fYgxJIA5c1sRvZ = ayzNrCUegfFI57jLp94K1ocED-100
		om3XlN9aWpCnAEuYO = len(USuRxnPlV5.menuItemsLIST)
		USuRxnPlV5.menuItemsLIST[:] = USuRxnPlV5.menuItemsLIST[BpNo34OSb8fYgxJIA5c1sRvZ:ayzNrCUegfFI57jLp94K1ocED]
		BsewTaqSNkcuHhtf8pZvGVD7L(Vea0sXycdJ8LFSMzhB5Zt73u2rD,SwDfU9qkrKo6QW2y,MBHEOqmtX3SPb2whAFr6ul,233,om3XlN9aWpCnAEuYO,k9U0ol3zPOiDyQ)
	return True
def H5YObrSN4ZomGWidXpVtPKJ(Vea0sXycdJ8LFSMzhB5Zt73u2rD,kxY4EfTKobmQJ8OathHI53,eeBfNX6GEZlyU5MLdCub1nAYrjv):
	if not Im36vznMobP7WCNfFY2lJZ(Vea0sXycdJ8LFSMzhB5Zt73u2rD,True): return
	pj3iPglDkueR29AH6U = lr845giTQzJ01vqZP(Vea0sXycdJ8LFSMzhB5Zt73u2rD)
	P4OVJ8jvKxU = Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.getSetting('av.iptv.timestamp_'+Vea0sXycdJ8LFSMzhB5Zt73u2rD)
	if not P4OVJ8jvKxU or BbIVuS4KecnqNvZz5GptR-int(P4OVJ8jvKxU)>24*lgZ9dofsL1JV5vQHTDS:
		RepGgckNqE,XOSVmnLg957jiID0Q1RPlvpbkw,beE5JlkVDgdzro4y = hX7rFmcGbqlaER2xL(Vea0sXycdJ8LFSMzhB5Zt73u2rD,False)
		if not RepGgckNqE: return
	vbArRLplfGVWP6y3OU7ojI08YCm = int(Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.getSetting('av.iptv.timediff_'+Vea0sXycdJ8LFSMzhB5Zt73u2rD))
	Szg3qvldoOyU = Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.getSetting('av.iptv.server_'+Vea0sXycdJ8LFSMzhB5Zt73u2rD)
	YsyfvFHASN = Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.getSetting('av.iptv.username_'+Vea0sXycdJ8LFSMzhB5Zt73u2rD)
	ww2AC3SkbFQXc6Pj = Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.getSetting('av.iptv.password_'+Vea0sXycdJ8LFSMzhB5Zt73u2rD)
	CESTGisrcgVOl = kxY4EfTKobmQJ8OathHI53.split(KCQExdbYFqM)
	vUjB2fqo7IJm1YyMhP4S0 = CESTGisrcgVOl[-1].replace('.ts',cdZKMn68Pzg4).replace('.m3u8',cdZKMn68Pzg4)
	if eeBfNX6GEZlyU5MLdCub1nAYrjv=='SHORT_EPG': VX6dUojJM9b4Il7 = 'get_short_epg'
	else: VX6dUojJM9b4Il7 = 'get_simple_data_table'
	jcidYWSngJx2lphkZN7f5AqRu,AZnTKcDC0twiN2l6Fzxr3f,Szg3qvldoOyU,YsyfvFHASN,ww2AC3SkbFQXc6Pj = EEJjV7pU0Cy9RScBXefYh(Vea0sXycdJ8LFSMzhB5Zt73u2rD)
	if not YsyfvFHASN: return
	sF4E5y9qwdB8pKveI0TVMn = jcidYWSngJx2lphkZN7f5AqRu+'&action='+VX6dUojJM9b4Il7+'&stream_id='+vUjB2fqo7IJm1YyMhP4S0
	ajEFui1BI6z8RJor = p1Y6cxNUTHaXlsh8(fS25N8gAZxpbnLi3srX7PJ,sF4E5y9qwdB8pKveI0TVMn,cdZKMn68Pzg4,pj3iPglDkueR29AH6U,cdZKMn68Pzg4,'IPTV-EPG_ITEMS-2nd')
	yyPXg6sSd3nOMqzkwGIZaVjD1NpBQ = lMeKd3hC6cmS('dict',ajEFui1BI6z8RJor)
	lv4UPKVMI1OiXy36 = yyPXg6sSd3nOMqzkwGIZaVjD1NpBQ['epg_listings']
	eo948RaukQNt7r = []
	if eeBfNX6GEZlyU5MLdCub1nAYrjv in ['ARCHIVED','TIMESHIFT']:
		for ZUSphruPxENelqv0LY in lv4UPKVMI1OiXy36:
			if ZUSphruPxENelqv0LY['has_archive']==1:
				eo948RaukQNt7r.append(ZUSphruPxENelqv0LY)
				if eeBfNX6GEZlyU5MLdCub1nAYrjv in ['TIMESHIFT']: break
		if not eo948RaukQNt7r: return
		zJLApFBcIhnSj('link',XQgovGj6VkUFxH4a2+Gzygq01Kcb9U3+'الملفات الأولي بهذه القائمة قد لا تعمل'+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
		if eeBfNX6GEZlyU5MLdCub1nAYrjv in ['TIMESHIFT']:
			M578Enu0x4UzdORyf = 2
			fdqGsHhbJn = M578Enu0x4UzdORyf*lgZ9dofsL1JV5vQHTDS
			eo948RaukQNt7r = []
			YJQ0LT7uyUI = int(int(ZUSphruPxENelqv0LY['start_timestamp'])/fdqGsHhbJn)*fdqGsHhbJn
			iLM6WcNQfKZ4 = BbIVuS4KecnqNvZz5GptR+fdqGsHhbJn
			OOH7JBcfUMz4CX = int((iLM6WcNQfKZ4-YJQ0LT7uyUI)/lgZ9dofsL1JV5vQHTDS)
			for ATg1dc5byeWvr6pVzBPF in range(OOH7JBcfUMz4CX):
				if ATg1dc5byeWvr6pVzBPF>=6:
					if ATg1dc5byeWvr6pVzBPF%M578Enu0x4UzdORyf!=0: continue
					TT4qsM7VWD8aIN9CnLhylF = fdqGsHhbJn
				else: TT4qsM7VWD8aIN9CnLhylF = fdqGsHhbJn//2
				OwfRnUWLKXmIN3BF = YJQ0LT7uyUI+ATg1dc5byeWvr6pVzBPF*lgZ9dofsL1JV5vQHTDS
				ZUSphruPxENelqv0LY = {}
				ZUSphruPxENelqv0LY['title'] = cdZKMn68Pzg4
				C4wF1LSOhfRW6XqxajoyY3MGv2E = bD7kJZhMCdaqF68P45KlNIgO1.localtime(OwfRnUWLKXmIN3BF-vbArRLplfGVWP6y3OU7ojI08YCm-lgZ9dofsL1JV5vQHTDS)
				ZUSphruPxENelqv0LY['start'] = bD7kJZhMCdaqF68P45KlNIgO1.strftime('%Y.%m.%d %H:%M:%S',C4wF1LSOhfRW6XqxajoyY3MGv2E)
				ZUSphruPxENelqv0LY['start_timestamp'] = str(OwfRnUWLKXmIN3BF)
				ZUSphruPxENelqv0LY['stop_timestamp'] = str(OwfRnUWLKXmIN3BF+TT4qsM7VWD8aIN9CnLhylF)
				eo948RaukQNt7r.append(ZUSphruPxENelqv0LY)
	elif eeBfNX6GEZlyU5MLdCub1nAYrjv in ['SHORT_EPG','FULL_EPG']: eo948RaukQNt7r = lv4UPKVMI1OiXy36
	if eeBfNX6GEZlyU5MLdCub1nAYrjv=='FULL_EPG' and len(eo948RaukQNt7r)>0:
		zJLApFBcIhnSj('link',XQgovGj6VkUFxH4a2+Gzygq01Kcb9U3+'هذه قائمة برامج القنوات (جدول فقط)ـ'+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	CqKjfNdvGBtQE5y = []
	qsSTC3ZfW1NthKUbHQEnlpP9GY5 = bu6LzUQF7K.getInfoLabel('ListItem.Icon')
	for ZUSphruPxENelqv0LY in eo948RaukQNt7r:
		FghljxYu6ZiV7nCmtSUrywKDek = abn2REWAS3FwTN0rlQmgOk.b64decode(ZUSphruPxENelqv0LY['title'])
		if W5domCu6XrQUFkiPpa3bNLtHglG: FghljxYu6ZiV7nCmtSUrywKDek = FghljxYu6ZiV7nCmtSUrywKDek.decode(vczMIlkCAh2u10B3)
		OwfRnUWLKXmIN3BF = int(ZUSphruPxENelqv0LY['start_timestamp'])
		ss8N32pCxIUekBM = int(ZUSphruPxENelqv0LY['stop_timestamp'])
		dvCwYeAugFhrV = str(int((ss8N32pCxIUekBM-OwfRnUWLKXmIN3BF+59)/60))
		Q1zM0pnwLTfl3sHA49RbtUahgmY8 = ZUSphruPxENelqv0LY['start'].replace(VBpIH2QSmvDGlA6TO3e,':')
		C4wF1LSOhfRW6XqxajoyY3MGv2E = bD7kJZhMCdaqF68P45KlNIgO1.localtime(OwfRnUWLKXmIN3BF-lgZ9dofsL1JV5vQHTDS)
		HmXAekGphtICY17gfKv0nib = bD7kJZhMCdaqF68P45KlNIgO1.strftime('%H:%M',C4wF1LSOhfRW6XqxajoyY3MGv2E)
		vAKTP51JReHz4Yf = bD7kJZhMCdaqF68P45KlNIgO1.strftime('%a',C4wF1LSOhfRW6XqxajoyY3MGv2E)
		if eeBfNX6GEZlyU5MLdCub1nAYrjv=='SHORT_EPG': FghljxYu6ZiV7nCmtSUrywKDek = bxf7gZvNK29cEoiAIJlMq0dP+HmXAekGphtICY17gfKv0nib+' ـ '+FghljxYu6ZiV7nCmtSUrywKDek+kH8E2zqNyims6KJfI
		elif eeBfNX6GEZlyU5MLdCub1nAYrjv=='TIMESHIFT': FghljxYu6ZiV7nCmtSUrywKDek = vAKTP51JReHz4Yf+VBpIH2QSmvDGlA6TO3e+HmXAekGphtICY17gfKv0nib+' ('+dvCwYeAugFhrV+'min)'
		else: FghljxYu6ZiV7nCmtSUrywKDek = vAKTP51JReHz4Yf+VBpIH2QSmvDGlA6TO3e+HmXAekGphtICY17gfKv0nib+' ('+dvCwYeAugFhrV+'min)   '+FghljxYu6ZiV7nCmtSUrywKDek+' ـ'
		if eeBfNX6GEZlyU5MLdCub1nAYrjv in ['ARCHIVED','FULL_EPG','TIMESHIFT']:
			MX8D1fxdbnFa = Szg3qvldoOyU+'/timeshift/'+YsyfvFHASN+KCQExdbYFqM+ww2AC3SkbFQXc6Pj+KCQExdbYFqM+dvCwYeAugFhrV+KCQExdbYFqM+Q1zM0pnwLTfl3sHA49RbtUahgmY8+KCQExdbYFqM+vUjB2fqo7IJm1YyMhP4S0+'.m3u8'
			if eeBfNX6GEZlyU5MLdCub1nAYrjv=='FULL_EPG': zJLApFBcIhnSj('link',XQgovGj6VkUFxH4a2+FghljxYu6ZiV7nCmtSUrywKDek,MX8D1fxdbnFa,9999,qsSTC3ZfW1NthKUbHQEnlpP9GY5,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,{'folder':Vea0sXycdJ8LFSMzhB5Zt73u2rD})
			else: zJLApFBcIhnSj('video',XQgovGj6VkUFxH4a2+FghljxYu6ZiV7nCmtSUrywKDek,MX8D1fxdbnFa,235,qsSTC3ZfW1NthKUbHQEnlpP9GY5,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,{'folder':Vea0sXycdJ8LFSMzhB5Zt73u2rD})
		CqKjfNdvGBtQE5y.append(FghljxYu6ZiV7nCmtSUrywKDek)
	if eeBfNX6GEZlyU5MLdCub1nAYrjv=='SHORT_EPG' and CqKjfNdvGBtQE5y: IQ0dKViyGxE = NcRbram3fy(CqKjfNdvGBtQE5y)
	return CqKjfNdvGBtQE5y
def jyripTCwLE0(Vea0sXycdJ8LFSMzhB5Zt73u2rD):
	if not Im36vznMobP7WCNfFY2lJZ(Vea0sXycdJ8LFSMzhB5Zt73u2rD,True): return
	Szg3qvldoOyU,zNWbDhltCB9SxE5KkYTyuaA,qCFMVt46f0lap3wgn = cdZKMn68Pzg4,0,0
	RepGgckNqE,XOSVmnLg957jiID0Q1RPlvpbkw,beE5JlkVDgdzro4y = hX7rFmcGbqlaER2xL(Vea0sXycdJ8LFSMzhB5Zt73u2rD,False)
	if RepGgckNqE:
		sRyMGxwU9HgDo7Pc = coTKUpHL9yaPF3b1S(XOSVmnLg957jiID0Q1RPlvpbkw)
		zNWbDhltCB9SxE5KkYTyuaA = zzb5DtLHap736(sRyMGxwU9HgDo7Pc[0],int(beE5JlkVDgdzro4y))
		RTr92nPJkjuBoDMbELV8Oa = wwATViQ0xDaoNMEK4v3PIeC8UzZ5(Vea0sXycdJ8LFSMzhB5Zt73u2rD,'LIVE_GROUPED')
		cY1DzUC9nxHgQM4BjIts = sZHYrLPog4wmuW0ECdc(RTr92nPJkjuBoDMbELV8Oa,'list','LIVE_GROUPED')
		a2a0mpV49WBD5sIFYzU = sZHYrLPog4wmuW0ECdc(RTr92nPJkjuBoDMbELV8Oa,'list','LIVE_GROUPED',cY1DzUC9nxHgQM4BjIts[1])
		kxY4EfTKobmQJ8OathHI53 = a2a0mpV49WBD5sIFYzU[0][2]
		Bg7U4Ptj5Aw = ffUFBJQ57j2XgoGeOLn9uwpC.findall('://(.*?)/',kxY4EfTKobmQJ8OathHI53,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		Bg7U4Ptj5Aw = Bg7U4Ptj5Aw[0]
		if ':' in Bg7U4Ptj5Aw: MnmU9NpO6eTzZW,fJ9R5nchWE = Bg7U4Ptj5Aw.split(':')
		else: MnmU9NpO6eTzZW,fJ9R5nchWE = Bg7U4Ptj5Aw,'80'
		DkUaLwqye4Qhd8TfV7nNuvEM = coTKUpHL9yaPF3b1S(MnmU9NpO6eTzZW)
		qCFMVt46f0lap3wgn = zzb5DtLHap736(DkUaLwqye4Qhd8TfV7nNuvEM[0],int(fJ9R5nchWE))
	if zNWbDhltCB9SxE5KkYTyuaA and qCFMVt46f0lap3wgn:
		KZ4oqDz5xgA2tkGcTaeQ1Lh3dp = 'هل تريد استخدام السيرفر الأصلي أم السيرفر الأسرع ؟!!'
		KZ4oqDz5xgA2tkGcTaeQ1Lh3dp += '\n\n'+'وقت ضائع في السيرفر الأصلي'+ssELJkeScrtni2+str(int(qCFMVt46f0lap3wgn*1000))+' ملي ثانية'
		KZ4oqDz5xgA2tkGcTaeQ1Lh3dp += '\n\n'+'وقت ضائع في السيرفر البديل'+ssELJkeScrtni2+str(int(zNWbDhltCB9SxE5KkYTyuaA*1000))+' ملي ثانية'
		GPQCWezyxpbjhHNXMVEaI4FR = JyLdvftP3CU('center','السيرفر الأصلي','السيرفر الأسرع',OPEJxmUqr9wAX1i,KZ4oqDz5xgA2tkGcTaeQ1Lh3dp)
		if GPQCWezyxpbjhHNXMVEaI4FR==1 and zNWbDhltCB9SxE5KkYTyuaA<qCFMVt46f0lap3wgn: Szg3qvldoOyU = XOSVmnLg957jiID0Q1RPlvpbkw+':'+beE5JlkVDgdzro4y
	else: NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,'البرنامج لم يجد السيرفر البديل')
	Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.setSetting('av.iptv.server_'+Vea0sXycdJ8LFSMzhB5Zt73u2rD,Szg3qvldoOyU)
	return
def RPZbqous7rtdy56LeI18Cv04AKHW(Vea0sXycdJ8LFSMzhB5Zt73u2rD,kxY4EfTKobmQJ8OathHI53,kuMXTLrvIZGfjCDtA9YNJ5SxQK):
	J8wUvxLd7kNoGf4pY1XCn = Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.getSetting('av.iptv.useragent_'+Vea0sXycdJ8LFSMzhB5Zt73u2rD)
	ITXKP0wLvFMQ9Niq6ctH8 = Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.getSetting('av.iptv.referer_'+Vea0sXycdJ8LFSMzhB5Zt73u2rD)
	if J8wUvxLd7kNoGf4pY1XCn or ITXKP0wLvFMQ9Niq6ctH8:
		kxY4EfTKobmQJ8OathHI53 += '|'
		if J8wUvxLd7kNoGf4pY1XCn: kxY4EfTKobmQJ8OathHI53 += '&User-Agent='+J8wUvxLd7kNoGf4pY1XCn
		if ITXKP0wLvFMQ9Niq6ctH8: kxY4EfTKobmQJ8OathHI53 += '&Referer='+ITXKP0wLvFMQ9Niq6ctH8
		kxY4EfTKobmQJ8OathHI53 = kxY4EfTKobmQJ8OathHI53.replace('|&','|')
	jHfsIYCpMd6QXZJhF5tkO3 = Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.getSetting('av.iptv.server_'+Vea0sXycdJ8LFSMzhB5Zt73u2rD)
	if jHfsIYCpMd6QXZJhF5tkO3:
		G0oAfM4cpBHFJY = ffUFBJQ57j2XgoGeOLn9uwpC.findall('://(.*?)/',kxY4EfTKobmQJ8OathHI53,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		kxY4EfTKobmQJ8OathHI53 = kxY4EfTKobmQJ8OathHI53.replace(G0oAfM4cpBHFJY[0],jHfsIYCpMd6QXZJhF5tkO3)
	bmgwWLk3er(kxY4EfTKobmQJ8OathHI53,LMihk2Vzl4DesIQ65TGmvxqcKdHp,kuMXTLrvIZGfjCDtA9YNJ5SxQK)
	return
def BzSKH15l2PN8dgraGXxMj3tQ7Um(Vea0sXycdJ8LFSMzhB5Zt73u2rD):
	NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,'تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـIPTV أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـIPTV تحتاج ـUser-Agent خاص')
	J8wUvxLd7kNoGf4pY1XCn = Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.getSetting('av.iptv.useragent_'+Vea0sXycdJ8LFSMzhB5Zt73u2rD)
	i2Q8cvOzsg9wkVDUYNyo5ZplA1 = JyLdvftP3CU('center','استخدام الأصلي','تعديل القديم',J8wUvxLd7kNoGf4pY1XCn,'هذا هو ـUser-Agent المستخدم حاليا مع ـIPTV الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـIPTV ؟!')
	if i2Q8cvOzsg9wkVDUYNyo5ZplA1==1: J8wUvxLd7kNoGf4pY1XCn = BzkmLuvJD9n25Pg('أكتب ـIPTV User-Agent جديد',J8wUvxLd7kNoGf4pY1XCn,True)
	else: J8wUvxLd7kNoGf4pY1XCn = 'Unknown'
	if J8wUvxLd7kNoGf4pY1XCn==VBpIH2QSmvDGlA6TO3e:
		NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,'غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	i2Q8cvOzsg9wkVDUYNyo5ZplA1 = JyLdvftP3CU('center',cdZKMn68Pzg4,cdZKMn68Pzg4,J8wUvxLd7kNoGf4pY1XCn,'هل تريد استخدام هذا ـUser-Agent بدلا من  القديم ؟')
	if i2Q8cvOzsg9wkVDUYNyo5ZplA1!=1:
		NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,'تم الإلغاء')
		return
	Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.setSetting('av.iptv.useragent_'+Vea0sXycdJ8LFSMzhB5Zt73u2rD,J8wUvxLd7kNoGf4pY1XCn)
	SYaTv4t7q0cy96(Vea0sXycdJ8LFSMzhB5Zt73u2rD)
	return
def Y2fWsBKEyhaNv7Pl9Xwej(Vea0sXycdJ8LFSMzhB5Zt73u2rD):
	NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,'تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـIPTV أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـIPTV تحتاج ـReferer خاص')
	ITXKP0wLvFMQ9Niq6ctH8 = Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.getSetting('av.iptv.referer_'+Vea0sXycdJ8LFSMzhB5Zt73u2rD)
	i2Q8cvOzsg9wkVDUYNyo5ZplA1 = JyLdvftP3CU('center','استخدام الأصلي','تعديل القديم',ITXKP0wLvFMQ9Niq6ctH8,'هذا هو ـReferer المستخدم حاليا مع ـIPTV الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـIPTV ؟!')
	if i2Q8cvOzsg9wkVDUYNyo5ZplA1==1: ITXKP0wLvFMQ9Niq6ctH8 = BzkmLuvJD9n25Pg('أكتب ـIPTV Referer جديد',ITXKP0wLvFMQ9Niq6ctH8,True)
	else: ITXKP0wLvFMQ9Niq6ctH8 = cdZKMn68Pzg4
	if ITXKP0wLvFMQ9Niq6ctH8==VBpIH2QSmvDGlA6TO3e:
		NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,'غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	i2Q8cvOzsg9wkVDUYNyo5ZplA1 = JyLdvftP3CU('center',cdZKMn68Pzg4,cdZKMn68Pzg4,ITXKP0wLvFMQ9Niq6ctH8,'هل تريد استخدام هذا ـReferer بدلا من  القديم ؟')
	if i2Q8cvOzsg9wkVDUYNyo5ZplA1!=1:
		NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,'تم الإلغاء')
		return
	Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.setSetting('av.iptv.referer_'+Vea0sXycdJ8LFSMzhB5Zt73u2rD,ITXKP0wLvFMQ9Niq6ctH8)
	SYaTv4t7q0cy96(Vea0sXycdJ8LFSMzhB5Zt73u2rD)
	return
def EEJjV7pU0Cy9RScBXefYh(Vea0sXycdJ8LFSMzhB5Zt73u2rD,JuaRl8wLhzgQHjP=cdZKMn68Pzg4):
	if not JuaRl8wLhzgQHjP: JuaRl8wLhzgQHjP = Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.getSetting('av.iptv.url_'+Vea0sXycdJ8LFSMzhB5Zt73u2rD)
	Szg3qvldoOyU = CxlbPZwGTcH87e1sWhfSIz29uRUEpV(JuaRl8wLhzgQHjP,'url')
	YsyfvFHASN = ffUFBJQ57j2XgoGeOLn9uwpC.findall('username=(.*?)&',JuaRl8wLhzgQHjP+'&',ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	ww2AC3SkbFQXc6Pj = ffUFBJQ57j2XgoGeOLn9uwpC.findall('password=(.*?)&',JuaRl8wLhzgQHjP+'&',ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if not YsyfvFHASN or not ww2AC3SkbFQXc6Pj:
		NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,'فحص اشتراك ـIPTV','رابط اشتراك ـIPTV الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـIPTV وقم بإضافة رابط ـIPTV جديد أو قم بإصلاح الرابط القديم')
		return cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4
	YsyfvFHASN = YsyfvFHASN[0]
	ww2AC3SkbFQXc6Pj = ww2AC3SkbFQXc6Pj[0]
	jcidYWSngJx2lphkZN7f5AqRu = Szg3qvldoOyU+'/player_api.php?username='+YsyfvFHASN+'&password='+ww2AC3SkbFQXc6Pj
	AZnTKcDC0twiN2l6Fzxr3f = Szg3qvldoOyU+'/get.php?username='+YsyfvFHASN+'&password='+ww2AC3SkbFQXc6Pj+'&type=m3u_plus'
	return jcidYWSngJx2lphkZN7f5AqRu,AZnTKcDC0twiN2l6Fzxr3f,Szg3qvldoOyU,YsyfvFHASN,ww2AC3SkbFQXc6Pj
def sC6JUuF3LSOy8(Vea0sXycdJ8LFSMzhB5Zt73u2rD,KZV2X1pyHqe9Yjtcr8QCxi=cdZKMn68Pzg4):
	A2vi5PFs9t7OU = KZV2X1pyHqe9Yjtcr8QCxi.replace(KCQExdbYFqM,'_').replace(':','_').replace('.','_')
	A2vi5PFs9t7OU = A2vi5PFs9t7OU.replace('?','_').replace('=','_').replace('&','_')
	A2vi5PFs9t7OU = YRESXadfbIy3khwqmL8WC.path.join(qq9xw1jKIVH5kuNGMsPLiCO6Rp0Zv,A2vi5PFs9t7OU).strip('.m3u')+'.m3u'
	return A2vi5PFs9t7OU
def S4msZ0wigOJREj3rolfqQGch(Vea0sXycdJ8LFSMzhB5Zt73u2rD):
	I4u3Rmh0Bd5j9GHNDQnsXt2 = Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.getSetting('av.iptv.url_'+Vea0sXycdJ8LFSMzhB5Zt73u2rD)
	HGCwXOKctZBSqzV9a614 = True
	if I4u3Rmh0Bd5j9GHNDQnsXt2:
		i2Q8cvOzsg9wkVDUYNyo5ZplA1 = UN8rA03xkWLCGzebyEoF9YDRKBwSMO('center','كتابة جديد','تعديل القديم','مسح القديم','الرابط الحالي هو:',Gzygq01Kcb9U3+I4u3Rmh0Bd5j9GHNDQnsXt2+kH8E2zqNyims6KJfI+'\n\n هذا هو رابط ـIPTV المسجل في البرنامج ... هل تريد تعديله أم تريد كتابة رابط جديد ؟!')
		if i2Q8cvOzsg9wkVDUYNyo5ZplA1==-1: return
		elif i2Q8cvOzsg9wkVDUYNyo5ZplA1==0: I4u3Rmh0Bd5j9GHNDQnsXt2 = cdZKMn68Pzg4
		elif i2Q8cvOzsg9wkVDUYNyo5ZplA1==2:
			i2Q8cvOzsg9wkVDUYNyo5ZplA1 = JyLdvftP3CU('center',cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,'هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if i2Q8cvOzsg9wkVDUYNyo5ZplA1 in [-1,0]: return
			NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,'تم مسح الرابط')
			HGCwXOKctZBSqzV9a614 = False
			eu9I0Al8sXOwQPWaMJ4dog7Tjz2ZKi = cdZKMn68Pzg4
	if HGCwXOKctZBSqzV9a614:
		eu9I0Al8sXOwQPWaMJ4dog7Tjz2ZKi = BzkmLuvJD9n25Pg('اكتب رابط ـIPTV كاملا',I4u3Rmh0Bd5j9GHNDQnsXt2)
		eu9I0Al8sXOwQPWaMJ4dog7Tjz2ZKi = eu9I0Al8sXOwQPWaMJ4dog7Tjz2ZKi.strip(VBpIH2QSmvDGlA6TO3e)
		if not eu9I0Al8sXOwQPWaMJ4dog7Tjz2ZKi:
			i2Q8cvOzsg9wkVDUYNyo5ZplA1 = JyLdvftP3CU('center',cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,'لقد قمت بإدخال رابط فارغ .. هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if i2Q8cvOzsg9wkVDUYNyo5ZplA1 in [-1,0]: return
			NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,'تم مسح الرابط')
	else:
		jcidYWSngJx2lphkZN7f5AqRu,AZnTKcDC0twiN2l6Fzxr3f,Szg3qvldoOyU,YsyfvFHASN,ww2AC3SkbFQXc6Pj = EEJjV7pU0Cy9RScBXefYh(Vea0sXycdJ8LFSMzhB5Zt73u2rD,eu9I0Al8sXOwQPWaMJ4dog7Tjz2ZKi)
		if not YsyfvFHASN: return
		KZ4oqDz5xgA2tkGcTaeQ1Lh3dp = 'هذه المعلومات تم أخذها من رابط ـIPTV الذي انت كتبته . هل تريد استخدامها ؟!\n'
		KZ4oqDz5xgA2tkGcTaeQ1Lh3dp += ssELJkeScrtni2+bxf7gZvNK29cEoiAIJlMq0dP+Szg3qvldoOyU+kH8E2zqNyims6KJfI+'عنوان السيرفر: '
		KZ4oqDz5xgA2tkGcTaeQ1Lh3dp += ssELJkeScrtni2+bxf7gZvNK29cEoiAIJlMq0dP+YsyfvFHASN+kH8E2zqNyims6KJfI+'اسم المستخدم: '
		KZ4oqDz5xgA2tkGcTaeQ1Lh3dp += ssELJkeScrtni2+bxf7gZvNK29cEoiAIJlMq0dP+yy6Oei8IP1sgfMh4CckLlK++'كلمة السر: '
		i2Q8cvOzsg9wkVDUYNyo5ZplA1 = JyLdvftP3CU('right',cdZKMn68Pzg4,cdZKMn68Pzg4,'الرابط الجديد هو:',Gzygq01Kcb9U3+eu9I0Al8sXOwQPWaMJ4dog7Tjz2ZKi+kH8E2zqNyims6KJfI+'\n\n'+KZ4oqDz5xgA2tkGcTaeQ1Lh3dp)
		if i2Q8cvOzsg9wkVDUYNyo5ZplA1!=1:
			NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,'تم الإلغاء')
			return
	Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.setSetting('av.iptv.url_'+Vea0sXycdJ8LFSMzhB5Zt73u2rD,eu9I0Al8sXOwQPWaMJ4dog7Tjz2ZKi)
	Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.setSetting('av.iptv.timestamp_'+Vea0sXycdJ8LFSMzhB5Zt73u2rD,cdZKMn68Pzg4)
	Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.setSetting('av.iptv.timediff_'+Vea0sXycdJ8LFSMzhB5Zt73u2rD,cdZKMn68Pzg4)
	J8wUvxLd7kNoGf4pY1XCn = Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.getSetting('av.iptv.useragent_'+Vea0sXycdJ8LFSMzhB5Zt73u2rD)
	if not J8wUvxLd7kNoGf4pY1XCn: Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.setSetting('av.iptv.useragent_'+Vea0sXycdJ8LFSMzhB5Zt73u2rD,'Unknown')
	Jje2IVCX1AWduswkKhBr7DfNcy4n = JyLdvftP3CU('center',cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,eu9I0Al8sXOwQPWaMJ4dog7Tjz2ZKi+'\n\nتم تغير رابط اشتراك ـIPTV إلى هذا الرابط الجديد ... هل تريد فحص هذا الرابط الآن ؟')
	if Jje2IVCX1AWduswkKhBr7DfNcy4n==1: RepGgckNqE,XOSVmnLg957jiID0Q1RPlvpbkw,beE5JlkVDgdzro4y = hX7rFmcGbqlaER2xL(Vea0sXycdJ8LFSMzhB5Zt73u2rD,True)
	SYaTv4t7q0cy96(Vea0sXycdJ8LFSMzhB5Zt73u2rD)
	return
def KJEI4tXxRaAzPWojcQuLB9k(oPs342UIN6ieO9BVJWZpfXE,DVEcs2ShJgRT,ZpPvIGFq91fzMk64Q7OyNdD5wbL,KGdsq9fgW31RcXomzCxrea,eB76azgblwARsQINn,zqj2ltB4agIQVifTWcxX7nC,AZnTKcDC0twiN2l6Fzxr3f):
	a2a0mpV49WBD5sIFYzU,r0YlJFfeCZaokWS51 = [],[]
	nnALmwq9OGxj20UJd = ['.avi','.mp4','.mkv','.mp3','.webm','.aac']
	for uvjQ0YydJMPkbGeg8I3FUslAW in oPs342UIN6ieO9BVJWZpfXE:
		if zqj2ltB4agIQVifTWcxX7nC%473==0:
			x3G0I9vUCjg(KGdsq9fgW31RcXomzCxrea,40+int(10*zqj2ltB4agIQVifTWcxX7nC/eB76azgblwARsQINn),'قراءة الفيديوهات','الفيديو رقم:-',str(zqj2ltB4agIQVifTWcxX7nC)+' / '+str(eB76azgblwARsQINn))
			if KGdsq9fgW31RcXomzCxrea.iscanceled():
				KGdsq9fgW31RcXomzCxrea.close()
				return None,None,None
		kxY4EfTKobmQJ8OathHI53 = ffUFBJQ57j2XgoGeOLn9uwpC.findall('^(.*?)\n+((http|https|rtmp).*?)$',uvjQ0YydJMPkbGeg8I3FUslAW,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if kxY4EfTKobmQJ8OathHI53:
			uvjQ0YydJMPkbGeg8I3FUslAW,kxY4EfTKobmQJ8OathHI53,ZsOUtP3XGW0Mgexzofd9YkFb56S4rE = kxY4EfTKobmQJ8OathHI53[0]
			kxY4EfTKobmQJ8OathHI53 = kxY4EfTKobmQJ8OathHI53.replace(ssELJkeScrtni2,cdZKMn68Pzg4)
			uvjQ0YydJMPkbGeg8I3FUslAW = uvjQ0YydJMPkbGeg8I3FUslAW.replace(ssELJkeScrtni2,cdZKMn68Pzg4)
		else:
			r0YlJFfeCZaokWS51.append({'line':uvjQ0YydJMPkbGeg8I3FUslAW})
			continue
		Oyc53409UnEIwbB,SUkst0aLFhj,RRSaoMVs1BJdWNEpAP,FghljxYu6ZiV7nCmtSUrywKDek,kuMXTLrvIZGfjCDtA9YNJ5SxQK,bSEjHFX1aun5kox = {},cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,False
		try:
			uvjQ0YydJMPkbGeg8I3FUslAW,FghljxYu6ZiV7nCmtSUrywKDek = uvjQ0YydJMPkbGeg8I3FUslAW.rsplit('",',1)
			uvjQ0YydJMPkbGeg8I3FUslAW = uvjQ0YydJMPkbGeg8I3FUslAW+'"'
		except:
			try: uvjQ0YydJMPkbGeg8I3FUslAW,FghljxYu6ZiV7nCmtSUrywKDek = uvjQ0YydJMPkbGeg8I3FUslAW.rsplit('1,',1)
			except: FghljxYu6ZiV7nCmtSUrywKDek = cdZKMn68Pzg4
		Oyc53409UnEIwbB['url'] = kxY4EfTKobmQJ8OathHI53
		pIm3onk0V6GE4H5QzTrD = ffUFBJQ57j2XgoGeOLn9uwpC.findall(' (.*?)="(.*?)"',uvjQ0YydJMPkbGeg8I3FUslAW,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for D8QslnRP0KIkdYcbviAGTSEo7U69z,bK9NATPpaXoZB6MC in pIm3onk0V6GE4H5QzTrD:
			D8QslnRP0KIkdYcbviAGTSEo7U69z = D8QslnRP0KIkdYcbviAGTSEo7U69z.replace('"',cdZKMn68Pzg4).strip(VBpIH2QSmvDGlA6TO3e)
			Oyc53409UnEIwbB[D8QslnRP0KIkdYcbviAGTSEo7U69z] = bK9NATPpaXoZB6MC.strip(VBpIH2QSmvDGlA6TO3e)
		KnyNSkJH0OzQ = list(Oyc53409UnEIwbB.keys())
		if not FghljxYu6ZiV7nCmtSUrywKDek:
			if 'name' in KnyNSkJH0OzQ and Oyc53409UnEIwbB['name']: FghljxYu6ZiV7nCmtSUrywKDek = Oyc53409UnEIwbB['name']
		Oyc53409UnEIwbB['title'] = FghljxYu6ZiV7nCmtSUrywKDek.strip(VBpIH2QSmvDGlA6TO3e).replace(wr0HaqRdJ2D9LT7nSO1KMe38ly,VBpIH2QSmvDGlA6TO3e).replace(wr0HaqRdJ2D9LT7nSO1KMe38ly,VBpIH2QSmvDGlA6TO3e)
		if 'logo' in KnyNSkJH0OzQ:
			Oyc53409UnEIwbB['img'] = Oyc53409UnEIwbB['logo']
			del Oyc53409UnEIwbB['logo']
		else: Oyc53409UnEIwbB['img'] = cdZKMn68Pzg4
		if 'group' in KnyNSkJH0OzQ and Oyc53409UnEIwbB['group']: RRSaoMVs1BJdWNEpAP = Oyc53409UnEIwbB['group']
		if any(value in kxY4EfTKobmQJ8OathHI53.lower() for value in nnALmwq9OGxj20UJd):
			bSEjHFX1aun5kox = True if 'm3u' not in kxY4EfTKobmQJ8OathHI53 else False
		if bSEjHFX1aun5kox or '__SERIES__' in RRSaoMVs1BJdWNEpAP or '__MOVIES__' in RRSaoMVs1BJdWNEpAP:
			kuMXTLrvIZGfjCDtA9YNJ5SxQK = 'VOD'
			if '__SERIES__' in RRSaoMVs1BJdWNEpAP: kuMXTLrvIZGfjCDtA9YNJ5SxQK = kuMXTLrvIZGfjCDtA9YNJ5SxQK+'_SERIES'
			elif '__MOVIES__' in RRSaoMVs1BJdWNEpAP: kuMXTLrvIZGfjCDtA9YNJ5SxQK = kuMXTLrvIZGfjCDtA9YNJ5SxQK+'_MOVIES'
			else: kuMXTLrvIZGfjCDtA9YNJ5SxQK = kuMXTLrvIZGfjCDtA9YNJ5SxQK+'_UNKNOWN'
			RRSaoMVs1BJdWNEpAP = RRSaoMVs1BJdWNEpAP.replace('__SERIES__',cdZKMn68Pzg4).replace('__MOVIES__',cdZKMn68Pzg4)
		else:
			kuMXTLrvIZGfjCDtA9YNJ5SxQK = 'LIVE'
			if FghljxYu6ZiV7nCmtSUrywKDek in DVEcs2ShJgRT: SUkst0aLFhj = SUkst0aLFhj+'_EPG'
			if FghljxYu6ZiV7nCmtSUrywKDek in ZpPvIGFq91fzMk64Q7OyNdD5wbL: SUkst0aLFhj = SUkst0aLFhj+'_ARCHIVED'
			if not RRSaoMVs1BJdWNEpAP: kuMXTLrvIZGfjCDtA9YNJ5SxQK = kuMXTLrvIZGfjCDtA9YNJ5SxQK+'_UNKNOWN'
			else: kuMXTLrvIZGfjCDtA9YNJ5SxQK = kuMXTLrvIZGfjCDtA9YNJ5SxQK+SUkst0aLFhj
		RRSaoMVs1BJdWNEpAP = RRSaoMVs1BJdWNEpAP.strip(VBpIH2QSmvDGlA6TO3e).replace(wr0HaqRdJ2D9LT7nSO1KMe38ly,VBpIH2QSmvDGlA6TO3e).replace(wr0HaqRdJ2D9LT7nSO1KMe38ly,VBpIH2QSmvDGlA6TO3e)
		if 'LIVE_UNKNOWN' in kuMXTLrvIZGfjCDtA9YNJ5SxQK: RRSaoMVs1BJdWNEpAP = '!!__UNKNOWN_LIVE__!!'
		elif 'VOD_UNKNOWN' in kuMXTLrvIZGfjCDtA9YNJ5SxQK: RRSaoMVs1BJdWNEpAP = '!!__UNKNOWN_VOD__!!'
		elif 'VOD_SERIES' in kuMXTLrvIZGfjCDtA9YNJ5SxQK:
			y0QLtvfZWKV8zghSPF4eDpuRl6 = ffUFBJQ57j2XgoGeOLn9uwpC.findall('(.*?) [Ss]\d+ +[Ee]\d+',Oyc53409UnEIwbB['title'],ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			if y0QLtvfZWKV8zghSPF4eDpuRl6: y0QLtvfZWKV8zghSPF4eDpuRl6 = y0QLtvfZWKV8zghSPF4eDpuRl6[0]
			else: y0QLtvfZWKV8zghSPF4eDpuRl6 = '!!__UNKNOWN_SERIES__!!'
			RRSaoMVs1BJdWNEpAP = RRSaoMVs1BJdWNEpAP+'__SERIES__'+y0QLtvfZWKV8zghSPF4eDpuRl6
		if 'id' in KnyNSkJH0OzQ: del Oyc53409UnEIwbB['id']
		if 'ID' in KnyNSkJH0OzQ: del Oyc53409UnEIwbB['ID']
		if 'name' in KnyNSkJH0OzQ: del Oyc53409UnEIwbB['name']
		FghljxYu6ZiV7nCmtSUrywKDek = Oyc53409UnEIwbB['title']
		FghljxYu6ZiV7nCmtSUrywKDek = XTL0AWmwbDJfGRNi(FghljxYu6ZiV7nCmtSUrywKDek)
		FghljxYu6ZiV7nCmtSUrywKDek = gP1wn5hsKSfVuOHDaz(FghljxYu6ZiV7nCmtSUrywKDek)
		me0pgIcO1rq82JTtVXiLYwlj,RRSaoMVs1BJdWNEpAP = UGqRJKkWISv3PVDjsgBz9uw4f(RRSaoMVs1BJdWNEpAP)
		VjUWbd6POr0eAo,FghljxYu6ZiV7nCmtSUrywKDek = UGqRJKkWISv3PVDjsgBz9uw4f(FghljxYu6ZiV7nCmtSUrywKDek)
		Oyc53409UnEIwbB['type'] = kuMXTLrvIZGfjCDtA9YNJ5SxQK
		Oyc53409UnEIwbB['context'] = SUkst0aLFhj
		Oyc53409UnEIwbB['group'] = RRSaoMVs1BJdWNEpAP.upper()
		Oyc53409UnEIwbB['title'] = FghljxYu6ZiV7nCmtSUrywKDek.upper()
		Oyc53409UnEIwbB['country'] = VjUWbd6POr0eAo.upper()
		Oyc53409UnEIwbB['language'] = me0pgIcO1rq82JTtVXiLYwlj.upper()
		a2a0mpV49WBD5sIFYzU.append(Oyc53409UnEIwbB)
		zqj2ltB4agIQVifTWcxX7nC += 1
	return a2a0mpV49WBD5sIFYzU,zqj2ltB4agIQVifTWcxX7nC,r0YlJFfeCZaokWS51
def gP1wn5hsKSfVuOHDaz(FghljxYu6ZiV7nCmtSUrywKDek):
	FghljxYu6ZiV7nCmtSUrywKDek = FghljxYu6ZiV7nCmtSUrywKDek.replace(wr0HaqRdJ2D9LT7nSO1KMe38ly,VBpIH2QSmvDGlA6TO3e).replace(wr0HaqRdJ2D9LT7nSO1KMe38ly,VBpIH2QSmvDGlA6TO3e).replace(wr0HaqRdJ2D9LT7nSO1KMe38ly,VBpIH2QSmvDGlA6TO3e)
	FghljxYu6ZiV7nCmtSUrywKDek = FghljxYu6ZiV7nCmtSUrywKDek.replace('||','|').replace('___',':').replace('--','-')
	FghljxYu6ZiV7nCmtSUrywKDek = FghljxYu6ZiV7nCmtSUrywKDek.replace('[[','[').replace(']]',']')
	FghljxYu6ZiV7nCmtSUrywKDek = FghljxYu6ZiV7nCmtSUrywKDek.replace('((','(').replace('))',')')
	FghljxYu6ZiV7nCmtSUrywKDek = FghljxYu6ZiV7nCmtSUrywKDek.replace('<<','<').replace('>>','>')
	FghljxYu6ZiV7nCmtSUrywKDek = FghljxYu6ZiV7nCmtSUrywKDek.strip(VBpIH2QSmvDGlA6TO3e)
	return FghljxYu6ZiV7nCmtSUrywKDek
def XBpQbhTqNvYK0Usjn(zQrTywG64KYZIn2jXa,KGdsq9fgW31RcXomzCxrea):
	IvUahiecdM8DmJZ5 = {}
	for bvfP6pcm4enTAQZEUgxoV in zzSXPqifhs8rYnUvbMkuR26B7: IvUahiecdM8DmJZ5[bvfP6pcm4enTAQZEUgxoV] = []
	eB76azgblwARsQINn = len(zQrTywG64KYZIn2jXa)
	Qp1UTWbC8Aa3oDc = str(eB76azgblwARsQINn)
	zqj2ltB4agIQVifTWcxX7nC = 0
	r0YlJFfeCZaokWS51 = []
	for Oyc53409UnEIwbB in zQrTywG64KYZIn2jXa:
		if zqj2ltB4agIQVifTWcxX7nC%873==0:
			x3G0I9vUCjg(KGdsq9fgW31RcXomzCxrea,50+int(5*zqj2ltB4agIQVifTWcxX7nC/eB76azgblwARsQINn),'تصنيف الفيديوهات الغير مرتبة','الفيديو رقم:-',str(zqj2ltB4agIQVifTWcxX7nC)+' / '+Qp1UTWbC8Aa3oDc)
			if KGdsq9fgW31RcXomzCxrea.iscanceled():
				KGdsq9fgW31RcXomzCxrea.close()
				return None,None
		RRSaoMVs1BJdWNEpAP,SUkst0aLFhj,FghljxYu6ZiV7nCmtSUrywKDek,kxY4EfTKobmQJ8OathHI53,qsSTC3ZfW1NthKUbHQEnlpP9GY5 = Oyc53409UnEIwbB['group'],Oyc53409UnEIwbB['context'],Oyc53409UnEIwbB['title'],Oyc53409UnEIwbB['url'],Oyc53409UnEIwbB['img']
		VjUWbd6POr0eAo,me0pgIcO1rq82JTtVXiLYwlj,bvfP6pcm4enTAQZEUgxoV = Oyc53409UnEIwbB['country'],Oyc53409UnEIwbB['language'],Oyc53409UnEIwbB['type']
		V2RytdCl5ekaxMXpnf0 = (RRSaoMVs1BJdWNEpAP,SUkst0aLFhj,FghljxYu6ZiV7nCmtSUrywKDek,kxY4EfTKobmQJ8OathHI53,qsSTC3ZfW1NthKUbHQEnlpP9GY5)
		lM9TuRvJnLXgsBtx8U = False
		if 'LIVE' in bvfP6pcm4enTAQZEUgxoV:
			if 'UNKNOWN' in bvfP6pcm4enTAQZEUgxoV: IvUahiecdM8DmJZ5['LIVE_UNKNOWN_GROUPED'].append(V2RytdCl5ekaxMXpnf0)
			elif 'LIVE' in bvfP6pcm4enTAQZEUgxoV: IvUahiecdM8DmJZ5['LIVE_GROUPED'].append(V2RytdCl5ekaxMXpnf0)
			else: lM9TuRvJnLXgsBtx8U = True
			IvUahiecdM8DmJZ5['LIVE_ORIGINAL_GROUPED'].append(V2RytdCl5ekaxMXpnf0)
		elif 'VOD' in bvfP6pcm4enTAQZEUgxoV:
			if 'UNKNOWN' in bvfP6pcm4enTAQZEUgxoV: IvUahiecdM8DmJZ5['VOD_UNKNOWN_GROUPED'].append(V2RytdCl5ekaxMXpnf0)
			elif 'MOVIES' in bvfP6pcm4enTAQZEUgxoV: IvUahiecdM8DmJZ5['VOD_MOVIES_GROUPED'].append(V2RytdCl5ekaxMXpnf0)
			elif 'SERIES' in bvfP6pcm4enTAQZEUgxoV: IvUahiecdM8DmJZ5['VOD_SERIES_GROUPED'].append(V2RytdCl5ekaxMXpnf0)
			else: lM9TuRvJnLXgsBtx8U = True
			IvUahiecdM8DmJZ5['VOD_ORIGINAL_GROUPED'].append(V2RytdCl5ekaxMXpnf0)
		else: lM9TuRvJnLXgsBtx8U = True
		if lM9TuRvJnLXgsBtx8U: r0YlJFfeCZaokWS51.append(Oyc53409UnEIwbB)
		zqj2ltB4agIQVifTWcxX7nC += 1
	CfRFxvwsGgDlVNJHUbMQi9jYZ58cI6 = sorted(zQrTywG64KYZIn2jXa,reverse=False,key=lambda D8QslnRP0KIkdYcbviAGTSEo7U69z: D8QslnRP0KIkdYcbviAGTSEo7U69z['title'].lower())
	del zQrTywG64KYZIn2jXa
	Qp1UTWbC8Aa3oDc = str(eB76azgblwARsQINn)
	zqj2ltB4agIQVifTWcxX7nC = 0
	for Oyc53409UnEIwbB in CfRFxvwsGgDlVNJHUbMQi9jYZ58cI6:
		zqj2ltB4agIQVifTWcxX7nC += 1
		if zqj2ltB4agIQVifTWcxX7nC%873==0:
			x3G0I9vUCjg(KGdsq9fgW31RcXomzCxrea,55+int(5*zqj2ltB4agIQVifTWcxX7nC/eB76azgblwARsQINn),'تصنيف الفيديوهات المرتبة','الفيديو رقم:-',str(zqj2ltB4agIQVifTWcxX7nC)+' / '+Qp1UTWbC8Aa3oDc)
			if KGdsq9fgW31RcXomzCxrea.iscanceled():
				KGdsq9fgW31RcXomzCxrea.close()
				return None,None
		bvfP6pcm4enTAQZEUgxoV = Oyc53409UnEIwbB['type']
		RRSaoMVs1BJdWNEpAP,SUkst0aLFhj,FghljxYu6ZiV7nCmtSUrywKDek,kxY4EfTKobmQJ8OathHI53,qsSTC3ZfW1NthKUbHQEnlpP9GY5 = Oyc53409UnEIwbB['group'],Oyc53409UnEIwbB['context'],Oyc53409UnEIwbB['title'],Oyc53409UnEIwbB['url'],Oyc53409UnEIwbB['img']
		VjUWbd6POr0eAo,me0pgIcO1rq82JTtVXiLYwlj = Oyc53409UnEIwbB['country'],Oyc53409UnEIwbB['language']
		Chzk8epJXg90ou37NjcOUDyZ4b = (RRSaoMVs1BJdWNEpAP,SUkst0aLFhj+'_TIMESHIFT',FghljxYu6ZiV7nCmtSUrywKDek,kxY4EfTKobmQJ8OathHI53,qsSTC3ZfW1NthKUbHQEnlpP9GY5)
		V2RytdCl5ekaxMXpnf0 = (RRSaoMVs1BJdWNEpAP,SUkst0aLFhj,FghljxYu6ZiV7nCmtSUrywKDek,kxY4EfTKobmQJ8OathHI53,qsSTC3ZfW1NthKUbHQEnlpP9GY5)
		ZJTA83RaMCFVK56Elkm = (VjUWbd6POr0eAo,SUkst0aLFhj,FghljxYu6ZiV7nCmtSUrywKDek,kxY4EfTKobmQJ8OathHI53,qsSTC3ZfW1NthKUbHQEnlpP9GY5)
		v4pbFPcJk2zo1 = (me0pgIcO1rq82JTtVXiLYwlj,SUkst0aLFhj,FghljxYu6ZiV7nCmtSUrywKDek,kxY4EfTKobmQJ8OathHI53,qsSTC3ZfW1NthKUbHQEnlpP9GY5)
		if 'LIVE' in bvfP6pcm4enTAQZEUgxoV:
			if 'UNKNOWN' in bvfP6pcm4enTAQZEUgxoV: IvUahiecdM8DmJZ5['LIVE_UNKNOWN_GROUPED_SORTED'].append(V2RytdCl5ekaxMXpnf0)
			else: IvUahiecdM8DmJZ5['LIVE_GROUPED_SORTED'].append(V2RytdCl5ekaxMXpnf0)
			if 'EPG'		in bvfP6pcm4enTAQZEUgxoV: IvUahiecdM8DmJZ5['LIVE_EPG_GROUPED_SORTED'].append(V2RytdCl5ekaxMXpnf0)
			if 'ARCHIVED'	in bvfP6pcm4enTAQZEUgxoV: IvUahiecdM8DmJZ5['LIVE_ARCHIVED_GROUPED_SORTED'].append(V2RytdCl5ekaxMXpnf0)
			if 'ARCHIVED'	in bvfP6pcm4enTAQZEUgxoV: IvUahiecdM8DmJZ5['LIVE_TIMESHIFT_GROUPED_SORTED'].append(Chzk8epJXg90ou37NjcOUDyZ4b)
			IvUahiecdM8DmJZ5['LIVE_FROM_NAME_SORTED'].append(ZJTA83RaMCFVK56Elkm)
			IvUahiecdM8DmJZ5['LIVE_FROM_GROUP_SORTED'].append(v4pbFPcJk2zo1)
		elif 'VOD' in bvfP6pcm4enTAQZEUgxoV:
			if   'UNKNOWN'	in bvfP6pcm4enTAQZEUgxoV: IvUahiecdM8DmJZ5['VOD_UNKNOWN_GROUPED_SORTED'].append(V2RytdCl5ekaxMXpnf0)
			elif 'MOVIES'	in bvfP6pcm4enTAQZEUgxoV: IvUahiecdM8DmJZ5['VOD_MOVIES_GROUPED_SORTED'].append(V2RytdCl5ekaxMXpnf0)
			elif 'SERIES'	in bvfP6pcm4enTAQZEUgxoV: IvUahiecdM8DmJZ5['VOD_SERIES_GROUPED_SORTED'].append(V2RytdCl5ekaxMXpnf0)
			IvUahiecdM8DmJZ5['VOD_FROM_NAME_SORTED'].append(ZJTA83RaMCFVK56Elkm)
			IvUahiecdM8DmJZ5['VOD_FROM_GROUP_SORTED'].append(v4pbFPcJk2zo1)
	return IvUahiecdM8DmJZ5,r0YlJFfeCZaokWS51
def UGqRJKkWISv3PVDjsgBz9uw4f(FghljxYu6ZiV7nCmtSUrywKDek):
	if len(FghljxYu6ZiV7nCmtSUrywKDek)<3: return FghljxYu6ZiV7nCmtSUrywKDek,FghljxYu6ZiV7nCmtSUrywKDek
	lGaZCfebRnAdBvgQ4ToJhq2I6x7,F87ZVIhcX4OJyMkLN5 = cdZKMn68Pzg4,cdZKMn68Pzg4
	s8V0d4IDnRZyXB3qOfSEkvbjph5 = FghljxYu6ZiV7nCmtSUrywKDek
	CzB8GjXODyxPHRMJhAQdUr2wq = FghljxYu6ZiV7nCmtSUrywKDek[:1]
	PPlkNc21DbXsgnu6A8 = FghljxYu6ZiV7nCmtSUrywKDek[1:]
	if   CzB8GjXODyxPHRMJhAQdUr2wq=='(': F87ZVIhcX4OJyMkLN5 = ')'
	elif CzB8GjXODyxPHRMJhAQdUr2wq=='[': F87ZVIhcX4OJyMkLN5 = ']'
	elif CzB8GjXODyxPHRMJhAQdUr2wq=='<': F87ZVIhcX4OJyMkLN5 = '>'
	elif CzB8GjXODyxPHRMJhAQdUr2wq=='|': F87ZVIhcX4OJyMkLN5 = '|'
	if F87ZVIhcX4OJyMkLN5 and (F87ZVIhcX4OJyMkLN5 in PPlkNc21DbXsgnu6A8):
		sCLpx2rb49YyGhN35eVF,LHkdz7VDJo80GFtBhqyc9wv = PPlkNc21DbXsgnu6A8.split(F87ZVIhcX4OJyMkLN5,1)
		lGaZCfebRnAdBvgQ4ToJhq2I6x7 = sCLpx2rb49YyGhN35eVF
		s8V0d4IDnRZyXB3qOfSEkvbjph5 = CzB8GjXODyxPHRMJhAQdUr2wq+sCLpx2rb49YyGhN35eVF+F87ZVIhcX4OJyMkLN5+VBpIH2QSmvDGlA6TO3e+LHkdz7VDJo80GFtBhqyc9wv
	elif FghljxYu6ZiV7nCmtSUrywKDek.count('|')>=2:
		sCLpx2rb49YyGhN35eVF,LHkdz7VDJo80GFtBhqyc9wv = FghljxYu6ZiV7nCmtSUrywKDek.split('|',1)
		lGaZCfebRnAdBvgQ4ToJhq2I6x7 = sCLpx2rb49YyGhN35eVF
		s8V0d4IDnRZyXB3qOfSEkvbjph5 = sCLpx2rb49YyGhN35eVF+' |'+LHkdz7VDJo80GFtBhqyc9wv
	else:
		F87ZVIhcX4OJyMkLN5 = ffUFBJQ57j2XgoGeOLn9uwpC.findall('^\w{2}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',FghljxYu6ZiV7nCmtSUrywKDek,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if not F87ZVIhcX4OJyMkLN5: F87ZVIhcX4OJyMkLN5 = ffUFBJQ57j2XgoGeOLn9uwpC.findall('^\w{3}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',FghljxYu6ZiV7nCmtSUrywKDek,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if not F87ZVIhcX4OJyMkLN5: F87ZVIhcX4OJyMkLN5 = ffUFBJQ57j2XgoGeOLn9uwpC.findall('^\w{4}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',FghljxYu6ZiV7nCmtSUrywKDek,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if F87ZVIhcX4OJyMkLN5:
			sCLpx2rb49YyGhN35eVF,LHkdz7VDJo80GFtBhqyc9wv = FghljxYu6ZiV7nCmtSUrywKDek.split(F87ZVIhcX4OJyMkLN5[0],1)
			lGaZCfebRnAdBvgQ4ToJhq2I6x7 = sCLpx2rb49YyGhN35eVF
			s8V0d4IDnRZyXB3qOfSEkvbjph5 = sCLpx2rb49YyGhN35eVF+VBpIH2QSmvDGlA6TO3e+F87ZVIhcX4OJyMkLN5[0]+VBpIH2QSmvDGlA6TO3e+LHkdz7VDJo80GFtBhqyc9wv
	s8V0d4IDnRZyXB3qOfSEkvbjph5 = s8V0d4IDnRZyXB3qOfSEkvbjph5.replace(U4ImogGksPlcBVfAb,VBpIH2QSmvDGlA6TO3e).replace(wr0HaqRdJ2D9LT7nSO1KMe38ly,VBpIH2QSmvDGlA6TO3e)
	lGaZCfebRnAdBvgQ4ToJhq2I6x7 = lGaZCfebRnAdBvgQ4ToJhq2I6x7.replace(wr0HaqRdJ2D9LT7nSO1KMe38ly,VBpIH2QSmvDGlA6TO3e)
	if not lGaZCfebRnAdBvgQ4ToJhq2I6x7: lGaZCfebRnAdBvgQ4ToJhq2I6x7 = '!!__UNKNOWN__!!'
	lGaZCfebRnAdBvgQ4ToJhq2I6x7 = lGaZCfebRnAdBvgQ4ToJhq2I6x7.strip(VBpIH2QSmvDGlA6TO3e)
	s8V0d4IDnRZyXB3qOfSEkvbjph5 = s8V0d4IDnRZyXB3qOfSEkvbjph5.strip(VBpIH2QSmvDGlA6TO3e)
	return lGaZCfebRnAdBvgQ4ToJhq2I6x7,s8V0d4IDnRZyXB3qOfSEkvbjph5
def lr845giTQzJ01vqZP(Vea0sXycdJ8LFSMzhB5Zt73u2rD):
	pj3iPglDkueR29AH6U = {}
	J8wUvxLd7kNoGf4pY1XCn = Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.getSetting('av.iptv.useragent_'+Vea0sXycdJ8LFSMzhB5Zt73u2rD)
	if J8wUvxLd7kNoGf4pY1XCn: pj3iPglDkueR29AH6U['User-Agent'] = J8wUvxLd7kNoGf4pY1XCn
	ITXKP0wLvFMQ9Niq6ctH8 = Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.getSetting('av.iptv.referer_'+Vea0sXycdJ8LFSMzhB5Zt73u2rD)
	if ITXKP0wLvFMQ9Niq6ctH8: pj3iPglDkueR29AH6U['Referer'] = ITXKP0wLvFMQ9Niq6ctH8
	return pj3iPglDkueR29AH6U
def VEFIiuClxN6GjWzmpUsbTr4ekt(Vea0sXycdJ8LFSMzhB5Zt73u2rD):
	global KGdsq9fgW31RcXomzCxrea,IvUahiecdM8DmJZ5,ssnMlW9pZ2,bJj3qg4XCfGd0,HPJoQA6URLk18nhXva7cbVDKMO,cY1DzUC9nxHgQM4BjIts,bsXtEzrKQ1f,BrCgRhzJ2KXakVq608w9,AXLJu7i8khn951BsFOyZNIEWT2R
	jcidYWSngJx2lphkZN7f5AqRu,AZnTKcDC0twiN2l6Fzxr3f,Szg3qvldoOyU,YsyfvFHASN,ww2AC3SkbFQXc6Pj = EEJjV7pU0Cy9RScBXefYh(Vea0sXycdJ8LFSMzhB5Zt73u2rD)
	if not YsyfvFHASN: return
	pj3iPglDkueR29AH6U = lr845giTQzJ01vqZP(Vea0sXycdJ8LFSMzhB5Zt73u2rD)
	GPQCWezyxpbjhHNXMVEaI4FR = JyLdvftP3CU('center',cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,'جلب ملفات ـIPTV جديدة قد تحتاج عدة دقائق . هل تريد أن تجلب الملفات الآن ؟')
	if GPQCWezyxpbjhHNXMVEaI4FR!=1: return
	A2vi5PFs9t7OU = gZ9swV4tb1lmTqMxASN8X.replace('___','_'+Vea0sXycdJ8LFSMzhB5Zt73u2rD)
	if 1:
		RepGgckNqE,XOSVmnLg957jiID0Q1RPlvpbkw,beE5JlkVDgdzro4y = hX7rFmcGbqlaER2xL(Vea0sXycdJ8LFSMzhB5Zt73u2rD,False)
		if not RepGgckNqE:
			NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,'فشل بسحب ملفات ـIPTV . أحتمال رابط ـIPTV غير صحيح أو قديم أو لا يعمل .. علما أن هذه الخدمة تحتاج اشتراك مدفوع وصحيح ويجب أن تضيف رابط الاشتراك بنفسك للبرنامج باستخدام قائمة ـIPTV الموجودة بهذا البرنامج')
			if not AZnTKcDC0twiN2l6Fzxr3f: SsziMZd5UbeL2NRxVpwjO(E7lrS9VXJF58d2NUAfkvxwjmHM,xxd7Xp5lvem(LMihk2Vzl4DesIQ65TGmvxqcKdHp)+'   No IPTV URL found to download IPTV files')
			else: SsziMZd5UbeL2NRxVpwjO(E7lrS9VXJF58d2NUAfkvxwjmHM,xxd7Xp5lvem(LMihk2Vzl4DesIQ65TGmvxqcKdHp)+'   Failed to download IPTV files')
			return
		bmCIrFtRfk = ImLjWxYH1p3rRF2VhCOvz8(AZnTKcDC0twiN2l6Fzxr3f,pj3iPglDkueR29AH6U,True)
		if not bmCIrFtRfk: return
		open(A2vi5PFs9t7OU,'wb').write(bmCIrFtRfk)
	else: bmCIrFtRfk = open(A2vi5PFs9t7OU,'rb').read()
	if W5domCu6XrQUFkiPpa3bNLtHglG and bmCIrFtRfk: bmCIrFtRfk = bmCIrFtRfk.decode(vczMIlkCAh2u10B3)
	KGdsq9fgW31RcXomzCxrea = g6UkpOE3s5XLiFH()
	KGdsq9fgW31RcXomzCxrea.create('جلب ملفات ـIPTV جديدة',cdZKMn68Pzg4)
	x3G0I9vUCjg(KGdsq9fgW31RcXomzCxrea,15,'تنظيف الملف الرئيسي',cdZKMn68Pzg4)
	bmCIrFtRfk = bmCIrFtRfk.replace('"tvg-','" tvg-')
	bmCIrFtRfk = bmCIrFtRfk.replace('َ',cdZKMn68Pzg4).replace('ً',cdZKMn68Pzg4).replace('ُ',cdZKMn68Pzg4).replace('ٌ',cdZKMn68Pzg4)
	bmCIrFtRfk = bmCIrFtRfk.replace('ّ',cdZKMn68Pzg4).replace('ِ',cdZKMn68Pzg4).replace('ٍ',cdZKMn68Pzg4).replace('ْ',cdZKMn68Pzg4)
	bmCIrFtRfk = bmCIrFtRfk.replace('group-title=','group=').replace('tvg-',cdZKMn68Pzg4)
	ZpPvIGFq91fzMk64Q7OyNdD5wbL,DVEcs2ShJgRT = [],[]
	x3G0I9vUCjg(KGdsq9fgW31RcXomzCxrea,20,'جلب الملفات الثانوية','الملف رقم:-','1 / 3')
	if KGdsq9fgW31RcXomzCxrea.iscanceled():
		KGdsq9fgW31RcXomzCxrea.close()
		return
	kxY4EfTKobmQJ8OathHI53 = jcidYWSngJx2lphkZN7f5AqRu+'&action=get_series_categories'
	oyufnwWte9Im4cFA6hSLODiGRMsJx8 = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',kxY4EfTKobmQJ8OathHI53,cdZKMn68Pzg4,pj3iPglDkueR29AH6U,cdZKMn68Pzg4,cdZKMn68Pzg4,'IPTV-CREATE_STREAMS-1st')
	ajEFui1BI6z8RJor = oyufnwWte9Im4cFA6hSLODiGRMsJx8.content
	ajEFui1BI6z8RJor = XTL0AWmwbDJfGRNi(ajEFui1BI6z8RJor)
	YwJBN3dAxt4UWOuHe1Dz = ffUFBJQ57j2XgoGeOLn9uwpC.findall('category_name":"(.*?)"',ajEFui1BI6z8RJor,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	del ajEFui1BI6z8RJor
	for RRSaoMVs1BJdWNEpAP in YwJBN3dAxt4UWOuHe1Dz:
		RRSaoMVs1BJdWNEpAP = RRSaoMVs1BJdWNEpAP.replace('\/',KCQExdbYFqM)
		if xicJPb0AW1nsRfH3kCv7: RRSaoMVs1BJdWNEpAP = RRSaoMVs1BJdWNEpAP.decode(vczMIlkCAh2u10B3).encode(vczMIlkCAh2u10B3)
		bmCIrFtRfk = bmCIrFtRfk.replace('group="'+RRSaoMVs1BJdWNEpAP+'"','group="__SERIES__'+RRSaoMVs1BJdWNEpAP+'"')
	del YwJBN3dAxt4UWOuHe1Dz
	x3G0I9vUCjg(KGdsq9fgW31RcXomzCxrea,25,'جلب الملفات الثانوية','الملف رقم:-','2 / 3')
	if KGdsq9fgW31RcXomzCxrea.iscanceled():
		KGdsq9fgW31RcXomzCxrea.close()
		return
	kxY4EfTKobmQJ8OathHI53 = jcidYWSngJx2lphkZN7f5AqRu+'&action=get_vod_categories'
	oyufnwWte9Im4cFA6hSLODiGRMsJx8 = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',kxY4EfTKobmQJ8OathHI53,cdZKMn68Pzg4,pj3iPglDkueR29AH6U,cdZKMn68Pzg4,cdZKMn68Pzg4,'IPTV-CREATE_STREAMS-2nd')
	ajEFui1BI6z8RJor = oyufnwWte9Im4cFA6hSLODiGRMsJx8.content
	ajEFui1BI6z8RJor = XTL0AWmwbDJfGRNi(ajEFui1BI6z8RJor)
	cJZbI4EvHpntGlsFOS7oDyxqAa = ffUFBJQ57j2XgoGeOLn9uwpC.findall('category_name":"(.*?)"',ajEFui1BI6z8RJor,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	del ajEFui1BI6z8RJor
	for RRSaoMVs1BJdWNEpAP in cJZbI4EvHpntGlsFOS7oDyxqAa:
		RRSaoMVs1BJdWNEpAP = RRSaoMVs1BJdWNEpAP.replace('\/',KCQExdbYFqM)
		if xicJPb0AW1nsRfH3kCv7: RRSaoMVs1BJdWNEpAP = RRSaoMVs1BJdWNEpAP.decode(vczMIlkCAh2u10B3).encode(vczMIlkCAh2u10B3)
		bmCIrFtRfk = bmCIrFtRfk.replace('group="'+RRSaoMVs1BJdWNEpAP+'"','group="__MOVIES__'+RRSaoMVs1BJdWNEpAP+'"')
	del cJZbI4EvHpntGlsFOS7oDyxqAa
	x3G0I9vUCjg(KGdsq9fgW31RcXomzCxrea,30,'جلب الملفات الثانوية','الملف رقم:-','3 / 3')
	if KGdsq9fgW31RcXomzCxrea.iscanceled():
		KGdsq9fgW31RcXomzCxrea.close()
		return
	kxY4EfTKobmQJ8OathHI53 = jcidYWSngJx2lphkZN7f5AqRu+'&action=get_live_streams'
	oyufnwWte9Im4cFA6hSLODiGRMsJx8 = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',kxY4EfTKobmQJ8OathHI53,cdZKMn68Pzg4,pj3iPglDkueR29AH6U,cdZKMn68Pzg4,cdZKMn68Pzg4,'IPTV-CREATE_STREAMS-3rd')
	ajEFui1BI6z8RJor = oyufnwWte9Im4cFA6hSLODiGRMsJx8.content
	ajEFui1BI6z8RJor = XTL0AWmwbDJfGRNi(ajEFui1BI6z8RJor)
	ixRo0gSflLv75KVZmhyMI = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"name":"(.*?)".*?"tv_archive":(.*?),',ajEFui1BI6z8RJor,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	for yy0cNBFOGVZh8rIeQ4,LHSQe6dtRA0fFv8giTIkWlnP4J in ixRo0gSflLv75KVZmhyMI:
		if LHSQe6dtRA0fFv8giTIkWlnP4J=='1': ZpPvIGFq91fzMk64Q7OyNdD5wbL.append(yy0cNBFOGVZh8rIeQ4)
	del ixRo0gSflLv75KVZmhyMI
	AGn7TI6of3LCHK9h4ZbgzxX8W = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"name":"(.*?)".*?"epg_channel_id":(.*?),',ajEFui1BI6z8RJor,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	del ajEFui1BI6z8RJor
	for yy0cNBFOGVZh8rIeQ4,gpZhvES67y in AGn7TI6of3LCHK9h4ZbgzxX8W:
		if gpZhvES67y!='null': DVEcs2ShJgRT.append(yy0cNBFOGVZh8rIeQ4)
	del AGn7TI6of3LCHK9h4ZbgzxX8W
	bmCIrFtRfk = bmCIrFtRfk.replace(CPjOZMmw8sfGg2B9LthIdXa1iKQUF,ssELJkeScrtni2)
	oPs342UIN6ieO9BVJWZpfXE = ffUFBJQ57j2XgoGeOLn9uwpC.findall('NF:(.+?)'+'#'+'EXTI',bmCIrFtRfk+'\n+'+'#'+'EXTINF:',ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if not oPs342UIN6ieO9BVJWZpfXE:
		SsziMZd5UbeL2NRxVpwjO(E7lrS9VXJF58d2NUAfkvxwjmHM,xxd7Xp5lvem(LMihk2Vzl4DesIQ65TGmvxqcKdHp)+'   Folder:'+Vea0sXycdJ8LFSMzhB5Zt73u2rD+'   No video links found in IPTV file')
		NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,'رابط ـIPTV الذي أنت أضفته لا توجد فيه فيديوهات .. احتمال رابط ـIPTV غير صحيح'+ssELJkeScrtni2+bxf7gZvNK29cEoiAIJlMq0dP+'مجلد رقم '+Vea0sXycdJ8LFSMzhB5Zt73u2rD)
		KGdsq9fgW31RcXomzCxrea.close()
		return
	OJMBZjGwdq = []
	for uvjQ0YydJMPkbGeg8I3FUslAW in oPs342UIN6ieO9BVJWZpfXE:
		HW9VuF5JZAI1zYSrc = uvjQ0YydJMPkbGeg8I3FUslAW.lower()
		if 'adult' in HW9VuF5JZAI1zYSrc: continue
		if 'xxx' in HW9VuF5JZAI1zYSrc: continue
		OJMBZjGwdq.append(uvjQ0YydJMPkbGeg8I3FUslAW)
	oPs342UIN6ieO9BVJWZpfXE = OJMBZjGwdq
	del OJMBZjGwdq
	dIZNi2xEHT69Y8czWv = 1024*1024
	jj4paidWFcfM9oO12eEVC6 = 1+len(bmCIrFtRfk)//dIZNi2xEHT69Y8czWv//10
	del bmCIrFtRfk
	M6cnTwgRzuH = len(oPs342UIN6ieO9BVJWZpfXE)
	y5FswDzoEC1mqr3dxafcb2gpjvOuk = WjO0oaTH4cZg8BDuJkMymizfS(oPs342UIN6ieO9BVJWZpfXE,jj4paidWFcfM9oO12eEVC6)
	del oPs342UIN6ieO9BVJWZpfXE
	for ZoQJArX6xtaIG0MfLnvqEmD in range(jj4paidWFcfM9oO12eEVC6):
		x3G0I9vUCjg(KGdsq9fgW31RcXomzCxrea,35+int(5*ZoQJArX6xtaIG0MfLnvqEmD/jj4paidWFcfM9oO12eEVC6),'تقطيع الملف الرئيسي','الجزء رقم:-',str(ZoQJArX6xtaIG0MfLnvqEmD+1)+' / '+str(jj4paidWFcfM9oO12eEVC6))
		if KGdsq9fgW31RcXomzCxrea.iscanceled():
			KGdsq9fgW31RcXomzCxrea.close()
			return
		qPlfgxceavQ = str(y5FswDzoEC1mqr3dxafcb2gpjvOuk[ZoQJArX6xtaIG0MfLnvqEmD])
		if W5domCu6XrQUFkiPpa3bNLtHglG: qPlfgxceavQ = qPlfgxceavQ.encode(vczMIlkCAh2u10B3)
		open(A2vi5PFs9t7OU+'.00'+str(ZoQJArX6xtaIG0MfLnvqEmD),'wb').write(qPlfgxceavQ)
	del y5FswDzoEC1mqr3dxafcb2gpjvOuk,qPlfgxceavQ
	V5K6oJqfgs09vtdiO8,zQrTywG64KYZIn2jXa,zqj2ltB4agIQVifTWcxX7nC = [],[],0
	for ZoQJArX6xtaIG0MfLnvqEmD in range(jj4paidWFcfM9oO12eEVC6):
		if KGdsq9fgW31RcXomzCxrea.iscanceled():
			KGdsq9fgW31RcXomzCxrea.close()
			return
		qPlfgxceavQ = open(A2vi5PFs9t7OU+'.00'+str(ZoQJArX6xtaIG0MfLnvqEmD),'rb').read()
		bD7kJZhMCdaqF68P45KlNIgO1.sleep(1)
		try: YRESXadfbIy3khwqmL8WC.remove(A2vi5PFs9t7OU+'.00'+str(ZoQJArX6xtaIG0MfLnvqEmD))
		except: pass
		if W5domCu6XrQUFkiPpa3bNLtHglG: qPlfgxceavQ = qPlfgxceavQ.decode(vczMIlkCAh2u10B3)
		zPnvoYJyLrUQu0HCmk1w7OsSFl = lMeKd3hC6cmS('list',qPlfgxceavQ)
		del qPlfgxceavQ
		a2a0mpV49WBD5sIFYzU,zqj2ltB4agIQVifTWcxX7nC,r0YlJFfeCZaokWS51 = KJEI4tXxRaAzPWojcQuLB9k(zPnvoYJyLrUQu0HCmk1w7OsSFl,DVEcs2ShJgRT,ZpPvIGFq91fzMk64Q7OyNdD5wbL,KGdsq9fgW31RcXomzCxrea,M6cnTwgRzuH,zqj2ltB4agIQVifTWcxX7nC,AZnTKcDC0twiN2l6Fzxr3f)
		if KGdsq9fgW31RcXomzCxrea.iscanceled():
			KGdsq9fgW31RcXomzCxrea.close()
			return
		if not a2a0mpV49WBD5sIFYzU:
			KGdsq9fgW31RcXomzCxrea.close()
			return
		zQrTywG64KYZIn2jXa += a2a0mpV49WBD5sIFYzU
		V5K6oJqfgs09vtdiO8 += r0YlJFfeCZaokWS51
	del zPnvoYJyLrUQu0HCmk1w7OsSFl,a2a0mpV49WBD5sIFYzU
	IvUahiecdM8DmJZ5,r0YlJFfeCZaokWS51 = XBpQbhTqNvYK0Usjn(zQrTywG64KYZIn2jXa,KGdsq9fgW31RcXomzCxrea)
	if KGdsq9fgW31RcXomzCxrea.iscanceled():
		KGdsq9fgW31RcXomzCxrea.close()
		return
	V5K6oJqfgs09vtdiO8 += r0YlJFfeCZaokWS51
	del zQrTywG64KYZIn2jXa,r0YlJFfeCZaokWS51
	bJj3qg4XCfGd0,HPJoQA6URLk18nhXva7cbVDKMO,cY1DzUC9nxHgQM4BjIts,bsXtEzrKQ1f,BrCgRhzJ2KXakVq608w9 = {},{},{},0,0
	wLOjSMzVeZ8I0C3stWakYTUyc7 = list(IvUahiecdM8DmJZ5.keys())
	AXLJu7i8khn951BsFOyZNIEWT2R = len(wLOjSMzVeZ8I0C3stWakYTUyc7)*3
	if 1:
		R9IcLVCtrSOD = {}
		for MBHEOqmtX3SPb2whAFr6ul in wLOjSMzVeZ8I0C3stWakYTUyc7:
			R9IcLVCtrSOD[MBHEOqmtX3SPb2whAFr6ul] = qMrpRl8enOuvS6hV2XcZgT(daemon=IZQbmFzLHDtXfc,target=MrDlUQdItzgcnE0pZY82,args=(MBHEOqmtX3SPb2whAFr6ul,))
			R9IcLVCtrSOD[MBHEOqmtX3SPb2whAFr6ul].start()
		for MBHEOqmtX3SPb2whAFr6ul in wLOjSMzVeZ8I0C3stWakYTUyc7:
			R9IcLVCtrSOD[MBHEOqmtX3SPb2whAFr6ul].join()
		if KGdsq9fgW31RcXomzCxrea.iscanceled():
			KGdsq9fgW31RcXomzCxrea.close()
			return
	else:
		for MBHEOqmtX3SPb2whAFr6ul in wLOjSMzVeZ8I0C3stWakYTUyc7:
			MrDlUQdItzgcnE0pZY82(MBHEOqmtX3SPb2whAFr6ul)
			if KGdsq9fgW31RcXomzCxrea.iscanceled():
				KGdsq9fgW31RcXomzCxrea.close()
				return
	m4cprS5FuYxjRH3yiMVKhAqIU8(Vea0sXycdJ8LFSMzhB5Zt73u2rD,False)
	wLOjSMzVeZ8I0C3stWakYTUyc7 = list(bJj3qg4XCfGd0.keys())
	ssnMlW9pZ2 = 0
	if 1:
		R9IcLVCtrSOD = {}
		for MBHEOqmtX3SPb2whAFr6ul in wLOjSMzVeZ8I0C3stWakYTUyc7:
			R9IcLVCtrSOD[MBHEOqmtX3SPb2whAFr6ul] = qMrpRl8enOuvS6hV2XcZgT(daemon=IZQbmFzLHDtXfc,target=oSpCPgODjwKRkyTtx,args=(Vea0sXycdJ8LFSMzhB5Zt73u2rD,MBHEOqmtX3SPb2whAFr6ul))
			R9IcLVCtrSOD[MBHEOqmtX3SPb2whAFr6ul].start()
		for MBHEOqmtX3SPb2whAFr6ul in wLOjSMzVeZ8I0C3stWakYTUyc7:
			R9IcLVCtrSOD[MBHEOqmtX3SPb2whAFr6ul].join()
		if KGdsq9fgW31RcXomzCxrea.iscanceled():
			KGdsq9fgW31RcXomzCxrea.close()
			return
	else:
		for MBHEOqmtX3SPb2whAFr6ul in wLOjSMzVeZ8I0C3stWakYTUyc7:
			oSpCPgODjwKRkyTtx(Vea0sXycdJ8LFSMzhB5Zt73u2rD,MBHEOqmtX3SPb2whAFr6ul)
			if KGdsq9fgW31RcXomzCxrea.iscanceled():
				KGdsq9fgW31RcXomzCxrea.close()
				return
	ZoQJArX6xtaIG0MfLnvqEmD = 0
	fMG40az7RTuNHc6tJji5 = len(V5K6oJqfgs09vtdiO8)
	RTr92nPJkjuBoDMbELV8Oa = wwATViQ0xDaoNMEK4v3PIeC8UzZ5(Vea0sXycdJ8LFSMzhB5Zt73u2rD,'IGNORED')
	for c0nXbOZWKUj7h1fR5rT in V5K6oJqfgs09vtdiO8:
		if ZoQJArX6xtaIG0MfLnvqEmD%27==0:
			x3G0I9vUCjg(KGdsq9fgW31RcXomzCxrea,95+int(5*ZoQJArX6xtaIG0MfLnvqEmD//fMG40az7RTuNHc6tJji5),'تخزين المهملة','الفيديو رقم:-',str(ZoQJArX6xtaIG0MfLnvqEmD)+' / '+str(fMG40az7RTuNHc6tJji5))
			if KGdsq9fgW31RcXomzCxrea.iscanceled():
				KGdsq9fgW31RcXomzCxrea.close()
				return
		uAkLQ7gEZaIBv6Fyn(RTr92nPJkjuBoDMbELV8Oa,'IGNORED',str(c0nXbOZWKUj7h1fR5rT),cdZKMn68Pzg4,jCmv4M3HNPdyaLS)
		ZoQJArX6xtaIG0MfLnvqEmD += 1
	uAkLQ7gEZaIBv6Fyn(RTr92nPJkjuBoDMbELV8Oa,'IGNORED','__COUNT__',str(fMG40az7RTuNHc6tJji5),jCmv4M3HNPdyaLS)
	uAkLQ7gEZaIBv6Fyn(RTr92nPJkjuBoDMbELV8Oa,'DUMMY','__DUMMY__','1',jCmv4M3HNPdyaLS)
	KGdsq9fgW31RcXomzCxrea.close()
	bD7kJZhMCdaqF68P45KlNIgO1.sleep(1)
	RuDBlzZQK8ihkY36tf7FjGHvoAST = U2i5lhIGe8EmckoLY(Vea0sXycdJ8LFSMzhB5Zt73u2rD,False)
	NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,bxf7gZvNK29cEoiAIJlMq0dP+'تم جلب ملفات ـIPTV جديدة'+kH8E2zqNyims6KJfI+'\n\n'+RuDBlzZQK8ihkY36tf7FjGHvoAST)
	SYaTv4t7q0cy96(Vea0sXycdJ8LFSMzhB5Zt73u2rD)
	tiuZ61v2BRxSKgJWfpbL0Yq(False)
	XfABsbKWoLhI(False)
	return
def MrDlUQdItzgcnE0pZY82(MBHEOqmtX3SPb2whAFr6ul):
	global KGdsq9fgW31RcXomzCxrea,IvUahiecdM8DmJZ5,ssnMlW9pZ2,bJj3qg4XCfGd0,HPJoQA6URLk18nhXva7cbVDKMO,cY1DzUC9nxHgQM4BjIts,bsXtEzrKQ1f,BrCgRhzJ2KXakVq608w9,AXLJu7i8khn951BsFOyZNIEWT2R
	bJj3qg4XCfGd0[MBHEOqmtX3SPb2whAFr6ul] = {}
	IxVL4f8sCoMUnG,oMR23rWOz6ClIkKyZGnTcX1ge = {},[]
	vsGQhBFW3Y5NdT6Se = len(IvUahiecdM8DmJZ5[MBHEOqmtX3SPb2whAFr6ul])
	bJj3qg4XCfGd0[MBHEOqmtX3SPb2whAFr6ul]['__COUNT__'] = vsGQhBFW3Y5NdT6Se
	if vsGQhBFW3Y5NdT6Se>0:
		GGhBXJAnQ6vPY7L,HGau6FAynjiwM,EOjM5gWYtZSlnuaeRs3hBDv6,egc2LvFlYh8UMV3,EaP3xnWRG6ivq87zkp1oBwTIVLXY = zip(*IvUahiecdM8DmJZ5[MBHEOqmtX3SPb2whAFr6ul])
		del HGau6FAynjiwM,EOjM5gWYtZSlnuaeRs3hBDv6,egc2LvFlYh8UMV3
		XrHLAPxJqmckTSU = list(set(GGhBXJAnQ6vPY7L))
		for RRSaoMVs1BJdWNEpAP in XrHLAPxJqmckTSU:
			IxVL4f8sCoMUnG[RRSaoMVs1BJdWNEpAP] = cdZKMn68Pzg4
			bJj3qg4XCfGd0[MBHEOqmtX3SPb2whAFr6ul][RRSaoMVs1BJdWNEpAP] = []
		x3G0I9vUCjg(KGdsq9fgW31RcXomzCxrea,60+int(15*BrCgRhzJ2KXakVq608w9//AXLJu7i8khn951BsFOyZNIEWT2R),'تصنيع القوائم','الجزء رقم:-',str(BrCgRhzJ2KXakVq608w9)+' / '+str(AXLJu7i8khn951BsFOyZNIEWT2R))
		if KGdsq9fgW31RcXomzCxrea.iscanceled(): return
		BrCgRhzJ2KXakVq608w9 += 1
		Lz5ovMJKWgQBs4nTExqtGDjAIY = len(XrHLAPxJqmckTSU)
		del XrHLAPxJqmckTSU
		oMR23rWOz6ClIkKyZGnTcX1ge = list(set(zip(GGhBXJAnQ6vPY7L,EaP3xnWRG6ivq87zkp1oBwTIVLXY)))
		del GGhBXJAnQ6vPY7L,EaP3xnWRG6ivq87zkp1oBwTIVLXY
		for RRSaoMVs1BJdWNEpAP,cxokMEeWJnSdZGt53qYhI in oMR23rWOz6ClIkKyZGnTcX1ge:
			if not IxVL4f8sCoMUnG[RRSaoMVs1BJdWNEpAP] and cxokMEeWJnSdZGt53qYhI: IxVL4f8sCoMUnG[RRSaoMVs1BJdWNEpAP] = cxokMEeWJnSdZGt53qYhI
		x3G0I9vUCjg(KGdsq9fgW31RcXomzCxrea,60+int(15*BrCgRhzJ2KXakVq608w9//AXLJu7i8khn951BsFOyZNIEWT2R),'تصنيع القوائم','الجزء رقم:-',str(BrCgRhzJ2KXakVq608w9)+' / '+str(AXLJu7i8khn951BsFOyZNIEWT2R))
		if KGdsq9fgW31RcXomzCxrea.iscanceled(): return
		BrCgRhzJ2KXakVq608w9 += 1
		HruweSoBRk47LFC0ZINi9YqPU6a = list(IxVL4f8sCoMUnG.keys())
		WWaDiPEM1GbHVOwhfqC = list(IxVL4f8sCoMUnG.values())
		del IxVL4f8sCoMUnG
		oMR23rWOz6ClIkKyZGnTcX1ge = list(zip(HruweSoBRk47LFC0ZINi9YqPU6a,WWaDiPEM1GbHVOwhfqC))
		del HruweSoBRk47LFC0ZINi9YqPU6a,WWaDiPEM1GbHVOwhfqC
		oMR23rWOz6ClIkKyZGnTcX1ge = sorted(oMR23rWOz6ClIkKyZGnTcX1ge)
	else: BrCgRhzJ2KXakVq608w9 += 2
	bJj3qg4XCfGd0[MBHEOqmtX3SPb2whAFr6ul]['__GROUPS__'] = oMR23rWOz6ClIkKyZGnTcX1ge
	del oMR23rWOz6ClIkKyZGnTcX1ge
	for RRSaoMVs1BJdWNEpAP,SUkst0aLFhj,FghljxYu6ZiV7nCmtSUrywKDek,kxY4EfTKobmQJ8OathHI53,qsSTC3ZfW1NthKUbHQEnlpP9GY5 in IvUahiecdM8DmJZ5[MBHEOqmtX3SPb2whAFr6ul]:
		bJj3qg4XCfGd0[MBHEOqmtX3SPb2whAFr6ul][RRSaoMVs1BJdWNEpAP].append((SUkst0aLFhj,FghljxYu6ZiV7nCmtSUrywKDek,kxY4EfTKobmQJ8OathHI53,qsSTC3ZfW1NthKUbHQEnlpP9GY5))
	x3G0I9vUCjg(KGdsq9fgW31RcXomzCxrea,60+int(15*BrCgRhzJ2KXakVq608w9//AXLJu7i8khn951BsFOyZNIEWT2R),'تصنيع القوائم','الجزء رقم:-',str(BrCgRhzJ2KXakVq608w9)+' / '+str(AXLJu7i8khn951BsFOyZNIEWT2R))
	if KGdsq9fgW31RcXomzCxrea.iscanceled(): return
	BrCgRhzJ2KXakVq608w9 += 1
	del IvUahiecdM8DmJZ5[MBHEOqmtX3SPb2whAFr6ul]
	cY1DzUC9nxHgQM4BjIts[MBHEOqmtX3SPb2whAFr6ul] = list(bJj3qg4XCfGd0[MBHEOqmtX3SPb2whAFr6ul].keys())
	HPJoQA6URLk18nhXva7cbVDKMO[MBHEOqmtX3SPb2whAFr6ul] = len(cY1DzUC9nxHgQM4BjIts[MBHEOqmtX3SPb2whAFr6ul])
	bsXtEzrKQ1f += HPJoQA6URLk18nhXva7cbVDKMO[MBHEOqmtX3SPb2whAFr6ul]
	return
def oSpCPgODjwKRkyTtx(Vea0sXycdJ8LFSMzhB5Zt73u2rD,MBHEOqmtX3SPb2whAFr6ul):
	global KGdsq9fgW31RcXomzCxrea,IvUahiecdM8DmJZ5,ssnMlW9pZ2,bJj3qg4XCfGd0,HPJoQA6URLk18nhXva7cbVDKMO,cY1DzUC9nxHgQM4BjIts,bsXtEzrKQ1f,BrCgRhzJ2KXakVq608w9,AXLJu7i8khn951BsFOyZNIEWT2R
	RTr92nPJkjuBoDMbELV8Oa = wwATViQ0xDaoNMEK4v3PIeC8UzZ5(Vea0sXycdJ8LFSMzhB5Zt73u2rD,MBHEOqmtX3SPb2whAFr6ul)
	for zqj2ltB4agIQVifTWcxX7nC in range(1+HPJoQA6URLk18nhXva7cbVDKMO[MBHEOqmtX3SPb2whAFr6ul]//273):
		Q50egF8EqH7mbYWaPpuhJrwcM = []
		rVJj3DRWkaAfqzw5od = cY1DzUC9nxHgQM4BjIts[MBHEOqmtX3SPb2whAFr6ul][0:273]
		for RRSaoMVs1BJdWNEpAP in rVJj3DRWkaAfqzw5od:
			Q50egF8EqH7mbYWaPpuhJrwcM.append(bJj3qg4XCfGd0[MBHEOqmtX3SPb2whAFr6ul][RRSaoMVs1BJdWNEpAP])
		uAkLQ7gEZaIBv6Fyn(RTr92nPJkjuBoDMbELV8Oa,MBHEOqmtX3SPb2whAFr6ul,rVJj3DRWkaAfqzw5od,Q50egF8EqH7mbYWaPpuhJrwcM,jCmv4M3HNPdyaLS,True)
		ssnMlW9pZ2 += len(rVJj3DRWkaAfqzw5od)
		x3G0I9vUCjg(KGdsq9fgW31RcXomzCxrea,75+int(20*ssnMlW9pZ2//bsXtEzrKQ1f),'تخزين القوائم','القائمة رقم:-',str(ssnMlW9pZ2)+' / '+str(bsXtEzrKQ1f))
		if KGdsq9fgW31RcXomzCxrea.iscanceled(): return
		del cY1DzUC9nxHgQM4BjIts[MBHEOqmtX3SPb2whAFr6ul][0:273]
	del bJj3qg4XCfGd0[MBHEOqmtX3SPb2whAFr6ul],cY1DzUC9nxHgQM4BjIts[MBHEOqmtX3SPb2whAFr6ul],HPJoQA6URLk18nhXva7cbVDKMO[MBHEOqmtX3SPb2whAFr6ul]
	return
def U2i5lhIGe8EmckoLY(Vea0sXycdJ8LFSMzhB5Zt73u2rD,bUHVjvzwnyi=True):
	if not Im36vznMobP7WCNfFY2lJZ(Vea0sXycdJ8LFSMzhB5Zt73u2rD,bUHVjvzwnyi): return
	BwSH9qje6tpNEMJyWCz87T = OPEJxmUqr9wAX1i
	U0HdARtn2fcGJjv7aMKg9epBDTlos = wwATViQ0xDaoNMEK4v3PIeC8UzZ5(Vea0sXycdJ8LFSMzhB5Zt73u2rD,'LIVE_ORIGINAL_GROUPED')
	dRbFgAhq7GljwHfJXWuVOi2NrB = wwATViQ0xDaoNMEK4v3PIeC8UzZ5(Vea0sXycdJ8LFSMzhB5Zt73u2rD,'VOD_ORIGINAL_GROUPED')
	fMG40az7RTuNHc6tJji5 = sZHYrLPog4wmuW0ECdc(U0HdARtn2fcGJjv7aMKg9epBDTlos,'int','IGNORED','__COUNT__')
	Jqb5zogxLXOifaeTWwmNCDQ4vYBF = sZHYrLPog4wmuW0ECdc(U0HdARtn2fcGJjv7aMKg9epBDTlos,'int','LIVE_ORIGINAL_GROUPED','__COUNT__')
	IEaCymoO9dVGjZ7Nw = sZHYrLPog4wmuW0ECdc(dRbFgAhq7GljwHfJXWuVOi2NrB,'int','VOD_ORIGINAL_GROUPED','__COUNT__')
	NLoVHtl9jparnA = sZHYrLPog4wmuW0ECdc(U0HdARtn2fcGJjv7aMKg9epBDTlos,'int','LIVE_GROUPED','__COUNT__')
	u4fdoZwiHKyM0Qp2LCWcsgxYSFUJzV = sZHYrLPog4wmuW0ECdc(U0HdARtn2fcGJjv7aMKg9epBDTlos,'int','LIVE_UNKNOWN_GROUPED','__COUNT__')
	FhAwtSKg3bzpXIWGc29TqMkL = sZHYrLPog4wmuW0ECdc(U0HdARtn2fcGJjv7aMKg9epBDTlos,'int','VOD_MOVIES_GROUPED','__COUNT__')
	x0lFhJ5dUjvfEs = sZHYrLPog4wmuW0ECdc(dRbFgAhq7GljwHfJXWuVOi2NrB,'int','VOD_SERIES_GROUPED','__COUNT__')
	A7fOi1rdYbpVySNQ6HmDa5B = sZHYrLPog4wmuW0ECdc(U0HdARtn2fcGJjv7aMKg9epBDTlos,'int','VOD_UNKNOWN_GROUPED','__COUNT__')
	cY1DzUC9nxHgQM4BjIts = sZHYrLPog4wmuW0ECdc(dRbFgAhq7GljwHfJXWuVOi2NrB,'list','VOD_SERIES_GROUPED','__GROUPS__')
	jFVn1GDzgUQbvfa4JpWThBm2Si = []
	for RRSaoMVs1BJdWNEpAP,qsSTC3ZfW1NthKUbHQEnlpP9GY5 in cY1DzUC9nxHgQM4BjIts:
		M0Sn3syBLpqWzhoX9OTYal2u71xV4 = RRSaoMVs1BJdWNEpAP.split('__SERIES__')[1]
		jFVn1GDzgUQbvfa4JpWThBm2Si.append(M0Sn3syBLpqWzhoX9OTYal2u71xV4)
	qGygYXdwVzkcm9HQIF4B = len(jFVn1GDzgUQbvfa4JpWThBm2Si)
	om3XlN9aWpCnAEuYO = int(FhAwtSKg3bzpXIWGc29TqMkL)+int(x0lFhJ5dUjvfEs)+int(A7fOi1rdYbpVySNQ6HmDa5B)+int(u4fdoZwiHKyM0Qp2LCWcsgxYSFUJzV)+int(NLoVHtl9jparnA)
	RuDBlzZQK8ihkY36tf7FjGHvoAST = cdZKMn68Pzg4
	RuDBlzZQK8ihkY36tf7FjGHvoAST += 'قنوات: '+str(NLoVHtl9jparnA)
	RuDBlzZQK8ihkY36tf7FjGHvoAST += '   .   أفلام: '+str(FhAwtSKg3bzpXIWGc29TqMkL)
	RuDBlzZQK8ihkY36tf7FjGHvoAST += '\nمسلسلات: '+str(qGygYXdwVzkcm9HQIF4B)
	RuDBlzZQK8ihkY36tf7FjGHvoAST += '   .   حلقات: '+str(x0lFhJ5dUjvfEs)
	RuDBlzZQK8ihkY36tf7FjGHvoAST += '\nقنوات مجهولة: '+str(u4fdoZwiHKyM0Qp2LCWcsgxYSFUJzV)
	RuDBlzZQK8ihkY36tf7FjGHvoAST += '   .   فيدوهات مجهولة: '+str(A7fOi1rdYbpVySNQ6HmDa5B)
	RuDBlzZQK8ihkY36tf7FjGHvoAST += '\nمجموع القنوات: '+str(Jqb5zogxLXOifaeTWwmNCDQ4vYBF)
	RuDBlzZQK8ihkY36tf7FjGHvoAST += '   .   مجموع الفيديوهات: '+str(IEaCymoO9dVGjZ7Nw)
	RuDBlzZQK8ihkY36tf7FjGHvoAST += '\n\nمجموع المضافة: '+str(om3XlN9aWpCnAEuYO)
	RuDBlzZQK8ihkY36tf7FjGHvoAST += '   .   مجموع المهملة: '+str(fMG40az7RTuNHc6tJji5)
	if bUHVjvzwnyi: NiWSoAmhdkQPlTpneyVzDO8tw9aL('center',cdZKMn68Pzg4,BwSH9qje6tpNEMJyWCz87T,RuDBlzZQK8ihkY36tf7FjGHvoAST)
	I8bqu2jHQXRTf3S = RuDBlzZQK8ihkY36tf7FjGHvoAST.replace('\n\n',ssELJkeScrtni2)
	SsziMZd5UbeL2NRxVpwjO(F0FeocLXmbJhdBwQnS18PCHZIU,'.\tCounts of IPTV videos   Folder: '+Vea0sXycdJ8LFSMzhB5Zt73u2rD+ssELJkeScrtni2+I8bqu2jHQXRTf3S)
	return RuDBlzZQK8ihkY36tf7FjGHvoAST
def m4cprS5FuYxjRH3yiMVKhAqIU8(Vea0sXycdJ8LFSMzhB5Zt73u2rD,bUHVjvzwnyi=True):
	if bUHVjvzwnyi:
		GPQCWezyxpbjhHNXMVEaI4FR = JyLdvftP3CU('center',cdZKMn68Pzg4,cdZKMn68Pzg4,'مسح ملفات ـIPTV','تستطيع في أي وقت الدخول إلى قائمة ـIPTV وجلب ملفات ـIPTV جديدة .. هل تريد الآن مسح الملفات القديمة المخزنة في البرنامج ؟!')
		if GPQCWezyxpbjhHNXMVEaI4FR!=1: return
		EEQgChOkLxAr3Z0FitTWlu58jMsd = gZ9swV4tb1lmTqMxASN8X.replace('___','_'+Vea0sXycdJ8LFSMzhB5Zt73u2rD)
		try: YRESXadfbIy3khwqmL8WC.remove(EEQgChOkLxAr3Z0FitTWlu58jMsd)
		except: pass
	EEQgChOkLxAr3Z0FitTWlu58jMsd = W2EwcUy5Xz.replace('___','_'+Vea0sXycdJ8LFSMzhB5Zt73u2rD)
	try: YRESXadfbIy3khwqmL8WC.remove(EEQgChOkLxAr3Z0FitTWlu58jMsd)
	except: pass
	EEQgChOkLxAr3Z0FitTWlu58jMsd = qha7jkcX9GtvJ4DsZ1.replace('___','_'+Vea0sXycdJ8LFSMzhB5Zt73u2rD)
	try: YRESXadfbIy3khwqmL8WC.remove(EEQgChOkLxAr3Z0FitTWlu58jMsd)
	except: pass
	uVOoSHfqe4WtiF(TV08xYHA2ok,'SECTIONS_IPTV','SECTIONS_IPTV_'+Vea0sXycdJ8LFSMzhB5Zt73u2rD)
	uVOoSHfqe4WtiF(TV08xYHA2ok,'SECTIONS_IPTV','SECTIONS_IPTV_ALL')
	tiuZ61v2BRxSKgJWfpbL0Yq(False)
	SYaTv4t7q0cy96(Vea0sXycdJ8LFSMzhB5Zt73u2rD)
	if bUHVjvzwnyi:
		NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,'تم مسح جميع ملفات ـIPTV')
		XfABsbKWoLhI(False)
	return
def Im36vznMobP7WCNfFY2lJZ(Vea0sXycdJ8LFSMzhB5Zt73u2rD=cdZKMn68Pzg4,bUHVjvzwnyi=True):
	if Vea0sXycdJ8LFSMzhB5Zt73u2rD:
		RTr92nPJkjuBoDMbELV8Oa = wwATViQ0xDaoNMEK4v3PIeC8UzZ5(str(Vea0sXycdJ8LFSMzhB5Zt73u2rD),'DUMMY')
		ZsOUtP3XGW0Mgexzofd9YkFb56S4rE = sZHYrLPog4wmuW0ECdc(RTr92nPJkjuBoDMbELV8Oa,'str','DUMMY','__DUMMY__')
		if ZsOUtP3XGW0Mgexzofd9YkFb56S4rE: return True
	else:
		Vea0sXycdJ8LFSMzhB5Zt73u2rD = '1'
		for ZLQ8R02Aq7U1gKE in range(1,d37Zoe1YJgWbMq+1):
			RTr92nPJkjuBoDMbELV8Oa = wwATViQ0xDaoNMEK4v3PIeC8UzZ5(str(ZLQ8R02Aq7U1gKE),'DUMMY')
			ZsOUtP3XGW0Mgexzofd9YkFb56S4rE = sZHYrLPog4wmuW0ECdc(RTr92nPJkjuBoDMbELV8Oa,'str','DUMMY','__DUMMY__')
			if ZsOUtP3XGW0Mgexzofd9YkFb56S4rE: return True
	if bUHVjvzwnyi:
		NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,'هذا الجزء من البرنامج يحتاج اشتراك IPTV مدفوع من شركة IPTV .. ونوع الرابط المطلوب هو  m3u .. وهذا مثال لتوضيح شكل الرابط المطلوب في هذا البرنامج  '+Gzygq01Kcb9U3+' \n\nhttp://xyz.xyz/get.php?username=xyz&password=xyz&type=m3u_plus '+kH8E2zqNyims6KJfI)
		BwSH9qje6tpNEMJyWCz87T = 'إضافة وتغيير رابط '+G9Gz76P41qQAW2viUsjEymXYOVuBSc[1]+' (مجلد '+G9Gz76P41qQAW2viUsjEymXYOVuBSc[int(Vea0sXycdJ8LFSMzhB5Zt73u2rD)]+')'
		GPQCWezyxpbjhHNXMVEaI4FR = JyLdvftP3CU(cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,BwSH9qje6tpNEMJyWCz87T,'لإضافة رابط IPTV .. أولا أفتح قائمة IPTV .. وثانيا أنقر على إضافة رابط أو اشتراك ـIPTV .. وثالثا أنقر على جلب ملفات ـIPTV \n\n هل تريد إضافة أو تغيير رابط IPTV الآن ؟!')
		if GPQCWezyxpbjhHNXMVEaI4FR==1: S4msZ0wigOJREj3rolfqQGch(Vea0sXycdJ8LFSMzhB5Zt73u2rD)
	return False
def pi7dszu648(AGlajBRVeDYSUwd5qg,Vea0sXycdJ8LFSMzhB5Zt73u2rD=cdZKMn68Pzg4,MBHEOqmtX3SPb2whAFr6ul=cdZKMn68Pzg4,SwDfU9qkrKo6QW2y=cdZKMn68Pzg4):
	if not SwDfU9qkrKo6QW2y: SwDfU9qkrKo6QW2y = '1'
	ohGe84MLmzaQXICbNvcVUkW,X9XExg7ect62uBzjfqhPCyb18,bUHVjvzwnyi = qbIcHCMdkFKn21e(AGlajBRVeDYSUwd5qg)
	if not Im36vznMobP7WCNfFY2lJZ(Vea0sXycdJ8LFSMzhB5Zt73u2rD,bUHVjvzwnyi): return
	if not ohGe84MLmzaQXICbNvcVUkW:
		ohGe84MLmzaQXICbNvcVUkW = BzkmLuvJD9n25Pg()
		if not ohGe84MLmzaQXICbNvcVUkW: return
	QpdACXI5Da34h = [cdZKMn68Pzg4,'LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not MBHEOqmtX3SPb2whAFr6ul:
		if not bUHVjvzwnyi:
			if   '_IPTV-LIVE_' in X9XExg7ect62uBzjfqhPCyb18: MBHEOqmtX3SPb2whAFr6ul = QpdACXI5Da34h[1]
			elif '_IPTV-MOVIES' in X9XExg7ect62uBzjfqhPCyb18: MBHEOqmtX3SPb2whAFr6ul = QpdACXI5Da34h[2]
			elif '_IPTV-SERIES' in X9XExg7ect62uBzjfqhPCyb18: MBHEOqmtX3SPb2whAFr6ul = QpdACXI5Da34h[3]
			else: MBHEOqmtX3SPb2whAFr6ul = QpdACXI5Da34h[0]
		else:
			e0emHnNKBv5 = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			tcxhXCe0Z6EaAyPu = NAfHLMC8Ip64FmT7l5oJWXaq3hK('أختر البحث المناسب', e0emHnNKBv5)
			if tcxhXCe0Z6EaAyPu==-1: return
			MBHEOqmtX3SPb2whAFr6ul = QpdACXI5Da34h[tcxhXCe0Z6EaAyPu]
	ohGe84MLmzaQXICbNvcVUkW = ohGe84MLmzaQXICbNvcVUkW+'_NODIALOGS_'
	if Vea0sXycdJ8LFSMzhB5Zt73u2rD: LMejKcGP5p9QUkrFgqWAVivnNt6yoT(ohGe84MLmzaQXICbNvcVUkW,Vea0sXycdJ8LFSMzhB5Zt73u2rD,MBHEOqmtX3SPb2whAFr6ul,SwDfU9qkrKo6QW2y)
	else:
		for Vea0sXycdJ8LFSMzhB5Zt73u2rD in range(1,d37Zoe1YJgWbMq+1):
			LMejKcGP5p9QUkrFgqWAVivnNt6yoT(ohGe84MLmzaQXICbNvcVUkW,str(Vea0sXycdJ8LFSMzhB5Zt73u2rD),MBHEOqmtX3SPb2whAFr6ul,SwDfU9qkrKo6QW2y)
		USuRxnPlV5.menuItemsLIST[:] = sorted(USuRxnPlV5.menuItemsLIST,reverse=False,key=lambda D8QslnRP0KIkdYcbviAGTSEo7U69z: D8QslnRP0KIkdYcbviAGTSEo7U69z[1].lower())
	return
def LMejKcGP5p9QUkrFgqWAVivnNt6yoT(AGlajBRVeDYSUwd5qg,Vea0sXycdJ8LFSMzhB5Zt73u2rD,MBHEOqmtX3SPb2whAFr6ul=cdZKMn68Pzg4,SwDfU9qkrKo6QW2y=cdZKMn68Pzg4):
	if not SwDfU9qkrKo6QW2y: SwDfU9qkrKo6QW2y = '1'
	ohGe84MLmzaQXICbNvcVUkW,X9XExg7ect62uBzjfqhPCyb18,bUHVjvzwnyi = qbIcHCMdkFKn21e(AGlajBRVeDYSUwd5qg)
	if not Vea0sXycdJ8LFSMzhB5Zt73u2rD: return
	if not Im36vznMobP7WCNfFY2lJZ(Vea0sXycdJ8LFSMzhB5Zt73u2rD,bUHVjvzwnyi): return
	if not ohGe84MLmzaQXICbNvcVUkW:
		ohGe84MLmzaQXICbNvcVUkW = BzkmLuvJD9n25Pg()
		if not ohGe84MLmzaQXICbNvcVUkW: return
	QpdACXI5Da34h = [cdZKMn68Pzg4,'LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not MBHEOqmtX3SPb2whAFr6ul:
		if not bUHVjvzwnyi:
			if   '_IPTV-LIVE_' in X9XExg7ect62uBzjfqhPCyb18: MBHEOqmtX3SPb2whAFr6ul = QpdACXI5Da34h[1]
			elif '_IPTV-MOVIES' in X9XExg7ect62uBzjfqhPCyb18: MBHEOqmtX3SPb2whAFr6ul = QpdACXI5Da34h[2]
			elif '_IPTV-SERIES' in X9XExg7ect62uBzjfqhPCyb18: MBHEOqmtX3SPb2whAFr6ul = QpdACXI5Da34h[3]
			else: MBHEOqmtX3SPb2whAFr6ul = QpdACXI5Da34h[0]
		else:
			e0emHnNKBv5 = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			tcxhXCe0Z6EaAyPu = NAfHLMC8Ip64FmT7l5oJWXaq3hK('أختر البحث المناسب', e0emHnNKBv5)
			if tcxhXCe0Z6EaAyPu==-1: return
			MBHEOqmtX3SPb2whAFr6ul = QpdACXI5Da34h[tcxhXCe0Z6EaAyPu]
	EPIa0wcWlkB3YmRD7MXG1sKiuAy = ohGe84MLmzaQXICbNvcVUkW.lower()
	RTr92nPJkjuBoDMbELV8Oa = wwATViQ0xDaoNMEK4v3PIeC8UzZ5(Vea0sXycdJ8LFSMzhB5Zt73u2rD,'SEARCH')
	iiAOHkqYIRW7Bs46CEj3Layefb2hSP = sZHYrLPog4wmuW0ECdc(RTr92nPJkjuBoDMbELV8Oa,'list','SEARCH',(MBHEOqmtX3SPb2whAFr6ul,EPIa0wcWlkB3YmRD7MXG1sKiuAy))
	if not iiAOHkqYIRW7Bs46CEj3Layefb2hSP:
		cclF9OSIRgsikfwXZn,n9SfaWL451JGCHVmURhueKr8 = [],[]
		if not MBHEOqmtX3SPb2whAFr6ul: tprNzkQVObJZnoLiu = [1,2,3,4,5]
		else: tprNzkQVObJZnoLiu = [QpdACXI5Da34h.index(MBHEOqmtX3SPb2whAFr6ul)]
		for ZoQJArX6xtaIG0MfLnvqEmD in tprNzkQVObJZnoLiu:
			RTr92nPJkjuBoDMbELV8Oa = wwATViQ0xDaoNMEK4v3PIeC8UzZ5(Vea0sXycdJ8LFSMzhB5Zt73u2rD,QpdACXI5Da34h[ZoQJArX6xtaIG0MfLnvqEmD])
			if ZoQJArX6xtaIG0MfLnvqEmD!=3:
				a2a0mpV49WBD5sIFYzU = sZHYrLPog4wmuW0ECdc(RTr92nPJkjuBoDMbELV8Oa,'dict',QpdACXI5Da34h[ZoQJArX6xtaIG0MfLnvqEmD])
				del a2a0mpV49WBD5sIFYzU['__COUNT__']
				del a2a0mpV49WBD5sIFYzU['__GROUPS__']
				del a2a0mpV49WBD5sIFYzU['__SEQUENCED_COLUMNS__']
				cY1DzUC9nxHgQM4BjIts = list(a2a0mpV49WBD5sIFYzU.keys())
				for RRSaoMVs1BJdWNEpAP in cY1DzUC9nxHgQM4BjIts:
					for SUkst0aLFhj,FghljxYu6ZiV7nCmtSUrywKDek,kxY4EfTKobmQJ8OathHI53,qsSTC3ZfW1NthKUbHQEnlpP9GY5 in a2a0mpV49WBD5sIFYzU[RRSaoMVs1BJdWNEpAP]:
						if EPIa0wcWlkB3YmRD7MXG1sKiuAy in FghljxYu6ZiV7nCmtSUrywKDek.lower(): n9SfaWL451JGCHVmURhueKr8.append((FghljxYu6ZiV7nCmtSUrywKDek,kxY4EfTKobmQJ8OathHI53,qsSTC3ZfW1NthKUbHQEnlpP9GY5))
					del a2a0mpV49WBD5sIFYzU[RRSaoMVs1BJdWNEpAP]
				del a2a0mpV49WBD5sIFYzU
			else: cY1DzUC9nxHgQM4BjIts = sZHYrLPog4wmuW0ECdc(RTr92nPJkjuBoDMbELV8Oa,'list',QpdACXI5Da34h[ZoQJArX6xtaIG0MfLnvqEmD],'__GROUPS__')
			for RRSaoMVs1BJdWNEpAP in cY1DzUC9nxHgQM4BjIts:
				try: RRSaoMVs1BJdWNEpAP,qsSTC3ZfW1NthKUbHQEnlpP9GY5 = RRSaoMVs1BJdWNEpAP
				except: qsSTC3ZfW1NthKUbHQEnlpP9GY5 = cdZKMn68Pzg4
				if EPIa0wcWlkB3YmRD7MXG1sKiuAy in RRSaoMVs1BJdWNEpAP.lower():
					if ZoQJArX6xtaIG0MfLnvqEmD!=3: H3rokbwzj5daEcu = RRSaoMVs1BJdWNEpAP
					else:
						hewJPMkX2xfSCAgFlo5b,fHb7iXcpWT1U2sGCJY = RRSaoMVs1BJdWNEpAP.split('__SERIES__')
						if EPIa0wcWlkB3YmRD7MXG1sKiuAy in hewJPMkX2xfSCAgFlo5b.lower(): H3rokbwzj5daEcu = hewJPMkX2xfSCAgFlo5b
						else: H3rokbwzj5daEcu = fHb7iXcpWT1U2sGCJY
					cclF9OSIRgsikfwXZn.append((RRSaoMVs1BJdWNEpAP,H3rokbwzj5daEcu,QpdACXI5Da34h[ZoQJArX6xtaIG0MfLnvqEmD],qsSTC3ZfW1NthKUbHQEnlpP9GY5))
			del cY1DzUC9nxHgQM4BjIts
		cclF9OSIRgsikfwXZn = set(cclF9OSIRgsikfwXZn)
		n9SfaWL451JGCHVmURhueKr8 = set(n9SfaWL451JGCHVmURhueKr8)
		cclF9OSIRgsikfwXZn = sorted(cclF9OSIRgsikfwXZn,reverse=False,key=lambda D8QslnRP0KIkdYcbviAGTSEo7U69z: D8QslnRP0KIkdYcbviAGTSEo7U69z[1])
		n9SfaWL451JGCHVmURhueKr8 = sorted(n9SfaWL451JGCHVmURhueKr8,reverse=False,key=lambda D8QslnRP0KIkdYcbviAGTSEo7U69z: D8QslnRP0KIkdYcbviAGTSEo7U69z[0])
		uAkLQ7gEZaIBv6Fyn(RTr92nPJkjuBoDMbELV8Oa,'SEARCH',(MBHEOqmtX3SPb2whAFr6ul,EPIa0wcWlkB3YmRD7MXG1sKiuAy),(cclF9OSIRgsikfwXZn,n9SfaWL451JGCHVmURhueKr8),jCmv4M3HNPdyaLS)
	else: cclF9OSIRgsikfwXZn,n9SfaWL451JGCHVmURhueKr8 = iiAOHkqYIRW7Bs46CEj3Layefb2hSP
	cY1DzUC9nxHgQM4BjIts = len(cclF9OSIRgsikfwXZn)
	FypbJ0WMOZI = len(n9SfaWL451JGCHVmURhueKr8)
	iQBgv5oEbM6ZFH4U8qtC = int(SwDfU9qkrKo6QW2y)
	q6ki83rAIZtL7Dh0RF = max(0,(iQBgv5oEbM6ZFH4U8qtC-1)*100)
	fNUem0ay4SPOt = max(0,iQBgv5oEbM6ZFH4U8qtC*100)
	JCzj2V0nGX6RwA4 = max(0,q6ki83rAIZtL7Dh0RF-cY1DzUC9nxHgQM4BjIts)
	AecEHsCRSomFUpwWrzM = max(0,fNUem0ay4SPOt-cY1DzUC9nxHgQM4BjIts)
	for RRSaoMVs1BJdWNEpAP,H3rokbwzj5daEcu,s8hDWSzkMKf5730dlFJjYaxprb,qsSTC3ZfW1NthKUbHQEnlpP9GY5 in cclF9OSIRgsikfwXZn[q6ki83rAIZtL7Dh0RF:fNUem0ay4SPOt]:
		zJLApFBcIhnSj('folder',XQgovGj6VkUFxH4a2+H3rokbwzj5daEcu,s8hDWSzkMKf5730dlFJjYaxprb,234,qsSTC3ZfW1NthKUbHQEnlpP9GY5,'1',RRSaoMVs1BJdWNEpAP,cdZKMn68Pzg4,{'folder':Vea0sXycdJ8LFSMzhB5Zt73u2rD})
	del cclF9OSIRgsikfwXZn
	for FghljxYu6ZiV7nCmtSUrywKDek,kxY4EfTKobmQJ8OathHI53,qsSTC3ZfW1NthKUbHQEnlpP9GY5 in n9SfaWL451JGCHVmURhueKr8[JCzj2V0nGX6RwA4:AecEHsCRSomFUpwWrzM]:
		AAeR1YfaTpksgG3Lt6UlKcZMPnV = Aty25FEGpLUbfwKT19vzVm3IsYk(kxY4EfTKobmQJ8OathHI53)
		kuMXTLrvIZGfjCDtA9YNJ5SxQK = 'live'
		if '.mkv' in AAeR1YfaTpksgG3Lt6UlKcZMPnV or 'VOD' in MBHEOqmtX3SPb2whAFr6ul: kuMXTLrvIZGfjCDtA9YNJ5SxQK = 'video'
		zJLApFBcIhnSj(kuMXTLrvIZGfjCDtA9YNJ5SxQK,XQgovGj6VkUFxH4a2+FghljxYu6ZiV7nCmtSUrywKDek,kxY4EfTKobmQJ8OathHI53,235,qsSTC3ZfW1NthKUbHQEnlpP9GY5,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,{'folder':Vea0sXycdJ8LFSMzhB5Zt73u2rD})
	del n9SfaWL451JGCHVmURhueKr8
	BsewTaqSNkcuHhtf8pZvGVD7L(Vea0sXycdJ8LFSMzhB5Zt73u2rD,SwDfU9qkrKo6QW2y,MBHEOqmtX3SPb2whAFr6ul,239,cY1DzUC9nxHgQM4BjIts+FypbJ0WMOZI,ohGe84MLmzaQXICbNvcVUkW+'_NODIALOGS_')
	return
def BsewTaqSNkcuHhtf8pZvGVD7L(Vea0sXycdJ8LFSMzhB5Zt73u2rD,SwDfU9qkrKo6QW2y,MBHEOqmtX3SPb2whAFr6ul,HHrpyfWjGC,om3XlN9aWpCnAEuYO,JAYWBoz54tGw7O):
	if SwDfU9qkrKo6QW2y!='1': zJLApFBcIhnSj('folder',XQgovGj6VkUFxH4a2+'صفحة '+str(1),MBHEOqmtX3SPb2whAFr6ul,HHrpyfWjGC,cdZKMn68Pzg4,str(1),JAYWBoz54tGw7O,cdZKMn68Pzg4,{'folder':Vea0sXycdJ8LFSMzhB5Zt73u2rD})
	if not om3XlN9aWpCnAEuYO: om3XlN9aWpCnAEuYO = 0
	WQMiE9Lpzj34wGbk = int(om3XlN9aWpCnAEuYO/100)+1
	for iQBgv5oEbM6ZFH4U8qtC in range(2,WQMiE9Lpzj34wGbk):
		GXvW7eaHFjyiI6QUJ8brY9pKAs = (iQBgv5oEbM6ZFH4U8qtC%10==0 or int(SwDfU9qkrKo6QW2y)-4<iQBgv5oEbM6ZFH4U8qtC<int(SwDfU9qkrKo6QW2y)+4)
		esqA6aNSBjd5J = (GXvW7eaHFjyiI6QUJ8brY9pKAs and int(SwDfU9qkrKo6QW2y)-40<iQBgv5oEbM6ZFH4U8qtC<int(SwDfU9qkrKo6QW2y)+40)
		if str(iQBgv5oEbM6ZFH4U8qtC)!=SwDfU9qkrKo6QW2y and (iQBgv5oEbM6ZFH4U8qtC%100==0 or esqA6aNSBjd5J):
			zJLApFBcIhnSj('folder',XQgovGj6VkUFxH4a2+'صفحة '+str(iQBgv5oEbM6ZFH4U8qtC),MBHEOqmtX3SPb2whAFr6ul,HHrpyfWjGC,cdZKMn68Pzg4,str(iQBgv5oEbM6ZFH4U8qtC),JAYWBoz54tGw7O,cdZKMn68Pzg4,{'folder':Vea0sXycdJ8LFSMzhB5Zt73u2rD})
	if str(WQMiE9Lpzj34wGbk)!=SwDfU9qkrKo6QW2y: zJLApFBcIhnSj('folder',XQgovGj6VkUFxH4a2+'أخر صفحة '+str(WQMiE9Lpzj34wGbk),MBHEOqmtX3SPb2whAFr6ul,HHrpyfWjGC,cdZKMn68Pzg4,str(WQMiE9Lpzj34wGbk),JAYWBoz54tGw7O,cdZKMn68Pzg4,{'folder':Vea0sXycdJ8LFSMzhB5Zt73u2rD})
	return
def wwATViQ0xDaoNMEK4v3PIeC8UzZ5(Vea0sXycdJ8LFSMzhB5Zt73u2rD,MBHEOqmtX3SPb2whAFr6ul):
	if 'SERIES' in MBHEOqmtX3SPb2whAFr6ul or 'VOD_ORIGINAL' in MBHEOqmtX3SPb2whAFr6ul: RTr92nPJkjuBoDMbELV8Oa = qha7jkcX9GtvJ4DsZ1
	else: RTr92nPJkjuBoDMbELV8Oa = W2EwcUy5Xz
	RTr92nPJkjuBoDMbELV8Oa = RTr92nPJkjuBoDMbELV8Oa.replace('___','_'+Vea0sXycdJ8LFSMzhB5Zt73u2rD)
	return RTr92nPJkjuBoDMbELV8Oa
def AAvHQpkS3dtIbaWxhioMc5mgKFwUE(Vea0sXycdJ8LFSMzhB5Zt73u2rD,MBHEOqmtX3SPb2whAFr6ul,k9U0ol3zPOiDyQ):
	jcidYWSngJx2lphkZN7f5AqRu,AZnTKcDC0twiN2l6Fzxr3f,Szg3qvldoOyU,YsyfvFHASN,ww2AC3SkbFQXc6Pj = EEJjV7pU0Cy9RScBXefYh(Vea0sXycdJ8LFSMzhB5Zt73u2rD)
	if not YsyfvFHASN: return
	pj3iPglDkueR29AH6U = lr845giTQzJ01vqZP(Vea0sXycdJ8LFSMzhB5Zt73u2rD)
	if   MBHEOqmtX3SPb2whAFr6ul=='XTREAM_LIVE_GROUPS': kxY4EfTKobmQJ8OathHI53 = jcidYWSngJx2lphkZN7f5AqRu+'&action=get_live_categories'
	elif MBHEOqmtX3SPb2whAFr6ul=='XTREAM_VOD_GROUPS': kxY4EfTKobmQJ8OathHI53 = jcidYWSngJx2lphkZN7f5AqRu+'&action=get_vod_categories'
	elif MBHEOqmtX3SPb2whAFr6ul=='XTREAM_SERIES_GROUPS': kxY4EfTKobmQJ8OathHI53 = jcidYWSngJx2lphkZN7f5AqRu+'&action=get_series_categories'
	elif MBHEOqmtX3SPb2whAFr6ul=='XTREAM_LIVE_ITEMS': kxY4EfTKobmQJ8OathHI53 = jcidYWSngJx2lphkZN7f5AqRu+'&action=get_live_streams&category_id='+k9U0ol3zPOiDyQ
	elif MBHEOqmtX3SPb2whAFr6ul=='XTREAM_VOD_ITEMS': kxY4EfTKobmQJ8OathHI53 = jcidYWSngJx2lphkZN7f5AqRu+'&action=get_vod_streams&category_id='+k9U0ol3zPOiDyQ
	elif MBHEOqmtX3SPb2whAFr6ul=='XTREAM_SERIES_ITEMS': kxY4EfTKobmQJ8OathHI53 = jcidYWSngJx2lphkZN7f5AqRu+'&action=get_series&category_id='+k9U0ol3zPOiDyQ
	elif MBHEOqmtX3SPb2whAFr6ul=='XTREAM_EPISODES': kxY4EfTKobmQJ8OathHI53 = jcidYWSngJx2lphkZN7f5AqRu+'&action=get_series_info&series_id='+k9U0ol3zPOiDyQ
	else: return
	oyufnwWte9Im4cFA6hSLODiGRMsJx8 = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',kxY4EfTKobmQJ8OathHI53,cdZKMn68Pzg4,pj3iPglDkueR29AH6U,cdZKMn68Pzg4,cdZKMn68Pzg4,'IPTV-XTREAM_MENUS-1st')
	ajEFui1BI6z8RJor = oyufnwWte9Im4cFA6hSLODiGRMsJx8.content
	if xicJPb0AW1nsRfH3kCv7: ajEFui1BI6z8RJor = ajEFui1BI6z8RJor.decode(vczMIlkCAh2u10B3).encode(vczMIlkCAh2u10B3)
	NNRbElkJqHD9mts6KfXIgQv = lMeKd3hC6cmS('list',ajEFui1BI6z8RJor)
	if 'GROUPS' in MBHEOqmtX3SPb2whAFr6ul:
		MBHEOqmtX3SPb2whAFr6ul = MBHEOqmtX3SPb2whAFr6ul.replace('_GROUPS','_ITEMS')
		NNRbElkJqHD9mts6KfXIgQv = sorted(NNRbElkJqHD9mts6KfXIgQv,reverse=False,key=lambda D8QslnRP0KIkdYcbviAGTSEo7U69z: D8QslnRP0KIkdYcbviAGTSEo7U69z['category_name'].lower())
		for RRSaoMVs1BJdWNEpAP in NNRbElkJqHD9mts6KfXIgQv:
			Kk8Hy5cBjOW = RRSaoMVs1BJdWNEpAP['category_id']
			FghljxYu6ZiV7nCmtSUrywKDek = RRSaoMVs1BJdWNEpAP['category_name']
			zJLApFBcIhnSj('folder',XQgovGj6VkUFxH4a2+FghljxYu6ZiV7nCmtSUrywKDek,MBHEOqmtX3SPb2whAFr6ul,285,cdZKMn68Pzg4,cdZKMn68Pzg4,str(Kk8Hy5cBjOW),cdZKMn68Pzg4,{'folder':Vea0sXycdJ8LFSMzhB5Zt73u2rD})
	elif MBHEOqmtX3SPb2whAFr6ul=='XTREAM_SERIES_ITEMS':
		NNRbElkJqHD9mts6KfXIgQv = sorted(NNRbElkJqHD9mts6KfXIgQv,reverse=False,key=lambda D8QslnRP0KIkdYcbviAGTSEo7U69z: D8QslnRP0KIkdYcbviAGTSEo7U69z['name'].lower())
		for WIzqb9YnxoK7NUQfrv40 in NNRbElkJqHD9mts6KfXIgQv:
			FghljxYu6ZiV7nCmtSUrywKDek = WIzqb9YnxoK7NUQfrv40['name']
			cxokMEeWJnSdZGt53qYhI = WIzqb9YnxoK7NUQfrv40['cover']
			Kk8Hy5cBjOW = WIzqb9YnxoK7NUQfrv40['series_id']
			zJLApFBcIhnSj('folder',XQgovGj6VkUFxH4a2+FghljxYu6ZiV7nCmtSUrywKDek,'XTREAM_EPISODES',285,cxokMEeWJnSdZGt53qYhI,cdZKMn68Pzg4,str(Kk8Hy5cBjOW),cdZKMn68Pzg4,{'folder':Vea0sXycdJ8LFSMzhB5Zt73u2rD})
	elif MBHEOqmtX3SPb2whAFr6ul=='XTREAM_EPISODES':
		cxokMEeWJnSdZGt53qYhI = NNRbElkJqHD9mts6KfXIgQv['info']['cover']
		yy0cNBFOGVZh8rIeQ4 = NNRbElkJqHD9mts6KfXIgQv['info']['name']
		yXbI2th1uFv5M30ifcn = NNRbElkJqHD9mts6KfXIgQv['episodes']
		for EvzCeNF0UIHu4D9MqhTa in yXbI2th1uFv5M30ifcn:
			mmSjpdb6c73wDMvze2lgIX = yXbI2th1uFv5M30ifcn[EvzCeNF0UIHu4D9MqhTa]
			for BtUd4vo6ZcVnrbM9k2 in mmSjpdb6c73wDMvze2lgIX:
				FghljxYu6ZiV7nCmtSUrywKDek = BtUd4vo6ZcVnrbM9k2['title']
				tpN3aQdyikTzrXY8RVjuq = ffUFBJQ57j2XgoGeOLn9uwpC.findall('\d+.(S\d+E\d+)',FghljxYu6ZiV7nCmtSUrywKDek,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
				if tpN3aQdyikTzrXY8RVjuq: FghljxYu6ZiV7nCmtSUrywKDek = yy0cNBFOGVZh8rIeQ4+VBpIH2QSmvDGlA6TO3e+tpN3aQdyikTzrXY8RVjuq[0]
				Kk8Hy5cBjOW = BtUd4vo6ZcVnrbM9k2['id']
				niD8tMNCa03E7g4qGKHXhjls5Wkm1 = BtUd4vo6ZcVnrbM9k2['container_extension']
				kxY4EfTKobmQJ8OathHI53 = jcidYWSngJx2lphkZN7f5AqRu.split('/player_api.php')[0]+'/series/'+YsyfvFHASN+KCQExdbYFqM+ww2AC3SkbFQXc6Pj+KCQExdbYFqM+str(Kk8Hy5cBjOW)+'.'+niD8tMNCa03E7g4qGKHXhjls5Wkm1
				zJLApFBcIhnSj('video',XQgovGj6VkUFxH4a2+FghljxYu6ZiV7nCmtSUrywKDek,kxY4EfTKobmQJ8OathHI53,235,cxokMEeWJnSdZGt53qYhI,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,{'folder':Vea0sXycdJ8LFSMzhB5Zt73u2rD})
	elif 'ITEMS' in MBHEOqmtX3SPb2whAFr6ul:
		kuMXTLrvIZGfjCDtA9YNJ5SxQK = 'live' if 'LIVE' in MBHEOqmtX3SPb2whAFr6ul else 'video'
		NNRbElkJqHD9mts6KfXIgQv = sorted(NNRbElkJqHD9mts6KfXIgQv,reverse=False,key=lambda D8QslnRP0KIkdYcbviAGTSEo7U69z: D8QslnRP0KIkdYcbviAGTSEo7U69z['name'].lower())
		for HIAFiSYnaXg in NNRbElkJqHD9mts6KfXIgQv:
			FghljxYu6ZiV7nCmtSUrywKDek = HIAFiSYnaXg['name']
			cxokMEeWJnSdZGt53qYhI = HIAFiSYnaXg['stream_icon']
			Kk8Hy5cBjOW = HIAFiSYnaXg['stream_id']
			try:
				niD8tMNCa03E7g4qGKHXhjls5Wkm1 = HIAFiSYnaXg['container_extension']
				if niD8tMNCa03E7g4qGKHXhjls5Wkm1: niD8tMNCa03E7g4qGKHXhjls5Wkm1 = '.'+niD8tMNCa03E7g4qGKHXhjls5Wkm1
			except: niD8tMNCa03E7g4qGKHXhjls5Wkm1 = cdZKMn68Pzg4
			if HIAFiSYnaXg['stream_type']=='live': bvfP6pcm4enTAQZEUgxoV,II8JeSMC31rx2jF7 = cdZKMn68Pzg4,'live'
			elif HIAFiSYnaXg['stream_type']=='movie': bvfP6pcm4enTAQZEUgxoV,II8JeSMC31rx2jF7 = 'movie/','video'
			kxY4EfTKobmQJ8OathHI53 = jcidYWSngJx2lphkZN7f5AqRu.split('/player_api.php')[0]+KCQExdbYFqM+bvfP6pcm4enTAQZEUgxoV+YsyfvFHASN+KCQExdbYFqM+ww2AC3SkbFQXc6Pj+KCQExdbYFqM+str(Kk8Hy5cBjOW)+niD8tMNCa03E7g4qGKHXhjls5Wkm1
			zJLApFBcIhnSj(kuMXTLrvIZGfjCDtA9YNJ5SxQK,XQgovGj6VkUFxH4a2+FghljxYu6ZiV7nCmtSUrywKDek,kxY4EfTKobmQJ8OathHI53,235,cxokMEeWJnSdZGt53qYhI,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,{'folder':Vea0sXycdJ8LFSMzhB5Zt73u2rD})
	return
def SYaTv4t7q0cy96(Vea0sXycdJ8LFSMzhB5Zt73u2rD):
	NNqDuAfp4amdkLPovXrc02ZYl81 = Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.getSetting('av.language.provider')
	D7fpJ0XmCQTLoMxr6uHZcUPh = Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.getSetting('av.language.code')
	uVOoSHfqe4WtiF(TV08xYHA2ok,'MENUS_CACHE_'+NNqDuAfp4amdkLPovXrc02ZYl81+'_'+D7fpJ0XmCQTLoMxr6uHZcUPh,'%_IP'+Vea0sXycdJ8LFSMzhB5Zt73u2rD+'_%')
	return
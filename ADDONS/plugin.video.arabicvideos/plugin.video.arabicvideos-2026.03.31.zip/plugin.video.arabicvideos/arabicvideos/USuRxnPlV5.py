# -*- coding: utf-8 -*-
import sys as sjVE6XGymcf09qbiKODZdAC
LVpmDXhWH5wGKy1eqMB = sjVE6XGymcf09qbiKODZdAC.version_info [0] == 2
RGEuTe9PD7o45d2v = 2048
r3HIioGW0Nl = 7
def Brz09AF6apy52OuEq1s (ccr3g6sWvxSOqDiLJuF1Vf2KUtG):
	global YzIBLo1J4ZOCEPtjq
	SSzr8EskcFRLobZqtC2QeTyPg4Y = ord (ccr3g6sWvxSOqDiLJuF1Vf2KUtG [-1])
	JIf7wGht4BqbQ5Xik1mYTA3DeLvaPO = ccr3g6sWvxSOqDiLJuF1Vf2KUtG [:-1]
	ZYd0PzhKWmvFN5TfcQI = SSzr8EskcFRLobZqtC2QeTyPg4Y % len (JIf7wGht4BqbQ5Xik1mYTA3DeLvaPO)
	itRzfVamqWwLIynhGpDM4ZUe = JIf7wGht4BqbQ5Xik1mYTA3DeLvaPO [:ZYd0PzhKWmvFN5TfcQI] + JIf7wGht4BqbQ5Xik1mYTA3DeLvaPO [ZYd0PzhKWmvFN5TfcQI:]
	if LVpmDXhWH5wGKy1eqMB:
		MHSngXbpVZde6NiQc9IrCxt78 = unicode () .join ([unichr (ord (Ep0JIWsLABieR) - RGEuTe9PD7o45d2v - (D2bEPIlOQJy4dYntR3MCiKLusT + SSzr8EskcFRLobZqtC2QeTyPg4Y) % r3HIioGW0Nl) for D2bEPIlOQJy4dYntR3MCiKLusT, Ep0JIWsLABieR in enumerate (itRzfVamqWwLIynhGpDM4ZUe)])
	else:
		MHSngXbpVZde6NiQc9IrCxt78 = str () .join ([chr (ord (Ep0JIWsLABieR) - RGEuTe9PD7o45d2v - (D2bEPIlOQJy4dYntR3MCiKLusT + SSzr8EskcFRLobZqtC2QeTyPg4Y) % r3HIioGW0Nl) for D2bEPIlOQJy4dYntR3MCiKLusT, Ep0JIWsLABieR in enumerate (itRzfVamqWwLIynhGpDM4ZUe)])
	return eval (MHSngXbpVZde6NiQc9IrCxt78)
ObuCsdoDtKmhPLSMH8YGan,vbYokBuWlxeLDcdVNM60,J6jL2d7CKE0WA4lBXFPghR5eoxHb=Brz09AF6apy52OuEq1s,Brz09AF6apy52OuEq1s,Brz09AF6apy52OuEq1s
aNdix5gq7yeFHTMWhnzm8pX0Y16,dwiIAcPl04ey7Zv38Mz,zBGPHsxIiQmd7oTSORl9bAynr5kNq=J6jL2d7CKE0WA4lBXFPghR5eoxHb,vbYokBuWlxeLDcdVNM60,ObuCsdoDtKmhPLSMH8YGan
rbUkdYi32PJaRtnxhDvQs,TtyzcuW45VKA,LungQF89BqemOb32jJsZlW=zBGPHsxIiQmd7oTSORl9bAynr5kNq,dwiIAcPl04ey7Zv38Mz,aNdix5gq7yeFHTMWhnzm8pX0Y16
iRfoNckJs7Ibxzh5j92w8DSWF,NV3enkyQ7Rmp2LYAUagsCJz0ZP,HC9xWUMpBQJEuTteAqjd=LungQF89BqemOb32jJsZlW,TtyzcuW45VKA,rbUkdYi32PJaRtnxhDvQs
s8fcjBCSMxzAIkZQbJPga,AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu,liyzjA4RkEb1cT6fr5pGKdWNHOxM=HC9xWUMpBQJEuTteAqjd,NV3enkyQ7Rmp2LYAUagsCJz0ZP,iRfoNckJs7Ibxzh5j92w8DSWF
nfg30bHwd4aNV12SR7UjFck,Rsdai9xIEPcpuBMKOUwkTA05q,KNomgGw1kdMCBH=liyzjA4RkEb1cT6fr5pGKdWNHOxM,AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu,s8fcjBCSMxzAIkZQbJPga
SGazRxP3yBKZ15ILuch,YnHG75e2QWwo,S5fhsRT8JV=KNomgGw1kdMCBH,Rsdai9xIEPcpuBMKOUwkTA05q,nfg30bHwd4aNV12SR7UjFck
WupgNDhcjK1SiYsF5VLGb9w3loJqX,f8Ja1q5eO02B,xN4fKmsnyM3Y2=S5fhsRT8JV,YnHG75e2QWwo,SGazRxP3yBKZ15ILuch
uxE8MyoTRglrcaiQf,aar0zhDnJsOTP7EdgR16HIS29,opyTNwHgfqbZREWKU=xN4fKmsnyM3Y2,f8Ja1q5eO02B,WupgNDhcjK1SiYsF5VLGb9w3loJqX
On1WZJc6dtksqVNgSQ5GBAjuipe,AiCor1fIVTDxQUWwHe9vPR7,tRnTydV03Xfi7rbQ=opyTNwHgfqbZREWKU,aar0zhDnJsOTP7EdgR16HIS29,uxE8MyoTRglrcaiQf
LJPOQNK1mcG,k5oIaYyp2mnrLK49qhzS,zDek1IW37rq6UoKdwyRiAVpF=tRnTydV03Xfi7rbQ,AiCor1fIVTDxQUWwHe9vPR7,On1WZJc6dtksqVNgSQ5GBAjuipe
from dUqF7rBe81 import *
SITESURLS = {
			 KNomgGw1kdMCBH(u"ࠪࡅࡍ࡝ࡁࡌࠩඓ")		:[nfg30bHwd4aNV12SR7UjFck(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡳ࠯ࡣ࡫ࡻࡦࡱࡴࡷ࠰ࡱࡩࡹ࠭ඔ")]
			,uxE8MyoTRglrcaiQf(u"ࠬࡇࡋࡐࡃࡐࠫඕ")		:[AiCor1fIVTDxQUWwHe9vPR7(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢ࡭࠱ࡷࡻ࠵࡯࡭ࡦࠪඖ")]
			,s8fcjBCSMxzAIkZQbJPga(u"ࠧࡂࡍ࡚ࡅࡒ࠭඗")		:[Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤ࡯࠳ࡹࡶࠨ඘")]
			,On1WZJc6dtksqVNgSQ5GBAjuipe(u"ࠩࡄࡏ࡜ࡇࡍࡕࡗࡅࡉࠬ඙")	:[KNomgGw1kdMCBH(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡹ࠮ࡢ࡭ࡺࡥࡲ࠴ࡴࡶࡤࡨࠫක")]
			,uxE8MyoTRglrcaiQf(u"ࠫࡆࡒࡍࡂࡃࡕࡉࡋ࠭ඛ")		:[LJPOQNK1mcG(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡ࡭࡯ࡤࡥࡷ࡫ࡦ࠯ࡥ࡫ࠫග")]
			,zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"࠭ࡁࡍࡏࡖࡘࡇࡇࠧඝ")		:[TtyzcuW45VKA(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡧ࡬࡮ࡵࡷࡦࡦ࠴ࡴࡷࠩඞ")]
			,tRnTydV03Xfi7rbQ(u"ࠨࡃࡑࡍࡒࡋ࡚ࡊࡆࠪඟ")		:[AiCor1fIVTDxQUWwHe9vPR7(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡳ࡯࡭ࡦࡼ࡬ࡨ࠳ࡹࡨࡰࡹࠪච")]
			,k5oIaYyp2mnrLK49qhzS(u"ࠪࡅࡗࡇࡂࡊࡅࡗࡓࡔࡔࡓࠨඡ")	:[opyTNwHgfqbZREWKU(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡣࡵࡥࡧ࡯ࡣ࠮ࡶࡲࡳࡳࡹ࠮ࡤࡱࡰࠫජ")]
			,YnHG75e2QWwo(u"ࠬࡇࡒࡂࡄࡖࡉࡊࡊࠧඣ")		:[HC9xWUMpBQJEuTteAqjd(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡴࡤࡦࡸ࡫ࡥࡥ࠰ࡱࡩࡹ࠭ඤ")]
			,dwiIAcPl04ey7Zv38Mz(u"ࠧࡂ࡛ࡏࡓࡑ࠭ඥ")		:[zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡩ࠳ࡧࡹ࡭ࡱ࡯࠲ࡳ࡫ࡴࠨඦ")]
			,opyTNwHgfqbZREWKU(u"ࠩࡅࡓࡐࡘࡁࠨට")		:[J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸ࡮ࡡࡩ࡫ࡧࡰ࡮ࡼࡥ࠯ࡥࡲࠫඨ")]
			,LungQF89BqemOb32jJsZlW(u"ࠫࡇࡘࡓࡕࡇࡍࠫඩ")		:[ObuCsdoDtKmhPLSMH8YGan(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡢࡳࡵࡷ࡭࡯࠴ࡣࡢ࡯ࠪඪ")]
			,AiCor1fIVTDxQUWwHe9vPR7(u"࠭ࡃࡊࡏࡄ࠸࠵࠶ࠧණ")		:[nfg30bHwd4aNV12SR7UjFck(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡥ࡬ࡱࡦ࠺࠰࠱࠰ࡦࡳࡲ࠭ඬ")]
			,iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠨࡅࡌࡑࡆ࠺ࡐࠨත")		:[iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻ࠳ࡩࡩ࡮ࡣ࠷ࡴ࠳ࡩ࡯࡮ࠩථ")]
			,ObuCsdoDtKmhPLSMH8YGan(u"ࠪࡇࡎࡓࡁ࠵ࡗࠪද")		:[LungQF89BqemOb32jJsZlW(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࠷ࡣࡪ࡯ࡤ࠸ࡺ࠴ࡣࡰ࡯ࠪධ")]
			,J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠬࡉࡉࡎࡃࡄࡆࡉࡕࠧන")		:[liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡤ࡯࠱ࡧ࡮ࡳࡡ࠴ࡤࡧࡳ࠳ࡩ࡯࡮ࠩ඲")]
			,f8Ja1q5eO02B(u"ࠧࡄࡋࡐࡅࡈࡒࡕࡃࠩඳ")		:[NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡦ࡭࡮ࡳࡡࡤ࡮ࡸࡦ࠳ࡩ࡬ࡶࡤࠪප")]
			,k5oIaYyp2mnrLK49qhzS(u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅ࡛ࡔࡘࡋࠨඵ")	:[iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡹࡼࡶ࠯ࡥ࡬ࡱࡦࡩ࡬ࡶࡤ࠱ࡷ࡭ࡵࡰࠨබ")]
			,liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠫࡈࡏࡍࡂࡈࡄࡒࡘ࠭භ")		:[KNomgGw1kdMCBH(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡧ࡮ࡳࡡࡧࡣࡱࡷ࠳ࡩ࡯ࠨම")]
			,aNdix5gq7yeFHTMWhnzm8pX0Y16(u"࠭ࡃࡊࡏࡄࡊࡗࡋࡅࠨඹ")		:[iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡥ࡬ࡱࡦ࡬ࡲࡦࡧ࠱࡭ࡳ࡬࡯ࠨය")]
			,TtyzcuW45VKA(u"ࠨࡅࡌࡑࡆࡒࡉࡈࡊࡗࠫර")	:[rbUkdYi32PJaRtnxhDvQs(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡱࡾ࠳ࡣࡪ࡯ࡤ࠲ࡳ࡫ࡴࠨ඼")]
			,aar0zhDnJsOTP7EdgR16HIS29(u"ࠪࡇࡎࡓࡁࡏࡑ࡚ࠫල")		:[tRnTydV03Xfi7rbQ(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡩࡩ࡮ࡣࡱࡳࡼ࠴ࡣࡤࠩ඾")]
			,opyTNwHgfqbZREWKU(u"ࠬࡉࡉࡎࡃ࡚ࡆࡆ࡙ࠧ඿")		:[J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡮ࡻࡦ࡭ࡲࡧ࠮ࡤࡥࠪව")]
			,s8fcjBCSMxzAIkZQbJPga(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒࠬශ")	:[zDek1IW37rq6UoKdwyRiAVpF(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱ࠲ࡨࡵ࡭ࠨෂ"),iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡫ࡷࡧࡰࡩࡳ࡯࠲ࡦࡶࡩ࠯ࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠴ࡣࡰ࡯ࠪස"),opyTNwHgfqbZREWKU(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸ࡫ࡡࡳࡥ࡫࠲ࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯࠰ࡦࡳࡲ࠭හ")]
			,liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠫࡉࡘࡁࡎࡃࡆࡅࡋࡋࠧළ")	:[HC9xWUMpBQJEuTteAqjd(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷ࠳࠷࠱ࡨࡷࡧ࡭ࡢࡥࡤࡪࡪ࠳ࡴࡷ࠰ࡦࡳࡲ࠭ෆ")]
			,xN4fKmsnyM3Y2(u"࠭ࡄࡓࡃࡐࡅࡘ࠽ࠧ෇")		:[zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡦࡵࡥࡲࡧࡳ࠸࠰ࡱࡩࡹ࠭෈")]
			,nfg30bHwd4aNV12SR7UjFck(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠳ࠪ෉")		:[dwiIAcPl04ey7Zv38Mz(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩ࡬ࡿࡢࡦࡵࡷ࠲࡫ࡻ࡮ࠨ්")]
			,xN4fKmsnyM3Y2(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠶ࠬ෋")		:[nfg30bHwd4aNV12SR7UjFck(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫ࡧࡺࡤࡨࡷࡹ࠴࡮ࡦࡹࡶࠫ෌")]
			,xN4fKmsnyM3Y2(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠹ࠧ෍")		:[TtyzcuW45VKA(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡪࡧࡪࡽࡧ࡫ࡳࡵ࠰ࡥ࡭ࡩ࠭෎")]
			,rbUkdYi32PJaRtnxhDvQs(u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠵ࠩා")		:[On1WZJc6dtksqVNgSQ5GBAjuipe(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨ࡫ࡾ࠳ࡢࡦࡵࡷ࠲ࡳ࡫ࡴࠨැ")]
			,TtyzcuW45VKA(u"ࠩࡈࡋ࡞ࡊࡅࡂࡆࠪෑ")		:[ObuCsdoDtKmhPLSMH8YGan(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪ࡭ࡹࡥࡧࡤࡨ࠳ࡲࡩࡷࡧࠪි")]
			,AiCor1fIVTDxQUWwHe9vPR7(u"ࠫࡊࡒࡃࡊࡐࡈࡑࡆ࠭ී")		:[zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥ࡭ࡥ࡬ࡲࡪࡳࡡ࠯ࡥࡲࡱࠬු")]
			,s8fcjBCSMxzAIkZQbJPga(u"࠭ࡅࡍࡋࡉ࡚ࡎࡊࡅࡐࠩ෕")	:[LungQF89BqemOb32jJsZlW(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡵ࡫ࡥ࡭࡯ࡤ࠯ࡧ࡯࡭࡫࠴࡮ࡦࡹࡶࠫූ")]
			,AiCor1fIVTDxQUWwHe9vPR7(u"ࠨࡈࡄࡆࡗࡇࡋࡂࠩ෗")		:[aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡪࡦࡨࡲ࡬ࡣ࠱ࡧࡴࡳࠧෘ")]
			,aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠪࡊࡆࡐࡅࡓࡕࡋࡓ࡜࠭ෙ")	:[LungQF89BqemOb32jJsZlW(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡬ࡡ࡫ࡧࡵ࠲ࡸ࡮࡯ࡸࠩේ")]
			,iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠬࡌࡁࡓࡇࡖࡏࡔ࠭ෛ")		:[AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡷ࡫ࡳ࠲࡫ࡧࡲࡦࡵ࡮ࡳ࠳ࡴࡥࡵࠩො")]
			,KNomgGw1kdMCBH(u"ࠧࡇࡃࡖࡉࡑࡎࡄ࠳ࠩෝ")		:[LungQF89BqemOb32jJsZlW(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡷࡱࡧ࠮ࡧࡣࡶࡩࡱ࡮ࡤ࠯ࡥ࡯ࡳࡺࡪࠧෞ")]
			,HC9xWUMpBQJEuTteAqjd(u"ࠩࡉࡓࡘ࡚ࡁࠨෟ")		:[HC9xWUMpBQJEuTteAqjd(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡫ࡵࡳࡵࡣ࠰ࡸࡻ࠴ࡷࡦࡤࡶ࡭ࡹ࡫ࠧ෠")]
			,nfg30bHwd4aNV12SR7UjFck(u"ࠫࡋ࡛ࡎࡐࡐࡗ࡚ࠬ෡")		:[iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡧ࠯ࡣ࡯ࡱࡪࡹࡨ࡬ࡣ࡫࠲ࡳ࡫ࡴࠨ෢")]
			,S5fhsRT8JV(u"࠭ࡆࡖࡕࡋࡅࡗ࡚ࡖࠨ෣")		:[nfg30bHwd4aNV12SR7UjFck(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡤ࠱ࡪࡺࡹࡨࡢࡴ࠰ࡸࡻ࠴ࡣࡰ࡯ࠪ෤")]
			,NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠨࡈࡘࡗࡍࡇࡒࡗࡋࡇࡉࡔ࠭෥")	:[vbYokBuWlxeLDcdVNM60(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡷ࠳࡬ࡵࡴࡪࡤࡶ࠳ࡼࡩࡥࡧࡲࠫ෦")]
			,HC9xWUMpBQJEuTteAqjd(u"ࠪࡌࡆࡒࡁࡄࡋࡐࡅࠬ෧")		:[TtyzcuW45VKA(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡮ࡡ࡭ࡣࡦ࡭ࡲࡧ࠮࡮ࡧࡧ࡭ࡦ࠭෨")]
			,liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠬࡏࡆࡊࡎࡐࠫ෩")		:[LJPOQNK1mcG(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡴ࠱࡭࡫࡯࡬࡮ࡶࡹ࠲࡮ࡸࠧ෪"),opyTNwHgfqbZREWKU(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡱ࠲࡮࡬ࡩ࡭࡯ࡷࡺ࠳࡯ࡲࠨ෫"),AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡩࡥ࠳࡯ࡦࡪ࡮ࡰࡸࡻ࠴ࡩࡳࠩ෬"),rbUkdYi32PJaRtnxhDvQs(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡪࡦ࠸࠮ࡪࡨ࡬ࡰࡲࡺࡶ࠯࡫ࡵࠫ෭"),AiCor1fIVTDxQUWwHe9vPR7(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠽࠸࠴࠱࠺࠲࠱࠶࠹࠴࠱࠳࠴ࠪ෮")]
			,WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠫࡐࡇࡒࡃࡃࡏࡅ࡙࡜ࠧ෯")	:[s8fcjBCSMxzAIkZQbJPga(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡢࡴࡥࡥࡱࡧ࠭ࡵࡸ࠱࡭ࡶ࠭෰")]
			,tRnTydV03Xfi7rbQ(u"࠭ࡋࡂࡖࡎࡓ࡙࡚ࡖࠨ෱")		:[iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭࡬ࡸࡰࡵࡴ࠯ࡥࡤࡱࠬෲ")]
			,S5fhsRT8JV(u"ࠨࡍࡌࡖࡒࡇࡌࡌࠩෳ")		:[ObuCsdoDtKmhPLSMH8YGan(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯࡮ࡸ࡭ࡢ࡮࡮࠲ࡴࡸࡧࠨ෴")]
			,xN4fKmsnyM3Y2(u"ࠪࡐࡆࡘࡏ࡛ࡃࠪ෵")		:[dwiIAcPl04ey7Zv38Mz(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡲࡡࡳࡱࡽࡥ࠳࡯࡮࡬ࠩ෶")]
			,dwiIAcPl04ey7Zv38Mz(u"ࠬࡒࡏࡅ࡛ࡑࡉ࡙࠭෷")		:[zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡭ࡱࡧࡽࡳ࡫ࡴ࠯ࡨࡸࡲࠬ෸")]
			,opyTNwHgfqbZREWKU(u"ࠧࡎࡃࡖࡅ࡛ࡏࡄࡆࡑࠪ෹")	:[LungQF89BqemOb32jJsZlW(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨࡲ࠳ࡳࡡࡴࡣ࠱ࡲࡪࡽࡳࠨ෺")]
			,vbYokBuWlxeLDcdVNM60(u"ࠩࡓࡅࡓࡋࡔࠨ෻")		:[LungQF89BqemOb32jJsZlW(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡻࡼࡽ࠮ࡱࡣࡱࡩࡹ࠴ࡣࡰ࠰࡬ࡰࠬ෼")]
			,LungQF89BqemOb32jJsZlW(u"ࠫࡗࡋࡌࡆࡃࡖࡉࡘ࠭෽")		:[opyTNwHgfqbZREWKU(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡵࡸࡶ࡬࡫࠮ࡴࡪ࠲࡯ࡴࡪࡩ࠰ࡧࡰࡥࡩࡥࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷ࠴ࡵ࡬ࡥ࠱࡬ࡲࡩ࡫ࡸ࠯ࡪࡷࡱࡱ࠭෾")]
			,aar0zhDnJsOTP7EdgR16HIS29(u"࠭ࡓࡆࡔࡌࡉࡘ࡚ࡉࡎࡇࠪ෿")	:[s8fcjBCSMxzAIkZQbJPga(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡤࡤ࠲ࡸ࡫ࡲࡪࡧࡶࡸ࡮ࡳࡥ࠯ࡥࡤࡱࠬ฀")]
			,On1WZJc6dtksqVNgSQ5GBAjuipe(u"ࠨࡕࡋࡅࡍࡏࡄ࠵ࡗࠪก")		:[nfg30bHwd4aNV12SR7UjFck(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡷ࡭ࡧࡨࡩ࡫ࡨࡨ࠹ࡻ࠮࡯ࡧࡷࠫข")]
			,ObuCsdoDtKmhPLSMH8YGan(u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙࠷࠭ฃ")	:[aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹࡨࡢࡪ࡬ࡨ࠹ࡻ࠮ࡧࡱࡵࡹࡲ࠭ค")]
			,dwiIAcPl04ey7Zv38Mz(u"࡙ࠬࡈࡂࡊࡌࡈࡓࡋࡗࡔࠩฅ")	:[dwiIAcPl04ey7Zv38Mz(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡳࡦ࠱ࡷ࡭࠺ࡵ࠯ࡰࡨࡻࡸ࠭ฆ")]
			,LJPOQNK1mcG(u"ࠧࡔࡊࡒࡊࡍࡇࠧง")		:[opyTNwHgfqbZREWKU(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡶ࡬ࡴ࡬ࡨࡢ࠰ࡷࡺࠬจ")]
			,NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠩࡖࡌࡔࡕࡆࡎࡃ࡛ࠫฉ")		:[LungQF89BqemOb32jJsZlW(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸ࡮࡯ࡰࡨࡰࡥࡽ࠴ࡣࡰ࡯ࠪช"),S5fhsRT8JV(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹࡴࡢࡶ࡬ࡧ࠳ࡹࡨࡰࡱࡩࡱࡦࡾ࠮ࡤࡱࡰࠫซ"),nfg30bHwd4aNV12SR7UjFck(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡩࡱࡲࡪࡲࡧࡸ࠯ࡣࡽࡹࡷ࡫ࡥࡥࡩࡨ࠲ࡳ࡫ࡴࠨฌ")]
			,zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"࠭ࡓࡉࡑࡒࡊࡓࡋࡔࠨญ")		:[nfg30bHwd4aNV12SR7UjFck(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡶ࠲ࡸ࡮࡯ࡰࡨࡱࡩࡹ࠴࡯࡯࡮࡬ࡲࡪ࠭ฎ")]
			,nfg30bHwd4aNV12SR7UjFck(u"ࠨࡖࡌࡏࡆࡇࡔࠨฏ")		:[NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡸ࡮ࡱࡡࡢࡶ࠱ࡲࡪࡺࠧฐ")]
			,iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠪࡘ࡛ࡌࡕࡏࠩฑ")		:[aar0zhDnJsOTP7EdgR16HIS29(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹ࠮ࡵࡸࡩࡹࡳ࠴࡭ࡦࠩฒ")]
			,s8fcjBCSMxzAIkZQbJPga(u"ࠬ࡜ࡁࡓࡄࡒࡒࠬณ")		:[nfg30bHwd4aNV12SR7UjFck(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡮࠰ࡹࡥࡷࡨ࡯࡯࠰ࡦࡥࡲ࠭ด")]
			,YnHG75e2QWwo(u"ࠧࡗࡋࡇࡉࡔࡔࡓࡂࡇࡐࠫต")	:[uxE8MyoTRglrcaiQf(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡹ࡭ࡩ࡫࡯࠯ࡰࡶࡥࡪࡳ࠮࡯ࡧࡷࠫถ")]
			,Rsdai9xIEPcpuBMKOUwkTA05q(u"࡚ࠩࡉࡈࡏࡍࡂ࠳ࠪท")		:[S5fhsRT8JV(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼ࡫ࡣࡪ࡯ࡤ࠲ࡩ࡯ࡲࡦࡥࡷࠫธ")]
			,zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"ࠫ࡜ࡋࡃࡊࡏࡄ࠶ࠬน")		:[AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡦࡥ࡬ࡱࡦ࠴ࡡࡤࠩบ")]
			,SGazRxP3yBKZ15ILuch(u"࡙࠭ࡂࡓࡒࡘࠬป")		:[dwiIAcPl04ey7Zv38Mz(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡻ࠱ࡽࡦࡷ࡯ࡵ࠰ࡷࡺࠬผ")]
			,YnHG75e2QWwo(u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩฝ")		:[f8Ja1q5eO02B(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡥࡲࡱࠬพ")]
			,vbYokBuWlxeLDcdVNM60(u"ࠪ࡝࡙ࡈ࡟ࡄࡊࡄࡒࡓࡋࡌࡔࠩฟ")	:[aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡧࡴࡳࠧภ")]
			,S5fhsRT8JV(u"ࠬࡏࡐࡕࡘࠪม")			:[cdZKMn68Pzg4]
			,LJPOQNK1mcG(u"࠭ࡍ࠴ࡗࠪย")			:[cdZKMn68Pzg4]
			,f8Ja1q5eO02B(u"ࠧࡓࡇࡓࡓࡘ࠭ร")		:[TtyzcuW45VKA(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡳ࡫ࡴ࡭࡫ࡩࡽ࠳ࡧࡰࡱ࠱ࡎࡓࡉࡏࡒࡆࡒࡒ࠳ࡆࡊࡄࡐࡐࡖ࠳ࡦࡪࡤࡰࡰࡶ࠲ࡽࡳ࡬ࠨฤ"),nfg30bHwd4aNV12SR7UjFck(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡴࡥࡵ࡮࡬ࡪࡾ࠴ࡡࡱࡲ࠲ࡏࡔࡊࡉࡓࡇࡓࡓ࠴ࡇࡄࡅࡑࡑࡗ࠶࠾࠯ࡢࡦࡧࡳࡳࡹ࠱࠹࠰ࡻࡱࡱ࠭ล"),nfg30bHwd4aNV12SR7UjFck(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴࡮ࡦࡶ࡯࡭࡫ࡿ࠮ࡢࡲࡳ࠳ࡐࡕࡄࡊࡔࡈࡔࡔ࠵ࡁࡅࡆࡒࡒࡘ࠷࠹࠰ࡣࡧࡨࡴࡴࡳ࠲࠻࠱ࡼࡲࡲࠧฦ")]
			,AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"ࠫࡗࡋࡐࡐࡕࡢࡆࡐࡖ࠱ࠨว")	:[zDek1IW37rq6UoKdwyRiAVpF(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡧࡪࡶ࡫ࡹࡧ࠴ࡣࡰ࡯࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠵ࡋࡐࡆࡌ࠳ࡷࡧࡷ࠰ࡴࡨࡪࡸ࠵ࡨࡦࡣࡧࡷ࠴ࡳࡡࡴࡶࡨࡶ࠴ࡇࡄࡅࡑࡑࡗ࠴ࡧࡤࡥࡱࡱࡷ࠳ࡾ࡭࡭ࠩศ"),dwiIAcPl04ey7Zv38Mz(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡨ࡫ࡷ࡬ࡺࡨ࠮ࡤࡱࡰ࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠯ࡌࡑࡇࡍ࠴ࡸࡡࡸ࠱ࡵࡩ࡫ࡹ࠯ࡩࡧࡤࡨࡸ࠵࡭ࡢࡵࡷࡩࡷ࠵ࡁࡅࡆࡒࡒࡘ࠷࠸࠰ࡣࡧࡨࡴࡴࡳ࠲࠺࠱ࡼࡲࡲࠧษ"),J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡩ࡬ࡸ࡭ࡻࡢ࠯ࡥࡲࡱ࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠰ࡍࡒࡈࡎ࠵ࡲࡢࡹ࠲ࡶࡪ࡬ࡳ࠰ࡪࡨࡥࡩࡹ࠯࡮ࡣࡶࡸࡪࡸ࠯ࡂࡆࡇࡓࡓ࡙࠱࠺࠱ࡤࡨࡩࡵ࡮ࡴ࠳࠼࠲ࡽࡳ࡬ࠨส")]
			,iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠨࡔࡈࡔࡔ࡙࡟ࡃࡍࡓ࠶ࠬห")	:[SGazRxP3yBKZ15ILuch(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡲࡦࡲࡲ࠲ࡺࡱ࠮ࡵࡱ࠲ࡅࡉࡊࡏࡏࡕ࠲ࡥࡩࡪ࡯࡯ࡵ࠱ࡼࡲࡲࠧฬ"),Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡳࡧࡳࡳ࠳ࡻ࡫࠯ࡶࡲ࠳ࡆࡊࡄࡐࡐࡖ࠵࠽࠵ࡡࡥࡦࡲࡲࡸ࠷࠸࠯ࡺࡰࡰࠬอ"),aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡴࡨࡴࡴ࠴ࡵ࡬࠰ࡷࡳ࠴ࡇࡄࡅࡑࡑࡗ࠶࠿࠯ࡢࡦࡧࡳࡳࡹ࠱࠺࠰ࡻࡱࡱ࠭ฮ")]
			,AiCor1fIVTDxQUWwHe9vPR7(u"ࠬࡘࡅࡑࡑࡖࡣࡇࡑࡐ࠴ࠩฯ")	:[aar0zhDnJsOTP7EdgR16HIS29(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡶࡪࡶ࡯࠯࡯ࡲࡳࡴ࠴ࡣࡰ࡯࠲ࡅࡉࡊࡏࡏࡕ࠲ࡥࡩࡪ࡯࡯ࡵ࠱ࡼࡲࡲࠧะ"),liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡷ࡫ࡰࡰ࠰ࡰࡳࡴࡵ࠮ࡤࡱࡰ࠳ࡆࡊࡄࡐࡐࡖ࠵࠽࠵ࡡࡥࡦࡲࡲࡸ࠷࠸࠯ࡺࡰࡰࠬั"),HC9xWUMpBQJEuTteAqjd(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮ࡸࡥࡱࡱ࠱ࡱࡴࡵ࡯࠯ࡥࡲࡱ࠴ࡇࡄࡅࡑࡑࡗ࠶࠿࠯ࡢࡦࡧࡳࡳࡹ࠱࠺࠰ࡻࡱࡱ࠭า")]
			,zDek1IW37rq6UoKdwyRiAVpF(u"ࠩࡎࡓࡉࡏ࡟ࡔࡑࡘࡖࡈࡋࡓࠨำ")	:[YnHG75e2QWwo(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡹࡵࡳࡩࡨ࠲ࡸ࡮࠯࡬ࡱࡧ࡭ࠬิ"),aar0zhDnJsOTP7EdgR16HIS29(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲࡯ࡴࡪࡩࠨี"),vbYokBuWlxeLDcdVNM60(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠯ࡲࡼࡸ࡭ࡵ࡮ࡢࡰࡼࡻ࡭࡫ࡲࡦ࠰ࡦࡳࡲ࠵࡫ࡰࡦ࡬ࠫึ")]
			,AiCor1fIVTDxQUWwHe9vPR7(u"࠭ࡆࡊࡎࡈࡗࡤ࡙ࡏࡖࡔࡆࡉࡘ࠭ื"):[S5fhsRT8JV(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡱࡩࡹࡲࡩࡧࡻ࠱ࡥࡵࡶุࠧ")]
			,f8Ja1q5eO02B(u"ࠨࡍࡒࡈࡎࡋࡍࡂࡆࡢࡅࡕࡖูࠧ")	:[zDek1IW37rq6UoKdwyRiAVpF(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡷ࡭ࡳࡿ࠮ࡤࡥ࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨฺࠬ"),s8fcjBCSMxzAIkZQbJPga(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴ࠴࠳࠵࠽࠴ࡦࡸࡵ࠱ࡷࡹࡵࡲࡦࠩ฻")]
			}
if hiuZa0PIsErm6UC7:
	SITESURLS[zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"ࠫࡕ࡟ࡔࡉࡑࡑࠫ฼")]      = [S5fhsRT8JV(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡸࡨࡶࡨ࡫࡬࠯ࡣࡳࡴ࠴ࡲࡩࡴࡶࡳࡰࡦࡿࠧ฽"),WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵ࡵࡴࡣࡪࡩࡷ࡫ࡰࡰࡴࡷࠫ฾"),rbUkdYi32PJaRtnxhDvQs(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡺࡪࡸࡣࡦ࡮࠱ࡥࡵࡶ࠯ࡴࡧࡱࡨࡪࡳࡡࡪ࡮ࠪ฿"),tRnTydV03Xfi7rbQ(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡻ࡫ࡲࡤࡧ࡯࠲ࡦࡶࡰ࠰ࡩࡨࡸࡲ࡫ࡳࡴࡣࡪࡩࡸ࠭เ"),TtyzcuW45VKA(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡼࡥࡳࡥࡨࡰ࠳ࡧࡰࡱ࠱ࡪࡩࡹ࡯ࡳ࡭ࡣࡰ࡭ࡨ࠭แ"),LungQF89BqemOb32jJsZlW(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲࡫ࡪࡺࡱࡶࡧࡶࡸ࡮ࡵ࡮ࡴࠩโ"),LJPOQNK1mcG(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡷࡧࡵࡧࡪࡲ࠮ࡢࡲࡳ࠳࡬࡫ࡴ࡬ࡰࡲࡻࡳ࡫ࡲࡳࡱࡵࡷࠬใ"),rbUkdYi32PJaRtnxhDvQs(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡸࡨࡶࡨ࡫࡬࠯ࡣࡳࡴ࠴ࡩࡡࡱࡶࡦ࡬ࡦ࠭ไ"),zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵ࡴࡦࡵࡷ࡭ࡳ࡭ࠧๅ"),tRnTydV03Xfi7rbQ(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡺࡪࡸࡣࡦ࡮࠱ࡥࡵࡶ࠯ࡨࡧࡷࡩࡽࡺࡲࡢࡲࡼࡸ࡭ࡵ࡮ࡤࡱࡧࡩࠬๆ"),f8Ja1q5eO02B(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡻ࡫ࡲࡤࡧ࡯࠲ࡦࡶࡰ࠰ࡧࡻࡩࡨࡻࡴࡦ࡬ࡶࠫ็"),rbUkdYi32PJaRtnxhDvQs(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡼࡥࡳࡥࡨࡰ࠳ࡧࡰࡱ࠱ࡺࡩࡧࡩࡡࡤࡪࡨ่ࠫ")]
	SITESURLS[SGazRxP3yBKZ15ILuch(u"ࠪࡔ࡞࡚ࡈࡐࡐࡢࡆࡐࡖ࠱ࠨ้")] = [rbUkdYi32PJaRtnxhDvQs(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠯ࡲࡼࡸ࡭ࡵ࡮ࡢࡰࡼࡻ࡭࡫ࡲࡦ࠰ࡦࡳࡲ࠵࡬ࡪࡵࡷࡴࡱࡧࡹࠨ๊"),nfg30bHwd4aNV12SR7UjFck(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠰ࡳࡽࡹ࡮࡯࡯ࡣࡱࡽࡼ࡮ࡥࡳࡧ࠱ࡧࡴࡳ࠯ࡶࡵࡤ࡫ࡪࡸࡥࡱࡱࡵࡸ๋ࠬ"),NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠱ࡴࡾࡺࡨࡰࡰࡤࡲࡾࡽࡨࡦࡴࡨ࠲ࡨࡵ࡭࠰ࡵࡨࡲࡩ࡫࡭ࡢ࡫࡯ࠫ์"),vbYokBuWlxeLDcdVNM60(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠲ࡵࡿࡴࡩࡱࡱࡥࡳࡿࡷࡩࡧࡵࡩ࠳ࡩ࡯࡮࠱ࡪࡩࡹࡳࡥࡴࡵࡤ࡫ࡪࡹࠧํ"),zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠳ࡶࡹࡵࡪࡲࡲࡦࡴࡹࡸࡪࡨࡶࡪ࠴ࡣࡰ࡯࠲࡫ࡪࡺࡩࡴ࡮ࡤࡱ࡮ࡩࠧ๎"),vbYokBuWlxeLDcdVNM60(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠴ࡰࡺࡶ࡫ࡳࡳࡧ࡮ࡺࡹ࡫ࡩࡷ࡫࠮ࡤࡱࡰ࠳࡬࡫ࡴࡲࡷࡨࡷࡹ࡯࡯࡯ࡵࠪ๏"),nfg30bHwd4aNV12SR7UjFck(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠮ࡱࡻࡷ࡬ࡴࡴࡡ࡯ࡻࡺ࡬ࡪࡸࡥ࠯ࡥࡲࡱ࠴࡭ࡥࡵ࡭ࡱࡳࡼࡴࡥࡳࡴࡲࡶࡸ࠭๐"),LJPOQNK1mcG(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠯ࡲࡼࡸ࡭ࡵ࡮ࡢࡰࡼࡻ࡭࡫ࡲࡦ࠰ࡦࡳࡲ࠵ࡣࡢࡲࡷࡧ࡭ࡧࠧ๑"),aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠰ࡳࡽࡹ࡮࡯࡯ࡣࡱࡽࡼ࡮ࡥࡳࡧ࠱ࡧࡴࡳ࠯ࡵࡧࡶࡸ࡮ࡴࡧࠨ๒"),aar0zhDnJsOTP7EdgR16HIS29(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠱ࡴࡾࡺࡨࡰࡰࡤࡲࡾࡽࡨࡦࡴࡨ࠲ࡨࡵ࡭࠰ࡩࡨࡸࡪࡾࡴࡳࡣࡳࡽࡹ࡮࡯࡯ࡥࡲࡨࡪ࠭๓"),LungQF89BqemOb32jJsZlW(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠲ࡵࡿࡴࡩࡱࡱࡥࡳࡿࡷࡩࡧࡵࡩ࠳ࡩ࡯࡮࠱ࡨࡼࡪࡩࡵࡵࡧ࡭ࡷࠬ๔"),opyTNwHgfqbZREWKU(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠳ࡶࡹࡵࡪࡲࡲࡦࡴࡹࡸࡪࡨࡶࡪ࠴ࡣࡰ࡯࠲ࡻࡪࡨࡣࡢࡥ࡫ࡩࠬ๕")]
	SITESURLS[YnHG75e2QWwo(u"ࠩࡓ࡝࡙ࡎࡏࡏࡡࡅࡏࡕ࠸ࠧ๖")] = [LungQF89BqemOb32jJsZlW(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡷࡪࡸࡶࡦࡴ࠴࠲ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡦࡳࡧࡨࡨࡩࡴࡳ࠯ࡱࡵ࡫࠴ࡲࡩࡴࡶࡳࡰࡦࡿࠧ๗"),ObuCsdoDtKmhPLSMH8YGan(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡸ࡫ࡲࡷࡧࡵ࠵࠳ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡧࡴࡨࡩࡩࡪ࡮ࡴ࠰ࡲࡶ࡬࠵ࡵࡴࡣࡪࡩࡷ࡫ࡰࡰࡴࡷࠫ๘"),uxE8MyoTRglrcaiQf(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡹࡥࡳࡸࡨࡶ࠶࠴࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡨࡵࡩࡪࡪࡤ࡯ࡵ࠱ࡳࡷ࡭࠯ࡴࡧࡱࡨࡪࡳࡡࡪ࡮ࠪ๙"),AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡳࡦࡴࡹࡩࡷ࠷࠮࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡩࡶࡪ࡫ࡤࡥࡰࡶ࠲ࡴࡸࡧ࠰ࡩࡨࡸࡲ࡫ࡳࡴࡣࡪࡩࡸ࠭๚"),AiCor1fIVTDxQUWwHe9vPR7(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡴࡧࡵࡺࡪࡸ࠱࠯࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡪࡷ࡫ࡥࡥࡦࡱࡷ࠳ࡵࡲࡨ࠱ࡪࡩࡹ࡯ࡳ࡭ࡣࡰ࡭ࡨ࠭๛"),s8fcjBCSMxzAIkZQbJPga(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡵࡨࡶࡻ࡫ࡲ࠲࠰࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲࡫ࡸࡥࡦࡦࡧࡲࡸ࠴࡯ࡳࡩ࠲࡫ࡪࡺࡱࡶࡧࡶࡸ࡮ࡵ࡮ࡴࠩ๜"),iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡶࡩࡷࡼࡥࡳ࠳࠱࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳࡬ࡲࡦࡧࡧࡨࡳࡹ࠮ࡰࡴࡪ࠳࡬࡫ࡴ࡬ࡰࡲࡻࡳ࡫ࡲࡳࡱࡵࡷࠬ๝"),vbYokBuWlxeLDcdVNM60(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡷࡪࡸࡶࡦࡴ࠴࠲ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡦࡳࡧࡨࡨࡩࡴࡳ࠯ࡱࡵ࡫࠴ࡩࡡࡱࡶࡦ࡬ࡦ࠭๞"),S5fhsRT8JV(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡸ࡫ࡲࡷࡧࡵ࠵࠳ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡧࡴࡨࡩࡩࡪ࡮ࡴ࠰ࡲࡶ࡬࠵ࡴࡦࡵࡷ࡭ࡳ࡭ࠧ๟"),AiCor1fIVTDxQUWwHe9vPR7(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡹࡥࡳࡸࡨࡶ࠶࠴࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡨࡵࡩࡪࡪࡤ࡯ࡵ࠱ࡳࡷ࡭࠯ࡨࡧࡷࡩࡽࡺࡲࡢࡲࡼࡸ࡭ࡵ࡮ࡤࡱࡧࡩࠬ๠"),KNomgGw1kdMCBH(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡳࡦࡴࡹࡩࡷ࠷࠮࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡩࡶࡪ࡫ࡤࡥࡰࡶ࠲ࡴࡸࡧ࠰ࡧࡻࡩࡨࡻࡴࡦ࡬ࡶࠫ๡"),s8fcjBCSMxzAIkZQbJPga(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡴࡧࡵࡺࡪࡸ࠱࠯࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡪࡷ࡫ࡥࡥࡦࡱࡷ࠳ࡵࡲࡨ࠱ࡺࡩࡧࡩࡡࡤࡪࡨࠫ๢")]
	SITESURLS[f8Ja1q5eO02B(u"ࠨࡒ࡜ࡘࡍࡕࡎࡠࡄࡎࡔ࠸࠭๣")] = [f8Ja1q5eO02B(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡺࡱ࠮ࡵࡱ࠲ࡰ࡮ࡹࡴࡱ࡮ࡤࡽࠬ๤"),iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡻ࡫࠯ࡶࡲ࠳ࡺࡹࡡࡨࡧࡵࡩࡵࡵࡲࡵࠩ๥"),dwiIAcPl04ey7Zv38Mz(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡵ࡬࠰ࡷࡳ࠴ࡹࡥ࡯ࡦࡨࡱࡦ࡯࡬ࠨ๦"),SGazRxP3yBKZ15ILuch(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡶ࡭࠱ࡸࡴ࠵ࡧࡦࡶࡰࡩࡸࡹࡡࡨࡧࡶࠫ๧"),f8Ja1q5eO02B(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡷ࡮࠲ࡹࡵ࠯ࡨࡧࡷ࡭ࡸࡲࡡ࡮࡫ࡦࠫ๨"),s8fcjBCSMxzAIkZQbJPga(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡸ࡯࠳ࡺ࡯࠰ࡩࡨࡸࡶࡻࡥࡴࡶ࡬ࡳࡳࡹࠧ๩"),uxE8MyoTRglrcaiQf(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡹࡰ࠴ࡴࡰ࠱ࡪࡩࡹࡱ࡮ࡰࡹࡱࡩࡷࡸ࡯ࡳࡵࠪ๪"),AiCor1fIVTDxQUWwHe9vPR7(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡺࡱ࠮ࡵࡱ࠲ࡧࡦࡶࡴࡤࡪࡤࠫ๫"),ObuCsdoDtKmhPLSMH8YGan(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡻ࡫࠯ࡶࡲ࠳ࡹ࡫ࡳࡵ࡫ࡱ࡫ࠬ๬"),dwiIAcPl04ey7Zv38Mz(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡵ࡬࠰ࡷࡳ࠴࡭ࡥࡵࡧࡻࡸࡷࡧࡰࡺࡶ࡫ࡳࡳࡩ࡯ࡥࡧࠪ๭"),f8Ja1q5eO02B(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡶ࡭࠱ࡸࡴ࠵ࡥࡹࡧࡦࡹࡹ࡫ࡪࡴࠩ๮"),f8Ja1q5eO02B(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡷ࡮࠲ࡹࡵ࠯ࡸࡧࡥࡧࡦࡩࡨࡦࠩ๯")]
else:
	SITESURLS[zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"ࠧࡑ࡛ࡗࡌࡔࡔࠧ๰")]      = [Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱࡯࡭ࡸࡺࡰ࡭ࡣࡼࠫ๱"),tRnTydV03Xfi7rbQ(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡹࡸࡧࡧࡦࡴࡨࡴࡴࡸࡴࠨ๲"),NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡸ࡫࡮ࡥࡧࡰࡥ࡮ࡲࠧ๳"),k5oIaYyp2mnrLK49qhzS(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵ࡯ࡨࡷࡸࡧࡧࡦࡵࠪ๴"),opyTNwHgfqbZREWKU(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶ࡬ࡷࡱࡧ࡭ࡪࡥࠪ๵"),uxE8MyoTRglrcaiQf(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ࠭๶"),LJPOQNK1mcG(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸࡰࡴ࡯ࡸࡰࡨࡶࡷࡵࡲࡴࠩ๷"),S5fhsRT8JV(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡦࡥࡵࡺࡣࡩࡣࠪ๸"),k5oIaYyp2mnrLK49qhzS(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡸࡪࡹࡴࡪࡰࡪࠫ๹"),f8Ja1q5eO02B(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴࡦࡺࡷࡶࡦࡶࡹࡵࡪࡲࡲࡨࡵࡤࡦࠩ๺"),HC9xWUMpBQJEuTteAqjd(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡫ࡸࡦࡥࡸࡸࡪࡰࡳࠨ๻"),zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡷࡦࡤࡦࡥࡨ࡮ࡥࠨ๼")]
	SITESURLS[S5fhsRT8JV(u"࠭ࡐ࡚ࡖࡋࡓࡓࡥࡂࡌࡒ࠴ࠫ๽")] = [tRnTydV03Xfi7rbQ(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰࡮࡬ࡷࡹࡶ࡬ࡢࡻࠪ๾"),NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡸࡷࡦ࡭ࡥࡳࡧࡳࡳࡷࡺࠧ๿"),xN4fKmsnyM3Y2(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡷࡪࡴࡤࡦ࡯ࡤ࡭ࡱ࠭຀"),YnHG75e2QWwo(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴ࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩກ"),xN4fKmsnyM3Y2(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵ࡫ࡶࡰࡦࡳࡩࡤࠩຂ"),tRnTydV03Xfi7rbQ(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶࡴࡹࡪࡹࡴࡪࡱࡱࡷࠬ຃"),uxE8MyoTRglrcaiQf(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷ࡯ࡳࡵࡷ࡯ࡧࡵࡶࡴࡸࡳࠨຄ"),LJPOQNK1mcG(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡥࡤࡴࡹࡩࡨࡢࠩ຅"),dwiIAcPl04ey7Zv38Mz(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡷࡩࡸࡺࡩ࡯ࡩࠪຆ"),liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺࡥࡹࡶࡵࡥࡵࡿࡴࡩࡱࡱࡧࡴࡪࡥࠨງ"),WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡪࡾࡥࡤࡷࡷࡩ࡯ࡹࠧຈ"),Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡽࡥࡣࡥࡤࡧ࡭࡫ࠧຉ")]
	SITESURLS[xN4fKmsnyM3Y2(u"ࠬࡖ࡙ࡕࡊࡒࡒࡤࡈࡋࡑ࠴ࠪຊ")] = [S5fhsRT8JV(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯࡭࡫ࡶࡸࡵࡲࡡࡺࠩ຋"),rbUkdYi32PJaRtnxhDvQs(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡷࡶࡥ࡬࡫ࡲࡦࡲࡲࡶࡹ࠭ຌ"),S5fhsRT8JV(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡶࡩࡳࡪࡥ࡮ࡣ࡬ࡰࠬຍ"),liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺ࡭ࡦࡵࡶࡥ࡬࡫ࡳࠨຎ"),KNomgGw1kdMCBH(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴࡪࡵ࡯ࡥࡲ࡯ࡣࠨຏ"),xN4fKmsnyM3Y2(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵࡳࡸࡩࡸࡺࡩࡰࡰࡶࠫຐ"),Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶ࡮ࡲࡴࡽ࡮ࡦࡴࡵࡳࡷࡹࠧຑ"),tRnTydV03Xfi7rbQ(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡤࡣࡳࡸࡨ࡮ࡡࠨຒ"),NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡶࡨࡷࡹ࡯࡮ࡨࠩຓ"),ObuCsdoDtKmhPLSMH8YGan(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹ࡫ࡸࡵࡴࡤࡴࡾࡺࡨࡰࡰࡦࡳࡩ࡫ࠧດ"),NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡩࡽ࡫ࡣࡶࡶࡨ࡮ࡸ࠭ຕ"),f8Ja1q5eO02B(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡼ࡫ࡢࡤࡣࡦ࡬ࡪ࠭ຖ")]
	SITESURLS[LJPOQNK1mcG(u"ࠫࡕ࡟ࡔࡉࡑࡑࡣࡇࡑࡐ࠴ࠩທ")] = [ObuCsdoDtKmhPLSMH8YGan(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵࡬ࡪࡵࡷࡴࡱࡧࡹࠨຘ"),aNdix5gq7yeFHTMWhnzm8pX0Y16(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡶࡵࡤ࡫ࡪࡸࡥࡱࡱࡵࡸࠬນ"),AiCor1fIVTDxQUWwHe9vPR7(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡵࡨࡲࡩ࡫࡭ࡢ࡫࡯ࠫບ"),vbYokBuWlxeLDcdVNM60(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹࡳࡥࡴࡵࡤ࡫ࡪࡹࠧປ"),iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺࡩࡴ࡮ࡤࡱ࡮ࡩࠧຜ"),HC9xWUMpBQJEuTteAqjd(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴࡲࡷࡨࡷࡹ࡯࡯࡯ࡵࠪຝ"),tRnTydV03Xfi7rbQ(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵ࡭ࡱࡳࡼࡴࡥࡳࡴࡲࡶࡸ࠭ພ"),rbUkdYi32PJaRtnxhDvQs(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡣࡢࡲࡷࡧ࡭ࡧࠧຟ"),tRnTydV03Xfi7rbQ(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡵࡧࡶࡸ࡮ࡴࡧࠨຠ"),opyTNwHgfqbZREWKU(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸࡪࡾࡴࡳࡣࡳࡽࡹ࡮࡯࡯ࡥࡲࡨࡪ࠭ມ"),xN4fKmsnyM3Y2(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡨࡼࡪࡩࡵࡵࡧ࡭ࡷࠬຢ"),liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡻࡪࡨࡣࡢࡥ࡫ࡩࠬຣ")]
api_python_actions = [Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠪࡐࡎ࡙ࡔࡑࡎࡄ࡝ࠬ຤"),AiCor1fIVTDxQUWwHe9vPR7(u"ࠫࡗࡋࡐࡐࡔࡗࡗࠬລ"),KNomgGw1kdMCBH(u"ࠬࡋࡍࡂࡋࡏࡗࠬ຦"),SGazRxP3yBKZ15ILuch(u"࠭ࡍࡆࡕࡖࡅࡌࡋࡓࠨວ"),rbUkdYi32PJaRtnxhDvQs(u"ࠧࡊࡕࡏࡅࡒࡏࡃࡔࠩຨ"),WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠨࡓࡘࡉࡘ࡚ࡉࡐࡐࡖࠫຩ"),AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"ࠩࡎࡒࡔ࡝ࡎࡆࡔࡕࡓࡗ࡙ࠧສ"),On1WZJc6dtksqVNgSQ5GBAjuipe(u"ࠪࡇࡆࡖࡔࡄࡊࡄࠫຫ"),LungQF89BqemOb32jJsZlW(u"࡙ࠫࡋࡓࡕࡋࡑࡋࠬຬ"),zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"ࠬࡋࡘࡕࡔࡄࡔ࡞࡚ࡈࡐࡐࡆࡓࡉࡋࠧອ"),opyTNwHgfqbZREWKU(u"࠭ࡅ࡙ࡇࡆ࡙࡙ࡋࡊࡔࠩຮ"),xN4fKmsnyM3Y2(u"ࠧࡘࡇࡅࡇࡆࡉࡈࡆࠩຯ")]
api_repos_actions = [J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠨࡃࡇࡈࡔࡔࡓࠨະ"),YnHG75e2QWwo(u"ࠩࡄࡈࡉࡕࡎࡔ࠳࠻ࠫັ"),iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠪࡅࡉࡊࡏࡏࡕ࠴࠽ࠬາ")]
non_videos_actions = [xN4fKmsnyM3Y2(u"ࠫࡆࡒࡌࠨຳ"),dwiIAcPl04ey7Zv38Mz(u"ࠬࡖ࡙ࡕࡊࡒࡒࠬິ"),NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"࠭ࡉࡏࡕࡗࡅࡑࡒࠧີ"),nfg30bHwd4aNV12SR7UjFck(u"ࠧࡎࡇࡗࡖࡔࡖࡏࡍࡋࡖࠫຶ"),zDek1IW37rq6UoKdwyRiAVpF(u"ࠨࡔࡈࡔࡔ࡙ࠧື"),uxE8MyoTRglrcaiQf(u"ࠩࡇࡓࡓࡇࡔࡊࡑࡑࡗຸࠬ"),rbUkdYi32PJaRtnxhDvQs(u"ࠪࡇࡆࡖࡔࡄࡊࡄࡍࡉູ࠭"),liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠫࡈࡇࡐࡕࡅࡋࡅ࡙ࡕࡋࡆࡐ຺ࠪ"),HC9xWUMpBQJEuTteAqjd(u"ࠬࡉࡁࡑࡖࡆࡌࡆࡍࡅࡕࡋࡇࠫົ"),nfg30bHwd4aNV12SR7UjFck(u"࠭ࡓࡊࡖࡈࡗ࡚ࡘࡌࡔࠩຼ")]+api_python_actions+api_repos_actions
RlZN1M72iH9vU3C8 = ksTLSoVGg0ht
EXB156kCy3JW7U8gfqhGiwlov = IZQbmFzLHDtXfc
UZOwXToGvJnEqB4tgczAS2hHu = ksTLSoVGg0ht
tbo8MkxlHv9qwdP6gI1rJzOV3Na = ksTLSoVGg0ht
avprivsnorestrict = ksTLSoVGg0ht
avprivslongperiod = ksTLSoVGg0ht
resolveonly = ksTLSoVGg0ht
xUMtw80gPFOkSKNb7podmjzE = ksTLSoVGg0ht
ALLOW_DNS_FIX = RRAmELdrBNQGixkaTlC8ozVFe
ALLOW_PROXY_FIX = RRAmELdrBNQGixkaTlC8ozVFe
ALLOW_SHOWDIALOGS_FIX = RRAmELdrBNQGixkaTlC8ozVFe
menuItemsLIST = []
SEND_THESE_EVENTS = []
SAVED_FORWARDS = {}
menuItemsDICT = {}
BADSCRAPERS = []
WEBCACHEDATA = {}
BADWEBSITES = [SGazRxP3yBKZ15ILuch(u"ࠧࡇࡗࡖࡌࡆࡘࡔࡗࠩຽ"),rbUkdYi32PJaRtnxhDvQs(u"ࠨࡆࡕࡅࡒࡇࡃࡂࡈࡈࠫ຾"),TtyzcuW45VKA(u"ࠩࡆࡍࡒࡇ࠴࠱࠲ࠪ຿"),HC9xWUMpBQJEuTteAqjd(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠸ࠬເ"),AiCor1fIVTDxQUWwHe9vPR7(u"ࠫࡑࡇࡒࡐ࡜ࡄࠫແ"),SGazRxP3yBKZ15ILuch(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠷ࠧໂ"),zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"࡙࠭ࡂࡓࡒࡘࠬໃ"),WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠧࡗࡃࡕࡆࡔࡔࠧໄ"),rbUkdYi32PJaRtnxhDvQs(u"ࠨࡊࡄࡐࡆࡉࡉࡎࡃࠪ໅"),nfg30bHwd4aNV12SR7UjFck(u"ࠩࡓࡅࡓࡋࡔࠨໆ"),s8fcjBCSMxzAIkZQbJPga(u"ࠪࡗࡍࡇࡂࡂࡍࡄࡘ࡞࠭໇")]
BADWEBSITES += [S5fhsRT8JV(u"ࠫࡋࡇࡂࡓࡃࡎࡅ່ࠬ"),aar0zhDnJsOTP7EdgR16HIS29(u"ࠬࡋࡌࡊࡈ࡙ࡍࡉࡋࡏࠨ້"),tRnTydV03Xfi7rbQ(u"࠭ࡃࡊࡏࡄࡒࡔ࡝໊ࠧ")]
BADCOMMONIDS = [xN4fKmsnyM3Y2(u"ࠧ࠺࠻࠼࠽࠲࠿࠹࠺࠻࠰࠽࠾࠿࠹࠮࠻࠼࠽࠾࠳࠰࠱࠲࠳໋ࠫ"),NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠨ࠻࠼࠼࠽࠳࠷࠸࠸࠹࠱࠺࠻࠴࠵࠯࠶࠷࠷࠸࠭࠳࠲࠻࠺ࠬ໌")]
GEOLOCATION_DATA = cdZKMn68Pzg4
AV_CLIENT_IDS = cdZKMn68Pzg4
DNS_SERVERS = [LJPOQNK1mcG(u"ࠩ࠴࠲࠶࠴࠱࠯࠳ࠪໍ"),nfg30bHwd4aNV12SR7UjFck(u"ࠪ࠼࠳࠾࠮࠹࠰࠻ࠫ໎"),J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠫ࠶࠴࠰࠯࠲࠱࠵ࠬ໏"),AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"ࠬ࠾࠮࠹࠰࠷࠲࠹࠭໐"),HC9xWUMpBQJEuTteAqjd(u"࠭࠲࠱࠺࠱࠺࠼࠴࠲࠳࠴࠱࠶࠷࠸ࠧ໑"),liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠧ࠳࠲࠻࠲࠻࠽࠮࠳࠴࠳࠲࠷࠸࠰ࠨ໒")]
busydialog_active = ksTLSoVGg0ht
dns_succeeded_urls = []
scrapers_succeeded = ksTLSoVGg0ht
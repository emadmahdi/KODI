# -*- coding: utf-8 -*-
from RgJNGc7YMP import *
UkXlAzsMcamKJrEIgnxi6bWh = 'ARABSEED'
headers = {'User-Agent':knzwM2WCl7jAex9H4YFva()}
nc3GLkA65oxOd = '_ARS_'
cDTdfqVAF0BLGiX364IEwaZbr = USuRxnPlV5.SITESURLS[UkXlAzsMcamKJrEIgnxi6bWh][0]
cJWUPuDGM0Yybv5a9KnIrVzhH78 = ['رمضان','الرئيسية','المضاف حديثاً','مصارعه','اعلن معنا – For ads','موبايلات','برامج كمبيوتر','العاب كمبيوتر','اسلاميات','اخرى','اقسام اخري','اشتراكات']
def HHN5EpbszV3iA2m89hGSQjaPgUZy(mode,url,text):
	if   mode==250: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = kUq58vC7x9hWma164JejMKQ()
	elif mode==251: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = GDQUH4fN02sIt81mAcY(url,text)
	elif mode==252: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = RPZbqous7rtdy56LeI18Cv04AKHW(url)
	elif mode==253: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = yIZWSuMpvs3(url)
	elif mode==254: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = XxcpMKIUzr0sVDngR(url,'CATEGORIES___'+text)
	elif mode==255: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = XxcpMKIUzr0sVDngR(url,'FILTERS___'+text)
	elif mode==259: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = z4hetAJw3NaT9ROjG6xbZ5CHlW81(text)
	else: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = False
	return xsGUcR3ef6glKY5hQwpFXEaSt2mrIz
def kUq58vC7x9hWma164JejMKQ():
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(r43t1YI9deXA5N,'GET',cDTdfqVAF0BLGiX364IEwaZbr+'/main',cdZKMn68Pzg4,headers,cdZKMn68Pzg4,cdZKMn68Pzg4,'ARABSEED-MENU-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'بحث في الموقع',cdZKMn68Pzg4,259,cdZKMn68Pzg4,cdZKMn68Pzg4,'_REMEMBERRESULTS_')
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'فلتر محدد',cDTdfqVAF0BLGiX364IEwaZbr+'/category/اخرى',254)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'فلتر كامل',cDTdfqVAF0BLGiX364IEwaZbr+'/category/اخرى',255)
	zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'المميزة',cDTdfqVAF0BLGiX364IEwaZbr+'/main',251,cdZKMn68Pzg4,cdZKMn68Pzg4,'featured_main')
	zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+'احدث الافلام',cDTdfqVAF0BLGiX364IEwaZbr+'/main',251,cdZKMn68Pzg4,cdZKMn68Pzg4,'new_movies')
	zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+'احدث الحلقات',cDTdfqVAF0BLGiX364IEwaZbr+'/main',251,cdZKMn68Pzg4,cdZKMn68Pzg4,'new_episodes')
	zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	ll9vYSyie5kwbR16U0a2K = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"menu__bar hide__md"(.*?)</div>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	PfGSURJ9jeNtx7FX = ll9vYSyie5kwbR16U0a2K[nnsBpJv6XL3OzHoe4Vuhr]
	zaUqdBJDmY = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?<span>(.*?)<',PfGSURJ9jeNtx7FX,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	for c0cDhidBlOn7,title in zaUqdBJDmY:
		if '/category/' not in c0cDhidBlOn7: continue
		title = gbd90SjF2mZqf81IRDaTwJkWu(title)
		if title not in cJWUPuDGM0Yybv5a9KnIrVzhH78 and title!=cdZKMn68Pzg4:
			if 'http' not in c0cDhidBlOn7: c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr+c0cDhidBlOn7
			zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+title,c0cDhidBlOn7,251)
	return OO1cj2REUZHJ8x5V
def oQF2hgjusp8Ne(url,type):
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',url,cdZKMn68Pzg4,headers,cdZKMn68Pzg4,cdZKMn68Pzg4,'ARABSEED-SUBMENU-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	if 'class="SliderInSection' in OO1cj2REUZHJ8x5V: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'الأكثر مشاهدة',url,251,cdZKMn68Pzg4,cdZKMn68Pzg4,'most')
	if 'class="MainSlides' in OO1cj2REUZHJ8x5V: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'المميزة',url,251,cdZKMn68Pzg4,cdZKMn68Pzg4,'featured')
	if 'class="LinksList' in OO1cj2REUZHJ8x5V:
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="LinksList(.*?)</ul>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if ppvsMqCHf8SEzxQg:
			KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
			if len(ppvsMqCHf8SEzxQg)>1 and type=='new_episodes': KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[1]
			items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)"(.*?)</a>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			for c0cDhidBlOn7,title in items:
				UHXfFEWmlxMAnzju4 = ffUFBJQ57j2XgoGeOLn9uwpC.findall('</i>(.*?)<span>(.*?)<',title,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
				try: O0Ftx1MjvKl = UHXfFEWmlxMAnzju4[0][0].replace(ssELJkeScrtni2,cdZKMn68Pzg4).strip(VBpIH2QSmvDGlA6TO3e)
				except: O0Ftx1MjvKl = cdZKMn68Pzg4
				try: NJdmDUfLgXRY4Iti = UHXfFEWmlxMAnzju4[0][1].replace(ssELJkeScrtni2,cdZKMn68Pzg4).strip(VBpIH2QSmvDGlA6TO3e)
				except: NJdmDUfLgXRY4Iti = cdZKMn68Pzg4
				UHXfFEWmlxMAnzju4 = O0Ftx1MjvKl+VBpIH2QSmvDGlA6TO3e+NJdmDUfLgXRY4Iti
				if '<strong>' in title:
					hObrNWozwt = ffUFBJQ57j2XgoGeOLn9uwpC.findall('</i>(.*?)<',title,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
					if hObrNWozwt: UHXfFEWmlxMAnzju4 = hObrNWozwt[0]
				if not UHXfFEWmlxMAnzju4:
					hObrNWozwt = ffUFBJQ57j2XgoGeOLn9uwpC.findall('alt="(.*?)"',title,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
					if hObrNWozwt: UHXfFEWmlxMAnzju4 = hObrNWozwt[0]
				if UHXfFEWmlxMAnzju4:
					if 'key=' in c0cDhidBlOn7: type = c0cDhidBlOn7.split('key=')[1]
					else: type = 'newest'
					UHXfFEWmlxMAnzju4 = UHXfFEWmlxMAnzju4.strip(VBpIH2QSmvDGlA6TO3e)
					zJLApFBcIhnSj('folder',nc3GLkA65oxOd+UHXfFEWmlxMAnzju4,c0cDhidBlOn7,251,cdZKMn68Pzg4,cdZKMn68Pzg4,type)
	return
def GDQUH4fN02sIt81mAcY(url,VS3jbIxtKQ):
	pOaMLH2bhdNnkz0fWDI,data,items = 'GET',cdZKMn68Pzg4,[]
	if VS3jbIxtKQ=='filters':
		if '?' in url:
			sCnJbTExYfN,H3F607d1jsXEnMvor2 = 'POST',{}
			HOCWKhxITtulVGX,hXu08Aat2cymHMVSIJ = url.split('?')
			LrPZs7iUEO9AkKV4gfIcoxQqn2 = hXu08Aat2cymHMVSIJ.split('&')
			for FTYWLlCaGDuxyzZpS3B in LrPZs7iUEO9AkKV4gfIcoxQqn2:
				key,value = FTYWLlCaGDuxyzZpS3B.split('=')
				H3F607d1jsXEnMvor2[key] = value
			if LrPZs7iUEO9AkKV4gfIcoxQqn2: pOaMLH2bhdNnkz0fWDI,url,data = sCnJbTExYfN,HOCWKhxITtulVGX,H3F607d1jsXEnMvor2
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,pOaMLH2bhdNnkz0fWDI,url,data,headers,cdZKMn68Pzg4,cdZKMn68Pzg4,'ARABSEED-TITLES-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	if VS3jbIxtKQ=='filters': ppvsMqCHf8SEzxQg = [OO1cj2REUZHJ8x5V]
	elif 'featured' in VS3jbIxtKQ: ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"swiper-wrapper"(.*?)</section>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	elif VS3jbIxtKQ=='new_movies': ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('<b>احدث الافلام</b>(.*?)</section>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	elif VS3jbIxtKQ=='new_episodes': ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('<b>احدث الحلقات</b>(.*?)</section>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	elif VS3jbIxtKQ=='most': ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="SliderInSection(.*?)class="LinksList',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	else: ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"blocks__section(.*?)"paginate"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if 'featured' in VS3jbIxtKQ:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
	else: KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
	items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"item__contents.*?href="(.*?)".*? title="(.*?)".*?src="(.*?)"',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if not items: items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="([^"]*)" title="([^"]*)".*?src="(.*?)"',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	KRmzvoWYyxfXw37SEh1Q = []
	for c0cDhidBlOn7,title,y90BoFz8MA1ZThaSC2ILXHiK3OY6w in items:
		if 'WWE' in title: continue
		title = gbd90SjF2mZqf81IRDaTwJkWu(title)
		if 'الحلقة' in title:
			E0w56WHxZPYGVvnTQ4O2t1C8DAjq = ffUFBJQ57j2XgoGeOLn9uwpC.findall('(.*?) الحلقة \d+',title,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			if E0w56WHxZPYGVvnTQ4O2t1C8DAjq:
				title = '_MOD_' + E0w56WHxZPYGVvnTQ4O2t1C8DAjq[0]
				if title not in KRmzvoWYyxfXw37SEh1Q:
					KRmzvoWYyxfXw37SEh1Q.append(title)
					zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,253,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
			else: zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,252,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
		elif '/selary/' in c0cDhidBlOn7 or 'مسلسل' in title:
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,253,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
		else:
			zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,252,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
	if not VS3jbIxtKQ or VS3jbIxtKQ in ['search','filters']:
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"paginate"(.*?)</section>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if ppvsMqCHf8SEzxQg:
			KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
			items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)">(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			for c0cDhidBlOn7,title in items:
				title = gbd90SjF2mZqf81IRDaTwJkWu(title)
				zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'صفحة '+title,c0cDhidBlOn7,251,cdZKMn68Pzg4,cdZKMn68Pzg4,VS3jbIxtKQ)
	return
def yIZWSuMpvs3(url):
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',url,cdZKMn68Pzg4,headers,cdZKMn68Pzg4,cdZKMn68Pzg4,'ARABSEED-EPISODES-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"poster__single".*?src="(.*?)".*?alt="(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if not items: return
	y90BoFz8MA1ZThaSC2ILXHiK3OY6w,name = items[0]
	if 'الحلقة' in name: name = name.split('الحلقة')[0].strip(VBpIH2QSmvDGlA6TO3e)
	elif 'حلقة' in name: name = name.split('حلقة')[0].strip(VBpIH2QSmvDGlA6TO3e)
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"episodes__list boxs__wrapper(.*?)</ul>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?"epi__num">.*?<b>(.*?)</b>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,E0w56WHxZPYGVvnTQ4O2t1C8DAjq in items:
			title = name+' - حلقة رقم '+E0w56WHxZPYGVvnTQ4O2t1C8DAjq
			zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,252,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
	else: zJLApFBcIhnSj('video',nc3GLkA65oxOd+'ملف التشغيل',url,252,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
	return
def ZyAUipSQ75Hst(title,c0cDhidBlOn7):
	UHXfFEWmlxMAnzju4 = ffUFBJQ57j2XgoGeOLn9uwpC.findall('[a-zA-Z-]+',title,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if UHXfFEWmlxMAnzju4: title = UHXfFEWmlxMAnzju4[0]
	else: title = title+VBpIH2QSmvDGlA6TO3e+CxlbPZwGTcH87e1sWhfSIz29uRUEpV(c0cDhidBlOn7,'name')
	title = title.replace('عرب سيد',cdZKMn68Pzg4).replace('مباشر',cdZKMn68Pzg4).replace('مشاهدة',cdZKMn68Pzg4)
	title = title.replace('ٍ',cdZKMn68Pzg4)
	title = title.replace(wr0HaqRdJ2D9LT7nSO1KMe38ly,VBpIH2QSmvDGlA6TO3e).replace(wr0HaqRdJ2D9LT7nSO1KMe38ly,VBpIH2QSmvDGlA6TO3e)
	return title
def RPZbqous7rtdy56LeI18Cv04AKHW(url):
	wRlW4txQshKmeXdO7zABrLPT1GbZ0 = CxlbPZwGTcH87e1sWhfSIz29uRUEpV(url,'url')
	headers = {'Referer':wRlW4txQshKmeXdO7zABrLPT1GbZ0}
	XFj0lV5yMtS67EwbCJ9oO,hgUHAlMnVoFue5f = [],[]
	uoJt9Es85B = url+'/download'
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(r43t1YI9deXA5N,'GET',uoJt9Es85B,cdZKMn68Pzg4,headers,cdZKMn68Pzg4,cdZKMn68Pzg4,'ARABSEED-PLAY-1st')
	JJPEReUDbt0QoWHkL21TA = Zty0AsgQ5jpkTh91OW.content
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"downloads__tabs"(.*?)</section>',JJPEReUDbt0QoWHkL21TA,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="([^"]*)".*?<h4>(.*?)</h4>.*?<p>(.*?)</p>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,CCpDMVI0dq2,UHXfFEWmlxMAnzju4 in items:
			l1MCIuwhAELbO2eJ96kNta7rp0B = ffUFBJQ57j2XgoGeOLn9uwpC.findall('\d+',UHXfFEWmlxMAnzju4,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			l1MCIuwhAELbO2eJ96kNta7rp0B = '__'+l1MCIuwhAELbO2eJ96kNta7rp0B[0] if l1MCIuwhAELbO2eJ96kNta7rp0B else cdZKMn68Pzg4
			if '/l/' in c0cDhidBlOn7:
				c0cDhidBlOn7 = c0cDhidBlOn7.split('/l/')[1]
				c0cDhidBlOn7 = abn2REWAS3FwTN0rlQmgOk.b64decode(c0cDhidBlOn7)
				if W5domCu6XrQUFkiPpa3bNLtHglG: c0cDhidBlOn7 = c0cDhidBlOn7.decode(vczMIlkCAh2u10B3)
			if c0cDhidBlOn7 in hgUHAlMnVoFue5f: continue
			hgUHAlMnVoFue5f.append(c0cDhidBlOn7)
			c0cDhidBlOn7 = c0cDhidBlOn7+'?named='+CCpDMVI0dq2+'__download'+l1MCIuwhAELbO2eJ96kNta7rp0B
			XFj0lV5yMtS67EwbCJ9oO.append(c0cDhidBlOn7)
	JjFAsD5y8KlVx4twkmYSarE = url+'/watch'
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(r43t1YI9deXA5N,'GET',JjFAsD5y8KlVx4twkmYSarE,cdZKMn68Pzg4,headers,cdZKMn68Pzg4,cdZKMn68Pzg4,'ARABSEED-PLAY-2nd')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="servers__list(.*?)</ul>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('data-qu="(.*?)".*?data-link="(.*?)".*?<span>(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for l1MCIuwhAELbO2eJ96kNta7rp0B,c0cDhidBlOn7,title in items:
			if '=aHR0' in c0cDhidBlOn7:
				GGdCvD82L9TRUHKBSVw4itI = ffUFBJQ57j2XgoGeOLn9uwpC.findall('=(aHR0.*?)$',c0cDhidBlOn7,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
				if GGdCvD82L9TRUHKBSVw4itI:
					c0cDhidBlOn7 = abn2REWAS3FwTN0rlQmgOk.b64decode(GGdCvD82L9TRUHKBSVw4itI[0]+'===').decode(vczMIlkCAh2u10B3)
					c0cDhidBlOn7 = wrcgBRto5yMTdbhZLfzKe1UOpVSmYH(c0cDhidBlOn7)
			if 'http' not in c0cDhidBlOn7: c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr+c0cDhidBlOn7
			if c0cDhidBlOn7 in hgUHAlMnVoFue5f: continue
			hgUHAlMnVoFue5f.append(c0cDhidBlOn7)
			c0cDhidBlOn7 = c0cDhidBlOn7+'?named='+title+'__watch__'+l1MCIuwhAELbO2eJ96kNta7rp0B
			XFj0lV5yMtS67EwbCJ9oO.append(c0cDhidBlOn7)
	HYBN2AQsjimSMgT8OvE3ynX67tJwR = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"video_frame" src="(.*?)".*?height="(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL|ffUFBJQ57j2XgoGeOLn9uwpC.IGNORECASE)
	if HYBN2AQsjimSMgT8OvE3ynX67tJwR:
		c0cDhidBlOn7,l1MCIuwhAELbO2eJ96kNta7rp0B = HYBN2AQsjimSMgT8OvE3ynX67tJwR[0]
		if '=aHR0' in c0cDhidBlOn7:
			GGdCvD82L9TRUHKBSVw4itI = ffUFBJQ57j2XgoGeOLn9uwpC.findall('=(aHR0.*?)$',c0cDhidBlOn7,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			if GGdCvD82L9TRUHKBSVw4itI:
				c0cDhidBlOn7 = abn2REWAS3FwTN0rlQmgOk.b64decode(GGdCvD82L9TRUHKBSVw4itI[0]+'===').decode(vczMIlkCAh2u10B3)
				c0cDhidBlOn7 = wrcgBRto5yMTdbhZLfzKe1UOpVSmYH(c0cDhidBlOn7)
		if 'http' not in c0cDhidBlOn7: c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr+c0cDhidBlOn7
		name = CxlbPZwGTcH87e1sWhfSIz29uRUEpV(c0cDhidBlOn7,'name')
		if c0cDhidBlOn7 not in hgUHAlMnVoFue5f:
			hgUHAlMnVoFue5f.append(c0cDhidBlOn7)
			c0cDhidBlOn7 = c0cDhidBlOn7+'?named='+name+'__embed__'+l1MCIuwhAELbO2eJ96kNta7rp0B
			XFj0lV5yMtS67EwbCJ9oO.append(c0cDhidBlOn7)
	import r0y4XTKznF
	r0y4XTKznF.noHliPXkcg3pJTdSauCvm5sU(XFj0lV5yMtS67EwbCJ9oO,UkXlAzsMcamKJrEIgnxi6bWh,'video',url)
	return
def FnxPocQH19pNfjUMEveWr(url):
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(r43t1YI9deXA5N,'GET',url,cdZKMn68Pzg4,headers,cdZKMn68Pzg4,cdZKMn68Pzg4,'ARABSEED-PLAY-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	HOCWKhxITtulVGX = Zty0AsgQ5jpkTh91OW.url
	wRlW4txQshKmeXdO7zABrLPT1GbZ0 = CxlbPZwGTcH87e1sWhfSIz29uRUEpV(HOCWKhxITtulVGX,'url')
	headers['Referer'] = wRlW4txQshKmeXdO7zABrLPT1GbZ0+KCQExdbYFqM
	headers['Content-Type'] = 'application/x-www-form-urlencoded'
	pcX7zxFRmsADwUr,tckvzfNEsVawXyHWd = [],[]
	cOVHC0F6h9oI7NdDE1nbjS,KK4vlptGLONxC2DkJesMc8mYgb,qql0VnmM2gWRGdhOeHIwFy = cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4
	qNwtyICDZ65dpAvUezjY,CIzj5LcAG2STeM6VUmfH1EX,hhrsHmBZueQLlOEMwiCAXUSIF = cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4
	qHOzT7kPag80m = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"WatchButtons"(.*?)</div>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if qHOzT7kPag80m:
		KdWauEhgN6OQzjRVm1ro8tkB3 = qHOzT7kPag80m[nnsBpJv6XL3OzHoe4Vuhr]
		if '<form' in KdWauEhgN6OQzjRVm1ro8tkB3:
			tckvzfNEsVawXyHWd = ffUFBJQ57j2XgoGeOLn9uwpC.findall('<form action="(.*?)".*?name="(.*?)".*?value="(.*?)"',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			if tckvzfNEsVawXyHWd:
				pOaMLH2bhdNnkz0fWDI = 'POST'
				for pxJ5fy4tNOXYv7kRHL1A,name,value in tckvzfNEsVawXyHWd:
					if 'wpost' in name: cOVHC0F6h9oI7NdDE1nbjS,KK4vlptGLONxC2DkJesMc8mYgb,qql0VnmM2gWRGdhOeHIwFy = pxJ5fy4tNOXYv7kRHL1A,name,value
					elif 'dpost' in name: qNwtyICDZ65dpAvUezjY,CIzj5LcAG2STeM6VUmfH1EX,hhrsHmBZueQLlOEMwiCAXUSIF = pxJ5fy4tNOXYv7kRHL1A,name,value
				bVkl8opNg2iuQMyGdBWHKA9C45racw = KK4vlptGLONxC2DkJesMc8mYgb+'='+qql0VnmM2gWRGdhOeHIwFy
				E9ET7O2XhuwZF8UanHvjqIQSdM3 = CIzj5LcAG2STeM6VUmfH1EX+'='+hhrsHmBZueQLlOEMwiCAXUSIF
		else:
			tckvzfNEsVawXyHWd = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)"',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			if tckvzfNEsVawXyHWd:
				pOaMLH2bhdNnkz0fWDI = 'GET'
				for c0cDhidBlOn7 in tckvzfNEsVawXyHWd:
					if 'wpost' in c0cDhidBlOn7: cOVHC0F6h9oI7NdDE1nbjS = c0cDhidBlOn7
					elif 'dpost' in c0cDhidBlOn7: qNwtyICDZ65dpAvUezjY = c0cDhidBlOn7
				bVkl8opNg2iuQMyGdBWHKA9C45racw = cdZKMn68Pzg4
				E9ET7O2XhuwZF8UanHvjqIQSdM3 = cdZKMn68Pzg4
	if cOVHC0F6h9oI7NdDE1nbjS:
		Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(r43t1YI9deXA5N,pOaMLH2bhdNnkz0fWDI,cOVHC0F6h9oI7NdDE1nbjS,bVkl8opNg2iuQMyGdBWHKA9C45racw,headers,cdZKMn68Pzg4,cdZKMn68Pzg4,'ARABSEED-PLAY-2nd')
		OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="WatcherArea(.*?</ul>)',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if ppvsMqCHf8SEzxQg:
			mlkP0QINy3nW4bpTr8HC75oXaOYhc = ppvsMqCHf8SEzxQg[0]
			mlkP0QINy3nW4bpTr8HC75oXaOYhc = mlkP0QINy3nW4bpTr8HC75oXaOYhc.replace('</ul>','<h3>')
			mlkP0QINy3nW4bpTr8HC75oXaOYhc = mlkP0QINy3nW4bpTr8HC75oXaOYhc.replace('<h3>','<h3><h3>')
			akIvSitzr0mKe = ffUFBJQ57j2XgoGeOLn9uwpC.findall('<h3>.*?(\d+)(.*?)<h3>',mlkP0QINy3nW4bpTr8HC75oXaOYhc,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			if not akIvSitzr0mKe: akIvSitzr0mKe = [(cdZKMn68Pzg4,mlkP0QINy3nW4bpTr8HC75oXaOYhc)]
			for l1MCIuwhAELbO2eJ96kNta7rp0B,KdWauEhgN6OQzjRVm1ro8tkB3 in akIvSitzr0mKe:
				if l1MCIuwhAELbO2eJ96kNta7rp0B: l1MCIuwhAELbO2eJ96kNta7rp0B = '____'+l1MCIuwhAELbO2eJ96kNta7rp0B
				items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('data-link="(.*?)".*?<span>(.*?)</span>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
				for c0cDhidBlOn7,name in items:
					if 'http' not in c0cDhidBlOn7: c0cDhidBlOn7 = 'http:'+c0cDhidBlOn7
					c0cDhidBlOn7 = c0cDhidBlOn7+'?named='+name+'__watch'+l1MCIuwhAELbO2eJ96kNta7rp0B
					pcX7zxFRmsADwUr.append(c0cDhidBlOn7)
		zz4ZPovUbyk5GEhNMs8JDnaVXftS = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="containerIframe".*? src="(.*?)".*? height="(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL|ffUFBJQ57j2XgoGeOLn9uwpC.IGNORECASE)
		if zz4ZPovUbyk5GEhNMs8JDnaVXftS:
			c0cDhidBlOn7,l1MCIuwhAELbO2eJ96kNta7rp0B = zz4ZPovUbyk5GEhNMs8JDnaVXftS[0]
			name = CxlbPZwGTcH87e1sWhfSIz29uRUEpV(c0cDhidBlOn7,'name')
			if '%' in l1MCIuwhAELbO2eJ96kNta7rp0B: c0cDhidBlOn7 = c0cDhidBlOn7+'?named='+name+'__embed__'
			else: c0cDhidBlOn7 = c0cDhidBlOn7+'?named='+name+'__embed____'+l1MCIuwhAELbO2eJ96kNta7rp0B
			pcX7zxFRmsADwUr.append(c0cDhidBlOn7)
	if qNwtyICDZ65dpAvUezjY:
		Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(r43t1YI9deXA5N,pOaMLH2bhdNnkz0fWDI,qNwtyICDZ65dpAvUezjY,E9ET7O2XhuwZF8UanHvjqIQSdM3,headers,cdZKMn68Pzg4,cdZKMn68Pzg4,'ARABSEED-PLAY-3rd')
		OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="DownloadArea(.*?)<script src=',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if ppvsMqCHf8SEzxQg:
			mlkP0QINy3nW4bpTr8HC75oXaOYhc = ppvsMqCHf8SEzxQg[0]
			akIvSitzr0mKe = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="DownloadServers(.*?)</ul>',mlkP0QINy3nW4bpTr8HC75oXaOYhc,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			for KdWauEhgN6OQzjRVm1ro8tkB3 in akIvSitzr0mKe:
				items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?<span>(.*?)</span>.*?<p>(.*?)</p>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
				for c0cDhidBlOn7,title,l1MCIuwhAELbO2eJ96kNta7rp0B in items:
					if not c0cDhidBlOn7: continue
					if 'reviewstation' in c0cDhidBlOn7: continue
					c0cDhidBlOn7 = NLqxoZ37dYf0awrsIE(c0cDhidBlOn7)
					c0cDhidBlOn7 = c0cDhidBlOn7+'?named='+title+'__download____'+l1MCIuwhAELbO2eJ96kNta7rp0B
					pcX7zxFRmsADwUr.append(c0cDhidBlOn7)
	BHxDrOTvwW8VKhinymCGZ = str(pcX7zxFRmsADwUr)
	Q4MzfNTaSYmJBe8FInOqGldjtv7D = ['.zip?','.rar?','.txt?','.pdf?','.tar?','.iso?','.zip.','.rar.','.txt.','.pdf.','.tar.','.iso.']
	if any(value in BHxDrOTvwW8VKhinymCGZ for value in Q4MzfNTaSYmJBe8FInOqGldjtv7D):
		NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,'جرب رابط مختلف لأن هذا الرابط ليس من نوع الروابط التي فيها ملفات فيديو .. لأن هذا الموقع فيه خدمات أخرى غير ملفات الفيديو')
		return
	import r0y4XTKznF
	r0y4XTKznF.noHliPXkcg3pJTdSauCvm5sU(pcX7zxFRmsADwUr,UkXlAzsMcamKJrEIgnxi6bWh,'video',url)
	return
def z4hetAJw3NaT9ROjG6xbZ5CHlW81(search):
	search,EL8zUgbXheot,showDialogs = qbIcHCMdkFKn21e(search)
	if not search: search = BzkmLuvJD9n25Pg()
	if not search: return
	search = search.replace(VBpIH2QSmvDGlA6TO3e,'+')
	url = cDTdfqVAF0BLGiX364IEwaZbr+'/find/?word='+search+'&type='
	GDQUH4fN02sIt81mAcY(url,'search')
	return
def XxcpMKIUzr0sVDngR(url,filter):
	if '??' in url: url = url.split('//getposts??')[0]
	type,filter = filter.split('___',1)
	if filter==cdZKMn68Pzg4: KFGqxsBnZYLb3NvMU,ejQ8ZCtBaV7 = cdZKMn68Pzg4,cdZKMn68Pzg4
	else: KFGqxsBnZYLb3NvMU,ejQ8ZCtBaV7 = filter.split('___')
	if type=='CATEGORIES':
		if TUBoFrl6IHzu8Pq[0]+'==' not in KFGqxsBnZYLb3NvMU: rrb0SF6otehufCYOX4 = TUBoFrl6IHzu8Pq[0]
		for WCqkctAYD2O3Hz7Fl8fKRS5 in range(len(TUBoFrl6IHzu8Pq[0:-1])):
			if TUBoFrl6IHzu8Pq[WCqkctAYD2O3Hz7Fl8fKRS5]+'==' in KFGqxsBnZYLb3NvMU: rrb0SF6otehufCYOX4 = TUBoFrl6IHzu8Pq[WCqkctAYD2O3Hz7Fl8fKRS5+1]
		gmjZQuBFv8RzlNtDVEOc = KFGqxsBnZYLb3NvMU+'&&'+rrb0SF6otehufCYOX4+'==0'
		qwmxUpZfQj8EAV3Tc = ejQ8ZCtBaV7+'&&'+rrb0SF6otehufCYOX4+'==0'
		vMp6jZbo3UkEsSxRFQndyA = gmjZQuBFv8RzlNtDVEOc.strip('&&')+'___'+qwmxUpZfQj8EAV3Tc.strip('&&')
		YqrzmSVb3R9MgUnX2auEHlpBhZD = XFoM2xPKIt3u51hLj(ejQ8ZCtBaV7,'modified_filters')
		HOCWKhxITtulVGX = url+'//getposts??'+YqrzmSVb3R9MgUnX2auEHlpBhZD
	elif type=='FILTERS':
		zM2ZBJ4IYN8osGTtwgRheLu6dU = XFoM2xPKIt3u51hLj(KFGqxsBnZYLb3NvMU,'modified_values')
		zM2ZBJ4IYN8osGTtwgRheLu6dU = NLqxoZ37dYf0awrsIE(zM2ZBJ4IYN8osGTtwgRheLu6dU)
		if ejQ8ZCtBaV7!=cdZKMn68Pzg4: ejQ8ZCtBaV7 = XFoM2xPKIt3u51hLj(ejQ8ZCtBaV7,'modified_filters')
		if ejQ8ZCtBaV7==cdZKMn68Pzg4: HOCWKhxITtulVGX = url
		else: HOCWKhxITtulVGX = url+'//getposts??'+ejQ8ZCtBaV7
		GMmu2UjLcIOxW0wHaB1KoRyDs856 = c4WGnhHrZFl2iyOxoEUNYLVvQ6PD0(HOCWKhxITtulVGX)
		zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'أظهار قائمة الفيديو التي تم اختيارها ',GMmu2UjLcIOxW0wHaB1KoRyDs856,251,cdZKMn68Pzg4,cdZKMn68Pzg4,'filters')
		zJLApFBcIhnSj('folder',nc3GLkA65oxOd+' [[   '+zM2ZBJ4IYN8osGTtwgRheLu6dU+'   ]]',GMmu2UjLcIOxW0wHaB1KoRyDs856,251,cdZKMn68Pzg4,cdZKMn68Pzg4,'filters')
		zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(r43t1YI9deXA5N,'POST',url,cdZKMn68Pzg4,headers,cdZKMn68Pzg4,cdZKMn68Pzg4,'ARABSEED-FILTERS_MENU-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="TaxPageFilter"(.*?)class="TermBTNs"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
	gvt1u7KH3ifz = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="TaxPageFilterItem".*?<em>(.*?)</em>.*?data-tax="(.*?)"(.*?)</ul>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	QyVfKYzNLMbdHROg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="RatingFilter".*?<h4>(.*?)</h4>.*?(<ul>)(.*?)</ul>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	hQ9ADnZlSxI1m8ui = gvt1u7KH3ifz+QyVfKYzNLMbdHROg
	dict = {}
	for name,rfJG62Vo0pTEljwPN1WahD7sx4t3QR,KdWauEhgN6OQzjRVm1ro8tkB3 in hQ9ADnZlSxI1m8ui:
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('data-name="(.*?)".*?data-tax="(.*?)".*?data-term="(.*?)"',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if name=='اخرى': name = 'الاقسام'
		if not items:
			zaUqdBJDmY = ffUFBJQ57j2XgoGeOLn9uwpC.findall('data-rate="(.*?)".*?<em>(.*?)</em>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			items = []
			for zj6FI51Rypka0e8xiECfc7g,value in zaUqdBJDmY: items.append([zj6FI51Rypka0e8xiECfc7g,cdZKMn68Pzg4,value])
			rfJG62Vo0pTEljwPN1WahD7sx4t3QR = 'rate'
			name = 'التقييم'
		else: rfJG62Vo0pTEljwPN1WahD7sx4t3QR = items[0][1]
		if '==' not in HOCWKhxITtulVGX: HOCWKhxITtulVGX = url
		if type=='CATEGORIES':
			if rrb0SF6otehufCYOX4!=rfJG62Vo0pTEljwPN1WahD7sx4t3QR: continue
			elif len(items)<=1:
				if rfJG62Vo0pTEljwPN1WahD7sx4t3QR==TUBoFrl6IHzu8Pq[-1]: GDQUH4fN02sIt81mAcY(HOCWKhxITtulVGX)
				else: XxcpMKIUzr0sVDngR(HOCWKhxITtulVGX,'CATEGORIES___'+vMp6jZbo3UkEsSxRFQndyA)
				return
			else:
				GMmu2UjLcIOxW0wHaB1KoRyDs856 = c4WGnhHrZFl2iyOxoEUNYLVvQ6PD0(HOCWKhxITtulVGX)
				if rfJG62Vo0pTEljwPN1WahD7sx4t3QR==TUBoFrl6IHzu8Pq[-1]: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'الجميع ',GMmu2UjLcIOxW0wHaB1KoRyDs856,251,cdZKMn68Pzg4,cdZKMn68Pzg4,'filters')
				else: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'الجميع ',HOCWKhxITtulVGX,254,cdZKMn68Pzg4,cdZKMn68Pzg4,vMp6jZbo3UkEsSxRFQndyA)
		elif type=='FILTERS':
			gmjZQuBFv8RzlNtDVEOc = KFGqxsBnZYLb3NvMU+'&&'+rfJG62Vo0pTEljwPN1WahD7sx4t3QR+'==0'
			qwmxUpZfQj8EAV3Tc = ejQ8ZCtBaV7+'&&'+rfJG62Vo0pTEljwPN1WahD7sx4t3QR+'==0'
			vMp6jZbo3UkEsSxRFQndyA = gmjZQuBFv8RzlNtDVEOc+'___'+qwmxUpZfQj8EAV3Tc
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'الجميع :'+name,HOCWKhxITtulVGX,255,cdZKMn68Pzg4,cdZKMn68Pzg4,vMp6jZbo3UkEsSxRFQndyA)
		dict[rfJG62Vo0pTEljwPN1WahD7sx4t3QR] = {}
		for zj6FI51Rypka0e8xiECfc7g,tYPfm3ISxD,value in items:
			if zj6FI51Rypka0e8xiECfc7g in cJWUPuDGM0Yybv5a9KnIrVzhH78: continue
			if 'الكل' in zj6FI51Rypka0e8xiECfc7g: continue
			zj6FI51Rypka0e8xiECfc7g = gbd90SjF2mZqf81IRDaTwJkWu(zj6FI51Rypka0e8xiECfc7g)
			CCpDMVI0dq2,UHXfFEWmlxMAnzju4 = zj6FI51Rypka0e8xiECfc7g,zj6FI51Rypka0e8xiECfc7g
			UHXfFEWmlxMAnzju4 = name+': '+CCpDMVI0dq2
			dict[rfJG62Vo0pTEljwPN1WahD7sx4t3QR][value] = UHXfFEWmlxMAnzju4
			gmjZQuBFv8RzlNtDVEOc = KFGqxsBnZYLb3NvMU+'&&'+rfJG62Vo0pTEljwPN1WahD7sx4t3QR+'=='+CCpDMVI0dq2
			qwmxUpZfQj8EAV3Tc = ejQ8ZCtBaV7+'&&'+rfJG62Vo0pTEljwPN1WahD7sx4t3QR+'=='+value
			AL8gJZ0NtE91Bexjin4 = gmjZQuBFv8RzlNtDVEOc+'___'+qwmxUpZfQj8EAV3Tc
			if type=='FILTERS':
				zJLApFBcIhnSj('folder',nc3GLkA65oxOd+UHXfFEWmlxMAnzju4,url,255,cdZKMn68Pzg4,cdZKMn68Pzg4,AL8gJZ0NtE91Bexjin4)
			elif type=='CATEGORIES' and TUBoFrl6IHzu8Pq[-2]+'==' in KFGqxsBnZYLb3NvMU:
				YqrzmSVb3R9MgUnX2auEHlpBhZD = XFoM2xPKIt3u51hLj(qwmxUpZfQj8EAV3Tc,'modified_filters')
				N8jUpQxY0rhtDAzbG4kOs9X = url+'//getposts??'+YqrzmSVb3R9MgUnX2auEHlpBhZD
				GMmu2UjLcIOxW0wHaB1KoRyDs856 = c4WGnhHrZFl2iyOxoEUNYLVvQ6PD0(N8jUpQxY0rhtDAzbG4kOs9X)
				zJLApFBcIhnSj('folder',nc3GLkA65oxOd+UHXfFEWmlxMAnzju4,GMmu2UjLcIOxW0wHaB1KoRyDs856,251,cdZKMn68Pzg4,cdZKMn68Pzg4,'filters')
			else: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+UHXfFEWmlxMAnzju4,url,254,cdZKMn68Pzg4,cdZKMn68Pzg4,AL8gJZ0NtE91Bexjin4)
	return
TUBoFrl6IHzu8Pq = ['category','country','release-year']
U4c89YoCKaXy = ['category','country','genre','release-year','language','quality','rate']
def c4WGnhHrZFl2iyOxoEUNYLVvQ6PD0(url):
	gSwoK7z0L1ncI23d5GeXNZRmB9 = '/wp-content/themes/Elshaikh2021/Ajaxat/Home/FilteringHome.php'
	url = url.replace('//getposts',gSwoK7z0L1ncI23d5GeXNZRmB9)
	url = url.replace('/category/اخرى',cdZKMn68Pzg4)
	if gSwoK7z0L1ncI23d5GeXNZRmB9 not in url: url = url+gSwoK7z0L1ncI23d5GeXNZRmB9
	url = url.replace('release-year','year')
	url = url.replace('??','?')
	url = url.replace('&&','&')
	url = url.replace('==','=')
	return url
def XFoM2xPKIt3u51hLj(o3JURfrMDgp76,mode):
	o3JURfrMDgp76 = o3JURfrMDgp76.strip('&&')
	bLxfgF7nlO1uZiY9e5T0HDdIw3kpy,n7VBe6ZgDI14lizTfHOmk = {},cdZKMn68Pzg4
	if '==' in o3JURfrMDgp76:
		items = o3JURfrMDgp76.split('&&')
		for HYBN2AQsjimSMgT8OvE3ynX67tJwR in items:
			IN0jyfe1PRdDz6YX3CoJkHthw,value = HYBN2AQsjimSMgT8OvE3ynX67tJwR.split('==')
			bLxfgF7nlO1uZiY9e5T0HDdIw3kpy[IN0jyfe1PRdDz6YX3CoJkHthw] = value
	for key in U4c89YoCKaXy:
		if key in list(bLxfgF7nlO1uZiY9e5T0HDdIw3kpy.keys()): value = bLxfgF7nlO1uZiY9e5T0HDdIw3kpy[key]
		else: value = '0'
		if '%' not in value: value = YQlEOShHM7RLak2t0yA4NXqv(value)
		if mode=='modified_values' and value!='0': n7VBe6ZgDI14lizTfHOmk = n7VBe6ZgDI14lizTfHOmk+' + '+value
		elif mode=='modified_filters' and value!='0': n7VBe6ZgDI14lizTfHOmk = n7VBe6ZgDI14lizTfHOmk+'&&'+key+'=='+value
		elif mode=='all': n7VBe6ZgDI14lizTfHOmk = n7VBe6ZgDI14lizTfHOmk+'&&'+key+'=='+value
	n7VBe6ZgDI14lizTfHOmk = n7VBe6ZgDI14lizTfHOmk.strip(' + ')
	n7VBe6ZgDI14lizTfHOmk = n7VBe6ZgDI14lizTfHOmk.strip('&&')
	return n7VBe6ZgDI14lizTfHOmk
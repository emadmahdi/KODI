# -*- coding: utf-8 -*-
from RgJNGc7YMP import *
UkXlAzsMcamKJrEIgnxi6bWh = 'SHAHID4U2'
nc3GLkA65oxOd = '_SH2_'
cDTdfqVAF0BLGiX364IEwaZbr = USuRxnPlV5.SITESURLS[UkXlAzsMcamKJrEIgnxi6bWh][0]
headers = {'User-Agent':knzwM2WCl7jAex9H4YFva(True)}
cJWUPuDGM0Yybv5a9KnIrVzhH78 = []
def HHN5EpbszV3iA2m89hGSQjaPgUZy(mode,url,text):
	if   mode==1090: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = kUq58vC7x9hWma164JejMKQ()
	elif mode==1091: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = GDQUH4fN02sIt81mAcY(url,text)
	elif mode==1092: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = RPZbqous7rtdy56LeI18Cv04AKHW(url)
	elif mode==1093: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = yIZWSuMpvs3(url,text)
	elif mode==1094: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = XxcpMKIUzr0sVDngR(url,'FULL_FILTER___'+text)
	elif mode==1095: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = XxcpMKIUzr0sVDngR(url,'DEFINED_FILTER___'+text)
	elif mode==1099: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = z4hetAJw3NaT9ROjG6xbZ5CHlW81(text)
	else: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = False
	return xsGUcR3ef6glKY5hQwpFXEaSt2mrIz
def kUq58vC7x9hWma164JejMKQ():
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',cDTdfqVAF0BLGiX364IEwaZbr,cdZKMn68Pzg4,headers,cdZKMn68Pzg4,cdZKMn68Pzg4,'SHAHID4U2-MENU-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	u1P73L0UmkA4eaIBbCgZfrvRtJ = CxlbPZwGTcH87e1sWhfSIz29uRUEpV(Zty0AsgQ5jpkTh91OW.url,'url')
	if xicJPb0AW1nsRfH3kCv7: u1P73L0UmkA4eaIBbCgZfrvRtJ = u1P73L0UmkA4eaIBbCgZfrvRtJ.encode(vczMIlkCAh2u10B3)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'بحث في الموقع',cdZKMn68Pzg4,1099,cdZKMn68Pzg4,cdZKMn68Pzg4,'_REMEMBERRESULTS_')
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'فلتر محدد',u1P73L0UmkA4eaIBbCgZfrvRtJ,1095)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'فلتر كامل',u1P73L0UmkA4eaIBbCgZfrvRtJ,1094)
	zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'المميزة',u1P73L0UmkA4eaIBbCgZfrvRtJ,1091,cdZKMn68Pzg4,cdZKMn68Pzg4,'featured')
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"main-menu"(.*?)</div>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?>(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,title in items:
			title = title.replace(ssELJkeScrtni2,cdZKMn68Pzg4).replace(CPjOZMmw8sfGg2B9LthIdXa1iKQUF,cdZKMn68Pzg4).strip(VBpIH2QSmvDGlA6TO3e)
			if title in cJWUPuDGM0Yybv5a9KnIrVzhH78: continue
			if 'http' not in c0cDhidBlOn7: c0cDhidBlOn7 = u1P73L0UmkA4eaIBbCgZfrvRtJ+c0cDhidBlOn7
			if 'netflix' in c0cDhidBlOn7: title = 'نيتفلكس'
			zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+title,c0cDhidBlOn7,1091)
	return OO1cj2REUZHJ8x5V
def GDQUH4fN02sIt81mAcY(url,w3wLtqKIc0=cdZKMn68Pzg4,Zty0AsgQ5jpkTh91OW=cdZKMn68Pzg4):
	if not Zty0AsgQ5jpkTh91OW: Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',url,cdZKMn68Pzg4,headers,cdZKMn68Pzg4,cdZKMn68Pzg4,'SHAHID4U2-TITLES-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	ppvsMqCHf8SEzxQg,items,KRmzvoWYyxfXw37SEh1Q = [],[],[]
	if w3wLtqKIc0=='featured': ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"Slides--Main"(.*?)"filterTabs"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	else: ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"BlocksHolder"(.*?)"pagination"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if not ppvsMqCHf8SEzxQg: return
	KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
	items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?title="(.*?)".*?data-src="(.*?)"',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	rgWUvoaJnZARc375bjQ = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for c0cDhidBlOn7,title,y90BoFz8MA1ZThaSC2ILXHiK3OY6w in items:
		if 'WWE' in title: continue
		if 'javascript' in c0cDhidBlOn7: continue
		if 'http' not in c0cDhidBlOn7: c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr+c0cDhidBlOn7
		title = gbd90SjF2mZqf81IRDaTwJkWu(title)
		title = title.strip(VBpIH2QSmvDGlA6TO3e)
		E0w56WHxZPYGVvnTQ4O2t1C8DAjq = ffUFBJQ57j2XgoGeOLn9uwpC.findall('(.*?) الحلقة \d+',title,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if '/film/' in c0cDhidBlOn7 or 'فيلم' in c0cDhidBlOn7 or any(value in title for value in rgWUvoaJnZARc375bjQ):
			zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,1092,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
		elif E0w56WHxZPYGVvnTQ4O2t1C8DAjq and 'الحلقة' in title and '/list' not in url:
			title = '_MOD_' + E0w56WHxZPYGVvnTQ4O2t1C8DAjq[0]
			if title not in KRmzvoWYyxfXw37SEh1Q:
				zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,1093,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
				KRmzvoWYyxfXw37SEh1Q.append(title)
		elif '/actor/' in c0cDhidBlOn7:
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,1091,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
		elif '/series/' in c0cDhidBlOn7 and '/list' not in url:
			c0cDhidBlOn7 = c0cDhidBlOn7+'/list'
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,1091,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
		elif '/list' in url and 'حلقة' in title:
			zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,1092,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
		else: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,1093,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"pagination"(.*?)</ul>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg and not w3wLtqKIc0:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('<li>.*?href="(.*?)">(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,title in items:
			title = gbd90SjF2mZqf81IRDaTwJkWu(title)
			if title: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'صفحة '+title,c0cDhidBlOn7,1091,cdZKMn68Pzg4,cdZKMn68Pzg4,w3wLtqKIc0)
	return
def yIZWSuMpvs3(url,dzcpTs6kZQL):
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',url,cdZKMn68Pzg4,headers,cdZKMn68Pzg4,cdZKMn68Pzg4,'SHAHID4U2-EPISODES-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="w-100(.*?)</div>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if not ppvsMqCHf8SEzxQg: ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="EpisodesList"(.*?)</div>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		rLJZ6CbxyPwqoj1YUGk5svB0 = ppvsMqCHf8SEzxQg[nnsBpJv6XL3OzHoe4Vuhr]
		C1w6jOhrMDFag2BLNYdp = rLJZ6CbxyPwqoj1YUGk5svB0.count('/season/')+rLJZ6CbxyPwqoj1YUGk5svB0.count('/series/')
		XVlqfhN29sdBQ = rLJZ6CbxyPwqoj1YUGk5svB0.count('href')-C1w6jOhrMDFag2BLNYdp
		if len(ppvsMqCHf8SEzxQg)==bVX3ev1spE:
			WcR9PJOi8Xn4FBIjuZAzbKGC = ppvsMqCHf8SEzxQg[hiuZa0PIsErm6UC7]
			jlDS6GakiCbEgd2ZpKMTU4tWfO = WcR9PJOi8Xn4FBIjuZAzbKGC.count('/season/')+WcR9PJOi8Xn4FBIjuZAzbKGC.count('/series/')
			wKVf37krZLWNMHJlTmPuiCygFQ = WcR9PJOi8Xn4FBIjuZAzbKGC.count('href=')-jlDS6GakiCbEgd2ZpKMTU4tWfO
		else: WcR9PJOi8Xn4FBIjuZAzbKGC,jlDS6GakiCbEgd2ZpKMTU4tWfO,wKVf37krZLWNMHJlTmPuiCygFQ = cdZKMn68Pzg4,nnsBpJv6XL3OzHoe4Vuhr,nnsBpJv6XL3OzHoe4Vuhr
		KdWauEhgN6OQzjRVm1ro8tkB3 = cdZKMn68Pzg4
		if not dzcpTs6kZQL:
			if C1w6jOhrMDFag2BLNYdp>hiuZa0PIsErm6UC7: KdWauEhgN6OQzjRVm1ro8tkB3 = rLJZ6CbxyPwqoj1YUGk5svB0
			elif jlDS6GakiCbEgd2ZpKMTU4tWfO>hiuZa0PIsErm6UC7: KdWauEhgN6OQzjRVm1ro8tkB3 = WcR9PJOi8Xn4FBIjuZAzbKGC
		if not KdWauEhgN6OQzjRVm1ro8tkB3:
			if XVlqfhN29sdBQ: KdWauEhgN6OQzjRVm1ro8tkB3 = rLJZ6CbxyPwqoj1YUGk5svB0
			elif wKVf37krZLWNMHJlTmPuiCygFQ: KdWauEhgN6OQzjRVm1ro8tkB3 = WcR9PJOi8Xn4FBIjuZAzbKGC
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?<span>(.*?)<.*?<em>(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,CCpDMVI0dq2,UHXfFEWmlxMAnzju4 in items:
			title = CCpDMVI0dq2+VBpIH2QSmvDGlA6TO3e+UHXfFEWmlxMAnzju4
			if '/season/' not in c0cDhidBlOn7 and '/series/' not in c0cDhidBlOn7: zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,1092)
			else: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,1093,cdZKMn68Pzg4,cdZKMn68Pzg4,'season')
	return
def RPZbqous7rtdy56LeI18Cv04AKHW(url):
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(r43t1YI9deXA5N,'GET',url,cdZKMn68Pzg4,headers,cdZKMn68Pzg4,cdZKMn68Pzg4,'SHAHID4U2-PLAY-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	XFj0lV5yMtS67EwbCJ9oO,t0m67ZgxBv4Xb = [],[]
	JjFAsD5y8KlVx4twkmYSarE = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="watch" href="(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	uoJt9Es85B = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="download" href="(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if JjFAsD5y8KlVx4twkmYSarE:
		JjFAsD5y8KlVx4twkmYSarE = JjFAsD5y8KlVx4twkmYSarE[0].replace(Tf2ZPslXS84Yw15aNkjQ7oOzqMc,KCQExdbYFqM).replace(':/','://').rstrip(KCQExdbYFqM)+KCQExdbYFqM
		Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(r43t1YI9deXA5N,'GET',JjFAsD5y8KlVx4twkmYSarE,cdZKMn68Pzg4,headers,cdZKMn68Pzg4,cdZKMn68Pzg4,'SHAHID4U2-PLAY-2nd')
		OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"watch"(.*?)</ul>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL|ffUFBJQ57j2XgoGeOLn9uwpC.IGNORECASE)
		if ppvsMqCHf8SEzxQg:
			KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
			items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('data-watch="(.*?)".*?</i>(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			for c0cDhidBlOn7,title in items:
				if c0cDhidBlOn7 in t0m67ZgxBv4Xb: continue
				c0cDhidBlOn7 = c0cDhidBlOn7+'?named='+title+'__watch'
				XFj0lV5yMtS67EwbCJ9oO.append(c0cDhidBlOn7)
				t0m67ZgxBv4Xb.append(c0cDhidBlOn7)
	if uoJt9Es85B:
		uoJt9Es85B = uoJt9Es85B[0].replace(Tf2ZPslXS84Yw15aNkjQ7oOzqMc,KCQExdbYFqM).replace(':/','://').rstrip(KCQExdbYFqM)+KCQExdbYFqM
		Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(r43t1YI9deXA5N,'GET',uoJt9Es85B,cdZKMn68Pzg4,headers,cdZKMn68Pzg4,cdZKMn68Pzg4,'SHAHID4U2-PLAY-3rd')
		OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"DownList"(.*?)</ul>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL|ffUFBJQ57j2XgoGeOLn9uwpC.IGNORECASE)
		if ppvsMqCHf8SEzxQg:
			KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
			items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?<quality>(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			for c0cDhidBlOn7,title in items:
				if c0cDhidBlOn7 in t0m67ZgxBv4Xb: continue
				c0cDhidBlOn7 = c0cDhidBlOn7+'?named='+title+'__download'
				XFj0lV5yMtS67EwbCJ9oO.append(c0cDhidBlOn7)
				t0m67ZgxBv4Xb.append(c0cDhidBlOn7)
	import r0y4XTKznF
	r0y4XTKznF.noHliPXkcg3pJTdSauCvm5sU(XFj0lV5yMtS67EwbCJ9oO,UkXlAzsMcamKJrEIgnxi6bWh,'video',url)
	return
def z4hetAJw3NaT9ROjG6xbZ5CHlW81(search):
	search,EL8zUgbXheot,showDialogs = qbIcHCMdkFKn21e(search)
	if not search:
		search = BzkmLuvJD9n25Pg()
		if not search: return
	search = search.replace(VBpIH2QSmvDGlA6TO3e,'+')
	url = cDTdfqVAF0BLGiX364IEwaZbr+'/?s='+search
	GDQUH4fN02sIt81mAcY(url,'search')
	return
def J1BMh3gS6EbcwT284RdnKzkitfUqW(url):
	url = url.split('/smartemadfilter?')[0]
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(r43t1YI9deXA5N,'GET',url,cdZKMn68Pzg4,headers,cdZKMn68Pzg4,cdZKMn68Pzg4,'SHAHID4U2-GET_FILTERS_BLOCKS-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	hQ9ADnZlSxI1m8ui = []
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('adv-filter(.*?)shows-container',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		hQ9ADnZlSxI1m8ui = ffUFBJQ57j2XgoGeOLn9uwpC.findall('''updateQuery\('(.*?)'.*?value.*?>(.*?)<(.*?)</select''',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		uN1gsqUIpJSERY4,OTVQcUsEmXhfdL38,akIvSitzr0mKe = zip(*hQ9ADnZlSxI1m8ui)
		hQ9ADnZlSxI1m8ui = zip(OTVQcUsEmXhfdL38,uN1gsqUIpJSERY4,akIvSitzr0mKe)
	return hQ9ADnZlSxI1m8ui
def ycYdX9u6W0oOnbMaDlf4KiPz(KdWauEhgN6OQzjRVm1ro8tkB3):
	items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('value="(.*?)".*?>\s*(.*?)\s*<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	return items
def VOx3AWdmCD8cSvXKLgr(url):
	if '/smartemadfilter?' not in url: url = url+'/smartemadfilter?'
	NLpSEUdj5H081igYnC4TbA2QtoVclF = url.split('/smartemadfilter?')[0]
	YYpjB2CuTidaMgcGrlJOswovm = CxlbPZwGTcH87e1sWhfSIz29uRUEpV(url,'url')
	url = url.replace(NLpSEUdj5H081igYnC4TbA2QtoVclF,YYpjB2CuTidaMgcGrlJOswovm)
	url = url.replace('/smartemadfilter?','/?')
	return url
SGJUq2RCH79hWyemglnMOpc8bB = ['quality','year','genre','category']
BWyLSPXqTxQojMGK74EAlNfvmaV = ['category','genre','year']
def XxcpMKIUzr0sVDngR(url,filter):
	url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==cdZKMn68Pzg4: KFGqxsBnZYLb3NvMU,ejQ8ZCtBaV7 = cdZKMn68Pzg4,cdZKMn68Pzg4
	else: KFGqxsBnZYLb3NvMU,ejQ8ZCtBaV7 = filter.split('___')
	if type=='DEFINED_FILTER':
		if BWyLSPXqTxQojMGK74EAlNfvmaV[0]+'=' not in KFGqxsBnZYLb3NvMU: rrb0SF6otehufCYOX4 = BWyLSPXqTxQojMGK74EAlNfvmaV[0]
		for WCqkctAYD2O3Hz7Fl8fKRS5 in range(len(BWyLSPXqTxQojMGK74EAlNfvmaV[0:-1])):
			if BWyLSPXqTxQojMGK74EAlNfvmaV[WCqkctAYD2O3Hz7Fl8fKRS5]+'=' in KFGqxsBnZYLb3NvMU: rrb0SF6otehufCYOX4 = BWyLSPXqTxQojMGK74EAlNfvmaV[WCqkctAYD2O3Hz7Fl8fKRS5+1]
		gmjZQuBFv8RzlNtDVEOc = KFGqxsBnZYLb3NvMU+'&'+rrb0SF6otehufCYOX4+'=0'
		qwmxUpZfQj8EAV3Tc = ejQ8ZCtBaV7+'&'+rrb0SF6otehufCYOX4+'=0'
		vMp6jZbo3UkEsSxRFQndyA = gmjZQuBFv8RzlNtDVEOc.strip('&')+'___'+qwmxUpZfQj8EAV3Tc.strip('&')
		YqrzmSVb3R9MgUnX2auEHlpBhZD = XFoM2xPKIt3u51hLj(ejQ8ZCtBaV7,'modified_filters')
		HOCWKhxITtulVGX = url+'/smartemadfilter?'+YqrzmSVb3R9MgUnX2auEHlpBhZD
	elif type=='FULL_FILTER':
		zM2ZBJ4IYN8osGTtwgRheLu6dU = XFoM2xPKIt3u51hLj(KFGqxsBnZYLb3NvMU,'modified_values')
		zM2ZBJ4IYN8osGTtwgRheLu6dU = NLqxoZ37dYf0awrsIE(zM2ZBJ4IYN8osGTtwgRheLu6dU)
		if ejQ8ZCtBaV7!=cdZKMn68Pzg4: ejQ8ZCtBaV7 = XFoM2xPKIt3u51hLj(ejQ8ZCtBaV7,'modified_filters')
		if ejQ8ZCtBaV7==cdZKMn68Pzg4: HOCWKhxITtulVGX = url
		else: HOCWKhxITtulVGX = url+'/smartemadfilter?'+ejQ8ZCtBaV7
		N8jUpQxY0rhtDAzbG4kOs9X = VOx3AWdmCD8cSvXKLgr(HOCWKhxITtulVGX)
		zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'أظهار قائمة الفيديو التي تم اختيارها ',N8jUpQxY0rhtDAzbG4kOs9X,1091)
		zJLApFBcIhnSj('folder',nc3GLkA65oxOd+' [[   '+zM2ZBJ4IYN8osGTtwgRheLu6dU+'   ]]',N8jUpQxY0rhtDAzbG4kOs9X,1091)
		zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	hQ9ADnZlSxI1m8ui = J1BMh3gS6EbcwT284RdnKzkitfUqW(url)
	dict = {}
	for name,rfJG62Vo0pTEljwPN1WahD7sx4t3QR,KdWauEhgN6OQzjRVm1ro8tkB3 in hQ9ADnZlSxI1m8ui:
		name = name.replace('كل ',cdZKMn68Pzg4)
		items = ycYdX9u6W0oOnbMaDlf4KiPz(KdWauEhgN6OQzjRVm1ro8tkB3)
		if '=' not in HOCWKhxITtulVGX: HOCWKhxITtulVGX = url
		if type=='DEFINED_FILTER':
			if rrb0SF6otehufCYOX4!=rfJG62Vo0pTEljwPN1WahD7sx4t3QR: continue
			elif len(items)<2:
				if rfJG62Vo0pTEljwPN1WahD7sx4t3QR==BWyLSPXqTxQojMGK74EAlNfvmaV[-1]:
					N8jUpQxY0rhtDAzbG4kOs9X = VOx3AWdmCD8cSvXKLgr(HOCWKhxITtulVGX)
					GDQUH4fN02sIt81mAcY(N8jUpQxY0rhtDAzbG4kOs9X)
				else: XxcpMKIUzr0sVDngR(HOCWKhxITtulVGX,'DEFINED_FILTER___'+vMp6jZbo3UkEsSxRFQndyA)
				return
			else:
				if rfJG62Vo0pTEljwPN1WahD7sx4t3QR==BWyLSPXqTxQojMGK74EAlNfvmaV[-1]:
					N8jUpQxY0rhtDAzbG4kOs9X = VOx3AWdmCD8cSvXKLgr(HOCWKhxITtulVGX)
					zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'الجميع',N8jUpQxY0rhtDAzbG4kOs9X,1091)
				else: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'الجميع',HOCWKhxITtulVGX,1095,cdZKMn68Pzg4,cdZKMn68Pzg4,vMp6jZbo3UkEsSxRFQndyA)
		elif type=='FULL_FILTER':
			gmjZQuBFv8RzlNtDVEOc = KFGqxsBnZYLb3NvMU+'&'+rfJG62Vo0pTEljwPN1WahD7sx4t3QR+'=0'
			qwmxUpZfQj8EAV3Tc = ejQ8ZCtBaV7+'&'+rfJG62Vo0pTEljwPN1WahD7sx4t3QR+'=0'
			vMp6jZbo3UkEsSxRFQndyA = gmjZQuBFv8RzlNtDVEOc+'___'+qwmxUpZfQj8EAV3Tc
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'الجميع :'+name,HOCWKhxITtulVGX,1094,cdZKMn68Pzg4,cdZKMn68Pzg4,vMp6jZbo3UkEsSxRFQndyA)
		dict[rfJG62Vo0pTEljwPN1WahD7sx4t3QR] = {}
		for value,zj6FI51Rypka0e8xiECfc7g in items:
			if value=='196533': zj6FI51Rypka0e8xiECfc7g = 'أفلام نيتفلكس'
			elif value=='196531': zj6FI51Rypka0e8xiECfc7g = 'مسلسلات نيتفلكس'
			if zj6FI51Rypka0e8xiECfc7g in cJWUPuDGM0Yybv5a9KnIrVzhH78: continue
			dict[rfJG62Vo0pTEljwPN1WahD7sx4t3QR][value] = zj6FI51Rypka0e8xiECfc7g
			gmjZQuBFv8RzlNtDVEOc = KFGqxsBnZYLb3NvMU+'&'+rfJG62Vo0pTEljwPN1WahD7sx4t3QR+'='+zj6FI51Rypka0e8xiECfc7g
			qwmxUpZfQj8EAV3Tc = ejQ8ZCtBaV7+'&'+rfJG62Vo0pTEljwPN1WahD7sx4t3QR+'='+value
			AL8gJZ0NtE91Bexjin4 = gmjZQuBFv8RzlNtDVEOc+'___'+qwmxUpZfQj8EAV3Tc
			title = zj6FI51Rypka0e8xiECfc7g+' :'#+dict[rfJG62Vo0pTEljwPN1WahD7sx4t3QR]['0']
			title = zj6FI51Rypka0e8xiECfc7g+' :'+name
			if type=='FULL_FILTER': zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,url,1094,cdZKMn68Pzg4,cdZKMn68Pzg4,AL8gJZ0NtE91Bexjin4)
			elif type=='DEFINED_FILTER' and BWyLSPXqTxQojMGK74EAlNfvmaV[-2]+'=' in KFGqxsBnZYLb3NvMU:
				YqrzmSVb3R9MgUnX2auEHlpBhZD = XFoM2xPKIt3u51hLj(qwmxUpZfQj8EAV3Tc,'modified_filters')
				HOCWKhxITtulVGX = url+'/smartemadfilter?'+YqrzmSVb3R9MgUnX2auEHlpBhZD
				N8jUpQxY0rhtDAzbG4kOs9X = VOx3AWdmCD8cSvXKLgr(HOCWKhxITtulVGX)
				zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,N8jUpQxY0rhtDAzbG4kOs9X,1091)
			else: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,url,1095,cdZKMn68Pzg4,cdZKMn68Pzg4,AL8gJZ0NtE91Bexjin4)
	return
def XFoM2xPKIt3u51hLj(o3JURfrMDgp76,mode):
	o3JURfrMDgp76 = o3JURfrMDgp76.replace('=&','=0&')
	o3JURfrMDgp76 = o3JURfrMDgp76.strip('&')
	bLxfgF7nlO1uZiY9e5T0HDdIw3kpy = {}
	if '=' in o3JURfrMDgp76:
		items = o3JURfrMDgp76.split('&')
		for HYBN2AQsjimSMgT8OvE3ynX67tJwR in items:
			IN0jyfe1PRdDz6YX3CoJkHthw,value = HYBN2AQsjimSMgT8OvE3ynX67tJwR.split('=')
			bLxfgF7nlO1uZiY9e5T0HDdIw3kpy[IN0jyfe1PRdDz6YX3CoJkHthw] = value
	n7VBe6ZgDI14lizTfHOmk = cdZKMn68Pzg4
	for key in SGJUq2RCH79hWyemglnMOpc8bB:
		if key in list(bLxfgF7nlO1uZiY9e5T0HDdIw3kpy.keys()): value = bLxfgF7nlO1uZiY9e5T0HDdIw3kpy[key]
		else: value = '0'
		if '%' not in value: value = YQlEOShHM7RLak2t0yA4NXqv(value)
		if mode=='modified_values' and value!='0': n7VBe6ZgDI14lizTfHOmk = n7VBe6ZgDI14lizTfHOmk+' + '+value
		elif mode=='modified_filters' and value!='0': n7VBe6ZgDI14lizTfHOmk = n7VBe6ZgDI14lizTfHOmk+'&'+key+'='+value
		elif mode=='all': n7VBe6ZgDI14lizTfHOmk = n7VBe6ZgDI14lizTfHOmk+'&'+key+'='+value
	n7VBe6ZgDI14lizTfHOmk = n7VBe6ZgDI14lizTfHOmk.strip(' + ')
	n7VBe6ZgDI14lizTfHOmk = n7VBe6ZgDI14lizTfHOmk.strip('&')
	n7VBe6ZgDI14lizTfHOmk = n7VBe6ZgDI14lizTfHOmk.replace('=0','=')
	return n7VBe6ZgDI14lizTfHOmk
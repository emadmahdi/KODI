# -*- coding: utf-8 -*-
from RgJNGc7YMP import *
UkXlAzsMcamKJrEIgnxi6bWh = 'CIMALIGHT'
nc3GLkA65oxOd = '_CML_'
cDTdfqVAF0BLGiX364IEwaZbr = USuRxnPlV5.SITESURLS[UkXlAzsMcamKJrEIgnxi6bWh][0]
cJWUPuDGM0Yybv5a9KnIrVzhH78 = ['قنوات فضائية']
def HHN5EpbszV3iA2m89hGSQjaPgUZy(mode,url,text):
	if   mode==470: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = kUq58vC7x9hWma164JejMKQ()
	elif mode==471: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = GDQUH4fN02sIt81mAcY(url,text)
	elif mode==472: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = RPZbqous7rtdy56LeI18Cv04AKHW(url)
	elif mode==473: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = m3uV0rQSzFgqE6lIh4Y5bXxjiANDP(url,text)
	elif mode==474: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = oQF2hgjusp8Ne(url)
	elif mode==479: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = z4hetAJw3NaT9ROjG6xbZ5CHlW81(text)
	else: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = False
	return xsGUcR3ef6glKY5hQwpFXEaSt2mrIz
def kUq58vC7x9hWma164JejMKQ():
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',cDTdfqVAF0BLGiX364IEwaZbr,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'CIMALIGHT-MENU-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'بحث في الموقع',cdZKMn68Pzg4,479,cdZKMn68Pzg4,cdZKMn68Pzg4,'_REMEMBERRESULTS_')
	zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"content"(.*?)</div>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
	items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?</i>(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	for c0cDhidBlOn7,title in items:
		title = title.replace(wr0HaqRdJ2D9LT7nSO1KMe38ly,cdZKMn68Pzg4).strip(VBpIH2QSmvDGlA6TO3e)
		c0cDhidBlOn7 = c0cDhidBlOn7.replace('cat=online-movies1','cat=online-movies')
		zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+title,c0cDhidBlOn7,474)
	zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('/category.php">(.*?)"navslide-divider"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall("'dropdown-menu'(.*?)</ul>",OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?>(.*?)</a>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	for c0cDhidBlOn7,title in items:
		if title in cJWUPuDGM0Yybv5a9KnIrVzhH78: continue
		if 'مسلسل ' in title: continue
		if 'برنامج ' in title: continue
		if 'للكبار' in title: continue
		zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+title,c0cDhidBlOn7,474)
	return
def oQF2hgjusp8Ne(url):
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'CIMALIGHT-TITLES-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	if 'topvideos.php' in url: ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"caret"(.*?)id="pm-grid"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	else: ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"caret"(.*?)</ul>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?>(.*?)</a>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,title in items:
			if 'topvideos.php' in c0cDhidBlOn7:
				if 'topvideos.php?c=english-movies' in c0cDhidBlOn7: continue
				if 'topvideos.php?c=online-movies1' in c0cDhidBlOn7: continue
				if 'topvideos.php?c=misc' in c0cDhidBlOn7: continue
				if 'topvideos.php?c=tv-channel' in c0cDhidBlOn7: continue
				if 'منذ البداية' in title and 'do=rating' not in c0cDhidBlOn7: continue
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,471)
	else: GDQUH4fN02sIt81mAcY(url)
	return
def GDQUH4fN02sIt81mAcY(url,CvSX7Etpz80eGlT1brgWZkJ=cdZKMn68Pzg4):
	u1P73L0UmkA4eaIBbCgZfrvRtJ = CxlbPZwGTcH87e1sWhfSIz29uRUEpV(url,'url')
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'CIMALIGHT-TITLES-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	items = []
	if CvSX7Etpz80eGlT1brgWZkJ=='featured_movies':
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"container-fluid"(.*?)</ul>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?"title">(.*?)</div>.*?image:url\(\'(.*?)\'\)',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		zz4ZPovUbyk5GEhNMs8JDnaVXftS,Snu3TYPhdqbc,ggiTmuXzR7bJMjDE06r3 = zip(*items)
		items = zip(ggiTmuXzR7bJMjDE06r3,zz4ZPovUbyk5GEhNMs8JDnaVXftS,Snu3TYPhdqbc)
	elif CvSX7Etpz80eGlT1brgWZkJ=='featured_series':
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('المسلسلات المميزة(.*?)<style>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?title="(.*?)".*?image:url\(\'(.*?)\'\)',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		zz4ZPovUbyk5GEhNMs8JDnaVXftS,Snu3TYPhdqbc,ggiTmuXzR7bJMjDE06r3 = zip(*items)
		items = zip(ggiTmuXzR7bJMjDE06r3,zz4ZPovUbyk5GEhNMs8JDnaVXftS,Snu3TYPhdqbc)
	else:
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('(data-echo=".*?)</ul>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if not ppvsMqCHf8SEzxQg: ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"BlocksList"(.*?)"titleSectionCon"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if not ppvsMqCHf8SEzxQg: ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('id="pm-grid"(.*?)</ul>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if not ppvsMqCHf8SEzxQg: ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('id="pm-related"(.*?)</ul>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if not ppvsMqCHf8SEzxQg: ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('pm-ul-browse-videos(.*?)clearfix',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if not ppvsMqCHf8SEzxQg: return
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
	if not items: items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if not items: items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('src="(.*?)".*?href="(.*?)".*?>(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	KRmzvoWYyxfXw37SEh1Q = []
	rgWUvoaJnZARc375bjQ = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for y90BoFz8MA1ZThaSC2ILXHiK3OY6w,c0cDhidBlOn7,title in items:
		c0cDhidBlOn7 = NLqxoZ37dYf0awrsIE(c0cDhidBlOn7).strip(KCQExdbYFqM)
		title = title.replace('ماي سيما',cdZKMn68Pzg4).replace('مشاهدة',cdZKMn68Pzg4).strip(VBpIH2QSmvDGlA6TO3e).replace(wr0HaqRdJ2D9LT7nSO1KMe38ly,VBpIH2QSmvDGlA6TO3e)
		if 'http' not in c0cDhidBlOn7: c0cDhidBlOn7 = u1P73L0UmkA4eaIBbCgZfrvRtJ+KCQExdbYFqM+c0cDhidBlOn7.strip(KCQExdbYFqM)
		if 'http' not in y90BoFz8MA1ZThaSC2ILXHiK3OY6w: y90BoFz8MA1ZThaSC2ILXHiK3OY6w = u1P73L0UmkA4eaIBbCgZfrvRtJ+KCQExdbYFqM+y90BoFz8MA1ZThaSC2ILXHiK3OY6w.strip(KCQExdbYFqM)
		E0w56WHxZPYGVvnTQ4O2t1C8DAjq = ffUFBJQ57j2XgoGeOLn9uwpC.findall('(.*?) (الحلقة|حلقة) \d+',title,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if any(value in title for value in rgWUvoaJnZARc375bjQ):
			title = '_MOD_'+title
			zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,472,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
		elif E0w56WHxZPYGVvnTQ4O2t1C8DAjq and 'حلقة' in title:
			title = '_MOD_'+E0w56WHxZPYGVvnTQ4O2t1C8DAjq[0][0]
			if title not in KRmzvoWYyxfXw37SEh1Q:
				zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,473,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
				KRmzvoWYyxfXw37SEh1Q.append(title)
		elif '/movseries/' in c0cDhidBlOn7:
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,471,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
		else: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,473,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
	if CvSX7Etpz80eGlT1brgWZkJ not in ['featured_movies','featured_series']:
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"pagination(.*?)</ul>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if ppvsMqCHf8SEzxQg:
			KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
			items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?>(.*?)</a>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			for c0cDhidBlOn7,title in items:
				if c0cDhidBlOn7=='#': continue
				c0cDhidBlOn7 = u1P73L0UmkA4eaIBbCgZfrvRtJ+KCQExdbYFqM+c0cDhidBlOn7.strip(KCQExdbYFqM)
				title = gbd90SjF2mZqf81IRDaTwJkWu(title)
				zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'صفحة '+title,c0cDhidBlOn7,471)
		UrOQ4PapMvq1kRiLeWSGYg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('showmore" href="(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if UrOQ4PapMvq1kRiLeWSGYg:
			c0cDhidBlOn7 = UrOQ4PapMvq1kRiLeWSGYg[0]
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'مشاهدة المزيد',c0cDhidBlOn7,471)
	return
def m3uV0rQSzFgqE6lIh4Y5bXxjiANDP(url,v7BFbdjHVQwcOZ1Il86huxJs9ge):
	u1P73L0UmkA4eaIBbCgZfrvRtJ = CxlbPZwGTcH87e1sWhfSIz29uRUEpV(url,'url')
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'CIMALIGHT-EPISODES-2nd')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	ptXc2zV0RhTb = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"SeasonsBox"(.*?)</div>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	items = []
	if ptXc2zV0RhTb and not v7BFbdjHVQwcOZ1Il86huxJs9ge:
		y90BoFz8MA1ZThaSC2ILXHiK3OY6w = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"series-header".*?src="(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		y90BoFz8MA1ZThaSC2ILXHiK3OY6w = y90BoFz8MA1ZThaSC2ILXHiK3OY6w[0] if y90BoFz8MA1ZThaSC2ILXHiK3OY6w else cdZKMn68Pzg4
		KdWauEhgN6OQzjRVm1ro8tkB3 = ptXc2zV0RhTb[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('openCity\(event\, \'(.*?)\'\)".*?>(.*?)</button>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if len(items)==1: v7BFbdjHVQwcOZ1Il86huxJs9ge = items[0][0]
		elif len(items)>1:
			for v7BFbdjHVQwcOZ1Il86huxJs9ge,title in items: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,url,473,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,cdZKMn68Pzg4,v7BFbdjHVQwcOZ1Il86huxJs9ge)
	ll9vYSyie5kwbR16U0a2K = ffUFBJQ57j2XgoGeOLn9uwpC.findall('id="'+v7BFbdjHVQwcOZ1Il86huxJs9ge+'"(.*?)</ul>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ll9vYSyie5kwbR16U0a2K and len(items)<2:
		y90BoFz8MA1ZThaSC2ILXHiK3OY6w = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"series-header".*?src="(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		y90BoFz8MA1ZThaSC2ILXHiK3OY6w = y90BoFz8MA1ZThaSC2ILXHiK3OY6w[0] if y90BoFz8MA1ZThaSC2ILXHiK3OY6w else cdZKMn68Pzg4
		KdWauEhgN6OQzjRVm1ro8tkB3 = ll9vYSyie5kwbR16U0a2K[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?title="(.*?)"',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if items:
			for c0cDhidBlOn7,title in items:
				title = title.replace('ماي سيما',cdZKMn68Pzg4).replace('مسلسل',cdZKMn68Pzg4).strip(VBpIH2QSmvDGlA6TO3e)
				if 'http' not in c0cDhidBlOn7: c0cDhidBlOn7 = u1P73L0UmkA4eaIBbCgZfrvRtJ+KCQExdbYFqM+c0cDhidBlOn7.strip(KCQExdbYFqM)
				zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,472,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
		else:
			items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?title="(.*?)".*?image:url\((.*?)\)',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			for c0cDhidBlOn7,title,y90BoFz8MA1ZThaSC2ILXHiK3OY6w in items:
				if 'http' not in c0cDhidBlOn7: c0cDhidBlOn7 = u1P73L0UmkA4eaIBbCgZfrvRtJ+KCQExdbYFqM+c0cDhidBlOn7.strip(KCQExdbYFqM)
				zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,472,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
	if 'id="pm-related"' in OO1cj2REUZHJ8x5V:
		if items: zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
		zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'مواضيع ذات صلة',url,471)
	return
def RPZbqous7rtdy56LeI18Cv04AKHW(url):
	pcX7zxFRmsADwUr = []
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'CIMALIGHT-PLAY-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('<div itemprop="description">(.*?)href=',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		eVdYQAPy2Dm = ffUFBJQ57j2XgoGeOLn9uwpC.findall('<p>(.*?)</p>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if eVdYQAPy2Dm and bMOpKuUkQ5J2(UkXlAzsMcamKJrEIgnxi6bWh,url,eVdYQAPy2Dm,True): return
	HOCWKhxITtulVGX = url.replace('/watch.php','/play.php')
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',HOCWKhxITtulVGX,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'CIMALIGHT-PLAY-2nd')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	K8miIPYBMNuvcTweGnlSzWfX = []
	c0cDhidBlOn7 = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"embedded".*?src="(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if c0cDhidBlOn7:
		c0cDhidBlOn7 = c0cDhidBlOn7[0]
		if c0cDhidBlOn7 and c0cDhidBlOn7 not in K8miIPYBMNuvcTweGnlSzWfX:
			K8miIPYBMNuvcTweGnlSzWfX.append(c0cDhidBlOn7)
			c0cDhidBlOn7 = c0cDhidBlOn7+'?named=__embed'
			if 'http' not in c0cDhidBlOn7: c0cDhidBlOn7 = 'http:'+c0cDhidBlOn7
			pcX7zxFRmsADwUr.append(c0cDhidBlOn7)
	items = ffUFBJQ57j2XgoGeOLn9uwpC.findall("iframe src='(.*?)'.*?<strong>(.*?)</strong>",OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	for c0cDhidBlOn7,title in items:
		if c0cDhidBlOn7 not in K8miIPYBMNuvcTweGnlSzWfX:
			K8miIPYBMNuvcTweGnlSzWfX.append(c0cDhidBlOn7)
			c0cDhidBlOn7 = c0cDhidBlOn7+'?named='+title+'__watch'
			if 'http' not in c0cDhidBlOn7: c0cDhidBlOn7 = 'http:'+c0cDhidBlOn7
			pcX7zxFRmsADwUr.append(c0cDhidBlOn7)
	HOCWKhxITtulVGX = url.replace('/watch.php','/downloads.php')
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',HOCWKhxITtulVGX,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'CIMALIGHT-PLAY-3rd')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"downloadlist"(.*?)</ul>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?<strong>(.*?)</strong>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,title in items:
			if c0cDhidBlOn7 not in K8miIPYBMNuvcTweGnlSzWfX:
				K8miIPYBMNuvcTweGnlSzWfX.append(c0cDhidBlOn7)
				c0cDhidBlOn7 = c0cDhidBlOn7+'?named='+title+'__download'
				if 'http' not in c0cDhidBlOn7: c0cDhidBlOn7 = 'http:'+c0cDhidBlOn7
				pcX7zxFRmsADwUr.append(c0cDhidBlOn7)
	import r0y4XTKznF
	r0y4XTKznF.noHliPXkcg3pJTdSauCvm5sU(pcX7zxFRmsADwUr,UkXlAzsMcamKJrEIgnxi6bWh,'video',url)
	return
def z4hetAJw3NaT9ROjG6xbZ5CHlW81(search):
	search,EL8zUgbXheot,showDialogs = qbIcHCMdkFKn21e(search)
	if search==cdZKMn68Pzg4: search = BzkmLuvJD9n25Pg()
	if search==cdZKMn68Pzg4: return
	search = search.replace(VBpIH2QSmvDGlA6TO3e,'+')
	wRlW4txQshKmeXdO7zABrLPT1GbZ0 = CxlbPZwGTcH87e1sWhfSIz29uRUEpV(cDTdfqVAF0BLGiX364IEwaZbr,'url')
	url = wRlW4txQshKmeXdO7zABrLPT1GbZ0+'/search.php?keywords='+search
	GDQUH4fN02sIt81mAcY(url,'search')
	return
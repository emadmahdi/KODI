# -*- coding: utf-8 -*-
from RgJNGc7YMP import *
headers = { 'User-Agent' : cdZKMn68Pzg4 }
UkXlAzsMcamKJrEIgnxi6bWh = 'AKOAMCAM'
nc3GLkA65oxOd = '_AKC_'
cDTdfqVAF0BLGiX364IEwaZbr = USuRxnPlV5.SITESURLS[UkXlAzsMcamKJrEIgnxi6bWh][0]
cJWUPuDGM0Yybv5a9KnIrVzhH78 = ['مصارعة']
def HHN5EpbszV3iA2m89hGSQjaPgUZy(mode,url,text):
	if   mode==350: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = kUq58vC7x9hWma164JejMKQ()
	elif mode==351: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = GDQUH4fN02sIt81mAcY(url,text)
	elif mode==352: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = yIZWSuMpvs3(url)
	elif mode==353: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = RPZbqous7rtdy56LeI18Cv04AKHW(url)
	elif mode==354: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = XxcpMKIUzr0sVDngR(url,'FILTERS___'+text)
	elif mode==355: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = XxcpMKIUzr0sVDngR(url,'CATEGORIES___'+text)
	elif mode==356: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = puWVoBFSQjqI7hMXzOgK59Usbxkda(url)
	elif mode==357: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = I6hlmRPSW04(url)
	elif mode==359: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = z4hetAJw3NaT9ROjG6xbZ5CHlW81(text)
	else: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = False
	return xsGUcR3ef6glKY5hQwpFXEaSt2mrIz
def kUq58vC7x9hWma164JejMKQ():
	zJLApFBcIhnSj('link',nc3GLkA65oxOd+bxf7gZvNK29cEoiAIJlMq0dP+'هذا الموقع مغلق'+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,8)
	zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'بحث في الموقع',cdZKMn68Pzg4,359,cdZKMn68Pzg4,cdZKMn68Pzg4,'_REMEMBERRESULTS_')
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'فلتر محدد',cDTdfqVAF0BLGiX364IEwaZbr,356)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'فلتر كامل',cDTdfqVAF0BLGiX364IEwaZbr,357)
	zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	OO1cj2REUZHJ8x5V = Gc05Efm73C8s(K8DZxE74Afz52gBYbOMtpvql0RJma,cDTdfqVAF0BLGiX364IEwaZbr,cdZKMn68Pzg4,headers,cdZKMn68Pzg4,'AKOAMCAM-MENU-1st')
	HOCWKhxITtulVGX = ffUFBJQ57j2XgoGeOLn9uwpC.findall('recently-container.*?href="(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if HOCWKhxITtulVGX: HOCWKhxITtulVGX = HOCWKhxITtulVGX[0]
	else: HOCWKhxITtulVGX = cDTdfqVAF0BLGiX364IEwaZbr
	zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+'اضيف حديثا',HOCWKhxITtulVGX,351)
	HOCWKhxITtulVGX = ffUFBJQ57j2XgoGeOLn9uwpC.findall('@id":"(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if HOCWKhxITtulVGX: HOCWKhxITtulVGX = HOCWKhxITtulVGX[0]
	else: HOCWKhxITtulVGX = cDTdfqVAF0BLGiX364IEwaZbr
	zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+'المميزة',HOCWKhxITtulVGX,351,cdZKMn68Pzg4,cdZKMn68Pzg4,'featured')
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('main-categories-list(.*?)main-categories-list',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?class="font.*?>(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,title in items:
			if title not in cJWUPuDGM0Yybv5a9KnIrVzhH78: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,351)
		zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="categories-box(.*?)<footer',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?">(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,title in items:
			c0cDhidBlOn7 = gbd90SjF2mZqf81IRDaTwJkWu(c0cDhidBlOn7)
			if title not in cJWUPuDGM0Yybv5a9KnIrVzhH78: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,351)
	return OO1cj2REUZHJ8x5V
def puWVoBFSQjqI7hMXzOgK59Usbxkda(website=cdZKMn68Pzg4):
	OO1cj2REUZHJ8x5V = Gc05Efm73C8s(r43t1YI9deXA5N,cDTdfqVAF0BLGiX364IEwaZbr,cdZKMn68Pzg4,headers,cdZKMn68Pzg4,'AKOAMCAM-MENU-1st')
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="menu(.*?)<nav',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?text">(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,title in items:
			if title not in cJWUPuDGM0Yybv5a9KnIrVzhH78:
				title = title+' مصنفة'
				zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,355)
		if website==cdZKMn68Pzg4: zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	return OO1cj2REUZHJ8x5V
def I6hlmRPSW04(website=cdZKMn68Pzg4):
	OO1cj2REUZHJ8x5V = Gc05Efm73C8s(r43t1YI9deXA5N,cDTdfqVAF0BLGiX364IEwaZbr,cdZKMn68Pzg4,headers,cdZKMn68Pzg4,'AKOAMCAM-MENU-1st')
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="menu(.*?)<nav',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?text">(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,title in items:
			if title not in cJWUPuDGM0Yybv5a9KnIrVzhH78:
				title = title+' مفلترة'
				zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,354)
		if website==cdZKMn68Pzg4: zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	return OO1cj2REUZHJ8x5V
def GDQUH4fN02sIt81mAcY(url,type=cdZKMn68Pzg4):
	OO1cj2REUZHJ8x5V = Gc05Efm73C8s(fS25N8gAZxpbnLi3srX7PJ,url,cdZKMn68Pzg4,headers,True,'AKOAMCAM-TITLES-1st')
	if type=='featured': ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('swiper-container(.*?)swiper-button-prev',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	else: ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="container"(.*?)main-footer',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('xlink:href="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		KRmzvoWYyxfXw37SEh1Q = []
		for y90BoFz8MA1ZThaSC2ILXHiK3OY6w,c0cDhidBlOn7,title in items:
			title = gbd90SjF2mZqf81IRDaTwJkWu(title)
			if 'الحلقة' in title or 'الحلقه' in title:
				E0w56WHxZPYGVvnTQ4O2t1C8DAjq = ffUFBJQ57j2XgoGeOLn9uwpC.findall('(.*?) (الحلقة|الحلقه) \d+',title,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
				if E0w56WHxZPYGVvnTQ4O2t1C8DAjq:
					title = '_MOD_' + E0w56WHxZPYGVvnTQ4O2t1C8DAjq[0][0]
					if title not in KRmzvoWYyxfXw37SEh1Q:
						zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,352,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
						KRmzvoWYyxfXw37SEh1Q.append(title)
			elif 'مسلسل' in title:
				zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,352,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
			else: zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,353,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('pagination(.*?)</div>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href=["\'](.*?)["\'].*?>(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,title in items:
			c0cDhidBlOn7 = gbd90SjF2mZqf81IRDaTwJkWu(c0cDhidBlOn7)
			title = gbd90SjF2mZqf81IRDaTwJkWu(title)
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'صفحة '+title,c0cDhidBlOn7,351)
	return
def z4hetAJw3NaT9ROjG6xbZ5CHlW81(search):
	search,EL8zUgbXheot,showDialogs = qbIcHCMdkFKn21e(search)
	if search==cdZKMn68Pzg4: search = BzkmLuvJD9n25Pg()
	if search==cdZKMn68Pzg4: return
	nuKdVC6ePlg = search.replace(VBpIH2QSmvDGlA6TO3e,'+')
	url = cDTdfqVAF0BLGiX364IEwaZbr + '/?s='+nuKdVC6ePlg
	xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = GDQUH4fN02sIt81mAcY(url)
	return
def yIZWSuMpvs3(url):
	OO1cj2REUZHJ8x5V = Gc05Efm73C8s(K8DZxE74Afz52gBYbOMtpvql0RJma,url,cdZKMn68Pzg4,headers,True,'AKOAMCAM-EPISODES-1st')
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('text-white">الحلقات(.*?)<header',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		PCktNV4H3DEOSpeh = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(http.*?)".*?src="(.*?)".*?alt="(.*?)"',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,title in PCktNV4H3DEOSpeh:
			if 'الحلقة' in title or 'الحلقه' in title: zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,353,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
	else:
		y90BoFz8MA1ZThaSC2ILXHiK3OY6w = bu6LzUQF7K.getInfoLabel('ListItem.Icon')
		if OO1cj2REUZHJ8x5V.count('<title>')>1: title = ffUFBJQ57j2XgoGeOLn9uwpC.findall('<title>(.*?)<',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)[1]
		else: title = 'رابط التشغيل'
		zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,url,353,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
	return
def RPZbqous7rtdy56LeI18Cv04AKHW(url):
	pcX7zxFRmsADwUr,lycT0JB1noerD5YANK2PbHa8QVM = [],[]
	F6HXplv3ahRQsPd = e4qbrCQPyuMjpK(r43t1YI9deXA5N,'GET',url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'AKOAMCAM-PLAY-1st')
	OO1cj2REUZHJ8x5V = F6HXplv3ahRQsPd.content
	eaZTIfi39lq7WXOEYvS10VyJUGpnKc = ffUFBJQ57j2XgoGeOLn9uwpC.findall('post_id=(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if eaZTIfi39lq7WXOEYvS10VyJUGpnKc:
		eaZTIfi39lq7WXOEYvS10VyJUGpnKc = eaZTIfi39lq7WXOEYvS10VyJUGpnKc[0]
		headers = {'User-Agent':cdZKMn68Pzg4,'Content-Type':'application/x-www-form-urlencoded'}
		data = {'post_id':eaZTIfi39lq7WXOEYvS10VyJUGpnKc}
		HOCWKhxITtulVGX = cDTdfqVAF0BLGiX364IEwaZbr+'/wp-content/themes/aflam8kkk/Inc/Ajax/Single/Watch.php'
		FZ7MtGLzcp63nTaxJNuqHbCEfgV = e4qbrCQPyuMjpK(r43t1YI9deXA5N,'POST',HOCWKhxITtulVGX,data,headers,cdZKMn68Pzg4,cdZKMn68Pzg4,'AKOAMCAM-PLAY-1st')
		JJPEReUDbt0QoWHkL21TA = FZ7MtGLzcp63nTaxJNuqHbCEfgV.content
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('data-server="(.*?)".*?class="text">(.*?)<',JJPEReUDbt0QoWHkL21TA,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for C5nqNRT6tDkg,name in items:
			c0cDhidBlOn7 = 'https://w.akoam.cam/wp-content/themes/aflam8kkk/Inc/Ajax/Single/Server.php'
			c0cDhidBlOn7 = c0cDhidBlOn7+'?postid='+eaZTIfi39lq7WXOEYvS10VyJUGpnKc+'&serverid='+C5nqNRT6tDkg+'?named='+name+'__watch'
			pcX7zxFRmsADwUr.append(c0cDhidBlOn7)
			lycT0JB1noerD5YANK2PbHa8QVM.append(name)
		HOCWKhxITtulVGX = cDTdfqVAF0BLGiX364IEwaZbr+'/wp-content/themes/aflam8kkk/Inc/Ajax/Single/Download.php'
		FZ7MtGLzcp63nTaxJNuqHbCEfgV = e4qbrCQPyuMjpK(r43t1YI9deXA5N,'POST',HOCWKhxITtulVGX,data,headers,cdZKMn68Pzg4,cdZKMn68Pzg4,'AKOAMCAM-PLAY-1st')
		JJPEReUDbt0QoWHkL21TA = FZ7MtGLzcp63nTaxJNuqHbCEfgV.content
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?class="text">(.*?)<',JJPEReUDbt0QoWHkL21TA,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,title in items:
			c0cDhidBlOn7 = c0cDhidBlOn7.strip(VBpIH2QSmvDGlA6TO3e)
			c0cDhidBlOn7 = c0cDhidBlOn7+'?named='+title+'__download'
			pcX7zxFRmsADwUr.append(c0cDhidBlOn7)
			lycT0JB1noerD5YANK2PbHa8QVM.append(title)
	import r0y4XTKznF
	r0y4XTKznF.noHliPXkcg3pJTdSauCvm5sU(pcX7zxFRmsADwUr,UkXlAzsMcamKJrEIgnxi6bWh,'video',url)
	return
def XxcpMKIUzr0sVDngR(url,filter):
	fCAW9dmInLiV = ['cat','genre','release-year','quality','orderby']
	if '?' in url: url = url.split('?')[0]
	type,filter = filter.split('___',1)
	if filter==cdZKMn68Pzg4: KFGqxsBnZYLb3NvMU,ejQ8ZCtBaV7 = cdZKMn68Pzg4,cdZKMn68Pzg4
	else: KFGqxsBnZYLb3NvMU,ejQ8ZCtBaV7 = filter.split('___')
	if type=='CATEGORIES':
		if fCAW9dmInLiV[0]+'=' not in KFGqxsBnZYLb3NvMU: rrb0SF6otehufCYOX4 = fCAW9dmInLiV[0]
		for WCqkctAYD2O3Hz7Fl8fKRS5 in range(len(fCAW9dmInLiV[0:-1])):
			if fCAW9dmInLiV[WCqkctAYD2O3Hz7Fl8fKRS5]+'=' in KFGqxsBnZYLb3NvMU: rrb0SF6otehufCYOX4 = fCAW9dmInLiV[WCqkctAYD2O3Hz7Fl8fKRS5+1]
		gmjZQuBFv8RzlNtDVEOc = KFGqxsBnZYLb3NvMU+'&'+rrb0SF6otehufCYOX4+'=0'
		qwmxUpZfQj8EAV3Tc = ejQ8ZCtBaV7+'&'+rrb0SF6otehufCYOX4+'=0'
		vMp6jZbo3UkEsSxRFQndyA = gmjZQuBFv8RzlNtDVEOc.strip('&')+'___'+qwmxUpZfQj8EAV3Tc.strip('&')
		YqrzmSVb3R9MgUnX2auEHlpBhZD = XFoM2xPKIt3u51hLj(ejQ8ZCtBaV7,'all')
		HOCWKhxITtulVGX = url+'?'+YqrzmSVb3R9MgUnX2auEHlpBhZD
	elif type=='FILTERS':
		zM2ZBJ4IYN8osGTtwgRheLu6dU = XFoM2xPKIt3u51hLj(KFGqxsBnZYLb3NvMU,'modified_values')
		zM2ZBJ4IYN8osGTtwgRheLu6dU = NLqxoZ37dYf0awrsIE(zM2ZBJ4IYN8osGTtwgRheLu6dU)
		if ejQ8ZCtBaV7!=cdZKMn68Pzg4: ejQ8ZCtBaV7 = XFoM2xPKIt3u51hLj(ejQ8ZCtBaV7,'all')
		if ejQ8ZCtBaV7==cdZKMn68Pzg4: HOCWKhxITtulVGX = url
		else: HOCWKhxITtulVGX = url+'?'+ejQ8ZCtBaV7
		zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'أظهار قائمة الفيديو التي تم اختيارها',HOCWKhxITtulVGX,351,cdZKMn68Pzg4,'1')
		zJLApFBcIhnSj('folder',nc3GLkA65oxOd+' [[   '+zM2ZBJ4IYN8osGTtwgRheLu6dU+'   ]]',HOCWKhxITtulVGX,351,cdZKMn68Pzg4,'1')
		zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	OO1cj2REUZHJ8x5V = Gc05Efm73C8s(r43t1YI9deXA5N,url,cdZKMn68Pzg4,headers,True,'AKOAMCAM-FILTERS_MENU-1st')
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('<form id(.*?)</form>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
	hQ9ADnZlSxI1m8ui = ffUFBJQ57j2XgoGeOLn9uwpC.findall('<select.*?name="(.*?)".*?">(.*?)<(.*?)</select>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	dict = {}
	for rfJG62Vo0pTEljwPN1WahD7sx4t3QR,name,KdWauEhgN6OQzjRVm1ro8tkB3 in hQ9ADnZlSxI1m8ui:
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('<option(.*?)>(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if '=' not in HOCWKhxITtulVGX: HOCWKhxITtulVGX = url
		if type=='CATEGORIES':
			if rrb0SF6otehufCYOX4!=rfJG62Vo0pTEljwPN1WahD7sx4t3QR: continue
			elif len(items)<=1:
				if rfJG62Vo0pTEljwPN1WahD7sx4t3QR==fCAW9dmInLiV[-1]: GDQUH4fN02sIt81mAcY(HOCWKhxITtulVGX)
				else: XxcpMKIUzr0sVDngR(HOCWKhxITtulVGX,'CATEGORIES___'+vMp6jZbo3UkEsSxRFQndyA)
				return
			else:
				if rfJG62Vo0pTEljwPN1WahD7sx4t3QR==fCAW9dmInLiV[-1]: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'الجميع',HOCWKhxITtulVGX,351,cdZKMn68Pzg4,'1')
				else: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'الجميع',HOCWKhxITtulVGX,355,cdZKMn68Pzg4,cdZKMn68Pzg4,vMp6jZbo3UkEsSxRFQndyA)
		elif type=='FILTERS':
			gmjZQuBFv8RzlNtDVEOc = KFGqxsBnZYLb3NvMU+'&'+rfJG62Vo0pTEljwPN1WahD7sx4t3QR+'=0'
			qwmxUpZfQj8EAV3Tc = ejQ8ZCtBaV7+'&'+rfJG62Vo0pTEljwPN1WahD7sx4t3QR+'=0'
			vMp6jZbo3UkEsSxRFQndyA = gmjZQuBFv8RzlNtDVEOc+'___'+qwmxUpZfQj8EAV3Tc
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'الجميع : '+name,HOCWKhxITtulVGX,354,cdZKMn68Pzg4,cdZKMn68Pzg4,vMp6jZbo3UkEsSxRFQndyA)
		dict[rfJG62Vo0pTEljwPN1WahD7sx4t3QR] = {}
		for value,zj6FI51Rypka0e8xiECfc7g in items:
			if zj6FI51Rypka0e8xiECfc7g in cJWUPuDGM0Yybv5a9KnIrVzhH78: continue
			if 'value' not in value: value = zj6FI51Rypka0e8xiECfc7g
			else: value = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"(.*?)"',value,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)[0]
			dict[rfJG62Vo0pTEljwPN1WahD7sx4t3QR][value] = zj6FI51Rypka0e8xiECfc7g
			gmjZQuBFv8RzlNtDVEOc = KFGqxsBnZYLb3NvMU+'&'+rfJG62Vo0pTEljwPN1WahD7sx4t3QR+'='+zj6FI51Rypka0e8xiECfc7g
			qwmxUpZfQj8EAV3Tc = ejQ8ZCtBaV7+'&'+rfJG62Vo0pTEljwPN1WahD7sx4t3QR+'='+value
			AL8gJZ0NtE91Bexjin4 = gmjZQuBFv8RzlNtDVEOc+'___'+qwmxUpZfQj8EAV3Tc
			title = zj6FI51Rypka0e8xiECfc7g+' : '#+dict[rfJG62Vo0pTEljwPN1WahD7sx4t3QR]['0']
			title = zj6FI51Rypka0e8xiECfc7g+' : '+name
			if type=='FILTERS': zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,url,354,cdZKMn68Pzg4,cdZKMn68Pzg4,AL8gJZ0NtE91Bexjin4)
			elif type=='CATEGORIES' and fCAW9dmInLiV[-2]+'=' in KFGqxsBnZYLb3NvMU:
				YqrzmSVb3R9MgUnX2auEHlpBhZD = XFoM2xPKIt3u51hLj(qwmxUpZfQj8EAV3Tc,'all')
				N8jUpQxY0rhtDAzbG4kOs9X = url+'?'+YqrzmSVb3R9MgUnX2auEHlpBhZD
				zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,N8jUpQxY0rhtDAzbG4kOs9X,351,cdZKMn68Pzg4,'1')
			else: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,url,355,cdZKMn68Pzg4,cdZKMn68Pzg4,AL8gJZ0NtE91Bexjin4)
	return
def XFoM2xPKIt3u51hLj(o3JURfrMDgp76,mode):
	o3JURfrMDgp76 = o3JURfrMDgp76.strip('&')
	bLxfgF7nlO1uZiY9e5T0HDdIw3kpy = {}
	if '=' in o3JURfrMDgp76:
		items = o3JURfrMDgp76.split('&')
		for HYBN2AQsjimSMgT8OvE3ynX67tJwR in items:
			IN0jyfe1PRdDz6YX3CoJkHthw,value = HYBN2AQsjimSMgT8OvE3ynX67tJwR.split('=')
			bLxfgF7nlO1uZiY9e5T0HDdIw3kpy[IN0jyfe1PRdDz6YX3CoJkHthw] = value
	n7VBe6ZgDI14lizTfHOmk = cdZKMn68Pzg4
	w6wuL59PgeE = ['cat','genre','release-year','quality','orderby']
	for key in w6wuL59PgeE:
		if key in list(bLxfgF7nlO1uZiY9e5T0HDdIw3kpy.keys()): value = bLxfgF7nlO1uZiY9e5T0HDdIw3kpy[key]
		else: value = '0'
		if mode=='modified_values' and value!='0': n7VBe6ZgDI14lizTfHOmk = n7VBe6ZgDI14lizTfHOmk+' + '+value
		elif mode=='modified_filters' and value!='0': n7VBe6ZgDI14lizTfHOmk = n7VBe6ZgDI14lizTfHOmk+'&'+key+'='+value
		elif mode=='all': n7VBe6ZgDI14lizTfHOmk = n7VBe6ZgDI14lizTfHOmk+'&'+key+'='+value
	n7VBe6ZgDI14lizTfHOmk = n7VBe6ZgDI14lizTfHOmk.strip(' + ')
	n7VBe6ZgDI14lizTfHOmk = n7VBe6ZgDI14lizTfHOmk.strip('&')
	return n7VBe6ZgDI14lizTfHOmk
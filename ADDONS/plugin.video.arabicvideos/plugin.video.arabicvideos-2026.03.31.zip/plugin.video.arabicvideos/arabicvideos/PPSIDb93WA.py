# -*- coding: utf-8 -*-
from RgJNGc7YMP import *
UkXlAzsMcamKJrEIgnxi6bWh = 'SHAHID4U'
nc3GLkA65oxOd = '_SH4_'
cDTdfqVAF0BLGiX364IEwaZbr = USuRxnPlV5.SITESURLS[UkXlAzsMcamKJrEIgnxi6bWh][0]
headers = {'User-Agent':knzwM2WCl7jAex9H4YFva(True)}
cJWUPuDGM0Yybv5a9KnIrVzhH78 = ['عروض مصارعة','الكل','افلام','javascript','مصارعة حرة']
def HHN5EpbszV3iA2m89hGSQjaPgUZy(mode,url,text):
	if   mode==110: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = kUq58vC7x9hWma164JejMKQ()
	elif mode==111: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = GDQUH4fN02sIt81mAcY(url,text)
	elif mode==112: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = RPZbqous7rtdy56LeI18Cv04AKHW(url)
	elif mode==113: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = yIZWSuMpvs3(url,True)
	elif mode==114: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = XxcpMKIUzr0sVDngR(url,'FULL_FILTER___'+text)
	elif mode==115: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = XxcpMKIUzr0sVDngR(url,'DEFINED_FILTER___'+text)
	elif mode==116: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = yIZWSuMpvs3(url,False)
	elif mode==119: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = z4hetAJw3NaT9ROjG6xbZ5CHlW81(text)
	else: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = False
	return xsGUcR3ef6glKY5hQwpFXEaSt2mrIz
def kUq58vC7x9hWma164JejMKQ():
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'بحث في الموقع',cdZKMn68Pzg4,119,cdZKMn68Pzg4,cdZKMn68Pzg4,'_REMEMBERRESULTS_')
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'فلتر محدد',cDTdfqVAF0BLGiX364IEwaZbr,115)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'فلتر كامل',cDTdfqVAF0BLGiX364IEwaZbr,114)
	zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'المميزة',cDTdfqVAF0BLGiX364IEwaZbr,111,cdZKMn68Pzg4,cdZKMn68Pzg4,'featured')
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',cDTdfqVAF0BLGiX364IEwaZbr,cdZKMn68Pzg4,headers,cdZKMn68Pzg4,cdZKMn68Pzg4,'SHAHID4U-MENU-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('simple-filter(.*?)adv-filter',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if not ppvsMqCHf8SEzxQg:
		NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,'موقع شاهد فوريو','البرنامج لم يستطيع إيجاد عنوان الموقع أو تصميم الموقع تغير')
		return
	else:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('location = \'(.*?)\'.*?src="(.*?)".*?<h3>(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for filter,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,title in items:
			url = cDTdfqVAF0BLGiX364IEwaZbr+filter
			zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+title,url,111,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,cdZKMn68Pzg4,filter)
		zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="dropdown"(.*?)<script>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?>(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,title in items:
			title = title.replace(ssELJkeScrtni2,cdZKMn68Pzg4).replace(CPjOZMmw8sfGg2B9LthIdXa1iKQUF,cdZKMn68Pzg4).strip(VBpIH2QSmvDGlA6TO3e)
			if title in cJWUPuDGM0Yybv5a9KnIrVzhH78: continue
			if 'http' not in c0cDhidBlOn7: c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr+c0cDhidBlOn7
			if 'netflix' in c0cDhidBlOn7: title = 'نيتفلكس'
			zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+title,c0cDhidBlOn7,111)
	return OO1cj2REUZHJ8x5V
def GDQUH4fN02sIt81mAcY(url,w3wLtqKIc0=cdZKMn68Pzg4,Zty0AsgQ5jpkTh91OW=cdZKMn68Pzg4):
	if not Zty0AsgQ5jpkTh91OW: Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',url,cdZKMn68Pzg4,headers,cdZKMn68Pzg4,cdZKMn68Pzg4,'SHAHID4U-TITLES-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	ppvsMqCHf8SEzxQg,items,KRmzvoWYyxfXw37SEh1Q = [],[],[]
	if w3wLtqKIc0=='featured': ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('glide__slides(.*?)</ul>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	else: ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('shows-container(.*?)pagination',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if not ppvsMqCHf8SEzxQg: return
	KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
	if not items: items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?url\((.*?)\).*?"title">(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	rgWUvoaJnZARc375bjQ = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for c0cDhidBlOn7,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,title in items:
		if 'WWE' in title: continue
		if 'javascript' in c0cDhidBlOn7: continue
		c0cDhidBlOn7 = NLqxoZ37dYf0awrsIE(c0cDhidBlOn7).strip(KCQExdbYFqM)
		title = gbd90SjF2mZqf81IRDaTwJkWu(title)
		title = title.strip(VBpIH2QSmvDGlA6TO3e)
		E0w56WHxZPYGVvnTQ4O2t1C8DAjq = ffUFBJQ57j2XgoGeOLn9uwpC.findall('(.*?) الحلقة \d+',title,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if '/film/' in c0cDhidBlOn7 or 'فيلم' in c0cDhidBlOn7 or any(value in title for value in rgWUvoaJnZARc375bjQ):
			zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,112,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
		elif E0w56WHxZPYGVvnTQ4O2t1C8DAjq and 'الحلقة' in title and '/list' not in url:
			title = '_MOD_' + E0w56WHxZPYGVvnTQ4O2t1C8DAjq[0]
			if title not in KRmzvoWYyxfXw37SEh1Q:
				zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,113,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
				KRmzvoWYyxfXw37SEh1Q.append(title)
		elif '/actor/' in c0cDhidBlOn7:
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,111,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
		elif '/series/' in c0cDhidBlOn7 and '/list' not in url:
			c0cDhidBlOn7 = c0cDhidBlOn7+'/list'
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,111,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
		elif '/list' in url and 'حلقة' in title:
			zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,112,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
		else: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,113,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"pagination"(.*?)</ul>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg and w3wLtqKIc0!='featured':
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		if w3wLtqKIc0!='search': items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('(updateQuery).*?>(.+?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		else: items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('<li>.*?href="(.*?)">(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if 'page=' in url: url = url.split('page=',1)[0][:-1]
		for c0cDhidBlOn7,title in items:
			title = title.replace(ssELJkeScrtni2,cdZKMn68Pzg4).replace(CPjOZMmw8sfGg2B9LthIdXa1iKQUF,cdZKMn68Pzg4)
			title = title.strip(VBpIH2QSmvDGlA6TO3e)
			if w3wLtqKIc0!='search':
				c0cDhidBlOn7 = url+'&page='+title if '?' in url else url+'?page='+title
			title = gbd90SjF2mZqf81IRDaTwJkWu(title)
			if title: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'صفحة '+title,c0cDhidBlOn7,111,cdZKMn68Pzg4,cdZKMn68Pzg4,w3wLtqKIc0)
	return
def yIZWSuMpvs3(url,t3m6oclnhrPOvH7zW):
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',url,cdZKMn68Pzg4,headers,cdZKMn68Pzg4,cdZKMn68Pzg4,'SHAHID4U-EPISODES-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('items d-flex(.*?)</div>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if len(ppvsMqCHf8SEzxQg)>1:
		if '/season/' in ppvsMqCHf8SEzxQg[0]: DFNaireZ7Akmt3syhvJfCRwdE5z,PCktNV4H3DEOSpeh = ppvsMqCHf8SEzxQg[0],ppvsMqCHf8SEzxQg[1]
		else: DFNaireZ7Akmt3syhvJfCRwdE5z,PCktNV4H3DEOSpeh = ppvsMqCHf8SEzxQg[1],ppvsMqCHf8SEzxQg[0]
	else: DFNaireZ7Akmt3syhvJfCRwdE5z,PCktNV4H3DEOSpeh = ppvsMqCHf8SEzxQg[0],ppvsMqCHf8SEzxQg[0]
	for DXAlBvH2ITZoyunMU0Rq3pw7sx in range(2):
		if t3m6oclnhrPOvH7zW: mode,type,KdWauEhgN6OQzjRVm1ro8tkB3 = 116,'folder',DFNaireZ7Akmt3syhvJfCRwdE5z
		else: mode,type,KdWauEhgN6OQzjRVm1ro8tkB3 = 112,'video',PCktNV4H3DEOSpeh
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?span.*?">(.*?)<.*?span.*?">(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if t3m6oclnhrPOvH7zW and len(items)<2:
			t3m6oclnhrPOvH7zW = False
			continue
		for c0cDhidBlOn7,CCpDMVI0dq2,UHXfFEWmlxMAnzju4 in items:
			title = CCpDMVI0dq2+VBpIH2QSmvDGlA6TO3e+UHXfFEWmlxMAnzju4
			zJLApFBcIhnSj(type,nc3GLkA65oxOd+title,c0cDhidBlOn7,mode)
		break
	if not items and '/episodes' in OO1cj2REUZHJ8x5V:
		dd4lCYjmc65feZy = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="breadcrumb"(.*?)</div>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if dd4lCYjmc65feZy:
			KdWauEhgN6OQzjRVm1ro8tkB3 = dd4lCYjmc65feZy[0]
			zz4ZPovUbyk5GEhNMs8JDnaVXftS = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)"',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			if len(zz4ZPovUbyk5GEhNMs8JDnaVXftS)>2:
				c0cDhidBlOn7 = zz4ZPovUbyk5GEhNMs8JDnaVXftS[2]+'list'
				GDQUH4fN02sIt81mAcY(c0cDhidBlOn7)
	return
def RPZbqous7rtdy56LeI18Cv04AKHW(url):
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(r43t1YI9deXA5N,'GET',url,cdZKMn68Pzg4,headers,cdZKMn68Pzg4,cdZKMn68Pzg4,'SHAHID4U-PLAY-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="actions(.*?)</div>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if not ppvsMqCHf8SEzxQg: return
	KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
	zz4ZPovUbyk5GEhNMs8JDnaVXftS = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)"',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	an7RJC4k5gh = '/watch/' in KdWauEhgN6OQzjRVm1ro8tkB3
	download = '/download/' in KdWauEhgN6OQzjRVm1ro8tkB3
	if   an7RJC4k5gh and not download: JjFAsD5y8KlVx4twkmYSarE,uoJt9Es85B = zz4ZPovUbyk5GEhNMs8JDnaVXftS[0],cdZKMn68Pzg4
	elif not an7RJC4k5gh and download: JjFAsD5y8KlVx4twkmYSarE,uoJt9Es85B = cdZKMn68Pzg4,zz4ZPovUbyk5GEhNMs8JDnaVXftS[0]
	elif an7RJC4k5gh and download: JjFAsD5y8KlVx4twkmYSarE,uoJt9Es85B = zz4ZPovUbyk5GEhNMs8JDnaVXftS[0],zz4ZPovUbyk5GEhNMs8JDnaVXftS[1]
	else: JjFAsD5y8KlVx4twkmYSarE,uoJt9Es85B = cdZKMn68Pzg4,cdZKMn68Pzg4
	pcX7zxFRmsADwUr = []
	if an7RJC4k5gh:
		Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(r43t1YI9deXA5N,'GET',JjFAsD5y8KlVx4twkmYSarE,cdZKMn68Pzg4,headers,cdZKMn68Pzg4,cdZKMn68Pzg4,'SHAHID4U-PLAY-2nd')
		JJPEReUDbt0QoWHkL21TA = Zty0AsgQ5jpkTh91OW.content
		ll9vYSyie5kwbR16U0a2K = ffUFBJQ57j2XgoGeOLn9uwpC.findall('let servers(.*?)player',JJPEReUDbt0QoWHkL21TA,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL|ffUFBJQ57j2XgoGeOLn9uwpC.IGNORECASE)
		if ll9vYSyie5kwbR16U0a2K:
			PfGSURJ9jeNtx7FX = ll9vYSyie5kwbR16U0a2K[0]
			zaUqdBJDmY = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"name":"(.*?)".*?"url":"(.*?)"',PfGSURJ9jeNtx7FX,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			for title,c0cDhidBlOn7 in zaUqdBJDmY:
				c0cDhidBlOn7 = c0cDhidBlOn7.replace('\\/',KCQExdbYFqM)
				c0cDhidBlOn7 = c0cDhidBlOn7+'?named='+title+'__watch'
				pcX7zxFRmsADwUr.append(c0cDhidBlOn7)
	if download:
		Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(r43t1YI9deXA5N,'GET',uoJt9Es85B,cdZKMn68Pzg4,headers,cdZKMn68Pzg4,cdZKMn68Pzg4,'SHAHID4U-PLAY-3rd')
		JJPEReUDbt0QoWHkL21TA = Zty0AsgQ5jpkTh91OW.content
		ll9vYSyie5kwbR16U0a2K = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"servers"(.*?)info-container',JJPEReUDbt0QoWHkL21TA,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if ll9vYSyie5kwbR16U0a2K:
			PfGSURJ9jeNtx7FX = ll9vYSyie5kwbR16U0a2K[0]
			zaUqdBJDmY = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?<span>(.*?)<.*?</i>.*?<span>(.*?)<',PfGSURJ9jeNtx7FX,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			for c0cDhidBlOn7,title,l1MCIuwhAELbO2eJ96kNta7rp0B in zaUqdBJDmY:
				c0cDhidBlOn7 = c0cDhidBlOn7+'?named='+title+'__download'+'____'+l1MCIuwhAELbO2eJ96kNta7rp0B
				pcX7zxFRmsADwUr.append(c0cDhidBlOn7)
	import r0y4XTKznF
	r0y4XTKznF.noHliPXkcg3pJTdSauCvm5sU(pcX7zxFRmsADwUr,UkXlAzsMcamKJrEIgnxi6bWh,'video',url)
	return
def z4hetAJw3NaT9ROjG6xbZ5CHlW81(search):
	search,EL8zUgbXheot,showDialogs = qbIcHCMdkFKn21e(search)
	if not search:
		search = BzkmLuvJD9n25Pg()
		if not search: return
	search = search.replace(VBpIH2QSmvDGlA6TO3e,'+')
	url = cDTdfqVAF0BLGiX364IEwaZbr+'/search?s='+search
	GDQUH4fN02sIt81mAcY(url,'search')
	return
def J1BMh3gS6EbcwT284RdnKzkitfUqW(url):
	url = url.split('/smartemadfilter?')[0]
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(r43t1YI9deXA5N,'GET',url,cdZKMn68Pzg4,headers,cdZKMn68Pzg4,cdZKMn68Pzg4,'SHAHID4U-GET_FILTERS_BLOCKS-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	hQ9ADnZlSxI1m8ui = []
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('adv-filter(.*?)shows-container',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		hQ9ADnZlSxI1m8ui = ffUFBJQ57j2XgoGeOLn9uwpC.findall('''updateQuery\('(.*?)'.*?value.*?>(.*?)<(.*?)</select''',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		uN1gsqUIpJSERY4,OTVQcUsEmXhfdL38,akIvSitzr0mKe = zip(*hQ9ADnZlSxI1m8ui)
		hQ9ADnZlSxI1m8ui = zip(OTVQcUsEmXhfdL38,uN1gsqUIpJSERY4,akIvSitzr0mKe)
	return hQ9ADnZlSxI1m8ui
def ycYdX9u6W0oOnbMaDlf4KiPz(KdWauEhgN6OQzjRVm1ro8tkB3):
	items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('value="(.*?)".*?>\s*(.*?)\s*<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	return items
def VOx3AWdmCD8cSvXKLgr(url):
	if '/smartemadfilter?' not in url: url = url+'/smartemadfilter?'
	NLpSEUdj5H081igYnC4TbA2QtoVclF = url.split('/smartemadfilter?')[0]
	YYpjB2CuTidaMgcGrlJOswovm = CxlbPZwGTcH87e1sWhfSIz29uRUEpV(url,'url')
	url = url.replace(NLpSEUdj5H081igYnC4TbA2QtoVclF,YYpjB2CuTidaMgcGrlJOswovm)
	url = url.replace('/smartemadfilter?','/?')
	return url
SGJUq2RCH79hWyemglnMOpc8bB = ['quality','year','genre','category']
BWyLSPXqTxQojMGK74EAlNfvmaV = ['category','genre','year']
def XxcpMKIUzr0sVDngR(url,filter):
	url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==cdZKMn68Pzg4: KFGqxsBnZYLb3NvMU,ejQ8ZCtBaV7 = cdZKMn68Pzg4,cdZKMn68Pzg4
	else: KFGqxsBnZYLb3NvMU,ejQ8ZCtBaV7 = filter.split('___')
	if type=='DEFINED_FILTER':
		if BWyLSPXqTxQojMGK74EAlNfvmaV[0]+'=' not in KFGqxsBnZYLb3NvMU: rrb0SF6otehufCYOX4 = BWyLSPXqTxQojMGK74EAlNfvmaV[0]
		for WCqkctAYD2O3Hz7Fl8fKRS5 in range(len(BWyLSPXqTxQojMGK74EAlNfvmaV[0:-1])):
			if BWyLSPXqTxQojMGK74EAlNfvmaV[WCqkctAYD2O3Hz7Fl8fKRS5]+'=' in KFGqxsBnZYLb3NvMU: rrb0SF6otehufCYOX4 = BWyLSPXqTxQojMGK74EAlNfvmaV[WCqkctAYD2O3Hz7Fl8fKRS5+1]
		gmjZQuBFv8RzlNtDVEOc = KFGqxsBnZYLb3NvMU+'&'+rrb0SF6otehufCYOX4+'=0'
		qwmxUpZfQj8EAV3Tc = ejQ8ZCtBaV7+'&'+rrb0SF6otehufCYOX4+'=0'
		vMp6jZbo3UkEsSxRFQndyA = gmjZQuBFv8RzlNtDVEOc.strip('&')+'___'+qwmxUpZfQj8EAV3Tc.strip('&')
		YqrzmSVb3R9MgUnX2auEHlpBhZD = XFoM2xPKIt3u51hLj(ejQ8ZCtBaV7,'modified_filters')
		HOCWKhxITtulVGX = url+'/smartemadfilter?'+YqrzmSVb3R9MgUnX2auEHlpBhZD
	elif type=='FULL_FILTER':
		zM2ZBJ4IYN8osGTtwgRheLu6dU = XFoM2xPKIt3u51hLj(KFGqxsBnZYLb3NvMU,'modified_values')
		zM2ZBJ4IYN8osGTtwgRheLu6dU = NLqxoZ37dYf0awrsIE(zM2ZBJ4IYN8osGTtwgRheLu6dU)
		if ejQ8ZCtBaV7!=cdZKMn68Pzg4: ejQ8ZCtBaV7 = XFoM2xPKIt3u51hLj(ejQ8ZCtBaV7,'modified_filters')
		if ejQ8ZCtBaV7==cdZKMn68Pzg4: HOCWKhxITtulVGX = url
		else: HOCWKhxITtulVGX = url+'/smartemadfilter?'+ejQ8ZCtBaV7
		N8jUpQxY0rhtDAzbG4kOs9X = VOx3AWdmCD8cSvXKLgr(HOCWKhxITtulVGX)
		zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'أظهار قائمة الفيديو التي تم اختيارها ',N8jUpQxY0rhtDAzbG4kOs9X,111)
		zJLApFBcIhnSj('folder',nc3GLkA65oxOd+' [[   '+zM2ZBJ4IYN8osGTtwgRheLu6dU+'   ]]',N8jUpQxY0rhtDAzbG4kOs9X,111)
		zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	hQ9ADnZlSxI1m8ui = J1BMh3gS6EbcwT284RdnKzkitfUqW(url)
	dict = {}
	for name,rfJG62Vo0pTEljwPN1WahD7sx4t3QR,KdWauEhgN6OQzjRVm1ro8tkB3 in hQ9ADnZlSxI1m8ui:
		name = name.replace('كل ',cdZKMn68Pzg4)
		items = ycYdX9u6W0oOnbMaDlf4KiPz(KdWauEhgN6OQzjRVm1ro8tkB3)
		if '=' not in HOCWKhxITtulVGX: HOCWKhxITtulVGX = url
		if type=='DEFINED_FILTER':
			if rrb0SF6otehufCYOX4!=rfJG62Vo0pTEljwPN1WahD7sx4t3QR: continue
			elif len(items)<2:
				if rfJG62Vo0pTEljwPN1WahD7sx4t3QR==BWyLSPXqTxQojMGK74EAlNfvmaV[-1]:
					N8jUpQxY0rhtDAzbG4kOs9X = VOx3AWdmCD8cSvXKLgr(HOCWKhxITtulVGX)
					GDQUH4fN02sIt81mAcY(N8jUpQxY0rhtDAzbG4kOs9X)
				else: XxcpMKIUzr0sVDngR(HOCWKhxITtulVGX,'DEFINED_FILTER___'+vMp6jZbo3UkEsSxRFQndyA)
				return
			else:
				if rfJG62Vo0pTEljwPN1WahD7sx4t3QR==BWyLSPXqTxQojMGK74EAlNfvmaV[-1]:
					N8jUpQxY0rhtDAzbG4kOs9X = VOx3AWdmCD8cSvXKLgr(HOCWKhxITtulVGX)
					zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'الجميع',N8jUpQxY0rhtDAzbG4kOs9X,111)
				else: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'الجميع',HOCWKhxITtulVGX,115,cdZKMn68Pzg4,cdZKMn68Pzg4,vMp6jZbo3UkEsSxRFQndyA)
		elif type=='FULL_FILTER':
			gmjZQuBFv8RzlNtDVEOc = KFGqxsBnZYLb3NvMU+'&'+rfJG62Vo0pTEljwPN1WahD7sx4t3QR+'=0'
			qwmxUpZfQj8EAV3Tc = ejQ8ZCtBaV7+'&'+rfJG62Vo0pTEljwPN1WahD7sx4t3QR+'=0'
			vMp6jZbo3UkEsSxRFQndyA = gmjZQuBFv8RzlNtDVEOc+'___'+qwmxUpZfQj8EAV3Tc
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'الجميع :'+name,HOCWKhxITtulVGX,114,cdZKMn68Pzg4,cdZKMn68Pzg4,vMp6jZbo3UkEsSxRFQndyA)
		dict[rfJG62Vo0pTEljwPN1WahD7sx4t3QR] = {}
		for value,zj6FI51Rypka0e8xiECfc7g in items:
			if value=='196533': zj6FI51Rypka0e8xiECfc7g = 'أفلام نيتفلكس'
			elif value=='196531': zj6FI51Rypka0e8xiECfc7g = 'مسلسلات نيتفلكس'
			if zj6FI51Rypka0e8xiECfc7g in cJWUPuDGM0Yybv5a9KnIrVzhH78: continue
			dict[rfJG62Vo0pTEljwPN1WahD7sx4t3QR][value] = zj6FI51Rypka0e8xiECfc7g
			gmjZQuBFv8RzlNtDVEOc = KFGqxsBnZYLb3NvMU+'&'+rfJG62Vo0pTEljwPN1WahD7sx4t3QR+'='+zj6FI51Rypka0e8xiECfc7g
			qwmxUpZfQj8EAV3Tc = ejQ8ZCtBaV7+'&'+rfJG62Vo0pTEljwPN1WahD7sx4t3QR+'='+value
			AL8gJZ0NtE91Bexjin4 = gmjZQuBFv8RzlNtDVEOc+'___'+qwmxUpZfQj8EAV3Tc
			title = zj6FI51Rypka0e8xiECfc7g+' :'#+dict[rfJG62Vo0pTEljwPN1WahD7sx4t3QR]['0']
			title = zj6FI51Rypka0e8xiECfc7g+' :'+name
			if type=='FULL_FILTER': zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,url,114,cdZKMn68Pzg4,cdZKMn68Pzg4,AL8gJZ0NtE91Bexjin4)
			elif type=='DEFINED_FILTER' and BWyLSPXqTxQojMGK74EAlNfvmaV[-2]+'=' in KFGqxsBnZYLb3NvMU:
				YqrzmSVb3R9MgUnX2auEHlpBhZD = XFoM2xPKIt3u51hLj(qwmxUpZfQj8EAV3Tc,'modified_filters')
				HOCWKhxITtulVGX = url+'/smartemadfilter?'+YqrzmSVb3R9MgUnX2auEHlpBhZD
				N8jUpQxY0rhtDAzbG4kOs9X = VOx3AWdmCD8cSvXKLgr(HOCWKhxITtulVGX)
				zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,N8jUpQxY0rhtDAzbG4kOs9X,111)
			else: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,url,115,cdZKMn68Pzg4,cdZKMn68Pzg4,AL8gJZ0NtE91Bexjin4)
	return
def XFoM2xPKIt3u51hLj(o3JURfrMDgp76,mode):
	o3JURfrMDgp76 = o3JURfrMDgp76.replace('=&','=0&')
	o3JURfrMDgp76 = o3JURfrMDgp76.strip('&')
	bLxfgF7nlO1uZiY9e5T0HDdIw3kpy = {}
	if '=' in o3JURfrMDgp76:
		items = o3JURfrMDgp76.split('&')
		for HYBN2AQsjimSMgT8OvE3ynX67tJwR in items:
			IN0jyfe1PRdDz6YX3CoJkHthw,value = HYBN2AQsjimSMgT8OvE3ynX67tJwR.split('=')
			bLxfgF7nlO1uZiY9e5T0HDdIw3kpy[IN0jyfe1PRdDz6YX3CoJkHthw] = value
	n7VBe6ZgDI14lizTfHOmk = cdZKMn68Pzg4
	for key in SGJUq2RCH79hWyemglnMOpc8bB:
		if key in list(bLxfgF7nlO1uZiY9e5T0HDdIw3kpy.keys()): value = bLxfgF7nlO1uZiY9e5T0HDdIw3kpy[key]
		else: value = '0'
		if '%' not in value: value = YQlEOShHM7RLak2t0yA4NXqv(value)
		if mode=='modified_values' and value!='0': n7VBe6ZgDI14lizTfHOmk = n7VBe6ZgDI14lizTfHOmk+' + '+value
		elif mode=='modified_filters' and value!='0': n7VBe6ZgDI14lizTfHOmk = n7VBe6ZgDI14lizTfHOmk+'&'+key+'='+value
		elif mode=='all': n7VBe6ZgDI14lizTfHOmk = n7VBe6ZgDI14lizTfHOmk+'&'+key+'='+value
	n7VBe6ZgDI14lizTfHOmk = n7VBe6ZgDI14lizTfHOmk.strip(' + ')
	n7VBe6ZgDI14lizTfHOmk = n7VBe6ZgDI14lizTfHOmk.strip('&')
	n7VBe6ZgDI14lizTfHOmk = n7VBe6ZgDI14lizTfHOmk.replace('=0','=')
	return n7VBe6ZgDI14lizTfHOmk
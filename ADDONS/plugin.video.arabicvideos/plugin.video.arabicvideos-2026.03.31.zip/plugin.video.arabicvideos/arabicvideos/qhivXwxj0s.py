# -*- coding: utf-8 -*-
import sys as sjVE6XGymcf09qbiKODZdAC
LVpmDXhWH5wGKy1eqMB = sjVE6XGymcf09qbiKODZdAC.version_info [0] == 2
RGEuTe9PD7o45d2v = 2048
r3HIioGW0Nl = 7
def Brz09AF6apy52OuEq1s (ccr3g6sWvxSOqDiLJuF1Vf2KUtG):
	global YzIBLo1J4ZOCEPtjq
	SSzr8EskcFRLobZqtC2QeTyPg4Y = ord (ccr3g6sWvxSOqDiLJuF1Vf2KUtG [-1])
	JIf7wGht4BqbQ5Xik1mYTA3DeLvaPO = ccr3g6sWvxSOqDiLJuF1Vf2KUtG [:-1]
	ZYd0PzhKWmvFN5TfcQI = SSzr8EskcFRLobZqtC2QeTyPg4Y % len (JIf7wGht4BqbQ5Xik1mYTA3DeLvaPO)
	itRzfVamqWwLIynhGpDM4ZUe = JIf7wGht4BqbQ5Xik1mYTA3DeLvaPO [:ZYd0PzhKWmvFN5TfcQI] + JIf7wGht4BqbQ5Xik1mYTA3DeLvaPO [ZYd0PzhKWmvFN5TfcQI:]
	if LVpmDXhWH5wGKy1eqMB:
		MHSngXbpVZde6NiQc9IrCxt78 = unicode () .join ([unichr (ord (Ep0JIWsLABieR) - RGEuTe9PD7o45d2v - (D2bEPIlOQJy4dYntR3MCiKLusT + SSzr8EskcFRLobZqtC2QeTyPg4Y) % r3HIioGW0Nl) for D2bEPIlOQJy4dYntR3MCiKLusT, Ep0JIWsLABieR in enumerate (itRzfVamqWwLIynhGpDM4ZUe)])
	else:
		MHSngXbpVZde6NiQc9IrCxt78 = str () .join ([chr (ord (Ep0JIWsLABieR) - RGEuTe9PD7o45d2v - (D2bEPIlOQJy4dYntR3MCiKLusT + SSzr8EskcFRLobZqtC2QeTyPg4Y) % r3HIioGW0Nl) for D2bEPIlOQJy4dYntR3MCiKLusT, Ep0JIWsLABieR in enumerate (itRzfVamqWwLIynhGpDM4ZUe)])
	return eval (MHSngXbpVZde6NiQc9IrCxt78)
ObuCsdoDtKmhPLSMH8YGan,vbYokBuWlxeLDcdVNM60,J6jL2d7CKE0WA4lBXFPghR5eoxHb=Brz09AF6apy52OuEq1s,Brz09AF6apy52OuEq1s,Brz09AF6apy52OuEq1s
aNdix5gq7yeFHTMWhnzm8pX0Y16,dwiIAcPl04ey7Zv38Mz,zBGPHsxIiQmd7oTSORl9bAynr5kNq=J6jL2d7CKE0WA4lBXFPghR5eoxHb,vbYokBuWlxeLDcdVNM60,ObuCsdoDtKmhPLSMH8YGan
rbUkdYi32PJaRtnxhDvQs,TtyzcuW45VKA,LungQF89BqemOb32jJsZlW=zBGPHsxIiQmd7oTSORl9bAynr5kNq,dwiIAcPl04ey7Zv38Mz,aNdix5gq7yeFHTMWhnzm8pX0Y16
iRfoNckJs7Ibxzh5j92w8DSWF,NV3enkyQ7Rmp2LYAUagsCJz0ZP,HC9xWUMpBQJEuTteAqjd=LungQF89BqemOb32jJsZlW,TtyzcuW45VKA,rbUkdYi32PJaRtnxhDvQs
s8fcjBCSMxzAIkZQbJPga,AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu,liyzjA4RkEb1cT6fr5pGKdWNHOxM=HC9xWUMpBQJEuTteAqjd,NV3enkyQ7Rmp2LYAUagsCJz0ZP,iRfoNckJs7Ibxzh5j92w8DSWF
nfg30bHwd4aNV12SR7UjFck,Rsdai9xIEPcpuBMKOUwkTA05q,KNomgGw1kdMCBH=liyzjA4RkEb1cT6fr5pGKdWNHOxM,AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu,s8fcjBCSMxzAIkZQbJPga
SGazRxP3yBKZ15ILuch,YnHG75e2QWwo,S5fhsRT8JV=KNomgGw1kdMCBH,Rsdai9xIEPcpuBMKOUwkTA05q,nfg30bHwd4aNV12SR7UjFck
WupgNDhcjK1SiYsF5VLGb9w3loJqX,f8Ja1q5eO02B,xN4fKmsnyM3Y2=S5fhsRT8JV,YnHG75e2QWwo,SGazRxP3yBKZ15ILuch
uxE8MyoTRglrcaiQf,aar0zhDnJsOTP7EdgR16HIS29,opyTNwHgfqbZREWKU=xN4fKmsnyM3Y2,f8Ja1q5eO02B,WupgNDhcjK1SiYsF5VLGb9w3loJqX
On1WZJc6dtksqVNgSQ5GBAjuipe,AiCor1fIVTDxQUWwHe9vPR7,tRnTydV03Xfi7rbQ=opyTNwHgfqbZREWKU,aar0zhDnJsOTP7EdgR16HIS29,uxE8MyoTRglrcaiQf
LJPOQNK1mcG,k5oIaYyp2mnrLK49qhzS,zDek1IW37rq6UoKdwyRiAVpF=tRnTydV03Xfi7rbQ,AiCor1fIVTDxQUWwHe9vPR7,On1WZJc6dtksqVNgSQ5GBAjuipe
from RgJNGc7YMP import *
UkXlAzsMcamKJrEIgnxi6bWh = J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠪࡖࡆࡔࡄࡐࡏࡖࠫ᳎")
nc3GLkA65oxOd = xN4fKmsnyM3Y2(u"ࠫࡤࡒࡓࡕࡡࠪ᳏")
RDjfuZILUYwhx = iwQJREcVTSe1G2gCvlfhbHWLjqopa
eeSQItHBimn5daWcYpbRvxVyuo = J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"࠱࠱Ἲ")
def HHN5EpbszV3iA2m89hGSQjaPgUZy(HHrpyfWjGC,url,JAYWBoz54tGw7O,aOZ3yVnsNlB974pR,g8tTFcBGwdKlo42LUkW):
	try: e3e5Wr7HPcK6RbEwXTmu = str(g8tTFcBGwdKlo42LUkW[On1WZJc6dtksqVNgSQ5GBAjuipe(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ᳐")])
	except: e3e5Wr7HPcK6RbEwXTmu = cdZKMn68Pzg4
	if   HHrpyfWjGC==HC9xWUMpBQJEuTteAqjd(u"࠲࠸࠳Ἳ"): xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = kUq58vC7x9hWma164JejMKQ()
	elif HHrpyfWjGC==dwiIAcPl04ey7Zv38Mz(u"࠳࠹࠵Ἴ"): xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = GS0uA5oliq74K(JAYWBoz54tGw7O)
	elif HHrpyfWjGC==HC9xWUMpBQJEuTteAqjd(u"࠴࠺࠷Ἵ"): xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = JgaTNOGC8V2k7nmfqBW0rs(JAYWBoz54tGw7O,HC9xWUMpBQJEuTteAqjd(u"࠴࠺࠷Ἵ"))
	elif HHrpyfWjGC==zDek1IW37rq6UoKdwyRiAVpF(u"࠵࠻࠹Ἶ"): xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = JgaTNOGC8V2k7nmfqBW0rs(JAYWBoz54tGw7O,zDek1IW37rq6UoKdwyRiAVpF(u"࠵࠻࠹Ἶ"))
	elif HHrpyfWjGC==rbUkdYi32PJaRtnxhDvQs(u"࠶࠼࠴Ἷ"): xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = Zy6VvL54w7tBal(JAYWBoz54tGw7O)
	elif HHrpyfWjGC==SGazRxP3yBKZ15ILuch(u"࠷࠶࠶ὀ"): xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = RSMZ1NhjDoqlQvU7Ey5Bpbxk4XG(url,JAYWBoz54tGw7O)
	elif HHrpyfWjGC==YnHG75e2QWwo(u"࠱࠷࠸ὁ"): xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = wfXezL8AxmIrY7tKh1H5jSuc2F4v3(url,JAYWBoz54tGw7O)
	elif HHrpyfWjGC==liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"࠲࠸࠺ὂ"): xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = LgqhlWACEIxdGpf5TYOPsUNi173K(url,JAYWBoz54tGw7O)
	elif HHrpyfWjGC==SGazRxP3yBKZ15ILuch(u"࠳࠹࠼ὃ"): xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = K3f5lLpgPoI8cJdHFEDbwRny(url,JAYWBoz54tGw7O)
	elif HHrpyfWjGC==rbUkdYi32PJaRtnxhDvQs(u"࠺࠺࠶ὄ"): xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = Jpihb2QUaW7VM9R5lXCNtT1A()
	elif HHrpyfWjGC==WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"࠻࠻࠸ὅ"): xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = hJtjnIV15XGiKeuv2yPL()
	elif HHrpyfWjGC==k5oIaYyp2mnrLK49qhzS(u"࠼࠼࠳὆"): xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = iQFDul68fTNaS5(e3e5Wr7HPcK6RbEwXTmu,JAYWBoz54tGw7O,aOZ3yVnsNlB974pR)
	elif HHrpyfWjGC==NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"࠽࠶࠵὇"): xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = SSxfkWcDPQjv9LVrybuN5ed2Z6oR3g(e3e5Wr7HPcK6RbEwXTmu,JAYWBoz54tGw7O)
	elif HHrpyfWjGC==AiCor1fIVTDxQUWwHe9vPR7(u"࠷࠷࠷Ὀ"): xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = vOS2QdgtGZ(e3e5Wr7HPcK6RbEwXTmu,JAYWBoz54tGw7O)
	else: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = ksTLSoVGg0ht
	return xsGUcR3ef6glKY5hQwpFXEaSt2mrIz
def kUq58vC7x9hWma164JejMKQ():
	zJLApFBcIhnSj(S5fhsRT8JV(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭᳑"),On1WZJc6dtksqVNgSQ5GBAjuipe(u"ࠧใ่๋หฯࠦสๅใี๎ํ์ฺࠠึ๋หห๐ษࠨ᳒"),cdZKMn68Pzg4,aNdix5gq7yeFHTMWhnzm8pX0Y16(u"࠲࠸࠴Ὁ"),cdZKMn68Pzg4,cdZKMn68Pzg4,uxE8MyoTRglrcaiQf(u"ࠨࡡࡏࡍ࡛ࡋࡔࡗࡡࡢࡖࡆࡔࡄࡐࡏࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ᳓"))
	zJLApFBcIhnSj(S5fhsRT8JV(u"ࠩࡩࡳࡱࡪࡥࡳ᳔ࠩ"),On1WZJc6dtksqVNgSQ5GBAjuipe(u"ࠪๆฺุ๋ࠠึ๋หห๐᳕ࠧ"),cdZKMn68Pzg4,tRnTydV03Xfi7rbQ(u"࠳࠹࠶Ὂ"),cdZKMn68Pzg4,cdZKMn68Pzg4,liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠫࡤ࡙ࡉࡕࡇࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ᳖"))
	zJLApFBcIhnSj(On1WZJc6dtksqVNgSQ5GBAjuipe(u"ࠬ࡬࡯࡭ࡦࡨࡶ᳗ࠬ"),aar0zhDnJsOTP7EdgR16HIS29(u"࠭แ๋ัํ์์อสࠡ฻ื์ฬฬ๊ส᳘ࠩ"),cdZKMn68Pzg4,k5oIaYyp2mnrLK49qhzS(u"࠴࠺࠸Ὃ"),cdZKMn68Pzg4,cdZKMn68Pzg4,zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"ࠧࡠࡕࡌࡘࡊ࡙࡟ࡠࡔࡄࡒࡉࡕࡍࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣ᳙ࠬ"))
	zJLApFBcIhnSj(iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᳚"),LungQF89BqemOb32jJsZlW(u"ࠩไ๎ิ๐่่ษอࠤอำหࠡ฻ื์ฬฬ๊ࠨ᳛"),cdZKMn68Pzg4,J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"࠵࠻࠺Ὄ"),cdZKMn68Pzg4,cdZKMn68Pzg4,xN4fKmsnyM3Y2(u"ࠪࡣࡘࡏࡔࡆࡕࡢࡣࡗࡇࡎࡅࡑࡐࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ᳜"))
	zJLApFBcIhnSj(WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠫ࡫ࡵ࡬ࡥࡧࡵ᳝ࠫ"),f8Ja1q5eO02B(u"ࠬ็๊ะ์๋๋ฬะฺࠠึ๋หห๐ษࠡ็้ࠤ็ูๅࠨ᳞"),cdZKMn68Pzg4,NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"࠼࠼࠳Ὅ"),cdZKMn68Pzg4,cdZKMn68Pzg4,J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"࠭࡟ࡔࡋࡗࡉࡘࡥ࡟ࡓࡃࡑࡈࡔࡓ࡟ࠨ᳟"))
	zJLApFBcIhnSj(LJPOQNK1mcG(u"ࠧ࡭࡫ࡱ࡯ࠬ᳠"),Gzygq01Kcb9U3+dwiIAcPl04ey7Zv38Mz(u"ࠨࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦࠧ᳡")+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,iRfoNckJs7Ibxzh5j92w8DSWF(u"࠿࠹࠺࠻὎"))
	zJLApFBcIhnSj(dwiIAcPl04ey7Zv38Mz(u"ࠩࡩࡳࡱࡪࡥࡳ᳢ࠩ"),aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠪๆ๋๎วหࠢࡐ࠷ู࡚ࠦี๊สส๏ฯ᳣ࠧ"),cdZKMn68Pzg4,HC9xWUMpBQJEuTteAqjd(u"࠱࠷࠵὏"),cdZKMn68Pzg4,cdZKMn68Pzg4,WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠫࡤࡓ࠳ࡖࡡࡢࡐࡎ࡜ࡅࡠࡡࡕࡅࡓࡊࡏࡎࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ᳤࠭"))
	zJLApFBcIhnSj(SGazRxP3yBKZ15ILuch(u"ࠬ࡬࡯࡭ࡦࡨࡶ᳥ࠬ"),LungQF89BqemOb32jJsZlW(u"࠭แ๋ัํ์์อสࠡࡏ࠶࡙ࠥ฿ิ้ษษ๎ฮ᳦࠭"),cdZKMn68Pzg4,TtyzcuW45VKA(u"࠲࠸࠶ὐ"),cdZKMn68Pzg4,cdZKMn68Pzg4,tRnTydV03Xfi7rbQ(u"ࠧࡠࡏ࠶࡙ࡤࡥࡖࡐࡆࡢࡣࡗࡇࡎࡅࡑࡐࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ᳧"))
	zJLApFBcIhnSj(KNomgGw1kdMCBH(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᳨"),s8fcjBCSMxzAIkZQbJPga(u"ࠩๅื๊ࠦโ็๊สฮࠥࡓ࠳ࡖࠢ฼ุํอฦ๋ࠩᳩ"),cdZKMn68Pzg4,S5fhsRT8JV(u"࠳࠹࠶ὑ"),cdZKMn68Pzg4,cdZKMn68Pzg4,zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"ࠪࡣࡒ࠹ࡕࡠࡡࡏࡍ࡛ࡋ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᳪ"))
	zJLApFBcIhnSj(aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᳫ"),k5oIaYyp2mnrLK49qhzS(u"่ࠬำๆࠢไ๎ิ๐่ࠡࡏ࠶࡙ࠥ฿ิ้ษษ๎ࠬᳬ"),cdZKMn68Pzg4,SGazRxP3yBKZ15ILuch(u"࠴࠺࠷ὒ"),cdZKMn68Pzg4,cdZKMn68Pzg4,aar0zhDnJsOTP7EdgR16HIS29(u"࠭࡟ࡎ࠵ࡘࡣࡤ࡜ࡏࡅࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ᳭࠭"))
	zJLApFBcIhnSj(LJPOQNK1mcG(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᳮ"),liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠨใํำ๏๎็ศฬࠣࡑ࠸࡛ࠠษฯฮࠤ฾ฺ่ศศํࠫᳯ"),cdZKMn68Pzg4,AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"࠵࠻࠺ὓ"),cdZKMn68Pzg4,cdZKMn68Pzg4,AiCor1fIVTDxQUWwHe9vPR7(u"ࠩࡢࡑ࠸࡛࡟ࡠࡔࡄࡒࡉࡕࡍࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᳰ"))
	zJLApFBcIhnSj(LJPOQNK1mcG(u"ࠪࡪࡴࡲࡤࡦࡴࠪᳱ"),KNomgGw1kdMCBH(u"ࠫๆ๐ฯ๋๊๊หฯࠦࡍ࠴ࡗࠣ฽ู๎วว์ฬࠤ๊์ࠠใี่ࠫᳲ"),cdZKMn68Pzg4,J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"࠼࠼࠵ὔ"),cdZKMn68Pzg4,cdZKMn68Pzg4,iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠬࡥࡍ࠴ࡗࡢࡣࡗࡇࡎࡅࡑࡐࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᳳ"))
	zJLApFBcIhnSj(zDek1IW37rq6UoKdwyRiAVpF(u"࠭࡬ࡪࡰ࡮ࠫ᳴"),Gzygq01Kcb9U3+aar0zhDnJsOTP7EdgR16HIS29(u"ࠧࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥ࠭ᳵ")+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,Rsdai9xIEPcpuBMKOUwkTA05q(u"࠿࠹࠺࠻ὕ"))
	zJLApFBcIhnSj(f8Ja1q5eO02B(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᳶ"),iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠩๅ๊ํอสࠡࡋࡓࡘู࡛ࠦี๊สส๏ฯࠧ᳷"),cdZKMn68Pzg4,opyTNwHgfqbZREWKU(u"࠱࠷࠵ὖ"),cdZKMn68Pzg4,cdZKMn68Pzg4,KNomgGw1kdMCBH(u"ࠪࡣࡎࡖࡔࡗࡡࡢࡐࡎ࡜ࡅࡠࡡࡕࡅࡓࡊࡏࡎࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭᳸"))
	zJLApFBcIhnSj(aar0zhDnJsOTP7EdgR16HIS29(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ᳹"),uxE8MyoTRglrcaiQf(u"ࠬ็๊ะ์๋๋ฬะࠠࡊࡒࡗ࡚ࠥ฿ิ้ษษ๎ฮ࠭ᳺ"),cdZKMn68Pzg4,HC9xWUMpBQJEuTteAqjd(u"࠲࠸࠶ὗ"),cdZKMn68Pzg4,cdZKMn68Pzg4,uxE8MyoTRglrcaiQf(u"࠭࡟ࡊࡒࡗ࡚ࡤࡥࡖࡐࡆࡢࡣࡗࡇࡎࡅࡑࡐࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ᳻"))
	zJLApFBcIhnSj(vbYokBuWlxeLDcdVNM60(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᳼"),J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠨไึ้่ࠥๆ้ษอࠤࡎࡖࡔࡗࠢ฼ุํอฦ๋ࠩ᳽"),cdZKMn68Pzg4,YnHG75e2QWwo(u"࠳࠹࠶὘"),cdZKMn68Pzg4,cdZKMn68Pzg4,AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"ࠩࡢࡍࡕ࡚ࡖࡠࡡࡏࡍ࡛ࡋ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ᳾"))
	zJLApFBcIhnSj(zDek1IW37rq6UoKdwyRiAVpF(u"ࠪࡪࡴࡲࡤࡦࡴࠪ᳿"),WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠫ็ูๅࠡใํำ๏๎ࠠࡊࡒࡗ࡚ࠥ฿ิ้ษษ๎ࠬᴀ"),cdZKMn68Pzg4,aNdix5gq7yeFHTMWhnzm8pX0Y16(u"࠴࠺࠷Ὑ"),cdZKMn68Pzg4,cdZKMn68Pzg4,aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠬࡥࡉࡑࡖ࡙ࡣࡤ࡜ࡏࡅࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᴁ"))
	zJLApFBcIhnSj(opyTNwHgfqbZREWKU(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᴂ"),f8Ja1q5eO02B(u"ࠧโ์า๎ํํวหࠢࡌࡔ࡙࡜ࠠษฯฮࠤ฾ฺ่ศศํࠫᴃ"),cdZKMn68Pzg4,ObuCsdoDtKmhPLSMH8YGan(u"࠵࠻࠺὚"),cdZKMn68Pzg4,cdZKMn68Pzg4,opyTNwHgfqbZREWKU(u"ࠨࡡࡌࡔ࡙࡜࡟ࡠࡔࡄࡒࡉࡕࡍࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᴄ"))
	zJLApFBcIhnSj(Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠩࡩࡳࡱࡪࡥࡳࠩᴅ"),TtyzcuW45VKA(u"ࠪๅ๏ี๊้้สฮࠥࡏࡐࡕࡘࠣ฽ู๎วว์ฬࠤ๊์ࠠใี่ࠫᴆ"),cdZKMn68Pzg4,AiCor1fIVTDxQUWwHe9vPR7(u"࠼࠼࠴Ὓ"),cdZKMn68Pzg4,cdZKMn68Pzg4,SGazRxP3yBKZ15ILuch(u"ࠫࡤࡏࡐࡕࡘࡢࡣࡗࡇࡎࡅࡑࡐࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᴇ"))
	return
def Jpihb2QUaW7VM9R5lXCNtT1A():
	zJLApFBcIhnSj(LJPOQNK1mcG(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᴈ"),aar0zhDnJsOTP7EdgR16HIS29(u"࠭࡟ࡊࡒࡗࡣࠬᴉ")+J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠧโ์า๎ํํวหࠢฯ้๏฿ࠠࡊࡒࡗ࡚ࠬᴊ"),cdZKMn68Pzg4,tRnTydV03Xfi7rbQ(u"࠽࠶࠵὜"))
	zJLApFBcIhnSj(LJPOQNK1mcG(u"ࠨ࡮࡬ࡲࡰ࠭ᴋ"),Gzygq01Kcb9U3+NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠩࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦࠧᴌ")+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,xN4fKmsnyM3Y2(u"࠹࠺࠻࠼Ὕ"))
	for e3e5Wr7HPcK6RbEwXTmu in range(hiuZa0PIsErm6UC7,d37Zoe1YJgWbMq+hiuZa0PIsErm6UC7):
		nc3GLkA65oxOd = zDek1IW37rq6UoKdwyRiAVpF(u"ࠪࡣࡎࡖࠧᴍ")+str(e3e5Wr7HPcK6RbEwXTmu)+nfg30bHwd4aNV12SR7UjFck(u"ࠫࡤ࠭ᴎ")
		zJLApFBcIhnSj(NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᴏ"),nc3GLkA65oxOd+tRnTydV03Xfi7rbQ(u"࠭ࠠโ์า๎ํํวห่ࠢะ้ีࠠࠨᴐ")+G9Gz76P41qQAW2viUsjEymXYOVuBSc[e3e5Wr7HPcK6RbEwXTmu],cdZKMn68Pzg4,AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"࠸࠸࠷὞"),cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,{SGazRxP3yBKZ15ILuch(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᴑ"):e3e5Wr7HPcK6RbEwXTmu})
	return
def hJtjnIV15XGiKeuv2yPL():
	zJLApFBcIhnSj(SGazRxP3yBKZ15ILuch(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᴒ"),k5oIaYyp2mnrLK49qhzS(u"ࠩࡢࡑ࠸࡛࡟ࠨᴓ")+ObuCsdoDtKmhPLSMH8YGan(u"ࠪๅ๏ี๊้้สฮࠥาๅ๋฻ࠣࡑ࠸࡛ࠧᴔ"),cdZKMn68Pzg4,aNdix5gq7yeFHTMWhnzm8pX0Y16(u"࠹࠹࠹Ὗ"))
	zJLApFBcIhnSj(uxE8MyoTRglrcaiQf(u"ࠫࡱ࡯࡮࡬ࠩᴕ"),Gzygq01Kcb9U3+iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠬࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࠪᴖ")+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,opyTNwHgfqbZREWKU(u"࠼࠽࠾࠿ὠ"))
	for e3e5Wr7HPcK6RbEwXTmu in range(hiuZa0PIsErm6UC7,d37Zoe1YJgWbMq+hiuZa0PIsErm6UC7):
		nc3GLkA65oxOd = J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"࠭࡟ࡎࡗࠪᴗ")+str(e3e5Wr7HPcK6RbEwXTmu)+TtyzcuW45VKA(u"ࠧࡠࠩᴘ")
		zJLApFBcIhnSj(iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᴙ"),nc3GLkA65oxOd+zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"ࠩࠣๅ๏ี๊้้สฮ๋ࠥฬๅัࠣࠫᴚ")+G9Gz76P41qQAW2viUsjEymXYOVuBSc[e3e5Wr7HPcK6RbEwXTmu],cdZKMn68Pzg4,liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"࠻࠻࠻ὡ"),cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,{nfg30bHwd4aNV12SR7UjFck(u"ࠪࡪࡴࡲࡤࡦࡴࠪᴛ"):e3e5Wr7HPcK6RbEwXTmu})
	return
def haxR3HSXy4iPFn(xgPSaoLzTlFtQD37M6HIEsWY):
	global LcBbgl9PNj,rrBpds0l7OS
	EsoNPCTO6a243HIqXh0R,KIOap9Wsnru,tcDxzmPhwuVGE9ls0n6g = hhHQ695ZrMo2bFnIJqt(xgPSaoLzTlFtQD37M6HIEsWY)
	try:
		if HC9xWUMpBQJEuTteAqjd(u"ࠫࡎࡌࡉࡍࡏࠪᴜ") in xgPSaoLzTlFtQD37M6HIEsWY: EsoNPCTO6a243HIqXh0R(xgPSaoLzTlFtQD37M6HIEsWY)
		else: EsoNPCTO6a243HIqXh0R()
		ChlTZv7fx35BLjUAuI8X0yrW2gzYPJ = ksTLSoVGg0ht
	except:
		CzSKmItBXnVrORuN1c9Wap()
		ChlTZv7fx35BLjUAuI8X0yrW2gzYPJ = IZQbmFzLHDtXfc
	xgPSaoLzTlFtQD37M6HIEsWY = N6EjMQZJwbdDLla0C24Opifg(xgPSaoLzTlFtQD37M6HIEsWY)
	if ChlTZv7fx35BLjUAuI8X0yrW2gzYPJ:
		bJqPkYBXsenxTRwKu(xgPSaoLzTlFtQD37M6HIEsWY,dwiIAcPl04ey7Zv38Mz(u"ࠬ็ิๅࠢ็่ศูแࠨᴝ"),bD7kJZhMCdaqF68P45KlNIgO1=LJPOQNK1mcG(u"࠷࠶࠰࠱ὢ"))
		LcBbgl9PNj += hiuZa0PIsErm6UC7
		rrBpds0l7OS += f8Ja1q5eO02B(u"࠭ࠠ࠯ࠢࠪᴞ")+xgPSaoLzTlFtQD37M6HIEsWY
	else: bJqPkYBXsenxTRwKu(xgPSaoLzTlFtQD37M6HIEsWY,cdZKMn68Pzg4,bD7kJZhMCdaqF68P45KlNIgO1=f8Ja1q5eO02B(u"࠷࠰࠱࠲ὣ"))
	return
p1aOI2dPBNz9wm7uF56S = {}
def a2u7fFRVJ1TxUBj9e6NsOdXy4l5hC(zzyVhCras3TfkdK8HARZoEwLBvDFQ6=IZQbmFzLHDtXfc):
	global LcBbgl9PNj,rrBpds0l7OS,p1aOI2dPBNz9wm7uF56S
	if not zzyVhCras3TfkdK8HARZoEwLBvDFQ6:
		p1aOI2dPBNz9wm7uF56S = sZHYrLPog4wmuW0ECdc(TV08xYHA2ok,HC9xWUMpBQJEuTteAqjd(u"ࠧࡥ࡫ࡦࡸࠬᴟ"),S5fhsRT8JV(u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡗࡎ࡚ࡅࡔࠩᴠ"),S5fhsRT8JV(u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡘࡏࡔࡆࡕࡢࡅࡑࡒࠧᴡ"))
		if p1aOI2dPBNz9wm7uF56S: return
	BoyIUWYSNR0jhDxQwvJriO4PkL = JyLdvftP3CU(zDek1IW37rq6UoKdwyRiAVpF(u"ࠪࡧࡪࡴࡴࡦࡴࠪᴢ"),cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,ObuCsdoDtKmhPLSMH8YGan(u"ࠫาะ้ࠡฬ่่หࠦ็ั้ࠣห้่วว็ฬࠤ࠳࠴ࠠิ์ไัฺࠦวๅสิ๊ฬ๋ฬࠡฮ่๎฾ࠦๅ้ษๅ฽ࠥอไโ์า๎ํࠦวๅฬํࠤๆ๐ࠠศๆหี๋อๅอࠢะฮ๎๊ࠦิฬัีัࠦๅ็้สࠤๆ่ืࠡษ็ว็ูวๆࠢส่ึฬ๊ิ์ฬࠤ࠳࠴ࠠฬ็ࠣ๎็๎ๅࠡษ็ฬึ์วๆฮࠣฬำุๆ้ࠡำ๋ࠥอไฤไึห๊ࠦอห๋่ࠣฬࠦสฮฬสะࠥษๆࠡฬ่่หํวࠡ็ิอࠥษฮา๋ࠣ࠲࠳ࠦ็ั้ࠣห้฿ๅๅ์ฬࠤฯำสศฮࠣ฽ฬีษࠡลๅ่๋ࠥๆࠡ࠵ࠣำ็อฦใࠢ࡟ࡲࡡࡴࠧᴣ")+Gzygq01Kcb9U3+opyTNwHgfqbZREWKU(u"ࠬํไࠡฬิ๎ิࠦร็ࠢอะ๊฿ࠠใษษ้ฮࠦวๅลๅืฬ๋ࠠศๆล๊ࠥลࠧᴤ")+kH8E2zqNyims6KJfI)
	if BoyIUWYSNR0jhDxQwvJriO4PkL!=hiuZa0PIsErm6UC7: return
	tHOfW4iaMLm8VuZegxobrlnj5A0yB(c5oDzdPaOE8,c5oDzdPaOE8,c5oDzdPaOE8)
	N5q8Py9F7nuLOHfdbK1MrAp4DWvI6 = USuRxnPlV5.menuItemsLIST
	LcBbgl9PNj,rrBpds0l7OS,OiHTsc4dBCz = nnsBpJv6XL3OzHoe4Vuhr,cdZKMn68Pzg4,{}
	for xgPSaoLzTlFtQD37M6HIEsWY in JjQWY0xnmlrqD:
		bD7kJZhMCdaqF68P45KlNIgO1.sleep(hiuZa0PIsErm6UC7)
		OiHTsc4dBCz[xgPSaoLzTlFtQD37M6HIEsWY] = qMrpRl8enOuvS6hV2XcZgT(daemon=IZQbmFzLHDtXfc,target=haxR3HSXy4iPFn,args=(xgPSaoLzTlFtQD37M6HIEsWY,))
		OiHTsc4dBCz[xgPSaoLzTlFtQD37M6HIEsWY].start()
	else:
		for xgPSaoLzTlFtQD37M6HIEsWY in list(OiHTsc4dBCz.keys()): OiHTsc4dBCz[xgPSaoLzTlFtQD37M6HIEsWY].join()
	USuRxnPlV5.menuItemsLIST[:] = N5q8Py9F7nuLOHfdbK1MrAp4DWvI6
	p1aOI2dPBNz9wm7uF56S = {}
	for xgPSaoLzTlFtQD37M6HIEsWY in list(OiHTsc4dBCz.keys()):
		try: cE1PqHoJUlMmvQKuwIfnTtLRAzG = USuRxnPlV5.menuItemsDICT[xgPSaoLzTlFtQD37M6HIEsWY]
		except: continue
		xgPSaoLzTlFtQD37M6HIEsWY = s8fcjBCSMxzAIkZQbJPga(u"࠭࡟ࡍࡕࡗࡣࠬᴥ")+N6EjMQZJwbdDLla0C24Opifg(xgPSaoLzTlFtQD37M6HIEsWY)
		for kuMXTLrvIZGfjCDtA9YNJ5SxQK,yy0cNBFOGVZh8rIeQ4,kxY4EfTKobmQJ8OathHI53,HHrpyfWjGC,cxokMEeWJnSdZGt53qYhI,iQBgv5oEbM6ZFH4U8qtC,JAYWBoz54tGw7O,SUkst0aLFhj,RqmGlEdhA8z7M in cE1PqHoJUlMmvQKuwIfnTtLRAzG:
			if not yy0cNBFOGVZh8rIeQ4: yy0cNBFOGVZh8rIeQ4 = AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"ࠧ࠯࠰࠱࠲ࠬᴦ")
			else:
				if yy0cNBFOGVZh8rIeQ4.count(Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠨࡡࠪᴧ"))>hiuZa0PIsErm6UC7: yy0cNBFOGVZh8rIeQ4 = yy0cNBFOGVZh8rIeQ4.split(KNomgGw1kdMCBH(u"ࠩࡢࠫᴨ"),bVX3ev1spE)[bVX3ev1spE]
				yy0cNBFOGVZh8rIeQ4 = yy0cNBFOGVZh8rIeQ4.replace(TtyzcuW45VKA(u"ࠪࢤࠬᴩ"),cdZKMn68Pzg4).replace(YnHG75e2QWwo(u"ࠫࠥࡎࡄࠨᴪ"),cdZKMn68Pzg4).replace(iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠬࡎࡄࠡࠩᴫ"),cdZKMn68Pzg4)
				yy0cNBFOGVZh8rIeQ4 = yy0cNBFOGVZh8rIeQ4.replace(vbYokBuWlxeLDcdVNM60(u"࠭เࠨᴬ"),cdZKMn68Pzg4).replace(liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠧสࠩᴭ"),YnHG75e2QWwo(u"ࠨ้ࠪᴮ")).replace(zDek1IW37rq6UoKdwyRiAVpF(u"ࠩวࠫᴯ"),On1WZJc6dtksqVNgSQ5GBAjuipe(u"ࠪ์ࠬᴰ"))
				yy0cNBFOGVZh8rIeQ4 = yy0cNBFOGVZh8rIeQ4.replace(On1WZJc6dtksqVNgSQ5GBAjuipe(u"ࠫศ࠭ᴱ"),LJPOQNK1mcG(u"ࠬอࠧᴲ")).replace(J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"࠭ลࠨᴳ"),On1WZJc6dtksqVNgSQ5GBAjuipe(u"ࠧศࠩᴴ")).replace(SGazRxP3yBKZ15ILuch(u"ࠨฤࠪᴵ"),WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠩสࠫᴶ"))
				yy0cNBFOGVZh8rIeQ4 = yy0cNBFOGVZh8rIeQ4.replace(s8fcjBCSMxzAIkZQbJPga(u"่ࠪศ࠭ᴷ"),opyTNwHgfqbZREWKU(u"้ࠫอࠧᴸ")).replace(rbUkdYi32PJaRtnxhDvQs(u"๊ࠬลࠨᴹ"),vbYokBuWlxeLDcdVNM60(u"࠭ไศࠩᴺ")).replace(LungQF89BqemOb32jJsZlW(u"ࠧๅฤࠪᴻ"),iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠨๆสࠫᴼ"))
				yy0cNBFOGVZh8rIeQ4 = yy0cNBFOGVZh8rIeQ4.replace(rbUkdYi32PJaRtnxhDvQs(u"ࠩ๑ࠫᴽ"),cdZKMn68Pzg4).replace(opyTNwHgfqbZREWKU(u"ࠪ๏ࠬᴾ"),cdZKMn68Pzg4).replace(zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"ࠫ๔࠭ᴿ"),cdZKMn68Pzg4).replace(LungQF89BqemOb32jJsZlW(u"ࠬ๒ࠧᵀ"),cdZKMn68Pzg4)
				yy0cNBFOGVZh8rIeQ4 = yy0cNBFOGVZh8rIeQ4.replace(tRnTydV03Xfi7rbQ(u"࠭๐ࠨᵁ"),cdZKMn68Pzg4).replace(aar0zhDnJsOTP7EdgR16HIS29(u"ࠧ๎ࠩᵂ"),cdZKMn68Pzg4).replace(zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"ࠨ๔ࠪᵃ"),cdZKMn68Pzg4).replace(zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"ࠩ๔ࠫᵄ"),cdZKMn68Pzg4)
				yy0cNBFOGVZh8rIeQ4 = yy0cNBFOGVZh8rIeQ4.replace(ObuCsdoDtKmhPLSMH8YGan(u"ࠪࢀࠬᵅ"),cdZKMn68Pzg4).replace(aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠫࢃ࠭ᵆ"),cdZKMn68Pzg4)
				yy0cNBFOGVZh8rIeQ4 = yy0cNBFOGVZh8rIeQ4.replace(uxE8MyoTRglrcaiQf(u"ࠬอ่็ࠢ็ห๏์ࠧᵇ"),cdZKMn68Pzg4).replace(AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"࠭ำ๋็สࠤ้อ๊หࠩᵈ"),cdZKMn68Pzg4)
				pjXxRTBlb9m8CqSkQ4ot3vhiNfa5Es = [zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"ࠧศๆ฼หอ࠭ᵉ"),uxE8MyoTRglrcaiQf(u"ࠨะํห้࠭ᵊ"),S5fhsRT8JV(u"ࠩส่อ๎ๅࠨᵋ"),LJPOQNK1mcG(u"ࠪห้อๆࠨᵌ"),SGazRxP3yBKZ15ILuch(u"ࠫฬ฽แศๆࠪᵍ"),ObuCsdoDtKmhPLSMH8YGan(u"ࠬำวๅ์๊ࠫᵎ"),opyTNwHgfqbZREWKU(u"࠭วๅ฼สึࠬᵏ"),HC9xWUMpBQJEuTteAqjd(u"ࠧึษ็ัࠬᵐ"),LJPOQNK1mcG(u"ࠨษ็ำ๏์ࠧᵑ"),SGazRxP3yBKZ15ILuch(u"่ࠩ์ฬ๊๊ะࠩᵒ"),iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠪห้฿วๅ็ࠪᵓ"),opyTNwHgfqbZREWKU(u"ࠫฬ฿ๅศๆࠪᵔ")]
				if not any(bK9NATPpaXoZB6MC in yy0cNBFOGVZh8rIeQ4 for bK9NATPpaXoZB6MC in pjXxRTBlb9m8CqSkQ4ot3vhiNfa5Es): yy0cNBFOGVZh8rIeQ4 = yy0cNBFOGVZh8rIeQ4.replace(k5oIaYyp2mnrLK49qhzS(u"ࠬอไࠨᵕ"),cdZKMn68Pzg4)
				yy0cNBFOGVZh8rIeQ4 = yy0cNBFOGVZh8rIeQ4.replace(LungQF89BqemOb32jJsZlW(u"࠭วฯำํࠫᵖ"),iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠧศะิํࠬᵗ")).replace(Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠨษฯ๊อ๏ࠧᵘ"),KNomgGw1kdMCBH(u"ࠩสะ๋ฮ๊ࠨᵙ")).replace(rbUkdYi32PJaRtnxhDvQs(u"ࠪ฽ฬฬไ๋้ࠪᵚ"),aar0zhDnJsOTP7EdgR16HIS29(u"ࠫ฾อฦๅ์ࠪᵛ"))
				yy0cNBFOGVZh8rIeQ4 = yy0cNBFOGVZh8rIeQ4.replace(tRnTydV03Xfi7rbQ(u"ࠬอฬ็สํ๋ࠬᵜ"),aar0zhDnJsOTP7EdgR16HIS29(u"࠭วอ่ห๎ࠬᵝ")).replace(KNomgGw1kdMCBH(u"ฺࠧำห๎์࠭ᵞ"),S5fhsRT8JV(u"ࠨ฻ิฬ๏࠭ᵟ")).replace(AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"ࠩิ์๊อๆิ์๊ࠫᵠ"),tRnTydV03Xfi7rbQ(u"ࠪีํ๋ว็ีํࠫᵡ"))
				yy0cNBFOGVZh8rIeQ4 = yy0cNBFOGVZh8rIeQ4.replace(On1WZJc6dtksqVNgSQ5GBAjuipe(u"ࠫ฿ืศ๋้ࠪᵢ"),YnHG75e2QWwo(u"ࠬเัษ์ࠪᵣ")).replace(nfg30bHwd4aNV12SR7UjFck(u"่࠭ࠡ็ึุ่๊วหࠩᵤ"),k5oIaYyp2mnrLK49qhzS(u"ࠧๆี็ื้อสࠨᵥ")).replace(aar0zhDnJsOTP7EdgR16HIS29(u"ࠨษ฽ห๋๏ࠧᵦ"),zDek1IW37rq6UoKdwyRiAVpF(u"ࠩส฾ฬ์๊ࠨᵧ"))
				yy0cNBFOGVZh8rIeQ4 = yy0cNBFOGVZh8rIeQ4.replace(Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠪฮฬื๊ฯ์ࠪᵨ"),HC9xWUMpBQJEuTteAqjd(u"ࠫฯอั๋ะࠪᵩ")).replace(Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠬิ๊ศๆࠣ฽้๋๊ࠨᵪ"),s8fcjBCSMxzAIkZQbJPga(u"࠭ฮ๋ษ็ࠫᵫ")).replace(YnHG75e2QWwo(u"ࠧๆ๊ึ๎็๐็ࠨᵬ"),k5oIaYyp2mnrLK49qhzS(u"ࠨ็๋ื๏่้ࠨᵭ"))
				yy0cNBFOGVZh8rIeQ4 = yy0cNBFOGVZh8rIeQ4.replace(LJPOQNK1mcG(u"๊๊ࠩิ๏ࠧᵮ"),J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"๋๋ࠪี๊ࠨᵯ")).replace(tRnTydV03Xfi7rbQ(u"ࠫ์์ฯ๋้ࠪᵰ"),HC9xWUMpBQJEuTteAqjd(u"ࠬํๆะ์ࠪᵱ")).replace(AiCor1fIVTDxQUWwHe9vPR7(u"่࠭ฬษษๆ๏ํࠧᵲ"),SGazRxP3yBKZ15ILuch(u"้ࠧอสส็๐ࠧᵳ"))
				yy0cNBFOGVZh8rIeQ4 = yy0cNBFOGVZh8rIeQ4.replace(aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠨฬ็๎ๆุ๊้่ํ๋ࠬᵴ"),zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"ࠩอ่ๆุ๊้่ࠪᵵ")).replace(NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠪฮ้็า๋๊้๎์࠭ᵶ"),ObuCsdoDtKmhPLSMH8YGan(u"ࠫฯ๊แำ์๋๊ࠬᵷ")).replace(xN4fKmsnyM3Y2(u"ࠬ๎ࠠไำอ์๋࠭ᵸ"),S5fhsRT8JV(u"่࠭ไำอ์๋࠭ᵹ"))
				yy0cNBFOGVZh8rIeQ4 = yy0cNBFOGVZh8rIeQ4.replace(TtyzcuW45VKA(u"ࠧศๆะห้๐็ࠨᵺ"),dwiIAcPl04ey7Zv38Mz(u"ࠨฯส่๏ํࠧᵻ")).replace(S5fhsRT8JV(u"่ࠩ์ุ໒โ๋ࠩᵼ"),dwiIAcPl04ey7Zv38Mz(u"้ࠪํู๊ใ๋ࠪᵽ")).replace(AiCor1fIVTDxQUWwHe9vPR7(u"ࠫฬ๊ว็็ํࠫᵾ"),vbYokBuWlxeLDcdVNM60(u"ࠬอๆๆ์ࠪᵿ"))
				yy0cNBFOGVZh8rIeQ4 = yy0cNBFOGVZh8rIeQ4.replace(iRfoNckJs7Ibxzh5j92w8DSWF(u"࠭วๅ็ึุ่๊วหࠩᶀ"),AiCor1fIVTDxQUWwHe9vPR7(u"ࠧๆี็ื้อสࠨᶁ")).replace(zDek1IW37rq6UoKdwyRiAVpF(u"ࠨษ็ฬึอๅอࠩᶂ"),zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"ࠩหีฬ๋ฬࠨᶃ")).replace(Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠪ็ฬืส้่ࠪᶄ"),dwiIAcPl04ey7Zv38Mz(u"่ࠫืส้่ࠪᶅ"))
				yy0cNBFOGVZh8rIeQ4 = yy0cNBFOGVZh8rIeQ4.replace(s8fcjBCSMxzAIkZQbJPga(u"ࠬำั้สࠪᶆ"),KNomgGw1kdMCBH(u"࠭อาสࠪᶇ")).replace(KNomgGw1kdMCBH(u"ࠧศๆส๊ฬฺ๊ะࠩᶈ"),J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠨษ้หู๐ฯࠨᶉ")).replace(tRnTydV03Xfi7rbQ(u"ࠩสื๏๎๊่ࠩᶊ"),YnHG75e2QWwo(u"ࠪหุ๐่๋ࠩᶋ"))
				yy0cNBFOGVZh8rIeQ4 = yy0cNBFOGVZh8rIeQ4.replace(nfg30bHwd4aNV12SR7UjFck(u"ࠫ฾ืศ๊ࠩᶌ"),aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠬ฿ัษ์ࠪᶍ")).replace(zDek1IW37rq6UoKdwyRiAVpF(u"࠭สาๅ์ࠫᶎ"),LJPOQNK1mcG(u"ࠧหำๆ๎ࠬᶏ")).replace(tRnTydV03Xfi7rbQ(u"ࠨฬิ็๏ํࠧᶐ"),HC9xWUMpBQJEuTteAqjd(u"ࠩอี่๐ࠧᶑ")).replace(NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠪห้๋ึศใࠪᶒ"),TtyzcuW45VKA(u"๊ࠫ฼วโࠩᶓ"))
				yy0cNBFOGVZh8rIeQ4 = yy0cNBFOGVZh8rIeQ4.replace(aar0zhDnJsOTP7EdgR16HIS29(u"ࠬื๊ศุํࠫᶔ"),HC9xWUMpBQJEuTteAqjd(u"࠭ั๋ษูอࠬᶕ")).replace(rbUkdYi32PJaRtnxhDvQs(u"ࠧา์สฺ์࠭ᶖ"),nfg30bHwd4aNV12SR7UjFck(u"ࠨำํห฻ฯࠧᶗ")).replace(LungQF89BqemOb32jJsZlW(u"ࠩสื๏๎๊่ࠩᶘ"),liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠪหุ๐่๋ࠩᶙ"))
				yy0cNBFOGVZh8rIeQ4 = yy0cNBFOGVZh8rIeQ4.replace(dwiIAcPl04ey7Zv38Mz(u"่ࠫ๎ๅ๋ั์ࠫᶚ"),rbUkdYi32PJaRtnxhDvQs(u"้่ࠬๆ์า๎ࠬᶛ")).replace(AiCor1fIVTDxQUWwHe9vPR7(u"࠭ใ้็ํำ๏ํࠧᶜ"),J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠧไ๊่๎ิ๐ࠧᶝ")).replace(f8Ja1q5eO02B(u"ࠨษ้๎๊๐ࠧᶞ"),LJPOQNK1mcG(u"ࠩส๊๊๐ࠧᶟ"))
				yy0cNBFOGVZh8rIeQ4 = yy0cNBFOGVZh8rIeQ4.replace(liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠪห๋๐ๅ๋ึ้ࠫᶠ"),ObuCsdoDtKmhPLSMH8YGan(u"ࠫฬ์ๅ๋ึ้ࠫᶡ")).replace(YnHG75e2QWwo(u"ࠬอๆๆ๋ࠪᶢ"),opyTNwHgfqbZREWKU(u"࠭ว็็ํุ๋࠭ᶣ")).replace(aar0zhDnJsOTP7EdgR16HIS29(u"ࠧศ่่๎ࠬᶤ"),opyTNwHgfqbZREWKU(u"ࠨษ้้๏ฺๆࠨᶥ"))
				yy0cNBFOGVZh8rIeQ4 = yy0cNBFOGVZh8rIeQ4.replace(S5fhsRT8JV(u"ࠩส๊๊๐ิ็ึ้ࠫᶦ"),liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠪห๋๋๊ี่ࠪᶧ")).replace(dwiIAcPl04ey7Zv38Mz(u"ࠫฬ๊ว็็ํุ๋࠭ᶨ"),NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠬอๆๆ์ื๊ࠬᶩ")).replace(zDek1IW37rq6UoKdwyRiAVpF(u"࠭วโๆส้๋ࠥำๅี็หฯ࠭ᶪ"),LJPOQNK1mcG(u"ࠧศใ็ห๊่ࠦๆี็ื้อสࠨᶫ"))
				yy0cNBFOGVZh8rIeQ4 = yy0cNBFOGVZh8rIeQ4.replace(wr0HaqRdJ2D9LT7nSO1KMe38ly,VBpIH2QSmvDGlA6TO3e).strip(YnHG75e2QWwo(u"ࠨ࠯ࠪᶬ")).strip(VBpIH2QSmvDGlA6TO3e)
			if yy0cNBFOGVZh8rIeQ4 not in list(p1aOI2dPBNz9wm7uF56S.keys()): p1aOI2dPBNz9wm7uF56S[yy0cNBFOGVZh8rIeQ4] = {}
			p1aOI2dPBNz9wm7uF56S[yy0cNBFOGVZh8rIeQ4][xgPSaoLzTlFtQD37M6HIEsWY] = [kuMXTLrvIZGfjCDtA9YNJ5SxQK,yy0cNBFOGVZh8rIeQ4,kxY4EfTKobmQJ8OathHI53,HHrpyfWjGC,cxokMEeWJnSdZGt53qYhI,iQBgv5oEbM6ZFH4U8qtC,JAYWBoz54tGw7O,SUkst0aLFhj,RqmGlEdhA8z7M]
	uAkLQ7gEZaIBv6Fyn(TV08xYHA2ok,J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡘࡏࡔࡆࡕࠪᶭ"),k5oIaYyp2mnrLK49qhzS(u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤ࡙ࡉࡕࡇࡖࡣࡆࡒࡌࠨᶮ"),p1aOI2dPBNz9wm7uF56S,jCmv4M3HNPdyaLS)
	if LcBbgl9PNj>=eeSQItHBimn5daWcYpbRvxVyuo: NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,S5fhsRT8JV(u"้ࠫี๊ไุ่่๊ࠢษࠡใํࠤࠬᶯ")+str(LcBbgl9PNj)+WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠬࠦๅ้ไ฼ࠤ๊์ࠠๆ๊สๆ฾ࠦวๅสิ๊ฬ๋ฬࠡ࠰࠱࠲ࠥ๎็ไาสࠤฺ๊ใๅหࠣือฮ็ศࠢ฼หิฯࠠๆ่ࠣห้หๆหำ้๎ฯูࠦ็ัๆࠤํอไๆ๊สๆ฾ࠦ็๋࠼ࠪᶰ")+rrBpds0l7OS)
	NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,aar0zhDnJsOTP7EdgR16HIS29(u"࠭สๆࠢฯ่อࠦฬๆ์฼ࠤฬ๊รใีส้ࠥอไๆฬ๋ๅึฯࠠโ์ࠣห้ฮั็ษ่ะࠬᶱ"))
	tHOfW4iaMLm8VuZegxobrlnj5A0yB(rrVbXS3ncE,rrVbXS3ncE,rrVbXS3ncE)
	MF2hUj6YZ9rCcEOqXkBL0f8Pz()
	return
def tNzrMPyRv6iaGVpASC7EcfmZbj(e3e5Wr7HPcK6RbEwXTmu,X9XExg7ect62uBzjfqhPCyb18):
	nB3YKPXmCteR5c4FqMphN2izG = ksTLSoVGg0ht
	ANclvfeVCGhO28szDLBHyor = USuRxnPlV5.menuItemsLIST
	USuRxnPlV5.menuItemsLIST[:] = []
	if nB3YKPXmCteR5c4FqMphN2izG and LungQF89BqemOb32jJsZlW(u"ࠧࡠࡅࡕࡉࡆ࡚ࡅࡏࡇ࡚ࡣࠬᶲ") not in X9XExg7ect62uBzjfqhPCyb18:
		xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = sZHYrLPog4wmuW0ECdc(TV08xYHA2ok,zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"ࠨ࡮࡬ࡷࡹ࠭ᶳ"),s8fcjBCSMxzAIkZQbJPga(u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡎࡖࡔࡗࠩᶴ"),YnHG75e2QWwo(u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡏࡐࡕࡘࡢࠫᶵ")+e3e5Wr7HPcK6RbEwXTmu)
	elif liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠫࡤࡒࡉࡗࡇࡢࠫᶶ") not in X9XExg7ect62uBzjfqhPCyb18 or LJPOQNK1mcG(u"ࠬࡥࡖࡐࡆࡢࠫᶷ") not in X9XExg7ect62uBzjfqhPCyb18:
		import tjK6YdAZJT
		KZ4oqDz5xgA2tkGcTaeQ1Lh3dp = vbYokBuWlxeLDcdVNM60(u"࠭ไๅลึๅ๊ࠥฯ๋ๅู้้ࠣไสࠢไ๎ࠥํะศࠢส่๊๎โฺࠢ࠱ࠤํืำศๆฬࠤฬ๊ฮุลࠣ็ฬ์ࠠโ์๊หࠥะแศืํ่ࠥอไๆึๆ่ฮࠦ࠮ࠡลำหࠥอไๆึๆ่ฮࠦไ๋ีอࠤาาศࠡใฯีอࠦลาีส่ࠥํะ่ࠢสฺ่๊ใๅหࠣษ้๏ࠠศๆ่ฬึ๋ฬࠡ็้ࠤ็อฦๆหࠣีุอฦๅࠢส่อืๆศ็ฯࠫᶸ")
		if S5fhsRT8JV(u"ࠧࡠࡎࡌ࡚ࡊࡥࠧᶹ") not in X9XExg7ect62uBzjfqhPCyb18:
			try: tjK6YdAZJT.iBT7IHNAlEYDgsRthp3x9ynd(e3e5Wr7HPcK6RbEwXTmu,nfg30bHwd4aNV12SR7UjFck(u"ࠨࡘࡒࡈࡤ࡛ࡎࡌࡐࡒ࡛ࡓࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧᶺ"),cdZKMn68Pzg4,cdZKMn68Pzg4,X9XExg7ect62uBzjfqhPCyb18+nfg30bHwd4aNV12SR7UjFck(u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧᶻ"),ksTLSoVGg0ht)
			except: NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,YnHG75e2QWwo(u"้ࠪํู่ࠡโࡌࡔ࡙࡜ࠠๅๆไ๎ิ๐่่ษอࠫᶼ"),KZ4oqDz5xgA2tkGcTaeQ1Lh3dp)
			try: tjK6YdAZJT.iBT7IHNAlEYDgsRthp3x9ynd(e3e5Wr7HPcK6RbEwXTmu,SGazRxP3yBKZ15ILuch(u"࡛ࠫࡕࡄࡠࡏࡒ࡚ࡎࡋࡓࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩᶽ"),cdZKMn68Pzg4,cdZKMn68Pzg4,X9XExg7ect62uBzjfqhPCyb18+aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᶾ"),ksTLSoVGg0ht)
			except: NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,LJPOQNK1mcG(u"࠭ๅ้ไ฼ࠤๅࡏࡐࡕࡘ่้ࠣ็๊ะ์๋๋ฬะࠧᶿ"),KZ4oqDz5xgA2tkGcTaeQ1Lh3dp)
			try: tjK6YdAZJT.iBT7IHNAlEYDgsRthp3x9ynd(e3e5Wr7HPcK6RbEwXTmu,aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠧࡗࡑࡇࡣࡘࡋࡒࡊࡇࡖࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬ᷀"),cdZKMn68Pzg4,cdZKMn68Pzg4,X9XExg7ect62uBzjfqhPCyb18+vbYokBuWlxeLDcdVNM60(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭᷁"),ksTLSoVGg0ht)
			except: NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,HC9xWUMpBQJEuTteAqjd(u"่ࠩ์็฿ࠠแࡋࡓࡘ࡛ࠦไๅใํำ๏๎็ศฬ᷂ࠪ"),KZ4oqDz5xgA2tkGcTaeQ1Lh3dp)
		if Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠪࡣ࡛ࡕࡄࡠࠩ᷃") not in X9XExg7ect62uBzjfqhPCyb18:
			try: tjK6YdAZJT.iBT7IHNAlEYDgsRthp3x9ynd(e3e5Wr7HPcK6RbEwXTmu,Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠫࡑࡏࡖࡆࡡࡘࡒࡐࡔࡏࡘࡐࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫ᷄"),cdZKMn68Pzg4,cdZKMn68Pzg4,X9XExg7ect62uBzjfqhPCyb18+s8fcjBCSMxzAIkZQbJPga(u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ᷅"),ksTLSoVGg0ht)
			except: NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"࠭ๅ้ไ฼ࠤๅࡏࡐࡕࡘ่้่ࠣๆ้ษอࠫ᷆"),KZ4oqDz5xgA2tkGcTaeQ1Lh3dp)
			try: tjK6YdAZJT.iBT7IHNAlEYDgsRthp3x9ynd(e3e5Wr7HPcK6RbEwXTmu,opyTNwHgfqbZREWKU(u"ࠧࡍࡋ࡙ࡉࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭᷇"),cdZKMn68Pzg4,cdZKMn68Pzg4,X9XExg7ect62uBzjfqhPCyb18+LJPOQNK1mcG(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭᷈"),ksTLSoVGg0ht)
			except: NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"่ࠩ์็฿ࠠแࡋࡓࡘ࡛ࠦไๅไ้์ฬะࠧ᷉"),KZ4oqDz5xgA2tkGcTaeQ1Lh3dp)
		xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = USuRxnPlV5.menuItemsLIST
		if nB3YKPXmCteR5c4FqMphN2izG: uAkLQ7gEZaIBv6Fyn(TV08xYHA2ok,WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡏࡐࡕࡘ᷊ࠪ"),HC9xWUMpBQJEuTteAqjd(u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡉࡑࡖ࡙ࡣࠬ᷋")+e3e5Wr7HPcK6RbEwXTmu,xsGUcR3ef6glKY5hQwpFXEaSt2mrIz,jCmv4M3HNPdyaLS)
	USuRxnPlV5.menuItemsLIST[:] = ANclvfeVCGhO28szDLBHyor
	return xsGUcR3ef6glKY5hQwpFXEaSt2mrIz
def KJ7A5drjqIN8iCB2Pm(e3e5Wr7HPcK6RbEwXTmu,X9XExg7ect62uBzjfqhPCyb18):
	nB3YKPXmCteR5c4FqMphN2izG = ksTLSoVGg0ht
	ANclvfeVCGhO28szDLBHyor = USuRxnPlV5.menuItemsLIST
	USuRxnPlV5.menuItemsLIST[:] = []
	if nB3YKPXmCteR5c4FqMphN2izG and opyTNwHgfqbZREWKU(u"ࠬࡥࡃࡓࡇࡄࡘࡊࡔࡅࡘࡡࠪ᷌") not in X9XExg7ect62uBzjfqhPCyb18:
		xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = sZHYrLPog4wmuW0ECdc(TV08xYHA2ok,ObuCsdoDtKmhPLSMH8YGan(u"࠭࡬ࡪࡵࡷࠫ᷍"),LungQF89BqemOb32jJsZlW(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡐ࠷᷎࡚࠭"),Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡑ࠸࡛࡟ࠨ᷏")+e3e5Wr7HPcK6RbEwXTmu)
	elif aar0zhDnJsOTP7EdgR16HIS29(u"ࠩࡢࡐࡎ࡜ࡅࡠ᷐ࠩ") not in X9XExg7ect62uBzjfqhPCyb18 or AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"ࠪࡣ࡛ࡕࡄࡠࠩ᷑") not in X9XExg7ect62uBzjfqhPCyb18:
		import cwOg9mFakl
		KZ4oqDz5xgA2tkGcTaeQ1Lh3dp = xN4fKmsnyM3Y2(u"้๊ࠫริใ่ࠣิ๐ใࠡ็ื็้ฯࠠโ์๋ࠣีอࠠศๆ่์็฿ࠠ࠯๋ࠢีุอไสࠢส่ำ฽รࠡๅส๊ࠥ็๊่ษࠣฮๆอี๋ๆࠣห้๋ิไๆฬࠤ࠳ࠦรัษࠣห้๋ิไๆฬࠤ้๐ำหࠢะะอࠦแอำหࠤสืำศๆ๋ࠣีํࠠศๆุ่่๊ษࠡว็ํࠥอไๆสิ้ัࠦๅ็ࠢๅหห๋ษࠡำึหห๊ࠠศๆหี๋อๅอࠩ᷒")
		if S5fhsRT8JV(u"ࠬࡥࡌࡊࡘࡈࡣࠬᷓ") not in X9XExg7ect62uBzjfqhPCyb18:
			try: cwOg9mFakl.iBT7IHNAlEYDgsRthp3x9ynd(e3e5Wr7HPcK6RbEwXTmu,LJPOQNK1mcG(u"࠭ࡖࡐࡆࡢ࡙ࡓࡑࡎࡐ࡙ࡑࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬᷔ"),cdZKMn68Pzg4,cdZKMn68Pzg4,X9XExg7ect62uBzjfqhPCyb18+nfg30bHwd4aNV12SR7UjFck(u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᷕ"),ksTLSoVGg0ht)
			except: NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,ObuCsdoDtKmhPLSMH8YGan(u"ࠨ็๋ๆ฾ࠦเࡎ࠵ࡘࠤ้๊แ๋ัํ์์อสࠨᷖ"),KZ4oqDz5xgA2tkGcTaeQ1Lh3dp)
			try: cwOg9mFakl.iBT7IHNAlEYDgsRthp3x9ynd(e3e5Wr7HPcK6RbEwXTmu,dwiIAcPl04ey7Zv38Mz(u"࡙ࠩࡓࡉࡥࡍࡐࡘࡌࡉࡘࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧᷗ"),cdZKMn68Pzg4,cdZKMn68Pzg4,X9XExg7ect62uBzjfqhPCyb18+aar0zhDnJsOTP7EdgR16HIS29(u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᷘ"),ksTLSoVGg0ht)
			except: NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,k5oIaYyp2mnrLK49qhzS(u"๊ࠫ๎โฺࠢใࡑ࠸࡛ࠠๅๆไ๎ิ๐่่ษอࠫᷙ"),KZ4oqDz5xgA2tkGcTaeQ1Lh3dp)
			try: cwOg9mFakl.iBT7IHNAlEYDgsRthp3x9ynd(e3e5Wr7HPcK6RbEwXTmu,AiCor1fIVTDxQUWwHe9vPR7(u"ࠬ࡜ࡏࡅࡡࡖࡉࡗࡏࡅࡔࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪᷚ"),cdZKMn68Pzg4,cdZKMn68Pzg4,X9XExg7ect62uBzjfqhPCyb18+tRnTydV03Xfi7rbQ(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᷛ"),ksTLSoVGg0ht)
			except: NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠧๆ๊ๅ฽ࠥๆࡍ࠴ࡗ่้ࠣ็๊ะ์๋๋ฬะࠧᷜ"),KZ4oqDz5xgA2tkGcTaeQ1Lh3dp)
		if aar0zhDnJsOTP7EdgR16HIS29(u"ࠨࡡ࡙ࡓࡉࡥࠧᷝ") not in X9XExg7ect62uBzjfqhPCyb18:
			try: cwOg9mFakl.iBT7IHNAlEYDgsRthp3x9ynd(e3e5Wr7HPcK6RbEwXTmu,aar0zhDnJsOTP7EdgR16HIS29(u"ࠩࡏࡍ࡛ࡋ࡟ࡖࡐࡎࡒࡔ࡝ࡎࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩᷞ"),cdZKMn68Pzg4,cdZKMn68Pzg4,X9XExg7ect62uBzjfqhPCyb18+On1WZJc6dtksqVNgSQ5GBAjuipe(u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᷟ"),ksTLSoVGg0ht)
			except: NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"๊ࠫ๎โฺࠢใࡑ࠸࡛ࠠๅๆๅ๊ํอสࠨᷠ"),KZ4oqDz5xgA2tkGcTaeQ1Lh3dp)
			try: cwOg9mFakl.iBT7IHNAlEYDgsRthp3x9ynd(e3e5Wr7HPcK6RbEwXTmu,uxE8MyoTRglrcaiQf(u"ࠬࡒࡉࡗࡇࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫᷡ"),cdZKMn68Pzg4,cdZKMn68Pzg4,X9XExg7ect62uBzjfqhPCyb18+vbYokBuWlxeLDcdVNM60(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᷢ"),ksTLSoVGg0ht)
			except: NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,LungQF89BqemOb32jJsZlW(u"ࠧๆ๊ๅ฽ࠥๆࡍ࠴ࡗ่้่ࠣๆ้ษอࠫᷣ"),KZ4oqDz5xgA2tkGcTaeQ1Lh3dp)
		xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = USuRxnPlV5.menuItemsLIST
		if nB3YKPXmCteR5c4FqMphN2izG: uAkLQ7gEZaIBv6Fyn(TV08xYHA2ok,f8Ja1q5eO02B(u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡑ࠸࡛ࠧᷤ"),J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡒ࠹ࡕࡠࠩᷥ")+e3e5Wr7HPcK6RbEwXTmu,xsGUcR3ef6glKY5hQwpFXEaSt2mrIz,jCmv4M3HNPdyaLS)
	USuRxnPlV5.menuItemsLIST[:] = ANclvfeVCGhO28szDLBHyor
	return xsGUcR3ef6glKY5hQwpFXEaSt2mrIz
def iQFDul68fTNaS5(e3e5Wr7HPcK6RbEwXTmu,X9XExg7ect62uBzjfqhPCyb18,iJLMVpO23FlPIedm1xbwjy):
	tHOfW4iaMLm8VuZegxobrlnj5A0yB(Il4q1Ex7r0Y6wy2URk,Il4q1Ex7r0Y6wy2URk,c5oDzdPaOE8)
	if iJLMVpO23FlPIedm1xbwjy: a2u7fFRVJ1TxUBj9e6NsOdXy4l5hC(ksTLSoVGg0ht)
	elif ObuCsdoDtKmhPLSMH8YGan(u"ࠪࡣࡈࡘࡅࡂࡖࡈࡒࡊ࡝࡟ࠨᷦ") in X9XExg7ect62uBzjfqhPCyb18 and not iJLMVpO23FlPIedm1xbwjy: a2u7fFRVJ1TxUBj9e6NsOdXy4l5hC(IZQbmFzLHDtXfc)
	iKXH1jGfIvCTuV5qEtZkpQ4SWJg7Oe = X9XExg7ect62uBzjfqhPCyb18.replace(AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"ࠫࡤࡉࡒࡆࡃࡗࡉࡓࡋࡗࡠࠩᷧ"),cdZKMn68Pzg4).replace(Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧᷨ"),cdZKMn68Pzg4).replace(xN4fKmsnyM3Y2(u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᷩ"),cdZKMn68Pzg4)
	if not iJLMVpO23FlPIedm1xbwjy:
		zJLApFBcIhnSj(KNomgGw1kdMCBH(u"ࠧ࡭࡫ࡱ࡯ࠬᷪ"),aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠨฬะำ๏ัࠠใษษ้ฮࠦวๅลๅืฬ๋ࠧᷫ"),cdZKMn68Pzg4,SGazRxP3yBKZ15ILuch(u"࠷࠷࠵ὤ"),cdZKMn68Pzg4,cdZKMn68Pzg4,rbUkdYi32PJaRtnxhDvQs(u"ࠩࡢࡇࡗࡋࡁࡕࡇࡑࡉ࡜ࡥࠧᷬ")+iKXH1jGfIvCTuV5qEtZkpQ4SWJg7Oe,cdZKMn68Pzg4,{vbYokBuWlxeLDcdVNM60(u"ࠪࡪࡴࡲࡤࡦࡴࠪᷭ"):e3e5Wr7HPcK6RbEwXTmu})
		zJLApFBcIhnSj(S5fhsRT8JV(u"ࠫࡱ࡯࡮࡬ࠩᷮ"),Gzygq01Kcb9U3+WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠬࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࠪᷯ")+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,YnHG75e2QWwo(u"࠺࠻࠼࠽ὥ"))
		RQ6kcmed3DvwrX58qHEu = [aar0zhDnJsOTP7EdgR16HIS29(u"࠭รโๆส้ࠬᷰ"),f8Ja1q5eO02B(u"ࠧๆี็ื้อสࠨᷱ"),SGazRxP3yBKZ15ILuch(u"ࠨ็ึีา๐วหࠩᷲ"),rbUkdYi32PJaRtnxhDvQs(u"ࠩหีฬ๋ฬࠨᷳ"),vbYokBuWlxeLDcdVNM60(u"ࠪว฼็วๅ๋ࠢ็ึะ่็ࠩᷴ"),vbYokBuWlxeLDcdVNM60(u"ࠫึ๋ึศ่ࠪ᷵"),rbUkdYi32PJaRtnxhDvQs(u"ࠬษอะอ࠰วำืࠧ᷶"),rbUkdYi32PJaRtnxhDvQs(u"࠭ำๅษึ่᷷ࠬ"),J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠧๆ๊ึ๎็๏᷸ࠧ"),NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠨลื๋ึ࠳รไอิ᷹ࠫ"),Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠩส่ว์᷺ࠧ"),S5fhsRT8JV(u"ฺࠪา้ࠧ᷻"),k5oIaYyp2mnrLK49qhzS(u"ࠫึ๐วืหࠪ᷼"),xN4fKmsnyM3Y2(u"ࠬ์๊หใ็็ุ᷽࠭"),xN4fKmsnyM3Y2(u"࠭ๅๆอ็๎๋࠭᷾"),uxE8MyoTRglrcaiQf(u"ࠧษอࠣั๏᷿࠭"),LJPOQNK1mcG(u"ࠨัํ๊๏ฯࠧḀ"),nfg30bHwd4aNV12SR7UjFck(u"ࠩึ๊ํอสࠨḁ"),k5oIaYyp2mnrLK49qhzS(u"ࠪวำื้ࠨḂ")]
		iJLMVpO23FlPIedm1xbwjy = nnsBpJv6XL3OzHoe4Vuhr
		for Xh0MrnNgCoE4uIpA7fcSj2RUzswQ in RQ6kcmed3DvwrX58qHEu:
			iJLMVpO23FlPIedm1xbwjy += hiuZa0PIsErm6UC7
			zJLApFBcIhnSj(iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫḃ"),nc3GLkA65oxOd+Xh0MrnNgCoE4uIpA7fcSj2RUzswQ,cdZKMn68Pzg4,liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"࠹࠹࠷ὦ"),cdZKMn68Pzg4,str(iJLMVpO23FlPIedm1xbwjy),iKXH1jGfIvCTuV5qEtZkpQ4SWJg7Oe,cdZKMn68Pzg4,{J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬḄ"):e3e5Wr7HPcK6RbEwXTmu})
	else:
		wmJ9NCykoxj8 = [vbYokBuWlxeLDcdVNM60(u"࠭วโๆส้ࠬḅ"),ObuCsdoDtKmhPLSMH8YGan(u"ࠧ࡮ࡱࡹ࡭ࡪ࠭Ḇ"),J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠨใํ่๊࠭ḇ"),SGazRxP3yBKZ15ILuch(u"ࠩไ่๊࠭Ḉ")]
		UA1q3m0veRxyn8 = [aar0zhDnJsOTP7EdgR16HIS29(u"ุ้๊ࠪำๅࠩḉ"),zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"ࠫࡸ࡫ࡲࡪࡧࡶࠫḊ")]
		aeXYZs4iILx8fTzRck = [aNdix5gq7yeFHTMWhnzm8pX0Y16(u"๋ࠬำศำะࠫḋ"),iRfoNckJs7Ibxzh5j92w8DSWF(u"࠭ๅิำะ๎ฬะࠧḌ")]
		o6F5wG0MuOsnPcemHd9jpJZIEQ = [TtyzcuW45VKA(u"ࠧษำส้ั࠭ḍ"),J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠨࡵ࡫ࡳࡼ࠭Ḏ"),aar0zhDnJsOTP7EdgR16HIS29(u"ࠩอ่ๆุ๊้่ࠪḏ"),S5fhsRT8JV(u"ࠪฮ้๐แำ์๋๊ࠬḐ")]
		YLHx9O0p243j6XIoq = [nfg30bHwd4aNV12SR7UjFck(u"ࠫฬ์ๅ๋ࠩḑ"),liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"้ࠬัห๊้ࠫḒ"),liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"࠭ใศำอ์๋࠭ḓ"),Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠧ࡬࡫ࡧࡷࠬḔ"),nfg30bHwd4aNV12SR7UjFck(u"ࠨูไ่ࠬḕ"),WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠩส฻ๆอไࠨḖ")]
		PfS7ciTjYdMg6L8 = [AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"ࠪี๊฼ว็ࠩḗ")]
		rDMwBgVzEW = [J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠫฬำฯฬࠩḘ"),iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠬอฮาࠩḙ"),LungQF89BqemOb32jJsZlW(u"࠭ๅ้ะิࠫḚ"),ObuCsdoDtKmhPLSMH8YGan(u"ࠧอัํำࠬḛ"),tRnTydV03Xfi7rbQ(u"ࠨ็ูหๆ࠭Ḝ"),s8fcjBCSMxzAIkZQbJPga(u"ࠩะำ๏ัࠧḝ")]
		ooHgTQ2R1xC = [On1WZJc6dtksqVNgSQ5GBAjuipe(u"ࠪื้อำๅࠩḞ"),zDek1IW37rq6UoKdwyRiAVpF(u"ุ๊ࠫำๅ้ࠪḟ")]
		mt3WjalxMR6OF4sX0r9LD2QdwJq = [liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠬอฺศ่ํࠫḠ"),uxE8MyoTRglrcaiQf(u"࠭ๅ้ีํๆ๎࠭ḡ"),zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"ࠧไๆํฬࠬḢ"),rbUkdYi32PJaRtnxhDvQs(u"ࠨฯไ่ࠬḣ"),dwiIAcPl04ey7Zv38Mz(u"ࠩࡰࡹࡸ࡯ࡣࠨḤ")]
		j1I2lbMUPf4GyTKRsuh = [J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠪห่ััࠨḥ"),TtyzcuW45VKA(u"ࠫฬฺ็าࠩḦ"),f8Ja1q5eO02B(u"๋ࠬๅ๋ิ๊ࠫḧ"),Rsdai9xIEPcpuBMKOUwkTA05q(u"࠭วฺๆ์ࠫḨ"),J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠧๆะอหึํࠧḩ"),KNomgGw1kdMCBH(u"ࠨ็ัฮฬืวหࠩḪ"),s8fcjBCSMxzAIkZQbJPga(u"ࠩสๆํ๏ࠧḫ")]
		UqLC1p9dRjvakOuwDMN3 = [HC9xWUMpBQJEuTteAqjd(u"ࠪห้อๆࠨḬ"),YnHG75e2QWwo(u"ࠫาอไ๋ࠩḭ"),opyTNwHgfqbZREWKU(u"๋ࠬหษฬࠪḮ"),J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"࠭ัศศฯࠫḯ")]
		NBzMJawH1SxAXPuVZj7bE9 = [opyTNwHgfqbZREWKU(u"ࠧืฯๆࠫḰ"),vbYokBuWlxeLDcdVNM60(u"ࠨๅ๋้๏ี๊ࠨḱ")]
		EEPn96lTbFwR1pfxaC = [opyTNwHgfqbZREWKU(u"ࠩิ๎ฬ฼็ࠨḲ"),J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠪ็ํื็ࠨḳ"),xN4fKmsnyM3Y2(u"๊ࠫ฻วา฻๊ࠫḴ"),J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ฺ่ࠬหࠩḵ"),vbYokBuWlxeLDcdVNM60(u"࠭ั๋ษูอࠬḶ")]
		LqGcH1s2bnTOklEuAmQw0 = [zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"ࠧ็์อๅ้้ำࠨḷ"),WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠨࡰࡨࡸ࡫ࡲࡩࡹࠩḸ"),tRnTydV03Xfi7rbQ(u"้ࠩ๎ฯ็ไ๋ๅึࠫḹ")]
		ppkt2AuWY7gqUI = [vbYokBuWlxeLDcdVNM60(u"้๊ࠪัไ๋่ࠪḺ"),AiCor1fIVTDxQUWwHe9vPR7(u"ࠫฬฺฮศืࠪḻ"),zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"ࠬ์ฬ้็ࠪḼ")]
		CGOjMRlNnBafrtz = [TtyzcuW45VKA(u"࠭ศฬࠢะ๎ࠬḽ"),f8Ja1q5eO02B(u"ࠧ࡭࡫ࡹࡩࠬḾ"),WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠨไ้ห์࠭ḿ"),vbYokBuWlxeLDcdVNM60(u"ࠩๅ๊ํอสࠨṀ")]
		k1kr6Y9vdHwJIDCMsq2pfBxVGt7nT = [J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠪำ๏์ࠧṁ"),k5oIaYyp2mnrLK49qhzS(u"ࠫฬีู๋้ࠪṂ"),WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ุ๊ࠬศำสฮࠬṃ"),HC9xWUMpBQJEuTteAqjd(u"࠭ไุ็ํหฯ࠭Ṅ"),On1WZJc6dtksqVNgSQ5GBAjuipe(u"ࠧะ฻สลࠬṅ"),opyTNwHgfqbZREWKU(u"ࠨไิห๋࠭Ṇ"),iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠩๅูฬฬฯࠨṇ"),AiCor1fIVTDxQUWwHe9vPR7(u"ࠪีะอมࠨṈ"),AiCor1fIVTDxQUWwHe9vPR7(u"๊ࠫืฬฺ์๊ࠫṉ"),LJPOQNK1mcG(u"ࠬอะศ่ࠪṊ"),LungQF89BqemOb32jJsZlW(u"࠭วิๆส้ࠬṋ"),SGazRxP3yBKZ15ILuch(u"ࠧห๊สุ๏ำࠧṌ"),TtyzcuW45VKA(u"ࠨะฺฬࠬṍ"),NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠩะ์ื๎๊ࠨṎ"),WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠪ฽ฯฮวหࠩṏ"),aar0zhDnJsOTP7EdgR16HIS29(u"๊ࠫ๎วๅ์าࠫṐ"),tRnTydV03Xfi7rbQ(u"ࠬ์่ศ฻ํࠫṑ"),zDek1IW37rq6UoKdwyRiAVpF(u"ู࠭ใษษำࠬṒ"),WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠧศ่สุ๏ีࠧṓ")]
		xB05gYe93E6Vus1Rny = [LJPOQNK1mcG(u"ࠨ࠴࠳࠵࠵࠭Ṕ"),tRnTydV03Xfi7rbQ(u"ࠩ࠵࠴࠶࠷ࠧṕ"),LungQF89BqemOb32jJsZlW(u"ࠪ࠶࠵࠷࠲ࠨṖ"),TtyzcuW45VKA(u"ࠫ࠷࠶࠱࠴ࠩṗ"),vbYokBuWlxeLDcdVNM60(u"ࠬ࠸࠰࠲࠶ࠪṘ"),nfg30bHwd4aNV12SR7UjFck(u"࠭࠲࠱࠳࠸ࠫṙ"),WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠧ࠳࠲࠴࠺ࠬṚ"),aar0zhDnJsOTP7EdgR16HIS29(u"ࠨ࠴࠳࠵࠼࠭ṛ"),vbYokBuWlxeLDcdVNM60(u"ࠩ࠵࠴࠶࠾ࠧṜ"),ObuCsdoDtKmhPLSMH8YGan(u"ࠪ࠶࠵࠷࠹ࠨṝ"),vbYokBuWlxeLDcdVNM60(u"ࠫ࠷࠶࠲࠱ࠩṞ"),aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠬ࠸࠰࠳࠳ࠪṟ"),KNomgGw1kdMCBH(u"࠭࠲࠱࠴࠵ࠫṠ"),opyTNwHgfqbZREWKU(u"ࠧ࠳࠲࠵࠷ࠬṡ"),Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠨ࠴࠳࠶࠹࠭Ṣ"),vbYokBuWlxeLDcdVNM60(u"ࠩ࠵࠴࠷࠻ࠧṣ"),liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠪ࠶࠵࠸࠶ࠨṤ"),ObuCsdoDtKmhPLSMH8YGan(u"ࠫ࠷࠶࠲࠸ࠩṥ"),uxE8MyoTRglrcaiQf(u"ࠬ࠸࠰࠳࠺ࠪṦ")]
		for yy0cNBFOGVZh8rIeQ4 in sorted(list(p1aOI2dPBNz9wm7uF56S.keys())):
			wRbgsDELJBq9odiKFIu6 = yy0cNBFOGVZh8rIeQ4.lower()
			rrb0SF6otehufCYOX4 = []
			if any(value in wRbgsDELJBq9odiKFIu6 for value in wmJ9NCykoxj8): rrb0SF6otehufCYOX4.append(hiuZa0PIsErm6UC7)
			if any(value in wRbgsDELJBq9odiKFIu6 for value in UA1q3m0veRxyn8): rrb0SF6otehufCYOX4.append(bVX3ev1spE)
			if any(value in wRbgsDELJBq9odiKFIu6 for value in aeXYZs4iILx8fTzRck): rrb0SF6otehufCYOX4.append(kzoASbNraPcfgvWJmY9Qu)
			if any(value in wRbgsDELJBq9odiKFIu6 for value in o6F5wG0MuOsnPcemHd9jpJZIEQ): rrb0SF6otehufCYOX4.append(iwQJREcVTSe1G2gCvlfhbHWLjqopa)
			if any(value in wRbgsDELJBq9odiKFIu6 for value in YLHx9O0p243j6XIoq): rrb0SF6otehufCYOX4.append(ffXqoLey4TixFJBw)
			if any(value in wRbgsDELJBq9odiKFIu6 for value in PfS7ciTjYdMg6L8): rrb0SF6otehufCYOX4.append(opyTNwHgfqbZREWKU(u"࠹ὧ"))
			if any(value in wRbgsDELJBq9odiKFIu6 for value in rDMwBgVzEW) and wRbgsDELJBq9odiKFIu6 not in [f8Ja1q5eO02B(u"࠭วฯำ์ࠫṧ")]: rrb0SF6otehufCYOX4.append(YnHG75e2QWwo(u"࠻Ὠ"))
			if any(value in wRbgsDELJBq9odiKFIu6 for value in ooHgTQ2R1xC): rrb0SF6otehufCYOX4.append(opyTNwHgfqbZREWKU(u"࠽Ὡ"))
			if any(value in wRbgsDELJBq9odiKFIu6 for value in mt3WjalxMR6OF4sX0r9LD2QdwJq): rrb0SF6otehufCYOX4.append(liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"࠿Ὢ"))
			if any(value in wRbgsDELJBq9odiKFIu6 for value in j1I2lbMUPf4GyTKRsuh): rrb0SF6otehufCYOX4.append(KNomgGw1kdMCBH(u"࠱࠱Ὣ"))
			if any(value in wRbgsDELJBq9odiKFIu6 for value in UqLC1p9dRjvakOuwDMN3): rrb0SF6otehufCYOX4.append(nfg30bHwd4aNV12SR7UjFck(u"࠲࠳Ὤ"))
			if any(value in wRbgsDELJBq9odiKFIu6 for value in NBzMJawH1SxAXPuVZj7bE9): rrb0SF6otehufCYOX4.append(nfg30bHwd4aNV12SR7UjFck(u"࠳࠵Ὥ"))
			if any(value in wRbgsDELJBq9odiKFIu6 for value in EEPn96lTbFwR1pfxaC): rrb0SF6otehufCYOX4.append(AiCor1fIVTDxQUWwHe9vPR7(u"࠴࠷Ὦ"))
			if any(value in wRbgsDELJBq9odiKFIu6 for value in LqGcH1s2bnTOklEuAmQw0): rrb0SF6otehufCYOX4.append(ObuCsdoDtKmhPLSMH8YGan(u"࠵࠹Ὧ"))
			if any(value in wRbgsDELJBq9odiKFIu6 for value in ppkt2AuWY7gqUI): rrb0SF6otehufCYOX4.append(s8fcjBCSMxzAIkZQbJPga(u"࠶࠻ὰ"))
			if any(value in wRbgsDELJBq9odiKFIu6 for value in CGOjMRlNnBafrtz): rrb0SF6otehufCYOX4.append(aar0zhDnJsOTP7EdgR16HIS29(u"࠷࠶ά"))
			if any(value in wRbgsDELJBq9odiKFIu6 for value in k1kr6Y9vdHwJIDCMsq2pfBxVGt7nT): rrb0SF6otehufCYOX4.append(s8fcjBCSMxzAIkZQbJPga(u"࠱࠸ὲ"))
			if any(value in wRbgsDELJBq9odiKFIu6 for value in xB05gYe93E6Vus1Rny): rrb0SF6otehufCYOX4.append(zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"࠲࠺έ"))
			if not rrb0SF6otehufCYOX4: rrb0SF6otehufCYOX4 = [s8fcjBCSMxzAIkZQbJPga(u"࠳࠼ὴ")]
			for HoO9J2jYcCe8W in rrb0SF6otehufCYOX4:
				if str(HoO9J2jYcCe8W)==iJLMVpO23FlPIedm1xbwjy:
					zJLApFBcIhnSj(zDek1IW37rq6UoKdwyRiAVpF(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧṨ"),nc3GLkA65oxOd+yy0cNBFOGVZh8rIeQ4,yy0cNBFOGVZh8rIeQ4,YnHG75e2QWwo(u"࠴࠺࠻ή"),cdZKMn68Pzg4,cdZKMn68Pzg4,iKXH1jGfIvCTuV5qEtZkpQ4SWJg7Oe+HC9xWUMpBQJEuTteAqjd(u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬṩ"))
	tHOfW4iaMLm8VuZegxobrlnj5A0yB(Il4q1Ex7r0Y6wy2URk,Il4q1Ex7r0Y6wy2URk,rrVbXS3ncE)
	return
def SSxfkWcDPQjv9LVrybuN5ed2Z6oR3g(e3e5Wr7HPcK6RbEwXTmu,X9XExg7ect62uBzjfqhPCyb18):
	nB3YKPXmCteR5c4FqMphN2izG = ksTLSoVGg0ht
	if nB3YKPXmCteR5c4FqMphN2izG:
		zJLApFBcIhnSj(zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"ࠩ࡯࡭ࡳࡱࠧṪ"),rbUkdYi32PJaRtnxhDvQs(u"ࠪฮาี๊ฬࠢๅหห๋ษࠡลๅืฬ๋ࠠࡊࡒࡗ࡚ࠬṫ"),cdZKMn68Pzg4,s8fcjBCSMxzAIkZQbJPga(u"࠻࠻࠺ὶ"),cdZKMn68Pzg4,cdZKMn68Pzg4,AiCor1fIVTDxQUWwHe9vPR7(u"ࠫࡤࡉࡒࡆࡃࡗࡉࡓࡋࡗࡠࠩṬ"),cdZKMn68Pzg4,{SGazRxP3yBKZ15ILuch(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬṭ"):e3e5Wr7HPcK6RbEwXTmu})
		zJLApFBcIhnSj(Rsdai9xIEPcpuBMKOUwkTA05q(u"࠭࡬ࡪࡰ࡮ࠫṮ"),Gzygq01Kcb9U3+KNomgGw1kdMCBH(u"ࠧ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࠬṯ")+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,S5fhsRT8JV(u"࠾࠿࠹࠺ί"))
	ANclvfeVCGhO28szDLBHyor = USuRxnPlV5.menuItemsLIST[:]
	import tjK6YdAZJT
	if e3e5Wr7HPcK6RbEwXTmu:
		if not tjK6YdAZJT.Im36vznMobP7WCNfFY2lJZ(e3e5Wr7HPcK6RbEwXTmu,IZQbmFzLHDtXfc): return
		gQw6uIDP2ksN51rEJyAph4lOSfX = tNzrMPyRv6iaGVpASC7EcfmZbj(e3e5Wr7HPcK6RbEwXTmu,X9XExg7ect62uBzjfqhPCyb18)
		zzXM2q1ErD = sorted(gQw6uIDP2ksN51rEJyAph4lOSfX,reverse=ksTLSoVGg0ht,key=lambda key: key[hiuZa0PIsErm6UC7].lower())
	else:
		if not tjK6YdAZJT.Im36vznMobP7WCNfFY2lJZ(cdZKMn68Pzg4,IZQbmFzLHDtXfc): return
		if nB3YKPXmCteR5c4FqMphN2izG and SGazRxP3yBKZ15ILuch(u"ࠨࡡࡆࡖࡊࡇࡔࡆࡐࡈ࡛ࡤ࠭Ṱ") not in X9XExg7ect62uBzjfqhPCyb18:
			zzXM2q1ErD = sZHYrLPog4wmuW0ECdc(TV08xYHA2ok,ObuCsdoDtKmhPLSMH8YGan(u"ࠩ࡯࡭ࡸࡺࠧṱ"),rbUkdYi32PJaRtnxhDvQs(u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡏࡐࡕࡘࠪṲ"),J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡉࡑࡖ࡙ࡣࡆࡒࡌࠨṳ"))
		else:
			V92VvyUdWaKumCAkEYZ,zzXM2q1ErD,gQw6uIDP2ksN51rEJyAph4lOSfX = [],[],[]
			for btBA7UjPMk5a49xsKm2RD in range(hiuZa0PIsErm6UC7,d37Zoe1YJgWbMq+hiuZa0PIsErm6UC7):
				zzXM2q1ErD += tNzrMPyRv6iaGVpASC7EcfmZbj(str(btBA7UjPMk5a49xsKm2RD),X9XExg7ect62uBzjfqhPCyb18)
			for type,yy0cNBFOGVZh8rIeQ4,url,HHrpyfWjGC,fh6qmOxoiv1UPXZanLprDeMI8,aOZ3yVnsNlB974pR,JAYWBoz54tGw7O,x8FkISpTrmqPJe2nvZOWU7zuNcj,g8tTFcBGwdKlo42LUkW in zzXM2q1ErD:
				if JAYWBoz54tGw7O not in V92VvyUdWaKumCAkEYZ:
					V92VvyUdWaKumCAkEYZ.append(JAYWBoz54tGw7O)
					MIW9ijJ0w1hFUneT8ZHPagXGlzq = type,yy0cNBFOGVZh8rIeQ4,JAYWBoz54tGw7O,uxE8MyoTRglrcaiQf(u"࠷࠶࠶ὸ"),fh6qmOxoiv1UPXZanLprDeMI8,aOZ3yVnsNlB974pR,X9XExg7ect62uBzjfqhPCyb18,x8FkISpTrmqPJe2nvZOWU7zuNcj,g8tTFcBGwdKlo42LUkW
					gQw6uIDP2ksN51rEJyAph4lOSfX.append(MIW9ijJ0w1hFUneT8ZHPagXGlzq)
			zzXM2q1ErD = sorted(gQw6uIDP2ksN51rEJyAph4lOSfX,reverse=ksTLSoVGg0ht,key=lambda key: key[hiuZa0PIsErm6UC7].lower())
			if nB3YKPXmCteR5c4FqMphN2izG: uAkLQ7gEZaIBv6Fyn(TV08xYHA2ok,AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡊࡒࡗ࡚ࠬṴ"),liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡋࡓࡘ࡛ࡥࡁࡍࡎࠪṵ"),zzXM2q1ErD,jCmv4M3HNPdyaLS)
	USuRxnPlV5.menuItemsLIST[:] = ANclvfeVCGhO28szDLBHyor+zzXM2q1ErD
	XfABsbKWoLhI(ksTLSoVGg0ht)
	return
def vOS2QdgtGZ(e3e5Wr7HPcK6RbEwXTmu,X9XExg7ect62uBzjfqhPCyb18):
	nB3YKPXmCteR5c4FqMphN2izG = ksTLSoVGg0ht
	if nB3YKPXmCteR5c4FqMphN2izG:
		zJLApFBcIhnSj(tRnTydV03Xfi7rbQ(u"ࠧ࡭࡫ࡱ࡯ࠬṶ"),zDek1IW37rq6UoKdwyRiAVpF(u"ࠨฬะำ๏ัࠠใษษ้ฮࠦรใีส้ࠥࡓ࠳ࡖࠩṷ"),cdZKMn68Pzg4,nfg30bHwd4aNV12SR7UjFck(u"࠷࠷࠷ό"),cdZKMn68Pzg4,cdZKMn68Pzg4,ObuCsdoDtKmhPLSMH8YGan(u"ࠩࡢࡇࡗࡋࡁࡕࡇࡑࡉ࡜ࡥࠧṸ"),cdZKMn68Pzg4,{KNomgGw1kdMCBH(u"ࠪࡪࡴࡲࡤࡦࡴࠪṹ"):e3e5Wr7HPcK6RbEwXTmu})
		zJLApFBcIhnSj(S5fhsRT8JV(u"ࠫࡱ࡯࡮࡬ࠩṺ"),Gzygq01Kcb9U3+J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠬࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࠪṻ")+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,Rsdai9xIEPcpuBMKOUwkTA05q(u"࠺࠻࠼࠽ὺ"))
	ANclvfeVCGhO28szDLBHyor = USuRxnPlV5.menuItemsLIST[:]
	import cwOg9mFakl
	if e3e5Wr7HPcK6RbEwXTmu:
		if not cwOg9mFakl.Im36vznMobP7WCNfFY2lJZ(e3e5Wr7HPcK6RbEwXTmu,IZQbmFzLHDtXfc): return
		gQw6uIDP2ksN51rEJyAph4lOSfX = KJ7A5drjqIN8iCB2Pm(e3e5Wr7HPcK6RbEwXTmu,X9XExg7ect62uBzjfqhPCyb18)
		zzXM2q1ErD = sorted(gQw6uIDP2ksN51rEJyAph4lOSfX,reverse=ksTLSoVGg0ht,key=lambda key: key[hiuZa0PIsErm6UC7].lower())
	else:
		if not cwOg9mFakl.Im36vznMobP7WCNfFY2lJZ(cdZKMn68Pzg4,IZQbmFzLHDtXfc): return
		if nB3YKPXmCteR5c4FqMphN2izG and TtyzcuW45VKA(u"࠭࡟ࡄࡔࡈࡅ࡙ࡋࡎࡆ࡙ࡢࠫṼ") not in X9XExg7ect62uBzjfqhPCyb18:
			zzXM2q1ErD = sZHYrLPog4wmuW0ECdc(TV08xYHA2ok,aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠧ࡭࡫ࡶࡸࠬṽ"),On1WZJc6dtksqVNgSQ5GBAjuipe(u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡑ࠸࡛ࠧṾ"),ObuCsdoDtKmhPLSMH8YGan(u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡒ࠹ࡕࡠࡃࡏࡐࠬṿ"))
		else:
			V92VvyUdWaKumCAkEYZ,zzXM2q1ErD,gQw6uIDP2ksN51rEJyAph4lOSfX = [],[],[]
			for btBA7UjPMk5a49xsKm2RD in range(hiuZa0PIsErm6UC7,d37Zoe1YJgWbMq+hiuZa0PIsErm6UC7):
				zzXM2q1ErD += KJ7A5drjqIN8iCB2Pm(str(btBA7UjPMk5a49xsKm2RD),X9XExg7ect62uBzjfqhPCyb18)
			for type,yy0cNBFOGVZh8rIeQ4,url,HHrpyfWjGC,fh6qmOxoiv1UPXZanLprDeMI8,aOZ3yVnsNlB974pR,JAYWBoz54tGw7O,x8FkISpTrmqPJe2nvZOWU7zuNcj,g8tTFcBGwdKlo42LUkW in zzXM2q1ErD:
				if JAYWBoz54tGw7O not in V92VvyUdWaKumCAkEYZ:
					V92VvyUdWaKumCAkEYZ.append(JAYWBoz54tGw7O)
					MIW9ijJ0w1hFUneT8ZHPagXGlzq = type,yy0cNBFOGVZh8rIeQ4,JAYWBoz54tGw7O,aNdix5gq7yeFHTMWhnzm8pX0Y16(u"࠳࠹࠹ύ"),fh6qmOxoiv1UPXZanLprDeMI8,aOZ3yVnsNlB974pR,X9XExg7ect62uBzjfqhPCyb18,x8FkISpTrmqPJe2nvZOWU7zuNcj,g8tTFcBGwdKlo42LUkW
					gQw6uIDP2ksN51rEJyAph4lOSfX.append(MIW9ijJ0w1hFUneT8ZHPagXGlzq)
			zzXM2q1ErD = sorted(gQw6uIDP2ksN51rEJyAph4lOSfX,reverse=ksTLSoVGg0ht,key=lambda key: key[hiuZa0PIsErm6UC7].lower())
			if nB3YKPXmCteR5c4FqMphN2izG: uAkLQ7gEZaIBv6Fyn(TV08xYHA2ok,J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡓ࠳ࡖࠩẀ"),NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡍ࠴ࡗࡢࡅࡑࡒࠧẁ"),zzXM2q1ErD,jCmv4M3HNPdyaLS)
	USuRxnPlV5.menuItemsLIST[:] = ANclvfeVCGhO28szDLBHyor+zzXM2q1ErD
	XfABsbKWoLhI(ksTLSoVGg0ht)
	return
def RSMZ1NhjDoqlQvU7Ey5Bpbxk4XG(group,X9XExg7ect62uBzjfqhPCyb18):
	nB3YKPXmCteR5c4FqMphN2izG = ksTLSoVGg0ht
	xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = []
	zBvrM5IJUXi9xcRQls6dqbZW3FEj = k5oIaYyp2mnrLK49qhzS(u"ࠬࡥࡉࡑࡖ࡙ࡣࠬẂ") if WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"࠭ࡉࡑࡖ࡙ࠫẃ") in X9XExg7ect62uBzjfqhPCyb18 else HC9xWUMpBQJEuTteAqjd(u"ࠧࡠࡏ࠶࡙ࡤ࠭Ẅ")
	if nB3YKPXmCteR5c4FqMphN2izG: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = sZHYrLPog4wmuW0ECdc(TV08xYHA2ok,opyTNwHgfqbZREWKU(u"ࠨ࡮࡬ࡷࡹ࠭ẅ"),TtyzcuW45VKA(u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࠫẆ")+zBvrM5IJUXi9xcRQls6dqbZW3FEj[:-hiuZa0PIsErm6UC7],group)
	if not xsGUcR3ef6glKY5hQwpFXEaSt2mrIz:
		for e3e5Wr7HPcK6RbEwXTmu in range(hiuZa0PIsErm6UC7,d37Zoe1YJgWbMq+hiuZa0PIsErm6UC7):
			if nB3YKPXmCteR5c4FqMphN2izG: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz += sZHYrLPog4wmuW0ECdc(TV08xYHA2ok,On1WZJc6dtksqVNgSQ5GBAjuipe(u"ࠪࡰ࡮ࡹࡴࠨẇ"),NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘ࠭Ẉ")+zBvrM5IJUXi9xcRQls6dqbZW3FEj[:-hiuZa0PIsErm6UC7],opyTNwHgfqbZREWKU(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙ࠧẉ")+zBvrM5IJUXi9xcRQls6dqbZW3FEj+str(e3e5Wr7HPcK6RbEwXTmu))
			elif zBvrM5IJUXi9xcRQls6dqbZW3FEj==zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"࠭࡟ࡊࡒࡗ࡚ࡤ࠭Ẋ"): xsGUcR3ef6glKY5hQwpFXEaSt2mrIz += tNzrMPyRv6iaGVpASC7EcfmZbj(str(e3e5Wr7HPcK6RbEwXTmu),J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠧࡠࡅࡕࡉࡆ࡚ࡅࡏࡇ࡚ࡣࠬẋ"))
			elif zBvrM5IJUXi9xcRQls6dqbZW3FEj==S5fhsRT8JV(u"ࠨࡡࡐ࠷࡚ࡥࠧẌ"): xsGUcR3ef6glKY5hQwpFXEaSt2mrIz += KJ7A5drjqIN8iCB2Pm(str(e3e5Wr7HPcK6RbEwXTmu),xN4fKmsnyM3Y2(u"ࠩࡢࡇࡗࡋࡁࡕࡇࡑࡉ࡜ࡥࠧẍ"))
		for type,yy0cNBFOGVZh8rIeQ4,url,HHrpyfWjGC,fh6qmOxoiv1UPXZanLprDeMI8,aOZ3yVnsNlB974pR,JAYWBoz54tGw7O,x8FkISpTrmqPJe2nvZOWU7zuNcj,g8tTFcBGwdKlo42LUkW in xsGUcR3ef6glKY5hQwpFXEaSt2mrIz:
			if JAYWBoz54tGw7O==group: dH3YIkvnm6NW0oRMO41ybpC(type,yy0cNBFOGVZh8rIeQ4,url,HHrpyfWjGC,fh6qmOxoiv1UPXZanLprDeMI8,aOZ3yVnsNlB974pR,JAYWBoz54tGw7O,x8FkISpTrmqPJe2nvZOWU7zuNcj,g8tTFcBGwdKlo42LUkW)
		items,zaUqdBJDmY = [],[]
		for type,yy0cNBFOGVZh8rIeQ4,url,HHrpyfWjGC,fh6qmOxoiv1UPXZanLprDeMI8,aOZ3yVnsNlB974pR,JAYWBoz54tGw7O,x8FkISpTrmqPJe2nvZOWU7zuNcj,g8tTFcBGwdKlo42LUkW in USuRxnPlV5.menuItemsLIST:
			qqIgLMmNSFV = type,yy0cNBFOGVZh8rIeQ4[iwQJREcVTSe1G2gCvlfhbHWLjqopa:],url,HHrpyfWjGC,fh6qmOxoiv1UPXZanLprDeMI8,aOZ3yVnsNlB974pR,JAYWBoz54tGw7O,x8FkISpTrmqPJe2nvZOWU7zuNcj,cdZKMn68Pzg4
			if qqIgLMmNSFV not in zaUqdBJDmY:
				zaUqdBJDmY.append(qqIgLMmNSFV)
				HYBN2AQsjimSMgT8OvE3ynX67tJwR = type,yy0cNBFOGVZh8rIeQ4,url,HHrpyfWjGC,fh6qmOxoiv1UPXZanLprDeMI8,aOZ3yVnsNlB974pR,JAYWBoz54tGw7O,x8FkISpTrmqPJe2nvZOWU7zuNcj,g8tTFcBGwdKlo42LUkW
				items.append(HYBN2AQsjimSMgT8OvE3ynX67tJwR)
		xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = sorted(items,reverse=ksTLSoVGg0ht,key=lambda key: key[hiuZa0PIsErm6UC7].lower()[opyTNwHgfqbZREWKU(u"࠸ὼ"):])
		if nB3YKPXmCteR5c4FqMphN2izG: uAkLQ7gEZaIBv6Fyn(TV08xYHA2ok,TtyzcuW45VKA(u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࠬẎ")+zBvrM5IJUXi9xcRQls6dqbZW3FEj[:-hiuZa0PIsErm6UC7],group,xsGUcR3ef6glKY5hQwpFXEaSt2mrIz,jCmv4M3HNPdyaLS)
	if f8Ja1q5eO02B(u"ࠫࡤࡘࡁࡏࡆࡒࡑࡤ࠭ẏ") in X9XExg7ect62uBzjfqhPCyb18 and len(xsGUcR3ef6glKY5hQwpFXEaSt2mrIz)>RDjfuZILUYwhx:
		USuRxnPlV5.menuItemsLIST[:] = []
		zJLApFBcIhnSj(dwiIAcPl04ey7Zv38Mz(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬẐ"),k5oIaYyp2mnrLK49qhzS(u"࡛࠭ࠨẑ")+Gzygq01Kcb9U3+group+kH8E2zqNyims6KJfI+nfg30bHwd4aNV12SR7UjFck(u"ࠧࠡ࠼ส่็ูๅ࡞ࠩẒ"),group,dwiIAcPl04ey7Zv38Mz(u"࠵࠻࠻ώ"),cdZKMn68Pzg4,cdZKMn68Pzg4,zBvrM5IJUXi9xcRQls6dqbZW3FEj+AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"ࠨࡡࡕࡅࡓࡊࡏࡎࡡࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧẓ"))
		zJLApFBcIhnSj(WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠩࡩࡳࡱࡪࡥࡳࠩẔ"),rbUkdYi32PJaRtnxhDvQs(u"ࠪษ฾อฯสࠢส่฼๊ศࠡษ็฽ู๎วว์้๋ࠣࠦๆโีࠣห้่ำๆࠩẕ"),group,AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"࠶࠼࠵὾"),cdZKMn68Pzg4,cdZKMn68Pzg4,zBvrM5IJUXi9xcRQls6dqbZW3FEj+HC9xWUMpBQJEuTteAqjd(u"ࠫࡤࡘࡁࡏࡆࡒࡑࡤࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪẖ"))
		zJLApFBcIhnSj(iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠬࡲࡩ࡯࡭ࠪẗ"),Gzygq01Kcb9U3+vbYokBuWlxeLDcdVNM60(u"࠭࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫẘ")+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,ObuCsdoDtKmhPLSMH8YGan(u"࠿࠹࠺࠻὿"))
		xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = USuRxnPlV5.menuItemsLIST+EduRM2WTj7xz1.sample(xsGUcR3ef6glKY5hQwpFXEaSt2mrIz,RDjfuZILUYwhx)
	USuRxnPlV5.menuItemsLIST[:] = xsGUcR3ef6glKY5hQwpFXEaSt2mrIz
	XfABsbKWoLhI(ksTLSoVGg0ht)
	return
def GS0uA5oliq74K(X9XExg7ect62uBzjfqhPCyb18):
	zJLApFBcIhnSj(KNomgGw1kdMCBH(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧẙ"),nfg30bHwd4aNV12SR7UjFck(u"ࠨว฼หิฯุࠠๆหࠤ็์่ศฬࠣ฽ู๎วว์ฬࠫẚ"),cdZKMn68Pzg4,J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"࠱࠷࠳ᾀ"),cdZKMn68Pzg4,cdZKMn68Pzg4,On1WZJc6dtksqVNgSQ5GBAjuipe(u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡍࡋ࡙ࡉ࡙࡜࡟ࡠࡔࡄࡒࡉࡕࡍࡠࠩẛ"))
	zJLApFBcIhnSj(uxE8MyoTRglrcaiQf(u"ࠪࡰ࡮ࡴ࡫ࠨẜ"),Gzygq01Kcb9U3+uxE8MyoTRglrcaiQf(u"ࠫࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡࠩẝ")+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"࠺࠻࠼࠽ᾁ"))
	FLBouiNJczKQw5sHUYEaIm0 = USuRxnPlV5.menuItemsLIST[:]
	USuRxnPlV5.menuItemsLIST[:] = []
	import DhuqxTdFXE
	DhuqxTdFXE.yKvktsG9BnHTge4fVuREIpm83(aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠬ࠶ࠧẞ"),ksTLSoVGg0ht)
	DhuqxTdFXE.yKvktsG9BnHTge4fVuREIpm83(S5fhsRT8JV(u"࠭࠱ࠨẟ"),ksTLSoVGg0ht)
	DhuqxTdFXE.yKvktsG9BnHTge4fVuREIpm83(opyTNwHgfqbZREWKU(u"ࠧ࠳ࠩẠ"),ksTLSoVGg0ht)
	if iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠨࡡࡕࡅࡓࡊࡏࡎࡡࠪạ") in X9XExg7ect62uBzjfqhPCyb18:
		USuRxnPlV5.menuItemsLIST[:] = vA5jFKah9cbX6eiGpTw(USuRxnPlV5.menuItemsLIST)
		if len(USuRxnPlV5.menuItemsLIST)>RDjfuZILUYwhx: USuRxnPlV5.menuItemsLIST[:] = EduRM2WTj7xz1.sample(USuRxnPlV5.menuItemsLIST,RDjfuZILUYwhx)
	USuRxnPlV5.menuItemsLIST[:] = FLBouiNJczKQw5sHUYEaIm0+USuRxnPlV5.menuItemsLIST
	return
def Zy6VvL54w7tBal(X9XExg7ect62uBzjfqhPCyb18):
	X9XExg7ect62uBzjfqhPCyb18 = X9XExg7ect62uBzjfqhPCyb18.replace(zDek1IW37rq6UoKdwyRiAVpF(u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫẢ"),cdZKMn68Pzg4).replace(On1WZJc6dtksqVNgSQ5GBAjuipe(u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧả"),cdZKMn68Pzg4)
	headers = { HC9xWUMpBQJEuTteAqjd(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨẤ") : cdZKMn68Pzg4 }
	url = iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡦࡪࡹࡴࡳࡣࡱࡨࡴࡳࡳ࠯ࡥࡲࡱ࠴ࡸࡡ࡯ࡦࡲࡱ࠲ࡧࡲࡢࡤ࡬ࡧ࠲ࡽ࡯ࡳࡦࡶࠫấ")
	data = {ObuCsdoDtKmhPLSMH8YGan(u"࠭ࡱࡶࡣࡱࡸ࡮ࡺࡹࠨẦ"):WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠧ࠶࠲ࠪầ")}
	data = RV59cpi6BbrlJQuzwCTa(data)
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(qIOfxknj8DiBYboGtQN4v,xN4fKmsnyM3Y2(u"ࠨࡉࡈࡘࠬẨ"),url,data,headers,cdZKMn68Pzg4,cdZKMn68Pzg4,NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠩࡕࡅࡓࡊࡏࡎࡕ࠰ࡖࡆࡔࡄࡐࡏࡢ࡚ࡎࡊࡅࡐࡕࡢࡊࡗࡕࡍࡠ࡙ࡒࡖࡉ࡙࠭࠲ࡵࡷࠫẩ"))
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall(KNomgGw1kdMCBH(u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡧࡴࡴࡴࡦࡰࡷࠦ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤࡦࡰࡪࡧࡲࡧ࡫ࡻࠦࠬẪ"),OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[nnsBpJv6XL3OzHoe4Vuhr]
	items = ffUFBJQ57j2XgoGeOLn9uwpC.findall(zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"ࠫࡁࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡵࡧ࡮࠿࠰࠭ࡃࡁࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡵࡧ࡮࠿ࠩẫ"),KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	ZKp0qslL6zXW8y23vTVBJt4G,cTj01fRxOuH = list(zip(*items))
	LV60nohugWM2Ex = []
	hbKC6mVQgJ9fI = [VBpIH2QSmvDGlA6TO3e,tRnTydV03Xfi7rbQ(u"ࠬࠨࠧẬ"),uxE8MyoTRglrcaiQf(u"࠭ࡠࠨậ"),uxE8MyoTRglrcaiQf(u"ࠧ࠭ࠩẮ"),iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠨ࠰ࠪắ"),f8Ja1q5eO02B(u"ࠩ࠽ࠫẰ"),aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠪ࠿ࠬằ"),f8Ja1q5eO02B(u"ࠦࠬࠨẲ"),YnHG75e2QWwo(u"ࠬ࠳ࠧẳ")]
	UGwMyLzK7VovB162YrAa4ihXc = cTj01fRxOuH+ZKp0qslL6zXW8y23vTVBJt4G
	for DDEG1xIVFBKJ3pvHf in UGwMyLzK7VovB162YrAa4ihXc:
		if DDEG1xIVFBKJ3pvHf in cTj01fRxOuH: XETV19gCQuItq6mA7Wd = bVX3ev1spE
		if DDEG1xIVFBKJ3pvHf in ZKp0qslL6zXW8y23vTVBJt4G: XETV19gCQuItq6mA7Wd = iwQJREcVTSe1G2gCvlfhbHWLjqopa
		J8yYH0PWuU79i = [WCqkctAYD2O3Hz7Fl8fKRS5 in DDEG1xIVFBKJ3pvHf for WCqkctAYD2O3Hz7Fl8fKRS5 in hbKC6mVQgJ9fI]
		if any(J8yYH0PWuU79i):
			OMQouSr6t7xL = J8yYH0PWuU79i.index(IZQbmFzLHDtXfc)
			iF3sVaobhjtXSILcdvk = hbKC6mVQgJ9fI[OMQouSr6t7xL]
			JxN73Z4aWYuBrpMVL = cdZKMn68Pzg4
			if DDEG1xIVFBKJ3pvHf.count(iF3sVaobhjtXSILcdvk)>hiuZa0PIsErm6UC7: z2TC4B6F5dmM8gEUqs,X9DwnLtEVd8yIZ1P,JxN73Z4aWYuBrpMVL = DDEG1xIVFBKJ3pvHf.split(iF3sVaobhjtXSILcdvk,bVX3ev1spE)
			else: z2TC4B6F5dmM8gEUqs,X9DwnLtEVd8yIZ1P = DDEG1xIVFBKJ3pvHf.split(iF3sVaobhjtXSILcdvk,hiuZa0PIsErm6UC7)
			if len(z2TC4B6F5dmM8gEUqs)>XETV19gCQuItq6mA7Wd: LV60nohugWM2Ex.append(z2TC4B6F5dmM8gEUqs.lower())
			if len(X9DwnLtEVd8yIZ1P)>XETV19gCQuItq6mA7Wd: LV60nohugWM2Ex.append(X9DwnLtEVd8yIZ1P.lower())
			if len(JxN73Z4aWYuBrpMVL)>XETV19gCQuItq6mA7Wd: LV60nohugWM2Ex.append(JxN73Z4aWYuBrpMVL.lower())
		elif len(DDEG1xIVFBKJ3pvHf)>XETV19gCQuItq6mA7Wd: LV60nohugWM2Ex.append(DDEG1xIVFBKJ3pvHf.lower())
	for WCqkctAYD2O3Hz7Fl8fKRS5 in range(YnHG75e2QWwo(u"࠻ᾂ")): EduRM2WTj7xz1.shuffle(LV60nohugWM2Ex)
	if zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"࠭࡟ࡔࡋࡗࡉࡘࡥࠧẴ") in X9XExg7ect62uBzjfqhPCyb18:
		vdf8l2sjCLa0WzwQoGX7Z1kJU = RgmY38c0XdHUK1CVwqQ7orZ
	elif SGazRxP3yBKZ15ILuch(u"ࠧࡠࡋࡓࡘ࡛ࡥࠧẵ") in X9XExg7ect62uBzjfqhPCyb18:
		vdf8l2sjCLa0WzwQoGX7Z1kJU = [Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠨࡋࡓࡘ࡛࠭Ặ")]
		import tjK6YdAZJT
		if not tjK6YdAZJT.Im36vznMobP7WCNfFY2lJZ(cdZKMn68Pzg4,IZQbmFzLHDtXfc): return
	elif zDek1IW37rq6UoKdwyRiAVpF(u"ࠩࡢࡑ࠸࡛࡟ࠨặ") in X9XExg7ect62uBzjfqhPCyb18:
		vdf8l2sjCLa0WzwQoGX7Z1kJU = [AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"ࠪࡑ࠸࡛ࠧẸ")]
		import cwOg9mFakl
		if not cwOg9mFakl.Im36vznMobP7WCNfFY2lJZ(cdZKMn68Pzg4,IZQbmFzLHDtXfc): return
	count,psQyJo2qj4niVS6axIeEH = nnsBpJv6XL3OzHoe4Vuhr,nnsBpJv6XL3OzHoe4Vuhr
	zJLApFBcIhnSj(AiCor1fIVTDxQUWwHe9vPR7(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫẹ"),WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠬࡡࠠࠡ࡟ࠣ࠾ฬ๊ศฮอࠣ฽๋࠭Ẻ"),cdZKMn68Pzg4,S5fhsRT8JV(u"࠴࠺࠹ᾃ"),cdZKMn68Pzg4,cdZKMn68Pzg4,iRfoNckJs7Ibxzh5j92w8DSWF(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫẻ")+X9XExg7ect62uBzjfqhPCyb18)
	zJLApFBcIhnSj(AiCor1fIVTDxQUWwHe9vPR7(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧẼ"),aar0zhDnJsOTP7EdgR16HIS29(u"ࠨว฼หิฯࠠศๆหัะࠦวๅ฻ื์ฬฬ๊ࠨẽ"),cdZKMn68Pzg4,opyTNwHgfqbZREWKU(u"࠵࠻࠺ᾄ"),cdZKMn68Pzg4,cdZKMn68Pzg4,opyTNwHgfqbZREWKU(u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧẾ")+X9XExg7ect62uBzjfqhPCyb18)
	zJLApFBcIhnSj(aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠪࡰ࡮ࡴ࡫ࠨế"),Gzygq01Kcb9U3+aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠫࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡࠩỀ")+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,YnHG75e2QWwo(u"࠾࠿࠹࠺ᾅ"))
	XwJa3R47piCuS = USuRxnPlV5.menuItemsLIST[:]
	USuRxnPlV5.menuItemsLIST[:] = []
	HpEu9MkjbNicD = []
	for DDEG1xIVFBKJ3pvHf in LV60nohugWM2Ex:
		X9DwnLtEVd8yIZ1P = ffUFBJQ57j2XgoGeOLn9uwpC.findall(uxE8MyoTRglrcaiQf(u"ࠬࡡࠠ࡝࠮࡟࠿ࡡࡀ࡜࠮࡞࠮ࡠࡂࡢࠢ࡝ࠩ࡟࡟ࡡࡣ࡜ࠩ࡞ࠬࡠࢀࡢࡽ࡝ࠣ࡟ࡄࠬề")+xN4fKmsnyM3Y2(u"࠭ࠣࠨỂ")+liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠧ࡝ࠦ࡟ࠩࡡࡤ࡜ࠧ࡞࠭ࡠࡤࡢ࠼࡝ࡀࡠࠫể"),DDEG1xIVFBKJ3pvHf,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if X9DwnLtEVd8yIZ1P: DDEG1xIVFBKJ3pvHf = DDEG1xIVFBKJ3pvHf.split(X9DwnLtEVd8yIZ1P[nnsBpJv6XL3OzHoe4Vuhr],hiuZa0PIsErm6UC7)[nnsBpJv6XL3OzHoe4Vuhr]
		SEhXKpdHzxN8fDRP0clwjCVAuIe = DDEG1xIVFBKJ3pvHf.replace(SGazRxP3yBKZ15ILuch(u"ࠨ๓ࠪỄ"),cdZKMn68Pzg4).replace(J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠩ๑ࠫễ"),cdZKMn68Pzg4).replace(s8fcjBCSMxzAIkZQbJPga(u"ࠪ๏ࠬỆ"),cdZKMn68Pzg4).replace(opyTNwHgfqbZREWKU(u"ࠫ๔࠭ệ"),cdZKMn68Pzg4).replace(vbYokBuWlxeLDcdVNM60(u"ࠬ๒ࠧỈ"),cdZKMn68Pzg4)
		SEhXKpdHzxN8fDRP0clwjCVAuIe = SEhXKpdHzxN8fDRP0clwjCVAuIe.replace(TtyzcuW45VKA(u"࠭๐ࠨỉ"),cdZKMn68Pzg4).replace(liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠧ๎ࠩỊ"),cdZKMn68Pzg4).replace(LungQF89BqemOb32jJsZlW(u"ࠨ๔ࠪị"),cdZKMn68Pzg4).replace(liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠩฏࠫỌ"),cdZKMn68Pzg4).replace(AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"ࠪไࠬọ"),cdZKMn68Pzg4)
		if SEhXKpdHzxN8fDRP0clwjCVAuIe: HpEu9MkjbNicD.append(SEhXKpdHzxN8fDRP0clwjCVAuIe)
	n4H9QcPqvAtikVRy = []
	for DXAlBvH2ITZoyunMU0Rq3pw7sx in range(nnsBpJv6XL3OzHoe4Vuhr,ObuCsdoDtKmhPLSMH8YGan(u"࠸࠰ᾆ")):
		search = EduRM2WTj7xz1.sample(HpEu9MkjbNicD,hiuZa0PIsErm6UC7)[nnsBpJv6XL3OzHoe4Vuhr]
		if search in n4H9QcPqvAtikVRy: continue
		n4H9QcPqvAtikVRy.append(search)
		xgPSaoLzTlFtQD37M6HIEsWY = EduRM2WTj7xz1.sample(vdf8l2sjCLa0WzwQoGX7Z1kJU,hiuZa0PIsErm6UC7)[nnsBpJv6XL3OzHoe4Vuhr]
		SsziMZd5UbeL2NRxVpwjO(F0FeocLXmbJhdBwQnS18PCHZIU,xxd7Xp5lvem(UkXlAzsMcamKJrEIgnxi6bWh)+WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠫࠥࠦࠠࡓࡣࡱࡨࡴࡳࠠࡗ࡫ࡧࡩࡴࠦࡓࡦࡣࡵࡧ࡭ࠦࠠࠡࡵ࡬ࡸࡪࡀࠧỎ")+str(xgPSaoLzTlFtQD37M6HIEsWY)+AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"ࠬࠦࠠࡴࡧࡤࡶࡨ࡮࠺ࠨỏ")+search)
		EsoNPCTO6a243HIqXh0R,KIOap9Wsnru,tcDxzmPhwuVGE9ls0n6g = hhHQ695ZrMo2bFnIJqt(xgPSaoLzTlFtQD37M6HIEsWY)
		KIOap9Wsnru(search+AiCor1fIVTDxQUWwHe9vPR7(u"࠭࡟ࡏࡑࡇࡍࡆࡒࡏࡈࡕࡢࠫỐ"))
		if len(USuRxnPlV5.menuItemsLIST)>nnsBpJv6XL3OzHoe4Vuhr: break
	search = search.replace(k5oIaYyp2mnrLK49qhzS(u"ࠧࡠࡏࡒࡈࡤ࠭ố"),cdZKMn68Pzg4)
	XwJa3R47piCuS[nnsBpJv6XL3OzHoe4Vuhr][hiuZa0PIsErm6UC7] = J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠨ࡝ࠪỒ")+Gzygq01Kcb9U3+search+kH8E2zqNyims6KJfI+SGazRxP3yBKZ15ILuch(u"ࠩࠣ࠾อำหࠡ฻้ࡡࠬồ")
	USuRxnPlV5.menuItemsLIST[:] = vA5jFKah9cbX6eiGpTw(USuRxnPlV5.menuItemsLIST)
	if len(USuRxnPlV5.menuItemsLIST)>RDjfuZILUYwhx: USuRxnPlV5.menuItemsLIST[:] = EduRM2WTj7xz1.sample(USuRxnPlV5.menuItemsLIST,RDjfuZILUYwhx)
	USuRxnPlV5.menuItemsLIST[:] = XwJa3R47piCuS+USuRxnPlV5.menuItemsLIST
	return
def wfXezL8AxmIrY7tKh1H5jSuc2F4v3(HRNoOjcIt0zSqKQxBpYPyGeTFJAv,X9XExg7ect62uBzjfqhPCyb18):
	HRNoOjcIt0zSqKQxBpYPyGeTFJAv = HRNoOjcIt0zSqKQxBpYPyGeTFJAv.replace(dwiIAcPl04ey7Zv38Mz(u"ࠪࡣࡒࡕࡄࡠࠩỔ"),cdZKMn68Pzg4)
	X9XExg7ect62uBzjfqhPCyb18 = X9XExg7ect62uBzjfqhPCyb18.replace(ObuCsdoDtKmhPLSMH8YGan(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭ổ"),cdZKMn68Pzg4).replace(nfg30bHwd4aNV12SR7UjFck(u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩỖ"),cdZKMn68Pzg4)
	a2u7fFRVJ1TxUBj9e6NsOdXy4l5hC(ksTLSoVGg0ht)
	if not p1aOI2dPBNz9wm7uF56S: return
	if WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"࠭࡟ࡓࡃࡑࡈࡔࡓ࡟ࠨỗ") in X9XExg7ect62uBzjfqhPCyb18:
		zJLApFBcIhnSj(HC9xWUMpBQJEuTteAqjd(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧỘ"),Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠨ࡝ࠪộ")+Gzygq01Kcb9U3+HRNoOjcIt0zSqKQxBpYPyGeTFJAv+kH8E2zqNyims6KJfI+Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠩࠣ࠾ฬ๊โิ็ࡠࠫỚ"),HRNoOjcIt0zSqKQxBpYPyGeTFJAv,tRnTydV03Xfi7rbQ(u"࠱࠷࠸ᾇ"),cdZKMn68Pzg4,cdZKMn68Pzg4,f8Ja1q5eO02B(u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨớ")+X9XExg7ect62uBzjfqhPCyb18)
		zJLApFBcIhnSj(HC9xWUMpBQJEuTteAqjd(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫỜ"),S5fhsRT8JV(u"ࠬหูศัฬࠤฬ๊ืๅสࠣห้฿ิ้ษษ๎๋ࠥๆ่ࠡไืࠥอไใี่ࠫờ"),HRNoOjcIt0zSqKQxBpYPyGeTFJAv,nfg30bHwd4aNV12SR7UjFck(u"࠲࠸࠹ᾈ"),cdZKMn68Pzg4,cdZKMn68Pzg4,KNomgGw1kdMCBH(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫỞ")+X9XExg7ect62uBzjfqhPCyb18)
		zJLApFBcIhnSj(rbUkdYi32PJaRtnxhDvQs(u"ࠧ࡭࡫ࡱ࡯ࠬở"),Gzygq01Kcb9U3+zDek1IW37rq6UoKdwyRiAVpF(u"ࠨ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥ࠭Ỡ")+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"࠻࠼࠽࠾ᾉ"))
	for website in sorted(list(p1aOI2dPBNz9wm7uF56S[HRNoOjcIt0zSqKQxBpYPyGeTFJAv].keys())):
		kuMXTLrvIZGfjCDtA9YNJ5SxQK,yy0cNBFOGVZh8rIeQ4,url,tvo4ZrLBKs3fTMJ9kqb1CxR8W6,fh6qmOxoiv1UPXZanLprDeMI8,aOZ3yVnsNlB974pR,JAYWBoz54tGw7O,x8FkISpTrmqPJe2nvZOWU7zuNcj,g8tTFcBGwdKlo42LUkW = p1aOI2dPBNz9wm7uF56S[HRNoOjcIt0zSqKQxBpYPyGeTFJAv][website]
		if HC9xWUMpBQJEuTteAqjd(u"ࠩࡢࡖࡆࡔࡄࡐࡏࡢࠫỡ") in X9XExg7ect62uBzjfqhPCyb18 or len(p1aOI2dPBNz9wm7uF56S[HRNoOjcIt0zSqKQxBpYPyGeTFJAv])==hiuZa0PIsErm6UC7:
			dH3YIkvnm6NW0oRMO41ybpC(kuMXTLrvIZGfjCDtA9YNJ5SxQK,cdZKMn68Pzg4,url,tvo4ZrLBKs3fTMJ9kqb1CxR8W6,cdZKMn68Pzg4,aOZ3yVnsNlB974pR,JAYWBoz54tGw7O,cdZKMn68Pzg4,cdZKMn68Pzg4)
			USuRxnPlV5.menuItemsLIST[:] = vA5jFKah9cbX6eiGpTw(USuRxnPlV5.menuItemsLIST)
			ANclvfeVCGhO28szDLBHyor,zzXM2q1ErD = USuRxnPlV5.menuItemsLIST[:kzoASbNraPcfgvWJmY9Qu],USuRxnPlV5.menuItemsLIST[kzoASbNraPcfgvWJmY9Qu:]
			if WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠪࡣࡗࡇࡎࡅࡑࡐࡣࠬỢ") in X9XExg7ect62uBzjfqhPCyb18:
				for WCqkctAYD2O3Hz7Fl8fKRS5 in range(vbYokBuWlxeLDcdVNM60(u"࠼ᾊ")): EduRM2WTj7xz1.shuffle(zzXM2q1ErD)
				USuRxnPlV5.menuItemsLIST[:] = ANclvfeVCGhO28szDLBHyor+zzXM2q1ErD[:RDjfuZILUYwhx]
			else: USuRxnPlV5.menuItemsLIST[:] = ANclvfeVCGhO28szDLBHyor+zzXM2q1ErD
		elif k5oIaYyp2mnrLK49qhzS(u"ࠫࡤ࡙ࡉࡕࡇࡖࡣࠬợ") in X9XExg7ect62uBzjfqhPCyb18: zJLApFBcIhnSj(On1WZJc6dtksqVNgSQ5GBAjuipe(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬỤ"),website,url,tvo4ZrLBKs3fTMJ9kqb1CxR8W6,fh6qmOxoiv1UPXZanLprDeMI8,aOZ3yVnsNlB974pR,JAYWBoz54tGw7O,x8FkISpTrmqPJe2nvZOWU7zuNcj,g8tTFcBGwdKlo42LUkW)
	return
def JgaTNOGC8V2k7nmfqBW0rs(X9XExg7ect62uBzjfqhPCyb18,HHrpyfWjGC):
	X9XExg7ect62uBzjfqhPCyb18 = X9XExg7ect62uBzjfqhPCyb18.replace(iRfoNckJs7Ibxzh5j92w8DSWF(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨụ"),cdZKMn68Pzg4).replace(TtyzcuW45VKA(u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫỦ"),cdZKMn68Pzg4)
	yy0cNBFOGVZh8rIeQ4,zzXM2q1ErD = cdZKMn68Pzg4,[]
	zJLApFBcIhnSj(liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨủ"),NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠩ࡞ࠫỨ")+Gzygq01Kcb9U3+yy0cNBFOGVZh8rIeQ4+kH8E2zqNyims6KJfI+vbYokBuWlxeLDcdVNM60(u"ࠪࠤ࠿อไใี่ࡡࠬứ"),cdZKMn68Pzg4,HHrpyfWjGC,cdZKMn68Pzg4,cdZKMn68Pzg4,S5fhsRT8JV(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩỪ")+X9XExg7ect62uBzjfqhPCyb18)
	zJLApFBcIhnSj(tRnTydV03Xfi7rbQ(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬừ"),liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"࠭ลฺษาอࠥ฽ไษࠢๅืู๊ࠦี๊สส๏࠭Ử"),cdZKMn68Pzg4,HHrpyfWjGC,cdZKMn68Pzg4,cdZKMn68Pzg4,tRnTydV03Xfi7rbQ(u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬử")+X9XExg7ect62uBzjfqhPCyb18)
	zJLApFBcIhnSj(f8Ja1q5eO02B(u"ࠨ࡮࡬ࡲࡰ࠭Ữ"),Gzygq01Kcb9U3+iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠩࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦࠧữ")+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,opyTNwHgfqbZREWKU(u"࠽࠾࠿࠹ᾋ"))
	ANclvfeVCGhO28szDLBHyor = USuRxnPlV5.menuItemsLIST[:]
	USuRxnPlV5.menuItemsLIST[:] = []
	xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = []
	if LJPOQNK1mcG(u"ࠪࡣࡘࡏࡔࡆࡕࡢࠫỰ") in X9XExg7ect62uBzjfqhPCyb18:
		a2u7fFRVJ1TxUBj9e6NsOdXy4l5hC(ksTLSoVGg0ht)
		if not p1aOI2dPBNz9wm7uF56S: return
		tm20eIwub3SLoURM14z = list(p1aOI2dPBNz9wm7uF56S.keys())
		HRNoOjcIt0zSqKQxBpYPyGeTFJAv = EduRM2WTj7xz1.sample(tm20eIwub3SLoURM14z,hiuZa0PIsErm6UC7)[nnsBpJv6XL3OzHoe4Vuhr]
		LV60nohugWM2Ex = list(p1aOI2dPBNz9wm7uF56S[HRNoOjcIt0zSqKQxBpYPyGeTFJAv].keys())
		website = EduRM2WTj7xz1.sample(LV60nohugWM2Ex,hiuZa0PIsErm6UC7)[nnsBpJv6XL3OzHoe4Vuhr]
		kuMXTLrvIZGfjCDtA9YNJ5SxQK,yy0cNBFOGVZh8rIeQ4,url,tvo4ZrLBKs3fTMJ9kqb1CxR8W6,fh6qmOxoiv1UPXZanLprDeMI8,aOZ3yVnsNlB974pR,JAYWBoz54tGw7O,x8FkISpTrmqPJe2nvZOWU7zuNcj,g8tTFcBGwdKlo42LUkW = p1aOI2dPBNz9wm7uF56S[HRNoOjcIt0zSqKQxBpYPyGeTFJAv][website]
		SsziMZd5UbeL2NRxVpwjO(F0FeocLXmbJhdBwQnS18PCHZIU,xxd7Xp5lvem(UkXlAzsMcamKJrEIgnxi6bWh)+nfg30bHwd4aNV12SR7UjFck(u"ࠫࠥࠦࠠࡓࡣࡱࡨࡴࡳࠠࡄࡣࡷࡩ࡬ࡵࡲࡺࠢࠣࠤࡼ࡫ࡢࡴ࡫ࡷࡩ࠿ࠦࠧự")+website+uxE8MyoTRglrcaiQf(u"ࠬࠦࠠࠡࡰࡤࡱࡪࡀࠠࠨỲ")+yy0cNBFOGVZh8rIeQ4+iRfoNckJs7Ibxzh5j92w8DSWF(u"࠭ࠠࠡࠢࡸࡶࡱࡀࠠࠨỳ")+url+Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠧࠡࠢࠣࡱࡴࡪࡥ࠻ࠢࠪỴ")+str(tvo4ZrLBKs3fTMJ9kqb1CxR8W6))
	elif YnHG75e2QWwo(u"ࠨࡡࡌࡔ࡙࡜࡟ࠨỵ") in X9XExg7ect62uBzjfqhPCyb18:
		import tjK6YdAZJT
		if not tjK6YdAZJT.Im36vznMobP7WCNfFY2lJZ(cdZKMn68Pzg4,IZQbmFzLHDtXfc): return
		for e3e5Wr7HPcK6RbEwXTmu in range(hiuZa0PIsErm6UC7,d37Zoe1YJgWbMq+hiuZa0PIsErm6UC7):
			xsGUcR3ef6glKY5hQwpFXEaSt2mrIz += tNzrMPyRv6iaGVpASC7EcfmZbj(str(e3e5Wr7HPcK6RbEwXTmu),X9XExg7ect62uBzjfqhPCyb18)
		if not xsGUcR3ef6glKY5hQwpFXEaSt2mrIz: return
		kuMXTLrvIZGfjCDtA9YNJ5SxQK,yy0cNBFOGVZh8rIeQ4,url,tvo4ZrLBKs3fTMJ9kqb1CxR8W6,fh6qmOxoiv1UPXZanLprDeMI8,aOZ3yVnsNlB974pR,JAYWBoz54tGw7O,x8FkISpTrmqPJe2nvZOWU7zuNcj,g8tTFcBGwdKlo42LUkW = EduRM2WTj7xz1.sample(xsGUcR3ef6glKY5hQwpFXEaSt2mrIz,hiuZa0PIsErm6UC7)[nnsBpJv6XL3OzHoe4Vuhr]
		SsziMZd5UbeL2NRxVpwjO(F0FeocLXmbJhdBwQnS18PCHZIU,xxd7Xp5lvem(UkXlAzsMcamKJrEIgnxi6bWh)+k5oIaYyp2mnrLK49qhzS(u"ࠩࠣࠤࠥࡘࡡ࡯ࡦࡲࡱࠥࡉࡡࡵࡧࡪࡳࡷࡿࠠࠡࠢࡱࡥࡲ࡫࠺ࠡࠩỶ")+yy0cNBFOGVZh8rIeQ4+HC9xWUMpBQJEuTteAqjd(u"ࠪࠤࠥࠦࡵࡳ࡮࠽ࠤࠬỷ")+url+vbYokBuWlxeLDcdVNM60(u"ࠫࠥࠦࠠ࡮ࡱࡧࡩ࠿ࠦࠧỸ")+str(tvo4ZrLBKs3fTMJ9kqb1CxR8W6))
	elif ObuCsdoDtKmhPLSMH8YGan(u"ࠬࡥࡍ࠴ࡗࡢࠫỹ") in X9XExg7ect62uBzjfqhPCyb18:
		import cwOg9mFakl
		if not cwOg9mFakl.Im36vznMobP7WCNfFY2lJZ(cdZKMn68Pzg4,IZQbmFzLHDtXfc): return
		for e3e5Wr7HPcK6RbEwXTmu in range(hiuZa0PIsErm6UC7,d37Zoe1YJgWbMq+hiuZa0PIsErm6UC7):
			xsGUcR3ef6glKY5hQwpFXEaSt2mrIz += KJ7A5drjqIN8iCB2Pm(str(e3e5Wr7HPcK6RbEwXTmu),X9XExg7ect62uBzjfqhPCyb18)
		if not xsGUcR3ef6glKY5hQwpFXEaSt2mrIz: return
		kuMXTLrvIZGfjCDtA9YNJ5SxQK,yy0cNBFOGVZh8rIeQ4,url,tvo4ZrLBKs3fTMJ9kqb1CxR8W6,fh6qmOxoiv1UPXZanLprDeMI8,aOZ3yVnsNlB974pR,JAYWBoz54tGw7O,x8FkISpTrmqPJe2nvZOWU7zuNcj,g8tTFcBGwdKlo42LUkW = EduRM2WTj7xz1.sample(xsGUcR3ef6glKY5hQwpFXEaSt2mrIz,hiuZa0PIsErm6UC7)[nnsBpJv6XL3OzHoe4Vuhr]
		SsziMZd5UbeL2NRxVpwjO(F0FeocLXmbJhdBwQnS18PCHZIU,xxd7Xp5lvem(UkXlAzsMcamKJrEIgnxi6bWh)+nfg30bHwd4aNV12SR7UjFck(u"࠭ࠠࠡࠢࡕࡥࡳࡪ࡯࡮ࠢࡆࡥࡹ࡫ࡧࡰࡴࡼࠤࠥࠦ࡮ࡢ࡯ࡨ࠾ࠥ࠭Ỻ")+yy0cNBFOGVZh8rIeQ4+ObuCsdoDtKmhPLSMH8YGan(u"ࠧࠡࠢࠣࡹࡷࡲ࠺ࠡࠩỻ")+url+NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠨࠢࠣࠤࡲࡵࡤࡦ࠼ࠣࠫỼ")+str(tvo4ZrLBKs3fTMJ9kqb1CxR8W6))
	aMzIR6Qk89TmuDiUq = yy0cNBFOGVZh8rIeQ4
	W9HVtrK73q8Isb0DfoMBTQXdY = []
	for WCqkctAYD2O3Hz7Fl8fKRS5 in range(nnsBpJv6XL3OzHoe4Vuhr,On1WZJc6dtksqVNgSQ5GBAjuipe(u"࠶࠶ᾌ")):
		if WCqkctAYD2O3Hz7Fl8fKRS5>nnsBpJv6XL3OzHoe4Vuhr: SsziMZd5UbeL2NRxVpwjO(F0FeocLXmbJhdBwQnS18PCHZIU,xxd7Xp5lvem(UkXlAzsMcamKJrEIgnxi6bWh)+zDek1IW37rq6UoKdwyRiAVpF(u"ࠩࠣࠤࠥࡘࡡ࡯ࡦࡲࡱࠥࡉࡡࡵࡧࡪࡳࡷࡿࠠࠡࠢࡱࡥࡲ࡫࠺ࠡࠩỽ")+yy0cNBFOGVZh8rIeQ4+s8fcjBCSMxzAIkZQbJPga(u"ࠪࠤࠥࠦࡵࡳ࡮࠽ࠤࠬỾ")+url+YnHG75e2QWwo(u"ࠫࠥࠦࠠ࡮ࡱࡧࡩ࠿ࠦࠧỿ")+str(tvo4ZrLBKs3fTMJ9kqb1CxR8W6))
		USuRxnPlV5.menuItemsLIST[:] = []
		if tvo4ZrLBKs3fTMJ9kqb1CxR8W6==LungQF89BqemOb32jJsZlW(u"࠸࠳࠵ᾍ") and SGazRxP3yBKZ15ILuch(u"ࠬࡥ࡟ࡊࡒࡗ࡚ࡘ࡫ࡲࡪࡧࡶࡣࡤ࠭ἀ") in JAYWBoz54tGw7O: tvo4ZrLBKs3fTMJ9kqb1CxR8W6 = AiCor1fIVTDxQUWwHe9vPR7(u"࠲࠴࠵ᾎ")
		if tvo4ZrLBKs3fTMJ9kqb1CxR8W6==WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"࠸࠳࠷ᾏ") and opyTNwHgfqbZREWKU(u"࠭࡟ࡠࡏ࠶࡙ࡘ࡫ࡲࡪࡧࡶࡣࡤ࠭ἁ") in JAYWBoz54tGw7O: tvo4ZrLBKs3fTMJ9kqb1CxR8W6 = WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"࠹࠴࠷ᾐ")
		if tvo4ZrLBKs3fTMJ9kqb1CxR8W6==uxE8MyoTRglrcaiQf(u"࠴࠸࠹ᾑ"): tvo4ZrLBKs3fTMJ9kqb1CxR8W6 = aNdix5gq7yeFHTMWhnzm8pX0Y16(u"࠶࠾࠷ᾒ")
		tYPfm3ISxD = dH3YIkvnm6NW0oRMO41ybpC(kuMXTLrvIZGfjCDtA9YNJ5SxQK,yy0cNBFOGVZh8rIeQ4,url,tvo4ZrLBKs3fTMJ9kqb1CxR8W6,fh6qmOxoiv1UPXZanLprDeMI8,aOZ3yVnsNlB974pR,JAYWBoz54tGw7O,x8FkISpTrmqPJe2nvZOWU7zuNcj,g8tTFcBGwdKlo42LUkW)
		if ObuCsdoDtKmhPLSMH8YGan(u"ࠧࡠࡋࡓࡘ࡛ࡥࠧἂ") in X9XExg7ect62uBzjfqhPCyb18 and tvo4ZrLBKs3fTMJ9kqb1CxR8W6==zDek1IW37rq6UoKdwyRiAVpF(u"࠶࠼࠷ᾓ"): del USuRxnPlV5.menuItemsLIST[:kzoASbNraPcfgvWJmY9Qu]
		if uxE8MyoTRglrcaiQf(u"ࠨࡡࡐ࠷࡚ࡥࠧἃ") in X9XExg7ect62uBzjfqhPCyb18 and tvo4ZrLBKs3fTMJ9kqb1CxR8W6==aar0zhDnJsOTP7EdgR16HIS29(u"࠷࠶࠹ᾔ"): del USuRxnPlV5.menuItemsLIST[:kzoASbNraPcfgvWJmY9Qu]
		zzXM2q1ErD[:] = vA5jFKah9cbX6eiGpTw(USuRxnPlV5.menuItemsLIST)
		if W9HVtrK73q8Isb0DfoMBTQXdY and VWC0FPRg21pTjI5K3ZEtcXxlA(AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"ࡷࠪั้่ษࠨἄ")) in str(zzXM2q1ErD) or VWC0FPRg21pTjI5K3ZEtcXxlA(rbUkdYi32PJaRtnxhDvQs(u"ࡸࠫา๊โ่ࠩἅ")) in str(zzXM2q1ErD):
			yy0cNBFOGVZh8rIeQ4 = aMzIR6Qk89TmuDiUq
			zzXM2q1ErD[:] = W9HVtrK73q8Isb0DfoMBTQXdY
			break
		aMzIR6Qk89TmuDiUq = yy0cNBFOGVZh8rIeQ4
		W9HVtrK73q8Isb0DfoMBTQXdY = zzXM2q1ErD
		if str(zzXM2q1ErD).count(opyTNwHgfqbZREWKU(u"ࠫࡻ࡯ࡤࡦࡱࠪἆ"))>nnsBpJv6XL3OzHoe4Vuhr: break
		if str(zzXM2q1ErD).count(uxE8MyoTRglrcaiQf(u"ࠬࡲࡩࡷࡧࠪἇ"))>nnsBpJv6XL3OzHoe4Vuhr: break
		if tvo4ZrLBKs3fTMJ9kqb1CxR8W6==SGazRxP3yBKZ15ILuch(u"࠲࠴࠵ᾕ"): break
		if tvo4ZrLBKs3fTMJ9kqb1CxR8W6==aNdix5gq7yeFHTMWhnzm8pX0Y16(u"࠸࠳࠶ᾖ"): break
		if tvo4ZrLBKs3fTMJ9kqb1CxR8W6==dwiIAcPl04ey7Zv38Mz(u"࠴࠼࠵ᾗ"): break
		if SGazRxP3yBKZ15ILuch(u"࠭࡟ࡓࡃࡑࡈࡔࡓ࡟ࠨἈ") in X9XExg7ect62uBzjfqhPCyb18 and zzXM2q1ErD: kuMXTLrvIZGfjCDtA9YNJ5SxQK,yy0cNBFOGVZh8rIeQ4,url,tvo4ZrLBKs3fTMJ9kqb1CxR8W6,fh6qmOxoiv1UPXZanLprDeMI8,aOZ3yVnsNlB974pR,JAYWBoz54tGw7O,x8FkISpTrmqPJe2nvZOWU7zuNcj,g8tTFcBGwdKlo42LUkW = EduRM2WTj7xz1.sample(zzXM2q1ErD,hiuZa0PIsErm6UC7)[nnsBpJv6XL3OzHoe4Vuhr]
	if not yy0cNBFOGVZh8rIeQ4: yy0cNBFOGVZh8rIeQ4 = SGazRxP3yBKZ15ILuch(u"ࠧ࠯࠰࠱࠲ࠬἉ")
	elif yy0cNBFOGVZh8rIeQ4.count(J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠨࡡࠪἊ"))>hiuZa0PIsErm6UC7: yy0cNBFOGVZh8rIeQ4 = yy0cNBFOGVZh8rIeQ4.split(aar0zhDnJsOTP7EdgR16HIS29(u"ࠩࡢࠫἋ"),bVX3ev1spE)[bVX3ev1spE]
	yy0cNBFOGVZh8rIeQ4 = yy0cNBFOGVZh8rIeQ4.replace(S5fhsRT8JV(u"࡙ࠪࡓࡑࡎࡐ࡙ࡑ࠾ࠥ࠭Ἄ"),cdZKMn68Pzg4)
	yy0cNBFOGVZh8rIeQ4 = yy0cNBFOGVZh8rIeQ4.replace(xN4fKmsnyM3Y2(u"ࠫࡤࡓࡏࡅࡡࠪἍ"),cdZKMn68Pzg4)
	ANclvfeVCGhO28szDLBHyor[nnsBpJv6XL3OzHoe4Vuhr][hiuZa0PIsErm6UC7] = AiCor1fIVTDxQUWwHe9vPR7(u"ࠬࡡࠧἎ")+Gzygq01Kcb9U3+yy0cNBFOGVZh8rIeQ4+kH8E2zqNyims6KJfI+liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"࠭ࠠ࠻ษ็ๆุ๋࡝ࠨἏ")
	if liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠧࡠࡔࡄࡒࡉࡕࡍࡠࠩἐ") in X9XExg7ect62uBzjfqhPCyb18:
		for WCqkctAYD2O3Hz7Fl8fKRS5 in range(WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"࠼ᾘ")): EduRM2WTj7xz1.shuffle(zzXM2q1ErD)
		USuRxnPlV5.menuItemsLIST[:] = ANclvfeVCGhO28szDLBHyor+zzXM2q1ErD[:RDjfuZILUYwhx]
	else: USuRxnPlV5.menuItemsLIST[:] = ANclvfeVCGhO28szDLBHyor+zzXM2q1ErD
	return
def LgqhlWACEIxdGpf5TYOPsUNi173K(hUe1QdzicSIN,c3EZrqLkshKCJn0byXAGmfDTQN):
	c3EZrqLkshKCJn0byXAGmfDTQN = c3EZrqLkshKCJn0byXAGmfDTQN.replace(zDek1IW37rq6UoKdwyRiAVpF(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪἑ"),cdZKMn68Pzg4).replace(uxE8MyoTRglrcaiQf(u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ἒ"),cdZKMn68Pzg4)
	Q9pr7YKmZny8V5ifEugGWI = c3EZrqLkshKCJn0byXAGmfDTQN
	if aar0zhDnJsOTP7EdgR16HIS29(u"ࠪࡣࡤࡏࡐࡕࡘࡖࡩࡷ࡯ࡥࡴࡡࡢࠫἓ") in c3EZrqLkshKCJn0byXAGmfDTQN:
		Q9pr7YKmZny8V5ifEugGWI = c3EZrqLkshKCJn0byXAGmfDTQN.split(J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠫࡤࡥࡉࡑࡖ࡙ࡗࡪࡸࡩࡦࡵࡢࡣࠬἔ"))[nnsBpJv6XL3OzHoe4Vuhr]
		type = YnHG75e2QWwo(u"ࠬ࠲ࡓࡆࡔࡌࡉࡘࡀࠠࠨἕ")
	elif opyTNwHgfqbZREWKU(u"࠭ࡖࡐࡆࠪ἖") in hUe1QdzicSIN: type = S5fhsRT8JV(u"ࠧ࠭ࡘࡌࡈࡊࡕࡓ࠻ࠢࠪ἗")
	elif tRnTydV03Xfi7rbQ(u"ࠨࡎࡌ࡚ࡊ࠭Ἐ") in hUe1QdzicSIN: type = dwiIAcPl04ey7Zv38Mz(u"ࠩ࠯ࡐࡎ࡜ࡅ࠻ࠢࠪἙ")
	zJLApFBcIhnSj(LungQF89BqemOb32jJsZlW(u"ࠪࡪࡴࡲࡤࡦࡴࠪἚ"),tRnTydV03Xfi7rbQ(u"ࠫࡠ࠭Ἓ")+Gzygq01Kcb9U3+type+Q9pr7YKmZny8V5ifEugGWI+kH8E2zqNyims6KJfI+opyTNwHgfqbZREWKU(u"ࠬࠦ࠺ศๆๅื๊ࡣࠧἜ"),hUe1QdzicSIN,uxE8MyoTRglrcaiQf(u"࠵࠻࠽ᾙ"),cdZKMn68Pzg4,cdZKMn68Pzg4,TtyzcuW45VKA(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫἝ")+c3EZrqLkshKCJn0byXAGmfDTQN)
	zJLApFBcIhnSj(opyTNwHgfqbZREWKU(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ἞"),NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠨว฼หิฯࠠศๆฺ่อࠦวๅ฻ื์ฬฬ๊ࠡ็้ࠤ๋็ำࠡษ็ๆุ๋ࠧ἟"),hUe1QdzicSIN,uxE8MyoTRglrcaiQf(u"࠶࠼࠷ᾚ"),cdZKMn68Pzg4,cdZKMn68Pzg4,rbUkdYi32PJaRtnxhDvQs(u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧἠ")+c3EZrqLkshKCJn0byXAGmfDTQN)
	zJLApFBcIhnSj(LungQF89BqemOb32jJsZlW(u"ࠪࡰ࡮ࡴ࡫ࠨἡ"),Gzygq01Kcb9U3+AiCor1fIVTDxQUWwHe9vPR7(u"ࠫࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡࠩἢ")+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"࠿࠹࠺࠻ᾛ"))
	import tjK6YdAZJT
	for e3e5Wr7HPcK6RbEwXTmu in range(hiuZa0PIsErm6UC7,d37Zoe1YJgWbMq+hiuZa0PIsErm6UC7):
		if tRnTydV03Xfi7rbQ(u"ࠬࡥ࡟ࡊࡒࡗ࡚ࡘ࡫ࡲࡪࡧࡶࡣࡤ࠭ἣ") in c3EZrqLkshKCJn0byXAGmfDTQN: tjK6YdAZJT.iBT7IHNAlEYDgsRthp3x9ynd(str(e3e5Wr7HPcK6RbEwXTmu),hUe1QdzicSIN,c3EZrqLkshKCJn0byXAGmfDTQN,cdZKMn68Pzg4,ksTLSoVGg0ht)
		else: tjK6YdAZJT.yKvktsG9BnHTge4fVuREIpm83(str(e3e5Wr7HPcK6RbEwXTmu),hUe1QdzicSIN,c3EZrqLkshKCJn0byXAGmfDTQN,cdZKMn68Pzg4,ksTLSoVGg0ht)
	USuRxnPlV5.menuItemsLIST[:] = vA5jFKah9cbX6eiGpTw(USuRxnPlV5.menuItemsLIST)
	if len(USuRxnPlV5.menuItemsLIST)>(RDjfuZILUYwhx+kzoASbNraPcfgvWJmY9Qu): USuRxnPlV5.menuItemsLIST[:] = USuRxnPlV5.menuItemsLIST[:kzoASbNraPcfgvWJmY9Qu]+EduRM2WTj7xz1.sample(USuRxnPlV5.menuItemsLIST[kzoASbNraPcfgvWJmY9Qu:],RDjfuZILUYwhx)
	return
def K3f5lLpgPoI8cJdHFEDbwRny(hUe1QdzicSIN,c3EZrqLkshKCJn0byXAGmfDTQN):
	c3EZrqLkshKCJn0byXAGmfDTQN = c3EZrqLkshKCJn0byXAGmfDTQN.replace(LungQF89BqemOb32jJsZlW(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨἤ"),cdZKMn68Pzg4).replace(TtyzcuW45VKA(u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫἥ"),cdZKMn68Pzg4)
	Q9pr7YKmZny8V5ifEugGWI = c3EZrqLkshKCJn0byXAGmfDTQN
	if NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠨࡡࡢࡑ࠸࡛ࡓࡦࡴ࡬ࡩࡸࡥ࡟ࠨἦ") in c3EZrqLkshKCJn0byXAGmfDTQN:
		Q9pr7YKmZny8V5ifEugGWI = c3EZrqLkshKCJn0byXAGmfDTQN.split(NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠩࡢࡣࡒ࠹ࡕࡔࡧࡵ࡭ࡪࡹ࡟ࡠࠩἧ"))[nnsBpJv6XL3OzHoe4Vuhr]
		type = uxE8MyoTRglrcaiQf(u"ࠪ࠰ࡘࡋࡒࡊࡇࡖ࠾ࠥ࠭Ἠ")
	elif ObuCsdoDtKmhPLSMH8YGan(u"࡛ࠫࡕࡄࠨἩ") in hUe1QdzicSIN: type = zDek1IW37rq6UoKdwyRiAVpF(u"ࠬ࠲ࡖࡊࡆࡈࡓࡘࡀࠠࠨἪ")
	elif ObuCsdoDtKmhPLSMH8YGan(u"࠭ࡌࡊࡘࡈࠫἫ") in hUe1QdzicSIN: type = aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠧ࠭ࡎࡌ࡚ࡊࡀࠠࠨἬ")
	zJLApFBcIhnSj(opyTNwHgfqbZREWKU(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨἭ"),rbUkdYi32PJaRtnxhDvQs(u"ࠩ࡞ࠫἮ")+Gzygq01Kcb9U3+type+Q9pr7YKmZny8V5ifEugGWI+kH8E2zqNyims6KJfI+xN4fKmsnyM3Y2(u"ࠪࠤ࠿อไใี่ࡡࠬἯ"),hUe1QdzicSIN,aar0zhDnJsOTP7EdgR16HIS29(u"࠱࠷࠺ᾜ"),cdZKMn68Pzg4,cdZKMn68Pzg4,J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩἰ")+c3EZrqLkshKCJn0byXAGmfDTQN)
	zJLApFBcIhnSj(rbUkdYi32PJaRtnxhDvQs(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬἱ"),Rsdai9xIEPcpuBMKOUwkTA05q(u"࠭ลฺษาอࠥอไุๆหࠤฬู๊ี๊สส๏ࠦๅ็้ࠢๅุࠦวๅไึ้ࠬἲ"),hUe1QdzicSIN,AiCor1fIVTDxQUWwHe9vPR7(u"࠲࠸࠻ᾝ"),cdZKMn68Pzg4,cdZKMn68Pzg4,J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬἳ")+c3EZrqLkshKCJn0byXAGmfDTQN)
	zJLApFBcIhnSj(k5oIaYyp2mnrLK49qhzS(u"ࠨ࡮࡬ࡲࡰ࠭ἴ"),Gzygq01Kcb9U3+NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠩࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦࠧἵ")+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,vbYokBuWlxeLDcdVNM60(u"࠻࠼࠽࠾ᾞ"))
	import cwOg9mFakl
	for e3e5Wr7HPcK6RbEwXTmu in range(hiuZa0PIsErm6UC7,d37Zoe1YJgWbMq+hiuZa0PIsErm6UC7):
		if dwiIAcPl04ey7Zv38Mz(u"ࠪࡣࡤࡓ࠳ࡖࡕࡨࡶ࡮࡫ࡳࡠࡡࠪἶ") in c3EZrqLkshKCJn0byXAGmfDTQN: cwOg9mFakl.iBT7IHNAlEYDgsRthp3x9ynd(str(e3e5Wr7HPcK6RbEwXTmu),hUe1QdzicSIN,c3EZrqLkshKCJn0byXAGmfDTQN,cdZKMn68Pzg4,ksTLSoVGg0ht)
		else: cwOg9mFakl.yKvktsG9BnHTge4fVuREIpm83(str(e3e5Wr7HPcK6RbEwXTmu),hUe1QdzicSIN,c3EZrqLkshKCJn0byXAGmfDTQN,cdZKMn68Pzg4,ksTLSoVGg0ht)
	USuRxnPlV5.menuItemsLIST[:] = vA5jFKah9cbX6eiGpTw(USuRxnPlV5.menuItemsLIST)
	if len(USuRxnPlV5.menuItemsLIST)>(RDjfuZILUYwhx+kzoASbNraPcfgvWJmY9Qu): USuRxnPlV5.menuItemsLIST[:] = USuRxnPlV5.menuItemsLIST[:kzoASbNraPcfgvWJmY9Qu]+EduRM2WTj7xz1.sample(USuRxnPlV5.menuItemsLIST[kzoASbNraPcfgvWJmY9Qu:],RDjfuZILUYwhx)
	return
def vA5jFKah9cbX6eiGpTw(IoPnLQMdaZqTc):
	mm9lCOfEskFcKrQi = []
	for type,yy0cNBFOGVZh8rIeQ4,url,HHrpyfWjGC,fh6qmOxoiv1UPXZanLprDeMI8,aOZ3yVnsNlB974pR,JAYWBoz54tGw7O,x8FkISpTrmqPJe2nvZOWU7zuNcj,g8tTFcBGwdKlo42LUkW in IoPnLQMdaZqTc:
		if NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ฺࠫ็อสࠩἷ") in yy0cNBFOGVZh8rIeQ4 or xN4fKmsnyM3Y2(u"ࠬ฻แฮ้ࠪἸ") in yy0cNBFOGVZh8rIeQ4 or aar0zhDnJsOTP7EdgR16HIS29(u"࠭ࡰࡢࡩࡨࠫἹ") in yy0cNBFOGVZh8rIeQ4.lower(): continue
		mm9lCOfEskFcKrQi.append([type,yy0cNBFOGVZh8rIeQ4,url,HHrpyfWjGC,fh6qmOxoiv1UPXZanLprDeMI8,aOZ3yVnsNlB974pR,JAYWBoz54tGw7O,x8FkISpTrmqPJe2nvZOWU7zuNcj,g8tTFcBGwdKlo42LUkW])
	return mm9lCOfEskFcKrQi
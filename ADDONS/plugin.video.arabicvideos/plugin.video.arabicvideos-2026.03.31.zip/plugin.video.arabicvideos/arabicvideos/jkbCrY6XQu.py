# -*- coding: utf-8 -*-
from RgJNGc7YMP import *
headers = { 'User-Agent' : cdZKMn68Pzg4 }
UkXlAzsMcamKJrEIgnxi6bWh = 'AKOAM'
nc3GLkA65oxOd = '_AKO_'
cDTdfqVAF0BLGiX364IEwaZbr = USuRxnPlV5.SITESURLS[UkXlAzsMcamKJrEIgnxi6bWh][0]
ppQOGyNuHEXa9ro5JZ = ['فيلم','كليب','العرض الاسبوعي','مسرحية','مسرحيه','اغنية','اعلان','لقاء']
def HHN5EpbszV3iA2m89hGSQjaPgUZy(mode,url,text):
	if   mode==70: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = kUq58vC7x9hWma164JejMKQ()
	elif mode==71: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = WH7waGAlyphZe3(url)
	elif mode==72: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = GDQUH4fN02sIt81mAcY(url,text)
	elif mode==73: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = nA07lUxVOsFoJbuQrvIL4c2WBaYdzw(url)
	elif mode==74: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = RPZbqous7rtdy56LeI18Cv04AKHW(url)
	elif mode==79: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = z4hetAJw3NaT9ROjG6xbZ5CHlW81(text)
	else: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = False
	return xsGUcR3ef6glKY5hQwpFXEaSt2mrIz
def kUq58vC7x9hWma164JejMKQ():
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'بحث في الموقع',cdZKMn68Pzg4,79,cdZKMn68Pzg4,cdZKMn68Pzg4,'_REMEMBERRESULTS_')
	zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+'سلسلة افلام',cdZKMn68Pzg4,79,cdZKMn68Pzg4,cdZKMn68Pzg4,'سلسلة افلام')
	zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+'سلاسل منوعة',cdZKMn68Pzg4,79,cdZKMn68Pzg4,cdZKMn68Pzg4,'سلسلة')
	zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	cJWUPuDGM0Yybv5a9KnIrVzhH78 = ['الكتب و الابحاث','الكورسات التعليمية','الألعاب','البرامج','الاجهزة اللوحية','الصور و الخلفيات','المصارعة الحرة']
	OO1cj2REUZHJ8x5V = Gc05Efm73C8s(r43t1YI9deXA5N,cDTdfqVAF0BLGiX364IEwaZbr,cdZKMn68Pzg4,headers,cdZKMn68Pzg4,'AKOAM-MENU-1st')
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="partions"(.*?)</ul>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)">(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,title in items:
			if title not in cJWUPuDGM0Yybv5a9KnIrVzhH78:
				zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+title,c0cDhidBlOn7,71)
	return OO1cj2REUZHJ8x5V
def WH7waGAlyphZe3(url):
	OO1cj2REUZHJ8x5V = Gc05Efm73C8s(r43t1YI9deXA5N,url,cdZKMn68Pzg4,headers,cdZKMn68Pzg4,'AKOAM-CATEGORIES-1st')
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('sect_parts(.*?)</div>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?>(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,title in items:
			title = title.strip(VBpIH2QSmvDGlA6TO3e)
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,72)
		zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'جميع الفروع',url,72)
	else: GDQUH4fN02sIt81mAcY(url,cdZKMn68Pzg4)
	return
def GDQUH4fN02sIt81mAcY(url,type):
	OO1cj2REUZHJ8x5V = Gc05Efm73C8s(K8DZxE74Afz52gBYbOMtpvql0RJma,url,cdZKMn68Pzg4,headers,True,'AKOAM-TITLES-1st')
	items = []
	if type=='featured':
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('section_title featured_title(.*?)subjects-crousel',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)"><div class="subject_box.*?src="(.*?)".*?<h3.*?>(.*?)</h3>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	elif type=='search':
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('akoam_result(.*?)<script',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?background-image: url\((.*?)\).*?<h1>(.*?)</h1>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	elif type=='more':
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('section_title more_title(.*?)footer_bottom_services',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	else:
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('navigation(.*?)<script',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if not items and ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('div class="subject_box.*?href="(.*?)".*?src="(.*?)".*?<h3.*?>(.*?)</h3>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	for c0cDhidBlOn7,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,title in items:
		if 'توضيح هام' in title: continue
		title = title.replace(ssELJkeScrtni2,cdZKMn68Pzg4).strip(VBpIH2QSmvDGlA6TO3e)
		title = gbd90SjF2mZqf81IRDaTwJkWu(title)
		if any(value in title for value in ppQOGyNuHEXa9ro5JZ): zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,73,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
		else: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,73,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="pagination"(.*?)</ul>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall("</li><li >.*?href='(.*?)'>(.*?)<",KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,title in items:
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'صفحة '+title,c0cDhidBlOn7,72,cdZKMn68Pzg4,cdZKMn68Pzg4,type)
	return
def PnEjrtY4ykp2M(url):
	OO1cj2REUZHJ8x5V = Gc05Efm73C8s(r43t1YI9deXA5N,url,cdZKMn68Pzg4,headers,True,'AKOAM-SECTIONS-2nd')
	HOCWKhxITtulVGX = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"href","(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	HOCWKhxITtulVGX = HOCWKhxITtulVGX[1]
	return HOCWKhxITtulVGX
def nA07lUxVOsFoJbuQrvIL4c2WBaYdzw(url):
	OO1cj2REUZHJ8x5V = Gc05Efm73C8s(K8DZxE74Afz52gBYbOMtpvql0RJma,url,cdZKMn68Pzg4,headers,True,'AKOAM-SECTIONS-1st')
	xFDsWfKnPh3mEVUp1wrL = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"(https*://akwam.net/\w+.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	qgWoF0fTE4Ml = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"(https*://underurl.com/\w+.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if xFDsWfKnPh3mEVUp1wrL or qgWoF0fTE4Ml:
		if xFDsWfKnPh3mEVUp1wrL: N8jUpQxY0rhtDAzbG4kOs9X = xFDsWfKnPh3mEVUp1wrL[0]
		elif qgWoF0fTE4Ml: N8jUpQxY0rhtDAzbG4kOs9X = PnEjrtY4ykp2M(qgWoF0fTE4Ml[0])
		N8jUpQxY0rhtDAzbG4kOs9X = NLqxoZ37dYf0awrsIE(N8jUpQxY0rhtDAzbG4kOs9X)
		import DZnyUWGkNK
		if '/series/' in N8jUpQxY0rhtDAzbG4kOs9X or '/shows/' in N8jUpQxY0rhtDAzbG4kOs9X: DZnyUWGkNK.yIZWSuMpvs3(N8jUpQxY0rhtDAzbG4kOs9X)
		else: DZnyUWGkNK.RPZbqous7rtdy56LeI18Cv04AKHW(N8jUpQxY0rhtDAzbG4kOs9X)
		return
	eVdYQAPy2Dm = ffUFBJQ57j2XgoGeOLn9uwpC.findall('محتوى الفيلم.*?>.*?(\w*?)\W*?<',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if eVdYQAPy2Dm and bMOpKuUkQ5J2(UkXlAzsMcamKJrEIgnxi6bWh,url,eVdYQAPy2Dm): return
	items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('<br />\n<a href="(.*?)".*?<span style="color:.*?">(.*?)</span>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	for c0cDhidBlOn7,title in items:
		title = gbd90SjF2mZqf81IRDaTwJkWu(title)
		zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,73)
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="sub_title".*?<h1.*?>(.*?)</h1>.*?class="main_img".*?src="(.*?)".*?ad-300-250(.*?)ako-feedback',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if not ppvsMqCHf8SEzxQg:
		bJqPkYBXsenxTRwKu('خطأ خارجي','لا يوجد ملف فيديو')
		return
	name,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
	name = name.strip(VBpIH2QSmvDGlA6TO3e)
	if 'sub_epsiode_title' in KdWauEhgN6OQzjRVm1ro8tkB3:
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('sub_epsiode_title">(.*?)</h2>.*?sub_file_title.*?>(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	else:
		RGYqOt1xo7fU2raCdjcF46l0ZNksD = ffUFBJQ57j2XgoGeOLn9uwpC.findall('sub_file_title\'>(.*?) - <i>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		items = []
		for filename in RGYqOt1xo7fU2raCdjcF46l0ZNksD:
			items.append( ('رابط التشغيل',filename) )
	if not items: items = [ ('رابط التشغيل',cdZKMn68Pzg4) ]
	count = 0
	lycT0JB1noerD5YANK2PbHa8QVM,m9ngHAiWz4JZ3cbUhuxeQrYv6jP0 = [],[]
	size = len(items)
	for title,filename in items:
		eAbnqlfDFHjkQh2wB3vW0JR = cdZKMn68Pzg4
		if ' - ' in filename: filename = filename.split(' - ')[0]
		else: filename = 'dummy.zip'
		if '.' in filename: eAbnqlfDFHjkQh2wB3vW0JR = filename.split('.')[-1]
		title = title.replace(ssELJkeScrtni2,cdZKMn68Pzg4).strip(VBpIH2QSmvDGlA6TO3e)
		lycT0JB1noerD5YANK2PbHa8QVM.append(title)
		m9ngHAiWz4JZ3cbUhuxeQrYv6jP0.append(count)
		count += 1
	if size>0:
		if any(value in name for value in ppQOGyNuHEXa9ro5JZ):
			if size==1:
				AS6jLpMwW5Ql3kUFNfT = 0
			else:
				AS6jLpMwW5Ql3kUFNfT = NAfHLMC8Ip64FmT7l5oJWXaq3hK('اختر الفيديو المناسب:', lycT0JB1noerD5YANK2PbHa8QVM)
				if AS6jLpMwW5Ql3kUFNfT == -1: return
			RPZbqous7rtdy56LeI18Cv04AKHW(url+'?section='+str(1+m9ngHAiWz4JZ3cbUhuxeQrYv6jP0[size-AS6jLpMwW5Ql3kUFNfT-1]))
		else:
			for WCqkctAYD2O3Hz7Fl8fKRS5 in reversed(range(size)):
				title = name + ' - ' + lycT0JB1noerD5YANK2PbHa8QVM[WCqkctAYD2O3Hz7Fl8fKRS5]
				title = title.replace(ssELJkeScrtni2,cdZKMn68Pzg4).strip(VBpIH2QSmvDGlA6TO3e)
				c0cDhidBlOn7 = url + '?section='+str(size-WCqkctAYD2O3Hz7Fl8fKRS5)
				zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,74,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
	else:
		zJLApFBcIhnSj('video',nc3GLkA65oxOd+'الرابط ليس فيديو',cdZKMn68Pzg4,9999,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
	return
def RPZbqous7rtdy56LeI18Cv04AKHW(url):
	HOCWKhxITtulVGX,E0w56WHxZPYGVvnTQ4O2t1C8DAjq = url.split('?section=')
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',HOCWKhxITtulVGX,cdZKMn68Pzg4,headers,True,cdZKMn68Pzg4,'AKOAM-PLAY_AKOAM-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('ad-300-250.*?ad-300-250(.*?)ako-feedback',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	mlkP0QINy3nW4bpTr8HC75oXaOYhc = ppvsMqCHf8SEzxQg[0].replace("'direct_link_box",'"direct_link_box epsoide_box')
	mlkP0QINy3nW4bpTr8HC75oXaOYhc = mlkP0QINy3nW4bpTr8HC75oXaOYhc + 'direct_link_box'
	akIvSitzr0mKe = ffUFBJQ57j2XgoGeOLn9uwpC.findall('epsoide_box(.*?)direct_link_box',mlkP0QINy3nW4bpTr8HC75oXaOYhc,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	E0w56WHxZPYGVvnTQ4O2t1C8DAjq = len(akIvSitzr0mKe)-int(E0w56WHxZPYGVvnTQ4O2t1C8DAjq)
	KdWauEhgN6OQzjRVm1ro8tkB3 = akIvSitzr0mKe[E0w56WHxZPYGVvnTQ4O2t1C8DAjq]
	XFj0lV5yMtS67EwbCJ9oO = []
	Gyc2UKNZoOq8PSHzrgTR = {'1423075862':'dailymotion','1477487601':'estream','1505328404':'streamango',
		'1423080015':'flashx','1458117295':'openload','1423079306':'vimple','1430052371':'ok.ru',
		'1477488213':'thevid','1558278006':'uqload','1477487990':'vidtodo'}
	items = ffUFBJQ57j2XgoGeOLn9uwpC.findall("class='download_btn.*?href='(.*?)'",KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	for c0cDhidBlOn7 in items:
		XFj0lV5yMtS67EwbCJ9oO.append(c0cDhidBlOn7+'?named=________akoam')
	items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('background-image: url\((.*?)\).*?href=\'(.*?)\'',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	for KNeZjwm7VAxpMCdXfvyT5QBg,c0cDhidBlOn7 in items:
		KNeZjwm7VAxpMCdXfvyT5QBg = KNeZjwm7VAxpMCdXfvyT5QBg.split(KCQExdbYFqM)[-1]
		KNeZjwm7VAxpMCdXfvyT5QBg = KNeZjwm7VAxpMCdXfvyT5QBg.split('.')[0]
		if KNeZjwm7VAxpMCdXfvyT5QBg in Gyc2UKNZoOq8PSHzrgTR:
			XFj0lV5yMtS67EwbCJ9oO.append(c0cDhidBlOn7+'?named='+Gyc2UKNZoOq8PSHzrgTR[KNeZjwm7VAxpMCdXfvyT5QBg]+'________akoam')
		else: XFj0lV5yMtS67EwbCJ9oO.append(c0cDhidBlOn7+'?named='+KNeZjwm7VAxpMCdXfvyT5QBg+'________akoam')
	if not XFj0lV5yMtS67EwbCJ9oO:
		message = ffUFBJQ57j2XgoGeOLn9uwpC.findall('sub-no-file.*?\n(.*?)\n',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if message: NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,'رسالة من الموقع الاصلي',message[0])
	else:
		import r0y4XTKznF
		r0y4XTKznF.noHliPXkcg3pJTdSauCvm5sU(XFj0lV5yMtS67EwbCJ9oO,UkXlAzsMcamKJrEIgnxi6bWh,'video',url)
	return
def z4hetAJw3NaT9ROjG6xbZ5CHlW81(search):
	search,EL8zUgbXheot,showDialogs = qbIcHCMdkFKn21e(search)
	if search==cdZKMn68Pzg4: search = BzkmLuvJD9n25Pg()
	if search==cdZKMn68Pzg4: return
	nuKdVC6ePlg = search.replace(VBpIH2QSmvDGlA6TO3e,'%20')
	url = cDTdfqVAF0BLGiX364IEwaZbr + '/search/'+nuKdVC6ePlg
	xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = GDQUH4fN02sIt81mAcY(url,'search')
	return
# -*- coding: utf-8 -*-
from RgJNGc7YMP import *
UkXlAzsMcamKJrEIgnxi6bWh = 'EGYBESTVIP'
nc3GLkA65oxOd = '_EGV_'
cDTdfqVAF0BLGiX364IEwaZbr = USuRxnPlV5.SITESURLS[UkXlAzsMcamKJrEIgnxi6bWh][0]
def HHN5EpbszV3iA2m89hGSQjaPgUZy(mode,url,aOZ3yVnsNlB974pR,text):
	if   mode==220: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = kUq58vC7x9hWma164JejMKQ()
	elif mode==221: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = GDQUH4fN02sIt81mAcY(url,aOZ3yVnsNlB974pR)
	elif mode==222: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = oQF2hgjusp8Ne(url)
	elif mode==223: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = RPZbqous7rtdy56LeI18Cv04AKHW(url)
	elif mode==224: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = XxcpMKIUzr0sVDngR(url)
	elif mode==229: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = z4hetAJw3NaT9ROjG6xbZ5CHlW81(text)
	else: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = False
	return xsGUcR3ef6glKY5hQwpFXEaSt2mrIz
def kUq58vC7x9hWma164JejMKQ():
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'بحث في الموقع',cdZKMn68Pzg4,229,cdZKMn68Pzg4,cdZKMn68Pzg4,'_REMEMBERRESULTS_')
	zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(r43t1YI9deXA5N,'GET',cDTdfqVAF0BLGiX364IEwaZbr,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'EGYBEST-MENU-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="i i-home"(.*?)</div>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)"(.*?)</a>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,title in items:
			if '</i>' in title: title = title.split('</i>')[1]
			zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+title,c0cDhidBlOn7,222)
		zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="ba(.*?)<script',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('pda bdb"><strong>(.*?)<.*?href="(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for title,c0cDhidBlOn7 in items:
			zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+title,c0cDhidBlOn7,221)
		zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?>(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,title in items:
			if 'html' not in c0cDhidBlOn7: continue
			if not c0cDhidBlOn7.endswith(KCQExdbYFqM): zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+title,c0cDhidBlOn7,221)
	return OO1cj2REUZHJ8x5V
def oQF2hgjusp8Ne(url):
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(r43t1YI9deXA5N,'GET',url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'EGYBESTVIP-SUBMENU-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="rs_scroll"(.*?)</div>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
	items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?</i>(.*?)</a>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	for c0cDhidBlOn7,title in items:
		zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,224)
	return
def XxcpMKIUzr0sVDngR(url):
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'الجميع',url,221)
	OO1cj2REUZHJ8x5V = Gc05Efm73C8s(r43t1YI9deXA5N,url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'EGYBESTVIP-FILTERS_MENU-1st')
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="sub_nav(.*?)id="movies',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".+?>(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,title in items:
			if c0cDhidBlOn7=='#': name = title
			else:
				title = title + '  :  ' + 'فلتر ' + name
				zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,221)
	else: GDQUH4fN02sIt81mAcY(url)
	return
def GDQUH4fN02sIt81mAcY(url,aOZ3yVnsNlB974pR='1'):
	if aOZ3yVnsNlB974pR==cdZKMn68Pzg4: aOZ3yVnsNlB974pR = '1'
	if '/search' in url or '?' in url: HOCWKhxITtulVGX = url + '&'
	else: HOCWKhxITtulVGX = url + '?'
	HOCWKhxITtulVGX = HOCWKhxITtulVGX + 'page=' + aOZ3yVnsNlB974pR
	OO1cj2REUZHJ8x5V = Gc05Efm73C8s(K8DZxE74Afz52gBYbOMtpvql0RJma,HOCWKhxITtulVGX,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'EGYBESTVIP-TITLES-1st')
	if '/season' in url:
		ppvsMqCHf8SEzxQg=ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="pda"(.*?)div',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[-1]
	elif '/series/' in url:
		ppvsMqCHf8SEzxQg=ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="owl-carousel owl-carousel(.*?)div',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
	else:
		ppvsMqCHf8SEzxQg=ffUFBJQ57j2XgoGeOLn9uwpC.findall('id="movies(.*?)</div>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[-1]
	items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('<a href="(.*?)".*?src="(.*?)".*?title">(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	for c0cDhidBlOn7,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,title in items:
		title = gbd90SjF2mZqf81IRDaTwJkWu(title)
		if '/movie/' in c0cDhidBlOn7 or '/episode' in c0cDhidBlOn7:
			zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7.rstrip(KCQExdbYFqM),223,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
		else:
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,221,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
	if len(items)>=16:
		hbsV0CKiRqm6uo = ['/movies','/tv','/search','/trending']
		aOZ3yVnsNlB974pR = int(aOZ3yVnsNlB974pR)
		if any(value in url for value in hbsV0CKiRqm6uo):
			for V0acmG6IUlR9DXNsoAiS in range(0,1000,100):
				if int(aOZ3yVnsNlB974pR/100)*100==V0acmG6IUlR9DXNsoAiS:
					for WCqkctAYD2O3Hz7Fl8fKRS5 in range(V0acmG6IUlR9DXNsoAiS,V0acmG6IUlR9DXNsoAiS+100,10):
						if int(aOZ3yVnsNlB974pR/10)*10==WCqkctAYD2O3Hz7Fl8fKRS5:
							for QfnFcWCNaUP9KoVOw in range(WCqkctAYD2O3Hz7Fl8fKRS5,WCqkctAYD2O3Hz7Fl8fKRS5+10,1):
								if not aOZ3yVnsNlB974pR==QfnFcWCNaUP9KoVOw and QfnFcWCNaUP9KoVOw!=0:
									zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'صفحة '+str(QfnFcWCNaUP9KoVOw),url,221,cdZKMn68Pzg4,str(QfnFcWCNaUP9KoVOw))
						elif WCqkctAYD2O3Hz7Fl8fKRS5!=0: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'صفحة '+str(WCqkctAYD2O3Hz7Fl8fKRS5),url,221,cdZKMn68Pzg4,str(WCqkctAYD2O3Hz7Fl8fKRS5))
						else: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'صفحة '+str(1),url,221,cdZKMn68Pzg4,str(1))
				elif V0acmG6IUlR9DXNsoAiS!=0: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'صفحة '+str(V0acmG6IUlR9DXNsoAiS),url,221,cdZKMn68Pzg4,str(V0acmG6IUlR9DXNsoAiS))
				else: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'صفحة '+str(1),url,221)
	return
def RPZbqous7rtdy56LeI18Cv04AKHW(url):
	lycT0JB1noerD5YANK2PbHa8QVM,pcX7zxFRmsADwUr = [],[]
	OO1cj2REUZHJ8x5V = Gc05Efm73C8s(r43t1YI9deXA5N,url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'EGYBESTVIP-PLAY-1st')
	eVdYQAPy2Dm = ffUFBJQ57j2XgoGeOLn9uwpC.findall('<td>التصنيف</td>.*?">(.*?)<',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if eVdYQAPy2Dm and bMOpKuUkQ5J2(UkXlAzsMcamKJrEIgnxi6bWh,url,eVdYQAPy2Dm): return
	cOVHC0F6h9oI7NdDE1nbjS,qNwtyICDZ65dpAvUezjY = cdZKMn68Pzg4,cdZKMn68Pzg4
	fTWo1bc7qIYn,J0J1lgIO4zfp = OO1cj2REUZHJ8x5V,OO1cj2REUZHJ8x5V
	G7JLrTdE0mo8y = ffUFBJQ57j2XgoGeOLn9uwpC.findall('show_dl api" href="(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if G7JLrTdE0mo8y:
		for c0cDhidBlOn7 in G7JLrTdE0mo8y:
			if '/watch/' in c0cDhidBlOn7: cOVHC0F6h9oI7NdDE1nbjS = c0cDhidBlOn7
			elif '/download/' in c0cDhidBlOn7: qNwtyICDZ65dpAvUezjY = c0cDhidBlOn7
		if cOVHC0F6h9oI7NdDE1nbjS!=cdZKMn68Pzg4: fTWo1bc7qIYn = Gc05Efm73C8s(r43t1YI9deXA5N,cOVHC0F6h9oI7NdDE1nbjS,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'EGYBESTVIP-PLAY-2nd')
		if qNwtyICDZ65dpAvUezjY!=cdZKMn68Pzg4: J0J1lgIO4zfp = Gc05Efm73C8s(r43t1YI9deXA5N,qNwtyICDZ65dpAvUezjY,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'EGYBESTVIP-PLAY-3rd')
	Pb6wRGTnV8Ac7HW = ffUFBJQ57j2XgoGeOLn9uwpC.findall('id="video".*?data-src="(.*?)"',fTWo1bc7qIYn,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if Pb6wRGTnV8Ac7HW:
		HOCWKhxITtulVGX = Pb6wRGTnV8Ac7HW[0]
		if HOCWKhxITtulVGX!=cdZKMn68Pzg4 and 'uploaded.egybest.download' in HOCWKhxITtulVGX and '/?id=_' not in HOCWKhxITtulVGX:
			JJPEReUDbt0QoWHkL21TA = Gc05Efm73C8s(r43t1YI9deXA5N,HOCWKhxITtulVGX,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'EGYBESTVIP-PLAY-4th')
			ReGIgcBjY9 = ffUFBJQ57j2XgoGeOLn9uwpC.findall('source src="(.*?)" title="(.*?)"',JJPEReUDbt0QoWHkL21TA,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			if ReGIgcBjY9:
				for c0cDhidBlOn7,l1MCIuwhAELbO2eJ96kNta7rp0B in ReGIgcBjY9:
					pcX7zxFRmsADwUr.append(c0cDhidBlOn7+'?named=ed.egybest.do__watch__mp4__'+l1MCIuwhAELbO2eJ96kNta7rp0B)
			else:
				wRlW4txQshKmeXdO7zABrLPT1GbZ0 = HOCWKhxITtulVGX.split(KCQExdbYFqM)[2]
				pcX7zxFRmsADwUr.append(HOCWKhxITtulVGX+'?named='+wRlW4txQshKmeXdO7zABrLPT1GbZ0+'__watch')
		elif HOCWKhxITtulVGX!=cdZKMn68Pzg4:
			wRlW4txQshKmeXdO7zABrLPT1GbZ0 = HOCWKhxITtulVGX.split(KCQExdbYFqM)[2]
			pcX7zxFRmsADwUr.append(HOCWKhxITtulVGX+'?named='+wRlW4txQshKmeXdO7zABrLPT1GbZ0+'__watch')
	wV43RaAT28Pe1nK5CvbH7rf90 = ffUFBJQ57j2XgoGeOLn9uwpC.findall('<table class="dls_table(.*?)</table>',J0J1lgIO4zfp,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if wV43RaAT28Pe1nK5CvbH7rf90:
		wV43RaAT28Pe1nK5CvbH7rf90 = wV43RaAT28Pe1nK5CvbH7rf90[0]
		C0APGhkynY = ffUFBJQ57j2XgoGeOLn9uwpC.findall('<td>.*?<td>(.*?)<.*?href="(.*?)"',wV43RaAT28Pe1nK5CvbH7rf90,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if C0APGhkynY:
			for l1MCIuwhAELbO2eJ96kNta7rp0B,c0cDhidBlOn7 in C0APGhkynY:
				if 'myegyvip' not in c0cDhidBlOn7: continue
				if c0cDhidBlOn7.count(KCQExdbYFqM)>=2:
					wRlW4txQshKmeXdO7zABrLPT1GbZ0 = c0cDhidBlOn7.split(KCQExdbYFqM)[2]
					pcX7zxFRmsADwUr.append(c0cDhidBlOn7+'?named='+wRlW4txQshKmeXdO7zABrLPT1GbZ0+'__download__mp4__'+l1MCIuwhAELbO2eJ96kNta7rp0B)
	zzXM2q1ErD = []
	for c0cDhidBlOn7 in pcX7zxFRmsADwUr:
		zzXM2q1ErD.append(c0cDhidBlOn7)
	import r0y4XTKznF
	r0y4XTKznF.noHliPXkcg3pJTdSauCvm5sU(zzXM2q1ErD,UkXlAzsMcamKJrEIgnxi6bWh,'video',url)
	return
def z4hetAJw3NaT9ROjG6xbZ5CHlW81(search):
	search,EL8zUgbXheot,showDialogs = qbIcHCMdkFKn21e(search)
	if search==cdZKMn68Pzg4: search = BzkmLuvJD9n25Pg()
	if search==cdZKMn68Pzg4: return
	nuKdVC6ePlg = search.replace(VBpIH2QSmvDGlA6TO3e,'+')
	OO1cj2REUZHJ8x5V = Gc05Efm73C8s(AlfMBJhUD65to2WrQcb,cDTdfqVAF0BLGiX364IEwaZbr,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'EGYBESTVIP-SEARCH-1st')
	ZkrlcUwCsK0XGpDSBjW = ffUFBJQ57j2XgoGeOLn9uwpC.findall('name="_token" value="(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ZkrlcUwCsK0XGpDSBjW:
		url = cDTdfqVAF0BLGiX364IEwaZbr+'/search?_token='+ZkrlcUwCsK0XGpDSBjW[0]+'&q='+nuKdVC6ePlg
		GDQUH4fN02sIt81mAcY(url)
	return
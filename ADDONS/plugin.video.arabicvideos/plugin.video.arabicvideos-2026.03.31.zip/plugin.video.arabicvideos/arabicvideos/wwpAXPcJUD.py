# -*- coding: utf-8 -*-
from RgJNGc7YMP import *
UkXlAzsMcamKJrEIgnxi6bWh = 'EGYNOW'
nc3GLkA65oxOd = '_EGN_'
cDTdfqVAF0BLGiX364IEwaZbr = USuRxnPlV5.SITESURLS[UkXlAzsMcamKJrEIgnxi6bWh][0]
cJWUPuDGM0Yybv5a9KnIrVzhH78 = ['عروض مصارعة','الكل','n/A','المزيد','قصة عشق']
def HHN5EpbszV3iA2m89hGSQjaPgUZy(mode,url,text):
	if   mode==430: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = kUq58vC7x9hWma164JejMKQ()
	elif mode==431: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = GDQUH4fN02sIt81mAcY(url,text)
	elif mode==432: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = RPZbqous7rtdy56LeI18Cv04AKHW(url)
	elif mode==433: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = yIZWSuMpvs3(url)
	elif mode==434: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = XxcpMKIUzr0sVDngR(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==435: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = XxcpMKIUzr0sVDngR(url,'SPECIFIED_FILTER___'+text)
	elif mode==436: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = oQF2hgjusp8Ne(url)
	elif mode==437: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = OOWry1B4vRJFVqPGn8mtKcgMI2h(url)
	elif mode==439: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = z4hetAJw3NaT9ROjG6xbZ5CHlW81(text)
	else: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = False
	return xsGUcR3ef6glKY5hQwpFXEaSt2mrIz
def kUq58vC7x9hWma164JejMKQ():
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',cDTdfqVAF0BLGiX364IEwaZbr+'/films',cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'EGYNOW-MENU-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	u1P73L0UmkA4eaIBbCgZfrvRtJ = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"canonical" href="(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	u1P73L0UmkA4eaIBbCgZfrvRtJ = u1P73L0UmkA4eaIBbCgZfrvRtJ[0].strip(KCQExdbYFqM)
	u1P73L0UmkA4eaIBbCgZfrvRtJ = CxlbPZwGTcH87e1sWhfSIz29uRUEpV(u1P73L0UmkA4eaIBbCgZfrvRtJ,'url')
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'بحث في الموقع',cdZKMn68Pzg4,439,cdZKMn68Pzg4,cdZKMn68Pzg4,'_REMEMBERRESULTS_')
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'فلتر محدد',u1P73L0UmkA4eaIBbCgZfrvRtJ,435)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'فلتر كامل',u1P73L0UmkA4eaIBbCgZfrvRtJ,434)
	zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+'المضاف حديثا',u1P73L0UmkA4eaIBbCgZfrvRtJ,431)
	zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+'افلام اون لاين',u1P73L0UmkA4eaIBbCgZfrvRtJ+'/films1',436)
	zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+'مسلسلات اون لاين',u1P73L0UmkA4eaIBbCgZfrvRtJ+'/series-all1',436)
	zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+'قائمة تفصيلية',u1P73L0UmkA4eaIBbCgZfrvRtJ,437)
	zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"SiteNavigation"(.*?)"Search"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
	items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?>(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	for c0cDhidBlOn7,title in items:
		if title in cJWUPuDGM0Yybv5a9KnIrVzhH78: continue
		if title=='الرئيسية': continue
		if 'اون لاين' in title: continue
		zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+title,c0cDhidBlOn7,431)
	return
def OOWry1B4vRJFVqPGn8mtKcgMI2h(website=cdZKMn68Pzg4):
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',website+'/films',cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'EGYNOW-MENU-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	u1P73L0UmkA4eaIBbCgZfrvRtJ = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"canonical" href="(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	u1P73L0UmkA4eaIBbCgZfrvRtJ = u1P73L0UmkA4eaIBbCgZfrvRtJ[0].strip(KCQExdbYFqM)
	u1P73L0UmkA4eaIBbCgZfrvRtJ = CxlbPZwGTcH87e1sWhfSIz29uRUEpV(u1P73L0UmkA4eaIBbCgZfrvRtJ,'url')
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"ListDroped"(.*?)"SearchingMaster"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
	items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('data-tax="(.*?)" data-term="(.*?)" data-name="(.*?)"',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	for rrb0SF6otehufCYOX4,value,title in items:
		if title in cJWUPuDGM0Yybv5a9KnIrVzhH78: continue
		c0cDhidBlOn7 = website+'/explore/?'+rrb0SF6otehufCYOX4+'='+value
		zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+title,c0cDhidBlOn7,431)
	return
def oQF2hgjusp8Ne(url):
	u1P73L0UmkA4eaIBbCgZfrvRtJ = CxlbPZwGTcH87e1sWhfSIz29uRUEpV(url,'url')
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'EGYNOW-SUBMENU-1st')
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'الجميع',url,431)
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"titleSectionCon"(.*?)</div></div>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
	items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('data-key="(.*?)".*?<em>(.*?)</em>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	for w3wLtqKIc0,title in items:
		if title in cJWUPuDGM0Yybv5a9KnIrVzhH78: continue
		HOCWKhxITtulVGX = u1P73L0UmkA4eaIBbCgZfrvRtJ+'/wp-content/themes/EgyNowByElshaikh/Ajaxt/Movies/Keys.php?key='+w3wLtqKIc0
		zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,HOCWKhxITtulVGX,431)
	return
def GDQUH4fN02sIt81mAcY(url,CvSX7Etpz80eGlT1brgWZkJ=cdZKMn68Pzg4):
	u1P73L0UmkA4eaIBbCgZfrvRtJ = CxlbPZwGTcH87e1sWhfSIz29uRUEpV(url,'url')
	items = []
	if '/Terms.php' in url or '/Get.php' in url or '/Keys.php' in url:
		HOCWKhxITtulVGX,H3F607d1jsXEnMvor2 = sRAznbuQ5jiN09o4V8tpEYSlG7fe(url)
		npaJqziQ13tIH0hLjDdB2cWX7uUMPR = {'X-Requested-With':'XMLHttpRequest','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'POST',HOCWKhxITtulVGX,H3F607d1jsXEnMvor2,npaJqziQ13tIH0hLjDdB2cWX7uUMPR,cdZKMn68Pzg4,cdZKMn68Pzg4,'EGYNOW-TITLES-1st')
		OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
		KdWauEhgN6OQzjRVm1ro8tkB3 = OO1cj2REUZHJ8x5V
	elif CvSX7Etpz80eGlT1brgWZkJ=='featured':
		Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'EGYNOW-TITLES-2nd')
		OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"MainSlider"(.*?)"MatchesTable"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('<a href="([^"]*)" title="([^"]*)".*?image: url\((.*?)\)',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	else:
		Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'EGYNOW-TITLES-2nd')
		OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"BlocksList"(.*?)"Paginate"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if not ppvsMqCHf8SEzxQg: ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"BlocksList"(.*?)"titleSectionCon"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
	if not items: items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('<a href="([^"]*)" title="([^"]*)".*?data-image="(.*?)"',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	KRmzvoWYyxfXw37SEh1Q = []
	rgWUvoaJnZARc375bjQ = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for c0cDhidBlOn7,title,y90BoFz8MA1ZThaSC2ILXHiK3OY6w in items:
		c0cDhidBlOn7 = NLqxoZ37dYf0awrsIE(c0cDhidBlOn7).strip(KCQExdbYFqM)
		title = gbd90SjF2mZqf81IRDaTwJkWu(title)
		E0w56WHxZPYGVvnTQ4O2t1C8DAjq = ffUFBJQ57j2XgoGeOLn9uwpC.findall('(.*?) الحلقة \d+',title,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if any(value in title for value in rgWUvoaJnZARc375bjQ):
			zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,432,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
		elif E0w56WHxZPYGVvnTQ4O2t1C8DAjq and 'الحلقة' in title:
			title = '_MOD_' + E0w56WHxZPYGVvnTQ4O2t1C8DAjq[0]
			if title not in KRmzvoWYyxfXw37SEh1Q:
				zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,433,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
				KRmzvoWYyxfXw37SEh1Q.append(title)
		elif '/movseries/' in c0cDhidBlOn7:
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,431,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
		else: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,433,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
	if CvSX7Etpz80eGlT1brgWZkJ!='featured':
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"Paginate"(.*?)</ul>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if ppvsMqCHf8SEzxQg:
			KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
			items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)">(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			for c0cDhidBlOn7,title in items:
				if 'http' not in c0cDhidBlOn7: c0cDhidBlOn7 = u1P73L0UmkA4eaIBbCgZfrvRtJ+c0cDhidBlOn7
				c0cDhidBlOn7 = gbd90SjF2mZqf81IRDaTwJkWu(c0cDhidBlOn7)
				title = gbd90SjF2mZqf81IRDaTwJkWu(title)
				if title!=cdZKMn68Pzg4: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'صفحة '+title,c0cDhidBlOn7,431)
		UrOQ4PapMvq1kRiLeWSGYg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('showmore" href="(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if UrOQ4PapMvq1kRiLeWSGYg:
			c0cDhidBlOn7 = UrOQ4PapMvq1kRiLeWSGYg[0]
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'مشاهدة المزيد',c0cDhidBlOn7,431)
	return
def yIZWSuMpvs3(url):
	u1P73L0UmkA4eaIBbCgZfrvRtJ = CxlbPZwGTcH87e1sWhfSIz29uRUEpV(url,'url')
	ptXc2zV0RhTb,ll9vYSyie5kwbR16U0a2K = [],[]
	if 'Episodes.php' in url:
		HOCWKhxITtulVGX,H3F607d1jsXEnMvor2 = sRAznbuQ5jiN09o4V8tpEYSlG7fe(url)
		npaJqziQ13tIH0hLjDdB2cWX7uUMPR = {'X-Requested-With':'XMLHttpRequest','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'POST',HOCWKhxITtulVGX,H3F607d1jsXEnMvor2,npaJqziQ13tIH0hLjDdB2cWX7uUMPR,cdZKMn68Pzg4,cdZKMn68Pzg4,'EGYNOW-EPISODES-1st')
		OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
		ll9vYSyie5kwbR16U0a2K = [OO1cj2REUZHJ8x5V]
	else:
		Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'EGYNOW-EPISODES-2nd')
		OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
		ptXc2zV0RhTb = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"SeasonsList"(.*?)</ul>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		ll9vYSyie5kwbR16U0a2K = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"EpisodesList"(.*?)</ul>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ptXc2zV0RhTb:
		y90BoFz8MA1ZThaSC2ILXHiK3OY6w = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"og:image" content="(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		y90BoFz8MA1ZThaSC2ILXHiK3OY6w = y90BoFz8MA1ZThaSC2ILXHiK3OY6w[0]
		KdWauEhgN6OQzjRVm1ro8tkB3 = ptXc2zV0RhTb[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('data-id="(.*?)".*?data-season="(.*?)".*?">(.*?)</a>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for PTsY9XSpQFhGuxtvJk74oV3fwdWeaE,A0wZognpkWBSRE1,title in items:
			c0cDhidBlOn7 = u1P73L0UmkA4eaIBbCgZfrvRtJ+'/wp-content/themes/EgyNowByElshaikh/Ajaxt/Single/Episodes.php?'+'season='+A0wZognpkWBSRE1+'&post_id='+PTsY9XSpQFhGuxtvJk74oV3fwdWeaE
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,433,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
	elif ll9vYSyie5kwbR16U0a2K:
		y90BoFz8MA1ZThaSC2ILXHiK3OY6w = bu6LzUQF7K.getInfoLabel('ListItem.Thumb')
		KdWauEhgN6OQzjRVm1ro8tkB3 = ll9vYSyie5kwbR16U0a2K[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?</i>(.*?)<em>(.*?)</em>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,title,E0w56WHxZPYGVvnTQ4O2t1C8DAjq in items:
			title = title+VBpIH2QSmvDGlA6TO3e+E0w56WHxZPYGVvnTQ4O2t1C8DAjq
			zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,432,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
	return
def RPZbqous7rtdy56LeI18Cv04AKHW(url):
	HOCWKhxITtulVGX = url+'/watch/'
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',HOCWKhxITtulVGX,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'EGYNOW-PLAY-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	pcX7zxFRmsADwUr = []
	u1P73L0UmkA4eaIBbCgZfrvRtJ = CxlbPZwGTcH87e1sWhfSIz29uRUEpV(HOCWKhxITtulVGX,'url')
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"container-servers"(.*?)</ul>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		w6ImbV0vxLgs9NoMXJ42cO8alAd = ffUFBJQ57j2XgoGeOLn9uwpC.findall('data-id="(.*?)"',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if w6ImbV0vxLgs9NoMXJ42cO8alAd:
			w6ImbV0vxLgs9NoMXJ42cO8alAd = w6ImbV0vxLgs9NoMXJ42cO8alAd[0]
			items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('data-server="(.*?)".*?<span>(.*?)</span>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			for wRlW4txQshKmeXdO7zABrLPT1GbZ0,title in items:
				c0cDhidBlOn7 = u1P73L0UmkA4eaIBbCgZfrvRtJ+'/wp-content/themes/EgyNowByElshaikh/Ajaxt/Single/Server.php?server='+wRlW4txQshKmeXdO7zABrLPT1GbZ0+'&post_id='+w6ImbV0vxLgs9NoMXJ42cO8alAd+'?named='+title+'__watch'
				pcX7zxFRmsADwUr.append(c0cDhidBlOn7)
	SOBJrlvFKpwUbPdknY1T = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"container-iframe"><iframe src="(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if SOBJrlvFKpwUbPdknY1T:
		SOBJrlvFKpwUbPdknY1T = SOBJrlvFKpwUbPdknY1T[0].replace(ssELJkeScrtni2,cdZKMn68Pzg4)
		title = CxlbPZwGTcH87e1sWhfSIz29uRUEpV(SOBJrlvFKpwUbPdknY1T,'name')
		c0cDhidBlOn7 = SOBJrlvFKpwUbPdknY1T+'?named='+title+'__embed'
		pcX7zxFRmsADwUr.append(c0cDhidBlOn7)
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"container-download"(.*?)</ul>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?span>(.*?)<.*?em>(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,title,l1MCIuwhAELbO2eJ96kNta7rp0B in items:
			c0cDhidBlOn7 = c0cDhidBlOn7.replace(ssELJkeScrtni2,cdZKMn68Pzg4)
			if l1MCIuwhAELbO2eJ96kNta7rp0B!=cdZKMn68Pzg4: l1MCIuwhAELbO2eJ96kNta7rp0B = '____'+l1MCIuwhAELbO2eJ96kNta7rp0B
			c0cDhidBlOn7 = c0cDhidBlOn7+'?named='+title+'__download'+l1MCIuwhAELbO2eJ96kNta7rp0B
			pcX7zxFRmsADwUr.append(c0cDhidBlOn7)
	import r0y4XTKznF
	r0y4XTKznF.noHliPXkcg3pJTdSauCvm5sU(pcX7zxFRmsADwUr,UkXlAzsMcamKJrEIgnxi6bWh,'video',url)
	return
def z4hetAJw3NaT9ROjG6xbZ5CHlW81(search):
	search,EL8zUgbXheot,showDialogs = qbIcHCMdkFKn21e(search)
	if search==cdZKMn68Pzg4: search = BzkmLuvJD9n25Pg()
	if search==cdZKMn68Pzg4: return
	search = search.replace(VBpIH2QSmvDGlA6TO3e,'%20')
	url = cDTdfqVAF0BLGiX364IEwaZbr+'/?s='+search
	GDQUH4fN02sIt81mAcY(url)
	return
def J1BMh3gS6EbcwT284RdnKzkitfUqW(url):
	url = url.split('/smartemadfilter?')[0]
	u1P73L0UmkA4eaIBbCgZfrvRtJ = CxlbPZwGTcH87e1sWhfSIz29uRUEpV(url,'url')
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(r43t1YI9deXA5N,'GET',u1P73L0UmkA4eaIBbCgZfrvRtJ,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'EGYNOW-GET_FILTERS_BLOCKS-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('("dropdown-button".*?)"SearchingMaster"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
	hQ9ADnZlSxI1m8ui = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"dropdown-button".*?<em>(.*?)</em>(.*?data-tax="(.*?)".*?</div>)',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	return hQ9ADnZlSxI1m8ui
def ycYdX9u6W0oOnbMaDlf4KiPz(KdWauEhgN6OQzjRVm1ro8tkB3):
	items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('data-term="(\d+)" data-name="(.*?)"',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	return items
def PVO4RmQY92jycoli0GtrusH(url):
	NLpSEUdj5H081igYnC4TbA2QtoVclF = url.split('/smartemadfilter?')[0]
	YYpjB2CuTidaMgcGrlJOswovm = CxlbPZwGTcH87e1sWhfSIz29uRUEpV(url,'url')
	url = url.replace(NLpSEUdj5H081igYnC4TbA2QtoVclF,YYpjB2CuTidaMgcGrlJOswovm)
	url = url.replace('/smartemadfilter?','/explore/?')
	return url
def QVOgIWZlpCaD1XnfLxseFSdK3GcqA(qwmxUpZfQj8EAV3Tc,url):
	YqrzmSVb3R9MgUnX2auEHlpBhZD = XFoM2xPKIt3u51hLj(qwmxUpZfQj8EAV3Tc,'modified_filters')
	N8jUpQxY0rhtDAzbG4kOs9X = url+'/smartemadfilter?'+YqrzmSVb3R9MgUnX2auEHlpBhZD
	N8jUpQxY0rhtDAzbG4kOs9X = PVO4RmQY92jycoli0GtrusH(N8jUpQxY0rhtDAzbG4kOs9X)
	return N8jUpQxY0rhtDAzbG4kOs9X
fCAW9dmInLiV = ['category','country','genre','release-year']
w6wuL59PgeE = ['quality','release-year','genre','category','language','country']
def XxcpMKIUzr0sVDngR(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==cdZKMn68Pzg4: KFGqxsBnZYLb3NvMU,ejQ8ZCtBaV7 = cdZKMn68Pzg4,cdZKMn68Pzg4
	else: KFGqxsBnZYLb3NvMU,ejQ8ZCtBaV7 = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if fCAW9dmInLiV[0]+'=' not in KFGqxsBnZYLb3NvMU: rrb0SF6otehufCYOX4 = fCAW9dmInLiV[0]
		for WCqkctAYD2O3Hz7Fl8fKRS5 in range(len(fCAW9dmInLiV[0:-1])):
			if fCAW9dmInLiV[WCqkctAYD2O3Hz7Fl8fKRS5]+'=' in KFGqxsBnZYLb3NvMU: rrb0SF6otehufCYOX4 = fCAW9dmInLiV[WCqkctAYD2O3Hz7Fl8fKRS5+1]
		gmjZQuBFv8RzlNtDVEOc = KFGqxsBnZYLb3NvMU+'&'+rrb0SF6otehufCYOX4+'=0'
		qwmxUpZfQj8EAV3Tc = ejQ8ZCtBaV7+'&'+rrb0SF6otehufCYOX4+'=0'
		vMp6jZbo3UkEsSxRFQndyA = gmjZQuBFv8RzlNtDVEOc.strip('&')+'___'+qwmxUpZfQj8EAV3Tc.strip('&')
		YqrzmSVb3R9MgUnX2auEHlpBhZD = XFoM2xPKIt3u51hLj(ejQ8ZCtBaV7,'modified_filters')
		HOCWKhxITtulVGX = url+'/smartemadfilter?'+YqrzmSVb3R9MgUnX2auEHlpBhZD
	elif type=='ALL_ITEMS_FILTER':
		zM2ZBJ4IYN8osGTtwgRheLu6dU = XFoM2xPKIt3u51hLj(KFGqxsBnZYLb3NvMU,'modified_values')
		zM2ZBJ4IYN8osGTtwgRheLu6dU = NLqxoZ37dYf0awrsIE(zM2ZBJ4IYN8osGTtwgRheLu6dU)
		if ejQ8ZCtBaV7!=cdZKMn68Pzg4: ejQ8ZCtBaV7 = XFoM2xPKIt3u51hLj(ejQ8ZCtBaV7,'modified_filters')
		if ejQ8ZCtBaV7==cdZKMn68Pzg4: HOCWKhxITtulVGX = url
		else: HOCWKhxITtulVGX = url+'/smartemadfilter?'+ejQ8ZCtBaV7
		HOCWKhxITtulVGX = PVO4RmQY92jycoli0GtrusH(HOCWKhxITtulVGX)
		zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'أظهار قائمة الفيديو التي تم اختيارها ',HOCWKhxITtulVGX,431)
		zJLApFBcIhnSj('folder',nc3GLkA65oxOd+' [[   '+zM2ZBJ4IYN8osGTtwgRheLu6dU+'   ]]',HOCWKhxITtulVGX,431)
		zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	hQ9ADnZlSxI1m8ui = J1BMh3gS6EbcwT284RdnKzkitfUqW(url)
	dict = {}
	for name,KdWauEhgN6OQzjRVm1ro8tkB3,rfJG62Vo0pTEljwPN1WahD7sx4t3QR in hQ9ADnZlSxI1m8ui:
		name = name.replace('--',cdZKMn68Pzg4)
		items = ycYdX9u6W0oOnbMaDlf4KiPz(KdWauEhgN6OQzjRVm1ro8tkB3)
		if '=' not in HOCWKhxITtulVGX: HOCWKhxITtulVGX = url
		if type=='SPECIFIED_FILTER':
			if rrb0SF6otehufCYOX4!=rfJG62Vo0pTEljwPN1WahD7sx4t3QR: continue
			elif len(items)<2:
				if rfJG62Vo0pTEljwPN1WahD7sx4t3QR==fCAW9dmInLiV[-1]:
					url = PVO4RmQY92jycoli0GtrusH(url)
					GDQUH4fN02sIt81mAcY(url)
				else: XxcpMKIUzr0sVDngR(HOCWKhxITtulVGX,'SPECIFIED_FILTER___'+vMp6jZbo3UkEsSxRFQndyA)
				return
			else:
				HOCWKhxITtulVGX = PVO4RmQY92jycoli0GtrusH(HOCWKhxITtulVGX)
				if rfJG62Vo0pTEljwPN1WahD7sx4t3QR==fCAW9dmInLiV[-1]: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'الجميع ',HOCWKhxITtulVGX,431)
				else: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'الجميع ',HOCWKhxITtulVGX,435,cdZKMn68Pzg4,cdZKMn68Pzg4,vMp6jZbo3UkEsSxRFQndyA)
		elif type=='ALL_ITEMS_FILTER':
			gmjZQuBFv8RzlNtDVEOc = KFGqxsBnZYLb3NvMU+'&'+rfJG62Vo0pTEljwPN1WahD7sx4t3QR+'=0'
			qwmxUpZfQj8EAV3Tc = ejQ8ZCtBaV7+'&'+rfJG62Vo0pTEljwPN1WahD7sx4t3QR+'=0'
			vMp6jZbo3UkEsSxRFQndyA = gmjZQuBFv8RzlNtDVEOc+'___'+qwmxUpZfQj8EAV3Tc
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'الجميع :'+name,HOCWKhxITtulVGX,434,cdZKMn68Pzg4,cdZKMn68Pzg4,vMp6jZbo3UkEsSxRFQndyA)
		dict[rfJG62Vo0pTEljwPN1WahD7sx4t3QR] = {}
		for value,zj6FI51Rypka0e8xiECfc7g in items:
			if value=='196533': zj6FI51Rypka0e8xiECfc7g = 'أفلام نيتفلكس'
			elif value=='196531': zj6FI51Rypka0e8xiECfc7g = 'مسلسلات نيتفلكس'
			if zj6FI51Rypka0e8xiECfc7g in cJWUPuDGM0Yybv5a9KnIrVzhH78: continue
			dict[rfJG62Vo0pTEljwPN1WahD7sx4t3QR][value] = zj6FI51Rypka0e8xiECfc7g
			gmjZQuBFv8RzlNtDVEOc = KFGqxsBnZYLb3NvMU+'&'+rfJG62Vo0pTEljwPN1WahD7sx4t3QR+'='+zj6FI51Rypka0e8xiECfc7g
			qwmxUpZfQj8EAV3Tc = ejQ8ZCtBaV7+'&'+rfJG62Vo0pTEljwPN1WahD7sx4t3QR+'='+value
			AL8gJZ0NtE91Bexjin4 = gmjZQuBFv8RzlNtDVEOc+'___'+qwmxUpZfQj8EAV3Tc
			title = zj6FI51Rypka0e8xiECfc7g+' :'#+dict[rfJG62Vo0pTEljwPN1WahD7sx4t3QR]['0']
			title = zj6FI51Rypka0e8xiECfc7g+' :'+name
			if type=='ALL_ITEMS_FILTER': zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,url,434,cdZKMn68Pzg4,cdZKMn68Pzg4,AL8gJZ0NtE91Bexjin4)
			elif type=='SPECIFIED_FILTER' and fCAW9dmInLiV[-2]+'=' in KFGqxsBnZYLb3NvMU:
				N8jUpQxY0rhtDAzbG4kOs9X = QVOgIWZlpCaD1XnfLxseFSdK3GcqA(qwmxUpZfQj8EAV3Tc,url)
				zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,N8jUpQxY0rhtDAzbG4kOs9X,431)
			else: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,url,435,cdZKMn68Pzg4,cdZKMn68Pzg4,AL8gJZ0NtE91Bexjin4)
	return
def XFoM2xPKIt3u51hLj(o3JURfrMDgp76,mode):
	o3JURfrMDgp76 = o3JURfrMDgp76.replace('=&','=0&')
	o3JURfrMDgp76 = o3JURfrMDgp76.strip('&')
	bLxfgF7nlO1uZiY9e5T0HDdIw3kpy = {}
	if '=' in o3JURfrMDgp76:
		items = o3JURfrMDgp76.split('&')
		for HYBN2AQsjimSMgT8OvE3ynX67tJwR in items:
			IN0jyfe1PRdDz6YX3CoJkHthw,value = HYBN2AQsjimSMgT8OvE3ynX67tJwR.split('=')
			bLxfgF7nlO1uZiY9e5T0HDdIw3kpy[IN0jyfe1PRdDz6YX3CoJkHthw] = value
	n7VBe6ZgDI14lizTfHOmk = cdZKMn68Pzg4
	for key in w6wuL59PgeE:
		if key in list(bLxfgF7nlO1uZiY9e5T0HDdIw3kpy.keys()): value = bLxfgF7nlO1uZiY9e5T0HDdIw3kpy[key]
		else: value = '0'
		if '%' not in value: value = YQlEOShHM7RLak2t0yA4NXqv(value)
		if mode=='modified_values' and value!='0': n7VBe6ZgDI14lizTfHOmk = n7VBe6ZgDI14lizTfHOmk+' + '+value
		elif mode=='modified_filters' and value!='0': n7VBe6ZgDI14lizTfHOmk = n7VBe6ZgDI14lizTfHOmk+'&'+key+'='+value
		elif mode=='all_filters': n7VBe6ZgDI14lizTfHOmk = n7VBe6ZgDI14lizTfHOmk+'&'+key+'='+value
	n7VBe6ZgDI14lizTfHOmk = n7VBe6ZgDI14lizTfHOmk.strip(' + ')
	n7VBe6ZgDI14lizTfHOmk = n7VBe6ZgDI14lizTfHOmk.strip('&')
	n7VBe6ZgDI14lizTfHOmk = n7VBe6ZgDI14lizTfHOmk.replace('=0','=')
	return n7VBe6ZgDI14lizTfHOmk
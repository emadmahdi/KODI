# -*- coding: utf-8 -*-
from RgJNGc7YMP import *
UkXlAzsMcamKJrEIgnxi6bWh = 'SHOOFMAX'
nc3GLkA65oxOd = '_SHM_'
cDTdfqVAF0BLGiX364IEwaZbr = USuRxnPlV5.SITESURLS[UkXlAzsMcamKJrEIgnxi6bWh][0]
Nl3Tz5nOPvLKqH7jJAVs1mF2r = USuRxnPlV5.SITESURLS[UkXlAzsMcamKJrEIgnxi6bWh][1]
NSdOvMkYVXusnpbT5P6trAx2ZL8UC0 = USuRxnPlV5.SITESURLS[UkXlAzsMcamKJrEIgnxi6bWh][2]
def HHN5EpbszV3iA2m89hGSQjaPgUZy(mode,url,text):
	if   mode==50: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = kUq58vC7x9hWma164JejMKQ()
	elif mode==51: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = GDQUH4fN02sIt81mAcY(url)
	elif mode==52: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = yIZWSuMpvs3(url)
	elif mode==53: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = RPZbqous7rtdy56LeI18Cv04AKHW(url)
	elif mode==55: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = LCuN1sAc5qFobe0h9yGDnpfv4()
	elif mode==56: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = DDefqMN70L()
	elif mode==57: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = UD3BusZHCQpzAawykn9EqL0lOrjV1f(url,1)
	elif mode==58: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = UD3BusZHCQpzAawykn9EqL0lOrjV1f(url,2)
	elif mode==59: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = z4hetAJw3NaT9ROjG6xbZ5CHlW81(text)
	else: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = False
	return xsGUcR3ef6glKY5hQwpFXEaSt2mrIz
def kUq58vC7x9hWma164JejMKQ():
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'بحث في الموقع',cdZKMn68Pzg4,59,cdZKMn68Pzg4,cdZKMn68Pzg4,'_REMEMBERRESULTS_')
	zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+'المسلسلات',cdZKMn68Pzg4,56)
	zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+'الافلام',cdZKMn68Pzg4,55)
	return cdZKMn68Pzg4
def LCuN1sAc5qFobe0h9yGDnpfv4():
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'أفلام مرتبة بسنة الإنتاج',cDTdfqVAF0BLGiX364IEwaZbr+'/movie/1/yop',57)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'أفلام مرتبة بالأفضل تقييم',cDTdfqVAF0BLGiX364IEwaZbr+'/movie/1/review',57)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'أفلام مرتبة بالأكثر مشاهدة',cDTdfqVAF0BLGiX364IEwaZbr+'/movie/1/views',57)
	return
def DDefqMN70L():
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'مسلسلات مرتبة بسنة الإنتاج',cDTdfqVAF0BLGiX364IEwaZbr+'/series/1/yop',57)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'مسلسلات مرتبة بالأفضل تقييم',cDTdfqVAF0BLGiX364IEwaZbr+'/series/1/review',57)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'مسلسلات مرتبة بالأكثر مشاهدة',cDTdfqVAF0BLGiX364IEwaZbr+'/series/1/views',57)
	return
def GDQUH4fN02sIt81mAcY(url):
	if '?' in url:
		FxVBtGij82cmkq = url.split('?')
		url = FxVBtGij82cmkq[0]
		filter = '?' + YQlEOShHM7RLak2t0yA4NXqv(FxVBtGij82cmkq[1],'=&:/%')
	else: filter = cdZKMn68Pzg4
	type,aOZ3yVnsNlB974pR,sort = url.split(KCQExdbYFqM)[-3:]
	if sort in ['yop','review','views']:
		if type=='movie': BWZvnMf70Pwma='فيلم'
		elif type=='series': BWZvnMf70Pwma='مسلسل'
		url = cDTdfqVAF0BLGiX364IEwaZbr + '/genre/filter/' + YQlEOShHM7RLak2t0yA4NXqv(BWZvnMf70Pwma) + KCQExdbYFqM + aOZ3yVnsNlB974pR + KCQExdbYFqM + sort + filter
		OO1cj2REUZHJ8x5V = Gc05Efm73C8s(K8DZxE74Afz52gBYbOMtpvql0RJma,url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'SHOOFMAX-TITLES-1st')
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"pid":(.*?),.*?"ptitle":"(.*?)".+?"pepisodes":(.*?),"presbase":"(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		m5RwjZI0knHMG47NcdVYBip=0
		for id,title,fHwc9rj87CJIByshPTnpV2qDuO,y90BoFz8MA1ZThaSC2ILXHiK3OY6w in items:
			m5RwjZI0knHMG47NcdVYBip += 1
			y90BoFz8MA1ZThaSC2ILXHiK3OY6w = NSdOvMkYVXusnpbT5P6trAx2ZL8UC0 + '/v2/img/program/main/' + y90BoFz8MA1ZThaSC2ILXHiK3OY6w + '-2.jpg'
			c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr + '/program/' + id
			if type=='movie': zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,53,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
			if type=='series': zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'مسلسل '+title,c0cDhidBlOn7+'?ep='+fHwc9rj87CJIByshPTnpV2qDuO+'='+title+'='+y90BoFz8MA1ZThaSC2ILXHiK3OY6w,52,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
	else:
		if type=='movie': BWZvnMf70Pwma='movies'
		elif type=='series': BWZvnMf70Pwma='series'
		url = Nl3Tz5nOPvLKqH7jJAVs1mF2r + '/json/selected/' + sort + '-' + BWZvnMf70Pwma + '-WW.json'
		OO1cj2REUZHJ8x5V = Gc05Efm73C8s(K8DZxE74Afz52gBYbOMtpvql0RJma,url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'SHOOFMAX-TITLES-2nd')
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"ref":(.*?),"ep":(.*?),"base":"(.*?)","title":"(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		m5RwjZI0knHMG47NcdVYBip=0
		for id,fHwc9rj87CJIByshPTnpV2qDuO,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,title in items:
			m5RwjZI0knHMG47NcdVYBip += 1
			y90BoFz8MA1ZThaSC2ILXHiK3OY6w = Nl3Tz5nOPvLKqH7jJAVs1mF2r + '/img/program/' + y90BoFz8MA1ZThaSC2ILXHiK3OY6w + '-2.jpg'
			c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr + '/program/' + id
			if type=='movie': zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,53,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
			elif type=='series': zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'مسلسل '+title,c0cDhidBlOn7+'?ep='+fHwc9rj87CJIByshPTnpV2qDuO+'='+title+'='+y90BoFz8MA1ZThaSC2ILXHiK3OY6w,52,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
	title='صفحة '
	if m5RwjZI0knHMG47NcdVYBip==16:
		for PT2Oyq3GtKBap8cWDs in range(1,13) :
			if not aOZ3yVnsNlB974pR==str(PT2Oyq3GtKBap8cWDs):
				url = cDTdfqVAF0BLGiX364IEwaZbr+'/genre/filter/'+type+KCQExdbYFqM+str(PT2Oyq3GtKBap8cWDs)+KCQExdbYFqM+sort+filter
				zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title+str(PT2Oyq3GtKBap8cWDs),url,51)
	return
def yIZWSuMpvs3(url):
	FxVBtGij82cmkq = url.split('=')
	fHwc9rj87CJIByshPTnpV2qDuO = int(FxVBtGij82cmkq[1])
	name = NLqxoZ37dYf0awrsIE(FxVBtGij82cmkq[2])
	name = name.replace('_MOD_مسلسل ',cdZKMn68Pzg4)
	y90BoFz8MA1ZThaSC2ILXHiK3OY6w = FxVBtGij82cmkq[3]
	url = url.split('?')[0]
	if fHwc9rj87CJIByshPTnpV2qDuO==0:
		OO1cj2REUZHJ8x5V = Gc05Efm73C8s(K8DZxE74Afz52gBYbOMtpvql0RJma,url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'SHOOFMAX-EPISODES-1st')
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('<select(.*?)</select>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('option value="(.*?)"',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		fHwc9rj87CJIByshPTnpV2qDuO = int(items[-1])
	for E0w56WHxZPYGVvnTQ4O2t1C8DAjq in range(fHwc9rj87CJIByshPTnpV2qDuO,0,-1):
		c0cDhidBlOn7 = url + '?ep=' + str(E0w56WHxZPYGVvnTQ4O2t1C8DAjq)
		title = '_MOD_مسلسل '+name+' - الحلقة '+str(E0w56WHxZPYGVvnTQ4O2t1C8DAjq)
		zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,53,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
	return
def RPZbqous7rtdy56LeI18Cv04AKHW(url):
	OO1cj2REUZHJ8x5V = Gc05Efm73C8s(r43t1YI9deXA5N,url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'SHOOFMAX-PLAY-1st')
	nnDI1WNuXk028YE = ffUFBJQ57j2XgoGeOLn9uwpC.findall('متوفر على شوف ماكس بعد.*?moment\("(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if nnDI1WNuXk028YE:
		bD7kJZhMCdaqF68P45KlNIgO1 = nnDI1WNuXk028YE[1].replace('T',KATUbrqnhgW2GkBJzMDsREmtdo78)
		NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,'رسالة من الموقع الأصلي','هذا الفيديو سيكون متوفر على شوف ماكس بعد هذا الوقت'+ssELJkeScrtni2+bD7kJZhMCdaqF68P45KlNIgO1)
		return
	nnpf2yMjEI1Q7xASk4K3c9,bVAy38oGrjc7IHphkilSY = [],[]
	kXcFtey7rG5E8MQdTagzl = ffUFBJQ57j2XgoGeOLn9uwpC.findall('var origin_link = "(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)[0]
	kUJpQA8Bvs0HundfWlmOGIgVx = ffUFBJQ57j2XgoGeOLn9uwpC.findall('var backup_origin_link = "(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)[0]
	zz4ZPovUbyk5GEhNMs8JDnaVXftS = ffUFBJQ57j2XgoGeOLn9uwpC.findall('hls: (.*?)_link\+"(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	for wRlW4txQshKmeXdO7zABrLPT1GbZ0,c0cDhidBlOn7 in zz4ZPovUbyk5GEhNMs8JDnaVXftS:
		if 'backup' in wRlW4txQshKmeXdO7zABrLPT1GbZ0:
			wRlW4txQshKmeXdO7zABrLPT1GbZ0 = 'backup server'
			url = kUJpQA8Bvs0HundfWlmOGIgVx + c0cDhidBlOn7
		else:
			wRlW4txQshKmeXdO7zABrLPT1GbZ0 = 'main server'
			url = kXcFtey7rG5E8MQdTagzl + c0cDhidBlOn7
		if '.m3u8' in url:
			nnpf2yMjEI1Q7xASk4K3c9.append(url)
			bVAy38oGrjc7IHphkilSY.append('m3u8  '+wRlW4txQshKmeXdO7zABrLPT1GbZ0)
	zz4ZPovUbyk5GEhNMs8JDnaVXftS = ffUFBJQ57j2XgoGeOLn9uwpC.findall('mp4:.*?_link.*?\t(.*?)_link\+"(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	zz4ZPovUbyk5GEhNMs8JDnaVXftS += ffUFBJQ57j2XgoGeOLn9uwpC.findall('mp4:.*?\t(.*?)_link\+"(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	for wRlW4txQshKmeXdO7zABrLPT1GbZ0,c0cDhidBlOn7 in zz4ZPovUbyk5GEhNMs8JDnaVXftS:
		filename = c0cDhidBlOn7.split(KCQExdbYFqM)[-1]
		filename = filename.replace('fallback',cdZKMn68Pzg4)
		filename = filename.replace('.mp4',cdZKMn68Pzg4)
		filename = filename.replace('-',cdZKMn68Pzg4)
		if 'backup' in wRlW4txQshKmeXdO7zABrLPT1GbZ0:
			wRlW4txQshKmeXdO7zABrLPT1GbZ0 = 'backup server'
			url = kUJpQA8Bvs0HundfWlmOGIgVx + c0cDhidBlOn7
		else:
			wRlW4txQshKmeXdO7zABrLPT1GbZ0 = 'main server'
			url = kXcFtey7rG5E8MQdTagzl + c0cDhidBlOn7
		nnpf2yMjEI1Q7xASk4K3c9.append(url)
		bVAy38oGrjc7IHphkilSY.append('mp4  '+wRlW4txQshKmeXdO7zABrLPT1GbZ0+wr0HaqRdJ2D9LT7nSO1KMe38ly+filename)
	AS6jLpMwW5Ql3kUFNfT = NAfHLMC8Ip64FmT7l5oJWXaq3hK('Select Video Quality:', bVAy38oGrjc7IHphkilSY)
	if AS6jLpMwW5Ql3kUFNfT == -1 : return
	url = nnpf2yMjEI1Q7xASk4K3c9[AS6jLpMwW5Ql3kUFNfT]
	bmgwWLk3er(url,UkXlAzsMcamKJrEIgnxi6bWh,'video')
	return
def UD3BusZHCQpzAawykn9EqL0lOrjV1f(url,type):
	if 'series' in url: HOCWKhxITtulVGX = cDTdfqVAF0BLGiX364IEwaZbr + '/genre/مسلسل'
	else: HOCWKhxITtulVGX = cDTdfqVAF0BLGiX364IEwaZbr + '/genre/فيلم'
	HOCWKhxITtulVGX = YQlEOShHM7RLak2t0yA4NXqv(HOCWKhxITtulVGX)
	OO1cj2REUZHJ8x5V = Gc05Efm73C8s(r43t1YI9deXA5N,HOCWKhxITtulVGX,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'SHOOFMAX-FILTERS-1st')
	if type==1: ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('subgenre(.*?)div',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	elif type==2: ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('country(.*?)div',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
	items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('option value="(.*?)">(.*?)</option',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if type==1:
		for eeSQ6CgZTRwyL8PxhNb2MvAmD4W5k9,title in items:
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,url+'?subgenre='+eeSQ6CgZTRwyL8PxhNb2MvAmD4W5k9,58)
	elif type==2:
		url,eeSQ6CgZTRwyL8PxhNb2MvAmD4W5k9 = url.split('?')
		for bQ6ElSoGTsM4CgPBF3hUXNWdyZHO,title in items:
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,url+'?country='+bQ6ElSoGTsM4CgPBF3hUXNWdyZHO+'&'+eeSQ6CgZTRwyL8PxhNb2MvAmD4W5k9,51)
	return
def z4hetAJw3NaT9ROjG6xbZ5CHlW81(search):
	search,EL8zUgbXheot,showDialogs = qbIcHCMdkFKn21e(search)
	if not search: search = BzkmLuvJD9n25Pg()
	if not search: return
	nuKdVC6ePlg = search.replace(VBpIH2QSmvDGlA6TO3e,'%20')
	url = cDTdfqVAF0BLGiX364IEwaZbr+'/search?q='+nuKdVC6ePlg
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',url,cdZKMn68Pzg4,cdZKMn68Pzg4,True,cdZKMn68Pzg4,'SHOOFMAX-SEARCH-2nd')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('general-body(.*?)search-bottom-padding',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
	items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?background-image: url\((.*?)\).*?<span>(.*?)</span>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if items:
		for c0cDhidBlOn7,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,title in items:
			url = cDTdfqVAF0BLGiX364IEwaZbr + c0cDhidBlOn7
			if '/program/' in url:
				if '?ep=' in url:
					title = '_MOD_مسلسل '+title
					url = url.replace('?ep=1','?ep=0')
					url = url+'='+YQlEOShHM7RLak2t0yA4NXqv(title)+'='+y90BoFz8MA1ZThaSC2ILXHiK3OY6w
					zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,url,52,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
				else:
					title = '_MOD_فيلم '+title
					zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,url,53,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
	return
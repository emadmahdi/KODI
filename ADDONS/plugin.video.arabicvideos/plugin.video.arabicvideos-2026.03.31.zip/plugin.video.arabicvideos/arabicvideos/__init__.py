# -*- coding: utf-8 -*-
import sys as sjVE6XGymcf09qbiKODZdAC
LVpmDXhWH5wGKy1eqMB = sjVE6XGymcf09qbiKODZdAC.version_info [0] == 2
RGEuTe9PD7o45d2v = 2048
r3HIioGW0Nl = 7
def Brz09AF6apy52OuEq1s (ccr3g6sWvxSOqDiLJuF1Vf2KUtG):
	global YzIBLo1J4ZOCEPtjq
	SSzr8EskcFRLobZqtC2QeTyPg4Y = ord (ccr3g6sWvxSOqDiLJuF1Vf2KUtG [-1])
	JIf7wGht4BqbQ5Xik1mYTA3DeLvaPO = ccr3g6sWvxSOqDiLJuF1Vf2KUtG [:-1]
	ZYd0PzhKWmvFN5TfcQI = SSzr8EskcFRLobZqtC2QeTyPg4Y % len (JIf7wGht4BqbQ5Xik1mYTA3DeLvaPO)
	itRzfVamqWwLIynhGpDM4ZUe = JIf7wGht4BqbQ5Xik1mYTA3DeLvaPO [:ZYd0PzhKWmvFN5TfcQI] + JIf7wGht4BqbQ5Xik1mYTA3DeLvaPO [ZYd0PzhKWmvFN5TfcQI:]
	if LVpmDXhWH5wGKy1eqMB:
		MHSngXbpVZde6NiQc9IrCxt78 = unicode () .join ([unichr (ord (Ep0JIWsLABieR) - RGEuTe9PD7o45d2v - (D2bEPIlOQJy4dYntR3MCiKLusT + SSzr8EskcFRLobZqtC2QeTyPg4Y) % r3HIioGW0Nl) for D2bEPIlOQJy4dYntR3MCiKLusT, Ep0JIWsLABieR in enumerate (itRzfVamqWwLIynhGpDM4ZUe)])
	else:
		MHSngXbpVZde6NiQc9IrCxt78 = str () .join ([chr (ord (Ep0JIWsLABieR) - RGEuTe9PD7o45d2v - (D2bEPIlOQJy4dYntR3MCiKLusT + SSzr8EskcFRLobZqtC2QeTyPg4Y) % r3HIioGW0Nl) for D2bEPIlOQJy4dYntR3MCiKLusT, Ep0JIWsLABieR in enumerate (itRzfVamqWwLIynhGpDM4ZUe)])
	return eval (MHSngXbpVZde6NiQc9IrCxt78)
ObuCsdoDtKmhPLSMH8YGan,vbYokBuWlxeLDcdVNM60,J6jL2d7CKE0WA4lBXFPghR5eoxHb=Brz09AF6apy52OuEq1s,Brz09AF6apy52OuEq1s,Brz09AF6apy52OuEq1s
aNdix5gq7yeFHTMWhnzm8pX0Y16,dwiIAcPl04ey7Zv38Mz,zBGPHsxIiQmd7oTSORl9bAynr5kNq=J6jL2d7CKE0WA4lBXFPghR5eoxHb,vbYokBuWlxeLDcdVNM60,ObuCsdoDtKmhPLSMH8YGan
rbUkdYi32PJaRtnxhDvQs,TtyzcuW45VKA,LungQF89BqemOb32jJsZlW=zBGPHsxIiQmd7oTSORl9bAynr5kNq,dwiIAcPl04ey7Zv38Mz,aNdix5gq7yeFHTMWhnzm8pX0Y16
iRfoNckJs7Ibxzh5j92w8DSWF,NV3enkyQ7Rmp2LYAUagsCJz0ZP,HC9xWUMpBQJEuTteAqjd=LungQF89BqemOb32jJsZlW,TtyzcuW45VKA,rbUkdYi32PJaRtnxhDvQs
s8fcjBCSMxzAIkZQbJPga,AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu,liyzjA4RkEb1cT6fr5pGKdWNHOxM=HC9xWUMpBQJEuTteAqjd,NV3enkyQ7Rmp2LYAUagsCJz0ZP,iRfoNckJs7Ibxzh5j92w8DSWF
nfg30bHwd4aNV12SR7UjFck,Rsdai9xIEPcpuBMKOUwkTA05q,KNomgGw1kdMCBH=liyzjA4RkEb1cT6fr5pGKdWNHOxM,AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu,s8fcjBCSMxzAIkZQbJPga
SGazRxP3yBKZ15ILuch,YnHG75e2QWwo,S5fhsRT8JV=KNomgGw1kdMCBH,Rsdai9xIEPcpuBMKOUwkTA05q,nfg30bHwd4aNV12SR7UjFck
WupgNDhcjK1SiYsF5VLGb9w3loJqX,f8Ja1q5eO02B,xN4fKmsnyM3Y2=S5fhsRT8JV,YnHG75e2QWwo,SGazRxP3yBKZ15ILuch
uxE8MyoTRglrcaiQf,aar0zhDnJsOTP7EdgR16HIS29,opyTNwHgfqbZREWKU=xN4fKmsnyM3Y2,f8Ja1q5eO02B,WupgNDhcjK1SiYsF5VLGb9w3loJqX
On1WZJc6dtksqVNgSQ5GBAjuipe,AiCor1fIVTDxQUWwHe9vPR7,tRnTydV03Xfi7rbQ=opyTNwHgfqbZREWKU,aar0zhDnJsOTP7EdgR16HIS29,uxE8MyoTRglrcaiQf
LJPOQNK1mcG,k5oIaYyp2mnrLK49qhzS,zDek1IW37rq6UoKdwyRiAVpF=tRnTydV03Xfi7rbQ,AiCor1fIVTDxQUWwHe9vPR7,On1WZJc6dtksqVNgSQ5GBAjuipe
from kI5NbK0vO6 import *
UkXlAzsMcamKJrEIgnxi6bWh = vbYokBuWlxeLDcdVNM60(u"࠭ࡉࡏࡋࡗࠫᐊ")
ppWtKTjVzdQwmoqNi7E,YkqWMTnVUjh1rQaXpG8LR7xo,mrcsT4vGxI6o7PMayUkHdtEZXB,VvpotnYyg78jbBiuHZADl0mcRE,fh6qmOxoiv1UPXZanLprDeMI8,aOZ3yVnsNlB974pR,ttFj9PmIcsuGpzib3aS,x8FkISpTrmqPJe2nvZOWU7zuNcj,g8tTFcBGwdKlo42LUkW = AanhLX36W9emBvK(I4sncq6lxyDa03Gr5B)
RF0PjmkWc9w8Z = int(VvpotnYyg78jbBiuHZADl0mcRE)
cqGjBytdAwrYOnUPWEluH = bu6LzUQF7K.getInfoLabel(YnHG75e2QWwo(u"ࠧࡍ࡫ࡶࡸࡎࡺࡥ࡮࠰ࡏࡥࡧ࡫࡬ࠨᐋ"))
cqGjBytdAwrYOnUPWEluH = cqGjBytdAwrYOnUPWEluH.replace(AJNSwOflIdq,cdZKMn68Pzg4).replace(vuUhZiIkAo7CRpjaEr,cdZKMn68Pzg4)
if RF0PjmkWc9w8Z==J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"࠲࠷࠲ᐵ"): TSa1qFmfJIQlG78zV6WXZU9E0u = YnHG75e2QWwo(u"ࠨࠢࠣࠤ࡛࡫ࡲࡴ࡫ࡲࡲ࠿࡛ࠦࠡࠩᐌ")+cWEA5yRl3VqGKk+liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠩࠣࡡࠥࠦࠠࡌࡱࡧ࡭࠿࡛ࠦࠡࠩᐍ")+Zcl1ozMwTy0DUB7VjvENKA9W8xGXH2+S5fhsRT8JV(u"ࠪࠤࡢ࠭ᐎ")
else:
	mNWxlcPVnEIAurkgGJvysdpzaTRBL = NLqxoZ37dYf0awrsIE(I4sncq6lxyDa03Gr5B).replace(Gzygq01Kcb9U3,cdZKMn68Pzg4).replace(bxf7gZvNK29cEoiAIJlMq0dP,cdZKMn68Pzg4)
	mNWxlcPVnEIAurkgGJvysdpzaTRBL = mNWxlcPVnEIAurkgGJvysdpzaTRBL.replace(kH8E2zqNyims6KJfI,cdZKMn68Pzg4).strip(VBpIH2QSmvDGlA6TO3e)
	mNWxlcPVnEIAurkgGJvysdpzaTRBL = mNWxlcPVnEIAurkgGJvysdpzaTRBL.replace(KATUbrqnhgW2GkBJzMDsREmtdo78,VBpIH2QSmvDGlA6TO3e).replace(U4ImogGksPlcBVfAb,VBpIH2QSmvDGlA6TO3e).replace(wr0HaqRdJ2D9LT7nSO1KMe38ly,VBpIH2QSmvDGlA6TO3e)
	if k5oIaYyp2mnrLK49qhzS(u"ࠫࠫࡻࡲ࡭࠿ࠪᐏ") in mNWxlcPVnEIAurkgGJvysdpzaTRBL:
		mNWxlcPVnEIAurkgGJvysdpzaTRBL,Jp8XbTB5EqjRzYPd = mNWxlcPVnEIAurkgGJvysdpzaTRBL.rsplit(WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠬࠬࡵࡳ࡮ࡀࠫᐐ"),On1WZJc6dtksqVNgSQ5GBAjuipe(u"࠲ᐶ"))
		mNWxlcPVnEIAurkgGJvysdpzaTRBL += f8Ja1q5eO02B(u"࠭ࠦࡶࡴ࡯ࡁࠬᐑ")+FOkLsAqwop0x3mciC62dRZag8VEGY(Jp8XbTB5EqjRzYPd,UkXlAzsMcamKJrEIgnxi6bWh)
	TSa1qFmfJIQlG78zV6WXZU9E0u = aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠧࠡࠢࠣࡐࡦࡨࡥ࡭࠼ࠣ࡟ࠥ࠭ᐒ")+cqGjBytdAwrYOnUPWEluH+aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠨࠢࡠࠤࠥࠦࡍࡰࡦࡨ࠾ࠥࡡࠠࠨᐓ")+VvpotnYyg78jbBiuHZADl0mcRE+KNomgGw1kdMCBH(u"ࠩࠣࡡࠥࠦࠠࡑࡣࡷ࡬࠿࡛ࠦࠡࠩᐔ")+mNWxlcPVnEIAurkgGJvysdpzaTRBL+SGazRxP3yBKZ15ILuch(u"ࠪࠤࡢ࠭ᐕ")
iUESurfB2zWZwt71VxdTv0NRa = AiCor1fIVTDxQUWwHe9vPR7(u"ࠫࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠫᐖ")
SsziMZd5UbeL2NRxVpwjO(F0FeocLXmbJhdBwQnS18PCHZIU,iUESurfB2zWZwt71VxdTv0NRa+ssELJkeScrtni2+xxd7Xp5lvem(UkXlAzsMcamKJrEIgnxi6bWh)+TSa1qFmfJIQlG78zV6WXZU9E0u)
if J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠬࡥࠧᐗ") in x8FkISpTrmqPJe2nvZOWU7zuNcj: sB57UXujkE,FGhagED1KZXiwsPB = x8FkISpTrmqPJe2nvZOWU7zuNcj.split(vbYokBuWlxeLDcdVNM60(u"࠭࡟ࠨᐘ"),hiuZa0PIsErm6UC7)
else: sB57UXujkE,FGhagED1KZXiwsPB = x8FkISpTrmqPJe2nvZOWU7zuNcj,cdZKMn68Pzg4
PPrzL3OaoQHM = cdZKMn68Pzg4
if sB57UXujkE in [zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"ࠧ࠲ࠩᐙ"),nfg30bHwd4aNV12SR7UjFck(u"ࠨ࠴ࠪᐚ"),iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠩ࠶ࠫᐛ"),nfg30bHwd4aNV12SR7UjFck(u"ࠪ࠸ࠬᐜ"),On1WZJc6dtksqVNgSQ5GBAjuipe(u"ࠫ࠺࠭ᐝ"),vbYokBuWlxeLDcdVNM60(u"ࠬ࠷࠱ࠨᐞ"),KNomgGw1kdMCBH(u"࠭࠱࠳ࠩᐟ"),s8fcjBCSMxzAIkZQbJPga(u"ࠧ࠲࠵ࠪᐠ")] and (S5fhsRT8JV(u"ࠨࡃࡇࡈࠬᐡ") in FGhagED1KZXiwsPB or dwiIAcPl04ey7Zv38Mz(u"ࠩࡕࡉࡒࡕࡖࡆࠩᐢ") in FGhagED1KZXiwsPB or AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"࡙ࠪࡕ࠭ᐣ") in FGhagED1KZXiwsPB or xN4fKmsnyM3Y2(u"ࠫࡉࡕࡗࡏࠩᐤ") in FGhagED1KZXiwsPB):
	USuRxnPlV5.xUMtw80gPFOkSKNb7podmjzE = IZQbmFzLHDtXfc
	USuRxnPlV5.resolveonly = IZQbmFzLHDtXfc
	JuvIbFsth7DQg6Y5MP8xG = ksTLSoVGg0ht
	from tl2c8gLbnA import nCgwEFhXp1z9jSokQqBLYW
	nCgwEFhXp1z9jSokQqBLYW(x8FkISpTrmqPJe2nvZOWU7zuNcj,sB57UXujkE,FGhagED1KZXiwsPB)
	Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.setSetting(AiCor1fIVTDxQUWwHe9vPR7(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡴࡨࡪࡷ࡫ࡳࡩࠩᐥ"),I4sncq6lxyDa03Gr5B)
elif not sB57UXujkE and not qqYeaz369sxbmjwviyhrQTC1 and RF0PjmkWc9w8Z in [k5oIaYyp2mnrLK49qhzS(u"࠴࠶࠹ᐷ"),LungQF89BqemOb32jJsZlW(u"࠺࠵࠺ᐸ")]:
	USuRxnPlV5.xUMtw80gPFOkSKNb7podmjzE = ksTLSoVGg0ht
	USuRxnPlV5.resolveonly = IZQbmFzLHDtXfc
	JuvIbFsth7DQg6Y5MP8xG = IZQbmFzLHDtXfc
	e3e5Wr7HPcK6RbEwXTmu = str(g8tTFcBGwdKlo42LUkW[Rsdai9xIEPcpuBMKOUwkTA05q(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᐦ")])
	UkXlAzsMcamKJrEIgnxi6bWh = NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠧࡊࡒࡗ࡚ࠬᐧ") if RF0PjmkWc9w8Z==tRnTydV03Xfi7rbQ(u"࠶࠸࠻ᐹ") else vbYokBuWlxeLDcdVNM60(u"ࠨࡏ࠶࡙ࠬᐨ")
	wimRPTNYfb7 = UkXlAzsMcamKJrEIgnxi6bWh.lower()
	wbIl8gEPfoLVHAjGX = Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.getSetting(zDek1IW37rq6UoKdwyRiAVpF(u"ࠩࡤࡺ࠳࠭ᐩ")+wimRPTNYfb7+KNomgGw1kdMCBH(u"ࠪ࠲ࡺࡹࡥࡳࡣࡪࡩࡳࡺ࡟ࠨᐪ")+e3e5Wr7HPcK6RbEwXTmu)
	BTxbqm5VtWyhe7 = Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.getSetting(NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠫࡦࡼ࠮ࠨᐫ")+wimRPTNYfb7+xN4fKmsnyM3Y2(u"ࠬ࠴ࡲࡦࡨࡨࡶࡪࡸ࡟ࠨᐬ")+e3e5Wr7HPcK6RbEwXTmu)
	if wbIl8gEPfoLVHAjGX or BTxbqm5VtWyhe7:
		mrcsT4vGxI6o7PMayUkHdtEZXB += KNomgGw1kdMCBH(u"࠭ࡼࠨᐭ")
		if wbIl8gEPfoLVHAjGX: mrcsT4vGxI6o7PMayUkHdtEZXB += tRnTydV03Xfi7rbQ(u"ࠧࠧࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࡂ࠭ᐮ")+wbIl8gEPfoLVHAjGX
		if BTxbqm5VtWyhe7: mrcsT4vGxI6o7PMayUkHdtEZXB += zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"ࠨࠨࡕࡩ࡫࡫ࡲࡦࡴࡀࠫᐯ")+BTxbqm5VtWyhe7
		mrcsT4vGxI6o7PMayUkHdtEZXB = mrcsT4vGxI6o7PMayUkHdtEZXB.replace(WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠩࡿࠪࠬᐰ"),dwiIAcPl04ey7Zv38Mz(u"ࠪࢀࠬᐱ"))
	clUPLsEjhHT1Nnt3S = Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.getSetting(NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠫࡦࡼ࠮ࠨᐲ")+wimRPTNYfb7+f8Ja1q5eO02B(u"ࠬ࠴ࡳࡦࡴࡹࡩࡷࡥࠧᐳ")+e3e5Wr7HPcK6RbEwXTmu)
	if clUPLsEjhHT1Nnt3S:
		o6UJrY74yWEwu12zK5SseOBlx3 = ffUFBJQ57j2XgoGeOLn9uwpC.findall(s8fcjBCSMxzAIkZQbJPga(u"࠭࠺࠰࠱ࠫ࠲࠯ࡅࠩ࠰ࠩᐴ"),mrcsT4vGxI6o7PMayUkHdtEZXB,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		mrcsT4vGxI6o7PMayUkHdtEZXB = mrcsT4vGxI6o7PMayUkHdtEZXB.replace(o6UJrY74yWEwu12zK5SseOBlx3[nnsBpJv6XL3OzHoe4Vuhr],clUPLsEjhHT1Nnt3S)
	bmgwWLk3er(mrcsT4vGxI6o7PMayUkHdtEZXB,UkXlAzsMcamKJrEIgnxi6bWh,ppWtKTjVzdQwmoqNi7E)
else:
	USuRxnPlV5.xUMtw80gPFOkSKNb7podmjzE = ksTLSoVGg0ht
	USuRxnPlV5.resolveonly = ksTLSoVGg0ht
	JuvIbFsth7DQg6Y5MP8xG = ksTLSoVGg0ht
	import RgJNGc7YMP
	try: RgJNGc7YMP.ZMJLlOs8mI6tn3DNQzU(ppWtKTjVzdQwmoqNi7E,YkqWMTnVUjh1rQaXpG8LR7xo,mrcsT4vGxI6o7PMayUkHdtEZXB,VvpotnYyg78jbBiuHZADl0mcRE,fh6qmOxoiv1UPXZanLprDeMI8,aOZ3yVnsNlB974pR,ttFj9PmIcsuGpzib3aS,x8FkISpTrmqPJe2nvZOWU7zuNcj,g8tTFcBGwdKlo42LUkW,RF0PjmkWc9w8Z,sB57UXujkE,FGhagED1KZXiwsPB,cqGjBytdAwrYOnUPWEluH)
	except Exception as slLdQivRgqyEecYfkj1MZXxhP3: PPrzL3OaoQHM = tBFq6lJxpriTH8XsOEQA.format_exc()
FFMEqG9Pbe5uKy680lHIQDhx2Ta(USuRxnPlV5.xUMtw80gPFOkSKNb7podmjzE,PPrzL3OaoQHM,JuvIbFsth7DQg6Y5MP8xG)
# -*- coding: utf-8 -*-
from RgJNGc7YMP import *
UkXlAzsMcamKJrEIgnxi6bWh = 'CIMANOW'
nc3GLkA65oxOd = '_CMN_'
cDTdfqVAF0BLGiX364IEwaZbr = USuRxnPlV5.SITESURLS[UkXlAzsMcamKJrEIgnxi6bWh][0]
cJWUPuDGM0Yybv5a9KnIrVzhH78 = ['قائمتي']
def HHN5EpbszV3iA2m89hGSQjaPgUZy(mode,url,text):
	if   mode==300: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = kUq58vC7x9hWma164JejMKQ()
	elif mode==301: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = oQF2hgjusp8Ne(url)
	elif mode==302: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = GDQUH4fN02sIt81mAcY(url)
	elif mode==303: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = B7G46YUWzH0D1XRKO(url)
	elif mode==304: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = yIZWSuMpvs3(url)
	elif mode==305: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = RPZbqous7rtdy56LeI18Cv04AKHW(url)
	elif mode==306: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = wbR96iuFa7sg2E1ndcLxm()
	elif mode==309: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = z4hetAJw3NaT9ROjG6xbZ5CHlW81(text)
	else: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = False
	return xsGUcR3ef6glKY5hQwpFXEaSt2mrIz
def kUq58vC7x9hWma164JejMKQ():
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'بحث في الموقع',cdZKMn68Pzg4,309,cdZKMn68Pzg4,cdZKMn68Pzg4,'_REMEMBERRESULTS_')
	zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(r43t1YI9deXA5N,'GET',cDTdfqVAF0BLGiX364IEwaZbr+'/home',cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'CIMANOW-MENU-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('<header(.*?)</header>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
	items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('<li><a href="(.*?)">(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	for c0cDhidBlOn7,title in items:
		title = title.strip(VBpIH2QSmvDGlA6TO3e)
		if not any(value in title for value in cJWUPuDGM0Yybv5a9KnIrVzhH78):
			zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+title,c0cDhidBlOn7,301)
	zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	oQF2hgjusp8Ne(cDTdfqVAF0BLGiX364IEwaZbr+'/home',OO1cj2REUZHJ8x5V)
	return OO1cj2REUZHJ8x5V
def wbR96iuFa7sg2E1ndcLxm():
	NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,'موقع سيما ناو بطيء من المصدر .. بسبب قيام أصحاب الموقع بتشفير محتويات جميع صفحات الموقع .. والوقت الضائع يذهب في معالجة تشفير الصفحات المشفرة قبل عرض محتوياتها في قوائم هذا البرنامج')
	return
def oQF2hgjusp8Ne(url,OO1cj2REUZHJ8x5V=cdZKMn68Pzg4):
	if not OO1cj2REUZHJ8x5V:
		Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(r43t1YI9deXA5N,'GET',url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'CIMANOW-SUBMENU-1st')
		OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	udsnZkQyF3Air1Jfa = 0
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('<section>.*?</section>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	for KdWauEhgN6OQzjRVm1ro8tkB3 in ppvsMqCHf8SEzxQg:
		udsnZkQyF3Air1Jfa += 1
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('<section>.*?<span>(.*?)<(.*?)href="(.*?)"',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for title,pw5AYBfqRMt8h0kUbV2zQISCc1NK,c0cDhidBlOn7 in items:
			title = title.strip(VBpIH2QSmvDGlA6TO3e)
			if title==cdZKMn68Pzg4: title = 'بووووو'
			if 'em><a' not in pw5AYBfqRMt8h0kUbV2zQISCc1NK:
				if KdWauEhgN6OQzjRVm1ro8tkB3.count('/category/')>0:
					RQ6kcmed3DvwrX58qHEu = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)"',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
					for c0cDhidBlOn7 in RQ6kcmed3DvwrX58qHEu:
						title = c0cDhidBlOn7.split(KCQExdbYFqM)[-2]
						zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,301)
					continue
				else: c0cDhidBlOn7 = url+'?sequence='+str(udsnZkQyF3Air1Jfa)
			if not any(value in title for value in cJWUPuDGM0Yybv5a9KnIrVzhH78):
				zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,302)
	if not ppvsMqCHf8SEzxQg: GDQUH4fN02sIt81mAcY(url,OO1cj2REUZHJ8x5V)
	return
def GDQUH4fN02sIt81mAcY(url,OO1cj2REUZHJ8x5V=cdZKMn68Pzg4):
	if OO1cj2REUZHJ8x5V==cdZKMn68Pzg4:
		Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'CIMANOW-TITLES-1st')
		OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	if '?sequence=' in url:
		url,udsnZkQyF3Air1Jfa = url.split('?sequence=')
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('(<section>.*?</section>)',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[int(udsnZkQyF3Air1Jfa)-1]
	else:
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"posts"(.*?)</body>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
	items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('<a.*?href="(.*?)"(.*?)data-src="(.*?)"',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	KRmzvoWYyxfXw37SEh1Q = []
	for c0cDhidBlOn7,data,y90BoFz8MA1ZThaSC2ILXHiK3OY6w in items:
		title = ffUFBJQ57j2XgoGeOLn9uwpC.findall('<em>(.*?)</em>(.*?)</li>.*?</em>(.*?)<em>',data,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if title: title = title[0][2].replace(ssELJkeScrtni2,cdZKMn68Pzg4).strip(VBpIH2QSmvDGlA6TO3e)
		if not title or title==cdZKMn68Pzg4:
			title = ffUFBJQ57j2XgoGeOLn9uwpC.findall('title">.*?</em>(.*?)<',data,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			if title: title = title[0].replace(ssELJkeScrtni2,cdZKMn68Pzg4).strip(VBpIH2QSmvDGlA6TO3e)
			if not title or title==cdZKMn68Pzg4:
				title = ffUFBJQ57j2XgoGeOLn9uwpC.findall('title">(.*?)<',data,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
				title = title[0].replace(ssELJkeScrtni2,cdZKMn68Pzg4).strip(VBpIH2QSmvDGlA6TO3e)
		title = gbd90SjF2mZqf81IRDaTwJkWu(title)
		title = title.replace(wr0HaqRdJ2D9LT7nSO1KMe38ly,VBpIH2QSmvDGlA6TO3e)
		if title not in KRmzvoWYyxfXw37SEh1Q:
			KRmzvoWYyxfXw37SEh1Q.append(title)
			PfGSURJ9jeNtx7FX = c0cDhidBlOn7+data+y90BoFz8MA1ZThaSC2ILXHiK3OY6w
			if '/selary/' in PfGSURJ9jeNtx7FX or 'مسلسل' in PfGSURJ9jeNtx7FX or '"episode"' in PfGSURJ9jeNtx7FX:
				if 'برامج' in data: title = 'برنامج '+title
				elif 'مسلسل' in data or 'موسم' in data: title = 'مسلسل '+title
				zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,303,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
			else: zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,305,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"pagination"(.*?)</div>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('<li><a href="(.*?)">(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,title in items:
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'صفحة '+title,c0cDhidBlOn7,302)
	return
def B7G46YUWzH0D1XRKO(url):
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'CIMANOW-SEASONS-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	name = ffUFBJQ57j2XgoGeOLn9uwpC.findall('<title>(.*?)</title>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if name:
		name = name[0].replace('| سيما ناو',cdZKMn68Pzg4).replace('Cima Now',cdZKMn68Pzg4).strip(VBpIH2QSmvDGlA6TO3e).replace(wr0HaqRdJ2D9LT7nSO1KMe38ly,VBpIH2QSmvDGlA6TO3e)
		name = name.split('الحلقة')[0].strip(VBpIH2QSmvDGlA6TO3e)+' - '
	else: name = cdZKMn68Pzg4
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('<section(.*?)</section>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)">(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if len(items)>1:
			for c0cDhidBlOn7,title in items:
				title = name+title.replace(ssELJkeScrtni2,cdZKMn68Pzg4).strip(VBpIH2QSmvDGlA6TO3e)
				zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,304)
		elif len(items)==1:
			c0cDhidBlOn7,title = items[0]
			yIZWSuMpvs3(c0cDhidBlOn7)
		else: yIZWSuMpvs3(url)
	return
def yIZWSuMpvs3(url):
	if '/selary/' not in url: url = url.strip(KCQExdbYFqM)+'/watching'
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'CIMANOW-EPISODES-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	if '/selary/' not in url:
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"episodes"(.*?)</ul>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[nnsBpJv6XL3OzHoe4Vuhr]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)">(.*?)</a>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,title in items:
			title = title.replace(ssELJkeScrtni2,cdZKMn68Pzg4).strip(VBpIH2QSmvDGlA6TO3e)
			title = 'الحلقة '+title
			zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,305)
	else:
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"details"(.*?)"related"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[nnsBpJv6XL3OzHoe4Vuhr]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?src=.*?src="(.*?)".*?alt="(.*?)"',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,title in items:
			title = title.replace(ssELJkeScrtni2,cdZKMn68Pzg4).strip(VBpIH2QSmvDGlA6TO3e)
			zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,305,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
	return
def RPZbqous7rtdy56LeI18Cv04AKHW(url):
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'CIMANOW-PLAY-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	qEUfsD9YnF4JWhXkK = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="shine" href="(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if qEUfsD9YnF4JWhXkK:
		wRlW4txQshKmeXdO7zABrLPT1GbZ0 = CxlbPZwGTcH87e1sWhfSIz29uRUEpV(qEUfsD9YnF4JWhXkK[0],'url')
		headers = {'Referer':wRlW4txQshKmeXdO7zABrLPT1GbZ0}
	else: headers = cdZKMn68Pzg4
	HOCWKhxITtulVGX = url+'watching/'
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',HOCWKhxITtulVGX,cdZKMn68Pzg4,headers,cdZKMn68Pzg4,cdZKMn68Pzg4,'CIMANOW-PLAY-5th')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	pcX7zxFRmsADwUr = []
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"download"(.*?)</ul>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?</i>(.*?)</a>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,title in items:
			title = title.replace(ssELJkeScrtni2,cdZKMn68Pzg4).strip(VBpIH2QSmvDGlA6TO3e)
			l1MCIuwhAELbO2eJ96kNta7rp0B = ffUFBJQ57j2XgoGeOLn9uwpC.findall('\d\d\d+',title,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			if l1MCIuwhAELbO2eJ96kNta7rp0B:
				l1MCIuwhAELbO2eJ96kNta7rp0B = '____'+l1MCIuwhAELbO2eJ96kNta7rp0B[0]
				title = CxlbPZwGTcH87e1sWhfSIz29uRUEpV(c0cDhidBlOn7,'name')
			else: l1MCIuwhAELbO2eJ96kNta7rp0B = cdZKMn68Pzg4
			cz5qCJd6O3g4ISxVa1EtQpysvGHPk = c0cDhidBlOn7+'?named='+title+'__download'+l1MCIuwhAELbO2eJ96kNta7rp0B
			pcX7zxFRmsADwUr.append(cz5qCJd6O3g4ISxVa1EtQpysvGHPk)
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"watch"(.*?)</ul>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		zz4ZPovUbyk5GEhNMs8JDnaVXftS = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"embed".*?src="(.*?)"',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7 in zz4ZPovUbyk5GEhNMs8JDnaVXftS:
			if 'http' not in c0cDhidBlOn7: c0cDhidBlOn7 = 'http:'+c0cDhidBlOn7
			title = CxlbPZwGTcH87e1sWhfSIz29uRUEpV(c0cDhidBlOn7,'name')
			c0cDhidBlOn7 = c0cDhidBlOn7+'?named='+title+'__embed'
			pcX7zxFRmsADwUr.append(c0cDhidBlOn7)
		zz4ZPovUbyk5GEhNMs8JDnaVXftS = [cDTdfqVAF0BLGiX364IEwaZbr+'/wp-content/themes/Cima%20Now%20New/core.php']
		if zz4ZPovUbyk5GEhNMs8JDnaVXftS:
			items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('data-index="(.*?)".*?data-id="(.*?)".*?>(.*?)</li>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			for OMQouSr6t7xL,id,title in items:
				title = title.replace(ssELJkeScrtni2,cdZKMn68Pzg4).strip(VBpIH2QSmvDGlA6TO3e)
				c0cDhidBlOn7 = zz4ZPovUbyk5GEhNMs8JDnaVXftS[0]+'?action=switch&index='+OMQouSr6t7xL+'&id='+id+'?named='+title+'__watch'
				pcX7zxFRmsADwUr.append(c0cDhidBlOn7)
	import r0y4XTKznF
	r0y4XTKznF.noHliPXkcg3pJTdSauCvm5sU(pcX7zxFRmsADwUr,UkXlAzsMcamKJrEIgnxi6bWh,'video',url)
	return
def z4hetAJw3NaT9ROjG6xbZ5CHlW81(search):
	search,EL8zUgbXheot,showDialogs = qbIcHCMdkFKn21e(search)
	if search==cdZKMn68Pzg4: search = BzkmLuvJD9n25Pg()
	if search==cdZKMn68Pzg4: return
	search = search.replace(VBpIH2QSmvDGlA6TO3e,'+')
	url = cDTdfqVAF0BLGiX364IEwaZbr + '/?s='+search
	GDQUH4fN02sIt81mAcY(url)
	return
﻿# -*- coding: utf-8 -*-
from RgJNGc7YMP import *
UkXlAzsMcamKJrEIgnxi6bWh = 'ALMAAREF'
headers = {'User-Agent':cdZKMn68Pzg4}
nc3GLkA65oxOd = '_MRF_'
cDTdfqVAF0BLGiX364IEwaZbr = USuRxnPlV5.SITESURLS[UkXlAzsMcamKJrEIgnxi6bWh][0]
cJWUPuDGM0Yybv5a9KnIrVzhH78 = ['التواصل الاجتماعي','صور التواصل الاجتماعي','أرشيف جميع البرامج']
def HHN5EpbszV3iA2m89hGSQjaPgUZy(mode,url,text,aOZ3yVnsNlB974pR):
	if   mode==40: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = kUq58vC7x9hWma164JejMKQ()
	elif mode==41: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = CGOjMRlNnBafrtz()
	elif mode==42: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = GbOpW3NmLQt0(text,aOZ3yVnsNlB974pR)
	elif mode==43: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = RPZbqous7rtdy56LeI18Cv04AKHW(url)
	elif mode==44: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = GDQUH4fN02sIt81mAcY(text,aOZ3yVnsNlB974pR)
	elif mode==49: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = z4hetAJw3NaT9ROjG6xbZ5CHlW81(text)
	else: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = False
	return xsGUcR3ef6glKY5hQwpFXEaSt2mrIz
def kUq58vC7x9hWma164JejMKQ():
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'بحث في الموقع',cdZKMn68Pzg4,49)
	zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	zJLApFBcIhnSj('live',nc3GLkA65oxOd+'البث الحي لقناة المعارف',cdZKMn68Pzg4,41)
	GbOpW3NmLQt0(cdZKMn68Pzg4,'1')
	return
def EaY6HTgvVCt9(EL8zUgbXheot,vn7ZaSMYX3V8UyuCb):
	search,sort,uUlpK8jRfLE9tT17mVwZv5,rrb0SF6otehufCYOX4,cvuOmhBKflpGYnLj5 = cdZKMn68Pzg4,[],[],[],[]
	tYPfm3ISxD,YNdoFuTiayZJt8WBUc7gP9v4 = sRAznbuQ5jiN09o4V8tpEYSlG7fe(EL8zUgbXheot)
	for zj6FI51Rypka0e8xiECfc7g in list(YNdoFuTiayZJt8WBUc7gP9v4.keys()):
		value = YNdoFuTiayZJt8WBUc7gP9v4[zj6FI51Rypka0e8xiECfc7g]
		if not value: continue
		if   zj6FI51Rypka0e8xiECfc7g=='sort': sort = [value]
		elif zj6FI51Rypka0e8xiECfc7g=='series': uUlpK8jRfLE9tT17mVwZv5 = [value]
		elif zj6FI51Rypka0e8xiECfc7g=='search': search = value
		elif zj6FI51Rypka0e8xiECfc7g=='category': rrb0SF6otehufCYOX4 = [value]
		elif zj6FI51Rypka0e8xiECfc7g=='specialist': cvuOmhBKflpGYnLj5 = [value]
	jYazNf8LMbPRh09gt5 = {"action":"facetwp_refresh","data":{"facets":{"search":search,"video_categories":rrb0SF6otehufCYOX4,"specialist":cvuOmhBKflpGYnLj5,"series":uUlpK8jRfLE9tT17mVwZv5,"number":[],"sort_video":sort,"count":[],"pagination":[]},"frozen_facets":{},"template":"video_desktop_posts","extras":{"sort":"default"},"soft_refresh":0,"is_bfcache":1,"first_load":0,"paged":int(vn7ZaSMYX3V8UyuCb)}}
	jYazNf8LMbPRh09gt5 = sJB3aL8gGVrRU.dumps(jYazNf8LMbPRh09gt5)
	c0cDhidBlOn7 = 'https://almaaref.ch/wp-json/facetwp/v1/refresh'
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'POST',c0cDhidBlOn7,jYazNf8LMbPRh09gt5,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'ALMAAREF-REQUEST_DATA_PAGE-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	data = lMeKd3hC6cmS('dict',OO1cj2REUZHJ8x5V)
	return data
def GbOpW3NmLQt0(EL8zUgbXheot,level):
	akIvSitzr0mKe = EaY6HTgvVCt9(EL8zUgbXheot,'1')
	KdWauEhgN6OQzjRVm1ro8tkB3 = akIvSitzr0mKe['facets']
	if level=='1':
		KdWauEhgN6OQzjRVm1ro8tkB3 = KdWauEhgN6OQzjRVm1ro8tkB3['video_categories']
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('<div(.*?)/div>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for HYBN2AQsjimSMgT8OvE3ynX67tJwR in items:
			a6ihlXO2CxHKrTuoknwzQ3cPBNGULj = ffUFBJQ57j2XgoGeOLn9uwpC.findall('data-value=\\"(.*?)\\".*?display-value\\">(.*?)<',HYBN2AQsjimSMgT8OvE3ynX67tJwR+'<',ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			if not a6ihlXO2CxHKrTuoknwzQ3cPBNGULj: a6ihlXO2CxHKrTuoknwzQ3cPBNGULj = ffUFBJQ57j2XgoGeOLn9uwpC.findall('data-value=\\"(.*?)\\">(.*?)<',HYBN2AQsjimSMgT8OvE3ynX67tJwR+'<',ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			rrb0SF6otehufCYOX4,title = a6ihlXO2CxHKrTuoknwzQ3cPBNGULj[0]
			if xicJPb0AW1nsRfH3kCv7: title = XTL0AWmwbDJfGRNi(title)
			if not EL8zUgbXheot: zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+title,cdZKMn68Pzg4,42,cdZKMn68Pzg4,'2','?category='+rrb0SF6otehufCYOX4)
			else: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,cdZKMn68Pzg4,42,cdZKMn68Pzg4,'2',EL8zUgbXheot+'&category='+rrb0SF6otehufCYOX4)
	if level=='2':
		KdWauEhgN6OQzjRVm1ro8tkB3 = KdWauEhgN6OQzjRVm1ro8tkB3['specialist']
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('value="(.*?)".*?>(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for cvuOmhBKflpGYnLj5,title in items:
			if xicJPb0AW1nsRfH3kCv7: title = XTL0AWmwbDJfGRNi(title)
			if not cvuOmhBKflpGYnLj5: title = title = 'الجميع'
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,cdZKMn68Pzg4,42,cdZKMn68Pzg4,'3',EL8zUgbXheot+'&specialist='+cvuOmhBKflpGYnLj5)
	elif level=='3':
		KdWauEhgN6OQzjRVm1ro8tkB3 = KdWauEhgN6OQzjRVm1ro8tkB3['series']
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('value="(.*?)".*?>(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for uUlpK8jRfLE9tT17mVwZv5,title in items:
			if xicJPb0AW1nsRfH3kCv7: title = XTL0AWmwbDJfGRNi(title)
			if not uUlpK8jRfLE9tT17mVwZv5: title = title = 'الجميع'
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,cdZKMn68Pzg4,42,cdZKMn68Pzg4,'4',EL8zUgbXheot+'&series='+uUlpK8jRfLE9tT17mVwZv5)
	elif level=='4':
		KdWauEhgN6OQzjRVm1ro8tkB3 = KdWauEhgN6OQzjRVm1ro8tkB3['sort_video']
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('value="(.*?)".*?>(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for sort,title in items:
			if not sort: continue
			if xicJPb0AW1nsRfH3kCv7: title = XTL0AWmwbDJfGRNi(title)
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,cdZKMn68Pzg4,44,cdZKMn68Pzg4,'1',EL8zUgbXheot+'&sort='+sort)
	return
def GDQUH4fN02sIt81mAcY(EL8zUgbXheot,vn7ZaSMYX3V8UyuCb):
	akIvSitzr0mKe = EaY6HTgvVCt9(EL8zUgbXheot,vn7ZaSMYX3V8UyuCb)
	KdWauEhgN6OQzjRVm1ro8tkB3 = akIvSitzr0mKe['template']
	items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('src="(.*?)".*?href="(.*?)">(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	for y90BoFz8MA1ZThaSC2ILXHiK3OY6w,c0cDhidBlOn7,title in items:
		if xicJPb0AW1nsRfH3kCv7: title = XTL0AWmwbDJfGRNi(title)
		zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,43,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
	KdWauEhgN6OQzjRVm1ro8tkB3 = akIvSitzr0mKe['facets']['pagination']
	items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('data-page="(.*?)">(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	for aOZ3yVnsNlB974pR,title in items:
		if vn7ZaSMYX3V8UyuCb==aOZ3yVnsNlB974pR: continue
		if xicJPb0AW1nsRfH3kCv7: title = XTL0AWmwbDJfGRNi(title)
		zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'صفحة '+title,cdZKMn68Pzg4,44,cdZKMn68Pzg4,aOZ3yVnsNlB974pR,EL8zUgbXheot)
	return
def RPZbqous7rtdy56LeI18Cv04AKHW(url):
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'ALMAAREF-PLAY-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	c0cDhidBlOn7 = ffUFBJQ57j2XgoGeOLn9uwpC.findall('<video src="(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if not c0cDhidBlOn7: c0cDhidBlOn7 = ffUFBJQ57j2XgoGeOLn9uwpC.findall('youtube_url.*?(http.*?)&',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	XFj0lV5yMtS67EwbCJ9oO = []
	if c0cDhidBlOn7:
		c0cDhidBlOn7 = c0cDhidBlOn7[0].replace('\/',KCQExdbYFqM)
		XFj0lV5yMtS67EwbCJ9oO.append(c0cDhidBlOn7)
	import r0y4XTKznF
	r0y4XTKznF.noHliPXkcg3pJTdSauCvm5sU(XFj0lV5yMtS67EwbCJ9oO,UkXlAzsMcamKJrEIgnxi6bWh,'video',url)
	return
def CGOjMRlNnBafrtz():
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(r43t1YI9deXA5N,'GET',cDTdfqVAF0BLGiX364IEwaZbr+'/البث-المباشر-6',cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'ALMAAREF-LIVE-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	url = ffUFBJQ57j2XgoGeOLn9uwpC.findall('data-item=.*?(http.*?)&',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	url = url[0].replace('\/',KCQExdbYFqM)
	bmgwWLk3er(url,UkXlAzsMcamKJrEIgnxi6bWh,'live')
	return
def z4hetAJw3NaT9ROjG6xbZ5CHlW81(search):
	search,EL8zUgbXheot,showDialogs = qbIcHCMdkFKn21e(search)
	tRVA4uqBQJUl7YzgM = False
	if search==cdZKMn68Pzg4:
		search = BzkmLuvJD9n25Pg()
		tRVA4uqBQJUl7YzgM = True
	if search==cdZKMn68Pzg4: return
	if not tRVA4uqBQJUl7YzgM: GDQUH4fN02sIt81mAcY('?search='+search,'1')
	else: GbOpW3NmLQt0('?search='+search,'1')
	return
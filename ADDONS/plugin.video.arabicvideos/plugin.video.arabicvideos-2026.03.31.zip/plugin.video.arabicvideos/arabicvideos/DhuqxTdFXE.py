# -*- coding: utf-8 -*-
from RgJNGc7YMP import *
UkXlAzsMcamKJrEIgnxi6bWh = 'LIVETV'
cDTdfqVAF0BLGiX364IEwaZbr = USuRxnPlV5.SITESURLS['PYTHON'][0]
def HHN5EpbszV3iA2m89hGSQjaPgUZy(mode,url):
	if   mode==100: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = kUq58vC7x9hWma164JejMKQ()
	elif mode==101: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = yKvktsG9BnHTge4fVuREIpm83('0',True)
	elif mode==102: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = yKvktsG9BnHTge4fVuREIpm83('1',True)
	elif mode==103: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = yKvktsG9BnHTge4fVuREIpm83('2',True)
	elif mode==104: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = yKvktsG9BnHTge4fVuREIpm83('3',True)
	elif mode==105: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = RPZbqous7rtdy56LeI18Cv04AKHW(url)
	elif mode==106: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = yKvktsG9BnHTge4fVuREIpm83('4',True)
	else: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = False
	return xsGUcR3ef6glKY5hQwpFXEaSt2mrIz
def kUq58vC7x9hWma164JejMKQ():
	zJLApFBcIhnSj('folder','_M3U_'+'قوائم فيديوهات M3U',cdZKMn68Pzg4,762)
	zJLApFBcIhnSj('folder','_IPT_'+'قوائم فيديوهات IPTV',cdZKMn68Pzg4,761)
	zJLApFBcIhnSj('folder','_TV0_'+'قنوات من مواقعها الأصلية',cdZKMn68Pzg4,101)
	zJLApFBcIhnSj('folder','_TV4_'+'قنوات مختارة من يوتيوب',cdZKMn68Pzg4,106)
	zJLApFBcIhnSj('folder','_YUT_'+'قنوات عربية من يوتيوب',cdZKMn68Pzg4,147)
	zJLApFBcIhnSj('folder','_YUT_'+'قنوات أجنبية من يوتيوب',cdZKMn68Pzg4,148)
	zJLApFBcIhnSj('folder','_IFL_'+'  قناة آي فيلم من موقعهم  ',cdZKMn68Pzg4,28)
	zJLApFBcIhnSj('live','_MRF_'+'قناة المعارف من موقعهم',cdZKMn68Pzg4,41)
	zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	zJLApFBcIhnSj('folder','_TV1_'+'قنوات تلفزيونية عامة',cdZKMn68Pzg4,102)
	zJLApFBcIhnSj('folder','_TV2_'+'قنوات تلفزيونية خاصة',cdZKMn68Pzg4,103)
	zJLApFBcIhnSj('folder','_TV3_'+'قنوات تلفزيونية للفحص',cdZKMn68Pzg4,104)
	return
def yKvktsG9BnHTge4fVuREIpm83(doSG8hTOgfkb0z7cn,showDialogs=True):
	nc3GLkA65oxOd = '_TV'+doSG8hTOgfkb0z7cn+'_'
	jYazNf8LMbPRh09gt5 = {'id':cdZKMn68Pzg4,'user':USuRxnPlV5.AV_CLIENT_IDS,'function':'list','menu':doSG8hTOgfkb0z7cn}
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(AlfMBJhUD65to2WrQcb,'POST',cDTdfqVAF0BLGiX364IEwaZbr,jYazNf8LMbPRh09gt5,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'LIVETV-ITEMS-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('([^;\r\n]+?);;(.*?);;(.*?);;(.*?);;(.*?);;',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if items:
		for WCqkctAYD2O3Hz7Fl8fKRS5 in range(len(items)):
			name = items[WCqkctAYD2O3Hz7Fl8fKRS5][3]
			start = name[0:2]
			start = start.replace('al','Al')
			start = start.replace('El','Al')
			start = start.replace('AL','Al')
			start = start.replace('EL','Al')
			name = start+name[2:]
			start = name[0:3]
			start = start.replace('Al-','Al')
			start = start.replace('Al ','Al')
			name = start+name[3:]
			items[WCqkctAYD2O3Hz7Fl8fKRS5] = items[WCqkctAYD2O3Hz7Fl8fKRS5][0],items[WCqkctAYD2O3Hz7Fl8fKRS5][1],items[WCqkctAYD2O3Hz7Fl8fKRS5][2],name,items[WCqkctAYD2O3Hz7Fl8fKRS5][4]
		items = set(items)
		items = sorted(items, reverse=False, key=lambda key: key[0].lower())
		items = sorted(items, reverse=False, key=lambda key: key[3].lower())
		for MqpxmkbFcNAvGjVKoHzaw,wRlW4txQshKmeXdO7zABrLPT1GbZ0,gIK4kes9HnLF8p0itS,name,y90BoFz8MA1ZThaSC2ILXHiK3OY6w in items:
			if '#' in MqpxmkbFcNAvGjVKoHzaw: continue
			if MqpxmkbFcNAvGjVKoHzaw!='URL': name = name+Gzygq01Kcb9U3+U4ImogGksPlcBVfAb+MqpxmkbFcNAvGjVKoHzaw+kH8E2zqNyims6KJfI
			url = MqpxmkbFcNAvGjVKoHzaw+';;'+wRlW4txQshKmeXdO7zABrLPT1GbZ0+';;'+gIK4kes9HnLF8p0itS+';;'+doSG8hTOgfkb0z7cn
			zJLApFBcIhnSj('live',nc3GLkA65oxOd+cdZKMn68Pzg4+name,url,105,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
	else:
		if showDialogs: zJLApFBcIhnSj('link',nc3GLkA65oxOd+'هذه الخدمة مخصصة للمبرمج فقط',cdZKMn68Pzg4,9999)
	return
def RPZbqous7rtdy56LeI18Cv04AKHW(id):
	MqpxmkbFcNAvGjVKoHzaw,wRlW4txQshKmeXdO7zABrLPT1GbZ0,gIK4kes9HnLF8p0itS,doSG8hTOgfkb0z7cn = id.split(';;')
	url = cdZKMn68Pzg4
	if MqpxmkbFcNAvGjVKoHzaw=='URL': url = gIK4kes9HnLF8p0itS
	elif MqpxmkbFcNAvGjVKoHzaw=='YOUTUBE':
		url = USuRxnPlV5.SITESURLS['YOUTUBE'][0]+'/watch?v='+gIK4kes9HnLF8p0itS
		import r0y4XTKznF
		r0y4XTKznF.noHliPXkcg3pJTdSauCvm5sU([url],UkXlAzsMcamKJrEIgnxi6bWh,'live',url)
		return
	elif MqpxmkbFcNAvGjVKoHzaw=='GA':
		jYazNf8LMbPRh09gt5 = { 'id' : cdZKMn68Pzg4, 'user' : USuRxnPlV5.AV_CLIENT_IDS , 'function' : 'playGA1' , 'menu' : cdZKMn68Pzg4 }
		Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(AlfMBJhUD65to2WrQcb,'GET',cDTdfqVAF0BLGiX364IEwaZbr,jYazNf8LMbPRh09gt5,cdZKMn68Pzg4,False,cdZKMn68Pzg4,'LIVETV-PLAY-1st')
		if not Zty0AsgQ5jpkTh91OW.succeeded:
			NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,'هذه الخدمة مخصصة للمبرمج فقط')
			return
		OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
		cookies = Zty0AsgQ5jpkTh91OW.cookies
		A8WHmOhrecgySK4Pp = cookies['ASP.NET_SessionId']
		url = Zty0AsgQ5jpkTh91OW.headers['Location']
		jYazNf8LMbPRh09gt5 = { 'id' : gIK4kes9HnLF8p0itS , 'user' : USuRxnPlV5.AV_CLIENT_IDS , 'function' : 'playGA2' , 'menu' : cdZKMn68Pzg4 }
		headers = { 'Cookie' : 'ASP.NET_SessionId='+A8WHmOhrecgySK4Pp }
		Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(AlfMBJhUD65to2WrQcb,'GET',cDTdfqVAF0BLGiX364IEwaZbr,jYazNf8LMbPRh09gt5,headers,cdZKMn68Pzg4,cdZKMn68Pzg4,'LIVETV-PLAY-2nd')
		if not Zty0AsgQ5jpkTh91OW.succeeded:
			NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,'هذه الخدمة مخصصة للمبرمج فقط')
			return
		OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
		url = ffUFBJQ57j2XgoGeOLn9uwpC.findall('resp":"(http.*?m3u8)(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		c0cDhidBlOn7 = url[0][0]
		KD5VpOUmXSbZ96 = url[0][1]
		ZJ2wWDoygNufqL3en = 'http://38.'+wRlW4txQshKmeXdO7zABrLPT1GbZ0+'777/'+gIK4kes9HnLF8p0itS+'_HD.m3u8'+KD5VpOUmXSbZ96
		m34qFCfDyvsY1H9nMhN6 = ZJ2wWDoygNufqL3en.replace('36:7','40:7').replace('_HD.m3u8','.m3u8')
		TO2n3rNZCMoL0t4zpfSDY1xGy = ZJ2wWDoygNufqL3en.replace('36:7','42:7').replace('_HD.m3u8','.m3u8')
		lycT0JB1noerD5YANK2PbHa8QVM = ['HD','SD1','SD2']
		pcX7zxFRmsADwUr = [ZJ2wWDoygNufqL3en,m34qFCfDyvsY1H9nMhN6,TO2n3rNZCMoL0t4zpfSDY1xGy]
		AS6jLpMwW5Ql3kUFNfT = 0
		if AS6jLpMwW5Ql3kUFNfT == -1: return
		else: url = pcX7zxFRmsADwUr[AS6jLpMwW5Ql3kUFNfT]
	elif MqpxmkbFcNAvGjVKoHzaw=='NT':
		headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
		jYazNf8LMbPRh09gt5 = { 'id' : gIK4kes9HnLF8p0itS , 'user' : USuRxnPlV5.AV_CLIENT_IDS , 'function' : 'playNT' , 'menu' : doSG8hTOgfkb0z7cn }
		Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(AlfMBJhUD65to2WrQcb,'POST', cDTdfqVAF0BLGiX364IEwaZbr, jYazNf8LMbPRh09gt5, headers, False,cdZKMn68Pzg4,'LIVETV-PLAY-3rd')
		if not Zty0AsgQ5jpkTh91OW.succeeded:
			NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,'هذه الخدمة مخصصة للمبرمج فقط')
			return
		OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
		url = Zty0AsgQ5jpkTh91OW.headers['Location']
		url = url.replace('%20',VBpIH2QSmvDGlA6TO3e)
		url = url.replace('%3D','=')
		if 'Learn' in gIK4kes9HnLF8p0itS:
			url = url.replace('NTNNile',cdZKMn68Pzg4)
			url = url.replace('learning1','Learning')
	elif MqpxmkbFcNAvGjVKoHzaw=='PL':
		jYazNf8LMbPRh09gt5 = { 'id' : gIK4kes9HnLF8p0itS , 'user' : USuRxnPlV5.AV_CLIENT_IDS , 'function' : 'playPL' , 'menu' : doSG8hTOgfkb0z7cn }
		Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(AlfMBJhUD65to2WrQcb,'POST', cDTdfqVAF0BLGiX364IEwaZbr, jYazNf8LMbPRh09gt5, cdZKMn68Pzg4,False,cdZKMn68Pzg4,'LIVETV-PLAY-4th')
		if not Zty0AsgQ5jpkTh91OW.succeeded:
			NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,'هذه الخدمة مخصصة للمبرمج فقط')
			return
		OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
		url = Zty0AsgQ5jpkTh91OW.headers['Location']
		headers = {'Referer':Zty0AsgQ5jpkTh91OW.headers['Referer']}
		Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(fS25N8gAZxpbnLi3srX7PJ,'POST',url, cdZKMn68Pzg4,headers , cdZKMn68Pzg4,cdZKMn68Pzg4,'LIVETV-PLAY-5th')
		if not Zty0AsgQ5jpkTh91OW.succeeded:
			NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,'هذه الخدمة مخصصة للمبرمج فقط')
			return
		OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('source src="(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		url = items[0]
	elif MqpxmkbFcNAvGjVKoHzaw in ['TA','FM','YU','WS1','WS2','RL1','RL2']:
		if MqpxmkbFcNAvGjVKoHzaw=='TA': gIK4kes9HnLF8p0itS = id
		headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
		jYazNf8LMbPRh09gt5 = { 'id' : gIK4kes9HnLF8p0itS , 'user' : USuRxnPlV5.AV_CLIENT_IDS , 'function' : 'play'+MqpxmkbFcNAvGjVKoHzaw , 'menu' : doSG8hTOgfkb0z7cn }
		Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(AlfMBJhUD65to2WrQcb,'POST',cDTdfqVAF0BLGiX364IEwaZbr,jYazNf8LMbPRh09gt5,headers,cdZKMn68Pzg4,cdZKMn68Pzg4,'LIVETV-PLAY-6th')
		if not Zty0AsgQ5jpkTh91OW.succeeded:
			NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,'هذه الخدمة مخصصة للمبرمج فقط')
			return
		OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
		url = Zty0AsgQ5jpkTh91OW.headers['Location']
		if MqpxmkbFcNAvGjVKoHzaw=='FM':
			Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(fS25N8gAZxpbnLi3srX7PJ,'GET', url, cdZKMn68Pzg4, cdZKMn68Pzg4, False,cdZKMn68Pzg4,'LIVETV-PLAY-7th')
			url = Zty0AsgQ5jpkTh91OW.headers['Location']
			url = url.replace('https','http')
	bmgwWLk3er(url,UkXlAzsMcamKJrEIgnxi6bWh,'live')
	return
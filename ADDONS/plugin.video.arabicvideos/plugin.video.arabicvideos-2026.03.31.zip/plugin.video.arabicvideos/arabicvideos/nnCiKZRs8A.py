# -*- coding: utf-8 -*-
from RgJNGc7YMP import *
UkXlAzsMcamKJrEIgnxi6bWh = 'IFILM'
nc3GLkA65oxOd = '_IFL_'
cDTdfqVAF0BLGiX364IEwaZbr = USuRxnPlV5.SITESURLS[UkXlAzsMcamKJrEIgnxi6bWh][0]
Nl3Tz5nOPvLKqH7jJAVs1mF2r = USuRxnPlV5.SITESURLS[UkXlAzsMcamKJrEIgnxi6bWh][1]
NSdOvMkYVXusnpbT5P6trAx2ZL8UC0 = USuRxnPlV5.SITESURLS[UkXlAzsMcamKJrEIgnxi6bWh][2]
XXy6t0QWkGmgMTIs7VzbRqhlO = USuRxnPlV5.SITESURLS[UkXlAzsMcamKJrEIgnxi6bWh][3]
def HHN5EpbszV3iA2m89hGSQjaPgUZy(mode,url,aOZ3yVnsNlB974pR,text):
	if   mode==20: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = Cyz4Gr7bnvV0JUdBcLHIpRFAD2()
	elif mode==21: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = kUq58vC7x9hWma164JejMKQ(url)
	elif mode==22: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = GDQUH4fN02sIt81mAcY(url,aOZ3yVnsNlB974pR)
	elif mode==23: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = yIZWSuMpvs3(url,aOZ3yVnsNlB974pR)
	elif mode==24: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = RPZbqous7rtdy56LeI18Cv04AKHW(url,text)
	elif mode==25: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = D1fTLAseZnq50Fmyh3Kl4Gw6HEr(url)
	elif mode==27: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = CGOjMRlNnBafrtz(url)
	elif mode==28: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = XO9CDIi7NoEGnwmVdR306zH()
	elif mode==29: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = z4hetAJw3NaT9ROjG6xbZ5CHlW81(text)
	else: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = False
	return xsGUcR3ef6glKY5hQwpFXEaSt2mrIz
def Cyz4Gr7bnvV0JUdBcLHIpRFAD2():
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'عربي',cDTdfqVAF0BLGiX364IEwaZbr,21,cdZKMn68Pzg4,'101')
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'English',Nl3Tz5nOPvLKqH7jJAVs1mF2r,21,cdZKMn68Pzg4,'101')
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'فارسى',NSdOvMkYVXusnpbT5P6trAx2ZL8UC0,21,cdZKMn68Pzg4,'101')
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'فارسى 2',XXy6t0QWkGmgMTIs7VzbRqhlO,21,cdZKMn68Pzg4,'101')
	return
def XO9CDIi7NoEGnwmVdR306zH():
	zJLApFBcIhnSj('live',nc3GLkA65oxOd+'عربي',cDTdfqVAF0BLGiX364IEwaZbr,27)
	zJLApFBcIhnSj('live',nc3GLkA65oxOd+'English',Nl3Tz5nOPvLKqH7jJAVs1mF2r,27)
	zJLApFBcIhnSj('live',nc3GLkA65oxOd+'فارسى',NSdOvMkYVXusnpbT5P6trAx2ZL8UC0,27)
	zJLApFBcIhnSj('live',nc3GLkA65oxOd+'فارسى 2',XXy6t0QWkGmgMTIs7VzbRqhlO,27)
	return
def kUq58vC7x9hWma164JejMKQ(h5nrPwCSeUumH):
	UkXlAzsMcamKJrEIgnxi6bWh = h5nrPwCSeUumH
	if h5nrPwCSeUumH=='IFILM-ARABIC': h5nrPwCSeUumH = cDTdfqVAF0BLGiX364IEwaZbr
	elif h5nrPwCSeUumH=='IFILM-ENGLISH': h5nrPwCSeUumH = Nl3Tz5nOPvLKqH7jJAVs1mF2r
	else: UkXlAzsMcamKJrEIgnxi6bWh = cdZKMn68Pzg4
	GFskvRIgwN5OSx = ru4oTqviByhkteQlnAxNzCY1Zb0V(h5nrPwCSeUumH)
	if GFskvRIgwN5OSx=='ar' or UkXlAzsMcamKJrEIgnxi6bWh=='IFILM-ARABIC':
		XXmvdN2sw7IMkyW = 'بحث في الموقع'
		ARoy9XWOZtYka6Busejr = 'مسلسلات - حالية'
		wRbgsDELJBq9odiKFIu6 = 'مسلسلات - أحدث'
		QCrBfpwSzaiGFq = 'مسلسلات - أبجدي'
		A1yjLHDewVX = 'بث حي آي فيلم'
		fNcHZkKiIAM8D63x5UEFphTO9BJ2 = 'أفلام'
		U56gOoZvmMarqxc7T9pYdeW1 = 'موسيقى'
		BlKDmNdaujqOsfE0hWy = 'برامج'
	elif GFskvRIgwN5OSx=='en' or UkXlAzsMcamKJrEIgnxi6bWh=='IFILM-ENGLISH':
		XXmvdN2sw7IMkyW = 'Search in site'
		ARoy9XWOZtYka6Busejr = 'Series - Current'
		wRbgsDELJBq9odiKFIu6 = 'Series - Latest'
		QCrBfpwSzaiGFq = 'Series - Alphabet'
		A1yjLHDewVX = 'Live iFilm channel'
		fNcHZkKiIAM8D63x5UEFphTO9BJ2 = 'Movies'
		U56gOoZvmMarqxc7T9pYdeW1 = 'Music'
		BlKDmNdaujqOsfE0hWy = 'Shows'
	elif GFskvRIgwN5OSx in ['fa','fa2']:
		XXmvdN2sw7IMkyW = 'جستجو در سایت'
		ARoy9XWOZtYka6Busejr = 'سريال - جاری'
		wRbgsDELJBq9odiKFIu6 = 'سريال - آخرین'
		QCrBfpwSzaiGFq = 'سريال - الفبا'
		A1yjLHDewVX = 'پخش زنده اي فيلم'
		fNcHZkKiIAM8D63x5UEFphTO9BJ2 = 'فيلم'
		U56gOoZvmMarqxc7T9pYdeW1 = 'موسيقى'
		BlKDmNdaujqOsfE0hWy = 'برنامه ها'
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+XXmvdN2sw7IMkyW,h5nrPwCSeUumH,29,cdZKMn68Pzg4,cdZKMn68Pzg4,'_REMEMBERRESULTS_')
	zJLApFBcIhnSj('live',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+A1yjLHDewVX,h5nrPwCSeUumH,27)
	zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	doSG8hTOgfkb0z7cn = ['Series','Program','Music']
	OO1cj2REUZHJ8x5V = Gc05Efm73C8s(r43t1YI9deXA5N,h5nrPwCSeUumH+'/home',cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'IFILM-MENU-1st')
	ppvsMqCHf8SEzxQg=ffUFBJQ57j2XgoGeOLn9uwpC.findall('button-menu(.*?)/Contact',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)">(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,title in items:
			if any(value in c0cDhidBlOn7 for value in doSG8hTOgfkb0z7cn):
				url = h5nrPwCSeUumH+c0cDhidBlOn7
				if 'Series' in c0cDhidBlOn7:
					zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+ARoy9XWOZtYka6Busejr,url,22,cdZKMn68Pzg4,'100')
					zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+wRbgsDELJBq9odiKFIu6,url,22,cdZKMn68Pzg4,'101')
					zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+QCrBfpwSzaiGFq,url,22,cdZKMn68Pzg4,'201')
				elif 'Film' in c0cDhidBlOn7: zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+fNcHZkKiIAM8D63x5UEFphTO9BJ2,url,22,cdZKMn68Pzg4,'100')
				elif 'Music' in c0cDhidBlOn7: zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+U56gOoZvmMarqxc7T9pYdeW1,url,25,cdZKMn68Pzg4,'101')
				elif 'Program' in c0cDhidBlOn7: zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+BlKDmNdaujqOsfE0hWy,url,22,cdZKMn68Pzg4,'101')
	return OO1cj2REUZHJ8x5V
def D1fTLAseZnq50Fmyh3Kl4Gw6HEr(url):
	h5nrPwCSeUumH = QwyBLepgH5jiIS4lO8PVtEaKJbMcfT(url)
	OO1cj2REUZHJ8x5V = Gc05Efm73C8s(r43t1YI9deXA5N,url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'IFILM-MUSIC_MENU-1st')
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('Music-tools-header(.*?)Music-body',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
	title = ffUFBJQ57j2XgoGeOLn9uwpC.findall('<p>(.*?)</p>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)[0]
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,url,22,cdZKMn68Pzg4,'101')
	items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)">(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	for c0cDhidBlOn7,title in items:
		c0cDhidBlOn7 = h5nrPwCSeUumH + c0cDhidBlOn7
		zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,23,cdZKMn68Pzg4,'101')
	return
def GDQUH4fN02sIt81mAcY(url,aOZ3yVnsNlB974pR):
	h5nrPwCSeUumH = QwyBLepgH5jiIS4lO8PVtEaKJbMcfT(url)
	GFskvRIgwN5OSx = ru4oTqviByhkteQlnAxNzCY1Zb0V(url)
	type = url.split(KCQExdbYFqM)[-1]
	SF7ysDGaC5gWHnU = str(int(aOZ3yVnsNlB974pR)//100)
	aOZ3yVnsNlB974pR = str(int(aOZ3yVnsNlB974pR)%100)
	if type=='Series' and aOZ3yVnsNlB974pR=='0':
		OO1cj2REUZHJ8x5V = Gc05Efm73C8s(K8DZxE74Afz52gBYbOMtpvql0RJma,url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'IFILM-TITLES-1st')
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('serial-body(.*?)class="row',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?src=(.*?)>.*?h3>(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,title in items:
			title = XTL0AWmwbDJfGRNi(title)
			title = gbd90SjF2mZqf81IRDaTwJkWu(title)
			c0cDhidBlOn7 = h5nrPwCSeUumH + c0cDhidBlOn7
			y90BoFz8MA1ZThaSC2ILXHiK3OY6w = h5nrPwCSeUumH + YQlEOShHM7RLak2t0yA4NXqv(y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,23,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,SF7ysDGaC5gWHnU+'01')
	m5RwjZI0knHMG47NcdVYBip=0
	if type=='Series': rrb0SF6otehufCYOX4='3'
	if type=='Film': rrb0SF6otehufCYOX4='5'
	if type=='Program': rrb0SF6otehufCYOX4='7'
	if type in ['Series','Program','Film'] and aOZ3yVnsNlB974pR!='0':
		HOCWKhxITtulVGX = h5nrPwCSeUumH+'/Home/PageingItem?category='+rrb0SF6otehufCYOX4+'&page='+aOZ3yVnsNlB974pR+'&size=30&orderby='+SF7ysDGaC5gWHnU
		OO1cj2REUZHJ8x5V = Gc05Efm73C8s(K8DZxE74Afz52gBYbOMtpvql0RJma,HOCWKhxITtulVGX,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'IFILM-TITLES-2nd')
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"Id":(.*?),"Title":(.*?),.+?"ImageAddress_S":"(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for id,title,y90BoFz8MA1ZThaSC2ILXHiK3OY6w in items:
			title = XTL0AWmwbDJfGRNi(title)
			title = title.replace('\\',cdZKMn68Pzg4)
			title = title.replace('"',cdZKMn68Pzg4)
			m5RwjZI0knHMG47NcdVYBip += 1
			c0cDhidBlOn7 = h5nrPwCSeUumH + KCQExdbYFqM + type + '/Content/' + id
			y90BoFz8MA1ZThaSC2ILXHiK3OY6w = h5nrPwCSeUumH + YQlEOShHM7RLak2t0yA4NXqv(y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
			if type=='Film': zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,24,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,SF7ysDGaC5gWHnU+'01')
			else: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,23,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,SF7ysDGaC5gWHnU+'01')
	if type=='Music':
		OO1cj2REUZHJ8x5V = Gc05Efm73C8s(K8DZxE74Afz52gBYbOMtpvql0RJma,h5nrPwCSeUumH+'/Music/Index?page='+aOZ3yVnsNlB974pR,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'IFILM-TITLES-3rd')
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('pagination-demo(.*?)pagination-demo',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?src="(.*?)".*?<h3>(.*?)</h3>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,title in items:
			m5RwjZI0knHMG47NcdVYBip += 1
			y90BoFz8MA1ZThaSC2ILXHiK3OY6w = h5nrPwCSeUumH + y90BoFz8MA1ZThaSC2ILXHiK3OY6w
			c0cDhidBlOn7 = h5nrPwCSeUumH + c0cDhidBlOn7
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,23,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,'101')
	if m5RwjZI0knHMG47NcdVYBip>20:
		title='صفحة '
		if GFskvRIgwN5OSx=='en': title = 'Page '
		if GFskvRIgwN5OSx=='fa': title = 'صفحه '
		if GFskvRIgwN5OSx=='fa2': title = 'صفحه '
		for PT2Oyq3GtKBap8cWDs in range(1,11) :
			if not aOZ3yVnsNlB974pR==str(PT2Oyq3GtKBap8cWDs):
				Y3XILh4yQ2g = '0'+str(PT2Oyq3GtKBap8cWDs)
				zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title+str(PT2Oyq3GtKBap8cWDs),url,22,cdZKMn68Pzg4,SF7ysDGaC5gWHnU+Y3XILh4yQ2g[-2:])
	return
def yIZWSuMpvs3(url,aOZ3yVnsNlB974pR):
	if not aOZ3yVnsNlB974pR: aOZ3yVnsNlB974pR = 0
	h5nrPwCSeUumH = QwyBLepgH5jiIS4lO8PVtEaKJbMcfT(url)
	hQrBKyjMaeIUV = QwyBLepgH5jiIS4lO8PVtEaKJbMcfT(url)
	GFskvRIgwN5OSx = ru4oTqviByhkteQlnAxNzCY1Zb0V(url)
	FxVBtGij82cmkq = url.split(KCQExdbYFqM)
	id,type = FxVBtGij82cmkq[-1],FxVBtGij82cmkq[3]
	SF7ysDGaC5gWHnU = str(int(aOZ3yVnsNlB974pR)//100)
	aOZ3yVnsNlB974pR = str(int(aOZ3yVnsNlB974pR)%100)
	m5RwjZI0knHMG47NcdVYBip = 0
	if type=='Series':
		OO1cj2REUZHJ8x5V = Gc05Efm73C8s(K8DZxE74Afz52gBYbOMtpvql0RJma,url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'IFILM-EPISODES-1st')
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('Comment_panel_Item.*?p>(.*?)<i.+?var inter_ = (.*?);.*?src="(.*?)\'.*?data-url="(.*?)\'',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		title = ' - الحلقة '
		if GFskvRIgwN5OSx=='en': title = ' - Episode '
		if GFskvRIgwN5OSx=='fa': title = ' - قسمت '
		if GFskvRIgwN5OSx=='fa2': title = ' - قسمت '
		if GFskvRIgwN5OSx=='fa': bFyhc2jMA3C0SeixnHpQV = cdZKMn68Pzg4
		else: bFyhc2jMA3C0SeixnHpQV = GFskvRIgwN5OSx
		Hx3heqpDk4RIuc8o = ffUFBJQ57j2XgoGeOLn9uwpC.findall('data-video="(.*?)(\'.*?\'_)(.*?)">',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for name,count,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,c0cDhidBlOn7 in items:
			for E0w56WHxZPYGVvnTQ4O2t1C8DAjq in range(int(count),0,-1):
				eXMbRhJ3ZisUz = y90BoFz8MA1ZThaSC2ILXHiK3OY6w + bFyhc2jMA3C0SeixnHpQV + id + KCQExdbYFqM + str(E0w56WHxZPYGVvnTQ4O2t1C8DAjq) + '.png'
				ARoy9XWOZtYka6Busejr = name + title + str(E0w56WHxZPYGVvnTQ4O2t1C8DAjq)
				ARoy9XWOZtYka6Busejr = gbd90SjF2mZqf81IRDaTwJkWu(ARoy9XWOZtYka6Busejr)
				zJLApFBcIhnSj('video',nc3GLkA65oxOd+ARoy9XWOZtYka6Busejr,url,24,eXMbRhJ3ZisUz,cdZKMn68Pzg4,str(E0w56WHxZPYGVvnTQ4O2t1C8DAjq))
	elif type=='Program':
		HOCWKhxITtulVGX = h5nrPwCSeUumH+'/Home/PageingAttachmentItem?id='+str(id)+'&page='+aOZ3yVnsNlB974pR+'&size=30&orderby=1'
		OO1cj2REUZHJ8x5V = Gc05Efm73C8s(K8DZxE74Afz52gBYbOMtpvql0RJma,HOCWKhxITtulVGX,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'IFILM-EPISODES-2nd')
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('Episode":(.*?),.*?ImageAddress_S":"(.*?)".*?VideoAddress":"(.*?)".*?Discription":"(.*?)".*?Caption":"(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		title = ' - الحلقة '
		if GFskvRIgwN5OSx=='en': title = ' - Episode '
		if GFskvRIgwN5OSx=='fa': title = ' - قسمت '
		if GFskvRIgwN5OSx=='fa2': title = ' - قسمت '
		for E0w56WHxZPYGVvnTQ4O2t1C8DAjq,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,c0cDhidBlOn7,XsdxF1TKr5GWVID8AiRYkgm3,name in items:
			m5RwjZI0knHMG47NcdVYBip += 1
			eXMbRhJ3ZisUz = hQrBKyjMaeIUV + YQlEOShHM7RLak2t0yA4NXqv(y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
			name = XTL0AWmwbDJfGRNi(name)
			ARoy9XWOZtYka6Busejr = name + title + str(E0w56WHxZPYGVvnTQ4O2t1C8DAjq)
			zJLApFBcIhnSj('video',nc3GLkA65oxOd+ARoy9XWOZtYka6Busejr,HOCWKhxITtulVGX,24,eXMbRhJ3ZisUz,cdZKMn68Pzg4,str(m5RwjZI0knHMG47NcdVYBip))
	elif type=='Music':
		if 'Content' in url and 'category' not in url:
			HOCWKhxITtulVGX = h5nrPwCSeUumH+'/Music/GetTracksBy?id='+str(id)+'&page='+aOZ3yVnsNlB974pR+'&size=30&type=0'
			OO1cj2REUZHJ8x5V = Gc05Efm73C8s(K8DZxE74Afz52gBYbOMtpvql0RJma,HOCWKhxITtulVGX,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'IFILM-EPISODES-3rd')
			items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('ImageAddress_S":"(.*?)".*?VoiceAddress":"(.*?)".*?Caption":"(.*?)","Title":"(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			for y90BoFz8MA1ZThaSC2ILXHiK3OY6w,c0cDhidBlOn7,name,title in items:
				m5RwjZI0knHMG47NcdVYBip += 1
				eXMbRhJ3ZisUz = hQrBKyjMaeIUV + YQlEOShHM7RLak2t0yA4NXqv(y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
				ARoy9XWOZtYka6Busejr = name + ' - ' + title
				ARoy9XWOZtYka6Busejr = ARoy9XWOZtYka6Busejr.strip(VBpIH2QSmvDGlA6TO3e)
				ARoy9XWOZtYka6Busejr = XTL0AWmwbDJfGRNi(ARoy9XWOZtYka6Busejr)
				zJLApFBcIhnSj('video',nc3GLkA65oxOd+ARoy9XWOZtYka6Busejr,HOCWKhxITtulVGX,24,eXMbRhJ3ZisUz,cdZKMn68Pzg4,str(m5RwjZI0knHMG47NcdVYBip))
		elif 'Clips' in url:
			HOCWKhxITtulVGX = h5nrPwCSeUumH+'/Music/GetTracksBy?id=0&page='+aOZ3yVnsNlB974pR+'&size=30&type=15'
			OO1cj2REUZHJ8x5V = Gc05Efm73C8s(K8DZxE74Afz52gBYbOMtpvql0RJma,HOCWKhxITtulVGX,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'IFILM-EPISODES-4th')
			items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('ImageAddress_S":"(.*?)".*?Caption":"(.*?)".*?VideoAddress":"(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			for y90BoFz8MA1ZThaSC2ILXHiK3OY6w,title,c0cDhidBlOn7 in items:
				m5RwjZI0knHMG47NcdVYBip += 1
				eXMbRhJ3ZisUz = hQrBKyjMaeIUV + YQlEOShHM7RLak2t0yA4NXqv(y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
				ARoy9XWOZtYka6Busejr = title.strip(VBpIH2QSmvDGlA6TO3e)
				ARoy9XWOZtYka6Busejr = XTL0AWmwbDJfGRNi(ARoy9XWOZtYka6Busejr)
				zJLApFBcIhnSj('video',nc3GLkA65oxOd+ARoy9XWOZtYka6Busejr,HOCWKhxITtulVGX,24,eXMbRhJ3ZisUz,cdZKMn68Pzg4,str(m5RwjZI0knHMG47NcdVYBip))
		elif 'category' in url:
			if 'category=6' in url:
				HOCWKhxITtulVGX = h5nrPwCSeUumH+'/Music/GetTracksBy?id=0&page='+aOZ3yVnsNlB974pR+'&size=30&type=6'
				OO1cj2REUZHJ8x5V = Gc05Efm73C8s(K8DZxE74Afz52gBYbOMtpvql0RJma,HOCWKhxITtulVGX,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'IFILM-EPISODES-5th')
			elif 'category=4' in url:
				HOCWKhxITtulVGX = h5nrPwCSeUumH+'/Music/GetTracksBy?id=0&page='+aOZ3yVnsNlB974pR+'&size=30&type=4'
				OO1cj2REUZHJ8x5V = Gc05Efm73C8s(K8DZxE74Afz52gBYbOMtpvql0RJma,HOCWKhxITtulVGX,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'IFILM-EPISODES-6th')
			items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('ImageAddress_S":"(.*?)".*?VoiceAddress":"(.*?)".*?Caption":"(.*?)","Title":"(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			for y90BoFz8MA1ZThaSC2ILXHiK3OY6w,c0cDhidBlOn7,name,title in items:
				m5RwjZI0knHMG47NcdVYBip += 1
				eXMbRhJ3ZisUz = hQrBKyjMaeIUV + YQlEOShHM7RLak2t0yA4NXqv(y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
				ARoy9XWOZtYka6Busejr = name + ' - ' + title
				ARoy9XWOZtYka6Busejr = ARoy9XWOZtYka6Busejr.strip(VBpIH2QSmvDGlA6TO3e)
				ARoy9XWOZtYka6Busejr = XTL0AWmwbDJfGRNi(ARoy9XWOZtYka6Busejr)
				zJLApFBcIhnSj('video',nc3GLkA65oxOd+ARoy9XWOZtYka6Busejr,HOCWKhxITtulVGX,24,eXMbRhJ3ZisUz,cdZKMn68Pzg4,str(m5RwjZI0knHMG47NcdVYBip))
	if type=='Music' or type=='Program':
		if m5RwjZI0knHMG47NcdVYBip>25:
			title='صفحة '
			if GFskvRIgwN5OSx=='en': title = ' Page '
			if GFskvRIgwN5OSx=='fa': title = ' صفحه '
			if GFskvRIgwN5OSx=='fa2': title = ' صفحه '
			for PT2Oyq3GtKBap8cWDs in range(1,11):
				if not aOZ3yVnsNlB974pR==str(PT2Oyq3GtKBap8cWDs):
					Y3XILh4yQ2g = '0'+str(PT2Oyq3GtKBap8cWDs)
					zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title+str(PT2Oyq3GtKBap8cWDs),url,23,cdZKMn68Pzg4,SF7ysDGaC5gWHnU+Y3XILh4yQ2g[-2:])
	return
def RPZbqous7rtdy56LeI18Cv04AKHW(url,E0w56WHxZPYGVvnTQ4O2t1C8DAjq):
	hQrBKyjMaeIUV = QwyBLepgH5jiIS4lO8PVtEaKJbMcfT(url)
	lycT0JB1noerD5YANK2PbHa8QVM,pcX7zxFRmsADwUr = [],[]
	OO1cj2REUZHJ8x5V = Gc05Efm73C8s(K8DZxE74Afz52gBYbOMtpvql0RJma,url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'IFILM-PLAY-1st')
	items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('data-video="(.*?)(\'.*?\'_)(.*?)">',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if items:
		GFskvRIgwN5OSx = ru4oTqviByhkteQlnAxNzCY1Zb0V(url)
		FxVBtGij82cmkq = url.split(KCQExdbYFqM)
		id,type = FxVBtGij82cmkq[-1],FxVBtGij82cmkq[3]
		c0cDhidBlOn7 = items[0][0]+GFskvRIgwN5OSx+id+'/,'+E0w56WHxZPYGVvnTQ4O2t1C8DAjq+','+E0w56WHxZPYGVvnTQ4O2t1C8DAjq+'_'+items[0][2]
		lycT0JB1noerD5YANK2PbHa8QVM.append('m3u8')
		pcX7zxFRmsADwUr.append(c0cDhidBlOn7)
	items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('data-url="(http.*?)(\'.*?\')(\..*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if items:
		GFskvRIgwN5OSx = ru4oTqviByhkteQlnAxNzCY1Zb0V(url)
		FxVBtGij82cmkq = url.split(KCQExdbYFqM)
		id,type = FxVBtGij82cmkq[-1],FxVBtGij82cmkq[3]
		c0cDhidBlOn7 = items[0][0]+GFskvRIgwN5OSx+id+KCQExdbYFqM+E0w56WHxZPYGVvnTQ4O2t1C8DAjq+items[0][2]
		lycT0JB1noerD5YANK2PbHa8QVM.append('mp4 url')
		pcX7zxFRmsADwUr.append(c0cDhidBlOn7)
	items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('source src="(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	for c0cDhidBlOn7 in items:
		c0cDhidBlOn7 = c0cDhidBlOn7.replace(Tf2ZPslXS84Yw15aNkjQ7oOzqMc,KCQExdbYFqM)
		lycT0JB1noerD5YANK2PbHa8QVM.append('mp4 src')
		pcX7zxFRmsADwUr.append(c0cDhidBlOn7)
	items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('VideoAddress":"(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if items:
		c0cDhidBlOn7 = items[int(E0w56WHxZPYGVvnTQ4O2t1C8DAjq)-1]
		c0cDhidBlOn7 = hQrBKyjMaeIUV+YQlEOShHM7RLak2t0yA4NXqv(c0cDhidBlOn7)
		lycT0JB1noerD5YANK2PbHa8QVM.append('mp4 address')
		pcX7zxFRmsADwUr.append(c0cDhidBlOn7)
	items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('VoiceAddress":"(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if items:
		c0cDhidBlOn7 = items[int(E0w56WHxZPYGVvnTQ4O2t1C8DAjq)-1]
		c0cDhidBlOn7 = hQrBKyjMaeIUV+YQlEOShHM7RLak2t0yA4NXqv(c0cDhidBlOn7)
		lycT0JB1noerD5YANK2PbHa8QVM.append('mp3 address')
		pcX7zxFRmsADwUr.append(c0cDhidBlOn7)
	if len(pcX7zxFRmsADwUr)==1: c0cDhidBlOn7 = pcX7zxFRmsADwUr[0]
	else:
		AS6jLpMwW5Ql3kUFNfT = NAfHLMC8Ip64FmT7l5oJWXaq3hK('اختر الفيديو المناسب:', lycT0JB1noerD5YANK2PbHa8QVM)
		if AS6jLpMwW5Ql3kUFNfT == -1 : return
		c0cDhidBlOn7 = pcX7zxFRmsADwUr[AS6jLpMwW5Ql3kUFNfT]
	bmgwWLk3er(c0cDhidBlOn7,UkXlAzsMcamKJrEIgnxi6bWh,'video')
	return
def QwyBLepgH5jiIS4lO8PVtEaKJbMcfT(url):
	if cDTdfqVAF0BLGiX364IEwaZbr in url: xgPSaoLzTlFtQD37M6HIEsWY = cDTdfqVAF0BLGiX364IEwaZbr
	elif Nl3Tz5nOPvLKqH7jJAVs1mF2r in url: xgPSaoLzTlFtQD37M6HIEsWY = Nl3Tz5nOPvLKqH7jJAVs1mF2r
	elif NSdOvMkYVXusnpbT5P6trAx2ZL8UC0 in url: xgPSaoLzTlFtQD37M6HIEsWY = NSdOvMkYVXusnpbT5P6trAx2ZL8UC0
	elif XXy6t0QWkGmgMTIs7VzbRqhlO in url: xgPSaoLzTlFtQD37M6HIEsWY = XXy6t0QWkGmgMTIs7VzbRqhlO
	else: xgPSaoLzTlFtQD37M6HIEsWY = cdZKMn68Pzg4
	return xgPSaoLzTlFtQD37M6HIEsWY
def ru4oTqviByhkteQlnAxNzCY1Zb0V(url):
	if   cDTdfqVAF0BLGiX364IEwaZbr in url: GFskvRIgwN5OSx = 'ar'
	elif Nl3Tz5nOPvLKqH7jJAVs1mF2r in url: GFskvRIgwN5OSx = 'en'
	elif NSdOvMkYVXusnpbT5P6trAx2ZL8UC0 in url: GFskvRIgwN5OSx = 'fa'
	elif XXy6t0QWkGmgMTIs7VzbRqhlO in url: GFskvRIgwN5OSx = 'fa2'
	else: GFskvRIgwN5OSx = cdZKMn68Pzg4
	return GFskvRIgwN5OSx
def CGOjMRlNnBafrtz(url):
	GFskvRIgwN5OSx = ru4oTqviByhkteQlnAxNzCY1Zb0V(url)
	HOCWKhxITtulVGX = url + '/Home/Live'
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(r43t1YI9deXA5N,'GET',HOCWKhxITtulVGX,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'IFILM-LIVE-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('source src="(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	N8jUpQxY0rhtDAzbG4kOs9X = items[0]
	bmgwWLk3er(N8jUpQxY0rhtDAzbG4kOs9X,UkXlAzsMcamKJrEIgnxi6bWh,'live')
	return
def z4hetAJw3NaT9ROjG6xbZ5CHlW81(search):
	search,EL8zUgbXheot,showDialogs = qbIcHCMdkFKn21e(search)
	if not search:
		search = BzkmLuvJD9n25Pg()
		if not search: return
	nuKdVC6ePlg = search.replace(VBpIH2QSmvDGlA6TO3e,'+')
	if showDialogs:
		YL1mjqt3AlF = [ cDTdfqVAF0BLGiX364IEwaZbr , Nl3Tz5nOPvLKqH7jJAVs1mF2r , NSdOvMkYVXusnpbT5P6trAx2ZL8UC0 , XXy6t0QWkGmgMTIs7VzbRqhlO ]
		Dh86vEgI1n = [ 'عربي' , 'English' , 'فارسى' , 'فارسى 2' ]
		AS6jLpMwW5Ql3kUFNfT = NAfHLMC8Ip64FmT7l5oJWXaq3hK('اختر اللغة المناسبة:', Dh86vEgI1n)
		if AS6jLpMwW5Ql3kUFNfT == -1 : return
		website = YL1mjqt3AlF[AS6jLpMwW5Ql3kUFNfT]
	else:
		if '_IFILM-ARABIC_' in EL8zUgbXheot: website = cDTdfqVAF0BLGiX364IEwaZbr
		elif '_IFILM-ENGLISH_' in EL8zUgbXheot: website = Nl3Tz5nOPvLKqH7jJAVs1mF2r
		else: website = cdZKMn68Pzg4
	if not website: return
	GFskvRIgwN5OSx = ru4oTqviByhkteQlnAxNzCY1Zb0V(website)
	HOCWKhxITtulVGX = website + "/Home/Search?searchstring=" + nuKdVC6ePlg
	OO1cj2REUZHJ8x5V = Gc05Efm73C8s(K8DZxE74Afz52gBYbOMtpvql0RJma,HOCWKhxITtulVGX,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'IFILM-SEARCH-1st')
	items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"ImageAddress_[SML]":"(.*?\/.*?)".*?"CategoryId":(.*?),"Id":(.*?),"Title":"(.*?)",',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if items:
		for y90BoFz8MA1ZThaSC2ILXHiK3OY6w,rrb0SF6otehufCYOX4,id,title in items:
			if rrb0SF6otehufCYOX4 in ['3','7']:
				title = title.replace('\\',cdZKMn68Pzg4)
				title = title.replace('"',cdZKMn68Pzg4)
				if rrb0SF6otehufCYOX4=='3':
					type = 'Series'
					if GFskvRIgwN5OSx=='ar': name = 'مسلسل : '
					elif GFskvRIgwN5OSx=='en': name = 'Series : '
					elif GFskvRIgwN5OSx=='fa': name = 'سريال ها : '
					elif GFskvRIgwN5OSx=='fa2': name = 'سريال ها : '
				elif rrb0SF6otehufCYOX4=='5':
					type = 'Film'
					if GFskvRIgwN5OSx=='ar': name = 'فيلم : '
					elif GFskvRIgwN5OSx=='en': name = 'Movie : '
					elif GFskvRIgwN5OSx=='fa': name = 'فيلم : '
					elif GFskvRIgwN5OSx=='fa2': name = 'فلم ها : '
				elif rrb0SF6otehufCYOX4=='7':
					type = 'Program'
					if GFskvRIgwN5OSx=='ar': name = 'برنامج : '
					elif GFskvRIgwN5OSx=='en': name = 'Program : '
					elif GFskvRIgwN5OSx=='fa': name = 'برنامه ها : '
					elif GFskvRIgwN5OSx=='fa2': name = 'برنامه ها : '
				title = name + title
				c0cDhidBlOn7 = website + KCQExdbYFqM + type + '/Content/' + id
				y90BoFz8MA1ZThaSC2ILXHiK3OY6w = YQlEOShHM7RLak2t0yA4NXqv(y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
				y90BoFz8MA1ZThaSC2ILXHiK3OY6w = website+y90BoFz8MA1ZThaSC2ILXHiK3OY6w
				zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,23,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,'101')
	return
# -*- coding: utf-8 -*-
from RgJNGc7YMP import *
UkXlAzsMcamKJrEIgnxi6bWh = 'DAILYMOTION'
nc3GLkA65oxOd = '_DLM_'
cDTdfqVAF0BLGiX364IEwaZbr = USuRxnPlV5.SITESURLS[UkXlAzsMcamKJrEIgnxi6bWh][0]
Nl3Tz5nOPvLKqH7jJAVs1mF2r = USuRxnPlV5.SITESURLS[UkXlAzsMcamKJrEIgnxi6bWh][1]
NSdOvMkYVXusnpbT5P6trAx2ZL8UC0 = USuRxnPlV5.SITESURLS[UkXlAzsMcamKJrEIgnxi6bWh][2]
def HHN5EpbszV3iA2m89hGSQjaPgUZy(mode,url,text,type,aOZ3yVnsNlB974pR):
	if	 mode==400: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = kUq58vC7x9hWma164JejMKQ()
	elif mode==401: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = aSKVsb1XiEwmWCJ9Hh(url,text)
	elif mode==402: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = uWY1XROJ7iMK8(url,text)
	elif mode==403: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = RPZbqous7rtdy56LeI18Cv04AKHW(url,text)
	elif mode==404: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = z7gom8OKtCxkGlWMPI1DNi(text,aOZ3yVnsNlB974pR)
	elif mode==405: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = cMs8xfbvnWPGdziyJp0SAuLV5N(text,aOZ3yVnsNlB974pR)
	elif mode==406: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = nKZS7F94Dpw5YUfxiCelo6brc3z(text,aOZ3yVnsNlB974pR)
	elif mode==407: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = WWRl4rSZKib8z3Yny7jak2E(url,aOZ3yVnsNlB974pR)
	elif mode==408: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = vyNPugXTfI54haJLFq9iDKQp(url,aOZ3yVnsNlB974pR)
	elif mode==409: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = z4hetAJw3NaT9ROjG6xbZ5CHlW81(text,aOZ3yVnsNlB974pR)
	elif mode==411: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = Pafi0ycArMs(url,text)
	elif mode==414: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = sz3YETLUXhHKq58uAk6MvDFlS(text)
	elif mode==415: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = g8gCD9BGS0eyrWT(text,aOZ3yVnsNlB974pR)
	elif mode==416: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = NNRgoxY3sv52fmZM(text,aOZ3yVnsNlB974pR)
	elif mode==417: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = lq1GKijJ4A58s(url,aOZ3yVnsNlB974pR)
	else: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = False
	return xsGUcR3ef6glKY5hQwpFXEaSt2mrIz
def kUq58vC7x9hWma164JejMKQ():
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'الرئيسية',cdZKMn68Pzg4,414)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'بحث في الموقع',cdZKMn68Pzg4,409,cdZKMn68Pzg4,cdZKMn68Pzg4,'_REMEMBERRESULTS_')
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'بحث عن فيديوهات',cdZKMn68Pzg4,409,cdZKMn68Pzg4,'videos?sortBy=','_REMEMBERRESULTS_')
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'بحث عن آخر الفيديوهات',cdZKMn68Pzg4,409,cdZKMn68Pzg4,'videos?sortBy=RECENT','_REMEMBERRESULTS_')
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'بحث عن الفيديوهات الأكثر مشاهدة',cdZKMn68Pzg4,409,cdZKMn68Pzg4,'videos?sortBy=VIEW_COUNT','_REMEMBERRESULTS_')
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'بحث عن قوائم التشغيل',cdZKMn68Pzg4,409,cdZKMn68Pzg4,'playlists','_REMEMBERRESULTS_')
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'بحث عن مستخدم',cdZKMn68Pzg4,409,cdZKMn68Pzg4,'channels','_REMEMBERRESULTS_')
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'بحث عن بث حي',cdZKMn68Pzg4,409,cdZKMn68Pzg4,'lives','_REMEMBERRESULTS_')
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'بحث عن هاشتاك',cdZKMn68Pzg4,409,cdZKMn68Pzg4,'hashtags','_REMEMBERRESULTS_')
	return
def uWY1XROJ7iMK8(url,L6ocbK1GJq):
	if '/dm_' in url:
		Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(AlfMBJhUD65to2WrQcb,'GET',url,cdZKMn68Pzg4,cdZKMn68Pzg4,False,cdZKMn68Pzg4,'DAILYMOTION-CHANNELS_SUBMENU-1st',False,False)
		headers = Zty0AsgQ5jpkTh91OW.headers
		if 'Location' in list(headers.keys()): url = cDTdfqVAF0BLGiX364IEwaZbr+headers['Location']
	L6ocbK1GJq = Gzygq01Kcb9U3+L6ocbK1GJq+kH8E2zqNyims6KJfI
	L6ocbK1GJq = IIOrumdEle0fSVYp92xTMCctbPB45F(L6ocbK1GJq)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+':: بث حي',url,411,cdZKMn68Pzg4,cdZKMn68Pzg4,'channel_lives_now')
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+':: آخر الفيديوهات',url+'/videos',408)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+':: الأكثر مشاهدة',url+'/videos?sort=visited',408)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+':: المميزة',url,411,cdZKMn68Pzg4,cdZKMn68Pzg4,'channel_featured_videos')
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+':: قوائم التشغيل',url+'/playlists',407)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+':: قوائم التشغيل أبجدية',url+'/playlists?sort=alphaaz',407)
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+':: قنوات ذات صلة',url,411,cdZKMn68Pzg4,cdZKMn68Pzg4,'channel_related_channel')
	return
def IIOrumdEle0fSVYp92xTMCctbPB45F(title):
	title = title.rstrip('\\').strip(VBpIH2QSmvDGlA6TO3e).replace('\\\\','\\')
	title = XTL0AWmwbDJfGRNi(title)
	return title
def RPZbqous7rtdy56LeI18Cv04AKHW(url,JFQSL6r7GUcvxz):
	import r0y4XTKznF
	r0y4XTKznF.noHliPXkcg3pJTdSauCvm5sU([url],UkXlAzsMcamKJrEIgnxi6bWh,'video',url)
	return
def z7gom8OKtCxkGlWMPI1DNi(search,aOZ3yVnsNlB974pR=cdZKMn68Pzg4):
	if aOZ3yVnsNlB974pR==cdZKMn68Pzg4: aOZ3yVnsNlB974pR = '1'
	if 'sortBy=' in search: sort = search.split('sortBy=')[1].split('&')[0]
	else: sort = cdZKMn68Pzg4
	search = search.split('/videos')[0]
	CvSX7Etpz80eGlT1brgWZkJ = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeVideos":true,"page":mypagenumber,"limit":mypagelimitmysortmethod},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    views {      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment VIDEO_WATCH_LATER_FRAGMENT on Video {  id  isInWatchLater  __typename}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    videos {      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_WATCH_LATER_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	CvSX7Etpz80eGlT1brgWZkJ = CvSX7Etpz80eGlT1brgWZkJ.replace('mysearchwords',search)
	CvSX7Etpz80eGlT1brgWZkJ = CvSX7Etpz80eGlT1brgWZkJ.replace('mypagelimit','40')
	CvSX7Etpz80eGlT1brgWZkJ = CvSX7Etpz80eGlT1brgWZkJ.replace('mypagenumber',aOZ3yVnsNlB974pR)
	if sort==cdZKMn68Pzg4: CvSX7Etpz80eGlT1brgWZkJ = CvSX7Etpz80eGlT1brgWZkJ.replace('mysortmethod',cdZKMn68Pzg4)
	else: CvSX7Etpz80eGlT1brgWZkJ = CvSX7Etpz80eGlT1brgWZkJ.replace('mysortmethod',',"sortByVideos":"'+sort+'"')
	url = cDTdfqVAF0BLGiX364IEwaZbr+'/search/'+search+'/videos'
	OO1cj2REUZHJ8x5V = zu649N5027IWgsLMRU3e(CvSX7Etpz80eGlT1brgWZkJ,search)
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"videos"(.*?)"VideoConnection"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"node":.*?"xid":"(.*?)",.*?"title":"(.*?)",.*?"name":"(.*?)",.*?"displayName":"(.*?)",.*?"duration":(.*?),".*?thumbnailx240":"(.*?)",',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for id,title,tb4d5p7o3ieh,L6ocbK1GJq,Kr1n9xq5TY4gohlVdNEu0b,y90BoFz8MA1ZThaSC2ILXHiK3OY6w in items:
			y90BoFz8MA1ZThaSC2ILXHiK3OY6w = y90BoFz8MA1ZThaSC2ILXHiK3OY6w.replace('\/',KCQExdbYFqM)
			c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr+'/video/'+id
			title = IIOrumdEle0fSVYp92xTMCctbPB45F(title)
			JFQSL6r7GUcvxz = tb4d5p7o3ieh+'::'+L6ocbK1GJq
			zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,403,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,Kr1n9xq5TY4gohlVdNEu0b,JFQSL6r7GUcvxz)
		if '"hasNextPage":true' in OO1cj2REUZHJ8x5V:
			aOZ3yVnsNlB974pR = str(int(aOZ3yVnsNlB974pR)+1)
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'صفحة '+aOZ3yVnsNlB974pR,url,404,cdZKMn68Pzg4,aOZ3yVnsNlB974pR,search)
	return
def cMs8xfbvnWPGdziyJp0SAuLV5N(search,aOZ3yVnsNlB974pR=cdZKMn68Pzg4):
	if aOZ3yVnsNlB974pR==cdZKMn68Pzg4: aOZ3yVnsNlB974pR = '1'
	CvSX7Etpz80eGlT1brgWZkJ = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":true,"shouldIncludeVideos":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    views {      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment VIDEO_WATCH_LATER_FRAGMENT on Video {  id  isInWatchLater  __typename}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    videos {      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_WATCH_LATER_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	CvSX7Etpz80eGlT1brgWZkJ = CvSX7Etpz80eGlT1brgWZkJ.replace('mysearchwords',search)
	CvSX7Etpz80eGlT1brgWZkJ = CvSX7Etpz80eGlT1brgWZkJ.replace('mypagelimit','40')
	CvSX7Etpz80eGlT1brgWZkJ = CvSX7Etpz80eGlT1brgWZkJ.replace('mypagenumber',aOZ3yVnsNlB974pR)
	url = cDTdfqVAF0BLGiX364IEwaZbr+'/search/'+search+'/playlists'
	OO1cj2REUZHJ8x5V = zu649N5027IWgsLMRU3e(CvSX7Etpz80eGlT1brgWZkJ,search)
	items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"node".*?"xid":"(.*?)",.*?"name":"(.*?)",.*?"xid":"(.*?)",.*?"name":"(.*?)",.*?"displayName":"(.*?)",.*?"thumbnailx240":"(.*?)",.*?"total":(.*?),"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	for id,name,bawPVykZBGer3ugLOtKAm,tb4d5p7o3ieh,L6ocbK1GJq,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,count in items:
		y90BoFz8MA1ZThaSC2ILXHiK3OY6w = y90BoFz8MA1ZThaSC2ILXHiK3OY6w.replace('\/',KCQExdbYFqM)
		c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr+'/playlist/'+id
		title = 'LIST'+count+':  '+name
		title = IIOrumdEle0fSVYp92xTMCctbPB45F(title)
		JFQSL6r7GUcvxz = tb4d5p7o3ieh+'::'+L6ocbK1GJq
		zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,401,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,cdZKMn68Pzg4,JFQSL6r7GUcvxz)
	if '"hasNextPage":true' in OO1cj2REUZHJ8x5V:
		aOZ3yVnsNlB974pR = str(int(aOZ3yVnsNlB974pR)+1)
		zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'صفحة '+aOZ3yVnsNlB974pR,url,405,cdZKMn68Pzg4,aOZ3yVnsNlB974pR,search)
	return
def nKZS7F94Dpw5YUfxiCelo6brc3z(search,aOZ3yVnsNlB974pR=cdZKMn68Pzg4):
	if aOZ3yVnsNlB974pR==cdZKMn68Pzg4: aOZ3yVnsNlB974pR = '1'
	CvSX7Etpz80eGlT1brgWZkJ = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":true,"shouldIncludePlaylists":false,"shouldIncludeVideos":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    views {      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment VIDEO_WATCH_LATER_FRAGMENT on Video {  id  isInWatchLater  __typename}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    videos {      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_WATCH_LATER_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	CvSX7Etpz80eGlT1brgWZkJ = CvSX7Etpz80eGlT1brgWZkJ.replace('mysearchwords',search)
	CvSX7Etpz80eGlT1brgWZkJ = CvSX7Etpz80eGlT1brgWZkJ.replace('mypagelimit','40')
	CvSX7Etpz80eGlT1brgWZkJ = CvSX7Etpz80eGlT1brgWZkJ.replace('mypagenumber',aOZ3yVnsNlB974pR)
	url = cDTdfqVAF0BLGiX364IEwaZbr+'/search/'+search+'/channels'
	OO1cj2REUZHJ8x5V = zu649N5027IWgsLMRU3e(CvSX7Etpz80eGlT1brgWZkJ,search)
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"channels"(.*?)"ChannelConnection"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"node".*?"name":"(.*?)",.*?"displayName":"(.*?)",.*?"thumbnailx240":"(.*?)",',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for id,name,y90BoFz8MA1ZThaSC2ILXHiK3OY6w in items:
			y90BoFz8MA1ZThaSC2ILXHiK3OY6w = y90BoFz8MA1ZThaSC2ILXHiK3OY6w.replace('\/',KCQExdbYFqM)
			c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr+KCQExdbYFqM+id
			title = 'USER:  '+name
			title = IIOrumdEle0fSVYp92xTMCctbPB45F(title)
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,402,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,cdZKMn68Pzg4,name)
		if '"hasNextPage":true' in OO1cj2REUZHJ8x5V:
			aOZ3yVnsNlB974pR = str(int(aOZ3yVnsNlB974pR)+1)
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'صفحة '+aOZ3yVnsNlB974pR,url,406,cdZKMn68Pzg4,aOZ3yVnsNlB974pR,search)
	return
def sz3YETLUXhHKq58uAk6MvDFlS(XXEoyqtC7jvK1a2rwDVIZHP):
	CvSX7Etpz80eGlT1brgWZkJ = '''{"operationName":"HOME_QUERY","variables":{"space":"nextplore"},"query":"fragment TOPIC_BASE_FRAG on Topic {  id  xid  name  thumbnail: coverURL(size: \\"x532\\")  coverURL: coverURL(size: \\"x532\\")  isFollowed  whitelistStatus {    id    isWhitelisted    __typename  }  __typename}query HOME_QUERY($space: String!) {  home: views {    id    neon {      id      sections(space: $space) {        edges {          node {            id            name            title            description            groupingType            type            relatedComponent {              __typename              ... on Collection {                id                xid                __typename              }              ... on Channel {                id                xid                name                displayName                logoURL(size: \\"x60\\")                __typename              }              ... on Topic {                id                __typename                ...TOPIC_BASE_FRAG              }            }            components {              edges {                node {                  __typename                  ... on Video {                    id                    xid                    title                    thumbnailx60: thumbnailURL(size: \\"x60\\")                    thumbnailx120: thumbnailURL(size: \\"x120\\")                    thumbnailx240: thumbnailURL(size: \\"x240\\")                    thumbnailx360: thumbnailURL(size: \\"x360\\")                    thumbnailx480: thumbnailURL(size: \\"x480\\")                    thumbnailx720: thumbnailURL(size: \\"x720\\")                    aspectRatio                    createdAt                    channel {                      id                      xid                      name                      displayName                      logoURLx25: logoURL(size: \\"x25\\")                      accountType                      __typename                    }                    description                    duration                    __typename                  }                  ... on Live {                    id                    xid                    title                    thumbnailx60: thumbnailURL(size: \\"x60\\")                    thumbnailx120: thumbnailURL(size: \\"x120\\")                    thumbnailx240: thumbnailURL(size: \\"x240\\")                    thumbnailx360: thumbnailURL(size: \\"x360\\")                    thumbnailx480: thumbnailURL(size: \\"x480\\")                    thumbnailx720: thumbnailURL(size: \\"x720\\")                    aspectRatio                    createdAt                    channel {                      id                      xid                      name                      displayName                      logoURLx25: logoURL(size: \\"x25\\")                      accountType                      __typename                    }                    startAt                    __typename                  }                }                __typename              }              __typename            }            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	ppsyEOKtjW3GY6nUPF = zu649N5027IWgsLMRU3e(CvSX7Etpz80eGlT1brgWZkJ)
	if ppsyEOKtjW3GY6nUPF:
		mmf4jR1lkKcFnwSxd9Ers = lMeKd3hC6cmS('dict',ppsyEOKtjW3GY6nUPF)
		NmyrJzuVBxZ = mmf4jR1lkKcFnwSxd9Ers['data']['home']['neon']['sections']['edges']
		if not XXEoyqtC7jvK1a2rwDVIZHP:
			DChe7rygFY = []
			for dVRQBgxrlkDK1vHG8TmohNZa3yAcOY in NmyrJzuVBxZ:
				N87VjPhxDQem59SpXCTAObK = dVRQBgxrlkDK1vHG8TmohNZa3yAcOY['node']['title']
				if N87VjPhxDQem59SpXCTAObK not in DChe7rygFY: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+N87VjPhxDQem59SpXCTAObK,cdZKMn68Pzg4,414,cdZKMn68Pzg4,cdZKMn68Pzg4,N87VjPhxDQem59SpXCTAObK)
				DChe7rygFY.append(N87VjPhxDQem59SpXCTAObK)
		else:
			for dVRQBgxrlkDK1vHG8TmohNZa3yAcOY in NmyrJzuVBxZ:
				N87VjPhxDQem59SpXCTAObK = dVRQBgxrlkDK1vHG8TmohNZa3yAcOY['node']['title']
				if N87VjPhxDQem59SpXCTAObK==XXEoyqtC7jvK1a2rwDVIZHP:
					ee9JKpVM236u8rFO = dVRQBgxrlkDK1vHG8TmohNZa3yAcOY['node']['components']['edges']
					for HHDEibksuOe5SVpx in ee9JKpVM236u8rFO:
						Kr1n9xq5TY4gohlVdNEu0b = str(HHDEibksuOe5SVpx['node']['duration'])
						title = XTL0AWmwbDJfGRNi(HHDEibksuOe5SVpx['node']['title'])
						title = title.replace('\/',KCQExdbYFqM)
						Ozs53xWnMc = HHDEibksuOe5SVpx['node']['xid']
						y90BoFz8MA1ZThaSC2ILXHiK3OY6w = HHDEibksuOe5SVpx['node']['thumbnailx480']
						y90BoFz8MA1ZThaSC2ILXHiK3OY6w = y90BoFz8MA1ZThaSC2ILXHiK3OY6w.replace('\/',KCQExdbYFqM)
						c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr+'/video/'+Ozs53xWnMc
						zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,403,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,Kr1n9xq5TY4gohlVdNEu0b)
	return
def g8gCD9BGS0eyrWT(search,aOZ3yVnsNlB974pR=cdZKMn68Pzg4):
	if aOZ3yVnsNlB974pR==cdZKMn68Pzg4: aOZ3yVnsNlB974pR = '1'
	CvSX7Etpz80eGlT1brgWZkJ = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeTopics":false,"shouldIncludeVideos":false,"shouldIncludeLives":true,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    id    views {      id      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  aspectRatio  __typename}fragment VIDEO_FAVORITES_FRAGMENT on Media {  __typename  ... on Video {    id    viewerEngagement {      id      favorited      __typename    }    __typename  }  ... on Live {    id    viewerEngagement {      id      favorited      __typename    }    __typename  }}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}fragment TOPIC_BASE_FRAG on Topic {  id  xid  name  videos(sort: \\"recent\\", first: 5) {    pageInfo {      hasNextPage      nextPage      __typename    }    edges {      node {        id        ...VIDEO_BASE_FRAGMENT        ...VIDEO_FAVORITES_FRAGMENT        __typename      }      __typename    }    __typename  }  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeTopics: Boolean!, $shouldIncludeLives: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(      query: $query      first: $limit      page: $page      sort: $sortByVideos      durationMin: $durationMinVideos      durationMax: $durationMaxVideos      createdAfter: $createdAfterVideos    ) @include(if: $shouldIncludeVideos) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_FAVORITES_FRAGMENT          __typename        }        __typename      }      __typename    }    lives(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeLives) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          xid          title          thumbnail: thumbnailURL(size: \\"x240\\")          thumbnailx60: thumbnailURL(size: \\"x60\\")          thumbnailx120: thumbnailURL(size: \\"x120\\")          thumbnailx240: thumbnailURL(size: \\"x240\\")          thumbnailx720: thumbnailURL(size: \\"x720\\")          audienceCount          aspectRatio          isOnAir          channel {            id            xid            name            displayName            accountType            __typename          }          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    topics(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeTopics) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...TOPIC_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	CvSX7Etpz80eGlT1brgWZkJ = CvSX7Etpz80eGlT1brgWZkJ.replace('mysearchwords',search)
	CvSX7Etpz80eGlT1brgWZkJ = CvSX7Etpz80eGlT1brgWZkJ.replace('mypagelimit','40')
	CvSX7Etpz80eGlT1brgWZkJ = CvSX7Etpz80eGlT1brgWZkJ.replace('mypagenumber',aOZ3yVnsNlB974pR)
	url = cDTdfqVAF0BLGiX364IEwaZbr+'/search/'+search+'/lives'
	ppsyEOKtjW3GY6nUPF = zu649N5027IWgsLMRU3e(CvSX7Etpz80eGlT1brgWZkJ,search)
	if ppsyEOKtjW3GY6nUPF:
		mmf4jR1lkKcFnwSxd9Ers = lMeKd3hC6cmS('dict',ppsyEOKtjW3GY6nUPF)
		try: NmyrJzuVBxZ = mmf4jR1lkKcFnwSxd9Ers['data']['search']['lives']['edges']
		except: NmyrJzuVBxZ = []
		for dVRQBgxrlkDK1vHG8TmohNZa3yAcOY in NmyrJzuVBxZ:
			name = dVRQBgxrlkDK1vHG8TmohNZa3yAcOY['node']['title']
			name = XTL0AWmwbDJfGRNi(name)
			Ozs53xWnMc = dVRQBgxrlkDK1vHG8TmohNZa3yAcOY['node']['xid']
			c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr+'/video/'+Ozs53xWnMc
			zJLApFBcIhnSj('live',nc3GLkA65oxOd+'LIVE: '+name,c0cDhidBlOn7,403)
		if '"hasNextPage":true' in ppsyEOKtjW3GY6nUPF:
			aOZ3yVnsNlB974pR = str(int(aOZ3yVnsNlB974pR)+1)
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'صفحة '+aOZ3yVnsNlB974pR,url,415,cdZKMn68Pzg4,aOZ3yVnsNlB974pR,search)
	return
def FtxXMTv4BrUsHCSdp7Vzbe(search,aOZ3yVnsNlB974pR=cdZKMn68Pzg4):
	if aOZ3yVnsNlB974pR==cdZKMn68Pzg4: aOZ3yVnsNlB974pR = '1'
	CvSX7Etpz80eGlT1brgWZkJ = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeTopics":true,"shouldIncludeVideos":false,"shouldIncludeLives":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    id    views {      id      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  aspectRatio  __typename}fragment VIDEO_FAVORITES_FRAGMENT on Media {  __typename  ... on Video {    id    isInWatchLater    __typename  }  ... on Live {    id    isInWatchLater    __typename  }}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}fragment TOPIC_BASE_FRAG on Topic {  id  xid  name  videos(sort: \\"recent\\", first: 5) {    pageInfo {      hasNextPage      nextPage      __typename    }    edges {      node {        id        ...VIDEO_BASE_FRAGMENT        ...VIDEO_FAVORITES_FRAGMENT        __typename      }      __typename    }    __typename  }  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeTopics: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(      query: $query      first: $limit      page: $page      sort: $sortByVideos      durationMin: $durationMinVideos      durationMax: $durationMaxVideos      createdAfter: $createdAfterVideos    ) @include(if: $shouldIncludeVideos) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_FAVORITES_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    topics(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeTopics) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...TOPIC_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	CvSX7Etpz80eGlT1brgWZkJ = CvSX7Etpz80eGlT1brgWZkJ.replace('mysearchwords',search)
	CvSX7Etpz80eGlT1brgWZkJ = CvSX7Etpz80eGlT1brgWZkJ.replace('mypagelimit','40')
	CvSX7Etpz80eGlT1brgWZkJ = CvSX7Etpz80eGlT1brgWZkJ.replace('mypagenumber',aOZ3yVnsNlB974pR)
	url = cDTdfqVAF0BLGiX364IEwaZbr+'/search/'+search+'/topics'
	ppsyEOKtjW3GY6nUPF = zu649N5027IWgsLMRU3e(CvSX7Etpz80eGlT1brgWZkJ,search)
	if ppsyEOKtjW3GY6nUPF:
		mmf4jR1lkKcFnwSxd9Ers = lMeKd3hC6cmS('dict',ppsyEOKtjW3GY6nUPF)
		try: NmyrJzuVBxZ = mmf4jR1lkKcFnwSxd9Ers['data']['search']['topics']['edges']
		except: NmyrJzuVBxZ = []
		for dVRQBgxrlkDK1vHG8TmohNZa3yAcOY in NmyrJzuVBxZ:
			name = dVRQBgxrlkDK1vHG8TmohNZa3yAcOY['node']['name']
			Ozs53xWnMc = dVRQBgxrlkDK1vHG8TmohNZa3yAcOY['node']['xid']
			c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr+'/topic/'+Ozs53xWnMc
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'TOPIC: '+name,c0cDhidBlOn7,413)
		if '"hasNextPage":true' in ppsyEOKtjW3GY6nUPF:
			aOZ3yVnsNlB974pR = str(int(aOZ3yVnsNlB974pR)+1)
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'صفحة '+aOZ3yVnsNlB974pR,url,412,cdZKMn68Pzg4,aOZ3yVnsNlB974pR,search)
	return
def HWXLCKl3ysmPxfTwRAa7uqk(url,aOZ3yVnsNlB974pR=cdZKMn68Pzg4):
	if aOZ3yVnsNlB974pR==cdZKMn68Pzg4: aOZ3yVnsNlB974pR = '1'
	Ozs53xWnMc = url.split(KCQExdbYFqM)[-1]
	CvSX7Etpz80eGlT1brgWZkJ = '''{"operationName":"DISCOVERY_TOPIC_MAIN_QUERY","variables":{"page":mypagenumber,"xid":"mytopicid"},"query":"fragment TOPIC_VIDEO_FRAGMENT on Video {  id  xid  title  duration  isLiked  isInWatchLater  isCreatedForKids  createdAt  isExplicit  videoHeight: height  videoWidth: width  category  channel {    id    xid    name    displayName    logoURLx25: logoURL(size: \\"x25\\")    logoURL(size: \\"x60\\")    accountType    __typename  }  stats {    id    views {      id      total      __typename    }    __typename  }  language {    id    codeAlpha2    __typename  }  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  bestAvailableQuality  aspectRatio  isPublished  __typename}query DISCOVERY_TOPIC_MAIN_QUERY($xid: String!, $page: Int = 1) {  topic(xid: $xid) {    id    xid    name    videos(sort: \\"recent\\", first: 30, page: $page) {      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...TOPIC_VIDEO_FRAGMENT          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	CvSX7Etpz80eGlT1brgWZkJ = CvSX7Etpz80eGlT1brgWZkJ.replace('mytopicid',Ozs53xWnMc)
	CvSX7Etpz80eGlT1brgWZkJ = CvSX7Etpz80eGlT1brgWZkJ.replace('mypagenumber',aOZ3yVnsNlB974pR)
	ppsyEOKtjW3GY6nUPF = zu649N5027IWgsLMRU3e(CvSX7Etpz80eGlT1brgWZkJ)
	if ppsyEOKtjW3GY6nUPF:
		mmf4jR1lkKcFnwSxd9Ers = lMeKd3hC6cmS('dict',ppsyEOKtjW3GY6nUPF)
		NmyrJzuVBxZ = mmf4jR1lkKcFnwSxd9Ers['data']['topic']['videos']['edges']
		for dVRQBgxrlkDK1vHG8TmohNZa3yAcOY in NmyrJzuVBxZ:
			Kr1n9xq5TY4gohlVdNEu0b = str(dVRQBgxrlkDK1vHG8TmohNZa3yAcOY['node']['duration'])
			title = XTL0AWmwbDJfGRNi(dVRQBgxrlkDK1vHG8TmohNZa3yAcOY['node']['title'])
			title = title.replace('\/',KCQExdbYFqM)
			Ozs53xWnMc = dVRQBgxrlkDK1vHG8TmohNZa3yAcOY['node']['xid']
			y90BoFz8MA1ZThaSC2ILXHiK3OY6w = dVRQBgxrlkDK1vHG8TmohNZa3yAcOY['node']['thumbnailx480']
			y90BoFz8MA1ZThaSC2ILXHiK3OY6w = y90BoFz8MA1ZThaSC2ILXHiK3OY6w.replace('\/',KCQExdbYFqM)
			c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr+'/video/'+Ozs53xWnMc
			zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,403,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,Kr1n9xq5TY4gohlVdNEu0b)
		if '"hasNextPage":true' in ppsyEOKtjW3GY6nUPF:
			aOZ3yVnsNlB974pR = str(int(aOZ3yVnsNlB974pR)+1)
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'صفحة '+aOZ3yVnsNlB974pR,url,413,cdZKMn68Pzg4,aOZ3yVnsNlB974pR)
	return
def aSKVsb1XiEwmWCJ9Hh(url,JFQSL6r7GUcvxz):
	id = url.split(KCQExdbYFqM)[-1]
	tb4d5p7o3ieh,L6ocbK1GJq = JFQSL6r7GUcvxz.split('::',1)
	c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr+KCQExdbYFqM+tb4d5p7o3ieh
	L6ocbK1GJq = IIOrumdEle0fSVYp92xTMCctbPB45F(L6ocbK1GJq)
	title = Gzygq01Kcb9U3+'OWNER:  '+L6ocbK1GJq+kH8E2zqNyims6KJfI
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,402,cdZKMn68Pzg4,cdZKMn68Pzg4,L6ocbK1GJq)
	CvSX7Etpz80eGlT1brgWZkJ = '''{"operationName":"DISCOVERY_QUEUE_QUERY","variables":{"collectionXid":"myplaylistid","videoXid":"x7s7qbn"},"query":"query DISCOVERY_QUEUE_QUERY($videoXid: String!, $collectionXid: String, $device: String, $videoCountPerSection: Int) {  views {    id    neon {      id      sections(device: $device, space: \\"watching\\", followingChannelXids: [], followingTopicXids: [], watchedVideoXids: [], context: {mediaXid: $videoXid, collectionXid: $collectionXid}, first: 20) {        edges {          node {            id            name            groupingType            relatedComponent {              ... on Channel {                __typename                id                xid                name                displayName                logoURL(size: \\"x60\\")                logoURLx25: logoURL(size: \\"x25\\")              }              ... on Topic {                __typename                id                xid                name                names {                  edges {                    node {                      id                      name                      language {                        id                        codeAlpha2                        __typename                      }                      __typename                    }                    __typename                  }                  __typename                }              }              ... on Collection {                __typename                id                xid                name              }              __typename            }            components(first: $videoCountPerSection) {              metadata {                algorithm {                  name                  version                  uuid                  __typename                }                __typename              }              edges {                node {                  ... on Video {                    __typename                    id                    xid                    title                    duration                    thumbnailx60: thumbnailURL(size: \\"x60\\")                    thumbnailx120: thumbnailURL(size: \\"x120\\")                    thumbnailx240: thumbnailURL(size: \\"x240\\")                    thumbnailx720: thumbnailURL(size: \\"x720\\")                    channel {                      id                      xid                      accountType                      displayName                      logoURLx25: logoURL(size: \\"x25\\")                      logoURL(size: \\"x60\\")                      __typename                    }                  }                  ... on Channel {                    __typename                    id                    xid                    name                    displayName                    accountType                    logoURL(size: \\"x60\\")                  }                  __typename                }                __typename              }              __typename            }            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	CvSX7Etpz80eGlT1brgWZkJ = CvSX7Etpz80eGlT1brgWZkJ.replace('myplaylistid',id)
	OO1cj2REUZHJ8x5V = zu649N5027IWgsLMRU3e(CvSX7Etpz80eGlT1brgWZkJ)
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"collection_videos"(.*?)"SectionEdge"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"node".*?"xid":"(.*?)",.*?"title":"(.*?)",.*?"duration":(.*?),".*?thumbnailx240":"(.*?)",.*?"xid":"(.*?)",.*?"displayName":"(.*?)",',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for id,title,Kr1n9xq5TY4gohlVdNEu0b,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,tb4d5p7o3ieh,L6ocbK1GJq in items:
			y90BoFz8MA1ZThaSC2ILXHiK3OY6w = y90BoFz8MA1ZThaSC2ILXHiK3OY6w.replace('\/',KCQExdbYFqM)
			c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr+'/video/'+id
			title = IIOrumdEle0fSVYp92xTMCctbPB45F(title)
			JFQSL6r7GUcvxz = tb4d5p7o3ieh+'::'+L6ocbK1GJq
			zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,403,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,Kr1n9xq5TY4gohlVdNEu0b,JFQSL6r7GUcvxz)
	return
def vyNPugXTfI54haJLFq9iDKQp(url,aOZ3yVnsNlB974pR=cdZKMn68Pzg4):
	if aOZ3yVnsNlB974pR==cdZKMn68Pzg4: aOZ3yVnsNlB974pR = '1'
	gIK4kes9HnLF8p0itS = url.split(KCQExdbYFqM)[-2]
	if 'sort=' in url: sort = url.split('sort=')[1].split('&')[0]
	else: sort = 'recent'
	CvSX7Etpz80eGlT1brgWZkJ = '''{"operationName":"CHANNEL_VIDEOS_QUERY","variables":{"channel_xid":"mychannelid","sort":"mysortmethod","page":mypagenumber},"query":"fragment CHANNEL_BASE_FRAGMENT on Channel {  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  isFollowed  accountType  __typename}fragment CHANNEL_IMAGES_FRAGMENT on Channel {  id  coverURLx375: coverURL(size: \\"x375\\")  __typename}fragment CHANNEL_UPDATED_FRAGMENT on Channel {  id  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}fragment CHANNEL_COMPLETE_FRAGMENT on Channel {  id  ...CHANNEL_BASE_FRAGMENT  ...CHANNEL_IMAGES_FRAGMENT  ...CHANNEL_UPDATED_FRAGMENT  description  coverURL1024x: coverURL(size: \\"1024x\\")  coverURL1920x: coverURL(size: \\"1920x\\")  externalLinks {    facebookURL    twitterURL    websiteURL    instagramURL    __typename  }  __typename}fragment CHANNEL_FRAGMENT on Channel {  accountType  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  coverURLx375: coverURL(size: \\"x375\\")  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}fragment VIDEO_FRAGMENT on Video {  id  xid  title  viewCount  duration  createdAt  isInWatchLater  channel {    id    ...CHANNEL_FRAGMENT    __typename  }  thumbURLx240: thumbnailURL(size: \\"x240\\")  thumbURLx360: thumbnailURL(size: \\"x360\\")  thumbURLx480: thumbnailURL(size: \\"x480\\")  thumbURLx720: thumbnailURL(size: \\"x720\\")  __typename}query CHANNEL_VIDEOS_QUERY($channel_xid: String!, $sort: String, $page: Int!) {  channel(xid: $channel_xid) {    id    ...CHANNEL_COMPLETE_FRAGMENT    channel_videos_all_videos: videos(sort: $sort, page: $page, first: mypagelimit) {      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...VIDEO_FRAGMENT          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	CvSX7Etpz80eGlT1brgWZkJ = CvSX7Etpz80eGlT1brgWZkJ.replace('mychannelid',gIK4kes9HnLF8p0itS)
	CvSX7Etpz80eGlT1brgWZkJ = CvSX7Etpz80eGlT1brgWZkJ.replace('mypagelimit','40')
	CvSX7Etpz80eGlT1brgWZkJ = CvSX7Etpz80eGlT1brgWZkJ.replace('mypagenumber',aOZ3yVnsNlB974pR)
	CvSX7Etpz80eGlT1brgWZkJ = CvSX7Etpz80eGlT1brgWZkJ.replace('mysortmethod',sort)
	OO1cj2REUZHJ8x5V = zu649N5027IWgsLMRU3e(CvSX7Etpz80eGlT1brgWZkJ)
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"channel_videos_all_videos"(.*?)"VideoConnection"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"node".*?"xid":"(.*?)",.*?"title":"(.*?)",.*?"duration":(.*?),".*?name":"(.*?)",.*?"displayName":"(.*?)",.*?"thumbURLx240":"(.*?)",',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for id,title,Kr1n9xq5TY4gohlVdNEu0b,tb4d5p7o3ieh,L6ocbK1GJq,y90BoFz8MA1ZThaSC2ILXHiK3OY6w in items:
			y90BoFz8MA1ZThaSC2ILXHiK3OY6w = y90BoFz8MA1ZThaSC2ILXHiK3OY6w.replace('\/',KCQExdbYFqM)
			c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr+'/video/'+id
			title = IIOrumdEle0fSVYp92xTMCctbPB45F(title)
			JFQSL6r7GUcvxz = tb4d5p7o3ieh+'::'+L6ocbK1GJq
			zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,403,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,Kr1n9xq5TY4gohlVdNEu0b,JFQSL6r7GUcvxz)
		if '"hasNextPage":true' in OO1cj2REUZHJ8x5V:
			aOZ3yVnsNlB974pR = str(int(aOZ3yVnsNlB974pR)+1)
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'صفحة '+aOZ3yVnsNlB974pR,url,408,cdZKMn68Pzg4,aOZ3yVnsNlB974pR)
	return
def WWRl4rSZKib8z3Yny7jak2E(url,aOZ3yVnsNlB974pR=cdZKMn68Pzg4):
	if aOZ3yVnsNlB974pR==cdZKMn68Pzg4: aOZ3yVnsNlB974pR = '1'
	gIK4kes9HnLF8p0itS = url.split(KCQExdbYFqM)[-2]
	if 'sort=' in url: sort = url.split('sort=')[1].split('&')[0]
	else: sort = 'recent'
	CvSX7Etpz80eGlT1brgWZkJ = '''{"operationName":"CHANNEL_COLLECTIONS_QUERY","variables":{"channel_xid":"mychannelid","sort":"mysortmethod","page":mypagenumber},"query":"fragment CHANNEL_BASE_FRAGMENT on Channel {  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  isFollowed  accountType  __typename}fragment CHANNEL_IMAGES_FRAGMENT on Channel {  id  coverURLx375: coverURL(size: \\"x375\\")  __typename}fragment CHANNEL_UPDATED_FRAGMENT on Channel {  id  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}fragment CHANNEL_COMPLETE_FRAGMENT on Channel {  id  ...CHANNEL_BASE_FRAGMENT  ...CHANNEL_IMAGES_FRAGMENT  ...CHANNEL_UPDATED_FRAGMENT  description  coverURL1024x: coverURL(size: \\"1024x\\")  coverURL1920x: coverURL(size: \\"1920x\\")  externalLinks {    facebookURL    twitterURL    websiteURL    instagramURL    __typename  }  __typename}fragment CHANNEL_FRAGMENT on Channel {  accountType  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  coverURLx375: coverURL(size: \\"x375\\")  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}query CHANNEL_COLLECTIONS_QUERY($channel_xid: String!, $sort: String, $page: Int!) {  channel(xid: $channel_xid) {    id    ...CHANNEL_COMPLETE_FRAGMENT    channel_playlist_collections: collections(sort: $sort, page: $page, first: mypagelimit) {      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          xid          updatedAt          name          description          thumbURLx240: thumbnailURL(size: \\"x240\\")          thumbURLx360: thumbnailURL(size: \\"x360\\")          thumbURLx480: thumbnailURL(size: \\"x480\\")          stats {            videos {              total              __typename            }            __typename          }          channel {            id            ...CHANNEL_FRAGMENT            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	CvSX7Etpz80eGlT1brgWZkJ = CvSX7Etpz80eGlT1brgWZkJ.replace('mychannelid',gIK4kes9HnLF8p0itS)
	CvSX7Etpz80eGlT1brgWZkJ = CvSX7Etpz80eGlT1brgWZkJ.replace('mypagelimit','40')
	CvSX7Etpz80eGlT1brgWZkJ = CvSX7Etpz80eGlT1brgWZkJ.replace('mypagenumber',aOZ3yVnsNlB974pR)
	CvSX7Etpz80eGlT1brgWZkJ = CvSX7Etpz80eGlT1brgWZkJ.replace('mysortmethod',sort)
	OO1cj2REUZHJ8x5V = zu649N5027IWgsLMRU3e(CvSX7Etpz80eGlT1brgWZkJ)
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"channel_playlist_collections"(.*?)"CollectionConnection"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"node".*?"xid":"(.*?)",.*?"name":"(.*?)",.*?"thumbURLx240":"(.*?)",.*?"total":(.*?),".*?xid":"(.*?)",.*?"name":"(.*?)",.*?"displayName":"(.*?)",',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for id,name,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,count,bawPVykZBGer3ugLOtKAm,tb4d5p7o3ieh,L6ocbK1GJq in items:
			y90BoFz8MA1ZThaSC2ILXHiK3OY6w = y90BoFz8MA1ZThaSC2ILXHiK3OY6w.replace('\/',KCQExdbYFqM)
			c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr+'/playlist/'+id
			title = 'LIST'+count+':  '+name
			title = IIOrumdEle0fSVYp92xTMCctbPB45F(title)
			JFQSL6r7GUcvxz = tb4d5p7o3ieh+'::'+L6ocbK1GJq
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,401,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,cdZKMn68Pzg4,JFQSL6r7GUcvxz)
		if '"hasNextPage":true' in OO1cj2REUZHJ8x5V:
			aOZ3yVnsNlB974pR = str(int(aOZ3yVnsNlB974pR)+1)
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'صفحة '+aOZ3yVnsNlB974pR,url,407,cdZKMn68Pzg4,aOZ3yVnsNlB974pR)
	return
def Pafi0ycArMs(url,LxQrFEXnJUAqtTHmV7w42b3NKP):
	gIK4kes9HnLF8p0itS = url.split(KCQExdbYFqM)[3]
	CvSX7Etpz80eGlT1brgWZkJ = '''{"operationName":"CHANNEL_QUERY_DESKTOP","variables":{"channel_name":"mychannelid","relatedChannels":100},"query":"fragment CHANNEL_FRAGMENT on Channel {  accountType  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  coverURLx375: coverURL(size: \\"x375\\")  isFollowed  stats {    id    views {      id      total      __typename    }    followers {      id      total      __typename    }    videos {      id      total      __typename    }    __typename  }  __typename}fragment LIVE_FRAGMENT on Live {  id  xid  title  startAt  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  channel {    id    ...CHANNEL_FRAGMENT    __typename  }  __typename}fragment VIDEO_FRAGMENT on Video {  id  xid  title  viewCount  duration  createdAt  isInWatchLater  channel {    id    ...CHANNEL_FRAGMENT    __typename  }  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment CHANNEL_MAIN_FRAGMENT on Channel {  id  xid  name  displayName  description  accountType  isArtist  logoURL(size: \\"x60\\")  coverURL1024x: coverURL(size: \\"1024x\\")  coverURL1920x: coverURL(size: \\"1920x\\")  isFollowed  tagline  country {    id    codeAlpha2    __typename  }  stats {    id    views {      id      total      __typename    }    followers {      id      total      __typename    }    videos {      id      total      __typename    }    __typename  }  externalLinks {    id    facebookURL    twitterURL    websiteURL    instagramURL    pinterestURL    __typename  }  channel_lives_now: lives(first: 4, isOnAir: true) {    edges {      node {        id        ...LIVE_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_lives_scheduled: lives(first: 4, startIn: 7200) {    edges {      node {        id        ...LIVE_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_featured_videos: videos(first: 4, isFeatured: true) {    edges {      node {        id        ...VIDEO_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_all_videos: videos(first: 4) {    edges {      node {        id        ...VIDEO_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_most_viewed: videos(first: 4, sort: \\"visited\\") {    edges {      node {        id        ...VIDEO_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_collections: collections(first: 4) {    edges {      node {        id        xid        name        description        stats {          id          videos {            id            total            __typename          }          __typename        }        thumbnailx240: thumbnailURL(size: \\"x240\\")        thumbnailx360: thumbnailURL(size: \\"x360\\")        thumbnailx480: thumbnailURL(size: \\"x480\\")        channel {          id          ...CHANNEL_FRAGMENT          __typename        }        __typename      }      __typename    }    __typename  }  channel_related_channel: networkChannels(    hasPublicVideos: true    first: $relatedChannels  ) {    edges {      node {        id        ...CHANNEL_FRAGMENT        __typename      }      __typename    }    __typename  }  __typename}query CHANNEL_QUERY_DESKTOP($channel_name: String!, $relatedChannels: Int) {  channel(name: $channel_name) {    id    ...CHANNEL_MAIN_FRAGMENT    __typename  }}"}'''
	CvSX7Etpz80eGlT1brgWZkJ = CvSX7Etpz80eGlT1brgWZkJ.replace('mychannelid',gIK4kes9HnLF8p0itS)
	OO1cj2REUZHJ8x5V = zu649N5027IWgsLMRU3e(CvSX7Etpz80eGlT1brgWZkJ)
	wVIasWUT5d3uH682CQ = sJB3aL8gGVrRU.loads(OO1cj2REUZHJ8x5V)
	try: items = wVIasWUT5d3uH682CQ['data']['channel'][LxQrFEXnJUAqtTHmV7w42b3NKP]['edges']
	except: items = []
	if not items: zJLApFBcIhnSj('link',nc3GLkA65oxOd+'لا توجد نتائج',cdZKMn68Pzg4,9999)
	else:
		for HYBN2AQsjimSMgT8OvE3ynX67tJwR in items:
			zJZdackhvFL5Cx4DV9X7r = HYBN2AQsjimSMgT8OvE3ynX67tJwR['node']
			Ozs53xWnMc = zJZdackhvFL5Cx4DV9X7r['xid']
			keys = list(zJZdackhvFL5Cx4DV9X7r.keys())
			OOlPI082yTZBjNotdDLcfsUMzbGEa9 = zJZdackhvFL5Cx4DV9X7r['__typename'].lower()
			if OOlPI082yTZBjNotdDLcfsUMzbGEa9=='channel':
				name = zJZdackhvFL5Cx4DV9X7r['name']
				gylu6G8czCFE = zJZdackhvFL5Cx4DV9X7r['displayName']
				title = 'USER:  '+gylu6G8czCFE
				y90BoFz8MA1ZThaSC2ILXHiK3OY6w = zJZdackhvFL5Cx4DV9X7r['coverURLx375']
			else:
				name = zJZdackhvFL5Cx4DV9X7r['channel']['name']
				gylu6G8czCFE = zJZdackhvFL5Cx4DV9X7r['channel']['displayName']
				title = zJZdackhvFL5Cx4DV9X7r['title']
				y90BoFz8MA1ZThaSC2ILXHiK3OY6w = zJZdackhvFL5Cx4DV9X7r['thumbnailx360']
				if OOlPI082yTZBjNotdDLcfsUMzbGEa9=='live': title = 'LIVE:  '+title
			title = IIOrumdEle0fSVYp92xTMCctbPB45F(title)
			JFQSL6r7GUcvxz = name+'::'+gylu6G8czCFE
			if xicJPb0AW1nsRfH3kCv7:
				title = title.encode(vczMIlkCAh2u10B3)
				JFQSL6r7GUcvxz = JFQSL6r7GUcvxz.encode(vczMIlkCAh2u10B3)
			y90BoFz8MA1ZThaSC2ILXHiK3OY6w = y90BoFz8MA1ZThaSC2ILXHiK3OY6w.replace('\/',KCQExdbYFqM)
			if OOlPI082yTZBjNotdDLcfsUMzbGEa9=='channel':
				c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr+KCQExdbYFqM+Ozs53xWnMc
				zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,402,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,cdZKMn68Pzg4,JFQSL6r7GUcvxz)
			else:
				if OOlPI082yTZBjNotdDLcfsUMzbGEa9=='video': Kr1n9xq5TY4gohlVdNEu0b = str(zJZdackhvFL5Cx4DV9X7r['duration'])
				else: Kr1n9xq5TY4gohlVdNEu0b = cdZKMn68Pzg4
				c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr+'/video/'+Ozs53xWnMc
				zJLApFBcIhnSj(OOlPI082yTZBjNotdDLcfsUMzbGEa9,nc3GLkA65oxOd+title,c0cDhidBlOn7,403,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,Kr1n9xq5TY4gohlVdNEu0b,JFQSL6r7GUcvxz)
	return
def NNRgoxY3sv52fmZM(search,aOZ3yVnsNlB974pR=cdZKMn68Pzg4):
	if aOZ3yVnsNlB974pR==cdZKMn68Pzg4: aOZ3yVnsNlB974pR = '1'
	CvSX7Etpz80eGlT1brgWZkJ = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeHashtags":true,"shouldIncludeVideos":false,"shouldIncludeLives":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  duration  aspectRatio  thumbnail(height: PORTRAIT_240) {    id    url    __typename  }  creator {    id    xid    name    displayName    accountType    avatar(height: SQUARE_60) {      id      url      __typename    }    __typename  }  __typename}fragment CHANNEL_BASE_FRAG on Channel {  id  xid  name  displayName  accountType  isFollowed  avatar(height: SQUARE_120) {    id    url    __typename  }  followerEngagement {    id    followDate    __typename  }  metrics {    id    engagement {      id      followers {        edges {          node {            id            total            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  description  thumbnail(height: PORTRAIT_240) {    id    url    __typename  }  creator {    id    xid    name    displayName    accountType    avatar(height: SQUARE_60) {      id      url      __typename    }    __typename  }  metrics {    id    engagement {      id      videos(filter: {visibility: {eq: PUBLIC}}) {        edges {          node {            id            total            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }  __typename}fragment HASHTAG_BASE_FRAG on Hashtag {  id  xid  name  metrics {    id    engagement {      id      videos {        edges {          node {            id            total            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }  __typename}fragment LIVE_BASE_FRAGMENT on Live {  id  xid  title  audienceCount  aspectRatio  isOnAir  thumbnail(height: PORTRAIT_240) {    id    url    __typename  }  creator {    id    xid    name    displayName    accountType    avatar(height: SQUARE_60) {      id      url      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeHashtags: Boolean!, $shouldIncludeLives: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(      query: $query      first: $limit      page: $page      sort: $sortByVideos      durationMin: $durationMinVideos      durationMax: $durationMaxVideos      createdAfter: $createdAfterVideos    ) @include(if: $shouldIncludeVideos) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          __typename        }        __typename      }      __typename    }    lives(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeLives) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...LIVE_BASE_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    hashtags(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeHashtags) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...HASHTAG_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	CvSX7Etpz80eGlT1brgWZkJ = CvSX7Etpz80eGlT1brgWZkJ.replace('mysearchwords',search)
	CvSX7Etpz80eGlT1brgWZkJ = CvSX7Etpz80eGlT1brgWZkJ.replace('mypagelimit','40')
	CvSX7Etpz80eGlT1brgWZkJ = CvSX7Etpz80eGlT1brgWZkJ.replace('mypagenumber',aOZ3yVnsNlB974pR)
	url = cDTdfqVAF0BLGiX364IEwaZbr+'/search/'+search+'/hashtags'
	ppsyEOKtjW3GY6nUPF = zu649N5027IWgsLMRU3e(CvSX7Etpz80eGlT1brgWZkJ,search)
	if ppsyEOKtjW3GY6nUPF:
		mmf4jR1lkKcFnwSxd9Ers = lMeKd3hC6cmS('dict',ppsyEOKtjW3GY6nUPF)
		try: NmyrJzuVBxZ = mmf4jR1lkKcFnwSxd9Ers['data']['search']['hashtags']['edges']
		except: NmyrJzuVBxZ = []
		for dVRQBgxrlkDK1vHG8TmohNZa3yAcOY in NmyrJzuVBxZ:
			name = dVRQBgxrlkDK1vHG8TmohNZa3yAcOY['node']['name']
			name = XTL0AWmwbDJfGRNi(name)
			c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr+'/hashtag/'+name[1:]
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'HSHTG: '+name,c0cDhidBlOn7,417)
		if '"hasNextPage":true' in ppsyEOKtjW3GY6nUPF:
			aOZ3yVnsNlB974pR = str(int(aOZ3yVnsNlB974pR)+1)
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'صفحة '+aOZ3yVnsNlB974pR,url,416,cdZKMn68Pzg4,aOZ3yVnsNlB974pR,search)
	return
def lq1GKijJ4A58s(url,aOZ3yVnsNlB974pR=cdZKMn68Pzg4):
	if aOZ3yVnsNlB974pR==cdZKMn68Pzg4: aOZ3yVnsNlB974pR = '1'
	name = url.split(KCQExdbYFqM)[-1]
	CvSX7Etpz80eGlT1brgWZkJ = '''{"operationName":"HASHTAG_VIDEOS_QUERY","variables":{"hashtag_name":"#myhashtagname","page":mypagenumber},"query":"fragment FRAG_VIDEO_BASE on Video {  id  xid  title  description  thumbnail: thumbnailURL(size: \\"x240\\")  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  bestAvailableQuality  duration  createdAt  viewerEngagement {    id    liked    favorited    __typename  }  isExplicit  canDisplayAds  aspectRatio  stats {    id    views {      id      total      __typename    }    __typename  }  language {    id    codeAlpha2    __typename  }  videoHeight: height  videoWidth: width  __typename}fragment CHANNEL_BASE_FRAG on Channel {  id  xid  name  displayName  description  logoURL(size: \\"x25\\")  logoURLx60: logoURL(size: \\"x60\\")  coverURL(size: \\"x200\\")  coverURLx1024: coverURL(size: \\"1024x\\")  isFollowed  isArtist  accountType  __typename}fragment VIDEO_FRAG on Video {  id  ...FRAG_VIDEO_BASE  channel {    id    ...CHANNEL_BASE_FRAG    __typename  }  __typename}query HASHTAG_VIDEOS_QUERY($hashtag_name: String!, $page: Int!) {  contentFeed(    name: HASHTAG    filter: {name: {eq: $hashtag_name}, post: {eq: VIDEO}}    sort: {create: DESC}    page: $page    first: 30  ) {    totalCount    pageInfo {      hasNextPage      nextPage      __typename    }    edges {      node {        post {          ...VIDEO_FRAG          __typename        }        featured        __typename      }      __typename    }    __typename  }}"}'''
	CvSX7Etpz80eGlT1brgWZkJ = CvSX7Etpz80eGlT1brgWZkJ.replace('myhashtagname',name)
	CvSX7Etpz80eGlT1brgWZkJ = CvSX7Etpz80eGlT1brgWZkJ.replace('mypagenumber',aOZ3yVnsNlB974pR)
	ppsyEOKtjW3GY6nUPF = zu649N5027IWgsLMRU3e(CvSX7Etpz80eGlT1brgWZkJ)
	if ppsyEOKtjW3GY6nUPF:
		mmf4jR1lkKcFnwSxd9Ers = lMeKd3hC6cmS('dict',ppsyEOKtjW3GY6nUPF)
		NmyrJzuVBxZ = mmf4jR1lkKcFnwSxd9Ers['data']['contentFeed']['edges']
		for dVRQBgxrlkDK1vHG8TmohNZa3yAcOY in NmyrJzuVBxZ:
			Kr1n9xq5TY4gohlVdNEu0b = str(dVRQBgxrlkDK1vHG8TmohNZa3yAcOY['node']['post']['duration'])
			title = XTL0AWmwbDJfGRNi(dVRQBgxrlkDK1vHG8TmohNZa3yAcOY['node']['post']['title'])
			title = title.replace('\/',KCQExdbYFqM)
			Ozs53xWnMc = dVRQBgxrlkDK1vHG8TmohNZa3yAcOY['node']['post']['xid']
			y90BoFz8MA1ZThaSC2ILXHiK3OY6w = dVRQBgxrlkDK1vHG8TmohNZa3yAcOY['node']['post']['thumbnailx480']
			y90BoFz8MA1ZThaSC2ILXHiK3OY6w = y90BoFz8MA1ZThaSC2ILXHiK3OY6w.replace('\/',KCQExdbYFqM)
			c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr+'/video/'+Ozs53xWnMc
			zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,403,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,Kr1n9xq5TY4gohlVdNEu0b)
		if '"hasNextPage":true' in ppsyEOKtjW3GY6nUPF:
			aOZ3yVnsNlB974pR = str(int(aOZ3yVnsNlB974pR)+1)
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'صفحة '+aOZ3yVnsNlB974pR,url,416,cdZKMn68Pzg4,aOZ3yVnsNlB974pR)
	return
def zu649N5027IWgsLMRU3e(CvSX7Etpz80eGlT1brgWZkJ,search=cdZKMn68Pzg4):
	if W5domCu6XrQUFkiPpa3bNLtHglG: CvSX7Etpz80eGlT1brgWZkJ = CvSX7Etpz80eGlT1brgWZkJ.encode(vczMIlkCAh2u10B3)
	eSyiVDZgNTMPsm5qFJQAlIUB = wwAizrT8xmZbWKcB()
	headers = {"Authorization":eSyiVDZgNTMPsm5qFJQAlIUB,"Origin":cDTdfqVAF0BLGiX364IEwaZbr}
	if search:
		u1P73L0UmkA4eaIBbCgZfrvRtJ = NSdOvMkYVXusnpbT5P6trAx2ZL8UC0
		headers.update({'Content-Type':'application/json','Referer':cDTdfqVAF0BLGiX364IEwaZbr+KCQExdbYFqM,'X-DM-AppInfo-Id':'com.dailymotion.neon'})
	else:
		u1P73L0UmkA4eaIBbCgZfrvRtJ = Nl3Tz5nOPvLKqH7jJAVs1mF2r
		headers.update({'Content-Type':'text/plain; charset=utf-8'})
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(AlfMBJhUD65to2WrQcb,'POST',Nl3Tz5nOPvLKqH7jJAVs1mF2r,CvSX7Etpz80eGlT1brgWZkJ,headers,cdZKMn68Pzg4,cdZKMn68Pzg4,'DAILYMOTION-GET_PAGEDATA-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	return OO1cj2REUZHJ8x5V
def wwAizrT8xmZbWKcB():
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(AlfMBJhUD65to2WrQcb,'GET',cDTdfqVAF0BLGiX364IEwaZbr,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'DAILYMOTION-GET_AUTHINTICATION-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	L8ZCQRjWUoh = ffUFBJQ57j2XgoGeOLn9uwpC.findall('apiClientId.*?return"(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	L8ZCQRjWUoh = L8ZCQRjWUoh[nnsBpJv6XL3OzHoe4Vuhr]
	Ro8GnV4rHCueZczYKJX3b0hSNkBp = ffUFBJQ57j2XgoGeOLn9uwpC.findall('apiClientSecret.*?return"(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	Ro8GnV4rHCueZczYKJX3b0hSNkBp = Ro8GnV4rHCueZczYKJX3b0hSNkBp[nnsBpJv6XL3OzHoe4Vuhr]
	l9K0hfSoFkrUxqzQHLAMgO7cbvy = 'https://graphql.api.dailymotion.com/oauth/token'
	UUGLiJvdSVzlKx5soQhM8jpfgTBO7 = 'client_credentials'
	data = {'client_id':L8ZCQRjWUoh,'client_secret':Ro8GnV4rHCueZczYKJX3b0hSNkBp,'grant_type':UUGLiJvdSVzlKx5soQhM8jpfgTBO7}
	headers = {'Content-Type':'application/x-www-form-urlencoded'}
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(AlfMBJhUD65to2WrQcb,'POST',l9K0hfSoFkrUxqzQHLAMgO7cbvy,data,headers,cdZKMn68Pzg4,cdZKMn68Pzg4,'DAILYMOTION-GET_AUTHINTICATION-2nd')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	itxKks3Ih8cvm2MTrpXgYWJAaqL = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"access_token": *"(.*?)".*?"token_type": *"(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	AAWrf84vgX,x3EVc7mqXFdgnKTszHRBNbPLG = itxKks3Ih8cvm2MTrpXgYWJAaqL[0]
	eSyiVDZgNTMPsm5qFJQAlIUB = x3EVc7mqXFdgnKTszHRBNbPLG+" "+AAWrf84vgX
	return eSyiVDZgNTMPsm5qFJQAlIUB
def z4hetAJw3NaT9ROjG6xbZ5CHlW81(search,VS3jbIxtKQ=cdZKMn68Pzg4):
	search,EL8zUgbXheot,showDialogs = qbIcHCMdkFKn21e(search)
	if not VS3jbIxtKQ and showDialogs:
		wUXZhFO0dc935oyS2xMNLJDB1t7 = ['بحث عن فيديوهات','بحث عن آخر الفيديوهات','بحث عن الفيديوهات الاكثر مشاهدة','(جيد للمسلسلات) بحث عن قوائم تشغيل','بحث عن مستخدم','بحث عن بث حي','بحث عن هاشتاك']
		AS6jLpMwW5Ql3kUFNfT = NAfHLMC8Ip64FmT7l5oJWXaq3hK('موقع ديلي موشن - اختر البحث',wUXZhFO0dc935oyS2xMNLJDB1t7)
		if AS6jLpMwW5Ql3kUFNfT==-1: return
		elif AS6jLpMwW5Ql3kUFNfT==0: VS3jbIxtKQ = 'videos?sortBy='
		elif AS6jLpMwW5Ql3kUFNfT==1: VS3jbIxtKQ = 'videos?sortBy=RECENT'
		elif AS6jLpMwW5Ql3kUFNfT==2: VS3jbIxtKQ = 'videos?sortBy=VIEW_COUNT'
		elif AS6jLpMwW5Ql3kUFNfT==3: VS3jbIxtKQ = 'playlists'
		elif AS6jLpMwW5Ql3kUFNfT==4: VS3jbIxtKQ = 'channels'
		elif AS6jLpMwW5Ql3kUFNfT==5: VS3jbIxtKQ = 'lives'
		elif AS6jLpMwW5Ql3kUFNfT==6: VS3jbIxtKQ = 'hashtags'
	elif '_DAILYMOTION-VIDEOS_' in EL8zUgbXheot: VS3jbIxtKQ = 'videos?sortBy='
	elif '_DAILYMOTION-PLAYLISTS_' in EL8zUgbXheot: VS3jbIxtKQ = 'playlists'
	elif '_DAILYMOTION-CHANNELS_' in EL8zUgbXheot: VS3jbIxtKQ = 'channels'
	elif '_DAILYMOTION-LIVES_' in EL8zUgbXheot: VS3jbIxtKQ = 'lives'
	elif '_DAILYMOTION-HASHTAGS_' in EL8zUgbXheot: VS3jbIxtKQ = 'hashtags'
	elif not VS3jbIxtKQ: VS3jbIxtKQ = 'videos?sortBy='
	if not search:
		search = BzkmLuvJD9n25Pg()
		if not search: return
	if 'videos' in VS3jbIxtKQ: z7gom8OKtCxkGlWMPI1DNi(search+KCQExdbYFqM+VS3jbIxtKQ)
	elif 'playlists' in VS3jbIxtKQ: cMs8xfbvnWPGdziyJp0SAuLV5N(search)
	elif 'channels' in VS3jbIxtKQ: nKZS7F94Dpw5YUfxiCelo6brc3z(search)
	elif 'lives' in VS3jbIxtKQ: g8gCD9BGS0eyrWT(search)
	elif 'hashtags' in VS3jbIxtKQ: NNRgoxY3sv52fmZM(search)
	return
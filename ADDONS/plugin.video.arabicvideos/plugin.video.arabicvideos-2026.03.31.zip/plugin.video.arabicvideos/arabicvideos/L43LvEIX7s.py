# -*- coding: utf-8 -*-
from RgJNGc7YMP import *
UkXlAzsMcamKJrEIgnxi6bWh = 'FASELHD2'
headers = {'User-Agent':cdZKMn68Pzg4}
nc3GLkA65oxOd = '_FH2_'
cDTdfqVAF0BLGiX364IEwaZbr = USuRxnPlV5.SITESURLS[UkXlAzsMcamKJrEIgnxi6bWh][nnsBpJv6XL3OzHoe4Vuhr]
cJWUPuDGM0Yybv5a9KnIrVzhH78 = ['FaselHD']
def HHN5EpbszV3iA2m89hGSQjaPgUZy(mode,url,text):
	if   mode==590: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = kUq58vC7x9hWma164JejMKQ()
	elif mode==591: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = GDQUH4fN02sIt81mAcY(url,text)
	elif mode==592: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = RPZbqous7rtdy56LeI18Cv04AKHW(url)
	elif mode==593: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = RRDJdY2uVAykMUN9Fr4v7E0nZKX(url,text)
	elif mode==599: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = z4hetAJw3NaT9ROjG6xbZ5CHlW81(text)
	else: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = False
	return xsGUcR3ef6glKY5hQwpFXEaSt2mrIz
def kUq58vC7x9hWma164JejMKQ():
	u1P73L0UmkA4eaIBbCgZfrvRtJ = cDTdfqVAF0BLGiX364IEwaZbr
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',u1P73L0UmkA4eaIBbCgZfrvRtJ,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'FASELHD2-MENU-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'بحث في الموقع',u1P73L0UmkA4eaIBbCgZfrvRtJ,599,cdZKMn68Pzg4,cdZKMn68Pzg4,'_REMEMBERRESULTS_')
	zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('<h3>(.*?)<.*?href="(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	udsnZkQyF3Air1Jfa = nnsBpJv6XL3OzHoe4Vuhr
	for title,c0cDhidBlOn7 in items:
		c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr
		title = title.strip(VBpIH2QSmvDGlA6TO3e)
		if any(value in title for value in cJWUPuDGM0Yybv5a9KnIrVzhH78): continue
		zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+title,c0cDhidBlOn7,591,cdZKMn68Pzg4,cdZKMn68Pzg4,'featured'+str(udsnZkQyF3Air1Jfa))
		udsnZkQyF3Air1Jfa += hiuZa0PIsErm6UC7
	zJLApFBcIhnSj('link',Gzygq01Kcb9U3+' ===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"main-menu"(.*?)</nav>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[nnsBpJv6XL3OzHoe4Vuhr]
		BxyImC5vLNnH3Ro8 = ffUFBJQ57j2XgoGeOLn9uwpC.findall('<li (.*?)</li>',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for doSG8hTOgfkb0z7cn in BxyImC5vLNnH3Ro8:
			items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?>(.*?)<',doSG8hTOgfkb0z7cn,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			for c0cDhidBlOn7,title in items:
				if 'http' not in c0cDhidBlOn7: c0cDhidBlOn7 = u1P73L0UmkA4eaIBbCgZfrvRtJ+c0cDhidBlOn7
				zJLApFBcIhnSj('folder',UkXlAzsMcamKJrEIgnxi6bWh+'_SCRIPT_'+nc3GLkA65oxOd+title,c0cDhidBlOn7,591)
	return OO1cj2REUZHJ8x5V
def GDQUH4fN02sIt81mAcY(url,VS3jbIxtKQ=cdZKMn68Pzg4):
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'FASELHD2-TITLES-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	items = []
	if 'featured' in VS3jbIxtKQ:
		udsnZkQyF3Air1Jfa = VS3jbIxtKQ[-hiuZa0PIsErm6UC7]
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"boxes--holder"(.*?)</ul>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[int(udsnZkQyF3Air1Jfa)]
	elif VS3jbIxtKQ=='filters':
		ppvsMqCHf8SEzxQg = [OO1cj2REUZHJ8x5V.replace('\\/',KCQExdbYFqM).replace('\\"','"')]
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[nnsBpJv6XL3OzHoe4Vuhr]
	else:
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"boxes--holder"(.*?)"pagination"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[nnsBpJv6XL3OzHoe4Vuhr]
	if not items: items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?data-image="(.*?)".*?alt="(.*?)"',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	rgWUvoaJnZARc375bjQ = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية','حلقة']
	KRmzvoWYyxfXw37SEh1Q = []
	for c0cDhidBlOn7,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,title in items:
		title = title.strip(VBpIH2QSmvDGlA6TO3e)
		try: title = title.encode(OtSgpZ7UjmKc3byDVQeWaEs890Xi).decode(vczMIlkCAh2u10B3)
		except: pass
		title = gbd90SjF2mZqf81IRDaTwJkWu(title)
		if any(value in title.lower() for value in cJWUPuDGM0Yybv5a9KnIrVzhH78): continue
		E0w56WHxZPYGVvnTQ4O2t1C8DAjq = ffUFBJQ57j2XgoGeOLn9uwpC.findall('(.*?) (الحلقة|حلقة).\d+',title,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if '/movseries/' in c0cDhidBlOn7: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,591,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
		elif E0w56WHxZPYGVvnTQ4O2t1C8DAjq:
			title = '_MOD_'+E0w56WHxZPYGVvnTQ4O2t1C8DAjq[0][0]
			if title not in KRmzvoWYyxfXw37SEh1Q:
				zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,593,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
				KRmzvoWYyxfXw37SEh1Q.append(title)
		elif any(value in title for value in rgWUvoaJnZARc375bjQ): zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,592,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
		else: zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,593,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
	if VS3jbIxtKQ=='filters':
		TTHMO0LXA8IVRgukFC6d4B3rG7U = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"more_button_page":(.*?),',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if TTHMO0LXA8IVRgukFC6d4B3rG7U:
			count = TTHMO0LXA8IVRgukFC6d4B3rG7U[0]
			c0cDhidBlOn7 = url+'/offset/'+count
			zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'صفحة أخرى',c0cDhidBlOn7,591,cdZKMn68Pzg4,cdZKMn68Pzg4,'filters')
	elif 'featured' not in VS3jbIxtKQ:
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('class="pagination(.*?)</div>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if ppvsMqCHf8SEzxQg:
			KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
			items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)">(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			for c0cDhidBlOn7,title in items:
				title = gbd90SjF2mZqf81IRDaTwJkWu(title)
				c0cDhidBlOn7 = gbd90SjF2mZqf81IRDaTwJkWu(c0cDhidBlOn7)
				if 'http' not in c0cDhidBlOn7: c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr+c0cDhidBlOn7
				zJLApFBcIhnSj('folder',nc3GLkA65oxOd+'صفحة '+title,c0cDhidBlOn7,591,cdZKMn68Pzg4,cdZKMn68Pzg4,'details4')
	return
def RRDJdY2uVAykMUN9Fr4v7E0nZKX(url,data=cdZKMn68Pzg4):
	if '/Episodes.php' in url:
		headers = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'POST',url,data,headers,cdZKMn68Pzg4,cdZKMn68Pzg4,'FASELHD2-SEASONS_EPISODES-1st')
		OO1cj2REUZHJ8x5V = '"EpisodesList"'+Zty0AsgQ5jpkTh91OW.content+'</div>'
	else:
		Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(K8DZxE74Afz52gBYbOMtpvql0RJma,'GET',url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'FASELHD2-SEASONS_EPISODES-2nd')
		OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	fh6qmOxoiv1UPXZanLprDeMI8 = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"inner--image"><img src="(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	y90BoFz8MA1ZThaSC2ILXHiK3OY6w = fh6qmOxoiv1UPXZanLprDeMI8[nnsBpJv6XL3OzHoe4Vuhr] if fh6qmOxoiv1UPXZanLprDeMI8 else cdZKMn68Pzg4
	items = []
	if not data:
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"SeasonsList"(.*?)</ul>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if ppvsMqCHf8SEzxQg:
			KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[nnsBpJv6XL3OzHoe4Vuhr]
			items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('data-id="(.*?)" data-season="(.*?)".*?">(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			if len(items)>1:
				for w6ImbV0vxLgs9NoMXJ42cO8alAd,v7BFbdjHVQwcOZ1Il86huxJs9ge,title in items:
					c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr+'/wp-content/themes/AflamPlus/Inc/Ajax/Single/Episodes.php'
					H3F607d1jsXEnMvor2 = 'season='+v7BFbdjHVQwcOZ1Il86huxJs9ge+'&post_id='+w6ImbV0vxLgs9NoMXJ42cO8alAd
					zJLApFBcIhnSj('folder',nc3GLkA65oxOd+title,c0cDhidBlOn7,593,y90BoFz8MA1ZThaSC2ILXHiK3OY6w,cdZKMn68Pzg4,H3F607d1jsXEnMvor2)
		data = IZQbmFzLHDtXfc
	if data and len(items)<bVX3ev1spE:
		ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"EpisodesList"(.*?)</div>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if ppvsMqCHf8SEzxQg:
			KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[nnsBpJv6XL3OzHoe4Vuhr]
			items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)">(.*?)<em>(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
			for c0cDhidBlOn7,CCpDMVI0dq2,UHXfFEWmlxMAnzju4 in items:
				title = CCpDMVI0dq2+VBpIH2QSmvDGlA6TO3e+UHXfFEWmlxMAnzju4
				title = title.strip(VBpIH2QSmvDGlA6TO3e)
				zJLApFBcIhnSj('video',nc3GLkA65oxOd+title,c0cDhidBlOn7,592,y90BoFz8MA1ZThaSC2ILXHiK3OY6w)
	return
def RPZbqous7rtdy56LeI18Cv04AKHW(url):
	url = url.strip(KCQExdbYFqM)+'/watch/'
	XFj0lV5yMtS67EwbCJ9oO,ivH6wA3K87bMu4CFDWZ,ZZnPUQW4BjTMhwc21o5JGVOLf = [],[],[]
	Zty0AsgQ5jpkTh91OW = e4qbrCQPyuMjpK(AlfMBJhUD65to2WrQcb,'GET',url,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,'FASELHD2-PLAY-1st')
	OO1cj2REUZHJ8x5V = Zty0AsgQ5jpkTh91OW.content
	Vxmvwdp53LetBqA6ycNDGO = ffUFBJQ57j2XgoGeOLn9uwpC.findall('العمر :.*?<strong">(.*?)</strong>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if Vxmvwdp53LetBqA6ycNDGO and bMOpKuUkQ5J2(UkXlAzsMcamKJrEIgnxi6bWh,url,Vxmvwdp53LetBqA6ycNDGO): return
	c0cDhidBlOn7 = ffUFBJQ57j2XgoGeOLn9uwpC.findall('<iframe src="(.*?)"',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if c0cDhidBlOn7:
		c0cDhidBlOn7 = c0cDhidBlOn7[0]
		XFj0lV5yMtS67EwbCJ9oO.append(c0cDhidBlOn7+'?named=__embed')
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"main--contents"(.*?)</ul>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('data-i="(.*?)".*?data-id="(.*?)".*?<span>(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for zTWvBbKS9Q1LFO7tUu4Jo3E6,w6ImbV0vxLgs9NoMXJ42cO8alAd,title in items:
			title = title.strip(VBpIH2QSmvDGlA6TO3e)
			c0cDhidBlOn7 = cDTdfqVAF0BLGiX364IEwaZbr+'/wp-content/themes/AflamPlus/Inc/Ajax/Single/Server.php?id='+w6ImbV0vxLgs9NoMXJ42cO8alAd+'&i='+zTWvBbKS9Q1LFO7tUu4Jo3E6
			XFj0lV5yMtS67EwbCJ9oO.append(c0cDhidBlOn7+'?named='+title+'__watch')
	ppvsMqCHf8SEzxQg = ffUFBJQ57j2XgoGeOLn9uwpC.findall('"downloads"(.*?)</div>',OO1cj2REUZHJ8x5V,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
	if ppvsMqCHf8SEzxQg:
		KdWauEhgN6OQzjRVm1ro8tkB3 = ppvsMqCHf8SEzxQg[0]
		items = ffUFBJQ57j2XgoGeOLn9uwpC.findall('href="(.*?)".*?<span>(.*?)<',KdWauEhgN6OQzjRVm1ro8tkB3,ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		for c0cDhidBlOn7,name in items:
			XFj0lV5yMtS67EwbCJ9oO.append(c0cDhidBlOn7+'?named='+name+'__download')
	for we1gUShrJEsnv7Aq in XFj0lV5yMtS67EwbCJ9oO:
		c0cDhidBlOn7,name = we1gUShrJEsnv7Aq.split('?named')
		if c0cDhidBlOn7 not in ivH6wA3K87bMu4CFDWZ:
			ivH6wA3K87bMu4CFDWZ.append(c0cDhidBlOn7)
			ZZnPUQW4BjTMhwc21o5JGVOLf.append(we1gUShrJEsnv7Aq)
	import r0y4XTKznF
	r0y4XTKznF.noHliPXkcg3pJTdSauCvm5sU(ZZnPUQW4BjTMhwc21o5JGVOLf,UkXlAzsMcamKJrEIgnxi6bWh,'video',url)
	return
def z4hetAJw3NaT9ROjG6xbZ5CHlW81(search):
	search,EL8zUgbXheot,showDialogs = qbIcHCMdkFKn21e(search)
	if search==cdZKMn68Pzg4: search = BzkmLuvJD9n25Pg()
	if search==cdZKMn68Pzg4: return
	search = search.replace(VBpIH2QSmvDGlA6TO3e,'+')
	u1P73L0UmkA4eaIBbCgZfrvRtJ = cDTdfqVAF0BLGiX364IEwaZbr
	url = u1P73L0UmkA4eaIBbCgZfrvRtJ+'/?s='+search
	GDQUH4fN02sIt81mAcY(url,'details5')
	return
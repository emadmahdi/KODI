# -*- coding: utf-8 -*-
from RgJNGc7YMP import *
UkXlAzsMcamKJrEIgnxi6bWh = 'GLOBALSEARCH'
nc3GLkA65oxOd = '_GLS_'
def HHN5EpbszV3iA2m89hGSQjaPgUZy(HHrpyfWjGC,kxY4EfTKobmQJ8OathHI53,JAYWBoz54tGw7O,aOZ3yVnsNlB974pR):
	if   HHrpyfWjGC==540: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = kUq58vC7x9hWma164JejMKQ()
	elif HHrpyfWjGC==541: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = LFhDxf0sbaMJ34BUe7(JAYWBoz54tGw7O)
	elif HHrpyfWjGC==542: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = VlDem3X2qRLW9EcxwFSa0(JAYWBoz54tGw7O,kxY4EfTKobmQJ8OathHI53,aOZ3yVnsNlB974pR)
	elif HHrpyfWjGC==543: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = dyFxfXn4IO6USkT()
	elif HHrpyfWjGC==548: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = Vwe16UlK7DnOcQYuxibTfWhA(kxY4EfTKobmQJ8OathHI53,JAYWBoz54tGw7O)
	elif HHrpyfWjGC==549: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = z4hetAJw3NaT9ROjG6xbZ5CHlW81(JAYWBoz54tGw7O)
	else: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = False
	return xsGUcR3ef6glKY5hQwpFXEaSt2mrIz
def kUq58vC7x9hWma164JejMKQ():
	zJLApFBcIhnSj('folder','بحث جديد لجميع المواقع',cdZKMn68Pzg4,549)
	zJLApFBcIhnSj('link','كيف يعمل بحث جميع المواقع','',543)
	zJLApFBcIhnSj('link',Gzygq01Kcb9U3+'==== كلمات البحث المخزنة ===='+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	E7hMbtIzwl5DPsCQ60roqfGm = sZHYrLPog4wmuW0ECdc(TV08xYHA2ok,'dict','GLOBALSEARCH_SPLITTED_ALL')
	if E7hMbtIzwl5DPsCQ60roqfGm:
		E7hMbtIzwl5DPsCQ60roqfGm = E7hMbtIzwl5DPsCQ60roqfGm['__SEQUENCED_COLUMNS__']
		for ohGe84MLmzaQXICbNvcVUkW in reversed(E7hMbtIzwl5DPsCQ60roqfGm):
			zJLApFBcIhnSj('folder',ohGe84MLmzaQXICbNvcVUkW,cdZKMn68Pzg4,549,cdZKMn68Pzg4,cdZKMn68Pzg4,ohGe84MLmzaQXICbNvcVUkW)
	return
def z4hetAJw3NaT9ROjG6xbZ5CHlW81(ohGe84MLmzaQXICbNvcVUkW):
	if not ohGe84MLmzaQXICbNvcVUkW:
		ohGe84MLmzaQXICbNvcVUkW = BzkmLuvJD9n25Pg()
		if not ohGe84MLmzaQXICbNvcVUkW: return
		ohGe84MLmzaQXICbNvcVUkW = ohGe84MLmzaQXICbNvcVUkW.lower()
	OHkUL3XJYCcvux60qez4rp7h8dnty = ohGe84MLmzaQXICbNvcVUkW.replace(nc3GLkA65oxOd,cdZKMn68Pzg4)
	BWmyO1TLnp7UXgh9b(OHkUL3XJYCcvux60qez4rp7h8dnty,'_ALL',True)
	zJLApFBcIhnSj('link','بحث جماعي للمواقع - '+OHkUL3XJYCcvux60qez4rp7h8dnty,'search_sites_all',542,cdZKMn68Pzg4,cdZKMn68Pzg4,OHkUL3XJYCcvux60qez4rp7h8dnty)
	zJLApFBcIhnSj('folder','بحث منفرد للمواقع - '+OHkUL3XJYCcvux60qez4rp7h8dnty,cdZKMn68Pzg4,541,cdZKMn68Pzg4,cdZKMn68Pzg4,OHkUL3XJYCcvux60qez4rp7h8dnty)
	zJLApFBcIhnSj('link',Gzygq01Kcb9U3+'===== ===== ===== '+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999)
	zJLApFBcIhnSj('folder','نتائج البحث مفصلة - '+OHkUL3XJYCcvux60qez4rp7h8dnty,'opened_sites_all',542,cdZKMn68Pzg4,cdZKMn68Pzg4,OHkUL3XJYCcvux60qez4rp7h8dnty)
	zJLApFBcIhnSj('folder','نتائج البحث مقسمة - '+OHkUL3XJYCcvux60qez4rp7h8dnty,'listed_sites_all',542,cdZKMn68Pzg4,cdZKMn68Pzg4,OHkUL3XJYCcvux60qez4rp7h8dnty)
	return
def BWmyO1TLnp7UXgh9b(a5P8A4H61OJh,WUDlLX2APpknMteRy8fBNh4,vqKRPWFxb4A0QtXL23sOVg):
	if WUDlLX2APpknMteRy8fBNh4=='_ALL': mBaviOqJuZWDwrSYyUl2cLT = '_GLS_'
	elif WUDlLX2APpknMteRy8fBNh4=='_GOOGLE': mBaviOqJuZWDwrSYyUl2cLT = '_GOS_'
	bb5P3wZefQrmK7dgcTz6hGkC4 = sZHYrLPog4wmuW0ECdc(TV08xYHA2ok,'list','GLOBALSEARCH_SPLITTED'+WUDlLX2APpknMteRy8fBNh4,a5P8A4H61OJh)
	jZ7hD2IWe54 = sZHYrLPog4wmuW0ECdc(TV08xYHA2ok,'list','GLOBALSEARCH_SPLITTED'+WUDlLX2APpknMteRy8fBNh4,mBaviOqJuZWDwrSYyUl2cLT+a5P8A4H61OJh)
	uVOoSHfqe4WtiF(TV08xYHA2ok,'GLOBALSEARCH_SPLITTED'+WUDlLX2APpknMteRy8fBNh4,a5P8A4H61OJh)
	uVOoSHfqe4WtiF(TV08xYHA2ok,'GLOBALSEARCH_SPLITTED'+WUDlLX2APpknMteRy8fBNh4,mBaviOqJuZWDwrSYyUl2cLT+a5P8A4H61OJh)
	yaibYfWHAPB = bb5P3wZefQrmK7dgcTz6hGkC4+jZ7hD2IWe54
	if yaibYfWHAPB and vqKRPWFxb4A0QtXL23sOVg: a5P8A4H61OJh = mBaviOqJuZWDwrSYyUl2cLT+a5P8A4H61OJh
	uAkLQ7gEZaIBv6Fyn(TV08xYHA2ok,'GLOBALSEARCH_SPLITTED'+WUDlLX2APpknMteRy8fBNh4,a5P8A4H61OJh,yaibYfWHAPB,tvpq3ilsT1ZYAenaVj09BC2d)
	return
def hhHux2SIiEe1ft(WUDlLX2APpknMteRy8fBNh4):
	BoyIUWYSNR0jhDxQwvJriO4PkL = JyLdvftP3CU(cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,'هل تريد مسح جميع كلمات البحث المخزنة في البرنامج ؟!!')
	if BoyIUWYSNR0jhDxQwvJriO4PkL!=1: return
	uVOoSHfqe4WtiF(TV08xYHA2ok,'GLOBALSEARCH_SPLITTED'+WUDlLX2APpknMteRy8fBNh4)
	uVOoSHfqe4WtiF(TV08xYHA2ok,'GLOBALSEARCH_DETAILED'+WUDlLX2APpknMteRy8fBNh4)
	uVOoSHfqe4WtiF(TV08xYHA2ok,'GLOBALSEARCH_DIVIDED'+WUDlLX2APpknMteRy8fBNh4)
	if WUDlLX2APpknMteRy8fBNh4=='_GOOGLE': uVOoSHfqe4WtiF(TV08xYHA2ok,'GOOGLESEARCH_RESULTS')
	NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,'تم بنجاح مسح جميع كلمات البحث المخزنة في البرنامج')
	return
def VlDem3X2qRLW9EcxwFSa0(OcWIiXphw7UVjYPMZnfk36JFTNsq0D,uuFLw0AbON5QhZySr8MgWRYxU1Ve,sAUTCzFhEdRb=cdZKMn68Pzg4,PSC0cIJA5g2zWTYl3xUVtDZRsia=wrAD3j7pXC4KmfvTHy5QbxBe0SgM,QCMF7GTZRJeopgyEbW1uKviL5wP={}):
	BBEwapyMZf3lO,IU71s9jHaQVTBWS,dKxkGDyb1cpgHZTtqWsUJFCf4n,T6LSZfFPektbiRd,R9IcLVCtrSOD = [],{},{},{},{}
	if '_all' in uuFLw0AbON5QhZySr8MgWRYxU1Ve: WUDlLX2APpknMteRy8fBNh4,ZZ7vkMQKEHSICXWdTgbj,mBaviOqJuZWDwrSYyUl2cLT = '_ALL','_all','_GLS_'
	elif '_google' in uuFLw0AbON5QhZySr8MgWRYxU1Ve: WUDlLX2APpknMteRy8fBNh4,ZZ7vkMQKEHSICXWdTgbj,mBaviOqJuZWDwrSYyUl2cLT = '_GOOGLE','_google','_GOS_'
	if uuFLw0AbON5QhZySr8MgWRYxU1Ve in ['listed_sites'+ZZ7vkMQKEHSICXWdTgbj,'opened_sites'+ZZ7vkMQKEHSICXWdTgbj,'closed_sites'+ZZ7vkMQKEHSICXWdTgbj]:
		if uuFLw0AbON5QhZySr8MgWRYxU1Ve=='listed_sites'+ZZ7vkMQKEHSICXWdTgbj: BBEwapyMZf3lO = sZHYrLPog4wmuW0ECdc(TV08xYHA2ok,'list','GLOBALSEARCH_SPLITTED'+WUDlLX2APpknMteRy8fBNh4,mBaviOqJuZWDwrSYyUl2cLT+OcWIiXphw7UVjYPMZnfk36JFTNsq0D)
		elif uuFLw0AbON5QhZySr8MgWRYxU1Ve=='opened_sites'+ZZ7vkMQKEHSICXWdTgbj: BBEwapyMZf3lO = sZHYrLPog4wmuW0ECdc(TV08xYHA2ok,'list','GLOBALSEARCH_DETAILED'+WUDlLX2APpknMteRy8fBNh4,OcWIiXphw7UVjYPMZnfk36JFTNsq0D)
		elif uuFLw0AbON5QhZySr8MgWRYxU1Ve=='closed_sites'+ZZ7vkMQKEHSICXWdTgbj: BBEwapyMZf3lO = sZHYrLPog4wmuW0ECdc(TV08xYHA2ok,'list','GLOBALSEARCH_DIVIDED'+WUDlLX2APpknMteRy8fBNh4,(sAUTCzFhEdRb,OcWIiXphw7UVjYPMZnfk36JFTNsq0D))
	if not BBEwapyMZf3lO:
		rejRY592MzwLXCqP6kNISHByim = 'هذا البحث غير موجود في كاش البرنامج \n\n\n'
		li3O6w58Lr1AhRbzvXjeDU7MdH = 'هل تريد الآن البحث في جميع المواقع عن \n "'+bxf7gZvNK29cEoiAIJlMq0dP+VBpIH2QSmvDGlA6TO3e+OcWIiXphw7UVjYPMZnfk36JFTNsq0D+VBpIH2QSmvDGlA6TO3e+kH8E2zqNyims6KJfI+'" \n علما أن هذا البحث قد يحتاج بعض الوقت'
		if uuFLw0AbON5QhZySr8MgWRYxU1Ve=='search_sites'+ZZ7vkMQKEHSICXWdTgbj: KZ4oqDz5xgA2tkGcTaeQ1Lh3dp = li3O6w58Lr1AhRbzvXjeDU7MdH
		else: KZ4oqDz5xgA2tkGcTaeQ1Lh3dp = rejRY592MzwLXCqP6kNISHByim+li3O6w58Lr1AhRbzvXjeDU7MdH
		BoyIUWYSNR0jhDxQwvJriO4PkL = JyLdvftP3CU(cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,KZ4oqDz5xgA2tkGcTaeQ1Lh3dp)
		if BoyIUWYSNR0jhDxQwvJriO4PkL!=1: return
		tHOfW4iaMLm8VuZegxobrlnj5A0yB(c5oDzdPaOE8,c5oDzdPaOE8,c5oDzdPaOE8)
		SsziMZd5UbeL2NRxVpwjO(F0FeocLXmbJhdBwQnS18PCHZIU,xxd7Xp5lvem(UkXlAzsMcamKJrEIgnxi6bWh)+'   Search For: [ '+OcWIiXphw7UVjYPMZnfk36JFTNsq0D+' ]')
		h6IOyVTo9F = 1
		for xgPSaoLzTlFtQD37M6HIEsWY in PSC0cIJA5g2zWTYl3xUVtDZRsia:
			SR2EuODYfzkVWiH0m = QCMF7GTZRJeopgyEbW1uKviL5wP[xgPSaoLzTlFtQD37M6HIEsWY] if QCMF7GTZRJeopgyEbW1uKviL5wP else OcWIiXphw7UVjYPMZnfk36JFTNsq0D
			try: EsoNPCTO6a243HIqXh0R,KIOap9Wsnru,tcDxzmPhwuVGE9ls0n6g = hhHQ695ZrMo2bFnIJqt(xgPSaoLzTlFtQD37M6HIEsWY)
			except: continue
			IU71s9jHaQVTBWS[xgPSaoLzTlFtQD37M6HIEsWY] = []
			X9XExg7ect62uBzjfqhPCyb18 = '_NODIALOGS_'
			if '-' in xgPSaoLzTlFtQD37M6HIEsWY: X9XExg7ect62uBzjfqhPCyb18 = X9XExg7ect62uBzjfqhPCyb18+'_REMEMBERRESULTS__'+xgPSaoLzTlFtQD37M6HIEsWY+'_'
			if h6IOyVTo9F:
				bD7kJZhMCdaqF68P45KlNIgO1.sleep(0.75)
				R9IcLVCtrSOD[xgPSaoLzTlFtQD37M6HIEsWY] = qMrpRl8enOuvS6hV2XcZgT(daemon=IZQbmFzLHDtXfc,target=KIOap9Wsnru,args=(SR2EuODYfzkVWiH0m+X9XExg7ect62uBzjfqhPCyb18,))
				R9IcLVCtrSOD[xgPSaoLzTlFtQD37M6HIEsWY].start()
			else: KIOap9Wsnru(SR2EuODYfzkVWiH0m+X9XExg7ect62uBzjfqhPCyb18)
			bJqPkYBXsenxTRwKu(N6EjMQZJwbdDLla0C24Opifg(xgPSaoLzTlFtQD37M6HIEsWY),cdZKMn68Pzg4,bD7kJZhMCdaqF68P45KlNIgO1=1000)
		if h6IOyVTo9F:
			bD7kJZhMCdaqF68P45KlNIgO1.sleep(2)
			for xgPSaoLzTlFtQD37M6HIEsWY in PSC0cIJA5g2zWTYl3xUVtDZRsia: R9IcLVCtrSOD[xgPSaoLzTlFtQD37M6HIEsWY].join(10)
			bD7kJZhMCdaqF68P45KlNIgO1.sleep(2)
		for xgPSaoLzTlFtQD37M6HIEsWY in PSC0cIJA5g2zWTYl3xUVtDZRsia:
			try: EsoNPCTO6a243HIqXh0R,KIOap9Wsnru,tcDxzmPhwuVGE9ls0n6g = hhHQ695ZrMo2bFnIJqt(xgPSaoLzTlFtQD37M6HIEsWY)
			except: continue
			for CQpgO980c57WrijoU6tb in USuRxnPlV5.menuItemsLIST:
				kuMXTLrvIZGfjCDtA9YNJ5SxQK,yy0cNBFOGVZh8rIeQ4,kxY4EfTKobmQJ8OathHI53,HHrpyfWjGC,fh6qmOxoiv1UPXZanLprDeMI8,aOZ3yVnsNlB974pR,JAYWBoz54tGw7O,x8FkISpTrmqPJe2nvZOWU7zuNcj,g8tTFcBGwdKlo42LUkW = CQpgO980c57WrijoU6tb
				if tcDxzmPhwuVGE9ls0n6g in yy0cNBFOGVZh8rIeQ4:
					if 'IPTV-' in xgPSaoLzTlFtQD37M6HIEsWY and (239>=HHrpyfWjGC>=230 or 289>=HHrpyfWjGC>=280):
						if CQpgO980c57WrijoU6tb in IU71s9jHaQVTBWS['IPTV-LIVE']: continue
						if CQpgO980c57WrijoU6tb in IU71s9jHaQVTBWS['IPTV-MOVIES']: continue
						if CQpgO980c57WrijoU6tb in IU71s9jHaQVTBWS['IPTV-SERIES']: continue
						if 'صفحة' not in yy0cNBFOGVZh8rIeQ4:
							if   kuMXTLrvIZGfjCDtA9YNJ5SxQK=='live': xgPSaoLzTlFtQD37M6HIEsWY = 'IPTV-LIVE'
							elif kuMXTLrvIZGfjCDtA9YNJ5SxQK=='video': xgPSaoLzTlFtQD37M6HIEsWY = 'IPTV-MOVIES'
							elif kuMXTLrvIZGfjCDtA9YNJ5SxQK=='folder': xgPSaoLzTlFtQD37M6HIEsWY = 'IPTV-SERIES'
						else:
							if   'LIVE' in kxY4EfTKobmQJ8OathHI53: xgPSaoLzTlFtQD37M6HIEsWY = 'IPTV-LIVE'
							elif 'MOVIES' in kxY4EfTKobmQJ8OathHI53: xgPSaoLzTlFtQD37M6HIEsWY = 'IPTV-MOVIES'
							elif 'SERIES' in kxY4EfTKobmQJ8OathHI53: xgPSaoLzTlFtQD37M6HIEsWY = 'IPTV-SERIES'
					elif 'M3U-' in xgPSaoLzTlFtQD37M6HIEsWY and 729>=HHrpyfWjGC>=710:
						if CQpgO980c57WrijoU6tb in IU71s9jHaQVTBWS['M3U-LIVE']: continue
						if CQpgO980c57WrijoU6tb in IU71s9jHaQVTBWS['M3U-MOVIES']: continue
						if CQpgO980c57WrijoU6tb in IU71s9jHaQVTBWS['M3U-SERIES']: continue
						if 'صفحة' not in yy0cNBFOGVZh8rIeQ4:
							if   kuMXTLrvIZGfjCDtA9YNJ5SxQK=='live': xgPSaoLzTlFtQD37M6HIEsWY = 'M3U-LIVE'
							elif kuMXTLrvIZGfjCDtA9YNJ5SxQK=='video': xgPSaoLzTlFtQD37M6HIEsWY = 'M3U-MOVIES'
							elif kuMXTLrvIZGfjCDtA9YNJ5SxQK=='folder': xgPSaoLzTlFtQD37M6HIEsWY = 'M3U-SERIES'
						else:
							if   'LIVE' in kxY4EfTKobmQJ8OathHI53: xgPSaoLzTlFtQD37M6HIEsWY = 'M3U-LIVE'
							elif 'MOVIES' in kxY4EfTKobmQJ8OathHI53: xgPSaoLzTlFtQD37M6HIEsWY = 'M3U-MOVIES'
							elif 'SERIES' in kxY4EfTKobmQJ8OathHI53: xgPSaoLzTlFtQD37M6HIEsWY = 'M3U-SERIES'
					elif 'YOUTUBE-' in xgPSaoLzTlFtQD37M6HIEsWY and 149>=HHrpyfWjGC>=140:
						if CQpgO980c57WrijoU6tb in IU71s9jHaQVTBWS['YOUTUBE-CHANNELS']: continue
						if CQpgO980c57WrijoU6tb in IU71s9jHaQVTBWS['YOUTUBE-PLAYLISTS']: continue
						if CQpgO980c57WrijoU6tb in IU71s9jHaQVTBWS['YOUTUBE-VIDEOS']: continue
						if 'صفحة أخرى' in yy0cNBFOGVZh8rIeQ4 or ':: ' in yy0cNBFOGVZh8rIeQ4:
							continue
						else:
							if   HHrpyfWjGC==144 and 'USER' in yy0cNBFOGVZh8rIeQ4: xgPSaoLzTlFtQD37M6HIEsWY = 'YOUTUBE-CHANNELS'
							elif HHrpyfWjGC==144 and 'CHNL' in yy0cNBFOGVZh8rIeQ4: xgPSaoLzTlFtQD37M6HIEsWY = 'YOUTUBE-CHANNELS'
							elif HHrpyfWjGC==144 and 'LIST' in yy0cNBFOGVZh8rIeQ4: xgPSaoLzTlFtQD37M6HIEsWY = 'YOUTUBE-PLAYLISTS'
							elif HHrpyfWjGC==143: xgPSaoLzTlFtQD37M6HIEsWY = 'YOUTUBE-VIDEOS'
							else: continue
					elif 'DAILYMOTION-' in xgPSaoLzTlFtQD37M6HIEsWY and 419>=HHrpyfWjGC>=400:
						if CQpgO980c57WrijoU6tb in IU71s9jHaQVTBWS['DAILYMOTION-PLAYLISTS']: continue
						if CQpgO980c57WrijoU6tb in IU71s9jHaQVTBWS['DAILYMOTION-CHANNELS']: continue
						if CQpgO980c57WrijoU6tb in IU71s9jHaQVTBWS['DAILYMOTION-VIDEOS']: continue
						if CQpgO980c57WrijoU6tb in IU71s9jHaQVTBWS['DAILYMOTION-LIVES']: continue
						if CQpgO980c57WrijoU6tb in IU71s9jHaQVTBWS['DAILYMOTION-HASHTAGS']: continue
						if   HHrpyfWjGC in [401,405]: xgPSaoLzTlFtQD37M6HIEsWY = 'DAILYMOTION-PLAYLISTS'
						elif HHrpyfWjGC in [402,406]: xgPSaoLzTlFtQD37M6HIEsWY = 'DAILYMOTION-CHANNELS'
						elif HHrpyfWjGC in [404]: xgPSaoLzTlFtQD37M6HIEsWY = 'DAILYMOTION-VIDEOS'
						elif HHrpyfWjGC in [415]: xgPSaoLzTlFtQD37M6HIEsWY = 'DAILYMOTION-LIVES'
						elif HHrpyfWjGC in [416]: xgPSaoLzTlFtQD37M6HIEsWY = 'DAILYMOTION-HASHTAGS'
					elif 'PANET-' in xgPSaoLzTlFtQD37M6HIEsWY and 39>=HHrpyfWjGC>=30:
						if CQpgO980c57WrijoU6tb in IU71s9jHaQVTBWS['PANET-SERIES']: continue
						if CQpgO980c57WrijoU6tb in IU71s9jHaQVTBWS['PANET-MOVIES']: continue
						if   HHrpyfWjGC in [32,39]: xgPSaoLzTlFtQD37M6HIEsWY = 'PANET-SERIES'
						elif HHrpyfWjGC in [33,39]: xgPSaoLzTlFtQD37M6HIEsWY = 'PANET-MOVIES'
					elif 'IFILM-' in xgPSaoLzTlFtQD37M6HIEsWY and 29>=HHrpyfWjGC>=20:
						if CQpgO980c57WrijoU6tb in IU71s9jHaQVTBWS['IFILM-ARABIC']: continue
						if CQpgO980c57WrijoU6tb in IU71s9jHaQVTBWS['IFILM-ENGLISH']: continue
						if   '/ar.' in kxY4EfTKobmQJ8OathHI53: xgPSaoLzTlFtQD37M6HIEsWY = 'IFILM-ARABIC'
						elif '/en.' in kxY4EfTKobmQJ8OathHI53: xgPSaoLzTlFtQD37M6HIEsWY = 'IFILM-ENGLISH'
					IU71s9jHaQVTBWS[xgPSaoLzTlFtQD37M6HIEsWY].append(CQpgO980c57WrijoU6tb)
		for xgPSaoLzTlFtQD37M6HIEsWY in list(IU71s9jHaQVTBWS.keys()):
			dKxkGDyb1cpgHZTtqWsUJFCf4n[xgPSaoLzTlFtQD37M6HIEsWY] = []
			T6LSZfFPektbiRd[xgPSaoLzTlFtQD37M6HIEsWY] = []
			for kuMXTLrvIZGfjCDtA9YNJ5SxQK,yy0cNBFOGVZh8rIeQ4,kxY4EfTKobmQJ8OathHI53,HHrpyfWjGC,fh6qmOxoiv1UPXZanLprDeMI8,aOZ3yVnsNlB974pR,JAYWBoz54tGw7O,x8FkISpTrmqPJe2nvZOWU7zuNcj,g8tTFcBGwdKlo42LUkW in IU71s9jHaQVTBWS[xgPSaoLzTlFtQD37M6HIEsWY]:
				CQpgO980c57WrijoU6tb = (kuMXTLrvIZGfjCDtA9YNJ5SxQK,yy0cNBFOGVZh8rIeQ4,kxY4EfTKobmQJ8OathHI53,HHrpyfWjGC,fh6qmOxoiv1UPXZanLprDeMI8,aOZ3yVnsNlB974pR,JAYWBoz54tGw7O,x8FkISpTrmqPJe2nvZOWU7zuNcj,g8tTFcBGwdKlo42LUkW)
				if 'صفحة' in yy0cNBFOGVZh8rIeQ4 and kuMXTLrvIZGfjCDtA9YNJ5SxQK=='folder': T6LSZfFPektbiRd[xgPSaoLzTlFtQD37M6HIEsWY].append(CQpgO980c57WrijoU6tb)
				else: dKxkGDyb1cpgHZTtqWsUJFCf4n[xgPSaoLzTlFtQD37M6HIEsWY].append(CQpgO980c57WrijoU6tb)
		O0c1JFe6wtVsyD2UgHki5bCfPpvBz,iku96GWV05 = [],[]
		bNRdCW4JEwY7T = list(dKxkGDyb1cpgHZTtqWsUJFCf4n.keys())
		IvBkQW84Axbr2nC5FNKEcLRg = RBbaFi3ZLnIgrfNOy0jU7kPQYp(bNRdCW4JEwY7T)
		gLIZ24eCoKX0HF5Nk = []
		for xgPSaoLzTlFtQD37M6HIEsWY in IvBkQW84Axbr2nC5FNKEcLRg:
			if isinstance(xgPSaoLzTlFtQD37M6HIEsWY,tuple):
				gLIZ24eCoKX0HF5Nk = [xgPSaoLzTlFtQD37M6HIEsWY]
				continue
			if xgPSaoLzTlFtQD37M6HIEsWY not in PSC0cIJA5g2zWTYl3xUVtDZRsia: continue
			if dKxkGDyb1cpgHZTtqWsUJFCf4n[xgPSaoLzTlFtQD37M6HIEsWY]:
				jeqgyCEd3YZ = N6EjMQZJwbdDLla0C24Opifg(xgPSaoLzTlFtQD37M6HIEsWY)
				XBwxciUkGRd4CNm5p67neZlT0A = [('link',bxf7gZvNK29cEoiAIJlMq0dP+'===== '+jeqgyCEd3YZ+' ====='+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,9999,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4)]
				if 0: AJCD3xIbdyq9tTRKLBMWjmgz1o = OcWIiXphw7UVjYPMZnfk36JFTNsq0D+' - '+'بحث'+VBpIH2QSmvDGlA6TO3e+jeqgyCEd3YZ
				else: AJCD3xIbdyq9tTRKLBMWjmgz1o = 'بحث'+VBpIH2QSmvDGlA6TO3e+jeqgyCEd3YZ+' - '+OcWIiXphw7UVjYPMZnfk36JFTNsq0D
				if len(dKxkGDyb1cpgHZTtqWsUJFCf4n[xgPSaoLzTlFtQD37M6HIEsWY])<8: cef7TKzkFwyjH = []
				else:
					BhmEc80v5VkYgfzsM4PpObItLZHW = Gzygq01Kcb9U3+AJCD3xIbdyq9tTRKLBMWjmgz1o+kH8E2zqNyims6KJfI
					cef7TKzkFwyjH = [('folder',mBaviOqJuZWDwrSYyUl2cLT+BhmEc80v5VkYgfzsM4PpObItLZHW,'closed_sites'+ZZ7vkMQKEHSICXWdTgbj,542,cdZKMn68Pzg4,xgPSaoLzTlFtQD37M6HIEsWY,OcWIiXphw7UVjYPMZnfk36JFTNsq0D,cdZKMn68Pzg4,cdZKMn68Pzg4)]
				xxocsmdv4WaUibJ1jq = dKxkGDyb1cpgHZTtqWsUJFCf4n[xgPSaoLzTlFtQD37M6HIEsWY]+T6LSZfFPektbiRd[xgPSaoLzTlFtQD37M6HIEsWY]
				ggcr8HzmFl6d = gLIZ24eCoKX0HF5Nk+XBwxciUkGRd4CNm5p67neZlT0A+xxocsmdv4WaUibJ1jq[:7]+cef7TKzkFwyjH
				O0c1JFe6wtVsyD2UgHki5bCfPpvBz += ggcr8HzmFl6d
				jcFD0UxwKbMGk8Yov = [('folder',mBaviOqJuZWDwrSYyUl2cLT+AJCD3xIbdyq9tTRKLBMWjmgz1o,'closed_sites'+ZZ7vkMQKEHSICXWdTgbj,542,cdZKMn68Pzg4,xgPSaoLzTlFtQD37M6HIEsWY,OcWIiXphw7UVjYPMZnfk36JFTNsq0D,cdZKMn68Pzg4,cdZKMn68Pzg4)]
				sPUateZmWGMhc9j = gLIZ24eCoKX0HF5Nk+jcFD0UxwKbMGk8Yov
				iku96GWV05 += sPUateZmWGMhc9j
				uAkLQ7gEZaIBv6Fyn(TV08xYHA2ok,'GLOBALSEARCH_DIVIDED'+WUDlLX2APpknMteRy8fBNh4,(xgPSaoLzTlFtQD37M6HIEsWY,OcWIiXphw7UVjYPMZnfk36JFTNsq0D),xxocsmdv4WaUibJ1jq,tvpq3ilsT1ZYAenaVj09BC2d)
				gLIZ24eCoKX0HF5Nk = []
		uAkLQ7gEZaIBv6Fyn(TV08xYHA2ok,'GLOBALSEARCH_DETAILED'+WUDlLX2APpknMteRy8fBNh4,OcWIiXphw7UVjYPMZnfk36JFTNsq0D,O0c1JFe6wtVsyD2UgHki5bCfPpvBz,tvpq3ilsT1ZYAenaVj09BC2d)
		uVOoSHfqe4WtiF(TV08xYHA2ok,'GLOBALSEARCH_SPLITTED'+WUDlLX2APpknMteRy8fBNh4,OcWIiXphw7UVjYPMZnfk36JFTNsq0D)
		uAkLQ7gEZaIBv6Fyn(TV08xYHA2ok,'GLOBALSEARCH_SPLITTED'+WUDlLX2APpknMteRy8fBNh4,mBaviOqJuZWDwrSYyUl2cLT+OcWIiXphw7UVjYPMZnfk36JFTNsq0D,iku96GWV05,tvpq3ilsT1ZYAenaVj09BC2d)
		NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,'البحث الجماعي انتهى بنجاح \n\n تم تخزين النتائج في كاش البرنامج لمدة ثلاثين يوم حتى تستطيع العودة إليها بدون عمل بحث جديد')
		BBEwapyMZf3lO = iku96GWV05 if uuFLw0AbON5QhZySr8MgWRYxU1Ve=='listed_sites'+ZZ7vkMQKEHSICXWdTgbj and iku96GWV05 else O0c1JFe6wtVsyD2UgHki5bCfPpvBz
	if uuFLw0AbON5QhZySr8MgWRYxU1Ve in ['listed_sites'+ZZ7vkMQKEHSICXWdTgbj,'opened_sites'+ZZ7vkMQKEHSICXWdTgbj,'closed_sites'+ZZ7vkMQKEHSICXWdTgbj]:
		for kuMXTLrvIZGfjCDtA9YNJ5SxQK,yy0cNBFOGVZh8rIeQ4,kxY4EfTKobmQJ8OathHI53,HHrpyfWjGC,fh6qmOxoiv1UPXZanLprDeMI8,aOZ3yVnsNlB974pR,JAYWBoz54tGw7O,x8FkISpTrmqPJe2nvZOWU7zuNcj,g8tTFcBGwdKlo42LUkW in BBEwapyMZf3lO:
			if uuFLw0AbON5QhZySr8MgWRYxU1Ve in ['listed_sites'+ZZ7vkMQKEHSICXWdTgbj,'opened_sites'+ZZ7vkMQKEHSICXWdTgbj] and 'صفحة' in yy0cNBFOGVZh8rIeQ4 and kuMXTLrvIZGfjCDtA9YNJ5SxQK=='folder': continue
			zJLApFBcIhnSj(kuMXTLrvIZGfjCDtA9YNJ5SxQK,yy0cNBFOGVZh8rIeQ4,kxY4EfTKobmQJ8OathHI53,HHrpyfWjGC,fh6qmOxoiv1UPXZanLprDeMI8,aOZ3yVnsNlB974pR,JAYWBoz54tGw7O,x8FkISpTrmqPJe2nvZOWU7zuNcj,g8tTFcBGwdKlo42LUkW)
	tHOfW4iaMLm8VuZegxobrlnj5A0yB(rrVbXS3ncE,rrVbXS3ncE,rrVbXS3ncE)
	return
def LFhDxf0sbaMJ34BUe7(search):
	IvBkQW84Axbr2nC5FNKEcLRg = RBbaFi3ZLnIgrfNOy0jU7kPQYp(RgmY38c0XdHUK1CVwqQ7orZ)
	for xgPSaoLzTlFtQD37M6HIEsWY in IvBkQW84Axbr2nC5FNKEcLRg:
		if '-' in xgPSaoLzTlFtQD37M6HIEsWY: continue
		if isinstance(xgPSaoLzTlFtQD37M6HIEsWY,tuple):
			USuRxnPlV5.menuItemsLIST.append(xgPSaoLzTlFtQD37M6HIEsWY)
			continue
		EsoNPCTO6a243HIqXh0R,KIOap9Wsnru,tcDxzmPhwuVGE9ls0n6g = hhHQ695ZrMo2bFnIJqt(xgPSaoLzTlFtQD37M6HIEsWY)
		name = N6EjMQZJwbdDLla0C24Opifg(xgPSaoLzTlFtQD37M6HIEsWY)+' - '+search
		zJLApFBcIhnSj('folder',tcDxzmPhwuVGE9ls0n6g+name,xgPSaoLzTlFtQD37M6HIEsWY,548,'','',search)
	return
def Vwe16UlK7DnOcQYuxibTfWhA(xgPSaoLzTlFtQD37M6HIEsWY,search):
	EsoNPCTO6a243HIqXh0R,KIOap9Wsnru,tcDxzmPhwuVGE9ls0n6g = hhHQ695ZrMo2bFnIJqt(xgPSaoLzTlFtQD37M6HIEsWY)
	KIOap9Wsnru(search)
	return
def dyFxfXn4IO6USkT():
	NiWSoAmhdkQPlTpneyVzDO8tw9aL('','',OPEJxmUqr9wAX1i,'هذا البحث يستخدم محركات البحث الصغيرة الموجودة في كل موقع من مواقع البرنامج .. ونتائج هذا البحث تعتمد على دقة وفعالية وبرمجة كل موقع منها\n\nللأسف هذه المحركات الصغيرة لا تفهم جميع تفاصيل الفيديوهات ولا تفهم طريقة تفكير البشر ولا تستطيع إصلاح الأخطاء الإملائية .. ولهذا هي تحتاج دقة كبيرة جدا في اختيار وكتابة كلمات البحث المناسبة الصحيحة الدقيقة حتى تجد لك طلبك')
	return
def ZZqCLn7Jil50Vrowup(OcWIiXphw7UVjYPMZnfk36JFTNsq0D=cdZKMn68Pzg4):
	ohGe84MLmzaQXICbNvcVUkW,X9XExg7ect62uBzjfqhPCyb18,showDialogs = qbIcHCMdkFKn21e(OcWIiXphw7UVjYPMZnfk36JFTNsq0D)
	if not ohGe84MLmzaQXICbNvcVUkW:
		ohGe84MLmzaQXICbNvcVUkW = BzkmLuvJD9n25Pg()
		if not ohGe84MLmzaQXICbNvcVUkW: return
		ohGe84MLmzaQXICbNvcVUkW = ohGe84MLmzaQXICbNvcVUkW.lower()
	SsziMZd5UbeL2NRxVpwjO(F0FeocLXmbJhdBwQnS18PCHZIU,xxd7Xp5lvem(UkXlAzsMcamKJrEIgnxi6bWh)+'   Search For: [ '+ohGe84MLmzaQXICbNvcVUkW+' ]')
	nuKdVC6ePlg = ohGe84MLmzaQXICbNvcVUkW+X9XExg7ect62uBzjfqhPCyb18
	if 0: s3sqnFejZx2,OHkUL3XJYCcvux60qez4rp7h8dnty = ohGe84MLmzaQXICbNvcVUkW+' - ',cdZKMn68Pzg4
	else: s3sqnFejZx2,OHkUL3XJYCcvux60qez4rp7h8dnty = cdZKMn68Pzg4,' - '+ohGe84MLmzaQXICbNvcVUkW
	zJLApFBcIhnSj('link',Gzygq01Kcb9U3+'مواقع سيرفرات خاصة - قليلة المشاكل'+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,157)
	zJLApFBcIhnSj('folder','_M3U_'+s3sqnFejZx2+'بحث M3U'+OHkUL3XJYCcvux60qez4rp7h8dnty,cdZKMn68Pzg4,719,cdZKMn68Pzg4,cdZKMn68Pzg4,nuKdVC6ePlg)
	zJLApFBcIhnSj('folder','_IPT_'+s3sqnFejZx2+'بحث IPTV'+OHkUL3XJYCcvux60qez4rp7h8dnty,cdZKMn68Pzg4,239,cdZKMn68Pzg4,cdZKMn68Pzg4,nuKdVC6ePlg)
	zJLApFBcIhnSj('folder','_BKR_'+s3sqnFejZx2+'بحث موقع بكرا'+OHkUL3XJYCcvux60qez4rp7h8dnty,cdZKMn68Pzg4,379,cdZKMn68Pzg4,cdZKMn68Pzg4,nuKdVC6ePlg)
	zJLApFBcIhnSj('folder','_ART_'+s3sqnFejZx2+'بحث موقع تونز عربية'+OHkUL3XJYCcvux60qez4rp7h8dnty,cdZKMn68Pzg4,739,cdZKMn68Pzg4,cdZKMn68Pzg4,nuKdVC6ePlg)
	zJLApFBcIhnSj('folder','_KRB_'+s3sqnFejZx2+'بحث موقع قناة كربلاء'+OHkUL3XJYCcvux60qez4rp7h8dnty,cdZKMn68Pzg4,329,cdZKMn68Pzg4,cdZKMn68Pzg4,nuKdVC6ePlg)
	zJLApFBcIhnSj('folder','_FH2_'+s3sqnFejZx2+'بحث موقع فاصل الثاني'+OHkUL3XJYCcvux60qez4rp7h8dnty,cdZKMn68Pzg4,599,cdZKMn68Pzg4,cdZKMn68Pzg4,nuKdVC6ePlg)
	zJLApFBcIhnSj('folder','_KTV_'+s3sqnFejZx2+'بحث موقع كتكوت تيفي'+OHkUL3XJYCcvux60qez4rp7h8dnty,cdZKMn68Pzg4,819,cdZKMn68Pzg4,cdZKMn68Pzg4,nuKdVC6ePlg)
	zJLApFBcIhnSj('folder','_EB1_'+s3sqnFejZx2+'بحث موقع ايجي بيست 1'+OHkUL3XJYCcvux60qez4rp7h8dnty,cdZKMn68Pzg4,779,cdZKMn68Pzg4,cdZKMn68Pzg4,nuKdVC6ePlg)
	zJLApFBcIhnSj('folder','_EB2_'+s3sqnFejZx2+'بحث موقع ايجي بيست 2'+OHkUL3XJYCcvux60qez4rp7h8dnty,cdZKMn68Pzg4,789,cdZKMn68Pzg4,cdZKMn68Pzg4,nuKdVC6ePlg)
	zJLApFBcIhnSj('folder','_IFL_'+s3sqnFejZx2+'  بحث موقع قناة آي فيلم'+OHkUL3XJYCcvux60qez4rp7h8dnty+wr0HaqRdJ2D9LT7nSO1KMe38ly,cdZKMn68Pzg4,29,cdZKMn68Pzg4,cdZKMn68Pzg4,nuKdVC6ePlg)
	zJLApFBcIhnSj('folder','_AKO_'+s3sqnFejZx2+'بحث موقع أكوام القديم'+OHkUL3XJYCcvux60qez4rp7h8dnty,cdZKMn68Pzg4,79,cdZKMn68Pzg4,cdZKMn68Pzg4,nuKdVC6ePlg)
	zJLApFBcIhnSj('folder','_AKW_'+s3sqnFejZx2+'بحث موقع أكوام الجديد'+OHkUL3XJYCcvux60qez4rp7h8dnty,cdZKMn68Pzg4,249,cdZKMn68Pzg4,cdZKMn68Pzg4,nuKdVC6ePlg)
	zJLApFBcIhnSj('folder','_MRF_'+s3sqnFejZx2+'بحث موقع قناة المعارف'+OHkUL3XJYCcvux60qez4rp7h8dnty,cdZKMn68Pzg4,49,cdZKMn68Pzg4,cdZKMn68Pzg4,nuKdVC6ePlg)
	zJLApFBcIhnSj('folder','_SHM_'+s3sqnFejZx2+'بحث موقع شوف ماكس'+OHkUL3XJYCcvux60qez4rp7h8dnty,cdZKMn68Pzg4,59,cdZKMn68Pzg4,cdZKMn68Pzg4,nuKdVC6ePlg)
	zJLApFBcIhnSj('link',Gzygq01Kcb9U3+'مواقع سيرفرات خاصة وعامة - كثيرة المشاكل'+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,157)
	zJLApFBcIhnSj('folder','_LRZ_'+s3sqnFejZx2+'بحث موقع لاروزا'+OHkUL3XJYCcvux60qez4rp7h8dnty,cdZKMn68Pzg4,709,cdZKMn68Pzg4,cdZKMn68Pzg4,nuKdVC6ePlg)
	zJLApFBcIhnSj('folder','_FJS_'+s3sqnFejZx2+' بحث موقع فجر شو'+OHkUL3XJYCcvux60qez4rp7h8dnty+VBpIH2QSmvDGlA6TO3e,cdZKMn68Pzg4,399,cdZKMn68Pzg4,cdZKMn68Pzg4,nuKdVC6ePlg)
	zJLApFBcIhnSj('folder','_TVF_'+s3sqnFejZx2+'بحث موقع تيفي فان'+OHkUL3XJYCcvux60qez4rp7h8dnty,cdZKMn68Pzg4,469,cdZKMn68Pzg4,cdZKMn68Pzg4,nuKdVC6ePlg)
	zJLApFBcIhnSj('folder','_LDN_'+s3sqnFejZx2+'بحث موقع لودي نت'+OHkUL3XJYCcvux60qez4rp7h8dnty,cdZKMn68Pzg4,459,cdZKMn68Pzg4,cdZKMn68Pzg4,nuKdVC6ePlg)
	zJLApFBcIhnSj('folder','_CMN_'+s3sqnFejZx2+'بحث موقع سيما ناو'+OHkUL3XJYCcvux60qez4rp7h8dnty,cdZKMn68Pzg4,309,cdZKMn68Pzg4,cdZKMn68Pzg4,nuKdVC6ePlg)
	zJLApFBcIhnSj('folder','_SHN_'+s3sqnFejZx2+'بحث موقع شاهد نيوز'+OHkUL3XJYCcvux60qez4rp7h8dnty,cdZKMn68Pzg4,589,cdZKMn68Pzg4,cdZKMn68Pzg4,nuKdVC6ePlg+'_NODIALOGS_')
	zJLApFBcIhnSj('folder','_ARS_'+s3sqnFejZx2+'بحث موقع عرب سييد'+OHkUL3XJYCcvux60qez4rp7h8dnty,cdZKMn68Pzg4,259,cdZKMn68Pzg4,cdZKMn68Pzg4,nuKdVC6ePlg)
	zJLApFBcIhnSj('folder','_CCB_'+s3sqnFejZx2+'بحث موقع سيما كلوب'+OHkUL3XJYCcvux60qez4rp7h8dnty,cdZKMn68Pzg4,829,cdZKMn68Pzg4,cdZKMn68Pzg4,nuKdVC6ePlg)
	zJLApFBcIhnSj('folder','_SH4_'+s3sqnFejZx2+'بحث موقع شاهد فوريو'+OHkUL3XJYCcvux60qez4rp7h8dnty,cdZKMn68Pzg4,119,cdZKMn68Pzg4,cdZKMn68Pzg4,nuKdVC6ePlg+'_NODIALOGS_')
	zJLApFBcIhnSj('folder','_SHT_'+s3sqnFejZx2+'بحث موقع شوفها تيفي'+OHkUL3XJYCcvux60qez4rp7h8dnty,cdZKMn68Pzg4,649,cdZKMn68Pzg4,cdZKMn68Pzg4,nuKdVC6ePlg)
	zJLApFBcIhnSj('folder','_WC1_'+s3sqnFejZx2+'بحث موقع وي سيما 1'+OHkUL3XJYCcvux60qez4rp7h8dnty,cdZKMn68Pzg4,569,cdZKMn68Pzg4,cdZKMn68Pzg4,nuKdVC6ePlg)
	zJLApFBcIhnSj('folder','_WC2_'+s3sqnFejZx2+'بحث موقع وي سيما 2'+OHkUL3XJYCcvux60qez4rp7h8dnty,cdZKMn68Pzg4,1009,cdZKMn68Pzg4,cdZKMn68Pzg4,nuKdVC6ePlg)
	zJLApFBcIhnSj('link',Gzygq01Kcb9U3+'مواقع سيرفرات عامة - كثيرة المشاكل'+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,157)
	zJLApFBcIhnSj('folder','_TKT_'+s3sqnFejZx2+'بحث موقع تكات'+OHkUL3XJYCcvux60qez4rp7h8dnty,cdZKMn68Pzg4,949,cdZKMn68Pzg4,cdZKMn68Pzg4,nuKdVC6ePlg)
	zJLApFBcIhnSj('folder','_FST_'+s3sqnFejZx2+'بحث موقع فوستا'+OHkUL3XJYCcvux60qez4rp7h8dnty,cdZKMn68Pzg4,609,cdZKMn68Pzg4,cdZKMn68Pzg4,nuKdVC6ePlg)
	zJLApFBcIhnSj('folder','_FBK_'+s3sqnFejZx2+'بحث موقع فبركة'+OHkUL3XJYCcvux60qez4rp7h8dnty,cdZKMn68Pzg4,629,cdZKMn68Pzg4,cdZKMn68Pzg4,nuKdVC6ePlg)
	zJLApFBcIhnSj('folder','_YQT_'+s3sqnFejZx2+'بحث موقع ياقوت'+OHkUL3XJYCcvux60qez4rp7h8dnty,cdZKMn68Pzg4,669,cdZKMn68Pzg4,cdZKMn68Pzg4,nuKdVC6ePlg)
	zJLApFBcIhnSj('folder','_SHB_'+s3sqnFejZx2+'بحث موقع شبكتي'+OHkUL3XJYCcvux60qez4rp7h8dnty,cdZKMn68Pzg4,969,cdZKMn68Pzg4,cdZKMn68Pzg4,nuKdVC6ePlg)
	zJLApFBcIhnSj('folder','_VRB_'+s3sqnFejZx2+'بحث موقع فاربون'+OHkUL3XJYCcvux60qez4rp7h8dnty,cdZKMn68Pzg4,879,cdZKMn68Pzg4,cdZKMn68Pzg4,nuKdVC6ePlg)
	zJLApFBcIhnSj('folder','_BRS_'+s3sqnFejZx2+'بحث موقع برستيج'+OHkUL3XJYCcvux60qez4rp7h8dnty,cdZKMn68Pzg4,659,cdZKMn68Pzg4,cdZKMn68Pzg4,nuKdVC6ePlg)
	zJLApFBcIhnSj('folder','_KRM_'+s3sqnFejZx2+'بحث موقع كرمالك'+OHkUL3XJYCcvux60qez4rp7h8dnty,cdZKMn68Pzg4,929,cdZKMn68Pzg4,cdZKMn68Pzg4,nuKdVC6ePlg)
	zJLApFBcIhnSj('folder','_ANZ_'+s3sqnFejZx2+'بحث موقع انمي زد'+OHkUL3XJYCcvux60qez4rp7h8dnty,cdZKMn68Pzg4,979,cdZKMn68Pzg4,cdZKMn68Pzg4,nuKdVC6ePlg)
	zJLApFBcIhnSj('folder','_FSK_'+s3sqnFejZx2+'بحث موقع فارسكو'+OHkUL3XJYCcvux60qez4rp7h8dnty,cdZKMn68Pzg4,999,cdZKMn68Pzg4,cdZKMn68Pzg4,nuKdVC6ePlg)
	zJLApFBcIhnSj('folder','_HLC_'+s3sqnFejZx2+'بحث موقع هلا سيما'+OHkUL3XJYCcvux60qez4rp7h8dnty,cdZKMn68Pzg4,89,cdZKMn68Pzg4,cdZKMn68Pzg4,nuKdVC6ePlg)
	zJLApFBcIhnSj('folder','_MST_'+s3sqnFejZx2+'بحث موقع المصطبة'+OHkUL3XJYCcvux60qez4rp7h8dnty,cdZKMn68Pzg4,869,cdZKMn68Pzg4,cdZKMn68Pzg4,nuKdVC6ePlg)
	zJLApFBcIhnSj('folder','_SNT_'+s3sqnFejZx2+'بحث موقع شوف نت'+OHkUL3XJYCcvux60qez4rp7h8dnty,cdZKMn68Pzg4,849,cdZKMn68Pzg4,cdZKMn68Pzg4,nuKdVC6ePlg)
	zJLApFBcIhnSj('folder','_DR7_'+s3sqnFejZx2+'بحث موقع دراما صح'+OHkUL3XJYCcvux60qez4rp7h8dnty,cdZKMn68Pzg4,689,cdZKMn68Pzg4,cdZKMn68Pzg4,nuKdVC6ePlg)
	zJLApFBcIhnSj('folder','_CFR_'+s3sqnFejZx2+'بحث موقع سيما فري'+OHkUL3XJYCcvux60qez4rp7h8dnty,cdZKMn68Pzg4,839,cdZKMn68Pzg4,cdZKMn68Pzg4,nuKdVC6ePlg)
	zJLApFBcIhnSj('folder','_CMF_'+s3sqnFejZx2+'بحث موقع سيما فانز'+OHkUL3XJYCcvux60qez4rp7h8dnty,cdZKMn68Pzg4,99,cdZKMn68Pzg4,cdZKMn68Pzg4,nuKdVC6ePlg)
	zJLApFBcIhnSj('folder','_CML_'+s3sqnFejZx2+'بحث موقع سيما لايت'+OHkUL3XJYCcvux60qez4rp7h8dnty,cdZKMn68Pzg4,479,cdZKMn68Pzg4,cdZKMn68Pzg4,nuKdVC6ePlg)
	zJLApFBcIhnSj('folder','_C4H_'+s3sqnFejZx2+'بحث موقع سيما 400'+OHkUL3XJYCcvux60qez4rp7h8dnty,cdZKMn68Pzg4,699,cdZKMn68Pzg4,cdZKMn68Pzg4,nuKdVC6ePlg)
	zJLApFBcIhnSj('folder','_ABD_'+s3sqnFejZx2+'بحث موقع سيما عبدو'+OHkUL3XJYCcvux60qez4rp7h8dnty,cdZKMn68Pzg4,559,cdZKMn68Pzg4,cdZKMn68Pzg4,nuKdVC6ePlg)
	zJLApFBcIhnSj('folder','_AKT_'+s3sqnFejZx2+'بحث موقع اكوام تيوب'+OHkUL3XJYCcvux60qez4rp7h8dnty,cdZKMn68Pzg4,859,cdZKMn68Pzg4,cdZKMn68Pzg4,nuKdVC6ePlg)
	zJLApFBcIhnSj('folder','_DCF_'+s3sqnFejZx2+'بحث موقع دراما كافيه'+OHkUL3XJYCcvux60qez4rp7h8dnty,cdZKMn68Pzg4,939,cdZKMn68Pzg4,cdZKMn68Pzg4,nuKdVC6ePlg)
	zJLApFBcIhnSj('folder','_FTV_'+s3sqnFejZx2+'بحث موقع فوشار تيفي'+OHkUL3XJYCcvux60qez4rp7h8dnty,cdZKMn68Pzg4,919,cdZKMn68Pzg4,cdZKMn68Pzg4,nuKdVC6ePlg)
	zJLApFBcIhnSj('folder','_CWB_'+s3sqnFejZx2+'بحث موقع سيما وبس'+OHkUL3XJYCcvux60qez4rp7h8dnty,cdZKMn68Pzg4,989,cdZKMn68Pzg4,cdZKMn68Pzg4,nuKdVC6ePlg)
	zJLApFBcIhnSj('folder','_AHK_'+s3sqnFejZx2+'بحث موقع أهواك تيفي'+OHkUL3XJYCcvux60qez4rp7h8dnty,cdZKMn68Pzg4,619,cdZKMn68Pzg4,cdZKMn68Pzg4,nuKdVC6ePlg)
	zJLApFBcIhnSj('folder','_SRT_'+s3sqnFejZx2+'بحث موقع سيريس تايم'+OHkUL3XJYCcvux60qez4rp7h8dnty,cdZKMn68Pzg4,899,cdZKMn68Pzg4,cdZKMn68Pzg4,nuKdVC6ePlg)
	zJLApFBcIhnSj('folder','_FVD_'+s3sqnFejZx2+'بحث موقع فوشار فيديو'+OHkUL3XJYCcvux60qez4rp7h8dnty,cdZKMn68Pzg4,909,cdZKMn68Pzg4,cdZKMn68Pzg4,nuKdVC6ePlg)
	zJLApFBcIhnSj('folder','_C4P_'+s3sqnFejZx2+'بحث موقع سيما فور بي'+OHkUL3XJYCcvux60qez4rp7h8dnty,cdZKMn68Pzg4,889,cdZKMn68Pzg4,cdZKMn68Pzg4,nuKdVC6ePlg)
	zJLApFBcIhnSj('folder','_EB4_'+s3sqnFejZx2+'بحث موقع ايجي بيست 4'+OHkUL3XJYCcvux60qez4rp7h8dnty,cdZKMn68Pzg4,809,cdZKMn68Pzg4,cdZKMn68Pzg4,nuKdVC6ePlg)
	zJLApFBcIhnSj('link',Gzygq01Kcb9U3+'مواقع سيرفرات خاصة - قليلة المشاكل'+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,157)
	zJLApFBcIhnSj('folder','_YUT_'+s3sqnFejZx2+'بحث موقع يوتيوب'+OHkUL3XJYCcvux60qez4rp7h8dnty,cdZKMn68Pzg4,149,cdZKMn68Pzg4,cdZKMn68Pzg4,nuKdVC6ePlg)
	zJLApFBcIhnSj('folder','_DLM_'+s3sqnFejZx2+'بحث موقع دايلي موشن'+OHkUL3XJYCcvux60qez4rp7h8dnty,cdZKMn68Pzg4,409,cdZKMn68Pzg4,cdZKMn68Pzg4,nuKdVC6ePlg)
	return
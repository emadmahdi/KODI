# -*- coding: utf-8 -*-
import sys as sjVE6XGymcf09qbiKODZdAC
LVpmDXhWH5wGKy1eqMB = sjVE6XGymcf09qbiKODZdAC.version_info [0] == 2
RGEuTe9PD7o45d2v = 2048
r3HIioGW0Nl = 7
def Brz09AF6apy52OuEq1s (ccr3g6sWvxSOqDiLJuF1Vf2KUtG):
	global YzIBLo1J4ZOCEPtjq
	SSzr8EskcFRLobZqtC2QeTyPg4Y = ord (ccr3g6sWvxSOqDiLJuF1Vf2KUtG [-1])
	JIf7wGht4BqbQ5Xik1mYTA3DeLvaPO = ccr3g6sWvxSOqDiLJuF1Vf2KUtG [:-1]
	ZYd0PzhKWmvFN5TfcQI = SSzr8EskcFRLobZqtC2QeTyPg4Y % len (JIf7wGht4BqbQ5Xik1mYTA3DeLvaPO)
	itRzfVamqWwLIynhGpDM4ZUe = JIf7wGht4BqbQ5Xik1mYTA3DeLvaPO [:ZYd0PzhKWmvFN5TfcQI] + JIf7wGht4BqbQ5Xik1mYTA3DeLvaPO [ZYd0PzhKWmvFN5TfcQI:]
	if LVpmDXhWH5wGKy1eqMB:
		MHSngXbpVZde6NiQc9IrCxt78 = unicode () .join ([unichr (ord (Ep0JIWsLABieR) - RGEuTe9PD7o45d2v - (D2bEPIlOQJy4dYntR3MCiKLusT + SSzr8EskcFRLobZqtC2QeTyPg4Y) % r3HIioGW0Nl) for D2bEPIlOQJy4dYntR3MCiKLusT, Ep0JIWsLABieR in enumerate (itRzfVamqWwLIynhGpDM4ZUe)])
	else:
		MHSngXbpVZde6NiQc9IrCxt78 = str () .join ([chr (ord (Ep0JIWsLABieR) - RGEuTe9PD7o45d2v - (D2bEPIlOQJy4dYntR3MCiKLusT + SSzr8EskcFRLobZqtC2QeTyPg4Y) % r3HIioGW0Nl) for D2bEPIlOQJy4dYntR3MCiKLusT, Ep0JIWsLABieR in enumerate (itRzfVamqWwLIynhGpDM4ZUe)])
	return eval (MHSngXbpVZde6NiQc9IrCxt78)
ObuCsdoDtKmhPLSMH8YGan,vbYokBuWlxeLDcdVNM60,J6jL2d7CKE0WA4lBXFPghR5eoxHb=Brz09AF6apy52OuEq1s,Brz09AF6apy52OuEq1s,Brz09AF6apy52OuEq1s
aNdix5gq7yeFHTMWhnzm8pX0Y16,dwiIAcPl04ey7Zv38Mz,zBGPHsxIiQmd7oTSORl9bAynr5kNq=J6jL2d7CKE0WA4lBXFPghR5eoxHb,vbYokBuWlxeLDcdVNM60,ObuCsdoDtKmhPLSMH8YGan
rbUkdYi32PJaRtnxhDvQs,TtyzcuW45VKA,LungQF89BqemOb32jJsZlW=zBGPHsxIiQmd7oTSORl9bAynr5kNq,dwiIAcPl04ey7Zv38Mz,aNdix5gq7yeFHTMWhnzm8pX0Y16
iRfoNckJs7Ibxzh5j92w8DSWF,NV3enkyQ7Rmp2LYAUagsCJz0ZP,HC9xWUMpBQJEuTteAqjd=LungQF89BqemOb32jJsZlW,TtyzcuW45VKA,rbUkdYi32PJaRtnxhDvQs
s8fcjBCSMxzAIkZQbJPga,AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu,liyzjA4RkEb1cT6fr5pGKdWNHOxM=HC9xWUMpBQJEuTteAqjd,NV3enkyQ7Rmp2LYAUagsCJz0ZP,iRfoNckJs7Ibxzh5j92w8DSWF
nfg30bHwd4aNV12SR7UjFck,Rsdai9xIEPcpuBMKOUwkTA05q,KNomgGw1kdMCBH=liyzjA4RkEb1cT6fr5pGKdWNHOxM,AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu,s8fcjBCSMxzAIkZQbJPga
SGazRxP3yBKZ15ILuch,YnHG75e2QWwo,S5fhsRT8JV=KNomgGw1kdMCBH,Rsdai9xIEPcpuBMKOUwkTA05q,nfg30bHwd4aNV12SR7UjFck
WupgNDhcjK1SiYsF5VLGb9w3loJqX,f8Ja1q5eO02B,xN4fKmsnyM3Y2=S5fhsRT8JV,YnHG75e2QWwo,SGazRxP3yBKZ15ILuch
uxE8MyoTRglrcaiQf,aar0zhDnJsOTP7EdgR16HIS29,opyTNwHgfqbZREWKU=xN4fKmsnyM3Y2,f8Ja1q5eO02B,WupgNDhcjK1SiYsF5VLGb9w3loJqX
On1WZJc6dtksqVNgSQ5GBAjuipe,AiCor1fIVTDxQUWwHe9vPR7,tRnTydV03Xfi7rbQ=opyTNwHgfqbZREWKU,aar0zhDnJsOTP7EdgR16HIS29,uxE8MyoTRglrcaiQf
LJPOQNK1mcG,k5oIaYyp2mnrLK49qhzS,zDek1IW37rq6UoKdwyRiAVpF=tRnTydV03Xfi7rbQ,AiCor1fIVTDxQUWwHe9vPR7,On1WZJc6dtksqVNgSQ5GBAjuipe
from RgJNGc7YMP import *
UkXlAzsMcamKJrEIgnxi6bWh = TtyzcuW45VKA(u"࠭ࡄࡐ࡙ࡑࡐࡔࡇࡄࠨ೧")
def HHN5EpbszV3iA2m89hGSQjaPgUZy(HHrpyfWjGC,kxY4EfTKobmQJ8OathHI53):
	if   HHrpyfWjGC==TtyzcuW45VKA(u"࠸࠹࠰൫"): xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = RToGWF1BuvsbVOEDgSk0PKdi4cl32a()
	elif HHrpyfWjGC==uxE8MyoTRglrcaiQf(u"࠹࠳࠲൬"): xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = RPZbqous7rtdy56LeI18Cv04AKHW(kxY4EfTKobmQJ8OathHI53)
	elif HHrpyfWjGC==dwiIAcPl04ey7Zv38Mz(u"࠳࠴࠴൭"): xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = AYmqIhOf6NLFdM()
	elif HHrpyfWjGC==LungQF89BqemOb32jJsZlW(u"࠴࠵࠶൮"): xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = jIDGfNJTsoxQXAZvqn()
	else: xsGUcR3ef6glKY5hQwpFXEaSt2mrIz = ksTLSoVGg0ht
	return xsGUcR3ef6glKY5hQwpFXEaSt2mrIz
def RPZbqous7rtdy56LeI18Cv04AKHW(kxY4EfTKobmQJ8OathHI53):
	bmgwWLk3er(kxY4EfTKobmQJ8OathHI53,UkXlAzsMcamKJrEIgnxi6bWh,TtyzcuW45VKA(u"ࠧࡷ࡫ࡧࡩࡴ࠭೨"))
	return
def jIDGfNJTsoxQXAZvqn():
	KZ4oqDz5xgA2tkGcTaeQ1Lh3dp = aar0zhDnJsOTP7EdgR16HIS29(u"ࠨลำ๋อࠦลๅ๋ࠣีฬฮืࠡษ็ๅ๏ี๊้ࠢฦ์ࠥอไึ๊อࠤๆ๐ࠠศๆ่์็฿ࠠศๆ่฻้๎ศࠡอ่ࠤศ฼ฺุࠢ฼่๎ࠦาาࠢส่็อฦๆหࠣห้๐ๅ๋่ࠣฯ๊ࠦรฯฬสีࠥࠨสฮ็ํ่๋ࠥไโษอࠤๆ๐ฯ๋๊ࠥࠤะ๋ࠠศะอหึࠦฯใหࠣห้฻่าหࠣ์ฬิสศำ๊ࠣํ฿ࠠๆๆไࠤฬ๊ี้ำฬࠤํฮูะ้สࠤุ๎แࠡ์หำศࠦวๅฬะ้๏๊ࠧ೩")
	NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,xN4fKmsnyM3Y2(u"ฺࠩี๏่ษࠡฬะ้๏๊ࠠศๆ่่ๆอสࠨ೪"),KZ4oqDz5xgA2tkGcTaeQ1Lh3dp)
	return
def RToGWF1BuvsbVOEDgSk0PKdi4cl32a():
	zJLApFBcIhnSj(rbUkdYi32PJaRtnxhDvQs(u"ࠪࡰ࡮ࡴ࡫ࠨ೫"),HC9xWUMpBQJEuTteAqjd(u"ࠫ฼ื๊ใหࠣฮา๋๊ๅ่่ࠢๆอสࠡษ็ๅ๏ี๊้ࠩ೬"),cdZKMn68Pzg4,liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"࠵࠶࠷൯"))
	zJLApFBcIhnSj(s8fcjBCSMxzAIkZQbJPga(u"ࠬࡲࡩ࡯࡭ࠪ೭"),S5fhsRT8JV(u"࠭ส฻์ํี๋ࠥใศ่ࠣฮา๋๊ๅࠢส่ๆ๐ฯ๋๊๊หฯ࠭೮"),cdZKMn68Pzg4,J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"࠶࠷࠷൰"))
	zJLApFBcIhnSj(Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠧ࡭࡫ࡱ࡯ࠬ೯"),Gzygq01Kcb9U3+SGazRxP3yBKZ15ILuch(u"ࠨࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦࠧ೰")+kH8E2zqNyims6KJfI,cdZKMn68Pzg4,AiCor1fIVTDxQUWwHe9vPR7(u"࠽࠾࠿࠹൱"))
	dBP2bvZMxaQJ9U1k5yNDSe = OMYxzuPXVQvRlg4qreioF()
	RldH72MP4hwWL6i = YRESXadfbIy3khwqmL8WC.stat(dBP2bvZMxaQJ9U1k5yNDSe).st_mtime
	O0ekN3yvUMwVlcqo17SsGut = []
	if W5domCu6XrQUFkiPpa3bNLtHglG: Tnrcgwu8bEAeZ = YRESXadfbIy3khwqmL8WC.listdir(dBP2bvZMxaQJ9U1k5yNDSe.encode(vczMIlkCAh2u10B3))
	else: Tnrcgwu8bEAeZ = YRESXadfbIy3khwqmL8WC.listdir(dBP2bvZMxaQJ9U1k5yNDSe.decode(vczMIlkCAh2u10B3))
	for egcKB4Phb2Fn15JfX0IApVd7mWz in Tnrcgwu8bEAeZ:
		if W5domCu6XrQUFkiPpa3bNLtHglG: egcKB4Phb2Fn15JfX0IApVd7mWz = egcKB4Phb2Fn15JfX0IApVd7mWz.decode(vczMIlkCAh2u10B3)
		if not egcKB4Phb2Fn15JfX0IApVd7mWz.startswith(LJPOQNK1mcG(u"ࠩࡩ࡭ࡱ࡫࡟ࠨೱ")): continue
		GLhTujPRxw7dBkE8VtDlOmNCpvzb = YRESXadfbIy3khwqmL8WC.path.join(dBP2bvZMxaQJ9U1k5yNDSe,egcKB4Phb2Fn15JfX0IApVd7mWz)
		RldH72MP4hwWL6i = YRESXadfbIy3khwqmL8WC.path.getmtime(GLhTujPRxw7dBkE8VtDlOmNCpvzb)
		O0ekN3yvUMwVlcqo17SsGut.append([egcKB4Phb2Fn15JfX0IApVd7mWz,RldH72MP4hwWL6i])
	O0ekN3yvUMwVlcqo17SsGut = sorted(O0ekN3yvUMwVlcqo17SsGut,reverse=IZQbmFzLHDtXfc,key=lambda key: key[hiuZa0PIsErm6UC7])
	for egcKB4Phb2Fn15JfX0IApVd7mWz,RldH72MP4hwWL6i in O0ekN3yvUMwVlcqo17SsGut:
		if xicJPb0AW1nsRfH3kCv7:
			try: egcKB4Phb2Fn15JfX0IApVd7mWz = egcKB4Phb2Fn15JfX0IApVd7mWz.decode(vczMIlkCAh2u10B3)
			except: pass
			egcKB4Phb2Fn15JfX0IApVd7mWz = egcKB4Phb2Fn15JfX0IApVd7mWz.encode(vczMIlkCAh2u10B3)
		GLhTujPRxw7dBkE8VtDlOmNCpvzb = YRESXadfbIy3khwqmL8WC.path.join(dBP2bvZMxaQJ9U1k5yNDSe,egcKB4Phb2Fn15JfX0IApVd7mWz)
		zJLApFBcIhnSj(AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"ࠪࡺ࡮ࡪࡥࡰࠩೲ"),egcKB4Phb2Fn15JfX0IApVd7mWz,GLhTujPRxw7dBkE8VtDlOmNCpvzb,AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"࠸࠹࠱൲"))
	return
def OMYxzuPXVQvRlg4qreioF():
	dBP2bvZMxaQJ9U1k5yNDSe = Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.getSetting(k5oIaYyp2mnrLK49qhzS(u"ࠫࡦࡼ࠮ࡥࡱࡺࡲࡱࡵࡡࡥ࠰ࡳࡥࡹ࡮ࠧೳ"))
	if dBP2bvZMxaQJ9U1k5yNDSe: return dBP2bvZMxaQJ9U1k5yNDSe
	Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.setSetting(LJPOQNK1mcG(u"ࠬࡧࡶ࠯ࡦࡲࡻࡳࡲ࡯ࡢࡦ࠱ࡴࡦࡺࡨࠨ೴"),qq9xw1jKIVH5kuNGMsPLiCO6Rp0Zv)
	return qq9xw1jKIVH5kuNGMsPLiCO6Rp0Zv
def AYmqIhOf6NLFdM():
	dBP2bvZMxaQJ9U1k5yNDSe = OMYxzuPXVQvRlg4qreioF()
	CC0ZyVANq2Gcapwz1dl5SJgIUDr4f = JyLdvftP3CU(TtyzcuW45VKA(u"࠭ࡣࡦࡰࡷࡩࡷ࠭೵"),cdZKMn68Pzg4,cdZKMn68Pzg4,tRnTydV03Xfi7rbQ(u"ࠧๆๅส๊ࠥะฮำ์้ࠤ๊๊แศฬࠣห้ะอๆ์็ࠫ೶"),bxf7gZvNK29cEoiAIJlMq0dP+dBP2bvZMxaQJ9U1k5yNDSe+kH8E2zqNyims6KJfI+zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"ࠨ࡞ࡱࡠࡳํะศ๊ࠢ์๋ࠥใศ่ࠣฮำุ๊็่่ࠢๆอสࠡษ็ๅ๏ี๊้ࠢส่ฯ๐ࠠหฯ่่์อࠠศ่อࠤออำหะาห๊ࠦ็ัษࠣห้ฮั็ษ่ะࠥ࠴่ࠠๆࠣฮึ๐ฯࠡฬ฽๎๏ืࠠศๆ่็ฬ์ࠠภࠩ೷"))
	if CC0ZyVANq2Gcapwz1dl5SJgIUDr4f==YnHG75e2QWwo(u"࠷൳"):
		SSwv0ERhlodaAfLQX8 = ZDudO4KVpTzJF0m(k5oIaYyp2mnrLK49qhzS(u"࠳൴"),On1WZJc6dtksqVNgSQ5GBAjuipe(u"่ࠩ็ฬ์ࠠหฯ่๎้ࠦๅๅใสฮࠥอไโ์า๎ํ࠭೸"),nfg30bHwd4aNV12SR7UjFck(u"ࠪࡰࡴࡩࡡ࡭ࠩ೹"),cdZKMn68Pzg4,ksTLSoVGg0ht,IZQbmFzLHDtXfc,dBP2bvZMxaQJ9U1k5yNDSe)
		BoyIUWYSNR0jhDxQwvJriO4PkL = JyLdvftP3CU(vbYokBuWlxeLDcdVNM60(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ೺"),cdZKMn68Pzg4,cdZKMn68Pzg4,aNdix5gq7yeFHTMWhnzm8pX0Y16(u"๋ࠬใศ่ࠣฮำุ๊็่่ࠢๆอสࠡษ็ฮา๋๊ๅࠩ೻"),bxf7gZvNK29cEoiAIJlMq0dP+dBP2bvZMxaQJ9U1k5yNDSe+kH8E2zqNyims6KJfI+LJPOQNK1mcG(u"࠭࡜࡯࡞ࡱ๋ีอ่๊ࠠࠣห้๋ใศ่ࠣห้าฯ๋ั่ࠣฯิา๋่้้ࠣ็วหࠢส่ๆ๐ฯ๋๊ࠣห้ะ๊ࠡฬะ้้ํวࠡษ้ฮࠥฮวิฬัำฬ๋่ࠠาสࠤฬ๊ศา่ส้ัࠦ࠮้ࠡ็ࠤฯื๊ะࠢสืฯิฯศ็๊ࠤอีไศ่๊ࠢࠥอไๆๅส๊ࠥอไใัํ้ࠥลࠧ೼"))
		if BoyIUWYSNR0jhDxQwvJriO4PkL==TtyzcuW45VKA(u"࠲൵"):
			Hgmcv0pjTFoGRLXdiP4rKSzs2Ab.setSetting(uxE8MyoTRglrcaiQf(u"ࠧࡢࡸ࠱ࡨࡴࡽ࡮࡭ࡱࡤࡨ࠳ࡶࡡࡵࡪࠪ೽"),SSwv0ERhlodaAfLQX8)
			NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,ObuCsdoDtKmhPLSMH8YGan(u"ࠨฬ่ࠤฯเ๊๋ำ้่ࠣอๆࠡฬัึ๏์ࠠศๆ่่ๆอสࠡษ็้า๋ไสࠩ೾"))
	return
def lLUNFT524ix(kxY4EfTKobmQJ8OathHI53,Hmq6vzsocj8wWg=cdZKMn68Pzg4,website=cdZKMn68Pzg4):
	SsziMZd5UbeL2NRxVpwjO(F0FeocLXmbJhdBwQnS18PCHZIU,xxd7Xp5lvem(UkXlAzsMcamKJrEIgnxi6bWh)+uxE8MyoTRglrcaiQf(u"ࠩࠣࠤࠥࡖࡲࡦࡲࡤࡶ࡮ࡴࡧࠡࡶࡲࠤࡩࡵࡷ࡯࡮ࡲࡥࡩࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ೿")+kxY4EfTKobmQJ8OathHI53+NV3enkyQ7Rmp2LYAUagsCJz0ZP(u"ࠪࠤࡢ࠭ഀ"))
	if not Hmq6vzsocj8wWg: Hmq6vzsocj8wWg = Aty25FEGpLUbfwKT19vzVm3IsYk(kxY4EfTKobmQJ8OathHI53)
	dBP2bvZMxaQJ9U1k5yNDSe = OMYxzuPXVQvRlg4qreioF()
	OO1KS902kyCdIta3RnLouAVxqPJW = DFr1WoZABRnSM79gObypfq(ksTLSoVGg0ht)
	egcKB4Phb2Fn15JfX0IApVd7mWz = OO1KS902kyCdIta3RnLouAVxqPJW.replace(VBpIH2QSmvDGlA6TO3e,aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠫࡤ࠭ഁ"))
	egcKB4Phb2Fn15JfX0IApVd7mWz = RQfVumjSLa16XNAp2d(egcKB4Phb2Fn15JfX0IApVd7mWz)
	egcKB4Phb2Fn15JfX0IApVd7mWz = nfg30bHwd4aNV12SR7UjFck(u"ࠬ࡬ࡩ࡭ࡧࡢࠫം")+str(int(BbIVuS4KecnqNvZz5GptR))[-LJPOQNK1mcG(u"࠶൶"):]+S5fhsRT8JV(u"࠭࡟ࠨഃ")+egcKB4Phb2Fn15JfX0IApVd7mWz+Hmq6vzsocj8wWg
	zvY4UMIJkScr9l = YRESXadfbIy3khwqmL8WC.path.join(dBP2bvZMxaQJ9U1k5yNDSe,egcKB4Phb2Fn15JfX0IApVd7mWz)
	pj3iPglDkueR29AH6U = {}
	pj3iPglDkueR29AH6U[aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠧࡂࡥࡦࡩࡵࡺ࠭ࡆࡰࡦࡳࡩ࡯࡮ࡨࠩഄ")] = cdZKMn68Pzg4
	pj3iPglDkueR29AH6U[dwiIAcPl04ey7Zv38Mz(u"ࠨࡃࡦࡧࡪࡶࡴࠨഅ")] = uxE8MyoTRglrcaiQf(u"ࠩ࠭࠳࠯࠭ആ")
	kxY4EfTKobmQJ8OathHI53 = kxY4EfTKobmQJ8OathHI53.replace(f8Ja1q5eO02B(u"ࠪࡺࡪࡸࡩࡧࡻࡳࡩࡪࡸ࠽ࡧࡣ࡯ࡷࡪ࠭ഇ"),cdZKMn68Pzg4)
	if nfg30bHwd4aNV12SR7UjFck(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴ࠾ࠩഈ") in kxY4EfTKobmQJ8OathHI53:
		HOCWKhxITtulVGX,wbIl8gEPfoLVHAjGX = kxY4EfTKobmQJ8OathHI53.rsplit(iRfoNckJs7Ibxzh5j92w8DSWF(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ࠿ࠪഉ"),dwiIAcPl04ey7Zv38Mz(u"࠴൷"))
		wbIl8gEPfoLVHAjGX = wbIl8gEPfoLVHAjGX.replace(liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"࠭ࡼࠨഊ"),cdZKMn68Pzg4).replace(uxE8MyoTRglrcaiQf(u"ࠧࠧࠩഋ"),cdZKMn68Pzg4)
	else: HOCWKhxITtulVGX,wbIl8gEPfoLVHAjGX = kxY4EfTKobmQJ8OathHI53,None
	if not wbIl8gEPfoLVHAjGX: wbIl8gEPfoLVHAjGX = knzwM2WCl7jAex9H4YFva()
	if wbIl8gEPfoLVHAjGX: pj3iPglDkueR29AH6U[nfg30bHwd4aNV12SR7UjFck(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬഌ")] = wbIl8gEPfoLVHAjGX
	if LungQF89BqemOb32jJsZlW(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࡀࠫ഍") in HOCWKhxITtulVGX: HOCWKhxITtulVGX,BTxbqm5VtWyhe7 = HOCWKhxITtulVGX.rsplit(liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࡁࠬഎ"),AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"࠵൸"))
	else: HOCWKhxITtulVGX,BTxbqm5VtWyhe7 = HOCWKhxITtulVGX,cdZKMn68Pzg4
	HOCWKhxITtulVGX = HOCWKhxITtulVGX.strip(aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠫࢁ࠭ഏ")).strip(nfg30bHwd4aNV12SR7UjFck(u"ࠬࠬࠧഐ")).strip(uxE8MyoTRglrcaiQf(u"࠭ࡼࠨ഑")).strip(uxE8MyoTRglrcaiQf(u"ࠧࠧࠩഒ"))
	BTxbqm5VtWyhe7 = BTxbqm5VtWyhe7.replace(AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"ࠨࡾࠪഓ"),cdZKMn68Pzg4).replace(rbUkdYi32PJaRtnxhDvQs(u"ࠩࠩࠫഔ"),cdZKMn68Pzg4)
	if BTxbqm5VtWyhe7:	pj3iPglDkueR29AH6U[TtyzcuW45VKA(u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫക")] = BTxbqm5VtWyhe7
	SsziMZd5UbeL2NRxVpwjO(F0FeocLXmbJhdBwQnS18PCHZIU,xxd7Xp5lvem(UkXlAzsMcamKJrEIgnxi6bWh)+TtyzcuW45VKA(u"ࠫࠥࠦࠠࡅࡱࡺࡲࡱࡵࡡࡥ࡫ࡱ࡫ࠥࡼࡩࡥࡧࡲࠤ࡫࡯࡬ࡦࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬഖ")+HOCWKhxITtulVGX+LJPOQNK1mcG(u"ࠬࠦ࡝ࠡࠢࠣࡌࡪࡧࡤࡦࡴࡶ࠾ࠥࡡࠠࠨഗ")+str(pj3iPglDkueR29AH6U)+LJPOQNK1mcG(u"࠭ࠠ࡞ࠢࠣࠤࡋ࡯࡬ࡦ࠼ࠣ࡟ࠥ࠭ഘ")+zvY4UMIJkScr9l+AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"ࠧࠡ࡟ࠪങ"))
	xlj2AYD4RmQg = AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"࠶࠶࠲࠵൹")*AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"࠶࠶࠲࠵൹")
	cXifm7wjTnyk2CN53OoLlJp1WZBg6 = DDIHrSF2Ue65Tasq8E1mPQZVbiw()//xlj2AYD4RmQg
	if not cXifm7wjTnyk2CN53OoLlJp1WZBg6:
		E3WHU2OdFfmX459c(WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠨࡴ࡬࡫࡭ࡺࠧച"),iRfoNckJs7Ibxzh5j92w8DSWF(u"่ࠩืฬำษࠡษ็ฮำุ๊็่ࠢะ์๎ไสࠩഛ"),aar0zhDnJsOTP7EdgR16HIS29(u"่้ࠪษำโࠢส่อืๆศ็ฯࠤ฿๐ัࠡไสำึࠦร็ࠢํัิีࠠๆไาหึࠦๅิษะอࠥอไหะี๎๋ࠦวๅใสี฿ฯࠠโ์ࠣะ์อาไ๋ࠢ฽้๐็ࠡใส๊ࠥะอๆ์็ࠤฬ๊แ๋ัํ์์อสࠡๆ้ࠤ๏฿ๅๅࠢ฼๊ิ้ࠠฦๆ์ࠤศ์๋ࠠไ๋้๋ࠥศา็ฯ๎ࠥฮั็ษ่ะ้่ࠥะ์ࠣฬา๊่ࠠา๊ࠤฬ๊ๅีๅ็อ๊ࠥว็ࠢอั๊๐ไࠡษ็ๅ๏ี๊้้สฮ่ࠥฯࠡ์ึฬอࠦวๆฬ็หฦࠦฬ่ษี็ࠥฮวๅ็็ๅฬะ้้ࠠำหࠥ็๊่ࠢั฻ํืษࠡ฻็ํࠥ฿ๅๅࠢฯ๋ฬุใࠡสุ์ึฯࠠึฯํัฮ่ࠦๅ้ำหࠥอไิสหࠤ็อๅࠡษ็้อืๅอ่ࠢศ็ะวࠡส่๊฾ࠦวๅสิ๊ฬ๋ฬࠡ็้ࠤฯำๅ๋ๆࠣห้็๊ะ์๋๋ฬะࠧജ"),LungQF89BqemOb32jJsZlW(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧഝ"))
		SsziMZd5UbeL2NRxVpwjO(E7lrS9VXJF58d2NUAfkvxwjmHM,xxd7Xp5lvem(UkXlAzsMcamKJrEIgnxi6bWh)+J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠬࠦࠠࠡࡗࡱࡥࡧࡲࡥࠡࡶࡲࠤࡩ࡫ࡴࡦࡴࡰ࡭ࡳ࡫ࠠࡵࡪࡨࠤࡩ࡯ࡳ࡬ࠢࡩࡶࡪ࡫ࠠࡴࡲࡤࡧࡪ࠭ഞ"))
		return ksTLSoVGg0ht
	if Hmq6vzsocj8wWg==S5fhsRT8JV(u"࠭࠮࡮࠵ࡸ࠼ࠬട"):
		lycT0JB1noerD5YANK2PbHa8QVM,pcX7zxFRmsADwUr = ek1pl9vDTX8HnjwUCJ6PQBsmfg4ZMq(UkXlAzsMcamKJrEIgnxi6bWh,HOCWKhxITtulVGX,pj3iPglDkueR29AH6U)
		if len(lycT0JB1noerD5YANK2PbHa8QVM)==LJPOQNK1mcG(u"࠶ൺ"):
			bJqPkYBXsenxTRwKu(ObuCsdoDtKmhPLSMH8YGan(u"ࠧโึ็ࠤๆ๐ࠠฦ์ฯหิࠦๅๅใࠣห้ะอๆ์็ࠫഠ"),cdZKMn68Pzg4)
			return ksTLSoVGg0ht
		elif len(lycT0JB1noerD5YANK2PbHa8QVM)==zDek1IW37rq6UoKdwyRiAVpF(u"࠱ൻ"): AS6jLpMwW5Ql3kUFNfT = AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"࠱ർ")
		elif len(lycT0JB1noerD5YANK2PbHa8QVM)>AiCor1fIVTDxQUWwHe9vPR7(u"࠳ൽ"):
			AS6jLpMwW5Ql3kUFNfT = NAfHLMC8Ip64FmT7l5oJWXaq3hK(ObuCsdoDtKmhPLSMH8YGan(u"ࠨษัฮึࠦวๅ็็ๅࠥอไๆ่สือ࠭ഡ"), lycT0JB1noerD5YANK2PbHa8QVM)
			if AS6jLpMwW5Ql3kUFNfT == -WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"࠴ൾ") :
				bJqPkYBXsenxTRwKu(liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠩอ้ࠥหไ฻ษฤࠤฬ๊สฮ็ํ่ࠬഢ"),cdZKMn68Pzg4)
				return ksTLSoVGg0ht
		HOCWKhxITtulVGX = pcX7zxFRmsADwUr[AS6jLpMwW5Ql3kUFNfT]
	RvU6MFQtJG4NTg3lz = TtyzcuW45VKA(u"࠴ൿ")
	import requests as JVaKHgG2Fy8AIWz
	if Hmq6vzsocj8wWg==aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠪ࠲ࡲ࠹ࡵ࠹ࠩണ"):
		zvY4UMIJkScr9l = zvY4UMIJkScr9l.rsplit(LungQF89BqemOb32jJsZlW(u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪത"))[nnsBpJv6XL3OzHoe4Vuhr]+uxE8MyoTRglrcaiQf(u"ࠬ࠴࡭ࡱ࠶ࠪഥ")
		oyufnwWte9Im4cFA6hSLODiGRMsJx8 = e4qbrCQPyuMjpK(AlfMBJhUD65to2WrQcb,WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"࠭ࡇࡆࡖࠪദ"),HOCWKhxITtulVGX,cdZKMn68Pzg4,pj3iPglDkueR29AH6U,cdZKMn68Pzg4,cdZKMn68Pzg4,s8fcjBCSMxzAIkZQbJPga(u"ࠧࡅࡑ࡚ࡒࡑࡕࡁࡅ࠯ࡇࡓ࡜ࡔࡌࡐࡃࡇࡣ࡛ࡏࡄࡆࡑ࠰࠵ࡸࡺࠧധ"))
		Fcw6dXreRNm8CuvBMnq1SaZV = oyufnwWte9Im4cFA6hSLODiGRMsJx8.content
		zz4ZPovUbyk5GEhNMs8JDnaVXftS = ffUFBJQ57j2XgoGeOLn9uwpC.findall(J6jL2d7CKE0WA4lBXFPghR5eoxHb(u"ࠨࠥࡈ࡜࡙ࡏࡎࡇ࠼࠱࠮ࡄࡡ࡜࡯࡞ࡵࡡ࠭࠴ࠪࡀࠫ࡞ࡠࡳࡢࡲ࡞ࠩന"),Fcw6dXreRNm8CuvBMnq1SaZV+S5fhsRT8JV(u"ࠩ࡟ࡲࡡࡸࠧഩ"),ffUFBJQ57j2XgoGeOLn9uwpC.DOTALL)
		if not zz4ZPovUbyk5GEhNMs8JDnaVXftS:
			SsziMZd5UbeL2NRxVpwjO(E7lrS9VXJF58d2NUAfkvxwjmHM,xxd7Xp5lvem(UkXlAzsMcamKJrEIgnxi6bWh)+f8Ja1q5eO02B(u"ࠪࠤࠥࠦࡔࡩࡧࠣࡱ࠸ࡻ࠸ࠡࡨ࡬ࡰࡪࠦࡤࡪࡦࠣࡲࡴࡺࠠࡩࡣࡹࡩࠥࡺࡨࡦࠢࡵࡩࡶࡻࡩࡳࡧࡧࠤࡱ࡯࡮࡬ࡵࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭പ")+HOCWKhxITtulVGX+vbYokBuWlxeLDcdVNM60(u"ࠫࠥࡣࠧഫ"))
			return ksTLSoVGg0ht
		c0cDhidBlOn7 = zz4ZPovUbyk5GEhNMs8JDnaVXftS[nnsBpJv6XL3OzHoe4Vuhr]
		if not c0cDhidBlOn7.startswith(rbUkdYi32PJaRtnxhDvQs(u"ࠬ࡮ࡴࡵࡲࠪബ")):
			if c0cDhidBlOn7.startswith(Tf2ZPslXS84Yw15aNkjQ7oOzqMc): c0cDhidBlOn7 = HOCWKhxITtulVGX.split(WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"࠭࠺ࠨഭ"),SGazRxP3yBKZ15ILuch(u"࠶඀"))[nnsBpJv6XL3OzHoe4Vuhr]+YnHG75e2QWwo(u"ࠧ࠻ࠩമ")+c0cDhidBlOn7
			elif c0cDhidBlOn7.startswith(KCQExdbYFqM): c0cDhidBlOn7 = CxlbPZwGTcH87e1sWhfSIz29uRUEpV(HOCWKhxITtulVGX,aar0zhDnJsOTP7EdgR16HIS29(u"ࠨࡷࡵࡰࠬയ"))+c0cDhidBlOn7
			else: c0cDhidBlOn7 = HOCWKhxITtulVGX.rsplit(KCQExdbYFqM,aNdix5gq7yeFHTMWhnzm8pX0Y16(u"࠷ඁ"))[nnsBpJv6XL3OzHoe4Vuhr]+KCQExdbYFqM+c0cDhidBlOn7
		oyufnwWte9Im4cFA6hSLODiGRMsJx8 = JVaKHgG2Fy8AIWz.request(zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"ࠩࡊࡉ࡙࠭ര"),c0cDhidBlOn7,headers=pj3iPglDkueR29AH6U,verify=ksTLSoVGg0ht)
		nzoFeDB9XugwEiU475RA = oyufnwWte9Im4cFA6hSLODiGRMsJx8.content
		UfcTHzgr1kiAQy4LwaB3Z5KNoX = len(nzoFeDB9XugwEiU475RA)
		HH9qnEIKr3kQzG1 = len(zz4ZPovUbyk5GEhNMs8JDnaVXftS)
		RvU6MFQtJG4NTg3lz = UfcTHzgr1kiAQy4LwaB3Z5KNoX*HH9qnEIKr3kQzG1
	else:
		UfcTHzgr1kiAQy4LwaB3Z5KNoX = k5oIaYyp2mnrLK49qhzS(u"࠱ං")*xlj2AYD4RmQg
		oyufnwWte9Im4cFA6hSLODiGRMsJx8 = JVaKHgG2Fy8AIWz.request(LJPOQNK1mcG(u"ࠪࡋࡊ࡚ࠧറ"),HOCWKhxITtulVGX,headers=pj3iPglDkueR29AH6U,verify=ksTLSoVGg0ht,stream=IZQbmFzLHDtXfc)
		if opyTNwHgfqbZREWKU(u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲ࡒࡥ࡯ࡩࡷ࡬ࠬല") in oyufnwWte9Im4cFA6hSLODiGRMsJx8.headers: RvU6MFQtJG4NTg3lz = int(oyufnwWte9Im4cFA6hSLODiGRMsJx8.headers[xN4fKmsnyM3Y2(u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡌࡦࡰࡪࡸ࡭࠭ള")])
		HH9qnEIKr3kQzG1 = int(RvU6MFQtJG4NTg3lz//UfcTHzgr1kiAQy4LwaB3Z5KNoX)
	ppcYGhHNRS6UMLVQkDKlb = int(RvU6MFQtJG4NTg3lz//xlj2AYD4RmQg)+aNdix5gq7yeFHTMWhnzm8pX0Y16(u"࠲ඃ")
	if RvU6MFQtJG4NTg3lz<ObuCsdoDtKmhPLSMH8YGan(u"࠴࠴࠴࠵࠶඄"):
		SsziMZd5UbeL2NRxVpwjO(E7lrS9VXJF58d2NUAfkvxwjmHM,xxd7Xp5lvem(UkXlAzsMcamKJrEIgnxi6bWh)+LungQF89BqemOb32jJsZlW(u"࡙࠭ࠠࠡࠢ࡭ࡩ࡫࡯ࠡࡨ࡬ࡰࡪࠦࡩࡴࠢࡷࡳࡴࠦࡳ࡮ࡣ࡯ࡰࠥࡵࡲࠡ࡫ࡷࠤ࡮ࡹࠠ࡮࠵ࡸ࠼ࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨഴ")+HOCWKhxITtulVGX+zBGPHsxIiQmd7oTSORl9bAynr5kNq(u"ࠧࠡ࡟ࠣࠤࠥ࡜ࡩࡥࡧࡲࠤ࡫࡯࡬ࡦࠢࡶ࡭ࡿ࡫࠺ࠡ࡝ࠣࠫവ")+str(ppcYGhHNRS6UMLVQkDKlb)+uxE8MyoTRglrcaiQf(u"ࠨࠢࡐࡆࠥࡣࠠࠡࠢࡄࡺࡦ࡯࡬ࡢࡤ࡯ࡩࠥࡹࡩࡻࡧ࠽ࠤࡠࠦࠧശ")+str(cXifm7wjTnyk2CN53OoLlJp1WZBg6)+LungQF89BqemOb32jJsZlW(u"ࠩࠣࡑࡇࠦ࡝ࠡࠢࠣࡊ࡮ࡲࡥ࠻ࠢ࡞ࠤࠬഷ")+zvY4UMIJkScr9l+aNdix5gq7yeFHTMWhnzm8pX0Y16(u"ࠪࠤࡢ࠭സ"))
		NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,uxE8MyoTRglrcaiQf(u"ࠫๆฺไࠡใํࠤ๊฿ัโหࠣัั๋ࠠๆๆไࠤฬ๊แ๋ัํ์ࠥษ่ࠡษ็้้็ࠠึ฼ํีࠥาฯศ๋่ࠢ์ึวࠡๆสࠤ๏๋ใ็ࠢ็่อืๆศ็ฯࠤฯำๅ๋ๆ๋ࠣีอࠠศๆ่่ๆ࠭ഹ"))
		return ksTLSoVGg0ht
	wwJPW0OnErUGxaKQyje = zDek1IW37rq6UoKdwyRiAVpF(u"࠷࠴࠵අ")
	TTmWLvhQBJtsUdMZ = cXifm7wjTnyk2CN53OoLlJp1WZBg6-ppcYGhHNRS6UMLVQkDKlb
	if TTmWLvhQBJtsUdMZ<wwJPW0OnErUGxaKQyje:
		SsziMZd5UbeL2NRxVpwjO(E7lrS9VXJF58d2NUAfkvxwjmHM,xxd7Xp5lvem(UkXlAzsMcamKJrEIgnxi6bWh)+vbYokBuWlxeLDcdVNM60(u"ࠬࠦࠠࠡࡐࡲࡸࠥ࡫࡮ࡰࡷࡪ࡬ࠥࡪࡩࡴ࡭ࠣࡷࡵࡧࡣࡦࠢࡷࡳࠥࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠠࡵࡪࡨࠤࡻ࡯ࡤࡦࡱࠣࡪ࡮ࡲࡥ࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫഺ")+HOCWKhxITtulVGX+k5oIaYyp2mnrLK49qhzS(u"࠭ࠠ࡞ࠢࠣࠤ࡛࡯ࡤࡦࡱࠣࡪ࡮ࡲࡥࠡࡵ࡬ࡾࡪࡀࠠ࡜഻ࠢࠪ")+str(ppcYGhHNRS6UMLVQkDKlb)+tRnTydV03Xfi7rbQ(u"ࠧࠡࡏࡅࠤࡢࠦࠠࠡࡃࡹࡥ࡮ࡲࡡࡣ࡮ࡨࠤࡸ࡯ࡺࡦ࠼ࠣ࡟഼ࠥ࠭")+str(cXifm7wjTnyk2CN53OoLlJp1WZBg6)+k5oIaYyp2mnrLK49qhzS(u"ࠨࠢࡐࡆࠥ࠳ࠠࠨഽ")+str(wwJPW0OnErUGxaKQyje)+vbYokBuWlxeLDcdVNM60(u"ࠩࠣࡑࡇࠦ࡝ࠡࠢࠣࡊ࡮ࡲࡥ࠻ࠢ࡞ࠤࠬാ")+zvY4UMIJkScr9l+vbYokBuWlxeLDcdVNM60(u"ࠪࠤࡢ࠭ി"))
		NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,LungQF89BqemOb32jJsZlW(u"้ࠫอ๋๊ࠠฯำ๋ࠥำศฯฬࠤ่อแ๋ห่้ࠣะอๆ์็ࠫീ"),Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠬอไๆๆไࠤฬ๊ๅุๆ๋ฬࠥะอๆ์็๋ࠥำฬๆ้ࠣࠫു")+str(ppcYGhHNRS6UMLVQkDKlb)+AiCor1fIVTDxQUWwHe9vPR7(u"࠭ࠠๆ์฽หออ๊ห๋ࠢะ์อาไࠢไ๎์ࠦๅิษะอࠥ็วา฼ฬࠤࠬൂ")+str(cXifm7wjTnyk2CN53OoLlJp1WZBg6)+rbUkdYi32PJaRtnxhDvQs(u"ࠧࠡ็ํ฾ฬฮว๋ฬࠣ์้๊ๅฮษไ฼ฮูࠦๅ๋ࠣ฽๊๊ࠠอ้สึ่ࠦศะ๊้ࠤฺ๊วไๆࠣ๎ัฮࠠฦสๅหฦࠦࠧൃ")+str(wwJPW0OnErUGxaKQyje)+nfg30bHwd4aNV12SR7UjFck(u"ࠨ่ࠢ๎฿อศศ์อࠤๆอั฻หࠣำฬฬๅศ๋๋ࠢีอࠠๆ฻้ห์ࠦร็ࠢฯ๋ฬุใࠡๆสࠤฯ๎ฬะࠢไ๎์ࠦๅิษะอ้ࠥวโ์ฬࠤ้ะอๆ์็ࠤ๊๊แࠡษ็ๅ๏ี๊้ࠢส่๊฽ไ้สࠪൄ"))
		return ksTLSoVGg0ht
	BoyIUWYSNR0jhDxQwvJriO4PkL = JyLdvftP3CU(Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠩࡦࡩࡳࡺࡥࡳࠩ൅"),cdZKMn68Pzg4,cdZKMn68Pzg4,KNomgGw1kdMCBH(u"๋้ࠪࠦสา์าࠤฯำๅ๋ๆࠣห้๋ไโࠢยࠫെ"),iRfoNckJs7Ibxzh5j92w8DSWF(u"ࠫฬ๊ๅๅใࠣห้๋ืๅ๊หࠤาาๅ่ࠢอๆึ๐ศศࠢࠪേ")+str(ppcYGhHNRS6UMLVQkDKlb)+WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠬࠦๅ๋฼สฬฬ๐ส๊ࠡฯ๋ฬุใࠡใํ๋๋ࠥำศฯฬࠤๆอั฻หࠣฮ็ื๊ษษࠣࠫൈ")+str(cXifm7wjTnyk2CN53OoLlJp1WZBg6)+iRfoNckJs7Ibxzh5j92w8DSWF(u"࠭ࠠๆ์฽หออ๊ห๋๋ࠢีอࠠศๆ่่ๆࠦโะࠢํัฯอฬࠡส฼ฺࠥอไ้ไอࠤ้๊สฮ็ํ่๋ࠥๆࠡษ็ษ๋ะั็ฬࠣษ้๏ࠠอ้สึ่ࠦ࠮้ࠡ็ࠤฬ์สࠡ็อว่ี้ࠠฬิ๎ิࠦวๅษึฮ๊ืวาࠢหฮา๋๊ๅ่่ࠢๆࠦวๅใํำ๏๎ࠠภࠩ൉"))
	if BoyIUWYSNR0jhDxQwvJriO4PkL!=LungQF89BqemOb32jJsZlW(u"࠵ආ"):
		NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,cdZKMn68Pzg4,k5oIaYyp2mnrLK49qhzS(u"ࠧห็ࠣษ้เวยࠢ฼้้๐ษࠡฬะ้๏๊ࠠๆๆไࠤฬ๊แ๋ัํ์ࠬൊ"))
		SsziMZd5UbeL2NRxVpwjO(F0FeocLXmbJhdBwQnS18PCHZIU,xxd7Xp5lvem(UkXlAzsMcamKJrEIgnxi6bWh)+vbYokBuWlxeLDcdVNM60(u"ࠨࠢࠣࠤ࡚ࡹࡥࡳࠢࡦࡥࡳࡩࡥ࡭ࡧࡧࠤࡹ࡮ࡥࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࠣࡳ࡫ࠦࡴࡩࡧࠣࡺ࡮ࡪࡥࡰࠢࡩ࡭ࡱ࡫ࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪോ")+HOCWKhxITtulVGX+f8Ja1q5eO02B(u"ࠩࠣࡡࠥࠦࠠࡇ࡫࡯ࡩ࠿࡛ࠦࠡࠩൌ")+zvY4UMIJkScr9l+nfg30bHwd4aNV12SR7UjFck(u"ࠪࠤࡢ്࠭"))
		return ksTLSoVGg0ht
	SsziMZd5UbeL2NRxVpwjO(F0FeocLXmbJhdBwQnS18PCHZIU,xxd7Xp5lvem(UkXlAzsMcamKJrEIgnxi6bWh)+WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"ࠫࠥࠦࠠࡅࡱࡺࡲࡱࡵࡡࡥࠢࡶࡸࡦࡸࡴࡦࡦࠣࡷࡺࡩࡣࡦࡵࡶࡪࡺࡲ࡬ࡺࠩൎ"))
	Nb0fUsFqmz5HMREpVZc7jC = g6UkpOE3s5XLiFH()
	Nb0fUsFqmz5HMREpVZc7jC.create(zvY4UMIJkScr9l,HC9xWUMpBQJEuTteAqjd(u"ࠬอไิูิࠤๆ๎โ้๋ࠡࠤ๊้ว็ࠢอาื๐ๆࠡ็็ๅࠥอไโ์า๎ํ࠭൏"))
	dPWKNS28UXwoy1bxCH5AkIsOVgat7 = IZQbmFzLHDtXfc
	O0Ftx1MjvKl = bD7kJZhMCdaqF68P45KlNIgO1.time()
	if not USuRxnPlV5.tbo8MkxlHv9qwdP6gI1rJzOV3Na:
		NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,rbUkdYi32PJaRtnxhDvQs(u"࠭ศิสหࠤ฾ีๅࠡษ็ฮอืูࠡฬ่ࠤสฺ๊ศรࠣฮา๋๊ๅ่่ࠢๆࠦวๅใํำ๏๎ࠧ൐"))
		return ksTLSoVGg0ht
	if W5domCu6XrQUFkiPpa3bNLtHglG: EEQgChOkLxAr3Z0FitTWlu58jMsd = open(zvY4UMIJkScr9l,AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"ࠧࡸࡤࠪ൑"))
	else: EEQgChOkLxAr3Z0FitTWlu58jMsd = open(zvY4UMIJkScr9l.decode(vczMIlkCAh2u10B3),k5oIaYyp2mnrLK49qhzS(u"ࠨࡹࡥࠫ൒"))
	if Hmq6vzsocj8wWg==aar0zhDnJsOTP7EdgR16HIS29(u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨ൓"):
		for DXAlBvH2ITZoyunMU0Rq3pw7sx in range(aar0zhDnJsOTP7EdgR16HIS29(u"࠶ඇ"),HH9qnEIKr3kQzG1+aar0zhDnJsOTP7EdgR16HIS29(u"࠶ඇ")):
			c0cDhidBlOn7 = zz4ZPovUbyk5GEhNMs8JDnaVXftS[DXAlBvH2ITZoyunMU0Rq3pw7sx-ObuCsdoDtKmhPLSMH8YGan(u"࠷ඈ")]
			if not c0cDhidBlOn7.startswith(LJPOQNK1mcG(u"ࠪ࡬ࡹࡺࡰࠨൔ")):
				if c0cDhidBlOn7.startswith(Tf2ZPslXS84Yw15aNkjQ7oOzqMc): c0cDhidBlOn7 = HOCWKhxITtulVGX.split(On1WZJc6dtksqVNgSQ5GBAjuipe(u"ࠫ࠿࠭ൕ"),WupgNDhcjK1SiYsF5VLGb9w3loJqX(u"࠱ඉ"))[nnsBpJv6XL3OzHoe4Vuhr]+xN4fKmsnyM3Y2(u"ࠬࡀࠧൖ")+c0cDhidBlOn7
				elif c0cDhidBlOn7.startswith(KCQExdbYFqM): c0cDhidBlOn7 = CxlbPZwGTcH87e1sWhfSIz29uRUEpV(HOCWKhxITtulVGX,AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"࠭ࡵࡳ࡮ࠪൗ"))+c0cDhidBlOn7
				else: c0cDhidBlOn7 = HOCWKhxITtulVGX.rsplit(KCQExdbYFqM,YnHG75e2QWwo(u"࠲ඊ"))[nnsBpJv6XL3OzHoe4Vuhr]+KCQExdbYFqM+c0cDhidBlOn7
			oyufnwWte9Im4cFA6hSLODiGRMsJx8 = JVaKHgG2Fy8AIWz.request(Rsdai9xIEPcpuBMKOUwkTA05q(u"ࠧࡈࡇࡗࠫ൘"),c0cDhidBlOn7,headers=pj3iPglDkueR29AH6U,verify=ksTLSoVGg0ht)
			nzoFeDB9XugwEiU475RA = oyufnwWte9Im4cFA6hSLODiGRMsJx8.content
			oyufnwWte9Im4cFA6hSLODiGRMsJx8.close()
			EEQgChOkLxAr3Z0FitTWlu58jMsd.write(nzoFeDB9XugwEiU475RA)
			luNaVsOGDcXJ4WBP = bD7kJZhMCdaqF68P45KlNIgO1.time()
			ahGJiPQe6Ep3CNOobuKY45rzjI = luNaVsOGDcXJ4WBP-O0Ftx1MjvKl
			Uz5geG1IiPLTmKRhWnAp87Ya62 = ahGJiPQe6Ep3CNOobuKY45rzjI//DXAlBvH2ITZoyunMU0Rq3pw7sx
			fuR2s6KPgSoCebZ8xdXjvqB = Uz5geG1IiPLTmKRhWnAp87Ya62*(HH9qnEIKr3kQzG1+xN4fKmsnyM3Y2(u"࠳උ"))
			D76O1UtL9xS2aKBGMXIwhvyEf54Tp = fuR2s6KPgSoCebZ8xdXjvqB-ahGJiPQe6Ep3CNOobuKY45rzjI
			x3G0I9vUCjg(Nb0fUsFqmz5HMREpVZc7jC,int(dwiIAcPl04ey7Zv38Mz(u"࠵࠵࠶ඍ")*DXAlBvH2ITZoyunMU0Rq3pw7sx//(HH9qnEIKr3kQzG1+ObuCsdoDtKmhPLSMH8YGan(u"࠴ඌ"))),TtyzcuW45VKA(u"ࠨษ็ื฼ืࠠโ๊ๅࠤ์๎ࠠๆๅส๊ࠥะฮำ์้ࠤ๊๊แࠡษ็ๅ๏ี๊้ࠩ൙"),AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"ࠩฯ่อࠦๅๅใࠣห้็๊ะ์๋࠾࠲ࠦวๅฮีลࠥืโๆࠩ൚"),str(DXAlBvH2ITZoyunMU0Rq3pw7sx*UfcTHzgr1kiAQy4LwaB3Z5KNoX//xlj2AYD4RmQg)+KCQExdbYFqM+str(ppcYGhHNRS6UMLVQkDKlb)+f8Ja1q5eO02B(u"ࠪࠤࡒࡈࠠࠡࠢࠣ์็ะࠠๆฬหๆ๏ࡀࠠࠨ൛")+bD7kJZhMCdaqF68P45KlNIgO1.strftime(liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠦࠪࡎ࠺ࠦࡏ࠽ࠩࡘࠨ൜"),bD7kJZhMCdaqF68P45KlNIgO1.gmtime(D76O1UtL9xS2aKBGMXIwhvyEf54Tp))+tRnTydV03Xfi7rbQ(u"ࠬࠦเࠨ൝"))
			if Nb0fUsFqmz5HMREpVZc7jC.iscanceled():
				dPWKNS28UXwoy1bxCH5AkIsOVgat7 = ksTLSoVGg0ht
				break
	else:
		DXAlBvH2ITZoyunMU0Rq3pw7sx = aar0zhDnJsOTP7EdgR16HIS29(u"࠵ඎ")
		for nzoFeDB9XugwEiU475RA in oyufnwWte9Im4cFA6hSLODiGRMsJx8.iter_content(chunk_size=UfcTHzgr1kiAQy4LwaB3Z5KNoX):
			EEQgChOkLxAr3Z0FitTWlu58jMsd.write(nzoFeDB9XugwEiU475RA)
			DXAlBvH2ITZoyunMU0Rq3pw7sx = DXAlBvH2ITZoyunMU0Rq3pw7sx+YnHG75e2QWwo(u"࠷ඏ")
			luNaVsOGDcXJ4WBP = bD7kJZhMCdaqF68P45KlNIgO1.time()
			ahGJiPQe6Ep3CNOobuKY45rzjI = luNaVsOGDcXJ4WBP-O0Ftx1MjvKl
			Uz5geG1IiPLTmKRhWnAp87Ya62 = ahGJiPQe6Ep3CNOobuKY45rzjI/DXAlBvH2ITZoyunMU0Rq3pw7sx
			fuR2s6KPgSoCebZ8xdXjvqB = Uz5geG1IiPLTmKRhWnAp87Ya62*(HH9qnEIKr3kQzG1+aNdix5gq7yeFHTMWhnzm8pX0Y16(u"࠱ඐ"))
			D76O1UtL9xS2aKBGMXIwhvyEf54Tp = fuR2s6KPgSoCebZ8xdXjvqB-ahGJiPQe6Ep3CNOobuKY45rzjI
			x3G0I9vUCjg(Nb0fUsFqmz5HMREpVZc7jC,int(AiCor1fIVTDxQUWwHe9vPR7(u"࠳࠳࠴ඒ")*DXAlBvH2ITZoyunMU0Rq3pw7sx/(HH9qnEIKr3kQzG1+ObuCsdoDtKmhPLSMH8YGan(u"࠲එ"))),uxE8MyoTRglrcaiQf(u"࠭วๅีฺีࠥ็่ใ๊ࠢ์๋ࠥใศ่ࠣฮำุ๊็่่ࠢๆࠦวๅใํำ๏๎ࠧ൞"),dwiIAcPl04ey7Zv38Mz(u"ࠧอๆหࠤ๊๊แࠡษ็ๅ๏ี๊้࠼࠰ࠤฬ๊ฬำรࠣี็๋ࠧൟ"),str(DXAlBvH2ITZoyunMU0Rq3pw7sx*UfcTHzgr1kiAQy4LwaB3Z5KNoX//xlj2AYD4RmQg)+KCQExdbYFqM+str(ppcYGhHNRS6UMLVQkDKlb)+liyzjA4RkEb1cT6fr5pGKdWNHOxM(u"ࠨࠢࡐࡆ๊ࠥࠦࠠࠡๅฮ๋ࠥสษไํ࠾ࠥ࠭ൠ")+bD7kJZhMCdaqF68P45KlNIgO1.strftime(AAcvWYJkObFK9Cs2zMSaeRrmTjPHBu(u"ࠤࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠦൡ"),bD7kJZhMCdaqF68P45KlNIgO1.gmtime(D76O1UtL9xS2aKBGMXIwhvyEf54Tp))+S5fhsRT8JV(u"ࠪࠤๅ࠭ൢ"))
			if Nb0fUsFqmz5HMREpVZc7jC.iscanceled():
				dPWKNS28UXwoy1bxCH5AkIsOVgat7 = ksTLSoVGg0ht
				break
		oyufnwWte9Im4cFA6hSLODiGRMsJx8.close()
	EEQgChOkLxAr3Z0FitTWlu58jMsd.close()
	Nb0fUsFqmz5HMREpVZc7jC.close()
	if not dPWKNS28UXwoy1bxCH5AkIsOVgat7:
		SsziMZd5UbeL2NRxVpwjO(F0FeocLXmbJhdBwQnS18PCHZIU,xxd7Xp5lvem(UkXlAzsMcamKJrEIgnxi6bWh)+s8fcjBCSMxzAIkZQbJPga(u"ࠫࠥࠦࠠࡖࡵࡨࡶࠥࡩࡡ࡯ࡥࡨࡰࡪࡪ࠯ࡪࡰࡷࡩࡷࡸࡵࡱࡶࡨࡨࠥࡺࡨࡦࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤࡵࡸ࡯ࡤࡧࡶࡷࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨൣ")+HOCWKhxITtulVGX+zDek1IW37rq6UoKdwyRiAVpF(u"ࠬࠦ࡝ࠡࠢࠣࡊ࡮ࡲࡥ࠻ࠢ࡞ࠤࠬ൤")+zvY4UMIJkScr9l+iRfoNckJs7Ibxzh5j92w8DSWF(u"࠭ࠠ࡞ࠩ൥"))
		NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,uxE8MyoTRglrcaiQf(u"ࠧษฯึฬࠥ฽ไษๅࠣฮ๊ࠦลๅ฼สลࠥ฿ๅๅ์ฬࠤฯำๅ๋ๆ้้ࠣ็ࠠศๆไ๎ิ๐่ࠨ൦"))
		return IZQbmFzLHDtXfc
	SsziMZd5UbeL2NRxVpwjO(F0FeocLXmbJhdBwQnS18PCHZIU,xxd7Xp5lvem(UkXlAzsMcamKJrEIgnxi6bWh)+s8fcjBCSMxzAIkZQbJPga(u"ࠨࠢࠣࠤ࡛࡯ࡤࡦࡱࠣࡪ࡮ࡲࡥࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࡨࡨࠥࡹࡵࡤࡥࡨࡷࡸ࡬ࡵ࡭࡮ࡼࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ൧")+HOCWKhxITtulVGX+LJPOQNK1mcG(u"ࠩࠣࡡࠥࠦࠠࡇ࡫࡯ࡩ࠿࡛ࠦࠡࠩ൨")+zvY4UMIJkScr9l+vbYokBuWlxeLDcdVNM60(u"ࠪࠤࡢ࠭൩"))
	NiWSoAmhdkQPlTpneyVzDO8tw9aL(cdZKMn68Pzg4,cdZKMn68Pzg4,OPEJxmUqr9wAX1i,KNomgGw1kdMCBH(u"ࠫฯ๋ࠠหฯ่๎้ࠦๅๅใࠣห้็๊ะ์๋ࠤอ์ฬศฯࠪ൪"))
	return IZQbmFzLHDtXfc
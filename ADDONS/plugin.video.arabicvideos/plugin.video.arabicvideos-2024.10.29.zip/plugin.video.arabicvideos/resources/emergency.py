# -*- coding: utf-8 -*-
import sys as gg1ld5VjY2mp
IIi9zsqYPJfc = gg1ld5VjY2mp.version_info [0] == 2
bP2ZBf3egNLOmKq9I4syFADCxYH = 2048
Sf3wZs8pNngMLRhcVTCXGloK2btU = 7
def O5MDZEYJuIL0RvQ8Ka (wtPpKD8X2arM):
	global PasySCuvO8Kwmeirc2V5lDQXZRM7ht
	v09Gu3I64mnA5NRwxd8ypkMoUKz1aH = ord (wtPpKD8X2arM [-1])
	WweD2znymN = wtPpKD8X2arM [:-1]
	kkC1ybHdhBPVpDKriTmjSq = v09Gu3I64mnA5NRwxd8ypkMoUKz1aH % len (WweD2znymN)
	nbkhj6DFlw0qs = WweD2znymN [:kkC1ybHdhBPVpDKriTmjSq] + WweD2znymN [kkC1ybHdhBPVpDKriTmjSq:]
	if IIi9zsqYPJfc:
		vjq74QNB3GM9aAPhD = unicode () .join ([unichr (ord (KuWjL23cGwH6olpCn8kM0ea) - bP2ZBf3egNLOmKq9I4syFADCxYH - (nnlLE7zod3ShYXK0cFDCetOf6kG8 + v09Gu3I64mnA5NRwxd8ypkMoUKz1aH) % Sf3wZs8pNngMLRhcVTCXGloK2btU) for nnlLE7zod3ShYXK0cFDCetOf6kG8, KuWjL23cGwH6olpCn8kM0ea in enumerate (nbkhj6DFlw0qs)])
	else:
		vjq74QNB3GM9aAPhD = str () .join ([chr (ord (KuWjL23cGwH6olpCn8kM0ea) - bP2ZBf3egNLOmKq9I4syFADCxYH - (nnlLE7zod3ShYXK0cFDCetOf6kG8 + v09Gu3I64mnA5NRwxd8ypkMoUKz1aH) % Sf3wZs8pNngMLRhcVTCXGloK2btU) for nnlLE7zod3ShYXK0cFDCetOf6kG8, KuWjL23cGwH6olpCn8kM0ea in enumerate (nbkhj6DFlw0qs)])
	return eval (vjq74QNB3GM9aAPhD)
O0qe5lNJfWbLGsi1QzAXZ3hvYBwmk,ff2d9Z5mxuMyqi7XVJ4YoDj,KVAWmnJX6TcU9xHvRq0b7dug2r=O5MDZEYJuIL0RvQ8Ka,O5MDZEYJuIL0RvQ8Ka,O5MDZEYJuIL0RvQ8Ka
iCk3MmElRa0ISdZpDxwfc1FX,x3RuGaLQ4cey0mt,RkiQlBV7rwTK2aZPdpG8WLY=KVAWmnJX6TcU9xHvRq0b7dug2r,ff2d9Z5mxuMyqi7XVJ4YoDj,O0qe5lNJfWbLGsi1QzAXZ3hvYBwmk
j2SXhepCgAvyr4,Jz2v9yw6KlprjqA,JAj6q7amCXyFE2GTxNup3l40WdVt=RkiQlBV7rwTK2aZPdpG8WLY,x3RuGaLQ4cey0mt,iCk3MmElRa0ISdZpDxwfc1FX
xiEgOmve1dWZX,nshJxOiVtzHalKXRLU,uynKGh9Vv4oSsWCBa0gdr32=JAj6q7amCXyFE2GTxNup3l40WdVt,Jz2v9yw6KlprjqA,j2SXhepCgAvyr4
RTLEXavDjlN,uiUSXfolyczwQ,H0ksjBLAC8zVh35gW4ufU6=uynKGh9Vv4oSsWCBa0gdr32,nshJxOiVtzHalKXRLU,xiEgOmve1dWZX
HEfuL2N5VUKoYJcXDAkO,Dvx5khQtfiJc6ws1XK89GVeNp0IYzn,yyzX7esWRD4=H0ksjBLAC8zVh35gW4ufU6,uiUSXfolyczwQ,RTLEXavDjlN
ldXtDfxokBZGEwmuY94K5TiOJ6,MoV1fmXK9ESylW7OCbjNvxaegPwGsQ,ss9tTUhPubGYRI1f6JnqNV4yS3Ea=yyzX7esWRD4,Dvx5khQtfiJc6ws1XK89GVeNp0IYzn,HEfuL2N5VUKoYJcXDAkO
SSTimV6rXJe9f4nCPaUgdGpOlu,XPsWmoIKhE4ndqUjLk6Yp8a2Drg,nnlrkqMSKtgYf94mi=ss9tTUhPubGYRI1f6JnqNV4yS3Ea,MoV1fmXK9ESylW7OCbjNvxaegPwGsQ,ldXtDfxokBZGEwmuY94K5TiOJ6
TZkhGjbENyC2rPVA6fK8,NCXSi0gIb9vHWYpkjr5BAthQuZMP2s,og0RUiBKzN5p4=nnlrkqMSKtgYf94mi,XPsWmoIKhE4ndqUjLk6Yp8a2Drg,SSTimV6rXJe9f4nCPaUgdGpOlu
ONyuAzwBCxU7Io6pYZs09DTr48SFM,jLn7lHtqCadP1JYVbRWX0AK,a5tvLNjCry=og0RUiBKzN5p4,NCXSi0gIb9vHWYpkjr5BAthQuZMP2s,TZkhGjbENyC2rPVA6fK8
itvje9547cgw,kVa3fbJpuN2,WcRKZQ05gVPGIAUeTz96OSLNuk3jpv=a5tvLNjCry,jLn7lHtqCadP1JYVbRWX0AK,ONyuAzwBCxU7Io6pYZs09DTr48SFM
import xbmc as DM7hrPUFE1BXQo,xbmcgui as i2btzDPXF5x4JCgdQ3m,sys as gg1ld5VjY2mp,os as kX7GlIrQYFDW0PuCi,requests as iN7JSmEMuKbenIT,re as TW0UsyRrExatz,xbmcvfs as Wi6Q1jbN3Kw,base64 as FNCy9Snevhol,time as xNkdSWnUqe
def r0rZO6h9J8TNfIb4(text):
	wonyKpOhD5I8xjNb4tRrS7GueiAf = H0ksjBLAC8zVh35gW4ufU6(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧࠀ")
	if avj1sKEB0bD2excRYmF79NIgkP3: fd7MQgcahTmSxo = i2btzDPXF5x4JCgdQ3m.Dialog().yesno(wonyKpOhD5I8xjNb4tRrS7GueiAf,text,TZkhGjbENyC2rPVA6fK8(u"ࠬ࠭ࠁ"),TZkhGjbENyC2rPVA6fK8(u"࠭ࠧࠂ"),TZkhGjbENyC2rPVA6fK8(u"ࠧไๆสࠫࠃ"),nshJxOiVtzHalKXRLU(u"ࠨ่฼้ࠬࠄ"))
	else: fd7MQgcahTmSxo = i2btzDPXF5x4JCgdQ3m.Dialog().yesno(wonyKpOhD5I8xjNb4tRrS7GueiAf,text,yyzX7esWRD4(u"ࠩๆ่ฬ࠭ࠅ"),Jz2v9yw6KlprjqA(u"๊ࠪ฾๋ࠧࠆ"))
	return fd7MQgcahTmSxo
def GymkHSIcaTnsVwo61xtRQWu(SipaMdC96w):
	fd7MQgcahTmSxo = r0rZO6h9J8TNfIb4(ONyuAzwBCxU7Io6pYZs09DTr48SFM(u"ࠫ็ฮไࠡวิืฬ๊ࠠิฮ็ࠤฬ๊รฯูสลࠥ๐ฬษࠢฦ๊ࠥะิ฻ๆࠣฬึ์วๆฮࠣ฽๊อฯ๊ࠡอ๊ฯ฾ัࠡฯอํࠥะุ่ำ่่ࠣࠦวๅ็ืห่๊้ࠠษ็วำ฽วยࠢ࠱࠲ࠥ฿ๆะ้สࠤุ๐โ้็ࠣ็ํี๊ࠡสอืั๐ไ้ࠡำ๋ࠥอไๆึส็้่ࠦศๆฦา฼อมࠡใํࠤุาไࠡษ็วำ฽วยࠢ࠱࠲ࠥ๎ศฺั๊ห่ࠥๅࠡสศีุอไࠡีฯ่ࠥอไฤะฺหฦࠦไๅ็หี๊าࠠ࠯࠰๋้ࠣࠦสา์าࠤฬ๊ย็ࠢศีุอไࠡีฯ่ࠥอไฤะฺหฦࠦลๅ๋ࠣห้๋ศา็ฯࠤฤࠧࠧࠇ"))
	if fd7MQgcahTmSxo==MoV1fmXK9ESylW7OCbjNvxaegPwGsQ(u"࠶ࡱ") and kX7GlIrQYFDW0PuCi.path.exists(SipaMdC96w):
		nn2bMiU4ohRHqT79ljpNPcfvkX = DM7hrPUFE1BXQo.getInfoLabel(HEfuL2N5VUKoYJcXDAkO(u"࡙ࠬࡹࡴࡶࡨࡱ࠳ࡇࡤࡥࡱࡱ࡚ࡪࡸࡳࡪࡱࡱࠬࠬࠈ")+yBSZ8wPGNL4iV5bM+KVAWmnJX6TcU9xHvRq0b7dug2r(u"࠭ࠩࠨࠉ"))
		file = open(SipaMdC96w,NCXSi0gIb9vHWYpkjr5BAthQuZMP2s(u"ࠧࡳࡤࠪࠊ"))
		GlbQ7EUCydphgRfsJv3nY5FoP = kX7GlIrQYFDW0PuCi.path.getsize(SipaMdC96w)
		if GlbQ7EUCydphgRfsJv3nY5FoP>xiEgOmve1dWZX(u"࠹࠰࠲࠲࠳࠴ࡲ"): file.seek(-xiEgOmve1dWZX(u"࠹࠰࠲࠲࠳࠴ࡲ"),kX7GlIrQYFDW0PuCi.SEEK_END)
		data = file.read()
		file.close()
		oTlmaMeRJuxI7pKPG9ZhwDfUjSN = TW0UsyRrExatz.findall(iCk3MmElRa0ISdZpDxwfc1FX(u"ࠣࠩࡸࡷࡪࡸ࡟ࡪࡦࠪ࠾ࠥ࠭ࠨ࠯ࠬࡂ࠭ࠬࠨࠋ"),data,TW0UsyRrExatz.DOTALL)
		if not oTlmaMeRJuxI7pKPG9ZhwDfUjSN: oTlmaMeRJuxI7pKPG9ZhwDfUjSN = TW0UsyRrExatz.findall(Dvx5khQtfiJc6ws1XK89GVeNp0IYzn(u"ࠤࠪࡹࡸ࡫ࡲࠨ࠼ࠣࠫ࠭࠴ࠪࡀࠫࠪࠦࠌ"),data,TW0UsyRrExatz.DOTALL)
		oTlmaMeRJuxI7pKPG9ZhwDfUjSN = oTlmaMeRJuxI7pKPG9ZhwDfUjSN[j2SXhepCgAvyr4(u"࠰ࡳ")] if oTlmaMeRJuxI7pKPG9ZhwDfUjSN else j2SXhepCgAvyr4(u"ࠪ࠴࠵࠶࠰ࠨࠍ")
		oTlmaMeRJuxI7pKPG9ZhwDfUjSN = oTlmaMeRJuxI7pKPG9ZhwDfUjSN.split(ONyuAzwBCxU7Io6pYZs09DTr48SFM(u"ࠫࡡࡴࠧࠎ"),WcRKZQ05gVPGIAUeTz96OSLNuk3jpv(u"࠲ࡴ"))[Jz2v9yw6KlprjqA(u"࠲ࡵ")]
		wiMqksltGRcD3KH = jLn7lHtqCadP1JYVbRWX0AK(u"ࠬࡇࡖ࠻ࠢࠪࠏ")+oTlmaMeRJuxI7pKPG9ZhwDfUjSN+JAj6q7amCXyFE2GTxNup3l40WdVt(u"࠭࠭ࡓࡧࡦࡳࡻ࡫ࡲࡺࠩࠐ")
		message = ONyuAzwBCxU7Io6pYZs09DTr48SFM(u"ࠧࡆ࡯ࡤ࡭ࡱࠦࡓࡦࡰࡧࡩࡷࡀࠠࠨࠑ")+oTlmaMeRJuxI7pKPG9ZhwDfUjSN+uynKGh9Vv4oSsWCBa0gdr32(u"ࠨࠢ࠽ࠫࠒ")+ff2d9Z5mxuMyqi7XVJ4YoDj(u"ࠩ࡟ࡲࠬࠓ")+iCk3MmElRa0ISdZpDxwfc1FX(u"ࠪࡅࡩࡪ࡯࡯࡙ࠢࡩࡷࡹࡩࡰࡰ࠽ࠤࠬࠔ")+nn2bMiU4ohRHqT79ljpNPcfvkX+uiUSXfolyczwQ(u"ࠫࠥࡀࠧࠕ")
		RAfZNMdkT43PEg2Ush = FNCy9Snevhol.b64encode(data)
		Q2qJZ9knDz8iTYuIG = {SSTimV6rXJe9f4nCPaUgdGpOlu(u"ࠬࡹࡵࡣ࡬ࡨࡧࡹ࠭ࠖ"):wiMqksltGRcD3KH,xiEgOmve1dWZX(u"࠭࡭ࡦࡵࡶࡥ࡬࡫ࠧࠗ"):message,jLn7lHtqCadP1JYVbRWX0AK(u"ࠧ࡭ࡱࡪࡪ࡮ࡲࡥࠨ࠘"):RAfZNMdkT43PEg2Ush}
		gvmQPBynDMEz3dVp = nshJxOiVtzHalKXRLU(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡻ࡫ࡲࡤࡧ࡯࠲ࡦࡶࡰ࠰ࡵࡨࡲࡩ࡫࡭ࡢ࡫࡯ࠫ࠙")
		xy3l4aPuBNk8WYAGD7XMKo6sUE = iN7JSmEMuKbenIT.request(ff2d9Z5mxuMyqi7XVJ4YoDj(u"ࠩࡓࡓࡘ࡚ࠧࠚ"),gvmQPBynDMEz3dVp,data=Q2qJZ9knDz8iTYuIG)
		if xy3l4aPuBNk8WYAGD7XMKo6sUE.status_code==ff2d9Z5mxuMyqi7XVJ4YoDj(u"࠵࠴࠵ࡶ"): i2btzDPXF5x4JCgdQ3m.Dialog().ok(uiUSXfolyczwQ(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ࠛ"),JAj6q7amCXyFE2GTxNup3l40WdVt(u"ࠫั๐ฯࠡ࠰࠱ࠤ๋าอหࠢ฼้้๐ษࠡวิืฬ๊ࠠิฮ็ࠤฬ๊รฯูสลࠬࠜ"))
		else: i2btzDPXF5x4JCgdQ3m.Dialog().ok(j2SXhepCgAvyr4(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨࠝ"),XPsWmoIKhE4ndqUjLk6Yp8a2Drg(u"࠭ไๅลึๅࠥ࠴࠮ࠡใื่ฯูࠦๆๆํอࠥหัิษ็ࠤุาไࠡษ็วำ฽วยࠩࠞ"))
	return
def xx90LqEZ83IoT6():
	fd7MQgcahTmSxo = r0rZO6h9J8TNfIb4(kVa3fbJpuN2(u"ࠧๆๆไࠤส฿ฯศัสฮࠥอไษำ้ห๊า๋ࠠฯอ์๏ูࠦๅ๋้ࠣ฾๊่ๆษอࠤฯิีࠡฬะำ๏ัࠠศๆหี๋อๅอ๋ࠢฮ๋฾๊ๆࠢ฼้้ࠦวๅสิ๊ฬ๋ฬࠡ࠰࠱ࠤ฾์ฯࠡ็ึัࠥํะศࠢส่๊๊แࠡีํๆํ๋ࠠศๆหี๋อๅอࠢหา้่ࠠๆๆไࠤัี๊ะࠢไหึเࠠ࠯࠰๋้ࠣࠦสา์าࠤฬ๊ย็่ࠢืาࠦๅๅใࠣษ฾ีวะษอࠤฬ๊ศา่ส้ัࠦฟࠢࠩࠟ"))
	if fd7MQgcahTmSxo==iCk3MmElRa0ISdZpDxwfc1FX(u"࠵ࡷ"):
		XFH7MyorAkS08RNjhg = jLn7lHtqCadP1JYVbRWX0AK(u"࡚ࡲࡶࡧࢇ")
		veuzTq4HOkJPA5DMKEZIQLSnbURg = kX7GlIrQYFDW0PuCi.path.join(DDWLbr8MRfNk3,MoV1fmXK9ESylW7OCbjNvxaegPwGsQ(u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪࠠ"),ONyuAzwBCxU7Io6pYZs09DTr48SFM(u"ࠩࡤࡨࡩࡵ࡮ࡠࡦࡤࡸࡦ࠭ࠡ"),yBSZ8wPGNL4iV5bM)
		NQx3BVehWnGcAdlYO5SZF8mzLPktyM = kX7GlIrQYFDW0PuCi.path.join(veuzTq4HOkJPA5DMKEZIQLSnbURg,xiEgOmve1dWZX(u"ࠪࡷࡪࡺࡴࡪࡰࡪࡷ࠳ࡾ࡭࡭ࠩࠢ"))
		if kX7GlIrQYFDW0PuCi.path.exists(NQx3BVehWnGcAdlYO5SZF8mzLPktyM):
			try: kX7GlIrQYFDW0PuCi.remove(NQx3BVehWnGcAdlYO5SZF8mzLPktyM)
			except Exception as yXib9x3dtqThPvY7oeSm8NZEHp1: XFH7MyorAkS08RNjhg = Jz2v9yw6KlprjqA(u"ࡆࡢ࡮ࡶࡩ࢈")
		if XFH7MyorAkS08RNjhg: i2btzDPXF5x4JCgdQ3m.Dialog().ok(ss9tTUhPubGYRI1f6JnqNV4yS3Ea(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧࠣ"),JAj6q7amCXyFE2GTxNup3l40WdVt(u"ࠬา๊ะࠢ࠱࠲ࠥ์ฬฮฬࠣ฽๊๊๊ส่ࠢืาࠦวๅ็็ๅࠬࠤ"))
		else: i2btzDPXF5x4JCgdQ3m.Dialog().ok(uynKGh9Vv4oSsWCBa0gdr32(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩࠥ"),nnlrkqMSKtgYf94mi(u"ࠧๅๆฦืๆࠦ࠮࠯ࠢไุ้ะฺࠠ็็๎ฮࠦๅิฯࠣห้๋ไโࠩࠦ"))
	return
def i0IozNp5hjatwB2TbmOsyLkA6gUr4():
	fd7MQgcahTmSxo = r0rZO6h9J8TNfIb4(kVa3fbJpuN2(u"ࠨ็ฯ่ิࠦใศึࠣห้ฮั็ษ่ะࠥ๐อห๊ํࠤ฾๊้ࠡ็็ๅฬะࠠหะุࠤฯ์ุ๋็ࠣ฽๊๊ࠠศๆหี๋อๅอ่ࠢฯ้ࠦๅๅใสฮࠥอไๆใู่ฮ่ࠦๆๆไหฯࠦࡉࡑࡖ࡙ࠤํࠦࡍ࠴ࡗࠣ์ฺ๎ัࠡษ็ๆํอฦๆࠢ࠱࠲ࠥ฿ๆะ่ࠢืาࠦ็ัษࠣห้๋ฬๅัࠣื๏่่ๆࠢส่อืๆศ็ฯࠤอิไใ่ࠢะ้ีࠠอัํำࠥ็วา฼ࠣ࠲࠳ࠦ็ๅࠢอี๏ีࠠศๆล๊๋ࠥำฮ่ࠢะ้ีࠠไษืࠤฬ๊ศา่ส้ัࠦฟࠢࠩࠧ"))
	if fd7MQgcahTmSxo==x3RuGaLQ4cey0mt(u"࠶ࡸ"):
		if Oi5GqMVfB8oJ9pDtQCPNmlY3nXW: ABTKaHId1uNY3GFL78t6jSE2 = Wi6Q1jbN3Kw.translatePath(Dvx5khQtfiJc6ws1XK89GVeNp0IYzn(u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴ࡺࡥ࡮ࡲࠪࠨ"))
		else: ABTKaHId1uNY3GFL78t6jSE2 = DM7hrPUFE1BXQo.translatePath(ldXtDfxokBZGEwmuY94K5TiOJ6(u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡴࡦ࡯ࡳࠫࠩ"))
		DqJn8LtScfZxol4TH1hCO = kX7GlIrQYFDW0PuCi.path.join(ABTKaHId1uNY3GFL78t6jSE2,yBSZ8wPGNL4iV5bM)
		XFH7MyorAkS08RNjhg = XPsWmoIKhE4ndqUjLk6Yp8a2Drg(u"ࡕࡴࡸࡩࢉ")
		if kX7GlIrQYFDW0PuCi.path.exists(DqJn8LtScfZxol4TH1hCO):
			for RA7805fanEPMiXYmJ,rrfRKbXYTPo4Lst,xvl0ARF4PUwfe6ur in kX7GlIrQYFDW0PuCi.walk(DqJn8LtScfZxol4TH1hCO,topdown=Dvx5khQtfiJc6ws1XK89GVeNp0IYzn(u"ࡈࡤࡰࡸ࡫ࢊ")):
				for QTcJkEaXMz94VWoiwngHq6uryd1 in xvl0ARF4PUwfe6ur:
					za2VGRg1OxUvwf = kX7GlIrQYFDW0PuCi.path.join(RA7805fanEPMiXYmJ,QTcJkEaXMz94VWoiwngHq6uryd1)
					try: kX7GlIrQYFDW0PuCi.remove(za2VGRg1OxUvwf)
					except Exception as yXib9x3dtqThPvY7oeSm8NZEHp1: XFH7MyorAkS08RNjhg = XPsWmoIKhE4ndqUjLk6Yp8a2Drg(u"ࡉࡥࡱࡹࡥࢋ")
				for W8HCkMTrvnf in rrfRKbXYTPo4Lst:
					SRicPmyN5IHgtuYFjBqDks4T1e8vLZ = kX7GlIrQYFDW0PuCi.path.join(RA7805fanEPMiXYmJ,W8HCkMTrvnf)
					try: kX7GlIrQYFDW0PuCi.rmdir(SRicPmyN5IHgtuYFjBqDks4T1e8vLZ)
					except: pass
			try: kX7GlIrQYFDW0PuCi.rmdir(RA7805fanEPMiXYmJ)
			except: pass
		if XFH7MyorAkS08RNjhg: i2btzDPXF5x4JCgdQ3m.Dialog().ok(jLn7lHtqCadP1JYVbRWX0AK(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧࠪ"),H0ksjBLAC8zVh35gW4ufU6(u"ࠬา๊ะࠢ࠱࠲ࠥ์ฬฮฬࠣ฽๊๊๊ส่ࠢืาࠦๅอๆาࠤ่อิࠡษ็ฬึ์วๆฮࠪࠫ"))
		else: i2btzDPXF5x4JCgdQ3m.Dialog().ok(WcRKZQ05gVPGIAUeTz96OSLNuk3jpv(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩࠬ"),xiEgOmve1dWZX(u"ࠧๅๆฦืๆࠦ࠮࠯ࠢไุ้ะฺࠠ็็๎ฮࠦๅิฯ้ࠣั๊ฯࠡๅสุࠥอไษำ้ห๊าࠧ࠭"))
	return
def mI7sUt4FwlHp1():
	gvmQPBynDMEz3dVp = JAj6q7amCXyFE2GTxNup3l40WdVt(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡸࡻࡲࡨࡧ࠱ࡷ࡭࠵࡫ࡰࡦ࡬࠳ࡪࡳࡡࡥࡡࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳ࠰ࡱ࡯ࡨ࠴࡯࡮ࡥࡧࡻ࠲࡭ࡺ࡭࡭ࠩ࠮")
	xy3l4aPuBNk8WYAGD7XMKo6sUE = iN7JSmEMuKbenIT.request(HEfuL2N5VUKoYJcXDAkO(u"ࠩࡊࡉ࡙࠭࠯"),gvmQPBynDMEz3dVp)
	dyFsf0ZnuWebU4Ahtri = xy3l4aPuBNk8WYAGD7XMKo6sUE.content
	dyFsf0ZnuWebU4Ahtri = dyFsf0ZnuWebU4Ahtri.decode(uynKGh9Vv4oSsWCBa0gdr32(u"ࠪࡹࡹ࡬࠸ࠨ࠰"))
	xvl0ARF4PUwfe6ur = TW0UsyRrExatz.findall(SSTimV6rXJe9f4nCPaUgdGpOlu(u"ࠫ࡭ࡸࡥࡧ࠿ࠥࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࠫ࠲࠯ࡅࠩ࠯ࡼ࡬ࡴࠧ࠭࠱"),dyFsf0ZnuWebU4Ahtri,TW0UsyRrExatz.DOTALL)
	xvl0ARF4PUwfe6ur = sorted(xvl0ARF4PUwfe6ur,reverse=kVa3fbJpuN2(u"ࡘࡷࡻࡥࢌ"))
	uXWeE6LDMb = i2btzDPXF5x4JCgdQ3m.Dialog().select(SSTimV6rXJe9f4nCPaUgdGpOlu(u"ࠬอฮหำࠣห้หีะษิࠤฬ๊ะ๋ࠢอี๏ีࠠหอห๎ฯํࠧ࠲"),xvl0ARF4PUwfe6ur)
	if uXWeE6LDMb==-Jz2v9yw6KlprjqA(u"࠷ࡹ"): return
	filename = xvl0ARF4PUwfe6ur[uXWeE6LDMb]
	if avj1sKEB0bD2excRYmF79NIgkP3: filename = filename.encode(ss9tTUhPubGYRI1f6JnqNV4yS3Ea(u"࠭ࡵࡵࡨ࠻ࠫ࠳"))
	fz7aHFIWmnP5BGkqMtAuE8N = gvmQPBynDMEz3dVp.rsplit(RkiQlBV7rwTK2aZPdpG8WLY(u"ࠧ࠰ࠩ࠴"),SSTimV6rXJe9f4nCPaUgdGpOlu(u"࠱ࡺ"))[jLn7lHtqCadP1JYVbRWX0AK(u"࠱ࡻ")]+TZkhGjbENyC2rPVA6fK8(u"ࠨ࠱ࠪ࠵")+uynKGh9Vv4oSsWCBa0gdr32(u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࠩ࠶")+filename+HEfuL2N5VUKoYJcXDAkO(u"ࠪ࠲ࡿ࡯ࡰࠨ࠷")
	XFH7MyorAkS08RNjhg = H0ksjBLAC8zVh35gW4ufU6(u"ࡋࡧ࡬ࡴࡧࢍ")
	xy3l4aPuBNk8WYAGD7XMKo6sUE = iN7JSmEMuKbenIT.request(Dvx5khQtfiJc6ws1XK89GVeNp0IYzn(u"ࠫࡌࡋࡔࠨ࠸"),fz7aHFIWmnP5BGkqMtAuE8N)
	if xy3l4aPuBNk8WYAGD7XMKo6sUE.status_code==j2SXhepCgAvyr4(u"࠴࠳࠴ࡼ"):
		pFifHTuqRM = xy3l4aPuBNk8WYAGD7XMKo6sUE.content
		import zipfile as Z4drUizp5XKxsI9SbeEuDOjQgfH2,io as HHwr1gfjMVDsS
		Vr2LYEiz5H01hajfsDJNMCc = HHwr1gfjMVDsS.BytesIO(pFifHTuqRM)
		gRSw9G6xFLAqcHC = kX7GlIrQYFDW0PuCi.path.join(DDWLbr8MRfNk3,nnlrkqMSKtgYf94mi(u"ࠬࡧࡤࡥࡱࡱࡷࠬ࠹"))
		D6i14bEWrmRLPvwIFjT = Z4drUizp5XKxsI9SbeEuDOjQgfH2.ZipFile(Vr2LYEiz5H01hajfsDJNMCc)
		D6i14bEWrmRLPvwIFjT.extractall(gRSw9G6xFLAqcHC)
		xNkdSWnUqe.sleep(iCk3MmElRa0ISdZpDxwfc1FX(u"࠴ࡽ"))
		DM7hrPUFE1BXQo.executebuiltin(HEfuL2N5VUKoYJcXDAkO(u"࠭ࡕࡱࡦࡤࡸࡪࡒ࡯ࡤࡣ࡯ࡅࡩࡪ࡯࡯ࡵࠪ࠺"))
		xNkdSWnUqe.sleep(ldXtDfxokBZGEwmuY94K5TiOJ6(u"࠵ࡾ"))
		zJcIxuwqF6mng4aeL2rs0MTdK = DM7hrPUFE1BXQo.executeJSONRPC(MoV1fmXK9ESylW7OCbjNvxaegPwGsQ(u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡁࡥࡦࡲࡲࡸ࠴ࡓࡦࡶࡄࡨࡩࡵ࡮ࡆࡰࡤࡦࡱ࡫ࡤࠣ࠮ࠥ࡭ࡩࠨ࠺࠲࠮ࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡡࡥࡦࡲࡲ࡮ࡪࠢ࠻ࠤࠪ࠻")+yBSZ8wPGNL4iV5bM+uynKGh9Vv4oSsWCBa0gdr32(u"ࠨࠤ࠯ࠦࡪࡴࡡࡣ࡮ࡨࡨࠧࡀࡴࡳࡷࡨࢁࢂ࠭࠼"))
		if xiEgOmve1dWZX(u"ࠩࡒࡏࠬ࠽") in zJcIxuwqF6mng4aeL2rs0MTdK: XFH7MyorAkS08RNjhg = uiUSXfolyczwQ(u"࡚ࡲࡶࡧࢎ")
	if XFH7MyorAkS08RNjhg: i2btzDPXF5x4JCgdQ3m.Dialog().ok(uiUSXfolyczwQ(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭࠾"),a5tvLNjCry(u"ࠫั๐ฯࠡ࠰࠱ࠤ๋าอหࠢ฼้้๐ษࠡฬฮฬ๏ะࠠศๆศูิอัࠡษ็ๆิ๐ๅࠡ࡞ࡱࡠࡳࠦࠧ࠿")+filename)
	else: i2btzDPXF5x4JCgdQ3m.Dialog().ok(ff2d9Z5mxuMyqi7XVJ4YoDj(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨࡀ"),H0ksjBLAC8zVh35gW4ufU6(u"࠭ไๅลึๅࠥ࠴࠮ࠡใื่ฯูࠦๆๆํอࠥะหษ์อࠤฬ๊ลึัสีࠥอไใัํ้ࠥࡢ࡮࡝ࡰࠣࠫࡁ")+filename)
	IulYmRxWHL0eZSAPp8JqkiO()
	return
def IulYmRxWHL0eZSAPp8JqkiO(PXYSCymHUufO0x4ZG=None):
	if PXYSCymHUufO0x4ZG==None:
		fd7MQgcahTmSxo = r0rZO6h9J8TNfIb4(x3RuGaLQ4cey0mt(u"ࠧฮฬ์ࠤ๏ฮโ๊ࠢส่ส฻ฯศำࠣห้่ฯ๋็ࠣๅ๏ࠦฬ่ษี็ࠥ๎ไศࠢํฮ๊ࠦสฮัํฯ์ࠦร้ฬ๋้ฬะ๊ไ์สࠤ࠳࠴๋ࠠฮหࠤศ์ࠠหไ๋้ࠥฮล๋ไสๅࠥอไหฯา๎ะࠦวๅล๋ฮํ๋วห์ๆ๎ࠥ࠴࠮้ࠡ็ࠤฯื๊ะࠢศ๎็อแࠡษ็ฮาี๊ฬࠢส่ศ๎ส้็สฮ๏้๊ࠡๆ็ฬึ์วๆฮࠣรࠦ࠭ࡂ"))
		if fd7MQgcahTmSxo==-ldXtDfxokBZGEwmuY94K5TiOJ6(u"࠶ࡿ"): return
		PXYSCymHUufO0x4ZG = RkiQlBV7rwTK2aZPdpG8WLY(u"ࡕࡴࡸࡩ࢐") if fd7MQgcahTmSxo==og0RUiBKzN5p4(u"࠷ࢀ") else SSTimV6rXJe9f4nCPaUgdGpOlu(u"ࡆࡢ࡮ࡶࡩ࢏")
	if Oi5GqMVfB8oJ9pDtQCPNmlY3nXW: UjApiY0dIcefl5GaktqL = kX7GlIrQYFDW0PuCi.path.join(DDWLbr8MRfNk3,Dvx5khQtfiJc6ws1XK89GVeNp0IYzn(u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪࡃ"),O0qe5lNJfWbLGsi1QzAXZ3hvYBwmk(u"ࠩࡇࡥࡹࡧࡢࡢࡵࡨࠫࡄ"),TZkhGjbENyC2rPVA6fK8(u"ࠪࡅࡩࡪ࡯࡯ࡵ࠶࠷࠳ࡪࡢࠨࡅ"))
	else: UjApiY0dIcefl5GaktqL = kX7GlIrQYFDW0PuCi.path.join(DDWLbr8MRfNk3,xiEgOmve1dWZX(u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭ࡆ"),SSTimV6rXJe9f4nCPaUgdGpOlu(u"ࠬࡊࡡࡵࡣࡥࡥࡸ࡫ࠧࡇ"),iCk3MmElRa0ISdZpDxwfc1FX(u"࠭ࡁࡥࡦࡲࡲࡸ࠸࠷࠯ࡦࡥࠫࡈ"))
	import sqlite3 as jjVFSNpRseu7
	XFH7MyorAkS08RNjhg = iCk3MmElRa0ISdZpDxwfc1FX(u"ࡈࡤࡰࡸ࡫࢑")
	OZz0g2IlfaWAFj73vE = j2SXhepCgAvyr4(u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥࠩࡉ")
	MM4l2sxb9BJUR5 = a5tvLNjCry(u"ࠨࡤ࡯ࡥࡨࡱ࡬ࡪࡵࡷࠫࡊ") if avj1sKEB0bD2excRYmF79NIgkP3 else ldXtDfxokBZGEwmuY94K5TiOJ6(u"ࠩࡸࡴࡩࡧࡴࡦࡡࡵࡹࡱ࡫ࡳࠨࡋ")
	try:
		mwsSu7jy38VelOkhgTC = jjVFSNpRseu7.connect(UjApiY0dIcefl5GaktqL)
		mwsSu7jy38VelOkhgTC.text_factory = str
		a0qMeLJNFlw5mDrOECWGgPKpnz = mwsSu7jy38VelOkhgTC.cursor()
		a0qMeLJNFlw5mDrOECWGgPKpnz.execute(kVa3fbJpuN2(u"ࠪࡗࡊࡒࡅࡄࡖࠣࡳࡷ࡯ࡧࡪࡰࠣࡊࡗࡕࡍࠡ࡫ࡱࡷࡹࡧ࡬࡭ࡧࡧࠤ࡜ࡎࡅࡓࡇࠣࡥࡩࡪ࡯࡯ࡋࡇࠤࡂࠦࠢࠨࡌ")+yBSZ8wPGNL4iV5bM+uynKGh9Vv4oSsWCBa0gdr32(u"ࠫࠧࠦ࠻ࠨࡍ"))
		RCPpiIW5S4FTxYm = a0qMeLJNFlw5mDrOECWGgPKpnz.fetchall()
		if RCPpiIW5S4FTxYm and OZz0g2IlfaWAFj73vE not in str(RCPpiIW5S4FTxYm): a0qMeLJNFlw5mDrOECWGgPKpnz.execute(a5tvLNjCry(u"࡛ࠬࡐࡅࡃࡗࡉࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤࠡࡕࡈࡘࠥࡵࡲࡪࡩ࡬ࡲࠥࡃࠠࠣࠩࡎ")+OZz0g2IlfaWAFj73vE+kVa3fbJpuN2(u"࡙࠭ࠢࠡࡋࡉࡗࡋࠠࡢࡦࡧࡳࡳࡏࡄࠡ࠿ࠣࠦࠬࡏ")+yBSZ8wPGNL4iV5bM+XPsWmoIKhE4ndqUjLk6Yp8a2Drg(u"ࠧࠣࠢ࠾ࠫࡐ"))
		a0qMeLJNFlw5mDrOECWGgPKpnz.execute(XPsWmoIKhE4ndqUjLk6Yp8a2Drg(u"ࠨࡕࡈࡐࡊࡉࡔࠡࠬࠣࡊࡗࡕࡍࠡࠩࡑ")+MM4l2sxb9BJUR5+SSTimV6rXJe9f4nCPaUgdGpOlu(u"࡛ࠩࠣࡍࡋࡒࡆࠢࡤࡨࡩࡵ࡮ࡊࡆࠣࡁࠥࠨࠧࡒ")+yBSZ8wPGNL4iV5bM+KVAWmnJX6TcU9xHvRq0b7dug2r(u"ࠪࠦࠥࡁࠧࡓ"))
		RCPpiIW5S4FTxYm = a0qMeLJNFlw5mDrOECWGgPKpnz.fetchall()
		kO0MAngBVuxym7N6F4Rvo35IrWXQ = ldXtDfxokBZGEwmuY94K5TiOJ6(u"ࡊࡦࡲࡳࡦ࢓") if RCPpiIW5S4FTxYm else yyzX7esWRD4(u"ࡗࡶࡺ࡫࢒")
		if not kO0MAngBVuxym7N6F4Rvo35IrWXQ and not PXYSCymHUufO0x4ZG: a0qMeLJNFlw5mDrOECWGgPKpnz.execute(RTLEXavDjlN(u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࠪࡔ")+MM4l2sxb9BJUR5+jLn7lHtqCadP1JYVbRWX0AK(u"ࠬࠦࡗࡉࡇࡕࡉࠥࡧࡤࡥࡱࡱࡍࡉࠦ࠽ࠡࠤࠪࡕ")+yBSZ8wPGNL4iV5bM+NCXSi0gIb9vHWYpkjr5BAthQuZMP2s(u"࠭ࠢࠡ࠽ࠪࡖ"))
		elif kO0MAngBVuxym7N6F4Rvo35IrWXQ and PXYSCymHUufO0x4ZG:
			if avj1sKEB0bD2excRYmF79NIgkP3: a0qMeLJNFlw5mDrOECWGgPKpnz.execute(jLn7lHtqCadP1JYVbRWX0AK(u"ࠧࡊࡐࡖࡉࡗ࡚ࠠࡊࡐࡗࡓࠥ࠭ࡗ")+MM4l2sxb9BJUR5+jLn7lHtqCadP1JYVbRWX0AK(u"ࠨࠢࠫࡥࡩࡪ࡯࡯ࡋࡇ࠭ࠥ࡜ࡁࡍࡗࡈࡗࠥ࠮ࠢࠨࡘ")+yBSZ8wPGNL4iV5bM+NCXSi0gIb9vHWYpkjr5BAthQuZMP2s(u"ࠩࠥ࠭ࠥࡁ࡙ࠧ"))
			else: a0qMeLJNFlw5mDrOECWGgPKpnz.execute(kVa3fbJpuN2(u"ࠪࡍࡓ࡙ࡅࡓࡖࠣࡍࡓ࡚ࡏ࡚ࠡࠩ")+MM4l2sxb9BJUR5+xiEgOmve1dWZX(u"ࠫࠥ࠮ࡡࡥࡦࡲࡲࡎࡊࠬࡶࡲࡧࡥࡹ࡫ࡒࡶ࡮ࡨ࠭ࠥ࡜ࡁࡍࡗࡈࡗࠥ࠮ࠢࠨ࡛")+yBSZ8wPGNL4iV5bM+MoV1fmXK9ESylW7OCbjNvxaegPwGsQ(u"ࠬࠨࠬ࠲ࠫࠣ࠿ࠬ࡜"))
		mwsSu7jy38VelOkhgTC.commit()
		mwsSu7jy38VelOkhgTC.close()
		XFH7MyorAkS08RNjhg = uynKGh9Vv4oSsWCBa0gdr32(u"࡙ࡸࡵࡦ࢔")
	except: pass
	if XFH7MyorAkS08RNjhg:
		xNkdSWnUqe.sleep(iCk3MmElRa0ISdZpDxwfc1FX(u"࠱ࢁ"))
		DM7hrPUFE1BXQo.executebuiltin(x3RuGaLQ4cey0mt(u"࠭ࡕࡱࡦࡤࡸࡪࡒ࡯ࡤࡣ࡯ࡅࡩࡪ࡯࡯ࡵࠪ࡝"))
		xNkdSWnUqe.sleep(WcRKZQ05gVPGIAUeTz96OSLNuk3jpv(u"࠲ࢂ"))
		i2btzDPXF5x4JCgdQ3m.Dialog().ok(jLn7lHtqCadP1JYVbRWX0AK(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ࡞"),Dvx5khQtfiJc6ws1XK89GVeNp0IYzn(u"ࠨฮํำࠥ࠴࠮่ࠡฯัฯࠦวๅ฻่่๏ฯࠧ࡟"))
	else: i2btzDPXF5x4JCgdQ3m.Dialog().ok(itvje9547cgw(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬࡠ"),yyzX7esWRD4(u"่้ࠪษำโࠢ࠱࠲ࠥ็ิๅฬࠣห้฿ๅๅ์ฬࠫࡡ"))
	return
OgdxI7wKrRmMCoithGFEs = gg1ld5VjY2mp.argv[jLn7lHtqCadP1JYVbRWX0AK(u"࠳ࢃ")]
yBSZ8wPGNL4iV5bM = uynKGh9Vv4oSsWCBa0gdr32(u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩࡢ")
xYRbh0QepFEszf3nN = DM7hrPUFE1BXQo.getInfoLabel(uynKGh9Vv4oSsWCBa0gdr32(u"࡙ࠧࡹࡴࡶࡨࡱ࠳ࡈࡵࡪ࡮ࡧ࡚ࡪࡸࡳࡪࡱࡱࠦࡣ"))
O9Os02S6TdzZfJlm = TW0UsyRrExatz.findall(uiUSXfolyczwQ(u"࠭ࠨ࡝ࡦ࡟ࡨࡡ࠴࡜ࡥࠫࠪࡤ"),xYRbh0QepFEszf3nN,TW0UsyRrExatz.DOTALL)
O9Os02S6TdzZfJlm = float(O9Os02S6TdzZfJlm[itvje9547cgw(u"࠳ࢄ")])
avj1sKEB0bD2excRYmF79NIgkP3 = O9Os02S6TdzZfJlm<O0qe5lNJfWbLGsi1QzAXZ3hvYBwmk(u"࠵࠾ࢅ")
Oi5GqMVfB8oJ9pDtQCPNmlY3nXW = O9Os02S6TdzZfJlm>j2SXhepCgAvyr4(u"࠶࠾࠮࠺࠻ࢆ")
if Oi5GqMVfB8oJ9pDtQCPNmlY3nXW:
	KSjvH4opAFLsl0R69ycfBamO = Wi6Q1jbN3Kw.translatePath(x3RuGaLQ4cey0mt(u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲ࡰࡴ࡭ࡰࡢࡶ࡫ࠫࡥ"))
	DDWLbr8MRfNk3 = Wi6Q1jbN3Kw.translatePath(x3RuGaLQ4cey0mt(u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳࡭ࡵ࡭ࡦࠩࡦ"))
else:
	KSjvH4opAFLsl0R69ycfBamO = DM7hrPUFE1BXQo.translatePath(itvje9547cgw(u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴ࡲ࡯ࡨࡲࡤࡸ࡭࠭ࡧ"))
	DDWLbr8MRfNk3 = DM7hrPUFE1BXQo.translatePath(uynKGh9Vv4oSsWCBa0gdr32(u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡨࡰ࡯ࡨࠫࡨ"))
izEvdUIVfhmegLS98Row26QaC = kX7GlIrQYFDW0PuCi.path.join(KSjvH4opAFLsl0R69ycfBamO,a5tvLNjCry(u"ࠫࡰࡵࡤࡪ࠰࡯ࡳ࡬࠭ࡩ"))
dAx8a0FiwbcNuWfLzRETY9JnHrsDMm = kX7GlIrQYFDW0PuCi.path.join(KSjvH4opAFLsl0R69ycfBamO,x3RuGaLQ4cey0mt(u"ࠬࡱ࡯ࡥ࡫࠱ࡳࡱࡪ࠮࡭ࡱࡪࠫࡪ"))
if   OgdxI7wKrRmMCoithGFEs==xiEgOmve1dWZX(u"࠭ࡳࡦࡰࡧࡣࡱࡵࡧࡧ࡫࡯ࡩࠬ࡫")			: GymkHSIcaTnsVwo61xtRQWu(izEvdUIVfhmegLS98Row26QaC)
elif OgdxI7wKrRmMCoithGFEs==JAj6q7amCXyFE2GTxNup3l40WdVt(u"ࠧࡴࡧࡱࡨࡤࡵ࡬ࡥࡡ࡯ࡳ࡬࡬ࡩ࡭ࡧࠪ࡬")		: GymkHSIcaTnsVwo61xtRQWu(dAx8a0FiwbcNuWfLzRETY9JnHrsDMm)
elif OgdxI7wKrRmMCoithGFEs==SSTimV6rXJe9f4nCPaUgdGpOlu(u"ࠨࡦࡨࡰࡪࡺࡥࡠࡵࡨࡸࡹ࡯࡮ࡨࡵࠪ࡭")		: xx90LqEZ83IoT6()
elif OgdxI7wKrRmMCoithGFEs==kVa3fbJpuN2(u"ࠩࡧࡩࡱ࡫ࡴࡦࡡࡦࡥࡨ࡮ࡥࠨ࡮")			: i0IozNp5hjatwB2TbmOsyLkA6gUr4()
elif OgdxI7wKrRmMCoithGFEs==KVAWmnJX6TcU9xHvRq0b7dug2r(u"ࠪ࡭ࡳࡹࡴࡢ࡮࡯ࡣࡴࡲࡤࡠࡸࡨࡶࡸ࡯࡯࡯ࠩ࡯")	: mI7sUt4FwlHp1()
elif OgdxI7wKrRmMCoithGFEs==uiUSXfolyczwQ(u"ࠫࡲࡵࡤࡪࡨࡼࡣࡦࡻࡴࡰࡷࡳࡨࡦࡺࡥࠨࡰ")	: IulYmRxWHL0eZSAPp8JqkiO()
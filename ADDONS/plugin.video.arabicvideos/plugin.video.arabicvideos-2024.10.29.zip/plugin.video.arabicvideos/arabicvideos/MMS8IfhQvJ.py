# -*- coding: utf-8 -*-
from a1aDsx9ioY import *
s5slfAmHkUtMR3WSKY1ZTX = 'TVFUN'
TdtCLWYSJNK8zOb = '_TVF_'
ffVP3AK5RqhkgYnjZoNis = Kkfl8xemuHbd1w3a0ABPcDrN[s5slfAmHkUtMR3WSKY1ZTX][0]
tlcXBJEfIHF02vQ6yxSom9z1 = ['بث مباشر']
def RAndFk3y4Pbvs29(mode,url,text):
	if   mode==460: tRojAyBgfDH37eLCwP4dWl = hXz0OvlBbVLste3xWE6C74()
	elif mode==461: tRojAyBgfDH37eLCwP4dWl = UUhwKBgI2nt(url,text)
	elif mode==462: tRojAyBgfDH37eLCwP4dWl = sWujQcGynM9NtJeTfqk3D(url)
	elif mode==463: tRojAyBgfDH37eLCwP4dWl = EL0QAd56tj7Db9eFSw3UZofIsra8(url)
	elif mode==469: tRojAyBgfDH37eLCwP4dWl = b6WZDnA0dLBiCITrF37OS(text)
	else: tRojAyBgfDH37eLCwP4dWl = False
	return tRojAyBgfDH37eLCwP4dWl
def hXz0OvlBbVLste3xWE6C74():
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',ffVP3AK5RqhkgYnjZoNis,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'TVFUN-MENU-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'بحث في الموقع',G9G0YqivIfmUWO8K,469,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'_REMEMBERRESULTS_')
	Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"menu-btn"(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?<span>(.*?)</span>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title in items:
			if 'http' not in Y6YdkAMluFbwx: Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+Y6YdkAMluFbwx
			if title=='الرئيسية': title = 'جديد حلقات تيفي فان'
			if title in tlcXBJEfIHF02vQ6yxSom9z1: continue
			Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,461)
	return
def UUhwKBgI2nt(url,TDgxqHQoZd8v=G9G0YqivIfmUWO8K):
	items = []
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'TVFUN-TITLES-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('class="head-title"(.*?)id="footer"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('class="thumb.*?href="(.*?)".*?src="(.*?)" alt="(.*?)"',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		ehHpxSUAZnVITs4y5XjDKb8zC = []
		N78M4ZjFtLi0CvKDzTlmERSe9rc = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
		for Y6YdkAMluFbwx,M4qkBDatEIf3T,title in items:
			title = '_MOD_'+title.replace('<br>',ww0sZkBU9JKd).replace(zVnkcBX6aJDPRpqyCjhoSZYQbL,ww0sZkBU9JKd).strip(ww0sZkBU9JKd)
			if 'http' not in Y6YdkAMluFbwx: Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+Y6YdkAMluFbwx
			Y6YdkAMluFbwx = aKAyEnjxIlzZtCTv(Y6YdkAMluFbwx)
			RnV3EqPNpXTDuI7 = oo9kuULlebNgpY0Om.findall('(.*?) الحلقة \d+',title,oo9kuULlebNgpY0Om.DOTALL)
			if any(yW70dtahIjkPCJg2TA in title for yW70dtahIjkPCJg2TA in N78M4ZjFtLi0CvKDzTlmERSe9rc):
				Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,462,M4qkBDatEIf3T)
			elif RnV3EqPNpXTDuI7 and 'الحلقة' in title:
				title = '_MOD_' + RnV3EqPNpXTDuI7[0]
				if title not in ehHpxSUAZnVITs4y5XjDKb8zC:
					Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,463,M4qkBDatEIf3T)
					ehHpxSUAZnVITs4y5XjDKb8zC.append(title)
			else: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,463,M4qkBDatEIf3T)
	if TDgxqHQoZd8v!='latest':
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"pagination"(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if cSLKDEATk7y10ovtGZCwF:
			BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
			items = oo9kuULlebNgpY0Om.findall('<a href="(.*?)".*?>(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
			for Y6YdkAMluFbwx,title in items:
				Y6YdkAMluFbwx = Y6YdkAMluFbwx.strip(ww0sZkBU9JKd)
				if Y6YdkAMluFbwx=="": continue
				if 'http' not in Y6YdkAMluFbwx: Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+Y6YdkAMluFbwx
				if title!=G9G0YqivIfmUWO8K: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'صفحة '+title,Y6YdkAMluFbwx,461)
	return
def EL0QAd56tj7Db9eFSw3UZofIsra8(url):
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'TVFUN-EPISODES-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('class="head-title"(.*?)id="footer"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('class="thumb.*?href="(.*?)".*?src="(.*?)" alt="(.*?)"',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		if items:
			for Y6YdkAMluFbwx,M4qkBDatEIf3T,title in items:
				title = '_MOD_'+title.replace('<br>',ww0sZkBU9JKd).replace(zVnkcBX6aJDPRpqyCjhoSZYQbL,ww0sZkBU9JKd).strip(ww0sZkBU9JKd)
				if 'http' not in Y6YdkAMluFbwx: Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+Y6YdkAMluFbwx
				Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,462,M4qkBDatEIf3T)
		else:
			items = oo9kuULlebNgpY0Om.findall('class="episode.*?href="(.*?)" title="(.*?)"',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
			for Y6YdkAMluFbwx,title in items:
				if 'http' not in Y6YdkAMluFbwx: Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+Y6YdkAMluFbwx
				Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,462)
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"pagination"(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?>(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title in items:
			Y6YdkAMluFbwx = Y6YdkAMluFbwx.strip(ww0sZkBU9JKd)
			if Y6YdkAMluFbwx=="": continue
			if 'http' not in Y6YdkAMluFbwx: Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+Y6YdkAMluFbwx
			if title!=G9G0YqivIfmUWO8K: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'صفحة '+title,Y6YdkAMluFbwx,463)
	return
def sWujQcGynM9NtJeTfqk3D(url):
	ODnaR0N8UHv7Twy6jS = []
	XXzvmn7ewM8yBfoxua = url.replace('/video/','/watch/')
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',XXzvmn7ewM8yBfoxua,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'TVFUN-PLAY-2nd')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('VideoServers"(.*?)</div>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		dsGzqX4k0a8RLyc = oo9kuULlebNgpY0Om.findall('''setVideo\('(.*?)'\).*?">(.*?)<''',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for SJ8AtziPBkwHTjoFgsIvYKq1WrMn0V,name in dsGzqX4k0a8RLyc:
			SJ8AtziPBkwHTjoFgsIvYKq1WrMn0V = SJ8AtziPBkwHTjoFgsIvYKq1WrMn0V[2:]
			if gA0m6CQUyfLG: SJ8AtziPBkwHTjoFgsIvYKq1WrMn0V = SJ8AtziPBkwHTjoFgsIvYKq1WrMn0V.decode(f3uIcZ2C6pzbX1JlFBrVOdt)
			SJ8AtziPBkwHTjoFgsIvYKq1WrMn0V = jaFsD83SB9ZQkrxeI.b64decode(SJ8AtziPBkwHTjoFgsIvYKq1WrMn0V)
			if LTze51miOknVcslNF43WSA6vMjYZt: SJ8AtziPBkwHTjoFgsIvYKq1WrMn0V = SJ8AtziPBkwHTjoFgsIvYKq1WrMn0V.decode(f3uIcZ2C6pzbX1JlFBrVOdt)
			Y6YdkAMluFbwx = oo9kuULlebNgpY0Om.findall('src="(.*?)"',SJ8AtziPBkwHTjoFgsIvYKq1WrMn0V,oo9kuULlebNgpY0Om.DOTALL)
			Y6YdkAMluFbwx = Y6YdkAMluFbwx[0]
			if 'http' not in Y6YdkAMluFbwx:
				if '//' in Y6YdkAMluFbwx: Y6YdkAMluFbwx = 'http:'+Y6YdkAMluFbwx
				else: Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+Y6YdkAMluFbwx
			if Y6YdkAMluFbwx not in ODnaR0N8UHv7Twy6jS:
				Y6YdkAMluFbwx = Y6YdkAMluFbwx+'?named='+name+'__watch'
				ODnaR0N8UHv7Twy6jS.append(Y6YdkAMluFbwx)
	import iOVAoxDJew
	iOVAoxDJew.XTjZSa3Idi5DwmqxWrJyKGk(ODnaR0N8UHv7Twy6jS,s5slfAmHkUtMR3WSKY1ZTX,'video',url)
	return
def b6WZDnA0dLBiCITrF37OS(search):
	search,EIcQfuLpMO2jX,showDialogs = bY6tjyS08hUC(search)
	if not search:
		search = ZT7zGWSCtpvfmwMNRjYrKL()
		if not search: return
	if ww0sZkBU9JKd in search:
		if showDialogs: hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'TVFUN موقع تيفي فان','للأسف البحث في هذا الموقع لا يعمل عند طلب أكثر من كلمة واحدة ... يرجى البحث عن كلمة واحدة فقط')
		return
	url = ffVP3AK5RqhkgYnjZoNis+'/q/'+search+'/'
	UUhwKBgI2nt(url)
	return